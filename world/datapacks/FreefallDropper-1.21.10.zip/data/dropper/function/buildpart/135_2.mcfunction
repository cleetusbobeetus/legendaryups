setblock 160 218 574 minecraft:blue_concrete
fill 160 218 578 161 218 578 minecraft:black_concrete
fill 160 218 580 160 219 580 minecraft:blue_concrete
fill 160 218 581 161 219 581 minecraft:black_concrete
fill 160 218 583 160 219 583 minecraft:blue_concrete
fill 161 218 563 161 219 563 minecraft:black_concrete
fill 161 218 564 161 219 564 minecraft:blue_concrete
fill 161 218 565 162 219 565 minecraft:black_concrete
fill 161 218 567 161 219 567 minecraft:blue_concrete
fill 161 218 568 162 218 568 minecraft:black_concrete
setblock 161 218 572 minecraft:black_concrete
fill 161 218 573 161 219 573 minecraft:blue_concrete
fill 161 218 574 162 218 574 minecraft:black_concrete
fill 161 218 579 161 219 579 minecraft:blue_concrete
fill 161 218 580 162 219 580 minecraft:black_concrete
fill 161 218 582 161 219 582 minecraft:blue_concrete
fill 161 218 583 162 219 583 minecraft:black_concrete
fill 162 218 563 162 219 563 minecraft:blue_concrete
fill 162 218 564 163 219 564 minecraft:black_concrete
fill 162 218 566 162 219 566 minecraft:blue_concrete
fill 162 218 567 163 219 567 minecraft:black_concrete
setblock 162 218 569 minecraft:blue_concrete
fill 162 218 570 162 218 571 minecraft:black_concrete
setblock 162 218 572 minecraft:blue_concrete
setblock 162 218 573 minecraft:black_concrete
setblock 162 218 575 minecraft:blue_concrete
fill 162 218 576 162 218 577 minecraft:black_concrete
setblock 162 218 578 minecraft:blue_concrete
fill 162 218 579 163 219 579 minecraft:black_concrete
fill 162 218 581 162 219 581 minecraft:blue_concrete
fill 162 218 582 163 219 582 minecraft:black_concrete
fill 163 218 563 164 219 563 minecraft:black_concrete
fill 163 218 565 163 219 565 minecraft:blue_concrete
fill 163 218 566 164 219 566 minecraft:black_concrete
fill 163 218 568 163 219 568 minecraft:blue_concrete
fill 163 218 569 163 219 570 minecraft:black_concrete
setblock 163 218 571 minecraft:blue_concrete
fill 163 218 575 163 218 576 minecraft:black_concrete
fill 163 218 577 163 219 577 minecraft:blue_concrete
fill 163 218 578 164 219 578 minecraft:black_concrete
fill 163 218 580 163 219 580 minecraft:blue_concrete
fill 163 218 581 164 219 581 minecraft:black_concrete
fill 163 218 583 163 219 583 minecraft:blue_concrete
setblock 163 218 599 minecraft:blue_concrete
fill 164 218 562 164 219 562 minecraft:black_concrete
fill 164 218 564 164 219 564 minecraft:blue_concrete
fill 164 218 565 165 219 565 minecraft:black_concrete
fill 164 218 567 164 219 567 minecraft:blue_concrete
fill 164 218 568 164 219 569 minecraft:black_concrete
fill 164 218 570 164 219 570 minecraft:blue_concrete
fill 164 218 571 165 218 571 minecraft:black_concrete
setblock 164 218 575 minecraft:black_concrete
fill 164 218 576 164 219 576 minecraft:blue_concrete
fill 164 218 577 165 219 577 minecraft:black_concrete
fill 164 218 579 164 219 579 minecraft:blue_concrete
fill 164 218 580 165 219 580 minecraft:black_concrete
fill 164 218 582 164 219 582 minecraft:blue_concrete
fill 164 218 583 164 219 584 minecraft:black_concrete
fill 165 218 563 165 219 563 minecraft:blue_concrete
fill 165 218 564 166 219 564 minecraft:black_concrete
fill 165 218 566 165 219 566 minecraft:blue_concrete
fill 165 218 567 165 218 568 minecraft:black_concrete
setblock 165 218 569 minecraft:blue_concrete
setblock 165 218 570 minecraft:black_concrete
setblock 165 218 575 minecraft:blue_concrete
fill 165 218 576 166 218 576 minecraft:black_concrete
fill 165 218 578 165 219 578 minecraft:blue_concrete
fill 165 218 579 166 219 579 minecraft:black_concrete
fill 165 218 581 165 219 581 minecraft:blue_concrete
fill 165 218 582 165 219 583 minecraft:black_concrete
setblock 165 218 599 minecraft:blue_concrete
fill 166 218 563 167 219 563 minecraft:black_concrete
fill 166 218 565 166 219 565 minecraft:blue_concrete
fill 166 218 566 166 218 567 minecraft:black_concrete
setblock 166 218 571 minecraft:blue_concrete
fill 166 218 572 166 218 573 minecraft:black_concrete
setblock 166 218 574 minecraft:blue_concrete
setblock 166 218 575 minecraft:black_concrete
setblock 166 218 577 minecraft:blue_concrete
fill 166 218 578 167 218 578 minecraft:black_concrete
fill 166 218 580 166 219 580 minecraft:blue_concrete
fill 166 218 581 166 219 582 minecraft:black_concrete
fill 166 218 583 166 219 583 minecraft:blue_concrete
fill 167 218 564 167 219 564 minecraft:blue_concrete
fill 167 218 565 167 219 566 minecraft:black_concrete
setblock 167 218 567 minecraft:blue_concrete
fill 167 218 571 167 218 572 minecraft:black_concrete
fill 167 218 573 167 219 573 minecraft:blue_concrete
fill 167 218 574 168 218 574 minecraft:black_concrete
fill 167 218 579 167 219 579 minecraft:blue_concrete
fill 167 218 580 167 219 581 minecraft:black_concrete
fill 167 218 582 167 219 582 minecraft:blue_concrete
fill 167 218 583 168 219 583 minecraft:black_concrete
fill 168 218 563 168 219 563 minecraft:blue_concrete
fill 168 218 564 168 219 565 minecraft:black_concrete
fill 168 218 566 168 219 566 minecraft:blue_concrete
fill 168 218 567 169 218 567 minecraft:black_concrete
setblock 168 218 571 minecraft:black_concrete
fill 168 218 572 168 219 572 minecraft:blue_concrete
fill 168 218 573 169 219 573 minecraft:black_concrete
setblock 168 218 578 minecraft:blue_concrete
fill 168 218 579 168 219 580 minecraft:black_concrete
fill 168 218 581 168 219 581 minecraft:blue_concrete
fill 168 218 582 169 219 582 minecraft:black_concrete
fill 169 218 564 169 219 564 minecraft:black_concrete
fill 169 218 565 169 219 565 minecraft:blue_concrete
fill 169 218 566 170 219 566 minecraft:black_concrete
setblock 169 218 568 minecraft:blue_concrete
fill 169 218 569 169 218 570 minecraft:black_concrete
setblock 169 218 571 minecraft:blue_concrete
fill 169 218 572 170 219 572 minecraft:black_concrete
setblock 169 218 574 minecraft:blue_concrete
fill 169 218 578 169 218 579 minecraft:black_concrete
fill 169 218 580 169 219 580 minecraft:blue_concrete
fill 169 218 581 170 219 581 minecraft:black_concrete
fill 170 218 564 170 219 564 minecraft:blue_concrete
fill 170 218 565 171 219 565 minecraft:black_concrete
fill 170 218 567 170 219 567 minecraft:blue_concrete
fill 170 218 568 170 219 569 minecraft:black_concrete
fill 170 218 570 170 219 570 minecraft:blue_concrete
fill 170 218 571 171 219 571 minecraft:black_concrete
fill 170 218 573 170 219 573 minecraft:blue_concrete
fill 170 218 574 170 218 575 minecraft:black_concrete
setblock 170 218 576 minecraft:blue_concrete
fill 170 218 577 170 218 578 minecraft:black_concrete
fill 170 218 579 170 219 579 minecraft:blue_concrete
fill 170 218 580 171 219 580 minecraft:black_concrete
fill 170 218 582 170 219 582 minecraft:blue_concrete
fill 171 218 566 171 219 566 minecraft:blue_concrete
fill 171 218 567 171 219 568 minecraft:black_concrete
fill 171 218 569 171 219 569 minecraft:blue_concrete
fill 171 218 570 172 219 570 minecraft:black_concrete
fill 171 218 572 171 219 572 minecraft:blue_concrete
fill 171 218 573 171 219 574 minecraft:black_concrete
fill 171 218 575 171 219 575 minecraft:blue_concrete
fill 171 218 576 171 219 577 minecraft:black_concrete
fill 171 218 578 171 219 578 minecraft:blue_concrete
fill 171 218 579 172 219 579 minecraft:black_concrete
fill 171 218 581 171 219 581 minecraft:blue_concrete
fill 172 218 566 172 219 567 minecraft:black_concrete
fill 172 218 568 172 219 568 minecraft:blue_concrete
fill 172 218 569 173 219 569 minecraft:black_concrete
fill 172 218 571 172 219 571 minecraft:blue_concrete
fill 172 218 572 172 219 573 minecraft:black_concrete
fill 172 218 574 172 219 574 minecraft:blue_concrete
fill 172 218 575 172 219 576 minecraft:black_concrete
fill 172 218 577 172 219 577 minecraft:blue_concrete
fill 172 218 578 173 219 578 minecraft:black_concrete
fill 172 218 580 172 219 580 minecraft:blue_concrete
fill 173 218 567 173 219 567 minecraft:blue_concrete
fill 173 218 568 173 219 568 minecraft:black_concrete
fill 173 218 570 173 219 570 minecraft:blue_concrete
fill 173 218 571 173 219 572 minecraft:black_concrete
fill 173 218 573 173 219 573 minecraft:blue_concrete
fill 173 218 574 173 219 575 minecraft:black_concrete
fill 173 218 576 173 219 576 minecraft:blue_concrete
fill 173 218 577 174 219 577 minecraft:black_concrete
fill 173 218 579 173 219 579 minecraft:blue_concrete
fill 174 218 569 174 219 569 minecraft:blue_concrete
fill 174 218 570 174 219 571 minecraft:black_concrete
fill 174 218 572 174 219 572 minecraft:blue_concrete
fill 174 218 573 174 219 574 minecraft:black_concrete
fill 174 218 575 174 219 575 minecraft:blue_concrete
fill 174 218 576 174 219 576 minecraft:black_concrete
setblock 174 218 599 minecraft:blue_concrete
fill 175 218 573 175 219 573 minecraft:black_concrete
setblock 177 218 557 minecraft:blue_concrete
setblock 183 218 557 minecraft:blue_concrete
setblock 183 218 561 minecraft:blue_concrete
setblock 183 218 566 minecraft:blue_concrete
fill 183 218 589 183 218 590 minecraft:blue_concrete
fill 141 219 557 147 219 557 minecraft:black_concrete
fill 141 219 559 151 219 576 minecraft:black_concrete
fill 141 219 578 153 219 598 minecraft:black_concrete
setblock 141 219 599 minecraft:blue_concrete
fill 142 219 558 183 219 558 minecraft:black_concrete
fill 142 219 577 152 219 577 minecraft:black_concrete
fill 142 219 599 142 307 599 minecraft:black_concrete
fill 144 219 599 152 219 599 minecraft:black_concrete
fill 149 219 557 161 219 557 minecraft:black_concrete
fill 152 219 559 152 219 572 minecraft:black_concrete
setblock 152 219 573 minecraft:waxed_copper_block
fill 152 219 574 152 219 576 minecraft:black_concrete
fill 153 219 559 153 219 568 minecraft:black_concrete
fill 153 219 569 153 219 572 minecraft:waxed_copper_block
fill 153 219 574 153 219 577 minecraft:waxed_copper_block
fill 154 219 559 154 219 566 minecraft:black_concrete
fill 154 219 567 154 219 568 minecraft:waxed_copper_block
fill 154 219 578 154 219 579 minecraft:waxed_copper_block
fill 154 219 580 154 219 599 minecraft:black_concrete
fill 155 219 559 155 219 565 minecraft:black_concrete
setblock 155 219 566 minecraft:waxed_copper_block
setblock 155 219 580 minecraft:waxed_copper_block
fill 155 219 581 155 219 598 minecraft:black_concrete
fill 156 219 559 156 219 564 minecraft:black_concrete
setblock 156 219 565 minecraft:waxed_copper_block
setblock 156 219 581 minecraft:waxed_copper_block
fill 156 219 582 156 219 599 minecraft:black_concrete
fill 157 219 559 157 219 563 minecraft:black_concrete
setblock 157 219 564 minecraft:waxed_copper_block
setblock 157 219 569 minecraft:black_concrete
setblock 157 219 582 minecraft:waxed_copper_block
fill 157 219 583 157 219 598 minecraft:black_concrete
fill 158 219 559 159 219 562 minecraft:black_concrete
fill 158 219 563 159 219 563 minecraft:waxed_copper_block
fill 158 219 568 158 219 572 minecraft:shroomlight
fill 158 219 574 158 219 578 minecraft:shroomlight
fill 158 219 583 159 219 583 minecraft:waxed_copper_block
fill 158 219 584 159 219 598 minecraft:black_concrete
fill 159 219 568 162 219 568 minecraft:shroomlight
fill 159 219 569 161 219 571 minecraft:black_concrete
fill 159 219 572 162 219 572 minecraft:shroomlight
fill 159 219 573 160 219 573 minecraft:black_concrete
fill 159 219 574 162 219 574 minecraft:shroomlight
fill 159 219 575 161 219 577 minecraft:black_concrete
fill 159 219 578 162 219 578 minecraft:shroomlight
setblock 159 219 599 minecraft:white_concrete
fill 160 219 559 163 219 561 minecraft:black_concrete
fill 160 219 562 163 219 562 minecraft:waxed_copper_block
fill 160 219 584 163 219 584 minecraft:waxed_copper_block
fill 160 219 585 163 219 598 minecraft:black_concrete
fill 161 219 599 167 224 599 minecraft:black_concrete
fill 162 219 569 162 219 571 minecraft:shroomlight
setblock 162 219 573 minecraft:shroomlight
fill 162 219 575 162 219 577 minecraft:shroomlight
fill 163 219 557 167 219 557 minecraft:black_concrete
fill 163 219 571 169 219 571 minecraft:shroomlight
fill 163 219 575 166 219 575 minecraft:shroomlight
setblock 163 219 576 minecraft:black_concrete
fill 164 219 559 183 219 560 minecraft:black_concrete
setblock 164 219 561 minecraft:waxed_copper_block
setblock 164 219 585 minecraft:waxed_copper_block
fill 164 219 586 183 219 598 minecraft:black_concrete
fill 165 219 561 183 219 561 minecraft:black_concrete
fill 165 219 562 168 219 562 minecraft:waxed_copper_block
fill 165 219 567 165 219 570 minecraft:shroomlight
setblock 165 219 576 minecraft:black_concrete
fill 165 219 584 168 219 584 minecraft:waxed_copper_block
fill 165 219 585 183 219 585 minecraft:black_concrete
setblock 166 219 566 minecraft:black_concrete
fill 166 219 567 169 219 567 minecraft:shroomlight
fill 166 219 568 168 219 570 minecraft:black_concrete
fill 166 219 572 166 219 574 minecraft:shroomlight
fill 166 219 576 166 219 578 minecraft:shroomlight
setblock 167 219 572 minecraft:black_concrete
fill 167 219 574 170 219 574 minecraft:shroomlight
fill 167 219 575 169 219 577 minecraft:black_concrete
fill 167 219 578 170 219 578 minecraft:shroomlight
fill 169 219 557 174 219 557 minecraft:black_concrete
fill 169 219 562 183 219 562 minecraft:black_concrete
fill 169 219 563 170 219 563 minecraft:waxed_copper_block
fill 169 219 568 169 219 570 minecraft:shroomlight
setblock 169 219 579 minecraft:black_concrete
fill 169 219 583 170 219 583 minecraft:waxed_copper_block
fill 169 219 584 183 219 584 minecraft:black_concrete
fill 169 219 599 174 219 599 minecraft:black_concrete
fill 170 219 575 170 219 577 minecraft:shroomlight
fill 171 219 563 183 219 563 minecraft:black_concrete
setblock 171 219 564 minecraft:waxed_copper_block
setblock 171 219 582 minecraft:waxed_copper_block
fill 171 219 583 183 219 583 minecraft:black_concrete
fill 172 219 564 183 219 564 minecraft:black_concrete
setblock 172 219 565 minecraft:waxed_copper_block
setblock 172 219 581 minecraft:waxed_copper_block
fill 172 219 582 183 219 582 minecraft:black_concrete
fill 173 219 565 183 219 565 minecraft:black_concrete
setblock 173 219 566 minecraft:waxed_copper_block
setblock 173 219 580 minecraft:waxed_copper_block
fill 173 219 581 183 219 581 minecraft:black_concrete
fill 174 219 566 182 219 566 minecraft:black_concrete
fill 174 219 567 174 219 568 minecraft:waxed_copper_block
fill 174 219 578 174 219 579 minecraft:waxed_copper_block
fill 174 219 580 183 219 580 minecraft:black_concrete
fill 175 219 567 183 219 568 minecraft:black_concrete
fill 175 219 569 175 219 572 minecraft:waxed_copper_block
fill 175 219 574 175 219 577 minecraft:waxed_copper_block
fill 175 219 578 183 219 579 minecraft:black_concrete
fill 176 219 557 179 219 557 minecraft:black_concrete
fill 176 219 569 182 219 572 minecraft:black_concrete
setblock 176 219 573 minecraft:waxed_copper_block
fill 176 219 574 183 219 577 minecraft:black_concrete
setblock 176 219 599 minecraft:white_concrete
fill 177 219 573 183 219 573 minecraft:black_concrete
fill 177 219 599 183 219 599 minecraft:black_concrete
fill 181 219 557 183 234 557 minecraft:black_concrete
setblock 183 219 566 minecraft:shroomlight
fill 183 219 569 183 281 569 minecraft:black_concrete
fill 183 219 571 183 290 572 minecraft:black_concrete
fill 141 220 557 141 221 557 minecraft:blue_concrete
fill 141 220 558 141 220 562 minecraft:black_concrete
setblock 141 220 563 minecraft:blue_concrete
fill 141 220 564 141 224 567 minecraft:black_concrete
setblock 141 220 568 minecraft:blue_concrete
fill 141 220 569 141 220 576 minecraft:black_concrete
fill 141 220 578 141 220 586 minecraft:black_concrete
setblock 141 220 587 minecraft:blue_concrete
fill 141 220 588 141 220 594 minecraft:black_concrete
setblock 141 220 595 minecraft:blue_concrete
fill 141 220 596 141 299 596 minecraft:black_concrete
setblock 141 220 597 minecraft:blue_concrete
fill 141 220 598 141 220 599 minecraft:black_concrete
fill 142 220 557 144 221 557 minecraft:black_concrete
fill 143 220 599 143 265 599 minecraft:black_concrete
setblock 144 220 599 minecraft:blue_concrete
setblock 145 220 557 minecraft:blue_concrete
fill 145 220 599 155 220 599 minecraft:black_concrete
fill 146 220 557 149 220 557 minecraft:black_concrete
setblock 150 220 557 minecraft:shroomlight
fill 151 220 557 165 220 557 minecraft:black_concrete
setblock 153 220 573 minecraft:waxed_copper_block
setblock 156 220 599 minecraft:blue_concrete
fill 157 220 599 160 220 599 minecraft:black_concrete
setblock 164 220 562 minecraft:waxed_copper_block
setblock 164 220 584 minecraft:waxed_copper_block
setblock 166 220 557 minecraft:shroomlight
fill 167 220 557 173 220 557 minecraft:black_concrete
fill 168 220 599 173 220 599 minecraft:black_concrete
setblock 174 220 557 minecraft:shroomlight
fill 174 220 599 174 221 599 minecraft:blue_concrete
fill 175 220 557 176 220 557 minecraft:black_concrete
setblock 175 220 573 minecraft:waxed_copper_block
fill 175 220 599 178 307 599 minecraft:black_concrete
setblock 177 220 557 minecraft:shroomlight
fill 178 220 557 178 249 557 minecraft:black_concrete
setblock 179 220 557 minecraft:blue_concrete
fill 179 220 599 179 221 599 minecraft:blue_concrete
fill 180 220 557 180 307 557 minecraft:black_concrete
fill 180 220 599 183 220 599 minecraft:black_concrete
fill 183 220 558 183 269 558 minecraft:black_concrete
setblock 183 220 559 minecraft:blue_concrete
fill 183 220 560 183 220 568 minecraft:black_concrete
fill 183 220 570 183 228 570 minecraft:black_concrete
setblock 183 220 573 minecraft:blue_concrete
fill 183 220 574 183 220 585 minecraft:black_concrete
setblock 183 220 586 minecraft:shroomlight
fill 183 220 587 183 220 592 minecraft:black_concrete
setblock 183 220 593 minecraft:shroomlight
fill 183 220 594 183 230 598 minecraft:black_concrete
fill 141 221 558 141 232 560 minecraft:black_concrete
setblock 141 221 561 minecraft:shroomlight
fill 141 221 562 141 223 563 minecraft:black_concrete
fill 141 221 568 141 243 568 minecraft:black_concrete
setblock 141 221 569 minecraft:blue_concrete
fill 141 221 570 141 228 575 minecraft:black_concrete
setblock 141 221 576 minecraft:blue_concrete
fill 141 221 577 141 222 579 minecraft:black_concrete
setblock 141 221 580 minecraft:blue_concrete
fill 141 221 581 141 224 590 minecraft:black_concrete
setblock 141 221 591 minecraft:blue_concrete
fill 141 221 592 141 224 595 minecraft:black_concrete
fill 141 221 597 141 224 597 minecraft:black_concrete
fill 141 221 598 141 221 599 minecraft:blue_concrete
fill 144 221 599 146 243 599 minecraft:black_concrete
fill 145 221 557 146 224 557 minecraft:black_concrete
setblock 147 221 557 minecraft:blue_concrete
setblock 147 221 599 minecraft:blue_concrete
fill 148 221 557 149 245 557 minecraft:black_concrete
fill 148 221 599 150 231 599 minecraft:black_concrete
setblock 150 221 557 minecraft:blue_concrete
fill 151 221 557 157 225 557 minecraft:black_concrete
setblock 151 221 599 minecraft:blue_concrete
fill 152 221 599 159 223 599 minecraft:black_concrete
setblock 158 221 557 minecraft:blue_concrete
fill 159 221 557 167 224 557 minecraft:black_concrete
setblock 160 221 599 minecraft:blue_concrete
setblock 168 221 557 minecraft:blue_concrete
fill 168 221 599 170 227 599 minecraft:black_concrete
fill 169 221 557 170 226 557 minecraft:black_concrete
setblock 171 221 557 minecraft:blue_concrete
fill 171 221 599 172 221 599 minecraft:blue_concrete
fill 172 221 557 173 251 557 minecraft:black_concrete
fill 173 221 599 173 263 599 minecraft:black_concrete
fill 174 221 557 175 221 557 minecraft:blue_concrete
fill 176 221 557 177 224 557 minecraft:black_concrete
fill 179 221 557 179 307 557 minecraft:black_concrete
setblock 180 221 599 minecraft:blue_concrete
fill 181 221 599 183 239 599 minecraft:black_concrete
fill 183 221 559 183 225 559 minecraft:black_concrete
setblock 183 221 560 minecraft:blue_concrete
fill 183 221 561 183 224 565 minecraft:black_concrete
setblock 183 221 566 minecraft:blue_concrete
fill 183 221 567 183 224 568 minecraft:black_concrete
fill 183 221 573 183 224 583 minecraft:black_concrete
setblock 183 221 584 minecraft:blue_concrete
fill 183 221 585 183 230 591 minecraft:black_concrete
setblock 183 221 592 minecraft:blue_concrete
fill 183 221 593 183 301 593 minecraft:black_concrete
fill 141 222 557 143 257 557 minecraft:black_concrete
fill 141 222 561 141 247 561 minecraft:black_concrete
fill 141 222 569 141 231 569 minecraft:black_concrete
fill 141 222 576 141 307 576 minecraft:black_concrete
fill 141 222 580 141 227 580 minecraft:black_concrete
fill 141 222 591 141 224 591 minecraft:black_concrete
fill 141 222 598 141 307 599 minecraft:black_concrete
setblock 144 222 557 minecraft:shroomlight
fill 147 222 557 147 307 557 minecraft:black_concrete
fill 147 222 599 147 307 599 minecraft:black_concrete
fill 150 222 557 150 277 557 minecraft:black_concrete
fill 151 222 599 151 239 599 minecraft:black_concrete
fill 158 222 557 158 307 557 minecraft:black_concrete
fill 160 222 599 160 259 599 minecraft:black_concrete
fill 168 222 557 168 276 557 minecraft:black_concrete
fill 171 222 557 171 307 557 minecraft:black_concrete
fill 171 222 599 172 224 599 minecraft:black_concrete
fill 174 222 557 175 263 557 minecraft:black_concrete
fill 174 222 599 174 235 599 minecraft:black_concrete
fill 179 222 599 180 247 599 minecraft:black_concrete
fill 183 222 560 183 263 560 minecraft:black_concrete
fill 183 222 566 183 307 566 minecraft:black_concrete
fill 183 222 584 183 307 584 minecraft:black_concrete
fill 183 222 592 183 283 592 minecraft:black_concrete
fill 141 223 577 141 307 577 minecraft:black_concrete
setblock 141 223 578 minecraft:white_concrete
fill 141 223 579 141 247 579 minecraft:black_concrete
fill 144 223 557 144 250 557 minecraft:black_concrete
fill 144 223 585 150 226 585 minecraft:orange_concrete
fill 145 223 583 150 226 584 minecraft:orange_concrete
fill 145 223 586 150 226 587 minecraft:orange_concrete
fill 146 223 582 148 226 582 minecraft:orange_concrete
fill 146 223 588 149 226 588 minecraft:orange_concrete
fill 173 223 574 178 228 577 minecraft:orange_concrete
fill 174 223 578 177 228 578 minecraft:orange_concrete
fill 175 223 573 176 228 573 minecraft:orange_concrete
fill 141 224 562 141 226 562 minecraft:black_concrete
setblock 141 224 563 minecraft:shroomlight
fill 141 224 578 141 265 578 minecraft:black_concrete
setblock 144 224 560 minecraft:light[level=14]
setblock 144 224 568 minecraft:light[level=14]
setblock 144 224 576 minecraft:light[level=14]
fill 144 224 584 144 225 584 minecraft:orange_concrete
fill 144 224 586 144 225 586 minecraft:orange_concrete
setblock 144 224 592 minecraft:light[level=14]
fill 149 224 582 149 225 582 minecraft:orange_concrete
fill 151 224 585 151 225 585 minecraft:orange_concrete
setblock 152 224 560 minecraft:light[level=14]
setblock 152 224 568 minecraft:light[level=14]
setblock 152 224 576 minecraft:light[level=14]
setblock 152 224 584 minecraft:light[level=14]
setblock 152 224 592 minecraft:light[level=14]
fill 152 224 599 154 248 599 minecraft:black_concrete
setblock 155 224 599 minecraft:shroomlight
fill 156 224 599 159 236 599 minecraft:black_concrete
setblock 160 224 560 minecraft:light[level=14]
setblock 160 224 568 minecraft:light[level=14]
setblock 160 224 576 minecraft:light[level=14]
setblock 160 224 584 minecraft:light[level=14]
setblock 160 224 592 minecraft:light[level=14]
setblock 168 224 560 minecraft:light[level=14]
setblock 168 224 568 minecraft:light[level=14]
setblock 168 224 576 minecraft:light[level=14]
setblock 168 224 584 minecraft:light[level=14]
setblock 168 224 592 minecraft:light[level=14]
fill 172 224 575 172 227 576 minecraft:orange_concrete
fill 173 224 578 173 227 578 minecraft:orange_concrete
fill 174 224 573 174 227 573 minecraft:orange_concrete
fill 174 224 579 177 227 579 minecraft:orange_concrete
setblock 176 224 560 minecraft:light[level=14]
setblock 176 224 568 minecraft:light[level=14]
setblock 176 224 584 minecraft:light[level=14]
setblock 176 224 592 minecraft:light[level=14]
fill 177 224 573 178 227 573 minecraft:orange_concrete
fill 178 224 578 178 227 578 minecraft:orange_concrete
fill 179 224 575 179 227 577 minecraft:orange_concrete
fill 141 225 563 141 247 564 minecraft:black_concrete
fill 141 225 565 141 227 565 minecraft:gold_block
fill 141 225 566 141 229 567 minecraft:black_concrete
fill 141 225 581 141 227 581 minecraft:gold_block
fill 141 225 582 141 226 590 minecraft:black_concrete
setblock 141 225 591 minecraft:white_concrete
fill 141 225 592 141 284 593 minecraft:black_concrete
setblock 141 225 594 minecraft:shroomlight
fill 141 225 595 141 307 595 minecraft:black_concrete
fill 141 225 597 141 227 597 minecraft:gold_block
fill 145 225 557 145 227 557 minecraft:gold_block
fill 146 225 557 146 307 557 minecraft:black_concrete
fill 155 225 599 155 227 599 minecraft:gold_block
fill 159 225 557 160 241 557 minecraft:black_concrete
fill 161 225 557 161 227 557 minecraft:gold_block
fill 161 225 599 161 235 599 minecraft:black_concrete
fill 162 225 557 167 228 557 minecraft:black_concrete
setblock 162 225 599 minecraft:shroomlight
fill 163 225 599 167 228 599 minecraft:black_concrete
fill 171 225 599 171 227 599 minecraft:gold_block
fill 172 225 574 172 226 574 minecraft:orange_concrete
fill 172 225 577 172 226 577 minecraft:orange_concrete
fill 172 225 599 172 254 599 minecraft:black_concrete
fill 173 225 573 173 226 573 minecraft:orange_concrete
fill 175 225 572 176 226 572 minecraft:orange_concrete
fill 176 225 557 176 246 557 minecraft:black_concrete
fill 177 225 557 177 227 557 minecraft:gold_block
fill 179 225 574 179 226 574 minecraft:orange_concrete
fill 183 225 561 183 241 562 minecraft:black_concrete
setblock 183 225 563 minecraft:shroomlight
fill 183 225 564 183 243 565 minecraft:black_concrete
fill 183 225 567 183 227 567 minecraft:gold_block
fill 183 225 568 183 307 568 minecraft:black_concrete
fill 183 225 573 183 242 576 minecraft:black_concrete
setblock 183 225 577 minecraft:shroomlight
fill 183 225 578 183 227 582 minecraft:black_concrete
fill 183 225 583 183 227 583 minecraft:gold_block
fill 141 226 591 141 254 591 minecraft:black_concrete
fill 141 226 594 141 283 594 minecraft:black_concrete
fill 151 226 557 155 228 557 minecraft:black_concrete
setblock 156 226 557 minecraft:shroomlight
fill 157 226 557 157 259 557 minecraft:black_concrete
fill 162 226 599 162 246 599 minecraft:black_concrete
setblock 183 226 559 minecraft:white_concrete
fill 183 226 563 183 280 563 minecraft:black_concrete
fill 183 226 577 183 307 577 minecraft:black_concrete
setblock 141 227 562 minecraft:shroomlight
fill 141 227 582 141 254 585 minecraft:black_concrete
setblock 141 227 586 minecraft:shroomlight
fill 141 227 587 141 232 590 minecraft:black_concrete
fill 145 227 584 149 227 586 minecraft:orange_concrete
fill 146 227 583 149 227 583 minecraft:orange_concrete
fill 146 227 587 149 227 587 minecraft:orange_concrete
setblock 150 227 585 minecraft:orange_concrete
fill 156 227 557 156 307 557 minecraft:black_concrete
setblock 169 227 557 minecraft:shroomlight
fill 170 227 557 170 306 557 minecraft:black_concrete
fill 183 227 559 183 307 559 minecraft:black_concrete
fill 141 228 562 141 307 562 minecraft:black_concrete
fill 141 228 565 141 233 565 minecraft:black_concrete
setblock 141 228 580 minecraft:shroomlight
fill 141 228 581 141 233 581 minecraft:black_concrete
fill 141 228 586 141 236 586 minecraft:black_concrete
fill 141 228 597 141 233 597 minecraft:black_concrete
fill 145 228 557 145 233 557 minecraft:black_concrete
fill 147 228 584 148 228 586 minecraft:orange_concrete
fill 155 228 599 155 233 599 minecraft:black_concrete
fill 161 228 557 161 233 557 minecraft:black_concrete
setblock 168 228 599 minecraft:shroomlight
fill 169 228 557 169 282 557 minecraft:black_concrete
fill 169 228 599 171 233 599 minecraft:black_concrete
fill 177 228 557 177 233 557 minecraft:black_concrete
fill 183 228 567 183 233 567 minecraft:black_concrete
fill 183 228 578 183 231 581 minecraft:black_concrete
setblock 183 228 582 minecraft:shroomlight
fill 183 228 583 183 233 583 minecraft:black_concrete
fill 141 229 570 141 244 572 minecraft:black_concrete
setblock 141 229 573 minecraft:white_concrete
fill 141 229 574 141 261 575 minecraft:black_concrete
fill 141 229 580 141 307 580 minecraft:black_concrete
fill 151 229 557 154 238 557 minecraft:black_concrete
setblock 155 229 557 minecraft:shroomlight
fill 162 229 557 163 237 557 minecraft:black_concrete
fill 163 229 599 164 296 599 minecraft:black_concrete
setblock 164 229 557 minecraft:white_concrete
fill 165 229 557 167 294 557 minecraft:black_concrete
setblock 165 229 599 minecraft:shroomlight
fill 166 229 599 168 307 599 minecraft:black_concrete
fill 174 229 575 177 229 576 minecraft:orange_concrete
fill 175 229 574 176 229 574 minecraft:orange_concrete
fill 175 229 577 177 229 577 minecraft:orange_concrete
setblock 183 229 570 minecraft:shroomlight
fill 183 229 582 183 257 582 minecraft:black_concrete
fill 141 230 566 141 307 566 minecraft:black_concrete
setblock 141 230 567 minecraft:white_concrete
fill 141 230 573 141 240 573 minecraft:black_concrete
fill 155 230 557 155 240 557 minecraft:black_concrete
fill 164 230 557 164 258 557 minecraft:black_concrete
fill 165 230 599 165 268 599 minecraft:black_concrete
fill 183 230 570 183 286 570 minecraft:black_concrete
fill 141 231 567 141 255 567 minecraft:black_concrete
fill 183 231 585 183 254 587 minecraft:black_concrete
setblock 183 231 588 minecraft:shroomlight
fill 183 231 589 183 246 591 minecraft:black_concrete
setblock 183 231 594 minecraft:shroomlight
fill 183 231 595 183 232 598 minecraft:black_concrete
setblock 141 232 569 minecraft:shroomlight
setblock 144 232 560 minecraft:light[level=14]
setblock 144 232 568 minecraft:light[level=14]
setblock 144 232 576 minecraft:light[level=14]
setblock 144 232 584 minecraft:light[level=14]
setblock 144 232 592 minecraft:light[level=14]
fill 148 232 599 148 307 599 minecraft:black_concrete
setblock 149 232 599 minecraft:shroomlight
fill 150 232 599 150 246 599 minecraft:black_concrete
setblock 152 232 560 minecraft:light[level=14]
setblock 152 232 568 minecraft:light[level=14]
setblock 152 232 576 minecraft:light[level=14]
setblock 152 232 584 minecraft:light[level=14]
setblock 152 232 592 minecraft:light[level=14]
setblock 160 232 560 minecraft:light[level=14]
setblock 160 232 568 minecraft:light[level=14]
setblock 160 232 576 minecraft:light[level=14]
setblock 160 232 584 minecraft:light[level=14]
setblock 160 232 592 minecraft:light[level=14]
setblock 168 232 560 minecraft:light[level=14]
setblock 168 232 568 minecraft:light[level=14]
setblock 168 232 576 minecraft:light[level=14]
setblock 168 232 584 minecraft:light[level=14]
setblock 168 232 592 minecraft:light[level=14]
fill 173 232 585 176 239 586 minecraft:orange_concrete
fill 174 232 584 176 239 584 minecraft:orange_concrete
fill 174 232 587 176 239 587 minecraft:orange_concrete
setblock 176 232 560 minecraft:light[level=14]
setblock 176 232 568 minecraft:light[level=14]
setblock 176 232 576 minecraft:light[level=14]
setblock 176 232 592 minecraft:light[level=14]
fill 183 232 578 183 241 580 minecraft:black_concrete
setblock 183 232 581 minecraft:shroomlight
fill 183 232 588 183 244 588 minecraft:black_concrete
fill 183 232 594 183 253 594 minecraft:black_concrete
fill 141 233 558 141 290 558 minecraft:black_concrete
setblock 141 233 559 minecraft:white_concrete
fill 141 233 560 141 265 560 minecraft:black_concrete
fill 141 233 569 141 307 569 minecraft:black_concrete
setblock 141 233 587 minecraft:shroomlight
fill 141 233 588 141 253 590 minecraft:black_concrete
fill 149 233 599 149 279 599 minecraft:black_concrete
fill 172 233 584 172 238 586 minecraft:orange_concrete
fill 173 233 583 173 238 584 minecraft:orange_concrete
fill 173 233 587 173 238 588 minecraft:orange_concrete
fill 174 233 583 176 238 583 minecraft:orange_concrete
fill 174 233 588 176 238 588 minecraft:orange_concrete
fill 177 233 584 177 238 587 minecraft:orange_concrete
fill 183 233 581 183 244 581 minecraft:black_concrete
fill 183 233 595 183 291 595 minecraft:black_concrete
setblock 183 233 596 minecraft:shroomlight
fill 183 233 597 183 275 598 minecraft:black_concrete
fill 141 234 559 141 307 559 minecraft:black_concrete
fill 141 234 565 141 236 565 minecraft:gold_block
fill 141 234 581 141 236 581 minecraft:gold_block
fill 141 234 587 141 299 587 minecraft:black_concrete
fill 141 234 597 141 236 597 minecraft:gold_block
fill 145 234 557 145 236 557 minecraft:gold_block
fill 155 234 599 155 236 599 minecraft:gold_block
fill 161 234 557 161 236 557 minecraft:gold_block
fill 169 234 599 170 281 599 minecraft:black_concrete
fill 171 234 599 171 236 599 minecraft:gold_block
fill 172 234 583 172 237 583 minecraft:orange_concrete
fill 172 234 587 172 237 587 minecraft:orange_concrete
fill 174 234 582 176 237 582 minecraft:orange_concrete
fill 174 234 589 176 237 589 minecraft:orange_concrete
fill 177 234 557 177 236 557 minecraft:gold_block
fill 177 234 583 177 237 583 minecraft:orange_concrete
fill 177 234 588 177 237 588 minecraft:orange_concrete
fill 178 234 584 178 237 587 minecraft:orange_concrete
fill 183 234 567 183 236 567 minecraft:gold_block
fill 183 234 583 183 236 583 minecraft:gold_block
fill 183 234 596 183 307 596 minecraft:black_concrete
fill 171 235 585 171 236 586 minecraft:orange_concrete
fill 172 235 588 172 236 588 minecraft:orange_concrete
fill 173 235 582 173 236 582 minecraft:orange_concrete
fill 173 235 589 173 236 589 minecraft:orange_concrete
fill 175 235 569 179 236 573 minecraft:polished_blackstone
fill 178 235 583 178 236 583 minecraft:orange_concrete
fill 180 235 571 181 235 571 minecraft:polished_blackstone
setblock 181 235 557 minecraft:white_concrete
fill 182 235 557 183 301 557 minecraft:black_concrete
setblock 161 236 599 minecraft:shroomlight
setblock 174 236 599 minecraft:white_concrete
fill 181 236 557 181 283 557 minecraft:black_concrete
fill 141 237 565 141 242 565 minecraft:black_concrete
fill 141 237 581 141 242 581 minecraft:black_concrete
setblock 141 237 586 minecraft:shroomlight
fill 141 237 597 141 242 597 minecraft:black_concrete
fill 145 237 557 145 242 557 minecraft:black_concrete
fill 155 237 599 157 242 599 minecraft:black_concrete
setblock 158 237 599 minecraft:shroomlight
fill 159 237 599 159 297 599 minecraft:black_concrete
fill 161 237 557 161 242 557 minecraft:black_concrete
setblock 161 237 599 minecraft:black_concrete
fill 171 237 599 171 242 599 minecraft:black_concrete
fill 174 237 599 174 275 599 minecraft:black_concrete
fill 177 237 557 177 242 557 minecraft:black_concrete
fill 183 237 567 183 242 567 minecraft:black_concrete
fill 183 237 583 183 242 583 minecraft:black_concrete
fill 141 238 586 141 307 586 minecraft:black_concrete
fill 158 238 599 158 270 599 minecraft:black_concrete
setblock 161 238 599 minecraft:shroomlight
fill 162 238 557 162 263 557 minecraft:black_concrete
setblock 163 238 557 minecraft:shroomlight
setblock 151 239 557 minecraft:shroomlight
fill 152 239 557 154 276 557 minecraft:black_concrete
fill 161 239 599 161 262 599 minecraft:black_concrete
fill 163 239 557 163 248 557 minecraft:black_concrete
setblock 144 240 560 minecraft:light[level=14]
setblock 144 240 568 minecraft:light[level=14]
setblock 144 240 576 minecraft:light[level=14]
setblock 144 240 584 minecraft:light[level=14]
setblock 144 240 592 minecraft:light[level=14]
fill 151 240 557 151 288 557 minecraft:black_concrete
setblock 151 240 599 minecraft:shroomlight
setblock 152 240 560 minecraft:light[level=14]
setblock 152 240 568 minecraft:light[level=14]
setblock 152 240 576 minecraft:light[level=14]
setblock 152 240 584 minecraft:light[level=14]
setblock 152 240 592 minecraft:light[level=14]
setblock 160 240 560 minecraft:light[level=14]
setblock 160 240 568 minecraft:light[level=14]
setblock 160 240 576 minecraft:light[level=14]
setblock 160 240 584 minecraft:light[level=14]
setblock 160 240 592 minecraft:light[level=14]
setblock 168 240 560 minecraft:light[level=14]
setblock 168 240 568 minecraft:light[level=14]
setblock 168 240 576 minecraft:light[level=14]
setblock 168 240 584 minecraft:light[level=14]
setblock 168 240 592 minecraft:light[level=14]
fill 174 240 569 174 241 573 minecraft:waxed_copper_block
fill 175 240 568 175 241 569 minecraft:waxed_copper_block
fill 175 240 571 179 241 571 minecraft:waxed_cut_copper
fill 175 240 573 175 241 574 minecraft:waxed_copper_block
setblock 176 240 560 minecraft:light[level=14]
fill 176 240 568 179 241 568 minecraft:waxed_copper_block
fill 176 240 574 179 241 574 minecraft:waxed_copper_block
setblock 176 240 576 minecraft:light[level=14]
setblock 176 240 584 minecraft:light[level=14]
setblock 176 240 592 minecraft:light[level=14]
fill 177 240 569 177 241 570 minecraft:waxed_cut_copper
fill 177 240 572 177 241 573 minecraft:waxed_cut_copper
fill 179 240 569 180 241 569 minecraft:waxed_copper_block
fill 179 240 573 180 241 573 minecraft:waxed_copper_block
fill 180 240 570 180 241 572 minecraft:waxed_copper_block
fill 181 240 599 181 307 599 minecraft:black_concrete
setblock 182 240 599 minecraft:white_concrete
fill 183 240 599 183 307 599 minecraft:black_concrete
setblock 141 241 573 minecraft:shroomlight
fill 151 241 599 151 307 599 minecraft:black_concrete
setblock 155 241 557 minecraft:shroomlight
fill 182 241 599 182 257 599 minecraft:black_concrete
fill 141 242 573 141 258 573 minecraft:black_concrete
fill 155 242 557 155 307 557 minecraft:black_concrete
setblock 159 242 557 minecraft:white_concrete
fill 160 242 557 160 307 557 minecraft:black_concrete
setblock 183 242 561 minecraft:shroomlight
fill 183 242 562 183 244 562 minecraft:black_concrete
fill 183 242 578 183 273 578 minecraft:black_concrete
setblock 183 242 579 minecraft:white_concrete
fill 183 242 580 183 263 580 minecraft:black_concrete
fill 141 243 565 141 245 565 minecraft:gold_block
fill 141 243 581 141 245 581 minecraft:gold_block
fill 141 243 597 141 245 597 minecraft:gold_block
fill 145 243 557 145 245 557 minecraft:gold_block
fill 155 243 599 155 245 599 minecraft:gold_block
fill 156 243 599 157 274 599 minecraft:black_concrete
fill 159 243 557 159 307 557 minecraft:black_concrete
fill 161 243 557 161 245 557 minecraft:gold_block
fill 171 243 599 171 245 599 minecraft:gold_block
fill 177 243 557 177 245 557 minecraft:gold_block
fill 183 243 561 183 259 561 minecraft:black_concrete
fill 183 243 567 183 245 567 minecraft:gold_block
fill 183 243 573 183 267 575 minecraft:black_concrete
setblock 183 243 576 minecraft:white_concrete
fill 183 243 579 183 247 579 minecraft:black_concrete
fill 183 243 583 183 245 583 minecraft:gold_block
setblock 141 244 568 minecraft:shroomlight
fill 144 244 599 144 307 599 minecraft:black_concrete
setblock 145 244 599 minecraft:white_concrete
fill 146 244 599 146 262 599 minecraft:black_concrete
fill 183 244 564 183 246 564 minecraft:black_concrete
setblock 183 244 565 minecraft:shroomlight
fill 183 244 576 183 249 576 minecraft:black_concrete
fill 141 245 568 141 273 568 minecraft:black_concrete
fill 141 245 570 141 278 571 minecraft:black_concrete
setblock 141 245 572 minecraft:white_concrete
fill 145 245 599 145 307 599 minecraft:black_concrete
setblock 183 245 562 minecraft:shroomlight
fill 183 245 565 183 307 565 minecraft:black_concrete
setblock 183 245 581 minecraft:shroomlight
setblock 183 245 588 minecraft:shroomlight
fill 141 246 565 141 251 565 minecraft:black_concrete
fill 141 246 572 141 301 572 minecraft:black_concrete
fill 141 246 581 141 251 581 minecraft:black_concrete
fill 141 246 597 141 248 597 minecraft:black_concrete
fill 145 246 557 145 251 557 minecraft:black_concrete
fill 148 246 557 148 253 557 minecraft:black_concrete
setblock 149 246 557 minecraft:shroomlight
fill 155 246 599 155 251 599 minecraft:black_concrete
fill 161 246 557 161 251 557 minecraft:black_concrete
fill 171 246 599 171 251 599 minecraft:black_concrete
fill 177 246 557 177 251 557 minecraft:black_concrete
fill 183 246 562 183 251 562 minecraft:black_concrete
fill 183 246 567 183 251 567 minecraft:black_concrete
fill 183 246 581 183 254 581 minecraft:black_concrete
fill 183 246 583 183 251 583 minecraft:black_concrete
fill 183 246 588 183 284 588 minecraft:black_concrete
fill 149 247 557 149 256 557 minecraft:black_concrete
setblock 150 247 599 minecraft:shroomlight
setblock 162 247 599 minecraft:shroomlight
setblock 176 247 557 minecraft:shroomlight
setblock 183 247 564 minecraft:white_concrete
fill 183 247 589 183 307 590 minecraft:black_concrete
setblock 183 247 591 minecraft:shroomlight
setblock 141 248 561 minecraft:shroomlight
setblock 141 248 563 minecraft:white_concrete
fill 141 248 564 141 307 564 minecraft:black_concrete
setblock 141 248 579 minecraft:white_concrete
setblock 144 248 560 minecraft:light[level=14]
setblock 144 248 568 minecraft:light[level=14]
setblock 144 248 576 minecraft:light[level=14]
setblock 144 248 584 minecraft:light[level=14]
setblock 144 248 592 minecraft:light[level=14]
fill 150 248 599 150 307 599 minecraft:black_concrete
setblock 152 248 560 minecraft:light[level=14]
setblock 152 248 568 minecraft:light[level=14]
setblock 152 248 576 minecraft:light[level=14]
setblock 152 248 584 minecraft:light[level=14]
setblock 152 248 592 minecraft:light[level=14]
setblock 160 248 560 minecraft:light[level=14]
setblock 160 248 568 minecraft:light[level=14]
setblock 160 248 576 minecraft:light[level=14]
setblock 160 248 584 minecraft:light[level=14]
setblock 160 248 592 minecraft:light[level=14]
fill 162 248 599 162 290 599 minecraft:black_concrete
setblock 168 248 560 minecraft:light[level=14]
setblock 168 248 568 minecraft:light[level=14]
setblock 168 248 576 minecraft:light[level=14]
setblock 168 248 584 minecraft:light[level=14]
setblock 168 248 592 minecraft:light[level=14]
fill 176 248 557 176 307 557 minecraft:black_concrete
setblock 176 248 560 minecraft:light[level=14]
setblock 176 248 568 minecraft:light[level=14]
setblock 176 248 576 minecraft:light[level=14]
setblock 176 248 584 minecraft:light[level=14]
setblock 176 248 592 minecraft:light[level=14]
setblock 179 248 599 minecraft:white_concrete
fill 180 248 599 180 274 599 minecraft:black_concrete
fill 183 248 564 183 260 564 minecraft:black_concrete
setblock 183 248 579 minecraft:shroomlight
fill 183 248 591 183 292 591 minecraft:black_concrete
fill 141 249 561 141 266 561 minecraft:black_concrete
fill 141 249 563 141 307 563 minecraft:black_concrete
fill 141 249 579 141 306 579 minecraft:black_concrete
setblock 141 249 597 minecraft:shroomlight
fill 152 249 599 153 260 599 minecraft:black_concrete
setblock 154 249 599 minecraft:shroomlight
setblock 163 249 557 minecraft:shroomlight
fill 179 249 599 179 307 599 minecraft:black_concrete
fill 183 249 579 183 254 579 minecraft:black_concrete
fill 141 250 597 141 251 597 minecraft:black_concrete
fill 154 250 599 154 307 599 minecraft:black_concrete
fill 163 250 557 163 307 557 minecraft:black_concrete
setblock 178 250 557 minecraft:shroomlight
setblock 183 250 576 minecraft:shroomlight
setblock 144 251 557 minecraft:shroomlight
fill 178 251 557 178 307 557 minecraft:black_concrete
fill 183 251 576 183 307 576 minecraft:black_concrete
fill 141 252 565 141 254 565 minecraft:gold_block
fill 141 252 581 141 254 581 minecraft:gold_block
fill 141 252 597 141 254 597 minecraft:gold_block
fill 144 252 557 144 307 557 minecraft:black_concrete
fill 145 252 557 145 254 557 minecraft:gold_block
fill 155 252 599 155 254 599 minecraft:gold_block
fill 161 252 557 161 254 557 minecraft:gold_block
fill 171 252 599 171 254 599 minecraft:gold_block
setblock 172 252 557 minecraft:shroomlight
fill 173 252 557 173 282 557 minecraft:black_concrete
fill 177 252 557 177 254 557 minecraft:gold_block
setblock 183 252 562 minecraft:white_concrete
fill 183 252 567 183 254 567 minecraft:gold_block
fill 183 252 583 183 254 583 minecraft:gold_block
fill 172 253 557 172 307 557 minecraft:black_concrete
fill 183 253 562 183 265 562 minecraft:black_concrete
setblock 141 254 588 minecraft:white_concrete
fill 141 254 589 141 278 590 minecraft:black_concrete
setblock 148 254 557 minecraft:white_concrete
setblock 183 254 594 minecraft:shroomlight
fill 141 255 565 141 259 565 minecraft:black_concrete
fill 141 255 581 141 260 583 minecraft:black_concrete
setblock 141 255 584 minecraft:white_concrete
fill 141 255 585 141 276 585 minecraft:black_concrete
fill 141 255 588 141 307 588 minecraft:black_concrete
setblock 141 255 591 minecraft:shroomlight
fill 141 255 597 141 260 597 minecraft:black_concrete
fill 145 255 557 145 260 557 minecraft:black_concrete
fill 148 255 557 148 266 557 minecraft:black_concrete
fill 155 255 599 155 260 599 minecraft:black_concrete
fill 161 255 557 161 260 557 minecraft:black_concrete
fill 171 255 599 171 260 599 minecraft:black_concrete
setblock 172 255 599 minecraft:shroomlight
fill 177 255 557 177 258 557 minecraft:black_concrete
fill 183 255 567 183 260 567 minecraft:black_concrete
setblock 183 255 579 minecraft:shroomlight
setblock 183 255 581 minecraft:shroomlight
fill 183 255 583 183 260 583 minecraft:black_concrete
fill 183 255 585 183 307 585 minecraft:black_concrete
setblock 183 255 586 minecraft:shroomlight
fill 183 255 587 183 267 587 minecraft:black_concrete
fill 183 255 594 183 302 594 minecraft:black_concrete
setblock 141 256 567 minecraft:shroomlight
fill 141 256 584 141 307 584 minecraft:black_concrete
fill 141 256 591 141 307 591 minecraft:black_concrete
setblock 144 256 560 minecraft:light[level=14]
setblock 144 256 568 minecraft:light[level=14]
setblock 144 256 576 minecraft:light[level=14]
setblock 144 256 584 minecraft:light[level=14]
setblock 144 256 592 minecraft:light[level=14]
setblock 152 256 560 minecraft:light[level=14]
setblock 152 256 568 minecraft:light[level=14]
setblock 152 256 576 minecraft:light[level=14]
setblock 152 256 584 minecraft:light[level=14]
setblock 152 256 592 minecraft:light[level=14]
setblock 160 256 560 minecraft:light[level=14]
setblock 160 256 568 minecraft:light[level=14]
setblock 160 256 576 minecraft:light[level=14]
setblock 160 256 584 minecraft:light[level=14]
setblock 160 256 592 minecraft:light[level=14]
setblock 168 256 560 minecraft:light[level=14]
setblock 168 256 568 minecraft:light[level=14]
setblock 168 256 576 minecraft:light[level=14]
setblock 168 256 584 minecraft:light[level=14]
setblock 168 256 592 minecraft:light[level=14]
fill 172 256 599 172 287 599 minecraft:black_concrete
setblock 176 256 560 minecraft:light[level=14]
setblock 176 256 568 minecraft:light[level=14]
setblock 176 256 576 minecraft:light[level=14]
setblock 176 256 584 minecraft:light[level=14]
setblock 176 256 592 minecraft:light[level=14]
fill 183 256 579 183 307 579 minecraft:black_concrete
fill 183 256 581 183 307 581 minecraft:black_concrete
fill 183 256 586 183 307 586 minecraft:black_concrete
fill 141 257 567 141 307 567 minecraft:black_concrete
setblock 149 257 557 minecraft:white_concrete
fill 141 258 557 142 271 557 minecraft:black_concrete
setblock 143 258 557 minecraft:shroomlight
fill 149 258 557 149 271 557 minecraft:black_concrete
setblock 182 258 599 minecraft:shroomlight
setblock 183 258 582 minecraft:white_concrete
setblock 141 259 573 minecraft:shroomlight
fill 143 259 557 143 270 557 minecraft:black_concrete
setblock 164 259 557 minecraft:shroomlight
setblock 177 259 557 minecraft:white_concrete
fill 182 259 599 182 275 599 minecraft:black_concrete
fill 183 259 582 183 280 582 minecraft:black_concrete
setblock 141 260 565 minecraft:shroomlight
fill 141 260 573 141 307 573 minecraft:black_concrete
setblock 157 260 557 minecraft:shroomlight
setblock 160 260 599 minecraft:shroomlight
fill 164 260 557 164 280 557 minecraft:black_concrete
setblock 177 260 557 minecraft:black_concrete
setblock 183 260 561 minecraft:white_concrete
fill 141 261 565 141 263 565 minecraft:gold_block
fill 141 261 581 141 263 581 minecraft:gold_block
fill 141 261 582 141 265 583 minecraft:black_concrete
fill 141 261 597 141 263 597 minecraft:gold_block
fill 145 261 557 145 263 557 minecraft:gold_block
fill 152 261 599 152 266 599 minecraft:black_concrete
setblock 153 261 599 minecraft:shroomlight
fill 155 261 599 155 263 599 minecraft:gold_block
fill 157 261 557 157 264 557 minecraft:black_concrete
fill 160 261 599 160 307 599 minecraft:black_concrete
fill 161 261 557 161 263 557 minecraft:gold_block
fill 171 261 599 171 263 599 minecraft:gold_block
fill 177 261 557 177 263 557 minecraft:gold_block
fill 183 261 561 183 307 561 minecraft:black_concrete
setblock 183 261 564 minecraft:white_concrete
fill 183 261 567 183 263 567 minecraft:gold_block
fill 183 261 583 183 263 583 minecraft:gold_block
fill 141 262 574 141 287 574 minecraft:black_concrete
setblock 141 262 575 minecraft:white_concrete
fill 153 262 599 153 307 599 minecraft:black_concrete
fill 183 262 564 183 307 564 minecraft:black_concrete
fill 141 263 575 141 277 575 minecraft:black_concrete
setblock 146 263 599 minecraft:shroomlight
setblock 161 263 599 minecraft:shroomlight
fill 141 264 565 141 269 565 minecraft:black_concrete
fill 141 264 581 141 269 581 minecraft:black_concrete
fill 141 264 597 141 269 597 minecraft:black_concrete
setblock 144 264 560 minecraft:light[level=14]
setblock 144 264 568 minecraft:light[level=14]
setblock 144 264 576 minecraft:light[level=14]
setblock 144 264 584 minecraft:light[level=14]
setblock 144 264 592 minecraft:light[level=14]
fill 145 264 557 145 269 557 minecraft:black_concrete
fill 146 264 599 146 282 599 minecraft:black_concrete
setblock 152 264 560 minecraft:light[level=14]
setblock 152 264 568 minecraft:light[level=14]
setblock 152 264 576 minecraft:light[level=14]
setblock 152 264 584 minecraft:light[level=14]
setblock 152 264 592 minecraft:light[level=14]
fill 155 264 599 155 269 599 minecraft:black_concrete
setblock 160 264 560 minecraft:light[level=14]
setblock 160 264 568 minecraft:light[level=14]
setblock 160 264 576 minecraft:light[level=14]
setblock 160 264 584 minecraft:light[level=14]
setblock 160 264 592 minecraft:light[level=14]
fill 161 264 557 161 269 557 minecraft:black_concrete
fill 161 264 599 161 281 599 minecraft:black_concrete
setblock 162 264 557 minecraft:white_concrete
setblock 168 264 560 minecraft:light[level=14]
setblock 168 264 568 minecraft:light[level=14]
setblock 168 264 576 minecraft:light[level=14]
setblock 168 264 584 minecraft:light[level=14]
setblock 168 264 592 minecraft:light[level=14]
fill 171 264 599 171 268 599 minecraft:black_concrete
setblock 173 264 599 minecraft:white_concrete
setblock 174 264 557 minecraft:shroomlight
fill 175 264 557 175 275 557 minecraft:black_concrete
setblock 176 264 560 minecraft:light[level=14]
setblock 176 264 568 minecraft:light[level=14]
setblock 176 264 576 minecraft:light[level=14]
setblock 176 264 584 minecraft:light[level=14]
setblock 176 264 592 minecraft:light[level=14]
fill 177 264 557 177 269 557 minecraft:black_concrete
setblock 183 264 560 minecraft:shroomlight
fill 183 264 567 183 269 567 minecraft:black_concrete
setblock 183 264 580 minecraft:white_concrete
fill 183 264 583 183 269 583 minecraft:black_concrete
setblock 157 265 557 minecraft:shroomlight
fill 162 265 557 162 307 557 minecraft:black_concrete
fill 173 265 599 173 281 599 minecraft:black_concrete
fill 174 265 557 174 307 557 minecraft:black_concrete
fill 183 265 560 183 278 560 minecraft:black_concrete
setblock 183 265 580 minecraft:shroomlight
setblock 141 266 560 minecraft:shroomlight
setblock 141 266 578 minecraft:white_concrete
setblock 141 266 582 minecraft:shroomlight
fill 141 266 583 141 307 583 minecraft:black_concrete
setblock 143 266 599 minecraft:shroomlight
fill 157 266 557 157 292 557 minecraft:black_concrete
setblock 183 266 562 minecraft:shroomlight
fill 183 266 580 183 267 580 minecraft:black_concrete
fill 141 267 560 141 307 560 minecraft:black_concrete
setblock 141 267 561 minecraft:white_concrete
fill 141 267 578 141 307 578 minecraft:black_concrete
fill 141 267 582 141 307 582 minecraft:black_concrete
fill 143 267 599 143 307 599 minecraft:black_concrete
setblock 148 267 557 minecraft:shroomlight
setblock 152 267 599 minecraft:white_concrete
fill 183 267 562 183 291 562 minecraft:black_concrete
fill 141 268 561 141 272 561 minecraft:black_concrete
fill 148 268 557 148 305 557 minecraft:black_concrete
fill 152 268 599 152 307 599 minecraft:black_concrete
fill 183 268 573 183 270 574 minecraft:black_concrete
setblock 183 268 575 minecraft:white_concrete
setblock 183 268 580 minecraft:shroomlight
setblock 183 268 587 minecraft:shroomlight
setblock 165 269 599 minecraft:white_concrete
setblock 171 269 599 minecraft:white_concrete
fill 183 269 575 183 307 575 minecraft:black_concrete
fill 183 269 580 183 273 580 minecraft:black_concrete
fill 183 269 587 183 307 587 minecraft:black_concrete
fill 141 270 565 141 272 565 minecraft:gold_block
fill 141 270 581 141 272 581 minecraft:gold_block
fill 141 270 597 141 272 597 minecraft:gold_block
fill 145 270 557 145 272 557 minecraft:gold_block
fill 155 270 599 155 272 599 minecraft:gold_block
fill 161 270 557 161 272 557 minecraft:gold_block
fill 165 270 599 165 307 599 minecraft:black_concrete
fill 171 270 599 171 272 599 minecraft:gold_block
fill 177 270 557 177 272 557 minecraft:gold_block
setblock 183 270 558 minecraft:shroomlight
fill 183 270 567 183 272 567 minecraft:gold_block
fill 183 270 583 183 272 583 minecraft:gold_block
setblock 143 271 557 minecraft:shroomlight
setblock 158 271 599 minecraft:white_concrete
fill 183 271 558 183 307 558 minecraft:black_concrete
fill 183 271 573 183 282 573 minecraft:black_concrete
setblock 183 271 574 minecraft:white_concrete
fill 141 272 557 141 307 557 minecraft:black_concrete
setblock 142 272 557 minecraft:shroomlight
fill 143 272 557 143 307 557 minecraft:black_concrete
setblock 144 272 560 minecraft:light[level=14]
setblock 144 272 568 minecraft:light[level=14]
setblock 144 272 576 minecraft:light[level=14]
setblock 144 272 584 minecraft:light[level=14]
setblock 144 272 592 minecraft:light[level=14]
setblock 149 272 557 minecraft:shroomlight
setblock 152 272 560 minecraft:light[level=14]
setblock 152 272 568 minecraft:light[level=14]
setblock 152 272 576 minecraft:light[level=14]
setblock 152 272 584 minecraft:light[level=14]
setblock 152 272 592 minecraft:light[level=14]
fill 158 272 599 158 307 599 minecraft:black_concrete
setblock 160 272 560 minecraft:light[level=14]
setblock 160 272 568 minecraft:light[level=14]
setblock 160 272 576 minecraft:light[level=14]
setblock 160 272 584 minecraft:light[level=14]
setblock 160 272 592 minecraft:light[level=14]
setblock 168 272 560 minecraft:light[level=14]
setblock 168 272 568 minecraft:light[level=14]
setblock 168 272 576 minecraft:light[level=14]
setblock 168 272 584 minecraft:light[level=14]
setblock 168 272 592 minecraft:light[level=14]
setblock 176 272 560 minecraft:light[level=14]
setblock 176 272 568 minecraft:light[level=14]
setblock 176 272 576 minecraft:light[level=14]
setblock 176 272 584 minecraft:light[level=14]
setblock 176 272 592 minecraft:light[level=14]
fill 183 272 574 183 277 574 minecraft:black_concrete
setblock 141 273 561 minecraft:shroomlight
fill 141 273 565 141 287 565 minecraft:black_concrete
fill 141 273 581 141 287 581 minecraft:black_concrete
fill 141 273 597 141 287 597 minecraft:black_concrete
fill 142 273 557 142 290 557 minecraft:black_concrete
fill 145 273 557 145 287 557 minecraft:black_concrete
fill 149 273 557 149 307 557 minecraft:black_concrete
fill 155 273 599 155 287 599 minecraft:black_concrete
fill 161 273 557 161 287 557 minecraft:black_concrete
fill 171 273 599 171 287 599 minecraft:black_concrete
fill 177 273 557 177 280 557 minecraft:black_concrete
fill 183 273 567 183 287 567 minecraft:black_concrete
fill 183 273 583 183 287 583 minecraft:black_concrete
fill 141 274 561 141 297 561 minecraft:black_concrete
setblock 141 274 568 minecraft:white_concrete
setblock 183 274 578 minecraft:shroomlight
setblock 183 274 580 minecraft:white_concrete
fill 141 275 568 141 285 568 minecraft:black_concrete
setblock 156 275 599 minecraft:shroomlight
fill 157 275 599 157 307 599 minecraft:black_concrete
setblock 180 275 599 minecraft:white_concrete
fill 183 275 578 183 307 578 minecraft:black_concrete
fill 183 275 580 183 307 580 minecraft:black_concrete
fill 156 276 599 156 307 599 minecraft:black_concrete
setblock 174 276 599 minecraft:shroomlight
setblock 175 276 557 minecraft:white_concrete
fill 180 276 599 180 307 599 minecraft:black_concrete
setblock 182 276 599 minecraft:shroomlight
setblock 183 276 597 minecraft:shroomlight
fill 183 276 598 183 307 598 minecraft:black_concrete
setblock 141 277 585 minecraft:shroomlight
setblock 152 277 557 minecraft:white_concrete
fill 153 277 557 154 277 557 minecraft:black_concrete
setblock 168 277 557 minecraft:shroomlight
setblock 174 277 599 minecraft:white_concrete
fill 175 277 557 175 307 557 minecraft:black_concrete
fill 182 277 599 182 307 599 minecraft:black_concrete
fill 183 277 597 183 307 597 minecraft:black_concrete
setblock 141 278 575 minecraft:shroomlight
fill 141 278 585 141 307 585 minecraft:black_concrete
setblock 150 278 557 minecraft:shroomlight
fill 152 278 557 152 307 557 minecraft:black_concrete
setblock 153 278 557 minecraft:shroomlight
fill 154 278 557 154 307 557 minecraft:black_concrete
fill 168 278 557 168 294 557 minecraft:black_concrete
fill 174 278 599 174 307 599 minecraft:black_concrete
setblock 183 278 574 minecraft:shroomlight
fill 141 279 570 141 307 570 minecraft:black_concrete
setblock 141 279 571 minecraft:shroomlight
fill 141 279 575 141 291 575 minecraft:black_concrete
setblock 141 279 589 minecraft:shroomlight
fill 141 279 590 141 307 590 minecraft:black_concrete
fill 150 279 557 150 288 557 minecraft:black_concrete
fill 150 279 577 161 279 577 minecraft:gold_block
fill 151 279 572 151 280 573 minecraft:gold_block
fill 151 279 576 162 279 576 minecraft:gold_block
fill 151 279 579 163 279 580 minecraft:gold_block
fill 152 279 570 173 279 570 minecraft:gold_block
fill 152 279 573 175 279 573 minecraft:gold_block
fill 152 279 582 174 279 583 minecraft:gold_block
fill 153 279 557 153 307 557 minecraft:black_concrete
fill 153 279 569 153 280 569 minecraft:gold_block
fill 153 279 574 163 279 575 minecraft:gold_block
fill 153 279 578 162 279 578 minecraft:gold_block
fill 153 279 581 177 279 581 minecraft:gold_block
fill 154 279 571 176 279 572 minecraft:gold_block
fill 154 279 585 155 280 586 minecraft:gold_block
fill 155 279 567 156 280 568 minecraft:gold_block
fill 155 279 584 176 279 584 minecraft:gold_block
fill 156 279 569 174 279 569 minecraft:gold_block
fill 156 279 585 172 279 585 minecraft:gold_block
fill 156 279 588 157 280 588 minecraft:gold_block
fill 157 279 568 171 279 568 minecraft:gold_block
fill 157 279 586 170 280 587 minecraft:gold_block
fill 157 279 589 157 280 589 minecraft:gold_block
fill 158 279 565 159 280 567 minecraft:gold_block
fill 159 279 590 160 280 590 minecraft:gold_block
fill 160 279 566 168 280 567 minecraft:gold_block
fill 160 279 588 160 280 589 minecraft:gold_block
fill 161 279 564 162 280 565 minecraft:gold_block
fill 161 279 588 170 280 588 minecraft:gold_block
fill 163 279 589 164 280 590 minecraft:gold_block
fill 164 279 563 164 280 565 minecraft:gold_block
fill 164 279 574 177 279 574 minecraft:gold_block
fill 164 279 580 175 279 580 minecraft:gold_block
fill 164 279 591 164 280 591 minecraft:gold_block
fill 165 279 564 165 280 565 minecraft:gold_block
fill 165 279 575 177 279 575 minecraft:gold_block
fill 165 279 579 175 279 579 minecraft:gold_block
fill 166 279 576 175 279 576 minecraft:gold_block
fill 166 279 578 177 279 578 minecraft:gold_block
fill 166 279 589 167 280 590 minecraft:gold_block
fill 167 279 577 178 279 577 minecraft:gold_block
fill 168 279 564 168 280 565 minecraft:gold_block
fill 169 279 564 169 280 564 minecraft:gold_block
fill 169 279 567 171 280 567 minecraft:gold_block
fill 169 279 589 170 280 589 minecraft:gold_block
fill 171 279 565 171 280 566 minecraft:gold_block
fill 171 279 586 173 280 586 minecraft:gold_block
fill 172 279 566 172 280 566 minecraft:gold_block
fill 172 279 587 173 280 587 minecraft:gold_block
fill 173 279 568 174 280 568 minecraft:gold_block
fill 175 279 585 175 280 585 minecraft:gold_block
fill 177 279 582 177 280 582 minecraft:gold_block
setblock 183 279 560 minecraft:shroomlight
fill 183 279 574 183 307 574 minecraft:black_concrete
fill 141 280 571 153 280 571 minecraft:black_concrete
fill 141 280 589 156 280 589 minecraft:black_concrete
fill 142 280 558 151 280 570 minecraft:black_concrete
fill 142 280 572 149 280 588 minecraft:black_concrete
fill 142 280 590 158 280 598 minecraft:black_concrete
setblock 149 280 599 minecraft:white_concrete
fill 150 280 572 150 280 576 minecraft:black_concrete
fill 150 280 577 160 280 577 minecraft:gold_block
fill 150 280 578 150 280 588 minecraft:black_concrete
fill 151 280 574 152 280 575 minecraft:black_concrete
fill 151 280 576 160 280 576 minecraft:gold_block
fill 151 280 578 152 280 578 minecraft:black_concrete
fill 151 280 579 154 280 580 minecraft:gold_block
fill 151 280 581 151 280 588 minecraft:black_concrete
fill 152 280 558 152 280 569 minecraft:black_concrete
fill 152 280 570 159 280 570 minecraft:gold_block
fill 152 280 572 153 280 572 minecraft:black_concrete
fill 152 280 573 161 280 573 minecraft:gold_block
setblock 152 280 581 minecraft:black_concrete
fill 152 280 582 155 280 583 minecraft:gold_block
fill 152 280 584 153 280 588 minecraft:black_concrete
fill 153 280 558 154 280 568 minecraft:black_concrete
fill 153 280 574 161 280 575 minecraft:gold_block
fill 153 280 578 154 280 578 minecraft:gold_block
fill 153 280 581 155 280 581 minecraft:gold_block
fill 154 280 569 155 280 569 minecraft:black_concrete
fill 154 280 571 160 280 572 minecraft:gold_block
setblock 154 280 584 minecraft:black_concrete
fill 154 280 587 155 280 588 minecraft:black_concrete
fill 155 280 558 157 280 566 minecraft:black_concrete
fill 155 280 578 160 280 580 minecraft:waxed_cut_copper
fill 155 280 584 157 280 584 minecraft:gold_block
fill 156 280 569 159 280 569 minecraft:gold_block
fill 156 280 581 161 280 582 minecraft:waxed_cut_copper
setblock 156 280 583 minecraft:gold_block
fill 156 280 585 158 280 585 minecraft:gold_block
fill 156 280 586 156 280 587 minecraft:black_concrete
setblock 157 280 567 minecraft:black_concrete
fill 157 280 568 160 280 568 minecraft:gold_block
fill 157 280 583 160 280 583 minecraft:waxed_cut_copper
fill 158 280 558 160 280 564 minecraft:black_concrete
fill 158 280 584 159 280 584 minecraft:waxed_cut_copper
fill 158 280 588 159 280 589 minecraft:black_concrete
setblock 159 280 585 minecraft:waxed_cut_copper
fill 159 280 591 163 280 598 minecraft:black_concrete
setblock 160 280 565 minecraft:black_concrete
fill 160 280 569 168 280 570 minecraft:waxed_cut_copper
fill 160 280 584 168 280 585 minecraft:gold_block
fill 161 280 558 163 280 563 minecraft:black_concrete
fill 161 280 568 167 280 568 minecraft:waxed_cut_copper
fill 161 280 571 167 280 571 minecraft:waxed_cut_copper
setblock 161 280 572 minecraft:gold_block
fill 161 280 576 161 280 578 minecraft:shroomlight
fill 161 280 579 161 280 580 minecraft:waxed_cut_copper
fill 161 280 583 167 280 583 minecraft:gold_block
fill 161 280 589 162 280 590 minecraft:black_concrete
fill 162 280 572 166 280 573 minecraft:waxed_cut_copper
setblock 162 280 574 minecraft:gold_block
fill 162 280 575 162 280 576 minecraft:shroomlight
fill 162 280 578 162 280 579 minecraft:shroomlight
setblock 162 280 580 minecraft:waxed_cut_copper
fill 162 280 581 166 280 582 minecraft:gold_block
fill 163 280 564 163 280 565 minecraft:black_concrete
fill 163 280 574 163 280 575 minecraft:shroomlight
fill 163 280 579 163 280 580 minecraft:shroomlight
fill 164 280 558 182 280 562 minecraft:black_concrete
fill 164 280 574 165 280 574 minecraft:shroomlight
fill 164 280 580 165 280 580 minecraft:shroomlight
fill 164 280 592 182 280 598 minecraft:black_concrete
fill 165 280 563 182 280 563 minecraft:black_concrete
fill 165 280 575 166 280 575 minecraft:shroomlight
fill 165 280 579 166 280 579 minecraft:shroomlight
fill 165 280 589 165 280 591 minecraft:black_concrete
fill 166 280 564 167 280 565 minecraft:black_concrete
fill 166 280 574 177 280 574 minecraft:gold_block
fill 166 280 576 167 280 576 minecraft:shroomlight
fill 166 280 578 167 280 578 minecraft:shroomlight
fill 166 280 580 173 280 580 minecraft:waxed_cut_copper
fill 166 280 591 182 280 591 minecraft:black_concrete
fill 167 280 572 175 280 573 minecraft:gold_block
fill 167 280 575 177 280 575 minecraft:gold_block
setblock 167 280 577 minecraft:shroomlight
fill 167 280 579 173 280 579 minecraft:waxed_cut_copper
fill 167 280 581 172 280 582 minecraft:waxed_cut_copper
fill 168 280 568 171 280 568 minecraft:gold_block
fill 168 280 571 176 280 571 minecraft:gold_block
fill 168 280 576 175 280 576 minecraft:gold_block
fill 168 280 577 173 280 578 minecraft:waxed_cut_copper
fill 168 280 583 171 280 583 minecraft:waxed_cut_copper
fill 168 280 589 168 280 590 minecraft:black_concrete
fill 169 280 565 170 280 566 minecraft:black_concrete
fill 169 280 569 173 280 570 minecraft:gold_block
fill 169 280 584 169 280 585 minecraft:waxed_cut_copper
fill 169 280 590 182 280 590 minecraft:black_concrete
fill 170 280 564 182 280 564 minecraft:black_concrete
setblock 170 280 584 minecraft:waxed_cut_copper
fill 170 280 585 172 280 585 minecraft:gold_block
fill 171 280 584 176 280 584 minecraft:gold_block
fill 171 280 587 171 280 589 minecraft:black_concrete
fill 172 280 565 182 280 565 minecraft:black_concrete
fill 172 280 567 172 280 568 minecraft:black_concrete
fill 172 280 583 174 280 583 minecraft:gold_block
fill 172 280 588 182 280 589 minecraft:black_concrete
fill 173 280 566 182 280 567 minecraft:black_concrete
fill 173 280 581 174 280 582 minecraft:gold_block
fill 173 280 585 174 280 585 minecraft:black_concrete
setblock 174 280 569 minecraft:gold_block
fill 174 280 570 182 280 570 minecraft:black_concrete
fill 174 280 577 175 280 580 minecraft:gold_block
fill 174 280 586 182 280 587 minecraft:black_concrete
fill 175 280 568 182 280 569 minecraft:black_concrete
fill 175 280 581 177 280 581 minecraft:gold_block
fill 175 280 582 176 280 583 minecraft:black_concrete
setblock 176 280 572 minecraft:gold_block
fill 176 280 573 182 280 573 minecraft:black_concrete
fill 176 280 576 182 280 576 minecraft:black_concrete
fill 176 280 577 177 280 578 minecraft:gold_block
fill 176 280 579 182 280 580 minecraft:black_concrete
fill 176 280 585 182 280 585 minecraft:black_concrete
fill 177 280 571 182 280 572 minecraft:black_concrete
fill 177 280 583 182 280 584 minecraft:black_concrete
fill 178 280 574 182 280 575 minecraft:black_concrete
setblock 178 280 577 minecraft:gold_block
fill 178 280 578 182 280 578 minecraft:black_concrete
fill 178 280 581 182 280 582 minecraft:black_concrete
fill 179 280 577 182 280 577 minecraft:black_concrete
fill 183 280 560 183 290 560 minecraft:black_concrete
fill 141 281 571 141 290 571 minecraft:black_concrete
fill 141 281 589 141 307 589 minecraft:black_concrete
fill 149 281 599 149 307 599 minecraft:black_concrete
setblock 164 281 557 minecraft:shroomlight
setblock 177 281 557 minecraft:shroomlight
setblock 183 281 563 minecraft:shroomlight
setblock 183 281 582 minecraft:white_concrete
setblock 161 282 599 minecraft:shroomlight
fill 164 282 557 164 307 557 minecraft:black_concrete
fill 169 282 599 169 307 599 minecraft:black_concrete
setblock 170 282 599 minecraft:white_concrete
setblock 173 282 599 minecraft:white_concrete
fill 177 282 557 177 287 557 minecraft:black_concrete
fill 183 282 563 183 307 563 minecraft:black_concrete
setblock 183 282 569 minecraft:white_concrete
fill 183 282 582 183 307 582 minecraft:black_concrete
setblock 146 283 599 minecraft:white_concrete
fill 161 283 599 161 307 599 minecraft:black_concrete
setblock 169 283 557 minecraft:white_concrete
fill 170 283 599 170 288 599 minecraft:black_concrete
setblock 173 283 557 minecraft:shroomlight
fill 173 283 599 173 307 599 minecraft:black_concrete
fill 183 283 569 183 307 569 minecraft:black_concrete
setblock 183 283 573 minecraft:shroomlight
setblock 141 284 594 minecraft:shroomlight
fill 146 284 599 146 307 599 minecraft:black_concrete
fill 169 284 557 169 307 557 minecraft:black_concrete
fill 173 284 557 173 307 557 minecraft:black_concrete
setblock 181 284 557 minecraft:shroomlight
fill 183 284 573 183 290 573 minecraft:black_concrete
setblock 183 284 592 minecraft:shroomlight
setblock 141 285 592 minecraft:white_concrete
fill 141 285 593 141 298 594 minecraft:black_concrete
fill 181 285 557 181 307 557 minecraft:black_concrete
setblock 183 285 588 minecraft:white_concrete
fill 183 285 592 183 292 592 minecraft:black_concrete
setblock 141 286 568 minecraft:shroomlight
fill 141 286 592 141 293 592 minecraft:black_concrete
fill 183 286 588 183 307 588 minecraft:black_concrete
fill 141 287 568 141 307 568 minecraft:black_concrete
setblock 183 287 570 minecraft:white_concrete
fill 141 288 565 141 290 565 minecraft:gold_block
setblock 141 288 574 minecraft:shroomlight
fill 141 288 581 141 290 581 minecraft:gold_block
fill 141 288 597 141 290 597 minecraft:gold_block
setblock 144 288 560 minecraft:light[level=14]
setblock 144 288 568 minecraft:light[level=14]
setblock 144 288 576 minecraft:light[level=14]
setblock 144 288 584 minecraft:light[level=14]
setblock 144 288 592 minecraft:light[level=14]
fill 145 288 557 145 290 557 minecraft:gold_block
setblock 152 288 560 minecraft:light[level=14]
setblock 152 288 568 minecraft:light[level=14]
setblock 152 288 576 minecraft:light[level=14]
setblock 152 288 584 minecraft:light[level=14]
setblock 152 288 592 minecraft:light[level=14]
fill 155 288 599 155 290 599 minecraft:gold_block
setblock 160 288 560 minecraft:light[level=14]
setblock 160 288 568 minecraft:light[level=14]
setblock 160 288 576 minecraft:light[level=14]
setblock 160 288 584 minecraft:light[level=14]
setblock 160 288 592 minecraft:light[level=14]
fill 161 288 557 161 290 557 minecraft:gold_block
setblock 168 288 560 minecraft:light[level=14]
setblock 168 288 568 minecraft:light[level=14]
setblock 168 288 576 minecraft:light[level=14]
setblock 168 288 584 minecraft:light[level=14]
setblock 168 288 592 minecraft:light[level=14]
fill 171 288 599 171 290 599 minecraft:gold_block
setblock 172 288 599 minecraft:white_concrete
setblock 176 288 560 minecraft:light[level=14]
setblock 176 288 568 minecraft:light[level=14]
setblock 176 288 576 minecraft:light[level=14]
setblock 176 288 584 minecraft:light[level=14]
setblock 176 288 592 minecraft:light[level=14]
fill 177 288 557 177 290 557 minecraft:gold_block
fill 183 288 567 183 290 567 minecraft:gold_block
fill 183 288 570 183 302 570 minecraft:black_concrete
fill 183 288 583 183 290 583 minecraft:gold_block
fill 141 289 574 141 307 574 minecraft:black_concrete
fill 150 289 557 151 289 557 minecraft:shroomlight
setblock 170 289 599 minecraft:shroomlight
fill 172 289 599 172 307 599 minecraft:black_concrete
fill 150 290 557 151 307 557 minecraft:black_concrete
fill 170 290 599 170 301 599 minecraft:black_concrete
setblock 141 291 558 minecraft:shroomlight
fill 141 291 565 141 296 565 minecraft:black_concrete
setblock 141 291 571 minecraft:shroomlight
fill 141 291 581 141 296 581 minecraft:black_concrete
fill 141 291 597 141 296 597 minecraft:black_concrete
setblock 142 291 557 minecraft:white_concrete
fill 145 291 557 145 292 557 minecraft:black_concrete
fill 155 291 599 155 296 599 minecraft:black_concrete
fill 161 291 557 161 296 557 minecraft:black_concrete
setblock 162 291 599 minecraft:white_concrete
fill 171 291 599 171 296 599 minecraft:black_concrete
fill 177 291 557 177 296 557 minecraft:black_concrete
setblock 183 291 560 minecraft:white_concrete
fill 183 291 567 183 296 567 minecraft:black_concrete
fill 183 291 571 183 307 571 minecraft:black_concrete
fill 183 291 572 183 291 573 minecraft:shroomlight
fill 183 291 583 183 296 583 minecraft:black_concrete
fill 141 292 558 141 307 558 minecraft:black_concrete
fill 141 292 571 141 305 571 minecraft:black_concrete
setblock 141 292 575 minecraft:shroomlight
fill 142 292 557 142 307 557 minecraft:black_concrete
fill 162 292 599 162 307 599 minecraft:black_concrete
fill 183 292 560 183 307 560 minecraft:black_concrete
setblock 183 292 562 minecraft:white_concrete
fill 183 292 572 183 307 573 minecraft:black_concrete
setblock 183 292 595 minecraft:shroomlight
fill 141 293 575 141 307 575 minecraft:black_concrete
setblock 145 293 557 minecraft:shroomlight
setblock 157 293 557 minecraft:white_concrete
fill 183 293 562 183 294 562 minecraft:black_concrete
setblock 183 293 591 minecraft:white_concrete
setblock 183 293 592 minecraft:shroomlight
fill 183 293 595 183 305 595 minecraft:black_concrete
setblock 141 294 592 minecraft:shroomlight
fill 145 294 557 145 296 557 minecraft:black_concrete
fill 157 294 557 157 307 557 minecraft:black_concrete
fill 183 294 591 183 307 592 minecraft:black_concrete
fill 141 295 592 141 307 592 minecraft:black_concrete
fill 165 295 557 166 307 557 minecraft:black_concrete
fill 167 295 557 168 295 557 minecraft:shroomlight
setblock 183 295 562 minecraft:white_concrete
setblock 144 296 560 minecraft:light[level=14]
setblock 144 296 568 minecraft:light[level=14]
setblock 144 296 576 minecraft:light[level=14]
setblock 144 296 584 minecraft:light[level=14]
setblock 144 296 592 minecraft:light[level=14]
setblock 152 296 560 minecraft:light[level=14]
setblock 152 296 568 minecraft:light[level=14]
setblock 152 296 576 minecraft:light[level=14]
setblock 152 296 584 minecraft:light[level=14]
setblock 152 296 592 minecraft:light[level=14]
setblock 160 296 560 minecraft:light[level=14]
setblock 160 296 568 minecraft:light[level=14]
setblock 160 296 576 minecraft:light[level=14]
setblock 160 296 584 minecraft:light[level=14]
setblock 160 296 592 minecraft:light[level=14]
fill 167 296 557 168 301 557 minecraft:black_concrete
setblock 168 296 560 minecraft:light[level=14]
setblock 168 296 568 minecraft:light[level=14]
setblock 168 296 576 minecraft:light[level=14]
setblock 168 296 584 minecraft:light[level=14]
setblock 168 296 592 minecraft:light[level=14]
setblock 176 296 560 minecraft:light[level=14]
setblock 176 296 568 minecraft:light[level=14]
setblock 176 296 576 minecraft:light[level=14]
setblock 176 296 584 minecraft:light[level=14]
setblock 176 296 592 minecraft:light[level=14]
fill 183 296 562 183 305 562 minecraft:black_concrete
fill 141 297 565 141 299 565 minecraft:gold_block
fill 141 297 581 141 299 581 minecraft:gold_block
fill 141 297 597 141 299 597 minecraft:gold_block
fill 145 297 557 145 299 557 minecraft:gold_block
fill 155 297 599 155 299 599 minecraft:gold_block
fill 161 297 557 161 299 557 minecraft:gold_block
setblock 163 297 599 minecraft:white_concrete
fill 164 297 599 164 302 599 minecraft:black_concrete
fill 171 297 599 171 299 599 minecraft:gold_block
fill 177 297 557 177 299 557 minecraft:gold_block
fill 183 297 567 183 299 567 minecraft:gold_block
fill 183 297 583 183 299 583 minecraft:gold_block
setblock 141 298 561 minecraft:shroomlight
setblock 159 298 599 minecraft:shroomlight
fill 163 298 599 163 307 599 minecraft:black_concrete
fill 141 299 561 141 307 561 minecraft:black_concrete
setblock 141 299 593 minecraft:shroomlight
fill 141 299 594 141 307 594 minecraft:black_concrete
fill 159 299 599 159 307 599 minecraft:black_concrete
fill 141 300 565 141 307 565 minecraft:black_concrete
fill 141 300 581 141 307 581 minecraft:black_concrete
setblock 141 300 587 minecraft:shroomlight
fill 141 300 593 141 307 593 minecraft:black_concrete
setblock 141 300 596 minecraft:shroomlight
fill 141 300 597 141 307 597 minecraft:black_concrete
fill 145 300 557 145 303 557 minecraft:black_concrete
fill 155 300 599 155 307 599 minecraft:black_concrete
fill 161 300 557 161 307 557 minecraft:black_concrete
fill 171 300 599 171 307 599 minecraft:black_concrete
fill 177 300 557 177 301 557 minecraft:black_concrete
fill 183 300 567 183 302 567 minecraft:black_concrete
fill 183 300 583 183 305 583 minecraft:black_concrete
fill 141 301 587 141 307 587 minecraft:black_concrete
fill 141 301 596 141 307 596 minecraft:black_concrete
setblock 141 302 572 minecraft:white_concrete
fill 167 302 557 167 307 557 minecraft:black_concrete
setblock 168 302 557 minecraft:shroomlight
setblock 170 302 599 minecraft:shroomlight
setblock 177 302 557 minecraft:white_concrete
setblock 182 302 557 minecraft:white_concrete
fill 183 302 557 183 307 557 minecraft:black_concrete
setblock 183 302 593 minecraft:shroomlight
fill 141 303 572 141 307 572 minecraft:black_concrete
setblock 164 303 599 minecraft:white_concrete
fill 168 303 557 168 307 557 minecraft:black_concrete
fill 170 303 599 170 307 599 minecraft:black_concrete
fill 177 303 557 177 307 557 minecraft:black_concrete
fill 182 303 557 182 307 557 minecraft:black_concrete
setblock 183 303 567 minecraft:white_concrete
setblock 183 303 570 minecraft:shroomlight
fill 183 303 593 183 307 593 minecraft:black_concrete
setblock 183 303 594 minecraft:white_concrete
setblock 145 304 557 minecraft:shroomlight
fill 164 304 599 164 307 599 minecraft:black_concrete
fill 183 304 567 183 305 567 minecraft:black_concrete
fill 183 304 570 183 307 570 minecraft:black_concrete
fill 183 304 594 183 307 594 minecraft:black_concrete
fill 145 305 557 145 307 557 minecraft:black_concrete
setblock 141 306 571 minecraft:shroomlight
setblock 148 306 557 minecraft:white_concrete
setblock 183 306 562 minecraft:white_concrete
setblock 183 306 567 minecraft:shroomlight
setblock 183 306 583 minecraft:shroomlight
setblock 183 306 595 minecraft:shroomlight
setblock 141 307 571 minecraft:black_concrete
setblock 141 307 579 minecraft:white_concrete
setblock 148 307 557 minecraft:black_concrete
setblock 170 307 557 minecraft:shroomlight
setblock 183 307 562 minecraft:black_concrete
setblock 183 307 567 minecraft:black_concrete
setblock 183 307 583 minecraft:black_concrete
setblock 183 307 595 minecraft:black_concrete
