fill 227 176 590 227 177 590 minecraft:quartz_block
fill 227 176 592 227 177 592 minecraft:quartz_block
fill 227 176 594 227 177 594 minecraft:quartz_block
fill 227 176 596 227 177 596 minecraft:quartz_block
fill 227 176 598 227 177 598 minecraft:quartz_block
fill 228 176 589 228 177 589 minecraft:quartz_block
fill 228 176 591 228 177 591 minecraft:quartz_block
fill 228 176 593 228 177 593 minecraft:quartz_block
fill 228 176 595 228 177 595 minecraft:quartz_block
fill 228 176 597 228 177 597 minecraft:quartz_block
fill 229 176 590 229 177 590 minecraft:quartz_block
fill 229 176 592 229 177 592 minecraft:quartz_block
fill 229 176 594 229 177 594 minecraft:quartz_block
fill 229 176 596 229 177 596 minecraft:quartz_block
fill 229 176 598 229 177 598 minecraft:quartz_block
fill 194 178 559 200 178 563 minecraft:gold_block
setblock 219 178 590 minecraft:ochre_froglight
setblock 219 178 592 minecraft:ochre_froglight
setblock 219 178 594 minecraft:ochre_froglight
setblock 219 178 596 minecraft:ochre_froglight
setblock 219 178 598 minecraft:ochre_froglight
setblock 220 178 589 minecraft:ochre_froglight
setblock 220 178 591 minecraft:ochre_froglight
setblock 220 178 593 minecraft:ochre_froglight
setblock 220 178 595 minecraft:ochre_froglight
setblock 220 178 597 minecraft:ochre_froglight
setblock 221 178 590 minecraft:ochre_froglight
setblock 221 178 592 minecraft:ochre_froglight
setblock 221 178 594 minecraft:ochre_froglight
setblock 221 178 596 minecraft:ochre_froglight
setblock 221 178 598 minecraft:ochre_froglight
setblock 222 178 589 minecraft:ochre_froglight
setblock 222 178 591 minecraft:ochre_froglight
setblock 222 178 593 minecraft:ochre_froglight
setblock 222 178 595 minecraft:ochre_froglight
setblock 222 178 597 minecraft:ochre_froglight
setblock 223 178 590 minecraft:ochre_froglight
setblock 223 178 592 minecraft:ochre_froglight
setblock 223 178 594 minecraft:ochre_froglight
setblock 223 178 596 minecraft:ochre_froglight
setblock 223 178 598 minecraft:ochre_froglight
setblock 224 178 589 minecraft:ochre_froglight
setblock 224 178 591 minecraft:ochre_froglight
setblock 224 178 593 minecraft:ochre_froglight
setblock 224 178 595 minecraft:ochre_froglight
setblock 224 178 597 minecraft:ochre_froglight
setblock 225 178 590 minecraft:ochre_froglight
setblock 225 178 592 minecraft:ochre_froglight
setblock 225 178 594 minecraft:ochre_froglight
setblock 225 178 596 minecraft:ochre_froglight
setblock 225 178 598 minecraft:ochre_froglight
setblock 226 178 589 minecraft:ochre_froglight
setblock 226 178 591 minecraft:ochre_froglight
setblock 226 178 593 minecraft:ochre_froglight
setblock 226 178 595 minecraft:ochre_froglight
setblock 226 178 597 minecraft:ochre_froglight
setblock 227 178 590 minecraft:ochre_froglight
setblock 227 178 592 minecraft:ochre_froglight
setblock 227 178 594 minecraft:ochre_froglight
setblock 227 178 596 minecraft:ochre_froglight
setblock 227 178 598 minecraft:ochre_froglight
setblock 228 178 589 minecraft:ochre_froglight
setblock 228 178 591 minecraft:ochre_froglight
setblock 228 178 593 minecraft:ochre_froglight
setblock 228 178 595 minecraft:ochre_froglight
setblock 228 178 597 minecraft:ochre_froglight
setblock 229 178 590 minecraft:ochre_froglight
setblock 229 178 592 minecraft:ochre_froglight
setblock 229 178 594 minecraft:ochre_froglight
setblock 229 178 596 minecraft:ochre_froglight
setblock 229 178 598 minecraft:ochre_froglight
setblock 191 179 560 minecraft:light[level=14]
setblock 191 179 568 minecraft:light[level=14]
setblock 191 179 576 minecraft:light[level=14]
setblock 191 179 584 minecraft:light[level=14]
setblock 191 179 592 minecraft:light[level=14]
fill 195 179 560 199 179 562 minecraft:gold_block
setblock 199 179 568 minecraft:light[level=14]
setblock 199 179 576 minecraft:light[level=14]
setblock 199 179 584 minecraft:light[level=14]
setblock 199 179 592 minecraft:light[level=14]
setblock 207 179 560 minecraft:light[level=14]
setblock 207 179 568 minecraft:light[level=14]
setblock 207 179 576 minecraft:light[level=14]
setblock 207 179 584 minecraft:light[level=14]
setblock 207 179 592 minecraft:light[level=14]
setblock 215 179 560 minecraft:light[level=14]
setblock 215 179 568 minecraft:light[level=14]
setblock 215 179 576 minecraft:light[level=14]
setblock 215 179 584 minecraft:light[level=14]
setblock 215 179 592 minecraft:light[level=14]
fill 219 179 590 219 180 590 minecraft:quartz_block
fill 219 179 592 219 180 592 minecraft:quartz_block
fill 219 179 594 219 180 594 minecraft:quartz_block
fill 219 179 596 219 180 596 minecraft:quartz_block
fill 219 179 598 219 220 598 minecraft:quartz_block
fill 220 179 589 220 180 589 minecraft:quartz_block
fill 220 179 591 220 180 591 minecraft:quartz_block
fill 220 179 593 220 180 593 minecraft:quartz_block
fill 220 179 595 220 180 595 minecraft:quartz_block
fill 220 179 597 220 185 597 minecraft:quartz_block
fill 221 179 590 221 180 590 minecraft:quartz_block
fill 221 179 592 221 180 592 minecraft:quartz_block
fill 221 179 594 221 180 594 minecraft:quartz_block
fill 221 179 596 221 180 596 minecraft:quartz_block
fill 221 179 598 221 220 598 minecraft:quartz_block
fill 222 179 589 222 180 589 minecraft:quartz_block
fill 222 179 591 222 180 591 minecraft:quartz_block
fill 222 179 593 222 180 593 minecraft:quartz_block
fill 222 179 595 222 180 595 minecraft:quartz_block
fill 222 179 597 222 185 597 minecraft:quartz_block
setblock 223 179 560 minecraft:light[level=14]
setblock 223 179 568 minecraft:light[level=14]
setblock 223 179 576 minecraft:light[level=14]
setblock 223 179 584 minecraft:light[level=14]
fill 223 179 590 223 180 590 minecraft:quartz_block
fill 223 179 592 223 180 592 minecraft:quartz_block
fill 223 179 594 223 180 594 minecraft:quartz_block
fill 223 179 596 223 180 596 minecraft:quartz_block
fill 223 179 598 223 180 598 minecraft:quartz_block
fill 224 179 589 224 180 589 minecraft:quartz_block
fill 224 179 591 224 180 591 minecraft:quartz_block
fill 224 179 593 224 180 593 minecraft:quartz_block
fill 224 179 595 224 180 595 minecraft:quartz_block
fill 224 179 597 224 180 597 minecraft:quartz_block
fill 225 179 590 225 180 590 minecraft:quartz_block
fill 225 179 592 225 180 592 minecraft:quartz_block
fill 225 179 594 225 180 594 minecraft:quartz_block
fill 225 179 596 225 180 596 minecraft:quartz_block
fill 225 179 598 225 180 598 minecraft:quartz_block
fill 226 179 589 226 180 589 minecraft:quartz_block
fill 226 179 591 226 180 591 minecraft:quartz_block
fill 226 179 593 226 180 593 minecraft:quartz_block
fill 226 179 595 226 180 595 minecraft:quartz_block
fill 226 179 597 226 180 597 minecraft:quartz_block
fill 227 179 590 227 180 590 minecraft:quartz_block
fill 227 179 592 227 180 592 minecraft:quartz_block
fill 227 179 594 227 180 594 minecraft:quartz_block
fill 227 179 596 227 180 596 minecraft:quartz_block
fill 227 179 598 227 180 598 minecraft:quartz_block
fill 228 179 589 228 180 589 minecraft:quartz_block
fill 228 179 591 228 185 591 minecraft:quartz_block
fill 228 179 593 228 185 593 minecraft:quartz_block
fill 228 179 595 228 180 595 minecraft:quartz_block
fill 228 179 597 228 180 597 minecraft:quartz_block
fill 229 179 590 229 220 590 minecraft:quartz_block
fill 229 179 592 229 220 592 minecraft:quartz_block
fill 229 179 594 229 180 594 minecraft:quartz_block
fill 229 179 596 229 180 596 minecraft:quartz_block
fill 229 179 598 229 180 598 minecraft:quartz_block
fill 190 180 567 190 185 569 minecraft:quartz_block
fill 190 180 579 190 185 581 minecraft:quartz_block
fill 190 180 591 190 185 593 minecraft:quartz_block
fill 196 180 561 198 180 561 minecraft:gold_block
fill 196 180 597 198 185 597 minecraft:quartz_block
fill 200 180 559 202 185 559 minecraft:quartz_block
fill 201 180 580 201 181 580 minecraft:stripped_dark_oak_log
fill 208 180 597 210 185 597 minecraft:quartz_block
fill 212 180 559 214 185 559 minecraft:quartz_block
fill 224 180 559 226 185 559 minecraft:quartz_block
fill 228 180 567 228 185 569 minecraft:quartz_block
fill 228 180 579 228 185 581 minecraft:quartz_block
fill 197 181 560 197 181 562 minecraft:gold_block
fill 220 181 590 227 181 596 minecraft:gold_block
fill 223 181 597 228 181 597 minecraft:gold_block
setblock 228 181 590 minecraft:gold_block
fill 228 181 594 228 181 596 minecraft:gold_block
fill 221 182 591 227 182 596 minecraft:gold_block
fill 222 183 592 226 183 595 minecraft:gold_block
fill 223 184 593 225 184 594 minecraft:gold_block
fill 189 185 561 189 185 566 minecraft:yellow_terracotta
fill 189 185 573 189 185 578 minecraft:yellow_terracotta
fill 189 185 585 189 185 590 minecraft:yellow_terracotta
fill 189 185 597 189 185 598 minecraft:yellow_terracotta
fill 190 185 598 193 185 598 minecraft:yellow_terracotta
fill 193 185 558 198 185 558 minecraft:yellow_terracotta
fill 200 185 598 205 185 598 minecraft:yellow_terracotta
fill 205 185 558 210 185 558 minecraft:yellow_terracotta
fill 212 185 598 217 185 598 minecraft:yellow_terracotta
fill 217 185 558 222 185 558 minecraft:yellow_terracotta
fill 224 185 598 229 185 598 minecraft:yellow_terracotta
fill 229 185 558 229 185 563 minecraft:yellow_terracotta
fill 229 185 570 229 185 575 minecraft:yellow_terracotta
fill 229 185 582 229 185 587 minecraft:yellow_terracotta
fill 229 185 594 229 185 597 minecraft:yellow_terracotta
fill 188 186 563 188 191 566 minecraft:ochre_froglight
fill 188 186 575 188 191 578 minecraft:ochre_froglight
fill 188 186 587 188 191 590 minecraft:ochre_froglight
fill 188 186 599 191 191 599 minecraft:ochre_froglight
fill 195 186 557 198 191 557 minecraft:ochre_froglight
fill 200 186 599 203 191 599 minecraft:ochre_froglight
fill 207 186 557 210 191 557 minecraft:ochre_froglight
fill 212 186 599 215 191 599 minecraft:ochre_froglight
fill 219 186 557 222 191 557 minecraft:ochre_froglight
fill 224 186 599 227 191 599 minecraft:ochre_froglight
fill 230 186 558 230 191 561 minecraft:ochre_froglight
fill 230 186 570 230 191 573 minecraft:ochre_froglight
fill 230 186 582 230 191 585 minecraft:ochre_froglight
fill 230 186 594 230 191 597 minecraft:ochre_froglight
setblock 191 187 560 minecraft:light[level=14]
setblock 191 187 568 minecraft:light[level=14]
setblock 191 187 576 minecraft:light[level=14]
setblock 191 187 584 minecraft:light[level=14]
setblock 191 187 592 minecraft:light[level=14]
setblock 199 187 560 minecraft:light[level=14]
setblock 199 187 568 minecraft:light[level=14]
setblock 199 187 576 minecraft:light[level=14]
setblock 199 187 584 minecraft:light[level=14]
setblock 199 187 592 minecraft:light[level=14]
setblock 207 187 560 minecraft:light[level=14]
setblock 207 187 568 minecraft:light[level=14]
setblock 207 187 576 minecraft:light[level=14]
setblock 207 187 584 minecraft:light[level=14]
setblock 207 187 592 minecraft:light[level=14]
setblock 215 187 560 minecraft:light[level=14]
setblock 215 187 568 minecraft:light[level=14]
setblock 215 187 576 minecraft:light[level=14]
setblock 215 187 584 minecraft:light[level=14]
setblock 215 187 592 minecraft:light[level=14]
fill 220 187 573 221 188 573 minecraft:raw_gold_block
setblock 223 187 560 minecraft:light[level=14]
setblock 223 187 568 minecraft:light[level=14]
setblock 223 187 576 minecraft:light[level=14]
setblock 223 187 584 minecraft:light[level=14]
setblock 223 187 592 minecraft:light[level=14]
fill 218 188 585 218 189 586 minecraft:gold_block
fill 188 192 563 188 201 563 minecraft:yellow_terracotta
fill 188 192 564 188 192 565 minecraft:ochre_froglight
fill 188 192 566 188 200 566 minecraft:yellow_terracotta
fill 188 192 575 188 196 575 minecraft:yellow_terracotta
fill 188 192 576 188 192 577 minecraft:ochre_froglight
fill 188 192 578 188 196 578 minecraft:yellow_terracotta
fill 188 192 587 188 200 587 minecraft:yellow_terracotta
fill 188 192 588 188 192 589 minecraft:ochre_froglight
fill 188 192 590 188 200 590 minecraft:yellow_terracotta
fill 188 192 599 188 200 599 minecraft:yellow_terracotta
fill 189 192 599 190 192 599 minecraft:ochre_froglight
fill 191 192 599 191 200 599 minecraft:yellow_terracotta
fill 195 192 557 195 200 557 minecraft:yellow_terracotta
fill 196 192 557 197 192 557 minecraft:ochre_froglight
fill 198 192 557 198 200 557 minecraft:yellow_terracotta
fill 200 192 599 200 200 599 minecraft:yellow_terracotta
fill 201 192 599 202 192 599 minecraft:ochre_froglight
fill 203 192 599 203 200 599 minecraft:yellow_terracotta
fill 207 192 557 207 197 557 minecraft:yellow_terracotta
fill 208 192 557 209 192 557 minecraft:ochre_froglight
fill 210 192 557 210 197 557 minecraft:yellow_terracotta
fill 212 192 599 212 198 599 minecraft:yellow_terracotta
fill 213 192 599 214 192 599 minecraft:ochre_froglight
fill 215 192 599 215 201 599 minecraft:yellow_terracotta
fill 219 192 557 219 200 557 minecraft:yellow_terracotta
fill 220 192 557 221 192 557 minecraft:ochre_froglight
fill 222 192 557 222 200 557 minecraft:yellow_terracotta
fill 224 192 599 224 200 599 minecraft:yellow_terracotta
fill 225 192 599 226 192 599 minecraft:ochre_froglight
fill 227 192 599 227 197 599 minecraft:yellow_terracotta
fill 230 192 558 230 200 558 minecraft:yellow_terracotta
fill 230 192 559 230 192 560 minecraft:ochre_froglight
fill 230 192 561 230 200 561 minecraft:yellow_terracotta
fill 230 192 570 230 200 570 minecraft:yellow_terracotta
fill 230 192 571 230 192 572 minecraft:ochre_froglight
fill 230 192 573 230 198 573 minecraft:yellow_terracotta
fill 230 192 582 230 200 582 minecraft:yellow_terracotta
fill 230 192 583 230 192 584 minecraft:ochre_froglight
fill 230 192 585 230 196 585 minecraft:yellow_terracotta
fill 230 192 594 230 196 594 minecraft:yellow_terracotta
fill 230 192 595 230 192 596 minecraft:ochre_froglight
fill 230 192 597 230 200 597 minecraft:yellow_terracotta
fill 188 193 564 188 196 565 minecraft:yellow_terracotta
fill 188 193 576 188 200 577 minecraft:yellow_terracotta
fill 188 193 588 188 200 589 minecraft:yellow_terracotta
fill 189 193 599 190 198 599 minecraft:yellow_terracotta
fill 196 193 557 197 198 557 minecraft:yellow_terracotta
fill 201 193 599 202 196 599 minecraft:yellow_terracotta
fill 208 193 557 209 200 557 minecraft:yellow_terracotta
fill 213 193 599 214 200 599 minecraft:yellow_terracotta
fill 220 193 557 221 196 557 minecraft:yellow_terracotta
fill 225 193 599 226 196 599 minecraft:yellow_terracotta
fill 230 193 559 230 201 560 minecraft:yellow_terracotta
fill 230 193 571 230 196 572 minecraft:yellow_terracotta
fill 230 193 583 230 196 584 minecraft:yellow_terracotta
fill 230 193 595 230 197 596 minecraft:yellow_terracotta
fill 197 194 559 197 208 559 minecraft:red_wool
setblock 191 195 560 minecraft:light[level=14]
setblock 191 195 568 minecraft:light[level=14]
setblock 191 195 576 minecraft:light[level=14]
setblock 191 195 584 minecraft:light[level=14]
setblock 191 195 592 minecraft:light[level=14]
fill 195 195 559 196 208 559 minecraft:red_wool
fill 198 195 559 199 208 559 minecraft:red_wool
setblock 199 195 560 minecraft:light[level=14]
setblock 199 195 568 minecraft:light[level=14]
setblock 199 195 576 minecraft:light[level=14]
setblock 199 195 584 minecraft:light[level=14]
setblock 199 195 592 minecraft:light[level=14]
setblock 207 195 560 minecraft:light[level=14]
setblock 207 195 568 minecraft:light[level=14]
setblock 207 195 576 minecraft:light[level=14]
setblock 207 195 584 minecraft:light[level=14]
setblock 207 195 592 minecraft:light[level=14]
setblock 215 195 560 minecraft:light[level=14]
setblock 215 195 568 minecraft:light[level=14]
setblock 215 195 576 minecraft:light[level=14]
setblock 215 195 584 minecraft:light[level=14]
setblock 215 195 592 minecraft:light[level=14]
setblock 223 195 560 minecraft:light[level=14]
setblock 223 195 568 minecraft:light[level=14]
setblock 223 195 576 minecraft:light[level=14]
setblock 223 195 584 minecraft:light[level=14]
setblock 223 195 592 minecraft:light[level=14]
setblock 188 197 564 minecraft:gold_block
fill 188 197 565 188 200 565 minecraft:yellow_terracotta
setblock 188 197 575 minecraft:gold_block
setblock 188 197 578 minecraft:gold_block
fill 188 197 585 188 197 586 minecraft:gold_block
setblock 188 197 591 minecraft:gold_block
fill 188 197 592 188 197 596 minecraft:yellow_terracotta
setblock 190 197 557 minecraft:gold_block
setblock 197 197 599 minecraft:gold_block
fill 201 197 599 201 200 599 minecraft:yellow_terracotta
setblock 202 197 599 minecraft:gold_block
setblock 206 197 599 minecraft:gold_block
fill 212 197 557 212 198 557 minecraft:yellow_terracotta
setblock 213 197 557 minecraft:gold_block
setblock 214 197 557 minecraft:yellow_terracotta
setblock 216 197 599 minecraft:gold_block
fill 217 197 599 221 197 599 minecraft:yellow_terracotta
fill 220 197 557 220 200 557 minecraft:yellow_terracotta
setblock 221 197 557 minecraft:gold_block
setblock 225 197 599 minecraft:gold_block
fill 226 197 599 226 200 599 minecraft:yellow_terracotta
fill 227 197 557 227 200 557 minecraft:yellow_terracotta
setblock 228 197 557 minecraft:gold_block
fill 230 197 571 230 198 571 minecraft:gold_block
fill 230 197 572 230 200 572 minecraft:yellow_terracotta
setblock 230 197 583 minecraft:gold_block
fill 230 197 584 230 200 584 minecraft:yellow_terracotta
fill 230 197 585 230 198 585 minecraft:gold_block
setblock 230 197 594 minecraft:gold_block
fill 188 198 557 188 198 559 minecraft:yellow_terracotta
setblock 188 198 560 minecraft:gold_block
fill 188 198 564 188 200 564 minecraft:yellow_terracotta
fill 188 198 575 188 200 575 minecraft:yellow_terracotta
fill 188 198 578 188 200 578 minecraft:yellow_terracotta
fill 188 198 580 188 200 581 minecraft:yellow_terracotta
setblock 188 198 582 minecraft:gold_block
fill 188 198 585 188 199 585 minecraft:gold_block
fill 188 198 586 188 200 586 minecraft:yellow_terracotta
fill 188 198 591 188 198 593 minecraft:yellow_terracotta
setblock 188 198 594 minecraft:gold_block
fill 188 198 595 188 200 596 minecraft:yellow_terracotta
fill 188 198 597 188 198 598 minecraft:gold_block
fill 190 198 557 190 200 557 minecraft:yellow_terracotta
setblock 193 198 557 minecraft:gold_block
fill 197 198 599 197 200 599 minecraft:yellow_terracotta
fill 199 198 557 200 200 557 minecraft:yellow_terracotta
setblock 201 198 557 minecraft:gold_block
fill 202 198 599 202 202 599 minecraft:yellow_terracotta
fill 206 198 599 206 200 599 minecraft:yellow_terracotta
setblock 207 198 557 minecraft:gold_block
setblock 210 198 557 minecraft:gold_block
fill 213 198 557 213 200 557 minecraft:yellow_terracotta
setblock 214 198 557 minecraft:gold_block
fill 216 198 599 216 200 599 minecraft:yellow_terracotta
setblock 217 198 599 minecraft:gold_block
setblock 218 198 557 minecraft:gold_block
fill 218 198 599 221 200 599 minecraft:yellow_terracotta
fill 221 198 557 221 200 557 minecraft:yellow_terracotta
setblock 222 198 599 minecraft:gold_block
fill 225 198 599 225 200 599 minecraft:yellow_terracotta
setblock 227 198 599 minecraft:gold_block
fill 228 198 557 228 200 557 minecraft:yellow_terracotta
fill 230 198 562 230 199 562 minecraft:gold_block
fill 230 198 564 230 200 568 minecraft:yellow_terracotta
setblock 230 198 569 minecraft:gold_block
setblock 230 198 574 minecraft:gold_block
fill 230 198 575 230 198 580 minecraft:yellow_terracotta
setblock 230 198 581 minecraft:gold_block
fill 230 198 583 230 200 583 minecraft:yellow_terracotta
fill 230 198 586 230 200 590 minecraft:yellow_terracotta
setblock 230 198 591 minecraft:gold_block
fill 230 198 592 230 198 595 minecraft:yellow_terracotta
setblock 230 198 596 minecraft:gold_block
fill 188 199 557 188 200 558 minecraft:yellow_terracotta
setblock 188 199 559 minecraft:gold_block
fill 188 199 560 188 200 560 minecraft:yellow_terracotta
setblock 188 199 567 minecraft:gold_block
fill 188 199 582 188 200 582 minecraft:yellow_terracotta
fill 188 199 591 188 200 592 minecraft:yellow_terracotta
setblock 188 199 593 minecraft:gold_block
fill 188 199 594 188 200 594 minecraft:yellow_terracotta
fill 188 199 597 188 200 598 minecraft:yellow_terracotta
fill 189 199 599 189 200 599 minecraft:yellow_terracotta
setblock 190 199 599 minecraft:gold_block
fill 193 199 557 193 200 557 minecraft:yellow_terracotta
fill 196 199 557 196 200 557 minecraft:yellow_terracotta
setblock 197 199 557 minecraft:gold_block
setblock 198 199 599 minecraft:gold_block
fill 201 199 557 201 200 557 minecraft:yellow_terracotta
fill 207 199 557 207 200 557 minecraft:yellow_terracotta
fill 207 199 599 210 200 599 minecraft:yellow_terracotta
fill 210 199 557 210 200 557 minecraft:yellow_terracotta
fill 211 199 599 212 199 599 minecraft:gold_block
setblock 212 199 557 minecraft:gold_block
fill 214 199 557 214 200 557 minecraft:yellow_terracotta
fill 217 199 599 217 201 599 minecraft:yellow_terracotta
fill 218 199 557 218 200 557 minecraft:yellow_terracotta
fill 222 199 599 222 200 599 minecraft:yellow_terracotta
fill 223 199 557 224 199 557 minecraft:gold_block
fill 225 199 557 225 200 557 minecraft:yellow_terracotta
fill 227 199 599 227 200 599 minecraft:yellow_terracotta
fill 230 199 569 230 200 569 minecraft:yellow_terracotta
fill 230 199 571 230 200 571 minecraft:yellow_terracotta
setblock 230 199 573 minecraft:gold_block
fill 230 199 574 230 200 577 minecraft:yellow_terracotta
setblock 230 199 578 minecraft:gold_block
fill 230 199 579 230 200 581 minecraft:yellow_terracotta
fill 230 199 585 230 200 585 minecraft:yellow_terracotta
fill 230 199 591 230 200 593 minecraft:yellow_terracotta
setblock 230 199 594 minecraft:gold_block
fill 230 199 595 230 200 596 minecraft:yellow_terracotta
setblock 188 200 559 minecraft:yellow_terracotta
setblock 188 200 567 minecraft:yellow_terracotta
setblock 188 200 585 minecraft:yellow_terracotta
fill 188 200 593 188 201 593 minecraft:yellow_terracotta
fill 190 200 567 190 205 569 minecraft:quartz_block
fill 190 200 579 190 205 581 minecraft:quartz_block
fill 190 200 591 190 205 593 minecraft:quartz_block
setblock 190 200 599 minecraft:yellow_terracotta
fill 196 200 597 198 205 597 minecraft:quartz_block
setblock 197 200 557 minecraft:yellow_terracotta
setblock 198 200 599 minecraft:yellow_terracotta
fill 200 200 559 202 205 559 minecraft:quartz_block
fill 208 200 597 210 205 597 minecraft:quartz_block
fill 211 200 599 212 200 599 minecraft:yellow_terracotta
fill 212 200 557 212 201 557 minecraft:yellow_terracotta
fill 212 200 559 214 205 559 minecraft:quartz_block
fill 220 200 597 222 205 597 minecraft:quartz_block
fill 223 200 557 224 200 557 minecraft:yellow_terracotta
fill 224 200 559 226 205 559 minecraft:quartz_block
fill 228 200 567 228 205 569 minecraft:quartz_block
fill 228 200 579 228 205 581 minecraft:quartz_block
fill 228 200 591 228 205 593 minecraft:quartz_block
setblock 230 200 562 minecraft:yellow_terracotta
setblock 230 200 573 minecraft:yellow_terracotta
setblock 230 200 578 minecraft:yellow_terracotta
setblock 230 200 594 minecraft:yellow_terracotta
fill 188 201 557 188 307 562 minecraft:gold_block
fill 188 201 564 188 201 582 minecraft:gold_block
setblock 188 201 583 minecraft:yellow_terracotta
fill 188 201 584 188 201 592 minecraft:gold_block
fill 188 201 594 188 201 599 minecraft:gold_block
fill 189 201 599 192 202 599 minecraft:gold_block
fill 190 201 557 208 202 557 minecraft:gold_block
setblock 193 201 599 minecraft:yellow_terracotta
fill 194 201 599 201 201 599 minecraft:gold_block
fill 203 201 599 209 202 599 minecraft:gold_block
setblock 209 201 557 minecraft:yellow_terracotta
fill 210 201 557 211 202 557 minecraft:gold_block
setblock 210 201 599 minecraft:yellow_terracotta
fill 211 201 599 214 201 599 minecraft:gold_block
fill 213 201 557 230 202 557 minecraft:gold_block
fill 216 201 599 216 202 599 minecraft:gold_block
fill 218 201 599 222 202 599 minecraft:gold_block
fill 224 201 599 230 201 599 minecraft:gold_block
fill 230 201 558 230 205 558 minecraft:gold_block
fill 230 201 561 230 205 564 minecraft:gold_block
setblock 230 201 565 minecraft:yellow_terracotta
fill 230 201 566 230 202 566 minecraft:gold_block
setblock 230 201 567 minecraft:yellow_terracotta
fill 230 201 568 230 201 573 minecraft:gold_block
fill 230 201 574 230 201 575 minecraft:yellow_terracotta
fill 230 201 576 230 201 586 minecraft:gold_block
setblock 230 201 587 minecraft:yellow_terracotta
fill 230 201 588 230 201 594 minecraft:gold_block
fill 230 201 595 230 202 595 minecraft:yellow_terracotta
fill 230 201 596 230 205 597 minecraft:gold_block
fill 188 202 563 188 202 565 minecraft:gold_block
fill 188 202 566 188 202 567 minecraft:yellow_terracotta
fill 188 202 568 188 205 580 minecraft:gold_block
setblock 188 202 581 minecraft:yellow_terracotta
fill 188 202 582 188 205 589 minecraft:gold_block
fill 188 202 590 188 203 590 minecraft:yellow_terracotta
fill 188 202 591 188 202 597 minecraft:gold_block
setblock 188 202 598 minecraft:yellow_terracotta
setblock 188 202 599 minecraft:gold_block
fill 189 202 557 189 307 557 minecraft:gold_block
fill 193 202 599 197 307 599 minecraft:gold_block
fill 198 202 599 198 203 599 minecraft:yellow_terracotta
fill 199 202 599 201 202 599 minecraft:gold_block
fill 209 202 557 209 205 557 minecraft:gold_block
fill 210 202 599 212 205 599 minecraft:gold_block
fill 212 202 557 212 307 557 minecraft:gold_block
setblock 213 202 599 minecraft:yellow_terracotta
fill 214 202 599 215 205 599 minecraft:gold_block
fill 217 202 599 217 307 599 minecraft:gold_block
fill 223 202 599 224 205 599 minecraft:gold_block
fill 225 202 599 225 203 599 minecraft:yellow_terracotta
fill 226 202 599 230 202 599 minecraft:gold_block
fill 230 202 559 230 205 560 minecraft:gold_block
fill 230 202 565 230 307 565 minecraft:gold_block
fill 230 202 567 230 202 571 minecraft:gold_block
fill 230 202 572 230 203 572 minecraft:yellow_terracotta
fill 230 202 573 230 202 582 minecraft:gold_block
fill 230 202 583 230 202 584 minecraft:yellow_terracotta
fill 230 202 585 230 205 588 minecraft:gold_block
fill 230 202 589 230 203 589 minecraft:yellow_terracotta
fill 230 202 590 230 202 594 minecraft:gold_block
fill 230 202 598 230 307 598 minecraft:gold_block
fill 188 203 563 188 205 564 minecraft:gold_block
setblock 188 203 565 minecraft:yellow_terracotta
fill 188 203 566 188 205 567 minecraft:gold_block
fill 188 203 581 188 307 581 minecraft:gold_block
fill 188 203 591 188 307 595 minecraft:gold_block
setblock 188 203 596 minecraft:yellow_terracotta
fill 188 203 597 188 307 598 minecraft:gold_block
setblock 188 203 599 minecraft:yellow_terracotta
fill 189 203 599 189 205 599 minecraft:gold_block
fill 190 203 557 192 307 557 minecraft:gold_block
setblock 190 203 599 minecraft:yellow_terracotta
setblock 191 203 560 minecraft:light[level=14]
setblock 191 203 568 minecraft:light[level=14]
setblock 191 203 576 minecraft:light[level=14]
setblock 191 203 584 minecraft:light[level=14]
setblock 191 203 592 minecraft:light[level=14]
fill 191 203 599 192 205 599 minecraft:gold_block
setblock 193 203 557 minecraft:yellow_terracotta
fill 194 203 557 208 205 557 minecraft:gold_block
setblock 199 203 560 minecraft:light[level=14]
setblock 199 203 568 minecraft:light[level=14]
setblock 199 203 576 minecraft:light[level=14]
setblock 199 203 584 minecraft:light[level=14]
setblock 199 203 592 minecraft:light[level=14]
setblock 199 203 599 minecraft:yellow_terracotta
fill 200 203 599 203 205 599 minecraft:gold_block
setblock 204 203 599 minecraft:yellow_terracotta
fill 205 203 599 207 307 599 minecraft:gold_block
setblock 207 203 560 minecraft:light[level=14]
setblock 207 203 568 minecraft:light[level=14]
setblock 207 203 576 minecraft:light[level=14]
setblock 207 203 584 minecraft:light[level=14]
setblock 207 203 592 minecraft:light[level=14]
setblock 208 203 599 minecraft:yellow_terracotta
fill 209 203 599 209 307 599 minecraft:gold_block
setblock 210 203 557 minecraft:yellow_terracotta
fill 211 203 557 211 307 557 minecraft:gold_block
fill 213 203 557 219 205 557 minecraft:gold_block
fill 213 203 599 213 205 599 minecraft:gold_block
setblock 215 203 560 minecraft:light[level=14]
setblock 215 203 568 minecraft:light[level=14]
setblock 215 203 576 minecraft:light[level=14]
setblock 215 203 584 minecraft:light[level=14]
setblock 215 203 592 minecraft:light[level=14]
setblock 216 203 599 minecraft:yellow_terracotta
fill 218 203 599 219 307 599 minecraft:gold_block
setblock 220 203 557 minecraft:yellow_terracotta
setblock 220 203 599 minecraft:yellow_terracotta
fill 221 203 557 221 205 557 minecraft:gold_block
fill 221 203 599 222 307 599 minecraft:gold_block
setblock 222 203 557 minecraft:yellow_terracotta
fill 223 203 557 230 307 557 minecraft:gold_block
setblock 223 203 560 minecraft:light[level=14]
setblock 223 203 568 minecraft:light[level=14]
setblock 223 203 576 minecraft:light[level=14]
setblock 223 203 584 minecraft:light[level=14]
setblock 223 203 592 minecraft:light[level=14]
fill 226 203 599 229 205 599 minecraft:gold_block
setblock 230 203 566 minecraft:yellow_terracotta
fill 230 203 567 230 307 567 minecraft:gold_block
setblock 230 203 568 minecraft:yellow_terracotta
fill 230 203 569 230 205 571 minecraft:gold_block
fill 230 203 573 230 205 573 minecraft:gold_block
setblock 230 203 574 minecraft:yellow_terracotta
fill 230 203 575 230 307 578 minecraft:gold_block
setblock 230 203 579 minecraft:yellow_terracotta
fill 230 203 580 230 205 584 minecraft:gold_block
fill 230 203 590 230 307 593 minecraft:gold_block
setblock 230 203 594 minecraft:yellow_terracotta
fill 230 203 595 230 205 595 minecraft:gold_block
setblock 230 203 599 minecraft:yellow_terracotta
fill 188 204 565 188 205 565 minecraft:gold_block
fill 188 204 590 188 205 590 minecraft:gold_block
fill 188 204 596 188 307 596 minecraft:gold_block
fill 188 204 599 188 205 599 minecraft:gold_block
fill 190 204 599 190 205 599 minecraft:gold_block
fill 193 204 557 193 307 557 minecraft:gold_block
fill 198 204 599 199 307 599 minecraft:gold_block
fill 204 204 599 204 307 599 minecraft:gold_block
fill 208 204 599 208 307 599 minecraft:gold_block
fill 210 204 557 210 205 557 minecraft:gold_block
fill 216 204 599 216 307 599 minecraft:gold_block
fill 220 204 557 220 205 557 minecraft:gold_block
fill 220 204 599 220 307 599 minecraft:gold_block
fill 222 204 557 222 205 557 minecraft:gold_block
fill 225 204 599 225 205 599 minecraft:gold_block
fill 230 204 566 230 307 566 minecraft:gold_block
fill 230 204 568 230 307 568 minecraft:gold_block
fill 230 204 572 230 205 572 minecraft:gold_block
fill 230 204 574 230 307 574 minecraft:gold_block
fill 230 204 579 230 307 579 minecraft:gold_block
fill 230 204 589 230 307 589 minecraft:gold_block
fill 230 204 594 230 205 594 minecraft:gold_block
fill 230 204 599 230 307 599 minecraft:gold_block
fill 189 205 561 189 205 566 minecraft:yellow_terracotta
fill 189 205 573 189 205 578 minecraft:yellow_terracotta
fill 189 205 585 189 205 590 minecraft:yellow_terracotta
fill 189 205 597 189 205 598 minecraft:yellow_terracotta
fill 190 205 598 193 205 598 minecraft:yellow_terracotta
fill 193 205 558 198 205 558 minecraft:yellow_terracotta
fill 200 205 598 205 205 598 minecraft:yellow_terracotta
fill 205 205 558 210 205 558 minecraft:yellow_terracotta
fill 212 205 598 217 205 598 minecraft:yellow_terracotta
fill 217 205 558 222 205 558 minecraft:yellow_terracotta
fill 224 205 598 229 205 598 minecraft:yellow_terracotta
fill 229 205 558 229 205 563 minecraft:yellow_terracotta
fill 229 205 570 229 205 575 minecraft:yellow_terracotta
fill 229 205 582 229 205 587 minecraft:yellow_terracotta
fill 229 205 594 229 205 597 minecraft:yellow_terracotta
fill 188 206 563 188 211 566 minecraft:ochre_froglight
fill 188 206 567 188 307 574 minecraft:gold_block
fill 188 206 575 188 211 578 minecraft:ochre_froglight
fill 188 206 579 188 307 580 minecraft:gold_block
fill 188 206 582 188 307 586 minecraft:gold_block
fill 188 206 587 188 211 590 minecraft:ochre_froglight
fill 188 206 599 191 211 599 minecraft:ochre_froglight
fill 192 206 599 192 307 599 minecraft:gold_block
fill 194 206 557 194 307 557 minecraft:gold_block
fill 195 206 557 198 211 557 minecraft:ochre_froglight
fill 199 206 557 206 307 557 minecraft:gold_block
fill 200 206 599 203 211 599 minecraft:ochre_froglight
fill 207 206 557 210 211 557 minecraft:ochre_froglight
fill 210 206 599 211 307 599 minecraft:gold_block
fill 212 206 599 215 211 599 minecraft:ochre_froglight
fill 213 206 557 218 307 557 minecraft:gold_block
fill 219 206 557 222 211 557 minecraft:ochre_froglight
fill 223 206 599 223 307 599 minecraft:gold_block
fill 224 206 599 227 211 599 minecraft:ochre_froglight
fill 228 206 599 229 307 599 minecraft:gold_block
fill 230 206 558 230 211 561 minecraft:ochre_froglight
fill 230 206 562 230 307 564 minecraft:gold_block
fill 230 206 569 230 307 569 minecraft:gold_block
fill 230 206 570 230 211 573 minecraft:ochre_froglight
fill 230 206 580 230 307 581 minecraft:gold_block
fill 230 206 582 230 211 585 minecraft:ochre_froglight
fill 230 206 586 230 307 588 minecraft:gold_block
fill 230 206 594 230 211 597 minecraft:ochre_froglight
fill 194 209 559 200 210 559 minecraft:gold_block
setblock 191 211 560 minecraft:light[level=14]
setblock 191 211 568 minecraft:light[level=14]
setblock 191 211 576 minecraft:light[level=14]
setblock 191 211 584 minecraft:light[level=14]
setblock 191 211 592 minecraft:light[level=14]
setblock 199 211 560 minecraft:light[level=14]
setblock 199 211 568 minecraft:light[level=14]
setblock 199 211 576 minecraft:light[level=14]
setblock 199 211 584 minecraft:light[level=14]
setblock 199 211 592 minecraft:light[level=14]
setblock 207 211 560 minecraft:light[level=14]
setblock 207 211 568 minecraft:light[level=14]
setblock 207 211 576 minecraft:light[level=14]
setblock 207 211 584 minecraft:light[level=14]
setblock 207 211 592 minecraft:light[level=14]
setblock 215 211 560 minecraft:light[level=14]
setblock 215 211 568 minecraft:light[level=14]
setblock 215 211 576 minecraft:light[level=14]
setblock 215 211 584 minecraft:light[level=14]
setblock 215 211 592 minecraft:light[level=14]
setblock 223 211 560 minecraft:light[level=14]
setblock 223 211 568 minecraft:light[level=14]
setblock 223 211 576 minecraft:light[level=14]
setblock 223 211 584 minecraft:light[level=14]
setblock 223 211 592 minecraft:light[level=14]
fill 188 212 563 188 230 563 minecraft:gold_block
fill 188 212 564 188 212 565 minecraft:ochre_froglight
fill 188 212 566 188 230 566 minecraft:gold_block
fill 188 212 575 188 230 575 minecraft:gold_block
fill 188 212 576 188 212 577 minecraft:ochre_froglight
fill 188 212 578 188 230 578 minecraft:gold_block
fill 188 212 587 188 230 587 minecraft:gold_block
fill 188 212 588 188 212 589 minecraft:ochre_froglight
fill 188 212 590 188 230 590 minecraft:gold_block
fill 188 212 599 188 230 599 minecraft:gold_block
fill 189 212 599 190 212 599 minecraft:ochre_froglight
fill 191 212 599 191 230 599 minecraft:gold_block
fill 195 212 557 195 230 557 minecraft:gold_block
fill 196 212 557 197 212 557 minecraft:ochre_froglight
fill 198 212 557 198 230 557 minecraft:gold_block
fill 200 212 599 200 230 599 minecraft:gold_block
fill 201 212 599 202 212 599 minecraft:ochre_froglight
fill 203 212 599 203 230 599 minecraft:gold_block
fill 207 212 557 207 230 557 minecraft:gold_block
fill 208 212 557 209 212 557 minecraft:ochre_froglight
fill 210 212 557 210 230 557 minecraft:gold_block
fill 212 212 599 212 230 599 minecraft:gold_block
fill 213 212 599 214 212 599 minecraft:ochre_froglight
fill 215 212 599 215 230 599 minecraft:gold_block
fill 219 212 557 219 230 557 minecraft:gold_block
fill 220 212 557 221 212 557 minecraft:ochre_froglight
fill 222 212 557 222 230 557 minecraft:gold_block
fill 224 212 599 224 230 599 minecraft:gold_block
fill 225 212 599 226 212 599 minecraft:ochre_froglight
fill 227 212 599 227 230 599 minecraft:gold_block
fill 230 212 558 230 230 558 minecraft:gold_block
fill 230 212 559 230 212 560 minecraft:ochre_froglight
fill 230 212 561 230 230 561 minecraft:gold_block
fill 230 212 570 230 230 570 minecraft:gold_block
fill 230 212 571 230 212 572 minecraft:ochre_froglight
fill 230 212 573 230 230 573 minecraft:gold_block
fill 230 212 582 230 230 582 minecraft:gold_block
fill 230 212 583 230 212 584 minecraft:ochre_froglight
fill 230 212 585 230 230 585 minecraft:gold_block
fill 230 212 594 230 230 594 minecraft:gold_block
fill 230 212 595 230 212 596 minecraft:ochre_froglight
fill 230 212 597 230 230 597 minecraft:gold_block
fill 188 213 564 188 230 565 minecraft:gold_block
fill 188 213 576 188 230 577 minecraft:gold_block
fill 188 213 588 188 230 589 minecraft:gold_block
fill 189 213 599 190 230 599 minecraft:gold_block
fill 196 213 557 197 230 557 minecraft:gold_block
fill 201 213 599 202 230 599 minecraft:gold_block
fill 205 213 568 206 214 569 minecraft:raw_gold_block
fill 208 213 557 209 230 557 minecraft:gold_block
fill 213 213 599 214 230 599 minecraft:gold_block
fill 220 213 557 221 230 557 minecraft:gold_block
fill 225 213 599 226 230 599 minecraft:gold_block
fill 230 213 559 230 230 560 minecraft:gold_block
fill 230 213 571 230 230 572 minecraft:gold_block
fill 230 213 583 230 230 584 minecraft:gold_block
fill 230 213 595 230 230 596 minecraft:gold_block
setblock 191 219 560 minecraft:light[level=14]
setblock 191 219 568 minecraft:light[level=14]
setblock 191 219 576 minecraft:light[level=14]
setblock 191 219 584 minecraft:light[level=14]
setblock 191 219 592 minecraft:light[level=14]
setblock 199 219 560 minecraft:light[level=14]
setblock 199 219 568 minecraft:light[level=14]
setblock 199 219 576 minecraft:light[level=14]
setblock 199 219 584 minecraft:light[level=14]
setblock 199 219 592 minecraft:light[level=14]
setblock 207 219 560 minecraft:light[level=14]
setblock 207 219 568 minecraft:light[level=14]
setblock 207 219 576 minecraft:light[level=14]
setblock 207 219 584 minecraft:light[level=14]
setblock 207 219 592 minecraft:light[level=14]
setblock 215 219 560 minecraft:light[level=14]
setblock 215 219 568 minecraft:light[level=14]
setblock 215 219 576 minecraft:light[level=14]
setblock 215 219 584 minecraft:light[level=14]
setblock 215 219 592 minecraft:light[level=14]
setblock 223 219 560 minecraft:light[level=14]
setblock 223 219 568 minecraft:light[level=14]
setblock 223 219 576 minecraft:light[level=14]
setblock 223 219 584 minecraft:light[level=14]
setblock 223 219 592 minecraft:light[level=14]
fill 190 220 567 190 220 569 minecraft:quartz_block
fill 190 220 579 190 220 581 minecraft:quartz_block
fill 190 220 591 190 220 593 minecraft:quartz_block
fill 196 220 597 198 220 597 minecraft:quartz_block
fill 200 220 559 202 220 559 minecraft:quartz_block
fill 208 220 597 210 220 597 minecraft:quartz_block
fill 212 220 559 214 220 559 minecraft:quartz_block
fill 220 220 597 222 220 597 minecraft:quartz_block
fill 224 220 559 226 220 559 minecraft:quartz_block
fill 228 220 567 228 220 569 minecraft:quartz_block
fill 228 220 579 228 220 581 minecraft:quartz_block
fill 228 220 591 228 220 593 minecraft:quartz_block
fill 205 225 580 207 225 582 minecraft:redstone_block
fill 209 225 572 211 225 574 minecraft:redstone_block
fill 212 225 581 214 225 583 minecraft:redstone_block
fill 189 226 558 189 226 561 minecraft:red_wool
fill 189 226 562 189 226 565 minecraft:gold_block
fill 189 226 566 189 226 569 minecraft:red_wool
fill 189 226 570 189 226 573 minecraft:gold_block
fill 189 226 574 189 226 577 minecraft:red_wool
fill 189 226 578 189 226 581 minecraft:gold_block
fill 189 226 582 189 226 585 minecraft:red_wool
fill 189 226 586 189 226 589 minecraft:gold_block
fill 189 226 590 189 226 593 minecraft:red_wool
fill 189 226 594 189 226 597 minecraft:gold_block
setblock 189 226 598 minecraft:red_wool
fill 190 226 558 193 226 561 minecraft:gold_block
fill 190 226 562 193 226 565 minecraft:red_wool
fill 190 226 566 193 226 569 minecraft:gold_block
fill 190 226 570 193 226 573 minecraft:red_wool
fill 190 226 574 193 226 577 minecraft:gold_block
fill 190 226 578 193 226 581 minecraft:red_wool
fill 190 226 582 193 226 585 minecraft:gold_block
fill 190 226 586 193 226 589 minecraft:red_wool
fill 190 226 590 193 226 593 minecraft:gold_block
fill 190 226 594 193 226 597 minecraft:red_wool
fill 190 226 598 193 226 598 minecraft:gold_block
fill 194 226 558 197 226 561 minecraft:red_wool
fill 194 226 562 197 226 565 minecraft:gold_block
fill 194 226 566 197 226 569 minecraft:red_wool
fill 194 226 570 197 226 573 minecraft:gold_block
fill 194 226 574 197 226 577 minecraft:red_wool
fill 194 226 578 197 226 581 minecraft:gold_block
fill 194 226 582 197 226 585 minecraft:red_wool
fill 194 226 586 197 226 589 minecraft:gold_block
fill 194 226 590 197 226 593 minecraft:red_wool
fill 194 226 594 197 226 597 minecraft:gold_block
fill 194 226 598 197 226 598 minecraft:red_wool
fill 198 226 558 201 226 561 minecraft:gold_block
fill 198 226 562 201 226 565 minecraft:red_wool
fill 198 226 566 201 226 569 minecraft:gold_block
fill 198 226 570 201 226 573 minecraft:red_wool
fill 198 226 574 201 226 577 minecraft:gold_block
fill 198 226 578 201 226 581 minecraft:red_wool
fill 198 226 582 201 226 585 minecraft:gold_block
fill 198 226 586 201 226 589 minecraft:red_wool
fill 198 226 590 201 226 593 minecraft:gold_block
fill 198 226 594 201 226 597 minecraft:red_wool
fill 198 226 598 201 226 598 minecraft:gold_block
fill 202 226 558 205 226 561 minecraft:red_wool
fill 202 226 562 205 226 565 minecraft:gold_block
fill 202 226 566 205 226 569 minecraft:red_wool
fill 202 226 570 205 226 573 minecraft:gold_block
fill 202 226 574 205 226 577 minecraft:red_wool
fill 202 226 578 204 226 581 minecraft:gold_block
fill 202 226 582 204 226 585 minecraft:red_wool
fill 202 226 586 205 226 589 minecraft:gold_block
fill 202 226 590 205 226 593 minecraft:red_wool
fill 202 226 594 205 226 597 minecraft:gold_block
fill 202 226 598 205 226 598 minecraft:red_wool
fill 205 226 578 205 226 579 minecraft:gold_block
fill 205 226 583 205 226 585 minecraft:red_wool
fill 206 226 558 209 226 561 minecraft:gold_block
fill 206 226 562 209 226 565 minecraft:red_wool
fill 206 226 566 209 226 569 minecraft:gold_block
fill 206 226 570 208 226 573 minecraft:red_wool
fill 206 226 574 208 226 577 minecraft:gold_block
fill 206 226 578 208 226 579 minecraft:red_wool
fill 206 226 583 209 226 585 minecraft:gold_block
fill 206 226 586 209 226 589 minecraft:red_wool
fill 206 226 590 209 226 593 minecraft:gold_block
fill 206 226 594 209 226 597 minecraft:red_wool
fill 206 226 598 209 226 598 minecraft:gold_block
fill 208 226 580 209 226 581 minecraft:red_wool
fill 208 226 582 209 226 582 minecraft:gold_block
fill 209 226 570 209 226 571 minecraft:red_wool
fill 209 226 575 209 226 576 minecraft:gold_block
fill 210 226 558 213 226 561 minecraft:red_wool
fill 210 226 562 213 226 565 minecraft:gold_block
fill 210 226 566 213 226 569 minecraft:red_wool
fill 210 226 570 213 226 571 minecraft:gold_block
fill 210 226 575 213 226 576 minecraft:red_wool
fill 210 226 580 211 226 581 minecraft:gold_block
fill 210 226 582 211 226 585 minecraft:red_wool
fill 210 226 586 213 226 589 minecraft:gold_block
fill 210 226 590 213 226 593 minecraft:red_wool
fill 210 226 594 213 226 597 minecraft:gold_block
fill 210 226 598 213 226 598 minecraft:red_wool
fill 212 226 572 213 226 573 minecraft:gold_block
fill 212 226 574 213 226 574 minecraft:red_wool
fill 212 226 577 213 226 577 minecraft:red_wool
fill 212 226 578 213 226 580 minecraft:gold_block
fill 212 226 584 213 226 585 minecraft:red_wool
fill 214 226 558 217 226 561 minecraft:gold_block
fill 214 226 562 217 226 565 minecraft:red_wool
fill 214 226 566 217 226 569 minecraft:gold_block
fill 214 226 570 217 226 573 minecraft:red_wool
fill 214 226 574 217 226 577 minecraft:gold_block
fill 214 226 578 217 226 580 minecraft:red_wool
fill 214 226 584 217 226 585 minecraft:gold_block
fill 214 226 586 217 226 589 minecraft:red_wool
fill 214 226 590 217 226 593 minecraft:gold_block
fill 214 226 594 217 226 597 minecraft:red_wool
fill 214 226 598 217 226 598 minecraft:gold_block
fill 215 226 581 217 226 581 minecraft:red_wool
fill 215 226 582 217 226 583 minecraft:gold_block
fill 218 226 558 221 226 561 minecraft:red_wool
fill 218 226 562 221 226 565 minecraft:gold_block
fill 218 226 566 221 226 569 minecraft:red_wool
fill 218 226 570 221 226 573 minecraft:gold_block
fill 218 226 574 221 226 577 minecraft:red_wool
fill 218 226 578 221 226 581 minecraft:gold_block
fill 218 226 582 221 226 585 minecraft:red_wool
fill 218 226 586 221 226 589 minecraft:gold_block
fill 218 226 590 221 226 593 minecraft:red_wool
fill 218 226 594 221 226 597 minecraft:gold_block
fill 218 226 598 221 226 598 minecraft:red_wool
fill 222 226 558 225 226 561 minecraft:gold_block
fill 222 226 562 225 226 565 minecraft:red_wool
fill 222 226 566 225 226 569 minecraft:gold_block
fill 222 226 570 225 226 573 minecraft:red_wool
fill 222 226 574 225 226 577 minecraft:gold_block
fill 222 226 578 225 226 581 minecraft:red_wool
fill 222 226 582 225 226 585 minecraft:gold_block
fill 222 226 586 225 226 589 minecraft:red_wool
fill 222 226 590 225 226 593 minecraft:gold_block
fill 222 226 594 225 226 597 minecraft:red_wool
fill 222 226 598 225 226 598 minecraft:gold_block
fill 226 226 558 229 226 561 minecraft:red_wool
fill 226 226 562 229 226 565 minecraft:gold_block
fill 226 226 566 229 226 569 minecraft:red_wool
fill 226 226 570 229 226 573 minecraft:gold_block
fill 226 226 574 229 226 577 minecraft:red_wool
fill 226 226 578 229 226 581 minecraft:gold_block
fill 226 226 582 229 226 585 minecraft:red_wool
fill 226 226 586 229 226 589 minecraft:gold_block
fill 226 226 590 229 226 593 minecraft:red_wool
fill 226 226 594 229 226 597 minecraft:gold_block
fill 226 226 598 229 226 598 minecraft:red_wool
fill 189 227 558 229 227 558 minecraft:quartz_block
fill 189 227 559 189 227 561 minecraft:red_wool
fill 189 227 562 229 227 562 minecraft:quartz_block
fill 189 227 563 189 227 565 minecraft:gold_block
fill 189 227 566 229 227 566 minecraft:quartz_block
fill 189 227 567 189 227 569 minecraft:red_wool
fill 189 227 570 229 227 570 minecraft:quartz_block
fill 189 227 571 189 227 573 minecraft:gold_block
fill 189 227 574 207 227 574 minecraft:quartz_block
fill 189 227 575 189 227 577 minecraft:red_wool
fill 189 227 578 207 227 578 minecraft:quartz_block
fill 189 227 579 189 227 581 minecraft:gold_block
fill 189 227 582 203 227 582 minecraft:quartz_block
fill 189 227 583 189 227 585 minecraft:red_wool
fill 189 227 586 229 227 586 minecraft:quartz_block
fill 189 227 587 189 227 589 minecraft:gold_block
fill 189 227 590 229 227 590 minecraft:quartz_block
fill 189 227 591 189 227 593 minecraft:red_wool
fill 189 227 594 229 227 594 minecraft:quartz_block
fill 189 227 595 189 227 597 minecraft:gold_block
fill 189 227 598 229 227 598 minecraft:quartz_block
fill 190 227 559 190 227 561 minecraft:quartz_block
fill 190 227 563 190 227 565 minecraft:quartz_block
fill 190 227 567 190 227 569 minecraft:quartz_block
fill 190 227 571 190 227 573 minecraft:quartz_block
fill 190 227 575 190 227 577 minecraft:quartz_block
fill 190 227 579 190 227 581 minecraft:quartz_block
fill 190 227 583 190 227 585 minecraft:quartz_block
fill 190 227 587 190 227 589 minecraft:quartz_block
fill 190 227 591 190 227 593 minecraft:quartz_block
fill 190 227 595 190 227 597 minecraft:quartz_block
fill 191 227 559 193 227 561 minecraft:gold_block
fill 191 227 563 193 227 565 minecraft:red_wool
fill 191 227 567 193 227 569 minecraft:gold_block
fill 191 227 571 193 227 573 minecraft:red_wool
fill 191 227 575 193 227 577 minecraft:gold_block
fill 191 227 579 193 227 581 minecraft:red_wool
fill 191 227 583 193 227 585 minecraft:gold_block
fill 191 227 587 193 227 589 minecraft:red_wool
fill 191 227 591 193 227 593 minecraft:gold_block
fill 191 227 595 193 227 597 minecraft:red_wool
fill 194 227 559 194 227 561 minecraft:quartz_block
fill 194 227 563 194 227 565 minecraft:quartz_block
fill 194 227 567 194 227 569 minecraft:quartz_block
fill 194 227 571 194 227 573 minecraft:quartz_block
fill 194 227 575 194 227 577 minecraft:quartz_block
fill 194 227 579 194 227 581 minecraft:quartz_block
fill 194 227 583 194 227 585 minecraft:quartz_block
fill 194 227 587 194 227 589 minecraft:quartz_block
fill 194 227 591 194 227 593 minecraft:quartz_block
fill 194 227 595 194 227 597 minecraft:quartz_block
fill 195 227 559 197 227 561 minecraft:red_wool
fill 195 227 563 197 227 565 minecraft:gold_block
fill 195 227 567 197 227 569 minecraft:red_wool
fill 195 227 571 197 227 573 minecraft:gold_block
fill 195 227 575 197 227 577 minecraft:red_wool
fill 195 227 579 197 227 581 minecraft:gold_block
fill 195 227 583 197 227 585 minecraft:red_wool
fill 195 227 587 197 227 589 minecraft:gold_block
fill 195 227 591 197 227 593 minecraft:red_wool
fill 195 227 595 197 227 597 minecraft:gold_block
fill 198 227 559 198 227 561 minecraft:quartz_block
fill 198 227 563 198 227 565 minecraft:quartz_block
fill 198 227 567 198 227 569 minecraft:quartz_block
fill 198 227 571 198 227 573 minecraft:quartz_block
fill 198 227 575 198 227 577 minecraft:quartz_block
fill 198 227 579 198 227 581 minecraft:quartz_block
fill 198 227 583 198 227 585 minecraft:quartz_block
fill 198 227 587 198 227 589 minecraft:quartz_block
fill 198 227 591 198 227 593 minecraft:quartz_block
fill 198 227 595 198 227 597 minecraft:quartz_block
fill 199 227 559 201 227 561 minecraft:gold_block
fill 199 227 563 201 227 565 minecraft:red_wool
fill 199 227 567 201 227 569 minecraft:gold_block
fill 199 227 571 201 227 573 minecraft:red_wool
fill 199 227 575 201 227 577 minecraft:gold_block
fill 199 227 579 201 227 581 minecraft:red_wool
fill 199 227 583 201 227 585 minecraft:gold_block
fill 199 227 587 201 227 589 minecraft:red_wool
fill 199 227 591 201 227 593 minecraft:gold_block
fill 199 227 595 201 227 597 minecraft:red_wool
fill 202 227 559 202 227 561 minecraft:quartz_block
fill 202 227 563 202 227 565 minecraft:quartz_block
fill 202 227 567 202 227 569 minecraft:quartz_block
fill 202 227 571 202 227 573 minecraft:quartz_block
fill 202 227 575 202 227 577 minecraft:quartz_block
fill 202 227 579 202 227 581 minecraft:quartz_block
fill 202 227 583 202 227 585 minecraft:quartz_block
fill 202 227 587 202 227 589 minecraft:quartz_block
fill 202 227 591 202 227 593 minecraft:quartz_block
fill 202 227 595 202 227 597 minecraft:quartz_block
fill 203 227 559 205 227 561 minecraft:red_wool
fill 203 227 563 205 227 565 minecraft:gold_block
fill 203 227 567 205 227 569 minecraft:red_wool
fill 203 227 571 205 227 573 minecraft:gold_block
fill 203 227 575 205 227 577 minecraft:red_wool
fill 203 227 579 203 227 581 minecraft:gold_block
fill 203 227 583 203 227 585 minecraft:red_wool
fill 203 227 587 205 227 589 minecraft:gold_block
fill 203 227 591 205 227 593 minecraft:red_wool
fill 203 227 595 205 227 597 minecraft:gold_block
fill 204 227 579 204 227 583 minecraft:ochre_froglight
fill 204 227 584 205 227 585 minecraft:red_wool
fill 205 227 579 208 227 579 minecraft:ochre_froglight
fill 205 227 580 207 227 582 minecraft:quartz_block
fill 205 227 583 208 227 583 minecraft:ochre_froglight
fill 206 227 559 206 227 561 minecraft:quartz_block
fill 206 227 563 206 227 565 minecraft:quartz_block
fill 206 227 567 206 227 569 minecraft:quartz_block
fill 206 227 571 206 227 573 minecraft:quartz_block
fill 206 227 575 206 227 577 minecraft:quartz_block
fill 206 227 584 206 227 585 minecraft:quartz_block
fill 206 227 587 206 227 589 minecraft:quartz_block
fill 206 227 591 206 227 593 minecraft:quartz_block
fill 206 227 595 206 227 597 minecraft:quartz_block
fill 207 227 559 209 227 561 minecraft:gold_block
fill 207 227 563 209 227 565 minecraft:red_wool
fill 207 227 567 209 227 569 minecraft:gold_block
fill 207 227 571 207 227 573 minecraft:red_wool
fill 207 227 575 207 227 577 minecraft:gold_block
fill 207 227 584 209 227 585 minecraft:gold_block
fill 207 227 587 209 227 589 minecraft:red_wool
fill 207 227 591 209 227 593 minecraft:gold_block
fill 207 227 595 209 227 597 minecraft:red_wool
fill 208 227 571 208 227 578 minecraft:ochre_froglight
fill 208 227 580 208 227 582 minecraft:ochre_froglight
fill 209 227 571 212 227 571 minecraft:ochre_froglight
fill 209 227 572 211 227 574 minecraft:quartz_block
fill 209 227 575 212 227 576 minecraft:ochre_froglight
fill 209 227 580 215 227 580 minecraft:ochre_froglight
setblock 209 227 581 minecraft:red_wool
fill 209 227 582 210 227 582 minecraft:quartz_block
setblock 209 227 583 minecraft:gold_block
fill 210 227 559 210 227 561 minecraft:quartz_block
fill 210 227 563 210 227 565 minecraft:quartz_block
fill 210 227 567 210 227 569 minecraft:quartz_block
setblock 210 227 581 minecraft:quartz_block
fill 210 227 583 210 227 585 minecraft:quartz_block
fill 210 227 587 210 227 589 minecraft:quartz_block
fill 210 227 591 210 227 593 minecraft:quartz_block
fill 210 227 595 210 227 597 minecraft:quartz_block
fill 211 227 559 213 227 561 minecraft:red_wool
fill 211 227 563 213 227 565 minecraft:gold_block
fill 211 227 567 213 227 569 minecraft:red_wool
fill 211 227 581 211 227 584 minecraft:ochre_froglight
fill 211 227 585 213 227 585 minecraft:red_wool
fill 211 227 587 213 227 589 minecraft:gold_block
fill 211 227 591 213 227 593 minecraft:red_wool
fill 211 227 595 213 227 597 minecraft:gold_block
fill 212 227 572 212 227 574 minecraft:ochre_froglight
fill 212 227 577 212 227 579 minecraft:ochre_froglight
fill 212 227 581 214 227 583 minecraft:quartz_block
fill 212 227 584 215 227 584 minecraft:ochre_froglight
fill 213 227 571 213 227 573 minecraft:gold_block
fill 213 227 574 229 227 574 minecraft:quartz_block
fill 213 227 575 213 227 577 minecraft:red_wool
fill 213 227 578 229 227 578 minecraft:quartz_block
setblock 213 227 579 minecraft:gold_block
fill 214 227 559 214 227 561 minecraft:quartz_block
fill 214 227 563 214 227 565 minecraft:quartz_block
fill 214 227 567 214 227 569 minecraft:quartz_block
fill 214 227 571 214 227 573 minecraft:quartz_block
fill 214 227 575 214 227 577 minecraft:quartz_block
setblock 214 227 579 minecraft:quartz_block
setblock 214 227 585 minecraft:quartz_block
fill 214 227 587 214 227 589 minecraft:quartz_block
fill 214 227 591 214 227 593 minecraft:quartz_block
fill 214 227 595 214 227 597 minecraft:quartz_block
fill 215 227 559 217 227 561 minecraft:gold_block
fill 215 227 563 217 227 565 minecraft:red_wool
fill 215 227 567 217 227 569 minecraft:gold_block
fill 215 227 571 217 227 573 minecraft:red_wool
fill 215 227 575 217 227 577 minecraft:gold_block
fill 215 227 579 217 227 579 minecraft:red_wool
fill 215 227 581 215 227 583 minecraft:ochre_froglight
fill 215 227 585 217 227 585 minecraft:gold_block
fill 215 227 587 217 227 589 minecraft:red_wool
fill 215 227 591 217 227 593 minecraft:gold_block
fill 215 227 595 217 227 597 minecraft:red_wool
fill 216 227 580 217 227 581 minecraft:red_wool
fill 216 227 582 229 227 582 minecraft:quartz_block
fill 216 227 583 217 227 584 minecraft:gold_block
fill 218 227 559 218 227 561 minecraft:quartz_block
fill 218 227 563 218 227 565 minecraft:quartz_block
fill 218 227 567 218 227 569 minecraft:quartz_block
fill 218 227 571 218 227 573 minecraft:quartz_block
fill 218 227 575 218 227 577 minecraft:quartz_block
fill 218 227 579 218 227 581 minecraft:quartz_block
fill 218 227 583 218 227 585 minecraft:quartz_block
fill 218 227 587 218 227 589 minecraft:quartz_block
fill 218 227 591 218 227 593 minecraft:quartz_block
fill 218 227 595 218 227 597 minecraft:quartz_block
fill 219 227 559 221 227 561 minecraft:red_wool
fill 219 227 563 221 227 565 minecraft:gold_block
fill 219 227 567 221 227 569 minecraft:red_wool
fill 219 227 571 221 227 573 minecraft:gold_block
fill 219 227 575 221 227 577 minecraft:red_wool
fill 219 227 579 221 227 581 minecraft:gold_block
fill 219 227 583 221 227 585 minecraft:red_wool
fill 219 227 587 221 227 589 minecraft:gold_block
fill 219 227 591 221 227 593 minecraft:red_wool
fill 219 227 595 221 227 597 minecraft:gold_block
fill 222 227 559 222 227 561 minecraft:quartz_block
fill 222 227 563 222 227 565 minecraft:quartz_block
fill 222 227 567 222 227 569 minecraft:quartz_block
fill 222 227 571 222 227 573 minecraft:quartz_block
fill 222 227 575 222 227 577 minecraft:quartz_block
fill 222 227 579 222 227 581 minecraft:quartz_block
fill 222 227 583 222 227 585 minecraft:quartz_block
fill 222 227 587 222 227 589 minecraft:quartz_block
fill 222 227 591 222 227 593 minecraft:quartz_block
fill 222 227 595 222 227 597 minecraft:quartz_block
fill 223 227 559 225 227 561 minecraft:gold_block
fill 223 227 563 225 227 565 minecraft:red_wool
fill 223 227 567 225 227 569 minecraft:gold_block
fill 223 227 571 225 227 573 minecraft:red_wool
fill 223 227 575 225 227 577 minecraft:gold_block
fill 223 227 579 225 227 581 minecraft:red_wool
fill 223 227 583 225 227 585 minecraft:gold_block
fill 223 227 587 225 227 589 minecraft:red_wool
fill 223 227 591 225 227 593 minecraft:gold_block
fill 223 227 595 225 227 597 minecraft:red_wool
fill 226 227 559 226 227 561 minecraft:quartz_block
fill 226 227 563 226 227 565 minecraft:quartz_block
fill 226 227 567 226 227 569 minecraft:quartz_block
fill 226 227 571 226 227 573 minecraft:quartz_block
fill 226 227 575 226 227 577 minecraft:quartz_block
fill 226 227 579 226 227 581 minecraft:quartz_block
fill 226 227 583 226 227 585 minecraft:quartz_block
fill 226 227 587 226 227 589 minecraft:quartz_block
fill 226 227 591 226 227 593 minecraft:quartz_block
fill 226 227 595 226 227 597 minecraft:quartz_block
fill 227 227 559 229 227 561 minecraft:red_wool
fill 227 227 563 229 227 565 minecraft:gold_block
fill 227 227 567 229 227 569 minecraft:red_wool
fill 227 227 571 229 227 573 minecraft:gold_block
fill 227 227 575 229 227 577 minecraft:red_wool
fill 227 227 579 229 227 581 minecraft:gold_block
fill 227 227 583 229 227 585 minecraft:red_wool
fill 227 227 587 229 227 589 minecraft:gold_block
fill 227 227 591 229 227 593 minecraft:red_wool
fill 227 227 595 229 227 597 minecraft:gold_block
fill 188 231 563 188 231 566 minecraft:ochre_froglight
fill 188 231 575 188 231 578 minecraft:ochre_froglight
fill 188 231 587 188 231 590 minecraft:ochre_froglight
fill 188 231 599 191 231 599 minecraft:ochre_froglight
fill 189 231 558 191 231 565 minecraft:quartz_block
fill 189 231 568 189 273 570 minecraft:quartz_block
fill 189 231 580 189 273 582 minecraft:quartz_block
fill 189 231 589 198 231 595 minecraft:quartz_block
fill 192 231 559 198 231 565 minecraft:quartz_block
fill 195 231 557 198 231 557 minecraft:ochre_froglight
fill 195 231 598 197 273 598 minecraft:quartz_block
fill 200 231 599 203 231 599 minecraft:ochre_froglight
fill 201 231 558 203 273 558 minecraft:quartz_block
fill 205 231 590 211 231 598 minecraft:quartz_block
fill 207 231 557 210 231 557 minecraft:ochre_froglight
fill 212 231 599 215 231 599 minecraft:ochre_froglight
fill 213 231 558 215 273 558 minecraft:quartz_block
fill 216 231 592 226 231 598 minecraft:quartz_block
fill 219 231 557 222 231 557 minecraft:ochre_froglight
fill 222 231 562 222 231 564 minecraft:yellow_terracotta
setblock 223 231 561 minecraft:yellow_terracotta
fill 223 231 562 225 273 564 minecraft:quartz_block
fill 223 231 565 225 231 565 minecraft:yellow_terracotta
fill 224 231 561 224 273 561 minecraft:quartz_block
fill 224 231 599 227 231 599 minecraft:ochre_froglight
fill 225 231 558 227 273 558 minecraft:quartz_block
fill 225 231 561 226 231 561 minecraft:yellow_terracotta
fill 226 231 562 226 231 564 minecraft:yellow_terracotta
fill 229 231 566 229 273 568 minecraft:quartz_block
fill 229 231 578 229 273 580 minecraft:quartz_block
fill 229 231 590 229 273 592 minecraft:quartz_block
fill 230 231 558 230 231 561 minecraft:ochre_froglight
fill 230 231 570 230 231 573 minecraft:ochre_froglight
fill 230 231 582 230 231 585 minecraft:ochre_froglight
fill 230 231 594 230 231 597 minecraft:ochre_froglight
fill 188 232 563 188 245 563 minecraft:gold_block
fill 188 232 564 188 232 565 minecraft:ochre_froglight
fill 188 232 566 188 245 566 minecraft:gold_block
fill 188 232 575 188 245 575 minecraft:gold_block
fill 188 232 576 188 232 577 minecraft:ochre_froglight
fill 188 232 578 188 245 578 minecraft:gold_block
fill 188 232 587 188 245 587 minecraft:gold_block
fill 188 232 588 188 232 589 minecraft:ochre_froglight
fill 188 232 590 188 245 590 minecraft:gold_block
fill 188 232 599 188 245 599 minecraft:gold_block
fill 189 232 558 189 257 559 minecraft:quartz_block
setblock 189 232 560 minecraft:ochre_froglight
fill 189 232 561 189 244 561 minecraft:quartz_block
setblock 189 232 562 minecraft:ochre_froglight
fill 189 232 563 189 244 563 minecraft:quartz_block
setblock 189 232 564 minecraft:ochre_froglight
fill 189 232 565 189 244 565 minecraft:quartz_block
fill 189 232 589 189 244 589 minecraft:quartz_block
setblock 189 232 590 minecraft:ochre_froglight
fill 189 232 591 189 247 591 minecraft:quartz_block
setblock 189 232 592 minecraft:ochre_froglight
fill 189 232 593 189 273 593 minecraft:quartz_block
setblock 189 232 594 minecraft:ochre_froglight
fill 189 232 595 189 247 595 minecraft:quartz_block
fill 189 232 599 190 232 599 minecraft:ochre_froglight
fill 190 232 558 191 273 558 minecraft:quartz_block
setblock 190 232 559 minecraft:ochre_froglight
fill 190 232 560 190 257 560 minecraft:quartz_block
setblock 190 232 561 minecraft:ochre_froglight
fill 190 232 562 190 257 562 minecraft:quartz_block
setblock 190 232 563 minecraft:ochre_froglight
fill 190 232 564 190 257 564 minecraft:quartz_block
setblock 190 232 565 minecraft:ochre_froglight
setblock 190 232 589 minecraft:ochre_froglight
fill 190 232 590 190 247 590 minecraft:quartz_block
setblock 190 232 591 minecraft:ochre_froglight
fill 190 232 592 190 247 592 minecraft:quartz_block
setblock 190 232 593 minecraft:ochre_froglight
fill 190 232 594 190 247 594 minecraft:quartz_block
setblock 190 232 595 minecraft:ochre_froglight
fill 191 232 559 191 257 559 minecraft:quartz_block
setblock 191 232 560 minecraft:ochre_froglight
fill 191 232 561 191 257 561 minecraft:quartz_block
setblock 191 232 562 minecraft:ochre_froglight
fill 191 232 563 191 257 563 minecraft:quartz_block
setblock 191 232 564 minecraft:ochre_froglight
fill 191 232 565 191 257 565 minecraft:quartz_block
fill 191 232 589 191 247 589 minecraft:quartz_block
setblock 191 232 590 minecraft:ochre_froglight
fill 191 232 591 191 247 591 minecraft:quartz_block
setblock 191 232 592 minecraft:ochre_froglight
fill 191 232 593 191 247 593 minecraft:quartz_block
setblock 191 232 594 minecraft:ochre_froglight
fill 191 232 595 191 247 595 minecraft:quartz_block
fill 191 232 599 191 245 599 minecraft:gold_block
setblock 192 232 559 minecraft:ochre_froglight
fill 192 232 560 192 257 560 minecraft:quartz_block
setblock 192 232 561 minecraft:ochre_froglight
fill 192 232 562 192 257 562 minecraft:quartz_block
setblock 192 232 563 minecraft:ochre_froglight
fill 192 232 564 192 257 564 minecraft:quartz_block
setblock 192 232 565 minecraft:ochre_froglight
setblock 192 232 589 minecraft:ochre_froglight
fill 192 232 590 192 247 590 minecraft:quartz_block
setblock 192 232 591 minecraft:ochre_froglight
fill 192 232 592 192 247 592 minecraft:quartz_block
setblock 192 232 593 minecraft:ochre_froglight
fill 192 232 594 192 247 594 minecraft:quartz_block
setblock 192 232 595 minecraft:ochre_froglight
fill 193 232 559 193 257 559 minecraft:quartz_block
setblock 193 232 560 minecraft:ochre_froglight
fill 193 232 561 193 257 561 minecraft:quartz_block
setblock 193 232 562 minecraft:ochre_froglight
fill 193 232 563 193 257 563 minecraft:quartz_block
setblock 193 232 564 minecraft:ochre_froglight
fill 193 232 565 193 257 565 minecraft:quartz_block
fill 193 232 589 193 247 589 minecraft:quartz_block
setblock 193 232 590 minecraft:ochre_froglight
fill 193 232 591 193 247 591 minecraft:quartz_block
setblock 193 232 592 minecraft:ochre_froglight
fill 193 232 593 193 247 593 minecraft:quartz_block
setblock 193 232 594 minecraft:ochre_froglight
fill 193 232 595 193 247 595 minecraft:quartz_block
setblock 194 232 559 minecraft:ochre_froglight
fill 194 232 560 194 257 560 minecraft:quartz_block
setblock 194 232 561 minecraft:ochre_froglight
fill 194 232 562 194 257 562 minecraft:quartz_block
setblock 194 232 563 minecraft:ochre_froglight
fill 194 232 564 194 257 564 minecraft:quartz_block
setblock 194 232 565 minecraft:ochre_froglight
setblock 194 232 589 minecraft:ochre_froglight
fill 194 232 590 194 247 590 minecraft:quartz_block
setblock 194 232 591 minecraft:ochre_froglight
fill 194 232 592 194 247 592 minecraft:quartz_block
setblock 194 232 593 minecraft:ochre_froglight
fill 194 232 594 194 247 594 minecraft:quartz_block
setblock 194 232 595 minecraft:ochre_froglight
fill 195 232 557 195 245 557 minecraft:gold_block
fill 195 232 559 195 257 559 minecraft:quartz_block
setblock 195 232 560 minecraft:ochre_froglight
fill 195 232 561 195 257 561 minecraft:quartz_block
setblock 195 232 562 minecraft:ochre_froglight
fill 195 232 563 195 257 563 minecraft:quartz_block
setblock 195 232 564 minecraft:ochre_froglight
fill 195 232 565 195 257 565 minecraft:quartz_block
fill 195 232 589 195 247 589 minecraft:quartz_block
setblock 195 232 590 minecraft:ochre_froglight
fill 195 232 591 195 247 591 minecraft:quartz_block
setblock 195 232 592 minecraft:ochre_froglight
fill 195 232 593 195 247 593 minecraft:quartz_block
setblock 195 232 594 minecraft:ochre_froglight
fill 195 232 595 195 247 595 minecraft:quartz_block
fill 196 232 557 197 232 557 minecraft:ochre_froglight
setblock 196 232 559 minecraft:ochre_froglight
fill 196 232 560 196 257 560 minecraft:quartz_block
setblock 196 232 561 minecraft:ochre_froglight
fill 196 232 562 196 257 562 minecraft:quartz_block
setblock 196 232 563 minecraft:ochre_froglight
fill 196 232 564 196 257 564 minecraft:quartz_block
setblock 196 232 565 minecraft:ochre_froglight
setblock 196 232 589 minecraft:ochre_froglight
fill 196 232 590 196 247 590 minecraft:quartz_block
setblock 196 232 591 minecraft:ochre_froglight
fill 196 232 592 196 247 592 minecraft:quartz_block
setblock 196 232 593 minecraft:ochre_froglight
fill 196 232 594 196 247 594 minecraft:quartz_block
setblock 196 232 595 minecraft:ochre_froglight
fill 197 232 559 197 257 559 minecraft:quartz_block
setblock 197 232 560 minecraft:ochre_froglight
fill 197 232 561 197 257 561 minecraft:quartz_block
setblock 197 232 562 minecraft:ochre_froglight
fill 197 232 563 197 257 563 minecraft:quartz_block
setblock 197 232 564 minecraft:ochre_froglight
fill 197 232 565 197 257 565 minecraft:quartz_block
fill 197 232 589 197 247 589 minecraft:quartz_block
setblock 197 232 590 minecraft:ochre_froglight
fill 197 232 591 197 247 591 minecraft:quartz_block
setblock 197 232 592 minecraft:ochre_froglight
fill 197 232 593 197 247 593 minecraft:quartz_block
setblock 197 232 594 minecraft:ochre_froglight
fill 197 232 595 197 247 595 minecraft:quartz_block
fill 198 232 557 198 245 557 minecraft:gold_block
setblock 198 232 559 minecraft:ochre_froglight
fill 198 232 560 198 257 560 minecraft:quartz_block
setblock 198 232 561 minecraft:ochre_froglight
fill 198 232 562 198 257 562 minecraft:quartz_block
setblock 198 232 563 minecraft:ochre_froglight
fill 198 232 564 198 257 564 minecraft:quartz_block
setblock 198 232 565 minecraft:ochre_froglight
setblock 198 232 589 minecraft:ochre_froglight
fill 198 232 590 198 247 590 minecraft:quartz_block
setblock 198 232 591 minecraft:ochre_froglight
fill 198 232 592 198 247 592 minecraft:quartz_block
setblock 198 232 593 minecraft:ochre_froglight
fill 198 232 594 198 247 594 minecraft:quartz_block
setblock 198 232 595 minecraft:ochre_froglight
fill 200 232 599 200 245 599 minecraft:gold_block
fill 201 232 599 202 232 599 minecraft:ochre_froglight
fill 203 232 599 203 245 599 minecraft:gold_block
setblock 205 232 590 minecraft:ochre_froglight
fill 205 232 591 205 252 591 minecraft:quartz_block
setblock 205 232 592 minecraft:ochre_froglight
fill 205 232 593 205 252 593 minecraft:quartz_block
setblock 205 232 594 minecraft:ochre_froglight
fill 205 232 595 205 252 595 minecraft:quartz_block
setblock 205 232 596 minecraft:ochre_froglight
fill 205 232 597 205 252 597 minecraft:quartz_block
setblock 205 232 598 minecraft:ochre_froglight
fill 206 232 590 206 252 590 minecraft:quartz_block
setblock 206 232 591 minecraft:ochre_froglight
fill 206 232 592 206 252 592 minecraft:quartz_block
setblock 206 232 593 minecraft:ochre_froglight
fill 206 232 594 206 252 594 minecraft:quartz_block
setblock 206 232 595 minecraft:ochre_froglight
fill 206 232 596 206 252 596 minecraft:quartz_block
setblock 206 232 597 minecraft:ochre_froglight
fill 206 232 598 206 252 598 minecraft:quartz_block
fill 207 232 557 207 245 557 minecraft:gold_block
setblock 207 232 590 minecraft:ochre_froglight
fill 207 232 591 207 252 591 minecraft:quartz_block
setblock 207 232 592 minecraft:ochre_froglight
fill 207 232 593 207 252 593 minecraft:quartz_block
setblock 207 232 594 minecraft:ochre_froglight
fill 207 232 595 207 252 595 minecraft:quartz_block
setblock 207 232 596 minecraft:ochre_froglight
fill 207 232 597 207 252 597 minecraft:quartz_block
setblock 207 232 598 minecraft:ochre_froglight
fill 208 232 557 209 232 557 minecraft:ochre_froglight
fill 208 232 590 208 252 590 minecraft:quartz_block
setblock 208 232 591 minecraft:ochre_froglight
fill 208 232 592 208 252 592 minecraft:quartz_block
setblock 208 232 593 minecraft:ochre_froglight
fill 208 232 594 208 252 594 minecraft:quartz_block
setblock 208 232 595 minecraft:ochre_froglight
fill 208 232 596 208 252 596 minecraft:quartz_block
setblock 208 232 597 minecraft:ochre_froglight
fill 208 232 598 208 273 598 minecraft:quartz_block
setblock 209 232 590 minecraft:ochre_froglight
fill 209 232 591 209 252 591 minecraft:quartz_block
setblock 209 232 592 minecraft:ochre_froglight
fill 209 232 593 209 252 593 minecraft:quartz_block
setblock 209 232 594 minecraft:ochre_froglight
fill 209 232 595 209 252 595 minecraft:quartz_block
setblock 209 232 596 minecraft:ochre_froglight
fill 209 232 597 209 252 597 minecraft:quartz_block
setblock 209 232 598 minecraft:ochre_froglight
fill 210 232 557 210 245 557 minecraft:gold_block
fill 210 232 590 210 252 590 minecraft:quartz_block
setblock 210 232 591 minecraft:ochre_froglight
fill 210 232 592 210 252 592 minecraft:quartz_block
setblock 210 232 593 minecraft:ochre_froglight
fill 210 232 594 210 252 594 minecraft:quartz_block
setblock 210 232 595 minecraft:ochre_froglight
fill 210 232 596 210 252 596 minecraft:quartz_block
setblock 210 232 597 minecraft:ochre_froglight
fill 210 232 598 210 252 598 minecraft:quartz_block
setblock 211 232 590 minecraft:ochre_froglight
fill 211 232 591 211 252 591 minecraft:quartz_block
setblock 211 232 592 minecraft:ochre_froglight
fill 211 232 593 211 252 593 minecraft:quartz_block
setblock 211 232 594 minecraft:ochre_froglight
fill 211 232 595 211 252 595 minecraft:quartz_block
setblock 211 232 596 minecraft:ochre_froglight
fill 211 232 597 211 252 597 minecraft:quartz_block
setblock 211 232 598 minecraft:ochre_froglight
fill 212 232 599 212 245 599 minecraft:gold_block
fill 213 232 599 214 232 599 minecraft:ochre_froglight
fill 215 232 599 215 245 599 minecraft:gold_block
fill 216 232 592 216 243 592 minecraft:quartz_block
setblock 216 232 593 minecraft:ochre_froglight
fill 216 232 594 216 243 594 minecraft:quartz_block
setblock 216 232 595 minecraft:ochre_froglight
fill 216 232 596 216 243 596 minecraft:quartz_block
setblock 216 232 597 minecraft:ochre_froglight
fill 216 232 598 216 243 598 minecraft:quartz_block
setblock 217 232 592 minecraft:ochre_froglight
fill 217 232 593 217 243 593 minecraft:quartz_block
setblock 217 232 594 minecraft:ochre_froglight
fill 217 232 595 217 243 595 minecraft:quartz_block
setblock 217 232 596 minecraft:ochre_froglight
fill 217 232 597 217 243 597 minecraft:quartz_block
setblock 217 232 598 minecraft:ochre_froglight
fill 218 232 592 218 243 592 minecraft:quartz_block
setblock 218 232 593 minecraft:ochre_froglight
fill 218 232 594 218 243 594 minecraft:quartz_block
setblock 218 232 595 minecraft:ochre_froglight
fill 218 232 596 218 243 596 minecraft:quartz_block
setblock 218 232 597 minecraft:ochre_froglight
fill 218 232 598 218 243 598 minecraft:quartz_block
fill 219 232 557 219 245 557 minecraft:gold_block
setblock 219 232 592 minecraft:ochre_froglight
fill 219 232 593 219 243 593 minecraft:quartz_block
setblock 219 232 594 minecraft:ochre_froglight
fill 219 232 595 219 243 595 minecraft:quartz_block
setblock 219 232 596 minecraft:ochre_froglight
fill 219 232 597 219 243 597 minecraft:quartz_block
setblock 219 232 598 minecraft:ochre_froglight
fill 220 232 557 221 232 557 minecraft:ochre_froglight
fill 220 232 592 220 243 592 minecraft:quartz_block
setblock 220 232 593 minecraft:ochre_froglight
fill 220 232 594 220 243 594 minecraft:quartz_block
setblock 220 232 595 minecraft:ochre_froglight
fill 220 232 596 220 243 596 minecraft:quartz_block
setblock 220 232 597 minecraft:ochre_froglight
fill 220 232 598 220 273 598 minecraft:quartz_block
setblock 221 232 592 minecraft:ochre_froglight
fill 221 232 593 221 243 593 minecraft:quartz_block
setblock 221 232 594 minecraft:ochre_froglight
fill 221 232 595 221 243 595 minecraft:quartz_block
setblock 221 232 596 minecraft:ochre_froglight
fill 221 232 597 221 245 597 minecraft:quartz_block
setblock 221 232 598 minecraft:ochre_froglight
fill 222 232 557 222 245 557 minecraft:gold_block
fill 222 232 592 222 243 592 minecraft:quartz_block
setblock 222 232 593 minecraft:ochre_froglight
fill 222 232 594 222 243 594 minecraft:quartz_block
setblock 222 232 595 minecraft:ochre_froglight
fill 222 232 596 222 243 596 minecraft:quartz_block
setblock 222 232 597 minecraft:ochre_froglight
fill 222 232 598 222 243 598 minecraft:quartz_block
setblock 223 232 592 minecraft:ochre_froglight
fill 223 232 593 223 243 593 minecraft:quartz_block
setblock 223 232 594 minecraft:ochre_froglight
fill 223 232 595 223 243 595 minecraft:quartz_block
setblock 223 232 596 minecraft:ochre_froglight
fill 223 232 597 223 243 597 minecraft:quartz_block
setblock 223 232 598 minecraft:ochre_froglight
fill 224 232 592 224 243 592 minecraft:quartz_block
setblock 224 232 593 minecraft:ochre_froglight
fill 224 232 594 224 243 594 minecraft:quartz_block
setblock 224 232 595 minecraft:ochre_froglight
fill 224 232 596 224 243 596 minecraft:quartz_block
setblock 224 232 597 minecraft:ochre_froglight
fill 224 232 598 224 243 598 minecraft:quartz_block
fill 224 232 599 224 245 599 minecraft:gold_block
setblock 225 232 592 minecraft:ochre_froglight
fill 225 232 593 225 243 593 minecraft:quartz_block
setblock 225 232 594 minecraft:ochre_froglight
fill 225 232 595 225 243 595 minecraft:quartz_block
setblock 225 232 596 minecraft:ochre_froglight
fill 225 232 597 225 243 597 minecraft:quartz_block
fill 225 232 598 225 232 599 minecraft:ochre_froglight
fill 226 232 592 226 243 592 minecraft:quartz_block
setblock 226 232 593 minecraft:ochre_froglight
fill 226 232 594 226 243 594 minecraft:quartz_block
setblock 226 232 595 minecraft:ochre_froglight
fill 226 232 596 226 243 596 minecraft:quartz_block
setblock 226 232 597 minecraft:ochre_froglight
fill 226 232 598 226 243 598 minecraft:quartz_block
setblock 226 232 599 minecraft:ochre_froglight
fill 227 232 599 227 245 599 minecraft:gold_block
fill 230 232 558 230 245 558 minecraft:gold_block
fill 230 232 559 230 232 560 minecraft:ochre_froglight
fill 230 232 561 230 245 561 minecraft:gold_block
fill 230 232 570 230 245 570 minecraft:gold_block
fill 230 232 571 230 232 572 minecraft:ochre_froglight
fill 230 232 573 230 245 573 minecraft:gold_block
fill 230 232 582 230 245 582 minecraft:gold_block
fill 230 232 583 230 232 584 minecraft:ochre_froglight
fill 230 232 585 230 245 585 minecraft:gold_block
fill 230 232 594 230 245 594 minecraft:gold_block
fill 230 232 595 230 232 596 minecraft:ochre_froglight
fill 230 232 597 230 245 597 minecraft:gold_block
fill 188 233 564 188 245 565 minecraft:gold_block
fill 188 233 576 188 245 577 minecraft:gold_block
fill 188 233 588 188 245 589 minecraft:gold_block
fill 189 233 560 189 234 560 minecraft:quartz_block
fill 189 233 562 189 234 562 minecraft:quartz_block
fill 189 233 564 189 234 564 minecraft:quartz_block
fill 189 233 590 189 234 590 minecraft:quartz_block
fill 189 233 592 189 234 592 minecraft:quartz_block
fill 189 233 594 189 234 594 minecraft:quartz_block
fill 189 233 599 190 245 599 minecraft:gold_block
fill 190 233 559 190 234 559 minecraft:quartz_block
fill 190 233 561 190 234 561 minecraft:quartz_block
fill 190 233 563 190 234 563 minecraft:quartz_block
fill 190 233 565 190 234 565 minecraft:quartz_block
fill 190 233 589 190 234 589 minecraft:quartz_block
fill 190 233 591 190 234 591 minecraft:quartz_block
fill 190 233 593 190 234 593 minecraft:quartz_block
fill 190 233 595 190 234 595 minecraft:quartz_block
fill 191 233 560 191 234 560 minecraft:quartz_block
fill 191 233 562 191 234 562 minecraft:quartz_block
fill 191 233 564 191 234 564 minecraft:quartz_block
fill 191 233 590 191 234 590 minecraft:quartz_block
fill 191 233 592 191 234 592 minecraft:quartz_block
fill 191 233 594 191 234 594 minecraft:quartz_block
fill 192 233 559 192 234 559 minecraft:quartz_block
fill 192 233 561 192 234 561 minecraft:quartz_block
fill 192 233 563 192 234 563 minecraft:quartz_block
fill 192 233 565 192 234 565 minecraft:quartz_block
fill 192 233 589 192 234 589 minecraft:quartz_block
fill 192 233 591 192 234 591 minecraft:quartz_block
fill 192 233 593 192 234 593 minecraft:quartz_block
fill 192 233 595 192 234 595 minecraft:quartz_block
fill 193 233 560 193 234 560 minecraft:quartz_block
fill 193 233 562 193 234 562 minecraft:quartz_block
fill 193 233 564 193 234 564 minecraft:quartz_block
fill 193 233 590 193 234 590 minecraft:quartz_block
fill 193 233 592 193 234 592 minecraft:quartz_block
fill 193 233 594 193 234 594 minecraft:quartz_block
fill 194 233 559 194 234 559 minecraft:quartz_block
fill 194 233 561 194 234 561 minecraft:quartz_block
fill 194 233 563 194 234 563 minecraft:quartz_block
fill 194 233 565 194 234 565 minecraft:quartz_block
fill 194 233 589 194 234 589 minecraft:quartz_block
fill 194 233 591 194 234 591 minecraft:quartz_block
fill 194 233 593 194 234 593 minecraft:quartz_block
fill 194 233 595 194 234 595 minecraft:quartz_block
fill 195 233 560 195 234 560 minecraft:quartz_block
fill 195 233 562 195 234 562 minecraft:quartz_block
fill 195 233 564 195 234 564 minecraft:quartz_block
fill 195 233 590 195 234 590 minecraft:quartz_block
fill 195 233 592 195 234 592 minecraft:quartz_block
fill 195 233 594 195 234 594 minecraft:quartz_block
fill 196 233 557 197 245 557 minecraft:gold_block
fill 196 233 559 196 234 559 minecraft:quartz_block
fill 196 233 561 196 234 561 minecraft:quartz_block
fill 196 233 563 196 234 563 minecraft:quartz_block
fill 196 233 565 196 234 565 minecraft:quartz_block
fill 196 233 589 196 234 589 minecraft:quartz_block
fill 196 233 591 196 234 591 minecraft:quartz_block
fill 196 233 593 196 234 593 minecraft:quartz_block
fill 196 233 595 196 234 595 minecraft:quartz_block
fill 197 233 560 197 234 560 minecraft:quartz_block
fill 197 233 562 197 234 562 minecraft:quartz_block
fill 197 233 564 197 234 564 minecraft:quartz_block
fill 197 233 590 197 234 590 minecraft:quartz_block
fill 197 233 592 197 234 592 minecraft:quartz_block
fill 197 233 594 197 234 594 minecraft:quartz_block
fill 198 233 559 198 234 559 minecraft:quartz_block
fill 198 233 561 198 234 561 minecraft:quartz_block
fill 198 233 563 198 234 563 minecraft:quartz_block
fill 198 233 565 198 234 565 minecraft:quartz_block
fill 198 233 589 198 234 589 minecraft:quartz_block
fill 198 233 591 198 234 591 minecraft:quartz_block
fill 198 233 593 198 234 593 minecraft:quartz_block
fill 198 233 595 198 234 595 minecraft:quartz_block
fill 201 233 599 202 245 599 minecraft:gold_block
fill 205 233 590 205 234 590 minecraft:quartz_block
fill 205 233 592 205 234 592 minecraft:quartz_block
fill 205 233 594 205 234 594 minecraft:quartz_block
fill 205 233 596 205 234 596 minecraft:quartz_block
fill 205 233 598 205 234 598 minecraft:quartz_block
fill 206 233 591 206 234 591 minecraft:quartz_block
fill 206 233 593 206 234 593 minecraft:quartz_block
fill 206 233 595 206 234 595 minecraft:quartz_block
fill 206 233 597 206 234 597 minecraft:quartz_block
fill 207 233 590 207 234 590 minecraft:quartz_block
fill 207 233 592 207 234 592 minecraft:quartz_block
fill 207 233 594 207 234 594 minecraft:quartz_block
fill 207 233 596 207 234 596 minecraft:quartz_block
fill 207 233 598 207 234 598 minecraft:quartz_block
fill 208 233 557 209 245 557 minecraft:gold_block
fill 208 233 591 208 234 591 minecraft:quartz_block
fill 208 233 593 208 234 593 minecraft:quartz_block
fill 208 233 595 208 234 595 minecraft:quartz_block
fill 208 233 597 208 234 597 minecraft:quartz_block
fill 209 233 590 209 234 590 minecraft:quartz_block
fill 209 233 592 209 234 592 minecraft:quartz_block
fill 209 233 594 209 234 594 minecraft:quartz_block
fill 209 233 596 209 234 596 minecraft:quartz_block
fill 209 233 598 209 234 598 minecraft:quartz_block
fill 210 233 591 210 234 591 minecraft:quartz_block
fill 210 233 593 210 234 593 minecraft:quartz_block
fill 210 233 595 210 234 595 minecraft:quartz_block
fill 210 233 597 210 234 597 minecraft:quartz_block
fill 211 233 590 211 234 590 minecraft:quartz_block
fill 211 233 592 211 234 592 minecraft:quartz_block
fill 211 233 594 211 234 594 minecraft:quartz_block
fill 211 233 596 211 234 596 minecraft:quartz_block
fill 211 233 598 211 234 598 minecraft:quartz_block
fill 213 233 599 214 245 599 minecraft:gold_block
fill 216 233 593 216 234 593 minecraft:quartz_block
fill 216 233 595 216 234 595 minecraft:quartz_block
fill 216 233 597 216 234 597 minecraft:quartz_block
fill 217 233 592 217 234 592 minecraft:quartz_block
fill 217 233 594 217 234 594 minecraft:quartz_block
fill 217 233 596 217 234 596 minecraft:quartz_block
fill 217 233 598 217 234 598 minecraft:quartz_block
fill 218 233 593 218 234 593 minecraft:quartz_block
fill 218 233 595 218 234 595 minecraft:quartz_block
fill 218 233 597 218 234 597 minecraft:quartz_block
fill 219 233 592 219 234 592 minecraft:quartz_block
fill 219 233 594 219 234 594 minecraft:quartz_block
fill 219 233 596 219 234 596 minecraft:quartz_block
fill 219 233 598 219 234 598 minecraft:quartz_block
fill 220 233 557 221 245 557 minecraft:gold_block
fill 220 233 593 220 234 593 minecraft:quartz_block
fill 220 233 595 220 234 595 minecraft:quartz_block
fill 220 233 597 220 234 597 minecraft:quartz_block
fill 221 233 592 221 234 592 minecraft:quartz_block
fill 221 233 594 221 234 594 minecraft:quartz_block
fill 221 233 596 221 234 596 minecraft:quartz_block
fill 221 233 598 221 234 598 minecraft:quartz_block
fill 222 233 593 222 234 593 minecraft:quartz_block
fill 222 233 595 222 234 595 minecraft:quartz_block
fill 222 233 597 222 234 597 minecraft:quartz_block
fill 223 233 592 223 234 592 minecraft:quartz_block
fill 223 233 594 223 234 594 minecraft:quartz_block
fill 223 233 596 223 234 596 minecraft:quartz_block
fill 223 233 598 223 234 598 minecraft:quartz_block
fill 224 233 593 224 234 593 minecraft:quartz_block
fill 224 233 595 224 234 595 minecraft:quartz_block
fill 224 233 597 224 234 597 minecraft:quartz_block
fill 225 233 592 225 234 592 minecraft:quartz_block
fill 225 233 594 225 234 594 minecraft:quartz_block
fill 225 233 596 225 234 596 minecraft:quartz_block
fill 225 233 598 225 234 598 minecraft:quartz_block
fill 225 233 599 226 245 599 minecraft:gold_block
fill 226 233 593 226 234 593 minecraft:quartz_block
fill 226 233 595 226 234 595 minecraft:quartz_block
fill 226 233 597 226 234 597 minecraft:quartz_block
fill 230 233 559 230 245 560 minecraft:gold_block
fill 230 233 571 230 245 572 minecraft:gold_block
fill 230 233 583 230 245 584 minecraft:gold_block
fill 230 233 595 230 245 596 minecraft:gold_block
setblock 189 235 560 minecraft:ochre_froglight
setblock 189 235 562 minecraft:ochre_froglight
setblock 189 235 564 minecraft:ochre_froglight
setblock 189 235 590 minecraft:ochre_froglight
setblock 189 235 592 minecraft:ochre_froglight
setblock 189 235 594 minecraft:ochre_froglight
setblock 190 235 559 minecraft:ochre_froglight
setblock 190 235 561 minecraft:ochre_froglight
setblock 190 235 563 minecraft:ochre_froglight
setblock 190 235 565 minecraft:ochre_froglight
setblock 190 235 589 minecraft:ochre_froglight
setblock 190 235 591 minecraft:ochre_froglight
setblock 190 235 593 minecraft:ochre_froglight
setblock 190 235 595 minecraft:ochre_froglight
setblock 191 235 560 minecraft:ochre_froglight
setblock 191 235 562 minecraft:ochre_froglight
setblock 191 235 564 minecraft:ochre_froglight
setblock 191 235 568 minecraft:light[level=14]
setblock 191 235 576 minecraft:light[level=14]
setblock 191 235 584 minecraft:light[level=14]
setblock 191 235 590 minecraft:ochre_froglight
setblock 191 235 592 minecraft:ochre_froglight
setblock 191 235 594 minecraft:ochre_froglight
setblock 192 235 559 minecraft:ochre_froglight
setblock 192 235 561 minecraft:ochre_froglight
setblock 192 235 563 minecraft:ochre_froglight
setblock 192 235 565 minecraft:ochre_froglight
setblock 192 235 589 minecraft:ochre_froglight
setblock 192 235 591 minecraft:ochre_froglight
setblock 192 235 593 minecraft:ochre_froglight
setblock 192 235 595 minecraft:ochre_froglight
setblock 193 235 560 minecraft:ochre_froglight
setblock 193 235 562 minecraft:ochre_froglight
setblock 193 235 564 minecraft:ochre_froglight
setblock 193 235 590 minecraft:ochre_froglight
setblock 193 235 592 minecraft:ochre_froglight
setblock 193 235 594 minecraft:ochre_froglight
setblock 194 235 559 minecraft:ochre_froglight
setblock 194 235 561 minecraft:ochre_froglight
setblock 194 235 563 minecraft:ochre_froglight
setblock 194 235 565 minecraft:ochre_froglight
setblock 194 235 589 minecraft:ochre_froglight
setblock 194 235 591 minecraft:ochre_froglight
setblock 194 235 593 minecraft:ochre_froglight
setblock 194 235 595 minecraft:ochre_froglight
setblock 195 235 560 minecraft:ochre_froglight
setblock 195 235 562 minecraft:ochre_froglight
setblock 195 235 564 minecraft:ochre_froglight
setblock 195 235 590 minecraft:ochre_froglight
setblock 195 235 592 minecraft:ochre_froglight
setblock 195 235 594 minecraft:ochre_froglight
setblock 196 235 559 minecraft:ochre_froglight
setblock 196 235 561 minecraft:ochre_froglight
setblock 196 235 563 minecraft:ochre_froglight
setblock 196 235 565 minecraft:ochre_froglight
setblock 196 235 589 minecraft:ochre_froglight
setblock 196 235 591 minecraft:ochre_froglight
setblock 196 235 593 minecraft:ochre_froglight
setblock 196 235 595 minecraft:ochre_froglight
setblock 197 235 560 minecraft:ochre_froglight
setblock 197 235 562 minecraft:ochre_froglight
setblock 197 235 564 minecraft:ochre_froglight
setblock 197 235 590 minecraft:ochre_froglight
setblock 197 235 592 minecraft:ochre_froglight
setblock 197 235 594 minecraft:ochre_froglight
setblock 198 235 559 minecraft:ochre_froglight
setblock 198 235 561 minecraft:ochre_froglight
setblock 198 235 563 minecraft:ochre_froglight
setblock 198 235 565 minecraft:ochre_froglight
setblock 198 235 589 minecraft:ochre_froglight
setblock 198 235 591 minecraft:ochre_froglight
setblock 198 235 593 minecraft:ochre_froglight
setblock 198 235 595 minecraft:ochre_froglight
setblock 199 235 560 minecraft:light[level=14]
setblock 199 235 568 minecraft:light[level=14]
setblock 199 235 576 minecraft:light[level=14]
setblock 199 235 584 minecraft:light[level=14]
setblock 199 235 592 minecraft:light[level=14]
setblock 205 235 590 minecraft:ochre_froglight
setblock 205 235 592 minecraft:ochre_froglight
setblock 205 235 594 minecraft:ochre_froglight
setblock 205 235 596 minecraft:ochre_froglight
setblock 205 235 598 minecraft:ochre_froglight
setblock 206 235 591 minecraft:ochre_froglight
setblock 206 235 593 minecraft:ochre_froglight
setblock 206 235 595 minecraft:ochre_froglight
setblock 206 235 597 minecraft:ochre_froglight
setblock 207 235 560 minecraft:light[level=14]
setblock 207 235 568 minecraft:light[level=14]
setblock 207 235 576 minecraft:light[level=14]
setblock 207 235 584 minecraft:light[level=14]
setblock 207 235 590 minecraft:ochre_froglight
setblock 207 235 592 minecraft:ochre_froglight
setblock 207 235 594 minecraft:ochre_froglight
setblock 207 235 596 minecraft:ochre_froglight
setblock 207 235 598 minecraft:ochre_froglight
setblock 208 235 591 minecraft:ochre_froglight
setblock 208 235 593 minecraft:ochre_froglight
setblock 208 235 595 minecraft:ochre_froglight
setblock 208 235 597 minecraft:ochre_froglight
setblock 209 235 590 minecraft:ochre_froglight
setblock 209 235 592 minecraft:ochre_froglight
setblock 209 235 594 minecraft:ochre_froglight
setblock 209 235 596 minecraft:ochre_froglight
setblock 209 235 598 minecraft:ochre_froglight
setblock 210 235 591 minecraft:ochre_froglight
setblock 210 235 593 minecraft:ochre_froglight
setblock 210 235 595 minecraft:ochre_froglight
setblock 210 235 597 minecraft:ochre_froglight
setblock 211 235 590 minecraft:ochre_froglight
setblock 211 235 592 minecraft:ochre_froglight
setblock 211 235 594 minecraft:ochre_froglight
setblock 211 235 596 minecraft:ochre_froglight
setblock 211 235 598 minecraft:ochre_froglight
setblock 215 235 560 minecraft:light[level=14]
setblock 215 235 568 minecraft:light[level=14]
setblock 215 235 576 minecraft:light[level=14]
setblock 215 235 584 minecraft:light[level=14]
setblock 215 235 592 minecraft:light[level=14]
setblock 216 235 593 minecraft:ochre_froglight
setblock 216 235 595 minecraft:ochre_froglight
setblock 216 235 597 minecraft:ochre_froglight
setblock 217 235 592 minecraft:ochre_froglight
setblock 217 235 594 minecraft:ochre_froglight
setblock 217 235 596 minecraft:ochre_froglight
setblock 217 235 598 minecraft:ochre_froglight
setblock 218 235 593 minecraft:ochre_froglight
setblock 218 235 595 minecraft:ochre_froglight
setblock 218 235 597 minecraft:ochre_froglight
setblock 219 235 592 minecraft:ochre_froglight
setblock 219 235 594 minecraft:ochre_froglight
setblock 219 235 596 minecraft:ochre_froglight
setblock 219 235 598 minecraft:ochre_froglight
setblock 220 235 593 minecraft:ochre_froglight
setblock 220 235 595 minecraft:ochre_froglight
setblock 220 235 597 minecraft:ochre_froglight
setblock 221 235 592 minecraft:ochre_froglight
setblock 221 235 594 minecraft:ochre_froglight
setblock 221 235 596 minecraft:ochre_froglight
setblock 221 235 598 minecraft:ochre_froglight
setblock 222 235 593 minecraft:ochre_froglight
setblock 222 235 595 minecraft:ochre_froglight
setblock 222 235 597 minecraft:ochre_froglight
setblock 223 235 560 minecraft:light[level=14]
setblock 223 235 568 minecraft:light[level=14]
setblock 223 235 576 minecraft:light[level=14]
setblock 223 235 584 minecraft:light[level=14]
setblock 223 235 592 minecraft:ochre_froglight
setblock 223 235 594 minecraft:ochre_froglight
setblock 223 235 596 minecraft:ochre_froglight
setblock 223 235 598 minecraft:ochre_froglight
setblock 224 235 593 minecraft:ochre_froglight
setblock 224 235 595 minecraft:ochre_froglight
setblock 224 235 597 minecraft:ochre_froglight
setblock 225 235 592 minecraft:ochre_froglight
setblock 225 235 594 minecraft:ochre_froglight
setblock 225 235 596 minecraft:ochre_froglight
setblock 225 235 598 minecraft:ochre_froglight
setblock 226 235 593 minecraft:ochre_froglight
setblock 226 235 595 minecraft:ochre_froglight
setblock 226 235 597 minecraft:ochre_froglight
fill 189 236 560 189 237 560 minecraft:quartz_block
fill 189 236 562 189 237 562 minecraft:quartz_block
fill 189 236 564 189 237 564 minecraft:quartz_block
fill 189 236 590 189 237 590 minecraft:quartz_block
fill 189 236 592 189 237 592 minecraft:quartz_block
fill 189 236 594 189 237 594 minecraft:quartz_block
fill 190 236 559 190 237 559 minecraft:quartz_block
fill 190 236 561 190 237 561 minecraft:quartz_block
fill 190 236 563 190 237 563 minecraft:quartz_block
fill 190 236 565 190 237 565 minecraft:quartz_block
fill 190 236 589 190 237 589 minecraft:quartz_block
fill 190 236 591 190 237 591 minecraft:quartz_block
fill 190 236 593 190 237 593 minecraft:quartz_block
fill 190 236 595 190 237 595 minecraft:quartz_block
fill 191 236 560 191 237 560 minecraft:quartz_block
fill 191 236 562 191 237 562 minecraft:quartz_block
fill 191 236 564 191 237 564 minecraft:quartz_block
fill 191 236 590 191 237 590 minecraft:quartz_block
fill 191 236 592 191 237 592 minecraft:quartz_block
fill 191 236 594 191 237 594 minecraft:quartz_block
fill 192 236 559 192 237 559 minecraft:quartz_block
fill 192 236 561 192 237 561 minecraft:quartz_block
fill 192 236 563 192 237 563 minecraft:quartz_block
fill 192 236 565 192 237 565 minecraft:quartz_block
fill 192 236 589 192 237 589 minecraft:quartz_block
fill 192 236 591 192 237 591 minecraft:quartz_block
fill 192 236 593 192 237 593 minecraft:quartz_block
fill 192 236 595 192 237 595 minecraft:quartz_block
fill 193 236 560 193 237 560 minecraft:quartz_block
fill 193 236 562 193 237 562 minecraft:quartz_block
fill 193 236 564 193 237 564 minecraft:quartz_block
fill 193 236 590 193 237 590 minecraft:quartz_block
fill 193 236 592 193 237 592 minecraft:quartz_block
fill 193 236 594 193 237 594 minecraft:quartz_block
fill 194 236 559 194 237 559 minecraft:quartz_block
fill 194 236 561 194 237 561 minecraft:quartz_block
fill 194 236 563 194 237 563 minecraft:quartz_block
fill 194 236 565 194 237 565 minecraft:quartz_block
fill 194 236 589 194 237 589 minecraft:quartz_block
fill 194 236 591 194 237 591 minecraft:quartz_block
fill 194 236 593 194 237 593 minecraft:quartz_block
fill 194 236 595 194 237 595 minecraft:quartz_block
fill 195 236 560 195 237 560 minecraft:quartz_block
fill 195 236 562 195 237 562 minecraft:quartz_block
fill 195 236 564 195 237 564 minecraft:quartz_block
fill 195 236 590 195 237 590 minecraft:quartz_block
fill 195 236 592 195 237 592 minecraft:quartz_block
fill 195 236 594 195 237 594 minecraft:quartz_block
fill 196 236 559 196 237 559 minecraft:quartz_block
fill 196 236 561 196 237 561 minecraft:quartz_block
fill 196 236 563 196 237 563 minecraft:quartz_block
fill 196 236 565 196 237 565 minecraft:quartz_block
fill 196 236 589 196 237 589 minecraft:quartz_block
fill 196 236 591 196 237 591 minecraft:quartz_block
fill 196 236 593 196 237 593 minecraft:quartz_block
fill 196 236 595 196 237 595 minecraft:quartz_block
fill 197 236 560 197 237 560 minecraft:quartz_block
fill 197 236 562 197 237 562 minecraft:quartz_block
fill 197 236 564 197 237 564 minecraft:quartz_block
fill 197 236 590 197 237 590 minecraft:quartz_block
fill 197 236 592 197 237 592 minecraft:quartz_block
fill 197 236 594 197 237 594 minecraft:quartz_block
fill 198 236 559 198 237 559 minecraft:quartz_block
fill 198 236 561 198 237 561 minecraft:quartz_block
fill 198 236 563 198 237 563 minecraft:quartz_block
fill 198 236 565 198 237 565 minecraft:quartz_block
fill 198 236 589 198 237 589 minecraft:quartz_block
fill 198 236 591 198 237 591 minecraft:quartz_block
fill 198 236 593 198 237 593 minecraft:quartz_block
fill 198 236 595 198 237 595 minecraft:quartz_block
fill 205 236 590 205 237 590 minecraft:quartz_block
fill 205 236 592 205 237 592 minecraft:quartz_block
fill 205 236 594 205 237 594 minecraft:quartz_block
fill 205 236 596 205 237 596 minecraft:quartz_block
fill 205 236 598 205 237 598 minecraft:quartz_block
fill 206 236 591 206 237 591 minecraft:quartz_block
fill 206 236 593 206 237 593 minecraft:quartz_block
fill 206 236 595 206 237 595 minecraft:quartz_block
fill 206 236 597 206 237 597 minecraft:quartz_block
fill 207 236 590 207 237 590 minecraft:quartz_block
fill 207 236 592 207 237 592 minecraft:quartz_block
fill 207 236 594 207 237 594 minecraft:quartz_block
fill 207 236 596 207 237 596 minecraft:quartz_block
fill 207 236 598 207 237 598 minecraft:quartz_block
fill 208 236 591 208 237 591 minecraft:quartz_block
fill 208 236 593 208 237 593 minecraft:quartz_block
fill 208 236 595 208 237 595 minecraft:quartz_block
fill 208 236 597 208 237 597 minecraft:quartz_block
fill 209 236 590 209 237 590 minecraft:quartz_block
fill 209 236 592 209 237 592 minecraft:quartz_block
fill 209 236 594 209 237 594 minecraft:quartz_block
fill 209 236 596 209 237 596 minecraft:quartz_block
fill 209 236 598 209 237 598 minecraft:quartz_block
fill 210 236 591 210 237 591 minecraft:quartz_block
fill 210 236 593 210 237 593 minecraft:quartz_block
fill 210 236 595 210 237 595 minecraft:quartz_block
fill 210 236 597 210 237 597 minecraft:quartz_block
fill 211 236 590 211 237 590 minecraft:quartz_block
fill 211 236 592 211 237 592 minecraft:quartz_block
fill 211 236 594 211 237 594 minecraft:quartz_block
fill 211 236 596 211 237 596 minecraft:quartz_block
fill 211 236 598 211 237 598 minecraft:quartz_block
fill 216 236 593 216 237 593 minecraft:quartz_block
fill 216 236 595 216 237 595 minecraft:quartz_block
fill 216 236 597 216 237 597 minecraft:quartz_block
fill 217 236 592 217 237 592 minecraft:quartz_block
fill 217 236 594 217 237 594 minecraft:quartz_block
fill 217 236 596 217 237 596 minecraft:quartz_block
fill 217 236 598 217 237 598 minecraft:quartz_block
fill 218 236 593 218 237 593 minecraft:quartz_block
fill 218 236 595 218 237 595 minecraft:quartz_block
fill 218 236 597 218 237 597 minecraft:quartz_block
fill 219 236 592 219 237 592 minecraft:quartz_block
fill 219 236 594 219 237 594 minecraft:quartz_block
fill 219 236 596 219 237 596 minecraft:quartz_block
fill 219 236 598 219 237 598 minecraft:quartz_block
fill 220 236 593 220 237 593 minecraft:quartz_block
fill 220 236 595 220 237 595 minecraft:quartz_block
fill 220 236 597 220 237 597 minecraft:quartz_block
fill 221 236 592 221 237 592 minecraft:quartz_block
fill 221 236 594 221 237 594 minecraft:quartz_block
fill 221 236 596 221 237 596 minecraft:quartz_block
fill 221 236 598 221 237 598 minecraft:quartz_block
fill 222 236 593 222 237 593 minecraft:quartz_block
fill 222 236 595 222 237 595 minecraft:quartz_block
fill 222 236 597 222 237 597 minecraft:quartz_block
fill 223 236 592 223 237 592 minecraft:quartz_block
fill 223 236 594 223 237 594 minecraft:quartz_block
fill 223 236 596 223 237 596 minecraft:quartz_block
fill 223 236 598 223 237 598 minecraft:quartz_block
fill 224 236 593 224 237 593 minecraft:quartz_block
fill 224 236 595 224 237 595 minecraft:quartz_block
fill 224 236 597 224 237 597 minecraft:quartz_block
fill 225 236 592 225 237 592 minecraft:quartz_block
fill 225 236 594 225 237 594 minecraft:quartz_block
fill 225 236 596 225 237 596 minecraft:quartz_block
fill 225 236 598 225 237 598 minecraft:quartz_block
fill 226 236 593 226 237 593 minecraft:quartz_block
fill 226 236 595 226 237 595 minecraft:quartz_block
fill 226 236 597 226 237 597 minecraft:quartz_block
fill 193 237 577 194 238 578 minecraft:raw_gold_block
setblock 189 238 560 minecraft:ochre_froglight
setblock 189 238 562 minecraft:ochre_froglight
setblock 189 238 564 minecraft:ochre_froglight
setblock 189 238 590 minecraft:ochre_froglight
setblock 189 238 592 minecraft:ochre_froglight
setblock 189 238 594 minecraft:ochre_froglight
setblock 190 238 559 minecraft:ochre_froglight
setblock 190 238 561 minecraft:ochre_froglight
setblock 190 238 563 minecraft:ochre_froglight
setblock 190 238 565 minecraft:ochre_froglight
setblock 190 238 589 minecraft:ochre_froglight
setblock 190 238 591 minecraft:ochre_froglight
setblock 190 238 593 minecraft:ochre_froglight
setblock 190 238 595 minecraft:ochre_froglight
setblock 191 238 560 minecraft:ochre_froglight
setblock 191 238 562 minecraft:ochre_froglight
setblock 191 238 564 minecraft:ochre_froglight
setblock 191 238 590 minecraft:ochre_froglight
setblock 191 238 592 minecraft:ochre_froglight
setblock 191 238 594 minecraft:ochre_froglight
setblock 192 238 559 minecraft:ochre_froglight
setblock 192 238 561 minecraft:ochre_froglight
setblock 192 238 563 minecraft:ochre_froglight
setblock 192 238 565 minecraft:ochre_froglight
setblock 192 238 589 minecraft:ochre_froglight
setblock 192 238 591 minecraft:ochre_froglight
setblock 192 238 593 minecraft:ochre_froglight
setblock 192 238 595 minecraft:ochre_froglight
setblock 193 238 560 minecraft:ochre_froglight
setblock 193 238 562 minecraft:ochre_froglight
setblock 193 238 564 minecraft:ochre_froglight
setblock 193 238 590 minecraft:ochre_froglight
setblock 193 238 592 minecraft:ochre_froglight
setblock 193 238 594 minecraft:ochre_froglight
setblock 194 238 559 minecraft:ochre_froglight
setblock 194 238 561 minecraft:ochre_froglight
setblock 194 238 563 minecraft:ochre_froglight
setblock 194 238 565 minecraft:ochre_froglight
setblock 194 238 589 minecraft:ochre_froglight
setblock 194 238 591 minecraft:ochre_froglight
setblock 194 238 593 minecraft:ochre_froglight
setblock 194 238 595 minecraft:ochre_froglight
setblock 195 238 560 minecraft:ochre_froglight
setblock 195 238 562 minecraft:ochre_froglight
setblock 195 238 564 minecraft:ochre_froglight
setblock 195 238 590 minecraft:ochre_froglight
setblock 195 238 592 minecraft:ochre_froglight
setblock 195 238 594 minecraft:ochre_froglight
setblock 196 238 559 minecraft:ochre_froglight
setblock 196 238 561 minecraft:ochre_froglight
setblock 196 238 563 minecraft:ochre_froglight
setblock 196 238 565 minecraft:ochre_froglight
setblock 196 238 589 minecraft:ochre_froglight
setblock 196 238 591 minecraft:ochre_froglight
setblock 196 238 593 minecraft:ochre_froglight
setblock 196 238 595 minecraft:ochre_froglight
setblock 197 238 560 minecraft:ochre_froglight
setblock 197 238 562 minecraft:ochre_froglight
setblock 197 238 564 minecraft:ochre_froglight
setblock 197 238 590 minecraft:ochre_froglight
setblock 197 238 592 minecraft:ochre_froglight
setblock 197 238 594 minecraft:ochre_froglight
setblock 198 238 559 minecraft:ochre_froglight
setblock 198 238 561 minecraft:ochre_froglight
setblock 198 238 563 minecraft:ochre_froglight
setblock 198 238 565 minecraft:ochre_froglight
setblock 198 238 589 minecraft:ochre_froglight
setblock 198 238 591 minecraft:ochre_froglight
setblock 198 238 593 minecraft:ochre_froglight
setblock 198 238 595 minecraft:ochre_froglight
setblock 205 238 590 minecraft:ochre_froglight
setblock 205 238 592 minecraft:ochre_froglight
setblock 205 238 594 minecraft:ochre_froglight
setblock 205 238 596 minecraft:ochre_froglight
setblock 205 238 598 minecraft:ochre_froglight
setblock 206 238 591 minecraft:ochre_froglight
setblock 206 238 593 minecraft:ochre_froglight
setblock 206 238 595 minecraft:ochre_froglight
setblock 206 238 597 minecraft:ochre_froglight
setblock 207 238 590 minecraft:ochre_froglight
setblock 207 238 592 minecraft:ochre_froglight
setblock 207 238 594 minecraft:ochre_froglight
setblock 207 238 596 minecraft:ochre_froglight
setblock 207 238 598 minecraft:ochre_froglight
setblock 208 238 591 minecraft:ochre_froglight
setblock 208 238 593 minecraft:ochre_froglight
setblock 208 238 595 minecraft:ochre_froglight
setblock 208 238 597 minecraft:ochre_froglight
setblock 209 238 590 minecraft:ochre_froglight
setblock 209 238 592 minecraft:ochre_froglight
setblock 209 238 594 minecraft:ochre_froglight
setblock 209 238 596 minecraft:ochre_froglight
setblock 209 238 598 minecraft:ochre_froglight
setblock 210 238 591 minecraft:ochre_froglight
setblock 210 238 593 minecraft:ochre_froglight
setblock 210 238 595 minecraft:ochre_froglight
setblock 210 238 597 minecraft:ochre_froglight
setblock 211 238 590 minecraft:ochre_froglight
setblock 211 238 592 minecraft:ochre_froglight
setblock 211 238 594 minecraft:ochre_froglight
setblock 211 238 596 minecraft:ochre_froglight
setblock 211 238 598 minecraft:ochre_froglight
setblock 216 238 593 minecraft:ochre_froglight
setblock 216 238 595 minecraft:ochre_froglight
setblock 216 238 597 minecraft:ochre_froglight
setblock 217 238 592 minecraft:ochre_froglight
setblock 217 238 594 minecraft:ochre_froglight
setblock 217 238 596 minecraft:ochre_froglight
setblock 217 238 598 minecraft:ochre_froglight
setblock 218 238 593 minecraft:ochre_froglight
setblock 218 238 595 minecraft:ochre_froglight
setblock 218 238 597 minecraft:ochre_froglight
setblock 219 238 592 minecraft:ochre_froglight
setblock 219 238 594 minecraft:ochre_froglight
setblock 219 238 596 minecraft:ochre_froglight
setblock 219 238 598 minecraft:ochre_froglight
setblock 220 238 593 minecraft:ochre_froglight
setblock 220 238 595 minecraft:ochre_froglight
setblock 220 238 597 minecraft:ochre_froglight
setblock 221 238 592 minecraft:ochre_froglight
setblock 221 238 594 minecraft:ochre_froglight
setblock 221 238 596 minecraft:ochre_froglight
setblock 221 238 598 minecraft:ochre_froglight
setblock 222 238 593 minecraft:ochre_froglight
setblock 222 238 595 minecraft:ochre_froglight
setblock 222 238 597 minecraft:ochre_froglight
setblock 223 238 592 minecraft:ochre_froglight
setblock 223 238 594 minecraft:ochre_froglight
setblock 223 238 596 minecraft:ochre_froglight
setblock 223 238 598 minecraft:ochre_froglight
setblock 224 238 593 minecraft:ochre_froglight
setblock 224 238 595 minecraft:ochre_froglight
setblock 224 238 597 minecraft:ochre_froglight
setblock 225 238 592 minecraft:ochre_froglight
setblock 225 238 594 minecraft:ochre_froglight
setblock 225 238 596 minecraft:ochre_froglight
setblock 225 238 598 minecraft:ochre_froglight
setblock 226 238 593 minecraft:ochre_froglight
setblock 226 238 595 minecraft:ochre_froglight
setblock 226 238 597 minecraft:ochre_froglight
fill 189 239 560 189 240 560 minecraft:quartz_block
fill 189 239 562 189 240 562 minecraft:quartz_block
fill 189 239 564 189 240 564 minecraft:quartz_block
fill 189 239 590 189 240 590 minecraft:quartz_block
fill 189 239 592 189 240 592 minecraft:quartz_block
fill 189 239 594 189 240 594 minecraft:quartz_block
fill 190 239 559 190 240 559 minecraft:quartz_block
fill 190 239 561 190 240 561 minecraft:quartz_block
fill 190 239 563 190 240 563 minecraft:quartz_block
fill 190 239 565 190 240 565 minecraft:quartz_block
fill 190 239 589 190 240 589 minecraft:quartz_block
fill 190 239 591 190 240 591 minecraft:quartz_block
fill 190 239 593 190 240 593 minecraft:quartz_block
fill 190 239 595 190 240 595 minecraft:quartz_block
fill 191 239 560 191 240 560 minecraft:quartz_block
fill 191 239 562 191 240 562 minecraft:quartz_block
fill 191 239 564 191 240 564 minecraft:quartz_block
fill 191 239 590 191 240 590 minecraft:quartz_block
fill 191 239 592 191 240 592 minecraft:quartz_block
fill 191 239 594 191 240 594 minecraft:quartz_block
fill 192 239 559 192 240 559 minecraft:quartz_block
fill 192 239 561 192 240 561 minecraft:quartz_block
fill 192 239 563 192 240 563 minecraft:quartz_block
fill 192 239 565 192 240 565 minecraft:quartz_block
fill 192 239 589 192 240 589 minecraft:quartz_block
fill 192 239 591 192 240 591 minecraft:quartz_block
fill 192 239 593 192 240 593 minecraft:quartz_block
fill 192 239 595 192 240 595 minecraft:quartz_block
fill 193 239 560 193 240 560 minecraft:quartz_block
fill 193 239 562 193 240 562 minecraft:quartz_block
fill 193 239 564 193 240 564 minecraft:quartz_block
fill 193 239 590 193 240 590 minecraft:quartz_block
fill 193 239 592 193 240 592 minecraft:quartz_block
fill 193 239 594 193 240 594 minecraft:quartz_block
fill 194 239 559 194 240 559 minecraft:quartz_block
fill 194 239 561 194 240 561 minecraft:quartz_block
fill 194 239 563 194 240 563 minecraft:quartz_block
fill 194 239 565 194 240 565 minecraft:quartz_block
fill 194 239 589 194 240 589 minecraft:quartz_block
fill 194 239 591 194 240 591 minecraft:quartz_block
fill 194 239 593 194 240 593 minecraft:quartz_block
fill 194 239 595 194 240 595 minecraft:quartz_block
fill 195 239 560 195 240 560 minecraft:quartz_block
fill 195 239 562 195 240 562 minecraft:quartz_block
fill 195 239 564 195 240 564 minecraft:quartz_block
fill 195 239 590 195 240 590 minecraft:quartz_block
fill 195 239 592 195 240 592 minecraft:quartz_block
fill 195 239 594 195 240 594 minecraft:quartz_block
fill 196 239 559 196 240 559 minecraft:quartz_block
fill 196 239 561 196 240 561 minecraft:quartz_block
fill 196 239 563 196 240 563 minecraft:quartz_block
fill 196 239 565 196 240 565 minecraft:quartz_block
fill 196 239 589 196 240 589 minecraft:quartz_block
fill 196 239 591 196 240 591 minecraft:quartz_block
fill 196 239 593 196 240 593 minecraft:quartz_block
fill 196 239 595 196 240 595 minecraft:quartz_block
fill 197 239 560 197 240 560 minecraft:quartz_block
fill 197 239 562 197 240 562 minecraft:quartz_block
fill 197 239 564 197 240 564 minecraft:quartz_block
fill 197 239 590 197 240 590 minecraft:quartz_block
fill 197 239 592 197 240 592 minecraft:quartz_block
fill 197 239 594 197 240 594 minecraft:quartz_block
fill 198 239 559 198 240 559 minecraft:quartz_block
fill 198 239 561 198 240 561 minecraft:quartz_block
fill 198 239 563 198 240 563 minecraft:quartz_block
fill 198 239 565 198 240 565 minecraft:quartz_block
fill 198 239 589 198 240 589 minecraft:quartz_block
fill 198 239 591 198 240 591 minecraft:quartz_block
fill 198 239 593 198 240 593 minecraft:quartz_block
fill 198 239 595 198 240 595 minecraft:quartz_block
fill 202 239 563 202 240 563 minecraft:raw_gold_block
fill 205 239 590 205 240 590 minecraft:quartz_block
fill 205 239 592 205 240 592 minecraft:quartz_block
fill 205 239 594 205 240 594 minecraft:quartz_block
fill 205 239 596 205 240 596 minecraft:quartz_block
fill 205 239 598 205 240 598 minecraft:quartz_block
fill 206 239 591 206 240 591 minecraft:quartz_block
fill 206 239 593 206 240 593 minecraft:quartz_block
fill 206 239 595 206 240 595 minecraft:quartz_block
fill 206 239 597 206 240 597 minecraft:quartz_block
fill 207 239 590 207 240 590 minecraft:quartz_block
fill 207 239 592 207 240 592 minecraft:quartz_block
fill 207 239 594 207 240 594 minecraft:quartz_block
fill 207 239 596 207 240 596 minecraft:quartz_block
fill 207 239 598 207 240 598 minecraft:quartz_block
fill 208 239 591 208 240 591 minecraft:quartz_block
fill 208 239 593 208 240 593 minecraft:quartz_block
fill 208 239 595 208 240 595 minecraft:quartz_block
fill 208 239 597 208 240 597 minecraft:quartz_block
fill 209 239 590 209 240 590 minecraft:quartz_block
fill 209 239 592 209 240 592 minecraft:quartz_block
fill 209 239 594 209 240 594 minecraft:quartz_block
fill 209 239 596 209 240 596 minecraft:quartz_block
fill 209 239 598 209 240 598 minecraft:quartz_block
fill 210 239 591 210 240 591 minecraft:quartz_block
fill 210 239 593 210 240 593 minecraft:quartz_block
fill 210 239 595 210 240 595 minecraft:quartz_block
fill 210 239 597 210 240 597 minecraft:quartz_block
fill 211 239 590 211 240 590 minecraft:quartz_block
fill 211 239 592 211 240 592 minecraft:quartz_block
fill 211 239 594 211 240 594 minecraft:quartz_block
fill 211 239 596 211 240 596 minecraft:quartz_block
fill 211 239 598 211 240 598 minecraft:quartz_block
fill 216 239 593 216 240 593 minecraft:quartz_block
fill 216 239 595 216 240 595 minecraft:quartz_block
fill 216 239 597 216 240 597 minecraft:quartz_block
fill 217 239 592 217 240 592 minecraft:quartz_block
fill 217 239 594 217 240 594 minecraft:quartz_block
fill 217 239 596 217 240 596 minecraft:quartz_block
fill 217 239 598 217 240 598 minecraft:quartz_block
fill 218 239 593 218 240 593 minecraft:quartz_block
fill 218 239 595 218 240 595 minecraft:quartz_block
fill 218 239 597 218 240 597 minecraft:quartz_block
fill 219 239 592 219 240 592 minecraft:quartz_block
fill 219 239 594 219 240 594 minecraft:quartz_block
fill 219 239 596 219 240 596 minecraft:quartz_block
fill 219 239 598 219 240 598 minecraft:quartz_block
fill 220 239 593 220 240 593 minecraft:quartz_block
fill 220 239 595 220 240 595 minecraft:quartz_block
fill 220 239 597 220 240 597 minecraft:quartz_block
fill 221 239 592 221 240 592 minecraft:quartz_block
fill 221 239 594 221 240 594 minecraft:quartz_block
fill 221 239 596 221 240 596 minecraft:quartz_block
fill 221 239 598 221 240 598 minecraft:quartz_block
fill 222 239 562 222 239 564 minecraft:yellow_terracotta
fill 222 239 593 222 240 593 minecraft:quartz_block
fill 222 239 595 222 240 595 minecraft:quartz_block
fill 222 239 597 222 240 597 minecraft:quartz_block
setblock 223 239 561 minecraft:yellow_terracotta
fill 223 239 565 225 239 565 minecraft:yellow_terracotta
fill 223 239 592 223 240 592 minecraft:quartz_block
fill 223 239 594 223 240 594 minecraft:quartz_block
fill 223 239 596 223 240 596 minecraft:quartz_block
fill 223 239 598 223 240 598 minecraft:quartz_block
fill 224 239 593 224 240 593 minecraft:quartz_block
fill 224 239 595 224 240 595 minecraft:quartz_block
fill 224 239 597 224 240 597 minecraft:quartz_block
fill 225 239 561 226 239 561 minecraft:yellow_terracotta
fill 225 239 592 225 240 592 minecraft:quartz_block
fill 225 239 594 225 240 594 minecraft:quartz_block
fill 225 239 596 225 240 596 minecraft:quartz_block
fill 225 239 598 225 240 598 minecraft:quartz_block
fill 226 239 562 226 239 564 minecraft:yellow_terracotta
fill 226 239 593 226 240 593 minecraft:quartz_block
fill 226 239 595 226 240 595 minecraft:quartz_block
fill 226 239 597 226 240 597 minecraft:quartz_block
fill 190 240 567 190 245 569 minecraft:quartz_block
fill 190 240 579 190 245 581 minecraft:quartz_block
fill 196 240 597 198 245 597 minecraft:quartz_block
fill 200 240 559 202 245 559 minecraft:quartz_block
fill 200 240 593 200 241 595 minecraft:gold_block
fill 201 240 594 201 241 594 minecraft:gold_block
fill 212 240 559 214 245 559 minecraft:quartz_block
fill 224 240 559 226 245 559 minecraft:quartz_block
fill 228 240 567 228 245 569 minecraft:quartz_block
fill 228 240 579 228 245 581 minecraft:quartz_block
fill 228 240 591 228 245 593 minecraft:quartz_block
setblock 189 241 560 minecraft:ochre_froglight
setblock 189 241 562 minecraft:ochre_froglight
setblock 189 241 564 minecraft:ochre_froglight
setblock 189 241 590 minecraft:ochre_froglight
setblock 189 241 592 minecraft:ochre_froglight
setblock 189 241 594 minecraft:ochre_froglight
setblock 190 241 559 minecraft:ochre_froglight
setblock 190 241 561 minecraft:ochre_froglight
setblock 190 241 563 minecraft:ochre_froglight
setblock 190 241 565 minecraft:ochre_froglight
setblock 190 241 589 minecraft:ochre_froglight
setblock 190 241 591 minecraft:ochre_froglight
setblock 190 241 593 minecraft:ochre_froglight
setblock 190 241 595 minecraft:ochre_froglight
setblock 191 241 560 minecraft:ochre_froglight
setblock 191 241 562 minecraft:ochre_froglight
setblock 191 241 564 minecraft:ochre_froglight
setblock 191 241 590 minecraft:ochre_froglight
setblock 191 241 592 minecraft:ochre_froglight
setblock 191 241 594 minecraft:ochre_froglight
setblock 192 241 559 minecraft:ochre_froglight
setblock 192 241 561 minecraft:ochre_froglight
setblock 192 241 563 minecraft:ochre_froglight
setblock 192 241 565 minecraft:ochre_froglight
setblock 192 241 589 minecraft:ochre_froglight
setblock 192 241 591 minecraft:ochre_froglight
setblock 192 241 593 minecraft:ochre_froglight
setblock 192 241 595 minecraft:ochre_froglight
setblock 193 241 560 minecraft:ochre_froglight
setblock 193 241 562 minecraft:ochre_froglight
setblock 193 241 564 minecraft:ochre_froglight
setblock 193 241 590 minecraft:ochre_froglight
setblock 193 241 592 minecraft:ochre_froglight
setblock 193 241 594 minecraft:ochre_froglight
setblock 194 241 559 minecraft:ochre_froglight
setblock 194 241 561 minecraft:ochre_froglight
setblock 194 241 563 minecraft:ochre_froglight
setblock 194 241 565 minecraft:ochre_froglight
setblock 194 241 589 minecraft:ochre_froglight
setblock 194 241 591 minecraft:ochre_froglight
setblock 194 241 593 minecraft:ochre_froglight
setblock 194 241 595 minecraft:ochre_froglight
setblock 195 241 560 minecraft:ochre_froglight
setblock 195 241 562 minecraft:ochre_froglight
setblock 195 241 564 minecraft:ochre_froglight
setblock 195 241 590 minecraft:ochre_froglight
setblock 195 241 592 minecraft:ochre_froglight
setblock 195 241 594 minecraft:ochre_froglight
setblock 196 241 559 minecraft:ochre_froglight
setblock 196 241 561 minecraft:ochre_froglight
setblock 196 241 563 minecraft:ochre_froglight
setblock 196 241 565 minecraft:ochre_froglight
setblock 196 241 589 minecraft:ochre_froglight
setblock 196 241 591 minecraft:ochre_froglight
setblock 196 241 593 minecraft:ochre_froglight
setblock 196 241 595 minecraft:ochre_froglight
setblock 197 241 560 minecraft:ochre_froglight
setblock 197 241 562 minecraft:ochre_froglight
setblock 197 241 564 minecraft:ochre_froglight
setblock 197 241 590 minecraft:ochre_froglight
setblock 197 241 592 minecraft:ochre_froglight
setblock 197 241 594 minecraft:ochre_froglight
setblock 198 241 559 minecraft:ochre_froglight
setblock 198 241 561 minecraft:ochre_froglight
setblock 198 241 563 minecraft:ochre_froglight
setblock 198 241 565 minecraft:ochre_froglight
setblock 198 241 589 minecraft:ochre_froglight
setblock 198 241 591 minecraft:ochre_froglight
setblock 198 241 593 minecraft:ochre_froglight
setblock 198 241 595 minecraft:ochre_froglight
setblock 205 241 590 minecraft:ochre_froglight
setblock 205 241 592 minecraft:ochre_froglight
setblock 205 241 594 minecraft:ochre_froglight
setblock 205 241 596 minecraft:ochre_froglight
setblock 205 241 598 minecraft:ochre_froglight
setblock 206 241 591 minecraft:ochre_froglight
setblock 206 241 593 minecraft:ochre_froglight
setblock 206 241 595 minecraft:ochre_froglight
setblock 206 241 597 minecraft:ochre_froglight
setblock 207 241 590 minecraft:ochre_froglight
setblock 207 241 592 minecraft:ochre_froglight
setblock 207 241 594 minecraft:ochre_froglight
setblock 207 241 596 minecraft:ochre_froglight
setblock 207 241 598 minecraft:ochre_froglight
setblock 208 241 591 minecraft:ochre_froglight
setblock 208 241 593 minecraft:ochre_froglight
setblock 208 241 595 minecraft:ochre_froglight
setblock 208 241 597 minecraft:ochre_froglight
setblock 209 241 590 minecraft:ochre_froglight
setblock 209 241 592 minecraft:ochre_froglight
setblock 209 241 594 minecraft:ochre_froglight
setblock 209 241 596 minecraft:ochre_froglight
setblock 209 241 598 minecraft:ochre_froglight
setblock 210 241 591 minecraft:ochre_froglight
setblock 210 241 593 minecraft:ochre_froglight
setblock 210 241 595 minecraft:ochre_froglight
setblock 210 241 597 minecraft:ochre_froglight
setblock 211 241 590 minecraft:ochre_froglight
setblock 211 241 592 minecraft:ochre_froglight
setblock 211 241 594 minecraft:ochre_froglight
setblock 211 241 596 minecraft:ochre_froglight
setblock 211 241 598 minecraft:ochre_froglight
setblock 216 241 593 minecraft:ochre_froglight
setblock 216 241 595 minecraft:ochre_froglight
setblock 216 241 597 minecraft:ochre_froglight
setblock 217 241 592 minecraft:ochre_froglight
setblock 217 241 594 minecraft:ochre_froglight
setblock 217 241 596 minecraft:ochre_froglight
setblock 217 241 598 minecraft:ochre_froglight
setblock 218 241 593 minecraft:ochre_froglight
setblock 218 241 595 minecraft:ochre_froglight
setblock 218 241 597 minecraft:ochre_froglight
setblock 219 241 592 minecraft:ochre_froglight
setblock 219 241 594 minecraft:ochre_froglight
setblock 219 241 596 minecraft:ochre_froglight
setblock 219 241 598 minecraft:ochre_froglight
setblock 220 241 593 minecraft:ochre_froglight
setblock 220 241 595 minecraft:ochre_froglight
setblock 220 241 597 minecraft:ochre_froglight
setblock 221 241 592 minecraft:ochre_froglight
setblock 221 241 594 minecraft:ochre_froglight
setblock 221 241 596 minecraft:ochre_froglight
setblock 221 241 598 minecraft:ochre_froglight
setblock 222 241 593 minecraft:ochre_froglight
setblock 222 241 595 minecraft:ochre_froglight
setblock 222 241 597 minecraft:ochre_froglight
setblock 223 241 592 minecraft:ochre_froglight
setblock 223 241 594 minecraft:ochre_froglight
setblock 223 241 596 minecraft:ochre_froglight
setblock 223 241 598 minecraft:ochre_froglight
setblock 224 241 593 minecraft:ochre_froglight
setblock 224 241 595 minecraft:ochre_froglight
setblock 224 241 597 minecraft:ochre_froglight
setblock 225 241 592 minecraft:ochre_froglight
setblock 225 241 594 minecraft:ochre_froglight
setblock 225 241 596 minecraft:ochre_froglight
setblock 225 241 598 minecraft:ochre_froglight
setblock 226 241 593 minecraft:ochre_froglight
setblock 226 241 595 minecraft:ochre_froglight
setblock 226 241 597 minecraft:ochre_froglight
fill 189 242 560 189 243 560 minecraft:quartz_block
fill 189 242 562 189 243 562 minecraft:quartz_block
fill 189 242 564 189 243 564 minecraft:quartz_block
fill 189 242 590 189 243 590 minecraft:quartz_block
fill 189 242 592 189 243 592 minecraft:quartz_block
fill 189 242 594 189 243 594 minecraft:quartz_block
fill 190 242 559 190 243 559 minecraft:quartz_block
fill 190 242 561 190 243 561 minecraft:quartz_block
fill 190 242 563 190 243 563 minecraft:quartz_block
fill 190 242 565 190 243 565 minecraft:quartz_block
fill 190 242 589 190 243 589 minecraft:quartz_block
fill 190 242 591 190 243 591 minecraft:quartz_block
fill 190 242 593 190 243 593 minecraft:quartz_block
fill 190 242 595 190 243 595 minecraft:quartz_block
fill 191 242 560 191 243 560 minecraft:quartz_block
fill 191 242 562 191 243 562 minecraft:quartz_block
fill 191 242 564 191 243 564 minecraft:quartz_block
fill 191 242 590 191 243 590 minecraft:quartz_block
fill 191 242 592 191 243 592 minecraft:quartz_block
fill 191 242 594 191 243 594 minecraft:quartz_block
fill 192 242 559 192 243 559 minecraft:quartz_block
fill 192 242 561 192 243 561 minecraft:quartz_block
fill 192 242 563 192 243 563 minecraft:quartz_block
fill 192 242 565 192 243 565 minecraft:quartz_block
fill 192 242 589 192 243 589 minecraft:quartz_block
fill 192 242 591 192 243 591 minecraft:quartz_block
fill 192 242 593 192 243 593 minecraft:quartz_block
fill 192 242 595 192 243 595 minecraft:quartz_block
fill 193 242 560 193 243 560 minecraft:quartz_block
fill 193 242 562 193 243 562 minecraft:quartz_block
fill 193 242 564 193 243 564 minecraft:quartz_block
fill 193 242 590 193 243 590 minecraft:quartz_block
fill 193 242 592 193 243 592 minecraft:quartz_block
fill 193 242 594 193 243 594 minecraft:quartz_block
fill 194 242 559 194 243 559 minecraft:quartz_block
fill 194 242 561 194 243 561 minecraft:quartz_block
fill 194 242 563 194 243 563 minecraft:quartz_block
fill 194 242 565 194 243 565 minecraft:quartz_block
fill 194 242 589 194 243 589 minecraft:quartz_block
fill 194 242 591 194 243 591 minecraft:quartz_block
fill 194 242 593 194 243 593 minecraft:quartz_block
fill 194 242 595 194 243 595 minecraft:quartz_block
fill 195 242 560 195 243 560 minecraft:quartz_block
fill 195 242 562 195 243 562 minecraft:quartz_block
fill 195 242 564 195 243 564 minecraft:quartz_block
fill 195 242 590 195 243 590 minecraft:quartz_block
fill 195 242 592 195 243 592 minecraft:quartz_block
fill 195 242 594 195 243 594 minecraft:quartz_block
fill 196 242 559 196 243 559 minecraft:quartz_block
fill 196 242 561 196 243 561 minecraft:quartz_block
fill 196 242 563 196 243 563 minecraft:quartz_block
fill 196 242 565 196 243 565 minecraft:quartz_block
fill 196 242 589 196 243 589 minecraft:quartz_block
fill 196 242 591 196 243 591 minecraft:quartz_block
fill 196 242 593 196 243 593 minecraft:quartz_block
fill 196 242 595 196 243 595 minecraft:quartz_block
fill 197 242 560 197 243 560 minecraft:quartz_block
fill 197 242 562 197 243 562 minecraft:quartz_block
fill 197 242 564 197 243 564 minecraft:quartz_block
fill 197 242 590 197 243 590 minecraft:quartz_block
fill 197 242 592 197 243 592 minecraft:quartz_block
fill 197 242 594 197 243 594 minecraft:quartz_block
fill 198 242 559 198 243 559 minecraft:quartz_block
fill 198 242 561 198 243 561 minecraft:quartz_block
fill 198 242 563 198 243 563 minecraft:quartz_block
fill 198 242 565 198 243 565 minecraft:quartz_block
fill 198 242 589 198 243 589 minecraft:quartz_block
fill 198 242 591 198 243 591 minecraft:quartz_block
fill 198 242 593 198 243 593 minecraft:quartz_block
fill 198 242 595 198 243 595 minecraft:quartz_block
fill 205 242 590 205 243 590 minecraft:quartz_block
fill 205 242 592 205 243 592 minecraft:quartz_block
fill 205 242 594 205 243 594 minecraft:quartz_block
fill 205 242 596 205 243 596 minecraft:quartz_block
fill 205 242 598 205 243 598 minecraft:quartz_block
fill 206 242 591 206 243 591 minecraft:quartz_block
fill 206 242 593 206 243 593 minecraft:quartz_block
fill 206 242 595 206 243 595 minecraft:quartz_block
fill 206 242 597 206 243 597 minecraft:quartz_block
fill 207 242 590 207 243 590 minecraft:quartz_block
fill 207 242 592 207 243 592 minecraft:quartz_block
fill 207 242 594 207 243 594 minecraft:quartz_block
fill 207 242 596 207 243 596 minecraft:quartz_block
fill 207 242 598 207 243 598 minecraft:quartz_block
fill 208 242 591 208 243 591 minecraft:quartz_block
fill 208 242 593 208 243 593 minecraft:quartz_block
fill 208 242 595 208 243 595 minecraft:quartz_block
fill 208 242 597 208 243 597 minecraft:quartz_block
fill 209 242 590 209 243 590 minecraft:quartz_block
fill 209 242 592 209 243 592 minecraft:quartz_block
fill 209 242 594 209 243 594 minecraft:quartz_block
fill 209 242 596 209 243 596 minecraft:quartz_block
fill 209 242 598 209 243 598 minecraft:quartz_block
fill 210 242 591 210 243 591 minecraft:quartz_block
fill 210 242 593 210 243 593 minecraft:quartz_block
fill 210 242 595 210 243 595 minecraft:quartz_block
fill 210 242 597 210 243 597 minecraft:quartz_block
fill 211 242 590 211 243 590 minecraft:quartz_block
fill 211 242 592 211 243 592 minecraft:quartz_block
fill 211 242 594 211 243 594 minecraft:quartz_block
fill 211 242 596 211 243 596 minecraft:quartz_block
fill 211 242 598 211 243 598 minecraft:quartz_block
fill 216 242 593 216 243 593 minecraft:quartz_block
fill 216 242 595 216 243 595 minecraft:quartz_block
schedule function dropper:buildpart/136_3 1t
