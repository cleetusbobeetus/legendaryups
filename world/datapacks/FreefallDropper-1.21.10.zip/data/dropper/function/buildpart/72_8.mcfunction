setblock 24 219 332 minecraft:light[level=12]
setblock 24 219 339 minecraft:light[level=12]
setblock 24 219 346 minecraft:light[level=12]
setblock 24 219 353 minecraft:light[level=12]
setblock 24 219 360 minecraft:light[level=12]
setblock 24 219 363 minecraft:yellow_terracotta
fill 25 219 323 27 219 324 minecraft:honeycomb_block
fill 25 219 363 28 219 363 minecraft:honeycomb_block
fill 26 219 362 29 219 362 minecraft:honeycomb_block
setblock 27 219 342 minecraft:brown_terracotta
fill 27 219 345 27 219 346 minecraft:brown_terracotta
setblock 28 219 323 minecraft:honeycomb_block
setblock 28 219 324 minecraft:yellow_terracotta
fill 28 219 325 29 221 325 minecraft:honeycomb_block
fill 28 219 341 30 219 341 minecraft:brown_terracotta
setblock 28 219 346 minecraft:brown_terracotta
setblock 29 219 323 minecraft:yellow_terracotta
fill 29 219 324 29 222 324 minecraft:honeycomb_block
fill 29 219 361 30 219 361 minecraft:honeycomb_block
setblock 29 219 363 minecraft:yellow_terracotta
fill 30 219 323 30 222 323 minecraft:honeycomb_block
setblock 30 219 362 minecraft:yellow_terracotta
fill 30 219 363 33 219 363 minecraft:honeycomb_block
setblock 31 219 332 minecraft:light[level=12]
fill 31 219 336 31 221 336 minecraft:yellow_terracotta
setblock 31 219 339 minecraft:light[level=12]
setblock 31 219 346 minecraft:brown_terracotta
setblock 31 219 353 minecraft:light[level=12]
setblock 31 219 360 minecraft:light[level=12]
setblock 31 219 361 minecraft:yellow_terracotta
fill 31 219 362 34 219 362 minecraft:honeycomb_block
fill 32 219 323 32 219 324 minecraft:honeycomb_block
setblock 32 219 325 minecraft:yellow_terracotta
fill 32 219 343 32 219 345 minecraft:brown_terracotta
fill 32 219 361 33 221 361 minecraft:honeycomb_block
setblock 33 219 323 minecraft:honeycomb_block
setblock 33 219 324 minecraft:yellow_terracotta
fill 33 219 325 33 222 325 minecraft:honeycomb_block
setblock 34 219 323 minecraft:yellow_terracotta
fill 34 219 324 34 222 324 minecraft:honeycomb_block
setblock 34 219 363 minecraft:yellow_terracotta
fill 35 219 323 35 222 323 minecraft:honeycomb_block
setblock 35 219 362 minecraft:yellow_terracotta
fill 35 219 363 38 219 363 minecraft:honeycomb_block
fill 36 219 362 36 222 362 minecraft:honeycomb_block
setblock 37 219 324 minecraft:honeycomb_block
setblock 38 219 323 minecraft:honeycomb_block
setblock 38 219 325 minecraft:light[level=12]
setblock 38 219 332 minecraft:light[level=12]
setblock 38 219 339 minecraft:light[level=12]
setblock 38 219 346 minecraft:light[level=12]
setblock 38 219 353 minecraft:light[level=12]
setblock 38 219 360 minecraft:light[level=12]
setblock 39 219 323 minecraft:yellow_terracotta
setblock 39 219 362 minecraft:honeycomb_block
setblock 39 219 363 minecraft:yellow_terracotta
fill 40 219 323 40 222 323 minecraft:honeycomb_block
fill 40 219 360 40 219 361 minecraft:honeycomb_block
setblock 40 219 362 minecraft:yellow_terracotta
fill 40 219 363 40 222 363 minecraft:honeycomb_block
setblock 41 219 325 minecraft:honeycomb_block
setblock 41 219 343 minecraft:honey_block
fill 41 219 357 41 222 357 minecraft:honeycomb_block
setblock 41 219 361 minecraft:yellow_terracotta
fill 41 219 362 41 222 362 minecraft:honeycomb_block
setblock 42 219 337 minecraft:yellow_terracotta
fill 42 219 342 42 239 342 minecraft:honeycomb_block
setblock 0 220 350 minecraft:yellow_terracotta
fill 1 220 323 2 220 323 minecraft:honeycomb_block
setblock 1 220 324 minecraft:honey_block
setblock 1 220 339 minecraft:honeycomb_block
setblock 1 220 340 minecraft:yellow_terracotta
fill 1 220 341 1 223 341 minecraft:honeycomb_block
setblock 1 220 345 minecraft:yellow_terracotta
fill 1 220 346 1 221 348 minecraft:honeycomb_block
setblock 1 220 349 minecraft:honey_block
setblock 1 220 354 minecraft:honeycomb_block
setblock 1 220 355 minecraft:yellow_terracotta
fill 1 220 356 1 220 359 minecraft:honeycomb_block
setblock 1 220 360 minecraft:yellow_terracotta
fill 1 220 361 2 220 363 minecraft:honeycomb_block
fill 2 220 342 2 220 343 minecraft:honeycomb_block
setblock 2 220 344 minecraft:yellow_terracotta
fill 2 220 345 2 223 345 minecraft:honeycomb_block
fill 2 220 357 2 220 358 minecraft:honeycomb_block
setblock 2 220 359 minecraft:yellow_terracotta
fill 2 220 360 3 222 360 minecraft:honeycomb_block
setblock 3 220 323 minecraft:yellow_terracotta
setblock 3 220 324 minecraft:brown_terracotta
setblock 3 220 327 minecraft:brown_terracotta
fill 3 220 361 3 220 362 minecraft:honeycomb_block
setblock 3 220 363 minecraft:yellow_terracotta
fill 4 220 323 7 220 323 minecraft:honeycomb_block
setblock 4 220 361 minecraft:honeycomb_block
setblock 4 220 362 minecraft:yellow_terracotta
fill 4 220 363 7 220 363 minecraft:honeycomb_block
setblock 5 220 361 minecraft:yellow_terracotta
fill 5 220 362 8 220 362 minecraft:honeycomb_block
setblock 6 220 324 minecraft:brown_terracotta
setblock 6 220 327 minecraft:brown_terracotta
fill 6 220 361 6 223 361 minecraft:honeycomb_block
setblock 7 220 324 minecraft:yellow_terracotta
setblock 8 220 323 minecraft:yellow_terracotta
fill 8 220 324 10 221 324 minecraft:honeycomb_block
setblock 8 220 363 minecraft:yellow_terracotta
fill 9 220 323 9 223 323 minecraft:honeycomb_block
setblock 9 220 362 minecraft:yellow_terracotta
fill 9 220 363 12 220 363 minecraft:honeycomb_block
setblock 10 220 361 minecraft:yellow_terracotta
fill 10 220 362 10 223 362 minecraft:honeycomb_block
fill 11 220 322 11 242 322 minecraft:honeycomb_block
fill 11 220 361 11 221 361 minecraft:honeycomb_block
setblock 13 220 323 minecraft:yellow_terracotta
setblock 13 220 363 minecraft:yellow_terracotta
fill 14 220 323 15 222 323 minecraft:honeycomb_block
setblock 14 220 362 minecraft:yellow_terracotta
fill 14 220 363 14 223 363 minecraft:honeycomb_block
fill 20 220 323 22 220 323 minecraft:honeycomb_block
fill 21 220 363 22 220 363 minecraft:honeycomb_block
setblock 23 220 323 minecraft:yellow_terracotta
fill 23 220 324 26 220 324 minecraft:honeycomb_block
setblock 23 220 363 minecraft:yellow_terracotta
fill 24 220 323 27 220 323 minecraft:honeycomb_block
fill 24 220 363 27 220 363 minecraft:honeycomb_block
fill 25 220 362 28 220 362 minecraft:honeycomb_block
setblock 26 220 325 minecraft:yellow_terracotta
setblock 27 220 324 minecraft:yellow_terracotta
fill 27 220 325 27 223 325 minecraft:honeycomb_block
setblock 28 220 323 minecraft:yellow_terracotta
fill 28 220 324 28 223 324 minecraft:honeycomb_block
fill 28 220 351 29 222 351 minecraft:flowering_azalea_leaves[persistent=true]
fill 28 220 361 29 220 361 minecraft:honeycomb_block
setblock 28 220 363 minecraft:yellow_terracotta
fill 29 220 323 29 223 323 minecraft:honeycomb_block
fill 29 220 350 31 222 350 minecraft:flowering_azalea_leaves[persistent=true]
fill 29 220 352 31 222 352 minecraft:flowering_azalea_leaves[persistent=true]
setblock 29 220 362 minecraft:yellow_terracotta
fill 29 220 363 32 220 363 minecraft:honeycomb_block
fill 30 220 324 30 220 325 minecraft:honeycomb_block
fill 30 220 349 30 222 349 minecraft:flowering_azalea_leaves[persistent=true]
setblock 30 220 361 minecraft:yellow_terracotta
fill 30 220 362 33 220 362 minecraft:honeycomb_block
setblock 31 220 324 minecraft:honeycomb_block
setblock 31 220 325 minecraft:yellow_terracotta
fill 31 220 351 31 222 351 minecraft:flowering_azalea_leaves[persistent=true]
fill 31 220 361 31 222 361 minecraft:honeycomb_block
setblock 32 220 323 minecraft:honeycomb_block
setblock 32 220 324 minecraft:yellow_terracotta
fill 32 220 325 32 223 325 minecraft:honeycomb_block
setblock 33 220 323 minecraft:yellow_terracotta
fill 33 220 324 33 223 324 minecraft:honeycomb_block
setblock 33 220 363 minecraft:yellow_terracotta
fill 34 220 323 34 223 323 minecraft:honeycomb_block
fill 34 220 325 34 221 325 minecraft:honeycomb_block
setblock 34 220 362 minecraft:yellow_terracotta
fill 34 220 363 37 220 363 minecraft:honeycomb_block
setblock 35 220 322 minecraft:yellow_concrete
fill 35 220 362 35 223 362 minecraft:honeycomb_block
setblock 37 220 324 minecraft:yellow_terracotta
setblock 38 220 323 minecraft:yellow_terracotta
fill 38 220 324 38 223 324 minecraft:honeycomb_block
setblock 38 220 363 minecraft:yellow_terracotta
fill 39 220 323 39 223 323 minecraft:honeycomb_block
setblock 39 220 362 minecraft:yellow_terracotta
fill 39 220 363 39 223 363 minecraft:honeycomb_block
setblock 40 220 360 minecraft:honeycomb_block
setblock 40 220 361 minecraft:yellow_terracotta
fill 40 220 362 40 223 362 minecraft:honeycomb_block
setblock 41 220 325 minecraft:yellow_terracotta
fill 41 220 326 41 223 326 minecraft:honeycomb_block
setblock 41 220 337 minecraft:honey_block
setblock 41 220 360 minecraft:yellow_terracotta
fill 41 220 361 41 223 361 minecraft:honeycomb_block
fill 42 220 337 42 275 337 minecraft:honeycomb_block
setblock 0 221 328 minecraft:yellow_concrete
fill 0 221 350 1 224 350 minecraft:honeycomb_block
setblock 1 221 323 minecraft:honeycomb_block
setblock 1 221 324 minecraft:yellow_terracotta
setblock 1 221 330 minecraft:honey_block
setblock 1 221 339 minecraft:yellow_terracotta
fill 1 221 340 2 223 340 minecraft:honeycomb_block
fill 1 221 342 1 221 343 minecraft:honeycomb_block
setblock 1 221 344 minecraft:yellow_terracotta
fill 1 221 345 1 224 345 minecraft:honeycomb_block
setblock 1 221 349 minecraft:yellow_terracotta
fill 1 221 351 1 221 353 minecraft:honeycomb_block
setblock 1 221 354 minecraft:yellow_terracotta
fill 1 221 355 1 221 358 minecraft:honeycomb_block
setblock 1 221 359 minecraft:yellow_terracotta
fill 1 221 360 1 221 363 minecraft:honeycomb_block
setblock 2 221 323 minecraft:yellow_terracotta
fill 2 221 341 2 221 342 minecraft:honeycomb_block
setblock 2 221 343 minecraft:yellow_terracotta
fill 2 221 344 3 223 344 minecraft:honeycomb_block
fill 2 221 346 2 221 347 minecraft:honeycomb_block
setblock 2 221 348 minecraft:yellow_terracotta
fill 2 221 356 2 221 357 minecraft:honeycomb_block
setblock 2 221 358 minecraft:yellow_terracotta
fill 2 221 359 3 222 359 minecraft:honeycomb_block
fill 2 221 361 2 221 362 minecraft:honeycomb_block
setblock 2 221 363 minecraft:yellow_terracotta
fill 3 221 323 6 221 323 minecraft:honeycomb_block
setblock 3 221 342 minecraft:yellow_terracotta
fill 3 221 343 3 224 343 minecraft:honeycomb_block
fill 3 221 345 3 222 345 minecraft:honeycomb_block
setblock 3 221 361 minecraft:honeycomb_block
setblock 3 221 362 minecraft:yellow_terracotta
fill 3 221 363 6 221 363 minecraft:honeycomb_block
fill 4 221 324 5 221 324 minecraft:honeycomb_block
setblock 4 221 361 minecraft:yellow_terracotta
fill 4 221 362 7 221 362 minecraft:honeycomb_block
fill 5 221 361 5 224 361 minecraft:honeycomb_block
setblock 6 221 324 minecraft:yellow_terracotta
setblock 7 221 323 minecraft:yellow_terracotta
fill 7 221 324 7 224 324 minecraft:honeycomb_block
setblock 7 221 363 minecraft:yellow_terracotta
fill 8 221 323 8 224 323 minecraft:honeycomb_block
setblock 8 221 362 minecraft:yellow_terracotta
fill 8 221 363 11 221 363 minecraft:honeycomb_block
setblock 9 221 361 minecraft:yellow_terracotta
fill 9 221 362 9 224 362 minecraft:honeycomb_block
fill 10 221 361 10 222 361 minecraft:honeycomb_block
setblock 10 221 364 minecraft:yellow_terracotta
setblock 11 221 324 minecraft:yellow_terracotta
setblock 12 221 323 minecraft:yellow_terracotta
fill 12 221 324 12 224 324 minecraft:honeycomb_block
setblock 12 221 363 minecraft:yellow_terracotta
fill 13 221 323 13 224 323 minecraft:honeycomb_block
setblock 13 221 362 minecraft:yellow_terracotta
fill 13 221 363 13 224 363 minecraft:honeycomb_block
setblock 16 221 323 minecraft:honeycomb_block
setblock 17 221 323 minecraft:yellow_terracotta
setblock 17 221 363 minecraft:yellow_terracotta
fill 18 221 323 21 221 323 minecraft:honeycomb_block
fill 20 221 363 21 221 363 minecraft:honeycomb_block
setblock 22 221 323 minecraft:yellow_terracotta
fill 22 221 324 25 221 324 minecraft:honeycomb_block
setblock 22 221 363 minecraft:yellow_terracotta
fill 23 221 323 26 221 323 minecraft:honeycomb_block
fill 23 221 363 26 221 363 minecraft:honeycomb_block
setblock 24 221 325 minecraft:honeycomb_block
fill 24 221 362 27 221 362 minecraft:honeycomb_block
setblock 25 221 325 minecraft:yellow_terracotta
setblock 26 221 324 minecraft:yellow_terracotta
fill 26 221 325 26 224 325 minecraft:honeycomb_block
setblock 27 221 323 minecraft:yellow_terracotta
fill 27 221 324 27 224 324 minecraft:honeycomb_block
fill 27 221 361 28 221 361 minecraft:honeycomb_block
setblock 27 221 363 minecraft:yellow_terracotta
fill 28 221 323 28 224 323 minecraft:honeycomb_block
setblock 28 221 326 minecraft:honeycomb_block
setblock 28 221 350 minecraft:flowering_azalea_leaves[persistent=true]
setblock 28 221 352 minecraft:flowering_azalea_leaves[persistent=true]
setblock 28 221 362 minecraft:yellow_terracotta
fill 28 221 363 31 221 363 minecraft:honeycomb_block
setblock 29 221 326 minecraft:yellow_terracotta
setblock 29 221 349 minecraft:flowering_azalea_leaves[persistent=true]
fill 29 221 353 30 221 353 minecraft:flowering_azalea_leaves[persistent=true]
setblock 29 221 361 minecraft:yellow_terracotta
fill 29 221 362 32 221 362 minecraft:honeycomb_block
setblock 30 221 324 minecraft:honeycomb_block
setblock 30 221 325 minecraft:yellow_terracotta
fill 30 221 326 30 224 326 minecraft:honeycomb_block
fill 30 221 351 30 222 351 minecraft:flowering_azalea_leaves[persistent=true]
fill 30 221 361 30 223 361 minecraft:honeycomb_block
setblock 31 221 324 minecraft:yellow_terracotta
fill 31 221 325 31 224 325 minecraft:honeycomb_block
setblock 31 221 349 minecraft:flowering_azalea_leaves[persistent=true]
setblock 32 221 323 minecraft:yellow_terracotta
fill 32 221 324 32 224 324 minecraft:honeycomb_block
fill 32 221 350 32 221 352 minecraft:flowering_azalea_leaves[persistent=true]
setblock 32 221 363 minecraft:yellow_terracotta
fill 33 221 323 33 224 323 minecraft:honeycomb_block
setblock 33 221 362 minecraft:yellow_terracotta
fill 33 221 363 36 221 363 minecraft:honeycomb_block
fill 34 221 362 34 224 362 minecraft:honeycomb_block
fill 35 221 322 35 237 322 minecraft:honeycomb_block
setblock 35 221 324 minecraft:honeycomb_block
fill 35 221 354 35 224 354 minecraft:brown_terracotta
setblock 36 221 324 minecraft:yellow_terracotta
fill 36 221 353 36 224 353 minecraft:brown_terracotta
fill 36 221 355 36 224 355 minecraft:brown_terracotta
setblock 37 221 323 minecraft:yellow_terracotta
fill 37 221 324 37 224 324 minecraft:honeycomb_block
fill 37 221 354 37 224 354 minecraft:brown_terracotta
setblock 37 221 363 minecraft:yellow_terracotta
fill 38 221 323 38 224 323 minecraft:honeycomb_block
setblock 38 221 362 minecraft:yellow_terracotta
fill 38 221 363 38 224 363 minecraft:honeycomb_block
fill 39 221 324 40 221 324 minecraft:honeycomb_block
fill 39 221 362 39 224 362 minecraft:honeycomb_block
setblock 40 221 360 minecraft:yellow_terracotta
fill 40 221 361 40 224 361 minecraft:honeycomb_block
setblock 41 221 323 minecraft:honeycomb_block
setblock 41 221 324 minecraft:yellow_terracotta
fill 41 221 325 41 224 325 minecraft:honeycomb_block
fill 41 221 327 41 222 327 minecraft:honeycomb_block
setblock 41 221 331 minecraft:honey_block
fill 41 221 340 41 221 343 minecraft:honeycomb_block
setblock 41 221 344 minecraft:yellow_terracotta
fill 41 221 345 41 224 345 minecraft:honeycomb_block
setblock 41 221 356 minecraft:honey_block
setblock 41 221 359 minecraft:yellow_terracotta
fill 41 221 360 41 224 360 minecraft:honeycomb_block
setblock 42 221 343 minecraft:yellow_terracotta
fill 0 222 328 0 280 328 minecraft:honeycomb_block
setblock 0 222 336 minecraft:yellow_concrete
setblock 1 222 323 minecraft:yellow_terracotta
fill 1 222 324 1 224 325 minecraft:honeycomb_block
setblock 1 222 336 minecraft:honey_block
setblock 1 222 338 minecraft:yellow_terracotta
fill 1 222 339 1 225 339 minecraft:honeycomb_block
setblock 1 222 342 minecraft:honeycomb_block
setblock 1 222 343 minecraft:yellow_terracotta
fill 1 222 344 1 225 344 minecraft:honeycomb_block
fill 1 222 346 1 222 347 minecraft:honeycomb_block
setblock 1 222 348 minecraft:yellow_terracotta
fill 1 222 349 2 224 349 minecraft:honeycomb_block
fill 1 222 351 1 222 352 minecraft:honeycomb_block
setblock 1 222 353 minecraft:yellow_terracotta
fill 1 222 354 1 222 357 minecraft:honeycomb_block
setblock 1 222 358 minecraft:yellow_terracotta
fill 1 222 359 1 222 362 minecraft:honeycomb_block
setblock 1 222 363 minecraft:yellow_terracotta
fill 2 222 323 5 222 323 minecraft:honeycomb_block
setblock 2 222 341 minecraft:honeycomb_block
setblock 2 222 342 minecraft:yellow_terracotta
fill 2 222 343 2 225 343 minecraft:honeycomb_block
setblock 2 222 346 minecraft:honeycomb_block
setblock 2 222 347 minecraft:yellow_terracotta
fill 2 222 348 3 224 348 minecraft:honeycomb_block
fill 2 222 350 2 222 351 minecraft:honeycomb_block
setblock 2 222 356 minecraft:honeycomb_block
setblock 2 222 357 minecraft:yellow_terracotta
fill 2 222 358 2 225 358 minecraft:honeycomb_block
setblock 2 222 361 minecraft:honeycomb_block
setblock 2 222 362 minecraft:yellow_terracotta
fill 2 222 363 5 222 363 minecraft:honeycomb_block
fill 3 222 324 4 222 324 minecraft:honeycomb_block
setblock 3 222 341 minecraft:yellow_terracotta
fill 3 222 342 3 225 342 minecraft:honeycomb_block
setblock 3 222 346 minecraft:yellow_terracotta
fill 3 222 347 3 225 347 minecraft:honeycomb_block
setblock 3 222 361 minecraft:yellow_terracotta
fill 3 222 362 6 222 362 minecraft:honeycomb_block
fill 4 222 343 4 222 344 minecraft:honeycomb_block
setblock 4 222 345 minecraft:yellow_terracotta
fill 4 222 361 4 224 361 minecraft:honeycomb_block
setblock 5 222 324 minecraft:yellow_terracotta
setblock 6 222 323 minecraft:yellow_terracotta
fill 6 222 324 6 225 324 minecraft:honeycomb_block
setblock 6 222 363 minecraft:yellow_terracotta
fill 7 222 323 7 225 323 minecraft:honeycomb_block
setblock 7 222 362 minecraft:yellow_terracotta
fill 7 222 363 10 222 363 minecraft:honeycomb_block
fill 8 222 324 9 222 324 minecraft:honeycomb_block
setblock 8 222 361 minecraft:yellow_terracotta
fill 8 222 362 8 225 362 minecraft:honeycomb_block
fill 9 222 361 9 223 361 minecraft:honeycomb_block
setblock 10 222 324 minecraft:yellow_terracotta
fill 10 222 364 10 229 364 minecraft:honeycomb_block
setblock 11 222 323 minecraft:yellow_terracotta
fill 11 222 324 11 225 324 minecraft:honeycomb_block
setblock 11 222 363 minecraft:yellow_terracotta
fill 12 222 323 12 225 323 minecraft:honeycomb_block
setblock 12 222 362 minecraft:yellow_terracotta
fill 12 222 363 12 225 363 minecraft:honeycomb_block
setblock 13 222 362 minecraft:honeycomb_block
setblock 16 222 323 minecraft:yellow_terracotta
setblock 16 222 363 minecraft:yellow_terracotta
fill 17 222 323 20 222 323 minecraft:honeycomb_block
fill 18 222 328 21 271 328 minecraft:yellow_terracotta
setblock 18 222 363 minecraft:honey_block
fill 19 222 327 21 271 327 minecraft:yellow_terracotta
fill 19 222 329 21 271 329 minecraft:yellow_terracotta
fill 19 222 363 20 222 363 minecraft:honeycomb_block
fill 20 222 326 20 232 326 minecraft:yellow_terracotta
setblock 21 222 323 minecraft:yellow_terracotta
fill 21 222 324 24 222 324 minecraft:honeycomb_block
setblock 21 222 363 minecraft:yellow_terracotta
fill 22 222 323 25 222 323 minecraft:honeycomb_block
fill 22 222 363 25 222 363 minecraft:honeycomb_block
setblock 23 222 325 minecraft:honeycomb_block
fill 23 222 362 26 222 362 minecraft:honeycomb_block
setblock 24 222 325 minecraft:yellow_terracotta
setblock 25 222 324 minecraft:yellow_terracotta
fill 25 222 325 25 225 325 minecraft:honeycomb_block
setblock 26 222 322 minecraft:yellow_concrete
setblock 26 222 323 minecraft:yellow_terracotta
fill 26 222 324 26 225 324 minecraft:honeycomb_block
fill 26 222 326 27 222 326 minecraft:honeycomb_block
setblock 26 222 363 minecraft:yellow_terracotta
fill 27 222 323 27 225 323 minecraft:honeycomb_block
setblock 27 222 361 minecraft:honeycomb_block
setblock 27 222 362 minecraft:yellow_terracotta
fill 27 222 363 30 222 363 minecraft:honeycomb_block
setblock 28 222 325 minecraft:honeycomb_block
setblock 28 222 326 minecraft:yellow_terracotta
setblock 28 222 361 minecraft:yellow_terracotta
fill 28 222 362 31 222 362 minecraft:honeycomb_block
setblock 29 222 325 minecraft:yellow_terracotta
fill 29 222 326 29 225 326 minecraft:honeycomb_block
fill 29 222 335 32 224 337 minecraft:flowering_azalea_leaves[persistent=true]
fill 29 222 361 29 223 361 minecraft:honeycomb_block
setblock 30 222 324 minecraft:yellow_terracotta
fill 30 222 325 30 225 325 minecraft:honeycomb_block
fill 30 222 334 31 224 334 minecraft:flowering_azalea_leaves[persistent=true]
fill 31 222 322 31 308 322 minecraft:honeycomb_block
setblock 31 222 323 minecraft:yellow_terracotta
fill 31 222 324 31 225 324 minecraft:honeycomb_block
fill 31 222 326 31 223 326 minecraft:honeycomb_block
setblock 31 222 363 minecraft:yellow_terracotta
fill 32 222 323 32 225 323 minecraft:honeycomb_block
setblock 32 222 361 minecraft:honeycomb_block
setblock 32 222 362 minecraft:yellow_terracotta
fill 32 222 363 35 222 363 minecraft:honeycomb_block
fill 33 222 362 33 225 362 minecraft:honeycomb_block
setblock 34 222 325 minecraft:yellow_terracotta
setblock 35 222 324 minecraft:yellow_terracotta
setblock 36 222 323 minecraft:yellow_terracotta
fill 36 222 324 36 225 324 minecraft:honeycomb_block
setblock 36 222 363 minecraft:yellow_terracotta
fill 37 222 323 37 225 323 minecraft:honeycomb_block
setblock 37 222 362 minecraft:yellow_terracotta
fill 37 222 363 37 225 363 minecraft:honeycomb_block
fill 38 222 362 38 225 362 minecraft:honeycomb_block
setblock 39 222 324 minecraft:honeycomb_block
setblock 40 222 324 minecraft:yellow_terracotta
fill 40 222 325 40 225 325 minecraft:honeycomb_block
fill 40 222 360 40 224 360 minecraft:honeycomb_block
setblock 41 222 323 minecraft:yellow_terracotta
fill 41 222 324 41 225 324 minecraft:honeycomb_block
fill 41 222 340 41 222 342 minecraft:honeycomb_block
setblock 41 222 343 minecraft:yellow_terracotta
fill 41 222 344 41 225 344 minecraft:honeycomb_block
fill 41 222 346 41 222 347 minecraft:honeycomb_block
setblock 41 222 348 minecraft:yellow_terracotta
setblock 41 222 350 minecraft:honey_block
fill 41 222 356 41 223 356 minecraft:honeycomb_block
setblock 41 222 358 minecraft:yellow_terracotta
fill 41 222 359 41 225 359 minecraft:honeycomb_block
setblock 41 222 363 minecraft:yellow_terracotta
fill 42 222 343 42 308 343 minecraft:honeycomb_block
fill 0 223 336 0 308 336 minecraft:honeycomb_block
setblock 0 223 360 minecraft:yellow_terracotta
fill 1 223 323 4 223 323 minecraft:honeycomb_block
setblock 1 223 326 minecraft:honeycomb_block
fill 1 223 338 1 224 338 minecraft:honeycomb_block
setblock 1 223 342 minecraft:yellow_terracotta
fill 1 223 343 1 226 343 minecraft:honeycomb_block
setblock 1 223 346 minecraft:honeycomb_block
setblock 1 223 347 minecraft:yellow_terracotta
fill 1 223 348 1 226 348 minecraft:honeycomb_block
setblock 1 223 351 minecraft:honeycomb_block
setblock 1 223 352 minecraft:yellow_terracotta
fill 1 223 353 1 223 356 minecraft:honeycomb_block
setblock 1 223 357 minecraft:yellow_terracotta
fill 1 223 358 1 223 361 minecraft:honeycomb_block
setblock 1 223 362 minecraft:yellow_terracotta
fill 1 223 363 4 223 363 minecraft:honeycomb_block
fill 2 223 324 3 223 324 minecraft:honeycomb_block
setblock 2 223 341 minecraft:yellow_terracotta
fill 2 223 342 2 226 342 minecraft:honeycomb_block
setblock 2 223 346 minecraft:yellow_terracotta
fill 2 223 347 2 226 347 minecraft:honeycomb_block
setblock 2 223 350 minecraft:honeycomb_block
setblock 2 223 351 minecraft:yellow_terracotta
fill 2 223 352 2 223 355 minecraft:honeycomb_block
setblock 2 223 356 minecraft:yellow_terracotta
fill 2 223 357 2 225 357 minecraft:honeycomb_block
fill 2 223 359 2 223 360 minecraft:honeycomb_block
setblock 2 223 361 minecraft:yellow_terracotta
fill 2 223 362 5 223 362 minecraft:honeycomb_block
setblock 3 223 325 minecraft:light[level=15]
setblock 3 223 333 minecraft:light[level=15]
fill 3 223 341 3 225 341 minecraft:honeycomb_block
setblock 3 223 345 minecraft:yellow_terracotta
fill 3 223 346 4 225 346 minecraft:honeycomb_block
setblock 3 223 349 minecraft:honeycomb_block
setblock 3 223 350 minecraft:yellow_terracotta
setblock 3 223 357 minecraft:light[level=15]
setblock 3 223 360 minecraft:yellow_terracotta
fill 3 223 361 3 224 361 minecraft:honeycomb_block
setblock 4 223 324 minecraft:yellow_terracotta
fill 4 223 342 4 223 343 minecraft:honeycomb_block
setblock 4 223 344 minecraft:yellow_terracotta
fill 4 223 345 4 226 345 minecraft:honeycomb_block
fill 4 223 347 4 223 348 minecraft:honeycomb_block
setblock 5 223 323 minecraft:yellow_terracotta
fill 5 223 324 5 226 324 minecraft:honeycomb_block
setblock 5 223 363 minecraft:yellow_terracotta
fill 6 223 323 6 226 323 minecraft:honeycomb_block
setblock 6 223 362 minecraft:yellow_terracotta
fill 6 223 363 9 223 363 minecraft:honeycomb_block
setblock 7 223 361 minecraft:yellow_terracotta
fill 7 223 362 7 226 362 minecraft:honeycomb_block
setblock 8 223 324 minecraft:honeycomb_block
setblock 8 223 361 minecraft:honeycomb_block
setblock 9 223 324 minecraft:yellow_terracotta
setblock 10 223 323 minecraft:yellow_terracotta
fill 10 223 324 10 226 324 minecraft:honeycomb_block
setblock 10 223 363 minecraft:yellow_terracotta
fill 11 223 323 11 226 323 minecraft:honeycomb_block
setblock 11 223 325 minecraft:light[level=15]
setblock 11 223 333 minecraft:light[level=15]
setblock 11 223 341 minecraft:light[level=15]
setblock 11 223 349 minecraft:light[level=15]
setblock 11 223 357 minecraft:light[level=15]
setblock 11 223 362 minecraft:yellow_terracotta
fill 11 223 363 11 225 363 minecraft:honeycomb_block
setblock 12 223 362 minecraft:honeycomb_block
setblock 14 223 323 minecraft:honeycomb_block
setblock 15 223 323 minecraft:yellow_terracotta
setblock 15 223 363 minecraft:yellow_terracotta
fill 16 223 323 19 223 323 minecraft:honeycomb_block
fill 18 223 326 18 224 327 minecraft:brown_terracotta
fill 18 223 329 18 224 329 minecraft:brown_terracotta
setblock 19 223 325 minecraft:light[level=15]
fill 19 223 326 19 224 326 minecraft:brown_terracotta
fill 19 223 330 21 224 330 minecraft:brown_terracotta
setblock 19 223 333 minecraft:light[level=15]
setblock 19 223 341 minecraft:light[level=15]
setblock 19 223 349 minecraft:light[level=15]
setblock 19 223 357 minecraft:light[level=15]
setblock 20 223 323 minecraft:yellow_terracotta
fill 20 223 324 23 223 324 minecraft:honeycomb_block
setblock 20 223 363 minecraft:yellow_terracotta
setblock 21 223 322 minecraft:orange_terracotta
fill 21 223 323 24 223 323 minecraft:honeycomb_block
fill 21 223 326 21 224 326 minecraft:brown_terracotta
fill 21 223 363 24 223 363 minecraft:honeycomb_block
setblock 22 223 325 minecraft:honeycomb_block
fill 22 223 327 22 224 329 minecraft:brown_terracotta
setblock 23 223 325 minecraft:yellow_terracotta
fill 23 223 362 25 223 362 minecraft:honeycomb_block
setblock 24 223 324 minecraft:yellow_terracotta
fill 24 223 325 24 226 325 minecraft:honeycomb_block
setblock 25 223 323 minecraft:yellow_terracotta
fill 25 223 324 25 226 324 minecraft:honeycomb_block
fill 25 223 326 26 223 326 minecraft:honeycomb_block
setblock 25 223 363 minecraft:yellow_terracotta
fill 26 223 322 26 226 323 minecraft:honeycomb_block
setblock 26 223 362 minecraft:yellow_terracotta
fill 26 223 363 29 223 363 minecraft:honeycomb_block
setblock 27 223 326 minecraft:yellow_terracotta
setblock 27 223 333 minecraft:light[level=15]
setblock 27 223 341 minecraft:light[level=15]
setblock 27 223 349 minecraft:light[level=15]
setblock 27 223 357 minecraft:light[level=15]
setblock 27 223 361 minecraft:yellow_terracotta
fill 27 223 362 30 223 362 minecraft:honeycomb_block
setblock 28 223 325 minecraft:yellow_terracotta
fill 28 223 326 28 226 326 minecraft:honeycomb_block
setblock 28 223 361 minecraft:honeycomb_block
setblock 29 223 324 minecraft:yellow_terracotta
fill 29 223 325 29 226 325 minecraft:honeycomb_block
setblock 29 223 334 minecraft:flowering_azalea_leaves[persistent=true]
setblock 30 223 323 minecraft:yellow_terracotta
fill 30 223 324 30 226 324 minecraft:honeycomb_block
fill 30 223 338 31 223 338 minecraft:flowering_azalea_leaves[persistent=true]
setblock 30 223 363 minecraft:yellow_terracotta
fill 31 223 323 31 226 323 minecraft:honeycomb_block
setblock 31 223 362 minecraft:yellow_terracotta
fill 31 223 363 34 223 363 minecraft:honeycomb_block
setblock 32 223 334 minecraft:flowering_azalea_leaves[persistent=true]
fill 32 223 362 32 225 362 minecraft:honeycomb_block
setblock 33 223 325 minecraft:yellow_terracotta
setblock 34 223 324 minecraft:yellow_terracotta
fill 34 223 325 35 223 325 minecraft:honeycomb_block
setblock 35 223 323 minecraft:yellow_terracotta
fill 35 223 324 35 226 324 minecraft:honeycomb_block
setblock 35 223 333 minecraft:light[level=15]
setblock 35 223 341 minecraft:light[level=15]
setblock 35 223 349 minecraft:light[level=15]
setblock 35 223 357 minecraft:light[level=15]
setblock 35 223 363 minecraft:yellow_terracotta
fill 36 223 323 36 226 323 minecraft:honeycomb_block
setblock 36 223 362 minecraft:yellow_terracotta
fill 36 223 363 36 226 363 minecraft:honeycomb_block
fill 37 223 362 37 224 362 minecraft:honeycomb_block
setblock 38 223 322 minecraft:yellow_concrete
setblock 39 223 324 minecraft:yellow_terracotta
setblock 40 223 323 minecraft:yellow_terracotta
fill 40 223 324 40 226 324 minecraft:honeycomb_block
fill 40 223 326 40 224 326 minecraft:honeycomb_block
setblock 40 223 363 minecraft:yellow_terracotta
fill 41 223 323 41 226 323 minecraft:honeycomb_block
setblock 41 223 327 minecraft:yellow_terracotta
fill 41 223 328 41 226 328 minecraft:honeycomb_block
fill 41 223 340 41 223 341 minecraft:honeycomb_block
setblock 41 223 342 minecraft:yellow_terracotta
fill 41 223 343 41 226 343 minecraft:honeycomb_block
setblock 41 223 346 minecraft:honeycomb_block
setblock 41 223 347 minecraft:yellow_terracotta
fill 41 223 348 41 224 350 minecraft:honeycomb_block
fill 41 223 355 41 224 355 minecraft:honeycomb_block
setblock 41 223 357 minecraft:yellow_terracotta
fill 41 223 358 41 226 358 minecraft:honeycomb_block
setblock 41 223 362 minecraft:yellow_terracotta
fill 41 223 363 41 226 363 minecraft:honeycomb_block
fill 0 224 360 1 224 360 minecraft:honeycomb_block
fill 1 224 323 3 224 323 minecraft:honeycomb_block
setblock 1 224 326 minecraft:yellow_terracotta
fill 1 224 327 1 227 327 minecraft:honeycomb_block
setblock 1 224 329 minecraft:honey_block
setblock 1 224 340 minecraft:honeycomb_block
setblock 1 224 341 minecraft:yellow_terracotta
fill 1 224 342 1 227 342 minecraft:honeycomb_block
setblock 1 224 346 minecraft:yellow_terracotta
fill 1 224 347 1 227 347 minecraft:honeycomb_block
setblock 1 224 351 minecraft:yellow_terracotta
fill 1 224 352 1 224 355 minecraft:honeycomb_block
setblock 1 224 356 minecraft:yellow_terracotta
fill 1 224 357 1 225 359 minecraft:honeycomb_block
setblock 1 224 361 minecraft:yellow_terracotta
fill 1 224 362 3 224 363 minecraft:honeycomb_block
setblock 2 224 324 minecraft:honeycomb_block
setblock 2 224 325 minecraft:yellow_terracotta
setblock 2 224 340 minecraft:yellow_terracotta
fill 2 224 341 2 227 341 minecraft:honeycomb_block
setblock 2 224 344 minecraft:honeycomb_block
setblock 2 224 345 minecraft:yellow_terracotta
fill 2 224 346 2 227 346 minecraft:honeycomb_block
setblock 2 224 350 minecraft:yellow_terracotta
fill 2 224 351 2 224 354 minecraft:honeycomb_block
setblock 2 224 355 minecraft:yellow_terracotta
fill 2 224 356 2 226 356 minecraft:honeycomb_block
setblock 2 224 359 minecraft:honeycomb_block
setblock 2 224 360 minecraft:yellow_terracotta
fill 2 224 361 2 226 361 minecraft:honeycomb_block
setblock 3 224 324 minecraft:yellow_terracotta
setblock 3 224 344 minecraft:yellow_terracotta
fill 3 224 345 3 227 345 minecraft:honeycomb_block
setblock 3 224 349 minecraft:yellow_terracotta
fill 3 224 350 3 226 351 minecraft:honeycomb_block
setblock 4 224 323 minecraft:yellow_terracotta
fill 4 224 324 4 227 324 minecraft:honeycomb_block
setblock 4 224 342 minecraft:honeycomb_block
setblock 4 224 343 minecraft:yellow_terracotta
fill 4 224 344 4 227 344 minecraft:honeycomb_block
setblock 4 224 347 minecraft:honeycomb_block
setblock 4 224 348 minecraft:yellow_terracotta
fill 4 224 349 4 227 349 minecraft:honeycomb_block
setblock 4 224 362 minecraft:honeycomb_block
setblock 4 224 363 minecraft:yellow_terracotta
fill 5 224 323 5 227 323 minecraft:honeycomb_block
setblock 5 224 362 minecraft:yellow_terracotta
fill 5 224 363 8 224 363 minecraft:honeycomb_block
setblock 6 224 361 minecraft:yellow_terracotta
fill 6 224 362 6 226 362 minecraft:honeycomb_block
setblock 7 224 361 minecraft:honeycomb_block
setblock 8 224 324 minecraft:yellow_terracotta
setblock 9 224 323 minecraft:yellow_terracotta
fill 9 224 324 9 226 324 minecraft:honeycomb_block
setblock 9 224 363 minecraft:yellow_terracotta
fill 10 224 323 10 227 323 minecraft:honeycomb_block
setblock 10 224 362 minecraft:yellow_terracotta
fill 10 224 363 10 226 363 minecraft:honeycomb_block
setblock 14 224 323 minecraft:yellow_terracotta
fill 15 224 323 18 224 323 minecraft:honeycomb_block
fill 17 224 326 17 224 329 minecraft:brown_terracotta
fill 18 224 325 20 224 325 minecraft:brown_terracotta
setblock 18 224 330 minecraft:brown_terracotta
setblock 19 224 323 minecraft:yellow_terracotta
fill 19 224 324 22 224 324 minecraft:honeycomb_block
fill 19 224 331 21 224 331 minecraft:brown_terracotta
fill 20 224 323 23 224 323 minecraft:honeycomb_block
fill 20 224 363 23 224 363 minecraft:honeycomb_block
fill 21 224 322 21 266 322 minecraft:honeycomb_block
setblock 21 224 325 minecraft:honeycomb_block
setblock 22 224 325 minecraft:yellow_terracotta
setblock 22 224 326 minecraft:brown_terracotta
setblock 22 224 330 minecraft:brown_terracotta
setblock 23 224 324 minecraft:yellow_terracotta
fill 23 224 325 23 227 325 minecraft:honeycomb_block
fill 23 224 327 23 224 329 minecraft:brown_terracotta
fill 23 224 362 24 224 362 minecraft:honeycomb_block
setblock 24 224 323 minecraft:yellow_terracotta
fill 24 224 324 24 227 324 minecraft:honeycomb_block
fill 24 224 326 25 224 326 minecraft:honeycomb_block
setblock 24 224 363 minecraft:yellow_terracotta
fill 25 224 323 25 227 323 minecraft:honeycomb_block
setblock 25 224 362 minecraft:yellow_terracotta
fill 25 224 363 28 224 363 minecraft:honeycomb_block
setblock 26 224 326 minecraft:yellow_terracotta
fill 26 224 362 29 224 362 minecraft:honeycomb_block
setblock 27 224 325 minecraft:yellow_terracotta
fill 27 224 326 27 227 326 minecraft:honeycomb_block
setblock 28 224 324 minecraft:yellow_terracotta
fill 28 224 325 28 227 325 minecraft:honeycomb_block
setblock 29 224 323 minecraft:yellow_terracotta
fill 29 224 324 29 227 324 minecraft:honeycomb_block
setblock 29 224 363 minecraft:yellow_terracotta
fill 30 224 323 30 227 323 minecraft:honeycomb_block
setblock 30 224 362 minecraft:yellow_terracotta
fill 30 224 363 33 224 363 minecraft:honeycomb_block
setblock 31 224 326 minecraft:yellow_terracotta
fill 31 224 362 31 225 362 minecraft:honeycomb_block
setblock 32 224 325 minecraft:yellow_terracotta
setblock 33 224 324 minecraft:yellow_terracotta
fill 33 224 325 34 224 325 minecraft:honeycomb_block
setblock 34 224 323 minecraft:yellow_terracotta
fill 34 224 324 34 227 324 minecraft:honeycomb_block
fill 34 224 346 37 271 348 minecraft:yellow_terracotta
setblock 34 224 363 minecraft:yellow_terracotta
fill 35 224 323 35 227 323 minecraft:honeycomb_block
fill 35 224 345 36 271 345 minecraft:yellow_terracotta
fill 35 224 349 36 271 349 minecraft:yellow_terracotta
setblock 35 224 353 minecraft:brown_terracotta
setblock 35 224 355 minecraft:brown_terracotta
setblock 35 224 362 minecraft:yellow_terracotta
fill 35 224 363 35 227 363 minecraft:honeycomb_block
setblock 36 224 362 minecraft:honeycomb_block
setblock 37 224 353 minecraft:brown_terracotta
setblock 37 224 355 minecraft:brown_terracotta
fill 38 224 322 38 308 322 minecraft:honeycomb_block
setblock 38 224 324 minecraft:yellow_terracotta
setblock 39 224 323 minecraft:yellow_terracotta
fill 39 224 324 39 227 324 minecraft:honeycomb_block
setblock 39 224 363 minecraft:yellow_terracotta
fill 40 224 323 40 227 323 minecraft:honeycomb_block
setblock 40 224 362 minecraft:yellow_terracotta
fill 40 224 363 40 227 363 minecraft:honeycomb_block
setblock 41 224 326 minecraft:yellow_terracotta
fill 41 224 327 41 227 327 minecraft:honeycomb_block
fill 41 224 329 41 225 329 minecraft:honeycomb_block
fill 41 224 332 41 225 332 minecraft:honey_block
setblock 41 224 338 minecraft:honey_block
setblock 41 224 341 minecraft:yellow_terracotta
fill 41 224 342 41 227 342 minecraft:honeycomb_block
setblock 41 224 346 minecraft:yellow_terracotta
fill 41 224 347 41 227 347 minecraft:honeycomb_block
setblock 41 224 351 minecraft:yellow_terracotta
fill 41 224 352 41 225 354 minecraft:honeycomb_block
setblock 41 224 356 minecraft:yellow_terracotta
fill 41 224 357 41 227 357 minecraft:honeycomb_block
setblock 41 224 361 minecraft:yellow_terracotta
fill 41 224 362 41 227 362 minecraft:honeycomb_block
fill 0 225 350 0 308 350 minecraft:honeycomb_block
fill 0 225 360 0 294 360 minecraft:honeycomb_block
fill 1 225 323 1 225 324 minecraft:honeycomb_block
setblock 1 225 325 minecraft:yellow_terracotta
fill 1 225 326 1 228 326 minecraft:honeycomb_block
fill 1 225 328 1 226 328 minecraft:honeycomb_block
setblock 1 225 335 minecraft:honey_block
setblock 1 225 340 minecraft:yellow_terracotta
fill 1 225 341 1 228 341 minecraft:honeycomb_block
setblock 1 225 345 minecraft:yellow_terracotta
fill 1 225 346 1 228 346 minecraft:honeycomb_block
setblock 1 225 349 minecraft:honeycomb_block
setblock 1 225 350 minecraft:yellow_terracotta
fill 1 225 351 1 225 354 minecraft:honeycomb_block
setblock 1 225 355 minecraft:yellow_terracotta
fill 1 225 356 1 228 356 minecraft:honeycomb_block
setblock 1 225 360 minecraft:yellow_terracotta
fill 1 225 361 1 226 363 minecraft:honeycomb_block
setblock 2 225 323 minecraft:honeycomb_block
setblock 2 225 324 minecraft:yellow_terracotta
fill 2 225 325 2 228 325 minecraft:honeycomb_block
fill 2 225 340 2 226 340 minecraft:honeycomb_block
setblock 2 225 344 minecraft:yellow_terracotta
fill 2 225 345 2 228 345 minecraft:honeycomb_block
setblock 2 225 348 minecraft:honeycomb_block
setblock 2 225 349 minecraft:yellow_terracotta
fill 2 225 350 2 225 353 minecraft:honeycomb_block
setblock 2 225 354 minecraft:yellow_terracotta
fill 2 225 355 2 228 355 minecraft:honeycomb_block
setblock 2 225 359 minecraft:yellow_terracotta
fill 2 225 360 2 226 360 minecraft:honeycomb_block
fill 2 225 362 2 225 363 minecraft:honeycomb_block
setblock 3 225 323 minecraft:yellow_terracotta
fill 3 225 324 3 228 324 minecraft:honeycomb_block
setblock 3 225 325 minecraft:light[level=12]
setblock 3 225 332 minecraft:light[level=12]
setblock 3 225 339 minecraft:light[level=12]
setblock 3 225 343 minecraft:yellow_terracotta
fill 3 225 344 3 228 344 minecraft:honeycomb_block
setblock 3 225 348 minecraft:yellow_terracotta
fill 3 225 349 3 228 349 minecraft:honeycomb_block
setblock 3 225 352 minecraft:honeycomb_block
setblock 3 225 353 minecraft:light[level=12]
setblock 3 225 360 minecraft:light[level=12]
setblock 3 225 362 minecraft:honeycomb_block
setblock 3 225 363 minecraft:yellow_terracotta
fill 4 225 323 4 228 323 minecraft:honeycomb_block
fill 4 225 343 4 226 343 minecraft:honeycomb_block
setblock 4 225 347 minecraft:yellow_terracotta
fill 4 225 348 4 228 348 minecraft:honeycomb_block
setblock 4 225 362 minecraft:yellow_terracotta
fill 4 225 363 7 225 363 minecraft:honeycomb_block
fill 5 225 362 5 227 362 minecraft:honeycomb_block
setblock 7 225 324 minecraft:yellow_terracotta
setblock 8 225 323 minecraft:yellow_terracotta
fill 8 225 324 8 227 324 minecraft:honeycomb_block
setblock 8 225 363 minecraft:yellow_terracotta
fill 9 225 323 9 228 323 minecraft:honeycomb_block
setblock 9 225 362 minecraft:yellow_terracotta
fill 9 225 363 9 226 363 minecraft:honeycomb_block
setblock 10 225 325 minecraft:light[level=12]
setblock 10 225 332 minecraft:light[level=12]
setblock 10 225 339 minecraft:light[level=12]
setblock 10 225 346 minecraft:light[level=12]
setblock 10 225 353 minecraft:light[level=12]
setblock 10 225 360 minecraft:light[level=12]
setblock 13 225 323 minecraft:yellow_terracotta
fill 14 225 323 17 225 323 minecraft:honeycomb_block
setblock 17 225 325 minecraft:light[level=12]
setblock 17 225 332 minecraft:light[level=12]
setblock 17 225 339 minecraft:light[level=12]
setblock 17 225 346 minecraft:light[level=12]
setblock 17 225 353 minecraft:light[level=12]
setblock 17 225 360 minecraft:light[level=12]
setblock 17 225 363 minecraft:honey_block
setblock 18 225 323 minecraft:yellow_terracotta
fill 19 225 323 21 225 324 minecraft:honeycomb_block
fill 20 225 363 22 225 363 minecraft:honeycomb_block
setblock 21 225 325 minecraft:yellow_terracotta
setblock 22 225 323 minecraft:honeycomb_block
setblock 22 225 324 minecraft:yellow_terracotta
fill 22 225 325 22 228 325 minecraft:honeycomb_block
setblock 23 225 323 minecraft:yellow_terracotta
fill 23 225 324 23 228 324 minecraft:honeycomb_block
fill 23 225 326 24 225 326 minecraft:honeycomb_block
setblock 23 225 363 minecraft:yellow_terracotta
fill 24 225 323 24 228 323 minecraft:honeycomb_block
setblock 24 225 332 minecraft:light[level=12]
setblock 24 225 339 minecraft:light[level=12]
setblock 24 225 346 minecraft:light[level=12]
setblock 24 225 353 minecraft:light[level=12]
setblock 24 225 360 minecraft:light[level=12]
setblock 24 225 362 minecraft:yellow_terracotta
fill 24 225 363 27 225 363 minecraft:honeycomb_block
setblock 25 225 326 minecraft:yellow_terracotta
fill 25 225 362 28 225 362 minecraft:honeycomb_block
setblock 26 225 325 minecraft:yellow_terracotta
fill 26 225 326 26 228 326 minecraft:honeycomb_block
setblock 27 225 324 minecraft:yellow_terracotta
fill 27 225 325 27 228 325 minecraft:honeycomb_block
setblock 28 225 323 minecraft:yellow_terracotta
fill 28 225 324 28 228 324 minecraft:honeycomb_block
setblock 28 225 363 minecraft:yellow_terracotta
fill 29 225 323 29 228 323 minecraft:honeycomb_block
setblock 29 225 362 minecraft:yellow_terracotta
fill 29 225 363 32 225 363 minecraft:honeycomb_block
setblock 30 225 326 minecraft:yellow_terracotta
fill 30 225 362 30 226 362 minecraft:honeycomb_block
setblock 31 225 325 minecraft:yellow_terracotta
setblock 31 225 332 minecraft:light[level=12]
setblock 31 225 339 minecraft:light[level=12]
fill 31 225 341 32 226 342 minecraft:yellow_concrete
setblock 31 225 346 minecraft:light[level=12]
setblock 31 225 353 minecraft:light[level=12]
setblock 31 225 360 minecraft:light[level=12]
setblock 32 225 324 minecraft:yellow_terracotta
fill 32 225 325 33 225 325 minecraft:honeycomb_block
setblock 33 225 323 minecraft:yellow_terracotta
fill 33 225 324 33 228 324 minecraft:honeycomb_block
fill 33 225 345 33 226 349 minecraft:brown_terracotta
setblock 33 225 363 minecraft:yellow_terracotta
fill 34 225 323 34 228 323 minecraft:honeycomb_block
fill 34 225 345 34 226 345 minecraft:brown_terracotta
fill 34 225 349 34 226 350 minecraft:brown_terracotta
fill 34 225 363 34 227 363 minecraft:honeycomb_block
fill 35 225 344 36 226 344 minecraft:brown_terracotta
fill 35 225 350 37 226 350 minecraft:brown_terracotta
setblock 37 225 324 minecraft:yellow_terracotta
fill 37 225 345 38 226 345 minecraft:brown_terracotta
fill 37 225 349 38 226 349 minecraft:brown_terracotta
setblock 38 225 323 minecraft:yellow_terracotta
fill 38 225 324 38 227 324 minecraft:honeycomb_block
setblock 38 225 325 minecraft:light[level=12]
setblock 38 225 332 minecraft:light[level=12]
setblock 38 225 339 minecraft:light[level=12]
fill 38 225 346 38 226 348 minecraft:brown_terracotta
setblock 38 225 353 minecraft:light[level=12]
setblock 38 225 360 minecraft:light[level=12]
setblock 38 225 363 minecraft:yellow_terracotta
fill 39 225 323 39 228 323 minecraft:honeycomb_block
setblock 39 225 362 minecraft:yellow_terracotta
fill 39 225 363 39 228 363 minecraft:honeycomb_block
setblock 40 225 326 minecraft:yellow_terracotta
setblock 40 225 361 minecraft:yellow_terracotta
fill 40 225 362 40 227 362 minecraft:honeycomb_block
setblock 41 225 325 minecraft:yellow_terracotta
fill 41 225 326 41 228 326 minecraft:honeycomb_block
setblock 41 225 341 minecraft:honeycomb_block
setblock 41 225 345 minecraft:yellow_terracotta
fill 41 225 346 41 228 346 minecraft:honeycomb_block
fill 41 225 348 41 225 349 minecraft:honeycomb_block
setblock 41 225 350 minecraft:yellow_terracotta
fill 41 225 351 41 228 351 minecraft:honeycomb_block
setblock 41 225 355 minecraft:yellow_terracotta
fill 41 225 356 41 228 356 minecraft:honeycomb_block
setblock 41 225 360 minecraft:yellow_terracotta
fill 41 225 361 41 228 361 minecraft:honeycomb_block
setblock 42 225 327 minecraft:yellow_terracotta
setblock 0 226 361 minecraft:orange_terracotta
setblock 1 226 323 minecraft:honeycomb_block
setblock 1 226 324 minecraft:yellow_terracotta
fill 1 226 325 1 229 325 minecraft:honeycomb_block
setblock 1 226 339 minecraft:yellow_terracotta
fill 1 226 340 1 229 340 minecraft:honeycomb_block
setblock 1 226 344 minecraft:yellow_terracotta
fill 1 226 345 1 229 345 minecraft:honeycomb_block
setblock 1 226 349 minecraft:yellow_terracotta
fill 1 226 350 1 226 353 minecraft:honeycomb_block
setblock 1 226 354 minecraft:yellow_terracotta
fill 1 226 355 1 229 355 minecraft:honeycomb_block
fill 1 226 357 1 226 358 minecraft:honeycomb_block
setblock 1 226 359 minecraft:yellow_terracotta
fill 1 226 360 1 229 360 minecraft:honeycomb_block
setblock 2 226 323 minecraft:yellow_terracotta
fill 2 226 324 2 227 324 minecraft:honeycomb_block
fill 2 226 326 2 227 326 minecraft:honeycomb_block
setblock 2 226 343 minecraft:yellow_terracotta
fill 2 226 344 2 229 344 minecraft:honeycomb_block
setblock 2 226 348 minecraft:yellow_terracotta
fill 2 226 349 2 226 352 minecraft:honeycomb_block
setblock 2 226 353 minecraft:yellow_terracotta
fill 2 226 354 2 229 354 minecraft:honeycomb_block
setblock 2 226 362 minecraft:honeycomb_block
setblock 2 226 363 minecraft:yellow_terracotta
fill 3 226 323 3 229 323 minecraft:honeycomb_block
setblock 3 226 342 minecraft:yellow_terracotta
fill 3 226 343 3 229 343 minecraft:honeycomb_block
setblock 3 226 346 minecraft:honeycomb_block
setblock 3 226 347 minecraft:yellow_terracotta
fill 3 226 348 3 229 348 minecraft:honeycomb_block
setblock 3 226 352 minecraft:yellow_terracotta
setblock 3 226 362 minecraft:yellow_terracotta
fill 3 226 363 6 226 363 minecraft:honeycomb_block
setblock 4 226 346 minecraft:yellow_terracotta
fill 4 226 347 4 229 347 minecraft:honeycomb_block
setblock 4 226 350 minecraft:honeycomb_block
fill 4 226 362 4 227 362 minecraft:honeycomb_block
setblock 6 226 324 minecraft:yellow_terracotta
setblock 7 226 323 minecraft:yellow_terracotta
fill 7 226 324 7 227 324 minecraft:honeycomb_block
setblock 7 226 363 minecraft:yellow_terracotta
fill 8 226 323 8 229 323 minecraft:honeycomb_block
fill 8 226 363 8 227 363 minecraft:honeycomb_block
setblock 11 226 364 minecraft:orange_terracotta
setblock 12 226 323 minecraft:yellow_terracotta
fill 13 226 323 16 226 323 minecraft:honeycomb_block
setblock 15 226 322 minecraft:orange_terracotta
setblock 17 226 323 minecraft:yellow_terracotta
fill 18 226 323 21 226 323 minecraft:honeycomb_block
fill 19 226 324 20 226 324 minecraft:honeycomb_block
setblock 21 226 324 minecraft:yellow_terracotta
fill 21 226 325 21 229 325 minecraft:honeycomb_block
setblock 21 226 363 minecraft:honeycomb_block
setblock 21 226 364 minecraft:orange_terracotta
setblock 22 226 323 minecraft:yellow_terracotta
fill 22 226 324 22 229 324 minecraft:honeycomb_block
setblock 22 226 363 minecraft:yellow_terracotta
fill 23 226 323 23 229 323 minecraft:honeycomb_block
setblock 23 226 326 minecraft:honeycomb_block
fill 23 226 363 26 226 363 minecraft:honeycomb_block
setblock 24 226 326 minecraft:yellow_terracotta
fill 24 226 362 27 226 362 minecraft:honeycomb_block
setblock 25 226 325 minecraft:yellow_terracotta
fill 25 226 326 25 229 326 minecraft:honeycomb_block
setblock 26 226 324 minecraft:yellow_terracotta
fill 26 226 325 26 229 325 minecraft:honeycomb_block
setblock 27 226 323 minecraft:yellow_terracotta
fill 27 226 324 27 229 324 minecraft:honeycomb_block
setblock 27 226 363 minecraft:yellow_terracotta
fill 28 226 323 28 229 323 minecraft:honeycomb_block
setblock 28 226 362 minecraft:yellow_terracotta
fill 28 226 363 31 226 363 minecraft:honeycomb_block
setblock 29 226 326 minecraft:yellow_terracotta
setblock 29 226 362 minecraft:honeycomb_block
setblock 30 226 325 minecraft:yellow_terracotta
setblock 31 226 324 minecraft:yellow_terracotta
fill 31 226 325 32 226 325 minecraft:honeycomb_block
setblock 32 226 323 minecraft:yellow_terracotta
fill 32 226 324 32 229 324 minecraft:honeycomb_block
fill 32 226 345 32 226 349 minecraft:brown_terracotta
setblock 32 226 363 minecraft:yellow_terracotta
fill 33 226 323 33 229 323 minecraft:honeycomb_block
fill 33 226 344 34 226 344 minecraft:brown_terracotta
setblock 33 226 350 minecraft:brown_terracotta
fill 33 226 363 33 228 363 minecraft:honeycomb_block
fill 34 226 351 37 226 351 minecraft:brown_terracotta
fill 35 226 343 36 226 343 minecraft:brown_terracotta
setblock 36 226 324 minecraft:yellow_terracotta
setblock 37 226 323 minecraft:yellow_terracotta
fill 37 226 324 37 227 324 minecraft:honeycomb_block
fill 37 226 344 38 226 344 minecraft:brown_terracotta
setblock 37 226 363 minecraft:yellow_terracotta
fill 38 226 323 38 229 323 minecraft:honeycomb_block
setblock 38 226 350 minecraft:brown_terracotta
fill 38 226 363 38 229 363 minecraft:honeycomb_block
fill 39 226 345 39 226 349 minecraft:brown_terracotta
setblock 39 226 362 minecraft:honeycomb_block
setblock 40 226 325 minecraft:yellow_terracotta
fill 40 226 326 40 229 326 minecraft:honeycomb_block
setblock 40 226 361 minecraft:honeycomb_block
setblock 41 226 324 minecraft:yellow_terracotta
fill 41 226 325 41 229 325 minecraft:honeycomb_block
setblock 41 226 329 minecraft:yellow_terracotta
setblock 41 226 344 minecraft:yellow_terracotta
fill 41 226 345 41 229 345 minecraft:honeycomb_block
setblock 41 226 348 minecraft:honeycomb_block
setblock 41 226 349 minecraft:yellow_terracotta
fill 41 226 350 41 229 350 minecraft:honeycomb_block
fill 41 226 352 41 226 353 minecraft:honeycomb_block
setblock 41 226 354 minecraft:yellow_terracotta
fill 41 226 355 41 229 355 minecraft:honeycomb_block
setblock 41 226 359 minecraft:yellow_terracotta
fill 41 226 360 41 229 360 minecraft:honeycomb_block
fill 42 226 327 42 244 327 minecraft:honeycomb_block
setblock 42 226 358 minecraft:yellow_terracotta
setblock 0 227 347 minecraft:yellow_terracotta
fill 0 227 361 1 228 361 minecraft:honeycomb_block
setblock 1 227 323 minecraft:yellow_terracotta
fill 1 227 324 1 230 324 minecraft:honeycomb_block
setblock 1 227 328 minecraft:yellow_terracotta
fill 1 227 329 1 230 329 minecraft:honeycomb_block
setblock 1 227 339 minecraft:honeycomb_block
setblock 1 227 343 minecraft:yellow_terracotta
fill 1 227 344 1 230 344 minecraft:honeycomb_block
setblock 1 227 348 minecraft:yellow_terracotta
fill 1 227 349 1 227 352 minecraft:honeycomb_block
setblock 1 227 353 minecraft:yellow_terracotta
fill 1 227 354 1 230 354 minecraft:honeycomb_block
setblock 1 227 357 minecraft:honeycomb_block
setblock 1 227 358 minecraft:yellow_terracotta
fill 1 227 359 1 230 359 minecraft:honeycomb_block
setblock 1 227 362 minecraft:honeycomb_block
setblock 1 227 363 minecraft:yellow_terracotta
fill 2 227 323 2 230 323 minecraft:honeycomb_block
setblock 2 227 342 minecraft:yellow_terracotta
fill 2 227 343 2 230 343 minecraft:honeycomb_block
setblock 2 227 347 minecraft:yellow_terracotta
fill 2 227 348 2 227 351 minecraft:honeycomb_block
setblock 2 227 352 minecraft:yellow_terracotta
fill 2 227 353 2 230 353 minecraft:honeycomb_block
setblock 2 227 362 minecraft:yellow_terracotta
fill 2 227 363 5 227 363 minecraft:honeycomb_block
setblock 3 227 342 minecraft:honeycomb_block
setblock 3 227 346 minecraft:yellow_terracotta
fill 3 227 347 3 230 347 minecraft:honeycomb_block
setblock 3 227 350 minecraft:honeycomb_block
setblock 3 227 351 minecraft:yellow_terracotta
fill 3 227 352 3 230 352 minecraft:honeycomb_block
setblock 3 227 362 minecraft:honeycomb_block
setblock 4 227 345 minecraft:yellow_terracotta
fill 4 227 346 4 230 346 minecraft:honeycomb_block
setblock 4 227 350 minecraft:yellow_terracotta
setblock 5 227 324 minecraft:yellow_terracotta
setblock 6 227 323 minecraft:yellow_terracotta
fill 6 227 324 6 228 324 minecraft:honeycomb_block
setblock 6 227 363 minecraft:yellow_terracotta
fill 7 227 323 7 229 323 minecraft:honeycomb_block
fill 7 227 363 7 228 363 minecraft:honeycomb_block
setblock 10 227 363 minecraft:honey_block
setblock 11 227 323 minecraft:yellow_terracotta
fill 11 227 364 11 260 364 minecraft:honeycomb_block
setblock 13 227 323 minecraft:honey_block
fill 15 227 322 15 232 322 minecraft:honeycomb_block
setblock 16 227 323 minecraft:yellow_terracotta
fill 17 227 323 20 227 323 minecraft:honeycomb_block
setblock 19 227 324 minecraft:honeycomb_block
setblock 20 227 324 minecraft:yellow_terracotta
setblock 21 227 323 minecraft:yellow_terracotta
fill 21 227 324 21 230 324 minecraft:honeycomb_block
setblock 21 227 363 minecraft:yellow_terracotta
fill 21 227 364 21 262 364 minecraft:honeycomb_block
fill 22 227 323 22 230 323 minecraft:honeycomb_block
fill 22 227 363 25 227 363 minecraft:honeycomb_block
setblock 23 227 326 minecraft:yellow_terracotta
setblock 24 227 325 minecraft:yellow_terracotta
fill 24 227 326 24 230 326 minecraft:honeycomb_block
setblock 25 227 324 minecraft:yellow_terracotta
fill 25 227 325 25 230 325 minecraft:honeycomb_block
fill 26 227 322 26 267 322 minecraft:honeycomb_block
setblock 26 227 323 minecraft:yellow_terracotta
fill 26 227 324 26 230 324 minecraft:honeycomb_block
setblock 26 227 362 minecraft:honeycomb_block
setblock 26 227 363 minecraft:yellow_terracotta
fill 27 227 323 27 230 323 minecraft:honeycomb_block
setblock 27 227 362 minecraft:yellow_terracotta
fill 27 227 363 30 227 363 minecraft:honeycomb_block
setblock 28 227 326 minecraft:yellow_terracotta
setblock 29 227 325 minecraft:yellow_terracotta
setblock 30 227 324 minecraft:yellow_terracotta
fill 30 227 325 31 227 325 minecraft:honeycomb_block
setblock 31 227 323 minecraft:yellow_terracotta
fill 31 227 324 31 229 324 minecraft:honeycomb_block
setblock 31 227 363 minecraft:yellow_terracotta
fill 32 227 323 32 230 323 minecraft:honeycomb_block
fill 32 227 363 32 228 363 minecraft:honeycomb_block
setblock 35 227 324 minecraft:yellow_terracotta
setblock 36 227 323 minecraft:yellow_terracotta
setblock 36 227 324 minecraft:honeycomb_block
setblock 36 227 363 minecraft:yellow_terracotta
setblock 37 227 322 minecraft:orange_terracotta
fill 37 227 323 37 230 323 minecraft:honeycomb_block
fill 37 227 363 37 229 363 minecraft:honeycomb_block
setblock 40 227 324 minecraft:yellow_terracotta
fill 40 227 325 40 230 325 minecraft:honeycomb_block
fill 40 227 347 40 227 348 minecraft:honeycomb_block
setblock 40 227 349 minecraft:yellow_terracotta
setblock 41 227 323 minecraft:yellow_terracotta
fill 41 227 324 41 230 324 minecraft:honeycomb_block
setblock 41 227 328 minecraft:yellow_terracotta
fill 41 227 329 41 230 329 minecraft:honeycomb_block
setblock 41 227 339 minecraft:honey_block
setblock 41 227 343 minecraft:yellow_terracotta
fill 41 227 344 41 230 344 minecraft:honeycomb_block
setblock 41 227 348 minecraft:yellow_terracotta
fill 41 227 349 41 230 349 minecraft:honeycomb_block
setblock 41 227 352 minecraft:honeycomb_block
setblock 41 227 353 minecraft:yellow_terracotta
fill 41 227 354 41 230 354 minecraft:honeycomb_block
setblock 41 227 358 minecraft:yellow_terracotta
fill 41 227 359 41 230 359 minecraft:honeycomb_block
setblock 41 227 363 minecraft:yellow_terracotta
fill 42 227 358 42 308 358 minecraft:honeycomb_block
fill 0 228 347 0 244 347 minecraft:honeycomb_block
fill 1 228 323 1 231 323 minecraft:honeycomb_block
setblock 1 228 327 minecraft:yellow_terracotta
fill 1 228 328 1 231 328 minecraft:honeycomb_block
fill 1 228 330 1 229 330 minecraft:honeycomb_block
setblock 1 228 334 minecraft:honey_block
setblock 1 228 342 minecraft:yellow_terracotta
fill 1 228 343 1 231 343 minecraft:honeycomb_block
setblock 1 228 347 minecraft:yellow_terracotta
fill 1 228 348 1 228 351 minecraft:honeycomb_block
setblock 1 228 352 minecraft:yellow_terracotta
fill 1 228 353 1 231 353 minecraft:honeycomb_block
setblock 1 228 357 minecraft:yellow_terracotta
fill 1 228 358 1 231 358 minecraft:honeycomb_block
setblock 1 228 362 minecraft:yellow_terracotta
fill 1 228 363 4 228 363 minecraft:honeycomb_block
setblock 2 228 326 minecraft:yellow_terracotta
setblock 2 228 341 minecraft:yellow_terracotta
fill 2 228 342 2 231 342 minecraft:honeycomb_block
setblock 2 228 346 minecraft:yellow_terracotta
fill 2 228 347 2 228 350 minecraft:honeycomb_block
setblock 2 228 351 minecraft:yellow_terracotta
fill 2 228 352 2 231 352 minecraft:honeycomb_block
setblock 3 228 345 minecraft:yellow_terracotta
fill 3 228 346 3 231 346 minecraft:honeycomb_block
setblock 3 228 350 minecraft:yellow_terracotta
fill 3 228 351 3 231 351 minecraft:honeycomb_block
fill 3 228 353 3 229 353 minecraft:honeycomb_block
setblock 4 228 324 minecraft:yellow_terracotta
setblock 4 228 345 minecraft:honeycomb_block
setblock 4 228 349 minecraft:yellow_terracotta
fill 4 228 350 4 231 350 minecraft:honeycomb_block
setblock 5 228 323 minecraft:yellow_terracotta
setblock 5 228 324 minecraft:honeycomb_block
setblock 5 228 363 minecraft:yellow_terracotta
fill 6 228 323 6 230 323 minecraft:honeycomb_block
setblock 6 228 363 minecraft:honeycomb_block
setblock 16 228 363 minecraft:honey_block
fill 17 228 323 19 228 323 minecraft:honeycomb_block
setblock 19 228 324 minecraft:yellow_terracotta
setblock 20 228 323 minecraft:yellow_terracotta
fill 20 228 324 20 230 325 minecraft:honeycomb_block
fill 21 228 323 21 231 323 minecraft:honeycomb_block
fill 22 228 363 24 228 363 minecraft:honeycomb_block
setblock 23 228 325 minecraft:yellow_terracotta
fill 23 228 326 23 231 326 minecraft:honeycomb_block
setblock 24 228 324 minecraft:yellow_terracotta
fill 24 228 325 24 231 325 minecraft:honeycomb_block
setblock 25 228 323 minecraft:yellow_terracotta
fill 25 228 324 25 231 324 minecraft:honeycomb_block
setblock 25 228 363 minecraft:yellow_terracotta
fill 26 228 323 26 231 323 minecraft:honeycomb_block
fill 26 228 363 29 228 363 minecraft:honeycomb_block
setblock 27 228 326 minecraft:yellow_terracotta
fill 27 228 358 27 235 358 minecraft:brown_terracotta
setblock 28 228 325 minecraft:yellow_terracotta
setblock 29 228 324 minecraft:yellow_terracotta
fill 29 228 325 30 228 325 minecraft:honeycomb_block
setblock 30 228 323 minecraft:yellow_terracotta
fill 30 228 324 30 231 324 minecraft:honeycomb_block
setblock 30 228 363 minecraft:yellow_terracotta
fill 31 228 323 31 231 323 minecraft:honeycomb_block
setblock 31 228 363 minecraft:honeycomb_block
setblock 35 228 323 minecraft:yellow_terracotta
setblock 35 228 363 minecraft:honey_block
setblock 35 228 364 minecraft:yellow_terracotta
fill 36 228 323 36 231 323 minecraft:honeycomb_block
setblock 36 228 363 minecraft:honeycomb_block
fill 37 228 322 37 235 322 minecraft:honeycomb_block
setblock 39 228 324 minecraft:yellow_terracotta
setblock 40 228 323 minecraft:yellow_terracotta
fill 40 228 324 40 230 324 minecraft:honeycomb_block
setblock 40 228 347 minecraft:honeycomb_block
setblock 40 228 348 minecraft:yellow_terracotta
fill 40 228 349 40 229 351 minecraft:honeycomb_block
setblock 40 228 363 minecraft:yellow_terracotta
fill 41 228 323 41 231 323 minecraft:honeycomb_block
setblock 41 228 327 minecraft:yellow_terracotta
fill 41 228 328 41 231 328 minecraft:honeycomb_block
fill 41 228 330 41 229 330 minecraft:honeycomb_block
setblock 41 228 333 minecraft:honey_block
fill 41 228 343 41 231 343 minecraft:honeycomb_block
setblock 41 228 347 minecraft:yellow_terracotta
fill 41 228 348 41 231 348 minecraft:honeycomb_block
setblock 41 228 352 minecraft:yellow_terracotta
fill 41 228 353 41 231 353 minecraft:honeycomb_block
setblock 41 228 357 minecraft:yellow_terracotta
fill 41 228 358 41 231 358 minecraft:honeycomb_block
setblock 41 228 362 minecraft:yellow_terracotta
fill 41 228 363 41 231 363 minecraft:honeycomb_block
fill 0 229 361 0 281 361 minecraft:honeycomb_block
setblock 1 229 326 minecraft:yellow_terracotta
fill 1 229 327 2 231 327 minecraft:honeycomb_block
setblock 1 229 331 minecraft:yellow_terracotta
setblock 1 229 341 minecraft:yellow_terracotta
fill 1 229 342 1 232 342 minecraft:honeycomb_block
setblock 1 229 346 minecraft:yellow_terracotta
fill 1 229 347 1 229 350 minecraft:honeycomb_block
setblock 1 229 351 minecraft:yellow_terracotta
fill 1 229 352 1 232 352 minecraft:honeycomb_block
setblock 1 229 356 minecraft:yellow_terracotta
fill 1 229 357 1 232 357 minecraft:honeycomb_block
setblock 1 229 361 minecraft:yellow_terracotta
fill 1 229 362 1 231 363 minecraft:honeycomb_block
fill 2 229 326 2 232 326 minecraft:honeycomb_block
setblock 2 229 341 minecraft:honeycomb_block
setblock 2 229 345 minecraft:yellow_terracotta
fill 2 229 346 2 229 349 minecraft:honeycomb_block
setblock 2 229 350 minecraft:yellow_terracotta
fill 2 229 351 2 232 351 minecraft:honeycomb_block
setblock 2 229 355 minecraft:yellow_terracotta
fill 2 229 363 3 229 363 minecraft:honeycomb_block
setblock 3 229 344 minecraft:yellow_terracotta
fill 3 229 345 3 232 345 minecraft:honeycomb_block
setblock 3 229 349 minecraft:yellow_terracotta
fill 3 229 350 3 232 350 minecraft:honeycomb_block
setblock 4 229 323 minecraft:yellow_terracotta
setblock 4 229 348 minecraft:yellow_terracotta
fill 4 229 349 4 232 349 minecraft:honeycomb_block
setblock 4 229 363 minecraft:yellow_terracotta
fill 5 229 323 5 231 323 minecraft:honeycomb_block
setblock 5 229 363 minecraft:honeycomb_block
fill 17 229 323 18 229 323 minecraft:honeycomb_block
setblock 19 229 323 minecraft:yellow_terracotta
fill 19 229 324 19 232 324 minecraft:honeycomb_block
fill 20 229 323 20 232 323 minecraft:honeycomb_block
setblock 22 229 325 minecraft:yellow_terracotta
fill 22 229 326 22 232 326 minecraft:honeycomb_block
fill 22 229 363 23 229 363 minecraft:honeycomb_block
setblock 23 229 324 minecraft:yellow_terracotta
fill 23 229 325 23 232 325 minecraft:honeycomb_block
setblock 24 229 323 minecraft:yellow_terracotta
fill 24 229 324 24 232 324 minecraft:honeycomb_block
setblock 24 229 363 minecraft:yellow_terracotta
fill 25 229 323 25 232 323 minecraft:honeycomb_block
fill 25 229 363 28 229 363 minecraft:honeycomb_block
setblock 26 229 326 minecraft:yellow_terracotta
setblock 27 229 325 minecraft:yellow_terracotta
setblock 28 229 324 minecraft:yellow_terracotta
fill 28 229 325 29 229 325 minecraft:honeycomb_block
setblock 29 229 323 minecraft:yellow_terracotta
fill 29 229 324 29 232 324 minecraft:honeycomb_block
setblock 29 229 363 minecraft:yellow_terracotta
fill 30 229 323 30 232 323 minecraft:honeycomb_block
setblock 30 229 363 minecraft:honeycomb_block
setblock 34 229 323 minecraft:yellow_terracotta
fill 35 229 323 35 231 323 minecraft:honeycomb_block
fill 35 229 364 35 248 364 minecraft:honeycomb_block
setblock 39 229 323 minecraft:yellow_terracotta
setblock 39 229 363 minecraft:yellow_terracotta
fill 40 229 323 40 232 323 minecraft:honeycomb_block
setblock 40 229 347 minecraft:yellow_terracotta
fill 40 229 348 40 232 348 minecraft:honeycomb_block
setblock 40 229 352 minecraft:yellow_terracotta
fill 40 229 353 40 232 353 minecraft:honeycomb_block
fill 40 229 363 40 232 363 minecraft:honeycomb_block
setblock 41 229 326 minecraft:yellow_terracotta
fill 41 229 327 41 232 327 minecraft:honeycomb_block
setblock 41 229 346 minecraft:yellow_terracotta
fill 41 229 347 41 232 347 minecraft:honeycomb_block
setblock 41 229 351 minecraft:yellow_terracotta
fill 41 229 352 41 232 352 minecraft:honeycomb_block
setblock 41 229 356 minecraft:yellow_terracotta
fill 41 229 357 41 232 357 minecraft:honeycomb_block
setblock 41 229 361 minecraft:yellow_terracotta
fill 41 229 362 41 232 362 minecraft:honeycomb_block
setblock 1 230 325 minecraft:yellow_terracotta
fill 1 230 326 1 233 326 minecraft:honeycomb_block
setblock 1 230 330 minecraft:yellow_terracotta
fill 1 230 331 1 231 333 minecraft:honeycomb_block
setblock 1 230 340 minecraft:yellow_terracotta
fill 1 230 341 1 233 341 minecraft:honeycomb_block
setblock 1 230 345 minecraft:yellow_terracotta
fill 1 230 346 1 230 349 minecraft:honeycomb_block
setblock 1 230 350 minecraft:yellow_terracotta
fill 1 230 351 1 233 351 minecraft:honeycomb_block
setblock 1 230 355 minecraft:yellow_terracotta
fill 1 230 356 2 232 356 minecraft:honeycomb_block
setblock 1 230 360 minecraft:yellow_terracotta
fill 1 230 361 1 233 361 minecraft:honeycomb_block
setblock 2 230 328 minecraft:honeycomb_block
setblock 2 230 329 minecraft:yellow_terracotta
setblock 2 230 344 minecraft:yellow_terracotta
fill 2 230 345 2 230 348 minecraft:honeycomb_block
setblock 2 230 349 minecraft:yellow_terracotta
fill 2 230 350 2 233 350 minecraft:honeycomb_block
setblock 2 230 354 minecraft:yellow_terracotta
fill 2 230 355 2 233 355 minecraft:honeycomb_block
setblock 2 230 363 minecraft:honeycomb_block
setblock 3 230 323 minecraft:yellow_terracotta
fill 3 230 344 3 233 344 minecraft:honeycomb_block
setblock 3 230 348 minecraft:yellow_terracotta
fill 3 230 349 3 233 349 minecraft:honeycomb_block
setblock 3 230 353 minecraft:yellow_terracotta
setblock 3 230 363 minecraft:yellow_terracotta
fill 4 230 323 4 233 323 minecraft:honeycomb_block
setblock 4 230 347 minecraft:yellow_terracotta
fill 4 230 348 4 233 348 minecraft:honeycomb_block
setblock 4 230 363 minecraft:honeycomb_block
setblock 10 230 364 minecraft:yellow_concrete
setblock 14 230 323 minecraft:honey_block
setblock 17 230 323 minecraft:honeycomb_block
setblock 18 230 323 minecraft:yellow_terracotta
fill 18 230 324 18 233 324 minecraft:honeycomb_block
fill 19 230 323 19 233 323 minecraft:honeycomb_block
setblock 21 230 325 minecraft:yellow_terracotta
setblock 22 230 324 minecraft:yellow_terracotta
fill 22 230 325 22 233 325 minecraft:honeycomb_block
setblock 22 230 363 minecraft:honeycomb_block
setblock 23 230 323 minecraft:yellow_terracotta
fill 23 230 324 23 233 324 minecraft:honeycomb_block
setblock 23 230 363 minecraft:yellow_terracotta
fill 24 230 323 24 233 323 minecraft:honeycomb_block
fill 24 230 363 27 230 363 minecraft:honeycomb_block
setblock 25 230 326 minecraft:yellow_terracotta
setblock 26 230 325 minecraft:yellow_terracotta
setblock 26 230 326 minecraft:honeycomb_block
setblock 27 230 324 minecraft:yellow_terracotta
fill 27 230 325 28 230 325 minecraft:honeycomb_block
setblock 28 230 323 minecraft:yellow_terracotta
fill 28 230 324 28 233 324 minecraft:honeycomb_block
setblock 28 230 363 minecraft:yellow_terracotta
fill 29 230 323 29 233 323 minecraft:honeycomb_block
setblock 33 230 323 minecraft:yellow_terracotta
setblock 34 230 323 minecraft:honeycomb_block
setblock 38 230 323 minecraft:yellow_terracotta
setblock 38 230 363 minecraft:yellow_terracotta
fill 39 230 323 39 233 323 minecraft:honeycomb_block
fill 39 230 363 39 233 363 minecraft:honeycomb_block
setblock 40 230 326 minecraft:yellow_terracotta
fill 40 230 327 40 233 327 minecraft:honeycomb_block
setblock 40 230 346 minecraft:yellow_terracotta
fill 40 230 347 40 233 347 minecraft:honeycomb_block
fill 40 230 349 40 230 350 minecraft:honeycomb_block
setblock 40 230 351 minecraft:yellow_terracotta
fill 40 230 352 40 233 352 minecraft:honeycomb_block
fill 40 230 354 40 230 355 minecraft:honeycomb_block
setblock 41 230 325 minecraft:yellow_terracotta
fill 41 230 326 41 233 326 minecraft:honeycomb_block
setblock 41 230 330 minecraft:yellow_terracotta
fill 41 230 331 41 233 331 minecraft:honeycomb_block
setblock 41 230 340 minecraft:honey_block
setblock 41 230 345 minecraft:yellow_terracotta
fill 41 230 346 41 233 346 minecraft:honeycomb_block
setblock 41 230 350 minecraft:yellow_terracotta
fill 41 230 351 41 233 351 minecraft:honeycomb_block
setblock 41 230 355 minecraft:yellow_terracotta
fill 41 230 356 41 233 356 minecraft:honeycomb_block
setblock 41 230 360 minecraft:yellow_terracotta
fill 41 230 361 41 233 361 minecraft:honeycomb_block
setblock 42 230 356 minecraft:yellow_concrete
setblock 1 231 324 minecraft:yellow_terracotta
fill 1 231 325 1 234 325 minecraft:honeycomb_block
setblock 1 231 329 minecraft:yellow_terracotta
fill 1 231 330 2 233 330 minecraft:honeycomb_block
setblock 1 231 334 minecraft:yellow_terracotta
fill 1 231 335 1 231 338 minecraft:honeycomb_block
setblock 1 231 339 minecraft:yellow_terracotta
fill 1 231 340 1 234 340 minecraft:honeycomb_block
setblock 1 231 344 minecraft:yellow_terracotta
fill 1 231 345 1 231 348 minecraft:honeycomb_block
setblock 1 231 349 minecraft:yellow_terracotta
fill 1 231 350 1 234 350 minecraft:honeycomb_block
setblock 1 231 354 minecraft:yellow_terracotta
fill 1 231 355 1 234 355 minecraft:honeycomb_block
setblock 1 231 359 minecraft:yellow_terracotta
fill 1 231 360 1 234 360 minecraft:honeycomb_block
setblock 2 231 323 minecraft:yellow_terracotta
setblock 2 231 328 minecraft:yellow_terracotta
fill 2 231 329 2 234 329 minecraft:honeycomb_block
fill 2 231 331 2 232 331 minecraft:honeycomb_block
setblock 2 231 343 minecraft:yellow_terracotta
fill 2 231 344 2 231 347 minecraft:honeycomb_block
setblock 2 231 348 minecraft:yellow_terracotta
fill 2 231 349 2 234 349 minecraft:honeycomb_block
setblock 2 231 353 minecraft:yellow_terracotta
fill 2 231 354 3 233 354 minecraft:honeycomb_block
setblock 2 231 357 minecraft:honeycomb_block
setblock 2 231 363 minecraft:yellow_terracotta
fill 3 231 323 3 234 323 minecraft:honeycomb_block
setblock 3 231 325 minecraft:light[level=15]
setblock 3 231 332 minecraft:light[level=12]
setblock 3 231 333 minecraft:light[level=15]
setblock 3 231 339 minecraft:light[level=12]
setblock 3 231 341 minecraft:light[level=15]
setblock 3 231 347 minecraft:yellow_terracotta
fill 3 231 348 3 234 348 minecraft:honeycomb_block
setblock 3 231 352 minecraft:yellow_terracotta
fill 3 231 353 3 234 353 minecraft:honeycomb_block
setblock 3 231 357 minecraft:light[level=15]
setblock 3 231 360 minecraft:light[level=12]
setblock 4 231 347 minecraft:honeycomb_block
setblock 4 231 351 minecraft:yellow_terracotta
setblock 8 231 323 minecraft:honey_block
setblock 9 231 363 minecraft:honey_block
setblock 10 231 325 minecraft:light[level=12]
setblock 10 231 332 minecraft:light[level=12]
setblock 10 231 339 minecraft:light[level=12]
setblock 10 231 346 minecraft:light[level=12]
setblock 10 231 353 minecraft:light[level=12]
setblock 10 231 360 minecraft:light[level=12]
fill 10 231 364 10 308 364 minecraft:honeycomb_block
setblock 11 231 325 minecraft:light[level=15]
setblock 11 231 333 minecraft:light[level=15]
setblock 11 231 341 minecraft:light[level=15]
setblock 11 231 349 minecraft:light[level=15]
setblock 11 231 357 minecraft:light[level=15]
setblock 17 231 323 minecraft:yellow_terracotta
setblock 17 231 325 minecraft:light[level=12]
setblock 17 231 332 minecraft:light[level=12]
setblock 17 231 339 minecraft:light[level=12]
setblock 17 231 346 minecraft:light[level=12]
setblock 17 231 353 minecraft:light[level=12]
setblock 17 231 360 minecraft:light[level=12]
fill 18 231 323 18 234 323 minecraft:honeycomb_block
setblock 19 231 325 minecraft:light[level=15]
setblock 19 231 333 minecraft:light[level=15]
setblock 19 231 341 minecraft:light[level=15]
setblock 19 231 349 minecraft:light[level=15]
setblock 19 231 357 minecraft:light[level=15]
setblock 20 231 324 minecraft:honeycomb_block
setblock 20 231 325 minecraft:yellow_terracotta
setblock 21 231 324 minecraft:yellow_terracotta
fill 21 231 325 21 234 325 minecraft:honeycomb_block
setblock 22 231 323 minecraft:yellow_terracotta
fill 22 231 324 22 234 324 minecraft:honeycomb_block
setblock 22 231 363 minecraft:yellow_terracotta
fill 23 231 323 23 234 323 minecraft:honeycomb_block
fill 23 231 363 26 231 363 minecraft:honeycomb_block
setblock 24 231 326 minecraft:yellow_terracotta
setblock 24 231 332 minecraft:light[level=12]
setblock 24 231 339 minecraft:light[level=12]
setblock 24 231 346 minecraft:light[level=12]
setblock 24 231 353 minecraft:light[level=12]
setblock 24 231 360 minecraft:light[level=12]
setblock 25 231 325 minecraft:yellow_terracotta
setblock 25 231 326 minecraft:honeycomb_block
setblock 26 231 324 minecraft:yellow_terracotta
fill 26 231 325 27 232 325 minecraft:honeycomb_block
fill 26 231 358 26 235 358 minecraft:brown_terracotta
setblock 27 231 323 minecraft:yellow_terracotta
fill 27 231 324 27 234 324 minecraft:honeycomb_block
setblock 27 231 333 minecraft:light[level=15]
setblock 27 231 341 minecraft:light[level=15]
setblock 27 231 349 minecraft:light[level=15]
fill 27 231 357 27 235 357 minecraft:brown_terracotta
fill 27 231 359 27 235 359 minecraft:brown_terracotta
setblock 27 231 363 minecraft:yellow_terracotta
fill 28 231 323 28 234 323 minecraft:honeycomb_block
fill 28 231 358 28 235 358 minecraft:brown_terracotta
setblock 31 231 325 minecraft:light[level=12]
setblock 31 231 332 minecraft:light[level=12]
setblock 31 231 339 minecraft:light[level=12]
setblock 31 231 346 minecraft:light[level=12]
setblock 31 231 353 minecraft:light[level=12]
setblock 31 231 360 minecraft:light[level=12]
setblock 32 231 323 minecraft:yellow_terracotta
setblock 33 231 323 minecraft:honeycomb_block
setblock 34 231 363 minecraft:honey_block
setblock 35 231 325 minecraft:light[level=15]
setblock 35 231 333 minecraft:light[level=15]
setblock 35 231 341 minecraft:light[level=15]
setblock 35 231 357 minecraft:light[level=15]
setblock 37 231 323 minecraft:yellow_terracotta
setblock 37 231 363 minecraft:yellow_terracotta
fill 38 231 323 38 234 323 minecraft:honeycomb_block
setblock 38 231 325 minecraft:light[level=12]
setblock 38 231 332 minecraft:light[level=12]
setblock 38 231 339 minecraft:light[level=12]
setblock 38 231 346 minecraft:light[level=12]
setblock 38 231 353 minecraft:light[level=12]
setblock 38 231 360 minecraft:light[level=12]
fill 38 231 363 38 234 363 minecraft:honeycomb_block
setblock 40 231 325 minecraft:yellow_terracotta
fill 40 231 326 40 234 326 minecraft:honeycomb_block
fill 40 231 328 40 232 328 minecraft:honeycomb_block
fill 40 231 346 40 234 346 minecraft:honeycomb_block
setblock 40 231 349 minecraft:honeycomb_block
setblock 40 231 350 minecraft:yellow_terracotta
fill 40 231 351 40 234 351 minecraft:honeycomb_block
setblock 40 231 354 minecraft:honeycomb_block
setblock 40 231 355 minecraft:yellow_terracotta
fill 40 231 356 40 233 357 minecraft:honeycomb_block
setblock 41 231 324 minecraft:yellow_terracotta
fill 41 231 325 41 234 325 minecraft:honeycomb_block
setblock 41 231 329 minecraft:yellow_terracotta
fill 41 231 330 41 234 330 minecraft:honeycomb_block
fill 41 231 332 41 232 332 minecraft:honeycomb_block
setblock 41 231 334 minecraft:honey_block
setblock 41 231 344 minecraft:yellow_terracotta
fill 41 231 345 41 234 345 minecraft:honeycomb_block
setblock 41 231 349 minecraft:yellow_terracotta
fill 41 231 350 41 234 350 minecraft:honeycomb_block
setblock 41 231 354 minecraft:yellow_terracotta
fill 41 231 355 41 234 355 minecraft:honeycomb_block
setblock 41 231 359 minecraft:yellow_terracotta
fill 41 231 360 41 234 360 minecraft:honeycomb_block
fill 42 231 356 42 308 356 minecraft:honeycomb_block
setblock 0 232 330 minecraft:yellow_concrete
setblock 1 232 323 minecraft:yellow_terracotta
fill 1 232 324 1 235 324 minecraft:honeycomb_block
setblock 1 232 327 minecraft:honeycomb_block
setblock 1 232 328 minecraft:yellow_terracotta
fill 1 232 329 1 235 329 minecraft:honeycomb_block
fill 1 232 331 1 232 332 minecraft:honeycomb_block
setblock 1 232 333 minecraft:yellow_terracotta
fill 1 232 334 1 232 337 minecraft:honeycomb_block
setblock 1 232 338 minecraft:yellow_terracotta
fill 1 232 339 1 235 339 minecraft:honeycomb_block
setblock 1 232 343 minecraft:yellow_terracotta
fill 1 232 344 1 232 347 minecraft:honeycomb_block
setblock 1 232 348 minecraft:yellow_terracotta
fill 1 232 349 1 235 349 minecraft:honeycomb_block
setblock 1 232 353 minecraft:yellow_terracotta
fill 1 232 354 1 235 354 minecraft:honeycomb_block
setblock 1 232 358 minecraft:yellow_terracotta
fill 1 232 359 1 235 359 minecraft:honeycomb_block
setblock 1 232 362 minecraft:honeycomb_block
setblock 1 232 363 minecraft:yellow_terracotta
fill 2 232 323 2 235 323 minecraft:honeycomb_block
setblock 2 232 327 minecraft:yellow_terracotta
fill 2 232 328 2 235 328 minecraft:honeycomb_block
setblock 2 232 332 minecraft:yellow_terracotta
fill 2 232 333 2 234 334 minecraft:honeycomb_block
setblock 2 232 341 minecraft:honeycomb_block
setblock 2 232 342 minecraft:yellow_terracotta
fill 2 232 343 2 232 346 minecraft:honeycomb_block
setblock 2 232 347 minecraft:yellow_terracotta
fill 2 232 348 2 235 348 minecraft:honeycomb_block
setblock 2 232 352 minecraft:yellow_terracotta
fill 2 232 353 2 235 353 minecraft:honeycomb_block
setblock 2 232 357 minecraft:yellow_terracotta
fill 2 232 363 2 235 363 minecraft:honeycomb_block
setblock 3 232 346 minecraft:yellow_terracotta
fill 3 232 347 3 235 347 minecraft:honeycomb_block
setblock 3 232 351 minecraft:yellow_terracotta
fill 3 232 352 3 235 352 minecraft:honeycomb_block
setblock 3 232 355 minecraft:honeycomb_block
setblock 4 232 350 minecraft:yellow_terracotta
fill 4 232 351 4 235 351 minecraft:honeycomb_block
setblock 15 232 363 minecraft:honey_block
setblock 16 232 323 minecraft:yellow_terracotta
fill 17 232 323 17 235 323 minecraft:honeycomb_block
setblock 19 232 325 minecraft:yellow_terracotta
setblock 20 232 324 minecraft:yellow_terracotta
fill 20 232 325 20 235 325 minecraft:honeycomb_block
setblock 21 232 323 minecraft:yellow_terracotta
fill 21 232 324 21 235 324 minecraft:honeycomb_block
fill 21 232 326 21 233 326 minecraft:honeycomb_block
setblock 21 232 363 minecraft:yellow_terracotta
fill 22 232 323 22 235 323 minecraft:honeycomb_block
fill 22 232 363 25 232 363 minecraft:honeycomb_block
setblock 23 232 326 minecraft:yellow_terracotta
setblock 24 232 325 minecraft:yellow_terracotta
fill 24 232 326 24 234 326 minecraft:honeycomb_block
setblock 25 232 322 minecraft:yellow_concrete
setblock 25 232 324 minecraft:yellow_terracotta
fill 25 232 325 25 235 325 minecraft:honeycomb_block
setblock 26 232 323 minecraft:yellow_terracotta
fill 26 232 324 26 235 324 minecraft:honeycomb_block
setblock 26 232 363 minecraft:yellow_terracotta
fill 27 232 323 27 235 323 minecraft:honeycomb_block
fill 27 232 363 27 235 363 minecraft:honeycomb_block
setblock 31 232 323 minecraft:yellow_terracotta
setblock 32 232 323 minecraft:honeycomb_block
setblock 36 232 322 minecraft:yellow_concrete
setblock 36 232 323 minecraft:yellow_terracotta
fill 37 232 323 37 235 323 minecraft:honeycomb_block
fill 37 232 363 37 235 363 minecraft:honeycomb_block
setblock 39 232 349 minecraft:honeycomb_block
setblock 39 232 350 minecraft:yellow_terracotta
fill 39 232 351 39 232 354 minecraft:honeycomb_block
fill 40 232 325 40 235 325 minecraft:honeycomb_block
setblock 40 232 329 minecraft:yellow_terracotta
fill 40 232 330 40 235 330 minecraft:honeycomb_block
setblock 40 232 349 minecraft:yellow_terracotta
fill 40 232 350 40 235 350 minecraft:honeycomb_block
setblock 40 232 354 minecraft:yellow_terracotta
fill 40 232 355 40 235 355 minecraft:honeycomb_block
setblock 40 232 358 minecraft:honeycomb_block
setblock 40 232 359 minecraft:yellow_terracotta
fill 40 232 360 40 235 360 minecraft:honeycomb_block
setblock 41 232 323 minecraft:yellow_terracotta
fill 41 232 324 41 235 324 minecraft:honeycomb_block
setblock 41 232 328 minecraft:yellow_terracotta
fill 41 232 329 41 235 329 minecraft:honeycomb_block
setblock 41 232 333 minecraft:yellow_terracotta
fill 41 232 334 41 235 334 minecraft:honeycomb_block
setblock 41 232 342 minecraft:honeycomb_block
setblock 41 232 343 minecraft:yellow_terracotta
fill 41 232 344 41 235 344 minecraft:honeycomb_block
setblock 41 232 348 minecraft:yellow_terracotta
fill 41 232 349 41 235 349 minecraft:honeycomb_block
setblock 41 232 353 minecraft:yellow_terracotta
fill 41 232 354 41 235 354 minecraft:honeycomb_block
setblock 41 232 358 minecraft:yellow_terracotta
fill 41 232 359 41 235 359 minecraft:honeycomb_block
setblock 41 232 363 minecraft:yellow_terracotta
fill 0 233 330 0 308 330 minecraft:honeycomb_block
setblock 0 233 342 minecraft:orange_terracotta
fill 0 233 343 2 235 343 minecraft:honeycomb_block
fill 1 233 323 1 236 323 minecraft:honeycomb_block
setblock 1 233 327 minecraft:yellow_terracotta
fill 1 233 328 1 236 328 minecraft:honeycomb_block
setblock 1 233 331 minecraft:honeycomb_block
setblock 1 233 332 minecraft:yellow_terracotta
fill 1 233 333 1 233 336 minecraft:honeycomb_block
setblock 1 233 337 minecraft:yellow_terracotta
fill 1 233 338 2 235 338 minecraft:honeycomb_block
setblock 1 233 342 minecraft:yellow_terracotta
fill 1 233 344 1 233 346 minecraft:honeycomb_block
setblock 1 233 347 minecraft:yellow_terracotta
fill 1 233 348 1 236 348 minecraft:honeycomb_block
setblock 1 233 352 minecraft:yellow_terracotta
fill 1 233 353 1 236 353 minecraft:honeycomb_block
setblock 1 233 356 minecraft:honeycomb_block
setblock 1 233 357 minecraft:yellow_terracotta
fill 1 233 358 2 235 358 minecraft:honeycomb_block
setblock 1 233 362 minecraft:yellow_terracotta
fill 1 233 363 1 236 363 minecraft:honeycomb_block
setblock 2 233 326 minecraft:yellow_terracotta
fill 2 233 327 2 236 327 minecraft:honeycomb_block
setblock 2 233 331 minecraft:yellow_terracotta
fill 2 233 332 2 236 332 minecraft:honeycomb_block
setblock 2 233 335 minecraft:honeycomb_block
setblock 2 233 336 minecraft:yellow_terracotta
fill 2 233 337 2 236 337 minecraft:honeycomb_block
fill 2 233 339 2 233 340 minecraft:honeycomb_block
setblock 2 233 341 minecraft:yellow_terracotta
fill 2 233 342 2 236 342 minecraft:honeycomb_block
fill 2 233 344 2 233 345 minecraft:honeycomb_block
setblock 2 233 346 minecraft:yellow_terracotta
fill 2 233 347 2 236 347 minecraft:honeycomb_block
setblock 2 233 351 minecraft:yellow_terracotta
fill 2 233 352 2 236 352 minecraft:honeycomb_block
setblock 2 233 356 minecraft:yellow_terracotta
fill 2 233 357 2 236 357 minecraft:honeycomb_block
setblock 3 233 330 minecraft:yellow_terracotta
fill 3 233 331 3 236 331 minecraft:honeycomb_block
setblock 3 233 345 minecraft:yellow_terracotta
fill 3 233 346 3 236 346 minecraft:honeycomb_block
setblock 3 233 350 minecraft:yellow_terracotta
fill 3 233 351 3 236 351 minecraft:honeycomb_block
setblock 3 233 355 minecraft:yellow_terracotta
setblock 4 233 349 minecraft:yellow_terracotta
fill 4 233 350 4 235 350 minecraft:honeycomb_block
fill 4 233 352 4 234 352 minecraft:honeycomb_block
setblock 15 233 322 minecraft:yellow_terracotta
setblock 15 233 323 minecraft:honey_block
fill 16 233 323 16 236 323 minecraft:honeycomb_block
fill 17 233 324 17 234 324 minecraft:honeycomb_block
setblock 18 233 325 minecraft:yellow_terracotta
setblock 19 233 324 minecraft:yellow_terracotta
fill 19 233 325 19 236 325 minecraft:honeycomb_block
setblock 20 233 323 minecraft:yellow_terracotta
fill 20 233 324 20 236 324 minecraft:honeycomb_block
fill 20 233 326 20 234 326 minecraft:honeycomb_block
setblock 20 233 363 minecraft:yellow_terracotta
fill 21 233 323 21 236 323 minecraft:honeycomb_block
fill 21 233 363 24 233 363 minecraft:honeycomb_block
setblock 22 233 326 minecraft:yellow_terracotta
setblock 23 233 325 minecraft:yellow_terracotta
fill 23 233 326 23 235 326 minecraft:honeycomb_block
setblock 24 233 324 minecraft:yellow_terracotta
fill 24 233 325 24 236 325 minecraft:honeycomb_block
fill 25 233 322 25 266 322 minecraft:honeycomb_block
setblock 25 233 323 minecraft:yellow_terracotta
fill 25 233 324 25 236 324 minecraft:honeycomb_block
setblock 25 233 363 minecraft:yellow_terracotta
fill 26 233 323 26 236 323 minecraft:honeycomb_block
fill 26 233 325 26 234 325 minecraft:honeycomb_block
fill 26 233 357 26 235 357 minecraft:brown_terracotta
fill 26 233 359 26 235 359 minecraft:brown_terracotta
fill 26 233 363 26 236 363 minecraft:honeycomb_block
fill 28 233 357 28 235 357 minecraft:brown_terracotta
fill 28 233 359 28 235 359 minecraft:brown_terracotta
setblock 30 233 323 minecraft:yellow_terracotta
setblock 31 233 323 minecraft:honeycomb_block
setblock 35 233 323 minecraft:yellow_terracotta
fill 36 233 322 36 236 323 minecraft:honeycomb_block
fill 36 233 363 36 236 363 minecraft:honeycomb_block
setblock 39 233 348 minecraft:honeycomb_block
setblock 39 233 349 minecraft:yellow_terracotta
fill 39 233 350 39 233 353 minecraft:honeycomb_block
setblock 39 233 354 minecraft:yellow_terracotta
fill 39 233 355 39 235 356 minecraft:honeycomb_block
setblock 40 233 323 minecraft:yellow_terracotta
fill 40 233 324 40 235 324 minecraft:honeycomb_block
setblock 40 233 328 minecraft:yellow_terracotta
fill 40 233 329 40 236 329 minecraft:honeycomb_block
fill 40 233 331 40 233 332 minecraft:honeycomb_block
fill 40 233 345 40 235 345 minecraft:honeycomb_block
setblock 40 233 348 minecraft:yellow_terracotta
fill 40 233 349 40 236 349 minecraft:honeycomb_block
setblock 40 233 353 minecraft:yellow_terracotta
fill 40 233 354 40 236 354 minecraft:honeycomb_block
setblock 40 233 358 minecraft:yellow_terracotta
fill 40 233 359 40 236 359 minecraft:honeycomb_block
fill 40 233 361 40 233 362 minecraft:honeycomb_block
setblock 40 233 363 minecraft:yellow_terracotta
fill 41 233 323 41 236 323 minecraft:honeycomb_block
setblock 41 233 327 minecraft:yellow_terracotta
fill 41 233 328 41 236 328 minecraft:honeycomb_block
setblock 41 233 332 minecraft:yellow_terracotta
fill 41 233 333 41 236 333 minecraft:honeycomb_block
fill 41 233 335 41 233 336 minecraft:honeycomb_block
setblock 41 233 341 minecraft:honeycomb_block
setblock 41 233 342 minecraft:yellow_terracotta
fill 41 233 343 41 236 343 minecraft:honeycomb_block
setblock 41 233 347 minecraft:yellow_terracotta
fill 41 233 348 41 236 348 minecraft:honeycomb_block
setblock 41 233 352 minecraft:yellow_terracotta
fill 41 233 353 41 236 353 minecraft:honeycomb_block
setblock 41 233 357 minecraft:yellow_terracotta
fill 41 233 358 41 236 358 minecraft:honeycomb_block
setblock 41 233 362 minecraft:yellow_terracotta
fill 41 233 363 41 236 363 minecraft:honeycomb_block
fill 0 234 342 1 237 342 minecraft:honeycomb_block
setblock 1 234 326 minecraft:yellow_terracotta
fill 1 234 327 1 237 327 minecraft:honeycomb_block
setblock 1 234 330 minecraft:honeycomb_block
setblock 1 234 331 minecraft:yellow_terracotta
fill 1 234 332 1 234 335 minecraft:honeycomb_block
setblock 1 234 336 minecraft:yellow_terracotta
fill 1 234 337 1 237 337 minecraft:honeycomb_block
setblock 1 234 341 minecraft:yellow_terracotta
fill 1 234 344 1 234 345 minecraft:honeycomb_block
setblock 1 234 346 minecraft:yellow_terracotta
fill 1 234 347 1 237 347 minecraft:honeycomb_block
setblock 1 234 351 minecraft:yellow_terracotta
fill 1 234 352 1 237 352 minecraft:honeycomb_block
setblock 1 234 356 minecraft:yellow_terracotta
fill 1 234 357 1 237 357 minecraft:honeycomb_block
setblock 1 234 361 minecraft:yellow_terracotta
fill 1 234 362 1 237 362 minecraft:honeycomb_block
fill 2 234 326 2 236 326 minecraft:honeycomb_block
setblock 2 234 330 minecraft:yellow_terracotta
fill 2 234 331 2 237 331 minecraft:honeycomb_block
setblock 2 234 335 minecraft:yellow_terracotta
fill 2 234 336 2 237 336 minecraft:honeycomb_block
setblock 2 234 339 minecraft:honeycomb_block
setblock 2 234 340 minecraft:yellow_terracotta
fill 2 234 341 2 237 341 minecraft:honeycomb_block
setblock 2 234 344 minecraft:honeycomb_block
setblock 2 234 345 minecraft:yellow_terracotta
fill 2 234 346 2 237 346 minecraft:honeycomb_block
setblock 2 234 350 minecraft:yellow_terracotta
fill 2 234 351 2 237 351 minecraft:honeycomb_block
setblock 2 234 354 minecraft:honeycomb_block
setblock 2 234 355 minecraft:yellow_terracotta
fill 2 234 356 3 236 356 minecraft:honeycomb_block
setblock 2 234 359 minecraft:honeycomb_block
setblock 3 234 329 minecraft:yellow_terracotta
fill 3 234 330 3 237 330 minecraft:honeycomb_block
fill 3 234 332 3 234 333 minecraft:honeycomb_block
setblock 3 234 334 minecraft:yellow_terracotta
setblock 3 234 344 minecraft:yellow_terracotta
fill 3 234 345 3 236 345 minecraft:honeycomb_block
setblock 3 234 349 minecraft:yellow_terracotta
fill 3 234 350 3 237 350 minecraft:honeycomb_block
setblock 3 234 354 minecraft:yellow_terracotta
fill 3 234 355 3 237 355 minecraft:honeycomb_block
setblock 4 234 349 minecraft:honeycomb_block
setblock 8 234 363 minecraft:honey_block
setblock 9 234 323 minecraft:honey_block
fill 15 234 322 15 237 323 minecraft:honeycomb_block
setblock 18 234 324 minecraft:yellow_terracotta
fill 18 234 325 18 237 325 minecraft:honeycomb_block
setblock 19 234 323 minecraft:yellow_terracotta
fill 19 234 324 19 237 324 minecraft:honeycomb_block
fill 19 234 326 19 235 326 minecraft:honeycomb_block
setblock 19 234 363 minecraft:yellow_terracotta
fill 20 234 323 20 237 323 minecraft:honeycomb_block
fill 20 234 363 23 234 363 minecraft:honeycomb_block
setblock 21 234 326 minecraft:yellow_terracotta
setblock 22 234 325 minecraft:yellow_terracotta
fill 22 234 326 22 236 326 minecraft:honeycomb_block
setblock 23 234 324 minecraft:yellow_terracotta
fill 23 234 325 23 237 325 minecraft:honeycomb_block
setblock 24 234 323 minecraft:yellow_terracotta
fill 24 234 324 24 237 324 minecraft:honeycomb_block
setblock 24 234 363 minecraft:yellow_terracotta
fill 25 234 323 25 237 323 minecraft:honeycomb_block
fill 25 234 363 25 237 363 minecraft:honeycomb_block
setblock 28 234 324 minecraft:yellow_terracotta
setblock 29 234 323 minecraft:yellow_terracotta
fill 30 234 323 30 235 323 minecraft:honeycomb_block
setblock 34 234 323 minecraft:honey_block
fill 35 234 323 35 237 323 minecraft:honeycomb_block
fill 35 234 363 35 237 363 minecraft:honeycomb_block
setblock 38 234 353 minecraft:honeycomb_block
fill 38 234 362 39 234 362 minecraft:honeycomb_block
setblock 39 234 323 minecraft:yellow_terracotta
setblock 39 234 348 minecraft:yellow_terracotta
fill 39 234 349 39 234 352 minecraft:honeycomb_block
setblock 39 234 353 minecraft:yellow_terracotta
fill 39 234 354 39 237 354 minecraft:honeycomb_block
setblock 39 234 357 minecraft:honeycomb_block
setblock 39 234 358 minecraft:yellow_terracotta
setblock 39 234 363 minecraft:yellow_terracotta
fill 40 234 323 40 237 323 minecraft:honeycomb_block
setblock 40 234 327 minecraft:yellow_terracotta
fill 40 234 328 40 237 328 minecraft:honeycomb_block
setblock 40 234 331 minecraft:honeycomb_block
setblock 40 234 332 minecraft:yellow_terracotta
fill 40 234 333 40 236 334 minecraft:honeycomb_block
setblock 40 234 347 minecraft:yellow_terracotta
fill 40 234 348 40 237 348 minecraft:honeycomb_block
setblock 40 234 352 minecraft:yellow_terracotta
fill 40 234 353 40 237 353 minecraft:honeycomb_block
setblock 40 234 356 minecraft:honeycomb_block
setblock 40 234 357 minecraft:yellow_terracotta
fill 40 234 358 40 237 358 minecraft:honeycomb_block
setblock 40 234 361 minecraft:honeycomb_block
setblock 40 234 362 minecraft:yellow_terracotta
fill 40 234 363 40 237 363 minecraft:honeycomb_block
setblock 41 234 326 minecraft:yellow_terracotta
fill 41 234 327 41 237 327 minecraft:honeycomb_block
setblock 41 234 331 minecraft:yellow_terracotta
fill 41 234 332 41 237 332 minecraft:honeycomb_block
setblock 41 234 335 minecraft:honeycomb_block
setblock 41 234 336 minecraft:yellow_terracotta
fill 41 234 337 41 234 340 minecraft:honeycomb_block
setblock 41 234 341 minecraft:yellow_terracotta
fill 41 234 342 41 237 342 minecraft:honeycomb_block
setblock 41 234 346 minecraft:yellow_terracotta
fill 41 234 347 41 237 347 minecraft:honeycomb_block
setblock 41 234 351 minecraft:yellow_terracotta
fill 41 234 352 41 237 352 minecraft:honeycomb_block
setblock 41 234 356 minecraft:yellow_terracotta
fill 41 234 357 41 237 357 minecraft:honeycomb_block
setblock 41 234 361 minecraft:yellow_terracotta
fill 41 234 362 41 237 362 minecraft:honeycomb_block
setblock 0 235 357 minecraft:yellow_terracotta
setblock 1 235 325 minecraft:yellow_terracotta
fill 1 235 326 1 238 326 minecraft:honeycomb_block
setblock 1 235 330 minecraft:yellow_terracotta
fill 1 235 331 1 235 334 minecraft:honeycomb_block
setblock 1 235 335 minecraft:yellow_terracotta
fill 1 235 336 1 238 336 minecraft:honeycomb_block
setblock 1 235 340 minecraft:yellow_terracotta
fill 1 235 341 1 238 341 minecraft:honeycomb_block
setblock 1 235 344 minecraft:honeycomb_block
setblock 1 235 345 minecraft:yellow_terracotta
fill 1 235 346 1 238 346 minecraft:honeycomb_block
setblock 1 235 350 minecraft:yellow_terracotta
fill 1 235 351 1 238 351 minecraft:honeycomb_block
setblock 1 235 355 minecraft:yellow_terracotta
fill 1 235 356 1 238 356 minecraft:honeycomb_block
setblock 1 235 360 minecraft:yellow_terracotta
fill 1 235 361 1 238 361 minecraft:honeycomb_block
setblock 2 235 329 minecraft:yellow_terracotta
fill 2 235 330 2 238 330 minecraft:honeycomb_block
setblock 2 235 333 minecraft:honeycomb_block
setblock 2 235 334 minecraft:yellow_terracotta
fill 2 235 335 3 237 335 minecraft:honeycomb_block
setblock 2 235 339 minecraft:yellow_terracotta
fill 2 235 340 2 238 340 minecraft:honeycomb_block
setblock 2 235 344 minecraft:yellow_terracotta
fill 2 235 345 2 238 345 minecraft:honeycomb_block
setblock 2 235 349 minecraft:yellow_terracotta
fill 2 235 350 2 238 350 minecraft:honeycomb_block
setblock 2 235 354 minecraft:yellow_terracotta
fill 2 235 355 2 238 355 minecraft:honeycomb_block
setblock 2 235 359 minecraft:yellow_terracotta
setblock 3 235 323 minecraft:yellow_terracotta
fill 3 235 329 3 237 329 minecraft:honeycomb_block
setblock 3 235 332 minecraft:honeycomb_block
setblock 3 235 333 minecraft:yellow_terracotta
fill 3 235 334 3 238 334 minecraft:honeycomb_block
fill 3 235 336 3 235 337 minecraft:honeycomb_block
setblock 3 235 344 minecraft:honeycomb_block
setblock 3 235 348 minecraft:yellow_terracotta
fill 3 235 349 3 238 349 minecraft:honeycomb_block
setblock 3 235 353 minecraft:yellow_terracotta
fill 3 235 354 3 238 354 minecraft:honeycomb_block
setblock 4 235 352 minecraft:yellow_terracotta
setblock 10 235 322 minecraft:orange_terracotta
setblock 14 235 363 minecraft:honey_block
setblock 16 235 324 minecraft:honeycomb_block
setblock 17 235 324 minecraft:yellow_terracotta
fill 17 235 325 17 238 325 minecraft:honeycomb_block
setblock 18 235 323 minecraft:yellow_terracotta
fill 18 235 324 18 238 324 minecraft:honeycomb_block
setblock 18 235 363 minecraft:yellow_terracotta
fill 19 235 323 19 238 323 minecraft:honeycomb_block
fill 19 235 363 22 235 363 minecraft:honeycomb_block
setblock 20 235 326 minecraft:yellow_terracotta
setblock 21 235 325 minecraft:yellow_terracotta
fill 21 235 326 21 237 326 minecraft:honeycomb_block
setblock 22 235 324 minecraft:yellow_terracotta
fill 22 235 325 22 238 325 minecraft:honeycomb_block
setblock 23 235 323 minecraft:yellow_terracotta
fill 23 235 324 23 238 324 minecraft:honeycomb_block
setblock 23 235 363 minecraft:yellow_terracotta
fill 24 235 323 24 238 323 minecraft:honeycomb_block
fill 24 235 363 24 238 363 minecraft:honeycomb_block
setblock 25 235 358 minecraft:brown_terracotta
setblock 27 235 324 minecraft:yellow_terracotta
setblock 27 235 356 minecraft:brown_terracotta
setblock 27 235 360 minecraft:brown_terracotta
setblock 28 235 323 minecraft:yellow_terracotta
setblock 28 235 363 minecraft:yellow_terracotta
fill 29 235 323 29 236 323 minecraft:honeycomb_block
setblock 29 235 358 minecraft:brown_terracotta
setblock 33 235 363 minecraft:yellow_terracotta
fill 34 235 323 34 238 323 minecraft:honeycomb_block
fill 34 235 363 34 238 363 minecraft:honeycomb_block
fill 37 235 362 38 235 362 minecraft:honeycomb_block
setblock 38 235 323 minecraft:yellow_terracotta
fill 38 235 351 38 235 352 minecraft:honeycomb_block
setblock 38 235 353 minecraft:yellow_terracotta
fill 38 235 354 38 236 356 minecraft:honeycomb_block
setblock 38 235 363 minecraft:yellow_terracotta
setblock 38 235 364 minecraft:orange_terracotta
fill 39 235 323 39 238 323 minecraft:honeycomb_block
setblock 39 235 347 minecraft:yellow_terracotta
fill 39 235 348 39 235 351 minecraft:honeycomb_block
setblock 39 235 352 minecraft:yellow_terracotta
fill 39 235 353 39 238 353 minecraft:honeycomb_block
setblock 39 235 357 minecraft:yellow_terracotta
fill 39 235 358 39 236 360 minecraft:honeycomb_block
setblock 39 235 362 minecraft:yellow_terracotta
fill 39 235 363 39 238 363 minecraft:honeycomb_block
setblock 40 235 326 minecraft:yellow_terracotta
fill 40 235 327 40 238 327 minecraft:honeycomb_block
setblock 40 235 331 minecraft:yellow_terracotta
fill 40 235 332 40 238 332 minecraft:honeycomb_block
setblock 40 235 335 minecraft:honeycomb_block
setblock 40 235 336 minecraft:yellow_terracotta
fill 40 235 344 40 236 344 minecraft:honeycomb_block
setblock 40 235 346 minecraft:yellow_terracotta
fill 40 235 347 40 238 347 minecraft:honeycomb_block
setblock 40 235 351 minecraft:yellow_terracotta
fill 40 235 352 40 238 352 minecraft:honeycomb_block
setblock 40 235 356 minecraft:yellow_terracotta
fill 40 235 357 40 238 357 minecraft:honeycomb_block
setblock 40 235 361 minecraft:yellow_terracotta
fill 40 235 362 40 238 362 minecraft:honeycomb_block
setblock 41 235 325 minecraft:yellow_terracotta
fill 41 235 326 41 238 326 minecraft:honeycomb_block
setblock 41 235 330 minecraft:yellow_terracotta
fill 41 235 331 41 238 331 minecraft:honeycomb_block
setblock 41 235 335 minecraft:yellow_terracotta
fill 41 235 336 41 235 339 minecraft:honeycomb_block
setblock 41 235 340 minecraft:yellow_terracotta
fill 41 235 341 41 238 341 minecraft:honeycomb_block
setblock 41 235 345 minecraft:yellow_terracotta
fill 41 235 346 41 238 346 minecraft:honeycomb_block
setblock 41 235 350 minecraft:yellow_terracotta
fill 41 235 351 41 238 351 minecraft:honeycomb_block
setblock 41 235 355 minecraft:yellow_terracotta
fill 41 235 356 41 238 356 minecraft:honeycomb_block
setblock 41 235 360 minecraft:yellow_terracotta
fill 41 235 361 41 238 361 minecraft:honeycomb_block
setblock 42 235 352 minecraft:orange_terracotta
fill 0 236 343 1 236 343 minecraft:honeycomb_block
fill 0 236 357 0 308 357 minecraft:honeycomb_block
setblock 1 236 324 minecraft:yellow_terracotta
fill 1 236 325 1 239 325 minecraft:honeycomb_block
setblock 1 236 329 minecraft:yellow_terracotta
fill 1 236 330 1 236 333 minecraft:honeycomb_block
setblock 1 236 334 minecraft:yellow_terracotta
fill 1 236 335 1 239 335 minecraft:honeycomb_block
setblock 1 236 338 minecraft:honeycomb_block
setblock 1 236 339 minecraft:yellow_terracotta
fill 1 236 340 1 239 340 minecraft:honeycomb_block
setblock 1 236 344 minecraft:yellow_terracotta
fill 1 236 345 1 239 345 minecraft:honeycomb_block
setblock 1 236 349 minecraft:yellow_terracotta
fill 1 236 350 1 239 350 minecraft:honeycomb_block
setblock 1 236 354 minecraft:yellow_terracotta
fill 1 236 355 1 239 355 minecraft:honeycomb_block
setblock 1 236 358 minecraft:honeycomb_block
setblock 1 236 359 minecraft:yellow_terracotta
fill 1 236 360 2 238 360 minecraft:honeycomb_block
setblock 2 236 323 minecraft:yellow_terracotta
setblock 2 236 328 minecraft:yellow_terracotta
fill 2 236 329 2 239 329 minecraft:honeycomb_block
setblock 2 236 333 minecraft:yellow_terracotta
fill 2 236 334 2 239 334 minecraft:honeycomb_block
setblock 2 236 338 minecraft:yellow_terracotta
fill 2 236 339 2 239 339 minecraft:honeycomb_block
setblock 2 236 343 minecraft:yellow_terracotta
fill 2 236 344 2 239 344 minecraft:honeycomb_block
setblock 2 236 348 minecraft:yellow_terracotta
fill 2 236 349 2 239 349 minecraft:honeycomb_block
setblock 2 236 353 minecraft:yellow_terracotta
fill 2 236 354 2 239 354 minecraft:honeycomb_block
setblock 2 236 358 minecraft:yellow_terracotta
fill 2 236 359 2 239 359 minecraft:honeycomb_block
setblock 2 236 363 minecraft:yellow_terracotta
setblock 3 236 332 minecraft:yellow_terracotta
fill 3 236 333 3 239 333 minecraft:honeycomb_block
setblock 3 236 336 minecraft:honeycomb_block
setblock 3 236 337 minecraft:yellow_terracotta
fill 3 236 338 3 239 338 minecraft:honeycomb_block
setblock 3 236 347 minecraft:yellow_terracotta
fill 3 236 348 3 237 348 minecraft:honeycomb_block
setblock 3 236 352 minecraft:yellow_terracotta
fill 3 236 353 3 239 353 minecraft:honeycomb_block
setblock 3 236 357 minecraft:yellow_terracotta
fill 10 236 322 10 239 322 minecraft:honeycomb_block
fill 14 236 323 14 238 323 minecraft:honeycomb_block
setblock 16 236 324 minecraft:yellow_terracotta
setblock 17 236 323 minecraft:yellow_terracotta
fill 17 236 324 17 239 324 minecraft:honeycomb_block
setblock 17 236 363 minecraft:yellow_terracotta
fill 18 236 323 18 239 323 minecraft:honeycomb_block
fill 18 236 363 21 236 363 minecraft:honeycomb_block
setblock 19 236 326 minecraft:yellow_terracotta
setblock 20 236 325 minecraft:yellow_terracotta
fill 20 236 326 20 237 326 minecraft:honeycomb_block
fill 20 236 362 22 236 362 minecraft:honeycomb_block
setblock 21 236 324 minecraft:yellow_terracotta
fill 21 236 325 21 239 325 minecraft:honeycomb_block
setblock 22 236 323 minecraft:yellow_terracotta
fill 22 236 324 22 239 324 minecraft:honeycomb_block
setblock 22 236 363 minecraft:yellow_terracotta
fill 23 236 323 23 239 323 minecraft:honeycomb_block
setblock 23 236 362 minecraft:yellow_terracotta
fill 23 236 363 23 239 363 minecraft:honeycomb_block
setblock 26 236 324 minecraft:yellow_terracotta
setblock 27 236 323 minecraft:yellow_terracotta
setblock 27 236 363 minecraft:yellow_terracotta
fill 28 236 323 28 237 323 minecraft:honeycomb_block
fill 28 236 363 29 238 363 minecraft:honeycomb_block
setblock 31 236 363 minecraft:honeycomb_block
setblock 32 236 363 minecraft:yellow_terracotta
fill 33 236 363 33 239 363 minecraft:honeycomb_block
fill 35 236 362 37 236 362 minecraft:honeycomb_block
setblock 37 236 322 minecraft:yellow_concrete
setblock 37 236 323 minecraft:yellow_terracotta
setblock 37 236 363 minecraft:yellow_terracotta
fill 38 236 323 38 239 323 minecraft:honeycomb_block
fill 38 236 350 38 236 351 minecraft:honeycomb_block
setblock 38 236 352 minecraft:yellow_terracotta
fill 38 236 353 38 239 353 minecraft:honeycomb_block
setblock 38 236 357 minecraft:yellow_terracotta
fill 38 236 358 38 239 358 minecraft:honeycomb_block
setblock 38 236 361 minecraft:honeycomb_block
setblock 38 236 362 minecraft:yellow_terracotta
fill 38 236 363 38 239 364 minecraft:honeycomb_block
setblock 39 236 330 minecraft:honeycomb_block
setblock 39 236 331 minecraft:yellow_terracotta
fill 39 236 332 39 239 332 minecraft:honeycomb_block
fill 39 236 347 39 236 350 minecraft:honeycomb_block
setblock 39 236 351 minecraft:yellow_terracotta
fill 39 236 352 39 239 352 minecraft:honeycomb_block
setblock 39 236 355 minecraft:honeycomb_block
setblock 39 236 356 minecraft:yellow_terracotta
fill 39 236 357 39 239 357 minecraft:honeycomb_block
setblock 39 236 361 minecraft:yellow_terracotta
fill 39 236 362 39 239 362 minecraft:honeycomb_block
setblock 40 236 325 minecraft:yellow_terracotta
fill 40 236 326 40 237 326 minecraft:honeycomb_block
setblock 40 236 330 minecraft:yellow_terracotta
fill 40 236 331 40 239 331 minecraft:honeycomb_block
setblock 40 236 335 minecraft:yellow_terracotta
fill 40 236 336 41 236 338 minecraft:honeycomb_block
fill 40 236 343 40 237 343 minecraft:honeycomb_block
setblock 40 236 345 minecraft:yellow_terracotta
fill 40 236 346 40 239 346 minecraft:honeycomb_block
setblock 40 236 350 minecraft:yellow_terracotta
fill 40 236 351 40 239 351 minecraft:honeycomb_block
setblock 40 236 355 minecraft:yellow_terracotta
fill 40 236 356 40 239 356 minecraft:honeycomb_block
setblock 40 236 360 minecraft:yellow_terracotta
fill 40 236 361 40 239 361 minecraft:honeycomb_block
setblock 41 236 324 minecraft:yellow_terracotta
fill 41 236 325 41 238 325 minecraft:honeycomb_block
setblock 41 236 329 minecraft:yellow_terracotta
fill 41 236 330 41 239 330 minecraft:honeycomb_block
setblock 41 236 334 minecraft:yellow_terracotta
fill 41 236 335 41 239 335 minecraft:honeycomb_block
setblock 41 236 339 minecraft:yellow_terracotta
fill 41 236 340 41 239 340 minecraft:honeycomb_block
setblock 41 236 344 minecraft:yellow_terracotta
fill 41 236 345 41 239 345 minecraft:honeycomb_block
setblock 41 236 349 minecraft:yellow_terracotta
fill 41 236 350 41 239 350 minecraft:honeycomb_block
setblock 41 236 354 minecraft:yellow_terracotta
fill 41 236 355 41 239 355 minecraft:honeycomb_block
setblock 41 236 359 minecraft:yellow_terracotta
fill 41 236 360 41 239 360 minecraft:honeycomb_block
fill 42 236 352 42 277 352 minecraft:honeycomb_block
setblock 42 236 362 minecraft:yellow_concrete
fill 0 237 343 0 272 343 minecraft:honeycomb_block
setblock 1 237 323 minecraft:yellow_terracotta
fill 1 237 324 1 238 324 minecraft:honeycomb_block
setblock 1 237 328 minecraft:yellow_terracotta
fill 1 237 329 1 237 332 minecraft:honeycomb_block
setblock 1 237 333 minecraft:yellow_terracotta
fill 1 237 334 1 240 334 minecraft:honeycomb_block
setblock 1 237 338 minecraft:yellow_terracotta
fill 1 237 339 1 240 339 minecraft:honeycomb_block
setblock 1 237 343 minecraft:yellow_terracotta
fill 1 237 344 1 240 344 minecraft:honeycomb_block
setblock 1 237 348 minecraft:yellow_terracotta
fill 1 237 349 1 240 349 minecraft:honeycomb_block
setblock 1 237 353 minecraft:yellow_terracotta
fill 1 237 354 1 240 354 minecraft:honeycomb_block
setblock 1 237 358 minecraft:yellow_terracotta
fill 1 237 359 1 240 359 minecraft:honeycomb_block
setblock 1 237 363 minecraft:yellow_terracotta
setblock 2 237 327 minecraft:yellow_terracotta
fill 2 237 328 2 239 328 minecraft:honeycomb_block
setblock 2 237 332 minecraft:yellow_terracotta
fill 2 237 333 2 240 333 minecraft:honeycomb_block
setblock 2 237 337 minecraft:yellow_terracotta
fill 2 237 338 2 240 338 minecraft:honeycomb_block
setblock 2 237 342 minecraft:yellow_terracotta
fill 2 237 343 2 240 343 minecraft:honeycomb_block
setblock 2 237 347 minecraft:yellow_terracotta
fill 2 237 348 2 240 348 minecraft:honeycomb_block
setblock 2 237 352 minecraft:yellow_terracotta
fill 2 237 353 2 240 353 minecraft:honeycomb_block
setblock 2 237 356 minecraft:honeycomb_block
setblock 2 237 357 minecraft:yellow_terracotta
fill 2 237 358 2 240 358 minecraft:honeycomb_block
setblock 2 237 363 minecraft:honeycomb_block
setblock 3 237 325 minecraft:light[level=12]
setblock 3 237 331 minecraft:yellow_terracotta
fill 3 237 332 3 240 332 minecraft:honeycomb_block
setblock 3 237 336 minecraft:yellow_terracotta
fill 3 237 337 3 240 337 minecraft:honeycomb_block
fill 3 237 339 3 238 339 minecraft:honeycomb_block
setblock 3 237 346 minecraft:light[level=12]
setblock 3 237 347 minecraft:honeycomb_block
setblock 3 237 351 minecraft:yellow_terracotta
fill 3 237 352 3 239 352 minecraft:honeycomb_block
setblock 3 237 356 minecraft:yellow_terracotta
setblock 3 237 357 minecraft:honeycomb_block
setblock 3 237 360 minecraft:light[level=12]
setblock 7 237 363 minecraft:honey_block
setblock 10 237 325 minecraft:light[level=12]
setblock 10 237 332 minecraft:light[level=12]
setblock 10 237 339 minecraft:light[level=12]
setblock 10 237 346 minecraft:light[level=12]
setblock 10 237 353 minecraft:light[level=12]
setblock 10 237 360 minecraft:light[level=12]
setblock 15 237 324 minecraft:yellow_terracotta
setblock 16 237 323 minecraft:yellow_terracotta
fill 16 237 324 16 240 324 minecraft:honeycomb_block
setblock 16 237 363 minecraft:yellow_terracotta
setblock 17 237 322 minecraft:orange_terracotta
fill 17 237 323 17 240 323 minecraft:honeycomb_block
setblock 17 237 332 minecraft:light[level=12]
setblock 17 237 339 minecraft:light[level=12]
setblock 17 237 346 minecraft:light[level=12]
setblock 17 237 353 minecraft:light[level=12]
setblock 17 237 360 minecraft:light[level=12]
fill 17 237 363 20 237 363 minecraft:honeycomb_block
setblock 18 237 364 minecraft:orange_terracotta
setblock 19 237 325 minecraft:yellow_terracotta
setblock 19 237 326 minecraft:honeycomb_block
fill 19 237 362 21 237 362 minecraft:honeycomb_block
setblock 20 237 324 minecraft:yellow_terracotta
fill 20 237 325 20 239 325 minecraft:honeycomb_block
setblock 21 237 323 minecraft:yellow_terracotta
fill 21 237 324 21 240 324 minecraft:honeycomb_block
setblock 21 237 363 minecraft:yellow_terracotta
fill 22 237 323 22 240 323 minecraft:honeycomb_block
setblock 22 237 362 minecraft:yellow_terracotta
fill 22 237 363 22 240 363 minecraft:honeycomb_block
setblock 22 237 364 minecraft:yellow_concrete
fill 23 237 362 24 239 362 minecraft:honeycomb_block
setblock 24 237 325 minecraft:light[level=12]
setblock 24 237 332 minecraft:light[level=12]
setblock 24 237 339 minecraft:light[level=12]
setblock 24 237 346 minecraft:light[level=12]
setblock 24 237 353 minecraft:light[level=12]
setblock 24 237 360 minecraft:light[level=12]
setblock 25 237 324 minecraft:yellow_terracotta
setblock 26 237 323 minecraft:yellow_terracotta
setblock 26 237 363 minecraft:yellow_terracotta
fill 27 237 323 27 238 323 minecraft:honeycomb_block
fill 27 237 363 27 240 363 minecraft:honeycomb_block
setblock 30 237 363 minecraft:honeycomb_block
setblock 31 237 325 minecraft:light[level=12]
setblock 31 237 332 minecraft:light[level=12]
setblock 31 237 339 minecraft:light[level=12]
setblock 31 237 346 minecraft:light[level=12]
setblock 31 237 353 minecraft:light[level=12]
setblock 31 237 360 minecraft:light[level=12]
setblock 31 237 363 minecraft:yellow_terracotta
fill 32 237 363 32 240 363 minecraft:honeycomb_block
fill 34 237 362 36 237 362 minecraft:honeycomb_block
fill 36 237 322 37 273 322 minecraft:honeycomb_block
setblock 36 237 323 minecraft:yellow_terracotta
setblock 36 237 363 minecraft:yellow_terracotta
fill 37 237 323 37 240 323 minecraft:honeycomb_block
setblock 37 237 361 minecraft:honeycomb_block
setblock 37 237 362 minecraft:yellow_terracotta
fill 37 237 363 37 240 363 minecraft:honeycomb_block
setblock 38 237 325 minecraft:light[level=12]
setblock 38 237 332 minecraft:light[level=12]
setblock 38 237 339 minecraft:light[level=12]
setblock 38 237 346 minecraft:light[level=12]
setblock 38 237 350 minecraft:honeycomb_block
setblock 38 237 351 minecraft:yellow_terracotta
fill 38 237 352 38 240 352 minecraft:honeycomb_block
fill 38 237 354 38 237 355 minecraft:honeycomb_block
setblock 38 237 356 minecraft:yellow_terracotta
fill 38 237 357 38 240 357 minecraft:honeycomb_block
fill 38 237 359 39 237 359 minecraft:honeycomb_block
setblock 38 237 360 minecraft:light[level=12]
setblock 38 237 361 minecraft:yellow_terracotta
fill 38 237 362 38 240 362 minecraft:honeycomb_block
setblock 39 237 330 minecraft:yellow_terracotta
fill 39 237 331 39 238 331 minecraft:honeycomb_block
fill 39 237 333 39 237 334 minecraft:honeycomb_block
fill 39 237 347 39 237 349 minecraft:honeycomb_block
setblock 39 237 350 minecraft:yellow_terracotta
fill 39 237 351 39 240 351 minecraft:honeycomb_block
setblock 39 237 355 minecraft:yellow_terracotta
fill 39 237 356 39 240 356 minecraft:honeycomb_block
fill 39 237 358 39 238 358 minecraft:honeycomb_block
setblock 39 237 360 minecraft:yellow_terracotta
fill 39 237 361 39 240 361 minecraft:honeycomb_block
setblock 40 237 329 minecraft:yellow_terracotta
fill 40 237 330 40 240 330 minecraft:honeycomb_block
setblock 40 237 333 minecraft:honeycomb_block
setblock 40 237 334 minecraft:yellow_terracotta
fill 40 237 335 40 237 338 minecraft:honeycomb_block
setblock 40 237 339 minecraft:yellow_terracotta
fill 40 237 340 40 238 342 minecraft:honeycomb_block
setblock 40 237 344 minecraft:yellow_terracotta
fill 40 237 345 40 240 345 minecraft:honeycomb_block
setblock 40 237 349 minecraft:yellow_terracotta
fill 40 237 350 40 240 350 minecraft:honeycomb_block
setblock 40 237 354 minecraft:yellow_terracotta
fill 40 237 355 40 240 355 minecraft:honeycomb_block
setblock 40 237 359 minecraft:yellow_terracotta
fill 40 237 360 40 240 360 minecraft:honeycomb_block
setblock 41 237 323 minecraft:yellow_terracotta
fill 41 237 324 41 238 324 minecraft:honeycomb_block
setblock 41 237 328 minecraft:yellow_terracotta
fill 41 237 329 41 240 329 minecraft:honeycomb_block
setblock 41 237 333 minecraft:yellow_terracotta
fill 41 237 334 41 240 334 minecraft:honeycomb_block
fill 41 237 336 41 237 337 minecraft:honeycomb_block
setblock 41 237 338 minecraft:yellow_terracotta
fill 41 237 339 41 240 339 minecraft:honeycomb_block
setblock 41 237 343 minecraft:yellow_terracotta
fill 41 237 344 41 240 344 minecraft:honeycomb_block
setblock 41 237 348 minecraft:yellow_terracotta
fill 41 237 349 41 240 349 minecraft:honeycomb_block
setblock 41 237 353 minecraft:yellow_terracotta
fill 41 237 354 41 240 354 minecraft:honeycomb_block
setblock 41 237 358 minecraft:yellow_terracotta
fill 41 237 359 41 240 359 minecraft:honeycomb_block
setblock 41 237 363 minecraft:yellow_terracotta
fill 42 237 362 42 308 362 minecraft:honeycomb_block
setblock 0 238 333 minecraft:yellow_terracotta
fill 0 238 342 0 308 342 minecraft:honeycomb_block
setblock 1 238 327 minecraft:yellow_terracotta
fill 1 238 328 1 238 331 minecraft:honeycomb_block
setblock 1 238 332 minecraft:yellow_terracotta
fill 1 238 333 1 241 333 minecraft:honeycomb_block
setblock 1 238 337 minecraft:yellow_terracotta
fill 1 238 338 1 241 338 minecraft:honeycomb_block
setblock 1 238 342 minecraft:yellow_terracotta
fill 1 238 343 1 241 343 minecraft:honeycomb_block
setblock 1 238 347 minecraft:yellow_terracotta
fill 1 238 348 1 241 348 minecraft:honeycomb_block
setblock 1 238 352 minecraft:yellow_terracotta
fill 1 238 353 1 241 353 minecraft:honeycomb_block
setblock 1 238 357 minecraft:yellow_terracotta
fill 1 238 358 1 241 358 minecraft:honeycomb_block
setblock 1 238 362 minecraft:yellow_terracotta
fill 1 238 363 1 239 363 minecraft:honeycomb_block
setblock 2 238 327 minecraft:honeycomb_block
setblock 2 238 331 minecraft:yellow_terracotta
fill 2 238 332 2 241 332 minecraft:honeycomb_block
setblock 2 238 335 minecraft:honeycomb_block
setblock 2 238 336 minecraft:yellow_terracotta
fill 2 238 337 2 241 337 minecraft:honeycomb_block
setblock 2 238 341 minecraft:yellow_terracotta
fill 2 238 342 2 241 342 minecraft:honeycomb_block
setblock 2 238 346 minecraft:yellow_terracotta
fill 2 238 347 2 240 347 minecraft:honeycomb_block
setblock 2 238 351 minecraft:yellow_terracotta
fill 2 238 352 2 241 352 minecraft:honeycomb_block
setblock 2 238 356 minecraft:yellow_terracotta
fill 2 238 357 2 241 357 minecraft:honeycomb_block
setblock 3 238 330 minecraft:yellow_terracotta
fill 3 238 331 3 239 331 minecraft:honeycomb_block
setblock 3 238 335 minecraft:yellow_terracotta
fill 3 238 336 3 241 336 minecraft:honeycomb_block
setblock 3 238 350 minecraft:yellow_terracotta
setblock 3 238 351 minecraft:honeycomb_block
setblock 3 238 355 minecraft:yellow_terracotta
setblock 3 238 356 minecraft:honeycomb_block
fill 8 238 324 8 246 324 minecraft:brown_terracotta
setblock 10 238 323 minecraft:honey_block
fill 13 238 323 13 239 323 minecraft:honeycomb_block
setblock 13 238 363 minecraft:honey_block
fill 15 238 322 15 308 322 minecraft:honeycomb_block
setblock 15 238 323 minecraft:yellow_terracotta
fill 15 238 324 15 241 324 minecraft:honeycomb_block
setblock 15 238 363 minecraft:yellow_terracotta
fill 16 238 323 16 241 323 minecraft:honeycomb_block
fill 16 238 363 19 238 363 minecraft:honeycomb_block
setblock 16 238 364 minecraft:yellow_terracotta
fill 17 238 322 17 308 322 minecraft:honeycomb_block
setblock 18 238 325 minecraft:yellow_terracotta
fill 18 238 362 20 238 362 minecraft:honeycomb_block
fill 18 238 364 18 264 364 minecraft:honeycomb_block
setblock 19 238 324 minecraft:yellow_terracotta
fill 19 238 325 19 239 325 minecraft:honeycomb_block
setblock 20 238 323 minecraft:yellow_terracotta
fill 20 238 324 20 241 324 minecraft:honeycomb_block
fill 20 238 326 20 271 326 minecraft:yellow_terracotta
setblock 20 238 363 minecraft:yellow_terracotta
fill 21 238 323 21 241 323 minecraft:honeycomb_block
setblock 21 238 362 minecraft:yellow_terracotta
fill 21 238 363 21 241 363 minecraft:honeycomb_block
fill 22 238 362 22 241 362 minecraft:honeycomb_block
fill 22 238 364 22 241 364 minecraft:honeycomb_block
setblock 24 238 324 minecraft:yellow_terracotta
setblock 25 238 323 minecraft:yellow_terracotta
setblock 25 238 363 minecraft:yellow_terracotta
fill 26 238 323 26 239 323 minecraft:honeycomb_block
fill 26 238 363 26 241 363 minecraft:honeycomb_block
setblock 29 238 323 minecraft:honey_block
setblock 30 238 363 minecraft:yellow_terracotta
fill 31 238 363 31 241 363 minecraft:honeycomb_block
fill 33 238 362 35 238 362 minecraft:honeycomb_block
fill 35 238 322 35 238 323 minecraft:yellow_terracotta
fill 35 238 361 36 238 361 minecraft:honeycomb_block
setblock 35 238 363 minecraft:yellow_terracotta
fill 36 238 323 36 240 323 minecraft:honeycomb_block
setblock 36 238 362 minecraft:yellow_terracotta
fill 36 238 363 36 241 363 minecraft:honeycomb_block
fill 37 238 354 37 238 355 minecraft:honeycomb_block
setblock 37 238 361 minecraft:yellow_terracotta
fill 37 238 362 37 241 362 minecraft:honeycomb_block
setblock 38 238 350 minecraft:yellow_terracotta
fill 38 238 351 38 240 351 minecraft:honeycomb_block
setblock 38 238 354 minecraft:honeycomb_block
setblock 38 238 355 minecraft:yellow_terracotta
fill 38 238 356 38 241 356 minecraft:honeycomb_block
setblock 38 238 359 minecraft:honeycomb_block
setblock 38 238 360 minecraft:yellow_terracotta
fill 38 238 361 38 241 361 minecraft:honeycomb_block
setblock 39 238 333 minecraft:honeycomb_block
setblock 39 238 334 minecraft:yellow_terracotta
fill 39 238 335 40 239 336 minecraft:honeycomb_block
fill 39 238 347 39 238 348 minecraft:honeycomb_block
setblock 39 238 349 minecraft:yellow_terracotta
fill 39 238 350 39 241 350 minecraft:honeycomb_block
setblock 39 238 354 minecraft:yellow_terracotta
fill 39 238 355 39 241 355 minecraft:honeycomb_block
setblock 39 238 359 minecraft:yellow_terracotta
fill 39 238 360 39 241 360 minecraft:honeycomb_block
setblock 40 238 323 minecraft:yellow_terracotta
setblock 40 238 328 minecraft:yellow_terracotta
fill 40 238 329 40 239 329 minecraft:honeycomb_block
setblock 40 238 333 minecraft:yellow_terracotta
fill 40 238 334 40 241 334 minecraft:honeycomb_block
setblock 40 238 337 minecraft:honeycomb_block
setblock 40 238 338 minecraft:yellow_terracotta
fill 40 238 339 40 241 339 minecraft:honeycomb_block
setblock 40 238 343 minecraft:yellow_terracotta
fill 40 238 344 40 241 344 minecraft:honeycomb_block
setblock 40 238 348 minecraft:yellow_terracotta
fill 40 238 349 40 241 349 minecraft:honeycomb_block
setblock 40 238 353 minecraft:yellow_terracotta
fill 40 238 354 40 241 354 minecraft:honeycomb_block
setblock 40 238 358 minecraft:yellow_terracotta
fill 40 238 359 40 241 359 minecraft:honeycomb_block
setblock 40 238 363 minecraft:yellow_terracotta
setblock 41 238 323 minecraft:honeycomb_block
setblock 41 238 327 minecraft:yellow_terracotta
fill 41 238 328 41 240 328 minecraft:honeycomb_block
setblock 41 238 332 minecraft:yellow_terracotta
fill 41 238 333 41 241 333 minecraft:honeycomb_block
setblock 41 238 336 minecraft:honeycomb_block
setblock 41 238 337 minecraft:yellow_terracotta
fill 41 238 338 41 241 338 minecraft:honeycomb_block
setblock 41 238 342 minecraft:yellow_terracotta
fill 41 238 343 41 241 343 minecraft:honeycomb_block
setblock 41 238 347 minecraft:yellow_terracotta
fill 41 238 348 41 241 348 minecraft:honeycomb_block
setblock 41 238 352 minecraft:yellow_terracotta
fill 41 238 353 41 241 353 minecraft:honeycomb_block
setblock 41 238 357 minecraft:yellow_terracotta
fill 41 238 358 41 241 358 minecraft:honeycomb_block
setblock 41 238 362 minecraft:yellow_terracotta
fill 41 238 363 41 241 363 minecraft:honeycomb_block
setblock 42 238 346 minecraft:yellow_terracotta
fill 0 239 333 0 308 333 minecraft:honeycomb_block
setblock 1 239 326 minecraft:yellow_terracotta
fill 1 239 327 1 239 330 minecraft:honeycomb_block
setblock 1 239 331 minecraft:yellow_terracotta
fill 1 239 332 1 242 332 minecraft:honeycomb_block
setblock 1 239 336 minecraft:yellow_terracotta
fill 1 239 337 1 242 337 minecraft:honeycomb_block
setblock 1 239 341 minecraft:yellow_terracotta
fill 1 239 342 1 242 342 minecraft:honeycomb_block
setblock 1 239 346 minecraft:yellow_terracotta
fill 1 239 347 1 242 347 minecraft:honeycomb_block
setblock 1 239 351 minecraft:yellow_terracotta
fill 1 239 352 1 242 352 minecraft:honeycomb_block
setblock 1 239 356 minecraft:yellow_terracotta
fill 1 239 357 1 242 357 minecraft:honeycomb_block
setblock 1 239 360 minecraft:honeycomb_block
setblock 1 239 361 minecraft:yellow_terracotta
fill 1 239 362 1 241 362 minecraft:honeycomb_block
setblock 2 239 330 minecraft:yellow_terracotta
fill 2 239 331 2 241 331 minecraft:honeycomb_block
setblock 2 239 335 minecraft:yellow_terracotta
fill 2 239 336 2 242 336 minecraft:honeycomb_block
setblock 2 239 340 minecraft:yellow_terracotta
fill 2 239 341 2 242 341 minecraft:honeycomb_block
setblock 2 239 345 minecraft:yellow_terracotta
setblock 2 239 346 minecraft:honeycomb_block
setblock 2 239 350 minecraft:yellow_terracotta
fill 2 239 351 2 240 351 minecraft:honeycomb_block
setblock 2 239 355 minecraft:yellow_terracotta
fill 2 239 356 2 241 356 minecraft:honeycomb_block
setblock 3 239 325 minecraft:light[level=15]
setblock 3 239 334 minecraft:yellow_terracotta
fill 3 239 335 3 241 335 minecraft:honeycomb_block
setblock 3 239 339 minecraft:yellow_terracotta
setblock 3 239 341 minecraft:light[level=15]
setblock 3 239 349 minecraft:light[level=15]
setblock 3 239 354 minecraft:yellow_terracotta
setblock 3 239 355 minecraft:honeycomb_block
setblock 3 239 357 minecraft:light[level=15]
setblock 4 239 323 minecraft:honey_block
setblock 11 239 325 minecraft:light[level=15]
setblock 11 239 333 minecraft:light[level=15]
setblock 11 239 341 minecraft:light[level=15]
setblock 11 239 349 minecraft:light[level=15]
setblock 11 239 357 minecraft:light[level=15]
setblock 14 239 323 minecraft:yellow_terracotta
fill 15 239 323 15 242 323 minecraft:honeycomb_block
fill 15 239 363 18 239 363 minecraft:honeycomb_block
fill 16 239 364 16 308 364 minecraft:honeycomb_block
setblock 17 239 325 minecraft:yellow_terracotta
fill 17 239 362 19 239 362 minecraft:honeycomb_block
setblock 18 239 324 minecraft:yellow_terracotta
setblock 18 239 325 minecraft:honeycomb_block
setblock 19 239 323 minecraft:yellow_terracotta
fill 19 239 324 19 242 324 minecraft:honeycomb_block
setblock 19 239 333 minecraft:light[level=15]
setblock 19 239 341 minecraft:light[level=15]
setblock 19 239 349 minecraft:light[level=15]
setblock 19 239 357 minecraft:light[level=15]
setblock 19 239 363 minecraft:yellow_terracotta
fill 20 239 323 20 242 323 minecraft:honeycomb_block
setblock 20 239 362 minecraft:yellow_terracotta
fill 20 239 363 20 242 363 minecraft:honeycomb_block
fill 21 239 362 21 242 362 minecraft:honeycomb_block
setblock 23 239 324 minecraft:yellow_terracotta
setblock 24 239 323 minecraft:yellow_terracotta
setblock 24 239 363 minecraft:yellow_terracotta
fill 25 239 323 25 240 323 minecraft:honeycomb_block
fill 25 239 363 25 242 363 minecraft:honeycomb_block
setblock 27 239 325 minecraft:light[level=15]
setblock 27 239 333 minecraft:light[level=15]
setblock 27 239 341 minecraft:light[level=15]
setblock 27 239 349 minecraft:light[level=15]
setblock 27 239 357 minecraft:light[level=15]
setblock 28 239 363 minecraft:honeycomb_block
setblock 29 239 363 minecraft:yellow_terracotta
fill 30 239 363 30 242 363 minecraft:honeycomb_block
fill 32 239 362 34 239 362 minecraft:honeycomb_block
setblock 34 239 363 minecraft:yellow_terracotta
fill 35 239 322 35 239 323 minecraft:honeycomb_block
setblock 35 239 325 minecraft:light[level=15]
setblock 35 239 333 minecraft:light[level=15]
setblock 35 239 341 minecraft:light[level=15]
setblock 35 239 357 minecraft:light[level=15]
setblock 35 239 361 minecraft:honeycomb_block
setblock 35 239 362 minecraft:yellow_terracotta
fill 35 239 363 35 242 363 minecraft:honeycomb_block
setblock 36 239 361 minecraft:yellow_terracotta
schedule function dropper:buildpart/72_9 1t
