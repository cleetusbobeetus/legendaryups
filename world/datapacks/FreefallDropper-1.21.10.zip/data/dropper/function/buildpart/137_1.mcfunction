fill 277 82 586 277 87 587 minecraft:black_concrete
fill 277 82 588 277 83 589 minecraft:yellow_concrete
fill 277 82 595 277 84 595 minecraft:black_concrete
setblock 277 82 597 minecraft:yellow_concrete
fill 277 82 598 277 87 598 minecraft:black_concrete
setblock 235 83 559 minecraft:yellow_concrete
fill 235 83 563 235 86 563 minecraft:black_concrete
fill 235 83 579 235 83 580 minecraft:yellow_concrete
setblock 235 83 583 minecraft:yellow_concrete
fill 235 83 584 235 86 584 minecraft:black_concrete
fill 235 83 595 235 86 595 minecraft:black_concrete
setblock 236 83 599 minecraft:yellow_concrete
fill 244 83 557 244 86 557 minecraft:black_concrete
setblock 245 83 557 minecraft:yellow_concrete
setblock 247 83 599 minecraft:yellow_concrete
fill 248 83 557 249 83 557 minecraft:yellow_concrete
fill 251 83 599 252 86 599 minecraft:black_concrete
fill 265 83 557 265 86 557 minecraft:black_concrete
setblock 268 83 599 minecraft:yellow_concrete
setblock 269 83 557 minecraft:yellow_concrete
setblock 271 83 599 minecraft:yellow_concrete
fill 272 83 599 272 86 599 minecraft:black_concrete
fill 276 83 557 276 86 557 minecraft:black_concrete
setblock 277 83 557 minecraft:yellow_concrete
setblock 277 83 560 minecraft:yellow_concrete
fill 277 83 565 277 85 565 minecraft:black_concrete
fill 277 83 576 277 86 576 minecraft:black_concrete
setblock 277 83 577 minecraft:yellow_concrete
setblock 277 83 581 minecraft:yellow_concrete
setblock 277 83 592 minecraft:yellow_concrete
fill 277 83 593 277 85 593 minecraft:black_concrete
fill 277 83 597 277 86 597 minecraft:black_concrete
fill 235 84 557 235 85 558 minecraft:yellow_concrete
fill 235 84 559 235 89 560 minecraft:black_concrete
fill 235 84 569 235 84 570 minecraft:yellow_concrete
fill 235 84 571 235 89 572 minecraft:black_concrete
fill 235 84 578 235 85 578 minecraft:yellow_concrete
fill 235 84 579 235 89 580 minecraft:black_concrete
setblock 235 84 581 minecraft:yellow_concrete
fill 235 84 583 235 89 583 minecraft:black_concrete
fill 235 84 589 235 85 590 minecraft:yellow_concrete
fill 235 84 591 235 89 592 minecraft:black_concrete
fill 236 84 557 237 89 557 minecraft:black_concrete
fill 236 84 558 238 84 558 minecraft:orange_concrete
fill 236 84 560 236 84 562 minecraft:orange_concrete
fill 236 84 564 236 84 566 minecraft:orange_concrete
fill 236 84 568 236 84 570 minecraft:orange_concrete
fill 236 84 572 236 84 574 minecraft:orange_concrete
fill 236 84 576 236 84 578 minecraft:orange_concrete
fill 236 84 580 236 84 582 minecraft:orange_concrete
fill 236 84 584 236 84 586 minecraft:orange_concrete
fill 236 84 588 236 84 590 minecraft:orange_concrete
fill 236 84 592 236 84 594 minecraft:orange_concrete
fill 236 84 596 236 84 598 minecraft:orange_concrete
fill 236 84 599 236 89 599 minecraft:black_concrete
fill 237 84 599 238 84 599 minecraft:yellow_concrete
fill 238 84 557 239 85 557 minecraft:yellow_concrete
fill 238 84 598 240 84 598 minecraft:orange_concrete
fill 239 84 599 240 89 599 minecraft:black_concrete
fill 240 84 558 242 84 558 minecraft:orange_concrete
fill 242 84 598 244 84 598 minecraft:orange_concrete
fill 244 84 558 246 84 558 minecraft:orange_concrete
fill 245 84 557 245 89 557 minecraft:black_concrete
fill 245 84 599 246 85 599 minecraft:yellow_concrete
fill 246 84 598 248 84 598 minecraft:orange_concrete
setblock 247 84 557 minecraft:yellow_concrete
fill 247 84 599 248 89 599 minecraft:black_concrete
fill 248 84 557 249 89 557 minecraft:black_concrete
fill 248 84 558 250 84 558 minecraft:orange_concrete
setblock 249 84 599 minecraft:yellow_concrete
fill 250 84 557 250 85 557 minecraft:yellow_concrete
fill 250 84 598 252 84 598 minecraft:orange_concrete
fill 252 84 558 254 84 558 minecraft:orange_concrete
fill 254 84 598 256 84 598 minecraft:orange_concrete
fill 256 84 557 257 89 557 minecraft:black_concrete
fill 256 84 558 258 84 558 minecraft:orange_concrete
fill 257 84 599 258 85 599 minecraft:yellow_concrete
fill 258 84 557 259 84 557 minecraft:yellow_concrete
fill 258 84 598 260 84 598 minecraft:orange_concrete
fill 259 84 599 260 89 599 minecraft:black_concrete
fill 260 84 558 262 84 558 minecraft:orange_concrete
fill 262 84 598 264 84 598 minecraft:orange_concrete
fill 264 84 558 266 84 558 minecraft:orange_concrete
fill 266 84 598 268 84 598 minecraft:orange_concrete
fill 266 84 599 266 85 599 minecraft:yellow_concrete
fill 268 84 557 269 89 557 minecraft:black_concrete
fill 268 84 558 270 84 558 minecraft:orange_concrete
fill 268 84 599 268 89 599 minecraft:black_concrete
fill 269 84 599 270 84 599 minecraft:yellow_concrete
fill 270 84 557 271 85 557 minecraft:yellow_concrete
fill 270 84 598 272 84 598 minecraft:orange_concrete
fill 271 84 599 271 89 599 minecraft:black_concrete
fill 272 84 558 274 84 558 minecraft:orange_concrete
fill 274 84 598 276 84 598 minecraft:orange_concrete
fill 276 84 558 276 84 560 minecraft:orange_concrete
fill 276 84 562 276 84 564 minecraft:orange_concrete
fill 276 84 566 276 84 568 minecraft:orange_concrete
fill 276 84 570 276 84 572 minecraft:orange_concrete
fill 276 84 574 276 84 576 minecraft:orange_concrete
fill 276 84 578 276 84 580 minecraft:orange_concrete
fill 276 84 582 276 84 584 minecraft:orange_concrete
fill 276 84 586 276 84 588 minecraft:orange_concrete
fill 276 84 590 276 84 592 minecraft:orange_concrete
fill 276 84 594 276 84 596 minecraft:orange_concrete
fill 277 84 557 277 89 557 minecraft:black_concrete
fill 277 84 558 277 84 559 minecraft:yellow_concrete
fill 277 84 560 277 89 560 minecraft:black_concrete
fill 277 84 562 277 85 562 minecraft:yellow_concrete
setblock 277 84 563 minecraft:black_concrete
fill 277 84 568 277 89 569 minecraft:black_concrete
fill 277 84 570 277 85 571 minecraft:yellow_concrete
fill 277 84 577 277 86 577 minecraft:black_concrete
setblock 277 84 579 minecraft:yellow_concrete
fill 277 84 580 277 89 581 minecraft:black_concrete
fill 277 84 582 277 85 583 minecraft:yellow_concrete
fill 277 84 588 277 89 589 minecraft:black_concrete
fill 277 84 590 277 84 591 minecraft:yellow_concrete
fill 277 84 592 277 85 592 minecraft:black_concrete
fill 277 84 599 277 85 599 minecraft:yellow_concrete
setblock 235 85 566 minecraft:yellow_concrete
setblock 235 85 569 minecraft:yellow_concrete
fill 235 85 570 235 88 570 minecraft:black_concrete
setblock 235 85 577 minecraft:yellow_concrete
fill 235 85 581 235 88 581 minecraft:black_concrete
fill 235 85 597 235 85 598 minecraft:yellow_concrete
setblock 237 85 599 minecraft:yellow_concrete
fill 238 85 599 238 88 599 minecraft:black_concrete
fill 247 85 557 247 88 557 minecraft:black_concrete
fill 249 85 599 249 88 599 minecraft:black_concrete
setblock 251 85 557 minecraft:yellow_concrete
setblock 254 85 599 minecraft:yellow_concrete
fill 258 85 557 258 88 557 minecraft:black_concrete
setblock 259 85 557 minecraft:yellow_concrete
setblock 262 85 557 minecraft:yellow_concrete
setblock 265 85 599 minecraft:yellow_concrete
fill 269 85 599 270 88 599 minecraft:black_concrete
fill 277 85 558 277 88 559 minecraft:black_concrete
setblock 277 85 563 minecraft:yellow_concrete
setblock 277 85 574 minecraft:yellow_concrete
fill 277 85 575 277 87 575 minecraft:black_concrete
fill 277 85 579 277 88 579 minecraft:black_concrete
fill 277 85 590 277 88 590 minecraft:black_concrete
setblock 277 85 591 minecraft:yellow_concrete
fill 277 85 594 277 85 595 minecraft:yellow_concrete
fill 235 86 557 235 91 558 minecraft:black_concrete
fill 235 86 564 235 87 564 minecraft:yellow_concrete
fill 235 86 566 235 91 566 minecraft:black_concrete
fill 235 86 567 235 86 568 minecraft:yellow_concrete
fill 235 86 569 235 91 569 minecraft:black_concrete
fill 235 86 575 235 87 576 minecraft:yellow_concrete
fill 235 86 577 235 91 578 minecraft:black_concrete
fill 235 86 587 235 86 588 minecraft:yellow_concrete
fill 235 86 589 235 91 590 minecraft:black_concrete
fill 235 86 596 235 87 596 minecraft:yellow_concrete
fill 235 86 597 235 91 598 minecraft:black_concrete
setblock 235 86 599 minecraft:yellow_concrete
fill 237 86 599 237 91 599 minecraft:black_concrete
fill 238 86 557 239 91 557 minecraft:black_concrete
fill 240 86 557 241 86 557 minecraft:yellow_concrete
fill 243 86 599 244 87 599 minecraft:yellow_concrete
fill 245 86 599 246 91 599 minecraft:black_concrete
fill 250 86 557 251 91 557 minecraft:black_concrete
fill 252 86 557 253 87 557 minecraft:yellow_concrete
fill 254 86 599 254 91 599 minecraft:black_concrete
fill 255 86 599 256 86 599 minecraft:yellow_concrete
fill 257 86 599 258 91 599 minecraft:black_concrete
fill 259 86 557 259 91 557 minecraft:black_concrete
fill 260 86 557 261 86 557 minecraft:yellow_concrete
fill 262 86 557 262 91 557 minecraft:black_concrete
fill 263 86 599 264 87 599 minecraft:yellow_concrete
fill 264 86 557 264 87 557 minecraft:yellow_concrete
fill 265 86 599 266 91 599 minecraft:black_concrete
setblock 267 86 599 minecraft:yellow_concrete
fill 270 86 557 271 91 557 minecraft:black_concrete
fill 272 86 557 273 87 557 minecraft:yellow_concrete
fill 275 86 599 276 87 599 minecraft:yellow_concrete
setblock 277 86 561 minecraft:yellow_concrete
fill 277 86 562 277 91 563 minecraft:black_concrete
fill 277 86 564 277 87 565 minecraft:yellow_concrete
fill 277 86 570 277 91 571 minecraft:black_concrete
fill 277 86 572 277 86 573 minecraft:yellow_concrete
fill 277 86 574 277 87 574 minecraft:black_concrete
fill 277 86 582 277 91 583 minecraft:black_concrete
fill 277 86 584 277 87 585 minecraft:yellow_concrete
fill 277 86 591 277 91 591 minecraft:black_concrete
fill 277 86 592 277 86 593 minecraft:yellow_concrete
fill 277 86 594 277 87 595 minecraft:black_concrete
fill 277 86 596 277 87 596 minecraft:yellow_concrete
fill 277 86 599 277 91 599 minecraft:black_concrete
setblock 235 87 563 minecraft:yellow_concrete
fill 235 87 567 235 90 568 minecraft:black_concrete
setblock 235 87 584 minecraft:yellow_concrete
setblock 235 87 587 minecraft:yellow_concrete
fill 235 87 588 235 90 588 minecraft:black_concrete
setblock 235 87 595 minecraft:yellow_concrete
fill 235 87 599 235 90 599 minecraft:black_concrete
fill 240 87 557 240 90 557 minecraft:black_concrete
setblock 241 87 557 minecraft:yellow_concrete
setblock 244 87 557 minecraft:yellow_concrete
fill 251 87 599 252 87 599 minecraft:yellow_concrete
setblock 255 87 599 minecraft:yellow_concrete
fill 256 87 599 256 90 599 minecraft:black_concrete
fill 260 87 557 261 90 557 minecraft:black_concrete
setblock 265 87 557 minecraft:yellow_concrete
fill 267 87 599 267 90 599 minecraft:black_concrete
setblock 272 87 599 minecraft:yellow_concrete
setblock 276 87 557 minecraft:yellow_concrete
fill 277 87 561 277 90 561 minecraft:black_concrete
fill 277 87 572 277 90 572 minecraft:black_concrete
setblock 277 87 573 minecraft:yellow_concrete
fill 277 87 576 277 87 577 minecraft:yellow_concrete
fill 277 87 592 277 89 593 minecraft:black_concrete
setblock 277 87 597 minecraft:yellow_concrete
fill 235 88 561 235 89 562 minecraft:yellow_concrete
fill 235 88 563 235 93 564 minecraft:black_concrete
setblock 235 88 565 minecraft:yellow_concrete
fill 235 88 573 235 89 574 minecraft:yellow_concrete
fill 235 88 575 235 93 576 minecraft:black_concrete
fill 235 88 582 235 89 582 minecraft:yellow_concrete
fill 235 88 584 235 93 584 minecraft:black_concrete
fill 235 88 585 235 88 586 minecraft:yellow_concrete
fill 235 88 587 235 93 587 minecraft:black_concrete
fill 235 88 593 235 89 594 minecraft:yellow_concrete
fill 235 88 595 235 93 596 minecraft:black_concrete
fill 241 88 557 241 93 557 minecraft:black_concrete
fill 241 88 599 242 88 599 minecraft:yellow_concrete
fill 242 88 557 243 88 557 minecraft:yellow_concrete
fill 243 88 599 244 93 599 minecraft:black_concrete
fill 244 88 557 244 93 557 minecraft:black_concrete
fill 246 88 557 246 89 557 minecraft:yellow_concrete
fill 250 88 599 250 89 599 minecraft:yellow_concrete
fill 251 88 599 252 93 599 minecraft:black_concrete
fill 252 88 557 253 93 557 minecraft:black_concrete
fill 252 88 597 252 91 597 minecraft:magma_block
setblock 253 88 599 minecraft:yellow_concrete
fill 254 88 557 255 89 557 minecraft:yellow_concrete
fill 255 88 599 255 93 599 minecraft:black_concrete
fill 261 88 599 262 89 599 minecraft:yellow_concrete
setblock 263 88 557 minecraft:yellow_concrete
fill 263 88 599 264 93 599 minecraft:black_concrete
fill 264 88 557 265 93 557 minecraft:black_concrete
fill 266 88 557 267 89 557 minecraft:yellow_concrete
fill 272 88 557 273 93 557 minecraft:black_concrete
fill 272 88 599 272 93 599 minecraft:black_concrete
fill 273 88 599 274 88 599 minecraft:yellow_concrete
fill 274 88 557 275 88 557 minecraft:yellow_concrete
fill 275 88 599 276 90 599 minecraft:black_concrete
fill 276 88 557 276 93 557 minecraft:black_concrete
fill 277 88 564 277 93 565 minecraft:black_concrete
fill 277 88 566 277 89 567 minecraft:yellow_concrete
fill 277 88 573 277 93 573 minecraft:black_concrete
fill 277 88 574 277 88 575 minecraft:yellow_concrete
fill 277 88 576 277 89 577 minecraft:black_concrete
fill 277 88 578 277 89 578 minecraft:yellow_concrete
fill 277 88 584 277 93 585 minecraft:black_concrete
fill 277 88 586 277 89 587 minecraft:yellow_concrete
fill 277 88 594 277 91 594 minecraft:black_concrete
setblock 277 88 595 minecraft:yellow_concrete
fill 277 88 596 277 93 597 minecraft:black_concrete
fill 277 88 598 277 89 598 minecraft:yellow_concrete
fill 235 89 565 235 92 565 minecraft:black_concrete
setblock 235 89 570 minecraft:yellow_concrete
setblock 235 89 581 minecraft:yellow_concrete
fill 235 89 585 235 92 586 minecraft:black_concrete
setblock 238 89 599 minecraft:yellow_concrete
setblock 241 89 599 minecraft:yellow_concrete
fill 242 89 557 243 92 557 minecraft:black_concrete
fill 242 89 599 242 92 599 minecraft:black_concrete
setblock 247 89 557 minecraft:yellow_concrete
setblock 249 89 599 minecraft:yellow_concrete
fill 251 89 596 251 89 598 minecraft:magma_block
fill 252 89 595 252 91 596 minecraft:magma_block
fill 252 89 598 253 89 598 minecraft:magma_block
fill 253 89 596 253 90 597 minecraft:magma_block
fill 253 89 599 253 92 599 minecraft:black_concrete
setblock 258 89 557 minecraft:yellow_concrete
fill 263 89 557 263 92 557 minecraft:black_concrete
fill 269 89 599 270 89 599 minecraft:yellow_concrete
setblock 273 89 599 minecraft:yellow_concrete
fill 274 89 557 274 92 557 minecraft:black_concrete
fill 274 89 599 274 92 599 minecraft:black_concrete
setblock 275 89 557 minecraft:yellow_concrete
fill 277 89 558 277 89 559 minecraft:yellow_concrete
fill 277 89 574 277 91 575 minecraft:black_concrete
setblock 277 89 579 minecraft:yellow_concrete
setblock 277 89 590 minecraft:yellow_concrete
fill 277 89 595 277 91 595 minecraft:black_concrete
fill 235 90 559 235 91 560 minecraft:yellow_concrete
fill 235 90 561 235 95 562 minecraft:black_concrete
fill 235 90 570 235 95 570 minecraft:black_concrete
fill 235 90 571 235 90 572 minecraft:yellow_concrete
fill 235 90 573 235 95 574 minecraft:black_concrete
fill 235 90 579 235 91 580 minecraft:yellow_concrete
fill 235 90 581 235 95 582 minecraft:black_concrete
setblock 235 90 583 minecraft:yellow_concrete
fill 235 90 591 235 91 592 minecraft:yellow_concrete
fill 235 90 593 235 95 594 minecraft:black_concrete
fill 236 90 557 237 91 557 minecraft:yellow_concrete
fill 236 90 558 238 90 558 minecraft:orange_concrete
fill 236 90 560 236 90 562 minecraft:orange_concrete
fill 236 90 564 236 90 566 minecraft:orange_concrete
fill 236 90 568 236 90 570 minecraft:orange_concrete
fill 236 90 572 236 90 574 minecraft:orange_concrete
fill 236 90 576 236 90 578 minecraft:orange_concrete
fill 236 90 580 236 90 582 minecraft:orange_concrete
fill 236 90 584 236 90 586 minecraft:orange_concrete
fill 236 90 588 236 90 590 minecraft:orange_concrete
fill 236 90 592 236 90 594 minecraft:orange_concrete
fill 236 90 596 236 90 598 minecraft:orange_concrete
fill 236 90 599 236 91 599 minecraft:yellow_concrete
setblock 238 90 560 minecraft:light[level=14]
setblock 238 90 568 minecraft:light[level=14]
setblock 238 90 576 minecraft:light[level=14]
setblock 238 90 584 minecraft:light[level=14]
setblock 238 90 592 minecraft:light[level=14]
fill 238 90 598 240 90 598 minecraft:orange_concrete
fill 238 90 599 238 95 599 minecraft:black_concrete
fill 239 90 599 240 90 599 minecraft:yellow_concrete
fill 240 90 558 242 90 558 minecraft:orange_concrete
fill 241 90 599 241 95 599 minecraft:black_concrete
fill 242 90 598 244 90 598 minecraft:orange_concrete
fill 244 90 558 246 90 558 minecraft:orange_concrete
setblock 245 90 557 minecraft:yellow_concrete
fill 246 90 557 247 95 557 minecraft:black_concrete
setblock 246 90 560 minecraft:light[level=14]
setblock 246 90 568 minecraft:light[level=14]
setblock 246 90 576 minecraft:light[level=14]
setblock 246 90 584 minecraft:light[level=14]
setblock 246 90 592 minecraft:light[level=14]
fill 246 90 598 248 90 598 minecraft:orange_concrete
fill 247 90 599 248 91 599 minecraft:yellow_concrete
fill 248 90 557 249 91 557 minecraft:yellow_concrete
fill 248 90 558 250 90 558 minecraft:orange_concrete
fill 249 90 599 250 95 599 minecraft:black_concrete
fill 250 90 598 252 90 598 minecraft:orange_concrete
fill 251 90 595 251 90 597 minecraft:magma_block
fill 252 90 558 254 90 558 minecraft:orange_concrete
fill 252 90 594 252 92 594 minecraft:magma_block
fill 253 90 595 253 91 595 minecraft:magma_block
setblock 253 90 598 minecraft:magma_block
fill 254 90 557 255 95 557 minecraft:black_concrete
setblock 254 90 560 minecraft:light[level=14]
setblock 254 90 568 minecraft:light[level=14]
setblock 254 90 576 minecraft:light[level=14]
setblock 254 90 584 minecraft:light[level=14]
setblock 254 90 592 minecraft:light[level=14]
fill 254 90 598 256 90 598 minecraft:orange_concrete
fill 256 90 557 257 90 557 minecraft:yellow_concrete
fill 256 90 558 258 90 558 minecraft:orange_concrete
fill 258 90 557 258 95 557 minecraft:black_concrete
fill 258 90 598 260 90 598 minecraft:orange_concrete
fill 259 90 599 260 90 599 minecraft:yellow_concrete
fill 260 90 558 262 90 558 minecraft:orange_concrete
fill 261 90 599 262 95 599 minecraft:black_concrete
setblock 262 90 560 minecraft:light[level=14]
setblock 262 90 568 minecraft:light[level=14]
setblock 262 90 576 minecraft:light[level=14]
setblock 262 90 584 minecraft:light[level=14]
setblock 262 90 592 minecraft:light[level=14]
fill 262 90 598 264 90 598 minecraft:orange_concrete
fill 264 90 558 266 90 558 minecraft:orange_concrete
fill 266 90 557 267 95 557 minecraft:black_concrete
fill 266 90 598 268 90 598 minecraft:orange_concrete
fill 268 90 557 269 91 557 minecraft:yellow_concrete
fill 268 90 558 270 90 558 minecraft:orange_concrete
fill 268 90 599 268 91 599 minecraft:yellow_concrete
fill 269 90 599 270 95 599 minecraft:black_concrete
setblock 270 90 560 minecraft:light[level=14]
setblock 270 90 568 minecraft:light[level=14]
setblock 270 90 576 minecraft:light[level=14]
setblock 270 90 584 minecraft:light[level=14]
setblock 270 90 592 minecraft:light[level=14]
fill 270 90 598 272 90 598 minecraft:orange_concrete
setblock 271 90 599 minecraft:yellow_concrete
fill 272 90 558 274 90 558 minecraft:orange_concrete
fill 273 90 599 273 92 599 minecraft:black_concrete
fill 274 90 598 276 90 598 minecraft:orange_concrete
fill 275 90 557 275 95 557 minecraft:black_concrete
fill 276 90 558 276 90 560 minecraft:orange_concrete
fill 276 90 562 276 90 564 minecraft:orange_concrete
fill 276 90 566 276 90 568 minecraft:orange_concrete
fill 276 90 570 276 90 572 minecraft:orange_concrete
fill 276 90 574 276 90 576 minecraft:orange_concrete
fill 276 90 578 276 90 580 minecraft:orange_concrete
fill 276 90 582 276 90 584 minecraft:orange_concrete
fill 276 90 586 276 90 588 minecraft:orange_concrete
fill 276 90 590 276 90 592 minecraft:orange_concrete
fill 276 90 594 276 90 596 minecraft:orange_concrete
setblock 277 90 557 minecraft:yellow_concrete
fill 277 90 558 277 95 559 minecraft:black_concrete
fill 277 90 560 277 91 560 minecraft:yellow_concrete
fill 277 90 566 277 95 567 minecraft:black_concrete
fill 277 90 568 277 90 569 minecraft:yellow_concrete
fill 277 90 576 277 93 576 minecraft:black_concrete
setblock 277 90 577 minecraft:yellow_concrete
fill 277 90 578 277 95 579 minecraft:black_concrete
fill 277 90 580 277 91 581 minecraft:yellow_concrete
fill 277 90 586 277 92 587 minecraft:black_concrete
fill 277 90 588 277 90 589 minecraft:yellow_concrete
fill 277 90 590 277 95 590 minecraft:black_concrete
fill 277 90 592 277 91 592 minecraft:yellow_concrete
setblock 277 90 593 minecraft:black_concrete
fill 277 90 598 277 95 598 minecraft:black_concrete
fill 235 91 567 235 91 568 minecraft:yellow_concrete
setblock 235 91 571 minecraft:yellow_concrete
fill 235 91 572 235 94 572 minecraft:black_concrete
fill 235 91 583 235 94 583 minecraft:black_concrete
setblock 235 91 588 minecraft:yellow_concrete
setblock 235 91 599 minecraft:yellow_concrete
fill 239 91 599 240 94 599 minecraft:black_concrete
setblock 240 91 557 minecraft:yellow_concrete
fill 245 91 557 245 94 557 minecraft:black_concrete
fill 251 91 594 251 91 596 minecraft:magma_block
fill 252 91 593 252 92 593 minecraft:magma_block
setblock 253 91 594 minecraft:magma_block
setblock 253 91 596 minecraft:magma_block
fill 256 91 557 256 94 557 minecraft:black_concrete
setblock 256 91 599 minecraft:yellow_concrete
setblock 257 91 557 minecraft:yellow_concrete
setblock 259 91 599 minecraft:yellow_concrete
fill 260 91 557 261 91 557 minecraft:yellow_concrete
fill 260 91 599 260 94 599 minecraft:black_concrete
setblock 267 91 599 minecraft:yellow_concrete
fill 271 91 599 271 94 599 minecraft:black_concrete
fill 275 91 599 275 93 599 minecraft:black_concrete
setblock 276 91 599 minecraft:yellow_concrete
fill 277 91 557 277 94 557 minecraft:black_concrete
setblock 277 91 561 minecraft:yellow_concrete
fill 277 91 568 277 94 568 minecraft:black_concrete
setblock 277 91 569 minecraft:yellow_concrete
setblock 277 91 572 minecraft:yellow_concrete
fill 277 91 577 277 93 577 minecraft:black_concrete
fill 277 91 588 277 94 588 minecraft:black_concrete
setblock 277 91 589 minecraft:yellow_concrete
setblock 277 91 593 minecraft:yellow_concrete
fill 235 92 557 235 92 558 minecraft:yellow_concrete
fill 235 92 559 235 97 560 minecraft:black_concrete
fill 235 92 566 235 93 566 minecraft:yellow_concrete
fill 235 92 567 235 97 568 minecraft:black_concrete
setblock 235 92 569 minecraft:yellow_concrete
fill 235 92 571 235 97 571 minecraft:black_concrete
fill 235 92 577 235 93 578 minecraft:yellow_concrete
fill 235 92 579 235 97 580 minecraft:black_concrete
fill 235 92 588 235 97 588 minecraft:black_concrete
fill 235 92 589 235 92 590 minecraft:yellow_concrete
fill 235 92 591 235 97 592 minecraft:black_concrete
fill 235 92 597 235 93 598 minecraft:yellow_concrete
fill 235 92 599 236 97 599 minecraft:black_concrete
fill 236 92 557 237 97 557 minecraft:black_concrete
setblock 237 92 599 minecraft:yellow_concrete
fill 238 92 557 239 92 557 minecraft:yellow_concrete
fill 240 92 557 240 97 557 minecraft:black_concrete
fill 245 92 599 246 93 599 minecraft:yellow_concrete
fill 247 92 599 248 97 599 minecraft:black_concrete
fill 248 92 557 249 97 557 minecraft:black_concrete
fill 250 92 557 251 93 557 minecraft:yellow_concrete
setblock 252 92 592 minecraft:magma_block
fill 254 92 599 254 93 599 minecraft:yellow_concrete
fill 256 92 599 256 97 599 minecraft:black_concrete
fill 257 92 557 257 97 557 minecraft:black_concrete
fill 257 92 599 258 92 599 minecraft:yellow_concrete
setblock 259 92 557 minecraft:yellow_concrete
fill 259 92 599 259 97 599 minecraft:black_concrete
fill 260 92 557 261 97 557 minecraft:black_concrete
fill 262 92 557 262 93 557 minecraft:yellow_concrete
fill 265 92 599 266 93 599 minecraft:yellow_concrete
fill 267 92 599 268 97 599 minecraft:black_concrete
fill 268 92 557 269 97 557 minecraft:black_concrete
fill 270 92 557 271 92 557 minecraft:yellow_concrete
fill 276 92 599 276 93 599 minecraft:black_concrete
fill 277 92 560 277 97 561 minecraft:black_concrete
fill 277 92 562 277 93 563 minecraft:yellow_concrete
fill 277 92 569 277 97 569 minecraft:black_concrete
fill 277 92 570 277 92 571 minecraft:yellow_concrete
fill 277 92 572 277 97 572 minecraft:black_concrete
fill 277 92 574 277 93 574 minecraft:yellow_concrete
setblock 277 92 575 minecraft:black_concrete
fill 277 92 580 277 97 581 minecraft:black_concrete
fill 277 92 582 277 93 583 minecraft:yellow_concrete
fill 277 92 589 277 94 589 minecraft:black_concrete
setblock 277 92 591 minecraft:yellow_concrete
fill 277 92 592 277 97 593 minecraft:black_concrete
fill 277 92 594 277 93 595 minecraft:yellow_concrete
fill 277 92 599 277 93 599 minecraft:yellow_concrete
setblock 235 93 557 minecraft:yellow_concrete
fill 235 93 558 235 96 558 minecraft:black_concrete
setblock 235 93 565 minecraft:yellow_concrete
fill 235 93 569 235 96 569 minecraft:black_concrete
fill 235 93 585 235 93 586 minecraft:yellow_concrete
setblock 235 93 589 minecraft:yellow_concrete
fill 235 93 590 235 96 590 minecraft:black_concrete
fill 236 93 579 236 96 579 minecraft:magma_block
fill 237 93 599 237 96 599 minecraft:black_concrete
fill 238 93 557 238 96 557 minecraft:black_concrete
setblock 239 93 557 minecraft:yellow_concrete
fill 242 93 557 243 93 557 minecraft:yellow_concrete
setblock 242 93 599 minecraft:yellow_concrete
setblock 253 93 599 minecraft:yellow_concrete
fill 257 93 599 258 96 599 minecraft:black_concrete
fill 259 93 557 259 96 557 minecraft:black_concrete
setblock 263 93 557 minecraft:yellow_concrete
fill 270 93 557 270 96 557 minecraft:black_concrete
setblock 271 93 557 minecraft:yellow_concrete
fill 273 93 599 274 93 599 minecraft:yellow_concrete
setblock 274 93 557 minecraft:yellow_concrete
fill 277 93 570 277 96 571 minecraft:black_concrete
setblock 277 93 575 minecraft:yellow_concrete
setblock 277 93 586 minecraft:yellow_concrete
fill 277 93 587 277 95 587 minecraft:black_concrete
fill 277 93 591 277 96 591 minecraft:black_concrete
fill 235 94 557 235 99 557 minecraft:black_concrete
fill 235 94 563 235 95 564 minecraft:yellow_concrete
fill 235 94 565 235 99 566 minecraft:black_concrete
fill 235 94 575 235 94 576 minecraft:yellow_concrete
fill 235 94 577 235 99 578 minecraft:black_concrete
fill 235 94 584 235 95 584 minecraft:yellow_concrete
fill 235 94 585 235 99 586 minecraft:black_concrete
setblock 235 94 587 minecraft:yellow_concrete
fill 235 94 589 235 99 589 minecraft:black_concrete
fill 235 94 595 235 95 596 minecraft:yellow_concrete
fill 235 94 597 235 99 598 minecraft:black_concrete
fill 236 94 578 237 95 578 minecraft:magma_block
fill 236 94 580 237 95 580 minecraft:magma_block
fill 237 94 579 240 95 579 minecraft:magma_block
fill 239 94 557 239 99 557 minecraft:black_concrete
setblock 241 94 557 minecraft:yellow_concrete
fill 242 94 557 243 99 557 minecraft:black_concrete
fill 242 94 599 242 99 599 minecraft:black_concrete
fill 243 94 599 244 94 599 minecraft:yellow_concrete
fill 244 94 557 244 95 557 minecraft:yellow_concrete
fill 245 94 599 246 99 599 minecraft:black_concrete
fill 249 94 561 250 95 562 minecraft:shroomlight
fill 250 94 557 251 99 557 minecraft:black_concrete
fill 250 94 560 250 95 560 minecraft:shroomlight
fill 251 94 599 252 95 599 minecraft:yellow_concrete
fill 252 94 557 253 94 557 minecraft:yellow_concrete
fill 253 94 599 254 99 599 minecraft:black_concrete
setblock 255 94 599 minecraft:yellow_concrete
fill 262 94 557 263 99 557 minecraft:black_concrete
fill 263 94 599 264 95 599 minecraft:yellow_concrete
fill 264 94 557 265 95 557 minecraft:yellow_concrete
fill 265 94 599 266 99 599 minecraft:black_concrete
fill 271 94 557 271 99 557 minecraft:black_concrete
fill 272 94 557 273 94 557 minecraft:yellow_concrete
fill 272 94 599 272 95 599 minecraft:yellow_concrete
fill 273 94 599 274 95 599 minecraft:black_concrete
fill 274 94 557 274 99 557 minecraft:black_concrete
fill 275 94 599 276 94 599 minecraft:yellow_concrete
fill 276 94 557 276 95 557 minecraft:yellow_concrete
fill 277 94 562 277 99 563 minecraft:black_concrete
fill 277 94 564 277 95 565 minecraft:yellow_concrete
setblock 277 94 573 minecraft:yellow_concrete
fill 277 94 574 277 99 575 minecraft:black_concrete
fill 277 94 576 277 95 577 minecraft:yellow_concrete
fill 277 94 582 277 99 583 minecraft:black_concrete
fill 277 94 584 277 94 585 minecraft:yellow_concrete
fill 277 94 586 277 95 586 minecraft:black_concrete
fill 277 94 594 277 99 595 minecraft:black_concrete
fill 277 94 596 277 95 597 minecraft:yellow_concrete
fill 277 94 599 277 99 599 minecraft:black_concrete
setblock 235 95 572 minecraft:yellow_concrete
setblock 235 95 575 minecraft:yellow_concrete
fill 235 95 576 235 98 576 minecraft:black_concrete
setblock 235 95 583 minecraft:yellow_concrete
fill 235 95 587 235 98 587 minecraft:black_concrete
fill 238 95 578 239 95 578 minecraft:magma_block
fill 238 95 580 239 95 580 minecraft:magma_block
fill 239 95 599 240 95 599 minecraft:yellow_concrete
fill 241 95 557 241 98 557 minecraft:black_concrete
fill 241 95 579 243 95 579 minecraft:magma_block
setblock 243 95 599 minecraft:yellow_concrete
fill 244 95 599 244 98 599 minecraft:black_concrete
setblock 245 95 557 minecraft:yellow_concrete
fill 252 95 557 252 98 557 minecraft:black_concrete
setblock 253 95 557 minecraft:yellow_concrete
fill 255 95 599 255 98 599 minecraft:black_concrete
setblock 256 95 557 minecraft:yellow_concrete
setblock 260 95 599 minecraft:yellow_concrete
setblock 271 95 599 minecraft:yellow_concrete
fill 272 95 557 273 98 557 minecraft:black_concrete
fill 275 95 599 276 97 599 minecraft:black_concrete
setblock 277 95 557 minecraft:yellow_concrete
setblock 277 95 568 minecraft:yellow_concrete
fill 277 95 573 277 98 573 minecraft:black_concrete
fill 277 95 584 277 98 584 minecraft:black_concrete
setblock 277 95 585 minecraft:yellow_concrete
fill 277 95 588 277 95 589 minecraft:yellow_concrete
fill 235 96 561 235 97 562 minecraft:yellow_concrete
fill 235 96 563 235 101 564 minecraft:black_concrete
fill 235 96 570 235 97 570 minecraft:yellow_concrete
fill 235 96 572 235 101 572 minecraft:black_concrete
fill 235 96 573 235 96 574 minecraft:yellow_concrete
fill 235 96 575 235 101 575 minecraft:black_concrete
fill 235 96 581 235 97 582 minecraft:yellow_concrete
fill 235 96 583 235 101 584 minecraft:black_concrete
fill 235 96 593 235 96 594 minecraft:yellow_concrete
fill 235 96 595 235 101 596 minecraft:black_concrete
fill 236 96 558 238 96 558 minecraft:orange_concrete
fill 236 96 560 236 96 562 minecraft:orange_concrete
fill 236 96 564 236 96 566 minecraft:orange_concrete
fill 236 96 568 236 96 570 minecraft:orange_concrete
fill 236 96 572 236 96 574 minecraft:orange_concrete
fill 236 96 576 236 96 578 minecraft:orange_concrete
fill 236 96 580 236 96 582 minecraft:orange_concrete
fill 236 96 584 236 96 586 minecraft:orange_concrete
fill 236 96 588 236 96 590 minecraft:orange_concrete
fill 236 96 592 236 96 594 minecraft:orange_concrete
fill 236 96 596 236 96 598 minecraft:orange_concrete
fill 238 96 598 240 96 598 minecraft:orange_concrete
fill 238 96 599 238 97 599 minecraft:yellow_concrete
fill 239 96 599 240 101 599 minecraft:black_concrete
fill 240 96 558 242 96 558 minecraft:orange_concrete
setblock 241 96 599 minecraft:yellow_concrete
fill 242 96 598 244 96 598 minecraft:orange_concrete
fill 243 96 599 243 101 599 minecraft:black_concrete
fill 244 96 557 245 101 557 minecraft:black_concrete
fill 244 96 558 246 96 558 minecraft:orange_concrete
fill 246 96 557 247 97 557 minecraft:yellow_concrete
fill 246 96 598 248 96 598 minecraft:orange_concrete
fill 248 96 558 250 96 558 minecraft:orange_concrete
fill 249 96 599 250 97 599 minecraft:yellow_concrete
fill 250 96 598 252 96 598 minecraft:orange_concrete
fill 251 96 599 252 101 599 minecraft:black_concrete
fill 252 96 558 254 96 558 minecraft:orange_concrete
fill 253 96 557 253 101 557 minecraft:black_concrete
fill 254 96 557 255 96 557 minecraft:yellow_concrete
fill 254 96 598 256 96 598 minecraft:orange_concrete
fill 256 96 557 256 101 557 minecraft:black_concrete
fill 256 96 558 258 96 558 minecraft:orange_concrete
fill 258 96 557 258 97 557 minecraft:yellow_concrete
fill 258 96 598 260 96 598 minecraft:orange_concrete
fill 260 96 558 262 96 558 minecraft:orange_concrete
fill 260 96 599 260 101 599 minecraft:black_concrete
fill 261 96 599 262 96 599 minecraft:yellow_concrete
fill 262 96 598 264 96 598 minecraft:orange_concrete
fill 263 96 599 264 98 599 minecraft:black_concrete
fill 264 96 557 265 101 557 minecraft:black_concrete
fill 264 96 558 266 96 558 minecraft:orange_concrete
fill 266 96 557 267 97 557 minecraft:yellow_concrete
fill 266 96 598 268 96 598 minecraft:orange_concrete
fill 268 96 558 270 96 558 minecraft:orange_concrete
fill 269 96 599 270 97 599 minecraft:yellow_concrete
fill 270 96 598 272 96 598 minecraft:orange_concrete
fill 271 96 599 272 101 599 minecraft:black_concrete
fill 272 96 558 274 96 558 minecraft:orange_concrete
setblock 273 96 599 minecraft:yellow_concrete
fill 274 96 598 276 96 598 minecraft:orange_concrete
fill 274 96 599 274 99 599 minecraft:black_concrete
setblock 275 96 557 minecraft:yellow_concrete
fill 276 96 557 277 101 557 minecraft:black_concrete
fill 276 96 558 276 96 560 minecraft:orange_concrete
fill 276 96 562 276 96 564 minecraft:orange_concrete
fill 276 96 566 276 96 568 minecraft:orange_concrete
fill 276 96 570 276 96 572 minecraft:orange_concrete
fill 276 96 574 276 96 576 minecraft:orange_concrete
fill 276 96 578 276 96 580 minecraft:orange_concrete
fill 276 96 582 276 96 584 minecraft:orange_concrete
fill 276 96 586 276 96 588 minecraft:orange_concrete
fill 276 96 590 276 96 592 minecraft:orange_concrete
fill 276 96 594 276 96 596 minecraft:orange_concrete
fill 277 96 558 277 97 559 minecraft:yellow_concrete
fill 277 96 564 277 101 565 minecraft:black_concrete
fill 277 96 566 277 96 567 minecraft:yellow_concrete
fill 277 96 568 277 101 568 minecraft:black_concrete
fill 277 96 576 277 101 577 minecraft:black_concrete
fill 277 96 578 277 97 579 minecraft:yellow_concrete
fill 277 96 585 277 101 585 minecraft:black_concrete
fill 277 96 586 277 96 587 minecraft:yellow_concrete
fill 277 96 588 277 97 589 minecraft:black_concrete
fill 277 96 590 277 97 590 minecraft:yellow_concrete
fill 277 96 596 277 101 597 minecraft:black_concrete
fill 277 96 598 277 97 598 minecraft:yellow_concrete
setblock 235 97 558 minecraft:yellow_concrete
setblock 235 97 569 minecraft:yellow_concrete
fill 235 97 573 235 100 574 minecraft:black_concrete
setblock 235 97 590 minecraft:yellow_concrete
setblock 235 97 593 minecraft:yellow_concrete
fill 235 97 594 235 100 594 minecraft:black_concrete
setblock 237 97 599 minecraft:yellow_concrete
setblock 238 97 557 minecraft:yellow_concrete
fill 241 97 599 241 100 599 minecraft:black_concrete
fill 247 97 592 248 98 593 minecraft:yellow_concrete
fill 248 97 594 248 98 594 minecraft:yellow_concrete
fill 252 97 566 253 98 566 minecraft:shroomlight
fill 254 97 557 255 100 557 minecraft:black_concrete
fill 257 97 599 258 97 599 minecraft:yellow_concrete
setblock 259 97 557 minecraft:yellow_concrete
setblock 261 97 599 minecraft:yellow_concrete
fill 262 97 599 262 100 599 minecraft:black_concrete
setblock 270 97 557 minecraft:yellow_concrete
fill 273 97 599 273 99 599 minecraft:black_concrete
fill 275 97 557 275 100 557 minecraft:black_concrete
fill 277 97 566 277 100 566 minecraft:black_concrete
setblock 277 97 567 minecraft:yellow_concrete
fill 277 97 570 277 97 571 minecraft:yellow_concrete
fill 277 97 586 277 99 587 minecraft:black_concrete
setblock 277 97 591 minecraft:yellow_concrete
fill 235 98 558 235 103 558 minecraft:black_concrete
fill 235 98 559 235 98 560 minecraft:yellow_concrete
fill 235 98 561 235 103 562 minecraft:black_concrete
fill 235 98 567 235 99 568 minecraft:yellow_concrete
fill 235 98 569 235 103 570 minecraft:black_concrete
setblock 235 98 571 minecraft:yellow_concrete
fill 235 98 579 235 99 580 minecraft:yellow_concrete
fill 235 98 581 235 103 582 minecraft:black_concrete
fill 235 98 588 235 99 588 minecraft:yellow_concrete
fill 235 98 590 235 103 590 minecraft:black_concrete
fill 235 98 591 235 98 592 minecraft:yellow_concrete
fill 235 98 593 235 103 593 minecraft:black_concrete
fill 235 98 599 236 99 599 minecraft:yellow_concrete
fill 236 98 557 237 98 557 minecraft:yellow_concrete
fill 237 98 599 238 103 599 minecraft:black_concrete
fill 238 98 557 238 103 557 minecraft:black_concrete
setblock 238 98 560 minecraft:light[level=14]
setblock 238 98 568 minecraft:light[level=14]
setblock 238 98 576 minecraft:light[level=14]
setblock 238 98 584 minecraft:light[level=14]
setblock 238 98 592 minecraft:light[level=14]
fill 240 98 557 240 99 557 minecraft:yellow_concrete
fill 246 98 557 247 103 557 minecraft:black_concrete
setblock 246 98 560 minecraft:light[level=14]
setblock 246 98 568 minecraft:light[level=14]
setblock 246 98 576 minecraft:light[level=14]
setblock 246 98 584 minecraft:light[level=14]
setblock 246 98 592 minecraft:light[level=14]
fill 247 98 599 248 98 599 minecraft:yellow_concrete
fill 248 98 557 249 99 557 minecraft:yellow_concrete
fill 249 98 599 250 103 599 minecraft:black_concrete
setblock 254 98 560 minecraft:light[level=14]
setblock 254 98 568 minecraft:light[level=14]
setblock 254 98 576 minecraft:light[level=14]
setblock 254 98 584 minecraft:light[level=14]
setblock 254 98 592 minecraft:light[level=14]
fill 256 98 599 256 99 599 minecraft:yellow_concrete
setblock 257 98 557 minecraft:yellow_concrete
fill 257 98 599 258 103 599 minecraft:black_concrete
fill 258 98 557 259 103 557 minecraft:black_concrete
setblock 259 98 599 minecraft:yellow_concrete
fill 260 98 557 261 99 557 minecraft:yellow_concrete
fill 261 98 599 261 100 599 minecraft:black_concrete
setblock 262 98 560 minecraft:light[level=14]
setblock 262 98 568 minecraft:light[level=14]
setblock 262 98 576 minecraft:light[level=14]
setblock 262 98 584 minecraft:light[level=14]
setblock 262 98 592 minecraft:light[level=14]
fill 266 98 557 267 103 557 minecraft:black_concrete
fill 267 98 599 268 99 599 minecraft:yellow_concrete
fill 268 98 557 269 98 557 minecraft:yellow_concrete
fill 269 98 599 270 103 599 minecraft:black_concrete
fill 270 98 557 270 103 557 minecraft:black_concrete
setblock 270 98 560 minecraft:light[level=14]
setblock 270 98 568 minecraft:light[level=14]
setblock 270 98 576 minecraft:light[level=14]
setblock 270 98 584 minecraft:light[level=14]
setblock 270 98 592 minecraft:light[level=14]
setblock 275 98 599 minecraft:black_concrete
fill 276 98 599 276 99 599 minecraft:yellow_concrete
fill 277 98 558 277 103 559 minecraft:black_concrete
fill 277 98 560 277 99 561 minecraft:yellow_concrete
fill 277 98 567 277 103 567 minecraft:black_concrete
setblock 277 98 569 minecraft:yellow_concrete
fill 277 98 570 277 103 571 minecraft:black_concrete
fill 277 98 572 277 99 572 minecraft:yellow_concrete
fill 277 98 578 277 103 579 minecraft:black_concrete
fill 277 98 580 277 98 581 minecraft:yellow_concrete
fill 277 98 588 277 101 588 minecraft:black_concrete
setblock 277 98 589 minecraft:yellow_concrete
fill 277 98 590 277 103 591 minecraft:black_concrete
fill 277 98 592 277 99 593 minecraft:yellow_concrete
fill 277 98 598 277 100 598 minecraft:black_concrete
setblock 235 99 559 minecraft:yellow_concrete
fill 235 99 560 235 102 560 minecraft:black_concrete
fill 235 99 571 235 102 571 minecraft:black_concrete
setblock 235 99 576 minecraft:yellow_concrete
setblock 235 99 587 minecraft:yellow_concrete
fill 235 99 591 235 102 592 minecraft:black_concrete
fill 236 99 557 237 102 557 minecraft:black_concrete
setblock 241 99 557 minecraft:yellow_concrete
setblock 244 99 599 minecraft:yellow_concrete
setblock 247 99 599 minecraft:yellow_concrete
fill 248 99 599 248 102 599 minecraft:black_concrete
setblock 252 99 557 minecraft:yellow_concrete
setblock 255 99 599 minecraft:yellow_concrete
fill 257 99 557 257 102 557 minecraft:black_concrete
fill 259 99 599 259 102 599 minecraft:black_concrete
fill 263 99 599 263 101 599 minecraft:black_concrete
setblock 264 99 599 minecraft:yellow_concrete
fill 268 99 557 268 102 557 minecraft:black_concrete
setblock 269 99 557 minecraft:yellow_concrete
fill 272 99 557 273 99 557 minecraft:yellow_concrete
setblock 275 99 599 minecraft:yellow_concrete
fill 277 99 569 277 102 569 minecraft:black_concrete
setblock 277 99 573 minecraft:yellow_concrete
fill 277 99 580 277 102 580 minecraft:black_concrete
setblock 277 99 581 minecraft:yellow_concrete
setblock 277 99 584 minecraft:yellow_concrete
fill 277 99 589 277 101 589 minecraft:black_concrete
setblock 235 100 557 minecraft:yellow_concrete
fill 235 100 559 235 105 559 minecraft:black_concrete
fill 235 100 565 235 101 566 minecraft:yellow_concrete
fill 235 100 567 235 105 568 minecraft:black_concrete
fill 235 100 576 235 105 576 minecraft:black_concrete
fill 235 100 577 235 100 578 minecraft:yellow_concrete
fill 235 100 579 235 105 580 minecraft:black_concrete
fill 235 100 585 235 101 586 minecraft:yellow_concrete
fill 235 100 587 235 105 588 minecraft:black_concrete
setblock 235 100 589 minecraft:yellow_concrete
fill 235 100 597 235 101 598 minecraft:yellow_concrete
fill 235 100 599 236 105 599 minecraft:black_concrete
setblock 239 100 557 minecraft:yellow_concrete
fill 240 100 557 241 105 557 minecraft:black_concrete
fill 242 100 557 243 101 557 minecraft:yellow_concrete
fill 242 100 599 242 101 599 minecraft:yellow_concrete
fill 244 100 599 244 105 599 minecraft:black_concrete
fill 245 100 599 246 100 599 minecraft:yellow_concrete
fill 247 100 599 247 105 599 minecraft:black_concrete
fill 248 100 557 249 105 557 minecraft:black_concrete
fill 250 100 557 251 100 557 minecraft:yellow_concrete
fill 252 100 557 252 105 557 minecraft:black_concrete
fill 253 100 599 254 101 599 minecraft:yellow_concrete
fill 255 100 599 256 105 599 minecraft:black_concrete
fill 260 100 557 261 105 557 minecraft:black_concrete
fill 262 100 557 263 101 557 minecraft:yellow_concrete
fill 264 100 599 264 101 599 minecraft:black_concrete
fill 265 100 599 266 100 599 minecraft:yellow_concrete
fill 267 100 599 268 105 599 minecraft:black_concrete
fill 269 100 557 269 105 557 minecraft:black_concrete
setblock 271 100 557 minecraft:yellow_concrete
fill 272 100 557 273 105 557 minecraft:black_concrete
fill 273 100 599 274 101 599 minecraft:yellow_concrete
fill 274 100 557 274 101 557 minecraft:yellow_concrete
fill 275 100 599 276 105 599 minecraft:black_concrete
fill 277 100 560 277 105 561 minecraft:black_concrete
fill 277 100 562 277 100 563 minecraft:yellow_concrete
fill 277 100 572 277 105 573 minecraft:black_concrete
fill 277 100 574 277 101 575 minecraft:yellow_concrete
fill 277 100 581 277 105 581 minecraft:black_concrete
fill 277 100 582 277 100 583 minecraft:yellow_concrete
fill 277 100 584 277 105 584 minecraft:black_concrete
fill 277 100 586 277 101 586 minecraft:yellow_concrete
setblock 277 100 587 minecraft:black_concrete
fill 277 100 592 277 105 593 minecraft:black_concrete
fill 277 100 594 277 101 595 minecraft:yellow_concrete
setblock 277 100 599 minecraft:yellow_concrete
fill 235 101 557 235 104 557 minecraft:black_concrete
fill 235 101 573 235 101 574 minecraft:yellow_concrete
setblock 235 101 577 minecraft:yellow_concrete
fill 235 101 578 235 104 578 minecraft:black_concrete
fill 235 101 589 235 104 589 minecraft:black_concrete
setblock 235 101 594 minecraft:yellow_concrete
fill 239 101 557 239 104 557 minecraft:black_concrete
setblock 241 101 599 minecraft:yellow_concrete
fill 245 101 599 246 104 599 minecraft:black_concrete
fill 250 101 557 250 104 557 minecraft:black_concrete
setblock 251 101 557 minecraft:yellow_concrete
fill 254 101 557 255 101 557 minecraft:yellow_concrete
fill 261 101 599 262 101 599 minecraft:yellow_concrete
setblock 265 101 599 minecraft:yellow_concrete
fill 266 101 599 266 104 599 minecraft:black_concrete
fill 271 101 557 271 104 557 minecraft:black_concrete
setblock 275 101 557 minecraft:yellow_concrete
fill 277 101 562 277 104 562 minecraft:black_concrete
setblock 277 101 563 minecraft:yellow_concrete
setblock 277 101 566 minecraft:yellow_concrete
fill 277 101 582 277 104 583 minecraft:black_concrete
setblock 277 101 587 minecraft:yellow_concrete
setblock 277 101 598 minecraft:yellow_concrete
fill 277 101 599 277 104 599 minecraft:black_concrete
fill 235 102 563 235 102 564 minecraft:yellow_concrete
fill 235 102 565 235 107 566 minecraft:black_concrete
fill 235 102 572 235 103 572 minecraft:yellow_concrete
fill 235 102 573 235 107 574 minecraft:black_concrete
setblock 235 102 575 minecraft:yellow_concrete
fill 235 102 577 235 107 577 minecraft:black_concrete
fill 235 102 583 235 103 584 minecraft:yellow_concrete
fill 235 102 585 235 107 586 minecraft:black_concrete
fill 235 102 594 235 107 594 minecraft:black_concrete
fill 235 102 595 235 102 596 minecraft:yellow_concrete
fill 235 102 597 235 107 598 minecraft:black_concrete
fill 236 102 558 238 102 558 minecraft:orange_concrete
fill 236 102 560 236 102 562 minecraft:orange_concrete
fill 236 102 564 236 102 566 minecraft:orange_concrete
fill 236 102 568 236 102 570 minecraft:orange_concrete
fill 236 102 572 236 102 574 minecraft:orange_concrete
fill 236 102 576 236 102 578 minecraft:orange_concrete
fill 236 102 580 236 102 582 minecraft:orange_concrete
fill 236 102 584 236 102 586 minecraft:orange_concrete
fill 236 102 588 236 102 590 minecraft:orange_concrete
fill 236 102 592 236 102 594 minecraft:orange_concrete
fill 236 102 596 236 102 598 minecraft:orange_concrete
fill 238 102 598 240 102 598 minecraft:orange_concrete
fill 239 102 599 240 103 599 minecraft:yellow_concrete
fill 240 102 558 242 102 558 minecraft:orange_concrete
fill 241 102 599 242 107 599 minecraft:black_concrete
fill 242 102 557 243 107 557 minecraft:black_concrete
fill 242 102 598 244 102 598 minecraft:orange_concrete
setblock 243 102 599 minecraft:yellow_concrete
fill 244 102 557 245 103 557 minecraft:yellow_concrete
fill 244 102 558 246 102 558 minecraft:orange_concrete
fill 246 102 598 248 102 598 minecraft:orange_concrete
fill 248 102 558 250 102 558 minecraft:orange_concrete
fill 250 102 598 252 102 598 minecraft:orange_concrete
fill 251 102 557 251 107 557 minecraft:black_concrete
fill 251 102 599 252 103 599 minecraft:yellow_concrete
fill 252 102 558 254 102 558 minecraft:orange_concrete
setblock 253 102 557 minecraft:yellow_concrete
fill 253 102 599 254 107 599 minecraft:black_concrete
fill 254 102 557 255 107 557 minecraft:black_concrete
fill 254 102 598 256 102 598 minecraft:orange_concrete
fill 256 102 557 256 103 557 minecraft:yellow_concrete
fill 256 102 558 258 102 558 minecraft:orange_concrete
fill 258 102 598 260 102 598 minecraft:orange_concrete
fill 260 102 558 262 102 558 minecraft:orange_concrete
fill 260 102 599 260 103 599 minecraft:yellow_concrete
fill 261 102 599 262 103 599 minecraft:black_concrete
fill 262 102 557 263 107 557 minecraft:black_concrete
fill 262 102 598 264 102 598 minecraft:orange_concrete
fill 263 102 599 264 102 599 minecraft:yellow_concrete
fill 264 102 557 265 102 557 minecraft:yellow_concrete
fill 264 102 558 266 102 558 minecraft:orange_concrete
fill 265 102 599 265 107 599 minecraft:black_concrete
fill 266 102 598 268 102 598 minecraft:orange_concrete
fill 268 102 558 270 102 558 minecraft:orange_concrete
fill 270 102 598 272 102 598 minecraft:orange_concrete
fill 271 102 599 272 103 599 minecraft:yellow_concrete
fill 272 102 558 274 102 558 minecraft:orange_concrete
fill 273 102 599 274 107 599 minecraft:black_concrete
fill 274 102 557 275 107 557 minecraft:black_concrete
fill 274 102 598 276 102 598 minecraft:orange_concrete
fill 276 102 557 277 103 557 minecraft:yellow_concrete
fill 276 102 558 276 102 560 minecraft:orange_concrete
fill 276 102 562 276 102 564 minecraft:orange_concrete
fill 276 102 566 276 102 568 minecraft:orange_concrete
fill 276 102 570 276 102 572 minecraft:orange_concrete
fill 276 102 574 276 102 576 minecraft:orange_concrete
fill 276 102 578 276 102 580 minecraft:orange_concrete
fill 276 102 582 276 102 584 minecraft:orange_concrete
fill 276 102 586 276 102 588 minecraft:orange_concrete
fill 276 102 590 276 102 592 minecraft:orange_concrete
fill 276 102 594 276 102 596 minecraft:orange_concrete
fill 277 102 563 277 107 563 minecraft:black_concrete
fill 277 102 564 277 102 565 minecraft:yellow_concrete
fill 277 102 566 277 107 566 minecraft:black_concrete
fill 277 102 568 277 103 568 minecraft:yellow_concrete
fill 277 102 574 277 107 575 minecraft:black_concrete
fill 277 102 576 277 103 577 minecraft:yellow_concrete
setblock 277 102 585 minecraft:yellow_concrete
fill 277 102 586 277 107 587 minecraft:black_concrete
fill 277 102 588 277 103 589 minecraft:yellow_concrete
fill 277 102 594 277 107 595 minecraft:black_concrete
fill 277 102 596 277 102 597 minecraft:yellow_concrete
fill 277 102 598 277 103 598 minecraft:black_concrete
setblock 235 103 560 minecraft:yellow_concrete
setblock 235 103 563 minecraft:yellow_concrete
fill 235 103 564 235 106 564 minecraft:black_concrete
setblock 235 103 571 minecraft:yellow_concrete
fill 235 103 575 235 106 575 minecraft:black_concrete
fill 235 103 591 235 103 592 minecraft:yellow_concrete
setblock 235 103 595 minecraft:yellow_concrete
fill 235 103 596 235 106 596 minecraft:black_concrete
fill 236 103 557 237 103 557 minecraft:yellow_concrete
fill 243 103 599 243 106 599 minecraft:black_concrete
setblock 248 103 599 minecraft:yellow_concrete
fill 253 103 557 253 106 557 minecraft:black_concrete
setblock 257 103 557 minecraft:yellow_concrete
setblock 259 103 599 minecraft:yellow_concrete
fill 263 103 587 263 104 587 minecraft:shroomlight
fill 263 103 599 264 105 599 minecraft:black_concrete
fill 264 103 557 264 106 557 minecraft:black_concrete
setblock 265 103 557 minecraft:yellow_concrete
setblock 268 103 557 minecraft:yellow_concrete
fill 277 103 564 277 106 565 minecraft:black_concrete
setblock 277 103 569 minecraft:yellow_concrete
setblock 277 103 580 minecraft:yellow_concrete
fill 277 103 585 277 106 585 minecraft:black_concrete
fill 277 103 596 277 106 596 minecraft:black_concrete
setblock 277 103 597 minecraft:yellow_concrete
fill 235 104 558 235 105 558 minecraft:yellow_concrete
fill 235 104 560 235 109 560 minecraft:black_concrete
fill 235 104 561 235 104 562 minecraft:yellow_concrete
fill 235 104 563 235 109 563 minecraft:black_concrete
fill 235 104 569 235 105 570 minecraft:yellow_concrete
fill 235 104 571 235 109 572 minecraft:black_concrete
fill 235 104 581 235 104 582 minecraft:yellow_concrete
fill 235 104 583 235 109 584 minecraft:black_concrete
fill 235 104 590 235 105 590 minecraft:yellow_concrete
fill 235 104 591 235 109 592 minecraft:black_concrete
setblock 235 104 593 minecraft:yellow_concrete
fill 235 104 595 235 109 595 minecraft:black_concrete
fill 236 104 557 237 109 557 minecraft:black_concrete
fill 237 104 599 238 105 599 minecraft:yellow_concrete
fill 238 104 557 238 105 557 minecraft:yellow_concrete
fill 239 104 599 240 109 599 minecraft:black_concrete
fill 244 104 557 245 109 557 minecraft:black_concrete
fill 246 104 557 247 104 557 minecraft:yellow_concrete
fill 248 104 599 248 109 599 minecraft:black_concrete
fill 249 104 599 250 104 599 minecraft:yellow_concrete
fill 251 104 599 252 106 599 minecraft:black_concrete
fill 256 104 557 257 109 557 minecraft:black_concrete
fill 257 104 599 258 105 599 minecraft:yellow_concrete
fill 258 104 557 259 105 557 minecraft:yellow_concrete
fill 259 104 599 260 109 599 minecraft:black_concrete
setblock 261 104 599 minecraft:yellow_concrete
fill 262 104 599 262 107 599 minecraft:black_concrete
fill 265 104 557 265 109 557 minecraft:black_concrete
fill 266 104 557 267 104 557 minecraft:yellow_concrete
fill 268 104 557 268 109 557 minecraft:black_concrete
fill 269 104 599 270 105 599 minecraft:yellow_concrete
fill 270 104 557 270 105 557 minecraft:yellow_concrete
fill 271 104 599 272 109 599 minecraft:black_concrete
fill 276 104 557 277 109 557 minecraft:black_concrete
fill 277 104 558 277 105 559 minecraft:yellow_concrete
setblock 277 104 567 minecraft:yellow_concrete
fill 277 104 568 277 109 569 minecraft:black_concrete
fill 277 104 570 277 105 571 minecraft:yellow_concrete
fill 277 104 576 277 109 577 minecraft:black_concrete
fill 277 104 578 277 104 579 minecraft:yellow_concrete
fill 277 104 580 277 109 580 minecraft:black_concrete
fill 277 104 588 277 109 589 minecraft:black_concrete
fill 277 104 590 277 105 591 minecraft:yellow_concrete
fill 277 104 597 277 109 597 minecraft:black_concrete
setblock 277 104 598 minecraft:yellow_concrete
setblock 235 105 557 minecraft:yellow_concrete
fill 235 105 561 235 108 562 minecraft:black_concrete
setblock 235 105 578 minecraft:yellow_concrete
setblock 235 105 581 minecraft:yellow_concrete
fill 235 105 582 235 108 582 minecraft:black_concrete
setblock 235 105 589 minecraft:yellow_concrete
fill 235 105 593 235 108 593 minecraft:black_concrete
setblock 239 105 557 minecraft:yellow_concrete
fill 245 105 599 246 105 599 minecraft:yellow_concrete
fill 246 105 557 246 108 557 minecraft:black_concrete
setblock 247 105 557 minecraft:yellow_concrete
setblock 249 105 599 minecraft:yellow_concrete
setblock 250 105 557 minecraft:yellow_concrete
fill 250 105 599 250 108 599 minecraft:black_concrete
fill 261 105 599 261 107 599 minecraft:black_concrete
fill 266 105 557 267 108 557 minecraft:black_concrete
setblock 266 105 599 minecraft:yellow_concrete
setblock 271 105 557 minecraft:yellow_concrete
setblock 277 105 562 minecraft:yellow_concrete
fill 277 105 567 277 108 567 minecraft:black_concrete
fill 277 105 578 277 108 578 minecraft:black_concrete
setblock 277 105 579 minecraft:yellow_concrete
fill 277 105 582 277 105 583 minecraft:yellow_concrete
fill 277 105 598 277 107 598 minecraft:black_concrete
setblock 277 105 599 minecraft:yellow_concrete
fill 235 106 557 235 111 558 minecraft:black_concrete
setblock 235 106 559 minecraft:yellow_concrete
fill 235 106 567 235 107 568 minecraft:yellow_concrete
fill 235 106 569 235 111 570 minecraft:black_concrete
fill 235 106 576 235 107 576 minecraft:yellow_concrete
fill 235 106 578 235 111 578 minecraft:black_concrete
fill 235 106 579 235 106 580 minecraft:yellow_concrete
fill 235 106 581 235 111 581 minecraft:black_concrete
fill 235 106 587 235 107 588 minecraft:yellow_concrete
fill 235 106 589 235 111 590 minecraft:black_concrete
fill 235 106 599 236 106 599 minecraft:yellow_concrete
fill 237 106 599 238 111 599 minecraft:black_concrete
fill 238 106 557 239 111 557 minecraft:black_concrete
setblock 238 106 560 minecraft:light[level=14]
setblock 238 106 568 minecraft:light[level=14]
setblock 238 106 576 minecraft:light[level=14]
setblock 238 106 584 minecraft:light[level=14]
setblock 238 106 592 minecraft:light[level=14]
fill 240 106 557 241 107 557 minecraft:yellow_concrete
fill 244 106 599 244 107 599 minecraft:yellow_concrete
fill 245 106 599 246 111 599 minecraft:black_concrete
setblock 246 106 560 minecraft:light[level=14]
setblock 246 106 568 minecraft:light[level=14]
setblock 246 106 576 minecraft:light[level=14]
setblock 246 106 584 minecraft:light[level=14]
setblock 246 106 592 minecraft:light[level=14]
fill 247 106 557 247 111 557 minecraft:black_concrete
setblock 247 106 599 minecraft:yellow_concrete
fill 248 106 557 249 106 557 minecraft:yellow_concrete
fill 249 106 599 249 108 599 minecraft:black_concrete
fill 250 106 557 250 111 557 minecraft:black_concrete
fill 252 106 557 252 107 557 minecraft:yellow_concrete
setblock 254 106 560 minecraft:light[level=14]
setblock 254 106 568 minecraft:light[level=14]
setblock 254 106 576 minecraft:light[level=14]
setblock 254 106 584 minecraft:light[level=14]
setblock 254 106 592 minecraft:light[level=14]
fill 255 106 599 256 107 599 minecraft:yellow_concrete
fill 257 106 599 258 111 599 minecraft:black_concrete
fill 258 106 557 259 111 557 minecraft:black_concrete
fill 260 106 557 261 107 557 minecraft:yellow_concrete
setblock 262 106 560 minecraft:light[level=14]
setblock 262 106 568 minecraft:light[level=14]
setblock 262 106 576 minecraft:light[level=14]
setblock 262 106 584 minecraft:light[level=14]
setblock 262 106 592 minecraft:light[level=14]
setblock 263 106 599 minecraft:black_concrete
fill 264 106 599 264 107 599 minecraft:yellow_concrete
fill 266 106 599 266 111 599 minecraft:black_concrete
fill 267 106 599 268 106 599 minecraft:yellow_concrete
setblock 269 106 557 minecraft:yellow_concrete
fill 269 106 599 270 108 599 minecraft:black_concrete
fill 270 106 557 271 111 557 minecraft:black_concrete
setblock 270 106 560 minecraft:light[level=14]
setblock 270 106 568 minecraft:light[level=14]
setblock 270 106 576 minecraft:light[level=14]
setblock 270 106 584 minecraft:light[level=14]
setblock 270 106 592 minecraft:light[level=14]
fill 272 106 557 273 107 557 minecraft:yellow_concrete
fill 275 106 599 276 107 599 minecraft:yellow_concrete
fill 277 106 558 277 111 559 minecraft:black_concrete
fill 277 106 560 277 106 561 minecraft:yellow_concrete
fill 277 106 562 277 111 562 minecraft:black_concrete
fill 277 106 570 277 111 571 minecraft:black_concrete
fill 277 106 572 277 107 573 minecraft:yellow_concrete
fill 277 106 579 277 111 579 minecraft:black_concrete
setblock 277 106 581 minecraft:yellow_concrete
fill 277 106 582 277 111 583 minecraft:black_concrete
fill 277 106 584 277 107 584 minecraft:yellow_concrete
fill 277 106 590 277 111 591 minecraft:black_concrete
fill 277 106 592 277 106 593 minecraft:yellow_concrete
fill 277 106 599 277 111 599 minecraft:black_concrete
fill 235 107 559 235 110 559 minecraft:black_concrete
setblock 235 107 564 minecraft:yellow_concrete
setblock 235 107 575 minecraft:yellow_concrete
fill 235 107 579 235 110 580 minecraft:black_concrete
setblock 235 107 596 minecraft:yellow_concrete
setblock 235 107 599 minecraft:yellow_concrete
fill 236 107 599 236 110 599 minecraft:black_concrete
setblock 243 107 599 minecraft:yellow_concrete
fill 247 107 599 247 110 599 minecraft:black_concrete
fill 248 107 557 249 110 557 minecraft:black_concrete
fill 251 107 599 251 109 599 minecraft:black_concrete
setblock 252 107 599 minecraft:yellow_concrete
setblock 253 107 557 minecraft:yellow_concrete
setblock 263 107 599 minecraft:yellow_concrete
setblock 264 107 557 minecraft:yellow_concrete
setblock 267 107 599 minecraft:yellow_concrete
fill 268 107 599 268 110 599 minecraft:black_concrete
fill 269 107 557 269 110 557 minecraft:black_concrete
fill 277 107 560 277 110 560 minecraft:black_concrete
setblock 277 107 561 minecraft:yellow_concrete
fill 277 107 564 277 107 565 minecraft:yellow_concrete
fill 277 107 581 277 110 581 minecraft:black_concrete
setblock 277 107 585 minecraft:yellow_concrete
fill 277 107 592 277 110 592 minecraft:black_concrete
setblock 277 107 593 minecraft:yellow_concrete
setblock 277 107 596 minecraft:yellow_concrete
fill 235 108 564 235 113 564 minecraft:black_concrete
fill 235 108 565 235 108 566 minecraft:yellow_concrete
fill 235 108 567 235 113 568 minecraft:black_concrete
fill 235 108 573 235 109 574 minecraft:yellow_concrete
fill 235 108 575 235 113 576 minecraft:black_concrete
setblock 235 108 577 minecraft:yellow_concrete
fill 235 108 585 235 109 586 minecraft:yellow_concrete
fill 235 108 587 235 113 588 minecraft:black_concrete
fill 235 108 594 235 109 594 minecraft:yellow_concrete
fill 235 108 596 235 113 596 minecraft:black_concrete
fill 235 108 597 235 108 598 minecraft:yellow_concrete
fill 235 108 599 235 113 599 minecraft:black_concrete
fill 236 108 558 238 108 558 minecraft:orange_concrete
fill 236 108 560 236 108 562 minecraft:orange_concrete
fill 236 108 564 236 108 566 minecraft:orange_concrete
fill 236 108 568 236 108 570 minecraft:orange_concrete
fill 236 108 572 236 108 574 minecraft:orange_concrete
fill 236 108 576 236 108 578 minecraft:orange_concrete
fill 236 108 580 236 108 582 minecraft:orange_concrete
fill 236 108 584 236 108 586 minecraft:orange_concrete
fill 236 108 588 236 108 590 minecraft:orange_concrete
fill 236 108 592 236 108 594 minecraft:orange_concrete
fill 236 108 596 236 108 598 minecraft:orange_concrete
fill 238 108 598 240 108 598 minecraft:orange_concrete
fill 240 108 557 241 113 557 minecraft:black_concrete
fill 240 108 558 242 108 558 minecraft:orange_concrete
fill 241 108 599 242 109 599 minecraft:yellow_concrete
fill 242 108 557 243 109 557 minecraft:yellow_concrete
fill 242 108 598 244 108 598 minecraft:orange_concrete
fill 243 108 599 244 113 599 minecraft:black_concrete
fill 244 108 558 246 108 558 minecraft:orange_concrete
fill 246 108 598 248 108 598 minecraft:orange_concrete
fill 248 108 558 250 108 558 minecraft:orange_concrete
fill 250 108 598 252 108 598 minecraft:orange_concrete
setblock 251 108 557 minecraft:yellow_concrete
fill 252 108 557 253 113 557 minecraft:black_concrete
fill 252 108 558 254 108 558 minecraft:orange_concrete
fill 252 108 599 252 109 599 minecraft:black_concrete
fill 253 108 599 254 108 599 minecraft:yellow_concrete
fill 254 108 557 255 109 557 minecraft:yellow_concrete
fill 254 108 598 256 108 598 minecraft:orange_concrete
fill 255 108 599 256 113 599 minecraft:black_concrete
fill 256 108 558 258 108 558 minecraft:orange_concrete
fill 258 108 598 260 108 598 minecraft:orange_concrete
fill 260 108 557 261 113 557 minecraft:black_concrete
fill 260 108 558 262 108 558 minecraft:orange_concrete
fill 261 108 599 262 109 599 minecraft:yellow_concrete
fill 262 108 557 263 108 557 minecraft:yellow_concrete
fill 262 108 598 264 108 598 minecraft:orange_concrete
fill 263 108 599 264 113 599 minecraft:black_concrete
fill 264 108 557 264 113 557 minecraft:black_concrete
fill 264 108 558 266 108 558 minecraft:orange_concrete
setblock 265 108 599 minecraft:yellow_concrete
fill 266 108 598 268 108 598 minecraft:orange_concrete
fill 267 108 599 267 110 599 minecraft:black_concrete
fill 268 108 558 270 108 558 minecraft:orange_concrete
fill 270 108 598 272 108 598 minecraft:orange_concrete
fill 272 108 557 273 113 557 minecraft:black_concrete
fill 272 108 558 274 108 558 minecraft:orange_concrete
fill 273 108 599 274 109 599 minecraft:yellow_concrete
fill 274 108 557 275 109 557 minecraft:yellow_concrete
fill 274 108 598 276 108 598 minecraft:orange_concrete
fill 275 108 599 276 113 599 minecraft:black_concrete
fill 276 108 558 276 108 560 minecraft:orange_concrete
fill 276 108 562 276 108 564 minecraft:orange_concrete
fill 276 108 566 276 108 568 minecraft:orange_concrete
fill 276 108 570 276 108 572 minecraft:orange_concrete
fill 276 108 574 276 108 576 minecraft:orange_concrete
fill 276 108 578 276 108 580 minecraft:orange_concrete
fill 276 108 582 276 108 584 minecraft:orange_concrete
fill 276 108 586 276 108 588 minecraft:orange_concrete
fill 276 108 590 276 108 592 minecraft:orange_concrete
fill 276 108 594 276 108 596 minecraft:orange_concrete
fill 277 108 561 277 113 561 minecraft:black_concrete
setblock 277 108 563 minecraft:yellow_concrete
fill 277 108 564 277 113 565 minecraft:black_concrete
fill 277 108 566 277 109 566 minecraft:yellow_concrete
fill 277 108 572 277 113 573 minecraft:black_concrete
fill 277 108 574 277 108 575 minecraft:yellow_concrete
fill 277 108 584 277 113 585 minecraft:black_concrete
fill 277 108 586 277 109 587 minecraft:yellow_concrete
fill 277 108 593 277 113 593 minecraft:black_concrete
fill 277 108 594 277 108 595 minecraft:yellow_concrete
fill 277 108 596 277 113 596 minecraft:black_concrete
fill 277 108 598 277 109 598 minecraft:yellow_concrete
fill 235 109 561 235 109 562 minecraft:yellow_concrete
setblock 235 109 565 minecraft:yellow_concrete
fill 235 109 566 235 112 566 minecraft:black_concrete
fill 235 109 577 235 112 577 minecraft:black_concrete
setblock 235 109 582 minecraft:yellow_concrete
setblock 235 109 593 minecraft:yellow_concrete
fill 235 109 597 235 112 598 minecraft:black_concrete
setblock 246 109 557 minecraft:yellow_concrete
fill 249 109 599 250 109 599 minecraft:yellow_concrete
fill 251 109 557 251 112 557 minecraft:black_concrete
setblock 253 109 599 minecraft:yellow_concrete
fill 254 109 599 254 112 599 minecraft:black_concrete
fill 262 109 557 262 112 557 minecraft:black_concrete
setblock 263 109 557 minecraft:yellow_concrete
fill 265 109 599 265 112 599 minecraft:black_concrete
fill 266 109 557 267 109 557 minecraft:yellow_concrete
fill 269 109 599 269 111 599 minecraft:black_concrete
setblock 270 109 599 minecraft:yellow_concrete
fill 277 109 563 277 112 563 minecraft:black_concrete
setblock 277 109 567 minecraft:yellow_concrete
fill 277 109 574 277 112 574 minecraft:black_concrete
setblock 277 109 575 minecraft:yellow_concrete
setblock 277 109 578 minecraft:yellow_concrete
fill 277 109 594 277 112 595 minecraft:black_concrete
fill 235 110 560 235 111 560 minecraft:yellow_concrete
fill 235 110 561 235 115 562 minecraft:black_concrete
setblock 235 110 563 minecraft:yellow_concrete
fill 235 110 565 235 115 565 minecraft:black_concrete
fill 235 110 571 235 111 572 minecraft:yellow_concrete
fill 235 110 573 235 115 574 minecraft:black_concrete
fill 235 110 582 235 115 582 minecraft:black_concrete
fill 235 110 583 235 110 584 minecraft:yellow_concrete
fill 235 110 585 235 115 586 minecraft:black_concrete
fill 235 110 591 235 111 592 minecraft:yellow_concrete
fill 235 110 593 235 115 594 minecraft:black_concrete
setblock 235 110 595 minecraft:yellow_concrete
fill 236 110 557 237 111 557 minecraft:yellow_concrete
fill 239 110 599 240 111 599 minecraft:yellow_concrete
fill 241 110 599 242 115 599 minecraft:black_concrete
fill 242 110 557 243 115 557 minecraft:black_concrete
fill 244 110 557 245 110 557 minecraft:yellow_concrete
fill 246 110 557 246 115 557 minecraft:black_concrete
fill 248 110 599 248 111 599 minecraft:yellow_concrete
fill 249 110 599 250 111 599 minecraft:black_concrete
fill 251 110 599 252 110 599 minecraft:yellow_concrete
fill 253 110 599 253 115 599 minecraft:black_concrete
fill 254 110 557 255 115 557 minecraft:black_concrete
fill 256 110 557 257 111 557 minecraft:yellow_concrete
fill 259 110 599 260 111 599 minecraft:yellow_concrete
fill 261 110 599 262 115 599 minecraft:black_concrete
fill 263 110 557 263 115 557 minecraft:black_concrete
setblock 265 110 557 minecraft:yellow_concrete
fill 266 110 557 267 115 557 minecraft:black_concrete
fill 268 110 557 268 111 557 minecraft:yellow_concrete
fill 270 110 599 270 111 599 minecraft:black_concrete
fill 271 110 599 272 110 599 minecraft:yellow_concrete
fill 273 110 599 274 115 599 minecraft:black_concrete
fill 274 110 557 275 115 557 minecraft:black_concrete
fill 276 110 557 277 110 557 minecraft:yellow_concrete
fill 277 110 566 277 115 567 minecraft:black_concrete
fill 277 110 568 277 111 569 minecraft:yellow_concrete
fill 277 110 575 277 115 575 minecraft:black_concrete
fill 277 110 576 277 110 577 minecraft:yellow_concrete
fill 277 110 578 277 115 578 minecraft:black_concrete
fill 277 110 580 277 111 580 minecraft:yellow_concrete
fill 277 110 586 277 115 587 minecraft:black_concrete
fill 277 110 588 277 111 589 minecraft:yellow_concrete
setblock 277 110 597 minecraft:yellow_concrete
fill 277 110 598 277 115 598 minecraft:black_concrete
setblock 235 111 559 minecraft:yellow_concrete
fill 235 111 563 235 114 563 minecraft:black_concrete
fill 235 111 579 235 111 580 minecraft:yellow_concrete
setblock 235 111 583 minecraft:yellow_concrete
fill 235 111 584 235 114 584 minecraft:black_concrete
fill 235 111 595 235 114 595 minecraft:black_concrete
fill 236 111 574 236 113 576 minecraft:magma_block
setblock 236 111 599 minecraft:yellow_concrete
fill 237 111 575 237 114 575 minecraft:magma_block
fill 244 111 557 244 114 557 minecraft:black_concrete
setblock 245 111 557 minecraft:yellow_concrete
setblock 247 111 599 minecraft:yellow_concrete
fill 248 111 557 249 111 557 minecraft:yellow_concrete
fill 251 111 591 252 112 592 minecraft:red_concrete
fill 251 111 599 252 113 599 minecraft:black_concrete
fill 265 111 557 265 114 557 minecraft:black_concrete
fill 267 111 599 268 111 599 minecraft:yellow_concrete
setblock 269 111 557 minecraft:yellow_concrete
setblock 271 111 599 minecraft:yellow_concrete
fill 272 111 599 272 114 599 minecraft:black_concrete
fill 276 111 557 276 114 557 minecraft:black_concrete
setblock 277 111 557 minecraft:yellow_concrete
setblock 277 111 560 minecraft:yellow_concrete
fill 277 111 576 277 114 577 minecraft:black_concrete
setblock 277 111 581 minecraft:yellow_concrete
setblock 277 111 592 minecraft:yellow_concrete
fill 277 111 597 277 114 597 minecraft:black_concrete
fill 235 112 557 235 113 558 minecraft:yellow_concrete
fill 235 112 559 235 117 560 minecraft:black_concrete
fill 235 112 569 235 112 570 minecraft:yellow_concrete
fill 235 112 571 235 117 572 minecraft:black_concrete
fill 235 112 578 235 113 578 minecraft:yellow_concrete
fill 235 112 579 235 117 580 minecraft:black_concrete
setblock 235 112 581 minecraft:yellow_concrete
fill 235 112 583 235 117 583 minecraft:black_concrete
fill 235 112 589 235 113 590 minecraft:yellow_concrete
fill 235 112 591 235 117 592 minecraft:black_concrete
fill 236 112 557 237 117 557 minecraft:black_concrete
fill 236 112 599 236 117 599 minecraft:black_concrete
fill 237 112 574 238 114 574 minecraft:magma_block
fill 237 112 576 238 114 576 minecraft:magma_block
fill 237 112 599 238 112 599 minecraft:yellow_concrete
fill 238 112 557 239 113 557 minecraft:yellow_concrete
fill 238 112 575 238 114 575 minecraft:magma_block
fill 239 112 599 240 114 599 minecraft:black_concrete
fill 245 112 557 245 117 557 minecraft:black_concrete
fill 245 112 599 246 113 599 minecraft:yellow_concrete
setblock 247 112 557 minecraft:yellow_concrete
fill 247 112 599 248 117 599 minecraft:black_concrete
fill 248 112 557 249 117 557 minecraft:black_concrete
setblock 249 112 599 minecraft:yellow_concrete
fill 250 112 557 250 113 557 minecraft:yellow_concrete
fill 250 112 599 250 115 599 minecraft:black_concrete
fill 256 112 557 257 117 557 minecraft:black_concrete
fill 257 112 599 258 113 599 minecraft:yellow_concrete
fill 258 112 557 259 112 557 minecraft:yellow_concrete
fill 259 112 599 260 117 599 minecraft:black_concrete
fill 266 112 599 266 113 599 minecraft:yellow_concrete
fill 267 112 599 268 113 599 minecraft:black_concrete
fill 268 112 557 269 117 557 minecraft:black_concrete
fill 269 112 599 270 112 599 minecraft:yellow_concrete
fill 270 112 557 271 113 557 minecraft:yellow_concrete
fill 271 112 599 271 117 599 minecraft:black_concrete
fill 277 112 557 277 117 557 minecraft:black_concrete
fill 277 112 558 277 112 559 minecraft:yellow_concrete
fill 277 112 560 277 117 560 minecraft:black_concrete
fill 277 112 562 277 113 562 minecraft:yellow_concrete
fill 277 112 568 277 117 569 minecraft:black_concrete
fill 277 112 570 277 113 571 minecraft:yellow_concrete
setblock 277 112 579 minecraft:yellow_concrete
fill 277 112 580 277 117 581 minecraft:black_concrete
fill 277 112 582 277 113 583 minecraft:yellow_concrete
fill 277 112 588 277 117 589 minecraft:black_concrete
fill 277 112 590 277 112 591 minecraft:yellow_concrete
fill 277 112 592 277 117 592 minecraft:black_concrete
fill 277 112 599 277 113 599 minecraft:yellow_concrete
setblock 235 113 566 minecraft:yellow_concrete
setblock 235 113 569 minecraft:yellow_concrete
fill 235 113 570 235 116 570 minecraft:black_concrete
setblock 235 113 577 minecraft:yellow_concrete
fill 235 113 581 235 116 581 minecraft:black_concrete
fill 235 113 597 235 113 598 minecraft:yellow_concrete
setblock 237 113 599 minecraft:yellow_concrete
fill 238 113 599 238 116 599 minecraft:black_concrete
fill 239 113 574 239 114 576 minecraft:magma_block
fill 247 113 557 247 116 557 minecraft:black_concrete
fill 249 113 599 249 115 599 minecraft:black_concrete
setblock 251 113 557 minecraft:yellow_concrete
setblock 254 113 599 minecraft:yellow_concrete
fill 258 113 557 258 116 557 minecraft:black_concrete
setblock 259 113 557 minecraft:yellow_concrete
setblock 262 113 557 minecraft:yellow_concrete
setblock 265 113 599 minecraft:yellow_concrete
fill 269 113 599 270 115 599 minecraft:black_concrete
fill 270 113 568 271 114 569 minecraft:shroomlight
fill 277 113 558 277 116 559 minecraft:black_concrete
setblock 277 113 563 minecraft:yellow_concrete
setblock 277 113 574 minecraft:yellow_concrete
fill 277 113 579 277 116 579 minecraft:black_concrete
fill 277 113 590 277 116 590 minecraft:black_concrete
setblock 277 113 591 minecraft:yellow_concrete
fill 277 113 594 277 113 595 minecraft:yellow_concrete
fill 235 114 557 235 119 558 minecraft:black_concrete
fill 235 114 564 235 115 564 minecraft:yellow_concrete
fill 235 114 566 235 123 566 minecraft:black_concrete
fill 235 114 567 235 114 568 minecraft:yellow_concrete
fill 235 114 569 235 123 569 minecraft:black_concrete
fill 235 114 575 235 115 576 minecraft:yellow_concrete
fill 235 114 577 235 121 578 minecraft:black_concrete
fill 235 114 587 235 114 588 minecraft:yellow_concrete
fill 235 114 589 235 123 590 minecraft:black_concrete
fill 235 114 596 235 115 596 minecraft:yellow_concrete
fill 235 114 597 235 120 598 minecraft:black_concrete
setblock 235 114 599 minecraft:yellow_concrete
fill 236 114 558 238 114 558 minecraft:orange_concrete
fill 236 114 560 236 114 562 minecraft:orange_concrete
fill 236 114 564 236 114 566 minecraft:orange_concrete
fill 236 114 568 236 114 570 minecraft:orange_concrete
fill 236 114 572 236 114 574 minecraft:orange_concrete
setblock 236 114 575 minecraft:magma_block
fill 236 114 576 236 114 578 minecraft:orange_concrete
fill 236 114 580 236 114 582 minecraft:orange_concrete
fill 236 114 584 236 114 586 minecraft:orange_concrete
fill 236 114 588 236 114 590 minecraft:orange_concrete
fill 236 114 592 236 114 594 minecraft:orange_concrete
fill 236 114 596 236 114 598 minecraft:orange_concrete
fill 237 114 599 237 116 599 minecraft:black_concrete
fill 238 114 557 239 119 557 minecraft:black_concrete
setblock 238 114 560 minecraft:light[level=14]
setblock 238 114 568 minecraft:light[level=14]
setblock 238 114 584 minecraft:light[level=14]
setblock 238 114 592 minecraft:light[level=14]
fill 238 114 598 240 114 598 minecraft:orange_concrete
fill 240 114 557 241 114 557 minecraft:yellow_concrete
fill 240 114 558 242 114 558 minecraft:orange_concrete
fill 240 114 574 240 114 576 minecraft:magma_block
fill 241 114 575 241 115 575 minecraft:magma_block
fill 242 114 598 244 114 598 minecraft:orange_concrete
fill 243 114 599 244 115 599 minecraft:yellow_concrete
fill 244 114 558 246 114 558 minecraft:orange_concrete
fill 245 114 599 246 123 599 minecraft:black_concrete
setblock 246 114 560 minecraft:light[level=14]
setblock 246 114 568 minecraft:light[level=14]
setblock 246 114 576 minecraft:light[level=14]
setblock 246 114 584 minecraft:light[level=14]
setblock 246 114 592 minecraft:light[level=14]
fill 246 114 598 248 114 598 minecraft:orange_concrete
fill 248 114 558 250 114 558 minecraft:orange_concrete
fill 250 114 557 251 120 557 minecraft:black_concrete
fill 250 114 598 252 114 598 minecraft:orange_concrete
setblock 251 114 599 minecraft:black_concrete
fill 252 114 557 253 115 557 minecraft:yellow_concrete
fill 252 114 558 254 114 558 minecraft:orange_concrete
fill 252 114 599 252 115 599 minecraft:yellow_concrete
setblock 254 114 560 minecraft:light[level=14]
setblock 254 114 568 minecraft:light[level=14]
setblock 254 114 576 minecraft:light[level=14]
setblock 254 114 584 minecraft:light[level=14]
setblock 254 114 592 minecraft:light[level=14]
fill 254 114 598 256 114 598 minecraft:orange_concrete
fill 254 114 599 254 123 599 minecraft:black_concrete
fill 255 114 599 256 114 599 minecraft:yellow_concrete
fill 256 114 558 258 114 558 minecraft:orange_concrete
fill 257 114 599 258 116 599 minecraft:black_concrete
fill 258 114 598 260 114 598 minecraft:orange_concrete
fill 259 114 557 259 123 557 minecraft:black_concrete
fill 260 114 557 261 114 557 minecraft:yellow_concrete
fill 260 114 558 262 114 558 minecraft:orange_concrete
fill 262 114 557 262 119 557 minecraft:black_concrete
setblock 262 114 560 minecraft:light[level=14]
setblock 262 114 568 minecraft:light[level=14]
setblock 262 114 576 minecraft:light[level=14]
setblock 262 114 584 minecraft:light[level=14]
setblock 262 114 592 minecraft:light[level=14]
fill 262 114 598 264 114 598 minecraft:orange_concrete
fill 263 114 599 264 115 599 minecraft:yellow_concrete
fill 264 114 557 264 115 557 minecraft:yellow_concrete
fill 264 114 558 266 114 558 minecraft:orange_concrete
fill 265 114 599 266 123 599 minecraft:black_concrete
fill 266 114 598 268 114 598 minecraft:orange_concrete
setblock 267 114 599 minecraft:yellow_concrete
fill 268 114 558 270 114 558 minecraft:orange_concrete
fill 268 114 599 268 117 599 minecraft:black_concrete
fill 270 114 557 271 121 557 minecraft:black_concrete
setblock 270 114 560 minecraft:light[level=14]
setblock 270 114 576 minecraft:light[level=14]
setblock 270 114 584 minecraft:light[level=14]
setblock 270 114 592 minecraft:light[level=14]
fill 270 114 598 272 114 598 minecraft:orange_concrete
fill 272 114 557 273 115 557 minecraft:yellow_concrete
fill 272 114 558 274 114 558 minecraft:orange_concrete
fill 274 114 598 276 114 598 minecraft:orange_concrete
fill 275 114 599 276 114 599 minecraft:yellow_concrete
fill 276 114 558 276 114 560 minecraft:orange_concrete
fill 276 114 562 276 114 564 minecraft:orange_concrete
fill 276 114 566 276 114 568 minecraft:orange_concrete
fill 276 114 570 276 114 572 minecraft:orange_concrete
fill 276 114 574 276 114 576 minecraft:orange_concrete
fill 276 114 578 276 114 580 minecraft:orange_concrete
fill 276 114 582 276 114 584 minecraft:orange_concrete
fill 276 114 586 276 114 588 minecraft:orange_concrete
fill 276 114 590 276 114 592 minecraft:orange_concrete
fill 276 114 594 276 114 596 minecraft:orange_concrete
setblock 277 114 561 minecraft:yellow_concrete
fill 277 114 562 277 120 563 minecraft:black_concrete
fill 277 114 564 277 115 565 minecraft:yellow_concrete
fill 277 114 570 277 119 571 minecraft:black_concrete
fill 277 114 572 277 114 573 minecraft:yellow_concrete
fill 277 114 574 277 123 574 minecraft:black_concrete
fill 277 114 582 277 119 583 minecraft:black_concrete
fill 277 114 584 277 115 585 minecraft:yellow_concrete
fill 277 114 591 277 120 591 minecraft:black_concrete
setblock 277 114 593 minecraft:yellow_concrete
fill 277 114 594 277 119 595 minecraft:black_concrete
fill 277 114 596 277 115 596 minecraft:yellow_concrete
fill 277 114 599 277 123 599 minecraft:black_concrete
setblock 235 115 563 minecraft:yellow_concrete
fill 235 115 567 235 118 568 minecraft:black_concrete
setblock 235 115 584 minecraft:yellow_concrete
setblock 235 115 587 minecraft:yellow_concrete
fill 235 115 588 235 118 588 minecraft:black_concrete
setblock 235 115 595 minecraft:yellow_concrete
fill 235 115 599 235 118 599 minecraft:black_concrete
fill 239 115 575 240 115 575 minecraft:magma_block
fill 239 115 599 239 117 599 minecraft:black_concrete
fill 240 115 557 240 118 557 minecraft:black_concrete
setblock 240 115 599 minecraft:yellow_concrete
setblock 241 115 557 minecraft:yellow_concrete
setblock 242 115 575 minecraft:magma_block
setblock 244 115 557 minecraft:yellow_concrete
setblock 251 115 599 minecraft:yellow_concrete
setblock 255 115 599 minecraft:yellow_concrete
fill 256 115 599 256 118 599 minecraft:black_concrete
fill 260 115 557 261 118 557 minecraft:black_concrete
setblock 265 115 557 minecraft:yellow_concrete
fill 267 115 599 267 117 599 minecraft:black_concrete
setblock 272 115 599 minecraft:yellow_concrete
setblock 275 115 599 minecraft:yellow_concrete
setblock 276 115 557 minecraft:yellow_concrete
fill 276 115 599 276 118 599 minecraft:black_concrete
fill 277 115 561 277 118 561 minecraft:black_concrete
fill 277 115 572 277 118 572 minecraft:black_concrete
setblock 277 115 573 minecraft:yellow_concrete
fill 277 115 576 277 115 577 minecraft:yellow_concrete
fill 277 115 593 277 118 593 minecraft:black_concrete
setblock 277 115 597 minecraft:yellow_concrete
fill 235 116 561 235 117 562 minecraft:yellow_concrete
fill 235 116 563 235 123 564 minecraft:black_concrete
setblock 235 116 565 minecraft:yellow_concrete
fill 235 116 573 235 117 574 minecraft:yellow_concrete
fill 235 116 575 235 123 576 minecraft:black_concrete
fill 235 116 582 235 117 582 minecraft:yellow_concrete
fill 235 116 584 235 120 584 minecraft:black_concrete
fill 235 116 585 235 116 586 minecraft:yellow_concrete
fill 235 116 587 235 123 587 minecraft:black_concrete
fill 235 116 593 235 117 594 minecraft:yellow_concrete
fill 235 116 595 235 123 596 minecraft:black_concrete
fill 240 116 599 240 117 599 minecraft:black_concrete
fill 241 116 557 241 120 557 minecraft:black_concrete
fill 241 116 599 242 116 599 minecraft:yellow_concrete
fill 242 116 557 243 116 557 minecraft:yellow_concrete
fill 243 116 599 244 119 599 minecraft:black_concrete
fill 244 116 557 244 121 557 minecraft:black_concrete
fill 246 116 557 246 117 557 minecraft:yellow_concrete
fill 249 116 599 250 117 599 minecraft:yellow_concrete
fill 251 116 599 252 123 599 minecraft:black_concrete
fill 252 116 557 253 120 557 minecraft:black_concrete
setblock 253 116 599 minecraft:yellow_concrete
fill 254 116 557 255 117 557 minecraft:yellow_concrete
fill 255 116 599 255 118 599 minecraft:black_concrete
fill 261 116 599 262 117 599 minecraft:yellow_concrete
setblock 263 116 557 minecraft:yellow_concrete
fill 263 116 599 264 120 599 minecraft:black_concrete
fill 264 116 557 265 123 557 minecraft:black_concrete
fill 266 116 557 267 117 557 minecraft:yellow_concrete
setblock 269 116 599 minecraft:black_concrete
fill 270 116 599 270 117 599 minecraft:yellow_concrete
fill 272 116 557 273 120 557 minecraft:black_concrete
fill 272 116 599 272 123 599 minecraft:black_concrete
fill 273 116 599 274 116 599 minecraft:yellow_concrete
fill 274 116 557 275 116 557 minecraft:yellow_concrete
fill 275 116 599 275 123 599 minecraft:black_concrete
fill 276 116 557 276 123 557 minecraft:black_concrete
fill 277 116 564 277 123 565 minecraft:black_concrete
fill 277 116 566 277 117 567 minecraft:yellow_concrete
fill 277 116 573 277 123 573 minecraft:black_concrete
setblock 277 116 575 minecraft:yellow_concrete
fill 277 116 576 277 119 577 minecraft:black_concrete
fill 277 116 578 277 117 578 minecraft:yellow_concrete
fill 277 116 584 277 123 585 minecraft:black_concrete
fill 277 116 586 277 116 587 minecraft:yellow_concrete
fill 277 116 596 277 121 597 minecraft:black_concrete
fill 277 116 598 277 117 598 minecraft:yellow_concrete
fill 235 117 565 235 124 565 minecraft:black_concrete
setblock 235 117 570 minecraft:yellow_concrete
setblock 235 117 581 minecraft:yellow_concrete
fill 235 117 585 235 123 586 minecraft:black_concrete
fill 237 117 599 238 117 599 minecraft:yellow_concrete
setblock 241 117 599 minecraft:yellow_concrete
fill 242 117 557 243 123 557 minecraft:black_concrete
fill 242 117 599 242 123 599 minecraft:black_concrete
setblock 247 117 557 minecraft:yellow_concrete
fill 253 117 599 253 123 599 minecraft:black_concrete
fill 257 117 599 257 120 599 minecraft:black_concrete
setblock 258 117 557 minecraft:yellow_concrete
setblock 258 117 599 minecraft:yellow_concrete
fill 263 117 557 263 123 557 minecraft:black_concrete
fill 267 117 586 268 118 587 minecraft:red_concrete
setblock 269 117 599 minecraft:yellow_concrete
fill 273 117 599 274 119 599 minecraft:black_concrete
fill 274 117 557 274 120 557 minecraft:black_concrete
setblock 275 117 557 minecraft:yellow_concrete
fill 277 117 558 277 117 559 minecraft:yellow_concrete
fill 277 117 575 277 123 575 minecraft:black_concrete
setblock 277 117 579 minecraft:yellow_concrete
fill 277 117 586 277 121 586 minecraft:black_concrete
setblock 277 117 587 minecraft:yellow_concrete
setblock 277 117 590 minecraft:yellow_concrete
fill 235 118 559 235 119 560 minecraft:yellow_concrete
fill 235 118 561 235 123 562 minecraft:black_concrete
fill 235 118 570 235 126 570 minecraft:black_concrete
fill 235 118 571 235 118 572 minecraft:yellow_concrete
fill 235 118 573 235 119 574 minecraft:black_concrete
fill 235 118 579 235 119 580 minecraft:yellow_concrete
fill 235 118 581 235 123 582 minecraft:black_concrete
setblock 235 118 583 minecraft:yellow_concrete
fill 235 118 591 235 119 592 minecraft:yellow_concrete
fill 235 118 593 235 123 594 minecraft:black_concrete
fill 236 118 557 237 119 557 minecraft:yellow_concrete
fill 236 118 599 236 119 599 minecraft:yellow_concrete
fill 237 118 599 238 121 599 minecraft:black_concrete
fill 239 118 599 240 118 599 minecraft:yellow_concrete
fill 241 118 599 241 119 599 minecraft:black_concrete
setblock 245 118 557 minecraft:yellow_concrete
fill 246 118 557 247 120 557 minecraft:black_concrete
fill 247 118 599 248 119 599 minecraft:yellow_concrete
fill 248 118 557 249 119 557 minecraft:yellow_concrete
fill 249 118 599 250 123 599 minecraft:black_concrete
fill 254 118 557 255 123 557 minecraft:black_concrete
fill 256 118 557 257 118 557 minecraft:yellow_concrete
fill 258 118 557 258 123 557 minecraft:black_concrete
fill 258 118 599 258 119 599 minecraft:black_concrete
fill 259 118 599 260 118 599 minecraft:yellow_concrete
fill 261 118 586 261 119 588 minecraft:red_concrete
fill 261 118 599 262 121 599 minecraft:black_concrete
fill 262 118 587 262 119 588 minecraft:red_concrete
fill 266 118 557 267 119 557 minecraft:black_concrete
fill 267 118 599 268 119 599 minecraft:yellow_concrete
fill 268 118 557 269 119 557 minecraft:yellow_concrete
fill 268 118 570 269 119 571 minecraft:yellow_concrete
fill 269 118 599 270 119 599 minecraft:black_concrete
setblock 271 118 599 minecraft:yellow_concrete
fill 275 118 557 275 121 557 minecraft:black_concrete
setblock 277 118 557 minecraft:yellow_concrete
fill 277 118 558 277 121 559 minecraft:black_concrete
fill 277 118 560 277 119 560 minecraft:yellow_concrete
fill 277 118 566 277 123 567 minecraft:black_concrete
fill 277 118 568 277 118 569 minecraft:yellow_concrete
fill 277 118 578 277 123 579 minecraft:black_concrete
fill 277 118 580 277 119 581 minecraft:yellow_concrete
fill 277 118 587 277 124 587 minecraft:black_concrete
fill 277 118 588 277 118 589 minecraft:yellow_concrete
fill 277 118 590 277 123 590 minecraft:black_concrete
fill 277 118 592 277 119 592 minecraft:yellow_concrete
fill 277 118 598 277 123 598 minecraft:black_concrete
fill 235 119 567 235 119 568 minecraft:yellow_concrete
setblock 235 119 571 minecraft:yellow_concrete
fill 235 119 572 235 123 572 minecraft:black_concrete
fill 235 119 583 235 123 583 minecraft:black_concrete
setblock 235 119 588 minecraft:yellow_concrete
setblock 235 119 599 minecraft:yellow_concrete
fill 239 119 599 240 120 599 minecraft:black_concrete
setblock 240 119 557 minecraft:yellow_concrete
fill 245 119 557 245 123 557 minecraft:black_concrete
fill 255 119 599 256 119 599 minecraft:yellow_concrete
fill 256 119 557 256 120 557 minecraft:black_concrete
setblock 257 119 557 minecraft:yellow_concrete
setblock 259 119 599 minecraft:yellow_concrete
fill 260 119 557 261 119 557 minecraft:yellow_concrete
fill 260 119 599 260 124 599 minecraft:black_concrete
fill 271 119 599 271 120 599 minecraft:black_concrete
setblock 276 119 599 minecraft:yellow_concrete
fill 277 119 557 277 123 557 minecraft:black_concrete
setblock 277 119 561 minecraft:yellow_concrete
fill 277 119 568 277 123 568 minecraft:black_concrete
setblock 277 119 569 minecraft:yellow_concrete
setblock 277 119 572 minecraft:yellow_concrete
fill 277 119 588 277 121 589 minecraft:black_concrete
setblock 277 119 593 minecraft:yellow_concrete
setblock 235 120 557 minecraft:orange_terracotta
fill 235 120 558 235 120 560 minecraft:black_concrete
setblock 235 120 567 minecraft:orange_terracotta
fill 235 120 568 235 123 568 minecraft:black_concrete
fill 235 120 571 235 123 571 minecraft:black_concrete
setblock 235 120 573 minecraft:orange_terracotta
fill 235 120 574 235 123 574 minecraft:black_concrete
fill 235 120 579 235 123 580 minecraft:black_concrete
setblock 235 120 588 minecraft:orange_terracotta
setblock 235 120 591 minecraft:orange_terracotta
fill 235 120 592 235 123 592 minecraft:black_concrete
fill 235 120 599 236 123 599 minecraft:black_concrete
fill 236 120 557 238 123 557 minecraft:black_concrete
setblock 239 120 557 minecraft:orange_terracotta
fill 240 120 557 240 123 557 minecraft:black_concrete
setblock 241 120 599 minecraft:orange_terracotta
setblock 243 120 599 minecraft:orange_terracotta
fill 244 120 599 244 123 599 minecraft:black_concrete
fill 247 120 599 248 121 599 minecraft:black_concrete
fill 248 120 557 249 123 557 minecraft:black_concrete
fill 255 120 599 256 120 599 minecraft:black_concrete
fill 257 120 557 257 123 557 minecraft:black_concrete
setblock 258 120 599 minecraft:orange_terracotta
fill 259 120 599 259 123 599 minecraft:black_concrete
fill 260 120 557 261 123 557 minecraft:black_concrete
setblock 262 120 557 minecraft:orange_terracotta
setblock 266 120 557 minecraft:orange_terracotta
fill 267 120 557 269 123 557 minecraft:black_concrete
fill 267 120 599 269 123 599 minecraft:black_concrete
setblock 270 120 599 minecraft:orange_terracotta
setblock 273 120 599 minecraft:orange_terracotta
fill 274 120 599 274 123 599 minecraft:black_concrete
fill 276 120 599 276 123 599 minecraft:black_concrete
fill 277 120 560 277 120 561 minecraft:orange_terracotta
fill 277 120 569 277 120 570 minecraft:black_concrete
setblock 277 120 571 minecraft:orange_terracotta
fill 277 120 572 277 123 572 minecraft:black_concrete
setblock 277 120 576 minecraft:orange_terracotta
fill 277 120 577 277 121 577 minecraft:black_concrete
fill 277 120 580 277 123 582 minecraft:black_concrete
setblock 277 120 583 minecraft:orange_terracotta
fill 277 120 592 277 123 594 minecraft:black_concrete
setblock 277 120 595 minecraft:orange_terracotta
fill 235 121 557 235 123 557 minecraft:black_concrete
setblock 235 121 558 minecraft:orange_terracotta
fill 235 121 559 235 123 560 minecraft:black_concrete
fill 235 121 567 235 123 567 minecraft:black_concrete
setblock 235 121 573 minecraft:black_concrete
setblock 235 121 584 minecraft:orange_terracotta
fill 235 121 588 235 123 588 minecraft:black_concrete
fill 235 121 591 235 123 591 minecraft:black_concrete
fill 235 121 597 235 123 597 minecraft:black_concrete
setblock 235 121 598 minecraft:orange_terracotta
fill 239 121 557 239 123 557 minecraft:black_concrete
setblock 239 121 599 minecraft:black_concrete
setblock 240 121 599 minecraft:orange_terracotta
setblock 241 121 557 minecraft:orange_terracotta
fill 241 121 599 241 123 599 minecraft:black_concrete
fill 243 121 599 243 123 599 minecraft:black_concrete
setblock 246 121 557 minecraft:orange_terracotta
fill 247 121 557 247 123 557 minecraft:black_concrete
fill 250 121 557 251 121 557 minecraft:orange_terracotta
fill 252 121 557 252 123 557 minecraft:black_concrete
fill 253 121 557 253 122 557 minecraft:orange_terracotta
fill 255 121 599 257 121 599 minecraft:orange_terracotta
setblock 256 121 557 minecraft:orange_terracotta
fill 258 121 599 258 123 599 minecraft:black_concrete
setblock 262 121 557 minecraft:black_concrete
fill 263 121 599 263 123 599 minecraft:black_concrete
setblock 264 121 599 minecraft:orange_terracotta
fill 266 121 557 266 123 557 minecraft:black_concrete
fill 270 121 599 270 123 599 minecraft:black_concrete
fill 271 121 599 271 122 599 minecraft:orange_terracotta
setblock 272 121 557 minecraft:orange_terracotta
setblock 273 121 557 minecraft:black_concrete
fill 273 121 599 273 123 599 minecraft:black_concrete
setblock 274 121 557 minecraft:orange_terracotta
fill 277 121 560 277 123 561 minecraft:black_concrete
setblock 277 121 562 minecraft:orange_terracotta
fill 277 121 563 277 123 563 minecraft:black_concrete
setblock 277 121 569 minecraft:black_concrete
setblock 277 121 570 minecraft:orange_terracotta
fill 277 121 571 277 124 571 minecraft:black_concrete
fill 277 121 576 277 123 576 minecraft:black_concrete
fill 277 121 583 277 123 583 minecraft:black_concrete
setblock 277 121 591 minecraft:orange_terracotta
fill 277 121 595 277 124 595 minecraft:black_concrete
fill 235 122 558 235 123 558 minecraft:black_concrete
setblock 235 122 573 minecraft:orange_terracotta
fill 235 122 577 235 123 577 minecraft:black_concrete
setblock 235 122 578 minecraft:orange_terracotta
fill 235 122 584 235 123 584 minecraft:black_concrete
fill 235 122 598 235 123 598 minecraft:black_concrete
fill 237 122 599 237 124 599 minecraft:black_concrete
setblock 238 122 560 minecraft:light[level=14]
setblock 238 122 568 minecraft:light[level=14]
setblock 238 122 576 minecraft:light[level=14]
setblock 238 122 584 minecraft:light[level=14]
setblock 238 122 592 minecraft:light[level=14]
fill 238 122 599 239 122 599 minecraft:orange_terracotta
fill 240 122 599 240 123 599 minecraft:black_concrete
fill 241 122 557 241 123 557 minecraft:black_concrete
setblock 244 122 557 minecraft:orange_terracotta
fill 246 122 557 246 123 557 minecraft:black_concrete
setblock 246 122 560 minecraft:light[level=14]
setblock 246 122 568 minecraft:light[level=14]
setblock 246 122 576 minecraft:light[level=14]
setblock 246 122 584 minecraft:light[level=14]
setblock 246 122 592 minecraft:light[level=14]
setblock 247 122 599 minecraft:orange_terracotta
fill 248 122 599 248 123 599 minecraft:black_concrete
fill 250 122 557 250 123 557 minecraft:black_concrete
setblock 251 122 557 minecraft:orange_terracotta
setblock 254 122 560 minecraft:light[level=14]
setblock 254 122 568 minecraft:light[level=14]
setblock 254 122 576 minecraft:light[level=14]
setblock 254 122 584 minecraft:light[level=14]
setblock 254 122 592 minecraft:light[level=14]
fill 255 122 599 257 123 599 minecraft:black_concrete
fill 256 122 557 256 124 557 minecraft:black_concrete
fill 261 122 599 261 123 599 minecraft:black_concrete
setblock 262 122 557 minecraft:orange_terracotta
setblock 262 122 560 minecraft:light[level=14]
setblock 262 122 568 minecraft:light[level=14]
setblock 262 122 576 minecraft:light[level=14]
setblock 262 122 584 minecraft:light[level=14]
setblock 262 122 592 minecraft:light[level=14]
setblock 262 122 599 minecraft:orange_terracotta
fill 264 122 599 264 123 599 minecraft:black_concrete
setblock 270 122 557 minecraft:orange_terracotta
setblock 270 122 560 minecraft:light[level=14]
setblock 270 122 568 minecraft:light[level=14]
setblock 270 122 576 minecraft:light[level=14]
setblock 270 122 584 minecraft:light[level=14]
setblock 270 122 592 minecraft:light[level=14]
fill 271 122 557 272 123 557 minecraft:black_concrete
setblock 273 122 557 minecraft:orange_terracotta
fill 274 122 557 274 124 557 minecraft:black_concrete
setblock 275 122 557 minecraft:orange_terracotta
setblock 277 122 558 minecraft:orange_terracotta
fill 277 122 559 277 123 559 minecraft:black_concrete
fill 277 122 562 277 123 562 minecraft:black_concrete
setblock 277 122 569 minecraft:orange_terracotta
fill 277 122 570 277 123 570 minecraft:black_concrete
setblock 277 122 577 minecraft:orange_terracotta
setblock 277 122 586 minecraft:orange_terracotta
fill 277 122 588 277 123 588 minecraft:black_concrete
setblock 277 122 589 minecraft:orange_terracotta
fill 277 122 591 277 123 591 minecraft:black_concrete
fill 277 122 596 277 123 596 minecraft:black_concrete
setblock 277 122 597 minecraft:orange_terracotta
setblock 235 123 573 minecraft:black_concrete
fill 235 123 578 235 125 578 minecraft:black_concrete
fill 238 123 599 239 123 599 minecraft:black_concrete
setblock 244 123 557 minecraft:black_concrete
setblock 247 123 599 minecraft:black_concrete
setblock 251 123 557 minecraft:black_concrete
setblock 253 123 557 minecraft:black_concrete
setblock 262 123 557 minecraft:black_concrete
setblock 262 123 599 minecraft:black_concrete
setblock 270 123 557 minecraft:black_concrete
setblock 271 123 599 minecraft:black_concrete
setblock 273 123 557 minecraft:black_concrete
fill 275 123 557 275 124 557 minecraft:black_concrete
setblock 277 123 558 minecraft:black_concrete
fill 277 123 569 277 124 569 minecraft:black_concrete
fill 277 123 577 277 124 577 minecraft:black_concrete
setblock 277 123 586 minecraft:black_concrete
setblock 277 123 589 minecraft:black_concrete
setblock 277 123 597 minecraft:black_concrete
fill 235 124 557 235 129 564 minecraft:orange_terracotta
fill 235 124 566 235 131 569 minecraft:orange_terracotta
fill 235 124 571 235 125 577 minecraft:orange_terracotta
fill 235 124 579 235 125 599 minecraft:orange_terracotta
setblock 236 124 557 minecraft:orange_terracotta
fill 236 124 599 236 133 599 minecraft:orange_terracotta
fill 237 124 557 237 125 557 minecraft:black_concrete
fill 238 124 557 248 124 557 minecraft:orange_terracotta
fill 238 124 599 248 125 599 minecraft:orange_terracotta
setblock 249 124 557 minecraft:black_concrete
setblock 249 124 599 minecraft:black_concrete
fill 250 124 557 255 129 557 minecraft:orange_terracotta
fill 250 124 599 259 124 599 minecraft:orange_terracotta
fill 251 124 582 253 124 584 minecraft:redstone_block
fill 252 124 575 254 124 577 minecraft:redstone_block
fill 256 124 584 258 124 586 minecraft:redstone_block
fill 257 124 557 273 124 557 minecraft:orange_terracotta
fill 258 124 575 260 124 577 minecraft:redstone_block
fill 261 124 599 277 124 599 minecraft:orange_terracotta
fill 276 124 557 277 124 557 minecraft:orange_terracotta
fill 277 124 558 277 131 560 minecraft:orange_terracotta
setblock 277 124 561 minecraft:black_concrete
fill 277 124 562 277 124 568 minecraft:orange_terracotta
fill 277 124 570 277 131 570 minecraft:orange_terracotta
fill 277 124 572 277 129 576 minecraft:orange_terracotta
fill 277 124 578 277 131 578 minecraft:orange_terracotta
setblock 277 124 579 minecraft:black_concrete
fill 277 124 580 277 129 586 minecraft:orange_terracotta
fill 277 124 588 277 124 594 minecraft:orange_terracotta
fill 277 124 596 277 129 598 minecraft:orange_terracotta
fill 235 125 565 235 135 565 minecraft:orange_terracotta
setblock 236 125 557 minecraft:black_concrete
fill 237 125 599 237 131 599 minecraft:orange_terracotta
fill 238 125 557 244 129 557 minecraft:orange_terracotta
fill 238 125 580 254 125 580 minecraft:gray_concrete
fill 239 125 575 251 125 579 minecraft:gray_concrete
fill 239 125 581 250 125 585 minecraft:gray_concrete
fill 240 125 572 272 125 574 minecraft:gray_concrete
fill 240 125 586 255 125 588 minecraft:gray_concrete
fill 241 125 571 271 125 571 minecraft:gray_concrete
fill 241 125 589 271 125 589 minecraft:gray_concrete
fill 242 125 569 270 125 570 minecraft:gray_concrete
fill 242 125 590 270 125 591 minecraft:gray_concrete
fill 243 125 568 269 125 568 minecraft:gray_concrete
fill 243 125 592 269 125 592 minecraft:gray_concrete
fill 244 125 567 268 125 567 minecraft:gray_concrete
fill 244 125 593 268 125 593 minecraft:gray_concrete
setblock 245 125 557 minecraft:black_concrete
fill 245 125 566 267 125 566 minecraft:gray_concrete
fill 245 125 594 267 125 594 minecraft:gray_concrete
fill 246 125 557 249 131 557 minecraft:orange_terracotta
fill 247 125 565 265 125 565 minecraft:gray_concrete
fill 247 125 595 265 125 595 minecraft:gray_concrete
fill 248 125 564 264 125 564 minecraft:gray_concrete
fill 248 125 596 264 125 596 minecraft:gray_concrete
fill 249 125 599 258 125 599 minecraft:orange_terracotta
fill 251 125 563 261 125 563 minecraft:gray_concrete
fill 251 125 581 254 125 581 minecraft:gray_concrete
fill 251 125 585 255 125 585 minecraft:gray_concrete
fill 251 125 597 261 125 597 minecraft:gray_concrete
fill 252 125 578 254 125 579 minecraft:gray_concrete
fill 254 125 582 255 125 584 minecraft:gray_concrete
fill 255 125 575 257 125 578 minecraft:gray_concrete
fill 256 125 557 262 125 557 minecraft:orange_terracotta
fill 256 125 562 256 132 562 minecraft:gray_concrete
fill 256 125 582 273 125 583 minecraft:gray_concrete
fill 256 125 587 272 125 588 minecraft:gray_concrete
fill 256 125 598 256 132 598 minecraft:gray_concrete
fill 258 125 578 273 125 581 minecraft:gray_concrete
fill 259 125 584 272 125 586 minecraft:gray_concrete
setblock 259 125 599 minecraft:black_concrete
fill 260 125 599 276 125 599 minecraft:orange_terracotta
fill 261 125 575 273 125 577 minecraft:gray_concrete
fill 263 125 557 264 125 557 minecraft:black_concrete
fill 265 125 557 276 125 557 minecraft:orange_terracotta
fill 273 125 584 273 132 585 minecraft:gray_concrete
fill 274 125 580 274 132 580 minecraft:gray_concrete
fill 277 125 557 277 126 557 minecraft:black_concrete
fill 277 125 561 277 132 563 minecraft:orange_terracotta
fill 277 125 564 277 125 565 minecraft:black_concrete
fill 277 125 566 277 131 567 minecraft:orange_terracotta
setblock 277 125 568 minecraft:black_concrete
fill 277 125 569 277 130 569 minecraft:orange_terracotta
fill 277 125 571 277 131 571 minecraft:orange_terracotta
fill 277 125 577 277 129 577 minecraft:orange_terracotta
fill 277 125 579 277 131 579 minecraft:orange_terracotta
fill 277 125 587 277 129 589 minecraft:orange_terracotta
fill 277 125 590 277 126 590 minecraft:black_concrete
fill 277 125 591 277 131 595 minecraft:orange_terracotta
setblock 277 125 599 minecraft:black_concrete
setblock 235 126 571 minecraft:black_concrete
fill 235 126 572 235 129 585 minecraft:orange_terracotta
setblock 235 126 586 minecraft:black_concrete
fill 235 126 587 235 131 590 minecraft:orange_terracotta
setblock 235 126 591 minecraft:black_concrete
fill 235 126 592 235 129 594 minecraft:orange_terracotta
setblock 235 126 595 minecraft:black_concrete
fill 235 126 596 235 129 599 minecraft:orange_terracotta
fill 236 126 557 237 130 557 minecraft:orange_terracotta
fill 236 126 558 238 126 598 minecraft:gray_concrete
fill 238 126 599 245 129 599 minecraft:orange_terracotta
fill 239 126 558 241 126 576 minecraft:gray_concrete
fill 239 126 577 240 132 577 minecraft:magma_block
fill 239 126 578 239 126 598 minecraft:gray_concrete
fill 240 126 578 240 132 583 minecraft:gray_concrete
fill 240 126 584 240 132 584 minecraft:magma_block
fill 240 126 585 242 126 598 minecraft:gray_concrete
fill 241 126 577 241 132 582 minecraft:gray_concrete
fill 241 126 583 241 132 583 minecraft:magma_block
fill 241 126 584 246 130 584 minecraft:gray_concrete
fill 242 126 558 246 126 569 minecraft:gray_concrete
fill 242 126 570 243 132 570 minecraft:magma_block
fill 242 126 571 246 130 575 minecraft:gray_concrete
fill 242 126 576 243 132 576 minecraft:magma_block
fill 242 126 577 243 131 581 minecraft:gray_concrete
fill 242 126 582 242 132 582 minecraft:magma_block
fill 242 126 583 247 130 583 minecraft:gray_concrete
fill 243 126 582 249 129 582 minecraft:gray_concrete
fill 243 126 585 243 132 591 minecraft:gray_concrete
fill 243 126 592 243 132 592 minecraft:magma_block
fill 243 126 593 248 126 598 minecraft:gray_concrete
fill 244 126 570 253 130 570 minecraft:gray_concrete
fill 244 126 576 248 129 580 minecraft:gray_concrete
fill 244 126 581 244 131 581 minecraft:magma_block
fill 244 126 585 244 131 588 minecraft:gray_concrete
fill 244 126 589 244 132 589 minecraft:magma_block
fill 244 126 590 248 131 592 minecraft:gray_concrete
fill 245 126 557 245 129 557 minecraft:orange_terracotta
fill 245 126 581 249 129 581 minecraft:gray_concrete
fill 245 126 585 245 131 586 minecraft:gray_concrete
fill 245 126 587 245 131 587 minecraft:magma_block
fill 245 126 588 256 129 589 minecraft:gray_concrete
fill 246 126 585 246 130 585 minecraft:magma_block
fill 246 126 586 254 128 587 minecraft:gray_concrete
setblock 246 126 599 minecraft:black_concrete
fill 247 126 558 254 126 564 minecraft:gray_concrete
fill 247 126 565 248 132 565 minecraft:magma_block
fill 247 126 566 250 131 569 minecraft:gray_concrete
fill 247 126 571 248 131 571 minecraft:magma_block
fill 247 126 572 249 129 575 minecraft:gray_concrete
fill 247 126 584 247 130 584 minecraft:magma_block
fill 247 126 585 249 129 585 minecraft:gray_concrete
fill 247 126 599 250 130 599 minecraft:orange_terracotta
fill 248 126 583 248 129 583 minecraft:magma_block
fill 248 126 584 249 129 584 minecraft:gray_concrete
fill 249 126 565 276 126 565 minecraft:gray_concrete
fill 249 126 571 267 129 571 minecraft:gray_concrete
fill 249 126 576 249 129 578 minecraft:gray_concrete
fill 249 126 579 249 129 579 minecraft:magma_block
fill 249 126 580 251 128 580 minecraft:gray_concrete
fill 249 126 583 249 129 583 minecraft:gray_concrete
fill 249 126 590 249 131 594 minecraft:magma_block
fill 249 126 595 255 126 598 minecraft:gray_concrete
fill 250 126 572 250 130 572 minecraft:magma_block
fill 250 126 573 250 129 575 minecraft:gray_concrete
fill 250 126 576 250 129 576 minecraft:magma_block
fill 250 126 577 250 128 579 minecraft:gray_concrete
fill 250 126 581 250 126 585 minecraft:shroomlight
fill 250 126 590 253 130 594 minecraft:gray_concrete
fill 251 126 566 256 132 566 minecraft:gray_concrete
fill 251 126 567 251 132 567 minecraft:magma_block
fill 251 126 568 251 131 569 minecraft:gray_concrete
fill 251 126 572 254 129 573 minecraft:gray_concrete
fill 251 126 574 251 126 578 minecraft:shroomlight
fill 251 126 579 251 128 579 minecraft:gray_concrete
fill 251 126 581 254 126 581 minecraft:shroomlight
fill 251 126 582 253 126 584 minecraft:gray_concrete
fill 251 126 585 255 126 585 minecraft:shroomlight
setblock 251 126 599 minecraft:black_concrete
fill 252 126 567 262 131 567 minecraft:gray_concrete
fill 252 126 568 252 131 568 minecraft:magma_block
fill 252 126 569 252 131 569 minecraft:gray_concrete
fill 252 126 574 255 126 574 minecraft:shroomlight
fill 252 126 575 254 126 577 minecraft:gray_concrete
fill 252 126 578 261 126 578 minecraft:shroomlight
fill 252 126 579 253 127 580 minecraft:orange_concrete
fill 252 126 599 272 129 599 minecraft:orange_terracotta
fill 253 126 568 257 131 568 minecraft:gray_concrete
fill 253 126 569 253 131 569 minecraft:magma_block
fill 254 126 569 257 130 569 minecraft:gray_concrete
fill 254 126 570 254 130 570 minecraft:magma_block
fill 254 126 579 254 126 580 minecraft:shroomlight
fill 254 126 582 255 126 584 minecraft:shroomlight
fill 254 126 590 257 130 590 minecraft:gray_concrete
fill 254 126 591 254 130 592 minecraft:magma_block
fill 254 126 593 254 131 594 minecraft:gray_concrete
fill 255 126 558 255 126 562 minecraft:gray_concrete
fill 255 126 563 255 132 563 minecraft:magma_block
fill 255 126 564 255 132 564 minecraft:gray_concrete
fill 255 126 570 262 130 570 minecraft:gray_concrete
fill 255 126 572 255 129 572 minecraft:magma_block
fill 255 126 573 266 129 573 minecraft:gray_concrete
fill 255 126 575 255 126 577 minecraft:shroomlight
fill 255 126 586 255 126 587 minecraft:shroomlight
fill 255 126 591 258 130 593 minecraft:gray_concrete
fill 255 126 594 255 132 594 minecraft:magma_block
fill 256 126 557 261 129 557 minecraft:orange_terracotta
fill 256 126 558 276 126 561 minecraft:gray_concrete
fill 256 126 563 276 126 563 minecraft:gray_concrete
fill 256 126 564 256 132 564 minecraft:magma_block
fill 256 126 572 276 126 572 minecraft:gray_concrete
fill 256 126 574 256 128 574 minecraft:gray_concrete
fill 256 126 575 256 128 575 minecraft:magma_block
fill 256 126 576 256 127 577 minecraft:orange_concrete
fill 256 126 582 258 126 583 minecraft:shroomlight
fill 256 126 584 258 126 586 minecraft:gray_concrete
fill 256 126 587 259 126 587 minecraft:shroomlight
fill 256 126 594 263 132 595 minecraft:gray_concrete
fill 256 126 596 256 132 596 minecraft:magma_block
fill 256 126 597 256 132 597 minecraft:gray_concrete
fill 257 126 562 276 126 562 minecraft:gray_concrete
fill 257 126 564 276 126 564 minecraft:gray_concrete
fill 257 126 566 257 132 566 minecraft:magma_block
fill 257 126 574 257 126 577 minecraft:shroomlight
fill 257 126 588 257 129 588 minecraft:magma_block
fill 257 126 589 263 129 589 minecraft:gray_concrete
fill 257 126 596 276 126 596 minecraft:gray_concrete
fill 257 126 597 257 132 597 minecraft:magma_block
fill 257 126 598 276 126 598 minecraft:gray_concrete
fill 258 126 566 262 132 566 minecraft:gray_concrete
fill 258 126 568 258 130 569 minecraft:magma_block
fill 258 126 574 261 126 574 minecraft:shroomlight
fill 258 126 575 260 126 577 minecraft:gray_concrete
fill 258 126 579 258 126 581 minecraft:shroomlight
fill 258 126 588 261 129 588 minecraft:gray_concrete
fill 258 126 590 258 130 590 minecraft:magma_block
fill 258 126 597 276 126 597 minecraft:gray_concrete
fill 259 126 568 262 131 569 minecraft:gray_concrete
fill 259 126 579 260 127 582 minecraft:orange_concrete
fill 259 126 583 259 126 586 minecraft:shroomlight
fill 259 126 590 268 130 590 minecraft:gray_concrete
fill 259 126 591 259 131 591 minecraft:magma_block
fill 259 126 592 259 131 593 minecraft:gray_concrete
fill 260 126 583 261 128 587 minecraft:gray_concrete
fill 260 126 591 276 126 591 minecraft:gray_concrete
fill 260 126 592 260 131 592 minecraft:magma_block
fill 260 126 593 260 132 593 minecraft:gray_concrete
fill 261 126 575 261 126 577 minecraft:shroomlight
fill 261 126 579 262 128 582 minecraft:gray_concrete
fill 261 126 592 276 126 592 minecraft:gray_concrete
fill 261 126 593 261 132 593 minecraft:magma_block
setblock 262 126 557 minecraft:black_concrete
fill 262 126 574 263 128 578 minecraft:gray_concrete
fill 262 126 583 271 128 583 minecraft:gray_concrete
fill 262 126 584 262 129 584 minecraft:magma_block
fill 262 126 585 272 129 587 minecraft:gray_concrete
fill 262 126 588 262 130 588 minecraft:magma_block
fill 262 126 593 276 126 593 minecraft:gray_concrete
fill 263 126 557 267 129 557 minecraft:orange_terracotta
fill 263 126 566 263 131 570 minecraft:magma_block
fill 263 126 579 267 129 580 minecraft:gray_concrete
fill 263 126 581 263 129 581 minecraft:magma_block
fill 263 126 582 276 126 582 minecraft:gray_concrete
fill 263 126 584 268 129 584 minecraft:gray_concrete
fill 263 126 588 276 126 588 minecraft:gray_concrete
fill 264 126 566 268 126 570 minecraft:gray_concrete
fill 264 126 574 264 129 576 minecraft:gray_concrete
fill 264 126 577 264 129 577 minecraft:magma_block
fill 264 126 578 269 129 578 minecraft:gray_concrete
fill 264 126 581 276 126 581 minecraft:gray_concrete
fill 264 126 589 265 131 589 minecraft:magma_block
fill 264 126 594 276 126 594 minecraft:gray_concrete
fill 264 126 595 265 132 595 minecraft:magma_block
fill 265 126 574 265 130 575 minecraft:gray_concrete
fill 265 126 576 265 130 576 minecraft:magma_block
fill 265 126 577 270 130 577 minecraft:gray_concrete
fill 266 126 574 276 126 574 minecraft:gray_concrete
fill 266 126 575 266 130 575 minecraft:magma_block
fill 266 126 576 271 130 576 minecraft:gray_concrete
fill 266 126 589 276 126 589 minecraft:gray_concrete
fill 266 126 595 276 126 595 minecraft:gray_concrete
fill 267 126 573 267 131 573 minecraft:magma_block
fill 267 126 575 276 126 575 minecraft:gray_concrete
setblock 268 126 557 minecraft:black_concrete
fill 268 126 571 268 132 571 minecraft:magma_block
fill 268 126 573 276 126 573 minecraft:gray_concrete
fill 268 126 579 268 131 579 minecraft:magma_block
fill 268 126 580 273 131 580 minecraft:gray_concrete
fill 269 126 557 270 131 557 minecraft:orange_terracotta
fill 269 126 566 276 126 567 minecraft:gray_concrete
fill 269 126 568 269 132 568 minecraft:magma_block
fill 269 126 569 276 126 571 minecraft:gray_concrete
fill 269 126 579 276 126 579 minecraft:gray_concrete
fill 269 126 584 270 132 584 minecraft:magma_block
fill 269 126 590 270 132 590 minecraft:magma_block
fill 270 126 568 276 126 568 minecraft:gray_concrete
fill 270 126 578 270 132 578 minecraft:magma_block
setblock 271 126 557 minecraft:black_concrete
fill 271 126 577 271 132 577 minecraft:magma_block
fill 271 126 578 276 126 578 minecraft:gray_concrete
fill 271 126 584 272 132 584 minecraft:gray_concrete
fill 271 126 590 276 126 590 minecraft:gray_concrete
fill 272 126 557 276 129 557 minecraft:orange_terracotta
fill 272 126 576 272 132 576 minecraft:magma_block
fill 272 126 577 276 126 577 minecraft:gray_concrete
fill 272 126 583 273 132 583 minecraft:magma_block
fill 273 126 576 276 126 576 minecraft:gray_concrete
fill 273 126 586 276 126 587 minecraft:gray_concrete
setblock 273 126 599 minecraft:black_concrete
fill 274 126 583 276 126 585 minecraft:gray_concrete
fill 274 126 599 277 132 599 minecraft:orange_terracotta
fill 275 126 580 276 126 580 minecraft:gray_concrete
fill 277 126 564 277 129 564 minecraft:orange_terracotta
setblock 277 126 565 minecraft:black_concrete
fill 277 126 568 277 129 568 minecraft:orange_terracotta
fill 235 127 570 235 130 571 minecraft:orange_terracotta
fill 235 127 586 235 135 586 minecraft:orange_terracotta
fill 235 127 591 235 130 591 minecraft:orange_terracotta
fill 235 127 595 235 129 595 minecraft:orange_terracotta
fill 238 127 580 239 132 580 minecraft:gray_concrete
fill 239 127 575 241 132 576 minecraft:gray_concrete
fill 239 127 578 239 132 579 minecraft:gray_concrete
fill 239 127 581 239 132 585 minecraft:gray_concrete
fill 240 127 572 241 132 574 minecraft:gray_concrete
fill 240 127 585 242 132 588 minecraft:gray_concrete
fill 241 127 571 241 132 571 minecraft:gray_concrete
fill 241 127 589 242 132 589 minecraft:gray_concrete
fill 242 127 569 246 132 569 minecraft:gray_concrete
fill 242 127 590 242 132 591 minecraft:gray_concrete
fill 243 127 568 246 132 568 minecraft:gray_concrete
fill 244 127 567 246 132 567 minecraft:gray_concrete
fill 244 127 593 248 132 593 minecraft:gray_concrete
fill 245 127 566 246 132 566 minecraft:gray_concrete
fill 245 127 594 248 132 594 minecraft:gray_concrete
fill 246 127 599 246 131 599 minecraft:orange_terracotta
fill 247 127 595 255 132 595 minecraft:gray_concrete
fill 248 127 564 254 132 564 minecraft:gray_concrete
fill 248 127 596 255 132 596 minecraft:gray_concrete
fill 249 127 565 265 132 565 minecraft:gray_concrete
fill 250 127 581 251 128 585 minecraft:gray_concrete
fill 251 127 563 254 132 563 minecraft:gray_concrete
fill 251 127 574 251 128 578 minecraft:gray_concrete
fill 251 127 597 255 132 597 minecraft:gray_concrete
fill 251 127 599 251 129 599 minecraft:orange_terracotta
fill 252 127 574 252 128 577 minecraft:gray_concrete
fill 252 127 578 254 127 578 minecraft:orange_concrete
fill 252 127 581 253 127 582 minecraft:orange_concrete
fill 252 127 583 252 128 585 minecraft:gray_concrete
fill 253 127 574 253 128 576 minecraft:gray_concrete
fill 253 127 577 255 127 577 minecraft:orange_concrete
fill 253 127 583 259 127 583 minecraft:orange_concrete
fill 253 127 584 253 128 585 minecraft:gray_concrete
fill 254 127 574 255 128 575 minecraft:gray_concrete
fill 254 127 576 255 127 576 minecraft:orange_concrete
setblock 254 127 582 minecraft:orange_concrete
fill 254 127 584 258 127 584 minecraft:orange_concrete
fill 254 127 585 255 128 585 minecraft:gray_concrete
fill 255 127 586 259 128 587 minecraft:gray_concrete
fill 256 127 563 261 132 563 minecraft:gray_concrete
fill 256 127 572 272 129 572 minecraft:gray_concrete
fill 256 127 585 256 128 585 minecraft:magma_block
fill 257 127 564 264 132 564 minecraft:gray_concrete
fill 257 127 574 261 128 575 minecraft:gray_concrete
fill 257 127 576 258 127 577 minecraft:orange_concrete
fill 257 127 585 259 128 585 minecraft:gray_concrete
fill 257 127 596 264 132 596 minecraft:gray_concrete
fill 258 127 578 260 127 578 minecraft:orange_concrete
setblock 258 127 582 minecraft:orange_concrete
fill 258 127 597 261 132 597 minecraft:gray_concrete
fill 259 127 576 261 128 576 minecraft:gray_concrete
setblock 259 127 577 minecraft:orange_concrete
fill 259 127 584 259 128 584 minecraft:gray_concrete
fill 260 127 577 261 128 577 minecraft:gray_concrete
fill 260 127 591 270 131 591 minecraft:gray_concrete
fill 261 127 578 261 128 578 minecraft:gray_concrete
fill 261 127 592 269 131 592 minecraft:gray_concrete
fill 262 127 557 262 135 557 minecraft:orange_terracotta
fill 262 127 593 268 132 593 minecraft:gray_concrete
fill 263 127 582 273 129 582 minecraft:gray_concrete
fill 263 127 588 272 130 588 minecraft:gray_concrete
fill 264 127 566 267 131 570 minecraft:gray_concrete
fill 264 127 581 273 129 581 minecraft:gray_concrete
fill 264 127 594 267 132 594 minecraft:gray_concrete
fill 266 127 574 272 131 574 minecraft:gray_concrete
fill 266 127 589 271 132 589 minecraft:gray_concrete
fill 267 127 575 273 131 575 minecraft:gray_concrete
fill 268 127 557 268 130 557 minecraft:orange_terracotta
fill 268 127 567 268 132 570 minecraft:gray_concrete
fill 268 127 573 272 132 573 minecraft:gray_concrete
fill 269 127 569 270 132 571 minecraft:gray_concrete
fill 269 127 579 273 131 579 minecraft:gray_concrete
fill 271 127 557 271 132 557 minecraft:orange_terracotta
fill 271 127 571 271 132 571 minecraft:gray_concrete
fill 271 127 578 273 132 578 minecraft:gray_concrete
fill 272 127 577 273 132 577 minecraft:gray_concrete
fill 273 127 576 273 132 576 minecraft:gray_concrete
fill 273 127 599 273 135 599 minecraft:orange_terracotta
fill 277 127 557 277 129 557 minecraft:orange_terracotta
fill 277 127 565 277 129 565 minecraft:orange_terracotta
fill 277 127 590 277 131 590 minecraft:orange_terracotta
fill 246 129 586 252 129 587 minecraft:gray_concrete
setblock 249 129 580 minecraft:gray_concrete
fill 250 129 584 250 129 585 minecraft:gray_concrete
fill 251 129 574 251 129 575 minecraft:gray_concrete
setblock 251 129 585 minecraft:gray_concrete
setblock 252 129 574 minecraft:gray_concrete
fill 253 129 587 261 129 587 minecraft:gray_concrete
fill 260 129 574 263 129 574 minecraft:gray_concrete
fill 260 129 586 261 129 586 minecraft:gray_concrete
fill 261 129 575 263 129 575 minecraft:gray_concrete
setblock 261 129 585 minecraft:gray_concrete
fill 262 129 576 263 129 576 minecraft:gray_concrete
fill 263 129 577 263 129 578 minecraft:gray_concrete
fill 263 129 583 271 129 583 minecraft:gray_concrete
fill 235 130 557 235 130 562 minecraft:orange_terracotta
fill 235 130 563 235 130 564 minecraft:yellow_concrete
fill 235 130 572 235 131 572 minecraft:yellow_concrete
fill 235 130 573 235 135 574 minecraft:orange_terracotta
setblock 235 130 575 minecraft:yellow_concrete
fill 235 130 576 235 130 582 minecraft:orange_terracotta
fill 235 130 583 235 131 584 minecraft:yellow_concrete
fill 235 130 585 235 135 585 minecraft:orange_terracotta
fill 235 130 592 235 131 592 minecraft:yellow_concrete
fill 235 130 593 235 131 594 minecraft:orange_terracotta
fill 235 130 595 235 130 596 minecraft:yellow_concrete
fill 235 130 597 235 132 599 minecraft:orange_terracotta
fill 236 130 579 238 132 579 minecraft:magma_block
fill 238 130 557 243 131 557 minecraft:orange_terracotta
setblock 238 130 560 minecraft:light[level=14]
setblock 238 130 568 minecraft:light[level=14]
setblock 238 130 576 minecraft:light[level=14]
setblock 238 130 584 minecraft:light[level=14]
setblock 238 130 592 minecraft:light[level=14]
fill 238 130 599 238 131 599 minecraft:orange_terracotta
fill 239 130 599 240 131 599 minecraft:yellow_concrete
fill 241 130 599 242 135 599 minecraft:orange_terracotta
fill 243 130 582 247 130 582 minecraft:gray_concrete
setblock 243 130 599 minecraft:yellow_concrete
fill 244 130 557 245 131 557 minecraft:yellow_concrete
fill 244 130 576 246 130 580 minecraft:gray_concrete
fill 244 130 599 245 132 599 minecraft:orange_terracotta
fill 245 130 581 246 130 581 minecraft:gray_concrete
fill 245 130 588 251 130 589 minecraft:gray_concrete
setblock 246 130 560 minecraft:light[level=14]
fill 246 130 586 249 130 587 minecraft:gray_concrete
fill 247 130 572 247 130 578 minecraft:gray_concrete
fill 247 130 585 248 130 585 minecraft:gray_concrete
fill 248 130 572 248 130 575 minecraft:gray_concrete
fill 249 130 571 249 130 574 minecraft:gray_concrete
fill 250 130 557 252 132 557 minecraft:orange_terracotta
fill 250 130 571 254 130 571 minecraft:gray_concrete
setblock 250 130 573 minecraft:gray_concrete
setblock 250 130 587 minecraft:gray_concrete
setblock 251 130 572 minecraft:gray_concrete
fill 251 130 599 252 130 599 minecraft:yellow_concrete
fill 252 130 589 254 130 589 minecraft:gray_concrete
setblock 253 130 557 minecraft:yellow_concrete
fill 253 130 599 259 130 599 minecraft:orange_terracotta
fill 254 130 557 255 135 557 minecraft:orange_terracotta
setblock 254 130 560 minecraft:light[level=14]
setblock 254 130 576 minecraft:light[level=14]
setblock 254 130 584 minecraft:light[level=14]
fill 256 130 557 256 131 557 minecraft:yellow_concrete
fill 257 130 557 261 130 557 minecraft:orange_terracotta
fill 258 130 571 267 130 571 minecraft:gray_concrete
fill 258 130 589 263 130 589 minecraft:gray_concrete
fill 260 130 599 260 131 599 minecraft:yellow_concrete
fill 261 130 572 272 130 572 minecraft:gray_concrete
setblock 261 130 588 minecraft:gray_concrete
fill 261 130 599 262 135 599 minecraft:orange_terracotta
setblock 262 130 560 minecraft:light[level=14]
fill 262 130 573 266 130 573 minecraft:gray_concrete
setblock 262 130 576 minecraft:light[level=14]
setblock 262 130 584 minecraft:light[level=14]
fill 262 130 587 272 130 587 minecraft:gray_concrete
fill 263 130 557 263 135 557 minecraft:orange_terracotta
fill 263 130 574 264 130 574 minecraft:gray_concrete
fill 263 130 586 272 130 586 minecraft:gray_concrete
setblock 263 130 599 minecraft:yellow_concrete
fill 264 130 557 265 130 557 minecraft:yellow_concrete
setblock 264 130 575 minecraft:gray_concrete
fill 264 130 585 272 130 585 minecraft:gray_concrete
fill 264 130 599 270 131 599 minecraft:orange_terracotta
fill 265 130 578 269 130 578 minecraft:gray_concrete
fill 265 130 582 268 130 584 minecraft:gray_concrete
fill 266 130 557 267 131 557 minecraft:orange_terracotta
fill 266 130 579 267 130 581 minecraft:gray_concrete
fill 268 130 581 273 131 581 minecraft:gray_concrete
fill 269 130 582 271 131 583 minecraft:gray_concrete
setblock 270 130 560 minecraft:light[level=14]
setblock 270 130 568 minecraft:light[level=14]
setblock 270 130 592 minecraft:light[level=14]
fill 271 130 599 272 131 599 minecraft:yellow_concrete
fill 272 130 557 275 133 557 minecraft:orange_terracotta
fill 272 130 582 273 132 582 minecraft:gray_concrete
fill 276 130 557 277 131 557 minecraft:yellow_concrete
fill 277 130 564 277 130 565 minecraft:yellow_concrete
fill 277 130 568 277 131 568 minecraft:yellow_concrete
fill 277 130 572 277 133 575 minecraft:orange_terracotta
fill 277 130 576 277 131 577 minecraft:yellow_concrete
fill 277 130 580 277 130 584 minecraft:orange_terracotta
setblock 277 130 585 minecraft:yellow_concrete
fill 277 130 586 277 135 587 minecraft:orange_terracotta
fill 277 130 588 277 131 589 minecraft:yellow_concrete
fill 277 130 596 277 130 597 minecraft:yellow_concrete
fill 277 130 598 277 135 598 minecraft:orange_terracotta
fill 235 131 557 235 131 559 minecraft:orange_terracotta
setblock 235 131 560 minecraft:yellow_concrete
fill 235 131 561 235 131 562 minecraft:orange_terracotta
setblock 235 131 563 minecraft:yellow_concrete
fill 235 131 564 235 134 564 minecraft:orange_terracotta
setblock 235 131 570 minecraft:orange_terracotta
setblock 235 131 571 minecraft:yellow_concrete
fill 235 131 575 235 132 579 minecraft:orange_terracotta
setblock 235 131 580 minecraft:yellow_concrete
fill 235 131 581 235 131 582 minecraft:orange_terracotta
setblock 235 131 591 minecraft:yellow_concrete
setblock 235 131 595 minecraft:yellow_concrete
fill 235 131 596 235 134 596 minecraft:orange_terracotta
fill 236 131 557 237 131 557 minecraft:yellow_concrete
fill 236 131 578 238 131 578 minecraft:magma_block
fill 236 131 580 237 131 580 minecraft:magma_block
fill 241 131 584 245 131 584 minecraft:gray_concrete
fill 242 131 571 245 131 575 minecraft:gray_concrete
fill 242 131 583 245 131 583 minecraft:gray_concrete
fill 243 131 582 244 131 582 minecraft:gray_concrete
fill 243 131 599 243 133 599 minecraft:orange_terracotta
fill 244 131 570 250 131 570 minecraft:gray_concrete
fill 244 131 576 244 131 580 minecraft:gray_concrete
fill 245 131 576 245 131 577 minecraft:gray_concrete
fill 245 131 588 248 131 589 minecraft:gray_concrete
fill 246 131 571 246 131 574 minecraft:gray_concrete
fill 246 131 586 246 131 587 minecraft:gray_concrete
fill 247 131 572 247 131 573 minecraft:gray_concrete
setblock 247 131 587 minecraft:gray_concrete
fill 247 131 599 247 133 599 minecraft:orange_terracotta
setblock 248 131 572 minecraft:gray_concrete
setblock 248 131 599 minecraft:yellow_concrete
setblock 249 131 571 minecraft:gray_concrete
setblock 249 131 589 minecraft:gray_concrete
fill 249 131 599 250 131 599 minecraft:orange_terracotta
fill 250 131 590 250 131 594 minecraft:gray_concrete
fill 251 131 591 253 131 594 minecraft:gray_concrete
setblock 251 131 599 minecraft:yellow_concrete
fill 252 131 599 258 131 599 minecraft:orange_terracotta
fill 253 131 557 253 134 557 minecraft:orange_terracotta
setblock 254 131 592 minecraft:magma_block
fill 255 131 592 258 131 593 minecraft:gray_concrete
setblock 257 131 557 minecraft:yellow_concrete
fill 258 131 557 261 131 557 minecraft:orange_terracotta
setblock 258 131 568 minecraft:magma_block
setblock 259 131 599 minecraft:yellow_concrete
setblock 262 131 570 minecraft:gray_concrete
fill 262 131 590 268 131 590 minecraft:gray_concrete
fill 263 131 571 267 131 571 minecraft:gray_concrete
setblock 263 131 589 minecraft:gray_concrete
fill 263 131 599 263 134 599 minecraft:orange_terracotta
fill 264 131 557 264 134 557 minecraft:orange_terracotta
fill 264 131 572 272 131 572 minecraft:gray_concrete
fill 264 131 588 272 131 588 minecraft:gray_concrete
setblock 265 131 557 minecraft:yellow_concrete
fill 265 131 573 266 131 573 minecraft:gray_concrete
fill 265 131 587 272 131 587 minecraft:gray_concrete
fill 266 131 586 272 131 586 minecraft:gray_concrete
fill 267 131 576 270 131 577 minecraft:gray_concrete
fill 267 131 583 268 131 585 minecraft:gray_concrete
setblock 268 131 557 minecraft:yellow_concrete
fill 268 131 578 269 131 578 minecraft:gray_concrete
setblock 268 131 582 minecraft:gray_concrete
fill 269 131 585 272 132 585 minecraft:gray_concrete
fill 271 131 576 271 132 576 minecraft:gray_concrete
fill 277 131 564 277 134 565 minecraft:orange_terracotta
setblock 277 131 569 minecraft:yellow_concrete
setblock 277 131 580 minecraft:yellow_concrete
fill 277 131 581 277 132 585 minecraft:orange_terracotta
fill 277 131 596 277 134 596 minecraft:orange_terracotta
setblock 277 131 597 minecraft:yellow_concrete
fill 235 132 557 237 132 557 minecraft:orange_terracotta
fill 235 132 558 235 133 558 minecraft:yellow_concrete
fill 235 132 559 235 133 560 minecraft:orange_terracotta
fill 235 132 561 235 132 562 minecraft:yellow_concrete
fill 235 132 563 235 137 563 minecraft:orange_terracotta
fill 235 132 566 235 133 568 minecraft:orange_terracotta
fill 235 132 569 235 133 570 minecraft:yellow_concrete
fill 235 132 571 235 137 572 minecraft:orange_terracotta
fill 235 132 580 235 133 580 minecraft:orange_terracotta
fill 235 132 581 235 132 582 minecraft:yellow_concrete
fill 235 132 583 235 137 584 minecraft:orange_terracotta
fill 235 132 587 235 133 588 minecraft:orange_terracotta
fill 235 132 589 235 133 590 minecraft:yellow_concrete
fill 235 132 591 235 137 592 minecraft:orange_terracotta
setblock 235 132 593 minecraft:yellow_concrete
fill 235 132 594 235 134 595 minecraft:orange_terracotta
fill 236 132 558 238 132 558 minecraft:orange_concrete
fill 236 132 560 236 132 562 minecraft:orange_concrete
fill 236 132 564 236 132 566 minecraft:orange_concrete
fill 236 132 568 236 132 570 minecraft:orange_concrete
fill 236 132 572 236 132 574 minecraft:orange_concrete
fill 236 132 576 236 132 578 minecraft:orange_concrete
fill 236 132 580 236 132 582 minecraft:orange_concrete
fill 236 132 584 236 132 586 minecraft:orange_concrete
fill 236 132 588 236 132 590 minecraft:orange_concrete
fill 236 132 592 236 132 594 minecraft:orange_concrete
fill 236 132 596 236 132 598 minecraft:orange_concrete
setblock 237 132 578 minecraft:magma_block
setblock 237 132 580 minecraft:magma_block
fill 237 132 599 238 133 599 minecraft:yellow_concrete
fill 238 132 557 238 133 557 minecraft:yellow_concrete
fill 238 132 598 240 132 598 minecraft:orange_concrete
fill 239 132 557 245 132 557 minecraft:orange_terracotta
fill 239 132 599 240 137 599 minecraft:orange_terracotta
fill 240 132 558 242 132 558 minecraft:orange_concrete
fill 241 132 584 243 132 584 minecraft:gray_concrete
fill 242 132 571 243 132 575 minecraft:gray_concrete
fill 242 132 577 242 132 581 minecraft:gray_concrete
setblock 242 132 583 minecraft:gray_concrete
fill 242 132 598 244 132 598 minecraft:orange_concrete
fill 244 132 558 246 132 558 minecraft:orange_concrete
fill 244 132 570 244 132 573 minecraft:gray_concrete
fill 244 132 587 244 132 588 minecraft:gray_concrete
fill 244 132 590 247 132 592 minecraft:gray_concrete
fill 245 132 570 245 132 572 minecraft:gray_concrete
fill 245 132 588 245 132 589 minecraft:gray_concrete
fill 246 132 557 247 132 557 minecraft:yellow_concrete
fill 246 132 570 246 132 571 minecraft:gray_concrete
setblock 246 132 589 minecraft:gray_concrete
fill 246 132 598 248 132 598 minecraft:orange_concrete
fill 246 132 599 246 133 599 minecraft:yellow_concrete
fill 247 132 566 247 132 570 minecraft:gray_concrete
fill 248 132 557 249 133 557 minecraft:orange_terracotta
fill 248 132 558 250 132 558 minecraft:orange_concrete
fill 248 132 566 248 132 569 minecraft:gray_concrete
fill 248 132 591 248 132 592 minecraft:gray_concrete
fill 248 132 599 248 137 599 minecraft:orange_terracotta
fill 249 132 566 249 132 568 minecraft:gray_concrete
fill 249 132 592 249 132 594 minecraft:magma_block
fill 249 132 599 250 132 599 minecraft:yellow_concrete
fill 250 132 566 250 132 567 minecraft:gray_concrete
fill 250 132 593 252 132 594 minecraft:gray_concrete
fill 250 132 598 252 132 598 minecraft:orange_concrete
fill 251 132 599 256 133 599 minecraft:orange_terracotta
fill 252 132 558 254 132 558 minecraft:orange_concrete
setblock 252 132 567 minecraft:gray_concrete
fill 253 132 594 254 132 594 minecraft:gray_concrete
fill 254 132 598 255 132 598 minecraft:orange_concrete
fill 256 132 557 257 137 557 minecraft:orange_terracotta
fill 256 132 558 258 132 558 minecraft:orange_concrete
fill 257 132 599 258 133 599 minecraft:yellow_concrete
fill 258 132 557 259 133 557 minecraft:yellow_concrete
fill 258 132 598 260 132 598 minecraft:orange_concrete
fill 259 132 599 260 137 599 minecraft:orange_terracotta
fill 260 132 557 261 133 557 minecraft:orange_terracotta
schedule function dropper:buildpart/137_2 1t
