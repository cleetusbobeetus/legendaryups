setblock 57 196 339 minecraft:light[level=12]
setblock 57 196 346 minecraft:light[level=12]
setblock 57 196 353 minecraft:light[level=12]
setblock 57 196 356 minecraft:shroomlight
fill 57 196 357 57 213 357 minecraft:stripped_dark_oak_log
setblock 57 196 358 minecraft:shroomlight
fill 57 196 359 57 213 359 minecraft:stripped_dark_oak_log
setblock 57 196 360 minecraft:shroomlight
fill 57 196 361 57 213 361 minecraft:stripped_dark_oak_log
setblock 57 196 362 minecraft:shroomlight
fill 57 196 363 57 213 363 minecraft:stripped_dark_oak_log
fill 58 196 356 58 213 356 minecraft:stripped_dark_oak_log
setblock 58 196 357 minecraft:shroomlight
fill 58 196 358 58 213 358 minecraft:stripped_dark_oak_log
setblock 58 196 359 minecraft:shroomlight
fill 58 196 360 58 213 360 minecraft:stripped_dark_oak_log
setblock 58 196 361 minecraft:shroomlight
fill 58 196 362 58 213 362 minecraft:stripped_dark_oak_log
setblock 58 196 363 minecraft:shroomlight
setblock 59 196 356 minecraft:shroomlight
fill 59 196 357 59 213 357 minecraft:stripped_dark_oak_log
setblock 59 196 358 minecraft:shroomlight
fill 59 196 359 59 213 359 minecraft:stripped_dark_oak_log
setblock 59 196 360 minecraft:shroomlight
fill 59 196 361 59 213 361 minecraft:stripped_dark_oak_log
setblock 59 196 362 minecraft:shroomlight
fill 60 196 333 61 198 333 minecraft:stripped_dark_oak_log
fill 60 196 356 60 213 356 minecraft:stripped_dark_oak_log
setblock 60 196 357 minecraft:shroomlight
fill 60 196 358 60 213 358 minecraft:stripped_dark_oak_log
setblock 60 196 359 minecraft:shroomlight
fill 60 196 360 60 213 360 minecraft:stripped_dark_oak_log
setblock 60 196 361 minecraft:shroomlight
fill 60 196 362 60 213 362 minecraft:stripped_dark_oak_log
setblock 60 196 363 minecraft:shroomlight
setblock 61 196 356 minecraft:shroomlight
fill 61 196 357 61 213 357 minecraft:stripped_dark_oak_log
setblock 61 196 358 minecraft:shroomlight
fill 61 196 359 61 213 359 minecraft:stripped_dark_oak_log
setblock 61 196 360 minecraft:shroomlight
fill 61 196 361 61 213 361 minecraft:stripped_dark_oak_log
setblock 61 196 362 minecraft:shroomlight
fill 61 196 363 61 213 363 minecraft:stripped_dark_oak_log
setblock 64 196 325 minecraft:light[level=12]
setblock 64 196 332 minecraft:light[level=12]
setblock 64 196 339 minecraft:light[level=12]
setblock 64 196 346 minecraft:light[level=12]
setblock 64 196 353 minecraft:light[level=12]
setblock 64 196 360 minecraft:light[level=12]
setblock 71 196 325 minecraft:light[level=12]
setblock 71 196 332 minecraft:light[level=12]
setblock 71 196 339 minecraft:light[level=12]
setblock 71 196 346 minecraft:light[level=12]
setblock 71 196 353 minecraft:light[level=12]
setblock 71 196 360 minecraft:light[level=12]
fill 74 196 333 75 198 333 minecraft:stripped_dark_oak_log
fill 75 196 332 78 196 332 minecraft:stripped_dark_oak_log
fill 75 196 334 78 196 334 minecraft:stripped_dark_oak_log
setblock 78 196 325 minecraft:light[level=12]
setblock 78 196 339 minecraft:light[level=12]
setblock 78 196 346 minecraft:light[level=12]
setblock 78 196 353 minecraft:light[level=12]
setblock 78 196 360 minecraft:light[level=12]
setblock 80 196 333 minecraft:red_concrete
setblock 85 196 325 minecraft:light[level=12]
setblock 85 196 332 minecraft:light[level=12]
setblock 85 196 339 minecraft:light[level=12]
setblock 85 196 346 minecraft:light[level=12]
setblock 85 196 353 minecraft:light[level=12]
fill 89 196 330 89 224 330 minecraft:spruce_planks
fill 89 196 336 89 226 336 minecraft:spruce_planks
setblock 48 197 329 minecraft:stripped_dark_oak_log
setblock 48 197 336 minecraft:stripped_dark_oak_log
setblock 48 197 343 minecraft:stripped_dark_oak_log
setblock 48 197 350 minecraft:stripped_dark_oak_log
setblock 48 197 357 minecraft:stripped_dark_oak_log
setblock 49 197 323 minecraft:stripped_dark_oak_log
setblock 49 197 363 minecraft:stripped_dark_oak_log
fill 53 197 364 53 224 364 minecraft:spruce_planks
fill 55 197 356 55 198 356 minecraft:stripped_dark_oak_log
fill 55 197 358 55 198 358 minecraft:stripped_dark_oak_log
fill 55 197 360 55 198 360 minecraft:stripped_dark_oak_log
fill 55 197 362 55 198 362 minecraft:stripped_dark_oak_log
setblock 56 197 323 minecraft:stripped_dark_oak_log
fill 56 197 357 56 198 357 minecraft:stripped_dark_oak_log
fill 56 197 359 56 198 359 minecraft:stripped_dark_oak_log
fill 56 197 361 56 198 361 minecraft:stripped_dark_oak_log
fill 56 197 363 56 198 363 minecraft:stripped_dark_oak_log
setblock 57 197 333 minecraft:red_concrete
fill 57 197 356 57 198 356 minecraft:stripped_dark_oak_log
fill 57 197 358 57 198 358 minecraft:stripped_dark_oak_log
fill 57 197 360 57 198 360 minecraft:stripped_dark_oak_log
fill 57 197 362 57 198 362 minecraft:stripped_dark_oak_log
fill 58 197 357 58 198 357 minecraft:stripped_dark_oak_log
fill 58 197 359 58 198 359 minecraft:stripped_dark_oak_log
fill 58 197 361 58 198 361 minecraft:stripped_dark_oak_log
fill 58 197 363 58 198 363 minecraft:stripped_dark_oak_log
fill 59 197 332 63 197 332 minecraft:stripped_dark_oak_log
fill 59 197 334 63 197 334 minecraft:stripped_dark_oak_log
fill 59 197 356 59 198 356 minecraft:stripped_dark_oak_log
fill 59 197 358 59 198 358 minecraft:stripped_dark_oak_log
fill 59 197 360 59 198 360 minecraft:stripped_dark_oak_log
fill 59 197 362 59 198 362 minecraft:stripped_dark_oak_log
fill 60 197 357 60 198 357 minecraft:stripped_dark_oak_log
fill 60 197 359 60 198 359 minecraft:stripped_dark_oak_log
fill 60 197 361 60 198 361 minecraft:stripped_dark_oak_log
fill 60 197 363 60 198 363 minecraft:stripped_dark_oak_log
fill 61 197 356 61 198 356 minecraft:stripped_dark_oak_log
fill 61 197 358 61 198 358 minecraft:stripped_dark_oak_log
fill 61 197 360 61 198 360 minecraft:stripped_dark_oak_log
fill 61 197 362 61 198 362 minecraft:stripped_dark_oak_log
fill 62 197 333 65 198 333 minecraft:stripped_dark_oak_log
setblock 63 197 323 minecraft:stripped_dark_oak_log
setblock 63 197 363 minecraft:stripped_dark_oak_log
setblock 70 197 323 minecraft:stripped_dark_oak_log
fill 70 197 333 73 198 333 minecraft:stripped_dark_oak_log
setblock 70 197 363 minecraft:stripped_dark_oak_log
fill 72 197 332 76 197 332 minecraft:stripped_dark_oak_log
fill 72 197 334 76 197 334 minecraft:stripped_dark_oak_log
setblock 77 197 323 minecraft:stripped_dark_oak_log
setblock 77 197 363 minecraft:stripped_dark_oak_log
setblock 78 197 333 minecraft:red_concrete
setblock 84 197 323 minecraft:stripped_dark_oak_log
setblock 84 197 363 minecraft:stripped_dark_oak_log
setblock 88 197 326 minecraft:stripped_dark_oak_log
setblock 88 197 333 minecraft:stripped_dark_oak_log
setblock 88 197 340 minecraft:stripped_dark_oak_log
setblock 88 197 347 minecraft:stripped_dark_oak_log
setblock 88 197 354 minecraft:stripped_dark_oak_log
setblock 88 197 361 minecraft:stripped_dark_oak_log
setblock 48 198 323 minecraft:stripped_dark_oak_log
setblock 48 198 330 minecraft:stripped_dark_oak_log
setblock 48 198 337 minecraft:stripped_dark_oak_log
setblock 48 198 344 minecraft:stripped_dark_oak_log
setblock 48 198 351 minecraft:stripped_dark_oak_log
setblock 48 198 358 minecraft:stripped_dark_oak_log
setblock 50 198 363 minecraft:stripped_dark_oak_log
setblock 55 198 323 minecraft:stripped_dark_oak_log
fill 58 198 333 59 198 333 minecraft:red_concrete
setblock 62 198 323 minecraft:stripped_dark_oak_log
fill 62 198 332 73 198 332 minecraft:stripped_dark_oak_log
fill 62 198 334 73 198 334 minecraft:stripped_dark_oak_log
setblock 64 198 363 minecraft:stripped_dark_oak_log
fill 66 198 333 69 199 333 minecraft:stripped_dark_oak_log
fill 66 198 360 66 199 362 minecraft:iron_bars
setblock 69 198 323 minecraft:stripped_dark_oak_log
setblock 71 198 363 minecraft:stripped_dark_oak_log
setblock 76 198 323 minecraft:stripped_dark_oak_log
fill 76 198 333 77 198 333 minecraft:red_concrete
setblock 78 198 363 minecraft:stripped_dark_oak_log
setblock 83 198 323 minecraft:stripped_dark_oak_log
setblock 85 198 363 minecraft:stripped_dark_oak_log
setblock 88 198 325 minecraft:stripped_dark_oak_log
setblock 88 198 332 minecraft:stripped_dark_oak_log
setblock 88 198 339 minecraft:stripped_dark_oak_log
setblock 88 198 346 minecraft:stripped_dark_oak_log
setblock 88 198 353 minecraft:stripped_dark_oak_log
setblock 88 198 360 minecraft:stripped_dark_oak_log
fill 47 199 352 47 208 353 minecraft:spruce_planks
setblock 47 199 354 minecraft:red_concrete
fill 48 199 324 48 200 324 minecraft:stripped_dark_oak_log
fill 48 199 331 48 200 331 minecraft:stripped_dark_oak_log
fill 48 199 338 48 200 338 minecraft:stripped_dark_oak_log
fill 48 199 345 48 200 345 minecraft:stripped_dark_oak_log
fill 48 199 352 48 200 352 minecraft:stripped_dark_oak_log
fill 48 199 359 48 200 359 minecraft:stripped_dark_oak_log
fill 51 199 363 51 200 363 minecraft:stripped_dark_oak_log
fill 54 199 323 54 200 323 minecraft:stripped_dark_oak_log
setblock 55 199 356 minecraft:shroomlight
setblock 55 199 358 minecraft:shroomlight
setblock 55 199 360 minecraft:shroomlight
setblock 55 199 362 minecraft:shroomlight
setblock 56 199 357 minecraft:shroomlight
setblock 56 199 359 minecraft:shroomlight
setblock 56 199 361 minecraft:shroomlight
setblock 56 199 363 minecraft:shroomlight
setblock 57 199 356 minecraft:shroomlight
setblock 57 199 358 minecraft:shroomlight
setblock 57 199 360 minecraft:shroomlight
setblock 57 199 362 minecraft:shroomlight
setblock 58 199 357 minecraft:shroomlight
setblock 58 199 359 minecraft:shroomlight
setblock 58 199 361 minecraft:shroomlight
setblock 58 199 363 minecraft:shroomlight
setblock 59 199 356 minecraft:shroomlight
setblock 59 199 358 minecraft:shroomlight
setblock 59 199 360 minecraft:shroomlight
setblock 59 199 362 minecraft:shroomlight
fill 60 199 333 62 199 333 minecraft:red_concrete
setblock 60 199 357 minecraft:shroomlight
setblock 60 199 359 minecraft:shroomlight
setblock 60 199 361 minecraft:shroomlight
setblock 60 199 363 minecraft:shroomlight
fill 61 199 323 61 200 323 minecraft:stripped_dark_oak_log
setblock 61 199 356 minecraft:shroomlight
setblock 61 199 358 minecraft:shroomlight
setblock 61 199 360 minecraft:shroomlight
setblock 61 199 362 minecraft:shroomlight
fill 63 199 333 65 199 333 minecraft:stripped_dark_oak_log
fill 65 199 332 70 199 332 minecraft:stripped_dark_oak_log
fill 65 199 334 70 199 334 minecraft:stripped_dark_oak_log
fill 65 199 363 65 200 363 minecraft:stripped_dark_oak_log
fill 68 199 323 68 200 323 minecraft:stripped_dark_oak_log
fill 70 199 333 72 199 333 minecraft:stripped_dark_oak_log
fill 72 199 363 72 200 363 minecraft:stripped_dark_oak_log
fill 73 199 333 75 199 333 minecraft:red_concrete
fill 75 199 323 75 200 323 minecraft:stripped_dark_oak_log
fill 79 199 363 79 200 363 minecraft:stripped_dark_oak_log
fill 82 199 323 82 200 323 minecraft:stripped_dark_oak_log
fill 86 199 363 86 200 363 minecraft:stripped_dark_oak_log
fill 88 199 324 88 200 324 minecraft:stripped_dark_oak_log
fill 88 199 331 88 200 331 minecraft:stripped_dark_oak_log
fill 88 199 338 88 200 338 minecraft:stripped_dark_oak_log
fill 88 199 345 88 200 345 minecraft:stripped_dark_oak_log
fill 88 199 352 88 200 352 minecraft:stripped_dark_oak_log
fill 88 199 359 88 200 359 minecraft:stripped_dark_oak_log
fill 47 200 354 47 226 354 minecraft:spruce_planks
fill 48 200 323 49 200 323 minecraft:stripped_dark_oak_log
fill 48 200 325 48 200 327 minecraft:stripped_dark_oak_log
fill 48 200 329 48 200 330 minecraft:stripped_dark_oak_log
fill 48 200 332 48 200 334 minecraft:stripped_dark_oak_log
fill 48 200 336 48 200 337 minecraft:stripped_dark_oak_log
fill 48 200 339 48 200 341 minecraft:stripped_dark_oak_log
fill 48 200 343 48 200 344 minecraft:stripped_dark_oak_log
fill 48 200 346 48 200 348 minecraft:stripped_dark_oak_log
fill 48 200 350 48 200 351 minecraft:stripped_dark_oak_log
fill 48 200 353 48 200 355 minecraft:stripped_dark_oak_log
fill 48 200 357 48 200 358 minecraft:stripped_dark_oak_log
fill 48 200 360 48 200 362 minecraft:stripped_dark_oak_log
fill 49 200 363 50 200 363 minecraft:stripped_dark_oak_log
setblock 50 200 325 minecraft:light[level=15]
setblock 50 200 333 minecraft:light[level=15]
setblock 50 200 341 minecraft:light[level=15]
setblock 50 200 349 minecraft:light[level=15]
setblock 50 200 357 minecraft:light[level=15]
fill 51 200 323 53 200 323 minecraft:stripped_dark_oak_log
fill 52 200 363 54 200 363 minecraft:stripped_dark_oak_log
fill 55 200 323 56 200 323 minecraft:stripped_dark_oak_log
fill 55 200 356 55 201 356 minecraft:stripped_dark_oak_log
fill 55 200 358 55 201 358 minecraft:stripped_dark_oak_log
fill 55 200 360 55 201 360 minecraft:stripped_dark_oak_log
fill 55 200 362 55 201 362 minecraft:stripped_dark_oak_log
fill 56 200 357 56 201 357 minecraft:stripped_dark_oak_log
fill 56 200 359 56 201 359 minecraft:stripped_dark_oak_log
fill 56 200 361 56 201 361 minecraft:stripped_dark_oak_log
fill 56 200 363 56 201 363 minecraft:stripped_dark_oak_log
fill 57 200 356 57 201 356 minecraft:stripped_dark_oak_log
fill 57 200 358 57 201 358 minecraft:stripped_dark_oak_log
fill 57 200 360 57 201 360 minecraft:stripped_dark_oak_log
fill 57 200 362 57 201 362 minecraft:stripped_dark_oak_log
fill 58 200 323 60 200 323 minecraft:stripped_dark_oak_log
setblock 58 200 325 minecraft:light[level=15]
setblock 58 200 333 minecraft:light[level=15]
setblock 58 200 341 minecraft:light[level=15]
setblock 58 200 349 minecraft:light[level=15]
fill 58 200 357 58 201 357 minecraft:stripped_dark_oak_log
fill 58 200 359 58 201 359 minecraft:stripped_dark_oak_log
fill 58 200 361 58 201 361 minecraft:stripped_dark_oak_log
fill 58 200 363 58 201 363 minecraft:stripped_dark_oak_log
fill 59 200 356 59 201 356 minecraft:stripped_dark_oak_log
fill 59 200 358 59 201 358 minecraft:stripped_dark_oak_log
fill 59 200 360 59 201 360 minecraft:stripped_dark_oak_log
fill 59 200 362 59 201 362 minecraft:stripped_dark_oak_log
fill 60 200 357 60 201 357 minecraft:stripped_dark_oak_log
fill 60 200 359 60 201 359 minecraft:stripped_dark_oak_log
fill 60 200 361 60 201 361 minecraft:stripped_dark_oak_log
fill 60 200 363 60 201 363 minecraft:stripped_dark_oak_log
fill 61 200 356 61 201 356 minecraft:stripped_dark_oak_log
fill 61 200 358 61 201 358 minecraft:stripped_dark_oak_log
fill 61 200 360 61 201 360 minecraft:stripped_dark_oak_log
fill 61 200 362 61 201 362 minecraft:stripped_dark_oak_log
fill 62 200 323 63 200 323 minecraft:stripped_dark_oak_log
fill 63 200 363 64 200 363 minecraft:stripped_dark_oak_log
fill 64 200 333 71 200 333 minecraft:red_concrete
fill 65 200 323 67 200 323 minecraft:stripped_dark_oak_log
setblock 66 200 325 minecraft:light[level=15]
setblock 66 200 341 minecraft:light[level=15]
setblock 66 200 349 minecraft:light[level=15]
setblock 66 200 357 minecraft:light[level=15]
fill 66 200 363 68 200 363 minecraft:stripped_dark_oak_log
fill 69 200 323 70 200 323 minecraft:stripped_dark_oak_log
fill 70 200 363 71 200 363 minecraft:stripped_dark_oak_log
fill 72 200 323 74 200 323 minecraft:stripped_dark_oak_log
fill 73 200 363 75 200 363 minecraft:stripped_dark_oak_log
setblock 74 200 325 minecraft:light[level=15]
setblock 74 200 333 minecraft:light[level=15]
setblock 74 200 341 minecraft:light[level=15]
setblock 74 200 349 minecraft:light[level=15]
setblock 74 200 357 minecraft:light[level=15]
fill 76 200 323 77 200 323 minecraft:stripped_dark_oak_log
fill 77 200 363 78 200 363 minecraft:stripped_dark_oak_log
fill 79 200 323 81 200 323 minecraft:stripped_dark_oak_log
fill 80 200 363 82 200 363 minecraft:stripped_dark_oak_log
setblock 82 200 325 minecraft:light[level=15]
setblock 82 200 333 minecraft:light[level=15]
setblock 82 200 341 minecraft:light[level=15]
setblock 82 200 349 minecraft:light[level=15]
setblock 82 200 357 minecraft:light[level=15]
fill 83 200 323 84 200 323 minecraft:stripped_dark_oak_log
fill 84 200 363 85 200 363 minecraft:stripped_dark_oak_log
fill 85 200 340 87 201 340 minecraft:iron_bars
fill 86 200 323 88 200 323 minecraft:stripped_dark_oak_log
fill 87 200 363 88 200 363 minecraft:stripped_dark_oak_log
fill 88 200 325 88 200 326 minecraft:stripped_dark_oak_log
fill 88 200 328 88 200 330 minecraft:stripped_dark_oak_log
fill 88 200 332 88 200 333 minecraft:stripped_dark_oak_log
fill 88 200 335 88 200 337 minecraft:stripped_dark_oak_log
fill 88 200 339 88 200 340 minecraft:stripped_dark_oak_log
fill 88 200 342 88 200 344 minecraft:stripped_dark_oak_log
fill 88 200 346 88 200 347 minecraft:stripped_dark_oak_log
fill 88 200 349 88 200 351 minecraft:stripped_dark_oak_log
fill 88 200 353 88 200 354 minecraft:stripped_dark_oak_log
fill 88 200 356 88 200 358 minecraft:stripped_dark_oak_log
fill 88 200 360 88 200 361 minecraft:stripped_dark_oak_log
setblock 48 201 326 minecraft:stripped_dark_oak_log
setblock 48 201 333 minecraft:stripped_dark_oak_log
setblock 48 201 340 minecraft:stripped_dark_oak_log
setblock 48 201 347 minecraft:stripped_dark_oak_log
setblock 48 201 354 minecraft:stripped_dark_oak_log
setblock 48 201 361 minecraft:stripped_dark_oak_log
setblock 52 201 323 minecraft:stripped_dark_oak_log
setblock 53 201 363 minecraft:stripped_dark_oak_log
setblock 59 201 323 minecraft:stripped_dark_oak_log
setblock 66 201 323 minecraft:stripped_dark_oak_log
setblock 67 201 363 minecraft:stripped_dark_oak_log
setblock 73 201 323 minecraft:stripped_dark_oak_log
setblock 74 201 363 minecraft:stripped_dark_oak_log
setblock 80 201 323 minecraft:stripped_dark_oak_log
fill 81 201 359 81 201 361 minecraft:dark_oak_planks
setblock 81 201 363 minecraft:stripped_dark_oak_log
fill 82 201 358 85 201 358 minecraft:dark_oak_planks
fill 82 201 362 84 201 362 minecraft:dark_oak_planks
setblock 85 201 359 minecraft:dark_oak_planks
setblock 85 201 361 minecraft:dark_oak_planks
setblock 87 201 323 minecraft:stripped_dark_oak_log
setblock 88 201 329 minecraft:stripped_dark_oak_log
setblock 88 201 336 minecraft:stripped_dark_oak_log
setblock 88 201 343 minecraft:stripped_dark_oak_log
setblock 88 201 350 minecraft:stripped_dark_oak_log
setblock 88 201 357 minecraft:stripped_dark_oak_log
setblock 88 201 363 minecraft:stripped_dark_oak_log
setblock 48 202 327 minecraft:stripped_dark_oak_log
setblock 48 202 334 minecraft:stripped_dark_oak_log
setblock 48 202 341 minecraft:stripped_dark_oak_log
setblock 48 202 348 minecraft:stripped_dark_oak_log
setblock 48 202 355 minecraft:stripped_dark_oak_log
setblock 48 202 362 minecraft:stripped_dark_oak_log
setblock 50 202 325 minecraft:light[level=12]
setblock 50 202 332 minecraft:light[level=12]
setblock 50 202 339 minecraft:light[level=12]
setblock 50 202 346 minecraft:light[level=12]
setblock 50 202 353 minecraft:light[level=12]
setblock 50 202 360 minecraft:light[level=12]
setblock 51 202 323 minecraft:stripped_dark_oak_log
setblock 54 202 363 minecraft:stripped_dark_oak_log
setblock 55 202 356 minecraft:shroomlight
setblock 55 202 358 minecraft:shroomlight
setblock 55 202 360 minecraft:shroomlight
setblock 55 202 362 minecraft:shroomlight
setblock 56 202 357 minecraft:shroomlight
setblock 56 202 359 minecraft:shroomlight
setblock 56 202 361 minecraft:shroomlight
setblock 56 202 363 minecraft:shroomlight
setblock 57 202 325 minecraft:light[level=12]
setblock 57 202 332 minecraft:light[level=12]
setblock 57 202 339 minecraft:light[level=12]
setblock 57 202 346 minecraft:light[level=12]
setblock 57 202 353 minecraft:light[level=12]
setblock 57 202 356 minecraft:shroomlight
setblock 57 202 358 minecraft:shroomlight
setblock 57 202 360 minecraft:shroomlight
setblock 57 202 362 minecraft:shroomlight
setblock 58 202 323 minecraft:stripped_dark_oak_log
setblock 58 202 357 minecraft:shroomlight
setblock 58 202 359 minecraft:shroomlight
setblock 58 202 361 minecraft:shroomlight
setblock 58 202 363 minecraft:shroomlight
setblock 59 202 356 minecraft:shroomlight
setblock 59 202 358 minecraft:shroomlight
setblock 59 202 360 minecraft:shroomlight
setblock 59 202 362 minecraft:shroomlight
setblock 60 202 357 minecraft:shroomlight
setblock 60 202 359 minecraft:shroomlight
setblock 60 202 361 minecraft:shroomlight
setblock 60 202 363 minecraft:shroomlight
setblock 61 202 356 minecraft:shroomlight
setblock 61 202 358 minecraft:shroomlight
setblock 61 202 360 minecraft:shroomlight
setblock 61 202 362 minecraft:shroomlight
setblock 64 202 325 minecraft:light[level=12]
setblock 64 202 332 minecraft:light[level=12]
setblock 64 202 339 minecraft:light[level=12]
setblock 64 202 346 minecraft:light[level=12]
setblock 64 202 353 minecraft:light[level=12]
setblock 64 202 360 minecraft:light[level=12]
setblock 65 202 323 minecraft:stripped_dark_oak_log
setblock 68 202 363 minecraft:stripped_dark_oak_log
setblock 71 202 325 minecraft:light[level=12]
setblock 71 202 332 minecraft:light[level=12]
setblock 71 202 339 minecraft:light[level=12]
setblock 71 202 346 minecraft:light[level=12]
setblock 71 202 353 minecraft:light[level=12]
setblock 71 202 360 minecraft:light[level=12]
setblock 72 202 323 minecraft:stripped_dark_oak_log
setblock 75 202 363 minecraft:stripped_dark_oak_log
setblock 78 202 325 minecraft:light[level=12]
setblock 78 202 332 minecraft:light[level=12]
setblock 78 202 339 minecraft:light[level=12]
setblock 78 202 346 minecraft:light[level=12]
setblock 78 202 353 minecraft:light[level=12]
setblock 78 202 360 minecraft:light[level=12]
setblock 79 202 323 minecraft:stripped_dark_oak_log
setblock 82 202 363 minecraft:stripped_dark_oak_log
setblock 85 202 325 minecraft:light[level=12]
setblock 85 202 332 minecraft:light[level=12]
setblock 85 202 339 minecraft:light[level=12]
setblock 85 202 346 minecraft:light[level=12]
setblock 85 202 353 minecraft:light[level=12]
setblock 86 202 323 minecraft:stripped_dark_oak_log
setblock 88 202 328 minecraft:stripped_dark_oak_log
setblock 88 202 335 minecraft:stripped_dark_oak_log
setblock 88 202 342 minecraft:stripped_dark_oak_log
setblock 88 202 349 minecraft:stripped_dark_oak_log
setblock 88 202 356 minecraft:stripped_dark_oak_log
setblock 89 202 332 minecraft:red_concrete
fill 52 203 322 52 226 322 minecraft:spruce_planks
setblock 53 203 322 minecraft:red_concrete
fill 55 203 356 55 204 356 minecraft:stripped_dark_oak_log
fill 55 203 358 55 204 358 minecraft:stripped_dark_oak_log
fill 55 203 360 55 204 360 minecraft:stripped_dark_oak_log
fill 55 203 362 55 204 362 minecraft:stripped_dark_oak_log
fill 56 203 357 56 204 357 minecraft:stripped_dark_oak_log
fill 56 203 359 56 204 359 minecraft:stripped_dark_oak_log
fill 56 203 361 56 204 361 minecraft:stripped_dark_oak_log
fill 56 203 363 56 204 363 minecraft:stripped_dark_oak_log
fill 57 203 356 57 204 356 minecraft:stripped_dark_oak_log
fill 57 203 358 57 204 358 minecraft:stripped_dark_oak_log
fill 57 203 360 57 204 360 minecraft:stripped_dark_oak_log
fill 57 203 362 57 204 362 minecraft:stripped_dark_oak_log
fill 58 203 357 58 204 357 minecraft:stripped_dark_oak_log
fill 58 203 359 58 204 359 minecraft:stripped_dark_oak_log
fill 58 203 361 58 204 361 minecraft:stripped_dark_oak_log
fill 58 203 363 58 204 363 minecraft:stripped_dark_oak_log
fill 59 203 331 61 206 332 minecraft:cherry_leaves[persistent=true]
fill 59 203 356 59 204 356 minecraft:stripped_dark_oak_log
fill 59 203 358 59 204 358 minecraft:stripped_dark_oak_log
fill 59 203 360 59 204 360 minecraft:stripped_dark_oak_log
fill 59 203 362 59 204 362 minecraft:stripped_dark_oak_log
fill 60 203 330 61 206 330 minecraft:cherry_leaves[persistent=true]
fill 60 203 357 60 204 357 minecraft:stripped_dark_oak_log
fill 60 203 359 60 204 359 minecraft:stripped_dark_oak_log
fill 60 203 361 60 204 361 minecraft:stripped_dark_oak_log
fill 60 203 363 60 204 363 minecraft:stripped_dark_oak_log
fill 61 203 356 61 204 356 minecraft:stripped_dark_oak_log
fill 61 203 358 61 204 358 minecraft:stripped_dark_oak_log
fill 61 203 360 61 204 360 minecraft:stripped_dark_oak_log
fill 61 203 362 61 204 362 minecraft:stripped_dark_oak_log
setblock 69 203 322 minecraft:red_concrete
fill 89 203 332 89 226 332 minecraft:spruce_planks
setblock 48 204 329 minecraft:stripped_dark_oak_log
setblock 48 204 336 minecraft:stripped_dark_oak_log
setblock 48 204 343 minecraft:stripped_dark_oak_log
setblock 48 204 350 minecraft:stripped_dark_oak_log
setblock 48 204 357 minecraft:stripped_dark_oak_log
setblock 49 204 323 minecraft:stripped_dark_oak_log
setblock 49 204 363 minecraft:stripped_dark_oak_log
fill 53 204 322 53 226 322 minecraft:spruce_planks
setblock 56 204 323 minecraft:stripped_dark_oak_log
fill 59 204 330 59 206 330 minecraft:cherry_leaves[persistent=true]
fill 60 204 329 61 205 329 minecraft:cherry_leaves[persistent=true]
fill 60 204 333 61 205 333 minecraft:cherry_leaves[persistent=true]
setblock 63 204 323 minecraft:stripped_dark_oak_log
setblock 63 204 363 minecraft:stripped_dark_oak_log
fill 69 204 322 69 224 322 minecraft:spruce_planks
setblock 70 204 323 minecraft:stripped_dark_oak_log
setblock 70 204 363 minecraft:stripped_dark_oak_log
setblock 77 204 323 minecraft:stripped_dark_oak_log
setblock 77 204 363 minecraft:stripped_dark_oak_log
setblock 84 204 323 minecraft:stripped_dark_oak_log
setblock 84 204 363 minecraft:stripped_dark_oak_log
setblock 88 204 326 minecraft:stripped_dark_oak_log
setblock 88 204 333 minecraft:stripped_dark_oak_log
setblock 88 204 340 minecraft:stripped_dark_oak_log
setblock 88 204 347 minecraft:stripped_dark_oak_log
setblock 88 204 354 minecraft:stripped_dark_oak_log
setblock 88 204 361 minecraft:stripped_dark_oak_log
setblock 48 205 323 minecraft:stripped_dark_oak_log
setblock 48 205 330 minecraft:stripped_dark_oak_log
setblock 48 205 337 minecraft:stripped_dark_oak_log
setblock 48 205 344 minecraft:stripped_dark_oak_log
setblock 48 205 351 minecraft:stripped_dark_oak_log
setblock 48 205 358 minecraft:stripped_dark_oak_log
setblock 50 205 363 minecraft:stripped_dark_oak_log
setblock 55 205 323 minecraft:stripped_dark_oak_log
setblock 55 205 356 minecraft:shroomlight
setblock 55 205 358 minecraft:shroomlight
setblock 55 205 360 minecraft:shroomlight
setblock 55 205 362 minecraft:shroomlight
setblock 56 205 357 minecraft:shroomlight
setblock 56 205 359 minecraft:shroomlight
setblock 56 205 361 minecraft:shroomlight
setblock 56 205 363 minecraft:shroomlight
setblock 57 205 356 minecraft:shroomlight
setblock 57 205 358 minecraft:shroomlight
setblock 57 205 360 minecraft:shroomlight
setblock 57 205 362 minecraft:shroomlight
setblock 58 205 331 minecraft:cherry_leaves[persistent=true]
setblock 58 205 357 minecraft:shroomlight
setblock 58 205 359 minecraft:shroomlight
setblock 58 205 361 minecraft:shroomlight
setblock 58 205 363 minecraft:shroomlight
setblock 59 205 356 minecraft:shroomlight
setblock 59 205 358 minecraft:shroomlight
setblock 59 205 360 minecraft:shroomlight
setblock 59 205 362 minecraft:shroomlight
setblock 60 205 357 minecraft:shroomlight
setblock 60 205 359 minecraft:shroomlight
setblock 60 205 361 minecraft:shroomlight
setblock 60 205 363 minecraft:shroomlight
fill 61 205 322 62 226 322 minecraft:spruce_planks
setblock 61 205 356 minecraft:shroomlight
setblock 61 205 358 minecraft:shroomlight
setblock 61 205 360 minecraft:shroomlight
setblock 61 205 362 minecraft:shroomlight
setblock 62 205 323 minecraft:stripped_dark_oak_log
setblock 63 205 322 minecraft:red_concrete
fill 64 205 322 68 223 322 minecraft:spruce_planks
setblock 64 205 363 minecraft:stripped_dark_oak_log
setblock 69 205 323 minecraft:stripped_dark_oak_log
setblock 71 205 363 minecraft:stripped_dark_oak_log
setblock 76 205 323 minecraft:stripped_dark_oak_log
setblock 78 205 363 minecraft:stripped_dark_oak_log
setblock 83 205 323 minecraft:stripped_dark_oak_log
setblock 85 205 363 minecraft:stripped_dark_oak_log
setblock 88 205 325 minecraft:stripped_dark_oak_log
setblock 88 205 332 minecraft:stripped_dark_oak_log
setblock 88 205 339 minecraft:stripped_dark_oak_log
setblock 88 205 346 minecraft:stripped_dark_oak_log
setblock 88 205 353 minecraft:stripped_dark_oak_log
setblock 88 205 360 minecraft:stripped_dark_oak_log
fill 47 206 328 47 226 328 minecraft:spruce_planks
setblock 47 206 329 minecraft:red_concrete
setblock 48 206 324 minecraft:stripped_dark_oak_log
setblock 48 206 331 minecraft:stripped_dark_oak_log
setblock 48 206 338 minecraft:stripped_dark_oak_log
setblock 48 206 345 minecraft:stripped_dark_oak_log
setblock 48 206 352 minecraft:stripped_dark_oak_log
setblock 48 206 359 minecraft:stripped_dark_oak_log
setblock 51 206 363 minecraft:stripped_dark_oak_log
fill 54 206 322 54 226 322 minecraft:spruce_planks
setblock 54 206 323 minecraft:stripped_dark_oak_log
setblock 55 206 322 minecraft:red_concrete
fill 55 206 356 55 207 356 minecraft:stripped_dark_oak_log
fill 55 206 358 55 207 358 minecraft:stripped_dark_oak_log
fill 55 206 360 55 207 360 minecraft:stripped_dark_oak_log
fill 55 206 362 55 207 362 minecraft:stripped_dark_oak_log
fill 56 206 322 56 226 322 minecraft:spruce_planks
fill 56 206 357 56 207 357 minecraft:stripped_dark_oak_log
fill 56 206 359 56 207 359 minecraft:stripped_dark_oak_log
fill 56 206 361 56 207 361 minecraft:stripped_dark_oak_log
fill 56 206 363 56 207 363 minecraft:stripped_dark_oak_log
fill 57 206 356 57 207 356 minecraft:stripped_dark_oak_log
fill 57 206 358 57 207 358 minecraft:stripped_dark_oak_log
fill 57 206 360 57 207 360 minecraft:stripped_dark_oak_log
fill 57 206 362 57 207 362 minecraft:stripped_dark_oak_log
fill 58 206 357 58 207 357 minecraft:stripped_dark_oak_log
fill 58 206 359 58 207 359 minecraft:stripped_dark_oak_log
fill 58 206 361 58 207 361 minecraft:stripped_dark_oak_log
fill 58 206 363 58 207 363 minecraft:stripped_dark_oak_log
fill 59 206 356 59 207 356 minecraft:stripped_dark_oak_log
fill 59 206 358 59 207 358 minecraft:stripped_dark_oak_log
fill 59 206 360 59 207 360 minecraft:stripped_dark_oak_log
fill 59 206 362 59 207 362 minecraft:stripped_dark_oak_log
fill 60 206 357 60 207 357 minecraft:stripped_dark_oak_log
fill 60 206 359 60 207 359 minecraft:stripped_dark_oak_log
fill 60 206 361 60 207 361 minecraft:stripped_dark_oak_log
fill 60 206 363 60 207 363 minecraft:stripped_dark_oak_log
setblock 61 206 323 minecraft:stripped_dark_oak_log
fill 61 206 356 61 207 356 minecraft:stripped_dark_oak_log
fill 61 206 358 61 207 358 minecraft:stripped_dark_oak_log
fill 61 206 360 61 207 360 minecraft:stripped_dark_oak_log
fill 61 206 362 61 207 362 minecraft:stripped_dark_oak_log
fill 63 206 322 63 227 322 minecraft:spruce_planks
setblock 65 206 363 minecraft:stripped_dark_oak_log
setblock 68 206 323 minecraft:stripped_dark_oak_log
setblock 72 206 363 minecraft:stripped_dark_oak_log
setblock 75 206 323 minecraft:stripped_dark_oak_log
setblock 79 206 363 minecraft:stripped_dark_oak_log
setblock 82 206 323 minecraft:stripped_dark_oak_log
setblock 86 206 363 minecraft:stripped_dark_oak_log
setblock 88 206 324 minecraft:stripped_dark_oak_log
setblock 88 206 331 minecraft:stripped_dark_oak_log
setblock 88 206 338 minecraft:stripped_dark_oak_log
setblock 88 206 345 minecraft:stripped_dark_oak_log
setblock 88 206 352 minecraft:stripped_dark_oak_log
setblock 88 206 359 minecraft:stripped_dark_oak_log
fill 47 207 329 47 226 329 minecraft:spruce_planks
setblock 48 207 325 minecraft:stripped_dark_oak_log
setblock 48 207 332 minecraft:stripped_dark_oak_log
setblock 48 207 339 minecraft:stripped_dark_oak_log
setblock 48 207 346 minecraft:stripped_dark_oak_log
setblock 48 207 353 minecraft:stripped_dark_oak_log
setblock 48 207 360 minecraft:stripped_dark_oak_log
setblock 52 207 363 minecraft:stripped_dark_oak_log
setblock 53 207 323 minecraft:stripped_dark_oak_log
fill 55 207 322 55 226 322 minecraft:spruce_planks
setblock 60 207 323 minecraft:stripped_dark_oak_log
setblock 66 207 363 minecraft:stripped_dark_oak_log
setblock 67 207 323 minecraft:stripped_dark_oak_log
setblock 73 207 363 minecraft:stripped_dark_oak_log
setblock 74 207 323 minecraft:stripped_dark_oak_log
setblock 80 207 363 minecraft:stripped_dark_oak_log
setblock 81 207 323 minecraft:stripped_dark_oak_log
setblock 87 207 363 minecraft:stripped_dark_oak_log
setblock 88 207 323 minecraft:stripped_dark_oak_log
setblock 88 207 330 minecraft:stripped_dark_oak_log
setblock 88 207 337 minecraft:stripped_dark_oak_log
setblock 88 207 344 minecraft:stripped_dark_oak_log
setblock 88 207 351 minecraft:stripped_dark_oak_log
setblock 88 207 358 minecraft:stripped_dark_oak_log
setblock 48 208 326 minecraft:stripped_dark_oak_log
setblock 48 208 333 minecraft:stripped_dark_oak_log
setblock 48 208 340 minecraft:stripped_dark_oak_log
setblock 48 208 347 minecraft:stripped_dark_oak_log
setblock 48 208 354 minecraft:stripped_dark_oak_log
setblock 48 208 361 minecraft:stripped_dark_oak_log
setblock 50 208 325 minecraft:light[level=15]
setblock 50 208 332 minecraft:light[level=12]
setblock 50 208 333 minecraft:light[level=15]
setblock 50 208 339 minecraft:light[level=12]
setblock 50 208 341 minecraft:light[level=15]
setblock 50 208 346 minecraft:light[level=12]
setblock 50 208 349 minecraft:light[level=15]
setblock 50 208 353 minecraft:light[level=12]
setblock 50 208 357 minecraft:light[level=15]
setblock 50 208 360 minecraft:light[level=12]
setblock 52 208 323 minecraft:stripped_dark_oak_log
setblock 53 208 363 minecraft:stripped_dark_oak_log
setblock 55 208 356 minecraft:shroomlight
setblock 55 208 358 minecraft:shroomlight
setblock 55 208 360 minecraft:shroomlight
setblock 55 208 362 minecraft:shroomlight
setblock 56 208 357 minecraft:shroomlight
setblock 56 208 359 minecraft:shroomlight
setblock 56 208 361 minecraft:shroomlight
setblock 56 208 363 minecraft:shroomlight
setblock 57 208 325 minecraft:light[level=12]
setblock 57 208 332 minecraft:light[level=12]
setblock 57 208 339 minecraft:light[level=12]
setblock 57 208 346 minecraft:light[level=12]
setblock 57 208 353 minecraft:light[level=12]
setblock 57 208 356 minecraft:shroomlight
setblock 57 208 358 minecraft:shroomlight
setblock 57 208 360 minecraft:shroomlight
setblock 57 208 362 minecraft:shroomlight
setblock 58 208 325 minecraft:light[level=15]
setblock 58 208 333 minecraft:light[level=15]
setblock 58 208 341 minecraft:light[level=15]
setblock 58 208 349 minecraft:light[level=15]
setblock 58 208 357 minecraft:shroomlight
setblock 58 208 359 minecraft:shroomlight
setblock 58 208 361 minecraft:shroomlight
setblock 58 208 363 minecraft:shroomlight
setblock 59 208 323 minecraft:stripped_dark_oak_log
setblock 59 208 356 minecraft:shroomlight
setblock 59 208 358 minecraft:shroomlight
setblock 59 208 360 minecraft:shroomlight
setblock 59 208 362 minecraft:shroomlight
setblock 60 208 357 minecraft:shroomlight
setblock 60 208 359 minecraft:shroomlight
setblock 60 208 361 minecraft:shroomlight
setblock 60 208 363 minecraft:shroomlight
setblock 61 208 356 minecraft:shroomlight
setblock 61 208 358 minecraft:shroomlight
setblock 61 208 360 minecraft:shroomlight
setblock 61 208 362 minecraft:shroomlight
setblock 64 208 325 minecraft:light[level=12]
setblock 64 208 332 minecraft:light[level=12]
setblock 64 208 339 minecraft:light[level=12]
setblock 64 208 346 minecraft:light[level=12]
setblock 64 208 353 minecraft:light[level=12]
setblock 64 208 360 minecraft:light[level=12]
setblock 66 208 323 minecraft:stripped_dark_oak_log
setblock 66 208 325 minecraft:light[level=15]
setblock 66 208 333 minecraft:light[level=15]
setblock 66 208 341 minecraft:light[level=15]
setblock 66 208 349 minecraft:light[level=15]
setblock 66 208 357 minecraft:light[level=15]
setblock 67 208 363 minecraft:stripped_dark_oak_log
setblock 71 208 325 minecraft:light[level=12]
setblock 71 208 332 minecraft:light[level=12]
setblock 71 208 339 minecraft:light[level=12]
setblock 71 208 346 minecraft:light[level=12]
setblock 71 208 353 minecraft:light[level=12]
setblock 71 208 360 minecraft:light[level=12]
setblock 73 208 323 minecraft:stripped_dark_oak_log
setblock 74 208 325 minecraft:light[level=15]
setblock 74 208 333 minecraft:light[level=15]
setblock 74 208 341 minecraft:light[level=15]
setblock 74 208 349 minecraft:light[level=15]
setblock 74 208 357 minecraft:light[level=15]
setblock 74 208 363 minecraft:stripped_dark_oak_log
setblock 78 208 325 minecraft:light[level=12]
setblock 78 208 332 minecraft:light[level=12]
setblock 78 208 339 minecraft:light[level=12]
setblock 78 208 346 minecraft:light[level=12]
setblock 78 208 353 minecraft:light[level=12]
setblock 78 208 360 minecraft:light[level=12]
setblock 80 208 323 minecraft:stripped_dark_oak_log
setblock 81 208 363 minecraft:stripped_dark_oak_log
setblock 82 208 325 minecraft:light[level=15]
setblock 82 208 333 minecraft:light[level=15]
setblock 82 208 341 minecraft:light[level=15]
setblock 82 208 349 minecraft:light[level=15]
setblock 82 208 357 minecraft:light[level=15]
setblock 85 208 325 minecraft:light[level=12]
setblock 85 208 332 minecraft:light[level=12]
setblock 85 208 339 minecraft:light[level=12]
setblock 85 208 346 minecraft:light[level=12]
setblock 85 208 353 minecraft:light[level=12]
setblock 87 208 323 minecraft:stripped_dark_oak_log
setblock 88 208 329 minecraft:stripped_dark_oak_log
setblock 88 208 336 minecraft:stripped_dark_oak_log
setblock 88 208 343 minecraft:stripped_dark_oak_log
setblock 88 208 350 minecraft:stripped_dark_oak_log
setblock 88 208 357 minecraft:stripped_dark_oak_log
setblock 88 208 363 minecraft:stripped_dark_oak_log
fill 47 209 352 47 226 352 minecraft:spruce_planks
setblock 47 209 353 minecraft:red_concrete
fill 48 209 327 48 210 327 minecraft:stripped_dark_oak_log
fill 48 209 334 48 210 334 minecraft:stripped_dark_oak_log
fill 48 209 341 48 210 341 minecraft:stripped_dark_oak_log
fill 48 209 348 48 210 348 minecraft:stripped_dark_oak_log
fill 48 209 355 48 210 355 minecraft:stripped_dark_oak_log
fill 48 209 362 48 210 362 minecraft:stripped_dark_oak_log
fill 51 209 323 51 210 323 minecraft:stripped_dark_oak_log
fill 54 209 363 54 210 363 minecraft:stripped_dark_oak_log
fill 55 209 356 55 210 356 minecraft:stripped_dark_oak_log
fill 55 209 358 55 210 358 minecraft:stripped_dark_oak_log
fill 55 209 360 55 210 360 minecraft:stripped_dark_oak_log
fill 55 209 362 55 210 362 minecraft:stripped_dark_oak_log
fill 56 209 357 56 210 357 minecraft:stripped_dark_oak_log
fill 56 209 359 56 210 359 minecraft:stripped_dark_oak_log
fill 56 209 361 56 210 361 minecraft:stripped_dark_oak_log
fill 56 209 363 56 210 363 minecraft:stripped_dark_oak_log
fill 57 209 356 57 210 356 minecraft:stripped_dark_oak_log
fill 57 209 358 57 210 358 minecraft:stripped_dark_oak_log
fill 57 209 360 57 210 360 minecraft:stripped_dark_oak_log
fill 57 209 362 57 210 362 minecraft:stripped_dark_oak_log
fill 58 209 323 58 210 323 minecraft:stripped_dark_oak_log
fill 58 209 357 58 210 357 minecraft:stripped_dark_oak_log
fill 58 209 359 58 210 359 minecraft:stripped_dark_oak_log
fill 58 209 361 58 210 361 minecraft:stripped_dark_oak_log
fill 58 209 363 58 210 363 minecraft:stripped_dark_oak_log
fill 59 209 356 59 210 356 minecraft:stripped_dark_oak_log
fill 59 209 358 59 210 358 minecraft:stripped_dark_oak_log
fill 59 209 360 59 210 360 minecraft:stripped_dark_oak_log
fill 59 209 362 59 210 362 minecraft:stripped_dark_oak_log
fill 60 209 357 60 210 357 minecraft:stripped_dark_oak_log
fill 60 209 359 60 210 359 minecraft:stripped_dark_oak_log
fill 60 209 361 60 210 361 minecraft:stripped_dark_oak_log
fill 60 209 363 60 210 363 minecraft:stripped_dark_oak_log
fill 61 209 356 61 210 356 minecraft:stripped_dark_oak_log
fill 61 209 358 61 210 358 minecraft:stripped_dark_oak_log
fill 61 209 360 61 210 360 minecraft:stripped_dark_oak_log
fill 61 209 362 61 210 362 minecraft:stripped_dark_oak_log
fill 65 209 323 65 210 323 minecraft:stripped_dark_oak_log
fill 68 209 363 68 210 363 minecraft:stripped_dark_oak_log
fill 72 209 323 72 210 323 minecraft:stripped_dark_oak_log
fill 75 209 363 75 210 363 minecraft:stripped_dark_oak_log
fill 79 209 323 79 210 323 minecraft:stripped_dark_oak_log
fill 81 209 359 81 209 361 minecraft:dark_oak_planks
fill 82 209 358 85 209 358 minecraft:dark_oak_planks
fill 82 209 362 84 209 362 minecraft:dark_oak_planks
fill 82 209 363 82 210 363 minecraft:stripped_dark_oak_log
setblock 85 209 359 minecraft:dark_oak_planks
setblock 85 209 361 minecraft:dark_oak_planks
fill 86 209 323 86 210 323 minecraft:stripped_dark_oak_log
fill 88 209 328 88 210 328 minecraft:stripped_dark_oak_log
fill 88 209 335 88 210 335 minecraft:stripped_dark_oak_log
fill 88 209 342 88 210 342 minecraft:stripped_dark_oak_log
fill 88 209 349 88 210 349 minecraft:stripped_dark_oak_log
fill 88 209 356 88 210 356 minecraft:stripped_dark_oak_log
setblock 47 210 326 minecraft:red_concrete
fill 47 210 353 47 227 353 minecraft:spruce_planks
fill 48 210 323 48 210 326 minecraft:stripped_dark_oak_log
fill 48 210 329 48 210 333 minecraft:stripped_dark_oak_log
fill 48 210 336 48 210 340 minecraft:stripped_dark_oak_log
fill 48 210 343 48 210 347 minecraft:stripped_dark_oak_log
fill 48 210 350 48 210 354 minecraft:stripped_dark_oak_log
fill 48 210 357 48 210 361 minecraft:stripped_dark_oak_log
fill 49 210 323 49 211 323 minecraft:stripped_dark_oak_log
fill 49 210 359 50 211 359 minecraft:iron_bars
fill 49 210 363 53 210 363 minecraft:stripped_dark_oak_log
fill 52 210 323 56 210 323 minecraft:stripped_dark_oak_log
fill 59 210 323 63 210 323 minecraft:stripped_dark_oak_log
fill 63 210 363 67 210 363 minecraft:stripped_dark_oak_log
fill 66 210 323 70 210 323 minecraft:stripped_dark_oak_log
fill 70 210 363 74 210 363 minecraft:stripped_dark_oak_log
fill 73 210 323 77 210 323 minecraft:stripped_dark_oak_log
fill 77 210 363 81 210 363 minecraft:stripped_dark_oak_log
fill 80 210 323 84 210 323 minecraft:stripped_dark_oak_log
fill 84 210 363 88 210 363 minecraft:stripped_dark_oak_log
fill 87 210 323 88 210 323 minecraft:stripped_dark_oak_log
fill 88 210 324 88 210 326 minecraft:stripped_dark_oak_log
fill 88 210 329 88 210 333 minecraft:stripped_dark_oak_log
fill 88 210 336 88 210 340 minecraft:stripped_dark_oak_log
fill 88 210 343 88 210 347 minecraft:stripped_dark_oak_log
fill 88 210 350 88 210 354 minecraft:stripped_dark_oak_log
fill 88 210 357 88 210 361 minecraft:stripped_dark_oak_log
fill 47 211 326 47 224 326 minecraft:spruce_planks
setblock 48 211 329 minecraft:stripped_dark_oak_log
setblock 48 211 336 minecraft:stripped_dark_oak_log
setblock 48 211 343 minecraft:stripped_dark_oak_log
setblock 48 211 350 minecraft:stripped_dark_oak_log
setblock 48 211 357 minecraft:stripped_dark_oak_log
setblock 48 211 359 minecraft:iron_bars
setblock 49 211 363 minecraft:stripped_dark_oak_log
setblock 55 211 356 minecraft:shroomlight
setblock 55 211 358 minecraft:shroomlight
setblock 55 211 360 minecraft:shroomlight
setblock 55 211 362 minecraft:shroomlight
setblock 56 211 323 minecraft:stripped_dark_oak_log
setblock 56 211 357 minecraft:shroomlight
setblock 56 211 359 minecraft:shroomlight
setblock 56 211 361 minecraft:shroomlight
setblock 56 211 363 minecraft:shroomlight
setblock 57 211 356 minecraft:shroomlight
setblock 57 211 358 minecraft:shroomlight
setblock 57 211 360 minecraft:shroomlight
setblock 57 211 362 minecraft:shroomlight
setblock 58 211 357 minecraft:shroomlight
setblock 58 211 359 minecraft:shroomlight
setblock 58 211 361 minecraft:shroomlight
setblock 58 211 363 minecraft:shroomlight
setblock 59 211 356 minecraft:shroomlight
setblock 59 211 358 minecraft:shroomlight
setblock 59 211 360 minecraft:shroomlight
setblock 59 211 362 minecraft:shroomlight
setblock 60 211 357 minecraft:shroomlight
setblock 60 211 359 minecraft:shroomlight
setblock 60 211 361 minecraft:shroomlight
setblock 60 211 363 minecraft:shroomlight
setblock 61 211 356 minecraft:shroomlight
setblock 61 211 358 minecraft:shroomlight
setblock 61 211 360 minecraft:shroomlight
setblock 61 211 362 minecraft:shroomlight
setblock 63 211 323 minecraft:stripped_dark_oak_log
setblock 63 211 363 minecraft:stripped_dark_oak_log
setblock 70 211 323 minecraft:stripped_dark_oak_log
setblock 70 211 363 minecraft:stripped_dark_oak_log
setblock 77 211 323 minecraft:stripped_dark_oak_log
setblock 77 211 363 minecraft:stripped_dark_oak_log
fill 78 211 364 79 226 364 minecraft:spruce_planks
setblock 80 211 364 minecraft:red_concrete
fill 81 211 364 81 224 364 minecraft:spruce_planks
setblock 84 211 323 minecraft:stripped_dark_oak_log
setblock 84 211 363 minecraft:stripped_dark_oak_log
setblock 88 211 326 minecraft:stripped_dark_oak_log
setblock 88 211 333 minecraft:stripped_dark_oak_log
setblock 88 211 340 minecraft:stripped_dark_oak_log
setblock 88 211 347 minecraft:stripped_dark_oak_log
setblock 88 211 354 minecraft:stripped_dark_oak_log
setblock 88 211 361 minecraft:stripped_dark_oak_log
setblock 48 212 323 minecraft:stripped_dark_oak_log
fill 48 212 326 50 213 326 minecraft:iron_bars
setblock 48 212 330 minecraft:stripped_dark_oak_log
setblock 48 212 337 minecraft:stripped_dark_oak_log
setblock 48 212 344 minecraft:stripped_dark_oak_log
setblock 48 212 351 minecraft:stripped_dark_oak_log
setblock 48 212 358 minecraft:stripped_dark_oak_log
setblock 50 212 363 minecraft:stripped_dark_oak_log
setblock 55 212 323 minecraft:stripped_dark_oak_log
fill 55 212 356 55 213 356 minecraft:stripped_dark_oak_log
fill 55 212 358 55 213 358 minecraft:stripped_dark_oak_log
fill 55 212 360 55 213 360 minecraft:stripped_dark_oak_log
fill 55 212 362 55 213 362 minecraft:stripped_dark_oak_log
fill 56 212 357 56 213 357 minecraft:stripped_dark_oak_log
fill 56 212 359 56 213 359 minecraft:stripped_dark_oak_log
fill 56 212 361 56 213 361 minecraft:stripped_dark_oak_log
fill 56 212 363 56 213 363 minecraft:stripped_dark_oak_log
fill 57 212 356 57 213 356 minecraft:stripped_dark_oak_log
fill 57 212 358 57 213 358 minecraft:stripped_dark_oak_log
fill 57 212 360 57 213 360 minecraft:stripped_dark_oak_log
fill 57 212 362 57 213 362 minecraft:stripped_dark_oak_log
fill 58 212 357 58 213 357 minecraft:stripped_dark_oak_log
fill 58 212 359 58 213 359 minecraft:stripped_dark_oak_log
fill 58 212 361 58 213 361 minecraft:stripped_dark_oak_log
fill 58 212 363 58 213 363 minecraft:stripped_dark_oak_log
fill 59 212 356 59 213 356 minecraft:stripped_dark_oak_log
fill 59 212 358 59 213 358 minecraft:stripped_dark_oak_log
fill 59 212 360 59 213 360 minecraft:stripped_dark_oak_log
fill 59 212 362 59 213 362 minecraft:stripped_dark_oak_log
fill 60 212 357 60 213 357 minecraft:stripped_dark_oak_log
fill 60 212 359 60 213 359 minecraft:stripped_dark_oak_log
fill 60 212 361 60 213 361 minecraft:stripped_dark_oak_log
fill 60 212 363 60 213 363 minecraft:stripped_dark_oak_log
fill 61 212 356 61 213 356 minecraft:stripped_dark_oak_log
fill 61 212 358 61 213 358 minecraft:stripped_dark_oak_log
fill 61 212 360 61 213 360 minecraft:stripped_dark_oak_log
fill 61 212 362 61 213 362 minecraft:stripped_dark_oak_log
setblock 62 212 323 minecraft:stripped_dark_oak_log
setblock 64 212 363 minecraft:stripped_dark_oak_log
setblock 69 212 323 minecraft:stripped_dark_oak_log
setblock 71 212 363 minecraft:stripped_dark_oak_log
setblock 76 212 323 minecraft:stripped_dark_oak_log
setblock 78 212 363 minecraft:stripped_dark_oak_log
fill 80 212 364 80 223 364 minecraft:spruce_planks
fill 81 212 360 81 213 360 minecraft:red_concrete
fill 82 212 358 84 213 358 minecraft:red_concrete
setblock 83 212 323 minecraft:stripped_dark_oak_log
fill 83 212 362 84 213 362 minecraft:red_concrete
fill 85 212 359 85 213 359 minecraft:red_concrete
fill 85 212 361 85 213 361 minecraft:red_concrete
setblock 85 212 363 minecraft:stripped_dark_oak_log
setblock 88 212 325 minecraft:stripped_dark_oak_log
setblock 88 212 332 minecraft:stripped_dark_oak_log
setblock 88 212 339 minecraft:stripped_dark_oak_log
setblock 88 212 346 minecraft:stripped_dark_oak_log
setblock 88 212 353 minecraft:stripped_dark_oak_log
setblock 88 212 360 minecraft:stripped_dark_oak_log
setblock 48 213 324 minecraft:stripped_dark_oak_log
setblock 48 213 331 minecraft:stripped_dark_oak_log
setblock 48 213 338 minecraft:stripped_dark_oak_log
setblock 48 213 345 minecraft:stripped_dark_oak_log
setblock 48 213 352 minecraft:stripped_dark_oak_log
setblock 48 213 359 minecraft:stripped_dark_oak_log
setblock 51 213 363 minecraft:stripped_dark_oak_log
setblock 54 213 323 minecraft:stripped_dark_oak_log
setblock 61 213 323 minecraft:stripped_dark_oak_log
setblock 65 213 363 minecraft:stripped_dark_oak_log
setblock 68 213 323 minecraft:stripped_dark_oak_log
setblock 72 213 363 minecraft:stripped_dark_oak_log
setblock 75 213 323 minecraft:stripped_dark_oak_log
setblock 79 213 363 minecraft:stripped_dark_oak_log
setblock 82 213 323 minecraft:stripped_dark_oak_log
setblock 86 213 363 minecraft:stripped_dark_oak_log
setblock 88 213 324 minecraft:stripped_dark_oak_log
setblock 88 213 331 minecraft:stripped_dark_oak_log
setblock 88 213 338 minecraft:stripped_dark_oak_log
setblock 88 213 345 minecraft:stripped_dark_oak_log
setblock 88 213 352 minecraft:stripped_dark_oak_log
setblock 88 213 359 minecraft:stripped_dark_oak_log
setblock 50 214 325 minecraft:light[level=12]
setblock 50 214 332 minecraft:light[level=12]
setblock 50 214 339 minecraft:light[level=12]
setblock 50 214 346 minecraft:light[level=12]
setblock 50 214 353 minecraft:light[level=12]
setblock 50 214 360 minecraft:light[level=12]
setblock 57 214 325 minecraft:light[level=12]
setblock 57 214 332 minecraft:light[level=12]
setblock 57 214 339 minecraft:light[level=12]
setblock 57 214 346 minecraft:light[level=12]
setblock 57 214 353 minecraft:light[level=12]
setblock 57 214 360 minecraft:light[level=12]
setblock 64 214 325 minecraft:light[level=12]
setblock 64 214 332 minecraft:light[level=12]
setblock 64 214 339 minecraft:light[level=12]
setblock 64 214 346 minecraft:light[level=12]
setblock 64 214 353 minecraft:light[level=12]
setblock 64 214 360 minecraft:light[level=12]
setblock 71 214 325 minecraft:light[level=12]
setblock 71 214 332 minecraft:light[level=12]
setblock 71 214 339 minecraft:light[level=12]
setblock 71 214 346 minecraft:light[level=12]
setblock 71 214 353 minecraft:light[level=12]
setblock 71 214 360 minecraft:light[level=12]
setblock 78 214 325 minecraft:light[level=12]
setblock 78 214 332 minecraft:light[level=12]
setblock 78 214 339 minecraft:light[level=12]
setblock 78 214 346 minecraft:light[level=12]
setblock 78 214 353 minecraft:light[level=12]
setblock 78 214 360 minecraft:light[level=12]
setblock 85 214 325 minecraft:light[level=12]
setblock 85 214 332 minecraft:light[level=12]
setblock 85 214 339 minecraft:light[level=12]
setblock 85 214 346 minecraft:light[level=12]
setblock 85 214 353 minecraft:light[level=12]
setblock 85 214 360 minecraft:light[level=12]
setblock 50 216 325 minecraft:light[level=15]
setblock 50 216 333 minecraft:light[level=15]
setblock 50 216 341 minecraft:light[level=15]
setblock 50 216 349 minecraft:light[level=15]
setblock 50 216 357 minecraft:light[level=15]
setblock 56 216 364 minecraft:red_concrete
setblock 58 216 325 minecraft:light[level=15]
setblock 58 216 333 minecraft:light[level=15]
setblock 58 216 341 minecraft:light[level=15]
setblock 58 216 349 minecraft:light[level=15]
setblock 58 216 357 minecraft:light[level=15]
setblock 66 216 325 minecraft:light[level=15]
setblock 66 216 333 minecraft:light[level=15]
setblock 66 216 341 minecraft:light[level=15]
setblock 66 216 349 minecraft:light[level=15]
setblock 66 216 357 minecraft:light[level=15]
setblock 74 216 325 minecraft:light[level=15]
setblock 74 216 333 minecraft:light[level=15]
setblock 74 216 341 minecraft:light[level=15]
setblock 74 216 349 minecraft:light[level=15]
setblock 74 216 357 minecraft:light[level=15]
setblock 82 216 325 minecraft:light[level=15]
setblock 82 216 333 minecraft:light[level=15]
setblock 82 216 341 minecraft:light[level=15]
setblock 82 216 349 minecraft:light[level=15]
setblock 82 216 357 minecraft:light[level=15]
fill 56 217 364 56 226 364 minecraft:spruce_planks
fill 48 219 323 49 220 363 minecraft:hay_block
fill 50 219 323 52 220 324 minecraft:hay_block
fill 50 219 325 50 220 325 minecraft:dark_oak_planks
fill 50 219 326 52 220 327 minecraft:hay_block
fill 50 219 328 50 220 328 minecraft:dark_oak_planks
fill 50 219 329 52 220 330 minecraft:hay_block
fill 50 219 331 50 220 331 minecraft:dark_oak_planks
fill 50 219 332 52 220 333 minecraft:hay_block
fill 50 219 334 50 220 334 minecraft:dark_oak_planks
fill 50 219 335 52 220 336 minecraft:hay_block
fill 50 219 337 50 220 337 minecraft:dark_oak_planks
fill 50 219 338 52 220 339 minecraft:hay_block
fill 50 219 340 50 220 340 minecraft:dark_oak_planks
fill 50 219 341 52 220 342 minecraft:hay_block
fill 50 219 343 50 220 343 minecraft:dark_oak_planks
fill 50 219 344 52 220 345 minecraft:hay_block
fill 50 219 346 50 220 346 minecraft:dark_oak_planks
fill 50 219 347 52 220 348 minecraft:hay_block
fill 50 219 349 50 220 349 minecraft:dark_oak_planks
fill 50 219 350 52 220 351 minecraft:hay_block
fill 50 219 352 50 220 352 minecraft:dark_oak_planks
fill 50 219 353 52 220 354 minecraft:hay_block
fill 50 219 355 50 220 355 minecraft:dark_oak_planks
fill 50 219 356 52 220 357 minecraft:hay_block
fill 50 219 358 50 220 358 minecraft:dark_oak_planks
fill 50 219 359 52 220 360 minecraft:hay_block
fill 50 219 361 50 220 361 minecraft:dark_oak_planks
fill 50 219 362 52 220 363 minecraft:hay_block
fill 51 219 325 52 220 325 minecraft:hay_block
fill 51 219 328 52 220 328 minecraft:hay_block
fill 51 219 331 52 220 331 minecraft:hay_block
fill 51 219 334 52 220 334 minecraft:hay_block
fill 51 219 337 52 220 337 minecraft:hay_block
fill 51 219 340 52 220 340 minecraft:hay_block
fill 51 219 343 52 220 343 minecraft:hay_block
fill 51 219 346 52 220 346 minecraft:hay_block
fill 51 219 349 52 220 349 minecraft:hay_block
fill 51 219 352 52 220 352 minecraft:hay_block
fill 51 219 355 52 220 355 minecraft:hay_block
fill 51 219 358 52 220 358 minecraft:hay_block
fill 51 219 361 52 220 361 minecraft:hay_block
fill 53 219 323 53 220 363 minecraft:dark_oak_planks
fill 54 219 323 55 219 363 minecraft:hay_block
fill 56 219 323 58 220 324 minecraft:hay_block
fill 56 219 325 56 220 325 minecraft:dark_oak_planks
fill 56 219 326 58 220 327 minecraft:hay_block
fill 56 219 328 56 220 328 minecraft:dark_oak_planks
fill 56 219 329 58 220 330 minecraft:hay_block
fill 56 219 331 56 220 331 minecraft:dark_oak_planks
fill 56 219 332 58 220 333 minecraft:hay_block
fill 56 219 334 56 220 334 minecraft:dark_oak_planks
fill 56 219 335 58 220 336 minecraft:hay_block
fill 56 219 337 56 220 337 minecraft:dark_oak_planks
fill 56 219 338 58 220 339 minecraft:hay_block
fill 56 219 340 56 221 340 minecraft:dark_oak_planks
fill 56 219 341 58 219 342 minecraft:hay_block
fill 56 219 343 56 220 343 minecraft:dark_oak_planks
fill 56 219 344 58 219 345 minecraft:hay_block
fill 56 219 346 56 221 346 minecraft:dark_oak_planks
fill 56 219 347 58 220 348 minecraft:hay_block
fill 56 219 349 56 220 349 minecraft:dark_oak_planks
fill 56 219 350 58 220 351 minecraft:hay_block
fill 56 219 352 56 220 352 minecraft:dark_oak_planks
fill 56 219 353 58 220 354 minecraft:hay_block
fill 56 219 355 56 220 355 minecraft:dark_oak_planks
fill 56 219 356 58 220 357 minecraft:hay_block
fill 56 219 358 56 220 358 minecraft:dark_oak_planks
fill 56 219 359 58 220 360 minecraft:hay_block
fill 56 219 361 56 220 361 minecraft:dark_oak_planks
fill 56 219 362 58 220 363 minecraft:hay_block
fill 57 219 325 58 220 325 minecraft:hay_block
fill 57 219 328 58 220 328 minecraft:hay_block
fill 57 219 331 58 220 331 minecraft:hay_block
fill 57 219 334 58 220 334 minecraft:hay_block
fill 57 219 337 58 220 337 minecraft:hay_block
fill 57 219 340 58 219 340 minecraft:hay_block
setblock 57 219 343 minecraft:hay_block
fill 57 219 346 58 219 346 minecraft:hay_block
fill 57 219 349 58 220 349 minecraft:hay_block
fill 57 219 352 58 220 352 minecraft:hay_block
fill 57 219 355 58 220 355 minecraft:hay_block
fill 57 219 358 58 220 358 minecraft:hay_block
fill 57 219 361 58 220 361 minecraft:hay_block
fill 58 219 343 61 219 343 minecraft:dark_oak_planks
fill 59 219 323 59 220 342 minecraft:dark_oak_planks
fill 59 219 344 59 220 363 minecraft:dark_oak_planks
fill 60 219 323 61 219 340 minecraft:hay_block
fill 60 219 341 61 219 342 minecraft:dark_oak_planks
fill 60 219 344 61 219 345 minecraft:dark_oak_planks
fill 60 219 346 61 219 363 minecraft:hay_block
fill 62 219 323 64 220 324 minecraft:hay_block
fill 62 219 325 62 220 325 minecraft:dark_oak_planks
fill 62 219 326 64 220 327 minecraft:hay_block
fill 62 219 328 62 220 328 minecraft:dark_oak_planks
fill 62 219 329 64 220 330 minecraft:hay_block
fill 62 219 331 62 220 331 minecraft:dark_oak_planks
fill 62 219 332 64 220 333 minecraft:hay_block
fill 62 219 334 62 220 334 minecraft:dark_oak_planks
fill 62 219 335 64 220 336 minecraft:hay_block
fill 62 219 337 62 220 337 minecraft:dark_oak_planks
fill 62 219 338 64 219 339 minecraft:hay_block
fill 62 219 340 62 219 341 minecraft:dark_oak_planks
fill 62 219 345 62 219 346 minecraft:dark_oak_planks
fill 62 219 347 64 219 348 minecraft:hay_block
fill 62 219 349 62 220 349 minecraft:dark_oak_planks
fill 62 219 350 64 220 351 minecraft:hay_block
fill 62 219 352 62 220 352 minecraft:dark_oak_planks
fill 62 219 353 64 220 354 minecraft:hay_block
fill 62 219 355 62 220 355 minecraft:dark_oak_planks
fill 62 219 356 64 220 357 minecraft:hay_block
fill 62 219 358 62 220 358 minecraft:dark_oak_planks
fill 62 219 359 64 220 360 minecraft:hay_block
fill 62 219 361 62 220 361 minecraft:dark_oak_planks
fill 62 219 362 64 220 363 minecraft:hay_block
fill 63 219 325 64 220 325 minecraft:hay_block
fill 63 219 328 64 220 328 minecraft:hay_block
fill 63 219 331 64 220 331 minecraft:hay_block
fill 63 219 334 64 220 334 minecraft:hay_block
fill 63 219 337 64 220 337 minecraft:hay_block
fill 63 219 340 65 219 340 minecraft:dark_oak_planks
fill 63 219 346 65 219 346 minecraft:dark_oak_planks
fill 63 219 349 64 220 349 minecraft:hay_block
fill 63 219 352 64 220 352 minecraft:hay_block
fill 63 219 355 64 220 355 minecraft:hay_block
fill 63 219 358 64 220 358 minecraft:hay_block
fill 63 219 361 64 220 361 minecraft:hay_block
fill 65 219 323 65 220 339 minecraft:dark_oak_planks
fill 65 219 347 65 220 363 minecraft:dark_oak_planks
fill 66 219 323 67 219 340 minecraft:hay_block
fill 66 219 341 68 219 341 minecraft:dark_oak_planks
fill 66 219 345 68 219 345 minecraft:dark_oak_planks
fill 66 219 346 67 219 363 minecraft:hay_block
fill 67 219 342 69 219 344 minecraft:dark_oak_planks
fill 68 219 323 70 220 324 minecraft:hay_block
fill 68 219 325 68 220 325 minecraft:dark_oak_planks
fill 68 219 326 70 220 327 minecraft:hay_block
fill 68 219 328 68 220 328 minecraft:dark_oak_planks
fill 68 219 329 70 220 330 minecraft:hay_block
fill 68 219 331 68 220 331 minecraft:dark_oak_planks
fill 68 219 332 70 220 333 minecraft:hay_block
fill 68 219 334 68 220 334 minecraft:dark_oak_planks
fill 68 219 335 70 220 336 minecraft:hay_block
fill 68 219 337 68 220 337 minecraft:dark_oak_planks
fill 68 219 338 70 219 339 minecraft:hay_block
fill 68 219 340 68 220 340 minecraft:dark_oak_planks
fill 68 219 346 68 220 346 minecraft:dark_oak_planks
fill 68 219 347 70 219 348 minecraft:hay_block
fill 68 219 349 68 220 349 minecraft:dark_oak_planks
fill 68 219 350 70 220 351 minecraft:hay_block
fill 68 219 352 68 220 352 minecraft:dark_oak_planks
fill 68 219 353 70 220 354 minecraft:hay_block
fill 68 219 355 68 220 355 minecraft:dark_oak_planks
fill 68 219 356 70 220 357 minecraft:hay_block
fill 68 219 358 68 220 358 minecraft:dark_oak_planks
fill 68 219 359 70 220 360 minecraft:hay_block
fill 68 219 361 68 220 361 minecraft:dark_oak_planks
fill 68 219 362 70 220 363 minecraft:hay_block
fill 69 219 325 70 220 325 minecraft:hay_block
fill 69 219 328 70 220 328 minecraft:hay_block
fill 69 219 331 70 220 331 minecraft:hay_block
fill 69 219 334 70 220 334 minecraft:hay_block
fill 69 219 337 70 220 337 minecraft:hay_block
fill 69 219 340 70 219 341 minecraft:hay_block
fill 69 219 345 70 219 346 minecraft:hay_block
fill 69 219 349 70 220 349 minecraft:hay_block
fill 69 219 352 70 220 352 minecraft:hay_block
fill 69 219 355 70 220 355 minecraft:hay_block
fill 69 219 358 70 220 358 minecraft:hay_block
fill 69 219 361 70 220 361 minecraft:hay_block
setblock 70 219 342 minecraft:hay_block
fill 70 219 343 71 220 343 minecraft:dark_oak_planks
setblock 70 219 344 minecraft:hay_block
fill 71 219 323 71 220 342 minecraft:dark_oak_planks
fill 71 219 344 71 220 363 minecraft:dark_oak_planks
fill 72 219 323 73 219 363 minecraft:hay_block
fill 74 219 323 76 220 324 minecraft:hay_block
fill 74 219 325 74 220 325 minecraft:dark_oak_planks
fill 74 219 326 76 220 327 minecraft:hay_block
fill 74 219 328 74 220 328 minecraft:dark_oak_planks
fill 74 219 329 76 220 330 minecraft:hay_block
fill 74 219 331 74 220 331 minecraft:dark_oak_planks
fill 74 219 332 76 220 333 minecraft:hay_block
fill 74 219 334 74 220 334 minecraft:dark_oak_planks
fill 74 219 335 76 220 336 minecraft:hay_block
fill 74 219 337 74 220 337 minecraft:dark_oak_planks
fill 74 219 338 76 220 339 minecraft:hay_block
fill 74 219 340 74 221 340 minecraft:dark_oak_planks
fill 74 219 341 76 220 342 minecraft:hay_block
fill 74 219 343 74 221 343 minecraft:dark_oak_planks
fill 74 219 344 76 220 345 minecraft:hay_block
fill 74 219 346 74 221 346 minecraft:dark_oak_planks
fill 74 219 347 76 220 348 minecraft:hay_block
fill 74 219 349 74 220 349 minecraft:dark_oak_planks
fill 74 219 350 76 220 351 minecraft:hay_block
fill 74 219 352 74 220 352 minecraft:dark_oak_planks
fill 74 219 353 76 220 354 minecraft:hay_block
fill 74 219 355 74 220 355 minecraft:dark_oak_planks
fill 74 219 356 76 220 357 minecraft:hay_block
fill 74 219 358 74 220 358 minecraft:dark_oak_planks
fill 74 219 359 76 220 360 minecraft:hay_block
fill 74 219 361 74 220 361 minecraft:dark_oak_planks
fill 74 219 362 76 220 363 minecraft:hay_block
fill 75 219 325 76 220 325 minecraft:hay_block
fill 75 219 328 76 220 328 minecraft:hay_block
fill 75 219 331 76 220 331 minecraft:hay_block
fill 75 219 334 76 220 334 minecraft:hay_block
fill 75 219 337 76 220 337 minecraft:hay_block
fill 75 219 340 76 220 340 minecraft:hay_block
fill 75 219 343 76 220 343 minecraft:hay_block
fill 75 219 346 76 220 346 minecraft:hay_block
fill 75 219 349 76 220 349 minecraft:hay_block
fill 75 219 352 76 220 352 minecraft:hay_block
fill 75 219 355 76 220 355 minecraft:hay_block
fill 75 219 358 76 220 358 minecraft:hay_block
fill 75 219 361 76 220 361 minecraft:hay_block
fill 77 219 323 77 220 363 minecraft:dark_oak_planks
fill 78 219 323 79 220 363 minecraft:hay_block
fill 80 219 323 82 220 324 minecraft:hay_block
fill 80 219 325 80 220 325 minecraft:dark_oak_planks
fill 80 219 326 82 220 327 minecraft:hay_block
fill 80 219 328 80 220 328 minecraft:dark_oak_planks
fill 80 219 329 82 220 330 minecraft:hay_block
fill 80 219 331 80 220 331 minecraft:dark_oak_planks
fill 80 219 332 82 220 333 minecraft:hay_block
fill 80 219 334 80 220 334 minecraft:dark_oak_planks
fill 80 219 335 82 220 336 minecraft:hay_block
fill 80 219 337 80 220 337 minecraft:dark_oak_planks
fill 80 219 338 82 220 339 minecraft:hay_block
fill 80 219 340 80 220 340 minecraft:dark_oak_planks
fill 80 219 341 82 220 342 minecraft:hay_block
fill 80 219 343 80 220 343 minecraft:dark_oak_planks
fill 80 219 344 82 220 345 minecraft:hay_block
fill 80 219 346 80 220 346 minecraft:dark_oak_planks
fill 80 219 347 82 220 348 minecraft:hay_block
fill 80 219 349 80 220 349 minecraft:dark_oak_planks
fill 80 219 350 82 220 351 minecraft:hay_block
fill 80 219 352 80 220 352 minecraft:dark_oak_planks
fill 80 219 353 82 220 354 minecraft:hay_block
fill 80 219 355 80 220 355 minecraft:dark_oak_planks
fill 80 219 356 82 220 357 minecraft:hay_block
fill 80 219 358 80 220 358 minecraft:dark_oak_planks
fill 80 219 359 82 220 360 minecraft:hay_block
fill 80 219 361 80 220 361 minecraft:dark_oak_planks
fill 80 219 362 82 220 363 minecraft:hay_block
fill 81 219 325 82 220 325 minecraft:hay_block
fill 81 219 328 82 220 328 minecraft:hay_block
fill 81 219 331 82 220 331 minecraft:hay_block
fill 81 219 334 82 220 334 minecraft:hay_block
fill 81 219 337 82 220 337 minecraft:hay_block
fill 81 219 340 82 220 340 minecraft:hay_block
fill 81 219 343 82 220 343 minecraft:hay_block
fill 81 219 346 82 220 346 minecraft:hay_block
fill 81 219 349 82 220 349 minecraft:hay_block
fill 81 219 352 82 220 352 minecraft:hay_block
fill 81 219 355 82 220 355 minecraft:hay_block
fill 81 219 358 82 220 358 minecraft:hay_block
fill 81 219 361 82 220 361 minecraft:hay_block
fill 83 219 323 83 220 363 minecraft:dark_oak_planks
fill 84 219 323 85 220 363 minecraft:hay_block
fill 86 219 323 88 220 324 minecraft:hay_block
fill 86 219 325 86 220 325 minecraft:dark_oak_planks
fill 86 219 326 88 220 327 minecraft:hay_block
fill 86 219 328 86 220 328 minecraft:dark_oak_planks
fill 86 219 329 88 220 330 minecraft:hay_block
fill 86 219 331 86 220 331 minecraft:dark_oak_planks
fill 86 219 332 88 220 333 minecraft:hay_block
fill 86 219 334 86 220 334 minecraft:dark_oak_planks
fill 86 219 335 88 220 336 minecraft:hay_block
fill 86 219 337 86 220 337 minecraft:dark_oak_planks
fill 86 219 338 88 220 339 minecraft:hay_block
fill 86 219 340 86 220 340 minecraft:dark_oak_planks
fill 86 219 341 88 220 342 minecraft:hay_block
fill 86 219 343 86 220 343 minecraft:dark_oak_planks
fill 86 219 344 88 220 345 minecraft:hay_block
fill 86 219 346 86 220 346 minecraft:dark_oak_planks
fill 86 219 347 88 220 348 minecraft:hay_block
fill 86 219 349 86 220 349 minecraft:dark_oak_planks
fill 86 219 350 88 220 351 minecraft:hay_block
fill 86 219 352 86 220 352 minecraft:dark_oak_planks
fill 86 219 353 88 220 354 minecraft:hay_block
fill 86 219 355 86 220 355 minecraft:dark_oak_planks
fill 86 219 356 88 220 357 minecraft:hay_block
fill 86 219 358 86 220 358 minecraft:dark_oak_planks
fill 86 219 359 88 220 360 minecraft:hay_block
fill 86 219 361 86 220 361 minecraft:dark_oak_planks
fill 86 219 362 88 220 363 minecraft:hay_block
fill 87 219 325 88 220 325 minecraft:hay_block
fill 87 219 328 88 220 328 minecraft:hay_block
fill 87 219 331 88 220 331 minecraft:hay_block
fill 87 219 334 88 220 334 minecraft:hay_block
fill 87 219 337 88 220 337 minecraft:hay_block
fill 87 219 340 88 220 340 minecraft:hay_block
fill 87 219 343 88 220 343 minecraft:hay_block
fill 87 219 346 88 220 346 minecraft:hay_block
fill 87 219 349 88 220 349 minecraft:hay_block
fill 87 219 352 88 220 352 minecraft:hay_block
fill 87 219 355 88 220 355 minecraft:hay_block
fill 87 219 358 88 220 358 minecraft:hay_block
fill 87 219 361 88 220 361 minecraft:hay_block
fill 54 220 323 54 220 363 minecraft:hay_block
fill 55 220 323 55 220 340 minecraft:hay_block
fill 55 220 341 55 220 345 minecraft:dark_oak_planks
fill 55 220 346 55 220 363 minecraft:hay_block
fill 56 220 341 58 220 342 minecraft:dark_oak_planks
fill 56 220 344 58 220 345 minecraft:dark_oak_planks
fill 57 220 340 58 220 340 minecraft:dark_oak_planks
fill 57 220 343 60 220 343 minecraft:dark_oak_planks
fill 57 220 346 58 220 346 minecraft:dark_oak_planks
fill 60 220 323 61 220 338 minecraft:hay_block
fill 60 220 339 60 220 342 minecraft:dark_oak_planks
fill 60 220 344 60 220 347 minecraft:dark_oak_planks
fill 60 220 348 61 220 363 minecraft:hay_block
fill 61 220 339 61 220 341 minecraft:dark_oak_planks
fill 61 220 342 61 220 344 minecraft:sea_lantern
fill 61 220 345 61 220 347 minecraft:dark_oak_planks
fill 62 220 338 64 220 338 minecraft:hay_block
fill 62 220 339 62 220 340 minecraft:dark_oak_planks
setblock 62 220 341 minecraft:sea_lantern
setblock 62 220 345 minecraft:sea_lantern
fill 62 220 346 62 220 347 minecraft:dark_oak_planks
fill 62 220 348 64 220 348 minecraft:hay_block
fill 63 220 339 64 220 339 minecraft:dark_oak_planks
fill 63 220 340 65 220 340 minecraft:sea_lantern
fill 63 220 346 65 220 346 minecraft:sea_lantern
fill 63 220 347 64 220 347 minecraft:dark_oak_planks
fill 66 220 323 67 220 338 minecraft:hay_block
fill 66 220 339 67 220 340 minecraft:dark_oak_planks
setblock 66 220 341 minecraft:sea_lantern
setblock 66 220 345 minecraft:sea_lantern
fill 66 220 346 67 220 347 minecraft:dark_oak_planks
fill 66 220 348 67 220 363 minecraft:hay_block
fill 67 220 341 70 220 341 minecraft:dark_oak_planks
fill 67 220 342 67 220 344 minecraft:sea_lantern
fill 67 220 345 70 220 345 minecraft:dark_oak_planks
fill 68 220 338 70 220 338 minecraft:hay_block
fill 68 220 339 69 220 339 minecraft:dark_oak_planks
fill 68 220 342 69 220 344 minecraft:dark_oak_planks
fill 68 220 347 69 220 347 minecraft:dark_oak_planks
fill 68 220 348 70 220 348 minecraft:hay_block
fill 69 220 340 70 220 340 minecraft:dark_oak_planks
fill 69 220 346 70 220 346 minecraft:dark_oak_planks
setblock 70 220 339 minecraft:hay_block
setblock 70 220 342 minecraft:dark_oak_planks
setblock 70 220 344 minecraft:dark_oak_planks
setblock 70 220 347 minecraft:hay_block
fill 72 220 323 73 220 340 minecraft:hay_block
fill 72 220 341 73 220 345 minecraft:dark_oak_planks
fill 72 220 346 73 220 363 minecraft:hay_block
fill 52 221 343 54 221 343 minecraft:dark_oak_planks
fill 53 221 341 54 221 342 minecraft:dark_oak_planks
fill 53 221 344 54 221 345 minecraft:dark_oak_planks
fill 54 221 340 55 221 340 minecraft:dark_oak_planks
fill 54 221 346 55 221 346 minecraft:dark_oak_planks
fill 55 221 339 58 221 339 minecraft:dark_oak_planks
fill 55 221 347 58 221 347 minecraft:dark_oak_planks
fill 58 221 338 70 221 338 minecraft:dark_oak_planks
fill 58 221 348 70 221 348 minecraft:dark_oak_planks
fill 63 221 337 65 223 337 minecraft:dark_oak_planks
fill 63 221 349 65 223 349 minecraft:dark_oak_planks
setblock 63 221 364 minecraft:red_concrete
fill 70 221 339 73 221 339 minecraft:dark_oak_planks
fill 70 221 347 73 221 347 minecraft:dark_oak_planks
fill 72 221 340 73 221 340 minecraft:dark_oak_planks
fill 72 221 346 73 221 346 minecraft:dark_oak_planks
fill 74 221 341 75 221 342 minecraft:dark_oak_planks
fill 74 221 344 75 221 345 minecraft:dark_oak_planks
fill 75 221 343 76 221 343 minecraft:dark_oak_planks
fill 89 221 340 89 224 340 minecraft:spruce_planks
setblock 89 221 341 minecraft:red_concrete
fill 51 222 342 51 223 344 minecraft:dark_oak_planks
fill 52 222 341 52 222 342 minecraft:dark_oak_planks
fill 52 222 344 52 222 345 minecraft:dark_oak_planks
setblock 53 222 340 minecraft:dark_oak_planks
setblock 53 222 346 minecraft:dark_oak_planks
fill 54 222 339 55 222 339 minecraft:dark_oak_planks
fill 54 222 347 55 222 347 minecraft:dark_oak_planks
fill 56 222 338 58 222 338 minecraft:dark_oak_planks
fill 56 222 348 58 222 348 minecraft:dark_oak_planks
fill 59 222 337 62 223 337 minecraft:dark_oak_planks
fill 59 222 349 62 223 349 minecraft:dark_oak_planks
fill 63 222 364 63 227 364 minecraft:spruce_planks
fill 66 222 337 69 223 337 minecraft:dark_oak_planks
fill 66 222 349 69 223 349 minecraft:dark_oak_planks
fill 70 222 338 72 222 338 minecraft:dark_oak_planks
fill 70 222 348 72 222 348 minecraft:dark_oak_planks
fill 73 222 339 74 222 339 minecraft:dark_oak_planks
fill 73 222 347 74 222 347 minecraft:dark_oak_planks
setblock 75 222 340 minecraft:dark_oak_planks
setblock 75 222 346 minecraft:dark_oak_planks
fill 76 222 341 76 222 342 minecraft:dark_oak_planks
fill 76 222 344 76 222 345 minecraft:dark_oak_planks
fill 77 222 342 77 223 344 minecraft:dark_oak_planks
fill 89 222 341 89 224 341 minecraft:spruce_planks
fill 47 223 324 47 226 324 minecraft:spruce_planks
setblock 47 223 325 minecraft:dark_oak_planks
setblock 47 223 332 minecraft:dark_oak_planks
setblock 47 223 340 minecraft:dark_oak_planks
fill 47 223 363 47 223 364 minecraft:dark_oak_planks
setblock 50 223 322 minecraft:dark_oak_planks
setblock 51 223 341 minecraft:dark_oak_planks
setblock 51 223 345 minecraft:dark_oak_planks
setblock 52 223 340 minecraft:dark_oak_planks
setblock 52 223 346 minecraft:dark_oak_planks
fill 53 223 339 54 223 339 minecraft:dark_oak_planks
fill 53 223 347 54 223 347 minecraft:dark_oak_planks
fill 54 223 364 55 223 364 minecraft:dark_oak_planks
fill 55 223 338 56 223 338 minecraft:dark_oak_planks
fill 55 223 348 56 223 348 minecraft:dark_oak_planks
fill 57 223 322 58 223 322 minecraft:dark_oak_planks
fill 57 223 337 58 223 337 minecraft:dark_oak_planks
fill 57 223 349 58 223 349 minecraft:dark_oak_planks
fill 59 223 322 59 226 322 minecraft:spruce_planks
fill 64 223 364 65 223 364 minecraft:spruce_planks
setblock 66 223 364 minecraft:dark_oak_planks
fill 70 223 337 71 223 337 minecraft:dark_oak_planks
fill 70 223 349 71 223 349 minecraft:dark_oak_planks
fill 72 223 338 73 223 338 minecraft:dark_oak_planks
fill 72 223 348 73 223 348 minecraft:dark_oak_planks
fill 74 223 339 75 223 339 minecraft:dark_oak_planks
fill 74 223 347 75 223 347 minecraft:dark_oak_planks
setblock 75 223 364 minecraft:dark_oak_planks
setblock 76 223 340 minecraft:dark_oak_planks
setblock 76 223 346 minecraft:dark_oak_planks
setblock 77 223 341 minecraft:dark_oak_planks
setblock 77 223 345 minecraft:dark_oak_planks
fill 82 223 322 83 223 322 minecraft:dark_oak_planks
setblock 83 223 364 minecraft:dark_oak_planks
fill 84 223 364 84 226 364 minecraft:spruce_planks
setblock 85 223 364 minecraft:dark_oak_planks
fill 86 223 322 86 226 322 minecraft:spruce_planks
setblock 87 223 322 minecraft:dark_oak_planks
setblock 88 223 322 minecraft:spruce_planks
fill 88 223 364 89 223 364 minecraft:dark_oak_planks
setblock 89 223 322 minecraft:dark_oak_planks
setblock 89 223 328 minecraft:dark_oak_planks
fill 89 223 329 89 226 329 minecraft:spruce_planks
fill 89 223 357 89 226 357 minecraft:spruce_planks
setblock 89 223 358 minecraft:dark_oak_planks
fill 89 223 359 89 226 359 minecraft:spruce_planks
setblock 47 224 323 minecraft:dark_oak_planks
fill 47 224 325 47 226 325 minecraft:spruce_planks
fill 47 224 332 47 227 332 minecraft:spruce_planks
setblock 47 224 336 minecraft:red_concrete
fill 47 224 337 47 226 340 minecraft:spruce_planks
setblock 47 224 343 minecraft:dark_oak_planks
fill 47 224 363 47 226 363 minecraft:spruce_planks
setblock 47 224 364 minecraft:dark_oak_planks
fill 48 224 328 48 269 328 minecraft:stripped_dark_oak_log
fill 48 224 335 48 269 335 minecraft:stripped_dark_oak_log
fill 48 224 342 48 269 342 minecraft:stripped_dark_oak_log
fill 48 224 349 48 269 349 minecraft:stripped_dark_oak_log
fill 48 224 356 48 269 356 minecraft:stripped_dark_oak_log
fill 48 224 359 55 234 363 minecraft:stripped_dark_oak_log
fill 50 224 322 50 226 322 minecraft:spruce_planks
fill 50 224 323 50 269 323 minecraft:stripped_dark_oak_log
setblock 50 224 325 minecraft:light[level=15]
setblock 50 224 333 minecraft:light[level=15]
fill 50 224 335 51 224 335 minecraft:dark_oak_planks
setblock 50 224 341 minecraft:light[level=15]
setblock 50 224 349 minecraft:light[level=15]
setblock 50 224 357 minecraft:light[level=15]
fill 51 224 341 59 224 345 minecraft:spruce_planks
fill 52 224 325 52 224 326 minecraft:dark_oak_planks
fill 52 224 340 60 224 340 minecraft:spruce_planks
fill 52 224 346 60 224 346 minecraft:spruce_planks
fill 52 224 364 52 225 364 minecraft:dark_oak_planks
fill 53 224 339 62 224 339 minecraft:spruce_planks
fill 53 224 347 62 224 347 minecraft:spruce_planks
fill 54 224 364 55 226 364 minecraft:spruce_planks
fill 55 224 338 73 224 338 minecraft:spruce_planks
fill 55 224 348 73 224 348 minecraft:spruce_planks
fill 57 224 322 58 226 322 minecraft:spruce_planks
fill 57 224 323 57 269 323 minecraft:stripped_dark_oak_log
fill 57 224 337 71 224 337 minecraft:spruce_planks
fill 57 224 349 71 224 349 minecraft:spruce_planks
setblock 58 224 325 minecraft:light[level=15]
setblock 58 224 333 minecraft:light[level=15]
setblock 58 224 357 minecraft:light[level=15]
setblock 59 224 364 minecraft:dark_oak_planks
setblock 60 224 341 minecraft:spruce_planks
setblock 60 224 345 minecraft:spruce_planks
fill 60 224 364 61 226 364 minecraft:spruce_planks
fill 62 224 363 62 269 363 minecraft:stripped_dark_oak_log
fill 64 224 322 65 226 322 minecraft:spruce_planks
fill 64 224 323 64 269 323 minecraft:stripped_dark_oak_log
setblock 64 224 364 minecraft:dark_oak_planks
fill 65 224 364 66 226 364 minecraft:spruce_planks
setblock 66 224 322 minecraft:dark_oak_planks
setblock 66 224 325 minecraft:light[level=15]
setblock 66 224 333 minecraft:light[level=15]
fill 66 224 339 75 224 339 minecraft:spruce_planks
fill 66 224 347 75 224 347 minecraft:spruce_planks
setblock 66 224 357 minecraft:light[level=15]
fill 67 224 322 67 226 322 minecraft:spruce_planks
fill 67 224 327 68 231 327 minecraft:dark_oak_planks
fill 67 224 359 67 224 360 minecraft:dark_oak_planks
setblock 67 224 364 minecraft:red_concrete
setblock 68 224 322 minecraft:dark_oak_planks
fill 68 224 340 76 224 341 minecraft:spruce_planks
fill 68 224 345 76 224 346 minecraft:spruce_planks
fill 69 224 342 77 224 344 minecraft:spruce_planks
fill 69 224 363 69 269 363 minecraft:stripped_dark_oak_log
fill 70 224 322 70 227 322 minecraft:spruce_planks
setblock 71 224 322 minecraft:dark_oak_planks
fill 71 224 323 71 269 323 minecraft:stripped_dark_oak_log
fill 72 224 322 73 226 322 minecraft:spruce_planks
setblock 74 224 322 minecraft:red_concrete
setblock 74 224 325 minecraft:light[level=15]
setblock 74 224 333 minecraft:light[level=15]
setblock 74 224 349 minecraft:light[level=15]
setblock 74 224 357 minecraft:light[level=15]
fill 75 224 322 77 224 322 minecraft:spruce_planks
setblock 75 224 364 minecraft:spruce_planks
fill 76 224 357 88 225 363 minecraft:stripped_dark_oak_log
setblock 77 224 341 minecraft:spruce_planks
setblock 77 224 345 minecraft:spruce_planks
fill 78 224 323 78 269 323 minecraft:stripped_dark_oak_log
setblock 80 224 364 minecraft:dark_oak_planks
fill 82 224 322 83 226 322 minecraft:spruce_planks
setblock 82 224 325 minecraft:light[level=15]
setblock 82 224 333 minecraft:light[level=15]
setblock 82 224 341 minecraft:light[level=15]
setblock 82 224 349 minecraft:light[level=15]
fill 82 224 352 88 225 356 minecraft:stripped_dark_oak_log
fill 83 224 364 83 225 364 minecraft:spruce_planks
fill 85 224 323 85 269 323 minecraft:stripped_dark_oak_log
fill 85 224 364 85 225 364 minecraft:spruce_planks
fill 87 224 322 87 226 322 minecraft:spruce_planks
setblock 88 224 322 minecraft:dark_oak_planks
fill 88 224 327 88 269 327 minecraft:stripped_dark_oak_log
fill 88 224 334 88 269 334 minecraft:stripped_dark_oak_log
fill 88 224 341 88 269 341 minecraft:stripped_dark_oak_log
fill 88 224 348 88 269 348 minecraft:stripped_dark_oak_log
fill 88 224 364 89 226 364 minecraft:spruce_planks
setblock 89 224 322 minecraft:spruce_planks
setblock 89 224 326 minecraft:dark_oak_planks
fill 89 224 328 89 226 328 minecraft:spruce_planks
fill 89 224 333 89 226 333 minecraft:spruce_planks
setblock 89 224 334 minecraft:dark_oak_planks
fill 89 224 335 89 226 335 minecraft:spruce_planks
setblock 89 224 349 minecraft:dark_oak_planks
fill 89 224 358 89 226 358 minecraft:spruce_planks
fill 47 225 323 47 226 323 minecraft:spruce_planks
setblock 47 225 326 minecraft:dark_oak_planks
fill 47 225 336 47 226 336 minecraft:spruce_planks
fill 47 225 343 47 226 343 minecraft:spruce_planks
setblock 47 225 350 minecraft:dark_oak_planks
fill 47 225 364 47 226 364 minecraft:spruce_planks
setblock 48 225 329 minecraft:stripped_dark_oak_log
setblock 48 225 336 minecraft:stripped_dark_oak_log
setblock 48 225 343 minecraft:stripped_dark_oak_log
setblock 48 225 350 minecraft:stripped_dark_oak_log
setblock 48 225 357 minecraft:stripped_dark_oak_log
setblock 49 225 322 minecraft:red_concrete
setblock 49 225 323 minecraft:stripped_dark_oak_log
fill 49 225 335 50 225 335 minecraft:dark_oak_planks
fill 52 225 324 52 225 325 minecraft:dark_oak_planks
setblock 53 225 364 minecraft:dark_oak_planks
setblock 56 225 323 minecraft:stripped_dark_oak_log
setblock 56 225 363 minecraft:stripped_dark_oak_log
fill 57 225 343 57 228 343 minecraft:stripped_dark_oak_log
fill 59 225 364 59 226 364 minecraft:spruce_planks
setblock 63 225 323 minecraft:stripped_dark_oak_log
setblock 63 225 363 minecraft:stripped_dark_oak_log
fill 64 225 364 64 226 364 minecraft:spruce_planks
fill 66 225 322 66 226 322 minecraft:spruce_planks
fill 67 225 326 68 226 326 minecraft:dark_oak_planks
fill 67 225 328 67 231 328 minecraft:dark_oak_planks
fill 67 225 360 67 225 361 minecraft:dark_oak_planks
fill 67 225 364 68 226 364 minecraft:spruce_planks
fill 68 225 322 68 227 322 minecraft:spruce_planks
setblock 69 225 322 minecraft:dark_oak_planks
setblock 69 225 364 minecraft:dark_oak_planks
setblock 70 225 323 minecraft:stripped_dark_oak_log
setblock 70 225 363 minecraft:stripped_dark_oak_log
fill 70 225 364 70 226 364 minecraft:spruce_planks
fill 71 225 322 71 226 322 minecraft:spruce_planks
fill 72 225 364 73 226 364 minecraft:spruce_planks
fill 74 225 322 76 226 322 minecraft:spruce_planks
fill 74 225 364 75 225 364 minecraft:dark_oak_planks
setblock 77 225 322 minecraft:red_concrete
setblock 77 225 323 minecraft:stripped_dark_oak_log
fill 80 225 364 80 226 364 minecraft:spruce_planks
setblock 81 225 322 minecraft:dark_oak_planks
setblock 81 225 364 minecraft:dark_oak_planks
setblock 84 225 323 minecraft:stripped_dark_oak_log
fill 88 225 322 88 226 322 minecraft:spruce_planks
setblock 88 225 326 minecraft:stripped_dark_oak_log
setblock 88 225 333 minecraft:stripped_dark_oak_log
setblock 88 225 340 minecraft:stripped_dark_oak_log
setblock 88 225 347 minecraft:stripped_dark_oak_log
setblock 89 225 322 minecraft:dark_oak_planks
fill 89 225 326 89 226 326 minecraft:spruce_planks
setblock 89 225 330 minecraft:dark_oak_planks
fill 89 225 334 89 226 334 minecraft:spruce_planks
fill 89 225 340 89 225 341 minecraft:dark_oak_planks
fill 89 225 349 89 227 349 minecraft:spruce_planks
fill 89 225 353 89 226 353 minecraft:spruce_planks
setblock 89 225 354 minecraft:dark_oak_planks
setblock 89 225 361 minecraft:dark_oak_planks
fill 89 225 362 89 226 363 minecraft:spruce_planks
setblock 47 226 326 minecraft:spruce_planks
setblock 47 226 350 minecraft:spruce_planks
setblock 48 226 323 minecraft:stripped_dark_oak_log
setblock 48 226 330 minecraft:stripped_dark_oak_log
setblock 48 226 337 minecraft:stripped_dark_oak_log
setblock 48 226 344 minecraft:stripped_dark_oak_log
setblock 48 226 351 minecraft:stripped_dark_oak_log
setblock 48 226 358 minecraft:stripped_dark_oak_log
setblock 49 226 322 minecraft:spruce_planks
setblock 49 226 335 minecraft:dark_oak_planks
setblock 50 226 325 minecraft:light[level=12]
setblock 50 226 332 minecraft:light[level=12]
setblock 50 226 339 minecraft:light[level=12]
setblock 50 226 346 minecraft:light[level=12]
setblock 50 226 353 minecraft:light[level=12]
fill 52 226 323 52 226 324 minecraft:dark_oak_planks
fill 52 226 364 53 226 364 minecraft:spruce_planks
setblock 55 226 323 minecraft:stripped_dark_oak_log
setblock 57 226 325 minecraft:light[level=12]
setblock 57 226 332 minecraft:light[level=12]
setblock 57 226 339 minecraft:light[level=12]
setblock 57 226 346 minecraft:light[level=12]
setblock 57 226 353 minecraft:light[level=12]
setblock 57 226 360 minecraft:light[level=12]
setblock 57 226 363 minecraft:stripped_dark_oak_log
setblock 62 226 323 minecraft:stripped_dark_oak_log
setblock 64 226 325 minecraft:light[level=12]
setblock 64 226 332 minecraft:light[level=12]
setblock 64 226 339 minecraft:light[level=12]
setblock 64 226 346 minecraft:light[level=12]
setblock 64 226 353 minecraft:light[level=12]
setblock 64 226 360 minecraft:light[level=12]
setblock 64 226 363 minecraft:stripped_dark_oak_log
fill 66 226 326 66 227 327 minecraft:dark_oak_planks
fill 67 226 361 67 226 362 minecraft:dark_oak_planks
fill 68 226 328 68 231 328 minecraft:dark_oak_planks
setblock 69 226 322 minecraft:spruce_planks
setblock 69 226 323 minecraft:stripped_dark_oak_log
fill 69 226 326 69 227 327 minecraft:dark_oak_planks
setblock 69 226 364 minecraft:spruce_planks
setblock 71 226 325 minecraft:light[level=12]
setblock 71 226 332 minecraft:light[level=12]
setblock 71 226 339 minecraft:light[level=12]
setblock 71 226 346 minecraft:light[level=12]
setblock 71 226 353 minecraft:light[level=12]
setblock 71 226 360 minecraft:light[level=12]
setblock 71 226 363 minecraft:stripped_dark_oak_log
fill 74 226 364 75 226 364 minecraft:spruce_planks
setblock 76 226 323 minecraft:stripped_dark_oak_log
setblock 76 226 357 minecraft:shroomlight
fill 76 226 358 76 247 358 minecraft:stripped_dark_oak_log
setblock 76 226 359 minecraft:shroomlight
fill 76 226 360 76 247 360 minecraft:stripped_dark_oak_log
setblock 76 226 361 minecraft:shroomlight
fill 76 226 362 76 247 362 minecraft:stripped_dark_oak_log
setblock 76 226 363 minecraft:shroomlight
setblock 77 226 322 minecraft:spruce_planks
fill 77 226 357 77 247 357 minecraft:stripped_dark_oak_log
setblock 77 226 358 minecraft:shroomlight
fill 77 226 359 77 247 359 minecraft:stripped_dark_oak_log
setblock 77 226 360 minecraft:shroomlight
fill 77 226 361 77 247 361 minecraft:stripped_dark_oak_log
setblock 77 226 362 minecraft:shroomlight
fill 77 226 363 77 247 363 minecraft:stripped_dark_oak_log
setblock 78 226 325 minecraft:light[level=12]
setblock 78 226 332 minecraft:light[level=12]
setblock 78 226 339 minecraft:light[level=12]
setblock 78 226 346 minecraft:light[level=12]
setblock 78 226 353 minecraft:light[level=12]
setblock 78 226 357 minecraft:shroomlight
fill 78 226 358 78 247 358 minecraft:stripped_dark_oak_log
setblock 78 226 359 minecraft:shroomlight
fill 78 226 360 78 247 360 minecraft:stripped_dark_oak_log
setblock 78 226 361 minecraft:shroomlight
fill 78 226 362 78 247 362 minecraft:stripped_dark_oak_log
setblock 78 226 363 minecraft:shroomlight
fill 79 226 357 79 247 357 minecraft:stripped_dark_oak_log
setblock 79 226 358 minecraft:shroomlight
fill 79 226 359 79 247 359 minecraft:stripped_dark_oak_log
setblock 79 226 360 minecraft:shroomlight
fill 79 226 361 79 247 361 minecraft:stripped_dark_oak_log
setblock 79 226 362 minecraft:shroomlight
fill 79 226 363 79 248 363 minecraft:stripped_dark_oak_log
setblock 80 226 357 minecraft:shroomlight
fill 80 226 358 80 247 358 minecraft:stripped_dark_oak_log
setblock 80 226 359 minecraft:shroomlight
fill 80 226 360 80 247 360 minecraft:stripped_dark_oak_log
setblock 80 226 361 minecraft:shroomlight
fill 80 226 362 80 247 362 minecraft:stripped_dark_oak_log
setblock 80 226 363 minecraft:shroomlight
fill 81 226 322 81 227 322 minecraft:spruce_planks
fill 81 226 357 81 247 357 minecraft:stripped_dark_oak_log
setblock 81 226 358 minecraft:shroomlight
fill 81 226 359 81 247 359 minecraft:stripped_dark_oak_log
setblock 81 226 360 minecraft:shroomlight
fill 81 226 361 81 247 361 minecraft:stripped_dark_oak_log
setblock 81 226 362 minecraft:shroomlight
fill 81 226 363 81 247 363 minecraft:stripped_dark_oak_log
setblock 81 226 364 minecraft:spruce_planks
fill 82 226 352 82 247 352 minecraft:stripped_dark_oak_log
setblock 82 226 353 minecraft:shroomlight
fill 82 226 354 82 247 354 minecraft:stripped_dark_oak_log
setblock 82 226 355 minecraft:shroomlight
fill 82 226 356 82 247 356 minecraft:stripped_dark_oak_log
setblock 82 226 357 minecraft:shroomlight
fill 82 226 358 82 247 358 minecraft:stripped_dark_oak_log
setblock 82 226 359 minecraft:shroomlight
fill 82 226 360 82 247 360 minecraft:stripped_dark_oak_log
setblock 82 226 361 minecraft:shroomlight
fill 82 226 362 82 247 362 minecraft:stripped_dark_oak_log
setblock 82 226 363 minecraft:shroomlight
setblock 83 226 323 minecraft:stripped_dark_oak_log
setblock 83 226 352 minecraft:shroomlight
fill 83 226 353 83 247 353 minecraft:stripped_dark_oak_log
setblock 83 226 354 minecraft:shroomlight
fill 83 226 355 83 250 355 minecraft:stripped_dark_oak_log
setblock 83 226 356 minecraft:shroomlight
fill 83 226 357 83 250 357 minecraft:stripped_dark_oak_log
setblock 83 226 358 minecraft:shroomlight
fill 83 226 359 83 247 359 minecraft:stripped_dark_oak_log
setblock 83 226 360 minecraft:shroomlight
fill 83 226 361 83 247 361 minecraft:stripped_dark_oak_log
setblock 83 226 362 minecraft:shroomlight
fill 83 226 363 83 269 363 minecraft:stripped_dark_oak_log
setblock 83 226 364 minecraft:shroomlight
fill 84 226 352 84 247 352 minecraft:stripped_dark_oak_log
setblock 84 226 353 minecraft:shroomlight
fill 84 226 354 84 250 354 minecraft:stripped_dark_oak_log
setblock 84 226 355 minecraft:shroomlight
fill 84 226 356 84 250 356 minecraft:stripped_dark_oak_log
setblock 84 226 357 minecraft:shroomlight
fill 84 226 358 84 247 358 minecraft:stripped_dark_oak_log
setblock 84 226 359 minecraft:shroomlight
fill 84 226 360 84 247 360 minecraft:stripped_dark_oak_log
setblock 84 226 361 minecraft:shroomlight
fill 84 226 362 84 247 362 minecraft:stripped_dark_oak_log
setblock 84 226 363 minecraft:shroomlight
setblock 85 226 325 minecraft:light[level=12]
setblock 85 226 332 minecraft:light[level=12]
setblock 85 226 339 minecraft:light[level=12]
setblock 85 226 346 minecraft:light[level=12]
setblock 85 226 352 minecraft:shroomlight
fill 85 226 353 85 247 353 minecraft:stripped_dark_oak_log
setblock 85 226 354 minecraft:shroomlight
fill 85 226 355 85 250 355 minecraft:stripped_dark_oak_log
setblock 85 226 356 minecraft:shroomlight
fill 85 226 357 85 250 357 minecraft:stripped_dark_oak_log
setblock 85 226 358 minecraft:shroomlight
fill 85 226 359 85 247 359 minecraft:stripped_dark_oak_log
setblock 85 226 360 minecraft:shroomlight
fill 85 226 361 85 247 361 minecraft:stripped_dark_oak_log
setblock 85 226 362 minecraft:shroomlight
fill 85 226 363 85 250 363 minecraft:stripped_dark_oak_log
setblock 85 226 364 minecraft:shroomlight
fill 86 226 352 86 247 352 minecraft:stripped_dark_oak_log
setblock 86 226 353 minecraft:shroomlight
fill 86 226 354 86 250 354 minecraft:stripped_dark_oak_log
setblock 86 226 355 minecraft:shroomlight
fill 86 226 356 86 250 356 minecraft:stripped_dark_oak_log
setblock 86 226 357 minecraft:shroomlight
fill 86 226 358 86 247 358 minecraft:stripped_dark_oak_log
setblock 86 226 359 minecraft:shroomlight
fill 86 226 360 86 247 360 minecraft:stripped_dark_oak_log
setblock 86 226 361 minecraft:shroomlight
fill 86 226 362 86 247 362 minecraft:stripped_dark_oak_log
setblock 86 226 363 minecraft:shroomlight
setblock 87 226 352 minecraft:shroomlight
fill 87 226 353 87 247 353 minecraft:stripped_dark_oak_log
setblock 87 226 354 minecraft:shroomlight
fill 87 226 355 87 250 355 minecraft:stripped_dark_oak_log
setblock 87 226 356 minecraft:shroomlight
fill 87 226 357 87 250 357 minecraft:stripped_dark_oak_log
setblock 87 226 358 minecraft:shroomlight
fill 87 226 359 87 247 359 minecraft:stripped_dark_oak_log
setblock 87 226 360 minecraft:shroomlight
fill 87 226 361 87 247 361 minecraft:stripped_dark_oak_log
setblock 87 226 362 minecraft:shroomlight
fill 87 226 363 87 250 363 minecraft:stripped_dark_oak_log
setblock 87 226 364 minecraft:shroomlight
setblock 88 226 325 minecraft:stripped_dark_oak_log
setblock 88 226 332 minecraft:stripped_dark_oak_log
setblock 88 226 339 minecraft:stripped_dark_oak_log
setblock 88 226 346 minecraft:stripped_dark_oak_log
fill 88 226 352 88 248 352 minecraft:stripped_dark_oak_log
setblock 88 226 353 minecraft:shroomlight
fill 88 226 354 88 250 354 minecraft:stripped_dark_oak_log
setblock 88 226 355 minecraft:shroomlight
fill 88 226 356 88 251 356 minecraft:stripped_dark_oak_log
setblock 88 226 357 minecraft:shroomlight
fill 88 226 358 88 250 358 minecraft:stripped_dark_oak_log
setblock 88 226 359 minecraft:shroomlight
fill 88 226 360 88 250 360 minecraft:stripped_dark_oak_log
setblock 88 226 361 minecraft:shroomlight
fill 88 226 362 88 269 362 minecraft:stripped_dark_oak_log
setblock 88 226 363 minecraft:shroomlight
setblock 89 226 322 minecraft:spruce_planks
setblock 89 226 330 minecraft:spruce_planks
fill 89 226 340 89 226 341 minecraft:spruce_planks
setblock 89 226 354 minecraft:spruce_planks
setblock 89 226 361 minecraft:spruce_planks
fill 47 227 322 47 227 331 minecraft:dark_oak_planks
fill 47 227 333 47 227 352 minecraft:dark_oak_planks
fill 47 227 354 47 228 364 minecraft:dark_oak_planks
fill 48 227 322 60 227 322 minecraft:dark_oak_planks
fill 48 227 324 48 228 324 minecraft:stripped_dark_oak_log
fill 48 227 331 48 228 331 minecraft:stripped_dark_oak_log
fill 48 227 338 48 228 338 minecraft:stripped_dark_oak_log
fill 48 227 345 48 228 345 minecraft:stripped_dark_oak_log
fill 48 227 352 48 228 352 minecraft:stripped_dark_oak_log
fill 48 227 364 60 227 364 minecraft:dark_oak_planks
setblock 51 227 330 minecraft:shroomlight
setblock 51 227 336 minecraft:shroomlight
setblock 51 227 342 minecraft:shroomlight
setblock 51 227 348 minecraft:shroomlight
setblock 51 227 354 minecraft:shroomlight
setblock 52 227 323 minecraft:dark_oak_planks
fill 54 227 323 54 228 323 minecraft:stripped_dark_oak_log
setblock 55 227 326 minecraft:shroomlight
setblock 57 227 360 minecraft:shroomlight
fill 58 227 363 58 228 363 minecraft:stripped_dark_oak_log
setblock 61 227 322 minecraft:spruce_planks
fill 61 227 323 61 228 323 minecraft:stripped_dark_oak_log
setblock 61 227 326 minecraft:shroomlight
fill 61 227 364 61 228 364 minecraft:spruce_planks
fill 62 227 322 62 308 322 minecraft:dark_oak_planks
setblock 62 227 364 minecraft:dark_oak_planks
setblock 63 227 360 minecraft:shroomlight
fill 64 227 322 67 228 322 minecraft:dark_oak_planks
fill 64 227 364 66 274 364 minecraft:dark_oak_planks
fill 65 227 363 65 228 363 minecraft:stripped_dark_oak_log
fill 66 227 325 68 227 325 minecraft:dark_oak_planks
fill 66 227 328 66 231 328 minecraft:dark_oak_planks
setblock 67 227 326 minecraft:shroomlight
fill 67 227 329 68 231 329 minecraft:dark_oak_planks
setblock 67 227 362 minecraft:dark_oak_planks
setblock 67 227 364 minecraft:spruce_planks
fill 68 227 323 68 228 323 minecraft:stripped_dark_oak_log
setblock 68 227 326 minecraft:dark_oak_planks
fill 68 227 364 82 228 364 minecraft:dark_oak_planks
fill 69 227 322 69 308 322 minecraft:dark_oak_planks
fill 69 227 328 69 231 328 minecraft:dark_oak_planks
setblock 69 227 360 minecraft:shroomlight
fill 71 227 322 77 228 322 minecraft:dark_oak_planks
fill 72 227 363 72 228 363 minecraft:stripped_dark_oak_log
setblock 73 227 326 minecraft:shroomlight
fill 75 227 323 75 228 323 minecraft:stripped_dark_oak_log
setblock 75 227 360 minecraft:shroomlight
fill 76 227 357 76 228 357 minecraft:stripped_dark_oak_log
fill 76 227 359 76 228 359 minecraft:stripped_dark_oak_log
fill 76 227 361 76 228 361 minecraft:stripped_dark_oak_log
fill 76 227 363 76 228 363 minecraft:stripped_dark_oak_log
fill 77 227 358 77 228 358 minecraft:stripped_dark_oak_log
fill 77 227 360 77 228 360 minecraft:stripped_dark_oak_log
fill 77 227 362 77 228 362 minecraft:stripped_dark_oak_log
fill 78 227 357 78 228 357 minecraft:stripped_dark_oak_log
fill 78 227 359 78 228 359 minecraft:stripped_dark_oak_log
fill 78 227 361 78 228 361 minecraft:stripped_dark_oak_log
fill 78 227 363 78 228 363 minecraft:stripped_dark_oak_log
fill 79 227 322 79 308 322 minecraft:dark_oak_planks
setblock 79 227 326 minecraft:shroomlight
fill 79 227 358 79 228 358 minecraft:stripped_dark_oak_log
fill 79 227 360 79 228 360 minecraft:stripped_dark_oak_log
fill 79 227 362 79 228 362 minecraft:stripped_dark_oak_log
fill 80 227 357 80 228 357 minecraft:stripped_dark_oak_log
fill 80 227 359 80 228 359 minecraft:stripped_dark_oak_log
fill 80 227 361 80 228 361 minecraft:stripped_dark_oak_log
fill 80 227 363 80 228 363 minecraft:stripped_dark_oak_log
fill 81 227 358 81 228 358 minecraft:stripped_dark_oak_log
fill 81 227 360 81 228 360 minecraft:stripped_dark_oak_log
fill 81 227 362 81 228 362 minecraft:stripped_dark_oak_log
fill 82 227 322 85 227 322 minecraft:dark_oak_planks
fill 82 227 323 82 228 323 minecraft:stripped_dark_oak_log
fill 82 227 353 82 228 353 minecraft:stripped_dark_oak_log
fill 82 227 355 82 228 355 minecraft:stripped_dark_oak_log
fill 82 227 357 82 228 357 minecraft:stripped_dark_oak_log
fill 82 227 359 82 228 359 minecraft:stripped_dark_oak_log
fill 82 227 361 82 228 361 minecraft:stripped_dark_oak_log
fill 82 227 363 82 228 363 minecraft:stripped_dark_oak_log
fill 83 227 352 83 228 352 minecraft:stripped_dark_oak_log
fill 83 227 354 83 228 354 minecraft:stripped_dark_oak_log
fill 83 227 356 83 228 356 minecraft:stripped_dark_oak_log
fill 83 227 358 83 228 358 minecraft:stripped_dark_oak_log
fill 83 227 360 83 228 360 minecraft:stripped_dark_oak_log
fill 83 227 362 83 228 362 minecraft:stripped_dark_oak_log
setblock 83 227 364 minecraft:spruce_planks
fill 84 227 353 84 228 353 minecraft:stripped_dark_oak_log
fill 84 227 355 84 228 355 minecraft:stripped_dark_oak_log
fill 84 227 357 84 228 357 minecraft:stripped_dark_oak_log
fill 84 227 359 84 228 359 minecraft:stripped_dark_oak_log
fill 84 227 361 84 228 361 minecraft:stripped_dark_oak_log
fill 84 227 363 84 228 363 minecraft:stripped_dark_oak_log
fill 84 227 364 88 228 364 minecraft:dark_oak_planks
setblock 85 227 326 minecraft:shroomlight
setblock 85 227 332 minecraft:shroomlight
setblock 85 227 338 minecraft:shroomlight
setblock 85 227 344 minecraft:shroomlight
setblock 85 227 350 minecraft:shroomlight
fill 85 227 352 85 228 352 minecraft:stripped_dark_oak_log
fill 85 227 354 85 228 354 minecraft:stripped_dark_oak_log
fill 85 227 356 85 228 356 minecraft:stripped_dark_oak_log
fill 85 227 358 85 228 358 minecraft:stripped_dark_oak_log
fill 85 227 360 85 228 360 minecraft:stripped_dark_oak_log
fill 85 227 362 85 228 362 minecraft:stripped_dark_oak_log
setblock 86 227 322 minecraft:red_concrete
fill 86 227 353 86 228 353 minecraft:stripped_dark_oak_log
fill 86 227 355 86 228 355 minecraft:stripped_dark_oak_log
fill 86 227 357 86 228 357 minecraft:stripped_dark_oak_log
fill 86 227 359 86 228 359 minecraft:stripped_dark_oak_log
fill 86 227 361 86 228 361 minecraft:stripped_dark_oak_log
fill 86 227 363 86 228 363 minecraft:stripped_dark_oak_log
fill 87 227 322 89 308 322 minecraft:dark_oak_planks
fill 87 227 352 87 228 352 minecraft:stripped_dark_oak_log
fill 87 227 354 87 228 354 minecraft:stripped_dark_oak_log
fill 87 227 356 87 228 356 minecraft:stripped_dark_oak_log
fill 87 227 358 87 228 358 minecraft:stripped_dark_oak_log
fill 87 227 360 87 228 360 minecraft:stripped_dark_oak_log
fill 87 227 362 87 228 362 minecraft:stripped_dark_oak_log
fill 88 227 324 88 228 324 minecraft:stripped_dark_oak_log
fill 88 227 331 88 228 331 minecraft:stripped_dark_oak_log
fill 88 227 338 88 228 338 minecraft:stripped_dark_oak_log
fill 88 227 345 88 228 345 minecraft:stripped_dark_oak_log
fill 88 227 353 88 228 353 minecraft:stripped_dark_oak_log
fill 88 227 355 88 228 355 minecraft:stripped_dark_oak_log
fill 88 227 357 88 228 357 minecraft:stripped_dark_oak_log
fill 88 227 359 88 228 359 minecraft:stripped_dark_oak_log
fill 88 227 361 88 228 361 minecraft:stripped_dark_oak_log
fill 88 227 363 88 228 363 minecraft:stripped_dark_oak_log
fill 89 227 323 89 227 336 minecraft:dark_oak_planks
fill 89 227 338 89 228 342 minecraft:dark_oak_planks
fill 89 227 344 89 227 345 minecraft:dark_oak_planks
setblock 89 227 346 minecraft:spruce_planks
fill 89 227 347 89 308 348 minecraft:dark_oak_planks
fill 89 227 350 89 227 363 minecraft:dark_oak_planks
setblock 89 227 364 minecraft:spruce_planks
fill 47 228 322 47 233 324 minecraft:dark_oak_planks
setblock 47 228 325 minecraft:spruce_planks
fill 47 228 326 47 228 351 minecraft:dark_oak_planks
setblock 47 228 352 minecraft:spruce_planks
fill 47 228 353 47 301 353 minecraft:dark_oak_planks
setblock 48 228 322 minecraft:spruce_planks
fill 48 228 323 49 228 323 minecraft:stripped_dark_oak_log
fill 48 228 325 51 228 327 minecraft:stripped_dark_oak_log
fill 48 228 329 51 228 330 minecraft:stripped_dark_oak_log
fill 48 228 332 51 228 334 minecraft:stripped_dark_oak_log
fill 48 228 336 51 228 337 minecraft:stripped_dark_oak_log
fill 48 228 339 51 228 341 minecraft:stripped_dark_oak_log
fill 48 228 343 51 228 344 minecraft:stripped_dark_oak_log
fill 48 228 346 51 228 348 minecraft:stripped_dark_oak_log
fill 48 228 350 51 228 351 minecraft:stripped_dark_oak_log
fill 48 228 353 51 228 355 minecraft:stripped_dark_oak_log
fill 48 228 357 51 228 358 minecraft:stripped_dark_oak_log
setblock 48 228 364 minecraft:spruce_planks
fill 49 228 322 61 228 322 minecraft:dark_oak_planks
fill 49 228 324 87 228 324 minecraft:stripped_dark_oak_log
fill 49 228 328 51 228 328 minecraft:stripped_dark_oak_log
fill 49 228 331 51 228 331 minecraft:stripped_dark_oak_log
fill 49 228 335 51 228 335 minecraft:stripped_dark_oak_log
fill 49 228 338 51 228 338 minecraft:stripped_dark_oak_log
fill 49 228 342 51 228 342 minecraft:stripped_dark_oak_log
fill 49 228 345 51 228 345 minecraft:stripped_dark_oak_log
fill 49 228 349 51 228 349 minecraft:stripped_dark_oak_log
fill 49 228 352 51 228 352 minecraft:stripped_dark_oak_log
fill 49 228 356 51 228 356 minecraft:stripped_dark_oak_log
setblock 49 228 364 minecraft:dark_oak_planks
setblock 50 228 364 minecraft:spruce_planks
fill 51 228 323 53 228 323 minecraft:stripped_dark_oak_log
fill 51 228 364 52 308 364 minecraft:dark_oak_planks
fill 52 228 325 88 228 326 minecraft:stripped_dark_oak_log
setblock 53 228 364 minecraft:spruce_planks
fill 54 228 364 55 308 364 minecraft:dark_oak_planks
fill 55 228 323 56 228 323 minecraft:stripped_dark_oak_log
fill 56 228 360 57 228 363 minecraft:stripped_dark_oak_log
setblock 56 228 364 minecraft:spruce_planks
fill 57 228 364 58 228 364 minecraft:dark_oak_planks
fill 58 228 323 60 228 323 minecraft:stripped_dark_oak_log
fill 58 228 360 75 228 362 minecraft:stripped_dark_oak_log
fill 59 228 363 61 228 363 minecraft:stripped_dark_oak_log
setblock 59 228 364 minecraft:spruce_planks
fill 60 228 364 60 308 364 minecraft:dark_oak_planks
fill 62 228 323 63 228 323 minecraft:stripped_dark_oak_log
setblock 62 228 364 minecraft:spruce_planks
fill 63 228 322 63 308 322 minecraft:dark_oak_planks
fill 63 228 363 64 228 363 minecraft:stripped_dark_oak_log
fill 63 228 364 63 308 364 minecraft:dark_oak_planks
fill 65 228 323 67 228 323 minecraft:stripped_dark_oak_log
fill 65 228 327 65 231 328 minecraft:dark_oak_planks
fill 66 228 327 66 231 327 minecraft:dark_oak_planks
fill 66 228 329 66 231 329 minecraft:dark_oak_planks
fill 66 228 363 68 228 363 minecraft:stripped_dark_oak_log
fill 67 228 364 67 308 364 minecraft:dark_oak_planks
fill 68 228 322 68 308 322 minecraft:dark_oak_planks
fill 69 228 323 70 228 323 minecraft:stripped_dark_oak_log
fill 69 228 327 70 231 327 minecraft:dark_oak_planks
fill 69 228 329 69 231 329 minecraft:dark_oak_planks
fill 70 228 322 70 308 322 minecraft:dark_oak_planks
fill 70 228 363 71 228 363 minecraft:stripped_dark_oak_log
fill 72 228 323 74 228 323 minecraft:stripped_dark_oak_log
fill 73 228 363 75 228 363 minecraft:stripped_dark_oak_log
fill 76 228 323 77 228 323 minecraft:stripped_dark_oak_log
fill 78 228 322 78 261 322 minecraft:dark_oak_planks
fill 79 228 323 81 228 323 minecraft:stripped_dark_oak_log
fill 80 228 322 83 228 322 minecraft:dark_oak_planks
fill 83 228 323 84 228 323 minecraft:stripped_dark_oak_log
setblock 83 228 364 minecraft:dark_oak_planks
setblock 84 228 322 minecraft:spruce_planks
setblock 85 228 322 minecraft:dark_oak_planks
fill 85 228 327 87 228 351 minecraft:stripped_dark_oak_log
setblock 86 228 322 minecraft:spruce_planks
fill 86 228 323 88 228 323 minecraft:stripped_dark_oak_log
fill 88 228 328 88 228 330 minecraft:stripped_dark_oak_log
fill 88 228 332 88 228 333 minecraft:stripped_dark_oak_log
fill 88 228 335 88 228 337 minecraft:stripped_dark_oak_log
fill 88 228 339 88 228 340 minecraft:stripped_dark_oak_log
fill 88 228 342 88 228 344 minecraft:stripped_dark_oak_log
fill 88 228 346 88 228 347 minecraft:stripped_dark_oak_log
fill 88 228 349 88 228 351 minecraft:stripped_dark_oak_log
fill 89 228 323 89 228 329 minecraft:dark_oak_planks
setblock 89 228 330 minecraft:spruce_planks
fill 89 228 331 89 250 336 minecraft:dark_oak_planks
fill 89 228 343 89 308 344 minecraft:dark_oak_planks
setblock 89 228 345 minecraft:spruce_planks
fill 89 228 346 89 259 346 minecraft:dark_oak_planks
fill 89 228 349 89 228 357 minecraft:dark_oak_planks
setblock 89 228 358 minecraft:spruce_planks
fill 89 228 359 89 228 364 minecraft:dark_oak_planks
fill 47 229 325 47 283 336 minecraft:dark_oak_planks
setblock 47 229 337 minecraft:spruce_planks
fill 47 229 338 47 251 350 minecraft:dark_oak_planks
setblock 47 229 351 minecraft:spruce_planks
fill 47 229 352 47 308 352 minecraft:dark_oak_planks
fill 47 229 354 47 302 356 minecraft:dark_oak_planks
setblock 47 229 357 minecraft:spruce_planks
fill 47 229 358 47 253 358 minecraft:dark_oak_planks
setblock 47 229 359 minecraft:spruce_planks
fill 47 229 360 47 308 361 minecraft:dark_oak_planks
setblock 47 229 362 minecraft:spruce_planks
fill 47 229 363 47 308 364 minecraft:dark_oak_planks
fill 48 229 322 56 240 322 minecraft:dark_oak_planks
fill 48 229 326 48 230 326 minecraft:stripped_dark_oak_log
fill 48 229 333 48 230 333 minecraft:stripped_dark_oak_log
fill 48 229 340 48 230 340 minecraft:stripped_dark_oak_log
fill 48 229 347 48 230 347 minecraft:stripped_dark_oak_log
fill 48 229 354 48 230 354 minecraft:stripped_dark_oak_log
fill 48 229 364 48 308 364 minecraft:dark_oak_planks
fill 49 229 348 49 234 352 minecraft:red_wool
setblock 49 229 364 minecraft:spruce_planks
fill 50 229 364 50 308 364 minecraft:dark_oak_planks
fill 51 229 326 51 229 358 minecraft:red_concrete
fill 52 229 323 52 230 323 minecraft:stripped_dark_oak_log
fill 52 229 326 85 229 326 minecraft:red_concrete
fill 52 229 347 52 230 347 minecraft:dark_oak_planks
fill 53 229 364 53 308 364 minecraft:dark_oak_planks
fill 56 229 360 75 229 360 minecraft:red_concrete
fill 56 229 364 57 246 364 minecraft:dark_oak_planks
setblock 57 229 322 minecraft:spruce_planks
fill 57 229 339 57 238 347 minecraft:white_wool
fill 58 229 322 61 251 322 minecraft:dark_oak_planks
fill 58 229 358 58 230 358 minecraft:dark_oak_planks
setblock 58 229 364 minecraft:spruce_planks
fill 59 229 323 59 230 323 minecraft:stripped_dark_oak_log
fill 59 229 364 59 247 364 minecraft:dark_oak_planks
fill 60 229 363 60 230 363 minecraft:stripped_dark_oak_log
fill 61 229 358 61 230 358 minecraft:dark_oak_planks
fill 61 229 364 62 286 364 minecraft:dark_oak_planks
fill 64 229 322 64 289 322 minecraft:dark_oak_planks
setblock 65 229 322 minecraft:red_concrete
fill 65 229 325 70 231 325 minecraft:dark_oak_planks
fill 65 229 329 65 231 329 minecraft:dark_oak_planks
fill 66 229 322 67 243 322 minecraft:dark_oak_planks
fill 66 229 323 66 230 323 minecraft:stripped_dark_oak_log
fill 66 229 324 69 231 324 minecraft:dark_oak_planks
fill 67 229 330 67 231 330 minecraft:dark_oak_planks
fill 67 229 363 67 230 363 minecraft:stripped_dark_oak_log
fill 68 229 364 68 275 364 minecraft:dark_oak_planks
setblock 69 229 364 minecraft:spruce_planks
fill 70 229 328 70 231 328 minecraft:dark_oak_planks
fill 70 229 364 74 263 364 minecraft:dark_oak_planks
fill 71 229 322 73 248 322 minecraft:dark_oak_planks
fill 73 229 323 73 230 323 minecraft:stripped_dark_oak_log
setblock 74 229 322 minecraft:spruce_planks
fill 74 229 363 74 230 363 minecraft:stripped_dark_oak_log
fill 75 229 322 77 261 322 minecraft:dark_oak_planks
setblock 75 229 364 minecraft:spruce_planks
setblock 76 229 357 minecraft:shroomlight
setblock 76 229 359 minecraft:shroomlight
setblock 76 229 361 minecraft:shroomlight
setblock 76 229 363 minecraft:shroomlight
fill 76 229 364 82 252 364 minecraft:dark_oak_planks
setblock 77 229 358 minecraft:shroomlight
setblock 77 229 360 minecraft:shroomlight
setblock 77 229 362 minecraft:shroomlight
setblock 78 229 357 minecraft:shroomlight
setblock 78 229 359 minecraft:shroomlight
setblock 78 229 361 minecraft:shroomlight
setblock 78 229 363 minecraft:shroomlight
setblock 79 229 358 minecraft:shroomlight
setblock 79 229 360 minecraft:shroomlight
setblock 79 229 362 minecraft:shroomlight
fill 80 229 322 80 308 322 minecraft:dark_oak_planks
fill 80 229 323 80 230 323 minecraft:stripped_dark_oak_log
setblock 80 229 357 minecraft:shroomlight
setblock 80 229 359 minecraft:shroomlight
setblock 80 229 361 minecraft:shroomlight
setblock 80 229 363 minecraft:shroomlight
setblock 81 229 322 minecraft:spruce_planks
setblock 81 229 358 minecraft:shroomlight
setblock 81 229 360 minecraft:shroomlight
setblock 81 229 362 minecraft:shroomlight
fill 82 229 322 84 308 322 minecraft:dark_oak_planks
setblock 82 229 353 minecraft:shroomlight
setblock 82 229 355 minecraft:shroomlight
setblock 82 229 357 minecraft:shroomlight
setblock 82 229 359 minecraft:shroomlight
setblock 82 229 361 minecraft:shroomlight
setblock 82 229 363 minecraft:shroomlight
fill 83 229 327 83 230 327 minecraft:dark_oak_planks
setblock 83 229 352 minecraft:shroomlight
setblock 83 229 354 minecraft:shroomlight
setblock 83 229 356 minecraft:shroomlight
setblock 83 229 358 minecraft:shroomlight
setblock 83 229 360 minecraft:shroomlight
setblock 83 229 362 minecraft:shroomlight
setblock 83 229 364 minecraft:shroomlight
setblock 84 229 353 minecraft:shroomlight
setblock 84 229 355 minecraft:shroomlight
setblock 84 229 357 minecraft:shroomlight
setblock 84 229 359 minecraft:shroomlight
setblock 84 229 361 minecraft:shroomlight
setblock 84 229 363 minecraft:shroomlight
fill 84 229 364 84 308 364 minecraft:dark_oak_planks
setblock 85 229 322 minecraft:spruce_planks
fill 85 229 327 85 229 351 minecraft:red_concrete
setblock 85 229 352 minecraft:shroomlight
setblock 85 229 354 minecraft:shroomlight
setblock 85 229 356 minecraft:shroomlight
setblock 85 229 358 minecraft:shroomlight
setblock 85 229 360 minecraft:shroomlight
setblock 85 229 362 minecraft:shroomlight
setblock 85 229 364 minecraft:shroomlight
fill 86 229 322 86 308 322 minecraft:dark_oak_planks
fill 86 229 345 86 234 345 minecraft:red_wool
setblock 86 229 353 minecraft:shroomlight
setblock 86 229 355 minecraft:shroomlight
setblock 86 229 357 minecraft:shroomlight
setblock 86 229 359 minecraft:shroomlight
setblock 86 229 361 minecraft:shroomlight
setblock 86 229 363 minecraft:shroomlight
fill 86 229 364 86 308 364 minecraft:dark_oak_planks
fill 87 229 323 87 230 323 minecraft:stripped_dark_oak_log
setblock 87 229 352 minecraft:shroomlight
setblock 87 229 354 minecraft:shroomlight
setblock 87 229 356 minecraft:shroomlight
setblock 87 229 358 minecraft:shroomlight
setblock 87 229 360 minecraft:shroomlight
setblock 87 229 362 minecraft:shroomlight
setblock 87 229 364 minecraft:shroomlight
fill 88 229 329 88 230 329 minecraft:stripped_dark_oak_log
fill 88 229 336 88 230 336 minecraft:stripped_dark_oak_log
fill 88 229 343 88 230 343 minecraft:stripped_dark_oak_log
fill 88 229 350 88 230 350 minecraft:stripped_dark_oak_log
setblock 88 229 353 minecraft:shroomlight
setblock 88 229 355 minecraft:shroomlight
setblock 88 229 357 minecraft:shroomlight
setblock 88 229 359 minecraft:shroomlight
setblock 88 229 361 minecraft:shroomlight
setblock 88 229 363 minecraft:shroomlight
fill 88 229 364 89 249 364 minecraft:dark_oak_planks
setblock 89 229 323 minecraft:spruce_planks
fill 89 229 324 89 262 325 minecraft:dark_oak_planks
setblock 89 229 326 minecraft:spruce_planks
fill 89 229 327 89 308 330 minecraft:dark_oak_planks
fill 89 229 338 89 246 340 minecraft:dark_oak_planks
setblock 89 229 341 minecraft:spruce_planks
fill 89 229 342 89 308 342 minecraft:dark_oak_planks
fill 89 229 345 89 308 345 minecraft:dark_oak_planks
fill 89 229 349 89 236 353 minecraft:dark_oak_planks
setblock 89 229 354 minecraft:spruce_planks
fill 89 229 355 89 246 359 minecraft:dark_oak_planks
setblock 89 229 360 minecraft:spruce_planks
fill 89 229 361 89 308 363 minecraft:dark_oak_planks
fill 47 230 337 47 258 337 minecraft:dark_oak_planks
fill 47 230 351 47 308 351 minecraft:dark_oak_planks
fill 47 230 357 47 308 357 minecraft:dark_oak_planks
fill 47 230 359 47 287 359 minecraft:dark_oak_planks
fill 47 230 362 47 308 362 minecraft:dark_oak_planks
fill 48 230 323 48 230 325 minecraft:stripped_dark_oak_log
setblock 48 230 327 minecraft:stripped_dark_oak_log
fill 48 230 329 48 230 332 minecraft:stripped_dark_oak_log
setblock 48 230 334 minecraft:stripped_dark_oak_log
fill 48 230 336 48 230 339 minecraft:stripped_dark_oak_log
setblock 48 230 341 minecraft:stripped_dark_oak_log
fill 48 230 343 48 230 346 minecraft:stripped_dark_oak_log
setblock 48 230 348 minecraft:stripped_dark_oak_log
fill 48 230 350 48 230 353 minecraft:stripped_dark_oak_log
setblock 48 230 355 minecraft:stripped_dark_oak_log
fill 48 230 357 48 230 358 minecraft:stripped_dark_oak_log
setblock 49 230 323 minecraft:stripped_dark_oak_log
fill 49 230 364 49 308 364 minecraft:dark_oak_planks
setblock 51 230 323 minecraft:stripped_dark_oak_log
fill 51 230 347 51 231 347 minecraft:dark_oak_planks
fill 53 230 323 56 230 323 minecraft:stripped_dark_oak_log
fill 56 230 363 59 230 363 minecraft:stripped_dark_oak_log
fill 57 230 322 57 308 322 minecraft:dark_oak_planks
setblock 58 230 323 minecraft:stripped_dark_oak_log
fill 58 230 359 58 231 359 minecraft:dark_oak_planks
fill 58 230 364 58 308 364 minecraft:dark_oak_planks
fill 60 230 323 63 230 323 minecraft:stripped_dark_oak_log
fill 61 230 359 61 231 359 minecraft:dark_oak_planks
setblock 61 230 363 minecraft:stripped_dark_oak_log
fill 63 230 363 66 230 363 minecraft:stripped_dark_oak_log
fill 64 230 326 64 231 328 minecraft:dark_oak_planks
fill 65 230 322 65 269 322 minecraft:dark_oak_planks
setblock 65 230 323 minecraft:stripped_dark_oak_log
fill 65 230 324 65 231 324 minecraft:dark_oak_planks
fill 65 230 326 71 231 326 minecraft:dark_oak_planks
fill 66 230 330 66 231 330 minecraft:dark_oak_planks
fill 67 230 323 70 230 323 minecraft:stripped_dark_oak_log
fill 68 230 330 69 231 330 minecraft:dark_oak_planks
setblock 68 230 363 minecraft:stripped_dark_oak_log
fill 69 230 364 69 300 364 minecraft:dark_oak_planks
fill 70 230 329 70 231 329 minecraft:dark_oak_planks
fill 70 230 363 73 230 363 minecraft:stripped_dark_oak_log
fill 71 230 327 71 231 327 minecraft:dark_oak_planks
setblock 72 230 323 minecraft:stripped_dark_oak_log
fill 74 230 322 74 308 322 minecraft:dark_oak_planks
fill 74 230 323 77 230 323 minecraft:stripped_dark_oak_log
fill 75 230 363 76 230 363 minecraft:stripped_dark_oak_log
fill 75 230 364 75 308 364 minecraft:dark_oak_planks
fill 76 230 357 76 231 357 minecraft:stripped_dark_oak_log
fill 76 230 359 76 231 359 minecraft:stripped_dark_oak_log
fill 76 230 361 76 231 361 minecraft:stripped_dark_oak_log
fill 77 230 358 77 231 358 minecraft:stripped_dark_oak_log
fill 77 230 360 77 231 360 minecraft:stripped_dark_oak_log
fill 77 230 362 77 231 362 minecraft:stripped_dark_oak_log
fill 78 230 357 78 231 357 minecraft:stripped_dark_oak_log
fill 78 230 359 78 231 359 minecraft:stripped_dark_oak_log
fill 78 230 361 78 231 361 minecraft:stripped_dark_oak_log
fill 78 230 363 78 231 363 minecraft:stripped_dark_oak_log
setblock 79 230 323 minecraft:stripped_dark_oak_log
fill 79 230 358 79 231 358 minecraft:stripped_dark_oak_log
fill 79 230 360 79 231 360 minecraft:stripped_dark_oak_log
fill 79 230 362 79 231 362 minecraft:stripped_dark_oak_log
fill 80 230 357 80 231 357 minecraft:stripped_dark_oak_log
fill 80 230 359 80 231 359 minecraft:stripped_dark_oak_log
fill 80 230 361 80 231 361 minecraft:stripped_dark_oak_log
fill 80 230 363 80 231 363 minecraft:stripped_dark_oak_log
fill 81 230 322 81 308 322 minecraft:dark_oak_planks
fill 81 230 323 84 230 323 minecraft:stripped_dark_oak_log
fill 81 230 333 81 231 333 minecraft:shroomlight
fill 81 230 358 81 231 358 minecraft:stripped_dark_oak_log
fill 81 230 360 81 231 360 minecraft:stripped_dark_oak_log
fill 81 230 362 81 231 362 minecraft:stripped_dark_oak_log
fill 82 230 353 82 231 353 minecraft:stripped_dark_oak_log
fill 82 230 355 82 231 355 minecraft:stripped_dark_oak_log
fill 82 230 357 82 231 357 minecraft:stripped_dark_oak_log
fill 82 230 359 82 231 359 minecraft:stripped_dark_oak_log
fill 82 230 361 82 231 361 minecraft:stripped_dark_oak_log
fill 82 230 363 82 231 363 minecraft:stripped_dark_oak_log
fill 83 230 352 83 231 352 minecraft:stripped_dark_oak_log
fill 83 230 354 83 231 354 minecraft:stripped_dark_oak_log
fill 83 230 356 83 231 356 minecraft:stripped_dark_oak_log
fill 83 230 358 83 231 358 minecraft:stripped_dark_oak_log
fill 83 230 360 83 231 360 minecraft:stripped_dark_oak_log
fill 83 230 362 83 231 362 minecraft:stripped_dark_oak_log
fill 83 230 364 83 231 364 minecraft:dark_oak_planks
fill 84 230 327 84 231 327 minecraft:dark_oak_planks
fill 84 230 353 84 231 353 minecraft:stripped_dark_oak_log
fill 84 230 355 84 231 355 minecraft:stripped_dark_oak_log
fill 84 230 357 84 231 357 minecraft:stripped_dark_oak_log
fill 84 230 359 84 231 359 minecraft:stripped_dark_oak_log
fill 84 230 361 84 231 361 minecraft:stripped_dark_oak_log
fill 84 230 363 84 231 363 minecraft:stripped_dark_oak_log
fill 85 230 322 85 308 322 minecraft:dark_oak_planks
fill 85 230 352 85 231 352 minecraft:stripped_dark_oak_log
fill 85 230 354 85 231 354 minecraft:stripped_dark_oak_log
fill 85 230 356 85 231 356 minecraft:stripped_dark_oak_log
fill 85 230 358 85 231 358 minecraft:stripped_dark_oak_log
fill 85 230 360 85 231 360 minecraft:stripped_dark_oak_log
fill 85 230 362 85 231 362 minecraft:stripped_dark_oak_log
fill 85 230 364 85 231 364 minecraft:dark_oak_planks
setblock 86 230 323 minecraft:stripped_dark_oak_log
fill 86 230 343 86 234 344 minecraft:red_wool
fill 86 230 346 86 234 347 minecraft:red_wool
fill 86 230 353 86 231 353 minecraft:stripped_dark_oak_log
fill 86 230 355 86 231 355 minecraft:stripped_dark_oak_log
fill 86 230 357 86 231 357 minecraft:stripped_dark_oak_log
fill 86 230 359 86 231 359 minecraft:stripped_dark_oak_log
fill 86 230 361 86 231 361 minecraft:stripped_dark_oak_log
fill 86 230 363 86 231 363 minecraft:stripped_dark_oak_log
fill 87 230 352 87 231 352 minecraft:stripped_dark_oak_log
fill 87 230 354 87 231 354 minecraft:stripped_dark_oak_log
fill 87 230 356 87 231 356 minecraft:stripped_dark_oak_log
fill 87 230 358 87 231 358 minecraft:stripped_dark_oak_log
fill 87 230 360 87 231 360 minecraft:stripped_dark_oak_log
fill 87 230 362 87 231 362 minecraft:stripped_dark_oak_log
fill 87 230 364 87 231 364 minecraft:dark_oak_planks
fill 88 230 323 88 230 326 minecraft:stripped_dark_oak_log
setblock 88 230 328 minecraft:stripped_dark_oak_log
fill 88 230 330 88 230 333 minecraft:stripped_dark_oak_log
setblock 88 230 335 minecraft:stripped_dark_oak_log
fill 88 230 337 88 230 340 minecraft:stripped_dark_oak_log
setblock 88 230 342 minecraft:stripped_dark_oak_log
fill 88 230 344 88 230 347 minecraft:stripped_dark_oak_log
setblock 88 230 349 minecraft:stripped_dark_oak_log
setblock 88 230 351 minecraft:stripped_dark_oak_log
fill 88 230 353 88 231 353 minecraft:stripped_dark_oak_log
fill 88 230 355 88 231 355 minecraft:stripped_dark_oak_log
fill 88 230 357 88 231 357 minecraft:stripped_dark_oak_log
fill 88 230 359 88 231 359 minecraft:stripped_dark_oak_log
fill 88 230 361 88 231 361 minecraft:stripped_dark_oak_log
fill 88 230 363 88 231 363 minecraft:stripped_dark_oak_log
fill 89 230 323 89 308 323 minecraft:dark_oak_planks
fill 89 230 326 89 308 326 minecraft:dark_oak_planks
fill 89 230 337 89 308 337 minecraft:dark_oak_planks
fill 89 230 341 89 308 341 minecraft:dark_oak_planks
fill 89 230 354 89 308 354 minecraft:dark_oak_planks
fill 89 230 360 89 267 360 minecraft:dark_oak_planks
fill 50 231 347 50 232 347 minecraft:dark_oak_planks
fill 58 231 360 58 232 360 minecraft:dark_oak_planks
fill 61 231 360 61 232 360 minecraft:dark_oak_planks
setblock 64 231 325 minecraft:dark_oak_planks
setblock 64 231 329 minecraft:dark_oak_planks
setblock 65 231 330 minecraft:dark_oak_planks
fill 66 231 323 69 231 323 minecraft:dark_oak_planks
setblock 70 231 324 minecraft:dark_oak_planks
setblock 70 231 330 minecraft:dark_oak_planks
setblock 71 231 325 minecraft:dark_oak_planks
setblock 71 231 328 minecraft:dark_oak_planks
setblock 76 231 363 minecraft:stripped_dark_oak_log
fill 85 231 327 85 232 327 minecraft:dark_oak_planks
setblock 48 232 329 minecraft:stripped_dark_oak_log
setblock 48 232 336 minecraft:stripped_dark_oak_log
setblock 48 232 343 minecraft:stripped_dark_oak_log
setblock 48 232 350 minecraft:stripped_dark_oak_log
setblock 48 232 357 minecraft:stripped_dark_oak_log
setblock 49 232 323 minecraft:stripped_dark_oak_log
fill 49 232 347 49 233 347 minecraft:dark_oak_planks
setblock 50 232 325 minecraft:light[level=15]
setblock 50 232 332 minecraft:light[level=12]
setblock 50 232 333 minecraft:light[level=15]
setblock 50 232 339 minecraft:light[level=12]
setblock 50 232 341 minecraft:light[level=15]
setblock 50 232 346 minecraft:light[level=12]
setblock 50 232 349 minecraft:light[level=15]
setblock 50 232 353 minecraft:light[level=12]
setblock 50 232 357 minecraft:light[level=15]
setblock 56 232 323 minecraft:stripped_dark_oak_log
setblock 56 232 363 minecraft:stripped_dark_oak_log
setblock 57 232 325 minecraft:light[level=12]
setblock 57 232 332 minecraft:light[level=12]
setblock 57 232 353 minecraft:light[level=12]
setblock 57 232 360 minecraft:light[level=12]
setblock 58 232 325 minecraft:light[level=15]
setblock 58 232 333 minecraft:light[level=15]
setblock 58 232 341 minecraft:light[level=15]
setblock 58 232 349 minecraft:light[level=15]
setblock 58 232 357 minecraft:light[level=15]
fill 58 232 361 58 233 361 minecraft:dark_oak_planks
fill 60 232 323 60 233 325 minecraft:iron_bars
fill 61 232 361 61 233 361 minecraft:dark_oak_planks
setblock 63 232 323 minecraft:stripped_dark_oak_log
setblock 63 232 361 minecraft:red_concrete
setblock 63 232 363 minecraft:stripped_dark_oak_log
setblock 64 232 325 minecraft:light[level=12]
setblock 64 232 332 minecraft:light[level=12]
setblock 64 232 339 minecraft:light[level=12]
setblock 64 232 346 minecraft:light[level=12]
setblock 64 232 353 minecraft:light[level=12]
setblock 64 232 360 minecraft:light[level=12]
setblock 66 232 325 minecraft:light[level=15]
setblock 66 232 333 minecraft:light[level=15]
setblock 66 232 341 minecraft:light[level=15]
setblock 66 232 349 minecraft:light[level=15]
setblock 66 232 357 minecraft:light[level=15]
fill 67 232 327 67 235 327 minecraft:stripped_dark_oak_log
setblock 70 232 323 minecraft:stripped_dark_oak_log
setblock 70 232 363 minecraft:stripped_dark_oak_log
setblock 71 232 325 minecraft:light[level=12]
setblock 71 232 332 minecraft:light[level=12]
setblock 71 232 339 minecraft:light[level=12]
setblock 71 232 346 minecraft:light[level=12]
setblock 71 232 353 minecraft:light[level=12]
setblock 71 232 360 minecraft:light[level=12]
setblock 74 232 325 minecraft:light[level=15]
setblock 74 232 333 minecraft:light[level=15]
setblock 74 232 341 minecraft:light[level=15]
setblock 74 232 349 minecraft:light[level=15]
setblock 74 232 357 minecraft:light[level=15]
setblock 76 232 357 minecraft:shroomlight
setblock 76 232 359 minecraft:shroomlight
setblock 76 232 361 minecraft:shroomlight
setblock 76 232 363 minecraft:shroomlight
setblock 77 232 323 minecraft:stripped_dark_oak_log
setblock 77 232 358 minecraft:shroomlight
setblock 77 232 360 minecraft:shroomlight
setblock 77 232 362 minecraft:shroomlight
setblock 78 232 325 minecraft:light[level=12]
setblock 78 232 332 minecraft:light[level=12]
setblock 78 232 339 minecraft:light[level=12]
setblock 78 232 346 minecraft:light[level=12]
setblock 78 232 353 minecraft:light[level=12]
setblock 78 232 357 minecraft:shroomlight
setblock 78 232 359 minecraft:shroomlight
setblock 78 232 361 minecraft:shroomlight
setblock 78 232 363 minecraft:shroomlight
setblock 79 232 358 minecraft:shroomlight
setblock 79 232 360 minecraft:shroomlight
setblock 79 232 362 minecraft:shroomlight
setblock 80 232 357 minecraft:shroomlight
setblock 80 232 359 minecraft:shroomlight
setblock 80 232 361 minecraft:shroomlight
setblock 80 232 363 minecraft:shroomlight
fill 81 232 333 81 242 333 minecraft:dark_oak_planks
setblock 81 232 358 minecraft:shroomlight
setblock 81 232 360 minecraft:shroomlight
setblock 81 232 362 minecraft:shroomlight
setblock 82 232 325 minecraft:light[level=15]
setblock 82 232 333 minecraft:light[level=15]
setblock 82 232 341 minecraft:light[level=15]
setblock 82 232 349 minecraft:light[level=15]
setblock 82 232 353 minecraft:shroomlight
setblock 82 232 355 minecraft:shroomlight
setblock 82 232 357 minecraft:shroomlight
setblock 82 232 359 minecraft:shroomlight
setblock 82 232 361 minecraft:shroomlight
setblock 82 232 363 minecraft:shroomlight
setblock 83 232 352 minecraft:shroomlight
setblock 83 232 354 minecraft:shroomlight
setblock 83 232 356 minecraft:shroomlight
setblock 83 232 358 minecraft:shroomlight
setblock 83 232 360 minecraft:shroomlight
setblock 83 232 362 minecraft:shroomlight
setblock 83 232 364 minecraft:shroomlight
setblock 84 232 323 minecraft:stripped_dark_oak_log
setblock 84 232 353 minecraft:shroomlight
setblock 84 232 355 minecraft:shroomlight
setblock 84 232 357 minecraft:shroomlight
setblock 84 232 359 minecraft:shroomlight
setblock 84 232 361 minecraft:shroomlight
setblock 84 232 363 minecraft:shroomlight
setblock 85 232 325 minecraft:light[level=12]
setblock 85 232 332 minecraft:light[level=12]
setblock 85 232 339 minecraft:light[level=12]
setblock 85 232 346 minecraft:light[level=12]
setblock 85 232 352 minecraft:shroomlight
setblock 85 232 354 minecraft:shroomlight
setblock 85 232 356 minecraft:shroomlight
setblock 85 232 358 minecraft:shroomlight
setblock 85 232 360 minecraft:shroomlight
setblock 85 232 362 minecraft:shroomlight
setblock 85 232 364 minecraft:shroomlight
fill 86 232 327 86 233 327 minecraft:dark_oak_planks
setblock 86 232 353 minecraft:shroomlight
setblock 86 232 355 minecraft:shroomlight
setblock 86 232 357 minecraft:shroomlight
setblock 86 232 359 minecraft:shroomlight
setblock 86 232 361 minecraft:shroomlight
setblock 86 232 363 minecraft:shroomlight
setblock 87 232 352 minecraft:shroomlight
setblock 87 232 354 minecraft:shroomlight
setblock 87 232 356 minecraft:shroomlight
setblock 87 232 358 minecraft:shroomlight
setblock 87 232 360 minecraft:shroomlight
setblock 87 232 362 minecraft:shroomlight
setblock 87 232 364 minecraft:shroomlight
setblock 88 232 326 minecraft:stripped_dark_oak_log
setblock 88 232 333 minecraft:stripped_dark_oak_log
setblock 88 232 340 minecraft:stripped_dark_oak_log
setblock 88 232 347 minecraft:stripped_dark_oak_log
setblock 88 232 353 minecraft:shroomlight
setblock 88 232 355 minecraft:shroomlight
setblock 88 232 357 minecraft:shroomlight
setblock 88 232 359 minecraft:shroomlight
setblock 88 232 361 minecraft:shroomlight
setblock 88 232 363 minecraft:shroomlight
setblock 48 233 323 minecraft:stripped_dark_oak_log
setblock 48 233 330 minecraft:stripped_dark_oak_log
setblock 48 233 337 minecraft:stripped_dark_oak_log
setblock 48 233 344 minecraft:stripped_dark_oak_log
fill 48 233 347 48 234 347 minecraft:dark_oak_planks
setblock 48 233 351 minecraft:stripped_dark_oak_log
setblock 48 233 358 minecraft:stripped_dark_oak_log
setblock 55 233 323 minecraft:stripped_dark_oak_log
setblock 57 233 363 minecraft:stripped_dark_oak_log
fill 58 233 362 58 234 362 minecraft:dark_oak_planks
fill 61 233 362 61 234 362 minecraft:dark_oak_planks
setblock 62 233 323 minecraft:stripped_dark_oak_log
fill 63 233 361 63 234 361 minecraft:shroomlight
setblock 64 233 363 minecraft:stripped_dark_oak_log
setblock 69 233 323 minecraft:stripped_dark_oak_log
setblock 71 233 363 minecraft:stripped_dark_oak_log
setblock 76 233 323 minecraft:stripped_dark_oak_log
fill 76 233 357 76 234 357 minecraft:stripped_dark_oak_log
schedule function dropper:buildpart/73_4 1t
