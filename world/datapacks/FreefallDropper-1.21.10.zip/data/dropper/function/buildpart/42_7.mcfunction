fill 285 160 213 285 163 213 minecraft:red_nether_bricks
setblock 285 160 222 minecraft:polished_blackstone
setblock 286 160 182 minecraft:red_nether_bricks
setblock 286 160 207 minecraft:red_nether_bricks
setblock 286 160 211 minecraft:polished_blackstone
setblock 286 160 222 minecraft:red_nether_bricks
fill 296 160 182 299 160 182 minecraft:red_nether_bricks
setblock 298 160 183 minecraft:red_nether_bricks
setblock 299 160 183 minecraft:polished_blackstone
fill 299 160 184 299 161 184 minecraft:red_nether_bricks
setblock 300 160 182 minecraft:polished_blackstone
fill 300 160 183 300 163 183 minecraft:red_nether_bricks
setblock 300 160 222 minecraft:polished_blackstone
fill 301 160 182 304 160 182 minecraft:red_nether_bricks
fill 301 160 222 304 160 222 minecraft:red_nether_bricks
setblock 302 160 184 minecraft:red_nether_bricks
setblock 302 160 185 minecraft:polished_blackstone
setblock 303 160 184 minecraft:polished_blackstone
fill 303 160 185 303 161 185 minecraft:red_nether_bricks
setblock 304 160 183 minecraft:polished_blackstone
fill 304 160 184 304 162 184 minecraft:red_nether_bricks
setblock 305 160 182 minecraft:polished_blackstone
fill 305 160 183 305 162 183 minecraft:red_nether_bricks
fill 306 160 182 309 160 182 minecraft:red_nether_bricks
setblock 308 160 184 minecraft:polished_blackstone
setblock 309 160 183 minecraft:polished_blackstone
setblock 310 160 182 minecraft:polished_blackstone
setblock 310 160 183 minecraft:red_nether_bricks
fill 310 160 184 310 160 185 minecraft:polished_blackstone
fill 311 160 182 311 162 182 minecraft:red_nether_bricks
fill 311 160 184 311 183 184 minecraft:gilded_blackstone
fill 311 160 185 312 160 185 minecraft:polished_blackstone
setblock 312 160 184 minecraft:polished_blackstone
setblock 314 160 183 minecraft:polished_blackstone
setblock 315 160 182 minecraft:polished_blackstone
fill 315 160 183 315 162 183 minecraft:red_nether_bricks
setblock 315 160 222 minecraft:polished_blackstone
fill 316 160 182 316 163 182 minecraft:red_nether_bricks
fill 316 160 222 316 163 222 minecraft:red_nether_bricks
setblock 318 160 184 minecraft:polished_blackstone
setblock 319 160 183 minecraft:polished_blackstone
fill 319 160 184 319 162 184 minecraft:red_nether_bricks
setblock 320 160 182 minecraft:polished_blackstone
fill 320 160 183 320 163 183 minecraft:red_nether_bricks
setblock 320 160 187 minecraft:polished_blackstone
setblock 320 160 188 minecraft:red_nether_bricks
setblock 320 160 222 minecraft:polished_blackstone
fill 321 160 182 321 163 182 minecraft:red_nether_bricks
setblock 321 160 186 minecraft:polished_blackstone
fill 321 160 187 321 163 187 minecraft:red_nether_bricks
setblock 321 160 191 minecraft:polished_blackstone
setblock 321 160 206 minecraft:polished_blackstone
fill 321 160 207 321 160 210 minecraft:red_nether_bricks
setblock 321 160 211 minecraft:polished_blackstone
fill 321 160 212 321 163 212 minecraft:red_nether_bricks
setblock 321 160 216 minecraft:polished_blackstone
setblock 321 160 221 minecraft:polished_blackstone
fill 321 160 222 321 163 222 minecraft:red_nether_bricks
setblock 322 160 185 minecraft:polished_blackstone
fill 322 160 186 322 163 186 minecraft:red_nether_bricks
setblock 322 160 190 minecraft:polished_blackstone
fill 322 160 191 322 163 191 minecraft:red_nether_bricks
fill 322 160 203 322 160 204 minecraft:red_nether_bricks
setblock 322 160 205 minecraft:polished_blackstone
fill 322 160 206 322 160 209 minecraft:red_nether_bricks
setblock 322 160 210 minecraft:polished_blackstone
fill 322 160 211 322 163 211 minecraft:red_nether_bricks
setblock 322 160 215 minecraft:polished_blackstone
fill 322 160 216 322 163 216 minecraft:red_nether_bricks
setblock 322 160 220 minecraft:polished_blackstone
fill 322 160 221 322 163 221 minecraft:red_nether_bricks
setblock 323 160 184 minecraft:polished_blackstone
fill 323 160 185 323 163 185 minecraft:red_nether_bricks
setblock 323 160 189 minecraft:polished_blackstone
fill 323 160 190 323 163 190 minecraft:red_nether_bricks
setblock 323 160 194 minecraft:polished_blackstone
fill 323 160 195 323 162 195 minecraft:red_nether_bricks
fill 323 160 200 323 160 203 minecraft:red_nether_bricks
setblock 323 160 204 minecraft:polished_blackstone
fill 323 160 205 323 160 208 minecraft:red_nether_bricks
setblock 323 160 209 minecraft:polished_blackstone
fill 323 160 210 323 163 210 minecraft:red_nether_bricks
setblock 323 160 214 minecraft:polished_blackstone
fill 323 160 215 323 163 215 minecraft:red_nether_bricks
setblock 323 160 219 minecraft:polished_blackstone
fill 323 160 220 323 163 220 minecraft:red_nether_bricks
setblock 283 161 183 minecraft:polished_blackstone
fill 283 161 184 283 162 184 minecraft:red_nether_bricks
setblock 283 161 188 minecraft:polished_blackstone
fill 283 161 189 283 161 192 minecraft:red_nether_bricks
setblock 283 161 193 minecraft:polished_blackstone
fill 283 161 194 283 164 194 minecraft:red_nether_bricks
setblock 283 161 198 minecraft:polished_blackstone
fill 283 161 199 283 161 202 minecraft:red_nether_bricks
setblock 283 161 203 minecraft:polished_blackstone
fill 283 161 204 283 161 207 minecraft:red_nether_bricks
setblock 283 161 208 minecraft:polished_blackstone
fill 283 161 209 283 161 212 minecraft:red_nether_bricks
setblock 283 161 213 minecraft:polished_blackstone
fill 283 161 214 283 164 214 minecraft:red_nether_bricks
setblock 283 161 218 minecraft:polished_blackstone
fill 283 161 219 283 164 219 minecraft:red_nether_bricks
setblock 284 161 182 minecraft:polished_blackstone
setblock 284 161 187 minecraft:polished_blackstone
fill 284 161 188 284 162 188 minecraft:red_nether_bricks
setblock 284 161 202 minecraft:polished_blackstone
fill 284 161 203 284 161 206 minecraft:red_nether_bricks
setblock 284 161 207 minecraft:polished_blackstone
fill 284 161 208 284 164 208 minecraft:red_nether_bricks
setblock 284 161 212 minecraft:polished_blackstone
fill 284 161 213 284 164 213 minecraft:red_nether_bricks
setblock 284 161 217 minecraft:polished_blackstone
fill 284 161 218 284 162 218 minecraft:red_nether_bricks
setblock 284 161 222 minecraft:polished_blackstone
setblock 285 161 182 minecraft:red_nether_bricks
setblock 285 161 206 minecraft:polished_blackstone
fill 285 161 207 285 162 207 minecraft:red_nether_bricks
setblock 285 161 211 minecraft:polished_blackstone
fill 285 161 212 285 164 212 minecraft:red_nether_bricks
setblock 285 161 222 minecraft:red_nether_bricks
fill 297 161 182 298 161 182 minecraft:red_nether_bricks
setblock 298 161 183 minecraft:polished_blackstone
setblock 299 161 182 minecraft:polished_blackstone
fill 299 161 183 299 163 183 minecraft:red_nether_bricks
fill 300 161 182 303 161 182 minecraft:red_nether_bricks
setblock 301 161 184 minecraft:red_nether_bricks
setblock 302 161 184 minecraft:polished_blackstone
setblock 302 161 185 minecraft:red_nether_bricks
setblock 303 161 183 minecraft:polished_blackstone
fill 303 161 184 303 162 184 minecraft:red_nether_bricks
setblock 304 161 182 minecraft:polished_blackstone
fill 304 161 183 304 163 183 minecraft:red_nether_bricks
fill 305 161 182 308 161 182 minecraft:red_nether_bricks
setblock 308 161 183 minecraft:polished_blackstone
setblock 309 161 182 minecraft:polished_blackstone
setblock 309 161 183 minecraft:red_nether_bricks
fill 310 161 182 310 162 182 minecraft:red_nether_bricks
setblock 313 161 183 minecraft:polished_blackstone
setblock 314 161 182 minecraft:polished_blackstone
setblock 314 161 183 minecraft:red_nether_bricks
fill 315 161 182 315 164 182 minecraft:red_nether_bricks
setblock 315 161 222 minecraft:red_nether_bricks
setblock 317 161 184 minecraft:polished_blackstone
setblock 318 161 183 minecraft:polished_blackstone
fill 318 161 184 318 162 184 minecraft:red_nether_bricks
setblock 319 161 182 minecraft:polished_blackstone
fill 319 161 183 319 164 183 minecraft:red_nether_bricks
setblock 319 161 222 minecraft:polished_blackstone
fill 320 161 182 320 164 182 minecraft:red_nether_bricks
setblock 320 161 221 minecraft:polished_blackstone
fill 320 161 222 320 164 222 minecraft:red_nether_bricks
setblock 321 161 185 minecraft:polished_blackstone
fill 321 161 186 321 162 186 minecraft:red_nether_bricks
setblock 321 161 189 minecraft:red_nether_bricks
setblock 321 161 190 minecraft:polished_blackstone
fill 321 161 207 321 161 209 minecraft:red_nether_bricks
setblock 321 161 210 minecraft:polished_blackstone
fill 321 161 211 321 164 211 minecraft:red_nether_bricks
fill 321 161 213 321 161 214 minecraft:red_nether_bricks
setblock 321 161 215 minecraft:polished_blackstone
fill 321 161 216 321 163 217 minecraft:red_nether_bricks
fill 321 161 221 321 164 221 minecraft:red_nether_bricks
setblock 322 161 184 minecraft:polished_blackstone
fill 322 161 185 322 163 185 minecraft:red_nether_bricks
setblock 322 161 189 minecraft:polished_blackstone
fill 322 161 190 322 164 190 minecraft:red_nether_bricks
setblock 322 161 204 minecraft:polished_blackstone
fill 322 161 205 322 161 208 minecraft:red_nether_bricks
setblock 322 161 209 minecraft:polished_blackstone
fill 322 161 210 322 164 210 minecraft:red_nether_bricks
setblock 322 161 214 minecraft:polished_blackstone
fill 322 161 215 322 164 215 minecraft:red_nether_bricks
setblock 322 161 219 minecraft:polished_blackstone
fill 322 161 220 322 164 220 minecraft:red_nether_bricks
setblock 323 161 183 minecraft:polished_blackstone
fill 323 161 184 323 164 184 minecraft:red_nether_bricks
setblock 323 161 188 minecraft:polished_blackstone
fill 323 161 189 323 164 189 minecraft:red_nether_bricks
setblock 323 161 193 minecraft:polished_blackstone
fill 323 161 194 323 164 194 minecraft:red_nether_bricks
setblock 323 161 202 minecraft:red_nether_bricks
setblock 323 161 203 minecraft:polished_blackstone
fill 323 161 204 323 161 207 minecraft:red_nether_bricks
setblock 323 161 208 minecraft:polished_blackstone
fill 323 161 209 323 164 209 minecraft:red_nether_bricks
setblock 323 161 213 minecraft:polished_blackstone
fill 323 161 214 323 164 214 minecraft:red_nether_bricks
setblock 323 161 218 minecraft:polished_blackstone
fill 323 161 219 323 164 219 minecraft:red_nether_bricks
setblock 283 162 182 minecraft:polished_blackstone
setblock 283 162 183 minecraft:red_nether_bricks
setblock 283 162 187 minecraft:polished_blackstone
fill 283 162 188 283 162 191 minecraft:red_nether_bricks
setblock 283 162 192 minecraft:polished_blackstone
fill 283 162 193 283 165 193 minecraft:red_nether_bricks
setblock 283 162 197 minecraft:polished_blackstone
fill 283 162 198 283 162 201 minecraft:red_nether_bricks
setblock 283 162 202 minecraft:polished_blackstone
fill 283 162 203 283 162 206 minecraft:red_nether_bricks
setblock 283 162 207 minecraft:polished_blackstone
fill 283 162 208 283 162 211 minecraft:red_nether_bricks
setblock 283 162 212 minecraft:polished_blackstone
fill 283 162 213 283 165 213 minecraft:red_nether_bricks
setblock 283 162 217 minecraft:polished_blackstone
fill 283 162 218 283 165 218 minecraft:red_nether_bricks
setblock 283 162 221 minecraft:red_nether_bricks
setblock 283 162 222 minecraft:polished_blackstone
fill 284 162 203 284 162 205 minecraft:red_nether_bricks
setblock 284 162 206 minecraft:polished_blackstone
fill 284 162 207 284 165 207 minecraft:red_nether_bricks
setblock 284 162 211 minecraft:polished_blackstone
fill 284 162 212 284 165 212 minecraft:red_nether_bricks
setblock 284 162 216 minecraft:polished_blackstone
fill 284 162 217 284 163 217 minecraft:red_nether_bricks
setblock 284 162 222 minecraft:red_nether_bricks
setblock 285 162 206 minecraft:red_nether_bricks
setblock 285 162 210 minecraft:polished_blackstone
fill 285 162 211 285 164 211 minecraft:red_nether_bricks
setblock 297 162 182 minecraft:red_nether_bricks
setblock 298 162 182 minecraft:polished_blackstone
setblock 298 162 183 minecraft:red_nether_bricks
fill 299 162 182 302 162 182 minecraft:red_nether_bricks
setblock 301 162 184 minecraft:polished_blackstone
setblock 302 162 183 minecraft:polished_blackstone
setblock 302 162 184 minecraft:red_nether_bricks
setblock 303 162 182 minecraft:polished_blackstone
fill 303 162 183 303 163 183 minecraft:red_nether_bricks
fill 304 162 182 307 162 182 minecraft:red_nether_bricks
setblock 308 162 182 minecraft:polished_blackstone
setblock 309 162 182 minecraft:red_nether_bricks
setblock 313 162 182 minecraft:polished_blackstone
fill 314 162 182 314 165 182 minecraft:red_nether_bricks
setblock 317 162 183 minecraft:polished_blackstone
setblock 317 162 184 minecraft:red_nether_bricks
setblock 318 162 182 minecraft:polished_blackstone
fill 318 162 183 318 164 183 minecraft:red_nether_bricks
setblock 318 162 222 minecraft:polished_blackstone
fill 319 162 182 319 165 182 minecraft:red_nether_bricks
setblock 319 162 221 minecraft:polished_blackstone
fill 319 162 222 319 165 222 minecraft:red_nether_bricks
fill 320 162 221 320 165 221 minecraft:red_nether_bricks
setblock 321 162 184 minecraft:polished_blackstone
setblock 321 162 185 minecraft:red_nether_bricks
setblock 321 162 189 minecraft:polished_blackstone
setblock 321 162 190 minecraft:red_nether_bricks
setblock 321 162 208 minecraft:red_nether_bricks
setblock 321 162 209 minecraft:polished_blackstone
fill 321 162 210 321 165 210 minecraft:red_nether_bricks
setblock 321 162 213 minecraft:red_nether_bricks
setblock 321 162 214 minecraft:polished_blackstone
fill 321 162 215 321 165 215 minecraft:red_nether_bricks
setblock 322 162 183 minecraft:polished_blackstone
fill 322 162 184 322 163 184 minecraft:red_nether_bricks
setblock 322 162 188 minecraft:polished_blackstone
fill 322 162 189 322 164 189 minecraft:red_nether_bricks
setblock 322 162 192 minecraft:red_nether_bricks
fill 322 162 205 322 162 207 minecraft:red_nether_bricks
setblock 322 162 208 minecraft:polished_blackstone
fill 322 162 209 322 165 209 minecraft:red_nether_bricks
setblock 322 162 213 minecraft:polished_blackstone
fill 322 162 214 322 165 214 minecraft:red_nether_bricks
setblock 322 162 218 minecraft:polished_blackstone
fill 322 162 219 322 165 219 minecraft:red_nether_bricks
setblock 323 162 182 minecraft:polished_blackstone
fill 323 162 183 323 164 183 minecraft:red_nether_bricks
setblock 323 162 187 minecraft:polished_blackstone
fill 323 162 188 323 165 188 minecraft:red_nether_bricks
setblock 323 162 192 minecraft:polished_blackstone
fill 323 162 193 323 165 193 minecraft:red_nether_bricks
fill 323 162 203 323 162 206 minecraft:red_nether_bricks
setblock 323 162 207 minecraft:polished_blackstone
fill 323 162 208 323 165 208 minecraft:red_nether_bricks
setblock 323 162 212 minecraft:polished_blackstone
fill 323 162 213 323 165 213 minecraft:red_nether_bricks
setblock 323 162 217 minecraft:polished_blackstone
fill 323 162 218 323 165 218 minecraft:red_nether_bricks
setblock 323 162 222 minecraft:polished_blackstone
setblock 283 163 186 minecraft:polished_blackstone
fill 283 163 187 283 163 190 minecraft:red_nether_bricks
setblock 283 163 191 minecraft:polished_blackstone
fill 283 163 192 283 166 192 minecraft:red_nether_bricks
setblock 283 163 196 minecraft:polished_blackstone
setblock 283 163 201 minecraft:polished_blackstone
fill 283 163 202 283 163 205 minecraft:red_nether_bricks
setblock 283 163 206 minecraft:polished_blackstone
fill 283 163 207 283 163 210 minecraft:red_nether_bricks
setblock 283 163 211 minecraft:polished_blackstone
fill 283 163 212 283 166 212 minecraft:red_nether_bricks
setblock 283 163 216 minecraft:polished_blackstone
fill 283 163 217 283 166 217 minecraft:red_nether_bricks
setblock 283 163 221 minecraft:polished_blackstone
setblock 283 163 222 minecraft:red_nether_bricks
setblock 284 163 205 minecraft:polished_blackstone
fill 284 163 206 284 164 206 minecraft:red_nether_bricks
setblock 284 163 210 minecraft:polished_blackstone
fill 284 163 211 284 166 211 minecraft:red_nether_bricks
setblock 284 163 215 minecraft:polished_blackstone
fill 284 163 216 284 166 216 minecraft:red_nether_bricks
setblock 285 163 209 minecraft:polished_blackstone
setblock 285 163 210 minecraft:red_nether_bricks
fill 298 163 182 301 163 182 minecraft:red_nether_bricks
setblock 301 163 183 minecraft:polished_blackstone
setblock 302 163 182 minecraft:polished_blackstone
setblock 302 163 183 minecraft:red_nether_bricks
fill 303 163 182 306 163 182 minecraft:red_nether_bricks
setblock 307 163 182 minecraft:polished_blackstone
setblock 313 163 182 minecraft:red_nether_bricks
setblock 316 163 183 minecraft:polished_blackstone
setblock 317 163 182 minecraft:polished_blackstone
fill 317 163 183 317 164 183 minecraft:red_nether_bricks
setblock 317 163 222 minecraft:polished_blackstone
fill 318 163 182 318 166 182 minecraft:red_nether_bricks
setblock 318 163 221 minecraft:polished_blackstone
fill 318 163 222 318 166 222 minecraft:red_nether_bricks
fill 319 163 221 319 166 221 minecraft:red_nether_bricks
setblock 321 163 183 minecraft:polished_blackstone
setblock 321 163 188 minecraft:polished_blackstone
setblock 321 163 189 minecraft:red_nether_bricks
setblock 321 163 209 minecraft:red_nether_bricks
setblock 321 163 213 minecraft:polished_blackstone
fill 321 163 214 321 166 214 minecraft:red_nether_bricks
setblock 322 163 182 minecraft:polished_blackstone
setblock 322 163 183 minecraft:red_nether_bricks
setblock 322 163 187 minecraft:polished_blackstone
fill 322 163 188 322 164 188 minecraft:red_nether_bricks
setblock 322 163 192 minecraft:polished_blackstone
setblock 322 163 206 minecraft:red_nether_bricks
setblock 322 163 207 minecraft:polished_blackstone
fill 322 163 208 322 165 208 minecraft:red_nether_bricks
setblock 322 163 212 minecraft:polished_blackstone
fill 322 163 213 322 166 213 minecraft:red_nether_bricks
setblock 322 163 217 minecraft:polished_blackstone
fill 322 163 218 322 166 218 minecraft:red_nether_bricks
setblock 322 163 222 minecraft:polished_blackstone
fill 323 163 182 323 164 182 minecraft:red_nether_bricks
setblock 323 163 186 minecraft:polished_blackstone
fill 323 163 187 323 165 187 minecraft:red_nether_bricks
setblock 323 163 191 minecraft:polished_blackstone
fill 323 163 192 323 166 192 minecraft:red_nether_bricks
fill 323 163 204 323 163 205 minecraft:red_nether_bricks
setblock 323 163 206 minecraft:polished_blackstone
fill 323 163 207 323 166 207 minecraft:red_nether_bricks
setblock 323 163 211 minecraft:polished_blackstone
fill 323 163 212 323 166 212 minecraft:red_nether_bricks
setblock 323 163 216 minecraft:polished_blackstone
fill 323 163 217 323 166 217 minecraft:red_nether_bricks
setblock 323 163 221 minecraft:polished_blackstone
fill 323 163 222 323 166 222 minecraft:red_nether_bricks
fill 283 164 187 283 164 189 minecraft:red_nether_bricks
setblock 283 164 190 minecraft:polished_blackstone
fill 283 164 191 283 167 191 minecraft:red_nether_bricks
setblock 283 164 195 minecraft:polished_blackstone
fill 283 164 196 283 167 196 minecraft:red_nether_bricks
fill 283 164 202 283 164 204 minecraft:red_nether_bricks
setblock 283 164 205 minecraft:polished_blackstone
fill 283 164 206 283 164 209 minecraft:red_nether_bricks
setblock 283 164 210 minecraft:polished_blackstone
fill 283 164 211 283 167 211 minecraft:red_nether_bricks
setblock 283 164 215 minecraft:polished_blackstone
fill 283 164 216 283 167 216 minecraft:red_nether_bricks
setblock 283 164 220 minecraft:polished_blackstone
setblock 284 164 209 minecraft:polished_blackstone
fill 284 164 210 284 167 210 minecraft:red_nether_bricks
setblock 284 164 214 minecraft:polished_blackstone
fill 284 164 215 284 167 215 minecraft:red_nether_bricks
setblock 285 164 184 minecraft:light[level=14]
setblock 285 164 192 minecraft:light[level=14]
setblock 285 164 200 minecraft:light[level=14]
setblock 285 164 208 minecraft:light[level=14]
setblock 285 164 216 minecraft:light[level=14]
setblock 293 164 184 minecraft:light[level=14]
setblock 293 164 192 minecraft:light[level=14]
setblock 293 164 200 minecraft:light[level=14]
setblock 293 164 208 minecraft:light[level=14]
setblock 293 164 216 minecraft:light[level=14]
fill 298 164 182 300 164 182 minecraft:red_nether_bricks
setblock 301 164 182 minecraft:polished_blackstone
setblock 301 164 183 minecraft:red_nether_bricks
setblock 301 164 184 minecraft:light[level=14]
setblock 301 164 192 minecraft:light[level=14]
setblock 301 164 200 minecraft:light[level=14]
setblock 301 164 216 minecraft:light[level=14]
fill 302 164 182 304 164 182 minecraft:red_nether_bricks
setblock 309 164 184 minecraft:light[level=14]
setblock 309 164 192 minecraft:light[level=14]
setblock 309 164 200 minecraft:light[level=14]
setblock 309 164 208 minecraft:light[level=14]
setblock 309 164 216 minecraft:light[level=14]
setblock 315 164 222 minecraft:red_nether_bricks
setblock 316 164 182 minecraft:polished_blackstone
setblock 316 164 222 minecraft:polished_blackstone
fill 317 164 182 317 167 182 minecraft:red_nether_bricks
setblock 317 164 184 minecraft:light[level=14]
setblock 317 164 192 minecraft:light[level=14]
setblock 317 164 200 minecraft:light[level=14]
fill 317 164 203 317 164 205 minecraft:polished_blackstone
setblock 317 164 208 minecraft:light[level=14]
setblock 317 164 216 minecraft:light[level=14]
fill 317 164 222 317 167 222 minecraft:red_nether_bricks
fill 318 164 202 320 164 202 minecraft:polished_blackstone
fill 318 164 206 320 164 206 minecraft:polished_blackstone
fill 318 164 221 318 167 221 minecraft:red_nether_bricks
setblock 320 164 183 minecraft:polished_blackstone
setblock 321 164 182 minecraft:polished_blackstone
fill 321 164 203 321 164 205 minecraft:polished_blackstone
setblock 321 164 212 minecraft:polished_blackstone
fill 321 164 213 321 167 213 minecraft:red_nether_bricks
setblock 321 164 216 minecraft:red_nether_bricks
setblock 321 164 217 minecraft:polished_blackstone
setblock 321 164 222 minecraft:polished_blackstone
fill 322 164 182 322 165 182 minecraft:red_nether_bricks
setblock 322 164 186 minecraft:polished_blackstone
setblock 322 164 187 minecraft:red_nether_bricks
setblock 322 164 191 minecraft:polished_blackstone
setblock 322 164 207 minecraft:red_nether_bricks
setblock 322 164 211 minecraft:polished_blackstone
fill 322 164 212 322 167 212 minecraft:red_nether_bricks
setblock 322 164 216 minecraft:polished_blackstone
fill 322 164 217 322 167 217 minecraft:red_nether_bricks
setblock 322 164 221 minecraft:polished_blackstone
fill 322 164 222 322 167 222 minecraft:red_nether_bricks
setblock 323 164 185 minecraft:polished_blackstone
fill 323 164 186 323 165 186 minecraft:red_nether_bricks
setblock 323 164 190 minecraft:polished_blackstone
fill 323 164 191 323 167 191 minecraft:red_nether_bricks
setblock 323 164 205 minecraft:polished_blackstone
fill 323 164 206 323 165 206 minecraft:red_nether_bricks
setblock 323 164 210 minecraft:polished_blackstone
fill 323 164 211 323 167 211 minecraft:red_nether_bricks
setblock 323 164 215 minecraft:polished_blackstone
fill 323 164 216 323 167 216 minecraft:red_nether_bricks
setblock 323 164 220 minecraft:polished_blackstone
fill 323 164 221 323 167 221 minecraft:red_nether_bricks
setblock 283 165 188 minecraft:red_nether_bricks
setblock 283 165 189 minecraft:polished_blackstone
fill 283 165 190 283 168 190 minecraft:red_nether_bricks
setblock 283 165 194 minecraft:polished_blackstone
fill 283 165 195 283 168 195 minecraft:red_nether_bricks
setblock 283 165 203 minecraft:red_nether_bricks
setblock 283 165 204 minecraft:polished_blackstone
fill 283 165 205 283 165 208 minecraft:red_nether_bricks
setblock 283 165 209 minecraft:polished_blackstone
fill 283 165 210 283 168 210 minecraft:red_nether_bricks
setblock 283 165 214 minecraft:polished_blackstone
fill 283 165 215 283 168 215 minecraft:red_nether_bricks
setblock 283 165 219 minecraft:polished_blackstone
setblock 284 165 208 minecraft:polished_blackstone
fill 284 165 209 284 166 209 minecraft:red_nether_bricks
setblock 284 165 213 minecraft:polished_blackstone
fill 284 165 214 284 168 214 minecraft:red_nether_bricks
fill 298 165 182 299 165 182 minecraft:red_nether_bricks
setblock 300 165 182 minecraft:polished_blackstone
fill 301 165 182 303 165 182 minecraft:red_nether_bricks
fill 310 165 183 310 165 185 minecraft:polished_blackstone
fill 311 165 183 312 165 183 minecraft:polished_blackstone
fill 311 165 185 312 165 185 minecraft:polished_blackstone
setblock 312 165 184 minecraft:polished_blackstone
setblock 315 165 182 minecraft:polished_blackstone
setblock 315 165 222 minecraft:polished_blackstone
fill 316 165 182 316 168 182 minecraft:red_nether_bricks
fill 316 165 222 316 168 222 minecraft:red_nether_bricks
fill 317 165 221 317 168 221 minecraft:red_nether_bricks
setblock 320 165 182 minecraft:polished_blackstone
setblock 320 165 222 minecraft:polished_blackstone
fill 321 165 182 321 166 182 minecraft:red_nether_bricks
setblock 321 165 211 minecraft:polished_blackstone
fill 321 165 212 321 168 212 minecraft:red_nether_bricks
setblock 321 165 216 minecraft:polished_blackstone
fill 321 165 217 321 167 218 minecraft:red_nether_bricks
setblock 321 165 221 minecraft:polished_blackstone
fill 321 165 222 321 168 222 minecraft:red_nether_bricks
setblock 322 165 210 minecraft:polished_blackstone
fill 322 165 211 322 168 211 minecraft:red_nether_bricks
setblock 322 165 215 minecraft:polished_blackstone
fill 322 165 216 322 168 216 minecraft:red_nether_bricks
setblock 322 165 220 minecraft:polished_blackstone
setblock 323 165 189 minecraft:polished_blackstone
fill 323 165 190 323 167 190 minecraft:red_nether_bricks
setblock 323 165 194 minecraft:polished_blackstone
setblock 323 165 209 minecraft:polished_blackstone
fill 323 165 210 323 168 210 minecraft:red_nether_bricks
setblock 323 165 214 minecraft:polished_blackstone
fill 323 165 215 323 168 215 minecraft:red_nether_bricks
setblock 323 165 219 minecraft:polished_blackstone
fill 323 165 220 323 168 220 minecraft:red_nether_bricks
setblock 283 166 189 minecraft:red_nether_bricks
setblock 283 166 193 minecraft:polished_blackstone
fill 283 166 194 283 169 194 minecraft:red_nether_bricks
setblock 283 166 197 minecraft:red_nether_bricks
fill 283 166 204 283 166 207 minecraft:red_nether_bricks
setblock 283 166 208 minecraft:polished_blackstone
fill 283 166 209 283 169 209 minecraft:red_nether_bricks
setblock 283 166 213 minecraft:polished_blackstone
fill 283 166 214 283 169 214 minecraft:red_nether_bricks
setblock 283 166 218 minecraft:polished_blackstone
fill 283 166 219 283 169 219 minecraft:red_nether_bricks
setblock 284 166 212 minecraft:polished_blackstone
fill 284 166 213 284 169 213 minecraft:red_nether_bricks
setblock 298 166 182 minecraft:red_nether_bricks
setblock 299 166 182 minecraft:polished_blackstone
fill 300 166 182 302 167 182 minecraft:red_nether_bricks
setblock 314 166 182 minecraft:polished_blackstone
setblock 314 166 222 minecraft:polished_blackstone
fill 315 166 182 315 169 182 minecraft:red_nether_bricks
fill 315 166 222 315 169 222 minecraft:red_nether_bricks
fill 316 166 221 316 169 221 minecraft:red_nether_bricks
setblock 319 166 182 minecraft:polished_blackstone
setblock 319 166 222 minecraft:polished_blackstone
fill 320 166 182 320 169 182 minecraft:red_nether_bricks
setblock 320 166 221 minecraft:polished_blackstone
fill 320 166 222 320 169 222 minecraft:red_nether_bricks
fill 321 166 211 321 169 211 minecraft:red_nether_bricks
setblock 321 166 215 minecraft:polished_blackstone
fill 321 166 216 321 169 216 minecraft:red_nether_bricks
fill 321 166 221 321 169 221 minecraft:red_nether_bricks
setblock 322 166 209 minecraft:polished_blackstone
fill 322 166 210 322 169 210 minecraft:red_nether_bricks
setblock 322 166 214 minecraft:polished_blackstone
fill 322 166 215 322 169 215 minecraft:red_nether_bricks
setblock 322 166 219 minecraft:polished_blackstone
fill 322 166 220 322 169 220 minecraft:red_nether_bricks
setblock 323 166 188 minecraft:polished_blackstone
setblock 323 166 189 minecraft:red_nether_bricks
setblock 323 166 193 minecraft:polished_blackstone
fill 323 166 194 323 169 194 minecraft:red_nether_bricks
setblock 323 166 208 minecraft:polished_blackstone
fill 323 166 209 323 169 209 minecraft:red_nether_bricks
setblock 323 166 213 minecraft:polished_blackstone
fill 323 166 214 323 169 214 minecraft:red_nether_bricks
setblock 323 166 218 minecraft:polished_blackstone
fill 323 166 219 323 169 219 minecraft:red_nether_bricks
setblock 283 167 192 minecraft:polished_blackstone
fill 283 167 193 283 170 193 minecraft:red_nether_bricks
setblock 283 167 197 minecraft:polished_blackstone
fill 283 167 198 283 170 198 minecraft:red_nether_bricks
fill 283 167 205 283 167 206 minecraft:red_nether_bricks
setblock 283 167 207 minecraft:polished_blackstone
fill 283 167 208 283 170 208 minecraft:red_nether_bricks
setblock 283 167 212 minecraft:polished_blackstone
fill 283 167 213 283 170 213 minecraft:red_nether_bricks
setblock 283 167 217 minecraft:polished_blackstone
fill 283 167 218 283 170 218 minecraft:red_nether_bricks
setblock 284 167 211 minecraft:polished_blackstone
fill 284 167 212 284 170 212 minecraft:red_nether_bricks
setblock 284 167 216 minecraft:polished_blackstone
setblock 297 167 182 minecraft:red_nether_bricks
setblock 298 167 182 minecraft:polished_blackstone
fill 299 167 182 299 170 182 minecraft:red_nether_bricks
setblock 313 167 182 minecraft:polished_blackstone
setblock 313 167 222 minecraft:polished_blackstone
fill 314 167 182 314 170 182 minecraft:red_nether_bricks
fill 314 167 222 314 170 222 minecraft:red_nether_bricks
fill 315 167 221 315 170 221 minecraft:red_nether_bricks
setblock 318 167 182 minecraft:polished_blackstone
fill 318 167 220 319 167 220 minecraft:red_nether_bricks
setblock 318 167 222 minecraft:polished_blackstone
fill 319 167 182 319 170 182 minecraft:red_nether_bricks
setblock 319 167 221 minecraft:polished_blackstone
fill 319 167 222 319 170 222 minecraft:red_nether_bricks
setblock 320 167 215 minecraft:polished_blackstone
fill 320 167 221 320 170 221 minecraft:red_nether_bricks
setblock 321 167 214 minecraft:polished_blackstone
fill 321 167 215 321 170 215 minecraft:red_nether_bricks
setblock 321 167 219 minecraft:polished_blackstone
fill 322 167 209 322 168 209 minecraft:red_nether_bricks
setblock 322 167 213 minecraft:polished_blackstone
fill 322 167 214 322 170 214 minecraft:red_nether_bricks
setblock 322 167 218 minecraft:polished_blackstone
fill 322 167 219 322 170 219 minecraft:red_nether_bricks
fill 322 167 221 322 168 221 minecraft:red_nether_bricks
setblock 323 167 192 minecraft:polished_blackstone
fill 323 167 193 323 170 193 minecraft:red_nether_bricks
setblock 323 167 207 minecraft:polished_blackstone
fill 323 167 208 323 170 208 minecraft:red_nether_bricks
setblock 323 167 212 minecraft:polished_blackstone
fill 323 167 213 323 170 213 minecraft:red_nether_bricks
setblock 323 167 217 minecraft:polished_blackstone
fill 323 167 218 323 170 218 minecraft:red_nether_bricks
setblock 323 167 222 minecraft:polished_blackstone
setblock 283 168 191 minecraft:polished_blackstone
fill 283 168 192 283 171 192 minecraft:red_nether_bricks
setblock 283 168 196 minecraft:polished_blackstone
fill 283 168 197 283 171 197 minecraft:red_nether_bricks
fill 283 168 199 283 168 200 minecraft:red_nether_bricks
setblock 283 168 205 minecraft:red_nether_bricks
setblock 283 168 206 minecraft:polished_blackstone
fill 283 168 207 283 171 207 minecraft:red_nether_bricks
setblock 283 168 211 minecraft:polished_blackstone
fill 283 168 212 283 171 212 minecraft:red_nether_bricks
setblock 283 168 216 minecraft:polished_blackstone
fill 283 168 217 283 171 217 minecraft:red_nether_bricks
setblock 283 168 220 minecraft:red_nether_bricks
fill 284 168 211 284 169 211 minecraft:red_nether_bricks
setblock 284 168 215 minecraft:polished_blackstone
fill 284 168 216 284 171 216 minecraft:red_nether_bricks
setblock 296 168 182 minecraft:red_nether_bricks
setblock 297 168 182 minecraft:polished_blackstone
fill 298 168 182 298 171 182 minecraft:red_nether_bricks
fill 300 168 182 301 168 182 minecraft:red_nether_bricks
setblock 302 168 182 minecraft:polished_blackstone
setblock 311 168 222 minecraft:red_nether_bricks
setblock 312 168 182 minecraft:polished_blackstone
setblock 312 168 222 minecraft:polished_blackstone
fill 313 168 182 313 171 182 minecraft:red_nether_bricks
setblock 313 168 221 minecraft:polished_blackstone
fill 313 168 222 313 171 222 minecraft:red_nether_bricks
fill 314 168 221 314 171 221 minecraft:red_nether_bricks
fill 315 168 220 318 168 220 minecraft:red_nether_bricks
setblock 317 168 182 minecraft:polished_blackstone
setblock 317 168 222 minecraft:polished_blackstone
fill 318 168 182 318 171 182 minecraft:red_nether_bricks
setblock 318 168 221 minecraft:polished_blackstone
fill 318 168 222 318 171 222 minecraft:red_nether_bricks
setblock 319 168 220 minecraft:polished_blackstone
fill 319 168 221 319 171 221 minecraft:red_nether_bricks
setblock 320 168 214 minecraft:polished_blackstone
fill 320 168 215 320 169 217 minecraft:red_nether_bricks
fill 320 168 220 320 171 220 minecraft:red_nether_bricks
setblock 321 168 213 minecraft:polished_blackstone
fill 321 168 214 321 171 214 minecraft:red_nether_bricks
setblock 321 168 217 minecraft:red_nether_bricks
setblock 321 168 218 minecraft:polished_blackstone
fill 321 168 219 321 171 219 minecraft:red_nether_bricks
setblock 322 168 212 minecraft:polished_blackstone
fill 322 168 213 322 171 213 minecraft:red_nether_bricks
setblock 322 168 217 minecraft:polished_blackstone
fill 322 168 218 322 171 218 minecraft:red_nether_bricks
setblock 322 168 222 minecraft:polished_blackstone
setblock 323 168 191 minecraft:polished_blackstone
fill 323 168 192 323 170 192 minecraft:red_nether_bricks
setblock 323 168 195 minecraft:red_nether_bricks
setblock 323 168 211 minecraft:polished_blackstone
fill 323 168 212 323 171 212 minecraft:red_nether_bricks
setblock 323 168 216 minecraft:polished_blackstone
fill 323 168 217 323 171 217 minecraft:red_nether_bricks
setblock 323 168 221 minecraft:polished_blackstone
fill 323 168 222 323 171 222 minecraft:red_nether_bricks
fill 283 169 191 283 172 191 minecraft:red_nether_bricks
setblock 283 169 195 minecraft:polished_blackstone
fill 283 169 196 283 172 196 minecraft:red_nether_bricks
setblock 283 169 199 minecraft:red_nether_bricks
setblock 283 169 200 minecraft:polished_blackstone
fill 283 169 201 283 169 204 minecraft:red_nether_bricks
setblock 283 169 205 minecraft:polished_blackstone
fill 283 169 206 283 172 206 minecraft:red_nether_bricks
setblock 283 169 210 minecraft:polished_blackstone
fill 283 169 211 283 172 211 minecraft:red_nether_bricks
setblock 283 169 215 minecraft:polished_blackstone
fill 283 169 216 283 172 216 minecraft:red_nether_bricks
setblock 283 169 220 minecraft:polished_blackstone
setblock 284 169 214 minecraft:polished_blackstone
fill 284 169 215 284 172 215 minecraft:red_nether_bricks
setblock 295 169 182 minecraft:red_nether_bricks
setblock 295 169 222 minecraft:red_nether_bricks
setblock 296 169 182 minecraft:polished_blackstone
setblock 296 169 222 minecraft:polished_blackstone
fill 297 169 182 297 172 182 minecraft:red_nether_bricks
fill 297 169 222 300 169 222 minecraft:red_nether_bricks
setblock 300 169 182 minecraft:red_nether_bricks
setblock 301 169 182 minecraft:polished_blackstone
fill 302 169 182 302 172 182 minecraft:red_nether_bricks
setblock 310 169 222 minecraft:red_nether_bricks
setblock 311 169 182 minecraft:polished_blackstone
setblock 311 169 222 minecraft:polished_blackstone
fill 312 169 182 312 172 182 minecraft:red_nether_bricks
setblock 312 169 221 minecraft:polished_blackstone
fill 312 169 222 312 172 222 minecraft:red_nether_bricks
fill 313 169 221 313 172 221 minecraft:red_nether_bricks
fill 314 169 220 317 169 220 minecraft:red_nether_bricks
setblock 316 169 182 minecraft:polished_blackstone
fill 316 169 219 318 169 219 minecraft:red_nether_bricks
setblock 316 169 222 minecraft:polished_blackstone
fill 317 169 182 317 172 182 minecraft:red_nether_bricks
setblock 317 169 221 minecraft:polished_blackstone
fill 317 169 222 317 172 222 minecraft:red_nether_bricks
setblock 318 169 220 minecraft:polished_blackstone
fill 318 169 221 318 172 221 minecraft:red_nether_bricks
setblock 319 169 219 minecraft:polished_blackstone
fill 319 169 220 319 172 220 minecraft:red_nether_bricks
fill 320 169 214 320 171 214 minecraft:red_nether_bricks
setblock 320 169 218 minecraft:polished_blackstone
setblock 321 169 212 minecraft:polished_blackstone
fill 321 169 213 321 172 213 minecraft:red_nether_bricks
setblock 321 169 217 minecraft:polished_blackstone
fill 321 169 218 321 172 218 minecraft:red_nether_bricks
fill 321 169 220 321 170 220 minecraft:red_nether_bricks
setblock 321 169 222 minecraft:polished_blackstone
setblock 322 169 211 minecraft:polished_blackstone
fill 322 169 212 322 172 212 minecraft:red_nether_bricks
setblock 322 169 216 minecraft:polished_blackstone
fill 322 169 217 322 172 217 minecraft:red_nether_bricks
setblock 322 169 221 minecraft:polished_blackstone
fill 322 169 222 322 172 222 minecraft:red_nether_bricks
setblock 323 169 195 minecraft:polished_blackstone
fill 323 169 196 323 171 197 minecraft:red_nether_bricks
setblock 323 169 210 minecraft:polished_blackstone
fill 323 169 211 323 172 211 minecraft:red_nether_bricks
setblock 323 169 215 minecraft:polished_blackstone
fill 323 169 216 323 172 216 minecraft:red_nether_bricks
setblock 323 169 220 minecraft:polished_blackstone
fill 323 169 221 323 172 221 minecraft:red_nether_bricks
setblock 283 170 194 minecraft:polished_blackstone
fill 283 170 195 284 172 195 minecraft:red_nether_bricks
setblock 283 170 199 minecraft:polished_blackstone
fill 283 170 200 283 170 203 minecraft:red_nether_bricks
setblock 283 170 204 minecraft:polished_blackstone
fill 283 170 205 283 173 205 minecraft:red_nether_bricks
setblock 283 170 209 minecraft:polished_blackstone
fill 283 170 210 283 173 210 minecraft:red_nether_bricks
setblock 283 170 214 minecraft:polished_blackstone
fill 283 170 215 283 173 215 minecraft:red_nether_bricks
setblock 283 170 219 minecraft:polished_blackstone
fill 283 170 220 283 173 220 minecraft:red_nether_bricks
fill 284 170 194 284 173 194 minecraft:red_nether_bricks
fill 284 170 196 284 170 197 minecraft:red_nether_bricks
setblock 284 170 198 minecraft:polished_blackstone
setblock 284 170 213 minecraft:polished_blackstone
fill 284 170 214 284 171 214 minecraft:red_nether_bricks
setblock 284 170 217 minecraft:red_nether_bricks
fill 293 170 182 294 170 182 minecraft:red_nether_bricks
fill 293 170 222 294 170 222 minecraft:red_nether_bricks
setblock 295 170 182 minecraft:polished_blackstone
setblock 295 170 222 minecraft:polished_blackstone
fill 296 170 182 296 172 183 minecraft:red_nether_bricks
setblock 296 170 221 minecraft:polished_blackstone
fill 296 170 222 299 170 222 minecraft:red_nether_bricks
fill 297 170 183 298 170 183 minecraft:red_nether_bricks
fill 297 170 219 299 172 220 minecraft:magma_block
fill 297 170 221 298 172 221 minecraft:red_nether_bricks
fill 298 170 217 298 172 218 minecraft:magma_block
setblock 299 170 183 minecraft:polished_blackstone
setblock 299 170 221 minecraft:magma_block
setblock 300 170 182 minecraft:polished_blackstone
setblock 300 170 222 minecraft:polished_blackstone
fill 301 170 182 301 173 182 minecraft:red_nether_bricks
fill 301 170 222 302 172 222 minecraft:red_nether_bricks
fill 303 170 182 303 171 182 minecraft:red_nether_bricks
fill 307 170 222 309 170 222 minecraft:red_nether_bricks
setblock 309 170 182 minecraft:red_nether_bricks
fill 310 170 182 310 170 185 minecraft:polished_blackstone
setblock 310 170 221 minecraft:red_nether_bricks
setblock 310 170 222 minecraft:polished_blackstone
fill 311 170 182 311 173 182 minecraft:red_nether_bricks
fill 311 170 183 312 170 183 minecraft:polished_blackstone
fill 311 170 185 312 170 185 minecraft:polished_blackstone
setblock 311 170 221 minecraft:polished_blackstone
fill 311 170 222 311 173 222 minecraft:red_nether_bricks
setblock 312 170 184 minecraft:polished_blackstone
setblock 312 170 220 minecraft:polished_blackstone
fill 312 170 221 312 173 221 minecraft:red_nether_bricks
fill 313 170 220 316 170 220 minecraft:red_nether_bricks
setblock 314 170 183 minecraft:polished_blackstone
fill 314 170 219 317 170 219 minecraft:red_nether_bricks
setblock 315 170 182 minecraft:polished_blackstone
fill 315 170 183 317 171 183 minecraft:red_nether_bricks
setblock 315 170 222 minecraft:polished_blackstone
fill 316 170 182 316 173 182 minecraft:red_nether_bricks
setblock 316 170 221 minecraft:polished_blackstone
fill 316 170 222 316 173 222 minecraft:red_nether_bricks
setblock 317 170 220 minecraft:polished_blackstone
fill 317 170 221 317 173 221 minecraft:red_nether_bricks
setblock 318 170 219 minecraft:polished_blackstone
fill 318 170 220 318 173 220 minecraft:red_nether_bricks
fill 319 170 219 320 172 219 minecraft:red_nether_bricks
setblock 320 170 182 minecraft:polished_blackstone
fill 320 170 215 320 170 216 minecraft:red_nether_bricks
setblock 320 170 217 minecraft:polished_blackstone
fill 320 170 218 320 173 218 minecraft:red_nether_bricks
setblock 320 170 222 minecraft:polished_blackstone
fill 321 170 212 321 171 212 minecraft:red_nether_bricks
setblock 321 170 216 minecraft:polished_blackstone
fill 321 170 217 321 173 217 minecraft:red_nether_bricks
setblock 321 170 221 minecraft:polished_blackstone
fill 321 170 222 321 173 222 minecraft:red_nether_bricks
setblock 322 170 210 minecraft:polished_blackstone
fill 322 170 211 322 172 211 minecraft:red_nether_bricks
setblock 322 170 215 minecraft:polished_blackstone
fill 322 170 216 322 173 216 minecraft:red_nether_bricks
setblock 322 170 220 minecraft:polished_blackstone
fill 322 170 221 322 173 221 minecraft:red_nether_bricks
setblock 323 170 194 minecraft:polished_blackstone
fill 323 170 195 323 173 195 minecraft:red_nether_bricks
setblock 323 170 198 minecraft:red_nether_bricks
setblock 323 170 199 minecraft:polished_blackstone
setblock 323 170 209 minecraft:polished_blackstone
fill 323 170 210 323 173 210 minecraft:red_nether_bricks
setblock 323 170 214 minecraft:polished_blackstone
fill 323 170 215 323 173 215 minecraft:red_nether_bricks
setblock 323 170 219 minecraft:polished_blackstone
fill 323 170 220 323 173 220 minecraft:red_nether_bricks
setblock 283 171 193 minecraft:polished_blackstone
fill 283 171 194 283 174 194 minecraft:red_nether_bricks
setblock 283 171 198 minecraft:polished_blackstone
fill 283 171 199 283 171 202 minecraft:red_nether_bricks
setblock 283 171 203 minecraft:polished_blackstone
fill 283 171 204 283 174 204 minecraft:red_nether_bricks
setblock 283 171 208 minecraft:polished_blackstone
fill 283 171 209 283 173 209 minecraft:red_nether_bricks
setblock 283 171 213 minecraft:polished_blackstone
fill 283 171 214 283 174 214 minecraft:red_nether_bricks
setblock 283 171 218 minecraft:polished_blackstone
fill 283 171 219 283 174 219 minecraft:red_nether_bricks
fill 283 171 221 283 172 221 minecraft:red_nether_bricks
setblock 284 171 196 minecraft:red_nether_bricks
setblock 284 171 197 minecraft:polished_blackstone
fill 284 171 198 284 172 200 minecraft:red_nether_bricks
setblock 284 171 213 minecraft:red_nether_bricks
setblock 284 171 217 minecraft:polished_blackstone
fill 291 171 222 293 171 222 minecraft:red_nether_bricks
fill 292 171 182 293 171 182 minecraft:red_nether_bricks
fill 293 171 221 294 171 221 minecraft:red_nether_bricks
setblock 294 171 182 minecraft:polished_blackstone
setblock 294 171 222 minecraft:polished_blackstone
fill 295 171 182 295 173 183 minecraft:red_nether_bricks
setblock 295 171 221 minecraft:polished_blackstone
fill 295 171 222 298 171 222 minecraft:red_nether_bricks
fill 296 171 221 296 174 221 minecraft:red_nether_bricks
setblock 297 171 183 minecraft:red_nether_bricks
fill 297 171 217 297 172 218 minecraft:magma_block
setblock 298 171 183 minecraft:polished_blackstone
fill 298 171 214 298 171 216 minecraft:magma_block
setblock 299 171 182 minecraft:polished_blackstone
fill 299 171 183 300 173 183 minecraft:red_nether_bricks
fill 299 171 217 299 172 218 minecraft:magma_block
setblock 299 171 221 minecraft:red_nether_bricks
setblock 299 171 222 minecraft:polished_blackstone
fill 300 171 182 300 174 182 minecraft:red_nether_bricks
setblock 300 171 221 minecraft:polished_blackstone
fill 300 171 222 300 174 222 minecraft:red_nether_bricks
setblock 303 171 222 minecraft:red_nether_bricks
setblock 304 171 182 minecraft:polished_blackstone
setblock 304 171 222 minecraft:polished_blackstone
fill 305 171 182 308 171 182 minecraft:red_nether_bricks
fill 305 171 222 308 171 222 minecraft:red_nether_bricks
fill 308 171 221 309 171 221 minecraft:red_nether_bricks
setblock 309 171 182 minecraft:polished_blackstone
setblock 309 171 222 minecraft:polished_blackstone
fill 310 171 182 310 174 182 minecraft:red_nether_bricks
setblock 310 171 220 minecraft:red_nether_bricks
setblock 310 171 221 minecraft:polished_blackstone
fill 310 171 222 310 174 222 minecraft:red_nether_bricks
setblock 311 171 220 minecraft:polished_blackstone
fill 311 171 221 311 174 221 minecraft:red_nether_bricks
setblock 312 171 183 minecraft:red_nether_bricks
setblock 312 171 219 minecraft:polished_blackstone
fill 312 171 220 315 171 220 minecraft:red_nether_bricks
setblock 313 171 183 minecraft:polished_blackstone
fill 313 171 219 316 171 219 minecraft:red_nether_bricks
setblock 314 171 182 minecraft:polished_blackstone
fill 314 171 183 314 174 183 minecraft:red_nether_bricks
setblock 314 171 222 minecraft:polished_blackstone
fill 315 171 182 315 174 182 minecraft:red_nether_bricks
fill 315 171 218 317 171 218 minecraft:red_nether_bricks
setblock 315 171 221 minecraft:polished_blackstone
fill 315 171 222 315 174 222 minecraft:red_nether_bricks
setblock 316 171 220 minecraft:polished_blackstone
fill 316 171 221 316 174 221 minecraft:red_nether_bricks
fill 317 171 203 317 171 205 minecraft:polished_blackstone
setblock 317 171 219 minecraft:polished_blackstone
fill 317 171 220 317 174 220 minecraft:red_nether_bricks
fill 318 171 202 320 171 202 minecraft:polished_blackstone
fill 318 171 206 320 171 206 minecraft:polished_blackstone
fill 318 171 219 318 174 219 minecraft:red_nether_bricks
setblock 319 171 182 minecraft:polished_blackstone
setblock 319 171 222 minecraft:polished_blackstone
fill 320 171 182 320 174 182 minecraft:red_nether_bricks
setblock 320 171 215 minecraft:red_nether_bricks
setblock 320 171 216 minecraft:polished_blackstone
fill 320 171 217 320 173 217 minecraft:red_nether_bricks
setblock 320 171 221 minecraft:polished_blackstone
fill 320 171 222 320 174 222 minecraft:red_nether_bricks
fill 321 171 203 321 171 205 minecraft:polished_blackstone
setblock 321 171 215 minecraft:polished_blackstone
fill 321 171 216 321 174 216 minecraft:red_nether_bricks
setblock 321 171 220 minecraft:polished_blackstone
fill 321 171 221 321 174 221 minecraft:red_nether_bricks
setblock 322 171 210 minecraft:red_nether_bricks
setblock 322 171 214 minecraft:polished_blackstone
fill 322 171 215 322 174 215 minecraft:red_nether_bricks
setblock 322 171 219 minecraft:polished_blackstone
fill 322 171 220 322 174 220 minecraft:red_nether_bricks
setblock 323 171 193 minecraft:polished_blackstone
fill 323 171 194 323 173 194 minecraft:red_nether_bricks
setblock 323 171 198 minecraft:polished_blackstone
fill 323 171 199 323 172 201 minecraft:red_nether_bricks
setblock 323 171 208 minecraft:polished_blackstone
fill 323 171 209 323 174 209 minecraft:red_nether_bricks
setblock 323 171 213 minecraft:polished_blackstone
fill 323 171 214 323 174 214 minecraft:red_nether_bricks
setblock 323 171 218 minecraft:polished_blackstone
fill 323 171 219 323 174 219 minecraft:red_nether_bricks
setblock 283 172 192 minecraft:polished_blackstone
fill 283 172 193 283 175 193 minecraft:red_nether_bricks
setblock 283 172 197 minecraft:polished_blackstone
fill 283 172 198 283 172 201 minecraft:red_nether_bricks
setblock 283 172 202 minecraft:polished_blackstone
fill 283 172 203 283 175 203 minecraft:red_nether_bricks
setblock 283 172 207 minecraft:polished_blackstone
fill 283 172 208 283 173 208 minecraft:red_nether_bricks
setblock 283 172 212 minecraft:polished_blackstone
fill 283 172 213 283 174 213 minecraft:red_nether_bricks
setblock 283 172 217 minecraft:polished_blackstone
fill 283 172 218 283 175 218 minecraft:red_nether_bricks
setblock 284 172 196 minecraft:polished_blackstone
fill 284 172 197 284 175 197 minecraft:red_nether_bricks
setblock 284 172 201 minecraft:polished_blackstone
setblock 284 172 216 minecraft:polished_blackstone
setblock 284 172 217 minecraft:red_nether_bricks
setblock 285 172 184 minecraft:light[level=14]
setblock 285 172 192 minecraft:light[level=14]
setblock 285 172 200 minecraft:light[level=14]
setblock 285 172 208 minecraft:light[level=14]
setblock 285 172 216 minecraft:light[level=14]
fill 290 172 222 292 172 222 minecraft:red_nether_bricks
fill 291 172 182 292 172 182 minecraft:red_nether_bricks
fill 292 172 221 293 172 221 minecraft:red_nether_bricks
setblock 293 172 182 minecraft:polished_blackstone
fill 293 172 183 294 174 183 minecraft:red_nether_bricks
setblock 293 172 184 minecraft:light[level=14]
setblock 293 172 192 minecraft:light[level=14]
setblock 293 172 200 minecraft:light[level=14]
setblock 293 172 208 minecraft:light[level=14]
setblock 293 172 216 minecraft:light[level=14]
setblock 293 172 222 minecraft:polished_blackstone
fill 294 172 182 294 175 182 minecraft:red_nether_bricks
setblock 294 172 221 minecraft:polished_blackstone
fill 294 172 222 297 172 222 minecraft:red_nether_bricks
setblock 295 172 220 minecraft:polished_blackstone
fill 295 172 221 295 175 221 minecraft:red_nether_bricks
fill 296 172 220 296 175 220 minecraft:red_nether_bricks
setblock 297 172 183 minecraft:polished_blackstone
setblock 298 172 182 minecraft:polished_blackstone
fill 298 172 183 298 175 183 minecraft:red_nether_bricks
setblock 298 172 216 minecraft:magma_block
setblock 298 172 222 minecraft:polished_blackstone
fill 299 172 182 299 175 182 minecraft:red_nether_bricks
setblock 299 172 221 minecraft:polished_blackstone
fill 299 172 222 299 175 222 minecraft:red_nether_bricks
fill 300 172 221 301 174 221 minecraft:red_nether_bricks
setblock 301 172 184 minecraft:light[level=14]
setblock 301 172 192 minecraft:light[level=14]
setblock 301 172 200 minecraft:light[level=14]
setblock 301 172 216 minecraft:light[level=14]
setblock 303 172 182 minecraft:polished_blackstone
setblock 303 172 222 minecraft:polished_blackstone
fill 304 172 182 307 172 182 minecraft:red_nether_bricks
fill 304 172 222 307 172 222 minecraft:red_nether_bricks
fill 306 172 221 308 172 221 minecraft:red_nether_bricks
setblock 308 172 182 minecraft:polished_blackstone
setblock 308 172 222 minecraft:polished_blackstone
fill 309 172 182 309 175 182 minecraft:red_nether_bricks
setblock 309 172 184 minecraft:light[level=14]
setblock 309 172 192 minecraft:light[level=14]
setblock 309 172 200 minecraft:light[level=14]
setblock 309 172 208 minecraft:light[level=14]
setblock 309 172 216 minecraft:light[level=14]
setblock 309 172 220 minecraft:red_nether_bricks
setblock 309 172 221 minecraft:polished_blackstone
fill 309 172 222 309 175 222 minecraft:red_nether_bricks
setblock 310 172 220 minecraft:polished_blackstone
fill 310 172 221 310 175 221 minecraft:red_nether_bricks
setblock 311 172 183 minecraft:red_nether_bricks
setblock 311 172 219 minecraft:polished_blackstone
fill 311 172 220 314 172 220 minecraft:red_nether_bricks
setblock 312 172 183 minecraft:polished_blackstone
fill 312 172 219 315 172 219 minecraft:red_nether_bricks
setblock 313 172 182 minecraft:polished_blackstone
fill 313 172 183 313 175 183 minecraft:red_nether_bricks
setblock 313 172 222 minecraft:polished_blackstone
fill 314 172 182 314 175 182 minecraft:red_nether_bricks
fill 314 172 218 316 172 218 minecraft:red_nether_bricks
setblock 314 172 221 minecraft:polished_blackstone
fill 314 172 222 314 175 222 minecraft:red_nether_bricks
fill 315 172 183 316 172 183 minecraft:red_nether_bricks
setblock 315 172 220 minecraft:polished_blackstone
fill 315 172 221 315 175 221 minecraft:red_nether_bricks
setblock 316 172 219 minecraft:polished_blackstone
fill 316 172 220 316 175 220 minecraft:red_nether_bricks
setblock 317 172 183 minecraft:polished_blackstone
setblock 317 172 184 minecraft:light[level=14]
setblock 317 172 192 minecraft:light[level=14]
setblock 317 172 200 minecraft:light[level=14]
setblock 317 172 208 minecraft:light[level=14]
setblock 317 172 216 minecraft:light[level=14]
setblock 317 172 218 minecraft:polished_blackstone
fill 317 172 219 317 175 219 minecraft:red_nether_bricks
setblock 318 172 182 minecraft:polished_blackstone
setblock 318 172 218 minecraft:red_nether_bricks
setblock 318 172 222 minecraft:polished_blackstone
fill 319 172 182 319 175 182 minecraft:red_nether_bricks
setblock 319 172 221 minecraft:polished_blackstone
fill 319 172 222 319 175 222 minecraft:red_nether_bricks
setblock 320 172 215 minecraft:polished_blackstone
fill 320 172 216 320 173 216 minecraft:red_nether_bricks
setblock 320 172 220 minecraft:polished_blackstone
fill 320 172 221 320 175 221 minecraft:red_nether_bricks
setblock 321 172 214 minecraft:polished_blackstone
fill 321 172 215 321 174 215 minecraft:red_nether_bricks
setblock 321 172 219 minecraft:polished_blackstone
fill 321 172 220 321 175 220 minecraft:red_nether_bricks
setblock 322 172 213 minecraft:polished_blackstone
fill 322 172 214 322 175 214 minecraft:red_nether_bricks
setblock 322 172 218 minecraft:polished_blackstone
fill 322 172 219 322 175 219 minecraft:red_nether_bricks
setblock 323 172 193 minecraft:red_nether_bricks
setblock 323 172 196 minecraft:red_nether_bricks
setblock 323 172 197 minecraft:polished_blackstone
fill 323 172 198 323 175 198 minecraft:red_nether_bricks
setblock 323 172 202 minecraft:polished_blackstone
fill 323 172 203 323 175 203 minecraft:red_nether_bricks
fill 323 172 208 323 173 208 minecraft:red_nether_bricks
setblock 323 172 212 minecraft:polished_blackstone
fill 323 172 213 323 175 213 minecraft:red_nether_bricks
setblock 323 172 217 minecraft:polished_blackstone
fill 323 172 218 323 175 218 minecraft:red_nether_bricks
setblock 323 172 222 minecraft:polished_blackstone
fill 283 173 192 283 174 192 minecraft:red_nether_bricks
setblock 283 173 195 minecraft:red_nether_bricks
setblock 283 173 196 minecraft:polished_blackstone
fill 283 173 197 283 173 200 minecraft:red_nether_bricks
setblock 283 173 201 minecraft:polished_blackstone
fill 283 173 202 284 175 202 minecraft:red_nether_bricks
setblock 283 173 206 minecraft:polished_blackstone
setblock 283 173 207 minecraft:red_nether_bricks
setblock 283 173 211 minecraft:polished_blackstone
fill 283 173 212 283 174 212 minecraft:red_nether_bricks
setblock 283 173 216 minecraft:polished_blackstone
fill 283 173 217 283 175 217 minecraft:red_nether_bricks
setblock 283 173 221 minecraft:polished_blackstone
setblock 284 173 195 minecraft:polished_blackstone
fill 284 173 196 284 176 196 minecraft:red_nether_bricks
fill 284 173 198 284 173 199 minecraft:red_nether_bricks
setblock 284 173 200 minecraft:polished_blackstone
fill 284 173 201 284 176 201 minecraft:red_nether_bricks
fill 288 173 222 291 173 222 minecraft:red_nether_bricks
fill 290 173 182 291 173 182 minecraft:red_nether_bricks
fill 291 173 221 292 173 221 minecraft:red_nether_bricks
setblock 292 173 182 minecraft:polished_blackstone
fill 292 173 183 292 176 183 minecraft:red_nether_bricks
setblock 292 173 222 minecraft:polished_blackstone
fill 293 173 182 293 176 182 minecraft:red_nether_bricks
setblock 293 173 221 minecraft:polished_blackstone
fill 293 173 222 296 173 222 minecraft:red_nether_bricks
setblock 294 173 220 minecraft:polished_blackstone
fill 294 173 221 294 176 221 minecraft:red_nether_bricks
fill 295 173 220 295 175 220 minecraft:red_nether_bricks
setblock 296 173 182 minecraft:red_nether_bricks
setblock 296 173 183 minecraft:polished_blackstone
setblock 297 173 182 minecraft:polished_blackstone
fill 297 173 183 297 176 183 minecraft:red_nether_bricks
fill 297 173 220 297 173 221 minecraft:red_nether_bricks
setblock 297 173 222 minecraft:polished_blackstone
fill 298 173 182 298 176 182 minecraft:red_nether_bricks
fill 298 173 219 298 173 220 minecraft:magma_block
setblock 298 173 221 minecraft:polished_blackstone
fill 298 173 222 298 176 222 minecraft:red_nether_bricks
setblock 299 173 220 minecraft:magma_block
fill 299 173 221 299 176 221 minecraft:red_nether_bricks
setblock 301 173 222 minecraft:red_nether_bricks
setblock 302 173 182 minecraft:polished_blackstone
setblock 302 173 221 minecraft:red_nether_bricks
setblock 302 173 222 minecraft:polished_blackstone
fill 303 173 182 306 173 182 minecraft:red_nether_bricks
setblock 303 173 221 minecraft:polished_blackstone
fill 303 173 222 306 173 222 minecraft:red_nether_bricks
fill 304 173 221 307 173 221 minecraft:red_nether_bricks
setblock 307 173 182 minecraft:polished_blackstone
setblock 307 173 222 minecraft:polished_blackstone
fill 308 173 182 308 176 182 minecraft:red_nether_bricks
setblock 308 173 220 minecraft:red_nether_bricks
setblock 308 173 221 minecraft:polished_blackstone
fill 308 173 222 308 176 222 minecraft:red_nether_bricks
fill 309 173 183 310 173 183 minecraft:red_nether_bricks
setblock 309 173 220 minecraft:polished_blackstone
fill 309 173 221 309 176 221 minecraft:red_nether_bricks
setblock 310 173 219 minecraft:polished_blackstone
fill 310 173 220 313 173 220 minecraft:red_nether_bricks
setblock 311 173 183 minecraft:polished_blackstone
fill 311 173 219 314 173 219 minecraft:red_nether_bricks
setblock 312 173 182 minecraft:polished_blackstone
fill 312 173 183 312 176 183 minecraft:red_nether_bricks
setblock 312 173 222 minecraft:polished_blackstone
fill 313 173 182 313 176 182 minecraft:red_nether_bricks
fill 313 173 218 315 173 218 minecraft:red_nether_bricks
setblock 313 173 221 minecraft:polished_blackstone
fill 313 173 222 313 176 222 minecraft:red_nether_bricks
setblock 314 173 220 minecraft:polished_blackstone
fill 314 173 221 314 176 221 minecraft:red_nether_bricks
setblock 315 173 183 minecraft:red_nether_bricks
setblock 315 173 219 minecraft:polished_blackstone
fill 315 173 220 315 176 220 minecraft:red_nether_bricks
setblock 316 173 183 minecraft:polished_blackstone
setblock 316 173 218 minecraft:polished_blackstone
fill 316 173 219 316 176 219 minecraft:red_nether_bricks
setblock 317 173 182 minecraft:polished_blackstone
fill 317 173 183 317 174 183 minecraft:red_nether_bricks
setblock 317 173 218 minecraft:red_nether_bricks
setblock 317 173 222 minecraft:polished_blackstone
fill 318 173 182 318 176 182 minecraft:red_nether_bricks
setblock 318 173 221 minecraft:polished_blackstone
fill 318 173 222 318 176 222 minecraft:red_nether_bricks
setblock 319 173 219 minecraft:red_nether_bricks
setblock 319 173 220 minecraft:polished_blackstone
fill 319 173 221 319 176 221 minecraft:red_nether_bricks
setblock 320 173 219 minecraft:polished_blackstone
fill 320 173 220 320 175 220 minecraft:red_nether_bricks
setblock 321 173 214 minecraft:red_nether_bricks
setblock 321 173 218 minecraft:polished_blackstone
fill 321 173 219 321 175 219 minecraft:red_nether_bricks
setblock 322 173 212 minecraft:polished_blackstone
fill 322 173 213 322 174 213 minecraft:red_nether_bricks
setblock 322 173 217 minecraft:polished_blackstone
fill 322 173 218 322 176 218 minecraft:red_nether_bricks
setblock 322 173 222 minecraft:polished_blackstone
setblock 323 173 196 minecraft:polished_blackstone
fill 323 173 197 323 176 197 minecraft:red_nether_bricks
fill 323 173 199 323 173 200 minecraft:red_nether_bricks
setblock 323 173 201 minecraft:polished_blackstone
fill 323 173 202 323 176 202 minecraft:red_nether_bricks
fill 323 173 204 323 174 204 minecraft:red_nether_bricks
setblock 323 173 211 minecraft:polished_blackstone
fill 323 173 212 323 175 212 minecraft:red_nether_bricks
setblock 323 173 216 minecraft:polished_blackstone
fill 323 173 217 323 176 217 minecraft:red_nether_bricks
setblock 323 173 221 minecraft:polished_blackstone
fill 323 173 222 323 176 222 minecraft:red_nether_bricks
setblock 283 174 195 minecraft:polished_blackstone
fill 283 174 196 283 174 199 minecraft:red_nether_bricks
setblock 283 174 200 minecraft:polished_blackstone
fill 283 174 201 283 177 201 minecraft:red_nether_bricks
setblock 283 174 205 minecraft:polished_blackstone
fill 283 174 206 283 176 206 minecraft:red_nether_bricks
setblock 283 174 215 minecraft:polished_blackstone
fill 283 174 216 283 175 216 minecraft:red_nether_bricks
setblock 283 174 220 minecraft:polished_blackstone
fill 283 174 221 283 175 221 minecraft:red_nether_bricks
setblock 284 174 194 minecraft:polished_blackstone
fill 284 174 195 284 175 195 minecraft:red_nether_bricks
setblock 284 174 198 minecraft:red_nether_bricks
setblock 284 174 199 minecraft:polished_blackstone
fill 284 174 200 284 177 200 minecraft:red_nether_bricks
setblock 285 174 197 minecraft:red_nether_bricks
setblock 285 174 198 minecraft:polished_blackstone
fill 285 174 199 285 176 199 minecraft:red_nether_bricks
fill 287 174 222 290 174 222 minecraft:red_nether_bricks
fill 289 174 182 290 174 182 minecraft:red_nether_bricks
fill 290 174 221 291 174 221 minecraft:red_nether_bricks
setblock 291 174 182 minecraft:polished_blackstone
fill 291 174 183 291 177 183 minecraft:red_nether_bricks
setblock 291 174 222 minecraft:polished_blackstone
fill 292 174 182 292 177 182 minecraft:red_nether_bricks
setblock 292 174 221 minecraft:polished_blackstone
fill 292 174 222 295 174 222 minecraft:red_nether_bricks
setblock 293 174 220 minecraft:polished_blackstone
fill 293 174 221 293 177 221 minecraft:red_nether_bricks
fill 294 174 220 294 175 220 minecraft:red_nether_bricks
setblock 295 174 182 minecraft:red_nether_bricks
setblock 295 174 183 minecraft:polished_blackstone
setblock 296 174 182 minecraft:polished_blackstone
fill 296 174 183 296 177 183 minecraft:red_nether_bricks
setblock 296 174 222 minecraft:polished_blackstone
fill 297 174 182 297 177 182 minecraft:red_nether_bricks
setblock 297 174 220 minecraft:red_nether_bricks
setblock 297 174 221 minecraft:polished_blackstone
fill 297 174 222 297 177 222 minecraft:red_nether_bricks
fill 298 174 221 298 177 221 minecraft:red_nether_bricks
setblock 299 174 183 minecraft:red_nether_bricks
setblock 300 174 183 minecraft:polished_blackstone
setblock 301 174 182 minecraft:polished_blackstone
setblock 301 174 222 minecraft:polished_blackstone
fill 302 174 182 305 174 182 minecraft:red_nether_bricks
setblock 302 174 221 minecraft:polished_blackstone
fill 302 174 222 305 174 222 minecraft:red_nether_bricks
fill 303 174 221 306 174 221 minecraft:red_nether_bricks
setblock 306 174 182 minecraft:polished_blackstone
setblock 306 174 222 minecraft:polished_blackstone
fill 307 174 182 307 177 182 minecraft:red_nether_bricks
setblock 307 174 221 minecraft:polished_blackstone
fill 307 174 222 307 177 222 minecraft:red_nether_bricks
fill 308 174 183 309 174 183 minecraft:red_nether_bricks
setblock 308 174 220 minecraft:polished_blackstone
fill 308 174 221 308 177 221 minecraft:red_nether_bricks
fill 309 174 220 312 174 220 minecraft:red_nether_bricks
setblock 310 174 183 minecraft:polished_blackstone
fill 310 174 219 313 174 219 minecraft:red_nether_bricks
setblock 311 174 182 minecraft:polished_blackstone
fill 311 174 183 311 177 183 minecraft:red_nether_bricks
setblock 311 174 222 minecraft:polished_blackstone
fill 312 174 182 312 177 182 minecraft:red_nether_bricks
setblock 312 174 221 minecraft:polished_blackstone
fill 312 174 222 312 177 222 minecraft:red_nether_bricks
fill 313 174 218 314 174 218 minecraft:red_nether_bricks
setblock 313 174 220 minecraft:polished_blackstone
fill 313 174 221 313 177 221 minecraft:red_nether_bricks
setblock 314 174 219 minecraft:polished_blackstone
fill 314 174 220 314 177 220 minecraft:red_nether_bricks
setblock 315 174 183 minecraft:polished_blackstone
setblock 315 174 218 minecraft:polished_blackstone
fill 315 174 219 315 177 219 minecraft:red_nether_bricks
setblock 316 174 182 minecraft:polished_blackstone
fill 316 174 183 316 176 183 minecraft:red_nether_bricks
setblock 316 174 218 minecraft:red_nether_bricks
setblock 316 174 222 minecraft:polished_blackstone
fill 317 174 182 317 177 182 minecraft:red_nether_bricks
setblock 317 174 221 minecraft:polished_blackstone
fill 317 174 222 317 177 222 minecraft:red_nether_bricks
setblock 318 174 220 minecraft:polished_blackstone
fill 318 174 221 318 177 221 minecraft:red_nether_bricks
setblock 319 174 219 minecraft:polished_blackstone
fill 319 174 220 319 176 220 minecraft:red_nether_bricks
setblock 321 174 217 minecraft:polished_blackstone
fill 321 174 218 321 175 218 minecraft:red_nether_bricks
setblock 321 174 222 minecraft:polished_blackstone
setblock 322 174 216 minecraft:polished_blackstone
fill 322 174 217 322 176 217 minecraft:red_nether_bricks
setblock 322 174 221 minecraft:polished_blackstone
fill 322 174 222 322 177 222 minecraft:red_nether_bricks
setblock 323 174 195 minecraft:polished_blackstone
fill 323 174 196 323 176 196 minecraft:red_nether_bricks
setblock 323 174 199 minecraft:red_nether_bricks
setblock 323 174 200 minecraft:polished_blackstone
fill 323 174 201 323 177 201 minecraft:red_nether_bricks
setblock 323 174 205 minecraft:polished_blackstone
setblock 323 174 210 minecraft:polished_blackstone
fill 323 174 211 323 175 211 minecraft:red_nether_bricks
setblock 323 174 215 minecraft:polished_blackstone
fill 323 174 216 323 177 216 minecraft:red_nether_bricks
setblock 323 174 220 minecraft:polished_blackstone
fill 323 174 221 323 177 221 minecraft:red_nether_bricks
setblock 283 175 194 minecraft:polished_blackstone
fill 283 175 195 283 175 198 minecraft:red_nether_bricks
setblock 283 175 199 minecraft:polished_blackstone
fill 283 175 200 283 178 200 minecraft:red_nether_bricks
setblock 283 175 204 minecraft:polished_blackstone
fill 283 175 205 283 178 205 minecraft:red_nether_bricks
setblock 283 175 215 minecraft:red_nether_bricks
setblock 283 175 219 minecraft:polished_blackstone
setblock 283 175 220 minecraft:red_nether_bricks
setblock 284 175 198 minecraft:polished_blackstone
fill 284 175 199 284 178 199 minecraft:red_nether_bricks
setblock 284 175 203 minecraft:polished_blackstone
setblock 285 175 198 minecraft:red_nether_bricks
fill 287 175 222 289 175 222 minecraft:red_nether_bricks
fill 288 175 182 289 175 182 minecraft:red_nether_bricks
fill 289 175 221 290 175 221 minecraft:red_nether_bricks
setblock 290 175 182 minecraft:polished_blackstone
setblock 290 175 222 minecraft:polished_blackstone
fill 291 175 182 291 178 182 minecraft:red_nether_bricks
setblock 291 175 221 minecraft:polished_blackstone
fill 291 175 222 294 175 222 minecraft:red_nether_bricks
fill 292 175 221 292 178 221 minecraft:red_nether_bricks
setblock 293 175 183 minecraft:red_nether_bricks
setblock 293 175 220 minecraft:red_nether_bricks
setblock 294 175 183 minecraft:polished_blackstone
setblock 295 175 182 minecraft:polished_blackstone
fill 295 175 183 295 178 183 minecraft:red_nether_bricks
setblock 295 175 222 minecraft:polished_blackstone
fill 296 175 182 296 178 182 minecraft:red_nether_bricks
setblock 296 175 221 minecraft:polished_blackstone
fill 296 175 222 296 178 222 minecraft:red_nether_bricks
fill 297 175 221 297 177 221 minecraft:red_nether_bricks
setblock 299 175 183 minecraft:polished_blackstone
setblock 300 175 182 minecraft:polished_blackstone
setblock 300 175 183 minecraft:red_nether_bricks
setblock 300 175 221 minecraft:red_nether_bricks
setblock 300 175 222 minecraft:polished_blackstone
fill 301 175 182 304 175 182 minecraft:red_nether_bricks
setblock 301 175 221 minecraft:polished_blackstone
fill 301 175 222 304 175 222 minecraft:red_nether_bricks
fill 302 175 221 305 175 221 minecraft:red_nether_bricks
setblock 305 175 182 minecraft:polished_blackstone
setblock 305 175 222 minecraft:polished_blackstone
fill 306 175 182 306 178 182 minecraft:red_nether_bricks
setblock 306 175 221 minecraft:polished_blackstone
fill 306 175 222 306 178 222 minecraft:red_nether_bricks
setblock 307 175 220 minecraft:polished_blackstone
fill 307 175 221 307 178 221 minecraft:red_nether_bricks
setblock 308 175 183 minecraft:red_nether_bricks
fill 308 175 220 311 175 220 minecraft:red_nether_bricks
setblock 309 175 183 minecraft:polished_blackstone
setblock 310 175 182 minecraft:polished_blackstone
fill 310 175 183 310 178 183 minecraft:red_nether_bricks
fill 310 175 184 310 175 185 minecraft:polished_blackstone
fill 310 175 219 312 175 219 minecraft:red_nether_bricks
setblock 310 175 222 minecraft:polished_blackstone
fill 311 175 182 311 178 182 minecraft:red_nether_bricks
fill 311 175 185 312 175 185 minecraft:polished_blackstone
setblock 311 175 221 minecraft:polished_blackstone
fill 311 175 222 311 178 222 minecraft:red_nether_bricks
setblock 312 175 184 minecraft:polished_blackstone
setblock 312 175 220 minecraft:polished_blackstone
fill 312 175 221 312 178 221 minecraft:red_nether_bricks
setblock 313 175 219 minecraft:polished_blackstone
fill 313 175 220 313 178 220 minecraft:red_nether_bricks
setblock 314 175 183 minecraft:polished_blackstone
setblock 314 175 218 minecraft:polished_blackstone
fill 314 175 219 314 178 219 minecraft:red_nether_bricks
setblock 315 175 182 minecraft:polished_blackstone
fill 315 175 183 315 177 183 minecraft:red_nether_bricks
setblock 315 175 218 minecraft:red_nether_bricks
setblock 315 175 222 minecraft:polished_blackstone
fill 316 175 182 316 178 182 minecraft:red_nether_bricks
setblock 316 175 221 minecraft:polished_blackstone
fill 316 175 222 316 178 222 minecraft:red_nether_bricks
setblock 317 175 220 minecraft:polished_blackstone
fill 317 175 221 317 178 221 minecraft:red_nether_bricks
setblock 318 175 219 minecraft:polished_blackstone
fill 318 175 220 318 177 220 minecraft:red_nether_bricks
setblock 320 175 222 minecraft:polished_blackstone
setblock 321 175 221 minecraft:polished_blackstone
fill 321 175 222 321 178 222 minecraft:red_nether_bricks
setblock 322 175 215 minecraft:polished_blackstone
setblock 322 175 216 minecraft:red_nether_bricks
setblock 322 175 220 minecraft:polished_blackstone
fill 322 175 221 322 176 221 minecraft:red_nether_bricks
setblock 323 175 195 minecraft:red_nether_bricks
setblock 323 175 199 minecraft:polished_blackstone
fill 323 175 200 323 178 200 minecraft:red_nether_bricks
setblock 323 175 204 minecraft:polished_blackstone
fill 323 175 205 323 178 205 minecraft:red_nether_bricks
setblock 323 175 214 minecraft:polished_blackstone
fill 323 175 215 323 177 215 minecraft:red_nether_bricks
setblock 323 175 219 minecraft:polished_blackstone
fill 323 175 220 323 178 220 minecraft:red_nether_bricks
fill 283 176 194 283 176 197 minecraft:red_nether_bricks
setblock 283 176 198 minecraft:polished_blackstone
fill 283 176 199 283 179 199 minecraft:red_nether_bricks
setblock 283 176 202 minecraft:red_nether_bricks
setblock 283 176 203 minecraft:polished_blackstone
fill 283 176 204 283 179 204 minecraft:red_nether_bricks
setblock 284 176 197 minecraft:polished_blackstone
fill 284 176 198 284 179 198 minecraft:red_nether_bricks
setblock 284 176 202 minecraft:polished_blackstone
fill 284 176 203 284 179 203 minecraft:red_nether_bricks
fill 286 176 222 288 176 222 minecraft:red_nether_bricks
setblock 288 176 182 minecraft:red_nether_bricks
setblock 289 176 182 minecraft:polished_blackstone
setblock 289 176 221 minecraft:red_nether_bricks
setblock 289 176 222 minecraft:polished_blackstone
fill 290 176 182 290 178 183 minecraft:red_nether_bricks
setblock 290 176 221 minecraft:polished_blackstone
fill 290 176 222 293 176 222 minecraft:red_nether_bricks
fill 291 176 221 291 179 221 minecraft:red_nether_bricks
setblock 293 176 183 minecraft:polished_blackstone
setblock 294 176 182 minecraft:polished_blackstone
fill 294 176 183 294 179 183 minecraft:red_nether_bricks
setblock 294 176 222 minecraft:polished_blackstone
fill 295 176 182 295 179 182 minecraft:red_nether_bricks
setblock 295 176 221 minecraft:polished_blackstone
fill 295 176 222 295 179 222 minecraft:red_nether_bricks
fill 296 176 221 296 178 221 minecraft:red_nether_bricks
setblock 298 176 183 minecraft:polished_blackstone
setblock 299 176 182 minecraft:polished_blackstone
fill 299 176 183 299 177 183 minecraft:red_nether_bricks
setblock 299 176 222 minecraft:polished_blackstone
fill 300 176 182 303 176 182 minecraft:red_nether_bricks
setblock 300 176 221 minecraft:polished_blackstone
fill 300 176 222 303 176 222 minecraft:red_nether_bricks
fill 303 176 221 304 176 221 minecraft:red_nether_bricks
setblock 304 176 182 minecraft:polished_blackstone
setblock 304 176 222 minecraft:polished_blackstone
fill 305 176 182 305 179 182 minecraft:red_nether_bricks
setblock 305 176 221 minecraft:polished_blackstone
fill 305 176 222 305 179 222 minecraft:red_nether_bricks
fill 306 176 221 306 179 221 minecraft:red_nether_bricks
setblock 307 176 183 minecraft:red_nether_bricks
fill 307 176 220 310 176 220 minecraft:red_nether_bricks
setblock 308 176 183 minecraft:polished_blackstone
setblock 309 176 182 minecraft:polished_blackstone
fill 309 176 183 309 179 183 minecraft:red_nether_bricks
setblock 309 176 222 minecraft:polished_blackstone
fill 310 176 182 310 179 182 minecraft:red_nether_bricks
fill 310 176 219 311 176 219 minecraft:red_nether_bricks
setblock 310 176 221 minecraft:polished_blackstone
fill 310 176 222 310 179 222 minecraft:red_nether_bricks
setblock 311 176 220 minecraft:polished_blackstone
fill 311 176 221 311 179 221 minecraft:red_nether_bricks
setblock 312 176 219 minecraft:polished_blackstone
fill 312 176 220 312 179 220 minecraft:red_nether_bricks
setblock 313 176 183 minecraft:polished_blackstone
fill 313 176 219 313 178 219 minecraft:red_nether_bricks
setblock 314 176 182 minecraft:polished_blackstone
fill 314 176 183 314 179 183 minecraft:red_nether_bricks
setblock 314 176 222 minecraft:polished_blackstone
fill 315 176 182 315 179 182 minecraft:red_nether_bricks
setblock 315 176 221 minecraft:polished_blackstone
fill 315 176 222 315 179 222 minecraft:red_nether_bricks
setblock 316 176 220 minecraft:polished_blackstone
fill 316 176 221 316 179 221 minecraft:red_nether_bricks
setblock 317 176 219 minecraft:polished_blackstone
fill 317 176 220 317 178 220 minecraft:red_nether_bricks
setblock 319 176 182 minecraft:polished_blackstone
setblock 319 176 222 minecraft:polished_blackstone
setblock 320 176 221 minecraft:polished_blackstone
fill 320 176 222 320 179 222 minecraft:red_nether_bricks
fill 321 176 221 321 177 221 minecraft:red_nether_bricks
setblock 322 176 219 minecraft:polished_blackstone
setblock 322 176 220 minecraft:red_nether_bricks
setblock 323 176 198 minecraft:polished_blackstone
fill 323 176 199 323 179 199 minecraft:red_nether_bricks
setblock 323 176 203 minecraft:polished_blackstone
fill 323 176 204 323 179 204 minecraft:red_nether_bricks
setblock 323 176 213 minecraft:polished_blackstone
setblock 323 176 214 minecraft:red_nether_bricks
setblock 323 176 218 minecraft:polished_blackstone
fill 323 176 219 323 178 219 minecraft:red_nether_bricks
fill 283 177 194 283 177 196 minecraft:red_nether_bricks
setblock 283 177 197 minecraft:polished_blackstone
fill 283 177 198 283 180 198 minecraft:red_nether_bricks
setblock 283 177 202 minecraft:polished_blackstone
fill 283 177 203 283 180 203 minecraft:red_nether_bricks
setblock 284 177 196 minecraft:polished_blackstone
fill 284 177 197 284 178 197 minecraft:red_nether_bricks
setblock 284 177 201 minecraft:polished_blackstone
fill 284 177 202 284 180 202 minecraft:red_nether_bricks
fill 286 177 222 287 177 222 minecraft:red_nether_bricks
setblock 287 177 182 minecraft:red_nether_bricks
setblock 288 177 182 minecraft:polished_blackstone
setblock 288 177 222 minecraft:polished_blackstone
fill 289 177 182 289 179 183 minecraft:red_nether_bricks
setblock 289 177 221 minecraft:polished_blackstone
fill 289 177 222 292 177 222 minecraft:red_nether_bricks
fill 290 177 221 290 180 221 minecraft:red_nether_bricks
setblock 292 177 183 minecraft:polished_blackstone
setblock 293 177 182 minecraft:polished_blackstone
fill 293 177 183 293 180 183 minecraft:red_nether_bricks
setblock 293 177 222 minecraft:polished_blackstone
fill 294 177 182 294 180 182 minecraft:red_nether_bricks
setblock 294 177 221 minecraft:polished_blackstone
fill 294 177 222 294 180 222 minecraft:red_nether_bricks
fill 295 177 221 295 179 221 minecraft:red_nether_bricks
setblock 297 177 183 minecraft:polished_blackstone
setblock 298 177 182 minecraft:polished_blackstone
fill 298 177 183 298 180 183 minecraft:red_nether_bricks
setblock 298 177 222 minecraft:polished_blackstone
fill 299 177 182 302 177 182 minecraft:red_nether_bricks
fill 299 177 186 299 178 186 minecraft:magma_block
fill 299 177 222 302 177 222 minecraft:red_nether_bricks
setblock 303 177 182 minecraft:polished_blackstone
setblock 303 177 222 minecraft:polished_blackstone
fill 304 177 182 304 180 182 minecraft:red_nether_bricks
setblock 304 177 221 minecraft:polished_blackstone
fill 304 177 222 304 180 222 minecraft:red_nether_bricks
fill 305 177 221 305 180 221 minecraft:red_nether_bricks
setblock 307 177 183 minecraft:polished_blackstone
fill 307 177 220 309 177 220 minecraft:red_nether_bricks
setblock 308 177 182 minecraft:polished_blackstone
fill 308 177 183 308 180 183 minecraft:red_nether_bricks
setblock 308 177 222 minecraft:polished_blackstone
fill 309 177 182 309 180 182 minecraft:red_nether_bricks
setblock 309 177 221 minecraft:polished_blackstone
fill 309 177 222 309 180 222 minecraft:red_nether_bricks
setblock 310 177 219 minecraft:red_nether_bricks
setblock 310 177 220 minecraft:polished_blackstone
fill 310 177 221 310 180 221 minecraft:red_nether_bricks
setblock 311 177 219 minecraft:polished_blackstone
fill 311 177 220 311 180 220 minecraft:red_nether_bricks
setblock 312 177 183 minecraft:polished_blackstone
fill 312 177 219 312 178 219 minecraft:red_nether_bricks
setblock 313 177 182 minecraft:polished_blackstone
fill 313 177 183 313 180 183 minecraft:red_nether_bricks
setblock 313 177 222 minecraft:polished_blackstone
fill 314 177 182 314 180 182 minecraft:red_nether_bricks
setblock 314 177 221 minecraft:polished_blackstone
fill 314 177 222 314 180 222 minecraft:red_nether_bricks
setblock 315 177 220 minecraft:polished_blackstone
fill 315 177 221 315 180 221 minecraft:red_nether_bricks
fill 316 177 220 316 179 220 minecraft:red_nether_bricks
setblock 318 177 182 minecraft:polished_blackstone
setblock 318 177 222 minecraft:polished_blackstone
setblock 319 177 221 minecraft:polished_blackstone
fill 319 177 222 319 180 222 minecraft:red_nether_bricks
setblock 320 177 221 minecraft:red_nether_bricks
setblock 323 177 197 minecraft:polished_blackstone
fill 323 177 198 323 179 198 minecraft:red_nether_bricks
setblock 323 177 202 minecraft:polished_blackstone
fill 323 177 203 323 180 203 minecraft:red_nether_bricks
setblock 323 177 217 minecraft:polished_blackstone
fill 323 177 218 323 178 218 minecraft:red_nether_bricks
setblock 323 177 222 minecraft:polished_blackstone
setblock 283 178 195 minecraft:red_nether_bricks
setblock 283 178 196 minecraft:polished_blackstone
fill 283 178 197 283 181 197 minecraft:red_nether_bricks
setblock 283 178 201 minecraft:polished_blackstone
fill 283 178 202 283 181 202 minecraft:red_nether_bricks
fill 283 178 209 283 181 211 minecraft:magma_block
setblock 284 178 200 minecraft:polished_blackstone
fill 284 178 201 284 181 201 minecraft:red_nether_bricks
fill 284 178 210 284 181 210 minecraft:magma_block
setblock 286 178 182 minecraft:red_nether_bricks
setblock 286 178 222 minecraft:red_nether_bricks
setblock 287 178 182 minecraft:polished_blackstone
setblock 287 178 222 minecraft:polished_blackstone
fill 288 178 182 288 181 182 minecraft:red_nether_bricks
fill 288 178 222 291 178 222 minecraft:red_nether_bricks
setblock 291 178 183 minecraft:polished_blackstone
setblock 292 178 182 minecraft:polished_blackstone
fill 292 178 183 292 181 183 minecraft:red_nether_bricks
setblock 292 178 222 minecraft:polished_blackstone
fill 293 178 182 293 181 182 minecraft:red_nether_bricks
setblock 293 178 221 minecraft:polished_blackstone
fill 293 178 222 293 181 222 minecraft:red_nether_bricks
fill 294 178 221 294 179 221 minecraft:red_nether_bricks
setblock 296 178 183 minecraft:polished_blackstone
setblock 297 178 182 minecraft:polished_blackstone
fill 297 178 183 297 181 183 minecraft:red_nether_bricks
setblock 297 178 222 minecraft:polished_blackstone
fill 298 178 182 301 178 182 minecraft:red_nether_bricks
fill 298 178 222 301 178 222 minecraft:red_nether_bricks
setblock 302 178 182 minecraft:polished_blackstone
setblock 302 178 222 minecraft:polished_blackstone
fill 303 178 182 303 181 182 minecraft:red_nether_bricks
fill 303 178 222 303 181 222 minecraft:red_nether_bricks
fill 304 178 221 304 181 221 minecraft:red_nether_bricks
setblock 306 178 183 minecraft:polished_blackstone
setblock 307 178 182 minecraft:polished_blackstone
fill 307 178 183 307 181 183 minecraft:red_nether_bricks
fill 307 178 220 308 178 220 minecraft:red_nether_bricks
setblock 307 178 222 minecraft:polished_blackstone
fill 308 178 182 308 181 182 minecraft:red_nether_bricks
setblock 308 178 221 minecraft:polished_blackstone
fill 308 178 222 308 181 222 minecraft:red_nether_bricks
setblock 309 178 220 minecraft:polished_blackstone
fill 309 178 221 309 181 221 minecraft:red_nether_bricks
fill 310 178 220 310 181 220 minecraft:red_nether_bricks
setblock 311 178 183 minecraft:polished_blackstone
setblock 311 178 219 minecraft:red_nether_bricks
setblock 312 178 182 minecraft:polished_blackstone
fill 312 178 183 312 181 183 minecraft:red_nether_bricks
setblock 312 178 222 minecraft:polished_blackstone
fill 313 178 182 313 181 182 minecraft:red_nether_bricks
setblock 313 178 221 minecraft:polished_blackstone
fill 313 178 222 313 181 222 minecraft:red_nether_bricks
setblock 314 178 220 minecraft:polished_blackstone
fill 314 178 221 314 181 221 minecraft:red_nether_bricks
fill 315 178 220 315 179 220 minecraft:red_nether_bricks
setblock 317 178 182 minecraft:polished_blackstone
fill 317 178 203 317 178 205 minecraft:polished_blackstone
setblock 317 178 222 minecraft:polished_blackstone
setblock 318 178 182 minecraft:red_nether_bricks
fill 318 178 202 320 178 202 minecraft:polished_blackstone
fill 318 178 206 320 178 206 minecraft:polished_blackstone
setblock 318 178 221 minecraft:polished_blackstone
fill 318 178 222 318 181 222 minecraft:red_nether_bricks
setblock 319 178 221 minecraft:red_nether_bricks
fill 321 178 203 321 178 205 minecraft:polished_blackstone
setblock 322 178 222 minecraft:polished_blackstone
setblock 323 178 201 minecraft:polished_blackstone
fill 323 178 202 323 181 202 minecraft:red_nether_bricks
setblock 323 178 206 minecraft:polished_blackstone
setblock 323 178 221 minecraft:polished_blackstone
setblock 323 178 222 minecraft:red_nether_bricks
fill 283 179 196 283 182 196 minecraft:red_nether_bricks
setblock 283 179 200 minecraft:polished_blackstone
fill 283 179 201 283 182 201 minecraft:red_nether_bricks
setblock 283 179 205 minecraft:polished_blackstone
fill 283 179 206 283 182 206 minecraft:red_nether_bricks
setblock 284 179 199 minecraft:polished_blackstone
fill 284 179 200 284 182 200 minecraft:red_nether_bricks
fill 284 179 209 284 181 209 minecraft:magma_block
fill 284 179 211 284 181 211 minecraft:magma_block
setblock 286 179 182 minecraft:polished_blackstone
setblock 286 179 222 minecraft:polished_blackstone
fill 287 179 182 287 182 182 minecraft:red_nether_bricks
fill 287 179 222 290 179 222 minecraft:red_nether_bricks
fill 288 179 183 288 180 183 minecraft:red_nether_bricks
setblock 290 179 182 minecraft:red_nether_bricks
setblock 290 179 183 minecraft:polished_blackstone
setblock 291 179 182 minecraft:polished_blackstone
fill 291 179 183 291 182 183 minecraft:red_nether_bricks
setblock 291 179 222 minecraft:polished_blackstone
fill 292 179 182 292 182 182 minecraft:red_nether_bricks
fill 292 179 184 293 179 184 minecraft:red_nether_bricks
setblock 292 179 221 minecraft:polished_blackstone
fill 292 179 222 292 182 222 minecraft:red_nether_bricks
fill 293 179 221 293 180 221 minecraft:red_nether_bricks
setblock 295 179 183 minecraft:polished_blackstone
setblock 296 179 182 minecraft:polished_blackstone
fill 296 179 183 296 182 183 minecraft:red_nether_bricks
setblock 296 179 222 minecraft:polished_blackstone
fill 297 179 182 300 179 182 minecraft:red_nether_bricks
fill 297 179 222 300 179 222 minecraft:red_nether_bricks
setblock 301 179 182 minecraft:polished_blackstone
setblock 301 179 222 minecraft:polished_blackstone
fill 302 179 182 302 182 182 minecraft:red_nether_bricks
fill 302 179 222 302 182 222 minecraft:red_nether_bricks
setblock 305 179 183 minecraft:polished_blackstone
setblock 306 179 182 minecraft:polished_blackstone
fill 306 179 183 306 182 183 minecraft:red_nether_bricks
setblock 306 179 222 minecraft:polished_blackstone
fill 307 179 182 307 182 182 minecraft:red_nether_bricks
setblock 307 179 220 minecraft:red_nether_bricks
setblock 307 179 221 minecraft:polished_blackstone
fill 307 179 222 307 182 222 minecraft:red_nether_bricks
setblock 308 179 220 minecraft:polished_blackstone
fill 308 179 221 308 182 221 minecraft:red_nether_bricks
fill 309 179 220 309 182 220 minecraft:red_nether_bricks
setblock 310 179 183 minecraft:polished_blackstone
setblock 311 179 182 minecraft:polished_blackstone
fill 311 179 183 311 182 183 minecraft:red_nether_bricks
setblock 311 179 222 minecraft:polished_blackstone
fill 312 179 182 312 182 182 minecraft:red_nether_bricks
setblock 312 179 221 minecraft:polished_blackstone
fill 312 179 222 312 182 222 minecraft:red_nether_bricks
setblock 313 179 220 minecraft:polished_blackstone
fill 313 179 221 313 182 221 minecraft:red_nether_bricks
fill 314 179 220 314 180 220 minecraft:red_nether_bricks
setblock 316 179 182 minecraft:polished_blackstone
setblock 316 179 222 minecraft:polished_blackstone
fill 317 179 182 317 180 182 minecraft:red_nether_bricks
setblock 317 179 221 minecraft:polished_blackstone
fill 317 179 222 317 182 222 minecraft:red_nether_bricks
setblock 318 179 221 minecraft:red_nether_bricks
setblock 321 179 222 minecraft:polished_blackstone
setblock 322 179 222 minecraft:red_nether_bricks
setblock 323 179 200 minecraft:polished_blackstone
fill 323 179 201 323 182 201 minecraft:red_nether_bricks
setblock 323 179 205 minecraft:polished_blackstone
fill 323 179 206 323 182 206 minecraft:red_nether_bricks
setblock 323 179 220 minecraft:polished_blackstone
setblock 323 179 221 minecraft:red_nether_bricks
setblock 283 180 199 minecraft:polished_blackstone
fill 283 180 200 283 183 200 minecraft:red_nether_bricks
setblock 283 180 204 minecraft:polished_blackstone
fill 283 180 205 283 183 205 minecraft:red_nether_bricks
setblock 284 180 198 minecraft:polished_blackstone
fill 284 180 199 284 183 199 minecraft:red_nether_bricks
setblock 284 180 203 minecraft:polished_blackstone
fill 284 180 204 284 183 204 minecraft:red_nether_bricks
setblock 285 180 182 minecraft:polished_blackstone
setblock 285 180 184 minecraft:light[level=14]
setblock 285 180 192 minecraft:light[level=14]
setblock 285 180 200 minecraft:light[level=14]
setblock 285 180 208 minecraft:light[level=14]
fill 285 180 209 285 181 211 minecraft:magma_block
setblock 285 180 216 minecraft:light[level=14]
fill 286 180 182 286 183 182 minecraft:red_nether_bricks
fill 286 180 222 289 180 222 minecraft:red_nether_bricks
fill 287 180 183 287 181 183 minecraft:red_nether_bricks
setblock 289 180 182 minecraft:red_nether_bricks
setblock 289 180 183 minecraft:polished_blackstone
setblock 290 180 182 minecraft:polished_blackstone
fill 290 180 183 290 182 184 minecraft:red_nether_bricks
setblock 290 180 222 minecraft:polished_blackstone
fill 291 180 182 291 183 182 minecraft:red_nether_bricks
fill 291 180 184 292 180 184 minecraft:red_nether_bricks
setblock 291 180 221 minecraft:polished_blackstone
fill 291 180 222 291 183 222 minecraft:red_nether_bricks
fill 292 180 221 292 181 221 minecraft:red_nether_bricks
setblock 293 180 184 minecraft:polished_blackstone
setblock 293 180 192 minecraft:light[level=14]
setblock 293 180 200 minecraft:light[level=14]
setblock 293 180 208 minecraft:light[level=14]
setblock 293 180 216 minecraft:light[level=14]
setblock 294 180 183 minecraft:polished_blackstone
setblock 295 180 182 minecraft:polished_blackstone
fill 295 180 183 295 183 183 minecraft:red_nether_bricks
setblock 295 180 222 minecraft:polished_blackstone
fill 296 180 182 299 180 182 minecraft:red_nether_bricks
fill 296 180 222 299 180 222 minecraft:red_nether_bricks
setblock 300 180 182 minecraft:polished_blackstone
setblock 300 180 222 minecraft:polished_blackstone
fill 301 180 182 301 183 182 minecraft:red_nether_bricks
setblock 301 180 184 minecraft:light[level=14]
setblock 301 180 192 minecraft:light[level=14]
setblock 301 180 200 minecraft:light[level=14]
setblock 301 180 216 minecraft:light[level=14]
fill 301 180 222 301 183 222 minecraft:red_nether_bricks
setblock 304 180 183 minecraft:polished_blackstone
setblock 305 180 182 minecraft:polished_blackstone
fill 305 180 183 305 183 183 minecraft:red_nether_bricks
setblock 305 180 222 minecraft:polished_blackstone
fill 306 180 182 306 183 182 minecraft:red_nether_bricks
setblock 306 180 221 minecraft:polished_blackstone
fill 306 180 222 306 183 222 minecraft:red_nether_bricks
setblock 307 180 220 minecraft:polished_blackstone
fill 307 180 221 307 183 221 minecraft:red_nether_bricks
fill 308 180 220 308 183 220 minecraft:red_nether_bricks
setblock 309 180 183 minecraft:polished_blackstone
setblock 309 180 184 minecraft:light[level=14]
setblock 309 180 192 minecraft:light[level=14]
setblock 309 180 200 minecraft:light[level=14]
setblock 309 180 208 minecraft:light[level=14]
setblock 309 180 216 minecraft:light[level=14]
setblock 310 180 182 minecraft:polished_blackstone
fill 310 180 183 310 183 183 minecraft:red_nether_bricks
fill 310 180 184 310 180 185 minecraft:polished_blackstone
setblock 310 180 222 minecraft:polished_blackstone
fill 311 180 182 311 183 182 minecraft:red_nether_bricks
fill 311 180 185 312 180 185 minecraft:polished_blackstone
setblock 311 180 221 minecraft:polished_blackstone
fill 311 180 222 311 183 222 minecraft:red_nether_bricks
setblock 312 180 184 minecraft:polished_blackstone
setblock 312 180 220 minecraft:polished_blackstone
fill 312 180 221 312 183 221 minecraft:red_nether_bricks
fill 313 180 220 313 182 220 minecraft:red_nether_bricks
setblock 314 180 183 minecraft:polished_blackstone
setblock 315 180 182 minecraft:polished_blackstone
setblock 315 180 222 minecraft:polished_blackstone
fill 316 180 182 316 183 182 minecraft:red_nether_bricks
setblock 316 180 221 minecraft:polished_blackstone
fill 316 180 222 316 183 222 minecraft:red_nether_bricks
setblock 317 180 184 minecraft:light[level=14]
setblock 317 180 192 minecraft:light[level=14]
setblock 317 180 200 minecraft:light[level=14]
setblock 317 180 208 minecraft:light[level=14]
setblock 317 180 216 minecraft:light[level=14]
setblock 317 180 221 minecraft:red_nether_bricks
setblock 320 180 222 minecraft:polished_blackstone
setblock 323 180 199 minecraft:polished_blackstone
fill 323 180 200 323 183 200 minecraft:red_nether_bricks
setblock 323 180 204 minecraft:polished_blackstone
fill 323 180 205 323 183 205 minecraft:red_nether_bricks
fill 323 180 207 323 181 207 minecraft:red_nether_bricks
setblock 283 181 198 minecraft:polished_blackstone
fill 283 181 199 283 184 199 minecraft:red_nether_bricks
setblock 283 181 203 minecraft:polished_blackstone
fill 283 181 204 283 184 204 minecraft:red_nether_bricks
setblock 283 181 207 minecraft:red_nether_bricks
setblock 284 181 182 minecraft:polished_blackstone
fill 284 181 198 284 184 198 minecraft:red_nether_bricks
setblock 284 181 202 minecraft:polished_blackstone
fill 284 181 203 284 184 203 minecraft:red_nether_bricks
fill 284 181 205 284 182 205 minecraft:red_nether_bricks
fill 285 181 182 285 184 182 minecraft:red_nether_bricks
setblock 285 181 201 minecraft:polished_blackstone
fill 285 181 202 285 184 202 minecraft:red_nether_bricks
fill 286 181 183 286 182 183 minecraft:red_nether_bricks
fill 286 181 210 286 182 210 minecraft:magma_block
fill 286 181 222 288 181 222 minecraft:red_nether_bricks
setblock 288 181 183 minecraft:polished_blackstone
setblock 289 181 182 minecraft:polished_blackstone
fill 289 181 183 289 183 184 minecraft:red_nether_bricks
setblock 289 181 222 minecraft:polished_blackstone
fill 290 181 182 290 184 182 minecraft:red_nether_bricks
setblock 290 181 221 minecraft:polished_blackstone
fill 290 181 222 290 184 222 minecraft:red_nether_bricks
setblock 291 181 184 minecraft:red_nether_bricks
fill 291 181 221 291 183 221 minecraft:red_nether_bricks
setblock 292 181 184 minecraft:polished_blackstone
setblock 293 181 183 minecraft:polished_blackstone
fill 293 181 184 294 183 184 minecraft:red_nether_bricks
setblock 294 181 182 minecraft:polished_blackstone
fill 294 181 183 294 184 183 minecraft:red_nether_bricks
setblock 294 181 222 minecraft:polished_blackstone
fill 295 181 182 298 181 182 minecraft:red_nether_bricks
fill 295 181 222 298 181 222 minecraft:red_nether_bricks
setblock 298 181 183 minecraft:polished_blackstone
setblock 299 181 182 minecraft:polished_blackstone
fill 299 181 183 299 184 183 minecraft:red_nether_bricks
setblock 299 181 222 minecraft:polished_blackstone
fill 300 181 182 300 184 182 minecraft:red_nether_bricks
fill 300 181 222 300 184 222 minecraft:red_nether_bricks
setblock 303 181 183 minecraft:polished_blackstone
setblock 304 181 182 minecraft:polished_blackstone
fill 304 181 183 304 184 183 minecraft:red_nether_bricks
setblock 304 181 222 minecraft:polished_blackstone
fill 305 181 182 305 184 182 minecraft:red_nether_bricks
setblock 305 181 221 minecraft:polished_blackstone
fill 305 181 222 305 184 222 minecraft:red_nether_bricks
fill 306 181 221 306 184 221 minecraft:red_nether_bricks
fill 307 181 220 307 184 220 minecraft:red_nether_bricks
setblock 308 181 183 minecraft:polished_blackstone
setblock 309 181 182 minecraft:polished_blackstone
fill 309 181 183 309 184 183 minecraft:red_nether_bricks
setblock 309 181 222 minecraft:polished_blackstone
fill 310 181 182 310 184 182 minecraft:red_nether_bricks
setblock 310 181 221 minecraft:polished_blackstone
fill 310 181 222 310 184 222 minecraft:red_nether_bricks
setblock 311 181 220 minecraft:polished_blackstone
fill 311 181 221 311 184 221 minecraft:red_nether_bricks
fill 312 181 220 312 183 220 minecraft:red_nether_bricks
setblock 313 181 183 minecraft:polished_blackstone
setblock 314 181 182 minecraft:polished_blackstone
fill 314 181 183 314 184 183 minecraft:red_nether_bricks
setblock 314 181 222 minecraft:polished_blackstone
fill 315 181 182 315 184 182 minecraft:red_nether_bricks
fill 315 181 193 316 182 194 minecraft:blackstone
setblock 315 181 221 minecraft:polished_blackstone
fill 315 181 222 315 184 222 minecraft:red_nether_bricks
fill 316 181 221 316 182 221 minecraft:red_nether_bricks
setblock 319 181 222 minecraft:polished_blackstone
setblock 322 181 203 minecraft:red_nether_bricks
setblock 322 181 204 minecraft:polished_blackstone
setblock 323 181 198 minecraft:polished_blackstone
fill 323 181 199 323 184 199 minecraft:red_nether_bricks
setblock 323 181 203 minecraft:polished_blackstone
fill 323 181 204 323 184 204 minecraft:red_nether_bricks
setblock 323 181 208 minecraft:polished_blackstone
setblock 283 182 182 minecraft:polished_blackstone
fill 283 182 183 283 183 185 minecraft:red_nether_bricks
setblock 283 182 197 minecraft:polished_blackstone
fill 283 182 198 283 185 198 minecraft:red_nether_bricks
setblock 283 182 202 minecraft:polished_blackstone
fill 283 182 203 283 185 203 minecraft:red_nether_bricks
setblock 283 182 207 minecraft:polished_blackstone
fill 283 182 208 283 185 208 minecraft:red_nether_bricks
fill 284 182 182 284 185 182 minecraft:red_nether_bricks
setblock 284 182 201 minecraft:polished_blackstone
fill 284 182 202 284 185 202 minecraft:red_nether_bricks
setblock 284 182 206 minecraft:polished_blackstone
fill 285 182 183 285 183 183 minecraft:red_nether_bricks
setblock 285 182 200 minecraft:polished_blackstone
fill 285 182 201 285 185 201 minecraft:red_nether_bricks
fill 285 182 203 285 183 203 minecraft:red_nether_bricks
setblock 285 182 210 minecraft:magma_block
fill 285 182 222 287 182 222 minecraft:red_nether_bricks
setblock 287 182 183 minecraft:polished_blackstone
fill 287 182 184 288 184 184 minecraft:red_nether_bricks
fill 287 182 210 287 183 210 minecraft:magma_block
setblock 288 182 182 minecraft:polished_blackstone
fill 288 182 183 288 185 183 minecraft:red_nether_bricks
setblock 288 182 222 minecraft:polished_blackstone
fill 289 182 182 289 185 182 minecraft:red_nether_bricks
fill 289 182 222 289 185 222 minecraft:red_nether_bricks
fill 290 182 221 290 185 221 minecraft:red_nether_bricks
setblock 291 182 184 minecraft:polished_blackstone
setblock 292 182 183 minecraft:polished_blackstone
fill 292 182 184 292 185 184 minecraft:red_nether_bricks
setblock 293 182 182 minecraft:polished_blackstone
fill 293 182 183 293 185 183 minecraft:red_nether_bricks
setblock 293 182 222 minecraft:polished_blackstone
fill 294 182 182 297 182 182 minecraft:red_nether_bricks
fill 294 182 222 297 182 222 minecraft:red_nether_bricks
setblock 297 182 183 minecraft:polished_blackstone
setblock 298 182 182 minecraft:polished_blackstone
fill 298 182 183 298 185 183 minecraft:red_nether_bricks
setblock 298 182 222 minecraft:polished_blackstone
fill 299 182 182 299 185 182 minecraft:red_nether_bricks
fill 299 182 222 299 185 222 minecraft:red_nether_bricks
fill 300 182 183 301 182 183 minecraft:red_nether_bricks
setblock 302 182 183 minecraft:polished_blackstone
setblock 303 182 182 minecraft:polished_blackstone
fill 303 182 183 303 185 183 minecraft:red_nether_bricks
setblock 303 182 222 minecraft:polished_blackstone
fill 304 182 182 304 185 182 minecraft:red_nether_bricks
setblock 304 182 221 minecraft:polished_blackstone
fill 304 182 222 304 185 222 minecraft:red_nether_bricks
fill 305 182 221 305 185 221 minecraft:red_nether_bricks
setblock 307 182 183 minecraft:polished_blackstone
fill 307 182 184 310 182 184 minecraft:red_nether_bricks
setblock 308 182 182 minecraft:polished_blackstone
fill 308 182 183 308 185 183 minecraft:red_nether_bricks
setblock 308 182 222 minecraft:polished_blackstone
fill 309 182 182 309 185 182 minecraft:red_nether_bricks
setblock 309 182 221 minecraft:polished_blackstone
fill 309 182 222 309 185 222 minecraft:red_nether_bricks
setblock 310 182 220 minecraft:polished_blackstone
fill 310 182 221 310 185 221 minecraft:red_nether_bricks
fill 311 182 220 311 185 220 minecraft:red_nether_bricks
setblock 312 182 183 minecraft:polished_blackstone
setblock 313 182 182 minecraft:polished_blackstone
fill 313 182 183 313 185 183 minecraft:red_nether_bricks
setblock 313 182 222 minecraft:polished_blackstone
fill 314 182 182 314 185 182 minecraft:red_nether_bricks
setblock 314 182 221 minecraft:polished_blackstone
fill 314 182 222 314 185 222 minecraft:red_nether_bricks
fill 315 182 221 315 183 221 minecraft:red_nether_bricks
setblock 318 182 222 minecraft:polished_blackstone
setblock 319 182 222 minecraft:red_nether_bricks
setblock 322 182 202 minecraft:red_nether_bricks
setblock 322 182 203 minecraft:polished_blackstone
fill 322 182 204 322 183 206 minecraft:red_nether_bricks
fill 323 182 198 323 185 198 minecraft:red_nether_bricks
setblock 323 182 202 minecraft:polished_blackstone
fill 323 182 203 323 185 203 minecraft:red_nether_bricks
setblock 323 182 207 minecraft:polished_blackstone
fill 323 182 208 323 183 210 minecraft:red_nether_bricks
fill 283 183 182 283 186 182 minecraft:red_nether_bricks
setblock 283 183 186 minecraft:polished_blackstone
fill 283 183 187 283 184 189 minecraft:red_nether_bricks
fill 283 183 194 283 183 195 minecraft:red_nether_bricks
setblock 283 183 196 minecraft:polished_blackstone
fill 283 183 197 284 185 197 minecraft:red_nether_bricks
setblock 283 183 201 minecraft:polished_blackstone
fill 283 183 202 283 186 202 minecraft:red_nether_bricks
setblock 283 183 206 minecraft:polished_blackstone
fill 283 183 207 284 185 207 minecraft:red_nether_bricks
fill 283 183 209 283 184 209 minecraft:red_nether_bricks
fill 284 183 183 284 183 184 minecraft:red_nether_bricks
setblock 284 183 185 minecraft:polished_blackstone
fill 284 183 186 284 186 186 minecraft:red_nether_bricks
setblock 284 183 200 minecraft:polished_blackstone
fill 284 183 201 284 186 201 minecraft:red_nether_bricks
setblock 284 183 205 minecraft:polished_blackstone
fill 284 183 206 284 186 206 minecraft:red_nether_bricks
fill 285 183 200 285 186 200 minecraft:red_nether_bricks
setblock 285 183 204 minecraft:polished_blackstone
fill 285 183 205 285 186 205 minecraft:red_nether_bricks
fill 285 183 222 286 183 222 minecraft:red_nether_bricks
setblock 286 183 183 minecraft:polished_blackstone
fill 286 183 184 286 186 184 minecraft:red_nether_bricks
setblock 287 183 182 minecraft:polished_blackstone
fill 287 183 183 287 186 183 minecraft:red_nether_bricks
setblock 287 183 222 minecraft:polished_blackstone
fill 288 183 182 288 186 182 minecraft:red_nether_bricks
setblock 288 183 210 minecraft:magma_block
fill 288 183 222 288 186 222 minecraft:red_nether_bricks
setblock 290 183 183 minecraft:red_nether_bricks
setblock 290 183 184 minecraft:polished_blackstone
fill 290 183 185 290 186 185 minecraft:red_nether_bricks
setblock 291 183 183 minecraft:polished_blackstone
fill 291 183 184 291 186 184 minecraft:red_nether_bricks
setblock 292 183 182 minecraft:polished_blackstone
fill 292 183 183 292 186 183 minecraft:red_nether_bricks
setblock 292 183 222 minecraft:polished_blackstone
fill 293 183 182 296 183 182 minecraft:red_nether_bricks
fill 293 183 222 296 183 222 minecraft:red_nether_bricks
setblock 295 183 184 minecraft:polished_blackstone
setblock 296 183 183 minecraft:polished_blackstone
setblock 297 183 182 minecraft:polished_blackstone
fill 297 183 183 297 186 183 minecraft:red_nether_bricks
setblock 297 183 222 minecraft:polished_blackstone
fill 298 183 182 298 186 182 minecraft:red_nether_bricks
fill 298 183 222 298 186 222 minecraft:red_nether_bricks
setblock 300 183 183 minecraft:red_nether_bricks
setblock 301 183 183 minecraft:polished_blackstone
setblock 302 183 182 minecraft:polished_blackstone
fill 302 183 183 302 186 183 minecraft:red_nether_bricks
setblock 302 183 222 minecraft:polished_blackstone
fill 303 183 182 303 186 182 minecraft:red_nether_bricks
setblock 303 183 221 minecraft:polished_blackstone
fill 303 183 222 303 186 222 minecraft:red_nether_bricks
fill 304 183 221 304 186 221 minecraft:red_nether_bricks
setblock 305 183 184 minecraft:polished_blackstone
setblock 306 183 183 minecraft:polished_blackstone
fill 306 183 184 309 183 184 minecraft:red_nether_bricks
setblock 307 183 182 minecraft:polished_blackstone
fill 307 183 183 307 186 183 minecraft:red_nether_bricks
setblock 307 183 222 minecraft:polished_blackstone
fill 308 183 182 308 186 182 minecraft:red_nether_bricks
setblock 308 183 221 minecraft:polished_blackstone
fill 308 183 222 308 186 222 minecraft:red_nether_bricks
setblock 309 183 220 minecraft:polished_blackstone
fill 309 183 221 309 186 221 minecraft:red_nether_bricks
setblock 310 183 184 minecraft:polished_blackstone
fill 310 183 220 310 186 220 minecraft:red_nether_bricks
setblock 311 183 183 minecraft:polished_blackstone
setblock 312 183 182 minecraft:polished_blackstone
fill 312 183 183 312 186 183 minecraft:red_nether_bricks
setblock 312 183 222 minecraft:polished_blackstone
fill 313 183 182 313 186 182 minecraft:red_nether_bricks
setblock 313 183 221 minecraft:polished_blackstone
fill 313 183 222 313 186 222 minecraft:red_nether_bricks
fill 314 183 221 314 185 221 minecraft:red_nether_bricks
setblock 317 183 222 minecraft:polished_blackstone
fill 318 183 222 318 184 222 minecraft:red_nether_bricks
setblock 322 183 201 minecraft:red_nether_bricks
setblock 322 183 202 minecraft:polished_blackstone
fill 322 183 203 322 186 203 minecraft:red_nether_bricks
setblock 322 183 207 minecraft:polished_blackstone
fill 322 183 208 322 186 208 minecraft:red_nether_bricks
setblock 323 183 201 minecraft:polished_blackstone
fill 323 183 202 323 186 202 minecraft:red_nether_bricks
setblock 323 183 206 minecraft:polished_blackstone
fill 323 183 207 323 186 207 minecraft:red_nether_bricks
setblock 323 183 211 minecraft:polished_blackstone
fill 283 184 183 283 184 184 minecraft:red_nether_bricks
setblock 283 184 185 minecraft:polished_blackstone
fill 283 184 186 283 187 186 minecraft:red_nether_bricks
setblock 283 184 190 minecraft:polished_blackstone
fill 283 184 191 283 184 194 minecraft:red_nether_bricks
setblock 283 184 195 minecraft:polished_blackstone
fill 283 184 196 284 186 196 minecraft:red_nether_bricks
setblock 283 184 200 minecraft:polished_blackstone
fill 283 184 201 283 187 201 minecraft:red_nether_bricks
setblock 283 184 205 minecraft:polished_blackstone
fill 283 184 206 283 187 206 minecraft:red_nether_bricks
setblock 283 184 210 minecraft:polished_blackstone
setblock 284 184 183 minecraft:red_nether_bricks
setblock 284 184 184 minecraft:polished_blackstone
fill 284 184 185 285 186 185 minecraft:red_nether_bricks
fill 284 184 187 284 184 188 minecraft:red_nether_bricks
setblock 284 184 189 minecraft:polished_blackstone
fill 284 184 190 284 187 190 minecraft:red_nether_bricks
setblock 284 184 199 minecraft:polished_blackstone
fill 284 184 200 284 187 200 minecraft:red_nether_bricks
setblock 284 184 204 minecraft:polished_blackstone
fill 284 184 205 284 187 205 minecraft:red_nether_bricks
setblock 284 184 208 minecraft:red_nether_bricks
fill 284 184 222 285 184 222 minecraft:red_nether_bricks
setblock 285 184 183 minecraft:polished_blackstone
fill 285 184 184 285 187 184 minecraft:red_nether_bricks
fill 285 184 186 285 184 187 minecraft:red_nether_bricks
fill 285 184 199 285 187 199 minecraft:red_nether_bricks
setblock 285 184 203 minecraft:polished_blackstone
fill 285 184 204 285 187 204 minecraft:red_nether_bricks
fill 285 184 206 285 185 206 minecraft:red_nether_bricks
setblock 286 184 182 minecraft:polished_blackstone
fill 286 184 183 286 187 183 minecraft:red_nether_bricks
setblock 286 184 222 minecraft:polished_blackstone
fill 287 184 182 287 187 182 minecraft:red_nether_bricks
setblock 287 184 185 minecraft:red_nether_bricks
fill 287 184 222 287 187 222 minecraft:red_nether_bricks
setblock 288 184 185 minecraft:polished_blackstone
setblock 289 184 183 minecraft:red_nether_bricks
setblock 289 184 184 minecraft:polished_blackstone
fill 289 184 185 289 187 185 minecraft:red_nether_bricks
fill 289 184 221 289 186 221 minecraft:red_nether_bricks
setblock 290 184 183 minecraft:polished_blackstone
fill 290 184 184 290 187 184 minecraft:red_nether_bricks
setblock 291 184 182 minecraft:polished_blackstone
fill 291 184 183 291 187 183 minecraft:red_nether_bricks
fill 291 184 185 292 184 185 minecraft:red_nether_bricks
setblock 291 184 222 minecraft:polished_blackstone
fill 292 184 182 295 184 182 minecraft:red_nether_bricks
fill 292 184 222 295 184 222 minecraft:red_nether_bricks
setblock 293 184 184 minecraft:red_nether_bricks
setblock 294 184 184 minecraft:polished_blackstone
setblock 295 184 183 minecraft:polished_blackstone
fill 295 184 184 296 186 184 minecraft:red_nether_bricks
setblock 296 184 182 minecraft:polished_blackstone
fill 296 184 183 296 187 183 minecraft:red_nether_bricks
setblock 296 184 222 minecraft:polished_blackstone
fill 297 184 182 297 187 182 minecraft:red_nether_bricks
fill 297 184 222 297 187 222 minecraft:red_nether_bricks
setblock 300 184 183 minecraft:polished_blackstone
setblock 301 184 182 minecraft:polished_blackstone
fill 301 184 183 301 187 183 minecraft:red_nether_bricks
setblock 301 184 222 minecraft:polished_blackstone
fill 302 184 182 302 187 182 minecraft:red_nether_bricks
setblock 302 184 221 minecraft:polished_blackstone
fill 302 184 222 302 187 222 minecraft:red_nether_bricks
setblock 303 184 184 minecraft:red_nether_bricks
fill 303 184 221 303 187 221 minecraft:red_nether_bricks
setblock 304 184 184 minecraft:polished_blackstone
setblock 305 184 183 minecraft:polished_blackstone
fill 305 184 184 308 184 184 minecraft:red_nether_bricks
setblock 306 184 182 minecraft:polished_blackstone
fill 306 184 183 306 187 183 minecraft:red_nether_bricks
fill 306 184 220 306 185 220 minecraft:red_nether_bricks
setblock 306 184 222 minecraft:polished_blackstone
fill 307 184 182 307 187 182 minecraft:red_nether_bricks
setblock 307 184 221 minecraft:polished_blackstone
fill 307 184 222 307 187 222 minecraft:red_nether_bricks
setblock 308 184 220 minecraft:polished_blackstone
fill 308 184 221 308 187 221 minecraft:red_nether_bricks
setblock 309 184 184 minecraft:polished_blackstone
fill 309 184 220 309 187 220 minecraft:red_nether_bricks
setblock 310 184 183 minecraft:polished_blackstone
fill 310 184 184 311 186 184 minecraft:red_nether_bricks
setblock 311 184 182 minecraft:polished_blackstone
fill 311 184 183 311 187 183 minecraft:red_nether_bricks
setblock 311 184 222 minecraft:polished_blackstone
fill 312 184 182 312 187 182 minecraft:red_nether_bricks
setblock 312 184 221 minecraft:polished_blackstone
fill 312 184 222 312 187 222 minecraft:red_nether_bricks
fill 313 184 221 313 186 221 minecraft:red_nether_bricks
setblock 316 184 182 minecraft:polished_blackstone
setblock 316 184 222 minecraft:polished_blackstone
fill 317 184 222 317 185 222 minecraft:red_nether_bricks
setblock 322 184 200 minecraft:red_nether_bricks
setblock 322 184 201 minecraft:polished_blackstone
fill 322 184 202 322 187 202 minecraft:red_nether_bricks
fill 322 184 204 322 184 205 minecraft:red_nether_bricks
setblock 322 184 206 minecraft:polished_blackstone
fill 322 184 207 322 187 207 minecraft:red_nether_bricks
fill 322 184 209 323 184 209 minecraft:red_nether_bricks
fill 323 184 182 323 184 184 minecraft:red_nether_bricks
setblock 323 184 185 minecraft:polished_blackstone
fill 323 184 186 323 187 186 minecraft:red_nether_bricks
fill 323 184 197 323 186 197 minecraft:red_nether_bricks
setblock 323 184 200 minecraft:polished_blackstone
fill 323 184 201 323 187 201 minecraft:red_nether_bricks
setblock 323 184 205 minecraft:polished_blackstone
fill 323 184 206 323 187 206 minecraft:red_nether_bricks
fill 323 184 208 323 185 208 minecraft:red_nether_bricks
setblock 323 184 210 minecraft:polished_blackstone
fill 323 184 211 323 185 213 minecraft:red_nether_bricks
fill 323 184 222 323 186 222 minecraft:red_nether_bricks
setblock 283 185 183 minecraft:red_nether_bricks
setblock 283 185 184 minecraft:polished_blackstone
fill 283 185 185 283 188 185 minecraft:red_nether_bricks
fill 283 185 187 283 185 188 minecraft:red_nether_bricks
setblock 283 185 189 minecraft:polished_blackstone
fill 283 185 190 283 185 193 minecraft:red_nether_bricks
setblock 283 185 194 minecraft:polished_blackstone
fill 283 185 195 284 187 195 minecraft:red_nether_bricks
setblock 283 185 199 minecraft:polished_blackstone
fill 283 185 200 283 188 200 minecraft:red_nether_bricks
setblock 283 185 204 minecraft:polished_blackstone
fill 283 185 205 283 188 205 minecraft:red_nether_bricks
setblock 283 185 209 minecraft:polished_blackstone
fill 283 185 210 283 187 211 minecraft:red_nether_bricks
setblock 284 185 183 minecraft:polished_blackstone
fill 284 185 184 284 188 184 minecraft:red_nether_bricks
setblock 284 185 187 minecraft:red_nether_bricks
setblock 284 185 188 minecraft:polished_blackstone
fill 284 185 189 285 187 189 minecraft:red_nether_bricks
fill 284 185 191 284 185 192 minecraft:red_nether_bricks
setblock 284 185 193 minecraft:polished_blackstone
fill 284 185 194 284 188 194 minecraft:red_nether_bricks
setblock 284 185 198 minecraft:polished_blackstone
fill 284 185 199 284 188 199 minecraft:red_nether_bricks
setblock 284 185 203 minecraft:polished_blackstone
fill 284 185 204 284 188 204 minecraft:red_nether_bricks
setblock 284 185 208 minecraft:polished_blackstone
fill 284 185 209 284 187 210 minecraft:red_nether_bricks
setblock 284 185 222 minecraft:red_nether_bricks
setblock 285 185 182 minecraft:polished_blackstone
fill 285 185 183 285 188 183 minecraft:red_nether_bricks
setblock 285 185 186 minecraft:red_nether_bricks
setblock 285 185 187 minecraft:polished_blackstone
fill 285 185 188 285 188 188 minecraft:red_nether_bricks
fill 285 185 190 285 186 190 minecraft:red_nether_bricks
setblock 285 185 202 minecraft:polished_blackstone
fill 285 185 203 285 188 203 minecraft:red_nether_bricks
setblock 285 185 207 minecraft:polished_blackstone
fill 285 185 208 285 188 208 minecraft:red_nether_bricks
setblock 285 185 222 minecraft:polished_blackstone
fill 286 185 182 286 188 182 minecraft:red_nether_bricks
setblock 286 185 185 minecraft:red_nether_bricks
setblock 286 185 186 minecraft:polished_blackstone
fill 286 185 187 286 188 187 minecraft:red_nether_bricks
fill 286 185 222 286 188 222 minecraft:red_nether_bricks
setblock 287 185 184 minecraft:red_nether_bricks
setblock 287 185 185 minecraft:polished_blackstone
setblock 288 185 184 minecraft:polished_blackstone
fill 288 185 185 288 188 185 minecraft:red_nether_bricks
fill 288 185 221 288 186 221 minecraft:red_nether_bricks
setblock 289 185 183 minecraft:polished_blackstone
fill 289 185 184 289 188 184 minecraft:red_nether_bricks
setblock 290 185 182 minecraft:polished_blackstone
fill 290 185 183 290 188 183 minecraft:red_nether_bricks
setblock 290 185 222 minecraft:polished_blackstone
fill 291 185 182 294 185 182 minecraft:red_nether_bricks
setblock 291 185 185 minecraft:red_nether_bricks
fill 291 185 222 294 185 222 minecraft:red_nether_bricks
setblock 292 185 185 minecraft:polished_blackstone
setblock 293 185 184 minecraft:polished_blackstone
setblock 294 185 183 minecraft:polished_blackstone
fill 294 185 184 294 188 184 minecraft:red_nether_bricks
setblock 295 185 182 minecraft:polished_blackstone
fill 295 185 183 295 188 183 minecraft:red_nether_bricks
setblock 295 185 222 minecraft:polished_blackstone
fill 296 185 182 296 188 182 minecraft:red_nether_bricks
fill 296 185 222 296 188 222 minecraft:red_nether_bricks
setblock 299 185 183 minecraft:polished_blackstone
setblock 300 185 182 minecraft:polished_blackstone
fill 300 185 183 300 188 183 minecraft:red_nether_bricks
setblock 300 185 222 minecraft:polished_blackstone
fill 301 185 182 301 188 182 minecraft:red_nether_bricks
fill 301 185 184 302 185 184 minecraft:red_nether_bricks
fill 301 185 222 301 188 222 minecraft:red_nether_bricks
fill 302 185 221 302 188 221 minecraft:red_nether_bricks
setblock 303 185 184 minecraft:polished_blackstone
setblock 304 185 183 minecraft:polished_blackstone
fill 304 185 184 307 185 184 minecraft:red_nether_bricks
setblock 305 185 182 minecraft:polished_blackstone
fill 305 185 183 305 188 183 minecraft:red_nether_bricks
fill 305 185 220 305 186 220 minecraft:red_nether_bricks
setblock 305 185 222 minecraft:polished_blackstone
fill 306 185 182 306 188 182 minecraft:red_nether_bricks
setblock 306 185 221 minecraft:polished_blackstone
fill 306 185 222 306 188 222 minecraft:red_nether_bricks
setblock 307 185 220 minecraft:polished_blackstone
fill 307 185 221 307 188 221 minecraft:red_nether_bricks
setblock 308 185 184 minecraft:polished_blackstone
fill 308 185 220 308 188 220 minecraft:red_nether_bricks
setblock 309 185 183 minecraft:polished_blackstone
fill 309 185 184 309 188 184 minecraft:red_nether_bricks
setblock 310 185 182 minecraft:polished_blackstone
fill 310 185 183 310 188 183 minecraft:red_nether_bricks
fill 310 185 185 312 185 185 minecraft:polished_blackstone
setblock 310 185 222 minecraft:polished_blackstone
fill 311 185 182 311 188 182 minecraft:red_nether_bricks
setblock 311 185 221 minecraft:polished_blackstone
fill 311 185 222 311 188 222 minecraft:red_nether_bricks
setblock 312 185 184 minecraft:polished_blackstone
fill 312 185 221 312 187 221 minecraft:red_nether_bricks
setblock 315 185 182 minecraft:polished_blackstone
setblock 315 185 222 minecraft:polished_blackstone
fill 316 185 182 316 186 182 minecraft:red_nether_bricks
fill 316 185 222 316 186 222 minecraft:red_nether_bricks
fill 317 185 203 317 185 205 minecraft:polished_blackstone
fill 318 185 202 320 185 202 minecraft:polished_blackstone
fill 318 185 206 321 185 206 minecraft:polished_blackstone
fill 321 185 182 323 186 182 minecraft:red_nether_bricks
setblock 321 185 203 minecraft:polished_blackstone
fill 321 185 204 321 185 205 minecraft:red_nether_bricks
fill 321 185 207 321 188 207 minecraft:red_nether_bricks
setblock 322 185 200 minecraft:polished_blackstone
fill 322 185 201 322 188 201 minecraft:red_nether_bricks
setblock 322 185 204 minecraft:red_nether_bricks
setblock 322 185 205 minecraft:polished_blackstone
fill 322 185 206 322 188 206 minecraft:red_nether_bricks
setblock 322 185 209 minecraft:red_nether_bricks
setblock 322 185 210 minecraft:polished_blackstone
fill 322 185 211 322 188 211 minecraft:red_nether_bricks
setblock 323 185 183 minecraft:red_nether_bricks
setblock 323 185 184 minecraft:polished_blackstone
fill 323 185 185 323 188 185 minecraft:red_nether_bricks
fill 323 185 187 323 185 188 minecraft:red_nether_bricks
setblock 323 185 189 minecraft:polished_blackstone
fill 323 185 190 323 188 190 minecraft:red_nether_bricks
fill 323 185 195 323 187 196 minecraft:red_nether_bricks
setblock 323 185 199 minecraft:polished_blackstone
fill 323 185 200 323 188 200 minecraft:red_nether_bricks
setblock 323 185 204 minecraft:polished_blackstone
fill 323 185 205 323 188 205 minecraft:red_nether_bricks
setblock 323 185 209 minecraft:polished_blackstone
fill 323 185 210 323 188 210 minecraft:red_nether_bricks
setblock 323 185 214 minecraft:polished_blackstone
fill 282 186 181 282 187 184 minecraft:red_nether_bricks
setblock 282 186 185 minecraft:nether_bricks
setblock 282 186 192 minecraft:nether_bricks
fill 282 186 194 282 186 196 minecraft:red_nether_bricks
setblock 282 186 197 minecraft:nether_bricks
fill 282 186 198 282 187 203 minecraft:red_nether_bricks
setblock 282 186 207 minecraft:nether_bricks
fill 282 186 209 282 189 211 minecraft:red_nether_bricks
fill 282 186 212 282 186 213 minecraft:nether_bricks
setblock 283 186 183 minecraft:polished_blackstone
fill 283 186 184 283 189 184 minecraft:red_nether_bricks
setblock 283 186 187 minecraft:red_nether_bricks
setblock 283 186 188 minecraft:polished_blackstone
fill 283 186 189 283 186 192 minecraft:red_nether_bricks
setblock 283 186 193 minecraft:polished_blackstone
fill 283 186 194 283 189 194 minecraft:red_nether_bricks
setblock 283 186 197 minecraft:red_nether_bricks
setblock 283 186 198 minecraft:polished_blackstone
fill 283 186 199 283 189 199 minecraft:red_nether_bricks
setblock 283 186 203 minecraft:polished_blackstone
fill 283 186 204 283 189 204 minecraft:red_nether_bricks
setblock 283 186 207 minecraft:red_nether_bricks
setblock 283 186 208 minecraft:polished_blackstone
fill 283 186 209 283 189 209 minecraft:red_nether_bricks
setblock 283 186 212 minecraft:red_nether_bricks
setblock 283 186 213 minecraft:polished_blackstone
setblock 283 186 222 minecraft:red_nether_bricks
setblock 284 186 182 minecraft:polished_blackstone
fill 284 186 183 284 189 183 minecraft:red_nether_bricks
setblock 284 186 187 minecraft:polished_blackstone
fill 284 186 188 284 189 188 minecraft:red_nether_bricks
setblock 284 186 191 minecraft:red_nether_bricks
setblock 284 186 192 minecraft:polished_blackstone
fill 284 186 193 285 188 193 minecraft:red_nether_bricks
setblock 284 186 197 minecraft:polished_blackstone
fill 284 186 198 285 187 198 minecraft:red_nether_bricks
setblock 284 186 202 minecraft:polished_blackstone
fill 284 186 203 284 189 203 minecraft:red_nether_bricks
setblock 284 186 207 minecraft:polished_blackstone
fill 284 186 208 284 189 208 minecraft:red_nether_bricks
setblock 284 186 211 minecraft:red_nether_bricks
setblock 284 186 222 minecraft:polished_blackstone
fill 285 186 182 285 189 182 minecraft:red_nether_bricks
setblock 285 186 186 minecraft:polished_blackstone
fill 285 186 187 285 189 187 minecraft:red_nether_bricks
setblock 285 186 191 minecraft:polished_blackstone
fill 285 186 192 285 189 192 minecraft:red_nether_bricks
setblock 285 186 201 minecraft:polished_blackstone
fill 285 186 202 285 189 202 minecraft:red_nether_bricks
setblock 285 186 206 minecraft:polished_blackstone
fill 285 186 207 285 189 207 minecraft:red_nether_bricks
fill 285 186 209 285 187 209 minecraft:red_nether_bricks
fill 285 186 222 285 189 222 minecraft:red_nether_bricks
setblock 286 186 185 minecraft:polished_blackstone
fill 286 186 186 286 189 186 minecraft:red_nether_bricks
fill 286 186 188 286 186 189 minecraft:red_nether_bricks
setblock 286 186 204 minecraft:red_nether_bricks
setblock 286 186 205 minecraft:polished_blackstone
fill 287 186 181 290 186 181 minecraft:red_nether_bricks
setblock 287 186 184 minecraft:polished_blackstone
fill 287 186 185 287 189 185 minecraft:red_nether_bricks
setblock 288 186 183 minecraft:polished_blackstone
fill 288 186 184 288 189 184 minecraft:red_nether_bricks
fill 288 186 186 288 187 186 minecraft:red_nether_bricks
setblock 289 186 182 minecraft:polished_blackstone
fill 289 186 183 289 189 183 minecraft:red_nether_bricks
setblock 289 186 222 minecraft:polished_blackstone
fill 290 186 182 293 186 182 minecraft:red_nether_bricks
fill 290 186 222 293 186 222 minecraft:red_nether_bricks
setblock 291 186 181 minecraft:nether_bricks
setblock 291 186 185 minecraft:polished_blackstone
fill 292 186 181 296 186 181 minecraft:red_nether_bricks
setblock 292 186 184 minecraft:polished_blackstone
fill 292 186 185 293 186 185 minecraft:red_nether_bricks
setblock 293 186 183 minecraft:polished_blackstone
fill 293 186 184 293 189 184 minecraft:red_nether_bricks
setblock 294 186 182 minecraft:polished_blackstone
fill 294 186 183 294 189 183 minecraft:red_nether_bricks
setblock 294 186 222 minecraft:polished_blackstone
fill 295 186 182 295 189 182 minecraft:red_nether_bricks
fill 295 186 222 295 188 222 minecraft:red_nether_bricks
fill 296 186 223 304 186 223 minecraft:red_nether_bricks
setblock 297 186 184 minecraft:polished_blackstone
fill 298 186 181 298 187 181 minecraft:nether_bricks
setblock 298 186 183 minecraft:polished_blackstone
fill 298 186 184 301 186 184 minecraft:red_nether_bricks
fill 299 186 181 300 189 181 minecraft:red_nether_bricks
setblock 299 186 182 minecraft:polished_blackstone
fill 299 186 183 299 189 183 minecraft:red_nether_bricks
setblock 299 186 222 minecraft:polished_blackstone
fill 300 186 182 300 189 182 minecraft:red_nether_bricks
fill 300 186 222 300 189 222 minecraft:red_nether_bricks
fill 301 186 221 301 189 221 minecraft:red_nether_bricks
setblock 302 186 184 minecraft:polished_blackstone
setblock 303 186 183 minecraft:polished_blackstone
fill 303 186 184 306 186 184 minecraft:red_nether_bricks
setblock 304 186 182 minecraft:polished_blackstone
fill 304 186 183 304 189 183 minecraft:red_nether_bricks
setblock 304 186 222 minecraft:polished_blackstone
fill 305 186 182 305 189 182 minecraft:red_nether_bricks
setblock 305 186 221 minecraft:polished_blackstone
fill 305 186 222 305 189 222 minecraft:red_nether_bricks
setblock 305 186 223 minecraft:nether_bricks
setblock 306 186 220 minecraft:polished_blackstone
fill 306 186 221 306 189 221 minecraft:red_nether_bricks
fill 306 186 223 307 189 223 minecraft:red_nether_bricks
setblock 307 186 184 minecraft:polished_blackstone
fill 307 186 220 307 189 220 minecraft:red_nether_bricks
setblock 308 186 183 minecraft:polished_blackstone
fill 308 186 184 308 189 184 minecraft:red_nether_bricks
setblock 309 186 182 minecraft:polished_blackstone
fill 309 186 183 309 189 183 minecraft:red_nether_bricks
setblock 309 186 222 minecraft:polished_blackstone
fill 309 186 223 314 187 223 minecraft:red_nether_bricks
fill 310 186 182 310 189 182 minecraft:red_nether_bricks
setblock 310 186 221 minecraft:polished_blackstone
fill 310 186 222 310 189 222 minecraft:red_nether_bricks
fill 311 186 181 311 187 181 minecraft:nether_bricks
fill 311 186 221 311 188 221 minecraft:red_nether_bricks
fill 312 186 181 315 186 181 minecraft:red_nether_bricks
setblock 313 186 183 minecraft:polished_blackstone
setblock 314 186 182 minecraft:polished_blackstone
setblock 314 186 222 minecraft:polished_blackstone
fill 315 186 182 315 187 182 minecraft:red_nether_bricks
fill 315 186 222 315 187 222 minecraft:red_nether_bricks
fill 315 186 223 317 186 223 minecraft:nether_bricks
fill 320 186 223 320 187 223 minecraft:nether_bricks
fill 321 186 203 321 186 204 minecraft:red_nether_bricks
setblock 321 186 205 minecraft:polished_blackstone
fill 321 186 206 321 189 206 minecraft:red_nether_bricks
fill 321 186 208 321 186 209 minecraft:red_nether_bricks
fill 321 186 223 322 186 223 minecraft:red_nether_bricks
setblock 322 186 199 minecraft:polished_blackstone
fill 322 186 200 322 189 200 minecraft:red_nether_bricks
setblock 322 186 204 minecraft:polished_blackstone
fill 322 186 205 322 189 205 minecraft:red_nether_bricks
setblock 322 186 209 minecraft:polished_blackstone
fill 322 186 210 322 189 210 minecraft:red_nether_bricks
fill 322 186 212 323 186 212 minecraft:red_nether_bricks
setblock 323 186 183 minecraft:polished_blackstone
fill 323 186 184 323 189 184 minecraft:red_nether_bricks
setblock 323 186 187 minecraft:red_nether_bricks
setblock 323 186 188 minecraft:polished_blackstone
fill 323 186 189 324 189 189 minecraft:red_nether_bricks
fill 323 186 191 324 186 192 minecraft:red_nether_bricks
setblock 323 186 193 minecraft:polished_blackstone
fill 323 186 194 323 189 194 minecraft:red_nether_bricks
setblock 323 186 198 minecraft:polished_blackstone
fill 323 186 199 323 189 199 minecraft:red_nether_bricks
setblock 323 186 203 minecraft:polished_blackstone
fill 323 186 204 323 189 204 minecraft:red_nether_bricks
setblock 323 186 208 minecraft:polished_blackstone
fill 323 186 209 323 189 209 minecraft:red_nether_bricks
fill 323 186 211 323 187 211 minecraft:red_nether_bricks
setblock 323 186 213 minecraft:polished_blackstone
fill 323 186 214 323 188 215 minecraft:red_nether_bricks
fill 323 186 221 323 187 221 minecraft:red_nether_bricks
fill 323 186 223 324 186 223 minecraft:nether_bricks
setblock 324 186 190 minecraft:nether_bricks
setblock 324 186 193 minecraft:nether_bricks
fill 324 186 203 324 189 203 minecraft:red_nether_bricks
setblock 324 186 204 minecraft:nether_bricks
fill 324 186 216 324 186 217 minecraft:nether_bricks
setblock 324 186 220 minecraft:nether_bricks
fill 282 187 185 282 189 185 minecraft:red_nether_bricks
fill 282 187 192 282 189 192 minecraft:red_nether_bricks
setblock 282 187 194 minecraft:nether_bricks
setblock 282 187 195 minecraft:red_nether_bricks
setblock 282 187 196 minecraft:nether_bricks
fill 282 187 197 282 189 197 minecraft:red_nether_bricks
fill 282 187 207 282 189 207 minecraft:red_nether_bricks
fill 282 187 212 282 187 213 minecraft:red_nether_bricks
setblock 283 187 182 minecraft:polished_blackstone
fill 283 187 183 283 190 183 minecraft:red_nether_bricks
setblock 283 187 187 minecraft:polished_blackstone
fill 283 187 188 283 187 191 minecraft:red_nether_bricks
setblock 283 187 192 minecraft:polished_blackstone
fill 283 187 193 283 190 193 minecraft:red_nether_bricks
setblock 283 187 196 minecraft:red_nether_bricks
setblock 283 187 197 minecraft:polished_blackstone
fill 283 187 198 283 190 198 minecraft:red_nether_bricks
setblock 283 187 202 minecraft:polished_blackstone
fill 283 187 203 283 190 203 minecraft:red_nether_bricks
setblock 283 187 207 minecraft:polished_blackstone
fill 283 187 208 283 190 208 minecraft:red_nether_bricks
setblock 283 187 212 minecraft:polished_blackstone
fill 283 187 213 283 189 214 minecraft:red_nether_bricks
setblock 283 187 222 minecraft:polished_blackstone
fill 284 187 182 284 190 182 minecraft:red_nether_bricks
setblock 284 187 185 minecraft:red_nether_bricks
setblock 284 187 186 minecraft:polished_blackstone
fill 284 187 187 284 190 187 minecraft:red_nether_bricks
setblock 284 187 191 minecraft:polished_blackstone
fill 284 187 192 284 190 192 minecraft:red_nether_bricks
setblock 284 187 196 minecraft:polished_blackstone
fill 284 187 197 284 190 197 minecraft:red_nether_bricks
setblock 284 187 201 minecraft:polished_blackstone
fill 284 187 202 284 190 202 minecraft:red_nether_bricks
setblock 284 187 206 minecraft:polished_blackstone
fill 284 187 207 284 190 207 minecraft:red_nether_bricks
setblock 284 187 211 minecraft:polished_blackstone
fill 284 187 212 284 190 212 minecraft:red_nether_bricks
fill 284 187 222 284 190 222 minecraft:red_nether_bricks
setblock 285 187 185 minecraft:polished_blackstone
fill 285 187 186 285 190 186 minecraft:red_nether_bricks
setblock 285 187 190 minecraft:polished_blackstone
fill 285 187 191 286 189 191 minecraft:red_nether_bricks
setblock 285 187 194 minecraft:red_nether_bricks
setblock 285 187 195 minecraft:polished_blackstone
setblock 285 187 200 minecraft:polished_blackstone
fill 285 187 201 285 188 201 minecraft:red_nether_bricks
setblock 285 187 205 minecraft:polished_blackstone
fill 285 187 206 285 190 206 minecraft:red_nether_bricks
setblock 286 187 184 minecraft:polished_blackstone
fill 286 187 185 286 190 185 minecraft:red_nether_bricks
setblock 286 187 188 minecraft:red_nether_bricks
setblock 286 187 189 minecraft:polished_blackstone
fill 286 187 190 286 190 190 minecraft:red_nether_bricks
fill 287 187 181 287 189 181 minecraft:red_nether_bricks
setblock 287 187 183 minecraft:polished_blackstone
fill 287 187 184 287 190 184 minecraft:red_nether_bricks
fill 287 187 186 287 187 187 minecraft:red_nether_bricks
setblock 288 187 181 minecraft:nether_bricks
setblock 288 187 182 minecraft:polished_blackstone
fill 288 187 183 288 190 183 minecraft:red_nether_bricks
fill 288 187 192 289 188 193 minecraft:magma_block
setblock 288 187 222 minecraft:polished_blackstone
fill 289 187 181 291 188 182 minecraft:red_nether_bricks
setblock 289 187 186 minecraft:polished_blackstone
fill 289 187 222 292 187 222 minecraft:red_nether_bricks
setblock 290 187 185 minecraft:polished_blackstone
setblock 291 187 184 minecraft:polished_blackstone
fill 291 187 185 292 188 185 minecraft:red_nether_bricks
setblock 292 187 181 minecraft:nether_bricks
setblock 292 187 182 minecraft:red_nether_bricks
setblock 292 187 183 minecraft:polished_blackstone
fill 292 187 184 292 190 184 minecraft:red_nether_bricks
fill 293 187 181 296 187 181 minecraft:red_nether_bricks
setblock 293 187 182 minecraft:polished_blackstone
fill 293 187 183 293 190 183 minecraft:red_nether_bricks
setblock 293 187 222 minecraft:polished_blackstone
fill 294 187 182 294 190 182 minecraft:red_nether_bricks
fill 294 187 222 294 188 222 minecraft:red_nether_bricks
setblock 295 187 184 minecraft:red_nether_bricks
setblock 296 187 184 minecraft:polished_blackstone
fill 296 187 223 296 189 223 minecraft:red_nether_bricks
setblock 297 187 183 minecraft:polished_blackstone
fill 297 187 184 300 187 184 minecraft:red_nether_bricks
setblock 297 187 223 minecraft:nether_bricks
setblock 298 187 182 minecraft:polished_blackstone
fill 298 187 183 298 190 183 minecraft:red_nether_bricks
setblock 298 187 222 minecraft:polished_blackstone
fill 298 187 223 305 187 223 minecraft:red_nether_bricks
fill 299 187 182 299 190 182 minecraft:red_nether_bricks
fill 299 187 222 299 190 222 minecraft:red_nether_bricks
setblock 301 187 184 minecraft:polished_blackstone
setblock 302 187 183 minecraft:polished_blackstone
fill 302 187 184 305 187 184 minecraft:red_nether_bricks
fill 303 187 181 303 189 181 minecraft:red_nether_bricks
setblock 303 187 182 minecraft:polished_blackstone
fill 303 187 183 303 190 183 minecraft:red_nether_bricks
setblock 303 187 222 minecraft:polished_blackstone
setblock 304 187 181 minecraft:nether_bricks
fill 304 187 182 304 190 182 minecraft:red_nether_bricks
setblock 304 187 221 minecraft:polished_blackstone
fill 304 187 222 304 190 222 minecraft:red_nether_bricks
fill 305 187 181 308 189 181 minecraft:red_nether_bricks
setblock 305 187 185 minecraft:polished_blackstone
setblock 305 187 220 minecraft:polished_blackstone
fill 305 187 221 305 190 221 minecraft:red_nether_bricks
setblock 306 187 184 minecraft:polished_blackstone
fill 306 187 185 307 187 185 minecraft:red_nether_bricks
fill 306 187 220 306 189 220 minecraft:red_nether_bricks
setblock 307 187 183 minecraft:polished_blackstone
fill 307 187 184 307 190 184 minecraft:red_nether_bricks
setblock 308 187 182 minecraft:polished_blackstone
fill 308 187 183 308 190 183 minecraft:red_nether_bricks
setblock 308 187 222 minecraft:polished_blackstone
fill 309 187 182 309 190 182 minecraft:red_nether_bricks
setblock 309 187 221 minecraft:polished_blackstone
fill 309 187 222 309 190 222 minecraft:red_nether_bricks
setblock 310 187 184 minecraft:red_nether_bricks
fill 310 187 221 310 189 221 minecraft:red_nether_bricks
fill 311 187 184 311 211 184 minecraft:gilded_blackstone
fill 312 187 181 314 189 181 minecraft:red_nether_bricks
setblock 312 187 183 minecraft:polished_blackstone
setblock 313 187 182 minecraft:polished_blackstone
setblock 313 187 183 minecraft:red_nether_bricks
setblock 313 187 222 minecraft:polished_blackstone
fill 314 187 182 314 188 182 minecraft:red_nether_bricks
fill 314 187 222 314 188 222 minecraft:red_nether_bricks
setblock 315 187 181 minecraft:nether_bricks
fill 315 187 223 317 189 223 minecraft:red_nether_bricks
fill 318 187 181 319 187 181 minecraft:red_nether_bricks
setblock 320 187 181 minecraft:nether_bricks
fill 320 187 182 322 187 182 minecraft:red_nether_bricks
setblock 321 187 203 minecraft:red_nether_bricks
schedule function dropper:buildpart/42_8 1t
