setblock 285 249 231 minecraft:light[level=12]
fill 285 249 238 285 249 239 minecraft:light[level=12]
setblock 285 249 245 minecraft:light[level=12]
setblock 285 249 247 minecraft:light[level=12]
fill 285 249 251 286 249 251 minecraft:polished_blackstone
fill 285 249 252 286 249 253 minecraft:magma_block
fill 285 249 254 286 249 254 minecraft:polished_blackstone
setblock 285 249 255 minecraft:light[level=12]
setblock 285 249 259 minecraft:light[level=12]
setblock 285 249 263 minecraft:light[level=12]
setblock 285 249 266 minecraft:light[level=12]
fill 287 249 252 288 249 253 minecraft:polished_blackstone
fill 292 249 231 293 249 231 minecraft:light[level=12]
setblock 292 249 238 minecraft:light[level=12]
setblock 292 249 245 minecraft:light[level=12]
setblock 292 249 252 minecraft:light[level=12]
setblock 292 249 259 minecraft:light[level=12]
setblock 292 249 266 minecraft:light[level=12]
setblock 293 249 239 minecraft:light[level=12]
setblock 293 249 247 minecraft:light[level=12]
setblock 293 249 255 minecraft:light[level=12]
setblock 293 249 263 minecraft:light[level=12]
fill 294 249 236 295 249 236 minecraft:basalt
fill 295 249 233 295 250 235 minecraft:basalt
fill 295 249 237 296 249 237 minecraft:basalt
fill 296 249 234 296 249 236 minecraft:magma_block
fill 297 249 234 297 250 235 minecraft:basalt
setblock 298 249 228 minecraft:shroomlight
setblock 299 249 231 minecraft:light[level=12]
setblock 299 249 238 minecraft:light[level=12]
setblock 299 249 245 minecraft:light[level=12]
setblock 299 249 252 minecraft:light[level=12]
setblock 299 249 259 minecraft:light[level=12]
setblock 299 249 266 minecraft:light[level=12]
setblock 301 249 231 minecraft:light[level=12]
setblock 301 249 239 minecraft:light[level=12]
setblock 301 249 255 minecraft:light[level=12]
setblock 301 249 263 minecraft:light[level=12]
setblock 306 249 231 minecraft:light[level=12]
setblock 306 249 238 minecraft:light[level=12]
setblock 306 249 245 minecraft:light[level=12]
setblock 306 249 252 minecraft:light[level=12]
setblock 306 249 259 minecraft:light[level=12]
setblock 306 249 266 minecraft:light[level=12]
setblock 309 249 231 minecraft:light[level=12]
setblock 309 249 239 minecraft:light[level=12]
setblock 309 249 247 minecraft:light[level=12]
setblock 309 249 255 minecraft:light[level=12]
setblock 309 249 263 minecraft:light[level=12]
setblock 313 249 231 minecraft:light[level=12]
setblock 313 249 238 minecraft:light[level=12]
setblock 313 249 245 minecraft:light[level=12]
setblock 313 249 252 minecraft:light[level=12]
setblock 313 249 259 minecraft:light[level=12]
setblock 313 249 266 minecraft:light[level=12]
fill 314 249 270 314 283 270 minecraft:blackstone
setblock 317 249 231 minecraft:light[level=12]
setblock 317 249 239 minecraft:light[level=12]
setblock 317 249 247 minecraft:light[level=12]
setblock 317 249 255 minecraft:light[level=12]
setblock 317 249 263 minecraft:light[level=12]
setblock 320 249 231 minecraft:light[level=12]
setblock 320 249 238 minecraft:light[level=12]
setblock 320 249 245 minecraft:light[level=12]
setblock 320 249 252 minecraft:light[level=12]
setblock 320 249 259 minecraft:light[level=12]
setblock 320 249 266 minecraft:light[level=12]
fill 282 250 252 282 251 253 minecraft:polished_blackstone
fill 283 250 251 284 250 251 minecraft:polished_blackstone
fill 283 250 252 284 250 253 minecraft:magma_block
fill 283 250 254 284 250 254 minecraft:polished_blackstone
fill 285 250 252 286 250 253 minecraft:polished_blackstone
fill 292 250 228 294 273 228 minecraft:blackstone
setblock 295 250 228 minecraft:shroomlight
fill 295 250 230 295 251 232 minecraft:basalt
fill 295 250 236 296 250 236 minecraft:basalt
fill 296 250 228 298 250 228 minecraft:blackstone
fill 296 250 229 297 250 229 minecraft:basalt
fill 296 250 231 296 250 234 minecraft:magma_block
setblock 296 250 235 minecraft:basalt
fill 297 250 231 298 255 233 minecraft:basalt
fill 283 251 252 284 251 253 minecraft:polished_blackstone
fill 295 251 228 295 272 228 minecraft:blackstone
fill 295 251 229 295 252 229 minecraft:basalt
fill 295 251 233 296 251 233 minecraft:basalt
fill 296 251 228 297 252 228 minecraft:basalt
fill 296 251 229 296 251 231 minecraft:magma_block
fill 296 251 232 296 255 232 minecraft:basalt
setblock 296 251 234 minecraft:basalt
fill 297 251 229 297 252 230 minecraft:basalt
fill 298 251 228 298 283 228 minecraft:blackstone
setblock 298 251 229 minecraft:basalt
fill 302 251 233 302 252 234 minecraft:blackstone
fill 282 252 252 282 283 253 minecraft:blackstone
fill 283 252 228 283 283 228 minecraft:blackstone
setblock 284 252 228 minecraft:crying_obsidian
fill 285 252 228 285 283 228 minecraft:blackstone
fill 293 252 231 294 252 233 minecraft:orange_concrete
fill 294 252 229 294 252 230 minecraft:orange_concrete
fill 294 252 234 299 252 234 minecraft:orange_concrete
fill 295 252 230 295 254 230 minecraft:orange_concrete
fill 295 252 231 295 255 232 minecraft:basalt
fill 295 252 233 295 254 233 minecraft:orange_concrete
fill 295 252 235 298 252 235 minecraft:orange_concrete
fill 296 252 229 296 252 231 minecraft:basalt
fill 296 252 233 296 255 233 minecraft:basalt
fill 298 252 229 299 252 230 minecraft:orange_concrete
fill 299 252 231 300 252 233 minecraft:orange_concrete
setblock 300 252 230 minecraft:orange_concrete
fill 305 252 260 305 253 261 minecraft:blackstone
fill 313 252 260 315 252 260 minecraft:orange_concrete
fill 314 252 257 315 252 259 minecraft:orange_concrete
fill 314 252 261 315 252 262 minecraft:orange_concrete
fill 315 252 263 320 252 263 minecraft:orange_concrete
fill 316 252 256 319 252 257 minecraft:orange_concrete
fill 316 252 262 316 254 262 minecraft:orange_concrete
fill 317 252 264 318 252 264 minecraft:orange_concrete
fill 318 252 262 321 252 262 minecraft:orange_concrete
fill 319 252 258 321 252 258 minecraft:orange_concrete
setblock 320 252 257 minecraft:orange_concrete
fill 320 252 259 321 252 261 minecraft:orange_concrete
fill 284 253 228 284 274 228 minecraft:blackstone
fill 288 253 246 288 260 246 minecraft:dripstone_block
fill 290 253 242 290 260 242 minecraft:dripstone_block
fill 294 253 230 294 253 233 minecraft:orange_concrete
fill 294 253 254 294 260 254 minecraft:dripstone_block
fill 295 253 229 298 253 229 minecraft:orange_concrete
fill 295 253 234 299 253 234 minecraft:orange_concrete
fill 296 253 228 297 283 228 minecraft:blackstone
fill 296 253 230 296 255 231 minecraft:basalt
fill 296 253 241 296 260 241 minecraft:dripstone_block
fill 297 253 230 297 255 230 minecraft:basalt
setblock 297 253 235 minecraft:orange_concrete
fill 298 253 230 299 253 230 minecraft:orange_concrete
fill 299 253 231 299 254 233 minecraft:orange_concrete
fill 299 253 270 299 254 270 minecraft:magma_block
setblock 300 253 232 minecraft:orange_concrete
fill 304 253 240 304 260 240 minecraft:dripstone_block
fill 306 253 264 306 260 264 minecraft:dripstone_block
fill 309 253 262 309 260 262 minecraft:dripstone_block
fill 314 253 259 315 253 261 minecraft:orange_concrete
fill 315 253 239 315 260 239 minecraft:dripstone_block
fill 315 253 257 315 253 258 minecraft:orange_concrete
setblock 315 253 262 minecraft:orange_concrete
fill 316 253 257 319 253 257 minecraft:orange_concrete
fill 316 253 263 318 253 263 minecraft:orange_concrete
fill 318 253 262 320 253 262 minecraft:orange_concrete
fill 319 253 258 320 253 258 minecraft:orange_concrete
fill 320 253 259 320 254 261 minecraft:orange_concrete
fill 292 254 258 292 260 258 minecraft:dripstone_block
fill 296 254 234 298 254 234 minecraft:orange_concrete
setblock 298 254 230 minecraft:orange_concrete
fill 307 254 262 307 260 262 minecraft:dripstone_block
fill 315 254 251 315 260 251 minecraft:dripstone_block
fill 315 254 258 315 254 261 minecraft:orange_concrete
fill 317 254 251 317 260 251 minecraft:dripstone_block
fill 317 254 257 318 254 257 minecraft:orange_concrete
fill 318 254 262 319 254 262 minecraft:orange_concrete
setblock 319 254 258 minecraft:orange_concrete
setblock 282 255 262 minecraft:magma_block
fill 285 255 231 285 256 231 minecraft:light[level=12]
setblock 285 255 238 minecraft:light[level=12]
setblock 285 255 245 minecraft:light[level=12]
setblock 285 255 252 minecraft:light[level=12]
setblock 285 255 259 minecraft:light[level=12]
setblock 285 255 266 minecraft:light[level=12]
fill 288 255 248 288 260 248 minecraft:dripstone_block
fill 290 255 250 290 260 250 minecraft:dripstone_block
fill 291 255 240 291 260 240 minecraft:dripstone_block
setblock 292 255 231 minecraft:light[level=12]
setblock 292 255 238 minecraft:light[level=12]
setblock 292 255 245 minecraft:light[level=12]
setblock 292 255 252 minecraft:light[level=12]
setblock 292 255 259 minecraft:light[level=12]
setblock 292 255 266 minecraft:light[level=12]
setblock 299 255 231 minecraft:light[level=12]
setblock 299 255 238 minecraft:light[level=12]
setblock 299 255 245 minecraft:light[level=12]
setblock 299 255 252 minecraft:light[level=12]
setblock 299 255 259 minecraft:light[level=12]
setblock 299 255 266 minecraft:light[level=12]
fill 299 255 270 299 258 270 minecraft:blackstone
setblock 306 255 231 minecraft:light[level=12]
setblock 306 255 238 minecraft:light[level=12]
setblock 306 255 245 minecraft:light[level=12]
setblock 306 255 252 minecraft:light[level=12]
setblock 306 255 259 minecraft:light[level=12]
setblock 306 255 266 minecraft:light[level=12]
setblock 313 255 231 minecraft:light[level=12]
setblock 313 255 238 minecraft:light[level=12]
setblock 313 255 245 minecraft:light[level=12]
setblock 313 255 252 minecraft:light[level=12]
setblock 313 255 259 minecraft:light[level=12]
setblock 313 255 266 minecraft:light[level=12]
fill 316 255 241 316 260 241 minecraft:dripstone_block
setblock 320 255 231 minecraft:light[level=12]
setblock 320 255 238 minecraft:light[level=12]
setblock 320 255 245 minecraft:light[level=12]
setblock 320 255 252 minecraft:light[level=12]
setblock 320 255 259 minecraft:light[level=12]
setblock 320 255 266 minecraft:light[level=12]
fill 324 255 232 324 283 233 minecraft:blackstone
setblock 324 255 234 minecraft:crying_obsidian
fill 282 256 262 282 283 262 minecraft:blackstone
setblock 285 256 239 minecraft:light[level=12]
setblock 285 256 247 minecraft:light[level=12]
setblock 285 256 255 minecraft:light[level=12]
setblock 285 256 263 minecraft:light[level=12]
fill 287 256 251 287 260 251 minecraft:dripstone_block
fill 290 256 259 291 260 259 minecraft:dripstone_block
setblock 293 256 231 minecraft:light[level=12]
setblock 293 256 239 minecraft:light[level=12]
setblock 293 256 247 minecraft:light[level=12]
setblock 293 256 255 minecraft:light[level=12]
setblock 293 256 263 minecraft:light[level=12]
setblock 301 256 231 minecraft:light[level=12]
setblock 301 256 239 minecraft:light[level=12]
setblock 301 256 255 minecraft:light[level=12]
setblock 301 256 263 minecraft:light[level=12]
fill 303 256 240 303 260 240 minecraft:dripstone_block
fill 305 256 264 305 260 264 minecraft:dripstone_block
setblock 309 256 231 minecraft:light[level=12]
setblock 309 256 239 minecraft:light[level=12]
setblock 309 256 247 minecraft:light[level=12]
setblock 309 256 255 minecraft:light[level=12]
setblock 309 256 263 minecraft:light[level=12]
fill 310 256 255 310 260 255 minecraft:dripstone_block
fill 310 256 262 310 260 262 minecraft:dripstone_block
setblock 317 256 231 minecraft:light[level=12]
setblock 317 256 239 minecraft:light[level=12]
setblock 317 256 247 minecraft:light[level=12]
setblock 317 256 255 minecraft:light[level=12]
setblock 317 256 263 minecraft:light[level=12]
fill 324 256 234 324 283 234 minecraft:blackstone
setblock 324 256 242 minecraft:crying_obsidian
fill 289 257 242 289 260 242 minecraft:dripstone_block
fill 290 257 243 290 260 243 minecraft:dripstone_block
fill 290 257 258 291 260 258 minecraft:dripstone_block
fill 291 257 250 291 260 250 minecraft:dripstone_block
fill 292 257 259 292 260 259 minecraft:dripstone_block
fill 295 257 241 295 260 241 minecraft:dripstone_block
fill 296 257 242 296 260 242 minecraft:dripstone_block
fill 305 257 235 305 260 235 minecraft:dripstone_block
fill 306 257 262 306 260 262 minecraft:dripstone_block
fill 307 257 239 307 260 239 minecraft:dripstone_block
fill 309 257 240 309 260 240 minecraft:dripstone_block
fill 314 257 239 314 260 239 minecraft:dripstone_block
fill 315 257 238 315 260 238 minecraft:dripstone_block
fill 315 257 250 315 260 250 minecraft:dripstone_block
fill 316 257 240 316 260 240 minecraft:dripstone_block
fill 324 257 242 324 283 242 minecraft:blackstone
fill 287 258 246 287 260 246 minecraft:dripstone_block
fill 287 258 248 287 260 248 minecraft:dripstone_block
fill 287 258 250 287 260 250 minecraft:dripstone_block
fill 288 258 247 288 260 247 minecraft:dripstone_block
fill 288 258 249 288 260 249 minecraft:dripstone_block
fill 288 258 251 288 260 251 minecraft:dripstone_block
fill 289 258 246 289 260 246 minecraft:dripstone_block
fill 290 258 240 290 260 240 minecraft:dripstone_block
fill 290 258 248 290 260 248 minecraft:dripstone_block
fill 290 258 251 290 260 251 minecraft:dripstone_block
fill 290 258 255 291 260 255 minecraft:dripstone_block
fill 291 258 239 291 260 239 minecraft:dripstone_block
fill 293 258 254 293 260 254 minecraft:dripstone_block
fill 293 258 258 293 260 258 minecraft:dripstone_block
fill 294 258 253 294 260 253 minecraft:dripstone_block
fill 295 258 242 295 260 242 minecraft:dripstone_block
fill 296 258 234 296 260 234 minecraft:dripstone_block
fill 298 258 238 298 260 239 minecraft:dripstone_block
fill 304 258 241 304 260 241 minecraft:dripstone_block
fill 306 258 263 307 260 263 minecraft:dripstone_block
fill 308 258 240 308 260 240 minecraft:dripstone_block
fill 309 258 239 309 260 239 minecraft:dripstone_block
fill 309 258 255 309 260 255 minecraft:dripstone_block
fill 309 258 263 309 260 263 minecraft:dripstone_block
fill 314 258 251 314 260 251 minecraft:dripstone_block
fill 317 258 241 317 260 241 minecraft:dripstone_block
fill 317 258 252 317 260 252 minecraft:dripstone_block
fill 318 258 251 318 260 251 minecraft:dripstone_block
setblock 284 259 270 minecraft:crying_obsidian
fill 287 259 249 287 260 249 minecraft:dripstone_block
fill 288 259 245 288 260 245 minecraft:dripstone_block
fill 288 259 250 288 260 250 minecraft:dripstone_block
fill 289 259 243 289 260 243 minecraft:dripstone_block
fill 290 259 239 290 260 239 minecraft:dripstone_block
fill 290 259 249 290 260 249 minecraft:dripstone_block
fill 290 259 256 291 260 256 minecraft:dripstone_block
fill 291 259 251 291 260 251 minecraft:dripstone_block
fill 293 259 259 293 260 259 minecraft:dripstone_block
fill 294 259 255 294 260 255 minecraft:dripstone_block
fill 295 259 234 295 260 234 minecraft:dripstone_block
fill 295 259 254 295 260 254 minecraft:dripstone_block
fill 296 259 235 296 260 235 minecraft:dripstone_block
fill 297 259 238 297 260 239 minecraft:dripstone_block
setblock 299 259 270 minecraft:magma_block
fill 303 259 239 304 260 239 minecraft:dripstone_block
fill 303 259 241 303 260 241 minecraft:dripstone_block
fill 305 259 236 305 260 236 minecraft:dripstone_block
fill 305 259 263 305 260 263 minecraft:dripstone_block
setblock 305 259 270 minecraft:magma_block
fill 306 259 235 306 260 235 minecraft:dripstone_block
fill 306 259 265 306 260 265 minecraft:dripstone_block
fill 307 259 240 307 260 240 minecraft:dripstone_block
fill 308 259 239 308 260 239 minecraft:dripstone_block
fill 309 259 261 310 260 261 minecraft:dripstone_block
fill 310 259 254 310 260 254 minecraft:dripstone_block
fill 310 259 256 310 260 256 minecraft:dripstone_block
fill 310 259 263 310 260 263 minecraft:dripstone_block
fill 314 259 238 314 260 238 minecraft:dripstone_block
fill 314 259 250 314 260 250 minecraft:dripstone_block
fill 316 259 239 316 260 239 minecraft:dripstone_block
fill 316 259 251 316 260 251 minecraft:dripstone_block
fill 317 259 240 317 260 240 minecraft:dripstone_block
fill 317 259 250 317 260 250 minecraft:dripstone_block
fill 282 260 265 282 283 266 minecraft:blackstone
setblock 282 260 267 minecraft:crying_obsidian
fill 284 260 270 284 283 270 minecraft:blackstone
setblock 286 260 251 minecraft:dripstone_block
setblock 287 260 247 minecraft:dripstone_block
setblock 287 260 252 minecraft:dripstone_block
fill 289 260 247 289 260 249 minecraft:dripstone_block
fill 290 260 241 291 260 241 minecraft:dripstone_block
setblock 290 260 247 minecraft:dripstone_block
setblock 291 260 242 minecraft:dripstone_block
fill 291 260 248 291 260 249 minecraft:dripstone_block
setblock 292 260 240 minecraft:dripstone_block
setblock 292 260 257 minecraft:dripstone_block
setblock 293 260 253 minecraft:dripstone_block
setblock 295 260 235 minecraft:dripstone_block
setblock 296 260 233 minecraft:dripstone_block
setblock 296 260 240 minecraft:dripstone_block
fill 297 260 234 297 260 235 minecraft:dripstone_block
setblock 297 260 241 minecraft:dripstone_block
fill 299 260 270 299 283 270 minecraft:blackstone
fill 304 260 235 304 260 236 minecraft:dripstone_block
setblock 305 260 234 minecraft:dripstone_block
setblock 305 260 265 minecraft:dripstone_block
fill 305 260 270 305 283 270 minecraft:blackstone
setblock 306 260 236 minecraft:dripstone_block
setblock 306 260 239 minecraft:dripstone_block
fill 307 260 238 308 260 238 minecraft:dripstone_block
setblock 307 260 261 minecraft:dripstone_block
setblock 307 260 264 minecraft:dripstone_block
setblock 308 260 262 minecraft:dripstone_block
setblock 309 260 241 minecraft:dripstone_block
setblock 309 260 254 minecraft:dripstone_block
setblock 309 260 256 minecraft:dripstone_block
setblock 311 260 255 minecraft:dripstone_block
fill 315 260 240 315 260 241 minecraft:dripstone_block
fill 315 260 252 316 260 252 minecraft:dripstone_block
setblock 316 260 242 minecraft:dripstone_block
setblock 316 260 250 minecraft:dripstone_block
setblock 318 260 252 minecraft:dripstone_block
setblock 324 260 248 minecraft:magma_block
setblock 282 261 255 minecraft:magma_block
fill 282 261 267 286 262 267 minecraft:blackstone
fill 283 261 229 293 261 229 minecraft:basalt
fill 283 261 230 287 261 232 minecraft:blackstone
setblock 283 261 233 minecraft:tuff
fill 283 261 234 289 261 234 minecraft:basalt
fill 283 261 235 283 261 238 minecraft:blackstone
fill 283 261 239 285 261 239 minecraft:basalt
fill 283 261 240 286 261 243 minecraft:blackstone
fill 283 261 244 287 261 244 minecraft:basalt
fill 283 261 245 286 261 245 minecraft:blackstone
setblock 283 261 246 minecraft:tuff
fill 283 261 247 283 263 248 minecraft:blackstone
fill 283 261 249 286 261 249 minecraft:basalt
fill 283 261 250 284 261 253 minecraft:blackstone
fill 283 261 254 286 261 254 minecraft:basalt
fill 283 261 255 287 261 258 minecraft:blackstone
setblock 283 261 259 minecraft:tuff
fill 283 261 260 283 261 263 minecraft:blackstone
fill 283 261 264 291 261 264 minecraft:basalt
fill 283 261 265 285 261 266 minecraft:blackstone
fill 283 261 268 293 261 268 minecraft:blackstone
fill 283 261 269 287 261 269 minecraft:basalt
fill 284 261 233 295 261 233 minecraft:blackstone
setblock 284 261 235 minecraft:tuff
fill 284 261 236 284 261 238 minecraft:blackstone
fill 284 261 246 286 262 247 minecraft:blackstone
setblock 284 261 248 minecraft:tuff
fill 284 261 259 289 261 259 minecraft:basalt
fill 284 261 260 289 261 260 minecraft:blackstone
setblock 284 261 261 minecraft:tuff
fill 284 261 262 284 263 263 minecraft:blackstone
fill 285 261 235 290 261 236 minecraft:blackstone
setblock 285 261 237 minecraft:tuff
fill 285 261 238 290 262 238 minecraft:blackstone
fill 285 261 248 286 263 248 minecraft:blackstone
setblock 285 261 250 minecraft:tuff
fill 285 261 251 285 261 253 minecraft:blackstone
fill 285 261 261 290 261 262 minecraft:blackstone
setblock 285 261 263 minecraft:tuff
fill 286 261 237 291 261 237 minecraft:blackstone
setblock 286 261 239 minecraft:tuff
fill 286 261 250 286 261 251 minecraft:blackstone
setblock 286 261 252 minecraft:tuff
fill 286 261 253 286 264 253 minecraft:blackstone
fill 286 261 263 294 261 263 minecraft:blackstone
setblock 286 261 265 minecraft:tuff
fill 286 261 266 292 262 266 minecraft:blackstone
fill 287 261 239 289 261 239 minecraft:basalt
fill 287 261 240 289 261 240 minecraft:blackstone
setblock 287 261 241 minecraft:tuff
fill 287 261 242 287 263 243 minecraft:blackstone
fill 287 261 245 291 261 249 minecraft:netherrack
fill 287 261 250 290 261 250 minecraft:shroomlight
fill 287 261 251 293 261 253 minecraft:netherrack
setblock 287 261 254 minecraft:tuff
fill 287 261 265 298 261 265 minecraft:blackstone
setblock 287 261 267 minecraft:tuff
setblock 288 261 230 minecraft:tuff
fill 288 261 231 288 262 232 minecraft:blackstone
fill 288 261 241 288 262 242 minecraft:blackstone
fill 288 261 243 296 261 243 minecraft:netherrack
fill 288 261 244 290 261 244 minecraft:shroomlight
fill 288 261 254 291 261 255 minecraft:netherrack
setblock 288 261 256 minecraft:tuff
fill 288 261 257 288 263 258 minecraft:blackstone
fill 288 261 267 299 261 267 minecraft:blackstone
setblock 288 261 269 minecraft:tuff
fill 289 261 230 294 261 231 minecraft:blackstone
setblock 289 261 232 minecraft:tuff
fill 289 261 241 293 261 242 minecraft:netherrack
setblock 289 261 256 minecraft:netherrack
fill 289 261 257 290 261 257 minecraft:shroomlight
setblock 289 261 258 minecraft:tuff
fill 289 261 269 300 261 269 minecraft:basalt
fill 290 261 232 301 261 232 minecraft:blackstone
setblock 290 261 234 minecraft:tuff
fill 290 261 239 291 261 240 minecraft:netherrack
fill 290 261 256 291 261 256 minecraft:shroomlight
fill 290 261 258 295 261 259 minecraft:netherrack
setblock 290 261 260 minecraft:tuff
fill 291 261 234 296 261 234 minecraft:basalt
fill 291 261 235 294 261 235 minecraft:blackstone
setblock 291 261 236 minecraft:tuff
setblock 291 261 238 minecraft:shroomlight
fill 291 261 244 297 261 244 minecraft:netherrack
fill 291 261 250 297 261 250 minecraft:netherrack
fill 291 261 257 296 261 257 minecraft:netherrack
fill 291 261 260 295 261 260 minecraft:netherrack
fill 291 261 261 291 262 261 minecraft:blackstone
setblock 291 261 262 minecraft:tuff
fill 292 261 236 292 262 236 minecraft:blackstone
fill 292 261 237 296 261 238 minecraft:netherrack
setblock 292 261 239 minecraft:shroomlight
setblock 292 261 240 minecraft:netherrack
fill 292 261 245 294 261 245 minecraft:shroomlight
fill 292 261 246 296 261 248 minecraft:netherrack
fill 292 261 249 294 261 249 minecraft:shroomlight
setblock 292 261 254 minecraft:netherrack
setblock 292 261 255 minecraft:shroomlight
fill 292 261 256 297 261 256 minecraft:netherrack
fill 292 261 261 294 261 261 minecraft:netherrack
fill 292 261 262 292 263 262 minecraft:blackstone
setblock 292 261 264 minecraft:tuff
fill 293 261 236 296 261 236 minecraft:netherrack
fill 293 261 239 297 261 239 minecraft:netherrack
setblock 293 261 240 minecraft:shroomlight
setblock 293 261 254 minecraft:shroomlight
fill 293 261 255 297 261 255 minecraft:netherrack
fill 293 261 262 294 261 262 minecraft:netherrack
fill 293 261 264 296 261 264 minecraft:basalt
setblock 293 261 266 minecraft:tuff
setblock 294 261 229 minecraft:tuff
fill 294 261 240 301 261 240 minecraft:netherrack
setblock 294 261 241 minecraft:shroomlight
fill 294 261 242 295 261 242 minecraft:netherrack
fill 294 261 251 295 261 252 minecraft:netherrack
setblock 294 261 253 minecraft:shroomlight
fill 294 261 254 301 261 254 minecraft:netherrack
fill 294 261 266 305 261 266 minecraft:blackstone
setblock 294 261 268 minecraft:tuff
fill 295 261 229 306 261 229 minecraft:basalt
fill 295 261 230 300 261 230 minecraft:blackstone
setblock 295 261 231 minecraft:tuff
setblock 295 261 235 minecraft:netherrack
fill 295 261 241 298 261 241 minecraft:netherrack
fill 295 261 245 299 261 245 minecraft:netherrack
fill 295 261 249 299 261 249 minecraft:netherrack
fill 295 261 253 298 261 253 minecraft:netherrack
fill 295 261 261 295 261 262 minecraft:shroomlight
fill 295 261 263 301 261 263 minecraft:netherrack
fill 295 261 268 306 261 268 minecraft:blackstone
fill 296 261 231 307 261 231 minecraft:blackstone
setblock 296 261 233 minecraft:tuff
setblock 296 261 235 minecraft:shroomlight
setblock 296 261 242 minecraft:shroomlight
setblock 296 261 251 minecraft:netherrack
setblock 296 261 252 minecraft:shroomlight
setblock 296 261 258 minecraft:netherrack
fill 296 261 259 296 261 260 minecraft:shroomlight
fill 296 261 261 301 261 262 minecraft:netherrack
fill 297 261 233 298 263 233 minecraft:blackstone
fill 297 261 234 301 261 235 minecraft:netherrack
fill 297 261 236 297 261 237 minecraft:shroomlight
setblock 297 261 238 minecraft:netherrack
fill 297 261 242 301 261 242 minecraft:netherrack
setblock 297 261 243 minecraft:shroomlight
fill 297 261 246 298 261 246 minecraft:shroomlight
fill 297 261 247 298 261 247 minecraft:netherrack
fill 297 261 248 298 261 248 minecraft:shroomlight
setblock 297 261 251 minecraft:shroomlight
fill 297 261 252 301 261 252 minecraft:netherrack
fill 297 261 257 297 261 258 minecraft:shroomlight
fill 297 261 259 301 261 260 minecraft:netherrack
fill 297 261 264 301 261 264 minecraft:netherrack
fill 298 261 236 301 261 237 minecraft:netherrack
fill 298 261 238 298 261 239 minecraft:shroomlight
fill 298 261 243 299 261 243 minecraft:netherrack
setblock 298 261 244 minecraft:shroomlight
setblock 298 261 250 minecraft:shroomlight
fill 298 261 251 299 261 251 minecraft:netherrack
fill 298 261 255 298 261 256 minecraft:shroomlight
fill 298 261 257 301 261 258 minecraft:netherrack
fill 299 261 233 301 261 233 minecraft:netherrack
fill 299 261 238 301 261 239 minecraft:netherrack
setblock 299 261 241 minecraft:shroomlight
fill 299 261 244 300 261 244 minecraft:netherrack
fill 299 261 250 300 261 250 minecraft:netherrack
setblock 299 261 253 minecraft:shroomlight
fill 299 261 255 301 261 256 minecraft:netherrack
fill 299 261 265 301 261 265 minecraft:netherrack
fill 300 261 241 301 261 241 minecraft:netherrack
setblock 300 261 243 minecraft:shroomlight
setblock 300 261 251 minecraft:shroomlight
fill 300 261 253 301 261 253 minecraft:netherrack
setblock 300 261 267 minecraft:tuff
setblock 301 261 230 minecraft:tuff
setblock 301 261 243 minecraft:netherrack
setblock 301 261 251 minecraft:netherrack
fill 301 261 267 312 261 267 minecraft:blackstone
setblock 301 261 269 minecraft:tuff
fill 302 261 230 313 261 230 minecraft:blackstone
setblock 302 261 232 minecraft:tuff
fill 302 261 233 302 261 243 minecraft:shroomlight
fill 302 261 251 302 261 265 minecraft:shroomlight
fill 302 261 269 313 261 269 minecraft:basalt
fill 303 261 232 314 261 232 minecraft:blackstone
fill 303 261 233 303 261 243 minecraft:netherrack
fill 303 261 251 303 261 265 minecraft:netherrack
fill 304 261 233 304 261 242 minecraft:netherrack
setblock 304 261 243 minecraft:shroomlight
fill 304 261 244 305 261 244 minecraft:netherrack
fill 304 261 250 305 261 250 minecraft:netherrack
setblock 304 261 251 minecraft:shroomlight
fill 304 261 252 304 261 265 minecraft:netherrack
fill 305 261 233 305 261 240 minecraft:netherrack
setblock 305 261 241 minecraft:shroomlight
fill 305 261 242 306 261 243 minecraft:netherrack
fill 305 261 245 309 261 245 minecraft:netherrack
fill 305 261 249 309 261 249 minecraft:netherrack
fill 305 261 251 306 261 252 minecraft:netherrack
setblock 305 261 253 minecraft:shroomlight
fill 305 261 254 305 261 265 minecraft:netherrack
fill 306 261 233 306 261 237 minecraft:netherrack
fill 306 261 238 306 261 239 minecraft:shroomlight
fill 306 261 240 309 261 241 minecraft:netherrack
setblock 306 261 244 minecraft:shroomlight
fill 306 261 246 307 261 246 minecraft:shroomlight
fill 306 261 247 319 261 247 minecraft:netherrack
fill 306 261 248 307 261 248 minecraft:shroomlight
setblock 306 261 250 minecraft:shroomlight
fill 306 261 253 309 261 254 minecraft:netherrack
fill 306 261 255 306 261 256 minecraft:shroomlight
fill 306 261 257 306 261 265 minecraft:netherrack
setblock 306 261 266 minecraft:tuff
setblock 307 261 229 minecraft:tuff
fill 307 261 233 307 261 235 minecraft:netherrack
fill 307 261 236 307 261 237 minecraft:shroomlight
fill 307 261 238 311 261 239 minecraft:netherrack
setblock 307 261 242 minecraft:netherrack
setblock 307 261 243 minecraft:shroomlight
fill 307 261 244 313 261 244 minecraft:netherrack
fill 307 261 250 313 261 250 minecraft:netherrack
setblock 307 261 251 minecraft:shroomlight
setblock 307 261 252 minecraft:netherrack
fill 307 261 255 311 261 256 minecraft:netherrack
fill 307 261 257 307 261 258 minecraft:shroomlight
fill 307 261 259 307 261 265 minecraft:netherrack
fill 307 261 266 318 261 266 minecraft:blackstone
setblock 307 261 268 minecraft:tuff
fill 308 261 229 319 261 229 minecraft:basalt
setblock 308 261 231 minecraft:tuff
fill 308 261 233 308 264 233 minecraft:blackstone
fill 308 261 234 308 261 235 minecraft:shroomlight
fill 308 261 236 313 261 237 minecraft:netherrack
setblock 308 261 242 minecraft:shroomlight
fill 308 261 243 317 261 243 minecraft:netherrack
fill 308 261 246 319 261 246 minecraft:netherrack
fill 308 261 248 319 261 248 minecraft:netherrack
fill 308 261 251 317 261 251 minecraft:netherrack
setblock 308 261 252 minecraft:shroomlight
fill 308 261 257 313 261 258 minecraft:netherrack
fill 308 261 259 308 261 260 minecraft:shroomlight
fill 308 261 261 308 261 264 minecraft:netherrack
fill 308 261 265 311 261 265 minecraft:blackstone
fill 308 261 268 319 261 268 minecraft:blackstone
fill 309 261 231 320 261 231 minecraft:blackstone
setblock 309 261 233 minecraft:tuff
fill 309 261 234 309 261 235 minecraft:netherrack
fill 309 261 242 317 261 242 minecraft:netherrack
fill 309 261 252 319 261 252 minecraft:netherrack
fill 309 261 259 315 261 260 minecraft:netherrack
fill 309 261 261 309 261 262 minecraft:shroomlight
fill 309 261 263 309 261 264 minecraft:netherrack
fill 310 261 233 321 261 233 minecraft:blackstone
fill 310 261 234 315 261 234 minecraft:basalt
fill 310 261 235 311 261 235 minecraft:netherrack
setblock 310 261 240 minecraft:netherrack
setblock 310 261 241 minecraft:shroomlight
fill 310 261 245 312 261 245 minecraft:shroomlight
fill 310 261 249 312 261 249 minecraft:shroomlight
setblock 310 261 253 minecraft:shroomlight
setblock 310 261 254 minecraft:netherrack
fill 310 261 261 313 261 262 minecraft:netherrack
setblock 310 261 263 minecraft:shroomlight
fill 310 261 264 317 261 264 minecraft:basalt
setblock 311 261 240 minecraft:shroomlight
fill 311 261 241 317 261 241 minecraft:netherrack
fill 311 261 253 319 261 253 minecraft:netherrack
setblock 311 261 254 minecraft:shroomlight
setblock 311 261 263 minecraft:netherrack
fill 312 261 235 322 261 235 minecraft:blackstone
setblock 312 261 238 minecraft:netherrack
setblock 312 261 239 minecraft:shroomlight
fill 312 261 240 316 261 240 minecraft:netherrack
fill 312 261 254 318 261 254 minecraft:netherrack
setblock 312 261 255 minecraft:shroomlight
setblock 312 261 256 minecraft:netherrack
fill 312 261 263 323 261 263 minecraft:blackstone
setblock 312 261 265 minecraft:tuff
fill 313 261 238 314 261 238 minecraft:shroomlight
fill 313 261 239 316 261 239 minecraft:netherrack
fill 313 261 245 319 261 245 minecraft:netherrack
fill 313 261 249 319 261 249 minecraft:netherrack
fill 313 261 255 318 261 255 minecraft:netherrack
fill 313 261 256 314 261 256 minecraft:shroomlight
fill 313 261 265 323 261 265 minecraft:blackstone
setblock 313 261 267 minecraft:tuff
setblock 314 261 230 minecraft:tuff
fill 314 261 236 316 262 236 minecraft:blackstone
setblock 314 261 237 minecraft:shroomlight
fill 314 261 244 317 261 244 minecraft:shroomlight
fill 314 261 250 317 261 250 minecraft:shroomlight
fill 314 261 257 315 261 257 minecraft:shroomlight
setblock 314 261 258 minecraft:netherrack
setblock 314 261 261 minecraft:netherrack
fill 314 261 262 316 262 262 minecraft:blackstone
fill 314 261 267 323 261 267 minecraft:blackstone
setblock 314 261 269 minecraft:tuff
fill 315 261 230 323 261 230 minecraft:blackstone
setblock 315 261 232 minecraft:tuff
fill 315 261 237 323 261 237 minecraft:blackstone
setblock 315 261 238 minecraft:netherrack
fill 315 261 256 317 261 256 minecraft:netherrack
fill 315 261 258 316 261 258 minecraft:shroomlight
fill 315 261 261 322 261 261 minecraft:blackstone
fill 315 261 269 323 261 269 minecraft:basalt
fill 316 261 232 323 261 232 minecraft:blackstone
setblock 316 261 234 minecraft:tuff
fill 316 261 238 317 264 238 minecraft:blackstone
fill 316 261 257 317 261 257 minecraft:netherrack
setblock 316 261 259 minecraft:netherrack
setblock 316 261 260 minecraft:tuff
fill 317 261 234 323 261 234 minecraft:basalt
setblock 317 261 236 minecraft:tuff
fill 317 261 239 323 261 239 minecraft:basalt
fill 317 261 240 318 261 240 minecraft:blackstone
fill 317 261 258 323 261 258 minecraft:blackstone
fill 317 261 259 321 261 259 minecraft:basalt
fill 317 261 260 323 261 260 minecraft:blackstone
setblock 317 261 262 minecraft:tuff
fill 318 261 236 323 261 236 minecraft:blackstone
setblock 318 261 238 minecraft:tuff
fill 318 261 241 319 261 242 minecraft:blackstone
setblock 318 261 243 minecraft:shroomlight
setblock 318 261 244 minecraft:netherrack
fill 318 261 250 319 261 250 minecraft:netherrack
fill 318 261 251 319 261 251 minecraft:shroomlight
fill 318 261 256 320 261 257 minecraft:blackstone
fill 318 261 262 323 261 262 minecraft:blackstone
setblock 318 261 264 minecraft:tuff
fill 319 261 238 323 261 238 minecraft:blackstone
setblock 319 261 240 minecraft:tuff
fill 319 261 243 323 261 243 minecraft:blackstone
fill 319 261 244 320 261 244 minecraft:basalt
fill 319 261 254 323 261 254 minecraft:basalt
setblock 319 261 255 minecraft:blackstone
fill 319 261 264 323 261 264 minecraft:basalt
setblock 319 261 266 minecraft:tuff
setblock 320 261 229 minecraft:tuff
fill 320 261 240 323 261 241 minecraft:blackstone
setblock 320 261 242 minecraft:tuff
fill 320 261 245 321 261 248 minecraft:blackstone
fill 320 261 249 323 261 249 minecraft:basalt
fill 320 261 250 323 261 253 minecraft:blackstone
setblock 320 261 255 minecraft:tuff
fill 320 261 266 323 262 266 minecraft:blackstone
setblock 320 261 268 minecraft:tuff
fill 321 261 229 323 261 229 minecraft:basalt
setblock 321 261 231 minecraft:tuff
fill 321 261 242 323 263 242 minecraft:blackstone
setblock 321 261 244 minecraft:tuff
fill 321 261 255 323 261 256 minecraft:blackstone
setblock 321 261 257 minecraft:tuff
fill 321 261 268 323 263 268 minecraft:blackstone
fill 322 261 231 323 262 231 minecraft:blackstone
setblock 322 261 233 minecraft:tuff
fill 322 261 244 323 261 244 minecraft:basalt
fill 322 261 245 323 261 245 minecraft:blackstone
setblock 322 261 246 minecraft:tuff
fill 322 261 247 322 263 248 minecraft:blackstone
fill 322 261 257 323 263 257 minecraft:blackstone
setblock 322 261 259 minecraft:tuff
fill 323 261 233 323 264 233 minecraft:blackstone
setblock 323 261 235 minecraft:tuff
fill 323 261 246 323 262 247 minecraft:blackstone
setblock 323 261 248 minecraft:tuff
setblock 323 261 259 minecraft:basalt
setblock 323 261 261 minecraft:tuff
fill 324 261 248 324 266 248 minecraft:blackstone
fill 324 261 249 324 262 249 minecraft:magma_block
fill 282 262 255 282 283 255 minecraft:blackstone
fill 283 262 229 285 263 229 minecraft:blackstone
fill 283 262 230 292 262 230 minecraft:basalt
fill 283 262 231 286 262 234 minecraft:blackstone
fill 283 262 235 288 262 235 minecraft:basalt
setblock 283 262 236 minecraft:tuff
fill 283 262 237 283 262 239 minecraft:blackstone
fill 283 262 240 284 262 240 minecraft:basalt
fill 283 262 241 285 262 244 minecraft:blackstone
fill 283 262 245 293 262 245 minecraft:basalt
setblock 283 262 246 minecraft:blackstone
setblock 283 262 249 minecraft:tuff
fill 283 262 250 289 262 250 minecraft:basalt
fill 283 262 251 283 262 254 minecraft:blackstone
fill 283 262 255 285 262 255 minecraft:basalt
fill 283 262 256 286 262 259 minecraft:blackstone
fill 283 262 260 294 262 260 minecraft:basalt
fill 283 262 261 288 262 261 minecraft:blackstone
setblock 283 262 262 minecraft:tuff
fill 283 262 263 283 264 264 minecraft:blackstone
fill 283 262 265 290 262 265 minecraft:basalt
fill 283 262 266 284 262 266 minecraft:blackstone
fill 283 262 268 285 262 269 minecraft:blackstone
fill 284 262 236 289 262 237 minecraft:blackstone
setblock 284 262 238 minecraft:tuff
fill 284 262 239 290 263 239 minecraft:blackstone
fill 284 262 248 284 264 249 minecraft:blackstone
setblock 284 262 251 minecraft:tuff
fill 284 262 252 284 262 254 minecraft:blackstone
setblock 284 262 264 minecraft:tuff
setblock 285 262 240 minecraft:tuff
fill 285 262 249 295 262 249 minecraft:blackstone
fill 285 262 251 290 262 252 minecraft:blackstone
setblock 285 262 253 minecraft:tuff
fill 285 262 254 291 263 254 minecraft:blackstone
fill 285 262 262 289 262 264 minecraft:blackstone
setblock 285 262 266 minecraft:tuff
setblock 286 262 229 minecraft:tuff
fill 286 262 240 297 262 240 minecraft:basalt
fill 286 262 241 287 262 241 minecraft:blackstone
setblock 286 262 242 minecraft:tuff
fill 286 262 243 286 264 244 minecraft:blackstone
setblock 286 262 255 minecraft:tuff
setblock 286 262 268 minecraft:tuff
fill 286 262 269 292 263 269 minecraft:blackstone
fill 287 262 229 298 262 229 minecraft:blackstone
setblock 287 262 231 minecraft:tuff
fill 287 262 232 287 262 234 minecraft:blackstone
setblock 287 262 244 minecraft:tuff
fill 287 262 246 287 262 248 minecraft:blackstone
fill 287 262 253 297 262 253 minecraft:blackstone
fill 287 262 255 298 262 255 minecraft:basalt
fill 287 262 256 292 262 256 minecraft:blackstone
setblock 287 262 257 minecraft:tuff
fill 287 262 258 287 264 259 minecraft:blackstone
fill 287 262 267 291 262 268 minecraft:blackstone
setblock 288 262 233 minecraft:tuff
fill 288 262 234 294 263 234 minecraft:blackstone
fill 288 262 243 292 262 244 minecraft:blackstone
setblock 288 262 246 minecraft:tuff
fill 288 262 247 288 263 248 minecraft:blackstone
setblock 288 262 259 minecraft:tuff
fill 289 262 231 293 262 233 minecraft:blackstone
setblock 289 262 235 minecraft:tuff
fill 289 262 241 291 262 242 minecraft:blackstone
fill 289 262 246 294 262 247 minecraft:blackstone
setblock 289 262 248 minecraft:tuff
fill 289 262 257 293 262 259 minecraft:blackstone
setblock 289 262 261 minecraft:tuff
fill 290 262 235 301 262 235 minecraft:basalt
fill 290 262 236 291 262 236 minecraft:blackstone
setblock 290 262 237 minecraft:tuff
fill 290 262 248 298 262 248 minecraft:blackstone
setblock 290 262 250 minecraft:tuff
fill 290 262 261 290 262 262 minecraft:blackstone
setblock 290 262 263 minecraft:tuff
fill 290 262 264 296 263 264 minecraft:blackstone
fill 291 262 237 296 262 238 minecraft:blackstone
setblock 291 262 239 minecraft:tuff
fill 291 262 250 300 262 250 minecraft:basalt
fill 291 262 251 296 262 251 minecraft:blackstone
setblock 291 262 252 minecraft:tuff
fill 291 262 262 291 263 263 minecraft:blackstone
setblock 291 262 265 minecraft:tuff
fill 292 262 239 303 262 239 minecraft:blackstone
setblock 292 262 241 minecraft:tuff
fill 292 262 242 298 263 242 minecraft:blackstone
fill 292 262 252 303 262 252 minecraft:blackstone
setblock 292 262 254 minecraft:tuff
fill 292 262 261 301 262 261 minecraft:blackstone
fill 292 262 263 302 262 263 minecraft:blackstone
fill 292 262 265 303 262 265 minecraft:basalt
setblock 292 262 267 minecraft:tuff
fill 292 262 268 298 263 268 minecraft:blackstone
setblock 293 262 230 minecraft:tuff
fill 293 262 236 295 262 236 minecraft:blackstone
fill 293 262 241 304 262 241 minecraft:blackstone
setblock 293 262 243 minecraft:tuff
fill 293 262 244 299 263 244 minecraft:blackstone
fill 293 262 254 304 262 254 minecraft:blackstone
setblock 293 262 256 minecraft:tuff
fill 293 262 262 295 263 262 minecraft:blackstone
fill 293 262 266 297 262 267 minecraft:blackstone
setblock 293 262 269 minecraft:tuff
fill 294 262 230 305 262 230 minecraft:basalt
fill 294 262 231 299 262 231 minecraft:blackstone
setblock 294 262 232 minecraft:tuff
fill 294 262 233 296 264 233 minecraft:blackstone
fill 294 262 243 305 262 243 minecraft:blackstone
setblock 294 262 245 minecraft:tuff
fill 294 262 256 299 262 257 minecraft:blackstone
setblock 294 262 258 minecraft:tuff
fill 294 262 259 300 263 259 minecraft:blackstone
fill 294 262 269 305 262 269 minecraft:blackstone
fill 295 262 232 306 262 232 minecraft:blackstone
setblock 295 262 234 minecraft:tuff
fill 295 262 245 299 262 245 minecraft:basalt
fill 295 262 246 298 262 246 minecraft:blackstone
setblock 295 262 247 minecraft:tuff
fill 295 262 258 306 262 258 minecraft:blackstone
setblock 295 262 260 minecraft:tuff
fill 296 262 234 307 262 234 minecraft:blackstone
setblock 296 262 236 minecraft:tuff
fill 296 262 247 298 263 247 minecraft:blackstone
setblock 296 262 249 minecraft:tuff
fill 296 262 260 307 262 260 minecraft:basalt
setblock 296 262 262 minecraft:tuff
fill 297 262 236 302 262 237 minecraft:blackstone
setblock 297 262 238 minecraft:tuff
fill 297 262 249 299 263 249 minecraft:blackstone
setblock 297 262 251 minecraft:tuff
fill 297 262 262 308 262 262 minecraft:blackstone
setblock 297 262 264 minecraft:tuff
fill 298 262 238 309 262 238 minecraft:blackstone
setblock 298 262 240 minecraft:tuff
fill 298 262 251 309 262 251 minecraft:blackstone
setblock 298 262 253 minecraft:tuff
fill 298 262 264 309 262 264 minecraft:blackstone
setblock 298 262 266 minecraft:tuff
fill 298 262 267 304 263 267 minecraft:blackstone
setblock 299 262 229 minecraft:tuff
fill 299 262 233 300 264 233 minecraft:blackstone
fill 299 262 240 310 262 240 minecraft:basalt
setblock 299 262 242 minecraft:tuff
fill 299 262 253 310 262 253 minecraft:blackstone
setblock 299 262 255 minecraft:tuff
fill 299 262 266 310 262 266 minecraft:blackstone
setblock 299 262 268 minecraft:tuff
fill 300 262 229 311 262 229 minecraft:blackstone
setblock 300 262 231 minecraft:tuff
fill 300 262 242 311 262 242 minecraft:blackstone
setblock 300 262 244 minecraft:tuff
fill 300 262 255 311 262 255 minecraft:basalt
fill 300 262 256 305 262 256 minecraft:blackstone
setblock 300 262 257 minecraft:tuff
fill 300 262 268 311 262 268 minecraft:blackstone
fill 301 262 231 312 262 231 minecraft:blackstone
setblock 301 262 233 minecraft:tuff
fill 301 262 257 312 262 257 minecraft:blackstone
setblock 301 262 259 minecraft:tuff
fill 302 262 233 307 262 233 minecraft:blackstone
setblock 302 262 235 minecraft:tuff
fill 302 262 259 313 262 259 minecraft:blackstone
setblock 302 262 261 minecraft:tuff
fill 303 262 235 314 262 235 minecraft:basalt
fill 303 262 236 308 262 236 minecraft:blackstone
setblock 303 262 237 minecraft:tuff
fill 303 262 261 314 262 261 minecraft:blackstone
setblock 303 262 263 minecraft:tuff
fill 304 262 237 315 262 237 minecraft:blackstone
setblock 304 262 239 minecraft:tuff
fill 304 262 244 312 262 244 minecraft:blackstone
fill 304 262 250 315 262 250 minecraft:basalt
setblock 304 262 252 minecraft:tuff
fill 304 262 263 315 262 263 minecraft:blackstone
setblock 304 262 265 minecraft:tuff
fill 305 262 239 316 262 239 minecraft:blackstone
setblock 305 262 241 minecraft:tuff
fill 305 262 245 306 262 245 minecraft:basalt
fill 305 262 249 308 263 249 minecraft:blackstone
fill 305 262 252 316 262 252 minecraft:blackstone
setblock 305 262 254 minecraft:tuff
fill 305 262 265 316 262 265 minecraft:basalt
setblock 305 262 267 minecraft:tuff
setblock 306 262 230 minecraft:tuff
fill 306 262 241 317 262 241 minecraft:blackstone
setblock 306 262 243 minecraft:tuff
fill 306 262 246 307 262 248 minecraft:blackstone
fill 306 262 254 317 262 254 minecraft:blackstone
setblock 306 262 256 minecraft:tuff
fill 306 262 267 317 262 267 minecraft:blackstone
setblock 306 262 269 minecraft:tuff
fill 307 262 230 318 262 230 minecraft:basalt
setblock 307 262 232 minecraft:tuff
fill 307 262 243 318 262 243 minecraft:blackstone
setblock 307 262 245 minecraft:tuff
fill 307 262 256 318 262 256 minecraft:blackstone
setblock 307 262 258 minecraft:tuff
fill 307 262 269 318 262 269 minecraft:blackstone
fill 308 262 232 319 262 232 minecraft:blackstone
setblock 308 262 234 minecraft:tuff
fill 308 262 245 319 262 245 minecraft:basalt
fill 308 262 246 313 262 246 minecraft:blackstone
setblock 308 262 247 minecraft:tuff
fill 308 262 248 314 263 248 minecraft:blackstone
fill 308 262 258 319 262 258 minecraft:blackstone
setblock 308 262 260 minecraft:tuff
fill 309 262 233 313 262 234 minecraft:blackstone
setblock 309 262 236 minecraft:tuff
fill 309 262 247 320 262 247 minecraft:blackstone
setblock 309 262 249 minecraft:tuff
fill 309 262 260 320 262 260 minecraft:basalt
setblock 309 262 262 minecraft:tuff
fill 310 262 236 313 262 236 minecraft:blackstone
setblock 310 262 238 minecraft:tuff
fill 310 262 249 321 262 249 minecraft:blackstone
setblock 310 262 251 minecraft:tuff
fill 310 262 262 313 263 262 minecraft:blackstone
setblock 310 262 264 minecraft:tuff
fill 311 262 238 315 262 238 minecraft:blackstone
setblock 311 262 240 minecraft:tuff
fill 311 262 251 322 262 251 minecraft:blackstone
setblock 311 262 253 minecraft:tuff
fill 311 262 264 322 262 264 minecraft:blackstone
setblock 311 262 266 minecraft:tuff
setblock 312 262 229 minecraft:tuff
fill 312 262 240 323 262 240 minecraft:basalt
setblock 312 262 242 minecraft:tuff
fill 312 262 253 323 262 253 minecraft:blackstone
setblock 312 262 255 minecraft:tuff
fill 312 262 266 319 262 266 minecraft:blackstone
setblock 312 262 268 minecraft:tuff
fill 313 262 229 323 262 229 minecraft:blackstone
setblock 313 262 231 minecraft:tuff
fill 313 262 242 320 262 242 minecraft:blackstone
setblock 313 262 244 minecraft:tuff
fill 313 262 255 323 262 255 minecraft:basalt
setblock 313 262 257 minecraft:tuff
fill 313 262 268 320 262 268 minecraft:blackstone
fill 314 262 231 321 262 231 minecraft:blackstone
setblock 314 262 233 minecraft:tuff
fill 314 262 234 320 263 234 minecraft:blackstone
fill 314 262 244 323 262 244 minecraft:blackstone
setblock 314 262 246 minecraft:tuff
fill 314 262 257 321 262 257 minecraft:blackstone
setblock 314 262 259 minecraft:tuff
fill 315 262 233 322 262 233 minecraft:blackstone
setblock 315 262 235 minecraft:tuff
fill 315 262 246 322 262 246 minecraft:blackstone
setblock 315 262 248 minecraft:tuff
fill 315 262 259 323 262 259 minecraft:blackstone
setblock 315 262 261 minecraft:tuff
fill 316 262 235 323 262 235 minecraft:basalt
setblock 316 262 237 minecraft:tuff
fill 316 262 248 321 262 248 minecraft:blackstone
setblock 316 262 250 minecraft:tuff
fill 316 262 261 323 262 261 minecraft:blackstone
setblock 316 262 263 minecraft:tuff
fill 317 262 236 321 262 237 minecraft:blackstone
setblock 317 262 239 minecraft:tuff
fill 317 262 250 323 262 250 minecraft:basalt
setblock 317 262 252 minecraft:tuff
fill 317 262 262 321 262 263 minecraft:blackstone
setblock 317 262 265 minecraft:tuff
fill 318 262 238 322 262 239 minecraft:blackstone
setblock 318 262 241 minecraft:tuff
fill 318 262 252 323 262 252 minecraft:blackstone
setblock 318 262 254 minecraft:tuff
fill 318 262 265 323 262 265 minecraft:basalt
setblock 318 262 267 minecraft:tuff
setblock 319 262 230 minecraft:tuff
fill 319 262 241 323 262 241 minecraft:blackstone
setblock 319 262 243 minecraft:tuff
fill 319 262 254 323 262 254 minecraft:blackstone
setblock 319 262 256 minecraft:tuff
fill 319 262 267 323 262 267 minecraft:blackstone
setblock 319 262 269 minecraft:tuff
fill 320 262 230 323 262 230 minecraft:basalt
setblock 320 262 232 minecraft:tuff
fill 320 262 243 323 264 243 minecraft:blackstone
setblock 320 262 245 minecraft:tuff
fill 320 262 256 323 262 256 minecraft:blackstone
setblock 320 262 258 minecraft:tuff
fill 320 262 269 323 264 269 minecraft:blackstone
fill 321 262 232 323 263 232 minecraft:blackstone
setblock 321 262 234 minecraft:tuff
fill 321 262 245 323 262 245 minecraft:basalt
setblock 321 262 247 minecraft:tuff
fill 321 262 258 323 264 258 minecraft:blackstone
setblock 321 262 260 minecraft:tuff
fill 322 262 234 323 264 234 minecraft:blackstone
setblock 322 262 236 minecraft:tuff
fill 322 262 237 323 263 237 minecraft:blackstone
setblock 322 262 249 minecraft:tuff
fill 322 262 260 323 262 260 minecraft:basalt
setblock 322 262 262 minecraft:tuff
fill 322 262 263 323 264 263 minecraft:blackstone
setblock 323 262 236 minecraft:blackstone
setblock 323 262 238 minecraft:tuff
fill 323 262 239 323 265 239 minecraft:blackstone
fill 323 262 248 323 264 249 minecraft:blackstone
setblock 323 262 251 minecraft:tuff
fill 323 262 262 323 263 262 minecraft:blackstone
setblock 323 262 264 minecraft:tuff
fill 282 263 267 283 263 267 minecraft:blackstone
fill 283 263 230 284 266 230 minecraft:blackstone
fill 283 263 231 291 263 231 minecraft:basalt
fill 283 263 232 285 263 235 minecraft:blackstone
fill 283 263 236 287 263 236 minecraft:basalt
fill 283 263 237 288 263 238 minecraft:blackstone
setblock 283 263 239 minecraft:tuff
fill 283 263 240 289 264 240 minecraft:blackstone
setblock 283 263 241 minecraft:basalt
fill 283 263 242 284 263 245 minecraft:blackstone
fill 283 263 246 292 263 246 minecraft:basalt
fill 283 263 249 283 265 250 minecraft:blackstone
fill 283 263 251 288 263 251 minecraft:basalt
setblock 283 263 252 minecraft:tuff
fill 283 263 253 283 263 255 minecraft:blackstone
fill 283 263 256 284 263 256 minecraft:basalt
fill 283 263 257 285 263 260 minecraft:blackstone
fill 283 263 261 293 263 261 minecraft:basalt
setblock 283 263 262 minecraft:blackstone
setblock 283 263 265 minecraft:tuff
fill 283 263 266 289 263 266 minecraft:basalt
fill 283 263 268 284 263 269 minecraft:blackstone
setblock 284 263 241 minecraft:tuff
fill 284 263 247 286 263 247 minecraft:blackstone
fill 284 263 250 294 263 250 minecraft:blackstone
fill 284 263 252 285 263 253 minecraft:blackstone
setblock 284 263 254 minecraft:tuff
fill 284 263 255 290 264 255 minecraft:blackstone
fill 284 263 264 288 263 265 minecraft:blackstone
setblock 284 263 267 minecraft:tuff
setblock 285 263 230 minecraft:tuff
fill 285 263 241 296 263 241 minecraft:basalt
fill 285 263 242 286 263 242 minecraft:blackstone
setblock 285 263 243 minecraft:tuff
fill 285 263 244 285 265 245 minecraft:blackstone
fill 285 263 249 287 264 249 minecraft:blackstone
setblock 285 263 256 minecraft:tuff
fill 285 263 262 287 263 263 minecraft:blackstone
fill 285 263 267 290 263 268 minecraft:blackstone
setblock 285 263 269 minecraft:tuff
fill 286 263 229 290 263 230 minecraft:blackstone
setblock 286 263 232 minecraft:tuff
fill 286 263 233 286 263 235 minecraft:blackstone
setblock 286 263 245 minecraft:tuff
fill 286 263 252 295 263 252 minecraft:blackstone
fill 286 263 256 297 263 256 minecraft:basalt
fill 286 263 257 287 263 257 minecraft:blackstone
setblock 286 263 258 minecraft:tuff
fill 286 263 259 286 265 260 minecraft:blackstone
fill 287 263 232 292 263 233 minecraft:blackstone
setblock 287 263 234 minecraft:tuff
fill 287 263 235 293 264 235 minecraft:blackstone
fill 287 263 244 291 263 245 minecraft:blackstone
setblock 287 263 247 minecraft:tuff
fill 287 263 248 287 264 248 minecraft:blackstone
fill 287 263 253 289 264 253 minecraft:blackstone
setblock 287 263 260 minecraft:tuff
setblock 288 263 236 minecraft:tuff
fill 288 263 242 290 263 243 minecraft:blackstone
setblock 288 263 249 minecraft:tuff
fill 288 263 259 292 263 260 minecraft:blackstone
setblock 288 263 262 minecraft:tuff
fill 288 263 263 290 264 263 minecraft:blackstone
fill 289 263 236 300 263 236 minecraft:basalt
fill 289 263 237 294 263 237 minecraft:blackstone
setblock 289 263 238 minecraft:tuff
fill 289 263 247 293 263 249 minecraft:blackstone
setblock 289 263 251 minecraft:tuff
fill 289 263 257 291 263 258 minecraft:blackstone
fill 289 263 262 290 263 262 minecraft:blackstone
setblock 289 263 264 minecraft:tuff
fill 289 263 265 295 264 265 minecraft:blackstone
fill 290 263 238 301 263 238 minecraft:blackstone
setblock 290 263 240 minecraft:tuff
fill 290 263 251 301 263 251 minecraft:basalt
setblock 290 263 253 minecraft:tuff
setblock 290 263 266 minecraft:tuff
setblock 291 263 229 minecraft:tuff
fill 291 263 230 297 264 230 minecraft:blackstone
fill 291 263 239 295 263 240 minecraft:blackstone
setblock 291 263 242 minecraft:tuff
fill 291 263 243 297 264 243 minecraft:blackstone
fill 291 263 253 302 263 253 minecraft:blackstone
setblock 291 263 255 minecraft:tuff
fill 291 263 266 302 263 266 minecraft:basalt
fill 291 263 267 296 263 267 minecraft:blackstone
setblock 291 263 268 minecraft:tuff
fill 292 263 229 303 263 229 minecraft:blackstone
setblock 292 263 231 minecraft:tuff
setblock 292 263 244 minecraft:tuff
fill 292 263 245 298 263 245 minecraft:blackstone
fill 292 263 254 296 263 255 minecraft:blackstone
setblock 292 263 257 minecraft:tuff
fill 292 263 258 298 264 258 minecraft:blackstone
fill 292 263 263 294 264 263 minecraft:blackstone
fill 293 263 231 304 263 231 minecraft:basalt
fill 293 263 232 298 263 232 minecraft:blackstone
setblock 293 263 233 minecraft:tuff
setblock 293 263 246 minecraft:tuff
fill 293 263 257 304 263 257 minecraft:blackstone
setblock 293 263 259 minecraft:tuff
fill 293 263 260 299 264 260 minecraft:blackstone
fill 293 263 269 297 264 269 minecraft:blackstone
setblock 294 263 235 minecraft:tuff
fill 294 263 246 298 263 246 minecraft:basalt
fill 294 263 247 295 263 247 minecraft:blackstone
setblock 294 263 248 minecraft:tuff
fill 294 263 249 296 265 249 minecraft:blackstone
setblock 294 263 261 minecraft:tuff
fill 295 263 234 299 263 235 minecraft:blackstone
setblock 295 263 237 minecraft:tuff
fill 295 263 248 298 263 248 minecraft:blackstone
setblock 295 263 250 minecraft:tuff
fill 295 263 261 306 263 261 minecraft:basalt
setblock 295 263 263 minecraft:tuff
fill 296 263 237 307 263 237 minecraft:blackstone
setblock 296 263 239 minecraft:tuff
fill 296 263 240 302 264 240 minecraft:blackstone
fill 296 263 250 300 263 250 minecraft:blackstone
setblock 296 263 252 minecraft:tuff
fill 296 263 262 300 263 263 minecraft:blackstone
setblock 296 263 265 minecraft:tuff
fill 297 263 239 308 263 239 minecraft:blackstone
setblock 297 263 241 minecraft:tuff
fill 297 263 252 308 263 252 minecraft:blackstone
setblock 297 263 254 minecraft:tuff
fill 297 263 255 303 264 255 minecraft:blackstone
fill 297 263 264 301 263 265 minecraft:blackstone
setblock 297 263 267 minecraft:tuff
setblock 298 263 230 minecraft:tuff
fill 298 263 241 309 263 241 minecraft:basalt
setblock 298 263 243 minecraft:tuff
fill 298 263 254 309 263 254 minecraft:blackstone
setblock 298 263 256 minecraft:tuff
setblock 298 263 269 minecraft:tuff
fill 299 263 230 310 263 230 minecraft:blackstone
setblock 299 263 232 minecraft:tuff
fill 299 263 242 303 263 243 minecraft:blackstone
setblock 299 263 245 minecraft:tuff
fill 299 263 256 310 263 256 minecraft:basalt
setblock 299 263 258 minecraft:tuff
fill 299 263 268 303 263 269 minecraft:blackstone
fill 300 263 232 311 263 232 minecraft:blackstone
setblock 300 263 234 minecraft:tuff
fill 300 263 235 306 264 235 minecraft:blackstone
setblock 300 263 244 minecraft:blackstone
fill 300 263 258 311 263 258 minecraft:blackstone
setblock 300 263 260 minecraft:tuff
fill 301 263 233 305 263 234 minecraft:blackstone
setblock 301 263 236 minecraft:tuff
fill 301 263 259 305 263 260 minecraft:blackstone
setblock 301 263 262 minecraft:tuff
fill 301 263 263 307 264 263 minecraft:blackstone
fill 302 263 236 313 263 236 minecraft:basalt
setblock 302 263 238 minecraft:tuff
setblock 302 263 251 minecraft:tuff
fill 302 263 262 309 263 262 minecraft:blackstone
setblock 302 263 264 minecraft:tuff
fill 302 263 265 308 264 265 minecraft:blackstone
fill 303 263 238 314 263 238 minecraft:blackstone
setblock 303 263 240 minecraft:tuff
fill 303 263 251 314 263 251 minecraft:basalt
setblock 303 263 253 minecraft:tuff
fill 303 263 264 314 263 264 minecraft:blackstone
setblock 303 263 266 minecraft:tuff
setblock 304 263 229 minecraft:tuff
fill 304 263 240 315 263 240 minecraft:blackstone
setblock 304 263 242 minecraft:tuff
fill 304 263 243 304 263 244 minecraft:blackstone
fill 304 263 250 307 263 250 minecraft:blackstone
fill 304 263 253 315 263 253 minecraft:blackstone
setblock 304 263 255 minecraft:tuff
fill 304 263 266 315 263 266 minecraft:basalt
setblock 304 263 268 minecraft:tuff
fill 304 263 269 310 264 269 minecraft:blackstone
fill 305 263 229 316 263 229 minecraft:blackstone
setblock 305 263 231 minecraft:tuff
fill 305 263 242 310 263 243 minecraft:blackstone
setblock 305 263 244 minecraft:tuff
fill 305 263 245 311 263 245 minecraft:blackstone
fill 305 263 255 316 263 255 minecraft:blackstone
setblock 305 263 257 minecraft:tuff
fill 305 263 267 309 263 268 minecraft:blackstone
fill 306 263 231 317 263 231 minecraft:basalt
setblock 306 263 233 minecraft:tuff
fill 306 263 234 312 264 234 minecraft:blackstone
fill 306 263 244 317 263 244 minecraft:blackstone
setblock 306 263 246 minecraft:tuff
fill 306 263 247 306 263 248 minecraft:blackstone
fill 306 263 257 317 263 257 minecraft:blackstone
setblock 306 263 259 minecraft:tuff
fill 306 263 260 312 264 260 minecraft:blackstone
fill 307 263 233 307 264 233 minecraft:blackstone
setblock 307 263 235 minecraft:tuff
fill 307 263 246 318 263 246 minecraft:basalt
fill 307 263 247 312 263 247 minecraft:blackstone
setblock 307 263 248 minecraft:tuff
fill 307 263 259 318 263 259 minecraft:blackstone
setblock 307 263 261 minecraft:tuff
fill 308 263 235 319 263 235 minecraft:blackstone
setblock 308 263 237 minecraft:tuff
setblock 308 263 250 minecraft:tuff
fill 308 263 261 319 263 261 minecraft:basalt
setblock 308 263 263 minecraft:tuff
fill 309 263 233 318 263 233 minecraft:blackstone
fill 309 263 237 320 263 237 minecraft:blackstone
setblock 309 263 239 minecraft:tuff
fill 309 263 249 313 263 250 minecraft:blackstone
setblock 309 263 252 minecraft:tuff
fill 309 263 263 320 263 263 minecraft:blackstone
setblock 309 263 265 minecraft:tuff
setblock 309 263 270 minecraft:shroomlight
fill 310 263 239 321 263 239 minecraft:blackstone
setblock 310 263 241 minecraft:tuff
fill 310 263 252 321 263 252 minecraft:blackstone
setblock 310 263 254 minecraft:tuff
fill 310 263 265 321 263 265 minecraft:blackstone
setblock 310 263 267 minecraft:tuff
fill 310 263 268 316 264 268 minecraft:blackstone
setblock 311 263 230 minecraft:tuff
fill 311 263 241 322 263 241 minecraft:basalt
fill 311 263 242 316 263 242 minecraft:blackstone
setblock 311 263 243 minecraft:tuff
fill 311 263 254 322 263 254 minecraft:blackstone
setblock 311 263 256 minecraft:tuff
fill 311 263 267 322 263 267 minecraft:blackstone
setblock 311 263 269 minecraft:tuff
fill 312 263 230 323 263 230 minecraft:blackstone
setblock 312 263 232 minecraft:tuff
fill 312 263 243 319 263 243 minecraft:blackstone
setblock 312 263 245 minecraft:tuff
fill 312 263 256 323 263 256 minecraft:basalt
setblock 312 263 258 minecraft:tuff
fill 312 263 269 319 263 269 minecraft:blackstone
fill 313 263 232 320 263 232 minecraft:blackstone
setblock 313 263 234 minecraft:tuff
fill 313 263 245 323 263 245 minecraft:blackstone
setblock 313 263 247 minecraft:tuff
fill 313 263 258 320 263 258 minecraft:blackstone
setblock 313 263 260 minecraft:tuff
setblock 314 263 236 minecraft:tuff
fill 314 263 247 321 263 247 minecraft:blackstone
setblock 314 263 249 minecraft:tuff
fill 314 263 250 320 264 250 minecraft:blackstone
fill 314 263 260 323 263 260 minecraft:blackstone
setblock 314 263 262 minecraft:tuff
fill 315 263 236 323 263 236 minecraft:basalt
setblock 315 263 238 minecraft:tuff
fill 315 263 248 319 263 249 minecraft:blackstone
setblock 315 263 251 minecraft:tuff
fill 315 263 262 322 263 262 minecraft:blackstone
setblock 315 263 264 minecraft:tuff
setblock 316 263 240 minecraft:tuff
fill 316 263 251 323 263 251 minecraft:basalt
setblock 316 263 253 minecraft:tuff
fill 316 263 264 323 263 264 minecraft:blackstone
setblock 316 263 266 minecraft:tuff
setblock 317 263 229 minecraft:tuff
fill 317 263 240 323 263 240 minecraft:blackstone
setblock 317 263 242 minecraft:tuff
fill 317 263 253 323 263 253 minecraft:blackstone
setblock 317 263 255 minecraft:tuff
fill 317 263 266 323 263 266 minecraft:basalt
setblock 317 263 268 minecraft:tuff
fill 318 263 229 323 263 229 minecraft:blackstone
setblock 318 263 231 minecraft:tuff
fill 318 263 238 323 263 238 minecraft:blackstone
fill 318 263 242 320 263 242 minecraft:blackstone
setblock 318 263 244 minecraft:tuff
fill 318 263 255 323 263 255 minecraft:blackstone
setblock 318 263 257 minecraft:tuff
fill 318 263 268 320 264 268 minecraft:blackstone
fill 319 263 231 323 263 231 minecraft:basalt
setblock 319 263 233 minecraft:tuff
fill 319 263 244 323 263 244 minecraft:blackstone
setblock 319 263 246 minecraft:tuff
fill 319 263 257 321 263 257 minecraft:blackstone
setblock 319 263 259 minecraft:tuff
fill 320 263 233 322 264 233 minecraft:blackstone
setblock 320 263 235 minecraft:tuff
fill 320 263 246 323 263 246 minecraft:basalt
setblock 320 263 248 minecraft:tuff
fill 320 263 249 322 265 249 minecraft:blackstone
fill 320 263 259 323 265 259 minecraft:blackstone
setblock 320 263 261 minecraft:tuff
fill 321 263 234 321 265 235 minecraft:blackstone
setblock 321 263 237 minecraft:tuff
fill 321 263 248 321 264 248 minecraft:blackstone
setblock 321 263 250 minecraft:tuff
fill 321 263 261 323 263 261 minecraft:basalt
setblock 321 263 263 minecraft:tuff
fill 322 263 235 323 265 235 minecraft:blackstone
setblock 322 263 239 minecraft:tuff
fill 322 263 250 323 265 250 minecraft:blackstone
setblock 322 263 252 minecraft:tuff
setblock 322 263 265 minecraft:tuff
setblock 323 263 241 minecraft:tuff
setblock 323 263 247 minecraft:blackstone
setblock 323 263 252 minecraft:blackstone
setblock 323 263 254 minecraft:tuff
fill 323 263 265 323 266 265 minecraft:blackstone
setblock 323 263 267 minecraft:tuff
fill 324 263 249 324 264 249 minecraft:blackstone
setblock 324 263 250 minecraft:shroomlight
fill 324 263 251 324 283 251 minecraft:blackstone
fill 282 264 267 282 283 267 minecraft:blackstone
setblock 283 264 229 minecraft:tuff
fill 283 264 231 283 267 231 minecraft:blackstone
fill 283 264 232 290 264 232 minecraft:basalt
fill 283 264 233 284 264 236 minecraft:blackstone
fill 283 264 237 286 264 237 minecraft:basalt
fill 283 264 238 287 264 239 minecraft:blackstone
fill 283 264 241 288 265 241 minecraft:blackstone
setblock 283 264 242 minecraft:tuff
fill 283 264 243 283 264 246 minecraft:blackstone
fill 283 264 247 291 264 247 minecraft:basalt
setblock 283 264 248 minecraft:blackstone
fill 283 264 251 293 264 251 minecraft:blackstone
fill 283 264 252 287 264 252 minecraft:basalt
fill 283 264 253 285 264 254 minecraft:blackstone
setblock 283 264 255 minecraft:tuff
fill 283 264 256 289 265 256 minecraft:blackstone
setblock 283 264 257 minecraft:basalt
fill 283 264 258 284 264 261 minecraft:blackstone
fill 283 264 262 292 264 262 minecraft:basalt
fill 283 264 265 287 264 266 minecraft:blackstone
fill 283 264 267 288 264 267 minecraft:basalt
setblock 283 264 268 minecraft:tuff
fill 283 264 269 289 265 269 minecraft:blackstone
fill 284 264 229 295 264 229 minecraft:blackstone
setblock 284 264 231 minecraft:tuff
fill 284 264 242 295 264 242 minecraft:basalt
fill 284 264 243 285 264 243 minecraft:blackstone
setblock 284 264 244 minecraft:tuff
fill 284 264 245 284 266 246 minecraft:blackstone
fill 284 264 250 286 265 250 minecraft:blackstone
setblock 284 264 257 minecraft:tuff
fill 284 264 263 286 264 264 minecraft:blackstone
fill 284 264 268 295 264 268 minecraft:blackstone
fill 285 264 230 289 264 231 minecraft:blackstone
setblock 285 264 233 minecraft:tuff
fill 285 264 234 285 264 236 minecraft:blackstone
setblock 285 264 246 minecraft:tuff
setblock 285 264 248 minecraft:blackstone
fill 285 264 257 296 264 257 minecraft:basalt
fill 285 264 258 286 264 258 minecraft:blackstone
setblock 285 264 259 minecraft:tuff
fill 285 264 260 285 266 261 minecraft:blackstone
fill 286 264 233 291 264 234 minecraft:blackstone
setblock 286 264 235 minecraft:tuff
fill 286 264 236 292 265 236 minecraft:blackstone
fill 286 264 245 290 264 246 minecraft:blackstone
setblock 286 264 248 minecraft:tuff
fill 286 264 254 288 265 254 minecraft:blackstone
setblock 286 264 261 minecraft:tuff
setblock 287 264 237 minecraft:tuff
fill 287 264 243 289 264 244 minecraft:blackstone
setblock 287 264 250 minecraft:tuff
fill 287 264 260 291 264 261 minecraft:blackstone
setblock 287 264 263 minecraft:tuff
fill 287 264 264 293 265 264 minecraft:blackstone
fill 288 264 237 299 264 237 minecraft:basalt
fill 288 264 238 293 264 238 minecraft:blackstone
setblock 288 264 239 minecraft:tuff
fill 288 264 248 292 264 250 minecraft:blackstone
setblock 288 264 252 minecraft:tuff
fill 288 264 258 290 264 259 minecraft:blackstone
setblock 288 264 265 minecraft:tuff
fill 288 264 266 294 265 266 minecraft:blackstone
fill 289 264 239 300 264 239 minecraft:blackstone
setblock 289 264 241 minecraft:tuff
fill 289 264 252 300 264 252 minecraft:basalt
setblock 289 264 254 minecraft:tuff
setblock 289 264 267 minecraft:tuff
setblock 290 264 230 minecraft:tuff
fill 290 264 231 296 265 231 minecraft:blackstone
fill 290 264 240 294 264 241 minecraft:blackstone
setblock 290 264 243 minecraft:tuff
fill 290 264 244 296 265 244 minecraft:blackstone
fill 290 264 253 294 264 254 minecraft:blackstone
setblock 290 264 256 minecraft:tuff
fill 290 264 267 301 264 267 minecraft:basalt
setblock 290 264 269 minecraft:tuff
setblock 291 264 232 minecraft:tuff
setblock 291 264 245 minecraft:tuff
fill 291 264 246 297 264 246 minecraft:blackstone
fill 291 264 255 295 264 256 minecraft:blackstone
setblock 291 264 258 minecraft:tuff
fill 291 264 259 297 265 259 minecraft:blackstone
setblock 291 264 263 minecraft:blackstone
fill 291 264 269 292 265 269 minecraft:blackstone
fill 292 264 232 303 264 232 minecraft:basalt
fill 292 264 233 293 264 233 minecraft:blackstone
setblock 292 264 234 minecraft:tuff
fill 292 264 245 297 264 245 minecraft:blackstone
setblock 292 264 247 minecraft:tuff
setblock 292 264 260 minecraft:tuff
fill 292 264 261 298 265 261 minecraft:blackstone
fill 293 264 234 304 264 234 minecraft:blackstone
setblock 293 264 236 minecraft:tuff
fill 293 264 247 297 264 247 minecraft:basalt
fill 293 264 248 297 264 248 minecraft:blackstone
setblock 293 264 249 minecraft:tuff
fill 293 264 250 298 264 250 minecraft:blackstone
setblock 293 264 262 minecraft:tuff
fill 294 264 235 298 264 236 minecraft:blackstone
setblock 294 264 238 minecraft:tuff
setblock 294 264 251 minecraft:tuff
fill 294 264 262 305 264 262 minecraft:basalt
setblock 294 264 264 minecraft:tuff
fill 295 264 238 306 264 238 minecraft:blackstone
setblock 295 264 240 minecraft:tuff
fill 295 264 241 301 265 241 minecraft:blackstone
fill 295 264 251 299 264 251 minecraft:blackstone
setblock 295 264 253 minecraft:tuff
fill 295 264 254 301 265 254 minecraft:blackstone
fill 295 264 263 299 264 264 minecraft:blackstone
setblock 295 264 266 minecraft:tuff
setblock 296 264 229 minecraft:tuff
setblock 296 264 242 minecraft:tuff
fill 296 264 253 307 264 253 minecraft:blackstone
setblock 296 264 255 minecraft:tuff
fill 296 264 256 302 265 256 minecraft:blackstone
fill 296 264 265 300 264 266 minecraft:blackstone
setblock 296 264 268 minecraft:tuff
fill 297 264 229 308 264 229 minecraft:blackstone
setblock 297 264 231 minecraft:tuff
setblock 297 264 233 minecraft:blackstone
fill 297 264 242 308 264 242 minecraft:basalt
setblock 297 264 244 minecraft:tuff
setblock 297 264 249 minecraft:blackstone
setblock 297 264 257 minecraft:tuff
fill 297 264 268 308 264 268 minecraft:blackstone
fill 298 264 230 302 264 231 minecraft:blackstone
setblock 298 264 233 minecraft:tuff
fill 298 264 243 298 264 244 minecraft:blackstone
fill 298 264 245 298 264 249 minecraft:shroomlight
fill 298 264 257 309 264 257 minecraft:basalt
setblock 298 264 259 minecraft:tuff
fill 298 264 269 302 265 269 minecraft:blackstone
setblock 299 264 235 minecraft:tuff
fill 299 264 236 305 265 236 minecraft:blackstone
setblock 299 264 243 minecraft:blackstone
fill 299 264 244 299 264 245 minecraft:shroomlight
fill 299 264 249 299 264 250 minecraft:shroomlight
fill 299 264 258 303 264 259 minecraft:blackstone
setblock 299 264 261 minecraft:tuff
setblock 300 264 237 minecraft:tuff
fill 300 264 243 300 264 244 minecraft:shroomlight
fill 300 264 250 300 264 251 minecraft:shroomlight
fill 300 264 260 304 264 261 minecraft:blackstone
setblock 300 264 263 minecraft:tuff
fill 300 264 264 306 265 264 minecraft:blackstone
fill 301 264 233 306 264 233 minecraft:blackstone
fill 301 264 237 312 264 237 minecraft:basalt
setblock 301 264 239 minecraft:tuff
fill 301 264 243 304 264 243 minecraft:shroomlight
fill 301 264 251 304 264 251 minecraft:shroomlight
setblock 301 264 252 minecraft:tuff
setblock 301 264 265 minecraft:tuff
fill 301 264 266 307 265 266 minecraft:blackstone
fill 302 264 239 313 264 239 minecraft:blackstone
setblock 302 264 241 minecraft:tuff
fill 302 264 252 313 264 252 minecraft:basalt
setblock 302 264 254 minecraft:tuff
setblock 302 264 267 minecraft:tuff
setblock 303 264 230 minecraft:tuff
fill 303 264 231 309 265 231 minecraft:blackstone
fill 303 264 240 307 264 241 minecraft:blackstone
fill 303 264 254 314 264 254 minecraft:blackstone
setblock 303 264 256 minecraft:tuff
fill 303 264 267 314 264 267 minecraft:basalt
setblock 303 264 269 minecraft:tuff
fill 304 264 230 315 264 230 minecraft:blackstone
setblock 304 264 232 minecraft:tuff
fill 304 264 244 305 264 244 minecraft:shroomlight
fill 304 264 250 305 264 250 minecraft:shroomlight
fill 304 264 255 308 264 256 minecraft:blackstone
setblock 304 264 258 minecraft:tuff
fill 304 264 259 310 265 259 minecraft:blackstone
fill 305 264 232 316 264 232 minecraft:basalt
setblock 305 264 234 minecraft:tuff
fill 305 264 243 315 264 243 minecraft:blackstone
fill 305 264 245 306 264 245 minecraft:shroomlight
fill 305 264 249 306 264 249 minecraft:shroomlight
fill 305 264 251 306 264 251 minecraft:blackstone
fill 305 264 258 316 264 258 minecraft:blackstone
setblock 305 264 260 minecraft:tuff
fill 305 264 261 311 265 261 minecraft:blackstone
setblock 306 264 236 minecraft:tuff
fill 306 264 244 309 264 244 minecraft:blackstone
fill 306 264 246 306 264 248 minecraft:shroomlight
fill 306 264 250 312 264 250 minecraft:blackstone
setblock 306 264 262 minecraft:tuff
fill 307 264 235 311 264 236 minecraft:blackstone
setblock 307 264 238 minecraft:tuff
fill 307 264 245 310 264 246 minecraft:blackstone
fill 307 264 247 317 264 247 minecraft:basalt
fill 307 264 248 311 264 249 minecraft:blackstone
setblock 307 264 251 minecraft:tuff
fill 307 264 262 318 264 262 minecraft:basalt
setblock 307 264 264 minecraft:tuff
fill 308 264 238 315 264 238 minecraft:blackstone
setblock 308 264 240 minecraft:tuff
fill 308 264 241 314 265 241 minecraft:blackstone
fill 308 264 251 319 264 251 minecraft:blackstone
setblock 308 264 253 minecraft:tuff
fill 308 264 263 312 264 264 minecraft:blackstone
setblock 308 264 266 minecraft:tuff
setblock 309 264 229 minecraft:tuff
fill 309 264 233 310 264 233 minecraft:blackstone
fill 309 264 240 320 264 240 minecraft:blackstone
setblock 309 264 242 minecraft:tuff
fill 309 264 253 320 264 253 minecraft:blackstone
setblock 309 264 255 minecraft:tuff
fill 309 264 256 315 265 256 minecraft:blackstone
fill 309 264 265 313 264 266 minecraft:blackstone
setblock 309 264 268 minecraft:tuff
fill 309 264 270 309 283 270 minecraft:blackstone
fill 310 264 229 321 264 229 minecraft:blackstone
setblock 310 264 231 minecraft:tuff
fill 310 264 242 321 264 242 minecraft:basalt
setblock 310 264 244 minecraft:tuff
fill 310 264 255 321 264 255 minecraft:blackstone
setblock 310 264 257 minecraft:tuff
fill 311 264 231 322 264 231 minecraft:blackstone
setblock 311 264 233 minecraft:tuff
fill 311 264 244 316 264 245 minecraft:blackstone
setblock 311 264 246 minecraft:tuff
fill 311 264 257 322 264 257 minecraft:basalt
setblock 311 264 259 minecraft:tuff
fill 311 264 269 315 265 269 minecraft:blackstone
fill 312 264 233 319 264 233 minecraft:blackstone
setblock 312 264 235 minecraft:tuff
fill 312 264 236 318 265 236 minecraft:blackstone
fill 312 264 246 323 264 246 minecraft:blackstone
setblock 312 264 248 minecraft:tuff
fill 312 264 249 318 265 249 minecraft:blackstone
fill 312 264 259 319 264 259 minecraft:blackstone
setblock 312 264 261 minecraft:tuff
fill 313 264 234 317 264 235 minecraft:blackstone
setblock 313 264 237 minecraft:tuff
fill 313 264 248 320 264 248 minecraft:blackstone
setblock 313 264 250 minecraft:tuff
fill 313 264 260 317 264 261 minecraft:blackstone
setblock 313 264 263 minecraft:tuff
fill 313 264 264 319 265 264 minecraft:blackstone
fill 314 264 237 323 264 237 minecraft:basalt
setblock 314 264 239 minecraft:tuff
setblock 314 264 252 minecraft:tuff
fill 314 264 263 321 264 263 minecraft:blackstone
setblock 314 264 265 minecraft:tuff
fill 314 264 266 320 265 266 minecraft:blackstone
fill 315 264 239 322 264 239 minecraft:blackstone
setblock 315 264 241 minecraft:tuff
fill 315 264 252 323 264 252 minecraft:basalt
setblock 315 264 254 minecraft:tuff
fill 315 264 265 322 264 265 minecraft:blackstone
setblock 315 264 267 minecraft:tuff
setblock 316 264 230 minecraft:tuff
fill 316 264 241 323 264 241 minecraft:blackstone
setblock 316 264 243 minecraft:tuff
fill 316 264 254 323 264 254 minecraft:blackstone
setblock 316 264 256 minecraft:tuff
fill 316 264 267 323 264 267 minecraft:basalt
setblock 316 264 269 minecraft:tuff
fill 317 264 230 323 264 230 minecraft:blackstone
setblock 317 264 232 minecraft:tuff
fill 317 264 243 319 264 244 minecraft:blackstone
setblock 317 264 245 minecraft:tuff
fill 317 264 256 323 264 256 minecraft:blackstone
setblock 317 264 258 minecraft:tuff
fill 317 264 268 317 264 269 minecraft:blackstone
fill 318 264 232 323 264 232 minecraft:basalt
setblock 318 264 234 minecraft:tuff
fill 318 264 235 320 266 235 minecraft:blackstone
fill 318 264 238 319 264 238 minecraft:blackstone
fill 318 264 245 323 264 245 minecraft:blackstone
setblock 318 264 247 minecraft:tuff
fill 318 264 258 320 264 258 minecraft:blackstone
setblock 318 264 260 minecraft:tuff
fill 318 264 261 323 265 261 minecraft:blackstone
fill 318 264 269 319 265 269 minecraft:blackstone
fill 319 264 234 320 265 234 minecraft:blackstone
setblock 319 264 236 minecraft:tuff
fill 319 264 247 323 264 247 minecraft:basalt
setblock 319 264 249 minecraft:tuff
fill 319 264 260 323 264 260 minecraft:blackstone
setblock 319 264 262 minecraft:tuff
fill 320 264 236 323 266 236 minecraft:blackstone
setblock 320 264 238 minecraft:tuff
fill 320 264 244 322 265 244 minecraft:blackstone
setblock 320 264 251 minecraft:tuff
fill 320 264 262 323 264 262 minecraft:basalt
setblock 320 264 264 minecraft:tuff
fill 321 264 238 323 264 238 minecraft:blackstone
setblock 321 264 240 minecraft:tuff
fill 321 264 250 321 266 251 minecraft:blackstone
setblock 321 264 253 minecraft:tuff
fill 321 264 264 323 265 264 minecraft:blackstone
setblock 321 264 266 minecraft:tuff
setblock 321 264 268 minecraft:blackstone
setblock 322 264 229 minecraft:tuff
fill 322 264 240 323 266 240 minecraft:blackstone
setblock 322 264 242 minecraft:tuff
setblock 322 264 248 minecraft:blackstone
fill 322 264 251 323 266 251 minecraft:blackstone
fill 322 264 253 323 264 253 minecraft:blackstone
setblock 322 264 255 minecraft:tuff
fill 322 264 266 323 266 266 minecraft:blackstone
setblock 322 264 268 minecraft:tuff
fill 323 264 229 323 265 229 minecraft:blackstone
setblock 323 264 231 minecraft:tuff
setblock 323 264 242 minecraft:basalt
setblock 323 264 244 minecraft:tuff
fill 323 264 255 323 266 255 minecraft:blackstone
setblock 323 264 257 minecraft:tuff
setblock 323 264 268 minecraft:blackstone
setblock 324 264 250 minecraft:magma_block
fill 283 265 229 287 265 229 minecraft:blackstone
setblock 283 265 232 minecraft:tuff
fill 283 265 233 289 265 233 minecraft:basalt
fill 283 265 234 283 265 237 minecraft:blackstone
fill 283 265 238 285 265 238 minecraft:basalt
fill 283 265 239 286 265 240 minecraft:blackstone
fill 283 265 242 287 266 242 minecraft:blackstone
fill 283 265 243 294 265 243 minecraft:basalt
fill 283 265 244 284 265 244 minecraft:blackstone
setblock 283 265 245 minecraft:tuff
fill 283 265 246 283 267 247 minecraft:blackstone
fill 283 265 248 290 265 248 minecraft:basalt
fill 283 265 251 285 265 252 minecraft:blackstone
fill 283 265 253 286 265 253 minecraft:basalt
fill 283 265 254 285 265 255 minecraft:blackstone
fill 283 265 257 288 266 257 minecraft:blackstone
setblock 283 265 258 minecraft:tuff
fill 283 265 259 283 265 262 minecraft:blackstone
fill 283 265 263 291 265 263 minecraft:basalt
fill 283 265 264 285 265 267 minecraft:blackstone
fill 283 265 268 287 265 268 minecraft:basalt
fill 284 265 231 288 265 232 minecraft:blackstone
setblock 284 265 234 minecraft:tuff
fill 284 265 235 284 265 237 minecraft:blackstone
setblock 284 265 247 minecraft:tuff
setblock 284 265 249 minecraft:blackstone
fill 284 265 258 295 265 258 minecraft:basalt
fill 284 265 259 285 265 259 minecraft:blackstone
setblock 284 265 260 minecraft:tuff
fill 284 265 261 284 267 262 minecraft:blackstone
fill 285 265 230 294 265 230 minecraft:blackstone
fill 285 265 234 290 265 235 minecraft:blackstone
setblock 285 265 236 minecraft:tuff
fill 285 265 237 291 266 237 minecraft:blackstone
fill 285 265 246 289 265 247 minecraft:blackstone
setblock 285 265 249 minecraft:tuff
setblock 285 265 262 minecraft:tuff
setblock 286 265 238 minecraft:tuff
fill 286 265 244 288 265 245 minecraft:blackstone
fill 286 265 249 293 265 249 minecraft:blackstone
setblock 286 265 251 minecraft:tuff
fill 286 265 252 292 266 252 minecraft:blackstone
fill 286 265 255 287 266 255 minecraft:blackstone
fill 286 265 261 290 265 262 minecraft:blackstone
setblock 286 265 264 minecraft:tuff
fill 286 265 265 286 265 267 minecraft:blackstone
fill 287 265 238 298 265 238 minecraft:basalt
fill 287 265 239 292 265 239 minecraft:blackstone
setblock 287 265 240 minecraft:tuff
fill 287 265 250 291 265 251 minecraft:blackstone
setblock 287 265 253 minecraft:tuff
fill 287 265 259 289 265 260 minecraft:blackstone
fill 287 265 265 292 266 265 minecraft:blackstone
setblock 287 265 266 minecraft:tuff
fill 287 265 267 293 266 267 minecraft:blackstone
setblock 288 265 229 minecraft:tuff
fill 288 265 240 299 265 240 minecraft:blackstone
setblock 288 265 242 minecraft:tuff
fill 288 265 253 299 265 253 minecraft:basalt
setblock 288 265 255 minecraft:tuff
setblock 288 265 268 minecraft:tuff
fill 289 265 229 300 265 229 minecraft:blackstone
setblock 289 265 231 minecraft:tuff
fill 289 265 232 295 266 232 minecraft:blackstone
fill 289 265 241 293 265 242 minecraft:blackstone
setblock 289 265 244 minecraft:tuff
fill 289 265 245 295 266 245 minecraft:blackstone
fill 289 265 254 293 265 255 minecraft:blackstone
setblock 289 265 257 minecraft:tuff
fill 289 265 268 300 265 268 minecraft:basalt
setblock 290 265 233 minecraft:tuff
setblock 290 265 246 minecraft:tuff
fill 290 265 247 296 265 247 minecraft:blackstone
fill 290 265 256 294 265 257 minecraft:blackstone
setblock 290 265 259 minecraft:tuff
fill 290 265 260 296 266 260 minecraft:blackstone
setblock 290 265 269 minecraft:blackstone
fill 291 265 233 302 265 233 minecraft:basalt
fill 291 265 234 296 265 234 minecraft:blackstone
setblock 291 265 235 minecraft:tuff
fill 291 265 246 296 265 246 minecraft:blackstone
setblock 291 265 248 minecraft:tuff
setblock 291 265 261 minecraft:tuff
fill 291 265 262 297 266 262 minecraft:blackstone
fill 292 265 235 303 265 235 minecraft:blackstone
setblock 292 265 237 minecraft:tuff
fill 292 265 248 296 265 248 minecraft:basalt
setblock 292 265 250 minecraft:tuff
fill 292 265 251 298 265 251 minecraft:blackstone
setblock 292 265 263 minecraft:tuff
fill 293 265 236 297 265 237 minecraft:blackstone
setblock 293 265 239 minecraft:tuff
fill 293 265 250 297 265 250 minecraft:blackstone
setblock 293 265 252 minecraft:tuff
fill 293 265 263 304 265 263 minecraft:basalt
setblock 293 265 265 minecraft:tuff
fill 293 265 269 294 265 269 minecraft:blackstone
setblock 293 265 270 minecraft:magma_block
fill 294 265 239 305 265 239 minecraft:blackstone
setblock 294 265 241 minecraft:tuff
fill 294 265 242 299 265 242 minecraft:blackstone
fill 294 265 252 299 265 252 minecraft:blackstone
setblock 294 265 254 minecraft:tuff
fill 294 265 255 300 266 255 minecraft:blackstone
fill 294 265 264 298 265 265 minecraft:blackstone
setblock 294 265 267 minecraft:tuff
setblock 295 265 230 minecraft:tuff
setblock 295 265 243 minecraft:tuff
setblock 295 265 256 minecraft:tuff
fill 295 265 257 301 266 257 minecraft:blackstone
fill 295 265 266 299 265 267 minecraft:blackstone
setblock 295 265 269 minecraft:tuff
setblock 295 265 270 minecraft:crying_obsidian
fill 296 265 230 307 265 230 minecraft:blackstone
setblock 296 265 232 minecraft:tuff
fill 296 265 243 298 265 243 minecraft:basalt
setblock 296 265 245 minecraft:tuff
setblock 296 265 258 minecraft:tuff
fill 296 265 269 297 265 269 minecraft:blackstone
fill 297 265 231 301 265 232 minecraft:blackstone
setblock 297 265 234 minecraft:tuff
setblock 297 265 244 minecraft:blackstone
fill 297 265 245 297 266 245 minecraft:netherrack
setblock 297 265 246 minecraft:shroomlight
setblock 297 265 247 minecraft:netherrack
setblock 297 265 248 minecraft:shroomlight
fill 297 265 249 297 266 249 minecraft:netherrack
fill 297 265 258 308 265 258 minecraft:basalt
setblock 297 265 260 minecraft:tuff
fill 298 265 234 309 265 234 minecraft:blackstone
setblock 298 265 236 minecraft:tuff
fill 298 265 237 304 266 237 minecraft:blackstone
setblock 298 265 244 minecraft:shroomlight
setblock 298 265 250 minecraft:shroomlight
fill 298 265 259 302 265 260 minecraft:blackstone
setblock 298 265 262 minecraft:tuff
setblock 299 265 238 minecraft:tuff
setblock 299 265 243 minecraft:netherrack
setblock 299 265 251 minecraft:netherrack
fill 299 265 261 303 265 262 minecraft:blackstone
setblock 299 265 264 minecraft:tuff
fill 299 265 265 305 266 265 minecraft:blackstone
fill 300 265 238 311 265 238 minecraft:basalt
setblock 300 265 240 minecraft:tuff
fill 300 265 242 301 265 242 minecraft:netherrack
fill 300 265 252 301 265 252 minecraft:netherrack
setblock 300 265 253 minecraft:tuff
setblock 300 265 266 minecraft:tuff
fill 300 265 267 306 266 267 minecraft:blackstone
setblock 301 265 229 minecraft:tuff
fill 301 265 240 312 265 240 minecraft:blackstone
fill 301 265 253 312 265 253 minecraft:basalt
setblock 301 265 255 minecraft:tuff
setblock 301 265 268 minecraft:tuff
fill 302 265 229 313 265 229 minecraft:blackstone
setblock 302 265 231 minecraft:tuff
fill 302 265 232 308 266 232 minecraft:blackstone
fill 302 265 241 306 265 241 minecraft:blackstone
setblock 302 265 242 minecraft:shroomlight
setblock 302 265 252 minecraft:shroomlight
fill 302 265 254 306 265 255 minecraft:blackstone
setblock 302 265 257 minecraft:tuff
fill 302 265 268 313 265 268 minecraft:basalt
setblock 303 265 233 minecraft:tuff
fill 303 265 242 304 265 242 minecraft:netherrack
fill 303 265 252 304 265 252 minecraft:netherrack
fill 303 265 256 307 265 257 minecraft:blackstone
setblock 303 265 259 minecraft:tuff
fill 303 265 260 309 266 260 minecraft:blackstone
fill 303 265 269 307 265 269 minecraft:blackstone
fill 304 265 233 315 265 233 minecraft:basalt
setblock 304 265 235 minecraft:tuff
setblock 304 265 261 minecraft:tuff
fill 304 265 262 310 266 262 minecraft:blackstone
fill 305 265 235 316 265 235 minecraft:blackstone
setblock 305 265 237 minecraft:tuff
fill 305 265 242 313 265 242 minecraft:blackstone
setblock 305 265 243 minecraft:netherrack
setblock 305 265 251 minecraft:netherrack
setblock 305 265 252 minecraft:blackstone
setblock 305 265 263 minecraft:tuff
fill 306 265 236 310 265 237 minecraft:blackstone
setblock 306 265 239 minecraft:tuff
fill 306 265 243 307 265 243 minecraft:basalt
setblock 306 265 244 minecraft:shroomlight
setblock 306 265 250 minecraft:shroomlight
fill 306 265 251 311 265 251 minecraft:blackstone
setblock 306 265 252 minecraft:tuff
fill 306 265 263 317 265 263 minecraft:basalt
setblock 306 265 265 minecraft:tuff
fill 307 265 239 318 265 239 minecraft:blackstone
setblock 307 265 241 minecraft:tuff
fill 307 265 244 314 265 244 minecraft:blackstone
fill 307 265 245 307 266 245 minecraft:netherrack
setblock 307 265 246 minecraft:shroomlight
setblock 307 265 247 minecraft:netherrack
setblock 307 265 248 minecraft:shroomlight
fill 307 265 249 307 266 249 minecraft:netherrack
fill 307 265 250 317 265 250 minecraft:blackstone
fill 307 265 252 318 265 252 minecraft:blackstone
setblock 307 265 254 minecraft:tuff
fill 307 265 255 313 266 255 minecraft:blackstone
fill 307 265 264 311 265 265 minecraft:blackstone
setblock 307 265 267 minecraft:tuff
setblock 308 265 230 minecraft:tuff
setblock 308 265 243 minecraft:tuff
fill 308 265 245 308 265 247 minecraft:blackstone
fill 308 265 248 316 265 248 minecraft:basalt
fill 308 265 249 310 265 249 minecraft:blackstone
fill 308 265 254 319 265 254 minecraft:blackstone
setblock 308 265 256 minecraft:tuff
fill 308 265 257 314 266 257 minecraft:blackstone
fill 308 265 266 312 265 267 minecraft:blackstone
setblock 308 265 269 minecraft:tuff
fill 309 265 230 320 265 230 minecraft:blackstone
setblock 309 265 232 minecraft:tuff
fill 309 265 243 320 265 243 minecraft:basalt
setblock 309 265 245 minecraft:tuff
fill 309 265 246 309 267 247 minecraft:blackstone
setblock 309 265 258 minecraft:tuff
fill 309 265 269 310 265 269 minecraft:blackstone
fill 310 265 231 314 265 232 minecraft:blackstone
setblock 310 265 234 minecraft:tuff
fill 310 265 245 315 265 246 minecraft:blackstone
setblock 310 265 247 minecraft:tuff
fill 310 265 258 321 265 258 minecraft:basalt
setblock 310 265 260 minecraft:tuff
fill 311 265 234 318 265 234 minecraft:blackstone
setblock 311 265 236 minecraft:tuff
fill 311 265 237 317 266 237 minecraft:blackstone
fill 311 265 247 322 265 247 minecraft:blackstone
setblock 311 265 249 minecraft:tuff
fill 311 265 259 315 265 260 minecraft:blackstone
setblock 311 265 262 minecraft:tuff
setblock 312 265 238 minecraft:tuff
setblock 312 265 251 minecraft:tuff
fill 312 265 261 316 265 262 minecraft:blackstone
setblock 312 265 264 minecraft:tuff
fill 312 265 265 318 266 265 minecraft:blackstone
fill 313 265 238 323 265 238 minecraft:basalt
setblock 313 265 240 minecraft:tuff
fill 313 265 251 320 265 251 minecraft:blackstone
setblock 313 265 253 minecraft:tuff
setblock 313 265 266 minecraft:tuff
fill 313 265 267 319 266 267 minecraft:blackstone
setblock 314 265 229 minecraft:tuff
fill 314 265 240 321 265 240 minecraft:blackstone
setblock 314 265 242 minecraft:tuff
fill 314 265 253 323 265 253 minecraft:basalt
setblock 314 265 255 minecraft:tuff
setblock 314 265 268 minecraft:tuff
fill 315 265 229 322 265 229 minecraft:blackstone
setblock 315 265 231 minecraft:tuff
fill 315 265 232 321 266 232 minecraft:blackstone
fill 315 265 241 319 265 242 minecraft:blackstone
setblock 315 265 244 minecraft:tuff
fill 315 265 255 322 265 255 minecraft:blackstone
setblock 315 265 257 minecraft:tuff
fill 315 265 268 323 265 268 minecraft:basalt
fill 316 265 231 323 265 231 minecraft:blackstone
setblock 316 265 233 minecraft:tuff
fill 316 265 244 319 265 245 minecraft:blackstone
setblock 316 265 246 minecraft:tuff
fill 316 265 256 320 265 257 minecraft:blackstone
setblock 316 265 259 minecraft:tuff
fill 316 265 260 322 266 260 minecraft:blackstone
fill 316 265 269 317 265 269 minecraft:blackstone
fill 317 265 233 323 265 233 minecraft:basalt
setblock 317 265 235 minecraft:tuff
fill 317 265 246 323 265 246 minecraft:blackstone
setblock 317 265 248 minecraft:tuff
fill 317 265 259 319 265 259 minecraft:blackstone
setblock 317 265 261 minecraft:tuff
fill 317 265 262 323 266 262 minecraft:blackstone
setblock 318 265 237 minecraft:tuff
fill 318 265 248 323 265 248 minecraft:basalt
setblock 318 265 250 minecraft:tuff
setblock 318 265 263 minecraft:tuff
fill 319 265 236 319 267 237 minecraft:blackstone
setblock 319 265 239 minecraft:tuff
fill 319 265 249 319 265 250 minecraft:blackstone
setblock 319 265 252 minecraft:tuff
fill 319 265 263 323 265 263 minecraft:basalt
setblock 319 265 265 minecraft:tuff
fill 320 265 237 323 265 237 minecraft:blackstone
fill 320 265 239 322 265 239 minecraft:blackstone
setblock 320 265 241 minecraft:tuff
fill 320 265 242 323 268 242 minecraft:blackstone
fill 320 265 245 321 266 245 minecraft:blackstone
fill 320 265 250 320 266 250 minecraft:blackstone
fill 320 265 252 323 267 252 minecraft:blackstone
setblock 320 265 254 minecraft:tuff
fill 320 265 264 320 265 265 minecraft:blackstone
setblock 320 265 267 minecraft:tuff
setblock 320 265 269 minecraft:blackstone
setblock 321 265 230 minecraft:tuff
fill 321 265 241 323 267 241 minecraft:blackstone
setblock 321 265 243 minecraft:tuff
fill 321 265 254 323 265 254 minecraft:blackstone
setblock 321 265 256 minecraft:tuff
fill 321 265 257 323 268 257 minecraft:blackstone
fill 321 265 265 321 266 267 minecraft:blackstone
setblock 321 265 269 minecraft:tuff
fill 322 265 230 323 266 230 minecraft:blackstone
setblock 322 265 232 minecraft:tuff
setblock 322 265 234 minecraft:blackstone
fill 322 265 243 323 265 243 minecraft:basalt
setblock 322 265 245 minecraft:tuff
fill 322 265 256 323 267 256 minecraft:blackstone
setblock 322 265 258 minecraft:tuff
fill 322 265 265 322 266 265 minecraft:blackstone
fill 322 265 267 323 267 267 minecraft:blackstone
fill 322 265 269 323 265 269 minecraft:blackstone
fill 323 265 232 323 268 232 minecraft:blackstone
setblock 323 265 234 minecraft:tuff
fill 323 265 244 323 265 245 minecraft:blackstone
setblock 323 265 247 minecraft:tuff
setblock 323 265 249 minecraft:blackstone
setblock 323 265 258 minecraft:basalt
setblock 323 265 260 minecraft:tuff
fill 324 265 249 324 266 249 minecraft:magma_block
fill 324 265 250 324 270 250 minecraft:blackstone
fill 283 266 229 292 266 229 minecraft:basalt
fill 283 266 232 287 266 233 minecraft:blackstone
fill 283 266 234 288 266 234 minecraft:basalt
setblock 283 266 235 minecraft:tuff
fill 283 266 236 283 266 238 minecraft:blackstone
fill 283 266 239 284 266 239 minecraft:basalt
fill 283 266 240 285 266 241 minecraft:blackstone
fill 283 266 243 286 267 243 minecraft:blackstone
fill 283 266 244 293 266 244 minecraft:basalt
setblock 283 266 245 minecraft:blackstone
setblock 283 266 248 minecraft:tuff
fill 283 266 249 289 266 249 minecraft:basalt
fill 283 266 250 283 266 253 minecraft:blackstone
fill 283 266 254 285 266 254 minecraft:basalt
fill 283 266 255 285 266 256 minecraft:blackstone
fill 283 266 258 287 267 258 minecraft:blackstone
fill 283 266 259 294 266 259 minecraft:basalt
fill 283 266 260 284 266 260 minecraft:blackstone
setblock 283 266 261 minecraft:tuff
fill 283 266 262 283 268 263 minecraft:blackstone
fill 283 266 264 290 266 264 minecraft:basalt
fill 283 266 265 284 266 268 minecraft:blackstone
fill 283 266 269 286 266 269 minecraft:basalt
fill 284 266 231 293 266 231 minecraft:blackstone
fill 284 266 235 289 266 236 minecraft:blackstone
setblock 284 266 237 minecraft:tuff
fill 284 266 238 290 267 238 minecraft:blackstone
fill 284 266 247 288 266 248 minecraft:blackstone
setblock 284 266 250 minecraft:tuff
fill 284 266 251 284 266 253 minecraft:blackstone
setblock 284 266 263 minecraft:tuff
fill 285 266 230 286 266 230 minecraft:blackstone
setblock 285 266 239 minecraft:tuff
fill 285 266 245 287 266 246 minecraft:blackstone
fill 285 266 250 290 266 251 minecraft:blackstone
setblock 285 266 252 minecraft:tuff
fill 285 266 253 291 267 253 minecraft:blackstone
fill 285 266 262 289 266 263 minecraft:blackstone
setblock 285 266 265 minecraft:tuff
fill 285 266 266 285 266 268 minecraft:blackstone
fill 286 266 239 297 266 239 minecraft:basalt
fill 286 266 240 291 266 240 minecraft:blackstone
setblock 286 266 241 minecraft:tuff
setblock 286 266 254 minecraft:tuff
fill 286 266 256 286 267 256 minecraft:blackstone
fill 286 266 260 288 266 261 minecraft:blackstone
fill 286 266 265 286 266 266 minecraft:blackstone
setblock 286 266 267 minecraft:tuff
fill 286 266 268 292 267 268 minecraft:blackstone
setblock 287 266 230 minecraft:tuff
fill 287 266 241 298 266 241 minecraft:blackstone
setblock 287 266 243 minecraft:tuff
fill 287 266 254 298 266 254 minecraft:basalt
setblock 287 266 256 minecraft:tuff
fill 287 266 266 291 267 266 minecraft:blackstone
setblock 287 266 269 minecraft:tuff
fill 288 266 230 299 266 230 minecraft:blackstone
setblock 288 266 232 minecraft:tuff
fill 288 266 233 294 267 233 minecraft:blackstone
fill 288 266 242 292 266 243 minecraft:blackstone
setblock 288 266 245 minecraft:tuff
fill 288 266 246 294 267 246 minecraft:blackstone
fill 288 266 255 292 266 256 minecraft:blackstone
setblock 288 266 258 minecraft:tuff
fill 288 266 269 299 266 269 minecraft:basalt
setblock 289 266 234 minecraft:tuff
setblock 289 266 247 minecraft:tuff
fill 289 266 248 295 267 248 minecraft:blackstone
fill 289 266 257 293 266 258 minecraft:blackstone
setblock 289 266 260 minecraft:tuff
fill 289 266 261 295 267 261 minecraft:blackstone
fill 290 266 234 301 266 234 minecraft:basalt
fill 290 266 235 295 266 235 minecraft:blackstone
setblock 290 266 236 minecraft:tuff
fill 290 266 247 295 266 247 minecraft:blackstone
setblock 290 266 249 minecraft:tuff
setblock 290 266 262 minecraft:tuff
fill 290 266 263 296 267 263 minecraft:blackstone
fill 291 266 236 302 266 236 minecraft:blackstone
setblock 291 266 238 minecraft:tuff
fill 291 266 249 296 266 249 minecraft:basalt
fill 291 266 250 296 266 250 minecraft:blackstone
setblock 291 266 251 minecraft:tuff
setblock 291 266 264 minecraft:tuff
fill 292 266 237 296 266 238 minecraft:blackstone
setblock 292 266 240 minecraft:tuff
fill 292 266 251 297 266 251 minecraft:blackstone
setblock 292 266 253 minecraft:tuff
fill 292 266 264 303 266 264 minecraft:basalt
setblock 292 266 266 minecraft:tuff
setblock 293 266 229 minecraft:tuff
fill 293 266 240 304 266 240 minecraft:blackstone
setblock 293 266 242 minecraft:tuff
fill 293 266 243 297 266 243 minecraft:blackstone
fill 293 266 252 297 266 253 minecraft:blackstone
setblock 293 266 255 minecraft:tuff
fill 293 266 256 299 267 256 minecraft:blackstone
fill 293 266 265 297 266 266 minecraft:blackstone
setblock 293 266 268 minecraft:tuff
fill 293 266 270 293 280 270 minecraft:blackstone
fill 294 266 229 305 266 229 minecraft:basalt
setblock 294 266 231 minecraft:tuff
fill 294 266 242 298 266 242 minecraft:blackstone
setblock 294 266 244 minecraft:tuff
setblock 294 266 257 minecraft:tuff
fill 294 266 258 300 267 258 minecraft:blackstone
fill 294 266 267 298 266 268 minecraft:blackstone
fill 295 266 231 306 266 231 minecraft:blackstone
setblock 295 266 233 minecraft:tuff
fill 295 266 244 296 266 244 minecraft:basalt
setblock 295 266 246 minecraft:tuff
setblock 295 266 259 minecraft:tuff
fill 295 266 270 295 283 270 minecraft:blackstone
fill 296 266 232 300 266 233 minecraft:blackstone
setblock 296 266 235 minecraft:tuff
setblock 296 266 245 minecraft:blackstone
fill 296 266 246 296 267 248 minecraft:netherrack
fill 296 266 259 307 266 259 minecraft:basalt
setblock 296 266 261 minecraft:tuff
fill 297 266 235 308 266 235 minecraft:blackstone
setblock 297 266 237 minecraft:tuff
fill 297 266 238 303 267 238 minecraft:blackstone
setblock 297 266 244 minecraft:netherrack
setblock 297 266 250 minecraft:netherrack
fill 297 266 260 301 266 261 minecraft:blackstone
setblock 297 266 263 minecraft:tuff
setblock 298 266 239 minecraft:tuff
setblock 298 266 243 minecraft:netherrack
setblock 298 266 251 minecraft:netherrack
setblock 298 266 252 minecraft:tuff
fill 298 266 253 300 266 253 minecraft:blackstone
fill 298 266 262 302 266 263 minecraft:blackstone
setblock 298 266 265 minecraft:tuff
fill 298 266 266 304 267 266 minecraft:blackstone
fill 299 266 239 310 266 239 minecraft:basalt
setblock 299 266 241 minecraft:tuff
fill 299 266 242 300 266 242 minecraft:netherrack
fill 299 266 252 300 266 252 minecraft:netherrack
setblock 299 266 254 minecraft:tuff
setblock 299 266 267 minecraft:tuff
fill 299 266 268 305 267 268 minecraft:blackstone
setblock 300 266 230 minecraft:tuff
setblock 300 266 241 minecraft:blackstone
fill 300 266 254 311 266 254 minecraft:basalt
setblock 300 266 256 minecraft:tuff
setblock 300 266 269 minecraft:tuff
fill 301 266 230 312 266 230 minecraft:blackstone
setblock 301 266 232 minecraft:tuff
fill 301 266 233 307 267 233 minecraft:blackstone
fill 301 266 241 301 267 241 minecraft:netherrack
fill 301 266 253 301 267 253 minecraft:netherrack
fill 301 266 255 305 266 256 minecraft:blackstone
setblock 301 266 258 minecraft:tuff
fill 301 266 269 312 266 269 minecraft:basalt
setblock 302 266 234 minecraft:tuff
fill 302 266 241 302 267 241 minecraft:shroomlight
fill 302 266 253 302 267 253 minecraft:shroomlight
fill 302 266 257 306 266 258 minecraft:blackstone
setblock 302 266 260 minecraft:tuff
fill 302 266 261 308 267 261 minecraft:blackstone
fill 303 266 234 314 266 234 minecraft:basalt
setblock 303 266 236 minecraft:tuff
fill 303 266 241 303 267 241 minecraft:netherrack
fill 303 266 253 303 267 253 minecraft:netherrack
setblock 303 266 262 minecraft:tuff
fill 303 266 263 309 267 263 minecraft:blackstone
fill 304 266 236 315 266 236 minecraft:blackstone
setblock 304 266 238 minecraft:tuff
fill 304 266 241 311 266 241 minecraft:blackstone
fill 304 266 242 305 266 242 minecraft:netherrack
fill 304 266 252 305 266 252 minecraft:netherrack
setblock 304 266 253 minecraft:blackstone
setblock 304 266 264 minecraft:tuff
fill 305 266 237 309 266 238 minecraft:blackstone
setblock 305 266 240 minecraft:tuff
setblock 305 266 253 minecraft:tuff
fill 305 266 264 316 266 264 minecraft:basalt
setblock 305 266 266 minecraft:tuff
setblock 306 266 229 minecraft:tuff
fill 306 266 240 317 266 240 minecraft:blackstone
setblock 306 266 242 minecraft:tuff
setblock 306 266 243 minecraft:netherrack
setblock 306 266 251 minecraft:netherrack
fill 306 266 252 310 266 253 minecraft:blackstone
setblock 306 266 255 minecraft:tuff
fill 306 266 256 312 267 256 minecraft:blackstone
fill 306 266 265 310 266 266 minecraft:blackstone
setblock 306 266 268 minecraft:tuff
fill 307 266 229 318 266 229 minecraft:basalt
setblock 307 266 231 minecraft:tuff
fill 307 266 242 312 266 243 minecraft:blackstone
setblock 307 266 244 minecraft:netherrack
setblock 307 266 250 minecraft:netherrack
fill 307 266 251 316 266 251 minecraft:blackstone
setblock 307 266 257 minecraft:tuff
fill 307 266 258 313 267 258 minecraft:blackstone
fill 307 266 267 311 266 268 minecraft:blackstone
fill 308 266 231 319 266 231 minecraft:blackstone
setblock 308 266 233 minecraft:tuff
fill 308 266 244 319 266 244 minecraft:basalt
fill 308 266 245 313 266 245 minecraft:blackstone
fill 308 266 246 308 267 248 minecraft:netherrack
fill 308 266 249 315 266 249 minecraft:basalt
fill 308 266 250 309 266 250 minecraft:blackstone
setblock 308 266 259 minecraft:tuff
fill 309 266 232 313 266 233 minecraft:blackstone
setblock 309 266 235 minecraft:tuff
setblock 309 266 248 minecraft:tuff
fill 309 266 259 320 266 259 minecraft:basalt
setblock 309 266 261 minecraft:tuff
fill 310 266 235 317 266 235 minecraft:blackstone
setblock 310 266 237 minecraft:tuff
fill 310 266 238 316 267 238 minecraft:blackstone
fill 310 266 246 314 266 248 minecraft:blackstone
setblock 310 266 250 minecraft:tuff
fill 310 266 260 314 266 261 minecraft:blackstone
setblock 310 266 263 minecraft:tuff
setblock 311 266 239 minecraft:tuff
fill 311 266 250 319 266 250 minecraft:blackstone
setblock 311 266 252 minecraft:tuff
fill 311 266 253 317 267 253 minecraft:blackstone
fill 311 266 262 315 266 263 minecraft:blackstone
setblock 311 266 265 minecraft:tuff
fill 311 266 266 317 267 266 minecraft:blackstone
fill 312 266 239 323 266 239 minecraft:basalt
setblock 312 266 241 minecraft:tuff
fill 312 266 252 319 266 252 minecraft:blackstone
setblock 312 266 254 minecraft:tuff
setblock 312 266 267 minecraft:tuff
fill 312 266 268 318 267 268 minecraft:blackstone
setblock 313 266 230 minecraft:tuff
fill 313 266 241 318 266 242 minecraft:blackstone
setblock 313 266 243 minecraft:tuff
fill 313 266 254 323 266 254 minecraft:basalt
setblock 313 266 256 minecraft:tuff
setblock 313 266 269 minecraft:tuff
fill 314 266 230 321 266 230 minecraft:blackstone
setblock 314 266 232 minecraft:tuff
fill 314 266 233 320 267 233 minecraft:blackstone
fill 314 266 243 323 266 243 minecraft:blackstone
setblock 314 266 245 minecraft:tuff
fill 314 266 255 318 266 256 minecraft:blackstone
setblock 314 266 258 minecraft:tuff
fill 314 266 269 323 266 269 minecraft:basalt
setblock 315 266 234 minecraft:tuff
fill 315 266 245 319 266 246 minecraft:blackstone
setblock 315 266 247 minecraft:tuff
fill 315 266 248 321 267 248 minecraft:blackstone
fill 315 266 257 319 266 258 minecraft:blackstone
setblock 315 266 260 minecraft:tuff
fill 315 266 261 321 267 261 minecraft:blackstone
fill 316 266 234 323 266 234 minecraft:basalt
setblock 316 266 236 minecraft:tuff
fill 316 266 247 323 266 247 minecraft:blackstone
setblock 316 266 249 minecraft:tuff
setblock 316 266 262 minecraft:tuff
fill 316 266 263 322 267 263 minecraft:blackstone
fill 317 266 236 318 267 236 minecraft:blackstone
setblock 317 266 238 minecraft:tuff
fill 317 266 249 323 266 249 minecraft:basalt
setblock 317 266 251 minecraft:tuff
setblock 317 266 264 minecraft:tuff
fill 318 266 237 318 268 238 minecraft:blackstone
setblock 318 266 240 minecraft:tuff
fill 318 266 251 320 267 251 minecraft:blackstone
setblock 318 266 253 minecraft:tuff
fill 318 266 264 323 266 264 minecraft:basalt
setblock 318 266 266 minecraft:tuff
setblock 319 266 229 minecraft:tuff
fill 319 266 238 323 266 238 minecraft:blackstone
fill 319 266 240 320 266 241 minecraft:blackstone
setblock 319 266 242 minecraft:tuff
fill 319 266 253 323 266 253 minecraft:blackstone
setblock 319 266 255 minecraft:tuff
fill 319 266 256 321 267 256 minecraft:blackstone
fill 319 266 265 320 266 266 minecraft:blackstone
setblock 319 266 268 minecraft:tuff
fill 320 266 229 323 266 229 minecraft:basalt
setblock 320 266 231 minecraft:tuff
fill 320 266 237 322 267 237 minecraft:blackstone
setblock 320 266 244 minecraft:tuff
fill 320 266 246 320 267 246 minecraft:blackstone
fill 320 266 255 322 266 255 minecraft:blackstone
setblock 320 266 257 minecraft:tuff
fill 320 266 258 323 269 258 minecraft:blackstone
fill 320 266 267 320 268 268 minecraft:blackstone
fill 321 266 231 323 267 231 minecraft:blackstone
setblock 321 266 233 minecraft:tuff
setblock 321 266 235 minecraft:blackstone
setblock 321 266 240 minecraft:blackstone
fill 321 266 244 323 266 244 minecraft:basalt
setblock 321 266 246 minecraft:tuff
setblock 321 266 259 minecraft:tuff
fill 321 266 268 323 268 268 minecraft:blackstone
fill 322 266 232 322 268 233 minecraft:blackstone
setblock 322 266 235 minecraft:tuff
fill 322 266 245 323 266 246 minecraft:blackstone
setblock 322 266 248 minecraft:tuff
setblock 322 266 250 minecraft:blackstone
fill 322 266 259 323 266 259 minecraft:basalt
setblock 322 266 261 minecraft:tuff
fill 323 266 233 323 268 233 minecraft:blackstone
setblock 323 266 235 minecraft:blackstone
setblock 323 266 237 minecraft:tuff
fill 323 266 248 323 269 248 minecraft:blackstone
setblock 323 266 250 minecraft:tuff
fill 323 266 260 323 266 261 minecraft:blackstone
setblock 323 266 263 minecraft:tuff
fill 283 267 229 284 270 229 minecraft:blackstone
fill 283 267 230 291 267 230 minecraft:basalt
fill 283 267 232 286 267 234 minecraft:blackstone
fill 283 267 235 287 267 235 minecraft:basalt
fill 283 267 236 288 267 237 minecraft:blackstone
setblock 283 267 238 minecraft:tuff
fill 283 267 239 289 268 239 minecraft:blackstone
setblock 283 267 240 minecraft:basalt
fill 283 267 241 284 267 242 minecraft:blackstone
fill 283 267 244 285 268 244 minecraft:blackstone
fill 283 267 245 292 267 245 minecraft:basalt
fill 283 267 248 287 267 249 minecraft:blackstone
fill 283 267 250 288 267 250 minecraft:basalt
setblock 283 267 251 minecraft:tuff
fill 283 267 252 283 267 254 minecraft:blackstone
fill 283 267 255 284 267 255 minecraft:basalt
fill 283 267 256 285 267 257 minecraft:blackstone
fill 283 267 259 286 268 259 minecraft:blackstone
fill 283 267 260 293 267 260 minecraft:basalt
setblock 283 267 261 minecraft:blackstone
setblock 283 267 264 minecraft:tuff
fill 283 267 265 289 267 265 minecraft:basalt
fill 283 267 266 283 267 269 minecraft:blackstone
fill 284 267 231 285 267 231 minecraft:blackstone
setblock 284 267 240 minecraft:tuff
fill 284 267 246 286 267 247 minecraft:blackstone
fill 284 267 251 289 267 252 minecraft:blackstone
setblock 284 267 253 minecraft:tuff
fill 284 267 254 290 268 254 minecraft:blackstone
fill 284 267 263 288 267 264 minecraft:blackstone
setblock 284 267 266 minecraft:tuff
fill 284 267 267 284 267 269 minecraft:blackstone
setblock 285 267 229 minecraft:tuff
fill 285 267 240 296 267 240 minecraft:basalt
fill 285 267 241 290 267 241 minecraft:blackstone
setblock 285 267 242 minecraft:tuff
setblock 285 267 255 minecraft:tuff
fill 285 267 261 287 267 262 minecraft:blackstone
fill 285 267 266 286 267 267 minecraft:blackstone
setblock 285 267 268 minecraft:tuff
fill 285 267 269 291 268 269 minecraft:blackstone
fill 286 267 229 297 267 229 minecraft:blackstone
setblock 286 267 231 minecraft:tuff
fill 286 267 242 297 267 242 minecraft:blackstone
setblock 286 267 244 minecraft:tuff
fill 286 267 255 297 267 255 minecraft:basalt
setblock 286 267 257 minecraft:tuff
fill 287 267 231 292 267 232 minecraft:blackstone
setblock 287 267 233 minecraft:tuff
fill 287 267 234 293 268 234 minecraft:blackstone
fill 287 267 243 291 267 244 minecraft:blackstone
setblock 287 267 246 minecraft:tuff
fill 287 267 247 293 268 247 minecraft:blackstone
fill 287 267 256 291 267 257 minecraft:blackstone
setblock 287 267 259 minecraft:tuff
fill 287 267 267 290 268 267 minecraft:blackstone
setblock 288 267 235 minecraft:tuff
setblock 288 267 248 minecraft:tuff
fill 288 267 249 294 268 249 minecraft:blackstone
fill 288 267 258 292 267 259 minecraft:blackstone
setblock 288 267 261 minecraft:tuff
fill 288 267 262 294 268 262 minecraft:blackstone
fill 289 267 235 300 267 235 minecraft:basalt
fill 289 267 236 294 267 236 minecraft:blackstone
setblock 289 267 237 minecraft:tuff
setblock 289 267 250 minecraft:tuff
setblock 289 267 263 minecraft:tuff
fill 289 267 264 295 268 264 minecraft:blackstone
fill 290 267 237 301 267 237 minecraft:blackstone
setblock 290 267 239 minecraft:tuff
fill 290 267 250 295 267 250 minecraft:basalt
fill 290 267 251 295 267 251 minecraft:blackstone
setblock 290 267 252 minecraft:tuff
setblock 290 267 265 minecraft:tuff
fill 291 267 238 295 267 239 minecraft:blackstone
setblock 291 267 241 minecraft:tuff
fill 291 267 252 297 267 252 minecraft:blackstone
setblock 291 267 254 minecraft:tuff
fill 291 267 265 302 267 265 minecraft:basalt
setblock 291 267 267 minecraft:tuff
setblock 292 267 230 minecraft:tuff
fill 292 267 241 298 267 241 minecraft:blackstone
setblock 292 267 243 minecraft:tuff
fill 292 267 244 295 268 244 minecraft:blackstone
fill 292 267 253 296 267 254 minecraft:blackstone
setblock 292 267 256 minecraft:tuff
fill 292 267 257 298 268 257 minecraft:blackstone
fill 292 267 266 296 267 267 minecraft:blackstone
setblock 292 267 269 minecraft:tuff
fill 293 267 230 304 267 230 minecraft:basalt
fill 293 267 231 298 267 231 minecraft:blackstone
setblock 293 267 232 minecraft:tuff
fill 293 267 243 296 267 243 minecraft:blackstone
setblock 293 267 245 minecraft:tuff
setblock 293 267 258 minecraft:tuff
fill 293 267 259 299 268 259 minecraft:blackstone
fill 293 267 268 297 267 269 minecraft:blackstone
fill 294 267 232 305 267 232 minecraft:blackstone
setblock 294 267 234 minecraft:tuff
fill 294 267 245 295 267 245 minecraft:basalt
setblock 294 267 247 minecraft:tuff
setblock 294 267 260 minecraft:tuff
fill 295 267 233 299 267 234 minecraft:blackstone
setblock 295 267 236 minecraft:tuff
fill 295 267 246 295 267 247 minecraft:blackstone
setblock 295 267 249 minecraft:tuff
fill 295 267 260 306 267 260 minecraft:basalt
setblock 295 267 262 minecraft:tuff
fill 296 267 236 307 267 236 minecraft:blackstone
setblock 296 267 238 minecraft:tuff
fill 296 267 239 302 268 239 minecraft:blackstone
fill 296 267 244 296 267 245 minecraft:netherrack
fill 296 267 249 296 267 250 minecraft:netherrack
setblock 296 267 251 minecraft:tuff
fill 296 267 261 300 267 262 minecraft:blackstone
setblock 296 267 264 minecraft:tuff
setblock 297 267 240 minecraft:tuff
setblock 297 267 243 minecraft:shroomlight
setblock 297 267 251 minecraft:shroomlight
setblock 297 267 253 minecraft:tuff
fill 297 267 254 303 267 254 minecraft:blackstone
fill 297 267 263 301 267 264 minecraft:blackstone
setblock 297 267 266 minecraft:tuff
fill 297 267 267 303 268 267 minecraft:blackstone
setblock 298 267 229 minecraft:tuff
fill 298 267 240 309 267 240 minecraft:basalt
setblock 298 267 242 minecraft:netherrack
setblock 298 267 252 minecraft:netherrack
setblock 298 267 253 minecraft:blackstone
setblock 298 267 255 minecraft:tuff
setblock 298 267 268 minecraft:tuff
fill 298 267 269 304 268 269 minecraft:blackstone
fill 299 267 229 310 267 229 minecraft:blackstone
setblock 299 267 231 minecraft:tuff
fill 299 267 241 299 268 241 minecraft:shroomlight
setblock 299 267 245 minecraft:light[level=12]
setblock 299 267 252 minecraft:light[level=12]
fill 299 267 253 299 268 253 minecraft:shroomlight
fill 299 267 255 310 267 255 minecraft:basalt
setblock 299 267 257 minecraft:tuff
fill 300 267 231 311 267 231 minecraft:blackstone
setblock 300 267 233 minecraft:tuff
fill 300 267 234 306 268 234 minecraft:blackstone
setblock 300 267 241 minecraft:netherrack
setblock 300 267 253 minecraft:netherrack
fill 300 267 256 304 267 257 minecraft:blackstone
setblock 300 267 259 minecraft:tuff
setblock 301 267 235 minecraft:tuff
fill 301 267 258 305 267 259 minecraft:blackstone
setblock 301 267 261 minecraft:tuff
fill 301 267 262 307 268 262 minecraft:blackstone
fill 302 267 235 313 267 235 minecraft:basalt
setblock 302 267 237 minecraft:tuff
setblock 302 267 263 minecraft:tuff
fill 302 267 264 308 268 264 minecraft:blackstone
fill 303 267 237 314 267 237 minecraft:blackstone
setblock 303 267 239 minecraft:tuff
setblock 303 267 265 minecraft:tuff
fill 304 267 238 308 267 239 minecraft:blackstone
setblock 304 267 241 minecraft:netherrack
setblock 304 267 253 minecraft:netherrack
setblock 304 267 254 minecraft:tuff
fill 304 267 265 315 267 265 minecraft:basalt
setblock 304 267 267 minecraft:tuff
setblock 305 267 230 minecraft:tuff
fill 305 267 241 305 268 241 minecraft:shroomlight
fill 305 267 253 305 268 253 minecraft:shroomlight
fill 305 267 254 316 267 254 minecraft:blackstone
setblock 305 267 256 minecraft:tuff
fill 305 267 257 311 268 257 minecraft:blackstone
fill 305 267 266 309 267 267 minecraft:blackstone
setblock 305 267 269 minecraft:tuff
fill 306 267 230 317 267 230 minecraft:basalt
setblock 306 267 232 minecraft:tuff
fill 306 267 241 316 267 241 minecraft:blackstone
setblock 306 267 242 minecraft:netherrack
setblock 306 267 245 minecraft:light[level=12]
setblock 306 267 252 minecraft:netherrack
fill 306 267 253 309 267 253 minecraft:blackstone
setblock 306 267 258 minecraft:tuff
fill 306 267 259 312 268 259 minecraft:blackstone
fill 306 267 268 310 267 269 minecraft:blackstone
fill 307 267 232 318 267 232 minecraft:blackstone
setblock 307 267 234 minecraft:tuff
fill 307 267 242 310 267 242 minecraft:blackstone
setblock 307 267 243 minecraft:shroomlight
setblock 307 267 251 minecraft:shroomlight
fill 307 267 252 315 267 252 minecraft:blackstone
setblock 307 267 260 minecraft:tuff
fill 308 267 233 312 267 234 minecraft:blackstone
setblock 308 267 236 minecraft:tuff
fill 308 267 243 317 267 243 minecraft:blackstone
fill 308 267 244 308 267 245 minecraft:netherrack
fill 308 267 249 308 267 250 minecraft:netherrack
setblock 308 267 251 minecraft:blackstone
fill 308 267 260 319 267 260 minecraft:basalt
setblock 308 267 262 minecraft:tuff
fill 309 267 236 316 267 236 minecraft:blackstone
setblock 309 267 238 minecraft:tuff
fill 309 267 239 315 268 239 minecraft:blackstone
fill 309 267 244 311 268 244 minecraft:blackstone
fill 309 267 245 318 267 245 minecraft:basalt
fill 309 267 248 313 267 249 minecraft:blackstone
fill 309 267 250 314 267 250 minecraft:basalt
setblock 309 267 251 minecraft:tuff
fill 309 267 261 313 267 262 minecraft:blackstone
setblock 309 267 264 minecraft:tuff
setblock 310 267 240 minecraft:tuff
fill 310 267 246 312 267 247 minecraft:blackstone
fill 310 267 251 317 267 251 minecraft:blackstone
setblock 310 267 253 minecraft:tuff
fill 310 267 263 314 267 264 minecraft:blackstone
setblock 310 267 266 minecraft:tuff
fill 310 267 267 316 268 267 minecraft:blackstone
setblock 311 267 229 minecraft:tuff
fill 311 267 240 322 267 240 minecraft:basalt
setblock 311 267 242 minecraft:tuff
setblock 311 267 255 minecraft:tuff
setblock 311 267 268 minecraft:tuff
fill 311 267 269 317 268 269 minecraft:blackstone
fill 312 267 229 323 267 229 minecraft:blackstone
setblock 312 267 231 minecraft:tuff
schedule function dropper:buildpart/54_4 1t
