fill 424 35 502 424 36 504 minecraft:blackstone
setblock 425 35 464 minecraft:blackstone
setblock 425 35 465 minecraft:polished_blackstone_bricks
setblock 425 35 475 minecraft:polished_blackstone_bricks
fill 425 35 476 425 38 476 minecraft:blackstone
setblock 425 35 480 minecraft:polished_blackstone_bricks
fill 425 35 481 425 38 481 minecraft:blackstone
setblock 425 35 485 minecraft:polished_blackstone_bricks
fill 425 35 486 425 38 486 minecraft:blackstone
setblock 425 35 500 minecraft:polished_blackstone_bricks
fill 425 35 501 425 36 501 minecraft:blackstone
fill 425 35 503 425 35 504 minecraft:blackstone
setblock 426 35 464 minecraft:polished_blackstone_bricks
fill 426 35 465 426 38 465 minecraft:blackstone
setblock 426 35 475 minecraft:blackstone
setblock 426 35 479 minecraft:polished_blackstone_bricks
fill 426 35 480 426 38 480 minecraft:blackstone
setblock 426 35 484 minecraft:polished_blackstone_bricks
fill 426 35 485 426 38 485 minecraft:blackstone
setblock 426 35 503 minecraft:blackstone
setblock 426 35 504 minecraft:polished_blackstone_bricks
fill 427 35 464 427 38 464 minecraft:blackstone
setblock 427 35 478 minecraft:polished_blackstone_bricks
fill 427 35 479 427 36 479 minecraft:blackstone
setblock 427 35 483 minecraft:polished_blackstone_bricks
fill 427 35 484 427 37 484 minecraft:blackstone
setblock 427 35 503 minecraft:polished_blackstone_bricks
fill 427 35 504 427 38 504 minecraft:blackstone
fill 428 35 503 428 37 503 minecraft:blackstone
setblock 430 35 465 minecraft:polished_blackstone_bricks
setblock 431 35 464 minecraft:polished_blackstone_bricks
fill 431 35 465 431 38 465 minecraft:blackstone
setblock 431 35 504 minecraft:polished_blackstone_bricks
fill 432 35 464 435 35 464 minecraft:blackstone
setblock 432 35 503 minecraft:polished_blackstone_bricks
fill 432 35 504 432 38 504 minecraft:blackstone
setblock 436 35 464 minecraft:polished_blackstone_bricks
setblock 436 35 504 minecraft:polished_blackstone_bricks
fill 437 35 464 437 38 464 minecraft:blackstone
fill 437 35 504 437 38 504 minecraft:blackstone
fill 440 35 503 441 35 503 minecraft:blackstone
setblock 441 35 464 minecraft:polished_blackstone_bricks
fill 441 35 465 441 38 465 minecraft:blackstone
setblock 441 35 504 minecraft:polished_blackstone_bricks
fill 442 35 464 442 38 464 minecraft:blackstone
setblock 442 35 503 minecraft:polished_blackstone_bricks
fill 442 35 504 442 38 504 minecraft:blackstone
setblock 443 35 502 minecraft:polished_blackstone_bricks
fill 443 35 503 443 38 503 minecraft:blackstone
fill 444 35 502 444 38 502 minecraft:blackstone
setblock 445 35 465 minecraft:polished_blackstone_bricks
setblock 446 35 464 minecraft:polished_blackstone_bricks
fill 446 35 465 446 38 465 minecraft:blackstone
setblock 446 35 504 minecraft:polished_blackstone_bricks
fill 447 35 464 447 38 464 minecraft:blackstone
setblock 447 35 503 minecraft:polished_blackstone_bricks
fill 447 35 504 447 38 504 minecraft:blackstone
setblock 448 35 502 minecraft:polished_blackstone_bricks
fill 448 35 503 448 38 503 minecraft:blackstone
setblock 449 35 501 minecraft:polished_blackstone_bricks
fill 449 35 502 449 38 502 minecraft:blackstone
setblock 450 35 465 minecraft:polished_blackstone_bricks
fill 450 35 501 450 36 501 minecraft:blackstone
setblock 451 35 464 minecraft:polished_blackstone_bricks
fill 451 35 465 451 37 465 minecraft:blackstone
setblock 451 35 504 minecraft:polished_blackstone_bricks
fill 452 35 464 452 38 464 minecraft:blackstone
setblock 452 35 503 minecraft:polished_blackstone_bricks
fill 452 35 504 452 38 504 minecraft:blackstone
setblock 453 35 502 minecraft:polished_blackstone_bricks
fill 453 35 503 453 38 503 minecraft:blackstone
setblock 454 35 502 minecraft:blackstone
setblock 456 35 504 minecraft:polished_blackstone_bricks
setblock 457 35 503 minecraft:polished_blackstone_bricks
fill 457 35 504 457 38 504 minecraft:blackstone
fill 458 35 503 458 36 503 minecraft:blackstone
setblock 461 35 504 minecraft:polished_blackstone_bricks
setblock 462 35 503 minecraft:polished_blackstone_bricks
fill 462 35 504 462 38 504 minecraft:blackstone
fill 463 35 478 463 36 478 minecraft:blackstone
setblock 463 35 482 minecraft:polished_blackstone_bricks
fill 463 35 483 463 38 483 minecraft:blackstone
fill 463 35 485 463 35 486 minecraft:blackstone
setblock 463 35 487 minecraft:polished_blackstone_bricks
fill 463 35 488 463 37 489 minecraft:blackstone
setblock 463 35 497 minecraft:polished_blackstone_bricks
fill 463 35 498 463 36 498 minecraft:blackstone
setblock 463 35 502 minecraft:polished_blackstone_bricks
fill 463 35 503 463 38 503 minecraft:blackstone
setblock 464 35 475 minecraft:blackstone
setblock 464 35 476 minecraft:polished_blackstone_bricks
fill 464 35 477 464 38 477 minecraft:blackstone
setblock 464 35 481 minecraft:polished_blackstone_bricks
fill 464 35 482 464 38 482 minecraft:blackstone
setblock 464 35 486 minecraft:polished_blackstone_bricks
fill 464 35 487 464 38 487 minecraft:blackstone
setblock 464 35 491 minecraft:polished_blackstone_bricks
fill 464 35 492 464 38 492 minecraft:blackstone
setblock 464 35 496 minecraft:polished_blackstone_bricks
fill 464 35 497 464 38 497 minecraft:blackstone
setblock 464 35 501 minecraft:polished_blackstone_bricks
fill 464 35 502 464 38 502 minecraft:blackstone
setblock 424 36 464 minecraft:blackstone
setblock 424 36 465 minecraft:polished_blackstone_bricks
fill 424 36 466 424 36 469 minecraft:blackstone
setblock 424 36 470 minecraft:polished_blackstone_bricks
fill 424 36 471 424 39 471 minecraft:blackstone
setblock 424 36 475 minecraft:polished_blackstone_bricks
fill 424 36 476 424 39 476 minecraft:blackstone
setblock 424 36 480 minecraft:polished_blackstone_bricks
fill 424 36 481 424 39 481 minecraft:blackstone
setblock 424 36 485 minecraft:polished_blackstone_bricks
fill 424 36 486 424 39 486 minecraft:blackstone
setblock 424 36 490 minecraft:polished_blackstone_bricks
fill 424 36 491 424 39 491 minecraft:blackstone
setblock 424 36 496 minecraft:blackstone
setblock 424 36 499 minecraft:blackstone
setblock 424 36 500 minecraft:polished_blackstone_bricks
fill 424 36 501 424 39 501 minecraft:blackstone
setblock 425 36 464 minecraft:polished_blackstone_bricks
fill 425 36 465 425 38 466 minecraft:blackstone
setblock 425 36 474 minecraft:polished_blackstone_bricks
fill 425 36 475 425 39 475 minecraft:blackstone
setblock 425 36 479 minecraft:polished_blackstone_bricks
fill 425 36 480 425 39 480 minecraft:blackstone
setblock 425 36 484 minecraft:polished_blackstone_bricks
fill 425 36 485 425 39 485 minecraft:blackstone
setblock 425 36 489 minecraft:polished_blackstone_bricks
setblock 425 36 503 minecraft:blackstone
setblock 425 36 504 minecraft:polished_blackstone_bricks
fill 426 36 464 426 39 464 minecraft:blackstone
setblock 426 36 478 minecraft:polished_blackstone_bricks
fill 426 36 479 426 39 479 minecraft:blackstone
setblock 426 36 483 minecraft:polished_blackstone_bricks
fill 426 36 484 426 39 484 minecraft:blackstone
setblock 426 36 503 minecraft:polished_blackstone_bricks
fill 426 36 504 426 39 504 minecraft:blackstone
setblock 427 36 478 minecraft:blackstone
setblock 427 36 482 minecraft:polished_blackstone_bricks
fill 427 36 483 427 37 483 minecraft:blackstone
fill 427 36 503 427 37 503 minecraft:blackstone
setblock 429 36 465 minecraft:polished_blackstone_bricks
setblock 430 36 464 minecraft:polished_blackstone_bricks
fill 430 36 465 430 39 465 minecraft:blackstone
setblock 430 36 504 minecraft:polished_blackstone_bricks
fill 431 36 464 434 36 464 minecraft:blackstone
setblock 431 36 503 minecraft:polished_blackstone_bricks
fill 431 36 504 431 39 504 minecraft:blackstone
setblock 435 36 464 minecraft:polished_blackstone_bricks
setblock 435 36 504 minecraft:polished_blackstone_bricks
fill 436 36 464 436 39 464 minecraft:blackstone
fill 436 36 504 436 39 504 minecraft:blackstone
setblock 440 36 464 minecraft:polished_blackstone_bricks
fill 440 36 465 440 39 465 minecraft:blackstone
setblock 440 36 503 minecraft:blackstone
setblock 440 36 504 minecraft:polished_blackstone_bricks
fill 441 36 464 441 39 464 minecraft:blackstone
setblock 441 36 503 minecraft:polished_blackstone_bricks
fill 441 36 504 441 39 504 minecraft:blackstone
fill 442 36 503 442 39 503 minecraft:blackstone
fill 443 36 502 443 39 502 minecraft:blackstone
setblock 444 36 465 minecraft:polished_blackstone_bricks
setblock 445 36 464 minecraft:polished_blackstone_bricks
fill 445 36 465 445 39 465 minecraft:blackstone
setblock 445 36 504 minecraft:polished_blackstone_bricks
fill 446 36 464 446 39 464 minecraft:blackstone
setblock 446 36 503 minecraft:polished_blackstone_bricks
fill 446 36 504 446 39 504 minecraft:blackstone
setblock 447 36 502 minecraft:polished_blackstone_bricks
fill 447 36 503 447 39 503 minecraft:blackstone
setblock 448 36 501 minecraft:polished_blackstone_bricks
fill 448 36 502 448 39 502 minecraft:blackstone
setblock 449 36 465 minecraft:polished_blackstone_bricks
setblock 449 36 501 minecraft:blackstone
setblock 450 36 464 minecraft:polished_blackstone_bricks
fill 450 36 465 450 39 465 minecraft:blackstone
setblock 450 36 504 minecraft:polished_blackstone_bricks
fill 451 36 464 451 39 464 minecraft:blackstone
setblock 451 36 503 minecraft:polished_blackstone_bricks
fill 451 36 504 451 39 504 minecraft:blackstone
setblock 452 36 502 minecraft:polished_blackstone_bricks
fill 452 36 503 452 39 503 minecraft:blackstone
setblock 453 36 502 minecraft:blackstone
setblock 455 36 504 minecraft:polished_blackstone_bricks
setblock 456 36 503 minecraft:polished_blackstone_bricks
fill 456 36 504 456 39 504 minecraft:blackstone
setblock 457 36 503 minecraft:blackstone
setblock 460 36 504 minecraft:polished_blackstone_bricks
setblock 461 36 503 minecraft:polished_blackstone_bricks
fill 461 36 504 461 39 504 minecraft:blackstone
fill 462 36 503 462 38 503 minecraft:blackstone
fill 463 36 464 463 37 464 minecraft:blackstone
setblock 463 36 481 minecraft:polished_blackstone_bricks
fill 463 36 482 463 39 482 minecraft:blackstone
setblock 463 36 485 minecraft:blackstone
setblock 463 36 486 minecraft:polished_blackstone_bricks
fill 463 36 487 463 39 487 minecraft:blackstone
setblock 463 36 501 minecraft:polished_blackstone_bricks
fill 463 36 502 463 38 502 minecraft:blackstone
setblock 464 36 465 minecraft:polished_blackstone_bricks
setblock 464 36 475 minecraft:polished_blackstone_bricks
fill 464 36 476 464 39 476 minecraft:blackstone
setblock 464 36 480 minecraft:polished_blackstone_bricks
fill 464 36 481 464 39 481 minecraft:blackstone
setblock 464 36 485 minecraft:polished_blackstone_bricks
fill 464 36 486 464 39 486 minecraft:blackstone
setblock 464 36 490 minecraft:polished_blackstone_bricks
fill 464 36 491 464 39 491 minecraft:blackstone
setblock 464 36 495 minecraft:polished_blackstone_bricks
fill 464 36 496 464 39 496 minecraft:blackstone
setblock 464 36 500 minecraft:polished_blackstone_bricks
fill 464 36 501 464 39 501 minecraft:blackstone
setblock 424 37 464 minecraft:polished_blackstone_bricks
fill 424 37 465 424 37 468 minecraft:blackstone
setblock 424 37 469 minecraft:polished_blackstone_bricks
fill 424 37 470 424 40 470 minecraft:blackstone
setblock 424 37 474 minecraft:polished_blackstone_bricks
fill 424 37 475 424 40 475 minecraft:blackstone
setblock 424 37 479 minecraft:polished_blackstone_bricks
fill 424 37 480 424 40 480 minecraft:blackstone
setblock 424 37 484 minecraft:polished_blackstone_bricks
fill 424 37 485 424 40 485 minecraft:blackstone
setblock 424 37 489 minecraft:polished_blackstone_bricks
fill 424 37 490 424 40 490 minecraft:blackstone
setblock 424 37 499 minecraft:polished_blackstone_bricks
fill 424 37 500 424 38 500 minecraft:blackstone
fill 424 37 502 424 37 503 minecraft:blackstone
setblock 424 37 504 minecraft:polished_blackstone_bricks
fill 425 37 464 425 40 464 minecraft:blackstone
setblock 425 37 467 minecraft:blackstone
fill 425 37 474 425 40 474 minecraft:blackstone
setblock 425 37 478 minecraft:polished_blackstone_bricks
fill 425 37 479 425 40 479 minecraft:blackstone
setblock 425 37 483 minecraft:polished_blackstone_bricks
fill 425 37 484 425 40 484 minecraft:blackstone
setblock 425 37 488 minecraft:polished_blackstone_bricks
fill 425 37 489 425 40 489 minecraft:blackstone
setblock 425 37 503 minecraft:polished_blackstone_bricks
fill 425 37 504 425 40 504 minecraft:blackstone
setblock 426 37 477 minecraft:polished_blackstone_bricks
fill 426 37 478 426 38 478 minecraft:blackstone
setblock 426 37 482 minecraft:polished_blackstone_bricks
fill 426 37 483 426 40 483 minecraft:blackstone
setblock 426 37 487 minecraft:polished_blackstone_bricks
fill 426 37 503 426 38 503 minecraft:blackstone
setblock 427 37 481 minecraft:polished_blackstone_bricks
setblock 427 37 482 minecraft:blackstone
setblock 428 37 465 minecraft:polished_blackstone_bricks
setblock 429 37 464 minecraft:polished_blackstone_bricks
fill 429 37 465 429 40 465 minecraft:blackstone
setblock 429 37 504 minecraft:polished_blackstone_bricks
fill 430 37 464 433 37 464 minecraft:blackstone
fill 430 37 504 430 40 504 minecraft:blackstone
setblock 434 37 464 minecraft:polished_blackstone_bricks
setblock 434 37 504 minecraft:polished_blackstone_bricks
fill 435 37 464 435 40 464 minecraft:blackstone
fill 435 37 504 435 38 504 minecraft:blackstone
setblock 439 37 464 minecraft:polished_blackstone_bricks
fill 439 37 465 439 40 465 minecraft:blackstone
setblock 439 37 504 minecraft:polished_blackstone_bricks
fill 440 37 464 440 40 464 minecraft:blackstone
setblock 440 37 503 minecraft:polished_blackstone_bricks
fill 440 37 504 440 40 504 minecraft:blackstone
fill 441 37 503 441 40 503 minecraft:blackstone
setblock 443 37 465 minecraft:polished_blackstone_bricks
setblock 444 37 464 minecraft:polished_blackstone_bricks
fill 444 37 465 444 40 465 minecraft:blackstone
setblock 444 37 504 minecraft:polished_blackstone_bricks
fill 445 37 464 445 40 464 minecraft:blackstone
fill 445 37 466 445 38 466 minecraft:blackstone
setblock 445 37 503 minecraft:polished_blackstone_bricks
fill 445 37 504 445 40 504 minecraft:blackstone
setblock 446 37 502 minecraft:polished_blackstone_bricks
fill 446 37 503 446 40 503 minecraft:blackstone
fill 447 37 502 447 40 502 minecraft:blackstone
setblock 448 37 465 minecraft:polished_blackstone_bricks
setblock 449 37 464 minecraft:polished_blackstone_bricks
fill 449 37 465 449 40 465 minecraft:blackstone
setblock 449 37 504 minecraft:polished_blackstone_bricks
fill 450 37 464 450 40 464 minecraft:blackstone
setblock 450 37 503 minecraft:polished_blackstone_bricks
fill 450 37 504 450 40 504 minecraft:blackstone
setblock 451 37 502 minecraft:polished_blackstone_bricks
fill 451 37 503 451 40 503 minecraft:blackstone
setblock 452 37 502 minecraft:blackstone
setblock 454 37 464 minecraft:polished_blackstone_bricks
setblock 454 37 504 minecraft:polished_blackstone_bricks
setblock 455 37 503 minecraft:polished_blackstone_bricks
fill 455 37 504 455 40 504 minecraft:blackstone
setblock 459 37 504 minecraft:polished_blackstone_bricks
fill 460 37 504 460 40 504 minecraft:blackstone
setblock 461 37 503 minecraft:blackstone
fill 462 37 484 462 38 484 minecraft:blackstone
setblock 463 37 480 minecraft:polished_blackstone_bricks
fill 463 37 481 463 40 481 minecraft:blackstone
setblock 463 37 485 minecraft:polished_blackstone_bricks
fill 463 37 486 463 40 486 minecraft:blackstone
setblock 463 37 490 minecraft:polished_blackstone_bricks
setblock 463 37 500 minecraft:polished_blackstone_bricks
fill 463 37 501 463 38 501 minecraft:blackstone
setblock 464 37 464 minecraft:polished_blackstone_bricks
fill 464 37 465 464 40 465 minecraft:blackstone
setblock 464 37 475 minecraft:blackstone
setblock 464 37 479 minecraft:polished_blackstone_bricks
fill 464 37 480 464 40 480 minecraft:blackstone
setblock 464 37 484 minecraft:polished_blackstone_bricks
fill 464 37 485 464 40 485 minecraft:blackstone
setblock 464 37 489 minecraft:polished_blackstone_bricks
fill 464 37 490 464 40 490 minecraft:blackstone
setblock 464 37 494 minecraft:polished_blackstone_bricks
fill 464 37 495 464 40 495 minecraft:blackstone
setblock 464 37 499 minecraft:polished_blackstone_bricks
fill 464 37 500 464 40 500 minecraft:blackstone
setblock 464 37 504 minecraft:polished_blackstone_bricks
fill 424 38 464 424 38 467 minecraft:blackstone
setblock 424 38 468 minecraft:polished_blackstone_bricks
fill 424 38 469 424 41 469 minecraft:blackstone
setblock 424 38 473 minecraft:polished_blackstone_bricks
fill 424 38 474 424 41 474 minecraft:blackstone
setblock 424 38 478 minecraft:polished_blackstone_bricks
fill 424 38 479 424 41 479 minecraft:blackstone
setblock 424 38 483 minecraft:polished_blackstone_bricks
fill 424 38 484 424 41 484 minecraft:blackstone
setblock 424 38 488 minecraft:polished_blackstone_bricks
fill 424 38 489 424 41 489 minecraft:blackstone
setblock 424 38 502 minecraft:blackstone
setblock 424 38 503 minecraft:polished_blackstone_bricks
fill 424 38 504 424 41 504 minecraft:blackstone
setblock 425 38 467 minecraft:polished_blackstone_bricks
fill 425 38 468 425 41 468 minecraft:blackstone
setblock 425 38 477 minecraft:polished_blackstone_bricks
fill 425 38 478 425 41 478 minecraft:blackstone
setblock 425 38 482 minecraft:polished_blackstone_bricks
fill 425 38 483 425 41 483 minecraft:blackstone
setblock 425 38 487 minecraft:polished_blackstone_bricks
fill 425 38 488 425 41 488 minecraft:blackstone
setblock 426 38 466 minecraft:light[level=11]
setblock 426 38 474 minecraft:light[level=11]
setblock 426 38 481 minecraft:polished_blackstone_bricks
fill 426 38 482 426 41 482 minecraft:blackstone
setblock 426 38 486 minecraft:polished_blackstone_bricks
fill 426 38 487 426 41 487 minecraft:blackstone
setblock 426 38 490 minecraft:light[level=11]
setblock 426 38 498 minecraft:light[level=11]
setblock 427 38 465 minecraft:polished_blackstone_bricks
setblock 428 38 464 minecraft:polished_blackstone_bricks
fill 428 38 465 428 41 465 minecraft:blackstone
setblock 428 38 504 minecraft:polished_blackstone_bricks
fill 429 38 464 432 38 464 minecraft:blackstone
fill 429 38 504 429 41 504 minecraft:blackstone
setblock 432 38 465 minecraft:polished_blackstone_bricks
setblock 433 38 464 minecraft:polished_blackstone_bricks
setblock 433 38 504 minecraft:polished_blackstone_bricks
fill 434 38 464 434 41 464 minecraft:blackstone
setblock 434 38 466 minecraft:light[level=11]
setblock 434 38 474 minecraft:light[level=11]
setblock 434 38 482 minecraft:light[level=11]
setblock 434 38 490 minecraft:light[level=11]
setblock 434 38 498 minecraft:light[level=11]
setblock 434 38 504 minecraft:blackstone
setblock 438 38 464 minecraft:polished_blackstone_bricks
setblock 438 38 504 minecraft:polished_blackstone_bricks
fill 439 38 464 439 41 464 minecraft:blackstone
fill 439 38 504 439 41 504 minecraft:blackstone
fill 440 38 503 440 41 503 minecraft:blackstone
setblock 442 38 465 minecraft:polished_blackstone_bricks
setblock 442 38 466 minecraft:light[level=11]
setblock 442 38 474 minecraft:light[level=11]
setblock 442 38 482 minecraft:light[level=11]
setblock 442 38 490 minecraft:light[level=11]
setblock 442 38 498 minecraft:light[level=11]
setblock 443 38 464 minecraft:polished_blackstone_bricks
fill 443 38 465 443 41 465 minecraft:blackstone
setblock 443 38 504 minecraft:polished_blackstone_bricks
fill 444 38 464 444 41 464 minecraft:blackstone
fill 444 38 466 444 39 466 minecraft:blackstone
setblock 444 38 503 minecraft:polished_blackstone_bricks
fill 444 38 504 444 41 504 minecraft:blackstone
setblock 445 38 502 minecraft:polished_blackstone_bricks
fill 445 38 503 445 41 503 minecraft:blackstone
setblock 446 38 466 minecraft:polished_blackstone_bricks
fill 446 38 502 446 41 502 minecraft:blackstone
setblock 447 38 465 minecraft:polished_blackstone_bricks
setblock 448 38 464 minecraft:polished_blackstone_bricks
fill 448 38 465 448 41 465 minecraft:blackstone
setblock 448 38 504 minecraft:polished_blackstone_bricks
fill 449 38 464 449 41 464 minecraft:blackstone
setblock 449 38 503 minecraft:polished_blackstone_bricks
fill 449 38 504 449 41 504 minecraft:blackstone
setblock 450 38 466 minecraft:light[level=11]
setblock 450 38 474 minecraft:light[level=11]
setblock 450 38 482 minecraft:light[level=11]
setblock 450 38 490 minecraft:light[level=11]
setblock 450 38 498 minecraft:light[level=11]
setblock 450 38 502 minecraft:polished_blackstone_bricks
fill 450 38 503 450 41 503 minecraft:blackstone
setblock 453 38 464 minecraft:polished_blackstone_bricks
setblock 453 38 504 minecraft:polished_blackstone_bricks
setblock 454 38 503 minecraft:polished_blackstone_bricks
fill 454 38 504 454 41 504 minecraft:blackstone
setblock 458 38 466 minecraft:light[level=11]
setblock 458 38 474 minecraft:light[level=11]
setblock 458 38 482 minecraft:light[level=11]
setblock 458 38 490 minecraft:light[level=11]
setblock 458 38 498 minecraft:light[level=11]
setblock 458 38 504 minecraft:polished_blackstone_bricks
fill 459 38 504 459 41 504 minecraft:blackstone
setblock 462 38 464 minecraft:blackstone
fill 462 38 483 462 39 483 minecraft:blackstone
setblock 462 38 485 minecraft:polished_blackstone_bricks
fill 462 38 486 462 41 486 minecraft:blackstone
setblock 463 38 464 minecraft:polished_blackstone_bricks
setblock 463 38 479 minecraft:polished_blackstone_bricks
fill 463 38 480 463 41 480 minecraft:blackstone
setblock 463 38 484 minecraft:polished_blackstone_bricks
fill 463 38 485 463 41 485 minecraft:blackstone
setblock 463 38 488 minecraft:blackstone
setblock 463 38 489 minecraft:polished_blackstone_bricks
fill 463 38 490 463 40 491 minecraft:blackstone
setblock 463 38 504 minecraft:polished_blackstone_bricks
fill 464 38 464 464 41 464 minecraft:blackstone
fill 464 38 466 464 39 466 minecraft:blackstone
setblock 464 38 478 minecraft:polished_blackstone_bricks
fill 464 38 479 464 41 479 minecraft:blackstone
setblock 464 38 483 minecraft:polished_blackstone_bricks
fill 464 38 484 464 41 484 minecraft:blackstone
setblock 464 38 488 minecraft:polished_blackstone_bricks
fill 464 38 489 464 41 489 minecraft:blackstone
setblock 464 38 493 minecraft:polished_blackstone_bricks
fill 464 38 494 464 41 494 minecraft:blackstone
setblock 464 38 498 minecraft:polished_blackstone_bricks
fill 464 38 499 464 41 499 minecraft:blackstone
setblock 464 38 503 minecraft:polished_blackstone_bricks
fill 464 38 504 464 41 504 minecraft:blackstone
fill 424 39 464 424 39 466 minecraft:blackstone
setblock 424 39 467 minecraft:polished_blackstone_bricks
fill 424 39 468 424 42 468 minecraft:blackstone
setblock 424 39 472 minecraft:polished_blackstone_bricks
fill 424 39 473 424 42 473 minecraft:blackstone
setblock 424 39 477 minecraft:polished_blackstone_bricks
fill 424 39 478 424 42 478 minecraft:blackstone
setblock 424 39 482 minecraft:polished_blackstone_bricks
fill 424 39 483 424 42 483 minecraft:blackstone
setblock 424 39 487 minecraft:polished_blackstone_bricks
fill 424 39 488 424 42 488 minecraft:blackstone
setblock 424 39 492 minecraft:polished_blackstone_bricks
setblock 424 39 502 minecraft:polished_blackstone_bricks
fill 424 39 503 424 42 503 minecraft:blackstone
setblock 425 39 465 minecraft:blackstone
setblock 425 39 466 minecraft:polished_blackstone_bricks
fill 425 39 467 425 42 467 minecraft:blackstone
fill 425 39 469 425 39 470 minecraft:blackstone
setblock 425 39 476 minecraft:polished_blackstone_bricks
fill 425 39 477 425 42 477 minecraft:blackstone
setblock 425 39 481 minecraft:polished_blackstone_bricks
fill 425 39 482 425 42 482 minecraft:blackstone
setblock 425 39 486 minecraft:polished_blackstone_bricks
fill 425 39 487 425 42 487 minecraft:blackstone
setblock 426 39 465 minecraft:polished_blackstone_bricks
setblock 426 39 480 minecraft:polished_blackstone_bricks
fill 426 39 481 426 42 481 minecraft:blackstone
setblock 426 39 485 minecraft:polished_blackstone_bricks
fill 426 39 486 426 42 486 minecraft:blackstone
setblock 427 39 464 minecraft:polished_blackstone_bricks
fill 427 39 465 427 42 465 minecraft:blackstone
setblock 427 39 504 minecraft:polished_blackstone_bricks
fill 428 39 464 431 39 464 minecraft:blackstone
fill 428 39 504 428 42 504 minecraft:blackstone
setblock 431 39 465 minecraft:polished_blackstone_bricks
setblock 432 39 464 minecraft:polished_blackstone_bricks
fill 432 39 465 432 42 465 minecraft:blackstone
setblock 432 39 504 minecraft:polished_blackstone_bricks
fill 433 39 464 433 42 464 minecraft:blackstone
setblock 437 39 464 minecraft:polished_blackstone_bricks
setblock 437 39 504 minecraft:polished_blackstone_bricks
fill 438 39 464 438 41 465 minecraft:blackstone
fill 438 39 504 438 42 504 minecraft:blackstone
setblock 441 39 465 minecraft:polished_blackstone_bricks
setblock 442 39 464 minecraft:polished_blackstone_bricks
fill 442 39 465 442 42 465 minecraft:blackstone
setblock 442 39 504 minecraft:polished_blackstone_bricks
fill 443 39 464 443 42 464 minecraft:blackstone
fill 443 39 466 443 40 466 minecraft:blackstone
setblock 443 39 503 minecraft:polished_blackstone_bricks
fill 443 39 504 443 42 504 minecraft:blackstone
setblock 444 39 502 minecraft:polished_blackstone_bricks
fill 444 39 503 444 42 503 minecraft:blackstone
setblock 445 39 466 minecraft:polished_blackstone_bricks
fill 445 39 502 445 42 502 minecraft:blackstone
setblock 446 39 465 minecraft:polished_blackstone_bricks
fill 446 39 466 446 42 466 minecraft:blackstone
setblock 447 39 464 minecraft:polished_blackstone_bricks
fill 447 39 465 447 42 465 minecraft:blackstone
setblock 447 39 504 minecraft:polished_blackstone_bricks
fill 448 39 464 448 42 464 minecraft:blackstone
setblock 448 39 503 minecraft:polished_blackstone_bricks
fill 448 39 504 448 42 504 minecraft:blackstone
setblock 449 39 502 minecraft:polished_blackstone_bricks
fill 449 39 503 449 42 503 minecraft:blackstone
fill 451 39 470 451 40 470 minecraft:cyan_stained_glass
setblock 452 39 464 minecraft:polished_blackstone_bricks
setblock 452 39 504 minecraft:polished_blackstone_bricks
setblock 453 39 464 minecraft:blackstone
fill 453 39 504 453 42 504 minecraft:blackstone
setblock 457 39 504 minecraft:polished_blackstone_bricks
fill 458 39 504 458 42 504 minecraft:blackstone
setblock 461 39 464 minecraft:blackstone
setblock 462 39 464 minecraft:polished_blackstone_bricks
setblock 462 39 484 minecraft:polished_blackstone_bricks
fill 462 39 485 462 42 485 minecraft:blackstone
fill 462 39 487 462 39 488 minecraft:blackstone
setblock 462 39 504 minecraft:polished_blackstone_bricks
fill 463 39 464 463 42 464 minecraft:blackstone
fill 463 39 479 463 42 479 minecraft:blackstone
setblock 463 39 483 minecraft:polished_blackstone_bricks
fill 463 39 484 463 42 484 minecraft:blackstone
setblock 463 39 488 minecraft:polished_blackstone_bricks
fill 463 39 489 463 42 489 minecraft:blackstone
setblock 463 39 503 minecraft:polished_blackstone_bricks
fill 463 39 504 463 42 504 minecraft:blackstone
setblock 464 39 467 minecraft:polished_blackstone_bricks
fill 464 39 468 464 42 468 minecraft:blackstone
setblock 464 39 477 minecraft:polished_blackstone_bricks
fill 464 39 478 464 42 478 minecraft:blackstone
setblock 464 39 482 minecraft:polished_blackstone_bricks
fill 464 39 483 464 42 483 minecraft:blackstone
setblock 464 39 487 minecraft:polished_blackstone_bricks
fill 464 39 488 464 42 488 minecraft:blackstone
setblock 464 39 492 minecraft:polished_blackstone_bricks
fill 464 39 493 464 42 493 minecraft:blackstone
setblock 464 39 497 minecraft:polished_blackstone_bricks
fill 464 39 498 464 42 498 minecraft:blackstone
setblock 464 39 502 minecraft:polished_blackstone_bricks
fill 464 39 503 464 42 503 minecraft:blackstone
fill 424 40 464 424 40 465 minecraft:blackstone
setblock 424 40 466 minecraft:polished_blackstone_bricks
fill 424 40 467 424 43 467 minecraft:blackstone
setblock 424 40 471 minecraft:polished_blackstone_bricks
fill 424 40 472 425 42 472 minecraft:blackstone
setblock 424 40 476 minecraft:polished_blackstone_bricks
fill 424 40 477 424 43 477 minecraft:blackstone
setblock 424 40 481 minecraft:polished_blackstone_bricks
fill 424 40 482 424 43 482 minecraft:blackstone
setblock 424 40 486 minecraft:polished_blackstone_bricks
fill 424 40 487 424 43 487 minecraft:blackstone
setblock 424 40 491 minecraft:polished_blackstone_bricks
fill 424 40 492 424 43 492 minecraft:blackstone
setblock 424 40 501 minecraft:polished_blackstone_bricks
fill 424 40 502 424 43 502 minecraft:blackstone
setblock 425 40 465 minecraft:polished_blackstone_bricks
fill 425 40 466 428 40 466 minecraft:blackstone
setblock 425 40 469 minecraft:blackstone
setblock 425 40 470 minecraft:polished_blackstone_bricks
fill 425 40 471 425 43 471 minecraft:blackstone
fill 425 40 473 425 41 473 minecraft:blackstone
setblock 425 40 475 minecraft:polished_blackstone_bricks
fill 425 40 476 425 43 476 minecraft:blackstone
setblock 425 40 480 minecraft:polished_blackstone_bricks
fill 425 40 481 425 43 481 minecraft:blackstone
setblock 425 40 485 minecraft:polished_blackstone_bricks
fill 425 40 486 425 43 486 minecraft:blackstone
setblock 425 40 490 minecraft:polished_blackstone_bricks
setblock 426 40 464 minecraft:polished_blackstone_bricks
fill 426 40 465 426 43 465 minecraft:blackstone
fill 426 40 467 426 41 467 minecraft:blackstone
fill 426 40 480 426 41 480 minecraft:blackstone
setblock 426 40 484 minecraft:polished_blackstone_bricks
fill 426 40 485 426 43 485 minecraft:blackstone
setblock 426 40 504 minecraft:polished_blackstone_bricks
fill 427 40 464 430 40 464 minecraft:blackstone
fill 427 40 504 427 43 504 minecraft:blackstone
setblock 430 40 465 minecraft:polished_blackstone_bricks
setblock 431 40 464 minecraft:polished_blackstone_bricks
fill 431 40 465 431 43 465 minecraft:blackstone
setblock 431 40 504 minecraft:polished_blackstone_bricks
fill 432 40 464 432 43 464 minecraft:blackstone
fill 433 40 465 434 40 465 minecraft:blackstone
setblock 435 40 465 minecraft:polished_blackstone_bricks
setblock 436 40 464 minecraft:polished_blackstone_bricks
fill 436 40 465 437 42 465 minecraft:blackstone
setblock 436 40 504 minecraft:polished_blackstone_bricks
fill 437 40 464 437 43 464 minecraft:blackstone
fill 437 40 504 437 43 504 minecraft:blackstone
setblock 440 40 465 minecraft:polished_blackstone_bricks
setblock 441 40 464 minecraft:polished_blackstone_bricks
fill 441 40 465 441 42 466 minecraft:blackstone
setblock 441 40 504 minecraft:polished_blackstone_bricks
fill 442 40 464 442 43 464 minecraft:blackstone
fill 442 40 466 442 41 466 minecraft:blackstone
setblock 442 40 503 minecraft:polished_blackstone_bricks
fill 442 40 504 442 43 504 minecraft:blackstone
setblock 443 40 502 minecraft:polished_blackstone_bricks
fill 443 40 503 443 43 503 minecraft:blackstone
setblock 444 40 466 minecraft:polished_blackstone_bricks
fill 444 40 474 444 41 474 minecraft:light_blue_stained_glass
fill 444 40 502 444 43 502 minecraft:blackstone
setblock 445 40 465 minecraft:polished_blackstone_bricks
fill 445 40 466 445 43 466 minecraft:blackstone
setblock 446 40 464 minecraft:polished_blackstone_bricks
fill 446 40 465 446 43 465 minecraft:blackstone
setblock 446 40 504 minecraft:polished_blackstone_bricks
fill 447 40 464 447 43 464 minecraft:blackstone
setblock 447 40 503 minecraft:polished_blackstone_bricks
fill 447 40 504 447 43 504 minecraft:blackstone
setblock 448 40 502 minecraft:polished_blackstone_bricks
fill 448 40 503 448 43 503 minecraft:blackstone
fill 450 40 478 451 41 479 minecraft:cyan_stained_glass
setblock 451 40 464 minecraft:polished_blackstone_bricks
setblock 451 40 504 minecraft:polished_blackstone_bricks
fill 452 40 464 452 43 464 minecraft:blackstone
fill 452 40 504 452 43 504 minecraft:blackstone
setblock 456 40 504 minecraft:polished_blackstone_bricks
fill 457 40 504 457 43 504 minecraft:blackstone
setblock 460 40 464 minecraft:blackstone
setblock 461 40 464 minecraft:polished_blackstone_bricks
setblock 461 40 504 minecraft:polished_blackstone_bricks
fill 462 40 464 462 43 464 minecraft:blackstone
setblock 462 40 482 minecraft:blackstone
setblock 462 40 483 minecraft:polished_blackstone_bricks
fill 462 40 484 462 43 484 minecraft:blackstone
setblock 462 40 487 minecraft:blackstone
setblock 462 40 488 minecraft:polished_blackstone_bricks
fill 462 40 489 462 43 489 minecraft:blackstone
fill 462 40 504 462 43 504 minecraft:blackstone
setblock 463 40 482 minecraft:polished_blackstone_bricks
fill 463 40 483 463 43 483 minecraft:blackstone
setblock 463 40 487 minecraft:polished_blackstone_bricks
fill 463 40 488 463 43 488 minecraft:blackstone
setblock 463 40 492 minecraft:polished_blackstone_bricks
setblock 464 40 466 minecraft:polished_blackstone_bricks
fill 464 40 467 464 43 467 minecraft:blackstone
fill 464 40 469 464 40 470 minecraft:blackstone
setblock 464 40 475 minecraft:blackstone
setblock 464 40 476 minecraft:polished_blackstone_bricks
fill 464 40 477 464 43 477 minecraft:blackstone
setblock 464 40 481 minecraft:polished_blackstone_bricks
fill 464 40 482 464 43 482 minecraft:blackstone
setblock 464 40 486 minecraft:polished_blackstone_bricks
fill 464 40 487 464 43 487 minecraft:blackstone
setblock 464 40 491 minecraft:polished_blackstone_bricks
fill 464 40 492 464 43 492 minecraft:blackstone
setblock 464 40 496 minecraft:polished_blackstone_bricks
fill 464 40 497 464 43 497 minecraft:blackstone
setblock 464 40 501 minecraft:polished_blackstone_bricks
fill 464 40 502 464 43 502 minecraft:blackstone
setblock 424 41 464 minecraft:blackstone
setblock 424 41 465 minecraft:polished_blackstone_bricks
fill 424 41 466 427 41 466 minecraft:blackstone
setblock 424 41 470 minecraft:polished_blackstone_bricks
fill 424 41 471 424 44 471 minecraft:blackstone
setblock 424 41 475 minecraft:polished_blackstone_bricks
fill 424 41 476 424 44 476 minecraft:blackstone
setblock 424 41 480 minecraft:polished_blackstone_bricks
fill 424 41 481 424 44 481 minecraft:blackstone
setblock 424 41 485 minecraft:polished_blackstone_bricks
fill 424 41 486 424 44 486 minecraft:blackstone
setblock 424 41 490 minecraft:polished_blackstone_bricks
fill 424 41 491 424 44 491 minecraft:blackstone
fill 424 41 493 424 42 493 minecraft:blackstone
setblock 425 41 464 minecraft:polished_blackstone_bricks
fill 425 41 465 425 44 465 minecraft:blackstone
setblock 425 41 469 minecraft:polished_blackstone_bricks
fill 425 41 470 425 44 470 minecraft:blackstone
setblock 425 41 474 minecraft:polished_blackstone_bricks
fill 425 41 475 425 44 475 minecraft:blackstone
setblock 425 41 479 minecraft:polished_blackstone_bricks
fill 425 41 480 425 44 480 minecraft:blackstone
setblock 425 41 484 minecraft:polished_blackstone_bricks
fill 425 41 485 425 44 485 minecraft:blackstone
setblock 425 41 489 minecraft:polished_blackstone_bricks
fill 425 41 490 425 44 490 minecraft:blackstone
setblock 425 41 504 minecraft:polished_blackstone_bricks
fill 426 41 464 429 41 464 minecraft:blackstone
setblock 426 41 468 minecraft:polished_blackstone_bricks
fill 426 41 469 426 44 469 minecraft:blackstone
setblock 426 41 483 minecraft:polished_blackstone_bricks
fill 426 41 484 426 44 484 minecraft:blackstone
fill 426 41 504 426 44 504 minecraft:blackstone
setblock 428 41 466 minecraft:polished_blackstone_bricks
setblock 429 41 465 minecraft:polished_blackstone_bricks
setblock 430 41 464 minecraft:polished_blackstone_bricks
fill 430 41 465 430 44 465 minecraft:blackstone
setblock 430 41 504 minecraft:polished_blackstone_bricks
fill 431 41 464 431 44 464 minecraft:blackstone
setblock 433 41 465 minecraft:blackstone
setblock 434 41 465 minecraft:polished_blackstone_bricks
setblock 435 41 464 minecraft:polished_blackstone_bricks
fill 435 41 465 435 44 465 minecraft:blackstone
fill 436 41 464 436 44 464 minecraft:blackstone
fill 436 41 504 436 44 504 minecraft:blackstone
setblock 439 41 465 minecraft:polished_blackstone_bricks
fill 439 41 503 439 42 503 minecraft:blackstone
setblock 440 41 464 minecraft:polished_blackstone_bricks
fill 440 41 465 440 43 466 minecraft:blackstone
setblock 440 41 504 minecraft:polished_blackstone_bricks
fill 441 41 464 441 44 464 minecraft:blackstone
setblock 441 41 503 minecraft:polished_blackstone_bricks
fill 441 41 504 441 44 504 minecraft:blackstone
fill 442 41 503 442 44 503 minecraft:blackstone
setblock 443 41 466 minecraft:polished_blackstone_bricks
fill 443 41 502 443 44 502 minecraft:blackstone
setblock 444 41 465 minecraft:polished_blackstone_bricks
fill 444 41 466 444 44 466 minecraft:blackstone
setblock 445 41 464 minecraft:polished_blackstone_bricks
fill 445 41 465 445 44 465 minecraft:blackstone
setblock 445 41 504 minecraft:polished_blackstone_bricks
fill 446 41 464 446 44 464 minecraft:blackstone
setblock 446 41 503 minecraft:polished_blackstone_bricks
fill 446 41 504 446 44 504 minecraft:blackstone
setblock 447 41 502 minecraft:polished_blackstone_bricks
fill 447 41 503 447 44 503 minecraft:blackstone
setblock 449 41 465 minecraft:polished_blackstone_bricks
setblock 450 41 464 minecraft:polished_blackstone_bricks
setblock 450 41 504 minecraft:polished_blackstone_bricks
fill 451 41 464 451 44 464 minecraft:blackstone
setblock 451 41 503 minecraft:polished_blackstone_bricks
fill 451 41 504 451 44 504 minecraft:blackstone
setblock 455 41 504 minecraft:polished_blackstone_bricks
fill 456 41 504 456 44 504 minecraft:blackstone
setblock 459 41 464 minecraft:blackstone
setblock 460 41 464 minecraft:polished_blackstone_bricks
setblock 460 41 504 minecraft:polished_blackstone_bricks
fill 461 41 464 461 44 464 minecraft:blackstone
fill 461 41 504 461 44 504 minecraft:blackstone
setblock 462 41 482 minecraft:polished_blackstone_bricks
fill 462 41 483 462 44 483 minecraft:blackstone
setblock 462 41 487 minecraft:polished_blackstone_bricks
fill 462 41 488 462 44 488 minecraft:blackstone
fill 462 41 490 463 41 490 minecraft:blackstone
setblock 463 41 465 minecraft:blackstone
setblock 463 41 466 minecraft:polished_blackstone_bricks
setblock 463 41 481 minecraft:polished_blackstone_bricks
fill 463 41 482 463 44 482 minecraft:blackstone
setblock 463 41 486 minecraft:polished_blackstone_bricks
fill 463 41 487 463 44 487 minecraft:blackstone
setblock 463 41 491 minecraft:polished_blackstone_bricks
fill 463 41 492 463 43 493 minecraft:blackstone
setblock 464 41 465 minecraft:polished_blackstone_bricks
fill 464 41 466 464 44 466 minecraft:blackstone
setblock 464 41 469 minecraft:blackstone
setblock 464 41 470 minecraft:polished_blackstone_bricks
fill 464 41 471 464 41 474 minecraft:blackstone
setblock 464 41 475 minecraft:polished_blackstone_bricks
fill 464 41 476 464 44 476 minecraft:blackstone
setblock 464 41 480 minecraft:polished_blackstone_bricks
fill 464 41 481 464 44 481 minecraft:blackstone
setblock 464 41 485 minecraft:polished_blackstone_bricks
fill 464 41 486 464 44 486 minecraft:blackstone
setblock 464 41 490 minecraft:polished_blackstone_bricks
fill 464 41 491 464 44 491 minecraft:blackstone
setblock 464 41 495 minecraft:polished_blackstone_bricks
fill 464 41 496 464 44 496 minecraft:blackstone
setblock 464 41 500 minecraft:polished_blackstone_bricks
fill 464 41 501 464 44 501 minecraft:blackstone
setblock 424 42 464 minecraft:polished_blackstone_bricks
fill 424 42 465 424 44 466 minecraft:blackstone
setblock 424 42 469 minecraft:polished_blackstone_bricks
fill 424 42 470 424 45 470 minecraft:blackstone
setblock 424 42 474 minecraft:polished_blackstone_bricks
fill 424 42 475 424 45 475 minecraft:blackstone
setblock 424 42 479 minecraft:polished_blackstone_bricks
fill 424 42 480 424 45 480 minecraft:blackstone
setblock 424 42 484 minecraft:polished_blackstone_bricks
fill 424 42 485 424 45 485 minecraft:blackstone
setblock 424 42 489 minecraft:polished_blackstone_bricks
fill 424 42 490 424 45 490 minecraft:blackstone
setblock 424 42 494 minecraft:polished_blackstone_bricks
setblock 424 42 504 minecraft:polished_blackstone_bricks
fill 425 42 464 428 42 464 minecraft:blackstone
fill 425 42 466 426 42 466 minecraft:blackstone
setblock 425 42 468 minecraft:polished_blackstone_bricks
fill 425 42 469 425 45 469 minecraft:blackstone
setblock 425 42 473 minecraft:polished_blackstone_bricks
fill 425 42 474 425 45 474 minecraft:blackstone
setblock 425 42 478 minecraft:polished_blackstone_bricks
fill 425 42 479 425 45 479 minecraft:blackstone
setblock 425 42 483 minecraft:polished_blackstone_bricks
fill 425 42 484 425 45 484 minecraft:blackstone
setblock 425 42 488 minecraft:polished_blackstone_bricks
fill 425 42 489 425 45 489 minecraft:blackstone
fill 425 42 491 425 43 491 minecraft:blackstone
fill 425 42 504 425 45 504 minecraft:blackstone
setblock 426 42 467 minecraft:polished_blackstone_bricks
fill 426 42 468 426 45 468 minecraft:blackstone
fill 426 42 470 426 43 470 minecraft:blackstone
setblock 426 42 482 minecraft:polished_blackstone_bricks
fill 426 42 483 426 43 483 minecraft:blackstone
setblock 426 42 487 minecraft:polished_blackstone_bricks
fill 426 42 488 426 45 488 minecraft:blackstone
setblock 427 42 466 minecraft:polished_blackstone_bricks
setblock 428 42 465 minecraft:polished_blackstone_bricks
fill 428 42 466 429 44 466 minecraft:blackstone
setblock 429 42 464 minecraft:polished_blackstone_bricks
fill 429 42 465 429 45 465 minecraft:blackstone
setblock 429 42 504 minecraft:polished_blackstone_bricks
fill 430 42 464 430 45 464 minecraft:blackstone
setblock 430 42 504 minecraft:blackstone
setblock 433 42 465 minecraft:polished_blackstone_bricks
setblock 434 42 464 minecraft:polished_blackstone_bricks
fill 434 42 465 434 45 465 minecraft:blackstone
fill 435 42 464 435 45 464 minecraft:blackstone
fill 435 42 504 435 45 504 minecraft:blackstone
setblock 438 42 464 minecraft:blackstone
setblock 438 42 465 minecraft:polished_blackstone_bricks
fill 438 42 466 439 44 466 minecraft:blackstone
setblock 439 42 464 minecraft:polished_blackstone_bricks
fill 439 42 465 439 45 465 minecraft:blackstone
setblock 439 42 504 minecraft:polished_blackstone_bricks
fill 440 42 464 440 45 464 minecraft:blackstone
setblock 440 42 503 minecraft:polished_blackstone_bricks
fill 440 42 504 440 45 504 minecraft:blackstone
fill 441 42 503 441 45 503 minecraft:blackstone
setblock 442 42 466 minecraft:polished_blackstone_bricks
fill 442 42 502 442 45 502 minecraft:blackstone
setblock 443 42 465 minecraft:polished_blackstone_bricks
fill 443 42 466 443 45 466 minecraft:blackstone
setblock 444 42 464 minecraft:polished_blackstone_bricks
fill 444 42 465 444 45 465 minecraft:blackstone
setblock 444 42 504 minecraft:polished_blackstone_bricks
fill 445 42 464 445 45 464 minecraft:blackstone
setblock 445 42 503 minecraft:polished_blackstone_bricks
fill 445 42 504 445 45 504 minecraft:blackstone
setblock 446 42 502 minecraft:polished_blackstone_bricks
fill 446 42 503 446 45 503 minecraft:blackstone
setblock 447 42 466 minecraft:polished_blackstone_bricks
setblock 448 42 465 minecraft:polished_blackstone_bricks
setblock 449 42 464 minecraft:polished_blackstone_bricks
fill 449 42 465 449 45 465 minecraft:blackstone
setblock 449 42 504 minecraft:polished_blackstone_bricks
fill 450 42 464 450 45 464 minecraft:blackstone
setblock 450 42 503 minecraft:polished_blackstone_bricks
fill 450 42 504 450 45 504 minecraft:blackstone
setblock 454 42 504 minecraft:polished_blackstone_bricks
fill 455 42 504 455 45 504 minecraft:blackstone
setblock 458 42 464 minecraft:blackstone
setblock 459 42 464 minecraft:polished_blackstone_bricks
setblock 459 42 504 minecraft:polished_blackstone_bricks
fill 460 42 464 460 45 464 minecraft:blackstone
fill 460 42 504 460 45 504 minecraft:blackstone
fill 461 42 465 462 42 465 minecraft:blackstone
fill 461 42 485 461 42 486 minecraft:blackstone
setblock 461 42 487 minecraft:polished_blackstone_bricks
fill 461 42 488 461 45 488 minecraft:blackstone
setblock 462 42 481 minecraft:polished_blackstone_bricks
fill 462 42 482 462 45 482 minecraft:blackstone
setblock 462 42 486 minecraft:polished_blackstone_bricks
fill 462 42 487 462 45 487 minecraft:blackstone
setblock 462 42 490 minecraft:blackstone
setblock 462 42 491 minecraft:polished_blackstone_bricks
fill 462 42 492 462 45 492 minecraft:blackstone
setblock 463 42 465 minecraft:polished_blackstone_bricks
fill 463 42 466 463 42 469 minecraft:blackstone
fill 463 42 478 463 43 478 minecraft:blackstone
setblock 463 42 480 minecraft:polished_blackstone_bricks
fill 463 42 481 463 45 481 minecraft:blackstone
setblock 463 42 485 minecraft:polished_blackstone_bricks
fill 463 42 486 463 45 486 minecraft:blackstone
setblock 463 42 490 minecraft:polished_blackstone_bricks
fill 463 42 491 463 45 491 minecraft:blackstone
setblock 463 42 494 minecraft:blackstone
setblock 464 42 464 minecraft:polished_blackstone_bricks
fill 464 42 465 464 45 465 minecraft:blackstone
setblock 464 42 469 minecraft:polished_blackstone_bricks
fill 464 42 470 464 42 473 minecraft:blackstone
setblock 464 42 474 minecraft:polished_blackstone_bricks
fill 464 42 475 464 45 475 minecraft:blackstone
setblock 464 42 479 minecraft:polished_blackstone_bricks
fill 464 42 480 464 45 480 minecraft:blackstone
setblock 464 42 484 minecraft:polished_blackstone_bricks
fill 464 42 485 464 45 485 minecraft:blackstone
setblock 464 42 489 minecraft:polished_blackstone_bricks
fill 464 42 490 464 45 490 minecraft:blackstone
setblock 464 42 494 minecraft:polished_blackstone_bricks
fill 464 42 495 464 45 495 minecraft:blackstone
setblock 464 42 499 minecraft:polished_blackstone_bricks
fill 464 42 500 464 45 500 minecraft:blackstone
setblock 464 42 504 minecraft:polished_blackstone_bricks
fill 424 43 464 427 43 464 minecraft:blackstone
setblock 424 43 468 minecraft:polished_blackstone_bricks
fill 424 43 469 424 46 469 minecraft:blackstone
setblock 424 43 472 minecraft:blackstone
setblock 424 43 473 minecraft:polished_blackstone_bricks
fill 424 43 474 424 46 474 minecraft:blackstone
setblock 424 43 478 minecraft:polished_blackstone_bricks
fill 424 43 479 424 46 479 minecraft:blackstone
setblock 424 43 483 minecraft:polished_blackstone_bricks
fill 424 43 484 424 46 484 minecraft:blackstone
setblock 424 43 488 minecraft:polished_blackstone_bricks
fill 424 43 489 424 46 489 minecraft:blackstone
setblock 424 43 493 minecraft:polished_blackstone_bricks
fill 424 43 494 424 45 495 minecraft:blackstone
setblock 424 43 503 minecraft:polished_blackstone_bricks
fill 424 43 504 424 46 504 minecraft:blackstone
setblock 425 43 466 minecraft:blackstone
setblock 425 43 467 minecraft:polished_blackstone_bricks
fill 425 43 468 425 46 468 minecraft:blackstone
setblock 425 43 472 minecraft:polished_blackstone_bricks
fill 425 43 473 425 46 473 minecraft:blackstone
setblock 425 43 477 minecraft:polished_blackstone_bricks
fill 425 43 478 425 46 478 minecraft:blackstone
setblock 425 43 482 minecraft:polished_blackstone_bricks
fill 425 43 483 425 46 483 minecraft:blackstone
setblock 425 43 487 minecraft:polished_blackstone_bricks
fill 425 43 488 425 46 488 minecraft:blackstone
setblock 425 43 492 minecraft:polished_blackstone_bricks
setblock 426 43 466 minecraft:polished_blackstone_bricks
fill 426 43 467 426 46 467 minecraft:blackstone
setblock 426 43 471 minecraft:polished_blackstone_bricks
fill 426 43 472 426 46 472 minecraft:blackstone
setblock 426 43 482 minecraft:blackstone
setblock 426 43 486 minecraft:polished_blackstone_bricks
fill 426 43 487 426 45 487 minecraft:blackstone
setblock 427 43 465 minecraft:polished_blackstone_bricks
fill 427 43 466 427 46 466 minecraft:blackstone
setblock 428 43 464 minecraft:polished_blackstone_bricks
fill 428 43 465 428 46 465 minecraft:blackstone
setblock 428 43 504 minecraft:polished_blackstone_bricks
fill 429 43 464 429 46 464 minecraft:blackstone
fill 429 43 504 429 44 504 minecraft:blackstone
setblock 430 43 466 minecraft:blackstone
setblock 432 43 465 minecraft:polished_blackstone_bricks
setblock 433 43 464 minecraft:polished_blackstone_bricks
fill 433 43 465 433 46 465 minecraft:blackstone
fill 434 43 464 434 46 464 minecraft:blackstone
fill 434 43 504 434 46 504 minecraft:blackstone
setblock 436 43 465 minecraft:blackstone
setblock 436 43 466 minecraft:polished_blackstone_bricks
setblock 437 43 465 minecraft:polished_blackstone_bricks
fill 437 43 466 437 46 466 minecraft:blackstone
setblock 438 43 464 minecraft:polished_blackstone_bricks
fill 438 43 465 438 46 465 minecraft:blackstone
setblock 438 43 503 minecraft:blackstone
setblock 438 43 504 minecraft:polished_blackstone_bricks
fill 439 43 464 439 46 464 minecraft:blackstone
setblock 439 43 503 minecraft:polished_blackstone_bricks
fill 439 43 504 439 46 504 minecraft:blackstone
fill 440 43 503 440 46 503 minecraft:blackstone
setblock 441 43 465 minecraft:blackstone
setblock 441 43 466 minecraft:polished_blackstone_bricks
fill 441 43 467 443 44 467 minecraft:blackstone
setblock 442 43 465 minecraft:polished_blackstone_bricks
fill 442 43 466 442 46 466 minecraft:blackstone
setblock 443 43 464 minecraft:polished_blackstone_bricks
fill 443 43 465 443 46 465 minecraft:blackstone
setblock 443 43 504 minecraft:polished_blackstone_bricks
fill 444 43 464 444 46 464 minecraft:blackstone
setblock 444 43 503 minecraft:polished_blackstone_bricks
fill 444 43 504 444 46 504 minecraft:blackstone
setblock 445 43 502 minecraft:polished_blackstone_bricks
fill 445 43 503 445 46 503 minecraft:blackstone
setblock 446 43 466 minecraft:polished_blackstone_bricks
setblock 446 43 502 minecraft:blackstone
setblock 447 43 465 minecraft:polished_blackstone_bricks
fill 447 43 466 447 44 466 minecraft:blackstone
setblock 448 43 464 minecraft:polished_blackstone_bricks
fill 448 43 465 448 46 465 minecraft:blackstone
setblock 448 43 504 minecraft:polished_blackstone_bricks
fill 449 43 464 449 46 464 minecraft:blackstone
setblock 449 43 503 minecraft:polished_blackstone_bricks
fill 449 43 504 449 46 504 minecraft:blackstone
setblock 453 43 504 minecraft:polished_blackstone_bricks
fill 454 43 504 454 44 504 minecraft:blackstone
setblock 457 43 464 minecraft:blackstone
setblock 458 43 464 minecraft:polished_blackstone_bricks
setblock 458 43 504 minecraft:polished_blackstone_bricks
fill 459 43 464 459 46 464 minecraft:blackstone
fill 459 43 504 459 46 504 minecraft:blackstone
fill 460 43 465 461 43 465 minecraft:blackstone
fill 461 43 484 461 43 485 minecraft:blackstone
setblock 461 43 486 minecraft:polished_blackstone_bricks
fill 461 43 487 461 46 487 minecraft:blackstone
fill 461 43 489 461 43 490 minecraft:blackstone
setblock 462 43 465 minecraft:polished_blackstone_bricks
fill 462 43 481 462 46 481 minecraft:blackstone
setblock 462 43 485 minecraft:polished_blackstone_bricks
fill 462 43 486 462 46 486 minecraft:blackstone
setblock 462 43 490 minecraft:polished_blackstone_bricks
fill 462 43 491 462 46 491 minecraft:blackstone
fill 462 43 493 462 44 493 minecraft:blackstone
setblock 463 43 464 minecraft:polished_blackstone_bricks
fill 463 43 465 463 43 468 minecraft:blackstone
setblock 463 43 469 minecraft:polished_blackstone_bricks
fill 463 43 470 463 43 473 minecraft:blackstone
fill 463 43 476 463 44 477 minecraft:blackstone
setblock 463 43 479 minecraft:polished_blackstone_bricks
fill 463 43 480 463 46 480 minecraft:blackstone
setblock 463 43 484 minecraft:polished_blackstone_bricks
fill 463 43 485 463 46 485 minecraft:blackstone
setblock 463 43 489 minecraft:polished_blackstone_bricks
fill 463 43 490 463 46 490 minecraft:blackstone
setblock 463 43 494 minecraft:polished_blackstone_bricks
fill 463 43 495 463 45 496 minecraft:blackstone
setblock 463 43 504 minecraft:polished_blackstone_bricks
fill 464 43 464 464 46 464 minecraft:blackstone
setblock 464 43 468 minecraft:polished_blackstone_bricks
fill 464 43 469 464 43 472 minecraft:blackstone
setblock 464 43 473 minecraft:polished_blackstone_bricks
fill 464 43 474 464 46 474 minecraft:blackstone
setblock 464 43 478 minecraft:polished_blackstone_bricks
fill 464 43 479 464 46 479 minecraft:blackstone
setblock 464 43 483 minecraft:polished_blackstone_bricks
fill 464 43 484 464 46 484 minecraft:blackstone
setblock 464 43 488 minecraft:polished_blackstone_bricks
fill 464 43 489 464 46 489 minecraft:blackstone
setblock 464 43 493 minecraft:polished_blackstone_bricks
fill 464 43 494 464 46 494 minecraft:blackstone
setblock 464 43 498 minecraft:polished_blackstone_bricks
fill 464 43 499 464 46 499 minecraft:blackstone
setblock 464 43 503 minecraft:polished_blackstone_bricks
fill 464 43 504 464 46 504 minecraft:blackstone
fill 424 44 464 426 44 464 minecraft:blackstone
setblock 424 44 467 minecraft:polished_blackstone_bricks
fill 424 44 468 424 47 468 minecraft:blackstone
setblock 424 44 472 minecraft:polished_blackstone_bricks
fill 424 44 473 424 47 473 minecraft:blackstone
setblock 424 44 477 minecraft:polished_blackstone_bricks
fill 424 44 478 424 47 478 minecraft:blackstone
setblock 424 44 482 minecraft:polished_blackstone_bricks
fill 424 44 483 424 47 483 minecraft:blackstone
setblock 424 44 487 minecraft:polished_blackstone_bricks
fill 424 44 488 424 47 488 minecraft:blackstone
setblock 424 44 492 minecraft:polished_blackstone_bricks
fill 424 44 493 424 47 493 minecraft:blackstone
setblock 424 44 496 minecraft:blackstone
setblock 424 44 502 minecraft:polished_blackstone_bricks
fill 424 44 503 424 47 503 minecraft:blackstone
setblock 425 44 466 minecraft:polished_blackstone_bricks
fill 425 44 467 425 47 467 minecraft:blackstone
setblock 425 44 471 minecraft:polished_blackstone_bricks
fill 425 44 472 425 47 472 minecraft:blackstone
setblock 425 44 476 minecraft:polished_blackstone_bricks
fill 425 44 477 425 47 477 minecraft:blackstone
setblock 425 44 481 minecraft:polished_blackstone_bricks
fill 425 44 482 425 47 482 minecraft:blackstone
setblock 425 44 486 minecraft:polished_blackstone_bricks
fill 425 44 487 425 47 487 minecraft:blackstone
setblock 425 44 491 minecraft:polished_blackstone_bricks
fill 425 44 492 425 47 492 minecraft:blackstone
setblock 426 44 465 minecraft:polished_blackstone_bricks
fill 426 44 466 426 47 466 minecraft:blackstone
setblock 426 44 470 minecraft:polished_blackstone_bricks
fill 426 44 471 426 47 471 minecraft:blackstone
fill 426 44 473 426 45 473 minecraft:blackstone
setblock 426 44 485 minecraft:polished_blackstone_bricks
fill 426 44 486 426 45 486 minecraft:blackstone
setblock 427 44 464 minecraft:polished_blackstone_bricks
fill 427 44 465 427 47 465 minecraft:blackstone
fill 427 44 467 427 45 467 minecraft:blackstone
setblock 427 44 504 minecraft:polished_blackstone_bricks
fill 428 44 464 428 47 464 minecraft:blackstone
fill 428 44 504 428 45 504 minecraft:blackstone
setblock 430 44 466 minecraft:polished_blackstone_bricks
setblock 431 44 465 minecraft:polished_blackstone_bricks
fill 431 44 466 431 46 466 minecraft:blackstone
setblock 432 44 464 minecraft:polished_blackstone_bricks
fill 432 44 465 432 47 465 minecraft:blackstone
fill 433 44 464 433 47 464 minecraft:blackstone
setblock 434 44 466 minecraft:blackstone
setblock 435 44 466 minecraft:polished_blackstone_bricks
setblock 436 44 465 minecraft:polished_blackstone_bricks
fill 436 44 466 436 47 466 minecraft:blackstone
setblock 437 44 464 minecraft:polished_blackstone_bricks
fill 437 44 465 437 47 465 minecraft:blackstone
setblock 437 44 504 minecraft:polished_blackstone_bricks
fill 438 44 464 438 47 464 minecraft:blackstone
setblock 438 44 503 minecraft:polished_blackstone_bricks
fill 438 44 504 438 47 504 minecraft:blackstone
setblock 439 44 467 minecraft:polished_blackstone_bricks
fill 439 44 503 439 47 503 minecraft:blackstone
setblock 440 44 465 minecraft:blackstone
setblock 440 44 466 minecraft:polished_blackstone_bricks
fill 440 44 467 440 47 467 minecraft:blackstone
setblock 441 44 465 minecraft:polished_blackstone_bricks
fill 441 44 466 441 47 466 minecraft:blackstone
fill 441 44 502 441 46 502 minecraft:blackstone
setblock 442 44 464 minecraft:polished_blackstone_bricks
fill 442 44 465 442 47 465 minecraft:blackstone
setblock 442 44 504 minecraft:polished_blackstone_bricks
fill 443 44 464 443 47 464 minecraft:blackstone
setblock 443 44 503 minecraft:polished_blackstone_bricks
fill 443 44 504 443 47 504 minecraft:blackstone
setblock 444 44 467 minecraft:polished_blackstone_bricks
setblock 444 44 502 minecraft:polished_blackstone_bricks
fill 444 44 503 444 47 503 minecraft:blackstone
setblock 445 44 466 minecraft:polished_blackstone_bricks
fill 445 44 502 445 45 502 minecraft:blackstone
setblock 446 44 465 minecraft:polished_blackstone_bricks
fill 446 44 466 446 46 466 minecraft:blackstone
setblock 447 44 464 minecraft:polished_blackstone_bricks
fill 447 44 465 447 47 465 minecraft:blackstone
setblock 447 44 504 minecraft:polished_blackstone_bricks
fill 448 44 464 448 47 464 minecraft:blackstone
setblock 448 44 503 minecraft:polished_blackstone_bricks
fill 448 44 504 448 47 504 minecraft:blackstone
setblock 449 44 503 minecraft:blackstone
setblock 452 44 464 minecraft:polished_blackstone_bricks
setblock 452 44 504 minecraft:polished_blackstone_bricks
fill 453 44 504 453 45 504 minecraft:blackstone
setblock 456 44 464 minecraft:blackstone
setblock 457 44 464 minecraft:polished_blackstone_bricks
setblock 457 44 504 minecraft:polished_blackstone_bricks
fill 458 44 464 458 47 464 minecraft:blackstone
fill 458 44 504 458 47 504 minecraft:blackstone
fill 459 44 465 460 44 465 minecraft:blackstone
setblock 461 44 465 minecraft:polished_blackstone_bricks
setblock 461 44 484 minecraft:blackstone
setblock 461 44 485 minecraft:polished_blackstone_bricks
fill 461 44 486 461 47 486 minecraft:blackstone
setblock 461 44 489 minecraft:blackstone
setblock 461 44 490 minecraft:polished_blackstone_bricks
fill 461 44 491 461 47 491 minecraft:blackstone
setblock 462 44 464 minecraft:polished_blackstone_bricks
fill 462 44 465 462 44 468 minecraft:blackstone
setblock 462 44 469 minecraft:polished_blackstone_bricks
fill 462 44 480 462 47 480 minecraft:blackstone
setblock 462 44 484 minecraft:polished_blackstone_bricks
fill 462 44 485 462 47 485 minecraft:blackstone
setblock 462 44 489 minecraft:polished_blackstone_bricks
fill 462 44 490 462 47 490 minecraft:blackstone
setblock 462 44 494 minecraft:polished_blackstone_bricks
setblock 462 44 504 minecraft:polished_blackstone_bricks
fill 463 44 464 463 44 467 minecraft:blackstone
setblock 463 44 468 minecraft:polished_blackstone_bricks
fill 463 44 469 463 44 472 minecraft:blackstone
setblock 463 44 473 minecraft:polished_blackstone_bricks
fill 463 44 474 463 46 475 minecraft:blackstone
setblock 463 44 478 minecraft:polished_blackstone_bricks
fill 463 44 479 463 47 479 minecraft:blackstone
setblock 463 44 483 minecraft:polished_blackstone_bricks
fill 463 44 484 463 47 484 minecraft:blackstone
setblock 463 44 488 minecraft:polished_blackstone_bricks
fill 463 44 489 463 47 489 minecraft:blackstone
setblock 463 44 492 minecraft:blackstone
setblock 463 44 493 minecraft:polished_blackstone_bricks
fill 463 44 494 463 47 494 minecraft:blackstone
fill 463 44 504 463 47 504 minecraft:blackstone
setblock 464 44 467 minecraft:polished_blackstone_bricks
fill 464 44 468 464 44 471 minecraft:blackstone
setblock 464 44 472 minecraft:polished_blackstone_bricks
fill 464 44 473 464 47 473 minecraft:blackstone
setblock 464 44 477 minecraft:polished_blackstone_bricks
fill 464 44 478 464 47 478 minecraft:blackstone
setblock 464 44 482 minecraft:polished_blackstone_bricks
fill 464 44 483 464 47 483 minecraft:blackstone
setblock 464 44 487 minecraft:polished_blackstone_bricks
fill 464 44 488 464 47 488 minecraft:blackstone
setblock 464 44 492 minecraft:polished_blackstone_bricks
fill 464 44 493 464 47 493 minecraft:blackstone
setblock 464 44 497 minecraft:polished_blackstone_bricks
fill 464 44 498 464 47 498 minecraft:blackstone
setblock 464 44 502 minecraft:polished_blackstone_bricks
fill 464 44 503 464 47 503 minecraft:blackstone
fill 424 45 464 424 45 465 minecraft:blackstone
setblock 424 45 466 minecraft:polished_blackstone_bricks
fill 424 45 467 424 48 467 minecraft:blackstone
setblock 424 45 471 minecraft:polished_blackstone_bricks
fill 424 45 472 424 48 472 minecraft:blackstone
setblock 424 45 476 minecraft:polished_blackstone_bricks
fill 424 45 477 424 48 477 minecraft:blackstone
setblock 424 45 481 minecraft:polished_blackstone_bricks
fill 424 45 482 424 48 482 minecraft:blackstone
setblock 424 45 486 minecraft:polished_blackstone_bricks
fill 424 45 487 424 48 487 minecraft:blackstone
setblock 424 45 491 minecraft:polished_blackstone_bricks
fill 424 45 492 424 48 492 minecraft:blackstone
setblock 424 45 496 minecraft:polished_blackstone_bricks
fill 424 45 497 424 48 497 minecraft:blackstone
fill 424 45 502 424 46 502 minecraft:blackstone
setblock 425 45 464 minecraft:blackstone
setblock 425 45 465 minecraft:polished_blackstone_bricks
fill 425 45 466 425 48 466 minecraft:blackstone
setblock 425 45 470 minecraft:polished_blackstone_bricks
fill 425 45 471 425 48 471 minecraft:blackstone
setblock 425 45 475 minecraft:polished_blackstone_bricks
fill 425 45 476 425 48 476 minecraft:blackstone
setblock 425 45 480 minecraft:polished_blackstone_bricks
fill 425 45 481 425 47 481 minecraft:blackstone
setblock 425 45 485 minecraft:polished_blackstone_bricks
fill 425 45 486 425 48 486 minecraft:blackstone
setblock 425 45 490 minecraft:polished_blackstone_bricks
fill 425 45 491 425 48 491 minecraft:blackstone
fill 425 45 493 425 46 493 minecraft:blackstone
setblock 426 45 464 minecraft:polished_blackstone_bricks
fill 426 45 465 426 48 465 minecraft:blackstone
setblock 426 45 469 minecraft:polished_blackstone_bricks
fill 426 45 470 426 48 470 minecraft:blackstone
setblock 426 45 504 minecraft:polished_blackstone_bricks
fill 427 45 464 427 48 464 minecraft:blackstone
setblock 427 45 468 minecraft:polished_blackstone_bricks
fill 427 45 469 427 46 469 minecraft:blackstone
fill 427 45 504 427 46 504 minecraft:blackstone
setblock 428 45 466 minecraft:blackstone
setblock 429 45 466 minecraft:polished_blackstone_bricks
fill 429 45 494 429 46 494 minecraft:light_blue_stained_glass
setblock 430 45 465 minecraft:polished_blackstone_bricks
fill 430 45 466 430 47 466 minecraft:blackstone
setblock 431 45 464 minecraft:polished_blackstone_bricks
fill 431 45 465 431 48 465 minecraft:blackstone
fill 432 45 464 432 48 464 minecraft:blackstone
fill 432 45 466 433 45 466 minecraft:blackstone
fill 433 45 504 433 47 504 minecraft:blackstone
setblock 434 45 466 minecraft:polished_blackstone_bricks
setblock 435 45 465 minecraft:polished_blackstone_bricks
fill 435 45 466 435 48 466 minecraft:blackstone
setblock 436 45 464 minecraft:polished_blackstone_bricks
fill 436 45 465 436 48 465 minecraft:blackstone
setblock 436 45 504 minecraft:polished_blackstone_bricks
fill 437 45 464 437 48 464 minecraft:blackstone
setblock 437 45 503 minecraft:polished_blackstone_bricks
fill 437 45 504 437 48 504 minecraft:blackstone
setblock 438 45 466 minecraft:blackstone
setblock 438 45 467 minecraft:polished_blackstone_bricks
fill 438 45 503 438 48 503 minecraft:blackstone
setblock 439 45 466 minecraft:polished_blackstone_bricks
fill 439 45 467 439 48 467 minecraft:blackstone
setblock 440 45 465 minecraft:polished_blackstone_bricks
fill 440 45 466 440 48 466 minecraft:blackstone
setblock 441 45 464 minecraft:polished_blackstone_bricks
fill 441 45 465 441 48 465 minecraft:blackstone
fill 441 45 467 442 45 467 minecraft:blackstone
setblock 441 45 504 minecraft:polished_blackstone_bricks
fill 442 45 464 442 48 464 minecraft:blackstone
setblock 442 45 503 minecraft:polished_blackstone_bricks
fill 442 45 504 442 48 504 minecraft:blackstone
setblock 443 45 467 minecraft:polished_blackstone_bricks
setblock 443 45 502 minecraft:polished_blackstone_bricks
fill 443 45 503 443 48 503 minecraft:blackstone
setblock 444 45 466 minecraft:polished_blackstone_bricks
setblock 444 45 467 minecraft:blackstone
fill 444 45 502 444 46 502 minecraft:blackstone
setblock 445 45 465 minecraft:polished_blackstone_bricks
fill 445 45 466 445 47 466 minecraft:blackstone
setblock 446 45 464 minecraft:polished_blackstone_bricks
fill 446 45 465 446 48 465 minecraft:blackstone
setblock 446 45 504 minecraft:polished_blackstone_bricks
fill 447 45 464 447 48 464 minecraft:blackstone
setblock 447 45 503 minecraft:polished_blackstone_bricks
fill 447 45 504 447 48 504 minecraft:blackstone
setblock 448 45 503 minecraft:blackstone
setblock 451 45 464 minecraft:polished_blackstone_bricks
setblock 451 45 504 minecraft:polished_blackstone_bricks
setblock 452 45 464 minecraft:blackstone
setblock 452 45 504 minecraft:blackstone
setblock 455 45 464 minecraft:blackstone
setblock 456 45 464 minecraft:polished_blackstone_bricks
setblock 456 45 504 minecraft:polished_blackstone_bricks
fill 457 45 464 457 48 464 minecraft:blackstone
fill 457 45 504 457 48 504 minecraft:blackstone
fill 458 45 465 459 45 465 minecraft:blackstone
setblock 460 45 465 minecraft:polished_blackstone_bricks
setblock 461 45 464 minecraft:polished_blackstone_bricks
fill 461 45 465 463 45 466 minecraft:blackstone
setblock 461 45 483 minecraft:blackstone
setblock 461 45 484 minecraft:polished_blackstone_bricks
fill 461 45 485 461 48 485 minecraft:blackstone
setblock 461 45 489 minecraft:polished_blackstone_bricks
fill 461 45 490 461 48 490 minecraft:blackstone
fill 461 45 492 461 46 492 minecraft:blackstone
setblock 461 45 504 minecraft:polished_blackstone_bricks
fill 462 45 464 463 47 464 minecraft:blackstone
setblock 462 45 467 minecraft:blackstone
setblock 462 45 468 minecraft:polished_blackstone_bricks
fill 462 45 469 462 45 472 minecraft:blackstone
setblock 462 45 483 minecraft:polished_blackstone_bricks
fill 462 45 484 462 48 484 minecraft:blackstone
setblock 462 45 488 minecraft:polished_blackstone_bricks
fill 462 45 489 462 48 489 minecraft:blackstone
setblock 462 45 493 minecraft:polished_blackstone_bricks
fill 462 45 494 462 47 495 minecraft:blackstone
fill 462 45 504 462 48 504 minecraft:blackstone
setblock 463 45 467 minecraft:polished_blackstone_bricks
fill 463 45 468 463 45 471 minecraft:blackstone
setblock 463 45 472 minecraft:polished_blackstone_bricks
fill 463 45 473 463 48 473 minecraft:blackstone
setblock 463 45 476 minecraft:blackstone
setblock 463 45 477 minecraft:polished_blackstone_bricks
fill 463 45 478 463 48 478 minecraft:blackstone
setblock 463 45 482 minecraft:polished_blackstone_bricks
fill 463 45 483 463 48 483 minecraft:blackstone
setblock 463 45 487 minecraft:polished_blackstone_bricks
fill 463 45 488 463 48 488 minecraft:blackstone
setblock 463 45 492 minecraft:polished_blackstone_bricks
fill 463 45 493 463 48 493 minecraft:blackstone
setblock 463 45 497 minecraft:polished_blackstone_bricks
setblock 464 45 466 minecraft:polished_blackstone_bricks
fill 464 45 467 464 45 470 minecraft:blackstone
setblock 464 45 471 minecraft:polished_blackstone_bricks
fill 464 45 472 464 48 472 minecraft:blackstone
setblock 464 45 476 minecraft:polished_blackstone_bricks
fill 464 45 477 464 48 477 minecraft:blackstone
setblock 464 45 481 minecraft:polished_blackstone_bricks
fill 464 45 482 464 48 482 minecraft:blackstone
setblock 464 45 486 minecraft:polished_blackstone_bricks
fill 464 45 487 464 48 487 minecraft:blackstone
setblock 464 45 491 minecraft:polished_blackstone_bricks
fill 464 45 492 464 48 492 minecraft:blackstone
setblock 464 45 496 minecraft:polished_blackstone_bricks
fill 464 45 497 464 48 497 minecraft:blackstone
setblock 464 45 501 minecraft:polished_blackstone_bricks
fill 464 45 502 464 46 502 minecraft:blackstone
setblock 424 46 464 minecraft:blackstone
setblock 424 46 465 minecraft:polished_blackstone_bricks
fill 424 46 466 424 49 466 minecraft:blackstone
setblock 424 46 470 minecraft:polished_blackstone_bricks
fill 424 46 471 424 49 471 minecraft:blackstone
setblock 424 46 475 minecraft:polished_blackstone_bricks
fill 424 46 476 424 49 476 minecraft:blackstone
setblock 424 46 480 minecraft:polished_blackstone_bricks
fill 424 46 481 424 49 481 minecraft:blackstone
setblock 424 46 485 minecraft:polished_blackstone_bricks
fill 424 46 486 424 49 486 minecraft:blackstone
setblock 424 46 490 minecraft:polished_blackstone_bricks
fill 424 46 491 424 49 491 minecraft:blackstone
setblock 424 46 494 minecraft:blackstone
setblock 424 46 495 minecraft:polished_blackstone_bricks
fill 424 46 496 424 49 496 minecraft:blackstone
setblock 425 46 464 minecraft:polished_blackstone_bricks
fill 425 46 465 425 49 465 minecraft:blackstone
setblock 425 46 469 minecraft:polished_blackstone_bricks
fill 425 46 470 425 49 470 minecraft:blackstone
setblock 425 46 474 minecraft:polished_blackstone_bricks
fill 425 46 475 425 49 475 minecraft:blackstone
setblock 425 46 479 minecraft:polished_blackstone_bricks
fill 425 46 480 425 47 480 minecraft:blackstone
setblock 425 46 484 minecraft:polished_blackstone_bricks
fill 425 46 485 425 47 485 minecraft:blackstone
setblock 425 46 489 minecraft:polished_blackstone_bricks
fill 425 46 490 425 48 490 minecraft:blackstone
setblock 425 46 504 minecraft:polished_blackstone_bricks
fill 426 46 464 426 49 464 minecraft:blackstone
setblock 426 46 468 minecraft:polished_blackstone_bricks
fill 426 46 469 426 49 469 minecraft:blackstone
setblock 426 46 473 minecraft:polished_blackstone_bricks
fill 426 46 474 426 47 474 minecraft:blackstone
setblock 426 46 482 minecraft:light[level=11]
setblock 426 46 490 minecraft:light[level=11]
setblock 426 46 498 minecraft:light[level=11]
fill 426 46 504 426 47 504 minecraft:blackstone
setblock 427 46 467 minecraft:polished_blackstone_bricks
setblock 427 46 468 minecraft:blackstone
setblock 428 46 466 minecraft:polished_blackstone_bricks
setblock 429 46 465 minecraft:polished_blackstone_bricks
fill 429 46 466 429 47 466 minecraft:blackstone
setblock 430 46 464 minecraft:polished_blackstone_bricks
fill 430 46 465 430 49 465 minecraft:blackstone
fill 431 46 464 431 49 464 minecraft:blackstone
setblock 432 46 466 minecraft:blackstone
setblock 433 46 466 minecraft:polished_blackstone_bricks
setblock 434 46 465 minecraft:polished_blackstone_bricks
fill 434 46 466 434 48 466 minecraft:blackstone
setblock 434 46 474 minecraft:light[level=11]
setblock 434 46 482 minecraft:light[level=11]
setblock 434 46 490 minecraft:light[level=11]
setblock 434 46 498 minecraft:light[level=11]
setblock 435 46 464 minecraft:polished_blackstone_bricks
fill 435 46 465 435 49 465 minecraft:blackstone
setblock 435 46 504 minecraft:polished_blackstone_bricks
fill 436 46 464 436 49 464 minecraft:blackstone
fill 436 46 504 436 49 504 minecraft:blackstone
setblock 437 46 467 minecraft:polished_blackstone_bricks
fill 437 46 503 437 49 503 minecraft:blackstone
setblock 438 46 466 minecraft:polished_blackstone_bricks
fill 438 46 467 438 48 467 minecraft:blackstone
setblock 439 46 465 minecraft:polished_blackstone_bricks
fill 439 46 466 439 49 466 minecraft:blackstone
setblock 440 46 464 minecraft:polished_blackstone_bricks
fill 440 46 465 440 49 465 minecraft:blackstone
fill 440 46 502 440 47 502 minecraft:blackstone
setblock 440 46 504 minecraft:polished_blackstone_bricks
fill 441 46 464 441 49 464 minecraft:blackstone
setblock 441 46 467 minecraft:blackstone
setblock 441 46 503 minecraft:polished_blackstone_bricks
fill 441 46 504 441 49 504 minecraft:blackstone
setblock 442 46 467 minecraft:polished_blackstone_bricks
setblock 442 46 474 minecraft:light[level=11]
setblock 442 46 482 minecraft:light[level=11]
setblock 442 46 490 minecraft:light[level=11]
setblock 442 46 498 minecraft:light[level=11]
setblock 442 46 502 minecraft:polished_blackstone_bricks
fill 442 46 503 442 49 503 minecraft:blackstone
setblock 443 46 466 minecraft:polished_blackstone_bricks
fill 443 46 467 443 47 467 minecraft:blackstone
fill 443 46 502 443 47 502 minecraft:blackstone
setblock 444 46 465 minecraft:polished_blackstone_bricks
fill 444 46 466 444 48 466 minecraft:blackstone
setblock 445 46 464 minecraft:polished_blackstone_bricks
fill 445 46 465 445 48 465 minecraft:blackstone
setblock 445 46 504 minecraft:polished_blackstone_bricks
fill 446 46 464 446 49 464 minecraft:blackstone
setblock 446 46 503 minecraft:polished_blackstone_bricks
fill 446 46 504 446 49 504 minecraft:blackstone
setblock 447 46 503 minecraft:blackstone
setblock 450 46 464 minecraft:polished_blackstone_bricks
setblock 450 46 466 minecraft:light[level=11]
setblock 450 46 474 minecraft:light[level=11]
setblock 450 46 482 minecraft:light[level=11]
setblock 450 46 490 minecraft:light[level=11]
setblock 450 46 498 minecraft:light[level=11]
setblock 450 46 504 minecraft:polished_blackstone_bricks
setblock 451 46 504 minecraft:blackstone
setblock 455 46 464 minecraft:polished_blackstone_bricks
fill 456 46 464 456 48 464 minecraft:blackstone
setblock 456 46 504 minecraft:blackstone
setblock 458 46 465 minecraft:blackstone
setblock 458 46 466 minecraft:light[level=11]
setblock 458 46 474 minecraft:light[level=11]
setblock 458 46 482 minecraft:light[level=11]
setblock 458 46 490 minecraft:light[level=11]
setblock 458 46 498 minecraft:light[level=11]
setblock 459 46 465 minecraft:polished_blackstone_bricks
setblock 460 46 464 minecraft:polished_blackstone_bricks
fill 460 46 465 462 46 466 minecraft:blackstone
setblock 460 46 488 minecraft:blackstone
setblock 460 46 489 minecraft:polished_blackstone_bricks
fill 460 46 490 460 48 490 minecraft:blackstone
setblock 460 46 504 minecraft:polished_blackstone_bricks
fill 461 46 464 461 49 464 minecraft:blackstone
fill 461 46 484 461 47 484 minecraft:blackstone
setblock 461 46 488 minecraft:polished_blackstone_bricks
fill 461 46 489 461 49 489 minecraft:blackstone
setblock 461 46 493 minecraft:polished_blackstone_bricks
fill 461 46 504 461 48 504 minecraft:blackstone
setblock 462 46 467 minecraft:polished_blackstone_bricks
fill 462 46 468 462 46 471 minecraft:blackstone
setblock 462 46 472 minecraft:polished_blackstone_bricks
fill 462 46 473 462 47 475 minecraft:blackstone
fill 462 46 479 462 47 479 minecraft:blackstone
setblock 462 46 482 minecraft:polished_blackstone_bricks
fill 462 46 483 462 49 483 minecraft:blackstone
setblock 462 46 487 minecraft:polished_blackstone_bricks
fill 462 46 488 462 49 488 minecraft:blackstone
setblock 462 46 492 minecraft:polished_blackstone_bricks
fill 462 46 493 462 49 493 minecraft:blackstone
setblock 463 46 465 minecraft:blackstone
setblock 463 46 466 minecraft:polished_blackstone_bricks
fill 463 46 467 463 46 470 minecraft:blackstone
setblock 463 46 471 minecraft:polished_blackstone_bricks
fill 463 46 472 463 49 472 minecraft:blackstone
setblock 463 46 476 minecraft:polished_blackstone_bricks
fill 463 46 477 463 49 477 minecraft:blackstone
setblock 463 46 481 minecraft:polished_blackstone_bricks
fill 463 46 482 463 49 482 minecraft:blackstone
setblock 463 46 486 minecraft:polished_blackstone_bricks
fill 463 46 487 463 49 487 minecraft:blackstone
setblock 463 46 491 minecraft:polished_blackstone_bricks
fill 463 46 492 463 49 492 minecraft:blackstone
setblock 463 46 495 minecraft:blackstone
setblock 463 46 496 minecraft:polished_blackstone_bricks
fill 463 46 497 463 49 497 minecraft:blackstone
setblock 464 46 465 minecraft:polished_blackstone_bricks
fill 464 46 466 464 46 469 minecraft:blackstone
setblock 464 46 470 minecraft:polished_blackstone_bricks
fill 464 46 471 464 49 471 minecraft:blackstone
setblock 464 46 475 minecraft:polished_blackstone_bricks
fill 464 46 476 464 49 476 minecraft:blackstone
setblock 464 46 480 minecraft:polished_blackstone_bricks
fill 464 46 481 464 49 481 minecraft:blackstone
setblock 464 46 485 minecraft:polished_blackstone_bricks
fill 464 46 486 464 49 486 minecraft:blackstone
setblock 464 46 490 minecraft:polished_blackstone_bricks
fill 464 46 491 464 49 491 minecraft:blackstone
setblock 464 46 495 minecraft:polished_blackstone_bricks
fill 464 46 496 464 49 496 minecraft:blackstone
setblock 464 46 500 minecraft:polished_blackstone_bricks
setblock 464 46 501 minecraft:blackstone
setblock 424 47 464 minecraft:polished_blackstone_bricks
fill 424 47 465 424 50 465 minecraft:blackstone
setblock 424 47 469 minecraft:polished_blackstone_bricks
fill 424 47 470 424 50 470 minecraft:blackstone
setblock 424 47 474 minecraft:polished_blackstone_bricks
fill 424 47 475 424 50 475 minecraft:blackstone
setblock 424 47 479 minecraft:polished_blackstone_bricks
fill 424 47 480 424 50 480 minecraft:blackstone
setblock 424 47 484 minecraft:polished_blackstone_bricks
fill 424 47 485 424 49 485 minecraft:blackstone
setblock 424 47 489 minecraft:polished_blackstone_bricks
fill 424 47 490 424 50 490 minecraft:blackstone
setblock 424 47 494 minecraft:polished_blackstone_bricks
fill 424 47 495 424 50 495 minecraft:blackstone
setblock 424 47 504 minecraft:polished_blackstone_bricks
fill 425 47 464 425 50 464 minecraft:blackstone
setblock 425 47 468 minecraft:polished_blackstone_bricks
fill 425 47 469 425 50 469 minecraft:blackstone
setblock 425 47 473 minecraft:polished_blackstone_bricks
fill 425 47 474 425 50 474 minecraft:blackstone
setblock 425 47 478 minecraft:polished_blackstone_bricks
setblock 425 47 479 minecraft:blackstone
setblock 425 47 483 minecraft:polished_blackstone_bricks
setblock 425 47 484 minecraft:blackstone
setblock 425 47 488 minecraft:polished_blackstone_bricks
fill 425 47 489 425 48 489 minecraft:blackstone
setblock 425 47 493 minecraft:polished_blackstone_bricks
setblock 425 47 504 minecraft:blackstone
setblock 426 47 467 minecraft:polished_blackstone_bricks
fill 426 47 468 426 50 468 minecraft:blackstone
setblock 426 47 472 minecraft:polished_blackstone_bricks
fill 426 47 473 426 49 473 minecraft:blackstone
setblock 427 47 466 minecraft:polished_blackstone_bricks
setblock 428 47 465 minecraft:polished_blackstone_bricks
setblock 428 47 466 minecraft:blackstone
setblock 429 47 464 minecraft:polished_blackstone_bricks
fill 429 47 465 429 49 465 minecraft:blackstone
fill 430 47 464 430 50 464 minecraft:blackstone
setblock 432 47 466 minecraft:polished_blackstone_bricks
setblock 433 47 465 minecraft:polished_blackstone_bricks
setblock 433 47 466 minecraft:blackstone
setblock 434 47 464 minecraft:polished_blackstone_bricks
fill 434 47 465 434 50 465 minecraft:blackstone
setblock 434 47 504 minecraft:polished_blackstone_bricks
fill 435 47 464 435 50 464 minecraft:blackstone
fill 435 47 504 435 50 504 minecraft:blackstone
setblock 437 47 466 minecraft:polished_blackstone_bricks
fill 437 47 467 437 48 467 minecraft:blackstone
setblock 438 47 465 minecraft:polished_blackstone_bricks
fill 438 47 466 438 50 466 minecraft:blackstone
setblock 439 47 464 minecraft:polished_blackstone_bricks
fill 439 47 465 439 50 465 minecraft:blackstone
setblock 439 47 504 minecraft:polished_blackstone_bricks
fill 440 47 464 440 50 464 minecraft:blackstone
setblock 440 47 503 minecraft:polished_blackstone_bricks
fill 440 47 504 440 50 504 minecraft:blackstone
setblock 441 47 467 minecraft:polished_blackstone_bricks
setblock 441 47 502 minecraft:polished_blackstone_bricks
fill 441 47 503 441 50 503 minecraft:blackstone
setblock 442 47 466 minecraft:polished_blackstone_bricks
setblock 442 47 467 minecraft:blackstone
fill 442 47 502 442 48 502 minecraft:blackstone
setblock 443 47 465 minecraft:polished_blackstone_bricks
fill 443 47 466 443 48 466 minecraft:blackstone
setblock 444 47 464 minecraft:polished_blackstone_bricks
fill 444 47 465 444 49 465 minecraft:blackstone
setblock 444 47 504 minecraft:polished_blackstone_bricks
fill 445 47 464 445 49 464 minecraft:blackstone
setblock 445 47 503 minecraft:polished_blackstone_bricks
fill 445 47 504 445 50 504 minecraft:blackstone
setblock 446 47 503 minecraft:blackstone
setblock 449 47 464 minecraft:polished_blackstone_bricks
setblock 449 47 504 minecraft:polished_blackstone_bricks
setblock 458 47 465 minecraft:polished_blackstone_bricks
setblock 459 47 464 minecraft:polished_blackstone_bricks
fill 459 47 465 462 47 465 minecraft:blackstone
setblock 459 47 504 minecraft:polished_blackstone_bricks
fill 460 47 464 460 50 464 minecraft:blackstone
fill 460 47 466 461 47 466 minecraft:blackstone
setblock 460 47 488 minecraft:polished_blackstone_bricks
setblock 460 47 489 minecraft:blackstone
setblock 460 47 491 minecraft:blackstone
fill 460 47 504 460 49 504 minecraft:blackstone
setblock 461 47 487 minecraft:polished_blackstone_bricks
fill 461 47 488 461 49 488 minecraft:blackstone
setblock 461 47 492 minecraft:polished_blackstone_bricks
fill 461 47 493 461 48 494 minecraft:blackstone
setblock 462 47 466 minecraft:polished_blackstone_bricks
fill 462 47 467 462 47 470 minecraft:blackstone
setblock 462 47 471 minecraft:polished_blackstone_bricks
fill 462 47 472 462 50 472 minecraft:blackstone
setblock 462 47 476 minecraft:polished_blackstone_bricks
fill 462 47 477 462 48 478 minecraft:blackstone
setblock 462 47 481 minecraft:polished_blackstone_bricks
fill 462 47 482 462 48 482 minecraft:blackstone
setblock 462 47 486 minecraft:polished_blackstone_bricks
fill 462 47 487 462 50 487 minecraft:blackstone
setblock 462 47 491 minecraft:polished_blackstone_bricks
fill 462 47 492 462 50 492 minecraft:blackstone
setblock 463 47 465 minecraft:polished_blackstone_bricks
fill 463 47 466 463 47 469 minecraft:blackstone
setblock 463 47 470 minecraft:polished_blackstone_bricks
fill 463 47 471 463 50 471 minecraft:blackstone
setblock 463 47 474 minecraft:blackstone
setblock 463 47 475 minecraft:polished_blackstone_bricks
fill 463 47 476 463 50 476 minecraft:blackstone
setblock 463 47 480 minecraft:polished_blackstone_bricks
fill 463 47 481 463 50 481 minecraft:blackstone
setblock 463 47 485 minecraft:polished_blackstone_bricks
fill 463 47 486 463 50 486 minecraft:blackstone
setblock 463 47 490 minecraft:polished_blackstone_bricks
fill 463 47 491 463 50 491 minecraft:blackstone
setblock 463 47 495 minecraft:polished_blackstone_bricks
fill 463 47 496 463 50 496 minecraft:blackstone
setblock 464 47 464 minecraft:polished_blackstone_bricks
fill 464 47 465 464 47 468 minecraft:blackstone
setblock 464 47 469 minecraft:polished_blackstone_bricks
fill 464 47 470 464 50 470 minecraft:blackstone
setblock 464 47 474 minecraft:polished_blackstone_bricks
fill 464 47 475 464 50 475 minecraft:blackstone
setblock 464 47 479 minecraft:polished_blackstone_bricks
fill 464 47 480 464 50 480 minecraft:blackstone
setblock 464 47 484 minecraft:polished_blackstone_bricks
fill 464 47 485 464 50 485 minecraft:blackstone
setblock 464 47 489 minecraft:polished_blackstone_bricks
fill 464 47 490 464 50 490 minecraft:blackstone
setblock 464 47 494 minecraft:polished_blackstone_bricks
fill 464 47 495 464 50 495 minecraft:blackstone
setblock 464 47 499 minecraft:polished_blackstone_bricks
setblock 464 47 500 minecraft:blackstone
setblock 464 47 504 minecraft:polished_blackstone_bricks
fill 424 48 464 424 51 464 minecraft:blackstone
setblock 424 48 468 minecraft:polished_blackstone_bricks
fill 424 48 469 424 51 469 minecraft:blackstone
setblock 424 48 473 minecraft:polished_blackstone_bricks
fill 424 48 474 424 51 474 minecraft:blackstone
setblock 424 48 478 minecraft:polished_blackstone_bricks
fill 424 48 479 424 51 479 minecraft:blackstone
setblock 424 48 483 minecraft:polished_blackstone_bricks
fill 424 48 484 424 49 484 minecraft:blackstone
setblock 424 48 488 minecraft:polished_blackstone_bricks
fill 424 48 489 424 50 489 minecraft:blackstone
setblock 424 48 493 minecraft:polished_blackstone_bricks
fill 424 48 494 424 51 494 minecraft:blackstone
setblock 424 48 504 minecraft:blackstone
setblock 425 48 467 minecraft:polished_blackstone_bricks
fill 425 48 468 425 51 468 minecraft:blackstone
setblock 425 48 472 minecraft:polished_blackstone_bricks
fill 425 48 473 425 51 473 minecraft:blackstone
setblock 425 48 477 minecraft:polished_blackstone_bricks
setblock 425 48 487 minecraft:polished_blackstone_bricks
setblock 425 48 488 minecraft:blackstone
setblock 425 48 492 minecraft:polished_blackstone_bricks
setblock 425 48 493 minecraft:blackstone
setblock 426 48 466 minecraft:polished_blackstone_bricks
fill 426 48 467 426 49 467 minecraft:blackstone
setblock 426 48 471 minecraft:polished_blackstone_bricks
fill 426 48 472 426 50 472 minecraft:blackstone
setblock 427 48 465 minecraft:polished_blackstone_bricks
setblock 427 48 466 minecraft:blackstone
setblock 428 48 464 minecraft:polished_blackstone_bricks
fill 428 48 465 428 49 465 minecraft:blackstone
fill 429 48 464 429 50 464 minecraft:blackstone
setblock 432 48 465 minecraft:polished_blackstone_bricks
setblock 433 48 464 minecraft:polished_blackstone_bricks
fill 433 48 465 433 50 465 minecraft:blackstone
fill 434 48 464 434 51 464 minecraft:blackstone
fill 434 48 504 434 51 504 minecraft:blackstone
setblock 436 48 466 minecraft:polished_blackstone_bricks
setblock 437 48 465 minecraft:polished_blackstone_bricks
fill 437 48 466 437 50 466 minecraft:blackstone
setblock 438 48 464 minecraft:polished_blackstone_bricks
fill 438 48 465 438 51 465 minecraft:blackstone
setblock 438 48 504 minecraft:polished_blackstone_bricks
fill 439 48 464 439 51 464 minecraft:blackstone
setblock 439 48 503 minecraft:polished_blackstone_bricks
fill 439 48 504 439 51 504 minecraft:blackstone
setblock 440 48 467 minecraft:polished_blackstone_bricks
setblock 440 48 502 minecraft:polished_blackstone_bricks
fill 440 48 503 440 51 503 minecraft:blackstone
setblock 441 48 466 minecraft:polished_blackstone_bricks
setblock 441 48 467 minecraft:blackstone
setblock 441 48 502 minecraft:blackstone
setblock 442 48 465 minecraft:polished_blackstone_bricks
fill 442 48 466 442 49 466 minecraft:blackstone
setblock 443 48 464 minecraft:polished_blackstone_bricks
fill 443 48 465 443 50 465 minecraft:blackstone
setblock 443 48 504 minecraft:polished_blackstone_bricks
fill 444 48 464 444 50 464 minecraft:blackstone
setblock 444 48 503 minecraft:polished_blackstone_bricks
fill 444 48 504 444 51 504 minecraft:blackstone
setblock 445 48 503 minecraft:blackstone
setblock 448 48 504 minecraft:polished_blackstone_bricks
setblock 458 48 464 minecraft:polished_blackstone_bricks
fill 458 48 465 461 48 465 minecraft:blackstone
setblock 458 48 504 minecraft:polished_blackstone_bricks
fill 459 48 464 459 51 464 minecraft:blackstone
fill 459 48 504 459 49 504 minecraft:blackstone
setblock 461 48 466 minecraft:polished_blackstone_bricks
setblock 461 48 486 minecraft:polished_blackstone_bricks
fill 461 48 487 461 49 487 minecraft:blackstone
setblock 461 48 491 minecraft:polished_blackstone_bricks
fill 461 48 492 461 50 492 minecraft:blackstone
setblock 462 48 464 minecraft:blackstone
setblock 462 48 465 minecraft:polished_blackstone_bricks
fill 462 48 466 462 48 469 minecraft:blackstone
setblock 462 48 470 minecraft:polished_blackstone_bricks
fill 462 48 471 462 51 471 minecraft:blackstone
fill 462 48 473 462 48 474 minecraft:blackstone
setblock 462 48 475 minecraft:polished_blackstone_bricks
fill 462 48 476 462 51 476 minecraft:blackstone
setblock 462 48 481 minecraft:blackstone
setblock 462 48 485 minecraft:polished_blackstone_bricks
fill 462 48 486 462 50 486 minecraft:blackstone
setblock 462 48 490 minecraft:polished_blackstone_bricks
fill 462 48 491 462 51 491 minecraft:blackstone
setblock 462 48 494 minecraft:blackstone
setblock 462 48 495 minecraft:polished_blackstone_bricks
setblock 463 48 464 minecraft:polished_blackstone_bricks
fill 463 48 465 463 48 468 minecraft:blackstone
setblock 463 48 469 minecraft:polished_blackstone_bricks
fill 463 48 470 463 51 470 minecraft:blackstone
setblock 463 48 474 minecraft:polished_blackstone_bricks
fill 463 48 475 463 51 475 minecraft:blackstone
setblock 463 48 479 minecraft:polished_blackstone_bricks
fill 463 48 480 463 51 480 minecraft:blackstone
setblock 463 48 484 minecraft:polished_blackstone_bricks
fill 463 48 485 463 50 485 minecraft:blackstone
setblock 463 48 489 minecraft:polished_blackstone_bricks
fill 463 48 490 463 51 490 minecraft:blackstone
setblock 463 48 494 minecraft:polished_blackstone_bricks
fill 463 48 495 463 51 495 minecraft:blackstone
setblock 463 48 504 minecraft:polished_blackstone_bricks
fill 464 48 464 464 48 467 minecraft:blackstone
setblock 464 48 468 minecraft:polished_blackstone_bricks
fill 464 48 469 464 51 469 minecraft:blackstone
setblock 464 48 473 minecraft:polished_blackstone_bricks
fill 464 48 474 464 51 474 minecraft:blackstone
setblock 464 48 478 minecraft:polished_blackstone_bricks
fill 464 48 479 464 51 479 minecraft:blackstone
setblock 464 48 483 minecraft:polished_blackstone_bricks
fill 464 48 484 464 51 484 minecraft:blackstone
setblock 464 48 488 minecraft:polished_blackstone_bricks
fill 464 48 489 464 51 489 minecraft:blackstone
setblock 464 48 493 minecraft:polished_blackstone_bricks
fill 464 48 494 464 51 494 minecraft:blackstone
setblock 464 48 498 minecraft:polished_blackstone_bricks
setblock 464 48 499 minecraft:blackstone
setblock 424 49 467 minecraft:polished_blackstone_bricks
fill 424 49 468 424 52 468 minecraft:blackstone
setblock 424 49 472 minecraft:polished_blackstone_bricks
fill 424 49 473 424 52 473 minecraft:blackstone
setblock 424 49 477 minecraft:polished_blackstone_bricks
fill 424 49 478 424 52 478 minecraft:blackstone
setblock 424 49 482 minecraft:polished_blackstone_bricks
setblock 424 49 483 minecraft:blackstone
setblock 424 49 487 minecraft:polished_blackstone_bricks
fill 424 49 488 424 50 488 minecraft:blackstone
setblock 424 49 492 minecraft:polished_blackstone_bricks
fill 424 49 493 424 51 493 minecraft:blackstone
setblock 424 49 497 minecraft:polished_blackstone_bricks
setblock 425 49 466 minecraft:polished_blackstone_bricks
fill 425 49 467 425 51 467 minecraft:blackstone
setblock 425 49 471 minecraft:polished_blackstone_bricks
fill 425 49 472 425 52 472 minecraft:blackstone
setblock 425 49 476 minecraft:polished_blackstone_bricks
setblock 425 49 477 minecraft:blackstone
setblock 426 49 465 minecraft:polished_blackstone_bricks
setblock 426 49 470 minecraft:polished_blackstone_bricks
fill 426 49 471 426 50 471 minecraft:blackstone
setblock 427 49 464 minecraft:polished_blackstone_bricks
setblock 427 49 465 minecraft:blackstone
fill 428 49 464 428 50 464 minecraft:blackstone
setblock 431 49 465 minecraft:polished_blackstone_bricks
setblock 432 49 464 minecraft:polished_blackstone_bricks
setblock 432 49 465 minecraft:blackstone
fill 433 49 464 433 52 464 minecraft:blackstone
setblock 435 49 466 minecraft:polished_blackstone_bricks
setblock 436 49 465 minecraft:polished_blackstone_bricks
fill 436 49 466 436 50 466 minecraft:blackstone
setblock 437 49 464 minecraft:polished_blackstone_bricks
fill 437 49 465 437 52 465 minecraft:blackstone
setblock 437 49 504 minecraft:polished_blackstone_bricks
fill 438 49 464 438 52 464 minecraft:blackstone
setblock 438 49 503 minecraft:polished_blackstone_bricks
fill 438 49 504 438 52 504 minecraft:blackstone
fill 439 49 503 439 52 503 minecraft:blackstone
setblock 440 49 466 minecraft:polished_blackstone_bricks
setblock 441 49 465 minecraft:polished_blackstone_bricks
setblock 441 49 466 minecraft:blackstone
setblock 442 49 464 minecraft:polished_blackstone_bricks
fill 442 49 465 442 50 465 minecraft:blackstone
setblock 442 49 504 minecraft:polished_blackstone_bricks
fill 443 49 464 443 51 464 minecraft:blackstone
setblock 443 49 503 minecraft:polished_blackstone_bricks
fill 443 49 504 443 52 504 minecraft:blackstone
setblock 444 49 503 minecraft:blackstone
setblock 457 49 464 minecraft:polished_blackstone_bricks
fill 458 49 464 458 50 464 minecraft:blackstone
fill 459 49 465 460 49 465 minecraft:blackstone
setblock 461 49 465 minecraft:polished_blackstone_bricks
setblock 461 49 490 minecraft:polished_blackstone_bricks
fill 461 49 491 461 50 491 minecraft:blackstone
setblock 461 49 493 minecraft:blackstone
setblock 462 49 464 minecraft:polished_blackstone_bricks
fill 462 49 465 464 49 465 minecraft:blackstone
fill 462 49 467 462 49 468 minecraft:blackstone
setblock 462 49 469 minecraft:polished_blackstone_bricks
fill 462 49 470 462 51 470 minecraft:blackstone
setblock 462 49 473 minecraft:blackstone
setblock 462 49 474 minecraft:polished_blackstone_bricks
fill 462 49 475 462 52 475 minecraft:blackstone
fill 462 49 477 462 50 477 minecraft:blackstone
setblock 462 49 484 minecraft:polished_blackstone_bricks
setblock 462 49 485 minecraft:blackstone
setblock 462 49 489 minecraft:polished_blackstone_bricks
fill 462 49 490 462 51 490 minecraft:blackstone
setblock 462 49 494 minecraft:polished_blackstone_bricks
fill 462 49 495 462 50 495 minecraft:blackstone
fill 463 49 464 464 50 464 minecraft:blackstone
fill 463 49 466 463 49 467 minecraft:blackstone
setblock 463 49 468 minecraft:polished_blackstone_bricks
fill 463 49 469 463 52 469 minecraft:blackstone
setblock 463 49 473 minecraft:polished_blackstone_bricks
fill 463 49 474 463 52 474 minecraft:blackstone
setblock 463 49 478 minecraft:polished_blackstone_bricks
fill 463 49 479 463 52 479 minecraft:blackstone
setblock 463 49 483 minecraft:polished_blackstone_bricks
fill 463 49 484 463 50 484 minecraft:blackstone
setblock 463 49 488 minecraft:polished_blackstone_bricks
fill 463 49 489 463 52 489 minecraft:blackstone
setblock 463 49 493 minecraft:polished_blackstone_bricks
fill 463 49 494 463 52 494 minecraft:blackstone
setblock 464 49 466 minecraft:blackstone
setblock 464 49 467 minecraft:polished_blackstone_bricks
fill 464 49 468 464 52 468 minecraft:blackstone
setblock 464 49 472 minecraft:polished_blackstone_bricks
fill 464 49 473 464 52 473 minecraft:blackstone
setblock 464 49 477 minecraft:polished_blackstone_bricks
fill 464 49 478 464 52 478 minecraft:blackstone
setblock 464 49 482 minecraft:polished_blackstone_bricks
fill 464 49 483 464 51 483 minecraft:blackstone
setblock 464 49 487 minecraft:polished_blackstone_bricks
fill 464 49 488 464 52 488 minecraft:blackstone
setblock 464 49 492 minecraft:polished_blackstone_bricks
fill 464 49 493 464 52 493 minecraft:blackstone
setblock 464 49 497 minecraft:polished_blackstone_bricks
setblock 464 49 498 minecraft:blackstone
setblock 424 50 466 minecraft:polished_blackstone_bricks
fill 424 50 467 424 53 467 minecraft:blackstone
setblock 424 50 471 minecraft:polished_blackstone_bricks
fill 424 50 472 424 53 472 minecraft:blackstone
setblock 424 50 476 minecraft:polished_blackstone_bricks
fill 424 50 477 424 53 477 minecraft:blackstone
setblock 424 50 486 minecraft:polished_blackstone_bricks
setblock 424 50 487 minecraft:blackstone
setblock 424 50 491 minecraft:polished_blackstone_bricks
fill 424 50 492 424 51 492 minecraft:blackstone
setblock 424 50 496 minecraft:polished_blackstone_bricks
setblock 425 50 465 minecraft:polished_blackstone_bricks
fill 425 50 466 425 51 466 minecraft:blackstone
setblock 425 50 470 minecraft:polished_blackstone_bricks
fill 425 50 471 425 53 471 minecraft:blackstone
setblock 425 50 475 minecraft:polished_blackstone_bricks
setblock 425 50 476 minecraft:blackstone
setblock 426 50 464 minecraft:polished_blackstone_bricks
setblock 426 50 465 minecraft:blackstone
setblock 426 50 469 minecraft:polished_blackstone_bricks
setblock 426 50 470 minecraft:blackstone
setblock 427 50 464 minecraft:blackstone
setblock 431 50 464 minecraft:polished_blackstone_bricks
fill 432 50 464 432 52 464 minecraft:blackstone
setblock 435 50 465 minecraft:polished_blackstone_bricks
setblock 436 50 464 minecraft:polished_blackstone_bricks
fill 436 50 465 436 52 465 minecraft:blackstone
setblock 436 50 504 minecraft:polished_blackstone_bricks
fill 437 50 464 437 53 464 minecraft:blackstone
setblock 437 50 503 minecraft:polished_blackstone_bricks
fill 437 50 504 437 53 504 minecraft:blackstone
fill 438 50 503 438 53 503 minecraft:blackstone
setblock 439 50 466 minecraft:polished_blackstone_bricks
setblock 440 50 465 minecraft:polished_blackstone_bricks
setblock 440 50 466 minecraft:blackstone
setblock 441 50 464 minecraft:polished_blackstone_bricks
fill 441 50 465 441 51 465 minecraft:blackstone
setblock 441 50 504 minecraft:polished_blackstone_bricks
fill 442 50 464 442 51 464 minecraft:blackstone
setblock 442 50 503 minecraft:polished_blackstone_bricks
fill 442 50 504 442 53 504 minecraft:blackstone
setblock 443 50 503 minecraft:blackstone
setblock 461 50 464 minecraft:polished_blackstone_bricks
setblock 461 50 489 minecraft:polished_blackstone_bricks
setblock 461 50 490 minecraft:blackstone
setblock 462 50 464 minecraft:blackstone
setblock 462 50 468 minecraft:polished_blackstone_bricks
fill 462 50 469 462 51 469 minecraft:blackstone
setblock 462 50 473 minecraft:polished_blackstone_bricks
fill 462 50 474 462 53 474 minecraft:blackstone
setblock 462 50 488 minecraft:polished_blackstone_bricks
fill 462 50 489 462 51 489 minecraft:blackstone
setblock 462 50 493 minecraft:polished_blackstone_bricks
fill 462 50 494 462 51 494 minecraft:blackstone
setblock 463 50 466 minecraft:blackstone
setblock 463 50 467 minecraft:polished_blackstone_bricks
fill 463 50 468 463 52 468 minecraft:blackstone
setblock 463 50 472 minecraft:polished_blackstone_bricks
fill 463 50 473 463 53 473 minecraft:blackstone
setblock 463 50 477 minecraft:polished_blackstone_bricks
fill 463 50 478 463 53 478 minecraft:blackstone
setblock 463 50 482 minecraft:polished_blackstone_bricks
setblock 463 50 483 minecraft:blackstone
setblock 463 50 487 minecraft:polished_blackstone_bricks
fill 463 50 488 463 51 488 minecraft:blackstone
setblock 463 50 492 minecraft:polished_blackstone_bricks
fill 463 50 493 463 52 493 minecraft:blackstone
setblock 464 50 465 minecraft:blackstone
setblock 464 50 466 minecraft:polished_blackstone_bricks
fill 464 50 467 464 52 467 minecraft:blackstone
setblock 464 50 471 minecraft:polished_blackstone_bricks
fill 464 50 472 464 53 472 minecraft:blackstone
setblock 464 50 476 minecraft:polished_blackstone_bricks
fill 464 50 477 464 53 477 minecraft:blackstone
setblock 464 50 481 minecraft:polished_blackstone_bricks
fill 464 50 482 464 52 482 minecraft:blackstone
setblock 464 50 486 minecraft:polished_blackstone_bricks
fill 464 50 487 464 52 487 minecraft:blackstone
setblock 464 50 491 minecraft:polished_blackstone_bricks
fill 464 50 492 464 53 492 minecraft:blackstone
setblock 464 50 496 minecraft:polished_blackstone_bricks
fill 464 50 497 464 51 497 minecraft:blackstone
setblock 424 51 465 minecraft:polished_blackstone_bricks
fill 424 51 466 424 53 466 minecraft:blackstone
setblock 424 51 470 minecraft:polished_blackstone_bricks
fill 424 51 471 424 54 471 minecraft:blackstone
setblock 424 51 475 minecraft:polished_blackstone_bricks
fill 424 51 476 424 54 476 minecraft:blackstone
setblock 424 51 490 minecraft:polished_blackstone_bricks
setblock 424 51 491 minecraft:blackstone
setblock 424 51 495 minecraft:polished_blackstone_bricks
setblock 425 51 464 minecraft:polished_blackstone_bricks
setblock 425 51 469 minecraft:polished_blackstone_bricks
fill 425 51 470 425 53 470 minecraft:blackstone
setblock 425 51 474 minecraft:polished_blackstone_bricks
fill 425 51 475 425 52 475 minecraft:blackstone
setblock 426 51 464 minecraft:blackstone
setblock 431 51 464 minecraft:blackstone
setblock 434 51 465 minecraft:polished_blackstone_bricks
setblock 435 51 464 minecraft:polished_blackstone_bricks
fill 435 51 465 435 52 465 minecraft:blackstone
setblock 435 51 504 minecraft:polished_blackstone_bricks
fill 436 51 464 436 54 464 minecraft:blackstone
fill 436 51 504 436 54 504 minecraft:blackstone
fill 437 51 503 437 54 503 minecraft:blackstone
setblock 439 51 465 minecraft:polished_blackstone_bricks
setblock 440 51 464 minecraft:polished_blackstone_bricks
setblock 440 51 465 minecraft:blackstone
setblock 440 51 504 minecraft:polished_blackstone_bricks
fill 441 51 464 441 52 464 minecraft:blackstone
setblock 441 51 503 minecraft:polished_blackstone_bricks
fill 441 51 504 441 54 504 minecraft:blackstone
setblock 442 51 503 minecraft:blackstone
setblock 460 51 464 minecraft:polished_blackstone_bricks
setblock 461 51 464 minecraft:blackstone
setblock 462 51 472 minecraft:polished_blackstone_bricks
fill 462 51 473 462 54 473 minecraft:blackstone
setblock 462 51 492 minecraft:polished_blackstone_bricks
setblock 462 51 493 minecraft:blackstone
setblock 463 51 467 minecraft:blackstone
setblock 463 51 471 minecraft:polished_blackstone_bricks
fill 463 51 472 463 54 472 minecraft:blackstone
setblock 463 51 476 minecraft:polished_blackstone_bricks
fill 463 51 477 463 54 477 minecraft:blackstone
setblock 463 51 486 minecraft:polished_blackstone_bricks
setblock 463 51 487 minecraft:blackstone
setblock 463 51 491 minecraft:polished_blackstone_bricks
fill 463 51 492 463 52 492 minecraft:blackstone
setblock 464 51 465 minecraft:polished_blackstone_bricks
setblock 464 51 466 minecraft:blackstone
setblock 464 51 470 minecraft:polished_blackstone_bricks
fill 464 51 471 464 54 471 minecraft:blackstone
setblock 464 51 475 minecraft:polished_blackstone_bricks
fill 464 51 476 464 54 476 minecraft:blackstone
setblock 464 51 480 minecraft:polished_blackstone_bricks
fill 464 51 481 464 52 481 minecraft:blackstone
setblock 464 51 485 minecraft:polished_blackstone_bricks
fill 464 51 486 464 52 486 minecraft:blackstone
setblock 464 51 490 minecraft:polished_blackstone_bricks
fill 464 51 491 464 53 491 minecraft:blackstone
setblock 464 51 495 minecraft:polished_blackstone_bricks
fill 464 51 496 464 52 496 minecraft:blackstone
setblock 424 52 464 minecraft:polished_blackstone_bricks
setblock 424 52 465 minecraft:blackstone
setblock 424 52 469 minecraft:polished_blackstone_bricks
fill 424 52 470 424 55 470 minecraft:blackstone
setblock 424 52 474 minecraft:polished_blackstone_bricks
fill 424 52 475 424 55 475 minecraft:blackstone
setblock 425 52 468 minecraft:polished_blackstone_bricks
fill 425 52 469 425 53 469 minecraft:blackstone
setblock 425 52 473 minecraft:polished_blackstone_bricks
fill 425 52 474 425 54 474 minecraft:blackstone
setblock 434 52 464 minecraft:polished_blackstone_bricks
setblock 434 52 504 minecraft:polished_blackstone_bricks
fill 435 52 464 435 55 464 minecraft:blackstone
fill 435 52 504 435 55 504 minecraft:blackstone
setblock 438 52 465 minecraft:polished_blackstone_bricks
setblock 439 52 464 minecraft:polished_blackstone_bricks
setblock 439 52 465 minecraft:blackstone
setblock 439 52 504 minecraft:polished_blackstone_bricks
fill 440 52 464 440 53 464 minecraft:blackstone
setblock 440 52 503 minecraft:polished_blackstone_bricks
fill 440 52 504 440 55 504 minecraft:blackstone
setblock 441 52 503 minecraft:blackstone
setblock 462 52 471 minecraft:polished_blackstone_bricks
fill 462 52 472 462 54 472 minecraft:blackstone
setblock 462 52 476 minecraft:polished_blackstone_bricks
setblock 463 52 470 minecraft:polished_blackstone_bricks
fill 463 52 471 463 55 471 minecraft:blackstone
setblock 463 52 475 minecraft:polished_blackstone_bricks
fill 463 52 476 463 55 476 minecraft:blackstone
setblock 463 52 490 minecraft:polished_blackstone_bricks
setblock 463 52 491 minecraft:blackstone
setblock 464 52 469 minecraft:polished_blackstone_bricks
fill 464 52 470 464 55 470 minecraft:blackstone
setblock 464 52 474 minecraft:polished_blackstone_bricks
fill 464 52 475 464 55 475 minecraft:blackstone
setblock 464 52 479 minecraft:polished_blackstone_bricks
fill 464 52 480 464 55 480 minecraft:blackstone
setblock 464 52 489 minecraft:polished_blackstone_bricks
fill 464 52 490 464 53 490 minecraft:blackstone
setblock 464 52 494 minecraft:polished_blackstone_bricks
fill 464 52 495 464 53 495 minecraft:blackstone
setblock 424 53 468 minecraft:polished_blackstone_bricks
fill 424 53 469 424 56 469 minecraft:blackstone
setblock 424 53 473 minecraft:polished_blackstone_bricks
fill 424 53 474 424 56 474 minecraft:blackstone
setblock 424 53 478 minecraft:polished_blackstone_bricks
setblock 425 53 472 minecraft:polished_blackstone_bricks
fill 425 53 473 425 54 473 minecraft:blackstone
setblock 433 53 464 minecraft:polished_blackstone_bricks
fill 434 53 464 434 56 464 minecraft:blackstone
fill 434 53 504 434 56 504 minecraft:blackstone
fill 436 53 503 436 55 503 minecraft:blackstone
setblock 438 53 464 minecraft:polished_blackstone_bricks
setblock 438 53 504 minecraft:polished_blackstone_bricks
fill 439 53 464 439 55 464 minecraft:blackstone
setblock 439 53 503 minecraft:polished_blackstone_bricks
fill 439 53 504 439 56 504 minecraft:blackstone
fill 440 53 503 440 56 503 minecraft:blackstone
setblock 462 53 475 minecraft:polished_blackstone_bricks
fill 462 53 476 462 56 476 minecraft:blackstone
setblock 463 53 469 minecraft:polished_blackstone_bricks
fill 463 53 470 463 54 470 minecraft:blackstone
setblock 463 53 474 minecraft:polished_blackstone_bricks
fill 463 53 475 463 56 475 minecraft:blackstone
setblock 464 53 468 minecraft:polished_blackstone_bricks
fill 464 53 469 464 56 469 minecraft:blackstone
setblock 464 53 473 minecraft:polished_blackstone_bricks
fill 464 53 474 464 56 474 minecraft:blackstone
setblock 464 53 478 minecraft:polished_blackstone_bricks
fill 464 53 479 464 56 479 minecraft:blackstone
setblock 464 53 493 minecraft:polished_blackstone_bricks
setblock 464 53 494 minecraft:blackstone
setblock 424 54 467 minecraft:polished_blackstone_bricks
fill 424 54 468 424 56 468 minecraft:blackstone
setblock 424 54 472 minecraft:polished_blackstone_bricks
fill 424 54 473 424 57 473 minecraft:blackstone
setblock 424 54 477 minecraft:polished_blackstone_bricks
fill 424 54 478 424 57 478 minecraft:blackstone
setblock 425 54 471 minecraft:polished_blackstone_bricks
setblock 425 54 472 minecraft:blackstone
setblock 426 54 466 minecraft:light[level=11]
setblock 426 54 474 minecraft:light[level=11]
setblock 426 54 482 minecraft:light[level=11]
setblock 426 54 490 minecraft:light[level=11]
setblock 426 54 498 minecraft:light[level=11]
fill 433 54 464 433 57 464 minecraft:blackstone
fill 433 54 504 433 57 504 minecraft:blackstone
setblock 434 54 466 minecraft:light[level=11]
setblock 434 54 474 minecraft:light[level=11]
setblock 434 54 482 minecraft:light[level=11]
setblock 434 54 490 minecraft:light[level=11]
setblock 434 54 498 minecraft:light[level=11]
fill 435 54 503 435 56 503 minecraft:blackstone
setblock 437 54 464 minecraft:polished_blackstone_bricks
setblock 437 54 504 minecraft:polished_blackstone_bricks
fill 438 54 464 438 57 464 minecraft:blackstone
setblock 438 54 503 minecraft:polished_blackstone_bricks
fill 438 54 504 438 57 504 minecraft:blackstone
fill 439 54 503 439 57 503 minecraft:blackstone
setblock 442 54 466 minecraft:light[level=11]
setblock 442 54 474 minecraft:light[level=11]
setblock 442 54 482 minecraft:light[level=11]
setblock 442 54 490 minecraft:light[level=11]
setblock 442 54 498 minecraft:light[level=11]
setblock 442 54 504 minecraft:polished_blackstone_bricks
setblock 450 54 466 minecraft:light[level=11]
setblock 450 54 474 minecraft:light[level=11]
setblock 450 54 482 minecraft:light[level=11]
setblock 450 54 490 minecraft:light[level=11]
setblock 450 54 498 minecraft:light[level=11]
setblock 458 54 466 minecraft:light[level=11]
setblock 458 54 474 minecraft:light[level=11]
setblock 458 54 482 minecraft:light[level=11]
setblock 458 54 490 minecraft:light[level=11]
setblock 458 54 498 minecraft:light[level=11]
setblock 462 54 474 minecraft:polished_blackstone_bricks
fill 462 54 475 462 57 475 minecraft:blackstone
setblock 463 54 473 minecraft:polished_blackstone_bricks
fill 463 54 474 463 57 474 minecraft:blackstone
setblock 463 54 478 minecraft:polished_blackstone_bricks
setblock 464 54 468 minecraft:blackstone
setblock 464 54 472 minecraft:polished_blackstone_bricks
fill 464 54 473 464 57 473 minecraft:blackstone
setblock 464 54 477 minecraft:polished_blackstone_bricks
fill 464 54 478 464 57 478 minecraft:blackstone
setblock 424 55 471 minecraft:polished_blackstone_bricks
fill 424 55 472 424 58 472 minecraft:blackstone
setblock 424 55 476 minecraft:polished_blackstone_bricks
fill 424 55 477 424 58 477 minecraft:blackstone
fill 432 55 464 432 58 464 minecraft:blackstone
fill 432 55 504 432 58 504 minecraft:blackstone
fill 434 55 503 434 57 503 minecraft:blackstone
setblock 436 55 464 minecraft:polished_blackstone_bricks
setblock 436 55 504 minecraft:polished_blackstone_bricks
fill 437 55 464 437 58 464 minecraft:blackstone
setblock 437 55 502 minecraft:blackstone
setblock 437 55 503 minecraft:polished_blackstone_bricks
fill 437 55 504 437 58 504 minecraft:blackstone
setblock 438 55 502 minecraft:polished_blackstone_bricks
fill 438 55 503 438 58 503 minecraft:blackstone
setblock 441 55 504 minecraft:polished_blackstone_bricks
fill 442 55 504 442 58 504 minecraft:blackstone
setblock 462 55 473 minecraft:polished_blackstone_bricks
fill 462 55 474 462 58 474 minecraft:blackstone
setblock 462 55 477 minecraft:blackstone
setblock 463 55 472 minecraft:polished_blackstone_bricks
fill 463 55 473 463 58 473 minecraft:blackstone
setblock 463 55 477 minecraft:polished_blackstone_bricks
fill 463 55 478 463 57 479 minecraft:blackstone
setblock 464 55 471 minecraft:polished_blackstone_bricks
fill 464 55 472 464 58 472 minecraft:blackstone
setblock 464 55 476 minecraft:polished_blackstone_bricks
fill 464 55 477 464 58 477 minecraft:blackstone
setblock 424 56 470 minecraft:polished_blackstone_bricks
fill 424 56 471 424 59 471 minecraft:blackstone
setblock 424 56 475 minecraft:polished_blackstone_bricks
fill 424 56 476 424 59 476 minecraft:blackstone
setblock 430 56 504 minecraft:polished_blackstone_bricks
fill 431 56 464 431 59 464 minecraft:blackstone
fill 431 56 504 431 59 504 minecraft:blackstone
fill 432 56 503 433 58 503 minecraft:blackstone
fill 434 56 502 436 56 502 minecraft:blackstone
setblock 435 56 464 minecraft:polished_blackstone_bricks
setblock 435 56 504 minecraft:polished_blackstone_bricks
fill 436 56 464 436 59 464 minecraft:blackstone
setblock 436 56 503 minecraft:polished_blackstone_bricks
fill 436 56 504 436 59 504 minecraft:blackstone
setblock 437 56 502 minecraft:polished_blackstone_bricks
fill 437 56 503 437 59 503 minecraft:blackstone
fill 438 56 502 439 58 502 minecraft:blackstone
setblock 440 56 504 minecraft:polished_blackstone_bricks
fill 441 56 504 441 59 504 minecraft:blackstone
fill 462 56 473 462 57 473 minecraft:blackstone
setblock 462 56 477 minecraft:polished_blackstone_bricks
setblock 463 56 471 minecraft:polished_blackstone_bricks
fill 463 56 472 463 59 472 minecraft:blackstone
setblock 463 56 476 minecraft:polished_blackstone_bricks
fill 463 56 477 463 59 477 minecraft:blackstone
setblock 464 56 470 minecraft:polished_blackstone_bricks
fill 464 56 471 464 59 471 minecraft:blackstone
setblock 464 56 475 minecraft:polished_blackstone_bricks
fill 464 56 476 464 59 476 minecraft:blackstone
setblock 464 56 480 minecraft:polished_blackstone_bricks
fill 464 56 481 464 59 481 minecraft:blackstone
setblock 424 57 469 minecraft:polished_blackstone_bricks
fill 424 57 470 424 60 470 minecraft:blackstone
setblock 424 57 474 minecraft:polished_blackstone_bricks
fill 424 57 475 424 60 475 minecraft:blackstone
setblock 424 57 479 minecraft:polished_blackstone_bricks
setblock 424 57 498 minecraft:blackstone
setblock 424 57 499 minecraft:polished_blackstone_bricks
setblock 429 57 504 minecraft:polished_blackstone_bricks
fill 430 57 464 430 60 464 minecraft:blackstone
fill 430 57 504 430 60 504 minecraft:blackstone
fill 431 57 503 431 60 503 minecraft:blackstone
fill 432 57 502 435 57 502 minecraft:blackstone
setblock 434 57 464 minecraft:polished_blackstone_bricks
setblock 434 57 504 minecraft:polished_blackstone_bricks
fill 435 57 464 435 60 464 minecraft:blackstone
fill 435 57 501 436 57 501 minecraft:blackstone
setblock 435 57 503 minecraft:polished_blackstone_bricks
fill 435 57 504 435 60 504 minecraft:blackstone
setblock 436 57 502 minecraft:polished_blackstone_bricks
fill 436 57 503 436 60 503 minecraft:blackstone
setblock 437 57 501 minecraft:polished_blackstone_bricks
fill 437 57 502 437 60 502 minecraft:blackstone
setblock 439 57 504 minecraft:polished_blackstone_bricks
setblock 440 57 503 minecraft:polished_blackstone_bricks
fill 440 57 504 440 60 504 minecraft:blackstone
fill 441 57 503 441 60 503 minecraft:blackstone
setblock 454 57 504 minecraft:polished_blackstone_bricks
fill 455 57 504 457 58 504 minecraft:blackstone
fill 457 57 471 461 58 475 minecraft:blackstone
setblock 462 57 476 minecraft:polished_blackstone_bricks
fill 462 57 477 462 59 478 minecraft:blackstone
setblock 463 57 471 minecraft:blackstone
setblock 463 57 475 minecraft:polished_blackstone_bricks
fill 463 57 476 463 60 476 minecraft:blackstone
setblock 463 57 480 minecraft:polished_blackstone_bricks
setblock 464 57 469 minecraft:polished_blackstone_bricks
fill 464 57 470 464 60 470 minecraft:blackstone
setblock 464 57 474 minecraft:polished_blackstone_bricks
fill 464 57 475 464 60 475 minecraft:blackstone
setblock 464 57 479 minecraft:polished_blackstone_bricks
fill 464 57 480 464 60 480 minecraft:blackstone
fill 424 58 469 424 59 469 minecraft:blackstone
setblock 424 58 473 minecraft:polished_blackstone_bricks
fill 424 58 474 424 61 474 minecraft:blackstone
setblock 424 58 478 minecraft:polished_blackstone_bricks
fill 424 58 479 424 61 479 minecraft:blackstone
setblock 424 58 497 minecraft:blackstone
setblock 424 58 498 minecraft:polished_blackstone_bricks
fill 424 58 499 424 58 502 minecraft:blackstone
fill 426 58 504 427 58 504 minecraft:blackstone
setblock 428 58 464 minecraft:polished_blackstone_bricks
setblock 428 58 504 minecraft:polished_blackstone_bricks
fill 429 58 464 429 61 464 minecraft:blackstone
setblock 429 58 503 minecraft:polished_blackstone_bricks
fill 429 58 504 429 61 504 minecraft:blackstone
fill 430 58 503 430 61 503 minecraft:blackstone
fill 431 58 502 434 58 502 minecraft:blackstone
setblock 433 58 464 minecraft:polished_blackstone_bricks
fill 433 58 465 434 60 465 minecraft:blackstone
fill 433 58 501 435 58 501 minecraft:blackstone
setblock 433 58 504 minecraft:polished_blackstone_bricks
fill 434 58 464 434 61 464 minecraft:blackstone
setblock 434 58 503 minecraft:polished_blackstone_bricks
fill 434 58 504 434 61 504 minecraft:blackstone
setblock 435 58 502 minecraft:polished_blackstone_bricks
fill 435 58 503 435 61 503 minecraft:blackstone
setblock 436 58 501 minecraft:polished_blackstone_bricks
fill 436 58 502 436 61 502 minecraft:blackstone
fill 437 58 501 438 60 501 minecraft:blackstone
setblock 438 58 464 minecraft:polished_blackstone_bricks
setblock 438 58 504 minecraft:polished_blackstone_bricks
setblock 439 58 503 minecraft:polished_blackstone_bricks
fill 439 58 504 439 61 504 minecraft:blackstone
setblock 440 58 502 minecraft:polished_blackstone_bricks
fill 440 58 503 440 61 503 minecraft:blackstone
setblock 443 58 504 minecraft:polished_blackstone_bricks
fill 451 58 504 452 58 504 minecraft:blackstone
setblock 453 58 504 minecraft:polished_blackstone_bricks
fill 454 58 504 454 61 504 minecraft:blackstone
fill 455 58 503 455 61 503 minecraft:blackstone
fill 456 58 464 457 58 464 minecraft:blackstone
setblock 458 58 504 minecraft:polished_blackstone_bricks
setblock 462 58 475 minecraft:polished_blackstone_bricks
fill 462 58 476 462 61 476 minecraft:blackstone
setblock 462 58 479 minecraft:blackstone
setblock 463 58 474 minecraft:polished_blackstone_bricks
fill 463 58 475 463 61 475 minecraft:blackstone
setblock 463 58 478 minecraft:blackstone
setblock 463 58 479 minecraft:polished_blackstone_bricks
fill 463 58 480 463 61 480 minecraft:blackstone
fill 464 58 469 464 61 469 minecraft:blackstone
setblock 464 58 473 minecraft:polished_blackstone_bricks
fill 464 58 474 464 61 474 minecraft:blackstone
setblock 464 58 478 minecraft:polished_blackstone_bricks
fill 464 58 479 464 61 479 minecraft:blackstone
setblock 464 58 482 minecraft:blackstone
fill 424 59 464 426 59 464 minecraft:blackstone
setblock 424 59 472 minecraft:polished_blackstone_bricks
fill 424 59 473 424 62 473 minecraft:blackstone
setblock 424 59 477 minecraft:polished_blackstone_bricks
fill 424 59 478 424 62 478 minecraft:blackstone
fill 424 59 480 424 60 480 minecraft:blackstone
setblock 424 59 497 minecraft:polished_blackstone_bricks
fill 424 59 498 424 59 501 minecraft:blackstone
setblock 424 59 502 minecraft:polished_blackstone_bricks
fill 424 59 503 424 61 504 minecraft:blackstone
fill 425 59 504 426 59 504 minecraft:blackstone
setblock 427 59 464 minecraft:polished_blackstone_bricks
setblock 427 59 503 minecraft:blackstone
setblock 427 59 504 minecraft:polished_blackstone_bricks
fill 428 59 464 428 62 464 minecraft:blackstone
setblock 428 59 503 minecraft:polished_blackstone_bricks
fill 428 59 504 428 62 504 minecraft:blackstone
setblock 429 59 502 minecraft:polished_blackstone_bricks
fill 429 59 503 429 62 503 minecraft:blackstone
fill 430 59 502 433 59 502 minecraft:blackstone
setblock 431 59 465 minecraft:polished_blackstone_bricks
fill 431 59 501 434 59 501 minecraft:blackstone
setblock 432 59 464 minecraft:polished_blackstone_bricks
fill 432 59 465 432 62 465 minecraft:blackstone
setblock 432 59 503 minecraft:blackstone
setblock 432 59 504 minecraft:polished_blackstone_bricks
fill 433 59 464 433 62 464 minecraft:blackstone
setblock 433 59 503 minecraft:polished_blackstone_bricks
fill 433 59 504 433 62 504 minecraft:blackstone
fill 434 59 500 435 59 500 minecraft:blackstone
setblock 434 59 502 minecraft:polished_blackstone_bricks
fill 434 59 503 434 62 503 minecraft:blackstone
setblock 435 59 465 minecraft:blackstone
setblock 435 59 501 minecraft:polished_blackstone_bricks
fill 435 59 502 435 62 502 minecraft:blackstone
setblock 436 59 500 minecraft:polished_blackstone_bricks
fill 436 59 501 436 62 501 minecraft:blackstone
setblock 437 59 464 minecraft:polished_blackstone_bricks
setblock 437 59 504 minecraft:polished_blackstone_bricks
fill 438 59 464 439 61 464 minecraft:blackstone
setblock 438 59 502 minecraft:blackstone
setblock 438 59 503 minecraft:polished_blackstone_bricks
fill 438 59 504 438 62 504 minecraft:blackstone
setblock 439 59 501 minecraft:blackstone
setblock 439 59 502 minecraft:polished_blackstone_bricks
fill 439 59 503 439 62 503 minecraft:blackstone
fill 440 59 502 440 62 502 minecraft:blackstone
setblock 442 59 503 minecraft:blackstone
setblock 442 59 504 minecraft:polished_blackstone_bricks
fill 443 59 504 444 61 504 minecraft:blackstone
fill 448 59 504 451 59 504 minecraft:blackstone
fill 451 59 503 452 59 503 minecraft:blackstone
setblock 452 59 504 minecraft:polished_blackstone_bricks
fill 453 59 464 456 59 464 minecraft:blackstone
setblock 453 59 503 minecraft:polished_blackstone_bricks
fill 453 59 504 453 62 504 minecraft:blackstone
fill 454 59 503 454 62 503 minecraft:blackstone
fill 455 59 504 456 59 504 minecraft:blackstone
fill 456 59 503 457 59 503 minecraft:blackstone
setblock 457 59 464 minecraft:polished_blackstone_bricks
fill 457 59 484 461 60 488 minecraft:blackstone
setblock 457 59 504 minecraft:polished_blackstone_bricks
fill 458 59 464 459 61 464 minecraft:blackstone
fill 458 59 473 460 63 473 minecraft:polished_blackstone_bricks
fill 458 59 504 459 61 504 minecraft:blackstone
setblock 462 59 474 minecraft:polished_blackstone_bricks
fill 462 59 475 462 60 475 minecraft:blackstone
setblock 462 59 479 minecraft:polished_blackstone_bricks
fill 462 59 486 463 59 486 minecraft:blackstone
setblock 463 59 473 minecraft:polished_blackstone_bricks
fill 463 59 474 463 62 474 minecraft:blackstone
setblock 463 59 478 minecraft:polished_blackstone_bricks
fill 463 59 479 463 62 479 minecraft:blackstone
fill 463 59 481 463 60 481 minecraft:blackstone
setblock 464 59 472 minecraft:polished_blackstone_bricks
fill 464 59 473 464 62 473 minecraft:blackstone
setblock 464 59 477 minecraft:polished_blackstone_bricks
fill 464 59 478 464 62 478 minecraft:blackstone
setblock 464 59 482 minecraft:polished_blackstone_bricks
fill 464 59 483 464 62 483 minecraft:blackstone
fill 424 60 464 424 60 465 minecraft:blackstone
setblock 424 60 466 minecraft:polished_blackstone_bricks
setblock 424 60 471 minecraft:polished_blackstone_bricks
fill 424 60 472 424 61 472 minecraft:blackstone
setblock 424 60 476 minecraft:polished_blackstone_bricks
fill 424 60 477 424 63 477 minecraft:blackstone
setblock 424 60 481 minecraft:polished_blackstone_bricks
setblock 424 60 496 minecraft:polished_blackstone_bricks
fill 424 60 497 424 60 500 minecraft:blackstone
setblock 424 60 501 minecraft:polished_blackstone_bricks
fill 424 60 502 425 62 502 minecraft:blackstone
setblock 425 60 464 minecraft:blackstone
setblock 425 60 499 minecraft:blackstone
setblock 425 60 500 minecraft:polished_blackstone_bricks
fill 425 60 501 425 63 501 minecraft:blackstone
fill 425 60 503 425 60 504 minecraft:blackstone
setblock 426 60 464 minecraft:polished_blackstone_bricks
setblock 426 60 503 minecraft:blackstone
setblock 426 60 504 minecraft:polished_blackstone_bricks
fill 427 60 464 427 63 464 minecraft:blackstone
setblock 427 60 503 minecraft:polished_blackstone_bricks
fill 427 60 504 427 63 504 minecraft:blackstone
setblock 428 60 502 minecraft:polished_blackstone_bricks
fill 428 60 503 428 63 503 minecraft:blackstone
fill 429 60 502 432 60 502 minecraft:blackstone
setblock 430 60 465 minecraft:polished_blackstone_bricks
fill 430 60 501 433 60 501 minecraft:blackstone
setblock 431 60 464 minecraft:polished_blackstone_bricks
fill 431 60 465 431 63 465 minecraft:blackstone
setblock 431 60 504 minecraft:polished_blackstone_bricks
fill 432 60 464 432 63 464 minecraft:blackstone
setblock 432 60 503 minecraft:polished_blackstone_bricks
fill 432 60 504 432 63 504 minecraft:blackstone
fill 433 60 500 434 60 500 minecraft:blackstone
setblock 433 60 502 minecraft:polished_blackstone_bricks
fill 433 60 503 433 63 503 minecraft:blackstone
setblock 434 60 501 minecraft:polished_blackstone_bricks
fill 434 60 502 434 63 502 minecraft:blackstone
setblock 435 60 465 minecraft:polished_blackstone_bricks
setblock 435 60 500 minecraft:polished_blackstone_bricks
fill 435 60 501 435 63 501 minecraft:blackstone
setblock 436 60 464 minecraft:polished_blackstone_bricks
fill 436 60 500 436 61 500 minecraft:blackstone
setblock 436 60 504 minecraft:polished_blackstone_bricks
fill 437 60 464 437 63 464 minecraft:blackstone
setblock 437 60 503 minecraft:polished_blackstone_bricks
fill 437 60 504 437 63 504 minecraft:blackstone
setblock 438 60 502 minecraft:polished_blackstone_bricks
fill 438 60 503 438 63 503 minecraft:blackstone
setblock 439 60 501 minecraft:polished_blackstone_bricks
fill 439 60 502 439 63 502 minecraft:blackstone
fill 441 60 502 441 61 502 minecraft:blackstone
setblock 441 60 504 minecraft:polished_blackstone_bricks
setblock 442 60 503 minecraft:polished_blackstone_bricks
fill 442 60 504 442 63 504 minecraft:blackstone
fill 443 60 495 444 61 496 minecraft:cyan_stained_glass
fill 443 60 503 443 62 503 minecraft:blackstone
setblock 445 60 504 minecraft:blackstone
setblock 446 60 504 minecraft:polished_blackstone_bricks
fill 447 60 504 450 60 504 minecraft:blackstone
fill 449 60 503 451 60 503 minecraft:blackstone
setblock 451 60 504 minecraft:polished_blackstone_bricks
fill 452 60 464 455 60 464 minecraft:blackstone
setblock 452 60 502 minecraft:blackstone
setblock 452 60 503 minecraft:polished_blackstone_bricks
fill 452 60 504 452 63 504 minecraft:blackstone
setblock 453 60 502 minecraft:polished_blackstone_bricks
fill 453 60 503 453 63 503 minecraft:blackstone
fill 454 60 502 455 62 502 minecraft:blackstone
setblock 455 60 504 minecraft:blackstone
setblock 456 60 464 minecraft:polished_blackstone_bricks
setblock 456 60 503 minecraft:blackstone
setblock 456 60 504 minecraft:polished_blackstone_bricks
fill 457 60 464 457 63 464 minecraft:blackstone
setblock 457 60 503 minecraft:polished_blackstone_bricks
fill 457 60 504 457 63 504 minecraft:blackstone
fill 458 60 503 458 62 503 minecraft:blackstone
setblock 460 60 464 minecraft:blackstone
setblock 460 60 504 minecraft:blackstone
setblock 462 60 477 minecraft:blackstone
setblock 462 60 478 minecraft:polished_blackstone_bricks
fill 462 60 479 462 61 480 minecraft:blackstone
setblock 463 60 472 minecraft:polished_blackstone_bricks
fill 463 60 473 463 61 473 minecraft:blackstone
setblock 463 60 477 minecraft:polished_blackstone_bricks
fill 463 60 478 463 63 478 minecraft:blackstone
setblock 464 60 471 minecraft:polished_blackstone_bricks
fill 464 60 472 464 63 472 minecraft:blackstone
setblock 464 60 476 minecraft:polished_blackstone_bricks
fill 464 60 477 464 63 477 minecraft:blackstone
setblock 464 60 481 minecraft:polished_blackstone_bricks
fill 464 60 482 464 63 482 minecraft:blackstone
fill 464 60 499 464 60 500 minecraft:blackstone
setblock 464 60 501 minecraft:polished_blackstone_bricks
setblock 424 61 464 minecraft:blackstone
setblock 424 61 465 minecraft:polished_blackstone_bricks
fill 424 61 466 424 64 466 minecraft:blackstone
setblock 424 61 471 minecraft:blackstone
setblock 424 61 475 minecraft:polished_blackstone_bricks
fill 424 61 476 424 63 476 minecraft:blackstone
setblock 424 61 480 minecraft:polished_blackstone_bricks
fill 424 61 481 424 64 481 minecraft:blackstone
fill 424 61 497 424 61 499 minecraft:blackstone
setblock 424 61 500 minecraft:polished_blackstone_bricks
fill 424 61 501 424 64 501 minecraft:blackstone
setblock 425 61 464 minecraft:polished_blackstone_bricks
setblock 425 61 499 minecraft:polished_blackstone_bricks
fill 425 61 500 425 64 500 minecraft:blackstone
setblock 425 61 503 minecraft:blackstone
setblock 425 61 504 minecraft:polished_blackstone_bricks
fill 426 61 464 426 64 464 minecraft:blackstone
setblock 426 61 503 minecraft:polished_blackstone_bricks
fill 426 61 504 426 64 504 minecraft:blackstone
setblock 427 61 502 minecraft:polished_blackstone_bricks
fill 427 61 503 427 64 503 minecraft:blackstone
setblock 428 61 465 minecraft:blackstone
fill 428 61 502 431 61 502 minecraft:blackstone
setblock 429 61 465 minecraft:polished_blackstone_bricks
fill 429 61 501 432 61 501 minecraft:blackstone
setblock 430 61 464 minecraft:polished_blackstone_bricks
fill 430 61 465 430 64 465 minecraft:blackstone
setblock 430 61 504 minecraft:polished_blackstone_bricks
fill 431 61 464 431 64 464 minecraft:blackstone
setblock 431 61 503 minecraft:polished_blackstone_bricks
fill 431 61 504 431 64 504 minecraft:blackstone
fill 432 61 500 433 61 500 minecraft:blackstone
setblock 432 61 502 minecraft:polished_blackstone_bricks
fill 432 61 503 432 64 503 minecraft:blackstone
setblock 433 61 465 minecraft:blackstone
setblock 433 61 501 minecraft:polished_blackstone_bricks
fill 433 61 502 433 64 502 minecraft:blackstone
setblock 434 61 465 minecraft:polished_blackstone_bricks
setblock 434 61 500 minecraft:polished_blackstone_bricks
fill 434 61 501 434 64 501 minecraft:blackstone
setblock 435 61 464 minecraft:polished_blackstone_bricks
fill 435 61 465 435 63 465 minecraft:blackstone
fill 435 61 500 435 62 500 minecraft:blackstone
setblock 435 61 504 minecraft:polished_blackstone_bricks
fill 436 61 464 436 64 464 minecraft:blackstone
setblock 436 61 503 minecraft:polished_blackstone_bricks
fill 436 61 504 436 64 504 minecraft:blackstone
setblock 437 61 501 minecraft:blackstone
setblock 437 61 502 minecraft:polished_blackstone_bricks
fill 437 61 503 437 64 503 minecraft:blackstone
setblock 438 61 501 minecraft:polished_blackstone_bricks
fill 438 61 502 438 64 502 minecraft:blackstone
setblock 439 61 501 minecraft:blackstone
setblock 440 61 504 minecraft:polished_blackstone_bricks
setblock 441 61 503 minecraft:polished_blackstone_bricks
fill 441 61 504 441 64 504 minecraft:blackstone
fill 442 61 503 442 63 503 minecraft:blackstone
setblock 445 61 504 minecraft:polished_blackstone_bricks
fill 446 61 504 449 61 504 minecraft:blackstone
fill 447 61 503 450 61 503 minecraft:blackstone
setblock 450 61 504 minecraft:polished_blackstone_bricks
fill 451 61 464 454 61 464 minecraft:blackstone
setblock 451 61 502 minecraft:blackstone
setblock 451 61 503 minecraft:polished_blackstone_bricks
fill 451 61 504 451 64 504 minecraft:blackstone
setblock 452 61 502 minecraft:polished_blackstone_bricks
fill 452 61 503 452 64 503 minecraft:blackstone
fill 453 61 502 453 63 502 minecraft:blackstone
setblock 455 61 464 minecraft:polished_blackstone_bricks
setblock 455 61 504 minecraft:polished_blackstone_bricks
fill 456 61 464 456 64 464 minecraft:blackstone
setblock 456 61 503 minecraft:polished_blackstone_bricks
fill 456 61 504 456 64 504 minecraft:blackstone
fill 457 61 503 457 63 503 minecraft:blackstone
fill 458 61 486 460 65 486 minecraft:polished_blackstone_bricks
setblock 460 61 464 minecraft:polished_blackstone_bricks
setblock 460 61 504 minecraft:polished_blackstone_bricks
fill 461 61 464 462 63 464 minecraft:blackstone
fill 461 61 504 461 64 504 minecraft:blackstone
setblock 462 61 477 minecraft:polished_blackstone_bricks
fill 462 61 478 462 62 478 minecraft:blackstone
setblock 463 61 476 minecraft:polished_blackstone_bricks
fill 463 61 477 463 63 477 minecraft:blackstone
setblock 463 61 481 minecraft:polished_blackstone_bricks
fill 463 61 482 463 62 482 minecraft:blackstone
setblock 464 61 464 minecraft:blackstone
setblock 464 61 470 minecraft:polished_blackstone_bricks
fill 464 61 471 464 63 471 minecraft:blackstone
setblock 464 61 475 minecraft:polished_blackstone_bricks
fill 464 61 476 464 64 476 minecraft:blackstone
setblock 464 61 480 minecraft:polished_blackstone_bricks
schedule function dropper:buildpart/117_2 1t
