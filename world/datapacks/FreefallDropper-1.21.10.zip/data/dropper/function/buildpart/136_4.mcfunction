fill 204 296 595 204 297 595 minecraft:quartz_block
fill 204 296 597 204 297 597 minecraft:quartz_block
setblock 205 296 558 minecraft:quartz_block
fill 205 296 561 205 298 561 minecraft:quartz_block
fill 205 296 590 205 297 590 minecraft:quartz_block
fill 205 296 592 205 297 592 minecraft:quartz_block
fill 205 296 594 205 297 594 minecraft:quartz_block
fill 205 296 596 205 297 596 minecraft:quartz_block
fill 205 296 598 205 297 598 minecraft:quartz_block
fill 206 296 560 206 297 560 minecraft:quartz_block
fill 206 296 595 206 297 595 minecraft:quartz_block
fill 204 297 561 204 298 562 minecraft:quartz_block
setblock 205 297 558 minecraft:gold_block
setblock 205 297 559 minecraft:quartz_block
fill 205 297 562 206 298 562 minecraft:quartz_block
fill 206 297 561 206 298 561 minecraft:quartz_block
fill 206 297 593 206 298 594 minecraft:quartz_block
setblock 189 298 562 minecraft:ochre_froglight
setblock 189 298 564 minecraft:ochre_froglight
setblock 189 298 566 minecraft:ochre_froglight
setblock 189 298 568 minecraft:ochre_froglight
setblock 189 298 570 minecraft:ochre_froglight
setblock 189 298 572 minecraft:ochre_froglight
setblock 190 298 561 minecraft:ochre_froglight
setblock 190 298 563 minecraft:ochre_froglight
setblock 190 298 565 minecraft:ochre_froglight
setblock 190 298 567 minecraft:ochre_froglight
setblock 190 298 569 minecraft:ochre_froglight
setblock 190 298 571 minecraft:ochre_froglight
setblock 190 298 573 minecraft:ochre_froglight
setblock 191 298 562 minecraft:ochre_froglight
setblock 191 298 564 minecraft:ochre_froglight
setblock 191 298 566 minecraft:ochre_froglight
setblock 191 298 568 minecraft:ochre_froglight
setblock 191 298 570 minecraft:ochre_froglight
setblock 191 298 572 minecraft:ochre_froglight
setblock 192 298 561 minecraft:ochre_froglight
setblock 192 298 563 minecraft:ochre_froglight
setblock 192 298 565 minecraft:ochre_froglight
setblock 192 298 567 minecraft:ochre_froglight
setblock 192 298 569 minecraft:ochre_froglight
setblock 192 298 571 minecraft:ochre_froglight
setblock 192 298 573 minecraft:ochre_froglight
setblock 192 298 591 minecraft:ochre_froglight
setblock 192 298 593 minecraft:ochre_froglight
setblock 192 298 595 minecraft:ochre_froglight
setblock 192 298 597 minecraft:ochre_froglight
setblock 193 298 562 minecraft:ochre_froglight
setblock 193 298 564 minecraft:ochre_froglight
setblock 193 298 566 minecraft:ochre_froglight
setblock 193 298 568 minecraft:ochre_froglight
setblock 193 298 570 minecraft:ochre_froglight
setblock 193 298 572 minecraft:ochre_froglight
setblock 193 298 590 minecraft:ochre_froglight
setblock 193 298 592 minecraft:ochre_froglight
setblock 193 298 594 minecraft:ochre_froglight
setblock 193 298 596 minecraft:ochre_froglight
setblock 193 298 598 minecraft:ochre_froglight
setblock 194 298 591 minecraft:ochre_froglight
setblock 194 298 593 minecraft:ochre_froglight
setblock 194 298 595 minecraft:ochre_froglight
setblock 194 298 597 minecraft:ochre_froglight
setblock 195 298 590 minecraft:ochre_froglight
setblock 195 298 592 minecraft:ochre_froglight
setblock 195 298 594 minecraft:ochre_froglight
setblock 195 298 596 minecraft:ochre_froglight
setblock 195 298 598 minecraft:ochre_froglight
setblock 196 298 591 minecraft:ochre_froglight
setblock 196 298 593 minecraft:ochre_froglight
setblock 196 298 595 minecraft:ochre_froglight
setblock 196 298 597 minecraft:ochre_froglight
setblock 197 298 590 minecraft:ochre_froglight
setblock 197 298 592 minecraft:ochre_froglight
setblock 197 298 594 minecraft:ochre_froglight
setblock 197 298 596 minecraft:ochre_froglight
setblock 197 298 598 minecraft:ochre_froglight
setblock 198 298 591 minecraft:ochre_froglight
setblock 198 298 593 minecraft:ochre_froglight
setblock 198 298 595 minecraft:ochre_froglight
setblock 198 298 597 minecraft:ochre_froglight
setblock 199 298 590 minecraft:ochre_froglight
setblock 199 298 592 minecraft:ochre_froglight
setblock 199 298 594 minecraft:ochre_froglight
setblock 199 298 596 minecraft:ochre_froglight
setblock 199 298 598 minecraft:ochre_froglight
setblock 200 298 591 minecraft:ochre_froglight
setblock 200 298 593 minecraft:ochre_froglight
setblock 200 298 595 minecraft:ochre_froglight
setblock 200 298 597 minecraft:ochre_froglight
setblock 201 298 590 minecraft:ochre_froglight
setblock 201 298 592 minecraft:ochre_froglight
setblock 201 298 594 minecraft:ochre_froglight
setblock 201 298 596 minecraft:ochre_froglight
setblock 201 298 598 minecraft:ochre_froglight
setblock 202 298 591 minecraft:ochre_froglight
setblock 202 298 593 minecraft:ochre_froglight
setblock 202 298 595 minecraft:ochre_froglight
setblock 202 298 597 minecraft:ochre_froglight
setblock 203 298 590 minecraft:ochre_froglight
setblock 203 298 592 minecraft:ochre_froglight
setblock 203 298 594 minecraft:ochre_froglight
setblock 203 298 596 minecraft:ochre_froglight
setblock 203 298 598 minecraft:ochre_froglight
fill 204 298 563 206 299 563 minecraft:quartz_block
setblock 204 298 591 minecraft:ochre_froglight
setblock 204 298 593 minecraft:ochre_froglight
setblock 204 298 595 minecraft:ochre_froglight
setblock 204 298 597 minecraft:ochre_froglight
setblock 205 298 559 minecraft:gold_block
fill 205 298 564 205 300 564 minecraft:quartz_block
setblock 205 298 590 minecraft:ochre_froglight
setblock 205 298 592 minecraft:ochre_froglight
setblock 205 298 594 minecraft:ochre_froglight
setblock 205 298 596 minecraft:ochre_froglight
setblock 205 298 598 minecraft:ochre_froglight
fill 206 298 592 206 299 592 minecraft:quartz_block
fill 189 299 562 189 300 562 minecraft:quartz_block
fill 189 299 564 189 300 564 minecraft:quartz_block
fill 189 299 566 189 300 566 minecraft:quartz_block
fill 189 299 568 189 300 568 minecraft:quartz_block
fill 189 299 570 189 300 570 minecraft:quartz_block
fill 189 299 572 189 300 572 minecraft:quartz_block
fill 190 299 561 190 300 561 minecraft:quartz_block
fill 190 299 563 190 300 563 minecraft:quartz_block
fill 190 299 565 190 300 565 minecraft:quartz_block
fill 190 299 567 190 300 567 minecraft:quartz_block
fill 190 299 569 190 300 569 minecraft:quartz_block
fill 190 299 571 190 300 571 minecraft:quartz_block
fill 190 299 573 190 300 573 minecraft:quartz_block
setblock 191 299 560 minecraft:light[level=14]
fill 191 299 562 191 300 562 minecraft:quartz_block
fill 191 299 564 191 300 564 minecraft:quartz_block
fill 191 299 566 191 300 566 minecraft:quartz_block
fill 191 299 568 191 300 568 minecraft:quartz_block
fill 191 299 570 191 300 570 minecraft:quartz_block
fill 191 299 572 191 300 572 minecraft:quartz_block
setblock 191 299 576 minecraft:light[level=14]
setblock 191 299 584 minecraft:light[level=14]
setblock 191 299 592 minecraft:light[level=14]
fill 192 299 561 192 300 561 minecraft:quartz_block
fill 192 299 563 192 300 563 minecraft:quartz_block
fill 192 299 565 192 300 565 minecraft:quartz_block
fill 192 299 567 192 300 567 minecraft:quartz_block
fill 192 299 569 192 300 569 minecraft:quartz_block
fill 192 299 571 192 300 571 minecraft:quartz_block
fill 192 299 573 192 300 573 minecraft:quartz_block
fill 192 299 591 192 300 591 minecraft:quartz_block
fill 192 299 593 192 300 593 minecraft:quartz_block
fill 192 299 595 192 300 595 minecraft:quartz_block
fill 192 299 597 192 300 597 minecraft:quartz_block
fill 193 299 562 193 300 562 minecraft:quartz_block
fill 193 299 564 193 300 564 minecraft:quartz_block
fill 193 299 566 193 300 566 minecraft:quartz_block
fill 193 299 568 193 300 568 minecraft:quartz_block
fill 193 299 570 193 300 570 minecraft:quartz_block
fill 193 299 572 193 300 572 minecraft:quartz_block
fill 193 299 574 193 300 574 minecraft:raw_gold_block
fill 193 299 590 193 300 590 minecraft:quartz_block
fill 193 299 592 193 300 592 minecraft:quartz_block
fill 193 299 594 193 300 594 minecraft:quartz_block
fill 193 299 596 193 300 596 minecraft:quartz_block
fill 193 299 598 193 300 598 minecraft:quartz_block
fill 194 299 591 194 300 591 minecraft:quartz_block
fill 194 299 593 194 300 593 minecraft:quartz_block
fill 194 299 595 194 300 595 minecraft:quartz_block
fill 194 299 597 194 300 597 minecraft:quartz_block
fill 195 299 590 195 300 590 minecraft:quartz_block
fill 195 299 592 195 300 592 minecraft:quartz_block
fill 195 299 594 195 300 594 minecraft:quartz_block
fill 195 299 596 195 300 596 minecraft:quartz_block
fill 195 299 598 195 300 598 minecraft:quartz_block
fill 196 299 591 196 300 591 minecraft:quartz_block
fill 196 299 593 196 300 593 minecraft:quartz_block
fill 196 299 595 196 300 595 minecraft:quartz_block
fill 196 299 597 196 300 597 minecraft:quartz_block
fill 197 299 590 197 300 590 minecraft:quartz_block
fill 197 299 592 197 300 592 minecraft:quartz_block
fill 197 299 594 197 300 594 minecraft:quartz_block
fill 197 299 596 197 300 596 minecraft:quartz_block
fill 197 299 598 197 300 598 minecraft:quartz_block
fill 198 299 591 198 300 591 minecraft:quartz_block
fill 198 299 593 198 300 593 minecraft:quartz_block
fill 198 299 595 198 300 595 minecraft:quartz_block
fill 198 299 597 198 300 597 minecraft:quartz_block
setblock 199 299 560 minecraft:light[level=14]
setblock 199 299 568 minecraft:light[level=14]
setblock 199 299 576 minecraft:light[level=14]
setblock 199 299 584 minecraft:light[level=14]
fill 199 299 590 199 300 590 minecraft:quartz_block
fill 199 299 592 199 300 592 minecraft:quartz_block
fill 199 299 594 199 300 594 minecraft:quartz_block
fill 199 299 596 199 300 596 minecraft:quartz_block
fill 199 299 598 199 300 598 minecraft:quartz_block
fill 200 299 591 200 300 591 minecraft:quartz_block
fill 200 299 593 200 300 593 minecraft:quartz_block
fill 200 299 595 200 300 595 minecraft:quartz_block
fill 200 299 597 200 300 597 minecraft:quartz_block
fill 201 299 590 201 300 590 minecraft:quartz_block
fill 201 299 592 201 300 592 minecraft:quartz_block
fill 201 299 594 201 300 594 minecraft:quartz_block
fill 201 299 596 201 300 596 minecraft:quartz_block
fill 201 299 598 201 300 598 minecraft:quartz_block
fill 202 299 591 202 300 591 minecraft:quartz_block
fill 202 299 593 202 300 593 minecraft:quartz_block
fill 202 299 595 202 300 595 minecraft:quartz_block
fill 202 299 597 202 300 597 minecraft:quartz_block
fill 203 299 590 203 300 590 minecraft:quartz_block
fill 203 299 592 203 300 592 minecraft:quartz_block
fill 203 299 594 203 300 594 minecraft:quartz_block
fill 203 299 596 203 300 596 minecraft:quartz_block
fill 203 299 598 203 300 598 minecraft:quartz_block
fill 204 299 564 204 300 564 minecraft:quartz_block
fill 204 299 591 204 300 591 minecraft:quartz_block
fill 204 299 593 204 300 593 minecraft:quartz_block
fill 204 299 595 204 300 595 minecraft:quartz_block
fill 204 299 597 204 300 597 minecraft:quartz_block
setblock 205 299 561 minecraft:gold_block
setblock 205 299 562 minecraft:quartz_block
fill 205 299 565 205 300 565 minecraft:quartz_block
fill 205 299 590 205 300 590 minecraft:quartz_block
fill 205 299 592 205 300 592 minecraft:quartz_block
fill 205 299 594 205 300 594 minecraft:quartz_block
fill 205 299 596 205 300 596 minecraft:quartz_block
fill 205 299 598 205 300 598 minecraft:quartz_block
fill 206 299 564 206 300 564 minecraft:quartz_block
fill 206 299 591 206 300 591 minecraft:quartz_block
setblock 207 299 560 minecraft:light[level=14]
setblock 207 299 568 minecraft:light[level=14]
setblock 207 299 576 minecraft:light[level=14]
setblock 207 299 584 minecraft:light[level=14]
setblock 207 299 592 minecraft:light[level=14]
setblock 215 299 560 minecraft:light[level=14]
setblock 215 299 568 minecraft:light[level=14]
setblock 215 299 576 minecraft:light[level=14]
setblock 215 299 584 minecraft:light[level=14]
setblock 215 299 592 minecraft:light[level=14]
setblock 223 299 560 minecraft:light[level=14]
setblock 223 299 568 minecraft:light[level=14]
setblock 223 299 576 minecraft:light[level=14]
setblock 223 299 584 minecraft:light[level=14]
setblock 223 299 592 minecraft:light[level=14]
fill 190 300 579 190 300 581 minecraft:quartz_block
fill 190 300 591 190 300 593 minecraft:quartz_block
fill 200 300 559 202 300 559 minecraft:quartz_block
fill 204 300 565 204 300 566 minecraft:quartz_block
fill 204 300 589 206 300 589 minecraft:quartz_block
setblock 205 300 562 minecraft:gold_block
setblock 205 300 563 minecraft:quartz_block
fill 205 300 566 205 300 567 minecraft:quartz_block
setblock 205 300 588 minecraft:quartz_block
fill 206 300 565 206 300 566 minecraft:quartz_block
setblock 206 300 590 minecraft:quartz_block
fill 208 300 597 210 300 597 minecraft:quartz_block
fill 212 300 559 214 300 559 minecraft:quartz_block
fill 220 300 597 222 300 597 minecraft:quartz_block
fill 224 300 559 226 300 559 minecraft:quartz_block
fill 227 300 586 227 300 592 minecraft:gold_block
fill 228 300 567 228 300 569 minecraft:quartz_block
fill 228 300 579 228 300 581 minecraft:quartz_block
fill 228 300 591 228 300 593 minecraft:quartz_block
