setblock 555 138 557 minecraft:white_concrete
fill 559 138 567 559 144 567 minecraft:black_concrete
fill 559 138 583 559 144 583 minecraft:black_concrete
setblock 517 139 584 minecraft:white_concrete
fill 517 139 586 517 170 586 minecraft:black_concrete
fill 522 139 557 522 166 557 minecraft:black_concrete
setblock 527 139 599 minecraft:white_stained_glass
setblock 529 139 599 minecraft:sea_lantern
fill 555 139 557 555 166 557 minecraft:black_concrete
setblock 556 139 557 minecraft:white_stained_glass
setblock 517 140 584 minecraft:black_concrete
setblock 520 140 560 minecraft:light[level=14]
setblock 520 140 568 minecraft:light[level=14]
setblock 520 140 576 minecraft:light[level=14]
setblock 520 140 584 minecraft:light[level=14]
setblock 520 140 592 minecraft:light[level=14]
fill 527 140 599 527 170 599 minecraft:black_concrete
setblock 528 140 560 minecraft:light[level=14]
setblock 528 140 568 minecraft:light[level=14]
setblock 528 140 576 minecraft:light[level=14]
setblock 528 140 584 minecraft:light[level=14]
setblock 528 140 592 minecraft:light[level=14]
fill 529 140 599 529 170 599 minecraft:black_concrete
setblock 536 140 560 minecraft:light[level=14]
setblock 536 140 568 minecraft:light[level=14]
setblock 536 140 576 minecraft:light[level=14]
setblock 536 140 584 minecraft:light[level=14]
setblock 536 140 592 minecraft:light[level=14]
setblock 537 140 599 minecraft:sea_lantern
fill 538 140 599 538 167 599 minecraft:black_concrete
setblock 544 140 560 minecraft:light[level=14]
setblock 544 140 568 minecraft:light[level=14]
setblock 544 140 576 minecraft:light[level=14]
setblock 544 140 584 minecraft:light[level=14]
setblock 544 140 592 minecraft:light[level=14]
setblock 552 140 560 minecraft:light[level=14]
setblock 552 140 568 minecraft:light[level=14]
setblock 552 140 576 minecraft:light[level=14]
setblock 552 140 584 minecraft:light[level=14]
setblock 552 140 592 minecraft:light[level=14]
fill 556 140 557 556 166 557 minecraft:black_concrete
setblock 517 141 584 minecraft:white_concrete
setblock 530 141 557 minecraft:white_stained_glass
fill 537 141 599 537 161 599 minecraft:black_concrete
setblock 547 141 599 minecraft:white_stained_glass
setblock 549 141 557 minecraft:white_concrete
fill 550 141 557 550 170 557 minecraft:black_concrete
setblock 554 141 599 minecraft:white_stained_glass
setblock 559 141 594 minecraft:white_concrete
fill 517 142 584 517 170 584 minecraft:black_concrete
fill 521 142 599 521 167 599 minecraft:black_concrete
setblock 522 142 599 minecraft:sea_lantern
fill 530 142 557 530 170 557 minecraft:black_concrete
setblock 531 142 599 minecraft:white_stained_glass
setblock 535 142 599 minecraft:white_stained_glass
fill 547 142 599 547 144 599 minecraft:black_concrete
fill 548 142 581 548 143 581 minecraft:blue_concrete
fill 549 142 557 549 170 557 minecraft:black_concrete
setblock 554 142 599 minecraft:black_concrete
setblock 555 142 599 minecraft:white_stained_glass
fill 559 142 594 559 166 594 minecraft:black_concrete
setblock 517 143 591 minecraft:sea_lantern
setblock 522 143 599 minecraft:black_concrete
fill 531 143 599 531 144 599 minecraft:black_concrete
fill 535 143 599 535 170 599 minecraft:black_concrete
setblock 536 143 599 minecraft:sea_lantern
fill 554 143 576 554 144 576 minecraft:white_stained_glass
setblock 554 143 599 minecraft:white_concrete
fill 555 143 599 555 170 599 minecraft:black_concrete
setblock 559 143 595 minecraft:white_stained_glass
fill 517 144 591 517 170 591 minecraft:black_concrete
setblock 522 144 599 minecraft:white_stained_glass
setblock 528 144 599 minecraft:sea_lantern
fill 536 144 599 536 170 599 minecraft:black_concrete
fill 554 144 599 554 151 599 minecraft:black_concrete
setblock 559 144 564 minecraft:white_stained_glass
fill 559 144 595 559 145 595 minecraft:black_concrete
fill 517 145 565 517 146 565 minecraft:white_concrete
fill 517 145 581 517 146 581 minecraft:white_concrete
fill 517 145 597 517 146 597 minecraft:white_concrete
fill 521 145 557 521 146 557 minecraft:white_concrete
fill 522 145 599 522 171 599 minecraft:black_concrete
fill 528 145 599 528 168 599 minecraft:black_concrete
fill 531 145 599 531 146 599 minecraft:white_concrete
fill 537 145 557 537 146 557 minecraft:white_concrete
fill 547 145 599 547 146 599 minecraft:white_concrete
fill 553 145 557 553 146 557 minecraft:white_concrete
fill 554 145 557 554 170 557 minecraft:black_concrete
fill 554 145 576 554 152 576 minecraft:black_concrete
fill 559 145 564 559 166 564 minecraft:black_concrete
fill 559 145 567 559 146 567 minecraft:white_concrete
fill 559 145 583 559 146 583 minecraft:white_concrete
fill 554 146 575 554 152 575 minecraft:black_concrete
setblock 559 146 565 minecraft:white_concrete
setblock 559 146 595 minecraft:white_stained_glass
fill 517 147 565 517 153 565 minecraft:black_concrete
fill 517 147 581 517 153 581 minecraft:black_concrete
fill 517 147 597 517 153 597 minecraft:black_concrete
setblock 518 147 599 minecraft:white_stained_glass
fill 521 147 557 521 153 557 minecraft:black_concrete
fill 531 147 599 531 150 599 minecraft:black_concrete
setblock 532 147 599 minecraft:sea_lantern
fill 537 147 557 537 153 557 minecraft:black_concrete
fill 547 147 599 547 149 599 minecraft:black_concrete
fill 553 147 557 553 153 557 minecraft:black_concrete
fill 553 147 576 553 152 576 minecraft:black_concrete
fill 555 147 575 555 152 576 minecraft:black_concrete
setblock 558 147 599 minecraft:white_stained_glass
fill 559 147 565 559 170 565 minecraft:black_concrete
fill 559 147 567 559 153 567 minecraft:black_concrete
fill 559 147 583 559 153 583 minecraft:black_concrete
fill 559 147 595 559 166 595 minecraft:black_concrete
fill 517 148 587 517 170 587 minecraft:black_concrete
setblock 517 148 588 minecraft:white_stained_glass
fill 518 148 599 518 162 599 minecraft:black_concrete
setblock 520 148 560 minecraft:light[level=14]
setblock 520 148 568 minecraft:light[level=14]
setblock 520 148 576 minecraft:light[level=14]
setblock 520 148 584 minecraft:light[level=14]
setblock 520 148 592 minecraft:light[level=14]
setblock 528 148 560 minecraft:light[level=14]
setblock 528 148 568 minecraft:light[level=14]
setblock 528 148 576 minecraft:light[level=14]
setblock 528 148 584 minecraft:light[level=14]
setblock 528 148 592 minecraft:light[level=14]
fill 532 148 599 532 153 599 minecraft:black_concrete
setblock 536 148 560 minecraft:light[level=14]
setblock 536 148 568 minecraft:light[level=14]
setblock 536 148 576 minecraft:light[level=14]
setblock 536 148 584 minecraft:light[level=14]
setblock 536 148 592 minecraft:light[level=14]
setblock 544 148 560 minecraft:light[level=14]
setblock 544 148 568 minecraft:light[level=14]
setblock 544 148 576 minecraft:light[level=14]
setblock 544 148 584 minecraft:light[level=14]
setblock 544 148 592 minecraft:light[level=14]
setblock 552 148 560 minecraft:light[level=14]
setblock 552 148 568 minecraft:light[level=14]
setblock 552 148 576 minecraft:light[level=14]
setblock 552 148 584 minecraft:light[level=14]
setblock 552 148 592 minecraft:light[level=14]
fill 553 148 575 553 152 575 minecraft:black_concrete
fill 553 148 577 555 152 577 minecraft:black_concrete
setblock 556 148 599 minecraft:sea_lantern
fill 558 148 599 558 167 599 minecraft:black_concrete
fill 517 149 588 517 170 588 minecraft:black_concrete
setblock 529 149 557 minecraft:white_concrete
setblock 539 149 599 minecraft:white_stained_glass
setblock 542 149 599 minecraft:white_stained_glass
fill 553 149 574 555 152 574 minecraft:black_concrete
fill 556 149 575 556 152 576 minecraft:black_concrete
fill 556 149 599 556 155 599 minecraft:black_concrete
fill 517 150 576 517 170 576 minecraft:black_concrete
setblock 517 150 577 minecraft:white_concrete
fill 517 150 578 517 170 580 minecraft:black_concrete
setblock 520 150 557 minecraft:white_stained_glass
fill 529 150 557 529 166 557 minecraft:black_concrete
fill 529 150 563 529 151 564 minecraft:blue_concrete
fill 530 150 564 530 151 564 minecraft:blue_concrete
fill 539 150 599 539 170 599 minecraft:black_concrete
fill 542 150 599 542 166 599 minecraft:black_concrete
setblock 547 150 599 minecraft:white_stained_glass
fill 552 150 575 552 152 577 minecraft:black_concrete
fill 553 150 578 555 152 578 minecraft:black_concrete
fill 556 150 574 556 152 574 minecraft:black_concrete
fill 556 150 577 556 152 577 minecraft:black_concrete
fill 517 151 577 517 153 577 minecraft:black_concrete
fill 520 151 557 520 170 557 minecraft:black_concrete
setblock 531 151 599 minecraft:white_concrete
fill 547 151 599 547 153 599 minecraft:black_concrete
fill 550 151 582 550 152 582 minecraft:blue_concrete
setblock 551 151 599 minecraft:white_concrete
fill 552 151 574 552 152 574 minecraft:black_concrete
fill 553 151 573 555 152 573 minecraft:black_concrete
fill 556 151 578 556 152 578 minecraft:black_concrete
fill 557 151 575 557 152 577 minecraft:black_concrete
setblock 528 152 557 minecraft:white_stained_glass
fill 531 152 599 531 153 599 minecraft:black_concrete
fill 551 152 575 551 152 577 minecraft:black_concrete
fill 551 152 599 551 170 599 minecraft:black_concrete
setblock 552 152 573 minecraft:black_concrete
setblock 552 152 578 minecraft:black_concrete
fill 553 152 579 555 152 579 minecraft:black_concrete
setblock 554 152 599 minecraft:white_concrete
setblock 556 152 573 minecraft:black_concrete
setblock 557 152 574 minecraft:black_concrete
setblock 559 152 562 minecraft:white_stained_glass
setblock 559 152 592 minecraft:white_stained_glass
fill 528 153 557 528 168 557 minecraft:black_concrete
fill 531 153 557 534 167 557 minecraft:black_concrete
setblock 535 153 557 minecraft:sea_lantern
fill 536 153 557 536 166 557 minecraft:black_concrete
fill 553 153 574 553 156 574 minecraft:obsidian
fill 554 153 577 554 155 577 minecraft:obsidian
fill 554 153 599 554 170 599 minecraft:black_concrete
fill 556 153 576 556 154 576 minecraft:obsidian
fill 559 153 562 559 156 562 minecraft:black_concrete
setblock 559 153 563 minecraft:white_concrete
fill 559 153 592 559 170 592 minecraft:black_concrete
fill 517 154 565 517 155 565 minecraft:white_concrete
setblock 517 154 575 minecraft:white_stained_glass
setblock 517 154 577 minecraft:white_stained_glass
fill 517 154 581 517 155 581 minecraft:white_concrete
fill 517 154 597 517 155 597 minecraft:white_concrete
fill 521 154 557 521 155 557 minecraft:white_concrete
fill 531 154 599 531 155 599 minecraft:white_concrete
setblock 532 154 599 minecraft:sea_lantern
fill 535 154 557 535 168 557 minecraft:black_concrete
fill 537 154 557 537 155 557 minecraft:white_concrete
fill 547 154 599 547 155 599 minecraft:white_concrete
fill 553 154 557 553 155 557 minecraft:white_concrete
fill 559 154 563 559 166 563 minecraft:black_concrete
fill 559 154 567 559 155 567 minecraft:white_concrete
fill 559 154 583 559 155 583 minecraft:white_concrete
setblock 517 155 560 minecraft:sea_lantern
fill 517 155 575 517 171 575 minecraft:black_concrete
fill 517 155 577 517 170 577 minecraft:black_concrete
setblock 517 155 585 minecraft:white_concrete
setblock 519 155 599 minecraft:white_stained_glass
setblock 523 155 599 minecraft:white_stained_glass
fill 527 155 566 528 156 567 minecraft:blue_concrete
fill 532 155 599 532 166 599 minecraft:black_concrete
fill 517 156 560 517 167 560 minecraft:black_concrete
fill 517 156 565 517 159 565 minecraft:black_concrete
fill 517 156 581 517 161 581 minecraft:black_concrete
fill 517 156 585 517 166 585 minecraft:black_concrete
fill 517 156 597 517 161 597 minecraft:black_concrete
fill 519 156 599 519 170 599 minecraft:black_concrete
setblock 520 156 560 minecraft:light[level=14]
setblock 520 156 568 minecraft:light[level=14]
setblock 520 156 576 minecraft:light[level=14]
setblock 520 156 584 minecraft:light[level=14]
setblock 520 156 592 minecraft:light[level=14]
fill 521 156 557 521 158 557 minecraft:black_concrete
fill 523 156 599 523 170 599 minecraft:black_concrete
setblock 528 156 560 minecraft:light[level=14]
setblock 528 156 568 minecraft:light[level=14]
setblock 528 156 576 minecraft:light[level=14]
setblock 528 156 584 minecraft:light[level=14]
setblock 528 156 592 minecraft:light[level=14]
fill 531 156 599 531 161 599 minecraft:black_concrete
setblock 536 156 560 minecraft:light[level=14]
setblock 536 156 568 minecraft:light[level=14]
setblock 536 156 576 minecraft:light[level=14]
setblock 536 156 584 minecraft:light[level=14]
setblock 536 156 592 minecraft:light[level=14]
fill 537 156 557 537 161 557 minecraft:black_concrete
setblock 544 156 560 minecraft:light[level=14]
setblock 544 156 568 minecraft:light[level=14]
setblock 544 156 576 minecraft:light[level=14]
setblock 544 156 584 minecraft:light[level=14]
setblock 544 156 592 minecraft:light[level=14]
fill 547 156 599 547 161 599 minecraft:black_concrete
setblock 548 156 557 minecraft:white_concrete
setblock 552 156 560 minecraft:light[level=14]
setblock 552 156 568 minecraft:light[level=14]
setblock 552 156 576 minecraft:light[level=14]
setblock 552 156 584 minecraft:light[level=14]
setblock 552 156 592 minecraft:light[level=14]
setblock 553 156 557 minecraft:white_stained_glass
setblock 556 156 599 minecraft:white_stained_glass
fill 559 156 567 559 161 567 minecraft:black_concrete
fill 559 156 583 559 161 583 minecraft:black_concrete
setblock 517 157 561 minecraft:sea_lantern
setblock 525 157 599 minecraft:white_concrete
fill 542 157 557 544 170 557 minecraft:black_concrete
setblock 543 157 599 minecraft:white_concrete
setblock 545 157 557 minecraft:white_stained_glass
fill 545 157 599 545 159 599 minecraft:black_concrete
setblock 546 157 599 minecraft:sea_lantern
fill 548 157 557 548 170 557 minecraft:black_concrete
setblock 552 157 599 minecraft:white_concrete
fill 553 157 557 553 161 557 minecraft:black_concrete
fill 556 157 599 556 168 599 minecraft:black_concrete
setblock 559 157 562 minecraft:sea_lantern
fill 517 158 561 517 170 561 minecraft:black_concrete
setblock 517 158 592 minecraft:sea_lantern
fill 525 158 599 525 171 599 minecraft:black_concrete
fill 543 158 599 543 166 599 minecraft:black_concrete
setblock 544 158 599 minecraft:sea_lantern
fill 545 158 557 545 164 557 minecraft:black_concrete
fill 546 158 599 546 163 599 minecraft:black_concrete
setblock 549 158 599 minecraft:white_concrete
fill 552 158 599 552 168 599 minecraft:black_concrete
setblock 559 158 559 minecraft:white_stained_glass
fill 559 158 562 559 170 562 minecraft:black_concrete
setblock 559 158 593 minecraft:white_concrete
setblock 517 159 562 minecraft:white_concrete
setblock 517 159 590 minecraft:white_stained_glass
fill 517 159 592 517 170 592 minecraft:black_concrete
setblock 521 159 557 minecraft:white_stained_glass
fill 544 159 599 544 170 599 minecraft:black_concrete
fill 549 159 599 549 167 599 minecraft:black_concrete
fill 559 159 559 559 170 559 minecraft:black_concrete
fill 559 159 593 559 170 593 minecraft:black_concrete
fill 517 160 562 517 167 562 minecraft:black_concrete
setblock 517 160 565 minecraft:sea_lantern
fill 517 160 590 517 168 590 minecraft:black_concrete
fill 521 160 557 521 161 557 minecraft:black_concrete
setblock 545 160 599 minecraft:white_concrete
setblock 559 160 558 minecraft:sea_lantern
setblock 517 161 565 minecraft:black_concrete
fill 545 161 599 545 170 599 minecraft:black_concrete
fill 559 161 558 559 170 558 minecraft:black_concrete
fill 517 162 565 517 164 565 minecraft:white_concrete
fill 517 162 581 517 164 581 minecraft:white_concrete
fill 517 162 597 517 164 597 minecraft:white_concrete
fill 521 162 557 521 164 557 minecraft:white_concrete
fill 531 162 599 531 164 599 minecraft:white_concrete
fill 537 162 557 537 164 557 minecraft:white_concrete
setblock 537 162 599 minecraft:white_stained_glass
fill 547 162 599 547 164 599 minecraft:white_concrete
fill 552 162 557 553 162 557 minecraft:white_concrete
fill 559 162 567 559 164 567 minecraft:white_concrete
setblock 559 162 576 minecraft:sea_lantern
fill 559 162 583 559 164 583 minecraft:white_concrete
setblock 518 163 599 minecraft:white_stained_glass
setblock 537 163 599 minecraft:black_concrete
fill 552 163 557 552 170 557 minecraft:black_concrete
fill 553 163 557 553 164 557 minecraft:white_concrete
fill 559 163 576 559 170 576 minecraft:black_concrete
fill 518 164 599 518 168 599 minecraft:black_concrete
setblock 520 164 560 minecraft:light[level=14]
setblock 520 164 568 minecraft:light[level=14]
setblock 520 164 576 minecraft:light[level=14]
setblock 520 164 584 minecraft:light[level=14]
setblock 520 164 592 minecraft:light[level=14]
setblock 528 164 560 minecraft:light[level=14]
setblock 528 164 568 minecraft:light[level=14]
setblock 528 164 576 minecraft:light[level=14]
setblock 528 164 584 minecraft:light[level=14]
setblock 528 164 592 minecraft:light[level=14]
setblock 536 164 560 minecraft:light[level=14]
setblock 536 164 568 minecraft:light[level=14]
setblock 536 164 576 minecraft:light[level=14]
setblock 536 164 584 minecraft:light[level=14]
setblock 536 164 592 minecraft:light[level=14]
setblock 537 164 599 minecraft:white_stained_glass
setblock 544 164 560 minecraft:light[level=14]
setblock 544 164 568 minecraft:light[level=14]
setblock 544 164 576 minecraft:light[level=14]
setblock 544 164 584 minecraft:light[level=14]
setblock 544 164 592 minecraft:light[level=14]
setblock 546 164 599 minecraft:sea_lantern
setblock 552 164 560 minecraft:light[level=14]
setblock 552 164 568 minecraft:light[level=14]
setblock 552 164 576 minecraft:light[level=14]
setblock 552 164 584 minecraft:light[level=14]
setblock 552 164 592 minecraft:light[level=14]
setblock 559 164 585 minecraft:white_stained_glass
setblock 517 165 558 minecraft:sea_lantern
fill 517 165 565 517 166 565 minecraft:black_concrete
fill 517 165 581 517 167 581 minecraft:black_concrete
fill 517 165 597 517 170 597 minecraft:black_concrete
fill 521 165 557 521 170 557 minecraft:black_concrete
fill 531 165 599 531 167 599 minecraft:black_concrete
fill 537 165 557 537 170 557 minecraft:black_concrete
fill 537 165 599 537 170 599 minecraft:black_concrete
setblock 545 165 557 minecraft:white_stained_glass
fill 546 165 599 547 166 599 minecraft:black_concrete
fill 550 165 590 550 166 590 minecraft:obsidian
fill 553 165 557 553 170 557 minecraft:black_concrete
fill 559 165 567 559 170 568 minecraft:black_concrete
setblock 559 165 569 minecraft:white_concrete
fill 559 165 570 559 165 571 minecraft:black_concrete
fill 559 165 583 559 170 583 minecraft:black_concrete
fill 559 165 585 559 170 585 minecraft:black_concrete
fill 517 166 558 517 170 558 minecraft:black_concrete
fill 545 166 557 545 170 557 minecraft:black_concrete
fill 559 166 569 559 166 570 minecraft:black_concrete
setblock 559 166 571 minecraft:sea_lantern
setblock 559 166 596 minecraft:sea_lantern
setblock 517 167 565 minecraft:blue_concrete
fill 517 167 570 517 170 570 minecraft:black_concrete
setblock 517 167 571 minecraft:blue_concrete
setblock 517 167 585 minecraft:blue_concrete
setblock 522 167 557 minecraft:blue_concrete
fill 523 167 557 523 170 557 minecraft:black_concrete
setblock 524 167 557 minecraft:blue_concrete
fill 525 167 557 526 168 557 minecraft:black_concrete
setblock 529 167 557 minecraft:sea_lantern
setblock 532 167 599 minecraft:blue_concrete
fill 536 167 557 536 168 557 minecraft:blue_concrete
fill 541 167 599 543 167 599 minecraft:blue_concrete
setblock 546 167 599 minecraft:blue_concrete
fill 547 167 599 547 170 599 minecraft:black_concrete
fill 555 167 557 556 167 557 minecraft:blue_concrete
setblock 557 167 599 minecraft:blue_concrete
setblock 559 167 560 minecraft:blue_concrete
fill 559 167 563 559 167 564 minecraft:blue_concrete
setblock 559 167 569 minecraft:blue_concrete
fill 559 167 570 559 170 571 minecraft:black_concrete
setblock 559 167 573 minecraft:blue_concrete
setblock 559 167 581 minecraft:blue_concrete
setblock 559 167 586 minecraft:blue_concrete
setblock 559 167 588 minecraft:sea_lantern
fill 559 167 594 559 167 595 minecraft:blue_concrete
fill 559 167 596 559 170 596 minecraft:black_concrete
setblock 517 168 560 minecraft:white_stained_glass
setblock 517 168 562 minecraft:blue_concrete
fill 517 168 565 517 170 565 minecraft:black_concrete
setblock 517 168 571 minecraft:black_concrete
setblock 517 168 572 minecraft:blue_concrete
setblock 517 168 581 minecraft:blue_concrete
fill 517 168 585 517 170 585 minecraft:black_concrete
fill 517 168 593 517 170 593 minecraft:black_concrete
fill 517 168 594 517 168 595 minecraft:blue_concrete
fill 520 168 599 521 168 599 minecraft:blue_concrete
fill 522 168 557 522 170 557 minecraft:black_concrete
fill 524 168 557 524 170 557 minecraft:black_concrete
fill 529 168 557 529 170 557 minecraft:black_concrete
fill 530 168 599 531 169 599 minecraft:blue_concrete
fill 531 168 557 531 170 557 minecraft:black_concrete
fill 532 168 557 533 168 557 minecraft:blue_concrete
fill 532 168 599 532 170 599 minecraft:black_concrete
setblock 534 168 557 minecraft:black_concrete
fill 538 168 557 540 168 557 minecraft:black_concrete
setblock 538 168 599 minecraft:white_concrete
fill 541 168 557 541 169 557 minecraft:blue_concrete
fill 541 168 599 543 170 599 minecraft:black_concrete
fill 546 168 599 546 170 599 minecraft:black_concrete
fill 549 168 599 550 168 599 minecraft:blue_concrete
fill 553 168 569 555 169 570 minecraft:obsidian
setblock 555 168 557 minecraft:white_concrete
fill 556 168 557 556 170 557 minecraft:black_concrete
fill 557 168 599 557 170 599 minecraft:black_concrete
fill 558 168 599 559 168 599 minecraft:blue_concrete
fill 559 168 560 559 169 560 minecraft:white_stained_glass
setblock 559 168 563 minecraft:sea_lantern
fill 559 168 564 559 170 564 minecraft:black_concrete
setblock 559 168 566 minecraft:blue_concrete
fill 559 168 569 559 170 569 minecraft:black_concrete
fill 559 168 573 559 170 573 minecraft:black_concrete
setblock 559 168 574 minecraft:sea_lantern
fill 559 168 575 559 171 575 minecraft:black_concrete
setblock 559 168 581 minecraft:black_concrete
setblock 559 168 586 minecraft:black_concrete
fill 559 168 588 559 170 588 minecraft:black_concrete
setblock 559 168 589 minecraft:blue_concrete
fill 559 168 594 559 170 595 minecraft:black_concrete
fill 517 169 560 517 170 560 minecraft:black_concrete
fill 517 169 562 517 171 562 minecraft:black_concrete
setblock 517 169 571 minecraft:blue_concrete
fill 517 169 572 517 170 572 minecraft:black_concrete
setblock 517 169 573 minecraft:blue_concrete
fill 517 169 581 517 170 581 minecraft:black_concrete
setblock 517 169 590 minecraft:blue_concrete
fill 517 169 594 517 170 595 minecraft:black_concrete
setblock 517 169 596 minecraft:blue_concrete
setblock 518 169 599 minecraft:blue_concrete
fill 520 169 599 521 170 599 minecraft:black_concrete
setblock 525 169 557 minecraft:blue_concrete
fill 526 169 557 526 170 557 minecraft:black_concrete
setblock 528 169 557 minecraft:sea_lantern
setblock 528 169 599 minecraft:blue_concrete
fill 532 169 557 533 170 557 minecraft:black_concrete
fill 534 169 557 535 169 557 minecraft:blue_concrete
fill 536 169 557 536 170 557 minecraft:black_concrete
fill 538 169 557 538 170 557 minecraft:black_concrete
fill 538 169 599 538 170 599 minecraft:black_concrete
setblock 539 169 557 minecraft:blue_concrete
fill 540 169 557 540 171 557 minecraft:black_concrete
fill 549 169 599 550 170 599 minecraft:black_concrete
setblock 552 169 599 minecraft:blue_concrete
fill 555 169 557 555 170 557 minecraft:black_concrete
setblock 556 169 599 minecraft:blue_concrete
fill 558 169 599 559 170 599 minecraft:black_concrete
fill 559 169 563 559 170 563 minecraft:black_concrete
fill 559 169 566 559 170 566 minecraft:black_concrete
fill 559 169 574 559 170 574 minecraft:black_concrete
setblock 559 169 581 minecraft:blue_concrete
setblock 559 169 586 minecraft:blue_concrete
fill 559 169 589 559 170 589 minecraft:black_concrete
setblock 517 170 571 minecraft:black_concrete
fill 517 170 573 517 172 573 minecraft:black_concrete
setblock 517 170 590 minecraft:black_concrete
setblock 517 170 596 minecraft:white_stained_glass
setblock 518 170 599 minecraft:black_concrete
setblock 525 170 557 minecraft:black_concrete
setblock 528 170 557 minecraft:black_concrete
setblock 528 170 599 minecraft:black_concrete
fill 530 170 599 531 170 599 minecraft:black_concrete
fill 534 170 557 535 170 557 minecraft:black_concrete
fill 539 170 557 539 171 557 minecraft:black_concrete
setblock 541 170 557 minecraft:black_concrete
setblock 552 170 599 minecraft:black_concrete
fill 556 170 599 556 171 599 minecraft:black_concrete
setblock 559 170 560 minecraft:black_concrete
setblock 559 170 581 minecraft:black_concrete
setblock 559 170 586 minecraft:black_concrete
fill 517 171 557 517 174 561 minecraft:blue_concrete
fill 517 171 563 517 202 563 minecraft:blue_concrete
setblock 517 171 564 minecraft:black_concrete
fill 517 171 565 517 173 565 minecraft:white_concrete
fill 517 171 566 517 172 566 minecraft:blue_concrete
setblock 517 171 567 minecraft:black_concrete
setblock 517 171 568 minecraft:blue_concrete
fill 517 171 570 517 207 572 minecraft:blue_concrete
fill 517 171 574 517 182 574 minecraft:blue_concrete
fill 517 171 576 517 192 578 minecraft:blue_concrete
setblock 517 171 579 minecraft:black_concrete
fill 517 171 580 517 179 580 minecraft:blue_concrete
fill 517 171 581 517 173 581 minecraft:white_concrete
fill 517 171 582 517 171 596 minecraft:blue_concrete
fill 517 171 597 517 173 597 minecraft:white_concrete
fill 517 171 598 517 234 598 minecraft:blue_concrete
fill 518 171 557 520 172 557 minecraft:blue_concrete
fill 518 171 599 521 171 599 minecraft:blue_concrete
fill 521 171 557 521 173 557 minecraft:white_concrete
fill 522 171 557 536 171 557 minecraft:blue_concrete
fill 523 171 599 524 182 599 minecraft:blue_concrete
fill 526 171 599 530 171 599 minecraft:blue_concrete
fill 531 171 599 531 173 599 minecraft:white_concrete
fill 532 171 599 533 175 599 minecraft:blue_concrete
fill 535 171 599 542 172 599 minecraft:blue_concrete
fill 537 171 557 537 173 557 minecraft:white_concrete
fill 538 171 557 538 186 557 minecraft:blue_concrete
fill 541 171 557 552 171 557 minecraft:blue_concrete
setblock 543 171 599 minecraft:white_stained_glass
fill 544 171 599 546 173 599 minecraft:blue_concrete
fill 547 171 599 547 173 599 minecraft:white_concrete
fill 548 171 599 555 171 599 minecraft:blue_concrete
fill 553 171 557 553 173 557 minecraft:white_concrete
fill 554 171 557 559 174 557 minecraft:blue_concrete
fill 557 171 599 559 212 599 minecraft:blue_concrete
fill 559 171 558 559 171 566 minecraft:blue_concrete
fill 559 171 567 559 173 567 minecraft:white_concrete
fill 559 171 568 559 171 574 minecraft:blue_concrete
fill 559 171 576 559 175 582 minecraft:blue_concrete
fill 559 171 583 559 174 583 minecraft:white_concrete
fill 559 171 584 559 171 598 minecraft:blue_concrete
fill 517 172 562 517 210 562 minecraft:blue_concrete
fill 517 172 564 517 212 564 minecraft:blue_concrete
setblock 517 172 567 minecraft:blue_concrete
setblock 517 172 568 minecraft:black_concrete
fill 517 172 569 517 180 569 minecraft:blue_concrete
fill 517 172 575 517 239 575 minecraft:blue_concrete
fill 517 172 579 517 192 579 minecraft:blue_concrete
fill 517 172 582 517 172 590 minecraft:blue_concrete
setblock 517 172 591 minecraft:black_concrete
fill 517 172 592 517 239 592 minecraft:blue_concrete
setblock 517 172 593 minecraft:black_concrete
fill 517 172 594 517 185 595 minecraft:blue_concrete
setblock 517 172 596 minecraft:black_concrete
setblock 517 172 599 minecraft:blue_concrete
setblock 518 172 599 minecraft:black_concrete
fill 519 172 599 522 172 599 minecraft:blue_concrete
setblock 520 172 560 minecraft:light[level=14]
setblock 520 172 568 minecraft:light[level=14]
setblock 520 172 576 minecraft:light[level=14]
setblock 520 172 584 minecraft:light[level=14]
setblock 520 172 592 minecraft:light[level=14]
fill 522 172 557 526 183 557 minecraft:blue_concrete
fill 525 172 599 528 172 599 minecraft:blue_concrete
setblock 527 172 557 minecraft:black_concrete
fill 528 172 557 536 172 557 minecraft:blue_concrete
setblock 528 172 560 minecraft:light[level=14]
setblock 528 172 568 minecraft:light[level=14]
setblock 528 172 576 minecraft:light[level=14]
setblock 528 172 584 minecraft:light[level=14]
setblock 528 172 592 minecraft:light[level=14]
setblock 529 172 599 minecraft:black_concrete
setblock 530 172 599 minecraft:blue_concrete
fill 534 172 599 534 213 599 minecraft:blue_concrete
setblock 536 172 560 minecraft:light[level=14]
setblock 536 172 568 minecraft:light[level=14]
setblock 536 172 576 minecraft:light[level=14]
setblock 536 172 584 minecraft:light[level=14]
setblock 536 172 592 minecraft:light[level=14]
fill 539 172 557 541 176 557 minecraft:blue_concrete
setblock 542 172 557 minecraft:black_concrete
fill 543 172 557 543 210 557 minecraft:blue_concrete
setblock 543 172 599 minecraft:blue_concrete
setblock 544 172 557 minecraft:black_concrete
setblock 544 172 560 minecraft:light[level=14]
setblock 544 172 568 minecraft:light[level=14]
setblock 544 172 576 minecraft:light[level=14]
setblock 544 172 584 minecraft:light[level=14]
setblock 544 172 592 minecraft:light[level=14]
fill 545 172 557 552 172 557 minecraft:blue_concrete
fill 548 172 599 554 182 599 minecraft:blue_concrete
setblock 552 172 560 minecraft:light[level=14]
setblock 552 172 568 minecraft:light[level=14]
setblock 552 172 576 minecraft:light[level=14]
setblock 552 172 584 minecraft:light[level=14]
setblock 552 172 592 minecraft:light[level=14]
setblock 555 172 599 minecraft:black_concrete
fill 556 172 599 556 190 599 minecraft:blue_concrete
fill 559 172 558 559 193 560 minecraft:blue_concrete
setblock 559 172 561 minecraft:black_concrete
fill 559 172 562 559 210 562 minecraft:blue_concrete
setblock 559 172 563 minecraft:black_concrete
fill 559 172 564 559 214 566 minecraft:blue_concrete
fill 559 172 568 559 217 568 minecraft:blue_concrete
setblock 559 172 569 minecraft:black_concrete
fill 559 172 570 559 235 570 minecraft:blue_concrete
setblock 559 172 571 minecraft:black_concrete
fill 559 172 572 559 172 575 minecraft:blue_concrete
fill 559 172 584 559 197 584 minecraft:blue_concrete
fill 559 172 585 559 172 586 minecraft:black_concrete
fill 559 172 587 559 172 594 minecraft:blue_concrete
setblock 559 172 595 minecraft:black_concrete
fill 559 172 596 559 205 598 minecraft:blue_concrete
setblock 517 173 566 minecraft:white_stained_glass
setblock 517 173 567 minecraft:black_concrete
fill 517 173 568 517 235 568 minecraft:blue_concrete
fill 517 173 573 517 197 573 minecraft:blue_concrete
fill 517 173 582 517 188 584 minecraft:blue_concrete
setblock 517 173 585 minecraft:black_concrete
fill 517 173 586 517 228 586 minecraft:blue_concrete
setblock 517 173 587 minecraft:sea_lantern
fill 517 173 588 517 178 591 minecraft:blue_concrete
fill 517 173 593 517 239 593 minecraft:blue_concrete
fill 517 173 596 517 188 596 minecraft:blue_concrete
setblock 517 173 599 minecraft:black_concrete
fill 518 173 557 519 199 557 minecraft:blue_concrete
fill 518 173 599 521 176 599 minecraft:blue_concrete
setblock 520 173 557 minecraft:black_concrete
setblock 522 173 599 minecraft:black_concrete
fill 524 173 571 525 178 572 minecraft:orange_concrete
setblock 525 173 599 minecraft:sea_lantern
fill 526 173 599 529 197 599 minecraft:blue_concrete
fill 527 173 557 531 210 557 minecraft:blue_concrete
setblock 530 173 599 minecraft:black_concrete
fill 531 173 593 533 174 593 minecraft:white_concrete
setblock 532 173 557 minecraft:black_concrete
fill 532 173 592 532 174 592 minecraft:white_concrete
fill 532 173 594 532 174 594 minecraft:white_concrete
fill 533 173 557 536 174 557 minecraft:blue_concrete
fill 535 173 599 541 175 599 minecraft:blue_concrete
fill 542 173 557 542 197 557 minecraft:blue_concrete
fill 542 173 599 543 173 599 minecraft:black_concrete
fill 544 173 557 545 211 557 minecraft:blue_concrete
fill 546 173 557 547 173 557 minecraft:black_concrete
fill 548 173 557 551 174 557 minecraft:blue_concrete
setblock 552 173 557 minecraft:black_concrete
fill 555 173 599 555 216 599 minecraft:blue_concrete
fill 559 173 561 559 209 561 minecraft:blue_concrete
fill 559 173 563 559 217 563 minecraft:blue_concrete
fill 559 173 569 559 239 569 minecraft:blue_concrete
fill 559 173 571 559 185 573 minecraft:blue_concrete
setblock 559 173 574 minecraft:black_concrete
fill 559 173 575 559 180 575 minecraft:blue_concrete
fill 559 173 585 559 179 587 minecraft:blue_concrete
setblock 559 173 588 minecraft:black_concrete
fill 559 173 589 559 235 590 minecraft:blue_concrete
setblock 559 173 591 minecraft:black_concrete
fill 559 173 592 559 188 595 minecraft:blue_concrete
fill 517 174 565 517 179 567 minecraft:blue_concrete
fill 517 174 581 517 179 581 minecraft:blue_concrete
fill 517 174 585 517 198 585 minecraft:blue_concrete
fill 517 174 587 517 236 587 minecraft:blue_concrete
fill 517 174 597 517 179 597 minecraft:blue_concrete
fill 517 174 599 517 240 599 minecraft:blue_concrete
fill 519 174 576 520 175 577 minecraft:white_concrete
fill 520 174 557 521 179 557 minecraft:blue_concrete
fill 522 174 599 522 210 599 minecraft:blue_concrete
fill 523 174 570 523 177 573 minecraft:orange_concrete
fill 524 174 570 526 177 570 minecraft:orange_concrete
fill 524 174 573 525 177 573 minecraft:orange_concrete
fill 525 174 599 525 185 599 minecraft:blue_concrete
fill 526 174 571 526 177 572 minecraft:orange_concrete
fill 530 174 599 531 179 599 minecraft:blue_concrete
fill 532 174 557 532 175 557 minecraft:blue_concrete
fill 537 174 557 537 179 557 minecraft:blue_concrete
fill 542 174 599 544 199 599 minecraft:blue_concrete
setblock 545 174 599 minecraft:white_stained_glass
fill 546 174 557 547 182 557 minecraft:blue_concrete
fill 546 174 599 547 175 599 minecraft:blue_concrete
fill 552 174 557 553 179 557 minecraft:blue_concrete
fill 559 174 567 559 179 567 minecraft:blue_concrete
fill 559 174 574 559 185 574 minecraft:blue_concrete
fill 559 174 588 559 217 588 minecraft:blue_concrete
fill 559 174 591 559 192 591 minecraft:blue_concrete
fill 517 175 557 517 235 557 minecraft:blue_concrete
setblock 517 175 558 minecraft:sea_lantern
fill 517 175 559 517 200 561 minecraft:blue_concrete
fill 522 175 570 522 176 572 minecraft:orange_concrete
fill 523 175 569 525 176 569 minecraft:orange_concrete
fill 526 175 573 526 176 573 minecraft:orange_concrete
fill 533 175 557 535 203 557 minecraft:blue_concrete
setblock 536 175 557 minecraft:white_concrete
fill 545 175 599 545 196 599 minecraft:blue_concrete
setblock 548 175 557 minecraft:white_stained_glass
fill 549 175 557 551 210 557 minecraft:blue_concrete
fill 554 175 557 555 180 557 minecraft:blue_concrete
setblock 556 175 557 minecraft:sea_lantern
fill 557 175 557 559 202 557 minecraft:blue_concrete
fill 559 175 583 559 179 583 minecraft:blue_concrete
fill 517 176 558 517 239 558 minecraft:blue_concrete
setblock 532 176 557 minecraft:white_concrete
setblock 532 176 599 minecraft:white_stained_glass
fill 533 176 599 533 221 599 minecraft:blue_concrete
setblock 535 176 599 minecraft:sea_lantern
fill 536 176 557 536 186 557 minecraft:blue_concrete
fill 536 176 599 540 184 599 minecraft:blue_concrete
setblock 541 176 599 minecraft:white_stained_glass
fill 546 176 599 546 187 599 minecraft:blue_concrete
setblock 547 176 599 minecraft:white_concrete
fill 548 176 557 548 239 557 minecraft:blue_concrete
fill 556 176 557 556 220 557 minecraft:blue_concrete
fill 559 176 576 559 178 578 minecraft:blue_concrete
setblock 559 176 579 minecraft:white_stained_glass
fill 559 176 580 559 205 582 minecraft:blue_concrete
fill 518 177 599 520 193 599 minecraft:blue_concrete
setblock 521 177 599 minecraft:white_concrete
fill 532 177 557 532 239 557 minecraft:blue_concrete
fill 532 177 599 532 186 599 minecraft:blue_concrete
fill 535 177 599 535 239 599 minecraft:blue_concrete
setblock 539 177 557 minecraft:white_stained_glass
fill 540 177 557 541 205 557 minecraft:blue_concrete
fill 541 177 599 541 214 599 minecraft:blue_concrete
fill 547 177 599 547 179 599 minecraft:blue_concrete
fill 559 177 579 559 179 579 minecraft:blue_concrete
fill 521 178 599 521 240 599 minecraft:blue_concrete
fill 529 178 563 530 179 563 minecraft:white_concrete
setblock 539 178 557 minecraft:blue_concrete
fill 517 179 588 517 191 588 minecraft:blue_concrete
setblock 517 179 589 minecraft:white_stained_glass
fill 517 179 590 517 183 591 minecraft:blue_concrete
fill 532 179 568 533 180 569 minecraft:white_concrete
setblock 539 179 557 minecraft:white_stained_glass
fill 559 179 576 559 229 576 minecraft:blue_concrete
setblock 559 179 577 minecraft:sea_lantern
fill 559 179 578 559 235 578 minecraft:blue_concrete
fill 517 180 565 517 181 565 minecraft:white_concrete
fill 517 180 566 517 181 567 minecraft:blue_concrete
setblock 517 180 580 minecraft:sea_lantern
fill 517 180 581 517 181 581 minecraft:white_concrete
fill 517 180 589 517 225 589 minecraft:blue_concrete
fill 517 180 597 517 181 597 minecraft:white_concrete
fill 520 180 557 520 181 557 minecraft:blue_concrete
setblock 520 180 560 minecraft:light[level=14]
setblock 520 180 568 minecraft:light[level=14]
setblock 520 180 576 minecraft:light[level=14]
setblock 520 180 584 minecraft:light[level=14]
setblock 520 180 592 minecraft:light[level=14]
fill 521 180 557 521 181 557 minecraft:white_concrete
setblock 528 180 560 minecraft:light[level=14]
setblock 528 180 568 minecraft:light[level=14]
setblock 528 180 576 minecraft:light[level=14]
setblock 528 180 584 minecraft:light[level=14]
setblock 528 180 592 minecraft:light[level=14]
fill 530 180 599 530 223 599 minecraft:blue_concrete
fill 531 180 599 531 181 599 minecraft:white_concrete
setblock 536 180 560 minecraft:light[level=14]
setblock 536 180 568 minecraft:light[level=14]
setblock 536 180 576 minecraft:light[level=14]
setblock 536 180 584 minecraft:light[level=14]
setblock 536 180 592 minecraft:light[level=14]
fill 537 180 557 537 181 557 minecraft:white_concrete
fill 539 180 557 539 200 557 minecraft:blue_concrete
setblock 544 180 560 minecraft:light[level=14]
setblock 544 180 568 minecraft:light[level=14]
setblock 544 180 576 minecraft:light[level=14]
setblock 544 180 584 minecraft:light[level=14]
setblock 544 180 592 minecraft:light[level=14]
fill 547 180 599 547 181 599 minecraft:white_concrete
fill 552 180 557 552 199 557 minecraft:blue_concrete
setblock 552 180 560 minecraft:light[level=14]
setblock 552 180 568 minecraft:light[level=14]
setblock 552 180 576 minecraft:light[level=14]
setblock 552 180 584 minecraft:light[level=14]
setblock 552 180 592 minecraft:light[level=14]
fill 553 180 557 553 181 557 minecraft:white_concrete
fill 559 180 567 559 181 567 minecraft:white_concrete
fill 559 180 577 559 223 577 minecraft:blue_concrete
setblock 559 180 579 minecraft:white_concrete
fill 559 180 583 559 181 583 minecraft:white_concrete
fill 559 180 585 559 181 585 minecraft:blue_concrete
setblock 559 180 586 minecraft:sea_lantern
fill 559 180 587 559 237 587 minecraft:blue_concrete
setblock 517 181 569 minecraft:sea_lantern
fill 517 181 580 517 239 580 minecraft:blue_concrete
fill 554 181 557 554 182 557 minecraft:blue_concrete
setblock 555 181 557 minecraft:sea_lantern
setblock 559 181 575 minecraft:sea_lantern
fill 559 181 579 559 239 579 minecraft:blue_concrete
fill 559 181 586 559 213 586 minecraft:blue_concrete
fill 517 182 565 517 197 566 minecraft:blue_concrete
setblock 517 182 567 minecraft:white_stained_glass
fill 517 182 569 517 239 569 minecraft:blue_concrete
fill 517 182 581 517 197 581 minecraft:blue_concrete
fill 517 182 597 517 197 597 minecraft:blue_concrete
setblock 520 182 557 minecraft:white_stained_glass
fill 521 182 557 521 196 557 minecraft:blue_concrete
fill 531 182 599 531 187 599 minecraft:blue_concrete
fill 537 182 557 537 186 557 minecraft:blue_concrete
fill 547 182 599 547 197 599 minecraft:blue_concrete
fill 553 182 557 553 197 557 minecraft:blue_concrete
fill 555 182 557 555 235 557 minecraft:blue_concrete
fill 559 182 567 559 197 567 minecraft:blue_concrete
fill 559 182 575 559 200 575 minecraft:blue_concrete
fill 559 182 583 559 192 583 minecraft:blue_concrete
setblock 559 182 585 minecraft:white_concrete
fill 517 183 567 517 185 567 minecraft:blue_concrete
setblock 517 183 574 minecraft:white_stained_glass
fill 520 183 557 520 237 557 minecraft:blue_concrete
setblock 523 183 599 minecraft:white_concrete
fill 524 183 599 524 239 599 minecraft:blue_concrete
setblock 546 183 557 minecraft:white_concrete
setblock 547 183 557 minecraft:white_stained_glass
fill 548 183 599 553 196 599 minecraft:blue_concrete
setblock 554 183 557 minecraft:sea_lantern
setblock 554 183 599 minecraft:sea_lantern
fill 559 183 585 559 239 585 minecraft:blue_concrete
fill 517 184 574 517 189 574 minecraft:blue_concrete
setblock 517 184 590 minecraft:white_stained_glass
fill 517 184 591 517 215 591 minecraft:blue_concrete
fill 522 184 557 524 185 557 minecraft:blue_concrete
fill 523 184 599 523 197 599 minecraft:blue_concrete
setblock 525 184 557 minecraft:white_concrete
fill 526 184 557 526 188 557 minecraft:blue_concrete
fill 546 184 557 547 194 557 minecraft:blue_concrete
fill 554 184 557 554 205 557 minecraft:blue_concrete
fill 554 184 599 554 239 599 minecraft:blue_concrete
fill 517 185 590 517 189 590 minecraft:blue_concrete
fill 525 185 557 525 195 557 minecraft:blue_concrete
fill 536 185 599 537 187 599 minecraft:blue_concrete
setblock 538 185 599 minecraft:white_concrete
fill 539 185 599 540 227 599 minecraft:blue_concrete
setblock 517 186 567 minecraft:sea_lantern
setblock 517 186 594 minecraft:white_concrete
fill 517 186 595 517 193 595 minecraft:blue_concrete
setblock 522 186 557 minecraft:white_concrete
fill 523 186 557 524 213 557 minecraft:blue_concrete
setblock 525 186 599 minecraft:white_stained_glass
fill 531 186 571 533 186 573 minecraft:redstone_block
fill 533 186 576 535 186 578 minecraft:redstone_block
fill 536 186 567 538 186 569 minecraft:redstone_block
fill 538 186 599 538 213 599 minecraft:blue_concrete
fill 539 186 576 541 186 578 minecraft:redstone_block
fill 559 186 571 559 219 571 minecraft:blue_concrete
setblock 559 186 572 minecraft:white_stained_glass
fill 559 186 573 559 232 573 minecraft:blue_concrete
setblock 559 186 574 minecraft:white_concrete
fill 517 187 567 517 194 567 minecraft:blue_concrete
fill 517 187 594 517 199 594 minecraft:blue_concrete
fill 518 187 572 530 187 574 minecraft:white_concrete
fill 522 187 557 522 235 557 minecraft:blue_concrete
fill 525 187 599 525 237 599 minecraft:blue_concrete
fill 531 187 574 535 187 574 minecraft:white_concrete
setblock 532 187 599 minecraft:sea_lantern
fill 534 187 572 535 187 573 minecraft:white_concrete
fill 536 187 557 538 187 566 minecraft:white_concrete
fill 536 187 570 538 187 571 minecraft:white_concrete
fill 536 187 575 538 187 592 minecraft:white_concrete
fill 539 187 572 556 187 574 minecraft:white_concrete
fill 559 187 572 559 239 572 minecraft:blue_concrete
fill 559 187 574 559 209 574 minecraft:blue_concrete
fill 518 188 558 529 188 571 minecraft:black_concrete
fill 518 188 572 530 188 572 minecraft:sea_lantern
fill 518 188 573 529 188 573 minecraft:white_concrete
fill 518 188 574 534 188 574 minecraft:sea_lantern
fill 518 188 575 531 188 598 minecraft:black_concrete
fill 530 188 558 534 188 569 minecraft:black_concrete
fill 530 188 570 530 188 571 minecraft:sea_lantern
setblock 530 188 573 minecraft:sea_lantern
fill 531 188 570 539 188 570 minecraft:sea_lantern
fill 531 188 571 533 188 573 minecraft:black_concrete
setblock 531 188 599 minecraft:sea_lantern
fill 532 188 575 532 188 579 minecraft:sea_lantern
fill 532 188 580 535 188 598 minecraft:black_concrete
fill 532 188 599 532 239 599 minecraft:blue_concrete
fill 533 188 575 535 188 575 minecraft:sea_lantern
fill 533 188 576 535 188 578 minecraft:black_concrete
fill 533 188 579 536 188 579 minecraft:sea_lantern
fill 534 188 571 534 188 573 minecraft:sea_lantern
fill 535 188 558 535 188 565 minecraft:black_concrete
fill 535 188 566 535 188 569 minecraft:sea_lantern
setblock 535 188 571 minecraft:sea_lantern
fill 535 188 572 535 188 574 minecraft:pearlescent_froglight
fill 536 188 557 536 188 566 minecraft:sea_lantern
fill 536 188 567 538 188 569 minecraft:black_concrete
fill 536 188 571 538 188 571 minecraft:pearlescent_froglight
fill 536 188 575 538 188 575 minecraft:pearlescent_froglight
fill 536 188 576 536 188 578 minecraft:sea_lantern
fill 536 188 580 536 188 592 minecraft:sea_lantern
fill 536 188 593 558 188 598 minecraft:black_concrete
setblock 536 188 599 minecraft:white_stained_glass
fill 537 188 557 537 188 565 minecraft:white_concrete
fill 537 188 566 539 188 566 minecraft:sea_lantern
fill 537 188 576 537 188 592 minecraft:white_concrete
fill 537 188 599 537 235 599 minecraft:blue_concrete
fill 538 188 557 538 188 565 minecraft:sea_lantern
fill 538 188 576 538 188 592 minecraft:sea_lantern
fill 539 188 558 558 188 565 minecraft:black_concrete
fill 539 188 567 539 188 569 minecraft:sea_lantern
setblock 539 188 571 minecraft:sea_lantern
fill 539 188 572 539 188 574 minecraft:pearlescent_froglight
fill 539 188 575 542 188 575 minecraft:sea_lantern
fill 539 188 576 541 188 578 minecraft:black_concrete
fill 539 188 579 542 188 579 minecraft:sea_lantern
fill 539 188 580 558 188 592 minecraft:black_concrete
fill 540 188 566 558 188 571 minecraft:black_concrete
fill 540 188 572 556 188 572 minecraft:sea_lantern
fill 540 188 573 556 188 573 minecraft:white_concrete
fill 540 188 574 556 188 574 minecraft:sea_lantern
fill 542 188 576 542 188 578 minecraft:sea_lantern
fill 543 188 575 558 188 579 minecraft:black_concrete
setblock 546 188 599 minecraft:sea_lantern
fill 557 188 572 558 188 574 minecraft:black_concrete
setblock 517 189 582 minecraft:sea_lantern
fill 517 189 583 517 189 584 minecraft:white_concrete
setblock 517 189 596 minecraft:white_concrete
fill 525 189 573 525 190 574 minecraft:cobblestone
setblock 526 189 557 minecraft:white_concrete
fill 527 189 566 527 190 567 minecraft:cobblestone
fill 527 189 581 527 190 582 minecraft:cobblestone
fill 528 189 566 533 189 580 minecraft:dark_oak_planks
fill 531 189 599 531 197 599 minecraft:blue_concrete
fill 534 189 562 534 190 563 minecraft:cobblestone
fill 534 189 566 546 189 569 minecraft:dark_oak_planks
fill 534 189 578 546 189 580 minecraft:dark_oak_planks
fill 534 189 585 534 190 586 minecraft:cobblestone
setblock 536 189 557 minecraft:sea_lantern
fill 536 189 599 536 194 599 minecraft:blue_concrete
fill 537 189 557 538 193 557 minecraft:blue_concrete
fill 541 189 562 541 190 563 minecraft:cobblestone
fill 541 189 585 541 190 586 minecraft:cobblestone
fill 542 189 570 546 189 577 minecraft:dark_oak_planks
fill 546 189 599 546 191 599 minecraft:blue_concrete
fill 548 189 566 548 190 567 minecraft:cobblestone
fill 548 189 581 548 190 582 minecraft:cobblestone
fill 550 189 573 550 190 574 minecraft:cobblestone
fill 559 189 592 559 235 594 minecraft:blue_concrete
setblock 559 189 595 minecraft:white_stained_glass
setblock 517 190 574 minecraft:white_concrete
fill 517 190 582 517 195 584 minecraft:blue_concrete
setblock 517 190 590 minecraft:white_stained_glass
fill 517 190 596 517 235 596 minecraft:blue_concrete
fill 526 190 557 526 220 557 minecraft:blue_concrete
fill 528 190 566 528 190 580 minecraft:dark_oak_planks
fill 529 190 566 546 190 566 minecraft:dark_oak_planks
fill 529 190 580 546 190 580 minecraft:dark_oak_planks
fill 536 190 557 536 231 557 minecraft:blue_concrete
fill 546 190 567 546 190 579 minecraft:dark_oak_planks
fill 559 190 595 559 222 595 minecraft:blue_concrete
fill 517 191 574 517 240 574 minecraft:blue_concrete
fill 517 191 590 517 202 590 minecraft:blue_concrete
setblock 528 191 566 minecraft:ochre_froglight
fill 528 191 567 528 196 568 minecraft:dark_oak_planks
setblock 528 191 569 minecraft:ochre_froglight
fill 528 191 570 528 196 571 minecraft:dark_oak_planks
setblock 528 191 572 minecraft:ochre_froglight
fill 528 191 573 528 196 574 minecraft:dark_oak_planks
setblock 528 191 575 minecraft:ochre_froglight
fill 528 191 576 528 196 577 minecraft:dark_oak_planks
setblock 528 191 578 minecraft:ochre_froglight
fill 528 191 579 528 196 580 minecraft:dark_oak_planks
fill 529 191 566 530 196 566 minecraft:dark_oak_planks
setblock 529 191 580 minecraft:ochre_froglight
fill 530 191 580 531 196 580 minecraft:dark_oak_planks
setblock 531 191 566 minecraft:ochre_froglight
fill 532 191 566 533 196 566 minecraft:dark_oak_planks
setblock 532 191 580 minecraft:ochre_froglight
fill 533 191 580 534 196 580 minecraft:dark_oak_planks
setblock 534 191 566 minecraft:ochre_froglight
fill 535 191 566 536 196 566 minecraft:dark_oak_planks
setblock 535 191 580 minecraft:ochre_froglight
fill 536 191 580 537 196 580 minecraft:dark_oak_planks
setblock 537 191 566 minecraft:ochre_froglight
fill 538 191 566 539 196 566 minecraft:dark_oak_planks
setblock 538 191 580 minecraft:ochre_froglight
fill 539 191 580 540 196 580 minecraft:dark_oak_planks
setblock 540 191 566 minecraft:ochre_froglight
fill 541 191 566 542 196 566 minecraft:dark_oak_planks
setblock 541 191 580 minecraft:ochre_froglight
fill 542 191 580 543 196 580 minecraft:dark_oak_planks
setblock 543 191 566 minecraft:ochre_froglight
fill 544 191 566 545 196 566 minecraft:dark_oak_planks
setblock 544 191 580 minecraft:ochre_froglight
fill 545 191 580 546 196 580 minecraft:dark_oak_planks
setblock 546 191 566 minecraft:ochre_froglight
fill 546 191 567 546 196 568 minecraft:dark_oak_planks
setblock 546 191 569 minecraft:ochre_froglight
fill 546 191 570 546 196 571 minecraft:dark_oak_planks
setblock 546 191 572 minecraft:ochre_froglight
fill 546 191 573 546 196 574 minecraft:dark_oak_planks
setblock 546 191 575 minecraft:ochre_froglight
fill 546 191 576 546 196 577 minecraft:dark_oak_planks
setblock 546 191 578 minecraft:ochre_froglight
fill 546 191 579 546 196 579 minecraft:dark_oak_planks
setblock 556 191 599 minecraft:white_concrete
setblock 517 192 588 minecraft:white_stained_glass
fill 528 192 566 528 194 566 minecraft:dark_oak_planks
fill 528 192 569 528 194 569 minecraft:dark_oak_planks
fill 528 192 572 528 194 572 minecraft:dark_oak_planks
fill 528 192 575 528 194 575 minecraft:dark_oak_planks
fill 528 192 578 528 194 578 minecraft:dark_oak_planks
fill 529 192 580 529 194 580 minecraft:dark_oak_planks
fill 531 192 566 531 194 566 minecraft:dark_oak_planks
fill 532 192 580 532 194 580 minecraft:dark_oak_planks
fill 534 192 566 534 194 566 minecraft:dark_oak_planks
fill 535 192 580 535 194 580 minecraft:dark_oak_planks
fill 537 192 566 537 194 566 minecraft:dark_oak_planks
fill 538 192 580 538 194 580 minecraft:dark_oak_planks
fill 540 192 566 540 194 566 minecraft:dark_oak_planks
fill 541 192 580 541 194 580 minecraft:dark_oak_planks
fill 543 192 566 543 194 566 minecraft:dark_oak_planks
fill 544 192 580 544 194 580 minecraft:dark_oak_planks
fill 546 192 566 546 194 566 minecraft:dark_oak_planks
fill 546 192 569 546 194 569 minecraft:dark_oak_planks
fill 546 192 572 546 194 572 minecraft:dark_oak_planks
fill 546 192 575 546 194 575 minecraft:dark_oak_planks
fill 546 192 578 546 194 578 minecraft:dark_oak_planks
setblock 546 192 599 minecraft:sea_lantern
fill 556 192 599 556 235 599 minecraft:blue_concrete
fill 517 193 576 517 213 576 minecraft:blue_concrete
setblock 517 193 577 minecraft:sea_lantern
fill 517 193 578 517 201 578 minecraft:blue_concrete
setblock 517 193 579 minecraft:sea_lantern
fill 517 193 588 517 239 588 minecraft:blue_concrete
fill 546 193 599 546 204 599 minecraft:blue_concrete
setblock 559 193 583 minecraft:sea_lantern
setblock 559 193 591 minecraft:white_concrete
fill 517 194 577 517 211 577 minecraft:blue_concrete
fill 517 194 579 517 204 579 minecraft:blue_concrete
setblock 517 194 595 minecraft:white_concrete
fill 518 194 599 519 214 599 minecraft:blue_concrete
setblock 520 194 599 minecraft:white_concrete
setblock 537 194 557 minecraft:sea_lantern
fill 538 194 557 538 214 557 minecraft:blue_concrete
fill 559 194 558 559 226 559 minecraft:blue_concrete
setblock 559 194 560 minecraft:white_concrete
fill 559 194 583 559 197 583 minecraft:blue_concrete
fill 559 194 591 559 198 591 minecraft:blue_concrete
setblock 517 195 567 minecraft:white_stained_glass
fill 517 195 595 517 207 595 minecraft:blue_concrete
fill 520 195 599 520 207 599 minecraft:blue_concrete
setblock 528 195 566 minecraft:ochre_froglight
setblock 528 195 569 minecraft:ochre_froglight
setblock 528 195 572 minecraft:ochre_froglight
setblock 528 195 575 minecraft:ochre_froglight
setblock 528 195 578 minecraft:ochre_froglight
setblock 529 195 580 minecraft:ochre_froglight
setblock 531 195 566 minecraft:ochre_froglight
setblock 532 195 580 minecraft:ochre_froglight
setblock 534 195 566 minecraft:ochre_froglight
setblock 535 195 580 minecraft:ochre_froglight
setblock 536 195 599 minecraft:white_concrete
fill 537 195 557 537 197 557 minecraft:blue_concrete
setblock 537 195 566 minecraft:ochre_froglight
setblock 538 195 580 minecraft:ochre_froglight
setblock 540 195 566 minecraft:ochre_froglight
setblock 541 195 580 minecraft:ochre_froglight
setblock 543 195 566 minecraft:ochre_froglight
setblock 544 195 580 minecraft:ochre_froglight
fill 546 195 557 546 239 557 minecraft:blue_concrete
setblock 546 195 566 minecraft:ochre_froglight
setblock 546 195 569 minecraft:ochre_froglight
setblock 546 195 572 minecraft:ochre_froglight
setblock 546 195 575 minecraft:ochre_froglight
setblock 546 195 578 minecraft:ochre_froglight
setblock 547 195 557 minecraft:white_stained_glass
fill 559 195 560 559 239 560 minecraft:blue_concrete
fill 517 196 567 517 239 567 minecraft:blue_concrete
fill 517 196 582 517 196 583 minecraft:blue_concrete
setblock 517 196 584 minecraft:sea_lantern
setblock 520 196 560 minecraft:light[level=14]
setblock 520 196 568 minecraft:light[level=14]
setblock 520 196 576 minecraft:light[level=14]
setblock 520 196 584 minecraft:light[level=14]
setblock 520 196 592 minecraft:light[level=14]
setblock 525 196 557 minecraft:white_stained_glass
setblock 528 196 560 minecraft:light[level=14]
setblock 528 196 566 minecraft:dark_oak_planks
fill 528 196 569 546 196 569 minecraft:dark_oak_planks
fill 528 196 572 533 196 572 minecraft:dark_oak_planks
fill 528 196 575 533 196 575 minecraft:dark_oak_planks
fill 528 196 578 546 196 578 minecraft:dark_oak_planks
setblock 528 196 584 minecraft:light[level=14]
setblock 528 196 592 minecraft:light[level=14]
fill 529 196 567 545 196 568 minecraft:dark_oak_planks
fill 529 196 570 533 196 571 minecraft:dark_oak_planks
fill 529 196 573 533 196 574 minecraft:dark_oak_planks
fill 529 196 576 533 196 577 minecraft:dark_oak_planks
fill 529 196 579 529 196 580 minecraft:dark_oak_planks
fill 530 196 579 545 196 579 minecraft:dark_oak_planks
setblock 531 196 566 minecraft:dark_oak_planks
setblock 532 196 580 minecraft:dark_oak_planks
setblock 534 196 566 minecraft:dark_oak_planks
setblock 535 196 580 minecraft:dark_oak_planks
setblock 536 196 560 minecraft:light[level=14]
setblock 536 196 584 minecraft:light[level=14]
setblock 536 196 592 minecraft:light[level=14]
setblock 536 196 599 minecraft:blue_concrete
setblock 537 196 566 minecraft:dark_oak_planks
setblock 538 196 580 minecraft:dark_oak_planks
setblock 540 196 566 minecraft:dark_oak_planks
setblock 541 196 580 minecraft:dark_oak_planks
fill 542 196 570 545 196 577 minecraft:dark_oak_planks
setblock 543 196 566 minecraft:dark_oak_planks
setblock 544 196 560 minecraft:light[level=14]
setblock 544 196 580 minecraft:dark_oak_planks
setblock 544 196 584 minecraft:light[level=14]
setblock 544 196 592 minecraft:light[level=14]
setblock 546 196 566 minecraft:dark_oak_planks
setblock 546 196 572 minecraft:dark_oak_planks
setblock 546 196 575 minecraft:dark_oak_planks
setblock 547 196 557 minecraft:white_concrete
setblock 552 196 560 minecraft:light[level=14]
setblock 552 196 568 minecraft:light[level=14]
setblock 552 196 576 minecraft:light[level=14]
setblock 552 196 584 minecraft:light[level=14]
setblock 552 196 592 minecraft:light[level=14]
fill 517 197 582 517 216 582 minecraft:blue_concrete
setblock 517 197 583 minecraft:sea_lantern
fill 517 197 584 517 239 584 minecraft:blue_concrete
setblock 521 197 557 minecraft:sea_lantern
fill 525 197 557 525 237 557 minecraft:blue_concrete
fill 528 197 566 533 197 580 minecraft:deepslate_tiles
fill 534 197 566 546 197 569 minecraft:deepslate_tiles
fill 534 197 578 546 197 580 minecraft:deepslate_tiles
setblock 536 197 599 minecraft:white_stained_glass
fill 542 197 570 546 197 577 minecraft:deepslate_tiles
setblock 545 197 599 minecraft:sea_lantern
fill 547 197 557 547 239 557 minecraft:blue_concrete
setblock 548 197 599 minecraft:white_stained_glass
fill 549 197 599 553 200 599 minecraft:blue_concrete
fill 517 198 565 517 200 565 minecraft:white_concrete
fill 517 198 566 517 225 566 minecraft:blue_concrete
setblock 517 198 573 minecraft:white_stained_glass
fill 517 198 581 517 200 581 minecraft:white_concrete
fill 517 198 583 517 231 583 minecraft:blue_concrete
fill 517 198 597 517 200 597 minecraft:white_concrete
fill 521 198 557 521 200 557 minecraft:white_concrete
setblock 523 198 599 minecraft:white_concrete
fill 526 198 599 527 198 599 minecraft:blue_concrete
setblock 528 198 599 minecraft:sea_lantern
fill 529 198 567 533 198 579 minecraft:deepslate_tiles
fill 529 198 599 529 208 599 minecraft:blue_concrete
fill 531 198 599 531 200 599 minecraft:white_concrete
fill 533 198 562 533 199 562 minecraft:white_concrete
fill 534 198 567 545 198 569 minecraft:deepslate_tiles
fill 534 198 578 545 198 579 minecraft:deepslate_tiles
fill 536 198 599 536 201 599 minecraft:blue_concrete
fill 537 198 557 537 200 557 minecraft:white_concrete
setblock 542 198 557 minecraft:sea_lantern
fill 542 198 570 545 198 577 minecraft:deepslate_tiles
fill 545 198 599 545 231 599 minecraft:blue_concrete
fill 547 198 599 547 200 599 minecraft:white_concrete
fill 548 198 599 548 239 599 minecraft:blue_concrete
fill 553 198 557 553 200 557 minecraft:white_concrete
fill 559 198 567 559 200 567 minecraft:white_concrete
fill 559 198 583 559 200 583 minecraft:white_concrete
setblock 559 198 584 minecraft:white_stained_glass
fill 517 199 573 517 235 573 minecraft:blue_concrete
setblock 517 199 585 minecraft:white_stained_glass
fill 523 199 599 523 203 599 minecraft:blue_concrete
fill 526 199 599 526 239 599 minecraft:blue_concrete
setblock 527 199 599 minecraft:white_stained_glass
fill 528 199 599 528 226 599 minecraft:blue_concrete
fill 530 199 568 533 199 578 minecraft:deepslate_tiles
fill 534 199 568 544 199 569 minecraft:deepslate_tiles
fill 534 199 578 544 199 578 minecraft:deepslate_tiles
fill 542 199 557 542 239 557 minecraft:blue_concrete
fill 542 199 570 544 199 577 minecraft:deepslate_tiles
fill 548 199 570 548 200 570 minecraft:blue_concrete
fill 559 199 584 559 239 584 minecraft:blue_concrete
setblock 559 199 591 minecraft:white_stained_glass
fill 517 200 585 517 212 585 minecraft:blue_concrete
setblock 517 200 594 minecraft:white_concrete
fill 518 200 557 518 212 557 minecraft:blue_concrete
setblock 519 200 557 minecraft:white_stained_glass
fill 527 200 599 527 212 599 minecraft:blue_concrete
fill 531 200 569 533 200 577 minecraft:deepslate_tiles
fill 534 200 569 543 200 569 minecraft:deepslate_tiles
fill 542 200 570 543 200 577 minecraft:deepslate_tiles
setblock 542 200 599 minecraft:sea_lantern
fill 543 200 599 544 239 599 minecraft:blue_concrete
setblock 552 200 557 minecraft:white_concrete
fill 559 200 591 559 239 591 minecraft:blue_concrete
setblock 517 201 559 minecraft:white_concrete
fill 517 201 560 517 236 561 minecraft:blue_concrete
fill 517 201 565 517 206 565 minecraft:blue_concrete
fill 517 201 581 517 206 581 minecraft:blue_concrete
fill 517 201 594 517 202 594 minecraft:blue_concrete
fill 517 201 597 517 206 597 minecraft:blue_concrete
fill 519 201 557 519 239 557 minecraft:blue_concrete
fill 521 201 557 521 206 557 minecraft:blue_concrete
fill 531 201 599 531 204 599 minecraft:blue_concrete
fill 532 201 570 533 201 576 minecraft:deepslate_tiles
fill 537 201 557 537 206 557 minecraft:blue_concrete
setblock 539 201 557 minecraft:sea_lantern
fill 542 201 570 542 201 576 minecraft:deepslate_tiles
setblock 542 201 599 minecraft:blue_concrete
fill 547 201 572 548 202 574 minecraft:white_concrete
fill 547 201 599 547 205 599 minecraft:blue_concrete
fill 549 201 599 549 206 599 minecraft:blue_concrete
setblock 550 201 599 minecraft:white_stained_glass
fill 551 201 599 553 227 599 minecraft:blue_concrete
setblock 552 201 557 minecraft:sea_lantern
fill 553 201 557 553 206 557 minecraft:blue_concrete
fill 559 201 567 559 206 567 minecraft:blue_concrete
setblock 559 201 575 minecraft:sea_lantern
fill 559 201 583 559 206 583 minecraft:blue_concrete
fill 517 202 559 517 205 559 minecraft:blue_concrete
setblock 517 202 578 minecraft:sea_lantern
fill 526 202 566 527 203 566 minecraft:obsidian
fill 533 202 571 533 202 575 minecraft:deepslate_tiles
setblock 536 202 599 minecraft:white_concrete
fill 539 202 557 539 203 557 minecraft:blue_concrete
setblock 542 202 599 minecraft:white_concrete
fill 550 202 599 550 239 599 minecraft:blue_concrete
fill 552 202 557 552 239 557 minecraft:blue_concrete
fill 559 202 575 559 205 575 minecraft:blue_concrete
setblock 517 203 563 minecraft:white_stained_glass
fill 517 203 578 517 211 578 minecraft:blue_concrete
setblock 517 203 590 minecraft:white_concrete
setblock 517 203 594 minecraft:white_concrete
fill 522 203 582 522 204 582 minecraft:white_stained_glass
fill 536 203 599 536 207 599 minecraft:blue_concrete
fill 542 203 599 542 212 599 minecraft:blue_concrete
fill 557 203 557 557 239 557 minecraft:blue_concrete
setblock 558 203 557 minecraft:white_stained_glass
fill 559 203 557 559 236 557 minecraft:blue_concrete
fill 517 204 563 517 205 563 minecraft:blue_concrete
fill 517 204 590 517 240 590 minecraft:blue_concrete
fill 517 204 594 517 205 594 minecraft:blue_concrete
setblock 520 204 560 minecraft:light[level=14]
setblock 520 204 568 minecraft:light[level=14]
setblock 520 204 576 minecraft:light[level=14]
setblock 520 204 584 minecraft:light[level=14]
setblock 520 204 592 minecraft:light[level=14]
setblock 523 204 599 minecraft:sea_lantern
setblock 528 204 560 minecraft:light[level=14]
setblock 528 204 568 minecraft:light[level=14]
setblock 528 204 576 minecraft:light[level=14]
setblock 528 204 584 minecraft:light[level=14]
setblock 528 204 592 minecraft:light[level=14]
fill 533 204 557 533 239 557 minecraft:blue_concrete
setblock 534 204 557 minecraft:white_stained_glass
fill 535 204 557 535 236 557 minecraft:blue_concrete
setblock 536 204 560 minecraft:light[level=14]
setblock 536 204 568 minecraft:light[level=14]
setblock 536 204 584 minecraft:light[level=14]
setblock 536 204 592 minecraft:light[level=14]
setblock 539 204 557 minecraft:sea_lantern
setblock 544 204 560 minecraft:light[level=14]
setblock 544 204 568 minecraft:light[level=14]
setblock 544 204 576 minecraft:light[level=14]
setblock 544 204 584 minecraft:light[level=14]
setblock 544 204 592 minecraft:light[level=14]
setblock 552 204 560 minecraft:light[level=14]
setblock 552 204 568 minecraft:light[level=14]
setblock 552 204 576 minecraft:light[level=14]
setblock 552 204 584 minecraft:light[level=14]
setblock 552 204 592 minecraft:light[level=14]
fill 558 204 557 558 232 557 minecraft:blue_concrete
setblock 517 205 579 minecraft:white_stained_glass
fill 522 205 582 522 213 582 minecraft:black_concrete
fill 523 205 599 523 240 599 minecraft:blue_concrete
setblock 531 205 599 minecraft:white_concrete
fill 534 205 557 534 239 557 minecraft:blue_concrete
setblock 539 205 557 minecraft:white_concrete
setblock 546 205 599 minecraft:sea_lantern
setblock 517 206 559 minecraft:white_concrete
setblock 517 206 563 minecraft:white_concrete
fill 517 206 579 517 239 579 minecraft:blue_concrete
setblock 517 206 594 minecraft:sea_lantern
fill 521 206 582 521 213 582 minecraft:black_concrete
fill 522 206 581 522 213 581 minecraft:black_concrete
fill 522 206 583 522 213 583 minecraft:black_concrete
fill 523 206 582 523 213 582 minecraft:black_concrete
setblock 531 206 599 minecraft:blue_concrete
fill 539 206 557 540 213 557 minecraft:blue_concrete
setblock 541 206 557 minecraft:white_stained_glass
fill 546 206 599 546 240 599 minecraft:blue_concrete
setblock 547 206 599 minecraft:sea_lantern
setblock 554 206 557 minecraft:white_stained_glass
fill 554 206 583 555 207 584 minecraft:blue_concrete
setblock 559 206 575 minecraft:sea_lantern
setblock 559 206 580 minecraft:sea_lantern
fill 559 206 581 559 207 582 minecraft:blue_concrete
fill 559 206 596 559 239 596 minecraft:blue_concrete
setblock 559 206 597 minecraft:white_stained_glass
fill 559 206 598 559 207 598 minecraft:blue_concrete
fill 517 207 559 517 239 559 minecraft:blue_concrete
fill 517 207 563 517 239 563 minecraft:blue_concrete
fill 517 207 565 517 209 565 minecraft:white_concrete
fill 517 207 581 517 209 581 minecraft:white_concrete
fill 517 207 594 517 239 594 minecraft:blue_concrete
fill 517 207 597 517 209 597 minecraft:white_concrete
fill 521 207 557 521 209 557 minecraft:white_concrete
fill 521 207 581 521 213 581 minecraft:black_concrete
fill 521 207 583 521 213 583 minecraft:black_concrete
fill 523 207 581 523 213 581 minecraft:black_concrete
fill 523 207 583 523 213 583 minecraft:black_concrete
fill 531 207 599 531 209 599 minecraft:white_concrete
fill 537 207 557 537 209 557 minecraft:white_concrete
fill 541 207 557 541 236 557 minecraft:blue_concrete
fill 547 207 599 547 209 599 minecraft:white_concrete
setblock 549 207 599 minecraft:white_concrete
fill 553 207 557 553 209 557 minecraft:white_concrete
fill 554 207 557 554 222 557 minecraft:blue_concrete
fill 559 207 567 559 209 567 minecraft:white_concrete
fill 559 207 575 559 227 575 minecraft:blue_concrete
fill 559 207 580 559 235 580 minecraft:blue_concrete
fill 559 207 583 559 209 583 minecraft:white_concrete
fill 559 207 597 559 236 597 minecraft:blue_concrete
fill 517 208 570 517 214 571 minecraft:blue_concrete
setblock 517 208 572 minecraft:white_concrete
setblock 517 208 595 minecraft:white_stained_glass
fill 520 208 582 520 213 582 minecraft:black_concrete
setblock 520 208 599 minecraft:white_concrete
fill 522 208 584 522 213 584 minecraft:black_concrete
fill 528 208 585 528 209 585 minecraft:white_stained_glass
setblock 536 208 599 minecraft:sea_lantern
fill 549 208 599 549 234 599 minecraft:blue_concrete
fill 559 208 581 559 240 581 minecraft:blue_concrete
setblock 559 208 582 minecraft:sea_lantern
setblock 559 208 598 minecraft:white_concrete
fill 517 209 572 517 215 572 minecraft:blue_concrete
fill 517 209 595 517 227 595 minecraft:blue_concrete
fill 520 209 581 520 213 581 minecraft:black_concrete
fill 520 209 583 520 213 583 minecraft:black_concrete
fill 520 209 599 520 226 599 minecraft:blue_concrete
fill 521 209 580 523 213 580 minecraft:black_concrete
fill 521 209 584 521 213 584 minecraft:black_concrete
fill 523 209 584 523 213 584 minecraft:black_concrete
fill 524 209 581 524 213 583 minecraft:black_concrete
setblock 529 209 599 minecraft:sea_lantern
fill 536 209 599 536 223 599 minecraft:blue_concrete
fill 559 209 582 559 239 582 minecraft:blue_concrete
fill 559 209 598 559 236 598 minecraft:blue_concrete
fill 517 210 565 517 215 565 minecraft:blue_concrete
fill 517 210 581 517 215 581 minecraft:blue_concrete
fill 517 210 597 517 215 597 minecraft:blue_concrete
fill 519 210 582 519 213 582 minecraft:black_concrete
fill 520 210 580 520 213 580 minecraft:black_concrete
fill 520 210 584 520 213 584 minecraft:black_concrete
fill 521 210 557 521 215 557 minecraft:blue_concrete
fill 522 210 585 522 213 585 minecraft:black_concrete
fill 524 210 580 524 213 580 minecraft:black_concrete
fill 524 210 584 524 213 584 minecraft:black_concrete
fill 527 210 585 528 217 585 minecraft:black_concrete
fill 529 210 599 529 215 599 minecraft:blue_concrete
fill 531 210 599 531 215 599 minecraft:blue_concrete
fill 537 210 557 537 212 557 minecraft:blue_concrete
fill 547 210 599 547 215 599 minecraft:blue_concrete
fill 553 210 557 553 215 557 minecraft:blue_concrete
setblock 559 210 561 minecraft:white_stained_glass
fill 559 210 567 559 215 567 minecraft:blue_concrete
setblock 559 210 574 minecraft:white_concrete
fill 559 210 583 559 215 583 minecraft:blue_concrete
setblock 517 211 562 minecraft:sea_lantern
fill 519 211 581 519 213 581 minecraft:black_concrete
fill 519 211 583 519 213 583 minecraft:black_concrete
fill 521 211 579 523 213 579 minecraft:black_concrete
fill 521 211 585 521 213 585 minecraft:black_concrete
setblock 522 211 599 minecraft:white_stained_glass
fill 523 211 585 523 213 585 minecraft:black_concrete
fill 525 211 581 525 213 583 minecraft:black_concrete
fill 527 211 557 528 239 557 minecraft:blue_concrete
setblock 529 211 557 minecraft:sea_lantern
fill 530 211 557 531 235 557 minecraft:blue_concrete
setblock 543 211 557 minecraft:white_concrete
setblock 549 211 557 minecraft:sea_lantern
fill 550 211 557 551 217 557 minecraft:blue_concrete
fill 559 211 561 559 237 561 minecraft:blue_concrete
setblock 559 211 562 minecraft:white_stained_glass
fill 559 211 574 559 235 574 minecraft:blue_concrete
fill 517 212 562 517 225 562 minecraft:blue_concrete
setblock 517 212 577 minecraft:sea_lantern
setblock 517 212 578 minecraft:white_stained_glass
fill 519 212 580 519 213 580 minecraft:black_concrete
fill 519 212 584 519 213 584 minecraft:black_concrete
setblock 520 212 560 minecraft:light[level=14]
setblock 520 212 568 minecraft:light[level=14]
setblock 520 212 576 minecraft:light[level=14]
fill 520 212 579 520 213 579 minecraft:black_concrete
fill 520 212 585 520 213 585 minecraft:black_concrete
setblock 520 212 592 minecraft:light[level=14]
fill 522 212 599 522 235 599 minecraft:blue_concrete
fill 524 212 579 524 213 579 minecraft:black_concrete
fill 524 212 585 524 213 585 minecraft:black_concrete
fill 525 212 580 525 213 580 minecraft:black_concrete
fill 525 212 584 525 213 584 minecraft:black_concrete
fill 527 212 584 528 217 584 minecraft:black_concrete
fill 527 212 586 528 217 586 minecraft:black_concrete
setblock 528 212 560 minecraft:light[level=14]
setblock 528 212 568 minecraft:light[level=14]
setblock 528 212 576 minecraft:light[level=14]
setblock 528 212 592 minecraft:light[level=14]
fill 529 212 557 529 237 557 minecraft:blue_concrete
setblock 536 212 560 minecraft:light[level=14]
setblock 536 212 568 minecraft:light[level=14]
setblock 536 212 576 minecraft:light[level=14]
setblock 536 212 584 minecraft:light[level=14]
setblock 536 212 592 minecraft:light[level=14]
fill 543 212 557 544 239 557 minecraft:blue_concrete
setblock 544 212 560 minecraft:light[level=14]
setblock 544 212 568 minecraft:light[level=14]
setblock 544 212 576 minecraft:light[level=14]
setblock 544 212 584 minecraft:light[level=14]
setblock 544 212 592 minecraft:light[level=14]
setblock 545 212 557 minecraft:sea_lantern
fill 549 212 557 549 235 557 minecraft:blue_concrete
setblock 552 212 560 minecraft:light[level=14]
setblock 552 212 568 minecraft:light[level=14]
setblock 552 212 576 minecraft:light[level=14]
setblock 552 212 584 minecraft:light[level=14]
setblock 552 212 592 minecraft:light[level=14]
fill 559 212 562 559 220 562 minecraft:blue_concrete
setblock 517 213 564 minecraft:white_stained_glass
fill 517 213 577 517 214 578 minecraft:blue_concrete
setblock 517 213 585 minecraft:white_concrete
setblock 518 213 557 minecraft:sea_lantern
fill 518 213 581 518 213 583 minecraft:black_concrete
setblock 519 213 579 minecraft:black_concrete
setblock 519 213 585 minecraft:black_concrete
fill 520 213 586 523 213 586 minecraft:black_concrete
fill 521 213 578 523 213 578 minecraft:black_concrete
setblock 525 213 579 minecraft:black_concrete
fill 525 213 585 526 213 585 minecraft:black_concrete
fill 526 213 581 526 213 584 minecraft:black_concrete
setblock 527 213 599 minecraft:white_concrete
fill 529 213 584 529 217 586 minecraft:black_concrete
setblock 537 213 557 minecraft:sea_lantern
setblock 542 213 599 minecraft:white_concrete
fill 545 213 557 545 219 557 minecraft:blue_concrete
setblock 557 213 599 minecraft:white_stained_glass
fill 558 213 599 559 236 599 minecraft:blue_concrete
fill 517 214 564 517 215 564 minecraft:blue_concrete
setblock 517 214 576 minecraft:sea_lantern
fill 517 214 585 517 239 585 minecraft:blue_concrete
fill 518 214 557 518 239 557 minecraft:blue_concrete
fill 520 214 582 520 215 582 minecraft:obsidian
fill 522 214 581 522 216 581 minecraft:obsidian
setblock 523 214 557 minecraft:sea_lantern
fill 523 214 583 523 216 583 minecraft:obsidian
fill 524 214 557 524 220 557 minecraft:blue_concrete
fill 526 214 584 526 217 586 minecraft:black_concrete
fill 527 214 583 528 217 583 minecraft:black_concrete
fill 527 214 587 528 217 587 minecraft:black_concrete
fill 527 214 599 527 229 599 minecraft:blue_concrete
setblock 534 214 599 minecraft:white_stained_glass
fill 537 214 557 537 215 557 minecraft:blue_concrete
setblock 538 214 599 minecraft:white_concrete
fill 539 214 557 539 215 557 minecraft:blue_concrete
setblock 540 214 557 minecraft:white_concrete
fill 542 214 599 542 219 599 minecraft:blue_concrete
fill 557 214 599 557 239 599 minecraft:blue_concrete
setblock 559 214 586 minecraft:sea_lantern
setblock 517 215 570 minecraft:white_concrete
fill 517 215 571 517 239 571 minecraft:blue_concrete
fill 517 215 576 517 222 576 minecraft:blue_concrete
setblock 517 215 577 minecraft:white_stained_glass
fill 517 215 578 517 236 578 minecraft:blue_concrete
fill 518 215 599 518 239 599 minecraft:blue_concrete
setblock 519 215 599 minecraft:white_stained_glass
fill 523 215 557 523 236 557 minecraft:blue_concrete
fill 525 215 584 525 217 586 minecraft:black_concrete
fill 526 215 583 526 217 583 minecraft:black_concrete
fill 526 215 587 526 217 587 minecraft:black_concrete
fill 529 215 583 529 217 583 minecraft:black_concrete
fill 529 215 587 529 217 587 minecraft:black_concrete
fill 530 215 584 530 217 586 minecraft:black_concrete
fill 534 215 599 534 239 599 minecraft:blue_concrete
setblock 538 215 557 minecraft:white_concrete
fill 538 215 599 538 239 599 minecraft:blue_concrete
fill 540 215 557 540 236 557 minecraft:blue_concrete
setblock 541 215 599 minecraft:white_concrete
fill 559 215 564 559 218 565 minecraft:blue_concrete
setblock 559 215 566 minecraft:sea_lantern
fill 559 215 586 559 240 586 minecraft:blue_concrete
setblock 517 216 564 minecraft:white_stained_glass
fill 517 216 565 517 218 565 minecraft:white_concrete
setblock 517 216 570 minecraft:white_stained_glass
setblock 517 216 572 minecraft:white_stained_glass
fill 517 216 577 517 236 577 minecraft:blue_concrete
fill 517 216 581 517 218 581 minecraft:white_concrete
setblock 517 216 591 minecraft:sea_lantern
fill 517 216 597 517 218 597 minecraft:white_concrete
fill 519 216 599 519 225 599 minecraft:blue_concrete
fill 521 216 557 521 218 557 minecraft:white_concrete
fill 525 216 583 525 217 583 minecraft:black_concrete
fill 527 216 582 528 217 582 minecraft:black_concrete
fill 527 216 588 528 217 588 minecraft:black_concrete
setblock 529 216 599 minecraft:white_stained_glass
fill 530 216 583 530 217 583 minecraft:black_concrete
fill 530 216 587 530 217 587 minecraft:black_concrete
fill 531 216 599 531 218 599 minecraft:white_concrete
fill 537 216 557 537 218 557 minecraft:white_concrete
fill 538 216 557 538 235 557 minecraft:blue_concrete
setblock 539 216 557 minecraft:sea_lantern
fill 541 216 599 541 226 599 minecraft:blue_concrete
fill 547 216 599 547 218 599 minecraft:white_concrete
fill 553 216 557 553 218 557 minecraft:white_concrete
fill 559 216 566 559 236 566 minecraft:blue_concrete
fill 559 216 567 559 218 567 minecraft:white_concrete
fill 559 216 583 559 218 583 minecraft:white_concrete
fill 517 217 564 517 236 564 minecraft:blue_concrete
fill 517 217 570 517 239 570 minecraft:blue_concrete
fill 517 217 572 517 239 572 minecraft:blue_concrete
setblock 517 217 582 minecraft:white_stained_glass
fill 517 217 591 517 239 591 minecraft:blue_concrete
fill 524 217 584 524 217 586 minecraft:black_concrete
setblock 525 217 587 minecraft:black_concrete
setblock 526 217 582 minecraft:black_concrete
setblock 526 217 588 minecraft:black_concrete
setblock 529 217 582 minecraft:black_concrete
setblock 529 217 588 minecraft:black_concrete
fill 529 217 599 529 235 599 minecraft:blue_concrete
fill 531 217 584 531 217 586 minecraft:black_concrete
fill 539 217 557 539 239 557 minecraft:blue_concrete
setblock 555 217 599 minecraft:sea_lantern
fill 517 218 582 517 239 582 minecraft:blue_concrete
fill 526 218 586 526 219 586 minecraft:obsidian
fill 527 218 583 527 219 583 minecraft:obsidian
fill 529 218 586 529 219 586 minecraft:obsidian
fill 550 218 557 550 236 557 minecraft:blue_concrete
fill 550 218 564 551 219 565 minecraft:obsidian
setblock 551 218 557 minecraft:white_concrete
fill 552 218 564 552 219 564 minecraft:obsidian
fill 555 218 599 555 237 599 minecraft:blue_concrete
setblock 559 218 563 minecraft:white_stained_glass
setblock 559 218 568 minecraft:sea_lantern
setblock 559 218 588 minecraft:white_stained_glass
fill 517 219 565 517 224 565 minecraft:blue_concrete
fill 517 219 581 517 221 581 minecraft:blue_concrete
fill 517 219 597 517 224 597 minecraft:blue_concrete
fill 521 219 557 521 224 557 minecraft:blue_concrete
fill 531 219 599 531 224 599 minecraft:blue_concrete
fill 537 219 557 537 224 557 minecraft:blue_concrete
fill 547 219 599 547 224 599 minecraft:blue_concrete
fill 551 219 557 551 239 557 minecraft:blue_concrete
fill 553 219 557 553 224 557 minecraft:blue_concrete
fill 559 219 563 559 222 563 minecraft:blue_concrete
setblock 559 219 564 minecraft:sea_lantern
fill 559 219 565 559 239 565 minecraft:blue_concrete
fill 559 219 567 559 219 568 minecraft:blue_concrete
fill 559 219 583 559 224 583 minecraft:blue_concrete
fill 559 219 588 559 237 588 minecraft:blue_concrete
setblock 520 220 560 minecraft:light[level=14]
setblock 520 220 568 minecraft:light[level=14]
setblock 520 220 576 minecraft:light[level=14]
setblock 520 220 584 minecraft:light[level=14]
setblock 520 220 592 minecraft:light[level=14]
setblock 528 220 560 minecraft:light[level=14]
setblock 528 220 568 minecraft:light[level=14]
setblock 528 220 576 minecraft:light[level=14]
setblock 528 220 584 minecraft:light[level=14]
setblock 528 220 592 minecraft:light[level=14]
setblock 536 220 560 minecraft:light[level=14]
setblock 536 220 568 minecraft:light[level=14]
setblock 536 220 576 minecraft:light[level=14]
setblock 536 220 584 minecraft:light[level=14]
setblock 536 220 592 minecraft:light[level=14]
setblock 542 220 599 minecraft:white_concrete
setblock 544 220 560 minecraft:light[level=14]
setblock 544 220 568 minecraft:light[level=14]
setblock 544 220 576 minecraft:light[level=14]
setblock 544 220 584 minecraft:light[level=14]
setblock 544 220 592 minecraft:light[level=14]
setblock 545 220 557 minecraft:white_concrete
setblock 552 220 560 minecraft:light[level=14]
setblock 552 220 568 minecraft:light[level=14]
setblock 552 220 576 minecraft:light[level=14]
setblock 552 220 584 minecraft:light[level=14]
setblock 552 220 592 minecraft:light[level=14]
fill 559 220 564 559 225 564 minecraft:blue_concrete
setblock 559 220 567 minecraft:sea_lantern
fill 559 220 568 559 239 568 minecraft:blue_concrete
setblock 559 220 571 minecraft:sea_lantern
setblock 524 221 557 minecraft:sea_lantern
setblock 526 221 557 minecraft:white_concrete
fill 542 221 599 542 239 599 minecraft:blue_concrete
fill 545 221 557 545 235 557 minecraft:blue_concrete
setblock 556 221 557 minecraft:sea_lantern
setblock 559 221 562 minecraft:white_concrete
fill 559 221 567 559 224 567 minecraft:blue_concrete
fill 559 221 571 559 235 571 minecraft:blue_concrete
setblock 517 222 581 minecraft:white_concrete
fill 524 222 557 524 239 557 minecraft:blue_concrete
fill 526 222 557 526 239 557 minecraft:blue_concrete
setblock 533 222 599 minecraft:sea_lantern
fill 556 222 557 556 239 557 minecraft:blue_concrete
fill 559 222 562 559 226 562 minecraft:blue_concrete
setblock 517 223 576 minecraft:white_stained_glass
fill 517 223 581 517 224 581 minecraft:blue_concrete
fill 533 223 599 533 239 599 minecraft:blue_concrete
fill 553 223 579 554 224 579 minecraft:blue_concrete
setblock 554 223 557 minecraft:white_concrete
setblock 559 223 563 minecraft:white_concrete
setblock 559 223 595 minecraft:white_concrete
fill 517 224 576 517 239 576 minecraft:blue_concrete
setblock 530 224 599 minecraft:white_stained_glass
fill 535 224 568 535 225 569 minecraft:white_concrete
setblock 536 224 599 minecraft:white_concrete
fill 544 224 567 545 225 568 minecraft:blue_concrete
setblock 554 224 557 minecraft:blue_concrete
fill 559 224 563 559 237 563 minecraft:blue_concrete
setblock 559 224 577 minecraft:sea_lantern
fill 559 224 595 559 239 595 minecraft:blue_concrete
fill 517 225 565 517 227 565 minecraft:white_concrete
fill 517 225 581 517 227 581 minecraft:white_concrete
fill 517 225 597 517 227 597 minecraft:white_concrete
fill 521 225 557 521 227 557 minecraft:white_concrete
fill 530 225 599 530 235 599 minecraft:blue_concrete
fill 531 225 599 531 227 599 minecraft:white_concrete
fill 536 225 599 536 229 599 minecraft:blue_concrete
fill 537 225 557 537 227 557 minecraft:white_concrete
fill 538 225 589 539 226 590 minecraft:blue_concrete
fill 547 225 599 547 227 599 minecraft:white_concrete
fill 553 225 557 553 227 557 minecraft:white_concrete
setblock 554 225 557 minecraft:white_stained_glass
fill 559 225 567 559 227 567 minecraft:white_concrete
fill 559 225 577 559 236 577 minecraft:blue_concrete
fill 559 225 583 559 227 583 minecraft:white_concrete
setblock 517 226 562 minecraft:white_stained_glass
setblock 517 226 566 minecraft:white_concrete
setblock 517 226 589 minecraft:white_stained_glass
setblock 519 226 599 minecraft:white_stained_glass
setblock 554 226 557 minecraft:sea_lantern
setblock 559 226 564 minecraft:white_stained_glass
fill 517 227 562 517 239 562 minecraft:blue_concrete
fill 517 227 566 517 239 566 minecraft:blue_concrete
fill 517 227 589 517 239 589 minecraft:blue_concrete
fill 519 227 599 519 235 599 minecraft:blue_concrete
setblock 520 227 599 minecraft:white_concrete
setblock 528 227 599 minecraft:white_stained_glass
setblock 541 227 599 minecraft:sea_lantern
fill 554 227 557 554 239 557 minecraft:blue_concrete
setblock 559 227 558 minecraft:white_concrete
fill 559 227 559 559 239 559 minecraft:blue_concrete
setblock 559 227 562 minecraft:sea_lantern
fill 559 227 564 559 239 564 minecraft:blue_concrete
setblock 517 228 565 minecraft:blue_concrete
fill 517 228 581 517 239 581 minecraft:blue_concrete
setblock 517 228 595 minecraft:white_stained_glass
fill 517 228 597 517 239 597 minecraft:blue_concrete
setblock 520 228 560 minecraft:light[level=14]
setblock 520 228 568 minecraft:light[level=14]
setblock 520 228 576 minecraft:light[level=14]
setblock 520 228 584 minecraft:light[level=14]
setblock 520 228 592 minecraft:light[level=14]
fill 520 228 599 520 239 599 minecraft:blue_concrete
fill 521 228 557 521 239 557 minecraft:blue_concrete
fill 526 228 579 527 229 579 minecraft:blue_concrete
setblock 528 228 560 minecraft:light[level=14]
setblock 528 228 568 minecraft:light[level=14]
setblock 528 228 576 minecraft:light[level=14]
setblock 528 228 584 minecraft:light[level=14]
setblock 528 228 592 minecraft:light[level=14]
fill 528 228 599 528 239 599 minecraft:blue_concrete
fill 531 228 599 531 235 599 minecraft:blue_concrete
setblock 536 228 560 minecraft:light[level=14]
setblock 536 228 568 minecraft:light[level=14]
setblock 536 228 576 minecraft:light[level=14]
setblock 536 228 584 minecraft:light[level=14]
setblock 536 228 592 minecraft:light[level=14]
fill 537 228 557 537 230 557 minecraft:blue_concrete
setblock 539 228 599 minecraft:white_concrete
fill 540 228 599 541 240 599 minecraft:blue_concrete
setblock 544 228 560 minecraft:light[level=14]
setblock 544 228 568 minecraft:light[level=14]
setblock 544 228 576 minecraft:light[level=14]
setblock 544 228 584 minecraft:light[level=14]
setblock 544 228 592 minecraft:light[level=14]
fill 547 228 599 547 236 599 minecraft:blue_concrete
fill 551 228 599 551 239 599 minecraft:blue_concrete
setblock 552 228 560 minecraft:light[level=14]
setblock 552 228 568 minecraft:light[level=14]
setblock 552 228 576 minecraft:light[level=14]
setblock 552 228 584 minecraft:light[level=14]
setblock 552 228 592 minecraft:light[level=14]
setblock 552 228 599 minecraft:white_concrete
fill 553 228 557 553 239 557 minecraft:blue_concrete
fill 553 228 599 553 235 599 minecraft:blue_concrete
fill 559 228 558 559 236 558 minecraft:blue_concrete
fill 559 228 562 559 235 562 minecraft:blue_concrete
fill 559 228 567 559 232 567 minecraft:blue_concrete
setblock 559 228 575 minecraft:sea_lantern
fill 559 228 583 559 239 583 minecraft:blue_concrete
setblock 517 229 565 minecraft:white_stained_glass
setblock 517 229 586 minecraft:white_concrete
fill 517 229 595 517 239 595 minecraft:blue_concrete
fill 539 229 599 539 231 599 minecraft:blue_concrete
fill 552 229 599 552 241 599 minecraft:blue_concrete
fill 559 229 575 559 236 575 minecraft:blue_concrete
fill 517 230 565 517 239 565 minecraft:blue_concrete
fill 517 230 586 517 235 586 minecraft:blue_concrete
setblock 527 230 599 minecraft:white_stained_glass
setblock 536 230 599 minecraft:white_stained_glass
setblock 559 230 576 minecraft:white_stained_glass
fill 527 231 599 527 239 599 minecraft:blue_concrete
fill 536 231 599 536 235 599 minecraft:blue_concrete
setblock 537 231 557 minecraft:sea_lantern
fill 559 231 576 559 239 576 minecraft:blue_concrete
setblock 517 232 583 minecraft:sea_lantern
setblock 536 232 557 minecraft:white_concrete
fill 537 232 557 537 234 557 minecraft:blue_concrete
setblock 539 232 599 minecraft:white_stained_glass
setblock 545 232 599 minecraft:sea_lantern
fill 517 233 583 517 239 583 minecraft:blue_concrete
fill 536 233 557 536 235 557 minecraft:blue_concrete
fill 539 233 599 539 240 599 minecraft:blue_concrete
fill 545 233 599 545 239 599 minecraft:blue_concrete
setblock 558 233 557 minecraft:white_concrete
setblock 559 233 567 minecraft:white_concrete
setblock 559 233 573 minecraft:white_concrete
fill 558 234 557 558 240 557 minecraft:blue_concrete
fill 559 234 567 559 236 567 minecraft:blue_concrete
fill 559 234 573 559 236 573 minecraft:blue_concrete
fill 517 235 598 517 236 598 minecraft:white_stained_glass
setblock 537 235 557 minecraft:sea_lantern
setblock 549 235 599 minecraft:sea_lantern
setblock 517 236 557 minecraft:black_concrete
setblock 517 236 568 minecraft:black_concrete
setblock 517 236 573 minecraft:black_concrete
setblock 517 236 586 minecraft:black_concrete
setblock 517 236 596 minecraft:white_concrete
setblock 519 236 599 minecraft:black_concrete
setblock 520 236 560 minecraft:light[level=14]
setblock 520 236 568 minecraft:light[level=14]
setblock 520 236 576 minecraft:light[level=14]
setblock 520 236 584 minecraft:light[level=14]
setblock 520 236 592 minecraft:light[level=14]
setblock 522 236 557 minecraft:black_concrete
fill 522 236 599 522 237 599 minecraft:black_concrete
setblock 528 236 560 minecraft:light[level=14]
setblock 528 236 568 minecraft:light[level=14]
setblock 528 236 576 minecraft:light[level=14]
setblock 528 236 584 minecraft:light[level=14]
setblock 528 236 592 minecraft:light[level=14]
fill 529 236 599 531 236 599 minecraft:black_concrete
fill 530 236 557 530 237 557 minecraft:black_concrete
fill 531 236 557 531 240 557 minecraft:blue_concrete
setblock 536 236 557 minecraft:white_stained_glass
setblock 536 236 560 minecraft:light[level=14]
setblock 536 236 568 minecraft:light[level=14]
setblock 536 236 576 minecraft:light[level=14]
setblock 536 236 584 minecraft:light[level=14]
setblock 536 236 592 minecraft:light[level=14]
fill 536 236 599 537 236 599 minecraft:black_concrete
fill 537 236 557 537 239 557 minecraft:blue_concrete
setblock 538 236 557 minecraft:black_concrete
setblock 544 236 560 minecraft:light[level=14]
setblock 544 236 568 minecraft:light[level=14]
setblock 544 236 576 minecraft:light[level=14]
setblock 544 236 584 minecraft:light[level=14]
setblock 544 236 592 minecraft:light[level=14]
setblock 545 236 557 minecraft:black_concrete
setblock 549 236 557 minecraft:black_concrete
fill 549 236 599 549 239 599 minecraft:blue_concrete
setblock 552 236 560 minecraft:light[level=14]
setblock 552 236 568 minecraft:light[level=14]
setblock 552 236 576 minecraft:light[level=14]
setblock 552 236 584 minecraft:light[level=14]
setblock 552 236 592 minecraft:light[level=14]
setblock 553 236 599 minecraft:black_concrete
setblock 555 236 557 minecraft:black_concrete
setblock 556 236 599 minecraft:black_concrete
setblock 559 236 562 minecraft:black_concrete
fill 559 236 570 559 237 570 minecraft:black_concrete
setblock 559 236 571 minecraft:white_concrete
setblock 559 236 574 minecraft:black_concrete
setblock 559 236 578 minecraft:black_concrete
setblock 559 236 580 minecraft:black_concrete
fill 559 236 589 559 239 589 minecraft:blue_concrete
setblock 559 236 590 minecraft:black_concrete
fill 559 236 592 559 239 593 minecraft:blue_concrete
fill 559 236 594 559 237 594 minecraft:black_concrete
fill 517 237 557 517 239 557 minecraft:blue_concrete
fill 517 237 560 517 239 560 minecraft:blue_concrete
setblock 517 237 561 minecraft:black_concrete
setblock 517 237 564 minecraft:black_concrete
fill 517 237 568 517 240 568 minecraft:blue_concrete
fill 517 237 573 517 240 573 minecraft:blue_concrete
fill 517 237 577 517 237 578 minecraft:black_concrete
fill 517 237 586 517 240 586 minecraft:blue_concrete
setblock 517 237 587 minecraft:black_concrete
setblock 517 237 596 minecraft:blue_concrete
fill 517 237 598 517 239 598 minecraft:blue_concrete
fill 519 237 599 519 239 599 minecraft:blue_concrete
fill 522 237 557 522 239 557 minecraft:blue_concrete
setblock 523 237 557 minecraft:black_concrete
fill 529 237 599 531 239 599 minecraft:blue_concrete
setblock 535 237 557 minecraft:black_concrete
fill 536 237 557 536 239 557 minecraft:blue_concrete
fill 536 237 599 537 239 599 minecraft:blue_concrete
fill 538 237 557 538 239 557 minecraft:blue_concrete
setblock 540 237 557 minecraft:black_concrete
setblock 541 237 557 minecraft:sea_lantern
fill 545 237 557 545 239 557 minecraft:blue_concrete
setblock 547 237 599 minecraft:black_concrete
fill 549 237 557 549 239 557 minecraft:blue_concrete
setblock 550 237 557 minecraft:black_concrete
setblock 553 237 599 minecraft:blue_concrete
setblock 555 237 557 minecraft:blue_concrete
fill 556 237 599 556 239 599 minecraft:blue_concrete
fill 558 237 599 558 239 599 minecraft:blue_concrete
fill 559 237 557 559 237 558 minecraft:black_concrete
fill 559 237 562 559 239 562 minecraft:blue_concrete
fill 559 237 566 559 237 567 minecraft:black_concrete
fill 559 237 571 559 239 571 minecraft:blue_concrete
setblock 559 237 573 minecraft:black_concrete
fill 559 237 574 559 240 574 minecraft:blue_concrete
setblock 559 237 575 minecraft:black_concrete
fill 559 237 577 559 238 577 minecraft:black_concrete
fill 559 237 578 559 239 578 minecraft:blue_concrete
setblock 559 237 580 minecraft:sea_lantern
fill 559 237 590 559 239 590 minecraft:blue_concrete
setblock 559 237 597 minecraft:black_concrete
setblock 559 237 598 minecraft:white_stained_glass
setblock 559 237 599 minecraft:black_concrete
fill 517 238 561 517 239 561 minecraft:blue_concrete
fill 517 238 564 517 239 564 minecraft:blue_concrete
setblock 517 238 577 minecraft:white_concrete
fill 517 238 578 517 239 578 minecraft:blue_concrete
fill 517 238 587 517 239 587 minecraft:blue_concrete
setblock 517 238 596 minecraft:black_concrete
setblock 520 238 557 minecraft:black_concrete
fill 522 238 599 522 239 599 minecraft:blue_concrete
fill 523 238 557 523 239 557 minecraft:blue_concrete
setblock 525 238 557 minecraft:black_concrete
setblock 525 238 599 minecraft:black_concrete
setblock 529 238 557 minecraft:black_concrete
fill 530 238 557 530 239 557 minecraft:blue_concrete
fill 532 238 574 534 238 576 minecraft:redstone_block
fill 535 238 557 535 239 557 minecraft:blue_concrete
fill 540 238 557 540 239 557 minecraft:blue_concrete
fill 540 238 570 542 238 572 minecraft:redstone_block
setblock 541 238 557 minecraft:black_concrete
fill 541 238 577 543 238 579 minecraft:redstone_block
fill 547 238 599 547 239 599 minecraft:blue_concrete
fill 550 238 557 550 239 557 minecraft:blue_concrete
setblock 553 238 599 minecraft:black_concrete
setblock 555 238 557 minecraft:black_concrete
setblock 555 238 599 minecraft:black_concrete
fill 559 238 557 559 239 558 minecraft:blue_concrete
setblock 559 238 561 minecraft:black_concrete
setblock 559 238 563 minecraft:black_concrete
fill 559 238 566 559 239 567 minecraft:blue_concrete
fill 559 238 570 559 239 570 minecraft:blue_concrete
fill 559 238 573 559 239 573 minecraft:blue_concrete
fill 559 238 575 559 239 575 minecraft:blue_concrete
fill 559 238 580 559 239 580 minecraft:blue_concrete
fill 559 238 587 559 238 588 minecraft:black_concrete
fill 559 238 594 559 239 594 minecraft:blue_concrete
fill 559 238 597 559 239 599 minecraft:blue_concrete
setblock 517 239 577 minecraft:blue_concrete
setblock 517 239 596 minecraft:blue_concrete
setblock 520 239 557 minecraft:blue_concrete
setblock 525 239 557 minecraft:blue_concrete
setblock 525 239 599 minecraft:blue_concrete
fill 526 239 566 532 239 569 minecraft:black_concrete
fill 526 239 581 532 239 584 minecraft:black_concrete
fill 527 239 570 539 239 571 minecraft:black_concrete
fill 527 239 579 540 239 580 minecraft:black_concrete
fill 528 239 572 539 239 572 minecraft:black_concrete
fill 528 239 578 540 239 578 minecraft:black_concrete
fill 529 239 557 529 240 557 minecraft:blue_concrete
fill 529 239 573 551 239 573 minecraft:black_concrete
fill 529 239 577 540 239 577 minecraft:black_concrete
fill 530 239 574 531 239 574 minecraft:black_concrete
fill 530 239 576 531 239 576 minecraft:black_concrete
setblock 531 239 575 minecraft:black_concrete
fill 533 239 567 534 239 569 minecraft:black_concrete
fill 533 239 581 534 239 583 minecraft:black_concrete
fill 535 239 568 544 239 569 minecraft:black_concrete
fill 535 239 574 536 239 576 minecraft:black_concrete
fill 535 239 581 544 239 582 minecraft:black_concrete
fill 537 239 565 544 239 567 minecraft:black_concrete
fill 537 239 583 544 239 585 minecraft:black_concrete
fill 538 239 564 544 240 564 minecraft:black_concrete
fill 538 239 586 544 240 586 minecraft:black_concrete
fill 539 239 563 544 240 563 minecraft:black_concrete
fill 539 239 587 544 240 587 minecraft:black_concrete
fill 540 239 562 544 240 562 minecraft:black_concrete
fill 540 239 574 553 239 576 minecraft:black_concrete
fill 540 239 588 544 240 588 minecraft:black_concrete
setblock 541 239 557 minecraft:blue_concrete
fill 541 239 561 543 240 561 minecraft:black_concrete
fill 541 239 580 544 239 580 minecraft:black_concrete
fill 541 239 589 543 240 589 minecraft:black_concrete
fill 543 239 560 543 240 560 minecraft:black_concrete
fill 543 239 570 544 239 572 minecraft:black_concrete
fill 543 239 590 543 240 590 minecraft:black_concrete
fill 544 239 577 547 239 579 minecraft:black_concrete
fill 545 239 571 547 240 572 minecraft:black_concrete
fill 548 239 572 550 240 572 minecraft:black_concrete
fill 548 239 577 550 240 578 minecraft:black_concrete
fill 551 239 577 551 240 577 minecraft:black_concrete
setblock 553 239 599 minecraft:blue_concrete
fill 554 239 575 554 240 575 minecraft:black_concrete
setblock 555 239 557 minecraft:blue_concrete
setblock 555 239 599 minecraft:blue_concrete
setblock 559 239 561 minecraft:blue_concrete
setblock 559 239 563 minecraft:blue_concrete
setblock 559 239 577 minecraft:blue_concrete
fill 559 239 587 559 239 588 minecraft:blue_concrete
fill 517 240 557 517 240 567 minecraft:black_concrete
fill 517 240 569 517 241 572 minecraft:black_concrete
fill 517 240 575 517 240 585 minecraft:black_concrete
fill 517 240 587 517 244 589 minecraft:black_concrete
fill 517 240 591 517 243 598 minecraft:black_concrete
fill 518 240 557 528 241 557 minecraft:black_concrete
fill 518 240 558 525 240 598 minecraft:obsidian
fill 518 240 599 520 274 599 minecraft:black_concrete
fill 522 240 599 522 307 599 minecraft:black_concrete
fill 524 240 599 532 240 599 minecraft:black_concrete
fill 526 240 558 536 240 565 minecraft:obsidian
fill 526 240 566 529 240 569 minecraft:black_concrete
fill 526 240 570 526 240 580 minecraft:obsidian
fill 526 240 581 529 240 584 minecraft:black_concrete
fill 526 240 585 536 240 598 minecraft:obsidian
fill 527 240 570 529 240 571 minecraft:black_concrete
fill 527 240 572 527 240 578 minecraft:obsidian
fill 527 240 579 529 240 580 minecraft:black_concrete
fill 528 240 572 529 240 572 minecraft:black_concrete
fill 528 240 573 528 240 577 minecraft:obsidian
fill 528 240 578 529 240 578 minecraft:black_concrete
fill 529 240 573 530 240 573 minecraft:black_concrete
fill 529 240 574 529 240 576 minecraft:obsidian
fill 529 240 577 530 240 577 minecraft:black_concrete
fill 530 240 557 530 306 557 minecraft:black_concrete
fill 530 240 566 532 240 568 minecraft:black_concrete
fill 530 240 569 534 240 572 minecraft:white_stained_glass
setblock 530 240 574 minecraft:black_concrete
setblock 530 240 575 minecraft:obsidian
setblock 530 240 576 minecraft:black_concrete
fill 530 240 578 534 240 581 minecraft:white_stained_glass
fill 530 240 582 532 240 584 minecraft:black_concrete
fill 531 240 573 531 240 577 minecraft:sea_lantern
fill 532 240 557 546 241 557 minecraft:black_concrete
fill 532 240 573 543 240 573 minecraft:sea_lantern
fill 532 240 574 534 240 576 minecraft:obsidian
fill 532 240 577 540 240 577 minecraft:sea_lantern
fill 533 240 566 536 240 566 minecraft:obsidian
fill 533 240 567 534 240 568 minecraft:black_concrete
fill 533 240 582 534 240 583 minecraft:black_concrete
fill 533 240 584 536 240 584 minecraft:obsidian
setblock 533 240 599 minecraft:sea_lantern
fill 534 240 599 538 240 599 minecraft:black_concrete
fill 535 240 567 536 240 567 minecraft:obsidian
fill 535 240 568 536 240 569 minecraft:black_concrete
fill 535 240 570 535 240 572 minecraft:white_stained_glass
fill 535 240 574 536 240 576 minecraft:sea_lantern
fill 535 240 578 535 240 580 minecraft:white_stained_glass
fill 535 240 581 536 240 582 minecraft:black_concrete
fill 535 240 583 536 240 583 minecraft:obsidian
fill 536 240 570 537 240 571 minecraft:white_stained_glass
fill 536 240 572 539 240 572 minecraft:sea_lantern
fill 536 240 578 540 240 578 minecraft:sea_lantern
fill 536 240 579 537 240 580 minecraft:white_stained_glass
fill 537 240 558 537 240 564 minecraft:obsidian
fill 537 240 565 537 240 568 minecraft:black_concrete
fill 537 240 569 538 240 569 minecraft:white_stained_glass
fill 537 240 581 542 240 581 minecraft:white_stained_glass
fill 537 240 582 537 240 585 minecraft:black_concrete
fill 537 240 586 537 240 598 minecraft:obsidian
fill 538 240 558 538 240 563 minecraft:obsidian
fill 538 240 565 538 240 566 minecraft:black_concrete
fill 538 240 567 542 240 568 minecraft:white_stained_glass
setblock 538 240 570 minecraft:white_stained_glass
fill 538 240 571 539 240 571 minecraft:sea_lantern
setblock 538 240 579 minecraft:sea_lantern
fill 538 240 580 539 240 580 minecraft:white_stained_glass
fill 538 240 582 542 240 583 minecraft:white_stained_glass
fill 538 240 584 538 240 585 minecraft:black_concrete
fill 538 240 587 538 240 598 minecraft:obsidian
fill 539 240 558 539 240 562 minecraft:obsidian
fill 539 240 565 540 240 565 minecraft:black_concrete
fill 539 240 566 542 240 566 minecraft:white_stained_glass
fill 539 240 569 539 240 570 minecraft:sea_lantern
setblock 539 240 579 minecraft:white_stained_glass
fill 539 240 584 542 240 584 minecraft:white_stained_glass
fill 539 240 585 540 240 585 minecraft:black_concrete
fill 539 240 588 539 240 598 minecraft:obsidian
fill 540 240 558 540 240 561 minecraft:obsidian
fill 540 240 569 543 240 569 minecraft:sea_lantern
fill 540 240 570 542 240 572 minecraft:obsidian
fill 540 240 574 541 240 576 minecraft:sea_lantern
fill 540 240 579 540 240 580 minecraft:sea_lantern
fill 540 240 589 540 240 598 minecraft:obsidian
fill 541 240 558 542 240 560 minecraft:obsidian
setblock 541 240 565 minecraft:white_stained_glass
fill 541 240 577 543 240 579 minecraft:obsidian
fill 541 240 580 544 240 580 minecraft:sea_lantern
setblock 541 240 585 minecraft:white_stained_glass
fill 541 240 590 542 240 598 minecraft:obsidian
fill 542 240 565 544 240 565 minecraft:black_concrete
fill 542 240 574 548 240 574 minecraft:white_stained_glass
fill 542 240 575 542 240 576 minecraft:sea_lantern
fill 542 240 585 544 240 585 minecraft:black_concrete
fill 542 240 599 545 245 599 minecraft:black_concrete
fill 543 240 558 558 240 559 minecraft:obsidian
fill 543 240 566 544 240 568 minecraft:black_concrete
fill 543 240 570 543 240 572 minecraft:sea_lantern
fill 543 240 575 549 240 575 minecraft:white_stained_glass
fill 543 240 576 544 240 576 minecraft:sea_lantern
fill 543 240 581 544 240 584 minecraft:black_concrete
fill 543 240 591 558 240 598 minecraft:obsidian
fill 544 240 560 558 240 561 minecraft:obsidian
fill 544 240 569 544 240 572 minecraft:black_concrete
fill 544 240 573 546 240 573 minecraft:white_stained_glass
fill 544 240 577 544 240 579 minecraft:sea_lantern
fill 544 240 589 558 240 590 minecraft:obsidian
fill 545 240 562 558 240 570 minecraft:obsidian
fill 545 240 576 546 240 577 minecraft:white_stained_glass
fill 545 240 578 547 240 579 minecraft:black_concrete
fill 545 240 580 558 240 588 minecraft:obsidian
setblock 547 240 557 minecraft:white_stained_glass
fill 547 240 573 551 240 573 minecraft:black_concrete
fill 547 240 576 548 240 576 minecraft:white_stained_glass
setblock 547 240 577 minecraft:black_concrete
fill 547 240 599 551 241 599 minecraft:black_concrete
fill 548 240 557 557 240 557 minecraft:black_concrete
fill 548 240 571 558 240 571 minecraft:obsidian
fill 548 240 579 558 240 579 minecraft:obsidian
fill 549 240 574 553 240 574 minecraft:black_concrete
fill 549 240 576 553 240 576 minecraft:black_concrete
fill 550 240 575 553 240 575 minecraft:black_concrete
fill 551 240 572 558 240 572 minecraft:obsidian
fill 551 240 578 558 240 578 minecraft:obsidian
fill 552 240 573 558 240 573 minecraft:obsidian
fill 552 240 577 558 240 577 minecraft:obsidian
fill 553 240 599 559 240 599 minecraft:black_concrete
fill 554 240 574 558 240 574 minecraft:obsidian
fill 554 240 576 558 240 576 minecraft:obsidian
fill 555 240 575 558 240 575 minecraft:obsidian
fill 559 240 557 559 240 573 minecraft:black_concrete
fill 559 240 575 559 240 580 minecraft:black_concrete
fill 559 240 582 559 240 585 minecraft:black_concrete
fill 559 240 587 559 245 591 minecraft:black_concrete
setblock 559 240 592 minecraft:blue_concrete
fill 559 240 593 559 240 597 minecraft:black_concrete
setblock 559 240 598 minecraft:blue_concrete
fill 517 241 557 517 261 560 minecraft:black_concrete
setblock 517 241 561 minecraft:blue_concrete
fill 517 241 562 517 243 568 minecraft:black_concrete
fill 517 241 573 517 241 584 minecraft:black_concrete
setblock 517 241 585 minecraft:blue_concrete
fill 517 241 586 517 259 586 minecraft:black_concrete
fill 517 241 590 517 267 590 minecraft:black_concrete
fill 517 241 599 517 307 599 minecraft:black_concrete
fill 521 241 599 521 273 599 minecraft:black_concrete
fill 523 241 599 527 247 599 minecraft:black_concrete
setblock 528 241 599 minecraft:blue_concrete
fill 529 241 557 529 307 557 minecraft:black_concrete
fill 529 241 599 537 241 599 minecraft:black_concrete
fill 531 241 557 531 287 557 minecraft:black_concrete
setblock 538 241 599 minecraft:blue_concrete
fill 539 241 599 541 274 599 minecraft:black_concrete
fill 546 241 599 546 307 599 minecraft:black_concrete
fill 547 241 557 551 253 557 minecraft:black_concrete
setblock 552 241 557 minecraft:blue_concrete
fill 553 241 557 559 241 557 minecraft:black_concrete
setblock 553 241 599 minecraft:blue_concrete
fill 554 241 599 559 252 599 minecraft:black_concrete
fill 559 241 558 559 247 562 minecraft:black_concrete
setblock 559 241 563 minecraft:blue_concrete
fill 559 241 564 559 243 567 minecraft:black_concrete
setblock 559 241 568 minecraft:blue_concrete
fill 559 241 569 559 244 572 minecraft:black_concrete
setblock 559 241 573 minecraft:blue_concrete
fill 559 241 574 559 242 576 minecraft:black_concrete
setblock 559 241 577 minecraft:blue_concrete
fill 559 241 578 559 241 582 minecraft:black_concrete
setblock 559 241 583 minecraft:blue_concrete
fill 559 241 584 559 287 584 minecraft:black_concrete
setblock 559 241 585 minecraft:sea_lantern
setblock 559 241 586 minecraft:white_concrete
fill 559 241 592 559 258 593 minecraft:black_concrete
setblock 559 241 594 minecraft:blue_concrete
fill 559 241 595 559 245 595 minecraft:black_concrete
fill 559 241 596 559 242 596 minecraft:blue_concrete
fill 559 241 597 559 241 598 minecraft:black_concrete
fill 517 242 561 517 307 561 minecraft:black_concrete
fill 517 242 569 517 245 569 minecraft:black_concrete
setblock 517 242 570 minecraft:blue_concrete
fill 517 242 571 517 243 582 minecraft:black_concrete
fill 517 242 583 517 242 584 minecraft:blue_concrete
fill 517 242 585 517 285 585 minecraft:black_concrete
setblock 518 242 557 minecraft:white_concrete
fill 519 242 557 522 243 557 minecraft:black_concrete
fill 523 242 557 524 242 557 minecraft:blue_concrete
fill 525 242 557 528 253 557 minecraft:black_concrete
fill 528 242 599 530 244 599 minecraft:black_concrete
setblock 531 242 599 minecraft:blue_concrete
fill 532 242 557 541 243 557 minecraft:black_concrete
fill 532 242 599 538 244 599 minecraft:black_concrete
setblock 542 242 557 minecraft:blue_concrete
fill 543 242 557 543 244 557 minecraft:black_concrete
fill 544 242 557 545 242 557 minecraft:blue_concrete
fill 546 242 557 546 283 557 minecraft:black_concrete
setblock 547 242 599 minecraft:blue_concrete
fill 548 242 599 553 250 599 minecraft:black_concrete
fill 552 242 557 556 243 557 minecraft:black_concrete
setblock 557 242 557 minecraft:white_concrete
fill 558 242 557 558 250 557 minecraft:black_concrete
setblock 559 242 557 minecraft:blue_concrete
fill 559 242 563 559 290 563 minecraft:black_concrete
fill 559 242 568 559 254 568 minecraft:black_concrete
fill 559 242 573 559 307 573 minecraft:black_concrete
fill 559 242 577 559 251 578 minecraft:black_concrete
setblock 559 242 579 minecraft:blue_concrete
fill 559 242 580 559 243 583 minecraft:black_concrete
fill 559 242 585 559 251 586 minecraft:black_concrete
fill 559 242 594 559 307 594 minecraft:black_concrete
setblock 559 242 597 minecraft:blue_concrete
fill 559 242 598 559 254 598 minecraft:black_concrete
fill 517 243 570 517 245 570 minecraft:black_concrete
fill 517 243 583 517 252 584 minecraft:black_concrete
fill 518 243 557 518 295 557 minecraft:black_concrete
fill 523 243 557 524 263 557 minecraft:black_concrete
setblock 531 243 599 minecraft:black_concrete
fill 542 243 557 542 307 557 minecraft:black_concrete
fill 544 243 557 545 243 557 minecraft:black_concrete
setblock 547 243 599 minecraft:black_concrete
fill 557 243 557 557 300 557 minecraft:black_concrete
fill 559 243 557 559 307 557 minecraft:black_concrete
fill 559 243 574 559 289 575 minecraft:black_concrete
setblock 559 243 576 minecraft:sea_lantern
fill 559 243 579 559 266 579 minecraft:black_concrete
fill 559 243 596 559 254 597 minecraft:black_concrete
fill 517 244 562 517 289 564 minecraft:black_concrete
fill 517 244 565 517 245 565 minecraft:white_concrete
fill 517 244 566 517 262 568 minecraft:black_concrete
fill 517 244 571 517 245 580 minecraft:black_concrete
fill 517 244 581 517 245 581 minecraft:white_concrete
fill 517 244 582 517 264 582 minecraft:black_concrete
fill 517 244 591 517 247 596 minecraft:black_concrete
fill 517 244 597 517 245 597 minecraft:white_concrete
fill 517 244 598 517 307 598 minecraft:black_concrete
fill 519 244 557 520 275 557 minecraft:black_concrete
setblock 520 244 560 minecraft:light[level=14]
setblock 520 244 568 minecraft:light[level=14]
setblock 520 244 576 minecraft:light[level=14]
setblock 520 244 584 minecraft:light[level=14]
setblock 520 244 592 minecraft:light[level=14]
fill 521 244 557 522 244 557 minecraft:white_concrete
fill 525 244 575 525 244 576 minecraft:obsidian
setblock 528 244 560 minecraft:light[level=14]
setblock 528 244 568 minecraft:light[level=14]
setblock 528 244 576 minecraft:light[level=14]
setblock 528 244 584 minecraft:light[level=14]
setblock 528 244 592 minecraft:light[level=14]
fill 531 244 599 531 245 599 minecraft:white_concrete
fill 532 244 557 536 256 557 minecraft:black_concrete
setblock 536 244 560 minecraft:light[level=14]
setblock 536 244 568 minecraft:light[level=14]
setblock 536 244 576 minecraft:light[level=14]
setblock 536 244 584 minecraft:light[level=14]
setblock 536 244 592 minecraft:light[level=14]
fill 537 244 557 537 245 557 minecraft:white_concrete
fill 538 244 557 541 244 557 minecraft:black_concrete
setblock 544 244 557 minecraft:sea_lantern
setblock 544 244 560 minecraft:light[level=14]
setblock 544 244 568 minecraft:light[level=14]
setblock 544 244 576 minecraft:light[level=14]
setblock 544 244 584 minecraft:light[level=14]
setblock 544 244 592 minecraft:light[level=14]
fill 545 244 557 545 283 557 minecraft:black_concrete
fill 546 244 582 547 244 583 minecraft:blue_concrete
fill 547 244 565 549 250 566 minecraft:black_concrete
fill 547 244 599 547 245 599 minecraft:white_concrete
fill 548 244 564 549 250 564 minecraft:black_concrete
fill 552 244 557 552 267 557 minecraft:black_concrete
setblock 552 244 560 minecraft:light[level=14]
setblock 552 244 568 minecraft:light[level=14]
setblock 552 244 576 minecraft:light[level=14]
setblock 552 244 584 minecraft:light[level=14]
setblock 552 244 592 minecraft:light[level=14]
fill 553 244 557 553 245 557 minecraft:white_concrete
fill 554 244 557 556 283 557 minecraft:black_concrete
fill 559 244 564 559 263 566 minecraft:black_concrete
fill 559 244 567 559 245 567 minecraft:white_concrete
fill 559 244 576 559 248 576 minecraft:black_concrete
fill 559 244 580 559 251 582 minecraft:black_concrete
fill 559 244 583 559 245 583 minecraft:white_concrete
fill 517 245 587 517 254 587 minecraft:black_concrete
setblock 517 245 588 minecraft:white_stained_glass
fill 517 245 589 517 307 589 minecraft:black_concrete
setblock 521 245 557 minecraft:white_concrete
fill 522 245 557 522 249 557 minecraft:black_concrete
fill 528 245 599 529 252 599 minecraft:black_concrete
setblock 530 245 599 minecraft:white_stained_glass
fill 532 245 599 534 284 599 minecraft:black_concrete
setblock 535 245 599 minecraft:sea_lantern
fill 536 245 599 538 245 599 minecraft:black_concrete
fill 538 245 557 539 290 557 minecraft:black_concrete
setblock 540 245 557 minecraft:white_concrete
fill 541 245 557 541 283 557 minecraft:black_concrete
setblock 543 245 557 minecraft:sea_lantern
fill 544 245 557 544 260 557 minecraft:black_concrete
fill 547 245 564 547 250 564 minecraft:black_concrete
fill 548 245 567 548 250 567 minecraft:black_concrete
fill 550 245 565 550 250 565 minecraft:black_concrete
fill 559 245 569 559 283 570 minecraft:black_concrete
setblock 559 245 571 minecraft:white_concrete
fill 559 245 572 559 307 572 minecraft:black_concrete
setblock 517 246 565 minecraft:white_stained_glass
setblock 517 246 569 minecraft:white_concrete
setblock 517 246 570 minecraft:sea_lantern
fill 517 246 571 517 246 575 minecraft:black_concrete
setblock 517 246 576 minecraft:white_stained_glass
fill 517 246 577 517 251 581 minecraft:black_concrete
fill 517 246 588 517 307 588 minecraft:black_concrete
fill 517 246 597 517 251 597 minecraft:black_concrete
fill 521 246 557 521 251 557 minecraft:black_concrete
fill 530 246 599 531 249 599 minecraft:black_concrete
fill 535 246 599 536 260 599 minecraft:black_concrete
fill 537 246 557 537 251 557 minecraft:black_concrete
setblock 537 246 599 minecraft:sea_lantern
fill 538 246 599 538 294 599 minecraft:black_concrete
fill 540 246 557 540 263 557 minecraft:black_concrete
fill 542 246 599 544 303 599 minecraft:black_concrete
fill 543 246 557 543 276 557 minecraft:black_concrete
setblock 545 246 599 minecraft:sea_lantern
fill 546 246 564 546 250 566 minecraft:black_concrete
fill 547 246 563 549 250 563 minecraft:black_concrete
fill 547 246 567 547 250 567 minecraft:black_concrete
fill 547 246 599 547 251 599 minecraft:black_concrete
fill 549 246 567 549 250 567 minecraft:black_concrete
fill 550 246 564 550 250 564 minecraft:black_concrete
fill 550 246 566 550 250 566 minecraft:black_concrete
fill 553 246 557 553 251 557 minecraft:black_concrete
fill 559 246 567 559 251 567 minecraft:black_concrete
fill 559 246 571 559 307 571 minecraft:black_concrete
fill 559 246 583 559 251 583 minecraft:black_concrete
fill 559 246 587 559 259 587 minecraft:black_concrete
setblock 559 246 588 minecraft:white_concrete
fill 559 246 589 559 250 591 minecraft:black_concrete
setblock 559 246 595 minecraft:sea_lantern
fill 517 247 565 517 251 565 minecraft:black_concrete
fill 517 247 569 517 274 572 minecraft:black_concrete
setblock 517 247 573 minecraft:white_concrete
fill 517 247 574 517 282 576 minecraft:black_concrete
fill 537 247 599 537 277 599 minecraft:black_concrete
fill 545 247 599 545 276 599 minecraft:black_concrete
fill 546 247 567 546 250 567 minecraft:black_concrete
fill 548 247 568 549 250 568 minecraft:black_concrete
fill 550 247 563 550 250 563 minecraft:black_concrete
fill 550 247 567 550 250 567 minecraft:black_concrete
fill 551 247 565 551 250 565 minecraft:black_concrete
fill 559 247 588 559 265 588 minecraft:black_concrete
fill 559 247 595 559 265 595 minecraft:black_concrete
fill 517 248 573 517 279 573 minecraft:black_concrete
fill 517 248 591 517 268 592 minecraft:black_concrete
setblock 517 248 593 minecraft:white_stained_glass
fill 517 248 594 517 267 596 minecraft:black_concrete
setblock 523 248 599 minecraft:sea_lantern
fill 524 248 599 527 264 599 minecraft:black_concrete
fill 545 248 564 545 250 566 minecraft:black_concrete
fill 546 248 563 546 250 563 minecraft:black_concrete
fill 547 248 562 549 250 562 minecraft:black_concrete
fill 547 248 568 547 250 568 minecraft:black_concrete
fill 550 248 568 550 250 568 minecraft:black_concrete
fill 551 248 564 551 250 564 minecraft:black_concrete
fill 551 248 566 551 250 567 minecraft:black_concrete
fill 553 248 571 553 249 571 minecraft:white_stained_glass
fill 559 248 558 559 249 560 minecraft:black_concrete
setblock 559 248 561 minecraft:sea_lantern
fill 559 248 562 559 257 562 minecraft:black_concrete
fill 517 249 593 517 265 593 minecraft:black_concrete
fill 523 249 599 523 307 599 minecraft:black_concrete
fill 536 249 570 536 250 570 minecraft:white_concrete
fill 545 249 563 545 250 563 minecraft:black_concrete
fill 545 249 567 545 250 567 minecraft:black_concrete
fill 546 249 562 546 250 562 minecraft:black_concrete
fill 546 249 568 546 250 568 minecraft:black_concrete
fill 548 249 569 549 250 569 minecraft:black_concrete
fill 550 249 562 550 250 562 minecraft:black_concrete
fill 551 249 563 551 250 563 minecraft:black_concrete
fill 552 249 565 552 250 565 minecraft:black_concrete
fill 559 249 561 559 307 561 minecraft:black_concrete
setblock 559 249 576 minecraft:white_stained_glass
setblock 522 250 557 minecraft:white_concrete
setblock 530 250 599 minecraft:white_stained_glass
fill 531 250 599 531 251 599 minecraft:black_concrete
fill 544 250 564 544 250 566 minecraft:black_concrete
setblock 545 250 562 minecraft:black_concrete
setblock 545 250 568 minecraft:black_concrete
fill 546 250 569 547 250 569 minecraft:black_concrete
fill 547 250 561 549 250 561 minecraft:black_concrete
setblock 550 250 569 minecraft:black_concrete
setblock 551 250 562 minecraft:black_concrete
setblock 551 250 568 minecraft:black_concrete
setblock 552 250 564 minecraft:black_concrete
fill 552 250 566 552 250 567 minecraft:black_concrete
fill 553 250 571 553 258 571 minecraft:black_concrete
fill 559 250 558 559 272 558 minecraft:black_concrete
setblock 559 250 559 minecraft:white_concrete
fill 559 250 560 559 307 560 minecraft:black_concrete
fill 559 250 576 559 307 576 minecraft:black_concrete
setblock 522 251 557 minecraft:sea_lantern
setblock 530 251 599 minecraft:black_concrete
fill 546 251 565 546 255 565 minecraft:obsidian
fill 548 251 599 549 274 599 minecraft:black_concrete
fill 549 251 564 549 255 564 minecraft:obsidian
fill 549 251 567 549 255 567 minecraft:obsidian
setblock 550 251 599 minecraft:white_stained_glass
fill 551 251 599 553 291 599 minecraft:black_concrete
fill 554 251 571 554 258 571 minecraft:black_concrete
setblock 558 251 557 minecraft:sea_lantern
fill 559 251 559 559 285 559 minecraft:black_concrete
setblock 559 251 589 minecraft:white_concrete
fill 559 251 590 559 253 591 minecraft:black_concrete
fill 517 252 565 517 254 565 minecraft:white_concrete
fill 517 252 577 517 256 580 minecraft:black_concrete
fill 517 252 581 517 254 581 minecraft:white_concrete
fill 517 252 597 517 254 597 minecraft:white_concrete
setblock 520 252 560 minecraft:light[level=14]
setblock 520 252 568 minecraft:light[level=14]
setblock 520 252 576 minecraft:light[level=14]
setblock 520 252 584 minecraft:light[level=14]
setblock 520 252 592 minecraft:light[level=14]
fill 521 252 557 521 254 557 minecraft:white_concrete
fill 522 252 557 522 282 557 minecraft:black_concrete
setblock 528 252 560 minecraft:light[level=14]
setblock 528 252 568 minecraft:light[level=14]
setblock 528 252 576 minecraft:light[level=14]
setblock 528 252 584 minecraft:light[level=14]
setblock 528 252 592 minecraft:light[level=14]
fill 530 252 599 531 252 599 minecraft:white_concrete
setblock 536 252 560 minecraft:light[level=14]
setblock 536 252 568 minecraft:light[level=14]
setblock 536 252 584 minecraft:light[level=14]
setblock 536 252 592 minecraft:light[level=14]
fill 537 252 557 537 254 557 minecraft:white_concrete
setblock 544 252 560 minecraft:light[level=14]
setblock 544 252 568 minecraft:light[level=14]
setblock 544 252 576 minecraft:light[level=14]
setblock 544 252 584 minecraft:light[level=14]
setblock 544 252 592 minecraft:light[level=14]
fill 547 252 599 547 254 599 minecraft:white_concrete
fill 550 252 599 550 307 599 minecraft:black_concrete
setblock 552 252 560 minecraft:light[level=14]
setblock 552 252 568 minecraft:light[level=14]
setblock 552 252 576 minecraft:light[level=14]
setblock 552 252 584 minecraft:light[level=14]
setblock 552 252 592 minecraft:light[level=14]
fill 553 252 557 553 254 557 minecraft:white_concrete
fill 553 252 572 554 258 572 minecraft:black_concrete
fill 558 252 557 558 307 557 minecraft:black_concrete
fill 559 252 567 559 254 567 minecraft:white_concrete
fill 559 252 577 559 307 577 minecraft:black_concrete
setblock 559 252 578 minecraft:sea_lantern
fill 559 252 580 559 307 580 minecraft:black_concrete
setblock 559 252 581 minecraft:sea_lantern
fill 559 252 582 559 307 582 minecraft:black_concrete
fill 559 252 583 559 254 583 minecraft:white_concrete
fill 559 252 585 559 263 585 minecraft:black_concrete
setblock 559 252 586 minecraft:white_stained_glass
fill 559 252 589 559 307 589 minecraft:black_concrete
setblock 517 253 583 minecraft:sea_lantern
fill 517 253 584 517 307 584 minecraft:black_concrete
setblock 528 253 599 minecraft:white_stained_glass
fill 529 253 599 530 307 599 minecraft:black_concrete
fill 531 253 599 531 254 599 minecraft:white_concrete
fill 552 253 571 552 258 572 minecraft:black_concrete
fill 553 253 570 554 258 570 minecraft:black_concrete
fill 554 253 599 554 307 599 minecraft:black_concrete
fill 555 253 571 555 258 571 minecraft:black_concrete
setblock 555 253 599 minecraft:white_stained_glass
fill 556 253 599 559 260 599 minecraft:black_concrete
fill 559 253 578 559 284 578 minecraft:black_concrete
fill 559 253 581 559 290 581 minecraft:black_concrete
fill 559 253 586 559 307 586 minecraft:black_concrete
fill 517 254 583 517 281 583 minecraft:black_concrete
setblock 525 254 557 minecraft:sea_lantern
fill 526 254 557 528 276 557 minecraft:black_concrete
fill 528 254 599 528 307 599 minecraft:black_concrete
fill 547 254 557 549 286 557 minecraft:black_concrete
setblock 550 254 557 minecraft:white_concrete
fill 551 254 557 551 307 557 minecraft:black_concrete
fill 552 254 570 552 258 570 minecraft:black_concrete
fill 553 254 573 554 258 573 minecraft:black_concrete
fill 555 254 570 555 258 570 minecraft:black_concrete
fill 555 254 572 555 258 572 minecraft:black_concrete
fill 555 254 599 555 307 599 minecraft:black_concrete
fill 559 254 590 559 307 590 minecraft:black_concrete
setblock 559 254 591 minecraft:sea_lantern
fill 517 255 565 517 260 565 minecraft:black_concrete
fill 517 255 581 517 260 581 minecraft:black_concrete
setblock 517 255 587 minecraft:white_concrete
fill 517 255 597 517 260 597 minecraft:black_concrete
fill 521 255 557 521 260 557 minecraft:black_concrete
fill 524 255 581 524 256 582 minecraft:obsidian
fill 525 255 557 525 264 557 minecraft:black_concrete
fill 531 255 599 531 260 599 minecraft:black_concrete
fill 537 255 557 537 260 557 minecraft:black_concrete
fill 547 255 599 547 260 599 minecraft:black_concrete
fill 550 255 557 550 291 557 minecraft:black_concrete
fill 551 255 571 551 258 572 minecraft:black_concrete
fill 552 255 573 552 258 573 minecraft:black_concrete
fill 553 255 557 553 260 557 minecraft:black_concrete
fill 553 255 569 554 258 569 minecraft:black_concrete
fill 555 255 573 555 258 573 minecraft:black_concrete
fill 559 255 567 559 260 567 minecraft:black_concrete
setblock 559 255 568 minecraft:white_stained_glass
fill 559 255 583 559 260 583 minecraft:black_concrete
fill 559 255 591 559 269 591 minecraft:black_concrete
fill 559 255 596 559 272 596 minecraft:black_concrete
setblock 559 255 597 minecraft:white_stained_glass
setblock 559 255 598 minecraft:white_concrete
fill 517 256 587 517 267 587 minecraft:black_concrete
fill 551 256 570 551 258 570 minecraft:black_concrete
fill 551 256 573 551 258 573 minecraft:black_concrete
fill 552 256 569 552 258 569 minecraft:black_concrete
fill 552 256 574 554 258 574 minecraft:black_concrete
fill 555 256 569 555 258 569 minecraft:black_concrete
fill 556 256 570 556 258 572 minecraft:black_concrete
fill 559 256 568 559 307 568 minecraft:black_concrete
fill 559 256 597 559 267 598 minecraft:black_concrete
setblock 517 257 577 minecraft:white_stained_glass
fill 517 257 578 517 258 580 minecraft:black_concrete
fill 532 257 557 535 276 557 minecraft:black_concrete
setblock 536 257 557 minecraft:sea_lantern
fill 536 257 596 537 258 597 minecraft:blue_concrete
fill 550 257 571 550 258 571 minecraft:black_concrete
fill 551 257 569 551 258 569 minecraft:black_concrete
fill 553 257 568 554 258 568 minecraft:black_concrete
fill 555 257 574 555 258 574 minecraft:black_concrete
fill 556 257 569 556 258 569 minecraft:black_concrete
fill 556 257 573 556 258 573 minecraft:black_concrete
fill 517 258 577 517 307 577 minecraft:black_concrete
fill 536 258 557 536 268 557 minecraft:black_concrete
setblock 550 258 570 minecraft:black_concrete
fill 550 258 572 550 258 573 minecraft:black_concrete
setblock 551 258 574 minecraft:black_concrete
setblock 552 258 568 minecraft:black_concrete
fill 552 258 575 554 258 575 minecraft:black_concrete
setblock 555 258 568 minecraft:black_concrete
setblock 556 258 574 minecraft:black_concrete
fill 557 258 570 557 258 573 minecraft:black_concrete
setblock 559 258 562 minecraft:white_stained_glass
fill 517 259 578 517 307 578 minecraft:black_concrete
setblock 517 259 579 minecraft:white_stained_glass
fill 517 259 580 517 286 580 minecraft:black_concrete
fill 531 259 584 532 260 585 minecraft:blue_concrete
fill 552 259 570 552 262 570 minecraft:obsidian
fill 553 259 573 553 261 573 minecraft:obsidian
fill 555 259 571 555 262 571 minecraft:obsidian
fill 559 259 562 559 274 562 minecraft:black_concrete
setblock 559 259 592 minecraft:white_concrete
fill 559 259 593 559 262 593 minecraft:black_concrete
fill 517 260 579 517 272 579 minecraft:black_concrete
setblock 517 260 586 minecraft:white_stained_glass
setblock 520 260 560 minecraft:light[level=14]
setblock 520 260 568 minecraft:light[level=14]
setblock 520 260 576 minecraft:light[level=14]
setblock 520 260 584 minecraft:light[level=14]
setblock 520 260 592 minecraft:light[level=14]
setblock 528 260 560 minecraft:light[level=14]
setblock 528 260 568 minecraft:light[level=14]
setblock 528 260 576 minecraft:light[level=14]
setblock 528 260 584 minecraft:light[level=14]
setblock 528 260 592 minecraft:light[level=14]
setblock 536 260 560 minecraft:light[level=14]
setblock 536 260 568 minecraft:light[level=14]
setblock 536 260 584 minecraft:light[level=14]
setblock 536 260 592 minecraft:light[level=14]
setblock 544 260 560 minecraft:light[level=14]
setblock 544 260 568 minecraft:light[level=14]
setblock 544 260 576 minecraft:light[level=14]
setblock 544 260 584 minecraft:light[level=14]
setblock 544 260 592 minecraft:light[level=14]
setblock 552 260 560 minecraft:light[level=14]
setblock 552 260 568 minecraft:light[level=14]
setblock 552 260 576 minecraft:light[level=14]
setblock 552 260 584 minecraft:light[level=14]
setblock 552 260 592 minecraft:light[level=14]
setblock 559 260 587 minecraft:white_concrete
fill 559 260 592 559 295 592 minecraft:black_concrete
fill 517 261 565 517 263 565 minecraft:white_concrete
fill 517 261 581 517 263 581 minecraft:white_concrete
fill 517 261 586 517 307 586 minecraft:black_concrete
fill 517 261 597 517 263 597 minecraft:white_concrete
fill 521 261 557 521 263 557 minecraft:white_concrete
fill 531 261 599 531 263 599 minecraft:white_concrete
fill 535 261 599 535 287 599 minecraft:black_concrete
setblock 536 261 599 minecraft:white_concrete
fill 537 261 557 537 263 557 minecraft:white_concrete
fill 539 261 568 539 262 569 minecraft:blue_concrete
setblock 544 261 557 minecraft:white_stained_glass
fill 547 261 599 547 263 599 minecraft:white_concrete
fill 553 261 557 553 263 557 minecraft:white_concrete
fill 556 261 599 556 270 599 minecraft:black_concrete
setblock 557 261 599 minecraft:sea_lantern
fill 558 261 599 559 307 599 minecraft:black_concrete
fill 559 261 567 559 263 567 minecraft:white_concrete
fill 559 261 583 559 263 583 minecraft:white_concrete
fill 559 261 587 559 271 587 minecraft:black_concrete
fill 517 262 557 517 273 559 minecraft:black_concrete
setblock 517 262 560 minecraft:white_stained_glass
fill 536 262 599 536 274 599 minecraft:black_concrete
fill 544 262 557 544 307 557 minecraft:black_concrete
fill 557 262 599 557 307 599 minecraft:black_concrete
fill 517 263 560 517 307 560 minecraft:black_concrete
setblock 517 263 566 minecraft:sea_lantern
fill 517 263 567 517 266 568 minecraft:black_concrete
setblock 559 263 593 minecraft:white_stained_glass
fill 517 264 565 517 269 566 minecraft:black_concrete
fill 517 264 581 517 269 581 minecraft:black_concrete
fill 517 264 597 517 269 597 minecraft:black_concrete
schedule function dropper:buildpart/143_2 1t
