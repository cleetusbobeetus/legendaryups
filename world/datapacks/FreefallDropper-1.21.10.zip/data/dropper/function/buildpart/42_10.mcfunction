fill 320 241 182 320 244 182 minecraft:red_nether_bricks
setblock 320 241 221 minecraft:polished_blackstone
fill 320 241 222 320 244 222 minecraft:red_nether_bricks
setblock 321 241 204 minecraft:red_nether_bricks
setblock 321 241 220 minecraft:polished_blackstone
fill 321 241 221 321 244 221 minecraft:red_nether_bricks
setblock 322 241 183 minecraft:red_nether_bricks
fill 322 241 200 322 243 200 minecraft:red_nether_bricks
setblock 322 241 204 minecraft:polished_blackstone
fill 322 241 205 322 244 205 minecraft:red_nether_bricks
setblock 322 241 209 minecraft:polished_blackstone
setblock 322 241 219 minecraft:polished_blackstone
fill 322 241 220 322 244 220 minecraft:red_nether_bricks
setblock 323 241 183 minecraft:polished_blackstone
fill 323 241 184 323 244 184 minecraft:red_nether_bricks
setblock 323 241 198 minecraft:polished_blackstone
fill 323 241 199 323 244 199 minecraft:red_nether_bricks
setblock 323 241 203 minecraft:polished_blackstone
fill 323 241 204 323 244 204 minecraft:red_nether_bricks
setblock 323 241 208 minecraft:polished_blackstone
fill 323 241 209 323 244 209 minecraft:red_nether_bricks
setblock 323 241 213 minecraft:polished_blackstone
fill 323 241 214 323 244 214 minecraft:red_nether_bricks
setblock 323 241 218 minecraft:polished_blackstone
fill 323 241 219 323 244 219 minecraft:red_nether_bricks
setblock 283 242 182 minecraft:polished_blackstone
fill 283 242 183 283 244 184 minecraft:red_nether_bricks
setblock 283 242 196 minecraft:red_nether_bricks
setblock 283 242 197 minecraft:polished_blackstone
fill 283 242 198 283 242 201 minecraft:red_nether_bricks
setblock 283 242 202 minecraft:polished_blackstone
fill 283 242 203 283 245 203 minecraft:red_nether_bricks
setblock 283 242 207 minecraft:polished_blackstone
fill 283 242 208 284 244 208 minecraft:red_nether_bricks
setblock 283 242 222 minecraft:polished_blackstone
setblock 284 242 201 minecraft:polished_blackstone
fill 284 242 202 284 245 202 minecraft:red_nether_bricks
setblock 284 242 206 minecraft:polished_blackstone
fill 284 242 207 284 245 207 minecraft:red_nether_bricks
fill 289 242 182 292 242 182 minecraft:red_nether_bricks
setblock 292 242 183 minecraft:polished_blackstone
fill 292 242 215 293 243 216 minecraft:blackstone
setblock 292 242 222 minecraft:red_nether_bricks
setblock 293 242 182 minecraft:polished_blackstone
fill 293 242 183 293 245 183 minecraft:red_nether_bricks
setblock 293 242 222 minecraft:polished_blackstone
fill 294 242 182 294 245 182 minecraft:red_nether_bricks
fill 294 242 184 295 242 184 minecraft:red_nether_bricks
fill 294 242 222 294 245 222 minecraft:red_nether_bricks
setblock 296 242 184 minecraft:polished_blackstone
fill 296 242 221 296 244 221 minecraft:red_nether_bricks
setblock 297 242 183 minecraft:polished_blackstone
fill 297 242 184 297 244 185 minecraft:red_nether_bricks
setblock 298 242 182 minecraft:polished_blackstone
fill 298 242 183 298 245 183 minecraft:red_nether_bricks
fill 298 242 185 299 242 185 minecraft:red_nether_bricks
setblock 298 242 222 minecraft:polished_blackstone
fill 299 242 182 299 245 182 minecraft:red_nether_bricks
setblock 299 242 221 minecraft:polished_blackstone
fill 299 242 222 302 242 222 minecraft:red_nether_bricks
setblock 300 242 184 minecraft:red_nether_bricks
fill 300 242 221 300 245 221 minecraft:red_nether_bricks
setblock 301 242 184 minecraft:polished_blackstone
setblock 302 242 183 minecraft:polished_blackstone
fill 302 242 184 302 245 184 minecraft:red_nether_bricks
setblock 303 242 182 minecraft:polished_blackstone
fill 303 242 183 303 245 183 minecraft:red_nether_bricks
setblock 303 242 222 minecraft:polished_blackstone
fill 304 242 182 304 245 182 minecraft:red_nether_bricks
fill 304 242 222 304 245 222 minecraft:red_nether_bricks
setblock 307 242 183 minecraft:polished_blackstone
setblock 308 242 182 minecraft:polished_blackstone
fill 308 242 183 311 242 183 minecraft:red_nether_bricks
setblock 308 242 222 minecraft:polished_blackstone
fill 309 242 182 309 245 182 minecraft:red_nether_bricks
fill 309 242 222 309 245 222 minecraft:red_nether_bricks
fill 310 242 221 310 245 221 minecraft:red_nether_bricks
setblock 312 242 183 minecraft:polished_blackstone
setblock 313 242 182 minecraft:polished_blackstone
fill 313 242 183 313 245 183 minecraft:red_nether_bricks
setblock 313 242 222 minecraft:polished_blackstone
fill 314 242 182 314 245 182 minecraft:red_nether_bricks
fill 314 242 184 315 242 184 minecraft:red_nether_bricks
setblock 314 242 221 minecraft:polished_blackstone
fill 314 242 222 314 245 222 minecraft:red_nether_bricks
setblock 315 242 220 minecraft:polished_blackstone
fill 315 242 221 315 245 221 minecraft:red_nether_bricks
setblock 316 242 184 minecraft:polished_blackstone
fill 316 242 220 316 245 220 minecraft:red_nether_bricks
setblock 317 242 183 minecraft:polished_blackstone
fill 317 242 184 318 244 184 minecraft:red_nether_bricks
setblock 318 242 182 minecraft:polished_blackstone
fill 318 242 183 318 245 183 minecraft:red_nether_bricks
setblock 318 242 222 minecraft:polished_blackstone
fill 319 242 182 319 245 182 minecraft:red_nether_bricks
setblock 319 242 221 minecraft:polished_blackstone
fill 319 242 222 319 245 222 minecraft:red_nether_bricks
setblock 320 242 220 minecraft:polished_blackstone
fill 320 242 221 320 245 221 minecraft:red_nether_bricks
setblock 321 242 203 minecraft:red_nether_bricks
setblock 321 242 204 minecraft:polished_blackstone
fill 321 242 205 321 243 207 minecraft:red_nether_bricks
setblock 321 242 220 minecraft:red_nether_bricks
setblock 322 242 183 minecraft:polished_blackstone
setblock 322 242 203 minecraft:polished_blackstone
fill 322 242 204 322 245 204 minecraft:red_nether_bricks
fill 322 242 206 322 242 207 minecraft:red_nether_bricks
setblock 322 242 208 minecraft:polished_blackstone
fill 322 242 209 322 243 211 minecraft:red_nether_bricks
setblock 322 242 218 minecraft:polished_blackstone
fill 322 242 219 322 244 219 minecraft:red_nether_bricks
setblock 323 242 182 minecraft:polished_blackstone
fill 323 242 183 323 245 183 minecraft:red_nether_bricks
fill 323 242 185 323 243 185 minecraft:red_nether_bricks
setblock 323 242 198 minecraft:red_nether_bricks
setblock 323 242 202 minecraft:polished_blackstone
fill 323 242 203 323 245 203 minecraft:red_nether_bricks
setblock 323 242 207 minecraft:polished_blackstone
fill 323 242 208 323 245 208 minecraft:red_nether_bricks
setblock 323 242 212 minecraft:polished_blackstone
fill 323 242 213 323 245 213 minecraft:red_nether_bricks
setblock 323 242 217 minecraft:polished_blackstone
fill 323 242 218 323 245 218 minecraft:red_nether_bricks
setblock 323 242 222 minecraft:polished_blackstone
fill 283 243 182 284 245 182 minecraft:red_nether_bricks
setblock 283 243 185 minecraft:red_nether_bricks
setblock 283 243 186 minecraft:polished_blackstone
setblock 283 243 196 minecraft:polished_blackstone
fill 283 243 197 283 243 200 minecraft:red_nether_bricks
setblock 283 243 201 minecraft:polished_blackstone
fill 283 243 202 283 246 202 minecraft:red_nether_bricks
setblock 283 243 206 minecraft:polished_blackstone
fill 283 243 207 283 246 207 minecraft:red_nether_bricks
setblock 283 243 211 minecraft:polished_blackstone
fill 283 243 212 283 246 212 minecraft:red_nether_bricks
setblock 283 243 222 minecraft:red_nether_bricks
setblock 284 243 200 minecraft:polished_blackstone
fill 284 243 201 284 246 201 minecraft:red_nether_bricks
setblock 284 243 205 minecraft:polished_blackstone
fill 284 243 206 284 246 206 minecraft:red_nether_bricks
setblock 287 243 182 minecraft:polished_blackstone
fill 288 243 182 291 243 182 minecraft:red_nether_bricks
setblock 290 243 183 minecraft:red_nether_bricks
setblock 291 243 183 minecraft:polished_blackstone
setblock 291 243 222 minecraft:red_nether_bricks
setblock 292 243 182 minecraft:polished_blackstone
fill 292 243 183 292 246 183 minecraft:red_nether_bricks
setblock 292 243 222 minecraft:polished_blackstone
fill 293 243 182 293 246 182 minecraft:red_nether_bricks
fill 293 243 184 294 243 184 minecraft:red_nether_bricks
fill 293 243 222 293 246 222 minecraft:red_nether_bricks
setblock 295 243 184 minecraft:polished_blackstone
fill 295 243 185 296 245 185 minecraft:red_nether_bricks
fill 295 243 221 295 245 221 minecraft:red_nether_bricks
setblock 296 243 183 minecraft:polished_blackstone
fill 296 243 184 296 246 184 minecraft:red_nether_bricks
setblock 297 243 182 minecraft:polished_blackstone
fill 297 243 183 297 246 183 minecraft:red_nether_bricks
setblock 297 243 222 minecraft:polished_blackstone
fill 298 243 182 298 246 182 minecraft:red_nether_bricks
setblock 298 243 185 minecraft:red_nether_bricks
setblock 298 243 221 minecraft:polished_blackstone
fill 298 243 222 301 243 222 minecraft:red_nether_bricks
setblock 299 243 185 minecraft:polished_blackstone
fill 299 243 221 299 245 221 minecraft:red_nether_bricks
setblock 300 243 184 minecraft:polished_blackstone
fill 300 243 185 300 246 185 minecraft:red_nether_bricks
setblock 301 243 183 minecraft:polished_blackstone
fill 301 243 184 301 246 184 minecraft:red_nether_bricks
setblock 302 243 182 minecraft:polished_blackstone
fill 302 243 183 302 246 183 minecraft:red_nether_bricks
setblock 302 243 222 minecraft:polished_blackstone
fill 303 243 182 303 246 182 minecraft:red_nether_bricks
fill 303 243 222 303 246 222 minecraft:red_nether_bricks
setblock 304 243 184 minecraft:red_nether_bricks
setblock 306 243 183 minecraft:polished_blackstone
setblock 307 243 182 minecraft:polished_blackstone
fill 307 243 183 310 243 183 minecraft:red_nether_bricks
setblock 307 243 222 minecraft:polished_blackstone
fill 308 243 182 308 246 182 minecraft:red_nether_bricks
fill 308 243 222 308 246 222 minecraft:red_nether_bricks
fill 309 243 221 309 246 221 minecraft:red_nether_bricks
setblock 311 243 183 minecraft:polished_blackstone
fill 311 243 184 314 243 184 minecraft:red_nether_bricks
setblock 312 243 182 minecraft:polished_blackstone
fill 312 243 183 312 246 183 minecraft:red_nether_bricks
setblock 312 243 222 minecraft:polished_blackstone
fill 313 243 182 313 246 182 minecraft:red_nether_bricks
setblock 313 243 220 minecraft:red_nether_bricks
setblock 313 243 221 minecraft:polished_blackstone
fill 313 243 222 313 246 222 minecraft:red_nether_bricks
setblock 314 243 220 minecraft:polished_blackstone
fill 314 243 221 314 246 221 minecraft:red_nether_bricks
setblock 315 243 184 minecraft:polished_blackstone
fill 315 243 220 315 246 220 minecraft:red_nether_bricks
setblock 316 243 183 minecraft:polished_blackstone
fill 316 243 184 316 246 184 minecraft:red_nether_bricks
setblock 317 243 182 minecraft:polished_blackstone
fill 317 243 183 317 246 183 minecraft:red_nether_bricks
setblock 317 243 222 minecraft:polished_blackstone
fill 318 243 182 318 246 182 minecraft:red_nether_bricks
setblock 318 243 221 minecraft:polished_blackstone
fill 318 243 222 318 246 222 minecraft:red_nether_bricks
setblock 319 243 184 minecraft:red_nether_bricks
setblock 319 243 220 minecraft:polished_blackstone
fill 319 243 221 319 246 221 minecraft:red_nether_bricks
fill 320 243 220 320 244 220 minecraft:red_nether_bricks
setblock 321 243 183 minecraft:polished_blackstone
setblock 321 243 202 minecraft:red_nether_bricks
setblock 321 243 203 minecraft:polished_blackstone
fill 321 243 204 321 246 204 minecraft:red_nether_bricks
setblock 321 243 208 minecraft:polished_blackstone
fill 321 243 209 321 246 209 minecraft:red_nether_bricks
setblock 322 243 182 minecraft:polished_blackstone
fill 322 243 183 322 244 183 minecraft:red_nether_bricks
setblock 322 243 202 minecraft:polished_blackstone
fill 322 243 203 322 246 203 minecraft:red_nether_bricks
setblock 322 243 206 minecraft:red_nether_bricks
setblock 322 243 207 minecraft:polished_blackstone
fill 322 243 208 322 246 208 minecraft:red_nether_bricks
setblock 322 243 212 minecraft:polished_blackstone
setblock 322 243 218 minecraft:red_nether_bricks
setblock 322 243 222 minecraft:polished_blackstone
fill 323 243 182 323 246 182 minecraft:red_nether_bricks
setblock 323 243 201 minecraft:polished_blackstone
fill 323 243 202 323 246 202 minecraft:red_nether_bricks
setblock 323 243 206 minecraft:polished_blackstone
fill 323 243 207 323 246 207 minecraft:red_nether_bricks
setblock 323 243 211 minecraft:polished_blackstone
fill 323 243 212 323 246 212 minecraft:red_nether_bricks
setblock 323 243 216 minecraft:polished_blackstone
fill 323 243 217 323 245 217 minecraft:red_nether_bricks
setblock 323 243 221 minecraft:polished_blackstone
fill 323 243 222 323 246 222 minecraft:red_nether_bricks
setblock 283 244 185 minecraft:polished_blackstone
fill 283 244 186 283 246 187 minecraft:red_nether_bricks
fill 283 244 196 283 244 199 minecraft:red_nether_bricks
setblock 283 244 200 minecraft:polished_blackstone
fill 283 244 201 283 247 201 minecraft:red_nether_bricks
setblock 283 244 205 minecraft:polished_blackstone
fill 283 244 206 283 247 206 minecraft:red_nether_bricks
setblock 283 244 210 minecraft:polished_blackstone
fill 283 244 211 283 247 211 minecraft:red_nether_bricks
setblock 284 244 199 minecraft:polished_blackstone
fill 284 244 200 284 245 200 minecraft:red_nether_bricks
setblock 284 244 204 minecraft:polished_blackstone
fill 284 244 205 285 245 205 minecraft:red_nether_bricks
setblock 284 244 209 minecraft:polished_blackstone
setblock 285 244 182 minecraft:red_nether_bricks
setblock 285 244 184 minecraft:light[level=14]
setblock 285 244 192 minecraft:light[level=14]
setblock 285 244 200 minecraft:light[level=14]
fill 285 244 204 285 245 204 minecraft:red_nether_bricks
setblock 285 244 208 minecraft:light[level=14]
setblock 285 244 216 minecraft:light[level=14]
setblock 286 244 182 minecraft:polished_blackstone
fill 287 244 182 290 244 182 minecraft:red_nether_bricks
setblock 289 244 183 minecraft:red_nether_bricks
setblock 290 244 183 minecraft:polished_blackstone
setblock 291 244 182 minecraft:polished_blackstone
fill 291 244 183 291 246 184 minecraft:red_nether_bricks
setblock 291 244 222 minecraft:polished_blackstone
fill 292 244 182 292 247 182 minecraft:red_nether_bricks
fill 292 244 184 293 244 184 minecraft:red_nether_bricks
fill 292 244 222 292 247 222 minecraft:red_nether_bricks
setblock 293 244 192 minecraft:light[level=14]
setblock 293 244 200 minecraft:light[level=14]
setblock 293 244 208 minecraft:light[level=14]
setblock 293 244 216 minecraft:light[level=14]
setblock 294 244 184 minecraft:polished_blackstone
fill 294 244 185 294 247 185 minecraft:red_nether_bricks
setblock 295 244 183 minecraft:polished_blackstone
fill 295 244 184 295 247 184 minecraft:red_nether_bricks
setblock 296 244 182 minecraft:polished_blackstone
fill 296 244 183 296 247 183 minecraft:red_nether_bricks
setblock 296 244 222 minecraft:polished_blackstone
fill 297 244 182 297 247 182 minecraft:red_nether_bricks
setblock 297 244 221 minecraft:polished_blackstone
fill 297 244 222 300 244 222 minecraft:red_nether_bricks
setblock 298 244 185 minecraft:polished_blackstone
fill 298 244 221 298 246 221 minecraft:red_nether_bricks
setblock 299 244 184 minecraft:polished_blackstone
fill 299 244 185 299 247 185 minecraft:red_nether_bricks
setblock 300 244 183 minecraft:polished_blackstone
fill 300 244 184 300 247 184 minecraft:red_nether_bricks
setblock 301 244 182 minecraft:polished_blackstone
fill 301 244 183 301 247 183 minecraft:red_nether_bricks
fill 301 244 185 301 245 185 minecraft:red_nether_bricks
setblock 301 244 192 minecraft:light[level=14]
setblock 301 244 200 minecraft:light[level=14]
setblock 301 244 208 minecraft:light[level=14]
setblock 301 244 216 minecraft:light[level=14]
setblock 301 244 222 minecraft:polished_blackstone
fill 302 244 182 302 247 182 minecraft:red_nether_bricks
fill 302 244 222 302 247 222 minecraft:red_nether_bricks
setblock 304 244 184 minecraft:polished_blackstone
setblock 305 244 183 minecraft:polished_blackstone
fill 305 244 184 305 246 184 minecraft:red_nether_bricks
setblock 306 244 182 minecraft:polished_blackstone
fill 306 244 183 309 244 183 minecraft:red_nether_bricks
setblock 306 244 222 minecraft:polished_blackstone
fill 307 244 182 307 247 182 minecraft:red_nether_bricks
fill 307 244 222 307 247 222 minecraft:red_nether_bricks
setblock 309 244 184 minecraft:polished_blackstone
setblock 309 244 192 minecraft:light[level=14]
setblock 309 244 200 minecraft:light[level=14]
setblock 309 244 208 minecraft:light[level=14]
setblock 309 244 216 minecraft:light[level=14]
setblock 310 244 183 minecraft:polished_blackstone
fill 310 244 184 313 244 184 minecraft:red_nether_bricks
setblock 311 244 182 minecraft:polished_blackstone
fill 311 244 183 311 247 183 minecraft:red_nether_bricks
setblock 311 244 222 minecraft:polished_blackstone
fill 312 244 182 312 247 182 minecraft:red_nether_bricks
setblock 312 244 221 minecraft:polished_blackstone
fill 312 244 222 312 247 222 minecraft:red_nether_bricks
setblock 313 244 220 minecraft:polished_blackstone
fill 313 244 221 313 247 221 minecraft:red_nether_bricks
setblock 314 244 184 minecraft:polished_blackstone
fill 314 244 220 314 247 220 minecraft:red_nether_bricks
setblock 315 244 183 minecraft:polished_blackstone
fill 315 244 184 315 247 184 minecraft:red_nether_bricks
setblock 316 244 182 minecraft:polished_blackstone
fill 316 244 183 316 247 183 minecraft:red_nether_bricks
setblock 316 244 222 minecraft:polished_blackstone
fill 317 244 182 317 247 182 minecraft:red_nether_bricks
setblock 317 244 192 minecraft:light[level=14]
setblock 317 244 200 minecraft:light[level=14]
setblock 317 244 208 minecraft:light[level=14]
setblock 317 244 216 minecraft:light[level=14]
setblock 317 244 221 minecraft:polished_blackstone
fill 317 244 222 317 247 222 minecraft:red_nether_bricks
setblock 318 244 220 minecraft:polished_blackstone
fill 318 244 221 318 247 221 minecraft:red_nether_bricks
setblock 319 244 184 minecraft:polished_blackstone
fill 319 244 220 319 245 220 minecraft:red_nether_bricks
setblock 320 244 183 minecraft:polished_blackstone
setblock 321 244 182 minecraft:polished_blackstone
fill 321 244 183 321 246 183 minecraft:red_nether_bricks
fill 321 244 203 321 246 203 minecraft:red_nether_bricks
fill 321 244 205 321 244 206 minecraft:red_nether_bricks
setblock 321 244 207 minecraft:polished_blackstone
fill 321 244 208 321 247 208 minecraft:red_nether_bricks
fill 321 244 210 322 244 210 minecraft:red_nether_bricks
setblock 321 244 222 minecraft:polished_blackstone
fill 322 244 182 322 247 182 minecraft:red_nether_bricks
setblock 322 244 201 minecraft:polished_blackstone
fill 322 244 202 322 247 202 minecraft:red_nether_bricks
setblock 322 244 206 minecraft:polished_blackstone
fill 322 244 207 322 247 207 minecraft:red_nether_bricks
fill 322 244 209 322 245 209 minecraft:red_nether_bricks
setblock 322 244 211 minecraft:polished_blackstone
fill 322 244 212 322 246 213 minecraft:red_nether_bricks
setblock 322 244 221 minecraft:polished_blackstone
fill 322 244 222 322 247 222 minecraft:red_nether_bricks
setblock 323 244 185 minecraft:polished_blackstone
fill 323 244 186 323 247 186 minecraft:red_nether_bricks
setblock 323 244 200 minecraft:polished_blackstone
fill 323 244 201 323 247 201 minecraft:red_nether_bricks
setblock 323 244 205 minecraft:polished_blackstone
fill 323 244 206 323 247 206 minecraft:red_nether_bricks
setblock 323 244 210 minecraft:polished_blackstone
fill 323 244 211 323 247 211 minecraft:red_nether_bricks
setblock 323 244 215 minecraft:polished_blackstone
fill 323 244 216 323 246 216 minecraft:red_nether_bricks
setblock 323 244 220 minecraft:polished_blackstone
fill 323 244 221 323 246 221 minecraft:red_nether_bricks
setblock 283 245 183 minecraft:red_nether_bricks
setblock 283 245 184 minecraft:polished_blackstone
fill 283 245 185 283 248 185 minecraft:red_nether_bricks
setblock 283 245 188 minecraft:red_nether_bricks
setblock 283 245 189 minecraft:polished_blackstone
fill 283 245 196 283 245 198 minecraft:red_nether_bricks
setblock 283 245 199 minecraft:polished_blackstone
fill 283 245 200 283 248 200 minecraft:red_nether_bricks
setblock 283 245 204 minecraft:polished_blackstone
fill 283 245 205 283 248 205 minecraft:red_nether_bricks
setblock 283 245 208 minecraft:red_nether_bricks
setblock 283 245 209 minecraft:polished_blackstone
fill 283 245 210 283 248 210 minecraft:red_nether_bricks
setblock 284 245 203 minecraft:polished_blackstone
fill 284 245 204 284 248 204 minecraft:red_nether_bricks
setblock 284 245 208 minecraft:polished_blackstone
fill 284 245 209 284 248 209 minecraft:red_nether_bricks
setblock 285 245 182 minecraft:polished_blackstone
fill 286 245 182 289 245 182 minecraft:red_nether_bricks
setblock 288 245 183 minecraft:red_nether_bricks
setblock 289 245 183 minecraft:polished_blackstone
setblock 290 245 182 minecraft:polished_blackstone
fill 290 245 183 290 247 184 minecraft:red_nether_bricks
fill 291 245 182 291 248 182 minecraft:red_nether_bricks
fill 291 245 222 291 248 222 minecraft:red_nether_bricks
setblock 292 245 184 minecraft:red_nether_bricks
setblock 292 245 185 minecraft:polished_blackstone
setblock 293 245 184 minecraft:polished_blackstone
fill 293 245 185 293 248 185 minecraft:red_nether_bricks
setblock 294 245 183 minecraft:polished_blackstone
fill 294 245 184 294 248 184 minecraft:red_nether_bricks
setblock 294 245 221 minecraft:red_nether_bricks
setblock 295 245 182 minecraft:polished_blackstone
fill 295 245 183 295 248 183 minecraft:red_nether_bricks
setblock 295 245 222 minecraft:polished_blackstone
fill 296 245 182 296 248 182 minecraft:red_nether_bricks
setblock 296 245 186 minecraft:polished_blackstone
setblock 296 245 221 minecraft:polished_blackstone
fill 296 245 222 299 245 222 minecraft:red_nether_bricks
setblock 297 245 184 minecraft:red_nether_bricks
setblock 297 245 185 minecraft:polished_blackstone
fill 297 245 186 297 247 186 minecraft:red_nether_bricks
fill 297 245 221 297 246 221 minecraft:red_nether_bricks
setblock 298 245 184 minecraft:polished_blackstone
fill 298 245 185 298 248 185 minecraft:red_nether_bricks
setblock 299 245 183 minecraft:polished_blackstone
fill 299 245 184 299 248 184 minecraft:red_nether_bricks
setblock 300 245 182 minecraft:polished_blackstone
fill 300 245 183 300 248 183 minecraft:red_nether_bricks
setblock 300 245 222 minecraft:polished_blackstone
fill 301 245 182 301 248 182 minecraft:red_nether_bricks
fill 301 245 222 301 248 222 minecraft:red_nether_bricks
setblock 303 245 184 minecraft:polished_blackstone
setblock 304 245 183 minecraft:polished_blackstone
fill 304 245 184 304 247 184 minecraft:red_nether_bricks
setblock 305 245 182 minecraft:polished_blackstone
fill 305 245 183 308 245 183 minecraft:red_nether_bricks
setblock 305 245 222 minecraft:polished_blackstone
fill 306 245 182 306 248 182 minecraft:red_nether_bricks
fill 306 245 184 307 245 184 minecraft:red_nether_bricks
fill 306 245 222 306 248 222 minecraft:red_nether_bricks
setblock 308 245 184 minecraft:polished_blackstone
setblock 309 245 183 minecraft:polished_blackstone
fill 309 245 184 312 245 184 minecraft:red_nether_bricks
setblock 310 245 182 minecraft:polished_blackstone
fill 310 245 183 310 248 183 minecraft:red_nether_bricks
setblock 310 245 222 minecraft:polished_blackstone
fill 311 245 182 311 248 182 minecraft:red_nether_bricks
setblock 311 245 221 minecraft:polished_blackstone
fill 311 245 222 311 248 222 minecraft:red_nether_bricks
setblock 312 245 220 minecraft:polished_blackstone
fill 312 245 221 312 248 221 minecraft:red_nether_bricks
setblock 313 245 184 minecraft:polished_blackstone
fill 313 245 220 313 248 220 minecraft:red_nether_bricks
setblock 314 245 183 minecraft:polished_blackstone
fill 314 245 184 314 248 184 minecraft:red_nether_bricks
setblock 315 245 182 minecraft:polished_blackstone
fill 315 245 183 315 248 183 minecraft:red_nether_bricks
setblock 315 245 222 minecraft:polished_blackstone
fill 316 245 182 316 248 182 minecraft:red_nether_bricks
setblock 316 245 221 minecraft:polished_blackstone
fill 316 245 222 316 248 222 minecraft:red_nether_bricks
setblock 317 245 184 minecraft:red_nether_bricks
setblock 317 245 220 minecraft:polished_blackstone
fill 317 245 221 317 248 221 minecraft:red_nether_bricks
setblock 318 245 184 minecraft:polished_blackstone
fill 318 245 220 318 246 220 minecraft:red_nether_bricks
setblock 319 245 183 minecraft:polished_blackstone
setblock 319 245 184 minecraft:red_nether_bricks
setblock 320 245 182 minecraft:polished_blackstone
fill 320 245 183 320 247 183 minecraft:red_nether_bricks
setblock 320 245 206 minecraft:red_nether_bricks
setblock 320 245 207 minecraft:polished_blackstone
setblock 320 245 222 minecraft:polished_blackstone
fill 321 245 182 321 247 182 minecraft:red_nether_bricks
setblock 321 245 205 minecraft:red_nether_bricks
setblock 321 245 206 minecraft:polished_blackstone
fill 321 245 207 321 248 207 minecraft:red_nether_bricks
setblock 321 245 210 minecraft:red_nether_bricks
setblock 321 245 211 minecraft:polished_blackstone
setblock 321 245 221 minecraft:polished_blackstone
fill 321 245 222 321 248 222 minecraft:red_nether_bricks
setblock 322 245 201 minecraft:red_nether_bricks
setblock 322 245 205 minecraft:polished_blackstone
fill 322 245 206 322 248 206 minecraft:red_nether_bricks
setblock 322 245 210 minecraft:polished_blackstone
fill 322 245 211 322 248 211 minecraft:red_nether_bricks
setblock 322 245 221 minecraft:red_nether_bricks
setblock 323 245 184 minecraft:polished_blackstone
fill 323 245 185 323 247 185 minecraft:red_nether_bricks
setblock 323 245 199 minecraft:polished_blackstone
fill 323 245 200 323 247 200 minecraft:red_nether_bricks
setblock 323 245 204 minecraft:polished_blackstone
fill 323 245 205 323 248 205 minecraft:red_nether_bricks
setblock 323 245 209 minecraft:polished_blackstone
fill 323 245 210 323 248 210 minecraft:red_nether_bricks
setblock 323 245 214 minecraft:polished_blackstone
fill 323 245 215 323 248 215 minecraft:red_nether_bricks
setblock 323 245 219 minecraft:polished_blackstone
fill 323 245 220 323 246 220 minecraft:red_nether_bricks
setblock 283 246 182 minecraft:red_nether_bricks
setblock 283 246 183 minecraft:polished_blackstone
fill 283 246 184 283 248 184 minecraft:red_nether_bricks
setblock 283 246 188 minecraft:polished_blackstone
fill 283 246 189 283 247 191 minecraft:red_nether_bricks
setblock 283 246 197 minecraft:red_nether_bricks
setblock 283 246 198 minecraft:polished_blackstone
fill 283 246 199 283 248 199 minecraft:red_nether_bricks
setblock 283 246 203 minecraft:polished_blackstone
fill 283 246 204 283 249 204 minecraft:red_nether_bricks
setblock 283 246 208 minecraft:polished_blackstone
fill 283 246 209 283 249 209 minecraft:red_nether_bricks
setblock 284 246 182 minecraft:polished_blackstone
setblock 284 246 202 minecraft:polished_blackstone
fill 284 246 203 284 248 203 minecraft:red_nether_bricks
fill 284 246 205 284 247 205 minecraft:red_nether_bricks
setblock 284 246 207 minecraft:polished_blackstone
fill 284 246 208 284 249 208 minecraft:red_nether_bricks
fill 284 246 210 284 247 210 minecraft:red_nether_bricks
fill 285 246 182 288 246 182 minecraft:red_nether_bricks
setblock 288 246 183 minecraft:polished_blackstone
setblock 289 246 182 minecraft:polished_blackstone
fill 289 246 183 289 249 183 minecraft:red_nether_bricks
fill 290 246 182 290 249 182 minecraft:red_nether_bricks
setblock 290 246 222 minecraft:red_nether_bricks
setblock 292 246 184 minecraft:polished_blackstone
fill 292 246 185 292 249 185 minecraft:red_nether_bricks
setblock 293 246 183 minecraft:polished_blackstone
fill 293 246 184 293 249 184 minecraft:red_nether_bricks
setblock 294 246 182 minecraft:polished_blackstone
fill 294 246 183 294 249 183 minecraft:red_nether_bricks
setblock 294 246 186 minecraft:red_nether_bricks
setblock 294 246 222 minecraft:polished_blackstone
fill 295 246 182 295 249 182 minecraft:red_nether_bricks
setblock 295 246 185 minecraft:red_nether_bricks
setblock 295 246 186 minecraft:polished_blackstone
setblock 295 246 221 minecraft:polished_blackstone
fill 295 246 222 298 246 222 minecraft:red_nether_bricks
setblock 296 246 185 minecraft:polished_blackstone
fill 296 246 186 296 247 186 minecraft:red_nether_bricks
setblock 296 246 221 minecraft:red_nether_bricks
setblock 297 246 184 minecraft:polished_blackstone
fill 297 246 185 297 249 185 minecraft:red_nether_bricks
setblock 298 246 183 minecraft:polished_blackstone
fill 298 246 184 298 249 184 minecraft:red_nether_bricks
setblock 299 246 182 minecraft:polished_blackstone
fill 299 246 183 299 249 183 minecraft:red_nether_bricks
setblock 299 246 222 minecraft:polished_blackstone
fill 300 246 182 300 249 182 minecraft:red_nether_bricks
fill 300 246 222 300 248 222 minecraft:red_nether_bricks
setblock 301 246 185 minecraft:polished_blackstone
setblock 302 246 184 minecraft:polished_blackstone
setblock 303 246 183 minecraft:polished_blackstone
fill 303 246 184 303 247 184 minecraft:red_nether_bricks
setblock 304 246 182 minecraft:polished_blackstone
fill 304 246 183 307 246 183 minecraft:red_nether_bricks
setblock 304 246 222 minecraft:polished_blackstone
fill 305 246 182 305 249 182 minecraft:red_nether_bricks
fill 305 246 222 305 248 222 minecraft:red_nether_bricks
setblock 306 246 184 minecraft:red_nether_bricks
setblock 307 246 184 minecraft:polished_blackstone
setblock 308 246 183 minecraft:polished_blackstone
fill 308 246 184 311 246 184 minecraft:red_nether_bricks
setblock 309 246 182 minecraft:polished_blackstone
fill 309 246 183 309 249 183 minecraft:red_nether_bricks
setblock 309 246 222 minecraft:polished_blackstone
fill 310 246 182 310 249 182 minecraft:red_nether_bricks
setblock 310 246 221 minecraft:polished_blackstone
fill 310 246 222 310 249 222 minecraft:red_nether_bricks
fill 311 246 221 311 249 221 minecraft:red_nether_bricks
setblock 312 246 184 minecraft:polished_blackstone
fill 312 246 220 312 247 220 minecraft:red_nether_bricks
setblock 313 246 183 minecraft:polished_blackstone
fill 313 246 184 313 249 184 minecraft:red_nether_bricks
setblock 314 246 182 minecraft:polished_blackstone
fill 314 246 183 314 249 183 minecraft:red_nether_bricks
setblock 314 246 222 minecraft:polished_blackstone
fill 315 246 182 315 249 182 minecraft:red_nether_bricks
setblock 315 246 221 minecraft:polished_blackstone
fill 315 246 222 315 249 222 minecraft:red_nether_bricks
setblock 316 246 220 minecraft:polished_blackstone
fill 316 246 221 316 249 221 minecraft:red_nether_bricks
setblock 317 246 184 minecraft:polished_blackstone
fill 317 246 220 317 247 220 minecraft:red_nether_bricks
setblock 318 246 183 minecraft:polished_blackstone
fill 318 246 184 318 247 184 minecraft:red_nether_bricks
setblock 319 246 182 minecraft:polished_blackstone
fill 319 246 183 319 247 183 minecraft:red_nether_bricks
setblock 319 246 222 minecraft:polished_blackstone
fill 320 246 182 320 248 182 minecraft:red_nether_bricks
setblock 320 246 206 minecraft:polished_blackstone
fill 320 246 207 320 246 208 minecraft:red_nether_bricks
setblock 320 246 221 minecraft:polished_blackstone
fill 320 246 222 320 248 222 minecraft:red_nether_bricks
setblock 321 246 205 minecraft:polished_blackstone
fill 321 246 206 321 248 206 minecraft:red_nether_bricks
setblock 321 246 210 minecraft:polished_blackstone
fill 321 246 211 321 248 211 minecraft:red_nether_bricks
setblock 321 246 221 minecraft:red_nether_bricks
setblock 322 246 204 minecraft:polished_blackstone
fill 322 246 205 322 249 205 minecraft:red_nether_bricks
setblock 322 246 209 minecraft:polished_blackstone
fill 322 246 210 322 249 210 minecraft:red_nether_bricks
setblock 323 246 183 minecraft:polished_blackstone
fill 323 246 184 323 247 184 minecraft:red_nether_bricks
setblock 323 246 187 minecraft:red_nether_bricks
setblock 323 246 203 minecraft:polished_blackstone
fill 323 246 204 323 249 204 minecraft:red_nether_bricks
setblock 323 246 208 minecraft:polished_blackstone
fill 323 246 209 323 249 209 minecraft:red_nether_bricks
setblock 323 246 213 minecraft:polished_blackstone
fill 323 246 214 323 249 214 minecraft:red_nether_bricks
setblock 283 247 183 minecraft:red_nether_bricks
setblock 283 247 186 minecraft:red_nether_bricks
setblock 283 247 187 minecraft:polished_blackstone
fill 283 247 188 283 250 188 minecraft:red_nether_bricks
setblock 283 247 192 minecraft:polished_blackstone
setblock 283 247 198 minecraft:red_nether_bricks
setblock 283 247 202 minecraft:polished_blackstone
fill 283 247 203 283 250 203 minecraft:red_nether_bricks
setblock 283 247 207 minecraft:polished_blackstone
fill 283 247 208 283 250 208 minecraft:red_nether_bricks
setblock 283 247 212 minecraft:polished_blackstone
setblock 284 247 202 minecraft:red_nether_bricks
setblock 284 247 206 minecraft:polished_blackstone
fill 284 247 207 284 249 207 minecraft:red_nether_bricks
fill 286 247 182 287 247 182 minecraft:red_nether_bricks
setblock 288 247 182 minecraft:polished_blackstone
fill 288 247 183 288 250 183 minecraft:red_nether_bricks
fill 289 247 182 289 250 182 minecraft:red_nether_bricks
fill 289 247 184 289 248 184 minecraft:red_nether_bricks
setblock 291 247 183 minecraft:red_nether_bricks
setblock 291 247 184 minecraft:polished_blackstone
fill 291 247 185 291 250 185 minecraft:red_nether_bricks
setblock 292 247 183 minecraft:polished_blackstone
fill 292 247 184 292 250 184 minecraft:red_nether_bricks
setblock 293 247 182 minecraft:polished_blackstone
fill 293 247 183 293 250 183 minecraft:red_nether_bricks
setblock 293 247 222 minecraft:polished_blackstone
fill 294 247 182 294 250 182 minecraft:red_nether_bricks
setblock 294 247 186 minecraft:polished_blackstone
fill 294 247 222 297 247 222 minecraft:red_nether_bricks
setblock 295 247 185 minecraft:polished_blackstone
fill 295 247 186 295 248 186 minecraft:red_nether_bricks
setblock 296 247 184 minecraft:polished_blackstone
fill 296 247 185 296 250 185 minecraft:red_nether_bricks
setblock 297 247 183 minecraft:polished_blackstone
fill 297 247 184 297 250 184 minecraft:red_nether_bricks
setblock 298 247 182 minecraft:polished_blackstone
fill 298 247 183 298 250 183 minecraft:red_nether_bricks
setblock 298 247 222 minecraft:polished_blackstone
fill 299 247 182 299 250 182 minecraft:red_nether_bricks
fill 299 247 222 299 249 222 minecraft:red_nether_bricks
setblock 300 247 185 minecraft:polished_blackstone
setblock 301 247 184 minecraft:polished_blackstone
setblock 302 247 183 minecraft:polished_blackstone
fill 302 247 184 302 248 184 minecraft:red_nether_bricks
setblock 303 247 182 minecraft:polished_blackstone
fill 303 247 183 306 247 183 minecraft:red_nether_bricks
setblock 303 247 222 minecraft:polished_blackstone
fill 304 247 182 304 250 182 minecraft:red_nether_bricks
fill 304 247 222 304 248 222 minecraft:red_nether_bricks
setblock 307 247 183 minecraft:polished_blackstone
fill 307 247 184 310 247 184 minecraft:red_nether_bricks
setblock 308 247 182 minecraft:polished_blackstone
fill 308 247 183 308 250 183 minecraft:red_nether_bricks
setblock 308 247 222 minecraft:polished_blackstone
fill 309 247 182 309 250 182 minecraft:red_nether_bricks
setblock 309 247 221 minecraft:polished_blackstone
fill 309 247 222 309 250 222 minecraft:red_nether_bricks
fill 310 247 221 310 250 221 minecraft:red_nether_bricks
setblock 311 247 184 minecraft:polished_blackstone
setblock 312 247 183 minecraft:polished_blackstone
fill 312 247 184 312 249 184 minecraft:red_nether_bricks
setblock 313 247 182 minecraft:polished_blackstone
fill 313 247 183 313 250 183 minecraft:red_nether_bricks
setblock 313 247 222 minecraft:polished_blackstone
fill 314 247 182 314 250 182 minecraft:red_nether_bricks
setblock 314 247 221 minecraft:polished_blackstone
fill 314 247 222 314 250 222 minecraft:red_nether_bricks
setblock 315 247 220 minecraft:polished_blackstone
fill 315 247 221 315 250 221 minecraft:red_nether_bricks
setblock 316 247 184 minecraft:polished_blackstone
setblock 316 247 220 minecraft:red_nether_bricks
setblock 317 247 183 minecraft:polished_blackstone
setblock 317 247 184 minecraft:red_nether_bricks
setblock 318 247 182 minecraft:polished_blackstone
fill 318 247 183 318 248 183 minecraft:red_nether_bricks
setblock 318 247 222 minecraft:polished_blackstone
fill 319 247 182 319 249 182 minecraft:red_nether_bricks
setblock 319 247 221 minecraft:polished_blackstone
fill 319 247 222 319 249 222 minecraft:red_nether_bricks
setblock 321 247 204 minecraft:polished_blackstone
setblock 321 247 205 minecraft:red_nether_bricks
setblock 321 247 209 minecraft:polished_blackstone
fill 321 247 210 321 249 210 minecraft:red_nether_bricks
setblock 322 247 203 minecraft:polished_blackstone
fill 322 247 204 322 249 204 minecraft:red_nether_bricks
setblock 322 247 208 minecraft:polished_blackstone
fill 322 247 209 322 250 209 minecraft:red_nether_bricks
setblock 322 247 212 minecraft:red_nether_bricks
setblock 322 247 213 minecraft:polished_blackstone
setblock 323 247 183 minecraft:red_nether_bricks
setblock 323 247 187 minecraft:polished_blackstone
setblock 323 247 202 minecraft:polished_blackstone
fill 323 247 203 323 250 203 minecraft:red_nether_bricks
setblock 323 247 207 minecraft:polished_blackstone
fill 323 247 208 323 250 208 minecraft:red_nether_bricks
setblock 323 247 212 minecraft:polished_blackstone
fill 323 247 213 323 250 213 minecraft:red_nether_bricks
setblock 283 248 186 minecraft:polished_blackstone
fill 283 248 187 283 251 187 minecraft:red_nether_bricks
fill 283 248 189 283 248 190 minecraft:red_nether_bricks
setblock 283 248 191 minecraft:polished_blackstone
fill 283 248 192 283 251 192 minecraft:red_nether_bricks
setblock 283 248 201 minecraft:polished_blackstone
fill 283 248 202 283 249 202 minecraft:red_nether_bricks
setblock 283 248 206 minecraft:polished_blackstone
fill 283 248 207 283 251 207 minecraft:red_nether_bricks
setblock 283 248 211 minecraft:polished_blackstone
fill 283 248 212 283 250 212 minecraft:red_nether_bricks
setblock 284 248 205 minecraft:polished_blackstone
fill 284 248 206 284 249 206 minecraft:red_nether_bricks
setblock 286 248 182 minecraft:red_nether_bricks
setblock 287 248 182 minecraft:polished_blackstone
fill 288 248 182 288 251 182 minecraft:red_nether_bricks
setblock 290 248 183 minecraft:red_nether_bricks
setblock 290 248 184 minecraft:polished_blackstone
setblock 291 248 183 minecraft:polished_blackstone
fill 291 248 184 291 251 184 minecraft:red_nether_bricks
setblock 292 248 182 minecraft:polished_blackstone
fill 292 248 183 292 251 183 minecraft:red_nether_bricks
setblock 292 248 222 minecraft:polished_blackstone
fill 293 248 182 293 251 182 minecraft:red_nether_bricks
fill 293 248 222 296 248 222 minecraft:red_nether_bricks
setblock 294 248 185 minecraft:polished_blackstone
setblock 294 248 186 minecraft:red_nether_bricks
setblock 295 248 184 minecraft:polished_blackstone
fill 295 248 185 295 250 185 minecraft:red_nether_bricks
setblock 296 248 183 minecraft:polished_blackstone
fill 296 248 184 296 251 184 minecraft:red_nether_bricks
setblock 297 248 182 minecraft:polished_blackstone
fill 297 248 183 297 251 183 minecraft:red_nether_bricks
setblock 297 248 222 minecraft:polished_blackstone
fill 298 248 182 298 251 182 minecraft:red_nether_bricks
fill 298 248 222 298 249 222 minecraft:red_nether_bricks
setblock 299 248 185 minecraft:polished_blackstone
setblock 300 248 184 minecraft:polished_blackstone
setblock 301 248 183 minecraft:polished_blackstone
setblock 301 248 184 minecraft:red_nether_bricks
setblock 302 248 182 minecraft:polished_blackstone
fill 302 248 183 305 248 183 minecraft:red_nether_bricks
setblock 302 248 222 minecraft:polished_blackstone
fill 303 248 182 303 250 182 minecraft:red_nether_bricks
setblock 303 248 222 minecraft:red_nether_bricks
setblock 306 248 183 minecraft:polished_blackstone
setblock 307 248 182 minecraft:polished_blackstone
fill 307 248 183 307 250 183 minecraft:red_nether_bricks
setblock 307 248 222 minecraft:polished_blackstone
fill 308 248 182 308 251 182 minecraft:red_nether_bricks
fill 308 248 184 309 248 184 minecraft:red_nether_bricks
fill 308 248 222 308 251 222 minecraft:red_nether_bricks
setblock 309 248 221 minecraft:red_nether_bricks
setblock 310 248 184 minecraft:polished_blackstone
setblock 311 248 183 minecraft:polished_blackstone
fill 311 248 184 311 249 184 minecraft:red_nether_bricks
setblock 312 248 182 minecraft:polished_blackstone
fill 312 248 183 312 251 183 minecraft:red_nether_bricks
setblock 312 248 222 minecraft:polished_blackstone
fill 313 248 182 313 251 182 minecraft:red_nether_bricks
setblock 313 248 221 minecraft:polished_blackstone
fill 313 248 222 313 251 222 minecraft:red_nether_bricks
setblock 314 248 220 minecraft:polished_blackstone
fill 314 248 221 314 251 221 minecraft:red_nether_bricks
setblock 315 248 184 minecraft:polished_blackstone
setblock 315 248 220 minecraft:red_nether_bricks
setblock 316 248 183 minecraft:polished_blackstone
setblock 316 248 184 minecraft:red_nether_bricks
setblock 317 248 182 minecraft:polished_blackstone
fill 317 248 183 317 249 183 minecraft:red_nether_bricks
setblock 317 248 222 minecraft:polished_blackstone
fill 318 248 182 318 249 182 minecraft:red_nether_bricks
setblock 318 248 221 minecraft:polished_blackstone
fill 318 248 222 318 250 222 minecraft:red_nether_bricks
setblock 321 248 208 minecraft:polished_blackstone
fill 321 248 209 321 249 209 minecraft:red_nether_bricks
setblock 322 248 203 minecraft:red_nether_bricks
setblock 322 248 207 minecraft:polished_blackstone
fill 322 248 208 322 251 208 minecraft:red_nether_bricks
setblock 322 248 212 minecraft:polished_blackstone
setblock 322 248 213 minecraft:red_nether_bricks
setblock 323 248 201 minecraft:polished_blackstone
fill 323 248 202 323 249 202 minecraft:red_nether_bricks
setblock 323 248 206 minecraft:polished_blackstone
fill 323 248 207 323 251 207 minecraft:red_nether_bricks
setblock 323 248 211 minecraft:polished_blackstone
fill 323 248 212 323 251 212 minecraft:red_nether_bricks
setblock 283 249 185 minecraft:polished_blackstone
fill 283 249 186 283 251 186 minecraft:red_nether_bricks
setblock 283 249 189 minecraft:red_nether_bricks
setblock 283 249 190 minecraft:polished_blackstone
fill 283 249 191 283 252 191 minecraft:red_nether_bricks
setblock 283 249 201 minecraft:red_nether_bricks
setblock 283 249 205 minecraft:polished_blackstone
fill 283 249 206 283 251 206 minecraft:red_nether_bricks
setblock 283 249 210 minecraft:polished_blackstone
fill 283 249 211 283 252 211 minecraft:red_nether_bricks
setblock 284 249 205 minecraft:red_nether_bricks
setblock 284 249 209 minecraft:polished_blackstone
fill 287 249 182 287 250 182 minecraft:red_nether_bricks
setblock 289 249 184 minecraft:polished_blackstone
setblock 290 249 183 minecraft:polished_blackstone
fill 290 249 184 290 251 184 minecraft:red_nether_bricks
setblock 291 249 182 minecraft:polished_blackstone
fill 291 249 183 291 252 183 minecraft:red_nether_bricks
fill 292 249 182 292 252 182 minecraft:red_nether_bricks
fill 292 249 222 295 249 222 minecraft:red_nether_bricks
setblock 293 249 185 minecraft:polished_blackstone
setblock 294 249 184 minecraft:polished_blackstone
fill 294 249 185 294 250 185 minecraft:red_nether_bricks
setblock 295 249 183 minecraft:polished_blackstone
fill 295 249 184 295 251 184 minecraft:red_nether_bricks
setblock 296 249 182 minecraft:polished_blackstone
fill 296 249 183 296 252 183 minecraft:red_nether_bricks
setblock 296 249 222 minecraft:polished_blackstone
fill 297 249 182 297 252 182 minecraft:red_nether_bricks
setblock 297 249 222 minecraft:red_nether_bricks
setblock 299 249 184 minecraft:polished_blackstone
setblock 300 249 183 minecraft:polished_blackstone
setblock 300 249 184 minecraft:red_nether_bricks
setblock 301 249 182 minecraft:polished_blackstone
fill 301 249 183 304 249 183 minecraft:red_nether_bricks
fill 302 249 182 302 251 182 minecraft:red_nether_bricks
setblock 305 249 183 minecraft:polished_blackstone
setblock 306 249 182 minecraft:polished_blackstone
setblock 306 249 183 minecraft:red_nether_bricks
setblock 306 249 222 minecraft:polished_blackstone
fill 307 249 182 307 252 182 minecraft:red_nether_bricks
fill 307 249 222 307 252 222 minecraft:red_nether_bricks
setblock 310 249 183 minecraft:polished_blackstone
setblock 310 249 184 minecraft:red_nether_bricks
setblock 311 249 182 minecraft:polished_blackstone
fill 311 249 183 311 251 183 minecraft:red_nether_bricks
setblock 311 249 222 minecraft:polished_blackstone
fill 312 249 182 312 252 182 minecraft:red_nether_bricks
setblock 312 249 221 minecraft:polished_blackstone
fill 312 249 222 312 252 222 minecraft:red_nether_bricks
fill 313 249 221 313 251 221 minecraft:red_nether_bricks
setblock 314 249 184 minecraft:polished_blackstone
setblock 315 249 183 minecraft:polished_blackstone
setblock 315 249 184 minecraft:red_nether_bricks
setblock 316 249 182 minecraft:polished_blackstone
setblock 316 249 183 minecraft:red_nether_bricks
setblock 316 249 222 minecraft:polished_blackstone
fill 317 249 182 317 250 182 minecraft:red_nether_bricks
setblock 317 249 221 minecraft:polished_blackstone
fill 317 249 222 317 250 222 minecraft:red_nether_bricks
setblock 321 249 207 minecraft:polished_blackstone
setblock 321 249 208 minecraft:red_nether_bricks
setblock 322 249 206 minecraft:polished_blackstone
fill 322 249 207 322 251 207 minecraft:red_nether_bricks
setblock 322 249 211 minecraft:polished_blackstone
fill 322 249 212 322 251 212 minecraft:red_nether_bricks
setblock 323 249 205 minecraft:polished_blackstone
fill 323 249 206 323 252 206 minecraft:red_nether_bricks
setblock 323 249 210 minecraft:polished_blackstone
fill 323 249 211 323 252 211 minecraft:red_nether_bricks
setblock 283 250 189 minecraft:polished_blackstone
fill 283 250 190 283 253 190 minecraft:red_nether_bricks
setblock 283 250 193 minecraft:red_nether_bricks
setblock 283 250 204 minecraft:polished_blackstone
fill 283 250 205 283 251 205 minecraft:red_nether_bricks
setblock 283 250 209 minecraft:polished_blackstone
fill 283 250 210 283 253 210 minecraft:red_nether_bricks
setblock 289 250 183 minecraft:polished_blackstone
setblock 290 250 182 minecraft:polished_blackstone
fill 290 250 183 290 253 183 minecraft:red_nether_bricks
fill 291 250 182 291 253 182 minecraft:red_nether_bricks
setblock 292 250 185 minecraft:polished_blackstone
fill 292 250 222 294 250 222 minecraft:red_nether_bricks
setblock 293 250 184 minecraft:polished_blackstone
fill 293 250 185 293 251 185 minecraft:red_nether_bricks
setblock 294 250 183 minecraft:polished_blackstone
fill 294 250 184 294 252 184 minecraft:red_nether_bricks
setblock 295 250 182 minecraft:polished_blackstone
fill 295 250 183 295 253 183 minecraft:red_nether_bricks
setblock 295 250 222 minecraft:polished_blackstone
fill 296 250 182 296 253 182 minecraft:red_nether_bricks
setblock 296 250 222 minecraft:red_nether_bricks
setblock 298 250 184 minecraft:polished_blackstone
setblock 299 250 183 minecraft:polished_blackstone
setblock 300 250 182 minecraft:polished_blackstone
fill 300 250 183 301 250 183 minecraft:red_nether_bricks
fill 301 250 182 301 251 182 minecraft:red_nether_bricks
setblock 305 250 182 minecraft:polished_blackstone
fill 306 250 182 306 252 182 minecraft:red_nether_bricks
setblock 309 250 183 minecraft:polished_blackstone
setblock 310 250 182 minecraft:polished_blackstone
fill 310 250 183 310 251 183 minecraft:red_nether_bricks
setblock 310 250 222 minecraft:polished_blackstone
fill 311 250 182 311 253 182 minecraft:red_nether_bricks
setblock 311 250 221 minecraft:polished_blackstone
fill 311 250 222 311 253 222 minecraft:red_nether_bricks
fill 312 250 221 312 253 221 minecraft:red_nether_bricks
setblock 314 250 183 minecraft:polished_blackstone
setblock 315 250 182 minecraft:polished_blackstone
setblock 315 250 183 minecraft:red_nether_bricks
setblock 315 250 222 minecraft:polished_blackstone
fill 316 250 182 316 251 182 minecraft:red_nether_bricks
fill 316 250 222 316 251 222 minecraft:red_nether_bricks
setblock 322 250 206 minecraft:red_nether_bricks
setblock 322 250 210 minecraft:polished_blackstone
fill 322 250 211 322 252 211 minecraft:red_nether_bricks
setblock 323 250 204 minecraft:polished_blackstone
fill 323 250 205 323 252 205 minecraft:red_nether_bricks
setblock 323 250 209 minecraft:polished_blackstone
fill 323 250 210 323 253 210 minecraft:red_nether_bricks
setblock 323 250 214 minecraft:polished_blackstone
setblock 283 251 188 minecraft:polished_blackstone
fill 283 251 189 283 254 189 minecraft:red_nether_bricks
setblock 283 251 193 minecraft:polished_blackstone
setblock 283 251 208 minecraft:polished_blackstone
fill 283 251 209 283 253 209 minecraft:red_nether_bricks
setblock 289 251 182 minecraft:polished_blackstone
fill 289 251 183 289 254 183 minecraft:red_nether_bricks
fill 290 251 182 290 254 182 minecraft:red_nether_bricks
setblock 292 251 184 minecraft:polished_blackstone
setblock 293 251 183 minecraft:polished_blackstone
fill 293 251 184 293 252 184 minecraft:red_nether_bricks
setblock 294 251 182 minecraft:polished_blackstone
fill 294 251 183 294 254 183 minecraft:red_nether_bricks
fill 295 251 182 295 254 182 minecraft:red_nether_bricks
setblock 298 251 183 minecraft:polished_blackstone
setblock 299 251 182 minecraft:polished_blackstone
setblock 300 251 182 minecraft:red_nether_bricks
setblock 304 251 182 minecraft:polished_blackstone
setblock 305 251 182 minecraft:red_nether_bricks
setblock 309 251 182 minecraft:polished_blackstone
setblock 309 251 183 minecraft:red_nether_bricks
setblock 309 251 222 minecraft:polished_blackstone
fill 310 251 182 310 254 182 minecraft:red_nether_bricks
setblock 310 251 221 minecraft:polished_blackstone
fill 310 251 222 310 254 222 minecraft:red_nether_bricks
fill 311 251 221 311 254 221 minecraft:red_nether_bricks
setblock 313 251 183 minecraft:polished_blackstone
setblock 314 251 182 minecraft:polished_blackstone
setblock 314 251 222 minecraft:polished_blackstone
setblock 315 251 182 minecraft:red_nether_bricks
fill 315 251 222 315 252 222 minecraft:red_nether_bricks
setblock 322 251 209 minecraft:polished_blackstone
fill 322 251 210 322 252 210 minecraft:red_nether_bricks
setblock 323 251 204 minecraft:red_nether_bricks
setblock 323 251 208 minecraft:polished_blackstone
fill 323 251 209 323 254 209 minecraft:red_nether_bricks
setblock 323 251 213 minecraft:polished_blackstone
fill 323 251 214 323 254 214 minecraft:red_nether_bricks
setblock 283 252 187 minecraft:polished_blackstone
fill 283 252 188 283 255 188 minecraft:red_nether_bricks
setblock 283 252 192 minecraft:polished_blackstone
fill 283 252 193 283 254 194 minecraft:red_nether_bricks
setblock 283 252 207 minecraft:polished_blackstone
fill 283 252 208 283 253 208 minecraft:red_nether_bricks
setblock 284 252 190 minecraft:red_nether_bricks
setblock 285 252 184 minecraft:light[level=14]
setblock 285 252 192 minecraft:light[level=14]
setblock 285 252 200 minecraft:light[level=14]
setblock 285 252 208 minecraft:light[level=14]
setblock 285 252 216 minecraft:light[level=14]
setblock 288 252 182 minecraft:polished_blackstone
fill 289 252 182 289 255 182 minecraft:red_nether_bricks
setblock 291 252 184 minecraft:polished_blackstone
setblock 292 252 183 minecraft:polished_blackstone
fill 292 252 184 292 253 184 minecraft:red_nether_bricks
setblock 293 252 182 minecraft:polished_blackstone
fill 293 252 183 293 255 183 minecraft:red_nether_bricks
setblock 293 252 192 minecraft:light[level=14]
setblock 293 252 200 minecraft:light[level=14]
setblock 293 252 208 minecraft:light[level=14]
setblock 293 252 216 minecraft:light[level=14]
fill 294 252 182 294 255 182 minecraft:red_nether_bricks
setblock 297 252 183 minecraft:polished_blackstone
setblock 298 252 182 minecraft:polished_blackstone
setblock 299 252 182 minecraft:red_nether_bricks
setblock 301 252 184 minecraft:light[level=14]
setblock 301 252 192 minecraft:light[level=14]
setblock 301 252 200 minecraft:light[level=14]
setblock 301 252 208 minecraft:light[level=14]
setblock 301 252 216 minecraft:light[level=14]
setblock 308 252 182 minecraft:polished_blackstone
setblock 308 252 222 minecraft:polished_blackstone
fill 309 252 182 309 255 182 minecraft:red_nether_bricks
setblock 309 252 184 minecraft:light[level=14]
setblock 309 252 192 minecraft:light[level=14]
setblock 309 252 200 minecraft:light[level=14]
setblock 309 252 208 minecraft:light[level=14]
setblock 309 252 216 minecraft:light[level=14]
fill 309 252 222 309 255 222 minecraft:red_nether_bricks
setblock 313 252 182 minecraft:polished_blackstone
setblock 313 252 222 minecraft:polished_blackstone
setblock 314 252 182 minecraft:red_nether_bricks
fill 314 252 222 314 255 222 minecraft:red_nether_bricks
setblock 317 252 184 minecraft:light[level=14]
setblock 317 252 192 minecraft:light[level=14]
setblock 317 252 200 minecraft:light[level=14]
setblock 317 252 208 minecraft:light[level=14]
setblock 317 252 216 minecraft:light[level=14]
setblock 322 252 209 minecraft:red_nether_bricks
setblock 323 252 207 minecraft:polished_blackstone
fill 323 252 208 323 255 208 minecraft:red_nether_bricks
setblock 323 252 212 minecraft:polished_blackstone
fill 323 252 213 323 255 213 minecraft:red_nether_bricks
fill 283 253 187 283 256 187 minecraft:red_nether_bricks
setblock 283 253 191 minecraft:polished_blackstone
fill 283 253 192 284 255 192 minecraft:red_nether_bricks
setblock 283 253 195 minecraft:red_nether_bricks
setblock 283 253 211 minecraft:polished_blackstone
setblock 284 253 189 minecraft:red_nether_bricks
setblock 284 253 190 minecraft:polished_blackstone
fill 284 253 191 284 256 191 minecraft:red_nether_bricks
fill 288 253 182 288 256 182 minecraft:red_nether_bricks
setblock 291 253 183 minecraft:polished_blackstone
setblock 292 253 182 minecraft:polished_blackstone
fill 292 253 183 292 256 183 minecraft:red_nether_bricks
fill 293 253 182 293 256 182 minecraft:red_nether_bricks
setblock 297 253 182 minecraft:polished_blackstone
setblock 307 253 182 minecraft:polished_blackstone
setblock 307 253 222 minecraft:polished_blackstone
fill 308 253 182 308 256 182 minecraft:red_nether_bricks
fill 308 253 222 308 256 222 minecraft:red_nether_bricks
fill 310 253 221 310 255 221 minecraft:red_nether_bricks
setblock 312 253 182 minecraft:polished_blackstone
setblock 312 253 222 minecraft:polished_blackstone
setblock 313 253 182 minecraft:red_nether_bricks
fill 313 253 222 313 256 222 minecraft:red_nether_bricks
setblock 323 253 206 minecraft:polished_blackstone
fill 323 253 207 323 256 207 minecraft:red_nether_bricks
setblock 323 253 211 minecraft:polished_blackstone
fill 323 253 212 323 256 212 minecraft:red_nether_bricks
setblock 283 254 190 minecraft:polished_blackstone
fill 283 254 191 283 257 191 minecraft:red_nether_bricks
setblock 283 254 195 minecraft:polished_blackstone
fill 283 254 196 283 257 196 minecraft:red_nether_bricks
setblock 283 254 210 minecraft:polished_blackstone
fill 283 254 211 283 257 211 minecraft:red_nether_bricks
setblock 284 254 188 minecraft:red_nether_bricks
setblock 284 254 189 minecraft:polished_blackstone
fill 284 254 190 284 257 190 minecraft:red_nether_bricks
setblock 284 254 193 minecraft:red_nether_bricks
setblock 284 254 194 minecraft:polished_blackstone
setblock 290 254 183 minecraft:polished_blackstone
setblock 291 254 182 minecraft:polished_blackstone
fill 291 254 183 291 257 183 minecraft:red_nether_bricks
fill 292 254 182 292 257 182 minecraft:red_nether_bricks
setblock 296 254 182 minecraft:polished_blackstone
setblock 306 254 222 minecraft:polished_blackstone
fill 307 254 182 307 257 182 minecraft:red_nether_bricks
fill 307 254 222 307 257 222 minecraft:red_nether_bricks
fill 309 254 221 309 256 221 minecraft:red_nether_bricks
setblock 311 254 182 minecraft:polished_blackstone
setblock 311 254 222 minecraft:polished_blackstone
setblock 312 254 182 minecraft:red_nether_bricks
setblock 312 254 221 minecraft:polished_blackstone
fill 312 254 222 312 257 222 minecraft:red_nether_bricks
fill 323 254 192 323 256 192 minecraft:red_nether_bricks
fill 323 254 206 323 257 206 minecraft:red_nether_bricks
setblock 323 254 210 minecraft:polished_blackstone
fill 323 254 211 323 257 211 minecraft:red_nether_bricks
setblock 323 254 215 minecraft:polished_blackstone
fill 283 255 186 283 257 186 minecraft:red_nether_bricks
setblock 283 255 189 minecraft:polished_blackstone
fill 283 255 190 283 258 190 minecraft:red_nether_bricks
setblock 283 255 193 minecraft:red_nether_bricks
setblock 283 255 194 minecraft:polished_blackstone
fill 283 255 195 284 257 195 minecraft:red_nether_bricks
fill 283 255 197 283 255 198 minecraft:red_nether_bricks
fill 283 255 210 283 258 210 minecraft:red_nether_bricks
fill 283 255 212 283 256 212 minecraft:red_nether_bricks
setblock 284 255 188 minecraft:polished_blackstone
fill 284 255 189 285 257 189 minecraft:red_nether_bricks
setblock 284 255 193 minecraft:polished_blackstone
fill 284 255 194 284 258 194 minecraft:red_nether_bricks
fill 284 255 196 284 256 196 minecraft:red_nether_bricks
fill 285 255 190 285 255 191 minecraft:red_nether_bricks
setblock 285 255 192 minecraft:polished_blackstone
fill 285 255 193 285 258 193 minecraft:red_nether_bricks
fill 287 255 182 287 257 182 minecraft:red_nether_bricks
setblock 289 255 183 minecraft:polished_blackstone
setblock 290 255 182 minecraft:polished_blackstone
fill 290 255 183 290 258 183 minecraft:red_nether_bricks
fill 291 255 182 291 258 182 minecraft:red_nether_bricks
setblock 295 255 182 minecraft:polished_blackstone
fill 296 255 182 296 258 182 minecraft:red_nether_bricks
setblock 305 255 222 minecraft:polished_blackstone
fill 306 255 222 306 258 222 minecraft:red_nether_bricks
fill 307 255 221 308 257 221 minecraft:red_nether_bricks
setblock 310 255 182 minecraft:polished_blackstone
setblock 310 255 222 minecraft:polished_blackstone
fill 311 255 182 311 258 182 minecraft:red_nether_bricks
setblock 311 255 221 minecraft:polished_blackstone
fill 311 255 222 311 258 222 minecraft:red_nether_bricks
fill 312 255 221 312 258 221 minecraft:red_nether_bricks
fill 322 255 211 322 257 212 minecraft:red_nether_bricks
fill 323 255 190 323 257 191 minecraft:red_nether_bricks
setblock 323 255 193 minecraft:red_nether_bricks
setblock 323 255 194 minecraft:polished_blackstone
fill 323 255 195 323 257 196 minecraft:red_nether_bricks
setblock 323 255 209 minecraft:polished_blackstone
fill 323 255 210 323 258 210 minecraft:red_nether_bricks
setblock 323 255 214 minecraft:polished_blackstone
fill 323 255 215 323 257 216 minecraft:red_nether_bricks
setblock 283 256 188 minecraft:polished_blackstone
fill 283 256 189 283 259 189 minecraft:red_nether_bricks
setblock 283 256 192 minecraft:red_nether_bricks
setblock 283 256 193 minecraft:polished_blackstone
fill 283 256 194 283 259 194 minecraft:red_nether_bricks
setblock 283 256 197 minecraft:red_nether_bricks
setblock 283 256 198 minecraft:polished_blackstone
fill 283 256 199 283 259 199 minecraft:red_nether_bricks
fill 283 256 209 283 259 209 minecraft:red_nether_bricks
setblock 283 256 213 minecraft:polished_blackstone
fill 283 256 214 283 259 214 minecraft:red_nether_bricks
setblock 284 256 187 minecraft:polished_blackstone
fill 284 256 188 284 259 188 minecraft:red_nether_bricks
setblock 284 256 192 minecraft:polished_blackstone
fill 284 256 193 284 259 193 minecraft:red_nether_bricks
setblock 284 256 197 minecraft:polished_blackstone
setblock 285 256 190 minecraft:red_nether_bricks
setblock 285 256 191 minecraft:polished_blackstone
fill 285 256 192 286 258 192 minecraft:red_nether_bricks
fill 285 256 194 285 256 195 minecraft:red_nether_bricks
fill 286 256 182 286 258 182 minecraft:red_nether_bricks
fill 286 256 191 286 259 191 minecraft:red_nether_bricks
fill 286 256 193 286 257 193 minecraft:red_nether_bricks
setblock 288 256 183 minecraft:polished_blackstone
setblock 289 256 182 minecraft:polished_blackstone
fill 289 256 183 289 259 183 minecraft:red_nether_bricks
setblock 289 256 222 minecraft:polished_blackstone
fill 290 256 182 290 259 182 minecraft:red_nether_bricks
fill 290 256 222 293 256 222 minecraft:red_nether_bricks
setblock 293 256 183 minecraft:polished_blackstone
setblock 294 256 182 minecraft:polished_blackstone
fill 295 256 182 295 259 182 minecraft:red_nether_bricks
setblock 303 256 222 minecraft:red_nether_bricks
setblock 304 256 222 minecraft:polished_blackstone
fill 305 256 222 305 259 222 minecraft:red_nether_bricks
fill 306 256 182 306 258 182 minecraft:red_nether_bricks
fill 306 256 221 306 259 221 minecraft:red_nether_bricks
fill 308 256 220 310 256 220 minecraft:red_nether_bricks
setblock 309 256 182 minecraft:polished_blackstone
setblock 309 256 222 minecraft:polished_blackstone
fill 310 256 182 310 259 182 minecraft:red_nether_bricks
setblock 310 256 221 minecraft:polished_blackstone
fill 310 256 222 310 259 222 minecraft:red_nether_bricks
fill 311 256 221 311 259 221 minecraft:red_nether_bricks
setblock 314 256 222 minecraft:polished_blackstone
setblock 322 256 213 minecraft:red_nether_bricks
fill 323 256 189 323 259 189 minecraft:red_nether_bricks
setblock 323 256 193 minecraft:polished_blackstone
fill 323 256 194 323 259 194 minecraft:red_nether_bricks
setblock 323 256 197 minecraft:red_nether_bricks
setblock 323 256 198 minecraft:polished_blackstone
fill 323 256 199 323 259 199 minecraft:red_nether_bricks
fill 323 256 205 323 258 205 minecraft:red_nether_bricks
setblock 323 256 208 minecraft:polished_blackstone
fill 323 256 209 323 259 209 minecraft:red_nether_bricks
setblock 323 256 213 minecraft:polished_blackstone
fill 323 256 214 323 259 214 minecraft:red_nether_bricks
setblock 323 256 217 minecraft:red_nether_bricks
fill 283 257 185 283 258 185 minecraft:red_nether_bricks
setblock 283 257 187 minecraft:polished_blackstone
fill 283 257 188 283 260 188 minecraft:red_nether_bricks
setblock 283 257 192 minecraft:polished_blackstone
fill 283 257 193 283 260 193 minecraft:red_nether_bricks
setblock 283 257 197 minecraft:polished_blackstone
fill 283 257 198 284 259 198 minecraft:red_nether_bricks
fill 283 257 200 283 257 201 minecraft:red_nether_bricks
setblock 283 257 212 minecraft:polished_blackstone
fill 283 257 213 283 260 213 minecraft:red_nether_bricks
fill 283 257 215 283 257 216 minecraft:red_nether_bricks
fill 284 257 187 284 260 187 minecraft:red_nether_bricks
setblock 284 257 191 minecraft:polished_blackstone
fill 284 257 192 284 260 192 minecraft:red_nether_bricks
setblock 284 257 196 minecraft:polished_blackstone
fill 284 257 197 285 259 197 minecraft:red_nether_bricks
fill 284 257 199 284 258 199 minecraft:red_nether_bricks
fill 285 257 182 285 259 182 minecraft:red_nether_bricks
fill 285 257 188 285 258 188 minecraft:red_nether_bricks
setblock 285 257 190 minecraft:polished_blackstone
fill 285 257 191 285 260 191 minecraft:red_nether_bricks
setblock 285 257 194 minecraft:red_nether_bricks
setblock 285 257 195 minecraft:polished_blackstone
fill 285 257 196 285 260 196 minecraft:red_nether_bricks
fill 286 257 190 286 260 190 minecraft:red_nether_bricks
setblock 286 257 194 minecraft:polished_blackstone
fill 286 257 195 286 260 195 minecraft:red_nether_bricks
setblock 287 257 183 minecraft:polished_blackstone
setblock 287 257 193 minecraft:magma_block
setblock 287 257 222 minecraft:red_nether_bricks
setblock 288 257 182 minecraft:polished_blackstone
fill 288 257 183 288 260 183 minecraft:red_nether_bricks
setblock 288 257 222 minecraft:polished_blackstone
fill 289 257 182 289 260 182 minecraft:red_nether_bricks
fill 289 257 222 292 257 222 minecraft:red_nether_bricks
setblock 292 257 183 minecraft:polished_blackstone
setblock 293 257 182 minecraft:polished_blackstone
fill 293 257 183 293 259 183 minecraft:red_nether_bricks
setblock 293 257 222 minecraft:polished_blackstone
fill 294 257 182 294 260 182 minecraft:red_nether_bricks
fill 294 257 222 295 259 222 minecraft:red_nether_bricks
setblock 302 257 222 minecraft:red_nether_bricks
setblock 303 257 222 minecraft:polished_blackstone
setblock 304 257 221 minecraft:polished_blackstone
fill 304 257 222 304 260 222 minecraft:red_nether_bricks
fill 305 257 182 305 259 182 minecraft:red_nether_bricks
fill 305 257 221 305 260 221 minecraft:red_nether_bricks
fill 306 257 220 309 257 220 minecraft:red_nether_bricks
setblock 308 257 182 minecraft:polished_blackstone
setblock 308 257 222 minecraft:polished_blackstone
fill 309 257 182 309 260 182 minecraft:red_nether_bricks
setblock 309 257 221 minecraft:polished_blackstone
fill 309 257 222 309 260 222 minecraft:red_nether_bricks
setblock 310 257 220 minecraft:polished_blackstone
fill 310 257 221 310 260 221 minecraft:red_nether_bricks
fill 311 257 220 311 260 220 minecraft:red_nether_bricks
setblock 313 257 221 minecraft:red_nether_bricks
setblock 313 257 222 minecraft:polished_blackstone
fill 314 257 222 314 260 222 minecraft:red_nether_bricks
setblock 322 257 193 minecraft:polished_blackstone
fill 322 257 194 322 259 195 minecraft:red_nether_bricks
fill 322 257 210 322 259 210 minecraft:red_nether_bricks
setblock 322 257 213 minecraft:polished_blackstone
fill 322 257 214 322 259 215 minecraft:red_nether_bricks
fill 323 257 188 323 260 188 minecraft:red_nether_bricks
setblock 323 257 192 minecraft:polished_blackstone
fill 323 257 193 323 260 193 minecraft:red_nether_bricks
setblock 323 257 197 minecraft:polished_blackstone
fill 323 257 198 323 260 198 minecraft:red_nether_bricks
fill 323 257 200 323 257 201 minecraft:red_nether_bricks
setblock 323 257 202 minecraft:polished_blackstone
fill 323 257 203 323 259 204 minecraft:red_nether_bricks
setblock 323 257 207 minecraft:polished_blackstone
fill 323 257 208 323 260 208 minecraft:red_nether_bricks
setblock 323 257 212 minecraft:polished_blackstone
fill 323 257 213 323 260 213 minecraft:red_nether_bricks
setblock 323 257 217 minecraft:polished_blackstone
fill 323 257 218 323 260 218 minecraft:red_nether_bricks
fill 283 258 184 283 259 184 minecraft:red_nether_bricks
setblock 283 258 186 minecraft:polished_blackstone
fill 283 258 187 283 261 187 minecraft:red_nether_bricks
setblock 283 258 191 minecraft:polished_blackstone
fill 283 258 192 283 261 192 minecraft:red_nether_bricks
setblock 283 258 195 minecraft:red_nether_bricks
setblock 283 258 196 minecraft:polished_blackstone
fill 283 258 197 283 261 197 minecraft:red_nether_bricks
setblock 283 258 200 minecraft:red_nether_bricks
setblock 283 258 201 minecraft:polished_blackstone
fill 283 258 202 283 260 203 minecraft:red_nether_bricks
fill 283 258 208 283 260 208 minecraft:red_nether_bricks
setblock 283 258 211 minecraft:polished_blackstone
fill 283 258 212 283 261 212 minecraft:red_nether_bricks
setblock 283 258 215 minecraft:red_nether_bricks
setblock 283 258 216 minecraft:polished_blackstone
fill 283 258 217 283 260 218 minecraft:red_nether_bricks
fill 284 258 182 284 260 182 minecraft:red_nether_bricks
fill 284 258 186 284 261 186 minecraft:red_nether_bricks
setblock 284 258 189 minecraft:red_nether_bricks
setblock 284 258 190 minecraft:polished_blackstone
fill 284 258 191 284 261 191 minecraft:red_nether_bricks
setblock 284 258 195 minecraft:polished_blackstone
fill 284 258 196 284 261 196 minecraft:red_nether_bricks
setblock 284 258 200 minecraft:polished_blackstone
fill 284 258 213 284 258 214 minecraft:red_nether_bricks
setblock 284 258 215 minecraft:polished_blackstone
fill 285 258 187 285 259 187 minecraft:red_nether_bricks
setblock 285 258 189 minecraft:polished_blackstone
fill 285 258 190 285 261 190 minecraft:red_nether_bricks
setblock 285 258 194 minecraft:polished_blackstone
fill 285 258 195 285 261 195 minecraft:red_nether_bricks
setblock 285 258 198 minecraft:red_nether_bricks
fill 285 258 222 286 258 222 minecraft:red_nether_bricks
setblock 286 258 183 minecraft:polished_blackstone
fill 286 258 189 286 261 189 minecraft:red_nether_bricks
setblock 286 258 193 minecraft:polished_blackstone
fill 286 258 194 286 261 194 minecraft:red_nether_bricks
fill 286 258 196 286 259 196 minecraft:red_nether_bricks
setblock 287 258 182 minecraft:polished_blackstone
fill 287 258 183 287 261 183 minecraft:red_nether_bricks
setblock 287 258 222 minecraft:polished_blackstone
fill 288 258 182 288 261 182 minecraft:red_nether_bricks
setblock 288 258 221 minecraft:polished_blackstone
fill 288 258 222 291 258 222 minecraft:red_nether_bricks
fill 289 258 221 292 258 221 minecraft:red_nether_bricks
setblock 291 258 183 minecraft:polished_blackstone
setblock 292 258 182 minecraft:polished_blackstone
fill 292 258 183 292 261 183 minecraft:red_nether_bricks
setblock 292 258 222 minecraft:polished_blackstone
fill 293 258 182 293 261 182 minecraft:red_nether_bricks
fill 293 258 222 293 261 222 minecraft:red_nether_bricks
setblock 296 258 222 minecraft:red_nether_bricks
setblock 297 258 222 minecraft:polished_blackstone
fill 298 258 222 301 258 222 minecraft:red_nether_bricks
setblock 302 258 221 minecraft:red_nether_bricks
setblock 302 258 222 minecraft:polished_blackstone
fill 303 258 182 304 260 182 minecraft:red_nether_bricks
setblock 303 258 221 minecraft:polished_blackstone
fill 303 258 222 303 261 222 minecraft:red_nether_bricks
setblock 304 258 220 minecraft:polished_blackstone
fill 304 258 221 304 261 221 minecraft:red_nether_bricks
fill 305 258 220 308 258 220 minecraft:red_nether_bricks
fill 306 258 219 309 258 219 minecraft:red_nether_bricks
setblock 307 258 182 minecraft:polished_blackstone
setblock 307 258 221 minecraft:red_nether_bricks
setblock 307 258 222 minecraft:polished_blackstone
fill 308 258 182 308 261 182 minecraft:red_nether_bricks
setblock 308 258 221 minecraft:polished_blackstone
fill 308 258 222 308 261 222 minecraft:red_nether_bricks
setblock 309 258 220 minecraft:polished_blackstone
fill 309 258 221 309 261 221 minecraft:red_nether_bricks
setblock 310 258 219 minecraft:polished_blackstone
fill 310 258 220 310 261 220 minecraft:red_nether_bricks
fill 312 258 220 312 259 220 minecraft:red_nether_bricks
setblock 312 258 222 minecraft:polished_blackstone
setblock 313 258 221 minecraft:polished_blackstone
fill 313 258 222 313 261 222 minecraft:red_nether_bricks
setblock 322 258 191 minecraft:red_nether_bricks
setblock 322 258 192 minecraft:polished_blackstone
fill 322 258 193 322 261 193 minecraft:red_nether_bricks
setblock 322 258 196 minecraft:red_nether_bricks
setblock 322 258 197 minecraft:polished_blackstone
fill 322 258 198 322 260 199 minecraft:red_nether_bricks
setblock 322 258 211 minecraft:red_nether_bricks
setblock 322 258 212 minecraft:polished_blackstone
fill 322 258 213 322 261 213 minecraft:red_nether_bricks
setblock 322 258 216 minecraft:red_nether_bricks
setblock 323 258 190 minecraft:red_nether_bricks
setblock 323 258 191 minecraft:polished_blackstone
fill 323 258 192 323 261 192 minecraft:red_nether_bricks
setblock 323 258 195 minecraft:red_nether_bricks
setblock 323 258 196 minecraft:polished_blackstone
fill 323 258 197 323 261 197 minecraft:red_nether_bricks
setblock 323 258 200 minecraft:red_nether_bricks
setblock 323 258 201 minecraft:polished_blackstone
fill 323 258 202 323 261 202 minecraft:red_nether_bricks
setblock 323 258 206 minecraft:polished_blackstone
fill 323 258 207 323 261 207 minecraft:red_nether_bricks
setblock 323 258 211 minecraft:polished_blackstone
fill 323 258 212 323 261 212 minecraft:red_nether_bricks
setblock 323 258 215 minecraft:red_nether_bricks
setblock 323 258 216 minecraft:polished_blackstone
fill 323 258 217 323 261 217 minecraft:red_nether_bricks
fill 323 258 219 323 259 219 minecraft:red_nether_bricks
fill 283 259 182 283 260 183 minecraft:red_nether_bricks
setblock 283 259 185 minecraft:polished_blackstone
fill 283 259 186 283 262 186 minecraft:red_nether_bricks
setblock 283 259 190 minecraft:polished_blackstone
fill 283 259 191 283 262 191 minecraft:red_nether_bricks
setblock 283 259 195 minecraft:polished_blackstone
fill 283 259 196 283 262 196 minecraft:red_nether_bricks
setblock 283 259 200 minecraft:polished_blackstone
fill 283 259 201 284 261 201 minecraft:red_nether_bricks
setblock 283 259 204 minecraft:red_nether_bricks
setblock 283 259 205 minecraft:polished_blackstone
setblock 283 259 210 minecraft:polished_blackstone
fill 283 259 211 283 262 211 minecraft:red_nether_bricks
setblock 283 259 215 minecraft:polished_blackstone
fill 283 259 216 284 261 216 minecraft:red_nether_bricks
setblock 283 259 219 minecraft:red_nether_bricks
setblock 283 259 220 minecraft:polished_blackstone
fill 283 259 221 283 262 221 minecraft:red_nether_bricks
fill 284 259 185 284 262 185 minecraft:red_nether_bricks
setblock 284 259 189 minecraft:polished_blackstone
fill 284 259 190 284 262 190 minecraft:red_nether_bricks
setblock 284 259 194 minecraft:polished_blackstone
fill 284 259 195 284 262 195 minecraft:red_nether_bricks
setblock 284 259 199 minecraft:polished_blackstone
fill 284 259 200 284 262 200 minecraft:red_nether_bricks
fill 284 259 212 284 259 213 minecraft:red_nether_bricks
setblock 284 259 214 minecraft:polished_blackstone
fill 284 259 215 284 262 215 minecraft:red_nether_bricks
fill 284 259 217 284 259 218 minecraft:red_nether_bricks
fill 284 259 222 285 259 222 minecraft:red_nether_bricks
setblock 285 259 183 minecraft:polished_blackstone
setblock 285 259 188 minecraft:polished_blackstone
fill 285 259 189 285 262 189 minecraft:red_nether_bricks
setblock 285 259 192 minecraft:red_nether_bricks
setblock 285 259 193 minecraft:polished_blackstone
fill 285 259 194 285 262 194 minecraft:red_nether_bricks
setblock 285 259 198 minecraft:polished_blackstone
fill 285 259 199 285 262 199 minecraft:red_nether_bricks
setblock 286 259 182 minecraft:polished_blackstone
fill 286 259 183 286 262 183 minecraft:red_nether_bricks
setblock 286 259 192 minecraft:polished_blackstone
fill 286 259 193 287 260 193 minecraft:red_nether_bricks
setblock 286 259 197 minecraft:polished_blackstone
setblock 286 259 221 minecraft:red_nether_bricks
setblock 286 259 222 minecraft:polished_blackstone
fill 287 259 182 287 262 182 minecraft:red_nether_bricks
fill 287 259 192 287 260 192 minecraft:red_nether_bricks
fill 287 259 194 287 260 194 minecraft:red_nether_bricks
setblock 287 259 221 minecraft:polished_blackstone
fill 287 259 222 290 259 222 minecraft:red_nether_bricks
setblock 288 259 184 minecraft:red_nether_bricks
fill 288 259 221 291 259 221 minecraft:red_nether_bricks
setblock 289 259 184 minecraft:polished_blackstone
setblock 290 259 183 minecraft:polished_blackstone
setblock 291 259 182 minecraft:polished_blackstone
fill 291 259 183 291 262 183 minecraft:red_nether_bricks
setblock 291 259 222 minecraft:polished_blackstone
fill 292 259 182 292 262 182 minecraft:red_nether_bricks
setblock 292 259 221 minecraft:polished_blackstone
fill 292 259 222 292 262 222 minecraft:red_nether_bricks
fill 293 259 221 294 261 221 minecraft:red_nether_bricks
setblock 296 259 182 minecraft:polished_blackstone
setblock 296 259 222 minecraft:polished_blackstone
fill 297 259 222 300 259 222 minecraft:red_nether_bricks
fill 300 259 221 301 259 221 minecraft:red_nether_bricks
setblock 301 259 222 minecraft:polished_blackstone
fill 302 259 182 302 262 182 minecraft:red_nether_bricks
setblock 302 259 221 minecraft:polished_blackstone
fill 302 259 222 302 262 222 minecraft:red_nether_bricks
setblock 303 259 220 minecraft:polished_blackstone
fill 303 259 221 303 262 221 minecraft:red_nether_bricks
fill 304 259 220 307 259 220 minecraft:red_nether_bricks
fill 305 259 219 308 259 219 minecraft:red_nether_bricks
setblock 306 259 182 minecraft:polished_blackstone
setblock 306 259 222 minecraft:polished_blackstone
fill 307 259 182 307 262 182 minecraft:red_nether_bricks
setblock 307 259 221 minecraft:polished_blackstone
fill 307 259 222 307 262 222 minecraft:red_nether_bricks
fill 308 259 218 308 260 218 minecraft:red_nether_bricks
setblock 308 259 220 minecraft:polished_blackstone
fill 308 259 221 308 262 221 minecraft:red_nether_bricks
setblock 309 259 219 minecraft:polished_blackstone
fill 309 259 220 309 262 220 minecraft:red_nether_bricks
fill 310 259 219 311 261 219 minecraft:red_nether_bricks
setblock 311 259 182 minecraft:polished_blackstone
setblock 311 259 222 minecraft:polished_blackstone
setblock 312 259 221 minecraft:polished_blackstone
fill 312 259 222 312 262 222 minecraft:red_nether_bricks
fill 313 259 221 313 262 221 minecraft:red_nether_bricks
setblock 315 259 222 minecraft:red_nether_bricks
setblock 322 259 190 minecraft:red_nether_bricks
setblock 322 259 191 minecraft:polished_blackstone
fill 322 259 192 322 262 192 minecraft:red_nether_bricks
setblock 322 259 196 minecraft:polished_blackstone
fill 322 259 197 322 262 197 minecraft:red_nether_bricks
setblock 322 259 200 minecraft:red_nether_bricks
setblock 322 259 201 minecraft:polished_blackstone
setblock 322 259 211 minecraft:polished_blackstone
fill 322 259 212 322 262 212 minecraft:red_nether_bricks
setblock 322 259 216 minecraft:polished_blackstone
fill 322 259 217 322 262 217 minecraft:red_nether_bricks
fill 323 259 187 323 261 187 minecraft:red_nether_bricks
setblock 323 259 190 minecraft:polished_blackstone
fill 323 259 191 323 262 191 minecraft:red_nether_bricks
setblock 323 259 195 minecraft:polished_blackstone
fill 323 259 196 323 262 196 minecraft:red_nether_bricks
setblock 323 259 200 minecraft:polished_blackstone
fill 323 259 201 323 262 201 minecraft:red_nether_bricks
setblock 323 259 205 minecraft:polished_blackstone
fill 323 259 206 323 262 206 minecraft:red_nether_bricks
setblock 323 259 210 minecraft:polished_blackstone
fill 323 259 211 323 262 211 minecraft:red_nether_bricks
setblock 323 259 215 minecraft:polished_blackstone
fill 323 259 216 323 262 216 minecraft:red_nether_bricks
setblock 323 259 220 minecraft:polished_blackstone
setblock 283 260 184 minecraft:polished_blackstone
fill 283 260 185 283 263 185 minecraft:red_nether_bricks
setblock 283 260 189 minecraft:polished_blackstone
fill 283 260 190 283 263 190 minecraft:red_nether_bricks
setblock 283 260 194 minecraft:polished_blackstone
fill 283 260 195 283 263 195 minecraft:red_nether_bricks
setblock 283 260 198 minecraft:red_nether_bricks
setblock 283 260 199 minecraft:polished_blackstone
fill 283 260 200 283 263 200 minecraft:red_nether_bricks
setblock 283 260 204 minecraft:polished_blackstone
fill 283 260 205 283 261 207 minecraft:red_nether_bricks
setblock 283 260 209 minecraft:polished_blackstone
fill 283 260 210 283 262 210 minecraft:red_nether_bricks
setblock 283 260 214 minecraft:polished_blackstone
fill 283 260 215 283 263 215 minecraft:red_nether_bricks
setblock 283 260 219 minecraft:polished_blackstone
fill 283 260 220 284 262 220 minecraft:red_nether_bricks
fill 283 260 222 284 260 222 minecraft:red_nether_bricks
setblock 284 260 183 minecraft:polished_blackstone
fill 284 260 184 284 263 184 minecraft:red_nether_bricks
setblock 284 260 188 minecraft:polished_blackstone
fill 284 260 189 284 263 189 minecraft:red_nether_bricks
setblock 284 260 193 minecraft:polished_blackstone
fill 284 260 194 284 263 194 minecraft:red_nether_bricks
setblock 284 260 197 minecraft:red_nether_bricks
setblock 284 260 198 minecraft:polished_blackstone
fill 284 260 199 284 263 199 minecraft:red_nether_bricks
setblock 284 260 202 minecraft:red_nether_bricks
setblock 284 260 212 minecraft:red_nether_bricks
setblock 284 260 213 minecraft:polished_blackstone
fill 284 260 214 284 263 214 minecraft:red_nether_bricks
setblock 284 260 217 minecraft:red_nether_bricks
setblock 284 260 218 minecraft:polished_blackstone
fill 284 260 219 284 263 219 minecraft:red_nether_bricks
fill 284 260 221 285 260 221 minecraft:red_nether_bricks
setblock 285 260 182 minecraft:polished_blackstone
fill 285 260 183 285 263 183 minecraft:red_nether_bricks
setblock 285 260 184 minecraft:light[level=14]
setblock 285 260 186 minecraft:red_nether_bricks
setblock 285 260 187 minecraft:polished_blackstone
fill 285 260 188 285 263 188 minecraft:red_nether_bricks
setblock 285 260 192 minecraft:polished_blackstone
fill 285 260 193 285 263 193 minecraft:red_nether_bricks
setblock 285 260 197 minecraft:polished_blackstone
fill 285 260 198 286 262 198 minecraft:red_nether_bricks
fill 285 260 200 285 261 200 minecraft:red_nether_bricks
setblock 285 260 208 minecraft:light[level=14]
setblock 285 260 216 minecraft:light[level=14]
setblock 285 260 222 minecraft:polished_blackstone
fill 286 260 182 286 263 182 minecraft:red_nether_bricks
setblock 286 260 191 minecraft:polished_blackstone
fill 286 260 192 286 263 192 minecraft:red_nether_bricks
setblock 286 260 196 minecraft:polished_blackstone
fill 286 260 197 286 263 197 minecraft:red_nether_bricks
setblock 286 260 221 minecraft:polished_blackstone
fill 286 260 222 289 260 222 minecraft:red_nether_bricks
setblock 287 260 184 minecraft:red_nether_bricks
setblock 287 260 195 minecraft:polished_blackstone
setblock 287 260 220 minecraft:polished_blackstone
fill 287 260 221 290 260 221 minecraft:red_nether_bricks
setblock 288 260 184 minecraft:polished_blackstone
fill 288 260 220 291 260 220 minecraft:red_nether_bricks
setblock 289 260 183 minecraft:polished_blackstone
setblock 289 260 184 minecraft:red_nether_bricks
setblock 290 260 182 minecraft:polished_blackstone
fill 290 260 183 290 263 183 minecraft:red_nether_bricks
setblock 290 260 222 minecraft:polished_blackstone
fill 291 260 182 291 263 182 minecraft:red_nether_bricks
setblock 291 260 221 minecraft:polished_blackstone
fill 291 260 222 291 263 222 minecraft:red_nether_bricks
fill 292 260 221 292 263 221 minecraft:red_nether_bricks
setblock 293 260 184 minecraft:light[level=14]
setblock 293 260 192 minecraft:light[level=14]
setblock 293 260 200 minecraft:light[level=14]
setblock 293 260 208 minecraft:light[level=14]
setblock 293 260 216 minecraft:light[level=14]
setblock 294 260 222 minecraft:red_nether_bricks
setblock 295 260 182 minecraft:polished_blackstone
setblock 295 260 221 minecraft:red_nether_bricks
setblock 295 260 222 minecraft:polished_blackstone
fill 296 260 182 297 262 182 minecraft:red_nether_bricks
setblock 296 260 221 minecraft:polished_blackstone
fill 296 260 222 299 260 222 minecraft:red_nether_bricks
fill 297 260 221 300 260 221 minecraft:red_nether_bricks
setblock 299 260 182 minecraft:red_nether_bricks
setblock 300 260 182 minecraft:polished_blackstone
setblock 300 260 222 minecraft:polished_blackstone
fill 301 260 182 301 263 182 minecraft:red_nether_bricks
setblock 301 260 184 minecraft:light[level=14]
setblock 301 260 192 minecraft:light[level=14]
setblock 301 260 200 minecraft:light[level=14]
setblock 301 260 208 minecraft:light[level=14]
setblock 301 260 216 minecraft:light[level=14]
setblock 301 260 220 minecraft:red_nether_bricks
setblock 301 260 221 minecraft:polished_blackstone
fill 301 260 222 301 263 222 minecraft:red_nether_bricks
setblock 302 260 220 minecraft:polished_blackstone
fill 302 260 221 302 263 221 minecraft:red_nether_bricks
setblock 303 260 219 minecraft:polished_blackstone
fill 303 260 220 306 260 220 minecraft:red_nether_bricks
fill 304 260 219 307 260 219 minecraft:red_nether_bricks
setblock 305 260 182 minecraft:polished_blackstone
setblock 305 260 222 minecraft:polished_blackstone
fill 306 260 182 306 263 182 minecraft:red_nether_bricks
fill 306 260 218 307 261 218 minecraft:red_nether_bricks
setblock 306 260 221 minecraft:polished_blackstone
fill 306 260 222 306 263 222 minecraft:red_nether_bricks
setblock 307 260 220 minecraft:polished_blackstone
fill 307 260 221 307 263 221 minecraft:red_nether_bricks
setblock 308 260 219 minecraft:polished_blackstone
fill 308 260 220 308 263 220 minecraft:red_nether_bricks
setblock 309 260 184 minecraft:light[level=14]
setblock 309 260 192 minecraft:light[level=14]
setblock 309 260 200 minecraft:light[level=14]
setblock 309 260 208 minecraft:light[level=14]
setblock 309 260 216 minecraft:light[level=14]
setblock 309 260 218 minecraft:polished_blackstone
fill 309 260 219 309 263 219 minecraft:red_nether_bricks
setblock 310 260 182 minecraft:polished_blackstone
setblock 310 260 222 minecraft:polished_blackstone
setblock 311 260 182 minecraft:red_nether_bricks
setblock 311 260 221 minecraft:polished_blackstone
fill 311 260 222 311 263 222 minecraft:red_nether_bricks
setblock 312 260 220 minecraft:polished_blackstone
fill 312 260 221 312 263 221 minecraft:red_nether_bricks
setblock 314 260 221 minecraft:red_nether_bricks
setblock 315 260 222 minecraft:polished_blackstone
setblock 317 260 184 minecraft:light[level=14]
setblock 317 260 192 minecraft:light[level=14]
setblock 317 260 200 minecraft:light[level=14]
setblock 317 260 208 minecraft:light[level=14]
setblock 317 260 216 minecraft:light[level=14]
fill 321 260 194 321 260 195 minecraft:red_nether_bricks
setblock 321 260 196 minecraft:polished_blackstone
fill 321 260 197 321 262 198 minecraft:red_nether_bricks
setblock 322 260 190 minecraft:polished_blackstone
fill 322 260 191 322 263 191 minecraft:red_nether_bricks
setblock 322 260 194 minecraft:red_nether_bricks
setblock 322 260 195 minecraft:polished_blackstone
fill 322 260 196 322 263 196 minecraft:red_nether_bricks
setblock 322 260 200 minecraft:polished_blackstone
fill 322 260 201 322 261 203 minecraft:red_nether_bricks
setblock 322 260 210 minecraft:polished_blackstone
fill 322 260 211 322 261 211 minecraft:red_nether_bricks
setblock 322 260 214 minecraft:red_nether_bricks
setblock 322 260 215 minecraft:polished_blackstone
fill 322 260 216 322 263 216 minecraft:red_nether_bricks
fill 322 260 218 322 261 218 minecraft:red_nether_bricks
setblock 323 260 189 minecraft:polished_blackstone
fill 323 260 190 323 263 190 minecraft:red_nether_bricks
setblock 323 260 194 minecraft:polished_blackstone
fill 323 260 195 323 263 195 minecraft:red_nether_bricks
setblock 323 260 199 minecraft:polished_blackstone
fill 323 260 200 323 263 200 minecraft:red_nether_bricks
setblock 323 260 203 minecraft:red_nether_bricks
setblock 323 260 204 minecraft:polished_blackstone
fill 323 260 205 323 263 205 minecraft:red_nether_bricks
setblock 323 260 209 minecraft:polished_blackstone
fill 323 260 210 323 263 210 minecraft:red_nether_bricks
setblock 323 260 214 minecraft:polished_blackstone
fill 323 260 215 323 263 215 minecraft:red_nether_bricks
setblock 323 260 219 minecraft:polished_blackstone
fill 323 260 220 323 261 222 minecraft:red_nether_bricks
setblock 283 261 182 minecraft:red_nether_bricks
setblock 283 261 183 minecraft:polished_blackstone
fill 283 261 184 283 264 184 minecraft:red_nether_bricks
setblock 283 261 188 minecraft:polished_blackstone
fill 283 261 189 283 264 189 minecraft:red_nether_bricks
setblock 283 261 193 minecraft:polished_blackstone
fill 283 261 194 283 264 194 minecraft:red_nether_bricks
setblock 283 261 198 minecraft:polished_blackstone
fill 283 261 199 283 264 199 minecraft:red_nether_bricks
setblock 283 261 202 minecraft:red_nether_bricks
setblock 283 261 203 minecraft:polished_blackstone
fill 283 261 204 283 264 204 minecraft:red_nether_bricks
setblock 283 261 208 minecraft:polished_blackstone
setblock 283 261 209 minecraft:red_nether_bricks
setblock 283 261 213 minecraft:polished_blackstone
fill 283 261 214 283 264 214 minecraft:red_nether_bricks
setblock 283 261 217 minecraft:red_nether_bricks
setblock 283 261 218 minecraft:polished_blackstone
fill 283 261 219 283 264 219 minecraft:red_nether_bricks
setblock 283 261 222 minecraft:red_nether_bricks
setblock 284 261 182 minecraft:polished_blackstone
fill 284 261 183 284 264 183 minecraft:red_nether_bricks
setblock 284 261 187 minecraft:polished_blackstone
fill 284 261 188 284 264 188 minecraft:red_nether_bricks
setblock 284 261 192 minecraft:polished_blackstone
fill 284 261 193 284 264 193 minecraft:red_nether_bricks
setblock 284 261 197 minecraft:polished_blackstone
fill 284 261 198 284 264 198 minecraft:red_nether_bricks
setblock 284 261 202 minecraft:polished_blackstone
fill 284 261 203 284 264 203 minecraft:red_nether_bricks
fill 284 261 213 284 262 213 minecraft:red_nether_bricks
setblock 284 261 217 minecraft:polished_blackstone
fill 284 261 218 285 263 218 minecraft:red_nether_bricks
setblock 284 261 221 minecraft:red_nether_bricks
setblock 284 261 222 minecraft:polished_blackstone
fill 285 261 182 285 264 182 minecraft:red_nether_bricks
setblock 285 261 186 minecraft:polished_blackstone
fill 285 261 187 285 262 187 minecraft:red_nether_bricks
setblock 285 261 191 minecraft:polished_blackstone
fill 285 261 192 285 264 192 minecraft:red_nether_bricks
setblock 285 261 196 minecraft:polished_blackstone
fill 285 261 197 285 264 197 minecraft:red_nether_bricks
setblock 285 261 201 minecraft:polished_blackstone
setblock 285 261 216 minecraft:polished_blackstone
fill 285 261 217 285 263 217 minecraft:red_nether_bricks
fill 285 261 219 285 262 219 minecraft:red_nether_bricks
setblock 285 261 221 minecraft:polished_blackstone
fill 285 261 222 288 261 222 minecraft:red_nether_bricks
setblock 286 261 184 minecraft:red_nether_bricks
setblock 286 261 190 minecraft:polished_blackstone
fill 286 261 191 286 262 191 minecraft:red_nether_bricks
fill 286 261 193 286 262 193 minecraft:red_nether_bricks
setblock 286 261 195 minecraft:polished_blackstone
fill 286 261 196 286 264 196 minecraft:red_nether_bricks
setblock 286 261 220 minecraft:polished_blackstone
fill 286 261 221 289 261 221 minecraft:red_nether_bricks
setblock 287 261 184 minecraft:polished_blackstone
setblock 287 261 194 minecraft:polished_blackstone
fill 287 261 220 290 261 220 minecraft:red_nether_bricks
setblock 288 261 183 minecraft:polished_blackstone
fill 288 261 184 288 262 184 minecraft:red_nether_bricks
setblock 289 261 182 minecraft:polished_blackstone
fill 289 261 183 289 264 183 minecraft:red_nether_bricks
setblock 289 261 222 minecraft:polished_blackstone
fill 290 261 182 290 264 182 minecraft:red_nether_bricks
setblock 290 261 221 minecraft:polished_blackstone
fill 290 261 222 290 264 222 minecraft:red_nether_bricks
setblock 291 261 220 minecraft:polished_blackstone
fill 291 261 221 291 264 221 minecraft:red_nether_bricks
setblock 294 261 182 minecraft:polished_blackstone
setblock 294 261 222 minecraft:polished_blackstone
fill 295 261 182 295 264 182 minecraft:red_nether_bricks
setblock 295 261 221 minecraft:polished_blackstone
fill 295 261 222 298 261 222 minecraft:red_nether_bricks
fill 296 261 221 299 261 221 minecraft:red_nether_bricks
setblock 298 261 182 minecraft:red_nether_bricks
setblock 299 261 182 minecraft:polished_blackstone
setblock 299 261 222 minecraft:polished_blackstone
fill 300 261 182 300 264 182 minecraft:red_nether_bricks
setblock 300 261 220 minecraft:red_nether_bricks
setblock 300 261 221 minecraft:polished_blackstone
fill 300 261 222 300 264 222 minecraft:red_nether_bricks
setblock 301 261 220 minecraft:polished_blackstone
fill 301 261 221 301 264 221 minecraft:red_nether_bricks
setblock 302 261 219 minecraft:polished_blackstone
fill 302 261 220 305 261 220 minecraft:red_nether_bricks
setblock 303 261 182 minecraft:red_nether_bricks
fill 303 261 219 306 261 219 minecraft:red_nether_bricks
setblock 304 261 182 minecraft:polished_blackstone
setblock 304 261 222 minecraft:polished_blackstone
fill 305 261 182 305 264 182 minecraft:red_nether_bricks
fill 305 261 218 305 263 218 minecraft:red_nether_bricks
setblock 305 261 221 minecraft:polished_blackstone
fill 305 261 222 305 264 222 minecraft:red_nether_bricks
setblock 306 261 220 minecraft:polished_blackstone
fill 306 261 221 306 264 221 minecraft:red_nether_bricks
setblock 307 261 219 minecraft:polished_blackstone
fill 307 261 220 307 264 220 minecraft:red_nether_bricks
setblock 308 261 218 minecraft:polished_blackstone
fill 308 261 219 308 264 219 minecraft:red_nether_bricks
setblock 309 261 182 minecraft:polished_blackstone
setblock 309 261 218 minecraft:red_nether_bricks
setblock 309 261 222 minecraft:polished_blackstone
fill 310 261 182 310 262 182 minecraft:red_nether_bricks
setblock 310 261 221 minecraft:polished_blackstone
fill 310 261 222 310 264 222 minecraft:red_nether_bricks
setblock 311 261 220 minecraft:polished_blackstone
fill 311 261 221 311 264 221 minecraft:red_nether_bricks
fill 312 261 220 312 262 220 minecraft:red_nether_bricks
setblock 314 261 222 minecraft:polished_blackstone
fill 315 261 222 315 262 222 minecraft:red_nether_bricks
setblock 321 261 194 minecraft:red_nether_bricks
setblock 321 261 195 minecraft:polished_blackstone
fill 321 261 196 321 264 196 minecraft:red_nether_bricks
setblock 321 261 199 minecraft:red_nether_bricks
fill 322 261 190 322 263 190 minecraft:red_nether_bricks
setblock 322 261 194 minecraft:polished_blackstone
fill 322 261 195 322 264 195 minecraft:red_nether_bricks
setblock 322 261 198 minecraft:red_nether_bricks
setblock 322 261 199 minecraft:polished_blackstone
fill 322 261 200 322 264 200 minecraft:red_nether_bricks
setblock 322 261 204 minecraft:polished_blackstone
setblock 322 261 214 minecraft:polished_blackstone
fill 322 261 215 322 263 215 minecraft:red_nether_bricks
setblock 322 261 219 minecraft:polished_blackstone
fill 322 261 222 322 262 222 minecraft:red_nether_bricks
fill 323 261 186 323 262 186 minecraft:red_nether_bricks
setblock 323 261 188 minecraft:polished_blackstone
fill 323 261 189 323 264 189 minecraft:red_nether_bricks
setblock 323 261 193 minecraft:polished_blackstone
fill 323 261 194 323 264 194 minecraft:red_nether_bricks
setblock 323 261 198 minecraft:polished_blackstone
fill 323 261 199 323 264 199 minecraft:red_nether_bricks
setblock 323 261 203 minecraft:polished_blackstone
fill 323 261 204 323 264 204 minecraft:red_nether_bricks
setblock 323 261 208 minecraft:polished_blackstone
fill 323 261 209 323 264 209 minecraft:red_nether_bricks
setblock 323 261 213 minecraft:polished_blackstone
fill 323 261 214 323 264 214 minecraft:red_nether_bricks
setblock 323 261 218 minecraft:polished_blackstone
fill 323 261 219 323 264 219 minecraft:red_nether_bricks
setblock 283 262 182 minecraft:polished_blackstone
fill 283 262 183 283 265 183 minecraft:red_nether_bricks
setblock 283 262 187 minecraft:polished_blackstone
fill 283 262 188 283 265 188 minecraft:red_nether_bricks
setblock 283 262 192 minecraft:polished_blackstone
fill 283 262 193 283 265 193 minecraft:red_nether_bricks
setblock 283 262 197 minecraft:polished_blackstone
fill 283 262 198 283 265 198 minecraft:red_nether_bricks
setblock 283 262 201 minecraft:red_nether_bricks
setblock 283 262 202 minecraft:polished_blackstone
fill 283 262 203 283 265 203 minecraft:red_nether_bricks
fill 283 262 205 283 262 206 minecraft:red_nether_bricks
setblock 283 262 212 minecraft:polished_blackstone
fill 283 262 213 283 264 213 minecraft:red_nether_bricks
setblock 283 262 216 minecraft:red_nether_bricks
setblock 283 262 217 minecraft:polished_blackstone
fill 283 262 218 283 265 218 minecraft:red_nether_bricks
setblock 283 262 222 minecraft:polished_blackstone
fill 284 262 182 284 265 182 minecraft:red_nether_bricks
setblock 284 262 186 minecraft:polished_blackstone
fill 284 262 187 284 265 187 minecraft:red_nether_bricks
setblock 284 262 191 minecraft:polished_blackstone
fill 284 262 192 284 265 192 minecraft:red_nether_bricks
setblock 284 262 196 minecraft:polished_blackstone
fill 284 262 197 284 265 197 minecraft:red_nether_bricks
setblock 284 262 201 minecraft:polished_blackstone
fill 284 262 202 284 265 202 minecraft:red_nether_bricks
setblock 284 262 216 minecraft:polished_blackstone
fill 284 262 217 284 265 217 minecraft:red_nether_bricks
setblock 284 262 221 minecraft:polished_blackstone
fill 284 262 222 287 262 222 minecraft:red_nether_bricks
setblock 285 262 190 minecraft:polished_blackstone
fill 285 262 191 285 264 191 minecraft:red_nether_bricks
setblock 285 262 195 minecraft:polished_blackstone
fill 285 262 196 285 265 196 minecraft:red_nether_bricks
setblock 285 262 200 minecraft:polished_blackstone
fill 285 262 201 285 264 201 minecraft:red_nether_bricks
setblock 285 262 220 minecraft:polished_blackstone
fill 285 262 221 288 262 221 minecraft:red_nether_bricks
setblock 286 262 184 minecraft:polished_blackstone
setblock 286 262 190 minecraft:red_nether_bricks
setblock 286 262 194 minecraft:polished_blackstone
fill 286 262 195 286 264 195 minecraft:red_nether_bricks
setblock 286 262 199 minecraft:polished_blackstone
fill 286 262 220 289 262 220 minecraft:red_nether_bricks
setblock 287 262 183 minecraft:polished_blackstone
setblock 287 262 184 minecraft:red_nether_bricks
setblock 288 262 182 minecraft:polished_blackstone
fill 288 262 183 288 265 183 minecraft:red_nether_bricks
setblock 288 262 222 minecraft:polished_blackstone
fill 289 262 182 289 265 182 minecraft:red_nether_bricks
setblock 289 262 221 minecraft:polished_blackstone
fill 289 262 222 289 265 222 minecraft:red_nether_bricks
setblock 290 262 220 minecraft:polished_blackstone
fill 290 262 221 290 265 221 minecraft:red_nether_bricks
setblock 291 262 220 minecraft:red_nether_bricks
setblock 292 262 183 minecraft:polished_blackstone
setblock 293 262 182 minecraft:polished_blackstone
setblock 293 262 221 minecraft:red_nether_bricks
setblock 293 262 222 minecraft:polished_blackstone
fill 294 262 182 294 265 182 minecraft:red_nether_bricks
setblock 294 262 221 minecraft:polished_blackstone
fill 294 262 222 297 262 222 minecraft:red_nether_bricks
fill 295 262 221 298 262 221 minecraft:red_nether_bricks
setblock 298 262 182 minecraft:polished_blackstone
setblock 298 262 222 minecraft:polished_blackstone
fill 299 262 182 299 265 182 minecraft:red_nether_bricks
setblock 299 262 220 minecraft:red_nether_bricks
setblock 299 262 221 minecraft:polished_blackstone
fill 299 262 222 299 265 222 minecraft:red_nether_bricks
setblock 300 262 220 minecraft:polished_blackstone
fill 300 262 221 300 265 221 minecraft:red_nether_bricks
fill 301 262 220 304 262 220 minecraft:red_nether_bricks
fill 302 262 219 305 262 219 minecraft:red_nether_bricks
setblock 303 262 182 minecraft:polished_blackstone
setblock 303 262 222 minecraft:polished_blackstone
fill 304 262 182 304 265 182 minecraft:red_nether_bricks
setblock 304 262 221 minecraft:polished_blackstone
fill 304 262 222 304 265 222 minecraft:red_nether_bricks
setblock 305 262 220 minecraft:polished_blackstone
fill 305 262 221 305 265 221 minecraft:red_nether_bricks
setblock 306 262 218 minecraft:red_nether_bricks
setblock 306 262 219 minecraft:polished_blackstone
fill 306 262 220 306 265 220 minecraft:red_nether_bricks
setblock 307 262 218 minecraft:polished_blackstone
fill 307 262 219 307 265 219 minecraft:red_nether_bricks
setblock 308 262 182 minecraft:polished_blackstone
setblock 308 262 218 minecraft:red_nether_bricks
setblock 308 262 222 minecraft:polished_blackstone
fill 309 262 182 309 264 182 minecraft:red_nether_bricks
setblock 309 262 221 minecraft:polished_blackstone
fill 309 262 222 309 265 222 minecraft:red_nether_bricks
setblock 310 262 219 minecraft:red_nether_bricks
setblock 310 262 220 minecraft:polished_blackstone
fill 310 262 221 310 265 221 minecraft:red_nether_bricks
fill 311 262 220 311 263 220 minecraft:red_nether_bricks
setblock 313 262 222 minecraft:polished_blackstone
fill 314 262 222 314 263 222 minecraft:red_nether_bricks
setblock 321 262 194 minecraft:polished_blackstone
fill 321 262 195 321 265 195 minecraft:red_nether_bricks
setblock 321 262 199 minecraft:polished_blackstone
fill 321 262 200 321 264 201 minecraft:red_nether_bricks
fill 321 262 222 321 263 222 minecraft:red_nether_bricks
setblock 322 262 193 minecraft:polished_blackstone
fill 322 262 194 322 265 194 minecraft:red_nether_bricks
setblock 322 262 198 minecraft:polished_blackstone
fill 322 262 199 322 265 199 minecraft:red_nether_bricks
fill 322 262 201 322 262 202 minecraft:red_nether_bricks
setblock 322 262 203 minecraft:polished_blackstone
fill 322 262 204 322 264 205 minecraft:red_nether_bricks
setblock 322 262 213 minecraft:polished_blackstone
fill 322 262 214 322 263 214 minecraft:red_nether_bricks
setblock 322 262 218 minecraft:polished_blackstone
fill 322 262 219 322 264 220 minecraft:red_nether_bricks
setblock 323 262 182 minecraft:polished_blackstone
fill 323 262 185 323 263 185 minecraft:red_nether_bricks
setblock 323 262 187 minecraft:polished_blackstone
fill 323 262 188 323 265 188 minecraft:red_nether_bricks
setblock 323 262 192 minecraft:polished_blackstone
fill 323 262 193 323 265 193 minecraft:red_nether_bricks
setblock 323 262 197 minecraft:polished_blackstone
fill 323 262 198 323 265 198 minecraft:red_nether_bricks
setblock 323 262 202 minecraft:polished_blackstone
fill 323 262 203 323 265 203 minecraft:red_nether_bricks
setblock 323 262 207 minecraft:polished_blackstone
fill 323 262 208 323 265 208 minecraft:red_nether_bricks
setblock 323 262 212 minecraft:polished_blackstone
fill 323 262 213 323 265 213 minecraft:red_nether_bricks
setblock 323 262 217 minecraft:polished_blackstone
fill 323 262 218 323 265 218 minecraft:red_nether_bricks
fill 323 262 220 323 262 221 minecraft:red_nether_bricks
setblock 323 262 222 minecraft:polished_blackstone
fill 283 263 182 283 266 182 minecraft:red_nether_bricks
setblock 283 263 186 minecraft:polished_blackstone
fill 283 263 187 283 266 187 minecraft:red_nether_bricks
setblock 283 263 191 minecraft:polished_blackstone
fill 283 263 192 283 266 192 minecraft:red_nether_bricks
setblock 283 263 196 minecraft:polished_blackstone
fill 283 263 197 283 266 197 minecraft:red_nether_bricks
setblock 283 263 201 minecraft:polished_blackstone
fill 283 263 202 283 266 202 minecraft:red_nether_bricks
setblock 283 263 205 minecraft:red_nether_bricks
setblock 283 263 206 minecraft:polished_blackstone
setblock 283 263 211 minecraft:polished_blackstone
setblock 283 263 212 minecraft:red_nether_bricks
setblock 283 263 216 minecraft:polished_blackstone
fill 283 263 217 283 266 217 minecraft:red_nether_bricks
setblock 283 263 220 minecraft:red_nether_bricks
setblock 283 263 221 minecraft:polished_blackstone
fill 283 263 222 286 263 222 minecraft:red_nether_bricks
setblock 284 263 185 minecraft:polished_blackstone
fill 284 263 186 284 266 186 minecraft:red_nether_bricks
setblock 284 263 190 minecraft:polished_blackstone
fill 284 263 191 284 266 191 minecraft:red_nether_bricks
setblock 284 263 195 minecraft:polished_blackstone
fill 284 263 196 284 266 196 minecraft:red_nether_bricks
setblock 284 263 200 minecraft:polished_blackstone
fill 284 263 201 284 266 201 minecraft:red_nether_bricks
setblock 284 263 215 minecraft:polished_blackstone
fill 284 263 216 284 265 216 minecraft:red_nether_bricks
setblock 284 263 220 minecraft:polished_blackstone
fill 284 263 221 287 263 221 minecraft:red_nether_bricks
setblock 285 263 189 minecraft:polished_blackstone
fill 285 263 190 285 264 190 minecraft:red_nether_bricks
setblock 285 263 194 minecraft:polished_blackstone
fill 285 263 195 285 266 195 minecraft:red_nether_bricks
setblock 285 263 198 minecraft:red_nether_bricks
setblock 285 263 199 minecraft:polished_blackstone
fill 285 263 200 285 266 200 minecraft:red_nether_bricks
setblock 285 263 219 minecraft:polished_blackstone
fill 285 263 220 288 263 220 minecraft:red_nether_bricks
setblock 286 263 183 minecraft:polished_blackstone
setblock 286 263 184 minecraft:red_nether_bricks
setblock 286 263 193 minecraft:polished_blackstone
setblock 286 263 194 minecraft:red_nether_bricks
setblock 286 263 198 minecraft:polished_blackstone
setblock 287 263 182 minecraft:polished_blackstone
fill 287 263 183 287 266 183 minecraft:red_nether_bricks
setblock 287 263 222 minecraft:polished_blackstone
fill 288 263 182 288 266 182 minecraft:red_nether_bricks
setblock 288 263 221 minecraft:polished_blackstone
fill 288 263 222 288 266 222 minecraft:red_nether_bricks
setblock 289 263 220 minecraft:polished_blackstone
fill 289 263 221 289 266 221 minecraft:red_nether_bricks
setblock 290 263 220 minecraft:red_nether_bricks
setblock 291 263 183 minecraft:polished_blackstone
setblock 292 263 182 minecraft:polished_blackstone
setblock 292 263 222 minecraft:polished_blackstone
fill 293 263 182 293 266 182 minecraft:red_nether_bricks
setblock 293 263 221 minecraft:polished_blackstone
fill 293 263 222 296 263 222 minecraft:red_nether_bricks
fill 294 263 221 297 263 221 minecraft:red_nether_bricks
setblock 296 263 182 minecraft:red_nether_bricks
setblock 297 263 182 minecraft:polished_blackstone
setblock 297 263 222 minecraft:polished_blackstone
fill 298 263 182 298 266 182 minecraft:red_nether_bricks
setblock 298 263 221 minecraft:polished_blackstone
fill 298 263 222 298 266 222 minecraft:red_nether_bricks
setblock 299 263 220 minecraft:polished_blackstone
fill 299 263 221 299 266 221 minecraft:red_nether_bricks
fill 300 263 220 303 263 220 minecraft:red_nether_bricks
fill 301 263 219 304 263 219 minecraft:red_nether_bricks
setblock 302 263 182 minecraft:polished_blackstone
setblock 302 263 222 minecraft:polished_blackstone
fill 303 263 182 303 266 182 minecraft:red_nether_bricks
setblock 303 263 221 minecraft:polished_blackstone
fill 303 263 222 303 266 222 minecraft:red_nether_bricks
setblock 304 263 220 minecraft:polished_blackstone
fill 304 263 221 304 266 221 minecraft:red_nether_bricks
setblock 305 263 219 minecraft:polished_blackstone
fill 305 263 220 305 266 220 minecraft:red_nether_bricks
setblock 306 263 218 minecraft:polished_blackstone
fill 306 263 219 306 266 219 minecraft:red_nether_bricks
setblock 307 263 182 minecraft:polished_blackstone
setblock 307 263 218 minecraft:red_nether_bricks
setblock 307 263 222 minecraft:polished_blackstone
fill 308 263 182 308 266 182 minecraft:red_nether_bricks
setblock 308 263 221 minecraft:polished_blackstone
fill 308 263 222 308 266 222 minecraft:red_nether_bricks
setblock 309 263 220 minecraft:polished_blackstone
fill 309 263 221 309 266 221 minecraft:red_nether_bricks
fill 310 263 220 310 264 220 minecraft:red_nether_bricks
setblock 312 263 222 minecraft:polished_blackstone
setblock 313 263 221 minecraft:polished_blackstone
fill 313 263 222 313 265 222 minecraft:red_nether_bricks
fill 320 263 222 320 264 222 minecraft:red_nether_bricks
fill 321 263 194 321 264 194 minecraft:red_nether_bricks
setblock 321 263 197 minecraft:red_nether_bricks
setblock 321 263 198 minecraft:polished_blackstone
fill 321 263 199 321 266 199 minecraft:red_nether_bricks
setblock 322 263 192 minecraft:polished_blackstone
fill 322 263 193 322 266 193 minecraft:red_nether_bricks
setblock 322 263 197 minecraft:polished_blackstone
fill 322 263 198 322 266 198 minecraft:red_nether_bricks
setblock 322 263 201 minecraft:red_nether_bricks
setblock 322 263 202 minecraft:polished_blackstone
fill 322 263 203 322 266 203 minecraft:red_nether_bricks
setblock 322 263 217 minecraft:polished_blackstone
fill 322 263 218 322 265 218 minecraft:red_nether_bricks
setblock 322 263 222 minecraft:polished_blackstone
fill 323 263 182 323 264 184 minecraft:red_nether_bricks
setblock 323 263 186 minecraft:polished_blackstone
fill 323 263 187 323 266 187 minecraft:red_nether_bricks
setblock 323 263 191 minecraft:polished_blackstone
fill 323 263 192 323 266 192 minecraft:red_nether_bricks
setblock 323 263 196 minecraft:polished_blackstone
fill 323 263 197 323 266 197 minecraft:red_nether_bricks
setblock 323 263 201 minecraft:polished_blackstone
fill 323 263 202 323 266 202 minecraft:red_nether_bricks
setblock 323 263 206 minecraft:polished_blackstone
fill 323 263 207 323 266 207 minecraft:red_nether_bricks
setblock 323 263 211 minecraft:polished_blackstone
fill 323 263 212 323 265 212 minecraft:red_nether_bricks
setblock 323 263 216 minecraft:polished_blackstone
fill 323 263 217 323 266 217 minecraft:red_nether_bricks
setblock 323 263 220 minecraft:red_nether_bricks
setblock 323 263 221 minecraft:polished_blackstone
fill 323 263 222 323 266 222 minecraft:red_nether_bricks
setblock 283 264 185 minecraft:polished_blackstone
fill 283 264 186 283 267 186 minecraft:red_nether_bricks
setblock 283 264 190 minecraft:polished_blackstone
fill 283 264 191 283 267 191 minecraft:red_nether_bricks
setblock 283 264 195 minecraft:polished_blackstone
fill 283 264 196 283 267 196 minecraft:red_nether_bricks
setblock 283 264 200 minecraft:polished_blackstone
fill 283 264 201 283 267 201 minecraft:red_nether_bricks
setblock 283 264 205 minecraft:polished_blackstone
setblock 283 264 206 minecraft:red_nether_bricks
setblock 283 264 215 minecraft:polished_blackstone
fill 283 264 216 283 267 216 minecraft:red_nether_bricks
setblock 283 264 220 minecraft:polished_blackstone
fill 283 264 221 285 264 222 minecraft:red_nether_bricks
setblock 284 264 184 minecraft:polished_blackstone
fill 284 264 185 284 267 185 minecraft:red_nether_bricks
setblock 284 264 189 minecraft:polished_blackstone
fill 284 264 190 284 267 190 minecraft:red_nether_bricks
setblock 284 264 194 minecraft:polished_blackstone
fill 284 264 195 284 267 195 minecraft:red_nether_bricks
setblock 284 264 199 minecraft:polished_blackstone
fill 284 264 200 284 267 200 minecraft:red_nether_bricks
setblock 284 264 215 minecraft:red_nether_bricks
setblock 284 264 218 minecraft:red_nether_bricks
setblock 284 264 219 minecraft:polished_blackstone
fill 284 264 220 287 264 220 minecraft:red_nether_bricks
setblock 285 264 183 minecraft:polished_blackstone
setblock 285 264 193 minecraft:polished_blackstone
fill 285 264 194 285 266 194 minecraft:red_nether_bricks
setblock 285 264 198 minecraft:polished_blackstone
fill 285 264 199 285 266 199 minecraft:red_nether_bricks
setblock 285 264 218 minecraft:polished_blackstone
setblock 285 264 219 minecraft:red_nether_bricks
setblock 286 264 182 minecraft:polished_blackstone
fill 286 264 183 286 267 183 minecraft:red_nether_bricks
setblock 286 264 197 minecraft:polished_blackstone
setblock 286 264 221 minecraft:red_nether_bricks
setblock 286 264 222 minecraft:polished_blackstone
fill 287 264 182 287 267 182 minecraft:red_nether_bricks
setblock 287 264 221 minecraft:polished_blackstone
fill 287 264 222 287 267 222 minecraft:red_nether_bricks
setblock 288 264 220 minecraft:polished_blackstone
fill 288 264 221 288 267 221 minecraft:red_nether_bricks
setblock 289 264 220 minecraft:red_nether_bricks
setblock 290 264 183 minecraft:polished_blackstone
setblock 291 264 182 minecraft:polished_blackstone
setblock 291 264 222 minecraft:polished_blackstone
fill 292 264 182 292 267 182 minecraft:red_nether_bricks
setblock 292 264 221 minecraft:polished_blackstone
fill 292 264 222 295 264 222 minecraft:red_nether_bricks
fill 293 264 221 296 264 221 minecraft:red_nether_bricks
setblock 296 264 182 minecraft:polished_blackstone
setblock 296 264 222 minecraft:polished_blackstone
fill 297 264 182 297 267 182 minecraft:red_nether_bricks
setblock 297 264 221 minecraft:polished_blackstone
fill 297 264 222 297 267 222 minecraft:red_nether_bricks
fill 298 264 221 298 267 221 minecraft:red_nether_bricks
fill 299 264 220 302 264 220 minecraft:red_nether_bricks
setblock 301 264 182 minecraft:polished_blackstone
fill 301 264 219 303 264 219 minecraft:red_nether_bricks
setblock 301 264 222 minecraft:polished_blackstone
fill 302 264 182 302 267 182 minecraft:red_nether_bricks
setblock 302 264 221 minecraft:polished_blackstone
fill 302 264 222 302 267 222 minecraft:red_nether_bricks
setblock 303 264 220 minecraft:polished_blackstone
fill 303 264 221 303 267 221 minecraft:red_nether_bricks
setblock 304 264 219 minecraft:polished_blackstone
fill 304 264 220 304 267 220 minecraft:red_nether_bricks
fill 305 264 219 305 266 219 minecraft:red_nether_bricks
setblock 306 264 182 minecraft:polished_blackstone
setblock 306 264 222 minecraft:polished_blackstone
fill 307 264 182 307 267 182 minecraft:red_nether_bricks
setblock 307 264 221 minecraft:polished_blackstone
fill 307 264 222 307 267 222 minecraft:red_nether_bricks
setblock 308 264 220 minecraft:polished_blackstone
fill 308 264 221 308 267 221 minecraft:red_nether_bricks
fill 309 264 220 309 265 220 minecraft:red_nether_bricks
setblock 311 264 222 minecraft:polished_blackstone
setblock 312 264 221 minecraft:polished_blackstone
fill 312 264 222 312 266 222 minecraft:red_nether_bricks
setblock 321 264 197 minecraft:polished_blackstone
fill 321 264 198 321 267 198 minecraft:red_nether_bricks
setblock 321 264 202 minecraft:polished_blackstone
setblock 321 264 222 minecraft:polished_blackstone
fill 322 264 182 322 267 182 minecraft:red_nether_bricks
setblock 322 264 191 minecraft:polished_blackstone
fill 322 264 192 322 267 192 minecraft:red_nether_bricks
setblock 322 264 196 minecraft:polished_blackstone
fill 322 264 197 322 267 197 minecraft:red_nether_bricks
setblock 322 264 201 minecraft:polished_blackstone
fill 322 264 202 322 267 202 minecraft:red_nether_bricks
setblock 322 264 216 minecraft:polished_blackstone
setblock 322 264 217 minecraft:red_nether_bricks
fill 322 264 222 322 267 222 minecraft:red_nether_bricks
setblock 323 264 185 minecraft:polished_blackstone
fill 323 264 186 323 267 186 minecraft:red_nether_bricks
setblock 323 264 190 minecraft:polished_blackstone
fill 323 264 191 323 267 191 minecraft:red_nether_bricks
setblock 323 264 195 minecraft:polished_blackstone
fill 323 264 196 323 267 196 minecraft:red_nether_bricks
setblock 323 264 200 minecraft:polished_blackstone
fill 323 264 201 323 267 201 minecraft:red_nether_bricks
setblock 323 264 205 minecraft:polished_blackstone
fill 323 264 206 323 267 206 minecraft:red_nether_bricks
setblock 323 264 210 minecraft:polished_blackstone
fill 323 264 211 323 265 211 minecraft:red_nether_bricks
setblock 323 264 215 minecraft:polished_blackstone
fill 323 264 216 323 267 216 minecraft:red_nether_bricks
setblock 323 264 220 minecraft:polished_blackstone
fill 323 264 221 323 267 221 minecraft:red_nether_bricks
setblock 283 265 184 minecraft:polished_blackstone
fill 283 265 185 283 268 185 minecraft:red_nether_bricks
setblock 283 265 189 minecraft:polished_blackstone
fill 283 265 190 283 268 190 minecraft:red_nether_bricks
setblock 283 265 194 minecraft:polished_blackstone
fill 283 265 195 283 268 195 minecraft:red_nether_bricks
setblock 283 265 199 minecraft:polished_blackstone
fill 283 265 200 283 268 200 minecraft:red_nether_bricks
setblock 283 265 204 minecraft:polished_blackstone
fill 283 265 205 283 268 205 minecraft:red_nether_bricks
setblock 283 265 214 minecraft:polished_blackstone
fill 283 265 215 283 266 215 minecraft:red_nether_bricks
setblock 283 265 219 minecraft:polished_blackstone
fill 283 265 220 284 265 222 minecraft:red_nether_bricks
setblock 284 265 183 minecraft:polished_blackstone
fill 284 265 184 284 268 184 minecraft:red_nether_bricks
setblock 284 265 188 minecraft:polished_blackstone
fill 284 265 189 284 268 189 minecraft:red_nether_bricks
setblock 284 265 193 minecraft:polished_blackstone
fill 284 265 194 284 268 194 minecraft:red_nether_bricks
setblock 284 265 198 minecraft:polished_blackstone
fill 284 265 199 284 268 199 minecraft:red_nether_bricks
setblock 284 265 203 minecraft:polished_blackstone
setblock 284 265 218 minecraft:polished_blackstone
fill 284 265 219 284 268 219 minecraft:red_nether_bricks
setblock 285 265 182 minecraft:polished_blackstone
fill 285 265 183 285 268 183 minecraft:red_nether_bricks
setblock 285 265 192 minecraft:polished_blackstone
setblock 285 265 193 minecraft:red_nether_bricks
setblock 285 265 197 minecraft:polished_blackstone
fill 285 265 198 285 267 198 minecraft:red_nether_bricks
fill 285 265 220 285 265 221 minecraft:red_nether_bricks
setblock 285 265 222 minecraft:polished_blackstone
fill 286 265 182 286 268 182 minecraft:red_nether_bricks
setblock 286 265 220 minecraft:red_nether_bricks
setblock 286 265 221 minecraft:polished_blackstone
fill 286 265 222 286 268 222 minecraft:red_nether_bricks
setblock 287 265 220 minecraft:polished_blackstone
fill 287 265 221 287 268 221 minecraft:red_nether_bricks
setblock 288 265 220 minecraft:red_nether_bricks
setblock 289 265 183 minecraft:polished_blackstone
setblock 290 265 182 minecraft:polished_blackstone
setblock 290 265 183 minecraft:red_nether_bricks
setblock 290 265 222 minecraft:polished_blackstone
fill 291 265 182 291 268 182 minecraft:red_nether_bricks
setblock 291 265 221 minecraft:polished_blackstone
fill 291 265 222 294 265 222 minecraft:red_nether_bricks
fill 292 265 221 295 265 221 minecraft:red_nether_bricks
setblock 295 265 182 minecraft:polished_blackstone
setblock 295 265 222 minecraft:polished_blackstone
fill 296 265 182 296 268 182 minecraft:red_nether_bricks
setblock 296 265 221 minecraft:polished_blackstone
fill 296 265 222 296 268 222 minecraft:red_nether_bricks
fill 297 265 221 297 268 221 minecraft:red_nether_bricks
fill 299 265 220 301 265 220 minecraft:red_nether_bricks
setblock 300 265 182 minecraft:polished_blackstone
setblock 300 265 222 minecraft:polished_blackstone
fill 301 265 182 301 268 182 minecraft:red_nether_bricks
setblock 301 265 221 minecraft:polished_blackstone
fill 301 265 222 301 268 222 minecraft:red_nether_bricks
setblock 302 265 219 minecraft:red_nether_bricks
setblock 302 265 220 minecraft:polished_blackstone
fill 302 265 221 302 268 221 minecraft:red_nether_bricks
setblock 303 265 219 minecraft:polished_blackstone
fill 303 265 220 303 268 220 minecraft:red_nether_bricks
fill 304 265 219 304 266 219 minecraft:red_nether_bricks
setblock 305 265 182 minecraft:polished_blackstone
setblock 305 265 222 minecraft:polished_blackstone
fill 306 265 182 306 268 182 minecraft:red_nether_bricks
setblock 306 265 221 minecraft:polished_blackstone
fill 306 265 222 306 268 222 minecraft:red_nether_bricks
setblock 307 265 220 minecraft:polished_blackstone
fill 307 265 221 307 268 221 minecraft:red_nether_bricks
fill 308 265 220 308 266 220 minecraft:red_nether_bricks
setblock 310 265 222 minecraft:polished_blackstone
setblock 311 265 221 minecraft:polished_blackstone
fill 311 265 222 311 267 222 minecraft:red_nether_bricks
setblock 320 265 222 minecraft:polished_blackstone
setblock 321 265 196 minecraft:polished_blackstone
fill 321 265 197 321 268 197 minecraft:red_nether_bricks
setblock 321 265 200 minecraft:red_nether_bricks
setblock 321 265 201 minecraft:polished_blackstone
fill 321 265 202 321 268 202 minecraft:red_nether_bricks
fill 321 265 222 321 268 222 minecraft:red_nether_bricks
setblock 322 265 191 minecraft:red_nether_bricks
setblock 322 265 195 minecraft:polished_blackstone
fill 322 265 196 322 268 196 minecraft:red_nether_bricks
setblock 322 265 200 minecraft:polished_blackstone
fill 322 265 201 322 268 201 minecraft:red_nether_bricks
setblock 322 265 204 minecraft:red_nether_bricks
setblock 322 265 205 minecraft:polished_blackstone
setblock 322 265 219 minecraft:red_nether_bricks
setblock 322 265 220 minecraft:polished_blackstone
fill 323 265 182 323 265 183 minecraft:red_nether_bricks
setblock 323 265 184 minecraft:polished_blackstone
fill 323 265 185 323 268 185 minecraft:red_nether_bricks
setblock 323 265 189 minecraft:polished_blackstone
fill 323 265 190 323 268 190 minecraft:red_nether_bricks
setblock 323 265 194 minecraft:polished_blackstone
fill 323 265 195 323 268 195 minecraft:red_nether_bricks
setblock 323 265 199 minecraft:polished_blackstone
fill 323 265 200 323 268 200 minecraft:red_nether_bricks
setblock 323 265 204 minecraft:polished_blackstone
fill 323 265 205 323 268 205 minecraft:red_nether_bricks
setblock 323 265 209 minecraft:polished_blackstone
setblock 323 265 210 minecraft:red_nether_bricks
setblock 323 265 214 minecraft:polished_blackstone
fill 323 265 215 323 266 215 minecraft:red_nether_bricks
setblock 323 265 219 minecraft:polished_blackstone
fill 323 265 220 323 268 220 minecraft:red_nether_bricks
setblock 283 266 183 minecraft:polished_blackstone
fill 283 266 184 283 269 184 minecraft:red_nether_bricks
setblock 283 266 188 minecraft:polished_blackstone
fill 283 266 189 283 269 189 minecraft:red_nether_bricks
setblock 283 266 193 minecraft:polished_blackstone
fill 283 266 194 283 269 194 minecraft:red_nether_bricks
setblock 283 266 198 minecraft:polished_blackstone
fill 283 266 199 283 269 199 minecraft:red_nether_bricks
setblock 283 266 203 minecraft:polished_blackstone
fill 283 266 204 283 269 204 minecraft:red_nether_bricks
setblock 283 266 218 minecraft:polished_blackstone
fill 283 266 219 283 266 222 minecraft:red_nether_bricks
setblock 284 266 182 minecraft:polished_blackstone
fill 284 266 183 284 269 183 minecraft:red_nether_bricks
setblock 284 266 187 minecraft:polished_blackstone
fill 284 266 188 284 269 188 minecraft:red_nether_bricks
setblock 284 266 192 minecraft:polished_blackstone
fill 284 266 193 284 268 193 minecraft:red_nether_bricks
setblock 284 266 197 minecraft:polished_blackstone
fill 284 266 198 284 269 198 minecraft:red_nether_bricks
setblock 284 266 202 minecraft:polished_blackstone
fill 284 266 203 284 269 203 minecraft:red_nether_bricks
setblock 284 266 217 minecraft:polished_blackstone
fill 284 266 218 284 267 218 minecraft:red_nether_bricks
fill 284 266 220 284 266 221 minecraft:red_nether_bricks
setblock 284 266 222 minecraft:polished_blackstone
fill 285 266 182 285 269 182 minecraft:red_nether_bricks
setblock 285 266 196 minecraft:polished_blackstone
setblock 285 266 197 minecraft:red_nether_bricks
setblock 285 266 221 minecraft:polished_blackstone
fill 285 266 222 285 269 222 minecraft:red_nether_bricks
fill 286 266 221 286 269 221 minecraft:red_nether_bricks
setblock 288 266 183 minecraft:polished_blackstone
setblock 289 266 182 minecraft:polished_blackstone
fill 289 266 183 289 269 183 minecraft:red_nether_bricks
setblock 289 266 222 minecraft:polished_blackstone
fill 290 266 182 290 269 182 minecraft:red_nether_bricks
setblock 290 266 221 minecraft:polished_blackstone
fill 290 266 222 293 266 222 minecraft:red_nether_bricks
fill 291 266 221 294 266 221 minecraft:red_nether_bricks
setblock 294 266 182 minecraft:polished_blackstone
setblock 294 266 222 minecraft:polished_blackstone
fill 295 266 182 295 269 182 minecraft:red_nether_bricks
setblock 295 266 221 minecraft:polished_blackstone
fill 295 266 222 295 269 222 minecraft:red_nether_bricks
fill 296 266 221 296 269 221 minecraft:red_nether_bricks
setblock 299 266 182 minecraft:polished_blackstone
fill 299 266 220 300 266 220 minecraft:red_nether_bricks
setblock 299 266 222 minecraft:polished_blackstone
fill 300 266 182 300 269 182 minecraft:red_nether_bricks
setblock 300 266 221 minecraft:polished_blackstone
fill 300 266 222 300 269 222 minecraft:red_nether_bricks
setblock 301 266 220 minecraft:polished_blackstone
fill 301 266 221 301 269 221 minecraft:red_nether_bricks
setblock 302 266 219 minecraft:polished_blackstone
fill 302 266 220 302 269 220 minecraft:red_nether_bricks
fill 303 266 219 303 267 219 minecraft:red_nether_bricks
setblock 304 266 182 minecraft:polished_blackstone
setblock 304 266 222 minecraft:polished_blackstone
fill 305 266 182 305 269 182 minecraft:red_nether_bricks
setblock 305 266 221 minecraft:polished_blackstone
fill 305 266 222 305 269 222 minecraft:red_nether_bricks
setblock 306 266 220 minecraft:polished_blackstone
fill 306 266 221 306 269 221 minecraft:red_nether_bricks
fill 307 266 220 307 267 220 minecraft:red_nether_bricks
setblock 309 266 222 minecraft:polished_blackstone
setblock 310 266 221 minecraft:polished_blackstone
fill 310 266 222 310 269 222 minecraft:red_nether_bricks
fill 320 266 222 320 269 222 minecraft:red_nether_bricks
fill 321 266 182 321 268 182 minecraft:red_nether_bricks
setblock 321 266 195 minecraft:polished_blackstone
fill 321 266 196 321 269 196 minecraft:red_nether_bricks
setblock 321 266 200 minecraft:polished_blackstone
fill 321 266 201 321 269 201 minecraft:red_nether_bricks
fill 321 266 203 321 267 203 minecraft:red_nether_bricks
setblock 322 266 194 minecraft:polished_blackstone
fill 322 266 195 322 269 195 minecraft:red_nether_bricks
setblock 322 266 199 minecraft:polished_blackstone
fill 322 266 200 322 269 200 minecraft:red_nether_bricks
setblock 322 266 204 minecraft:polished_blackstone
fill 322 266 205 322 269 205 minecraft:red_nether_bricks
setblock 323 266 182 minecraft:red_nether_bricks
setblock 323 266 183 minecraft:polished_blackstone
fill 323 266 184 323 269 184 minecraft:red_nether_bricks
setblock 323 266 188 minecraft:polished_blackstone
fill 323 266 189 323 269 189 minecraft:red_nether_bricks
setblock 323 266 193 minecraft:polished_blackstone
fill 323 266 194 323 269 194 minecraft:red_nether_bricks
setblock 323 266 198 minecraft:polished_blackstone
fill 323 266 199 323 269 199 minecraft:red_nether_bricks
setblock 323 266 203 minecraft:polished_blackstone
fill 323 266 204 323 269 204 minecraft:red_nether_bricks
setblock 323 266 208 minecraft:polished_blackstone
setblock 323 266 209 minecraft:red_nether_bricks
setblock 323 266 214 minecraft:red_nether_bricks
setblock 323 266 218 minecraft:polished_blackstone
fill 323 266 219 323 269 219 minecraft:red_nether_bricks
setblock 283 267 182 minecraft:polished_blackstone
fill 283 267 183 283 270 183 minecraft:red_nether_bricks
setblock 283 267 187 minecraft:polished_blackstone
fill 283 267 188 283 270 188 minecraft:red_nether_bricks
setblock 283 267 192 minecraft:polished_blackstone
fill 283 267 193 283 270 193 minecraft:red_nether_bricks
setblock 283 267 197 minecraft:polished_blackstone
fill 283 267 198 283 270 198 minecraft:red_nether_bricks
setblock 283 267 202 minecraft:polished_blackstone
fill 283 267 203 283 270 203 minecraft:red_nether_bricks
setblock 283 267 206 minecraft:red_nether_bricks
setblock 283 267 217 minecraft:polished_blackstone
fill 283 267 218 283 267 221 minecraft:red_nether_bricks
setblock 283 267 222 minecraft:polished_blackstone
fill 284 267 182 284 270 182 minecraft:red_nether_bricks
setblock 284 267 186 minecraft:polished_blackstone
fill 284 267 187 284 270 187 minecraft:red_nether_bricks
setblock 284 267 191 minecraft:polished_blackstone
fill 284 267 192 284 268 192 minecraft:red_nether_bricks
setblock 284 267 196 minecraft:polished_blackstone
fill 284 267 197 284 270 197 minecraft:red_nether_bricks
setblock 284 267 201 minecraft:polished_blackstone
fill 284 267 202 284 270 202 minecraft:red_nether_bricks
setblock 284 267 220 minecraft:red_nether_bricks
setblock 284 267 221 minecraft:polished_blackstone
fill 284 267 222 284 270 222 minecraft:red_nether_bricks
fill 285 267 221 285 270 221 minecraft:red_nether_bricks
setblock 287 267 183 minecraft:polished_blackstone
setblock 288 267 182 minecraft:polished_blackstone
fill 288 267 183 288 270 183 minecraft:red_nether_bricks
setblock 288 267 222 minecraft:polished_blackstone
fill 289 267 182 289 270 182 minecraft:red_nether_bricks
setblock 289 267 221 minecraft:polished_blackstone
fill 289 267 222 292 267 222 minecraft:red_nether_bricks
fill 290 267 221 292 267 221 minecraft:red_nether_bricks
setblock 293 267 182 minecraft:polished_blackstone
setblock 293 267 222 minecraft:polished_blackstone
fill 294 267 182 294 270 182 minecraft:red_nether_bricks
setblock 294 267 221 minecraft:polished_blackstone
fill 294 267 222 294 270 222 minecraft:red_nether_bricks
fill 295 267 221 295 270 221 minecraft:red_nether_bricks
setblock 298 267 182 minecraft:polished_blackstone
setblock 298 267 222 minecraft:polished_blackstone
fill 299 267 182 299 270 182 minecraft:red_nether_bricks
setblock 299 267 220 minecraft:red_nether_bricks
setblock 299 267 221 minecraft:polished_blackstone
fill 299 267 222 299 270 222 minecraft:red_nether_bricks
setblock 300 267 220 minecraft:polished_blackstone
fill 300 267 221 300 270 221 minecraft:red_nether_bricks
fill 301 267 220 301 270 220 minecraft:red_nether_bricks
setblock 303 267 182 minecraft:polished_blackstone
setblock 303 267 222 minecraft:polished_blackstone
fill 304 267 182 304 270 182 minecraft:red_nether_bricks
setblock 304 267 221 minecraft:polished_blackstone
fill 304 267 222 304 270 222 minecraft:red_nether_bricks
setblock 305 267 220 minecraft:polished_blackstone
fill 305 267 221 305 270 221 minecraft:red_nether_bricks
fill 306 267 220 306 268 220 minecraft:red_nether_bricks
setblock 308 267 222 minecraft:polished_blackstone
setblock 309 267 221 minecraft:polished_blackstone
fill 309 267 222 309 270 222 minecraft:red_nether_bricks
fill 319 267 222 319 270 222 minecraft:red_nether_bricks
fill 320 267 182 320 269 182 minecraft:red_nether_bricks
setblock 321 267 199 minecraft:polished_blackstone
fill 321 267 200 321 270 200 minecraft:red_nether_bricks
setblock 322 267 193 minecraft:polished_blackstone
fill 322 267 194 322 270 194 minecraft:red_nether_bricks
setblock 322 267 198 minecraft:polished_blackstone
fill 322 267 199 322 270 199 minecraft:red_nether_bricks
setblock 322 267 203 minecraft:polished_blackstone
fill 322 267 204 322 270 204 minecraft:red_nether_bricks
fill 322 267 206 322 268 206 minecraft:red_nether_bricks
setblock 323 267 182 minecraft:polished_blackstone
fill 323 267 183 323 270 183 minecraft:red_nether_bricks
setblock 323 267 187 minecraft:polished_blackstone
fill 323 267 188 323 270 188 minecraft:red_nether_bricks
setblock 323 267 192 minecraft:polished_blackstone
fill 323 267 193 323 270 193 minecraft:red_nether_bricks
setblock 323 267 197 minecraft:polished_blackstone
fill 323 267 198 323 270 198 minecraft:red_nether_bricks
setblock 323 267 202 minecraft:polished_blackstone
fill 323 267 203 323 270 203 minecraft:red_nether_bricks
setblock 323 267 207 minecraft:polished_blackstone
fill 323 267 208 323 270 208 minecraft:red_nether_bricks
setblock 323 267 217 minecraft:polished_blackstone
fill 323 267 218 323 270 218 minecraft:red_nether_bricks
setblock 323 267 222 minecraft:polished_blackstone
fill 283 268 182 283 270 182 minecraft:red_nether_bricks
setblock 283 268 186 minecraft:polished_blackstone
fill 283 268 187 283 270 187 minecraft:red_nether_bricks
setblock 283 268 191 minecraft:polished_blackstone
fill 283 268 192 283 270 192 minecraft:red_nether_bricks
setblock 283 268 196 minecraft:polished_blackstone
fill 283 268 197 283 270 197 minecraft:red_nether_bricks
setblock 283 268 201 minecraft:polished_blackstone
fill 283 268 202 283 270 202 minecraft:red_nether_bricks
setblock 283 268 206 minecraft:polished_blackstone
setblock 283 268 216 minecraft:polished_blackstone
fill 283 268 217 283 268 220 minecraft:red_nether_bricks
setblock 283 268 221 minecraft:polished_blackstone
fill 283 268 222 283 270 222 minecraft:red_nether_bricks
setblock 284 268 185 minecraft:polished_blackstone
fill 284 268 186 284 270 186 minecraft:red_nether_bricks
setblock 284 268 195 minecraft:polished_blackstone
fill 284 268 196 284 270 196 minecraft:red_nether_bricks
setblock 284 268 200 minecraft:polished_blackstone
fill 284 268 201 284 270 201 minecraft:red_nether_bricks
setblock 284 268 220 minecraft:polished_blackstone
fill 284 268 221 284 270 221 minecraft:red_nether_bricks
setblock 285 268 184 minecraft:polished_blackstone
setblock 285 268 192 minecraft:light[level=14]
setblock 285 268 200 minecraft:light[level=14]
setblock 285 268 208 minecraft:light[level=14]
setblock 285 268 216 minecraft:light[level=14]
setblock 286 268 183 minecraft:polished_blackstone
setblock 287 268 182 minecraft:polished_blackstone
fill 287 268 183 287 270 183 minecraft:red_nether_bricks
setblock 287 268 222 minecraft:polished_blackstone
fill 288 268 182 288 270 182 minecraft:red_nether_bricks
setblock 288 268 221 minecraft:polished_blackstone
fill 288 268 222 291 268 222 minecraft:red_nether_bricks
fill 289 268 221 290 270 221 minecraft:red_nether_bricks
setblock 292 268 182 minecraft:polished_blackstone
setblock 292 268 222 minecraft:polished_blackstone
fill 293 268 182 293 270 182 minecraft:red_nether_bricks
setblock 293 268 184 minecraft:light[level=14]
setblock 293 268 192 minecraft:light[level=14]
setblock 293 268 200 minecraft:light[level=14]
setblock 293 268 208 minecraft:light[level=14]
setblock 293 268 216 minecraft:light[level=14]
fill 293 268 222 293 270 222 minecraft:red_nether_bricks
fill 294 268 221 294 270 221 minecraft:red_nether_bricks
setblock 297 268 182 minecraft:polished_blackstone
setblock 297 268 222 minecraft:polished_blackstone
fill 298 268 182 298 270 182 minecraft:red_nether_bricks
setblock 298 268 221 minecraft:polished_blackstone
fill 298 268 222 298 270 222 minecraft:red_nether_bricks
setblock 299 268 220 minecraft:polished_blackstone
fill 299 268 221 299 270 221 minecraft:red_nether_bricks
fill 300 268 220 300 270 220 minecraft:red_nether_bricks
setblock 301 268 184 minecraft:light[level=14]
setblock 301 268 192 minecraft:light[level=14]
setblock 301 268 200 minecraft:light[level=14]
setblock 301 268 208 minecraft:light[level=14]
setblock 301 268 216 minecraft:light[level=14]
setblock 302 268 182 minecraft:polished_blackstone
setblock 302 268 222 minecraft:polished_blackstone
fill 303 268 182 303 270 182 minecraft:red_nether_bricks
setblock 303 268 221 minecraft:polished_blackstone
fill 303 268 222 303 270 222 minecraft:red_nether_bricks
setblock 304 268 220 minecraft:polished_blackstone
fill 304 268 221 304 270 221 minecraft:red_nether_bricks
fill 305 268 220 305 270 220 minecraft:red_nether_bricks
setblock 307 268 182 minecraft:polished_blackstone
setblock 307 268 222 minecraft:polished_blackstone
setblock 308 268 221 minecraft:polished_blackstone
fill 308 268 222 308 270 222 minecraft:red_nether_bricks
setblock 309 268 184 minecraft:light[level=14]
setblock 309 268 192 minecraft:light[level=14]
setblock 309 268 200 minecraft:light[level=14]
setblock 309 268 208 minecraft:light[level=14]
setblock 309 268 216 minecraft:light[level=14]
setblock 317 268 184 minecraft:light[level=14]
setblock 317 268 192 minecraft:light[level=14]
setblock 317 268 200 minecraft:light[level=14]
setblock 317 268 208 minecraft:light[level=14]
setblock 317 268 216 minecraft:light[level=14]
fill 319 268 182 319 270 182 minecraft:red_nether_bricks
schedule function dropper:buildpart/42_11 1t
