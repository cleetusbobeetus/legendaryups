fill 110 216 335 110 217 336 minecraft:white_concrete
fill 110 216 342 110 217 343 minecraft:white_concrete
fill 110 216 349 116 217 349 minecraft:iron_block
fill 110 216 351 116 217 351 minecraft:iron_block
setblock 111 216 323 minecraft:stripped_spruce_log
setblock 111 216 325 minecraft:light[level=12]
setblock 111 216 332 minecraft:light[level=12]
fill 111 216 335 116 217 335 minecraft:white_concrete
setblock 111 216 339 minecraft:light[level=12]
fill 111 216 343 116 217 343 minecraft:white_concrete
setblock 111 216 346 minecraft:light[level=12]
setblock 111 216 353 minecraft:light[level=12]
setblock 111 216 360 minecraft:light[level=12]
fill 112 216 323 115 216 323 minecraft:stone
fill 112 216 334 114 217 334 minecraft:white_concrete
fill 112 216 344 114 217 344 minecraft:white_concrete
setblock 116 216 323 minecraft:stripped_spruce_log
fill 116 216 324 119 216 324 minecraft:stone
fill 116 216 330 118 217 330 minecraft:iron_block
fill 116 216 336 117 217 336 minecraft:white_concrete
fill 116 216 342 117 217 342 minecraft:white_concrete
fill 116 216 348 118 217 348 minecraft:iron_block
fill 117 216 323 120 216 323 minecraft:stone
fill 117 216 328 118 217 328 minecraft:iron_block
fill 117 216 335 117 217 335 minecraft:light_gray_concrete
fill 117 216 337 117 217 341 minecraft:white_concrete
fill 117 216 343 117 217 343 minecraft:light_gray_concrete
fill 117 216 350 118 217 350 minecraft:iron_block
fill 117 216 363 120 216 363 minecraft:stone
setblock 118 216 325 minecraft:light[level=12]
setblock 118 216 332 minecraft:light[level=12]
fill 118 216 334 118 217 334 minecraft:light_gray_concrete
fill 118 216 338 118 217 340 minecraft:white_concrete
fill 118 216 344 118 217 344 minecraft:light_gray_concrete
setblock 118 216 346 minecraft:light[level=12]
setblock 118 216 353 minecraft:light[level=12]
setblock 118 216 360 minecraft:light[level=12]
fill 119 216 329 120 217 329 minecraft:iron_block
fill 119 216 331 120 217 331 minecraft:iron_block
fill 119 216 333 119 217 333 minecraft:light_gray_concrete
fill 119 216 345 119 217 345 minecraft:light_gray_concrete
fill 119 216 347 120 217 347 minecraft:iron_block
fill 119 216 349 120 217 349 minecraft:iron_block
setblock 120 216 324 minecraft:stripped_spruce_log
fill 120 216 325 123 216 325 minecraft:stone
fill 120 216 332 120 217 332 minecraft:light_gray_concrete
fill 120 216 346 120 217 346 minecraft:light_gray_concrete
fill 120 216 362 121 216 362 minecraft:stone
setblock 121 216 323 minecraft:stripped_spruce_log
fill 121 216 324 124 216 324 minecraft:stone
fill 121 216 330 121 217 330 minecraft:iron_block
fill 121 216 331 121 217 331 minecraft:light_gray_concrete
fill 121 216 333 121 217 333 minecraft:iron_block
fill 121 216 345 121 217 345 minecraft:iron_block
fill 121 216 347 121 217 347 minecraft:light_gray_concrete
fill 121 216 348 121 217 348 minecraft:iron_block
setblock 121 216 363 minecraft:stripped_spruce_log
fill 122 216 323 125 216 323 minecraft:stone
fill 122 216 331 122 217 331 minecraft:iron_block
fill 122 216 334 122 217 336 minecraft:iron_block
fill 122 216 342 122 217 344 minecraft:iron_block
fill 122 216 347 122 217 347 minecraft:iron_block
fill 122 216 360 122 218 360 minecraft:cobbled_deepslate
setblock 122 216 362 minecraft:stripped_spruce_log
fill 122 216 363 125 216 363 minecraft:stone
fill 123 216 332 123 217 333 minecraft:iron_block
fill 123 216 336 123 217 342 minecraft:iron_block
fill 123 216 345 123 217 346 minecraft:iron_block
fill 123 216 359 123 218 359 minecraft:cobbled_deepslate
fill 123 216 361 123 218 361 minecraft:cobbled_deepslate
fill 123 216 362 126 216 362 minecraft:stone
setblock 124 216 325 minecraft:stripped_spruce_log
fill 124 216 334 124 217 335 minecraft:iron_block
fill 124 216 343 124 217 344 minecraft:iron_block
fill 124 216 360 124 218 360 minecraft:cobbled_deepslate
fill 124 216 361 127 216 361 minecraft:stone
setblock 125 216 324 minecraft:stripped_spruce_log
fill 125 216 325 128 216 325 minecraft:stone
setblock 125 216 332 minecraft:light[level=12]
fill 125 216 336 125 216 342 minecraft:iron_block
setblock 125 216 346 minecraft:light[level=12]
setblock 125 216 353 minecraft:light[level=12]
setblock 125 216 360 minecraft:light[level=12]
setblock 126 216 323 minecraft:stripped_spruce_log
fill 126 216 324 129 216 324 minecraft:stone
setblock 126 216 363 minecraft:stripped_spruce_log
fill 127 216 323 130 216 323 minecraft:stone
setblock 127 216 362 minecraft:stripped_spruce_log
fill 127 216 363 130 216 363 minecraft:stone
fill 128 216 362 131 216 362 minecraft:stone
setblock 130 216 324 minecraft:stripped_spruce_log
setblock 131 216 323 minecraft:stripped_spruce_log
setblock 131 216 324 minecraft:stone
setblock 131 216 363 minecraft:stripped_spruce_log
fill 132 216 323 132 219 323 minecraft:stone
setblock 132 216 325 minecraft:light[level=12]
setblock 132 216 332 minecraft:light[level=12]
setblock 132 216 339 minecraft:light[level=12]
setblock 132 216 346 minecraft:light[level=12]
setblock 132 216 353 minecraft:light[level=12]
fill 132 216 360 134 219 360 minecraft:stripped_spruce_log
setblock 132 216 362 minecraft:stripped_spruce_log
fill 132 216 363 132 219 363 minecraft:stone
fill 133 216 361 133 219 361 minecraft:stripped_spruce_log
setblock 133 216 362 minecraft:stone
setblock 135 216 324 minecraft:stripped_spruce_log
setblock 135 216 360 minecraft:stone
fill 135 216 362 135 217 362 minecraft:stone
fill 136 216 333 136 223 333 minecraft:andesite
fill 136 216 338 136 241 338 minecraft:andesite
setblock 136 216 362 minecraft:diamond_block
fill 94 217 362 94 241 362 minecraft:andesite
fill 95 217 341 95 217 342 minecraft:stone
setblock 95 217 343 minecraft:stripped_spruce_log
fill 95 217 344 95 217 347 minecraft:stone
setblock 95 217 348 minecraft:stripped_spruce_log
fill 95 217 349 95 220 349 minecraft:stone
fill 96 217 343 96 218 343 minecraft:stone
setblock 96 217 347 minecraft:stripped_spruce_log
fill 96 217 348 96 220 348 minecraft:stone
fill 97 217 336 101 217 342 minecraft:blue_stained_glass
fill 97 217 363 99 217 363 minecraft:stone
setblock 99 217 322 minecraft:gold_block
setblock 99 217 323 minecraft:stone
setblock 100 217 323 minecraft:stripped_spruce_log
setblock 100 217 360 minecraft:raw_gold_block
setblock 100 217 363 minecraft:stripped_spruce_log
fill 101 217 323 104 217 323 minecraft:stone
fill 101 217 356 101 217 358 minecraft:raw_gold_block
fill 101 217 363 104 217 363 minecraft:stone
fill 102 217 324 103 217 324 minecraft:stone
setblock 102 217 360 minecraft:raw_gold_block
setblock 102 217 362 minecraft:raw_gold_block
setblock 104 217 324 minecraft:stripped_spruce_log
setblock 105 217 323 minecraft:stripped_spruce_log
fill 105 217 324 108 217 324 minecraft:stone
setblock 105 217 363 minecraft:stripped_spruce_log
fill 106 217 323 109 217 323 minecraft:stone
fill 106 217 363 107 217 363 minecraft:stone
setblock 110 217 323 minecraft:stripped_spruce_log
fill 111 217 323 114 217 323 minecraft:stone
setblock 115 217 323 minecraft:stripped_spruce_log
fill 116 217 323 118 217 324 minecraft:stone
fill 118 217 363 119 217 363 minecraft:stone
setblock 119 217 323 minecraft:stone
setblock 119 217 324 minecraft:stripped_spruce_log
fill 119 217 325 122 217 325 minecraft:stone
setblock 120 217 323 minecraft:stripped_spruce_log
fill 120 217 324 123 217 324 minecraft:stone
setblock 120 217 363 minecraft:stripped_spruce_log
setblock 120 217 364 minecraft:diamond_block
fill 121 217 323 124 217 323 minecraft:stone
setblock 121 217 362 minecraft:stripped_spruce_log
fill 121 217 363 124 217 363 minecraft:stone
fill 122 217 359 122 218 359 minecraft:cobbled_deepslate
fill 122 217 361 122 218 361 minecraft:cobbled_deepslate
fill 122 217 362 125 217 362 minecraft:stone
setblock 123 217 325 minecraft:stripped_spruce_log
setblock 124 217 324 minecraft:stripped_spruce_log
fill 124 217 325 127 217 325 minecraft:stone
fill 124 217 359 124 218 359 minecraft:cobbled_deepslate
fill 124 217 361 124 218 361 minecraft:cobbled_deepslate
setblock 125 217 323 minecraft:stripped_spruce_log
fill 125 217 324 128 217 324 minecraft:stone
fill 125 217 336 129 217 342 minecraft:blue_stained_glass
setblock 125 217 363 minecraft:stripped_spruce_log
fill 126 217 323 129 217 323 minecraft:stone
setblock 126 217 362 minecraft:stripped_spruce_log
fill 126 217 363 129 217 363 minecraft:stone
fill 127 217 362 130 217 362 minecraft:stone
setblock 129 217 324 minecraft:stripped_spruce_log
setblock 130 217 323 minecraft:stripped_spruce_log
fill 130 217 324 130 218 324 minecraft:stone
setblock 130 217 363 minecraft:stripped_spruce_log
fill 131 217 323 131 220 323 minecraft:stone
fill 131 217 363 131 220 363 minecraft:stone
fill 132 217 359 132 219 359 minecraft:stripped_spruce_log
fill 132 217 361 132 219 361 minecraft:stripped_spruce_log
fill 133 217 323 134 217 323 minecraft:stone
fill 133 217 363 134 217 363 minecraft:stone
fill 134 217 359 134 219 359 minecraft:stripped_spruce_log
fill 134 217 361 134 219 361 minecraft:stripped_spruce_log
setblock 135 217 323 minecraft:stripped_spruce_log
setblock 135 217 363 minecraft:stripped_spruce_log
fill 136 217 328 136 217 329 minecraft:raw_iron_block
setblock 136 217 345 minecraft:gold_block
fill 136 217 362 136 219 362 minecraft:andesite
setblock 94 218 341 minecraft:gold_block
setblock 95 218 342 minecraft:stripped_spruce_log
fill 95 218 343 95 218 346 minecraft:stone
setblock 95 218 347 minecraft:stripped_spruce_log
fill 95 218 348 95 221 348 minecraft:stone
setblock 95 218 351 minecraft:stone
setblock 96 218 345 minecraft:stone
setblock 96 218 346 minecraft:stripped_spruce_log
fill 96 218 347 96 221 347 minecraft:stone
fill 96 218 349 96 219 349 minecraft:stone
setblock 97 218 325 minecraft:light[level=15]
setblock 97 218 333 minecraft:light[level=15]
setblock 97 218 341 minecraft:light[level=15]
setblock 97 218 349 minecraft:light[level=15]
setblock 97 218 357 minecraft:light[level=15]
setblock 98 218 323 minecraft:stone
setblock 98 218 363 minecraft:stone
fill 99 218 322 99 231 322 minecraft:andesite
setblock 99 218 323 minecraft:stripped_spruce_log
setblock 99 218 363 minecraft:stripped_spruce_log
fill 100 218 323 103 218 323 minecraft:stone
fill 100 218 363 103 218 363 minecraft:stone
fill 101 218 324 102 218 324 minecraft:stone
fill 101 218 361 101 218 362 minecraft:raw_gold_block
setblock 103 218 324 minecraft:stripped_spruce_log
setblock 104 218 323 minecraft:stripped_spruce_log
fill 104 218 324 107 218 324 minecraft:stone
fill 104 218 334 108 267 336 minecraft:stripped_spruce_log
setblock 104 218 363 minecraft:stripped_spruce_log
fill 105 218 323 108 218 323 minecraft:stone
setblock 105 218 325 minecraft:light[level=15]
fill 105 218 331 105 218 332 minecraft:iron_block
fill 105 218 333 107 267 333 minecraft:stripped_spruce_log
fill 105 218 337 107 267 337 minecraft:stripped_spruce_log
setblock 105 218 341 minecraft:light[level=15]
fill 105 218 346 105 218 347 minecraft:iron_block
setblock 105 218 349 minecraft:light[level=15]
setblock 105 218 357 minecraft:light[level=15]
fill 105 218 363 106 218 363 minecraft:stone
setblock 108 218 324 minecraft:stripped_spruce_log
setblock 109 218 323 minecraft:stripped_spruce_log
fill 110 218 323 113 218 323 minecraft:stone
setblock 112 218 322 minecraft:diamond_block
setblock 113 218 325 minecraft:light[level=15]
setblock 113 218 333 minecraft:light[level=15]
setblock 113 218 349 minecraft:light[level=15]
setblock 113 218 357 minecraft:light[level=15]
setblock 114 218 323 minecraft:stripped_spruce_log
fill 115 218 323 118 218 323 minecraft:stone
fill 116 218 324 117 218 324 minecraft:stone
setblock 118 218 324 minecraft:stripped_spruce_log
fill 118 218 325 121 218 325 minecraft:stone
setblock 118 218 363 minecraft:stone
setblock 119 218 323 minecraft:stripped_spruce_log
fill 119 218 324 122 218 324 minecraft:stone
setblock 119 218 363 minecraft:stripped_spruce_log
fill 120 218 323 123 218 323 minecraft:stone
fill 120 218 331 121 218 331 minecraft:iron_block
fill 120 218 347 121 218 347 minecraft:iron_block
fill 120 218 363 123 218 363 minecraft:stone
fill 120 218 364 120 241 364 minecraft:andesite
setblock 121 218 333 minecraft:light[level=15]
setblock 121 218 341 minecraft:light[level=15]
setblock 121 218 349 minecraft:light[level=15]
setblock 121 218 357 minecraft:light[level=15]
setblock 121 218 360 minecraft:cobbled_deepslate
fill 121 218 362 124 218 362 minecraft:stone
setblock 122 218 325 minecraft:stripped_spruce_log
setblock 123 218 324 minecraft:stripped_spruce_log
fill 123 218 325 126 218 325 minecraft:stone
setblock 123 218 358 minecraft:cobbled_deepslate
setblock 124 218 323 minecraft:stripped_spruce_log
fill 124 218 324 127 218 324 minecraft:stone
setblock 124 218 363 minecraft:stripped_spruce_log
fill 125 218 323 128 218 323 minecraft:stone
setblock 125 218 360 minecraft:cobbled_deepslate
setblock 125 218 362 minecraft:stripped_spruce_log
fill 125 218 363 128 218 363 minecraft:stone
fill 126 218 362 129 218 362 minecraft:stone
setblock 127 218 325 minecraft:stripped_spruce_log
setblock 128 218 324 minecraft:stripped_spruce_log
setblock 129 218 323 minecraft:stripped_spruce_log
fill 129 218 324 129 220 324 minecraft:stone
setblock 129 218 325 minecraft:light[level=15]
setblock 129 218 333 minecraft:light[level=15]
setblock 129 218 341 minecraft:light[level=15]
setblock 129 218 349 minecraft:light[level=15]
fill 129 218 352 134 218 352 minecraft:raw_gold_block
setblock 129 218 357 minecraft:light[level=15]
setblock 129 218 363 minecraft:stripped_spruce_log
fill 130 218 323 130 221 323 minecraft:stone
fill 130 218 363 130 221 363 minecraft:stone
setblock 133 218 323 minecraft:stone
setblock 133 218 363 minecraft:stone
setblock 134 218 323 minecraft:stripped_spruce_log
setblock 134 218 363 minecraft:stripped_spruce_log
fill 135 218 323 135 221 323 minecraft:stone
setblock 135 218 346 minecraft:stone
setblock 135 218 347 minecraft:stripped_spruce_log
fill 135 218 348 135 221 348 minecraft:stone
setblock 135 218 362 minecraft:stripped_spruce_log
fill 135 218 363 135 221 363 minecraft:stone
fill 136 218 328 136 237 329 minecraft:andesite
fill 136 218 345 136 241 345 minecraft:andesite
fill 94 219 341 94 223 341 minecraft:andesite
setblock 94 219 342 minecraft:gold_block
setblock 94 219 353 minecraft:raw_iron_block
fill 95 219 342 95 219 345 minecraft:stone
setblock 95 219 346 minecraft:stripped_spruce_log
fill 95 219 347 95 222 347 minecraft:stone
setblock 95 219 351 minecraft:stripped_spruce_log
fill 95 219 352 95 222 352 minecraft:stone
fill 96 219 324 96 222 324 minecraft:spruce_log
fill 96 219 343 96 222 343 minecraft:spruce_log
setblock 96 219 345 minecraft:stripped_spruce_log
fill 96 219 346 97 221 346 minecraft:stone
setblock 96 219 350 minecraft:stripped_spruce_log
fill 96 219 362 96 222 362 minecraft:spruce_log
fill 97 219 345 97 222 345 minecraft:stone
fill 97 219 347 97 220 347 minecraft:stone
setblock 98 219 323 minecraft:stripped_spruce_log
fill 99 219 323 102 219 323 minecraft:stone
fill 99 219 363 102 219 363 minecraft:stone
setblock 101 219 324 minecraft:stone
setblock 102 219 322 minecraft:raw_iron_block
setblock 102 219 324 minecraft:stripped_spruce_log
setblock 102 219 364 minecraft:diamond_block
setblock 103 219 323 minecraft:stripped_spruce_log
fill 103 219 324 106 219 324 minecraft:stone
fill 103 219 333 103 220 336 minecraft:cobbled_deepslate
setblock 103 219 363 minecraft:stripped_spruce_log
fill 104 219 323 107 219 323 minecraft:stone
fill 104 219 332 104 220 333 minecraft:cobbled_deepslate
fill 104 219 337 104 220 337 minecraft:cobbled_deepslate
fill 104 219 363 105 219 363 minecraft:stone
fill 105 219 332 107 220 332 minecraft:cobbled_deepslate
fill 105 219 338 107 220 338 minecraft:cobbled_deepslate
setblock 107 219 324 minecraft:stripped_spruce_log
setblock 108 219 323 minecraft:stripped_spruce_log
fill 108 219 333 108 220 333 minecraft:cobbled_deepslate
fill 108 219 337 108 220 337 minecraft:cobbled_deepslate
fill 109 219 323 112 219 323 minecraft:stone
fill 109 219 334 109 220 336 minecraft:cobbled_deepslate
fill 112 219 322 112 232 322 minecraft:andesite
setblock 113 219 323 minecraft:stripped_spruce_log
fill 114 219 323 117 219 323 minecraft:stone
fill 115 219 324 115 222 324 minecraft:spruce_log
fill 115 219 362 115 222 362 minecraft:spruce_log
setblock 116 219 324 minecraft:stone
setblock 117 219 324 minecraft:stripped_spruce_log
setblock 117 219 363 minecraft:stone
setblock 118 219 323 minecraft:stripped_spruce_log
fill 118 219 324 120 219 325 minecraft:stone
setblock 118 219 363 minecraft:stripped_spruce_log
fill 119 219 323 122 219 323 minecraft:stone
fill 119 219 363 122 219 363 minecraft:stone
setblock 121 219 324 minecraft:stone
setblock 121 219 325 minecraft:stripped_spruce_log
fill 121 219 326 123 220 326 minecraft:stone
fill 121 219 362 123 219 362 minecraft:stone
setblock 122 219 324 minecraft:stripped_spruce_log
fill 122 219 325 125 219 325 minecraft:stone
fill 123 219 322 123 241 322 minecraft:andesite
setblock 123 219 323 minecraft:stripped_spruce_log
fill 123 219 324 126 219 324 minecraft:stone
setblock 123 219 363 minecraft:stripped_spruce_log
setblock 124 219 322 minecraft:diamond_block
fill 124 219 323 127 219 323 minecraft:stone
setblock 124 219 362 minecraft:stripped_spruce_log
fill 124 219 363 127 219 363 minecraft:stone
fill 125 219 362 127 220 362 minecraft:stone
setblock 126 219 325 minecraft:stripped_spruce_log
setblock 127 219 324 minecraft:stripped_spruce_log
setblock 127 219 325 minecraft:stone
setblock 128 219 323 minecraft:stripped_spruce_log
fill 128 219 324 128 222 324 minecraft:stone
setblock 128 219 363 minecraft:stripped_spruce_log
fill 129 219 323 129 222 323 minecraft:stone
fill 129 219 363 129 222 363 minecraft:stone
fill 130 219 352 135 219 352 minecraft:raw_gold_block
fill 131 219 351 134 219 351 minecraft:raw_gold_block
fill 131 219 353 135 219 353 minecraft:raw_gold_block
setblock 133 219 323 minecraft:stripped_spruce_log
setblock 133 219 363 minecraft:stripped_spruce_log
setblock 134 219 323 minecraft:stone
fill 134 219 324 134 222 324 minecraft:spruce_log
fill 134 219 343 134 222 343 minecraft:spruce_log
fill 134 219 362 134 222 362 minecraft:spruce_log
fill 134 219 363 134 222 363 minecraft:stone
setblock 135 219 345 minecraft:stone
setblock 135 219 346 minecraft:stripped_spruce_log
fill 135 219 347 135 222 347 minecraft:stone
fill 135 219 349 135 219 350 minecraft:stone
setblock 135 219 351 minecraft:stripped_spruce_log
fill 135 219 362 135 222 362 minecraft:stone
fill 94 220 342 94 241 342 minecraft:andesite
setblock 94 220 350 minecraft:raw_gold_block
fill 94 220 353 94 241 353 minecraft:andesite
fill 95 220 341 95 220 344 minecraft:stone
setblock 95 220 345 minecraft:stripped_spruce_log
fill 95 220 346 95 223 346 minecraft:stone
setblock 95 220 350 minecraft:stripped_spruce_log
fill 95 220 351 96 222 351 minecraft:stone
fill 95 220 353 95 221 353 minecraft:stone
setblock 96 220 344 minecraft:stripped_spruce_log
fill 96 220 345 96 223 345 minecraft:stone
setblock 96 220 349 minecraft:stripped_spruce_log
fill 96 220 350 96 223 350 minecraft:stone
setblock 96 220 352 minecraft:raw_gold_block
setblock 96 220 364 minecraft:diamond_block
setblock 97 220 323 minecraft:stripped_spruce_log
fill 97 220 344 97 223 344 minecraft:stone
setblock 97 220 348 minecraft:stripped_spruce_log
fill 97 220 349 97 223 349 minecraft:stone
fill 98 220 323 101 220 323 minecraft:stone
fill 99 220 363 101 220 363 minecraft:stone
setblock 100 220 324 minecraft:stone
setblock 101 220 324 minecraft:stripped_spruce_log
fill 102 220 322 102 226 322 minecraft:andesite
setblock 102 220 323 minecraft:stripped_spruce_log
fill 102 220 324 105 220 324 minecraft:stone
fill 102 220 333 102 220 337 minecraft:cobbled_deepslate
setblock 102 220 363 minecraft:stripped_spruce_log
fill 102 220 364 102 237 364 minecraft:andesite
fill 103 220 323 106 220 323 minecraft:stone
setblock 103 220 332 minecraft:cobbled_deepslate
fill 103 220 337 103 220 338 minecraft:cobbled_deepslate
fill 103 220 363 104 220 363 minecraft:stone
fill 104 220 331 108 220 331 minecraft:cobbled_deepslate
fill 104 220 338 104 220 339 minecraft:cobbled_deepslate
fill 105 220 339 107 220 339 minecraft:cobbled_deepslate
setblock 106 220 324 minecraft:stripped_spruce_log
setblock 107 220 323 minecraft:stripped_spruce_log
fill 107 220 324 107 223 324 minecraft:stone
fill 108 220 323 111 220 323 minecraft:stone
fill 108 220 332 109 220 332 minecraft:cobbled_deepslate
fill 108 220 338 109 220 338 minecraft:cobbled_deepslate
fill 109 220 333 110 220 333 minecraft:cobbled_deepslate
setblock 109 220 337 minecraft:cobbled_deepslate
fill 110 220 334 110 220 336 minecraft:cobbled_deepslate
setblock 112 220 323 minecraft:stripped_spruce_log
fill 113 220 323 116 220 323 minecraft:stone
fill 114 220 324 114 221 324 minecraft:stone
setblock 116 220 324 minecraft:stripped_spruce_log
setblock 117 220 323 minecraft:stripped_spruce_log
fill 117 220 324 119 220 325 minecraft:stone
setblock 117 220 363 minecraft:stripped_spruce_log
fill 118 220 323 121 220 323 minecraft:stone
fill 118 220 363 121 220 363 minecraft:stone
setblock 119 220 326 minecraft:raw_gold_block
setblock 120 220 324 minecraft:stone
setblock 120 220 325 minecraft:stripped_spruce_log
fill 120 220 326 120 223 326 minecraft:stone
fill 120 220 362 122 220 362 minecraft:stone
setblock 121 220 324 minecraft:stripped_spruce_log
fill 121 220 325 124 220 325 minecraft:stone
setblock 122 220 323 minecraft:stripped_spruce_log
fill 122 220 324 125 220 324 minecraft:stone
setblock 122 220 363 minecraft:stripped_spruce_log
fill 123 220 323 126 220 323 minecraft:stone
setblock 123 220 362 minecraft:stripped_spruce_log
fill 123 220 363 126 220 363 minecraft:stone
fill 124 220 322 124 241 322 minecraft:andesite
fill 124 220 362 124 223 362 minecraft:stone
setblock 125 220 325 minecraft:stripped_spruce_log
setblock 126 220 324 minecraft:stripped_spruce_log
fill 126 220 325 126 222 325 minecraft:stone
setblock 127 220 323 minecraft:stripped_spruce_log
fill 127 220 324 127 223 324 minecraft:stone
setblock 127 220 363 minecraft:stripped_spruce_log
fill 128 220 323 128 223 323 minecraft:stone
fill 128 220 363 128 223 363 minecraft:stone
setblock 129 220 364 minecraft:raw_iron_block
fill 130 220 364 131 239 364 minecraft:andesite
setblock 132 220 323 minecraft:stripped_spruce_log
fill 132 220 352 134 220 352 minecraft:raw_gold_block
setblock 132 220 363 minecraft:stripped_spruce_log
fill 133 220 323 133 223 323 minecraft:stone
fill 133 220 351 134 220 351 minecraft:raw_gold_block
fill 133 220 353 134 220 353 minecraft:raw_gold_block
fill 133 220 363 133 223 363 minecraft:stone
setblock 135 220 324 minecraft:stone
setblock 135 220 344 minecraft:stone
setblock 135 220 345 minecraft:stripped_spruce_log
fill 135 220 346 135 223 346 minecraft:stone
setblock 135 220 349 minecraft:stone
setblock 135 220 350 minecraft:stripped_spruce_log
fill 135 220 351 135 221 353 minecraft:stone
setblock 136 220 362 minecraft:raw_gold_block
setblock 94 221 328 minecraft:raw_iron_block
fill 94 221 350 94 225 350 minecraft:andesite
fill 95 221 341 95 221 343 minecraft:stone
setblock 95 221 344 minecraft:stripped_spruce_log
fill 95 221 345 95 224 345 minecraft:stone
setblock 95 221 349 minecraft:stripped_spruce_log
fill 95 221 350 95 224 350 minecraft:stone
setblock 95 221 354 minecraft:stripped_spruce_log
setblock 96 221 342 minecraft:stone
fill 96 221 344 96 224 344 minecraft:stone
setblock 96 221 348 minecraft:stripped_spruce_log
fill 96 221 349 96 224 349 minecraft:stone
setblock 96 221 352 minecraft:stone
setblock 96 221 353 minecraft:stripped_spruce_log
fill 96 221 364 96 241 364 minecraft:andesite
fill 97 221 323 100 221 323 minecraft:stone
setblock 97 221 347 minecraft:stripped_spruce_log
fill 97 221 348 98 223 348 minecraft:stone
fill 97 221 350 97 221 351 minecraft:stone
setblock 97 221 352 minecraft:raw_gold_block
setblock 98 221 346 minecraft:stripped_spruce_log
fill 98 221 347 98 224 347 minecraft:stone
setblock 99 221 324 minecraft:stone
fill 99 221 363 100 221 363 minecraft:stone
setblock 100 221 324 minecraft:stripped_spruce_log
setblock 101 221 323 minecraft:stripped_spruce_log
fill 101 221 324 104 221 324 minecraft:stone
setblock 101 221 363 minecraft:stripped_spruce_log
fill 102 221 323 105 221 323 minecraft:stone
fill 102 221 325 103 221 325 minecraft:stone
fill 102 221 363 103 221 363 minecraft:stone
setblock 105 221 324 minecraft:stripped_spruce_log
setblock 106 221 323 minecraft:stripped_spruce_log
fill 106 221 324 106 224 324 minecraft:stone
fill 107 221 323 110 221 323 minecraft:stone
setblock 111 221 323 minecraft:stripped_spruce_log
fill 112 221 323 115 221 323 minecraft:stone
fill 113 221 324 113 222 324 minecraft:stone
setblock 116 221 323 minecraft:stripped_spruce_log
fill 116 221 324 118 221 325 minecraft:stone
fill 117 221 323 120 221 323 minecraft:stone
fill 117 221 363 120 221 363 minecraft:stone
setblock 118 221 326 minecraft:stripped_spruce_log
setblock 119 221 324 minecraft:stone
setblock 119 221 325 minecraft:stripped_spruce_log
fill 119 221 326 119 224 326 minecraft:stone
fill 119 221 327 119 221 328 minecraft:raw_gold_block
setblock 120 221 324 minecraft:stripped_spruce_log
fill 120 221 325 123 221 325 minecraft:stone
fill 120 221 362 121 221 362 minecraft:stone
setblock 121 221 323 minecraft:stripped_spruce_log
fill 121 221 324 124 221 324 minecraft:stone
fill 121 221 326 122 221 326 minecraft:stone
setblock 121 221 363 minecraft:stripped_spruce_log
fill 122 221 323 125 221 323 minecraft:stone
setblock 122 221 362 minecraft:stripped_spruce_log
fill 122 221 363 125 221 363 minecraft:stone
setblock 123 221 326 minecraft:stripped_spruce_log
fill 123 221 362 123 224 362 minecraft:stone
setblock 124 221 325 minecraft:stripped_spruce_log
setblock 125 221 324 minecraft:stripped_spruce_log
fill 125 221 325 125 224 325 minecraft:stone
fill 125 221 362 126 221 362 minecraft:stone
setblock 126 221 323 minecraft:stripped_spruce_log
fill 126 221 324 126 224 324 minecraft:stone
setblock 126 221 363 minecraft:stripped_spruce_log
fill 127 221 323 127 224 323 minecraft:stone
fill 127 221 363 127 224 363 minecraft:stone
fill 129 221 324 131 224 324 minecraft:raw_gold_block
fill 129 221 364 129 242 364 minecraft:andesite
fill 130 221 325 130 224 325 minecraft:raw_gold_block
setblock 131 221 323 minecraft:stripped_spruce_log
setblock 131 221 363 minecraft:stripped_spruce_log
fill 132 221 323 132 224 323 minecraft:stone
fill 132 221 363 132 224 363 minecraft:stone
fill 134 221 323 134 222 323 minecraft:stone
fill 134 221 348 134 221 349 minecraft:stone
setblock 134 221 352 minecraft:raw_gold_block
setblock 135 221 324 minecraft:stripped_spruce_log
fill 135 221 325 135 223 326 minecraft:stone
setblock 135 221 344 minecraft:stripped_spruce_log
fill 135 221 345 135 224 345 minecraft:stone
setblock 135 221 349 minecraft:stripped_spruce_log
fill 135 221 350 135 224 350 minecraft:stone
setblock 135 221 354 minecraft:stripped_spruce_log
fill 135 221 355 135 223 356 minecraft:stone
fill 136 221 362 136 239 362 minecraft:andesite
fill 94 222 328 94 241 328 minecraft:andesite
fill 95 222 324 95 222 327 minecraft:stone
setblock 95 222 328 minecraft:stripped_spruce_log
fill 95 222 329 95 223 331 minecraft:stone
fill 95 222 340 95 222 342 minecraft:stone
setblock 95 222 343 minecraft:stripped_spruce_log
fill 95 222 344 95 224 344 minecraft:stone
setblock 95 222 348 minecraft:stripped_spruce_log
fill 95 222 349 95 224 349 minecraft:stone
setblock 95 222 353 minecraft:stripped_spruce_log
fill 95 222 354 95 223 356 minecraft:stone
setblock 95 222 364 minecraft:raw_iron_block
fill 96 222 323 99 222 323 minecraft:stone
setblock 96 222 341 minecraft:stone
setblock 96 222 342 minecraft:stripped_spruce_log
setblock 96 222 346 minecraft:stone
setblock 96 222 347 minecraft:stripped_spruce_log
fill 96 222 348 96 224 348 minecraft:stone
setblock 96 222 352 minecraft:stripped_spruce_log
fill 96 222 353 96 224 354 minecraft:stone
setblock 97 222 325 minecraft:light[level=12]
setblock 97 222 332 minecraft:light[level=12]
setblock 97 222 339 minecraft:light[level=12]
fill 97 222 343 97 224 343 minecraft:stone
setblock 97 222 346 minecraft:stripped_spruce_log
fill 97 222 347 97 225 347 minecraft:stone
setblock 97 222 350 minecraft:stone
setblock 97 222 351 minecraft:stripped_spruce_log
fill 97 222 352 97 225 352 minecraft:stone
setblock 97 222 353 minecraft:raw_gold_block
setblock 97 222 360 minecraft:light[level=12]
setblock 98 222 324 minecraft:stone
setblock 98 222 345 minecraft:stripped_spruce_log
fill 98 222 346 98 225 346 minecraft:stone
setblock 98 222 349 minecraft:stone
setblock 98 222 350 minecraft:stripped_spruce_log
fill 98 222 352 98 223 352 minecraft:raw_gold_block
fill 98 222 363 99 222 363 minecraft:stone
setblock 99 222 324 minecraft:stripped_spruce_log
setblock 100 222 323 minecraft:stripped_spruce_log
fill 100 222 324 103 222 324 minecraft:stone
setblock 100 222 363 minecraft:stripped_spruce_log
fill 101 222 323 104 222 323 minecraft:stone
fill 101 222 325 102 222 325 minecraft:stone
fill 101 222 363 102 223 363 minecraft:stone
setblock 103 222 325 minecraft:stripped_spruce_log
setblock 104 222 324 minecraft:stripped_spruce_log
fill 104 222 325 104 224 325 minecraft:stone
setblock 104 222 332 minecraft:light[level=12]
setblock 104 222 339 minecraft:light[level=12]
setblock 104 222 346 minecraft:light[level=12]
setblock 104 222 353 minecraft:light[level=12]
setblock 104 222 360 minecraft:light[level=12]
setblock 105 222 323 minecraft:stripped_spruce_log
fill 105 222 324 105 224 324 minecraft:stone
fill 106 222 323 109 222 323 minecraft:stone
setblock 108 222 324 minecraft:stone
setblock 110 222 323 minecraft:stripped_spruce_log
fill 111 222 323 114 222 323 minecraft:stone
setblock 111 222 325 minecraft:light[level=12]
setblock 111 222 332 minecraft:light[level=12]
setblock 111 222 339 minecraft:light[level=12]
setblock 111 222 346 minecraft:light[level=12]
setblock 111 222 353 minecraft:light[level=12]
setblock 111 222 360 minecraft:light[level=12]
fill 112 222 324 112 223 324 minecraft:stone
setblock 114 222 324 minecraft:stripped_spruce_log
setblock 115 222 323 minecraft:stripped_spruce_log
fill 115 222 325 117 222 325 minecraft:stone
fill 116 222 323 118 222 324 minecraft:stone
fill 116 222 363 119 222 363 minecraft:stone
setblock 117 222 326 minecraft:stripped_spruce_log
setblock 118 222 325 minecraft:stripped_spruce_log
fill 118 222 326 118 225 326 minecraft:stone
setblock 118 222 332 minecraft:light[level=12]
setblock 118 222 339 minecraft:light[level=12]
setblock 118 222 346 minecraft:light[level=12]
setblock 118 222 353 minecraft:light[level=12]
setblock 118 222 360 minecraft:light[level=12]
setblock 119 222 323 minecraft:stone
setblock 119 222 324 minecraft:stripped_spruce_log
fill 119 222 325 122 222 325 minecraft:stone
fill 119 222 362 120 222 362 minecraft:stone
setblock 120 222 323 minecraft:stripped_spruce_log
fill 120 222 324 123 222 324 minecraft:stone
setblock 120 222 363 minecraft:stripped_spruce_log
fill 121 222 323 124 222 323 minecraft:stone
setblock 121 222 326 minecraft:stone
setblock 121 222 362 minecraft:stripped_spruce_log
fill 121 222 363 124 222 363 minecraft:stone
setblock 122 222 326 minecraft:stripped_spruce_log
fill 122 222 362 122 224 362 minecraft:stone
setblock 123 222 325 minecraft:stripped_spruce_log
fill 123 222 326 124 222 326 minecraft:stone
setblock 124 222 324 minecraft:stripped_spruce_log
fill 124 222 325 124 225 325 minecraft:stone
setblock 125 222 323 minecraft:stripped_spruce_log
fill 125 222 324 125 224 324 minecraft:stone
setblock 125 222 332 minecraft:light[level=12]
setblock 125 222 339 minecraft:light[level=12]
setblock 125 222 346 minecraft:light[level=12]
setblock 125 222 353 minecraft:light[level=12]
setblock 125 222 360 minecraft:light[level=12]
setblock 125 222 362 minecraft:stone
setblock 125 222 363 minecraft:stripped_spruce_log
fill 126 222 323 126 224 323 minecraft:stone
setblock 126 222 362 minecraft:stripped_spruce_log
fill 126 222 363 126 224 363 minecraft:stone
fill 129 222 325 129 224 326 minecraft:raw_gold_block
setblock 130 222 323 minecraft:stripped_spruce_log
fill 130 222 326 131 224 326 minecraft:raw_gold_block
setblock 130 222 363 minecraft:stripped_spruce_log
fill 131 222 323 131 224 323 minecraft:stone
fill 131 222 325 131 224 325 minecraft:raw_gold_block
fill 131 222 363 131 224 363 minecraft:stone
fill 132 222 324 132 223 324 minecraft:raw_gold_block
setblock 132 222 325 minecraft:light[level=12]
setblock 132 222 332 minecraft:light[level=12]
setblock 132 222 339 minecraft:light[level=12]
setblock 132 222 346 minecraft:light[level=12]
setblock 132 222 353 minecraft:light[level=12]
setblock 132 222 360 minecraft:light[level=12]
setblock 132 222 364 minecraft:raw_iron_block
fill 134 222 347 134 222 348 minecraft:stone
setblock 134 222 349 minecraft:stripped_spruce_log
fill 134 222 350 134 222 353 minecraft:stone
setblock 135 222 323 minecraft:stripped_spruce_log
fill 135 222 324 135 224 324 minecraft:stone
setblock 135 222 327 minecraft:stone
setblock 135 222 328 minecraft:stripped_spruce_log
setblock 135 222 343 minecraft:stripped_spruce_log
fill 135 222 344 135 224 344 minecraft:stone
setblock 135 222 348 minecraft:stripped_spruce_log
fill 135 222 349 135 224 349 minecraft:stone
fill 135 222 351 135 222 352 minecraft:stone
setblock 135 222 353 minecraft:stripped_spruce_log
fill 135 222 354 135 224 354 minecraft:stone
setblock 135 222 357 minecraft:stone
setblock 135 222 358 minecraft:stripped_spruce_log
fill 135 222 359 135 223 361 minecraft:stone
setblock 135 222 363 minecraft:stripped_spruce_log
fill 95 223 323 95 223 326 minecraft:stone
setblock 95 223 327 minecraft:stripped_spruce_log
fill 95 223 328 96 224 328 minecraft:stone
setblock 95 223 332 minecraft:stripped_spruce_log
fill 95 223 333 95 223 336 minecraft:stone
setblock 95 223 337 minecraft:stripped_spruce_log
fill 95 223 338 95 223 341 minecraft:stone
setblock 95 223 342 minecraft:stripped_spruce_log
fill 95 223 343 95 224 343 minecraft:stone
setblock 95 223 347 minecraft:stripped_spruce_log
fill 95 223 348 95 224 348 minecraft:stone
setblock 95 223 351 minecraft:stone
setblock 95 223 352 minecraft:stripped_spruce_log
fill 95 223 353 95 224 353 minecraft:stone
setblock 95 223 357 minecraft:stripped_spruce_log
fill 95 223 364 95 233 364 minecraft:andesite
fill 96 223 323 98 223 323 minecraft:stone
setblock 96 223 324 minecraft:glowstone
setblock 96 223 325 minecraft:stone
setblock 96 223 326 minecraft:stripped_spruce_log
fill 96 223 327 96 224 327 minecraft:stone
fill 96 223 329 96 223 330 minecraft:stone
setblock 96 223 331 minecraft:stripped_spruce_log
fill 96 223 332 96 224 332 minecraft:stone
setblock 96 223 340 minecraft:stone
setblock 96 223 341 minecraft:stripped_spruce_log
fill 96 223 342 97 224 342 minecraft:stone
setblock 96 223 343 minecraft:glowstone
setblock 96 223 346 minecraft:stripped_spruce_log
fill 96 223 347 96 224 347 minecraft:stone
setblock 96 223 351 minecraft:stripped_spruce_log
fill 96 223 352 96 224 352 minecraft:stone
setblock 96 223 355 minecraft:stone
setblock 96 223 362 minecraft:glowstone
setblock 97 223 324 minecraft:stone
setblock 97 223 345 minecraft:stripped_spruce_log
fill 97 223 346 97 226 346 minecraft:stone
setblock 97 223 350 minecraft:stripped_spruce_log
fill 97 223 351 98 225 351 minecraft:stone
fill 97 223 353 97 224 353 minecraft:stone
fill 97 223 363 98 223 363 minecraft:stone
setblock 98 223 324 minecraft:stripped_spruce_log
fill 98 223 345 98 226 345 minecraft:stone
setblock 98 223 349 minecraft:stripped_spruce_log
fill 98 223 350 98 226 350 minecraft:stone
setblock 99 223 323 minecraft:stripped_spruce_log
fill 99 223 324 101 223 325 minecraft:stone
setblock 99 223 352 minecraft:raw_gold_block
setblock 99 223 363 minecraft:stripped_spruce_log
fill 100 223 323 103 223 323 minecraft:stone
fill 100 223 363 100 224 363 minecraft:stone
setblock 102 223 324 minecraft:stone
setblock 102 223 325 minecraft:stripped_spruce_log
setblock 103 223 324 minecraft:stripped_spruce_log
fill 103 223 325 103 225 325 minecraft:stone
setblock 104 223 323 minecraft:stripped_spruce_log
fill 104 223 324 104 224 324 minecraft:stone
fill 105 223 323 108 223 323 minecraft:stone
setblock 108 223 324 minecraft:stripped_spruce_log
setblock 109 223 323 minecraft:stripped_spruce_log
fill 110 223 323 111 224 324 minecraft:stone
fill 111 223 336 114 267 337 minecraft:stripped_spruce_log
fill 112 223 323 113 223 323 minecraft:stone
setblock 113 223 324 minecraft:stripped_spruce_log
setblock 114 223 323 minecraft:stripped_spruce_log
fill 114 223 324 114 224 325 minecraft:stone
fill 115 223 323 118 223 323 minecraft:stone
setblock 115 223 324 minecraft:glowstone
fill 115 223 325 116 223 325 minecraft:stone
setblock 115 223 362 minecraft:glowstone
fill 115 223 363 118 223 363 minecraft:stone
fill 116 223 324 117 223 324 minecraft:stone
setblock 116 223 326 minecraft:stripped_spruce_log
setblock 117 223 325 minecraft:stripped_spruce_log
fill 117 223 326 117 226 326 minecraft:stone
setblock 118 223 324 minecraft:stripped_spruce_log
fill 118 223 325 121 223 325 minecraft:stone
fill 118 223 362 119 223 362 minecraft:stone
setblock 119 223 323 minecraft:stripped_spruce_log
fill 119 223 324 122 223 324 minecraft:stone
setblock 119 223 363 minecraft:stripped_spruce_log
fill 120 223 323 123 223 323 minecraft:stone
setblock 120 223 362 minecraft:stripped_spruce_log
fill 120 223 363 123 223 363 minecraft:stone
setblock 121 223 326 minecraft:stripped_spruce_log
fill 121 223 362 121 224 362 minecraft:stone
setblock 122 223 325 minecraft:stripped_spruce_log
fill 122 223 326 123 224 326 minecraft:stone
setblock 123 223 324 minecraft:stripped_spruce_log
fill 123 223 325 123 226 325 minecraft:stone
setblock 124 223 323 minecraft:stripped_spruce_log
fill 124 223 324 124 224 324 minecraft:stone
setblock 124 223 363 minecraft:stripped_spruce_log
fill 125 223 323 125 224 323 minecraft:stone
setblock 125 223 362 minecraft:stripped_spruce_log
fill 125 223 363 125 224 363 minecraft:stone
setblock 128 223 324 minecraft:stripped_spruce_log
setblock 129 223 323 minecraft:stripped_spruce_log
fill 129 223 327 131 224 327 minecraft:raw_gold_block
setblock 129 223 363 minecraft:stripped_spruce_log
fill 130 223 323 130 224 323 minecraft:stone
setblock 130 223 328 minecraft:raw_gold_block
fill 130 223 363 130 224 363 minecraft:stone
fill 132 223 364 132 232 364 minecraft:andesite
setblock 134 223 323 minecraft:stripped_spruce_log
setblock 134 223 324 minecraft:glowstone
setblock 134 223 343 minecraft:glowstone
fill 134 223 346 134 223 347 minecraft:stone
setblock 134 223 348 minecraft:stripped_spruce_log
fill 134 223 349 134 223 352 minecraft:stone
setblock 134 223 353 minecraft:stripped_spruce_log
fill 134 223 354 134 224 355 minecraft:stone
setblock 134 223 362 minecraft:glowstone
setblock 134 223 363 minecraft:stripped_spruce_log
fill 135 223 323 135 224 323 minecraft:stone
setblock 135 223 327 minecraft:stripped_spruce_log
fill 135 223 328 135 224 330 minecraft:stone
setblock 135 223 342 minecraft:stripped_spruce_log
fill 135 223 343 135 224 343 minecraft:stone
setblock 135 223 347 minecraft:stripped_spruce_log
fill 135 223 348 135 224 348 minecraft:stone
setblock 135 223 351 minecraft:stone
setblock 135 223 352 minecraft:stripped_spruce_log
fill 135 223 353 135 224 353 minecraft:stone
setblock 135 223 357 minecraft:stripped_spruce_log
fill 135 223 358 135 224 358 minecraft:stone
setblock 135 223 362 minecraft:stripped_spruce_log
fill 135 223 363 135 224 363 minecraft:stone
setblock 136 223 341 minecraft:gold_block
setblock 94 224 341 minecraft:diamond_block
fill 95 224 323 95 224 325 minecraft:stone
setblock 95 224 326 minecraft:stripped_spruce_log
setblock 95 224 327 minecraft:stone
fill 95 224 329 95 224 330 minecraft:stone
setblock 95 224 331 minecraft:stripped_spruce_log
fill 95 224 332 95 224 335 minecraft:stone
setblock 95 224 336 minecraft:stripped_spruce_log
fill 95 224 337 95 224 340 minecraft:stone
setblock 95 224 341 minecraft:stripped_spruce_log
setblock 95 224 342 minecraft:stone
setblock 95 224 346 minecraft:stripped_spruce_log
setblock 95 224 347 minecraft:stone
setblock 95 224 351 minecraft:stripped_spruce_log
setblock 95 224 352 minecraft:stone
fill 95 224 354 95 224 355 minecraft:stone
setblock 95 224 356 minecraft:stripped_spruce_log
fill 95 224 357 95 224 359 minecraft:stone
fill 96 224 323 97 224 323 minecraft:stone
fill 96 224 324 96 225 324 minecraft:spruce_log
setblock 96 224 325 minecraft:stripped_spruce_log
setblock 96 224 326 minecraft:stone
setblock 96 224 329 minecraft:stone
setblock 96 224 330 minecraft:stripped_spruce_log
fill 96 224 331 97 224 331 minecraft:stone
fill 96 224 333 96 224 334 minecraft:stone
setblock 96 224 335 minecraft:stripped_spruce_log
fill 96 224 336 96 224 339 minecraft:stone
setblock 96 224 340 minecraft:stripped_spruce_log
setblock 96 224 341 minecraft:stone
fill 96 224 343 96 225 343 minecraft:spruce_log
setblock 96 224 345 minecraft:stripped_spruce_log
setblock 96 224 346 minecraft:stone
setblock 96 224 350 minecraft:stripped_spruce_log
setblock 96 224 351 minecraft:stone
setblock 96 224 355 minecraft:stripped_spruce_log
setblock 96 224 356 minecraft:stone
fill 96 224 362 96 225 362 minecraft:spruce_log
setblock 97 224 324 minecraft:stripped_spruce_log
fill 97 224 327 97 224 328 minecraft:stone
setblock 97 224 329 minecraft:stripped_spruce_log
fill 97 224 330 97 227 330 minecraft:stone
fill 97 224 332 97 224 333 minecraft:stone
setblock 97 224 344 minecraft:stripped_spruce_log
fill 97 224 345 97 227 345 minecraft:stone
setblock 97 224 348 minecraft:stone
setblock 97 224 349 minecraft:stripped_spruce_log
fill 97 224 350 97 227 350 minecraft:stone
setblock 97 224 354 minecraft:stripped_spruce_log
setblock 97 224 363 minecraft:stone
setblock 98 224 323 minecraft:stripped_spruce_log
fill 98 224 324 101 224 324 minecraft:stone
setblock 98 224 344 minecraft:stone
setblock 98 224 348 minecraft:stripped_spruce_log
fill 98 224 349 98 227 349 minecraft:stone
setblock 98 224 352 minecraft:stone
setblock 98 224 363 minecraft:stripped_spruce_log
fill 99 224 323 102 224 323 minecraft:stone
fill 99 224 325 100 224 325 minecraft:stone
setblock 99 224 363 minecraft:stone
setblock 101 224 325 minecraft:stripped_spruce_log
setblock 101 224 363 minecraft:stone
setblock 102 224 324 minecraft:stripped_spruce_log
fill 102 224 325 102 225 325 minecraft:stone
setblock 103 224 323 minecraft:stripped_spruce_log
setblock 103 224 324 minecraft:stone
fill 104 224 323 107 224 323 minecraft:stone
setblock 107 224 324 minecraft:stripped_spruce_log
setblock 108 224 323 minecraft:stripped_spruce_log
setblock 108 224 324 minecraft:stone
setblock 109 224 323 minecraft:stone
fill 110 224 336 110 225 338 minecraft:cobbled_deepslate
fill 111 224 335 114 225 335 minecraft:cobbled_deepslate
setblock 112 224 323 minecraft:stone
setblock 112 224 324 minecraft:stripped_spruce_log
setblock 113 224 323 minecraft:stripped_spruce_log
fill 113 224 324 113 224 325 minecraft:stone
fill 114 224 323 117 224 323 minecraft:stone
fill 114 224 338 114 267 338 minecraft:stripped_spruce_log
fill 115 224 324 115 225 324 minecraft:spruce_log
setblock 115 224 325 minecraft:stone
setblock 115 224 326 minecraft:stripped_spruce_log
fill 115 224 336 115 225 338 minecraft:cobbled_deepslate
fill 115 224 362 115 225 362 minecraft:spruce_log
fill 115 224 363 117 224 363 minecraft:stone
setblock 116 224 324 minecraft:stone
setblock 116 224 325 minecraft:stripped_spruce_log
fill 116 224 326 116 227 326 minecraft:stone
setblock 117 224 324 minecraft:stripped_spruce_log
fill 117 224 325 120 224 325 minecraft:stone
setblock 118 224 323 minecraft:stripped_spruce_log
fill 118 224 324 121 224 324 minecraft:stone
setblock 118 224 362 minecraft:stone
setblock 118 224 363 minecraft:stripped_spruce_log
fill 119 224 323 122 224 323 minecraft:stone
setblock 119 224 327 minecraft:stripped_spruce_log
setblock 119 224 362 minecraft:stripped_spruce_log
fill 119 224 363 122 224 363 minecraft:stone
setblock 120 224 326 minecraft:stripped_spruce_log
setblock 120 224 362 minecraft:stone
setblock 121 224 325 minecraft:stripped_spruce_log
fill 121 224 326 121 226 326 minecraft:stone
setblock 122 224 324 minecraft:stripped_spruce_log
fill 122 224 325 122 227 325 minecraft:stone
setblock 123 224 323 minecraft:stripped_spruce_log
setblock 123 224 324 minecraft:stone
setblock 123 224 363 minecraft:stripped_spruce_log
setblock 124 224 323 minecraft:stone
setblock 124 224 362 minecraft:stripped_spruce_log
setblock 124 224 363 minecraft:stone
setblock 125 224 362 minecraft:stone
fill 126 224 329 134 224 329 minecraft:stripped_spruce_log
setblock 127 224 324 minecraft:stripped_spruce_log
setblock 128 224 323 minecraft:stripped_spruce_log
fill 128 224 328 134 224 328 minecraft:stripped_spruce_log
setblock 128 224 363 minecraft:stripped_spruce_log
setblock 129 224 323 minecraft:stone
setblock 129 224 363 minecraft:stone
fill 130 224 330 130 225 330 minecraft:raw_gold_block
fill 132 224 351 132 233 351 minecraft:iron_bars
setblock 133 224 323 minecraft:stripped_spruce_log
fill 133 224 349 133 224 352 minecraft:stone
setblock 133 224 363 minecraft:stripped_spruce_log
setblock 134 224 323 minecraft:stone
fill 134 224 324 134 225 324 minecraft:spruce_log
fill 134 224 343 134 225 343 minecraft:spruce_log
fill 134 224 345 134 224 346 minecraft:stone
setblock 134 224 347 minecraft:stripped_spruce_log
fill 134 224 348 134 224 351 minecraft:stone
setblock 134 224 352 minecraft:stripped_spruce_log
setblock 134 224 353 minecraft:stone
setblock 134 224 356 minecraft:stone
setblock 134 224 357 minecraft:stripped_spruce_log
fill 134 224 362 134 225 362 minecraft:spruce_log
setblock 134 224 363 minecraft:stone
setblock 135 224 325 minecraft:stone
setblock 135 224 326 minecraft:stripped_spruce_log
setblock 135 224 327 minecraft:stone
setblock 135 224 331 minecraft:stripped_spruce_log
fill 135 224 332 135 224 333 minecraft:stone
setblock 135 224 342 minecraft:stone
setblock 135 224 346 minecraft:stripped_spruce_log
setblock 135 224 347 minecraft:stone
setblock 135 224 351 minecraft:stripped_spruce_log
setblock 135 224 352 minecraft:stone
setblock 135 224 355 minecraft:stone
setblock 135 224 356 minecraft:stripped_spruce_log
setblock 135 224 357 minecraft:stone
fill 135 224 359 135 224 360 minecraft:stone
setblock 135 224 361 minecraft:stripped_spruce_log
setblock 135 224 362 minecraft:stone
setblock 136 224 333 minecraft:gold_block
fill 136 224 341 136 242 341 minecraft:andesite
setblock 136 224 350 minecraft:raw_iron_block
fill 94 225 341 94 241 341 minecraft:andesite
setblock 94 225 356 minecraft:raw_gold_block
fill 95 225 323 95 225 363 minecraft:spruce_planks
fill 96 225 323 135 225 323 minecraft:spruce_planks
fill 96 225 325 96 225 342 minecraft:spruce_planks
fill 96 225 344 96 225 361 minecraft:spruce_planks
fill 96 225 363 135 225 363 minecraft:spruce_planks
fill 97 225 324 114 225 324 minecraft:spruce_planks
fill 97 225 326 97 225 327 minecraft:stone
setblock 97 225 328 minecraft:stripped_spruce_log
fill 97 225 329 98 227 329 minecraft:stone
fill 97 225 331 97 225 332 minecraft:stone
setblock 97 225 333 minecraft:stripped_spruce_log
fill 97 225 334 97 226 336 minecraft:stone
fill 97 225 341 97 225 342 minecraft:stone
setblock 97 225 343 minecraft:stripped_spruce_log
fill 97 225 344 97 228 344 minecraft:stone
setblock 97 225 348 minecraft:stripped_spruce_log
fill 97 225 349 97 228 349 minecraft:stone
setblock 97 225 353 minecraft:stripped_spruce_log
fill 97 225 354 97 227 355 minecraft:stone
fill 97 225 362 114 225 362 minecraft:spruce_planks
fill 98 225 325 99 225 325 minecraft:stone
fill 98 225 330 98 225 331 minecraft:stone
setblock 98 225 332 minecraft:stripped_spruce_log
setblock 98 225 347 minecraft:stripped_spruce_log
fill 98 225 348 98 227 348 minecraft:stone
setblock 98 225 352 minecraft:stripped_spruce_log
fill 98 225 353 98 227 353 minecraft:stone
setblock 100 225 325 minecraft:stripped_spruce_log
fill 101 225 325 101 226 325 minecraft:stone
setblock 104 225 322 minecraft:raw_iron_block
fill 105 225 322 105 241 322 minecraft:andesite
fill 105 225 330 119 225 330 minecraft:stripped_spruce_log
fill 109 225 329 133 225 329 minecraft:stripped_spruce_log
fill 109 225 337 109 225 338 minecraft:cobbled_deepslate
setblock 110 225 335 minecraft:cobbled_deepslate
fill 111 225 334 114 225 334 minecraft:cobbled_deepslate
setblock 111 225 364 minecraft:diamond_block
fill 113 225 325 114 225 325 minecraft:stone
setblock 115 225 325 minecraft:stripped_spruce_log
fill 115 225 326 115 227 326 minecraft:stone
setblock 115 225 335 minecraft:cobbled_deepslate
setblock 115 225 339 minecraft:cobbled_deepslate
fill 116 225 324 133 225 324 minecraft:spruce_planks
fill 116 225 325 119 225 325 minecraft:stone
fill 116 225 337 116 225 338 minecraft:cobbled_deepslate
fill 116 225 362 133 225 362 minecraft:spruce_planks
fill 117 225 322 117 241 322 minecraft:andesite
setblock 118 225 322 minecraft:raw_gold_block
setblock 118 225 327 minecraft:stripped_spruce_log
setblock 119 225 326 minecraft:stripped_spruce_log
setblock 119 225 327 minecraft:stone
setblock 120 225 325 minecraft:stripped_spruce_log
fill 120 225 326 120 227 326 minecraft:stone
fill 121 225 325 121 227 325 minecraft:stone
fill 121 225 328 133 225 328 minecraft:stripped_spruce_log
setblock 122 225 326 minecraft:stone
fill 130 225 326 130 225 327 minecraft:raw_gold_block
fill 133 225 348 133 225 351 minecraft:stone
setblock 133 225 352 minecraft:stripped_spruce_log
fill 133 225 353 133 227 354 minecraft:stone
fill 134 225 325 135 225 342 minecraft:spruce_planks
fill 134 225 344 135 225 361 minecraft:spruce_planks
setblock 135 225 324 minecraft:spruce_planks
setblock 135 225 343 minecraft:spruce_planks
setblock 135 225 362 minecraft:spruce_planks
fill 136 225 333 136 238 333 minecraft:andesite
fill 136 225 350 136 241 350 minecraft:andesite
setblock 94 226 350 minecraft:raw_iron_block
fill 94 226 351 94 239 351 minecraft:andesite
setblock 94 226 352 minecraft:raw_iron_block
fill 94 226 356 94 241 356 minecraft:andesite
setblock 95 226 323 minecraft:stone
setblock 95 226 324 minecraft:stripped_spruce_log
fill 95 226 325 95 226 328 minecraft:stone
setblock 95 226 329 minecraft:stripped_spruce_log
fill 95 226 330 95 226 333 minecraft:stone
setblock 95 226 334 minecraft:stripped_spruce_log
fill 95 226 335 95 226 338 minecraft:stone
setblock 95 226 339 minecraft:stripped_spruce_log
fill 95 226 340 95 226 343 minecraft:stone
setblock 95 226 344 minecraft:stripped_spruce_log
fill 95 226 345 95 226 348 minecraft:stone
setblock 95 226 349 minecraft:stripped_spruce_log
fill 95 226 350 95 226 353 minecraft:stone
setblock 95 226 354 minecraft:stripped_spruce_log
fill 95 226 355 95 226 358 minecraft:stone
setblock 95 226 359 minecraft:stripped_spruce_log
fill 95 226 360 95 229 360 minecraft:stone
setblock 96 226 323 minecraft:stripped_spruce_log
fill 96 226 324 96 226 327 minecraft:stone
setblock 96 226 328 minecraft:stripped_spruce_log
fill 96 226 329 96 226 332 minecraft:stone
setblock 96 226 333 minecraft:stripped_spruce_log
fill 96 226 334 96 226 337 minecraft:stone
setblock 96 226 338 minecraft:stripped_spruce_log
fill 96 226 339 96 226 342 minecraft:stone
setblock 96 226 343 minecraft:stripped_spruce_log
fill 96 226 344 96 226 347 minecraft:stone
setblock 96 226 348 minecraft:stripped_spruce_log
fill 96 226 349 96 226 352 minecraft:stone
setblock 96 226 353 minecraft:stripped_spruce_log
fill 96 226 354 96 226 357 minecraft:stone
setblock 96 226 358 minecraft:stripped_spruce_log
fill 97 226 323 99 226 324 minecraft:stone
setblock 97 226 325 minecraft:light[level=15]
setblock 97 226 326 minecraft:stone
setblock 97 226 327 minecraft:stripped_spruce_log
fill 97 226 328 98 226 328 minecraft:stone
setblock 97 226 331 minecraft:stone
setblock 97 226 332 minecraft:stripped_spruce_log
fill 97 226 333 98 228 333 minecraft:stone
setblock 97 226 337 minecraft:stripped_spruce_log
fill 97 226 338 97 226 341 minecraft:stone
setblock 97 226 342 minecraft:stripped_spruce_log
fill 97 226 343 97 228 343 minecraft:stone
setblock 97 226 347 minecraft:stripped_spruce_log
fill 97 226 348 97 229 348 minecraft:stone
setblock 97 226 351 minecraft:stone
setblock 97 226 352 minecraft:stripped_spruce_log
fill 97 226 353 97 229 353 minecraft:stone
setblock 97 226 356 minecraft:stone
setblock 97 226 357 minecraft:light[level=15]
fill 97 226 363 100 226 363 minecraft:stone
setblock 98 226 330 minecraft:stone
fill 98 226 331 100 226 331 minecraft:stripped_spruce_log
fill 98 226 332 98 229 332 minecraft:stone
fill 98 226 334 98 227 334 minecraft:stone
setblock 98 226 346 minecraft:stripped_spruce_log
fill 98 226 347 98 227 347 minecraft:stone
setblock 98 226 351 minecraft:stripped_spruce_log
fill 98 226 352 98 228 352 minecraft:stone
setblock 99 226 325 minecraft:stripped_spruce_log
fill 99 226 330 116 226 330 minecraft:stripped_spruce_log
fill 99 226 350 99 235 350 minecraft:cobbled_deepslate
setblock 100 226 323 minecraft:stone
setblock 100 226 324 minecraft:stripped_spruce_log
setblock 100 226 325 minecraft:stone
setblock 101 226 323 minecraft:stripped_spruce_log
fill 101 226 324 104 226 324 minecraft:stone
fill 102 226 323 105 226 323 minecraft:stone
fill 102 226 329 124 226 329 minecraft:stripped_spruce_log
fill 104 226 322 104 240 322 minecraft:andesite
setblock 105 226 325 minecraft:light[level=15]
setblock 105 226 341 minecraft:light[level=15]
setblock 105 226 349 minecraft:light[level=15]
setblock 105 226 357 minecraft:light[level=15]
setblock 106 226 323 minecraft:stripped_spruce_log
fill 107 226 323 110 226 323 minecraft:stone
setblock 111 226 323 minecraft:stripped_spruce_log
fill 111 226 324 114 226 324 minecraft:stone
fill 111 226 364 111 239 364 minecraft:andesite
fill 112 226 323 115 226 323 minecraft:stone
setblock 113 226 325 minecraft:stone
setblock 113 226 333 minecraft:light[level=15]
setblock 113 226 349 minecraft:light[level=15]
setblock 113 226 357 minecraft:light[level=15]
setblock 114 226 325 minecraft:stripped_spruce_log
fill 114 226 363 115 226 363 minecraft:stone
setblock 115 226 324 minecraft:stripped_spruce_log
fill 115 226 325 118 226 325 minecraft:stone
setblock 116 226 323 minecraft:stripped_spruce_log
fill 116 226 324 119 226 324 minecraft:stone
setblock 116 226 362 minecraft:stone
setblock 116 226 363 minecraft:stripped_spruce_log
fill 117 226 323 120 226 323 minecraft:stone
setblock 117 226 362 minecraft:stripped_spruce_log
fill 117 226 363 120 226 363 minecraft:stone
fill 118 226 322 118 241 322 minecraft:andesite
setblock 118 226 326 minecraft:stripped_spruce_log
fill 118 226 362 121 226 362 minecraft:stone
setblock 119 226 325 minecraft:stripped_spruce_log
fill 119 226 326 119 227 326 minecraft:stone
setblock 120 226 324 minecraft:stripped_spruce_log
fill 120 226 325 120 228 325 minecraft:stone
setblock 121 226 323 minecraft:stripped_spruce_log
fill 121 226 324 124 226 324 minecraft:stone
setblock 121 226 333 minecraft:light[level=15]
setblock 121 226 341 minecraft:light[level=15]
setblock 121 226 349 minecraft:light[level=15]
setblock 121 226 357 minecraft:light[level=15]
setblock 121 226 363 minecraft:stripped_spruce_log
fill 122 226 323 125 226 323 minecraft:stone
setblock 122 226 362 minecraft:stripped_spruce_log
fill 122 226 363 125 226 363 minecraft:stone
fill 123 226 362 124 226 362 minecraft:stone
setblock 125 226 324 minecraft:stripped_spruce_log
fill 125 226 329 129 226 329 minecraft:stripped_dark_oak_log
setblock 126 226 323 minecraft:stripped_spruce_log
setblock 126 226 363 minecraft:stripped_spruce_log
setblock 127 226 323 minecraft:stone
fill 127 226 363 128 226 363 minecraft:stone
setblock 129 226 325 minecraft:light[level=15]
fill 129 226 328 133 226 328 minecraft:stripped_dark_oak_log
setblock 129 226 333 minecraft:light[level=15]
setblock 129 226 341 minecraft:light[level=15]
setblock 129 226 349 minecraft:light[level=15]
setblock 129 226 357 minecraft:light[level=15]
fill 132 226 363 135 226 363 minecraft:stone
fill 133 226 348 133 226 350 minecraft:stone
setblock 133 226 351 minecraft:stripped_spruce_log
fill 133 226 352 135 227 352 minecraft:stone
setblock 133 226 355 minecraft:stone
fill 134 226 323 135 226 323 minecraft:stone
fill 134 226 328 134 226 329 minecraft:stone
setblock 134 226 330 minecraft:stripped_spruce_log
setblock 134 226 345 minecraft:stripped_spruce_log
fill 134 226 346 134 226 349 minecraft:stone
setblock 134 226 350 minecraft:stripped_spruce_log
fill 134 226 351 135 228 351 minecraft:stone
fill 134 226 353 134 226 354 minecraft:stone
setblock 134 226 355 minecraft:stripped_spruce_log
fill 134 226 356 134 226 359 minecraft:stone
setblock 135 226 324 minecraft:stripped_spruce_log
fill 135 226 325 135 226 328 minecraft:stone
setblock 135 226 329 minecraft:stripped_spruce_log
fill 135 226 330 135 226 333 minecraft:stone
setblock 135 226 334 minecraft:stripped_spruce_log
fill 135 226 335 135 226 338 minecraft:stone
setblock 135 226 339 minecraft:stripped_spruce_log
fill 135 226 340 135 226 343 minecraft:stone
setblock 135 226 344 minecraft:stripped_spruce_log
fill 135 226 345 135 226 348 minecraft:stone
setblock 135 226 349 minecraft:stripped_spruce_log
fill 135 226 350 135 229 350 minecraft:stone
setblock 135 226 353 minecraft:stone
setblock 135 226 354 minecraft:stripped_spruce_log
fill 135 226 355 135 226 358 minecraft:stone
setblock 135 226 359 minecraft:stripped_spruce_log
fill 135 226 360 135 227 362 minecraft:stone
setblock 136 226 343 minecraft:raw_iron_block
fill 94 227 350 94 241 350 minecraft:andesite
fill 94 227 352 94 236 352 minecraft:andesite
setblock 95 227 323 minecraft:stripped_spruce_log
fill 95 227 324 95 227 327 minecraft:stone
setblock 95 227 328 minecraft:stripped_spruce_log
fill 95 227 329 95 227 332 minecraft:stone
setblock 95 227 333 minecraft:stripped_spruce_log
fill 95 227 334 95 227 337 minecraft:stone
setblock 95 227 338 minecraft:stripped_spruce_log
fill 95 227 339 95 227 342 minecraft:stone
setblock 95 227 343 minecraft:stripped_spruce_log
fill 95 227 344 95 227 347 minecraft:stone
setblock 95 227 348 minecraft:stripped_spruce_log
fill 95 227 349 95 227 352 minecraft:stone
setblock 95 227 353 minecraft:stripped_spruce_log
fill 95 227 354 95 227 357 minecraft:stone
setblock 95 227 358 minecraft:stripped_spruce_log
fill 95 227 359 95 230 359 minecraft:stone
fill 95 227 361 95 228 361 minecraft:stone
fill 96 227 323 99 227 323 minecraft:stone
fill 96 227 325 96 227 326 minecraft:stone
setblock 96 227 327 minecraft:stripped_spruce_log
fill 96 227 328 96 227 331 minecraft:stone
setblock 96 227 332 minecraft:stripped_spruce_log
fill 96 227 333 96 227 336 minecraft:stone
setblock 96 227 337 minecraft:stripped_spruce_log
fill 96 227 338 96 227 341 minecraft:stone
setblock 96 227 342 minecraft:stripped_spruce_log
fill 96 227 343 96 227 346 minecraft:stone
setblock 96 227 347 minecraft:stripped_spruce_log
fill 96 227 348 96 227 351 minecraft:stone
setblock 96 227 352 minecraft:stripped_spruce_log
fill 96 227 353 96 227 356 minecraft:stone
setblock 96 227 357 minecraft:stripped_spruce_log
fill 96 227 358 96 230 358 minecraft:stone
fill 97 227 324 98 227 324 minecraft:stone
fill 97 227 327 97 228 328 minecraft:stone
setblock 97 227 331 minecraft:stripped_spruce_log
fill 97 227 332 97 230 332 minecraft:stone
fill 97 227 334 97 227 335 minecraft:stone
setblock 97 227 336 minecraft:stripped_spruce_log
fill 97 227 337 97 227 340 minecraft:stone
setblock 97 227 341 minecraft:stripped_spruce_log
setblock 97 227 342 minecraft:stone
setblock 97 227 346 minecraft:stripped_spruce_log
fill 97 227 347 97 229 347 minecraft:stone
setblock 97 227 351 minecraft:stripped_spruce_log
fill 97 227 352 97 230 352 minecraft:stone
setblock 97 227 356 minecraft:stripped_spruce_log
fill 98 227 330 104 227 330 minecraft:stripped_spruce_log
fill 98 227 331 98 229 331 minecraft:stone
setblock 98 227 335 minecraft:stripped_spruce_log
setblock 98 227 350 minecraft:stripped_spruce_log
fill 98 227 351 98 228 351 minecraft:stone
setblock 99 227 324 minecraft:stripped_spruce_log
setblock 100 227 323 minecraft:stripped_spruce_log
fill 100 227 324 102 227 324 minecraft:stone
fill 101 227 323 104 227 323 minecraft:stone
setblock 102 227 322 minecraft:gold_block
setblock 105 227 323 minecraft:stripped_spruce_log
fill 105 227 330 111 227 330 minecraft:stripped_dark_oak_log
fill 108 227 323 109 227 323 minecraft:stone
setblock 110 227 323 minecraft:stripped_spruce_log
fill 110 227 329 122 227 329 minecraft:stripped_dark_oak_log
fill 111 227 323 113 227 324 minecraft:stone
setblock 113 227 325 minecraft:stripped_spruce_log
setblock 114 227 323 minecraft:stone
setblock 114 227 324 minecraft:stripped_spruce_log
fill 114 227 325 117 227 325 minecraft:stone
setblock 114 227 363 minecraft:stone
setblock 115 227 323 minecraft:stripped_spruce_log
fill 115 227 324 118 227 324 minecraft:stone
setblock 115 227 363 minecraft:stripped_spruce_log
fill 116 227 323 119 227 323 minecraft:stone
setblock 116 227 362 minecraft:stripped_spruce_log
fill 116 227 363 119 227 363 minecraft:stone
setblock 117 227 326 minecraft:stripped_spruce_log
fill 117 227 362 120 227 362 minecraft:stone
setblock 118 227 325 minecraft:stripped_spruce_log
setblock 118 227 326 minecraft:stone
setblock 119 227 324 minecraft:stripped_spruce_log
fill 119 227 325 119 228 325 minecraft:stone
setblock 120 227 323 minecraft:stripped_spruce_log
fill 120 227 324 123 227 324 minecraft:stone
setblock 120 227 363 minecraft:stripped_spruce_log
fill 121 227 323 124 227 323 minecraft:stone
setblock 121 227 362 minecraft:stripped_spruce_log
fill 121 227 363 124 227 363 minecraft:stone
fill 122 227 362 123 227 362 minecraft:stone
setblock 124 227 324 minecraft:stripped_spruce_log
setblock 125 227 323 minecraft:stripped_spruce_log
setblock 125 227 363 minecraft:stripped_spruce_log
setblock 126 227 323 minecraft:stone
fill 126 227 363 127 227 363 minecraft:stone
fill 132 227 363 134 227 363 minecraft:stone
fill 133 227 348 133 227 349 minecraft:stone
setblock 133 227 350 minecraft:stripped_spruce_log
fill 133 227 351 133 230 351 minecraft:stone
setblock 133 227 355 minecraft:stripped_spruce_log
fill 133 227 356 135 228 356 minecraft:stone
setblock 134 227 328 minecraft:stone
setblock 134 227 329 minecraft:stripped_spruce_log
fill 134 227 330 135 227 332 minecraft:stone
fill 134 227 345 134 227 348 minecraft:stone
setblock 134 227 349 minecraft:stripped_spruce_log
fill 134 227 350 134 230 350 minecraft:stone
setblock 134 227 353 minecraft:stone
setblock 134 227 354 minecraft:stripped_spruce_log
fill 134 227 355 135 229 355 minecraft:stone
fill 134 227 357 134 227 358 minecraft:stone
setblock 134 227 359 minecraft:stripped_spruce_log
fill 134 227 360 134 230 360 minecraft:stone
setblock 135 227 323 minecraft:stripped_spruce_log
fill 135 227 324 135 227 327 minecraft:stone
setblock 135 227 328 minecraft:stripped_spruce_log
fill 135 227 329 135 230 329 minecraft:stone
setblock 135 227 333 minecraft:stripped_spruce_log
fill 135 227 334 135 227 337 minecraft:stone
setblock 135 227 338 minecraft:stripped_spruce_log
fill 135 227 339 135 227 342 minecraft:stone
setblock 135 227 343 minecraft:stripped_spruce_log
fill 135 227 344 135 227 347 minecraft:stone
setblock 135 227 348 minecraft:stripped_spruce_log
fill 135 227 349 135 230 349 minecraft:stone
setblock 135 227 353 minecraft:stripped_spruce_log
fill 135 227 354 135 230 354 minecraft:stone
setblock 135 227 357 minecraft:stone
setblock 135 227 358 minecraft:stripped_spruce_log
fill 135 227 359 135 230 359 minecraft:stone
setblock 135 227 363 minecraft:stripped_spruce_log
fill 136 227 343 136 241 343 minecraft:andesite
fill 95 228 324 95 228 326 minecraft:stone
setblock 95 228 327 minecraft:stripped_spruce_log
fill 95 228 328 95 228 331 minecraft:stone
setblock 95 228 332 minecraft:stripped_spruce_log
fill 95 228 333 95 228 336 minecraft:stone
setblock 95 228 337 minecraft:stripped_spruce_log
fill 95 228 338 95 228 341 minecraft:stone
setblock 95 228 342 minecraft:stripped_spruce_log
fill 95 228 343 95 228 346 minecraft:stone
setblock 95 228 347 minecraft:stripped_spruce_log
fill 95 228 348 95 228 351 minecraft:stone
setblock 95 228 352 minecraft:stripped_spruce_log
fill 95 228 353 95 228 356 minecraft:stone
setblock 95 228 357 minecraft:stripped_spruce_log
fill 95 228 358 95 231 358 minecraft:stone
fill 96 228 323 98 228 323 minecraft:stone
setblock 96 228 325 minecraft:stone
setblock 96 228 326 minecraft:stripped_spruce_log
fill 96 228 327 96 228 330 minecraft:stone
setblock 96 228 331 minecraft:stripped_spruce_log
fill 96 228 332 96 228 335 minecraft:stone
setblock 96 228 336 minecraft:stripped_spruce_log
fill 96 228 337 96 228 340 minecraft:stone
setblock 96 228 341 minecraft:stripped_spruce_log
fill 96 228 342 96 228 345 minecraft:stone
setblock 96 228 346 minecraft:stripped_spruce_log
fill 96 228 347 96 228 350 minecraft:stone
setblock 96 228 351 minecraft:stripped_spruce_log
fill 96 228 352 96 228 355 minecraft:stone
setblock 96 228 356 minecraft:stripped_spruce_log
fill 96 228 357 96 231 357 minecraft:stone
fill 97 228 324 97 238 324 minecraft:iron_bars
setblock 97 228 325 minecraft:light[level=12]
setblock 97 228 329 minecraft:stone
setblock 97 228 330 minecraft:stripped_spruce_log
fill 97 228 331 97 231 331 minecraft:stone
setblock 97 228 334 minecraft:stone
setblock 97 228 335 minecraft:stripped_spruce_log
fill 97 228 336 97 228 339 minecraft:stone
setblock 97 228 340 minecraft:stripped_spruce_log
setblock 97 228 345 minecraft:stripped_spruce_log
fill 97 228 346 97 229 346 minecraft:stone
setblock 97 228 350 minecraft:stripped_spruce_log
fill 97 228 351 97 230 351 minecraft:stone
setblock 97 228 354 minecraft:stone
setblock 97 228 355 minecraft:stripped_spruce_log
fill 97 228 356 97 229 356 minecraft:stone
setblock 97 228 360 minecraft:light[level=12]
setblock 98 228 329 minecraft:stripped_spruce_log
fill 98 228 330 98 229 330 minecraft:stone
setblock 98 228 334 minecraft:stripped_spruce_log
fill 98 228 335 98 231 335 minecraft:stone
setblock 98 228 349 minecraft:stripped_spruce_log
setblock 98 228 350 minecraft:stone
fill 98 228 364 98 241 364 minecraft:andesite
setblock 99 228 323 minecraft:stripped_spruce_log
fill 99 228 330 103 228 330 minecraft:stripped_dark_oak_log
setblock 99 228 364 minecraft:raw_iron_block
fill 100 228 323 103 228 323 minecraft:stone
fill 100 228 364 100 241 364 minecraft:andesite
fill 102 228 322 102 241 322 minecraft:andesite
setblock 104 228 325 minecraft:light[level=12]
setblock 104 228 332 minecraft:light[level=12]
setblock 104 228 339 minecraft:light[level=12]
setblock 104 228 346 minecraft:light[level=12]
setblock 104 228 353 minecraft:light[level=12]
setblock 104 228 360 minecraft:light[level=12]
fill 110 228 323 113 228 323 minecraft:stone
setblock 111 228 325 minecraft:light[level=12]
setblock 111 228 332 minecraft:light[level=12]
setblock 111 228 339 minecraft:light[level=12]
setblock 111 228 346 minecraft:light[level=12]
setblock 111 228 353 minecraft:light[level=12]
setblock 111 228 360 minecraft:light[level=12]
setblock 112 228 324 minecraft:stone
setblock 113 228 324 minecraft:stripped_spruce_log
setblock 113 228 363 minecraft:stone
setblock 114 228 323 minecraft:stripped_spruce_log
fill 114 228 324 116 228 325 minecraft:stone
setblock 114 228 363 minecraft:stripped_spruce_log
fill 115 228 323 118 228 323 minecraft:stone
fill 115 228 363 118 228 363 minecraft:stone
fill 116 228 362 119 228 362 minecraft:stone
setblock 117 228 324 minecraft:stone
setblock 117 228 325 minecraft:stripped_spruce_log
setblock 117 228 326 minecraft:stone
setblock 118 228 324 minecraft:stripped_spruce_log
fill 118 228 325 118 229 325 minecraft:stone
setblock 118 228 332 minecraft:light[level=12]
setblock 118 228 339 minecraft:light[level=12]
setblock 118 228 346 minecraft:light[level=12]
setblock 118 228 353 minecraft:light[level=12]
setblock 118 228 360 minecraft:light[level=12]
setblock 119 228 323 minecraft:stripped_spruce_log
fill 119 228 324 122 228 324 minecraft:stone
setblock 119 228 363 minecraft:stripped_spruce_log
fill 120 228 323 123 228 323 minecraft:stone
setblock 120 228 362 minecraft:stripped_spruce_log
fill 120 228 363 123 228 363 minecraft:stone
fill 121 228 362 122 228 362 minecraft:stone
setblock 122 228 322 minecraft:raw_gold_block
setblock 124 228 323 minecraft:stripped_spruce_log
setblock 124 228 363 minecraft:stripped_spruce_log
setblock 125 228 325 minecraft:light[level=12]
setblock 125 228 332 minecraft:light[level=12]
setblock 125 228 339 minecraft:light[level=12]
setblock 125 228 346 minecraft:light[level=12]
setblock 125 228 353 minecraft:light[level=12]
setblock 125 228 360 minecraft:light[level=12]
setblock 125 228 363 minecraft:stone
setblock 132 228 325 minecraft:light[level=12]
setblock 132 228 332 minecraft:light[level=12]
setblock 132 228 339 minecraft:light[level=12]
setblock 132 228 346 minecraft:light[level=12]
setblock 132 228 353 minecraft:light[level=12]
setblock 132 228 360 minecraft:light[level=12]
setblock 133 228 349 minecraft:stripped_spruce_log
fill 133 228 350 133 231 350 minecraft:stone
fill 133 228 352 133 228 353 minecraft:stone
setblock 133 228 354 minecraft:stripped_spruce_log
fill 133 228 355 133 231 355 minecraft:stone
fill 133 228 357 134 228 357 minecraft:stone
setblock 133 228 363 minecraft:stone
fill 134 228 329 134 228 332 minecraft:stone
setblock 134 228 333 minecraft:stripped_spruce_log
fill 134 228 334 135 230 334 minecraft:stone
fill 134 228 345 134 228 347 minecraft:stone
setblock 134 228 348 minecraft:stripped_spruce_log
fill 134 228 349 134 231 349 minecraft:stone
setblock 134 228 352 minecraft:stone
setblock 134 228 353 minecraft:stripped_spruce_log
fill 134 228 354 134 231 354 minecraft:stone
setblock 134 228 358 minecraft:stripped_spruce_log
fill 134 228 359 134 231 359 minecraft:stone
setblock 134 228 363 minecraft:stripped_spruce_log
fill 135 228 324 135 228 326 minecraft:stone
setblock 135 228 327 minecraft:stripped_spruce_log
fill 135 228 328 135 231 328 minecraft:stone
fill 135 228 330 135 228 331 minecraft:stone
setblock 135 228 332 minecraft:stripped_spruce_log
fill 135 228 333 135 231 333 minecraft:stone
fill 135 228 335 135 228 336 minecraft:stone
setblock 135 228 337 minecraft:stripped_spruce_log
fill 135 228 338 135 228 341 minecraft:stone
setblock 135 228 342 minecraft:stripped_spruce_log
fill 135 228 343 135 228 346 minecraft:stone
setblock 135 228 347 minecraft:stripped_spruce_log
fill 135 228 348 135 231 348 minecraft:stone
setblock 135 228 352 minecraft:stripped_spruce_log
fill 135 228 353 135 231 353 minecraft:stone
setblock 135 228 357 minecraft:stripped_spruce_log
fill 135 228 358 135 231 358 minecraft:stone
fill 135 228 360 135 228 361 minecraft:stone
setblock 135 228 362 minecraft:stripped_spruce_log
fill 135 228 363 135 231 363 minecraft:stone
setblock 95 229 322 minecraft:diamond_block
fill 95 229 324 95 229 325 minecraft:stone
setblock 95 229 326 minecraft:stripped_spruce_log
fill 95 229 327 95 229 330 minecraft:stone
setblock 95 229 331 minecraft:stripped_spruce_log
fill 95 229 332 95 229 335 minecraft:stone
setblock 95 229 336 minecraft:stripped_spruce_log
fill 95 229 337 95 229 340 minecraft:stone
setblock 95 229 341 minecraft:stripped_spruce_log
fill 95 229 342 95 229 345 minecraft:stone
setblock 95 229 346 minecraft:stripped_spruce_log
fill 95 229 347 95 229 350 minecraft:stone
setblock 95 229 351 minecraft:stripped_spruce_log
fill 95 229 352 95 229 355 minecraft:stone
setblock 95 229 356 minecraft:stripped_spruce_log
fill 95 229 357 95 232 357 minecraft:stone
setblock 95 229 361 minecraft:stripped_spruce_log
fill 96 229 323 97 229 323 minecraft:stone
fill 96 229 326 96 229 329 minecraft:stone
setblock 96 229 330 minecraft:stripped_spruce_log
fill 96 229 331 96 229 334 minecraft:stone
setblock 96 229 335 minecraft:stripped_spruce_log
fill 96 229 336 96 229 339 minecraft:stone
setblock 96 229 340 minecraft:stripped_spruce_log
fill 96 229 341 96 229 344 minecraft:stone
setblock 96 229 345 minecraft:stripped_spruce_log
fill 96 229 346 96 229 349 minecraft:stone
setblock 96 229 350 minecraft:stripped_spruce_log
fill 96 229 351 96 229 354 minecraft:stone
setblock 96 229 355 minecraft:stripped_spruce_log
fill 96 229 356 96 232 356 minecraft:stone
setblock 97 229 328 minecraft:stone
setblock 97 229 329 minecraft:stripped_spruce_log
fill 97 229 330 97 232 330 minecraft:stone
setblock 97 229 333 minecraft:stone
setblock 97 229 334 minecraft:stripped_spruce_log
fill 97 229 335 97 229 338 minecraft:stone
setblock 97 229 339 minecraft:stripped_spruce_log
setblock 97 229 349 minecraft:stripped_spruce_log
fill 97 229 350 97 230 350 minecraft:stone
setblock 97 229 354 minecraft:stripped_spruce_log
fill 97 229 355 97 230 355 minecraft:stone
setblock 98 229 323 minecraft:stripped_spruce_log
setblock 98 229 333 minecraft:stripped_spruce_log
fill 98 229 334 98 231 334 minecraft:stone
fill 99 229 323 100 229 323 minecraft:stone
fill 99 229 364 99 241 364 minecraft:andesite
fill 110 229 323 112 229 323 minecraft:stone
fill 111 229 338 111 267 338 minecraft:stripped_spruce_log
setblock 112 229 324 minecraft:stripped_spruce_log
setblock 113 229 323 minecraft:stripped_spruce_log
fill 113 229 324 116 229 324 minecraft:stone
setblock 113 229 363 minecraft:stripped_spruce_log
fill 114 229 323 117 229 323 minecraft:stone
fill 114 229 363 117 229 363 minecraft:stone
setblock 115 229 325 minecraft:stone
fill 115 229 362 118 229 362 minecraft:stone
setblock 116 229 325 minecraft:stripped_spruce_log
setblock 117 229 324 minecraft:stripped_spruce_log
setblock 117 229 325 minecraft:stone
setblock 118 229 323 minecraft:stripped_spruce_log
fill 118 229 324 121 229 324 minecraft:stone
setblock 118 229 363 minecraft:stripped_spruce_log
fill 119 229 323 122 229 323 minecraft:stone
setblock 119 229 362 minecraft:stripped_spruce_log
fill 119 229 363 122 229 363 minecraft:stone
fill 120 229 362 121 229 362 minecraft:stone
fill 122 229 322 122 239 322 minecraft:andesite
setblock 123 229 323 minecraft:stripped_spruce_log
setblock 123 229 363 minecraft:stripped_spruce_log
setblock 124 229 363 minecraft:stone
setblock 133 229 349 minecraft:stone
setblock 133 229 352 minecraft:stone
setblock 133 229 353 minecraft:stripped_spruce_log
fill 133 229 354 133 232 354 minecraft:stone
fill 133 229 356 133 229 357 minecraft:stone
setblock 133 229 363 minecraft:stripped_spruce_log
fill 134 229 330 134 229 331 minecraft:stone
setblock 134 229 332 minecraft:stripped_spruce_log
fill 134 229 333 134 232 333 minecraft:stone
fill 134 229 335 135 229 335 minecraft:stone
fill 134 229 345 134 229 346 minecraft:stone
setblock 134 229 347 minecraft:stripped_spruce_log
fill 134 229 348 134 232 348 minecraft:stone
setblock 134 229 351 minecraft:stone
setblock 134 229 352 minecraft:stripped_spruce_log
fill 134 229 353 134 232 353 minecraft:stone
setblock 134 229 356 minecraft:stone
setblock 134 229 357 minecraft:stripped_spruce_log
fill 134 229 358 134 232 358 minecraft:stone
fill 134 229 363 134 232 363 minecraft:stone
setblock 135 229 325 minecraft:stone
setblock 135 229 326 minecraft:stripped_spruce_log
fill 135 229 327 135 230 327 minecraft:stone
setblock 135 229 330 minecraft:stone
setblock 135 229 331 minecraft:stripped_spruce_log
fill 135 229 332 135 232 332 minecraft:stone
setblock 135 229 336 minecraft:stripped_spruce_log
fill 135 229 337 135 229 340 minecraft:stone
setblock 135 229 341 minecraft:stripped_spruce_log
fill 135 229 342 135 229 345 minecraft:stone
setblock 135 229 346 minecraft:stripped_spruce_log
fill 135 229 347 135 232 347 minecraft:stone
setblock 135 229 351 minecraft:stripped_spruce_log
fill 135 229 352 135 232 352 minecraft:stone
setblock 135 229 356 minecraft:stripped_spruce_log
fill 135 229 357 135 232 357 minecraft:stone
setblock 135 229 360 minecraft:stone
setblock 135 229 361 minecraft:stripped_spruce_log
fill 135 229 362 135 232 362 minecraft:stone
fill 94 230 331 94 242 331 minecraft:andesite
setblock 94 230 332 minecraft:raw_iron_block
fill 94 230 333 94 233 333 minecraft:andesite
setblock 94 230 360 minecraft:raw_gold_block
fill 95 230 322 95 241 322 minecraft:andesite
setblock 95 230 325 minecraft:stripped_spruce_log
fill 95 230 326 95 230 329 minecraft:stone
setblock 95 230 330 minecraft:stripped_spruce_log
fill 95 230 331 95 230 334 minecraft:stone
setblock 95 230 335 minecraft:stripped_spruce_log
fill 95 230 336 95 230 339 minecraft:stone
setblock 95 230 340 minecraft:stripped_spruce_log
fill 95 230 341 95 230 344 minecraft:stone
setblock 95 230 345 minecraft:stripped_spruce_log
fill 95 230 346 95 230 349 minecraft:stone
setblock 95 230 350 minecraft:stripped_spruce_log
fill 95 230 351 95 230 354 minecraft:stone
setblock 95 230 355 minecraft:stripped_spruce_log
fill 95 230 356 95 233 356 minecraft:stone
setblock 95 230 360 minecraft:stripped_spruce_log
fill 95 230 361 95 233 361 minecraft:stone
fill 96 230 327 96 230 328 minecraft:stone
setblock 96 230 329 minecraft:stripped_spruce_log
fill 96 230 330 96 230 333 minecraft:stone
setblock 96 230 334 minecraft:stripped_spruce_log
fill 96 230 335 96 230 338 minecraft:stone
setblock 96 230 339 minecraft:stripped_spruce_log
fill 96 230 340 96 230 343 minecraft:stone
setblock 96 230 344 minecraft:stripped_spruce_log
fill 96 230 345 96 230 348 minecraft:stone
setblock 96 230 349 minecraft:stripped_spruce_log
fill 96 230 350 96 230 353 minecraft:stone
setblock 96 230 354 minecraft:stripped_spruce_log
fill 96 230 355 96 233 355 minecraft:stone
setblock 97 230 329 minecraft:stone
setblock 97 230 333 minecraft:stripped_spruce_log
fill 97 230 334 97 230 337 minecraft:stone
setblock 97 230 338 minecraft:stripped_spruce_log
fill 97 230 339 97 233 339 minecraft:stone
setblock 97 230 349 minecraft:stone
setblock 97 230 353 minecraft:stripped_spruce_log
setblock 97 230 354 minecraft:stone
setblock 98 230 332 minecraft:stripped_spruce_log
fill 98 230 333 98 231 333 minecraft:stone
setblock 111 230 323 minecraft:stone
setblock 112 230 323 minecraft:stripped_spruce_log
fill 113 230 323 115 230 324 minecraft:stone
fill 113 230 338 113 267 338 minecraft:stripped_spruce_log
fill 113 230 363 116 230 363 minecraft:stone
fill 115 230 362 117 230 362 minecraft:stone
setblock 116 230 323 minecraft:stone
setblock 116 230 324 minecraft:stripped_spruce_log
setblock 117 230 323 minecraft:stripped_spruce_log
fill 117 230 324 119 230 324 minecraft:stone
setblock 117 230 363 minecraft:stripped_spruce_log
fill 118 230 323 121 230 323 minecraft:stone
setblock 118 230 362 minecraft:stripped_spruce_log
fill 118 230 363 121 230 363 minecraft:stone
fill 119 230 362 120 232 362 minecraft:stone
setblock 122 230 363 minecraft:stripped_spruce_log
setblock 123 230 363 minecraft:stone
setblock 133 230 352 minecraft:stripped_spruce_log
fill 133 230 353 133 233 353 minecraft:stone
setblock 133 230 356 minecraft:stone
setblock 133 230 357 minecraft:stripped_spruce_log
setblock 134 230 331 minecraft:stripped_spruce_log
fill 134 230 332 134 233 332 minecraft:stone
setblock 134 230 335 minecraft:stone
setblock 134 230 336 minecraft:stripped_spruce_log
setblock 134 230 346 minecraft:stripped_spruce_log
fill 134 230 347 134 233 347 minecraft:stone
setblock 134 230 351 minecraft:stripped_spruce_log
fill 134 230 352 134 233 352 minecraft:stone
setblock 134 230 355 minecraft:stone
setblock 134 230 356 minecraft:stripped_spruce_log
fill 134 230 357 134 233 357 minecraft:stone
setblock 135 230 322 minecraft:raw_iron_block
setblock 135 230 330 minecraft:stripped_spruce_log
fill 135 230 331 135 233 331 minecraft:stone
setblock 135 230 335 minecraft:stripped_spruce_log
fill 135 230 336 135 230 339 minecraft:stone
setblock 135 230 340 minecraft:stripped_spruce_log
fill 135 230 341 135 230 344 minecraft:stone
setblock 135 230 345 minecraft:stripped_spruce_log
fill 135 230 346 135 233 346 minecraft:stone
setblock 135 230 350 minecraft:stripped_spruce_log
fill 135 230 351 135 233 351 minecraft:stone
setblock 135 230 355 minecraft:stripped_spruce_log
fill 135 230 356 135 233 356 minecraft:stone
setblock 135 230 360 minecraft:stripped_spruce_log
fill 135 230 361 135 233 361 minecraft:stone
fill 136 230 322 136 241 322 minecraft:andesite
fill 94 231 332 94 242 332 minecraft:andesite
fill 94 231 360 94 241 360 minecraft:andesite
fill 95 231 326 95 231 328 minecraft:stone
setblock 95 231 329 minecraft:stripped_spruce_log
fill 95 231 330 95 231 333 minecraft:stone
setblock 95 231 334 minecraft:stripped_spruce_log
fill 95 231 335 95 231 338 minecraft:stone
setblock 95 231 339 minecraft:stripped_spruce_log
fill 95 231 340 95 231 343 minecraft:stone
setblock 95 231 344 minecraft:stripped_spruce_log
fill 95 231 345 95 231 348 minecraft:stone
setblock 95 231 349 minecraft:stripped_spruce_log
fill 95 231 350 95 231 353 minecraft:stone
setblock 95 231 354 minecraft:stripped_spruce_log
fill 95 231 355 95 234 355 minecraft:stone
setblock 95 231 359 minecraft:stripped_spruce_log
fill 95 231 360 95 234 360 minecraft:stone
setblock 96 231 328 minecraft:stripped_spruce_log
fill 96 231 329 96 231 332 minecraft:stone
setblock 96 231 333 minecraft:stripped_spruce_log
fill 96 231 334 96 231 337 minecraft:stone
setblock 96 231 338 minecraft:stripped_spruce_log
fill 96 231 339 96 231 342 minecraft:stone
setblock 96 231 343 minecraft:stripped_spruce_log
fill 96 231 344 96 231 347 minecraft:stone
setblock 96 231 348 minecraft:stripped_spruce_log
fill 96 231 349 96 231 352 minecraft:stone
setblock 96 231 353 minecraft:stripped_spruce_log
fill 96 231 354 96 234 354 minecraft:stone
setblock 96 231 358 minecraft:stripped_spruce_log
setblock 97 231 332 minecraft:stripped_spruce_log
fill 97 231 333 97 231 336 minecraft:stone
setblock 97 231 337 minecraft:stripped_spruce_log
fill 97 231 338 97 234 338 minecraft:stone
fill 98 231 350 98 235 350 minecraft:cobbled_deepslate
fill 99 231 349 99 235 349 minecraft:cobbled_deepslate
fill 99 231 351 99 235 351 minecraft:cobbled_deepslate
fill 100 231 350 100 235 350 minecraft:cobbled_deepslate
setblock 111 231 323 minecraft:stripped_spruce_log
fill 112 231 323 115 231 323 minecraft:stone
fill 112 231 363 115 231 363 minecraft:stone
setblock 114 231 324 minecraft:stone
setblock 115 231 324 minecraft:stripped_spruce_log
fill 115 231 362 116 231 362 minecraft:stone
setblock 116 231 323 minecraft:stripped_spruce_log
fill 116 231 324 117 231 324 minecraft:stone
setblock 116 231 363 minecraft:stripped_spruce_log
fill 117 231 323 120 231 323 minecraft:stone
setblock 117 231 362 minecraft:stripped_spruce_log
fill 117 231 363 120 231 363 minecraft:stone
fill 118 231 362 118 234 362 minecraft:stone
setblock 121 231 363 minecraft:stripped_spruce_log
fill 122 231 363 122 234 363 minecraft:stone
setblock 133 231 351 minecraft:stripped_spruce_log
fill 133 231 352 133 234 352 minecraft:stone
setblock 133 231 356 minecraft:stripped_spruce_log
fill 133 231 357 133 233 358 minecraft:stone
setblock 134 231 331 minecraft:stone
setblock 134 231 334 minecraft:stone
setblock 134 231 335 minecraft:stripped_spruce_log
fill 134 231 336 135 231 338 minecraft:stone
setblock 134 231 346 minecraft:stone
setblock 134 231 350 minecraft:stripped_spruce_log
fill 134 231 351 134 234 351 minecraft:stone
setblock 134 231 355 minecraft:stripped_spruce_log
fill 134 231 356 134 234 356 minecraft:stone
setblock 134 231 360 minecraft:stripped_spruce_log
fill 135 231 322 135 238 322 minecraft:andesite
setblock 135 231 329 minecraft:stripped_spruce_log
fill 135 231 330 135 234 330 minecraft:stone
setblock 135 231 334 minecraft:stripped_spruce_log
fill 135 231 335 135 234 335 minecraft:stone
setblock 135 231 339 minecraft:stripped_spruce_log
fill 135 231 340 135 231 343 minecraft:stone
setblock 135 231 344 minecraft:stripped_spruce_log
fill 135 231 345 135 234 345 minecraft:stone
setblock 135 231 349 minecraft:stripped_spruce_log
fill 135 231 350 135 234 350 minecraft:stone
setblock 135 231 354 minecraft:stripped_spruce_log
fill 135 231 355 135 234 355 minecraft:stone
setblock 135 231 359 minecraft:stripped_spruce_log
fill 135 231 360 135 234 360 minecraft:stone
fill 136 231 357 136 231 360 minecraft:andesite
setblock 136 231 361 minecraft:gold_block
fill 95 232 326 95 232 327 minecraft:stone
setblock 95 232 328 minecraft:stripped_spruce_log
fill 95 232 329 95 232 332 minecraft:stone
setblock 95 232 333 minecraft:stripped_spruce_log
fill 95 232 334 95 232 337 minecraft:stone
setblock 95 232 338 minecraft:stripped_spruce_log
fill 95 232 339 95 232 342 minecraft:stone
setblock 95 232 343 minecraft:stripped_spruce_log
fill 95 232 344 95 232 347 minecraft:stone
setblock 95 232 348 minecraft:stripped_spruce_log
fill 95 232 349 95 232 352 minecraft:stone
setblock 95 232 353 minecraft:stripped_spruce_log
fill 95 232 354 95 235 354 minecraft:stone
setblock 95 232 358 minecraft:stripped_spruce_log
fill 95 232 359 95 235 359 minecraft:stone
fill 96 232 328 96 232 331 minecraft:stone
setblock 96 232 332 minecraft:stripped_spruce_log
fill 96 232 333 96 232 336 minecraft:stone
setblock 96 232 337 minecraft:stripped_spruce_log
fill 96 232 338 96 232 341 minecraft:stone
setblock 96 232 342 minecraft:stripped_spruce_log
fill 96 232 343 96 234 343 minecraft:stone
fill 96 232 348 96 232 351 minecraft:stone
setblock 96 232 352 minecraft:stripped_spruce_log
fill 96 232 353 96 234 353 minecraft:stone
setblock 96 232 357 minecraft:stripped_spruce_log
fill 96 232 358 96 235 358 minecraft:stone
setblock 97 232 331 minecraft:stripped_spruce_log
fill 97 232 332 97 232 335 minecraft:stone
setblock 97 232 336 minecraft:stripped_spruce_log
fill 97 232 337 97 235 337 minecraft:stone
setblock 99 232 322 minecraft:diamond_block
fill 103 232 344 103 233 344 minecraft:raw_gold_block
fill 111 232 323 114 232 323 minecraft:stone
fill 112 232 338 112 267 338 minecraft:stripped_spruce_log
fill 112 232 363 114 232 363 minecraft:stone
setblock 114 232 324 minecraft:stripped_spruce_log
fill 114 232 362 115 232 362 minecraft:stone
setblock 115 232 323 minecraft:stripped_spruce_log
fill 115 232 324 116 232 324 minecraft:stone
setblock 115 232 363 minecraft:stripped_spruce_log
fill 116 232 323 119 232 323 minecraft:stone
setblock 116 232 362 minecraft:stripped_spruce_log
fill 116 232 363 119 232 363 minecraft:stone
fill 117 232 362 117 235 362 minecraft:stone
setblock 120 232 363 minecraft:stripped_spruce_log
fill 121 232 363 121 235 363 minecraft:stone
fill 133 232 351 133 234 351 minecraft:stone
setblock 133 232 355 minecraft:stripped_spruce_log
fill 133 232 356 133 235 356 minecraft:stone
fill 133 232 363 133 233 363 minecraft:stone
setblock 134 232 334 minecraft:stripped_spruce_log
fill 134 232 335 134 232 338 minecraft:stone
setblock 134 232 339 minecraft:stripped_spruce_log
fill 134 232 340 135 234 340 minecraft:stone
setblock 134 232 349 minecraft:stripped_spruce_log
fill 134 232 350 134 235 350 minecraft:stone
setblock 134 232 354 minecraft:stripped_spruce_log
fill 134 232 355 134 235 355 minecraft:stone
setblock 134 232 359 minecraft:stripped_spruce_log
fill 134 232 360 134 234 361 minecraft:stone
setblock 135 232 328 minecraft:stripped_spruce_log
fill 135 232 329 135 235 329 minecraft:stone
setblock 135 232 333 minecraft:stripped_spruce_log
fill 135 232 334 135 235 334 minecraft:stone
fill 135 232 336 135 232 337 minecraft:stone
setblock 135 232 338 minecraft:stripped_spruce_log
fill 135 232 339 135 235 339 minecraft:stone
fill 135 232 341 135 232 342 minecraft:stone
setblock 135 232 343 minecraft:stripped_spruce_log
fill 135 232 344 135 235 344 minecraft:stone
setblock 135 232 348 minecraft:stripped_spruce_log
fill 135 232 349 135 235 349 minecraft:stone
setblock 135 232 353 minecraft:stripped_spruce_log
fill 135 232 354 135 235 354 minecraft:stone
setblock 135 232 358 minecraft:stripped_spruce_log
fill 135 232 359 135 235 359 minecraft:stone
setblock 135 232 363 minecraft:stripped_spruce_log
setblock 136 232 357 minecraft:andesite
setblock 136 232 358 minecraft:raw_gold_block
fill 136 232 359 136 237 361 minecraft:andesite
setblock 95 233 326 minecraft:stone
setblock 95 233 327 minecraft:stripped_spruce_log
fill 95 233 328 95 233 331 minecraft:stone
setblock 95 233 332 minecraft:stripped_spruce_log
fill 95 233 333 95 233 336 minecraft:stone
setblock 95 233 337 minecraft:stripped_spruce_log
fill 95 233 338 95 233 341 minecraft:stone
setblock 95 233 342 minecraft:stripped_spruce_log
fill 95 233 343 95 233 346 minecraft:stone
setblock 95 233 347 minecraft:stripped_spruce_log
fill 95 233 348 95 233 351 minecraft:stone
setblock 95 233 352 minecraft:stripped_spruce_log
fill 95 233 353 95 236 353 minecraft:stone
setblock 95 233 357 minecraft:stripped_spruce_log
fill 95 233 358 95 236 358 minecraft:stone
fill 96 233 323 96 234 325 minecraft:iron_bars
fill 96 233 329 96 233 330 minecraft:stone
setblock 96 233 331 minecraft:stripped_spruce_log
fill 96 233 332 96 233 335 minecraft:stone
setblock 96 233 336 minecraft:stripped_spruce_log
fill 96 233 337 96 233 340 minecraft:stone
setblock 96 233 341 minecraft:stripped_spruce_log
fill 96 233 342 96 236 342 minecraft:stone
setblock 96 233 351 minecraft:stripped_spruce_log
setblock 96 233 352 minecraft:stone
setblock 96 233 356 minecraft:stripped_spruce_log
fill 96 233 357 96 236 357 minecraft:stone
fill 97 233 331 97 233 334 minecraft:stone
setblock 97 233 335 minecraft:stripped_spruce_log
fill 97 233 336 97 236 336 minecraft:stone
fill 98 233 349 98 235 349 minecraft:cobbled_deepslate
fill 98 233 351 98 235 351 minecraft:cobbled_deepslate
fill 99 233 322 99 239 322 minecraft:andesite
fill 100 233 349 100 235 349 minecraft:cobbled_deepslate
fill 100 233 351 100 235 351 minecraft:cobbled_deepslate
fill 110 233 323 113 233 323 minecraft:stone
fill 111 233 363 113 233 363 minecraft:stone
setblock 112 233 322 minecraft:raw_gold_block
fill 113 233 362 114 233 362 minecraft:stone
setblock 114 233 323 minecraft:stripped_spruce_log
fill 114 233 324 114 236 324 minecraft:stone
setblock 114 233 363 minecraft:stripped_spruce_log
setblock 115 233 322 minecraft:gold_block
fill 115 233 323 118 233 323 minecraft:stone
setblock 115 233 362 minecraft:stripped_spruce_log
fill 115 233 363 118 233 363 minecraft:stone
setblock 116 233 361 minecraft:stripped_spruce_log
fill 116 233 362 116 236 362 minecraft:stone
setblock 119 233 362 minecraft:stone
setblock 119 233 363 minecraft:stripped_spruce_log
setblock 120 233 362 minecraft:stripped_spruce_log
fill 120 233 363 120 236 363 minecraft:stone
fill 131 233 363 132 234 363 minecraft:stone
setblock 132 233 364 minecraft:diamond_block
setblock 133 233 354 minecraft:stripped_spruce_log
fill 133 233 355 133 236 355 minecraft:stone
setblock 133 233 359 minecraft:stripped_spruce_log
setblock 134 233 333 minecraft:stripped_spruce_log
fill 134 233 334 134 233 337 minecraft:stone
setblock 134 233 338 minecraft:stripped_spruce_log
fill 134 233 339 134 236 339 minecraft:stone
fill 134 233 341 134 233 342 minecraft:stone
setblock 134 233 348 minecraft:stripped_spruce_log
fill 134 233 349 134 236 349 minecraft:stone
setblock 134 233 353 minecraft:stripped_spruce_log
fill 134 233 354 134 236 354 minecraft:stone
setblock 134 233 358 minecraft:stripped_spruce_log
fill 134 233 359 134 236 359 minecraft:stone
setblock 134 233 363 minecraft:stripped_spruce_log
setblock 135 233 332 minecraft:stripped_spruce_log
fill 135 233 333 135 236 333 minecraft:stone
setblock 135 233 336 minecraft:stone
setblock 135 233 337 minecraft:stripped_spruce_log
fill 135 233 338 135 236 338 minecraft:stone
setblock 135 233 341 minecraft:stone
setblock 135 233 342 minecraft:stripped_spruce_log
fill 135 233 343 135 236 343 minecraft:stone
setblock 135 233 347 minecraft:stripped_spruce_log
fill 135 233 348 135 236 348 minecraft:stone
setblock 135 233 352 minecraft:stripped_spruce_log
fill 135 233 353 135 236 353 minecraft:stone
setblock 135 233 357 minecraft:stripped_spruce_log
fill 135 233 358 135 236 358 minecraft:stone
setblock 135 233 362 minecraft:stripped_spruce_log
fill 135 233 363 135 236 363 minecraft:stone
setblock 136 233 357 minecraft:raw_gold_block
fill 136 233 358 136 237 358 minecraft:andesite
setblock 94 234 333 minecraft:raw_gold_block
setblock 95 234 326 minecraft:stripped_spruce_log
fill 95 234 327 95 234 330 minecraft:stone
setblock 95 234 331 minecraft:stripped_spruce_log
fill 95 234 332 95 234 335 minecraft:stone
setblock 95 234 336 minecraft:stripped_spruce_log
fill 95 234 337 95 234 340 minecraft:stone
setblock 95 234 341 minecraft:stripped_spruce_log
fill 95 234 342 95 234 345 minecraft:stone
setblock 95 234 346 minecraft:stripped_spruce_log
fill 95 234 347 95 234 350 minecraft:stone
setblock 95 234 351 minecraft:stripped_spruce_log
fill 95 234 352 95 237 352 minecraft:stone
setblock 95 234 356 minecraft:stripped_spruce_log
fill 95 234 357 95 237 357 minecraft:stone
setblock 95 234 361 minecraft:stripped_spruce_log
fill 95 234 362 95 237 362 minecraft:stone
setblock 95 234 364 minecraft:diamond_block
setblock 96 234 329 minecraft:stone
setblock 96 234 330 minecraft:stripped_spruce_log
fill 96 234 331 96 234 334 minecraft:stone
setblock 96 234 335 minecraft:stripped_spruce_log
fill 96 234 336 96 234 339 minecraft:stone
setblock 96 234 340 minecraft:stripped_spruce_log
fill 96 234 341 96 237 341 minecraft:stone
setblock 96 234 355 minecraft:stripped_spruce_log
fill 96 234 356 96 237 356 minecraft:stone
setblock 97 234 325 minecraft:light[level=15]
fill 97 234 331 97 234 333 minecraft:stone
setblock 97 234 334 minecraft:stripped_spruce_log
fill 97 234 335 97 237 335 minecraft:stone
setblock 97 234 339 minecraft:stripped_spruce_log
fill 97 234 340 97 237 340 minecraft:stone
setblock 97 234 341 minecraft:light[level=15]
setblock 97 234 346 minecraft:light[level=12]
setblock 97 234 349 minecraft:light[level=15]
setblock 97 234 353 minecraft:light[level=12]
setblock 97 234 357 minecraft:light[level=15]
setblock 97 234 360 minecraft:light[level=12]
fill 103 234 344 103 240 344 minecraft:cobbled_deepslate
setblock 104 234 325 minecraft:light[level=12]
setblock 104 234 332 minecraft:light[level=12]
setblock 104 234 339 minecraft:light[level=12]
setblock 104 234 346 minecraft:light[level=12]
setblock 104 234 353 minecraft:light[level=12]
setblock 104 234 360 minecraft:light[level=12]
setblock 104 234 364 minecraft:diamond_block
setblock 105 234 325 minecraft:light[level=15]
setblock 105 234 341 minecraft:light[level=15]
setblock 105 234 349 minecraft:light[level=15]
setblock 105 234 357 minecraft:light[level=15]
fill 105 234 364 106 237 364 minecraft:andesite
fill 110 234 323 112 234 323 minecraft:stone
fill 110 234 363 112 234 363 minecraft:stone
setblock 111 234 325 minecraft:light[level=12]
setblock 111 234 332 minecraft:light[level=12]
setblock 111 234 339 minecraft:light[level=12]
setblock 111 234 346 minecraft:light[level=12]
setblock 111 234 353 minecraft:light[level=12]
setblock 111 234 360 minecraft:light[level=12]
fill 111 234 362 113 234 362 minecraft:stone
fill 112 234 322 112 241 322 minecraft:andesite
setblock 113 234 323 minecraft:stripped_spruce_log
fill 113 234 324 113 237 324 minecraft:stone
setblock 113 234 325 minecraft:light[level=15]
setblock 113 234 333 minecraft:light[level=15]
setblock 113 234 349 minecraft:light[level=15]
setblock 113 234 357 minecraft:light[level=15]
setblock 113 234 363 minecraft:stripped_spruce_log
fill 114 234 323 117 234 323 minecraft:stone
setblock 114 234 361 minecraft:stone
setblock 114 234 362 minecraft:stripped_spruce_log
fill 114 234 363 117 234 363 minecraft:stone
fill 115 234 322 115 241 322 minecraft:andesite
setblock 115 234 361 minecraft:stripped_spruce_log
setblock 115 234 362 minecraft:stone
fill 116 234 361 118 235 361 minecraft:stone
setblock 118 234 323 minecraft:stripped_spruce_log
setblock 118 234 325 minecraft:light[level=12]
setblock 118 234 332 minecraft:light[level=12]
setblock 118 234 339 minecraft:light[level=12]
setblock 118 234 346 minecraft:light[level=12]
setblock 118 234 353 minecraft:light[level=12]
setblock 118 234 360 minecraft:light[level=12]
setblock 118 234 363 minecraft:stripped_spruce_log
setblock 119 234 362 minecraft:stripped_spruce_log
fill 119 234 363 119 237 363 minecraft:stone
fill 120 234 362 120 237 362 minecraft:stone
setblock 121 234 325 minecraft:light[level=15]
setblock 121 234 333 minecraft:light[level=15]
setblock 121 234 341 minecraft:light[level=15]
setblock 121 234 349 minecraft:light[level=15]
setblock 121 234 357 minecraft:light[level=15]
setblock 125 234 325 minecraft:light[level=12]
setblock 125 234 332 minecraft:light[level=12]
setblock 125 234 339 minecraft:light[level=12]
setblock 125 234 346 minecraft:light[level=12]
setblock 125 234 353 minecraft:light[level=12]
setblock 125 234 360 minecraft:light[level=12]
setblock 129 234 325 minecraft:light[level=15]
setblock 129 234 333 minecraft:light[level=15]
setblock 129 234 341 minecraft:light[level=15]
setblock 129 234 349 minecraft:light[level=15]
setblock 129 234 357 minecraft:light[level=15]
fill 130 234 363 130 236 363 minecraft:stone
setblock 132 234 325 minecraft:light[level=12]
setblock 132 234 332 minecraft:light[level=12]
setblock 132 234 339 minecraft:light[level=12]
setblock 132 234 346 minecraft:light[level=12]
setblock 132 234 353 minecraft:light[level=12]
setblock 132 234 360 minecraft:light[level=12]
fill 132 234 364 132 241 364 minecraft:andesite
setblock 133 234 353 minecraft:stripped_spruce_log
fill 133 234 354 133 237 354 minecraft:stone
setblock 133 234 357 minecraft:stone
setblock 133 234 358 minecraft:stripped_spruce_log
fill 133 234 359 133 237 359 minecraft:stone
setblock 133 234 362 minecraft:stone
setblock 133 234 363 minecraft:stripped_spruce_log
setblock 134 234 332 minecraft:stripped_spruce_log
fill 134 234 333 134 234 336 minecraft:stone
setblock 134 234 337 minecraft:stripped_spruce_log
fill 134 234 338 134 237 338 minecraft:stone
setblock 134 234 341 minecraft:stone
setblock 134 234 342 minecraft:stripped_spruce_log
fill 134 234 343 134 234 346 minecraft:stone
setblock 134 234 347 minecraft:stripped_spruce_log
fill 134 234 348 134 237 348 minecraft:stone
setblock 134 234 352 minecraft:stripped_spruce_log
fill 134 234 353 134 237 353 minecraft:stone
setblock 134 234 357 minecraft:stripped_spruce_log
fill 134 234 358 134 237 358 minecraft:stone
setblock 134 234 362 minecraft:stripped_spruce_log
fill 134 234 363 134 237 363 minecraft:stone
setblock 135 234 331 minecraft:stripped_spruce_log
fill 135 234 332 135 237 332 minecraft:stone
setblock 135 234 336 minecraft:stripped_spruce_log
fill 135 234 337 135 237 337 minecraft:stone
setblock 135 234 341 minecraft:stripped_spruce_log
fill 135 234 342 135 237 342 minecraft:stone
setblock 135 234 346 minecraft:stripped_spruce_log
fill 135 234 347 135 237 347 minecraft:stone
setblock 135 234 351 minecraft:stripped_spruce_log
fill 135 234 352 135 237 352 minecraft:stone
setblock 135 234 356 minecraft:stripped_spruce_log
fill 135 234 357 135 237 357 minecraft:stone
setblock 135 234 361 minecraft:stripped_spruce_log
fill 135 234 362 135 237 362 minecraft:stone
fill 136 234 357 136 242 357 minecraft:andesite
fill 94 235 333 94 241 333 minecraft:andesite
fill 95 235 326 95 235 329 minecraft:stone
setblock 95 235 330 minecraft:stripped_spruce_log
fill 95 235 331 95 235 334 minecraft:stone
setblock 95 235 335 minecraft:stripped_spruce_log
fill 95 235 336 95 235 339 minecraft:stone
setblock 95 235 340 minecraft:stripped_spruce_log
fill 95 235 341 95 235 344 minecraft:stone
setblock 95 235 345 minecraft:stripped_spruce_log
fill 95 235 346 95 235 349 minecraft:stone
setblock 95 235 350 minecraft:stripped_spruce_log
fill 95 235 351 95 238 351 minecraft:stone
setblock 95 235 355 minecraft:stripped_spruce_log
fill 95 235 356 95 238 356 minecraft:stone
setblock 95 235 360 minecraft:stripped_spruce_log
fill 95 235 361 95 238 361 minecraft:stone
fill 95 235 363 96 235 363 minecraft:stone
fill 95 235 364 95 241 364 minecraft:andesite
fill 96 235 324 96 238 324 minecraft:spruce_log
setblock 96 235 329 minecraft:stripped_spruce_log
fill 96 235 330 96 235 333 minecraft:stone
setblock 96 235 334 minecraft:stripped_spruce_log
fill 96 235 335 96 235 338 minecraft:stone
setblock 96 235 339 minecraft:stripped_spruce_log
fill 96 235 340 96 238 340 minecraft:stone
fill 96 235 343 96 238 343 minecraft:spruce_log
setblock 96 235 344 minecraft:stripped_spruce_log
setblock 96 235 354 minecraft:stripped_spruce_log
fill 96 235 355 96 236 355 minecraft:stone
setblock 96 235 359 minecraft:stripped_spruce_log
fill 96 235 362 96 238 362 minecraft:spruce_log
setblock 97 235 332 minecraft:stone
setblock 97 235 333 minecraft:stripped_spruce_log
fill 97 235 334 97 238 334 minecraft:stone
setblock 97 235 338 minecraft:stripped_spruce_log
fill 97 235 339 97 238 339 minecraft:stone
fill 104 235 364 104 238 364 minecraft:andesite
fill 108 235 323 111 235 323 minecraft:stone
fill 108 235 363 111 235 363 minecraft:stone
fill 110 235 362 112 235 362 minecraft:stone
setblock 112 235 323 minecraft:stripped_spruce_log
fill 112 235 324 112 238 324 minecraft:stone
fill 112 235 361 113 235 361 minecraft:stone
setblock 112 235 363 minecraft:stripped_spruce_log
fill 113 235 323 116 235 323 minecraft:stone
setblock 113 235 362 minecraft:stripped_spruce_log
fill 113 235 363 116 235 363 minecraft:stone
setblock 114 235 361 minecraft:stripped_spruce_log
fill 114 235 362 114 238 362 minecraft:stone
fill 115 235 324 115 238 324 minecraft:spruce_log
fill 115 235 361 115 238 361 minecraft:stone
fill 115 235 362 115 238 362 minecraft:spruce_log
setblock 116 235 364 minecraft:raw_iron_block
setblock 117 235 323 minecraft:stripped_spruce_log
setblock 117 235 363 minecraft:stripped_spruce_log
fill 117 235 364 119 237 364 minecraft:andesite
fill 118 235 323 118 238 323 minecraft:stone
setblock 118 235 362 minecraft:stripped_spruce_log
fill 118 235 363 118 238 363 minecraft:stone
fill 119 235 362 119 238 362 minecraft:stone
fill 121 235 362 121 236 362 minecraft:stone
setblock 122 235 363 minecraft:stripped_spruce_log
fill 123 235 363 124 237 363 minecraft:stone
setblock 127 235 363 minecraft:stripped_spruce_log
fill 128 235 363 129 237 363 minecraft:stone
fill 130 235 362 132 235 362 minecraft:stone
setblock 131 235 363 minecraft:stone
setblock 132 235 363 minecraft:stripped_spruce_log
fill 133 235 335 133 235 336 minecraft:stone
setblock 133 235 337 minecraft:stripped_spruce_log
fill 133 235 338 133 236 340 minecraft:stone
setblock 133 235 352 minecraft:stripped_spruce_log
fill 133 235 353 133 238 353 minecraft:stone
setblock 133 235 357 minecraft:stripped_spruce_log
fill 133 235 358 133 238 358 minecraft:stone
fill 133 235 360 134 235 360 minecraft:stone
setblock 133 235 362 minecraft:stripped_spruce_log
fill 133 235 363 133 238 363 minecraft:stone
fill 134 235 324 134 238 324 minecraft:spruce_log
fill 134 235 332 134 235 335 minecraft:stone
setblock 134 235 336 minecraft:stripped_spruce_log
fill 134 235 337 134 238 337 minecraft:stone
setblock 134 235 340 minecraft:stone
setblock 134 235 341 minecraft:stripped_spruce_log
fill 134 235 342 134 238 342 minecraft:stone
fill 134 235 343 134 238 343 minecraft:spruce_log
fill 134 235 344 134 235 345 minecraft:stone
setblock 134 235 346 minecraft:stripped_spruce_log
fill 134 235 347 134 238 347 minecraft:stone
setblock 134 235 351 minecraft:stripped_spruce_log
fill 134 235 352 134 238 352 minecraft:stone
setblock 134 235 356 minecraft:stripped_spruce_log
fill 134 235 357 134 238 357 minecraft:stone
setblock 134 235 361 minecraft:stripped_spruce_log
fill 134 235 362 134 238 362 minecraft:spruce_log
setblock 135 235 330 minecraft:stripped_spruce_log
fill 135 235 331 135 238 331 minecraft:stone
setblock 135 235 335 minecraft:stripped_spruce_log
fill 135 235 336 135 238 336 minecraft:stone
setblock 135 235 340 minecraft:stripped_spruce_log
fill 135 235 341 135 238 341 minecraft:stone
setblock 135 235 345 minecraft:stripped_spruce_log
fill 135 235 346 135 238 346 minecraft:stone
setblock 135 235 350 minecraft:stripped_spruce_log
fill 135 235 351 135 238 351 minecraft:stone
setblock 135 235 355 minecraft:stripped_spruce_log
fill 135 235 356 135 238 356 minecraft:stone
setblock 135 235 360 minecraft:stripped_spruce_log
fill 135 235 361 135 238 361 minecraft:stone
setblock 94 236 344 minecraft:raw_iron_block
fill 94 236 345 94 241 345 minecraft:andesite
setblock 95 236 323 minecraft:stone
setblock 95 236 324 minecraft:stripped_spruce_log
fill 95 236 325 95 236 328 minecraft:stone
setblock 95 236 329 minecraft:stripped_spruce_log
fill 95 236 330 95 236 333 minecraft:stone
setblock 95 236 334 minecraft:stripped_spruce_log
fill 95 236 335 95 236 338 minecraft:stone
setblock 95 236 339 minecraft:stripped_spruce_log
fill 95 236 340 95 236 343 minecraft:stone
setblock 95 236 344 minecraft:stripped_spruce_log
fill 95 236 345 95 236 348 minecraft:stone
setblock 95 236 349 minecraft:stripped_spruce_log
fill 95 236 350 95 239 350 minecraft:stone
setblock 95 236 354 minecraft:stripped_spruce_log
fill 95 236 355 95 239 355 minecraft:stone
setblock 95 236 359 minecraft:stripped_spruce_log
fill 95 236 360 96 238 360 minecraft:stone
setblock 95 236 363 minecraft:stone
setblock 96 236 323 minecraft:stripped_spruce_log
fill 96 236 329 96 236 332 minecraft:stone
setblock 96 236 333 minecraft:stripped_spruce_log
fill 96 236 334 96 236 337 minecraft:stone
setblock 96 236 338 minecraft:stripped_spruce_log
fill 96 236 339 96 239 339 minecraft:stone
fill 96 236 344 96 239 344 minecraft:stone
setblock 96 236 358 minecraft:stripped_spruce_log
fill 96 236 359 96 239 359 minecraft:stone
setblock 96 236 363 minecraft:stripped_spruce_log
fill 97 236 323 97 239 323 minecraft:stone
setblock 97 236 332 minecraft:stripped_spruce_log
fill 97 236 333 97 238 333 minecraft:stone
setblock 97 236 337 minecraft:stripped_spruce_log
fill 97 236 338 97 239 338 minecraft:stone
setblock 97 236 341 minecraft:stone
fill 97 236 363 97 239 363 minecraft:stone
fill 102 236 344 102 240 344 minecraft:cobbled_deepslate
fill 103 236 343 103 240 343 minecraft:cobbled_deepslate
fill 103 236 345 103 240 345 minecraft:cobbled_deepslate
fill 104 236 344 104 240 344 minecraft:cobbled_deepslate
fill 107 236 323 110 236 323 minecraft:stone
fill 107 236 363 110 236 363 minecraft:stone
fill 108 236 362 111 236 362 minecraft:stone
setblock 110 236 324 minecraft:stripped_spruce_log
fill 110 236 361 112 236 361 minecraft:stone
setblock 111 236 323 minecraft:stripped_spruce_log
fill 111 236 324 111 239 324 minecraft:stone
setblock 111 236 363 minecraft:stripped_spruce_log
fill 112 236 323 115 236 323 minecraft:stone
setblock 112 236 362 minecraft:stripped_spruce_log
fill 112 236 363 115 236 363 minecraft:stone
setblock 113 236 360 minecraft:stone
setblock 113 236 361 minecraft:stripped_spruce_log
fill 113 236 362 113 239 362 minecraft:stone
setblock 114 236 360 minecraft:stripped_spruce_log
fill 114 236 361 114 239 361 minecraft:stone
fill 115 236 360 116 238 360 minecraft:stone
setblock 116 236 323 minecraft:stripped_spruce_log
fill 116 236 361 117 236 361 minecraft:stone
setblock 116 236 363 minecraft:stripped_spruce_log
fill 116 236 364 116 241 364 minecraft:andesite
fill 117 236 323 117 239 323 minecraft:stone
setblock 117 236 362 minecraft:stripped_spruce_log
fill 117 236 363 117 239 363 minecraft:stone
setblock 118 236 361 minecraft:stripped_spruce_log
fill 118 236 362 118 239 362 minecraft:stone
fill 119 236 361 119 239 361 minecraft:stone
setblock 121 236 363 minecraft:stripped_spruce_log
setblock 122 236 362 minecraft:stripped_spruce_log
fill 122 236 363 122 239 363 minecraft:stone
setblock 125 236 363 minecraft:stone
setblock 126 236 363 minecraft:stripped_spruce_log
setblock 127 236 362 minecraft:stripped_spruce_log
fill 127 236 363 127 239 363 minecraft:stone
fill 128 236 362 131 236 362 minecraft:stone
fill 130 236 361 132 236 361 minecraft:stone
setblock 131 236 363 minecraft:stripped_spruce_log
setblock 132 236 357 minecraft:stripped_spruce_log
setblock 132 236 362 minecraft:stripped_spruce_log
fill 132 236 363 132 239 363 minecraft:stone
fill 133 236 334 133 236 335 minecraft:stone
setblock 133 236 336 minecraft:stripped_spruce_log
fill 133 236 337 133 239 337 minecraft:stone
setblock 133 236 341 minecraft:stripped_spruce_log
fill 133 236 342 133 238 343 minecraft:stone
setblock 133 236 351 minecraft:stripped_spruce_log
fill 133 236 352 133 239 352 minecraft:stone
setblock 133 236 356 minecraft:stripped_spruce_log
fill 133 236 357 133 239 357 minecraft:stone
setblock 133 236 360 minecraft:stone
setblock 133 236 361 minecraft:stripped_spruce_log
fill 133 236 362 133 239 362 minecraft:stone
fill 134 236 332 134 236 334 minecraft:stone
setblock 134 236 335 minecraft:stripped_spruce_log
fill 134 236 336 134 239 336 minecraft:stone
setblock 134 236 340 minecraft:stripped_spruce_log
fill 134 236 341 134 239 341 minecraft:stone
setblock 134 236 344 minecraft:stone
setblock 134 236 345 minecraft:stripped_spruce_log
fill 134 236 346 134 239 346 minecraft:stone
setblock 134 236 350 minecraft:stripped_spruce_log
fill 134 236 351 134 239 351 minecraft:stone
setblock 134 236 355 minecraft:stripped_spruce_log
fill 134 236 356 134 239 356 minecraft:stone
setblock 134 236 360 minecraft:stripped_spruce_log
fill 134 236 361 134 239 361 minecraft:stone
setblock 135 236 329 minecraft:stripped_spruce_log
fill 135 236 330 135 239 330 minecraft:stone
setblock 135 236 334 minecraft:stripped_spruce_log
fill 135 236 335 135 239 335 minecraft:stone
setblock 135 236 339 minecraft:stripped_spruce_log
fill 135 236 340 135 239 340 minecraft:stone
setblock 135 236 344 minecraft:stripped_spruce_log
fill 135 236 345 135 239 345 minecraft:stone
setblock 135 236 349 minecraft:stripped_spruce_log
fill 135 236 350 135 239 350 minecraft:stone
setblock 135 236 354 minecraft:stripped_spruce_log
fill 135 236 355 135 239 355 minecraft:stone
setblock 135 236 359 minecraft:stripped_spruce_log
fill 135 236 360 135 239 360 minecraft:stone
setblock 94 237 344 minecraft:andesite
setblock 94 237 352 minecraft:raw_gold_block
setblock 94 237 363 minecraft:raw_gold_block
setblock 95 237 323 minecraft:stripped_spruce_log
fill 95 237 324 95 237 327 minecraft:stone
setblock 95 237 328 minecraft:stripped_spruce_log
fill 95 237 329 95 237 332 minecraft:stone
setblock 95 237 333 minecraft:stripped_spruce_log
fill 95 237 334 95 237 337 minecraft:stone
setblock 95 237 338 minecraft:stripped_spruce_log
fill 95 237 339 95 237 342 minecraft:stone
setblock 95 237 343 minecraft:stripped_spruce_log
fill 95 237 344 95 237 347 minecraft:stone
setblock 95 237 348 minecraft:stripped_spruce_log
fill 95 237 349 95 240 349 minecraft:stone
setblock 95 237 353 minecraft:stripped_spruce_log
fill 95 237 354 95 240 354 minecraft:stone
setblock 95 237 358 minecraft:stripped_spruce_log
fill 95 237 359 95 240 359 minecraft:stone
setblock 95 237 363 minecraft:stripped_spruce_log
fill 96 237 323 96 240 323 minecraft:stone
fill 96 237 329 96 237 331 minecraft:stone
setblock 96 237 332 minecraft:stripped_spruce_log
fill 96 237 333 96 237 336 minecraft:stone
setblock 96 237 337 minecraft:stripped_spruce_log
fill 96 237 338 96 240 338 minecraft:stone
setblock 96 237 342 minecraft:stripped_spruce_log
fill 96 237 345 96 238 345 minecraft:stone
setblock 96 237 357 minecraft:stripped_spruce_log
fill 96 237 358 96 239 358 minecraft:stone
setblock 96 237 361 minecraft:stone
fill 96 237 363 96 240 363 minecraft:stone
setblock 97 237 336 minecraft:stripped_spruce_log
fill 97 237 337 97 240 337 minecraft:stone
setblock 97 237 341 minecraft:stripped_spruce_log
fill 98 237 323 98 238 323 minecraft:stone
fill 98 237 363 98 238 363 minecraft:stone
fill 102 237 343 102 240 343 minecraft:cobbled_deepslate
fill 102 237 345 102 240 345 minecraft:cobbled_deepslate
fill 104 237 343 104 240 343 minecraft:cobbled_deepslate
fill 104 237 345 104 240 345 minecraft:cobbled_deepslate
setblock 105 237 323 minecraft:stripped_spruce_log
setblock 105 237 363 minecraft:stripped_spruce_log
fill 106 237 323 109 237 323 minecraft:stone
fill 106 237 363 109 237 363 minecraft:stone
fill 107 237 362 110 237 362 minecraft:stone
setblock 108 237 324 minecraft:stone
setblock 109 237 324 minecraft:stripped_spruce_log
fill 109 237 361 111 237 361 minecraft:stone
setblock 110 237 323 minecraft:stripped_spruce_log
fill 110 237 324 110 240 324 minecraft:stone
setblock 110 237 363 minecraft:stripped_spruce_log
fill 111 237 323 114 237 323 minecraft:stone
fill 111 237 360 112 237 360 minecraft:stone
setblock 111 237 362 minecraft:stripped_spruce_log
fill 111 237 363 114 237 363 minecraft:stone
setblock 112 237 361 minecraft:stripped_spruce_log
fill 112 237 362 112 240 362 minecraft:stone
setblock 113 237 360 minecraft:stripped_spruce_log
fill 113 237 361 113 240 361 minecraft:stone
setblock 114 237 324 minecraft:stripped_spruce_log
fill 114 237 360 114 240 360 minecraft:stone
setblock 115 237 323 minecraft:stripped_spruce_log
setblock 115 237 363 minecraft:stripped_spruce_log
fill 116 237 323 116 239 324 minecraft:stone
setblock 116 237 361 minecraft:stone
setblock 116 237 362 minecraft:stripped_spruce_log
fill 116 237 363 116 240 363 minecraft:stone
setblock 117 237 360 minecraft:stone
setblock 117 237 361 minecraft:stripped_spruce_log
fill 117 237 362 117 240 362 minecraft:stone
fill 118 237 361 118 240 361 minecraft:stone
setblock 119 237 323 minecraft:stone
fill 120 237 361 120 238 361 minecraft:stone
setblock 120 237 363 minecraft:stripped_spruce_log
setblock 121 237 362 minecraft:stripped_spruce_log
fill 121 237 363 121 240 363 minecraft:stone
fill 122 237 362 125 237 362 minecraft:stone
setblock 125 237 363 minecraft:stripped_spruce_log
setblock 126 237 362 minecraft:stripped_spruce_log
fill 126 237 363 126 240 363 minecraft:stone
fill 127 237 362 130 237 362 minecraft:stone
fill 128 237 361 131 237 361 minecraft:stone
setblock 130 237 363 minecraft:stripped_spruce_log
setblock 131 237 362 minecraft:stripped_spruce_log
fill 131 237 363 131 240 363 minecraft:stone
fill 132 237 323 134 237 323 minecraft:stone
fill 132 237 338 132 237 340 minecraft:stone
setblock 132 237 356 minecraft:stripped_spruce_log
fill 132 237 357 132 238 359 minecraft:stone
setblock 132 237 361 minecraft:stripped_spruce_log
fill 132 237 362 132 240 362 minecraft:stone
setblock 133 237 334 minecraft:stone
setblock 133 237 335 minecraft:stripped_spruce_log
fill 133 237 336 133 240 336 minecraft:stone
fill 133 237 338 133 237 339 minecraft:stone
setblock 133 237 340 minecraft:stripped_spruce_log
fill 133 237 341 133 240 341 minecraft:stone
setblock 133 237 344 minecraft:stone
setblock 133 237 345 minecraft:stripped_spruce_log
fill 133 237 346 133 240 346 minecraft:stone
fill 133 237 351 133 238 351 minecraft:stone
setblock 133 237 355 minecraft:stripped_spruce_log
fill 133 237 356 133 240 356 minecraft:stone
setblock 133 237 360 minecraft:stripped_spruce_log
fill 133 237 361 133 240 361 minecraft:stone
fill 134 237 331 134 237 333 minecraft:stone
setblock 134 237 334 minecraft:stripped_spruce_log
fill 134 237 335 134 240 335 minecraft:stone
setblock 134 237 339 minecraft:stripped_spruce_log
fill 134 237 340 134 240 340 minecraft:stone
setblock 134 237 344 minecraft:stripped_spruce_log
fill 134 237 345 134 240 345 minecraft:stone
setblock 134 237 349 minecraft:stripped_spruce_log
fill 134 237 350 134 240 350 minecraft:stone
setblock 134 237 354 minecraft:stripped_spruce_log
fill 134 237 355 134 240 355 minecraft:stone
setblock 134 237 359 minecraft:stripped_spruce_log
fill 134 237 360 134 240 360 minecraft:stone
fill 135 237 329 135 240 329 minecraft:stone
setblock 135 237 333 minecraft:stripped_spruce_log
fill 135 237 334 135 240 334 minecraft:stone
setblock 135 237 338 minecraft:stripped_spruce_log
fill 135 237 339 135 240 339 minecraft:stone
setblock 135 237 343 minecraft:stripped_spruce_log
fill 135 237 344 135 240 344 minecraft:stone
setblock 135 237 348 minecraft:stripped_spruce_log
fill 135 237 349 135 240 349 minecraft:stone
setblock 135 237 353 minecraft:stripped_spruce_log
fill 135 237 354 135 240 354 minecraft:stone
setblock 135 237 358 minecraft:stripped_spruce_log
fill 135 237 359 135 240 359 minecraft:stone
setblock 135 237 363 minecraft:stripped_spruce_log
setblock 94 238 322 minecraft:stone
fill 94 238 344 95 238 344 minecraft:stone
fill 94 238 352 94 241 352 minecraft:andesite
fill 94 238 358 95 238 358 minecraft:stone
fill 94 238 359 94 239 359 minecraft:andesite
setblock 94 238 363 minecraft:andesite
setblock 94 238 364 minecraft:stone
fill 95 238 323 95 238 326 minecraft:stone
setblock 95 238 327 minecraft:stripped_spruce_log
fill 95 238 328 95 238 331 minecraft:stone
setblock 95 238 332 minecraft:stripped_spruce_log
fill 95 238 333 95 238 336 minecraft:stone
setblock 95 238 337 minecraft:stripped_spruce_log
fill 95 238 338 95 238 341 minecraft:stone
setblock 95 238 342 minecraft:stripped_spruce_log
fill 95 238 343 95 240 343 minecraft:stone
fill 95 238 345 95 238 346 minecraft:stone
setblock 95 238 347 minecraft:stripped_spruce_log
fill 95 238 348 95 240 348 minecraft:stone
setblock 95 238 352 minecraft:stripped_spruce_log
fill 95 238 353 95 239 353 minecraft:stone
setblock 95 238 357 minecraft:stripped_spruce_log
setblock 95 238 362 minecraft:stripped_spruce_log
fill 95 238 363 95 240 363 minecraft:stone
fill 96 238 322 97 241 322 minecraft:andesite
fill 96 238 329 96 238 330 minecraft:stone
setblock 96 238 331 minecraft:stripped_spruce_log
fill 96 238 332 96 238 335 minecraft:stone
setblock 96 238 336 minecraft:stripped_spruce_log
schedule function dropper:buildpart/74_8 1t
