setblock 465 229 539 minecraft:light_blue_stained_glass
fill 465 229 540 465 255 543 minecraft:black_concrete
setblock 423 230 520 minecraft:white_concrete
fill 432 230 510 432 276 510 minecraft:black_concrete
setblock 433 230 510 minecraft:white_concrete
fill 434 230 510 435 251 510 minecraft:black_concrete
fill 440 230 552 440 237 552 minecraft:black_concrete
fill 465 230 539 465 307 539 minecraft:black_concrete
fill 423 231 520 423 239 520 minecraft:black_concrete
fill 423 231 528 423 239 533 minecraft:black_concrete
setblock 423 231 534 minecraft:sea_lantern
fill 423 231 535 423 304 535 minecraft:black_concrete
fill 433 231 510 433 244 510 minecraft:black_concrete
fill 423 232 534 423 233 534 minecraft:black_concrete
setblock 423 232 545 minecraft:white_concrete
fill 423 232 546 423 274 546 minecraft:black_concrete
fill 424 232 510 429 233 510 minecraft:black_concrete
setblock 430 232 510 minecraft:sea_lantern
fill 458 232 552 460 247 552 minecraft:black_concrete
setblock 461 232 552 minecraft:white_concrete
setblock 465 232 544 minecraft:sea_lantern
fill 465 232 545 465 250 546 minecraft:black_concrete
fill 423 233 545 423 239 545 minecraft:black_concrete
fill 430 233 510 430 292 510 minecraft:black_concrete
setblock 432 233 552 minecraft:light_blue_stained_glass
fill 434 233 552 434 254 552 minecraft:black_concrete
setblock 435 233 552 minecraft:light_blue_stained_glass
fill 436 233 552 436 253 552 minecraft:black_concrete
fill 447 233 510 447 304 510 minecraft:black_concrete
setblock 448 233 510 minecraft:sea_lantern
fill 449 233 510 449 235 510 minecraft:black_concrete
fill 461 233 552 461 263 552 minecraft:black_concrete
setblock 463 233 552 minecraft:light_blue_stained_glass
fill 465 233 544 465 307 544 minecraft:black_concrete
fill 423 234 517 423 307 517 minecraft:black_concrete
fill 423 234 518 423 236 518 minecraft:gold_block
fill 423 234 519 423 307 519 minecraft:black_concrete
fill 423 234 534 423 236 534 minecraft:gold_block
fill 423 234 539 423 281 540 minecraft:black_concrete
fill 423 234 541 423 235 541 minecraft:light_blue_stained_glass
fill 423 234 542 423 241 543 minecraft:black_concrete
fill 423 234 550 423 236 550 minecraft:gold_block
fill 424 234 510 426 266 510 minecraft:black_concrete
setblock 426 234 513 minecraft:light[level=14]
setblock 426 234 521 minecraft:light[level=14]
setblock 426 234 529 minecraft:light[level=14]
setblock 426 234 537 minecraft:light[level=14]
setblock 426 234 545 minecraft:light[level=14]
fill 427 234 510 427 236 510 minecraft:gold_block
fill 428 234 510 429 248 510 minecraft:black_concrete
fill 432 234 552 432 256 552 minecraft:black_concrete
setblock 434 234 513 minecraft:light[level=14]
setblock 434 234 521 minecraft:light[level=14]
setblock 434 234 529 minecraft:light[level=14]
setblock 434 234 537 minecraft:light[level=14]
setblock 434 234 545 minecraft:light[level=14]
fill 435 234 552 435 235 552 minecraft:black_concrete
fill 437 234 552 437 236 552 minecraft:gold_block
fill 438 234 552 439 241 552 minecraft:black_concrete
setblock 442 234 513 minecraft:light[level=14]
setblock 442 234 521 minecraft:light[level=14]
setblock 442 234 529 minecraft:light[level=14]
setblock 442 234 537 minecraft:light[level=14]
setblock 442 234 545 minecraft:light[level=14]
fill 443 234 510 443 236 510 minecraft:gold_block
fill 448 234 510 448 307 510 minecraft:black_concrete
setblock 450 234 513 minecraft:light[level=14]
setblock 450 234 521 minecraft:light[level=14]
setblock 450 234 529 minecraft:light[level=14]
setblock 450 234 537 minecraft:light[level=14]
setblock 450 234 545 minecraft:light[level=14]
fill 452 234 552 452 252 552 minecraft:black_concrete
fill 453 234 552 453 236 552 minecraft:gold_block
fill 457 234 510 458 261 510 minecraft:black_concrete
setblock 458 234 513 minecraft:light[level=14]
setblock 458 234 521 minecraft:light[level=14]
setblock 458 234 529 minecraft:light[level=14]
setblock 458 234 537 minecraft:light[level=14]
setblock 458 234 545 minecraft:light[level=14]
fill 459 234 510 459 236 510 minecraft:gold_block
fill 460 234 510 461 275 510 minecraft:black_concrete
setblock 462 234 510 minecraft:sea_lantern
fill 463 234 510 463 307 510 minecraft:black_concrete
fill 463 234 552 463 250 552 minecraft:black_concrete
fill 465 234 514 465 245 519 minecraft:black_concrete
fill 465 234 520 465 236 520 minecraft:gold_block
fill 465 234 521 465 247 522 minecraft:black_concrete
fill 465 234 536 465 236 536 minecraft:gold_block
setblock 426 235 552 minecraft:white_concrete
fill 427 235 552 429 307 552 minecraft:black_concrete
fill 438 235 510 440 271 510 minecraft:black_concrete
setblock 441 235 510 minecraft:light_blue_stained_glass
fill 462 235 510 462 248 510 minecraft:black_concrete
fill 423 236 541 423 291 541 minecraft:black_concrete
fill 424 236 552 424 307 552 minecraft:black_concrete
setblock 425 236 552 minecraft:white_concrete
fill 426 236 552 426 307 552 minecraft:black_concrete
setblock 435 236 552 minecraft:white_concrete
fill 441 236 510 441 237 510 minecraft:black_concrete
setblock 449 236 510 minecraft:white_concrete
setblock 451 236 552 minecraft:light_blue_stained_glass
fill 465 236 534 465 261 534 minecraft:black_concrete
setblock 465 236 535 minecraft:white_concrete
fill 465 236 547 465 307 547 minecraft:black_concrete
setblock 465 236 548 minecraft:sea_lantern
fill 465 236 549 465 307 549 minecraft:black_concrete
fill 423 237 518 423 242 518 minecraft:black_concrete
fill 423 237 534 423 242 534 minecraft:black_concrete
fill 423 237 550 423 242 550 minecraft:black_concrete
fill 425 237 552 425 307 552 minecraft:black_concrete
fill 427 237 510 427 242 510 minecraft:black_concrete
fill 435 237 552 435 278 552 minecraft:black_concrete
fill 437 237 552 437 242 552 minecraft:black_concrete
fill 443 237 510 443 242 510 minecraft:black_concrete
fill 449 237 510 449 245 510 minecraft:black_concrete
setblock 449 237 552 minecraft:sea_lantern
fill 450 237 552 451 307 552 minecraft:black_concrete
fill 453 237 552 453 242 552 minecraft:black_concrete
fill 459 237 510 459 242 510 minecraft:black_concrete
fill 465 237 520 465 242 520 minecraft:black_concrete
fill 465 237 535 465 242 536 minecraft:black_concrete
fill 465 237 548 465 272 548 minecraft:black_concrete
setblock 440 238 552 minecraft:white_concrete
setblock 441 238 510 minecraft:white_concrete
fill 442 238 545 446 243 546 minecraft:red_terracotta
fill 443 238 544 446 243 544 minecraft:red_terracotta
fill 443 238 547 446 243 547 minecraft:red_terracotta
fill 449 238 552 449 245 552 minecraft:black_concrete
setblock 465 238 524 minecraft:white_concrete
fill 465 238 525 465 247 530 minecraft:black_concrete
setblock 423 239 516 minecraft:light_blue_stained_glass
fill 440 239 552 440 279 552 minecraft:black_concrete
fill 441 239 510 441 307 510 minecraft:black_concrete
fill 442 239 544 442 242 544 minecraft:red_terracotta
fill 442 239 547 442 242 547 minecraft:red_terracotta
fill 443 239 543 446 242 543 minecraft:red_terracotta
fill 443 239 548 446 242 548 minecraft:red_terracotta
fill 447 239 545 447 242 547 minecraft:red_terracotta
fill 465 239 524 465 273 524 minecraft:black_concrete
setblock 465 239 537 minecraft:light_blue_stained_glass
fill 465 239 538 465 258 538 minecraft:black_concrete
fill 423 240 516 423 307 516 minecraft:black_concrete
setblock 423 240 520 minecraft:sea_lantern
setblock 423 240 526 minecraft:light_blue_stained_glass
fill 423 240 528 423 307 528 minecraft:black_concrete
setblock 423 240 529 minecraft:light_blue_stained_glass
fill 423 240 530 423 260 533 minecraft:black_concrete
setblock 423 240 545 minecraft:light_blue_stained_glass
fill 441 240 545 441 241 546 minecraft:red_terracotta
setblock 442 240 510 minecraft:light_blue_stained_glass
fill 442 240 543 442 241 543 minecraft:red_terracotta
fill 442 240 548 442 241 548 minecraft:red_terracotta
fill 447 240 544 447 241 544 minecraft:red_terracotta
fill 465 240 537 465 296 537 minecraft:black_concrete
fill 423 241 520 423 250 520 minecraft:black_concrete
fill 423 241 526 423 290 526 minecraft:black_concrete
fill 423 241 529 423 248 529 minecraft:black_concrete
fill 423 241 545 423 307 545 minecraft:black_concrete
fill 441 241 552 443 266 552 minecraft:black_concrete
fill 442 241 510 442 284 510 minecraft:black_concrete
setblock 444 241 552 minecraft:white_concrete
fill 445 241 552 448 242 552 minecraft:black_concrete
fill 423 242 542 423 244 542 minecraft:black_concrete
setblock 423 242 543 minecraft:white_concrete
setblock 426 242 513 minecraft:light[level=14]
setblock 426 242 521 minecraft:light[level=14]
setblock 426 242 529 minecraft:light[level=14]
setblock 426 242 537 minecraft:light[level=14]
setblock 426 242 545 minecraft:light[level=14]
setblock 434 242 513 minecraft:light[level=14]
setblock 434 242 521 minecraft:light[level=14]
setblock 434 242 529 minecraft:light[level=14]
setblock 434 242 537 minecraft:light[level=14]
setblock 434 242 545 minecraft:light[level=14]
setblock 438 242 552 minecraft:light_blue_stained_glass
fill 439 242 552 439 307 552 minecraft:black_concrete
setblock 442 242 513 minecraft:light[level=14]
setblock 442 242 521 minecraft:light[level=14]
setblock 442 242 529 minecraft:light[level=14]
setblock 442 242 537 minecraft:light[level=14]
fill 444 242 552 444 294 552 minecraft:black_concrete
setblock 450 242 513 minecraft:light[level=14]
setblock 450 242 521 minecraft:light[level=14]
setblock 450 242 529 minecraft:light[level=14]
setblock 450 242 537 minecraft:light[level=14]
setblock 450 242 545 minecraft:light[level=14]
setblock 458 242 513 minecraft:light[level=14]
setblock 458 242 521 minecraft:light[level=14]
setblock 458 242 529 minecraft:light[level=14]
setblock 458 242 537 minecraft:light[level=14]
setblock 458 242 545 minecraft:light[level=14]
fill 423 243 512 423 278 512 minecraft:black_concrete
setblock 423 243 513 minecraft:white_concrete
fill 423 243 518 423 245 518 minecraft:gold_block
fill 423 243 534 423 245 534 minecraft:gold_block
fill 423 243 543 423 253 543 minecraft:black_concrete
fill 423 243 550 423 245 550 minecraft:gold_block
fill 427 243 510 427 245 510 minecraft:gold_block
fill 437 243 552 437 245 552 minecraft:gold_block
fill 438 243 552 438 307 552 minecraft:black_concrete
fill 443 243 510 443 245 510 minecraft:gold_block
setblock 445 243 552 minecraft:sea_lantern
fill 446 243 552 448 257 552 minecraft:black_concrete
fill 453 243 552 453 245 552 minecraft:gold_block
fill 459 243 510 459 245 510 minecraft:gold_block
fill 465 243 520 465 245 520 minecraft:gold_block
fill 465 243 535 465 250 535 minecraft:black_concrete
fill 465 243 536 465 245 536 minecraft:gold_block
fill 423 244 513 423 297 513 minecraft:black_concrete
fill 445 244 552 445 274 552 minecraft:black_concrete
setblock 423 245 542 minecraft:white_concrete
setblock 433 245 510 minecraft:sea_lantern
fill 453 245 510 454 258 510 minecraft:black_concrete
setblock 455 245 510 minecraft:white_concrete
setblock 423 246 514 minecraft:white_concrete
fill 423 246 518 423 251 518 minecraft:black_concrete
setblock 423 246 534 minecraft:black_concrete
fill 423 246 542 423 307 542 minecraft:black_concrete
fill 423 246 550 423 251 550 minecraft:black_concrete
fill 427 246 510 427 251 510 minecraft:black_concrete
fill 433 246 510 433 307 510 minecraft:black_concrete
fill 437 246 552 437 251 552 minecraft:black_concrete
fill 443 246 510 443 251 510 minecraft:black_concrete
setblock 449 246 510 minecraft:white_concrete
setblock 449 246 552 minecraft:sea_lantern
fill 453 246 552 453 251 552 minecraft:black_concrete
fill 455 246 510 455 262 510 minecraft:black_concrete
fill 459 246 510 459 251 510 minecraft:black_concrete
setblock 465 246 514 minecraft:white_concrete
fill 465 246 515 465 251 520 minecraft:black_concrete
fill 465 246 536 465 251 536 minecraft:black_concrete
fill 423 247 514 423 307 514 minecraft:black_concrete
setblock 423 247 534 minecraft:white_concrete
fill 449 247 510 449 264 510 minecraft:black_concrete
fill 449 247 552 449 257 552 minecraft:black_concrete
fill 454 247 522 457 252 524 minecraft:light_blue_concrete
fill 455 247 521 455 252 521 minecraft:light_blue_concrete
fill 455 247 525 455 252 525 minecraft:light_blue_concrete
fill 465 247 514 465 250 514 minecraft:black_concrete
fill 423 248 534 423 251 534 minecraft:black_concrete
fill 453 248 522 453 251 524 minecraft:light_blue_concrete
fill 454 248 521 454 251 521 minecraft:light_blue_concrete
fill 454 248 525 454 251 525 minecraft:light_blue_concrete
fill 456 248 521 457 251 521 minecraft:light_blue_concrete
fill 456 248 525 457 251 525 minecraft:light_blue_concrete
fill 458 248 523 458 251 523 minecraft:light_blue_concrete
fill 458 248 552 458 251 552 minecraft:black_concrete
setblock 459 248 552 minecraft:sea_lantern
fill 460 248 552 460 276 552 minecraft:black_concrete
setblock 465 248 521 minecraft:light_blue_stained_glass
setblock 465 248 522 minecraft:white_concrete
fill 465 248 525 465 285 528 minecraft:black_concrete
setblock 465 248 529 minecraft:sea_lantern
fill 465 248 530 465 279 530 minecraft:black_concrete
setblock 423 249 529 minecraft:light_blue_stained_glass
fill 428 249 510 428 307 510 minecraft:black_concrete
setblock 429 249 510 minecraft:sea_lantern
fill 452 249 523 452 250 523 minecraft:light_blue_concrete
fill 453 249 521 453 250 521 minecraft:light_blue_concrete
fill 453 249 525 453 250 525 minecraft:light_blue_concrete
fill 454 249 526 456 250 526 minecraft:light_blue_concrete
fill 455 249 520 456 250 520 minecraft:light_blue_concrete
fill 458 249 522 458 250 522 minecraft:light_blue_concrete
fill 458 249 524 458 250 524 minecraft:light_blue_concrete
fill 459 249 552 459 269 552 minecraft:black_concrete
setblock 462 249 510 minecraft:light_blue_stained_glass
fill 465 249 521 465 259 522 minecraft:black_concrete
fill 465 249 529 465 255 529 minecraft:black_concrete
fill 423 250 529 423 307 529 minecraft:black_concrete
setblock 426 250 513 minecraft:light[level=14]
setblock 426 250 521 minecraft:light[level=14]
setblock 426 250 529 minecraft:light[level=14]
setblock 426 250 537 minecraft:light[level=14]
setblock 426 250 545 minecraft:light[level=14]
fill 429 250 510 429 288 510 minecraft:black_concrete
setblock 434 250 513 minecraft:light[level=14]
setblock 434 250 521 minecraft:light[level=14]
setblock 434 250 529 minecraft:light[level=14]
setblock 434 250 537 minecraft:light[level=14]
setblock 434 250 545 minecraft:light[level=14]
setblock 442 250 513 minecraft:light[level=14]
setblock 442 250 521 minecraft:light[level=14]
setblock 442 250 529 minecraft:light[level=14]
setblock 442 250 537 minecraft:light[level=14]
setblock 442 250 545 minecraft:light[level=14]
setblock 450 250 513 minecraft:light[level=14]
setblock 450 250 521 minecraft:light[level=14]
setblock 450 250 529 minecraft:light[level=14]
setblock 450 250 537 minecraft:light[level=14]
setblock 450 250 545 minecraft:light[level=14]
setblock 458 250 513 minecraft:light[level=14]
setblock 458 250 521 minecraft:light[level=14]
setblock 458 250 529 minecraft:light[level=14]
setblock 458 250 537 minecraft:light[level=14]
setblock 458 250 545 minecraft:light[level=14]
fill 462 250 510 462 267 510 minecraft:black_concrete
setblock 423 251 520 minecraft:light_blue_stained_glass
setblock 463 251 552 minecraft:white_concrete
setblock 465 251 514 minecraft:light_blue_stained_glass
setblock 465 251 535 minecraft:sea_lantern
fill 465 251 545 465 307 545 minecraft:black_concrete
setblock 465 251 546 minecraft:light_blue_stained_glass
fill 423 252 518 423 254 518 minecraft:gold_block
fill 423 252 520 423 289 520 minecraft:black_concrete
fill 423 252 534 423 254 534 minecraft:gold_block
fill 423 252 550 423 254 550 minecraft:gold_block
fill 427 252 510 427 254 510 minecraft:gold_block
fill 434 252 510 434 253 510 minecraft:black_concrete
setblock 435 252 510 minecraft:sea_lantern
fill 437 252 552 437 254 552 minecraft:gold_block
fill 443 252 510 443 254 510 minecraft:gold_block
fill 453 252 552 453 254 552 minecraft:gold_block
setblock 458 252 552 minecraft:light_blue_stained_glass
fill 459 252 510 459 254 510 minecraft:gold_block
fill 463 252 552 463 298 552 minecraft:black_concrete
fill 465 252 514 465 255 519 minecraft:black_concrete
fill 465 252 520 465 254 520 minecraft:gold_block
fill 465 252 535 465 307 535 minecraft:black_concrete
fill 465 252 536 465 254 536 minecraft:gold_block
fill 465 252 546 465 289 546 minecraft:black_concrete
setblock 423 253 544 minecraft:light_blue_stained_glass
fill 435 253 510 435 266 510 minecraft:black_concrete
setblock 452 253 552 minecraft:white_concrete
fill 458 253 552 458 284 552 minecraft:black_concrete
fill 461 253 539 463 254 539 minecraft:waxed_copper_block
fill 465 253 510 465 307 510 minecraft:black_concrete
setblock 465 253 511 minecraft:white_concrete
fill 465 253 550 465 307 550 minecraft:black_concrete
setblock 465 253 551 minecraft:light_blue_stained_glass
setblock 423 254 543 minecraft:light_blue_stained_glass
fill 423 254 544 423 307 544 minecraft:black_concrete
setblock 434 254 510 minecraft:light_blue_stained_glass
setblock 436 254 552 minecraft:white_concrete
fill 452 254 552 452 307 552 minecraft:black_concrete
fill 465 254 511 465 265 511 minecraft:black_concrete
fill 465 254 551 465 269 551 minecraft:black_concrete
fill 423 255 518 423 260 518 minecraft:black_concrete
fill 423 255 534 423 260 534 minecraft:black_concrete
fill 423 255 543 423 307 543 minecraft:black_concrete
fill 423 255 550 423 257 550 minecraft:black_concrete
fill 427 255 510 427 260 510 minecraft:black_concrete
fill 434 255 510 434 299 510 minecraft:black_concrete
setblock 434 255 552 minecraft:sea_lantern
fill 436 255 552 437 260 552 minecraft:black_concrete
fill 443 255 510 443 260 510 minecraft:black_concrete
setblock 453 255 552 minecraft:white_concrete
fill 459 255 510 459 260 510 minecraft:black_concrete
fill 465 255 520 465 260 520 minecraft:black_concrete
fill 465 255 531 465 307 531 minecraft:black_concrete
setblock 465 255 532 minecraft:sea_lantern
fill 465 255 533 465 304 533 minecraft:black_concrete
setblock 465 255 536 minecraft:black_concrete
setblock 423 256 536 minecraft:white_concrete
fill 434 256 552 434 307 552 minecraft:black_concrete
fill 453 256 552 453 260 552 minecraft:black_concrete
fill 465 256 514 465 258 514 minecraft:black_concrete
setblock 465 256 515 minecraft:sea_lantern
fill 465 256 516 465 257 519 minecraft:black_concrete
setblock 465 256 529 minecraft:sea_lantern
fill 465 256 532 465 263 532 minecraft:black_concrete
setblock 465 256 536 minecraft:white_concrete
fill 465 256 540 465 269 541 minecraft:black_concrete
setblock 465 256 542 minecraft:white_concrete
fill 465 256 543 465 307 543 minecraft:black_concrete
fill 423 257 522 423 268 523 minecraft:black_concrete
setblock 423 257 524 minecraft:white_concrete
fill 423 257 536 423 307 536 minecraft:black_concrete
setblock 432 257 552 minecraft:sea_lantern
fill 465 257 515 465 262 515 minecraft:black_concrete
fill 465 257 529 465 303 529 minecraft:black_concrete
fill 465 257 536 465 260 536 minecraft:black_concrete
fill 465 257 542 465 261 542 minecraft:black_concrete
fill 423 258 524 423 293 524 minecraft:black_concrete
setblock 423 258 550 minecraft:light_blue_stained_glass
setblock 426 258 513 minecraft:light[level=14]
setblock 426 258 521 minecraft:light[level=14]
setblock 426 258 529 minecraft:light[level=14]
setblock 426 258 537 minecraft:light[level=14]
setblock 426 258 545 minecraft:light[level=14]
fill 432 258 552 432 307 552 minecraft:black_concrete
setblock 434 258 513 minecraft:light[level=14]
setblock 434 258 521 minecraft:light[level=14]
setblock 434 258 529 minecraft:light[level=14]
setblock 434 258 537 minecraft:light[level=14]
setblock 434 258 545 minecraft:light[level=14]
setblock 442 258 513 minecraft:light[level=14]
setblock 442 258 521 minecraft:light[level=14]
setblock 442 258 529 minecraft:light[level=14]
setblock 442 258 537 minecraft:light[level=14]
setblock 442 258 545 minecraft:light[level=14]
fill 446 258 552 446 267 552 minecraft:black_concrete
setblock 447 258 552 minecraft:light_blue_stained_glass
fill 448 258 552 448 299 552 minecraft:black_concrete
setblock 449 258 552 minecraft:white_concrete
setblock 450 258 513 minecraft:light[level=14]
setblock 450 258 521 minecraft:light[level=14]
setblock 450 258 529 minecraft:light[level=14]
setblock 450 258 537 minecraft:light[level=14]
setblock 450 258 545 minecraft:light[level=14]
setblock 458 258 513 minecraft:light[level=14]
setblock 458 258 521 minecraft:light[level=14]
setblock 458 258 529 minecraft:light[level=14]
setblock 458 258 537 minecraft:light[level=14]
setblock 458 258 545 minecraft:light[level=14]
fill 465 258 516 465 278 517 minecraft:black_concrete
setblock 465 258 518 minecraft:light_blue_stained_glass
fill 465 258 519 465 279 519 minecraft:black_concrete
fill 423 259 550 423 260 550 minecraft:black_concrete
fill 447 259 552 447 307 552 minecraft:black_concrete
fill 449 259 552 449 307 552 minecraft:black_concrete
fill 450 259 510 451 259 510 minecraft:black_concrete
fill 452 259 510 453 259 510 minecraft:white_concrete
fill 454 259 510 454 307 510 minecraft:black_concrete
setblock 465 259 514 minecraft:sea_lantern
fill 465 259 518 465 267 518 minecraft:black_concrete
setblock 465 259 538 minecraft:light_blue_stained_glass
setblock 423 260 527 minecraft:light_blue_stained_glass
setblock 430 260 552 minecraft:light_blue_stained_glass
setblock 450 260 510 minecraft:sea_lantern
fill 451 260 510 453 307 510 minecraft:black_concrete
fill 465 260 514 465 285 514 minecraft:black_concrete
fill 465 260 521 465 307 521 minecraft:black_concrete
setblock 465 260 522 minecraft:white_concrete
fill 465 260 538 465 280 538 minecraft:black_concrete
fill 423 261 518 423 263 518 minecraft:gold_block
setblock 423 261 525 minecraft:sea_lantern
fill 423 261 527 423 266 527 minecraft:black_concrete
setblock 423 261 530 minecraft:white_concrete
fill 423 261 531 423 266 533 minecraft:black_concrete
fill 423 261 534 423 263 534 minecraft:gold_block
fill 423 261 550 423 263 550 minecraft:gold_block
fill 427 261 510 427 263 510 minecraft:gold_block
fill 430 261 552 430 307 552 minecraft:black_concrete
fill 436 261 552 436 266 552 minecraft:black_concrete
fill 437 261 552 437 263 552 minecraft:gold_block
fill 443 261 510 443 263 510 minecraft:gold_block
fill 450 261 510 450 307 510 minecraft:black_concrete
fill 453 261 552 453 263 552 minecraft:gold_block
fill 459 261 510 459 263 510 minecraft:gold_block
fill 465 261 520 465 263 520 minecraft:gold_block
fill 465 261 522 465 296 522 minecraft:black_concrete
fill 465 261 536 465 263 536 minecraft:gold_block
fill 423 262 525 423 279 525 minecraft:black_concrete
fill 423 262 530 423 264 530 minecraft:black_concrete
fill 457 262 510 457 307 510 minecraft:black_concrete
setblock 458 262 510 minecraft:light_blue_stained_glass
setblock 465 262 534 minecraft:light_blue_stained_glass
setblock 465 262 542 minecraft:light_blue_stained_glass
fill 444 263 510 445 307 510 minecraft:black_concrete
setblock 446 263 510 minecraft:light_blue_stained_glass
setblock 455 263 510 minecraft:white_concrete
fill 458 263 510 458 274 510 minecraft:black_concrete
setblock 465 263 515 minecraft:light_blue_stained_glass
fill 465 263 534 465 298 534 minecraft:black_concrete
fill 465 263 542 465 271 542 minecraft:black_concrete
fill 423 264 518 423 269 518 minecraft:black_concrete
fill 423 264 534 423 269 534 minecraft:black_concrete
fill 423 264 550 423 269 550 minecraft:black_concrete
fill 427 264 510 427 269 510 minecraft:black_concrete
fill 437 264 552 437 269 552 minecraft:black_concrete
fill 443 264 510 443 269 510 minecraft:black_concrete
fill 446 264 510 446 307 510 minecraft:black_concrete
fill 453 264 552 453 269 552 minecraft:black_concrete
fill 455 264 510 455 288 510 minecraft:black_concrete
fill 459 264 510 459 269 510 minecraft:black_concrete
setblock 461 264 552 minecraft:sea_lantern
fill 465 264 515 465 307 515 minecraft:black_concrete
fill 465 264 520 465 269 520 minecraft:black_concrete
setblock 465 264 532 minecraft:light_blue_stained_glass
fill 465 264 536 465 269 536 minecraft:black_concrete
setblock 423 265 530 minecraft:white_concrete
setblock 449 265 510 minecraft:white_concrete
fill 461 265 552 461 273 552 minecraft:black_concrete
fill 465 265 532 465 296 532 minecraft:black_concrete
fill 423 266 530 423 275 530 minecraft:black_concrete
setblock 426 266 513 minecraft:light[level=14]
setblock 426 266 521 minecraft:light[level=14]
setblock 426 266 529 minecraft:light[level=14]
setblock 426 266 537 minecraft:light[level=14]
setblock 426 266 545 minecraft:light[level=14]
setblock 434 266 513 minecraft:light[level=14]
setblock 434 266 521 minecraft:light[level=14]
setblock 434 266 529 minecraft:light[level=14]
setblock 434 266 537 minecraft:light[level=14]
setblock 434 266 545 minecraft:light[level=14]
setblock 442 266 513 minecraft:light[level=14]
setblock 442 266 521 minecraft:light[level=14]
setblock 442 266 529 minecraft:light[level=14]
setblock 442 266 537 minecraft:light[level=14]
setblock 442 266 545 minecraft:light[level=14]
fill 449 266 510 449 307 510 minecraft:black_concrete
setblock 450 266 513 minecraft:light[level=14]
setblock 450 266 521 minecraft:light[level=14]
setblock 450 266 529 minecraft:light[level=14]
setblock 450 266 537 minecraft:light[level=14]
setblock 450 266 545 minecraft:light[level=14]
setblock 458 266 513 minecraft:light[level=14]
setblock 458 266 521 minecraft:light[level=14]
setblock 458 266 529 minecraft:light[level=14]
setblock 458 266 537 minecraft:light[level=14]
setblock 458 266 545 minecraft:light[level=14]
setblock 465 266 511 minecraft:white_concrete
setblock 423 267 527 minecraft:white_concrete
fill 423 267 531 423 300 531 minecraft:black_concrete
setblock 423 267 532 minecraft:light_blue_stained_glass
fill 423 267 533 423 307 533 minecraft:black_concrete
fill 424 267 510 424 307 510 minecraft:black_concrete
setblock 425 267 510 minecraft:sea_lantern
fill 426 267 510 426 299 510 minecraft:black_concrete
setblock 435 267 510 minecraft:white_concrete
setblock 436 267 552 minecraft:white_concrete
setblock 441 267 552 minecraft:white_concrete
fill 442 267 552 443 270 552 minecraft:black_concrete
fill 465 267 511 465 270 511 minecraft:black_concrete
fill 423 268 527 423 274 527 minecraft:black_concrete
fill 423 268 532 423 307 532 minecraft:black_concrete
fill 425 268 510 425 286 510 minecraft:black_concrete
fill 435 268 510 435 292 510 minecraft:black_concrete
fill 436 268 552 436 283 552 minecraft:black_concrete
fill 441 268 552 441 292 552 minecraft:black_concrete
setblock 446 268 552 minecraft:sea_lantern
setblock 462 268 510 minecraft:light_blue_stained_glass
setblock 465 268 518 minecraft:sea_lantern
setblock 423 269 522 minecraft:light_blue_stained_glass
fill 423 269 523 423 304 523 minecraft:black_concrete
fill 446 269 552 446 307 552 minecraft:black_concrete
fill 462 269 510 462 307 510 minecraft:black_concrete
fill 465 269 518 465 307 518 minecraft:black_concrete
fill 423 270 510 423 307 510 minecraft:black_concrete
setblock 423 270 511 minecraft:light_blue_stained_glass
fill 423 270 518 423 272 518 minecraft:gold_block
fill 423 270 522 423 281 522 minecraft:black_concrete
fill 423 270 534 423 272 534 minecraft:gold_block
fill 423 270 550 423 272 550 minecraft:gold_block
fill 427 270 510 427 272 510 minecraft:gold_block
fill 436 270 527 436 272 527 minecraft:blue_stained_glass
fill 436 270 528 436 273 528 minecraft:waxed_cut_copper
fill 436 270 529 436 273 533 minecraft:blue_stained_glass
fill 436 270 534 436 273 534 minecraft:waxed_cut_copper
fill 436 270 535 436 272 535 minecraft:blue_stained_glass
fill 437 270 525 437 272 526 minecraft:blue_stained_glass
fill 437 270 536 437 272 537 minecraft:blue_stained_glass
fill 437 270 552 437 272 552 minecraft:gold_block
fill 438 270 524 438 273 524 minecraft:blue_stained_glass
fill 438 270 538 438 273 538 minecraft:blue_stained_glass
fill 439 270 523 439 273 523 minecraft:waxed_cut_copper
fill 439 270 539 439 273 539 minecraft:waxed_cut_copper
fill 440 270 522 440 273 522 minecraft:blue_stained_glass
fill 440 270 540 440 273 540 minecraft:blue_stained_glass
fill 441 270 521 442 272 521 minecraft:blue_stained_glass
fill 441 270 541 442 272 541 minecraft:blue_stained_glass
fill 443 270 510 443 272 510 minecraft:gold_block
fill 443 270 520 443 272 520 minecraft:blue_stained_glass
fill 443 270 542 443 272 542 minecraft:blue_stained_glass
fill 444 270 520 444 273 520 minecraft:waxed_cut_copper
fill 444 270 542 444 273 542 minecraft:waxed_cut_copper
fill 445 270 520 449 273 520 minecraft:blue_stained_glass
fill 445 270 542 449 273 542 minecraft:blue_stained_glass
fill 450 270 520 450 273 520 minecraft:waxed_cut_copper
fill 450 270 542 450 273 542 minecraft:waxed_cut_copper
fill 451 270 520 451 272 520 minecraft:blue_stained_glass
fill 451 270 542 451 272 542 minecraft:blue_stained_glass
fill 452 270 521 453 272 521 minecraft:blue_stained_glass
fill 452 270 541 453 272 541 minecraft:blue_stained_glass
fill 453 270 552 453 272 552 minecraft:gold_block
fill 454 270 522 454 273 522 minecraft:blue_stained_glass
fill 454 270 540 454 273 540 minecraft:blue_stained_glass
fill 455 270 523 455 273 523 minecraft:waxed_cut_copper
fill 455 270 539 455 273 539 minecraft:waxed_cut_copper
fill 456 270 524 456 273 524 minecraft:blue_stained_glass
fill 456 270 538 456 273 538 minecraft:blue_stained_glass
fill 457 270 525 457 272 526 minecraft:blue_stained_glass
fill 457 270 536 457 272 537 minecraft:blue_stained_glass
fill 458 270 527 458 272 527 minecraft:blue_stained_glass
fill 458 270 528 458 273 528 minecraft:waxed_cut_copper
fill 458 270 529 458 273 533 minecraft:blue_stained_glass
fill 458 270 534 458 273 534 minecraft:waxed_cut_copper
fill 458 270 535 458 272 535 minecraft:blue_stained_glass
fill 459 270 510 459 272 510 minecraft:gold_block
setblock 459 270 552 minecraft:light_blue_stained_glass
fill 465 270 520 465 272 520 minecraft:gold_block
fill 465 270 536 465 272 536 minecraft:gold_block
setblock 465 270 540 minecraft:light_blue_stained_glass
fill 465 270 541 465 292 541 minecraft:black_concrete
setblock 465 270 551 minecraft:light_blue_stained_glass
fill 423 271 511 423 281 511 minecraft:black_concrete
fill 438 271 525 438 274 525 minecraft:blue_stained_glass
fill 438 271 537 438 274 537 minecraft:blue_stained_glass
fill 441 271 522 441 274 522 minecraft:blue_stained_glass
fill 441 271 540 441 274 540 minecraft:blue_stained_glass
fill 442 271 552 442 280 552 minecraft:black_concrete
setblock 443 271 552 minecraft:sea_lantern
fill 453 271 522 453 274 522 minecraft:blue_stained_glass
fill 453 271 540 453 274 540 minecraft:blue_stained_glass
fill 456 271 525 456 274 525 minecraft:blue_stained_glass
fill 456 271 537 456 274 537 minecraft:blue_stained_glass
fill 459 271 552 459 280 552 minecraft:black_concrete
setblock 465 271 511 minecraft:light_blue_stained_glass
fill 465 271 540 465 293 540 minecraft:black_concrete
fill 465 271 551 465 307 551 minecraft:black_concrete
setblock 423 272 551 minecraft:light_blue_stained_glass
fill 437 272 527 437 274 527 minecraft:blue_stained_glass
fill 437 272 535 437 274 535 minecraft:blue_stained_glass
fill 438 272 510 438 307 510 minecraft:black_concrete
setblock 439 272 510 minecraft:white_concrete
fill 439 272 524 439 275 524 minecraft:blue_stained_glass
fill 439 272 538 439 275 538 minecraft:blue_stained_glass
fill 440 272 510 440 275 510 minecraft:black_concrete
fill 440 272 523 440 275 523 minecraft:blue_stained_glass
fill 440 272 539 440 275 539 minecraft:blue_stained_glass
fill 443 272 521 443 274 521 minecraft:blue_stained_glass
fill 443 272 541 443 274 541 minecraft:blue_stained_glass
fill 443 272 552 443 307 552 minecraft:black_concrete
fill 451 272 521 451 274 521 minecraft:blue_stained_glass
fill 451 272 541 451 274 541 minecraft:blue_stained_glass
fill 454 272 523 454 275 523 minecraft:blue_stained_glass
fill 454 272 539 454 275 539 minecraft:blue_stained_glass
fill 455 272 524 455 275 524 minecraft:blue_stained_glass
fill 455 272 538 455 275 538 minecraft:blue_stained_glass
fill 457 272 527 457 274 527 minecraft:blue_stained_glass
fill 457 272 535 457 274 535 minecraft:blue_stained_glass
fill 465 272 511 465 307 511 minecraft:black_concrete
setblock 465 272 542 minecraft:sea_lantern
fill 423 273 518 423 287 518 minecraft:black_concrete
fill 423 273 534 423 287 534 minecraft:black_concrete
fill 423 273 550 423 287 551 minecraft:black_concrete
fill 427 273 510 427 287 510 minecraft:black_concrete
setblock 437 273 526 minecraft:blue_stained_glass
fill 437 273 528 437 275 528 minecraft:waxed_cut_copper
fill 437 273 534 437 275 534 minecraft:waxed_cut_copper
setblock 437 273 536 minecraft:blue_stained_glass
fill 437 273 552 437 287 552 minecraft:black_concrete
fill 439 273 510 439 280 510 minecraft:black_concrete
setblock 442 273 521 minecraft:blue_stained_glass
setblock 442 273 541 minecraft:blue_stained_glass
fill 443 273 510 443 287 510 minecraft:black_concrete
fill 444 273 521 444 275 521 minecraft:waxed_cut_copper
fill 444 273 541 444 275 541 minecraft:waxed_cut_copper
fill 450 273 521 450 275 521 minecraft:waxed_cut_copper
fill 450 273 541 450 275 541 minecraft:waxed_cut_copper
setblock 452 273 521 minecraft:blue_stained_glass
setblock 452 273 541 minecraft:blue_stained_glass
fill 453 273 552 453 287 552 minecraft:black_concrete
setblock 457 273 526 minecraft:blue_stained_glass
fill 457 273 528 457 275 528 minecraft:waxed_cut_copper
fill 457 273 534 457 275 534 minecraft:waxed_cut_copper
setblock 457 273 536 minecraft:blue_stained_glass
fill 459 273 510 459 287 510 minecraft:black_concrete
setblock 464 273 552 minecraft:light_blue_stained_glass
fill 465 273 520 465 287 520 minecraft:black_concrete
fill 465 273 536 465 287 536 minecraft:black_concrete
fill 465 273 542 465 285 542 minecraft:black_concrete
setblock 465 273 548 minecraft:white_concrete
fill 465 273 552 465 307 552 minecraft:black_concrete
setblock 426 274 513 minecraft:light[level=14]
setblock 426 274 521 minecraft:light[level=14]
setblock 426 274 529 minecraft:light[level=14]
setblock 426 274 537 minecraft:light[level=14]
setblock 426 274 545 minecraft:light[level=14]
setblock 434 274 513 minecraft:light[level=14]
setblock 434 274 521 minecraft:light[level=14]
setblock 434 274 529 minecraft:light[level=14]
setblock 434 274 537 minecraft:light[level=14]
setblock 434 274 545 minecraft:light[level=14]
fill 436 274 530 437 274 532 minecraft:blue_stained_glass
fill 437 274 529 437 275 529 minecraft:blue_stained_glass
fill 437 274 533 437 275 533 minecraft:blue_stained_glass
fill 438 274 526 438 275 526 minecraft:blue_stained_glass
fill 438 274 536 438 275 536 minecraft:blue_stained_glass
fill 439 274 525 439 276 525 minecraft:blue_stained_glass
fill 439 274 537 439 276 537 minecraft:blue_stained_glass
fill 441 274 523 441 276 523 minecraft:blue_stained_glass
fill 441 274 539 441 276 539 minecraft:blue_stained_glass
setblock 442 274 513 minecraft:light[level=14]
setblock 442 274 521 minecraft:light[level=14]
fill 442 274 522 442 275 522 minecraft:blue_stained_glass
setblock 442 274 529 minecraft:light[level=14]
setblock 442 274 537 minecraft:light[level=14]
fill 442 274 540 442 275 540 minecraft:blue_stained_glass
setblock 442 274 545 minecraft:light[level=14]
fill 445 274 521 449 275 521 minecraft:blue_stained_glass
fill 445 274 541 449 275 541 minecraft:blue_stained_glass
fill 446 274 520 448 274 520 minecraft:blue_stained_glass
fill 446 274 542 448 274 542 minecraft:blue_stained_glass
setblock 450 274 513 minecraft:light[level=14]
setblock 450 274 529 minecraft:light[level=14]
setblock 450 274 537 minecraft:light[level=14]
setblock 450 274 545 minecraft:light[level=14]
fill 452 274 522 452 275 522 minecraft:blue_stained_glass
fill 452 274 540 452 275 540 minecraft:blue_stained_glass
fill 453 274 523 453 276 523 minecraft:blue_stained_glass
fill 453 274 539 453 276 539 minecraft:blue_stained_glass
fill 455 274 525 455 276 525 minecraft:blue_stained_glass
fill 455 274 537 455 276 537 minecraft:blue_stained_glass
fill 456 274 526 456 275 526 minecraft:blue_stained_glass
fill 456 274 536 456 275 536 minecraft:blue_stained_glass
fill 457 274 529 457 275 533 minecraft:blue_stained_glass
setblock 458 274 513 minecraft:light[level=14]
setblock 458 274 521 minecraft:light[level=14]
setblock 458 274 529 minecraft:light[level=14]
fill 458 274 530 458 274 532 minecraft:blue_stained_glass
setblock 458 274 537 minecraft:light[level=14]
setblock 458 274 545 minecraft:light[level=14]
setblock 461 274 552 minecraft:white_concrete
fill 464 274 552 464 278 552 minecraft:black_concrete
setblock 465 274 524 minecraft:light_blue_stained_glass
fill 465 274 548 465 278 548 minecraft:black_concrete
setblock 423 275 527 minecraft:white_concrete
setblock 423 275 546 minecraft:light_blue_stained_glass
fill 437 275 530 437 276 532 minecraft:blue_stained_glass
fill 438 275 527 438 276 528 minecraft:blue_stained_glass
fill 438 275 534 438 276 535 minecraft:blue_stained_glass
fill 439 275 526 439 276 526 minecraft:blue_stained_glass
fill 439 275 536 439 276 536 minecraft:blue_stained_glass
fill 440 275 524 440 276 524 minecraft:waxed_cut_copper
fill 440 275 538 440 276 538 minecraft:waxed_cut_copper
fill 442 275 523 442 276 523 minecraft:blue_stained_glass
fill 442 275 539 442 276 539 minecraft:blue_stained_glass
fill 443 275 522 444 276 522 minecraft:blue_stained_glass
fill 443 275 540 444 276 540 minecraft:blue_stained_glass
setblock 445 275 552 minecraft:white_concrete
fill 450 275 522 451 276 522 minecraft:blue_stained_glass
fill 450 275 540 451 276 540 minecraft:blue_stained_glass
fill 452 275 523 452 276 523 minecraft:blue_stained_glass
fill 452 275 539 452 276 539 minecraft:blue_stained_glass
fill 454 275 524 454 276 524 minecraft:waxed_cut_copper
fill 454 275 538 454 276 538 minecraft:waxed_cut_copper
fill 455 275 526 455 276 526 minecraft:blue_stained_glass
fill 455 275 536 455 276 536 minecraft:blue_stained_glass
fill 456 275 527 456 276 528 minecraft:blue_stained_glass
fill 456 275 534 456 276 535 minecraft:blue_stained_glass
setblock 458 275 510 minecraft:light_blue_stained_glass
fill 461 275 552 461 290 552 minecraft:black_concrete
fill 465 275 524 465 293 524 minecraft:black_concrete
fill 423 276 527 423 307 527 minecraft:black_concrete
setblock 423 276 530 minecraft:white_concrete
fill 423 276 546 423 291 546 minecraft:black_concrete
fill 438 276 529 438 277 533 minecraft:blue_stained_glass
fill 439 276 527 439 277 527 minecraft:blue_stained_glass
fill 439 276 535 439 277 535 minecraft:blue_stained_glass
setblock 440 276 510 minecraft:sea_lantern
fill 440 276 525 440 277 525 minecraft:blue_stained_glass
fill 440 276 537 440 277 537 minecraft:blue_stained_glass
fill 441 276 524 441 277 524 minecraft:blue_stained_glass
fill 441 276 538 441 277 538 minecraft:blue_stained_glass
fill 443 276 523 443 277 523 minecraft:blue_stained_glass
fill 443 276 539 443 277 539 minecraft:blue_stained_glass
fill 445 276 522 449 277 522 minecraft:blue_stained_glass
fill 445 276 540 449 277 540 minecraft:blue_stained_glass
fill 445 276 552 445 307 552 minecraft:black_concrete
fill 446 276 521 448 276 521 minecraft:blue_stained_glass
fill 446 276 541 448 276 541 minecraft:blue_stained_glass
fill 451 276 523 451 277 523 minecraft:blue_stained_glass
fill 451 276 539 451 277 539 minecraft:blue_stained_glass
fill 453 276 524 453 277 524 minecraft:blue_stained_glass
fill 453 276 538 453 277 538 minecraft:blue_stained_glass
fill 454 276 525 454 277 525 minecraft:blue_stained_glass
fill 454 276 537 454 277 537 minecraft:blue_stained_glass
fill 455 276 527 455 277 527 minecraft:blue_stained_glass
fill 455 276 535 455 277 535 minecraft:blue_stained_glass
fill 456 276 529 456 277 533 minecraft:blue_stained_glass
fill 457 276 530 457 276 532 minecraft:blue_stained_glass
fill 458 276 510 458 307 510 minecraft:black_concrete
fill 460 276 510 460 307 510 minecraft:black_concrete
setblock 461 276 510 minecraft:sea_lantern
fill 423 277 530 423 307 530 minecraft:black_concrete
setblock 432 277 510 minecraft:sea_lantern
setblock 439 277 528 minecraft:blue_stained_glass
fill 439 277 529 439 278 529 minecraft:waxed_cut_copper
fill 439 277 530 439 278 532 minecraft:blue_stained_glass
fill 439 277 533 439 278 533 minecraft:waxed_cut_copper
setblock 439 277 534 minecraft:blue_stained_glass
fill 440 277 510 440 307 510 minecraft:black_concrete
fill 440 277 526 440 277 527 minecraft:blue_stained_glass
fill 440 277 535 440 277 536 minecraft:blue_stained_glass
setblock 441 277 525 minecraft:waxed_cut_copper
setblock 441 277 537 minecraft:waxed_cut_copper
fill 442 277 524 443 277 524 minecraft:blue_stained_glass
fill 442 277 538 443 277 538 minecraft:blue_stained_glass
setblock 444 277 523 minecraft:blue_stained_glass
setblock 444 277 539 minecraft:blue_stained_glass
fill 445 277 523 445 278 523 minecraft:waxed_cut_copper
fill 445 277 539 445 278 539 minecraft:waxed_cut_copper
fill 446 277 523 448 278 523 minecraft:blue_stained_glass
fill 446 277 539 448 278 539 minecraft:blue_stained_glass
fill 449 277 523 449 278 523 minecraft:waxed_cut_copper
fill 449 277 539 449 278 539 minecraft:waxed_cut_copper
setblock 450 277 523 minecraft:blue_stained_glass
setblock 450 277 539 minecraft:blue_stained_glass
fill 451 277 524 452 277 524 minecraft:blue_stained_glass
fill 451 277 538 452 277 538 minecraft:blue_stained_glass
setblock 453 277 525 minecraft:waxed_cut_copper
setblock 453 277 537 minecraft:waxed_cut_copper
fill 454 277 526 454 277 527 minecraft:blue_stained_glass
fill 454 277 535 454 277 536 minecraft:blue_stained_glass
setblock 455 277 528 minecraft:blue_stained_glass
fill 455 277 529 455 278 529 minecraft:waxed_cut_copper
fill 455 277 530 455 278 532 minecraft:blue_stained_glass
fill 455 277 533 455 278 533 minecraft:waxed_cut_copper
setblock 455 277 534 minecraft:blue_stained_glass
setblock 460 277 552 minecraft:light_blue_stained_glass
fill 461 277 510 461 307 510 minecraft:black_concrete
fill 432 278 510 432 307 510 minecraft:black_concrete
fill 440 278 527 440 278 528 minecraft:blue_stained_glass
fill 440 278 529 440 279 529 minecraft:waxed_cut_copper
fill 440 278 530 440 280 532 minecraft:blue_stained_glass
fill 440 278 533 440 279 533 minecraft:waxed_cut_copper
fill 440 278 534 440 278 535 minecraft:blue_stained_glass
fill 441 278 526 441 278 527 minecraft:blue_stained_glass
fill 441 278 535 441 278 536 minecraft:blue_stained_glass
fill 442 278 525 443 278 525 minecraft:blue_stained_glass
fill 442 278 526 442 279 526 minecraft:waxed_cut_copper
fill 442 278 536 442 279 536 minecraft:waxed_cut_copper
fill 442 278 537 443 278 537 minecraft:blue_stained_glass
fill 443 278 524 444 278 524 minecraft:blue_stained_glass
fill 443 278 538 444 278 538 minecraft:blue_stained_glass
fill 445 278 524 445 279 524 minecraft:waxed_cut_copper
fill 445 278 538 445 279 538 minecraft:waxed_cut_copper
fill 446 278 524 448 280 524 minecraft:blue_stained_glass
fill 446 278 538 448 280 538 minecraft:blue_stained_glass
fill 449 278 524 449 279 524 minecraft:waxed_cut_copper
fill 449 278 538 449 279 538 minecraft:waxed_cut_copper
fill 450 278 524 451 278 524 minecraft:blue_stained_glass
fill 450 278 538 451 278 538 minecraft:blue_stained_glass
fill 451 278 525 452 278 525 minecraft:blue_stained_glass
fill 451 278 537 452 278 537 minecraft:blue_stained_glass
fill 452 278 526 452 279 526 minecraft:waxed_cut_copper
fill 452 278 536 452 279 536 minecraft:waxed_cut_copper
fill 453 278 526 453 278 527 minecraft:blue_stained_glass
fill 453 278 535 453 278 536 minecraft:blue_stained_glass
fill 454 278 527 454 278 528 minecraft:blue_stained_glass
fill 454 278 529 454 279 529 minecraft:waxed_cut_copper
fill 454 278 530 454 280 532 minecraft:blue_stained_glass
fill 454 278 533 454 279 533 minecraft:waxed_cut_copper
fill 454 278 534 454 278 535 minecraft:blue_stained_glass
fill 460 278 552 460 279 552 minecraft:black_concrete
setblock 423 279 512 minecraft:white_concrete
setblock 431 279 510 minecraft:white_concrete
setblock 435 279 552 minecraft:sea_lantern
fill 441 279 527 441 280 535 minecraft:blue_stained_glass
fill 442 279 527 442 280 529 minecraft:blue_stained_glass
fill 442 279 533 442 280 535 minecraft:blue_stained_glass
fill 443 279 525 445 280 526 minecraft:blue_stained_glass
setblock 443 279 527 minecraft:waxed_cut_copper
setblock 443 279 535 minecraft:waxed_cut_copper
fill 443 279 536 445 280 537 minecraft:blue_stained_glass
fill 446 279 525 451 280 525 minecraft:blue_stained_glass
fill 446 279 537 451 280 537 minecraft:blue_stained_glass
fill 449 279 526 451 280 526 minecraft:blue_stained_glass
fill 449 279 536 451 280 536 minecraft:blue_stained_glass
setblock 451 279 527 minecraft:waxed_cut_copper
setblock 451 279 535 minecraft:waxed_cut_copper
fill 452 279 527 453 280 529 minecraft:blue_stained_glass
fill 452 279 533 453 280 535 minecraft:blue_stained_glass
fill 453 279 530 453 280 532 minecraft:blue_stained_glass
setblock 464 279 552 minecraft:white_concrete
setblock 465 279 516 minecraft:white_concrete
fill 465 279 517 465 307 517 minecraft:black_concrete
setblock 465 279 548 minecraft:white_concrete
fill 423 280 512 423 295 512 minecraft:black_concrete
setblock 423 280 525 minecraft:light_blue_stained_glass
fill 424 280 511 437 280 551 minecraft:polished_blackstone
fill 431 280 510 431 307 510 minecraft:black_concrete
fill 435 280 552 435 282 552 minecraft:black_concrete
fill 438 280 511 438 280 527 minecraft:polished_blackstone
fill 438 280 528 439 280 534 minecraft:blue_stained_glass
fill 438 280 535 438 280 551 minecraft:polished_blackstone
fill 439 280 511 439 280 525 minecraft:polished_blackstone
fill 439 280 526 440 280 527 minecraft:blue_stained_glass
fill 439 280 535 440 280 536 minecraft:blue_stained_glass
fill 439 280 537 439 280 551 minecraft:polished_blackstone
fill 440 280 511 440 280 524 minecraft:polished_blackstone
fill 440 280 525 442 280 525 minecraft:blue_stained_glass
fill 440 280 528 440 280 529 minecraft:blue_stained_glass
fill 440 280 533 440 280 534 minecraft:blue_stained_glass
fill 440 280 537 442 280 537 minecraft:blue_stained_glass
fill 440 280 538 440 280 551 minecraft:polished_blackstone
setblock 440 280 552 minecraft:sea_lantern
fill 441 280 511 441 280 523 minecraft:polished_blackstone
fill 441 280 524 445 280 524 minecraft:blue_stained_glass
fill 441 280 526 442 280 526 minecraft:blue_stained_glass
fill 441 280 536 442 280 536 minecraft:blue_stained_glass
fill 441 280 538 445 280 538 minecraft:blue_stained_glass
fill 441 280 539 441 280 551 minecraft:polished_blackstone
fill 442 280 511 443 280 522 minecraft:polished_blackstone
fill 442 280 523 452 280 523 minecraft:blue_stained_glass
fill 442 280 530 443 280 532 minecraft:blue_stained_glass
fill 442 280 539 452 280 539 minecraft:blue_stained_glass
fill 442 280 540 443 280 551 minecraft:polished_blackstone
fill 443 280 527 444 280 529 minecraft:blue_stained_glass
fill 443 280 533 444 280 535 minecraft:blue_stained_glass
fill 444 280 511 464 280 521 minecraft:polished_blackstone
fill 444 280 522 450 280 522 minecraft:blue_stained_glass
fill 444 280 530 444 280 532 minecraft:sea_lantern
fill 444 280 540 450 280 540 minecraft:blue_stained_glass
fill 444 280 541 464 280 551 minecraft:polished_blackstone
fill 445 280 527 445 280 528 minecraft:blue_stained_glass
fill 445 280 529 445 280 530 minecraft:sea_lantern
fill 445 280 532 445 280 533 minecraft:sea_lantern
fill 445 280 534 445 280 535 minecraft:blue_stained_glass
fill 446 280 526 448 280 527 minecraft:blue_stained_glass
fill 446 280 528 446 280 529 minecraft:sea_lantern
fill 446 280 533 446 280 534 minecraft:sea_lantern
fill 446 280 535 448 280 536 minecraft:blue_stained_glass
fill 447 280 528 448 280 528 minecraft:sea_lantern
fill 447 280 534 448 280 534 minecraft:sea_lantern
fill 448 280 529 449 280 529 minecraft:sea_lantern
fill 448 280 533 449 280 533 minecraft:sea_lantern
fill 449 280 524 453 280 524 minecraft:blue_stained_glass
fill 449 280 527 451 280 528 minecraft:blue_stained_glass
fill 449 280 530 450 280 530 minecraft:sea_lantern
fill 449 280 532 450 280 532 minecraft:sea_lantern
fill 449 280 534 451 280 535 minecraft:blue_stained_glass
fill 449 280 538 453 280 538 minecraft:blue_stained_glass
fill 450 280 529 451 280 529 minecraft:blue_stained_glass
setblock 450 280 531 minecraft:sea_lantern
fill 450 280 533 451 280 533 minecraft:blue_stained_glass
fill 451 280 522 464 280 522 minecraft:polished_blackstone
fill 451 280 530 452 280 532 minecraft:blue_stained_glass
fill 451 280 540 464 280 540 minecraft:polished_blackstone
fill 452 280 525 454 280 526 minecraft:blue_stained_glass
fill 452 280 536 454 280 537 minecraft:blue_stained_glass
fill 453 280 523 464 280 523 minecraft:polished_blackstone
fill 453 280 539 464 280 539 minecraft:polished_blackstone
fill 454 280 524 464 280 524 minecraft:polished_blackstone
fill 454 280 527 455 280 529 minecraft:blue_stained_glass
fill 454 280 533 455 280 535 minecraft:blue_stained_glass
fill 454 280 538 464 280 538 minecraft:polished_blackstone
fill 455 280 525 464 280 525 minecraft:polished_blackstone
setblock 455 280 526 minecraft:blue_stained_glass
fill 455 280 530 456 280 532 minecraft:blue_stained_glass
setblock 455 280 536 minecraft:blue_stained_glass
fill 455 280 537 464 280 537 minecraft:polished_blackstone
fill 456 280 526 464 280 527 minecraft:polished_blackstone
fill 456 280 528 456 280 529 minecraft:blue_stained_glass
fill 456 280 533 456 280 534 minecraft:blue_stained_glass
fill 456 280 535 464 280 536 minecraft:polished_blackstone
fill 457 280 528 464 280 534 minecraft:polished_blackstone
setblock 460 280 552 minecraft:white_concrete
fill 464 280 552 464 307 552 minecraft:black_concrete
fill 465 280 516 465 294 516 minecraft:black_concrete
setblock 465 280 519 minecraft:light_blue_stained_glass
setblock 465 280 530 minecraft:light_blue_stained_glass
fill 465 280 548 465 307 548 minecraft:black_concrete
fill 423 281 525 423 306 525 minecraft:black_concrete
setblock 439 281 510 minecraft:sea_lantern
fill 440 281 552 440 292 552 minecraft:black_concrete
setblock 442 281 552 minecraft:sea_lantern
fill 444 281 530 444 281 532 minecraft:blue_stained_glass
setblock 445 281 529 minecraft:waxed_cut_copper
setblock 445 281 530 minecraft:blue_stained_glass
setblock 445 281 532 minecraft:blue_stained_glass
setblock 445 281 533 minecraft:waxed_cut_copper
fill 446 281 528 446 281 529 minecraft:blue_stained_glass
fill 446 281 533 446 281 534 minecraft:blue_stained_glass
fill 447 281 528 448 281 528 minecraft:blue_stained_glass
fill 447 281 534 448 281 534 minecraft:blue_stained_glass
setblock 448 281 529 minecraft:blue_stained_glass
setblock 448 281 533 minecraft:blue_stained_glass
setblock 449 281 529 minecraft:waxed_cut_copper
fill 449 281 530 450 281 530 minecraft:blue_stained_glass
fill 449 281 532 450 281 532 minecraft:blue_stained_glass
setblock 449 281 533 minecraft:waxed_cut_copper
setblock 450 281 531 minecraft:blue_stained_glass
setblock 459 281 552 minecraft:white_concrete
fill 460 281 552 460 307 552 minecraft:black_concrete
fill 465 281 519 465 307 519 minecraft:black_concrete
fill 465 281 530 465 307 530 minecraft:black_concrete
setblock 465 281 538 minecraft:white_concrete
setblock 423 282 511 minecraft:white_concrete
setblock 423 282 522 minecraft:sea_lantern
fill 423 282 539 423 283 539 minecraft:black_concrete
setblock 423 282 540 minecraft:light_blue_stained_glass
setblock 426 282 513 minecraft:light[level=14]
setblock 426 282 521 minecraft:light[level=14]
setblock 426 282 529 minecraft:light[level=14]
setblock 426 282 537 minecraft:light[level=14]
setblock 426 282 545 minecraft:light[level=14]
setblock 434 282 513 minecraft:light[level=14]
setblock 434 282 521 minecraft:light[level=14]
setblock 434 282 529 minecraft:light[level=14]
setblock 434 282 537 minecraft:light[level=14]
setblock 434 282 545 minecraft:light[level=14]
fill 439 282 510 439 307 510 minecraft:black_concrete
setblock 442 282 513 minecraft:light[level=14]
setblock 442 282 521 minecraft:light[level=14]
setblock 442 282 529 minecraft:light[level=14]
setblock 442 282 537 minecraft:light[level=14]
setblock 442 282 545 minecraft:light[level=14]
fill 442 282 552 442 306 552 minecraft:black_concrete
setblock 450 282 513 minecraft:light[level=14]
setblock 450 282 521 minecraft:light[level=14]
setblock 450 282 529 minecraft:light[level=14]
setblock 450 282 537 minecraft:light[level=14]
setblock 450 282 545 minecraft:light[level=14]
setblock 458 282 513 minecraft:light[level=14]
setblock 458 282 521 minecraft:light[level=14]
setblock 458 282 529 minecraft:light[level=14]
setblock 458 282 537 minecraft:light[level=14]
setblock 458 282 545 minecraft:light[level=14]
fill 459 282 552 459 294 552 minecraft:black_concrete
fill 465 282 538 465 307 538 minecraft:black_concrete
fill 423 283 511 423 301 511 minecraft:black_concrete
fill 423 283 522 423 307 522 minecraft:black_concrete
fill 423 283 540 423 290 540 minecraft:black_concrete
setblock 435 283 552 minecraft:light_blue_stained_glass
setblock 423 284 539 minecraft:sea_lantern
setblock 435 284 552 minecraft:black_concrete
fill 436 284 510 436 296 510 minecraft:black_concrete
setblock 436 284 552 minecraft:light_blue_stained_glass
setblock 437 284 510 minecraft:light_blue_stained_glass
fill 441 284 548 441 284 550 minecraft:waxed_copper_block
fill 458 284 511 460 285 514 minecraft:waxed_copper_block
fill 460 284 520 460 300 520 minecraft:waxed_copper_block
fill 423 285 539 423 305 539 minecraft:black_concrete
fill 423 285 547 423 307 548 minecraft:black_concrete
setblock 423 285 549 minecraft:light_blue_stained_glass
setblock 435 285 552 minecraft:sea_lantern
fill 436 285 552 436 307 552 minecraft:black_concrete
fill 437 285 510 437 307 510 minecraft:black_concrete
setblock 442 285 510 minecraft:white_concrete
setblock 458 285 552 minecraft:sea_lantern
setblock 459 285 515 minecraft:sea_lantern
fill 423 286 549 423 307 549 minecraft:black_concrete
fill 435 286 552 435 292 552 minecraft:black_concrete
fill 442 286 510 442 307 510 minecraft:black_concrete
fill 457 286 512 457 286 514 minecraft:waxed_cut_copper
fill 458 286 511 460 286 511 minecraft:waxed_cut_copper
fill 458 286 512 460 300 514 minecraft:waxed_copper_block
fill 458 286 515 460 286 515 minecraft:waxed_cut_copper
fill 458 286 552 458 307 552 minecraft:black_concrete
fill 459 286 519 459 286 521 minecraft:waxed_cut_copper
fill 460 286 519 461 286 519 minecraft:waxed_cut_copper
fill 460 286 521 461 286 521 minecraft:waxed_cut_copper
fill 461 286 512 461 286 514 minecraft:waxed_cut_copper
setblock 461 286 520 minecraft:waxed_cut_copper
setblock 465 286 514 minecraft:light_blue_stained_glass
setblock 465 286 525 minecraft:light_blue_stained_glass
fill 465 286 526 465 307 528 minecraft:black_concrete
setblock 465 286 542 minecraft:light_blue_stained_glass
setblock 425 287 510 minecraft:sea_lantern
fill 465 287 514 465 293 514 minecraft:black_concrete
fill 465 287 525 465 307 525 minecraft:black_concrete
fill 465 287 542 465 307 542 minecraft:black_concrete
fill 423 288 518 423 290 518 minecraft:gold_block
fill 423 288 534 423 290 534 minecraft:gold_block
fill 423 288 550 423 290 550 minecraft:gold_block
fill 423 288 551 423 307 551 minecraft:black_concrete
fill 425 288 510 425 307 510 minecraft:black_concrete
fill 427 288 510 427 290 510 minecraft:gold_block
fill 437 288 552 437 290 552 minecraft:gold_block
fill 443 288 510 443 290 510 minecraft:gold_block
fill 453 288 552 453 290 552 minecraft:gold_block
fill 459 288 510 459 290 510 minecraft:gold_block
fill 465 288 520 465 290 520 minecraft:gold_block
fill 465 288 536 465 290 536 minecraft:gold_block
setblock 429 289 510 minecraft:light_blue_stained_glass
setblock 455 289 510 minecraft:sea_lantern
fill 423 290 520 423 291 520 minecraft:light_blue_stained_glass
setblock 426 290 513 minecraft:light[level=14]
setblock 426 290 521 minecraft:light[level=14]
setblock 426 290 529 minecraft:light[level=14]
setblock 426 290 537 minecraft:light[level=14]
setblock 426 290 545 minecraft:light[level=14]
fill 429 290 510 429 307 510 minecraft:black_concrete
setblock 434 290 513 minecraft:light[level=14]
setblock 434 290 521 minecraft:light[level=14]
setblock 434 290 529 minecraft:light[level=14]
setblock 434 290 537 minecraft:light[level=14]
setblock 434 290 545 minecraft:light[level=14]
setblock 442 290 513 minecraft:light[level=14]
setblock 442 290 521 minecraft:light[level=14]
setblock 442 290 529 minecraft:light[level=14]
setblock 442 290 537 minecraft:light[level=14]
setblock 442 290 545 minecraft:light[level=14]
setblock 450 290 513 minecraft:light[level=14]
setblock 450 290 521 minecraft:light[level=14]
setblock 450 290 529 minecraft:light[level=14]
setblock 450 290 537 minecraft:light[level=14]
setblock 450 290 545 minecraft:light[level=14]
fill 455 290 510 455 307 510 minecraft:black_concrete
setblock 458 290 521 minecraft:light[level=14]
setblock 458 290 529 minecraft:light[level=14]
setblock 458 290 537 minecraft:light[level=14]
setblock 458 290 545 minecraft:light[level=14]
setblock 465 290 546 minecraft:white_concrete
fill 423 291 518 423 296 518 minecraft:black_concrete
setblock 423 291 526 minecraft:white_concrete
fill 423 291 534 423 296 534 minecraft:black_concrete
setblock 423 291 540 minecraft:light_blue_stained_glass
fill 423 291 550 423 296 550 minecraft:black_concrete
fill 427 291 510 427 296 510 minecraft:black_concrete
fill 437 291 552 437 296 552 minecraft:black_concrete
fill 443 291 510 443 296 510 minecraft:black_concrete
fill 453 291 552 453 296 552 minecraft:black_concrete
setblock 454 291 552 minecraft:sea_lantern
fill 455 291 552 457 292 552 minecraft:black_concrete
fill 459 291 510 459 296 510 minecraft:black_concrete
fill 459 291 519 459 291 521 minecraft:waxed_cut_copper
fill 460 291 519 461 291 519 minecraft:waxed_cut_copper
fill 460 291 521 461 291 521 minecraft:waxed_cut_copper
setblock 461 291 520 minecraft:waxed_cut_copper
setblock 461 291 552 minecraft:white_concrete
fill 465 291 520 465 296 520 minecraft:black_concrete
fill 465 291 536 465 296 536 minecraft:black_concrete
fill 465 291 546 465 307 546 minecraft:black_concrete
fill 423 292 520 423 307 520 minecraft:black_concrete
fill 423 292 526 423 307 526 minecraft:black_concrete
fill 423 292 540 423 307 540 minecraft:black_concrete
setblock 423 292 541 minecraft:sea_lantern
setblock 423 292 546 minecraft:white_concrete
setblock 431 292 552 minecraft:sea_lantern
fill 454 292 552 454 307 552 minecraft:black_concrete
fill 457 292 512 457 292 514 minecraft:waxed_cut_copper
fill 458 292 511 460 292 511 minecraft:waxed_cut_copper
fill 458 292 515 460 292 515 minecraft:waxed_cut_copper
fill 461 292 512 461 292 514 minecraft:waxed_cut_copper
fill 461 292 552 461 307 552 minecraft:black_concrete
fill 423 293 541 423 307 541 minecraft:black_concrete
fill 423 293 546 423 307 546 minecraft:black_concrete
setblock 430 293 510 minecraft:light_blue_stained_glass
fill 431 293 552 431 307 552 minecraft:black_concrete
setblock 435 293 510 minecraft:white_concrete
setblock 435 293 552 minecraft:light_blue_stained_glass
setblock 440 293 552 minecraft:sea_lantern
setblock 441 293 552 minecraft:white_concrete
setblock 455 293 552 minecraft:sea_lantern
fill 456 293 552 457 307 552 minecraft:black_concrete
setblock 465 293 541 minecraft:sea_lantern
setblock 423 294 524 minecraft:sea_lantern
fill 430 294 510 430 307 510 minecraft:black_concrete
fill 435 294 510 435 304 510 minecraft:black_concrete
fill 435 294 552 435 307 552 minecraft:black_concrete
fill 440 294 552 441 307 552 minecraft:black_concrete
fill 455 294 552 455 307 552 minecraft:black_concrete
setblock 465 294 514 minecraft:white_concrete
setblock 465 294 524 minecraft:sea_lantern
setblock 465 294 540 minecraft:light_blue_stained_glass
fill 465 294 541 465 307 541 minecraft:black_concrete
fill 423 295 524 423 307 524 minecraft:black_concrete
setblock 444 295 552 minecraft:white_concrete
setblock 459 295 552 minecraft:white_concrete
fill 465 295 514 465 307 514 minecraft:black_concrete
setblock 465 295 516 minecraft:light_blue_stained_glass
fill 465 295 524 465 307 524 minecraft:black_concrete
fill 465 295 540 465 307 540 minecraft:black_concrete
setblock 423 296 512 minecraft:sea_lantern
fill 444 296 552 444 307 552 minecraft:black_concrete
fill 459 296 519 459 296 521 minecraft:waxed_cut_copper
fill 459 296 552 459 304 552 minecraft:black_concrete
fill 460 296 519 461 296 519 minecraft:waxed_cut_copper
fill 460 296 521 461 296 521 minecraft:waxed_cut_copper
setblock 461 296 520 minecraft:waxed_cut_copper
fill 465 296 516 465 298 516 minecraft:black_concrete
fill 423 297 512 423 307 512 minecraft:black_concrete
fill 423 297 518 423 299 518 minecraft:gold_block
fill 423 297 534 423 299 534 minecraft:gold_block
setblock 423 297 537 minecraft:sea_lantern
fill 423 297 550 423 299 550 minecraft:gold_block
fill 427 297 510 427 299 510 minecraft:gold_block
setblock 436 297 510 minecraft:light_blue_stained_glass
fill 437 297 552 437 299 552 minecraft:gold_block
fill 443 297 510 443 299 510 minecraft:gold_block
fill 453 297 552 453 299 552 minecraft:gold_block
fill 459 297 510 459 299 510 minecraft:gold_block
fill 465 297 520 465 299 520 minecraft:gold_block
setblock 465 297 522 minecraft:light_blue_stained_glass
setblock 465 297 532 minecraft:white_concrete
fill 465 297 536 465 299 536 minecraft:gold_block
setblock 465 297 537 minecraft:light_blue_stained_glass
setblock 423 298 513 minecraft:white_concrete
fill 423 298 537 423 307 537 minecraft:black_concrete
setblock 426 298 513 minecraft:light[level=14]
setblock 426 298 521 minecraft:light[level=14]
setblock 426 298 529 minecraft:light[level=14]
setblock 426 298 537 minecraft:light[level=14]
setblock 426 298 545 minecraft:light[level=14]
setblock 434 298 513 minecraft:light[level=14]
setblock 434 298 521 minecraft:light[level=14]
setblock 434 298 529 minecraft:light[level=14]
setblock 434 298 537 minecraft:light[level=14]
setblock 434 298 545 minecraft:light[level=14]
fill 436 298 510 436 307 510 minecraft:black_concrete
setblock 442 298 513 minecraft:light[level=14]
setblock 442 298 521 minecraft:light[level=14]
setblock 442 298 529 minecraft:light[level=14]
setblock 442 298 537 minecraft:light[level=14]
setblock 442 298 545 minecraft:light[level=14]
setblock 450 298 513 minecraft:light[level=14]
setblock 450 298 521 minecraft:light[level=14]
setblock 450 298 529 minecraft:light[level=14]
setblock 450 298 537 minecraft:light[level=14]
setblock 450 298 545 minecraft:light[level=14]
fill 457 298 512 457 298 514 minecraft:waxed_cut_copper
fill 458 298 511 460 298 511 minecraft:waxed_cut_copper
fill 458 298 515 460 298 515 minecraft:waxed_cut_copper
setblock 458 298 521 minecraft:light[level=14]
setblock 458 298 529 minecraft:light[level=14]
setblock 458 298 537 minecraft:light[level=14]
setblock 458 298 545 minecraft:light[level=14]
fill 461 298 512 461 298 514 minecraft:waxed_cut_copper
fill 465 298 522 465 307 522 minecraft:black_concrete
fill 465 298 532 465 307 532 minecraft:black_concrete
fill 465 298 537 465 307 537 minecraft:black_concrete
setblock 423 299 513 minecraft:black_concrete
fill 461 299 520 463 300 520 minecraft:waxed_copper_block
setblock 463 299 552 minecraft:white_concrete
setblock 465 299 513 minecraft:light_blue_stained_glass
setblock 465 299 516 minecraft:white_concrete
setblock 465 299 534 minecraft:sea_lantern
setblock 423 300 513 minecraft:white_concrete
fill 423 300 518 423 307 518 minecraft:black_concrete
fill 423 300 534 423 307 534 minecraft:black_concrete
fill 423 300 550 423 307 550 minecraft:black_concrete
setblock 426 300 510 minecraft:white_concrete
fill 427 300 510 427 307 510 minecraft:black_concrete
setblock 434 300 510 minecraft:white_concrete
fill 437 300 552 437 307 552 minecraft:black_concrete
fill 443 300 510 443 307 510 minecraft:black_concrete
setblock 448 300 552 minecraft:white_concrete
fill 453 300 552 453 305 552 minecraft:black_concrete
fill 459 300 510 459 307 510 minecraft:black_concrete
setblock 459 300 520 minecraft:sea_lantern
fill 463 300 552 463 307 552 minecraft:black_concrete
fill 465 300 513 465 306 513 minecraft:black_concrete
fill 465 300 516 465 307 516 minecraft:black_concrete
fill 465 300 520 465 307 520 minecraft:black_concrete
fill 465 300 534 465 307 534 minecraft:black_concrete
fill 465 300 536 465 307 536 minecraft:black_concrete
fill 423 301 513 423 307 513 minecraft:black_concrete
setblock 423 301 531 minecraft:white_concrete
fill 426 301 510 426 307 510 minecraft:black_concrete
fill 434 301 510 434 307 510 minecraft:black_concrete
fill 448 301 552 448 303 552 minecraft:black_concrete
setblock 423 302 511 minecraft:light_blue_stained_glass
fill 423 302 531 423 305 531 minecraft:black_concrete
setblock 433 302 552 minecraft:white_concrete
fill 423 303 511 423 307 511 minecraft:black_concrete
fill 433 303 552 433 307 552 minecraft:black_concrete
setblock 448 304 552 minecraft:sea_lantern
setblock 465 304 529 minecraft:light_blue_stained_glass
setblock 423 305 523 minecraft:sea_lantern
setblock 423 305 535 minecraft:sea_lantern
setblock 435 305 510 minecraft:sea_lantern
setblock 447 305 510 minecraft:sea_lantern
fill 448 305 552 448 307 552 minecraft:black_concrete
setblock 459 305 552 minecraft:sea_lantern
fill 465 305 529 465 307 529 minecraft:black_concrete
setblock 465 305 533 minecraft:sea_lantern
fill 423 306 523 423 307 523 minecraft:black_concrete
setblock 423 306 531 minecraft:white_concrete
fill 423 306 535 423 307 535 minecraft:black_concrete
setblock 423 306 539 minecraft:white_concrete
fill 435 306 510 435 307 510 minecraft:black_concrete
setblock 447 306 510 minecraft:black_concrete
setblock 453 306 552 minecraft:white_concrete
fill 459 306 552 459 307 552 minecraft:black_concrete
fill 465 306 533 465 307 533 minecraft:black_concrete
setblock 423 307 525 minecraft:white_concrete
setblock 423 307 531 minecraft:black_concrete
setblock 423 307 539 minecraft:black_concrete
setblock 442 307 552 minecraft:white_concrete
setblock 447 307 510 minecraft:white_concrete
setblock 453 307 552 minecraft:black_concrete
setblock 465 307 513 minecraft:light_blue_stained_glass
