setblock 119 289 500 minecraft:sea_lantern
setblock 119 289 502 minecraft:sea_lantern
setblock 119 289 504 minecraft:sea_lantern
setblock 120 289 499 minecraft:sea_lantern
setblock 120 289 501 minecraft:sea_lantern
setblock 120 289 503 minecraft:sea_lantern
setblock 121 289 498 minecraft:sea_lantern
setblock 121 289 500 minecraft:sea_lantern
setblock 121 289 502 minecraft:sea_lantern
setblock 121 289 504 minecraft:sea_lantern
setblock 122 289 499 minecraft:sea_lantern
setblock 122 289 501 minecraft:sea_lantern
setblock 122 289 503 minecraft:sea_lantern
setblock 123 289 498 minecraft:sea_lantern
setblock 123 289 500 minecraft:sea_lantern
setblock 123 289 502 minecraft:sea_lantern
setblock 123 289 504 minecraft:sea_lantern
setblock 124 289 499 minecraft:sea_lantern
setblock 124 289 501 minecraft:sea_lantern
setblock 124 289 503 minecraft:sea_lantern
fill 125 289 489 125 289 490 minecraft:sculk
setblock 125 289 498 minecraft:sea_lantern
setblock 125 289 500 minecraft:sea_lantern
setblock 125 289 502 minecraft:sea_lantern
setblock 125 289 504 minecraft:sea_lantern
fill 126 289 491 126 289 492 minecraft:sculk
fill 127 289 493 128 289 493 minecraft:sculk
fill 129 289 486 132 289 486 minecraft:sculk
fill 129 289 494 130 289 494 minecraft:sculk
fill 131 289 493 132 289 493 minecraft:sculk
fill 132 289 487 133 289 487 minecraft:sculk
fill 132 289 492 133 289 492 minecraft:sculk
fill 133 289 488 133 289 491 minecraft:sculk
fill 95 290 482 95 291 482 minecraft:deepslate_bricks
fill 95 290 484 95 291 484 minecraft:deepslate_bricks
fill 95 290 486 95 291 486 minecraft:deepslate_bricks
fill 95 290 488 95 291 488 minecraft:deepslate_bricks
fill 96 290 481 96 291 481 minecraft:deepslate_bricks
fill 96 290 483 96 291 483 minecraft:deepslate_bricks
fill 96 290 485 96 291 485 minecraft:deepslate_bricks
fill 96 290 487 96 291 487 minecraft:deepslate_bricks
fill 96 290 489 96 291 489 minecraft:deepslate_bricks
fill 97 290 482 97 291 482 minecraft:deepslate_bricks
fill 97 290 484 97 291 484 minecraft:deepslate_bricks
fill 97 290 486 97 291 486 minecraft:deepslate_bricks
fill 97 290 488 97 291 488 minecraft:deepslate_bricks
fill 98 290 481 98 291 481 minecraft:deepslate_bricks
fill 98 290 483 98 291 483 minecraft:deepslate_bricks
setblock 98 290 485 minecraft:deepslate_bricks
fill 98 290 487 98 291 487 minecraft:deepslate_bricks
fill 98 290 489 98 291 489 minecraft:deepslate_bricks
fill 99 290 482 99 291 482 minecraft:deepslate_bricks
fill 99 290 484 99 291 484 minecraft:deepslate_bricks
fill 99 290 486 99 291 486 minecraft:deepslate_bricks
fill 99 290 488 99 291 488 minecraft:deepslate_bricks
fill 100 290 481 100 291 481 minecraft:deepslate_bricks
fill 100 290 483 100 291 483 minecraft:deepslate_bricks
setblock 100 290 485 minecraft:deepslate_bricks
fill 100 290 487 100 291 487 minecraft:deepslate_bricks
fill 100 290 489 100 291 489 minecraft:deepslate_bricks
fill 101 290 482 101 291 482 minecraft:deepslate_bricks
fill 101 290 484 101 291 484 minecraft:deepslate_bricks
fill 101 290 486 101 291 486 minecraft:deepslate_bricks
fill 101 290 488 101 291 488 minecraft:deepslate_bricks
fill 101 290 494 101 291 494 minecraft:deepslate_bricks
fill 101 290 496 101 291 496 minecraft:deepslate_bricks
fill 101 290 498 101 291 498 minecraft:deepslate_bricks
fill 101 290 500 101 291 500 minecraft:deepslate_bricks
fill 101 290 502 101 291 502 minecraft:deepslate_bricks
fill 101 290 504 101 291 504 minecraft:deepslate_bricks
setblock 102 290 465 minecraft:cyan_stained_glass
fill 102 290 469 102 290 470 minecraft:cyan_stained_glass
fill 102 290 481 102 291 481 minecraft:deepslate_bricks
fill 102 290 483 102 291 483 minecraft:deepslate_bricks
fill 102 290 485 102 291 485 minecraft:deepslate_bricks
fill 102 290 487 102 291 487 minecraft:deepslate_bricks
fill 102 290 489 102 291 489 minecraft:deepslate_bricks
fill 102 290 495 102 291 495 minecraft:deepslate_bricks
fill 102 290 497 102 291 497 minecraft:deepslate_bricks
fill 102 290 499 102 291 499 minecraft:deepslate_bricks
fill 102 290 501 102 291 501 minecraft:deepslate_bricks
fill 102 290 503 102 291 503 minecraft:deepslate_bricks
fill 103 290 494 103 291 494 minecraft:deepslate_bricks
fill 103 290 496 103 291 496 minecraft:deepslate_bricks
fill 103 290 498 103 291 498 minecraft:deepslate_bricks
fill 103 290 500 103 291 500 minecraft:deepslate_bricks
fill 103 290 502 103 291 502 minecraft:deepslate_bricks
fill 103 290 504 103 291 504 minecraft:deepslate_bricks
fill 104 290 495 104 291 495 minecraft:deepslate_bricks
fill 104 290 497 104 291 497 minecraft:deepslate_bricks
fill 104 290 499 104 291 499 minecraft:deepslate_bricks
fill 104 290 501 104 291 501 minecraft:deepslate_bricks
fill 104 290 503 104 291 503 minecraft:deepslate_bricks
fill 105 290 494 105 291 494 minecraft:deepslate_bricks
fill 105 290 496 105 291 496 minecraft:deepslate_bricks
fill 105 290 498 105 291 498 minecraft:deepslate_bricks
fill 105 290 500 105 291 500 minecraft:deepslate_bricks
fill 105 290 502 105 291 502 minecraft:deepslate_bricks
fill 105 290 504 105 291 504 minecraft:deepslate_bricks
fill 106 290 495 106 291 495 minecraft:deepslate_bricks
fill 106 290 497 106 291 497 minecraft:deepslate_bricks
fill 106 290 499 106 291 499 minecraft:deepslate_bricks
fill 106 290 501 106 291 501 minecraft:deepslate_bricks
fill 106 290 503 106 291 503 minecraft:deepslate_bricks
fill 107 290 494 107 291 494 minecraft:deepslate_bricks
fill 107 290 496 107 291 496 minecraft:deepslate_bricks
fill 107 290 498 107 291 498 minecraft:deepslate_bricks
fill 107 290 500 107 291 500 minecraft:deepslate_bricks
fill 107 290 502 107 291 502 minecraft:deepslate_bricks
fill 107 290 504 107 291 504 minecraft:deepslate_bricks
fill 108 290 495 108 291 495 minecraft:deepslate_bricks
fill 108 290 497 108 291 497 minecraft:deepslate_bricks
fill 108 290 499 108 291 499 minecraft:deepslate_bricks
fill 108 290 501 108 291 501 minecraft:deepslate_bricks
fill 108 290 503 108 291 503 minecraft:deepslate_bricks
fill 109 290 494 109 291 494 minecraft:deepslate_bricks
fill 109 290 496 109 291 496 minecraft:deepslate_bricks
fill 109 290 498 109 291 498 minecraft:deepslate_bricks
fill 109 290 500 109 291 500 minecraft:deepslate_bricks
fill 109 290 502 109 291 502 minecraft:deepslate_bricks
fill 109 290 504 109 291 504 minecraft:deepslate_bricks
fill 110 290 495 110 291 495 minecraft:deepslate_bricks
fill 110 290 497 110 291 497 minecraft:deepslate_bricks
fill 110 290 499 110 291 499 minecraft:deepslate_bricks
fill 110 290 501 110 291 501 minecraft:deepslate_bricks
fill 110 290 503 110 291 503 minecraft:deepslate_bricks
fill 111 290 494 111 291 494 minecraft:deepslate_bricks
fill 111 290 496 111 291 496 minecraft:deepslate_bricks
fill 111 290 498 111 291 498 minecraft:deepslate_bricks
fill 111 290 500 111 291 500 minecraft:deepslate_bricks
fill 111 290 502 111 291 502 minecraft:deepslate_bricks
fill 111 290 504 111 291 504 minecraft:deepslate_bricks
fill 115 290 498 115 291 498 minecraft:deepslate_bricks
fill 115 290 500 115 291 500 minecraft:deepslate_bricks
fill 115 290 502 115 291 502 minecraft:deepslate_bricks
fill 115 290 504 115 291 504 minecraft:deepslate_bricks
fill 116 290 499 116 291 499 minecraft:deepslate_bricks
fill 116 290 501 116 291 501 minecraft:deepslate_bricks
fill 116 290 503 116 291 503 minecraft:deepslate_bricks
fill 117 290 498 117 291 498 minecraft:deepslate_bricks
fill 117 290 500 117 291 500 minecraft:deepslate_bricks
fill 117 290 502 117 291 502 minecraft:deepslate_bricks
fill 117 290 504 117 291 504 minecraft:deepslate_bricks
fill 118 290 499 118 291 499 minecraft:deepslate_bricks
fill 118 290 501 118 291 501 minecraft:deepslate_bricks
fill 118 290 503 118 291 503 minecraft:deepslate_bricks
fill 119 290 498 119 291 498 minecraft:deepslate_bricks
fill 119 290 500 119 291 500 minecraft:deepslate_bricks
fill 119 290 502 119 291 502 minecraft:deepslate_bricks
fill 119 290 504 119 291 504 minecraft:deepslate_bricks
fill 120 290 499 120 291 499 minecraft:deepslate_bricks
fill 120 290 501 120 291 501 minecraft:deepslate_bricks
fill 120 290 503 120 291 503 minecraft:deepslate_bricks
fill 121 290 498 121 291 498 minecraft:deepslate_bricks
fill 121 290 500 121 291 500 minecraft:deepslate_bricks
fill 121 290 502 121 291 502 minecraft:deepslate_bricks
fill 121 290 504 121 291 504 minecraft:deepslate_bricks
fill 122 290 499 122 291 499 minecraft:deepslate_bricks
fill 122 290 501 122 291 501 minecraft:deepslate_bricks
fill 122 290 503 122 291 503 minecraft:deepslate_bricks
fill 123 290 498 123 291 498 minecraft:deepslate_bricks
fill 123 290 500 123 291 500 minecraft:deepslate_bricks
fill 123 290 502 123 291 502 minecraft:deepslate_bricks
fill 123 290 504 123 291 504 minecraft:deepslate_bricks
fill 124 290 499 124 291 499 minecraft:deepslate_bricks
fill 124 290 501 124 291 501 minecraft:deepslate_bricks
fill 124 290 503 124 291 503 minecraft:deepslate_bricks
fill 125 290 498 125 291 498 minecraft:deepslate_bricks
fill 125 290 500 125 291 500 minecraft:deepslate_bricks
fill 125 290 502 125 291 502 minecraft:deepslate_bricks
fill 125 290 504 125 291 504 minecraft:deepslate_bricks
fill 129 290 487 131 296 487 minecraft:deepslate_bricks
fill 95 291 501 95 294 501 minecraft:cyan_stained_glass
fill 96 291 500 97 294 500 minecraft:cyan_stained_glass
fill 98 291 485 100 291 485 minecraft:cyan_concrete
fill 94 292 469 94 307 469 minecraft:deepslate_tiles
fill 94 292 470 94 292 471 minecraft:sea_lantern
fill 94 292 472 94 307 472 minecraft:deepslate_tiles
fill 94 292 481 94 307 481 minecraft:deepslate_tiles
fill 94 292 482 94 292 483 minecraft:sea_lantern
fill 94 292 484 94 307 484 minecraft:deepslate_tiles
fill 94 292 493 94 307 493 minecraft:deepslate_tiles
fill 94 292 494 94 292 495 minecraft:sea_lantern
fill 94 292 496 94 307 496 minecraft:deepslate_tiles
fill 94 292 505 94 307 505 minecraft:deepslate_tiles
setblock 95 292 482 minecraft:sea_lantern
setblock 95 292 484 minecraft:sea_lantern
fill 95 292 485 95 293 485 minecraft:cyan_concrete
setblock 95 292 486 minecraft:sea_lantern
setblock 95 292 488 minecraft:sea_lantern
fill 95 292 505 96 292 505 minecraft:sea_lantern
setblock 96 292 481 minecraft:sea_lantern
setblock 96 292 483 minecraft:sea_lantern
setblock 96 292 485 minecraft:sea_lantern
setblock 96 292 487 minecraft:sea_lantern
setblock 96 292 489 minecraft:sea_lantern
fill 96 292 499 98 293 499 minecraft:cyan_stained_glass
fill 96 292 501 98 293 501 minecraft:cyan_stained_glass
setblock 97 292 482 minecraft:sea_lantern
setblock 97 292 484 minecraft:sea_lantern
setblock 97 292 485 minecraft:cyan_concrete
setblock 97 292 486 minecraft:sea_lantern
setblock 97 292 488 minecraft:sea_lantern
fill 97 292 505 97 307 505 minecraft:deepslate_tiles
setblock 98 292 481 minecraft:sea_lantern
setblock 98 292 483 minecraft:sea_lantern
setblock 98 292 485 minecraft:sea_lantern
setblock 98 292 487 minecraft:sea_lantern
setblock 98 292 489 minecraft:sea_lantern
fill 98 292 500 100 293 500 minecraft:cyan_stained_glass
setblock 99 292 482 minecraft:sea_lantern
setblock 99 292 484 minecraft:sea_lantern
setblock 99 292 485 minecraft:cyan_concrete
setblock 99 292 486 minecraft:sea_lantern
setblock 99 292 488 minecraft:sea_lantern
setblock 100 292 481 minecraft:sea_lantern
setblock 100 292 483 minecraft:sea_lantern
setblock 100 292 485 minecraft:sea_lantern
setblock 100 292 487 minecraft:sea_lantern
setblock 100 292 489 minecraft:sea_lantern
fill 101 292 463 101 307 463 minecraft:deepslate_tiles
setblock 101 292 482 minecraft:sea_lantern
setblock 101 292 484 minecraft:sea_lantern
setblock 101 292 486 minecraft:sea_lantern
setblock 101 292 488 minecraft:sea_lantern
setblock 101 292 494 minecraft:sea_lantern
setblock 101 292 496 minecraft:sea_lantern
setblock 101 292 498 minecraft:sea_lantern
setblock 101 292 500 minecraft:sea_lantern
setblock 101 292 502 minecraft:sea_lantern
setblock 101 292 504 minecraft:sea_lantern
fill 102 292 463 103 292 463 minecraft:sea_lantern
setblock 102 292 481 minecraft:sea_lantern
setblock 102 292 483 minecraft:sea_lantern
setblock 102 292 485 minecraft:sea_lantern
setblock 102 292 487 minecraft:sea_lantern
setblock 102 292 489 minecraft:sea_lantern
setblock 102 292 495 minecraft:sea_lantern
setblock 102 292 497 minecraft:sea_lantern
setblock 102 292 499 minecraft:sea_lantern
setblock 102 292 501 minecraft:sea_lantern
setblock 102 292 503 minecraft:sea_lantern
setblock 103 292 494 minecraft:sea_lantern
setblock 103 292 496 minecraft:sea_lantern
setblock 103 292 498 minecraft:sea_lantern
setblock 103 292 500 minecraft:sea_lantern
setblock 103 292 502 minecraft:sea_lantern
setblock 103 292 504 minecraft:sea_lantern
fill 104 292 463 104 307 463 minecraft:deepslate_tiles
setblock 104 292 495 minecraft:sea_lantern
setblock 104 292 497 minecraft:sea_lantern
setblock 104 292 499 minecraft:sea_lantern
setblock 104 292 501 minecraft:sea_lantern
setblock 104 292 503 minecraft:sea_lantern
setblock 105 292 494 minecraft:sea_lantern
setblock 105 292 496 minecraft:sea_lantern
setblock 105 292 498 minecraft:sea_lantern
setblock 105 292 500 minecraft:sea_lantern
setblock 105 292 502 minecraft:sea_lantern
setblock 105 292 504 minecraft:sea_lantern
setblock 106 292 495 minecraft:sea_lantern
setblock 106 292 497 minecraft:sea_lantern
setblock 106 292 499 minecraft:sea_lantern
setblock 106 292 501 minecraft:sea_lantern
setblock 106 292 503 minecraft:sea_lantern
fill 106 292 505 106 307 505 minecraft:deepslate_tiles
setblock 107 292 494 minecraft:sea_lantern
setblock 107 292 496 minecraft:sea_lantern
setblock 107 292 498 minecraft:sea_lantern
setblock 107 292 500 minecraft:sea_lantern
setblock 107 292 502 minecraft:sea_lantern
fill 107 292 504 107 292 505 minecraft:sea_lantern
setblock 108 292 495 minecraft:sea_lantern
setblock 108 292 497 minecraft:sea_lantern
setblock 108 292 499 minecraft:sea_lantern
setblock 108 292 501 minecraft:sea_lantern
setblock 108 292 503 minecraft:sea_lantern
setblock 108 292 505 minecraft:sea_lantern
setblock 109 292 494 minecraft:sea_lantern
setblock 109 292 496 minecraft:sea_lantern
setblock 109 292 498 minecraft:sea_lantern
setblock 109 292 500 minecraft:sea_lantern
setblock 109 292 502 minecraft:sea_lantern
setblock 109 292 504 minecraft:sea_lantern
fill 109 292 505 109 307 505 minecraft:deepslate_tiles
setblock 110 292 495 minecraft:sea_lantern
setblock 110 292 497 minecraft:sea_lantern
setblock 110 292 499 minecraft:sea_lantern
setblock 110 292 501 minecraft:sea_lantern
setblock 110 292 503 minecraft:sea_lantern
setblock 111 292 494 minecraft:sea_lantern
setblock 111 292 496 minecraft:sea_lantern
setblock 111 292 498 minecraft:sea_lantern
setblock 111 292 500 minecraft:sea_lantern
setblock 111 292 502 minecraft:sea_lantern
setblock 111 292 504 minecraft:sea_lantern
fill 113 292 463 113 307 463 minecraft:deepslate_tiles
fill 114 292 463 115 292 463 minecraft:sea_lantern
setblock 115 292 498 minecraft:sea_lantern
setblock 115 292 500 minecraft:sea_lantern
setblock 115 292 502 minecraft:sea_lantern
setblock 115 292 504 minecraft:sea_lantern
fill 116 292 463 116 307 463 minecraft:deepslate_tiles
setblock 116 292 499 minecraft:sea_lantern
setblock 116 292 501 minecraft:sea_lantern
setblock 116 292 503 minecraft:sea_lantern
setblock 117 292 498 minecraft:sea_lantern
setblock 117 292 500 minecraft:sea_lantern
setblock 117 292 502 minecraft:sea_lantern
setblock 117 292 504 minecraft:sea_lantern
setblock 118 292 499 minecraft:sea_lantern
setblock 118 292 501 minecraft:sea_lantern
setblock 118 292 503 minecraft:sea_lantern
fill 118 292 505 118 307 505 minecraft:deepslate_tiles
setblock 119 292 498 minecraft:sea_lantern
setblock 119 292 500 minecraft:sea_lantern
setblock 119 292 502 minecraft:sea_lantern
fill 119 292 504 119 292 505 minecraft:sea_lantern
setblock 120 292 499 minecraft:sea_lantern
setblock 120 292 501 minecraft:sea_lantern
setblock 120 292 503 minecraft:sea_lantern
setblock 120 292 505 minecraft:sea_lantern
setblock 121 292 498 minecraft:sea_lantern
setblock 121 292 500 minecraft:sea_lantern
setblock 121 292 502 minecraft:sea_lantern
setblock 121 292 504 minecraft:sea_lantern
fill 121 292 505 121 307 505 minecraft:deepslate_tiles
setblock 122 292 499 minecraft:sea_lantern
setblock 122 292 501 minecraft:sea_lantern
setblock 122 292 503 minecraft:sea_lantern
setblock 123 292 498 minecraft:sea_lantern
setblock 123 292 500 minecraft:sea_lantern
setblock 123 292 502 minecraft:sea_lantern
setblock 123 292 504 minecraft:sea_lantern
setblock 124 292 499 minecraft:sea_lantern
setblock 124 292 501 minecraft:sea_lantern
setblock 124 292 503 minecraft:sea_lantern
fill 125 292 463 125 307 463 minecraft:deepslate_tiles
setblock 125 292 498 minecraft:sea_lantern
setblock 125 292 500 minecraft:sea_lantern
setblock 125 292 502 minecraft:sea_lantern
setblock 125 292 504 minecraft:sea_lantern
fill 126 292 463 127 292 463 minecraft:sea_lantern
fill 128 292 463 128 307 463 minecraft:deepslate_tiles
fill 130 292 505 130 307 505 minecraft:deepslate_tiles
fill 131 292 505 132 292 505 minecraft:sea_lantern
fill 133 292 505 133 307 505 minecraft:deepslate_tiles
fill 136 292 464 136 307 464 minecraft:deepslate_tiles
fill 136 292 465 136 292 466 minecraft:sea_lantern
fill 136 292 467 136 307 467 minecraft:deepslate_tiles
fill 136 292 476 136 307 476 minecraft:deepslate_tiles
fill 136 292 477 136 292 478 minecraft:sea_lantern
fill 136 292 479 136 307 479 minecraft:deepslate_tiles
fill 136 292 488 136 307 488 minecraft:deepslate_tiles
fill 136 292 489 136 292 490 minecraft:sea_lantern
fill 136 292 491 136 307 491 minecraft:deepslate_tiles
fill 136 292 500 136 307 500 minecraft:deepslate_tiles
fill 136 292 501 136 292 502 minecraft:sea_lantern
fill 136 292 503 136 307 503 minecraft:deepslate_tiles
fill 94 293 470 94 307 471 minecraft:deepslate_tiles
fill 94 293 482 94 307 483 minecraft:deepslate_tiles
fill 94 293 494 94 307 495 minecraft:deepslate_tiles
fill 95 293 482 95 294 482 minecraft:deepslate_bricks
fill 95 293 484 95 294 484 minecraft:deepslate_bricks
fill 95 293 486 95 294 486 minecraft:deepslate_bricks
fill 95 293 488 95 294 488 minecraft:deepslate_bricks
fill 95 293 505 96 307 505 minecraft:deepslate_tiles
fill 96 293 481 96 294 481 minecraft:deepslate_bricks
fill 96 293 483 96 294 483 minecraft:deepslate_bricks
setblock 96 293 485 minecraft:cyan_concrete
fill 96 293 487 96 294 487 minecraft:deepslate_bricks
fill 96 293 489 96 294 489 minecraft:deepslate_bricks
setblock 97 293 466 minecraft:light[level=11]
setblock 97 293 474 minecraft:light[level=11]
fill 97 293 482 97 294 482 minecraft:deepslate_bricks
fill 97 293 484 97 294 486 minecraft:deepslate_bricks
fill 97 293 488 97 294 488 minecraft:deepslate_bricks
setblock 97 293 490 minecraft:light[level=11]
setblock 97 293 498 minecraft:light[level=11]
fill 98 293 481 98 294 481 minecraft:deepslate_bricks
fill 98 293 483 98 294 483 minecraft:deepslate_bricks
fill 98 293 485 100 294 485 minecraft:deepslate_bricks
fill 98 293 487 98 294 487 minecraft:deepslate_bricks
fill 98 293 489 98 294 489 minecraft:deepslate_bricks
fill 99 293 482 99 294 482 minecraft:deepslate_bricks
fill 99 293 484 99 294 484 minecraft:deepslate_bricks
fill 99 293 486 99 294 486 minecraft:deepslate_bricks
fill 99 293 488 99 294 488 minecraft:deepslate_bricks
fill 100 293 481 100 294 481 minecraft:deepslate_bricks
fill 100 293 483 100 294 483 minecraft:deepslate_bricks
fill 100 293 487 100 294 487 minecraft:deepslate_bricks
fill 100 293 489 100 294 489 minecraft:deepslate_bricks
fill 101 293 482 101 294 482 minecraft:deepslate_bricks
fill 101 293 484 101 294 484 minecraft:deepslate_bricks
fill 101 293 486 101 294 486 minecraft:deepslate_bricks
fill 101 293 488 101 294 488 minecraft:deepslate_bricks
fill 101 293 494 101 294 494 minecraft:deepslate_bricks
fill 101 293 496 101 294 496 minecraft:deepslate_bricks
fill 101 293 498 101 294 498 minecraft:deepslate_bricks
fill 101 293 500 101 294 500 minecraft:deepslate_bricks
fill 101 293 502 101 294 502 minecraft:deepslate_bricks
fill 101 293 504 101 294 504 minecraft:deepslate_bricks
fill 102 293 463 103 307 463 minecraft:deepslate_tiles
fill 102 293 481 102 294 481 minecraft:deepslate_bricks
fill 102 293 483 102 294 483 minecraft:deepslate_bricks
fill 102 293 485 102 294 485 minecraft:deepslate_bricks
fill 102 293 487 102 294 487 minecraft:deepslate_bricks
fill 102 293 489 102 294 489 minecraft:deepslate_bricks
fill 102 293 495 102 294 495 minecraft:deepslate_bricks
fill 102 293 497 102 294 497 minecraft:deepslate_bricks
fill 102 293 499 102 294 499 minecraft:deepslate_bricks
fill 102 293 501 102 294 501 minecraft:deepslate_bricks
fill 102 293 503 102 294 503 minecraft:deepslate_bricks
fill 103 293 494 103 294 494 minecraft:deepslate_bricks
fill 103 293 496 103 294 496 minecraft:deepslate_bricks
fill 103 293 498 103 294 498 minecraft:deepslate_bricks
fill 103 293 500 103 294 500 minecraft:deepslate_bricks
fill 103 293 502 103 294 502 minecraft:deepslate_bricks
fill 103 293 504 103 294 504 minecraft:deepslate_bricks
fill 104 293 495 104 294 495 minecraft:deepslate_bricks
fill 104 293 497 104 294 497 minecraft:deepslate_bricks
fill 104 293 499 104 294 499 minecraft:deepslate_bricks
fill 104 293 501 104 294 501 minecraft:deepslate_bricks
fill 104 293 503 104 294 503 minecraft:deepslate_bricks
setblock 105 293 466 minecraft:light[level=11]
setblock 105 293 474 minecraft:light[level=11]
setblock 105 293 482 minecraft:light[level=11]
setblock 105 293 490 minecraft:light[level=11]
fill 105 293 494 105 294 494 minecraft:deepslate_bricks
fill 105 293 496 105 294 496 minecraft:deepslate_bricks
fill 105 293 498 105 294 498 minecraft:deepslate_bricks
fill 105 293 500 105 294 500 minecraft:deepslate_bricks
fill 105 293 502 105 294 502 minecraft:deepslate_bricks
fill 105 293 504 105 294 504 minecraft:deepslate_bricks
fill 106 293 495 106 294 495 minecraft:deepslate_bricks
fill 106 293 497 106 294 497 minecraft:deepslate_bricks
fill 106 293 499 106 294 499 minecraft:deepslate_bricks
fill 106 293 501 106 294 501 minecraft:deepslate_bricks
fill 106 293 503 106 294 503 minecraft:deepslate_bricks
fill 107 293 494 107 294 494 minecraft:deepslate_bricks
fill 107 293 496 107 294 496 minecraft:deepslate_bricks
fill 107 293 498 107 294 498 minecraft:deepslate_bricks
fill 107 293 500 107 294 500 minecraft:deepslate_bricks
fill 107 293 502 107 294 502 minecraft:deepslate_bricks
fill 107 293 504 107 294 504 minecraft:deepslate_bricks
fill 107 293 505 108 307 505 minecraft:deepslate_tiles
fill 108 293 495 108 294 495 minecraft:deepslate_bricks
fill 108 293 497 108 294 497 minecraft:deepslate_bricks
fill 108 293 499 108 294 499 minecraft:deepslate_bricks
fill 108 293 501 108 294 501 minecraft:deepslate_bricks
fill 108 293 503 108 294 503 minecraft:deepslate_bricks
fill 109 293 494 109 294 494 minecraft:deepslate_bricks
fill 109 293 496 109 294 496 minecraft:deepslate_bricks
fill 109 293 498 109 294 498 minecraft:deepslate_bricks
fill 109 293 500 109 294 500 minecraft:deepslate_bricks
fill 109 293 502 109 294 502 minecraft:deepslate_bricks
fill 109 293 504 109 294 504 minecraft:deepslate_bricks
fill 110 293 495 110 294 495 minecraft:deepslate_bricks
fill 110 293 497 110 294 497 minecraft:deepslate_bricks
fill 110 293 499 110 294 499 minecraft:deepslate_bricks
fill 110 293 501 110 294 501 minecraft:deepslate_bricks
fill 110 293 503 110 294 503 minecraft:deepslate_bricks
fill 111 293 494 111 294 494 minecraft:deepslate_bricks
fill 111 293 496 111 294 496 minecraft:deepslate_bricks
fill 111 293 498 111 294 498 minecraft:deepslate_bricks
fill 111 293 500 111 294 500 minecraft:deepslate_bricks
fill 111 293 502 111 294 502 minecraft:deepslate_bricks
fill 111 293 504 111 294 504 minecraft:deepslate_bricks
setblock 113 293 466 minecraft:light[level=11]
setblock 113 293 474 minecraft:light[level=11]
setblock 113 293 482 minecraft:light[level=11]
setblock 113 293 490 minecraft:light[level=11]
setblock 113 293 498 minecraft:light[level=11]
fill 114 293 463 115 307 463 minecraft:deepslate_tiles
fill 115 293 498 115 294 498 minecraft:deepslate_bricks
fill 115 293 500 115 294 500 minecraft:deepslate_bricks
fill 115 293 502 115 294 502 minecraft:deepslate_bricks
fill 115 293 504 115 294 504 minecraft:deepslate_bricks
fill 116 293 499 116 294 499 minecraft:deepslate_bricks
fill 116 293 501 116 294 501 minecraft:deepslate_bricks
fill 116 293 503 116 294 503 minecraft:deepslate_bricks
fill 117 293 498 117 294 498 minecraft:deepslate_bricks
fill 117 293 500 117 294 500 minecraft:deepslate_bricks
fill 117 293 502 117 294 502 minecraft:deepslate_bricks
fill 117 293 504 117 294 504 minecraft:deepslate_bricks
fill 118 293 499 118 294 499 minecraft:deepslate_bricks
fill 118 293 501 118 294 501 minecraft:deepslate_bricks
fill 118 293 503 118 294 503 minecraft:deepslate_bricks
fill 119 293 498 119 294 498 minecraft:deepslate_bricks
fill 119 293 500 119 294 500 minecraft:deepslate_bricks
fill 119 293 502 119 294 502 minecraft:deepslate_bricks
fill 119 293 504 119 294 504 minecraft:deepslate_bricks
fill 119 293 505 120 307 505 minecraft:deepslate_tiles
fill 120 293 499 120 294 499 minecraft:deepslate_bricks
fill 120 293 501 120 294 501 minecraft:deepslate_bricks
fill 120 293 503 120 294 503 minecraft:deepslate_bricks
setblock 121 293 466 minecraft:light[level=11]
setblock 121 293 474 minecraft:light[level=11]
setblock 121 293 482 minecraft:light[level=11]
setblock 121 293 490 minecraft:light[level=11]
fill 121 293 498 121 294 498 minecraft:deepslate_bricks
fill 121 293 500 121 294 500 minecraft:deepslate_bricks
fill 121 293 502 121 294 502 minecraft:deepslate_bricks
fill 121 293 504 121 294 504 minecraft:deepslate_bricks
fill 122 293 499 122 294 499 minecraft:deepslate_bricks
fill 122 293 501 122 294 501 minecraft:deepslate_bricks
fill 122 293 503 122 294 503 minecraft:deepslate_bricks
fill 123 293 498 123 294 498 minecraft:deepslate_bricks
fill 123 293 500 123 294 500 minecraft:deepslate_bricks
fill 123 293 502 123 294 502 minecraft:deepslate_bricks
fill 123 293 504 123 294 504 minecraft:deepslate_bricks
fill 124 293 499 124 294 499 minecraft:deepslate_bricks
fill 124 293 501 124 294 501 minecraft:deepslate_bricks
fill 124 293 503 124 294 503 minecraft:deepslate_bricks
fill 125 293 498 125 294 498 minecraft:deepslate_bricks
fill 125 293 500 125 294 500 minecraft:deepslate_bricks
fill 125 293 502 125 294 502 minecraft:deepslate_bricks
fill 125 293 504 125 294 504 minecraft:deepslate_bricks
fill 126 293 463 127 307 463 minecraft:deepslate_tiles
setblock 129 293 466 minecraft:light[level=11]
setblock 129 293 474 minecraft:light[level=11]
setblock 129 293 482 minecraft:light[level=11]
setblock 129 293 498 minecraft:light[level=11]
fill 131 293 505 132 307 505 minecraft:deepslate_tiles
fill 136 293 465 136 307 466 minecraft:deepslate_tiles
fill 136 293 477 136 307 478 minecraft:deepslate_tiles
fill 136 293 489 136 307 490 minecraft:deepslate_tiles
fill 136 293 501 136 307 502 minecraft:deepslate_tiles
fill 95 294 485 96 294 485 minecraft:deepslate_bricks
setblock 95 295 482 minecraft:sea_lantern
setblock 95 295 484 minecraft:sea_lantern
fill 95 295 485 95 300 485 minecraft:deepslate_bricks
setblock 95 295 486 minecraft:sea_lantern
setblock 95 295 488 minecraft:sea_lantern
setblock 96 295 481 minecraft:sea_lantern
setblock 96 295 483 minecraft:sea_lantern
setblock 96 295 485 minecraft:sea_lantern
setblock 96 295 487 minecraft:sea_lantern
setblock 96 295 489 minecraft:sea_lantern
setblock 97 295 482 minecraft:sea_lantern
setblock 97 295 484 minecraft:sea_lantern
fill 97 295 485 97 300 485 minecraft:deepslate_bricks
setblock 97 295 486 minecraft:sea_lantern
setblock 97 295 488 minecraft:sea_lantern
setblock 98 295 481 minecraft:sea_lantern
setblock 98 295 483 minecraft:sea_lantern
setblock 98 295 485 minecraft:sea_lantern
setblock 98 295 487 minecraft:sea_lantern
setblock 98 295 489 minecraft:sea_lantern
setblock 99 295 482 minecraft:sea_lantern
setblock 99 295 484 minecraft:sea_lantern
fill 99 295 485 99 300 485 minecraft:deepslate_bricks
setblock 99 295 486 minecraft:sea_lantern
setblock 99 295 488 minecraft:sea_lantern
setblock 100 295 481 minecraft:sea_lantern
setblock 100 295 483 minecraft:sea_lantern
setblock 100 295 485 minecraft:sea_lantern
setblock 100 295 487 minecraft:sea_lantern
setblock 100 295 489 minecraft:sea_lantern
setblock 101 295 482 minecraft:sea_lantern
setblock 101 295 484 minecraft:sea_lantern
setblock 101 295 486 minecraft:sea_lantern
setblock 101 295 488 minecraft:sea_lantern
setblock 101 295 494 minecraft:sea_lantern
setblock 101 295 496 minecraft:sea_lantern
setblock 101 295 498 minecraft:sea_lantern
setblock 101 295 500 minecraft:sea_lantern
setblock 101 295 502 minecraft:sea_lantern
setblock 101 295 504 minecraft:sea_lantern
setblock 102 295 481 minecraft:sea_lantern
setblock 102 295 483 minecraft:sea_lantern
setblock 102 295 485 minecraft:sea_lantern
setblock 102 295 487 minecraft:sea_lantern
setblock 102 295 489 minecraft:sea_lantern
setblock 102 295 495 minecraft:sea_lantern
setblock 102 295 497 minecraft:sea_lantern
setblock 102 295 499 minecraft:sea_lantern
setblock 102 295 501 minecraft:sea_lantern
setblock 102 295 503 minecraft:sea_lantern
setblock 103 295 494 minecraft:sea_lantern
setblock 103 295 496 minecraft:sea_lantern
setblock 103 295 498 minecraft:sea_lantern
setblock 103 295 500 minecraft:sea_lantern
setblock 103 295 502 minecraft:sea_lantern
setblock 103 295 504 minecraft:sea_lantern
setblock 104 295 495 minecraft:sea_lantern
setblock 104 295 497 minecraft:sea_lantern
setblock 104 295 499 minecraft:sea_lantern
setblock 104 295 501 minecraft:sea_lantern
setblock 104 295 503 minecraft:sea_lantern
setblock 105 295 494 minecraft:sea_lantern
setblock 105 295 496 minecraft:sea_lantern
setblock 105 295 498 minecraft:sea_lantern
setblock 105 295 500 minecraft:sea_lantern
setblock 105 295 502 minecraft:sea_lantern
setblock 105 295 504 minecraft:sea_lantern
setblock 106 295 495 minecraft:sea_lantern
setblock 106 295 497 minecraft:sea_lantern
setblock 106 295 499 minecraft:sea_lantern
setblock 106 295 501 minecraft:sea_lantern
setblock 106 295 503 minecraft:sea_lantern
setblock 107 295 494 minecraft:sea_lantern
setblock 107 295 496 minecraft:sea_lantern
setblock 107 295 498 minecraft:sea_lantern
setblock 107 295 500 minecraft:sea_lantern
setblock 107 295 502 minecraft:sea_lantern
setblock 107 295 504 minecraft:sea_lantern
setblock 108 295 495 minecraft:sea_lantern
setblock 108 295 497 minecraft:sea_lantern
setblock 108 295 499 minecraft:sea_lantern
setblock 108 295 501 minecraft:sea_lantern
setblock 108 295 503 minecraft:sea_lantern
setblock 109 295 494 minecraft:sea_lantern
setblock 109 295 496 minecraft:sea_lantern
setblock 109 295 498 minecraft:sea_lantern
setblock 109 295 500 minecraft:sea_lantern
setblock 109 295 502 minecraft:sea_lantern
setblock 109 295 504 minecraft:sea_lantern
setblock 110 295 495 minecraft:sea_lantern
setblock 110 295 497 minecraft:sea_lantern
setblock 110 295 499 minecraft:sea_lantern
setblock 110 295 501 minecraft:sea_lantern
setblock 110 295 503 minecraft:sea_lantern
setblock 111 295 494 minecraft:sea_lantern
setblock 111 295 496 minecraft:sea_lantern
setblock 111 295 498 minecraft:sea_lantern
setblock 111 295 500 minecraft:sea_lantern
setblock 111 295 502 minecraft:sea_lantern
setblock 111 295 504 minecraft:sea_lantern
setblock 115 295 498 minecraft:sea_lantern
setblock 115 295 500 minecraft:sea_lantern
setblock 115 295 502 minecraft:sea_lantern
setblock 115 295 504 minecraft:sea_lantern
setblock 116 295 499 minecraft:sea_lantern
setblock 116 295 501 minecraft:sea_lantern
setblock 116 295 503 minecraft:sea_lantern
setblock 117 295 498 minecraft:sea_lantern
setblock 117 295 500 minecraft:sea_lantern
setblock 117 295 502 minecraft:sea_lantern
setblock 117 295 504 minecraft:sea_lantern
setblock 118 295 499 minecraft:sea_lantern
setblock 118 295 501 minecraft:sea_lantern
setblock 118 295 503 minecraft:sea_lantern
setblock 119 295 498 minecraft:sea_lantern
setblock 119 295 500 minecraft:sea_lantern
setblock 119 295 502 minecraft:sea_lantern
setblock 119 295 504 minecraft:sea_lantern
setblock 120 295 499 minecraft:sea_lantern
setblock 120 295 501 minecraft:sea_lantern
setblock 120 295 503 minecraft:sea_lantern
setblock 121 295 498 minecraft:sea_lantern
setblock 121 295 500 minecraft:sea_lantern
setblock 121 295 502 minecraft:sea_lantern
setblock 121 295 504 minecraft:sea_lantern
setblock 122 295 499 minecraft:sea_lantern
setblock 122 295 501 minecraft:sea_lantern
setblock 122 295 503 minecraft:sea_lantern
setblock 123 295 498 minecraft:sea_lantern
setblock 123 295 500 minecraft:sea_lantern
setblock 123 295 502 minecraft:sea_lantern
setblock 123 295 504 minecraft:sea_lantern
setblock 124 295 499 minecraft:sea_lantern
setblock 124 295 501 minecraft:sea_lantern
setblock 124 295 503 minecraft:sea_lantern
setblock 125 295 498 minecraft:sea_lantern
setblock 125 295 500 minecraft:sea_lantern
setblock 125 295 502 minecraft:sea_lantern
setblock 125 295 504 minecraft:sea_lantern
fill 129 295 470 131 296 470 minecraft:cyan_concrete
fill 95 296 482 95 297 482 minecraft:deepslate_bricks
fill 95 296 484 95 297 484 minecraft:deepslate_bricks
fill 95 296 486 95 297 486 minecraft:deepslate_bricks
fill 95 296 488 95 297 488 minecraft:deepslate_bricks
fill 96 296 481 96 297 481 minecraft:deepslate_bricks
fill 96 296 483 96 297 483 minecraft:deepslate_bricks
fill 96 296 485 96 297 485 minecraft:deepslate_bricks
fill 96 296 487 96 297 487 minecraft:deepslate_bricks
fill 96 296 489 96 297 489 minecraft:deepslate_bricks
fill 96 296 499 97 296 499 minecraft:cyan_concrete
fill 97 296 482 97 297 482 minecraft:deepslate_bricks
fill 97 296 484 97 297 484 minecraft:deepslate_bricks
fill 97 296 486 97 297 486 minecraft:deepslate_bricks
fill 97 296 488 97 297 488 minecraft:deepslate_bricks
fill 98 296 481 98 297 481 minecraft:deepslate_bricks
fill 98 296 483 98 297 483 minecraft:deepslate_bricks
fill 98 296 485 98 297 485 minecraft:deepslate_bricks
fill 98 296 487 98 297 487 minecraft:deepslate_bricks
fill 98 296 489 98 297 489 minecraft:deepslate_bricks
fill 99 296 482 99 297 482 minecraft:deepslate_bricks
fill 99 296 484 99 297 484 minecraft:deepslate_bricks
fill 99 296 486 99 297 486 minecraft:deepslate_bricks
fill 99 296 488 99 297 488 minecraft:deepslate_bricks
fill 100 296 481 100 297 481 minecraft:deepslate_bricks
fill 100 296 483 100 297 483 minecraft:deepslate_bricks
fill 100 296 485 100 297 485 minecraft:deepslate_bricks
fill 100 296 487 100 297 487 minecraft:deepslate_bricks
fill 100 296 489 100 297 489 minecraft:deepslate_bricks
fill 101 296 482 101 297 482 minecraft:deepslate_bricks
fill 101 296 484 101 297 484 minecraft:deepslate_bricks
fill 101 296 486 101 297 486 minecraft:deepslate_bricks
fill 101 296 488 101 297 488 minecraft:deepslate_bricks
fill 101 296 494 101 298 494 minecraft:deepslate_bricks
fill 101 296 496 101 298 496 minecraft:deepslate_bricks
fill 101 296 498 101 298 498 minecraft:deepslate_bricks
fill 101 296 500 101 298 500 minecraft:deepslate_bricks
fill 101 296 502 101 298 502 minecraft:deepslate_bricks
fill 101 296 504 101 300 504 minecraft:deepslate_bricks
fill 102 296 481 102 297 481 minecraft:deepslate_bricks
fill 102 296 483 102 297 483 minecraft:deepslate_bricks
fill 102 296 485 102 297 485 minecraft:deepslate_bricks
fill 102 296 487 102 297 487 minecraft:deepslate_bricks
fill 102 296 489 102 297 489 minecraft:deepslate_bricks
fill 102 296 495 102 298 495 minecraft:deepslate_bricks
fill 102 296 497 102 298 497 minecraft:deepslate_bricks
fill 102 296 499 102 298 499 minecraft:deepslate_bricks
fill 102 296 501 102 298 501 minecraft:deepslate_bricks
fill 102 296 503 102 298 503 minecraft:deepslate_bricks
fill 103 296 494 103 298 494 minecraft:deepslate_bricks
fill 103 296 496 103 298 496 minecraft:deepslate_bricks
fill 103 296 498 103 298 498 minecraft:deepslate_bricks
fill 103 296 500 103 298 500 minecraft:deepslate_bricks
fill 103 296 502 103 298 502 minecraft:deepslate_bricks
fill 103 296 504 103 300 504 minecraft:deepslate_bricks
fill 104 296 495 104 298 495 minecraft:deepslate_bricks
fill 104 296 497 104 298 497 minecraft:deepslate_bricks
fill 104 296 499 104 298 499 minecraft:deepslate_bricks
fill 104 296 501 104 298 501 minecraft:deepslate_bricks
fill 104 296 503 104 298 503 minecraft:deepslate_bricks
fill 105 296 494 105 298 494 minecraft:deepslate_bricks
fill 105 296 496 105 298 496 minecraft:deepslate_bricks
fill 105 296 498 105 298 498 minecraft:deepslate_bricks
fill 105 296 500 105 298 500 minecraft:deepslate_bricks
fill 105 296 502 105 298 502 minecraft:deepslate_bricks
fill 105 296 504 105 298 504 minecraft:deepslate_bricks
fill 106 296 495 106 298 495 minecraft:deepslate_bricks
fill 106 296 497 106 298 497 minecraft:deepslate_bricks
fill 106 296 499 106 298 499 minecraft:deepslate_bricks
fill 106 296 501 106 298 501 minecraft:deepslate_bricks
fill 106 296 503 106 298 503 minecraft:deepslate_bricks
fill 107 296 494 107 298 494 minecraft:deepslate_bricks
fill 107 296 496 107 298 496 minecraft:deepslate_bricks
fill 107 296 498 107 298 498 minecraft:deepslate_bricks
fill 107 296 500 107 298 500 minecraft:deepslate_bricks
fill 107 296 502 107 298 502 minecraft:deepslate_bricks
fill 107 296 504 107 298 504 minecraft:deepslate_bricks
fill 108 296 495 108 298 495 minecraft:deepslate_bricks
fill 108 296 497 108 298 497 minecraft:deepslate_bricks
fill 108 296 499 108 298 499 minecraft:deepslate_bricks
fill 108 296 501 108 298 501 minecraft:deepslate_bricks
fill 108 296 503 108 298 503 minecraft:deepslate_bricks
fill 109 296 494 109 298 494 minecraft:deepslate_bricks
fill 109 296 496 109 298 496 minecraft:deepslate_bricks
fill 109 296 498 109 298 498 minecraft:deepslate_bricks
fill 109 296 500 109 298 500 minecraft:deepslate_bricks
fill 109 296 502 109 298 502 minecraft:deepslate_bricks
fill 109 296 504 109 298 504 minecraft:deepslate_bricks
fill 110 296 495 110 298 495 minecraft:deepslate_bricks
fill 110 296 497 110 298 497 minecraft:deepslate_bricks
fill 110 296 499 110 298 499 minecraft:deepslate_bricks
fill 110 296 501 110 298 501 minecraft:deepslate_bricks
fill 110 296 503 110 298 503 minecraft:deepslate_bricks
fill 111 296 494 111 298 494 minecraft:deepslate_bricks
fill 111 296 496 111 298 496 minecraft:deepslate_bricks
fill 111 296 498 111 298 498 minecraft:deepslate_bricks
fill 111 296 500 111 298 500 minecraft:deepslate_bricks
fill 111 296 502 111 298 502 minecraft:deepslate_bricks
fill 111 296 504 111 298 504 minecraft:deepslate_bricks
fill 115 296 498 115 297 498 minecraft:deepslate_bricks
fill 115 296 500 115 297 500 minecraft:deepslate_bricks
fill 115 296 502 115 297 502 minecraft:deepslate_bricks
fill 115 296 504 115 297 504 minecraft:deepslate_bricks
fill 116 296 499 116 297 499 minecraft:deepslate_bricks
fill 116 296 501 116 297 501 minecraft:deepslate_bricks
fill 116 296 503 116 297 503 minecraft:deepslate_bricks
fill 117 296 498 117 297 498 minecraft:deepslate_bricks
fill 117 296 500 117 297 500 minecraft:deepslate_bricks
fill 117 296 502 117 297 502 minecraft:deepslate_bricks
fill 117 296 504 117 297 504 minecraft:deepslate_bricks
fill 118 296 499 118 297 499 minecraft:deepslate_bricks
fill 118 296 501 118 297 501 minecraft:deepslate_bricks
fill 118 296 503 118 297 503 minecraft:deepslate_bricks
fill 119 296 498 119 297 498 minecraft:deepslate_bricks
fill 119 296 500 119 297 500 minecraft:deepslate_bricks
fill 119 296 502 119 297 502 minecraft:deepslate_bricks
fill 119 296 504 119 297 504 minecraft:deepslate_bricks
fill 120 296 499 120 297 499 minecraft:deepslate_bricks
fill 120 296 501 120 297 501 minecraft:deepslate_bricks
fill 120 296 503 120 297 503 minecraft:deepslate_bricks
fill 121 296 498 121 297 498 minecraft:deepslate_bricks
fill 121 296 500 121 297 500 minecraft:deepslate_bricks
fill 121 296 502 121 297 502 minecraft:deepslate_bricks
fill 121 296 504 121 297 504 minecraft:deepslate_bricks
fill 122 296 499 122 297 499 minecraft:deepslate_bricks
fill 122 296 501 122 297 501 minecraft:deepslate_bricks
fill 122 296 503 122 297 503 minecraft:deepslate_bricks
fill 123 296 498 123 297 498 minecraft:deepslate_bricks
fill 123 296 500 123 297 500 minecraft:deepslate_bricks
fill 123 296 502 123 297 502 minecraft:deepslate_bricks
fill 123 296 504 123 297 504 minecraft:deepslate_bricks
fill 124 296 499 124 297 499 minecraft:deepslate_bricks
fill 124 296 501 124 297 501 minecraft:deepslate_bricks
fill 124 296 503 124 297 503 minecraft:deepslate_bricks
fill 125 296 498 125 297 498 minecraft:deepslate_bricks
fill 125 296 500 125 297 500 minecraft:deepslate_bricks
fill 125 296 502 125 297 502 minecraft:deepslate_bricks
fill 125 296 504 125 297 504 minecraft:deepslate_bricks
fill 132 296 470 134 296 470 minecraft:cyan_concrete
fill 95 297 467 95 300 467 minecraft:cyan_stained_glass
fill 97 297 499 99 297 499 minecraft:cyan_concrete
fill 123 297 486 124 297 488 minecraft:cyan_concrete
fill 124 297 484 128 297 485 minecraft:cyan_concrete
fill 124 297 489 125 297 490 minecraft:cyan_concrete
fill 125 297 491 127 297 491 minecraft:cyan_concrete
fill 126 297 490 129 297 490 minecraft:cyan_concrete
fill 126 297 492 128 297 492 minecraft:cyan_concrete
fill 127 297 493 132 297 493 minecraft:cyan_concrete
fill 128 297 489 129 298 489 minecraft:cyan_concrete
fill 128 297 494 131 297 494 minecraft:cyan_concrete
fill 129 297 485 130 297 488 minecraft:cyan_concrete
fill 130 297 490 131 300 490 minecraft:deepslate_bricks
fill 131 297 486 132 297 487 minecraft:cyan_concrete
fill 131 297 488 131 300 488 minecraft:deepslate_bricks
fill 131 297 492 133 297 492 minecraft:cyan_concrete
fill 132 297 488 133 298 491 minecraft:cyan_concrete
fill 133 297 470 134 297 470 minecraft:cyan_concrete
setblock 133 297 487 minecraft:cyan_concrete
fill 134 297 489 134 297 490 minecraft:cyan_concrete
fill 95 298 466 96 299 466 minecraft:cyan_stained_glass
fill 95 298 468 96 299 468 minecraft:cyan_stained_glass
setblock 95 298 482 minecraft:sea_lantern
setblock 95 298 484 minecraft:sea_lantern
setblock 95 298 486 minecraft:sea_lantern
setblock 95 298 488 minecraft:sea_lantern
fill 96 298 467 97 300 467 minecraft:cyan_stained_glass
setblock 96 298 481 minecraft:sea_lantern
setblock 96 298 483 minecraft:sea_lantern
setblock 96 298 485 minecraft:sea_lantern
setblock 96 298 487 minecraft:sea_lantern
setblock 96 298 489 minecraft:sea_lantern
setblock 97 298 482 minecraft:sea_lantern
setblock 97 298 484 minecraft:sea_lantern
setblock 97 298 486 minecraft:sea_lantern
setblock 97 298 488 minecraft:sea_lantern
setblock 98 298 481 minecraft:sea_lantern
setblock 98 298 483 minecraft:sea_lantern
setblock 98 298 485 minecraft:sea_lantern
setblock 98 298 487 minecraft:sea_lantern
setblock 98 298 489 minecraft:sea_lantern
setblock 99 298 482 minecraft:sea_lantern
setblock 99 298 484 minecraft:sea_lantern
setblock 99 298 486 minecraft:sea_lantern
setblock 99 298 488 minecraft:sea_lantern
fill 99 298 499 100 298 499 minecraft:cyan_concrete
setblock 100 298 481 minecraft:sea_lantern
setblock 100 298 483 minecraft:sea_lantern
setblock 100 298 485 minecraft:sea_lantern
setblock 100 298 487 minecraft:sea_lantern
setblock 100 298 489 minecraft:sea_lantern
setblock 101 298 482 minecraft:sea_lantern
setblock 101 298 484 minecraft:sea_lantern
setblock 101 298 486 minecraft:sea_lantern
setblock 101 298 488 minecraft:sea_lantern
setblock 102 298 481 minecraft:sea_lantern
setblock 102 298 483 minecraft:sea_lantern
setblock 102 298 485 minecraft:sea_lantern
setblock 102 298 487 minecraft:sea_lantern
setblock 102 298 489 minecraft:sea_lantern
setblock 115 298 498 minecraft:sea_lantern
setblock 115 298 500 minecraft:sea_lantern
setblock 115 298 502 minecraft:sea_lantern
setblock 115 298 504 minecraft:sea_lantern
setblock 116 298 499 minecraft:sea_lantern
setblock 116 298 501 minecraft:sea_lantern
setblock 116 298 503 minecraft:sea_lantern
setblock 117 298 498 minecraft:sea_lantern
setblock 117 298 500 minecraft:sea_lantern
setblock 117 298 502 minecraft:sea_lantern
setblock 117 298 504 minecraft:sea_lantern
setblock 118 298 499 minecraft:sea_lantern
setblock 118 298 501 minecraft:sea_lantern
setblock 118 298 503 minecraft:sea_lantern
setblock 119 298 498 minecraft:sea_lantern
setblock 119 298 500 minecraft:sea_lantern
setblock 119 298 502 minecraft:sea_lantern
setblock 119 298 504 minecraft:sea_lantern
setblock 120 298 499 minecraft:sea_lantern
setblock 120 298 501 minecraft:sea_lantern
setblock 120 298 503 minecraft:sea_lantern
setblock 121 298 498 minecraft:sea_lantern
setblock 121 298 500 minecraft:sea_lantern
setblock 121 298 502 minecraft:sea_lantern
setblock 121 298 504 minecraft:sea_lantern
setblock 122 298 499 minecraft:sea_lantern
setblock 122 298 501 minecraft:sea_lantern
setblock 122 298 503 minecraft:sea_lantern
setblock 123 298 498 minecraft:sea_lantern
setblock 123 298 500 minecraft:sea_lantern
setblock 123 298 502 minecraft:sea_lantern
setblock 123 298 504 minecraft:sea_lantern
fill 124 298 485 124 298 489 minecraft:cyan_concrete
setblock 124 298 499 minecraft:sea_lantern
setblock 124 298 501 minecraft:sea_lantern
setblock 124 298 503 minecraft:sea_lantern
fill 125 298 485 129 298 485 minecraft:cyan_concrete
fill 125 298 489 125 299 489 minecraft:cyan_concrete
setblock 125 298 498 minecraft:sea_lantern
setblock 125 298 500 minecraft:sea_lantern
setblock 125 298 502 minecraft:sea_lantern
setblock 125 298 504 minecraft:sea_lantern
fill 126 298 484 127 298 484 minecraft:cyan_concrete
fill 126 298 490 127 298 491 minecraft:cyan_concrete
fill 127 298 492 128 298 492 minecraft:cyan_concrete
fill 128 298 490 129 300 490 minecraft:deepslate_bricks
fill 128 298 493 131 298 493 minecraft:cyan_concrete
fill 129 298 486 129 298 488 minecraft:cyan_concrete
fill 130 298 486 131 298 487 minecraft:cyan_concrete
fill 130 298 488 130 300 488 minecraft:deepslate_bricks
fill 131 298 492 132 298 492 minecraft:cyan_concrete
setblock 132 298 487 minecraft:cyan_concrete
fill 95 299 482 95 300 482 minecraft:deepslate_bricks
fill 95 299 484 95 300 484 minecraft:deepslate_bricks
fill 95 299 486 95 300 486 minecraft:deepslate_bricks
fill 95 299 488 95 300 488 minecraft:deepslate_bricks
fill 96 299 481 96 300 481 minecraft:deepslate_bricks
fill 96 299 483 96 300 483 minecraft:deepslate_bricks
fill 96 299 485 96 300 485 minecraft:deepslate_bricks
fill 96 299 487 96 300 487 minecraft:deepslate_bricks
fill 96 299 489 96 300 489 minecraft:deepslate_bricks
fill 97 299 466 98 299 466 minecraft:cyan_stained_glass
fill 97 299 468 98 299 468 minecraft:cyan_stained_glass
fill 97 299 482 97 300 482 minecraft:deepslate_bricks
fill 97 299 484 97 300 484 minecraft:deepslate_bricks
fill 97 299 486 97 300 486 minecraft:deepslate_bricks
fill 97 299 488 97 300 488 minecraft:deepslate_bricks
fill 98 299 467 99 300 467 minecraft:cyan_stained_glass
fill 98 299 481 98 300 481 minecraft:deepslate_bricks
fill 98 299 483 98 300 483 minecraft:deepslate_bricks
fill 98 299 485 98 300 485 minecraft:deepslate_bricks
fill 98 299 487 98 300 487 minecraft:deepslate_bricks
fill 98 299 489 98 300 489 minecraft:deepslate_bricks
fill 99 299 482 99 300 482 minecraft:deepslate_bricks
fill 99 299 484 99 300 484 minecraft:deepslate_bricks
fill 99 299 486 99 300 486 minecraft:deepslate_bricks
fill 99 299 488 99 300 488 minecraft:deepslate_bricks
fill 100 299 481 100 300 481 minecraft:deepslate_bricks
fill 100 299 483 100 300 483 minecraft:deepslate_bricks
fill 100 299 485 100 300 485 minecraft:deepslate_bricks
fill 100 299 487 100 300 487 minecraft:deepslate_bricks
fill 100 299 489 100 300 489 minecraft:deepslate_bricks
fill 101 299 482 101 300 482 minecraft:deepslate_bricks
fill 101 299 484 101 300 484 minecraft:deepslate_bricks
fill 101 299 486 101 300 486 minecraft:deepslate_bricks
fill 101 299 488 101 300 488 minecraft:deepslate_bricks
fill 102 299 481 102 300 481 minecraft:deepslate_bricks
fill 102 299 483 102 300 483 minecraft:deepslate_bricks
fill 102 299 485 102 300 485 minecraft:deepslate_bricks
fill 102 299 487 102 300 487 minecraft:deepslate_bricks
fill 102 299 489 102 300 489 minecraft:deepslate_bricks
fill 102 299 495 110 299 503 minecraft:cyan_concrete
fill 115 299 498 115 300 498 minecraft:deepslate_bricks
fill 115 299 500 115 300 500 minecraft:deepslate_bricks
fill 115 299 502 115 300 502 minecraft:deepslate_bricks
fill 115 299 504 115 300 504 minecraft:deepslate_bricks
fill 116 299 499 116 300 499 minecraft:deepslate_bricks
fill 116 299 501 116 300 501 minecraft:deepslate_bricks
fill 116 299 503 116 300 503 minecraft:deepslate_bricks
fill 117 299 498 117 300 498 minecraft:deepslate_bricks
fill 117 299 500 117 300 500 minecraft:deepslate_bricks
fill 117 299 502 117 300 502 minecraft:deepslate_bricks
fill 117 299 504 117 300 504 minecraft:deepslate_bricks
fill 118 299 499 118 300 499 minecraft:deepslate_bricks
fill 118 299 501 118 300 501 minecraft:deepslate_bricks
fill 118 299 503 118 300 503 minecraft:deepslate_bricks
fill 119 299 498 119 300 498 minecraft:deepslate_bricks
fill 119 299 500 119 300 500 minecraft:deepslate_bricks
fill 119 299 502 119 300 502 minecraft:deepslate_bricks
fill 119 299 504 119 300 504 minecraft:deepslate_bricks
fill 120 299 499 120 300 499 minecraft:deepslate_bricks
fill 120 299 501 120 300 501 minecraft:deepslate_bricks
fill 120 299 503 120 300 503 minecraft:deepslate_bricks
fill 121 299 498 121 300 498 minecraft:deepslate_bricks
fill 121 299 500 121 300 500 minecraft:deepslate_bricks
fill 121 299 502 121 300 502 minecraft:deepslate_bricks
fill 121 299 504 121 300 504 minecraft:deepslate_bricks
fill 122 299 499 122 300 499 minecraft:deepslate_bricks
fill 122 299 501 122 300 501 minecraft:deepslate_bricks
fill 122 299 503 122 300 503 minecraft:deepslate_bricks
fill 123 299 498 123 300 498 minecraft:deepslate_bricks
fill 123 299 500 123 300 500 minecraft:deepslate_bricks
fill 123 299 502 123 300 502 minecraft:deepslate_bricks
fill 123 299 504 123 300 504 minecraft:deepslate_bricks
fill 124 299 486 124 299 488 minecraft:cyan_concrete
fill 124 299 499 124 300 499 minecraft:deepslate_bricks
fill 124 299 501 124 300 501 minecraft:deepslate_bricks
fill 124 299 503 124 300 503 minecraft:deepslate_bricks
fill 125 299 485 128 299 485 minecraft:cyan_concrete
fill 125 299 498 125 300 498 minecraft:deepslate_bricks
fill 125 299 500 125 300 500 minecraft:deepslate_bricks
fill 125 299 502 125 300 502 minecraft:deepslate_bricks
fill 125 299 504 125 300 504 minecraft:deepslate_bricks
fill 127 299 490 127 300 490 minecraft:deepslate_bricks
setblock 127 299 491 minecraft:cyan_concrete
setblock 128 299 489 minecraft:cyan_concrete
setblock 128 299 492 minecraft:cyan_concrete
fill 129 299 486 130 299 487 minecraft:cyan_concrete
fill 129 299 488 129 300 489 minecraft:deepslate_bricks
setblock 131 299 487 minecraft:cyan_concrete
setblock 131 299 492 minecraft:cyan_concrete
fill 132 299 488 132 299 491 minecraft:cyan_concrete
fill 96 300 473 96 300 475 minecraft:deepslate_bricks
fill 96 300 497 96 300 499 minecraft:deepslate_bricks
fill 100 300 467 101 300 467 minecraft:cyan_stained_glass
fill 102 300 503 104 300 503 minecraft:deepslate_bricks
fill 103 300 496 109 300 502 minecraft:cyan_concrete
fill 106 300 465 108 300 465 minecraft:deepslate_bricks
setblock 114 300 503 minecraft:deepslate_bricks
fill 118 300 465 120 300 465 minecraft:deepslate_bricks
fill 126 300 503 128 300 503 minecraft:deepslate_bricks
setblock 128 300 489 minecraft:deepslate_bricks
fill 129 300 487 131 300 487 minecraft:deepslate_bricks
fill 130 300 465 132 300 465 minecraft:deepslate_bricks
fill 134 300 473 134 300 475 minecraft:deepslate_bricks
fill 134 300 485 134 300 487 minecraft:deepslate_bricks
fill 134 300 497 134 300 499 minecraft:deepslate_bricks
setblock 97 301 466 minecraft:light[level=11]
setblock 97 301 474 minecraft:light[level=11]
setblock 97 301 482 minecraft:light[level=11]
setblock 97 301 490 minecraft:light[level=11]
setblock 97 301 498 minecraft:light[level=11]
setblock 105 301 466 minecraft:light[level=11]
setblock 105 301 474 minecraft:light[level=11]
setblock 105 301 482 minecraft:light[level=11]
setblock 105 301 490 minecraft:light[level=11]
setblock 105 301 498 minecraft:light[level=11]
setblock 113 301 466 minecraft:light[level=11]
setblock 113 301 474 minecraft:light[level=11]
setblock 113 301 482 minecraft:light[level=11]
setblock 113 301 490 minecraft:light[level=11]
setblock 113 301 498 minecraft:light[level=11]
setblock 121 301 466 minecraft:light[level=11]
setblock 121 301 474 minecraft:light[level=11]
setblock 121 301 482 minecraft:light[level=11]
setblock 121 301 490 minecraft:light[level=11]
setblock 121 301 498 minecraft:light[level=11]
setblock 129 301 466 minecraft:light[level=11]
setblock 129 301 474 minecraft:light[level=11]
setblock 129 301 482 minecraft:light[level=11]
setblock 129 301 490 minecraft:light[level=11]
setblock 129 301 498 minecraft:light[level=11]
