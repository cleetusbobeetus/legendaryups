fill 370 167 559 370 170 559 minecraft:green_terracotta
setblock 370 167 562 minecraft:green_terracotta
setblock 370 167 563 minecraft:oak_log
fill 370 167 564 371 167 564 minecraft:green_terracotta
setblock 370 167 568 minecraft:oak_log
fill 370 167 569 370 170 569 minecraft:green_terracotta
setblock 370 167 573 minecraft:oak_log
fill 370 167 574 371 167 574 minecraft:green_terracotta
setblock 370 167 578 minecraft:oak_log
fill 370 167 579 370 170 579 minecraft:green_terracotta
setblock 370 167 583 minecraft:oak_log
fill 370 167 584 370 169 585 minecraft:green_terracotta
setblock 370 167 588 minecraft:oak_log
setblock 370 167 598 minecraft:oak_log
fill 371 167 558 371 169 558 minecraft:brown_terracotta
setblock 371 167 563 minecraft:green_terracotta
fill 371 167 565 371 167 566 minecraft:brown_terracotta
setblock 371 167 568 minecraft:brown_terracotta
fill 371 167 572 371 168 572 minecraft:green_terracotta
fill 371 167 573 371 169 573 minecraft:brown_terracotta
fill 371 167 575 371 169 576 minecraft:brown_terracotta
setblock 371 167 577 minecraft:green_terracotta
fill 371 167 578 371 169 578 minecraft:brown_terracotta
fill 371 167 585 371 169 585 minecraft:brown_terracotta
fill 371 167 587 371 167 588 minecraft:brown_terracotta
fill 329 168 574 329 169 574 minecraft:brown_terracotta
setblock 329 168 579 minecraft:green_terracotta
fill 329 168 580 329 169 580 minecraft:brown_terracotta
setblock 329 168 581 minecraft:green_terracotta
fill 329 168 582 329 169 583 minecraft:brown_terracotta
fill 330 168 558 330 171 558 minecraft:green_terracotta
setblock 330 168 562 minecraft:oak_log
fill 330 168 563 330 171 563 minecraft:green_terracotta
setblock 330 168 567 minecraft:oak_log
fill 330 168 568 330 171 568 minecraft:green_terracotta
setblock 330 168 572 minecraft:oak_log
fill 330 168 573 330 170 574 minecraft:green_terracotta
setblock 330 168 577 minecraft:oak_log
fill 330 168 578 330 171 578 minecraft:green_terracotta
setblock 330 168 582 minecraft:oak_log
fill 330 168 583 330 171 583 minecraft:green_terracotta
setblock 330 168 587 minecraft:oak_log
setblock 330 168 597 minecraft:oak_log
fill 330 168 598 330 171 598 minecraft:green_terracotta
setblock 331 168 561 minecraft:oak_log
fill 331 168 562 331 171 562 minecraft:green_terracotta
setblock 331 168 566 minecraft:oak_log
fill 331 168 567 331 171 567 minecraft:green_terracotta
setblock 331 168 571 minecraft:oak_log
fill 331 168 572 331 171 572 minecraft:green_terracotta
setblock 331 168 576 minecraft:oak_log
fill 331 168 577 331 171 577 minecraft:green_terracotta
setblock 331 168 581 minecraft:oak_log
fill 331 168 582 331 171 582 minecraft:green_terracotta
fill 331 168 584 331 169 584 minecraft:green_terracotta
setblock 332 168 560 minecraft:oak_log
fill 332 168 561 333 170 561 minecraft:green_terracotta
setblock 332 168 565 minecraft:oak_log
setblock 333 168 559 minecraft:oak_log
fill 333 168 560 333 171 560 minecraft:green_terracotta
fill 333 168 599 333 169 599 minecraft:brown_terracotta
setblock 334 168 558 minecraft:oak_log
fill 334 168 559 334 171 559 minecraft:green_terracotta
setblock 334 168 598 minecraft:oak_log
fill 335 168 558 338 168 558 minecraft:green_terracotta
fill 335 168 598 338 168 598 minecraft:green_terracotta
setblock 337 168 560 minecraft:oak_log
setblock 338 168 559 minecraft:oak_log
setblock 339 168 558 minecraft:oak_log
fill 339 168 559 339 171 559 minecraft:green_terracotta
setblock 339 168 598 minecraft:oak_log
fill 340 168 558 340 171 558 minecraft:green_terracotta
fill 340 168 598 340 171 598 minecraft:green_terracotta
fill 341 168 599 343 169 599 minecraft:brown_terracotta
fill 342 168 557 343 169 557 minecraft:brown_terracotta
setblock 342 168 559 minecraft:green_terracotta
setblock 343 168 559 minecraft:oak_log
setblock 344 168 557 minecraft:green_terracotta
setblock 344 168 558 minecraft:oak_log
fill 344 168 559 344 171 559 minecraft:green_terracotta
setblock 344 168 598 minecraft:oak_log
setblock 344 168 599 minecraft:green_terracotta
fill 345 168 557 347 169 557 minecraft:brown_terracotta
fill 345 168 558 345 171 558 minecraft:green_terracotta
setblock 345 168 597 minecraft:oak_log
fill 345 168 598 345 171 598 minecraft:green_terracotta
fill 345 168 599 348 169 599 minecraft:brown_terracotta
fill 346 168 597 346 171 597 minecraft:green_terracotta
setblock 347 168 560 minecraft:oak_log
setblock 348 168 559 minecraft:oak_log
fill 348 168 560 349 170 560 minecraft:green_terracotta
setblock 349 168 557 minecraft:green_terracotta
setblock 349 168 558 minecraft:oak_log
fill 349 168 559 349 171 559 minecraft:green_terracotta
fill 349 168 596 349 169 596 minecraft:green_terracotta
setblock 349 168 598 minecraft:oak_log
setblock 349 168 599 minecraft:green_terracotta
fill 350 168 558 350 171 558 minecraft:green_terracotta
setblock 350 168 597 minecraft:oak_log
fill 350 168 598 350 171 598 minecraft:green_terracotta
fill 350 168 599 350 169 599 minecraft:brown_terracotta
setblock 351 168 560 minecraft:green_terracotta
setblock 351 168 596 minecraft:oak_log
fill 351 168 597 351 171 597 minecraft:green_terracotta
setblock 352 168 599 minecraft:green_terracotta
setblock 353 168 559 minecraft:oak_log
setblock 354 168 558 minecraft:oak_log
fill 354 168 559 354 171 559 minecraft:green_terracotta
setblock 354 168 598 minecraft:oak_log
fill 355 168 558 355 171 558 minecraft:green_terracotta
setblock 355 168 597 minecraft:oak_log
fill 355 168 598 357 169 598 minecraft:green_terracotta
fill 355 168 599 355 169 599 minecraft:brown_terracotta
setblock 356 168 599 minecraft:green_terracotta
setblock 362 168 558 minecraft:oak_leaves[persistent=true]
setblock 363 168 598 minecraft:oak_leaves[persistent=true]
fill 364 168 557 364 169 557 minecraft:brown_terracotta
fill 365 168 558 365 171 558 minecraft:green_terracotta
setblock 367 168 559 minecraft:green_terracotta
fill 367 168 599 367 169 599 minecraft:brown_terracotta
setblock 368 168 559 minecraft:oak_log
setblock 368 168 579 minecraft:oak_log
fill 368 168 580 368 171 580 minecraft:green_terracotta
setblock 368 168 583 minecraft:green_terracotta
setblock 368 168 584 minecraft:oak_log
setblock 369 168 558 minecraft:oak_log
fill 369 168 559 369 168 562 minecraft:green_terracotta
setblock 369 168 563 minecraft:oak_log
fill 369 168 564 369 168 567 minecraft:green_terracotta
fill 369 168 570 369 169 571 minecraft:green_terracotta
setblock 369 168 573 minecraft:oak_log
fill 369 168 574 370 170 574 minecraft:green_terracotta
setblock 369 168 578 minecraft:oak_log
fill 369 168 579 369 171 579 minecraft:green_terracotta
setblock 369 168 583 minecraft:oak_log
fill 369 168 584 369 171 584 minecraft:green_terracotta
setblock 369 168 587 minecraft:green_terracotta
setblock 369 168 598 minecraft:oak_log
fill 370 168 558 370 171 558 minecraft:green_terracotta
setblock 370 168 562 minecraft:oak_log
fill 370 168 563 370 170 564 minecraft:green_terracotta
setblock 370 168 566 minecraft:green_terracotta
setblock 370 168 567 minecraft:oak_log
fill 370 168 568 371 168 568 minecraft:green_terracotta
setblock 370 168 572 minecraft:oak_log
fill 370 168 573 370 171 573 minecraft:green_terracotta
setblock 370 168 577 minecraft:oak_log
fill 370 168 578 370 171 578 minecraft:green_terracotta
setblock 370 168 582 minecraft:oak_log
fill 370 168 583 370 171 583 minecraft:green_terracotta
setblock 370 168 587 minecraft:oak_log
fill 370 168 588 370 170 589 minecraft:green_terracotta
setblock 370 168 594 minecraft:oak_leaves[persistent=true]
setblock 370 168 597 minecraft:oak_log
fill 370 168 598 370 171 598 minecraft:green_terracotta
fill 371 168 559 371 169 559 minecraft:brown_terracotta
fill 371 168 560 371 168 561 minecraft:green_terracotta
fill 371 168 562 371 169 564 minecraft:brown_terracotta
setblock 371 168 565 minecraft:green_terracotta
fill 371 168 566 371 169 566 minecraft:brown_terracotta
fill 371 168 574 371 169 574 minecraft:brown_terracotta
fill 371 168 577 371 169 577 minecraft:brown_terracotta
fill 371 168 579 371 169 580 minecraft:brown_terracotta
setblock 371 168 581 minecraft:green_terracotta
fill 371 168 582 371 169 584 minecraft:brown_terracotta
fill 371 168 587 371 169 587 minecraft:brown_terracotta
setblock 371 168 588 minecraft:green_terracotta
fill 371 168 589 371 169 591 minecraft:brown_terracotta
setblock 371 168 592 minecraft:green_terracotta
fill 371 168 593 371 169 597 minecraft:brown_terracotta
setblock 329 169 579 minecraft:brown_terracotta
setblock 329 169 581 minecraft:brown_terracotta
setblock 330 169 561 minecraft:oak_log
fill 330 169 562 330 172 562 minecraft:green_terracotta
setblock 330 169 566 minecraft:oak_log
fill 330 169 567 330 172 567 minecraft:green_terracotta
setblock 330 169 571 minecraft:oak_log
fill 330 169 572 330 172 572 minecraft:green_terracotta
setblock 330 169 576 minecraft:oak_log
fill 330 169 577 330 172 577 minecraft:green_terracotta
setblock 330 169 581 minecraft:oak_log
fill 330 169 582 330 172 582 minecraft:green_terracotta
setblock 330 169 586 minecraft:oak_log
fill 330 169 587 330 171 588 minecraft:green_terracotta
setblock 330 169 593 minecraft:oak_leaves[persistent=true]
setblock 330 169 595 minecraft:green_terracotta
setblock 330 169 596 minecraft:oak_log
fill 330 169 597 330 172 597 minecraft:green_terracotta
setblock 331 169 560 minecraft:oak_log
fill 331 169 561 331 172 561 minecraft:green_terracotta
setblock 331 169 565 minecraft:oak_log
fill 331 169 566 332 171 566 minecraft:green_terracotta
setblock 331 169 570 minecraft:oak_log
fill 331 169 571 331 172 571 minecraft:green_terracotta
setblock 331 169 575 minecraft:oak_log
fill 331 169 576 331 171 576 minecraft:green_terracotta
setblock 331 169 580 minecraft:oak_log
fill 331 169 581 331 172 581 minecraft:green_terracotta
setblock 331 169 585 minecraft:oak_log
setblock 332 169 559 minecraft:oak_log
fill 332 169 560 332 172 560 minecraft:green_terracotta
setblock 332 169 564 minecraft:oak_log
fill 332 169 565 332 172 565 minecraft:green_terracotta
setblock 332 169 568 minecraft:light[level=14]
setblock 332 169 576 minecraft:light[level=14]
setblock 332 169 584 minecraft:light[level=14]
setblock 332 169 592 minecraft:light[level=14]
setblock 333 169 558 minecraft:oak_log
fill 333 169 559 333 172 559 minecraft:green_terracotta
setblock 333 169 562 minecraft:green_terracotta
setblock 333 169 563 minecraft:oak_log
setblock 333 169 598 minecraft:oak_log
fill 334 169 558 337 169 558 minecraft:green_terracotta
setblock 334 169 561 minecraft:green_terracotta
fill 334 169 598 337 169 598 minecraft:green_terracotta
setblock 336 169 560 minecraft:oak_log
setblock 337 169 559 minecraft:oak_log
fill 337 169 560 337 171 560 minecraft:green_terracotta
setblock 338 169 558 minecraft:oak_log
fill 338 169 559 338 172 559 minecraft:green_terracotta
setblock 338 169 598 minecraft:oak_log
fill 339 169 558 339 172 558 minecraft:green_terracotta
fill 339 169 598 339 172 598 minecraft:green_terracotta
setblock 340 169 560 minecraft:light[level=14]
setblock 340 169 568 minecraft:light[level=14]
setblock 340 169 576 minecraft:light[level=14]
setblock 340 169 584 minecraft:light[level=14]
setblock 340 169 592 minecraft:light[level=14]
setblock 342 169 559 minecraft:oak_log
setblock 343 169 558 minecraft:oak_log
fill 343 169 559 343 172 559 minecraft:green_terracotta
setblock 343 169 598 minecraft:oak_log
setblock 344 169 557 minecraft:brown_terracotta
fill 344 169 558 344 172 558 minecraft:green_terracotta
fill 344 169 598 344 172 598 minecraft:green_terracotta
setblock 344 169 599 minecraft:brown_terracotta
fill 345 169 597 345 172 597 minecraft:green_terracotta
setblock 346 169 560 minecraft:oak_log
setblock 347 169 559 minecraft:oak_log
fill 347 169 560 347 172 560 minecraft:green_terracotta
setblock 348 169 558 minecraft:oak_log
fill 348 169 559 348 172 559 minecraft:green_terracotta
setblock 348 169 568 minecraft:light[level=14]
setblock 348 169 576 minecraft:light[level=14]
setblock 348 169 584 minecraft:light[level=14]
setblock 348 169 592 minecraft:light[level=14]
setblock 348 169 598 minecraft:oak_log
setblock 349 169 557 minecraft:brown_terracotta
fill 349 169 558 349 172 558 minecraft:green_terracotta
setblock 349 169 597 minecraft:oak_log
fill 349 169 598 349 172 598 minecraft:green_terracotta
setblock 349 169 599 minecraft:brown_terracotta
setblock 350 169 596 minecraft:oak_log
fill 350 169 597 350 172 597 minecraft:green_terracotta
setblock 351 169 560 minecraft:oak_log
fill 351 169 596 351 170 596 minecraft:green_terracotta
setblock 352 169 559 minecraft:oak_log
setblock 352 169 599 minecraft:brown_terracotta
setblock 353 169 558 minecraft:oak_log
fill 353 169 559 353 172 559 minecraft:green_terracotta
setblock 353 169 598 minecraft:oak_log
fill 354 169 558 354 172 558 minecraft:green_terracotta
setblock 354 169 597 minecraft:oak_log
fill 354 169 598 354 172 598 minecraft:green_terracotta
setblock 356 169 560 minecraft:light[level=14]
setblock 356 169 568 minecraft:light[level=14]
setblock 356 169 576 minecraft:light[level=14]
setblock 356 169 584 minecraft:light[level=14]
setblock 356 169 592 minecraft:light[level=14]
setblock 356 169 599 minecraft:brown_terracotta
fill 364 169 558 364 172 558 minecraft:green_terracotta
setblock 364 169 560 minecraft:light[level=14]
setblock 364 169 568 minecraft:light[level=14]
setblock 364 169 576 minecraft:light[level=14]
setblock 364 169 584 minecraft:light[level=14]
setblock 364 169 592 minecraft:light[level=14]
setblock 366 169 559 minecraft:green_terracotta
setblock 367 169 559 minecraft:oak_log
fill 367 169 580 367 170 582 minecraft:green_terracotta
setblock 367 169 598 minecraft:green_terracotta
setblock 368 169 558 minecraft:oak_log
fill 368 169 559 368 169 562 minecraft:green_terracotta
setblock 368 169 563 minecraft:oak_log
fill 368 169 575 368 171 575 minecraft:green_terracotta
setblock 368 169 578 minecraft:oak_log
fill 368 169 579 368 172 579 minecraft:green_terracotta
setblock 368 169 583 minecraft:oak_log
fill 368 169 584 368 171 585 minecraft:green_terracotta
setblock 368 169 598 minecraft:oak_log
fill 369 169 558 369 169 561 minecraft:green_terracotta
setblock 369 169 562 minecraft:oak_log
fill 369 169 563 369 169 566 minecraft:green_terracotta
setblock 369 169 567 minecraft:oak_log
fill 369 169 568 369 171 569 minecraft:green_terracotta
setblock 369 169 572 minecraft:oak_log
fill 369 169 573 369 172 573 minecraft:green_terracotta
setblock 369 169 577 minecraft:oak_log
fill 369 169 578 369 172 578 minecraft:green_terracotta
setblock 369 169 582 minecraft:oak_log
fill 369 169 583 369 172 583 minecraft:green_terracotta
setblock 369 169 587 minecraft:oak_log
fill 369 169 588 369 172 588 minecraft:green_terracotta
fill 369 169 598 369 172 598 minecraft:green_terracotta
setblock 370 169 561 minecraft:oak_log
fill 370 169 562 370 172 562 minecraft:green_terracotta
setblock 370 169 566 minecraft:oak_log
fill 370 169 567 370 171 568 minecraft:green_terracotta
setblock 370 169 571 minecraft:oak_log
fill 370 169 572 370 172 572 minecraft:green_terracotta
setblock 370 169 576 minecraft:oak_log
fill 370 169 577 370 172 577 minecraft:green_terracotta
setblock 370 169 581 minecraft:oak_log
fill 370 169 582 370 172 582 minecraft:green_terracotta
setblock 370 169 586 minecraft:oak_log
fill 370 169 587 370 172 587 minecraft:green_terracotta
setblock 370 169 590 minecraft:green_terracotta
setblock 370 169 596 minecraft:oak_log
fill 370 169 597 370 172 597 minecraft:green_terracotta
fill 371 169 560 371 169 561 minecraft:brown_terracotta
setblock 371 169 565 minecraft:brown_terracotta
setblock 371 169 568 minecraft:brown_terracotta
setblock 371 169 572 minecraft:brown_terracotta
setblock 371 169 581 minecraft:brown_terracotta
setblock 371 169 588 minecraft:brown_terracotta
setblock 371 169 592 minecraft:brown_terracotta
fill 329 170 557 329 170 563 minecraft:green_terracotta
fill 329 170 564 329 171 564 minecraft:brown_terracotta
fill 329 170 565 329 170 575 minecraft:green_terracotta
setblock 329 170 576 minecraft:brown_terracotta
fill 329 170 577 329 171 585 minecraft:green_terracotta
fill 329 170 588 329 234 588 minecraft:green_terracotta
fill 329 170 590 329 171 595 minecraft:green_terracotta
fill 329 170 597 329 170 599 minecraft:green_terracotta
fill 330 170 557 336 235 557 minecraft:green_terracotta
setblock 330 170 560 minecraft:oak_log
fill 330 170 561 330 173 561 minecraft:green_terracotta
setblock 330 170 565 minecraft:oak_log
fill 330 170 566 330 173 566 minecraft:green_terracotta
setblock 330 170 570 minecraft:oak_log
fill 330 170 571 330 173 571 minecraft:green_terracotta
setblock 330 170 575 minecraft:oak_log
fill 330 170 576 330 173 576 minecraft:green_terracotta
setblock 330 170 580 minecraft:oak_log
fill 330 170 581 330 173 581 minecraft:green_terracotta
setblock 330 170 585 minecraft:oak_log
fill 330 170 586 331 172 586 minecraft:green_terracotta
setblock 330 170 589 minecraft:green_terracotta
setblock 330 170 590 minecraft:oak_log
setblock 330 170 595 minecraft:oak_log
fill 330 170 596 330 173 596 minecraft:green_terracotta
fill 330 170 599 345 170 599 minecraft:green_terracotta
setblock 331 170 559 minecraft:oak_log
fill 331 170 560 331 173 560 minecraft:green_terracotta
setblock 331 170 564 minecraft:oak_log
fill 331 170 565 331 173 565 minecraft:green_terracotta
setblock 331 170 569 minecraft:oak_log
fill 331 170 570 331 173 570 minecraft:green_terracotta
setblock 331 170 574 minecraft:oak_log
fill 331 170 575 331 171 575 minecraft:green_terracotta
setblock 331 170 579 minecraft:oak_log
fill 331 170 580 331 173 580 minecraft:green_terracotta
setblock 331 170 584 minecraft:oak_log
fill 331 170 585 331 173 585 minecraft:green_terracotta
setblock 332 170 558 minecraft:oak_log
fill 332 170 559 332 173 559 minecraft:green_terracotta
setblock 332 170 563 minecraft:oak_log
fill 332 170 564 332 173 564 minecraft:green_terracotta
setblock 332 170 567 minecraft:green_terracotta
setblock 332 170 598 minecraft:oak_log
fill 333 170 558 336 170 558 minecraft:green_terracotta
setblock 333 170 562 minecraft:oak_log
fill 333 170 563 333 173 563 minecraft:green_terracotta
fill 333 170 598 336 170 598 minecraft:green_terracotta
setblock 334 170 561 minecraft:oak_log
setblock 335 170 560 minecraft:oak_log
setblock 336 170 559 minecraft:oak_log
fill 336 170 560 336 172 560 minecraft:green_terracotta
setblock 337 170 558 minecraft:oak_log
fill 337 170 559 337 173 559 minecraft:green_terracotta
setblock 337 170 598 minecraft:oak_log
fill 338 170 557 338 173 558 minecraft:green_terracotta
fill 338 170 598 338 173 598 minecraft:green_terracotta
fill 339 170 557 339 236 557 minecraft:green_terracotta
fill 340 170 557 340 171 557 minecraft:brown_terracotta
fill 341 170 557 360 170 557 minecraft:green_terracotta
setblock 341 170 559 minecraft:oak_log
setblock 342 170 558 minecraft:oak_log
fill 342 170 559 342 173 559 minecraft:green_terracotta
setblock 342 170 598 minecraft:oak_log
fill 343 170 558 343 173 558 minecraft:green_terracotta
fill 343 170 598 343 173 598 minecraft:green_terracotta
setblock 344 170 560 minecraft:green_terracotta
fill 344 170 597 344 173 597 minecraft:green_terracotta
setblock 345 170 560 minecraft:oak_log
setblock 346 170 559 minecraft:oak_log
fill 346 170 560 346 173 560 minecraft:green_terracotta
setblock 346 170 599 minecraft:brown_terracotta
setblock 347 170 558 minecraft:oak_log
fill 347 170 559 347 173 559 minecraft:green_terracotta
setblock 347 170 598 minecraft:oak_log
fill 347 170 599 371 170 599 minecraft:green_terracotta
fill 348 170 558 348 173 558 minecraft:green_terracotta
setblock 348 170 596 minecraft:green_terracotta
setblock 348 170 597 minecraft:oak_log
fill 348 170 598 348 173 598 minecraft:green_terracotta
setblock 349 170 596 minecraft:oak_log
fill 349 170 597 349 173 597 minecraft:green_terracotta
setblock 350 170 559 minecraft:green_terracotta
setblock 350 170 560 minecraft:oak_log
fill 350 170 596 350 172 596 minecraft:green_terracotta
setblock 351 170 559 minecraft:oak_log
fill 351 170 560 352 170 560 minecraft:green_terracotta
setblock 352 170 558 minecraft:oak_log
fill 352 170 559 352 173 559 minecraft:green_terracotta
setblock 352 170 598 minecraft:oak_log
fill 353 170 558 353 173 558 minecraft:green_terracotta
setblock 353 170 597 minecraft:oak_log
fill 353 170 598 353 173 598 minecraft:green_terracotta
setblock 354 170 597 minecraft:green_terracotta
fill 355 170 598 356 170 598 minecraft:green_terracotta
fill 362 170 557 371 170 557 minecraft:green_terracotta
setblock 366 170 559 minecraft:oak_log
setblock 367 170 558 minecraft:oak_log
fill 367 170 559 369 170 560 minecraft:green_terracotta
fill 367 170 579 367 172 579 minecraft:green_terracotta
setblock 367 170 583 minecraft:oak_log
fill 367 170 584 367 173 584 minecraft:green_terracotta
setblock 367 170 598 minecraft:oak_log
fill 368 170 558 369 172 558 minecraft:green_terracotta
setblock 368 170 561 minecraft:green_terracotta
setblock 368 170 562 minecraft:oak_log
fill 368 170 563 368 170 566 minecraft:green_terracotta
setblock 368 170 567 minecraft:oak_log
setblock 368 170 577 minecraft:oak_log
fill 368 170 578 368 173 578 minecraft:green_terracotta
setblock 368 170 582 minecraft:oak_log
fill 368 170 583 368 173 583 minecraft:green_terracotta
setblock 368 170 586 minecraft:green_terracotta
fill 368 170 598 368 173 598 minecraft:green_terracotta
setblock 369 170 561 minecraft:oak_log
fill 369 170 562 369 170 565 minecraft:green_terracotta
setblock 369 170 566 minecraft:oak_log
fill 369 170 567 369 173 567 minecraft:green_terracotta
setblock 369 170 570 minecraft:green_terracotta
setblock 369 170 571 minecraft:oak_log
fill 369 170 572 369 173 572 minecraft:green_terracotta
setblock 369 170 576 minecraft:oak_log
fill 369 170 577 369 173 577 minecraft:green_terracotta
setblock 369 170 581 minecraft:oak_log
fill 369 170 582 369 173 582 minecraft:green_terracotta
setblock 369 170 585 minecraft:green_terracotta
setblock 369 170 586 minecraft:oak_log
fill 369 170 587 369 173 587 minecraft:green_terracotta
fill 369 170 589 369 171 589 minecraft:green_terracotta
setblock 370 170 560 minecraft:oak_log
fill 370 170 561 371 173 561 minecraft:green_terracotta
setblock 370 170 565 minecraft:oak_log
fill 370 170 566 371 173 566 minecraft:green_terracotta
setblock 370 170 570 minecraft:oak_log
fill 370 170 571 371 170 571 minecraft:green_terracotta
setblock 370 170 575 minecraft:oak_log
fill 370 170 576 371 173 576 minecraft:green_terracotta
setblock 370 170 580 minecraft:oak_log
fill 370 170 581 371 173 581 minecraft:green_terracotta
fill 370 170 584 371 170 584 minecraft:green_terracotta
setblock 370 170 585 minecraft:oak_log
fill 370 170 586 371 173 586 minecraft:green_terracotta
setblock 370 170 590 minecraft:oak_log
fill 370 170 591 371 172 592 minecraft:green_terracotta
fill 370 170 596 371 172 596 minecraft:green_terracotta
fill 371 170 558 371 171 560 minecraft:green_terracotta
fill 371 170 562 371 235 565 minecraft:green_terracotta
fill 371 170 567 371 170 570 minecraft:green_terracotta
fill 371 170 572 371 171 575 minecraft:green_terracotta
fill 371 170 577 371 238 580 minecraft:green_terracotta
setblock 371 170 582 minecraft:brown_terracotta
fill 371 170 583 371 238 583 minecraft:green_terracotta
fill 371 170 585 371 238 585 minecraft:green_terracotta
fill 371 170 587 371 171 590 minecraft:green_terracotta
fill 371 170 593 371 170 595 minecraft:green_terracotta
fill 371 170 597 371 235 598 minecraft:green_terracotta
setblock 329 171 557 minecraft:green_terracotta
setblock 329 171 558 minecraft:brown_terracotta
fill 329 171 559 329 234 563 minecraft:green_terracotta
fill 329 171 565 329 171 572 minecraft:green_terracotta
setblock 329 171 573 minecraft:brown_terracotta
fill 329 171 574 329 236 576 minecraft:green_terracotta
fill 329 171 586 329 234 587 minecraft:green_terracotta
fill 329 171 589 329 238 589 minecraft:green_terracotta
fill 329 171 596 329 236 598 minecraft:green_terracotta
fill 329 171 599 329 172 599 minecraft:brown_terracotta
setblock 330 171 559 minecraft:oak_log
fill 330 171 560 330 174 560 minecraft:green_terracotta
setblock 330 171 564 minecraft:oak_log
fill 330 171 565 330 174 565 minecraft:green_terracotta
setblock 330 171 569 minecraft:oak_log
fill 330 171 570 330 174 570 minecraft:green_terracotta
setblock 330 171 573 minecraft:green_terracotta
setblock 330 171 574 minecraft:oak_log
fill 330 171 575 330 174 575 minecraft:green_terracotta
setblock 330 171 579 minecraft:oak_log
fill 330 171 580 330 174 580 minecraft:green_terracotta
setblock 330 171 584 minecraft:oak_log
fill 330 171 585 330 174 585 minecraft:green_terracotta
setblock 330 171 589 minecraft:oak_log
fill 330 171 590 330 171 593 minecraft:green_terracotta
setblock 330 171 594 minecraft:oak_log
fill 330 171 595 330 174 595 minecraft:green_terracotta
fill 330 171 599 332 238 599 minecraft:green_terracotta
setblock 331 171 558 minecraft:oak_log
fill 331 171 559 331 174 559 minecraft:green_terracotta
setblock 331 171 563 minecraft:oak_log
fill 331 171 564 331 174 564 minecraft:green_terracotta
setblock 331 171 568 minecraft:oak_log
fill 331 171 569 331 174 569 minecraft:green_terracotta
setblock 331 171 573 minecraft:oak_log
setblock 331 171 574 minecraft:green_terracotta
setblock 331 171 578 minecraft:oak_log
fill 331 171 579 331 172 579 minecraft:green_terracotta
setblock 331 171 583 minecraft:oak_log
fill 331 171 584 331 174 584 minecraft:green_terracotta
setblock 331 171 587 minecraft:green_terracotta
setblock 331 171 598 minecraft:oak_log
fill 332 171 558 335 171 558 minecraft:green_terracotta
setblock 332 171 561 minecraft:green_terracotta
setblock 332 171 562 minecraft:oak_log
fill 332 171 563 332 174 563 minecraft:green_terracotta
setblock 332 171 567 minecraft:oak_log
fill 332 171 568 332 173 568 minecraft:green_terracotta
fill 332 171 598 335 171 598 minecraft:green_terracotta
setblock 333 171 561 minecraft:oak_log
fill 333 171 562 333 173 562 minecraft:green_terracotta
fill 333 171 564 333 172 564 minecraft:green_terracotta
setblock 333 171 599 minecraft:brown_terracotta
setblock 334 171 560 minecraft:oak_log
fill 334 171 561 334 172 561 minecraft:green_terracotta
fill 334 171 599 342 171 599 minecraft:green_terracotta
setblock 335 171 559 minecraft:oak_log
fill 335 171 560 335 173 560 minecraft:green_terracotta
setblock 336 171 558 minecraft:oak_log
fill 336 171 559 336 174 559 minecraft:green_terracotta
setblock 336 171 598 minecraft:oak_log
fill 337 171 557 337 174 558 minecraft:green_terracotta
fill 337 171 598 337 173 598 minecraft:green_terracotta
setblock 340 171 559 minecraft:oak_log
fill 341 171 557 343 238 557 minecraft:green_terracotta
setblock 341 171 558 minecraft:oak_log
fill 341 171 559 341 174 559 minecraft:green_terracotta
setblock 341 171 598 minecraft:oak_log
fill 342 171 558 342 174 558 minecraft:green_terracotta
fill 342 171 598 342 174 598 minecraft:green_terracotta
setblock 343 171 560 minecraft:green_terracotta
fill 343 171 597 343 174 597 minecraft:green_terracotta
setblock 343 171 599 minecraft:brown_terracotta
setblock 344 171 557 minecraft:brown_terracotta
setblock 344 171 560 minecraft:oak_log
fill 344 171 599 355 171 599 minecraft:green_terracotta
fill 345 171 557 349 234 557 minecraft:green_terracotta
setblock 345 171 559 minecraft:oak_log
fill 345 171 560 345 174 560 minecraft:green_terracotta
setblock 346 171 558 minecraft:oak_log
fill 346 171 559 346 174 559 minecraft:green_terracotta
setblock 346 171 598 minecraft:oak_log
fill 347 171 558 347 174 558 minecraft:green_terracotta
setblock 347 171 596 minecraft:green_terracotta
setblock 347 171 597 minecraft:oak_log
fill 347 171 598 347 174 598 minecraft:green_terracotta
setblock 348 171 560 minecraft:green_terracotta
setblock 348 171 596 minecraft:oak_log
fill 348 171 597 348 174 597 minecraft:green_terracotta
setblock 349 171 560 minecraft:oak_log
fill 349 171 596 349 173 596 minecraft:green_terracotta
fill 350 171 557 351 171 557 minecraft:brown_terracotta
setblock 350 171 559 minecraft:oak_log
fill 350 171 560 351 172 560 minecraft:green_terracotta
setblock 351 171 558 minecraft:oak_log
fill 351 171 559 351 174 559 minecraft:green_terracotta
setblock 351 171 598 minecraft:oak_log
fill 352 171 557 352 174 558 minecraft:green_terracotta
setblock 352 171 597 minecraft:oak_log
fill 352 171 598 352 174 598 minecraft:green_terracotta
fill 353 171 557 366 171 557 minecraft:green_terracotta
setblock 353 171 597 minecraft:green_terracotta
setblock 355 171 598 minecraft:green_terracotta
setblock 356 171 558 minecraft:oak_log
setblock 356 171 598 minecraft:oak_log
setblock 356 171 599 minecraft:brown_terracotta
fill 357 171 599 362 171 599 minecraft:green_terracotta
fill 363 171 558 363 173 558 minecraft:green_terracotta
setblock 363 171 599 minecraft:brown_terracotta
fill 364 171 599 364 238 599 minecraft:green_terracotta
setblock 365 171 559 minecraft:oak_log
setblock 365 171 599 minecraft:brown_terracotta
setblock 366 171 558 minecraft:oak_log
fill 366 171 559 368 171 560 minecraft:green_terracotta
setblock 366 171 598 minecraft:oak_log
fill 366 171 599 366 238 599 minecraft:green_terracotta
setblock 367 171 557 minecraft:brown_terracotta
fill 367 171 558 367 174 558 minecraft:green_terracotta
fill 367 171 580 367 171 581 minecraft:green_terracotta
setblock 367 171 582 minecraft:oak_log
fill 367 171 583 367 174 583 minecraft:green_terracotta
fill 367 171 585 367 172 585 minecraft:green_terracotta
fill 367 171 598 367 174 598 minecraft:green_terracotta
setblock 367 171 599 minecraft:brown_terracotta
fill 368 171 557 368 238 557 minecraft:green_terracotta
setblock 368 171 561 minecraft:oak_log
fill 368 171 562 368 171 565 minecraft:green_terracotta
setblock 368 171 566 minecraft:oak_log
fill 368 171 567 368 171 570 minecraft:green_terracotta
fill 368 171 573 368 172 574 minecraft:green_terracotta
setblock 368 171 576 minecraft:oak_log
fill 368 171 577 368 174 577 minecraft:green_terracotta
setblock 368 171 581 minecraft:oak_log
fill 368 171 582 368 174 582 minecraft:green_terracotta
setblock 368 171 586 minecraft:oak_log
fill 368 171 587 368 174 587 minecraft:green_terracotta
fill 368 171 599 370 171 599 minecraft:green_terracotta
setblock 369 171 557 minecraft:brown_terracotta
setblock 369 171 559 minecraft:green_terracotta
setblock 369 171 560 minecraft:oak_log
fill 369 171 561 369 171 564 minecraft:green_terracotta
setblock 369 171 565 minecraft:oak_log
fill 369 171 566 369 174 566 minecraft:green_terracotta
setblock 369 171 570 minecraft:oak_log
fill 369 171 571 370 173 571 minecraft:green_terracotta
setblock 369 171 574 minecraft:green_terracotta
setblock 369 171 575 minecraft:oak_log
fill 369 171 576 369 174 576 minecraft:green_terracotta
setblock 369 171 580 minecraft:oak_log
fill 369 171 581 369 174 581 minecraft:green_terracotta
setblock 369 171 585 minecraft:oak_log
fill 369 171 586 369 174 586 minecraft:green_terracotta
setblock 369 171 590 minecraft:oak_log
fill 370 171 557 371 234 557 minecraft:green_terracotta
setblock 370 171 559 minecraft:oak_log
fill 370 171 560 370 174 560 minecraft:green_terracotta
setblock 370 171 563 minecraft:green_terracotta
setblock 370 171 564 minecraft:oak_log
fill 370 171 565 370 174 565 minecraft:green_terracotta
setblock 370 171 569 minecraft:oak_log
fill 370 171 570 371 171 570 minecraft:green_terracotta
setblock 370 171 574 minecraft:oak_log
fill 370 171 575 370 174 575 minecraft:green_terracotta
setblock 370 171 579 minecraft:oak_log
fill 370 171 580 370 174 580 minecraft:green_terracotta
setblock 370 171 584 minecraft:oak_log
fill 370 171 585 370 174 585 minecraft:green_terracotta
setblock 370 171 588 minecraft:green_terracotta
setblock 370 171 589 minecraft:oak_log
fill 370 171 590 370 174 590 minecraft:green_terracotta
setblock 370 171 593 minecraft:green_terracotta
setblock 370 171 595 minecraft:oak_leaves[persistent=true]
fill 371 171 567 371 171 568 minecraft:green_terracotta
fill 371 171 569 371 172 569 minecraft:brown_terracotta
fill 371 171 571 371 172 571 minecraft:brown_terracotta
fill 371 171 582 371 234 582 minecraft:green_terracotta
setblock 371 171 584 minecraft:brown_terracotta
fill 371 171 593 371 172 593 minecraft:brown_terracotta
fill 371 171 594 371 238 595 minecraft:green_terracotta
setblock 371 171 599 minecraft:brown_terracotta
setblock 329 172 557 minecraft:brown_terracotta
fill 329 172 558 329 235 558 minecraft:green_terracotta
fill 329 172 564 329 234 568 minecraft:green_terracotta
setblock 329 172 569 minecraft:brown_terracotta
fill 329 172 570 329 234 573 minecraft:green_terracotta
fill 329 172 577 329 236 577 minecraft:green_terracotta
setblock 329 172 578 minecraft:brown_terracotta
fill 329 172 579 329 235 585 minecraft:green_terracotta
fill 329 172 590 330 173 591 minecraft:green_terracotta
setblock 329 172 592 minecraft:brown_terracotta
fill 329 172 593 329 236 595 minecraft:green_terracotta
setblock 330 172 558 minecraft:oak_log
fill 330 172 559 330 175 559 minecraft:green_terracotta
setblock 330 172 563 minecraft:oak_log
fill 330 172 564 330 175 564 minecraft:green_terracotta
setblock 330 172 568 minecraft:oak_log
fill 330 172 569 330 175 569 minecraft:green_terracotta
setblock 330 172 573 minecraft:oak_log
fill 330 172 574 330 175 574 minecraft:green_terracotta
setblock 330 172 578 minecraft:oak_log
fill 330 172 579 330 175 579 minecraft:green_terracotta
setblock 330 172 583 minecraft:oak_log
fill 330 172 584 330 175 584 minecraft:green_terracotta
setblock 330 172 587 minecraft:green_terracotta
setblock 330 172 588 minecraft:oak_log
fill 330 172 589 330 175 589 minecraft:green_terracotta
setblock 330 172 592 minecraft:green_terracotta
setblock 330 172 593 minecraft:oak_log
fill 330 172 594 330 175 594 minecraft:green_terracotta
setblock 330 172 598 minecraft:oak_log
fill 331 172 558 334 172 558 minecraft:green_terracotta
setblock 331 172 562 minecraft:oak_log
fill 331 172 563 331 175 563 minecraft:green_terracotta
setblock 331 172 566 minecraft:green_terracotta
setblock 331 172 567 minecraft:oak_log
fill 331 172 568 331 175 568 minecraft:green_terracotta
setblock 331 172 572 minecraft:oak_log
setblock 331 172 577 minecraft:oak_log
setblock 331 172 578 minecraft:green_terracotta
setblock 331 172 582 minecraft:oak_log
fill 331 172 583 331 174 583 minecraft:green_terracotta
setblock 331 172 587 minecraft:oak_log
fill 331 172 588 331 175 588 minecraft:green_terracotta
fill 331 172 598 334 172 598 minecraft:green_terracotta
setblock 332 172 561 minecraft:oak_log
fill 332 172 562 332 175 562 minecraft:green_terracotta
setblock 332 172 566 minecraft:oak_log
fill 332 172 567 332 175 567 minecraft:green_terracotta
setblock 333 172 560 minecraft:oak_log
fill 333 172 561 333 173 561 minecraft:green_terracotta
fill 333 172 599 339 236 599 minecraft:green_terracotta
setblock 334 172 559 minecraft:oak_log
fill 334 172 560 334 174 560 minecraft:green_terracotta
setblock 335 172 558 minecraft:oak_log
fill 335 172 559 335 175 559 minecraft:green_terracotta
setblock 335 172 598 minecraft:oak_log
fill 336 172 558 336 175 558 minecraft:green_terracotta
fill 336 172 598 336 173 598 minecraft:green_terracotta
fill 337 172 560 337 173 560 minecraft:iron_block
setblock 339 172 559 minecraft:oak_log
fill 340 172 557 340 238 557 minecraft:green_terracotta
setblock 340 172 558 minecraft:oak_log
fill 340 172 559 340 174 559 minecraft:green_terracotta
setblock 340 172 598 minecraft:oak_log
setblock 340 172 599 minecraft:brown_terracotta
fill 341 172 558 341 175 558 minecraft:green_terracotta
fill 341 172 598 341 175 599 minecraft:green_terracotta
fill 342 172 599 348 235 599 minecraft:green_terracotta
setblock 343 172 560 minecraft:oak_log
fill 344 172 557 344 238 557 minecraft:green_terracotta
setblock 344 172 559 minecraft:oak_log
fill 344 172 560 344 174 560 minecraft:green_terracotta
setblock 345 172 558 minecraft:oak_log
fill 345 172 559 345 175 559 minecraft:green_terracotta
setblock 345 172 598 minecraft:oak_log
fill 346 172 558 346 175 558 minecraft:green_terracotta
setblock 346 172 597 minecraft:oak_log
fill 346 172 598 346 175 598 minecraft:green_terracotta
setblock 347 172 596 minecraft:oak_log
fill 347 172 597 347 175 597 minecraft:green_terracotta
setblock 348 172 560 minecraft:oak_log
fill 348 172 596 348 174 596 minecraft:green_terracotta
setblock 349 172 559 minecraft:oak_log
fill 349 172 560 349 173 560 minecraft:green_terracotta
setblock 349 172 599 minecraft:brown_terracotta
fill 350 172 557 351 235 557 minecraft:green_terracotta
setblock 350 172 558 minecraft:oak_log
fill 350 172 559 350 174 559 minecraft:green_terracotta
setblock 350 172 598 minecraft:oak_log
fill 350 172 599 359 235 599 minecraft:green_terracotta
fill 351 172 558 351 175 558 minecraft:green_terracotta
setblock 351 172 597 minecraft:oak_log
fill 351 172 598 351 175 598 minecraft:green_terracotta
fill 352 172 597 352 173 597 minecraft:green_terracotta
setblock 353 172 557 minecraft:brown_terracotta
fill 354 172 557 367 234 557 minecraft:green_terracotta
setblock 355 172 558 minecraft:oak_log
setblock 355 172 598 minecraft:oak_log
setblock 357 172 558 minecraft:oak_leaves[persistent=true]
setblock 360 172 599 minecraft:brown_terracotta
fill 361 172 599 363 234 599 minecraft:green_terracotta
setblock 362 172 598 minecraft:oak_leaves[persistent=true]
setblock 364 172 559 minecraft:oak_log
setblock 365 172 558 minecraft:oak_log
fill 365 172 559 368 172 559 minecraft:green_terracotta
fill 365 172 599 365 238 599 minecraft:green_terracotta
fill 366 172 558 366 175 558 minecraft:green_terracotta
fill 366 172 560 367 172 560 minecraft:green_terracotta
fill 366 172 598 366 173 598 minecraft:green_terracotta
fill 367 172 562 367 172 565 minecraft:green_terracotta
setblock 367 172 566 minecraft:oak_log
setblock 367 172 580 minecraft:green_terracotta
setblock 367 172 581 minecraft:oak_log
fill 367 172 582 367 174 582 minecraft:green_terracotta
setblock 367 172 586 minecraft:oak_log
fill 367 172 599 367 238 599 minecraft:green_terracotta
setblock 368 172 560 minecraft:oak_log
fill 368 172 561 368 172 564 minecraft:green_terracotta
setblock 368 172 565 minecraft:oak_log
fill 368 172 566 368 172 569 minecraft:green_terracotta
setblock 368 172 570 minecraft:oak_log
fill 368 172 571 368 174 572 minecraft:green_terracotta
setblock 368 172 575 minecraft:oak_log
fill 368 172 576 368 174 576 minecraft:green_terracotta
setblock 368 172 580 minecraft:oak_log
fill 368 172 581 368 175 581 minecraft:green_terracotta
setblock 368 172 584 minecraft:green_terracotta
setblock 368 172 585 minecraft:oak_log
fill 368 172 586 368 175 586 minecraft:green_terracotta
fill 368 172 588 368 173 588 minecraft:green_terracotta
fill 368 172 599 369 172 599 minecraft:brown_terracotta
fill 369 172 557 369 236 557 minecraft:green_terracotta
setblock 369 172 559 minecraft:oak_log
fill 369 172 560 369 172 563 minecraft:green_terracotta
setblock 369 172 564 minecraft:oak_log
fill 369 172 565 369 175 565 minecraft:green_terracotta
setblock 369 172 568 minecraft:green_terracotta
setblock 369 172 569 minecraft:oak_log
fill 369 172 570 370 174 570 minecraft:green_terracotta
setblock 369 172 574 minecraft:oak_log
fill 369 172 575 369 175 575 minecraft:green_terracotta
setblock 369 172 579 minecraft:oak_log
fill 369 172 580 369 175 580 minecraft:green_terracotta
setblock 369 172 584 minecraft:oak_log
fill 369 172 585 369 175 585 minecraft:green_terracotta
setblock 369 172 589 minecraft:oak_log
fill 369 172 590 369 175 590 minecraft:green_terracotta
setblock 370 172 558 minecraft:oak_log
fill 370 172 559 370 175 559 minecraft:green_terracotta
setblock 370 172 563 minecraft:oak_log
fill 370 172 564 370 175 564 minecraft:green_terracotta
setblock 370 172 567 minecraft:green_terracotta
setblock 370 172 568 minecraft:oak_log
fill 370 172 569 370 175 569 minecraft:green_terracotta
setblock 370 172 573 minecraft:oak_log
fill 370 172 574 371 175 574 minecraft:green_terracotta
setblock 370 172 578 minecraft:oak_log
fill 370 172 579 370 175 579 minecraft:green_terracotta
setblock 370 172 583 minecraft:oak_log
fill 370 172 584 371 175 584 minecraft:green_terracotta
setblock 370 172 588 minecraft:oak_log
fill 370 172 589 370 175 589 minecraft:green_terracotta
setblock 370 172 593 minecraft:oak_log
setblock 370 172 598 minecraft:oak_log
fill 370 172 599 371 238 599 minecraft:green_terracotta
fill 371 172 558 371 238 558 minecraft:green_terracotta
fill 371 172 559 371 172 560 minecraft:brown_terracotta
setblock 371 172 567 minecraft:brown_terracotta
fill 371 172 568 371 238 568 minecraft:green_terracotta
setblock 371 172 570 minecraft:brown_terracotta
fill 371 172 572 371 238 572 minecraft:green_terracotta
setblock 371 172 573 minecraft:brown_terracotta
setblock 371 172 575 minecraft:brown_terracotta
fill 371 172 587 371 238 588 minecraft:green_terracotta
setblock 371 172 589 minecraft:brown_terracotta
fill 371 172 590 371 238 590 minecraft:green_terracotta
fill 329 173 557 329 238 557 minecraft:green_terracotta
fill 329 173 569 329 236 569 minecraft:green_terracotta
fill 329 173 578 330 175 578 minecraft:green_terracotta
fill 329 173 592 329 236 592 minecraft:green_terracotta
fill 329 173 599 329 235 599 minecraft:green_terracotta
fill 330 173 558 333 173 558 minecraft:green_terracotta
setblock 330 173 562 minecraft:oak_log
fill 330 173 563 330 176 563 minecraft:green_terracotta
setblock 330 173 567 minecraft:oak_log
fill 330 173 568 330 176 568 minecraft:green_terracotta
setblock 330 173 572 minecraft:oak_log
fill 330 173 573 330 176 573 minecraft:green_terracotta
setblock 330 173 577 minecraft:oak_log
setblock 330 173 582 minecraft:oak_log
fill 330 173 583 330 176 583 minecraft:green_terracotta
setblock 330 173 586 minecraft:green_terracotta
setblock 330 173 587 minecraft:oak_log
fill 330 173 588 330 176 588 minecraft:green_terracotta
setblock 330 173 592 minecraft:oak_log
fill 330 173 593 330 176 593 minecraft:green_terracotta
setblock 330 173 597 minecraft:oak_log
fill 330 173 598 333 173 598 minecraft:green_terracotta
setblock 331 173 561 minecraft:oak_log
fill 331 173 562 331 176 562 minecraft:green_terracotta
setblock 331 173 566 minecraft:oak_log
fill 331 173 567 331 176 567 minecraft:green_terracotta
setblock 331 173 571 minecraft:oak_log
setblock 331 173 581 minecraft:oak_log
fill 331 173 582 331 174 582 minecraft:green_terracotta
setblock 331 173 586 minecraft:oak_log
fill 331 173 587 331 175 587 minecraft:green_terracotta
fill 331 173 589 331 174 589 minecraft:green_terracotta
setblock 332 173 560 minecraft:oak_log
fill 332 173 561 332 175 561 minecraft:green_terracotta
setblock 332 173 565 minecraft:oak_log
fill 332 173 566 332 176 566 minecraft:green_terracotta
setblock 333 173 559 minecraft:oak_log
fill 333 173 560 333 174 560 minecraft:green_terracotta
setblock 333 173 564 minecraft:oak_log
setblock 334 173 558 minecraft:oak_log
fill 334 173 559 334 175 559 minecraft:green_terracotta
setblock 334 173 598 minecraft:oak_log
fill 335 173 558 335 176 558 minecraft:green_terracotta
setblock 335 173 598 minecraft:green_terracotta
setblock 338 173 559 minecraft:oak_log
setblock 339 173 558 minecraft:oak_log
fill 339 173 559 339 174 559 minecraft:green_terracotta
setblock 339 173 598 minecraft:oak_log
fill 340 173 558 340 176 558 minecraft:green_terracotta
fill 340 173 598 340 176 599 minecraft:green_terracotta
setblock 343 173 559 minecraft:oak_log
setblock 343 173 560 minecraft:green_terracotta
setblock 344 173 558 minecraft:oak_log
fill 344 173 559 344 176 559 minecraft:green_terracotta
setblock 344 173 598 minecraft:oak_log
fill 345 173 558 345 176 558 minecraft:green_terracotta
setblock 345 173 597 minecraft:oak_log
fill 345 173 598 345 176 598 minecraft:green_terracotta
setblock 346 173 596 minecraft:oak_log
fill 346 173 597 346 176 597 minecraft:green_terracotta
setblock 347 173 560 minecraft:oak_log
fill 347 173 596 347 174 596 minecraft:green_terracotta
setblock 348 173 559 minecraft:oak_log
fill 348 173 560 348 174 560 minecraft:green_terracotta
setblock 349 173 558 minecraft:oak_log
fill 349 173 559 349 175 559 minecraft:green_terracotta
setblock 349 173 598 minecraft:oak_log
fill 349 173 599 349 238 599 minecraft:green_terracotta
fill 350 173 558 350 175 558 minecraft:green_terracotta
setblock 350 173 560 minecraft:green_terracotta
setblock 350 173 597 minecraft:oak_log
fill 350 173 598 350 176 598 minecraft:green_terracotta
fill 351 173 597 351 174 597 minecraft:green_terracotta
fill 353 173 557 353 238 557 minecraft:green_terracotta
setblock 354 173 558 minecraft:oak_log
setblock 354 173 598 minecraft:oak_log
fill 360 173 599 360 238 599 minecraft:green_terracotta
setblock 364 173 558 minecraft:oak_log
fill 364 173 559 367 173 559 minecraft:green_terracotta
fill 365 173 558 365 176 558 minecraft:green_terracotta
setblock 366 173 560 minecraft:green_terracotta
setblock 367 173 560 minecraft:oak_log
fill 367 173 561 367 173 564 minecraft:green_terracotta
setblock 367 173 565 minecraft:oak_log
fill 367 173 566 368 173 568 minecraft:green_terracotta
setblock 367 173 580 minecraft:oak_log
fill 367 173 581 367 174 581 minecraft:green_terracotta
setblock 367 173 585 minecraft:oak_log
fill 367 173 586 367 174 586 minecraft:green_terracotta
setblock 368 173 558 minecraft:green_terracotta
setblock 368 173 559 minecraft:oak_log
fill 368 173 560 368 173 563 minecraft:green_terracotta
setblock 368 173 564 minecraft:oak_log
fill 368 173 565 368 176 565 minecraft:green_terracotta
setblock 368 173 569 minecraft:oak_log
fill 368 173 570 368 176 570 minecraft:green_terracotta
setblock 368 173 573 minecraft:green_terracotta
setblock 368 173 574 minecraft:oak_log
fill 368 173 575 368 174 575 minecraft:green_terracotta
setblock 368 173 579 minecraft:oak_log
fill 368 173 580 368 175 580 minecraft:green_terracotta
setblock 368 173 584 minecraft:oak_log
fill 368 173 585 368 176 585 minecraft:green_terracotta
fill 368 173 599 369 238 599 minecraft:green_terracotta
setblock 369 173 558 minecraft:oak_log
fill 369 173 559 369 173 562 minecraft:green_terracotta
setblock 369 173 563 minecraft:oak_log
fill 369 173 564 369 176 564 minecraft:green_terracotta
setblock 369 173 568 minecraft:oak_log
fill 369 173 569 369 176 569 minecraft:green_terracotta
setblock 369 173 573 minecraft:oak_log
fill 369 173 574 369 176 574 minecraft:green_terracotta
setblock 369 173 578 minecraft:oak_log
fill 369 173 579 369 176 579 minecraft:green_terracotta
setblock 369 173 583 minecraft:oak_log
fill 369 173 584 369 176 584 minecraft:green_terracotta
setblock 369 173 588 minecraft:oak_log
fill 369 173 589 369 176 589 minecraft:green_terracotta
fill 369 173 591 371 173 591 minecraft:green_terracotta
setblock 369 173 598 minecraft:oak_log
fill 370 173 558 370 176 558 minecraft:green_terracotta
setblock 370 173 562 minecraft:oak_log
fill 370 173 563 370 176 563 minecraft:green_terracotta
setblock 370 173 567 minecraft:oak_log
fill 370 173 568 370 176 568 minecraft:green_terracotta
setblock 370 173 572 minecraft:oak_log
fill 370 173 573 371 176 573 minecraft:green_terracotta
setblock 370 173 577 minecraft:oak_log
fill 370 173 578 370 176 578 minecraft:green_terracotta
setblock 370 173 582 minecraft:oak_log
fill 370 173 583 370 176 583 minecraft:green_terracotta
setblock 370 173 587 minecraft:oak_log
fill 370 173 588 370 176 588 minecraft:green_terracotta
setblock 370 173 592 minecraft:oak_log
fill 370 173 593 371 175 593 minecraft:green_terracotta
setblock 370 173 597 minecraft:oak_log
setblock 370 173 598 minecraft:green_terracotta
fill 371 173 559 371 234 560 minecraft:green_terracotta
fill 371 173 567 371 238 567 minecraft:green_terracotta
fill 371 173 569 371 234 571 minecraft:green_terracotta
fill 371 173 575 371 236 575 minecraft:green_terracotta
fill 371 173 589 371 238 589 minecraft:green_terracotta
fill 371 173 592 371 238 592 minecraft:green_terracotta
fill 371 173 596 371 235 596 minecraft:green_terracotta
fill 329 174 590 329 238 591 minecraft:green_terracotta
fill 330 174 558 332 174 558 minecraft:green_terracotta
setblock 330 174 561 minecraft:oak_log
fill 330 174 562 330 177 562 minecraft:green_terracotta
setblock 330 174 566 minecraft:oak_log
fill 330 174 567 330 177 567 minecraft:green_terracotta
setblock 330 174 571 minecraft:oak_log
fill 330 174 572 330 177 572 minecraft:green_terracotta
setblock 330 174 576 minecraft:oak_log
setblock 330 174 577 minecraft:green_terracotta
setblock 330 174 581 minecraft:oak_log
fill 330 174 582 330 176 582 minecraft:green_terracotta
setblock 330 174 586 minecraft:oak_log
fill 330 174 587 330 177 587 minecraft:green_terracotta
setblock 330 174 590 minecraft:green_terracotta
setblock 330 174 591 minecraft:oak_log
fill 330 174 592 330 177 592 minecraft:green_terracotta
setblock 330 174 596 minecraft:oak_log
fill 330 174 597 330 176 598 minecraft:green_terracotta
setblock 331 174 560 minecraft:oak_log
fill 331 174 561 331 177 561 minecraft:green_terracotta
setblock 331 174 565 minecraft:oak_log
fill 331 174 566 331 177 566 minecraft:green_terracotta
setblock 331 174 570 minecraft:oak_log
setblock 331 174 571 minecraft:green_terracotta
setblock 331 174 585 minecraft:oak_log
fill 331 174 586 331 175 586 minecraft:green_terracotta
fill 331 174 598 332 174 598 minecraft:green_terracotta
setblock 332 174 559 minecraft:oak_log
fill 332 174 560 332 175 560 minecraft:green_terracotta
setblock 332 174 564 minecraft:oak_log
fill 332 174 565 332 176 565 minecraft:green_terracotta
setblock 333 174 558 minecraft:oak_log
fill 333 174 559 333 175 559 minecraft:green_terracotta
setblock 333 174 598 minecraft:oak_log
fill 334 174 558 334 176 558 minecraft:green_terracotta
setblock 334 174 598 minecraft:green_terracotta
setblock 337 174 559 minecraft:oak_log
fill 338 174 557 338 235 557 minecraft:green_terracotta
setblock 338 174 558 minecraft:oak_log
setblock 338 174 559 minecraft:green_terracotta
setblock 338 174 598 minecraft:oak_log
fill 339 174 558 339 176 558 minecraft:green_terracotta
fill 339 174 598 339 175 598 minecraft:green_terracotta
setblock 342 174 559 minecraft:oak_log
setblock 343 174 558 minecraft:oak_log
fill 343 174 559 343 176 559 minecraft:green_terracotta
setblock 343 174 598 minecraft:oak_log
fill 344 174 558 344 177 558 minecraft:green_terracotta
setblock 344 174 597 minecraft:oak_log
fill 344 174 598 344 177 598 minecraft:green_terracotta
fill 345 174 597 345 177 597 minecraft:green_terracotta
setblock 346 174 560 minecraft:oak_log
setblock 346 174 596 minecraft:green_terracotta
setblock 347 174 559 minecraft:oak_log
setblock 347 174 560 minecraft:green_terracotta
setblock 348 174 558 minecraft:oak_log
fill 348 174 559 348 175 559 minecraft:green_terracotta
setblock 348 174 598 minecraft:oak_log
fill 349 174 558 349 176 558 minecraft:green_terracotta
setblock 349 174 597 minecraft:oak_log
fill 349 174 598 349 177 598 minecraft:green_terracotta
fill 350 174 597 350 175 597 minecraft:green_terracotta
setblock 353 174 598 minecraft:oak_log
setblock 355 174 598 minecraft:oak_leaves[persistent=true]
setblock 363 174 558 minecraft:oak_log
fill 364 174 558 364 174 559 minecraft:green_terracotta
fill 365 174 559 366 174 559 minecraft:green_terracotta
setblock 366 174 560 minecraft:oak_log
setblock 367 174 559 minecraft:oak_log
fill 367 174 560 369 175 560 minecraft:green_terracotta
fill 367 174 562 367 174 563 minecraft:green_terracotta
setblock 367 174 564 minecraft:oak_log
fill 367 174 565 367 174 568 minecraft:green_terracotta
setblock 367 174 569 minecraft:oak_log
setblock 367 174 584 minecraft:oak_log
setblock 367 174 585 minecraft:green_terracotta
setblock 368 174 558 minecraft:oak_log
fill 368 174 559 369 176 559 minecraft:green_terracotta
fill 368 174 561 368 174 562 minecraft:green_terracotta
setblock 368 174 563 minecraft:oak_log
fill 368 174 564 368 177 564 minecraft:green_terracotta
fill 368 174 566 368 174 567 minecraft:green_terracotta
setblock 368 174 568 minecraft:oak_log
fill 368 174 569 368 177 569 minecraft:green_terracotta
setblock 368 174 573 minecraft:oak_log
setblock 368 174 574 minecraft:green_terracotta
setblock 368 174 578 minecraft:oak_log
fill 368 174 579 368 175 579 minecraft:green_terracotta
setblock 368 174 583 minecraft:oak_log
fill 368 174 584 368 176 584 minecraft:green_terracotta
setblock 368 174 588 minecraft:oak_log
setblock 368 174 589 minecraft:green_terracotta
setblock 368 174 598 minecraft:oak_log
fill 369 174 558 369 177 558 minecraft:green_terracotta
setblock 369 174 561 minecraft:green_terracotta
setblock 369 174 562 minecraft:oak_log
fill 369 174 563 369 177 563 minecraft:green_terracotta
setblock 369 174 567 minecraft:oak_log
fill 369 174 568 369 177 568 minecraft:green_terracotta
setblock 369 174 571 minecraft:green_terracotta
setblock 369 174 572 minecraft:oak_log
fill 369 174 573 369 177 573 minecraft:green_terracotta
setblock 369 174 577 minecraft:oak_log
fill 369 174 578 369 176 578 minecraft:green_terracotta
setblock 369 174 582 minecraft:oak_log
fill 369 174 583 369 177 583 minecraft:green_terracotta
setblock 369 174 587 minecraft:oak_log
fill 369 174 588 369 177 588 minecraft:green_terracotta
setblock 369 174 591 minecraft:green_terracotta
setblock 369 174 598 minecraft:green_terracotta
setblock 370 174 561 minecraft:oak_log
fill 370 174 562 370 177 562 minecraft:green_terracotta
setblock 370 174 566 minecraft:oak_log
fill 370 174 567 370 177 567 minecraft:green_terracotta
setblock 370 174 571 minecraft:oak_log
fill 370 174 572 370 177 572 minecraft:green_terracotta
setblock 370 174 576 minecraft:oak_log
fill 370 174 577 370 177 577 minecraft:green_terracotta
setblock 370 174 581 minecraft:oak_log
fill 370 174 582 370 177 582 minecraft:green_terracotta
setblock 370 174 586 minecraft:oak_log
fill 370 174 587 370 177 587 minecraft:green_terracotta
setblock 370 174 591 minecraft:oak_log
fill 370 174 592 370 176 592 minecraft:green_terracotta
fill 371 174 561 371 238 561 minecraft:green_terracotta
fill 371 174 566 371 239 566 minecraft:green_terracotta
fill 371 174 576 371 238 576 minecraft:green_terracotta
fill 371 174 581 371 238 581 minecraft:green_terracotta
fill 371 174 586 371 238 586 minecraft:green_terracotta
fill 371 174 591 371 236 591 minecraft:green_terracotta
fill 330 175 558 331 175 558 minecraft:green_terracotta
setblock 330 175 560 minecraft:oak_log
fill 330 175 561 330 178 561 minecraft:green_terracotta
setblock 330 175 565 minecraft:oak_log
fill 330 175 566 330 178 566 minecraft:green_terracotta
setblock 330 175 570 minecraft:oak_log
fill 330 175 571 330 178 571 minecraft:green_terracotta
setblock 330 175 575 minecraft:oak_log
setblock 330 175 580 minecraft:oak_log
setblock 330 175 581 minecraft:green_terracotta
setblock 330 175 585 minecraft:oak_log
fill 330 175 586 330 178 586 minecraft:green_terracotta
setblock 330 175 590 minecraft:oak_log
fill 330 175 591 330 178 591 minecraft:green_terracotta
setblock 330 175 595 minecraft:oak_log
setblock 330 175 596 minecraft:green_terracotta
setblock 331 175 559 minecraft:oak_log
fill 331 175 560 331 177 560 minecraft:green_terracotta
setblock 331 175 564 minecraft:oak_log
fill 331 175 565 331 178 565 minecraft:green_terracotta
setblock 331 175 569 minecraft:oak_log
fill 331 175 570 331 176 570 minecraft:green_terracotta
setblock 331 175 585 minecraft:green_terracotta
setblock 331 175 598 minecraft:green_terracotta
setblock 332 175 558 minecraft:oak_log
fill 332 175 559 332 176 559 minecraft:green_terracotta
setblock 332 175 563 minecraft:oak_log
fill 332 175 564 332 176 564 minecraft:green_terracotta
setblock 332 175 598 minecraft:oak_log
fill 333 175 558 333 177 558 minecraft:green_terracotta
setblock 336 175 598 minecraft:oak_leaves[persistent=true]
fill 337 175 557 337 238 557 minecraft:green_terracotta
setblock 337 175 558 minecraft:oak_log
fill 338 175 558 338 176 558 minecraft:green_terracotta
setblock 341 175 559 minecraft:oak_log
setblock 342 175 558 minecraft:oak_log
setblock 342 175 559 minecraft:green_terracotta
setblock 342 175 598 minecraft:oak_log
fill 343 175 558 343 178 558 minecraft:green_terracotta
setblock 343 175 597 minecraft:oak_log
fill 343 175 598 343 178 598 minecraft:green_terracotta
fill 344 175 597 344 178 597 minecraft:green_terracotta
setblock 346 175 559 minecraft:oak_log
setblock 347 175 558 minecraft:oak_log
fill 347 175 559 347 176 559 minecraft:green_terracotta
setblock 347 175 598 minecraft:oak_log
fill 348 175 558 348 177 558 minecraft:green_terracotta
setblock 348 175 597 minecraft:oak_log
fill 348 175 598 348 178 598 minecraft:green_terracotta
setblock 349 175 597 minecraft:green_terracotta
fill 352 175 557 352 238 557 minecraft:green_terracotta
setblock 352 175 598 minecraft:oak_log
setblock 358 175 558 minecraft:oak_leaves[persistent=true]
setblock 361 175 598 minecraft:oak_leaves[persistent=true]
fill 363 175 558 364 175 558 minecraft:green_terracotta
setblock 365 175 559 minecraft:green_terracotta
setblock 366 175 559 minecraft:oak_log
setblock 366 175 560 minecraft:green_terracotta
setblock 367 175 558 minecraft:oak_log
fill 367 175 559 367 177 559 minecraft:green_terracotta
setblock 367 175 562 minecraft:green_terracotta
setblock 367 175 563 minecraft:oak_log
fill 367 175 564 367 175 567 minecraft:green_terracotta
setblock 367 175 568 minecraft:oak_log
fill 367 175 569 367 178 569 minecraft:green_terracotta
fill 368 175 558 368 178 558 minecraft:green_terracotta
setblock 368 175 561 minecraft:green_terracotta
setblock 368 175 562 minecraft:oak_log
fill 368 175 563 368 178 563 minecraft:green_terracotta
setblock 368 175 566 minecraft:green_terracotta
setblock 368 175 567 minecraft:oak_log
fill 368 175 568 368 178 568 minecraft:green_terracotta
setblock 368 175 571 minecraft:green_terracotta
setblock 368 175 572 minecraft:oak_log
setblock 368 175 573 minecraft:green_terracotta
setblock 368 175 582 minecraft:oak_log
fill 368 175 583 368 176 583 minecraft:green_terracotta
setblock 368 175 587 minecraft:oak_log
fill 368 175 588 368 176 588 minecraft:green_terracotta
setblock 369 175 561 minecraft:oak_log
fill 369 175 562 369 178 562 minecraft:green_terracotta
setblock 369 175 566 minecraft:oak_log
fill 369 175 567 369 178 567 minecraft:green_terracotta
setblock 369 175 570 minecraft:green_terracotta
setblock 369 175 571 minecraft:oak_log
fill 369 175 572 369 178 572 minecraft:green_terracotta
setblock 369 175 576 minecraft:oak_log
fill 369 175 577 369 176 577 minecraft:green_terracotta
setblock 369 175 581 minecraft:oak_log
fill 369 175 582 369 177 582 minecraft:green_terracotta
setblock 369 175 586 minecraft:oak_log
fill 369 175 587 369 177 587 minecraft:green_terracotta
setblock 370 175 560 minecraft:oak_log
fill 370 175 561 370 178 561 minecraft:green_terracotta
setblock 370 175 565 minecraft:oak_log
fill 370 175 566 370 178 566 minecraft:green_terracotta
setblock 370 175 570 minecraft:oak_log
fill 370 175 571 370 178 571 minecraft:green_terracotta
setblock 370 175 575 minecraft:oak_log
fill 370 175 576 370 177 576 minecraft:green_terracotta
setblock 370 175 580 minecraft:oak_log
fill 370 175 581 370 177 581 minecraft:green_terracotta
setblock 370 175 585 minecraft:oak_log
fill 370 175 586 370 178 586 minecraft:green_terracotta
setblock 370 175 590 minecraft:oak_log
fill 370 175 591 370 178 591 minecraft:green_terracotta
setblock 370 175 596 minecraft:oak_leaves[persistent=true]
fill 329 176 578 329 238 578 minecraft:green_terracotta
setblock 330 176 558 minecraft:green_terracotta
setblock 330 176 559 minecraft:oak_log
fill 330 176 560 330 179 560 minecraft:green_terracotta
setblock 330 176 564 minecraft:oak_log
fill 330 176 565 330 179 565 minecraft:green_terracotta
setblock 330 176 569 minecraft:oak_log
fill 330 176 570 330 179 570 minecraft:green_terracotta
setblock 330 176 584 minecraft:oak_log
fill 330 176 585 330 177 585 minecraft:green_terracotta
setblock 330 176 589 minecraft:oak_log
fill 330 176 590 330 179 590 minecraft:green_terracotta
setblock 330 176 594 minecraft:oak_log
setblock 330 176 595 minecraft:green_terracotta
setblock 331 176 558 minecraft:oak_log
setblock 331 176 559 minecraft:green_terracotta
setblock 331 176 563 minecraft:oak_log
fill 331 176 564 331 178 564 minecraft:green_terracotta
setblock 331 176 568 minecraft:oak_log
fill 331 176 569 331 177 569 minecraft:green_terracotta
fill 332 176 558 332 177 558 minecraft:green_terracotta
setblock 332 176 562 minecraft:oak_log
setblock 332 176 563 minecraft:green_terracotta
setblock 336 176 558 minecraft:oak_log
setblock 337 176 558 minecraft:green_terracotta
setblock 341 176 558 minecraft:oak_log
setblock 341 176 598 minecraft:oak_log
fill 341 176 599 341 239 599 minecraft:green_terracotta
fill 342 176 558 342 178 558 minecraft:green_terracotta
fill 342 176 598 342 179 598 minecraft:green_terracotta
fill 343 176 597 343 179 597 minecraft:green_terracotta
setblock 345 176 559 minecraft:oak_log
fill 345 176 578 346 176 579 minecraft:oak_leaves[persistent=true]
setblock 346 176 558 minecraft:oak_log
setblock 346 176 559 minecraft:green_terracotta
fill 346 176 576 347 176 577 minecraft:oak_leaves[persistent=true]
fill 346 176 580 348 176 580 minecraft:oak_leaves[persistent=true]
setblock 346 176 598 minecraft:oak_log
fill 347 176 558 347 177 558 minecraft:green_terracotta
fill 347 176 575 352 176 575 minecraft:oak_leaves[persistent=true]
fill 347 176 579 347 178 579 minecraft:oak_leaves[persistent=true]
fill 347 176 581 351 176 581 minecraft:oak_leaves[persistent=true]
setblock 347 176 597 minecraft:oak_log
fill 347 176 598 347 179 598 minecraft:green_terracotta
fill 348 176 574 350 176 574 minecraft:oak_leaves[persistent=true]
fill 348 176 576 348 178 576 minecraft:oak_leaves[persistent=true]
fill 348 176 582 350 176 582 minecraft:oak_leaves[persistent=true]
setblock 348 176 597 minecraft:green_terracotta
fill 351 176 576 351 178 576 minecraft:oak_leaves[persistent=true]
setblock 352 176 558 minecraft:oak_leaves[persistent=true]
fill 352 176 562 353 177 562 minecraft:oak_leaves[persistent=true]
fill 361 176 569 362 176 574 minecraft:oak_leaves[persistent=true]
fill 362 176 568 366 176 568 minecraft:oak_leaves[persistent=true]
fill 362 176 575 367 176 575 minecraft:oak_leaves[persistent=true]
fill 363 176 569 366 178 569 minecraft:oak_leaves[persistent=true]
fill 363 176 574 368 176 574 minecraft:oak_leaves[persistent=true]
fill 364 176 558 364 177 558 minecraft:green_terracotta
fill 364 176 567 365 176 567 minecraft:oak_leaves[persistent=true]
setblock 365 176 559 minecraft:oak_log
setblock 366 176 558 minecraft:oak_log
setblock 366 176 559 minecraft:green_terracotta
fill 367 176 558 367 179 558 minecraft:green_terracotta
fill 367 176 563 367 176 566 minecraft:green_terracotta
setblock 367 176 567 minecraft:oak_log
fill 367 176 568 367 179 568 minecraft:green_terracotta
fill 367 176 570 367 178 573 minecraft:oak_leaves[persistent=true]
setblock 367 176 598 minecraft:oak_leaves[persistent=true]
setblock 368 176 560 minecraft:green_terracotta
setblock 368 176 561 minecraft:oak_log
fill 368 176 562 368 177 562 minecraft:green_terracotta
setblock 368 176 566 minecraft:oak_log
fill 368 176 567 368 179 567 minecraft:green_terracotta
setblock 368 176 571 minecraft:oak_log
fill 368 176 572 368 178 572 minecraft:green_terracotta
fill 368 176 573 368 177 573 minecraft:oak_leaves[persistent=true]
setblock 368 176 582 minecraft:green_terracotta
setblock 368 176 586 minecraft:oak_log
setblock 368 176 587 minecraft:green_terracotta
setblock 369 176 560 minecraft:oak_log
fill 369 176 561 369 178 561 minecraft:green_terracotta
setblock 369 176 565 minecraft:oak_log
fill 369 176 566 369 179 566 minecraft:green_terracotta
setblock 369 176 570 minecraft:oak_log
fill 369 176 571 369 179 571 minecraft:green_terracotta
setblock 369 176 575 minecraft:oak_log
setblock 369 176 576 minecraft:green_terracotta
setblock 369 176 580 minecraft:oak_log
setblock 369 176 581 minecraft:green_terracotta
setblock 369 176 585 minecraft:oak_log
fill 369 176 586 369 177 586 minecraft:green_terracotta
setblock 369 176 590 minecraft:oak_log
setblock 370 176 559 minecraft:oak_log
fill 370 176 560 370 179 560 minecraft:green_terracotta
setblock 370 176 564 minecraft:oak_log
fill 370 176 565 370 179 565 minecraft:green_terracotta
setblock 370 176 569 minecraft:oak_log
fill 370 176 570 370 179 570 minecraft:green_terracotta
setblock 370 176 574 minecraft:oak_log
fill 370 176 575 370 178 575 minecraft:green_terracotta
setblock 370 176 579 minecraft:oak_log
fill 370 176 580 370 177 580 minecraft:green_terracotta
setblock 370 176 584 minecraft:oak_log
fill 370 176 585 370 178 585 minecraft:green_terracotta
setblock 370 176 589 minecraft:oak_log
fill 370 176 590 370 179 590 minecraft:green_terracotta
fill 371 176 574 371 234 574 minecraft:green_terracotta
fill 371 176 584 371 236 584 minecraft:green_terracotta
fill 371 176 593 371 238 593 minecraft:green_terracotta
setblock 330 177 558 minecraft:oak_log
fill 330 177 559 330 179 559 minecraft:green_terracotta
setblock 330 177 563 minecraft:oak_log
fill 330 177 564 330 179 564 minecraft:green_terracotta
setblock 330 177 568 minecraft:oak_log
fill 330 177 569 330 179 569 minecraft:green_terracotta
fill 330 177 578 330 178 578 minecraft:oak_leaves[persistent=true]
setblock 330 177 584 minecraft:green_terracotta
setblock 330 177 588 minecraft:oak_log
fill 330 177 589 330 179 589 minecraft:green_terracotta
setblock 330 177 593 minecraft:oak_log
setblock 330 177 594 minecraft:green_terracotta
setblock 330 177 597 minecraft:oak_leaves[persistent=true]
fill 331 177 558 331 178 558 minecraft:green_terracotta
setblock 331 177 562 minecraft:oak_log
fill 331 177 563 331 178 563 minecraft:green_terracotta
setblock 331 177 567 minecraft:oak_log
fill 331 177 568 331 178 568 minecraft:green_terracotta
setblock 332 177 560 minecraft:light[level=14]
setblock 332 177 568 minecraft:light[level=14]
setblock 332 177 576 minecraft:light[level=14]
setblock 332 177 584 minecraft:light[level=14]
setblock 332 177 592 minecraft:light[level=14]
setblock 340 177 558 minecraft:oak_log
setblock 340 177 560 minecraft:light[level=14]
setblock 340 177 568 minecraft:light[level=14]
setblock 340 177 576 minecraft:light[level=14]
setblock 340 177 584 minecraft:light[level=14]
setblock 340 177 592 minecraft:light[level=14]
setblock 340 177 598 minecraft:oak_log
fill 340 177 599 340 235 599 minecraft:green_terracotta
setblock 341 177 558 minecraft:green_terracotta
fill 341 177 598 341 179 598 minecraft:green_terracotta
setblock 345 177 558 minecraft:oak_log
setblock 345 177 598 minecraft:oak_log
fill 346 177 558 346 178 558 minecraft:green_terracotta
fill 346 177 577 346 177 579 minecraft:oak_leaves[persistent=true]
setblock 346 177 597 minecraft:oak_log
fill 346 177 598 346 179 598 minecraft:green_terracotta
fill 347 177 576 347 177 577 minecraft:oak_leaves[persistent=true]
fill 347 177 580 348 178 580 minecraft:oak_leaves[persistent=true]
setblock 347 177 597 minecraft:green_terracotta
setblock 348 177 560 minecraft:light[level=14]
setblock 348 177 568 minecraft:light[level=14]
fill 348 177 575 351 177 575 minecraft:oak_leaves[persistent=true]
fill 348 177 581 351 177 581 minecraft:oak_leaves[persistent=true]
setblock 348 177 584 minecraft:light[level=14]
setblock 348 177 592 minecraft:light[level=14]
setblock 354 177 598 minecraft:oak_leaves[persistent=true]
setblock 356 177 560 minecraft:light[level=14]
setblock 356 177 568 minecraft:light[level=14]
setblock 356 177 576 minecraft:light[level=14]
setblock 356 177 584 minecraft:light[level=14]
setblock 356 177 592 minecraft:light[level=14]
fill 361 177 571 362 177 572 minecraft:oak_leaves[persistent=true]
fill 362 177 569 362 177 570 minecraft:oak_leaves[persistent=true]
fill 362 177 573 362 177 574 minecraft:oak_leaves[persistent=true]
fill 363 177 568 366 177 568 minecraft:oak_leaves[persistent=true]
fill 363 177 574 367 177 574 minecraft:oak_leaves[persistent=true]
setblock 364 177 560 minecraft:light[level=14]
fill 364 177 575 365 177 575 minecraft:oak_leaves[persistent=true]
setblock 364 177 576 minecraft:light[level=14]
setblock 364 177 584 minecraft:light[level=14]
setblock 364 177 592 minecraft:light[level=14]
setblock 365 177 558 minecraft:oak_log
fill 366 177 558 366 179 558 minecraft:green_terracotta
fill 367 177 564 367 177 565 minecraft:green_terracotta
setblock 367 177 566 minecraft:oak_log
fill 367 177 567 367 179 567 minecraft:green_terracotta
setblock 368 177 559 minecraft:green_terracotta
setblock 368 177 565 minecraft:oak_log
fill 368 177 566 368 179 566 minecraft:green_terracotta
setblock 368 177 570 minecraft:oak_log
fill 368 177 571 368 179 571 minecraft:green_terracotta
setblock 369 177 559 minecraft:oak_log
setblock 369 177 560 minecraft:green_terracotta
setblock 369 177 564 minecraft:oak_log
fill 369 177 565 369 179 565 minecraft:green_terracotta
setblock 369 177 569 minecraft:oak_log
fill 369 177 570 369 179 570 minecraft:green_terracotta
setblock 369 177 574 minecraft:oak_log
setblock 369 177 584 minecraft:oak_log
setblock 369 177 585 minecraft:green_terracotta
setblock 369 177 589 minecraft:oak_log
setblock 370 177 558 minecraft:oak_log
fill 370 177 559 370 178 559 minecraft:green_terracotta
setblock 370 177 563 minecraft:oak_log
fill 370 177 564 370 179 564 minecraft:green_terracotta
setblock 370 177 568 minecraft:oak_log
fill 370 177 569 370 179 569 minecraft:green_terracotta
setblock 370 177 573 minecraft:oak_log
fill 370 177 574 370 179 574 minecraft:green_terracotta
setblock 370 177 578 minecraft:oak_log
setblock 370 177 579 minecraft:green_terracotta
setblock 370 177 583 minecraft:oak_log
fill 370 177 584 370 178 584 minecraft:green_terracotta
setblock 370 177 588 minecraft:oak_log
fill 370 177 589 370 179 589 minecraft:green_terracotta
fill 371 177 573 371 238 573 minecraft:green_terracotta
fill 330 178 558 330 179 558 minecraft:green_terracotta
setblock 330 178 562 minecraft:oak_log
fill 330 178 563 330 179 563 minecraft:green_terracotta
setblock 330 178 567 minecraft:oak_log
fill 330 178 568 330 179 568 minecraft:green_terracotta
setblock 330 178 572 minecraft:oak_log
setblock 330 178 584 minecraft:oak_leaves[persistent=true]
setblock 330 178 587 minecraft:oak_log
fill 330 178 588 330 179 588 minecraft:green_terracotta
setblock 330 178 592 minecraft:oak_log
fill 330 178 593 330 179 593 minecraft:green_terracotta
setblock 331 178 562 minecraft:green_terracotta
setblock 331 178 566 minecraft:oak_log
fill 331 178 567 331 179 567 minecraft:green_terracotta
setblock 335 178 598 minecraft:oak_leaves[persistent=true]
setblock 340 178 558 minecraft:oak_leaves[persistent=true]
fill 340 178 598 340 179 598 minecraft:green_terracotta
setblock 344 178 558 minecraft:oak_log
setblock 344 178 598 minecraft:oak_log
setblock 345 178 558 minecraft:green_terracotta
setblock 345 178 597 minecraft:oak_log
fill 345 178 598 345 179 598 minecraft:green_terracotta
fill 346 178 597 346 179 597 minecraft:green_terracotta
setblock 347 178 577 minecraft:oak_leaves[persistent=true]
setblock 349 178 581 minecraft:oak_leaves[persistent=true]
setblock 360 178 598 minecraft:oak_leaves[persistent=true]
fill 362 178 570 362 178 572 minecraft:oak_leaves[persistent=true]
fill 364 178 574 366 178 574 minecraft:oak_leaves[persistent=true]
setblock 365 178 558 minecraft:green_terracotta
setblock 367 178 565 minecraft:oak_log
fill 367 178 566 367 179 566 minecraft:green_terracotta
setblock 368 178 564 minecraft:oak_log
fill 368 178 565 368 179 565 minecraft:green_terracotta
setblock 368 178 569 minecraft:oak_log
fill 368 178 570 368 179 570 minecraft:green_terracotta
setblock 369 178 558 minecraft:oak_log
setblock 369 178 563 minecraft:oak_log
fill 369 178 564 369 179 564 minecraft:green_terracotta
setblock 369 178 568 minecraft:oak_log
fill 369 178 569 369 179 569 minecraft:green_terracotta
setblock 369 178 573 minecraft:oak_log
setblock 370 178 562 minecraft:oak_log
fill 370 178 563 370 179 563 minecraft:green_terracotta
setblock 370 178 567 minecraft:oak_log
fill 370 178 568 370 179 568 minecraft:green_terracotta
setblock 370 178 572 minecraft:oak_log
fill 370 178 573 370 179 573 minecraft:green_terracotta
setblock 370 178 583 minecraft:green_terracotta
setblock 370 178 587 minecraft:oak_log
fill 370 178 588 370 179 588 minecraft:green_terracotta
setblock 370 178 597 minecraft:oak_leaves[persistent=true]
setblock 330 179 561 minecraft:oak_log
setblock 330 179 562 minecraft:green_terracotta
setblock 330 179 566 minecraft:oak_log
setblock 330 179 567 minecraft:green_terracotta
setblock 330 179 571 minecraft:oak_log
setblock 330 179 591 minecraft:oak_log
setblock 330 179 592 minecraft:green_terracotta
setblock 331 179 565 minecraft:oak_log
setblock 331 179 566 minecraft:green_terracotta
setblock 334 179 558 minecraft:oak_leaves[persistent=true]
setblock 339 179 598 minecraft:green_terracotta
setblock 342 179 597 minecraft:green_terracotta
setblock 343 179 598 minecraft:oak_log
setblock 344 179 597 minecraft:oak_log
setblock 344 179 598 minecraft:green_terracotta
setblock 345 179 597 minecraft:green_terracotta
setblock 348 179 598 minecraft:oak_log
setblock 359 179 558 minecraft:oak_leaves[persistent=true]
setblock 366 179 598 minecraft:oak_leaves[persistent=true]
setblock 367 179 569 minecraft:oak_log
setblock 368 179 564 minecraft:green_terracotta
setblock 368 179 568 minecraft:oak_log
setblock 368 179 569 minecraft:green_terracotta
setblock 369 179 562 minecraft:oak_log
setblock 369 179 563 minecraft:green_terracotta
setblock 369 179 567 minecraft:oak_log
setblock 369 179 568 minecraft:green_terracotta
setblock 369 179 572 minecraft:oak_log
setblock 369 179 573 minecraft:green_terracotta
setblock 370 179 561 minecraft:oak_log
setblock 370 179 562 minecraft:green_terracotta
setblock 370 179 566 minecraft:oak_log
setblock 370 179 567 minecraft:green_terracotta
setblock 370 179 571 minecraft:oak_log
setblock 370 179 572 minecraft:green_terracotta
setblock 370 179 587 minecraft:green_terracotta
setblock 370 179 591 minecraft:oak_leaves[persistent=true]
fill 339 180 578 345 197 580 minecraft:jungle_log
fill 340 180 577 344 198 577 minecraft:jungle_log
fill 340 180 581 344 198 581 minecraft:jungle_log
fill 341 180 576 343 198 576 minecraft:jungle_log
fill 341 180 582 343 198 582 minecraft:jungle_log
fill 345 184 577 347 184 577 minecraft:dark_oak_log
fill 345 184 581 347 184 581 minecraft:dark_oak_log
fill 346 184 575 348 184 576 minecraft:dark_oak_log
fill 346 184 578 347 184 580 minecraft:dark_oak_log
fill 346 184 582 347 184 583 minecraft:dark_oak_log
fill 347 184 573 348 185 574 minecraft:dark_oak_log
fill 347 184 584 350 184 585 minecraft:dark_oak_log
fill 348 184 581 350 184 583 minecraft:redstone_block
fill 349 184 572 357 184 573 minecraft:dark_oak_log
fill 349 184 574 351 184 576 minecraft:redstone_block
fill 349 184 586 357 184 586 minecraft:dark_oak_log
fill 351 184 571 355 188 571 minecraft:dark_oak_log
fill 351 184 585 359 184 585 minecraft:dark_oak_log
fill 351 184 587 355 188 587 minecraft:dark_oak_log
fill 355 184 574 357 184 576 minecraft:redstone_block
fill 356 184 581 358 184 583 minecraft:redstone_block
fill 356 184 584 359 184 584 minecraft:dark_oak_log
fill 358 184 573 359 184 576 minecraft:dark_oak_log
fill 359 184 577 360 184 583 minecraft:dark_oak_log
fill 360 184 575 360 188 576 minecraft:dark_oak_log
fill 361 184 577 361 188 581 minecraft:dark_oak_log
setblock 332 185 560 minecraft:light[level=14]
setblock 332 185 568 minecraft:light[level=14]
setblock 332 185 576 minecraft:light[level=14]
setblock 332 185 584 minecraft:light[level=14]
setblock 332 185 592 minecraft:light[level=14]
setblock 340 185 560 minecraft:light[level=14]
setblock 340 185 568 minecraft:light[level=14]
setblock 340 185 576 minecraft:light[level=14]
setblock 340 185 584 minecraft:light[level=14]
setblock 340 185 592 minecraft:light[level=14]
fill 345 185 575 346 187 577 minecraft:dark_oak_log
fill 345 185 581 346 187 583 minecraft:dark_oak_log
fill 346 185 573 346 187 574 minecraft:dark_oak_log
fill 346 185 578 346 188 578 minecraft:dark_oak_log
fill 346 185 579 351 185 579 minecraft:stripped_oak_log
fill 346 185 580 346 188 580 minecraft:dark_oak_log
fill 346 185 584 348 185 585 minecraft:dark_oak_log
fill 347 185 572 352 187 572 minecraft:dark_oak_log
fill 347 185 575 347 188 575 minecraft:dark_oak_log
fill 347 185 576 348 185 578 minecraft:stripped_oak_log
fill 347 185 580 347 185 582 minecraft:stripped_oak_log
setblock 347 185 583 minecraft:dark_oak_log
fill 347 185 586 352 187 586 minecraft:dark_oak_log
setblock 348 185 560 minecraft:light[level=14]
setblock 348 185 568 minecraft:light[level=14]
setblock 348 185 575 minecraft:stripped_oak_log
fill 348 185 580 351 185 580 minecraft:stripped_oak_log
setblock 348 185 592 minecraft:light[level=14]
fill 349 185 571 350 187 571 minecraft:dark_oak_log
setblock 349 185 573 minecraft:dark_oak_log
fill 349 185 577 351 185 578 minecraft:stripped_oak_log
fill 349 185 584 357 185 584 minecraft:stripped_oak_log
fill 349 185 585 349 188 585 minecraft:dark_oak_log
fill 349 185 587 350 187 587 minecraft:dark_oak_log
fill 350 185 573 356 185 573 minecraft:stripped_oak_log
fill 350 185 585 356 186 585 minecraft:stripped_oak_log
fill 351 185 570 355 187 570 minecraft:dark_oak_log
fill 351 185 581 355 185 583 minecraft:stripped_oak_log
fill 351 185 588 355 187 588 minecraft:dark_oak_log
fill 352 185 574 354 185 577 minecraft:stripped_oak_log
fill 353 185 572 353 186 572 minecraft:stripped_oak_log
fill 353 185 586 353 186 586 minecraft:stripped_oak_log
fill 354 185 572 359 187 572 minecraft:dark_oak_log
fill 354 185 586 359 187 586 minecraft:dark_oak_log
fill 355 185 577 359 185 580 minecraft:stripped_oak_log
setblock 356 185 560 minecraft:light[level=14]
setblock 356 185 568 minecraft:light[level=14]
fill 356 185 571 357 187 571 minecraft:dark_oak_log
setblock 356 185 576 minecraft:light[level=14]
fill 356 185 587 357 187 587 minecraft:dark_oak_log
setblock 356 185 592 minecraft:light[level=14]
fill 357 185 573 360 185 573 minecraft:dark_oak_log
fill 357 185 585 360 187 585 minecraft:dark_oak_log
fill 358 185 574 360 185 574 minecraft:dark_oak_log
fill 358 185 575 358 185 576 minecraft:stripped_oak_log
fill 358 185 584 360 185 584 minecraft:dark_oak_log
fill 359 185 575 359 188 575 minecraft:dark_oak_log
fill 359 185 576 359 186 576 minecraft:stripped_oak_log
fill 359 185 581 359 185 582 minecraft:stripped_oak_log
fill 359 185 583 361 185 583 minecraft:dark_oak_log
fill 360 185 577 360 188 578 minecraft:dark_oak_log
fill 360 185 579 360 186 579 minecraft:stripped_oak_log
fill 360 185 580 360 188 582 minecraft:dark_oak_log
fill 361 185 575 361 187 576 minecraft:dark_oak_log
fill 361 185 582 361 187 582 minecraft:dark_oak_log
fill 362 185 577 362 187 581 minecraft:dark_oak_log
setblock 364 185 560 minecraft:light[level=14]
setblock 364 185 568 minecraft:light[level=14]
setblock 364 185 576 minecraft:light[level=14]
setblock 364 185 584 minecraft:light[level=14]
setblock 364 185 592 minecraft:light[level=14]
fill 330 186 558 338 186 598 minecraft:oak_log
fill 339 186 558 339 186 577 minecraft:oak_log
fill 339 186 581 339 186 598 minecraft:oak_log
fill 340 186 558 340 186 576 minecraft:oak_log
fill 340 186 582 340 186 598 minecraft:oak_log
fill 341 186 558 344 186 575 minecraft:oak_log
fill 341 186 583 344 186 598 minecraft:oak_log
setblock 344 186 576 minecraft:dark_oak_log
setblock 344 186 582 minecraft:dark_oak_log
fill 345 186 558 345 186 573 minecraft:oak_log
setblock 345 186 574 minecraft:dark_oak_log
fill 345 186 584 346 186 584 minecraft:dark_oak_log
fill 345 186 585 345 186 598 minecraft:oak_log
fill 346 186 558 346 186 572 minecraft:oak_log
fill 346 186 579 350 186 579 minecraft:stripped_oak_log
fill 346 186 585 348 187 585 minecraft:dark_oak_log
fill 346 186 586 346 186 598 minecraft:oak_log
fill 347 186 558 347 186 571 minecraft:oak_log
fill 347 186 573 347 188 574 minecraft:dark_oak_log
fill 347 186 576 347 186 578 minecraft:stripped_oak_log
fill 347 186 580 347 186 584 minecraft:ochre_froglight
fill 347 186 587 347 186 598 minecraft:oak_log
fill 348 186 558 349 186 570 minecraft:oak_log
setblock 348 186 571 minecraft:dark_oak_log
fill 348 186 573 348 186 577 minecraft:ochre_froglight
fill 348 186 578 350 186 578 minecraft:stripped_oak_log
fill 348 186 580 351 186 580 minecraft:ochre_froglight
fill 348 186 581 350 186 583 minecraft:oak_log
fill 348 186 584 351 186 584 minecraft:ochre_froglight
setblock 348 186 587 minecraft:dark_oak_log
fill 348 186 588 349 186 598 minecraft:oak_log
fill 349 186 573 352 186 573 minecraft:ochre_froglight
fill 349 186 574 351 186 576 minecraft:oak_log
fill 349 186 577 358 186 577 minecraft:ochre_froglight
fill 350 186 558 370 186 569 minecraft:oak_log
setblock 350 186 570 minecraft:dark_oak_log
setblock 350 186 588 minecraft:dark_oak_log
fill 350 186 589 370 186 598 minecraft:oak_log
fill 351 186 578 351 186 579 minecraft:ochre_froglight
fill 351 186 581 351 186 583 minecraft:ochre_froglight
fill 352 186 574 352 186 576 minecraft:ochre_froglight
fill 352 186 581 355 186 581 minecraft:ochre_froglight
fill 352 186 582 354 186 584 minecraft:stripped_oak_log
fill 353 186 573 353 186 576 minecraft:stripped_oak_log
fill 354 186 573 354 186 576 minecraft:ochre_froglight
fill 355 186 573 358 186 573 minecraft:ochre_froglight
fill 355 186 574 357 186 576 minecraft:oak_log
fill 355 186 578 355 186 580 minecraft:ochre_froglight
fill 355 186 582 355 186 584 minecraft:ochre_froglight
setblock 356 186 570 minecraft:dark_oak_log
fill 356 186 578 359 186 579 minecraft:stripped_oak_log
fill 356 186 580 359 186 580 minecraft:ochre_froglight
fill 356 186 581 358 186 583 minecraft:oak_log
fill 356 186 584 359 186 584 minecraft:ochre_froglight
setblock 356 186 588 minecraft:dark_oak_log
fill 357 186 570 370 186 570 minecraft:oak_log
fill 357 186 588 370 186 588 minecraft:oak_log
setblock 358 186 571 minecraft:dark_oak_log
fill 358 186 574 358 186 576 minecraft:ochre_froglight
setblock 358 186 587 minecraft:dark_oak_log
fill 359 186 571 370 186 571 minecraft:oak_log
fill 359 186 573 360 187 574 minecraft:dark_oak_log
setblock 359 186 577 minecraft:stripped_oak_log
fill 359 186 581 359 186 583 minecraft:ochre_froglight
fill 359 186 587 370 186 587 minecraft:oak_log
fill 360 186 572 370 186 572 minecraft:oak_log
fill 360 186 583 361 186 584 minecraft:dark_oak_log
fill 360 186 586 370 186 586 minecraft:oak_log
fill 361 186 573 370 186 573 minecraft:oak_log
setblock 361 186 574 minecraft:dark_oak_log
fill 361 186 585 370 186 585 minecraft:oak_log
fill 362 186 574 370 186 575 minecraft:oak_log
setblock 362 186 576 minecraft:dark_oak_log
setblock 362 186 582 minecraft:dark_oak_log
fill 362 186 583 370 186 584 minecraft:oak_log
fill 363 186 576 370 186 582 minecraft:oak_log
fill 346 187 579 348 187 579 minecraft:dark_oak_log
fill 346 187 584 360 187 584 minecraft:dark_oak_log
fill 347 187 576 348 187 578 minecraft:dark_oak_log
fill 347 187 580 348 187 583 minecraft:dark_oak_log
fill 348 187 573 350 187 575 minecraft:dark_oak_log
setblock 349 187 576 minecraft:dark_oak_log
fill 349 187 582 349 187 583 minecraft:dark_oak_log
setblock 350 187 583 minecraft:dark_oak_log
fill 350 187 585 356 188 585 minecraft:dark_oak_log
fill 351 187 573 358 187 574 minecraft:dark_oak_log
fill 353 187 572 353 188 572 minecraft:dark_oak_log
fill 353 187 586 353 188 586 minecraft:dark_oak_log
fill 356 187 575 358 187 575 minecraft:dark_oak_log
fill 356 187 583 361 187 583 minecraft:dark_oak_log
fill 357 187 576 359 187 576 minecraft:dark_oak_log
fill 357 187 582 359 187 582 minecraft:dark_oak_log
fill 358 187 577 359 187 581 minecraft:dark_oak_log
fill 360 187 579 360 188 579 minecraft:dark_oak_log
fill 345 188 577 347 188 577 minecraft:dark_oak_log
fill 345 188 581 347 188 581 minecraft:dark_oak_log
fill 346 188 575 346 188 576 minecraft:dark_oak_log
fill 346 188 579 347 188 579 minecraft:dark_oak_log
fill 346 188 582 348 188 583 minecraft:dark_oak_log
fill 347 188 576 348 188 576 minecraft:dark_oak_log
setblock 347 188 578 minecraft:dark_oak_log
setblock 347 188 580 minecraft:dark_oak_log
fill 347 188 584 348 188 585 minecraft:dark_oak_log
fill 348 188 573 349 188 575 minecraft:dark_oak_log
fill 349 188 572 352 188 572 minecraft:dark_oak_log
fill 349 188 583 349 188 584 minecraft:dark_oak_log
fill 349 188 586 352 188 586 minecraft:dark_oak_log
fill 350 188 573 350 188 574 minecraft:dark_oak_log
setblock 350 188 584 minecraft:dark_oak_log
fill 351 188 573 359 188 573 minecraft:dark_oak_log
fill 354 188 572 357 188 572 minecraft:dark_oak_log
fill 354 188 586 357 188 586 minecraft:dark_oak_log
fill 356 188 574 359 188 574 minecraft:dark_oak_log
fill 356 188 584 359 188 584 minecraft:dark_oak_log
fill 357 188 575 358 188 575 minecraft:dark_oak_log
fill 357 188 583 360 188 583 minecraft:dark_oak_log
fill 357 188 585 359 188 585 minecraft:dark_oak_log
fill 358 188 576 359 188 576 minecraft:dark_oak_log
fill 358 188 582 359 188 582 minecraft:dark_oak_log
fill 359 188 577 359 188 581 minecraft:dark_oak_log
fill 330 190 558 330 190 559 minecraft:green_terracotta
setblock 330 190 568 minecraft:oak_leaves[persistent=true]
fill 330 190 591 330 190 594 minecraft:green_terracotta
setblock 330 190 595 minecraft:oak_log
fill 330 190 596 331 190 598 minecraft:green_terracotta
setblock 331 190 558 minecraft:green_terracotta
setblock 331 190 593 minecraft:green_terracotta
setblock 331 190 594 minecraft:oak_log
fill 331 190 595 332 191 595 minecraft:green_terracotta
setblock 332 190 558 minecraft:oak_log
fill 332 190 564 332 201 564 minecraft:oak_leaves[persistent=true]
setblock 332 190 594 minecraft:green_terracotta
fill 332 190 596 332 190 597 minecraft:green_terracotta
setblock 332 190 598 minecraft:oak_log
fill 333 190 558 336 190 558 minecraft:green_terracotta
setblock 333 190 596 minecraft:green_terracotta
setblock 333 190 597 minecraft:oak_log
fill 333 190 598 336 190 598 minecraft:green_terracotta
setblock 334 190 595 minecraft:green_terracotta
setblock 334 190 596 minecraft:oak_log
fill 334 190 597 337 190 597 minecraft:green_terracotta
setblock 335 190 559 minecraft:green_terracotta
setblock 335 190 595 minecraft:oak_log
fill 335 190 596 338 190 596 minecraft:green_terracotta
setblock 336 190 559 minecraft:oak_log
fill 336 190 595 339 190 595 minecraft:green_terracotta
setblock 337 190 558 minecraft:oak_log
fill 337 190 559 340 190 559 minecraft:green_terracotta
setblock 337 190 598 minecraft:oak_log
fill 338 190 558 341 190 558 minecraft:green_terracotta
setblock 338 190 597 minecraft:oak_log
fill 338 190 598 341 190 598 minecraft:green_terracotta
setblock 339 190 596 minecraft:oak_log
fill 339 190 597 342 190 597 minecraft:green_terracotta
setblock 340 190 595 minecraft:oak_log
fill 340 190 596 343 190 596 minecraft:green_terracotta
setblock 341 190 595 minecraft:green_terracotta
setblock 342 190 558 minecraft:oak_log
setblock 342 190 598 minecraft:oak_log
fill 343 190 558 343 191 558 minecraft:green_terracotta
setblock 343 190 597 minecraft:oak_log
fill 343 190 598 346 190 598 minecraft:green_terracotta
fill 344 190 597 345 190 597 minecraft:green_terracotta
setblock 347 190 598 minecraft:oak_log
setblock 348 190 598 minecraft:green_terracotta
setblock 351 190 598 minecraft:green_terracotta
setblock 352 190 598 minecraft:oak_log
fill 353 190 558 356 190 558 minecraft:green_terracotta
fill 353 190 598 356 190 598 minecraft:green_terracotta
fill 355 190 597 357 190 597 minecraft:green_terracotta
setblock 356 190 559 minecraft:oak_log
setblock 357 190 558 minecraft:oak_log
fill 357 190 559 360 190 559 minecraft:green_terracotta
setblock 357 190 598 minecraft:oak_log
fill 358 190 558 361 190 558 minecraft:green_terracotta
setblock 358 190 597 minecraft:oak_log
fill 358 190 598 361 190 598 minecraft:green_terracotta
fill 359 190 597 362 190 597 minecraft:green_terracotta
setblock 361 190 559 minecraft:oak_log
setblock 362 190 558 minecraft:oak_log
fill 362 190 559 365 190 559 minecraft:green_terracotta
setblock 362 190 598 minecraft:oak_log
fill 363 190 558 366 190 558 minecraft:green_terracotta
fill 363 190 572 363 204 572 minecraft:iron_block
setblock 363 190 597 minecraft:oak_log
fill 363 190 598 366 190 598 minecraft:green_terracotta
fill 364 190 597 365 190 597 minecraft:green_terracotta
setblock 366 190 559 minecraft:oak_log
setblock 367 190 558 minecraft:oak_log
setblock 367 190 598 minecraft:oak_log
fill 368 190 558 370 191 558 minecraft:green_terracotta
fill 368 190 598 370 191 598 minecraft:green_terracotta
setblock 370 190 559 minecraft:green_terracotta
setblock 370 190 560 minecraft:oak_log
fill 370 190 561 370 193 561 minecraft:green_terracotta
setblock 370 190 563 minecraft:oak_leaves[persistent=true]
setblock 370 190 570 minecraft:oak_log
fill 370 190 571 370 190 574 minecraft:green_terracotta
setblock 370 190 575 minecraft:oak_log
setblock 370 190 576 minecraft:green_terracotta
setblock 370 190 588 minecraft:oak_leaves[persistent=true]
setblock 370 190 594 minecraft:green_terracotta
setblock 370 190 595 minecraft:oak_log
fill 370 190 596 370 192 597 minecraft:green_terracotta
setblock 330 191 558 minecraft:green_terracotta
setblock 330 191 559 minecraft:oak_log
setblock 330 191 574 minecraft:oak_leaves[persistent=true]
fill 330 191 592 330 191 593 minecraft:green_terracotta
setblock 330 191 594 minecraft:oak_log
fill 330 191 595 330 191 598 minecraft:green_terracotta
setblock 331 191 558 minecraft:oak_log
setblock 331 191 593 minecraft:oak_log
fill 331 191 594 331 193 594 minecraft:green_terracotta
fill 331 191 596 331 191 597 minecraft:green_terracotta
setblock 331 191 598 minecraft:oak_log
fill 332 191 558 335 191 558 minecraft:green_terracotta
setblock 332 191 596 minecraft:green_terracotta
setblock 332 191 597 minecraft:oak_log
fill 332 191 598 335 191 598 minecraft:green_terracotta
setblock 333 191 596 minecraft:oak_log
fill 333 191 597 336 191 597 minecraft:green_terracotta
fill 334 191 596 337 191 596 minecraft:green_terracotta
setblock 335 191 559 minecraft:oak_log
fill 335 191 595 338 191 595 minecraft:green_terracotta
setblock 336 191 558 minecraft:oak_log
fill 336 191 559 339 191 559 minecraft:green_terracotta
setblock 336 191 598 minecraft:oak_log
fill 337 191 558 340 191 558 minecraft:green_terracotta
setblock 337 191 597 minecraft:oak_log
fill 337 191 598 340 191 598 minecraft:green_terracotta
setblock 338 191 596 minecraft:oak_log
fill 338 191 597 341 191 597 minecraft:green_terracotta
setblock 339 191 595 minecraft:oak_log
fill 339 191 596 342 191 596 minecraft:green_terracotta
setblock 340 191 595 minecraft:green_terracotta
setblock 341 191 558 minecraft:oak_log
setblock 341 191 598 minecraft:oak_log
fill 342 191 558 342 193 558 minecraft:green_terracotta
setblock 342 191 597 minecraft:oak_log
fill 342 191 598 345 191 598 minecraft:green_terracotta
fill 343 191 597 344 191 597 minecraft:green_terracotta
setblock 346 191 598 minecraft:oak_log
setblock 347 191 598 minecraft:green_terracotta
setblock 350 191 558 minecraft:oak_leaves[persistent=true]
setblock 350 191 598 minecraft:oak_leaves[persistent=true]
fill 352 191 598 355 191 598 minecraft:green_terracotta
fill 353 191 558 355 191 558 minecraft:green_terracotta
setblock 355 191 559 minecraft:oak_log
fill 355 191 597 356 191 597 minecraft:green_terracotta
setblock 356 191 558 minecraft:oak_log
fill 356 191 559 359 191 559 minecraft:green_terracotta
setblock 356 191 598 minecraft:oak_log
fill 357 191 558 360 191 558 minecraft:green_terracotta
setblock 357 191 597 minecraft:oak_log
fill 357 191 598 360 191 598 minecraft:green_terracotta
fill 358 191 597 361 191 597 minecraft:green_terracotta
setblock 360 191 559 minecraft:oak_log
setblock 361 191 558 minecraft:oak_log
fill 361 191 559 364 191 559 minecraft:green_terracotta
setblock 361 191 598 minecraft:oak_log
fill 362 191 558 365 191 558 minecraft:green_terracotta
setblock 362 191 597 minecraft:oak_log
fill 362 191 598 365 191 598 minecraft:green_terracotta
fill 363 191 597 364 191 597 minecraft:green_terracotta
setblock 365 191 559 minecraft:oak_log
setblock 366 191 558 minecraft:oak_log
setblock 366 191 559 minecraft:green_terracotta
setblock 366 191 598 minecraft:oak_log
fill 367 191 558 367 194 558 minecraft:green_terracotta
fill 367 191 598 367 194 598 minecraft:green_terracotta
setblock 370 191 559 minecraft:oak_log
fill 370 191 560 370 194 560 minecraft:green_terracotta
setblock 370 191 574 minecraft:oak_log
setblock 370 191 575 minecraft:green_terracotta
setblock 370 191 582 minecraft:oak_leaves[persistent=true]
setblock 370 191 594 minecraft:oak_log
fill 370 191 595 370 194 595 minecraft:green_terracotta
setblock 330 192 558 minecraft:oak_log
fill 330 192 559 330 195 559 minecraft:green_terracotta
setblock 330 192 561 minecraft:oak_leaves[persistent=true]
setblock 330 192 580 minecraft:oak_leaves[persistent=true]
setblock 330 192 592 minecraft:green_terracotta
setblock 330 192 593 minecraft:oak_log
fill 330 192 594 330 192 597 minecraft:green_terracotta
setblock 330 192 598 minecraft:oak_log
fill 331 192 558 334 192 558 minecraft:green_terracotta
fill 331 192 595 331 192 596 minecraft:green_terracotta
setblock 331 192 597 minecraft:oak_log
fill 331 192 598 334 192 598 minecraft:green_terracotta
setblock 332 192 596 minecraft:oak_log
fill 332 192 597 335 192 597 minecraft:green_terracotta
fill 333 192 596 336 192 596 minecraft:green_terracotta
setblock 334 192 559 minecraft:oak_log
setblock 335 192 558 minecraft:oak_log
fill 335 192 559 338 192 559 minecraft:green_terracotta
setblock 335 192 598 minecraft:oak_log
fill 336 192 558 339 192 558 minecraft:green_terracotta
setblock 336 192 597 minecraft:oak_log
fill 336 192 598 339 192 598 minecraft:green_terracotta
setblock 337 192 595 minecraft:green_terracotta
setblock 337 192 596 minecraft:oak_log
fill 337 192 597 340 192 597 minecraft:green_terracotta
fill 338 192 596 341 192 596 minecraft:green_terracotta
setblock 340 192 558 minecraft:oak_log
setblock 340 192 598 minecraft:oak_log
fill 341 192 558 341 195 558 minecraft:green_terracotta
setblock 341 192 597 minecraft:oak_log
fill 341 192 598 344 192 598 minecraft:green_terracotta
fill 342 192 597 343 192 597 minecraft:green_terracotta
setblock 344 192 558 minecraft:oak_leaves[persistent=true]
fill 344 192 569 344 193 570 minecraft:glowstone
setblock 345 192 598 minecraft:oak_log
fill 352 192 558 354 192 558 minecraft:green_terracotta
fill 352 192 598 354 192 598 minecraft:green_terracotta
setblock 355 192 558 minecraft:oak_log
fill 355 192 559 358 192 559 minecraft:green_terracotta
setblock 355 192 598 minecraft:oak_log
fill 356 192 558 359 192 558 minecraft:green_terracotta
setblock 356 192 597 minecraft:oak_log
fill 356 192 598 359 192 598 minecraft:green_terracotta
fill 357 192 597 360 192 597 minecraft:green_terracotta
setblock 359 192 559 minecraft:oak_log
setblock 360 192 558 minecraft:oak_log
fill 360 192 559 363 192 559 minecraft:green_terracotta
setblock 360 192 598 minecraft:oak_log
fill 361 192 558 364 192 558 minecraft:green_terracotta
setblock 361 192 597 minecraft:oak_log
fill 361 192 598 364 192 598 minecraft:green_terracotta
setblock 362 192 597 minecraft:green_terracotta
setblock 364 192 559 minecraft:oak_log
setblock 365 192 558 minecraft:oak_log
fill 365 192 559 365 195 559 minecraft:green_terracotta
setblock 365 192 598 minecraft:oak_log
fill 366 192 558 366 195 558 minecraft:green_terracotta
fill 366 192 598 366 195 598 minecraft:green_terracotta
fill 368 192 558 369 192 558 minecraft:green_terracotta
fill 368 192 598 369 192 598 minecraft:green_terracotta
setblock 370 192 558 minecraft:oak_log
fill 370 192 559 370 195 559 minecraft:green_terracotta
setblock 370 192 576 minecraft:oak_leaves[persistent=true]
setblock 370 192 598 minecraft:oak_log
fill 330 193 558 333 193 558 minecraft:green_terracotta
setblock 330 193 567 minecraft:oak_leaves[persistent=true]
setblock 330 193 586 minecraft:oak_leaves[persistent=true]
fill 330 193 593 330 193 596 minecraft:green_terracotta
setblock 330 193 597 minecraft:oak_log
fill 330 193 598 333 193 598 minecraft:green_terracotta
setblock 331 193 595 minecraft:green_terracotta
setblock 331 193 596 minecraft:oak_log
fill 331 193 597 334 193 597 minecraft:green_terracotta
setblock 332 193 560 minecraft:light[level=14]
setblock 332 193 568 minecraft:light[level=14]
setblock 332 193 576 minecraft:light[level=14]
setblock 332 193 584 minecraft:light[level=14]
setblock 332 193 592 minecraft:light[level=14]
fill 333 193 596 335 193 596 minecraft:green_terracotta
setblock 334 193 558 minecraft:oak_log
fill 334 193 559 337 193 559 minecraft:green_terracotta
setblock 334 193 598 minecraft:oak_log
fill 335 193 558 338 193 558 minecraft:green_terracotta
setblock 335 193 597 minecraft:oak_log
fill 335 193 598 338 193 598 minecraft:green_terracotta
setblock 336 193 596 minecraft:oak_log
fill 336 193 597 339 193 597 minecraft:green_terracotta
fill 337 193 596 339 193 596 minecraft:green_terracotta
setblock 338 193 559 minecraft:oak_log
setblock 339 193 558 minecraft:oak_log
setblock 339 193 598 minecraft:oak_log
fill 340 193 558 340 196 558 minecraft:green_terracotta
setblock 340 193 560 minecraft:light[level=14]
setblock 340 193 568 minecraft:light[level=14]
setblock 340 193 576 minecraft:light[level=14]
setblock 340 193 584 minecraft:light[level=14]
setblock 340 193 592 minecraft:light[level=14]
setblock 340 193 597 minecraft:oak_log
fill 340 193 598 343 193 598 minecraft:green_terracotta
fill 341 193 597 342 193 597 minecraft:green_terracotta
setblock 344 193 598 minecraft:oak_log
setblock 348 193 560 minecraft:light[level=14]
setblock 348 193 568 minecraft:light[level=14]
setblock 348 193 576 minecraft:light[level=14]
setblock 348 193 584 minecraft:light[level=14]
setblock 348 193 592 minecraft:light[level=14]
fill 352 193 558 353 193 558 minecraft:green_terracotta
fill 352 193 598 353 193 598 minecraft:green_terracotta
setblock 354 193 558 minecraft:oak_log
fill 354 193 559 357 193 559 minecraft:green_terracotta
setblock 354 193 598 minecraft:oak_log
fill 355 193 558 358 193 558 minecraft:green_terracotta
fill 355 193 598 358 193 598 minecraft:green_terracotta
setblock 356 193 560 minecraft:light[level=14]
setblock 356 193 568 minecraft:light[level=14]
setblock 356 193 576 minecraft:light[level=14]
setblock 356 193 584 minecraft:light[level=14]
setblock 356 193 592 minecraft:light[level=14]
fill 356 193 597 359 193 597 minecraft:green_terracotta
setblock 358 193 559 minecraft:oak_log
fill 358 193 560 359 195 560 minecraft:green_terracotta
setblock 359 193 558 minecraft:oak_log
fill 359 193 559 362 193 559 minecraft:green_terracotta
setblock 359 193 598 minecraft:oak_log
fill 360 193 558 363 193 558 minecraft:green_terracotta
setblock 360 193 597 minecraft:oak_log
fill 360 193 598 363 193 598 minecraft:green_terracotta
fill 361 193 562 364 233 564 minecraft:oak_log
setblock 363 193 559 minecraft:oak_log
setblock 364 193 558 minecraft:oak_log
fill 364 193 559 364 196 559 minecraft:green_terracotta
setblock 364 193 560 minecraft:light[level=14]
setblock 364 193 568 minecraft:light[level=14]
setblock 364 193 576 minecraft:light[level=14]
setblock 364 193 584 minecraft:light[level=14]
setblock 364 193 592 minecraft:light[level=14]
setblock 364 193 598 minecraft:oak_log
fill 365 193 558 365 196 558 minecraft:green_terracotta
fill 365 193 598 365 196 598 minecraft:green_terracotta
setblock 368 193 558 minecraft:green_terracotta
setblock 368 193 598 minecraft:green_terracotta
setblock 369 193 558 minecraft:oak_log
setblock 369 193 598 minecraft:oak_log
fill 370 193 558 370 196 558 minecraft:green_terracotta
setblock 370 193 570 minecraft:oak_leaves[persistent=true]
setblock 370 193 589 minecraft:oak_leaves[persistent=true]
setblock 370 193 596 minecraft:green_terracotta
setblock 370 193 597 minecraft:oak_log
fill 370 193 598 370 196 598 minecraft:green_terracotta
fill 330 194 558 332 194 558 minecraft:green_terracotta
setblock 330 194 560 minecraft:green_terracotta
setblock 330 194 573 minecraft:oak_leaves[persistent=true]
setblock 330 194 592 minecraft:oak_leaves[persistent=true]
fill 330 194 593 330 194 595 minecraft:green_terracotta
setblock 330 194 596 minecraft:oak_log
fill 330 194 597 332 194 598 minecraft:green_terracotta
setblock 331 194 595 minecraft:oak_log
fill 331 194 596 331 197 596 minecraft:green_terracotta
setblock 333 194 558 minecraft:oak_log
fill 333 194 559 336 194 559 minecraft:green_terracotta
fill 333 194 596 333 194 597 minecraft:green_terracotta
setblock 333 194 598 minecraft:oak_log
fill 334 194 558 337 194 558 minecraft:green_terracotta
setblock 334 194 596 minecraft:green_terracotta
setblock 334 194 597 minecraft:oak_log
fill 334 194 598 337 194 598 minecraft:green_terracotta
setblock 335 194 596 minecraft:oak_log
fill 335 194 597 338 194 597 minecraft:green_terracotta
fill 336 194 596 338 194 596 minecraft:green_terracotta
setblock 337 194 559 minecraft:oak_log
setblock 338 194 558 minecraft:oak_log
setblock 338 194 598 minecraft:oak_log
fill 339 194 558 339 197 558 minecraft:green_terracotta
setblock 339 194 597 minecraft:oak_log
fill 339 194 598 342 194 598 minecraft:green_terracotta
fill 340 194 597 341 194 597 minecraft:green_terracotta
setblock 343 194 598 minecraft:oak_log
setblock 349 194 598 minecraft:oak_leaves[persistent=true]
fill 351 194 558 352 194 558 minecraft:green_terracotta
setblock 352 194 598 minecraft:green_terracotta
setblock 353 194 558 minecraft:oak_log
setblock 353 194 598 minecraft:oak_log
fill 354 194 558 356 194 559 minecraft:green_terracotta
fill 354 194 598 357 194 598 minecraft:green_terracotta
setblock 357 194 558 minecraft:green_terracotta
setblock 357 194 559 minecraft:oak_log
fill 357 194 560 357 197 560 minecraft:green_terracotta
setblock 358 194 558 minecraft:oak_log
fill 358 194 559 361 194 559 minecraft:green_terracotta
setblock 358 194 598 minecraft:oak_log
fill 359 194 558 362 194 558 minecraft:green_terracotta
fill 359 194 598 362 194 598 minecraft:green_terracotta
fill 360 194 563 360 195 563 minecraft:dark_oak_log
fill 361 194 561 364 195 561 minecraft:dark_oak_log
fill 361 194 565 364 195 565 minecraft:dark_oak_log
setblock 362 194 559 minecraft:oak_log
setblock 363 194 558 minecraft:oak_log
fill 363 194 559 363 197 559 minecraft:green_terracotta
setblock 363 194 598 minecraft:oak_log
fill 364 194 558 364 197 558 minecraft:green_terracotta
fill 364 194 598 364 196 598 minecraft:green_terracotta
fill 365 194 562 365 195 564 minecraft:dark_oak_log
setblock 368 194 558 minecraft:oak_log
setblock 368 194 598 minecraft:oak_log
fill 369 194 558 369 196 559 minecraft:green_terracotta
fill 369 194 598 369 197 598 minecraft:green_terracotta
setblock 370 194 561 minecraft:oak_log
fill 370 194 562 370 197 562 minecraft:green_terracotta
setblock 370 194 564 minecraft:oak_leaves[persistent=true]
setblock 370 194 583 minecraft:oak_leaves[persistent=true]
setblock 370 194 596 minecraft:oak_log
fill 370 194 597 370 197 597 minecraft:green_terracotta
fill 330 195 558 331 195 558 minecraft:green_terracotta
setblock 330 195 560 minecraft:oak_log
fill 330 195 578 330 195 579 minecraft:green_terracotta
setblock 330 195 580 minecraft:oak_log
fill 330 195 581 330 196 583 minecraft:green_terracotta
fill 330 195 593 330 195 594 minecraft:green_terracotta
setblock 330 195 595 minecraft:oak_log
fill 330 195 596 330 196 598 minecraft:green_terracotta
fill 331 195 595 331 198 595 minecraft:green_terracotta
fill 331 195 597 331 195 598 minecraft:green_terracotta
setblock 332 195 558 minecraft:oak_log
fill 332 195 559 335 195 559 minecraft:green_terracotta
setblock 332 195 597 minecraft:green_terracotta
setblock 332 195 598 minecraft:oak_log
fill 333 195 558 336 195 558 minecraft:green_terracotta
setblock 333 195 596 minecraft:green_terracotta
setblock 333 195 597 minecraft:oak_log
fill 333 195 598 336 195 598 minecraft:green_terracotta
setblock 334 195 596 minecraft:oak_log
fill 334 195 597 337 195 597 minecraft:green_terracotta
fill 335 195 596 337 195 596 minecraft:green_terracotta
setblock 336 195 559 minecraft:oak_log
setblock 337 195 558 minecraft:oak_log
fill 337 195 559 337 198 559 minecraft:green_terracotta
setblock 337 195 598 minecraft:oak_log
fill 338 195 558 338 198 558 minecraft:green_terracotta
setblock 338 195 597 minecraft:oak_log
fill 338 195 598 341 195 598 minecraft:green_terracotta
fill 339 195 597 340 195 597 minecraft:green_terracotta
fill 340 195 573 340 196 573 minecraft:glowstone
setblock 342 195 598 minecraft:oak_log
setblock 345 195 558 minecraft:oak_leaves[persistent=true]
fill 350 195 558 351 195 558 minecraft:green_terracotta
setblock 352 195 558 minecraft:oak_log
setblock 352 195 598 minecraft:oak_log
fill 353 195 558 355 195 559 minecraft:green_terracotta
fill 353 195 598 356 195 598 minecraft:green_terracotta
setblock 355 195 560 minecraft:oak_log
setblock 356 195 558 minecraft:green_terracotta
setblock 356 195 559 minecraft:oak_log
fill 356 195 560 356 198 560 minecraft:green_terracotta
setblock 357 195 558 minecraft:oak_log
fill 357 195 559 360 195 559 minecraft:green_terracotta
setblock 357 195 598 minecraft:oak_log
fill 358 195 558 361 195 558 minecraft:green_terracotta
fill 358 195 598 361 195 598 minecraft:green_terracotta
setblock 360 195 560 minecraft:oak_log
fill 360 195 561 360 195 562 minecraft:dark_oak_log
fill 360 195 564 360 195 565 minecraft:dark_oak_log
setblock 361 195 559 minecraft:oak_log
fill 361 195 560 364 195 560 minecraft:dark_oak_log
fill 361 195 566 364 195 566 minecraft:dark_oak_log
setblock 362 195 558 minecraft:oak_log
fill 362 195 559 362 198 559 minecraft:green_terracotta
setblock 362 195 598 minecraft:oak_log
fill 363 195 558 363 198 558 minecraft:green_terracotta
fill 363 195 598 363 198 598 minecraft:green_terracotta
setblock 365 195 561 minecraft:dark_oak_log
setblock 365 195 565 minecraft:dark_oak_log
setblock 366 195 559 minecraft:oak_log
fill 366 195 562 366 195 564 minecraft:dark_oak_log
setblock 367 195 558 minecraft:oak_log
fill 367 195 559 368 197 559 minecraft:green_terracotta
setblock 367 195 598 minecraft:oak_log
fill 368 195 558 368 198 558 minecraft:green_terracotta
fill 368 195 598 368 198 598 minecraft:green_terracotta
setblock 369 195 560 minecraft:green_terracotta
setblock 370 195 560 minecraft:oak_log
fill 370 195 561 370 198 561 minecraft:green_terracotta
fill 370 195 563 370 196 563 minecraft:green_terracotta
setblock 370 195 577 minecraft:oak_leaves[persistent=true]
setblock 370 195 595 minecraft:oak_log
fill 370 195 596 370 198 596 minecraft:green_terracotta
setblock 330 196 558 minecraft:green_terracotta
setblock 330 196 559 minecraft:oak_log
fill 330 196 560 330 198 561 minecraft:green_terracotta
fill 330 196 577 330 196 578 minecraft:green_terracotta
setblock 330 196 579 minecraft:oak_log
fill 330 196 580 331 198 580 minecraft:green_terracotta
setblock 330 196 584 minecraft:oak_log
fill 330 196 585 330 198 586 minecraft:green_terracotta
fill 330 196 592 330 196 593 minecraft:green_terracotta
setblock 330 196 594 minecraft:oak_log
fill 330 196 595 330 199 595 minecraft:green_terracotta
setblock 331 196 558 minecraft:oak_log
fill 331 196 559 334 196 559 minecraft:green_terracotta
fill 331 196 579 331 199 579 minecraft:green_terracotta
fill 331 196 581 331 196 582 minecraft:green_terracotta
setblock 331 196 583 minecraft:oak_log
setblock 331 196 597 minecraft:green_terracotta
setblock 331 196 598 minecraft:oak_log
fill 332 196 558 335 196 558 minecraft:green_terracotta
setblock 332 196 597 minecraft:oak_log
fill 332 196 598 335 196 598 minecraft:green_terracotta
fill 333 196 571 336 233 574 minecraft:oak_log
fill 333 196 597 336 196 597 minecraft:green_terracotta
fill 334 196 570 336 233 570 minecraft:oak_log
fill 334 196 596 335 196 596 minecraft:green_terracotta
setblock 335 196 559 minecraft:oak_log
setblock 336 196 558 minecraft:oak_log
fill 336 196 559 336 199 559 minecraft:green_terracotta
setblock 336 196 598 minecraft:oak_log
fill 337 196 558 337 199 558 minecraft:green_terracotta
fill 337 196 571 337 233 573 minecraft:oak_log
setblock 337 196 597 minecraft:oak_log
fill 337 196 598 340 196 598 minecraft:green_terracotta
fill 338 196 597 339 196 597 minecraft:green_terracotta
setblock 341 196 598 minecraft:oak_log
fill 342 196 598 342 197 598 minecraft:oak_leaves[persistent=true]
setblock 350 196 558 minecraft:green_terracotta
setblock 351 196 558 minecraft:oak_log
fill 352 196 558 354 196 559 minecraft:green_terracotta
fill 352 196 598 355 196 598 minecraft:green_terracotta
setblock 354 196 560 minecraft:oak_log
setblock 355 196 558 minecraft:green_terracotta
setblock 355 196 559 minecraft:oak_log
fill 355 196 560 355 199 560 minecraft:green_terracotta
setblock 356 196 558 minecraft:oak_log
fill 356 196 559 359 196 559 minecraft:green_terracotta
setblock 356 196 598 minecraft:oak_log
fill 357 196 558 360 196 558 minecraft:green_terracotta
fill 357 196 598 360 196 598 minecraft:green_terracotta
setblock 358 196 560 minecraft:green_terracotta
setblock 359 196 560 minecraft:oak_log
setblock 360 196 559 minecraft:oak_log
fill 360 196 560 360 199 560 minecraft:green_terracotta
setblock 361 196 558 minecraft:oak_log
fill 361 196 559 361 199 559 minecraft:green_terracotta
setblock 361 196 598 minecraft:oak_log
fill 362 196 558 362 199 558 minecraft:green_terracotta
fill 362 196 598 362 199 598 minecraft:green_terracotta
setblock 365 196 559 minecraft:oak_log
setblock 366 196 558 minecraft:oak_log
fill 366 196 559 366 199 559 minecraft:green_terracotta
setblock 366 196 598 minecraft:oak_log
fill 367 196 558 367 199 558 minecraft:green_terracotta
fill 367 196 598 367 199 598 minecraft:green_terracotta
setblock 369 196 560 minecraft:oak_log
fill 369 196 561 369 199 561 minecraft:green_terracotta
setblock 370 196 559 minecraft:oak_log
fill 370 196 560 370 199 560 minecraft:green_terracotta
setblock 370 196 564 minecraft:oak_log
setblock 370 196 571 minecraft:oak_leaves[persistent=true]
setblock 370 196 590 minecraft:oak_leaves[persistent=true]
fill 370 196 595 370 199 595 minecraft:green_terracotta
setblock 330 197 558 minecraft:oak_log
fill 330 197 559 333 197 559 minecraft:green_terracotta
setblock 330 197 562 minecraft:green_terracotta
setblock 330 197 563 minecraft:oak_log
setblock 330 197 566 minecraft:oak_leaves[persistent=true]
fill 330 197 572 330 198 572 minecraft:oak_leaves[persistent=true]
setblock 330 197 577 minecraft:green_terracotta
setblock 330 197 578 minecraft:oak_log
fill 330 197 579 330 200 579 minecraft:green_terracotta
fill 330 197 581 330 197 582 minecraft:green_terracotta
setblock 330 197 583 minecraft:oak_log
fill 330 197 584 332 198 584 minecraft:green_terracotta
setblock 330 197 587 minecraft:green_terracotta
setblock 330 197 588 minecraft:oak_log
fill 330 197 589 330 197 592 minecraft:green_terracotta
setblock 330 197 593 minecraft:oak_log
fill 330 197 594 331 199 594 minecraft:green_terracotta
fill 330 197 596 330 197 597 minecraft:green_terracotta
setblock 330 197 598 minecraft:oak_log
fill 331 197 558 334 197 558 minecraft:green_terracotta
fill 331 197 560 331 197 561 minecraft:green_terracotta
fill 331 197 578 331 200 578 minecraft:green_terracotta
setblock 331 197 581 minecraft:green_terracotta
setblock 331 197 582 minecraft:oak_log
fill 331 197 583 332 199 583 minecraft:green_terracotta
fill 331 197 585 331 197 586 minecraft:green_terracotta
setblock 331 197 587 minecraft:oak_log
setblock 331 197 597 minecraft:oak_log
fill 331 197 598 334 197 598 minecraft:green_terracotta
fill 332 197 570 332 198 574 minecraft:dark_oak_log
setblock 332 197 580 minecraft:green_terracotta
setblock 332 197 581 minecraft:oak_log
fill 332 197 582 332 200 582 minecraft:green_terracotta
fill 332 197 597 335 197 597 minecraft:green_terracotta
fill 333 197 569 333 198 570 minecraft:dark_oak_log
fill 333 197 575 336 198 575 minecraft:dark_oak_log
setblock 334 197 559 minecraft:oak_log
fill 334 197 569 336 198 569 minecraft:dark_oak_log
setblock 334 197 596 minecraft:green_terracotta
setblock 335 197 558 minecraft:oak_log
fill 335 197 559 335 200 559 minecraft:green_terracotta
setblock 335 197 598 minecraft:oak_log
fill 336 197 558 336 200 558 minecraft:green_terracotta
setblock 336 197 597 minecraft:oak_log
fill 336 197 598 339 197 598 minecraft:green_terracotta
fill 337 197 570 337 198 570 minecraft:dark_oak_log
fill 337 197 574 337 198 574 minecraft:dark_oak_log
fill 337 197 597 338 198 597 minecraft:green_terracotta
setblock 338 197 559 minecraft:green_terracotta
fill 338 197 571 338 198 573 minecraft:dark_oak_log
setblock 340 197 558 minecraft:oak_log
fill 340 197 573 340 200 573 minecraft:dark_oak_log
setblock 340 197 598 minecraft:oak_log
setblock 341 197 598 minecraft:green_terracotta
setblock 348 197 598 minecraft:oak_leaves[persistent=true]
setblock 349 197 558 minecraft:green_terracotta
setblock 350 197 558 minecraft:oak_log
fill 351 197 558 353 197 559 minecraft:green_terracotta
fill 351 197 598 354 197 598 minecraft:green_terracotta
setblock 353 197 560 minecraft:oak_log
setblock 354 197 558 minecraft:green_terracotta
setblock 354 197 559 minecraft:oak_log
fill 354 197 560 354 200 560 minecraft:green_terracotta
setblock 355 197 558 minecraft:oak_log
fill 355 197 559 358 197 559 minecraft:green_terracotta
setblock 355 197 598 minecraft:oak_log
fill 356 197 558 359 197 558 minecraft:green_terracotta
fill 356 197 598 359 197 598 minecraft:green_terracotta
setblock 358 197 560 minecraft:oak_log
setblock 359 197 559 minecraft:oak_log
fill 359 197 560 359 200 560 minecraft:green_terracotta
setblock 360 197 558 minecraft:oak_log
fill 360 197 559 360 200 559 minecraft:green_terracotta
setblock 360 197 598 minecraft:oak_log
fill 361 197 558 361 200 558 minecraft:green_terracotta
fill 361 197 560 361 198 560 minecraft:green_terracotta
fill 361 197 598 361 200 598 minecraft:green_terracotta
setblock 364 197 559 minecraft:oak_log
setblock 365 197 558 minecraft:oak_log
fill 365 197 559 365 200 559 minecraft:green_terracotta
setblock 365 197 598 minecraft:oak_log
fill 366 197 558 366 200 558 minecraft:green_terracotta
fill 366 197 598 366 200 598 minecraft:green_terracotta
setblock 369 197 558 minecraft:green_terracotta
setblock 369 197 559 minecraft:oak_log
fill 369 197 560 369 200 560 minecraft:green_terracotta
fill 369 197 562 369 198 562 minecraft:green_terracotta
setblock 370 197 558 minecraft:oak_log
fill 370 197 559 370 200 559 minecraft:green_terracotta
setblock 370 197 563 minecraft:oak_log
fill 370 197 564 370 199 565 minecraft:green_terracotta
fill 370 197 579 370 197 582 minecraft:green_terracotta
setblock 370 197 583 minecraft:oak_log
setblock 370 197 584 minecraft:oak_leaves[persistent=true]
setblock 370 197 598 minecraft:oak_log
fill 330 198 558 332 198 559 minecraft:green_terracotta
setblock 330 198 562 minecraft:oak_log
fill 330 198 563 330 200 564 minecraft:green_terracotta
setblock 330 198 576 minecraft:green_terracotta
setblock 330 198 577 minecraft:oak_log
fill 330 198 578 330 201 578 minecraft:green_terracotta
setblock 330 198 581 minecraft:green_terracotta
setblock 330 198 582 minecraft:oak_log
fill 330 198 583 330 201 583 minecraft:green_terracotta
setblock 330 198 587 minecraft:oak_log
fill 330 198 588 330 198 591 minecraft:green_terracotta
setblock 330 198 592 minecraft:oak_log
fill 330 198 593 331 200 593 minecraft:green_terracotta
setblock 330 198 596 minecraft:green_terracotta
setblock 330 198 597 minecraft:oak_log
fill 330 198 598 333 198 598 minecraft:green_terracotta
setblock 331 198 560 minecraft:green_terracotta
setblock 331 198 561 minecraft:oak_log
fill 331 198 562 331 201 562 minecraft:green_terracotta
fill 331 198 570 331 198 574 minecraft:dark_oak_log
fill 331 198 577 331 201 577 minecraft:green_terracotta
setblock 331 198 581 minecraft:oak_log
fill 331 198 582 331 201 582 minecraft:green_terracotta
setblock 331 198 585 minecraft:green_terracotta
setblock 331 198 586 minecraft:oak_log
fill 331 198 587 331 198 590 minecraft:green_terracotta
setblock 331 198 591 minecraft:oak_log
fill 331 198 592 331 201 592 minecraft:green_terracotta
setblock 331 198 596 minecraft:oak_log
fill 331 198 597 334 198 597 minecraft:green_terracotta
setblock 332 198 569 minecraft:dark_oak_log
setblock 332 198 575 minecraft:dark_oak_log
setblock 332 198 579 minecraft:green_terracotta
setblock 332 198 580 minecraft:oak_log
fill 332 198 581 333 200 581 minecraft:green_terracotta
setblock 332 198 585 minecraft:oak_log
fill 332 198 586 332 200 587 minecraft:green_terracotta
setblock 333 198 558 minecraft:green_terracotta
setblock 333 198 559 minecraft:oak_log
fill 333 198 568 336 198 568 minecraft:dark_oak_log
fill 333 198 576 337 198 576 minecraft:dark_oak_log
fill 333 198 579 333 199 579 minecraft:jungle_log
fill 333 198 582 333 198 583 minecraft:green_terracotta
fill 333 198 596 333 199 596 minecraft:green_terracotta
setblock 334 198 558 minecraft:oak_log
fill 334 198 559 334 201 559 minecraft:green_terracotta
setblock 334 198 598 minecraft:oak_log
fill 335 198 558 335 201 558 minecraft:green_terracotta
setblock 335 198 597 minecraft:oak_log
fill 335 198 598 338 198 598 minecraft:green_terracotta
fill 336 198 597 336 201 597 minecraft:green_terracotta
fill 337 198 569 338 198 569 minecraft:dark_oak_log
fill 337 198 575 338 198 575 minecraft:dark_oak_log
fill 337 198 577 338 199 579 minecraft:oak_log
setblock 338 198 559 minecraft:oak_log
setblock 338 198 570 minecraft:dark_oak_log
fill 338 198 574 340 198 574 minecraft:dark_oak_log
setblock 339 198 558 minecraft:oak_log
fill 339 198 571 339 198 573 minecraft:dark_oak_log
fill 339 198 577 339 199 577 minecraft:oak_log
fill 339 198 578 343 198 580 minecraft:jungle_log
setblock 339 198 598 minecraft:oak_log
fill 340 198 558 340 200 558 minecraft:green_terracotta
setblock 340 198 598 minecraft:green_terracotta
fill 344 198 578 349 198 580 minecraft:jungle_leaves[persistent=true]
fill 345 198 576 349 203 577 minecraft:jungle_leaves[persistent=true]
fill 345 198 581 349 203 582 minecraft:jungle_leaves[persistent=true]
setblock 346 198 558 minecraft:oak_leaves[persistent=true]
fill 346 198 575 354 200 575 minecraft:jungle_leaves[persistent=true]
fill 346 198 583 354 200 583 minecraft:jungle_leaves[persistent=true]
setblock 348 198 558 minecraft:green_terracotta
fill 348 198 574 352 205 574 minecraft:jungle_leaves[persistent=true]
fill 348 198 584 352 205 584 minecraft:jungle_leaves[persistent=true]
setblock 349 198 558 minecraft:oak_log
fill 350 198 558 352 198 559 minecraft:green_terracotta
fill 350 198 576 350 202 576 minecraft:jungle_leaves[persistent=true]
fill 350 198 582 350 202 582 minecraft:jungle_leaves[persistent=true]
setblock 351 198 560 minecraft:green_terracotta
fill 351 198 579 351 199 579 minecraft:jungle_log
fill 351 198 598 353 198 598 minecraft:green_terracotta
setblock 352 198 560 minecraft:oak_log
setblock 353 198 558 minecraft:green_terracotta
setblock 353 198 559 minecraft:oak_log
fill 353 198 560 353 201 560 minecraft:green_terracotta
setblock 354 198 558 minecraft:oak_log
fill 354 198 559 357 198 559 minecraft:green_terracotta
fill 354 198 561 355 198 561 minecraft:green_terracotta
setblock 354 198 598 minecraft:oak_log
fill 355 198 558 358 198 558 minecraft:green_terracotta
fill 355 198 598 358 198 598 minecraft:green_terracotta
setblock 356 198 561 minecraft:oak_log
setblock 357 198 560 minecraft:oak_log
fill 357 198 561 357 201 561 minecraft:green_terracotta
setblock 358 198 559 minecraft:oak_log
fill 358 198 560 358 201 560 minecraft:green_terracotta
setblock 359 198 558 minecraft:oak_log
fill 359 198 559 359 201 559 minecraft:green_terracotta
setblock 359 198 598 minecraft:oak_log
fill 360 198 558 360 201 558 minecraft:green_terracotta
fill 360 198 598 360 201 598 minecraft:green_terracotta
setblock 363 198 559 minecraft:oak_log
setblock 364 198 558 minecraft:oak_log
fill 364 198 559 364 201 559 minecraft:green_terracotta
setblock 364 198 598 minecraft:oak_log
fill 365 198 558 365 201 558 minecraft:green_terracotta
fill 365 198 598 365 201 598 minecraft:green_terracotta
setblock 367 198 559 minecraft:green_terracotta
setblock 368 198 559 minecraft:oak_log
setblock 369 198 558 minecraft:oak_log
fill 369 198 559 369 201 559 minecraft:green_terracotta
setblock 369 198 563 minecraft:oak_log
setblock 369 198 597 minecraft:green_terracotta
setblock 369 198 598 minecraft:oak_log
fill 370 198 558 370 201 558 minecraft:green_terracotta
setblock 370 198 562 minecraft:oak_log
fill 370 198 563 370 201 563 minecraft:green_terracotta
setblock 370 198 566 minecraft:green_terracotta
fill 370 198 578 370 198 581 minecraft:green_terracotta
setblock 370 198 582 minecraft:oak_log
fill 370 198 583 370 198 586 minecraft:green_terracotta
setblock 370 198 587 minecraft:oak_log
fill 370 198 593 370 200 594 minecraft:green_terracotta
setblock 370 198 597 minecraft:oak_log
fill 370 198 598 370 201 598 minecraft:green_terracotta
fill 330 199 558 330 199 560 minecraft:green_terracotta
setblock 330 199 561 minecraft:oak_log
fill 330 199 562 330 202 562 minecraft:green_terracotta
setblock 330 199 565 minecraft:green_terracotta
setblock 330 199 575 minecraft:green_terracotta
setblock 330 199 576 minecraft:oak_log
fill 330 199 577 330 202 577 minecraft:green_terracotta
setblock 330 199 580 minecraft:green_terracotta
setblock 330 199 581 minecraft:oak_log
fill 330 199 582 330 202 582 minecraft:green_terracotta
fill 330 199 584 330 199 585 minecraft:green_terracotta
setblock 330 199 586 minecraft:oak_log
fill 330 199 587 330 199 590 minecraft:green_terracotta
setblock 330 199 591 minecraft:oak_log
fill 330 199 592 330 202 592 minecraft:green_terracotta
setblock 330 199 596 minecraft:oak_log
fill 330 199 597 332 199 598 minecraft:green_terracotta
fill 331 199 558 331 199 559 minecraft:green_terracotta
setblock 331 199 560 minecraft:oak_log
fill 331 199 561 331 202 561 minecraft:green_terracotta
fill 331 199 563 331 200 563 minecraft:green_terracotta
setblock 331 199 580 minecraft:oak_log
fill 331 199 581 331 202 581 minecraft:green_terracotta
setblock 331 199 584 minecraft:green_terracotta
setblock 331 199 585 minecraft:oak_log
fill 331 199 586 331 199 589 minecraft:green_terracotta
setblock 331 199 590 minecraft:oak_log
fill 331 199 591 331 202 591 minecraft:green_terracotta
setblock 331 199 595 minecraft:oak_log
fill 331 199 596 331 202 596 minecraft:green_terracotta
setblock 332 199 558 minecraft:green_terracotta
setblock 332 199 559 minecraft:oak_log
fill 332 199 560 334 200 560 minecraft:green_terracotta
setblock 332 199 578 minecraft:green_terracotta
setblock 332 199 579 minecraft:oak_log
fill 332 199 580 333 201 580 minecraft:green_terracotta
schedule function dropper:buildpart/139_6 1t
