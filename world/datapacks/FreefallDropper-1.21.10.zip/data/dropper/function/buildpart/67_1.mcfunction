setblock 340 121 302 minecraft:light[level=15]
setblock 340 121 310 minecraft:light[level=15]
setblock 348 121 278 minecraft:light[level=15]
setblock 348 121 286 minecraft:light[level=15]
setblock 348 121 294 minecraft:light[level=15]
setblock 348 121 302 minecraft:light[level=15]
setblock 348 121 310 minecraft:light[level=15]
setblock 350 121 317 minecraft:white_wool
fill 351 121 317 353 124 317 minecraft:white_concrete
setblock 356 121 278 minecraft:light[level=15]
setblock 356 121 286 minecraft:light[level=15]
setblock 356 121 294 minecraft:light[level=15]
setblock 356 121 302 minecraft:light[level=15]
setblock 356 121 310 minecraft:light[level=15]
setblock 364 121 278 minecraft:light[level=15]
setblock 364 121 286 minecraft:light[level=15]
setblock 364 121 294 minecraft:light[level=15]
setblock 364 121 302 minecraft:light[level=15]
setblock 364 121 310 minecraft:light[level=15]
fill 371 121 292 371 128 292 minecraft:white_concrete
fill 350 122 317 350 125 317 minecraft:white_concrete
setblock 329 123 280 minecraft:white_wool
fill 329 123 281 329 128 282 minecraft:white_concrete
fill 329 123 311 329 128 311 minecraft:white_concrete
setblock 329 123 312 minecraft:white_wool
setblock 362 123 275 minecraft:white_wool
fill 329 124 280 329 128 280 minecraft:white_concrete
fill 329 124 312 329 128 312 minecraft:white_concrete
setblock 348 124 275 minecraft:white_wool
fill 349 124 275 349 126 275 minecraft:white_concrete
fill 359 124 275 359 128 275 minecraft:white_concrete
setblock 360 124 275 minecraft:white_wool
fill 362 124 275 362 128 275 minecraft:white_concrete
setblock 371 124 305 minecraft:white_wool
fill 371 124 306 371 128 307 minecraft:white_concrete
fill 329 125 298 329 125 300 minecraft:white_concrete
setblock 329 125 301 minecraft:light_blue_terracotta
setblock 329 125 302 minecraft:white_concrete
setblock 329 125 303 minecraft:light_blue_terracotta
setblock 329 125 306 minecraft:light_blue_terracotta
setblock 332 125 278 minecraft:light[level=12]
setblock 332 125 285 minecraft:light[level=12]
setblock 332 125 292 minecraft:light[level=12]
setblock 332 125 299 minecraft:light[level=12]
setblock 332 125 306 minecraft:light[level=12]
setblock 332 125 313 minecraft:light[level=12]
setblock 334 125 317 minecraft:light_blue_terracotta
fill 337 125 275 337 126 275 minecraft:light_blue_terracotta
fill 338 125 275 338 128 275 minecraft:white_concrete
setblock 339 125 278 minecraft:light[level=12]
setblock 339 125 285 minecraft:light[level=12]
setblock 339 125 292 minecraft:light[level=12]
setblock 339 125 299 minecraft:light[level=12]
setblock 339 125 306 minecraft:light[level=12]
setblock 339 125 313 minecraft:light[level=12]
setblock 346 125 278 minecraft:light[level=12]
setblock 346 125 285 minecraft:light[level=12]
setblock 346 125 299 minecraft:light[level=12]
setblock 346 125 306 minecraft:light[level=12]
setblock 346 125 313 minecraft:light[level=12]
fill 348 125 275 348 128 275 minecraft:white_concrete
setblock 351 125 275 minecraft:light_blue_terracotta
setblock 351 125 317 minecraft:light_blue_terracotta
setblock 352 125 317 minecraft:white_concrete
setblock 353 125 278 minecraft:light[level=12]
setblock 353 125 285 minecraft:light[level=12]
setblock 353 125 292 minecraft:light[level=12]
setblock 353 125 299 minecraft:light[level=12]
setblock 353 125 306 minecraft:light[level=12]
setblock 353 125 313 minecraft:light[level=12]
setblock 353 125 317 minecraft:light_blue_terracotta
fill 354 125 317 354 126 317 minecraft:white_concrete
setblock 355 125 317 minecraft:light_blue_terracotta
fill 356 125 317 356 128 317 minecraft:white_concrete
setblock 358 125 317 minecraft:light_blue_terracotta
fill 360 125 275 360 126 275 minecraft:white_concrete
setblock 360 125 278 minecraft:light[level=12]
setblock 360 125 285 minecraft:light[level=12]
setblock 360 125 292 minecraft:light[level=12]
setblock 360 125 299 minecraft:light[level=12]
setblock 360 125 306 minecraft:light[level=12]
setblock 360 125 313 minecraft:light[level=12]
setblock 360 125 317 minecraft:white_wool
fill 361 125 317 361 126 317 minecraft:light_blue_terracotta
setblock 366 125 275 minecraft:light_blue_terracotta
fill 367 125 275 368 125 275 minecraft:white_concrete
setblock 367 125 278 minecraft:light[level=12]
setblock 367 125 285 minecraft:light[level=12]
setblock 367 125 292 minecraft:light[level=12]
setblock 367 125 299 minecraft:light[level=12]
setblock 367 125 306 minecraft:light[level=12]
setblock 367 125 313 minecraft:light[level=12]
setblock 367 125 317 minecraft:light_blue_terracotta
setblock 371 125 293 minecraft:light_blue_terracotta
fill 371 125 305 371 130 305 minecraft:white_concrete
setblock 329 126 283 minecraft:light_blue_terracotta
setblock 329 126 285 minecraft:light_blue_terracotta
setblock 329 126 295 minecraft:light_blue_terracotta
setblock 329 126 298 minecraft:light_blue_terracotta
fill 329 126 299 329 128 301 minecraft:white_concrete
setblock 329 126 302 minecraft:light_blue_terracotta
fill 329 126 303 329 128 303 minecraft:white_concrete
fill 329 126 306 329 128 306 minecraft:white_concrete
fill 330 126 275 330 128 275 minecraft:white_concrete
setblock 331 126 275 minecraft:light_blue_terracotta
fill 332 126 275 333 128 275 minecraft:white_concrete
setblock 334 126 275 minecraft:light_blue_terracotta
fill 334 126 317 334 128 317 minecraft:white_concrete
fill 335 126 275 335 128 275 minecraft:white_concrete
fill 335 126 289 336 128 291 minecraft:red_concrete
fill 335 126 292 336 128 293 minecraft:purple_concrete
fill 336 126 286 336 128 288 minecraft:red_concrete
fill 336 126 294 336 128 296 minecraft:purple_concrete
fill 337 126 285 338 128 285 minecraft:orange_concrete
fill 337 126 286 337 128 287 minecraft:red_concrete
fill 337 126 288 342 126 294 minecraft:white_stained_glass
fill 337 126 295 337 128 296 minecraft:purple_concrete
fill 337 126 297 338 128 297 minecraft:light_blue_concrete
fill 338 126 284 339 128 284 minecraft:orange_concrete
fill 338 126 286 354 126 287 minecraft:white_stained_glass
fill 338 126 295 354 126 296 minecraft:white_stained_glass
fill 338 126 298 339 128 298 minecraft:light_blue_concrete
fill 339 126 283 340 128 283 minecraft:orange_concrete
fill 339 126 285 353 127 285 minecraft:white_stained_glass
fill 339 126 297 353 127 297 minecraft:white_stained_glass
fill 339 126 299 340 128 299 minecraft:light_blue_concrete
fill 340 126 282 340 128 282 minecraft:orange_concrete
fill 340 126 284 352 127 284 minecraft:white_stained_glass
fill 340 126 298 352 127 298 minecraft:white_stained_glass
fill 340 126 300 340 128 300 minecraft:light_blue_concrete
fill 341 126 281 342 128 282 minecraft:yellow_concrete
fill 341 126 283 351 127 283 minecraft:white_stained_glass
fill 341 126 299 351 127 299 minecraft:white_stained_glass
fill 341 126 300 342 128 301 minecraft:lime_concrete
fill 343 126 281 345 128 281 minecraft:yellow_concrete
fill 343 126 282 349 127 282 minecraft:white_stained_glass
fill 343 126 288 343 126 290 minecraft:white_stained_glass
fill 343 126 292 343 126 294 minecraft:white_stained_glass
fill 343 126 300 349 127 300 minecraft:white_stained_glass
fill 343 126 301 346 128 301 minecraft:lime_concrete
fill 344 126 280 345 128 280 minecraft:yellow_concrete
fill 344 126 288 345 126 288 minecraft:white_stained_glass
fill 344 126 294 345 126 294 minecraft:white_stained_glass
fill 344 126 302 346 128 302 minecraft:lime_concrete
fill 346 126 280 348 128 281 minecraft:lime_concrete
fill 347 126 288 355 126 288 minecraft:white_stained_glass
fill 347 126 294 355 126 294 minecraft:white_stained_glass
fill 347 126 301 348 128 302 minecraft:yellow_concrete
fill 349 126 281 351 128 281 minecraft:lime_concrete
fill 349 126 289 355 126 290 minecraft:white_stained_glass
fill 349 126 292 355 126 293 minecraft:white_stained_glass
fill 349 126 301 351 128 301 minecraft:yellow_concrete
setblock 350 126 275 minecraft:light_blue_terracotta
fill 350 126 282 351 128 282 minecraft:lime_concrete
fill 350 126 291 355 126 291 minecraft:white_stained_glass
fill 350 126 300 351 128 300 minecraft:yellow_concrete
fill 350 126 317 350 127 317 minecraft:light_blue_terracotta
fill 351 126 275 351 128 275 minecraft:white_concrete
fill 351 126 317 351 128 317 minecraft:white_concrete
fill 352 126 282 352 128 283 minecraft:light_blue_concrete
fill 352 126 299 352 128 300 minecraft:orange_concrete
setblock 352 126 317 minecraft:light_blue_terracotta
fill 353 126 283 353 128 284 minecraft:light_blue_concrete
fill 353 126 298 353 128 299 minecraft:orange_concrete
fill 353 126 317 353 128 317 minecraft:white_concrete
fill 354 126 284 354 128 285 minecraft:light_blue_concrete
fill 354 126 297 354 128 298 minecraft:orange_concrete
fill 355 126 285 355 128 285 minecraft:light_blue_concrete
fill 355 126 286 356 128 287 minecraft:purple_concrete
fill 355 126 295 356 128 296 minecraft:red_concrete
fill 355 126 297 355 128 297 minecraft:orange_concrete
setblock 355 126 317 minecraft:white_concrete
fill 356 126 288 356 128 290 minecraft:purple_concrete
fill 356 126 291 356 128 294 minecraft:red_concrete
fill 357 126 289 357 128 290 minecraft:purple_concrete
fill 357 126 291 357 128 293 minecraft:red_concrete
fill 358 126 317 358 128 317 minecraft:white_concrete
fill 360 126 317 360 128 317 minecraft:white_concrete
setblock 362 126 317 minecraft:light_blue_terracotta
setblock 365 126 275 minecraft:light_blue_terracotta
fill 366 126 275 366 128 275 minecraft:white_concrete
setblock 367 126 275 minecraft:light_blue_terracotta
fill 367 126 317 367 128 317 minecraft:white_concrete
fill 368 126 275 368 128 275 minecraft:white_concrete
setblock 368 126 317 minecraft:light_blue_terracotta
fill 370 126 275 370 128 275 minecraft:white_concrete
fill 371 126 275 371 126 276 minecraft:light_blue_terracotta
setblock 371 126 278 minecraft:light_blue_terracotta
fill 371 126 293 371 128 293 minecraft:white_concrete
setblock 371 126 294 minecraft:light_blue_terracotta
setblock 371 126 314 minecraft:white_wool
setblock 371 126 317 minecraft:light_blue_terracotta
fill 329 127 283 329 128 283 minecraft:white_concrete
fill 329 127 285 329 130 285 minecraft:white_concrete
fill 329 127 295 329 128 295 minecraft:white_concrete
setblock 329 127 297 minecraft:light_blue_terracotta
fill 329 127 298 329 128 298 minecraft:white_concrete
fill 329 127 302 329 128 302 minecraft:white_concrete
setblock 329 127 310 minecraft:light_blue_terracotta
setblock 329 127 313 minecraft:light_blue_terracotta
fill 330 127 276 330 127 277 minecraft:white_wool
setblock 330 127 278 minecraft:light_gray_wool
fill 330 127 279 330 127 281 minecraft:white_wool
setblock 330 127 282 minecraft:light_gray_wool
fill 330 127 283 330 127 285 minecraft:white_wool
setblock 330 127 286 minecraft:light_gray_wool
fill 330 127 287 330 127 289 minecraft:white_wool
setblock 330 127 290 minecraft:light_gray_wool
fill 330 127 291 330 127 293 minecraft:white_wool
setblock 330 127 294 minecraft:light_gray_wool
fill 330 127 295 330 127 297 minecraft:white_wool
setblock 330 127 298 minecraft:light_gray_wool
fill 330 127 299 330 127 301 minecraft:white_wool
setblock 330 127 302 minecraft:light_gray_wool
fill 330 127 303 330 127 305 minecraft:white_wool
setblock 330 127 306 minecraft:light_gray_wool
fill 330 127 307 330 127 309 minecraft:white_wool
setblock 330 127 310 minecraft:light_gray_wool
fill 330 127 311 330 127 313 minecraft:white_wool
setblock 330 127 314 minecraft:light_gray_wool
fill 330 127 315 331 127 316 minecraft:white_wool
fill 331 127 275 331 128 275 minecraft:white_concrete
setblock 331 127 276 minecraft:white_wool
setblock 331 127 277 minecraft:light_gray_wool
fill 331 127 278 331 127 280 minecraft:white_wool
setblock 331 127 281 minecraft:light_gray_wool
fill 331 127 282 331 127 284 minecraft:white_wool
setblock 331 127 285 minecraft:light_gray_wool
fill 331 127 286 331 127 288 minecraft:white_wool
setblock 331 127 289 minecraft:light_gray_wool
fill 331 127 290 331 127 292 minecraft:white_wool
setblock 331 127 293 minecraft:light_gray_wool
fill 331 127 294 331 127 296 minecraft:white_wool
setblock 331 127 297 minecraft:light_gray_wool
fill 331 127 298 331 127 300 minecraft:white_wool
setblock 331 127 301 minecraft:light_gray_wool
fill 331 127 302 331 127 304 minecraft:white_wool
setblock 331 127 305 minecraft:light_gray_wool
fill 331 127 306 331 127 308 minecraft:white_wool
setblock 331 127 309 minecraft:light_gray_wool
fill 331 127 310 331 127 312 minecraft:white_wool
setblock 331 127 313 minecraft:light_gray_wool
fill 331 127 314 333 127 314 minecraft:white_wool
setblock 332 127 276 minecraft:light_gray_wool
fill 332 127 277 332 127 279 minecraft:white_wool
setblock 332 127 280 minecraft:light_gray_wool
fill 332 127 281 332 127 283 minecraft:white_wool
setblock 332 127 284 minecraft:light_gray_wool
fill 332 127 285 332 127 287 minecraft:white_wool
setblock 332 127 288 minecraft:light_gray_wool
fill 332 127 289 332 127 291 minecraft:white_wool
setblock 332 127 292 minecraft:light_gray_wool
fill 332 127 293 332 127 295 minecraft:white_wool
setblock 332 127 296 minecraft:light_gray_wool
fill 332 127 297 332 127 299 minecraft:white_wool
setblock 332 127 300 minecraft:light_gray_wool
fill 332 127 301 332 127 303 minecraft:white_wool
setblock 332 127 304 minecraft:light_gray_wool
fill 332 127 305 332 127 307 minecraft:white_wool
setblock 332 127 308 minecraft:light_gray_wool
fill 332 127 309 332 127 311 minecraft:white_wool
setblock 332 127 312 minecraft:light_gray_wool
fill 332 127 313 334 127 313 minecraft:white_wool
setblock 332 127 315 minecraft:white_wool
setblock 332 127 316 minecraft:light_gray_wool
fill 333 127 276 333 127 278 minecraft:white_wool
setblock 333 127 279 minecraft:light_gray_wool
fill 333 127 280 333 127 282 minecraft:white_wool
setblock 333 127 283 minecraft:light_gray_wool
fill 333 127 284 333 127 286 minecraft:white_wool
setblock 333 127 287 minecraft:light_gray_wool
fill 333 127 288 333 127 290 minecraft:white_wool
setblock 333 127 291 minecraft:light_gray_wool
fill 333 127 292 333 127 294 minecraft:white_wool
setblock 333 127 295 minecraft:light_gray_wool
fill 333 127 296 333 127 298 minecraft:white_wool
setblock 333 127 299 minecraft:light_gray_wool
fill 333 127 300 333 127 302 minecraft:white_wool
setblock 333 127 303 minecraft:light_gray_wool
fill 333 127 304 333 127 306 minecraft:white_wool
setblock 333 127 307 minecraft:light_gray_wool
fill 333 127 308 333 127 310 minecraft:white_wool
setblock 333 127 311 minecraft:light_gray_wool
fill 333 127 312 335 127 312 minecraft:white_wool
setblock 333 127 315 minecraft:light_gray_wool
fill 333 127 316 335 127 316 minecraft:white_wool
fill 334 127 275 334 128 275 minecraft:white_concrete
fill 334 127 276 334 127 277 minecraft:white_wool
setblock 334 127 278 minecraft:light_gray_wool
fill 334 127 279 334 127 281 minecraft:white_wool
setblock 334 127 282 minecraft:light_gray_wool
fill 334 127 283 334 127 285 minecraft:white_wool
setblock 334 127 286 minecraft:light_gray_wool
fill 334 127 287 334 127 289 minecraft:white_wool
setblock 334 127 290 minecraft:light_gray_wool
fill 334 127 291 334 127 293 minecraft:white_wool
setblock 334 127 294 minecraft:light_gray_wool
fill 334 127 295 334 127 297 minecraft:white_wool
setblock 334 127 298 minecraft:light_gray_wool
fill 334 127 299 334 127 301 minecraft:white_wool
setblock 334 127 302 minecraft:light_gray_wool
fill 334 127 303 334 127 305 minecraft:white_wool
setblock 334 127 306 minecraft:light_gray_wool
fill 334 127 307 334 127 309 minecraft:white_wool
setblock 334 127 310 minecraft:light_gray_wool
fill 334 127 311 336 127 311 minecraft:white_wool
setblock 334 127 314 minecraft:light_gray_wool
fill 334 127 315 336 127 315 minecraft:white_wool
setblock 335 127 276 minecraft:white_wool
setblock 335 127 277 minecraft:light_gray_wool
fill 335 127 278 335 127 280 minecraft:white_wool
setblock 335 127 281 minecraft:light_gray_wool
fill 335 127 282 335 127 284 minecraft:white_wool
setblock 335 127 285 minecraft:light_gray_wool
fill 335 127 286 335 127 287 minecraft:white_wool
setblock 335 127 288 minecraft:red_concrete
setblock 335 127 294 minecraft:purple_concrete
fill 335 127 295 335 127 296 minecraft:white_wool
setblock 335 127 297 minecraft:light_gray_wool
fill 335 127 298 335 127 300 minecraft:white_wool
setblock 335 127 301 minecraft:light_gray_wool
fill 335 127 302 335 127 304 minecraft:white_wool
setblock 335 127 305 minecraft:light_gray_wool
fill 335 127 306 335 127 308 minecraft:white_wool
setblock 335 127 309 minecraft:light_gray_wool
fill 335 127 310 337 127 310 minecraft:white_wool
setblock 335 127 313 minecraft:light_gray_wool
fill 335 127 314 337 127 314 minecraft:white_wool
setblock 336 127 275 minecraft:light_blue_terracotta
setblock 336 127 276 minecraft:light_gray_wool
fill 336 127 277 336 127 279 minecraft:white_wool
setblock 336 127 280 minecraft:light_gray_wool
fill 336 127 281 336 127 283 minecraft:white_wool
setblock 336 127 284 minecraft:light_gray_wool
setblock 336 127 285 minecraft:white_wool
fill 336 127 297 336 127 299 minecraft:white_wool
setblock 336 127 300 minecraft:light_gray_wool
fill 336 127 301 336 127 303 minecraft:white_wool
setblock 336 127 304 minecraft:light_gray_wool
fill 336 127 305 336 127 307 minecraft:white_wool
setblock 336 127 308 minecraft:light_gray_wool
fill 336 127 309 338 127 309 minecraft:white_wool
setblock 336 127 312 minecraft:light_gray_wool
fill 336 127 313 338 127 313 minecraft:white_wool
setblock 336 127 316 minecraft:light_gray_wool
fill 337 127 275 337 128 275 minecraft:white_concrete
fill 337 127 276 337 127 278 minecraft:white_wool
setblock 337 127 279 minecraft:light_gray_wool
fill 337 127 280 337 127 282 minecraft:white_wool
setblock 337 127 283 minecraft:light_gray_wool
setblock 337 127 284 minecraft:orange_concrete
fill 337 127 288 341 127 294 minecraft:white_stained_glass
setblock 337 127 298 minecraft:light_blue_concrete
setblock 337 127 299 minecraft:light_gray_wool
fill 337 127 300 337 127 302 minecraft:white_wool
setblock 337 127 303 minecraft:light_gray_wool
fill 337 127 304 337 127 306 minecraft:white_wool
setblock 337 127 307 minecraft:light_gray_wool
fill 337 127 308 339 127 308 minecraft:white_wool
setblock 337 127 311 minecraft:light_gray_wool
fill 337 127 312 339 127 312 minecraft:white_wool
setblock 337 127 315 minecraft:light_gray_wool
fill 337 127 316 339 127 316 minecraft:white_wool
fill 338 127 276 338 127 277 minecraft:white_wool
setblock 338 127 278 minecraft:light_gray_wool
fill 338 127 279 338 127 281 minecraft:white_wool
setblock 338 127 282 minecraft:light_gray_wool
setblock 338 127 283 minecraft:orange_concrete
fill 338 127 286 344 127 287 minecraft:white_stained_glass
fill 338 127 295 344 127 296 minecraft:white_stained_glass
setblock 338 127 299 minecraft:light_blue_concrete
fill 338 127 300 338 127 301 minecraft:white_wool
setblock 338 127 302 minecraft:light_gray_wool
fill 338 127 303 338 127 305 minecraft:white_wool
setblock 338 127 306 minecraft:light_gray_wool
fill 338 127 307 340 127 307 minecraft:white_wool
setblock 338 127 310 minecraft:light_gray_wool
fill 338 127 311 340 127 311 minecraft:white_wool
setblock 338 127 314 minecraft:light_gray_wool
fill 338 127 315 340 127 315 minecraft:white_wool
setblock 338 127 317 minecraft:light_blue_terracotta
setblock 339 127 276 minecraft:white_wool
setblock 339 127 277 minecraft:light_gray_wool
fill 339 127 278 339 127 280 minecraft:white_wool
setblock 339 127 281 minecraft:light_gray_wool
setblock 339 127 282 minecraft:orange_concrete
setblock 339 127 300 minecraft:light_blue_concrete
setblock 339 127 301 minecraft:light_gray_wool
fill 339 127 302 339 127 304 minecraft:white_wool
setblock 339 127 305 minecraft:light_gray_wool
fill 339 127 306 341 127 306 minecraft:white_wool
setblock 339 127 309 minecraft:light_gray_wool
fill 339 127 310 341 127 310 minecraft:white_wool
setblock 339 127 313 minecraft:light_gray_wool
fill 339 127 314 341 127 314 minecraft:white_wool
setblock 340 127 276 minecraft:light_gray_wool
fill 340 127 277 340 127 279 minecraft:white_wool
setblock 340 127 280 minecraft:light_gray_wool
setblock 340 127 281 minecraft:white_wool
fill 340 127 301 340 127 303 minecraft:white_wool
setblock 340 127 304 minecraft:light_gray_wool
fill 340 127 305 342 127 305 minecraft:white_wool
setblock 340 127 308 minecraft:light_gray_wool
fill 340 127 309 342 127 309 minecraft:white_wool
setblock 340 127 312 minecraft:light_gray_wool
fill 340 127 313 342 127 313 minecraft:white_wool
setblock 340 127 316 minecraft:light_gray_wool
fill 341 127 276 341 127 278 minecraft:white_wool
setblock 341 127 279 minecraft:light_gray_wool
fill 341 127 280 342 127 280 minecraft:white_wool
setblock 341 127 302 minecraft:white_wool
setblock 341 127 303 minecraft:light_gray_wool
fill 341 127 304 343 127 304 minecraft:white_wool
setblock 341 127 307 minecraft:light_gray_wool
fill 341 127 308 343 127 308 minecraft:white_wool
setblock 341 127 311 minecraft:light_gray_wool
fill 341 127 312 343 127 312 minecraft:white_wool
setblock 341 127 315 minecraft:light_gray_wool
fill 341 127 316 343 127 316 minecraft:white_wool
fill 342 127 276 342 127 277 minecraft:white_wool
setblock 342 127 278 minecraft:light_gray_wool
fill 342 127 279 344 127 279 minecraft:white_wool
fill 342 127 288 342 127 289 minecraft:white_stained_glass
fill 342 127 290 342 127 292 minecraft:yellow_concrete
fill 342 127 293 342 127 294 minecraft:white_stained_glass
setblock 342 127 302 minecraft:light_gray_wool
fill 342 127 303 344 127 303 minecraft:white_wool
setblock 342 127 306 minecraft:light_gray_wool
fill 342 127 307 344 127 307 minecraft:white_wool
setblock 342 127 310 minecraft:light_gray_wool
fill 342 127 311 344 127 311 minecraft:white_wool
setblock 342 127 314 minecraft:light_gray_wool
fill 342 127 315 344 127 315 minecraft:white_wool
setblock 343 127 276 minecraft:white_wool
setblock 343 127 277 minecraft:light_gray_wool
fill 343 127 278 345 127 278 minecraft:white_wool
setblock 343 127 280 minecraft:yellow_concrete
fill 343 127 288 343 127 290 minecraft:yellow_concrete
fill 343 127 292 343 127 294 minecraft:yellow_concrete
setblock 343 127 302 minecraft:lime_concrete
setblock 343 127 305 minecraft:light_gray_wool
fill 343 127 306 345 127 306 minecraft:white_wool
setblock 343 127 309 minecraft:light_gray_wool
fill 343 127 310 345 127 310 minecraft:white_wool
setblock 343 127 313 minecraft:light_gray_wool
fill 343 127 314 345 127 314 minecraft:white_wool
setblock 344 127 276 minecraft:light_gray_wool
fill 344 127 277 346 127 277 minecraft:white_wool
fill 344 127 288 345 127 288 minecraft:yellow_concrete
fill 344 127 294 345 127 294 minecraft:yellow_concrete
setblock 344 127 304 minecraft:light_gray_wool
fill 344 127 305 346 127 305 minecraft:white_wool
setblock 344 127 308 minecraft:light_gray_wool
fill 344 127 309 346 127 309 minecraft:white_wool
setblock 344 127 312 minecraft:light_gray_wool
fill 344 127 313 346 127 313 minecraft:white_wool
setblock 344 127 316 minecraft:light_gray_wool
fill 345 127 276 347 127 276 minecraft:white_wool
setblock 345 127 279 minecraft:light_gray_wool
fill 345 127 286 354 127 286 minecraft:white_stained_glass
fill 345 127 287 347 127 287 minecraft:yellow_concrete
fill 345 127 295 347 127 295 minecraft:yellow_concrete
fill 345 127 296 354 127 296 minecraft:white_stained_glass
setblock 345 127 303 minecraft:light_gray_wool
fill 345 127 304 347 127 304 minecraft:white_wool
setblock 345 127 307 minecraft:light_gray_wool
fill 345 127 308 347 127 308 minecraft:white_wool
setblock 345 127 311 minecraft:light_gray_wool
fill 345 127 312 347 127 312 minecraft:white_wool
setblock 345 127 315 minecraft:light_gray_wool
fill 345 127 316 347 127 316 minecraft:white_wool
setblock 346 127 278 minecraft:light_gray_wool
fill 346 127 279 348 127 279 minecraft:white_wool
fill 346 127 303 348 127 303 minecraft:white_wool
setblock 346 127 306 minecraft:light_gray_wool
fill 346 127 307 348 127 307 minecraft:white_wool
setblock 346 127 310 minecraft:light_gray_wool
fill 346 127 311 348 127 311 minecraft:white_wool
setblock 346 127 314 minecraft:light_gray_wool
fill 346 127 315 348 127 315 minecraft:white_wool
setblock 347 127 277 minecraft:light_gray_wool
fill 347 127 278 349 127 278 minecraft:white_wool
fill 347 127 288 349 127 288 minecraft:yellow_concrete
fill 347 127 294 349 127 294 minecraft:yellow_concrete
setblock 347 127 305 minecraft:light_gray_wool
fill 347 127 306 349 127 306 minecraft:white_wool
setblock 347 127 309 minecraft:light_gray_wool
fill 347 127 310 349 127 310 minecraft:white_wool
setblock 347 127 313 minecraft:light_gray_wool
fill 347 127 314 349 127 314 minecraft:white_wool
setblock 348 127 276 minecraft:light_gray_wool
fill 348 127 277 350 127 277 minecraft:white_wool
fill 348 127 287 354 127 287 minecraft:white_stained_glass
fill 348 127 295 354 127 295 minecraft:white_stained_glass
setblock 348 127 304 minecraft:light_gray_wool
fill 348 127 305 350 127 305 minecraft:white_wool
setblock 348 127 308 minecraft:light_gray_wool
fill 348 127 309 350 127 309 minecraft:white_wool
setblock 348 127 312 minecraft:light_gray_wool
fill 348 127 313 350 127 313 minecraft:white_wool
setblock 348 127 316 minecraft:light_gray_wool
setblock 349 127 275 minecraft:light_blue_terracotta
fill 349 127 276 351 127 276 minecraft:white_wool
setblock 349 127 279 minecraft:light_gray_wool
setblock 349 127 280 minecraft:lime_concrete
fill 349 127 289 349 127 290 minecraft:yellow_concrete
fill 349 127 292 349 127 293 minecraft:yellow_concrete
setblock 349 127 302 minecraft:yellow_concrete
setblock 349 127 303 minecraft:light_gray_wool
fill 349 127 304 351 127 304 minecraft:white_wool
setblock 349 127 307 minecraft:light_gray_wool
fill 349 127 308 351 127 308 minecraft:white_wool
setblock 349 127 311 minecraft:light_gray_wool
fill 349 127 312 351 127 312 minecraft:white_wool
setblock 349 127 315 minecraft:light_gray_wool
fill 349 127 316 351 127 316 minecraft:white_wool
fill 350 127 275 350 128 275 minecraft:white_concrete
setblock 350 127 278 minecraft:light_gray_wool
fill 350 127 279 351 127 280 minecraft:white_wool
fill 350 127 288 355 127 289 minecraft:white_stained_glass
fill 350 127 290 350 127 292 minecraft:yellow_concrete
fill 350 127 293 355 127 294 minecraft:white_stained_glass
setblock 350 127 302 minecraft:light_gray_wool
fill 350 127 303 352 127 303 minecraft:white_wool
setblock 350 127 306 minecraft:light_gray_wool
fill 350 127 307 352 127 307 minecraft:white_wool
setblock 350 127 310 minecraft:light_gray_wool
fill 350 127 311 352 127 311 minecraft:white_wool
setblock 350 127 314 minecraft:light_gray_wool
fill 350 127 315 352 127 315 minecraft:white_wool
setblock 351 127 277 minecraft:light_gray_wool
fill 351 127 278 353 127 278 minecraft:white_wool
fill 351 127 290 355 127 292 minecraft:white_stained_glass
fill 351 127 302 353 127 302 minecraft:white_wool
setblock 351 127 305 minecraft:light_gray_wool
fill 351 127 306 353 127 306 minecraft:white_wool
setblock 351 127 309 minecraft:light_gray_wool
fill 351 127 310 353 127 310 minecraft:white_wool
setblock 351 127 313 minecraft:light_gray_wool
fill 351 127 314 353 127 314 minecraft:white_wool
setblock 352 127 276 minecraft:light_gray_wool
fill 352 127 277 354 127 277 minecraft:white_wool
setblock 352 127 279 minecraft:white_wool
setblock 352 127 280 minecraft:light_gray_wool
fill 352 127 281 354 127 281 minecraft:white_wool
fill 352 127 301 354 127 301 minecraft:white_wool
setblock 352 127 304 minecraft:light_gray_wool
fill 352 127 305 354 127 305 minecraft:white_wool
setblock 352 127 308 minecraft:light_gray_wool
fill 352 127 309 354 127 309 minecraft:white_wool
setblock 352 127 312 minecraft:light_gray_wool
fill 352 127 313 354 127 313 minecraft:white_wool
setblock 352 127 316 minecraft:light_gray_wool
fill 352 127 317 352 128 317 minecraft:white_concrete
fill 353 127 276 355 127 276 minecraft:white_wool
setblock 353 127 279 minecraft:light_gray_wool
fill 353 127 280 355 127 280 minecraft:white_wool
setblock 353 127 282 minecraft:light_blue_concrete
setblock 353 127 300 minecraft:orange_concrete
setblock 353 127 303 minecraft:light_gray_wool
fill 353 127 304 355 127 304 minecraft:white_wool
setblock 353 127 307 minecraft:light_gray_wool
fill 353 127 308 355 127 308 minecraft:white_wool
setblock 353 127 311 minecraft:light_gray_wool
fill 353 127 312 355 127 312 minecraft:white_wool
setblock 353 127 315 minecraft:light_gray_wool
fill 353 127 316 355 127 316 minecraft:white_wool
setblock 354 127 278 minecraft:light_gray_wool
fill 354 127 279 356 127 279 minecraft:white_wool
setblock 354 127 282 minecraft:light_gray_wool
setblock 354 127 283 minecraft:light_blue_concrete
setblock 354 127 299 minecraft:orange_concrete
fill 354 127 300 355 127 300 minecraft:white_wool
setblock 354 127 302 minecraft:light_gray_wool
fill 354 127 303 356 127 303 minecraft:white_wool
setblock 354 127 306 minecraft:light_gray_wool
fill 354 127 307 356 127 307 minecraft:white_wool
setblock 354 127 310 minecraft:light_gray_wool
fill 354 127 311 356 127 311 minecraft:white_wool
setblock 354 127 314 minecraft:light_gray_wool
fill 354 127 315 356 127 315 minecraft:white_wool
fill 354 127 317 355 127 317 minecraft:light_blue_terracotta
setblock 355 127 277 minecraft:light_gray_wool
fill 355 127 278 357 127 278 minecraft:white_wool
setblock 355 127 281 minecraft:light_gray_wool
fill 355 127 282 356 127 283 minecraft:white_wool
setblock 355 127 284 minecraft:light_blue_concrete
setblock 355 127 298 minecraft:orange_concrete
fill 355 127 299 356 127 299 minecraft:white_wool
setblock 355 127 301 minecraft:light_gray_wool
fill 355 127 302 357 127 302 minecraft:white_wool
setblock 355 127 305 minecraft:light_gray_wool
fill 355 127 306 357 127 306 minecraft:white_wool
setblock 355 127 309 minecraft:light_gray_wool
fill 355 127 310 357 127 310 minecraft:white_wool
setblock 355 127 313 minecraft:light_gray_wool
fill 355 127 314 357 127 314 minecraft:white_wool
setblock 356 127 276 minecraft:light_gray_wool
fill 356 127 277 358 127 277 minecraft:white_wool
setblock 356 127 280 minecraft:light_gray_wool
fill 356 127 281 358 127 281 minecraft:white_wool
setblock 356 127 284 minecraft:light_gray_wool
fill 356 127 285 358 127 285 minecraft:white_wool
fill 356 127 297 357 127 298 minecraft:white_wool
setblock 356 127 300 minecraft:light_gray_wool
fill 356 127 301 358 127 301 minecraft:white_wool
setblock 356 127 304 minecraft:light_gray_wool
fill 356 127 305 358 127 305 minecraft:white_wool
setblock 356 127 308 minecraft:light_gray_wool
fill 356 127 309 358 127 309 minecraft:white_wool
setblock 356 127 312 minecraft:light_gray_wool
fill 356 127 313 358 127 313 minecraft:white_wool
setblock 356 127 316 minecraft:light_gray_wool
fill 357 127 276 359 127 276 minecraft:white_wool
setblock 357 127 279 minecraft:light_gray_wool
fill 357 127 280 359 127 280 minecraft:white_wool
setblock 357 127 282 minecraft:white_wool
setblock 357 127 283 minecraft:light_gray_wool
fill 357 127 284 359 127 284 minecraft:white_wool
setblock 357 127 286 minecraft:white_wool
setblock 357 127 287 minecraft:light_gray_wool
setblock 357 127 288 minecraft:purple_concrete
setblock 357 127 294 minecraft:red_concrete
setblock 357 127 295 minecraft:light_gray_wool
fill 357 127 296 359 127 296 minecraft:white_wool
setblock 357 127 299 minecraft:light_gray_wool
fill 357 127 300 359 127 300 minecraft:white_wool
setblock 357 127 303 minecraft:light_gray_wool
fill 357 127 304 359 127 304 minecraft:white_wool
setblock 357 127 307 minecraft:light_gray_wool
fill 357 127 308 359 127 308 minecraft:white_wool
setblock 357 127 311 minecraft:light_gray_wool
fill 357 127 312 359 127 312 minecraft:white_wool
setblock 357 127 315 minecraft:light_gray_wool
fill 357 127 316 359 127 316 minecraft:white_wool
setblock 358 127 278 minecraft:light_gray_wool
fill 358 127 279 360 127 279 minecraft:white_wool
setblock 358 127 282 minecraft:light_gray_wool
fill 358 127 283 360 127 283 minecraft:white_wool
setblock 358 127 286 minecraft:light_gray_wool
fill 358 127 287 358 127 289 minecraft:white_wool
setblock 358 127 290 minecraft:light_gray_wool
fill 358 127 291 358 127 293 minecraft:white_wool
setblock 358 127 294 minecraft:light_gray_wool
fill 358 127 295 360 127 295 minecraft:white_wool
setblock 358 127 297 minecraft:white_wool
setblock 358 127 298 minecraft:light_gray_wool
fill 358 127 299 360 127 299 minecraft:white_wool
setblock 358 127 302 minecraft:light_gray_wool
fill 358 127 303 360 127 303 minecraft:white_wool
setblock 358 127 306 minecraft:light_gray_wool
fill 358 127 307 360 127 307 minecraft:white_wool
setblock 358 127 310 minecraft:light_gray_wool
fill 358 127 311 360 127 311 minecraft:white_wool
setblock 358 127 314 minecraft:light_gray_wool
fill 358 127 315 360 127 315 minecraft:white_wool
setblock 359 127 277 minecraft:light_gray_wool
fill 359 127 278 361 127 278 minecraft:white_wool
setblock 359 127 281 minecraft:light_gray_wool
fill 359 127 282 361 127 282 minecraft:white_wool
setblock 359 127 285 minecraft:light_gray_wool
fill 359 127 286 359 127 288 minecraft:white_wool
setblock 359 127 289 minecraft:light_gray_wool
fill 359 127 290 359 127 292 minecraft:white_wool
setblock 359 127 293 minecraft:light_gray_wool
fill 359 127 294 361 127 294 minecraft:white_wool
setblock 359 127 297 minecraft:light_gray_wool
fill 359 127 298 361 127 298 minecraft:white_wool
setblock 359 127 301 minecraft:light_gray_wool
fill 359 127 302 361 127 302 minecraft:white_wool
setblock 359 127 305 minecraft:light_gray_wool
fill 359 127 306 361 127 306 minecraft:white_wool
setblock 359 127 309 minecraft:light_gray_wool
fill 359 127 310 361 127 310 minecraft:white_wool
setblock 359 127 313 minecraft:light_gray_wool
fill 359 127 314 361 127 314 minecraft:white_wool
setblock 360 127 275 minecraft:light_blue_terracotta
setblock 360 127 276 minecraft:light_gray_wool
fill 360 127 277 362 127 277 minecraft:white_wool
setblock 360 127 280 minecraft:light_gray_wool
fill 360 127 281 362 127 281 minecraft:white_wool
setblock 360 127 284 minecraft:light_gray_wool
fill 360 127 285 360 127 287 minecraft:white_wool
setblock 360 127 288 minecraft:light_gray_wool
fill 360 127 289 360 127 291 minecraft:white_wool
setblock 360 127 292 minecraft:light_gray_wool
fill 360 127 293 362 127 293 minecraft:white_wool
setblock 360 127 296 minecraft:light_gray_wool
fill 360 127 297 362 127 297 minecraft:white_wool
setblock 360 127 300 minecraft:light_gray_wool
fill 360 127 301 362 127 301 minecraft:white_wool
setblock 360 127 304 minecraft:light_gray_wool
fill 360 127 305 362 127 305 minecraft:white_wool
setblock 360 127 308 minecraft:light_gray_wool
fill 360 127 309 362 127 309 minecraft:white_wool
setblock 360 127 312 minecraft:light_gray_wool
fill 360 127 313 362 127 313 minecraft:white_wool
setblock 360 127 316 minecraft:light_gray_wool
fill 361 127 276 363 127 276 minecraft:white_wool
setblock 361 127 279 minecraft:light_gray_wool
fill 361 127 280 363 127 280 minecraft:white_wool
setblock 361 127 283 minecraft:light_gray_wool
fill 361 127 284 361 127 286 minecraft:white_wool
setblock 361 127 287 minecraft:light_gray_wool
fill 361 127 288 361 127 290 minecraft:white_wool
setblock 361 127 291 minecraft:light_gray_wool
fill 361 127 292 363 127 292 minecraft:white_wool
setblock 361 127 295 minecraft:light_gray_wool
fill 361 127 296 363 127 296 minecraft:white_wool
setblock 361 127 299 minecraft:light_gray_wool
fill 361 127 300 363 127 300 minecraft:white_wool
setblock 361 127 303 minecraft:light_gray_wool
fill 361 127 304 363 127 304 minecraft:white_wool
setblock 361 127 307 minecraft:light_gray_wool
fill 361 127 308 363 127 308 minecraft:white_wool
setblock 361 127 311 minecraft:light_gray_wool
fill 361 127 312 363 127 312 minecraft:white_wool
setblock 361 127 315 minecraft:light_gray_wool
fill 361 127 316 363 127 316 minecraft:white_wool
fill 361 127 317 362 128 317 minecraft:white_concrete
setblock 362 127 278 minecraft:light_gray_wool
fill 362 127 279 364 127 279 minecraft:white_wool
setblock 362 127 282 minecraft:light_gray_wool
fill 362 127 283 362 127 285 minecraft:white_wool
setblock 362 127 286 minecraft:light_gray_wool
fill 362 127 287 362 127 289 minecraft:white_wool
setblock 362 127 290 minecraft:light_gray_wool
fill 362 127 291 364 127 291 minecraft:white_wool
setblock 362 127 294 minecraft:light_gray_wool
fill 362 127 295 364 127 295 minecraft:white_wool
setblock 362 127 298 minecraft:light_gray_wool
fill 362 127 299 364 127 299 minecraft:white_wool
setblock 362 127 302 minecraft:light_gray_wool
fill 362 127 303 364 127 303 minecraft:white_wool
setblock 362 127 306 minecraft:light_gray_wool
fill 362 127 307 364 127 307 minecraft:white_wool
setblock 362 127 310 minecraft:light_gray_wool
fill 362 127 311 364 127 311 minecraft:white_wool
setblock 362 127 314 minecraft:light_gray_wool
fill 362 127 315 364 127 315 minecraft:white_wool
setblock 363 127 277 minecraft:light_gray_wool
fill 363 127 278 365 127 278 minecraft:white_wool
setblock 363 127 281 minecraft:light_gray_wool
fill 363 127 282 363 127 284 minecraft:white_wool
setblock 363 127 285 minecraft:light_gray_wool
fill 363 127 286 363 127 288 minecraft:white_wool
setblock 363 127 289 minecraft:light_gray_wool
fill 363 127 290 365 127 290 minecraft:white_wool
setblock 363 127 293 minecraft:light_gray_wool
fill 363 127 294 365 127 294 minecraft:white_wool
setblock 363 127 297 minecraft:light_gray_wool
fill 363 127 298 365 127 298 minecraft:white_wool
setblock 363 127 301 minecraft:light_gray_wool
fill 363 127 302 365 127 302 minecraft:white_wool
setblock 363 127 305 minecraft:light_gray_wool
fill 363 127 306 365 127 306 minecraft:white_wool
setblock 363 127 309 minecraft:light_gray_wool
fill 363 127 310 365 127 310 minecraft:white_wool
setblock 363 127 313 minecraft:light_gray_wool
fill 363 127 314 365 127 314 minecraft:white_wool
setblock 363 127 317 minecraft:light_blue_terracotta
setblock 364 127 276 minecraft:light_gray_wool
fill 364 127 277 366 127 277 minecraft:white_wool
setblock 364 127 280 minecraft:light_gray_wool
fill 364 127 281 364 127 283 minecraft:white_wool
setblock 364 127 284 minecraft:light_gray_wool
fill 364 127 285 364 127 287 minecraft:white_wool
setblock 364 127 288 minecraft:light_gray_wool
fill 364 127 289 366 127 289 minecraft:white_wool
setblock 364 127 292 minecraft:light_gray_wool
fill 364 127 293 366 127 293 minecraft:white_wool
setblock 364 127 296 minecraft:light_gray_wool
fill 364 127 297 366 127 297 minecraft:white_wool
setblock 364 127 300 minecraft:light_gray_wool
fill 364 127 301 366 127 301 minecraft:white_wool
setblock 364 127 304 minecraft:light_gray_wool
fill 364 127 305 366 127 305 minecraft:white_wool
setblock 364 127 308 minecraft:light_gray_wool
fill 364 127 309 366 127 309 minecraft:white_wool
setblock 364 127 312 minecraft:light_gray_wool
fill 364 127 313 366 127 313 minecraft:white_wool
setblock 364 127 316 minecraft:light_gray_wool
fill 365 127 275 365 128 275 minecraft:white_concrete
fill 365 127 276 367 127 276 minecraft:white_wool
setblock 365 127 279 minecraft:light_gray_wool
fill 365 127 280 365 127 282 minecraft:white_wool
setblock 365 127 283 minecraft:light_gray_wool
fill 365 127 284 365 127 286 minecraft:white_wool
setblock 365 127 287 minecraft:light_gray_wool
fill 365 127 288 367 127 288 minecraft:white_wool
setblock 365 127 291 minecraft:light_gray_wool
fill 365 127 292 367 127 292 minecraft:white_wool
setblock 365 127 295 minecraft:light_gray_wool
fill 365 127 296 367 127 296 minecraft:white_wool
setblock 365 127 299 minecraft:light_gray_wool
fill 365 127 300 367 127 300 minecraft:white_wool
setblock 365 127 303 minecraft:light_gray_wool
fill 365 127 304 367 127 304 minecraft:white_wool
setblock 365 127 307 minecraft:light_gray_wool
fill 365 127 308 367 127 308 minecraft:white_wool
setblock 365 127 311 minecraft:light_gray_wool
fill 365 127 312 367 127 312 minecraft:white_wool
setblock 365 127 315 minecraft:light_gray_wool
fill 365 127 316 367 127 316 minecraft:white_wool
setblock 366 127 278 minecraft:light_gray_wool
fill 366 127 279 366 127 281 minecraft:white_wool
setblock 366 127 282 minecraft:light_gray_wool
fill 366 127 283 366 127 285 minecraft:white_wool
setblock 366 127 286 minecraft:light_gray_wool
fill 366 127 287 368 127 287 minecraft:white_wool
setblock 366 127 290 minecraft:light_gray_wool
fill 366 127 291 368 127 291 minecraft:white_wool
setblock 366 127 294 minecraft:light_gray_wool
fill 366 127 295 368 127 295 minecraft:white_wool
setblock 366 127 298 minecraft:light_gray_wool
fill 366 127 299 368 127 299 minecraft:white_wool
setblock 366 127 302 minecraft:light_gray_wool
fill 366 127 303 368 127 303 minecraft:white_wool
setblock 366 127 306 minecraft:light_gray_wool
fill 366 127 307 368 127 307 minecraft:white_wool
setblock 366 127 310 minecraft:light_gray_wool
fill 366 127 311 368 127 311 minecraft:white_wool
setblock 366 127 314 minecraft:light_gray_wool
fill 366 127 315 368 127 315 minecraft:white_wool
fill 367 127 275 367 128 275 minecraft:white_concrete
setblock 367 127 277 minecraft:light_gray_wool
fill 367 127 278 367 127 280 minecraft:white_wool
setblock 367 127 281 minecraft:light_gray_wool
fill 367 127 282 367 127 284 minecraft:white_wool
setblock 367 127 285 minecraft:light_gray_wool
fill 367 127 286 369 127 286 minecraft:white_wool
setblock 367 127 289 minecraft:light_gray_wool
fill 367 127 290 369 127 290 minecraft:white_wool
setblock 367 127 293 minecraft:light_gray_wool
fill 367 127 294 369 127 294 minecraft:white_wool
setblock 367 127 297 minecraft:light_gray_wool
fill 367 127 298 369 127 298 minecraft:white_wool
setblock 367 127 301 minecraft:light_gray_wool
fill 367 127 302 369 127 302 minecraft:white_wool
setblock 367 127 305 minecraft:light_gray_wool
fill 367 127 306 369 127 306 minecraft:white_wool
setblock 367 127 309 minecraft:light_gray_wool
fill 367 127 310 369 127 310 minecraft:white_wool
setblock 367 127 313 minecraft:light_gray_wool
fill 367 127 314 369 127 314 minecraft:white_wool
setblock 368 127 276 minecraft:light_gray_wool
fill 368 127 277 368 127 279 minecraft:white_wool
setblock 368 127 280 minecraft:light_gray_wool
fill 368 127 281 368 127 283 minecraft:white_wool
setblock 368 127 284 minecraft:light_gray_wool
fill 368 127 285 370 127 285 minecraft:white_wool
setblock 368 127 288 minecraft:light_gray_wool
fill 368 127 289 370 127 289 minecraft:white_wool
setblock 368 127 292 minecraft:light_gray_wool
fill 368 127 293 370 127 293 minecraft:white_wool
setblock 368 127 296 minecraft:light_gray_wool
fill 368 127 297 370 127 297 minecraft:white_wool
setblock 368 127 300 minecraft:light_gray_wool
fill 368 127 301 370 127 301 minecraft:white_wool
setblock 368 127 304 minecraft:light_gray_wool
fill 368 127 305 370 127 305 minecraft:white_wool
setblock 368 127 308 minecraft:light_gray_wool
fill 368 127 309 370 127 309 minecraft:white_wool
setblock 368 127 312 minecraft:light_gray_wool
fill 368 127 313 370 127 313 minecraft:white_wool
setblock 368 127 316 minecraft:light_gray_wool
fill 368 127 317 368 128 317 minecraft:white_concrete
fill 369 127 276 369 127 278 minecraft:white_wool
setblock 369 127 279 minecraft:light_gray_wool
fill 369 127 280 369 127 282 minecraft:white_wool
setblock 369 127 283 minecraft:light_gray_wool
fill 369 127 284 370 127 284 minecraft:white_wool
setblock 369 127 287 minecraft:light_gray_wool
fill 369 127 288 370 127 288 minecraft:white_wool
setblock 369 127 291 minecraft:light_gray_wool
fill 369 127 292 370 127 292 minecraft:white_wool
setblock 369 127 295 minecraft:light_gray_wool
fill 369 127 296 370 127 296 minecraft:white_wool
setblock 369 127 299 minecraft:light_gray_wool
fill 369 127 300 370 127 300 minecraft:white_wool
setblock 369 127 303 minecraft:light_gray_wool
fill 369 127 304 370 127 304 minecraft:white_wool
setblock 369 127 307 minecraft:light_gray_wool
fill 369 127 308 370 127 308 minecraft:white_wool
setblock 369 127 311 minecraft:light_gray_wool
fill 369 127 312 370 127 312 minecraft:white_wool
setblock 369 127 315 minecraft:light_gray_wool
fill 369 127 316 370 127 316 minecraft:white_wool
fill 370 127 276 370 127 277 minecraft:white_wool
setblock 370 127 278 minecraft:light_gray_wool
fill 370 127 279 370 127 281 minecraft:white_wool
setblock 370 127 282 minecraft:light_gray_wool
setblock 370 127 283 minecraft:white_wool
setblock 370 127 286 minecraft:light_gray_wool
setblock 370 127 287 minecraft:white_wool
setblock 370 127 290 minecraft:light_gray_wool
setblock 370 127 291 minecraft:white_wool
setblock 370 127 294 minecraft:light_gray_wool
setblock 370 127 295 minecraft:white_wool
setblock 370 127 298 minecraft:light_gray_wool
setblock 370 127 299 minecraft:white_wool
setblock 370 127 302 minecraft:light_gray_wool
setblock 370 127 303 minecraft:white_wool
setblock 370 127 306 minecraft:light_gray_wool
setblock 370 127 307 minecraft:white_wool
setblock 370 127 310 minecraft:light_gray_wool
setblock 370 127 311 minecraft:white_wool
setblock 370 127 314 minecraft:light_gray_wool
setblock 370 127 315 minecraft:white_wool
setblock 371 127 275 minecraft:light_blue_terracotta
fill 371 127 276 371 128 276 minecraft:white_concrete
fill 371 127 278 371 128 278 minecraft:white_concrete
setblock 371 127 281 minecraft:light_blue_terracotta
fill 371 127 294 371 128 294 minecraft:white_concrete
setblock 371 127 300 minecraft:light_blue_terracotta
setblock 371 127 308 minecraft:light_blue_terracotta
setblock 371 127 311 minecraft:light_blue_terracotta
setblock 371 127 314 minecraft:light_blue_terracotta
fill 371 127 317 371 128 317 minecraft:white_concrete
setblock 329 128 297 minecraft:white_concrete
setblock 329 128 310 minecraft:white_concrete
setblock 329 128 313 minecraft:white_concrete
setblock 336 128 275 minecraft:white_concrete
fill 337 128 288 338 128 291 minecraft:red_concrete
fill 337 128 292 338 128 294 minecraft:purple_concrete
fill 338 128 286 340 128 286 minecraft:orange_concrete
fill 338 128 287 339 128 287 minecraft:red_concrete
fill 338 128 295 339 128 295 minecraft:purple_concrete
fill 338 128 296 340 128 296 minecraft:light_blue_concrete
setblock 338 128 317 minecraft:white_concrete
fill 339 128 285 341 128 285 minecraft:orange_concrete
fill 339 128 297 341 128 297 minecraft:light_blue_concrete
fill 340 128 284 341 128 284 minecraft:orange_concrete
fill 340 128 298 341 128 298 minecraft:light_blue_concrete
setblock 341 128 283 minecraft:orange_concrete
setblock 341 128 299 minecraft:light_blue_concrete
fill 342 128 283 342 128 284 minecraft:yellow_concrete
fill 342 128 298 342 128 299 minecraft:lime_concrete
fill 343 128 282 345 128 283 minecraft:yellow_concrete
fill 343 128 299 346 128 300 minecraft:lime_concrete
fill 346 128 282 349 128 283 minecraft:lime_concrete
fill 347 128 299 349 128 300 minecraft:yellow_concrete
setblock 349 128 275 minecraft:white_concrete
fill 350 128 283 350 128 284 minecraft:lime_concrete
fill 350 128 298 350 128 299 minecraft:yellow_concrete
setblock 350 128 317 minecraft:white_concrete
fill 351 128 283 351 128 285 minecraft:light_blue_concrete
fill 351 128 297 351 128 299 minecraft:orange_concrete
fill 352 128 284 352 128 286 minecraft:light_blue_concrete
fill 352 128 296 352 128 298 minecraft:orange_concrete
fill 353 128 285 353 128 286 minecraft:light_blue_concrete
fill 353 128 287 354 128 287 minecraft:purple_concrete
fill 353 128 295 354 128 295 minecraft:red_concrete
fill 353 128 296 353 128 297 minecraft:orange_concrete
setblock 354 128 286 minecraft:light_blue_concrete
fill 354 128 288 355 128 290 minecraft:purple_concrete
fill 354 128 291 355 128 294 minecraft:red_concrete
setblock 354 128 296 minecraft:orange_concrete
fill 354 128 317 355 128 317 minecraft:white_concrete
setblock 360 128 275 minecraft:white_concrete
setblock 363 128 317 minecraft:white_concrete
fill 371 128 275 371 129 275 minecraft:white_concrete
setblock 371 128 281 minecraft:white_concrete
fill 371 128 300 371 129 300 minecraft:white_concrete
setblock 371 128 308 minecraft:white_concrete
fill 371 128 311 371 129 311 minecraft:white_concrete
setblock 371 128 314 minecraft:white_concrete
fill 329 129 275 332 129 275 minecraft:light_blue_terracotta
setblock 329 129 276 minecraft:white_concrete
fill 329 129 277 329 129 284 minecraft:light_blue_terracotta
fill 329 129 286 329 130 291 minecraft:light_blue_terracotta
setblock 329 129 292 minecraft:white_concrete
fill 329 129 293 329 129 299 minecraft:light_blue_terracotta
setblock 329 129 300 minecraft:white_concrete
fill 329 129 301 329 129 306 minecraft:light_blue_terracotta
setblock 329 129 307 minecraft:white_wool
fill 329 129 308 329 130 316 minecraft:light_blue_terracotta
fill 330 129 317 334 129 317 minecraft:light_blue_terracotta
setblock 332 129 278 minecraft:light[level=15]
setblock 332 129 286 minecraft:light[level=15]
setblock 332 129 294 minecraft:light[level=15]
setblock 332 129 302 minecraft:light[level=15]
setblock 332 129 310 minecraft:light[level=15]
setblock 333 129 275 minecraft:white_concrete
fill 334 129 275 342 129 275 minecraft:light_blue_terracotta
fill 336 129 317 336 214 317 minecraft:light_blue_terracotta
fill 338 129 317 343 129 317 minecraft:light_blue_terracotta
setblock 340 129 278 minecraft:light[level=15]
setblock 340 129 286 minecraft:light[level=15]
setblock 340 129 294 minecraft:light[level=15]
setblock 340 129 302 minecraft:light[level=15]
setblock 340 129 310 minecraft:light[level=15]
fill 344 129 275 363 129 275 minecraft:light_blue_terracotta
setblock 344 129 317 minecraft:white_concrete
fill 345 129 317 346 176 317 minecraft:light_blue_terracotta
setblock 348 129 278 minecraft:light[level=15]
setblock 348 129 286 minecraft:light[level=15]
setblock 348 129 294 minecraft:light[level=15]
setblock 348 129 302 minecraft:light[level=15]
setblock 348 129 310 minecraft:light[level=15]
fill 348 129 317 369 129 317 minecraft:light_blue_terracotta
setblock 356 129 278 minecraft:light[level=15]
setblock 356 129 286 minecraft:light[level=15]
setblock 356 129 294 minecraft:light[level=15]
setblock 356 129 302 minecraft:light[level=15]
setblock 356 129 310 minecraft:light[level=15]
setblock 364 129 275 minecraft:white_concrete
setblock 364 129 278 minecraft:light[level=15]
setblock 364 129 286 minecraft:light[level=15]
setblock 364 129 294 minecraft:light[level=15]
setblock 364 129 302 minecraft:light[level=15]
setblock 364 129 310 minecraft:light[level=15]
fill 365 129 275 370 130 275 minecraft:light_blue_terracotta
fill 371 129 276 371 148 276 minecraft:light_blue_terracotta
fill 371 129 278 371 160 278 minecraft:light_blue_terracotta
fill 371 129 280 371 129 299 minecraft:light_blue_terracotta
fill 371 129 301 371 130 304 minecraft:light_blue_terracotta
fill 371 129 306 371 188 306 minecraft:light_blue_terracotta
setblock 371 129 307 minecraft:white_concrete
fill 371 129 308 371 201 310 minecraft:light_blue_terracotta
fill 371 129 313 371 130 317 minecraft:light_blue_terracotta
fill 329 130 275 329 131 275 minecraft:white_concrete
fill 329 130 276 329 145 279 minecraft:light_blue_terracotta
fill 329 130 280 329 131 280 minecraft:white_concrete
fill 329 130 281 329 132 284 minecraft:light_blue_terracotta
fill 329 130 292 329 130 295 minecraft:light_blue_terracotta
setblock 329 130 296 minecraft:white_concrete
fill 329 130 297 329 155 300 minecraft:light_blue_terracotta
setblock 329 130 301 minecraft:white_concrete
fill 329 130 302 329 130 306 minecraft:light_blue_terracotta
setblock 329 130 307 minecraft:white_concrete
fill 329 130 317 331 215 317 minecraft:light_blue_terracotta
fill 330 130 275 338 130 275 minecraft:light_blue_terracotta
setblock 332 130 317 minecraft:white_concrete
fill 333 130 317 335 151 317 minecraft:light_blue_terracotta
fill 338 130 317 338 183 317 minecraft:light_blue_terracotta
setblock 339 130 275 minecraft:white_concrete
setblock 339 130 317 minecraft:white_concrete
fill 340 130 275 346 135 275 minecraft:light_blue_terracotta
fill 340 130 317 344 158 317 minecraft:light_blue_terracotta
fill 347 130 275 348 130 275 minecraft:white_concrete
fill 347 130 317 350 182 317 minecraft:light_blue_terracotta
fill 349 130 275 354 130 275 minecraft:light_blue_terracotta
fill 351 130 317 351 131 317 minecraft:white_concrete
fill 352 130 317 357 130 317 minecraft:light_blue_terracotta
setblock 355 130 275 minecraft:white_concrete
fill 356 130 275 358 130 275 minecraft:light_blue_terracotta
setblock 358 130 317 minecraft:white_concrete
setblock 359 130 275 minecraft:white_concrete
fill 359 130 317 362 130 317 minecraft:light_blue_terracotta
fill 360 130 275 364 143 275 minecraft:light_blue_terracotta
setblock 363 130 317 minecraft:white_concrete
setblock 364 130 317 minecraft:light_blue_terracotta
setblock 365 130 317 minecraft:white_concrete
fill 366 130 317 370 172 317 minecraft:light_blue_terracotta
fill 371 130 275 371 218 275 minecraft:light_blue_terracotta
fill 371 130 277 371 193 277 minecraft:light_blue_terracotta
fill 371 130 279 371 206 281 minecraft:light_blue_terracotta
setblock 371 130 282 minecraft:white_concrete
fill 371 130 283 371 143 284 minecraft:light_blue_terracotta
setblock 371 130 285 minecraft:white_concrete
fill 371 130 286 371 130 293 minecraft:light_blue_terracotta
fill 371 130 294 371 130 296 minecraft:white_concrete
fill 371 130 297 371 135 300 minecraft:light_blue_terracotta
fill 371 130 307 371 178 307 minecraft:light_blue_terracotta
fill 371 130 311 371 130 312 minecraft:light_blue_terracotta
fill 329 131 285 329 144 289 minecraft:light_blue_terracotta
setblock 329 131 290 minecraft:white_concrete
fill 329 131 291 329 167 294 minecraft:light_blue_terracotta
setblock 329 131 295 minecraft:white_concrete
fill 329 131 296 329 161 296 minecraft:light_blue_terracotta
fill 329 131 301 329 216 304 minecraft:light_blue_terracotta
setblock 329 131 305 minecraft:white_concrete
fill 329 131 306 329 215 309 minecraft:light_blue_terracotta
setblock 329 131 310 minecraft:white_concrete
fill 329 131 311 329 136 313 minecraft:light_blue_terracotta
setblock 329 131 314 minecraft:white_concrete
fill 329 131 315 329 215 316 minecraft:light_blue_terracotta
setblock 330 131 275 minecraft:white_concrete
fill 331 131 275 337 143 275 minecraft:light_blue_terracotta
setblock 332 131 278 minecraft:light[level=12]
setblock 332 131 285 minecraft:light[level=12]
setblock 332 131 292 minecraft:light[level=12]
setblock 332 131 299 minecraft:light[level=12]
setblock 332 131 306 minecraft:light[level=12]
setblock 332 131 313 minecraft:light[level=12]
fill 332 131 317 332 214 317 minecraft:light_blue_terracotta
setblock 337 131 306 minecraft:ochre_froglight
fill 337 131 317 337 136 317 minecraft:light_blue_terracotta
setblock 338 131 275 minecraft:white_concrete
fill 339 131 275 339 197 275 minecraft:light_blue_terracotta
setblock 339 131 278 minecraft:light[level=12]
setblock 339 131 285 minecraft:light[level=12]
setblock 339 131 292 minecraft:light[level=12]
setblock 339 131 299 minecraft:light[level=12]
setblock 339 131 306 minecraft:light[level=12]
setblock 339 131 313 minecraft:light[level=12]
fill 339 131 317 339 218 317 minecraft:light_blue_terracotta
setblock 346 131 278 minecraft:light[level=12]
setblock 346 131 285 minecraft:light[level=12]
setblock 346 131 299 minecraft:light[level=12]
setblock 346 131 306 minecraft:light[level=12]
fill 346 131 311 348 132 311 minecraft:white_concrete
setblock 346 131 313 minecraft:light[level=12]
fill 347 131 275 352 137 275 minecraft:light_blue_terracotta
fill 347 131 310 347 132 310 minecraft:white_concrete
fill 347 131 312 347 132 312 minecraft:white_concrete
fill 352 131 282 352 132 282 minecraft:ochre_froglight
setblock 352 131 317 minecraft:white_concrete
setblock 353 131 275 minecraft:white_concrete
setblock 353 131 278 minecraft:light[level=12]
setblock 353 131 285 minecraft:light[level=12]
setblock 353 131 292 minecraft:light[level=12]
setblock 353 131 299 minecraft:light[level=12]
setblock 353 131 306 minecraft:light[level=12]
setblock 353 131 313 minecraft:light[level=12]
fill 353 131 317 356 145 317 minecraft:light_blue_terracotta
fill 354 131 275 355 132 275 minecraft:light_blue_terracotta
setblock 356 131 275 minecraft:white_concrete
fill 356 131 286 361 135 288 minecraft:dirt
fill 357 131 275 359 214 275 minecraft:light_blue_terracotta
fill 357 131 285 360 135 285 minecraft:dirt
fill 357 131 289 360 135 289 minecraft:dirt
setblock 357 131 317 minecraft:white_concrete
fill 358 131 284 359 135 284 minecraft:dirt
fill 358 131 290 359 135 290 minecraft:dirt
fill 358 131 317 359 133 317 minecraft:light_blue_terracotta
setblock 360 131 278 minecraft:light[level=12]
setblock 360 131 292 minecraft:light[level=12]
setblock 360 131 299 minecraft:light[level=12]
setblock 360 131 306 minecraft:light[level=12]
setblock 360 131 313 minecraft:light[level=12]
setblock 360 131 317 minecraft:white_concrete
fill 361 131 317 363 139 317 minecraft:light_blue_terracotta
setblock 364 131 317 minecraft:white_wool
setblock 365 131 275 minecraft:white_concrete
fill 365 131 317 365 148 317 minecraft:light_blue_terracotta
fill 366 131 275 366 188 275 minecraft:light_blue_terracotta
setblock 367 131 275 minecraft:white_concrete
setblock 367 131 278 minecraft:light[level=12]
setblock 367 131 285 minecraft:light[level=12]
setblock 367 131 292 minecraft:light[level=12]
setblock 367 131 299 minecraft:light[level=12]
setblock 367 131 306 minecraft:light[level=12]
setblock 367 131 313 minecraft:light[level=12]
fill 368 131 275 370 133 275 minecraft:light_blue_terracotta
fill 371 131 282 371 179 282 minecraft:light_blue_terracotta
fill 371 131 285 371 133 291 minecraft:light_blue_terracotta
setblock 371 131 292 minecraft:white_concrete
fill 371 131 293 371 154 293 minecraft:light_blue_terracotta
setblock 371 131 294 minecraft:white_concrete
fill 371 131 295 371 214 296 minecraft:light_blue_terracotta
fill 371 131 301 371 208 303 minecraft:light_blue_terracotta
setblock 371 131 304 minecraft:white_concrete
fill 371 131 305 371 218 305 minecraft:light_blue_terracotta
setblock 371 131 311 minecraft:white_concrete
fill 371 131 312 371 145 312 minecraft:light_blue_terracotta
setblock 371 131 313 minecraft:white_concrete
fill 371 131 314 371 197 316 minecraft:light_blue_terracotta
setblock 371 131 317 minecraft:white_concrete
fill 329 132 275 330 144 275 minecraft:light_blue_terracotta
fill 329 132 280 329 142 280 minecraft:light_blue_terracotta
fill 329 132 290 329 145 290 minecraft:light_blue_terracotta
fill 329 132 295 329 218 295 minecraft:light_blue_terracotta
fill 329 132 305 329 214 305 minecraft:light_blue_terracotta
fill 329 132 310 329 182 310 minecraft:light_blue_terracotta
fill 329 132 314 329 218 314 minecraft:light_blue_terracotta
fill 337 132 306 337 139 306 minecraft:dirt
fill 338 132 275 338 219 275 minecraft:light_blue_terracotta
fill 351 132 317 352 133 317 minecraft:light_blue_terracotta
fill 353 132 275 353 218 275 minecraft:light_blue_terracotta
fill 355 132 286 355 135 288 minecraft:dirt
fill 356 132 275 356 141 275 minecraft:light_blue_terracotta
fill 356 132 285 356 135 285 minecraft:dirt
fill 356 132 289 356 135 289 minecraft:dirt
fill 357 132 284 357 135 284 minecraft:dirt
fill 357 132 290 357 135 290 minecraft:dirt
fill 357 132 317 357 218 317 minecraft:light_blue_terracotta
fill 360 132 284 360 135 284 minecraft:dirt
fill 360 132 290 360 135 290 minecraft:dirt
fill 360 132 317 360 154 317 minecraft:light_blue_terracotta
fill 361 132 285 361 135 285 minecraft:dirt
fill 361 132 289 361 135 289 minecraft:dirt
fill 362 132 287 362 135 287 minecraft:dirt
fill 364 132 317 364 214 317 minecraft:light_blue_terracotta
fill 365 132 275 365 218 275 minecraft:light_blue_terracotta
fill 367 132 275 367 220 275 minecraft:light_blue_terracotta
fill 371 132 292 371 218 292 minecraft:light_blue_terracotta
fill 371 132 294 371 218 294 minecraft:light_blue_terracotta
fill 371 132 304 371 218 304 minecraft:light_blue_terracotta
fill 371 132 311 371 218 311 minecraft:light_blue_terracotta
fill 371 132 313 371 140 313 minecraft:light_blue_terracotta
fill 371 132 317 371 219 317 minecraft:light_blue_terracotta
fill 329 133 281 329 166 281 minecraft:light_blue_terracotta
setblock 329 133 282 minecraft:white_wool
fill 329 133 283 329 147 284 minecraft:light_blue_terracotta
fill 336 133 306 336 139 306 minecraft:dirt
fill 337 133 305 337 139 305 minecraft:dirt
fill 352 133 282 352 142 282 minecraft:dirt
fill 352 133 307 354 135 308 minecraft:packed_mud
fill 353 133 306 354 135 306 minecraft:packed_mud
fill 354 133 275 354 218 275 minecraft:light_blue_terracotta
setblock 355 133 275 minecraft:white_wool
fill 355 133 285 355 135 285 minecraft:dirt
fill 355 133 289 355 135 289 minecraft:dirt
fill 356 133 284 356 135 284 minecraft:dirt
fill 356 133 290 356 135 290 minecraft:dirt
fill 358 133 283 359 135 283 minecraft:dirt
fill 358 133 291 359 135 291 minecraft:dirt
fill 361 133 284 361 135 284 minecraft:dirt
fill 361 133 290 361 135 290 minecraft:dirt
fill 362 133 286 362 135 286 minecraft:dirt
fill 362 133 288 362 135 288 minecraft:dirt
fill 329 134 282 329 158 282 minecraft:light_blue_terracotta
fill 336 134 305 336 139 305 minecraft:dirt
fill 337 134 307 337 139 307 minecraft:dirt
fill 338 134 306 338 139 306 minecraft:dirt
fill 351 134 282 351 142 282 minecraft:dirt
fill 351 134 308 351 135 308 minecraft:packed_mud
fill 351 134 317 351 172 317 minecraft:light_blue_terracotta
fill 352 134 283 352 142 283 minecraft:dirt
fill 352 134 306 352 136 306 minecraft:packed_mud
setblock 352 134 317 minecraft:white_wool
fill 354 134 286 354 135 288 minecraft:dirt
fill 355 134 275 355 197 275 minecraft:light_blue_terracotta
fill 355 134 284 355 135 284 minecraft:dirt
fill 355 134 290 355 135 290 minecraft:dirt
fill 355 134 306 355 134 308 minecraft:packed_mud
fill 357 134 283 357 135 283 minecraft:dirt
fill 357 134 291 357 135 291 minecraft:dirt
setblock 358 134 317 minecraft:white_wool
fill 359 134 317 359 218 317 minecraft:light_blue_terracotta
fill 360 134 283 360 135 283 minecraft:dirt
fill 360 134 291 360 135 291 minecraft:dirt
fill 362 134 285 362 135 285 minecraft:dirt
fill 362 134 289 362 135 289 minecraft:dirt
fill 368 134 275 368 218 275 minecraft:light_blue_terracotta
setblock 369 134 275 minecraft:white_wool
fill 370 134 275 370 215 275 minecraft:light_blue_terracotta
fill 371 134 285 371 163 286 minecraft:light_blue_terracotta
setblock 371 134 287 minecraft:white_wool
fill 371 134 288 371 155 291 minecraft:light_blue_terracotta
fill 335 135 306 335 139 306 minecraft:dirt
fill 336 135 307 336 139 307 minecraft:dirt
fill 337 135 304 337 139 304 minecraft:dirt
fill 338 135 305 338 139 305 minecraft:dirt
fill 338 135 307 338 139 307 minecraft:dirt
fill 351 135 283 351 142 283 minecraft:dirt
fill 352 135 281 352 142 281 minecraft:dirt
fill 352 135 309 354 136 309 minecraft:packed_mud
fill 352 135 317 352 215 317 minecraft:light_blue_terracotta
fill 353 135 282 353 142 282 minecraft:dirt
setblock 354 135 285 minecraft:dirt
setblock 354 135 289 minecraft:dirt
fill 355 135 307 355 135 308 minecraft:packed_mud
setblock 356 135 283 minecraft:dirt
setblock 356 135 291 minecraft:dirt
fill 358 135 282 359 135 282 minecraft:dirt
fill 358 135 292 359 135 292 minecraft:dirt
fill 358 135 317 358 150 317 minecraft:light_blue_terracotta
setblock 361 135 283 minecraft:dirt
setblock 361 135 291 minecraft:dirt
setblock 362 135 284 minecraft:dirt
setblock 362 135 290 minecraft:dirt
fill 363 135 285 363 135 289 minecraft:dirt
fill 369 135 275 369 218 275 minecraft:light_blue_terracotta
fill 371 135 287 371 209 287 minecraft:light_blue_terracotta
fill 335 136 305 335 139 305 minecraft:dirt
fill 335 136 307 335 139 307 minecraft:dirt
fill 336 136 304 336 139 304 minecraft:dirt
fill 337 136 308 337 139 308 minecraft:dirt
fill 338 136 304 338 139 304 minecraft:dirt
fill 339 136 306 339 139 306 minecraft:dirt
fill 340 136 275 340 218 275 minecraft:light_blue_terracotta
setblock 341 136 275 minecraft:white_wool
fill 342 136 275 346 137 275 minecraft:light_blue_terracotta
fill 343 136 288 343 137 288 minecraft:ochre_froglight
fill 350 136 282 350 142 282 minecraft:dirt
fill 351 136 281 351 142 281 minecraft:dirt
fill 351 136 307 351 137 308 minecraft:moss_block
fill 352 136 284 352 142 284 minecraft:dirt
fill 352 136 307 353 136 308 minecraft:packed_mud
fill 353 136 281 353 142 281 minecraft:dirt
fill 353 136 283 353 142 283 minecraft:dirt
fill 353 136 306 354 137 306 minecraft:moss_block
setblock 353 136 310 minecraft:moss_block
fill 354 136 307 355 137 307 minecraft:moss_block
setblock 354 136 308 minecraft:packed_mud
fill 355 136 308 355 137 308 minecraft:moss_block
fill 358 136 287 359 138 287 minecraft:white_concrete
fill 371 136 297 371 167 299 minecraft:light_blue_terracotta
setblock 371 136 300 minecraft:white_wool
setblock 329 137 311 minecraft:white_wool
fill 329 137 312 329 214 313 minecraft:light_blue_terracotta
setblock 332 137 278 minecraft:light[level=15]
setblock 332 137 285 minecraft:light[level=12]
setblock 332 137 286 minecraft:light[level=15]
setblock 332 137 292 minecraft:light[level=12]
setblock 332 137 294 minecraft:light[level=15]
setblock 332 137 299 minecraft:light[level=12]
setblock 332 137 302 minecraft:light[level=15]
setblock 332 137 306 minecraft:light[level=12]
setblock 332 137 310 minecraft:light[level=15]
setblock 332 137 313 minecraft:light[level=12]
fill 334 137 287 338 137 288 minecraft:white_wool
fill 334 137 306 334 139 306 minecraft:dirt
fill 335 137 286 337 138 286 minecraft:white_wool
fill 335 137 289 337 137 290 minecraft:white_wool
fill 335 137 304 335 139 304 minecraft:dirt
fill 336 137 308 336 139 308 minecraft:dirt
fill 337 137 303 337 139 303 minecraft:dirt
setblock 337 137 317 minecraft:white_wool
fill 338 137 289 338 138 289 minecraft:white_wool
fill 338 137 308 338 139 308 minecraft:dirt
setblock 339 137 278 minecraft:light[level=12]
setblock 339 137 285 minecraft:light[level=12]
setblock 339 137 292 minecraft:light[level=12]
setblock 339 137 299 minecraft:light[level=12]
fill 339 137 305 339 139 305 minecraft:dirt
fill 339 137 307 339 139 307 minecraft:dirt
setblock 339 137 313 minecraft:light[level=12]
setblock 340 137 278 minecraft:light[level=15]
setblock 340 137 286 minecraft:light[level=15]
setblock 340 137 294 minecraft:light[level=15]
setblock 340 137 302 minecraft:light[level=15]
setblock 340 137 310 minecraft:light[level=15]
fill 341 137 275 341 218 275 minecraft:light_blue_terracotta
setblock 346 137 278 minecraft:light[level=12]
setblock 346 137 285 minecraft:light[level=12]
setblock 346 137 299 minecraft:light[level=12]
setblock 346 137 306 minecraft:light[level=12]
setblock 346 137 313 minecraft:light[level=12]
setblock 348 137 278 minecraft:light[level=15]
setblock 348 137 286 minecraft:light[level=15]
setblock 348 137 294 minecraft:light[level=15]
setblock 348 137 302 minecraft:light[level=15]
setblock 348 137 310 minecraft:light[level=15]
fill 350 137 281 350 142 281 minecraft:dirt
fill 350 137 283 350 142 283 minecraft:dirt
fill 351 137 280 352 142 280 minecraft:dirt
fill 351 137 284 351 142 284 minecraft:dirt
fill 351 137 306 352 137 306 minecraft:moss_block
fill 351 137 309 354 137 309 minecraft:moss_block
fill 352 137 307 352 137 308 minecraft:moss_block
setblock 353 137 278 minecraft:light[level=12]
fill 353 137 284 353 142 284 minecraft:dirt
setblock 353 137 285 minecraft:light[level=12]
setblock 353 137 292 minecraft:light[level=12]
setblock 353 137 299 minecraft:light[level=12]
setblock 353 137 307 minecraft:moss_block
setblock 353 137 308 minecraft:packed_mud
setblock 353 137 313 minecraft:light[level=12]
fill 354 137 282 354 142 282 minecraft:dirt
setblock 354 137 308 minecraft:moss_block
setblock 356 137 278 minecraft:light[level=15]
setblock 356 137 286 minecraft:light[level=15]
setblock 356 137 294 minecraft:light[level=15]
setblock 356 137 302 minecraft:light[level=15]
setblock 356 137 310 minecraft:light[level=15]
setblock 360 137 278 minecraft:light[level=12]
setblock 360 137 285 minecraft:light[level=12]
setblock 360 137 292 minecraft:light[level=12]
setblock 360 137 299 minecraft:light[level=12]
setblock 360 137 306 minecraft:light[level=12]
setblock 360 137 313 minecraft:light[level=12]
setblock 364 137 278 minecraft:light[level=15]
setblock 364 137 286 minecraft:light[level=15]
setblock 364 137 294 minecraft:light[level=15]
setblock 364 137 302 minecraft:light[level=15]
setblock 364 137 310 minecraft:light[level=15]
setblock 367 137 278 minecraft:light[level=12]
setblock 367 137 285 minecraft:light[level=12]
setblock 367 137 292 minecraft:light[level=12]
setblock 367 137 299 minecraft:light[level=12]
setblock 367 137 306 minecraft:light[level=12]
setblock 367 137 313 minecraft:light[level=12]
fill 371 137 300 371 149 300 minecraft:light_blue_terracotta
fill 329 138 311 329 219 311 minecraft:light_blue_terracotta
fill 334 138 288 337 138 289 minecraft:white_wool
fill 334 138 305 334 139 305 minecraft:dirt
fill 334 138 307 334 139 307 minecraft:dirt
fill 335 138 287 338 138 287 minecraft:white_wool
setblock 335 138 290 minecraft:white_wool
fill 335 138 308 335 139 308 minecraft:dirt
fill 336 138 285 337 138 285 minecraft:white_wool
fill 336 138 302 336 139 302 minecraft:ochre_froglight
fill 336 138 303 336 139 303 minecraft:dirt
fill 337 138 290 338 138 290 minecraft:white_wool
fill 337 138 317 337 166 317 minecraft:light_blue_terracotta
setblock 338 138 288 minecraft:white_wool
fill 338 138 303 338 139 303 minecraft:dirt
setblock 339 138 289 minecraft:white_wool
fill 339 138 304 339 139 304 minecraft:dirt
fill 339 138 308 339 139 308 minecraft:dirt
fill 340 138 294 341 139 294 minecraft:white_concrete
fill 340 138 306 340 139 306 minecraft:dirt
fill 342 138 275 342 218 275 minecraft:light_blue_terracotta
setblock 343 138 275 minecraft:white_wool
fill 343 138 288 343 146 288 minecraft:dirt
fill 344 138 275 349 155 275 minecraft:light_blue_terracotta
fill 349 138 282 349 142 282 minecraft:dirt
setblock 350 138 275 minecraft:white_wool
fill 350 138 280 350 142 280 minecraft:dirt
fill 350 138 284 350 142 284 minecraft:dirt
fill 351 138 275 352 218 275 minecraft:light_blue_terracotta
fill 352 138 285 352 142 285 minecraft:dirt
fill 353 138 280 353 142 280 minecraft:dirt
fill 354 138 281 354 142 281 minecraft:dirt
fill 354 138 283 354 142 283 minecraft:dirt
setblock 334 139 304 minecraft:dirt
setblock 334 139 308 minecraft:dirt
setblock 335 139 303 minecraft:dirt
fill 335 139 309 338 139 309 minecraft:dirt
setblock 339 139 303 minecraft:dirt
fill 340 139 304 340 139 305 minecraft:dirt
setblock 340 139 307 minecraft:dirt
setblock 343 139 275 minecraft:light_blue_terracotta
fill 349 139 281 349 142 281 minecraft:dirt
fill 349 139 283 349 142 284 minecraft:dirt
fill 350 139 275 350 164 275 minecraft:light_blue_terracotta
fill 350 139 285 351 142 285 minecraft:dirt
fill 351 139 279 352 142 279 minecraft:dirt
fill 353 139 285 353 142 285 minecraft:dirt
fill 354 139 280 354 142 280 minecraft:dirt
fill 354 139 284 354 142 284 minecraft:dirt
fill 355 139 282 355 142 283 minecraft:dirt
fill 357 139 286 360 141 288 minecraft:oak_leaves[persistent=true]
fill 336 140 302 336 150 302 minecraft:dirt
fill 337 140 306 337 142 306 minecraft:white_concrete
fill 342 140 287 342 146 288 minecraft:dirt
setblock 343 140 275 minecraft:white_wool
fill 343 140 287 343 146 287 minecraft:dirt
fill 343 140 289 343 146 289 minecraft:dirt
fill 344 140 288 344 146 288 minecraft:dirt
fill 348 140 282 348 142 282 minecraft:dirt
fill 349 140 280 349 142 280 minecraft:dirt
fill 350 140 279 350 142 279 minecraft:dirt
fill 352 140 286 352 142 286 minecraft:dirt
fill 353 140 279 353 142 279 minecraft:dirt
fill 354 140 285 354 142 285 minecraft:dirt
fill 355 140 281 355 142 281 minecraft:dirt
fill 355 140 284 355 142 284 minecraft:dirt
fill 358 140 285 359 140 285 minecraft:oak_leaves[persistent=true]
fill 358 140 289 359 140 289 minecraft:oak_leaves[persistent=true]
setblock 361 140 317 minecraft:white_wool
fill 362 140 317 363 188 317 minecraft:light_blue_terracotta
fill 342 141 289 342 146 289 minecraft:dirt
fill 343 141 275 343 218 275 minecraft:light_blue_terracotta
fill 344 141 287 344 146 287 minecraft:dirt
fill 344 141 289 344 146 289 minecraft:dirt
fill 348 141 281 348 142 281 minecraft:dirt
fill 348 141 283 348 142 284 minecraft:dirt
fill 349 141 279 349 142 279 minecraft:dirt
fill 349 141 285 349 142 285 minecraft:dirt
fill 350 141 286 351 142 286 minecraft:dirt
fill 351 141 278 352 142 278 minecraft:dirt
fill 353 141 286 353 142 286 minecraft:dirt
fill 354 141 279 354 142 279 minecraft:dirt
fill 355 141 280 355 142 280 minecraft:dirt
fill 355 141 285 355 142 285 minecraft:dirt
fill 356 141 282 356 142 282 minecraft:dirt
fill 361 141 317 361 155 317 minecraft:light_blue_terracotta
setblock 371 141 313 minecraft:white_wool
fill 335 142 302 335 150 302 minecraft:dirt
fill 336 142 301 336 150 301 minecraft:dirt
fill 336 142 303 336 150 303 minecraft:dirt
fill 337 142 302 337 150 302 minecraft:dirt
fill 341 142 287 341 146 288 minecraft:dirt
fill 342 142 286 344 146 286 minecraft:dirt
fill 343 142 290 343 146 290 minecraft:dirt
fill 345 142 288 345 146 288 minecraft:dirt
setblock 347 142 282 minecraft:dirt
setblock 348 142 280 minecraft:dirt
setblock 348 142 285 minecraft:dirt
setblock 349 142 286 minecraft:dirt
setblock 350 142 278 minecraft:dirt
setblock 352 142 287 minecraft:dirt
fill 353 142 278 354 142 278 minecraft:dirt
setblock 354 142 286 minecraft:dirt
setblock 355 142 279 minecraft:dirt
setblock 356 142 275 minecraft:white_wool
fill 356 142 280 356 142 281 minecraft:dirt
fill 356 142 283 356 142 284 minecraft:dirt
fill 356 142 307 357 143 307 minecraft:white_concrete
fill 371 142 313 371 215 313 minecraft:light_blue_terracotta
setblock 329 143 280 minecraft:white_wool
setblock 332 143 278 minecraft:light[level=12]
setblock 332 143 285 minecraft:light[level=12]
setblock 332 143 292 minecraft:light[level=12]
setblock 332 143 299 minecraft:light[level=12]
setblock 332 143 306 minecraft:light[level=12]
setblock 332 143 313 minecraft:light[level=12]
fill 335 143 301 335 150 301 minecraft:dirt
fill 335 143 303 335 150 303 minecraft:dirt
fill 335 143 305 338 145 306 minecraft:oak_leaves[persistent=true]
fill 336 143 304 337 145 304 minecraft:oak_leaves[persistent=true]
fill 336 143 307 338 145 307 minecraft:oak_leaves[persistent=true]
fill 337 143 301 337 150 301 minecraft:dirt
fill 337 143 303 337 150 303 minecraft:dirt
setblock 339 143 278 minecraft:light[level=12]
setblock 339 143 285 minecraft:light[level=12]
setblock 339 143 292 minecraft:light[level=12]
setblock 339 143 299 minecraft:light[level=12]
setblock 339 143 306 minecraft:light[level=12]
setblock 339 143 313 minecraft:light[level=12]
fill 341 143 286 341 146 286 minecraft:dirt
fill 341 143 289 341 146 289 minecraft:dirt
fill 342 143 290 342 146 290 minecraft:dirt
fill 345 143 287 345 146 287 minecraft:dirt
fill 345 143 289 345 146 289 minecraft:dirt
setblock 346 143 278 minecraft:light[level=12]
setblock 346 143 285 minecraft:light[level=12]
setblock 346 143 299 minecraft:light[level=12]
setblock 346 143 306 minecraft:light[level=12]
setblock 346 143 313 minecraft:light[level=12]
fill 352 143 282 352 145 282 minecraft:white_concrete
setblock 353 143 278 minecraft:light[level=12]
setblock 353 143 285 minecraft:light[level=12]
setblock 353 143 292 minecraft:light[level=12]
setblock 353 143 299 minecraft:light[level=12]
setblock 353 143 306 minecraft:light[level=12]
setblock 353 143 313 minecraft:light[level=12]
fill 356 143 275 356 150 275 minecraft:light_blue_terracotta
setblock 360 143 278 minecraft:light[level=12]
setblock 360 143 285 minecraft:light[level=12]
setblock 360 143 292 minecraft:light[level=12]
setblock 360 143 299 minecraft:light[level=12]
setblock 360 143 306 minecraft:light[level=12]
setblock 360 143 313 minecraft:light[level=12]
setblock 367 143 278 minecraft:light[level=12]
setblock 367 143 285 minecraft:light[level=12]
setblock 367 143 292 minecraft:light[level=12]
setblock 367 143 299 minecraft:light[level=12]
setblock 367 143 306 minecraft:light[level=12]
setblock 367 143 313 minecraft:light[level=12]
fill 329 144 280 329 176 280 minecraft:light_blue_terracotta
fill 331 144 275 334 154 275 minecraft:light_blue_terracotta
fill 334 144 301 334 150 303 minecraft:dirt
setblock 335 144 275 minecraft:white_wool
fill 335 144 300 336 150 300 minecraft:dirt
setblock 335 144 307 minecraft:oak_leaves[persistent=true]
fill 336 144 275 337 214 275 minecraft:light_blue_terracotta
fill 336 144 308 337 144 308 minecraft:oak_leaves[persistent=true]
fill 338 144 302 338 150 302 minecraft:dirt
setblock 338 144 304 minecraft:oak_leaves[persistent=true]
fill 339 144 305 339 144 306 minecraft:oak_leaves[persistent=true]
fill 340 144 287 340 146 289 minecraft:dirt
fill 341 144 290 341 146 290 minecraft:dirt
fill 342 144 285 344 146 285 minecraft:dirt
fill 345 144 286 345 146 286 minecraft:dirt
fill 346 144 288 346 146 288 minecraft:dirt
fill 360 144 275 362 177 275 minecraft:light_blue_terracotta
setblock 363 144 275 minecraft:white_wool
fill 364 144 275 364 150 275 minecraft:light_blue_terracotta
setblock 371 144 283 minecraft:white_wool
fill 371 144 284 371 218 284 minecraft:light_blue_terracotta
fill 329 145 275 329 214 275 minecraft:light_blue_terracotta
setblock 329 145 285 minecraft:white_wool
fill 329 145 286 329 146 289 minecraft:light_blue_terracotta
setblock 330 145 275 minecraft:white_wool
setblock 332 145 278 minecraft:light[level=15]
setblock 332 145 286 minecraft:light[level=15]
setblock 332 145 294 minecraft:light[level=15]
setblock 332 145 302 minecraft:light[level=15]
setblock 332 145 310 minecraft:light[level=15]
fill 334 145 300 334 150 300 minecraft:dirt
fill 335 145 275 335 155 275 minecraft:light_blue_terracotta
fill 335 145 304 335 150 304 minecraft:dirt
fill 337 145 300 337 150 300 minecraft:dirt
fill 338 145 301 338 150 301 minecraft:dirt
fill 338 145 303 338 150 303 minecraft:dirt
setblock 340 145 278 minecraft:light[level=15]
fill 340 145 286 340 146 286 minecraft:dirt
fill 340 145 290 340 146 290 minecraft:dirt
setblock 340 145 294 minecraft:light[level=15]
setblock 340 145 302 minecraft:light[level=15]
setblock 340 145 310 minecraft:light[level=15]
fill 341 145 285 341 146 285 minecraft:dirt
fill 342 145 291 342 146 291 minecraft:dirt
fill 345 145 285 345 146 285 minecraft:dirt
fill 346 145 286 346 146 287 minecraft:dirt
fill 346 145 289 346 146 289 minecraft:dirt
setblock 348 145 278 minecraft:light[level=15]
setblock 348 145 286 minecraft:light[level=15]
setblock 348 145 294 minecraft:light[level=15]
setblock 348 145 302 minecraft:light[level=15]
setblock 348 145 310 minecraft:light[level=15]
setblock 356 145 278 minecraft:light[level=15]
setblock 356 145 286 minecraft:light[level=15]
setblock 356 145 294 minecraft:light[level=15]
setblock 356 145 302 minecraft:light[level=15]
setblock 356 145 310 minecraft:light[level=15]
fill 363 145 275 363 215 275 minecraft:light_blue_terracotta
setblock 364 145 278 minecraft:light[level=15]
setblock 364 145 286 minecraft:light[level=15]
setblock 364 145 294 minecraft:light[level=15]
setblock 364 145 302 minecraft:light[level=15]
setblock 364 145 310 minecraft:light[level=15]
fill 371 145 283 371 218 283 minecraft:light_blue_terracotta
fill 329 146 276 329 216 276 minecraft:light_blue_terracotta
setblock 329 146 277 minecraft:white_wool
fill 329 146 278 329 177 279 minecraft:light_blue_terracotta
fill 329 146 285 329 218 285 minecraft:light_blue_terracotta
setblock 329 146 290 minecraft:white_wool
fill 330 146 275 330 149 275 minecraft:light_blue_terracotta
fill 333 146 301 333 150 303 minecraft:dirt
fill 334 146 304 334 150 304 minecraft:dirt
fill 335 146 299 337 150 299 minecraft:dirt
fill 335 146 305 336 150 305 minecraft:dirt
fill 336 146 304 338 150 304 minecraft:dirt
fill 338 146 300 338 150 300 minecraft:dirt
fill 339 146 287 339 146 289 minecraft:dirt
fill 339 146 302 339 150 302 minecraft:dirt
setblock 340 146 285 minecraft:dirt
setblock 341 146 291 minecraft:dirt
fill 342 146 284 344 146 284 minecraft:dirt
setblock 347 146 288 minecraft:dirt
fill 350 146 282 353 148 283 minecraft:oak_leaves[persistent=true]
fill 351 146 281 353 148 281 minecraft:oak_leaves[persistent=true]
fill 351 146 284 352 148 284 minecraft:oak_leaves[persistent=true]
fill 353 146 317 353 218 317 minecraft:light_blue_terracotta
setblock 354 146 317 minecraft:white_wool
fill 355 146 317 356 155 317 minecraft:light_blue_terracotta
fill 360 146 285 360 149 285 minecraft:white_wool
setblock 371 146 312 minecraft:white_wool
fill 329 147 277 329 163 277 minecraft:light_blue_terracotta
fill 329 147 286 329 218 286 minecraft:light_blue_terracotta
setblock 329 147 287 minecraft:white_wool
fill 329 147 288 329 188 290 minecraft:light_blue_terracotta
fill 333 147 300 333 150 300 minecraft:dirt
fill 333 147 304 333 150 304 minecraft:dirt
fill 334 147 299 334 150 299 minecraft:dirt
fill 334 147 305 334 150 305 minecraft:dirt
fill 337 147 305 337 150 305 minecraft:dirt
fill 338 147 299 338 150 299 minecraft:dirt
fill 339 147 301 339 150 301 minecraft:dirt
fill 339 147 303 339 150 303 minecraft:dirt
fill 343 147 288 343 150 288 minecraft:iron_block
setblock 350 147 281 minecraft:oak_leaves[persistent=true]
fill 351 147 280 352 147 280 minecraft:oak_leaves[persistent=true]
setblock 353 147 284 minecraft:oak_leaves[persistent=true]
fill 354 147 282 354 147 283 minecraft:oak_leaves[persistent=true]
fill 354 147 317 354 186 317 minecraft:light_blue_terracotta
fill 358 147 283 359 147 285 minecraft:white_wool
fill 359 147 282 361 147 282 minecraft:white_wool
fill 360 147 283 362 148 284 minecraft:white_wool
fill 360 147 286 362 148 286 minecraft:white_wool
fill 361 147 285 362 148 285 minecraft:white_wool
fill 371 147 312 371 218 312 minecraft:light_blue_terracotta
setblock 329 148 283 minecraft:white_wool
fill 329 148 284 329 155 284 minecraft:light_blue_terracotta
fill 329 148 287 329 159 287 minecraft:light_blue_terracotta
fill 332 148 301 332 150 303 minecraft:dirt
fill 333 148 299 333 150 299 minecraft:dirt
fill 335 148 298 337 150 298 minecraft:dirt
fill 335 148 306 336 150 306 minecraft:dirt
fill 338 148 305 338 150 305 minecraft:dirt
fill 339 148 300 339 150 300 minecraft:dirt
fill 339 148 304 339 150 304 minecraft:dirt
fill 340 148 302 340 150 302 minecraft:dirt
fill 358 148 284 359 148 285 minecraft:white_wool
setblock 359 148 283 minecraft:white_wool
setblock 359 148 286 minecraft:white_wool
fill 360 148 282 362 148 282 minecraft:white_wool
fill 329 149 283 329 205 283 minecraft:light_blue_terracotta
setblock 332 149 278 minecraft:light[level=12]
setblock 332 149 285 minecraft:light[level=12]
setblock 332 149 292 minecraft:light[level=12]
setblock 332 149 299 minecraft:light[level=12]
fill 332 149 300 332 150 300 minecraft:dirt
fill 332 149 304 332 150 304 minecraft:dirt
setblock 332 149 306 minecraft:light[level=12]
setblock 332 149 313 minecraft:light[level=12]
fill 333 149 305 333 150 305 minecraft:dirt
fill 334 149 298 334 150 298 minecraft:dirt
fill 334 149 306 334 150 306 minecraft:dirt
fill 337 149 306 338 150 306 minecraft:dirt
fill 338 149 298 338 150 298 minecraft:dirt
setblock 339 149 278 minecraft:light[level=12]
setblock 339 149 285 minecraft:light[level=12]
setblock 339 149 292 minecraft:light[level=12]
fill 339 149 299 339 150 299 minecraft:dirt
fill 339 149 305 339 150 305 minecraft:dirt
setblock 339 149 306 minecraft:light[level=12]
setblock 339 149 313 minecraft:light[level=12]
fill 340 149 300 340 150 301 minecraft:dirt
fill 340 149 303 340 150 304 minecraft:dirt
setblock 346 149 278 minecraft:light[level=12]
setblock 346 149 285 minecraft:light[level=12]
setblock 346 149 299 minecraft:light[level=12]
setblock 346 149 306 minecraft:light[level=12]
setblock 346 149 313 minecraft:light[level=12]
setblock 353 149 278 minecraft:light[level=12]
setblock 353 149 285 minecraft:light[level=12]
setblock 353 149 292 minecraft:light[level=12]
setblock 353 149 299 minecraft:light[level=12]
setblock 353 149 306 minecraft:light[level=12]
setblock 353 149 313 minecraft:light[level=12]
setblock 360 149 278 minecraft:light[level=12]
setblock 360 149 284 minecraft:white_wool
setblock 360 149 292 minecraft:light[level=12]
setblock 360 149 299 minecraft:light[level=12]
setblock 360 149 306 minecraft:light[level=12]
setblock 360 149 313 minecraft:light[level=12]
setblock 365 149 317 minecraft:white_wool
setblock 367 149 278 minecraft:light[level=12]
setblock 367 149 285 minecraft:light[level=12]
setblock 367 149 292 minecraft:light[level=12]
setblock 367 149 299 minecraft:light[level=12]
setblock 367 149 306 minecraft:light[level=12]
setblock 367 149 313 minecraft:light[level=12]
setblock 371 149 276 minecraft:white_wool
setblock 330 150 275 minecraft:white_wool
fill 331 150 301 331 150 303 minecraft:dirt
setblock 332 150 299 minecraft:dirt
setblock 332 150 305 minecraft:dirt
setblock 333 150 298 minecraft:dirt
setblock 333 150 306 minecraft:dirt
fill 335 150 297 337 150 297 minecraft:dirt
fill 335 150 307 336 150 307 minecraft:dirt
setblock 339 150 298 minecraft:dirt
setblock 339 150 306 minecraft:dirt
setblock 340 150 299 minecraft:dirt
fill 365 150 317 365 187 317 minecraft:light_blue_terracotta
fill 371 150 276 371 215 276 minecraft:light_blue_terracotta
setblock 371 150 300 minecraft:white_wool
fill 330 151 275 330 202 275 minecraft:light_blue_terracotta
fill 336 151 302 336 154 302 minecraft:iron_block
setblock 343 151 288 minecraft:ochre_froglight
setblock 356 151 275 minecraft:white_wool
setblock 358 151 317 minecraft:white_wool
setblock 364 151 275 minecraft:white_wool
fill 371 151 300 371 167 300 minecraft:light_blue_terracotta
fill 333 152 317 333 220 317 minecraft:light_blue_terracotta
setblock 334 152 317 minecraft:white_wool
fill 335 152 317 335 218 317 minecraft:light_blue_terracotta
fill 356 152 275 356 218 275 minecraft:light_blue_terracotta
fill 358 152 317 358 211 317 minecraft:light_blue_terracotta
fill 364 152 275 364 209 275 minecraft:light_blue_terracotta
setblock 332 153 278 minecraft:light[level=15]
setblock 332 153 286 minecraft:light[level=15]
setblock 332 153 294 minecraft:light[level=15]
setblock 332 153 302 minecraft:light[level=15]
setblock 332 153 310 minecraft:light[level=15]
fill 334 153 317 334 215 317 minecraft:light_blue_terracotta
setblock 340 153 278 minecraft:light[level=15]
setblock 340 153 286 minecraft:light[level=15]
setblock 340 153 294 minecraft:light[level=15]
setblock 340 153 302 minecraft:light[level=15]
setblock 340 153 310 minecraft:light[level=15]
setblock 348 153 278 minecraft:light[level=15]
setblock 348 153 286 minecraft:light[level=15]
setblock 348 153 294 minecraft:light[level=15]
setblock 348 153 302 minecraft:light[level=15]
setblock 348 153 310 minecraft:light[level=15]
setblock 356 153 278 minecraft:light[level=15]
setblock 356 153 286 minecraft:light[level=15]
setblock 356 153 294 minecraft:light[level=15]
setblock 356 153 302 minecraft:light[level=15]
setblock 356 153 310 minecraft:light[level=15]
setblock 364 153 278 minecraft:light[level=15]
setblock 364 153 286 minecraft:light[level=15]
setblock 364 153 294 minecraft:light[level=15]
setblock 364 153 302 minecraft:light[level=15]
setblock 364 153 310 minecraft:light[level=15]
fill 345 154 311 345 156 311 minecraft:white_wool
fill 346 154 312 346 157 312 minecraft:white_wool
fill 353 154 305 354 155 305 minecraft:white_concrete
fill 331 155 275 333 177 275 minecraft:light_blue_terracotta
setblock 332 155 278 minecraft:light[level=12]
setblock 332 155 285 minecraft:light[level=12]
setblock 332 155 292 minecraft:light[level=12]
setblock 332 155 299 minecraft:light[level=12]
setblock 332 155 306 minecraft:light[level=12]
setblock 332 155 313 minecraft:light[level=12]
fill 333 155 297 333 156 297 minecraft:white_wool
setblock 334 155 275 minecraft:white_wool
setblock 336 155 302 minecraft:ochre_froglight
setblock 339 155 278 minecraft:light[level=12]
setblock 339 155 285 minecraft:light[level=12]
setblock 339 155 292 minecraft:light[level=12]
setblock 339 155 299 minecraft:light[level=12]
setblock 339 155 306 minecraft:light[level=12]
setblock 339 155 313 minecraft:light[level=12]
fill 344 155 311 344 156 313 minecraft:white_wool
fill 345 155 310 347 156 310 minecraft:white_wool
fill 345 155 312 345 156 313 minecraft:white_wool
setblock 346 155 278 minecraft:light[level=12]
setblock 346 155 285 minecraft:light[level=12]
setblock 346 155 292 minecraft:light[level=12]
setblock 346 155 299 minecraft:light[level=12]
setblock 346 155 306 minecraft:light[level=12]
fill 346 155 311 348 156 311 minecraft:white_wool
fill 346 155 313 348 156 313 minecraft:white_wool
fill 347 155 312 348 156 312 minecraft:white_wool
fill 347 155 314 348 155 314 minecraft:white_wool
setblock 353 155 278 minecraft:light[level=12]
setblock 353 155 285 minecraft:light[level=12]
setblock 353 155 292 minecraft:light[level=12]
setblock 353 155 299 minecraft:light[level=12]
setblock 353 155 306 minecraft:light[level=12]
setblock 353 155 313 minecraft:light[level=12]
fill 359 155 309 359 156 309 minecraft:ochre_froglight
setblock 360 155 278 minecraft:light[level=12]
setblock 360 155 285 minecraft:light[level=12]
setblock 360 155 292 minecraft:light[level=12]
setblock 360 155 299 minecraft:light[level=12]
setblock 360 155 306 minecraft:light[level=12]
setblock 360 155 313 minecraft:light[level=12]
setblock 360 155 317 minecraft:white_wool
setblock 367 155 278 minecraft:light[level=12]
setblock 367 155 285 minecraft:light[level=12]
setblock 367 155 292 minecraft:light[level=12]
setblock 367 155 299 minecraft:light[level=12]
setblock 367 155 306 minecraft:light[level=12]
setblock 367 155 313 minecraft:light[level=12]
setblock 371 155 293 minecraft:white_wool
setblock 329 156 284 minecraft:white_wool
fill 329 156 297 329 180 299 minecraft:light_blue_terracotta
setblock 329 156 300 minecraft:white_wool
fill 334 156 275 334 218 275 minecraft:light_blue_terracotta
setblock 335 156 275 minecraft:white_wool
setblock 344 156 275 minecraft:white_wool
fill 345 156 275 349 177 275 minecraft:light_blue_terracotta
fill 346 156 314 347 156 314 minecraft:white_wool
setblock 348 156 310 minecraft:white_wool
fill 355 156 317 355 163 317 minecraft:light_blue_terracotta
setblock 356 156 317 minecraft:white_wool
fill 360 156 317 360 218 317 minecraft:light_blue_terracotta
setblock 361 156 317 minecraft:white_wool
setblock 371 156 288 minecraft:white_wool
fill 371 156 289 371 193 291 minecraft:light_blue_terracotta
fill 371 156 293 371 196 293 minecraft:light_blue_terracotta
fill 329 157 284 329 213 284 minecraft:light_blue_terracotta
fill 329 157 300 329 192 300 minecraft:light_blue_terracotta
fill 335 157 275 335 214 275 minecraft:light_blue_terracotta
fill 341 157 293 341 158 294 minecraft:white_wool
fill 343 157 287 343 158 287 minecraft:ochre_froglight
fill 344 157 275 344 208 275 minecraft:light_blue_terracotta
setblock 346 157 313 minecraft:white_wool
fill 356 157 317 356 218 317 minecraft:light_blue_terracotta
fill 359 157 309 359 164 309 minecraft:dirt
fill 361 157 317 361 179 317 minecraft:light_blue_terracotta
fill 371 157 288 371 218 288 minecraft:light_blue_terracotta
fill 333 158 287 335 159 288 minecraft:white_concrete
setblock 329 159 282 minecraft:white_wool
fill 340 159 317 340 218 317 minecraft:light_blue_terracotta
setblock 341 159 317 minecraft:white_wool
fill 342 159 317 344 174 317 minecraft:light_blue_terracotta
fill 343 159 287 343 167 287 minecraft:dirt
fill 358 159 309 358 164 309 minecraft:dirt
fill 359 159 308 359 164 308 minecraft:dirt
fill 359 159 310 359 164 310 minecraft:dirt
fill 360 159 309 360 164 309 minecraft:dirt
fill 329 160 282 329 208 282 minecraft:light_blue_terracotta
setblock 329 160 287 minecraft:white_wool
fill 341 160 317 341 215 317 minecraft:light_blue_terracotta
fill 344 160 287 344 167 287 minecraft:dirt
fill 358 160 308 358 164 308 minecraft:dirt
fill 358 160 310 358 164 310 minecraft:dirt
fill 360 160 308 360 164 308 minecraft:dirt
fill 360 160 310 360 164 310 minecraft:dirt
fill 329 161 287 329 218 287 minecraft:light_blue_terracotta
setblock 332 161 278 minecraft:light[level=15]
setblock 332 161 285 minecraft:light[level=12]
setblock 332 161 286 minecraft:light[level=15]
setblock 332 161 292 minecraft:light[level=12]
setblock 332 161 294 minecraft:light[level=15]
setblock 332 161 299 minecraft:light[level=12]
setblock 332 161 302 minecraft:light[level=15]
setblock 332 161 306 minecraft:light[level=12]
setblock 332 161 310 minecraft:light[level=15]
setblock 332 161 313 minecraft:light[level=12]
setblock 339 161 278 minecraft:light[level=12]
setblock 339 161 285 minecraft:light[level=12]
setblock 339 161 292 minecraft:light[level=12]
setblock 339 161 299 minecraft:light[level=12]
setblock 339 161 306 minecraft:light[level=12]
setblock 339 161 313 minecraft:light[level=12]
setblock 340 161 278 minecraft:light[level=15]
setblock 340 161 286 minecraft:light[level=15]
setblock 340 161 294 minecraft:light[level=15]
setblock 340 161 302 minecraft:light[level=15]
setblock 340 161 310 minecraft:light[level=15]
fill 343 161 286 344 167 286 minecraft:dirt
fill 343 161 288 344 167 288 minecraft:dirt
setblock 346 161 278 minecraft:light[level=12]
setblock 346 161 285 minecraft:light[level=12]
setblock 346 161 292 minecraft:light[level=12]
setblock 346 161 299 minecraft:light[level=12]
setblock 346 161 306 minecraft:light[level=12]
setblock 346 161 313 minecraft:light[level=12]
setblock 348 161 278 minecraft:light[level=15]
setblock 348 161 286 minecraft:light[level=15]
setblock 348 161 294 minecraft:light[level=15]
setblock 348 161 302 minecraft:light[level=15]
setblock 348 161 310 minecraft:light[level=15]
setblock 353 161 278 minecraft:light[level=12]
setblock 353 161 285 minecraft:light[level=12]
setblock 353 161 292 minecraft:light[level=12]
setblock 353 161 299 minecraft:light[level=12]
setblock 353 161 306 minecraft:light[level=12]
setblock 353 161 313 minecraft:light[level=12]
setblock 356 161 278 minecraft:light[level=15]
setblock 356 161 286 minecraft:light[level=15]
setblock 356 161 294 minecraft:light[level=15]
setblock 356 161 302 minecraft:light[level=15]
setblock 356 161 310 minecraft:light[level=15]
fill 357 161 309 357 164 309 minecraft:dirt
fill 359 161 311 359 164 311 minecraft:dirt
setblock 360 161 278 minecraft:light[level=12]
setblock 360 161 285 minecraft:light[level=12]
setblock 360 161 292 minecraft:light[level=12]
setblock 360 161 299 minecraft:light[level=12]
setblock 360 161 306 minecraft:light[level=12]
setblock 360 161 313 minecraft:light[level=12]
setblock 364 161 278 minecraft:light[level=15]
setblock 364 161 286 minecraft:light[level=15]
setblock 364 161 294 minecraft:light[level=15]
setblock 364 161 302 minecraft:light[level=15]
setblock 364 161 310 minecraft:light[level=15]
setblock 367 161 278 minecraft:light[level=12]
setblock 367 161 285 minecraft:light[level=12]
setblock 367 161 292 minecraft:light[level=12]
setblock 367 161 299 minecraft:light[level=12]
setblock 367 161 306 minecraft:light[level=12]
setblock 367 161 313 minecraft:light[level=12]
setblock 371 161 278 minecraft:white_wool
setblock 329 162 296 minecraft:white_wool
fill 342 162 287 342 167 288 minecraft:dirt
fill 345 162 287 345 167 287 minecraft:dirt
fill 357 162 308 357 164 308 minecraft:dirt
fill 357 162 310 357 164 310 minecraft:dirt
fill 358 162 307 360 164 307 minecraft:dirt
fill 358 162 311 358 164 311 minecraft:dirt
fill 360 162 300 362 165 300 minecraft:packed_mud
fill 360 162 311 360 164 311 minecraft:dirt
fill 361 162 298 362 164 299 minecraft:packed_mud
fill 361 162 301 362 164 301 minecraft:packed_mud
fill 361 162 308 361 164 310 minecraft:dirt
fill 371 162 278 371 199 278 minecraft:light_blue_terracotta
fill 329 163 296 329 218 296 minecraft:light_blue_terracotta
fill 342 163 286 342 167 286 minecraft:dirt
fill 343 163 285 344 167 285 minecraft:dirt
fill 343 163 289 344 167 289 minecraft:dirt
fill 345 163 286 345 167 286 minecraft:dirt
fill 345 163 288 345 167 288 minecraft:dirt
fill 350 163 308 350 165 310 minecraft:packed_mud
fill 351 163 308 352 165 309 minecraft:packed_mud
fill 352 163 307 352 165 307 minecraft:packed_mud
fill 357 163 307 357 164 307 minecraft:dirt
fill 357 163 311 357 164 311 minecraft:dirt
fill 359 163 300 359 164 300 minecraft:packed_mud
fill 359 163 312 359 164 312 minecraft:dirt
fill 360 163 298 360 164 299 minecraft:packed_mud
fill 360 163 301 360 165 301 minecraft:packed_mud
setblock 361 163 302 minecraft:packed_mud
fill 361 163 307 361 164 307 minecraft:dirt
fill 361 163 311 361 164 311 minecraft:dirt
setblock 329 164 277 minecraft:white_wool
fill 334 164 303 334 165 304 minecraft:white_concrete
fill 341 164 286 341 167 288 minecraft:dirt
fill 342 164 285 342 167 285 minecraft:dirt
fill 342 164 289 342 167 289 minecraft:dirt
fill 345 164 285 345 167 285 minecraft:dirt
fill 345 164 289 345 167 289 minecraft:dirt
fill 346 164 287 346 167 287 minecraft:dirt
fill 349 164 308 349 165 309 minecraft:packed_mud
fill 350 164 307 351 166 307 minecraft:packed_mud
fill 351 164 310 351 166 310 minecraft:packed_mud
setblock 355 164 317 minecraft:white_wool
fill 356 164 308 356 164 310 minecraft:dirt
fill 358 164 306 360 164 306 minecraft:dirt
setblock 358 164 312 minecraft:dirt
setblock 359 164 299 minecraft:packed_mud
setblock 360 164 312 minecraft:dirt
fill 362 164 308 362 164 310 minecraft:dirt
setblock 363 164 300 minecraft:packed_mud
setblock 371 164 285 minecraft:white_wool
fill 371 164 286 371 200 286 minecraft:light_blue_terracotta
fill 329 165 277 329 218 277 minecraft:light_blue_terracotta
fill 341 165 285 341 167 285 minecraft:dirt
fill 341 165 289 341 167 289 minecraft:dirt
fill 343 165 284 344 167 284 minecraft:dirt
fill 343 165 290 344 167 290 minecraft:dirt
fill 346 165 286 346 167 286 minecraft:dirt
fill 346 165 288 346 167 288 minecraft:dirt
setblock 350 165 275 minecraft:white_wool
fill 352 165 310 352 166 310 minecraft:packed_mud
fill 355 165 317 355 166 317 minecraft:light_blue_terracotta
fill 359 165 299 359 165 301 minecraft:moss_block
fill 359 165 309 359 168 309 minecraft:white_concrete
fill 360 165 298 362 166 298 minecraft:moss_block
fill 360 165 299 362 165 299 minecraft:packed_mud
fill 360 165 302 362 166 302 minecraft:moss_block
fill 361 165 301 363 165 301 minecraft:moss_block
fill 363 165 299 363 166 300 minecraft:moss_block
fill 371 165 285 371 219 285 minecraft:light_blue_terracotta
fill 340 166 286 340 167 288 minecraft:dirt
fill 342 166 284 342 167 284 minecraft:dirt
fill 342 166 290 342 167 290 minecraft:dirt
fill 345 166 284 345 167 284 minecraft:dirt
fill 345 166 290 345 167 290 minecraft:dirt
fill 346 166 285 346 167 285 minecraft:dirt
fill 346 166 289 346 167 289 minecraft:dirt
fill 347 166 287 347 167 287 minecraft:dirt
fill 349 166 308 349 166 310 minecraft:moss_block
fill 350 166 275 350 218 275 minecraft:light_blue_terracotta
fill 350 166 308 351 166 309 minecraft:packed_mud
fill 350 166 310 350 167 310 minecraft:moss_block
fill 352 166 307 352 167 308 minecraft:moss_block
setblock 352 166 309 minecraft:packed_mud
setblock 353 166 308 minecraft:moss_block
fill 359 166 299 362 166 300 minecraft:moss_block
fill 360 166 301 362 166 301 minecraft:moss_block
setblock 329 167 281 minecraft:white_wool
setblock 332 167 278 minecraft:light[level=12]
setblock 332 167 285 minecraft:light[level=12]
fill 332 167 289 333 168 290 minecraft:white_wool
setblock 332 167 292 minecraft:light[level=12]
setblock 332 167 299 minecraft:light[level=12]
setblock 332 167 306 minecraft:light[level=12]
setblock 332 167 313 minecraft:light[level=12]
setblock 337 167 317 minecraft:white_wool
setblock 339 167 278 minecraft:light[level=12]
setblock 339 167 285 minecraft:light[level=12]
setblock 339 167 292 minecraft:light[level=12]
setblock 339 167 299 minecraft:light[level=12]
setblock 339 167 306 minecraft:light[level=12]
setblock 339 167 313 minecraft:light[level=12]
setblock 340 167 285 minecraft:dirt
setblock 340 167 289 minecraft:dirt
setblock 341 167 284 minecraft:dirt
setblock 341 167 290 minecraft:dirt
fill 343 167 283 344 167 283 minecraft:dirt
setblock 343 167 291 minecraft:dirt
setblock 346 167 278 minecraft:light[level=12]
setblock 346 167 284 minecraft:dirt
setblock 346 167 290 minecraft:dirt
setblock 346 167 292 minecraft:light[level=12]
setblock 346 167 299 minecraft:light[level=12]
setblock 346 167 306 minecraft:light[level=12]
setblock 346 167 313 minecraft:light[level=12]
setblock 347 167 286 minecraft:dirt
setblock 347 167 288 minecraft:dirt
fill 349 167 307 351 167 309 minecraft:moss_block
setblock 350 167 306 minecraft:moss_block
fill 351 167 310 352 167 310 minecraft:moss_block
fill 352 167 309 353 167 309 minecraft:moss_block
setblock 353 167 278 minecraft:light[level=12]
setblock 353 167 285 minecraft:light[level=12]
setblock 353 167 292 minecraft:light[level=12]
setblock 353 167 299 minecraft:light[level=12]
setblock 353 167 306 minecraft:light[level=12]
setblock 353 167 313 minecraft:light[level=12]
setblock 355 167 317 minecraft:white_wool
setblock 360 167 278 minecraft:light[level=12]
setblock 360 167 285 minecraft:light[level=12]
setblock 360 167 292 minecraft:light[level=12]
setblock 360 167 299 minecraft:light[level=12]
setblock 360 167 306 minecraft:light[level=12]
setblock 360 167 313 minecraft:light[level=12]
setblock 367 167 278 minecraft:light[level=12]
setblock 367 167 285 minecraft:light[level=12]
setblock 367 167 292 minecraft:light[level=12]
setblock 367 167 299 minecraft:light[level=12]
setblock 367 167 306 minecraft:light[level=12]
setblock 367 167 313 minecraft:light[level=12]
fill 329 168 281 329 215 281 minecraft:light_blue_terracotta
fill 329 168 291 329 182 293 minecraft:light_blue_terracotta
setblock 329 168 294 minecraft:white_wool
fill 337 168 317 337 211 317 minecraft:light_blue_terracotta
fill 343 168 287 343 170 287 minecraft:white_concrete
fill 355 168 317 355 209 317 minecraft:light_blue_terracotta
fill 357 168 309 358 170 309 minecraft:oak_leaves[persistent=true]
fill 358 168 308 360 170 308 minecraft:oak_leaves[persistent=true]
fill 358 168 310 360 170 310 minecraft:oak_leaves[persistent=true]
fill 359 168 311 359 170 311 minecraft:oak_leaves[persistent=true]
fill 360 168 309 360 170 309 minecraft:oak_leaves[persistent=true]
fill 371 168 297 371 218 297 minecraft:light_blue_terracotta
setblock 371 168 298 minecraft:white_wool
fill 371 168 299 371 218 299 minecraft:light_blue_terracotta
setblock 371 168 300 minecraft:white_wool
fill 329 169 294 329 219 294 minecraft:light_blue_terracotta
setblock 332 169 278 minecraft:light[level=15]
setblock 332 169 286 minecraft:light[level=15]
setblock 332 169 294 minecraft:light[level=15]
setblock 332 169 302 minecraft:light[level=15]
setblock 332 169 310 minecraft:light[level=15]
setblock 340 169 278 minecraft:light[level=15]
setblock 340 169 286 minecraft:light[level=15]
setblock 340 169 294 minecraft:light[level=15]
setblock 340 169 302 minecraft:light[level=15]
setblock 340 169 310 minecraft:light[level=15]
setblock 348 169 278 minecraft:light[level=15]
setblock 348 169 286 minecraft:light[level=15]
setblock 348 169 294 minecraft:light[level=15]
setblock 348 169 302 minecraft:light[level=15]
setblock 348 169 310 minecraft:light[level=15]
setblock 356 169 278 minecraft:light[level=15]
setblock 356 169 286 minecraft:light[level=15]
setblock 356 169 294 minecraft:light[level=15]
setblock 356 169 302 minecraft:light[level=15]
setblock 356 169 310 minecraft:light[level=15]
setblock 357 169 308 minecraft:oak_leaves[persistent=true]
setblock 357 169 310 minecraft:oak_leaves[persistent=true]
fill 358 169 307 360 169 307 minecraft:oak_leaves[persistent=true]
setblock 358 169 311 minecraft:oak_leaves[persistent=true]
fill 359 169 309 359 170 309 minecraft:oak_leaves[persistent=true]
setblock 360 169 311 minecraft:oak_leaves[persistent=true]
fill 361 169 308 361 169 310 minecraft:oak_leaves[persistent=true]
setblock 364 169 278 minecraft:light[level=15]
setblock 364 169 286 minecraft:light[level=15]
setblock 364 169 294 minecraft:light[level=15]
setblock 364 169 302 minecraft:light[level=15]
setblock 364 169 310 minecraft:light[level=15]
fill 371 169 298 371 218 298 minecraft:light_blue_terracotta
fill 371 169 300 371 184 300 minecraft:light_blue_terracotta
fill 366 170 296 367 171 296 minecraft:white_wool
fill 342 171 286 345 173 288 minecraft:oak_leaves[persistent=true]
fill 342 171 305 342 173 305 minecraft:white_wool
fill 343 171 289 343 173 289 minecraft:oak_leaves[persistent=true]
fill 339 172 304 341 173 307 minecraft:white_wool
fill 340 172 303 341 172 303 minecraft:white_wool
fill 340 172 308 342 172 308 minecraft:white_wool
setblock 341 172 287 minecraft:oak_leaves[persistent=true]
setblock 342 172 289 minecraft:oak_leaves[persistent=true]
fill 342 172 304 342 173 304 minecraft:white_wool
fill 342 172 306 342 173 307 minecraft:white_wool
fill 343 172 285 344 172 285 minecraft:oak_leaves[persistent=true]
fill 343 172 305 343 173 306 minecraft:white_wool
setblock 344 172 289 minecraft:oak_leaves[persistent=true]
fill 346 172 309 347 173 310 minecraft:white_concrete
fill 349 172 283 349 173 283 minecraft:white_wool
setblock 332 173 278 minecraft:light[level=12]
setblock 332 173 285 minecraft:light[level=12]
setblock 332 173 292 minecraft:light[level=12]
setblock 332 173 299 minecraft:light[level=12]
setblock 332 173 306 minecraft:light[level=12]
setblock 332 173 313 minecraft:light[level=12]
fill 337 173 290 337 174 290 minecraft:ochre_froglight
fill 338 173 305 338 173 306 minecraft:white_wool
setblock 339 173 278 minecraft:light[level=12]
setblock 339 173 285 minecraft:light[level=12]
setblock 339 173 292 minecraft:light[level=12]
setblock 339 173 299 minecraft:light[level=12]
setblock 339 173 313 minecraft:light[level=12]
fill 341 173 303 342 173 303 minecraft:white_wool
fill 341 173 308 342 173 308 minecraft:white_wool
setblock 343 173 307 minecraft:white_wool
setblock 346 173 278 minecraft:light[level=12]
setblock 346 173 285 minecraft:light[level=12]
setblock 346 173 292 minecraft:light[level=12]
setblock 346 173 299 minecraft:light[level=12]
setblock 346 173 306 minecraft:light[level=12]
setblock 346 173 313 minecraft:light[level=12]
setblock 351 173 317 minecraft:white_wool
setblock 353 173 278 minecraft:light[level=12]
setblock 353 173 285 minecraft:light[level=12]
setblock 353 173 292 minecraft:light[level=12]
setblock 353 173 299 minecraft:light[level=12]
setblock 353 173 306 minecraft:light[level=12]
setblock 353 173 313 minecraft:light[level=12]
setblock 360 173 278 minecraft:light[level=12]
setblock 360 173 285 minecraft:light[level=12]
setblock 360 173 292 minecraft:light[level=12]
setblock 360 173 299 minecraft:light[level=12]
setblock 360 173 306 minecraft:light[level=12]
setblock 360 173 313 minecraft:light[level=12]
fill 366 173 317 367 174 317 minecraft:light_blue_terracotta
setblock 367 173 278 minecraft:light[level=12]
setblock 367 173 285 minecraft:light[level=12]
setblock 367 173 292 minecraft:light[level=12]
setblock 367 173 299 minecraft:light[level=12]
setblock 367 173 306 minecraft:light[level=12]
setblock 367 173 313 minecraft:light[level=12]
setblock 368 173 317 minecraft:white_wool
fill 369 173 317 370 186 317 minecraft:light_blue_terracotta
fill 351 174 317 351 218 317 minecraft:light_blue_terracotta
fill 368 174 317 368 218 317 minecraft:light_blue_terracotta
fill 337 175 290 337 184 290 minecraft:dirt
setblock 342 175 317 minecraft:white_wool
fill 343 175 317 344 218 317 minecraft:light_blue_terracotta
fill 366 175 317 366 215 317 minecraft:light_blue_terracotta
setblock 367 175 317 minecraft:white_wool
fill 337 176 291 338 184 291 minecraft:dirt
fill 338 176 290 338 184 290 minecraft:dirt
fill 342 176 317 342 216 317 minecraft:light_blue_terracotta
fill 362 176 302 366 177 303 minecraft:white_wool
fill 363 176 300 365 177 301 minecraft:white_wool
fill 363 176 304 365 177 304 minecraft:white_wool
fill 364 176 299 365 176 299 minecraft:white_wool
fill 366 176 301 366 177 301 minecraft:white_wool
fill 367 176 317 367 218 317 minecraft:light_blue_terracotta
setblock 329 177 280 minecraft:white_wool
setblock 332 177 278 minecraft:light[level=15]
setblock 332 177 286 minecraft:light[level=15]
setblock 332 177 294 minecraft:light[level=15]
setblock 332 177 302 minecraft:light[level=15]
setblock 332 177 310 minecraft:light[level=15]
fill 337 177 289 338 184 289 minecraft:dirt
setblock 340 177 278 minecraft:light[level=15]
setblock 340 177 286 minecraft:light[level=15]
setblock 340 177 294 minecraft:light[level=15]
setblock 340 177 302 minecraft:light[level=15]
setblock 340 177 310 minecraft:light[level=15]
setblock 345 177 317 minecraft:white_wool
fill 346 177 317 346 218 317 minecraft:light_blue_terracotta
setblock 348 177 278 minecraft:light[level=15]
setblock 348 177 286 minecraft:light[level=15]
setblock 348 177 294 minecraft:light[level=15]
setblock 348 177 302 minecraft:light[level=15]
setblock 348 177 310 minecraft:light[level=15]
setblock 356 177 278 minecraft:light[level=15]
setblock 356 177 286 minecraft:light[level=15]
setblock 356 177 294 minecraft:light[level=15]
setblock 356 177 302 minecraft:light[level=15]
setblock 356 177 310 minecraft:light[level=15]
setblock 362 177 301 minecraft:white_wool
setblock 364 177 278 minecraft:light[level=15]
setblock 364 177 286 minecraft:light[level=15]
setblock 364 177 294 minecraft:light[level=15]
setblock 364 177 310 minecraft:light[level=15]
setblock 366 177 304 minecraft:white_wool
setblock 329 178 278 minecraft:white_wool
fill 329 178 279 329 218 280 minecraft:light_blue_terracotta
fill 331 178 275 332 206 275 minecraft:light_blue_terracotta
setblock 333 178 275 minecraft:white_wool
fill 336 178 289 336 184 291 minecraft:dirt
fill 337 178 292 338 184 292 minecraft:dirt
fill 339 178 290 339 184 291 minecraft:dirt
setblock 345 178 275 minecraft:white_wool
fill 345 178 317 345 218 317 minecraft:light_blue_terracotta
fill 346 178 275 349 182 275 minecraft:light_blue_terracotta
setblock 360 178 275 minecraft:white_wool
fill 361 178 275 362 215 275 minecraft:light_blue_terracotta
setblock 365 178 302 minecraft:white_wool
fill 329 179 278 329 209 278 minecraft:light_blue_terracotta
setblock 332 179 278 minecraft:light[level=12]
setblock 332 179 285 minecraft:light[level=12]
setblock 332 179 292 minecraft:light[level=12]
setblock 332 179 299 minecraft:light[level=12]
setblock 332 179 306 minecraft:light[level=12]
setblock 332 179 313 minecraft:light[level=12]
fill 333 179 275 333 218 275 minecraft:light_blue_terracotta
fill 336 179 292 336 184 292 minecraft:dirt
fill 337 179 288 338 184 288 minecraft:dirt
setblock 339 179 278 minecraft:light[level=12]
setblock 339 179 285 minecraft:light[level=12]
fill 339 179 289 339 184 289 minecraft:dirt
fill 339 179 292 339 184 292 minecraft:dirt
setblock 339 179 299 minecraft:light[level=12]
setblock 339 179 306 minecraft:light[level=12]
setblock 339 179 313 minecraft:light[level=12]
fill 345 179 275 345 214 275 minecraft:light_blue_terracotta
setblock 346 179 278 minecraft:light[level=12]
setblock 346 179 285 minecraft:light[level=12]
setblock 346 179 292 minecraft:light[level=12]
setblock 346 179 299 minecraft:light[level=12]
setblock 346 179 306 minecraft:light[level=12]
setblock 346 179 313 minecraft:light[level=12]
setblock 353 179 278 minecraft:light[level=12]
setblock 353 179 285 minecraft:light[level=12]
setblock 353 179 292 minecraft:light[level=12]
setblock 353 179 299 minecraft:light[level=12]
setblock 353 179 306 minecraft:light[level=12]
setblock 353 179 313 minecraft:light[level=12]
fill 360 179 275 360 215 275 minecraft:light_blue_terracotta
setblock 360 179 278 minecraft:light[level=12]
setblock 360 179 285 minecraft:light[level=12]
setblock 360 179 292 minecraft:light[level=12]
setblock 360 179 299 minecraft:light[level=12]
setblock 360 179 306 minecraft:light[level=12]
setblock 360 179 313 minecraft:light[level=12]
setblock 367 179 278 minecraft:light[level=12]
setblock 367 179 285 minecraft:light[level=12]
setblock 367 179 292 minecraft:light[level=12]
setblock 367 179 299 minecraft:light[level=12]
setblock 367 179 306 minecraft:light[level=12]
setblock 367 179 313 minecraft:light[level=12]
setblock 371 179 307 minecraft:white_wool
fill 335 180 289 335 184 291 minecraft:dirt
fill 336 180 288 336 184 288 minecraft:dirt
fill 337 180 293 338 184 293 minecraft:dirt
fill 339 180 288 339 184 288 minecraft:dirt
fill 340 180 289 340 184 291 minecraft:dirt
setblock 361 180 317 minecraft:white_wool
setblock 371 180 282 minecraft:white_wool
fill 371 180 307 371 214 307 minecraft:light_blue_terracotta
fill 329 181 297 329 219 297 minecraft:light_blue_terracotta
setblock 329 181 298 minecraft:white_wool
fill 329 181 299 329 183 299 minecraft:light_blue_terracotta
fill 335 181 288 335 184 288 minecraft:dirt
fill 335 181 292 335 184 292 minecraft:dirt
fill 336 181 293 336 184 293 minecraft:dirt
fill 337 181 287 338 184 287 minecraft:dirt
fill 339 181 293 339 184 293 minecraft:dirt
fill 340 181 288 340 184 288 minecraft:dirt
fill 340 181 292 340 184 292 minecraft:dirt
fill 361 181 317 361 218 317 minecraft:light_blue_terracotta
fill 362 181 286 363 182 286 minecraft:white_concrete
fill 371 181 282 371 188 282 minecraft:light_blue_terracotta
fill 329 182 298 329 217 298 minecraft:light_blue_terracotta
fill 334 182 289 334 184 292 minecraft:dirt
fill 335 182 293 335 184 293 minecraft:dirt
fill 336 182 287 336 184 287 minecraft:dirt
fill 337 182 294 338 184 294 minecraft:dirt
fill 339 182 287 339 184 287 minecraft:dirt
fill 340 182 293 340 184 293 minecraft:dirt
fill 341 182 289 341 184 292 minecraft:dirt
fill 329 183 291 329 215 292 minecraft:light_blue_terracotta
setblock 329 183 293 minecraft:white_wool
setblock 329 183 310 minecraft:white_wool
fill 334 183 288 334 184 288 minecraft:dirt
fill 334 183 293 334 184 293 minecraft:dirt
fill 335 183 287 335 184 287 minecraft:dirt
fill 336 183 294 336 184 294 minecraft:dirt
fill 336 183 301 337 184 302 minecraft:white_wool
fill 337 183 286 338 184 286 minecraft:dirt
fill 339 183 294 339 184 294 minecraft:dirt
fill 340 183 287 340 184 287 minecraft:dirt
fill 341 183 288 341 184 288 minecraft:dirt
fill 346 183 275 348 218 275 minecraft:light_blue_terracotta
fill 347 183 317 349 214 317 minecraft:light_blue_terracotta
setblock 349 183 275 minecraft:white_wool
setblock 350 183 317 minecraft:white_wool
fill 329 184 293 329 208 293 minecraft:light_blue_terracotta
setblock 329 184 299 minecraft:white_wool
fill 329 184 310 329 215 310 minecraft:light_blue_terracotta
fill 333 184 289 333 184 292 minecraft:dirt
setblock 334 184 287 minecraft:dirt
setblock 335 184 294 minecraft:dirt
setblock 336 184 286 minecraft:dirt
fill 337 184 295 338 184 295 minecraft:dirt
setblock 338 184 317 minecraft:white_wool
setblock 339 184 286 minecraft:dirt
setblock 340 184 294 minecraft:dirt
fill 340 184 304 340 185 304 minecraft:white_concrete
setblock 341 184 287 minecraft:dirt
setblock 341 184 293 minecraft:dirt
fill 342 184 289 342 184 292 minecraft:dirt
fill 349 184 275 349 195 275 minecraft:light_blue_terracotta
fill 350 184 317 350 218 317 minecraft:light_blue_terracotta
fill 329 185 299 329 218 299 minecraft:light_blue_terracotta
setblock 332 185 278 minecraft:light[level=15]
setblock 332 185 285 minecraft:light[level=12]
setblock 332 185 286 minecraft:light[level=15]
setblock 332 185 292 minecraft:light[level=12]
setblock 332 185 294 minecraft:light[level=15]
setblock 332 185 299 minecraft:light[level=12]
setblock 332 185 302 minecraft:light[level=15]
setblock 332 185 306 minecraft:light[level=12]
setblock 332 185 310 minecraft:light[level=15]
setblock 332 185 313 minecraft:light[level=12]
fill 333 185 290 334 185 291 minecraft:white_concrete
fill 337 185 290 337 187 290 minecraft:white_concrete
fill 338 185 317 338 215 317 minecraft:light_blue_terracotta
setblock 339 185 278 minecraft:light[level=12]
setblock 339 185 285 minecraft:light[level=12]
setblock 339 185 292 minecraft:light[level=12]
setblock 339 185 299 minecraft:light[level=12]
setblock 339 185 306 minecraft:light[level=12]
setblock 339 185 313 minecraft:light[level=12]
setblock 340 185 278 minecraft:light[level=15]
setblock 340 185 286 minecraft:light[level=15]
setblock 340 185 294 minecraft:light[level=15]
setblock 340 185 302 minecraft:light[level=15]
setblock 340 185 310 minecraft:light[level=15]
setblock 346 185 278 minecraft:light[level=12]
setblock 346 185 285 minecraft:light[level=12]
setblock 346 185 292 minecraft:light[level=12]
setblock 346 185 299 minecraft:light[level=12]
setblock 346 185 306 minecraft:light[level=12]
setblock 346 185 313 minecraft:light[level=12]
setblock 348 185 278 minecraft:light[level=15]
setblock 348 185 286 minecraft:light[level=15]
setblock 348 185 294 minecraft:light[level=15]
setblock 348 185 302 minecraft:light[level=15]
setblock 348 185 310 minecraft:light[level=15]
setblock 353 185 278 minecraft:light[level=12]
setblock 353 185 285 minecraft:light[level=12]
setblock 353 185 292 minecraft:light[level=12]
setblock 353 185 299 minecraft:light[level=12]
setblock 353 185 306 minecraft:light[level=12]
setblock 353 185 313 minecraft:light[level=12]
setblock 356 185 278 minecraft:light[level=15]
setblock 356 185 286 minecraft:light[level=15]
setblock 356 185 294 minecraft:light[level=15]
setblock 356 185 302 minecraft:light[level=15]
fill 356 185 304 356 186 304 minecraft:white_wool
setblock 356 185 310 minecraft:light[level=15]
setblock 360 185 278 minecraft:light[level=12]
setblock 360 185 285 minecraft:light[level=12]
setblock 360 185 292 minecraft:light[level=12]
setblock 360 185 299 minecraft:light[level=12]
setblock 360 185 306 minecraft:light[level=12]
setblock 360 185 313 minecraft:light[level=12]
setblock 364 185 278 minecraft:light[level=15]
setblock 364 185 286 minecraft:light[level=15]
setblock 364 185 294 minecraft:light[level=15]
setblock 364 185 302 minecraft:light[level=15]
setblock 364 185 310 minecraft:light[level=15]
setblock 367 185 278 minecraft:light[level=12]
setblock 367 185 285 minecraft:light[level=12]
setblock 367 185 292 minecraft:light[level=12]
setblock 367 185 299 minecraft:light[level=12]
setblock 367 185 306 minecraft:light[level=12]
setblock 367 185 313 minecraft:light[level=12]
setblock 371 185 300 minecraft:white_wool
fill 371 186 300 371 214 300 minecraft:light_blue_terracotta
setblock 354 187 317 minecraft:white_wool
fill 369 187 317 369 221 317 minecraft:light_blue_terracotta
setblock 370 187 317 minecraft:white_wool
fill 336 188 289 338 190 291 minecraft:oak_leaves[persistent=true]
fill 337 188 292 338 190 292 minecraft:oak_leaves[persistent=true]
fill 339 188 290 339 190 291 minecraft:oak_leaves[persistent=true]
fill 354 188 317 354 218 317 minecraft:light_blue_terracotta
setblock 365 188 317 minecraft:white_wool
fill 370 188 317 370 214 317 minecraft:light_blue_terracotta
setblock 329 189 288 minecraft:white_wool
fill 329 189 289 329 205 290 minecraft:light_blue_terracotta
setblock 336 189 292 minecraft:oak_leaves[persistent=true]
fill 337 189 288 338 189 288 minecraft:oak_leaves[persistent=true]
fill 339 189 288 339 190 288 minecraft:ochre_froglight
setblock 339 189 289 minecraft:oak_leaves[persistent=true]
setblock 339 189 292 minecraft:oak_leaves[persistent=true]
fill 360 189 310 361 190 310 minecraft:white_concrete
fill 362 189 317 362 215 317 minecraft:light_blue_terracotta
setblock 363 189 317 minecraft:white_wool
fill 365 189 317 365 218 317 minecraft:light_blue_terracotta
setblock 366 189 275 minecraft:white_wool
setblock 371 189 282 minecraft:white_wool
setblock 371 189 306 minecraft:white_wool
fill 329 190 288 329 216 288 minecraft:light_blue_terracotta
fill 363 190 317 363 218 317 minecraft:light_blue_terracotta
fill 366 190 275 366 218 275 minecraft:light_blue_terracotta
fill 371 190 282 371 214 282 minecraft:light_blue_terracotta
fill 371 190 306 371 204 306 minecraft:light_blue_terracotta
setblock 332 191 278 minecraft:light[level=12]
setblock 332 191 285 minecraft:light[level=12]
setblock 332 191 292 minecraft:light[level=12]
setblock 332 191 299 minecraft:light[level=12]
setblock 332 191 306 minecraft:light[level=12]
setblock 332 191 313 minecraft:light[level=12]
setblock 339 191 278 minecraft:light[level=12]
setblock 339 191 285 minecraft:light[level=12]
fill 339 191 288 339 198 288 minecraft:dirt
setblock 339 191 292 minecraft:light[level=12]
setblock 339 191 299 minecraft:light[level=12]
setblock 339 191 306 minecraft:light[level=12]
setblock 339 191 313 minecraft:light[level=12]
setblock 346 191 278 minecraft:light[level=12]
setblock 346 191 285 minecraft:light[level=12]
setblock 346 191 292 minecraft:light[level=12]
setblock 346 191 299 minecraft:light[level=12]
fill 346 191 306 346 192 307 minecraft:white_wool
setblock 346 191 313 minecraft:light[level=12]
setblock 353 191 278 minecraft:light[level=12]
setblock 353 191 285 minecraft:light[level=12]
setblock 353 191 292 minecraft:light[level=12]
setblock 353 191 299 minecraft:light[level=12]
setblock 353 191 306 minecraft:light[level=12]
setblock 353 191 313 minecraft:light[level=12]
setblock 360 191 278 minecraft:light[level=12]
setblock 360 191 285 minecraft:light[level=12]
setblock 360 191 292 minecraft:light[level=12]
setblock 360 191 299 minecraft:light[level=12]
setblock 360 191 306 minecraft:light[level=12]
setblock 360 191 313 minecraft:light[level=12]
setblock 367 191 278 minecraft:light[level=12]
setblock 367 191 285 minecraft:light[level=12]
setblock 367 191 292 minecraft:light[level=12]
setblock 367 191 299 minecraft:light[level=12]
setblock 367 191 306 minecraft:light[level=12]
setblock 367 191 313 minecraft:light[level=12]
fill 339 192 287 339 198 287 minecraft:dirt
fill 340 192 288 340 198 288 minecraft:dirt
setblock 329 193 300 minecraft:white_wool
setblock 332 193 278 minecraft:light[level=15]
setblock 332 193 286 minecraft:light[level=15]
setblock 332 193 294 minecraft:light[level=15]
setblock 332 193 302 minecraft:light[level=15]
setblock 332 193 310 minecraft:light[level=15]
fill 338 193 288 338 198 288 minecraft:dirt
fill 339 193 289 340 198 289 minecraft:dirt
setblock 340 193 278 minecraft:light[level=15]
setblock 340 193 286 minecraft:light[level=15]
fill 340 193 287 340 198 287 minecraft:dirt
setblock 340 193 294 minecraft:light[level=15]
setblock 340 193 302 minecraft:light[level=15]
setblock 340 193 310 minecraft:light[level=15]
setblock 348 193 278 minecraft:light[level=15]
setblock 348 193 286 minecraft:light[level=15]
setblock 348 193 294 minecraft:light[level=15]
setblock 348 193 302 minecraft:light[level=15]
setblock 348 193 310 minecraft:light[level=15]
setblock 356 193 278 minecraft:light[level=15]
setblock 356 193 286 minecraft:light[level=15]
setblock 356 193 294 minecraft:light[level=15]
setblock 356 193 302 minecraft:light[level=15]
schedule function dropper:buildpart/67_2 1t
