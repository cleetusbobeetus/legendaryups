setblock 370 106 579 minecraft:oak_log
fill 370 106 580 370 109 580 minecraft:green_terracotta
setblock 370 106 588 minecraft:oak_leaves[persistent=true]
setblock 330 107 558 minecraft:oak_log
fill 330 107 559 333 107 559 minecraft:green_terracotta
setblock 330 107 563 minecraft:oak_log
fill 330 107 564 330 110 564 minecraft:green_terracotta
setblock 330 107 574 minecraft:oak_leaves[persistent=true]
setblock 330 107 593 minecraft:oak_leaves[persistent=true]
setblock 330 107 598 minecraft:oak_log
fill 331 107 558 331 110 558 minecraft:green_terracotta
fill 331 107 598 331 108 598 minecraft:green_terracotta
setblock 334 107 559 minecraft:oak_log
setblock 335 107 558 minecraft:oak_log
fill 335 107 559 338 107 559 minecraft:green_terracotta
setblock 335 107 598 minecraft:oak_log
fill 336 107 558 336 110 558 minecraft:green_terracotta
fill 336 107 598 336 110 598 minecraft:green_terracotta
setblock 339 107 559 minecraft:oak_log
setblock 340 107 558 minecraft:oak_log
fill 340 107 559 340 110 559 minecraft:green_terracotta
setblock 340 107 598 minecraft:oak_log
fill 341 107 558 341 110 558 minecraft:green_terracotta
setblock 341 107 597 minecraft:oak_log
fill 341 107 598 341 110 598 minecraft:green_terracotta
setblock 342 107 596 minecraft:oak_log
fill 342 107 597 342 110 597 minecraft:green_terracotta
setblock 343 107 596 minecraft:green_terracotta
setblock 344 107 559 minecraft:oak_log
setblock 345 107 558 minecraft:oak_log
fill 345 107 559 345 110 559 minecraft:green_terracotta
setblock 345 107 598 minecraft:oak_log
fill 346 107 558 346 110 558 minecraft:green_terracotta
setblock 346 107 597 minecraft:oak_log
fill 346 107 598 346 110 598 minecraft:green_terracotta
fill 347 107 597 347 108 597 minecraft:green_terracotta
setblock 350 107 558 minecraft:oak_leaves[persistent=true]
setblock 350 107 598 minecraft:oak_log
setblock 351 107 598 minecraft:green_terracotta
setblock 359 107 558 minecraft:green_terracotta
setblock 360 107 558 minecraft:oak_log
setblock 360 107 598 minecraft:oak_log
fill 361 107 558 361 109 559 minecraft:green_terracotta
fill 361 107 598 361 110 598 minecraft:green_terracotta
setblock 364 107 559 minecraft:oak_log
setblock 365 107 558 minecraft:oak_log
fill 365 107 559 365 110 559 minecraft:green_terracotta
setblock 365 107 598 minecraft:oak_log
fill 366 107 558 366 110 558 minecraft:green_terracotta
fill 366 107 598 366 108 598 minecraft:green_terracotta
setblock 369 107 559 minecraft:oak_log
fill 369 107 560 369 110 560 minecraft:green_terracotta
setblock 369 107 563 minecraft:green_terracotta
setblock 369 107 579 minecraft:oak_log
fill 369 107 580 369 108 580 minecraft:green_terracotta
setblock 369 107 598 minecraft:oak_leaves[persistent=true]
setblock 370 107 558 minecraft:oak_log
fill 370 107 559 370 110 559 minecraft:green_terracotta
setblock 370 107 563 minecraft:oak_log
fill 370 107 564 370 110 564 minecraft:green_terracotta
setblock 370 107 573 minecraft:oak_log
setblock 370 107 574 minecraft:green_terracotta
setblock 370 107 578 minecraft:oak_log
fill 370 107 579 370 110 579 minecraft:green_terracotta
setblock 370 107 583 minecraft:oak_log
fill 330 108 558 330 110 559 minecraft:green_terracotta
setblock 330 108 562 minecraft:oak_log
fill 330 108 563 330 111 563 minecraft:green_terracotta
setblock 330 108 580 minecraft:oak_leaves[persistent=true]
setblock 330 108 598 minecraft:green_terracotta
fill 331 108 559 332 108 559 minecraft:green_terracotta
setblock 331 108 561 minecraft:oak_log
setblock 333 108 559 minecraft:oak_log
setblock 334 108 558 minecraft:oak_log
fill 334 108 559 337 108 559 minecraft:green_terracotta
setblock 334 108 598 minecraft:oak_log
fill 335 108 558 335 111 558 minecraft:green_terracotta
fill 335 108 598 335 111 598 minecraft:green_terracotta
setblock 338 108 559 minecraft:oak_log
setblock 339 108 558 minecraft:oak_log
fill 339 108 559 339 111 559 minecraft:green_terracotta
setblock 339 108 598 minecraft:oak_log
fill 340 108 558 340 111 558 minecraft:green_terracotta
setblock 340 108 597 minecraft:oak_log
fill 340 108 598 340 111 598 minecraft:green_terracotta
setblock 341 108 560 minecraft:green_terracotta
fill 341 108 597 341 111 597 minecraft:green_terracotta
setblock 342 108 560 minecraft:oak_log
setblock 343 108 559 minecraft:oak_log
fill 343 108 560 343 111 560 minecraft:green_terracotta
setblock 344 108 558 minecraft:oak_log
fill 344 108 559 344 111 559 minecraft:green_terracotta
setblock 344 108 598 minecraft:oak_log
fill 345 108 558 345 111 558 minecraft:green_terracotta
setblock 345 108 597 minecraft:oak_log
fill 345 108 598 345 111 598 minecraft:green_terracotta
fill 346 108 597 346 110 597 minecraft:green_terracotta
setblock 349 108 558 minecraft:oak_log
setblock 349 108 598 minecraft:oak_log
setblock 350 108 598 minecraft:green_terracotta
setblock 356 108 598 minecraft:oak_leaves[persistent=true]
setblock 358 108 558 minecraft:green_terracotta
setblock 359 108 558 minecraft:oak_log
fill 360 108 558 360 111 558 minecraft:green_terracotta
setblock 363 108 559 minecraft:oak_log
setblock 364 108 558 minecraft:oak_log
fill 364 108 559 364 110 560 minecraft:green_terracotta
setblock 364 108 598 minecraft:oak_log
fill 365 108 558 365 111 558 minecraft:green_terracotta
fill 365 108 560 366 108 560 minecraft:green_terracotta
fill 365 108 598 365 110 598 minecraft:green_terracotta
setblock 368 108 559 minecraft:oak_log
setblock 369 108 558 minecraft:oak_log
fill 369 108 559 369 111 559 minecraft:green_terracotta
setblock 369 108 563 minecraft:oak_log
fill 369 108 564 369 111 564 minecraft:green_terracotta
setblock 369 108 578 minecraft:oak_log
setblock 369 108 579 minecraft:green_terracotta
fill 370 108 558 370 111 558 minecraft:green_terracotta
setblock 370 108 562 minecraft:oak_log
fill 370 108 563 370 111 563 minecraft:green_terracotta
setblock 370 108 577 minecraft:oak_log
fill 370 108 578 370 110 578 minecraft:green_terracotta
setblock 370 108 582 minecraft:oak_log
fill 370 108 583 370 111 583 minecraft:green_terracotta
setblock 370 108 595 minecraft:oak_leaves[persistent=true]
setblock 330 109 561 minecraft:oak_log
fill 330 109 562 331 111 562 minecraft:green_terracotta
setblock 330 109 567 minecraft:oak_leaves[persistent=true]
setblock 330 109 586 minecraft:oak_leaves[persistent=true]
setblock 331 109 559 minecraft:green_terracotta
setblock 331 109 560 minecraft:oak_log
fill 331 109 561 331 112 561 minecraft:green_terracotta
setblock 332 109 559 minecraft:oak_log
setblock 333 109 558 minecraft:oak_log
fill 333 109 559 336 109 559 minecraft:green_terracotta
fill 333 109 569 335 110 570 minecraft:glowstone
setblock 333 109 598 minecraft:oak_log
fill 334 109 558 334 112 558 minecraft:green_terracotta
fill 334 109 598 334 112 598 minecraft:green_terracotta
setblock 337 109 559 minecraft:oak_log
setblock 338 109 558 minecraft:oak_log
fill 338 109 559 338 112 559 minecraft:green_terracotta
setblock 338 109 598 minecraft:oak_log
fill 339 109 558 339 112 558 minecraft:green_terracotta
fill 339 109 560 340 109 560 minecraft:green_terracotta
setblock 339 109 597 minecraft:oak_log
fill 339 109 598 339 112 598 minecraft:green_terracotta
fill 340 109 597 340 112 597 minecraft:green_terracotta
setblock 341 109 560 minecraft:oak_log
fill 341 109 587 342 110 587 minecraft:oak_leaves[persistent=true]
setblock 342 109 559 minecraft:oak_log
fill 342 109 560 342 112 560 minecraft:green_terracotta
setblock 343 109 558 minecraft:oak_log
fill 343 109 559 343 112 559 minecraft:green_terracotta
setblock 343 109 598 minecraft:oak_log
fill 344 109 558 344 112 558 minecraft:green_terracotta
setblock 344 109 597 minecraft:oak_log
fill 344 109 598 344 112 598 minecraft:green_terracotta
fill 345 109 597 345 112 597 minecraft:green_terracotta
setblock 348 109 558 minecraft:oak_log
setblock 348 109 598 minecraft:oak_log
setblock 349 109 598 minecraft:green_terracotta
setblock 357 109 558 minecraft:oak_leaves[persistent=true]
setblock 358 109 558 minecraft:oak_log
fill 359 109 558 359 112 558 minecraft:green_terracotta
fill 360 109 559 360 110 559 minecraft:green_terracotta
fill 360 109 598 360 111 598 minecraft:green_terracotta
setblock 362 109 558 minecraft:green_terracotta
setblock 362 109 559 minecraft:oak_log
fill 362 109 560 363 111 560 minecraft:green_terracotta
setblock 363 109 558 minecraft:oak_log
fill 363 109 559 363 112 559 minecraft:green_terracotta
setblock 363 109 598 minecraft:oak_log
fill 364 109 558 364 112 558 minecraft:green_terracotta
fill 364 109 598 364 112 598 minecraft:green_terracotta
setblock 365 109 560 minecraft:green_terracotta
setblock 366 109 560 minecraft:oak_log
setblock 367 109 559 minecraft:oak_log
setblock 368 109 558 minecraft:oak_log
fill 368 109 559 368 112 559 minecraft:green_terracotta
fill 369 109 558 369 112 558 minecraft:green_terracotta
setblock 369 109 562 minecraft:oak_log
fill 369 109 563 369 112 563 minecraft:green_terracotta
setblock 370 109 561 minecraft:oak_log
fill 370 109 562 370 112 562 minecraft:green_terracotta
setblock 370 109 566 minecraft:oak_log
fill 370 109 567 370 112 567 minecraft:green_terracotta
setblock 370 109 570 minecraft:oak_leaves[persistent=true]
setblock 370 109 577 minecraft:green_terracotta
setblock 370 109 581 minecraft:oak_log
fill 370 109 582 370 112 582 minecraft:green_terracotta
setblock 370 109 589 minecraft:oak_leaves[persistent=true]
setblock 330 110 560 minecraft:oak_log
fill 330 110 561 330 113 561 minecraft:green_terracotta
setblock 330 110 565 minecraft:oak_log
fill 330 110 566 330 113 566 minecraft:green_terracotta
setblock 330 110 573 minecraft:oak_leaves[persistent=true]
setblock 330 110 592 minecraft:oak_leaves[persistent=true]
setblock 331 110 559 minecraft:oak_log
fill 331 110 560 331 113 560 minecraft:green_terracotta
setblock 332 110 558 minecraft:oak_log
fill 332 110 559 335 110 559 minecraft:green_terracotta
fill 333 110 558 333 113 558 minecraft:green_terracotta
fill 333 110 598 333 113 598 minecraft:green_terracotta
setblock 336 110 559 minecraft:oak_log
setblock 337 110 558 minecraft:oak_log
fill 337 110 559 337 113 559 minecraft:green_terracotta
setblock 337 110 597 minecraft:green_terracotta
setblock 337 110 598 minecraft:oak_log
fill 338 110 558 338 113 558 minecraft:green_terracotta
fill 338 110 560 339 110 560 minecraft:green_terracotta
setblock 338 110 597 minecraft:oak_log
fill 338 110 598 338 113 598 minecraft:green_terracotta
fill 339 110 597 339 113 597 minecraft:green_terracotta
setblock 340 110 560 minecraft:oak_log
setblock 341 110 559 minecraft:oak_log
fill 341 110 560 341 113 560 minecraft:green_terracotta
setblock 342 110 558 minecraft:oak_log
fill 342 110 559 342 113 559 minecraft:green_terracotta
setblock 342 110 598 minecraft:oak_log
fill 343 110 558 343 113 558 minecraft:green_terracotta
setblock 343 110 597 minecraft:oak_log
fill 343 110 598 343 113 598 minecraft:green_terracotta
fill 344 110 597 344 113 597 minecraft:green_terracotta
setblock 346 110 559 minecraft:oak_log
setblock 347 110 558 minecraft:oak_log
setblock 347 110 598 minecraft:oak_log
setblock 348 110 558 minecraft:green_terracotta
fill 348 110 598 348 111 598 minecraft:green_terracotta
setblock 349 110 598 minecraft:oak_leaves[persistent=true]
setblock 351 110 558 minecraft:oak_leaves[persistent=true]
setblock 357 110 558 minecraft:oak_log
fill 358 110 558 358 113 558 minecraft:green_terracotta
fill 359 110 559 359 111 559 minecraft:green_terracotta
setblock 361 110 558 minecraft:green_terracotta
setblock 361 110 559 minecraft:oak_log
fill 361 110 560 361 113 560 minecraft:green_terracotta
setblock 362 110 558 minecraft:oak_log
fill 362 110 559 362 113 559 minecraft:green_terracotta
setblock 362 110 598 minecraft:oak_log
fill 363 110 558 363 113 558 minecraft:green_terracotta
fill 363 110 598 363 113 598 minecraft:green_terracotta
setblock 365 110 560 minecraft:oak_log
setblock 366 110 559 minecraft:oak_log
fill 366 110 560 367 112 560 minecraft:green_terracotta
setblock 367 110 558 minecraft:oak_log
fill 367 110 559 367 113 559 minecraft:green_terracotta
fill 368 110 558 368 113 558 minecraft:green_terracotta
setblock 368 110 562 minecraft:oak_log
setblock 368 110 598 minecraft:oak_leaves[persistent=true]
setblock 369 110 561 minecraft:oak_log
fill 369 110 562 369 113 562 minecraft:green_terracotta
setblock 369 110 565 minecraft:green_terracotta
setblock 369 110 566 minecraft:oak_log
setblock 370 110 560 minecraft:oak_log
fill 370 110 561 370 113 561 minecraft:green_terracotta
setblock 370 110 565 minecraft:oak_log
fill 370 110 566 370 113 566 minecraft:green_terracotta
fill 370 110 568 370 111 568 minecraft:green_terracotta
setblock 370 110 580 minecraft:oak_log
fill 370 110 581 370 112 581 minecraft:green_terracotta
setblock 330 111 558 minecraft:green_terracotta
setblock 330 111 559 minecraft:oak_log
fill 330 111 560 330 114 560 minecraft:green_terracotta
setblock 330 111 564 minecraft:oak_log
fill 330 111 565 330 114 565 minecraft:green_terracotta
setblock 330 111 579 minecraft:oak_leaves[persistent=true]
setblock 330 111 598 minecraft:oak_leaves[persistent=true]
setblock 331 111 558 minecraft:oak_log
fill 331 111 559 334 111 559 minecraft:green_terracotta
setblock 331 111 563 minecraft:oak_log
fill 332 111 558 332 114 558 minecraft:green_terracotta
fill 332 111 598 332 114 598 minecraft:green_terracotta
setblock 335 111 559 minecraft:oak_log
setblock 336 111 558 minecraft:oak_log
fill 336 111 559 336 113 560 minecraft:green_terracotta
setblock 336 111 598 minecraft:oak_log
fill 337 111 558 337 114 558 minecraft:green_terracotta
fill 337 111 560 338 111 560 minecraft:green_terracotta
setblock 337 111 597 minecraft:oak_log
fill 337 111 598 337 114 598 minecraft:green_terracotta
fill 338 111 597 338 114 597 minecraft:green_terracotta
setblock 339 111 560 minecraft:oak_log
setblock 340 111 559 minecraft:oak_log
fill 340 111 560 340 114 560 minecraft:green_terracotta
setblock 341 111 558 minecraft:oak_log
fill 341 111 559 341 114 559 minecraft:green_terracotta
setblock 341 111 598 minecraft:oak_log
fill 342 111 558 342 114 558 minecraft:green_terracotta
setblock 342 111 597 minecraft:oak_log
fill 342 111 598 342 114 598 minecraft:green_terracotta
fill 343 111 597 343 114 597 minecraft:green_terracotta
setblock 345 111 559 minecraft:oak_log
setblock 346 111 558 minecraft:oak_log
setblock 346 111 598 minecraft:oak_log
fill 347 111 558 347 112 558 minecraft:green_terracotta
fill 347 111 598 347 112 598 minecraft:green_terracotta
setblock 355 111 598 minecraft:oak_leaves[persistent=true]
setblock 356 111 558 minecraft:oak_log
fill 357 111 558 357 114 558 minecraft:green_terracotta
fill 358 111 559 358 112 559 minecraft:green_terracotta
fill 359 111 598 359 112 598 minecraft:green_terracotta
setblock 360 111 559 minecraft:oak_log
fill 360 111 560 360 114 560 minecraft:green_terracotta
setblock 361 111 558 minecraft:oak_log
fill 361 111 559 361 114 559 minecraft:green_terracotta
setblock 361 111 598 minecraft:oak_log
fill 362 111 558 362 114 558 minecraft:green_terracotta
fill 362 111 598 362 114 598 minecraft:green_terracotta
setblock 364 111 559 minecraft:green_terracotta
setblock 364 111 560 minecraft:oak_log
setblock 365 111 559 minecraft:oak_log
fill 365 111 560 365 114 560 minecraft:green_terracotta
setblock 366 111 558 minecraft:oak_log
fill 366 111 559 366 114 559 minecraft:green_terracotta
fill 367 111 558 367 114 558 minecraft:green_terracotta
setblock 368 111 561 minecraft:oak_log
fill 368 111 562 368 112 564 minecraft:green_terracotta
setblock 369 111 560 minecraft:oak_log
fill 369 111 561 369 114 561 minecraft:green_terracotta
setblock 369 111 565 minecraft:oak_log
fill 369 111 566 369 113 567 minecraft:green_terracotta
setblock 370 111 559 minecraft:oak_log
fill 370 111 560 370 114 560 minecraft:green_terracotta
setblock 370 111 564 minecraft:oak_log
fill 370 111 565 370 114 565 minecraft:green_terracotta
setblock 370 111 569 minecraft:oak_log
setblock 370 111 577 minecraft:oak_leaves[persistent=true]
setblock 370 111 579 minecraft:oak_log
setblock 370 111 580 minecraft:green_terracotta
setblock 370 111 584 minecraft:oak_log
setblock 330 112 558 minecraft:oak_log
fill 330 112 559 333 112 559 minecraft:green_terracotta
setblock 330 112 562 minecraft:green_terracotta
setblock 330 112 563 minecraft:oak_log
fill 330 112 564 331 114 564 minecraft:green_terracotta
setblock 330 112 567 minecraft:green_terracotta
setblock 330 112 585 minecraft:oak_leaves[persistent=true]
fill 331 112 558 331 115 558 minecraft:green_terracotta
setblock 331 112 562 minecraft:oak_log
fill 331 112 563 331 115 563 minecraft:green_terracotta
fill 331 112 598 331 115 598 minecraft:green_terracotta
setblock 334 112 559 minecraft:oak_log
setblock 335 112 558 minecraft:oak_log
fill 335 112 559 335 114 560 minecraft:green_terracotta
setblock 335 112 598 minecraft:oak_log
fill 336 112 558 336 115 558 minecraft:green_terracotta
setblock 336 112 597 minecraft:oak_log
fill 336 112 598 336 115 598 minecraft:green_terracotta
setblock 337 112 560 minecraft:green_terracotta
fill 337 112 597 337 115 597 minecraft:green_terracotta
setblock 338 112 560 minecraft:oak_log
setblock 339 112 559 minecraft:oak_log
fill 339 112 560 339 115 560 minecraft:green_terracotta
setblock 340 112 558 minecraft:oak_log
fill 340 112 559 340 115 559 minecraft:green_terracotta
fill 340 112 596 341 112 596 minecraft:green_terracotta
setblock 340 112 598 minecraft:oak_log
fill 341 112 558 341 115 558 minecraft:green_terracotta
setblock 341 112 597 minecraft:oak_log
fill 341 112 598 341 115 598 minecraft:green_terracotta
fill 342 112 597 342 115 597 minecraft:green_terracotta
setblock 343 112 560 minecraft:oak_log
setblock 344 112 559 minecraft:oak_log
setblock 345 112 558 minecraft:oak_log
setblock 345 112 559 minecraft:green_terracotta
setblock 345 112 598 minecraft:oak_log
fill 346 112 558 346 113 558 minecraft:green_terracotta
fill 346 112 598 346 114 598 minecraft:green_terracotta
fill 356 112 558 356 115 558 minecraft:green_terracotta
fill 357 112 559 357 113 559 minecraft:green_terracotta
setblock 359 112 559 minecraft:oak_log
fill 359 112 560 359 115 560 minecraft:green_terracotta
setblock 360 112 558 minecraft:oak_log
fill 360 112 559 360 115 559 minecraft:green_terracotta
setblock 360 112 598 minecraft:oak_log
fill 361 112 558 361 115 558 minecraft:green_terracotta
fill 361 112 598 361 115 598 minecraft:green_terracotta
setblock 362 112 560 minecraft:green_terracotta
setblock 362 112 561 minecraft:oak_log
setblock 363 112 560 minecraft:oak_log
fill 363 112 561 364 113 561 minecraft:green_terracotta
setblock 364 112 559 minecraft:oak_log
fill 364 112 560 364 115 560 minecraft:green_terracotta
setblock 365 112 558 minecraft:oak_log
fill 365 112 559 365 115 559 minecraft:green_terracotta
fill 366 112 558 366 115 558 minecraft:green_terracotta
fill 368 112 561 368 114 561 minecraft:green_terracotta
setblock 368 112 565 minecraft:oak_log
setblock 369 112 559 minecraft:oak_log
fill 369 112 560 369 115 560 minecraft:green_terracotta
setblock 369 112 564 minecraft:oak_log
fill 369 112 565 369 115 565 minecraft:green_terracotta
setblock 370 112 558 minecraft:oak_log
fill 370 112 559 370 115 559 minecraft:green_terracotta
setblock 370 112 563 minecraft:oak_log
fill 370 112 564 370 115 564 minecraft:green_terracotta
setblock 370 112 568 minecraft:oak_log
fill 370 112 569 370 114 570 minecraft:green_terracotta
setblock 370 112 571 minecraft:oak_leaves[persistent=true]
setblock 370 112 583 minecraft:oak_log
fill 370 112 584 370 114 584 minecraft:green_terracotta
setblock 370 112 596 minecraft:oak_leaves[persistent=true]
fill 330 113 558 330 115 559 minecraft:green_terracotta
setblock 330 113 562 minecraft:oak_log
fill 330 113 563 330 116 563 minecraft:green_terracotta
setblock 330 113 567 minecraft:oak_log
fill 330 113 584 330 113 586 minecraft:green_terracotta
setblock 330 113 587 minecraft:oak_log
setblock 330 113 591 minecraft:oak_leaves[persistent=true]
fill 331 113 559 332 113 559 minecraft:green_terracotta
setblock 331 113 561 minecraft:oak_log
fill 331 113 562 331 116 562 minecraft:green_terracotta
setblock 331 113 565 minecraft:green_terracotta
fill 331 113 566 331 114 566 minecraft:oak_log
setblock 332 113 560 minecraft:light[level=14]
setblock 332 113 568 minecraft:light[level=14]
setblock 332 113 576 minecraft:light[level=14]
setblock 332 113 584 minecraft:light[level=14]
setblock 332 113 592 minecraft:light[level=14]
setblock 333 113 559 minecraft:oak_log
setblock 334 113 558 minecraft:oak_log
fill 334 113 559 334 116 559 minecraft:green_terracotta
setblock 334 113 598 minecraft:oak_log
fill 335 113 558 335 116 558 minecraft:green_terracotta
setblock 335 113 597 minecraft:oak_log
fill 335 113 598 335 116 598 minecraft:green_terracotta
fill 336 113 597 336 116 597 minecraft:green_terracotta
setblock 337 113 560 minecraft:oak_log
setblock 338 113 559 minecraft:oak_log
fill 338 113 560 338 115 560 minecraft:green_terracotta
setblock 339 113 558 minecraft:oak_log
fill 339 113 559 339 116 559 minecraft:green_terracotta
fill 339 113 596 340 113 596 minecraft:green_terracotta
setblock 339 113 598 minecraft:oak_log
fill 340 113 558 340 116 558 minecraft:green_terracotta
setblock 340 113 568 minecraft:light[level=14]
setblock 340 113 576 minecraft:light[level=14]
setblock 340 113 584 minecraft:light[level=14]
setblock 340 113 592 minecraft:light[level=14]
setblock 340 113 597 minecraft:oak_log
fill 340 113 598 340 116 598 minecraft:green_terracotta
setblock 341 113 596 minecraft:oak_log
fill 341 113 597 341 116 597 minecraft:green_terracotta
setblock 342 113 560 minecraft:oak_log
setblock 343 113 559 minecraft:oak_log
setblock 344 113 558 minecraft:oak_log
setblock 344 113 559 minecraft:green_terracotta
setblock 344 113 598 minecraft:oak_log
fill 345 113 558 345 114 558 minecraft:green_terracotta
fill 345 113 598 345 115 598 minecraft:green_terracotta
setblock 348 113 560 minecraft:light[level=14]
setblock 348 113 568 minecraft:light[level=14]
setblock 348 113 576 minecraft:light[level=14]
setblock 348 113 584 minecraft:light[level=14]
setblock 348 113 592 minecraft:light[level=14]
fill 355 113 558 355 116 558 minecraft:green_terracotta
setblock 356 113 560 minecraft:light[level=14]
setblock 356 113 568 minecraft:light[level=14]
setblock 356 113 576 minecraft:light[level=14]
setblock 356 113 584 minecraft:light[level=14]
setblock 356 113 592 minecraft:light[level=14]
setblock 358 113 559 minecraft:oak_log
fill 358 113 560 358 115 560 minecraft:green_terracotta
setblock 358 113 598 minecraft:green_terracotta
setblock 359 113 558 minecraft:oak_log
fill 359 113 559 359 116 559 minecraft:green_terracotta
setblock 359 113 598 minecraft:oak_log
fill 360 113 558 360 116 558 minecraft:green_terracotta
fill 360 113 598 360 115 598 minecraft:green_terracotta
setblock 361 113 561 minecraft:oak_log
setblock 362 113 560 minecraft:oak_log
fill 362 113 561 362 114 561 minecraft:green_terracotta
setblock 363 113 559 minecraft:oak_log
fill 363 113 560 363 115 560 minecraft:green_terracotta
setblock 364 113 558 minecraft:oak_log
fill 364 113 559 364 116 559 minecraft:green_terracotta
setblock 364 113 568 minecraft:light[level=14]
setblock 364 113 576 minecraft:light[level=14]
setblock 364 113 584 minecraft:light[level=14]
setblock 364 113 592 minecraft:light[level=14]
fill 365 113 558 365 116 558 minecraft:green_terracotta
setblock 366 113 560 minecraft:green_terracotta
setblock 367 113 560 minecraft:oak_log
setblock 367 113 598 minecraft:oak_leaves[persistent=true]
setblock 368 113 559 minecraft:oak_log
fill 368 113 562 368 113 563 minecraft:green_terracotta
setblock 368 113 564 minecraft:oak_log
fill 368 113 565 368 115 566 minecraft:green_terracotta
setblock 369 113 558 minecraft:oak_log
fill 369 113 559 369 115 559 minecraft:green_terracotta
setblock 369 113 563 minecraft:oak_log
fill 369 113 564 369 116 564 minecraft:green_terracotta
setblock 369 113 568 minecraft:oak_log
fill 370 113 558 370 116 558 minecraft:green_terracotta
setblock 370 113 562 minecraft:oak_log
fill 370 113 563 370 116 563 minecraft:green_terracotta
setblock 370 113 567 minecraft:oak_log
fill 370 113 568 370 116 568 minecraft:green_terracotta
setblock 370 113 582 minecraft:oak_log
fill 370 113 583 370 114 583 minecraft:green_terracotta
fill 370 113 585 370 114 585 minecraft:green_terracotta
setblock 370 113 590 minecraft:oak_leaves[persistent=true]
setblock 330 114 561 minecraft:oak_log
fill 330 114 562 330 117 562 minecraft:green_terracotta
setblock 330 114 566 minecraft:oak_log
fill 330 114 567 330 116 568 minecraft:green_terracotta
setblock 330 114 572 minecraft:oak_leaves[persistent=true]
fill 330 114 584 330 114 585 minecraft:green_terracotta
setblock 330 114 586 minecraft:oak_log
fill 330 114 587 330 114 590 minecraft:green_terracotta
setblock 330 114 597 minecraft:oak_leaves[persistent=true]
setblock 331 114 559 minecraft:green_terracotta
setblock 331 114 560 minecraft:oak_log
fill 331 114 561 331 116 561 minecraft:green_terracotta
setblock 331 114 565 minecraft:oak_log
setblock 332 114 559 minecraft:oak_log
setblock 333 114 558 minecraft:oak_log
fill 333 114 559 333 116 559 minecraft:green_terracotta
setblock 333 114 598 minecraft:oak_log
fill 334 114 558 334 117 558 minecraft:green_terracotta
fill 334 114 598 334 117 598 minecraft:green_terracotta
fill 335 114 597 335 117 597 minecraft:green_terracotta
setblock 336 114 559 minecraft:green_terracotta
setblock 336 114 560 minecraft:oak_log
setblock 337 114 559 minecraft:oak_log
fill 337 114 560 337 115 560 minecraft:green_terracotta
setblock 338 114 558 minecraft:oak_log
fill 338 114 559 338 117 559 minecraft:green_terracotta
fill 338 114 596 339 114 596 minecraft:green_terracotta
setblock 338 114 598 minecraft:oak_log
fill 339 114 558 339 117 558 minecraft:green_terracotta
setblock 339 114 597 minecraft:oak_log
fill 339 114 598 339 117 598 minecraft:green_terracotta
setblock 340 114 596 minecraft:oak_log
fill 340 114 597 340 117 597 minecraft:green_terracotta
setblock 341 114 560 minecraft:oak_log
setblock 341 114 596 minecraft:green_terracotta
setblock 342 114 559 minecraft:oak_log
setblock 343 114 558 minecraft:oak_log
setblock 343 114 559 minecraft:green_terracotta
setblock 343 114 598 minecraft:oak_log
fill 344 114 558 344 115 558 minecraft:green_terracotta
fill 344 114 598 344 116 598 minecraft:green_terracotta
fill 346 114 558 346 115 558 minecraft:oak_leaves[persistent=true]
setblock 348 114 598 minecraft:oak_leaves[persistent=true]
setblock 352 114 558 minecraft:oak_leaves[persistent=true]
setblock 357 114 559 minecraft:oak_log
setblock 358 114 558 minecraft:oak_log
fill 358 114 559 358 117 559 minecraft:green_terracotta
setblock 358 114 598 minecraft:oak_log
fill 359 114 558 359 117 558 minecraft:green_terracotta
fill 359 114 598 359 115 598 minecraft:green_terracotta
setblock 360 114 561 minecraft:oak_log
setblock 361 114 560 minecraft:oak_log
setblock 361 114 561 minecraft:green_terracotta
setblock 362 114 559 minecraft:oak_log
fill 362 114 560 362 116 560 minecraft:green_terracotta
setblock 363 114 558 minecraft:oak_log
fill 363 114 559 363 116 559 minecraft:green_terracotta
setblock 363 114 561 minecraft:green_terracotta
fill 364 114 558 364 117 558 minecraft:green_terracotta
setblock 366 114 560 minecraft:oak_log
setblock 367 114 559 minecraft:oak_log
setblock 368 114 558 minecraft:oak_log
fill 368 114 559 368 115 559 minecraft:green_terracotta
setblock 368 114 562 minecraft:green_terracotta
setblock 368 114 563 minecraft:oak_log
fill 368 114 564 368 116 564 minecraft:green_terracotta
fill 369 114 558 369 116 558 minecraft:green_terracotta
setblock 369 114 562 minecraft:oak_log
fill 369 114 563 369 117 563 minecraft:green_terracotta
setblock 369 114 566 minecraft:green_terracotta
setblock 369 114 567 minecraft:oak_log
fill 369 114 568 369 117 568 minecraft:green_terracotta
setblock 370 114 561 minecraft:oak_log
fill 370 114 562 370 117 562 minecraft:green_terracotta
setblock 370 114 566 minecraft:oak_log
fill 370 114 567 370 117 567 minecraft:green_terracotta
setblock 370 114 571 minecraft:oak_log
setblock 370 114 586 minecraft:oak_log
setblock 330 115 560 minecraft:oak_log
fill 330 115 561 330 118 561 minecraft:green_terracotta
setblock 330 115 564 minecraft:green_terracotta
setblock 330 115 565 minecraft:oak_log
fill 330 115 566 331 116 566 minecraft:green_terracotta
setblock 330 115 578 minecraft:oak_leaves[persistent=true]
setblock 330 115 584 minecraft:green_terracotta
setblock 330 115 585 minecraft:oak_log
fill 330 115 586 330 115 589 minecraft:green_terracotta
setblock 330 115 590 minecraft:oak_log
fill 330 115 591 330 117 592 minecraft:green_terracotta
setblock 331 115 559 minecraft:oak_log
setblock 331 115 560 minecraft:green_terracotta
setblock 331 115 564 minecraft:oak_log
fill 331 115 565 331 117 565 minecraft:green_terracotta
setblock 332 115 558 minecraft:oak_log
setblock 332 115 559 minecraft:green_terracotta
setblock 332 115 598 minecraft:oak_log
fill 333 115 558 333 118 558 minecraft:green_terracotta
fill 333 115 598 333 118 598 minecraft:green_terracotta
fill 334 115 597 334 118 597 minecraft:green_terracotta
setblock 335 115 559 minecraft:green_terracotta
setblock 336 115 559 minecraft:oak_log
setblock 336 115 560 minecraft:green_terracotta
setblock 337 115 558 minecraft:oak_log
fill 337 115 559 337 117 559 minecraft:green_terracotta
setblock 337 115 598 minecraft:oak_log
fill 338 115 558 338 118 558 minecraft:green_terracotta
setblock 338 115 596 minecraft:green_terracotta
setblock 338 115 597 minecraft:oak_log
fill 338 115 598 338 118 598 minecraft:green_terracotta
setblock 339 115 596 minecraft:oak_log
fill 339 115 597 339 118 597 minecraft:green_terracotta
setblock 340 115 560 minecraft:oak_log
setblock 340 115 596 minecraft:green_terracotta
setblock 341 115 559 minecraft:oak_log
setblock 342 115 558 minecraft:oak_log
setblock 342 115 559 minecraft:green_terracotta
setblock 342 115 598 minecraft:oak_log
fill 343 115 558 343 116 558 minecraft:green_terracotta
setblock 343 115 597 minecraft:oak_log
fill 343 115 598 343 117 598 minecraft:green_terracotta
setblock 354 115 598 minecraft:oak_leaves[persistent=true]
setblock 357 115 558 minecraft:oak_log
fill 357 115 559 357 116 559 minecraft:green_terracotta
fill 358 115 558 358 118 558 minecraft:green_terracotta
fill 358 115 571 359 116 572 minecraft:glowstone
fill 359 115 570 359 116 570 minecraft:glowstone
setblock 360 115 560 minecraft:oak_log
fill 360 115 578 361 116 578 minecraft:glowstone
setblock 361 115 559 minecraft:oak_log
fill 361 115 560 361 116 560 minecraft:green_terracotta
setblock 362 115 558 minecraft:oak_log
fill 362 115 559 362 117 559 minecraft:green_terracotta
fill 363 115 558 363 118 558 minecraft:green_terracotta
setblock 366 115 559 minecraft:oak_log
setblock 367 115 558 minecraft:oak_log
setblock 367 115 559 minecraft:green_terracotta
fill 368 115 558 368 116 558 minecraft:green_terracotta
setblock 368 115 562 minecraft:oak_log
setblock 368 115 563 minecraft:green_terracotta
setblock 369 115 561 minecraft:oak_log
fill 369 115 562 369 117 562 minecraft:green_terracotta
setblock 369 115 566 minecraft:oak_log
fill 369 115 567 369 118 567 minecraft:green_terracotta
fill 369 115 569 370 115 569 minecraft:green_terracotta
setblock 370 115 560 minecraft:oak_log
fill 370 115 561 370 118 561 minecraft:green_terracotta
setblock 370 115 565 minecraft:oak_log
fill 370 115 566 370 118 566 minecraft:green_terracotta
setblock 370 115 570 minecraft:oak_log
fill 370 115 571 370 118 571 minecraft:green_terracotta
fill 370 115 572 370 116 572 minecraft:oak_leaves[persistent=true]
setblock 370 115 578 minecraft:oak_leaves[persistent=true]
setblock 370 115 585 minecraft:oak_log
setblock 370 115 586 minecraft:green_terracotta
setblock 370 115 597 minecraft:oak_leaves[persistent=true]
setblock 330 116 558 minecraft:green_terracotta
setblock 330 116 559 minecraft:oak_log
fill 330 116 560 330 118 560 minecraft:green_terracotta
setblock 330 116 564 minecraft:oak_log
fill 330 116 565 330 119 565 minecraft:green_terracotta
setblock 330 116 584 minecraft:oak_log
fill 330 116 585 330 116 588 minecraft:green_terracotta
setblock 330 116 589 minecraft:oak_log
fill 330 116 590 330 119 590 minecraft:green_terracotta
setblock 330 116 593 minecraft:green_terracotta
setblock 331 116 558 minecraft:oak_log
setblock 331 116 563 minecraft:oak_log
fill 331 116 564 331 117 564 minecraft:green_terracotta
fill 331 116 567 331 117 568 minecraft:oak_leaves[persistent=true]
setblock 331 116 587 minecraft:green_terracotta
setblock 331 116 588 minecraft:oak_log
fill 331 116 589 331 119 589 minecraft:green_terracotta
setblock 331 116 598 minecraft:oak_log
fill 332 116 558 332 118 558 minecraft:green_terracotta
fill 332 116 563 333 116 564 minecraft:oak_leaves[persistent=true]
fill 332 116 568 334 116 568 minecraft:oak_leaves[persistent=true]
fill 332 116 598 332 119 598 minecraft:green_terracotta
fill 334 116 564 334 117 567 minecraft:oak_leaves[persistent=true]
setblock 335 116 559 minecraft:oak_log
fill 335 116 565 335 116 567 minecraft:oak_leaves[persistent=true]
setblock 336 116 558 minecraft:oak_log
fill 336 116 559 336 117 559 minecraft:green_terracotta
setblock 336 116 598 minecraft:oak_log
fill 337 116 558 337 119 558 minecraft:green_terracotta
setblock 337 116 596 minecraft:green_terracotta
setblock 337 116 597 minecraft:oak_log
fill 337 116 598 337 119 598 minecraft:green_terracotta
setblock 338 116 596 minecraft:oak_log
fill 338 116 597 338 119 597 minecraft:green_terracotta
setblock 339 116 596 minecraft:green_terracotta
setblock 340 116 559 minecraft:oak_log
setblock 341 116 558 minecraft:oak_log
setblock 341 116 559 minecraft:green_terracotta
setblock 341 116 598 minecraft:oak_log
setblock 342 116 558 minecraft:green_terracotta
setblock 342 116 597 minecraft:oak_log
fill 342 116 598 342 118 598 minecraft:green_terracotta
fill 343 116 578 343 116 582 minecraft:oak_leaves[persistent=true]
fill 344 116 577 347 116 578 minecraft:oak_leaves[persistent=true]
fill 344 116 581 344 117 582 minecraft:oak_leaves[persistent=true]
fill 345 116 582 346 116 583 minecraft:oak_leaves[persistent=true]
fill 347 116 581 348 116 582 minecraft:oak_leaves[persistent=true]
fill 348 116 578 348 116 580 minecraft:oak_leaves[persistent=true]
setblock 356 116 558 minecraft:oak_log
fill 357 116 558 357 119 558 minecraft:green_terracotta
setblock 359 116 560 minecraft:oak_log
setblock 360 116 559 minecraft:oak_log
setblock 360 116 560 minecraft:green_terracotta
setblock 360 116 598 minecraft:oak_leaves[persistent=true]
setblock 361 116 558 minecraft:oak_log
fill 361 116 559 361 117 559 minecraft:green_terracotta
fill 362 116 558 362 118 558 minecraft:green_terracotta
setblock 365 116 559 minecraft:oak_log
setblock 366 116 558 minecraft:oak_log
fill 366 116 598 366 117 598 minecraft:oak_leaves[persistent=true]
setblock 367 116 558 minecraft:green_terracotta
setblock 368 116 565 minecraft:green_terracotta
setblock 368 116 566 minecraft:oak_log
setblock 369 116 560 minecraft:oak_log
fill 369 116 561 369 117 561 minecraft:green_terracotta
setblock 369 116 565 minecraft:oak_log
fill 369 116 566 369 119 566 minecraft:green_terracotta
setblock 369 116 569 minecraft:green_terracotta
setblock 370 116 559 minecraft:oak_log
fill 370 116 560 370 119 560 minecraft:green_terracotta
setblock 370 116 564 minecraft:oak_log
fill 370 116 565 370 119 565 minecraft:green_terracotta
setblock 370 116 569 minecraft:oak_log
fill 370 116 570 370 119 570 minecraft:green_terracotta
setblock 370 116 591 minecraft:oak_leaves[persistent=true]
setblock 330 117 558 minecraft:oak_log
setblock 330 117 559 minecraft:green_terracotta
setblock 330 117 563 minecraft:oak_log
fill 330 117 564 330 119 564 minecraft:green_terracotta
fill 330 117 566 330 117 567 minecraft:green_terracotta
setblock 330 117 568 minecraft:oak_log
setblock 330 117 571 minecraft:oak_leaves[persistent=true]
fill 330 117 585 330 117 587 minecraft:green_terracotta
setblock 330 117 588 minecraft:oak_log
fill 330 117 589 330 119 589 minecraft:green_terracotta
setblock 330 117 593 minecraft:oak_log
fill 330 117 594 330 119 594 minecraft:green_terracotta
fill 330 117 596 330 118 596 minecraft:oak_leaves[persistent=true]
setblock 331 117 558 minecraft:green_terracotta
setblock 331 117 563 minecraft:green_terracotta
fill 331 117 566 331 119 566 minecraft:oak_log
setblock 331 117 587 minecraft:oak_log
fill 331 117 588 331 119 588 minecraft:green_terracotta
fill 331 117 590 331 117 591 minecraft:green_terracotta
fill 331 117 598 331 119 598 minecraft:green_terracotta
fill 332 117 564 333 118 564 minecraft:oak_leaves[persistent=true]
fill 332 117 568 333 117 568 minecraft:oak_leaves[persistent=true]
setblock 334 117 559 minecraft:oak_log
setblock 335 117 558 minecraft:oak_log
setblock 335 117 559 minecraft:green_terracotta
setblock 335 117 598 minecraft:oak_log
fill 336 117 558 336 119 558 minecraft:green_terracotta
setblock 336 117 597 minecraft:oak_log
fill 336 117 598 336 119 598 minecraft:green_terracotta
setblock 337 117 596 minecraft:oak_log
fill 337 117 597 337 119 597 minecraft:green_terracotta
setblock 338 117 596 minecraft:green_terracotta
setblock 339 117 559 minecraft:oak_log
setblock 340 117 558 minecraft:oak_log
setblock 340 117 598 minecraft:oak_log
setblock 341 117 558 minecraft:green_terracotta
setblock 341 117 597 minecraft:oak_log
fill 341 117 598 341 119 598 minecraft:green_terracotta
fill 343 117 579 343 117 581 minecraft:oak_leaves[persistent=true]
fill 344 117 578 347 118 578 minecraft:oak_leaves[persistent=true]
fill 345 117 577 346 117 577 minecraft:oak_leaves[persistent=true]
fill 345 117 582 347 117 582 minecraft:oak_leaves[persistent=true]
fill 347 117 581 348 117 581 minecraft:oak_leaves[persistent=true]
setblock 347 117 598 minecraft:oak_leaves[persistent=true]
fill 348 117 579 348 117 580 minecraft:oak_leaves[persistent=true]
setblock 353 117 558 minecraft:oak_leaves[persistent=true]
fill 353 117 562 353 119 562 minecraft:iron_block
fill 356 117 558 356 118 558 minecraft:green_terracotta
setblock 359 117 559 minecraft:oak_log
setblock 360 117 558 minecraft:oak_log
setblock 360 117 559 minecraft:green_terracotta
fill 361 117 558 361 119 558 minecraft:green_terracotta
setblock 365 117 558 minecraft:oak_log
setblock 366 117 558 minecraft:green_terracotta
setblock 369 117 564 minecraft:oak_log
fill 369 117 565 369 119 565 minecraft:green_terracotta
setblock 369 117 569 minecraft:oak_log
setblock 370 117 558 minecraft:oak_log
fill 370 117 559 370 118 559 minecraft:green_terracotta
setblock 370 117 563 minecraft:oak_log
fill 370 117 564 370 119 564 minecraft:green_terracotta
setblock 370 117 568 minecraft:oak_log
fill 370 117 569 370 119 569 minecraft:green_terracotta
setblock 370 117 585 minecraft:oak_leaves[persistent=true]
fill 330 118 558 330 119 558 minecraft:oak_leaves[persistent=true]
setblock 330 118 562 minecraft:oak_log
fill 330 118 563 330 119 563 minecraft:green_terracotta
setblock 330 118 566 minecraft:green_terracotta
setblock 330 118 567 minecraft:oak_log
fill 330 118 568 330 119 568 minecraft:green_terracotta
setblock 330 118 577 minecraft:oak_leaves[persistent=true]
fill 330 118 585 330 118 586 minecraft:green_terracotta
setblock 330 118 587 minecraft:oak_log
fill 330 118 588 330 119 588 minecraft:green_terracotta
setblock 330 118 591 minecraft:green_terracotta
setblock 330 118 592 minecraft:oak_log
fill 330 118 593 330 119 593 minecraft:green_terracotta
fill 330 118 595 330 119 595 minecraft:green_terracotta
setblock 331 118 564 minecraft:oak_leaves[persistent=true]
fill 331 118 565 331 119 565 minecraft:oak_log
setblock 331 118 567 minecraft:oak_leaves[persistent=true]
fill 331 118 587 331 119 587 minecraft:green_terracotta
setblock 331 118 590 minecraft:green_terracotta
setblock 331 118 591 minecraft:oak_log
fill 331 118 592 331 119 592 minecraft:green_terracotta
setblock 334 118 558 minecraft:oak_log
fill 334 118 565 334 118 566 minecraft:oak_leaves[persistent=true]
setblock 334 118 598 minecraft:oak_log
fill 335 118 558 335 119 558 minecraft:green_terracotta
setblock 335 118 597 minecraft:oak_log
fill 335 118 598 335 119 598 minecraft:green_terracotta
fill 336 118 597 336 119 597 minecraft:green_terracotta
setblock 339 118 558 minecraft:oak_log
setblock 339 118 598 minecraft:oak_log
setblock 340 118 558 minecraft:green_terracotta
setblock 340 118 597 minecraft:oak_log
fill 340 118 598 340 119 598 minecraft:green_terracotta
setblock 344 118 581 minecraft:oak_leaves[persistent=true]
fill 345 118 582 346 118 582 minecraft:oak_leaves[persistent=true]
setblock 347 118 558 minecraft:oak_leaves[persistent=true]
setblock 347 118 581 minecraft:oak_leaves[persistent=true]
setblock 353 118 598 minecraft:oak_leaves[persistent=true]
setblock 359 118 558 minecraft:oak_log
fill 360 118 558 360 119 558 minecraft:green_terracotta
setblock 366 118 558 minecraft:oak_leaves[persistent=true]
setblock 369 118 563 minecraft:oak_log
fill 369 118 564 369 119 564 minecraft:green_terracotta
setblock 369 118 568 minecraft:oak_log
setblock 370 118 562 minecraft:oak_log
fill 370 118 563 370 119 563 minecraft:green_terracotta
setblock 370 118 567 minecraft:oak_log
fill 370 118 568 370 119 568 minecraft:green_terracotta
setblock 370 118 579 minecraft:oak_leaves[persistent=true]
setblock 330 119 562 minecraft:green_terracotta
setblock 330 119 566 minecraft:oak_log
setblock 330 119 567 minecraft:green_terracotta
setblock 330 119 583 minecraft:oak_leaves[persistent=true]
setblock 330 119 586 minecraft:oak_log
setblock 330 119 587 minecraft:green_terracotta
setblock 330 119 591 minecraft:oak_log
setblock 330 119 592 minecraft:green_terracotta
setblock 330 119 596 minecraft:oak_log
setblock 331 119 590 minecraft:oak_log
setblock 331 119 591 minecraft:green_terracotta
setblock 331 119 593 minecraft:green_terracotta
setblock 333 119 558 minecraft:oak_log
setblock 333 119 598 minecraft:oak_log
setblock 334 119 558 minecraft:green_terracotta
setblock 334 119 597 minecraft:oak_log
setblock 334 119 598 minecraft:green_terracotta
setblock 335 119 597 minecraft:green_terracotta
setblock 338 119 558 minecraft:oak_log
setblock 338 119 598 minecraft:oak_log
setblock 339 119 597 minecraft:oak_log
setblock 339 119 598 minecraft:green_terracotta
setblock 341 119 558 minecraft:oak_leaves[persistent=true]
setblock 358 119 558 minecraft:oak_log
setblock 359 119 558 minecraft:green_terracotta
setblock 359 119 598 minecraft:oak_leaves[persistent=true]
setblock 369 119 567 minecraft:oak_log
setblock 369 119 568 minecraft:green_terracotta
setblock 370 119 561 minecraft:oak_log
setblock 370 119 562 minecraft:green_terracotta
setblock 370 119 566 minecraft:oak_log
setblock 370 119 567 minecraft:green_terracotta
setblock 370 119 571 minecraft:oak_log
setblock 370 119 573 minecraft:oak_leaves[persistent=true]
setblock 370 119 592 minecraft:oak_leaves[persistent=true]
setblock 332 121 560 minecraft:light[level=14]
setblock 332 121 568 minecraft:light[level=14]
setblock 332 121 576 minecraft:light[level=14]
setblock 332 121 584 minecraft:light[level=14]
setblock 332 121 592 minecraft:light[level=14]
setblock 340 121 560 minecraft:light[level=14]
setblock 340 121 568 minecraft:light[level=14]
setblock 340 121 576 minecraft:light[level=14]
setblock 340 121 584 minecraft:light[level=14]
setblock 340 121 592 minecraft:light[level=14]
setblock 348 121 560 minecraft:light[level=14]
setblock 348 121 568 minecraft:light[level=14]
setblock 348 121 576 minecraft:light[level=14]
setblock 348 121 584 minecraft:light[level=14]
setblock 348 121 592 minecraft:light[level=14]
setblock 356 121 560 minecraft:light[level=14]
setblock 356 121 568 minecraft:light[level=14]
setblock 356 121 576 minecraft:light[level=14]
setblock 356 121 584 minecraft:light[level=14]
setblock 356 121 592 minecraft:light[level=14]
setblock 364 121 560 minecraft:light[level=14]
setblock 364 121 568 minecraft:light[level=14]
setblock 364 121 576 minecraft:light[level=14]
setblock 364 121 584 minecraft:light[level=14]
setblock 364 121 592 minecraft:light[level=14]
fill 346 124 576 348 124 578 minecraft:redstone_block
fill 351 124 571 353 124 573 minecraft:redstone_block
fill 355 124 579 357 124 581 minecraft:redstone_block
fill 336 125 577 341 126 577 minecraft:dirt
fill 337 125 572 337 126 573 minecraft:dark_oak_log
fill 337 125 574 342 126 576 minecraft:dirt
fill 337 125 578 338 126 582 minecraft:dirt
fill 338 125 570 338 126 572 minecraft:dark_oak_log
fill 338 125 573 350 125 573 minecraft:dirt
fill 338 125 583 338 126 584 minecraft:dirt
fill 339 125 568 339 126 571 minecraft:dark_oak_log
fill 339 125 572 350 125 572 minecraft:dirt
fill 339 125 578 339 126 581 minecraft:dirt
fill 339 125 582 342 126 586 minecraft:dark_oak_log
fill 340 125 567 341 126 570 minecraft:dark_oak_log
fill 340 125 571 350 125 571 minecraft:dirt
fill 340 125 578 340 126 578 minecraft:dirt
fill 340 125 579 342 126 581 minecraft:dark_oak_log
fill 340 125 587 342 126 587 minecraft:dark_oak_log
fill 341 125 566 343 126 566 minecraft:dirt
fill 341 125 578 344 126 578 minecraft:dark_oak_log
fill 341 125 588 342 126 588 minecraft:dark_oak_log
fill 342 125 565 355 126 565 minecraft:dirt
fill 342 125 567 349 126 569 minecraft:dark_oak_log
fill 342 125 570 348 126 570 minecraft:dirt
fill 342 125 577 345 125 577 minecraft:dark_oak_log
fill 342 125 589 343 126 589 minecraft:dark_oak_log
fill 343 125 564 354 126 564 minecraft:dirt
fill 343 125 574 343 126 575 minecraft:dirt
fill 343 125 576 345 125 576 minecraft:dark_oak_log
fill 343 125 579 343 126 580 minecraft:dark_oak_log
fill 343 125 581 347 126 588 minecraft:dirt
fill 343 125 590 343 126 590 minecraft:dark_oak_log
fill 344 125 566 345 126 566 minecraft:dark_oak_log
fill 344 125 574 346 126 574 minecraft:dirt
fill 344 125 575 349 125 575 minecraft:dark_oak_log
fill 344 125 579 347 125 580 minecraft:dirt
fill 344 125 589 350 126 590 minecraft:dirt
fill 345 125 563 353 126 563 minecraft:dirt
setblock 345 125 578 minecraft:dirt
fill 345 125 591 352 126 591 minecraft:dirt
fill 346 125 566 356 126 566 minecraft:dirt
fill 347 125 562 351 126 562 minecraft:dirt
fill 347 125 574 347 126 574 minecraft:dark_oak_log
fill 347 125 592 354 126 592 minecraft:dirt
fill 348 125 574 350 125 574 minecraft:dirt
setblock 348 125 579 minecraft:dirt
fill 348 125 580 349 126 585 minecraft:dark_oak_log
fill 348 125 586 348 126 588 minecraft:dirt
fill 349 125 570 352 125 570 minecraft:dark_oak_log
fill 349 125 576 350 126 578 minecraft:ochre_froglight
setblock 349 125 579 minecraft:dark_oak_log
fill 349 125 586 351 126 587 minecraft:dark_oak_log
fill 349 125 588 349 126 588 minecraft:dirt
fill 350 125 567 356 126 567 minecraft:dirt
fill 350 125 568 350 126 569 minecraft:dark_oak_log
fill 350 125 575 354 126 575 minecraft:ochre_froglight
fill 350 125 579 354 126 579 minecraft:ochre_froglight
fill 350 125 580 350 126 582 minecraft:dirt
fill 350 125 583 350 126 585 minecraft:dark_oak_log
fill 350 125 588 354 126 588 minecraft:dark_oak_log
fill 351 125 568 357 126 568 minecraft:dirt
fill 351 125 569 351 126 569 minecraft:dark_oak_log
fill 351 125 574 353 126 574 minecraft:ochre_froglight
fill 351 125 580 353 126 580 minecraft:ochre_froglight
fill 351 125 581 352 126 585 minecraft:dirt
fill 351 125 589 357 126 589 minecraft:dark_oak_log
fill 351 125 590 351 126 590 minecraft:dirt
fill 352 125 561 352 126 562 minecraft:dark_oak_log
fill 352 125 569 357 126 569 minecraft:dirt
fill 352 125 586 365 126 586 minecraft:dirt
fill 352 125 587 352 126 587 minecraft:dark_oak_log
fill 352 125 590 361 126 590 minecraft:dark_oak_log
fill 352 125 593 352 126 593 minecraft:dirt
fill 353 125 562 357 126 562 minecraft:dark_oak_log
fill 353 125 570 357 125 570 minecraft:dirt
fill 353 125 581 354 125 581 minecraft:dark_oak_log
fill 353 125 582 353 126 585 minecraft:dirt
fill 353 125 587 364 126 587 minecraft:dirt
fill 353 125 591 359 126 591 minecraft:dark_oak_log
fill 354 125 563 358 126 563 minecraft:dark_oak_log
fill 354 125 571 356 125 574 minecraft:dirt
fill 354 125 576 355 126 578 minecraft:ochre_froglight
setblock 354 125 580 minecraft:dark_oak_log
fill 354 125 582 363 125 582 minecraft:dark_oak_log
fill 354 125 583 355 126 585 minecraft:dirt
fill 355 125 564 359 126 564 minecraft:dark_oak_log
fill 355 125 575 356 126 575 minecraft:dirt
fill 355 125 588 363 126 588 minecraft:dirt
fill 355 125 592 357 126 592 minecraft:dark_oak_log
fill 356 125 565 359 126 565 minecraft:dark_oak_log
fill 356 125 576 357 126 577 minecraft:dark_oak_log
fill 356 125 578 363 125 578 minecraft:dirt
fill 356 125 583 361 126 583 minecraft:dark_oak_log
fill 356 125 584 365 126 585 minecraft:dirt
fill 357 125 566 360 126 567 minecraft:dark_oak_log
fill 357 125 571 357 126 573 minecraft:dirt
fill 357 125 574 359 126 575 minecraft:dark_oak_log
fill 358 125 568 360 126 573 minecraft:dark_oak_log
fill 358 125 576 358 126 576 minecraft:dark_oak_log
fill 358 125 577 364 126 577 minecraft:dirt
fill 358 125 579 360 125 580 minecraft:dirt
fill 358 125 581 365 125 581 minecraft:dark_oak_log
fill 358 125 589 361 126 589 minecraft:dirt
fill 359 125 563 359 126 563 minecraft:dirt
fill 359 125 576 364 126 576 minecraft:dirt
fill 360 125 564 361 126 565 minecraft:dirt
fill 360 125 574 365 126 575 minecraft:dirt
fill 361 125 566 363 126 573 minecraft:dirt
fill 361 125 579 362 126 579 minecraft:dirt
fill 361 125 580 366 126 580 minecraft:dark_oak_log
fill 362 125 565 362 126 565 minecraft:dirt
fill 362 125 583 366 126 583 minecraft:dirt
fill 362 125 589 362 126 589 minecraft:dark_oak_log
fill 363 125 579 367 126 579 minecraft:dark_oak_log
fill 364 125 567 364 126 573 minecraft:dirt
fill 364 125 578 367 126 578 minecraft:dark_oak_log
fill 364 125 582 367 126 582 minecraft:dirt
fill 365 125 568 365 126 573 minecraft:dirt
fill 365 125 576 367 126 577 minecraft:dark_oak_log
fill 366 125 570 366 126 573 minecraft:dirt
fill 366 125 574 367 126 575 minecraft:dark_oak_log
fill 366 125 581 367 126 581 minecraft:dirt
fill 366 125 584 366 126 584 minecraft:dirt
fill 367 125 572 367 126 573 minecraft:dark_oak_log
fill 367 125 580 367 126 580 minecraft:dirt
fill 368 125 577 368 126 577 minecraft:dark_oak_log
fill 330 126 558 335 126 598 minecraft:dirt
fill 336 126 558 336 126 576 minecraft:dirt
fill 336 126 578 336 126 598 minecraft:dirt
fill 337 126 558 337 126 571 minecraft:dirt
fill 337 126 583 337 126 598 minecraft:dirt
fill 338 126 558 338 126 569 minecraft:dirt
fill 338 126 573 349 126 573 minecraft:dirt
fill 338 126 585 338 126 598 minecraft:dirt
fill 339 126 558 339 126 567 minecraft:dirt
fill 339 126 572 349 126 572 minecraft:dirt
fill 339 126 587 339 126 598 minecraft:dirt
fill 340 126 558 340 126 566 minecraft:dirt
fill 340 126 571 349 126 571 minecraft:dirt
fill 340 126 588 340 126 598 minecraft:dirt
fill 341 126 558 341 126 565 minecraft:dirt
fill 341 126 589 341 126 598 minecraft:dirt
fill 342 126 558 342 126 564 minecraft:dirt
fill 342 126 577 344 126 577 minecraft:dark_oak_log
fill 342 126 590 342 126 598 minecraft:dirt
fill 343 126 558 344 126 563 minecraft:dirt
fill 343 126 576 344 126 576 minecraft:dark_oak_log
fill 343 126 591 344 126 598 minecraft:dirt
setblock 344 126 575 minecraft:dark_oak_log
fill 344 126 579 344 126 580 minecraft:dirt
fill 345 126 558 346 126 562 minecraft:dirt
fill 345 126 575 345 126 579 minecraft:ochre_froglight
fill 345 126 580 347 126 580 minecraft:dirt
fill 345 126 592 346 126 598 minecraft:dirt
fill 346 126 575 349 126 575 minecraft:ochre_froglight
fill 346 126 576 348 126 578 minecraft:dirt
fill 346 126 579 349 126 579 minecraft:ochre_froglight
fill 347 126 558 351 126 561 minecraft:dirt
fill 347 126 593 351 126 598 minecraft:dirt
fill 348 126 574 349 126 574 minecraft:dirt
setblock 349 126 570 minecraft:dark_oak_log
fill 350 126 570 350 126 574 minecraft:ochre_froglight
fill 351 126 570 354 126 570 minecraft:ochre_froglight
fill 351 126 571 353 126 573 minecraft:dirt
fill 352 126 558 370 126 560 minecraft:dirt
fill 352 126 594 370 126 598 minecraft:dirt
fill 353 126 561 370 126 561 minecraft:dirt
setblock 353 126 581 minecraft:dark_oak_log
fill 353 126 593 370 126 593 minecraft:dirt
fill 354 126 571 354 126 574 minecraft:ochre_froglight
fill 354 126 580 354 126 582 minecraft:ochre_froglight
fill 355 126 570 356 126 574 minecraft:dirt
fill 355 126 579 357 126 581 minecraft:dirt
fill 355 126 582 358 126 582 minecraft:ochre_froglight
fill 356 126 578 358 126 578 minecraft:ochre_froglight
setblock 357 126 570 minecraft:dirt
fill 358 126 562 370 126 562 minecraft:dirt
fill 358 126 579 358 126 581 minecraft:ochre_froglight
fill 358 126 592 370 126 592 minecraft:dirt
fill 359 126 578 360 126 580 minecraft:dirt
fill 359 126 581 363 126 582 minecraft:dark_oak_log
fill 360 126 563 370 126 563 minecraft:dirt
fill 360 126 591 370 126 591 minecraft:dirt
fill 361 126 578 363 126 578 minecraft:dirt
fill 362 126 564 370 126 564 minecraft:dirt
fill 362 126 590 370 126 590 minecraft:dirt
fill 363 126 565 370 126 565 minecraft:dirt
fill 363 126 589 370 126 589 minecraft:dirt
fill 364 126 566 370 126 566 minecraft:dirt
fill 364 126 581 365 126 581 minecraft:dark_oak_log
fill 364 126 588 370 126 588 minecraft:dirt
fill 365 126 567 370 126 567 minecraft:dirt
fill 365 126 587 370 126 587 minecraft:dirt
fill 366 126 568 370 126 569 minecraft:dirt
fill 366 126 585 370 126 586 minecraft:dirt
fill 367 126 570 370 126 571 minecraft:dirt
fill 367 126 583 370 126 584 minecraft:dirt
fill 368 126 572 370 126 576 minecraft:dirt
fill 368 126 578 370 126 582 minecraft:dirt
fill 369 126 577 370 126 577 minecraft:dirt
setblock 332 129 560 minecraft:light[level=14]
setblock 332 129 568 minecraft:light[level=14]
setblock 332 129 576 minecraft:light[level=14]
setblock 332 129 584 minecraft:light[level=14]
setblock 332 129 592 minecraft:light[level=14]
setblock 340 129 560 minecraft:light[level=14]
setblock 340 129 568 minecraft:light[level=14]
setblock 340 129 576 minecraft:light[level=14]
setblock 340 129 584 minecraft:light[level=14]
setblock 340 129 592 minecraft:light[level=14]
setblock 348 129 560 minecraft:light[level=14]
setblock 348 129 568 minecraft:light[level=14]
setblock 348 129 576 minecraft:light[level=14]
setblock 348 129 584 minecraft:light[level=14]
setblock 348 129 592 minecraft:light[level=14]
setblock 356 129 560 minecraft:light[level=14]
setblock 356 129 568 minecraft:light[level=14]
setblock 356 129 576 minecraft:light[level=14]
setblock 356 129 584 minecraft:light[level=14]
setblock 356 129 592 minecraft:light[level=14]
setblock 364 129 560 minecraft:light[level=14]
setblock 364 129 568 minecraft:light[level=14]
setblock 364 129 576 minecraft:light[level=14]
setblock 364 129 584 minecraft:light[level=14]
setblock 364 129 592 minecraft:light[level=14]
fill 330 130 558 330 130 559 minecraft:green_terracotta
setblock 330 130 560 minecraft:oak_log
fill 330 130 561 330 130 564 minecraft:green_terracotta
setblock 330 130 565 minecraft:oak_log
fill 330 130 566 330 130 569 minecraft:green_terracotta
setblock 330 130 570 minecraft:oak_log
fill 330 130 571 330 130 574 minecraft:green_terracotta
setblock 330 130 575 minecraft:oak_log
fill 330 130 576 330 130 579 minecraft:green_terracotta
setblock 330 130 580 minecraft:oak_log
fill 330 130 581 330 130 584 minecraft:green_terracotta
setblock 330 130 585 minecraft:oak_log
fill 330 130 586 330 130 589 minecraft:green_terracotta
setblock 330 130 590 minecraft:oak_log
fill 330 130 591 330 130 594 minecraft:green_terracotta
setblock 330 130 595 minecraft:oak_log
fill 330 130 596 331 130 598 minecraft:green_terracotta
setblock 331 130 558 minecraft:green_terracotta
setblock 331 130 559 minecraft:oak_log
fill 331 130 560 331 132 560 minecraft:green_terracotta
fill 331 130 570 331 130 573 minecraft:green_terracotta
setblock 331 130 574 minecraft:oak_log
fill 331 130 575 331 130 578 minecraft:green_terracotta
setblock 331 130 579 minecraft:oak_log
fill 331 130 580 331 130 583 minecraft:green_terracotta
setblock 331 130 584 minecraft:oak_log
fill 331 130 585 331 130 588 minecraft:green_terracotta
setblock 331 130 589 minecraft:oak_log
fill 331 130 590 331 130 593 minecraft:green_terracotta
setblock 331 130 594 minecraft:oak_log
fill 331 130 595 334 130 595 minecraft:green_terracotta
setblock 332 130 558 minecraft:oak_log
fill 332 130 559 333 131 559 minecraft:green_terracotta
setblock 332 130 572 minecraft:green_terracotta
setblock 332 130 573 minecraft:oak_log
fill 332 130 574 332 130 577 minecraft:green_terracotta
setblock 332 130 578 minecraft:oak_log
fill 332 130 579 332 130 582 minecraft:green_terracotta
setblock 332 130 583 minecraft:oak_log
setblock 332 130 587 minecraft:green_terracotta
setblock 332 130 588 minecraft:oak_log
fill 332 130 589 332 130 592 minecraft:green_terracotta
setblock 332 130 593 minecraft:oak_log
fill 332 130 594 333 131 594 minecraft:green_terracotta
fill 332 130 596 332 130 597 minecraft:green_terracotta
setblock 332 130 598 minecraft:oak_log
fill 333 130 558 336 130 558 minecraft:green_terracotta
setblock 333 130 592 minecraft:oak_log
setblock 333 130 593 minecraft:green_terracotta
setblock 333 130 596 minecraft:green_terracotta
setblock 333 130 597 minecraft:oak_log
fill 333 130 598 336 130 598 minecraft:green_terracotta
setblock 334 130 596 minecraft:oak_log
fill 334 130 597 337 130 597 minecraft:green_terracotta
setblock 335 130 595 minecraft:oak_log
fill 335 130 596 337 130 596 minecraft:green_terracotta
setblock 337 130 558 minecraft:oak_log
setblock 337 130 598 minecraft:oak_log
setblock 338 130 558 minecraft:oak_leaves[persistent=true]
setblock 338 130 597 minecraft:oak_log
fill 338 130 598 341 130 598 minecraft:green_terracotta
setblock 339 130 597 minecraft:green_terracotta
setblock 342 130 598 minecraft:oak_log
fill 343 130 598 346 130 598 minecraft:green_terracotta
fill 345 130 558 346 130 558 minecraft:green_terracotta
fill 346 130 597 347 130 597 minecraft:green_terracotta
setblock 347 130 558 minecraft:oak_log
setblock 347 130 598 minecraft:oak_log
fill 348 130 558 350 130 559 minecraft:green_terracotta
setblock 348 130 597 minecraft:oak_log
fill 348 130 598 351 130 598 minecraft:green_terracotta
fill 349 130 597 352 130 597 minecraft:green_terracotta
fill 350 130 596 353 130 596 minecraft:green_terracotta
setblock 351 130 558 minecraft:green_terracotta
setblock 351 130 559 minecraft:oak_log
setblock 352 130 558 minecraft:oak_log
fill 352 130 559 353 131 560 minecraft:green_terracotta
setblock 352 130 598 minecraft:oak_log
fill 353 130 558 356 130 558 minecraft:green_terracotta
fill 353 130 562 353 134 562 minecraft:iron_block
setblock 353 130 597 minecraft:oak_log
fill 353 130 598 356 130 598 minecraft:green_terracotta
fill 354 130 559 355 130 559 minecraft:green_terracotta
fill 354 130 597 357 130 597 minecraft:green_terracotta
setblock 356 130 559 minecraft:oak_log
setblock 357 130 558 minecraft:oak_log
fill 357 130 559 360 130 559 minecraft:green_terracotta
setblock 357 130 598 minecraft:oak_log
fill 358 130 558 361 130 558 minecraft:green_terracotta
setblock 358 130 597 minecraft:oak_log
fill 358 130 598 361 130 598 minecraft:green_terracotta
setblock 359 130 597 minecraft:green_terracotta
fill 361 130 597 362 130 597 minecraft:green_terracotta
setblock 362 130 558 minecraft:oak_log
fill 362 130 559 365 130 559 minecraft:green_terracotta
setblock 362 130 598 minecraft:oak_log
fill 363 130 558 366 130 558 minecraft:green_terracotta
setblock 363 130 597 minecraft:oak_log
fill 363 130 598 366 130 598 minecraft:green_terracotta
fill 364 130 597 367 130 597 minecraft:green_terracotta
fill 365 130 594 365 133 594 minecraft:iron_block
fill 365 130 596 368 130 596 minecraft:green_terracotta
setblock 366 130 559 minecraft:oak_log
setblock 367 130 558 minecraft:oak_log
fill 367 130 559 370 130 559 minecraft:green_terracotta
setblock 367 130 598 minecraft:oak_log
fill 368 130 558 370 131 558 minecraft:green_terracotta
fill 368 130 560 369 130 560 minecraft:green_terracotta
setblock 368 130 592 minecraft:oak_log
fill 368 130 593 369 130 595 minecraft:green_terracotta
setblock 368 130 597 minecraft:oak_log
fill 368 130 598 370 131 598 minecraft:green_terracotta
setblock 369 130 561 minecraft:oak_log
fill 369 130 562 370 131 563 minecraft:green_terracotta
fill 369 130 569 369 130 570 minecraft:green_terracotta
setblock 369 130 571 minecraft:oak_log
fill 369 130 572 369 130 575 minecraft:green_terracotta
setblock 369 130 576 minecraft:oak_log
fill 369 130 577 370 130 579 minecraft:green_terracotta
fill 369 130 589 369 130 590 minecraft:green_terracotta
setblock 369 130 591 minecraft:oak_log
fill 369 130 592 370 132 592 minecraft:green_terracotta
setblock 369 130 596 minecraft:oak_log
fill 369 130 597 370 132 597 minecraft:green_terracotta
setblock 370 130 560 minecraft:oak_log
fill 370 130 561 370 133 561 minecraft:green_terracotta
setblock 370 130 564 minecraft:green_terracotta
setblock 370 130 565 minecraft:oak_log
fill 370 130 566 370 130 569 minecraft:green_terracotta
setblock 370 130 570 minecraft:oak_log
fill 370 130 571 370 130 574 minecraft:green_terracotta
setblock 370 130 575 minecraft:oak_log
fill 370 130 576 370 133 576 minecraft:green_terracotta
setblock 370 130 580 minecraft:oak_log
fill 370 130 581 370 130 584 minecraft:green_terracotta
setblock 370 130 585 minecraft:oak_log
fill 370 130 586 370 130 589 minecraft:green_terracotta
setblock 370 130 590 minecraft:oak_log
fill 370 130 591 370 133 591 minecraft:green_terracotta
fill 370 130 593 370 130 594 minecraft:green_terracotta
setblock 370 130 595 minecraft:oak_log
fill 370 130 596 370 133 596 minecraft:green_terracotta
setblock 330 131 558 minecraft:green_terracotta
setblock 330 131 559 minecraft:oak_log
fill 330 131 560 330 131 563 minecraft:green_terracotta
fill 330 131 567 330 131 568 minecraft:green_terracotta
setblock 330 131 569 minecraft:oak_log
fill 330 131 570 330 131 573 minecraft:green_terracotta
setblock 330 131 574 minecraft:oak_log
fill 330 131 575 330 131 578 minecraft:green_terracotta
setblock 330 131 579 minecraft:oak_log
fill 330 131 580 330 131 583 minecraft:green_terracotta
setblock 330 131 584 minecraft:oak_log
fill 330 131 585 330 131 588 minecraft:green_terracotta
setblock 330 131 589 minecraft:oak_log
fill 330 131 590 330 131 593 minecraft:green_terracotta
setblock 330 131 594 minecraft:oak_log
fill 330 131 595 330 131 598 minecraft:green_terracotta
setblock 331 131 558 minecraft:oak_log
fill 331 131 559 331 134 559 minecraft:green_terracotta
fill 331 131 571 331 131 572 minecraft:green_terracotta
setblock 331 131 573 minecraft:oak_log
fill 331 131 574 331 131 577 minecraft:green_terracotta
setblock 331 131 578 minecraft:oak_log
fill 331 131 579 331 131 582 minecraft:green_terracotta
setblock 331 131 583 minecraft:oak_log
fill 331 131 584 331 131 587 minecraft:green_terracotta
setblock 331 131 588 minecraft:oak_log
fill 331 131 589 331 131 592 minecraft:green_terracotta
setblock 331 131 593 minecraft:oak_log
fill 331 131 594 331 131 597 minecraft:green_terracotta
setblock 331 131 598 minecraft:oak_log
fill 332 131 558 335 131 558 minecraft:green_terracotta
fill 332 131 573 332 131 576 minecraft:green_terracotta
setblock 332 131 577 minecraft:oak_log
fill 332 131 578 332 131 581 minecraft:green_terracotta
setblock 332 131 582 minecraft:oak_log
fill 332 131 583 332 132 583 minecraft:green_terracotta
fill 332 131 589 332 131 591 minecraft:green_terracotta
setblock 332 131 592 minecraft:oak_log
fill 332 131 593 332 132 593 minecraft:green_terracotta
fill 332 131 595 332 131 596 minecraft:green_terracotta
setblock 332 131 597 minecraft:oak_log
fill 332 131 598 335 131 598 minecraft:green_terracotta
setblock 333 131 595 minecraft:green_terracotta
setblock 333 131 596 minecraft:oak_log
fill 333 131 597 336 131 597 minecraft:green_terracotta
fill 334 131 596 336 131 596 minecraft:green_terracotta
setblock 336 131 558 minecraft:oak_log
setblock 336 131 598 minecraft:oak_log
setblock 337 131 597 minecraft:oak_log
fill 337 131 598 340 131 598 minecraft:green_terracotta
setblock 338 131 597 minecraft:green_terracotta
setblock 341 131 598 minecraft:oak_log
fill 342 131 598 345 131 598 minecraft:green_terracotta
setblock 345 131 558 minecraft:green_terracotta
setblock 346 131 558 minecraft:oak_log
setblock 346 131 597 minecraft:green_terracotta
setblock 346 131 598 minecraft:oak_log
fill 347 131 558 349 131 559 minecraft:green_terracotta
setblock 347 131 597 minecraft:oak_log
fill 347 131 598 350 131 598 minecraft:green_terracotta
fill 348 131 597 351 131 597 minecraft:green_terracotta
setblock 350 131 558 minecraft:green_terracotta
setblock 350 131 559 minecraft:oak_log
setblock 351 131 558 minecraft:oak_log
fill 351 131 559 351 133 560 minecraft:green_terracotta
setblock 351 131 598 minecraft:oak_log
fill 352 131 558 355 131 558 minecraft:green_terracotta
setblock 352 131 597 minecraft:oak_log
fill 352 131 598 355 131 598 minecraft:green_terracotta
fill 353 131 597 356 131 597 minecraft:green_terracotta
setblock 354 131 559 minecraft:green_terracotta
setblock 355 131 559 minecraft:oak_log
setblock 356 131 558 minecraft:oak_log
fill 356 131 559 359 131 559 minecraft:green_terracotta
setblock 356 131 598 minecraft:oak_log
fill 357 131 558 360 131 558 minecraft:green_terracotta
setblock 357 131 597 minecraft:oak_log
fill 357 131 598 360 131 598 minecraft:green_terracotta
setblock 360 131 559 minecraft:oak_log
setblock 361 131 558 minecraft:oak_log
fill 361 131 559 364 131 559 minecraft:green_terracotta
setblock 361 131 598 minecraft:oak_log
fill 362 131 558 365 131 558 minecraft:green_terracotta
setblock 362 131 597 minecraft:oak_log
fill 362 131 598 365 131 598 minecraft:green_terracotta
fill 363 131 570 366 179 573 minecraft:oak_log
fill 363 131 597 366 131 597 minecraft:green_terracotta
setblock 365 131 559 minecraft:oak_log
fill 365 131 596 367 131 596 minecraft:green_terracotta
setblock 366 131 558 minecraft:oak_log
fill 366 131 559 369 131 559 minecraft:green_terracotta
setblock 366 131 598 minecraft:oak_log
fill 367 131 558 367 134 558 minecraft:green_terracotta
setblock 367 131 597 minecraft:oak_log
fill 367 131 598 367 134 598 minecraft:green_terracotta
setblock 368 131 560 minecraft:green_terracotta
fill 368 131 593 368 131 595 minecraft:green_terracotta
setblock 368 131 596 minecraft:oak_log
fill 368 131 597 368 134 597 minecraft:green_terracotta
setblock 369 131 560 minecraft:oak_log
fill 369 131 561 369 134 561 minecraft:green_terracotta
setblock 369 131 570 minecraft:oak_log
fill 369 131 571 369 131 574 minecraft:green_terracotta
setblock 369 131 575 minecraft:oak_log
fill 369 131 576 369 131 579 minecraft:green_terracotta
setblock 369 131 580 minecraft:oak_log
setblock 369 131 589 minecraft:green_terracotta
setblock 369 131 590 minecraft:oak_log
fill 369 131 591 369 134 591 minecraft:green_terracotta
fill 369 131 593 369 131 594 minecraft:green_terracotta
setblock 369 131 595 minecraft:oak_log
fill 369 131 596 369 134 596 minecraft:green_terracotta
setblock 370 131 559 minecraft:oak_log
fill 370 131 560 370 134 560 minecraft:green_terracotta
setblock 370 131 564 minecraft:oak_log
fill 370 131 565 370 131 568 minecraft:green_terracotta
setblock 370 131 569 minecraft:oak_log
fill 370 131 570 370 131 573 minecraft:green_terracotta
setblock 370 131 574 minecraft:oak_log
fill 370 131 575 370 134 575 minecraft:green_terracotta
fill 370 131 577 370 131 578 minecraft:green_terracotta
setblock 370 131 579 minecraft:oak_log
fill 370 131 580 370 131 583 minecraft:green_terracotta
setblock 370 131 584 minecraft:oak_log
fill 370 131 585 370 131 588 minecraft:green_terracotta
setblock 370 131 589 minecraft:oak_log
fill 370 131 590 370 134 590 minecraft:green_terracotta
setblock 370 131 593 minecraft:green_terracotta
setblock 370 131 594 minecraft:oak_log
fill 370 131 595 370 134 595 minecraft:green_terracotta
setblock 330 132 558 minecraft:oak_log
fill 330 132 559 330 132 562 minecraft:green_terracotta
setblock 330 132 563 minecraft:oak_log
fill 330 132 569 330 132 572 minecraft:green_terracotta
setblock 330 132 573 minecraft:oak_log
fill 330 132 574 330 132 577 minecraft:green_terracotta
setblock 330 132 578 minecraft:oak_log
fill 330 132 579 330 132 582 minecraft:green_terracotta
setblock 330 132 583 minecraft:oak_log
fill 330 132 584 330 132 587 minecraft:green_terracotta
setblock 330 132 588 minecraft:oak_log
fill 330 132 589 330 132 592 minecraft:green_terracotta
setblock 330 132 593 minecraft:oak_log
fill 330 132 594 330 132 597 minecraft:green_terracotta
setblock 330 132 598 minecraft:oak_log
fill 331 132 558 334 132 558 minecraft:green_terracotta
setblock 331 132 572 minecraft:oak_log
fill 331 132 573 331 132 576 minecraft:green_terracotta
setblock 331 132 577 minecraft:oak_log
fill 331 132 578 331 132 581 minecraft:green_terracotta
setblock 331 132 582 minecraft:oak_log
fill 331 132 583 331 132 586 minecraft:green_terracotta
setblock 331 132 587 minecraft:oak_log
fill 331 132 588 331 132 591 minecraft:green_terracotta
setblock 331 132 592 minecraft:oak_log
fill 331 132 593 331 132 596 minecraft:green_terracotta
setblock 331 132 597 minecraft:oak_log
fill 331 132 598 334 132 598 minecraft:green_terracotta
setblock 332 132 559 minecraft:green_terracotta
fill 332 132 574 332 132 575 minecraft:green_terracotta
setblock 332 132 576 minecraft:oak_log
fill 332 132 577 332 132 580 minecraft:green_terracotta
setblock 332 132 581 minecraft:oak_log
fill 332 132 582 332 135 582 minecraft:green_terracotta
setblock 332 132 591 minecraft:oak_log
setblock 332 132 592 minecraft:green_terracotta
fill 332 132 594 332 132 595 minecraft:green_terracotta
setblock 332 132 596 minecraft:oak_log
fill 332 132 597 335 132 597 minecraft:green_terracotta
fill 333 132 596 334 132 596 minecraft:green_terracotta
setblock 335 132 558 minecraft:oak_log
setblock 335 132 598 minecraft:oak_log
setblock 336 132 558 minecraft:green_terracotta
setblock 336 132 597 minecraft:oak_log
fill 336 132 598 339 132 598 minecraft:green_terracotta
setblock 340 132 598 minecraft:oak_log
fill 342 132 598 344 132 598 minecraft:green_terracotta
setblock 344 132 558 minecraft:green_terracotta
setblock 345 132 558 minecraft:oak_log
setblock 345 132 598 minecraft:oak_log
fill 346 132 558 349 132 558 minecraft:green_terracotta
fill 346 132 598 349 132 598 minecraft:green_terracotta
fill 347 132 559 348 132 559 minecraft:green_terracotta
fill 347 132 597 350 132 597 minecraft:green_terracotta
setblock 349 132 559 minecraft:oak_log
setblock 350 132 558 minecraft:oak_log
fill 350 132 559 350 134 560 minecraft:green_terracotta
setblock 350 132 598 minecraft:oak_log
fill 351 132 558 354 132 558 minecraft:green_terracotta
setblock 351 132 597 minecraft:oak_log
fill 351 132 598 354 132 598 minecraft:green_terracotta
fill 352 132 559 352 132 560 minecraft:green_terracotta
fill 352 132 597 355 132 597 minecraft:green_terracotta
setblock 353 132 559 minecraft:green_terracotta
setblock 353 132 560 minecraft:oak_log
setblock 354 132 559 minecraft:oak_log
setblock 355 132 558 minecraft:oak_log
fill 355 132 559 358 132 559 minecraft:green_terracotta
setblock 355 132 598 minecraft:oak_log
fill 356 132 558 359 132 558 minecraft:green_terracotta
fill 356 132 598 359 132 598 minecraft:green_terracotta
setblock 359 132 559 minecraft:oak_log
setblock 360 132 558 minecraft:oak_log
fill 360 132 559 363 132 559 minecraft:green_terracotta
setblock 360 132 598 minecraft:oak_log
fill 361 132 558 364 132 558 minecraft:green_terracotta
fill 361 132 598 364 132 598 minecraft:green_terracotta
fill 362 132 570 362 133 573 minecraft:dark_oak_log
fill 362 132 597 365 132 597 minecraft:green_terracotta
fill 363 132 569 366 133 569 minecraft:dark_oak_log
fill 363 132 574 366 133 574 minecraft:dark_oak_log
setblock 364 132 559 minecraft:oak_log
setblock 365 132 558 minecraft:oak_log
fill 365 132 559 368 132 559 minecraft:green_terracotta
fill 365 132 596 366 132 596 minecraft:green_terracotta
setblock 365 132 598 minecraft:oak_log
fill 366 132 558 366 135 558 minecraft:green_terracotta
setblock 366 132 597 minecraft:oak_log
fill 366 132 598 366 135 598 minecraft:green_terracotta
setblock 367 132 560 minecraft:green_terracotta
fill 367 132 570 367 133 573 minecraft:dark_oak_log
setblock 367 132 596 minecraft:oak_log
fill 367 132 597 367 135 597 minecraft:green_terracotta
fill 368 132 558 369 132 558 minecraft:green_terracotta
setblock 368 132 560 minecraft:oak_log
fill 368 132 593 368 132 594 minecraft:green_terracotta
setblock 368 132 595 minecraft:oak_log
fill 368 132 596 368 135 596 minecraft:green_terracotta
fill 368 132 598 369 132 598 minecraft:green_terracotta
setblock 369 132 559 minecraft:oak_log
fill 369 132 560 369 135 560 minecraft:green_terracotta
fill 369 132 562 369 132 563 minecraft:green_terracotta
fill 369 132 572 369 132 573 minecraft:green_terracotta
setblock 369 132 574 minecraft:oak_log
fill 369 132 575 369 132 578 minecraft:green_terracotta
setblock 369 132 579 minecraft:oak_log
fill 369 132 580 370 133 581 minecraft:green_terracotta
setblock 369 132 590 minecraft:green_terracotta
setblock 369 132 593 minecraft:green_terracotta
setblock 369 132 594 minecraft:oak_log
fill 369 132 595 369 135 595 minecraft:green_terracotta
setblock 370 132 558 minecraft:oak_log
fill 370 132 559 370 135 559 minecraft:green_terracotta
setblock 370 132 562 minecraft:green_terracotta
setblock 370 132 563 minecraft:oak_log
fill 370 132 564 370 132 567 minecraft:green_terracotta
setblock 370 132 568 minecraft:oak_log
fill 370 132 569 370 132 572 minecraft:green_terracotta
setblock 370 132 573 minecraft:oak_log
fill 370 132 574 370 135 574 minecraft:green_terracotta
setblock 370 132 577 minecraft:green_terracotta
setblock 370 132 578 minecraft:oak_log
fill 370 132 579 370 135 579 minecraft:green_terracotta
setblock 370 132 582 minecraft:green_terracotta
setblock 370 132 583 minecraft:oak_log
fill 370 132 584 370 132 587 minecraft:green_terracotta
setblock 370 132 588 minecraft:oak_log
fill 370 132 589 370 135 589 minecraft:green_terracotta
setblock 370 132 593 minecraft:oak_log
fill 370 132 594 370 135 594 minecraft:green_terracotta
setblock 370 132 598 minecraft:oak_log
fill 330 133 558 330 133 561 minecraft:green_terracotta
setblock 330 133 562 minecraft:oak_log
fill 330 133 570 330 133 571 minecraft:green_terracotta
setblock 330 133 572 minecraft:oak_log
fill 330 133 573 330 133 576 minecraft:green_terracotta
setblock 330 133 577 minecraft:oak_log
fill 330 133 578 330 133 581 minecraft:green_terracotta
setblock 330 133 582 minecraft:oak_log
fill 330 133 583 330 133 586 minecraft:green_terracotta
setblock 330 133 587 minecraft:oak_log
fill 330 133 588 330 133 591 minecraft:green_terracotta
setblock 330 133 592 minecraft:oak_log
fill 330 133 593 330 133 596 minecraft:green_terracotta
setblock 330 133 597 minecraft:oak_log
fill 330 133 598 333 133 598 minecraft:green_terracotta
fill 331 133 558 333 133 558 minecraft:green_terracotta
fill 331 133 573 331 133 575 minecraft:green_terracotta
setblock 331 133 576 minecraft:oak_log
fill 331 133 577 331 133 580 minecraft:green_terracotta
setblock 331 133 581 minecraft:oak_log
fill 331 133 582 331 133 585 minecraft:green_terracotta
setblock 331 133 586 minecraft:oak_log
fill 331 133 587 331 133 590 minecraft:green_terracotta
setblock 331 133 591 minecraft:oak_log
fill 331 133 592 331 133 595 minecraft:green_terracotta
setblock 331 133 596 minecraft:oak_log
fill 331 133 597 334 133 597 minecraft:green_terracotta
fill 332 133 576 332 133 579 minecraft:green_terracotta
setblock 332 133 580 minecraft:oak_log
fill 332 133 581 332 136 581 minecraft:green_terracotta
setblock 332 133 594 minecraft:green_terracotta
setblock 332 133 595 minecraft:oak_log
fill 332 133 596 333 133 596 minecraft:green_terracotta
setblock 334 133 558 minecraft:oak_log
setblock 334 133 598 minecraft:oak_log
setblock 335 133 558 minecraft:green_terracotta
setblock 335 133 597 minecraft:oak_log
fill 335 133 598 338 133 598 minecraft:green_terracotta
fill 337 133 588 337 134 588 minecraft:oak_leaves[persistent=true]
setblock 339 133 558 minecraft:oak_leaves[persistent=true]
setblock 343 133 598 minecraft:green_terracotta
setblock 344 133 558 minecraft:oak_log
setblock 344 133 598 minecraft:oak_log
fill 345 133 558 348 133 558 minecraft:green_terracotta
fill 345 133 598 348 133 598 minecraft:green_terracotta
fill 346 133 559 347 133 559 minecraft:green_terracotta
fill 347 133 597 349 133 597 minecraft:green_terracotta
setblock 348 133 559 minecraft:oak_log
setblock 349 133 558 minecraft:oak_log
fill 349 133 559 349 136 559 minecraft:green_terracotta
setblock 349 133 598 minecraft:oak_log
fill 350 133 558 353 133 558 minecraft:green_terracotta
setblock 350 133 597 minecraft:oak_log
fill 350 133 598 353 133 598 minecraft:green_terracotta
fill 351 133 597 353 133 597 minecraft:green_terracotta
setblock 352 133 559 minecraft:green_terracotta
setblock 352 133 560 minecraft:oak_log
setblock 353 133 559 minecraft:oak_log
setblock 353 133 560 minecraft:green_terracotta
setblock 354 133 558 minecraft:oak_log
fill 354 133 559 357 133 559 minecraft:green_terracotta
setblock 354 133 598 minecraft:oak_log
fill 355 133 558 358 133 558 minecraft:green_terracotta
fill 355 133 598 358 133 598 minecraft:green_terracotta
setblock 358 133 559 minecraft:oak_log
setblock 359 133 558 minecraft:oak_log
fill 359 133 559 362 133 559 minecraft:green_terracotta
setblock 359 133 598 minecraft:oak_log
fill 360 133 558 363 133 558 minecraft:green_terracotta
fill 360 133 598 363 133 598 minecraft:green_terracotta
fill 361 133 570 361 133 573 minecraft:dark_oak_log
fill 362 133 568 362 133 569 minecraft:dark_oak_log
setblock 362 133 574 minecraft:dark_oak_log
setblock 363 133 559 minecraft:oak_log
fill 363 133 568 367 133 568 minecraft:dark_oak_log
fill 363 133 575 366 133 575 minecraft:dark_oak_log
fill 363 133 597 364 133 597 minecraft:green_terracotta
setblock 364 133 558 minecraft:oak_log
fill 364 133 559 367 133 559 minecraft:green_terracotta
setblock 364 133 598 minecraft:oak_log
fill 365 133 558 365 136 558 minecraft:green_terracotta
setblock 365 133 597 minecraft:oak_log
fill 365 133 598 365 136 598 minecraft:green_terracotta
setblock 366 133 596 minecraft:oak_log
fill 366 133 597 366 136 597 minecraft:green_terracotta
setblock 367 133 560 minecraft:oak_log
fill 367 133 569 368 133 569 minecraft:dark_oak_log
fill 367 133 574 368 133 574 minecraft:dark_oak_log
fill 367 133 596 367 136 596 minecraft:green_terracotta
setblock 368 133 558 minecraft:green_terracotta
setblock 368 133 559 minecraft:oak_log
fill 368 133 560 368 136 560 minecraft:green_terracotta
fill 368 133 570 368 133 573 minecraft:dark_oak_log
setblock 368 133 594 minecraft:oak_log
fill 368 133 595 368 135 595 minecraft:green_terracotta
setblock 368 133 598 minecraft:green_terracotta
setblock 369 133 558 minecraft:oak_log
fill 369 133 559 369 136 559 minecraft:green_terracotta
setblock 369 133 562 minecraft:green_terracotta
fill 369 133 574 369 133 577 minecraft:green_terracotta
setblock 369 133 578 minecraft:oak_log
fill 369 133 579 369 136 579 minecraft:green_terracotta
setblock 369 133 582 minecraft:green_terracotta
setblock 369 133 592 minecraft:green_terracotta
setblock 369 133 593 minecraft:oak_log
fill 369 133 594 369 136 594 minecraft:green_terracotta
setblock 369 133 597 minecraft:green_terracotta
setblock 369 133 598 minecraft:oak_log
fill 370 133 558 370 136 558 minecraft:green_terracotta
setblock 370 133 562 minecraft:oak_log
fill 370 133 563 370 133 565 minecraft:green_terracotta
fill 370 133 570 370 133 571 minecraft:green_terracotta
setblock 370 133 572 minecraft:oak_log
fill 370 133 573 370 134 573 minecraft:green_terracotta
setblock 370 133 577 minecraft:oak_log
fill 370 133 578 370 136 578 minecraft:green_terracotta
setblock 370 133 582 minecraft:oak_log
fill 370 133 583 370 133 586 minecraft:green_terracotta
setblock 370 133 587 minecraft:oak_log
fill 370 133 588 370 136 588 minecraft:green_terracotta
setblock 370 133 592 minecraft:oak_log
fill 370 133 593 370 136 593 minecraft:green_terracotta
setblock 370 133 597 minecraft:oak_log
fill 370 133 598 370 136 598 minecraft:green_terracotta
fill 330 134 558 330 134 560 minecraft:green_terracotta
setblock 330 134 561 minecraft:oak_log
fill 330 134 562 330 137 562 minecraft:green_terracotta
setblock 330 134 566 minecraft:oak_leaves[persistent=true]
setblock 330 134 571 minecraft:oak_log
fill 330 134 572 330 134 575 minecraft:green_terracotta
setblock 330 134 576 minecraft:oak_log
fill 330 134 577 330 134 580 minecraft:green_terracotta
setblock 330 134 581 minecraft:oak_log
fill 330 134 582 330 134 585 minecraft:green_terracotta
setblock 330 134 586 minecraft:oak_log
fill 330 134 587 330 134 590 minecraft:green_terracotta
setblock 330 134 591 minecraft:oak_log
fill 330 134 592 330 134 595 minecraft:green_terracotta
setblock 330 134 596 minecraft:oak_log
fill 330 134 597 332 134 598 minecraft:green_terracotta
fill 331 134 558 332 134 558 minecraft:green_terracotta
setblock 331 134 574 minecraft:green_terracotta
setblock 331 134 575 minecraft:oak_log
fill 331 134 576 331 134 579 minecraft:green_terracotta
setblock 331 134 580 minecraft:oak_log
fill 331 134 581 331 134 584 minecraft:green_terracotta
setblock 331 134 585 minecraft:oak_log
fill 331 134 586 331 134 589 minecraft:green_terracotta
setblock 331 134 590 minecraft:oak_log
fill 331 134 591 331 134 594 minecraft:green_terracotta
setblock 331 134 595 minecraft:oak_log
fill 331 134 596 331 136 596 minecraft:green_terracotta
fill 332 134 577 332 134 578 minecraft:green_terracotta
setblock 332 134 579 minecraft:oak_log
fill 332 134 580 332 137 580 minecraft:green_terracotta
setblock 333 134 558 minecraft:oak_log
setblock 333 134 597 minecraft:green_terracotta
setblock 333 134 598 minecraft:oak_log
setblock 334 134 558 minecraft:green_terracotta
setblock 334 134 597 minecraft:oak_log
fill 334 134 598 336 134 598 minecraft:green_terracotta
setblock 342 134 598 minecraft:oak_leaves[persistent=true]
setblock 343 134 558 minecraft:oak_log
fill 344 134 558 347 134 558 minecraft:green_terracotta
fill 344 134 598 347 134 598 minecraft:green_terracotta
setblock 346 134 559 minecraft:green_terracotta
setblock 347 134 559 minecraft:oak_log
setblock 348 134 558 minecraft:oak_log
fill 348 134 559 348 137 559 minecraft:green_terracotta
setblock 348 134 597 minecraft:green_terracotta
setblock 348 134 598 minecraft:oak_log
fill 349 134 558 352 134 558 minecraft:green_terracotta
fill 349 134 560 349 135 560 minecraft:green_terracotta
setblock 349 134 597 minecraft:oak_log
fill 349 134 598 352 134 598 minecraft:green_terracotta
fill 350 134 597 351 134 597 minecraft:green_terracotta
setblock 351 134 559 minecraft:green_terracotta
setblock 351 134 560 minecraft:oak_log
setblock 352 134 559 minecraft:oak_log
fill 352 134 560 352 137 560 minecraft:green_terracotta
setblock 353 134 558 minecraft:oak_log
fill 353 134 559 356 134 559 minecraft:green_terracotta
setblock 353 134 598 minecraft:oak_log
fill 354 134 558 357 134 558 minecraft:green_terracotta
fill 354 134 598 357 134 598 minecraft:green_terracotta
setblock 357 134 559 minecraft:oak_log
setblock 358 134 558 minecraft:oak_log
fill 358 134 559 361 134 559 minecraft:green_terracotta
setblock 358 134 598 minecraft:oak_log
fill 359 134 558 362 134 558 minecraft:green_terracotta
fill 359 134 598 362 134 598 minecraft:green_terracotta
setblock 362 134 559 minecraft:oak_log
setblock 363 134 558 minecraft:oak_log
fill 363 134 559 366 134 559 minecraft:green_terracotta
setblock 363 134 597 minecraft:green_terracotta
setblock 363 134 598 minecraft:oak_log
fill 364 134 558 364 137 558 minecraft:green_terracotta
setblock 364 134 597 minecraft:oak_log
fill 364 134 598 364 137 598 minecraft:green_terracotta
fill 365 134 597 365 137 597 minecraft:green_terracotta
setblock 366 134 560 minecraft:oak_log
fill 366 134 596 366 135 596 minecraft:green_terracotta
setblock 367 134 559 minecraft:oak_log
fill 367 134 560 367 137 560 minecraft:green_terracotta
setblock 368 134 558 minecraft:oak_log
fill 368 134 559 368 137 559 minecraft:green_terracotta
setblock 368 134 594 minecraft:green_terracotta
setblock 368 134 598 minecraft:oak_log
fill 369 134 558 369 137 558 minecraft:green_terracotta
setblock 369 134 562 minecraft:oak_log
setblock 369 134 576 minecraft:green_terracotta
setblock 369 134 577 minecraft:oak_log
fill 369 134 578 369 137 578 minecraft:green_terracotta
fill 369 134 580 369 134 581 minecraft:green_terracotta
setblock 369 134 582 minecraft:oak_log
setblock 369 134 592 minecraft:oak_log
fill 369 134 593 369 137 593 minecraft:green_terracotta
setblock 369 134 597 minecraft:oak_log
fill 369 134 598 369 137 598 minecraft:green_terracotta
setblock 370 134 561 minecraft:oak_log
fill 370 134 562 370 135 564 minecraft:green_terracotta
setblock 370 134 565 minecraft:oak_leaves[persistent=true]
setblock 370 134 572 minecraft:green_terracotta
setblock 370 134 576 minecraft:oak_log
fill 370 134 577 370 137 577 minecraft:green_terracotta
setblock 370 134 580 minecraft:green_terracotta
setblock 370 134 581 minecraft:oak_log
fill 370 134 582 370 134 585 minecraft:green_terracotta
setblock 370 134 586 minecraft:oak_log
fill 370 134 587 370 137 587 minecraft:green_terracotta
setblock 370 134 591 minecraft:oak_log
fill 370 134 592 370 137 592 minecraft:green_terracotta
setblock 370 134 596 minecraft:oak_log
fill 370 134 597 370 137 597 minecraft:green_terracotta
fill 330 135 558 330 135 559 minecraft:green_terracotta
setblock 330 135 560 minecraft:oak_log
fill 330 135 561 330 138 561 minecraft:green_terracotta
fill 330 135 572 330 135 574 minecraft:green_terracotta
setblock 330 135 575 minecraft:oak_log
fill 330 135 576 330 135 579 minecraft:green_terracotta
setblock 330 135 580 minecraft:oak_log
fill 330 135 581 330 135 584 minecraft:green_terracotta
setblock 330 135 585 minecraft:oak_log
fill 330 135 586 330 135 589 minecraft:green_terracotta
setblock 330 135 590 minecraft:oak_log
fill 330 135 591 330 135 594 minecraft:green_terracotta
setblock 330 135 595 minecraft:oak_log
fill 330 135 596 330 136 598 minecraft:green_terracotta
setblock 331 135 558 minecraft:green_terracotta
fill 331 135 575 331 135 578 minecraft:green_terracotta
setblock 331 135 579 minecraft:oak_log
fill 331 135 580 331 135 583 minecraft:green_terracotta
setblock 331 135 584 minecraft:oak_log
fill 331 135 585 331 136 587 minecraft:green_terracotta
setblock 331 135 593 minecraft:green_terracotta
setblock 331 135 594 minecraft:oak_log
fill 331 135 595 331 136 595 minecraft:green_terracotta
fill 331 135 597 331 135 598 minecraft:green_terracotta
setblock 332 135 558 minecraft:oak_log
setblock 332 135 578 minecraft:oak_log
fill 332 135 579 332 136 579 minecraft:green_terracotta
setblock 332 135 597 minecraft:green_terracotta
setblock 332 135 598 minecraft:oak_log
fill 333 135 558 333 136 558 minecraft:green_terracotta
fill 333 135 598 335 135 598 minecraft:green_terracotta
fill 337 135 564 339 136 565 minecraft:glowstone
fill 343 135 558 346 135 558 minecraft:green_terracotta
fill 344 135 598 346 135 598 minecraft:green_terracotta
setblock 345 135 559 minecraft:green_terracotta
setblock 346 135 559 minecraft:oak_log
setblock 347 135 558 minecraft:oak_log
fill 347 135 559 347 138 559 minecraft:green_terracotta
setblock 347 135 598 minecraft:oak_log
fill 348 135 558 351 135 558 minecraft:green_terracotta
fill 348 135 560 348 136 560 minecraft:green_terracotta
fill 348 135 598 351 135 598 minecraft:green_terracotta
setblock 350 135 559 minecraft:green_terracotta
setblock 350 135 560 minecraft:oak_log
setblock 351 135 559 minecraft:oak_log
fill 351 135 560 351 138 560 minecraft:green_terracotta
setblock 352 135 558 minecraft:oak_log
fill 352 135 559 355 135 559 minecraft:green_terracotta
setblock 352 135 598 minecraft:oak_log
fill 353 135 558 356 135 558 minecraft:green_terracotta
fill 353 135 598 356 135 598 minecraft:green_terracotta
setblock 356 135 559 minecraft:oak_log
setblock 357 135 558 minecraft:oak_log
fill 357 135 559 360 135 559 minecraft:green_terracotta
setblock 357 135 598 minecraft:oak_log
fill 358 135 558 361 135 558 minecraft:green_terracotta
fill 358 135 598 361 135 598 minecraft:green_terracotta
setblock 361 135 559 minecraft:oak_log
setblock 362 135 558 minecraft:oak_log
fill 362 135 559 365 135 559 minecraft:green_terracotta
setblock 362 135 598 minecraft:oak_log
fill 363 135 558 363 138 558 minecraft:green_terracotta
setblock 363 135 597 minecraft:oak_log
fill 363 135 598 363 138 598 minecraft:green_terracotta
fill 364 135 597 364 138 597 minecraft:green_terracotta
setblock 366 135 559 minecraft:oak_log
fill 366 135 560 366 138 560 minecraft:green_terracotta
setblock 367 135 558 minecraft:oak_log
fill 367 135 559 367 138 559 minecraft:green_terracotta
setblock 367 135 598 minecraft:oak_log
fill 368 135 558 368 138 558 minecraft:green_terracotta
setblock 368 135 597 minecraft:oak_log
fill 368 135 598 368 138 598 minecraft:green_terracotta
setblock 369 135 561 minecraft:oak_log
fill 369 135 562 369 138 562 minecraft:green_terracotta
setblock 369 135 577 minecraft:green_terracotta
setblock 369 135 580 minecraft:green_terracotta
setblock 369 135 581 minecraft:oak_log
fill 369 135 582 370 136 583 minecraft:green_terracotta
fill 369 135 592 369 136 592 minecraft:green_terracotta
setblock 369 135 596 minecraft:oak_log
fill 369 135 597 369 138 597 minecraft:green_terracotta
setblock 370 135 560 minecraft:oak_log
fill 370 135 561 370 138 561 minecraft:green_terracotta
setblock 370 135 575 minecraft:oak_log
fill 370 135 576 370 138 576 minecraft:green_terracotta
setblock 370 135 580 minecraft:oak_log
fill 370 135 581 370 138 581 minecraft:green_terracotta
setblock 370 135 584 minecraft:green_terracotta
setblock 370 135 585 minecraft:oak_log
fill 370 135 586 370 138 586 minecraft:green_terracotta
setblock 370 135 590 minecraft:oak_log
fill 370 135 591 370 138 591 minecraft:green_terracotta
setblock 370 135 595 minecraft:oak_log
fill 370 135 596 370 138 596 minecraft:green_terracotta
setblock 330 136 558 minecraft:green_terracotta
setblock 330 136 559 minecraft:oak_log
fill 330 136 560 330 139 560 minecraft:green_terracotta
setblock 330 136 573 minecraft:green_terracotta
setblock 330 136 574 minecraft:oak_log
fill 330 136 575 330 136 578 minecraft:green_terracotta
setblock 330 136 579 minecraft:oak_log
fill 330 136 580 330 136 583 minecraft:green_terracotta
setblock 330 136 584 minecraft:oak_log
fill 330 136 585 330 136 588 minecraft:green_terracotta
setblock 330 136 589 minecraft:oak_log
fill 330 136 590 330 136 593 minecraft:green_terracotta
setblock 330 136 594 minecraft:oak_log
fill 330 136 595 330 139 595 minecraft:green_terracotta
setblock 331 136 558 minecraft:oak_log
fill 331 136 576 331 136 577 minecraft:green_terracotta
setblock 331 136 578 minecraft:oak_log
fill 331 136 579 331 136 582 minecraft:green_terracotta
setblock 331 136 583 minecraft:oak_log
fill 331 136 584 331 139 584 minecraft:green_terracotta
setblock 331 136 597 minecraft:green_terracotta
setblock 331 136 598 minecraft:oak_log
fill 332 136 558 332 139 558 minecraft:green_terracotta
setblock 332 136 582 minecraft:oak_log
fill 332 136 598 334 136 598 minecraft:green_terracotta
setblock 335 136 598 minecraft:oak_leaves[persistent=true]
setblock 340 136 558 minecraft:oak_leaves[persistent=true]
fill 342 136 558 345 136 558 minecraft:green_terracotta
setblock 344 136 559 minecraft:green_terracotta
setblock 345 136 559 minecraft:oak_log
setblock 345 136 598 minecraft:green_terracotta
setblock 346 136 558 minecraft:oak_log
fill 346 136 559 346 139 559 minecraft:green_terracotta
setblock 346 136 598 minecraft:oak_log
fill 347 136 558 350 136 558 minecraft:green_terracotta
fill 347 136 560 347 137 560 minecraft:green_terracotta
fill 347 136 578 349 179 578 minecraft:oak_log
fill 347 136 598 350 136 598 minecraft:green_terracotta
fill 348 136 577 349 179 577 minecraft:oak_log
fill 348 136 579 349 179 579 minecraft:oak_log
setblock 349 136 560 minecraft:oak_log
fill 349 136 576 350 179 576 minecraft:oak_log
fill 349 136 580 350 179 580 minecraft:oak_log
setblock 350 136 559 minecraft:oak_log
fill 350 136 560 350 139 560 minecraft:green_terracotta
setblock 351 136 558 minecraft:oak_log
fill 351 136 559 354 136 559 minecraft:green_terracotta
setblock 351 136 598 minecraft:oak_log
fill 352 136 558 355 136 558 minecraft:green_terracotta
fill 352 136 598 354 136 598 minecraft:green_terracotta
setblock 355 136 559 minecraft:oak_log
setblock 356 136 558 minecraft:oak_log
fill 356 136 559 359 136 559 minecraft:green_terracotta
fill 357 136 558 360 136 558 minecraft:green_terracotta
fill 359 136 598 360 136 598 minecraft:green_terracotta
setblock 360 136 559 minecraft:oak_log
setblock 361 136 558 minecraft:oak_log
fill 361 136 559 364 136 559 minecraft:green_terracotta
setblock 361 136 598 minecraft:oak_log
fill 362 136 558 362 139 558 minecraft:green_terracotta
fill 362 136 598 362 139 598 minecraft:green_terracotta
fill 363 136 597 363 139 597 minecraft:green_terracotta
setblock 365 136 559 minecraft:oak_log
fill 365 136 560 365 139 560 minecraft:green_terracotta
setblock 366 136 558 minecraft:oak_log
fill 366 136 559 366 139 559 minecraft:green_terracotta
setblock 366 136 598 minecraft:oak_log
fill 367 136 558 367 139 558 minecraft:green_terracotta
setblock 367 136 597 minecraft:oak_log
fill 367 136 598 367 139 598 minecraft:green_terracotta
setblock 368 136 596 minecraft:oak_log
fill 368 136 597 368 139 597 minecraft:green_terracotta
setblock 369 136 560 minecraft:oak_log
fill 369 136 561 369 139 561 minecraft:green_terracotta
setblock 369 136 580 minecraft:oak_log
fill 369 136 581 369 139 581 minecraft:green_terracotta
setblock 369 136 584 minecraft:green_terracotta
setblock 369 136 585 minecraft:oak_log
setblock 369 136 595 minecraft:oak_log
fill 369 136 596 369 139 596 minecraft:green_terracotta
setblock 370 136 559 minecraft:oak_log
fill 370 136 560 370 139 560 minecraft:green_terracotta
fill 370 136 562 370 136 563 minecraft:green_terracotta
setblock 370 136 564 minecraft:oak_log
setblock 370 136 572 minecraft:oak_leaves[persistent=true]
fill 370 136 575 370 137 575 minecraft:green_terracotta
setblock 370 136 579 minecraft:oak_log
fill 370 136 580 370 139 580 minecraft:green_terracotta
setblock 370 136 584 minecraft:oak_log
fill 370 136 585 370 139 585 minecraft:green_terracotta
setblock 370 136 589 minecraft:oak_log
fill 370 136 590 370 139 590 minecraft:green_terracotta
setblock 370 136 594 minecraft:oak_log
fill 370 136 595 370 139 595 minecraft:green_terracotta
setblock 330 137 558 minecraft:oak_log
fill 330 137 559 330 140 559 minecraft:green_terracotta
setblock 330 137 565 minecraft:oak_leaves[persistent=true]
fill 330 137 574 330 137 577 minecraft:green_terracotta
setblock 330 137 578 minecraft:oak_log
fill 330 137 579 330 137 582 minecraft:green_terracotta
setblock 330 137 583 minecraft:oak_log
fill 330 137 584 330 137 587 minecraft:green_terracotta
setblock 330 137 588 minecraft:oak_log
fill 330 137 589 330 137 592 minecraft:green_terracotta
setblock 330 137 593 minecraft:oak_log
fill 330 137 594 330 140 594 minecraft:green_terracotta
fill 330 137 596 330 137 597 minecraft:green_terracotta
setblock 330 137 598 minecraft:oak_log
fill 331 137 558 331 140 558 minecraft:green_terracotta
setblock 331 137 576 minecraft:green_terracotta
setblock 331 137 577 minecraft:oak_log
fill 331 137 578 331 137 581 minecraft:green_terracotta
setblock 331 137 582 minecraft:oak_log
fill 331 137 583 331 140 583 minecraft:green_terracotta
fill 331 137 585 331 137 586 minecraft:green_terracotta
setblock 331 137 587 minecraft:oak_log
fill 331 137 598 333 137 598 minecraft:green_terracotta
setblock 332 137 560 minecraft:light[level=14]
setblock 332 137 568 minecraft:light[level=14]
setblock 332 137 576 minecraft:light[level=14]
setblock 332 137 581 minecraft:oak_log
fill 332 137 582 332 140 582 minecraft:green_terracotta
setblock 332 137 584 minecraft:light[level=14]
setblock 332 137 592 minecraft:light[level=14]
setblock 334 137 558 minecraft:oak_leaves[persistent=true]
setblock 340 137 560 minecraft:light[level=14]
setblock 340 137 568 minecraft:light[level=14]
setblock 340 137 576 minecraft:light[level=14]
setblock 340 137 584 minecraft:light[level=14]
setblock 340 137 592 minecraft:light[level=14]
setblock 341 137 598 minecraft:oak_leaves[persistent=true]
fill 342 137 558 344 137 558 minecraft:green_terracotta
setblock 344 137 559 minecraft:oak_log
setblock 344 137 598 minecraft:green_terracotta
setblock 345 137 558 minecraft:oak_log
fill 345 137 559 345 140 559 minecraft:green_terracotta
setblock 345 137 598 minecraft:oak_log
fill 346 137 558 349 137 558 minecraft:green_terracotta
fill 346 137 560 346 138 560 minecraft:green_terracotta
fill 346 137 598 349 137 598 minecraft:green_terracotta
fill 347 137 576 347 138 577 minecraft:dark_oak_log
fill 347 137 579 347 138 580 minecraft:dark_oak_log
setblock 348 137 560 minecraft:oak_log
setblock 348 137 568 minecraft:light[level=14]
fill 348 137 576 348 138 576 minecraft:dark_oak_log
fill 348 137 580 348 138 581 minecraft:dark_oak_log
setblock 348 137 584 minecraft:light[level=14]
setblock 348 137 592 minecraft:light[level=14]
setblock 349 137 559 minecraft:oak_log
fill 349 137 560 349 140 560 minecraft:green_terracotta
fill 349 137 575 349 138 575 minecraft:dark_oak_log
fill 349 137 581 350 138 581 minecraft:dark_oak_log
setblock 350 137 558 minecraft:oak_log
fill 350 137 559 353 137 559 minecraft:green_terracotta
setblock 350 137 598 minecraft:oak_log
fill 351 137 558 354 137 558 minecraft:green_terracotta
fill 351 137 598 353 137 598 minecraft:green_terracotta
setblock 354 137 559 minecraft:oak_log
setblock 355 137 558 minecraft:oak_log
fill 355 137 559 358 137 559 minecraft:green_terracotta
fill 356 137 558 359 137 558 minecraft:green_terracotta
setblock 356 137 560 minecraft:light[level=14]
setblock 356 137 568 minecraft:light[level=14]
setblock 356 137 576 minecraft:light[level=14]
setblock 356 137 584 minecraft:light[level=14]
setblock 356 137 592 minecraft:light[level=14]
setblock 359 137 559 minecraft:oak_log
setblock 359 137 598 minecraft:green_terracotta
setblock 360 137 558 minecraft:oak_log
fill 360 137 559 363 137 559 minecraft:green_terracotta
setblock 360 137 598 minecraft:oak_log
fill 361 137 558 361 140 558 minecraft:green_terracotta
fill 361 137 598 361 140 598 minecraft:green_terracotta
setblock 363 137 560 minecraft:oak_log
setblock 364 137 559 minecraft:oak_log
fill 364 137 560 364 140 560 minecraft:green_terracotta
setblock 364 137 568 minecraft:light[level=14]
setblock 364 137 576 minecraft:light[level=14]
setblock 364 137 584 minecraft:light[level=14]
setblock 364 137 592 minecraft:light[level=14]
setblock 365 137 558 minecraft:oak_log
fill 365 137 559 365 140 559 minecraft:green_terracotta
setblock 365 137 598 minecraft:oak_log
fill 366 137 558 366 140 558 minecraft:green_terracotta
setblock 366 137 597 minecraft:oak_log
fill 366 137 598 366 140 598 minecraft:green_terracotta
setblock 367 137 596 minecraft:oak_log
fill 367 137 597 367 140 597 minecraft:green_terracotta
setblock 368 137 560 minecraft:oak_log
fill 368 137 561 368 140 561 minecraft:green_terracotta
fill 368 137 596 368 138 596 minecraft:green_terracotta
setblock 369 137 559 minecraft:oak_log
fill 369 137 560 369 140 560 minecraft:green_terracotta
setblock 369 137 563 minecraft:green_terracotta
setblock 369 137 579 minecraft:oak_log
fill 369 137 580 369 140 580 minecraft:green_terracotta
fill 369 137 582 369 137 583 minecraft:green_terracotta
setblock 369 137 584 minecraft:oak_log
fill 369 137 585 369 139 586 minecraft:green_terracotta
setblock 369 137 594 minecraft:oak_log
fill 369 137 595 369 140 595 minecraft:green_terracotta
setblock 370 137 558 minecraft:oak_log
fill 370 137 559 370 140 559 minecraft:green_terracotta
setblock 370 137 562 minecraft:green_terracotta
setblock 370 137 563 minecraft:oak_log
fill 370 137 564 370 140 564 minecraft:green_terracotta
setblock 370 137 566 minecraft:oak_leaves[persistent=true]
setblock 370 137 578 minecraft:oak_log
fill 370 137 579 370 140 579 minecraft:green_terracotta
setblock 370 137 582 minecraft:green_terracotta
setblock 370 137 583 minecraft:oak_log
fill 370 137 584 370 140 584 minecraft:green_terracotta
setblock 370 137 588 minecraft:oak_log
fill 370 137 589 370 140 589 minecraft:green_terracotta
setblock 370 137 593 minecraft:oak_log
fill 370 137 594 370 140 594 minecraft:green_terracotta
setblock 370 137 598 minecraft:oak_log
fill 330 138 558 330 141 558 minecraft:green_terracotta
setblock 330 138 562 minecraft:oak_log
fill 330 138 563 330 141 563 minecraft:green_terracotta
setblock 330 138 571 minecraft:oak_leaves[persistent=true]
fill 330 138 574 330 138 576 minecraft:green_terracotta
setblock 330 138 577 minecraft:oak_log
fill 330 138 578 330 138 581 minecraft:green_terracotta
setblock 330 138 582 minecraft:oak_log
fill 330 138 583 330 138 586 minecraft:green_terracotta
setblock 330 138 587 minecraft:oak_log
fill 330 138 588 330 138 591 minecraft:green_terracotta
setblock 330 138 592 minecraft:oak_log
fill 330 138 593 330 141 593 minecraft:green_terracotta
setblock 330 138 596 minecraft:green_terracotta
setblock 330 138 597 minecraft:oak_log
fill 330 138 598 332 138 598 minecraft:green_terracotta
fill 331 138 577 331 138 580 minecraft:green_terracotta
setblock 331 138 581 minecraft:oak_log
fill 331 138 582 331 141 582 minecraft:green_terracotta
setblock 331 138 585 minecraft:green_terracotta
setblock 331 138 586 minecraft:oak_log
fill 331 138 587 331 141 587 minecraft:green_terracotta
setblock 332 138 580 minecraft:oak_log
fill 332 138 581 332 141 581 minecraft:green_terracotta
fill 332 138 583 332 139 583 minecraft:green_terracotta
fill 341 138 558 343 138 558 minecraft:green_terracotta
setblock 343 138 559 minecraft:oak_log
setblock 344 138 558 minecraft:oak_log
fill 344 138 559 344 141 559 minecraft:green_terracotta
setblock 344 138 598 minecraft:oak_log
fill 345 138 558 348 138 558 minecraft:green_terracotta
fill 345 138 560 345 139 560 minecraft:green_terracotta
fill 345 138 598 348 138 598 minecraft:green_terracotta
fill 346 138 576 346 138 580 minecraft:dark_oak_log
setblock 347 138 560 minecraft:oak_log
fill 347 138 575 348 138 575 minecraft:dark_oak_log
setblock 347 138 581 minecraft:dark_oak_log
setblock 348 138 559 minecraft:oak_log
fill 348 138 560 348 141 560 minecraft:green_terracotta
setblock 349 138 558 minecraft:oak_log
fill 349 138 559 352 138 559 minecraft:green_terracotta
setblock 349 138 574 minecraft:dark_oak_log
fill 349 138 582 350 138 582 minecraft:dark_oak_log
setblock 349 138 598 minecraft:oak_log
fill 350 138 558 353 138 558 minecraft:green_terracotta
fill 350 138 575 351 138 575 minecraft:dark_oak_log
fill 350 138 598 352 138 598 minecraft:green_terracotta
fill 351 138 581 352 138 581 minecraft:dark_oak_log
setblock 352 138 560 minecraft:oak_log
setblock 353 138 559 minecraft:oak_log
setblock 354 138 558 minecraft:oak_log
fill 354 138 559 357 138 559 minecraft:green_terracotta
fill 355 138 558 358 138 558 minecraft:green_terracotta
setblock 358 138 559 minecraft:oak_log
setblock 359 138 558 minecraft:oak_log
fill 359 138 559 362 138 559 minecraft:green_terracotta
setblock 359 138 598 minecraft:oak_log
fill 360 138 558 360 141 558 minecraft:green_terracotta
fill 360 138 598 360 141 598 minecraft:green_terracotta
setblock 362 138 560 minecraft:oak_log
setblock 363 138 559 minecraft:oak_log
fill 363 138 560 363 141 560 minecraft:green_terracotta
setblock 364 138 558 minecraft:oak_log
fill 364 138 559 364 141 559 minecraft:green_terracotta
setblock 364 138 598 minecraft:oak_log
fill 365 138 558 365 141 558 minecraft:green_terracotta
setblock 365 138 597 minecraft:oak_log
fill 365 138 598 365 141 598 minecraft:green_terracotta
fill 366 138 597 366 141 597 minecraft:green_terracotta
setblock 367 138 560 minecraft:oak_log
fill 367 138 596 367 141 596 minecraft:green_terracotta
setblock 368 138 559 minecraft:oak_log
fill 368 138 560 368 141 560 minecraft:green_terracotta
setblock 369 138 558 minecraft:oak_log
fill 369 138 559 369 141 559 minecraft:green_terracotta
setblock 369 138 563 minecraft:oak_log
setblock 369 138 578 minecraft:oak_log
fill 369 138 579 369 141 579 minecraft:green_terracotta
setblock 369 138 582 minecraft:green_terracotta
setblock 369 138 583 minecraft:oak_log
fill 369 138 584 369 141 584 minecraft:green_terracotta
setblock 369 138 587 minecraft:green_terracotta
setblock 369 138 588 minecraft:oak_log
fill 369 138 589 369 141 589 minecraft:green_terracotta
setblock 369 138 592 minecraft:green_terracotta
setblock 369 138 593 minecraft:oak_log
fill 369 138 594 369 141 594 minecraft:green_terracotta
setblock 369 138 598 minecraft:oak_log
fill 370 138 558 370 141 558 minecraft:green_terracotta
setblock 370 138 562 minecraft:oak_log
fill 370 138 563 370 141 563 minecraft:green_terracotta
setblock 370 138 577 minecraft:oak_log
fill 370 138 578 370 141 578 minecraft:green_terracotta
setblock 370 138 582 minecraft:oak_log
fill 370 138 583 370 141 583 minecraft:green_terracotta
setblock 370 138 587 minecraft:oak_log
fill 370 138 588 370 141 588 minecraft:green_terracotta
setblock 370 138 592 minecraft:oak_log
fill 370 138 593 370 141 593 minecraft:green_terracotta
setblock 370 138 597 minecraft:oak_log
fill 370 138 598 370 141 598 minecraft:green_terracotta
setblock 330 139 561 minecraft:oak_log
fill 330 139 562 330 142 562 minecraft:green_terracotta
fill 330 139 564 330 140 564 minecraft:green_terracotta
fill 330 139 574 330 139 575 minecraft:green_terracotta
setblock 330 139 576 minecraft:oak_log
fill 330 139 577 330 139 580 minecraft:green_terracotta
setblock 330 139 581 minecraft:oak_log
fill 330 139 582 330 139 585 minecraft:green_terracotta
setblock 330 139 586 minecraft:oak_log
fill 330 139 587 330 139 590 minecraft:green_terracotta
setblock 330 139 591 minecraft:oak_log
fill 330 139 592 330 142 592 minecraft:green_terracotta
setblock 330 139 596 minecraft:oak_log
fill 330 139 597 330 141 598 minecraft:green_terracotta
fill 331 139 577 331 139 579 minecraft:green_terracotta
setblock 331 139 580 minecraft:oak_log
fill 331 139 581 331 142 581 minecraft:green_terracotta
setblock 331 139 585 minecraft:oak_log
fill 331 139 586 331 142 586 minecraft:green_terracotta
fill 331 139 588 331 140 588 minecraft:green_terracotta
fill 331 139 598 331 140 598 minecraft:green_terracotta
fill 332 139 580 332 140 580 minecraft:green_terracotta
setblock 332 139 584 minecraft:oak_log
setblock 334 139 598 minecraft:oak_leaves[persistent=true]
fill 340 139 558 342 139 558 minecraft:green_terracotta
fill 341 139 585 341 140 586 minecraft:oak_leaves[persistent=true]
setblock 342 139 559 minecraft:oak_log
setblock 343 139 558 minecraft:oak_log
fill 343 139 559 343 142 559 minecraft:green_terracotta
fill 344 139 558 347 139 558 minecraft:green_terracotta
fill 344 139 560 344 140 560 minecraft:green_terracotta
fill 344 139 598 347 139 598 minecraft:green_terracotta
setblock 346 139 560 minecraft:oak_log
setblock 347 139 559 minecraft:oak_log
fill 347 139 560 347 141 561 minecraft:green_terracotta
setblock 348 139 558 minecraft:oak_log
fill 348 139 559 351 139 559 minecraft:green_terracotta
fill 348 139 561 348 140 561 minecraft:green_terracotta
setblock 348 139 598 minecraft:oak_log
fill 349 139 558 352 139 558 minecraft:green_terracotta
fill 349 139 598 351 140 598 minecraft:green_terracotta
setblock 351 139 560 minecraft:oak_log
setblock 352 139 559 minecraft:oak_log
fill 352 139 560 353 141 560 minecraft:green_terracotta
setblock 353 139 558 minecraft:oak_log
fill 353 139 559 356 139 559 minecraft:green_terracotta
setblock 353 139 598 minecraft:oak_leaves[persistent=true]
fill 354 139 558 357 139 558 minecraft:green_terracotta
setblock 357 139 559 minecraft:oak_log
setblock 358 139 558 minecraft:oak_log
fill 358 139 559 361 139 559 minecraft:green_terracotta
fill 359 139 558 359 142 558 minecraft:green_terracotta
fill 359 139 598 359 142 598 minecraft:green_terracotta
setblock 361 139 560 minecraft:oak_log
setblock 362 139 559 minecraft:oak_log
fill 362 139 560 362 142 560 minecraft:green_terracotta
fill 362 139 597 362 140 597 minecraft:green_terracotta
setblock 363 139 558 minecraft:oak_log
fill 363 139 559 363 142 559 minecraft:green_terracotta
setblock 363 139 598 minecraft:oak_log
fill 364 139 558 364 142 558 minecraft:green_terracotta
setblock 364 139 597 minecraft:oak_log
fill 364 139 598 364 142 598 minecraft:green_terracotta
fill 365 139 597 365 142 597 minecraft:green_terracotta
setblock 366 139 560 minecraft:oak_log
setblock 367 139 559 minecraft:oak_log
fill 367 139 560 367 142 560 minecraft:green_terracotta
setblock 368 139 558 minecraft:oak_log
fill 368 139 559 368 142 559 minecraft:green_terracotta
setblock 368 139 562 minecraft:green_terracotta
fill 368 139 581 368 139 582 minecraft:green_terracotta
setblock 368 139 583 minecraft:oak_log
fill 368 139 584 368 141 585 minecraft:green_terracotta
setblock 368 139 598 minecraft:oak_log
fill 369 139 558 369 142 558 minecraft:green_terracotta
setblock 369 139 562 minecraft:oak_log
fill 369 139 563 369 142 563 minecraft:green_terracotta
fill 369 139 578 369 140 578 minecraft:green_terracotta
setblock 369 139 582 minecraft:oak_log
fill 369 139 583 369 142 583 minecraft:green_terracotta
setblock 369 139 587 minecraft:oak_log
fill 369 139 588 369 142 588 minecraft:green_terracotta
fill 369 139 590 369 139 591 minecraft:green_terracotta
setblock 369 139 592 minecraft:oak_log
fill 369 139 593 369 142 593 minecraft:green_terracotta
setblock 369 139 597 minecraft:oak_log
fill 369 139 598 369 142 598 minecraft:green_terracotta
setblock 370 139 561 minecraft:oak_log
fill 370 139 562 370 142 562 minecraft:green_terracotta
setblock 370 139 565 minecraft:green_terracotta
setblock 370 139 576 minecraft:oak_log
fill 370 139 577 370 142 577 minecraft:green_terracotta
setblock 370 139 581 minecraft:oak_log
fill 370 139 582 370 142 582 minecraft:green_terracotta
setblock 370 139 586 minecraft:oak_log
fill 370 139 587 370 142 587 minecraft:green_terracotta
setblock 370 139 591 minecraft:oak_log
fill 370 139 592 370 142 592 minecraft:green_terracotta
setblock 370 139 596 minecraft:oak_log
fill 370 139 597 370 142 597 minecraft:green_terracotta
setblock 330 140 560 minecraft:oak_log
fill 330 140 561 330 143 561 minecraft:green_terracotta
setblock 330 140 565 minecraft:oak_log
setblock 330 140 574 minecraft:green_terracotta
setblock 330 140 575 minecraft:oak_log
fill 330 140 576 330 140 579 minecraft:green_terracotta
setblock 330 140 580 minecraft:oak_log
fill 330 140 581 330 140 584 minecraft:green_terracotta
setblock 330 140 585 minecraft:oak_log
fill 330 140 586 330 140 589 minecraft:green_terracotta
setblock 330 140 590 minecraft:oak_log
fill 330 140 591 330 143 591 minecraft:green_terracotta
setblock 330 140 595 minecraft:oak_log
fill 330 140 596 330 141 596 minecraft:green_terracotta
fill 331 140 577 331 140 578 minecraft:green_terracotta
setblock 331 140 579 minecraft:oak_log
fill 331 140 580 331 143 580 minecraft:green_terracotta
setblock 331 140 584 minecraft:oak_log
fill 331 140 585 332 142 585 minecraft:green_terracotta
setblock 331 140 589 minecraft:oak_log
setblock 332 140 583 minecraft:oak_log
fill 332 140 584 332 143 584 minecraft:green_terracotta
fill 339 140 558 341 140 558 minecraft:green_terracotta
setblock 340 140 598 minecraft:oak_leaves[persistent=true]
setblock 341 140 559 minecraft:oak_log
setblock 342 140 558 minecraft:oak_log
fill 342 140 559 342 143 559 minecraft:green_terracotta
fill 343 140 558 346 140 558 minecraft:green_terracotta
fill 343 140 560 343 141 560 minecraft:green_terracotta
fill 343 140 598 346 140 598 minecraft:green_terracotta
setblock 345 140 560 minecraft:oak_log
fill 345 140 561 346 142 561 minecraft:green_terracotta
setblock 346 140 559 minecraft:oak_log
fill 346 140 560 346 143 560 minecraft:green_terracotta
setblock 347 140 558 minecraft:oak_log
fill 347 140 559 350 140 559 minecraft:green_terracotta
setblock 347 140 598 minecraft:oak_log
fill 348 140 558 351 140 558 minecraft:green_terracotta
fill 348 140 598 348 143 598 minecraft:green_terracotta
setblock 349 140 561 minecraft:oak_log
setblock 350 140 560 minecraft:oak_log
setblock 351 140 559 minecraft:oak_log
fill 351 140 560 351 143 560 minecraft:green_terracotta
setblock 352 140 558 minecraft:oak_log
fill 352 140 559 355 140 559 minecraft:green_terracotta
fill 353 140 558 356 140 558 minecraft:green_terracotta
setblock 356 140 559 minecraft:oak_log
setblock 357 140 558 minecraft:oak_log
fill 357 140 559 360 140 559 minecraft:green_terracotta
fill 358 140 558 358 143 558 minecraft:green_terracotta
fill 358 140 598 358 143 598 minecraft:green_terracotta
setblock 359 140 560 minecraft:green_terracotta
setblock 360 140 560 minecraft:oak_log
setblock 361 140 559 minecraft:oak_log
fill 361 140 560 361 143 560 minecraft:green_terracotta
setblock 362 140 558 minecraft:oak_log
fill 362 140 559 362 143 559 minecraft:green_terracotta
setblock 362 140 598 minecraft:oak_log
fill 363 140 558 363 143 558 minecraft:green_terracotta
setblock 363 140 597 minecraft:oak_log
fill 363 140 598 363 143 598 minecraft:green_terracotta
fill 364 140 597 364 143 597 minecraft:green_terracotta
setblock 365 140 560 minecraft:oak_log
setblock 366 140 559 minecraft:oak_log
fill 366 140 560 366 143 560 minecraft:green_terracotta
fill 366 140 596 366 142 596 minecraft:green_terracotta
setblock 367 140 558 minecraft:oak_log
fill 367 140 559 367 143 559 minecraft:green_terracotta
setblock 367 140 598 minecraft:oak_log
fill 368 140 558 368 143 558 minecraft:green_terracotta
setblock 368 140 562 minecraft:oak_log
setblock 368 140 581 minecraft:green_terracotta
setblock 368 140 582 minecraft:oak_log
fill 368 140 583 368 143 583 minecraft:green_terracotta
setblock 368 140 586 minecraft:green_terracotta
setblock 368 140 587 minecraft:oak_log
fill 368 140 588 368 143 588 minecraft:green_terracotta
setblock 368 140 597 minecraft:oak_log
fill 368 140 598 368 143 598 minecraft:green_terracotta
setblock 369 140 561 minecraft:oak_log
fill 369 140 562 369 143 562 minecraft:green_terracotta
fill 369 140 564 369 141 564 minecraft:green_terracotta
setblock 369 140 581 minecraft:oak_log
fill 369 140 582 369 143 582 minecraft:green_terracotta
setblock 369 140 585 minecraft:green_terracotta
setblock 369 140 586 minecraft:oak_log
fill 369 140 587 369 143 587 minecraft:green_terracotta
setblock 369 140 590 minecraft:green_terracotta
setblock 369 140 591 minecraft:oak_log
fill 369 140 592 369 143 592 minecraft:green_terracotta
setblock 369 140 596 minecraft:oak_log
fill 369 140 597 369 143 597 minecraft:green_terracotta
setblock 370 140 560 minecraft:oak_log
fill 370 140 561 370 143 561 minecraft:green_terracotta
setblock 370 140 565 minecraft:oak_log
fill 370 140 566 370 143 566 minecraft:green_terracotta
setblock 370 140 573 minecraft:oak_leaves[persistent=true]
setblock 370 140 576 minecraft:green_terracotta
setblock 370 140 580 minecraft:oak_log
fill 370 140 581 370 143 581 minecraft:green_terracotta
setblock 370 140 585 minecraft:oak_log
fill 370 140 586 370 143 586 minecraft:green_terracotta
setblock 370 140 590 minecraft:oak_log
fill 370 140 591 370 143 591 minecraft:green_terracotta
setblock 370 140 595 minecraft:oak_log
fill 370 140 596 370 143 596 minecraft:green_terracotta
setblock 330 141 559 minecraft:oak_log
fill 330 141 560 330 144 560 minecraft:green_terracotta
setblock 330 141 564 minecraft:oak_log
fill 330 141 565 330 142 567 minecraft:green_terracotta
setblock 330 141 570 minecraft:oak_leaves[persistent=true]
setblock 330 141 574 minecraft:oak_log
fill 330 141 575 330 141 578 minecraft:green_terracotta
setblock 330 141 579 minecraft:oak_log
fill 330 141 580 330 141 583 minecraft:green_terracotta
setblock 330 141 584 minecraft:oak_log
fill 330 141 585 330 141 588 minecraft:green_terracotta
setblock 330 141 589 minecraft:oak_log
fill 330 141 590 330 144 590 minecraft:green_terracotta
setblock 330 141 594 minecraft:oak_log
setblock 330 141 595 minecraft:green_terracotta
setblock 331 141 558 minecraft:oak_log
setblock 331 141 577 minecraft:green_terracotta
setblock 331 141 578 minecraft:oak_log
fill 331 141 579 331 144 579 minecraft:green_terracotta
setblock 331 141 583 minecraft:oak_log
fill 331 141 584 331 144 584 minecraft:green_terracotta
setblock 331 141 588 minecraft:oak_log
fill 331 141 589 331 144 589 minecraft:green_terracotta
setblock 332 141 582 minecraft:oak_log
fill 332 141 583 332 144 583 minecraft:green_terracotta
setblock 335 141 558 minecraft:oak_leaves[persistent=true]
fill 339 141 558 340 141 558 minecraft:green_terracotta
setblock 340 141 559 minecraft:oak_log
setblock 341 141 558 minecraft:oak_log
fill 341 141 559 341 144 559 minecraft:green_terracotta
fill 342 141 558 345 141 558 minecraft:green_terracotta
fill 342 141 560 342 142 560 minecraft:green_terracotta
fill 342 141 561 342 142 561 minecraft:oak_leaves[persistent=true]
setblock 343 141 561 minecraft:oak_log
fill 343 141 598 345 141 598 minecraft:green_terracotta
setblock 344 141 560 minecraft:oak_log
fill 344 141 561 344 144 561 minecraft:green_terracotta
setblock 345 141 559 minecraft:oak_log
fill 345 141 560 345 144 560 minecraft:green_terracotta
setblock 346 141 558 minecraft:oak_log
fill 346 141 559 349 141 559 minecraft:green_terracotta
setblock 346 141 598 minecraft:oak_log
fill 347 141 558 350 141 558 minecraft:green_terracotta
fill 347 141 598 347 144 598 minecraft:green_terracotta
setblock 348 141 561 minecraft:oak_log
setblock 349 141 560 minecraft:oak_log
fill 349 141 561 350 142 561 minecraft:green_terracotta
fill 349 141 598 350 141 598 minecraft:green_terracotta
setblock 350 141 559 minecraft:oak_log
fill 350 141 560 350 144 560 minecraft:green_terracotta
fill 350 141 577 350 179 577 minecraft:oak_log
setblock 351 141 558 minecraft:oak_log
fill 351 141 559 354 141 559 minecraft:green_terracotta
fill 352 141 558 355 141 558 minecraft:green_terracotta
setblock 355 141 559 minecraft:oak_log
setblock 356 141 558 minecraft:oak_log
fill 356 141 559 359 141 559 minecraft:green_terracotta
fill 357 141 558 357 144 558 minecraft:green_terracotta
fill 357 141 598 357 144 598 minecraft:green_terracotta
setblock 358 141 560 minecraft:green_terracotta
setblock 359 141 560 minecraft:oak_log
setblock 360 141 559 minecraft:oak_log
fill 360 141 560 360 144 560 minecraft:green_terracotta
setblock 361 141 558 minecraft:oak_log
fill 361 141 559 361 144 559 minecraft:green_terracotta
setblock 361 141 597 minecraft:green_terracotta
setblock 361 141 598 minecraft:oak_log
fill 362 141 558 362 144 558 minecraft:green_terracotta
setblock 362 141 597 minecraft:oak_log
fill 362 141 598 362 144 598 minecraft:green_terracotta
setblock 363 141 561 minecraft:oak_log
fill 363 141 597 363 144 597 minecraft:green_terracotta
setblock 364 141 560 minecraft:oak_log
fill 364 141 561 366 141 561 minecraft:green_terracotta
setblock 365 141 559 minecraft:oak_log
fill 365 141 560 365 144 560 minecraft:green_terracotta
fill 365 141 596 365 143 596 minecraft:green_terracotta
setblock 366 141 558 minecraft:oak_log
fill 366 141 559 366 144 559 minecraft:green_terracotta
setblock 366 141 598 minecraft:oak_log
fill 367 141 558 367 144 558 minecraft:green_terracotta
setblock 367 141 597 minecraft:oak_log
fill 367 141 598 367 144 598 minecraft:green_terracotta
setblock 368 141 561 minecraft:oak_log
fill 368 141 562 368 142 563 minecraft:green_terracotta
setblock 368 141 581 minecraft:oak_log
fill 368 141 582 368 144 582 minecraft:green_terracotta
setblock 368 141 586 minecraft:oak_log
fill 368 141 587 368 144 587 minecraft:green_terracotta
fill 368 141 589 368 141 590 minecraft:green_terracotta
fill 368 141 597 368 144 597 minecraft:green_terracotta
setblock 369 141 560 minecraft:oak_log
fill 369 141 561 369 144 561 minecraft:green_terracotta
setblock 369 141 565 minecraft:oak_log
setblock 369 141 580 minecraft:oak_log
fill 369 141 581 369 144 581 minecraft:green_terracotta
setblock 369 141 585 minecraft:oak_log
fill 369 141 586 369 144 586 minecraft:green_terracotta
setblock 369 141 590 minecraft:oak_log
fill 369 141 591 369 144 591 minecraft:green_terracotta
setblock 369 141 595 minecraft:oak_log
fill 369 141 596 369 143 596 minecraft:green_terracotta
setblock 370 141 559 minecraft:oak_log
fill 370 141 560 370 144 560 minecraft:green_terracotta
setblock 370 141 564 minecraft:oak_log
fill 370 141 565 370 144 565 minecraft:green_terracotta
setblock 370 141 567 minecraft:oak_leaves[persistent=true]
setblock 370 141 579 minecraft:oak_log
fill 370 141 580 370 144 580 minecraft:green_terracotta
setblock 370 141 584 minecraft:oak_log
fill 370 141 585 370 144 585 minecraft:green_terracotta
schedule function dropper:buildpart/139_4 1t
