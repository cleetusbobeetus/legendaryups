fill 254 283 316 256 300 316 minecraft:cut_sandstone
setblock 255 283 296 minecraft:sandstone
fill 255 283 298 257 283 298 minecraft:sandstone
fill 255 283 315 257 285 315 minecraft:cut_sandstone
fill 256 283 293 258 283 293 minecraft:sandstone
setblock 256 283 295 minecraft:sandstone
setblock 256 283 297 minecraft:sandstone
setblock 257 283 294 minecraft:sandstone
fill 257 283 296 269 283 296 minecraft:sandstone
fill 258 283 295 269 283 295 minecraft:sandstone
fill 258 283 297 269 283 297 minecraft:sandstone
fill 259 283 277 261 285 277 minecraft:cut_sandstone
fill 259 283 294 269 283 294 minecraft:sandstone
fill 259 283 298 269 283 298 minecraft:sandstone
fill 260 283 276 262 300 276 minecraft:cut_sandstone
fill 260 283 293 269 283 293 minecraft:sandstone
fill 260 283 299 269 283 299 minecraft:sandstone
fill 261 283 292 269 283 292 minecraft:sandstone
fill 261 283 300 269 283 300 minecraft:sandstone
fill 262 283 291 269 283 291 minecraft:sandstone
fill 262 283 301 269 283 301 minecraft:sandstone
fill 263 283 290 269 283 290 minecraft:sandstone
fill 263 283 302 269 283 302 minecraft:sandstone
fill 264 283 289 269 283 289 minecraft:sandstone
fill 264 283 303 269 283 303 minecraft:sandstone
fill 265 283 288 269 283 288 minecraft:sandstone
fill 265 283 304 269 283 304 minecraft:sandstone
fill 266 283 287 269 283 287 minecraft:sandstone
fill 266 283 305 269 283 305 minecraft:sandstone
fill 266 283 310 276 284 316 minecraft:cut_sandstone
fill 267 283 286 269 283 286 minecraft:sandstone
fill 267 283 306 269 283 306 minecraft:sandstone
fill 268 283 285 269 283 285 minecraft:sandstone
fill 268 283 307 269 283 307 minecraft:sandstone
setblock 269 283 284 minecraft:sandstone
setblock 269 283 308 minecraft:sandstone
fill 270 283 290 276 284 300 minecraft:cut_sandstone
fill 270 283 304 276 284 309 minecraft:cut_sandstone
fill 271 283 277 273 285 277 minecraft:cut_sandstone
fill 272 283 276 274 300 276 minecraft:cut_sandstone
fill 275 283 285 275 285 287 minecraft:cut_sandstone
fill 276 283 284 276 300 286 minecraft:cut_sandstone
fill 277 283 312 277 285 312 minecraft:smooth_sandstone
setblock 277 283 313 minecraft:lapis_block
fill 277 283 314 277 285 315 minecraft:smooth_sandstone
setblock 235 284 305 minecraft:orange_terracotta
fill 241 284 317 241 299 317 minecraft:smooth_sandstone
fill 243 284 283 244 285 283 minecraft:cut_sandstone
fill 244 284 285 244 284 307 minecraft:smooth_sandstone
fill 245 284 284 267 284 284 minecraft:smooth_sandstone
fill 245 284 286 245 284 306 minecraft:smooth_sandstone
fill 245 284 308 267 284 308 minecraft:smooth_sandstone
fill 246 284 285 266 284 285 minecraft:smooth_sandstone
fill 246 284 287 246 284 305 minecraft:smooth_sandstone
fill 246 284 307 266 284 307 minecraft:smooth_sandstone
setblock 246 284 317 minecraft:orange_terracotta
fill 247 284 286 265 284 286 minecraft:smooth_sandstone
fill 247 284 288 247 284 304 minecraft:smooth_sandstone
fill 247 284 306 265 284 306 minecraft:smooth_sandstone
fill 248 284 287 264 284 287 minecraft:smooth_sandstone
fill 248 284 289 248 284 303 minecraft:smooth_sandstone
fill 248 284 305 264 284 305 minecraft:smooth_sandstone
fill 249 284 288 263 284 288 minecraft:smooth_sandstone
fill 249 284 290 249 284 302 minecraft:smooth_sandstone
fill 249 284 304 263 284 304 minecraft:smooth_sandstone
fill 250 284 289 262 284 289 minecraft:smooth_sandstone
fill 250 284 291 250 284 301 minecraft:smooth_sandstone
fill 250 284 303 262 284 303 minecraft:smooth_sandstone
fill 251 284 290 261 284 290 minecraft:smooth_sandstone
fill 251 284 292 251 284 300 minecraft:smooth_sandstone
fill 251 284 302 261 284 302 minecraft:smooth_sandstone
fill 252 284 291 260 284 291 minecraft:smooth_sandstone
fill 252 284 293 252 284 299 minecraft:smooth_sandstone
fill 252 284 301 260 284 301 minecraft:smooth_sandstone
setblock 252 284 317 minecraft:lapis_block
fill 253 284 292 259 284 292 minecraft:smooth_sandstone
fill 253 284 294 253 284 298 minecraft:smooth_sandstone
fill 253 284 300 259 284 300 minecraft:smooth_sandstone
setblock 254 284 275 minecraft:lapis_block
setblock 254 284 293 minecraft:smooth_sandstone
fill 254 284 295 254 284 297 minecraft:smooth_sandstone
fill 254 284 299 258 284 299 minecraft:smooth_sandstone
setblock 254 284 317 minecraft:lapis_block
fill 255 284 275 257 285 275 minecraft:smooth_sandstone
setblock 255 284 296 minecraft:smooth_sandstone
fill 255 284 298 257 284 298 minecraft:smooth_sandstone
fill 256 284 293 258 284 293 minecraft:smooth_sandstone
setblock 256 284 295 minecraft:smooth_sandstone
setblock 256 284 297 minecraft:smooth_sandstone
setblock 257 284 294 minecraft:smooth_sandstone
fill 257 284 296 268 284 296 minecraft:smooth_sandstone
fill 258 284 295 268 284 295 minecraft:smooth_sandstone
fill 258 284 297 268 284 297 minecraft:smooth_sandstone
fill 259 284 294 268 284 294 minecraft:smooth_sandstone
fill 259 284 298 268 284 298 minecraft:smooth_sandstone
fill 260 284 293 268 284 293 minecraft:smooth_sandstone
fill 260 284 299 268 284 299 minecraft:smooth_sandstone
fill 261 284 292 268 284 292 minecraft:smooth_sandstone
fill 261 284 300 268 284 300 minecraft:smooth_sandstone
fill 262 284 291 268 284 291 minecraft:smooth_sandstone
fill 262 284 301 268 284 301 minecraft:smooth_sandstone
setblock 263 284 275 minecraft:orange_terracotta
fill 263 284 290 268 284 290 minecraft:smooth_sandstone
fill 263 284 302 268 284 302 minecraft:smooth_sandstone
fill 264 284 289 268 284 289 minecraft:smooth_sandstone
fill 264 284 303 268 284 303 minecraft:smooth_sandstone
fill 265 284 288 268 284 288 minecraft:smooth_sandstone
fill 265 284 304 268 284 304 minecraft:smooth_sandstone
fill 266 284 287 268 284 287 minecraft:smooth_sandstone
fill 266 284 305 268 284 305 minecraft:smooth_sandstone
fill 266 284 309 269 285 309 minecraft:cut_sandstone
fill 267 284 286 268 284 286 minecraft:smooth_sandstone
fill 267 284 306 268 284 306 minecraft:smooth_sandstone
setblock 268 284 285 minecraft:smooth_sandstone
setblock 268 284 307 minecraft:smooth_sandstone
fill 269 284 304 269 285 308 minecraft:cut_sandstone
fill 277 284 313 277 285 313 minecraft:smooth_sandstone
setblock 235 285 305 minecraft:smooth_sandstone
fill 236 285 276 239 285 278 minecraft:cut_sandstone
fill 236 285 279 236 285 284 minecraft:chiseled_sandstone
fill 236 285 291 236 285 296 minecraft:chiseled_sandstone
fill 236 285 303 236 285 308 minecraft:chiseled_sandstone
fill 236 285 315 236 285 316 minecraft:chiseled_sandstone
fill 237 285 279 242 285 283 minecraft:cut_sandstone
fill 237 285 316 240 285 316 minecraft:chiseled_sandstone
setblock 238 285 285 minecraft:light[level=12]
setblock 238 285 292 minecraft:light[level=12]
setblock 238 285 299 minecraft:light[level=12]
setblock 238 285 306 minecraft:light[level=12]
setblock 238 285 313 minecraft:light[level=12]
fill 240 285 276 245 285 276 minecraft:chiseled_sandstone
fill 240 285 277 244 285 278 minecraft:cut_sandstone
fill 243 285 279 244 285 282 minecraft:cut_sandstone
setblock 245 285 278 minecraft:light[level=12]
fill 245 285 286 245 285 306 minecraft:sandstone
setblock 245 285 313 minecraft:light[level=12]
fill 246 285 285 266 285 285 minecraft:sandstone
fill 246 285 287 246 285 305 minecraft:sandstone
fill 246 285 307 266 285 307 minecraft:sandstone
fill 246 285 317 246 308 317 minecraft:smooth_sandstone
fill 247 285 286 265 285 286 minecraft:sandstone
fill 247 285 288 247 285 304 minecraft:sandstone
fill 247 285 306 265 285 306 minecraft:sandstone
fill 247 285 316 252 285 316 minecraft:chiseled_sandstone
fill 248 285 287 264 285 287 minecraft:sandstone
fill 248 285 289 248 285 303 minecraft:sandstone
fill 248 285 305 264 285 305 minecraft:sandstone
fill 249 285 288 263 285 288 minecraft:sandstone
fill 249 285 290 249 285 302 minecraft:sandstone
fill 249 285 304 263 285 304 minecraft:sandstone
fill 250 285 289 262 285 289 minecraft:sandstone
fill 250 285 291 250 285 301 minecraft:sandstone
fill 250 285 303 262 285 303 minecraft:sandstone
fill 251 285 290 261 285 290 minecraft:sandstone
fill 251 285 292 251 285 300 minecraft:sandstone
fill 251 285 302 261 285 302 minecraft:sandstone
fill 252 285 276 257 285 276 minecraft:chiseled_sandstone
setblock 252 285 278 minecraft:light[level=12]
fill 252 285 291 260 285 291 minecraft:sandstone
fill 252 285 293 252 285 299 minecraft:sandstone
fill 252 285 301 260 285 301 minecraft:sandstone
setblock 252 285 313 minecraft:light[level=12]
fill 252 285 317 252 308 317 minecraft:smooth_sandstone
fill 253 285 292 259 285 292 minecraft:sandstone
fill 253 285 294 253 285 298 minecraft:sandstone
fill 253 285 300 259 285 300 minecraft:sandstone
setblock 254 285 275 minecraft:smooth_sandstone
setblock 254 285 293 minecraft:sandstone
fill 254 285 295 254 285 297 minecraft:sandstone
fill 254 285 299 258 285 299 minecraft:sandstone
fill 254 285 317 254 308 317 minecraft:smooth_sandstone
setblock 255 285 296 minecraft:sandstone
fill 255 285 298 257 285 298 minecraft:sandstone
fill 256 285 293 258 285 293 minecraft:sandstone
setblock 256 285 295 minecraft:sandstone
setblock 256 285 297 minecraft:sandstone
setblock 257 285 294 minecraft:sandstone
fill 257 285 296 267 285 296 minecraft:sandstone
fill 258 285 295 267 285 295 minecraft:sandstone
fill 258 285 297 267 285 297 minecraft:sandstone
setblock 259 285 278 minecraft:light[level=12]
fill 259 285 294 267 285 294 minecraft:sandstone
fill 259 285 298 267 285 298 minecraft:sandstone
setblock 259 285 313 minecraft:light[level=12]
fill 259 285 316 264 285 316 minecraft:chiseled_sandstone
fill 260 285 293 267 285 293 minecraft:sandstone
fill 260 285 299 267 285 299 minecraft:sandstone
fill 261 285 292 267 285 292 minecraft:sandstone
fill 261 285 300 267 285 300 minecraft:sandstone
fill 262 285 291 267 285 291 minecraft:sandstone
fill 262 285 301 267 285 301 minecraft:sandstone
fill 263 285 275 263 294 275 minecraft:smooth_sandstone
fill 263 285 290 267 285 290 minecraft:sandstone
fill 263 285 302 267 285 302 minecraft:sandstone
fill 264 285 276 269 285 276 minecraft:chiseled_sandstone
fill 264 285 289 267 285 289 minecraft:sandstone
fill 264 285 303 267 285 303 minecraft:sandstone
fill 265 285 288 267 285 288 minecraft:sandstone
fill 265 285 304 267 285 304 minecraft:sandstone
setblock 266 285 278 minecraft:light[level=12]
fill 266 285 287 267 285 287 minecraft:sandstone
fill 266 285 305 267 285 305 minecraft:sandstone
fill 266 285 308 268 285 308 minecraft:cut_sandstone
fill 266 285 310 270 285 316 minecraft:cut_sandstone
setblock 267 285 286 minecraft:sandstone
setblock 267 285 306 minecraft:sandstone
fill 268 285 304 268 285 307 minecraft:cut_sandstone
fill 270 285 290 275 285 300 minecraft:cut_sandstone
fill 270 285 304 275 285 309 minecraft:cut_sandstone
setblock 270 285 317 minecraft:blue_terracotta
fill 271 285 310 275 285 315 minecraft:cut_sandstone
fill 271 285 316 276 285 316 minecraft:chiseled_sandstone
setblock 273 285 278 minecraft:light[level=12]
setblock 273 285 285 minecraft:light[level=12]
fill 276 285 276 276 285 281 minecraft:chiseled_sandstone
fill 276 285 288 276 285 293 minecraft:chiseled_sandstone
fill 276 285 294 276 285 299 minecraft:cut_sandstone
fill 276 285 300 276 285 305 minecraft:chiseled_sandstone
fill 276 285 306 276 285 311 minecraft:cut_sandstone
fill 276 285 312 276 285 315 minecraft:chiseled_sandstone
setblock 235 286 280 minecraft:orange_terracotta
fill 235 286 281 235 291 284 minecraft:glowstone
fill 235 286 293 235 291 296 minecraft:glowstone
fill 235 286 305 235 291 308 minecraft:glowstone
fill 235 286 317 238 291 317 minecraft:glowstone
setblock 236 286 276 minecraft:glowstone
fill 236 286 277 236 300 277 minecraft:cut_sandstone
setblock 236 286 278 minecraft:glowstone
fill 236 286 279 236 300 279 minecraft:cut_sandstone
setblock 236 286 280 minecraft:glowstone
fill 236 286 281 236 300 281 minecraft:cut_sandstone
setblock 236 286 282 minecraft:glowstone
fill 236 286 283 236 300 283 minecraft:cut_sandstone
setblock 237 286 275 minecraft:glowstone
fill 237 286 276 237 300 276 minecraft:cut_sandstone
setblock 237 286 277 minecraft:glowstone
fill 237 286 278 237 300 278 minecraft:cut_sandstone
setblock 237 286 279 minecraft:glowstone
fill 237 286 280 237 300 280 minecraft:cut_sandstone
setblock 237 286 281 minecraft:glowstone
fill 237 286 282 237 300 282 minecraft:cut_sandstone
setblock 237 286 283 minecraft:glowstone
fill 238 286 275 238 299 275 minecraft:smooth_sandstone
setblock 238 286 276 minecraft:glowstone
fill 238 286 277 238 300 277 minecraft:cut_sandstone
setblock 238 286 278 minecraft:glowstone
fill 238 286 279 238 300 279 minecraft:cut_sandstone
setblock 238 286 280 minecraft:glowstone
fill 238 286 281 238 300 281 minecraft:cut_sandstone
setblock 238 286 282 minecraft:glowstone
fill 238 286 283 238 300 283 minecraft:cut_sandstone
setblock 239 286 275 minecraft:glowstone
fill 239 286 276 239 300 276 minecraft:cut_sandstone
setblock 239 286 277 minecraft:glowstone
fill 239 286 278 239 300 278 minecraft:cut_sandstone
setblock 239 286 279 minecraft:glowstone
fill 239 286 280 239 300 280 minecraft:cut_sandstone
setblock 239 286 281 minecraft:glowstone
fill 239 286 282 239 300 282 minecraft:cut_sandstone
setblock 239 286 283 minecraft:glowstone
setblock 240 286 276 minecraft:glowstone
fill 240 286 277 240 300 277 minecraft:cut_sandstone
setblock 240 286 278 minecraft:glowstone
fill 240 286 279 240 300 279 minecraft:cut_sandstone
setblock 240 286 280 minecraft:glowstone
fill 240 286 281 240 300 281 minecraft:cut_sandstone
setblock 240 286 282 minecraft:glowstone
fill 240 286 283 240 300 283 minecraft:cut_sandstone
fill 241 286 275 245 286 275 minecraft:glowstone
fill 241 286 276 241 300 276 minecraft:cut_sandstone
setblock 241 286 277 minecraft:glowstone
fill 241 286 278 241 300 278 minecraft:cut_sandstone
setblock 241 286 279 minecraft:glowstone
fill 241 286 280 241 300 280 minecraft:cut_sandstone
setblock 241 286 281 minecraft:glowstone
fill 241 286 282 241 300 282 minecraft:cut_sandstone
setblock 241 286 283 minecraft:glowstone
setblock 242 286 276 minecraft:glowstone
fill 242 286 277 242 300 277 minecraft:cut_sandstone
setblock 242 286 278 minecraft:glowstone
fill 242 286 279 242 300 279 minecraft:cut_sandstone
setblock 242 286 280 minecraft:glowstone
fill 242 286 281 242 300 281 minecraft:cut_sandstone
setblock 242 286 282 minecraft:glowstone
fill 242 286 283 242 300 283 minecraft:cut_sandstone
fill 243 286 276 243 300 276 minecraft:cut_sandstone
setblock 243 286 277 minecraft:glowstone
fill 243 286 278 243 300 278 minecraft:cut_sandstone
setblock 243 286 279 minecraft:glowstone
fill 243 286 280 243 300 280 minecraft:cut_sandstone
setblock 243 286 281 minecraft:glowstone
fill 243 286 282 243 300 282 minecraft:cut_sandstone
setblock 243 286 283 minecraft:glowstone
setblock 244 286 276 minecraft:glowstone
fill 244 286 277 244 300 277 minecraft:cut_sandstone
setblock 244 286 278 minecraft:glowstone
fill 244 286 279 244 300 279 minecraft:cut_sandstone
setblock 244 286 280 minecraft:glowstone
fill 244 286 281 244 300 281 minecraft:cut_sandstone
setblock 244 286 282 minecraft:glowstone
fill 244 286 283 244 300 283 minecraft:cut_sandstone
setblock 246 286 275 minecraft:lapis_block
fill 247 286 288 247 286 304 minecraft:smooth_sandstone
fill 247 286 317 250 291 317 minecraft:glowstone
fill 248 286 287 264 286 287 minecraft:smooth_sandstone
fill 248 286 289 248 286 303 minecraft:smooth_sandstone
fill 248 286 305 264 286 305 minecraft:smooth_sandstone
fill 249 286 288 263 286 288 minecraft:smooth_sandstone
fill 249 286 290 249 286 302 minecraft:smooth_sandstone
fill 249 286 304 263 286 304 minecraft:smooth_sandstone
fill 250 286 289 262 286 289 minecraft:smooth_sandstone
fill 250 286 291 250 286 301 minecraft:smooth_sandstone
fill 250 286 303 262 286 303 minecraft:smooth_sandstone
fill 251 286 290 261 286 290 minecraft:smooth_sandstone
fill 251 286 292 251 286 300 minecraft:smooth_sandstone
fill 251 286 302 261 286 302 minecraft:smooth_sandstone
fill 252 286 291 260 286 291 minecraft:smooth_sandstone
fill 252 286 293 252 286 299 minecraft:smooth_sandstone
fill 252 286 301 260 286 301 minecraft:smooth_sandstone
fill 253 286 292 259 286 292 minecraft:smooth_sandstone
fill 253 286 294 253 286 298 minecraft:smooth_sandstone
fill 253 286 300 259 286 300 minecraft:smooth_sandstone
fill 254 286 275 257 291 275 minecraft:glowstone
setblock 254 286 293 minecraft:smooth_sandstone
fill 254 286 295 254 286 297 minecraft:smooth_sandstone
fill 254 286 299 258 286 299 minecraft:smooth_sandstone
setblock 255 286 296 minecraft:smooth_sandstone
fill 255 286 298 257 286 298 minecraft:smooth_sandstone
fill 256 286 293 258 286 293 minecraft:smooth_sandstone
setblock 256 286 295 minecraft:smooth_sandstone
setblock 256 286 297 minecraft:smooth_sandstone
fill 257 286 278 261 287 282 minecraft:chiseled_sandstone
setblock 257 286 294 minecraft:smooth_sandstone
fill 257 286 296 265 286 296 minecraft:smooth_sandstone
fill 258 286 295 265 286 295 minecraft:smooth_sandstone
fill 258 286 297 265 286 297 minecraft:smooth_sandstone
fill 259 286 276 259 286 277 minecraft:chiseled_sandstone
fill 259 286 294 265 286 294 minecraft:smooth_sandstone
fill 259 286 298 265 286 298 minecraft:smooth_sandstone
fill 259 286 317 262 291 317 minecraft:glowstone
fill 260 286 293 265 286 293 minecraft:smooth_sandstone
fill 260 286 299 265 286 299 minecraft:smooth_sandstone
fill 261 286 292 265 286 292 minecraft:smooth_sandstone
fill 261 286 300 265 286 300 minecraft:smooth_sandstone
fill 262 286 291 265 286 291 minecraft:smooth_sandstone
fill 262 286 301 265 286 301 minecraft:smooth_sandstone
fill 263 286 290 265 286 290 minecraft:smooth_sandstone
fill 263 286 302 265 286 302 minecraft:smooth_sandstone
fill 264 286 289 265 286 289 minecraft:smooth_sandstone
fill 264 286 303 265 286 303 minecraft:smooth_sandstone
setblock 265 286 288 minecraft:smooth_sandstone
setblock 265 286 304 minecraft:smooth_sandstone
fill 266 286 275 269 291 275 minecraft:glowstone
setblock 266 286 304 minecraft:glowstone
fill 266 286 305 266 293 305 minecraft:cut_sandstone
setblock 266 286 306 minecraft:glowstone
fill 266 286 307 266 293 307 minecraft:cut_sandstone
setblock 266 286 308 minecraft:glowstone
fill 266 286 309 266 293 309 minecraft:cut_sandstone
setblock 266 286 310 minecraft:glowstone
fill 266 286 311 266 293 311 minecraft:cut_sandstone
setblock 266 286 312 minecraft:glowstone
fill 266 286 313 266 293 313 minecraft:cut_sandstone
setblock 266 286 314 minecraft:glowstone
fill 266 286 315 266 293 315 minecraft:cut_sandstone
setblock 266 286 316 minecraft:glowstone
fill 267 286 304 267 293 304 minecraft:cut_sandstone
setblock 267 286 305 minecraft:glowstone
fill 267 286 306 267 293 306 minecraft:cut_sandstone
setblock 267 286 307 minecraft:glowstone
fill 267 286 308 267 293 308 minecraft:cut_sandstone
setblock 267 286 309 minecraft:glowstone
fill 267 286 310 267 293 310 minecraft:cut_sandstone
setblock 267 286 311 minecraft:glowstone
fill 267 286 312 267 293 312 minecraft:cut_sandstone
setblock 267 286 313 minecraft:glowstone
fill 267 286 314 267 293 314 minecraft:cut_sandstone
setblock 267 286 315 minecraft:glowstone
fill 267 286 316 267 300 316 minecraft:cut_sandstone
setblock 268 286 304 minecraft:glowstone
fill 268 286 305 268 293 305 minecraft:cut_sandstone
setblock 268 286 306 minecraft:glowstone
fill 268 286 307 268 293 307 minecraft:cut_sandstone
setblock 268 286 308 minecraft:glowstone
fill 268 286 309 268 293 309 minecraft:cut_sandstone
setblock 268 286 310 minecraft:glowstone
fill 268 286 311 268 293 311 minecraft:cut_sandstone
setblock 268 286 312 minecraft:glowstone
fill 268 286 313 268 293 313 minecraft:cut_sandstone
setblock 268 286 314 minecraft:glowstone
fill 268 286 315 268 293 315 minecraft:cut_sandstone
setblock 268 286 316 minecraft:glowstone
fill 269 286 304 269 293 304 minecraft:cut_sandstone
setblock 269 286 305 minecraft:glowstone
fill 269 286 306 269 293 306 minecraft:cut_sandstone
setblock 269 286 307 minecraft:glowstone
fill 269 286 308 269 293 308 minecraft:cut_sandstone
setblock 269 286 309 minecraft:glowstone
fill 269 286 310 269 293 310 minecraft:cut_sandstone
setblock 269 286 311 minecraft:glowstone
fill 269 286 312 269 293 312 minecraft:cut_sandstone
setblock 269 286 313 minecraft:glowstone
fill 269 286 314 269 293 314 minecraft:cut_sandstone
setblock 269 286 315 minecraft:glowstone
fill 269 286 316 269 293 316 minecraft:cut_sandstone
setblock 270 286 290 minecraft:glowstone
fill 270 286 291 270 299 291 minecraft:cut_sandstone
setblock 270 286 292 minecraft:glowstone
fill 270 286 293 270 299 293 minecraft:cut_sandstone
setblock 270 286 294 minecraft:glowstone
fill 270 286 295 270 299 295 minecraft:cut_sandstone
setblock 270 286 296 minecraft:glowstone
fill 270 286 297 270 299 297 minecraft:cut_sandstone
setblock 270 286 298 minecraft:glowstone
fill 270 286 299 270 299 299 minecraft:cut_sandstone
setblock 270 286 300 minecraft:glowstone
setblock 270 286 304 minecraft:glowstone
fill 270 286 305 270 293 305 minecraft:cut_sandstone
setblock 270 286 306 minecraft:glowstone
fill 270 286 307 270 293 307 minecraft:cut_sandstone
setblock 270 286 308 minecraft:glowstone
fill 270 286 309 270 293 309 minecraft:cut_sandstone
setblock 270 286 310 minecraft:glowstone
fill 270 286 311 270 293 311 minecraft:cut_sandstone
setblock 270 286 312 minecraft:glowstone
fill 270 286 313 270 293 313 minecraft:cut_sandstone
setblock 270 286 314 minecraft:glowstone
fill 270 286 315 270 293 315 minecraft:cut_sandstone
setblock 270 286 316 minecraft:glowstone
fill 270 286 317 270 308 317 minecraft:smooth_sandstone
fill 271 286 290 271 299 290 minecraft:cut_sandstone
setblock 271 286 291 minecraft:glowstone
fill 271 286 292 271 299 292 minecraft:cut_sandstone
setblock 271 286 293 minecraft:glowstone
fill 271 286 294 271 299 294 minecraft:cut_sandstone
setblock 271 286 295 minecraft:glowstone
fill 271 286 296 271 299 296 minecraft:cut_sandstone
setblock 271 286 297 minecraft:glowstone
fill 271 286 298 271 299 298 minecraft:cut_sandstone
setblock 271 286 299 minecraft:glowstone
fill 271 286 300 271 299 300 minecraft:cut_sandstone
fill 271 286 304 271 293 304 minecraft:cut_sandstone
setblock 271 286 305 minecraft:glowstone
fill 271 286 306 271 293 306 minecraft:cut_sandstone
setblock 271 286 307 minecraft:glowstone
fill 271 286 308 271 293 308 minecraft:cut_sandstone
setblock 271 286 309 minecraft:glowstone
fill 271 286 310 271 293 310 minecraft:cut_sandstone
setblock 271 286 311 minecraft:glowstone
fill 271 286 312 271 293 312 minecraft:cut_sandstone
setblock 271 286 313 minecraft:glowstone
fill 271 286 314 271 293 314 minecraft:cut_sandstone
setblock 271 286 315 minecraft:glowstone
fill 271 286 316 271 293 316 minecraft:cut_sandstone
fill 271 286 317 274 291 317 minecraft:glowstone
setblock 272 286 290 minecraft:glowstone
fill 272 286 291 272 299 291 minecraft:cut_sandstone
setblock 272 286 292 minecraft:glowstone
fill 272 286 293 272 299 293 minecraft:cut_sandstone
setblock 272 286 294 minecraft:glowstone
fill 272 286 295 272 299 295 minecraft:cut_sandstone
setblock 272 286 296 minecraft:glowstone
fill 272 286 297 272 299 297 minecraft:cut_sandstone
setblock 272 286 298 minecraft:glowstone
fill 272 286 299 272 299 299 minecraft:cut_sandstone
setblock 272 286 300 minecraft:glowstone
setblock 272 286 304 minecraft:glowstone
fill 272 286 305 272 293 305 minecraft:cut_sandstone
setblock 272 286 306 minecraft:glowstone
fill 272 286 307 272 293 307 minecraft:cut_sandstone
setblock 272 286 308 minecraft:glowstone
fill 272 286 309 272 293 309 minecraft:cut_sandstone
setblock 272 286 310 minecraft:glowstone
fill 272 286 311 272 293 311 minecraft:cut_sandstone
setblock 272 286 312 minecraft:glowstone
fill 272 286 313 272 293 313 minecraft:cut_sandstone
setblock 272 286 314 minecraft:glowstone
fill 272 286 315 272 293 315 minecraft:cut_sandstone
setblock 272 286 316 minecraft:glowstone
fill 273 286 290 273 299 290 minecraft:cut_sandstone
setblock 273 286 291 minecraft:glowstone
fill 273 286 292 273 299 292 minecraft:cut_sandstone
setblock 273 286 293 minecraft:glowstone
fill 273 286 294 273 299 294 minecraft:cut_sandstone
setblock 273 286 295 minecraft:glowstone
fill 273 286 296 273 299 296 minecraft:cut_sandstone
setblock 273 286 297 minecraft:glowstone
fill 273 286 298 273 299 298 minecraft:cut_sandstone
setblock 273 286 299 minecraft:glowstone
fill 273 286 300 273 299 300 minecraft:cut_sandstone
fill 273 286 304 273 293 304 minecraft:cut_sandstone
setblock 273 286 305 minecraft:glowstone
fill 273 286 306 273 293 306 minecraft:cut_sandstone
setblock 273 286 307 minecraft:glowstone
fill 273 286 308 273 293 308 minecraft:cut_sandstone
setblock 273 286 309 minecraft:glowstone
fill 273 286 310 273 293 310 minecraft:cut_sandstone
setblock 273 286 311 minecraft:glowstone
fill 273 286 312 273 293 312 minecraft:cut_sandstone
setblock 273 286 313 minecraft:glowstone
fill 273 286 314 273 293 314 minecraft:cut_sandstone
setblock 273 286 315 minecraft:glowstone
fill 273 286 316 273 293 316 minecraft:cut_sandstone
setblock 274 286 290 minecraft:glowstone
fill 274 286 291 274 299 291 minecraft:cut_sandstone
setblock 274 286 292 minecraft:glowstone
fill 274 286 293 274 299 293 minecraft:cut_sandstone
setblock 274 286 294 minecraft:glowstone
fill 274 286 295 274 299 295 minecraft:cut_sandstone
setblock 274 286 296 minecraft:glowstone
fill 274 286 297 274 299 297 minecraft:cut_sandstone
setblock 274 286 298 minecraft:glowstone
fill 274 286 299 274 299 299 minecraft:cut_sandstone
setblock 274 286 300 minecraft:glowstone
setblock 274 286 304 minecraft:glowstone
fill 274 286 305 274 293 305 minecraft:cut_sandstone
setblock 274 286 306 minecraft:glowstone
fill 274 286 307 274 293 307 minecraft:cut_sandstone
setblock 274 286 308 minecraft:glowstone
fill 274 286 309 274 293 309 minecraft:cut_sandstone
setblock 274 286 310 minecraft:glowstone
fill 274 286 311 274 293 311 minecraft:cut_sandstone
setblock 274 286 312 minecraft:glowstone
fill 274 286 313 274 293 313 minecraft:cut_sandstone
setblock 274 286 314 minecraft:glowstone
fill 274 286 315 274 293 315 minecraft:cut_sandstone
setblock 274 286 316 minecraft:glowstone
fill 275 286 290 275 299 290 minecraft:cut_sandstone
setblock 275 286 291 minecraft:glowstone
fill 275 286 292 275 299 292 minecraft:cut_sandstone
setblock 275 286 293 minecraft:glowstone
fill 275 286 294 275 299 294 minecraft:cut_sandstone
setblock 275 286 295 minecraft:glowstone
fill 275 286 296 275 299 296 minecraft:cut_sandstone
setblock 275 286 297 minecraft:glowstone
fill 275 286 298 275 300 298 minecraft:cut_sandstone
setblock 275 286 299 minecraft:glowstone
fill 275 286 300 275 299 300 minecraft:cut_sandstone
fill 275 286 304 275 293 304 minecraft:cut_sandstone
setblock 275 286 305 minecraft:glowstone
fill 275 286 306 275 293 306 minecraft:cut_sandstone
setblock 275 286 307 minecraft:glowstone
fill 275 286 308 275 293 308 minecraft:cut_sandstone
setblock 275 286 309 minecraft:glowstone
fill 275 286 310 275 293 310 minecraft:cut_sandstone
setblock 275 286 311 minecraft:glowstone
fill 275 286 312 275 293 312 minecraft:cut_sandstone
setblock 275 286 313 minecraft:glowstone
fill 275 286 314 275 293 314 minecraft:cut_sandstone
setblock 275 286 315 minecraft:glowstone
fill 275 286 316 275 293 316 minecraft:cut_sandstone
fill 276 286 290 277 286 290 minecraft:glowstone
fill 276 286 291 276 299 291 minecraft:cut_sandstone
setblock 276 286 292 minecraft:glowstone
fill 276 286 293 276 299 293 minecraft:cut_sandstone
setblock 276 286 294 minecraft:glowstone
fill 276 286 295 276 299 295 minecraft:cut_sandstone
setblock 276 286 296 minecraft:glowstone
fill 276 286 297 276 300 297 minecraft:cut_sandstone
setblock 276 286 298 minecraft:glowstone
fill 276 286 299 276 299 299 minecraft:cut_sandstone
fill 276 286 300 277 286 300 minecraft:glowstone
setblock 276 286 304 minecraft:glowstone
fill 276 286 305 276 293 305 minecraft:cut_sandstone
setblock 276 286 306 minecraft:glowstone
fill 276 286 307 276 293 307 minecraft:cut_sandstone
setblock 276 286 308 minecraft:glowstone
fill 276 286 309 276 300 309 minecraft:cut_sandstone
setblock 276 286 310 minecraft:glowstone
fill 276 286 311 276 293 311 minecraft:cut_sandstone
fill 276 286 312 277 286 312 minecraft:glowstone
fill 276 286 313 276 293 313 minecraft:cut_sandstone
fill 276 286 314 277 286 314 minecraft:glowstone
fill 276 286 315 276 293 315 minecraft:cut_sandstone
setblock 276 286 316 minecraft:glowstone
fill 277 286 276 277 291 279 minecraft:glowstone
fill 277 286 288 277 291 289 minecraft:glowstone
fill 277 286 291 277 291 291 minecraft:glowstone
fill 277 286 301 277 291 303 minecraft:glowstone
fill 277 286 313 277 292 313 minecraft:glowstone
fill 277 286 315 277 291 315 minecraft:glowstone
fill 235 287 280 235 295 280 minecraft:smooth_sandstone
fill 236 287 276 236 288 276 minecraft:cut_sandstone
fill 236 287 278 236 288 278 minecraft:cut_sandstone
fill 236 287 280 236 288 280 minecraft:cut_sandstone
fill 236 287 282 236 288 282 minecraft:cut_sandstone
setblock 237 287 275 minecraft:orange_terracotta
fill 237 287 277 237 288 277 minecraft:cut_sandstone
fill 237 287 279 237 288 279 minecraft:cut_sandstone
fill 237 287 281 237 288 281 minecraft:cut_sandstone
fill 237 287 283 237 288 283 minecraft:cut_sandstone
fill 238 287 276 238 288 276 minecraft:cut_sandstone
fill 238 287 278 238 288 278 minecraft:cut_sandstone
fill 238 287 280 238 288 280 minecraft:cut_sandstone
fill 238 287 282 238 288 282 minecraft:cut_sandstone
setblock 238 287 286 minecraft:light[level=15]
setblock 238 287 294 minecraft:light[level=15]
setblock 238 287 302 minecraft:light[level=15]
setblock 238 287 310 minecraft:light[level=15]
fill 239 287 275 239 288 275 minecraft:smooth_sandstone
fill 239 287 277 239 288 277 minecraft:cut_sandstone
fill 239 287 279 239 288 279 minecraft:cut_sandstone
fill 239 287 281 239 288 281 minecraft:cut_sandstone
fill 239 287 283 239 288 283 minecraft:cut_sandstone
fill 240 287 276 240 288 276 minecraft:cut_sandstone
fill 240 287 278 240 288 278 minecraft:cut_sandstone
fill 240 287 280 240 288 280 minecraft:cut_sandstone
fill 240 287 282 240 288 282 minecraft:cut_sandstone
fill 241 287 275 241 288 275 minecraft:smooth_sandstone
fill 241 287 277 241 288 277 minecraft:cut_sandstone
fill 241 287 279 241 288 279 minecraft:cut_sandstone
fill 241 287 281 241 288 281 minecraft:cut_sandstone
fill 241 287 283 241 288 283 minecraft:cut_sandstone
fill 242 287 275 245 291 275 minecraft:glowstone
fill 242 287 276 242 288 276 minecraft:cut_sandstone
fill 242 287 278 242 288 278 minecraft:cut_sandstone
fill 242 287 280 242 288 280 minecraft:cut_sandstone
fill 242 287 282 242 288 282 minecraft:cut_sandstone
fill 243 287 277 243 288 277 minecraft:cut_sandstone
fill 243 287 279 243 288 279 minecraft:cut_sandstone
fill 243 287 281 243 288 281 minecraft:cut_sandstone
fill 243 287 283 243 288 283 minecraft:cut_sandstone
fill 244 287 276 244 288 276 minecraft:cut_sandstone
fill 244 287 278 244 288 278 minecraft:cut_sandstone
fill 244 287 280 244 288 280 minecraft:cut_sandstone
fill 244 287 282 244 288 282 minecraft:cut_sandstone
fill 246 287 275 246 308 275 minecraft:smooth_sandstone
setblock 246 287 278 minecraft:light[level=15]
setblock 246 287 286 minecraft:light[level=15]
setblock 246 287 294 minecraft:light[level=15]
setblock 246 287 302 minecraft:light[level=15]
setblock 246 287 310 minecraft:light[level=15]
fill 248 287 289 248 287 303 minecraft:sandstone
fill 249 287 288 263 287 288 minecraft:sandstone
fill 249 287 290 249 287 302 minecraft:sandstone
fill 249 287 304 263 287 304 minecraft:sandstone
fill 250 287 289 262 287 289 minecraft:sandstone
fill 250 287 291 250 287 301 minecraft:sandstone
fill 250 287 303 262 287 303 minecraft:sandstone
fill 251 287 290 261 287 290 minecraft:sandstone
fill 251 287 292 251 287 300 minecraft:sandstone
fill 251 287 302 261 287 302 minecraft:sandstone
fill 252 287 291 260 287 291 minecraft:sandstone
fill 252 287 293 252 287 299 minecraft:sandstone
fill 252 287 301 260 287 301 minecraft:sandstone
fill 253 287 292 259 287 292 minecraft:sandstone
fill 253 287 294 253 287 298 minecraft:sandstone
fill 253 287 300 259 287 300 minecraft:sandstone
setblock 254 287 278 minecraft:light[level=15]
setblock 254 287 286 minecraft:light[level=15]
setblock 254 287 293 minecraft:sandstone
fill 254 287 295 254 287 297 minecraft:sandstone
fill 254 287 299 258 287 299 minecraft:sandstone
setblock 254 287 310 minecraft:light[level=15]
setblock 255 287 296 minecraft:sandstone
fill 255 287 298 257 287 298 minecraft:sandstone
fill 256 287 293 258 287 293 minecraft:sandstone
setblock 256 287 297 minecraft:sandstone
setblock 257 287 294 minecraft:sandstone
fill 257 287 296 264 287 296 minecraft:sandstone
fill 258 287 295 264 287 295 minecraft:sandstone
fill 258 287 297 264 287 297 minecraft:sandstone
fill 259 287 294 264 287 294 minecraft:sandstone
fill 259 287 298 264 287 298 minecraft:sandstone
fill 260 287 293 264 287 293 minecraft:sandstone
fill 260 287 299 264 287 299 minecraft:sandstone
fill 261 287 292 264 287 292 minecraft:sandstone
fill 261 287 300 264 287 300 minecraft:sandstone
setblock 262 287 278 minecraft:light[level=15]
setblock 262 287 286 minecraft:light[level=15]
fill 262 287 291 264 287 291 minecraft:sandstone
fill 262 287 301 264 287 301 minecraft:sandstone
setblock 262 287 310 minecraft:light[level=15]
fill 263 287 290 264 287 290 minecraft:sandstone
fill 263 287 302 264 287 302 minecraft:sandstone
fill 264 287 275 264 308 275 minecraft:smooth_sandstone
setblock 264 287 289 minecraft:sandstone
setblock 264 287 303 minecraft:sandstone
setblock 265 287 275 minecraft:black_terracotta
fill 266 287 304 266 288 304 minecraft:cut_sandstone
fill 266 287 306 266 288 306 minecraft:cut_sandstone
fill 266 287 308 266 288 308 minecraft:cut_sandstone
fill 266 287 310 266 288 310 minecraft:cut_sandstone
fill 266 287 312 266 288 312 minecraft:cut_sandstone
fill 266 287 314 266 288 314 minecraft:cut_sandstone
fill 266 287 316 266 288 316 minecraft:cut_sandstone
fill 267 287 305 267 288 305 minecraft:cut_sandstone
fill 267 287 307 267 288 307 minecraft:cut_sandstone
fill 267 287 309 267 288 309 minecraft:cut_sandstone
fill 267 287 311 267 288 311 minecraft:cut_sandstone
fill 267 287 313 267 288 313 minecraft:cut_sandstone
fill 267 287 315 267 288 315 minecraft:cut_sandstone
fill 268 287 304 268 288 304 minecraft:cut_sandstone
fill 268 287 306 268 288 306 minecraft:cut_sandstone
fill 268 287 308 268 288 308 minecraft:cut_sandstone
fill 268 287 310 268 288 310 minecraft:cut_sandstone
fill 268 287 312 268 288 312 minecraft:cut_sandstone
fill 268 287 314 268 288 314 minecraft:cut_sandstone
fill 268 287 316 268 288 316 minecraft:cut_sandstone
fill 269 287 305 269 288 305 minecraft:cut_sandstone
fill 269 287 307 269 288 307 minecraft:cut_sandstone
fill 269 287 309 269 288 309 minecraft:cut_sandstone
fill 269 287 311 269 288 311 minecraft:cut_sandstone
fill 269 287 313 269 288 313 minecraft:cut_sandstone
fill 269 287 315 269 288 315 minecraft:cut_sandstone
setblock 270 287 278 minecraft:light[level=15]
setblock 270 287 286 minecraft:light[level=15]
fill 270 287 290 270 288 290 minecraft:cut_sandstone
fill 270 287 292 270 288 292 minecraft:cut_sandstone
fill 270 287 294 270 288 294 minecraft:cut_sandstone
fill 270 287 296 270 288 296 minecraft:cut_sandstone
fill 270 287 298 270 288 298 minecraft:cut_sandstone
fill 270 287 300 270 288 300 minecraft:cut_sandstone
setblock 270 287 302 minecraft:light[level=15]
fill 270 287 304 270 288 304 minecraft:cut_sandstone
fill 270 287 306 270 288 306 minecraft:cut_sandstone
fill 270 287 308 270 288 308 minecraft:cut_sandstone
fill 270 287 310 270 288 310 minecraft:cut_sandstone
fill 270 287 312 270 288 312 minecraft:cut_sandstone
fill 270 287 314 270 288 314 minecraft:cut_sandstone
fill 270 287 316 270 288 316 minecraft:cut_sandstone
fill 271 287 291 271 288 291 minecraft:cut_sandstone
fill 271 287 293 271 288 293 minecraft:cut_sandstone
fill 271 287 295 271 288 295 minecraft:cut_sandstone
fill 271 287 297 271 288 297 minecraft:cut_sandstone
fill 271 287 299 271 288 299 minecraft:cut_sandstone
fill 271 287 305 271 288 305 minecraft:cut_sandstone
fill 271 287 307 271 288 307 minecraft:cut_sandstone
fill 271 287 309 271 288 309 minecraft:cut_sandstone
fill 271 287 311 271 288 311 minecraft:cut_sandstone
fill 271 287 313 271 288 313 minecraft:cut_sandstone
fill 271 287 315 271 288 315 minecraft:cut_sandstone
fill 272 287 290 272 288 290 minecraft:cut_sandstone
fill 272 287 292 272 288 292 minecraft:cut_sandstone
fill 272 287 294 272 288 294 minecraft:cut_sandstone
fill 272 287 296 272 288 296 minecraft:cut_sandstone
fill 272 287 298 272 288 298 minecraft:cut_sandstone
fill 272 287 300 272 288 300 minecraft:cut_sandstone
fill 272 287 304 272 288 304 minecraft:cut_sandstone
fill 272 287 306 272 288 306 minecraft:cut_sandstone
fill 272 287 308 272 288 308 minecraft:cut_sandstone
fill 272 287 310 272 288 310 minecraft:cut_sandstone
fill 272 287 312 272 288 312 minecraft:cut_sandstone
fill 272 287 314 272 288 314 minecraft:cut_sandstone
fill 272 287 316 272 288 316 minecraft:cut_sandstone
fill 273 287 291 273 288 291 minecraft:cut_sandstone
fill 273 287 293 273 288 293 minecraft:cut_sandstone
fill 273 287 295 273 288 295 minecraft:cut_sandstone
fill 273 287 297 273 288 297 minecraft:cut_sandstone
fill 273 287 299 273 288 299 minecraft:cut_sandstone
fill 273 287 305 273 288 305 minecraft:cut_sandstone
fill 273 287 307 273 288 307 minecraft:cut_sandstone
fill 273 287 309 273 288 309 minecraft:cut_sandstone
fill 273 287 311 273 288 311 minecraft:cut_sandstone
fill 273 287 313 273 288 313 minecraft:cut_sandstone
fill 273 287 315 273 288 315 minecraft:cut_sandstone
fill 274 287 290 274 288 290 minecraft:cut_sandstone
fill 274 287 292 274 288 292 minecraft:cut_sandstone
fill 274 287 294 274 288 294 minecraft:cut_sandstone
fill 274 287 296 274 288 296 minecraft:cut_sandstone
fill 274 287 298 274 288 298 minecraft:cut_sandstone
fill 274 287 300 274 288 300 minecraft:cut_sandstone
fill 274 287 304 274 288 304 minecraft:cut_sandstone
fill 274 287 306 274 288 306 minecraft:cut_sandstone
fill 274 287 308 274 288 308 minecraft:cut_sandstone
fill 274 287 310 274 288 310 minecraft:cut_sandstone
fill 274 287 312 274 288 312 minecraft:cut_sandstone
fill 274 287 314 274 288 314 minecraft:cut_sandstone
fill 274 287 316 274 288 316 minecraft:cut_sandstone
fill 275 287 291 275 288 291 minecraft:cut_sandstone
fill 275 287 293 275 288 293 minecraft:cut_sandstone
fill 275 287 295 275 288 295 minecraft:cut_sandstone
fill 275 287 297 275 288 297 minecraft:cut_sandstone
fill 275 287 299 275 288 299 minecraft:cut_sandstone
fill 275 287 305 275 288 305 minecraft:cut_sandstone
fill 275 287 307 275 288 307 minecraft:cut_sandstone
fill 275 287 309 275 288 309 minecraft:cut_sandstone
fill 275 287 311 275 288 311 minecraft:cut_sandstone
fill 275 287 313 275 288 313 minecraft:cut_sandstone
fill 275 287 315 275 288 315 minecraft:cut_sandstone
fill 276 287 290 276 288 290 minecraft:cut_sandstone
fill 276 287 292 276 288 292 minecraft:cut_sandstone
fill 276 287 294 276 288 294 minecraft:cut_sandstone
fill 276 287 296 276 288 296 minecraft:cut_sandstone
fill 276 287 298 276 288 298 minecraft:cut_sandstone
fill 276 287 300 276 288 300 minecraft:cut_sandstone
fill 276 287 304 276 288 304 minecraft:cut_sandstone
fill 276 287 306 276 288 306 minecraft:cut_sandstone
fill 276 287 308 276 288 308 minecraft:cut_sandstone
fill 276 287 310 276 288 310 minecraft:cut_sandstone
fill 276 287 312 276 288 312 minecraft:cut_sandstone
fill 276 287 314 276 288 314 minecraft:cut_sandstone
fill 276 287 316 276 288 316 minecraft:cut_sandstone
fill 277 287 290 277 292 290 minecraft:glowstone
fill 277 287 300 277 291 300 minecraft:glowstone
fill 277 287 312 277 291 312 minecraft:glowstone
fill 277 287 314 277 292 314 minecraft:glowstone
setblock 237 288 275 minecraft:smooth_sandstone
fill 249 288 290 249 288 302 minecraft:smooth_sandstone
fill 250 288 289 262 288 289 minecraft:smooth_sandstone
fill 250 288 291 250 288 301 minecraft:smooth_sandstone
fill 250 288 303 262 288 303 minecraft:smooth_sandstone
fill 251 288 290 261 288 290 minecraft:smooth_sandstone
fill 251 288 292 251 288 300 minecraft:smooth_sandstone
fill 251 288 302 261 288 302 minecraft:smooth_sandstone
fill 252 288 291 260 288 291 minecraft:smooth_sandstone
fill 252 288 293 252 288 299 minecraft:smooth_sandstone
fill 252 288 301 260 288 301 minecraft:smooth_sandstone
fill 253 288 292 259 288 292 minecraft:smooth_sandstone
fill 253 288 294 253 288 298 minecraft:smooth_sandstone
fill 253 288 300 259 288 300 minecraft:smooth_sandstone
setblock 254 288 293 minecraft:smooth_sandstone
fill 254 288 295 254 288 297 minecraft:smooth_sandstone
fill 254 288 299 258 288 299 minecraft:smooth_sandstone
setblock 255 288 296 minecraft:smooth_sandstone
fill 255 288 298 257 288 298 minecraft:smooth_sandstone
fill 256 288 293 258 288 293 minecraft:smooth_sandstone
setblock 256 288 297 minecraft:smooth_sandstone
setblock 257 288 294 minecraft:smooth_sandstone
fill 257 288 296 263 288 296 minecraft:smooth_sandstone
fill 258 288 279 260 289 281 minecraft:cut_sandstone
fill 258 288 295 263 288 295 minecraft:smooth_sandstone
fill 258 288 297 263 288 297 minecraft:smooth_sandstone
fill 259 288 294 263 288 294 minecraft:smooth_sandstone
fill 259 288 298 263 288 298 minecraft:smooth_sandstone
fill 260 288 293 263 288 293 minecraft:smooth_sandstone
fill 260 288 299 263 288 299 minecraft:smooth_sandstone
fill 261 288 292 263 288 292 minecraft:smooth_sandstone
fill 261 288 300 263 288 300 minecraft:smooth_sandstone
fill 262 288 291 263 288 291 minecraft:smooth_sandstone
fill 262 288 301 263 288 301 minecraft:smooth_sandstone
setblock 263 288 290 minecraft:smooth_sandstone
setblock 263 288 302 minecraft:smooth_sandstone
fill 265 288 275 265 308 275 minecraft:smooth_sandstone
fill 277 288 304 277 289 304 minecraft:blue_terracotta
setblock 236 289 276 minecraft:glowstone
setblock 236 289 278 minecraft:glowstone
setblock 236 289 280 minecraft:glowstone
setblock 236 289 282 minecraft:glowstone
setblock 237 289 275 minecraft:glowstone
setblock 237 289 277 minecraft:glowstone
setblock 237 289 279 minecraft:glowstone
setblock 237 289 281 minecraft:glowstone
setblock 237 289 283 minecraft:glowstone
setblock 238 289 276 minecraft:glowstone
setblock 238 289 278 minecraft:glowstone
setblock 238 289 280 minecraft:glowstone
setblock 238 289 282 minecraft:glowstone
setblock 239 289 275 minecraft:glowstone
setblock 239 289 277 minecraft:glowstone
setblock 239 289 279 minecraft:glowstone
setblock 239 289 281 minecraft:glowstone
setblock 239 289 283 minecraft:glowstone
setblock 240 289 276 minecraft:glowstone
setblock 240 289 278 minecraft:glowstone
setblock 240 289 280 minecraft:glowstone
setblock 240 289 282 minecraft:glowstone
setblock 241 289 275 minecraft:glowstone
setblock 241 289 277 minecraft:glowstone
setblock 241 289 279 minecraft:glowstone
setblock 241 289 281 minecraft:glowstone
setblock 241 289 283 minecraft:glowstone
setblock 242 289 276 minecraft:glowstone
setblock 242 289 278 minecraft:glowstone
setblock 242 289 280 minecraft:glowstone
setblock 242 289 282 minecraft:glowstone
setblock 243 289 277 minecraft:glowstone
setblock 243 289 279 minecraft:glowstone
setblock 243 289 281 minecraft:glowstone
setblock 243 289 283 minecraft:glowstone
setblock 244 289 276 minecraft:glowstone
setblock 244 289 278 minecraft:glowstone
setblock 244 289 280 minecraft:glowstone
setblock 244 289 282 minecraft:glowstone
fill 251 289 292 251 289 300 minecraft:sandstone
fill 252 289 291 260 289 291 minecraft:sandstone
fill 252 289 293 252 289 299 minecraft:sandstone
fill 252 289 301 260 289 301 minecraft:sandstone
fill 253 289 292 259 289 292 minecraft:sandstone
fill 253 289 294 253 289 298 minecraft:sandstone
fill 253 289 300 259 289 300 minecraft:sandstone
setblock 254 289 293 minecraft:sandstone
fill 254 289 295 254 289 297 minecraft:sandstone
fill 254 289 299 258 289 299 minecraft:sandstone
setblock 255 289 296 minecraft:sandstone
fill 255 289 298 257 289 298 minecraft:sandstone
fill 256 289 293 258 289 293 minecraft:sandstone
setblock 256 289 297 minecraft:sandstone
setblock 257 289 294 minecraft:sandstone
fill 257 289 296 261 289 296 minecraft:sandstone
fill 258 289 295 261 289 295 minecraft:sandstone
fill 258 289 297 261 289 297 minecraft:sandstone
fill 259 289 294 261 289 294 minecraft:sandstone
fill 259 289 298 261 289 298 minecraft:sandstone
fill 260 289 293 261 289 293 minecraft:sandstone
fill 260 289 299 261 289 299 minecraft:sandstone
setblock 261 289 292 minecraft:sandstone
setblock 261 289 300 minecraft:sandstone
setblock 266 289 304 minecraft:glowstone
setblock 266 289 306 minecraft:glowstone
setblock 266 289 308 minecraft:glowstone
setblock 266 289 310 minecraft:glowstone
setblock 266 289 312 minecraft:glowstone
setblock 266 289 314 minecraft:glowstone
setblock 266 289 316 minecraft:glowstone
setblock 267 289 305 minecraft:glowstone
setblock 267 289 307 minecraft:glowstone
setblock 267 289 309 minecraft:glowstone
setblock 267 289 311 minecraft:glowstone
setblock 267 289 313 minecraft:glowstone
setblock 267 289 315 minecraft:glowstone
setblock 268 289 304 minecraft:glowstone
setblock 268 289 306 minecraft:glowstone
setblock 268 289 308 minecraft:glowstone
setblock 268 289 310 minecraft:glowstone
setblock 268 289 312 minecraft:glowstone
setblock 268 289 314 minecraft:glowstone
setblock 268 289 316 minecraft:glowstone
setblock 269 289 305 minecraft:glowstone
setblock 269 289 307 minecraft:glowstone
setblock 269 289 309 minecraft:glowstone
setblock 269 289 311 minecraft:glowstone
setblock 269 289 313 minecraft:glowstone
setblock 269 289 315 minecraft:glowstone
setblock 270 289 290 minecraft:glowstone
setblock 270 289 292 minecraft:glowstone
setblock 270 289 294 minecraft:glowstone
setblock 270 289 296 minecraft:glowstone
setblock 270 289 298 minecraft:glowstone
setblock 270 289 300 minecraft:glowstone
setblock 270 289 304 minecraft:glowstone
setblock 270 289 306 minecraft:glowstone
setblock 270 289 308 minecraft:glowstone
setblock 270 289 310 minecraft:glowstone
setblock 270 289 312 minecraft:glowstone
setblock 270 289 314 minecraft:glowstone
setblock 270 289 316 minecraft:glowstone
setblock 271 289 291 minecraft:glowstone
setblock 271 289 293 minecraft:glowstone
setblock 271 289 295 minecraft:glowstone
setblock 271 289 297 minecraft:glowstone
setblock 271 289 299 minecraft:glowstone
setblock 271 289 305 minecraft:glowstone
setblock 271 289 307 minecraft:glowstone
setblock 271 289 309 minecraft:glowstone
setblock 271 289 311 minecraft:glowstone
setblock 271 289 313 minecraft:glowstone
setblock 271 289 315 minecraft:glowstone
setblock 272 289 290 minecraft:glowstone
setblock 272 289 292 minecraft:glowstone
setblock 272 289 294 minecraft:glowstone
setblock 272 289 296 minecraft:glowstone
setblock 272 289 298 minecraft:glowstone
setblock 272 289 300 minecraft:glowstone
setblock 272 289 304 minecraft:glowstone
setblock 272 289 306 minecraft:glowstone
setblock 272 289 308 minecraft:glowstone
setblock 272 289 310 minecraft:glowstone
setblock 272 289 312 minecraft:glowstone
setblock 272 289 314 minecraft:glowstone
setblock 272 289 316 minecraft:glowstone
setblock 273 289 291 minecraft:glowstone
setblock 273 289 293 minecraft:glowstone
setblock 273 289 295 minecraft:glowstone
setblock 273 289 297 minecraft:glowstone
setblock 273 289 299 minecraft:glowstone
setblock 273 289 305 minecraft:glowstone
setblock 273 289 307 minecraft:glowstone
setblock 273 289 309 minecraft:glowstone
setblock 273 289 311 minecraft:glowstone
setblock 273 289 313 minecraft:glowstone
setblock 273 289 315 minecraft:glowstone
setblock 274 289 290 minecraft:glowstone
setblock 274 289 292 minecraft:glowstone
setblock 274 289 294 minecraft:glowstone
setblock 274 289 296 minecraft:glowstone
setblock 274 289 298 minecraft:glowstone
setblock 274 289 300 minecraft:glowstone
setblock 274 289 304 minecraft:glowstone
setblock 274 289 306 minecraft:glowstone
setblock 274 289 308 minecraft:glowstone
setblock 274 289 310 minecraft:glowstone
setblock 274 289 312 minecraft:glowstone
setblock 274 289 314 minecraft:glowstone
setblock 274 289 316 minecraft:glowstone
setblock 275 289 291 minecraft:glowstone
setblock 275 289 293 minecraft:glowstone
setblock 275 289 295 minecraft:glowstone
setblock 275 289 297 minecraft:glowstone
setblock 275 289 299 minecraft:glowstone
setblock 275 289 305 minecraft:glowstone
setblock 275 289 307 minecraft:glowstone
setblock 275 289 309 minecraft:glowstone
setblock 275 289 311 minecraft:glowstone
setblock 275 289 313 minecraft:glowstone
setblock 275 289 315 minecraft:glowstone
setblock 276 289 290 minecraft:glowstone
setblock 276 289 292 minecraft:glowstone
setblock 276 289 294 minecraft:glowstone
setblock 276 289 296 minecraft:glowstone
setblock 276 289 298 minecraft:glowstone
setblock 276 289 300 minecraft:glowstone
setblock 276 289 304 minecraft:glowstone
setblock 276 289 306 minecraft:glowstone
setblock 276 289 308 minecraft:glowstone
setblock 276 289 310 minecraft:glowstone
setblock 276 289 312 minecraft:glowstone
setblock 276 289 314 minecraft:glowstone
setblock 276 289 316 minecraft:glowstone
fill 236 290 276 236 291 276 minecraft:cut_sandstone
fill 236 290 278 236 291 278 minecraft:cut_sandstone
fill 236 290 280 236 291 280 minecraft:cut_sandstone
fill 236 290 282 236 291 282 minecraft:cut_sandstone
fill 237 290 275 237 291 275 minecraft:smooth_sandstone
fill 237 290 277 237 291 277 minecraft:cut_sandstone
fill 237 290 279 237 291 279 minecraft:cut_sandstone
fill 237 290 281 237 291 281 minecraft:cut_sandstone
fill 237 290 283 237 291 283 minecraft:cut_sandstone
fill 238 290 276 238 291 276 minecraft:cut_sandstone
fill 238 290 278 238 291 278 minecraft:cut_sandstone
fill 238 290 280 238 291 280 minecraft:cut_sandstone
fill 238 290 282 238 291 282 minecraft:cut_sandstone
fill 239 290 275 239 291 275 minecraft:smooth_sandstone
fill 239 290 277 239 291 277 minecraft:cut_sandstone
fill 239 290 279 239 291 279 minecraft:cut_sandstone
fill 239 290 281 239 291 281 minecraft:cut_sandstone
fill 239 290 283 239 291 283 minecraft:cut_sandstone
fill 240 290 276 240 291 276 minecraft:cut_sandstone
fill 240 290 278 240 291 278 minecraft:cut_sandstone
fill 240 290 280 240 291 280 minecraft:cut_sandstone
fill 240 290 282 240 291 282 minecraft:cut_sandstone
setblock 240 290 317 minecraft:orange_terracotta
fill 241 290 275 241 291 275 minecraft:smooth_sandstone
fill 241 290 277 241 291 277 minecraft:cut_sandstone
fill 241 290 279 241 291 279 minecraft:cut_sandstone
fill 241 290 281 241 291 281 minecraft:cut_sandstone
fill 241 290 283 241 291 283 minecraft:cut_sandstone
fill 242 290 276 242 291 276 minecraft:cut_sandstone
fill 242 290 278 242 291 278 minecraft:cut_sandstone
fill 242 290 280 242 291 280 minecraft:cut_sandstone
fill 242 290 282 242 291 282 minecraft:cut_sandstone
fill 243 290 277 243 291 277 minecraft:cut_sandstone
fill 243 290 279 243 291 279 minecraft:cut_sandstone
fill 243 290 281 243 291 281 minecraft:cut_sandstone
fill 243 290 283 243 291 283 minecraft:cut_sandstone
fill 244 290 276 244 291 276 minecraft:cut_sandstone
fill 244 290 278 244 291 278 minecraft:cut_sandstone
fill 244 290 280 244 291 280 minecraft:cut_sandstone
fill 244 290 282 244 291 282 minecraft:cut_sandstone
fill 252 290 293 252 290 299 minecraft:smooth_sandstone
fill 253 290 292 259 290 292 minecraft:smooth_sandstone
fill 253 290 294 253 290 298 minecraft:smooth_sandstone
fill 253 290 300 259 290 300 minecraft:smooth_sandstone
setblock 254 290 293 minecraft:smooth_sandstone
fill 254 290 295 254 290 297 minecraft:smooth_sandstone
fill 254 290 299 258 290 299 minecraft:smooth_sandstone
setblock 255 290 296 minecraft:smooth_sandstone
fill 255 290 298 257 290 298 minecraft:smooth_sandstone
fill 255 290 317 255 308 317 minecraft:smooth_sandstone
fill 256 290 293 258 290 293 minecraft:smooth_sandstone
setblock 256 290 297 minecraft:smooth_sandstone
setblock 256 290 317 minecraft:lapis_block
setblock 257 290 294 minecraft:smooth_sandstone
fill 257 290 296 260 290 296 minecraft:smooth_sandstone
fill 258 290 280 260 292 280 minecraft:cut_sandstone
fill 258 290 295 260 290 295 minecraft:smooth_sandstone
fill 258 290 297 260 290 297 minecraft:smooth_sandstone
fill 259 290 279 259 292 279 minecraft:cut_sandstone
fill 259 290 281 259 292 281 minecraft:cut_sandstone
fill 259 290 294 260 290 294 minecraft:smooth_sandstone
fill 259 290 298 260 290 298 minecraft:smooth_sandstone
setblock 260 290 293 minecraft:smooth_sandstone
setblock 260 290 299 minecraft:smooth_sandstone
fill 266 290 291 268 291 292 minecraft:smooth_sandstone
fill 266 290 304 266 291 304 minecraft:cut_sandstone
fill 266 290 306 266 291 306 minecraft:cut_sandstone
fill 266 290 308 266 291 308 minecraft:cut_sandstone
fill 266 290 310 266 291 310 minecraft:cut_sandstone
fill 266 290 312 266 291 312 minecraft:cut_sandstone
fill 266 290 314 266 291 314 minecraft:cut_sandstone
fill 266 290 316 266 291 316 minecraft:cut_sandstone
fill 267 290 305 267 291 305 minecraft:cut_sandstone
fill 267 290 307 267 291 307 minecraft:cut_sandstone
fill 267 290 309 267 291 309 minecraft:cut_sandstone
fill 267 290 311 267 291 311 minecraft:cut_sandstone
fill 267 290 313 267 291 313 minecraft:cut_sandstone
fill 267 290 315 267 291 315 minecraft:cut_sandstone
fill 268 290 304 268 291 304 minecraft:cut_sandstone
fill 268 290 306 268 291 306 minecraft:cut_sandstone
fill 268 290 308 268 291 308 minecraft:cut_sandstone
fill 268 290 310 268 291 310 minecraft:cut_sandstone
fill 268 290 312 268 291 312 minecraft:cut_sandstone
fill 268 290 314 268 291 314 minecraft:cut_sandstone
fill 268 290 316 268 291 316 minecraft:cut_sandstone
fill 269 290 305 269 291 305 minecraft:cut_sandstone
fill 269 290 307 269 291 307 minecraft:cut_sandstone
fill 269 290 309 269 291 309 minecraft:cut_sandstone
fill 269 290 311 269 291 311 minecraft:cut_sandstone
fill 269 290 313 269 291 313 minecraft:cut_sandstone
fill 269 290 315 269 291 315 minecraft:cut_sandstone
fill 270 290 290 270 291 290 minecraft:cut_sandstone
fill 270 290 292 270 291 292 minecraft:cut_sandstone
fill 270 290 294 270 291 294 minecraft:cut_sandstone
fill 270 290 296 270 291 296 minecraft:cut_sandstone
fill 270 290 298 270 291 298 minecraft:cut_sandstone
fill 270 290 300 270 291 300 minecraft:cut_sandstone
fill 270 290 304 270 291 304 minecraft:cut_sandstone
fill 270 290 306 270 291 306 minecraft:cut_sandstone
fill 270 290 308 270 291 308 minecraft:cut_sandstone
fill 270 290 310 270 291 310 minecraft:cut_sandstone
fill 270 290 312 270 291 312 minecraft:cut_sandstone
fill 270 290 314 270 291 314 minecraft:cut_sandstone
fill 270 290 316 270 291 316 minecraft:cut_sandstone
setblock 271 290 275 minecraft:blue_terracotta
fill 271 290 291 271 291 291 minecraft:cut_sandstone
fill 271 290 293 271 291 293 minecraft:cut_sandstone
fill 271 290 295 271 291 295 minecraft:cut_sandstone
fill 271 290 297 271 291 297 minecraft:cut_sandstone
fill 271 290 299 271 291 299 minecraft:cut_sandstone
fill 271 290 305 271 291 305 minecraft:cut_sandstone
fill 271 290 307 271 291 307 minecraft:cut_sandstone
fill 271 290 309 271 291 309 minecraft:cut_sandstone
fill 271 290 311 271 291 311 minecraft:cut_sandstone
fill 271 290 313 271 291 313 minecraft:cut_sandstone
fill 271 290 315 271 291 315 minecraft:cut_sandstone
fill 272 290 290 272 291 290 minecraft:cut_sandstone
fill 272 290 292 272 291 292 minecraft:cut_sandstone
fill 272 290 294 272 291 294 minecraft:cut_sandstone
fill 272 290 296 272 291 296 minecraft:cut_sandstone
fill 272 290 298 272 291 298 minecraft:cut_sandstone
fill 272 290 300 272 291 300 minecraft:cut_sandstone
fill 272 290 304 272 291 304 minecraft:cut_sandstone
fill 272 290 306 272 291 306 minecraft:cut_sandstone
fill 272 290 308 272 291 308 minecraft:cut_sandstone
fill 272 290 310 272 291 310 minecraft:cut_sandstone
fill 272 290 312 272 291 312 minecraft:cut_sandstone
fill 272 290 314 272 291 314 minecraft:cut_sandstone
fill 272 290 316 272 291 316 minecraft:cut_sandstone
fill 273 290 291 273 291 291 minecraft:cut_sandstone
fill 273 290 293 273 291 293 minecraft:cut_sandstone
fill 273 290 295 273 291 295 minecraft:cut_sandstone
fill 273 290 297 273 291 297 minecraft:cut_sandstone
fill 273 290 299 273 291 299 minecraft:cut_sandstone
fill 273 290 305 273 291 305 minecraft:cut_sandstone
fill 273 290 307 273 291 307 minecraft:cut_sandstone
fill 273 290 309 273 291 309 minecraft:cut_sandstone
fill 273 290 311 273 291 311 minecraft:cut_sandstone
fill 273 290 313 273 291 313 minecraft:cut_sandstone
fill 273 290 315 273 291 315 minecraft:cut_sandstone
fill 274 290 290 274 291 290 minecraft:cut_sandstone
fill 274 290 292 274 291 292 minecraft:cut_sandstone
fill 274 290 294 274 291 294 minecraft:cut_sandstone
fill 274 290 296 274 291 296 minecraft:cut_sandstone
fill 274 290 298 274 291 298 minecraft:cut_sandstone
fill 274 290 300 274 291 300 minecraft:cut_sandstone
fill 274 290 304 274 291 304 minecraft:cut_sandstone
fill 274 290 306 274 291 306 minecraft:cut_sandstone
fill 274 290 308 274 291 308 minecraft:cut_sandstone
fill 274 290 310 274 291 310 minecraft:cut_sandstone
fill 274 290 312 274 291 312 minecraft:cut_sandstone
fill 274 290 314 274 291 314 minecraft:cut_sandstone
fill 274 290 316 274 291 316 minecraft:cut_sandstone
fill 275 290 291 275 291 291 minecraft:cut_sandstone
fill 275 290 293 275 291 293 minecraft:cut_sandstone
fill 275 290 295 275 291 295 minecraft:cut_sandstone
fill 275 290 297 275 291 297 minecraft:cut_sandstone
fill 275 290 299 275 291 299 minecraft:cut_sandstone
fill 275 290 305 275 291 305 minecraft:cut_sandstone
fill 275 290 307 275 291 307 minecraft:cut_sandstone
fill 275 290 309 275 291 309 minecraft:cut_sandstone
fill 275 290 311 275 291 311 minecraft:cut_sandstone
fill 275 290 313 275 291 313 minecraft:cut_sandstone
fill 275 290 315 275 291 315 minecraft:cut_sandstone
fill 276 290 290 276 291 290 minecraft:cut_sandstone
fill 276 290 292 276 291 292 minecraft:cut_sandstone
fill 276 290 294 276 291 294 minecraft:cut_sandstone
fill 276 290 296 276 291 296 minecraft:cut_sandstone
fill 276 290 298 276 291 298 minecraft:cut_sandstone
fill 276 290 300 276 291 300 minecraft:cut_sandstone
fill 276 290 304 276 291 304 minecraft:cut_sandstone
fill 276 290 306 276 291 306 minecraft:cut_sandstone
fill 276 290 308 276 291 308 minecraft:cut_sandstone
fill 276 290 310 276 291 310 minecraft:cut_sandstone
fill 276 290 312 276 291 312 minecraft:cut_sandstone
fill 276 290 314 276 291 314 minecraft:cut_sandstone
fill 276 290 316 276 291 316 minecraft:cut_sandstone
fill 277 290 304 277 308 304 minecraft:smooth_sandstone
setblock 238 291 285 minecraft:light[level=12]
setblock 238 291 292 minecraft:light[level=12]
setblock 238 291 299 minecraft:light[level=12]
setblock 238 291 306 minecraft:light[level=12]
setblock 238 291 313 minecraft:light[level=12]
fill 239 291 310 239 291 313 minecraft:chiseled_sandstone
fill 240 291 309 242 291 309 minecraft:chiseled_sandstone
setblock 240 291 313 minecraft:chiseled_sandstone
fill 240 291 317 240 308 317 minecraft:smooth_sandstone
setblock 242 291 313 minecraft:chiseled_sandstone
fill 243 291 310 243 291 312 minecraft:chiseled_sandstone
setblock 245 291 278 minecraft:light[level=12]
setblock 245 291 285 minecraft:light[level=12]
setblock 245 291 292 minecraft:light[level=12]
setblock 245 291 299 minecraft:light[level=12]
setblock 245 291 306 minecraft:light[level=12]
setblock 245 291 313 minecraft:light[level=12]
setblock 252 291 278 minecraft:light[level=12]
setblock 252 291 285 minecraft:light[level=12]
setblock 252 291 292 minecraft:light[level=12]
setblock 252 291 299 minecraft:light[level=12]
setblock 252 291 306 minecraft:light[level=12]
setblock 252 291 313 minecraft:light[level=12]
fill 253 291 294 253 291 298 minecraft:sandstone
fill 254 291 293 258 291 293 minecraft:sandstone
fill 254 291 295 254 291 297 minecraft:sandstone
fill 254 291 299 258 291 299 minecraft:sandstone
setblock 255 291 296 minecraft:sandstone
fill 255 291 298 257 291 298 minecraft:sandstone
setblock 256 291 297 minecraft:sandstone
fill 256 291 317 256 308 317 minecraft:smooth_sandstone
setblock 257 291 294 minecraft:sandstone
fill 257 291 296 259 291 296 minecraft:sandstone
fill 258 291 295 259 291 295 minecraft:sandstone
fill 258 291 297 259 291 297 minecraft:sandstone
setblock 259 291 278 minecraft:light[level=12]
setblock 259 291 285 minecraft:light[level=12]
setblock 259 291 292 minecraft:light[level=12]
setblock 259 291 294 minecraft:sandstone
setblock 259 291 298 minecraft:sandstone
setblock 259 291 306 minecraft:light[level=12]
setblock 259 291 313 minecraft:light[level=12]
setblock 266 291 278 minecraft:light[level=12]
setblock 266 291 285 minecraft:light[level=12]
setblock 266 291 299 minecraft:light[level=12]
fill 271 291 275 271 308 275 minecraft:smooth_sandstone
setblock 273 291 278 minecraft:light[level=12]
setblock 273 291 285 minecraft:light[level=12]
fill 235 292 281 235 293 281 minecraft:smooth_sandstone
fill 235 292 282 235 292 283 minecraft:glowstone
fill 235 292 284 235 308 284 minecraft:smooth_sandstone
setblock 235 292 289 minecraft:blue_terracotta
fill 235 292 293 235 308 293 minecraft:smooth_sandstone
fill 235 292 294 235 292 295 minecraft:glowstone
fill 235 292 296 235 308 296 minecraft:smooth_sandstone
setblock 235 292 300 minecraft:lapis_block
setblock 235 292 304 minecraft:black_terracotta
fill 235 292 305 235 308 305 minecraft:smooth_sandstone
fill 235 292 306 235 292 307 minecraft:glowstone
fill 235 292 308 235 308 308 minecraft:smooth_sandstone
fill 235 292 317 235 308 317 minecraft:smooth_sandstone
setblock 236 292 276 minecraft:glowstone
setblock 236 292 278 minecraft:glowstone
setblock 236 292 280 minecraft:glowstone
setblock 236 292 282 minecraft:glowstone
fill 236 292 317 237 292 317 minecraft:glowstone
setblock 237 292 275 minecraft:glowstone
setblock 237 292 277 minecraft:glowstone
setblock 237 292 279 minecraft:glowstone
setblock 237 292 281 minecraft:glowstone
setblock 237 292 283 minecraft:glowstone
setblock 238 292 276 minecraft:glowstone
setblock 238 292 278 minecraft:glowstone
setblock 238 292 280 minecraft:glowstone
setblock 238 292 282 minecraft:glowstone
fill 238 292 317 238 295 317 minecraft:smooth_sandstone
setblock 239 292 275 minecraft:glowstone
setblock 239 292 277 minecraft:glowstone
setblock 239 292 279 minecraft:glowstone
setblock 239 292 281 minecraft:glowstone
setblock 239 292 283 minecraft:glowstone
setblock 240 292 276 minecraft:glowstone
setblock 240 292 278 minecraft:glowstone
setblock 240 292 280 minecraft:glowstone
setblock 240 292 282 minecraft:glowstone
setblock 241 292 275 minecraft:glowstone
setblock 241 292 277 minecraft:glowstone
setblock 241 292 279 minecraft:glowstone
setblock 241 292 281 minecraft:glowstone
setblock 241 292 283 minecraft:glowstone
fill 242 292 275 242 301 275 minecraft:smooth_sandstone
setblock 242 292 276 minecraft:glowstone
setblock 242 292 278 minecraft:glowstone
setblock 242 292 280 minecraft:glowstone
setblock 242 292 282 minecraft:glowstone
fill 243 292 275 244 292 275 minecraft:glowstone
setblock 243 292 277 minecraft:glowstone
setblock 243 292 279 minecraft:glowstone
setblock 243 292 281 minecraft:glowstone
setblock 243 292 283 minecraft:glowstone
setblock 244 292 276 minecraft:glowstone
setblock 244 292 278 minecraft:glowstone
setblock 244 292 280 minecraft:glowstone
setblock 244 292 282 minecraft:glowstone
fill 245 292 275 245 308 275 minecraft:smooth_sandstone
fill 247 292 317 247 308 317 minecraft:smooth_sandstone
fill 248 292 317 249 292 317 minecraft:glowstone
fill 250 292 317 250 293 317 minecraft:smooth_sandstone
fill 254 292 275 254 308 275 minecraft:smooth_sandstone
fill 255 292 275 256 292 275 minecraft:glowstone
setblock 255 292 296 minecraft:smooth_sandstone
setblock 256 292 297 minecraft:smooth_sandstone
fill 257 292 275 257 308 275 minecraft:smooth_sandstone
setblock 257 292 296 minecraft:smooth_sandstone
fill 259 292 317 259 308 317 minecraft:smooth_sandstone
fill 260 292 317 261 292 317 minecraft:glowstone
fill 262 292 317 262 308 317 minecraft:smooth_sandstone
fill 266 292 275 266 308 275 minecraft:smooth_sandstone
setblock 266 292 304 minecraft:glowstone
setblock 266 292 306 minecraft:glowstone
setblock 266 292 308 minecraft:glowstone
setblock 266 292 310 minecraft:glowstone
setblock 266 292 312 minecraft:glowstone
setblock 266 292 314 minecraft:glowstone
setblock 266 292 316 minecraft:glowstone
fill 267 292 275 268 292 275 minecraft:glowstone
setblock 267 292 305 minecraft:glowstone
setblock 267 292 307 minecraft:glowstone
setblock 267 292 309 minecraft:glowstone
setblock 267 292 311 minecraft:glowstone
setblock 267 292 313 minecraft:glowstone
setblock 267 292 315 minecraft:glowstone
setblock 268 292 304 minecraft:glowstone
setblock 268 292 306 minecraft:glowstone
setblock 268 292 308 minecraft:glowstone
setblock 268 292 310 minecraft:glowstone
setblock 268 292 312 minecraft:glowstone
setblock 268 292 314 minecraft:glowstone
setblock 268 292 316 minecraft:glowstone
fill 269 292 275 269 308 275 minecraft:smooth_sandstone
setblock 269 292 305 minecraft:glowstone
setblock 269 292 307 minecraft:glowstone
setblock 269 292 309 minecraft:glowstone
setblock 269 292 311 minecraft:glowstone
setblock 269 292 313 minecraft:glowstone
setblock 269 292 315 minecraft:glowstone
setblock 270 292 290 minecraft:glowstone
setblock 270 292 292 minecraft:glowstone
setblock 270 292 294 minecraft:glowstone
setblock 270 292 296 minecraft:glowstone
setblock 270 292 298 minecraft:glowstone
setblock 270 292 300 minecraft:glowstone
setblock 270 292 304 minecraft:glowstone
setblock 270 292 306 minecraft:glowstone
setblock 270 292 308 minecraft:glowstone
setblock 270 292 310 minecraft:glowstone
setblock 270 292 312 minecraft:glowstone
setblock 270 292 314 minecraft:glowstone
setblock 270 292 316 minecraft:glowstone
setblock 271 292 291 minecraft:glowstone
setblock 271 292 293 minecraft:glowstone
setblock 271 292 295 minecraft:glowstone
setblock 271 292 297 minecraft:glowstone
setblock 271 292 299 minecraft:glowstone
setblock 271 292 305 minecraft:glowstone
setblock 271 292 307 minecraft:glowstone
setblock 271 292 309 minecraft:glowstone
setblock 271 292 311 minecraft:glowstone
setblock 271 292 313 minecraft:glowstone
setblock 271 292 315 minecraft:glowstone
fill 271 292 317 271 308 317 minecraft:smooth_sandstone
setblock 272 292 290 minecraft:glowstone
setblock 272 292 292 minecraft:glowstone
setblock 272 292 294 minecraft:glowstone
setblock 272 292 296 minecraft:glowstone
setblock 272 292 298 minecraft:glowstone
setblock 272 292 300 minecraft:glowstone
setblock 272 292 304 minecraft:glowstone
setblock 272 292 306 minecraft:glowstone
setblock 272 292 308 minecraft:glowstone
setblock 272 292 310 minecraft:glowstone
setblock 272 292 312 minecraft:glowstone
setblock 272 292 314 minecraft:glowstone
fill 272 292 316 272 292 317 minecraft:glowstone
setblock 273 292 291 minecraft:glowstone
setblock 273 292 293 minecraft:glowstone
setblock 273 292 295 minecraft:glowstone
setblock 273 292 297 minecraft:glowstone
setblock 273 292 299 minecraft:glowstone
setblock 273 292 305 minecraft:glowstone
setblock 273 292 307 minecraft:glowstone
setblock 273 292 309 minecraft:glowstone
setblock 273 292 311 minecraft:glowstone
setblock 273 292 313 minecraft:glowstone
setblock 273 292 315 minecraft:glowstone
setblock 273 292 317 minecraft:glowstone
setblock 274 292 290 minecraft:glowstone
setblock 274 292 292 minecraft:glowstone
setblock 274 292 294 minecraft:glowstone
setblock 274 292 296 minecraft:glowstone
setblock 274 292 298 minecraft:glowstone
setblock 274 292 300 minecraft:glowstone
setblock 274 292 304 minecraft:glowstone
setblock 274 292 306 minecraft:glowstone
setblock 274 292 308 minecraft:glowstone
setblock 274 292 310 minecraft:glowstone
setblock 274 292 312 minecraft:glowstone
setblock 274 292 314 minecraft:glowstone
setblock 274 292 316 minecraft:glowstone
fill 274 292 317 274 308 317 minecraft:smooth_sandstone
setblock 275 292 291 minecraft:glowstone
setblock 275 292 293 minecraft:glowstone
setblock 275 292 295 minecraft:glowstone
setblock 275 292 297 minecraft:glowstone
setblock 275 292 299 minecraft:glowstone
setblock 275 292 305 minecraft:glowstone
setblock 275 292 307 minecraft:glowstone
setblock 275 292 309 minecraft:glowstone
setblock 275 292 311 minecraft:glowstone
setblock 275 292 313 minecraft:glowstone
setblock 275 292 315 minecraft:glowstone
setblock 276 292 290 minecraft:glowstone
setblock 276 292 292 minecraft:glowstone
setblock 276 292 294 minecraft:glowstone
setblock 276 292 296 minecraft:glowstone
setblock 276 292 298 minecraft:glowstone
setblock 276 292 300 minecraft:glowstone
setblock 276 292 304 minecraft:glowstone
setblock 276 292 306 minecraft:glowstone
setblock 276 292 308 minecraft:glowstone
setblock 276 292 310 minecraft:glowstone
setblock 276 292 312 minecraft:glowstone
setblock 276 292 314 minecraft:glowstone
setblock 276 292 316 minecraft:glowstone
fill 277 292 276 277 308 276 minecraft:smooth_sandstone
fill 277 292 277 277 292 278 minecraft:glowstone
fill 277 292 279 277 308 279 minecraft:smooth_sandstone
fill 277 292 288 277 308 288 minecraft:smooth_sandstone
setblock 277 292 289 minecraft:glowstone
fill 277 292 291 277 308 291 minecraft:smooth_sandstone
fill 277 292 300 277 308 300 minecraft:smooth_sandstone
fill 277 292 301 277 292 302 minecraft:glowstone
fill 277 292 303 277 305 303 minecraft:smooth_sandstone
fill 277 292 312 277 308 312 minecraft:smooth_sandstone
fill 277 292 315 277 308 315 minecraft:smooth_sandstone
setblock 277 292 316 minecraft:orange_terracotta
fill 235 293 282 235 302 283 minecraft:smooth_sandstone
fill 235 293 289 235 308 289 minecraft:smooth_sandstone
fill 235 293 294 235 305 295 minecraft:smooth_sandstone
fill 235 293 300 235 308 300 minecraft:smooth_sandstone
fill 235 293 304 235 308 304 minecraft:smooth_sandstone
fill 235 293 306 235 308 307 minecraft:smooth_sandstone
fill 236 293 276 236 294 276 minecraft:cut_sandstone
fill 236 293 278 236 294 278 minecraft:cut_sandstone
fill 236 293 280 236 294 280 minecraft:cut_sandstone
fill 236 293 282 236 294 282 minecraft:cut_sandstone
fill 236 293 317 237 308 317 minecraft:smooth_sandstone
fill 237 293 275 237 294 275 minecraft:smooth_sandstone
fill 237 293 277 237 294 277 minecraft:cut_sandstone
fill 237 293 279 237 294 279 minecraft:cut_sandstone
fill 237 293 281 237 294 281 minecraft:cut_sandstone
fill 237 293 283 237 294 283 minecraft:cut_sandstone
fill 238 293 276 238 294 276 minecraft:cut_sandstone
fill 238 293 278 238 294 278 minecraft:cut_sandstone
fill 238 293 280 238 294 280 minecraft:cut_sandstone
fill 238 293 282 238 294 282 minecraft:cut_sandstone
fill 239 293 275 239 294 275 minecraft:smooth_sandstone
fill 239 293 277 239 294 277 minecraft:cut_sandstone
fill 239 293 279 239 294 279 minecraft:cut_sandstone
fill 239 293 281 239 294 281 minecraft:cut_sandstone
fill 239 293 283 239 294 283 minecraft:cut_sandstone
setblock 239 293 317 minecraft:black_terracotta
fill 240 293 276 240 294 276 minecraft:cut_sandstone
fill 240 293 278 240 294 278 minecraft:cut_sandstone
fill 240 293 280 240 294 280 minecraft:cut_sandstone
fill 240 293 282 240 294 282 minecraft:cut_sandstone
fill 241 293 275 241 294 275 minecraft:smooth_sandstone
fill 241 293 277 241 294 277 minecraft:cut_sandstone
fill 241 293 279 241 294 279 minecraft:cut_sandstone
fill 241 293 281 241 294 281 minecraft:cut_sandstone
fill 241 293 283 241 294 283 minecraft:cut_sandstone
fill 242 293 276 242 294 276 minecraft:cut_sandstone
fill 242 293 278 242 294 278 minecraft:cut_sandstone
fill 242 293 280 242 294 280 minecraft:cut_sandstone
fill 242 293 282 242 294 282 minecraft:cut_sandstone
fill 243 293 275 244 294 275 minecraft:smooth_sandstone
fill 243 293 277 243 294 277 minecraft:cut_sandstone
fill 243 293 279 243 294 279 minecraft:cut_sandstone
fill 243 293 281 243 294 281 minecraft:cut_sandstone
fill 243 293 283 243 294 283 minecraft:cut_sandstone
fill 244 293 276 244 294 276 minecraft:cut_sandstone
fill 244 293 278 244 294 278 minecraft:cut_sandstone
fill 244 293 280 244 294 280 minecraft:cut_sandstone
fill 244 293 282 244 294 282 minecraft:cut_sandstone
fill 248 293 317 249 308 317 minecraft:smooth_sandstone
fill 255 293 275 256 306 275 minecraft:smooth_sandstone
fill 259 293 280 259 297 280 minecraft:cut_sandstone
fill 260 293 317 261 308 317 minecraft:smooth_sandstone
setblock 266 293 304 minecraft:cut_sandstone
setblock 266 293 306 minecraft:cut_sandstone
setblock 266 293 308 minecraft:cut_sandstone
setblock 266 293 310 minecraft:cut_sandstone
setblock 266 293 312 minecraft:cut_sandstone
setblock 266 293 314 minecraft:cut_sandstone
fill 266 293 316 266 300 316 minecraft:cut_sandstone
fill 267 293 275 268 302 275 minecraft:smooth_sandstone
setblock 267 293 305 minecraft:cut_sandstone
setblock 267 293 307 minecraft:cut_sandstone
setblock 267 293 309 minecraft:cut_sandstone
setblock 267 293 311 minecraft:cut_sandstone
setblock 267 293 313 minecraft:cut_sandstone
setblock 267 293 315 minecraft:cut_sandstone
setblock 268 293 304 minecraft:cut_sandstone
setblock 268 293 306 minecraft:cut_sandstone
setblock 268 293 308 minecraft:cut_sandstone
setblock 268 293 310 minecraft:cut_sandstone
setblock 268 293 312 minecraft:cut_sandstone
setblock 268 293 314 minecraft:cut_sandstone
fill 268 293 316 268 300 316 minecraft:cut_sandstone
setblock 269 293 305 minecraft:cut_sandstone
setblock 269 293 307 minecraft:cut_sandstone
setblock 269 293 309 minecraft:cut_sandstone
setblock 269 293 311 minecraft:cut_sandstone
setblock 269 293 313 minecraft:cut_sandstone
setblock 269 293 315 minecraft:cut_sandstone
fill 270 293 290 270 294 290 minecraft:cut_sandstone
fill 270 293 292 270 294 292 minecraft:cut_sandstone
fill 270 293 294 270 294 294 minecraft:cut_sandstone
fill 270 293 296 270 294 296 minecraft:cut_sandstone
fill 270 293 298 270 294 298 minecraft:cut_sandstone
fill 270 293 300 270 294 300 minecraft:cut_sandstone
setblock 270 293 304 minecraft:cut_sandstone
setblock 270 293 306 minecraft:cut_sandstone
setblock 270 293 308 minecraft:cut_sandstone
setblock 270 293 310 minecraft:cut_sandstone
setblock 270 293 312 minecraft:cut_sandstone
setblock 270 293 314 minecraft:cut_sandstone
setblock 270 293 316 minecraft:cut_sandstone
fill 271 293 291 271 294 291 minecraft:cut_sandstone
fill 271 293 293 271 294 293 minecraft:cut_sandstone
fill 271 293 295 271 294 295 minecraft:cut_sandstone
fill 271 293 297 271 294 297 minecraft:cut_sandstone
fill 271 293 299 271 294 299 minecraft:cut_sandstone
setblock 271 293 305 minecraft:cut_sandstone
setblock 271 293 307 minecraft:cut_sandstone
setblock 271 293 309 minecraft:cut_sandstone
setblock 271 293 311 minecraft:cut_sandstone
setblock 271 293 313 minecraft:cut_sandstone
setblock 271 293 315 minecraft:cut_sandstone
fill 272 293 290 272 294 290 minecraft:cut_sandstone
fill 272 293 292 272 294 292 minecraft:cut_sandstone
fill 272 293 294 272 294 294 minecraft:cut_sandstone
fill 272 293 296 272 294 296 minecraft:cut_sandstone
fill 272 293 298 272 294 298 minecraft:cut_sandstone
fill 272 293 300 272 294 300 minecraft:cut_sandstone
setblock 272 293 304 minecraft:cut_sandstone
setblock 272 293 306 minecraft:cut_sandstone
setblock 272 293 308 minecraft:cut_sandstone
setblock 272 293 310 minecraft:cut_sandstone
setblock 272 293 312 minecraft:cut_sandstone
setblock 272 293 314 minecraft:cut_sandstone
setblock 272 293 316 minecraft:cut_sandstone
fill 272 293 317 273 308 317 minecraft:smooth_sandstone
fill 273 293 291 273 294 291 minecraft:cut_sandstone
fill 273 293 293 273 294 293 minecraft:cut_sandstone
fill 273 293 295 273 294 295 minecraft:cut_sandstone
fill 273 293 297 273 294 297 minecraft:cut_sandstone
fill 273 293 299 273 294 299 minecraft:cut_sandstone
setblock 273 293 305 minecraft:cut_sandstone
setblock 273 293 307 minecraft:cut_sandstone
setblock 273 293 309 minecraft:cut_sandstone
setblock 273 293 311 minecraft:cut_sandstone
setblock 273 293 313 minecraft:cut_sandstone
setblock 273 293 315 minecraft:cut_sandstone
fill 274 293 290 274 294 290 minecraft:cut_sandstone
fill 274 293 292 274 294 292 minecraft:cut_sandstone
fill 274 293 294 274 294 294 minecraft:cut_sandstone
fill 274 293 296 274 294 296 minecraft:cut_sandstone
fill 274 293 298 274 294 298 minecraft:cut_sandstone
fill 274 293 300 274 294 300 minecraft:cut_sandstone
setblock 274 293 304 minecraft:cut_sandstone
setblock 274 293 306 minecraft:cut_sandstone
setblock 274 293 308 minecraft:cut_sandstone
setblock 274 293 310 minecraft:cut_sandstone
setblock 274 293 312 minecraft:cut_sandstone
setblock 274 293 314 minecraft:cut_sandstone
setblock 274 293 316 minecraft:cut_sandstone
fill 275 293 291 275 294 291 minecraft:cut_sandstone
fill 275 293 293 275 294 293 minecraft:cut_sandstone
fill 275 293 295 275 294 295 minecraft:cut_sandstone
fill 275 293 297 275 294 297 minecraft:cut_sandstone
fill 275 293 299 275 294 299 minecraft:cut_sandstone
setblock 275 293 305 minecraft:cut_sandstone
setblock 275 293 307 minecraft:cut_sandstone
setblock 275 293 309 minecraft:cut_sandstone
setblock 275 293 311 minecraft:cut_sandstone
setblock 275 293 313 minecraft:cut_sandstone
setblock 275 293 315 minecraft:cut_sandstone
fill 276 293 290 276 294 290 minecraft:cut_sandstone
fill 276 293 292 276 294 292 minecraft:cut_sandstone
fill 276 293 294 276 294 294 minecraft:cut_sandstone
fill 276 293 296 276 294 296 minecraft:cut_sandstone
fill 276 293 298 276 294 298 minecraft:cut_sandstone
fill 276 293 300 276 294 300 minecraft:cut_sandstone
setblock 276 293 304 minecraft:cut_sandstone
setblock 276 293 306 minecraft:cut_sandstone
fill 276 293 308 276 300 308 minecraft:cut_sandstone
fill 276 293 310 276 300 310 minecraft:cut_sandstone
setblock 276 293 312 minecraft:cut_sandstone
setblock 276 293 314 minecraft:cut_sandstone
setblock 276 293 316 minecraft:cut_sandstone
fill 277 293 277 277 308 278 minecraft:smooth_sandstone
setblock 277 293 284 minecraft:blue_terracotta
fill 277 293 289 277 308 290 minecraft:smooth_sandstone
fill 277 293 301 277 308 302 minecraft:smooth_sandstone
fill 277 293 305 277 308 306 minecraft:smooth_sandstone
setblock 277 293 307 minecraft:black_terracotta
fill 277 293 313 277 308 314 minecraft:smooth_sandstone
fill 277 293 316 277 308 316 minecraft:smooth_sandstone
setblock 235 294 281 minecraft:black_terracotta
fill 239 294 317 239 308 317 minecraft:smooth_sandstone
setblock 250 294 317 minecraft:orange_terracotta
fill 267 294 305 275 294 315 minecraft:lapis_block
fill 277 294 284 277 308 284 minecraft:smooth_sandstone
setblock 277 294 298 minecraft:blue_terracotta
fill 277 294 307 277 308 307 minecraft:smooth_sandstone
fill 235 295 281 235 308 281 minecraft:smooth_sandstone
setblock 236 295 276 minecraft:glowstone
setblock 236 295 278 minecraft:glowstone
setblock 236 295 280 minecraft:glowstone
setblock 236 295 282 minecraft:glowstone
setblock 237 295 275 minecraft:glowstone
setblock 237 295 277 minecraft:glowstone
setblock 237 295 279 minecraft:glowstone
setblock 237 295 281 minecraft:glowstone
setblock 237 295 283 minecraft:glowstone
setblock 238 295 276 minecraft:glowstone
setblock 238 295 278 minecraft:glowstone
setblock 238 295 280 minecraft:glowstone
setblock 238 295 282 minecraft:glowstone
setblock 238 295 286 minecraft:light[level=15]
setblock 238 295 294 minecraft:light[level=15]
setblock 238 295 302 minecraft:light[level=15]
setblock 238 295 310 minecraft:light[level=15]
setblock 239 295 275 minecraft:glowstone
setblock 239 295 277 minecraft:glowstone
setblock 239 295 279 minecraft:glowstone
setblock 239 295 281 minecraft:glowstone
setblock 239 295 283 minecraft:glowstone
setblock 240 295 276 minecraft:glowstone
setblock 240 295 278 minecraft:glowstone
setblock 240 295 280 minecraft:glowstone
setblock 240 295 282 minecraft:glowstone
setblock 241 295 275 minecraft:glowstone
setblock 241 295 277 minecraft:glowstone
setblock 241 295 279 minecraft:glowstone
setblock 241 295 281 minecraft:glowstone
setblock 241 295 283 minecraft:glowstone
setblock 242 295 276 minecraft:glowstone
setblock 242 295 278 minecraft:glowstone
setblock 242 295 280 minecraft:glowstone
setblock 242 295 282 minecraft:glowstone
setblock 243 295 275 minecraft:glowstone
setblock 243 295 277 minecraft:glowstone
setblock 243 295 279 minecraft:glowstone
setblock 243 295 281 minecraft:glowstone
setblock 243 295 283 minecraft:glowstone
fill 244 295 275 244 308 275 minecraft:smooth_sandstone
setblock 244 295 276 minecraft:glowstone
setblock 244 295 278 minecraft:glowstone
setblock 244 295 280 minecraft:glowstone
setblock 244 295 282 minecraft:glowstone
setblock 246 295 278 minecraft:light[level=15]
setblock 246 295 286 minecraft:light[level=15]
setblock 246 295 294 minecraft:light[level=15]
setblock 246 295 302 minecraft:light[level=15]
setblock 246 295 310 minecraft:light[level=15]
fill 250 295 317 250 308 317 minecraft:smooth_sandstone
setblock 254 295 278 minecraft:light[level=15]
setblock 254 295 286 minecraft:light[level=15]
setblock 254 295 294 minecraft:light[level=15]
setblock 254 295 302 minecraft:light[level=15]
setblock 254 295 310 minecraft:light[level=15]
setblock 262 295 278 minecraft:light[level=15]
setblock 262 295 286 minecraft:light[level=15]
setblock 262 295 294 minecraft:light[level=15]
setblock 262 295 302 minecraft:light[level=15]
setblock 262 295 310 minecraft:light[level=15]
setblock 263 295 275 minecraft:orange_terracotta
fill 268 295 306 274 295 314 minecraft:lapis_block
setblock 270 295 278 minecraft:light[level=15]
setblock 270 295 286 minecraft:light[level=15]
setblock 270 295 290 minecraft:glowstone
setblock 270 295 292 minecraft:glowstone
setblock 270 295 294 minecraft:glowstone
setblock 270 295 296 minecraft:glowstone
setblock 270 295 298 minecraft:glowstone
setblock 270 295 300 minecraft:glowstone
setblock 270 295 302 minecraft:light[level=15]
setblock 271 295 291 minecraft:glowstone
setblock 271 295 293 minecraft:glowstone
setblock 271 295 295 minecraft:glowstone
setblock 271 295 297 minecraft:glowstone
setblock 271 295 299 minecraft:glowstone
setblock 272 295 290 minecraft:glowstone
setblock 272 295 292 minecraft:glowstone
setblock 272 295 294 minecraft:glowstone
setblock 272 295 296 minecraft:glowstone
setblock 272 295 298 minecraft:glowstone
setblock 272 295 300 minecraft:glowstone
setblock 273 295 291 minecraft:glowstone
setblock 273 295 293 minecraft:glowstone
setblock 273 295 295 minecraft:glowstone
setblock 273 295 297 minecraft:glowstone
setblock 273 295 299 minecraft:glowstone
setblock 274 295 290 minecraft:glowstone
setblock 274 295 292 minecraft:glowstone
setblock 274 295 294 minecraft:glowstone
setblock 274 295 296 minecraft:glowstone
setblock 274 295 298 minecraft:glowstone
setblock 274 295 300 minecraft:glowstone
setblock 275 295 291 minecraft:glowstone
setblock 275 295 293 minecraft:glowstone
setblock 275 295 295 minecraft:glowstone
setblock 275 295 297 minecraft:glowstone
setblock 275 295 299 minecraft:glowstone
setblock 276 295 290 minecraft:glowstone
setblock 276 295 292 minecraft:glowstone
setblock 276 295 294 minecraft:glowstone
setblock 276 295 296 minecraft:glowstone
setblock 276 295 298 minecraft:glowstone
setblock 276 295 300 minecraft:glowstone
fill 277 295 298 277 306 298 minecraft:smooth_sandstone
setblock 235 296 280 minecraft:blue_terracotta
fill 236 296 276 236 297 276 minecraft:cut_sandstone
fill 236 296 278 236 297 278 minecraft:cut_sandstone
fill 236 296 280 236 297 280 minecraft:cut_sandstone
fill 236 296 282 236 297 282 minecraft:cut_sandstone
fill 237 296 275 237 297 275 minecraft:smooth_sandstone
fill 237 296 277 237 297 277 minecraft:cut_sandstone
fill 237 296 279 237 297 279 minecraft:cut_sandstone
fill 237 296 281 237 297 281 minecraft:cut_sandstone
fill 237 296 283 237 297 283 minecraft:cut_sandstone
fill 238 296 276 238 297 276 minecraft:cut_sandstone
fill 238 296 278 238 297 278 minecraft:cut_sandstone
fill 238 296 280 238 297 280 minecraft:cut_sandstone
fill 238 296 282 238 297 282 minecraft:cut_sandstone
setblock 238 296 317 minecraft:blue_terracotta
fill 239 296 275 239 297 275 minecraft:smooth_sandstone
fill 239 296 277 239 297 277 minecraft:cut_sandstone
fill 239 296 279 239 297 279 minecraft:cut_sandstone
fill 239 296 281 239 297 281 minecraft:cut_sandstone
fill 239 296 283 239 297 283 minecraft:cut_sandstone
fill 240 296 276 240 297 276 minecraft:cut_sandstone
fill 240 296 278 240 297 278 minecraft:cut_sandstone
fill 240 296 280 240 297 280 minecraft:cut_sandstone
fill 240 296 282 240 297 282 minecraft:cut_sandstone
fill 241 296 275 241 297 275 minecraft:smooth_sandstone
fill 241 296 277 241 297 277 minecraft:cut_sandstone
fill 241 296 279 241 297 279 minecraft:cut_sandstone
fill 241 296 281 241 297 281 minecraft:cut_sandstone
fill 241 296 283 241 297 283 minecraft:cut_sandstone
fill 242 296 276 242 297 276 minecraft:cut_sandstone
fill 242 296 278 242 297 278 minecraft:cut_sandstone
fill 242 296 280 242 297 280 minecraft:cut_sandstone
fill 242 296 282 242 297 282 minecraft:cut_sandstone
fill 243 296 275 243 297 275 minecraft:smooth_sandstone
fill 243 296 277 243 297 277 minecraft:cut_sandstone
fill 243 296 279 243 297 279 minecraft:cut_sandstone
fill 243 296 281 243 297 281 minecraft:cut_sandstone
fill 243 296 283 243 297 283 minecraft:cut_sandstone
fill 244 296 276 244 297 276 minecraft:cut_sandstone
fill 244 296 278 244 297 278 minecraft:cut_sandstone
fill 244 296 280 244 297 280 minecraft:cut_sandstone
fill 244 296 282 244 297 282 minecraft:cut_sandstone
fill 260 296 281 260 297 282 minecraft:sandstone
fill 263 296 275 263 308 275 minecraft:smooth_sandstone
fill 269 296 307 273 296 313 minecraft:lapis_block
fill 270 296 290 270 297 290 minecraft:cut_sandstone
fill 270 296 292 270 297 292 minecraft:cut_sandstone
fill 270 296 294 270 297 294 minecraft:cut_sandstone
fill 270 296 296 270 297 296 minecraft:cut_sandstone
fill 270 296 298 270 297 298 minecraft:cut_sandstone
fill 270 296 300 270 297 300 minecraft:cut_sandstone
fill 271 296 291 271 297 291 minecraft:cut_sandstone
fill 271 296 293 271 297 293 minecraft:cut_sandstone
fill 271 296 295 271 297 295 minecraft:cut_sandstone
fill 271 296 297 271 297 297 minecraft:cut_sandstone
fill 271 296 299 271 297 299 minecraft:cut_sandstone
fill 272 296 290 272 297 290 minecraft:cut_sandstone
fill 272 296 292 272 297 292 minecraft:cut_sandstone
fill 272 296 294 272 297 294 minecraft:cut_sandstone
fill 272 296 296 272 297 296 minecraft:cut_sandstone
fill 272 296 298 272 297 298 minecraft:cut_sandstone
fill 272 296 300 272 297 300 minecraft:cut_sandstone
fill 273 296 291 273 297 291 minecraft:cut_sandstone
fill 273 296 293 273 297 293 minecraft:cut_sandstone
fill 273 296 295 273 297 295 minecraft:cut_sandstone
fill 273 296 297 273 297 297 minecraft:cut_sandstone
fill 273 296 299 273 297 299 minecraft:cut_sandstone
fill 274 296 290 274 297 290 minecraft:cut_sandstone
fill 274 296 292 274 297 292 minecraft:cut_sandstone
fill 274 296 294 274 297 294 minecraft:cut_sandstone
fill 274 296 296 274 297 296 minecraft:cut_sandstone
fill 274 296 298 274 297 298 minecraft:cut_sandstone
fill 274 296 300 274 297 300 minecraft:cut_sandstone
fill 275 296 291 275 297 291 minecraft:cut_sandstone
fill 275 296 293 275 297 293 minecraft:cut_sandstone
fill 275 296 295 275 297 295 minecraft:cut_sandstone
fill 275 296 297 275 297 297 minecraft:cut_sandstone
fill 275 296 299 275 297 299 minecraft:cut_sandstone
fill 276 296 290 276 297 290 minecraft:cut_sandstone
fill 276 296 292 276 297 292 minecraft:cut_sandstone
fill 276 296 294 276 297 294 minecraft:cut_sandstone
fill 276 296 296 276 297 296 minecraft:cut_sandstone
fill 276 296 298 276 297 298 minecraft:cut_sandstone
fill 276 296 300 276 297 300 minecraft:cut_sandstone
fill 235 297 280 235 308 280 minecraft:smooth_sandstone
setblock 235 297 315 minecraft:lapis_block
setblock 238 297 285 minecraft:light[level=12]
setblock 238 297 292 minecraft:light[level=12]
setblock 238 297 299 minecraft:light[level=12]
setblock 238 297 306 minecraft:light[level=12]
setblock 238 297 313 minecraft:light[level=12]
fill 238 297 317 238 308 317 minecraft:smooth_sandstone
setblock 245 297 278 minecraft:light[level=12]
setblock 245 297 285 minecraft:light[level=12]
setblock 245 297 292 minecraft:light[level=12]
setblock 245 297 299 minecraft:light[level=12]
setblock 245 297 306 minecraft:light[level=12]
setblock 245 297 313 minecraft:light[level=12]
setblock 252 297 278 minecraft:light[level=12]
setblock 252 297 285 minecraft:light[level=12]
setblock 252 297 292 minecraft:light[level=12]
setblock 252 297 299 minecraft:light[level=12]
setblock 252 297 306 minecraft:light[level=12]
setblock 252 297 313 minecraft:light[level=12]
setblock 259 297 278 minecraft:light[level=12]
setblock 259 297 285 minecraft:light[level=12]
setblock 259 297 292 minecraft:light[level=12]
setblock 259 297 299 minecraft:light[level=12]
setblock 259 297 306 minecraft:light[level=12]
setblock 259 297 313 minecraft:light[level=12]
setblock 266 297 278 minecraft:light[level=12]
setblock 266 297 285 minecraft:light[level=12]
setblock 266 297 292 minecraft:light[level=12]
setblock 266 297 299 minecraft:light[level=12]
setblock 266 297 306 minecraft:light[level=12]
setblock 266 297 313 minecraft:light[level=12]
fill 270 297 308 272 297 312 minecraft:lapis_block
setblock 273 297 278 minecraft:light[level=12]
setblock 273 297 285 minecraft:light[level=12]
setblock 273 297 306 minecraft:light[level=12]
setblock 273 297 313 minecraft:light[level=12]
setblock 277 297 295 minecraft:blue_terracotta
fill 235 298 315 235 308 315 minecraft:smooth_sandstone
setblock 236 298 276 minecraft:glowstone
setblock 236 298 278 minecraft:glowstone
setblock 236 298 280 minecraft:glowstone
setblock 236 298 282 minecraft:glowstone
setblock 237 298 275 minecraft:glowstone
setblock 237 298 277 minecraft:glowstone
setblock 237 298 279 minecraft:glowstone
setblock 237 298 281 minecraft:glowstone
setblock 237 298 283 minecraft:glowstone
setblock 238 298 276 minecraft:glowstone
setblock 238 298 278 minecraft:glowstone
setblock 238 298 280 minecraft:glowstone
setblock 238 298 282 minecraft:glowstone
setblock 239 298 275 minecraft:glowstone
setblock 239 298 277 minecraft:glowstone
setblock 239 298 279 minecraft:glowstone
setblock 239 298 281 minecraft:glowstone
setblock 239 298 283 minecraft:glowstone
setblock 240 298 276 minecraft:glowstone
setblock 240 298 278 minecraft:glowstone
setblock 240 298 280 minecraft:glowstone
setblock 240 298 282 minecraft:glowstone
setblock 241 298 275 minecraft:glowstone
setblock 241 298 277 minecraft:glowstone
setblock 241 298 279 minecraft:glowstone
setblock 241 298 281 minecraft:glowstone
setblock 241 298 283 minecraft:glowstone
setblock 242 298 276 minecraft:glowstone
setblock 242 298 278 minecraft:glowstone
setblock 242 298 280 minecraft:glowstone
setblock 242 298 282 minecraft:glowstone
setblock 243 298 275 minecraft:glowstone
setblock 243 298 277 minecraft:glowstone
setblock 243 298 279 minecraft:glowstone
setblock 243 298 281 minecraft:glowstone
setblock 243 298 283 minecraft:glowstone
setblock 244 298 276 minecraft:glowstone
setblock 244 298 278 minecraft:glowstone
setblock 244 298 280 minecraft:glowstone
setblock 244 298 282 minecraft:glowstone
setblock 250 298 275 minecraft:blue_terracotta
setblock 259 298 280 minecraft:glowstone
setblock 263 298 317 minecraft:lapis_block
setblock 270 298 290 minecraft:glowstone
setblock 270 298 292 minecraft:glowstone
setblock 270 298 294 minecraft:glowstone
setblock 270 298 296 minecraft:glowstone
setblock 270 298 298 minecraft:glowstone
setblock 270 298 300 minecraft:glowstone
setblock 271 298 291 minecraft:glowstone
setblock 271 298 293 minecraft:glowstone
setblock 271 298 295 minecraft:glowstone
setblock 271 298 297 minecraft:glowstone
setblock 271 298 299 minecraft:glowstone
setblock 272 298 290 minecraft:glowstone
setblock 272 298 292 minecraft:glowstone
setblock 272 298 294 minecraft:glowstone
setblock 272 298 296 minecraft:glowstone
setblock 272 298 298 minecraft:glowstone
setblock 272 298 300 minecraft:glowstone
setblock 273 298 291 minecraft:glowstone
setblock 273 298 293 minecraft:glowstone
setblock 273 298 295 minecraft:glowstone
setblock 273 298 297 minecraft:glowstone
setblock 273 298 299 minecraft:glowstone
setblock 274 298 290 minecraft:glowstone
setblock 274 298 292 minecraft:glowstone
setblock 274 298 294 minecraft:glowstone
setblock 274 298 296 minecraft:glowstone
setblock 274 298 298 minecraft:glowstone
setblock 274 298 300 minecraft:glowstone
setblock 275 298 291 minecraft:glowstone
setblock 275 298 293 minecraft:glowstone
setblock 275 298 295 minecraft:glowstone
setblock 275 298 297 minecraft:glowstone
setblock 275 298 299 minecraft:glowstone
setblock 276 298 290 minecraft:glowstone
setblock 276 298 292 minecraft:glowstone
setblock 276 298 294 minecraft:glowstone
setblock 276 298 296 minecraft:glowstone
setblock 276 298 298 minecraft:glowstone
setblock 276 298 300 minecraft:glowstone
fill 277 298 295 277 308 295 minecraft:smooth_sandstone
fill 236 299 276 236 300 276 minecraft:cut_sandstone
fill 236 299 278 236 300 278 minecraft:cut_sandstone
fill 236 299 280 236 300 280 minecraft:cut_sandstone
fill 236 299 282 236 300 282 minecraft:cut_sandstone
fill 237 299 275 237 308 275 minecraft:smooth_sandstone
fill 237 299 277 237 300 277 minecraft:cut_sandstone
fill 237 299 279 237 300 279 minecraft:cut_sandstone
fill 237 299 281 237 300 281 minecraft:cut_sandstone
fill 237 299 283 237 300 283 minecraft:cut_sandstone
fill 238 299 276 238 300 276 minecraft:cut_sandstone
fill 238 299 278 238 300 278 minecraft:cut_sandstone
fill 238 299 280 238 300 280 minecraft:cut_sandstone
fill 238 299 282 238 300 282 minecraft:cut_sandstone
fill 239 299 275 239 308 275 minecraft:smooth_sandstone
fill 239 299 277 239 300 277 minecraft:cut_sandstone
fill 239 299 279 239 300 279 minecraft:cut_sandstone
fill 239 299 281 239 300 281 minecraft:cut_sandstone
fill 239 299 283 239 300 283 minecraft:cut_sandstone
fill 239 299 310 239 299 313 minecraft:chiseled_sandstone
fill 240 299 276 240 300 276 minecraft:cut_sandstone
fill 240 299 278 240 300 278 minecraft:cut_sandstone
fill 240 299 280 240 300 280 minecraft:cut_sandstone
fill 240 299 282 240 300 282 minecraft:cut_sandstone
fill 240 299 309 242 299 309 minecraft:chiseled_sandstone
setblock 240 299 313 minecraft:chiseled_sandstone
fill 241 299 275 241 308 275 minecraft:smooth_sandstone
fill 241 299 277 241 300 277 minecraft:cut_sandstone
fill 241 299 279 241 300 279 minecraft:cut_sandstone
fill 241 299 281 241 300 281 minecraft:cut_sandstone
fill 241 299 283 241 300 283 minecraft:cut_sandstone
fill 242 299 276 242 300 276 minecraft:cut_sandstone
fill 242 299 278 242 300 278 minecraft:cut_sandstone
fill 242 299 280 242 300 280 minecraft:cut_sandstone
fill 242 299 282 242 300 282 minecraft:cut_sandstone
setblock 242 299 313 minecraft:chiseled_sandstone
fill 243 299 275 243 308 275 minecraft:smooth_sandstone
fill 243 299 277 243 300 277 minecraft:cut_sandstone
fill 243 299 279 243 300 279 minecraft:cut_sandstone
fill 243 299 281 243 300 281 minecraft:cut_sandstone
fill 243 299 283 243 300 283 minecraft:cut_sandstone
fill 243 299 310 243 299 312 minecraft:chiseled_sandstone
fill 244 299 276 244 300 276 minecraft:cut_sandstone
fill 244 299 278 244 300 278 minecraft:cut_sandstone
fill 244 299 280 244 300 280 minecraft:cut_sandstone
fill 244 299 282 244 300 282 minecraft:cut_sandstone
fill 250 299 275 250 308 275 minecraft:smooth_sandstone
setblock 259 299 275 minecraft:blue_terracotta
fill 263 299 317 263 308 317 minecraft:smooth_sandstone
setblock 270 299 290 minecraft:cut_sandstone
setblock 270 299 292 minecraft:cut_sandstone
setblock 270 299 294 minecraft:cut_sandstone
setblock 270 299 296 minecraft:cut_sandstone
setblock 270 299 298 minecraft:cut_sandstone
setblock 270 299 300 minecraft:cut_sandstone
setblock 271 299 291 minecraft:cut_sandstone
setblock 271 299 293 minecraft:cut_sandstone
setblock 271 299 295 minecraft:cut_sandstone
setblock 271 299 297 minecraft:cut_sandstone
setblock 271 299 299 minecraft:cut_sandstone
setblock 272 299 290 minecraft:cut_sandstone
setblock 272 299 292 minecraft:cut_sandstone
setblock 272 299 294 minecraft:cut_sandstone
setblock 272 299 296 minecraft:cut_sandstone
setblock 272 299 298 minecraft:cut_sandstone
setblock 272 299 300 minecraft:cut_sandstone
setblock 273 299 291 minecraft:cut_sandstone
setblock 273 299 293 minecraft:cut_sandstone
setblock 273 299 295 minecraft:cut_sandstone
setblock 273 299 297 minecraft:cut_sandstone
setblock 273 299 299 minecraft:cut_sandstone
setblock 274 299 290 minecraft:cut_sandstone
setblock 274 299 292 minecraft:cut_sandstone
setblock 274 299 294 minecraft:cut_sandstone
setblock 274 299 296 minecraft:cut_sandstone
setblock 274 299 298 minecraft:cut_sandstone
setblock 274 299 300 minecraft:cut_sandstone
setblock 275 299 291 minecraft:cut_sandstone
setblock 275 299 293 minecraft:cut_sandstone
setblock 275 299 295 minecraft:cut_sandstone
fill 275 299 297 275 300 297 minecraft:cut_sandstone
fill 275 299 299 275 300 299 minecraft:cut_sandstone
setblock 276 299 290 minecraft:cut_sandstone
setblock 276 299 292 minecraft:cut_sandstone
setblock 276 299 294 minecraft:cut_sandstone
fill 276 299 296 276 300 296 minecraft:cut_sandstone
fill 276 299 298 276 300 298 minecraft:cut_sandstone
setblock 276 299 300 minecraft:cut_sandstone
fill 237 300 285 237 300 287 minecraft:cut_sandstone
fill 237 300 297 237 300 299 minecraft:cut_sandstone
fill 237 300 309 237 300 311 minecraft:cut_sandstone
setblock 238 300 275 minecraft:blue_terracotta
fill 239 300 310 239 300 312 minecraft:lapis_block
fill 240 300 309 241 300 309 minecraft:lapis_block
setblock 240 300 313 minecraft:lapis_block
setblock 241 300 317 minecraft:orange_terracotta
setblock 242 300 313 minecraft:lapis_block
fill 243 300 311 243 300 312 minecraft:lapis_block
fill 243 300 315 245 300 315 minecraft:cut_sandstone
fill 247 300 277 249 300 277 minecraft:cut_sandstone
fill 255 300 315 257 300 315 minecraft:cut_sandstone
setblock 258 300 317 minecraft:lapis_block
fill 259 300 275 259 308 275 minecraft:smooth_sandstone
fill 259 300 277 261 300 277 minecraft:cut_sandstone
fill 267 300 315 269 300 315 minecraft:cut_sandstone
setblock 267 300 317 minecraft:black_terracotta
fill 271 300 277 273 300 277 minecraft:cut_sandstone
fill 271 300 291 274 300 299 minecraft:lapis_block
setblock 272 300 275 minecraft:blue_terracotta
setblock 275 300 275 minecraft:black_terracotta
fill 275 300 285 275 300 287 minecraft:cut_sandstone
fill 275 300 291 275 300 296 minecraft:lapis_block
fill 275 300 309 275 300 311 minecraft:cut_sandstone
fill 238 301 275 238 308 275 minecraft:smooth_sandstone
fill 241 301 317 241 308 317 minecraft:smooth_sandstone
fill 258 301 317 258 308 317 minecraft:smooth_sandstone
fill 267 301 317 267 308 317 minecraft:smooth_sandstone
fill 272 301 275 272 308 275 minecraft:smooth_sandstone
fill 275 301 275 275 308 275 minecraft:smooth_sandstone
setblock 242 302 275 minecraft:blue_terracotta
setblock 251 302 275 minecraft:lapis_block
setblock 277 302 287 minecraft:orange_terracotta
fill 235 303 282 235 308 282 minecraft:smooth_sandstone
setblock 235 303 283 minecraft:black_terracotta
setblock 238 303 278 minecraft:light[level=15]
setblock 238 303 285 minecraft:light[level=12]
setblock 238 303 286 minecraft:light[level=15]
setblock 238 303 292 minecraft:light[level=12]
setblock 238 303 294 minecraft:light[level=15]
setblock 238 303 299 minecraft:light[level=12]
setblock 238 303 302 minecraft:light[level=15]
setblock 238 303 306 minecraft:light[level=12]
setblock 238 303 310 minecraft:light[level=15]
setblock 238 303 313 minecraft:light[level=12]
fill 242 303 275 242 308 275 minecraft:smooth_sandstone
setblock 245 303 278 minecraft:light[level=12]
setblock 245 303 285 minecraft:light[level=12]
setblock 245 303 292 minecraft:light[level=12]
setblock 245 303 299 minecraft:light[level=12]
setblock 245 303 306 minecraft:light[level=12]
setblock 245 303 313 minecraft:light[level=12]
setblock 246 303 278 minecraft:light[level=15]
setblock 246 303 286 minecraft:light[level=15]
setblock 246 303 294 minecraft:light[level=15]
setblock 246 303 302 minecraft:light[level=15]
setblock 246 303 310 minecraft:light[level=15]
fill 251 303 275 251 308 275 minecraft:smooth_sandstone
setblock 252 303 278 minecraft:light[level=12]
setblock 252 303 285 minecraft:light[level=12]
setblock 252 303 292 minecraft:light[level=12]
setblock 252 303 299 minecraft:light[level=12]
setblock 252 303 306 minecraft:light[level=12]
setblock 252 303 313 minecraft:light[level=12]
setblock 254 303 278 minecraft:light[level=15]
setblock 254 303 286 minecraft:light[level=15]
setblock 254 303 294 minecraft:light[level=15]
setblock 254 303 302 minecraft:light[level=15]
setblock 254 303 310 minecraft:light[level=15]
setblock 259 303 278 minecraft:light[level=12]
setblock 259 303 285 minecraft:light[level=12]
setblock 259 303 292 minecraft:light[level=12]
setblock 259 303 299 minecraft:light[level=12]
setblock 259 303 306 minecraft:light[level=12]
setblock 259 303 313 minecraft:light[level=12]
setblock 262 303 278 minecraft:light[level=15]
setblock 262 303 286 minecraft:light[level=15]
setblock 262 303 294 minecraft:light[level=15]
setblock 262 303 302 minecraft:light[level=15]
setblock 262 303 310 minecraft:light[level=15]
setblock 266 303 278 minecraft:light[level=12]
setblock 266 303 285 minecraft:light[level=12]
setblock 266 303 292 minecraft:light[level=12]
setblock 266 303 299 minecraft:light[level=12]
setblock 266 303 306 minecraft:light[level=12]
setblock 266 303 313 minecraft:light[level=12]
fill 267 303 275 267 308 275 minecraft:smooth_sandstone
setblock 268 303 275 minecraft:lapis_block
setblock 270 303 278 minecraft:light[level=15]
setblock 270 303 286 minecraft:light[level=15]
setblock 270 303 294 minecraft:light[level=15]
setblock 270 303 302 minecraft:light[level=15]
setblock 270 303 310 minecraft:light[level=15]
setblock 273 303 278 minecraft:light[level=12]
setblock 273 303 285 minecraft:light[level=12]
setblock 273 303 292 minecraft:light[level=12]
setblock 273 303 299 minecraft:light[level=12]
setblock 273 303 306 minecraft:light[level=12]
setblock 273 303 313 minecraft:light[level=12]
fill 277 303 287 277 308 287 minecraft:smooth_sandstone
fill 235 304 283 235 308 283 minecraft:smooth_sandstone
fill 268 304 275 268 308 275 minecraft:smooth_sandstone
fill 235 306 294 235 308 294 minecraft:smooth_sandstone
setblock 235 306 295 minecraft:orange_terracotta
setblock 277 306 303 minecraft:blue_terracotta
setblock 235 307 292 minecraft:black_terracotta
fill 235 307 295 235 308 295 minecraft:smooth_sandstone
fill 255 307 275 255 308 275 minecraft:smooth_sandstone
setblock 256 307 275 minecraft:blue_terracotta
setblock 277 307 298 minecraft:orange_terracotta
fill 277 307 303 277 308 303 minecraft:smooth_sandstone
setblock 235 308 292 minecraft:smooth_sandstone
setblock 256 308 275 minecraft:smooth_sandstone
setblock 277 308 298 minecraft:smooth_sandstone
