fill 236 120 477 236 123 477 minecraft:brown_terracotta
setblock 236 120 480 minecraft:brown_terracotta
setblock 236 120 481 minecraft:bone_block
fill 236 120 482 236 122 483 minecraft:brown_terracotta
fill 236 120 499 236 120 500 minecraft:brown_terracotta
setblock 236 120 501 minecraft:bone_block
fill 236 120 502 236 123 502 minecraft:brown_terracotta
setblock 237 120 464 minecraft:brown_terracotta
setblock 237 120 476 minecraft:brown_terracotta
setblock 237 120 479 minecraft:brown_terracotta
setblock 237 120 480 minecraft:bone_block
setblock 237 120 504 minecraft:brown_terracotta
setblock 238 120 464 minecraft:bone_block
setblock 238 120 466 minecraft:light[level=12]
setblock 238 120 474 minecraft:light[level=12]
setblock 238 120 482 minecraft:light[level=12]
setblock 238 120 490 minecraft:light[level=12]
setblock 238 120 498 minecraft:light[level=12]
setblock 238 120 503 minecraft:brown_terracotta
setblock 238 120 504 minecraft:bone_block
fill 239 120 464 239 122 465 minecraft:brown_terracotta
setblock 239 120 503 minecraft:bone_block
fill 239 120 504 239 123 504 minecraft:brown_terracotta
fill 240 120 465 241 120 465 minecraft:brown_terracotta
setblock 240 120 502 minecraft:bone_block
fill 240 120 503 240 123 503 minecraft:brown_terracotta
fill 241 120 502 244 120 502 minecraft:brown_terracotta
setblock 242 120 465 minecraft:bone_block
setblock 243 120 464 minecraft:bone_block
fill 243 120 465 243 123 465 minecraft:brown_terracotta
fill 243 120 501 245 120 501 minecraft:brown_terracotta
setblock 243 120 504 minecraft:bone_block
fill 244 120 464 244 123 464 minecraft:brown_terracotta
setblock 244 120 503 minecraft:bone_block
fill 244 120 504 244 123 504 minecraft:brown_terracotta
setblock 245 120 466 minecraft:brown_terracotta
setblock 245 120 502 minecraft:bone_block
fill 245 120 503 245 123 503 minecraft:brown_terracotta
setblock 246 120 466 minecraft:light[level=12]
setblock 246 120 474 minecraft:light[level=12]
setblock 246 120 482 minecraft:light[level=12]
setblock 246 120 490 minecraft:light[level=12]
setblock 246 120 498 minecraft:light[level=12]
setblock 246 120 501 minecraft:bone_block
fill 246 120 502 246 123 502 minecraft:brown_terracotta
setblock 247 120 465 minecraft:bone_block
fill 247 120 501 247 123 501 minecraft:brown_terracotta
setblock 248 120 464 minecraft:bone_block
fill 248 120 465 248 123 465 minecraft:brown_terracotta
setblock 248 120 504 minecraft:bone_block
fill 249 120 464 249 123 464 minecraft:brown_terracotta
setblock 249 120 503 minecraft:bone_block
fill 249 120 504 249 123 504 minecraft:brown_terracotta
setblock 250 120 502 minecraft:bone_block
fill 250 120 503 250 123 503 minecraft:brown_terracotta
setblock 251 120 501 minecraft:bone_block
fill 251 120 502 251 123 502 minecraft:brown_terracotta
setblock 253 120 504 minecraft:bone_block
setblock 254 120 466 minecraft:light[level=12]
setblock 254 120 474 minecraft:light[level=12]
setblock 254 120 482 minecraft:light[level=12]
setblock 254 120 490 minecraft:light[level=12]
setblock 254 120 498 minecraft:light[level=12]
setblock 254 120 502 minecraft:brown_terracotta
setblock 254 120 503 minecraft:bone_block
fill 254 120 504 257 120 504 minecraft:brown_terracotta
fill 255 120 503 258 120 503 minecraft:brown_terracotta
fill 258 120 499 258 121 499 minecraft:bone_block
setblock 258 120 504 minecraft:bone_block
setblock 259 120 503 minecraft:bone_block
fill 259 120 504 259 123 504 minecraft:brown_terracotta
setblock 260 120 502 minecraft:bone_block
fill 260 120 503 263 120 503 minecraft:brown_terracotta
fill 261 120 502 264 120 502 minecraft:brown_terracotta
setblock 262 120 464 minecraft:brown_terracotta
setblock 262 120 466 minecraft:light[level=12]
setblock 262 120 474 minecraft:light[level=12]
setblock 262 120 482 minecraft:light[level=12]
setblock 262 120 490 minecraft:light[level=12]
setblock 262 120 498 minecraft:light[level=12]
setblock 263 120 464 minecraft:bone_block
setblock 263 120 504 minecraft:bone_block
fill 264 120 464 267 120 464 minecraft:brown_terracotta
setblock 264 120 503 minecraft:bone_block
fill 264 120 504 264 123 504 minecraft:brown_terracotta
setblock 265 120 502 minecraft:bone_block
fill 265 120 503 265 123 503 minecraft:brown_terracotta
fill 266 120 502 266 123 502 minecraft:brown_terracotta
setblock 268 120 464 minecraft:bone_block
setblock 268 120 503 minecraft:brown_terracotta
setblock 268 120 504 minecraft:bone_block
fill 269 120 464 271 121 464 minecraft:brown_terracotta
setblock 269 120 503 minecraft:bone_block
fill 269 120 504 269 123 504 minecraft:brown_terracotta
setblock 270 120 466 minecraft:light[level=12]
setblock 270 120 474 minecraft:light[level=12]
setblock 270 120 482 minecraft:light[level=12]
setblock 270 120 490 minecraft:light[level=12]
setblock 270 120 498 minecraft:light[level=12]
fill 270 120 503 270 122 503 minecraft:brown_terracotta
setblock 274 120 478 minecraft:bone_block
fill 274 120 479 274 122 479 minecraft:brown_terracotta
fill 274 120 481 274 121 481 minecraft:brown_terracotta
setblock 275 120 477 minecraft:bone_block
fill 275 120 478 275 123 478 minecraft:brown_terracotta
setblock 275 120 482 minecraft:bone_block
fill 275 120 483 275 123 483 minecraft:brown_terracotta
fill 276 120 472 276 123 472 minecraft:brown_terracotta
setblock 276 120 476 minecraft:bone_block
fill 276 120 477 276 123 477 minecraft:brown_terracotta
setblock 276 120 481 minecraft:bone_block
fill 276 120 482 276 123 482 minecraft:brown_terracotta
setblock 236 121 464 minecraft:brown_terracotta
setblock 236 121 465 minecraft:bone_block
fill 236 121 466 236 124 466 minecraft:brown_terracotta
fill 236 121 468 236 121 469 minecraft:brown_terracotta
setblock 236 121 470 minecraft:bone_block
fill 236 121 471 236 123 471 minecraft:brown_terracotta
setblock 236 121 475 minecraft:bone_block
fill 236 121 476 236 124 476 minecraft:brown_terracotta
setblock 236 121 480 minecraft:bone_block
fill 236 121 481 236 124 481 minecraft:brown_terracotta
setblock 236 121 484 minecraft:brown_terracotta
setblock 236 121 499 minecraft:brown_terracotta
setblock 236 121 500 minecraft:bone_block
fill 236 121 501 237 123 501 minecraft:brown_terracotta
setblock 237 121 464 minecraft:bone_block
fill 237 121 465 238 123 465 minecraft:brown_terracotta
setblock 237 121 479 minecraft:bone_block
fill 237 121 480 237 123 480 minecraft:brown_terracotta
fill 237 121 502 237 121 503 minecraft:brown_terracotta
setblock 237 121 504 minecraft:bone_block
fill 238 121 464 238 124 464 minecraft:brown_terracotta
setblock 238 121 503 minecraft:bone_block
fill 238 121 504 238 124 504 minecraft:brown_terracotta
setblock 239 121 502 minecraft:bone_block
fill 239 121 503 239 124 503 minecraft:brown_terracotta
setblock 240 121 465 minecraft:brown_terracotta
fill 240 121 502 243 121 502 minecraft:brown_terracotta
setblock 241 121 465 minecraft:bone_block
setblock 242 121 464 minecraft:bone_block
fill 242 121 465 242 123 466 minecraft:brown_terracotta
fill 242 121 501 244 121 501 minecraft:brown_terracotta
setblock 242 121 504 minecraft:bone_block
fill 243 121 464 243 124 464 minecraft:brown_terracotta
fill 243 121 466 244 121 466 minecraft:brown_terracotta
setblock 243 121 503 minecraft:bone_block
fill 243 121 504 243 124 504 minecraft:brown_terracotta
setblock 244 121 502 minecraft:bone_block
fill 244 121 503 244 124 503 minecraft:brown_terracotta
setblock 245 121 466 minecraft:bone_block
setblock 245 121 501 minecraft:bone_block
fill 245 121 502 245 124 502 minecraft:brown_terracotta
setblock 246 121 465 minecraft:bone_block
fill 246 121 466 246 124 466 minecraft:brown_terracotta
fill 246 121 501 246 124 501 minecraft:brown_terracotta
setblock 247 121 464 minecraft:bone_block
fill 247 121 465 247 124 465 minecraft:brown_terracotta
setblock 247 121 504 minecraft:bone_block
fill 248 121 464 248 124 464 minecraft:brown_terracotta
setblock 248 121 503 minecraft:bone_block
fill 248 121 504 248 124 504 minecraft:brown_terracotta
setblock 249 121 501 minecraft:brown_terracotta
setblock 249 121 502 minecraft:bone_block
fill 249 121 503 249 124 503 minecraft:brown_terracotta
setblock 250 121 501 minecraft:bone_block
fill 250 121 502 250 124 502 minecraft:brown_terracotta
setblock 251 121 464 minecraft:brown_terracotta
setblock 252 121 464 minecraft:bone_block
setblock 252 121 504 minecraft:bone_block
fill 253 121 464 253 124 464 minecraft:brown_terracotta
setblock 253 121 503 minecraft:bone_block
fill 253 121 504 256 121 504 minecraft:brown_terracotta
setblock 254 121 502 minecraft:bone_block
fill 254 121 503 257 121 503 minecraft:brown_terracotta
setblock 257 121 504 minecraft:bone_block
setblock 258 121 502 minecraft:brown_terracotta
setblock 258 121 503 minecraft:bone_block
fill 258 121 504 258 124 504 minecraft:brown_terracotta
fill 259 121 499 260 122 499 minecraft:bone_block
setblock 259 121 502 minecraft:bone_block
fill 259 121 503 262 121 503 minecraft:brown_terracotta
fill 260 121 464 261 121 464 minecraft:brown_terracotta
fill 260 121 502 263 121 502 minecraft:brown_terracotta
setblock 262 121 464 minecraft:bone_block
setblock 262 121 504 minecraft:bone_block
fill 263 121 464 266 121 464 minecraft:brown_terracotta
fill 263 121 501 264 121 501 minecraft:brown_terracotta
setblock 263 121 503 minecraft:bone_block
fill 263 121 504 263 124 504 minecraft:brown_terracotta
setblock 264 121 502 minecraft:bone_block
fill 264 121 503 264 124 503 minecraft:brown_terracotta
fill 265 121 502 265 124 502 minecraft:brown_terracotta
setblock 267 121 464 minecraft:bone_block
setblock 267 121 504 minecraft:bone_block
fill 268 121 464 268 124 464 minecraft:brown_terracotta
setblock 268 121 503 minecraft:bone_block
fill 268 121 504 268 124 504 minecraft:brown_terracotta
fill 269 121 503 269 123 503 minecraft:brown_terracotta
setblock 272 121 464 minecraft:bone_block
setblock 272 121 504 minecraft:bone_block
fill 273 121 504 273 123 504 minecraft:brown_terracotta
setblock 274 121 478 minecraft:brown_terracotta
setblock 274 121 482 minecraft:bone_block
setblock 275 121 476 minecraft:bone_block
fill 275 121 477 275 123 477 minecraft:brown_terracotta
setblock 275 121 481 minecraft:bone_block
fill 275 121 482 275 124 482 minecraft:brown_terracotta
fill 275 121 484 275 122 484 minecraft:brown_terracotta
setblock 276 121 464 minecraft:brown_terracotta
setblock 276 121 475 minecraft:bone_block
fill 276 121 476 276 124 476 minecraft:brown_terracotta
setblock 276 121 480 minecraft:bone_block
fill 276 121 481 276 124 481 minecraft:brown_terracotta
setblock 276 121 485 minecraft:bone_block
fill 276 121 486 276 124 486 minecraft:brown_terracotta
fill 276 121 502 276 122 503 minecraft:brown_terracotta
setblock 236 122 464 minecraft:bone_block
fill 236 122 465 236 125 465 minecraft:brown_terracotta
setblock 236 122 468 minecraft:brown_terracotta
setblock 236 122 469 minecraft:bone_block
fill 236 122 470 236 125 470 minecraft:brown_terracotta
setblock 236 122 474 minecraft:bone_block
fill 236 122 475 236 123 475 minecraft:brown_terracotta
setblock 236 122 478 minecraft:brown_terracotta
setblock 236 122 479 minecraft:bone_block
fill 236 122 480 236 125 480 minecraft:brown_terracotta
setblock 236 122 484 minecraft:bone_block
setblock 236 122 499 minecraft:bone_block
fill 236 122 500 236 125 500 minecraft:brown_terracotta
setblock 236 122 503 minecraft:brown_terracotta
setblock 236 122 504 minecraft:bone_block
fill 237 122 464 237 125 464 minecraft:brown_terracotta
fill 237 122 466 237 123 466 minecraft:brown_terracotta
setblock 237 122 478 minecraft:bone_block
fill 237 122 479 237 123 479 minecraft:brown_terracotta
fill 237 122 481 237 123 481 minecraft:brown_terracotta
setblock 237 122 502 minecraft:brown_terracotta
setblock 237 122 503 minecraft:bone_block
fill 237 122 504 237 125 504 minecraft:brown_terracotta
fill 238 122 503 238 125 503 minecraft:brown_terracotta
fill 239 122 502 242 122 502 minecraft:brown_terracotta
setblock 240 122 465 minecraft:bone_block
setblock 241 122 464 minecraft:bone_block
fill 241 122 465 241 124 466 minecraft:brown_terracotta
fill 241 122 501 243 122 501 minecraft:brown_terracotta
setblock 241 122 504 minecraft:bone_block
fill 242 122 464 242 125 464 minecraft:brown_terracotta
setblock 242 122 503 minecraft:bone_block
fill 242 122 504 242 125 504 minecraft:brown_terracotta
setblock 243 122 466 minecraft:brown_terracotta
setblock 243 122 502 minecraft:bone_block
fill 243 122 503 243 125 503 minecraft:brown_terracotta
setblock 244 122 466 minecraft:bone_block
setblock 244 122 501 minecraft:bone_block
fill 244 122 502 244 125 502 minecraft:brown_terracotta
setblock 245 122 465 minecraft:bone_block
fill 245 122 466 245 125 466 minecraft:brown_terracotta
fill 245 122 501 245 125 501 minecraft:brown_terracotta
setblock 246 122 464 minecraft:bone_block
fill 246 122 465 246 125 465 minecraft:brown_terracotta
setblock 246 122 504 minecraft:bone_block
fill 247 122 464 247 125 464 minecraft:brown_terracotta
setblock 247 122 503 minecraft:bone_block
fill 247 122 504 247 125 504 minecraft:brown_terracotta
setblock 248 122 502 minecraft:bone_block
fill 248 122 503 248 125 503 minecraft:brown_terracotta
setblock 249 122 501 minecraft:bone_block
fill 249 122 502 249 125 502 minecraft:brown_terracotta
setblock 250 122 501 minecraft:brown_terracotta
setblock 251 122 464 minecraft:bone_block
setblock 251 122 504 minecraft:bone_block
fill 252 122 464 252 125 464 minecraft:brown_terracotta
setblock 252 122 503 minecraft:bone_block
fill 252 122 504 255 122 504 minecraft:brown_terracotta
setblock 253 122 502 minecraft:bone_block
fill 253 122 503 256 122 503 minecraft:brown_terracotta
setblock 254 122 502 minecraft:brown_terracotta
setblock 256 122 504 minecraft:bone_block
setblock 257 122 502 minecraft:brown_terracotta
setblock 257 122 503 minecraft:bone_block
fill 257 122 504 257 125 504 minecraft:brown_terracotta
setblock 258 122 502 minecraft:bone_block
fill 258 122 503 261 122 503 minecraft:brown_terracotta
fill 259 122 464 260 122 464 minecraft:brown_terracotta
fill 259 122 502 262 122 502 minecraft:brown_terracotta
fill 260 122 498 262 123 498 minecraft:bone_block
fill 260 122 500 262 123 500 minecraft:bone_block
setblock 261 122 464 minecraft:bone_block
fill 261 122 499 261 123 499 minecraft:bone_block
setblock 261 122 504 minecraft:bone_block
fill 262 122 464 265 122 464 minecraft:brown_terracotta
setblock 262 122 503 minecraft:bone_block
fill 262 122 504 262 125 504 minecraft:brown_terracotta
setblock 263 122 502 minecraft:bone_block
fill 263 122 503 263 125 503 minecraft:brown_terracotta
setblock 264 122 465 minecraft:brown_terracotta
fill 264 122 502 264 124 502 minecraft:brown_terracotta
setblock 265 122 465 minecraft:bone_block
setblock 266 122 464 minecraft:bone_block
fill 266 122 465 267 124 465 minecraft:brown_terracotta
setblock 266 122 504 minecraft:bone_block
fill 267 122 464 267 125 464 minecraft:brown_terracotta
setblock 267 122 502 minecraft:brown_terracotta
setblock 267 122 503 minecraft:bone_block
fill 267 122 504 267 125 504 minecraft:brown_terracotta
fill 268 122 503 268 124 503 minecraft:brown_terracotta
fill 269 122 464 270 122 464 minecraft:brown_terracotta
fill 269 122 476 273 123 480 minecraft:soul_soil
setblock 271 122 464 minecraft:bone_block
setblock 271 122 504 minecraft:bone_block
fill 272 122 464 275 122 464 minecraft:brown_terracotta
fill 272 122 504 272 124 504 minecraft:brown_terracotta
setblock 274 122 478 minecraft:soul_soil
setblock 274 122 481 minecraft:bone_block
setblock 274 122 482 minecraft:brown_terracotta
fill 274 122 504 275 122 504 minecraft:brown_terracotta
setblock 275 122 476 minecraft:brown_terracotta
setblock 275 122 480 minecraft:bone_block
fill 275 122 481 275 125 481 minecraft:brown_terracotta
setblock 276 122 464 minecraft:bone_block
fill 276 122 465 276 124 466 minecraft:brown_terracotta
setblock 276 122 474 minecraft:bone_block
fill 276 122 475 276 125 475 minecraft:brown_terracotta
setblock 276 122 479 minecraft:bone_block
fill 276 122 480 276 125 480 minecraft:brown_terracotta
setblock 276 122 484 minecraft:bone_block
fill 276 122 485 276 125 485 minecraft:brown_terracotta
fill 276 122 487 276 123 487 minecraft:brown_terracotta
setblock 276 122 504 minecraft:bone_block
fill 236 123 464 236 126 464 minecraft:brown_terracotta
setblock 236 123 468 minecraft:bone_block
fill 236 123 469 236 126 469 minecraft:brown_terracotta
setblock 236 123 473 minecraft:bone_block
setblock 236 123 474 minecraft:brown_terracotta
setblock 236 123 478 minecraft:bone_block
fill 236 123 479 236 125 479 minecraft:brown_terracotta
setblock 236 123 482 minecraft:brown_terracotta
setblock 236 123 483 minecraft:bone_block
fill 236 123 484 236 125 485 minecraft:brown_terracotta
setblock 236 123 499 minecraft:brown_terracotta
setblock 236 123 503 minecraft:bone_block
fill 236 123 504 236 126 504 minecraft:brown_terracotta
setblock 237 123 467 minecraft:bone_block
setblock 237 123 502 minecraft:bone_block
fill 237 123 503 237 126 503 minecraft:brown_terracotta
fill 238 123 502 241 123 502 minecraft:brown_terracotta
setblock 239 123 464 minecraft:brown_terracotta
setblock 239 123 465 minecraft:bone_block
fill 239 123 466 240 125 466 minecraft:brown_terracotta
setblock 240 123 464 minecraft:bone_block
fill 240 123 465 240 126 465 minecraft:brown_terracotta
setblock 240 123 504 minecraft:bone_block
fill 241 123 464 241 126 464 minecraft:brown_terracotta
fill 241 123 501 242 123 501 minecraft:brown_terracotta
setblock 241 123 503 minecraft:bone_block
fill 241 123 504 241 126 504 minecraft:brown_terracotta
setblock 242 123 502 minecraft:bone_block
fill 242 123 503 242 126 503 minecraft:brown_terracotta
setblock 243 123 466 minecraft:bone_block
setblock 243 123 501 minecraft:bone_block
fill 243 123 502 243 126 502 minecraft:brown_terracotta
setblock 244 123 465 minecraft:bone_block
fill 244 123 466 244 126 466 minecraft:brown_terracotta
fill 244 123 501 244 125 501 minecraft:brown_terracotta
setblock 245 123 464 minecraft:bone_block
fill 245 123 465 245 126 465 minecraft:brown_terracotta
setblock 245 123 504 minecraft:bone_block
fill 246 123 464 246 126 464 minecraft:brown_terracotta
setblock 246 123 503 minecraft:bone_block
fill 246 123 504 246 126 504 minecraft:brown_terracotta
setblock 247 123 502 minecraft:bone_block
fill 247 123 503 247 126 503 minecraft:brown_terracotta
setblock 248 123 501 minecraft:bone_block
fill 248 123 502 248 125 502 minecraft:brown_terracotta
setblock 249 123 465 minecraft:bone_block
setblock 249 123 501 minecraft:brown_terracotta
setblock 250 123 464 minecraft:bone_block
setblock 250 123 504 minecraft:bone_block
fill 251 123 464 251 126 464 minecraft:brown_terracotta
setblock 251 123 503 minecraft:bone_block
fill 251 123 504 254 123 504 minecraft:brown_terracotta
setblock 252 123 502 minecraft:bone_block
fill 252 123 503 255 123 503 minecraft:brown_terracotta
setblock 255 123 504 minecraft:bone_block
setblock 256 123 503 minecraft:bone_block
fill 256 123 504 256 126 504 minecraft:brown_terracotta
fill 257 123 464 259 123 464 minecraft:brown_terracotta
fill 257 123 503 260 123 503 minecraft:brown_terracotta
fill 258 123 502 261 123 502 minecraft:brown_terracotta
setblock 260 123 464 minecraft:bone_block
setblock 260 123 504 minecraft:bone_block
fill 261 123 464 264 123 464 minecraft:brown_terracotta
setblock 261 123 503 minecraft:bone_block
fill 261 123 504 261 126 504 minecraft:brown_terracotta
fill 262 123 465 263 123 465 minecraft:brown_terracotta
setblock 262 123 502 minecraft:bone_block
fill 262 123 503 262 126 503 minecraft:brown_terracotta
fill 263 123 502 263 125 502 minecraft:brown_terracotta
setblock 264 123 465 minecraft:bone_block
setblock 265 123 464 minecraft:bone_block
fill 265 123 465 265 126 465 minecraft:brown_terracotta
setblock 265 123 504 minecraft:bone_block
fill 266 123 464 266 126 464 minecraft:brown_terracotta
setblock 266 123 503 minecraft:bone_block
fill 266 123 504 266 126 504 minecraft:brown_terracotta
setblock 267 123 502 minecraft:bone_block
fill 267 123 503 267 125 503 minecraft:brown_terracotta
setblock 269 123 464 minecraft:brown_terracotta
setblock 270 123 464 minecraft:bone_block
setblock 270 123 504 minecraft:bone_block
fill 271 123 464 274 123 464 minecraft:brown_terracotta
fill 271 123 504 271 124 504 minecraft:brown_terracotta
setblock 274 123 481 minecraft:brown_terracotta
setblock 274 123 504 minecraft:brown_terracotta
setblock 275 123 464 minecraft:bone_block
setblock 275 123 479 minecraft:bone_block
fill 275 123 480 275 125 480 minecraft:brown_terracotta
setblock 275 123 484 minecraft:bone_block
fill 275 123 485 275 124 485 minecraft:brown_terracotta
setblock 275 123 504 minecraft:bone_block
fill 276 123 464 276 126 464 minecraft:brown_terracotta
setblock 276 123 467 minecraft:brown_terracotta
setblock 276 123 468 minecraft:bone_block
fill 276 123 469 276 126 469 minecraft:brown_terracotta
fill 276 123 471 276 124 471 minecraft:brown_terracotta
setblock 276 123 473 minecraft:bone_block
fill 276 123 474 276 125 474 minecraft:brown_terracotta
setblock 276 123 478 minecraft:bone_block
fill 276 123 479 276 126 479 minecraft:brown_terracotta
setblock 276 123 483 minecraft:bone_block
fill 276 123 484 276 126 484 minecraft:brown_terracotta
setblock 276 123 502 minecraft:brown_terracotta
setblock 276 123 503 minecraft:bone_block
fill 276 123 504 276 126 504 minecraft:brown_terracotta
setblock 236 124 467 minecraft:bone_block
fill 236 124 468 236 127 468 minecraft:brown_terracotta
setblock 236 124 477 minecraft:bone_block
fill 236 124 478 236 125 478 minecraft:brown_terracotta
setblock 236 124 482 minecraft:bone_block
fill 236 124 483 236 127 483 minecraft:brown_terracotta
setblock 236 124 501 minecraft:brown_terracotta
setblock 236 124 502 minecraft:bone_block
fill 236 124 503 236 127 503 minecraft:brown_terracotta
setblock 237 124 465 minecraft:brown_terracotta
setblock 237 124 466 minecraft:bone_block
fill 237 124 467 237 127 467 minecraft:brown_terracotta
setblock 237 124 501 minecraft:bone_block
fill 237 124 502 240 124 502 minecraft:brown_terracotta
setblock 238 124 465 minecraft:bone_block
setblock 239 124 464 minecraft:bone_block
fill 239 124 465 239 127 465 minecraft:brown_terracotta
setblock 239 124 504 minecraft:bone_block
fill 240 124 464 240 127 464 minecraft:brown_terracotta
setblock 240 124 503 minecraft:bone_block
fill 240 124 504 240 127 504 minecraft:brown_terracotta
setblock 241 124 502 minecraft:bone_block
fill 241 124 503 241 127 503 minecraft:brown_terracotta
setblock 242 124 465 minecraft:brown_terracotta
setblock 242 124 466 minecraft:bone_block
setblock 242 124 501 minecraft:bone_block
fill 242 124 502 242 127 502 minecraft:brown_terracotta
setblock 243 124 465 minecraft:bone_block
fill 243 124 466 243 127 466 minecraft:brown_terracotta
fill 243 124 501 243 125 501 minecraft:brown_terracotta
setblock 244 124 464 minecraft:bone_block
fill 244 124 465 244 127 465 minecraft:brown_terracotta
setblock 244 124 504 minecraft:bone_block
fill 245 124 464 245 127 464 minecraft:brown_terracotta
setblock 245 124 503 minecraft:bone_block
fill 245 124 504 245 127 504 minecraft:brown_terracotta
setblock 246 124 502 minecraft:bone_block
fill 246 124 503 246 127 503 minecraft:brown_terracotta
setblock 247 124 501 minecraft:bone_block
fill 247 124 502 247 126 502 minecraft:brown_terracotta
setblock 248 124 465 minecraft:bone_block
setblock 249 124 464 minecraft:bone_block
setblock 249 124 465 minecraft:brown_terracotta
setblock 249 124 504 minecraft:bone_block
fill 250 124 464 250 127 464 minecraft:brown_terracotta
setblock 250 124 503 minecraft:bone_block
fill 250 124 504 253 124 504 minecraft:brown_terracotta
setblock 251 124 502 minecraft:bone_block
fill 251 124 503 254 124 503 minecraft:brown_terracotta
setblock 254 124 504 minecraft:bone_block
setblock 255 124 503 minecraft:bone_block
fill 255 124 504 255 127 504 minecraft:brown_terracotta
fill 256 124 464 258 124 464 minecraft:brown_terracotta
fill 256 124 503 259 124 503 minecraft:brown_terracotta
setblock 259 124 464 minecraft:bone_block
fill 259 124 502 260 124 502 minecraft:brown_terracotta
setblock 259 124 504 minecraft:bone_block
fill 260 124 464 263 124 464 minecraft:brown_terracotta
setblock 260 124 503 minecraft:bone_block
fill 260 124 504 260 127 504 minecraft:brown_terracotta
setblock 261 124 502 minecraft:bone_block
fill 261 124 503 261 127 503 minecraft:brown_terracotta
setblock 262 124 465 minecraft:brown_terracotta
fill 262 124 502 262 125 502 minecraft:brown_terracotta
setblock 263 124 465 minecraft:bone_block
setblock 264 124 464 minecraft:bone_block
fill 264 124 465 264 127 465 minecraft:brown_terracotta
setblock 264 124 504 minecraft:bone_block
fill 265 124 464 265 127 464 minecraft:brown_terracotta
setblock 265 124 503 minecraft:bone_block
fill 265 124 504 265 127 504 minecraft:brown_terracotta
fill 266 124 503 266 125 503 minecraft:brown_terracotta
fill 267 124 477 269 125 477 minecraft:bone_block
fill 267 124 479 269 125 479 minecraft:bone_block
fill 268 124 478 268 125 478 minecraft:bone_block
setblock 269 124 464 minecraft:bone_block
setblock 269 124 504 minecraft:bone_block
fill 270 124 464 273 124 464 minecraft:brown_terracotta
fill 270 124 504 270 125 504 minecraft:brown_terracotta
setblock 274 124 464 minecraft:bone_block
fill 275 124 464 275 127 464 minecraft:brown_terracotta
setblock 275 124 478 minecraft:bone_block
fill 275 124 479 275 125 479 minecraft:brown_terracotta
setblock 275 124 483 minecraft:bone_block
fill 275 124 484 275 125 484 minecraft:brown_terracotta
fill 275 124 504 275 125 504 minecraft:brown_terracotta
setblock 276 124 467 minecraft:bone_block
fill 276 124 468 276 127 468 minecraft:brown_terracotta
fill 276 124 470 276 125 470 minecraft:brown_terracotta
setblock 276 124 472 minecraft:bone_block
fill 276 124 473 276 125 473 minecraft:brown_terracotta
setblock 276 124 477 minecraft:bone_block
fill 276 124 478 276 127 478 minecraft:brown_terracotta
setblock 276 124 482 minecraft:bone_block
fill 276 124 483 276 127 483 minecraft:brown_terracotta
setblock 276 124 487 minecraft:bone_block
setblock 276 124 502 minecraft:bone_block
fill 276 124 503 276 125 503 minecraft:brown_terracotta
setblock 236 125 466 minecraft:bone_block
fill 236 125 467 236 128 467 minecraft:brown_terracotta
setblock 236 125 481 minecraft:bone_block
fill 236 125 482 236 127 482 minecraft:brown_terracotta
setblock 236 125 501 minecraft:bone_block
fill 236 125 502 237 127 502 minecraft:brown_terracotta
setblock 237 125 465 minecraft:bone_block
fill 237 125 466 238 127 466 minecraft:brown_terracotta
fill 237 125 468 237 126 468 minecraft:brown_terracotta
setblock 237 125 501 minecraft:brown_terracotta
setblock 238 125 464 minecraft:bone_block
fill 238 125 465 238 128 465 minecraft:brown_terracotta
setblock 238 125 504 minecraft:bone_block
fill 239 125 464 239 128 464 minecraft:brown_terracotta
setblock 239 125 502 minecraft:brown_terracotta
setblock 239 125 503 minecraft:bone_block
fill 239 125 504 239 128 504 minecraft:brown_terracotta
setblock 240 125 502 minecraft:bone_block
fill 240 125 503 240 128 503 minecraft:brown_terracotta
setblock 241 125 465 minecraft:brown_terracotta
setblock 241 125 466 minecraft:bone_block
fill 241 125 502 241 128 502 minecraft:brown_terracotta
setblock 242 125 465 minecraft:bone_block
fill 242 125 466 242 128 466 minecraft:brown_terracotta
setblock 242 125 501 minecraft:brown_terracotta
setblock 243 125 464 minecraft:bone_block
fill 243 125 465 243 128 465 minecraft:brown_terracotta
setblock 243 125 504 minecraft:bone_block
fill 244 125 464 244 128 464 minecraft:brown_terracotta
setblock 244 125 503 minecraft:bone_block
fill 244 125 504 244 128 504 minecraft:brown_terracotta
setblock 245 125 502 minecraft:bone_block
fill 245 125 503 245 128 503 minecraft:brown_terracotta
fill 246 125 502 246 127 502 minecraft:brown_terracotta
setblock 247 125 465 minecraft:bone_block
setblock 248 125 464 minecraft:bone_block
setblock 248 125 465 minecraft:brown_terracotta
setblock 248 125 504 minecraft:bone_block
fill 249 125 464 249 128 464 minecraft:brown_terracotta
setblock 249 125 503 minecraft:bone_block
fill 249 125 504 252 125 504 minecraft:brown_terracotta
fill 250 125 503 253 125 503 minecraft:brown_terracotta
setblock 253 125 504 minecraft:bone_block
setblock 254 125 503 minecraft:bone_block
fill 254 125 504 254 128 504 minecraft:brown_terracotta
fill 255 125 503 258 125 503 minecraft:brown_terracotta
fill 256 125 464 257 125 464 minecraft:brown_terracotta
setblock 258 125 464 minecraft:bone_block
setblock 258 125 504 minecraft:bone_block
fill 259 125 464 262 125 464 minecraft:brown_terracotta
setblock 259 125 503 minecraft:bone_block
fill 259 125 504 259 128 504 minecraft:brown_terracotta
fill 260 125 503 260 128 503 minecraft:brown_terracotta
setblock 261 125 465 minecraft:brown_terracotta
setblock 261 125 502 minecraft:brown_terracotta
setblock 262 125 465 minecraft:bone_block
setblock 263 125 464 minecraft:bone_block
fill 263 125 465 263 128 465 minecraft:brown_terracotta
setblock 263 125 504 minecraft:bone_block
fill 264 125 464 264 128 464 minecraft:brown_terracotta
setblock 264 125 503 minecraft:bone_block
fill 264 125 504 264 128 504 minecraft:brown_terracotta
fill 265 125 503 265 126 503 minecraft:brown_terracotta
setblock 266 125 465 minecraft:brown_terracotta
setblock 267 125 465 minecraft:bone_block
setblock 268 125 464 minecraft:bone_block
setblock 268 125 504 minecraft:bone_block
fill 269 125 464 272 125 464 minecraft:brown_terracotta
fill 269 125 478 270 126 478 minecraft:bone_block
setblock 269 125 504 minecraft:brown_terracotta
setblock 273 125 464 minecraft:bone_block
fill 274 125 464 274 128 464 minecraft:brown_terracotta
setblock 275 125 482 minecraft:bone_block
fill 275 125 483 275 126 483 minecraft:brown_terracotta
setblock 276 125 465 minecraft:brown_terracotta
setblock 276 125 466 minecraft:bone_block
fill 276 125 467 276 128 467 minecraft:brown_terracotta
setblock 276 125 471 minecraft:bone_block
setblock 276 125 476 minecraft:bone_block
fill 276 125 477 276 127 477 minecraft:brown_terracotta
setblock 276 125 481 minecraft:bone_block
fill 276 125 482 276 128 482 minecraft:brown_terracotta
setblock 276 125 486 minecraft:bone_block
fill 276 125 487 276 128 487 minecraft:brown_terracotta
setblock 236 126 465 minecraft:bone_block
fill 236 126 466 236 129 466 minecraft:brown_terracotta
setblock 236 126 470 minecraft:bone_block
setblock 236 126 480 minecraft:bone_block
setblock 236 126 481 minecraft:brown_terracotta
setblock 236 126 484 minecraft:brown_terracotta
setblock 236 126 485 minecraft:bone_block
fill 236 126 501 236 129 501 minecraft:brown_terracotta
setblock 237 126 464 minecraft:bone_block
fill 237 126 465 237 129 465 minecraft:brown_terracotta
setblock 237 126 504 minecraft:bone_block
fill 238 126 464 238 129 464 minecraft:brown_terracotta
setblock 238 126 503 minecraft:bone_block
fill 238 126 504 238 129 504 minecraft:brown_terracotta
setblock 239 126 466 minecraft:brown_terracotta
setblock 239 126 502 minecraft:bone_block
fill 239 126 503 239 129 503 minecraft:brown_terracotta
setblock 240 126 466 minecraft:bone_block
fill 240 126 502 240 128 502 minecraft:brown_terracotta
setblock 241 126 465 minecraft:bone_block
fill 241 126 466 241 129 466 minecraft:brown_terracotta
setblock 242 126 464 minecraft:bone_block
fill 242 126 465 242 129 465 minecraft:brown_terracotta
setblock 242 126 504 minecraft:bone_block
fill 243 126 464 243 129 464 minecraft:brown_terracotta
setblock 243 126 503 minecraft:bone_block
fill 243 126 504 243 129 504 minecraft:brown_terracotta
setblock 244 126 502 minecraft:bone_block
fill 244 126 503 244 129 503 minecraft:brown_terracotta
fill 245 126 502 245 127 502 minecraft:brown_terracotta
setblock 246 126 465 minecraft:bone_block
setblock 247 126 464 minecraft:bone_block
fill 247 126 465 247 127 465 minecraft:brown_terracotta
setblock 247 126 504 minecraft:bone_block
fill 248 126 464 248 129 464 minecraft:brown_terracotta
setblock 248 126 503 minecraft:bone_block
fill 248 126 504 251 126 504 minecraft:brown_terracotta
fill 249 126 503 251 126 503 minecraft:brown_terracotta
setblock 252 126 504 minecraft:bone_block
fill 253 126 504 253 128 504 minecraft:brown_terracotta
setblock 256 126 464 minecraft:brown_terracotta
fill 256 126 503 257 126 503 minecraft:brown_terracotta
setblock 257 126 464 minecraft:bone_block
setblock 257 126 504 minecraft:bone_block
fill 258 126 464 261 126 464 minecraft:brown_terracotta
setblock 258 126 503 minecraft:bone_block
fill 258 126 504 258 129 504 minecraft:brown_terracotta
fill 259 126 503 259 127 503 minecraft:brown_terracotta
setblock 261 126 465 minecraft:bone_block
setblock 262 126 464 minecraft:bone_block
fill 262 126 465 262 129 465 minecraft:brown_terracotta
setblock 262 126 504 minecraft:bone_block
fill 263 126 464 263 129 464 minecraft:brown_terracotta
setblock 263 126 503 minecraft:bone_block
fill 263 126 504 263 129 504 minecraft:brown_terracotta
setblock 264 126 503 minecraft:brown_terracotta
setblock 266 126 465 minecraft:bone_block
setblock 267 126 464 minecraft:bone_block
setblock 267 126 504 minecraft:bone_block
fill 268 126 464 271 126 464 minecraft:brown_terracotta
setblock 268 126 504 minecraft:brown_terracotta
fill 271 126 478 271 127 478 minecraft:bone_block
setblock 272 126 464 minecraft:bone_block
fill 273 126 464 273 129 464 minecraft:brown_terracotta
setblock 275 126 481 minecraft:bone_block
setblock 275 126 482 minecraft:brown_terracotta
setblock 276 126 465 minecraft:bone_block
fill 276 126 466 276 129 466 minecraft:brown_terracotta
setblock 276 126 470 minecraft:bone_block
fill 276 126 471 276 129 471 minecraft:brown_terracotta
setblock 276 126 475 minecraft:bone_block
setblock 276 126 476 minecraft:brown_terracotta
setblock 276 126 480 minecraft:bone_block
fill 276 126 481 276 129 481 minecraft:brown_terracotta
setblock 276 126 485 minecraft:bone_block
fill 276 126 486 276 129 486 minecraft:brown_terracotta
setblock 236 127 464 minecraft:bone_block
fill 236 127 465 236 130 465 minecraft:brown_terracotta
setblock 236 127 469 minecraft:bone_block
fill 236 127 470 236 130 470 minecraft:brown_terracotta
setblock 236 127 484 minecraft:bone_block
fill 236 127 485 236 130 485 minecraft:brown_terracotta
setblock 236 127 504 minecraft:bone_block
fill 237 127 464 237 130 464 minecraft:brown_terracotta
setblock 237 127 468 minecraft:bone_block
setblock 237 127 503 minecraft:bone_block
fill 237 127 504 237 130 504 minecraft:brown_terracotta
fill 238 127 503 238 130 503 minecraft:brown_terracotta
setblock 239 127 466 minecraft:bone_block
setblock 239 127 502 minecraft:brown_terracotta
setblock 240 127 465 minecraft:bone_block
fill 240 127 466 240 130 466 minecraft:brown_terracotta
setblock 241 127 464 minecraft:bone_block
fill 241 127 465 241 130 465 minecraft:brown_terracotta
setblock 241 127 504 minecraft:bone_block
fill 242 127 464 242 130 464 minecraft:brown_terracotta
setblock 242 127 503 minecraft:bone_block
fill 242 127 504 242 130 504 minecraft:brown_terracotta
setblock 243 127 502 minecraft:bone_block
fill 243 127 503 243 130 503 minecraft:brown_terracotta
setblock 244 127 466 minecraft:bone_block
fill 244 127 502 244 128 502 minecraft:brown_terracotta
setblock 245 127 465 minecraft:bone_block
setblock 246 127 464 minecraft:bone_block
fill 246 127 465 246 128 465 minecraft:brown_terracotta
setblock 246 127 504 minecraft:bone_block
fill 247 127 464 247 130 464 minecraft:brown_terracotta
setblock 247 127 503 minecraft:bone_block
fill 247 127 504 250 127 504 minecraft:brown_terracotta
fill 248 127 503 249 127 503 minecraft:brown_terracotta
setblock 251 127 504 minecraft:bone_block
fill 252 127 504 252 128 504 minecraft:brown_terracotta
setblock 256 127 464 minecraft:bone_block
setblock 256 127 504 minecraft:bone_block
fill 257 127 464 260 127 464 minecraft:brown_terracotta
fill 257 127 504 257 130 504 minecraft:brown_terracotta
setblock 258 127 503 minecraft:brown_terracotta
setblock 260 127 465 minecraft:bone_block
setblock 261 127 464 minecraft:bone_block
fill 261 127 465 261 130 465 minecraft:brown_terracotta
setblock 261 127 504 minecraft:bone_block
fill 262 127 464 262 130 464 minecraft:brown_terracotta
setblock 262 127 503 minecraft:bone_block
fill 262 127 504 262 130 504 minecraft:brown_terracotta
setblock 263 127 503 minecraft:brown_terracotta
setblock 265 127 465 minecraft:bone_block
setblock 266 127 464 minecraft:bone_block
setblock 266 127 504 minecraft:bone_block
fill 267 127 464 270 127 464 minecraft:brown_terracotta
setblock 267 127 504 minecraft:brown_terracotta
setblock 271 127 464 minecraft:bone_block
fill 272 127 464 272 130 464 minecraft:brown_terracotta
fill 272 127 478 273 128 478 minecraft:bone_block
setblock 275 127 465 minecraft:bone_block
setblock 276 127 464 minecraft:bone_block
fill 276 127 465 276 130 465 minecraft:brown_terracotta
setblock 276 127 469 minecraft:bone_block
fill 276 127 470 276 130 470 minecraft:brown_terracotta
fill 276 127 472 276 128 472 minecraft:brown_terracotta
setblock 276 127 479 minecraft:bone_block
fill 276 127 480 276 130 480 minecraft:brown_terracotta
setblock 276 127 484 minecraft:bone_block
fill 276 127 485 276 130 485 minecraft:brown_terracotta
setblock 276 127 504 minecraft:bone_block
fill 236 128 464 236 131 464 minecraft:brown_terracotta
setblock 236 128 468 minecraft:bone_block
fill 236 128 469 237 130 469 minecraft:brown_terracotta
fill 236 128 471 236 129 471 minecraft:brown_terracotta
fill 236 128 484 236 131 484 minecraft:brown_terracotta
fill 236 128 486 236 129 486 minecraft:brown_terracotta
setblock 236 128 502 minecraft:brown_terracotta
setblock 236 128 503 minecraft:bone_block
fill 236 128 504 236 131 504 minecraft:brown_terracotta
setblock 237 128 466 minecraft:brown_terracotta
setblock 237 128 467 minecraft:bone_block
fill 237 128 468 237 131 468 minecraft:brown_terracotta
setblock 237 128 502 minecraft:bone_block
fill 237 128 503 237 131 503 minecraft:brown_terracotta
setblock 238 128 466 minecraft:bone_block
fill 238 128 467 238 131 467 minecraft:brown_terracotta
setblock 238 128 474 minecraft:light[level=12]
setblock 238 128 482 minecraft:light[level=12]
setblock 238 128 490 minecraft:light[level=12]
setblock 238 128 498 minecraft:light[level=12]
setblock 239 128 465 minecraft:bone_block
fill 239 128 466 239 131 466 minecraft:brown_terracotta
setblock 240 128 464 minecraft:bone_block
fill 240 128 465 240 131 465 minecraft:brown_terracotta
setblock 240 128 504 minecraft:bone_block
fill 241 128 464 241 131 464 minecraft:brown_terracotta
setblock 241 128 503 minecraft:bone_block
fill 241 128 504 241 131 504 minecraft:brown_terracotta
setblock 242 128 502 minecraft:bone_block
fill 242 128 503 242 131 503 minecraft:brown_terracotta
setblock 243 128 466 minecraft:bone_block
setblock 243 128 502 minecraft:brown_terracotta
setblock 244 128 465 minecraft:bone_block
setblock 245 128 464 minecraft:bone_block
fill 245 128 465 245 130 465 minecraft:brown_terracotta
setblock 245 128 504 minecraft:bone_block
fill 246 128 464 246 131 464 minecraft:brown_terracotta
setblock 246 128 466 minecraft:light[level=12]
setblock 246 128 474 minecraft:light[level=12]
setblock 246 128 482 minecraft:light[level=12]
setblock 246 128 490 minecraft:light[level=12]
setblock 246 128 498 minecraft:light[level=12]
setblock 246 128 503 minecraft:bone_block
fill 246 128 504 249 128 504 minecraft:brown_terracotta
setblock 247 128 503 minecraft:brown_terracotta
setblock 250 128 504 minecraft:bone_block
setblock 251 128 504 minecraft:brown_terracotta
setblock 254 128 466 minecraft:light[level=12]
setblock 254 128 474 minecraft:light[level=12]
setblock 254 128 482 minecraft:light[level=12]
setblock 254 128 490 minecraft:light[level=12]
setblock 254 128 498 minecraft:light[level=12]
setblock 255 128 504 minecraft:bone_block
fill 256 128 464 259 128 464 minecraft:brown_terracotta
fill 256 128 504 256 131 504 minecraft:brown_terracotta
fill 259 128 472 260 129 473 minecraft:bone_block
setblock 260 128 464 minecraft:bone_block
fill 260 128 465 260 131 465 minecraft:brown_terracotta
setblock 260 128 504 minecraft:bone_block
fill 261 128 464 261 131 464 minecraft:brown_terracotta
fill 261 128 504 261 131 504 minecraft:brown_terracotta
setblock 262 128 466 minecraft:light[level=12]
setblock 262 128 474 minecraft:light[level=12]
setblock 262 128 482 minecraft:light[level=12]
setblock 262 128 490 minecraft:light[level=12]
setblock 262 128 498 minecraft:light[level=12]
setblock 264 128 465 minecraft:bone_block
setblock 265 128 464 minecraft:bone_block
setblock 265 128 504 minecraft:bone_block
fill 266 128 464 269 128 464 minecraft:brown_terracotta
setblock 270 128 464 minecraft:bone_block
setblock 270 128 466 minecraft:light[level=12]
setblock 270 128 474 minecraft:light[level=12]
setblock 270 128 482 minecraft:light[level=12]
setblock 270 128 490 minecraft:light[level=12]
setblock 270 128 498 minecraft:light[level=12]
fill 271 128 464 271 131 464 minecraft:brown_terracotta
fill 273 128 477 275 129 477 minecraft:bone_block
fill 273 128 479 275 129 479 minecraft:bone_block
fill 274 128 467 274 131 467 minecraft:soul_soil
fill 274 128 478 274 129 478 minecraft:bone_block
setblock 275 128 464 minecraft:bone_block
fill 275 128 465 275 129 467 minecraft:brown_terracotta
fill 276 128 464 276 131 464 minecraft:brown_terracotta
setblock 276 128 468 minecraft:bone_block
fill 276 128 469 276 131 469 minecraft:brown_terracotta
setblock 276 128 479 minecraft:brown_terracotta
setblock 276 128 483 minecraft:bone_block
fill 276 128 484 276 131 484 minecraft:brown_terracotta
setblock 276 128 488 minecraft:bone_block
fill 276 128 504 276 131 504 minecraft:brown_terracotta
setblock 236 129 467 minecraft:bone_block
fill 236 129 468 236 132 468 minecraft:brown_terracotta
setblock 236 129 487 minecraft:bone_block
fill 236 129 488 236 132 488 minecraft:brown_terracotta
setblock 236 129 502 minecraft:bone_block
fill 236 129 503 236 132 503 minecraft:brown_terracotta
setblock 237 129 466 minecraft:bone_block
fill 237 129 467 237 132 467 minecraft:brown_terracotta
fill 237 129 502 237 132 502 minecraft:brown_terracotta
setblock 238 129 465 minecraft:bone_block
fill 238 129 466 238 132 466 minecraft:brown_terracotta
setblock 239 129 464 minecraft:bone_block
fill 239 129 465 239 132 465 minecraft:brown_terracotta
setblock 239 129 504 minecraft:bone_block
fill 240 129 464 240 132 464 minecraft:brown_terracotta
setblock 240 129 503 minecraft:bone_block
fill 240 129 504 240 132 504 minecraft:brown_terracotta
setblock 241 129 502 minecraft:bone_block
fill 241 129 503 241 132 503 minecraft:brown_terracotta
setblock 242 129 466 minecraft:bone_block
setblock 243 129 465 minecraft:bone_block
setblock 243 129 466 minecraft:brown_terracotta
setblock 244 129 464 minecraft:bone_block
fill 244 129 465 244 132 465 minecraft:brown_terracotta
setblock 244 129 504 minecraft:bone_block
fill 245 129 464 245 132 464 minecraft:brown_terracotta
setblock 245 129 503 minecraft:bone_block
fill 245 129 504 248 129 504 minecraft:brown_terracotta
setblock 246 129 503 minecraft:brown_terracotta
setblock 249 129 504 minecraft:bone_block
setblock 250 129 504 minecraft:brown_terracotta
setblock 254 129 504 minecraft:bone_block
fill 255 129 504 255 132 504 minecraft:brown_terracotta
fill 256 129 464 258 129 464 minecraft:brown_terracotta
setblock 259 129 464 minecraft:bone_block
setblock 259 129 504 minecraft:bone_block
fill 260 129 464 260 132 464 minecraft:brown_terracotta
fill 260 129 504 260 132 504 minecraft:brown_terracotta
setblock 263 129 465 minecraft:bone_block
setblock 264 129 464 minecraft:bone_block
fill 264 129 465 264 132 465 minecraft:brown_terracotta
setblock 264 129 504 minecraft:bone_block
fill 265 129 464 268 129 464 minecraft:brown_terracotta
setblock 269 129 464 minecraft:bone_block
fill 270 129 464 270 132 464 minecraft:brown_terracotta
setblock 274 129 464 minecraft:bone_block
fill 274 129 465 274 132 465 minecraft:brown_terracotta
fill 275 129 464 275 132 464 minecraft:brown_terracotta
setblock 275 129 468 minecraft:bone_block
setblock 276 129 467 minecraft:bone_block
fill 276 129 468 276 132 468 minecraft:brown_terracotta
setblock 276 129 472 minecraft:bone_block
fill 276 129 473 276 132 473 minecraft:brown_terracotta
setblock 276 129 482 minecraft:bone_block
fill 276 129 483 276 132 483 minecraft:brown_terracotta
setblock 276 129 487 minecraft:bone_block
fill 276 129 488 276 132 488 minecraft:brown_terracotta
setblock 236 130 466 minecraft:bone_block
fill 236 130 467 236 133 467 minecraft:brown_terracotta
setblock 236 130 471 minecraft:bone_block
fill 236 130 472 236 133 472 minecraft:brown_terracotta
setblock 236 130 486 minecraft:bone_block
fill 236 130 487 236 133 487 minecraft:brown_terracotta
fill 236 130 489 236 130 490 minecraft:brown_terracotta
setblock 236 130 501 minecraft:bone_block
fill 236 130 502 236 133 502 minecraft:brown_terracotta
setblock 237 130 465 minecraft:bone_block
fill 237 130 466 237 133 466 minecraft:brown_terracotta
setblock 237 130 470 minecraft:bone_block
setblock 238 130 464 minecraft:bone_block
fill 238 130 465 238 133 465 minecraft:brown_terracotta
setblock 238 130 468 minecraft:brown_terracotta
setblock 238 130 504 minecraft:bone_block
fill 239 130 464 239 133 464 minecraft:brown_terracotta
setblock 239 130 503 minecraft:bone_block
fill 239 130 504 239 133 504 minecraft:brown_terracotta
fill 240 130 503 240 133 503 minecraft:brown_terracotta
setblock 241 130 466 minecraft:bone_block
setblock 242 130 465 minecraft:bone_block
fill 242 130 466 242 133 466 minecraft:brown_terracotta
setblock 243 130 464 minecraft:bone_block
fill 243 130 465 243 133 465 minecraft:brown_terracotta
setblock 243 130 504 minecraft:bone_block
fill 244 130 464 244 133 464 minecraft:brown_terracotta
setblock 244 130 503 minecraft:bone_block
fill 244 130 504 247 130 504 minecraft:brown_terracotta
setblock 245 130 503 minecraft:brown_terracotta
setblock 248 130 504 minecraft:bone_block
setblock 249 130 504 minecraft:brown_terracotta
fill 256 130 464 257 130 464 minecraft:brown_terracotta
setblock 258 130 464 minecraft:bone_block
setblock 258 130 504 minecraft:bone_block
fill 259 130 464 259 132 465 minecraft:brown_terracotta
fill 259 130 504 259 133 504 minecraft:brown_terracotta
setblock 262 130 465 minecraft:bone_block
setblock 263 130 464 minecraft:bone_block
fill 263 130 465 263 133 465 minecraft:brown_terracotta
setblock 263 130 504 minecraft:bone_block
fill 264 130 464 267 130 464 minecraft:brown_terracotta
setblock 268 130 464 minecraft:bone_block
fill 269 130 464 269 133 464 minecraft:brown_terracotta
setblock 273 130 464 minecraft:bone_block
fill 274 130 464 274 133 464 minecraft:brown_terracotta
fill 275 130 465 275 130 466 minecraft:brown_terracotta
setblock 275 130 467 minecraft:bone_block
fill 275 130 468 275 131 470 minecraft:brown_terracotta
setblock 276 130 466 minecraft:bone_block
fill 276 130 467 276 133 467 minecraft:brown_terracotta
setblock 276 130 471 minecraft:bone_block
fill 276 130 472 276 133 472 minecraft:brown_terracotta
fill 276 130 474 276 130 475 minecraft:brown_terracotta
setblock 276 130 481 minecraft:bone_block
fill 276 130 482 276 133 482 minecraft:brown_terracotta
setblock 276 130 486 minecraft:bone_block
fill 276 130 487 276 133 487 minecraft:brown_terracotta
fill 276 130 489 276 131 489 minecraft:brown_terracotta
setblock 236 131 465 minecraft:bone_block
fill 236 131 466 236 134 466 minecraft:brown_terracotta
setblock 236 131 469 minecraft:brown_terracotta
setblock 236 131 470 minecraft:bone_block
fill 236 131 471 237 133 471 minecraft:brown_terracotta
fill 236 131 473 236 132 473 minecraft:brown_terracotta
setblock 236 131 485 minecraft:bone_block
fill 236 131 486 236 134 486 minecraft:brown_terracotta
setblock 236 131 489 minecraft:brown_terracotta
setblock 236 131 490 minecraft:bone_block
fill 236 131 491 236 132 493 minecraft:brown_terracotta
setblock 236 131 500 minecraft:bone_block
fill 236 131 501 236 134 501 minecraft:brown_terracotta
setblock 237 131 464 minecraft:bone_block
fill 237 131 465 237 134 465 minecraft:brown_terracotta
setblock 237 131 469 minecraft:bone_block
fill 237 131 470 237 134 470 minecraft:brown_terracotta
fill 237 131 487 237 131 488 minecraft:brown_terracotta
setblock 237 131 489 minecraft:bone_block
fill 237 131 490 237 134 490 minecraft:brown_terracotta
setblock 237 131 504 minecraft:bone_block
fill 238 131 464 238 134 464 minecraft:brown_terracotta
setblock 238 131 468 minecraft:bone_block
fill 238 131 469 238 134 469 minecraft:brown_terracotta
setblock 238 131 503 minecraft:bone_block
fill 238 131 504 238 134 504 minecraft:brown_terracotta
fill 239 131 503 239 134 503 minecraft:brown_terracotta
setblock 240 131 466 minecraft:bone_block
setblock 241 131 465 minecraft:bone_block
fill 241 131 466 241 134 466 minecraft:brown_terracotta
setblock 242 131 464 minecraft:bone_block
fill 242 131 465 242 134 465 minecraft:brown_terracotta
setblock 242 131 504 minecraft:bone_block
fill 243 131 464 243 134 464 minecraft:brown_terracotta
setblock 243 131 503 minecraft:bone_block
fill 243 131 504 246 131 504 minecraft:brown_terracotta
setblock 244 131 503 minecraft:brown_terracotta
setblock 247 131 464 minecraft:bone_block
setblock 247 131 504 minecraft:bone_block
fill 251 131 473 251 132 474 minecraft:bone_block
fill 252 131 473 252 132 473 minecraft:bone_block
fill 255 131 464 256 131 464 minecraft:brown_terracotta
setblock 257 131 464 minecraft:bone_block
setblock 257 131 504 minecraft:bone_block
fill 258 131 464 258 133 465 minecraft:brown_terracotta
fill 258 131 504 258 134 504 minecraft:brown_terracotta
setblock 261 131 465 minecraft:bone_block
setblock 262 131 464 minecraft:bone_block
fill 262 131 465 262 134 465 minecraft:brown_terracotta
setblock 262 131 504 minecraft:bone_block
fill 263 131 464 266 131 464 minecraft:brown_terracotta
setblock 267 131 464 minecraft:bone_block
fill 268 131 464 268 134 464 minecraft:brown_terracotta
setblock 272 131 464 minecraft:bone_block
fill 273 131 464 273 133 465 minecraft:brown_terracotta
setblock 275 131 465 minecraft:brown_terracotta
setblock 275 131 466 minecraft:bone_block
fill 275 131 467 275 134 467 minecraft:brown_terracotta
setblock 275 131 471 minecraft:bone_block
fill 275 131 472 275 134 472 minecraft:brown_terracotta
setblock 276 131 465 minecraft:bone_block
fill 276 131 466 276 134 466 minecraft:brown_terracotta
setblock 276 131 470 minecraft:bone_block
fill 276 131 471 276 134 471 minecraft:brown_terracotta
setblock 276 131 474 minecraft:brown_terracotta
setblock 276 131 475 minecraft:bone_block
fill 276 131 476 276 134 476 minecraft:brown_terracotta
setblock 276 131 480 minecraft:bone_block
fill 276 131 481 276 134 481 minecraft:brown_terracotta
setblock 276 131 485 minecraft:bone_block
fill 276 131 486 276 134 486 minecraft:brown_terracotta
setblock 276 131 490 minecraft:bone_block
fill 276 131 491 276 134 491 minecraft:brown_terracotta
setblock 236 132 464 minecraft:bone_block
fill 236 132 465 236 135 465 minecraft:brown_terracotta
setblock 236 132 469 minecraft:bone_block
fill 236 132 470 236 135 470 minecraft:brown_terracotta
setblock 236 132 474 minecraft:bone_block
setblock 236 132 483 minecraft:brown_terracotta
setblock 236 132 484 minecraft:bone_block
fill 236 132 485 236 135 485 minecraft:brown_terracotta
setblock 236 132 489 minecraft:bone_block
fill 236 132 490 236 135 490 minecraft:brown_terracotta
setblock 236 132 494 minecraft:bone_block
fill 236 132 495 236 132 498 minecraft:brown_terracotta
setblock 236 132 499 minecraft:bone_block
fill 236 132 500 236 135 500 minecraft:brown_terracotta
setblock 236 132 504 minecraft:bone_block
fill 237 132 464 237 135 464 minecraft:brown_terracotta
setblock 237 132 468 minecraft:bone_block
fill 237 132 469 237 135 469 minecraft:brown_terracotta
setblock 237 132 472 minecraft:brown_terracotta
fill 237 132 486 237 132 487 minecraft:brown_terracotta
setblock 237 132 488 minecraft:bone_block
fill 237 132 489 237 135 489 minecraft:brown_terracotta
fill 237 132 491 237 132 492 minecraft:brown_terracotta
setblock 237 132 493 minecraft:bone_block
fill 237 132 494 237 135 494 minecraft:brown_terracotta
fill 237 132 501 237 133 501 minecraft:brown_terracotta
setblock 237 132 503 minecraft:bone_block
fill 237 132 504 237 135 504 minecraft:brown_terracotta
setblock 238 132 467 minecraft:bone_block
fill 238 132 468 238 135 468 minecraft:brown_terracotta
fill 238 132 470 238 133 470 minecraft:brown_terracotta
fill 238 132 503 238 135 503 minecraft:brown_terracotta
setblock 239 132 466 minecraft:bone_block
setblock 240 132 465 minecraft:bone_block
fill 240 132 466 240 135 466 minecraft:brown_terracotta
setblock 241 132 464 minecraft:bone_block
fill 241 132 465 241 135 465 minecraft:brown_terracotta
setblock 241 132 504 minecraft:bone_block
fill 242 132 464 242 135 464 minecraft:brown_terracotta
setblock 242 132 503 minecraft:bone_block
fill 242 132 504 245 132 504 minecraft:brown_terracotta
fill 243 132 503 243 134 503 minecraft:brown_terracotta
setblock 246 132 464 minecraft:bone_block
setblock 246 132 504 minecraft:bone_block
setblock 247 132 504 minecraft:brown_terracotta
fill 254 132 464 255 132 464 minecraft:brown_terracotta
setblock 256 132 464 minecraft:bone_block
setblock 256 132 504 minecraft:bone_block
fill 257 132 464 257 134 465 minecraft:brown_terracotta
fill 257 132 504 257 135 504 minecraft:brown_terracotta
setblock 260 132 465 minecraft:bone_block
setblock 261 132 464 minecraft:bone_block
fill 261 132 465 261 135 465 minecraft:brown_terracotta
setblock 261 132 504 minecraft:bone_block
fill 262 132 464 265 132 464 minecraft:brown_terracotta
setblock 266 132 464 minecraft:bone_block
fill 267 132 464 267 135 464 minecraft:brown_terracotta
setblock 271 132 464 minecraft:bone_block
fill 272 132 464 272 134 465 minecraft:brown_terracotta
setblock 274 132 466 minecraft:bone_block
fill 274 132 467 274 133 469 minecraft:brown_terracotta
setblock 275 132 465 minecraft:bone_block
fill 275 132 466 275 135 466 minecraft:brown_terracotta
fill 275 132 468 275 132 469 minecraft:brown_terracotta
setblock 275 132 470 minecraft:bone_block
fill 275 132 471 275 135 471 minecraft:brown_terracotta
fill 275 132 473 275 133 473 minecraft:brown_terracotta
setblock 275 132 504 minecraft:brown_terracotta
setblock 276 132 464 minecraft:bone_block
fill 276 132 465 276 135 465 minecraft:brown_terracotta
setblock 276 132 469 minecraft:bone_block
fill 276 132 470 276 135 470 minecraft:brown_terracotta
setblock 276 132 474 minecraft:bone_block
fill 276 132 475 276 135 475 minecraft:brown_terracotta
fill 276 132 477 276 132 478 minecraft:brown_terracotta
setblock 276 132 479 minecraft:bone_block
fill 276 132 480 276 135 480 minecraft:brown_terracotta
setblock 276 132 484 minecraft:bone_block
fill 276 132 485 276 135 485 minecraft:brown_terracotta
setblock 276 132 489 minecraft:bone_block
fill 276 132 490 276 135 490 minecraft:brown_terracotta
fill 276 132 492 276 132 493 minecraft:brown_terracotta
setblock 276 132 503 minecraft:brown_terracotta
setblock 276 132 504 minecraft:bone_block
fill 236 133 464 236 136 464 minecraft:brown_terracotta
setblock 236 133 468 minecraft:bone_block
fill 236 133 469 236 136 469 minecraft:brown_terracotta
setblock 236 133 473 minecraft:bone_block
fill 236 133 474 236 135 475 minecraft:brown_terracotta
setblock 236 133 483 minecraft:bone_block
fill 236 133 484 236 136 484 minecraft:brown_terracotta
setblock 236 133 488 minecraft:bone_block
fill 236 133 489 236 136 489 minecraft:brown_terracotta
fill 236 133 491 236 133 492 minecraft:brown_terracotta
setblock 236 133 493 minecraft:bone_block
fill 236 133 494 236 133 497 minecraft:brown_terracotta
setblock 236 133 498 minecraft:bone_block
fill 236 133 499 237 135 499 minecraft:brown_terracotta
setblock 236 133 503 minecraft:bone_block
fill 236 133 504 236 136 504 minecraft:brown_terracotta
setblock 237 133 467 minecraft:bone_block
fill 237 133 468 237 136 468 minecraft:brown_terracotta
setblock 237 133 472 minecraft:bone_block
fill 237 133 473 237 136 473 minecraft:brown_terracotta
fill 237 133 485 237 133 486 minecraft:brown_terracotta
setblock 237 133 487 minecraft:bone_block
fill 237 133 488 238 135 488 minecraft:brown_terracotta
setblock 237 133 491 minecraft:brown_terracotta
setblock 237 133 492 minecraft:bone_block
fill 237 133 493 238 135 493 minecraft:brown_terracotta
fill 237 133 495 237 133 496 minecraft:brown_terracotta
setblock 237 133 497 minecraft:bone_block
fill 237 133 498 237 136 498 minecraft:brown_terracotta
fill 237 133 500 237 134 500 minecraft:brown_terracotta
setblock 237 133 502 minecraft:bone_block
fill 237 133 503 237 136 503 minecraft:brown_terracotta
setblock 238 133 466 minecraft:bone_block
fill 238 133 467 239 134 467 minecraft:brown_terracotta
setblock 238 133 471 minecraft:bone_block
fill 238 133 489 238 133 490 minecraft:brown_terracotta
setblock 238 133 491 minecraft:bone_block
fill 238 133 492 238 136 492 minecraft:brown_terracotta
setblock 239 133 465 minecraft:bone_block
fill 239 133 466 239 136 466 minecraft:brown_terracotta
setblock 240 133 464 minecraft:bone_block
fill 240 133 465 240 136 465 minecraft:brown_terracotta
setblock 240 133 504 minecraft:bone_block
fill 241 133 464 241 136 464 minecraft:brown_terracotta
setblock 241 133 503 minecraft:bone_block
fill 241 133 504 244 133 504 minecraft:brown_terracotta
fill 242 133 503 242 136 503 minecraft:brown_terracotta
setblock 244 133 465 minecraft:bone_block
setblock 245 133 464 minecraft:bone_block
setblock 245 133 504 minecraft:bone_block
setblock 246 133 464 minecraft:brown_terracotta
fill 246 133 504 246 134 504 minecraft:brown_terracotta
setblock 254 133 464 minecraft:brown_terracotta
setblock 254 133 504 minecraft:brown_terracotta
setblock 255 133 464 minecraft:bone_block
setblock 255 133 504 minecraft:bone_block
fill 256 133 464 256 135 465 minecraft:brown_terracotta
fill 256 133 504 256 136 504 minecraft:brown_terracotta
setblock 259 133 464 minecraft:brown_terracotta
setblock 259 133 465 minecraft:bone_block
setblock 260 133 464 minecraft:bone_block
fill 260 133 465 260 136 465 minecraft:brown_terracotta
setblock 260 133 504 minecraft:bone_block
fill 261 133 464 264 133 464 minecraft:brown_terracotta
setblock 261 133 504 minecraft:brown_terracotta
setblock 264 133 465 minecraft:bone_block
setblock 265 133 464 minecraft:bone_block
fill 266 133 464 266 136 464 minecraft:brown_terracotta
setblock 270 133 464 minecraft:bone_block
fill 271 133 464 271 135 465 minecraft:brown_terracotta
setblock 273 133 466 minecraft:bone_block
fill 273 133 467 273 134 467 minecraft:soul_soil
setblock 274 133 465 minecraft:bone_block
fill 274 133 466 274 136 466 minecraft:brown_terracotta
setblock 274 133 470 minecraft:bone_block
fill 274 133 471 274 136 471 minecraft:brown_terracotta
setblock 275 133 464 minecraft:bone_block
fill 275 133 465 275 136 465 minecraft:brown_terracotta
setblock 275 133 468 minecraft:brown_terracotta
setblock 275 133 469 minecraft:bone_block
fill 275 133 470 275 136 470 minecraft:brown_terracotta
setblock 275 133 474 minecraft:bone_block
fill 275 133 475 275 136 475 minecraft:brown_terracotta
fill 275 133 487 275 133 488 minecraft:brown_terracotta
setblock 275 133 489 minecraft:bone_block
fill 275 133 490 275 136 490 minecraft:brown_terracotta
setblock 275 133 504 minecraft:bone_block
fill 276 133 464 276 136 464 minecraft:brown_terracotta
setblock 276 133 468 minecraft:bone_block
fill 276 133 469 276 136 469 minecraft:brown_terracotta
setblock 276 133 473 minecraft:bone_block
fill 276 133 474 276 136 474 minecraft:brown_terracotta
setblock 276 133 477 minecraft:brown_terracotta
setblock 276 133 478 minecraft:bone_block
fill 276 133 479 276 136 479 minecraft:brown_terracotta
setblock 276 133 483 minecraft:bone_block
fill 276 133 484 276 136 484 minecraft:brown_terracotta
setblock 276 133 488 minecraft:bone_block
fill 276 133 489 276 136 489 minecraft:brown_terracotta
setblock 276 133 492 minecraft:brown_terracotta
setblock 276 133 493 minecraft:bone_block
fill 276 133 494 276 135 495 minecraft:brown_terracotta
setblock 276 133 502 minecraft:brown_terracotta
setblock 276 133 503 minecraft:bone_block
fill 276 133 504 276 136 504 minecraft:brown_terracotta
setblock 236 134 467 minecraft:bone_block
fill 236 134 468 236 137 468 minecraft:brown_terracotta
setblock 236 134 471 minecraft:brown_terracotta
setblock 236 134 472 minecraft:bone_block
fill 236 134 473 236 137 473 minecraft:brown_terracotta
setblock 236 134 476 minecraft:brown_terracotta
setblock 236 134 477 minecraft:bone_block
fill 236 134 483 236 137 483 minecraft:brown_terracotta
setblock 236 134 487 minecraft:bone_block
fill 236 134 488 236 137 488 minecraft:brown_terracotta
setblock 236 134 491 minecraft:brown_terracotta
setblock 236 134 492 minecraft:bone_block
fill 236 134 493 236 134 496 minecraft:brown_terracotta
setblock 236 134 497 minecraft:bone_block
fill 236 134 498 236 137 498 minecraft:brown_terracotta
setblock 236 134 502 minecraft:bone_block
fill 236 134 503 236 137 503 minecraft:brown_terracotta
setblock 237 134 466 minecraft:bone_block
fill 237 134 467 237 137 467 minecraft:brown_terracotta
setblock 237 134 471 minecraft:bone_block
fill 237 134 472 237 137 472 minecraft:brown_terracotta
fill 237 134 474 237 135 474 minecraft:brown_terracotta
setblock 237 134 485 minecraft:brown_terracotta
setblock 237 134 486 minecraft:bone_block
fill 237 134 487 237 137 487 minecraft:brown_terracotta
setblock 237 134 491 minecraft:bone_block
fill 237 134 492 237 137 492 minecraft:brown_terracotta
setblock 237 134 495 minecraft:brown_terracotta
setblock 237 134 496 minecraft:bone_block
fill 237 134 497 237 137 497 minecraft:brown_terracotta
setblock 237 134 501 minecraft:bone_block
fill 237 134 502 237 137 502 minecraft:brown_terracotta
setblock 238 134 465 minecraft:bone_block
fill 238 134 466 238 137 466 minecraft:brown_terracotta
setblock 238 134 470 minecraft:bone_block
fill 238 134 471 238 137 471 minecraft:brown_terracotta
setblock 238 134 489 minecraft:brown_terracotta
setblock 238 134 490 minecraft:bone_block
fill 238 134 491 238 137 491 minecraft:brown_terracotta
setblock 238 134 494 minecraft:brown_terracotta
setblock 238 134 495 minecraft:bone_block
fill 238 134 496 238 137 496 minecraft:brown_terracotta
setblock 239 134 464 minecraft:bone_block
fill 239 134 465 239 137 465 minecraft:brown_terracotta
setblock 239 134 504 minecraft:bone_block
fill 240 134 464 240 137 464 minecraft:brown_terracotta
setblock 240 134 503 minecraft:bone_block
fill 240 134 504 243 134 504 minecraft:brown_terracotta
fill 241 134 503 241 137 503 minecraft:brown_terracotta
setblock 243 134 465 minecraft:bone_block
setblock 244 134 464 minecraft:bone_block
setblock 244 134 504 minecraft:bone_block
fill 245 134 464 245 135 464 minecraft:brown_terracotta
fill 245 134 504 245 135 504 minecraft:brown_terracotta
setblock 253 134 464 minecraft:brown_terracotta
setblock 254 134 464 minecraft:bone_block
setblock 254 134 504 minecraft:bone_block
fill 255 134 464 255 136 465 minecraft:brown_terracotta
fill 255 134 504 255 137 504 minecraft:brown_terracotta
setblock 258 134 464 minecraft:brown_terracotta
setblock 258 134 465 minecraft:bone_block
setblock 259 134 464 minecraft:bone_block
fill 259 134 465 259 136 466 minecraft:brown_terracotta
setblock 259 134 504 minecraft:bone_block
fill 260 134 464 263 134 464 minecraft:brown_terracotta
fill 260 134 466 260 135 466 minecraft:brown_terracotta
fill 260 134 504 260 135 504 minecraft:brown_terracotta
setblock 263 134 465 minecraft:bone_block
setblock 264 134 464 minecraft:bone_block
setblock 264 134 465 minecraft:brown_terracotta
fill 265 134 464 265 136 464 minecraft:brown_terracotta
setblock 269 134 464 minecraft:bone_block
fill 270 134 464 270 136 465 minecraft:brown_terracotta
setblock 272 134 466 minecraft:bone_block
setblock 273 134 464 minecraft:brown_terracotta
setblock 273 134 465 minecraft:bone_block
fill 273 134 466 273 137 466 minecraft:brown_terracotta
setblock 274 134 464 minecraft:bone_block
fill 274 134 465 274 137 465 minecraft:brown_terracotta
fill 274 134 467 274 134 468 minecraft:brown_terracotta
setblock 274 134 469 minecraft:bone_block
fill 274 134 470 274 137 470 minecraft:brown_terracotta
fill 274 134 472 274 134 473 minecraft:brown_terracotta
setblock 274 134 504 minecraft:bone_block
fill 275 134 464 275 137 464 minecraft:brown_terracotta
setblock 275 134 468 minecraft:bone_block
fill 275 134 469 275 137 469 minecraft:brown_terracotta
setblock 275 134 473 minecraft:bone_block
fill 275 134 474 275 137 474 minecraft:brown_terracotta
fill 275 134 476 275 135 476 minecraft:brown_terracotta
fill 275 134 486 275 134 487 minecraft:brown_terracotta
setblock 275 134 488 minecraft:bone_block
fill 275 134 489 275 137 489 minecraft:brown_terracotta
fill 275 134 491 275 134 492 minecraft:brown_terracotta
fill 275 134 504 275 137 504 minecraft:brown_terracotta
setblock 276 134 467 minecraft:bone_block
fill 276 134 468 276 137 468 minecraft:brown_terracotta
setblock 276 134 472 minecraft:bone_block
fill 276 134 473 276 137 473 minecraft:brown_terracotta
setblock 276 134 477 minecraft:bone_block
fill 276 134 478 276 137 478 minecraft:brown_terracotta
setblock 276 134 482 minecraft:bone_block
fill 276 134 483 276 137 483 minecraft:brown_terracotta
setblock 276 134 487 minecraft:bone_block
fill 276 134 488 276 137 488 minecraft:brown_terracotta
setblock 276 134 492 minecraft:bone_block
fill 276 134 493 276 137 493 minecraft:brown_terracotta
setblock 276 134 496 minecraft:brown_terracotta
setblock 276 134 497 minecraft:bone_block
fill 276 134 498 276 134 501 minecraft:brown_terracotta
setblock 276 134 502 minecraft:bone_block
fill 276 134 503 276 137 503 minecraft:brown_terracotta
setblock 236 135 466 minecraft:bone_block
fill 236 135 467 236 138 467 minecraft:brown_terracotta
setblock 236 135 471 minecraft:bone_block
fill 236 135 472 236 138 472 minecraft:brown_terracotta
setblock 236 135 476 minecraft:bone_block
fill 236 135 477 236 137 478 minecraft:brown_terracotta
fill 236 135 482 236 137 482 minecraft:brown_terracotta
setblock 236 135 486 minecraft:bone_block
fill 236 135 487 236 138 487 minecraft:brown_terracotta
setblock 236 135 491 minecraft:bone_block
fill 236 135 492 236 135 495 minecraft:brown_terracotta
setblock 236 135 496 minecraft:bone_block
fill 236 135 497 236 138 497 minecraft:brown_terracotta
setblock 236 135 501 minecraft:bone_block
fill 236 135 502 236 138 502 minecraft:brown_terracotta
setblock 237 135 465 minecraft:bone_block
fill 237 135 466 237 138 466 minecraft:brown_terracotta
setblock 237 135 470 minecraft:bone_block
fill 237 135 471 237 138 471 minecraft:brown_terracotta
setblock 237 135 475 minecraft:bone_block
setblock 237 135 485 minecraft:bone_block
fill 237 135 486 237 137 486 minecraft:brown_terracotta
setblock 237 135 490 minecraft:bone_block
fill 237 135 491 237 138 491 minecraft:brown_terracotta
setblock 237 135 495 minecraft:bone_block
fill 237 135 496 237 138 496 minecraft:brown_terracotta
setblock 237 135 500 minecraft:bone_block
fill 237 135 501 238 137 501 minecraft:brown_terracotta
setblock 238 135 464 minecraft:bone_block
fill 238 135 465 238 138 465 minecraft:brown_terracotta
fill 238 135 467 238 136 467 minecraft:brown_terracotta
setblock 238 135 469 minecraft:bone_block
fill 238 135 470 238 138 470 minecraft:brown_terracotta
fill 238 135 472 238 136 472 minecraft:brown_terracotta
setblock 238 135 487 minecraft:brown_terracotta
setblock 238 135 489 minecraft:bone_block
fill 238 135 490 238 138 490 minecraft:brown_terracotta
setblock 238 135 494 minecraft:bone_block
fill 238 135 495 238 138 495 minecraft:brown_terracotta
fill 238 135 497 238 135 498 minecraft:brown_terracotta
setblock 238 135 499 minecraft:bone_block
fill 238 135 500 238 138 500 minecraft:brown_terracotta
fill 238 135 502 239 135 502 minecraft:brown_terracotta
setblock 238 135 504 minecraft:bone_block
fill 239 135 464 239 138 464 minecraft:brown_terracotta
fill 239 135 491 239 135 492 minecraft:brown_terracotta
setblock 239 135 493 minecraft:bone_block
setblock 239 135 503 minecraft:bone_block
fill 239 135 504 242 135 504 minecraft:brown_terracotta
fill 240 135 503 240 138 503 minecraft:brown_terracotta
setblock 241 135 466 minecraft:bone_block
setblock 242 135 465 minecraft:bone_block
setblock 243 135 464 minecraft:bone_block
setblock 243 135 465 minecraft:brown_terracotta
setblock 243 135 504 minecraft:bone_block
fill 244 135 464 244 136 464 minecraft:brown_terracotta
fill 244 135 504 244 136 504 minecraft:brown_terracotta
setblock 253 135 464 minecraft:bone_block
setblock 253 135 504 minecraft:bone_block
fill 254 135 464 254 138 464 minecraft:brown_terracotta
fill 254 135 504 254 138 504 minecraft:brown_terracotta
setblock 257 135 464 minecraft:brown_terracotta
setblock 257 135 465 minecraft:bone_block
setblock 258 135 464 minecraft:bone_block
fill 258 135 465 258 136 466 minecraft:brown_terracotta
setblock 258 135 504 minecraft:bone_block
fill 259 135 464 262 135 464 minecraft:brown_terracotta
fill 259 135 504 259 136 504 minecraft:brown_terracotta
setblock 262 135 465 minecraft:bone_block
setblock 263 135 464 minecraft:bone_block
setblock 263 135 465 minecraft:brown_terracotta
fill 264 135 464 264 137 464 minecraft:brown_terracotta
setblock 268 135 464 minecraft:bone_block
fill 269 135 464 269 137 465 minecraft:brown_terracotta
setblock 271 135 466 minecraft:bone_block
setblock 272 135 464 minecraft:brown_terracotta
setblock 272 135 465 minecraft:bone_block
fill 272 135 466 272 138 466 minecraft:brown_terracotta
setblock 273 135 464 minecraft:bone_block
fill 273 135 465 273 138 465 minecraft:brown_terracotta
fill 273 135 467 273 135 468 minecraft:brown_terracotta
setblock 273 135 469 minecraft:bone_block
fill 273 135 470 273 137 471 minecraft:brown_terracotta
setblock 273 135 504 minecraft:bone_block
fill 274 135 464 274 138 464 minecraft:brown_terracotta
setblock 274 135 467 minecraft:brown_terracotta
setblock 274 135 468 minecraft:bone_block
fill 274 135 469 274 138 469 minecraft:brown_terracotta
setblock 274 135 472 minecraft:brown_terracotta
setblock 274 135 473 minecraft:bone_block
fill 274 135 474 274 138 474 minecraft:brown_terracotta
fill 274 135 504 274 138 504 minecraft:brown_terracotta
setblock 275 135 467 minecraft:bone_block
fill 275 135 468 275 138 468 minecraft:brown_terracotta
setblock 275 135 472 minecraft:bone_block
fill 275 135 473 275 138 473 minecraft:brown_terracotta
setblock 275 135 477 minecraft:bone_block
setblock 275 135 486 minecraft:brown_terracotta
setblock 275 135 487 minecraft:bone_block
fill 275 135 488 275 138 488 minecraft:brown_terracotta
setblock 275 135 491 minecraft:brown_terracotta
setblock 275 135 492 minecraft:bone_block
fill 275 135 493 275 136 495 minecraft:brown_terracotta
setblock 276 135 466 minecraft:bone_block
fill 276 135 467 276 138 467 minecraft:brown_terracotta
setblock 276 135 471 minecraft:bone_block
fill 276 135 472 276 138 472 minecraft:brown_terracotta
setblock 276 135 476 minecraft:bone_block
fill 276 135 477 276 138 477 minecraft:brown_terracotta
setblock 276 135 481 minecraft:bone_block
fill 276 135 482 276 138 482 minecraft:brown_terracotta
setblock 276 135 486 minecraft:bone_block
fill 276 135 487 276 138 487 minecraft:brown_terracotta
setblock 276 135 491 minecraft:bone_block
fill 276 135 492 276 138 492 minecraft:brown_terracotta
setblock 276 135 496 minecraft:bone_block
fill 276 135 497 276 135 500 minecraft:brown_terracotta
setblock 276 135 501 minecraft:bone_block
fill 276 135 502 276 138 502 minecraft:brown_terracotta
setblock 236 136 465 minecraft:bone_block
fill 236 136 466 236 139 466 minecraft:brown_terracotta
setblock 236 136 470 minecraft:bone_block
fill 236 136 471 236 139 471 minecraft:brown_terracotta
setblock 236 136 474 minecraft:brown_terracotta
setblock 236 136 475 minecraft:bone_block
fill 236 136 476 236 139 476 minecraft:brown_terracotta
setblock 236 136 479 minecraft:brown_terracotta
setblock 236 136 480 minecraft:bone_block
fill 236 136 481 236 137 481 minecraft:brown_terracotta
setblock 236 136 485 minecraft:bone_block
fill 236 136 486 236 139 486 minecraft:brown_terracotta
setblock 236 136 490 minecraft:bone_block
fill 236 136 491 236 136 494 minecraft:brown_terracotta
setblock 236 136 495 minecraft:bone_block
fill 236 136 496 236 139 496 minecraft:brown_terracotta
setblock 236 136 499 minecraft:brown_terracotta
setblock 236 136 500 minecraft:bone_block
fill 236 136 501 236 139 501 minecraft:brown_terracotta
setblock 237 136 464 minecraft:bone_block
fill 237 136 465 237 139 465 minecraft:brown_terracotta
setblock 237 136 469 minecraft:bone_block
fill 237 136 470 237 139 470 minecraft:brown_terracotta
setblock 237 136 474 minecraft:bone_block
fill 237 136 475 237 139 475 minecraft:brown_terracotta
setblock 237 136 485 minecraft:brown_terracotta
setblock 237 136 488 minecraft:brown_terracotta
setblock 237 136 489 minecraft:bone_block
fill 237 136 490 237 139 490 minecraft:brown_terracotta
setblock 237 136 493 minecraft:brown_terracotta
setblock 237 136 494 minecraft:bone_block
fill 237 136 495 237 139 495 minecraft:brown_terracotta
setblock 237 136 499 minecraft:bone_block
fill 237 136 500 237 139 500 minecraft:brown_terracotta
setblock 237 136 504 minecraft:bone_block
fill 238 136 464 238 139 464 minecraft:brown_terracotta
setblock 238 136 468 minecraft:bone_block
fill 238 136 469 238 138 469 minecraft:brown_terracotta
setblock 238 136 473 minecraft:bone_block
setblock 238 136 474 minecraft:light[level=12]
setblock 238 136 482 minecraft:light[level=12]
setblock 238 136 488 minecraft:bone_block
fill 238 136 489 238 138 489 minecraft:brown_terracotta
setblock 238 136 493 minecraft:bone_block
fill 238 136 494 239 138 494 minecraft:brown_terracotta
setblock 238 136 497 minecraft:brown_terracotta
setblock 238 136 498 minecraft:bone_block
fill 238 136 499 238 139 499 minecraft:brown_terracotta
setblock 238 136 502 minecraft:brown_terracotta
setblock 238 136 503 minecraft:bone_block
fill 238 136 504 241 136 504 minecraft:brown_terracotta
setblock 239 136 491 minecraft:brown_terracotta
setblock 239 136 492 minecraft:bone_block
fill 239 136 493 239 138 493 minecraft:brown_terracotta
fill 239 136 495 239 137 495 minecraft:brown_terracotta
fill 239 136 503 239 139 503 minecraft:brown_terracotta
setblock 240 136 466 minecraft:bone_block
setblock 241 136 465 minecraft:bone_block
setblock 242 136 464 minecraft:bone_block
setblock 242 136 465 minecraft:brown_terracotta
setblock 242 136 504 minecraft:bone_block
fill 243 136 464 243 137 464 minecraft:brown_terracotta
fill 243 136 504 243 137 504 minecraft:brown_terracotta
setblock 246 136 466 minecraft:light[level=12]
setblock 246 136 474 minecraft:light[level=12]
setblock 246 136 482 minecraft:light[level=12]
setblock 246 136 490 minecraft:light[level=12]
setblock 246 136 498 minecraft:light[level=12]
setblock 252 136 464 minecraft:bone_block
fill 253 136 464 253 138 464 minecraft:brown_terracotta
fill 253 136 504 253 137 504 minecraft:brown_terracotta
setblock 254 136 466 minecraft:light[level=12]
setblock 254 136 474 minecraft:light[level=12]
setblock 254 136 482 minecraft:light[level=12]
setblock 254 136 490 minecraft:light[level=12]
setblock 254 136 498 minecraft:light[level=12]
setblock 256 136 464 minecraft:brown_terracotta
setblock 256 136 465 minecraft:bone_block
setblock 257 136 464 minecraft:bone_block
fill 257 136 465 257 138 465 minecraft:brown_terracotta
setblock 257 136 504 minecraft:bone_block
fill 258 136 464 261 136 464 minecraft:brown_terracotta
fill 258 136 504 258 137 504 minecraft:brown_terracotta
fill 259 136 467 259 140 467 minecraft:soul_soil
setblock 261 136 465 minecraft:bone_block
setblock 262 136 464 minecraft:bone_block
setblock 262 136 465 minecraft:brown_terracotta
setblock 262 136 466 minecraft:light[level=12]
setblock 262 136 474 minecraft:light[level=12]
setblock 262 136 482 minecraft:light[level=12]
setblock 262 136 490 minecraft:light[level=12]
setblock 262 136 498 minecraft:light[level=12]
fill 263 136 464 263 137 464 minecraft:brown_terracotta
setblock 267 136 464 minecraft:bone_block
fill 268 136 464 268 138 464 minecraft:brown_terracotta
setblock 270 136 466 minecraft:light[level=12]
setblock 270 136 474 minecraft:light[level=12]
setblock 270 136 482 minecraft:light[level=12]
setblock 270 136 490 minecraft:light[level=12]
setblock 270 136 498 minecraft:light[level=12]
setblock 271 136 464 minecraft:brown_terracotta
setblock 271 136 465 minecraft:bone_block
fill 271 136 466 271 138 466 minecraft:brown_terracotta
setblock 272 136 464 minecraft:bone_block
fill 272 136 465 272 139 465 minecraft:brown_terracotta
fill 273 136 464 273 139 464 minecraft:brown_terracotta
setblock 273 136 467 minecraft:brown_terracotta
setblock 273 136 468 minecraft:bone_block
fill 273 136 469 273 139 469 minecraft:brown_terracotta
setblock 273 136 472 minecraft:brown_terracotta
fill 273 136 504 273 139 504 minecraft:brown_terracotta
setblock 274 136 467 minecraft:bone_block
fill 274 136 468 274 139 468 minecraft:brown_terracotta
setblock 274 136 472 minecraft:bone_block
fill 274 136 473 274 139 473 minecraft:brown_terracotta
fill 274 136 475 274 137 475 minecraft:brown_terracotta
setblock 275 136 466 minecraft:bone_block
fill 275 136 467 275 139 467 minecraft:brown_terracotta
setblock 275 136 471 minecraft:bone_block
fill 275 136 472 275 139 472 minecraft:brown_terracotta
setblock 275 136 476 minecraft:bone_block
fill 275 136 477 275 138 478 minecraft:brown_terracotta
setblock 275 136 486 minecraft:bone_block
fill 275 136 487 275 137 487 minecraft:brown_terracotta
setblock 275 136 491 minecraft:bone_block
fill 275 136 492 275 139 492 minecraft:brown_terracotta
setblock 275 136 496 minecraft:bone_block
fill 275 136 497 276 138 497 minecraft:brown_terracotta
setblock 276 136 465 minecraft:bone_block
fill 276 136 466 276 139 466 minecraft:brown_terracotta
setblock 276 136 470 minecraft:bone_block
fill 276 136 471 276 139 471 minecraft:brown_terracotta
setblock 276 136 475 minecraft:bone_block
fill 276 136 476 276 139 476 minecraft:brown_terracotta
setblock 276 136 480 minecraft:bone_block
fill 276 136 481 276 139 481 minecraft:brown_terracotta
setblock 276 136 485 minecraft:bone_block
fill 276 136 486 276 139 486 minecraft:brown_terracotta
setblock 276 136 490 minecraft:bone_block
fill 276 136 491 276 139 491 minecraft:brown_terracotta
setblock 276 136 494 minecraft:brown_terracotta
setblock 276 136 495 minecraft:bone_block
fill 276 136 496 276 139 496 minecraft:brown_terracotta
fill 276 136 498 276 136 499 minecraft:brown_terracotta
setblock 276 136 500 minecraft:bone_block
fill 276 136 501 276 139 501 minecraft:brown_terracotta
setblock 236 137 464 minecraft:bone_block
fill 236 137 465 236 140 465 minecraft:brown_terracotta
setblock 236 137 469 minecraft:bone_block
fill 236 137 470 236 140 470 minecraft:brown_terracotta
setblock 236 137 474 minecraft:bone_block
fill 236 137 475 236 140 475 minecraft:brown_terracotta
setblock 236 137 479 minecraft:bone_block
fill 236 137 480 236 139 480 minecraft:brown_terracotta
setblock 236 137 484 minecraft:bone_block
fill 236 137 485 236 139 485 minecraft:brown_terracotta
setblock 236 137 489 minecraft:bone_block
fill 236 137 490 236 137 493 minecraft:brown_terracotta
setblock 236 137 494 minecraft:bone_block
fill 236 137 495 236 140 495 minecraft:brown_terracotta
setblock 236 137 499 minecraft:bone_block
fill 236 137 500 236 140 500 minecraft:brown_terracotta
setblock 236 137 504 minecraft:bone_block
fill 237 137 464 237 140 464 minecraft:brown_terracotta
setblock 237 137 468 minecraft:bone_block
fill 237 137 469 237 140 469 minecraft:brown_terracotta
setblock 237 137 473 minecraft:bone_block
fill 237 137 474 237 140 474 minecraft:brown_terracotta
fill 237 137 476 237 138 476 minecraft:brown_terracotta
setblock 237 137 488 minecraft:bone_block
fill 237 137 489 237 140 489 minecraft:brown_terracotta
setblock 237 137 493 minecraft:bone_block
fill 237 137 494 237 140 494 minecraft:brown_terracotta
setblock 237 137 498 minecraft:bone_block
fill 237 137 499 237 140 499 minecraft:brown_terracotta
setblock 237 137 503 minecraft:bone_block
fill 237 137 504 240 137 504 minecraft:brown_terracotta
setblock 238 137 467 minecraft:bone_block
fill 238 137 468 238 138 468 minecraft:brown_terracotta
setblock 238 137 472 minecraft:bone_block
setblock 238 137 473 minecraft:brown_terracotta
setblock 238 137 488 minecraft:brown_terracotta
setblock 238 137 492 minecraft:bone_block
fill 238 137 493 238 140 493 minecraft:brown_terracotta
setblock 238 137 497 minecraft:bone_block
fill 238 137 498 238 140 498 minecraft:brown_terracotta
setblock 238 137 502 minecraft:bone_block
fill 238 137 503 238 140 503 minecraft:brown_terracotta
setblock 239 137 466 minecraft:bone_block
setblock 239 137 491 minecraft:bone_block
fill 239 137 492 239 138 492 minecraft:brown_terracotta
setblock 239 137 496 minecraft:bone_block
setblock 240 137 465 minecraft:bone_block
setblock 241 137 464 minecraft:bone_block
setblock 241 137 465 minecraft:brown_terracotta
setblock 241 137 504 minecraft:bone_block
setblock 242 137 464 minecraft:brown_terracotta
fill 242 137 504 242 138 504 minecraft:brown_terracotta
setblock 255 137 464 minecraft:brown_terracotta
setblock 255 137 465 minecraft:bone_block
setblock 256 137 464 minecraft:bone_block
fill 256 137 465 256 138 465 minecraft:brown_terracotta
setblock 256 137 504 minecraft:bone_block
fill 257 137 464 260 137 464 minecraft:brown_terracotta
fill 257 137 504 257 138 504 minecraft:brown_terracotta
fill 258 137 465 259 137 465 minecraft:brown_terracotta
setblock 260 137 465 minecraft:bone_block
setblock 261 137 464 minecraft:bone_block
setblock 261 137 465 minecraft:brown_terracotta
setblock 262 137 464 minecraft:brown_terracotta
setblock 267 137 464 minecraft:brown_terracotta
setblock 270 137 464 minecraft:brown_terracotta
setblock 270 137 465 minecraft:bone_block
setblock 271 137 464 minecraft:bone_block
fill 271 137 465 271 140 465 minecraft:brown_terracotta
fill 272 137 464 272 140 464 minecraft:brown_terracotta
fill 272 137 504 272 140 504 minecraft:brown_terracotta
setblock 273 137 467 minecraft:bone_block
fill 273 137 468 273 139 468 minecraft:brown_terracotta
setblock 273 137 472 minecraft:bone_block
fill 273 137 473 273 140 473 minecraft:brown_terracotta
setblock 274 137 466 minecraft:bone_block
fill 274 137 467 274 140 467 minecraft:brown_terracotta
setblock 274 137 471 minecraft:bone_block
fill 274 137 472 274 140 472 minecraft:brown_terracotta
setblock 274 137 476 minecraft:bone_block
setblock 275 137 465 minecraft:bone_block
fill 275 137 466 275 140 466 minecraft:brown_terracotta
setblock 275 137 470 minecraft:bone_block
fill 275 137 471 275 140 471 minecraft:brown_terracotta
setblock 275 137 475 minecraft:bone_block
fill 275 137 476 275 140 476 minecraft:brown_terracotta
setblock 275 137 479 minecraft:brown_terracotta
setblock 275 137 490 minecraft:bone_block
fill 275 137 491 275 140 491 minecraft:brown_terracotta
fill 275 137 493 275 137 494 minecraft:brown_terracotta
setblock 275 137 495 minecraft:bone_block
fill 275 137 496 275 140 496 minecraft:brown_terracotta
fill 275 137 498 275 137 499 minecraft:brown_terracotta
fill 275 137 503 275 138 503 minecraft:brown_terracotta
setblock 276 137 464 minecraft:bone_block
fill 276 137 465 276 140 465 minecraft:brown_terracotta
setblock 276 137 469 minecraft:bone_block
fill 276 137 470 276 140 470 minecraft:brown_terracotta
setblock 276 137 474 minecraft:bone_block
fill 276 137 475 276 140 475 minecraft:brown_terracotta
setblock 276 137 479 minecraft:bone_block
fill 276 137 480 276 140 480 minecraft:brown_terracotta
setblock 276 137 484 minecraft:bone_block
fill 276 137 485 276 139 485 minecraft:brown_terracotta
setblock 276 137 489 minecraft:bone_block
fill 276 137 490 276 140 490 minecraft:brown_terracotta
setblock 276 137 494 minecraft:bone_block
fill 276 137 495 276 140 495 minecraft:brown_terracotta
setblock 276 137 498 minecraft:brown_terracotta
setblock 276 137 499 minecraft:bone_block
fill 276 137 500 276 140 500 minecraft:brown_terracotta
setblock 276 137 504 minecraft:bone_block
fill 236 138 464 236 141 464 minecraft:brown_terracotta
setblock 236 138 468 minecraft:bone_block
fill 236 138 469 236 141 469 minecraft:brown_terracotta
setblock 236 138 473 minecraft:bone_block
fill 236 138 474 236 141 474 minecraft:brown_terracotta
setblock 236 138 477 minecraft:brown_terracotta
setblock 236 138 478 minecraft:bone_block
fill 236 138 479 236 141 479 minecraft:brown_terracotta
setblock 236 138 483 minecraft:bone_block
fill 236 138 484 236 139 484 minecraft:brown_terracotta
setblock 236 138 488 minecraft:bone_block
fill 236 138 489 236 138 492 minecraft:brown_terracotta
setblock 236 138 493 minecraft:bone_block
fill 236 138 494 236 141 494 minecraft:brown_terracotta
setblock 236 138 498 minecraft:bone_block
fill 236 138 499 236 141 499 minecraft:brown_terracotta
setblock 236 138 503 minecraft:bone_block
fill 236 138 504 239 138 504 minecraft:brown_terracotta
setblock 237 138 467 minecraft:bone_block
fill 237 138 468 237 140 468 minecraft:brown_terracotta
setblock 237 138 472 minecraft:bone_block
fill 237 138 473 237 141 473 minecraft:brown_terracotta
setblock 237 138 487 minecraft:bone_block
fill 237 138 488 237 139 488 minecraft:brown_terracotta
setblock 237 138 492 minecraft:bone_block
fill 237 138 493 237 141 493 minecraft:brown_terracotta
setblock 237 138 497 minecraft:bone_block
fill 237 138 498 237 141 498 minecraft:brown_terracotta
setblock 237 138 501 minecraft:brown_terracotta
setblock 237 138 502 minecraft:bone_block
fill 237 138 503 237 141 503 minecraft:brown_terracotta
setblock 238 138 466 minecraft:bone_block
setblock 238 138 467 minecraft:brown_terracotta
setblock 238 138 471 minecraft:bone_block
setblock 238 138 472 minecraft:brown_terracotta
setblock 238 138 491 minecraft:bone_block
fill 238 138 492 238 141 492 minecraft:brown_terracotta
setblock 238 138 496 minecraft:bone_block
fill 238 138 497 238 141 497 minecraft:brown_terracotta
setblock 238 138 501 minecraft:bone_block
setblock 239 138 465 minecraft:bone_block
setblock 239 138 495 minecraft:bone_block
setblock 239 138 496 minecraft:brown_terracotta
setblock 240 138 464 minecraft:bone_block
setblock 240 138 504 minecraft:bone_block
setblock 241 138 464 minecraft:brown_terracotta
fill 241 138 504 241 139 504 minecraft:brown_terracotta
fill 251 138 465 251 142 465 minecraft:bone_block
setblock 255 138 464 minecraft:bone_block
setblock 255 138 504 minecraft:bone_block
fill 256 138 464 259 138 464 minecraft:brown_terracotta
setblock 256 138 504 minecraft:brown_terracotta
setblock 258 138 465 minecraft:brown_terracotta
setblock 260 138 464 minecraft:bone_block
setblock 261 138 464 minecraft:brown_terracotta
setblock 269 138 464 minecraft:brown_terracotta
setblock 270 138 464 minecraft:bone_block
fill 270 138 465 270 139 465 minecraft:brown_terracotta
fill 271 138 464 271 141 464 minecraft:brown_terracotta
setblock 273 138 466 minecraft:bone_block
setblock 273 138 467 minecraft:brown_terracotta
setblock 273 138 470 minecraft:brown_terracotta
setblock 273 138 471 minecraft:bone_block
fill 273 138 472 273 141 472 minecraft:brown_terracotta
fill 273 138 474 273 139 474 minecraft:brown_terracotta
setblock 274 138 465 minecraft:bone_block
fill 274 138 466 274 141 466 minecraft:brown_terracotta
setblock 274 138 470 minecraft:bone_block
fill 274 138 471 274 141 471 minecraft:brown_terracotta
setblock 274 138 475 minecraft:bone_block
fill 274 138 476 274 141 476 minecraft:brown_terracotta
setblock 275 138 464 minecraft:bone_block
fill 275 138 465 275 141 465 minecraft:brown_terracotta
setblock 275 138 469 minecraft:bone_block
fill 275 138 470 275 141 470 minecraft:brown_terracotta
setblock 275 138 474 minecraft:bone_block
fill 275 138 475 275 141 475 minecraft:brown_terracotta
setblock 275 138 479 minecraft:bone_block
setblock 275 138 489 minecraft:bone_block
fill 275 138 490 275 140 490 minecraft:brown_terracotta
setblock 275 138 493 minecraft:brown_terracotta
setblock 275 138 494 minecraft:bone_block
fill 275 138 495 275 141 495 minecraft:brown_terracotta
setblock 275 138 498 minecraft:brown_terracotta
setblock 275 138 499 minecraft:bone_block
fill 275 138 500 275 139 502 minecraft:brown_terracotta
setblock 275 138 504 minecraft:bone_block
fill 276 138 464 276 141 464 minecraft:brown_terracotta
setblock 276 138 468 minecraft:bone_block
fill 276 138 469 276 141 469 minecraft:brown_terracotta
setblock 276 138 473 minecraft:bone_block
fill 276 138 474 276 141 474 minecraft:brown_terracotta
setblock 276 138 478 minecraft:bone_block
fill 276 138 479 276 141 479 minecraft:brown_terracotta
setblock 276 138 483 minecraft:bone_block
setblock 276 138 484 minecraft:brown_terracotta
setblock 276 138 488 minecraft:bone_block
fill 276 138 489 276 141 489 minecraft:brown_terracotta
setblock 276 138 493 minecraft:bone_block
fill 276 138 494 276 141 494 minecraft:brown_terracotta
setblock 276 138 498 minecraft:bone_block
fill 276 138 499 276 141 499 minecraft:brown_terracotta
setblock 276 138 503 minecraft:bone_block
fill 276 138 504 276 141 504 minecraft:brown_terracotta
setblock 236 139 467 minecraft:bone_block
fill 236 139 468 236 142 468 minecraft:brown_terracotta
setblock 236 139 472 minecraft:bone_block
fill 236 139 473 236 142 473 minecraft:brown_terracotta
setblock 236 139 477 minecraft:bone_block
fill 236 139 478 236 142 478 minecraft:brown_terracotta
setblock 236 139 487 minecraft:bone_block
fill 236 139 488 236 139 491 minecraft:brown_terracotta
setblock 236 139 492 minecraft:bone_block
fill 236 139 493 236 142 493 minecraft:brown_terracotta
setblock 236 139 497 minecraft:bone_block
fill 236 139 498 236 142 498 minecraft:brown_terracotta
setblock 236 139 502 minecraft:bone_block
fill 236 139 503 236 141 504 minecraft:brown_terracotta
setblock 237 139 466 minecraft:bone_block
fill 237 139 467 237 140 467 minecraft:brown_terracotta
setblock 237 139 471 minecraft:bone_block
fill 237 139 472 237 141 472 minecraft:brown_terracotta
setblock 237 139 476 minecraft:bone_block
setblock 237 139 487 minecraft:brown_terracotta
setblock 237 139 491 minecraft:bone_block
fill 237 139 492 237 142 492 minecraft:brown_terracotta
setblock 237 139 496 minecraft:bone_block
fill 237 139 497 237 142 497 minecraft:brown_terracotta
setblock 237 139 501 minecraft:bone_block
fill 237 139 502 237 142 502 minecraft:brown_terracotta
fill 237 139 504 238 139 504 minecraft:brown_terracotta
setblock 238 139 465 minecraft:bone_block
setblock 238 139 490 minecraft:bone_block
fill 238 139 491 238 140 491 minecraft:brown_terracotta
setblock 238 139 494 minecraft:brown_terracotta
setblock 238 139 495 minecraft:bone_block
fill 238 139 496 238 142 496 minecraft:brown_terracotta
setblock 238 139 500 minecraft:bone_block
setblock 238 139 501 minecraft:brown_terracotta
setblock 239 139 464 minecraft:bone_block
setblock 239 139 494 minecraft:bone_block
setblock 239 139 495 minecraft:brown_terracotta
setblock 239 139 504 minecraft:bone_block
setblock 240 139 464 minecraft:brown_terracotta
fill 240 139 504 240 140 504 minecraft:brown_terracotta
setblock 254 139 464 minecraft:bone_block
fill 255 139 464 258 139 464 minecraft:brown_terracotta
fill 258 139 467 258 140 467 minecraft:soul_soil
setblock 259 139 464 minecraft:bone_block
fill 259 139 466 259 140 466 minecraft:soul_soil
fill 259 139 468 259 140 468 minecraft:soul_soil
fill 260 139 467 260 140 467 minecraft:soul_soil
setblock 269 139 464 minecraft:bone_block
fill 270 139 464 270 142 464 minecraft:brown_terracotta
setblock 272 139 466 minecraft:bone_block
setblock 273 139 465 minecraft:bone_block
fill 273 139 466 273 140 466 minecraft:brown_terracotta
setblock 273 139 470 minecraft:bone_block
fill 273 139 471 273 141 471 minecraft:brown_terracotta
setblock 274 139 464 minecraft:bone_block
fill 274 139 465 274 142 465 minecraft:brown_terracotta
setblock 274 139 469 minecraft:bone_block
fill 274 139 470 274 142 470 minecraft:brown_terracotta
setblock 274 139 474 minecraft:bone_block
fill 274 139 475 274 142 475 minecraft:brown_terracotta
setblock 274 139 504 minecraft:bone_block
fill 275 139 464 275 142 464 minecraft:brown_terracotta
setblock 275 139 468 minecraft:bone_block
fill 275 139 469 275 142 469 minecraft:brown_terracotta
setblock 275 139 473 minecraft:bone_block
fill 275 139 474 275 142 474 minecraft:brown_terracotta
setblock 275 139 477 minecraft:brown_terracotta
setblock 275 139 478 minecraft:bone_block
setblock 275 139 479 minecraft:brown_terracotta
setblock 275 139 489 minecraft:brown_terracotta
setblock 275 139 493 minecraft:bone_block
fill 275 139 494 275 142 494 minecraft:brown_terracotta
setblock 275 139 497 minecraft:brown_terracotta
setblock 275 139 498 minecraft:bone_block
fill 275 139 499 275 142 499 minecraft:brown_terracotta
setblock 275 139 503 minecraft:bone_block
fill 275 139 504 275 142 504 minecraft:brown_terracotta
setblock 276 139 467 minecraft:bone_block
fill 276 139 468 276 142 468 minecraft:brown_terracotta
setblock 276 139 472 minecraft:bone_block
fill 276 139 473 276 142 473 minecraft:brown_terracotta
setblock 276 139 477 minecraft:bone_block
fill 276 139 478 276 142 478 minecraft:brown_terracotta
setblock 276 139 482 minecraft:bone_block
setblock 276 139 487 minecraft:bone_block
fill 276 139 488 276 140 488 minecraft:brown_terracotta
setblock 276 139 492 minecraft:bone_block
fill 276 139 493 276 142 493 minecraft:brown_terracotta
setblock 276 139 497 minecraft:bone_block
fill 276 139 498 276 142 498 minecraft:brown_terracotta
setblock 276 139 502 minecraft:bone_block
fill 276 139 503 276 142 503 minecraft:brown_terracotta
setblock 236 140 466 minecraft:bone_block
fill 236 140 467 236 142 467 minecraft:brown_terracotta
setblock 236 140 471 minecraft:bone_block
fill 236 140 472 236 143 472 minecraft:brown_terracotta
setblock 236 140 476 minecraft:bone_block
fill 236 140 477 236 143 477 minecraft:brown_terracotta
setblock 236 140 486 minecraft:bone_block
fill 236 140 487 236 140 490 minecraft:brown_terracotta
setblock 236 140 491 minecraft:bone_block
fill 236 140 492 236 143 492 minecraft:brown_terracotta
setblock 236 140 496 minecraft:bone_block
fill 236 140 497 236 143 497 minecraft:brown_terracotta
setblock 236 140 501 minecraft:bone_block
fill 236 140 502 236 143 502 minecraft:brown_terracotta
setblock 237 140 466 minecraft:brown_terracotta
setblock 237 140 470 minecraft:bone_block
fill 237 140 471 237 141 471 minecraft:brown_terracotta
setblock 237 140 475 minecraft:bone_block
setblock 237 140 490 minecraft:bone_block
fill 237 140 491 237 142 491 minecraft:brown_terracotta
setblock 237 140 495 minecraft:bone_block
fill 237 140 496 237 143 496 minecraft:brown_terracotta
setblock 237 140 500 minecraft:bone_block
fill 237 140 501 237 143 501 minecraft:brown_terracotta
setblock 237 140 504 minecraft:brown_terracotta
setblock 238 140 464 minecraft:bone_block
setblock 238 140 494 minecraft:bone_block
fill 238 140 495 238 143 495 minecraft:brown_terracotta
setblock 238 140 499 minecraft:bone_block
setblock 238 140 500 minecraft:brown_terracotta
setblock 238 140 504 minecraft:bone_block
fill 239 140 504 239 142 504 minecraft:brown_terracotta
fill 269 140 464 269 143 464 minecraft:brown_terracotta
setblock 272 140 465 minecraft:bone_block
setblock 272 140 466 minecraft:brown_terracotta
setblock 273 140 464 minecraft:bone_block
fill 273 140 465 273 143 465 minecraft:brown_terracotta
setblock 273 140 469 minecraft:bone_block
setblock 273 140 470 minecraft:brown_terracotta
setblock 273 140 474 minecraft:bone_block
setblock 273 140 504 minecraft:bone_block
fill 274 140 464 274 143 464 minecraft:brown_terracotta
setblock 274 140 468 minecraft:bone_block
fill 274 140 469 274 142 469 minecraft:brown_terracotta
setblock 274 140 473 minecraft:bone_block
fill 274 140 474 274 143 474 minecraft:brown_terracotta
setblock 274 140 503 minecraft:bone_block
fill 274 140 504 274 143 504 minecraft:brown_terracotta
setblock 275 140 467 minecraft:bone_block
fill 275 140 468 275 143 468 minecraft:brown_terracotta
setblock 275 140 472 minecraft:bone_block
fill 275 140 473 275 143 473 minecraft:brown_terracotta
setblock 275 140 477 minecraft:bone_block
fill 275 140 478 275 143 478 minecraft:brown_terracotta
setblock 275 140 492 minecraft:bone_block
fill 275 140 493 275 143 493 minecraft:brown_terracotta
setblock 275 140 497 minecraft:bone_block
fill 275 140 498 275 143 498 minecraft:brown_terracotta
fill 275 140 500 275 140 501 minecraft:brown_terracotta
setblock 275 140 502 minecraft:bone_block
fill 275 140 503 275 143 503 minecraft:brown_terracotta
setblock 276 140 466 minecraft:bone_block
fill 276 140 467 276 143 467 minecraft:brown_terracotta
setblock 276 140 471 minecraft:bone_block
fill 276 140 472 276 143 472 minecraft:brown_terracotta
setblock 276 140 476 minecraft:bone_block
fill 276 140 477 276 143 477 minecraft:brown_terracotta
setblock 276 140 481 minecraft:bone_block
setblock 276 140 487 minecraft:brown_terracotta
setblock 276 140 491 minecraft:bone_block
fill 276 140 492 276 143 492 minecraft:brown_terracotta
setblock 276 140 496 minecraft:bone_block
fill 276 140 497 276 143 497 minecraft:brown_terracotta
setblock 276 140 501 minecraft:bone_block
fill 276 140 502 276 143 502 minecraft:brown_terracotta
setblock 236 141 465 minecraft:bone_block
fill 236 141 466 236 142 466 minecraft:brown_terracotta
setblock 236 141 470 minecraft:bone_block
fill 236 141 471 236 144 471 minecraft:brown_terracotta
setblock 236 141 475 minecraft:bone_block
fill 236 141 476 236 144 476 minecraft:brown_terracotta
fill 236 141 487 236 141 489 minecraft:brown_terracotta
setblock 236 141 490 minecraft:bone_block
fill 236 141 491 236 144 491 minecraft:brown_terracotta
setblock 236 141 495 minecraft:bone_block
fill 236 141 496 236 144 496 minecraft:brown_terracotta
setblock 236 141 500 minecraft:bone_block
fill 236 141 501 236 144 501 minecraft:brown_terracotta
setblock 237 141 464 minecraft:bone_block
setblock 237 141 470 minecraft:brown_terracotta
setblock 237 141 474 minecraft:bone_block
setblock 237 141 490 minecraft:brown_terracotta
setblock 237 141 494 minecraft:bone_block
fill 237 141 495 237 144 495 minecraft:brown_terracotta
setblock 237 141 499 minecraft:bone_block
fill 237 141 500 237 144 500 minecraft:brown_terracotta
setblock 237 141 504 minecraft:bone_block
setblock 238 141 493 minecraft:bone_block
fill 238 141 494 238 142 494 minecraft:brown_terracotta
setblock 238 141 498 minecraft:bone_block
fill 238 141 499 238 142 499 minecraft:brown_terracotta
setblock 238 141 503 minecraft:bone_block
fill 238 141 504 238 144 504 minecraft:brown_terracotta
fill 250 141 465 250 142 465 minecraft:bone_block
fill 251 141 464 251 142 464 minecraft:bone_block
fill 251 141 466 251 142 466 minecraft:bone_block
fill 252 141 465 252 142 465 minecraft:bone_block
setblock 271 141 465 minecraft:bone_block
setblock 272 141 464 minecraft:bone_block
fill 272 141 465 272 144 465 minecraft:brown_terracotta
setblock 272 141 504 minecraft:bone_block
fill 273 141 464 273 144 464 minecraft:brown_terracotta
setblock 273 141 473 minecraft:bone_block
fill 273 141 504 273 144 504 minecraft:brown_terracotta
setblock 274 141 467 minecraft:bone_block
fill 274 141 468 274 142 468 minecraft:brown_terracotta
setblock 274 141 472 minecraft:bone_block
fill 274 141 473 274 144 473 minecraft:brown_terracotta
fill 274 141 503 274 144 503 minecraft:brown_terracotta
setblock 275 141 466 minecraft:bone_block
fill 275 141 467 275 143 467 minecraft:brown_terracotta
setblock 275 141 471 minecraft:bone_block
fill 275 141 472 275 144 472 minecraft:brown_terracotta
setblock 275 141 476 minecraft:bone_block
fill 275 141 477 275 144 477 minecraft:brown_terracotta
setblock 275 141 491 minecraft:bone_block
setblock 275 141 492 minecraft:brown_terracotta
setblock 275 141 496 minecraft:bone_block
fill 275 141 497 275 144 497 minecraft:brown_terracotta
setblock 275 141 500 minecraft:brown_terracotta
setblock 275 141 501 minecraft:bone_block
fill 275 141 502 275 144 502 minecraft:brown_terracotta
setblock 276 141 465 minecraft:bone_block
fill 276 141 466 276 144 466 minecraft:brown_terracotta
setblock 276 141 470 minecraft:bone_block
fill 276 141 471 276 144 471 minecraft:brown_terracotta
setblock 276 141 475 minecraft:bone_block
fill 276 141 476 276 144 476 minecraft:brown_terracotta
setblock 276 141 480 minecraft:bone_block
setblock 276 141 490 minecraft:bone_block
fill 276 141 491 276 143 491 minecraft:brown_terracotta
setblock 276 141 495 minecraft:bone_block
fill 276 141 496 276 144 496 minecraft:brown_terracotta
setblock 276 141 500 minecraft:bone_block
fill 276 141 501 276 144 501 minecraft:brown_terracotta
setblock 236 142 464 minecraft:bone_block
setblock 236 142 465 minecraft:brown_terracotta
setblock 236 142 469 minecraft:bone_block
fill 236 142 470 236 143 470 minecraft:brown_terracotta
setblock 236 142 474 minecraft:bone_block
fill 236 142 475 236 144 475 minecraft:brown_terracotta
setblock 236 142 479 minecraft:bone_block
setblock 236 142 488 minecraft:brown_terracotta
setblock 236 142 489 minecraft:bone_block
fill 236 142 490 236 144 490 minecraft:brown_terracotta
setblock 236 142 494 minecraft:bone_block
fill 236 142 495 236 144 495 minecraft:brown_terracotta
setblock 236 142 499 minecraft:bone_block
fill 236 142 500 236 144 500 minecraft:brown_terracotta
setblock 236 142 503 minecraft:brown_terracotta
setblock 236 142 504 minecraft:bone_block
setblock 237 142 493 minecraft:bone_block
fill 237 142 494 237 144 494 minecraft:brown_terracotta
setblock 237 142 498 minecraft:bone_block
fill 237 142 499 237 144 499 minecraft:brown_terracotta
setblock 237 142 503 minecraft:bone_block
fill 237 142 504 237 144 504 minecraft:brown_terracotta
setblock 238 142 497 minecraft:bone_block
fill 238 142 498 238 144 498 minecraft:brown_terracotta
setblock 271 142 464 minecraft:bone_block
setblock 271 142 465 minecraft:brown_terracotta
setblock 271 142 504 minecraft:bone_block
fill 272 142 464 272 144 464 minecraft:brown_terracotta
fill 272 142 504 272 144 504 minecraft:brown_terracotta
setblock 274 142 471 minecraft:bone_block
fill 274 142 472 274 144 472 minecraft:brown_terracotta
setblock 274 142 476 minecraft:bone_block
setblock 275 142 465 minecraft:bone_block
fill 275 142 466 275 143 466 minecraft:brown_terracotta
setblock 275 142 470 minecraft:bone_block
fill 275 142 471 275 144 471 minecraft:brown_terracotta
setblock 275 142 475 minecraft:bone_block
fill 275 142 476 275 144 476 minecraft:brown_terracotta
setblock 275 142 495 minecraft:bone_block
fill 275 142 496 275 144 496 minecraft:brown_terracotta
setblock 275 142 500 minecraft:bone_block
fill 275 142 501 275 144 501 minecraft:brown_terracotta
setblock 276 142 464 minecraft:bone_block
fill 276 142 465 276 144 465 minecraft:brown_terracotta
setblock 276 142 469 minecraft:bone_block
fill 276 142 470 276 144 470 minecraft:brown_terracotta
setblock 276 142 474 minecraft:bone_block
fill 276 142 475 276 144 475 minecraft:brown_terracotta
setblock 276 142 479 minecraft:bone_block
fill 276 142 480 276 144 480 minecraft:brown_terracotta
setblock 276 142 490 minecraft:brown_terracotta
setblock 276 142 494 minecraft:bone_block
fill 276 142 495 276 144 495 minecraft:brown_terracotta
setblock 276 142 499 minecraft:bone_block
fill 276 142 500 276 144 500 minecraft:brown_terracotta
setblock 276 142 504 minecraft:bone_block
setblock 236 143 469 minecraft:brown_terracotta
setblock 236 143 473 minecraft:bone_block
fill 236 143 474 236 144 474 minecraft:brown_terracotta
setblock 236 143 478 minecraft:bone_block
fill 236 143 479 236 144 479 minecraft:brown_terracotta
setblock 236 143 489 minecraft:brown_terracotta
setblock 236 143 493 minecraft:bone_block
fill 236 143 494 236 144 494 minecraft:brown_terracotta
setblock 236 143 498 minecraft:bone_block
fill 236 143 499 236 144 499 minecraft:brown_terracotta
setblock 236 143 503 minecraft:bone_block
fill 236 143 504 236 144 504 minecraft:brown_terracotta
setblock 237 143 492 minecraft:bone_block
fill 237 143 493 237 144 493 minecraft:brown_terracotta
setblock 237 143 497 minecraft:bone_block
fill 237 143 498 237 144 498 minecraft:brown_terracotta
setblock 237 143 502 minecraft:bone_block
setblock 237 143 503 minecraft:brown_terracotta
setblock 238 143 496 minecraft:bone_block
fill 238 143 497 238 144 497 minecraft:brown_terracotta
fill 242 143 497 246 144 501 minecraft:soul_soil
fill 244 143 502 244 143 503 minecraft:soul_soil
setblock 270 143 464 minecraft:bone_block
setblock 270 143 504 minecraft:bone_block
fill 271 143 464 271 144 464 minecraft:brown_terracotta
fill 271 143 504 271 144 504 minecraft:brown_terracotta
fill 273 143 503 273 144 503 minecraft:brown_terracotta
setblock 274 143 465 minecraft:bone_block
setblock 274 143 470 minecraft:bone_block
setblock 274 143 471 minecraft:brown_terracotta
setblock 274 143 475 minecraft:bone_block
setblock 274 143 476 minecraft:brown_terracotta
setblock 275 143 464 minecraft:bone_block
setblock 275 143 465 minecraft:brown_terracotta
setblock 275 143 469 minecraft:bone_block
fill 275 143 470 275 144 470 minecraft:brown_terracotta
setblock 275 143 474 minecraft:bone_block
fill 275 143 475 275 144 475 minecraft:brown_terracotta
setblock 275 143 494 minecraft:bone_block
fill 275 143 495 275 144 495 minecraft:brown_terracotta
setblock 275 143 499 minecraft:bone_block
fill 275 143 500 275 144 500 minecraft:brown_terracotta
setblock 275 143 504 minecraft:bone_block
fill 276 143 464 276 144 464 minecraft:brown_terracotta
setblock 276 143 468 minecraft:bone_block
fill 276 143 469 276 144 469 minecraft:brown_terracotta
setblock 276 143 473 minecraft:bone_block
fill 276 143 474 276 144 474 minecraft:brown_terracotta
setblock 276 143 478 minecraft:bone_block
fill 276 143 479 276 144 479 minecraft:brown_terracotta
setblock 276 143 493 minecraft:bone_block
fill 276 143 494 276 144 494 minecraft:brown_terracotta
setblock 276 143 498 minecraft:bone_block
fill 276 143 499 276 144 499 minecraft:brown_terracotta
setblock 276 143 503 minecraft:bone_block
fill 276 143 504 276 144 504 minecraft:brown_terracotta
setblock 236 144 472 minecraft:bone_block
setblock 236 144 473 minecraft:brown_terracotta
setblock 236 144 477 minecraft:bone_block
setblock 236 144 478 minecraft:brown_terracotta
setblock 236 144 492 minecraft:bone_block
setblock 236 144 493 minecraft:brown_terracotta
setblock 236 144 497 minecraft:bone_block
setblock 236 144 498 minecraft:brown_terracotta
setblock 236 144 502 minecraft:bone_block
setblock 236 144 503 minecraft:brown_terracotta
setblock 237 144 492 minecraft:brown_terracotta
setblock 237 144 496 minecraft:bone_block
setblock 237 144 497 minecraft:brown_terracotta
setblock 237 144 501 minecraft:bone_block
setblock 237 144 502 minecraft:brown_terracotta
setblock 238 144 466 minecraft:light[level=12]
setblock 238 144 474 minecraft:light[level=12]
setblock 238 144 482 minecraft:light[level=12]
setblock 238 144 490 minecraft:light[level=12]
setblock 238 144 496 minecraft:brown_terracotta
setblock 246 144 466 minecraft:light[level=12]
setblock 246 144 474 minecraft:light[level=12]
setblock 246 144 482 minecraft:light[level=12]
setblock 246 144 490 minecraft:light[level=12]
setblock 254 144 466 minecraft:light[level=12]
setblock 254 144 474 minecraft:light[level=12]
setblock 254 144 482 minecraft:light[level=12]
setblock 254 144 490 minecraft:light[level=12]
setblock 254 144 498 minecraft:light[level=12]
setblock 262 144 466 minecraft:light[level=12]
setblock 262 144 474 minecraft:light[level=12]
setblock 262 144 482 minecraft:light[level=12]
setblock 262 144 490 minecraft:light[level=12]
setblock 262 144 498 minecraft:light[level=12]
setblock 269 144 464 minecraft:bone_block
setblock 269 144 504 minecraft:bone_block
setblock 270 144 464 minecraft:brown_terracotta
setblock 270 144 466 minecraft:light[level=12]
setblock 270 144 474 minecraft:light[level=12]
setblock 270 144 482 minecraft:light[level=12]
setblock 270 144 490 minecraft:light[level=12]
setblock 270 144 498 minecraft:light[level=12]
setblock 270 144 504 minecraft:brown_terracotta
setblock 272 144 503 minecraft:brown_terracotta
setblock 273 144 465 minecraft:bone_block
setblock 274 144 464 minecraft:bone_block
setblock 274 144 465 minecraft:brown_terracotta
setblock 274 144 474 minecraft:bone_block
setblock 274 144 475 minecraft:brown_terracotta
fill 274 144 497 274 144 498 minecraft:brown_terracotta
setblock 274 144 499 minecraft:bone_block
setblock 274 144 500 minecraft:brown_terracotta
setblock 274 144 504 minecraft:bone_block
setblock 275 144 464 minecraft:brown_terracotta
setblock 275 144 468 minecraft:bone_block
setblock 275 144 469 minecraft:brown_terracotta
setblock 275 144 473 minecraft:bone_block
setblock 275 144 474 minecraft:brown_terracotta
setblock 275 144 478 minecraft:bone_block
setblock 275 144 494 minecraft:brown_terracotta
setblock 275 144 498 minecraft:bone_block
setblock 275 144 499 minecraft:brown_terracotta
setblock 275 144 503 minecraft:bone_block
setblock 275 144 504 minecraft:brown_terracotta
setblock 276 144 467 minecraft:bone_block
setblock 276 144 468 minecraft:brown_terracotta
setblock 276 144 472 minecraft:bone_block
setblock 276 144 473 minecraft:brown_terracotta
setblock 276 144 477 minecraft:bone_block
setblock 276 144 478 minecraft:brown_terracotta
setblock 276 144 492 minecraft:bone_block
setblock 276 144 493 minecraft:brown_terracotta
setblock 276 144 497 minecraft:bone_block
setblock 276 144 498 minecraft:brown_terracotta
setblock 276 144 502 minecraft:bone_block
setblock 276 144 503 minecraft:brown_terracotta
fill 246 149 481 248 149 483 minecraft:redstone_block
fill 249 149 490 251 149 492 minecraft:redstone_block
fill 253 149 482 255 149 484 minecraft:redstone_block
fill 235 150 484 248 150 488 minecraft:bone_block
fill 235 150 489 235 192 489 minecraft:brown_terracotta
fill 248 150 468 252 150 480 minecraft:bone_block
fill 248 150 489 248 150 504 minecraft:bone_block
fill 249 150 481 252 150 484 minecraft:bone_block
fill 249 150 488 252 150 489 minecraft:bone_block
fill 249 150 493 252 150 504 minecraft:bone_block
fill 252 150 485 268 150 487 minecraft:bone_block
fill 252 150 490 252 150 492 minecraft:bone_block
fill 253 150 488 268 150 488 minecraft:bone_block
fill 256 150 484 268 150 484 minecraft:bone_block
fill 235 151 484 244 151 484 minecraft:white_terracotta
fill 235 151 485 247 151 487 minecraft:bone_block
fill 235 151 488 247 151 488 minecraft:white_terracotta
fill 236 151 464 244 151 483 minecraft:soul_soil
fill 236 151 489 247 151 504 minecraft:soul_soil
fill 245 151 464 247 151 479 minecraft:soul_soil
fill 245 151 480 245 151 484 minecraft:shroomlight
fill 246 151 480 249 151 480 minecraft:shroomlight
fill 246 151 481 248 151 483 minecraft:soul_soil
fill 246 151 484 252 151 484 minecraft:shroomlight
fill 248 151 464 276 151 467 minecraft:soul_soil
fill 248 151 468 248 151 479 minecraft:white_terracotta
fill 248 151 485 248 151 493 minecraft:shroomlight
fill 248 151 494 248 151 504 minecraft:white_terracotta
fill 249 151 468 251 151 479 minecraft:bone_block
fill 249 151 481 249 151 483 minecraft:shroomlight
fill 249 151 488 252 151 489 minecraft:shroomlight
fill 249 151 490 251 151 492 minecraft:soul_soil
fill 249 151 493 252 151 493 minecraft:shroomlight
fill 249 151 494 251 151 504 minecraft:bone_block
fill 250 151 480 251 151 483 minecraft:bone_block
fill 252 151 468 252 151 480 minecraft:white_terracotta
fill 252 151 481 252 151 483 minecraft:shroomlight
fill 252 151 485 252 151 487 minecraft:shroomlight
fill 252 151 490 252 151 492 minecraft:shroomlight
fill 252 151 494 252 151 504 minecraft:white_terracotta
fill 253 151 468 276 151 480 minecraft:soul_soil
fill 253 151 481 256 151 481 minecraft:shroomlight
fill 253 151 482 255 151 484 minecraft:soul_soil
fill 253 151 485 256 151 485 minecraft:shroomlight
fill 253 151 486 268 151 487 minecraft:bone_block
fill 253 151 488 268 151 488 minecraft:white_terracotta
fill 253 151 489 276 151 504 minecraft:soul_soil
fill 256 151 482 256 151 484 minecraft:shroomlight
fill 257 151 481 276 151 483 minecraft:soul_soil
fill 257 151 484 268 151 484 minecraft:white_terracotta
fill 257 151 485 268 151 485 minecraft:bone_block
fill 269 151 484 276 151 488 minecraft:soul_soil
fill 235 152 484 235 196 488 minecraft:brown_terracotta
setblock 238 152 466 minecraft:light[level=12]
setblock 238 152 474 minecraft:light[level=12]
setblock 238 152 482 minecraft:light[level=12]
setblock 238 152 490 minecraft:light[level=12]
setblock 238 152 498 minecraft:light[level=12]
setblock 246 152 466 minecraft:light[level=12]
setblock 246 152 474 minecraft:light[level=12]
setblock 246 152 482 minecraft:light[level=12]
setblock 246 152 490 minecraft:light[level=12]
setblock 246 152 498 minecraft:light[level=12]
fill 248 152 485 248 152 487 minecraft:lime_stained_glass
fill 249 152 484 251 152 484 minecraft:lime_stained_glass
fill 249 152 488 251 152 488 minecraft:lime_stained_glass
fill 252 152 485 252 152 487 minecraft:lime_stained_glass
setblock 254 152 466 minecraft:light[level=12]
setblock 254 152 474 minecraft:light[level=12]
setblock 254 152 482 minecraft:light[level=12]
setblock 254 152 490 minecraft:light[level=12]
setblock 254 152 498 minecraft:light[level=12]
setblock 262 152 466 minecraft:light[level=12]
setblock 262 152 474 minecraft:light[level=12]
setblock 262 152 482 minecraft:light[level=12]
setblock 262 152 490 minecraft:light[level=12]
setblock 262 152 498 minecraft:light[level=12]
setblock 270 152 466 minecraft:light[level=12]
setblock 270 152 474 minecraft:light[level=12]
setblock 270 152 482 minecraft:light[level=12]
setblock 270 152 490 minecraft:light[level=12]
setblock 270 152 498 minecraft:light[level=12]
fill 239 153 484 247 153 488 minecraft:light_gray_concrete
fill 240 153 481 260 153 483 minecraft:light_gray_concrete
fill 240 153 489 260 153 491 minecraft:light_gray_concrete
fill 241 153 480 259 156 480 minecraft:light_gray_concrete
fill 241 153 492 259 156 492 minecraft:light_gray_concrete
fill 242 153 479 258 156 479 minecraft:light_gray_concrete
fill 242 153 493 258 156 493 minecraft:light_gray_concrete
fill 243 153 478 257 156 478 minecraft:light_gray_concrete
fill 243 153 494 257 156 494 minecraft:light_gray_concrete
fill 244 153 477 256 156 477 minecraft:light_gray_concrete
fill 244 153 495 256 156 495 minecraft:light_gray_concrete
fill 245 153 476 255 156 476 minecraft:light_gray_concrete
fill 245 153 496 255 156 496 minecraft:light_gray_concrete
fill 248 153 475 252 156 475 minecraft:light_gray_concrete
fill 248 153 484 248 153 485 minecraft:light_gray_concrete
fill 248 153 487 248 153 488 minecraft:light_gray_concrete
fill 248 153 497 252 156 497 minecraft:light_gray_concrete
setblock 249 153 484 minecraft:light_gray_concrete
setblock 249 153 488 minecraft:light_gray_concrete
fill 251 153 484 261 153 484 minecraft:light_gray_concrete
fill 251 153 488 261 153 488 minecraft:light_gray_concrete
fill 252 153 485 261 153 485 minecraft:light_gray_concrete
fill 252 153 487 261 153 487 minecraft:light_gray_concrete
fill 253 153 486 261 153 486 minecraft:light_gray_concrete
fill 237 154 482 237 155 490 minecraft:sea_lantern
fill 238 154 480 238 155 483 minecraft:sea_lantern
fill 238 154 484 246 154 488 minecraft:light_gray_concrete
fill 238 154 489 238 155 492 minecraft:sea_lantern
fill 239 154 478 239 155 480 minecraft:sea_lantern
fill 239 154 481 249 154 483 minecraft:light_gray_concrete
fill 239 154 489 249 154 491 minecraft:light_gray_concrete
fill 239 154 492 239 155 494 minecraft:sea_lantern
fill 240 154 477 240 155 478 minecraft:sea_lantern
fill 240 154 479 240 155 480 minecraft:light_gray_concrete
fill 240 154 492 240 155 493 minecraft:light_gray_concrete
fill 240 154 494 240 155 495 minecraft:sea_lantern
fill 241 154 476 241 155 477 minecraft:sea_lantern
fill 241 154 478 241 155 479 minecraft:light_gray_concrete
fill 241 154 493 241 155 494 minecraft:light_gray_concrete
fill 241 154 495 241 155 496 minecraft:sea_lantern
fill 242 154 475 242 155 476 minecraft:sea_lantern
fill 242 154 477 242 155 478 minecraft:light_gray_concrete
fill 242 154 494 242 155 495 minecraft:light_gray_concrete
fill 242 154 496 242 155 497 minecraft:sea_lantern
fill 243 154 475 244 155 475 minecraft:sea_lantern
fill 243 154 476 243 155 477 minecraft:light_gray_concrete
fill 243 154 495 243 155 496 minecraft:light_gray_concrete
fill 243 154 497 244 155 497 minecraft:sea_lantern
fill 244 154 474 247 155 474 minecraft:sea_lantern
fill 244 154 476 244 155 476 minecraft:light_gray_concrete
fill 244 154 496 244 155 496 minecraft:light_gray_concrete
fill 244 154 498 247 155 498 minecraft:sea_lantern
fill 245 154 475 247 155 475 minecraft:light_gray_concrete
fill 245 154 497 247 155 497 minecraft:light_gray_concrete
fill 246 154 473 254 155 473 minecraft:sea_lantern
fill 246 154 499 254 155 499 minecraft:sea_lantern
fill 247 154 484 247 154 485 minecraft:light_gray_concrete
fill 247 154 486 247 157 486 minecraft:light_blue_stained_glass
fill 247 154 487 247 154 488 minecraft:light_gray_concrete
fill 248 154 474 252 155 474 minecraft:light_gray_concrete
fill 248 154 484 248 156 484 minecraft:light_blue_stained_glass
fill 248 154 488 248 156 488 minecraft:light_blue_stained_glass
fill 248 154 498 252 155 498 minecraft:light_gray_concrete
fill 250 154 481 261 154 482 minecraft:light_gray_concrete
fill 250 154 483 250 157 483 minecraft:light_blue_stained_glass
fill 250 154 489 250 157 489 minecraft:light_blue_stained_glass
fill 250 154 490 261 154 491 minecraft:light_gray_concrete
fill 251 154 483 261 154 483 minecraft:light_gray_concrete
fill 251 154 489 261 154 489 minecraft:light_gray_concrete
fill 252 154 484 252 156 484 minecraft:light_blue_stained_glass
fill 252 154 488 252 156 488 minecraft:light_blue_stained_glass
fill 253 154 474 256 155 474 minecraft:sea_lantern
fill 253 154 475 255 155 475 minecraft:light_gray_concrete
fill 253 154 484 262 154 485 minecraft:light_gray_concrete
fill 253 154 486 253 157 486 minecraft:light_blue_stained_glass
fill 253 154 487 262 154 488 minecraft:light_gray_concrete
fill 253 154 497 255 155 497 minecraft:light_gray_concrete
fill 253 154 498 256 155 498 minecraft:sea_lantern
fill 254 154 486 262 154 486 minecraft:light_gray_concrete
fill 256 154 475 258 155 475 minecraft:sea_lantern
fill 256 154 476 257 155 476 minecraft:light_gray_concrete
fill 256 154 496 257 155 496 minecraft:light_gray_concrete
fill 256 154 497 258 155 497 minecraft:sea_lantern
fill 257 154 477 258 155 477 minecraft:light_gray_concrete
fill 257 154 495 258 155 495 minecraft:light_gray_concrete
fill 258 154 476 259 155 476 minecraft:sea_lantern
fill 258 154 478 259 155 478 minecraft:light_gray_concrete
fill 258 154 494 259 155 494 minecraft:light_gray_concrete
fill 258 154 496 259 155 496 minecraft:sea_lantern
fill 259 154 477 260 155 477 minecraft:sea_lantern
fill 259 154 479 260 155 479 minecraft:light_gray_concrete
fill 259 154 493 260 155 493 minecraft:light_gray_concrete
fill 259 154 495 260 155 495 minecraft:sea_lantern
fill 260 154 478 261 155 478 minecraft:sea_lantern
fill 260 154 480 260 155 480 minecraft:light_gray_concrete
fill 260 154 492 260 155 492 minecraft:light_gray_concrete
fill 260 154 494 261 155 494 minecraft:sea_lantern
fill 261 154 479 261 155 480 minecraft:sea_lantern
fill 261 154 492 261 155 493 minecraft:sea_lantern
fill 262 154 480 262 155 483 minecraft:sea_lantern
fill 262 154 489 262 155 492 minecraft:sea_lantern
fill 263 154 482 263 155 490 minecraft:sea_lantern
setblock 236 155 480 minecraft:brown_terracotta
setblock 236 155 481 minecraft:bone_block
fill 236 155 482 236 155 485 minecraft:brown_terracotta
setblock 236 155 486 minecraft:bone_block
fill 236 155 487 236 155 490 minecraft:brown_terracotta
fill 236 155 499 236 155 500 minecraft:brown_terracotta
setblock 236 155 501 minecraft:bone_block
fill 236 155 502 236 156 504 minecraft:brown_terracotta
setblock 237 155 504 minecraft:brown_terracotta
fill 238 155 484 245 155 488 minecraft:light_gray_concrete
setblock 238 155 504 minecraft:bone_block
fill 239 155 481 246 155 483 minecraft:light_gray_concrete
fill 239 155 489 246 155 491 minecraft:light_gray_concrete
fill 239 155 504 242 155 504 minecraft:brown_terracotta
fill 241 155 464 242 155 464 minecraft:brown_terracotta
fill 242 155 503 243 155 503 minecraft:brown_terracotta
setblock 243 155 464 minecraft:bone_block
setblock 243 155 504 minecraft:bone_block
fill 244 155 464 246 155 465 minecraft:brown_terracotta
setblock 244 155 503 minecraft:bone_block
fill 244 155 504 247 155 504 minecraft:brown_terracotta
fill 245 155 503 248 155 503 minecraft:brown_terracotta
fill 246 155 484 246 159 488 minecraft:light_blue_stained_glass
setblock 247 155 464 minecraft:brown_terracotta
setblock 247 155 465 minecraft:bone_block
fill 247 155 481 247 155 482 minecraft:light_gray_concrete
fill 247 155 483 247 158 485 minecraft:light_blue_stained_glass
fill 247 155 487 247 158 489 minecraft:light_blue_stained_glass
fill 247 155 490 247 155 491 minecraft:light_gray_concrete
setblock 248 155 464 minecraft:bone_block
fill 248 155 465 251 155 465 minecraft:brown_terracotta
fill 248 155 481 261 155 481 minecraft:light_gray_concrete
fill 248 155 482 249 158 483 minecraft:light_blue_stained_glass
fill 248 155 489 249 158 490 minecraft:light_blue_stained_glass
fill 248 155 491 261 155 491 minecraft:light_gray_concrete
setblock 248 155 504 minecraft:bone_block
fill 249 155 464 252 155 464 minecraft:brown_terracotta
setblock 249 155 503 minecraft:bone_block
fill 249 155 504 252 155 504 minecraft:brown_terracotta
fill 250 155 482 252 159 482 minecraft:light_blue_stained_glass
fill 250 155 490 252 159 490 minecraft:light_blue_stained_glass
fill 251 155 483 253 158 483 minecraft:light_blue_stained_glass
fill 251 155 489 253 158 489 minecraft:light_blue_stained_glass
setblock 252 155 465 minecraft:bone_block
setblock 253 155 464 minecraft:bone_block
fill 253 155 482 261 155 482 minecraft:light_gray_concrete
fill 253 155 484 254 158 485 minecraft:light_blue_stained_glass
fill 253 155 487 254 158 488 minecraft:light_blue_stained_glass
fill 253 155 490 261 155 490 minecraft:light_gray_concrete
setblock 253 155 504 minecraft:bone_block
fill 254 155 464 257 155 464 minecraft:brown_terracotta
fill 254 155 483 261 155 483 minecraft:light_gray_concrete
fill 254 155 486 254 159 486 minecraft:light_blue_stained_glass
fill 254 155 489 261 155 489 minecraft:light_gray_concrete
setblock 254 155 504 minecraft:brown_terracotta
fill 255 155 484 262 155 488 minecraft:light_gray_concrete
setblock 257 155 504 minecraft:brown_terracotta
setblock 258 155 464 minecraft:bone_block
setblock 258 155 504 minecraft:bone_block
fill 259 155 464 261 155 465 minecraft:brown_terracotta
fill 259 155 504 262 155 504 minecraft:brown_terracotta
fill 261 155 503 263 155 503 minecraft:brown_terracotta
setblock 262 155 464 minecraft:brown_terracotta
setblock 262 155 465 minecraft:bone_block
fill 262 155 466 265 155 466 minecraft:brown_terracotta
setblock 263 155 464 minecraft:bone_block
fill 263 155 465 266 155 465 minecraft:brown_terracotta
schedule function dropper:buildpart/113_6 1t
