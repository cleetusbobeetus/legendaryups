setblock 178 250 324 minecraft:dark_prismarine
setblock 179 250 323 minecraft:dark_prismarine
fill 179 250 324 179 253 324 minecraft:blue_terracotta
setblock 179 250 363 minecraft:dark_prismarine
fill 180 250 323 180 253 323 minecraft:blue_terracotta
setblock 180 250 362 minecraft:dark_prismarine
fill 180 250 363 180 253 363 minecraft:blue_terracotta
setblock 181 250 325 minecraft:blue_terracotta
setblock 181 250 326 minecraft:dark_prismarine
fill 181 250 327 181 252 328 minecraft:blue_terracotta
setblock 181 250 336 minecraft:dark_prismarine
fill 181 250 337 181 253 337 minecraft:blue_terracotta
setblock 181 250 341 minecraft:dark_prismarine
fill 181 250 342 181 253 342 minecraft:blue_terracotta
setblock 181 250 361 minecraft:dark_prismarine
fill 181 250 362 181 253 362 minecraft:blue_terracotta
setblock 182 250 325 minecraft:dark_prismarine
fill 182 250 326 182 253 326 minecraft:blue_terracotta
setblock 182 250 330 minecraft:dark_prismarine
fill 182 250 331 182 253 331 minecraft:blue_terracotta
setblock 182 250 335 minecraft:dark_prismarine
fill 182 250 336 182 253 336 minecraft:blue_terracotta
setblock 182 250 340 minecraft:dark_prismarine
fill 182 250 341 182 253 341 minecraft:blue_terracotta
setblock 182 250 345 minecraft:dark_prismarine
fill 182 250 346 182 253 346 minecraft:blue_terracotta
fill 182 250 356 182 253 356 minecraft:blue_terracotta
setblock 182 250 360 minecraft:dark_prismarine
fill 182 250 361 182 253 361 minecraft:blue_terracotta
fill 141 251 328 141 308 328 minecraft:blue_concrete
setblock 142 251 323 minecraft:blue_terracotta
setblock 142 251 324 minecraft:dark_prismarine
fill 142 251 325 142 254 325 minecraft:blue_terracotta
setblock 142 251 329 minecraft:dark_prismarine
setblock 142 251 339 minecraft:dark_prismarine
fill 142 251 340 142 254 340 minecraft:blue_terracotta
setblock 142 251 344 minecraft:dark_prismarine
fill 142 251 345 143 253 345 minecraft:blue_terracotta
setblock 142 251 349 minecraft:dark_prismarine
fill 142 251 350 142 251 353 minecraft:blue_terracotta
setblock 142 251 354 minecraft:dark_prismarine
fill 142 251 355 142 251 358 minecraft:blue_terracotta
setblock 142 251 359 minecraft:dark_prismarine
fill 142 251 360 142 254 360 minecraft:blue_terracotta
setblock 143 251 323 minecraft:dark_prismarine
fill 143 251 324 143 254 324 minecraft:blue_terracotta
setblock 143 251 343 minecraft:dark_prismarine
fill 143 251 344 143 254 344 minecraft:blue_terracotta
fill 143 251 356 143 251 357 minecraft:blue_terracotta
setblock 143 251 358 minecraft:dark_prismarine
fill 143 251 359 143 254 359 minecraft:blue_terracotta
setblock 143 251 362 minecraft:blue_terracotta
setblock 143 251 363 minecraft:dark_prismarine
fill 144 251 323 144 254 323 minecraft:blue_terracotta
setblock 144 251 325 minecraft:light[level=12]
setblock 144 251 332 minecraft:light[level=12]
setblock 144 251 339 minecraft:light[level=12]
setblock 144 251 346 minecraft:light[level=12]
setblock 144 251 353 minecraft:light[level=12]
setblock 144 251 362 minecraft:dark_prismarine
fill 144 251 363 147 251 363 minecraft:blue_terracotta
fill 145 251 344 148 251 344 minecraft:jungle_log
setblock 145 251 361 minecraft:dark_prismarine
fill 145 251 362 145 254 362 minecraft:blue_terracotta
fill 146 251 361 146 252 361 minecraft:blue_terracotta
setblock 148 251 323 minecraft:dark_prismarine
setblock 148 251 339 minecraft:jungle_log
fill 148 251 340 148 254 343 minecraft:jungle_leaves[persistent=true]
fill 148 251 345 148 254 348 minecraft:jungle_leaves[persistent=true]
setblock 148 251 349 minecraft:jungle_log
setblock 148 251 363 minecraft:dark_prismarine
fill 149 251 339 153 254 339 minecraft:jungle_leaves[persistent=true]
fill 149 251 340 149 251 341 minecraft:jungle_log
fill 149 251 342 153 251 346 minecraft:jungle_leaves[persistent=true]
fill 149 251 347 149 251 348 minecraft:jungle_log
fill 149 251 349 153 254 349 minecraft:jungle_leaves[persistent=true]
setblock 149 251 362 minecraft:dark_prismarine
fill 149 251 363 152 251 363 minecraft:blue_terracotta
fill 150 251 338 151 254 338 minecraft:jungle_leaves[persistent=true]
fill 150 251 340 152 254 341 minecraft:jungle_leaves[persistent=true]
fill 150 251 347 152 254 348 minecraft:jungle_leaves[persistent=true]
fill 150 251 350 151 254 350 minecraft:jungle_leaves[persistent=true]
setblock 151 251 325 minecraft:light[level=12]
setblock 151 251 332 minecraft:light[level=12]
fill 151 251 337 153 254 337 minecraft:jungle_leaves[persistent=true]
fill 151 251 351 153 254 351 minecraft:jungle_leaves[persistent=true]
setblock 151 251 353 minecraft:light[level=12]
setblock 151 251 360 minecraft:light[level=12]
fill 152 251 336 155 254 336 minecraft:jungle_leaves[persistent=true]
fill 152 251 352 155 254 352 minecraft:jungle_leaves[persistent=true]
fill 153 251 340 153 251 341 minecraft:jungle_log
fill 153 251 347 153 251 348 minecraft:jungle_log
setblock 153 251 363 minecraft:dark_prismarine
fill 154 251 335 164 254 335 minecraft:jungle_leaves[persistent=true]
fill 154 251 338 155 255 338 minecraft:jungle_leaves[persistent=true]
setblock 154 251 339 minecraft:jungle_log
fill 154 251 343 156 259 343 minecraft:jungle_leaves[persistent=true]
fill 154 251 344 157 251 344 minecraft:jungle_log
fill 154 251 345 156 259 345 minecraft:jungle_leaves[persistent=true]
setblock 154 251 349 minecraft:jungle_log
fill 154 251 350 155 255 350 minecraft:jungle_leaves[persistent=true]
fill 154 251 353 164 254 353 minecraft:jungle_leaves[persistent=true]
fill 154 251 363 157 251 363 minecraft:blue_terracotta
setblock 155 251 323 minecraft:purple_concrete
fill 155 251 337 155 255 337 minecraft:jungle_leaves[persistent=true]
fill 155 251 351 155 255 351 minecraft:jungle_leaves[persistent=true]
fill 157 251 334 161 254 334 minecraft:jungle_leaves[persistent=true]
fill 157 251 354 161 254 354 minecraft:jungle_leaves[persistent=true]
setblock 158 251 323 minecraft:dark_prismarine
setblock 158 251 325 minecraft:light[level=12]
setblock 158 251 332 minecraft:light[level=12]
setblock 158 251 360 minecraft:light[level=12]
setblock 158 251 362 minecraft:blue_terracotta
setblock 158 251 363 minecraft:dark_prismarine
fill 159 251 323 159 254 323 minecraft:blue_terracotta
setblock 159 251 362 minecraft:dark_prismarine
fill 159 251 363 159 254 363 minecraft:blue_terracotta
fill 160 251 362 160 254 362 minecraft:blue_terracotta
setblock 163 251 323 minecraft:dark_prismarine
fill 163 251 336 166 254 336 minecraft:jungle_leaves[persistent=true]
fill 163 251 352 166 254 352 minecraft:jungle_leaves[persistent=true]
setblock 163 251 363 minecraft:dark_prismarine
fill 164 251 323 164 254 323 minecraft:blue_terracotta
setblock 164 251 362 minecraft:dark_prismarine
fill 164 251 363 164 254 363 minecraft:blue_terracotta
setblock 165 251 325 minecraft:light[level=12]
setblock 165 251 332 minecraft:light[level=12]
fill 165 251 337 167 254 337 minecraft:jungle_leaves[persistent=true]
fill 165 251 351 167 254 351 minecraft:jungle_leaves[persistent=true]
setblock 165 251 353 minecraft:light[level=12]
setblock 165 251 360 minecraft:light[level=12]
fill 167 251 338 168 254 338 minecraft:jungle_leaves[persistent=true]
fill 167 251 350 168 254 350 minecraft:jungle_leaves[persistent=true]
fill 167 251 358 167 255 358 minecraft:purple_concrete
setblock 168 251 323 minecraft:dark_prismarine
fill 168 251 339 169 254 340 minecraft:jungle_leaves[persistent=true]
fill 168 251 348 169 254 349 minecraft:jungle_leaves[persistent=true]
fill 168 251 357 168 255 357 minecraft:purple_concrete
fill 169 251 323 169 254 323 minecraft:blue_terracotta
fill 169 251 341 170 254 342 minecraft:jungle_leaves[persistent=true]
fill 169 251 346 170 254 347 minecraft:jungle_leaves[persistent=true]
setblock 169 251 363 minecraft:purple_concrete
fill 170 251 340 170 254 340 minecraft:jungle_leaves[persistent=true]
fill 170 251 343 170 254 345 minecraft:jungle_leaves[persistent=true]
fill 170 251 348 170 254 348 minecraft:jungle_leaves[persistent=true]
fill 170 251 350 170 272 352 minecraft:dark_prismarine
fill 171 251 344 171 254 344 minecraft:jungle_leaves[persistent=true]
fill 171 251 351 171 272 351 minecraft:dark_prismarine
setblock 172 251 325 minecraft:light[level=12]
setblock 172 251 332 minecraft:light[level=12]
setblock 172 251 339 minecraft:light[level=12]
setblock 172 251 346 minecraft:light[level=12]
setblock 172 251 353 minecraft:light[level=12]
setblock 172 251 360 minecraft:light[level=12]
setblock 173 251 323 minecraft:dark_prismarine
fill 174 251 323 174 254 323 minecraft:blue_terracotta
fill 175 251 363 175 253 363 minecraft:blue_terracotta
setblock 176 251 324 minecraft:blue_terracotta
fill 176 251 341 176 263 341 minecraft:magenta_terracotta
setblock 177 251 324 minecraft:dark_prismarine
setblock 178 251 323 minecraft:dark_prismarine
fill 178 251 324 178 254 324 minecraft:blue_terracotta
fill 178 251 359 178 260 359 minecraft:iron_bars
setblock 178 251 362 minecraft:blue_terracotta
setblock 178 251 363 minecraft:dark_prismarine
fill 179 251 323 179 254 323 minecraft:blue_terracotta
setblock 179 251 325 minecraft:light[level=12]
setblock 179 251 332 minecraft:light[level=12]
setblock 179 251 339 minecraft:light[level=12]
setblock 179 251 346 minecraft:light[level=12]
setblock 179 251 353 minecraft:light[level=12]
setblock 179 251 360 minecraft:light[level=12]
setblock 179 251 362 minecraft:dark_prismarine
fill 179 251 363 179 254 363 minecraft:blue_terracotta
setblock 180 251 325 minecraft:blue_terracotta
fill 180 251 362 180 254 362 minecraft:blue_terracotta
setblock 181 251 325 minecraft:dark_prismarine
fill 181 251 326 181 254 326 minecraft:blue_terracotta
setblock 181 251 329 minecraft:blue_terracotta
setblock 181 251 336 minecraft:blue_terracotta
setblock 181 251 340 minecraft:dark_prismarine
fill 181 251 341 181 254 341 minecraft:blue_terracotta
setblock 181 251 344 minecraft:blue_terracotta
setblock 181 251 360 minecraft:dark_prismarine
fill 181 251 361 181 254 361 minecraft:blue_terracotta
setblock 182 251 324 minecraft:dark_prismarine
fill 182 251 325 182 254 325 minecraft:blue_terracotta
setblock 182 251 329 minecraft:dark_prismarine
fill 182 251 330 182 254 330 minecraft:blue_terracotta
setblock 182 251 334 minecraft:dark_prismarine
fill 182 251 335 182 254 335 minecraft:blue_terracotta
setblock 182 251 339 minecraft:dark_prismarine
fill 182 251 340 182 254 340 minecraft:blue_terracotta
setblock 182 251 344 minecraft:dark_prismarine
fill 182 251 345 182 254 345 minecraft:blue_terracotta
fill 182 251 347 182 252 347 minecraft:blue_terracotta
setblock 182 251 359 minecraft:dark_prismarine
fill 182 251 360 182 254 360 minecraft:blue_terracotta
setblock 142 252 323 minecraft:dark_prismarine
fill 142 252 324 142 255 324 minecraft:blue_terracotta
fill 142 252 326 142 252 327 minecraft:blue_terracotta
setblock 142 252 328 minecraft:dark_prismarine
fill 142 252 329 142 255 329 minecraft:blue_terracotta
setblock 142 252 338 minecraft:dark_prismarine
fill 142 252 339 142 255 339 minecraft:blue_terracotta
setblock 142 252 343 minecraft:dark_prismarine
fill 142 252 344 142 255 344 minecraft:blue_terracotta
setblock 142 252 348 minecraft:dark_prismarine
fill 142 252 349 142 252 352 minecraft:blue_terracotta
setblock 142 252 353 minecraft:dark_prismarine
fill 142 252 354 142 252 357 minecraft:blue_terracotta
setblock 142 252 358 minecraft:dark_prismarine
fill 142 252 359 142 255 359 minecraft:blue_terracotta
fill 142 252 361 142 252 362 minecraft:blue_terracotta
setblock 142 252 363 minecraft:dark_prismarine
fill 143 252 323 143 255 323 minecraft:blue_terracotta
setblock 143 252 326 minecraft:blue_terracotta
setblock 143 252 342 minecraft:dark_prismarine
fill 143 252 343 143 255 343 minecraft:blue_terracotta
setblock 143 252 346 minecraft:blue_terracotta
setblock 143 252 347 minecraft:dark_prismarine
setblock 143 252 356 minecraft:blue_terracotta
setblock 143 252 357 minecraft:dark_prismarine
fill 143 252 358 143 255 358 minecraft:blue_terracotta
setblock 143 252 362 minecraft:dark_prismarine
fill 143 252 363 146 252 363 minecraft:blue_terracotta
setblock 144 252 361 minecraft:dark_prismarine
fill 144 252 362 144 255 362 minecraft:blue_terracotta
fill 145 252 361 145 254 361 minecraft:blue_terracotta
setblock 147 252 323 minecraft:dark_prismarine
fill 147 252 340 147 253 348 minecraft:jungle_leaves[persistent=true]
setblock 147 252 363 minecraft:dark_prismarine
fill 148 252 323 148 255 323 minecraft:blue_terracotta
fill 148 252 339 148 253 339 minecraft:jungle_leaves[persistent=true]
fill 148 252 344 154 252 344 minecraft:jungle_log
fill 148 252 349 148 253 349 minecraft:jungle_leaves[persistent=true]
setblock 148 252 362 minecraft:dark_prismarine
fill 148 252 363 151 252 363 minecraft:blue_terracotta
setblock 149 252 323 minecraft:purple_concrete
fill 149 252 338 149 253 338 minecraft:jungle_leaves[persistent=true]
fill 149 252 340 149 254 343 minecraft:jungle_leaves[persistent=true]
fill 149 252 345 149 254 348 minecraft:jungle_leaves[persistent=true]
fill 149 252 350 149 253 350 minecraft:jungle_leaves[persistent=true]
setblock 149 252 362 minecraft:blue_terracotta
fill 150 252 337 150 253 337 minecraft:jungle_leaves[persistent=true]
fill 150 252 342 150 252 343 minecraft:jungle_log
fill 150 252 345 150 252 346 minecraft:jungle_log
fill 150 252 351 150 253 351 minecraft:jungle_leaves[persistent=true]
fill 151 252 336 151 253 336 minecraft:jungle_leaves[persistent=true]
fill 151 252 342 151 260 342 minecraft:jungle_leaves[persistent=true]
fill 151 252 343 152 252 343 minecraft:jungle_log
fill 151 252 345 152 252 345 minecraft:jungle_log
fill 151 252 346 151 260 346 minecraft:jungle_leaves[persistent=true]
fill 151 252 352 151 253 352 minecraft:jungle_leaves[persistent=true]
fill 152 252 335 153 253 335 minecraft:jungle_leaves[persistent=true]
setblock 152 252 342 minecraft:jungle_log
setblock 152 252 346 minecraft:jungle_log
fill 152 252 353 153 253 353 minecraft:jungle_leaves[persistent=true]
setblock 152 252 363 minecraft:dark_prismarine
fill 153 252 340 153 259 343 minecraft:jungle_leaves[persistent=true]
fill 153 252 345 153 259 348 minecraft:jungle_leaves[persistent=true]
fill 153 252 363 156 252 363 minecraft:blue_terracotta
fill 154 252 334 156 253 334 minecraft:jungle_leaves[persistent=true]
fill 154 252 339 154 259 339 minecraft:jungle_leaves[persistent=true]
fill 154 252 349 154 259 349 minecraft:jungle_leaves[persistent=true]
fill 154 252 354 156 253 354 minecraft:jungle_leaves[persistent=true]
fill 155 252 328 155 262 328 minecraft:magenta_terracotta
fill 155 252 340 158 256 340 minecraft:jungle_leaves[persistent=true]
fill 155 252 344 156 259 344 minecraft:jungle_leaves[persistent=true]
fill 155 252 348 158 256 348 minecraft:jungle_leaves[persistent=true]
setblock 157 252 323 minecraft:dark_prismarine
setblock 157 252 362 minecraft:blue_terracotta
setblock 157 252 363 minecraft:dark_prismarine
fill 158 252 323 158 255 323 minecraft:blue_terracotta
setblock 158 252 362 minecraft:dark_prismarine
fill 158 252 363 158 255 363 minecraft:blue_terracotta
fill 159 252 362 159 255 362 minecraft:blue_terracotta
setblock 161 252 324 minecraft:dark_prismarine
setblock 162 252 323 minecraft:dark_prismarine
fill 162 252 324 164 253 324 minecraft:blue_terracotta
fill 162 252 334 164 253 334 minecraft:jungle_leaves[persistent=true]
fill 162 252 354 164 253 354 minecraft:jungle_leaves[persistent=true]
setblock 162 252 363 minecraft:dark_prismarine
fill 163 252 323 163 255 323 minecraft:blue_terracotta
fill 163 252 339 167 252 339 minecraft:jungle_leaves[persistent=true]
fill 163 252 349 167 252 349 minecraft:jungle_leaves[persistent=true]
setblock 163 252 362 minecraft:dark_prismarine
fill 163 252 363 163 255 363 minecraft:blue_terracotta
fill 165 252 335 166 253 335 minecraft:jungle_leaves[persistent=true]
fill 165 252 353 166 253 353 minecraft:jungle_leaves[persistent=true]
fill 166 252 340 167 255 340 minecraft:jungle_leaves[persistent=true]
fill 166 252 348 167 255 348 minecraft:jungle_leaves[persistent=true]
setblock 167 252 323 minecraft:dark_prismarine
fill 167 252 336 167 253 336 minecraft:jungle_leaves[persistent=true]
fill 167 252 341 168 252 343 minecraft:jungle_leaves[persistent=true]
fill 167 252 345 168 252 347 minecraft:jungle_leaves[persistent=true]
fill 167 252 352 167 253 352 minecraft:jungle_leaves[persistent=true]
fill 167 252 357 167 255 357 minecraft:purple_concrete
fill 167 252 359 169 255 359 minecraft:purple_concrete
setblock 167 252 363 minecraft:dark_prismarine
fill 168 252 323 168 255 323 minecraft:blue_terracotta
fill 168 252 337 168 253 337 minecraft:jungle_leaves[persistent=true]
fill 168 252 344 168 255 344 minecraft:jungle_leaves[persistent=true]
fill 168 252 351 168 253 351 minecraft:jungle_leaves[persistent=true]
fill 168 252 356 168 255 356 minecraft:purple_concrete
fill 169 252 338 169 253 338 minecraft:jungle_leaves[persistent=true]
fill 169 252 350 169 253 350 minecraft:jungle_leaves[persistent=true]
fill 169 252 351 169 253 351 minecraft:black_concrete
fill 170 252 323 171 252 323 minecraft:blue_terracotta
fill 170 252 339 170 253 339 minecraft:jungle_leaves[persistent=true]
fill 170 252 349 170 253 349 minecraft:jungle_leaves[persistent=true]
fill 171 252 340 171 253 343 minecraft:jungle_leaves[persistent=true]
fill 171 252 345 171 253 348 minecraft:jungle_leaves[persistent=true]
fill 171 252 350 171 253 350 minecraft:black_concrete
fill 171 252 352 171 253 352 minecraft:black_concrete
setblock 172 252 323 minecraft:dark_prismarine
fill 172 252 347 172 253 347 minecraft:black_concrete
fill 173 252 323 173 255 323 minecraft:blue_terracotta
setblock 175 252 324 minecraft:blue_terracotta
setblock 176 252 324 minecraft:dark_prismarine
setblock 177 252 323 minecraft:dark_prismarine
fill 177 252 324 177 255 324 minecraft:blue_terracotta
setblock 177 252 362 minecraft:blue_terracotta
setblock 177 252 363 minecraft:dark_prismarine
fill 178 252 323 178 255 323 minecraft:blue_terracotta
fill 178 252 325 179 252 325 minecraft:blue_terracotta
setblock 178 252 362 minecraft:dark_prismarine
fill 178 252 363 178 255 363 minecraft:blue_terracotta
fill 179 252 362 179 255 362 minecraft:blue_terracotta
setblock 180 252 324 minecraft:blue_terracotta
setblock 180 252 325 minecraft:dark_prismarine
fill 180 252 326 180 254 327 minecraft:blue_terracotta
setblock 181 252 324 minecraft:dark_prismarine
fill 181 252 325 181 255 325 minecraft:blue_terracotta
setblock 181 252 329 minecraft:dark_prismarine
fill 181 252 330 181 255 330 minecraft:blue_terracotta
setblock 181 252 339 minecraft:dark_prismarine
fill 181 252 340 181 255 340 minecraft:blue_terracotta
setblock 181 252 344 minecraft:dark_prismarine
fill 181 252 345 181 255 345 minecraft:blue_terracotta
setblock 181 252 359 minecraft:dark_prismarine
fill 181 252 360 181 255 360 minecraft:blue_terracotta
setblock 182 252 323 minecraft:dark_prismarine
fill 182 252 324 182 255 324 minecraft:blue_terracotta
setblock 182 252 328 minecraft:dark_prismarine
fill 182 252 329 182 255 329 minecraft:blue_terracotta
setblock 182 252 333 minecraft:dark_prismarine
fill 182 252 334 182 255 334 minecraft:blue_terracotta
setblock 182 252 338 minecraft:dark_prismarine
fill 182 252 339 182 255 339 minecraft:blue_terracotta
setblock 182 252 343 minecraft:dark_prismarine
fill 182 252 344 182 255 344 minecraft:blue_terracotta
setblock 182 252 348 minecraft:dark_prismarine
setblock 182 252 358 minecraft:dark_prismarine
fill 182 252 359 182 255 359 minecraft:blue_terracotta
setblock 182 252 363 minecraft:dark_prismarine
fill 142 253 323 142 256 323 minecraft:blue_terracotta
setblock 142 253 326 minecraft:blue_terracotta
setblock 142 253 327 minecraft:dark_prismarine
fill 142 253 328 142 256 328 minecraft:blue_terracotta
fill 142 253 330 142 254 330 minecraft:blue_terracotta
setblock 142 253 333 minecraft:purple_concrete
setblock 142 253 337 minecraft:dark_prismarine
fill 142 253 338 142 256 338 minecraft:blue_terracotta
setblock 142 253 342 minecraft:dark_prismarine
fill 142 253 343 142 256 343 minecraft:blue_terracotta
setblock 142 253 347 minecraft:dark_prismarine
fill 142 253 348 142 253 351 minecraft:blue_terracotta
setblock 142 253 352 minecraft:dark_prismarine
fill 142 253 353 142 253 356 minecraft:blue_terracotta
setblock 142 253 357 minecraft:dark_prismarine
fill 142 253 358 142 256 358 minecraft:blue_terracotta
setblock 142 253 361 minecraft:blue_terracotta
setblock 142 253 362 minecraft:dark_prismarine
fill 142 253 363 145 253 363 minecraft:blue_terracotta
setblock 143 253 326 minecraft:dark_prismarine
setblock 143 253 341 minecraft:dark_prismarine
fill 143 253 342 143 256 342 minecraft:blue_terracotta
setblock 143 253 346 minecraft:dark_prismarine
fill 143 253 347 143 253 350 minecraft:blue_terracotta
setblock 143 253 356 minecraft:dark_prismarine
fill 143 253 357 143 256 357 minecraft:blue_terracotta
setblock 143 253 361 minecraft:dark_prismarine
fill 143 253 362 143 256 362 minecraft:blue_terracotta
setblock 144 253 325 minecraft:light[level=13]
setblock 144 253 333 minecraft:light[level=13]
setblock 144 253 341 minecraft:light[level=13]
setblock 144 253 349 minecraft:light[level=13]
setblock 144 253 357 minecraft:light[level=13]
setblock 144 253 360 minecraft:dark_prismarine
fill 144 253 361 144 255 361 minecraft:blue_terracotta
setblock 145 253 324 minecraft:dark_prismarine
setblock 146 253 323 minecraft:dark_prismarine
setblock 146 253 363 minecraft:dark_prismarine
fill 147 253 323 147 256 323 minecraft:blue_terracotta
setblock 147 253 362 minecraft:dark_prismarine
fill 147 253 363 150 253 363 minecraft:blue_terracotta
fill 148 253 344 150 260 344 minecraft:jungle_leaves[persistent=true]
fill 148 253 362 148 254 362 minecraft:blue_terracotta
fill 150 253 342 150 260 343 minecraft:jungle_leaves[persistent=true]
fill 150 253 345 150 260 346 minecraft:jungle_leaves[persistent=true]
fill 151 253 343 152 260 343 minecraft:jungle_leaves[persistent=true]
setblock 151 253 344 minecraft:jungle_log
fill 151 253 345 152 260 345 minecraft:jungle_leaves[persistent=true]
setblock 151 253 363 minecraft:dark_prismarine
setblock 152 253 325 minecraft:light[level=13]
setblock 152 253 333 minecraft:light[level=13]
fill 152 253 342 152 260 342 minecraft:jungle_leaves[persistent=true]
fill 152 253 344 154 260 344 minecraft:jungle_leaves[persistent=true]
fill 152 253 346 152 260 346 minecraft:jungle_leaves[persistent=true]
setblock 152 253 357 minecraft:light[level=13]
fill 152 253 363 155 253 363 minecraft:blue_terracotta
setblock 155 253 323 minecraft:blue_terracotta
setblock 156 253 323 minecraft:dark_prismarine
setblock 156 253 362 minecraft:blue_terracotta
setblock 156 253 363 minecraft:dark_prismarine
fill 157 253 323 157 256 323 minecraft:blue_terracotta
fill 157 253 339 160 254 339 minecraft:jungle_leaves[persistent=true]
fill 157 253 349 160 254 349 minecraft:jungle_leaves[persistent=true]
setblock 157 253 362 minecraft:dark_prismarine
fill 157 253 363 157 256 363 minecraft:blue_terracotta
fill 158 253 362 158 256 362 minecraft:blue_terracotta
setblock 159 253 324 minecraft:blue_terracotta
setblock 160 253 324 minecraft:dark_prismarine
setblock 160 253 325 minecraft:light[level=13]
setblock 160 253 333 minecraft:light[level=13]
setblock 160 253 357 minecraft:light[level=13]
setblock 161 253 323 minecraft:dark_prismarine
fill 161 253 324 161 256 324 minecraft:blue_terracotta
setblock 161 253 363 minecraft:dark_prismarine
fill 162 253 323 162 256 323 minecraft:blue_terracotta
setblock 162 253 362 minecraft:dark_prismarine
fill 162 253 363 162 256 363 minecraft:blue_terracotta
setblock 163 253 362 minecraft:blue_terracotta
fill 164 253 339 167 254 339 minecraft:jungle_leaves[persistent=true]
fill 164 253 349 167 254 349 minecraft:jungle_leaves[persistent=true]
setblock 165 253 324 minecraft:dark_prismarine
setblock 166 253 323 minecraft:dark_prismarine
fill 166 253 324 166 256 324 minecraft:blue_terracotta
fill 166 253 357 166 255 359 minecraft:purple_concrete
setblock 166 253 363 minecraft:dark_prismarine
fill 167 253 323 167 256 323 minecraft:blue_terracotta
fill 167 253 341 168 254 342 minecraft:jungle_leaves[persistent=true]
fill 167 253 346 168 254 347 minecraft:jungle_leaves[persistent=true]
fill 167 253 356 167 255 356 minecraft:purple_concrete
fill 167 253 360 169 255 360 minecraft:purple_concrete
setblock 168 253 325 minecraft:light[level=13]
setblock 168 253 333 minecraft:light[level=13]
fill 168 253 343 168 255 343 minecraft:jungle_leaves[persistent=true]
fill 168 253 345 168 255 345 minecraft:jungle_leaves[persistent=true]
setblock 169 253 352 minecraft:black_concrete
fill 169 253 356 169 255 356 minecraft:purple_concrete
setblock 170 253 323 minecraft:blue_terracotta
setblock 170 253 353 minecraft:black_concrete
fill 170 253 358 170 255 359 minecraft:purple_concrete
setblock 171 253 323 minecraft:dark_prismarine
setblock 171 253 349 minecraft:black_concrete
fill 172 253 323 172 256 323 minecraft:blue_terracotta
fill 172 253 350 172 253 352 minecraft:black_concrete
fill 173 253 324 174 253 324 minecraft:blue_terracotta
fill 174 253 363 174 254 363 minecraft:blue_terracotta
setblock 175 253 324 minecraft:dark_prismarine
setblock 176 253 323 minecraft:dark_prismarine
fill 176 253 324 176 255 325 minecraft:blue_terracotta
setblock 176 253 333 minecraft:light[level=13]
setblock 176 253 349 minecraft:light[level=13]
setblock 176 253 357 minecraft:light[level=13]
setblock 176 253 363 minecraft:dark_prismarine
fill 177 253 323 177 256 323 minecraft:blue_terracotta
fill 177 253 325 178 253 325 minecraft:blue_terracotta
setblock 177 253 362 minecraft:dark_prismarine
fill 177 253 363 177 256 363 minecraft:blue_terracotta
fill 178 253 362 178 256 362 minecraft:blue_terracotta
setblock 179 253 325 minecraft:dark_prismarine
setblock 180 253 324 minecraft:dark_prismarine
fill 180 253 325 180 256 325 minecraft:blue_terracotta
setblock 180 253 328 minecraft:blue_terracotta
fill 180 253 361 180 255 361 minecraft:blue_terracotta
setblock 181 253 323 minecraft:dark_prismarine
fill 181 253 324 181 256 324 minecraft:blue_terracotta
setblock 181 253 327 minecraft:blue_terracotta
setblock 181 253 328 minecraft:dark_prismarine
fill 181 253 329 181 256 329 minecraft:blue_terracotta
fill 181 253 331 181 254 331 minecraft:blue_terracotta
setblock 181 253 338 minecraft:dark_prismarine
fill 181 253 339 181 255 339 minecraft:blue_terracotta
setblock 181 253 343 minecraft:dark_prismarine
fill 181 253 344 181 256 344 minecraft:blue_terracotta
fill 181 253 346 181 254 346 minecraft:blue_terracotta
fill 181 253 359 181 256 359 minecraft:blue_terracotta
setblock 181 253 363 minecraft:dark_prismarine
fill 182 253 323 182 256 323 minecraft:blue_terracotta
setblock 182 253 327 minecraft:dark_prismarine
fill 182 253 328 182 256 328 minecraft:blue_terracotta
setblock 182 253 332 minecraft:dark_prismarine
fill 182 253 333 182 256 333 minecraft:blue_terracotta
setblock 182 253 337 minecraft:dark_prismarine
fill 182 253 338 182 256 338 minecraft:blue_terracotta
setblock 182 253 342 minecraft:dark_prismarine
fill 182 253 343 182 256 343 minecraft:blue_terracotta
setblock 182 253 347 minecraft:dark_prismarine
fill 182 253 348 182 254 350 minecraft:blue_terracotta
setblock 182 253 353 minecraft:purple_concrete
fill 182 253 355 182 254 355 minecraft:blue_terracotta
setblock 182 253 357 minecraft:dark_prismarine
fill 182 253 358 182 256 358 minecraft:blue_terracotta
setblock 182 253 362 minecraft:dark_prismarine
fill 182 253 363 182 256 363 minecraft:blue_terracotta
setblock 142 254 326 minecraft:dark_prismarine
fill 142 254 327 143 256 327 minecraft:blue_terracotta
setblock 142 254 337 minecraft:blue_terracotta
setblock 142 254 341 minecraft:dark_prismarine
fill 142 254 342 142 257 342 minecraft:blue_terracotta
setblock 142 254 345 minecraft:blue_terracotta
setblock 142 254 346 minecraft:dark_prismarine
fill 142 254 347 142 254 350 minecraft:blue_terracotta
setblock 142 254 351 minecraft:dark_prismarine
fill 142 254 352 142 254 355 minecraft:blue_terracotta
setblock 142 254 356 minecraft:dark_prismarine
fill 142 254 357 142 257 357 minecraft:blue_terracotta
setblock 142 254 361 minecraft:dark_prismarine
fill 142 254 362 142 256 363 minecraft:blue_terracotta
setblock 143 254 325 minecraft:dark_prismarine
fill 143 254 326 143 257 326 minecraft:blue_terracotta
fill 143 254 341 143 255 341 minecraft:blue_terracotta
setblock 143 254 345 minecraft:dark_prismarine
fill 143 254 346 143 254 349 minecraft:blue_terracotta
setblock 143 254 350 minecraft:dark_prismarine
fill 143 254 351 143 254 354 minecraft:blue_terracotta
setblock 143 254 355 minecraft:dark_prismarine
fill 143 254 356 143 257 356 minecraft:blue_terracotta
setblock 143 254 360 minecraft:dark_prismarine
fill 143 254 361 143 257 361 minecraft:blue_terracotta
fill 143 254 363 144 254 363 minecraft:blue_terracotta
setblock 144 254 324 minecraft:dark_prismarine
setblock 144 254 360 minecraft:blue_terracotta
setblock 145 254 323 minecraft:dark_prismarine
fill 145 254 324 145 257 324 minecraft:blue_terracotta
setblock 145 254 363 minecraft:dark_prismarine
fill 146 254 323 146 257 323 minecraft:blue_terracotta
setblock 146 254 362 minecraft:dark_prismarine
fill 146 254 363 149 254 363 minecraft:blue_terracotta
setblock 147 254 344 minecraft:jungle_leaves[persistent=true]
fill 147 254 362 147 255 362 minecraft:blue_terracotta
setblock 149 254 323 minecraft:blue_terracotta
setblock 150 254 363 minecraft:dark_prismarine
fill 151 254 344 151 260 344 minecraft:jungle_leaves[persistent=true]
fill 151 254 363 154 254 363 minecraft:blue_terracotta
fill 153 254 323 154 254 323 minecraft:blue_terracotta
setblock 155 254 323 minecraft:dark_prismarine
setblock 155 254 363 minecraft:dark_prismarine
fill 156 254 323 156 257 323 minecraft:blue_terracotta
setblock 156 254 362 minecraft:dark_prismarine
fill 156 254 363 156 257 363 minecraft:blue_terracotta
fill 157 254 324 158 254 324 minecraft:blue_terracotta
fill 157 254 362 157 257 362 minecraft:blue_terracotta
setblock 159 254 324 minecraft:dark_prismarine
setblock 160 254 323 minecraft:dark_prismarine
fill 160 254 324 160 257 324 minecraft:blue_terracotta
setblock 160 254 363 minecraft:dark_prismarine
fill 161 254 323 161 257 323 minecraft:blue_terracotta
setblock 161 254 362 minecraft:dark_prismarine
fill 161 254 363 161 257 363 minecraft:blue_terracotta
fill 162 254 324 163 254 324 minecraft:blue_terracotta
fill 162 254 362 162 255 362 minecraft:blue_terracotta
setblock 164 254 324 minecraft:dark_prismarine
setblock 165 254 323 minecraft:dark_prismarine
fill 165 254 324 165 257 324 minecraft:blue_terracotta
fill 165 254 357 165 255 359 minecraft:purple_concrete
setblock 165 254 363 minecraft:dark_prismarine
fill 166 254 323 166 257 323 minecraft:blue_terracotta
fill 166 254 356 166 255 356 minecraft:purple_concrete
fill 166 254 360 166 255 360 minecraft:purple_concrete
fill 166 254 363 166 255 363 minecraft:blue_terracotta
fill 167 254 324 167 255 324 minecraft:blue_terracotta
fill 167 254 355 169 255 355 minecraft:purple_concrete
fill 168 254 361 168 255 361 minecraft:purple_concrete
setblock 170 254 323 minecraft:dark_prismarine
fill 170 254 356 170 255 356 minecraft:purple_concrete
fill 170 254 360 170 255 360 minecraft:purple_concrete
fill 171 254 323 171 256 324 minecraft:blue_terracotta
fill 171 254 357 171 255 359 minecraft:purple_concrete
fill 172 254 324 173 254 324 minecraft:blue_terracotta
fill 173 254 363 173 255 363 minecraft:blue_terracotta
setblock 174 254 324 minecraft:dark_prismarine
setblock 175 254 323 minecraft:dark_prismarine
fill 175 254 324 175 256 325 minecraft:blue_terracotta
setblock 175 254 363 minecraft:dark_prismarine
fill 176 254 323 176 257 323 minecraft:blue_terracotta
setblock 176 254 362 minecraft:dark_prismarine
fill 176 254 363 176 257 363 minecraft:blue_terracotta
setblock 177 254 325 minecraft:blue_terracotta
fill 177 254 362 177 257 362 minecraft:blue_terracotta
setblock 178 254 325 minecraft:dark_prismarine
fill 178 254 326 179 256 326 minecraft:blue_terracotta
setblock 179 254 324 minecraft:dark_prismarine
fill 179 254 325 179 257 325 minecraft:blue_terracotta
setblock 180 254 323 minecraft:dark_prismarine
fill 180 254 324 180 257 324 minecraft:blue_terracotta
setblock 180 254 328 minecraft:dark_prismarine
fill 180 254 329 180 257 329 minecraft:blue_terracotta
setblock 180 254 363 minecraft:dark_prismarine
fill 181 254 323 181 257 323 minecraft:blue_terracotta
setblock 181 254 327 minecraft:dark_prismarine
fill 181 254 328 181 257 328 minecraft:blue_terracotta
setblock 181 254 332 minecraft:dark_prismarine
setblock 181 254 338 minecraft:blue_terracotta
setblock 181 254 342 minecraft:dark_prismarine
fill 181 254 343 181 257 343 minecraft:blue_terracotta
setblock 181 254 347 minecraft:dark_prismarine
fill 181 254 348 181 257 348 minecraft:blue_terracotta
fill 181 254 358 181 257 358 minecraft:blue_terracotta
setblock 181 254 362 minecraft:dark_prismarine
fill 181 254 363 181 257 363 minecraft:blue_terracotta
setblock 182 254 326 minecraft:dark_prismarine
fill 182 254 327 182 257 327 minecraft:blue_terracotta
setblock 182 254 331 minecraft:dark_prismarine
fill 182 254 332 182 257 332 minecraft:blue_terracotta
setblock 182 254 336 minecraft:dark_prismarine
fill 182 254 337 182 257 337 minecraft:blue_terracotta
setblock 182 254 341 minecraft:dark_prismarine
fill 182 254 342 182 257 342 minecraft:blue_terracotta
setblock 182 254 346 minecraft:dark_prismarine
fill 182 254 347 182 257 347 minecraft:blue_terracotta
setblock 182 254 351 minecraft:dark_prismarine
fill 182 254 352 182 255 354 minecraft:blue_terracotta
setblock 182 254 356 minecraft:dark_prismarine
fill 182 254 357 182 257 357 minecraft:blue_terracotta
setblock 182 254 361 minecraft:dark_prismarine
fill 182 254 362 182 257 362 minecraft:blue_terracotta
setblock 142 255 325 minecraft:dark_prismarine
fill 142 255 326 142 258 326 minecraft:blue_terracotta
setblock 142 255 330 minecraft:dark_prismarine
fill 142 255 331 142 258 331 minecraft:blue_terracotta
setblock 142 255 340 minecraft:dark_prismarine
fill 142 255 341 142 258 341 minecraft:blue_terracotta
setblock 142 255 345 minecraft:dark_prismarine
fill 142 255 346 142 255 349 minecraft:blue_terracotta
setblock 142 255 350 minecraft:dark_prismarine
fill 142 255 351 142 255 354 minecraft:blue_terracotta
setblock 142 255 355 minecraft:dark_prismarine
fill 142 255 356 142 258 356 minecraft:blue_terracotta
setblock 142 255 360 minecraft:dark_prismarine
fill 142 255 361 142 258 361 minecraft:blue_terracotta
setblock 143 255 324 minecraft:dark_prismarine
fill 143 255 325 143 258 325 minecraft:blue_terracotta
setblock 143 255 344 minecraft:dark_prismarine
fill 143 255 345 143 255 348 minecraft:blue_terracotta
setblock 143 255 349 minecraft:dark_prismarine
fill 143 255 350 143 255 353 minecraft:blue_terracotta
setblock 143 255 354 minecraft:dark_prismarine
fill 143 255 355 143 258 355 minecraft:blue_terracotta
setblock 143 255 359 minecraft:dark_prismarine
fill 143 255 360 143 258 360 minecraft:blue_terracotta
setblock 143 255 363 minecraft:blue_terracotta
setblock 144 255 323 minecraft:dark_prismarine
fill 144 255 324 144 258 324 minecraft:blue_terracotta
fill 144 255 346 144 255 347 minecraft:blue_terracotta
setblock 144 255 363 minecraft:dark_prismarine
fill 145 255 323 145 258 323 minecraft:blue_terracotta
setblock 145 255 362 minecraft:dark_prismarine
fill 145 255 363 148 255 363 minecraft:blue_terracotta
fill 146 255 362 146 256 362 minecraft:blue_terracotta
fill 148 255 342 149 260 343 minecraft:jungle_leaves[persistent=true]
fill 148 255 345 149 260 346 minecraft:jungle_leaves[persistent=true]
setblock 149 255 323 minecraft:dark_prismarine
fill 149 255 341 152 260 341 minecraft:jungle_leaves[persistent=true]
fill 149 255 347 152 260 347 minecraft:jungle_leaves[persistent=true]
setblock 149 255 363 minecraft:dark_prismarine
fill 150 255 323 153 255 323 minecraft:blue_terracotta
fill 150 255 363 153 255 363 minecraft:blue_terracotta
fill 151 255 339 152 259 340 minecraft:jungle_leaves[persistent=true]
fill 151 255 348 152 259 349 minecraft:jungle_leaves[persistent=true]
setblock 152 255 337 minecraft:spruce_planks
fill 153 255 339 153 259 339 minecraft:jungle_leaves[persistent=true]
fill 153 255 349 153 259 349 minecraft:jungle_leaves[persistent=true]
setblock 154 255 323 minecraft:dark_prismarine
fill 154 255 341 156 259 342 minecraft:jungle_leaves[persistent=true]
fill 154 255 346 156 259 347 minecraft:jungle_leaves[persistent=true]
setblock 154 255 363 minecraft:dark_prismarine
fill 155 255 323 155 258 323 minecraft:blue_terracotta
setblock 155 255 362 minecraft:dark_prismarine
fill 155 255 363 155 258 363 minecraft:blue_terracotta
fill 156 255 324 157 255 324 minecraft:blue_terracotta
fill 156 255 362 156 257 362 minecraft:blue_terracotta
fill 157 255 339 159 256 339 minecraft:jungle_leaves[persistent=true]
fill 157 255 341 157 257 341 minecraft:jungle_leaves[persistent=true]
fill 157 255 347 157 257 347 minecraft:jungle_leaves[persistent=true]
fill 157 255 349 159 256 349 minecraft:jungle_leaves[persistent=true]
setblock 158 255 324 minecraft:dark_prismarine
setblock 159 255 323 minecraft:dark_prismarine
fill 159 255 324 159 257 325 minecraft:blue_terracotta
setblock 159 255 363 minecraft:dark_prismarine
fill 160 255 323 160 258 323 minecraft:blue_terracotta
fill 160 255 325 161 255 325 minecraft:blue_terracotta
setblock 160 255 362 minecraft:dark_prismarine
fill 160 255 363 160 258 363 minecraft:blue_terracotta
fill 161 255 362 161 256 362 minecraft:blue_terracotta
setblock 162 255 324 minecraft:blue_terracotta
setblock 162 255 325 minecraft:dark_prismarine
setblock 163 255 324 minecraft:dark_prismarine
fill 163 255 325 163 258 325 minecraft:blue_terracotta
setblock 164 255 323 minecraft:dark_prismarine
fill 164 255 324 164 258 324 minecraft:blue_terracotta
setblock 164 255 358 minecraft:purple_concrete
setblock 164 255 363 minecraft:dark_prismarine
fill 165 255 323 165 258 323 minecraft:blue_terracotta
fill 165 255 339 167 255 339 minecraft:jungle_leaves[persistent=true]
fill 165 255 349 167 255 349 minecraft:jungle_leaves[persistent=true]
setblock 165 255 356 minecraft:purple_concrete
setblock 165 255 360 minecraft:purple_concrete
fill 165 255 363 165 256 363 minecraft:blue_terracotta
setblock 166 255 355 minecraft:purple_concrete
fill 166 255 361 167 255 361 minecraft:purple_concrete
fill 167 255 341 168 255 341 minecraft:jungle_leaves[persistent=true]
fill 167 255 347 168 255 347 minecraft:jungle_leaves[persistent=true]
fill 167 255 354 169 255 354 minecraft:purple_concrete
setblock 168 255 324 minecraft:dark_prismarine
setblock 168 255 342 minecraft:jungle_leaves[persistent=true]
setblock 168 255 346 minecraft:jungle_leaves[persistent=true]
setblock 168 255 363 minecraft:purple_concrete
setblock 169 255 323 minecraft:dark_prismarine
fill 169 255 324 170 257 324 minecraft:blue_terracotta
fill 169 255 361 170 255 361 minecraft:purple_concrete
fill 170 255 323 170 258 323 minecraft:blue_terracotta
setblock 170 255 355 minecraft:purple_concrete
setblock 171 255 356 minecraft:purple_concrete
setblock 171 255 360 minecraft:purple_concrete
setblock 172 255 324 minecraft:blue_terracotta
setblock 172 255 358 minecraft:purple_concrete
fill 172 255 363 172 256 363 minecraft:blue_terracotta
setblock 173 255 324 minecraft:dark_prismarine
fill 173 255 325 174 257 325 minecraft:blue_terracotta
setblock 174 255 323 minecraft:dark_prismarine
fill 174 255 324 174 258 324 minecraft:blue_terracotta
setblock 174 255 363 minecraft:dark_prismarine
fill 175 255 323 175 258 323 minecraft:blue_terracotta
setblock 175 255 342 minecraft:magenta_terracotta
setblock 175 255 362 minecraft:dark_prismarine
fill 175 255 363 175 258 363 minecraft:blue_terracotta
setblock 176 255 326 minecraft:dark_prismarine
fill 176 255 362 176 258 362 minecraft:blue_terracotta
setblock 177 255 325 minecraft:dark_prismarine
fill 177 255 326 177 258 326 minecraft:blue_terracotta
setblock 178 255 324 minecraft:dark_prismarine
fill 178 255 325 178 258 325 minecraft:blue_terracotta
setblock 179 255 323 minecraft:dark_prismarine
fill 179 255 324 179 258 324 minecraft:blue_terracotta
setblock 179 255 327 minecraft:blue_terracotta
setblock 179 255 328 minecraft:dark_prismarine
fill 179 255 361 179 256 361 minecraft:blue_terracotta
setblock 179 255 363 minecraft:dark_prismarine
fill 180 255 323 180 258 323 minecraft:blue_terracotta
setblock 180 255 326 minecraft:blue_terracotta
setblock 180 255 327 minecraft:dark_prismarine
fill 180 255 328 180 258 328 minecraft:blue_terracotta
fill 180 255 330 180 256 330 minecraft:blue_terracotta
fill 180 255 343 180 255 345 minecraft:blue_terracotta
setblock 180 255 362 minecraft:dark_prismarine
fill 180 255 363 180 258 363 minecraft:blue_terracotta
setblock 181 255 326 minecraft:dark_prismarine
fill 181 255 327 181 258 327 minecraft:blue_terracotta
setblock 181 255 331 minecraft:dark_prismarine
fill 181 255 332 181 258 332 minecraft:blue_terracotta
setblock 181 255 341 minecraft:dark_prismarine
fill 181 255 342 181 257 342 minecraft:blue_terracotta
setblock 181 255 346 minecraft:dark_prismarine
fill 181 255 347 181 258 347 minecraft:blue_terracotta
fill 181 255 349 181 255 350 minecraft:blue_terracotta
setblock 181 255 361 minecraft:dark_prismarine
fill 181 255 362 181 258 362 minecraft:blue_terracotta
setblock 182 255 325 minecraft:dark_prismarine
fill 182 255 326 182 258 326 minecraft:blue_terracotta
setblock 182 255 330 minecraft:dark_prismarine
fill 182 255 331 182 258 331 minecraft:blue_terracotta
setblock 182 255 335 minecraft:dark_prismarine
fill 182 255 336 182 257 336 minecraft:blue_terracotta
setblock 182 255 340 minecraft:dark_prismarine
fill 182 255 341 182 258 341 minecraft:blue_terracotta
setblock 182 255 345 minecraft:dark_prismarine
fill 182 255 346 182 258 346 minecraft:blue_terracotta
fill 182 255 348 182 255 349 minecraft:blue_terracotta
setblock 182 255 350 minecraft:dark_prismarine
fill 182 255 351 182 258 351 minecraft:blue_terracotta
setblock 182 255 355 minecraft:dark_prismarine
fill 182 255 356 182 258 356 minecraft:blue_terracotta
setblock 182 255 360 minecraft:dark_prismarine
fill 182 255 361 182 258 361 minecraft:blue_terracotta
setblock 142 256 324 minecraft:dark_prismarine
fill 142 256 325 142 259 325 minecraft:blue_terracotta
setblock 142 256 329 minecraft:dark_prismarine
fill 142 256 330 142 259 330 minecraft:blue_terracotta
setblock 142 256 332 minecraft:purple_concrete
setblock 142 256 339 minecraft:dark_prismarine
fill 142 256 340 142 258 340 minecraft:blue_terracotta
setblock 142 256 344 minecraft:dark_prismarine
fill 142 256 345 142 256 348 minecraft:blue_terracotta
setblock 142 256 349 minecraft:dark_prismarine
fill 142 256 350 142 256 353 minecraft:blue_terracotta
setblock 142 256 354 minecraft:dark_prismarine
fill 142 256 355 142 259 355 minecraft:blue_terracotta
setblock 142 256 359 minecraft:dark_prismarine
fill 142 256 360 142 259 360 minecraft:blue_terracotta
setblock 143 256 323 minecraft:dark_prismarine
fill 143 256 324 143 259 324 minecraft:blue_terracotta
setblock 143 256 328 minecraft:dark_prismarine
setblock 143 256 343 minecraft:dark_prismarine
fill 143 256 344 143 256 347 minecraft:blue_terracotta
setblock 143 256 348 minecraft:dark_prismarine
fill 143 256 349 143 256 352 minecraft:blue_terracotta
setblock 143 256 353 minecraft:dark_prismarine
fill 143 256 354 143 259 354 minecraft:blue_terracotta
setblock 143 256 358 minecraft:dark_prismarine
fill 143 256 359 143 258 359 minecraft:blue_terracotta
setblock 143 256 363 minecraft:dark_prismarine
fill 144 256 323 144 259 323 minecraft:blue_terracotta
fill 144 256 345 144 256 346 minecraft:blue_terracotta
setblock 144 256 347 minecraft:dark_prismarine
fill 144 256 348 144 258 349 minecraft:blue_terracotta
setblock 144 256 362 minecraft:dark_prismarine
fill 144 256 363 147 256 363 minecraft:blue_terracotta
fill 145 256 344 147 259 344 minecraft:jungle_leaves[persistent=true]
fill 145 256 362 145 257 362 minecraft:blue_terracotta
fill 146 256 341 147 259 343 minecraft:jungle_leaves[persistent=true]
fill 146 256 345 147 259 347 minecraft:jungle_leaves[persistent=true]
fill 147 256 340 150 259 340 minecraft:jungle_leaves[persistent=true]
fill 147 256 348 150 259 348 minecraft:jungle_leaves[persistent=true]
setblock 148 256 323 minecraft:dark_prismarine
fill 148 256 339 150 259 339 minecraft:jungle_leaves[persistent=true]
fill 148 256 341 148 259 341 minecraft:jungle_leaves[persistent=true]
fill 148 256 347 148 259 347 minecraft:jungle_leaves[persistent=true]
fill 148 256 349 150 259 349 minecraft:jungle_leaves[persistent=true]
setblock 148 256 363 minecraft:dark_prismarine
fill 149 256 323 152 256 323 minecraft:blue_terracotta
fill 149 256 363 152 256 363 minecraft:blue_terracotta
fill 151 256 338 151 259 338 minecraft:jungle_leaves[persistent=true]
fill 151 256 350 151 259 350 minecraft:jungle_leaves[persistent=true]
setblock 153 256 323 minecraft:dark_prismarine
setblock 153 256 363 minecraft:dark_prismarine
fill 154 256 323 154 258 324 minecraft:blue_terracotta
fill 154 256 363 154 259 363 minecraft:blue_terracotta
fill 155 256 324 156 256 324 minecraft:blue_terracotta
setblock 155 256 362 minecraft:blue_terracotta
setblock 157 256 324 minecraft:dark_prismarine
fill 157 256 325 158 258 325 minecraft:blue_terracotta
setblock 158 256 323 minecraft:dark_prismarine
fill 158 256 324 158 259 324 minecraft:blue_terracotta
setblock 158 256 363 minecraft:dark_prismarine
fill 159 256 323 159 259 323 minecraft:blue_terracotta
setblock 159 256 362 minecraft:dark_prismarine
fill 159 256 363 159 259 363 minecraft:blue_terracotta
setblock 160 256 325 minecraft:blue_terracotta
fill 160 256 362 160 257 362 minecraft:blue_terracotta
setblock 161 256 325 minecraft:dark_prismarine
setblock 162 256 324 minecraft:dark_prismarine
fill 162 256 325 162 259 325 minecraft:blue_terracotta
setblock 163 256 323 minecraft:dark_prismarine
fill 163 256 324 163 259 324 minecraft:blue_terracotta
fill 163 256 353 163 256 363 minecraft:dark_prismarine
fill 164 256 323 164 259 323 minecraft:blue_terracotta
fill 164 256 325 164 257 325 minecraft:blue_terracotta
fill 164 256 353 168 258 362 minecraft:dark_prismarine
fill 164 256 363 164 257 363 minecraft:blue_terracotta
fill 166 256 363 171 256 363 minecraft:dark_prismarine
setblock 167 256 324 minecraft:dark_prismarine
setblock 168 256 323 minecraft:dark_prismarine
fill 168 256 324 168 259 324 minecraft:blue_terracotta
fill 169 256 323 169 259 323 minecraft:blue_terracotta
fill 169 256 327 169 277 327 minecraft:magenta_terracotta
fill 169 256 353 173 258 356 minecraft:dark_prismarine
fill 169 256 359 173 258 362 minecraft:dark_prismarine
fill 170 256 357 173 258 358 minecraft:dark_prismarine
setblock 172 256 324 minecraft:dark_prismarine
fill 172 256 325 172 259 325 minecraft:blue_terracotta
setblock 173 256 323 minecraft:dark_prismarine
fill 173 256 324 173 259 324 minecraft:blue_terracotta
setblock 173 256 363 minecraft:dark_prismarine
fill 174 256 323 174 259 323 minecraft:blue_terracotta
fill 174 256 363 174 259 363 minecraft:blue_terracotta
setblock 175 256 326 minecraft:dark_prismarine
fill 175 256 362 175 259 362 minecraft:blue_terracotta
setblock 176 256 324 minecraft:blue_terracotta
setblock 176 256 325 minecraft:dark_prismarine
fill 176 256 326 176 259 326 minecraft:blue_terracotta
setblock 177 256 324 minecraft:dark_prismarine
fill 177 256 325 177 259 325 minecraft:blue_terracotta
setblock 178 256 323 minecraft:dark_prismarine
fill 178 256 324 178 259 324 minecraft:blue_terracotta
setblock 178 256 363 minecraft:dark_prismarine
fill 179 256 323 179 259 323 minecraft:blue_terracotta
setblock 179 256 327 minecraft:dark_prismarine
fill 179 256 328 179 259 328 minecraft:blue_terracotta
setblock 179 256 362 minecraft:dark_prismarine
fill 179 256 363 179 259 363 minecraft:blue_terracotta
setblock 180 256 326 minecraft:dark_prismarine
fill 180 256 327 180 259 327 minecraft:blue_terracotta
setblock 180 256 331 minecraft:dark_prismarine
fill 180 256 344 180 256 345 minecraft:blue_terracotta
setblock 180 256 346 minecraft:dark_prismarine
fill 180 256 347 180 258 347 minecraft:blue_terracotta
setblock 180 256 361 minecraft:dark_prismarine
fill 180 256 362 180 259 362 minecraft:blue_terracotta
setblock 181 256 325 minecraft:dark_prismarine
fill 181 256 326 181 259 326 minecraft:blue_terracotta
setblock 181 256 330 minecraft:dark_prismarine
fill 181 256 331 181 259 331 minecraft:blue_terracotta
fill 181 256 333 181 257 333 minecraft:blue_terracotta
setblock 181 256 340 minecraft:dark_prismarine
fill 181 256 341 181 257 341 minecraft:blue_terracotta
setblock 181 256 345 minecraft:dark_prismarine
fill 181 256 346 181 259 346 minecraft:blue_terracotta
setblock 181 256 349 minecraft:blue_terracotta
setblock 181 256 350 minecraft:dark_prismarine
fill 181 256 351 181 258 352 minecraft:blue_terracotta
setblock 181 256 360 minecraft:dark_prismarine
fill 181 256 361 181 259 361 minecraft:blue_terracotta
setblock 182 256 324 minecraft:dark_prismarine
fill 182 256 325 182 259 325 minecraft:blue_terracotta
setblock 182 256 329 minecraft:dark_prismarine
fill 182 256 330 182 259 330 minecraft:blue_terracotta
setblock 182 256 334 minecraft:dark_prismarine
fill 182 256 335 182 257 335 minecraft:blue_terracotta
setblock 182 256 339 minecraft:dark_prismarine
fill 182 256 340 182 258 340 minecraft:blue_terracotta
setblock 182 256 344 minecraft:dark_prismarine
fill 182 256 345 182 259 345 minecraft:blue_terracotta
setblock 182 256 348 minecraft:blue_terracotta
setblock 182 256 349 minecraft:dark_prismarine
fill 182 256 350 182 259 350 minecraft:blue_terracotta
fill 182 256 352 182 256 353 minecraft:blue_terracotta
setblock 182 256 354 minecraft:dark_prismarine
fill 182 256 355 182 259 355 minecraft:blue_terracotta
setblock 182 256 359 minecraft:dark_prismarine
fill 182 256 360 182 259 360 minecraft:blue_terracotta
setblock 142 257 323 minecraft:dark_prismarine
fill 142 257 324 142 260 324 minecraft:blue_terracotta
setblock 142 257 327 minecraft:blue_terracotta
setblock 142 257 328 minecraft:dark_prismarine
fill 142 257 329 142 260 329 minecraft:blue_terracotta
setblock 142 257 338 minecraft:purple_concrete
setblock 142 257 339 minecraft:blue_terracotta
setblock 142 257 343 minecraft:dark_prismarine
fill 142 257 344 142 257 347 minecraft:blue_terracotta
setblock 142 257 348 minecraft:dark_prismarine
fill 142 257 349 142 257 352 minecraft:blue_terracotta
setblock 142 257 353 minecraft:dark_prismarine
fill 142 257 354 142 260 354 minecraft:blue_terracotta
setblock 142 257 358 minecraft:dark_prismarine
fill 142 257 359 142 260 359 minecraft:blue_terracotta
setblock 142 257 362 minecraft:blue_terracotta
setblock 142 257 363 minecraft:dark_prismarine
fill 143 257 323 143 260 323 minecraft:blue_terracotta
setblock 143 257 327 minecraft:dark_prismarine
fill 143 257 328 143 258 328 minecraft:blue_terracotta
setblock 143 257 342 minecraft:dark_prismarine
fill 143 257 343 143 257 346 minecraft:blue_terracotta
setblock 143 257 347 minecraft:dark_prismarine
fill 143 257 348 143 257 351 minecraft:blue_terracotta
setblock 143 257 352 minecraft:dark_prismarine
fill 143 257 353 143 260 353 minecraft:blue_terracotta
setblock 143 257 357 minecraft:dark_prismarine
fill 143 257 358 143 258 358 minecraft:blue_terracotta
setblock 143 257 362 minecraft:dark_prismarine
fill 143 257 363 146 257 363 minecraft:blue_terracotta
setblock 144 257 325 minecraft:light[level=12]
setblock 144 257 332 minecraft:light[level=12]
setblock 144 257 339 minecraft:light[level=12]
setblock 144 257 346 minecraft:dark_prismarine
fill 144 257 347 144 258 347 minecraft:blue_terracotta
setblock 144 257 350 minecraft:blue_terracotta
setblock 144 257 353 minecraft:light[level=12]
setblock 144 257 360 minecraft:light[level=12]
fill 144 257 362 144 258 362 minecraft:blue_terracotta
fill 145 257 341 145 258 343 minecraft:jungle_leaves[persistent=true]
fill 145 257 345 145 258 347 minecraft:jungle_leaves[persistent=true]
fill 146 257 340 146 258 340 minecraft:jungle_leaves[persistent=true]
fill 146 257 348 146 258 348 minecraft:jungle_leaves[persistent=true]
setblock 147 257 323 minecraft:dark_prismarine
fill 147 257 339 147 258 339 minecraft:jungle_leaves[persistent=true]
fill 147 257 349 147 258 349 minecraft:jungle_leaves[persistent=true]
setblock 147 257 363 minecraft:dark_prismarine
fill 148 257 323 151 257 323 minecraft:blue_terracotta
fill 148 257 338 150 258 338 minecraft:jungle_leaves[persistent=true]
fill 148 257 350 150 258 350 minecraft:jungle_leaves[persistent=true]
fill 148 257 363 151 257 363 minecraft:blue_terracotta
setblock 151 257 325 minecraft:light[level=12]
setblock 151 257 332 minecraft:light[level=12]
setblock 151 257 353 minecraft:light[level=12]
setblock 151 257 360 minecraft:light[level=12]
setblock 152 257 323 minecraft:dark_prismarine
fill 152 257 338 154 258 338 minecraft:jungle_leaves[persistent=true]
fill 152 257 350 154 258 350 minecraft:jungle_leaves[persistent=true]
setblock 152 257 363 minecraft:dark_prismarine
fill 153 257 323 153 260 323 minecraft:blue_terracotta
fill 153 257 363 153 260 363 minecraft:blue_terracotta
setblock 155 257 324 minecraft:blue_terracotta
fill 155 257 339 155 258 340 minecraft:jungle_leaves[persistent=true]
fill 155 257 348 155 258 349 minecraft:jungle_leaves[persistent=true]
setblock 156 257 324 minecraft:dark_prismarine
fill 156 257 325 156 260 325 minecraft:blue_terracotta
fill 156 257 340 156 258 340 minecraft:jungle_leaves[persistent=true]
fill 156 257 348 156 258 348 minecraft:jungle_leaves[persistent=true]
setblock 157 257 323 minecraft:dark_prismarine
fill 157 257 324 157 260 324 minecraft:blue_terracotta
setblock 157 257 363 minecraft:dark_prismarine
fill 158 257 323 158 260 323 minecraft:blue_terracotta
setblock 158 257 332 minecraft:light[level=12]
setblock 158 257 339 minecraft:light[level=12]
setblock 158 257 353 minecraft:light[level=12]
setblock 158 257 360 minecraft:light[level=12]
setblock 158 257 362 minecraft:dark_prismarine
fill 158 257 363 158 260 363 minecraft:blue_terracotta
setblock 159 257 362 minecraft:blue_terracotta
setblock 160 257 325 minecraft:dark_prismarine
setblock 161 257 324 minecraft:dark_prismarine
fill 161 257 325 161 259 325 minecraft:blue_terracotta
setblock 162 257 323 minecraft:dark_prismarine
fill 162 257 324 162 260 324 minecraft:blue_terracotta
setblock 162 257 363 minecraft:dark_prismarine
fill 163 257 323 163 260 323 minecraft:blue_terracotta
fill 163 257 353 163 258 362 minecraft:dark_prismarine
fill 163 257 363 163 258 363 minecraft:blue_terracotta
setblock 165 257 325 minecraft:light[level=12]
setblock 165 257 332 minecraft:light[level=12]
setblock 165 257 339 minecraft:light[level=12]
fill 165 257 363 170 257 363 minecraft:dark_prismarine
setblock 166 257 324 minecraft:dark_prismarine
setblock 167 257 323 minecraft:dark_prismarine
fill 167 257 324 167 260 324 minecraft:blue_terracotta
fill 168 257 323 168 260 323 minecraft:blue_terracotta
setblock 171 257 323 minecraft:blue_terracotta
setblock 171 257 324 minecraft:dark_prismarine
fill 171 257 325 171 260 325 minecraft:blue_terracotta
setblock 171 257 363 minecraft:blue_terracotta
setblock 172 257 323 minecraft:dark_prismarine
fill 172 257 324 172 260 324 minecraft:blue_terracotta
setblock 172 257 332 minecraft:light[level=12]
setblock 172 257 339 minecraft:light[level=12]
setblock 172 257 346 minecraft:light[level=12]
setblock 172 257 363 minecraft:dark_prismarine
fill 173 257 323 173 260 323 minecraft:blue_terracotta
fill 173 257 363 173 260 363 minecraft:blue_terracotta
setblock 174 257 326 minecraft:dark_prismarine
setblock 175 257 324 minecraft:blue_terracotta
setblock 175 257 325 minecraft:dark_prismarine
fill 175 257 326 175 260 326 minecraft:blue_terracotta
fill 175 257 342 175 268 342 minecraft:magenta_terracotta
setblock 176 257 324 minecraft:dark_prismarine
fill 176 257 325 176 260 325 minecraft:blue_terracotta
setblock 177 257 323 minecraft:dark_prismarine
fill 177 257 324 177 260 324 minecraft:blue_terracotta
setblock 177 257 363 minecraft:dark_prismarine
fill 178 257 323 178 260 323 minecraft:blue_terracotta
setblock 178 257 326 minecraft:blue_terracotta
setblock 178 257 362 minecraft:dark_prismarine
fill 178 257 363 178 260 363 minecraft:blue_terracotta
fill 178 257 364 178 308 364 minecraft:blue_concrete
setblock 179 257 326 minecraft:dark_prismarine
fill 179 257 327 179 260 327 minecraft:blue_terracotta
fill 179 257 329 179 258 329 minecraft:blue_terracotta
setblock 179 257 332 minecraft:light[level=12]
setblock 179 257 339 minecraft:light[level=12]
setblock 179 257 346 minecraft:light[level=12]
setblock 179 257 353 minecraft:light[level=12]
setblock 179 257 360 minecraft:light[level=12]
setblock 179 257 361 minecraft:dark_prismarine
fill 179 257 362 179 260 362 minecraft:blue_terracotta
setblock 179 257 364 minecraft:light_blue_wool
setblock 180 257 325 minecraft:dark_prismarine
fill 180 257 326 180 260 326 minecraft:blue_terracotta
setblock 180 257 330 minecraft:dark_prismarine
fill 180 257 331 180 259 331 minecraft:blue_terracotta
setblock 180 257 344 minecraft:blue_terracotta
setblock 180 257 345 minecraft:dark_prismarine
fill 180 257 346 180 258 346 minecraft:blue_terracotta
fill 180 257 348 180 258 348 minecraft:blue_terracotta
fill 180 257 361 180 258 361 minecraft:blue_terracotta
fill 180 257 364 181 308 364 minecraft:blue_concrete
setblock 181 257 324 minecraft:dark_prismarine
fill 181 257 325 181 260 325 minecraft:blue_terracotta
setblock 181 257 329 minecraft:dark_prismarine
fill 181 257 330 181 260 330 minecraft:blue_terracotta
setblock 181 257 344 minecraft:dark_prismarine
fill 181 257 345 181 259 345 minecraft:blue_terracotta
setblock 181 257 349 minecraft:dark_prismarine
fill 181 257 350 181 260 350 minecraft:blue_terracotta
setblock 181 257 353 minecraft:blue_terracotta
setblock 181 257 357 minecraft:blue_terracotta
setblock 181 257 359 minecraft:dark_prismarine
fill 181 257 360 181 259 360 minecraft:blue_terracotta
setblock 182 257 323 minecraft:dark_prismarine
fill 182 257 324 182 260 324 minecraft:blue_terracotta
setblock 182 257 328 minecraft:dark_prismarine
fill 182 257 329 182 260 329 minecraft:blue_terracotta
setblock 182 257 333 minecraft:dark_prismarine
fill 182 257 334 182 258 334 minecraft:blue_terracotta
setblock 182 257 338 minecraft:dark_prismarine
setblock 182 257 339 minecraft:blue_terracotta
setblock 182 257 343 minecraft:dark_prismarine
fill 182 257 344 182 260 344 minecraft:blue_terracotta
setblock 182 257 348 minecraft:dark_prismarine
fill 182 257 349 182 260 349 minecraft:blue_terracotta
setblock 182 257 352 minecraft:blue_terracotta
setblock 182 257 353 minecraft:dark_prismarine
fill 182 257 354 182 260 354 minecraft:blue_terracotta
setblock 182 257 358 minecraft:dark_prismarine
fill 182 257 359 182 260 359 minecraft:blue_terracotta
setblock 182 257 363 minecraft:dark_prismarine
setblock 183 257 343 minecraft:light_blue_wool
fill 183 257 344 183 308 344 minecraft:blue_concrete
fill 142 258 323 142 261 323 minecraft:blue_terracotta
setblock 142 258 327 minecraft:dark_prismarine
fill 142 258 328 142 261 328 minecraft:blue_terracotta
setblock 142 258 342 minecraft:dark_prismarine
fill 142 258 343 142 258 346 minecraft:blue_terracotta
setblock 142 258 347 minecraft:dark_prismarine
fill 142 258 348 142 258 351 minecraft:blue_terracotta
setblock 142 258 352 minecraft:dark_prismarine
fill 142 258 353 142 261 353 minecraft:blue_terracotta
setblock 142 258 357 minecraft:dark_prismarine
fill 142 258 358 142 261 358 minecraft:blue_terracotta
setblock 142 258 362 minecraft:dark_prismarine
fill 142 258 363 145 258 363 minecraft:blue_terracotta
setblock 143 258 326 minecraft:dark_prismarine
fill 143 258 327 143 259 327 minecraft:blue_terracotta
fill 143 258 343 143 258 345 minecraft:blue_terracotta
setblock 143 258 346 minecraft:dark_prismarine
fill 143 258 347 143 258 350 minecraft:blue_terracotta
setblock 143 258 351 minecraft:dark_prismarine
fill 143 258 352 143 261 352 minecraft:blue_terracotta
setblock 143 258 356 minecraft:dark_prismarine
setblock 143 258 357 minecraft:blue_terracotta
setblock 143 258 361 minecraft:dark_prismarine
fill 143 258 362 143 259 362 minecraft:blue_terracotta
setblock 144 258 346 minecraft:blue_terracotta
setblock 144 258 350 minecraft:dark_prismarine
setblock 146 258 323 minecraft:dark_prismarine
setblock 146 258 363 minecraft:dark_prismarine
fill 147 258 323 150 258 323 minecraft:blue_terracotta
fill 147 258 363 150 258 363 minecraft:blue_terracotta
setblock 151 258 323 minecraft:dark_prismarine
setblock 151 258 363 minecraft:dark_prismarine
fill 152 258 323 152 261 323 minecraft:blue_terracotta
fill 152 258 363 152 259 363 minecraft:blue_terracotta
fill 153 258 324 153 259 324 minecraft:blue_terracotta
setblock 155 258 324 minecraft:dark_prismarine
setblock 156 258 323 minecraft:dark_prismarine
fill 156 258 324 156 261 324 minecraft:blue_terracotta
setblock 156 258 363 minecraft:dark_prismarine
fill 157 258 323 157 261 323 minecraft:blue_terracotta
fill 157 258 363 157 260 363 minecraft:blue_terracotta
setblock 159 258 324 minecraft:blue_terracotta
setblock 159 258 325 minecraft:dark_prismarine
setblock 160 258 324 minecraft:dark_prismarine
fill 160 258 325 160 260 325 minecraft:blue_terracotta
setblock 161 258 323 minecraft:dark_prismarine
fill 161 258 324 161 261 324 minecraft:blue_terracotta
setblock 161 258 363 minecraft:dark_prismarine
fill 162 258 323 162 261 323 minecraft:blue_terracotta
setblock 162 258 363 minecraft:blue_terracotta
setblock 164 258 325 minecraft:dark_prismarine
fill 164 258 363 166 258 363 minecraft:dark_prismarine
setblock 165 258 324 minecraft:dark_prismarine
setblock 166 258 323 minecraft:dark_prismarine
fill 166 258 324 166 259 324 minecraft:blue_terracotta
fill 167 258 323 167 261 323 minecraft:blue_terracotta
setblock 167 258 363 minecraft:purple_concrete
fill 168 258 363 171 258 363 minecraft:dark_prismarine
setblock 169 258 324 minecraft:blue_terracotta
setblock 170 258 324 minecraft:dark_prismarine
fill 170 258 325 170 260 325 minecraft:blue_terracotta
setblock 171 258 323 minecraft:dark_prismarine
fill 171 258 324 171 261 324 minecraft:blue_terracotta
fill 172 258 323 172 261 323 minecraft:blue_terracotta
setblock 172 258 363 minecraft:blue_terracotta
setblock 173 258 325 minecraft:blue_terracotta
setblock 173 258 326 minecraft:dark_prismarine
setblock 174 258 325 minecraft:dark_prismarine
fill 174 258 326 174 261 326 minecraft:blue_terracotta
setblock 175 258 324 minecraft:dark_prismarine
fill 175 258 325 175 261 325 minecraft:blue_terracotta
setblock 176 258 323 minecraft:dark_prismarine
fill 176 258 324 176 261 324 minecraft:blue_terracotta
setblock 176 258 363 minecraft:dark_prismarine
fill 177 258 323 177 261 323 minecraft:blue_terracotta
setblock 177 258 327 minecraft:dark_prismarine
setblock 177 258 362 minecraft:dark_prismarine
fill 177 258 363 177 261 363 minecraft:blue_terracotta
setblock 178 258 326 minecraft:dark_prismarine
fill 178 258 327 178 259 327 minecraft:blue_terracotta
fill 178 258 362 178 261 362 minecraft:blue_terracotta
setblock 179 258 325 minecraft:dark_prismarine
fill 179 258 326 179 261 326 minecraft:blue_terracotta
setblock 179 258 361 minecraft:blue_terracotta
fill 179 258 364 179 308 364 minecraft:blue_concrete
setblock 180 258 324 minecraft:dark_prismarine
fill 180 258 325 180 261 325 minecraft:blue_terracotta
setblock 180 258 329 minecraft:dark_prismarine
fill 180 258 330 180 261 330 minecraft:blue_terracotta
setblock 180 258 349 minecraft:dark_prismarine
setblock 181 258 323 minecraft:dark_prismarine
fill 181 258 324 181 261 324 minecraft:blue_terracotta
setblock 181 258 328 minecraft:dark_prismarine
fill 181 258 329 181 261 329 minecraft:blue_terracotta
setblock 181 258 343 minecraft:dark_prismarine
fill 181 258 344 181 259 344 minecraft:blue_terracotta
setblock 181 258 348 minecraft:dark_prismarine
fill 181 258 349 181 261 349 minecraft:blue_terracotta
setblock 181 258 353 minecraft:dark_prismarine
fill 181 258 354 181 261 354 minecraft:blue_terracotta
setblock 181 258 358 minecraft:dark_prismarine
fill 181 258 359 181 259 359 minecraft:blue_terracotta
setblock 181 258 363 minecraft:dark_prismarine
fill 182 258 323 182 261 323 minecraft:blue_terracotta
setblock 182 258 327 minecraft:dark_prismarine
fill 182 258 328 182 261 328 minecraft:blue_terracotta
setblock 182 258 332 minecraft:dark_prismarine
fill 182 258 333 182 260 333 minecraft:blue_terracotta
setblock 182 258 342 minecraft:dark_prismarine
fill 182 258 343 182 259 343 minecraft:blue_terracotta
setblock 182 258 347 minecraft:dark_prismarine
fill 182 258 348 182 261 348 minecraft:blue_terracotta
setblock 182 258 352 minecraft:dark_prismarine
fill 182 258 353 182 261 353 minecraft:blue_terracotta
setblock 182 258 357 minecraft:dark_prismarine
fill 182 258 358 182 261 358 minecraft:blue_terracotta
setblock 182 258 362 minecraft:dark_prismarine
fill 182 258 363 182 261 363 minecraft:blue_terracotta
fill 183 258 343 183 308 343 minecraft:blue_concrete
fill 141 259 357 141 308 358 minecraft:blue_concrete
setblock 141 259 359 minecraft:cyan_concrete
fill 141 259 360 141 308 360 minecraft:blue_concrete
setblock 142 259 326 minecraft:dark_prismarine
fill 142 259 327 142 262 327 minecraft:blue_terracotta
setblock 142 259 331 minecraft:dark_prismarine
setblock 142 259 341 minecraft:dark_prismarine
fill 142 259 342 142 259 345 minecraft:blue_terracotta
setblock 142 259 346 minecraft:dark_prismarine
fill 142 259 347 142 259 350 minecraft:blue_terracotta
setblock 142 259 351 minecraft:dark_prismarine
fill 142 259 352 142 262 352 minecraft:blue_terracotta
setblock 142 259 356 minecraft:dark_prismarine
fill 142 259 357 142 262 357 minecraft:blue_terracotta
setblock 142 259 361 minecraft:dark_prismarine
fill 142 259 362 142 261 363 minecraft:blue_terracotta
setblock 143 259 325 minecraft:dark_prismarine
setblock 143 259 326 minecraft:blue_terracotta
setblock 143 259 344 minecraft:blue_terracotta
setblock 143 259 345 minecraft:dark_prismarine
fill 143 259 346 143 259 349 minecraft:blue_terracotta
setblock 143 259 350 minecraft:dark_prismarine
fill 143 259 351 143 262 351 minecraft:blue_terracotta
setblock 143 259 355 minecraft:dark_prismarine
setblock 143 259 356 minecraft:blue_terracotta
fill 143 259 363 144 259 363 minecraft:blue_terracotta
setblock 144 259 348 minecraft:blue_terracotta
setblock 144 259 349 minecraft:dark_prismarine
setblock 144 259 350 minecraft:blue_terracotta
setblock 145 259 323 minecraft:dark_prismarine
setblock 145 259 363 minecraft:dark_prismarine
setblock 146 259 323 minecraft:blue_terracotta
setblock 146 259 363 minecraft:blue_terracotta
setblock 151 259 323 minecraft:blue_terracotta
fill 152 259 362 154 260 362 minecraft:dark_prismarine
setblock 154 259 323 minecraft:blue_terracotta
setblock 154 259 324 minecraft:dark_prismarine
setblock 155 259 323 minecraft:dark_prismarine
fill 155 259 324 155 261 324 minecraft:blue_terracotta
setblock 155 259 340 minecraft:jungle_leaves[persistent=true]
setblock 155 259 348 minecraft:jungle_leaves[persistent=true]
setblock 155 259 363 minecraft:dark_prismarine
fill 156 259 323 156 262 323 minecraft:blue_terracotta
fill 156 259 363 156 261 363 minecraft:blue_terracotta
setblock 157 259 325 minecraft:blue_terracotta
setblock 157 259 344 minecraft:jungle_leaves[persistent=true]
setblock 158 259 325 minecraft:dark_prismarine
setblock 159 259 324 minecraft:dark_prismarine
fill 159 259 325 159 260 325 minecraft:blue_terracotta
setblock 160 259 323 minecraft:dark_prismarine
fill 160 259 324 160 261 324 minecraft:blue_terracotta
setblock 160 259 363 minecraft:dark_prismarine
fill 161 259 323 161 262 323 minecraft:blue_terracotta
fill 161 259 348 162 272 349 minecraft:dark_prismarine
setblock 161 259 363 minecraft:blue_terracotta
fill 163 259 353 163 272 353 minecraft:dark_prismarine
setblock 163 259 354 minecraft:sea_lantern
fill 163 259 355 163 272 355 minecraft:dark_prismarine
setblock 163 259 356 minecraft:sea_lantern
fill 163 259 357 163 272 357 minecraft:dark_prismarine
setblock 163 259 358 minecraft:sea_lantern
fill 163 259 359 163 272 359 minecraft:dark_prismarine
setblock 163 259 360 minecraft:sea_lantern
fill 163 259 361 163 272 361 minecraft:dark_prismarine
setblock 163 259 362 minecraft:sea_lantern
fill 163 259 363 163 270 363 minecraft:dark_prismarine
setblock 164 259 324 minecraft:dark_prismarine
setblock 164 259 353 minecraft:sea_lantern
fill 164 259 354 164 272 354 minecraft:dark_prismarine
setblock 164 259 355 minecraft:sea_lantern
fill 164 259 356 164 272 356 minecraft:dark_prismarine
setblock 164 259 357 minecraft:sea_lantern
fill 164 259 358 164 272 358 minecraft:dark_prismarine
setblock 164 259 359 minecraft:sea_lantern
fill 164 259 360 164 272 360 minecraft:dark_prismarine
setblock 164 259 361 minecraft:sea_lantern
fill 164 259 362 164 272 362 minecraft:dark_prismarine
setblock 164 259 363 minecraft:sea_lantern
setblock 165 259 323 minecraft:dark_prismarine
fill 165 259 324 165 260 324 minecraft:blue_terracotta
fill 165 259 353 165 272 353 minecraft:dark_prismarine
setblock 165 259 354 minecraft:sea_lantern
fill 165 259 355 165 272 355 minecraft:dark_prismarine
setblock 165 259 356 minecraft:sea_lantern
fill 165 259 357 165 272 357 minecraft:dark_prismarine
setblock 165 259 358 minecraft:sea_lantern
fill 165 259 359 165 272 359 minecraft:dark_prismarine
setblock 165 259 360 minecraft:sea_lantern
fill 165 259 361 165 272 361 minecraft:dark_prismarine
setblock 165 259 362 minecraft:sea_lantern
fill 165 259 363 165 264 363 minecraft:dark_prismarine
fill 166 259 323 166 261 323 minecraft:blue_terracotta
setblock 166 259 353 minecraft:sea_lantern
fill 166 259 354 166 272 354 minecraft:dark_prismarine
setblock 166 259 355 minecraft:sea_lantern
fill 166 259 356 166 272 356 minecraft:dark_prismarine
setblock 166 259 357 minecraft:sea_lantern
fill 166 259 358 166 272 358 minecraft:dark_prismarine
setblock 166 259 359 minecraft:sea_lantern
fill 166 259 360 166 272 360 minecraft:dark_prismarine
setblock 166 259 361 minecraft:sea_lantern
fill 166 259 362 166 271 362 minecraft:dark_prismarine
setblock 166 259 363 minecraft:sea_lantern
fill 167 259 353 167 272 353 minecraft:dark_prismarine
setblock 167 259 354 minecraft:sea_lantern
fill 167 259 355 167 272 355 minecraft:dark_prismarine
setblock 167 259 356 minecraft:sea_lantern
fill 167 259 357 167 272 357 minecraft:dark_prismarine
setblock 167 259 358 minecraft:sea_lantern
fill 167 259 359 167 272 359 minecraft:dark_prismarine
setblock 167 259 360 minecraft:sea_lantern
fill 167 259 361 167 271 361 minecraft:dark_prismarine
setblock 167 259 362 minecraft:sea_lantern
fill 167 259 363 167 268 363 minecraft:dark_prismarine
setblock 168 259 353 minecraft:sea_lantern
fill 168 259 354 168 272 354 minecraft:dark_prismarine
setblock 168 259 355 minecraft:sea_lantern
fill 168 259 356 168 272 356 minecraft:dark_prismarine
setblock 168 259 357 minecraft:sea_lantern
fill 168 259 358 168 272 358 minecraft:dark_prismarine
setblock 168 259 359 minecraft:sea_lantern
fill 168 259 360 168 272 360 minecraft:dark_prismarine
setblock 168 259 361 minecraft:sea_lantern
fill 168 259 362 168 269 362 minecraft:dark_prismarine
setblock 168 259 363 minecraft:sea_lantern
setblock 169 259 324 minecraft:dark_prismarine
fill 169 259 353 169 272 353 minecraft:dark_prismarine
setblock 169 259 354 minecraft:sea_lantern
fill 169 259 355 169 272 355 minecraft:dark_prismarine
setblock 169 259 356 minecraft:sea_lantern
setblock 169 259 358 minecraft:sea_lantern
fill 169 259 359 169 269 359 minecraft:dark_prismarine
setblock 169 259 360 minecraft:sea_lantern
fill 169 259 361 169 270 361 minecraft:dark_prismarine
setblock 169 259 362 minecraft:sea_lantern
fill 169 259 363 169 267 363 minecraft:dark_prismarine
setblock 170 259 323 minecraft:dark_prismarine
fill 170 259 324 170 262 324 minecraft:blue_terracotta
setblock 170 259 353 minecraft:sea_lantern
fill 170 259 354 170 272 354 minecraft:dark_prismarine
setblock 170 259 355 minecraft:sea_lantern
fill 170 259 356 170 272 356 minecraft:dark_prismarine
setblock 170 259 357 minecraft:sea_lantern
fill 170 259 358 170 260 358 minecraft:dark_prismarine
setblock 170 259 359 minecraft:sea_lantern
fill 170 259 360 170 272 360 minecraft:dark_prismarine
setblock 170 259 361 minecraft:sea_lantern
fill 170 259 362 170 268 362 minecraft:dark_prismarine
setblock 170 259 363 minecraft:sea_lantern
fill 171 259 323 171 262 323 minecraft:blue_terracotta
fill 171 259 353 171 272 353 minecraft:dark_prismarine
setblock 171 259 354 minecraft:sea_lantern
fill 171 259 355 171 272 355 minecraft:dark_prismarine
setblock 171 259 356 minecraft:sea_lantern
fill 171 259 357 171 272 357 minecraft:dark_prismarine
setblock 171 259 358 minecraft:sea_lantern
fill 171 259 359 171 272 359 minecraft:dark_prismarine
setblock 171 259 360 minecraft:sea_lantern
fill 171 259 361 171 270 361 minecraft:dark_prismarine
setblock 171 259 362 minecraft:sea_lantern
fill 171 259 363 171 264 363 minecraft:dark_prismarine
setblock 172 259 353 minecraft:sea_lantern
fill 172 259 354 172 272 354 minecraft:dark_prismarine
setblock 172 259 355 minecraft:sea_lantern
fill 172 259 356 172 272 356 minecraft:dark_prismarine
setblock 172 259 357 minecraft:sea_lantern
fill 172 259 358 172 272 358 minecraft:dark_prismarine
setblock 172 259 359 minecraft:sea_lantern
fill 172 259 360 172 270 360 minecraft:dark_prismarine
setblock 172 259 361 minecraft:sea_lantern
fill 172 259 362 172 268 362 minecraft:dark_prismarine
setblock 172 259 363 minecraft:sea_lantern
setblock 173 259 325 minecraft:dark_prismarine
fill 173 259 326 173 261 326 minecraft:blue_terracotta
fill 173 259 353 173 272 353 minecraft:dark_prismarine
setblock 173 259 354 minecraft:sea_lantern
fill 173 259 355 173 272 355 minecraft:dark_prismarine
setblock 173 259 356 minecraft:sea_lantern
fill 173 259 357 173 272 357 minecraft:dark_prismarine
setblock 173 259 358 minecraft:sea_lantern
fill 173 259 359 173 272 359 minecraft:dark_prismarine
setblock 173 259 360 minecraft:sea_lantern
fill 173 259 361 173 268 361 minecraft:dark_prismarine
setblock 173 259 362 minecraft:sea_lantern
setblock 174 259 324 minecraft:dark_prismarine
fill 174 259 325 174 262 325 minecraft:blue_terracotta
setblock 175 259 323 minecraft:dark_prismarine
fill 175 259 324 175 262 324 minecraft:blue_terracotta
setblock 175 259 363 minecraft:dark_prismarine
fill 176 259 323 176 262 323 minecraft:blue_terracotta
setblock 176 259 362 minecraft:dark_prismarine
fill 176 259 363 176 262 363 minecraft:blue_terracotta
setblock 177 259 326 minecraft:dark_prismarine
setblock 177 259 327 minecraft:blue_terracotta
fill 177 259 362 177 262 362 minecraft:blue_terracotta
setblock 178 259 325 minecraft:dark_prismarine
fill 178 259 326 178 261 326 minecraft:blue_terracotta
setblock 179 259 324 minecraft:dark_prismarine
fill 179 259 325 179 262 325 minecraft:blue_terracotta
setblock 179 259 329 minecraft:dark_prismarine
setblock 180 259 323 minecraft:dark_prismarine
fill 180 259 324 180 262 324 minecraft:blue_terracotta
setblock 180 259 328 minecraft:dark_prismarine
fill 180 259 329 180 261 329 minecraft:blue_terracotta
setblock 180 259 363 minecraft:dark_prismarine
fill 181 259 323 181 262 323 minecraft:blue_terracotta
setblock 181 259 327 minecraft:dark_prismarine
fill 181 259 328 181 262 328 minecraft:blue_terracotta
setblock 181 259 332 minecraft:dark_prismarine
setblock 181 259 347 minecraft:dark_prismarine
fill 181 259 348 181 261 348 minecraft:blue_terracotta
setblock 181 259 351 minecraft:blue_terracotta
setblock 181 259 352 minecraft:dark_prismarine
fill 181 259 353 181 262 353 minecraft:blue_terracotta
setblock 181 259 362 minecraft:dark_prismarine
fill 181 259 363 181 262 363 minecraft:blue_terracotta
setblock 182 259 326 minecraft:dark_prismarine
fill 182 259 327 182 262 327 minecraft:blue_terracotta
setblock 182 259 331 minecraft:dark_prismarine
fill 182 259 332 182 261 332 minecraft:blue_terracotta
setblock 182 259 336 minecraft:purple_concrete
setblock 182 259 342 minecraft:blue_terracotta
setblock 182 259 346 minecraft:dark_prismarine
fill 182 259 347 182 262 347 minecraft:blue_terracotta
setblock 182 259 351 minecraft:dark_prismarine
fill 182 259 352 182 262 352 minecraft:blue_terracotta
setblock 182 259 356 minecraft:dark_prismarine
fill 182 259 357 182 262 357 minecraft:blue_terracotta
setblock 182 259 361 minecraft:dark_prismarine
fill 182 259 362 182 262 362 minecraft:blue_terracotta
fill 141 260 359 141 308 359 minecraft:blue_concrete
setblock 142 260 325 minecraft:dark_prismarine
fill 142 260 326 142 262 326 minecraft:blue_terracotta
setblock 142 260 330 minecraft:dark_prismarine
setblock 142 260 331 minecraft:blue_terracotta
setblock 142 260 337 minecraft:purple_concrete
fill 142 260 342 142 260 344 minecraft:blue_terracotta
setblock 142 260 345 minecraft:dark_prismarine
fill 142 260 346 142 260 349 minecraft:blue_terracotta
setblock 142 260 350 minecraft:dark_prismarine
fill 142 260 351 142 263 351 minecraft:blue_terracotta
setblock 142 260 355 minecraft:dark_prismarine
fill 142 260 356 142 263 356 minecraft:blue_terracotta
setblock 142 260 360 minecraft:dark_prismarine
fill 142 260 361 142 261 361 minecraft:blue_terracotta
fill 143 260 345 143 260 348 minecraft:blue_terracotta
setblock 143 260 349 minecraft:dark_prismarine
fill 143 260 350 143 263 350 minecraft:blue_terracotta
setblock 143 260 354 minecraft:dark_prismarine
setblock 143 260 355 minecraft:blue_terracotta
setblock 143 260 363 minecraft:blue_terracotta
setblock 144 260 323 minecraft:dark_prismarine
setblock 144 260 363 minecraft:dark_prismarine
setblock 145 260 323 minecraft:purple_concrete
fill 152 260 324 153 261 324 minecraft:dark_prismarine
fill 152 260 361 154 261 361 minecraft:dark_prismarine
setblock 152 260 363 minecraft:dark_prismarine
fill 153 260 325 153 263 325 minecraft:dark_prismarine
fill 153 260 341 153 260 343 minecraft:jungle_leaves[persistent=true]
fill 153 260 345 153 260 347 minecraft:jungle_leaves[persistent=true]
fill 153 260 360 153 263 360 minecraft:dark_prismarine
setblock 154 260 323 minecraft:dark_prismarine
fill 154 260 324 154 261 324 minecraft:blue_terracotta
fill 154 260 342 154 260 343 minecraft:jungle_leaves[persistent=true]
fill 154 260 345 154 260 346 minecraft:jungle_leaves[persistent=true]
setblock 154 260 363 minecraft:dark_prismarine
fill 155 260 323 155 263 323 minecraft:blue_terracotta
setblock 155 260 363 minecraft:blue_terracotta
setblock 157 260 325 minecraft:dark_prismarine
setblock 158 260 324 minecraft:dark_prismarine
setblock 158 260 325 minecraft:blue_terracotta
setblock 159 260 323 minecraft:dark_prismarine
fill 159 260 324 159 262 324 minecraft:blue_terracotta
setblock 159 260 363 minecraft:dark_prismarine
fill 160 260 323 160 262 323 minecraft:blue_terracotta
setblock 160 260 363 minecraft:purple_concrete
setblock 163 260 324 minecraft:dark_prismarine
fill 163 260 354 163 261 354 minecraft:dark_prismarine
fill 163 260 356 163 261 356 minecraft:dark_prismarine
fill 163 260 358 163 261 358 minecraft:dark_prismarine
fill 163 260 360 163 261 360 minecraft:dark_prismarine
fill 163 260 362 163 261 362 minecraft:dark_prismarine
setblock 164 260 323 minecraft:dark_prismarine
setblock 164 260 324 minecraft:blue_terracotta
fill 164 260 353 164 261 353 minecraft:dark_prismarine
fill 164 260 355 164 261 355 minecraft:dark_prismarine
fill 164 260 357 164 261 357 minecraft:dark_prismarine
fill 164 260 359 164 261 359 minecraft:dark_prismarine
fill 164 260 361 164 261 361 minecraft:dark_prismarine
fill 164 260 363 164 261 363 minecraft:dark_prismarine
fill 165 260 323 165 261 323 minecraft:blue_terracotta
fill 165 260 354 165 261 354 minecraft:dark_prismarine
fill 165 260 356 165 261 356 minecraft:dark_prismarine
fill 165 260 358 165 261 358 minecraft:dark_prismarine
fill 165 260 360 165 261 360 minecraft:dark_prismarine
fill 165 260 362 165 261 362 minecraft:dark_prismarine
fill 166 260 353 166 261 353 minecraft:dark_prismarine
fill 166 260 355 166 261 355 minecraft:dark_prismarine
fill 166 260 357 166 261 357 minecraft:dark_prismarine
fill 166 260 359 166 261 359 minecraft:dark_prismarine
fill 166 260 361 166 261 361 minecraft:dark_prismarine
setblock 166 260 363 minecraft:dark_prismarine
fill 167 260 354 167 261 354 minecraft:dark_prismarine
fill 167 260 356 167 261 356 minecraft:dark_prismarine
fill 167 260 358 167 261 358 minecraft:dark_prismarine
fill 167 260 360 167 261 360 minecraft:dark_prismarine
fill 167 260 362 167 261 362 minecraft:dark_prismarine
setblock 168 260 324 minecraft:dark_prismarine
fill 168 260 353 168 261 353 minecraft:dark_prismarine
fill 168 260 355 168 261 355 minecraft:dark_prismarine
fill 168 260 357 168 261 357 minecraft:dark_prismarine
fill 168 260 359 168 261 359 minecraft:dark_prismarine
fill 168 260 361 168 261 361 minecraft:dark_prismarine
fill 168 260 363 168 261 363 minecraft:dark_prismarine
setblock 169 260 323 minecraft:dark_prismarine
fill 169 260 324 169 261 324 minecraft:blue_terracotta
fill 169 260 354 169 261 354 minecraft:dark_prismarine
fill 169 260 356 169 261 356 minecraft:dark_prismarine
fill 169 260 358 169 261 358 minecraft:magenta_terracotta
fill 169 260 360 169 261 360 minecraft:dark_prismarine
fill 169 260 362 169 261 362 minecraft:dark_prismarine
fill 170 260 323 170 263 323 minecraft:blue_terracotta
fill 170 260 353 170 261 353 minecraft:dark_prismarine
fill 170 260 355 170 261 355 minecraft:dark_prismarine
fill 170 260 357 170 261 357 minecraft:dark_prismarine
fill 170 260 359 170 261 359 minecraft:dark_prismarine
fill 170 260 361 170 261 361 minecraft:dark_prismarine
fill 170 260 363 170 261 363 minecraft:dark_prismarine
fill 171 260 344 172 261 345 minecraft:black_concrete
fill 171 260 354 171 261 354 minecraft:dark_prismarine
fill 171 260 356 171 261 356 minecraft:dark_prismarine
fill 171 260 358 171 261 358 minecraft:dark_prismarine
fill 171 260 360 171 261 360 minecraft:dark_prismarine
fill 171 260 362 171 261 362 minecraft:dark_prismarine
setblock 172 260 325 minecraft:dark_prismarine
fill 172 260 353 172 261 353 minecraft:dark_prismarine
fill 172 260 355 172 261 355 minecraft:dark_prismarine
fill 172 260 357 172 261 357 minecraft:dark_prismarine
fill 172 260 359 172 261 359 minecraft:dark_prismarine
fill 172 260 361 172 261 361 minecraft:dark_prismarine
fill 172 260 363 172 261 363 minecraft:blue_terracotta
setblock 173 260 324 minecraft:dark_prismarine
fill 173 260 325 173 263 325 minecraft:blue_terracotta
fill 173 260 354 173 261 354 minecraft:dark_prismarine
fill 173 260 356 173 261 356 minecraft:dark_prismarine
fill 173 260 358 173 261 358 minecraft:dark_prismarine
fill 173 260 360 173 261 360 minecraft:dark_prismarine
fill 173 260 362 173 261 362 minecraft:dark_prismarine
setblock 174 260 323 minecraft:dark_prismarine
fill 174 260 324 174 263 324 minecraft:blue_terracotta
setblock 174 260 363 minecraft:dark_prismarine
fill 175 260 323 175 263 323 minecraft:blue_terracotta
setblock 175 260 362 minecraft:dark_prismarine
fill 175 260 363 175 263 363 minecraft:blue_terracotta
setblock 176 260 326 minecraft:dark_prismarine
fill 176 260 362 176 261 362 minecraft:blue_terracotta
setblock 177 260 325 minecraft:dark_prismarine
fill 177 260 326 177 262 326 minecraft:blue_terracotta
setblock 178 260 324 minecraft:dark_prismarine
fill 178 260 325 178 263 325 minecraft:blue_terracotta
setblock 179 260 323 minecraft:dark_prismarine
fill 179 260 324 179 263 324 minecraft:blue_terracotta
setblock 179 260 328 minecraft:dark_prismarine
setblock 179 260 329 minecraft:blue_terracotta
setblock 179 260 363 minecraft:dark_prismarine
fill 180 260 323 180 263 323 minecraft:blue_terracotta
setblock 180 260 327 minecraft:dark_prismarine
fill 180 260 328 180 262 328 minecraft:blue_terracotta
setblock 180 260 362 minecraft:dark_prismarine
fill 180 260 363 180 263 363 minecraft:blue_terracotta
setblock 181 260 326 minecraft:dark_prismarine
fill 181 260 327 181 263 327 minecraft:blue_terracotta
setblock 181 260 331 minecraft:dark_prismarine
setblock 181 260 332 minecraft:blue_terracotta
setblock 181 260 346 minecraft:dark_prismarine
setblock 181 260 347 minecraft:blue_terracotta
setblock 181 260 351 minecraft:dark_prismarine
fill 181 260 352 181 263 352 minecraft:blue_terracotta
setblock 181 260 361 minecraft:dark_prismarine
setblock 181 260 362 minecraft:blue_terracotta
setblock 182 260 325 minecraft:dark_prismarine
fill 182 260 326 182 263 326 minecraft:blue_terracotta
setblock 182 260 330 minecraft:dark_prismarine
fill 182 260 331 182 263 331 minecraft:blue_terracotta
setblock 182 260 345 minecraft:dark_prismarine
fill 182 260 346 182 261 346 minecraft:blue_terracotta
setblock 182 260 350 minecraft:dark_prismarine
fill 182 260 351 182 263 351 minecraft:blue_terracotta
setblock 182 260 355 minecraft:dark_prismarine
fill 182 260 356 182 263 356 minecraft:blue_terracotta
setblock 182 260 360 minecraft:dark_prismarine
fill 182 260 361 182 262 361 minecraft:blue_terracotta
setblock 142 261 324 minecraft:dark_prismarine
setblock 142 261 325 minecraft:blue_terracotta
setblock 142 261 329 minecraft:dark_prismarine
setblock 142 261 330 minecraft:blue_terracotta
setblock 142 261 343 minecraft:purple_concrete
setblock 142 261 344 minecraft:dark_prismarine
fill 142 261 345 142 261 348 minecraft:blue_terracotta
setblock 142 261 349 minecraft:dark_prismarine
fill 142 261 350 142 264 350 minecraft:blue_terracotta
setblock 142 261 354 minecraft:dark_prismarine
fill 142 261 355 142 264 355 minecraft:blue_terracotta
setblock 142 261 359 minecraft:dark_prismarine
setblock 142 261 360 minecraft:blue_terracotta
fill 143 261 346 143 261 347 minecraft:blue_terracotta
setblock 143 261 348 minecraft:dark_prismarine
fill 143 261 349 143 263 349 minecraft:blue_terracotta
setblock 143 261 353 minecraft:dark_prismarine
fill 143 261 354 143 262 354 minecraft:blue_terracotta
setblock 144 261 325 minecraft:light[level=13]
setblock 144 261 333 minecraft:light[level=13]
setblock 144 261 341 minecraft:light[level=13]
setblock 144 261 349 minecraft:light[level=13]
setblock 144 261 357 minecraft:light[level=13]
fill 148 261 343 148 262 344 minecraft:magenta_terracotta
fill 149 261 344 149 266 344 minecraft:magenta_terracotta
fill 152 261 325 152 262 325 minecraft:dark_prismarine
setblock 152 261 333 minecraft:light[level=13]
setblock 152 261 341 minecraft:light[level=13]
setblock 152 261 349 minecraft:light[level=13]
setblock 152 261 357 minecraft:light[level=13]
fill 152 261 360 152 262 360 minecraft:dark_prismarine
setblock 153 261 323 minecraft:dark_prismarine
fill 153 261 326 153 263 326 minecraft:dark_prismarine
fill 153 261 359 153 263 359 minecraft:dark_prismarine
setblock 153 261 362 minecraft:dark_prismarine
setblock 153 261 363 minecraft:purple_concrete
fill 154 261 323 154 263 323 minecraft:blue_terracotta
fill 154 261 325 154 262 325 minecraft:dark_prismarine
fill 154 261 360 154 262 360 minecraft:dark_prismarine
fill 156 261 328 156 277 328 minecraft:magenta_terracotta
setblock 157 261 324 minecraft:dark_prismarine
setblock 158 261 323 minecraft:dark_prismarine
fill 158 261 324 158 262 324 minecraft:blue_terracotta
fill 159 261 323 159 263 323 minecraft:blue_terracotta
setblock 160 261 325 minecraft:light[level=13]
setblock 160 261 333 minecraft:light[level=13]
setblock 160 261 341 minecraft:light[level=13]
setblock 160 261 349 minecraft:light[level=13]
setblock 160 261 357 minecraft:light[level=13]
setblock 163 261 323 minecraft:dark_prismarine
setblock 164 261 323 minecraft:blue_terracotta
setblock 166 261 363 minecraft:purple_concrete
setblock 168 261 323 minecraft:dark_prismarine
setblock 168 261 325 minecraft:light[level=13]
setblock 168 261 333 minecraft:light[level=13]
setblock 168 261 341 minecraft:light[level=13]
setblock 168 261 349 minecraft:light[level=13]
fill 169 261 323 169 264 323 minecraft:blue_terracotta
fill 170 261 358 170 272 358 minecraft:magenta_terracotta
setblock 171 261 325 minecraft:dark_prismarine
setblock 172 261 324 minecraft:dark_prismarine
fill 172 261 325 172 264 325 minecraft:blue_terracotta
setblock 173 261 323 minecraft:dark_prismarine
fill 173 261 324 173 264 324 minecraft:blue_terracotta
setblock 173 261 363 minecraft:dark_prismarine
fill 174 261 323 174 264 323 minecraft:blue_terracotta
fill 174 261 363 174 264 363 minecraft:blue_terracotta
setblock 175 261 326 minecraft:dark_prismarine
setblock 176 261 325 minecraft:dark_prismarine
fill 176 261 326 176 262 326 minecraft:blue_terracotta
setblock 176 261 333 minecraft:light[level=13]
setblock 176 261 349 minecraft:light[level=13]
setblock 176 261 357 minecraft:light[level=13]
setblock 177 261 324 minecraft:dark_prismarine
fill 177 261 325 177 264 325 minecraft:blue_terracotta
setblock 178 261 323 minecraft:dark_prismarine
fill 178 261 324 178 264 324 minecraft:blue_terracotta
setblock 178 261 363 minecraft:dark_prismarine
fill 179 261 323 179 264 323 minecraft:blue_terracotta
setblock 179 261 327 minecraft:dark_prismarine
setblock 179 261 362 minecraft:dark_prismarine
fill 179 261 363 179 264 363 minecraft:blue_terracotta
setblock 180 261 326 minecraft:dark_prismarine
fill 180 261 327 180 262 327 minecraft:blue_terracotta
setblock 180 261 362 minecraft:blue_terracotta
setblock 181 261 325 minecraft:dark_prismarine
fill 181 261 326 181 263 326 minecraft:blue_terracotta
setblock 181 261 330 minecraft:dark_prismarine
setblock 181 261 331 minecraft:blue_terracotta
setblock 181 261 350 minecraft:dark_prismarine
fill 181 261 351 181 262 351 minecraft:blue_terracotta
setblock 182 261 324 minecraft:dark_prismarine
fill 182 261 325 182 263 325 minecraft:blue_terracotta
setblock 182 261 329 minecraft:dark_prismarine
fill 182 261 330 182 264 330 minecraft:blue_terracotta
setblock 182 261 343 minecraft:purple_concrete
setblock 182 261 345 minecraft:blue_terracotta
setblock 182 261 349 minecraft:dark_prismarine
fill 182 261 350 182 264 350 minecraft:blue_terracotta
setblock 182 261 354 minecraft:dark_prismarine
fill 182 261 355 182 264 355 minecraft:blue_terracotta
setblock 182 261 359 minecraft:dark_prismarine
setblock 182 261 360 minecraft:blue_terracotta
setblock 142 262 324 minecraft:purple_concrete
setblock 142 262 328 minecraft:dark_prismarine
fill 142 262 345 142 262 347 minecraft:blue_terracotta
setblock 142 262 348 minecraft:dark_prismarine
fill 142 262 349 142 265 349 minecraft:blue_terracotta
setblock 142 262 353 minecraft:dark_prismarine
fill 142 262 354 142 265 354 minecraft:blue_terracotta
setblock 142 262 358 minecraft:dark_prismarine
setblock 143 262 348 minecraft:blue_terracotta
setblock 143 262 352 minecraft:dark_prismarine
fill 143 262 353 143 265 353 minecraft:blue_terracotta
setblock 147 262 363 minecraft:purple_concrete
setblock 152 262 323 minecraft:purple_concrete
fill 152 262 326 152 263 327 minecraft:dark_prismarine
fill 152 262 358 152 263 359 minecraft:dark_prismarine
setblock 153 262 323 minecraft:blue_terracotta
setblock 153 262 324 minecraft:dark_prismarine
fill 153 262 327 154 263 327 minecraft:dark_prismarine
fill 153 262 358 154 263 358 minecraft:dark_prismarine
setblock 153 262 361 minecraft:dark_prismarine
setblock 153 262 362 minecraft:purple_concrete
fill 154 262 326 154 263 326 minecraft:dark_prismarine
fill 154 262 359 154 263 359 minecraft:dark_prismarine
setblock 156 262 324 minecraft:dark_prismarine
setblock 157 262 323 minecraft:dark_prismarine
setblock 157 262 324 minecraft:blue_terracotta
fill 158 262 323 158 263 323 minecraft:blue_terracotta
setblock 162 262 323 minecraft:dark_prismarine
setblock 163 262 354 minecraft:sea_lantern
setblock 163 262 356 minecraft:sea_lantern
setblock 163 262 358 minecraft:sea_lantern
setblock 163 262 360 minecraft:sea_lantern
setblock 163 262 362 minecraft:sea_lantern
setblock 164 262 353 minecraft:sea_lantern
setblock 164 262 355 minecraft:sea_lantern
setblock 164 262 357 minecraft:sea_lantern
setblock 164 262 359 minecraft:sea_lantern
setblock 164 262 361 minecraft:sea_lantern
setblock 164 262 363 minecraft:sea_lantern
setblock 165 262 354 minecraft:sea_lantern
setblock 165 262 356 minecraft:sea_lantern
setblock 165 262 358 minecraft:sea_lantern
setblock 165 262 360 minecraft:sea_lantern
setblock 165 262 362 minecraft:sea_lantern
setblock 166 262 353 minecraft:sea_lantern
setblock 166 262 355 minecraft:sea_lantern
setblock 166 262 357 minecraft:sea_lantern
setblock 166 262 359 minecraft:sea_lantern
setblock 166 262 361 minecraft:sea_lantern
setblock 166 262 363 minecraft:sea_lantern
setblock 167 262 354 minecraft:sea_lantern
setblock 167 262 356 minecraft:sea_lantern
setblock 167 262 358 minecraft:sea_lantern
setblock 167 262 360 minecraft:sea_lantern
setblock 167 262 362 minecraft:sea_lantern
fill 168 262 323 168 263 323 minecraft:blue_terracotta
setblock 168 262 353 minecraft:sea_lantern
setblock 168 262 355 minecraft:sea_lantern
setblock 168 262 357 minecraft:sea_lantern
setblock 168 262 359 minecraft:sea_lantern
setblock 168 262 361 minecraft:sea_lantern
setblock 168 262 363 minecraft:sea_lantern
setblock 169 262 354 minecraft:sea_lantern
setblock 169 262 356 minecraft:sea_lantern
setblock 169 262 358 minecraft:sea_lantern
setblock 169 262 360 minecraft:sea_lantern
setblock 169 262 362 minecraft:sea_lantern
setblock 170 262 353 minecraft:sea_lantern
setblock 170 262 355 minecraft:sea_lantern
setblock 170 262 357 minecraft:sea_lantern
setblock 170 262 359 minecraft:sea_lantern
setblock 170 262 361 minecraft:sea_lantern
setblock 170 262 363 minecraft:sea_lantern
setblock 171 262 324 minecraft:dark_prismarine
setblock 171 262 325 minecraft:blue_terracotta
setblock 171 262 354 minecraft:sea_lantern
setblock 171 262 356 minecraft:sea_lantern
setblock 171 262 358 minecraft:sea_lantern
setblock 171 262 360 minecraft:sea_lantern
setblock 171 262 362 minecraft:sea_lantern
setblock 172 262 323 minecraft:dark_prismarine
fill 172 262 324 172 265 324 minecraft:blue_terracotta
setblock 172 262 353 minecraft:sea_lantern
setblock 172 262 355 minecraft:sea_lantern
setblock 172 262 357 minecraft:sea_lantern
setblock 172 262 359 minecraft:sea_lantern
setblock 172 262 361 minecraft:sea_lantern
setblock 172 262 363 minecraft:sea_lantern
fill 173 262 323 173 265 323 minecraft:blue_terracotta
setblock 173 262 354 minecraft:sea_lantern
setblock 173 262 356 minecraft:sea_lantern
setblock 173 262 358 minecraft:sea_lantern
setblock 173 262 360 minecraft:sea_lantern
setblock 173 262 362 minecraft:sea_lantern
fill 173 262 363 173 265 363 minecraft:blue_terracotta
setblock 174 262 326 minecraft:dark_prismarine
setblock 175 262 325 minecraft:dark_prismarine
setblock 175 262 326 minecraft:blue_terracotta
setblock 176 262 324 minecraft:dark_prismarine
fill 176 262 325 176 264 325 minecraft:blue_terracotta
setblock 177 262 323 minecraft:dark_prismarine
fill 177 262 324 177 265 324 minecraft:blue_terracotta
setblock 177 262 363 minecraft:dark_prismarine
fill 178 262 323 178 265 323 minecraft:blue_terracotta
setblock 178 262 362 minecraft:dark_prismarine
fill 178 262 363 178 265 363 minecraft:blue_terracotta
setblock 180 262 325 minecraft:dark_prismarine
setblock 180 262 326 minecraft:blue_terracotta
setblock 181 262 324 minecraft:dark_prismarine
setblock 181 262 325 minecraft:blue_terracotta
setblock 181 262 329 minecraft:dark_prismarine
setblock 181 262 330 minecraft:blue_terracotta
setblock 181 262 350 minecraft:blue_terracotta
setblock 182 262 323 minecraft:dark_prismarine
fill 182 262 324 182 263 324 minecraft:blue_terracotta
setblock 182 262 328 minecraft:dark_prismarine
fill 182 262 329 182 264 329 minecraft:blue_terracotta
setblock 182 262 337 minecraft:purple_concrete
setblock 182 262 348 minecraft:dark_prismarine
fill 182 262 349 182 264 349 minecraft:blue_terracotta
setblock 182 262 353 minecraft:dark_prismarine
fill 182 262 354 182 265 354 minecraft:blue_terracotta
setblock 182 262 358 minecraft:dark_prismarine
setblock 182 262 363 minecraft:dark_prismarine
fill 183 262 324 183 308 326 minecraft:blue_concrete
setblock 183 262 327 minecraft:light_blue_wool
fill 183 262 328 183 296 329 minecraft:blue_concrete
setblock 142 263 330 minecraft:purple_concrete
setblock 142 263 346 minecraft:blue_terracotta
setblock 142 263 347 minecraft:dark_prismarine
fill 142 263 348 142 266 348 minecraft:blue_terracotta
setblock 142 263 352 minecraft:dark_prismarine
fill 142 263 353 142 266 353 minecraft:blue_terracotta
setblock 142 263 357 minecraft:dark_prismarine
setblock 143 263 351 minecraft:dark_prismarine
fill 143 263 352 143 266 352 minecraft:blue_terracotta
setblock 144 263 325 minecraft:light[level=12]
setblock 144 263 332 minecraft:light[level=12]
setblock 144 263 339 minecraft:light[level=12]
setblock 144 263 346 minecraft:light[level=12]
setblock 144 263 353 minecraft:light[level=12]
setblock 144 263 360 minecraft:light[level=12]
setblock 146 263 323 minecraft:purple_concrete
fill 148 263 343 148 277 343 minecraft:magenta_terracotta
setblock 148 263 344 minecraft:pink_terracotta
setblock 151 263 325 minecraft:light[level=12]
setblock 151 263 332 minecraft:light[level=12]
setblock 151 263 339 minecraft:light[level=12]
setblock 151 263 346 minecraft:light[level=12]
setblock 151 263 353 minecraft:light[level=12]
setblock 151 263 360 minecraft:light[level=12]
fill 152 263 328 154 264 328 minecraft:dark_prismarine
fill 152 263 357 154 264 357 minecraft:dark_prismarine
setblock 153 263 324 minecraft:purple_concrete
fill 153 263 329 153 265 329 minecraft:dark_prismarine
fill 153 263 356 153 265 356 minecraft:dark_prismarine
setblock 153 263 361 minecraft:purple_concrete
setblock 153 263 363 minecraft:purple_concrete
setblock 155 263 328 minecraft:pink_terracotta
setblock 155 263 358 minecraft:pink_terracotta
fill 155 263 359 155 275 359 minecraft:magenta_terracotta
setblock 156 263 323 minecraft:dark_prismarine
fill 156 263 358 156 277 358 minecraft:magenta_terracotta
setblock 157 263 323 minecraft:blue_terracotta
setblock 158 263 325 minecraft:light[level=12]
setblock 158 263 332 minecraft:light[level=12]
setblock 158 263 339 minecraft:light[level=12]
setblock 158 263 346 minecraft:light[level=12]
setblock 158 263 353 minecraft:light[level=12]
setblock 158 263 360 minecraft:light[level=12]
fill 163 263 354 163 264 354 minecraft:dark_prismarine
fill 163 263 356 163 264 356 minecraft:dark_prismarine
fill 163 263 358 163 264 358 minecraft:dark_prismarine
fill 163 263 360 163 264 360 minecraft:dark_prismarine
fill 163 263 362 163 264 362 minecraft:dark_prismarine
fill 164 263 353 164 264 353 minecraft:dark_prismarine
fill 164 263 355 164 264 355 minecraft:dark_prismarine
fill 164 263 357 164 264 357 minecraft:dark_prismarine
fill 164 263 359 164 264 359 minecraft:dark_prismarine
fill 164 263 361 164 264 361 minecraft:dark_prismarine
fill 164 263 363 164 264 363 minecraft:dark_prismarine
fill 165 263 323 165 264 323 minecraft:purple_concrete
setblock 165 263 325 minecraft:light[level=12]
setblock 165 263 332 minecraft:light[level=12]
setblock 165 263 339 minecraft:light[level=12]
setblock 165 263 346 minecraft:light[level=12]
fill 165 263 354 165 264 354 minecraft:dark_prismarine
fill 165 263 356 165 264 356 minecraft:dark_prismarine
fill 165 263 358 165 264 358 minecraft:dark_prismarine
fill 165 263 360 165 264 360 minecraft:dark_prismarine
fill 165 263 362 165 264 362 minecraft:dark_prismarine
fill 166 263 353 166 264 353 minecraft:dark_prismarine
fill 166 263 355 166 264 355 minecraft:dark_prismarine
fill 166 263 357 166 264 357 minecraft:dark_prismarine
fill 166 263 359 166 264 359 minecraft:dark_prismarine
fill 166 263 361 166 264 361 minecraft:dark_prismarine
fill 166 263 363 166 264 363 minecraft:dark_prismarine
fill 167 263 354 167 264 354 minecraft:dark_prismarine
fill 167 263 356 167 264 356 minecraft:dark_prismarine
fill 167 263 358 167 264 358 minecraft:dark_prismarine
fill 167 263 360 167 264 360 minecraft:dark_prismarine
fill 167 263 362 167 264 362 minecraft:dark_prismarine
fill 168 263 353 168 264 353 minecraft:dark_prismarine
fill 168 263 355 168 264 355 minecraft:dark_prismarine
fill 168 263 357 168 264 357 minecraft:dark_prismarine
fill 168 263 359 168 264 359 minecraft:dark_prismarine
fill 168 263 361 168 264 361 minecraft:dark_prismarine
fill 168 263 363 168 264 363 minecraft:dark_prismarine
setblock 169 263 328 minecraft:pink_terracotta
fill 169 263 354 169 264 354 minecraft:dark_prismarine
fill 169 263 356 169 264 356 minecraft:dark_prismarine
setblock 169 263 358 minecraft:pink_terracotta
fill 169 263 360 169 264 360 minecraft:dark_prismarine
fill 169 263 362 169 264 362 minecraft:dark_prismarine
setblock 169 263 364 minecraft:light_blue_wool
setblock 170 263 324 minecraft:dark_prismarine
fill 170 263 353 170 264 353 minecraft:dark_prismarine
fill 170 263 355 170 264 355 minecraft:dark_prismarine
fill 170 263 357 170 264 357 minecraft:dark_prismarine
fill 170 263 359 170 264 359 minecraft:dark_prismarine
fill 170 263 361 170 264 361 minecraft:dark_prismarine
fill 170 263 363 170 264 363 minecraft:dark_prismarine
setblock 171 263 323 minecraft:dark_prismarine
fill 171 263 324 171 266 324 minecraft:blue_terracotta
fill 171 263 354 171 264 354 minecraft:dark_prismarine
fill 171 263 356 171 264 356 minecraft:dark_prismarine
fill 171 263 358 171 264 358 minecraft:dark_prismarine
fill 171 263 360 171 264 360 minecraft:dark_prismarine
fill 171 263 362 171 264 362 minecraft:dark_prismarine
fill 172 263 323 172 266 323 minecraft:blue_terracotta
setblock 172 263 332 minecraft:light[level=12]
fill 172 263 339 174 264 340 minecraft:spruce_planks
setblock 172 263 346 minecraft:light[level=12]
fill 172 263 353 172 264 353 minecraft:dark_prismarine
fill 172 263 355 172 264 355 minecraft:dark_prismarine
fill 172 263 357 172 264 357 minecraft:dark_prismarine
fill 172 263 359 172 264 359 minecraft:dark_prismarine
fill 172 263 361 172 264 361 minecraft:dark_prismarine
fill 172 263 363 172 264 363 minecraft:dark_prismarine
fill 173 263 354 173 264 354 minecraft:dark_prismarine
fill 173 263 356 173 264 356 minecraft:dark_prismarine
fill 173 263 358 173 264 358 minecraft:dark_prismarine
fill 173 263 360 173 264 360 minecraft:dark_prismarine
fill 173 263 362 173 264 362 minecraft:dark_prismarine
setblock 174 263 325 minecraft:dark_prismarine
setblock 175 263 324 minecraft:dark_prismarine
fill 175 263 325 175 265 325 minecraft:blue_terracotta
setblock 176 263 323 minecraft:dark_prismarine
fill 176 263 324 176 266 324 minecraft:blue_terracotta
setblock 176 263 342 minecraft:pink_terracotta
fill 176 263 343 176 277 343 minecraft:magenta_terracotta
setblock 176 263 363 minecraft:dark_prismarine
fill 177 263 323 177 266 323 minecraft:blue_terracotta
fill 177 263 363 177 266 363 minecraft:blue_terracotta
setblock 179 263 325 minecraft:light[level=12]
setblock 179 263 332 minecraft:light[level=12]
setblock 179 263 339 minecraft:light[level=12]
setblock 179 263 346 minecraft:light[level=12]
setblock 179 263 353 minecraft:light[level=12]
setblock 179 263 360 minecraft:light[level=12]
setblock 180 263 324 minecraft:dark_prismarine
setblock 181 263 323 minecraft:dark_prismarine
setblock 181 263 328 minecraft:dark_prismarine
setblock 181 263 329 minecraft:blue_terracotta
setblock 181 263 363 minecraft:dark_prismarine
setblock 182 263 323 minecraft:blue_terracotta
setblock 182 263 327 minecraft:dark_prismarine
fill 182 263 328 182 264 328 minecraft:blue_terracotta
setblock 182 263 348 minecraft:blue_terracotta
setblock 182 263 352 minecraft:dark_prismarine
fill 182 263 353 182 266 353 minecraft:blue_terracotta
setblock 182 263 357 minecraft:dark_prismarine
fill 183 263 327 183 308 327 minecraft:blue_concrete
fill 183 263 345 183 308 346 minecraft:blue_concrete
setblock 183 263 347 minecraft:light_blue_wool
fill 183 263 348 183 277 352 minecraft:blue_concrete
setblock 142 264 336 minecraft:purple_concrete
fill 142 264 347 142 265 347 minecraft:blue_terracotta
setblock 142 264 351 minecraft:dark_prismarine
fill 142 264 352 142 267 352 minecraft:blue_terracotta
setblock 142 264 356 minecraft:dark_prismarine
fill 142 264 357 142 267 357 minecraft:blue_terracotta
setblock 142 264 361 minecraft:purple_concrete
setblock 143 264 350 minecraft:dark_prismarine
fill 143 264 351 143 267 351 minecraft:blue_terracotta
fill 148 264 344 148 273 344 minecraft:magenta_terracotta
fill 152 264 329 152 265 329 minecraft:dark_prismarine
fill 152 264 356 152 265 356 minecraft:dark_prismarine
setblock 153 264 326 minecraft:purple_concrete
setblock 153 264 327 minecraft:dark_prismarine
fill 153 264 330 153 266 330 minecraft:dark_prismarine
fill 153 264 336 155 265 336 minecraft:dark_prismarine
fill 153 264 355 153 266 355 minecraft:dark_prismarine
setblock 153 264 358 minecraft:dark_prismarine
setblock 153 264 359 minecraft:purple_concrete
fill 154 264 329 154 265 329 minecraft:dark_prismarine
fill 154 264 335 154 265 335 minecraft:dark_prismarine
fill 154 264 337 154 265 337 minecraft:dark_prismarine
fill 154 264 356 154 265 356 minecraft:dark_prismarine
setblock 155 264 323 minecraft:dark_prismarine
fill 155 264 328 155 277 328 minecraft:magenta_terracotta
fill 155 264 358 155 277 358 minecraft:magenta_terracotta
setblock 156 264 323 minecraft:blue_terracotta
setblock 159 264 323 minecraft:purple_concrete
setblock 159 264 363 minecraft:purple_concrete
fill 169 264 328 169 277 328 minecraft:magenta_terracotta
setblock 169 264 358 minecraft:magenta_terracotta
fill 169 264 364 169 308 364 minecraft:blue_concrete
setblock 170 264 323 minecraft:dark_prismarine
fill 170 264 324 170 267 324 minecraft:blue_terracotta
fill 171 264 323 171 267 323 minecraft:blue_terracotta
setblock 173 264 325 minecraft:dark_prismarine
setblock 174 264 324 minecraft:dark_prismarine
fill 174 264 325 174 266 325 minecraft:blue_terracotta
setblock 175 264 323 minecraft:dark_prismarine
fill 175 264 324 175 267 324 minecraft:blue_terracotta
setblock 175 264 363 minecraft:dark_prismarine
fill 176 264 323 176 267 323 minecraft:blue_terracotta
fill 176 264 342 176 276 342 minecraft:magenta_terracotta
fill 176 264 363 176 267 363 minecraft:blue_terracotta
setblock 179 264 324 minecraft:dark_prismarine
setblock 180 264 323 minecraft:dark_prismarine
setblock 180 264 363 minecraft:dark_prismarine
setblock 181 264 323 minecraft:blue_terracotta
setblock 182 264 325 minecraft:purple_concrete
setblock 182 264 326 minecraft:dark_prismarine
setblock 182 264 327 minecraft:blue_terracotta
fill 182 264 344 182 265 344 minecraft:purple_concrete
setblock 182 264 351 minecraft:dark_prismarine
fill 182 264 352 182 267 352 minecraft:blue_terracotta
setblock 182 264 356 minecraft:dark_prismarine
fill 182 264 357 182 267 357 minecraft:blue_terracotta
fill 183 264 347 183 308 347 minecraft:blue_concrete
setblock 142 265 323 minecraft:purple_concrete
setblock 142 265 342 minecraft:purple_concrete
setblock 142 265 350 minecraft:dark_prismarine
fill 142 265 351 142 268 351 minecraft:blue_terracotta
setblock 142 265 355 minecraft:dark_prismarine
fill 142 265 356 142 268 356 minecraft:blue_terracotta
setblock 143 265 354 minecraft:dark_prismarine
setblock 146 265 363 minecraft:purple_concrete
fill 152 265 330 152 265 331 minecraft:dark_prismarine
fill 152 265 354 152 265 355 minecraft:dark_prismarine
setblock 153 265 323 minecraft:purple_concrete
setblock 153 265 327 minecraft:purple_concrete
setblock 153 265 328 minecraft:dark_prismarine
fill 153 265 331 153 267 332 minecraft:dark_prismarine
fill 153 265 353 153 267 354 minecraft:dark_prismarine
setblock 153 265 357 minecraft:dark_prismarine
setblock 153 265 358 minecraft:purple_concrete
fill 154 265 330 154 265 331 minecraft:dark_prismarine
fill 154 265 354 154 265 355 minecraft:dark_prismarine
setblock 163 265 354 minecraft:sea_lantern
setblock 163 265 356 minecraft:sea_lantern
setblock 163 265 358 minecraft:sea_lantern
setblock 163 265 360 minecraft:sea_lantern
setblock 163 265 362 minecraft:sea_lantern
setblock 164 265 353 minecraft:sea_lantern
setblock 164 265 355 minecraft:sea_lantern
setblock 164 265 357 minecraft:sea_lantern
setblock 164 265 359 minecraft:sea_lantern
setblock 164 265 361 minecraft:sea_lantern
setblock 164 265 363 minecraft:sea_lantern
setblock 165 265 354 minecraft:sea_lantern
setblock 165 265 356 minecraft:sea_lantern
setblock 165 265 358 minecraft:sea_lantern
setblock 165 265 360 minecraft:sea_lantern
setblock 165 265 362 minecraft:sea_lantern
setblock 165 265 363 minecraft:purple_concrete
setblock 166 265 353 minecraft:sea_lantern
setblock 166 265 355 minecraft:sea_lantern
setblock 166 265 357 minecraft:sea_lantern
setblock 166 265 359 minecraft:sea_lantern
setblock 166 265 361 minecraft:sea_lantern
setblock 166 265 363 minecraft:sea_lantern
setblock 167 265 354 minecraft:sea_lantern
setblock 167 265 356 minecraft:sea_lantern
setblock 167 265 358 minecraft:sea_lantern
setblock 167 265 360 minecraft:sea_lantern
setblock 167 265 362 minecraft:sea_lantern
setblock 168 265 353 minecraft:sea_lantern
setblock 168 265 355 minecraft:sea_lantern
setblock 168 265 357 minecraft:sea_lantern
setblock 168 265 359 minecraft:sea_lantern
setblock 168 265 361 minecraft:sea_lantern
setblock 168 265 363 minecraft:sea_lantern
setblock 169 265 323 minecraft:dark_prismarine
setblock 169 265 354 minecraft:sea_lantern
setblock 169 265 356 minecraft:sea_lantern
setblock 169 265 358 minecraft:sea_lantern
setblock 169 265 360 minecraft:sea_lantern
setblock 169 265 362 minecraft:sea_lantern
fill 170 265 323 170 268 323 minecraft:blue_terracotta
setblock 170 265 353 minecraft:sea_lantern
setblock 170 265 355 minecraft:sea_lantern
setblock 170 265 357 minecraft:sea_lantern
setblock 170 265 359 minecraft:sea_lantern
setblock 170 265 361 minecraft:sea_lantern
setblock 170 265 363 minecraft:sea_lantern
setblock 171 265 354 minecraft:sea_lantern
setblock 171 265 356 minecraft:sea_lantern
setblock 171 265 358 minecraft:sea_lantern
setblock 171 265 360 minecraft:sea_lantern
setblock 171 265 362 minecraft:sea_lantern
setblock 171 265 363 minecraft:purple_concrete
setblock 172 265 353 minecraft:sea_lantern
setblock 172 265 355 minecraft:sea_lantern
setblock 172 265 357 minecraft:sea_lantern
setblock 172 265 359 minecraft:sea_lantern
setblock 172 265 361 minecraft:sea_lantern
setblock 172 265 363 minecraft:sea_lantern
setblock 173 265 324 minecraft:dark_prismarine
fill 173 265 325 173 266 325 minecraft:blue_terracotta
setblock 173 265 354 minecraft:sea_lantern
setblock 173 265 356 minecraft:sea_lantern
setblock 173 265 358 minecraft:sea_lantern
setblock 173 265 360 minecraft:sea_lantern
setblock 173 265 362 minecraft:sea_lantern
setblock 174 265 323 minecraft:dark_prismarine
fill 174 265 324 174 268 324 minecraft:blue_terracotta
setblock 174 265 363 minecraft:dark_prismarine
fill 175 265 323 175 268 323 minecraft:blue_terracotta
fill 175 265 363 175 268 363 minecraft:blue_terracotta
setblock 178 265 324 minecraft:dark_prismarine
setblock 179 265 323 minecraft:dark_prismarine
setblock 179 265 363 minecraft:dark_prismarine
setblock 180 265 323 minecraft:blue_terracotta
setblock 182 265 338 minecraft:purple_concrete
setblock 182 265 350 minecraft:dark_prismarine
fill 182 265 351 182 268 351 minecraft:blue_terracotta
setblock 182 265 355 minecraft:dark_prismarine
fill 182 265 356 182 268 356 minecraft:blue_terracotta
fill 182 265 358 182 266 358 minecraft:blue_terracotta
setblock 142 266 329 minecraft:purple_concrete
setblock 142 266 349 minecraft:dark_prismarine
fill 142 266 350 142 269 350 minecraft:blue_terracotta
setblock 142 266 354 minecraft:dark_prismarine
fill 142 266 355 142 269 355 minecraft:blue_terracotta
setblock 142 266 358 minecraft:blue_terracotta
setblock 143 266 353 minecraft:dark_prismarine
fill 143 266 354 143 269 354 minecraft:blue_terracotta
setblock 147 266 323 minecraft:purple_concrete
fill 148 266 338 148 267 338 minecraft:black_concrete
fill 152 266 331 152 266 333 minecraft:dark_prismarine
fill 152 266 352 152 266 354 minecraft:dark_prismarine
setblock 152 266 363 minecraft:purple_concrete
setblock 153 266 329 minecraft:purple_concrete
fill 153 266 333 153 268 334 minecraft:dark_prismarine
fill 153 266 351 153 268 352 minecraft:dark_prismarine
setblock 153 266 356 minecraft:purple_concrete
fill 154 266 331 154 266 333 minecraft:dark_prismarine
fill 154 266 352 154 266 354 minecraft:dark_prismarine
fill 163 266 354 163 267 354 minecraft:dark_prismarine
fill 163 266 356 163 267 356 minecraft:dark_prismarine
fill 163 266 358 163 267 358 minecraft:dark_prismarine
fill 163 266 360 163 267 360 minecraft:dark_prismarine
fill 163 266 362 163 267 362 minecraft:dark_prismarine
fill 164 266 353 164 267 353 minecraft:dark_prismarine
fill 164 266 355 164 267 355 minecraft:dark_prismarine
fill 164 266 357 164 267 357 minecraft:dark_prismarine
fill 164 266 359 164 267 359 minecraft:dark_prismarine
fill 164 266 361 164 267 361 minecraft:dark_prismarine
fill 164 266 363 166 267 363 minecraft:dark_prismarine
fill 165 266 354 165 267 354 minecraft:dark_prismarine
fill 165 266 356 165 267 356 minecraft:dark_prismarine
fill 165 266 358 165 267 358 minecraft:dark_prismarine
fill 165 266 360 165 267 360 minecraft:dark_prismarine
fill 165 266 362 165 267 362 minecraft:dark_prismarine
fill 166 266 353 166 267 353 minecraft:dark_prismarine
fill 166 266 355 166 267 355 minecraft:dark_prismarine
fill 166 266 357 166 267 357 minecraft:dark_prismarine
fill 166 266 359 166 267 359 minecraft:dark_prismarine
fill 166 266 361 166 267 361 minecraft:dark_prismarine
fill 167 266 354 167 267 354 minecraft:dark_prismarine
fill 167 266 356 167 267 356 minecraft:dark_prismarine
fill 167 266 358 167 267 358 minecraft:dark_prismarine
fill 167 266 360 167 267 360 minecraft:dark_prismarine
fill 167 266 362 167 267 362 minecraft:dark_prismarine
setblock 168 266 323 minecraft:dark_prismarine
fill 168 266 353 168 267 353 minecraft:dark_prismarine
fill 168 266 355 168 267 355 minecraft:dark_prismarine
fill 168 266 357 168 267 357 minecraft:dark_prismarine
fill 168 266 359 168 267 359 minecraft:dark_prismarine
fill 168 266 361 168 267 361 minecraft:dark_prismarine
fill 168 266 363 168 267 363 minecraft:dark_prismarine
fill 169 266 323 169 269 323 minecraft:blue_terracotta
fill 169 266 354 169 267 354 minecraft:dark_prismarine
fill 169 266 356 169 267 356 minecraft:dark_prismarine
fill 169 266 358 169 267 358 minecraft:magenta_terracotta
fill 169 266 360 169 267 360 minecraft:dark_prismarine
fill 169 266 362 169 267 362 minecraft:dark_prismarine
fill 170 266 353 170 267 353 minecraft:dark_prismarine
fill 170 266 355 170 267 355 minecraft:dark_prismarine
fill 170 266 357 170 267 357 minecraft:dark_prismarine
fill 170 266 359 170 267 359 minecraft:dark_prismarine
fill 170 266 361 170 267 361 minecraft:dark_prismarine
setblock 170 266 363 minecraft:dark_prismarine
fill 171 266 354 171 267 354 minecraft:dark_prismarine
fill 171 266 356 171 267 356 minecraft:dark_prismarine
fill 171 266 358 171 267 358 minecraft:dark_prismarine
fill 171 266 360 171 267 360 minecraft:dark_prismarine
fill 171 266 362 171 267 362 minecraft:dark_prismarine
fill 171 266 363 172 266 363 minecraft:blue_terracotta
setblock 172 266 324 minecraft:dark_prismarine
fill 172 266 353 172 267 353 minecraft:dark_prismarine
fill 172 266 355 172 267 355 minecraft:dark_prismarine
fill 172 266 357 172 267 357 minecraft:dark_prismarine
fill 172 266 359 172 267 359 minecraft:dark_prismarine
fill 172 266 361 172 267 361 minecraft:dark_prismarine
setblock 173 266 323 minecraft:dark_prismarine
fill 173 266 324 173 269 324 minecraft:blue_terracotta
fill 173 266 354 173 267 354 minecraft:dark_prismarine
fill 173 266 356 173 267 356 minecraft:dark_prismarine
fill 173 266 358 173 267 358 minecraft:dark_prismarine
fill 173 266 360 173 267 360 minecraft:dark_prismarine
fill 173 266 362 173 266 363 minecraft:dark_prismarine
fill 174 266 323 174 269 323 minecraft:blue_terracotta
fill 174 266 363 174 269 363 minecraft:blue_terracotta
setblock 177 266 324 minecraft:dark_prismarine
setblock 178 266 323 minecraft:dark_prismarine
setblock 178 266 363 minecraft:dark_prismarine
setblock 179 266 323 minecraft:blue_terracotta
fill 179 266 363 179 269 363 minecraft:blue_terracotta
fill 181 266 353 181 266 354 minecraft:blue_terracotta
setblock 181 266 355 minecraft:dark_prismarine
setblock 182 266 332 minecraft:purple_concrete
fill 182 266 350 182 269 350 minecraft:blue_terracotta
setblock 182 266 354 minecraft:dark_prismarine
fill 182 266 355 182 269 355 minecraft:blue_terracotta
setblock 182 266 359 minecraft:dark_prismarine
fill 183 266 333 183 308 335 minecraft:blue_concrete
setblock 183 266 336 minecraft:cyan_concrete
setblock 142 267 335 minecraft:purple_concrete
setblock 142 267 348 minecraft:dark_prismarine
fill 142 267 349 142 270 349 minecraft:blue_terracotta
setblock 142 267 353 minecraft:dark_prismarine
fill 142 267 354 142 270 354 minecraft:blue_terracotta
setblock 142 267 358 minecraft:dark_prismarine
setblock 142 267 360 minecraft:purple_concrete
setblock 143 267 352 minecraft:dark_prismarine
fill 143 267 353 143 270 353 minecraft:blue_terracotta
fill 143 267 355 143 268 355 minecraft:blue_terracotta
fill 146 267 358 146 272 358 minecraft:dark_prismarine
fill 152 267 332 152 267 335 minecraft:dark_prismarine
fill 152 267 350 152 267 353 minecraft:dark_prismarine
setblock 153 267 330 minecraft:purple_concrete
fill 153 267 335 153 269 336 minecraft:dark_prismarine
fill 153 267 349 153 269 350 minecraft:dark_prismarine
setblock 153 267 355 minecraft:purple_concrete
setblock 154 267 322 minecraft:light_blue_wool
fill 154 267 332 154 267 335 minecraft:dark_prismarine
fill 154 267 350 154 267 353 minecraft:dark_prismarine
setblock 158 267 363 minecraft:purple_concrete
setblock 166 267 323 minecraft:purple_concrete
fill 168 267 323 168 270 323 minecraft:blue_terracotta
fill 170 267 363 171 267 363 minecraft:blue_terracotta
setblock 171 267 324 minecraft:dark_prismarine
setblock 172 267 323 minecraft:dark_prismarine
fill 172 267 324 172 270 324 minecraft:blue_terracotta
setblock 172 267 363 minecraft:dark_prismarine
fill 173 267 323 173 270 323 minecraft:blue_terracotta
setblock 173 267 362 minecraft:dark_prismarine
fill 173 267 363 173 270 363 minecraft:blue_terracotta
fill 174 267 362 176 268 362 minecraft:blue_terracotta
setblock 176 267 324 minecraft:dark_prismarine
setblock 177 267 323 minecraft:dark_prismarine
setblock 177 267 363 minecraft:dark_prismarine
fill 178 267 323 178 269 323 minecraft:blue_terracotta
fill 178 267 363 178 270 363 minecraft:blue_terracotta
setblock 181 267 353 minecraft:blue_terracotta
setblock 181 267 354 minecraft:dark_prismarine
fill 181 267 355 181 268 357 minecraft:blue_terracotta
setblock 182 267 326 minecraft:purple_concrete
setblock 182 267 353 minecraft:dark_prismarine
fill 182 267 354 182 270 354 minecraft:blue_terracotta
setblock 182 267 358 minecraft:dark_prismarine
fill 182 267 359 182 269 360 minecraft:blue_terracotta
fill 183 267 336 183 308 336 minecraft:blue_concrete
fill 142 268 322 143 308 322 minecraft:blue_concrete
setblock 142 268 341 minecraft:purple_concrete
fill 142 268 348 142 271 348 minecraft:blue_terracotta
setblock 142 268 352 minecraft:dark_prismarine
fill 142 268 353 142 271 353 minecraft:blue_terracotta
setblock 142 268 357 minecraft:dark_prismarine
fill 142 268 358 142 270 359 minecraft:blue_terracotta
setblock 143 268 351 minecraft:dark_prismarine
fill 143 268 352 143 271 352 minecraft:blue_terracotta
setblock 143 268 356 minecraft:dark_prismarine
setblock 144 268 322 minecraft:cyan_concrete
fill 145 268 322 145 308 322 minecraft:blue_concrete
setblock 145 268 363 minecraft:purple_concrete
fill 149 268 343 149 275 343 minecraft:magenta_terracotta
fill 152 268 334 152 268 337 minecraft:dark_prismarine
fill 152 268 348 152 268 351 minecraft:dark_prismarine
setblock 153 268 332 minecraft:purple_concrete
fill 153 268 337 153 269 340 minecraft:dark_prismarine
fill 153 268 345 153 269 348 minecraft:dark_prismarine
setblock 153 268 353 minecraft:purple_concrete
fill 154 268 322 154 308 322 minecraft:blue_concrete
fill 154 268 334 154 268 337 minecraft:dark_prismarine
fill 154 268 348 154 268 351 minecraft:dark_prismarine
setblock 160 268 323 minecraft:purple_concrete
setblock 163 268 354 minecraft:sea_lantern
setblock 163 268 356 minecraft:sea_lantern
setblock 163 268 358 minecraft:sea_lantern
setblock 163 268 360 minecraft:sea_lantern
setblock 163 268 362 minecraft:sea_lantern
setblock 164 268 353 minecraft:sea_lantern
setblock 164 268 355 minecraft:sea_lantern
setblock 164 268 357 minecraft:sea_lantern
setblock 164 268 359 minecraft:sea_lantern
setblock 164 268 361 minecraft:sea_lantern
setblock 164 268 363 minecraft:sea_lantern
setblock 165 268 354 minecraft:sea_lantern
setblock 165 268 356 minecraft:sea_lantern
setblock 165 268 358 minecraft:sea_lantern
setblock 165 268 360 minecraft:sea_lantern
setblock 165 268 362 minecraft:sea_lantern
fill 165 268 363 165 270 363 minecraft:dark_prismarine
setblock 166 268 353 minecraft:sea_lantern
setblock 166 268 355 minecraft:sea_lantern
setblock 166 268 357 minecraft:sea_lantern
setblock 166 268 359 minecraft:sea_lantern
setblock 166 268 361 minecraft:sea_lantern
setblock 166 268 363 minecraft:sea_lantern
fill 167 268 323 167 271 323 minecraft:blue_terracotta
setblock 167 268 354 minecraft:sea_lantern
setblock 167 268 356 minecraft:sea_lantern
setblock 167 268 358 minecraft:sea_lantern
setblock 167 268 360 minecraft:sea_lantern
setblock 167 268 362 minecraft:sea_lantern
setblock 168 268 353 minecraft:sea_lantern
setblock 168 268 355 minecraft:sea_lantern
setblock 168 268 357 minecraft:sea_lantern
setblock 168 268 359 minecraft:sea_lantern
setblock 168 268 361 minecraft:sea_lantern
setblock 168 268 363 minecraft:sea_lantern
setblock 169 268 324 minecraft:blue_terracotta
setblock 169 268 354 minecraft:sea_lantern
setblock 169 268 356 minecraft:sea_lantern
setblock 169 268 358 minecraft:sea_lantern
setblock 169 268 360 minecraft:sea_lantern
setblock 169 268 362 minecraft:sea_lantern
fill 169 268 363 169 269 363 minecraft:blue_terracotta
setblock 170 268 324 minecraft:dark_prismarine
fill 170 268 328 170 277 328 minecraft:magenta_terracotta
setblock 170 268 353 minecraft:sea_lantern
setblock 170 268 355 minecraft:sea_lantern
setblock 170 268 357 minecraft:sea_lantern
setblock 170 268 359 minecraft:sea_lantern
setblock 170 268 361 minecraft:sea_lantern
setblock 170 268 363 minecraft:sea_lantern
setblock 171 268 323 minecraft:dark_prismarine
fill 171 268 324 171 271 324 minecraft:blue_terracotta
setblock 171 268 354 minecraft:sea_lantern
setblock 171 268 356 minecraft:sea_lantern
setblock 171 268 358 minecraft:sea_lantern
setblock 171 268 360 minecraft:sea_lantern
setblock 171 268 362 minecraft:sea_lantern
setblock 171 268 363 minecraft:dark_prismarine
fill 172 268 323 172 271 323 minecraft:blue_terracotta
fill 172 268 325 172 269 325 minecraft:blue_terracotta
setblock 172 268 353 minecraft:sea_lantern
setblock 172 268 355 minecraft:sea_lantern
setblock 172 268 357 minecraft:sea_lantern
setblock 172 268 359 minecraft:sea_lantern
setblock 172 268 361 minecraft:sea_lantern
setblock 172 268 363 minecraft:sea_lantern
setblock 173 268 354 minecraft:sea_lantern
setblock 173 268 356 minecraft:sea_lantern
setblock 173 268 358 minecraft:sea_lantern
setblock 173 268 360 minecraft:sea_lantern
setblock 173 268 362 minecraft:sea_lantern
setblock 175 268 324 minecraft:dark_prismarine
setblock 176 268 323 minecraft:dark_prismarine
setblock 176 268 324 minecraft:blue_terracotta
setblock 176 268 363 minecraft:dark_prismarine
fill 177 268 323 177 271 323 minecraft:blue_terracotta
setblock 177 268 362 minecraft:dark_prismarine
fill 177 268 363 177 271 363 minecraft:blue_terracotta
setblock 179 268 323 minecraft:purple_concrete
setblock 180 268 363 minecraft:blue_terracotta
setblock 181 268 352 minecraft:blue_terracotta
setblock 181 268 353 minecraft:dark_prismarine
fill 181 268 354 181 271 354 minecraft:blue_terracotta
setblock 181 268 358 minecraft:dark_prismarine
setblock 182 268 345 minecraft:purple_concrete
setblock 182 268 352 minecraft:dark_prismarine
fill 182 268 353 182 271 353 minecraft:blue_terracotta
setblock 182 268 357 minecraft:dark_prismarine
fill 182 268 358 182 271 358 minecraft:blue_terracotta
setblock 182 268 361 minecraft:blue_terracotta
setblock 142 269 328 minecraft:purple_concrete
fill 142 269 333 142 269 335 minecraft:blue_terracotta
setblock 142 269 336 minecraft:dark_prismarine
setblock 142 269 347 minecraft:purple_concrete
setblock 142 269 351 minecraft:dark_prismarine
fill 142 269 352 142 272 352 minecraft:blue_terracotta
setblock 142 269 356 minecraft:dark_prismarine
fill 142 269 357 143 271 357 minecraft:blue_terracotta
setblock 142 269 360 minecraft:blue_terracotta
setblock 143 269 350 minecraft:dark_prismarine
fill 143 269 351 143 272 351 minecraft:blue_terracotta
setblock 143 269 355 minecraft:dark_prismarine
fill 143 269 356 143 272 356 minecraft:blue_terracotta
fill 144 269 322 144 308 322 minecraft:blue_concrete
setblock 144 269 325 minecraft:light[level=13]
setblock 144 269 332 minecraft:light[level=12]
setblock 144 269 333 minecraft:light[level=13]
setblock 144 269 339 minecraft:light[level=12]
setblock 144 269 341 minecraft:light[level=13]
setblock 144 269 346 minecraft:light[level=12]
setblock 144 269 349 minecraft:light[level=13]
setblock 144 269 353 minecraft:light[level=12]
setblock 144 269 357 minecraft:light[level=13]
setblock 144 269 360 minecraft:light[level=12]
setblock 151 269 325 minecraft:light[level=12]
setblock 151 269 332 minecraft:light[level=12]
setblock 151 269 339 minecraft:light[level=12]
setblock 151 269 346 minecraft:light[level=12]
setblock 151 269 353 minecraft:light[level=12]
setblock 151 269 360 minecraft:light[level=12]
fill 151 269 363 152 271 363 minecraft:blue_terracotta
fill 152 269 323 154 269 323 minecraft:blue_terracotta
setblock 152 269 325 minecraft:light[level=13]
setblock 152 269 333 minecraft:light[level=13]
fill 152 269 337 152 269 348 minecraft:dark_prismarine
setblock 152 269 349 minecraft:light[level=13]
setblock 152 269 357 minecraft:light[level=13]
fill 153 269 333 153 269 334 minecraft:purple_concrete
fill 153 269 341 154 270 344 minecraft:dark_prismarine
fill 153 269 351 153 269 352 minecraft:purple_concrete
fill 154 269 337 154 269 340 minecraft:dark_prismarine
fill 154 269 345 154 269 348 minecraft:dark_prismarine
setblock 158 269 325 minecraft:light[level=12]
setblock 158 269 332 minecraft:light[level=12]
setblock 158 269 339 minecraft:light[level=12]
setblock 158 269 346 minecraft:light[level=12]
setblock 158 269 353 minecraft:light[level=12]
setblock 158 269 360 minecraft:light[level=12]
setblock 160 269 325 minecraft:light[level=13]
setblock 160 269 333 minecraft:light[level=13]
setblock 160 269 341 minecraft:light[level=13]
fill 160 269 347 160 269 350 minecraft:purple_concrete
setblock 160 269 357 minecraft:light[level=13]
fill 161 269 347 163 269 347 minecraft:purple_concrete
fill 161 269 350 163 269 350 minecraft:purple_concrete
fill 163 269 348 163 270 349 minecraft:purple_concrete
fill 163 269 354 163 270 354 minecraft:dark_prismarine
fill 163 269 356 163 270 356 minecraft:dark_prismarine
fill 163 269 358 163 270 358 minecraft:dark_prismarine
fill 163 269 360 163 270 360 minecraft:dark_prismarine
fill 163 269 362 163 270 362 minecraft:dark_prismarine
fill 164 269 353 164 270 353 minecraft:dark_prismarine
fill 164 269 355 164 270 355 minecraft:dark_prismarine
fill 164 269 357 164 270 357 minecraft:dark_prismarine
fill 164 269 359 164 270 359 minecraft:dark_prismarine
fill 164 269 361 164 270 361 minecraft:dark_prismarine
fill 164 269 363 164 270 363 minecraft:dark_prismarine
setblock 165 269 325 minecraft:light[level=12]
setblock 165 269 332 minecraft:light[level=12]
setblock 165 269 339 minecraft:light[level=12]
setblock 165 269 346 minecraft:light[level=12]
fill 165 269 354 165 270 354 minecraft:dark_prismarine
fill 165 269 356 165 270 356 minecraft:dark_prismarine
fill 165 269 358 165 270 358 minecraft:dark_prismarine
fill 165 269 360 165 270 360 minecraft:dark_prismarine
fill 165 269 362 165 270 362 minecraft:dark_prismarine
fill 166 269 323 166 272 323 minecraft:blue_terracotta
fill 166 269 353 166 270 353 minecraft:dark_prismarine
fill 166 269 355 166 270 355 minecraft:dark_prismarine
fill 166 269 357 166 270 357 minecraft:dark_prismarine
fill 166 269 359 166 270 359 minecraft:dark_prismarine
fill 166 269 361 166 270 361 minecraft:dark_prismarine
setblock 166 269 363 minecraft:dark_prismarine
fill 167 269 354 167 270 354 minecraft:dark_prismarine
schedule function dropper:buildpart/75_13 1t
