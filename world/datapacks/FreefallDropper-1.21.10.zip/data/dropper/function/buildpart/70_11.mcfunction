setblock 500 264 315 minecraft:cobbled_deepslate
fill 500 264 316 503 264 316 minecraft:deepslate_tiles
setblock 501 264 314 minecraft:cobbled_deepslate
fill 501 264 315 504 264 315 minecraft:deepslate_tiles
fill 502 264 314 505 264 314 minecraft:deepslate_tiles
setblock 504 264 276 minecraft:cobbled_deepslate
setblock 504 264 316 minecraft:cobbled_deepslate
fill 505 264 276 508 264 276 minecraft:deepslate_tiles
setblock 505 264 315 minecraft:cobbled_deepslate
fill 505 264 316 505 267 316 minecraft:deepslate_tiles
setblock 506 264 314 minecraft:cobbled_deepslate
fill 506 264 315 506 267 315 minecraft:deepslate_tiles
fill 507 264 314 507 267 314 minecraft:deepslate_tiles
setblock 507 264 317 minecraft:redstone_block
fill 508 264 317 508 308 317 minecraft:deepslate_tiles
setblock 509 264 276 minecraft:cobbled_deepslate
fill 509 264 309 509 264 310 minecraft:deepslate_tiles
setblock 509 264 311 minecraft:cobbled_deepslate
fill 509 264 312 509 267 312 minecraft:deepslate_tiles
setblock 509 264 316 minecraft:cobbled_deepslate
fill 510 264 276 510 267 276 minecraft:deepslate_tiles
setblock 510 264 289 minecraft:deepslate_tiles
setblock 510 264 290 minecraft:cobbled_deepslate
fill 510 264 291 510 267 291 minecraft:deepslate_tiles
setblock 510 264 295 minecraft:cobbled_deepslate
fill 510 264 296 511 264 298 minecraft:deepslate_tiles
setblock 510 264 304 minecraft:deepslate_tiles
setblock 510 264 305 minecraft:cobbled_deepslate
fill 510 264 306 510 267 306 minecraft:deepslate_tiles
setblock 510 264 310 minecraft:cobbled_deepslate
fill 510 264 311 510 267 311 minecraft:deepslate_tiles
setblock 510 264 315 minecraft:cobbled_deepslate
fill 510 264 316 510 267 316 minecraft:deepslate_tiles
setblock 511 264 279 minecraft:cobbled_deepslate
fill 511 264 285 511 266 285 minecraft:deepslate_tiles
setblock 511 264 289 minecraft:cobbled_deepslate
fill 511 264 290 511 267 290 minecraft:deepslate_tiles
setblock 511 264 293 minecraft:deepslate_tiles
setblock 511 264 294 minecraft:cobbled_deepslate
fill 511 264 295 511 267 295 minecraft:deepslate_tiles
setblock 511 264 299 minecraft:cobbled_deepslate
fill 511 264 300 511 267 300 minecraft:deepslate_tiles
setblock 511 264 304 minecraft:cobbled_deepslate
fill 511 264 305 511 267 305 minecraft:deepslate_tiles
setblock 511 264 309 minecraft:cobbled_deepslate
fill 511 264 310 511 267 310 minecraft:deepslate_tiles
setblock 511 264 314 minecraft:cobbled_deepslate
fill 511 264 315 511 267 315 minecraft:deepslate_tiles
fill 470 265 314 471 268 314 minecraft:deepslate_tiles
fill 471 265 276 471 265 277 minecraft:deepslate_tiles
setblock 471 265 278 minecraft:cobbled_deepslate
fill 471 265 279 471 265 282 minecraft:deepslate_tiles
setblock 471 265 283 minecraft:cobbled_deepslate
fill 471 265 284 471 268 284 minecraft:deepslate_tiles
setblock 471 265 288 minecraft:cobbled_deepslate
fill 471 265 289 471 265 292 minecraft:deepslate_tiles
setblock 471 265 293 minecraft:cobbled_deepslate
fill 471 265 294 471 268 294 minecraft:deepslate_tiles
setblock 471 265 298 minecraft:cobbled_deepslate
fill 471 265 299 471 268 299 minecraft:deepslate_tiles
setblock 471 265 303 minecraft:cobbled_deepslate
fill 471 265 304 471 268 304 minecraft:deepslate_tiles
setblock 471 265 308 minecraft:cobbled_deepslate
fill 471 265 309 471 268 309 minecraft:deepslate_tiles
setblock 471 265 313 minecraft:cobbled_deepslate
setblock 472 265 276 minecraft:deepslate_tiles
setblock 472 265 285 minecraft:deepslate_tiles
setblock 472 265 287 minecraft:cobbled_deepslate
fill 472 265 288 472 268 288 minecraft:deepslate_tiles
setblock 472 265 292 minecraft:cobbled_deepslate
fill 472 265 293 472 268 293 minecraft:deepslate_tiles
setblock 472 265 296 minecraft:deepslate_tiles
setblock 472 265 297 minecraft:cobbled_deepslate
fill 472 265 298 472 268 298 minecraft:deepslate_tiles
setblock 472 265 302 minecraft:cobbled_deepslate
fill 472 265 303 472 268 303 minecraft:deepslate_tiles
setblock 472 265 307 minecraft:cobbled_deepslate
fill 472 265 308 472 268 308 minecraft:deepslate_tiles
setblock 472 265 312 minecraft:cobbled_deepslate
fill 472 265 313 472 268 313 minecraft:deepslate_tiles
setblock 473 265 276 minecraft:cobbled_deepslate
fill 473 265 277 474 267 277 minecraft:deepslate_tiles
setblock 473 265 278 minecraft:light[level=12]
setblock 473 265 285 minecraft:light[level=12]
setblock 473 265 287 minecraft:deepslate_tiles
setblock 473 265 290 minecraft:deepslate_tiles
setblock 473 265 291 minecraft:cobbled_deepslate
fill 473 265 292 473 268 292 minecraft:deepslate_tiles
setblock 473 265 296 minecraft:cobbled_deepslate
fill 473 265 297 473 268 297 minecraft:deepslate_tiles
setblock 473 265 301 minecraft:cobbled_deepslate
fill 473 265 302 473 268 302 minecraft:deepslate_tiles
setblock 473 265 306 minecraft:cobbled_deepslate
setblock 473 265 307 minecraft:deepslate_tiles
setblock 473 265 311 minecraft:cobbled_deepslate
fill 473 265 312 473 267 312 minecraft:deepslate_tiles
setblock 473 265 316 minecraft:cobbled_deepslate
fill 474 265 276 474 268 276 minecraft:deepslate_tiles
setblock 474 265 290 minecraft:cobbled_deepslate
fill 474 265 291 474 267 291 minecraft:deepslate_tiles
setblock 474 265 295 minecraft:cobbled_deepslate
fill 474 265 296 474 268 296 minecraft:deepslate_tiles
setblock 474 265 299 minecraft:deepslate_tiles
fill 474 265 300 474 265 303 minecraft:black_concrete
setblock 474 265 315 minecraft:cobbled_deepslate
fill 474 265 316 474 268 316 minecraft:deepslate_tiles
setblock 475 265 294 minecraft:cobbled_deepslate
setblock 475 265 314 minecraft:cobbled_deepslate
fill 475 265 315 475 268 315 minecraft:deepslate_tiles
setblock 476 265 314 minecraft:deepslate_tiles
setblock 478 265 276 minecraft:cobbled_deepslate
setblock 478 265 316 minecraft:cobbled_deepslate
fill 479 265 276 480 267 276 minecraft:deepslate_tiles
fill 479 265 316 479 267 316 minecraft:deepslate_tiles
setblock 480 265 278 minecraft:light[level=12]
setblock 480 265 285 minecraft:light[level=12]
setblock 480 265 292 minecraft:light[level=12]
setblock 480 265 299 minecraft:light[level=12]
setblock 480 265 306 minecraft:light[level=12]
setblock 480 265 313 minecraft:light[level=12]
setblock 482 265 316 minecraft:deepslate_tiles
setblock 483 265 276 minecraft:cobbled_deepslate
setblock 483 265 316 minecraft:cobbled_deepslate
fill 484 265 276 487 265 276 minecraft:deepslate_tiles
fill 484 265 316 487 265 316 minecraft:deepslate_tiles
setblock 487 265 277 minecraft:cobbled_deepslate
setblock 487 265 278 minecraft:light[level=12]
setblock 487 265 285 minecraft:light[level=12]
setblock 487 265 292 minecraft:light[level=12]
setblock 487 265 299 minecraft:light[level=12]
setblock 487 265 306 minecraft:light[level=12]
setblock 487 265 313 minecraft:light[level=12]
fill 487 265 315 488 265 315 minecraft:deepslate_tiles
setblock 488 265 276 minecraft:cobbled_deepslate
fill 488 265 277 488 268 277 minecraft:deepslate_tiles
setblock 488 265 316 minecraft:cobbled_deepslate
fill 489 265 276 489 268 276 minecraft:deepslate_tiles
setblock 489 265 315 minecraft:cobbled_deepslate
fill 489 265 316 489 268 316 minecraft:deepslate_tiles
setblock 490 265 278 minecraft:deepslate_tiles
setblock 490 265 314 minecraft:cobbled_deepslate
fill 490 265 315 493 265 315 minecraft:deepslate_tiles
setblock 491 265 277 minecraft:deepslate_tiles
setblock 491 265 278 minecraft:cobbled_deepslate
fill 491 265 314 494 265 314 minecraft:deepslate_tiles
fill 491 265 317 491 308 317 minecraft:deepslate_tiles
fill 492 265 275 493 291 275 minecraft:deepslate_tiles
setblock 492 265 277 minecraft:cobbled_deepslate
fill 492 265 278 492 268 278 minecraft:deepslate_tiles
setblock 493 265 276 minecraft:cobbled_deepslate
fill 493 265 277 493 268 277 minecraft:deepslate_tiles
setblock 493 265 316 minecraft:cobbled_deepslate
fill 494 265 276 494 268 276 minecraft:deepslate_tiles
fill 494 265 278 495 265 278 minecraft:deepslate_tiles
setblock 494 265 285 minecraft:light[level=12]
setblock 494 265 292 minecraft:light[level=12]
setblock 494 265 299 minecraft:light[level=12]
setblock 494 265 306 minecraft:light[level=12]
setblock 494 265 313 minecraft:light[level=12]
setblock 494 265 315 minecraft:cobbled_deepslate
fill 494 265 316 494 268 316 minecraft:deepslate_tiles
setblock 495 265 314 minecraft:cobbled_deepslate
fill 495 265 315 495 268 315 minecraft:deepslate_tiles
setblock 496 265 278 minecraft:cobbled_deepslate
fill 496 265 307 496 268 307 minecraft:white_wool
fill 496 265 314 496 268 314 minecraft:deepslate_tiles
setblock 497 265 277 minecraft:cobbled_deepslate
fill 497 265 278 497 267 278 minecraft:deepslate_tiles
setblock 498 265 276 minecraft:cobbled_deepslate
fill 498 265 277 498 268 277 minecraft:deepslate_tiles
setblock 498 265 316 minecraft:cobbled_deepslate
fill 499 265 276 499 268 276 minecraft:deepslate_tiles
setblock 499 265 314 minecraft:deepslate_tiles
setblock 499 265 315 minecraft:cobbled_deepslate
fill 499 265 316 502 265 316 minecraft:deepslate_tiles
setblock 500 265 314 minecraft:cobbled_deepslate
fill 500 265 315 503 265 315 minecraft:deepslate_tiles
setblock 501 265 277 minecraft:deepslate_tiles
setblock 501 265 278 minecraft:light[level=12]
setblock 501 265 285 minecraft:light[level=12]
setblock 501 265 292 minecraft:light[level=12]
setblock 501 265 299 minecraft:light[level=12]
setblock 501 265 306 minecraft:light[level=12]
setblock 501 265 313 minecraft:light[level=12]
fill 501 265 314 504 265 314 minecraft:deepslate_tiles
setblock 503 265 276 minecraft:cobbled_deepslate
setblock 503 265 316 minecraft:cobbled_deepslate
fill 504 265 276 507 265 276 minecraft:deepslate_tiles
setblock 504 265 315 minecraft:cobbled_deepslate
fill 504 265 316 504 268 316 minecraft:deepslate_tiles
setblock 505 265 314 minecraft:cobbled_deepslate
fill 505 265 315 505 268 315 minecraft:deepslate_tiles
fill 506 265 314 506 268 314 minecraft:deepslate_tiles
fill 507 265 317 507 308 317 minecraft:deepslate_tiles
setblock 508 265 276 minecraft:cobbled_deepslate
setblock 508 265 278 minecraft:light[level=12]
setblock 508 265 285 minecraft:light[level=12]
setblock 508 265 292 minecraft:light[level=12]
setblock 508 265 299 minecraft:light[level=12]
setblock 508 265 306 minecraft:light[level=12]
fill 508 265 313 508 266 313 minecraft:deepslate_tiles
setblock 508 265 316 minecraft:cobbled_deepslate
fill 509 265 276 509 267 277 minecraft:deepslate_tiles
setblock 509 265 309 minecraft:deepslate_tiles
setblock 509 265 310 minecraft:cobbled_deepslate
fill 509 265 311 509 268 311 minecraft:deepslate_tiles
setblock 509 265 315 minecraft:cobbled_deepslate
fill 509 265 316 509 268 316 minecraft:deepslate_tiles
fill 510 265 277 510 266 277 minecraft:deepslate_tiles
setblock 510 265 289 minecraft:cobbled_deepslate
fill 510 265 290 510 267 290 minecraft:deepslate_tiles
fill 510 265 292 510 265 293 minecraft:deepslate_tiles
setblock 510 265 294 minecraft:cobbled_deepslate
fill 510 265 295 510 265 298 minecraft:deepslate_tiles
setblock 510 265 299 minecraft:cobbled_deepslate
fill 510 265 300 510 265 303 minecraft:deepslate_tiles
setblock 510 265 304 minecraft:cobbled_deepslate
fill 510 265 305 510 268 305 minecraft:deepslate_tiles
setblock 510 265 309 minecraft:cobbled_deepslate
fill 510 265 310 510 268 310 minecraft:deepslate_tiles
setblock 510 265 314 minecraft:cobbled_deepslate
fill 510 265 315 510 268 315 minecraft:deepslate_tiles
setblock 511 265 278 minecraft:cobbled_deepslate
fill 511 265 279 511 267 280 minecraft:deepslate_tiles
setblock 511 265 288 minecraft:cobbled_deepslate
fill 511 265 289 511 268 289 minecraft:deepslate_tiles
setblock 511 265 293 minecraft:cobbled_deepslate
fill 511 265 294 511 268 294 minecraft:deepslate_tiles
fill 511 265 296 511 265 297 minecraft:deepslate_tiles
setblock 511 265 298 minecraft:cobbled_deepslate
fill 511 265 299 511 268 299 minecraft:deepslate_tiles
setblock 511 265 303 minecraft:cobbled_deepslate
fill 511 265 304 511 268 304 minecraft:deepslate_tiles
setblock 511 265 308 minecraft:cobbled_deepslate
fill 511 265 309 511 268 309 minecraft:deepslate_tiles
setblock 511 265 313 minecraft:cobbled_deepslate
fill 511 265 314 511 268 314 minecraft:deepslate_tiles
setblock 512 265 281 minecraft:redstone_block
fill 512 265 288 512 308 288 minecraft:deepslate_tiles
setblock 470 266 279 minecraft:white_wool
setblock 471 266 276 minecraft:deepslate_tiles
setblock 471 266 277 minecraft:cobbled_deepslate
fill 471 266 278 471 266 281 minecraft:deepslate_tiles
setblock 471 266 282 minecraft:cobbled_deepslate
fill 471 266 283 471 269 283 minecraft:deepslate_tiles
setblock 471 266 287 minecraft:cobbled_deepslate
fill 471 266 288 471 266 291 minecraft:deepslate_tiles
setblock 471 266 292 minecraft:cobbled_deepslate
fill 471 266 293 471 269 293 minecraft:deepslate_tiles
setblock 471 266 297 minecraft:cobbled_deepslate
fill 471 266 298 471 269 298 minecraft:deepslate_tiles
setblock 471 266 302 minecraft:cobbled_deepslate
fill 471 266 303 471 269 303 minecraft:deepslate_tiles
setblock 471 266 307 minecraft:cobbled_deepslate
fill 471 266 308 471 269 308 minecraft:deepslate_tiles
setblock 471 266 312 minecraft:cobbled_deepslate
fill 471 266 313 471 269 313 minecraft:deepslate_tiles
setblock 472 266 276 minecraft:cobbled_deepslate
fill 472 266 277 472 269 277 minecraft:deepslate_tiles
setblock 472 266 286 minecraft:cobbled_deepslate
fill 472 266 287 472 268 287 minecraft:deepslate_tiles
setblock 472 266 291 minecraft:cobbled_deepslate
fill 472 266 292 472 269 292 minecraft:deepslate_tiles
setblock 472 266 296 minecraft:cobbled_deepslate
fill 472 266 297 472 269 297 minecraft:deepslate_tiles
setblock 472 266 300 minecraft:deepslate_tiles
setblock 472 266 301 minecraft:cobbled_deepslate
fill 472 266 302 472 269 302 minecraft:deepslate_tiles
setblock 472 266 306 minecraft:cobbled_deepslate
fill 472 266 307 472 268 307 minecraft:deepslate_tiles
setblock 472 266 311 minecraft:cobbled_deepslate
fill 472 266 312 472 269 312 minecraft:deepslate_tiles
setblock 472 266 316 minecraft:cobbled_deepslate
fill 473 266 276 473 269 276 minecraft:deepslate_tiles
setblock 473 266 289 minecraft:deepslate_tiles
setblock 473 266 290 minecraft:cobbled_deepslate
fill 473 266 291 473 269 291 minecraft:deepslate_tiles
setblock 473 266 295 minecraft:cobbled_deepslate
fill 473 266 296 473 269 296 minecraft:deepslate_tiles
setblock 473 266 300 minecraft:cobbled_deepslate
fill 473 266 301 473 269 301 minecraft:deepslate_tiles
setblock 473 266 310 minecraft:cobbled_deepslate
fill 473 266 311 473 267 311 minecraft:deepslate_tiles
setblock 473 266 315 minecraft:cobbled_deepslate
fill 473 266 316 473 269 316 minecraft:deepslate_tiles
setblock 474 266 290 minecraft:deepslate_tiles
setblock 474 266 294 minecraft:cobbled_deepslate
fill 474 266 295 474 269 295 minecraft:deepslate_tiles
setblock 474 266 299 minecraft:cobbled_deepslate
setblock 474 266 314 minecraft:cobbled_deepslate
fill 474 266 315 474 269 315 minecraft:deepslate_tiles
setblock 475 266 277 minecraft:deepslate_tiles
fill 475 266 301 475 271 301 minecraft:bone_block
setblock 475 266 314 minecraft:deepslate_tiles
setblock 477 266 276 minecraft:cobbled_deepslate
setblock 477 266 316 minecraft:cobbled_deepslate
fill 478 266 276 478 269 276 minecraft:deepslate_tiles
setblock 478 266 315 minecraft:cobbled_deepslate
fill 478 266 316 478 268 316 minecraft:deepslate_tiles
setblock 481 266 276 minecraft:deepslate_tiles
setblock 482 266 276 minecraft:cobbled_deepslate
setblock 482 266 316 minecraft:cobbled_deepslate
fill 483 266 276 486 266 276 minecraft:deepslate_tiles
fill 483 266 316 486 266 316 minecraft:deepslate_tiles
setblock 486 266 277 minecraft:cobbled_deepslate
setblock 486 266 317 minecraft:white_wool
setblock 487 266 276 minecraft:cobbled_deepslate
fill 487 266 277 487 269 277 minecraft:deepslate_tiles
setblock 487 266 315 minecraft:deepslate_tiles
setblock 487 266 316 minecraft:cobbled_deepslate
fill 488 266 276 488 269 276 minecraft:deepslate_tiles
setblock 488 266 315 minecraft:cobbled_deepslate
fill 488 266 316 488 269 316 minecraft:deepslate_tiles
setblock 489 266 278 minecraft:deepslate_tiles
fill 489 266 315 492 266 315 minecraft:deepslate_tiles
setblock 490 266 278 minecraft:cobbled_deepslate
fill 490 266 314 493 266 314 minecraft:deepslate_tiles
setblock 491 266 277 minecraft:cobbled_deepslate
fill 491 266 278 491 269 278 minecraft:deepslate_tiles
setblock 492 266 276 minecraft:cobbled_deepslate
fill 492 266 277 492 269 277 minecraft:deepslate_tiles
setblock 492 266 316 minecraft:cobbled_deepslate
fill 493 266 276 493 269 276 minecraft:deepslate_tiles
setblock 493 266 315 minecraft:cobbled_deepslate
fill 493 266 316 493 269 316 minecraft:deepslate_tiles
setblock 494 266 278 minecraft:deepslate_tiles
setblock 494 266 314 minecraft:cobbled_deepslate
fill 494 266 315 494 269 315 minecraft:deepslate_tiles
setblock 495 266 278 minecraft:cobbled_deepslate
fill 495 266 314 495 268 314 minecraft:deepslate_tiles
setblock 496 266 277 minecraft:cobbled_deepslate
fill 496 266 278 496 268 278 minecraft:deepslate_tiles
setblock 497 266 276 minecraft:cobbled_deepslate
fill 497 266 277 497 269 277 minecraft:deepslate_tiles
setblock 497 266 316 minecraft:cobbled_deepslate
fill 498 266 276 498 269 276 minecraft:deepslate_tiles
setblock 498 266 315 minecraft:cobbled_deepslate
fill 498 266 316 501 266 316 minecraft:deepslate_tiles
setblock 499 266 314 minecraft:cobbled_deepslate
fill 499 266 315 502 266 315 minecraft:deepslate_tiles
fill 500 266 314 503 266 314 minecraft:deepslate_tiles
setblock 501 266 277 minecraft:cobbled_deepslate
setblock 502 266 276 minecraft:cobbled_deepslate
setblock 502 266 316 minecraft:cobbled_deepslate
fill 503 266 276 506 266 276 minecraft:deepslate_tiles
setblock 503 266 315 minecraft:cobbled_deepslate
fill 503 266 316 503 269 316 minecraft:deepslate_tiles
setblock 504 266 314 minecraft:cobbled_deepslate
fill 504 266 315 504 269 315 minecraft:deepslate_tiles
fill 505 266 314 505 268 314 minecraft:deepslate_tiles
setblock 507 266 276 minecraft:cobbled_deepslate
fill 507 266 287 507 271 287 minecraft:black_concrete
setblock 507 266 316 minecraft:cobbled_deepslate
fill 508 266 276 508 268 277 minecraft:deepslate_tiles
setblock 508 266 315 minecraft:cobbled_deepslate
fill 508 266 316 508 269 316 minecraft:deepslate_tiles
setblock 509 266 309 minecraft:cobbled_deepslate
fill 509 266 310 509 268 310 minecraft:deepslate_tiles
setblock 509 266 314 minecraft:cobbled_deepslate
fill 509 266 315 509 269 315 minecraft:deepslate_tiles
setblock 510 266 278 minecraft:cobbled_deepslate
setblock 510 266 289 minecraft:deepslate_tiles
setblock 510 266 292 minecraft:deepslate_tiles
setblock 510 266 293 minecraft:cobbled_deepslate
fill 510 266 294 510 266 297 minecraft:deepslate_tiles
setblock 510 266 298 minecraft:cobbled_deepslate
fill 510 266 299 510 266 302 minecraft:deepslate_tiles
setblock 510 266 303 minecraft:cobbled_deepslate
fill 510 266 304 510 269 304 minecraft:deepslate_tiles
setblock 510 266 308 minecraft:cobbled_deepslate
fill 510 266 309 510 269 309 minecraft:deepslate_tiles
setblock 510 266 313 minecraft:cobbled_deepslate
fill 510 266 314 510 269 314 minecraft:deepslate_tiles
setblock 511 266 277 minecraft:cobbled_deepslate
fill 511 266 278 511 269 278 minecraft:deepslate_tiles
fill 511 266 281 512 266 281 minecraft:deepslate_tiles
setblock 511 266 287 minecraft:cobbled_deepslate
fill 511 266 288 511 269 288 minecraft:deepslate_tiles
setblock 511 266 292 minecraft:cobbled_deepslate
fill 511 266 293 511 269 293 minecraft:deepslate_tiles
setblock 511 266 296 minecraft:deepslate_tiles
setblock 511 266 297 minecraft:cobbled_deepslate
fill 511 266 298 511 269 298 minecraft:deepslate_tiles
setblock 511 266 302 minecraft:cobbled_deepslate
fill 511 266 303 511 269 303 minecraft:deepslate_tiles
setblock 511 266 307 minecraft:cobbled_deepslate
fill 511 266 308 511 269 308 minecraft:deepslate_tiles
setblock 511 266 312 minecraft:cobbled_deepslate
fill 511 266 313 511 269 313 minecraft:deepslate_tiles
setblock 512 266 294 minecraft:white_wool
setblock 512 266 300 minecraft:white_wool
fill 470 267 279 471 268 279 minecraft:deepslate_tiles
setblock 470 267 303 minecraft:white_wool
setblock 471 267 276 minecraft:cobbled_deepslate
fill 471 267 277 471 269 278 minecraft:deepslate_tiles
setblock 471 267 280 minecraft:deepslate_tiles
setblock 471 267 281 minecraft:cobbled_deepslate
fill 471 267 282 471 270 282 minecraft:deepslate_tiles
setblock 471 267 286 minecraft:cobbled_deepslate
fill 471 267 287 471 267 290 minecraft:deepslate_tiles
setblock 471 267 291 minecraft:cobbled_deepslate
fill 471 267 292 471 270 292 minecraft:deepslate_tiles
setblock 471 267 296 minecraft:cobbled_deepslate
fill 471 267 297 471 270 297 minecraft:deepslate_tiles
setblock 471 267 301 minecraft:cobbled_deepslate
fill 471 267 302 471 270 302 minecraft:deepslate_tiles
setblock 471 267 306 minecraft:cobbled_deepslate
fill 471 267 307 471 270 307 minecraft:deepslate_tiles
setblock 471 267 311 minecraft:cobbled_deepslate
fill 471 267 312 471 270 312 minecraft:deepslate_tiles
setblock 471 267 316 minecraft:cobbled_deepslate
fill 472 267 276 472 270 276 minecraft:deepslate_tiles
fill 472 267 278 472 268 278 minecraft:deepslate_tiles
setblock 472 267 286 minecraft:deepslate_tiles
setblock 472 267 290 minecraft:cobbled_deepslate
fill 472 267 291 472 270 291 minecraft:deepslate_tiles
setblock 472 267 295 minecraft:cobbled_deepslate
fill 472 267 296 472 270 296 minecraft:deepslate_tiles
setblock 472 267 300 minecraft:cobbled_deepslate
fill 472 267 301 472 270 301 minecraft:deepslate_tiles
setblock 472 267 305 minecraft:cobbled_deepslate
fill 472 267 306 472 268 306 minecraft:deepslate_tiles
setblock 472 267 310 minecraft:cobbled_deepslate
fill 472 267 311 472 269 311 minecraft:deepslate_tiles
setblock 472 267 315 minecraft:cobbled_deepslate
fill 472 267 316 472 270 316 minecraft:deepslate_tiles
setblock 473 267 289 minecraft:cobbled_deepslate
fill 473 267 290 473 268 290 minecraft:deepslate_tiles
setblock 473 267 294 minecraft:cobbled_deepslate
fill 473 267 295 473 270 295 minecraft:deepslate_tiles
setblock 473 267 298 minecraft:deepslate_tiles
setblock 473 267 299 minecraft:cobbled_deepslate
fill 473 267 300 473 270 300 minecraft:deepslate_tiles
setblock 473 267 314 minecraft:cobbled_deepslate
fill 473 267 315 473 269 315 minecraft:deepslate_tiles
setblock 474 267 293 minecraft:cobbled_deepslate
fill 474 267 294 474 269 294 minecraft:deepslate_tiles
setblock 474 267 298 minecraft:cobbled_deepslate
setblock 474 267 299 minecraft:deepslate_tiles
setblock 474 267 300 minecraft:black_concrete
fill 474 267 301 474 270 303 minecraft:bone_block
setblock 474 267 314 minecraft:deepslate_tiles
setblock 475 267 277 minecraft:cobbled_deepslate
fill 475 267 299 476 270 300 minecraft:bone_block
fill 475 267 302 476 270 303 minecraft:bone_block
setblock 476 267 276 minecraft:cobbled_deepslate
fill 476 267 301 477 270 301 minecraft:bone_block
setblock 476 267 316 minecraft:cobbled_deepslate
fill 477 267 276 477 270 276 minecraft:deepslate_tiles
fill 477 267 300 477 270 300 minecraft:bone_block
fill 477 267 302 477 270 302 minecraft:bone_block
fill 477 267 316 477 269 316 minecraft:deepslate_tiles
setblock 480 267 316 minecraft:deepslate_tiles
setblock 481 267 276 minecraft:cobbled_deepslate
fill 482 267 276 485 267 276 minecraft:deepslate_tiles
fill 483 267 316 485 267 316 minecraft:deepslate_tiles
setblock 485 267 277 minecraft:cobbled_deepslate
setblock 486 267 276 minecraft:cobbled_deepslate
fill 486 267 277 486 270 277 minecraft:deepslate_tiles
setblock 486 267 316 minecraft:cobbled_deepslate
fill 486 267 317 486 277 317 minecraft:deepslate_tiles
fill 487 267 276 487 270 276 minecraft:deepslate_tiles
setblock 487 267 315 minecraft:cobbled_deepslate
fill 487 267 316 487 270 316 minecraft:deepslate_tiles
setblock 488 267 278 minecraft:deepslate_tiles
fill 488 267 315 491 267 315 minecraft:deepslate_tiles
setblock 489 267 278 minecraft:cobbled_deepslate
setblock 490 267 277 minecraft:cobbled_deepslate
fill 490 267 278 490 270 278 minecraft:deepslate_tiles
fill 490 267 314 492 267 314 minecraft:deepslate_tiles
setblock 491 267 276 minecraft:cobbled_deepslate
fill 491 267 277 491 270 277 minecraft:deepslate_tiles
setblock 491 267 316 minecraft:cobbled_deepslate
fill 492 267 276 492 270 276 minecraft:deepslate_tiles
setblock 492 267 315 minecraft:cobbled_deepslate
fill 492 267 316 492 270 316 minecraft:deepslate_tiles
setblock 493 267 314 minecraft:cobbled_deepslate
fill 493 267 315 493 270 315 minecraft:deepslate_tiles
setblock 494 267 278 minecraft:cobbled_deepslate
fill 494 267 314 494 269 314 minecraft:deepslate_tiles
setblock 495 267 277 minecraft:cobbled_deepslate
fill 495 267 278 495 270 278 minecraft:deepslate_tiles
setblock 496 267 276 minecraft:cobbled_deepslate
fill 496 267 277 496 270 277 minecraft:deepslate_tiles
setblock 496 267 316 minecraft:cobbled_deepslate
fill 497 267 276 497 270 276 minecraft:deepslate_tiles
setblock 497 267 315 minecraft:cobbled_deepslate
fill 497 267 316 500 267 316 minecraft:deepslate_tiles
setblock 498 267 314 minecraft:cobbled_deepslate
fill 498 267 315 501 267 315 minecraft:deepslate_tiles
setblock 499 267 314 minecraft:deepslate_tiles
setblock 500 267 277 minecraft:cobbled_deepslate
setblock 501 267 276 minecraft:cobbled_deepslate
setblock 501 267 316 minecraft:cobbled_deepslate
fill 502 267 276 505 267 276 minecraft:deepslate_tiles
setblock 502 267 315 minecraft:cobbled_deepslate
fill 502 267 316 502 270 316 minecraft:deepslate_tiles
fill 503 267 315 503 270 315 minecraft:deepslate_tiles
setblock 504 267 314 minecraft:deepslate_tiles
setblock 506 267 276 minecraft:cobbled_deepslate
setblock 506 267 316 minecraft:cobbled_deepslate
fill 507 267 276 507 269 277 minecraft:deepslate_tiles
setblock 507 267 315 minecraft:cobbled_deepslate
fill 507 267 316 507 270 316 minecraft:deepslate_tiles
setblock 508 267 314 minecraft:cobbled_deepslate
fill 508 267 315 508 270 315 minecraft:deepslate_tiles
fill 509 267 294 509 267 297 minecraft:deepslate_tiles
setblock 509 267 309 minecraft:deepslate_tiles
setblock 509 267 313 minecraft:cobbled_deepslate
fill 509 267 314 509 270 314 minecraft:deepslate_tiles
setblock 510 267 277 minecraft:cobbled_deepslate
fill 510 267 278 510 270 278 minecraft:deepslate_tiles
setblock 510 267 292 minecraft:cobbled_deepslate
fill 510 267 293 510 267 296 minecraft:deepslate_tiles
setblock 510 267 297 minecraft:cobbled_deepslate
fill 510 267 298 510 267 301 minecraft:deepslate_tiles
setblock 510 267 302 minecraft:cobbled_deepslate
fill 510 267 303 510 270 303 minecraft:deepslate_tiles
setblock 510 267 307 minecraft:cobbled_deepslate
fill 510 267 308 510 270 308 minecraft:deepslate_tiles
setblock 510 267 312 minecraft:cobbled_deepslate
fill 510 267 313 510 270 313 minecraft:deepslate_tiles
setblock 511 267 276 minecraft:cobbled_deepslate
fill 511 267 277 511 270 277 minecraft:deepslate_tiles
setblock 511 267 281 minecraft:cobbled_deepslate
setblock 511 267 286 minecraft:cobbled_deepslate
fill 511 267 287 511 268 287 minecraft:deepslate_tiles
setblock 511 267 291 minecraft:cobbled_deepslate
fill 511 267 292 511 270 292 minecraft:deepslate_tiles
setblock 511 267 296 minecraft:cobbled_deepslate
fill 511 267 297 511 270 297 minecraft:deepslate_tiles
setblock 511 267 301 minecraft:cobbled_deepslate
fill 511 267 302 511 270 302 minecraft:deepslate_tiles
setblock 511 267 306 minecraft:cobbled_deepslate
fill 511 267 307 511 270 307 minecraft:deepslate_tiles
setblock 511 267 311 minecraft:cobbled_deepslate
fill 511 267 312 511 270 312 minecraft:deepslate_tiles
setblock 511 267 316 minecraft:cobbled_deepslate
fill 512 267 281 512 308 281 minecraft:deepslate_tiles
fill 512 267 294 512 308 294 minecraft:deepslate_tiles
fill 512 267 300 512 308 300 minecraft:deepslate_tiles
fill 470 268 303 470 284 303 minecraft:deepslate_tiles
fill 470 268 315 470 308 315 minecraft:deepslate_tiles
fill 471 268 276 471 271 276 minecraft:deepslate_tiles
setblock 471 268 280 minecraft:cobbled_deepslate
fill 471 268 281 471 271 281 minecraft:deepslate_tiles
setblock 471 268 285 minecraft:cobbled_deepslate
fill 471 268 286 471 268 289 minecraft:deepslate_tiles
setblock 471 268 290 minecraft:cobbled_deepslate
fill 471 268 291 471 271 291 minecraft:deepslate_tiles
setblock 471 268 295 minecraft:cobbled_deepslate
fill 471 268 296 471 271 296 minecraft:deepslate_tiles
setblock 471 268 300 minecraft:cobbled_deepslate
fill 471 268 301 471 271 301 minecraft:deepslate_tiles
setblock 471 268 305 minecraft:cobbled_deepslate
fill 471 268 306 471 271 306 minecraft:deepslate_tiles
setblock 471 268 310 minecraft:cobbled_deepslate
fill 471 268 311 471 271 311 minecraft:deepslate_tiles
setblock 471 268 315 minecraft:cobbled_deepslate
fill 471 268 316 471 271 316 minecraft:deepslate_tiles
setblock 472 268 289 minecraft:cobbled_deepslate
fill 472 268 290 472 271 290 minecraft:deepslate_tiles
setblock 472 268 294 minecraft:cobbled_deepslate
fill 472 268 295 472 271 295 minecraft:deepslate_tiles
setblock 472 268 299 minecraft:cobbled_deepslate
fill 472 268 300 472 271 300 minecraft:deepslate_tiles
setblock 472 268 304 minecraft:cobbled_deepslate
fill 472 268 305 472 269 305 minecraft:deepslate_tiles
setblock 472 268 309 minecraft:cobbled_deepslate
setblock 472 268 310 minecraft:deepslate_tiles
setblock 472 268 314 minecraft:cobbled_deepslate
fill 472 268 315 472 270 315 minecraft:deepslate_tiles
setblock 473 268 277 minecraft:deepslate_tiles
setblock 473 268 289 minecraft:deepslate_tiles
setblock 473 268 293 minecraft:cobbled_deepslate
fill 473 268 294 473 271 294 minecraft:deepslate_tiles
setblock 473 268 298 minecraft:cobbled_deepslate
fill 473 268 299 473 271 299 minecraft:deepslate_tiles
setblock 474 268 277 minecraft:cobbled_deepslate
setblock 474 268 292 minecraft:cobbled_deepslate
setblock 474 268 293 minecraft:deepslate_tiles
setblock 474 268 297 minecraft:cobbled_deepslate
fill 474 268 298 474 269 298 minecraft:deepslate_tiles
fill 474 268 299 474 270 300 minecraft:bone_block
setblock 475 268 276 minecraft:cobbled_deepslate
setblock 475 268 316 minecraft:cobbled_deepslate
fill 476 268 276 476 271 276 minecraft:deepslate_tiles
fill 476 268 316 476 269 316 minecraft:deepslate_tiles
setblock 479 268 276 minecraft:deepslate_tiles
setblock 480 268 276 minecraft:cobbled_deepslate
fill 481 268 276 484 268 276 minecraft:deepslate_tiles
setblock 484 268 316 minecraft:deepslate_tiles
setblock 485 268 276 minecraft:cobbled_deepslate
fill 485 268 277 485 271 277 minecraft:deepslate_tiles
setblock 485 268 316 minecraft:cobbled_deepslate
fill 486 268 276 486 271 276 minecraft:deepslate_tiles
fill 486 268 316 486 271 316 minecraft:deepslate_tiles
setblock 487 268 278 minecraft:deepslate_tiles
fill 487 268 315 490 268 315 minecraft:deepslate_tiles
setblock 488 268 278 minecraft:cobbled_deepslate
setblock 489 268 277 minecraft:cobbled_deepslate
fill 489 268 278 489 271 278 minecraft:deepslate_tiles
setblock 490 268 276 minecraft:cobbled_deepslate
fill 490 268 277 490 271 277 minecraft:deepslate_tiles
fill 490 268 314 491 268 314 minecraft:deepslate_tiles
setblock 490 268 316 minecraft:cobbled_deepslate
fill 491 268 276 491 271 276 minecraft:deepslate_tiles
setblock 491 268 315 minecraft:cobbled_deepslate
fill 491 268 316 491 271 316 minecraft:deepslate_tiles
setblock 492 268 314 minecraft:cobbled_deepslate
fill 492 268 315 492 271 315 minecraft:deepslate_tiles
setblock 493 268 278 minecraft:cobbled_deepslate
fill 493 268 314 493 269 314 minecraft:deepslate_tiles
setblock 494 268 277 minecraft:cobbled_deepslate
fill 494 268 278 494 271 278 minecraft:deepslate_tiles
setblock 495 268 276 minecraft:cobbled_deepslate
fill 495 268 277 495 271 277 minecraft:deepslate_tiles
setblock 495 268 316 minecraft:cobbled_deepslate
fill 496 268 276 496 271 276 minecraft:deepslate_tiles
setblock 496 268 315 minecraft:cobbled_deepslate
fill 496 268 316 499 268 316 minecraft:deepslate_tiles
setblock 497 268 314 minecraft:cobbled_deepslate
fill 497 268 315 500 268 315 minecraft:deepslate_tiles
setblock 499 268 277 minecraft:cobbled_deepslate
setblock 500 268 276 minecraft:cobbled_deepslate
setblock 500 268 277 minecraft:deepslate_tiles
setblock 500 268 316 minecraft:cobbled_deepslate
fill 501 268 276 504 268 276 minecraft:deepslate_tiles
setblock 501 268 315 minecraft:cobbled_deepslate
fill 501 268 316 501 271 316 minecraft:deepslate_tiles
fill 502 268 315 502 270 315 minecraft:deepslate_tiles
setblock 505 268 276 minecraft:cobbled_deepslate
setblock 505 268 316 minecraft:cobbled_deepslate
fill 506 268 276 506 271 276 minecraft:deepslate_tiles
setblock 506 268 315 minecraft:cobbled_deepslate
fill 506 268 316 506 271 316 minecraft:deepslate_tiles
setblock 507 268 314 minecraft:cobbled_deepslate
fill 507 268 315 507 271 315 minecraft:deepslate_tiles
fill 508 268 314 508 271 314 minecraft:deepslate_tiles
setblock 509 268 276 minecraft:deepslate_tiles
setblock 509 268 277 minecraft:cobbled_deepslate
fill 509 268 294 509 268 296 minecraft:deepslate_tiles
setblock 509 268 297 minecraft:cobbled_deepslate
fill 509 268 298 510 269 299 minecraft:deepslate_tiles
setblock 509 268 312 minecraft:cobbled_deepslate
fill 509 268 313 509 270 313 minecraft:deepslate_tiles
setblock 510 268 276 minecraft:cobbled_deepslate
fill 510 268 277 510 271 277 minecraft:deepslate_tiles
setblock 510 268 291 minecraft:cobbled_deepslate
fill 510 268 292 510 268 295 minecraft:deepslate_tiles
setblock 510 268 296 minecraft:cobbled_deepslate
fill 510 268 297 510 271 297 minecraft:deepslate_tiles
setblock 510 268 300 minecraft:deepslate_tiles
setblock 510 268 301 minecraft:cobbled_deepslate
fill 510 268 302 510 271 302 minecraft:deepslate_tiles
setblock 510 268 306 minecraft:cobbled_deepslate
fill 510 268 307 510 271 307 minecraft:deepslate_tiles
setblock 510 268 311 minecraft:cobbled_deepslate
fill 510 268 312 510 271 312 minecraft:deepslate_tiles
setblock 510 268 316 minecraft:cobbled_deepslate
fill 511 268 276 511 271 276 minecraft:deepslate_tiles
setblock 511 268 279 minecraft:deepslate_tiles
setblock 511 268 280 minecraft:cobbled_deepslate
fill 511 268 281 511 271 281 minecraft:deepslate_tiles
setblock 511 268 290 minecraft:cobbled_deepslate
fill 511 268 291 511 271 291 minecraft:deepslate_tiles
setblock 511 268 295 minecraft:cobbled_deepslate
fill 511 268 296 511 271 296 minecraft:deepslate_tiles
setblock 511 268 300 minecraft:cobbled_deepslate
fill 511 268 301 511 271 301 minecraft:deepslate_tiles
setblock 511 268 305 minecraft:cobbled_deepslate
fill 511 268 306 511 271 306 minecraft:deepslate_tiles
setblock 511 268 310 minecraft:cobbled_deepslate
fill 511 268 311 511 271 311 minecraft:deepslate_tiles
setblock 511 268 315 minecraft:cobbled_deepslate
fill 511 268 316 511 271 316 minecraft:deepslate_tiles
fill 470 269 279 470 308 279 minecraft:deepslate_tiles
fill 470 269 314 470 308 314 minecraft:deepslate_tiles
setblock 471 269 279 minecraft:cobbled_deepslate
fill 471 269 280 471 272 280 minecraft:deepslate_tiles
setblock 471 269 284 minecraft:cobbled_deepslate
fill 471 269 285 471 269 288 minecraft:deepslate_tiles
setblock 471 269 289 minecraft:cobbled_deepslate
fill 471 269 290 471 272 290 minecraft:deepslate_tiles
setblock 471 269 294 minecraft:cobbled_deepslate
fill 471 269 295 471 272 295 minecraft:deepslate_tiles
setblock 471 269 299 minecraft:cobbled_deepslate
fill 471 269 300 471 272 300 minecraft:deepslate_tiles
setblock 471 269 304 minecraft:cobbled_deepslate
fill 471 269 305 471 272 305 minecraft:deepslate_tiles
setblock 471 269 309 minecraft:cobbled_deepslate
fill 471 269 310 471 271 310 minecraft:deepslate_tiles
setblock 471 269 314 minecraft:cobbled_deepslate
fill 471 269 315 471 272 315 minecraft:deepslate_tiles
setblock 472 269 278 minecraft:cobbled_deepslate
setblock 472 269 288 minecraft:cobbled_deepslate
fill 472 269 289 472 270 289 minecraft:deepslate_tiles
setblock 472 269 293 minecraft:cobbled_deepslate
fill 472 269 294 472 272 294 minecraft:deepslate_tiles
setblock 472 269 298 minecraft:cobbled_deepslate
fill 472 269 299 472 272 299 minecraft:deepslate_tiles
setblock 472 269 303 minecraft:cobbled_deepslate
fill 472 269 304 472 272 304 minecraft:deepslate_tiles
setblock 472 269 313 minecraft:cobbled_deepslate
setblock 472 269 314 minecraft:deepslate_tiles
setblock 473 269 277 minecraft:cobbled_deepslate
setblock 473 269 278 minecraft:light[level=13]
setblock 473 269 286 minecraft:light[level=13]
setblock 473 269 292 minecraft:cobbled_deepslate
fill 473 269 293 473 271 293 minecraft:deepslate_tiles
setblock 473 269 297 minecraft:cobbled_deepslate
fill 473 269 298 473 272 298 minecraft:deepslate_tiles
fill 473 269 302 473 270 302 minecraft:bone_block
setblock 473 269 310 minecraft:light[level=13]
setblock 474 269 276 minecraft:cobbled_deepslate
setblock 474 269 277 minecraft:deepslate_tiles
setblock 474 269 296 minecraft:cobbled_deepslate
setblock 474 269 297 minecraft:deepslate_tiles
setblock 474 269 316 minecraft:cobbled_deepslate
fill 475 269 276 475 272 276 minecraft:deepslate_tiles
fill 475 269 316 475 270 316 minecraft:deepslate_tiles
setblock 479 269 276 minecraft:cobbled_deepslate
fill 480 269 276 483 269 276 minecraft:deepslate_tiles
setblock 481 269 278 minecraft:light[level=13]
setblock 481 269 286 minecraft:light[level=13]
setblock 481 269 294 minecraft:light[level=13]
setblock 481 269 302 minecraft:light[level=13]
setblock 481 269 310 minecraft:light[level=13]
setblock 484 269 276 minecraft:cobbled_deepslate
fill 484 269 277 484 272 277 minecraft:deepslate_tiles
setblock 484 269 316 minecraft:cobbled_deepslate
fill 485 269 276 485 272 276 minecraft:deepslate_tiles
fill 485 269 316 485 272 316 minecraft:deepslate_tiles
setblock 487 269 278 minecraft:cobbled_deepslate
fill 487 269 315 489 269 315 minecraft:deepslate_tiles
setblock 488 269 277 minecraft:cobbled_deepslate
fill 488 269 278 488 272 278 minecraft:deepslate_tiles
setblock 489 269 276 minecraft:cobbled_deepslate
fill 489 269 277 489 272 277 minecraft:deepslate_tiles
setblock 489 269 286 minecraft:light[level=13]
setblock 489 269 302 minecraft:light[level=13]
setblock 489 269 310 minecraft:light[level=13]
setblock 489 269 316 minecraft:cobbled_deepslate
fill 490 269 276 490 272 276 minecraft:deepslate_tiles
setblock 490 269 315 minecraft:cobbled_deepslate
fill 490 269 316 490 272 316 minecraft:deepslate_tiles
setblock 491 269 314 minecraft:cobbled_deepslate
fill 491 269 315 491 272 315 minecraft:deepslate_tiles
setblock 492 269 278 minecraft:cobbled_deepslate
setblock 492 269 314 minecraft:deepslate_tiles
setblock 493 269 277 minecraft:cobbled_deepslate
fill 493 269 278 493 272 278 minecraft:deepslate_tiles
setblock 494 269 276 minecraft:cobbled_deepslate
fill 494 269 277 494 272 277 minecraft:deepslate_tiles
setblock 494 269 316 minecraft:cobbled_deepslate
fill 495 269 276 495 272 276 minecraft:deepslate_tiles
setblock 495 269 315 minecraft:cobbled_deepslate
fill 495 269 316 498 269 316 minecraft:deepslate_tiles
fill 496 269 315 499 269 315 minecraft:deepslate_tiles
setblock 497 269 278 minecraft:light[level=13]
setblock 497 269 286 minecraft:light[level=13]
setblock 497 269 294 minecraft:light[level=13]
setblock 497 269 302 minecraft:light[level=13]
setblock 497 269 310 minecraft:light[level=13]
setblock 498 269 277 minecraft:cobbled_deepslate
setblock 499 269 276 minecraft:cobbled_deepslate
setblock 499 269 277 minecraft:deepslate_tiles
setblock 499 269 316 minecraft:cobbled_deepslate
fill 500 269 276 503 269 276 minecraft:deepslate_tiles
setblock 500 269 315 minecraft:cobbled_deepslate
fill 500 269 316 500 272 316 minecraft:deepslate_tiles
setblock 501 269 315 minecraft:deepslate_tiles
setblock 504 269 276 minecraft:cobbled_deepslate
setblock 504 269 316 minecraft:cobbled_deepslate
fill 505 269 276 505 272 276 minecraft:deepslate_tiles
setblock 505 269 278 minecraft:light[level=13]
setblock 505 269 286 minecraft:light[level=13]
setblock 505 269 294 minecraft:light[level=13]
setblock 505 269 302 minecraft:light[level=13]
setblock 505 269 310 minecraft:light[level=13]
setblock 505 269 315 minecraft:cobbled_deepslate
fill 505 269 316 505 272 316 minecraft:deepslate_tiles
fill 506 269 277 506 270 277 minecraft:deepslate_tiles
setblock 506 269 314 minecraft:cobbled_deepslate
fill 506 269 315 506 272 315 minecraft:deepslate_tiles
fill 507 269 314 507 270 314 minecraft:deepslate_tiles
setblock 508 269 276 minecraft:deepslate_tiles
setblock 508 269 277 minecraft:cobbled_deepslate
setblock 509 269 276 minecraft:cobbled_deepslate
fill 509 269 277 509 272 277 minecraft:deepslate_tiles
setblock 509 269 295 minecraft:deepslate_tiles
setblock 509 269 296 minecraft:cobbled_deepslate
fill 509 269 297 509 272 297 minecraft:deepslate_tiles
setblock 509 269 300 minecraft:deepslate_tiles
setblock 509 269 311 minecraft:cobbled_deepslate
setblock 509 269 312 minecraft:deepslate_tiles
setblock 509 269 316 minecraft:cobbled_deepslate
fill 510 269 276 510 272 276 minecraft:deepslate_tiles
fill 510 269 291 510 269 294 minecraft:deepslate_tiles
setblock 510 269 295 minecraft:cobbled_deepslate
fill 510 269 296 510 272 296 minecraft:deepslate_tiles
setblock 510 269 300 minecraft:cobbled_deepslate
fill 510 269 301 510 272 301 minecraft:deepslate_tiles
setblock 510 269 305 minecraft:cobbled_deepslate
fill 510 269 306 510 272 306 minecraft:deepslate_tiles
setblock 510 269 310 minecraft:cobbled_deepslate
fill 510 269 311 510 272 311 minecraft:deepslate_tiles
setblock 510 269 315 minecraft:cobbled_deepslate
fill 510 269 316 510 272 316 minecraft:deepslate_tiles
setblock 511 269 279 minecraft:cobbled_deepslate
fill 511 269 280 511 272 280 minecraft:deepslate_tiles
setblock 511 269 289 minecraft:cobbled_deepslate
fill 511 269 290 511 271 290 minecraft:deepslate_tiles
setblock 511 269 294 minecraft:cobbled_deepslate
fill 511 269 295 511 272 295 minecraft:deepslate_tiles
setblock 511 269 299 minecraft:cobbled_deepslate
fill 511 269 300 511 272 300 minecraft:deepslate_tiles
setblock 511 269 304 minecraft:cobbled_deepslate
fill 511 269 305 511 272 305 minecraft:deepslate_tiles
setblock 511 269 309 minecraft:cobbled_deepslate
fill 511 269 310 511 272 310 minecraft:deepslate_tiles
setblock 511 269 314 minecraft:cobbled_deepslate
fill 511 269 315 511 272 315 minecraft:deepslate_tiles
setblock 512 269 306 minecraft:white_wool
fill 470 270 304 471 272 304 minecraft:deepslate_tiles
setblock 470 270 305 minecraft:redstone_block
setblock 471 270 277 minecraft:deepslate_tiles
setblock 471 270 278 minecraft:cobbled_deepslate
fill 471 270 279 471 272 279 minecraft:deepslate_tiles
setblock 471 270 283 minecraft:cobbled_deepslate
fill 471 270 284 471 270 287 minecraft:deepslate_tiles
setblock 471 270 288 minecraft:cobbled_deepslate
fill 471 270 289 471 272 289 minecraft:deepslate_tiles
setblock 471 270 293 minecraft:cobbled_deepslate
fill 471 270 294 471 272 294 minecraft:deepslate_tiles
setblock 471 270 298 minecraft:cobbled_deepslate
fill 471 270 299 471 272 299 minecraft:deepslate_tiles
setblock 471 270 303 minecraft:cobbled_deepslate
setblock 471 270 308 minecraft:cobbled_deepslate
fill 471 270 309 471 271 309 minecraft:deepslate_tiles
setblock 471 270 313 minecraft:cobbled_deepslate
fill 471 270 314 471 272 314 minecraft:deepslate_tiles
setblock 472 270 277 minecraft:cobbled_deepslate
setblock 472 270 278 minecraft:deepslate_tiles
setblock 472 270 292 minecraft:cobbled_deepslate
fill 472 270 293 472 272 293 minecraft:deepslate_tiles
setblock 472 270 297 minecraft:cobbled_deepslate
fill 472 270 298 472 272 298 minecraft:deepslate_tiles
setblock 472 270 302 minecraft:cobbled_deepslate
fill 472 270 303 472 272 303 minecraft:deepslate_tiles
setblock 473 270 276 minecraft:cobbled_deepslate
setblock 473 270 277 minecraft:deepslate_tiles
setblock 473 270 292 minecraft:deepslate_tiles
setblock 473 270 296 minecraft:cobbled_deepslate
fill 473 270 297 473 272 297 minecraft:deepslate_tiles
setblock 473 270 301 minecraft:cobbled_deepslate
setblock 473 270 316 minecraft:cobbled_deepslate
fill 474 270 276 474 272 276 minecraft:deepslate_tiles
fill 474 270 316 474 271 316 minecraft:deepslate_tiles
setblock 478 270 276 minecraft:cobbled_deepslate
fill 479 270 276 482 270 276 minecraft:deepslate_tiles
setblock 483 270 276 minecraft:cobbled_deepslate
fill 484 270 276 484 272 276 minecraft:deepslate_tiles
setblock 484 270 316 minecraft:deepslate_tiles
setblock 486 270 278 minecraft:cobbled_deepslate
setblock 487 270 277 minecraft:cobbled_deepslate
fill 487 270 278 487 272 278 minecraft:deepslate_tiles
fill 487 270 315 488 270 315 minecraft:deepslate_tiles
setblock 488 270 276 minecraft:cobbled_deepslate
fill 488 270 277 488 272 277 minecraft:deepslate_tiles
setblock 488 270 316 minecraft:cobbled_deepslate
fill 489 270 276 489 272 276 minecraft:deepslate_tiles
setblock 489 270 315 minecraft:cobbled_deepslate
fill 489 270 316 489 272 316 minecraft:deepslate_tiles
fill 490 270 315 490 272 315 minecraft:deepslate_tiles
setblock 491 270 278 minecraft:cobbled_deepslate
setblock 492 270 277 minecraft:cobbled_deepslate
fill 492 270 278 492 272 278 minecraft:deepslate_tiles
setblock 493 270 276 minecraft:cobbled_deepslate
fill 493 270 277 493 272 277 minecraft:deepslate_tiles
setblock 493 270 316 minecraft:cobbled_deepslate
fill 494 270 276 494 272 276 minecraft:deepslate_tiles
setblock 494 270 315 minecraft:cobbled_deepslate
fill 494 270 316 497 270 316 minecraft:deepslate_tiles
fill 495 270 315 498 270 315 minecraft:deepslate_tiles
setblock 497 270 277 minecraft:cobbled_deepslate
setblock 498 270 276 minecraft:cobbled_deepslate
setblock 498 270 277 minecraft:deepslate_tiles
setblock 498 270 316 minecraft:cobbled_deepslate
fill 499 270 276 502 270 276 minecraft:deepslate_tiles
setblock 499 270 315 minecraft:cobbled_deepslate
fill 499 270 316 499 272 316 minecraft:deepslate_tiles
setblock 503 270 276 minecraft:cobbled_deepslate
setblock 503 270 316 minecraft:cobbled_deepslate
fill 504 270 276 504 272 276 minecraft:deepslate_tiles
setblock 504 270 315 minecraft:cobbled_deepslate
fill 504 270 316 504 272 316 minecraft:deepslate_tiles
fill 505 270 315 505 272 315 minecraft:deepslate_tiles
fill 506 270 287 506 271 287 minecraft:black_concrete
setblock 507 270 276 minecraft:deepslate_tiles
setblock 507 270 277 minecraft:cobbled_deepslate
fill 507 270 286 507 271 286 minecraft:black_concrete
fill 507 270 288 507 271 288 minecraft:black_concrete
setblock 508 270 276 minecraft:cobbled_deepslate
fill 508 270 277 508 272 277 minecraft:deepslate_tiles
fill 508 270 287 508 271 287 minecraft:black_concrete
setblock 508 270 316 minecraft:cobbled_deepslate
fill 509 270 276 509 272 276 minecraft:deepslate_tiles
setblock 509 270 295 minecraft:cobbled_deepslate
fill 509 270 296 509 272 296 minecraft:deepslate_tiles
fill 509 270 298 509 270 299 minecraft:deepslate_tiles
setblock 509 270 300 minecraft:cobbled_deepslate
fill 509 270 301 509 272 301 minecraft:deepslate_tiles
setblock 509 270 315 minecraft:cobbled_deepslate
fill 509 270 316 509 272 316 minecraft:deepslate_tiles
fill 510 270 292 510 270 293 minecraft:deepslate_tiles
setblock 510 270 294 minecraft:cobbled_deepslate
fill 510 270 295 510 272 295 minecraft:deepslate_tiles
setblock 510 270 298 minecraft:deepslate_tiles
setblock 510 270 299 minecraft:cobbled_deepslate
fill 510 270 300 510 272 300 minecraft:deepslate_tiles
setblock 510 270 304 minecraft:cobbled_deepslate
fill 510 270 305 510 272 305 minecraft:deepslate_tiles
setblock 510 270 309 minecraft:cobbled_deepslate
fill 510 270 310 510 272 310 minecraft:deepslate_tiles
setblock 510 270 314 minecraft:cobbled_deepslate
fill 510 270 315 510 272 315 minecraft:deepslate_tiles
setblock 511 270 278 minecraft:cobbled_deepslate
fill 511 270 279 511 272 279 minecraft:deepslate_tiles
setblock 511 270 289 minecraft:deepslate_tiles
setblock 511 270 293 minecraft:cobbled_deepslate
fill 511 270 294 511 272 294 minecraft:deepslate_tiles
setblock 511 270 298 minecraft:cobbled_deepslate
fill 511 270 299 511 272 299 minecraft:deepslate_tiles
setblock 511 270 303 minecraft:cobbled_deepslate
fill 511 270 304 511 272 304 minecraft:deepslate_tiles
setblock 511 270 308 minecraft:cobbled_deepslate
fill 511 270 309 511 272 309 minecraft:deepslate_tiles
setblock 511 270 313 minecraft:cobbled_deepslate
fill 511 270 314 511 272 314 minecraft:deepslate_tiles
fill 512 270 306 512 308 306 minecraft:deepslate_tiles
fill 470 271 305 470 305 305 minecraft:deepslate_tiles
setblock 471 271 277 minecraft:cobbled_deepslate
fill 471 271 278 471 272 278 minecraft:deepslate_tiles
setblock 471 271 282 minecraft:cobbled_deepslate
fill 471 271 283 471 271 286 minecraft:deepslate_tiles
setblock 471 271 287 minecraft:cobbled_deepslate
fill 471 271 288 471 272 288 minecraft:deepslate_tiles
setblock 471 271 292 minecraft:cobbled_deepslate
fill 471 271 293 471 272 293 minecraft:deepslate_tiles
setblock 471 271 297 minecraft:cobbled_deepslate
fill 471 271 298 471 272 298 minecraft:deepslate_tiles
setblock 471 271 302 minecraft:cobbled_deepslate
fill 471 271 303 471 272 303 minecraft:deepslate_tiles
setblock 471 271 307 minecraft:cobbled_deepslate
fill 471 271 308 471 272 308 minecraft:deepslate_tiles
setblock 471 271 312 minecraft:cobbled_deepslate
fill 471 271 313 471 272 313 minecraft:deepslate_tiles
setblock 472 271 276 minecraft:cobbled_deepslate
setblock 472 271 277 minecraft:deepslate_tiles
setblock 472 271 291 minecraft:cobbled_deepslate
fill 472 271 292 472 272 292 minecraft:deepslate_tiles
setblock 472 271 296 minecraft:cobbled_deepslate
fill 472 271 297 472 272 297 minecraft:deepslate_tiles
setblock 472 271 301 minecraft:cobbled_deepslate
fill 472 271 302 472 272 302 minecraft:deepslate_tiles
setblock 472 271 316 minecraft:cobbled_deepslate
fill 473 271 276 473 272 276 minecraft:deepslate_tiles
setblock 473 271 278 minecraft:light[level=12]
setblock 473 271 285 minecraft:light[level=12]
setblock 473 271 292 minecraft:light[level=12]
setblock 473 271 295 minecraft:cobbled_deepslate
fill 473 271 296 473 272 296 minecraft:deepslate_tiles
setblock 473 271 300 minecraft:cobbled_deepslate
setblock 473 271 301 minecraft:deepslate_tiles
setblock 473 271 306 minecraft:light[level=12]
setblock 473 271 313 minecraft:light[level=12]
setblock 473 271 316 minecraft:deepslate_tiles
setblock 477 271 276 minecraft:cobbled_deepslate
fill 480 271 276 481 271 276 minecraft:deepslate_tiles
setblock 480 271 278 minecraft:light[level=12]
setblock 480 271 285 minecraft:light[level=12]
setblock 480 271 292 minecraft:light[level=12]
setblock 480 271 299 minecraft:light[level=12]
setblock 480 271 306 minecraft:light[level=12]
setblock 480 271 313 minecraft:light[level=12]
setblock 482 271 276 minecraft:cobbled_deepslate
fill 483 271 276 483 272 277 minecraft:deepslate_tiles
setblock 486 271 277 minecraft:cobbled_deepslate
fill 486 271 278 486 272 278 minecraft:deepslate_tiles
setblock 487 271 276 minecraft:cobbled_deepslate
fill 487 271 277 487 272 277 minecraft:deepslate_tiles
setblock 487 271 285 minecraft:light[level=12]
setblock 487 271 292 minecraft:light[level=12]
setblock 487 271 299 minecraft:light[level=12]
setblock 487 271 306 minecraft:light[level=12]
setblock 487 271 313 minecraft:light[level=12]
setblock 487 271 316 minecraft:cobbled_deepslate
fill 488 271 276 488 272 276 minecraft:deepslate_tiles
setblock 488 271 315 minecraft:cobbled_deepslate
fill 488 271 316 488 272 316 minecraft:deepslate_tiles
fill 489 271 315 489 272 315 minecraft:deepslate_tiles
setblock 490 271 278 minecraft:cobbled_deepslate
setblock 491 271 277 minecraft:cobbled_deepslate
fill 491 271 278 491 272 278 minecraft:deepslate_tiles
setblock 492 271 276 minecraft:cobbled_deepslate
fill 492 271 277 492 272 277 minecraft:deepslate_tiles
setblock 492 271 316 minecraft:cobbled_deepslate
fill 493 271 276 493 272 276 minecraft:deepslate_tiles
setblock 493 271 315 minecraft:cobbled_deepslate
fill 493 271 316 496 271 316 minecraft:deepslate_tiles
setblock 494 271 285 minecraft:light[level=12]
setblock 494 271 292 minecraft:light[level=12]
setblock 494 271 299 minecraft:light[level=12]
setblock 494 271 306 minecraft:light[level=12]
setblock 494 271 313 minecraft:light[level=12]
fill 494 271 315 496 271 315 minecraft:deepslate_tiles
setblock 496 271 277 minecraft:cobbled_deepslate
setblock 497 271 276 minecraft:cobbled_deepslate
fill 497 271 277 497 272 277 minecraft:deepslate_tiles
setblock 497 271 316 minecraft:cobbled_deepslate
fill 498 271 276 501 271 276 minecraft:deepslate_tiles
fill 498 271 316 498 272 316 minecraft:deepslate_tiles
setblock 501 271 278 minecraft:light[level=12]
setblock 501 271 285 minecraft:light[level=12]
setblock 501 271 292 minecraft:light[level=12]
setblock 501 271 299 minecraft:light[level=12]
setblock 501 271 306 minecraft:light[level=12]
setblock 501 271 313 minecraft:light[level=12]
setblock 501 271 317 minecraft:redstone_block
setblock 502 271 276 minecraft:cobbled_deepslate
setblock 502 271 316 minecraft:cobbled_deepslate
fill 502 271 317 503 308 317 minecraft:deepslate_tiles
fill 503 271 276 503 272 276 minecraft:deepslate_tiles
setblock 503 271 315 minecraft:cobbled_deepslate
fill 503 271 316 503 272 316 minecraft:deepslate_tiles
fill 504 271 315 504 272 315 minecraft:deepslate_tiles
setblock 506 271 277 minecraft:cobbled_deepslate
setblock 507 271 276 minecraft:cobbled_deepslate
fill 507 271 277 507 272 277 minecraft:deepslate_tiles
setblock 507 271 316 minecraft:cobbled_deepslate
fill 508 271 276 508 272 276 minecraft:deepslate_tiles
setblock 508 271 278 minecraft:light[level=12]
setblock 508 271 285 minecraft:light[level=12]
setblock 508 271 292 minecraft:light[level=12]
setblock 508 271 299 minecraft:light[level=12]
setblock 508 271 306 minecraft:light[level=12]
setblock 508 271 313 minecraft:light[level=12]
setblock 508 271 315 minecraft:cobbled_deepslate
fill 508 271 316 508 272 316 minecraft:deepslate_tiles
setblock 509 271 298 minecraft:deepslate_tiles
setblock 509 271 299 minecraft:cobbled_deepslate
fill 509 271 300 509 272 300 minecraft:deepslate_tiles
fill 509 271 302 509 272 302 minecraft:deepslate_tiles
setblock 509 271 314 minecraft:cobbled_deepslate
fill 509 271 315 509 272 315 minecraft:deepslate_tiles
setblock 510 271 278 minecraft:cobbled_deepslate
setblock 510 271 293 minecraft:cobbled_deepslate
fill 510 271 294 510 272 294 minecraft:deepslate_tiles
setblock 510 271 298 minecraft:cobbled_deepslate
fill 510 271 299 510 272 299 minecraft:deepslate_tiles
setblock 510 271 303 minecraft:cobbled_deepslate
fill 510 271 304 510 272 304 minecraft:deepslate_tiles
setblock 510 271 308 minecraft:cobbled_deepslate
fill 510 271 309 510 272 309 minecraft:deepslate_tiles
setblock 510 271 313 minecraft:cobbled_deepslate
fill 510 271 314 510 272 314 minecraft:deepslate_tiles
setblock 511 271 277 minecraft:cobbled_deepslate
fill 511 271 278 511 272 278 minecraft:deepslate_tiles
setblock 511 271 292 minecraft:cobbled_deepslate
fill 511 271 293 511 272 293 minecraft:deepslate_tiles
setblock 511 271 297 minecraft:cobbled_deepslate
fill 511 271 298 511 272 298 minecraft:deepslate_tiles
setblock 511 271 302 minecraft:cobbled_deepslate
fill 511 271 303 511 272 303 minecraft:deepslate_tiles
setblock 511 271 307 minecraft:cobbled_deepslate
fill 511 271 308 511 272 308 minecraft:deepslate_tiles
setblock 511 271 312 minecraft:cobbled_deepslate
fill 511 271 313 511 272 313 minecraft:deepslate_tiles
setblock 512 271 289 minecraft:white_wool
setblock 470 272 285 minecraft:redstone_block
setblock 471 272 276 minecraft:cobbled_deepslate
setblock 471 272 277 minecraft:deepslate_tiles
setblock 471 272 281 minecraft:cobbled_deepslate
fill 471 272 282 471 272 285 minecraft:deepslate_tiles
setblock 471 272 286 minecraft:cobbled_deepslate
setblock 471 272 287 minecraft:deepslate_tiles
setblock 471 272 291 minecraft:cobbled_deepslate
setblock 471 272 292 minecraft:deepslate_tiles
setblock 471 272 296 minecraft:cobbled_deepslate
setblock 471 272 297 minecraft:deepslate_tiles
setblock 471 272 301 minecraft:cobbled_deepslate
setblock 471 272 302 minecraft:deepslate_tiles
setblock 471 272 306 minecraft:cobbled_deepslate
setblock 471 272 307 minecraft:deepslate_tiles
setblock 471 272 316 minecraft:cobbled_deepslate
setblock 472 272 276 minecraft:deepslate_tiles
setblock 472 272 291 minecraft:deepslate_tiles
setblock 472 272 295 minecraft:cobbled_deepslate
setblock 472 272 296 minecraft:deepslate_tiles
setblock 472 272 300 minecraft:cobbled_deepslate
setblock 472 272 301 minecraft:deepslate_tiles
setblock 472 272 316 minecraft:deepslate_tiles
setblock 473 272 294 minecraft:cobbled_deepslate
setblock 473 272 295 minecraft:deepslate_tiles
setblock 473 272 299 minecraft:cobbled_deepslate
setblock 473 272 300 minecraft:deepslate_tiles
setblock 476 272 276 minecraft:cobbled_deepslate
fill 478 272 317 479 285 317 minecraft:deepslate_tiles
setblock 480 272 276 minecraft:deepslate_tiles
setblock 480 272 317 minecraft:redstone_block
setblock 481 272 276 minecraft:cobbled_deepslate
setblock 482 272 276 minecraft:deepslate_tiles
setblock 485 272 277 minecraft:cobbled_deepslate
setblock 485 272 278 minecraft:deepslate_tiles
setblock 486 272 276 minecraft:cobbled_deepslate
setblock 486 272 277 minecraft:deepslate_tiles
setblock 486 272 316 minecraft:cobbled_deepslate
setblock 487 272 276 minecraft:deepslate_tiles
setblock 487 272 316 minecraft:deepslate_tiles
setblock 487 272 317 minecraft:white_wool
setblock 488 272 315 minecraft:deepslate_tiles
fill 488 272 317 489 308 317 minecraft:deepslate_tiles
setblock 489 272 278 minecraft:cobbled_deepslate
setblock 489 272 279 minecraft:deepslate_tiles
setblock 490 272 277 minecraft:cobbled_deepslate
setblock 490 272 278 minecraft:deepslate_tiles
setblock 490 272 317 minecraft:white_wool
setblock 491 272 276 minecraft:cobbled_deepslate
setblock 491 272 277 minecraft:deepslate_tiles
setblock 491 272 316 minecraft:cobbled_deepslate
setblock 492 272 276 minecraft:deepslate_tiles
setblock 492 272 315 minecraft:cobbled_deepslate
fill 492 272 316 495 272 316 minecraft:deepslate_tiles
fill 493 272 315 494 272 315 minecraft:deepslate_tiles
setblock 494 272 278 minecraft:cobbled_deepslate
setblock 495 272 277 minecraft:cobbled_deepslate
setblock 496 272 276 minecraft:cobbled_deepslate
setblock 496 272 277 minecraft:deepslate_tiles
setblock 496 272 316 minecraft:cobbled_deepslate
fill 497 272 276 500 272 276 minecraft:deepslate_tiles
setblock 497 272 316 minecraft:deepslate_tiles
setblock 501 272 276 minecraft:cobbled_deepslate
setblock 501 272 316 minecraft:cobbled_deepslate
fill 501 272 317 501 285 317 minecraft:deepslate_tiles
setblock 502 272 276 minecraft:deepslate_tiles
setblock 502 272 316 minecraft:deepslate_tiles
setblock 506 272 276 minecraft:cobbled_deepslate
setblock 506 272 277 minecraft:deepslate_tiles
setblock 506 272 316 minecraft:cobbled_deepslate
setblock 507 272 276 minecraft:deepslate_tiles
setblock 507 272 315 minecraft:cobbled_deepslate
setblock 507 272 316 minecraft:deepslate_tiles
setblock 508 272 315 minecraft:deepslate_tiles
setblock 509 272 298 minecraft:cobbled_deepslate
setblock 509 272 299 minecraft:deepslate_tiles
setblock 509 272 303 minecraft:cobbled_deepslate
setblock 510 272 277 minecraft:cobbled_deepslate
setblock 510 272 278 minecraft:deepslate_tiles
setblock 510 272 293 minecraft:deepslate_tiles
setblock 510 272 297 minecraft:cobbled_deepslate
setblock 510 272 298 minecraft:deepslate_tiles
setblock 510 272 302 minecraft:cobbled_deepslate
setblock 510 272 303 minecraft:deepslate_tiles
setblock 510 272 307 minecraft:cobbled_deepslate
setblock 510 272 308 minecraft:deepslate_tiles
setblock 510 272 312 minecraft:cobbled_deepslate
setblock 510 272 313 minecraft:deepslate_tiles
setblock 511 272 276 minecraft:cobbled_deepslate
setblock 511 272 277 minecraft:deepslate_tiles
setblock 511 272 281 minecraft:cobbled_deepslate
setblock 511 272 291 minecraft:cobbled_deepslate
setblock 511 272 292 minecraft:deepslate_tiles
setblock 511 272 296 minecraft:cobbled_deepslate
setblock 511 272 297 minecraft:deepslate_tiles
setblock 511 272 301 minecraft:cobbled_deepslate
setblock 511 272 302 minecraft:deepslate_tiles
setblock 511 272 306 minecraft:cobbled_deepslate
setblock 511 272 307 minecraft:deepslate_tiles
setblock 511 272 311 minecraft:cobbled_deepslate
setblock 511 272 312 minecraft:deepslate_tiles
setblock 511 272 316 minecraft:cobbled_deepslate
fill 512 272 289 512 308 289 minecraft:deepslate_tiles
fill 470 273 285 470 308 285 minecraft:deepslate_tiles
fill 470 273 304 470 308 304 minecraft:deepslate_tiles
setblock 470 273 316 minecraft:redstone_block
setblock 471 273 317 minecraft:white_wool
fill 480 273 317 480 308 317 minecraft:deepslate_tiles
fill 487 273 317 487 308 317 minecraft:deepslate_tiles
fill 490 273 317 490 308 317 minecraft:deepslate_tiles
fill 470 274 316 470 308 316 minecraft:deepslate_tiles
fill 471 274 317 471 308 317 minecraft:deepslate_tiles
setblock 512 274 299 minecraft:white_wool
fill 481 275 275 482 299 275 minecraft:deepslate_tiles
setblock 483 275 275 minecraft:redstone_block
fill 512 275 299 512 288 299 minecraft:deepslate_tiles
fill 483 276 275 483 304 275 minecraft:deepslate_tiles
setblock 473 277 278 minecraft:light[level=13]
setblock 473 277 285 minecraft:light[level=12]
setblock 473 277 286 minecraft:light[level=13]
setblock 473 277 292 minecraft:light[level=12]
setblock 473 277 294 minecraft:light[level=13]
setblock 473 277 299 minecraft:light[level=12]
setblock 473 277 302 minecraft:light[level=13]
setblock 473 277 306 minecraft:light[level=12]
setblock 473 277 310 minecraft:light[level=13]
setblock 473 277 313 minecraft:light[level=12]
setblock 480 277 278 minecraft:light[level=12]
setblock 480 277 285 minecraft:light[level=12]
setblock 480 277 292 minecraft:light[level=12]
setblock 480 277 299 minecraft:light[level=12]
setblock 480 277 306 minecraft:light[level=12]
setblock 480 277 313 minecraft:light[level=12]
setblock 481 277 278 minecraft:light[level=13]
setblock 481 277 286 minecraft:light[level=13]
setblock 481 277 294 minecraft:light[level=13]
setblock 481 277 302 minecraft:light[level=13]
setblock 481 277 310 minecraft:light[level=13]
setblock 487 277 278 minecraft:light[level=12]
setblock 487 277 285 minecraft:light[level=12]
setblock 487 277 292 minecraft:light[level=12]
setblock 487 277 299 minecraft:light[level=12]
setblock 487 277 306 minecraft:light[level=12]
setblock 487 277 313 minecraft:light[level=12]
setblock 489 277 278 minecraft:light[level=13]
setblock 489 277 286 minecraft:light[level=13]
setblock 489 277 302 minecraft:light[level=13]
setblock 489 277 310 minecraft:light[level=13]
setblock 494 277 278 minecraft:light[level=12]
setblock 494 277 285 minecraft:light[level=12]
setblock 494 277 292 minecraft:light[level=12]
setblock 494 277 299 minecraft:light[level=12]
setblock 494 277 306 minecraft:light[level=12]
setblock 494 277 313 minecraft:light[level=12]
setblock 497 277 278 minecraft:light[level=13]
setblock 497 277 286 minecraft:light[level=13]
setblock 497 277 294 minecraft:light[level=13]
setblock 497 277 302 minecraft:light[level=13]
setblock 497 277 310 minecraft:light[level=13]
setblock 501 277 278 minecraft:light[level=12]
setblock 501 277 285 minecraft:light[level=12]
setblock 501 277 292 minecraft:light[level=12]
setblock 501 277 299 minecraft:light[level=12]
setblock 501 277 306 minecraft:light[level=12]
setblock 501 277 313 minecraft:light[level=12]
setblock 505 277 278 minecraft:light[level=13]
setblock 505 277 286 minecraft:light[level=13]
setblock 505 277 294 minecraft:light[level=13]
setblock 505 277 302 minecraft:light[level=13]
setblock 505 277 310 minecraft:light[level=13]
setblock 508 277 278 minecraft:light[level=12]
setblock 508 277 285 minecraft:light[level=12]
setblock 508 277 292 minecraft:light[level=12]
setblock 508 277 299 minecraft:light[level=12]
setblock 508 277 306 minecraft:light[level=12]
setblock 508 277 313 minecraft:light[level=12]
fill 471 278 276 486 278 316 minecraft:black_stained_glass
setblock 486 278 317 minecraft:white_wool
fill 487 278 276 487 278 292 minecraft:black_stained_glass
fill 487 278 294 487 278 316 minecraft:black_stained_glass
fill 488 278 276 489 278 290 minecraft:black_stained_glass
fill 488 278 296 489 278 316 minecraft:black_stained_glass
fill 490 278 276 511 278 289 minecraft:black_stained_glass
fill 490 278 297 511 278 316 minecraft:black_stained_glass
fill 491 278 290 511 278 290 minecraft:black_stained_glass
fill 491 278 296 511 278 296 minecraft:black_stained_glass
fill 493 278 291 511 278 292 minecraft:black_stained_glass
fill 493 278 294 511 278 295 minecraft:black_stained_glass
fill 494 278 293 511 278 293 minecraft:black_stained_glass
fill 471 279 276 481 279 276 minecraft:black_stained_glass
fill 471 279 277 471 279 279 minecraft:white_wool
fill 471 279 280 471 279 284 minecraft:black_stained_glass
setblock 471 279 285 minecraft:white_wool
fill 471 279 286 472 279 288 minecraft:black_stained_glass
fill 471 279 289 474 279 289 minecraft:white_wool
fill 471 279 290 471 279 296 minecraft:black_stained_glass
fill 471 279 297 474 279 297 minecraft:white_wool
fill 471 279 298 472 279 301 minecraft:black_stained_glass
setblock 471 279 302 minecraft:white_wool
fill 471 279 303 471 279 307 minecraft:black_stained_glass
fill 471 279 308 471 279 309 minecraft:white_wool
fill 471 279 310 476 279 312 minecraft:black_stained_glass
setblock 471 279 313 minecraft:white_wool
fill 471 279 314 474 279 316 minecraft:black_stained_glass
fill 472 279 277 476 279 277 minecraft:black_stained_glass
fill 472 279 278 472 279 279 minecraft:white_wool
fill 472 279 280 472 279 282 minecraft:black_stained_glass
setblock 472 279 283 minecraft:white_wool
fill 472 279 284 473 279 285 minecraft:black_stained_glass
fill 472 279 290 475 279 290 minecraft:black_stained_glass
fill 472 279 291 472 279 296 minecraft:white_wool
fill 472 279 302 473 279 303 minecraft:black_stained_glass
setblock 472 279 304 minecraft:white_wool
fill 472 279 305 472 279 306 minecraft:black_stained_glass
fill 472 279 307 472 279 308 minecraft:white_wool
fill 472 279 309 475 279 309 minecraft:black_stained_glass
fill 472 279 313 475 279 313 minecraft:black_stained_glass
fill 473 279 278 475 279 278 minecraft:black_stained_glass
fill 473 279 279 473 279 281 minecraft:white_wool
fill 473 279 282 475 279 283 minecraft:black_stained_glass
fill 473 279 286 476 279 286 minecraft:black_stained_glass
fill 473 279 287 473 279 288 minecraft:white_wool
fill 473 279 291 474 279 296 minecraft:black_stained_glass
fill 473 279 298 478 279 298 minecraft:black_stained_glass
fill 473 279 299 473 279 300 minecraft:white_wool
fill 473 279 301 476 279 301 minecraft:black_stained_glass
fill 473 279 304 474 279 305 minecraft:black_stained_glass
fill 473 279 306 474 279 307 minecraft:white_wool
fill 473 279 308 474 279 308 minecraft:black_stained_glass
setblock 474 279 279 minecraft:black_stained_glass
setblock 474 279 280 minecraft:white_wool
setblock 474 279 281 minecraft:black_stained_glass
fill 474 279 284 478 279 284 minecraft:black_stained_glass
setblock 474 279 285 minecraft:white_wool
fill 474 279 287 475 279 288 minecraft:black_stained_glass
fill 474 279 299 475 279 300 minecraft:black_stained_glass
setblock 474 279 302 minecraft:white_wool
fill 474 279 303 476 279 303 minecraft:black_stained_glass
setblock 475 279 279 minecraft:white_wool
fill 475 279 280 477 279 280 minecraft:black_stained_glass
setblock 475 279 281 minecraft:white_wool
fill 475 279 285 479 279 285 minecraft:black_stained_glass
fill 475 279 289 478 279 289 minecraft:black_stained_glass
fill 475 279 291 475 279 296 minecraft:white_wool
fill 475 279 297 484 279 297 minecraft:black_stained_glass
fill 475 279 302 478 279 302 minecraft:black_stained_glass
setblock 475 279 304 minecraft:black_stained_glass
fill 475 279 305 476 279 305 minecraft:white_wool
fill 475 279 306 476 279 307 minecraft:black_stained_glass
setblock 475 279 308 minecraft:white_wool
fill 475 279 314 476 279 315 minecraft:black_stained_glass
setblock 475 279 316 minecraft:white_wool
setblock 476 279 278 minecraft:white_wool
fill 476 279 279 482 279 279 minecraft:black_stained_glass
setblock 476 279 281 minecraft:black_stained_glass
setblock 476 279 282 minecraft:white_wool
setblock 476 279 283 minecraft:black_stained_glass
fill 476 279 287 479 279 287 minecraft:black_stained_glass
setblock 476 279 288 minecraft:white_wool
fill 476 279 290 478 279 290 minecraft:white_wool
fill 476 279 291 477 279 295 minecraft:black_stained_glass
fill 476 279 296 478 279 296 minecraft:white_wool
setblock 476 279 299 minecraft:white_wool
fill 476 279 300 479 279 300 minecraft:black_stained_glass
setblock 476 279 304 minecraft:white_wool
fill 476 279 308 478 279 308 minecraft:black_stained_glass
setblock 476 279 309 minecraft:white_wool
setblock 476 279 313 minecraft:white_wool
fill 476 279 316 478 279 316 minecraft:black_stained_glass
setblock 477 279 277 minecraft:white_wool
fill 477 279 278 480 279 278 minecraft:black_stained_glass
setblock 477 279 281 minecraft:white_wool
fill 477 279 282 484 279 282 minecraft:black_stained_glass
fill 477 279 283 479 279 283 minecraft:white_wool
setblock 477 279 286 minecraft:white_wool
fill 477 279 288 482 279 288 minecraft:black_stained_glass
fill 477 279 299 482 279 299 minecraft:black_stained_glass
setblock 477 279 301 minecraft:white_wool
fill 477 279 303 478 279 303 minecraft:white_wool
fill 477 279 304 478 279 305 minecraft:black_stained_glass
setblock 477 279 306 minecraft:white_wool
setblock 477 279 307 minecraft:black_stained_glass
fill 477 279 309 480 279 309 minecraft:black_stained_glass
setblock 477 279 310 minecraft:white_wool
fill 477 279 311 477 279 313 minecraft:black_stained_glass
setblock 477 279 314 minecraft:white_wool
fill 477 279 315 478 279 315 minecraft:black_stained_glass
fill 478 279 277 481 279 277 minecraft:black_stained_glass
setblock 478 279 280 minecraft:white_wool
fill 478 279 281 481 279 281 minecraft:black_stained_glass
fill 478 279 286 480 279 286 minecraft:black_stained_glass
fill 478 279 291 480 279 291 minecraft:black_stained_glass
fill 478 279 292 478 279 295 minecraft:white_wool
fill 478 279 301 479 279 301 minecraft:black_stained_glass
fill 478 279 306 483 279 306 minecraft:black_stained_glass
setblock 478 279 307 minecraft:white_wool
fill 478 279 310 481 279 310 minecraft:black_stained_glass
setblock 478 279 311 minecraft:white_wool
fill 478 279 312 479 279 314 minecraft:black_stained_glass
fill 479 279 280 483 279 280 minecraft:black_stained_glass
setblock 479 279 284 minecraft:white_wool
setblock 479 279 289 minecraft:white_wool
fill 479 279 290 484 279 290 minecraft:black_stained_glass
fill 479 279 292 480 279 296 minecraft:black_stained_glass
setblock 479 279 298 minecraft:white_wool
setblock 479 279 302 minecraft:white_wool
fill 479 279 303 484 279 303 minecraft:black_stained_glass
setblock 479 279 304 minecraft:white_wool
setblock 479 279 305 minecraft:black_stained_glass
fill 479 279 307 482 279 307 minecraft:black_stained_glass
setblock 479 279 308 minecraft:white_wool
fill 479 279 311 480 279 311 minecraft:black_stained_glass
fill 479 279 315 479 279 316 minecraft:white_wool
fill 480 279 283 482 279 284 minecraft:black_stained_glass
setblock 480 279 285 minecraft:white_wool
setblock 480 279 287 minecraft:white_wool
fill 480 279 289 481 279 289 minecraft:black_stained_glass
fill 480 279 298 481 279 298 minecraft:black_stained_glass
fill 480 279 300 480 279 301 minecraft:white_wool
fill 480 279 302 486 279 302 minecraft:black_stained_glass
fill 480 279 304 483 279 304 minecraft:black_stained_glass
setblock 480 279 305 minecraft:white_wool
fill 480 279 308 482 279 308 minecraft:black_stained_glass
fill 480 279 312 480 279 315 minecraft:white_wool
setblock 480 279 316 minecraft:black_stained_glass
setblock 481 279 278 minecraft:white_wool
fill 481 279 285 485 279 285 minecraft:black_stained_glass
setblock 481 279 286 minecraft:white_wool
fill 481 279 287 483 279 287 minecraft:black_stained_glass
fill 481 279 291 481 279 295 minecraft:white_wool
fill 481 279 296 486 279 296 minecraft:black_stained_glass
setblock 481 279 300 minecraft:white_wool
fill 481 279 301 484 279 301 minecraft:black_stained_glass
fill 481 279 305 483 279 305 minecraft:black_stained_glass
fill 481 279 309 482 279 309 minecraft:white_wool
fill 481 279 311 481 279 313 minecraft:white_wool
fill 481 279 314 484 279 315 minecraft:black_stained_glass
setblock 481 279 316 minecraft:white_wool
fill 482 279 276 482 279 277 minecraft:white_wool
setblock 482 279 278 minecraft:black_stained_glass
setblock 482 279 281 minecraft:white_wool
fill 482 279 286 484 279 286 minecraft:black_stained_glass
setblock 482 279 289 minecraft:white_wool
setblock 482 279 291 minecraft:white_wool
fill 482 279 292 483 279 294 minecraft:black_stained_glass
setblock 482 279 295 minecraft:white_wool
setblock 482 279 298 minecraft:white_wool
fill 482 279 300 483 279 300 minecraft:black_stained_glass
fill 482 279 310 483 279 310 minecraft:white_wool
fill 482 279 311 484 279 312 minecraft:black_stained_glass
setblock 482 279 313 minecraft:white_wool
fill 482 279 316 489 279 316 minecraft:black_stained_glass
fill 483 279 276 485 279 276 minecraft:black_stained_glass
fill 483 279 277 483 279 279 minecraft:white_wool
setblock 483 279 281 minecraft:black_stained_glass
setblock 483 279 283 minecraft:black_stained_glass
setblock 483 279 284 minecraft:white_wool
fill 483 279 288 484 279 288 minecraft:white_wool
fill 483 279 289 484 279 289 minecraft:black_stained_glass
fill 483 279 291 486 279 291 minecraft:black_stained_glass
setblock 483 279 295 minecraft:black_stained_glass
setblock 483 279 298 minecraft:black_stained_glass
setblock 483 279 299 minecraft:white_wool
fill 483 279 307 483 279 308 minecraft:white_wool
fill 483 279 309 489 279 309 minecraft:black_stained_glass
fill 483 279 313 489 279 313 minecraft:black_stained_glass
fill 484 279 277 485 279 279 minecraft:black_stained_glass
fill 484 279 280 484 279 281 minecraft:white_wool
fill 484 279 283 485 279 283 minecraft:white_wool
fill 484 279 284 489 279 284 minecraft:black_stained_glass
setblock 484 279 287 minecraft:white_wool
fill 484 279 292 484 279 295 minecraft:white_wool
setblock 484 279 298 minecraft:white_wool
fill 484 279 299 486 279 299 minecraft:black_stained_glass
setblock 484 279 300 minecraft:white_wool
fill 484 279 304 484 279 306 minecraft:white_wool
fill 484 279 307 484 279 308 minecraft:black_stained_glass
fill 484 279 310 489 279 310 minecraft:black_stained_glass
fill 485 279 280 489 279 281 minecraft:black_stained_glass
setblock 485 279 282 minecraft:white_wool
setblock 485 279 286 minecraft:white_wool
fill 485 279 287 486 279 288 minecraft:black_stained_glass
fill 485 279 289 485 279 290 minecraft:white_wool
fill 485 279 292 485 279 295 minecraft:black_stained_glass
setblock 485 279 297 minecraft:white_wool
setblock 485 279 298 minecraft:black_stained_glass
fill 485 279 300 489 279 300 minecraft:black_stained_glass
fill 485 279 301 486 279 301 minecraft:white_wool
fill 485 279 303 485 279 304 minecraft:white_wool
fill 485 279 305 485 279 307 minecraft:black_stained_glass
fill 485 279 308 486 279 308 minecraft:white_wool
fill 485 279 311 486 279 311 minecraft:white_wool
fill 485 279 312 489 279 312 minecraft:black_stained_glass
setblock 485 279 314 minecraft:white_wool
fill 485 279 315 489 279 315 minecraft:black_stained_glass
fill 486 279 276 488 279 276 minecraft:white_wool
fill 486 279 277 489 279 278 minecraft:black_stained_glass
fill 486 279 279 488 279 279 minecraft:white_wool
fill 486 279 282 486 279 283 minecraft:black_stained_glass
fill 486 279 285 488 279 285 minecraft:white_wool
fill 486 279 286 489 279 286 minecraft:black_stained_glass
setblock 486 279 289 minecraft:white_wool
setblock 486 279 290 minecraft:black_stained_glass
fill 486 279 292 486 279 294 minecraft:redstone_block
setblock 486 279 295 minecraft:black_stained_glass
fill 486 279 297 487 279 297 minecraft:black_stained_glass
setblock 486 279 298 minecraft:white_wool
fill 486 279 303 489 279 304 minecraft:black_stained_glass
setblock 486 279 305 minecraft:white_wool
fill 486 279 306 489 279 307 minecraft:black_stained_glass
fill 486 279 314 489 279 314 minecraft:black_stained_glass
fill 486 279 317 486 308 317 minecraft:deepslate_tiles
fill 487 279 282 488 279 282 minecraft:white_wool
fill 487 279 283 489 279 283 minecraft:black_stained_glass
setblock 487 279 287 minecraft:white_wool
fill 487 279 288 487 279 289 minecraft:black_stained_glass
fill 487 279 290 487 279 292 minecraft:redstone_block
fill 487 279 294 487 279 296 minecraft:redstone_block
fill 487 279 298 489 279 298 minecraft:black_stained_glass
setblock 487 279 299 minecraft:white_wool
fill 487 279 301 489 279 301 minecraft:black_stained_glass
setblock 487 279 302 minecraft:white_wool
fill 487 279 305 489 279 305 minecraft:black_stained_glass
fill 487 279 308 489 279 308 minecraft:black_stained_glass
fill 487 279 311 489 279 311 minecraft:black_stained_glass
fill 488 279 287 489 279 287 minecraft:black_stained_glass
fill 488 279 288 488 279 289 minecraft:white_wool
fill 488 279 290 489 279 290 minecraft:redstone_block
fill 488 279 296 489 279 296 minecraft:redstone_block
setblock 488 279 297 minecraft:white_wool
fill 488 279 299 489 279 299 minecraft:black_stained_glass
fill 488 279 302 489 279 302 minecraft:black_stained_glass
setblock 489 279 276 minecraft:black_stained_glass
setblock 489 279 279 minecraft:black_stained_glass
setblock 489 279 282 minecraft:black_stained_glass
setblock 489 279 285 minecraft:black_stained_glass
setblock 489 279 288 minecraft:black_stained_glass
fill 489 279 289 491 279 289 minecraft:redstone_block
fill 489 279 297 491 279 297 minecraft:redstone_block
fill 490 279 276 490 279 288 minecraft:white_wool
fill 490 279 298 490 279 316 minecraft:white_wool
fill 491 279 276 493 279 276 minecraft:white_wool
fill 491 279 277 495 279 278 minecraft:black_stained_glass
fill 491 279 279 493 279 279 minecraft:white_wool
fill 491 279 280 494 279 281 minecraft:black_stained_glass
fill 491 279 282 492 279 282 minecraft:white_wool
fill 491 279 283 494 279 284 minecraft:black_stained_glass
fill 491 279 285 492 279 285 minecraft:white_wool
fill 491 279 286 492 279 287 minecraft:black_stained_glass
setblock 491 279 288 minecraft:white_wool
fill 491 279 290 493 279 290 minecraft:redstone_block
fill 491 279 296 493 279 296 minecraft:redstone_block
fill 491 279 298 492 279 316 minecraft:black_stained_glass
fill 492 279 288 495 279 288 minecraft:black_stained_glass
fill 492 279 289 493 279 289 minecraft:white_wool
setblock 492 279 297 minecraft:white_wool
fill 493 279 282 494 279 282 minecraft:black_stained_glass
fill 493 279 285 493 279 286 minecraft:black_stained_glass
setblock 493 279 287 minecraft:white_wool
fill 493 279 291 493 279 292 minecraft:redstone_block
fill 493 279 294 493 279 295 minecraft:redstone_block
fill 493 279 297 494 279 298 minecraft:black_stained_glass
fill 493 279 299 494 279 299 minecraft:white_wool
fill 493 279 300 493 279 316 minecraft:black_stained_glass
fill 494 279 276 497 279 276 minecraft:black_stained_glass
fill 494 279 279 496 279 279 minecraft:black_stained_glass
fill 494 279 285 494 279 286 minecraft:white_wool
setblock 494 279 287 minecraft:black_stained_glass
setblock 494 279 289 minecraft:black_stained_glass
setblock 494 279 290 minecraft:white_wool
fill 494 279 291 497 279 291 minecraft:black_stained_glass
fill 494 279 292 494 279 294 minecraft:redstone_block
setblock 494 279 295 minecraft:white_wool
fill 494 279 296 499 279 296 minecraft:black_stained_glass
fill 494 279 300 498 279 300 minecraft:black_stained_glass
fill 494 279 301 494 279 302 minecraft:white_wool
fill 494 279 303 494 279 316 minecraft:black_stained_glass
fill 495 279 280 496 279 280 minecraft:white_wool
setblock 495 279 281 minecraft:black_stained_glass
fill 495 279 282 495 279 283 minecraft:white_wool
fill 495 279 284 495 279 286 minecraft:black_stained_glass
setblock 495 279 287 minecraft:white_wool
setblock 495 279 289 minecraft:white_wool
fill 495 279 290 496 279 290 minecraft:black_stained_glass
fill 495 279 292 496 279 295 minecraft:black_stained_glass
fill 495 279 297 496 279 298 minecraft:white_wool
fill 495 279 299 497 279 299 minecraft:black_stained_glass
fill 495 279 301 495 279 302 minecraft:black_stained_glass
fill 495 279 303 495 279 305 minecraft:white_wool
fill 495 279 306 495 279 307 minecraft:black_stained_glass
setblock 495 279 308 minecraft:white_wool
fill 495 279 309 497 279 310 minecraft:black_stained_glass
fill 495 279 311 496 279 311 minecraft:white_wool
fill 495 279 312 495 279 316 minecraft:black_stained_glass
setblock 496 279 277 minecraft:white_wool
setblock 496 279 278 minecraft:black_stained_glass
fill 496 279 281 497 279 281 minecraft:white_wool
fill 496 279 282 501 279 283 minecraft:black_stained_glass
setblock 496 279 284 minecraft:white_wool
fill 496 279 285 497 279 287 minecraft:black_stained_glass
setblock 496 279 288 minecraft:white_wool
fill 496 279 289 499 279 289 minecraft:black_stained_glass
setblock 496 279 301 minecraft:white_wool
fill 496 279 302 496 279 304 minecraft:black_stained_glass
fill 496 279 305 496 279 306 minecraft:white_wool
fill 496 279 307 496 279 308 minecraft:black_stained_glass
fill 496 279 312 498 279 313 minecraft:black_stained_glass
setblock 496 279 314 minecraft:white_wool
fill 496 279 315 499 279 316 minecraft:black_stained_glass
setblock 497 279 277 minecraft:black_stained_glass
fill 497 279 278 497 279 279 minecraft:white_wool
fill 497 279 280 500 279 280 minecraft:black_stained_glass
fill 497 279 284 500 279 284 minecraft:black_stained_glass
fill 497 279 288 505 279 288 minecraft:black_stained_glass
setblock 497 279 290 minecraft:white_wool
fill 497 279 292 511 279 294 minecraft:black_stained_glass
fill 497 279 295 500 279 295 minecraft:white_wool
fill 497 279 297 498 279 298 minecraft:black_stained_glass
fill 497 279 301 499 279 303 minecraft:black_stained_glass
setblock 497 279 304 minecraft:white_wool
fill 497 279 305 500 279 306 minecraft:black_stained_glass
fill 497 279 307 497 279 308 minecraft:white_wool
fill 497 279 311 498 279 311 minecraft:black_stained_glass
fill 497 279 314 499 279 314 minecraft:black_stained_glass
fill 498 279 276 498 279 278 minecraft:white_wool
fill 498 279 279 503 279 279 minecraft:black_stained_glass
fill 498 279 281 501 279 281 minecraft:black_stained_glass
fill 498 279 285 499 279 285 minecraft:black_stained_glass
fill 498 279 286 499 279 286 minecraft:white_wool
setblock 498 279 287 minecraft:black_stained_glass
fill 498 279 290 499 279 290 minecraft:black_stained_glass
fill 498 279 291 499 279 291 minecraft:white_wool
setblock 498 279 299 minecraft:white_wool
fill 498 279 304 501 279 304 minecraft:black_stained_glass
setblock 498 279 307 minecraft:white_wool
fill 498 279 308 501 279 308 minecraft:black_stained_glass
fill 498 279 309 498 279 310 minecraft:white_wool
fill 499 279 276 501 279 278 minecraft:black_stained_glass
setblock 499 279 287 minecraft:white_wool
fill 499 279 297 505 279 297 minecraft:black_stained_glass
setblock 499 279 298 minecraft:white_wool
fill 499 279 299 501 279 299 minecraft:black_stained_glass
setblock 499 279 300 minecraft:white_wool
fill 499 279 307 502 279 307 minecraft:black_stained_glass
fill 499 279 309 499 279 310 minecraft:black_stained_glass
fill 499 279 311 499 279 313 minecraft:white_wool
fill 500 279 285 501 279 285 minecraft:white_wool
fill 500 279 286 501 279 287 minecraft:black_stained_glass
fill 500 279 289 500 279 290 minecraft:white_wool
fill 500 279 291 511 279 291 minecraft:black_stained_glass
setblock 500 279 296 minecraft:white_wool
fill 500 279 298 509 279 298 minecraft:black_stained_glass
setblock 500 279 300 minecraft:black_stained_glass
setblock 500 279 301 minecraft:white_wool
fill 500 279 302 500 279 303 minecraft:black_stained_glass
setblock 500 279 309 minecraft:white_wool
fill 500 279 310 500 279 312 minecraft:black_stained_glass
fill 500 279 313 500 279 316 minecraft:white_wool
setblock 501 279 280 minecraft:white_wool
setblock 501 279 284 minecraft:white_wool
fill 501 279 289 501 279 290 minecraft:black_stained_glass
fill 501 279 295 501 279 296 minecraft:black_stained_glass
setblock 501 279 300 minecraft:white_wool
fill 501 279 301 503 279 301 minecraft:black_stained_glass
setblock 501 279 302 minecraft:white_wool
setblock 501 279 303 minecraft:black_stained_glass
setblock 501 279 305 minecraft:white_wool
fill 501 279 306 503 279 306 minecraft:black_stained_glass
fill 501 279 309 502 279 311 minecraft:black_stained_glass
setblock 501 279 312 minecraft:white_wool
fill 501 279 313 503 279 314 minecraft:black_stained_glass
fill 501 279 315 501 279 316 minecraft:white_wool
fill 502 279 276 510 279 276 minecraft:black_stained_glass
setblock 502 279 277 minecraft:white_wool
setblock 502 279 278 minecraft:black_stained_glass
fill 502 279 280 504 279 280 minecraft:black_stained_glass
setblock 502 279 281 minecraft:white_wool
setblock 502 279 282 minecraft:black_stained_glass
fill 502 279 283 503 279 283 minecraft:white_wool
fill 502 279 284 503 279 285 minecraft:black_stained_glass
setblock 502 279 286 minecraft:white_wool
fill 502 279 287 511 279 287 minecraft:black_stained_glass
setblock 502 279 289 minecraft:black_stained_glass
fill 502 279 290 504 279 290 minecraft:white_wool
fill 502 279 295 511 279 295 minecraft:black_stained_glass
fill 502 279 296 504 279 296 minecraft:white_wool
setblock 502 279 299 minecraft:white_wool
fill 502 279 300 507 279 300 minecraft:black_stained_glass
fill 502 279 302 506 279 302 minecraft:black_stained_glass
fill 502 279 303 502 279 304 minecraft:white_wool
fill 502 279 305 504 279 305 minecraft:black_stained_glass
setblock 502 279 308 minecraft:white_wool
fill 502 279 312 510 279 312 minecraft:black_stained_glass
setblock 502 279 315 minecraft:white_wool
fill 502 279 316 505 279 316 minecraft:black_stained_glass
fill 503 279 277 508 279 277 minecraft:black_stained_glass
setblock 503 279 278 minecraft:white_wool
fill 503 279 281 504 279 281 minecraft:black_stained_glass
fill 503 279 282 504 279 282 minecraft:white_wool
fill 503 279 286 504 279 286 minecraft:black_stained_glass
setblock 503 279 289 minecraft:white_wool
fill 503 279 299 504 279 299 minecraft:black_stained_glass
setblock 503 279 303 minecraft:white_wool
setblock 503 279 304 minecraft:black_stained_glass
setblock 503 279 307 minecraft:white_wool
fill 503 279 308 503 279 310 minecraft:black_stained_glass
setblock 503 279 311 minecraft:white_wool
fill 503 279 315 511 279 315 minecraft:black_stained_glass
fill 504 279 278 506 279 278 minecraft:black_stained_glass
setblock 504 279 279 minecraft:white_wool
fill 504 279 283 506 279 283 minecraft:black_stained_glass
setblock 504 279 284 minecraft:white_wool
fill 504 279 285 507 279 285 minecraft:black_stained_glass
fill 504 279 289 505 279 289 minecraft:black_stained_glass
setblock 504 279 301 minecraft:white_wool
fill 504 279 303 509 279 303 minecraft:black_stained_glass
setblock 504 279 304 minecraft:white_wool
setblock 504 279 306 minecraft:white_wool
fill 504 279 307 504 279 309 minecraft:black_stained_glass
setblock 504 279 310 minecraft:white_wool
fill 504 279 311 511 279 311 minecraft:black_stained_glass
setblock 504 279 313 minecraft:black_stained_glass
setblock 504 279 314 minecraft:white_wool
fill 505 279 279 506 279 279 minecraft:black_stained_glass
fill 505 279 280 506 279 281 minecraft:white_wool
fill 505 279 282 509 279 282 minecraft:black_stained_glass
fill 505 279 284 510 279 284 minecraft:black_stained_glass
setblock 505 279 286 minecraft:white_wool
fill 505 279 290 511 279 290 minecraft:black_stained_glass
setblock 505 279 296 minecraft:black_stained_glass
setblock 505 279 299 minecraft:white_wool
fill 505 279 301 510 279 301 minecraft:black_stained_glass
setblock 505 279 304 minecraft:black_stained_glass
setblock 505 279 305 minecraft:white_wool
fill 505 279 306 505 279 308 minecraft:black_stained_glass
setblock 505 279 309 minecraft:white_wool
fill 505 279 310 510 279 310 minecraft:black_stained_glass
setblock 505 279 313 minecraft:white_wool
fill 505 279 314 508 279 314 minecraft:black_stained_glass
fill 506 279 286 511 279 286 minecraft:black_stained_glass
fill 506 279 288 506 279 289 minecraft:white_wool
fill 506 279 296 506 279 297 minecraft:white_wool
fill 506 279 299 511 279 299 minecraft:black_stained_glass
setblock 506 279 304 minecraft:white_wool
fill 506 279 305 511 279 305 minecraft:black_stained_glass
fill 506 279 306 508 279 306 minecraft:white_wool
setblock 506 279 307 minecraft:black_stained_glass
setblock 506 279 308 minecraft:white_wool
fill 506 279 309 508 279 309 minecraft:black_stained_glass
fill 506 279 313 509 279 313 minecraft:black_stained_glass
setblock 506 279 316 minecraft:white_wool
fill 507 279 278 507 279 280 minecraft:white_wool
fill 507 279 281 511 279 281 minecraft:black_stained_glass
setblock 507 279 283 minecraft:white_wool
fill 507 279 288 508 279 288 minecraft:black_stained_glass
fill 507 279 289 509 279 289 minecraft:white_wool
fill 507 279 296 508 279 296 minecraft:black_stained_glass
fill 507 279 297 509 279 297 minecraft:white_wool
setblock 507 279 302 minecraft:white_wool
fill 507 279 304 511 279 304 minecraft:black_stained_glass
fill 507 279 307 508 279 307 minecraft:white_wool
setblock 507 279 308 minecraft:black_stained_glass
fill 507 279 316 510 279 316 minecraft:black_stained_glass
fill 508 279 278 508 279 279 minecraft:white_wool
fill 508 279 280 511 279 280 minecraft:black_stained_glass
fill 508 279 283 511 279 283 minecraft:black_stained_glass
setblock 508 279 285 minecraft:white_wool
setblock 508 279 300 minecraft:white_wool
fill 508 279 302 511 279 302 minecraft:black_stained_glass
fill 508 279 308 510 279 308 minecraft:white_wool
fill 509 279 277 509 279 278 minecraft:white_wool
fill 509 279 279 511 279 279 minecraft:black_stained_glass
fill 509 279 285 510 279 285 minecraft:black_stained_glass
fill 509 279 288 511 279 288 minecraft:white_wool
setblock 509 279 296 minecraft:white_wool
fill 509 279 300 510 279 300 minecraft:black_stained_glass
fill 509 279 306 510 279 307 minecraft:black_stained_glass
fill 509 279 309 511 279 309 minecraft:white_wool
setblock 509 279 314 minecraft:white_wool
fill 510 279 277 511 279 277 minecraft:white_wool
setblock 510 279 278 minecraft:black_stained_glass
setblock 510 279 282 minecraft:white_wool
fill 510 279 289 511 279 289 minecraft:black_stained_glass
fill 510 279 296 511 279 297 minecraft:black_stained_glass
fill 510 279 298 511 279 298 minecraft:white_wool
setblock 510 279 303 minecraft:white_wool
setblock 510 279 313 minecraft:white_wool
fill 510 279 314 511 279 314 minecraft:black_stained_glass
setblock 511 279 276 minecraft:white_wool
setblock 511 279 278 minecraft:white_wool
setblock 511 279 282 minecraft:black_stained_glass
fill 511 279 284 511 279 285 minecraft:white_wool
fill 511 279 300 511 279 301 minecraft:white_wool
setblock 511 279 303 minecraft:black_stained_glass
setblock 511 279 306 minecraft:black_stained_glass
setblock 511 279 307 minecraft:white_wool
setblock 511 279 308 minecraft:black_stained_glass
setblock 511 279 310 minecraft:white_wool
setblock 511 279 312 minecraft:white_wool
setblock 511 279 313 minecraft:black_stained_glass
setblock 511 279 316 minecraft:white_wool
fill 512 279 313 512 308 313 minecraft:deepslate_tiles
setblock 512 279 314 minecraft:white_wool
fill 512 280 314 512 308 314 minecraft:deepslate_tiles
setblock 471 283 279 minecraft:deepslate_tiles
setblock 471 283 280 minecraft:cobbled_deepslate
fill 471 283 281 471 283 284 minecraft:deepslate_tiles
setblock 471 283 285 minecraft:cobbled_deepslate
fill 471 283 286 471 283 289 minecraft:deepslate_tiles
setblock 471 283 290 minecraft:cobbled_deepslate
fill 471 283 291 471 283 292 minecraft:deepslate_tiles
fill 471 283 294 473 284 294 minecraft:cobbled_deepslate
fill 471 283 301 471 283 304 minecraft:deepslate_tiles
setblock 471 283 305 minecraft:cobbled_deepslate
fill 471 283 306 471 283 307 minecraft:deepslate_tiles
fill 472 283 282 472 283 283 minecraft:deepslate_tiles
setblock 472 283 284 minecraft:cobbled_deepslate
fill 472 283 285 472 283 288 minecraft:deepslate_tiles
fill 472 283 293 472 284 293 minecraft:cobbled_deepslate
fill 472 283 295 472 284 295 minecraft:cobbled_deepslate
setblock 473 283 278 minecraft:light[level=12]
setblock 473 283 285 minecraft:light[level=12]
setblock 473 283 292 minecraft:light[level=12]
setblock 473 283 299 minecraft:light[level=12]
setblock 473 283 306 minecraft:light[level=12]
setblock 473 283 313 minecraft:light[level=12]
fill 477 283 276 479 283 276 minecraft:deepslate_tiles
setblock 479 283 277 minecraft:cobbled_deepslate
setblock 480 283 276 minecraft:cobbled_deepslate
fill 480 283 277 482 283 278 minecraft:deepslate_tiles
setblock 480 283 285 minecraft:light[level=12]
setblock 480 283 292 minecraft:light[level=12]
setblock 480 283 299 minecraft:light[level=12]
setblock 480 283 306 minecraft:light[level=12]
setblock 480 283 313 minecraft:light[level=12]
setblock 480 283 316 minecraft:cobbled_deepslate
fill 481 283 276 484 283 276 minecraft:deepslate_tiles
fill 481 283 316 484 283 316 minecraft:deepslate_tiles
setblock 483 283 277 minecraft:deepslate_tiles
setblock 483 283 278 minecraft:cobbled_deepslate
fill 483 283 315 485 283 315 minecraft:deepslate_tiles
setblock 484 283 277 minecraft:cobbled_deepslate
fill 484 283 278 486 283 278 minecraft:deepslate_tiles
setblock 485 283 276 minecraft:cobbled_deepslate
fill 485 283 277 488 283 277 minecraft:deepslate_tiles
setblock 485 283 316 minecraft:cobbled_deepslate
fill 486 283 276 489 283 276 minecraft:deepslate_tiles
setblock 486 283 315 minecraft:cobbled_deepslate
fill 486 283 316 489 283 316 minecraft:deepslate_tiles
setblock 487 283 278 minecraft:light[level=12]
setblock 487 283 285 minecraft:light[level=12]
setblock 487 283 292 minecraft:light[level=12]
setblock 487 283 299 minecraft:light[level=12]
setblock 487 283 306 minecraft:light[level=12]
setblock 487 283 313 minecraft:light[level=12]
setblock 490 283 276 minecraft:cobbled_deepslate
fill 490 283 278 490 290 278 minecraft:white_wool
setblock 490 283 316 minecraft:cobbled_deepslate
setblock 494 283 278 minecraft:light[level=12]
setblock 494 283 285 minecraft:light[level=12]
setblock 494 283 292 minecraft:light[level=12]
setblock 494 283 299 minecraft:light[level=12]
setblock 494 283 306 minecraft:light[level=12]
setblock 494 283 313 minecraft:light[level=12]
fill 498 283 316 499 283 316 minecraft:deepslate_tiles
fill 500 283 305 500 284 305 minecraft:white_wool
setblock 500 283 316 minecraft:cobbled_deepslate
setblock 501 283 278 minecraft:light[level=12]
setblock 501 283 285 minecraft:light[level=12]
setblock 501 283 292 minecraft:light[level=12]
setblock 501 283 299 minecraft:light[level=12]
setblock 501 283 306 minecraft:light[level=12]
setblock 501 283 313 minecraft:light[level=12]
setblock 501 283 315 minecraft:cobbled_deepslate
fill 501 283 316 504 283 316 minecraft:deepslate_tiles
fill 502 283 276 504 283 276 minecraft:deepslate_tiles
fill 502 283 315 504 283 315 minecraft:deepslate_tiles
fill 504 283 282 504 294 282 minecraft:white_wool
setblock 505 283 316 minecraft:cobbled_deepslate
setblock 506 283 316 minecraft:deepslate_tiles
setblock 508 283 278 minecraft:light[level=12]
setblock 508 283 285 minecraft:light[level=12]
setblock 508 283 292 minecraft:light[level=12]
setblock 508 283 299 minecraft:light[level=12]
setblock 508 283 306 minecraft:light[level=12]
setblock 508 283 313 minecraft:light[level=12]
setblock 509 283 302 minecraft:cobbled_deepslate
fill 509 283 303 509 283 306 minecraft:deepslate_tiles
setblock 509 283 307 minecraft:cobbled_deepslate
fill 510 283 284 510 283 285 minecraft:deepslate_tiles
setblock 510 283 286 minecraft:cobbled_deepslate
fill 510 283 287 511 283 287 minecraft:deepslate_tiles
setblock 510 283 300 minecraft:deepslate_tiles
setblock 510 283 301 minecraft:cobbled_deepslate
fill 510 283 302 510 283 305 minecraft:deepslate_tiles
setblock 510 283 306 minecraft:cobbled_deepslate
fill 510 283 307 511 283 309 minecraft:deepslate_tiles
fill 511 283 281 511 283 284 minecraft:deepslate_tiles
setblock 511 283 285 minecraft:cobbled_deepslate
fill 511 283 286 511 286 286 minecraft:deepslate_tiles
fill 511 283 288 511 283 289 minecraft:deepslate_tiles
setblock 511 283 290 minecraft:cobbled_deepslate
fill 511 283 291 511 283 292 minecraft:deepslate_tiles
fill 511 283 297 511 283 299 minecraft:deepslate_tiles
setblock 511 283 300 minecraft:cobbled_deepslate
fill 511 283 301 511 283 304 minecraft:deepslate_tiles
setblock 511 283 305 minecraft:cobbled_deepslate
fill 511 283 306 511 286 306 minecraft:deepslate_tiles
setblock 511 283 310 minecraft:cobbled_deepslate
fill 471 284 280 471 284 283 minecraft:deepslate_tiles
setblock 471 284 284 minecraft:cobbled_deepslate
fill 471 284 285 471 284 288 minecraft:deepslate_tiles
setblock 471 284 289 minecraft:cobbled_deepslate
fill 471 284 290 471 286 291 minecraft:deepslate_tiles
setblock 471 284 293 minecraft:cobbled_deepslate
setblock 471 284 295 minecraft:cobbled_deepslate
setblock 472 284 283 minecraft:cobbled_deepslate
fill 472 284 284 472 284 287 minecraft:deepslate_tiles
setblock 472 284 288 minecraft:cobbled_deepslate
setblock 473 284 293 minecraft:cobbled_deepslate
setblock 473 284 295 minecraft:cobbled_deepslate
setblock 478 284 276 minecraft:deepslate_tiles
setblock 479 284 276 minecraft:cobbled_deepslate
fill 479 284 277 482 284 277 minecraft:deepslate_tiles
fill 480 284 276 483 284 276 minecraft:deepslate_tiles
fill 480 284 316 483 284 316 minecraft:deepslate_tiles
setblock 482 284 278 minecraft:cobbled_deepslate
setblock 483 284 277 minecraft:cobbled_deepslate
fill 483 284 278 484 284 278 minecraft:deepslate_tiles
fill 483 284 315 484 284 315 minecraft:deepslate_tiles
setblock 484 284 276 minecraft:cobbled_deepslate
fill 484 284 277 486 284 277 minecraft:deepslate_tiles
setblock 484 284 316 minecraft:cobbled_deepslate
fill 485 284 276 488 284 276 minecraft:deepslate_tiles
setblock 485 284 315 minecraft:cobbled_deepslate
fill 485 284 316 488 284 316 minecraft:deepslate_tiles
setblock 489 284 316 minecraft:cobbled_deepslate
setblock 498 284 316 minecraft:deepslate_tiles
setblock 499 284 316 minecraft:cobbled_deepslate
fill 500 284 316 503 284 316 minecraft:deepslate_tiles
fill 501 284 315 502 284 315 minecraft:deepslate_tiles
fill 502 284 280 502 288 280 minecraft:cobbled_deepslate
setblock 504 284 316 minecraft:cobbled_deepslate
setblock 505 284 316 minecraft:deepslate_tiles
fill 510 284 302 510 284 304 minecraft:deepslate_tiles
setblock 510 284 305 minecraft:cobbled_deepslate
fill 510 284 306 510 284 308 minecraft:deepslate_tiles
setblock 511 284 283 minecraft:deepslate_tiles
setblock 511 284 284 minecraft:cobbled_deepslate
fill 511 284 285 511 287 285 minecraft:deepslate_tiles
fill 511 284 287 511 284 288 minecraft:deepslate_tiles
setblock 511 284 289 minecraft:cobbled_deepslate
fill 511 284 290 511 286 291 minecraft:deepslate_tiles
fill 511 284 300 511 284 303 minecraft:deepslate_tiles
setblock 511 284 304 minecraft:cobbled_deepslate
fill 511 284 305 511 286 305 minecraft:deepslate_tiles
fill 511 284 307 511 284 308 minecraft:deepslate_tiles
setblock 511 284 309 minecraft:cobbled_deepslate
setblock 511 284 310 minecraft:deepslate_tiles
setblock 470 285 303 minecraft:white_wool
fill 471 285 281 471 285 282 minecraft:deepslate_tiles
setblock 471 285 283 minecraft:cobbled_deepslate
fill 471 285 284 471 285 287 minecraft:deepslate_tiles
setblock 471 285 288 minecraft:cobbled_deepslate
fill 471 285 289 471 288 289 minecraft:deepslate_tiles
setblock 472 285 275 minecraft:white_wool
fill 472 285 284 472 285 286 minecraft:deepslate_tiles
setblock 472 285 287 minecraft:cobbled_deepslate
fill 472 285 288 472 288 288 minecraft:deepslate_tiles
setblock 473 285 278 minecraft:light[level=13]
setblock 473 285 286 minecraft:light[level=13]
setblock 473 285 294 minecraft:light[level=13]
setblock 473 285 302 minecraft:light[level=13]
setblock 473 285 310 minecraft:light[level=13]
setblock 475 285 279 minecraft:white_wool
setblock 476 285 278 minecraft:white_wool
setblock 477 285 277 minecraft:white_wool
setblock 478 285 276 minecraft:white_wool
fill 479 285 276 482 285 276 minecraft:deepslate_tiles
fill 480 285 277 481 285 277 minecraft:deepslate_tiles
fill 480 285 316 482 285 316 minecraft:deepslate_tiles
setblock 481 285 278 minecraft:light[level=13]
setblock 481 285 286 minecraft:light[level=13]
setblock 481 285 294 minecraft:light[level=13]
setblock 481 285 302 minecraft:light[level=13]
setblock 481 285 310 minecraft:light[level=13]
setblock 482 285 277 minecraft:cobbled_deepslate
setblock 483 285 276 minecraft:cobbled_deepslate
fill 483 285 277 485 285 277 minecraft:deepslate_tiles
setblock 483 285 315 minecraft:deepslate_tiles
setblock 483 285 316 minecraft:cobbled_deepslate
fill 484 285 276 487 285 276 minecraft:deepslate_tiles
setblock 484 285 315 minecraft:cobbled_deepslate
fill 484 285 316 487 285 316 minecraft:deepslate_tiles
fill 486 285 277 486 287 278 minecraft:cobbled_deepslate
fill 487 285 277 487 287 277 minecraft:cobbled_deepslate
setblock 488 285 316 minecraft:cobbled_deepslate
setblock 489 285 278 minecraft:light[level=13]
setblock 489 285 286 minecraft:light[level=13]
setblock 489 285 294 minecraft:light[level=13]
setblock 489 285 302 minecraft:light[level=13]
setblock 489 285 310 minecraft:light[level=13]
setblock 497 285 278 minecraft:light[level=13]
setblock 497 285 286 minecraft:light[level=13]
setblock 497 285 294 minecraft:light[level=13]
setblock 497 285 302 minecraft:light[level=13]
setblock 497 285 310 minecraft:light[level=13]
setblock 498 285 316 minecraft:cobbled_deepslate
fill 499 285 316 502 285 316 minecraft:deepslate_tiles
setblock 503 285 316 minecraft:cobbled_deepslate
fill 504 285 316 504 286 316 minecraft:deepslate_tiles
setblock 505 285 278 minecraft:light[level=13]
setblock 505 285 286 minecraft:light[level=13]
setblock 505 285 294 minecraft:light[level=13]
setblock 505 285 302 minecraft:light[level=13]
setblock 505 285 310 minecraft:light[level=13]
fill 511 285 284 511 286 284 minecraft:deepslate_tiles
setblock 511 285 287 minecraft:deepslate_tiles
setblock 511 285 288 minecraft:cobbled_deepslate
fill 511 285 289 511 288 289 minecraft:deepslate_tiles
setblock 511 285 302 minecraft:deepslate_tiles
setblock 511 285 303 minecraft:cobbled_deepslate
setblock 511 285 304 minecraft:deepslate_tiles
setblock 511 285 307 minecraft:deepslate_tiles
setblock 511 285 308 minecraft:cobbled_deepslate
setblock 511 285 309 minecraft:deepslate_tiles
setblock 512 285 296 minecraft:redstone_block
setblock 512 285 305 minecraft:white_wool
fill 470 286 303 470 308 303 minecraft:deepslate_tiles
setblock 471 286 282 minecraft:cobbled_deepslate
setblock 471 286 283 minecraft:white_wool
fill 471 286 284 471 286 286 minecraft:deepslate_tiles
setblock 471 286 287 minecraft:cobbled_deepslate
fill 471 286 288 471 289 288 minecraft:deepslate_tiles
fill 472 286 275 472 308 275 minecraft:deepslate_tiles
setblock 472 286 282 minecraft:white_wool
setblock 472 286 285 minecraft:deepslate_tiles
setblock 472 286 286 minecraft:cobbled_deepslate
fill 472 286 287 472 289 287 minecraft:deepslate_tiles
setblock 473 286 281 minecraft:white_wool
setblock 474 286 280 minecraft:white_wool
setblock 477 286 276 minecraft:cobbled_deepslate
fill 478 286 276 481 286 276 minecraft:deepslate_tiles
fill 478 286 317 478 308 317 minecraft:deepslate_tiles
fill 479 286 316 481 286 316 minecraft:deepslate_tiles
setblock 479 286 317 minecraft:white_wool
setblock 480 286 277 minecraft:deepslate_tiles
setblock 481 286 277 minecraft:cobbled_deepslate
setblock 482 286 276 minecraft:cobbled_deepslate
fill 482 286 277 483 286 277 minecraft:deepslate_tiles
setblock 482 286 315 minecraft:deepslate_tiles
setblock 482 286 316 minecraft:cobbled_deepslate
fill 483 286 276 486 286 276 minecraft:deepslate_tiles
setblock 483 286 315 minecraft:cobbled_deepslate
fill 483 286 316 486 286 316 minecraft:deepslate_tiles
fill 484 286 315 484 289 315 minecraft:deepslate_tiles
fill 485 286 277 485 287 277 minecraft:cobbled_deepslate
setblock 487 286 316 minecraft:cobbled_deepslate
fill 488 286 316 488 289 316 minecraft:deepslate_tiles
setblock 497 286 316 minecraft:cobbled_deepslate
fill 498 286 316 501 286 316 minecraft:deepslate_tiles
fill 500 286 315 501 287 315 minecraft:deepslate_tiles
setblock 501 286 317 minecraft:white_wool
setblock 502 286 316 minecraft:cobbled_deepslate
fill 503 286 316 503 289 316 minecraft:deepslate_tiles
setblock 511 286 287 minecraft:cobbled_deepslate
fill 511 286 288 511 289 288 minecraft:deepslate_tiles
setblock 511 286 292 minecraft:cobbled_deepslate
setblock 511 286 307 minecraft:cobbled_deepslate
setblock 511 286 308 minecraft:deepslate_tiles
setblock 512 286 279 minecraft:redstone_block
fill 512 286 296 512 308 296 minecraft:deepslate_tiles
fill 512 286 305 512 308 305 minecraft:deepslate_tiles
setblock 512 286 307 minecraft:white_wool
fill 471 287 283 471 287 285 minecraft:deepslate_tiles
setblock 471 287 286 minecraft:cobbled_deepslate
fill 471 287 287 471 290 287 minecraft:deepslate_tiles
setblock 471 287 290 minecraft:deepslate_tiles
setblock 471 287 291 minecraft:cobbled_deepslate
fill 472 287 286 472 290 286 minecraft:deepslate_tiles
fill 477 287 276 480 287 276 minecraft:deepslate_tiles
fill 478 287 316 480 287 316 minecraft:deepslate_tiles
fill 479 287 317 479 308 317 minecraft:deepslate_tiles
setblock 480 287 277 minecraft:cobbled_deepslate
fill 480 287 315 481 287 315 minecraft:deepslate_tiles
setblock 481 287 276 minecraft:cobbled_deepslate
fill 481 287 277 482 289 277 minecraft:deepslate_tiles
setblock 481 287 316 minecraft:cobbled_deepslate
fill 482 287 276 485 287 276 minecraft:deepslate_tiles
setblock 482 287 315 minecraft:cobbled_deepslate
fill 482 287 316 485 287 316 minecraft:deepslate_tiles
fill 483 287 315 483 290 315 minecraft:deepslate_tiles
fill 485 287 315 485 288 315 minecraft:deepslate_tiles
setblock 486 287 276 minecraft:cobbled_deepslate
setblock 486 287 316 minecraft:cobbled_deepslate
fill 487 287 316 487 290 316 minecraft:deepslate_tiles
setblock 496 287 316 minecraft:cobbled_deepslate
fill 497 287 316 500 287 316 minecraft:deepslate_tiles
fill 499 287 315 499 289 315 minecraft:deepslate_tiles
fill 501 287 280 501 288 280 minecraft:cobbled_deepslate
setblock 501 287 316 minecraft:cobbled_deepslate
fill 501 287 317 501 308 317 minecraft:deepslate_tiles
fill 502 287 279 502 288 279 minecraft:cobbled_deepslate
fill 502 287 281 502 288 281 minecraft:cobbled_deepslate
fill 502 287 316 502 290 316 minecraft:deepslate_tiles
fill 503 287 280 503 288 280 minecraft:cobbled_deepslate
setblock 511 287 286 minecraft:cobbled_deepslate
fill 511 287 287 511 290 287 minecraft:deepslate_tiles
setblock 511 287 290 minecraft:deepslate_tiles
setblock 511 287 291 minecraft:cobbled_deepslate
fill 511 287 292 511 290 292 minecraft:deepslate_tiles
fill 512 287 279 512 308 279 minecraft:deepslate_tiles
fill 512 287 307 512 295 307 minecraft:deepslate_tiles
fill 471 288 283 471 288 284 minecraft:deepslate_tiles
setblock 471 288 285 minecraft:cobbled_deepslate
fill 471 288 286 471 291 286 minecraft:deepslate_tiles
setblock 471 288 290 minecraft:cobbled_deepslate
fill 471 288 291 471 290 292 minecraft:deepslate_tiles
setblock 472 288 289 minecraft:cobbled_deepslate
fill 476 288 276 479 288 276 minecraft:deepslate_tiles
fill 477 288 316 479 288 316 minecraft:deepslate_tiles
setblock 479 288 277 minecraft:cobbled_deepslate
fill 479 288 315 480 288 315 minecraft:deepslate_tiles
setblock 480 288 276 minecraft:cobbled_deepslate
fill 480 288 277 480 291 277 minecraft:deepslate_tiles
setblock 480 288 316 minecraft:cobbled_deepslate
fill 481 288 276 484 288 276 minecraft:deepslate_tiles
setblock 481 288 315 minecraft:cobbled_deepslate
fill 481 288 316 484 288 316 minecraft:deepslate_tiles
fill 482 288 315 482 291 315 minecraft:deepslate_tiles
setblock 485 288 276 minecraft:cobbled_deepslate
setblock 485 288 316 minecraft:cobbled_deepslate
fill 486 288 316 486 291 316 minecraft:deepslate_tiles
setblock 494 288 316 minecraft:deepslate_tiles
setblock 495 288 316 minecraft:cobbled_deepslate
fill 496 288 316 499 288 316 minecraft:deepslate_tiles
fill 497 288 315 498 290 315 minecraft:deepslate_tiles
setblock 500 288 315 minecraft:deepslate_tiles
setblock 500 288 316 minecraft:cobbled_deepslate
setblock 501 288 279 minecraft:cobbled_deepslate
setblock 501 288 281 minecraft:cobbled_deepslate
setblock 501 288 315 minecraft:cobbled_deepslate
fill 501 288 316 501 291 316 minecraft:deepslate_tiles
fill 502 288 315 502 291 315 minecraft:deepslate_tiles
setblock 503 288 279 minecraft:cobbled_deepslate
setblock 503 288 281 minecraft:cobbled_deepslate
setblock 511 288 285 minecraft:cobbled_deepslate
fill 511 288 286 511 291 286 minecraft:deepslate_tiles
setblock 511 288 290 minecraft:cobbled_deepslate
fill 511 288 291 511 291 291 minecraft:deepslate_tiles
fill 511 288 293 511 289 293 minecraft:deepslate_tiles
setblock 471 289 283 minecraft:deepslate_tiles
setblock 471 289 284 minecraft:cobbled_deepslate
fill 471 289 285 472 291 285 minecraft:deepslate_tiles
setblock 471 289 289 minecraft:cobbled_deepslate
fill 471 289 290 472 291 290 minecraft:deepslate_tiles
setblock 471 289 293 minecraft:deepslate_tiles
setblock 472 289 288 minecraft:cobbled_deepslate
fill 472 289 289 472 292 289 minecraft:deepslate_tiles
setblock 473 289 278 minecraft:light[level=12]
setblock 473 289 285 minecraft:light[level=12]
setblock 473 289 292 minecraft:light[level=12]
setblock 473 289 299 minecraft:light[level=12]
setblock 473 289 306 minecraft:light[level=12]
setblock 473 289 313 minecraft:light[level=12]
fill 475 289 276 478 289 276 minecraft:deepslate_tiles
fill 476 289 316 478 289 316 minecraft:deepslate_tiles
fill 477 289 315 479 289 315 minecraft:deepslate_tiles
setblock 478 289 277 minecraft:cobbled_deepslate
setblock 479 289 276 minecraft:cobbled_deepslate
fill 479 289 277 479 292 277 minecraft:deepslate_tiles
setblock 479 289 316 minecraft:cobbled_deepslate
fill 480 289 276 483 289 276 minecraft:deepslate_tiles
setblock 480 289 278 minecraft:light[level=12]
setblock 480 289 285 minecraft:light[level=12]
setblock 480 289 292 minecraft:light[level=12]
setblock 480 289 299 minecraft:light[level=12]
setblock 480 289 306 minecraft:light[level=12]
setblock 480 289 313 minecraft:light[level=12]
setblock 480 289 314 minecraft:deepslate_tiles
setblock 480 289 315 minecraft:cobbled_deepslate
fill 480 289 316 483 289 316 minecraft:deepslate_tiles
setblock 481 289 314 minecraft:cobbled_deepslate
fill 481 289 315 481 292 315 minecraft:deepslate_tiles
fill 482 289 314 483 291 314 minecraft:deepslate_tiles
setblock 484 289 276 minecraft:cobbled_deepslate
fill 484 289 291 484 290 291 minecraft:white_wool
setblock 484 289 316 minecraft:cobbled_deepslate
fill 485 289 276 485 292 276 minecraft:deepslate_tiles
setblock 485 289 315 minecraft:cobbled_deepslate
fill 485 289 316 485 292 316 minecraft:deepslate_tiles
fill 486 289 315 486 292 315 minecraft:deepslate_tiles
setblock 487 289 278 minecraft:light[level=12]
setblock 487 289 285 minecraft:light[level=12]
setblock 487 289 292 minecraft:light[level=12]
setblock 487 289 299 minecraft:light[level=12]
setblock 487 289 306 minecraft:light[level=12]
setblock 487 289 313 minecraft:light[level=12]
setblock 488 289 275 minecraft:white_wool
setblock 489 289 316 minecraft:cobbled_deepslate
fill 490 289 316 493 289 316 minecraft:deepslate_tiles
fill 492 289 307 492 290 307 minecraft:white_wool
setblock 494 289 278 minecraft:light[level=12]
setblock 494 289 285 minecraft:light[level=12]
setblock 494 289 292 minecraft:light[level=12]
setblock 494 289 299 minecraft:light[level=12]
setblock 494 289 306 minecraft:light[level=12]
setblock 494 289 313 minecraft:light[level=12]
setblock 494 289 316 minecraft:cobbled_deepslate
setblock 495 289 315 minecraft:cobbled_deepslate
fill 495 289 316 498 289 316 minecraft:deepslate_tiles
fill 496 289 315 496 292 315 minecraft:deepslate_tiles
fill 497 289 314 500 289 314 minecraft:deepslate_tiles
setblock 499 289 316 minecraft:cobbled_deepslate
setblock 500 289 315 minecraft:cobbled_deepslate
fill 500 289 316 500 292 316 minecraft:deepslate_tiles
setblock 501 289 278 minecraft:light[level=12]
setblock 501 289 285 minecraft:light[level=12]
setblock 501 289 292 minecraft:light[level=12]
setblock 501 289 299 minecraft:light[level=12]
setblock 501 289 306 minecraft:light[level=12]
setblock 501 289 313 minecraft:light[level=12]
setblock 501 289 314 minecraft:cobbled_deepslate
fill 501 289 315 501 292 315 minecraft:deepslate_tiles
setblock 504 289 316 minecraft:cobbled_deepslate
setblock 508 289 278 minecraft:light[level=12]
setblock 508 289 285 minecraft:light[level=12]
setblock 508 289 292 minecraft:light[level=12]
setblock 508 289 299 minecraft:light[level=12]
setblock 508 289 306 minecraft:light[level=12]
setblock 508 289 313 minecraft:light[level=12]
fill 510 289 288 510 289 289 minecraft:deepslate_tiles
setblock 510 289 290 minecraft:cobbled_deepslate
fill 510 289 291 510 292 291 minecraft:deepslate_tiles
fill 511 289 285 511 292 285 minecraft:deepslate_tiles
setblock 511 289 289 minecraft:cobbled_deepslate
fill 511 289 290 511 292 290 minecraft:deepslate_tiles
setblock 511 289 294 minecraft:cobbled_deepslate
setblock 512 289 299 minecraft:redstone_block
setblock 471 290 283 minecraft:cobbled_deepslate
fill 471 290 284 471 293 284 minecraft:deepslate_tiles
setblock 471 290 288 minecraft:cobbled_deepslate
fill 471 290 289 471 293 289 minecraft:deepslate_tiles
setblock 471 290 293 minecraft:cobbled_deepslate
fill 471 290 294 471 293 294 minecraft:deepslate_tiles
setblock 472 290 287 minecraft:cobbled_deepslate
fill 472 290 288 472 293 288 minecraft:deepslate_tiles
setblock 472 290 291 minecraft:deepslate_tiles
fill 474 290 276 477 290 276 minecraft:deepslate_tiles
fill 474 290 316 477 290 316 minecraft:deepslate_tiles
setblock 476 290 277 minecraft:deepslate_tiles
fill 476 290 315 478 290 315 minecraft:deepslate_tiles
setblock 477 290 277 minecraft:cobbled_deepslate
setblock 478 290 276 minecraft:cobbled_deepslate
fill 478 290 277 478 293 277 minecraft:deepslate_tiles
fill 478 290 314 479 290 314 minecraft:deepslate_tiles
setblock 478 290 316 minecraft:cobbled_deepslate
fill 479 290 276 482 290 276 minecraft:deepslate_tiles
setblock 479 290 315 minecraft:cobbled_deepslate
fill 479 290 316 482 290 316 minecraft:deepslate_tiles
setblock 480 290 314 minecraft:cobbled_deepslate
fill 480 290 315 480 293 315 minecraft:deepslate_tiles
setblock 481 290 277 minecraft:deepslate_tiles
fill 481 290 314 481 293 314 minecraft:deepslate_tiles
setblock 482 290 277 minecraft:cobbled_deepslate
setblock 483 290 276 minecraft:cobbled_deepslate
setblock 483 290 316 minecraft:cobbled_deepslate
fill 484 290 276 484 293 276 minecraft:deepslate_tiles
setblock 484 290 314 minecraft:deepslate_tiles
setblock 484 290 315 minecraft:cobbled_deepslate
fill 484 290 316 484 293 316 minecraft:deepslate_tiles
fill 485 290 315 485 293 315 minecraft:deepslate_tiles
fill 487 290 315 488 290 315 minecraft:deepslate_tiles
fill 488 290 275 488 308 275 minecraft:deepslate_tiles
setblock 488 290 316 minecraft:cobbled_deepslate
fill 489 290 316 492 290 316 minecraft:deepslate_tiles
fill 492 290 315 493 290 315 minecraft:deepslate_tiles
setblock 493 290 316 minecraft:cobbled_deepslate
setblock 494 290 315 minecraft:cobbled_deepslate
fill 494 290 316 497 290 316 minecraft:deepslate_tiles
setblock 495 290 314 minecraft:cobbled_deepslate
fill 495 290 315 495 293 315 minecraft:deepslate_tiles
fill 496 290 314 499 290 314 minecraft:deepslate_tiles
setblock 498 290 316 minecraft:cobbled_deepslate
setblock 499 290 315 minecraft:cobbled_deepslate
fill 499 290 316 499 293 316 minecraft:deepslate_tiles
setblock 500 290 314 minecraft:cobbled_deepslate
fill 500 290 315 500 293 315 minecraft:deepslate_tiles
fill 501 290 314 501 293 314 minecraft:deepslate_tiles
setblock 503 290 315 minecraft:deepslate_tiles
setblock 503 290 316 minecraft:cobbled_deepslate
fill 504 290 316 504 293 316 minecraft:deepslate_tiles
setblock 510 290 288 minecraft:deepslate_tiles
setblock 510 290 289 minecraft:cobbled_deepslate
fill 510 290 290 510 293 290 minecraft:deepslate_tiles
fill 510 290 292 510 291 292 minecraft:deepslate_tiles
setblock 511 290 288 minecraft:cobbled_deepslate
fill 511 290 289 511 293 289 minecraft:deepslate_tiles
setblock 511 290 293 minecraft:cobbled_deepslate
fill 511 290 294 511 291 296 minecraft:deepslate_tiles
fill 512 290 299 512 308 299 minecraft:deepslate_tiles
setblock 471 291 282 minecraft:cobbled_deepslate
fill 471 291 283 471 294 283 minecraft:deepslate_tiles
setblock 471 291 287 minecraft:cobbled_deepslate
fill 471 291 288 471 294 288 minecraft:deepslate_tiles
setblock 471 291 291 minecraft:deepslate_tiles
setblock 471 291 292 minecraft:cobbled_deepslate
fill 471 291 293 472 293 293 minecraft:deepslate_tiles
fill 471 291 295 471 292 295 minecraft:deepslate_tiles
fill 471 291 313 471 294 313 minecraft:deepslate_tiles
setblock 472 291 276 minecraft:cobbled_deepslate
setblock 472 291 286 minecraft:cobbled_deepslate
fill 472 291 287 472 294 287 minecraft:deepslate_tiles
setblock 472 291 291 minecraft:cobbled_deepslate
fill 472 291 292 472 294 292 minecraft:deepslate_tiles
setblock 472 291 316 minecraft:cobbled_deepslate
fill 473 291 276 476 291 276 minecraft:deepslate_tiles
fill 473 291 288 473 291 289 minecraft:deepslate_tiles
fill 473 291 316 476 291 316 minecraft:deepslate_tiles
fill 474 291 315 477 291 315 minecraft:deepslate_tiles
setblock 475 291 277 minecraft:deepslate_tiles
setblock 476 291 277 minecraft:cobbled_deepslate
fill 476 291 314 478 291 314 minecraft:deepslate_tiles
setblock 477 291 276 minecraft:cobbled_deepslate
fill 477 291 277 477 294 277 minecraft:deepslate_tiles
setblock 477 291 316 minecraft:cobbled_deepslate
fill 478 291 276 481 291 276 minecraft:deepslate_tiles
setblock 478 291 315 minecraft:cobbled_deepslate
fill 478 291 316 481 291 316 minecraft:deepslate_tiles
setblock 479 291 314 minecraft:cobbled_deepslate
fill 479 291 315 479 294 315 minecraft:deepslate_tiles
setblock 480 291 313 minecraft:cobbled_deepslate
fill 480 291 314 480 294 314 minecraft:deepslate_tiles
setblock 481 291 277 minecraft:cobbled_deepslate
fill 481 291 313 481 294 313 minecraft:deepslate_tiles
setblock 482 291 276 minecraft:cobbled_deepslate
fill 482 291 277 482 294 277 minecraft:deepslate_tiles
setblock 482 291 316 minecraft:cobbled_deepslate
fill 483 291 276 483 294 276 minecraft:deepslate_tiles
setblock 483 291 315 minecraft:cobbled_deepslate
fill 483 291 316 483 294 316 minecraft:deepslate_tiles
setblock 484 291 314 minecraft:cobbled_deepslate
fill 484 291 315 484 294 315 minecraft:deepslate_tiles
fill 485 291 314 485 294 314 minecraft:deepslate_tiles
setblock 486 291 276 minecraft:deepslate_tiles
setblock 487 291 315 minecraft:deepslate_tiles
setblock 487 291 316 minecraft:cobbled_deepslate
setblock 488 291 315 minecraft:cobbled_deepslate
fill 488 291 316 491 291 316 minecraft:deepslate_tiles
fill 489 291 315 492 291 315 minecraft:deepslate_tiles
fill 492 291 307 492 300 307 minecraft:black_concrete
setblock 492 291 316 minecraft:cobbled_deepslate
setblock 493 291 314 minecraft:deepslate_tiles
setblock 493 291 315 minecraft:cobbled_deepslate
fill 493 291 316 496 291 316 minecraft:deepslate_tiles
setblock 494 291 314 minecraft:cobbled_deepslate
fill 494 291 315 494 294 315 minecraft:deepslate_tiles
fill 495 291 314 498 291 314 minecraft:deepslate_tiles
fill 496 291 313 499 291 313 minecraft:deepslate_tiles
setblock 497 291 276 minecraft:cobbled_deepslate
setblock 497 291 315 minecraft:deepslate_tiles
setblock 497 291 316 minecraft:cobbled_deepslate
fill 498 291 276 500 292 276 minecraft:deepslate_tiles
setblock 498 291 315 minecraft:cobbled_deepslate
fill 498 291 316 498 294 316 minecraft:deepslate_tiles
fill 499 291 300 499 292 301 minecraft:white_wool
setblock 499 291 314 minecraft:cobbled_deepslate
fill 499 291 315 499 294 315 minecraft:deepslate_tiles
setblock 500 291 313 minecraft:cobbled_deepslate
fill 500 291 314 500 294 314 minecraft:deepslate_tiles
fill 502 291 314 502 292 314 minecraft:deepslate_tiles
setblock 502 291 316 minecraft:cobbled_deepslate
setblock 503 291 315 minecraft:cobbled_deepslate
fill 503 291 316 503 294 316 minecraft:deepslate_tiles
fill 505 291 316 505 292 316 minecraft:deepslate_tiles
fill 509 291 308 509 299 308 minecraft:cobbled_deepslate
setblock 510 291 287 minecraft:deepslate_tiles
setblock 510 291 288 minecraft:cobbled_deepslate
fill 510 291 289 510 294 289 minecraft:deepslate_tiles
setblock 510 291 293 minecraft:cobbled_deepslate
fill 510 291 294 510 294 294 minecraft:deepslate_tiles
fill 511 291 284 511 293 284 minecraft:deepslate_tiles
setblock 511 291 287 minecraft:cobbled_deepslate
fill 511 291 288 511 294 288 minecraft:deepslate_tiles
setblock 511 291 292 minecraft:cobbled_deepslate
fill 511 291 293 511 294 293 minecraft:deepslate_tiles
setblock 511 291 297 minecraft:cobbled_deepslate
setblock 471 292 276 minecraft:cobbled_deepslate
fill 471 292 277 471 292 280 minecraft:deepslate_tiles
setblock 471 292 281 minecraft:cobbled_deepslate
fill 471 292 282 471 295 282 minecraft:deepslate_tiles
setblock 471 292 285 minecraft:deepslate_tiles
setblock 471 292 286 minecraft:cobbled_deepslate
fill 471 292 287 471 295 287 minecraft:deepslate_tiles
setblock 471 292 290 minecraft:deepslate_tiles
setblock 471 292 291 minecraft:cobbled_deepslate
fill 471 292 292 471 295 292 minecraft:deepslate_tiles
setblock 471 292 296 minecraft:cobbled_deepslate
setblock 471 292 311 minecraft:cobbled_deepslate
fill 471 292 312 471 295 312 minecraft:deepslate_tiles
fill 471 292 314 471 292 315 minecraft:deepslate_tiles
setblock 471 292 316 minecraft:cobbled_deepslate
fill 472 292 276 475 292 276 minecraft:deepslate_tiles
setblock 472 292 284 minecraft:deepslate_tiles
setblock 472 292 285 minecraft:cobbled_deepslate
fill 472 292 286 472 295 286 minecraft:deepslate_tiles
setblock 472 292 290 minecraft:cobbled_deepslate
fill 472 292 291 473 294 291 minecraft:deepslate_tiles
setblock 472 292 294 minecraft:deepslate_tiles
fill 472 292 316 475 292 316 minecraft:deepslate_tiles
fill 473 292 277 474 292 277 minecraft:deepslate_tiles
fill 473 292 287 473 292 288 minecraft:deepslate_tiles
setblock 473 292 289 minecraft:cobbled_deepslate
fill 473 292 290 473 295 290 minecraft:deepslate_tiles
fill 473 292 315 476 292 315 minecraft:deepslate_tiles
setblock 475 292 277 minecraft:cobbled_deepslate
fill 475 292 314 477 292 314 minecraft:deepslate_tiles
setblock 476 292 276 minecraft:cobbled_deepslate
fill 476 292 277 476 295 277 minecraft:deepslate_tiles
setblock 476 292 316 minecraft:cobbled_deepslate
fill 477 292 276 480 292 276 minecraft:deepslate_tiles
fill 477 292 278 478 292 278 minecraft:deepslate_tiles
setblock 477 292 315 minecraft:cobbled_deepslate
fill 477 292 316 480 292 316 minecraft:deepslate_tiles
setblock 478 292 313 minecraft:deepslate_tiles
setblock 478 292 314 minecraft:cobbled_deepslate
fill 478 292 315 478 295 315 minecraft:deepslate_tiles
setblock 479 292 278 minecraft:cobbled_deepslate
setblock 479 292 313 minecraft:cobbled_deepslate
fill 479 292 314 479 295 314 minecraft:deepslate_tiles
setblock 480 292 277 minecraft:cobbled_deepslate
fill 480 292 313 480 295 313 minecraft:deepslate_tiles
setblock 481 292 276 minecraft:cobbled_deepslate
fill 481 292 277 481 295 277 minecraft:deepslate_tiles
setblock 481 292 316 minecraft:cobbled_deepslate
fill 482 292 276 482 295 276 minecraft:deepslate_tiles
fill 482 292 313 482 292 314 minecraft:deepslate_tiles
setblock 482 292 315 minecraft:cobbled_deepslate
fill 482 292 316 482 295 316 minecraft:deepslate_tiles
fill 483 292 277 483 293 277 minecraft:deepslate_tiles
setblock 483 292 314 minecraft:cobbled_deepslate
fill 483 292 315 483 295 315 minecraft:deepslate_tiles
fill 484 292 314 484 295 314 minecraft:deepslate_tiles
fill 485 292 275 485 304 275 minecraft:deepslate_tiles
setblock 486 292 275 minecraft:white_wool
setblock 486 292 276 minecraft:cobbled_deepslate
fill 486 292 314 487 292 314 minecraft:deepslate_tiles
setblock 486 292 316 minecraft:cobbled_deepslate
setblock 487 292 315 minecraft:cobbled_deepslate
fill 487 292 316 490 292 316 minecraft:deepslate_tiles
fill 488 292 315 491 292 315 minecraft:deepslate_tiles
fill 491 292 307 491 300 307 minecraft:black_concrete
fill 491 292 314 492 292 314 minecraft:deepslate_tiles
setblock 491 292 316 minecraft:cobbled_deepslate
setblock 492 292 275 minecraft:redstone_block
setblock 492 292 315 minecraft:cobbled_deepslate
fill 492 292 316 495 292 316 minecraft:deepslate_tiles
fill 493 292 275 493 308 275 minecraft:deepslate_tiles
setblock 493 292 314 minecraft:cobbled_deepslate
fill 493 292 315 493 295 315 minecraft:deepslate_tiles
fill 494 292 276 495 292 276 minecraft:deepslate_tiles
setblock 494 292 313 minecraft:cobbled_deepslate
fill 494 292 314 497 292 314 minecraft:deepslate_tiles
fill 495 292 313 498 292 313 minecraft:deepslate_tiles
setblock 496 292 276 minecraft:cobbled_deepslate
setblock 496 292 316 minecraft:cobbled_deepslate
fill 497 292 276 497 295 276 minecraft:deepslate_tiles
setblock 497 292 315 minecraft:cobbled_deepslate
fill 497 292 316 497 295 316 minecraft:deepslate_tiles
setblock 498 292 314 minecraft:cobbled_deepslate
fill 498 292 315 498 295 315 minecraft:deepslate_tiles
setblock 499 292 313 minecraft:cobbled_deepslate
fill 499 292 314 499 295 314 minecraft:deepslate_tiles
setblock 500 292 275 minecraft:redstone_block
fill 500 292 313 500 293 313 minecraft:deepslate_tiles
setblock 501 292 276 minecraft:cobbled_deepslate
setblock 501 292 316 minecraft:cobbled_deepslate
setblock 502 292 315 minecraft:cobbled_deepslate
fill 502 292 316 502 295 316 minecraft:deepslate_tiles
fill 503 292 315 503 295 315 minecraft:deepslate_tiles
setblock 510 292 287 minecraft:cobbled_deepslate
fill 510 292 288 510 295 288 minecraft:deepslate_tiles
setblock 510 292 292 minecraft:cobbled_deepslate
fill 510 292 293 510 295 293 minecraft:deepslate_tiles
fill 510 292 295 511 292 295 minecraft:deepslate_tiles
setblock 511 292 286 minecraft:cobbled_deepslate
fill 511 292 287 511 295 287 minecraft:deepslate_tiles
setblock 511 292 291 minecraft:cobbled_deepslate
fill 511 292 292 511 295 292 minecraft:deepslate_tiles
fill 511 292 294 511 293 294 minecraft:deepslate_tiles
setblock 511 292 296 minecraft:cobbled_deepslate
fill 511 292 297 511 294 298 minecraft:deepslate_tiles
setblock 511 292 310 minecraft:deepslate_tiles
setblock 511 292 311 minecraft:cobbled_deepslate
fill 511 292 312 511 294 313 minecraft:deepslate_tiles
fill 471 293 276 471 293 279 minecraft:deepslate_tiles
setblock 471 293 280 minecraft:cobbled_deepslate
fill 471 293 281 471 296 281 minecraft:deepslate_tiles
setblock 471 293 285 minecraft:cobbled_deepslate
fill 471 293 286 471 296 286 minecraft:deepslate_tiles
setblock 471 293 290 minecraft:cobbled_deepslate
fill 471 293 291 471 296 291 minecraft:deepslate_tiles
setblock 471 293 295 minecraft:cobbled_deepslate
fill 471 293 296 471 295 297 minecraft:deepslate_tiles
setblock 471 293 310 minecraft:cobbled_deepslate
fill 471 293 311 471 296 311 minecraft:deepslate_tiles
setblock 471 293 314 minecraft:deepslate_tiles
setblock 471 293 315 minecraft:cobbled_deepslate
fill 471 293 316 474 293 316 minecraft:deepslate_tiles
fill 472 293 276 472 293 278 minecraft:deepslate_tiles
setblock 472 293 283 minecraft:deepslate_tiles
setblock 472 293 284 minecraft:cobbled_deepslate
fill 472 293 285 472 296 285 minecraft:deepslate_tiles
setblock 472 293 289 minecraft:cobbled_deepslate
fill 472 293 290 472 296 290 minecraft:deepslate_tiles
setblock 472 293 294 minecraft:cobbled_deepslate
fill 472 293 295 472 296 295 minecraft:deepslate_tiles
fill 472 293 312 472 293 313 minecraft:deepslate_tiles
setblock 472 293 314 minecraft:cobbled_deepslate
fill 472 293 315 475 293 315 minecraft:deepslate_tiles
schedule function dropper:buildpart/70_12 1t
