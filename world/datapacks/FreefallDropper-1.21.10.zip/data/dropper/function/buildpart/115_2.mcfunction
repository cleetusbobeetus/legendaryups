setblock 335 87 464 minecraft:red_nether_bricks
setblock 335 87 504 minecraft:red_nether_bricks
fill 336 87 464 339 87 464 minecraft:pink_terracotta
setblock 336 87 503 minecraft:red_nether_bricks
fill 336 87 504 336 90 504 minecraft:pink_terracotta
fill 337 87 500 337 114 500 minecraft:red_nether_bricks
setblock 337 87 501 minecraft:pink_terracotta
setblock 337 87 502 minecraft:red_nether_bricks
fill 337 87 503 337 90 503 minecraft:pink_terracotta
setblock 338 87 501 minecraft:red_nether_bricks
fill 338 87 502 338 90 502 minecraft:pink_terracotta
fill 339 87 501 339 90 501 minecraft:pink_terracotta
setblock 340 87 464 minecraft:red_nether_bricks
fill 340 87 500 341 89 500 minecraft:pink_terracotta
setblock 340 87 504 minecraft:red_nether_bricks
fill 341 87 464 341 90 464 minecraft:pink_terracotta
fill 341 87 501 342 87 501 minecraft:pink_terracotta
setblock 341 87 503 minecraft:red_nether_bricks
fill 341 87 504 341 90 504 minecraft:pink_terracotta
setblock 342 87 502 minecraft:red_nether_bricks
fill 342 87 503 342 90 503 minecraft:pink_terracotta
setblock 343 87 501 minecraft:red_nether_bricks
fill 343 87 502 343 90 502 minecraft:pink_terracotta
setblock 344 87 464 minecraft:pink_terracotta
fill 344 87 501 344 89 501 minecraft:pink_terracotta
setblock 345 87 504 minecraft:red_nether_bricks
setblock 346 87 502 minecraft:pink_terracotta
setblock 346 87 503 minecraft:red_nether_bricks
fill 346 87 504 346 90 504 minecraft:pink_terracotta
fill 347 87 503 347 90 503 minecraft:pink_terracotta
setblock 356 87 504 minecraft:white_concrete
fill 357 87 504 359 87 504 minecraft:pink_terracotta
fill 358 87 464 359 87 464 minecraft:pink_terracotta
fill 359 87 503 360 87 503 minecraft:pink_terracotta
setblock 360 87 464 minecraft:red_nether_bricks
setblock 360 87 504 minecraft:red_nether_bricks
fill 361 87 464 361 89 465 minecraft:pink_terracotta
setblock 361 87 503 minecraft:red_nether_bricks
fill 361 87 504 364 87 504 minecraft:pink_terracotta
fill 362 87 465 363 87 465 minecraft:pink_terracotta
fill 362 87 503 362 90 503 minecraft:pink_terracotta
setblock 364 87 465 minecraft:red_nether_bricks
setblock 365 87 464 minecraft:red_nether_bricks
fill 365 87 465 365 90 465 minecraft:pink_terracotta
setblock 365 87 503 minecraft:pink_terracotta
setblock 365 87 504 minecraft:red_nether_bricks
fill 366 87 464 366 90 464 minecraft:pink_terracotta
setblock 366 87 503 minecraft:red_nether_bricks
fill 366 87 504 366 90 504 minecraft:pink_terracotta
setblock 368 87 476 minecraft:red_nether_bricks
setblock 368 87 477 minecraft:pink_terracotta
setblock 369 87 475 minecraft:red_nether_bricks
fill 369 87 476 369 89 476 minecraft:pink_terracotta
setblock 369 87 480 minecraft:red_nether_bricks
setblock 369 87 504 minecraft:pink_terracotta
setblock 370 87 464 minecraft:red_nether_bricks
fill 370 87 465 370 90 465 minecraft:pink_terracotta
setblock 370 87 469 minecraft:red_nether_bricks
fill 370 87 470 370 88 470 minecraft:pink_terracotta
setblock 370 87 474 minecraft:red_nether_bricks
fill 370 87 475 370 90 475 minecraft:pink_terracotta
setblock 370 87 479 minecraft:red_nether_bricks
fill 370 87 480 370 90 480 minecraft:pink_terracotta
fill 370 87 482 370 88 482 minecraft:pink_terracotta
setblock 370 87 498 minecraft:pink_terracotta
setblock 370 87 499 minecraft:red_nether_bricks
fill 370 87 500 370 90 500 minecraft:pink_terracotta
setblock 370 87 504 minecraft:red_nether_bricks
fill 330 88 464 333 88 464 minecraft:pink_terracotta
setblock 330 88 467 minecraft:white_concrete
fill 330 88 473 330 89 473 minecraft:white_concrete
setblock 330 88 478 minecraft:red_nether_bricks
fill 330 88 479 330 90 479 minecraft:pink_terracotta
setblock 330 88 492 minecraft:white_concrete
setblock 330 88 498 minecraft:red_nether_bricks
fill 330 88 499 330 91 499 minecraft:pink_terracotta
setblock 330 88 503 minecraft:red_nether_bricks
fill 330 88 504 330 91 504 minecraft:pink_terracotta
setblock 331 88 497 minecraft:red_nether_bricks
fill 331 88 498 331 91 498 minecraft:pink_terracotta
setblock 331 88 502 minecraft:red_nether_bricks
fill 331 88 503 334 88 503 minecraft:pink_terracotta
setblock 332 88 500 minecraft:pink_terracotta
setblock 332 88 501 minecraft:red_nether_bricks
fill 332 88 502 335 88 502 minecraft:pink_terracotta
setblock 333 88 504 minecraft:pink_terracotta
setblock 334 88 464 minecraft:red_nether_bricks
setblock 334 88 504 minecraft:red_nether_bricks
fill 335 88 464 338 88 464 minecraft:pink_terracotta
fill 335 88 501 336 88 501 minecraft:pink_terracotta
setblock 335 88 503 minecraft:red_nether_bricks
fill 335 88 504 335 91 504 minecraft:pink_terracotta
setblock 336 88 502 minecraft:red_nether_bricks
fill 336 88 503 336 91 503 minecraft:pink_terracotta
setblock 337 88 501 minecraft:red_nether_bricks
fill 337 88 502 337 91 502 minecraft:pink_terracotta
fill 338 88 501 338 91 501 minecraft:pink_terracotta
setblock 339 88 464 minecraft:red_nether_bricks
fill 339 88 500 339 90 500 minecraft:pink_terracotta
setblock 339 88 504 minecraft:red_nether_bricks
fill 340 88 464 340 91 464 minecraft:pink_terracotta
setblock 340 88 503 minecraft:red_nether_bricks
fill 340 88 504 340 91 504 minecraft:pink_terracotta
setblock 341 88 501 minecraft:pink_terracotta
setblock 341 88 502 minecraft:red_nether_bricks
fill 341 88 503 341 91 503 minecraft:pink_terracotta
setblock 342 88 501 minecraft:red_nether_bricks
fill 342 88 502 342 91 502 minecraft:pink_terracotta
fill 343 88 501 343 90 501 minecraft:pink_terracotta
setblock 344 88 464 minecraft:red_nether_bricks
setblock 344 88 504 minecraft:red_nether_bricks
setblock 345 88 503 minecraft:red_nether_bricks
fill 345 88 504 345 91 504 minecraft:pink_terracotta
setblock 346 88 502 minecraft:red_nether_bricks
fill 346 88 503 346 91 503 minecraft:pink_terracotta
setblock 349 88 504 minecraft:red_nether_bricks
fill 355 88 504 358 88 504 minecraft:pink_terracotta
fill 357 88 464 358 88 464 minecraft:pink_terracotta
fill 357 88 503 359 88 503 minecraft:pink_terracotta
setblock 359 88 464 minecraft:red_nether_bricks
fill 359 88 465 360 90 465 minecraft:pink_terracotta
setblock 359 88 504 minecraft:red_nether_bricks
fill 360 88 464 360 91 464 minecraft:pink_terracotta
setblock 360 88 503 minecraft:red_nether_bricks
fill 360 88 504 363 88 504 minecraft:pink_terracotta
setblock 361 88 502 minecraft:red_nether_bricks
fill 361 88 503 361 91 503 minecraft:pink_terracotta
setblock 362 88 465 minecraft:pink_terracotta
fill 362 88 502 362 90 502 minecraft:pink_terracotta
setblock 363 88 465 minecraft:red_nether_bricks
setblock 364 88 464 minecraft:red_nether_bricks
fill 364 88 465 364 91 465 minecraft:pink_terracotta
setblock 364 88 504 minecraft:red_nether_bricks
fill 365 88 464 365 91 464 minecraft:pink_terracotta
setblock 365 88 503 minecraft:red_nether_bricks
fill 365 88 504 365 91 504 minecraft:pink_terracotta
fill 366 88 465 366 89 465 minecraft:pink_terracotta
fill 366 88 503 367 90 503 minecraft:pink_terracotta
setblock 369 88 464 minecraft:red_nether_bricks
setblock 369 88 474 minecraft:red_nether_bricks
fill 369 88 475 369 89 475 minecraft:pink_terracotta
setblock 369 88 479 minecraft:red_nether_bricks
fill 369 88 480 369 89 480 minecraft:pink_terracotta
setblock 369 88 504 minecraft:red_nether_bricks
fill 370 88 464 370 91 464 minecraft:pink_terracotta
fill 370 88 466 370 88 467 minecraft:pink_terracotta
setblock 370 88 469 minecraft:pink_terracotta
setblock 370 88 473 minecraft:red_nether_bricks
fill 370 88 474 370 90 474 minecraft:pink_terracotta
setblock 370 88 478 minecraft:red_nether_bricks
fill 370 88 479 370 91 479 minecraft:pink_terracotta
setblock 370 88 495 minecraft:white_concrete
setblock 370 88 498 minecraft:red_nether_bricks
fill 370 88 499 370 91 499 minecraft:pink_terracotta
fill 370 88 501 370 88 502 minecraft:pink_terracotta
setblock 370 88 503 minecraft:red_nether_bricks
fill 370 88 504 370 91 504 minecraft:pink_terracotta
fill 330 89 464 330 90 465 minecraft:pink_terracotta
setblock 330 89 478 minecraft:pink_terracotta
fill 330 89 480 330 90 480 minecraft:pink_terracotta
setblock 330 89 497 minecraft:red_nether_bricks
fill 330 89 498 330 92 498 minecraft:pink_terracotta
setblock 330 89 501 minecraft:pink_terracotta
setblock 330 89 502 minecraft:red_nether_bricks
fill 330 89 503 333 89 503 minecraft:pink_terracotta
fill 331 89 464 332 89 464 minecraft:pink_terracotta
setblock 331 89 497 minecraft:pink_terracotta
setblock 331 89 501 minecraft:red_nether_bricks
fill 331 89 502 334 89 502 minecraft:pink_terracotta
setblock 332 89 466 minecraft:light[level=12]
setblock 332 89 474 minecraft:light[level=12]
setblock 332 89 482 minecraft:light[level=12]
setblock 332 89 490 minecraft:light[level=12]
setblock 332 89 498 minecraft:light[level=12]
setblock 332 89 499 minecraft:pink_terracotta
setblock 332 89 500 minecraft:red_nether_bricks
fill 332 89 501 332 92 501 minecraft:pink_terracotta
setblock 333 89 464 minecraft:red_nether_bricks
setblock 333 89 504 minecraft:red_nether_bricks
fill 334 89 464 337 89 464 minecraft:pink_terracotta
setblock 334 89 503 minecraft:red_nether_bricks
fill 334 89 504 334 92 504 minecraft:pink_terracotta
setblock 335 89 501 minecraft:pink_terracotta
setblock 335 89 502 minecraft:red_nether_bricks
fill 335 89 503 335 92 503 minecraft:pink_terracotta
setblock 336 89 501 minecraft:red_nether_bricks
fill 336 89 502 336 92 502 minecraft:pink_terracotta
fill 337 89 501 337 92 501 minecraft:pink_terracotta
setblock 338 89 464 minecraft:red_nether_bricks
fill 338 89 465 340 90 465 minecraft:pink_terracotta
fill 338 89 500 338 90 500 minecraft:pink_terracotta
setblock 338 89 504 minecraft:red_nether_bricks
fill 339 89 464 339 92 464 minecraft:pink_terracotta
setblock 339 89 503 minecraft:red_nether_bricks
fill 339 89 504 339 92 504 minecraft:pink_terracotta
setblock 340 89 466 minecraft:light[level=12]
setblock 340 89 474 minecraft:light[level=12]
setblock 340 89 482 minecraft:light[level=12]
setblock 340 89 490 minecraft:light[level=12]
setblock 340 89 498 minecraft:light[level=12]
setblock 340 89 502 minecraft:red_nether_bricks
fill 340 89 503 340 92 503 minecraft:pink_terracotta
setblock 341 89 501 minecraft:red_nether_bricks
fill 341 89 502 341 92 502 minecraft:pink_terracotta
setblock 342 89 464 minecraft:pink_terracotta
fill 342 89 501 342 91 501 minecraft:pink_terracotta
setblock 343 89 464 minecraft:red_nether_bricks
setblock 343 89 504 minecraft:red_nether_bricks
fill 344 89 464 344 92 464 minecraft:pink_terracotta
setblock 344 89 503 minecraft:red_nether_bricks
fill 344 89 504 344 92 504 minecraft:pink_terracotta
setblock 345 89 502 minecraft:red_nether_bricks
fill 345 89 503 345 92 503 minecraft:pink_terracotta
setblock 347 89 504 minecraft:pink_terracotta
setblock 348 89 466 minecraft:light[level=12]
setblock 348 89 474 minecraft:light[level=12]
setblock 348 89 482 minecraft:light[level=12]
setblock 348 89 490 minecraft:light[level=12]
setblock 348 89 498 minecraft:light[level=12]
setblock 348 89 504 minecraft:red_nether_bricks
fill 349 89 504 350 91 504 minecraft:pink_terracotta
setblock 351 89 464 minecraft:white_concrete
setblock 353 89 504 minecraft:red_nether_bricks
fill 354 89 504 357 89 504 minecraft:pink_terracotta
fill 355 89 464 357 89 464 minecraft:pink_terracotta
setblock 356 89 466 minecraft:light[level=12]
setblock 356 89 474 minecraft:light[level=12]
setblock 356 89 482 minecraft:light[level=12]
setblock 356 89 490 minecraft:light[level=12]
setblock 356 89 498 minecraft:light[level=12]
fill 356 89 503 358 89 503 minecraft:pink_terracotta
setblock 358 89 464 minecraft:red_nether_bricks
fill 358 89 465 358 92 465 minecraft:pink_terracotta
setblock 358 89 504 minecraft:red_nether_bricks
fill 359 89 464 359 92 464 minecraft:pink_terracotta
setblock 359 89 502 minecraft:pink_terracotta
setblock 359 89 503 minecraft:red_nether_bricks
fill 359 89 504 362 89 504 minecraft:pink_terracotta
setblock 360 89 502 minecraft:red_nether_bricks
fill 360 89 503 360 92 503 minecraft:pink_terracotta
fill 361 89 502 361 91 502 minecraft:pink_terracotta
setblock 362 89 465 minecraft:red_nether_bricks
setblock 363 89 464 minecraft:red_nether_bricks
fill 363 89 465 363 92 465 minecraft:pink_terracotta
fill 363 89 502 363 89 503 minecraft:pink_terracotta
setblock 363 89 504 minecraft:red_nether_bricks
fill 364 89 464 364 92 464 minecraft:pink_terracotta
setblock 364 89 466 minecraft:light[level=12]
setblock 364 89 474 minecraft:light[level=12]
setblock 364 89 482 minecraft:light[level=12]
setblock 364 89 490 minecraft:light[level=12]
setblock 364 89 498 minecraft:light[level=12]
setblock 364 89 503 minecraft:red_nether_bricks
fill 364 89 504 364 92 504 minecraft:pink_terracotta
fill 365 89 503 365 92 503 minecraft:pink_terracotta
setblock 367 89 465 minecraft:red_nether_bricks
setblock 367 89 504 minecraft:pink_terracotta
setblock 368 89 464 minecraft:red_nether_bricks
setblock 368 89 503 minecraft:pink_terracotta
setblock 368 89 504 minecraft:red_nether_bricks
fill 369 89 464 369 92 464 minecraft:pink_terracotta
setblock 369 89 478 minecraft:red_nether_bricks
fill 369 89 479 369 90 479 minecraft:pink_terracotta
setblock 369 89 502 minecraft:pink_terracotta
setblock 369 89 503 minecraft:red_nether_bricks
fill 369 89 504 369 92 504 minecraft:pink_terracotta
setblock 370 89 466 minecraft:pink_terracotta
setblock 370 89 467 minecraft:red_nether_bricks
fill 370 89 468 370 92 468 minecraft:pink_terracotta
setblock 370 89 470 minecraft:white_concrete
setblock 370 89 472 minecraft:red_nether_bricks
fill 370 89 473 370 90 473 minecraft:pink_terracotta
setblock 370 89 477 minecraft:red_nether_bricks
fill 370 89 478 370 92 478 minecraft:pink_terracotta
setblock 370 89 482 minecraft:red_nether_bricks
setblock 370 89 489 minecraft:white_concrete
fill 370 89 498 370 90 498 minecraft:pink_terracotta
setblock 370 89 501 minecraft:pink_terracotta
setblock 370 89 502 minecraft:red_nether_bricks
fill 370 89 503 370 92 503 minecraft:pink_terracotta
setblock 330 90 481 minecraft:red_nether_bricks
setblock 330 90 485 minecraft:white_concrete
setblock 330 90 496 minecraft:red_nether_bricks
fill 330 90 497 330 93 497 minecraft:pink_terracotta
setblock 330 90 501 minecraft:red_nether_bricks
fill 330 90 502 332 90 503 minecraft:pink_terracotta
setblock 331 90 464 minecraft:pink_terracotta
setblock 331 90 500 minecraft:red_nether_bricks
fill 331 90 501 331 93 501 minecraft:pink_terracotta
setblock 332 90 464 minecraft:red_nether_bricks
setblock 332 90 499 minecraft:red_nether_bricks
fill 332 90 500 332 92 500 minecraft:pink_terracotta
setblock 332 90 504 minecraft:red_nether_bricks
fill 333 90 464 336 90 464 minecraft:pink_terracotta
setblock 333 90 502 minecraft:pink_terracotta
setblock 333 90 503 minecraft:red_nether_bricks
fill 333 90 504 333 93 504 minecraft:pink_terracotta
setblock 334 90 501 minecraft:pink_terracotta
setblock 334 90 502 minecraft:red_nether_bricks
fill 334 90 503 334 93 503 minecraft:pink_terracotta
setblock 335 90 501 minecraft:red_nether_bricks
fill 335 90 502 335 93 502 minecraft:pink_terracotta
setblock 336 90 465 minecraft:red_nether_bricks
fill 336 90 501 336 93 501 minecraft:pink_terracotta
setblock 337 90 464 minecraft:red_nether_bricks
fill 337 90 465 337 93 465 minecraft:pink_terracotta
setblock 337 90 504 minecraft:red_nether_bricks
fill 338 90 464 338 93 464 minecraft:pink_terracotta
setblock 338 90 503 minecraft:red_nether_bricks
fill 338 90 504 338 93 504 minecraft:pink_terracotta
setblock 339 90 502 minecraft:red_nether_bricks
fill 339 90 503 339 93 503 minecraft:pink_terracotta
setblock 340 90 500 minecraft:pink_terracotta
setblock 340 90 501 minecraft:red_nether_bricks
fill 340 90 502 340 93 502 minecraft:pink_terracotta
fill 341 90 501 341 92 501 minecraft:pink_terracotta
setblock 342 90 464 minecraft:red_nether_bricks
setblock 342 90 504 minecraft:red_nether_bricks
fill 343 90 464 343 93 464 minecraft:pink_terracotta
setblock 343 90 503 minecraft:red_nether_bricks
fill 343 90 504 343 93 504 minecraft:pink_terracotta
setblock 344 90 502 minecraft:red_nether_bricks
fill 344 90 503 344 93 503 minecraft:pink_terracotta
setblock 345 90 464 minecraft:white_concrete
setblock 345 90 502 minecraft:pink_terracotta
setblock 347 90 504 minecraft:red_nether_bricks
fill 348 90 504 348 92 504 minecraft:pink_terracotta
setblock 351 90 504 minecraft:pink_terracotta
setblock 352 90 504 minecraft:red_nether_bricks
fill 353 90 504 356 90 504 minecraft:pink_terracotta
fill 354 90 464 356 90 464 minecraft:pink_terracotta
fill 355 90 503 357 90 503 minecraft:pink_terracotta
setblock 357 90 464 minecraft:red_nether_bricks
fill 357 90 465 357 93 465 minecraft:pink_terracotta
setblock 357 90 504 minecraft:red_nether_bricks
fill 358 90 464 358 93 464 minecraft:pink_terracotta
setblock 358 90 502 minecraft:pink_terracotta
setblock 358 90 503 minecraft:red_nether_bricks
fill 358 90 504 361 90 504 minecraft:pink_terracotta
setblock 359 90 502 minecraft:red_nether_bricks
fill 359 90 503 359 93 503 minecraft:pink_terracotta
fill 360 90 502 360 91 502 minecraft:pink_terracotta
setblock 361 90 464 minecraft:pink_terracotta
setblock 361 90 465 minecraft:red_nether_bricks
fill 361 90 466 362 92 466 minecraft:pink_terracotta
setblock 362 90 464 minecraft:red_nether_bricks
fill 362 90 465 362 93 465 minecraft:pink_terracotta
setblock 362 90 504 minecraft:red_nether_bricks
fill 363 90 464 363 93 464 minecraft:pink_terracotta
setblock 363 90 502 minecraft:pink_terracotta
setblock 363 90 503 minecraft:red_nether_bricks
fill 363 90 504 363 93 504 minecraft:pink_terracotta
fill 364 90 503 364 93 503 minecraft:pink_terracotta
setblock 366 90 465 minecraft:red_nether_bricks
setblock 367 90 464 minecraft:red_nether_bricks
fill 367 90 465 367 93 465 minecraft:pink_terracotta
setblock 367 90 504 minecraft:red_nether_bricks
fill 368 90 464 368 93 464 minecraft:pink_terracotta
setblock 368 90 503 minecraft:red_nether_bricks
fill 368 90 504 368 93 504 minecraft:pink_terracotta
setblock 369 90 478 minecraft:pink_terracotta
setblock 369 90 502 minecraft:red_nether_bricks
fill 369 90 503 369 92 503 minecraft:pink_terracotta
setblock 370 90 466 minecraft:red_nether_bricks
fill 370 90 467 370 93 467 minecraft:pink_terracotta
setblock 370 90 476 minecraft:red_nether_bricks
fill 370 90 477 370 91 477 minecraft:pink_terracotta
setblock 370 90 481 minecraft:red_nether_bricks
fill 370 90 482 370 91 483 minecraft:pink_terracotta
setblock 370 90 501 minecraft:red_nether_bricks
fill 370 90 502 370 93 502 minecraft:pink_terracotta
setblock 330 91 464 minecraft:pink_terracotta
setblock 330 91 465 minecraft:red_nether_bricks
setblock 330 91 466 minecraft:white_concrete
setblock 330 91 481 minecraft:pink_terracotta
setblock 330 91 491 minecraft:white_concrete
setblock 330 91 496 minecraft:pink_terracotta
setblock 330 91 500 minecraft:red_nether_bricks
fill 330 91 501 330 92 503 minecraft:pink_terracotta
setblock 331 91 464 minecraft:red_nether_bricks
setblock 331 91 499 minecraft:red_nether_bricks
fill 331 91 500 331 94 500 minecraft:pink_terracotta
fill 331 91 502 331 91 503 minecraft:pink_terracotta
setblock 331 91 504 minecraft:red_nether_bricks
fill 332 91 464 335 91 464 minecraft:pink_terracotta
setblock 332 91 502 minecraft:pink_terracotta
setblock 332 91 503 minecraft:red_nether_bricks
fill 332 91 504 332 94 504 minecraft:pink_terracotta
setblock 333 91 502 minecraft:red_nether_bricks
fill 333 91 503 333 94 503 minecraft:pink_terracotta
setblock 334 91 501 minecraft:red_nether_bricks
fill 334 91 502 334 94 502 minecraft:pink_terracotta
setblock 335 91 465 minecraft:red_nether_bricks
fill 335 91 501 335 93 501 minecraft:pink_terracotta
setblock 336 91 464 minecraft:red_nether_bricks
fill 336 91 465 336 94 465 minecraft:pink_terracotta
setblock 336 91 504 minecraft:red_nether_bricks
fill 337 91 464 337 94 464 minecraft:pink_terracotta
setblock 337 91 503 minecraft:red_nether_bricks
fill 337 91 504 337 94 504 minecraft:pink_terracotta
fill 338 91 465 339 91 465 minecraft:pink_terracotta
fill 338 91 500 338 114 500 minecraft:red_nether_bricks
setblock 338 91 502 minecraft:red_nether_bricks
fill 338 91 503 338 94 503 minecraft:pink_terracotta
setblock 339 91 501 minecraft:red_nether_bricks
fill 339 91 502 339 94 502 minecraft:pink_terracotta
setblock 340 91 465 minecraft:red_nether_bricks
fill 340 91 501 340 92 501 minecraft:pink_terracotta
setblock 341 91 464 minecraft:red_nether_bricks
setblock 341 91 504 minecraft:red_nether_bricks
fill 342 91 464 342 94 464 minecraft:pink_terracotta
setblock 342 91 503 minecraft:red_nether_bricks
fill 342 91 504 342 94 504 minecraft:pink_terracotta
setblock 343 91 502 minecraft:red_nether_bricks
fill 343 91 503 343 93 503 minecraft:pink_terracotta
setblock 344 91 502 minecraft:pink_terracotta
setblock 346 91 504 minecraft:red_nether_bricks
fill 347 91 504 347 92 504 minecraft:pink_terracotta
setblock 351 91 504 minecraft:red_nether_bricks
fill 352 91 504 355 91 504 minecraft:pink_terracotta
fill 353 91 464 355 91 464 minecraft:pink_terracotta
fill 355 91 503 356 91 503 minecraft:pink_terracotta
setblock 356 91 464 minecraft:red_nether_bricks
fill 356 91 465 356 94 465 minecraft:pink_terracotta
setblock 356 91 504 minecraft:red_nether_bricks
fill 357 91 464 357 94 464 minecraft:pink_terracotta
setblock 357 91 503 minecraft:red_nether_bricks
fill 357 91 504 360 91 504 minecraft:pink_terracotta
setblock 358 91 502 minecraft:red_nether_bricks
fill 358 91 503 358 94 503 minecraft:pink_terracotta
setblock 359 91 465 minecraft:pink_terracotta
setblock 359 91 466 minecraft:red_nether_bricks
setblock 359 91 502 minecraft:pink_terracotta
setblock 360 91 465 minecraft:red_nether_bricks
fill 360 91 466 360 94 466 minecraft:pink_terracotta
setblock 361 91 464 minecraft:red_nether_bricks
fill 361 91 465 361 94 465 minecraft:pink_terracotta
setblock 361 91 504 minecraft:red_nether_bricks
fill 362 91 464 362 94 464 minecraft:pink_terracotta
setblock 362 91 503 minecraft:red_nether_bricks
fill 362 91 504 362 94 504 minecraft:pink_terracotta
fill 363 91 503 363 93 503 minecraft:pink_terracotta
setblock 365 91 465 minecraft:red_nether_bricks
setblock 366 91 464 minecraft:red_nether_bricks
fill 366 91 465 366 94 465 minecraft:pink_terracotta
setblock 366 91 503 minecraft:pink_terracotta
setblock 366 91 504 minecraft:red_nether_bricks
fill 367 91 464 367 94 464 minecraft:pink_terracotta
setblock 367 91 503 minecraft:red_nether_bricks
fill 367 91 504 367 94 504 minecraft:pink_terracotta
fill 368 91 465 368 92 465 minecraft:pink_terracotta
fill 368 91 503 368 92 503 minecraft:pink_terracotta
setblock 369 91 502 minecraft:pink_terracotta
setblock 370 91 465 minecraft:red_nether_bricks
fill 370 91 466 370 94 466 minecraft:pink_terracotta
setblock 370 91 475 minecraft:red_nether_bricks
setblock 370 91 476 minecraft:pink_terracotta
setblock 370 91 480 minecraft:red_nether_bricks
fill 370 91 481 370 92 481 minecraft:pink_terracotta
setblock 370 91 500 minecraft:red_nether_bricks
fill 370 91 501 370 94 501 minecraft:pink_terracotta
setblock 330 92 464 minecraft:red_nether_bricks
fill 330 92 465 330 95 465 minecraft:pink_terracotta
setblock 330 92 472 minecraft:white_concrete
setblock 330 92 499 minecraft:red_nether_bricks
fill 330 92 500 330 95 500 minecraft:pink_terracotta
setblock 330 92 504 minecraft:red_nether_bricks
fill 331 92 464 334 92 464 minecraft:pink_terracotta
setblock 331 92 498 minecraft:red_nether_bricks
fill 331 92 499 331 93 499 minecraft:pink_terracotta
setblock 331 92 502 minecraft:pink_terracotta
setblock 331 92 503 minecraft:red_nether_bricks
fill 331 92 504 331 95 504 minecraft:pink_terracotta
setblock 332 92 502 minecraft:red_nether_bricks
fill 332 92 503 332 95 503 minecraft:pink_terracotta
fill 333 92 502 333 95 502 minecraft:pink_terracotta
setblock 334 92 465 minecraft:red_nether_bricks
setblock 334 92 501 minecraft:pink_terracotta
setblock 335 92 464 minecraft:red_nether_bricks
fill 335 92 465 335 95 465 minecraft:pink_terracotta
setblock 335 92 504 minecraft:red_nether_bricks
fill 336 92 464 336 95 464 minecraft:pink_terracotta
setblock 336 92 503 minecraft:red_nether_bricks
fill 336 92 504 336 95 504 minecraft:pink_terracotta
setblock 337 92 502 minecraft:red_nether_bricks
fill 337 92 503 337 95 503 minecraft:pink_terracotta
setblock 338 92 465 minecraft:pink_terracotta
setblock 338 92 501 minecraft:red_nether_bricks
fill 338 92 502 338 95 502 minecraft:pink_terracotta
setblock 339 92 465 minecraft:red_nether_bricks
fill 339 92 501 339 93 501 minecraft:pink_terracotta
setblock 340 92 464 minecraft:red_nether_bricks
setblock 340 92 465 minecraft:pink_terracotta
setblock 340 92 504 minecraft:red_nether_bricks
fill 341 92 464 341 95 464 minecraft:pink_terracotta
setblock 341 92 503 minecraft:red_nether_bricks
fill 341 92 504 341 95 504 minecraft:pink_terracotta
setblock 342 92 502 minecraft:red_nether_bricks
fill 342 92 503 342 94 503 minecraft:pink_terracotta
setblock 343 92 502 minecraft:pink_terracotta
setblock 345 92 504 minecraft:red_nether_bricks
fill 346 92 504 346 93 504 minecraft:pink_terracotta
fill 351 92 504 354 92 504 minecraft:pink_terracotta
fill 353 92 464 354 92 464 minecraft:pink_terracotta
setblock 355 92 464 minecraft:red_nether_bricks
fill 355 92 465 355 95 465 minecraft:pink_terracotta
setblock 355 92 503 minecraft:pink_terracotta
setblock 355 92 504 minecraft:red_nether_bricks
fill 356 92 464 356 95 464 minecraft:pink_terracotta
setblock 356 92 503 minecraft:red_nether_bricks
fill 356 92 504 359 92 504 minecraft:pink_terracotta
fill 357 92 503 357 95 503 minecraft:pink_terracotta
setblock 358 92 466 minecraft:red_nether_bricks
setblock 359 92 465 minecraft:red_nether_bricks
fill 359 92 466 359 95 466 minecraft:pink_terracotta
setblock 360 92 464 minecraft:red_nether_bricks
fill 360 92 465 360 95 465 minecraft:pink_terracotta
setblock 360 92 504 minecraft:red_nether_bricks
fill 361 92 464 361 95 464 minecraft:pink_terracotta
setblock 361 92 503 minecraft:red_nether_bricks
fill 361 92 504 361 95 504 minecraft:pink_terracotta
fill 362 92 503 362 94 503 minecraft:pink_terracotta
setblock 364 92 465 minecraft:red_nether_bricks
setblock 365 92 464 minecraft:red_nether_bricks
fill 365 92 465 365 95 465 minecraft:pink_terracotta
setblock 365 92 504 minecraft:red_nether_bricks
fill 366 92 464 366 95 464 minecraft:pink_terracotta
setblock 366 92 503 minecraft:red_nether_bricks
fill 366 92 504 366 95 504 minecraft:pink_terracotta
setblock 367 92 503 minecraft:pink_terracotta
setblock 370 92 464 minecraft:red_nether_bricks
fill 370 92 465 370 95 465 minecraft:pink_terracotta
setblock 370 92 471 minecraft:white_concrete
setblock 370 92 479 minecraft:red_nether_bricks
setblock 370 92 480 minecraft:pink_terracotta
setblock 370 92 482 minecraft:pink_terracotta
setblock 370 92 496 minecraft:white_concrete
fill 370 92 500 370 93 500 minecraft:pink_terracotta
setblock 370 92 504 minecraft:red_nether_bricks
fill 330 93 464 333 93 464 minecraft:pink_terracotta
setblock 330 93 478 minecraft:white_concrete
setblock 330 93 498 minecraft:red_nether_bricks
fill 330 93 499 330 96 499 minecraft:pink_terracotta
fill 330 93 501 330 93 502 minecraft:pink_terracotta
setblock 330 93 503 minecraft:red_nether_bricks
fill 330 93 504 330 96 504 minecraft:pink_terracotta
setblock 331 93 502 minecraft:red_nether_bricks
fill 331 93 503 331 96 503 minecraft:pink_terracotta
setblock 332 93 501 minecraft:red_nether_bricks
fill 332 93 502 332 94 502 minecraft:pink_terracotta
setblock 334 93 464 minecraft:red_nether_bricks
fill 334 93 465 334 96 465 minecraft:pink_terracotta
setblock 334 93 504 minecraft:red_nether_bricks
fill 335 93 464 335 96 464 minecraft:pink_terracotta
setblock 335 93 503 minecraft:red_nether_bricks
fill 335 93 504 335 96 504 minecraft:pink_terracotta
setblock 336 93 502 minecraft:red_nether_bricks
fill 336 93 503 336 96 503 minecraft:pink_terracotta
fill 337 93 501 337 114 501 minecraft:red_nether_bricks
fill 337 93 502 337 96 502 minecraft:pink_terracotta
setblock 338 93 465 minecraft:red_nether_bricks
setblock 338 93 501 minecraft:pink_terracotta
setblock 339 93 464 minecraft:red_nether_bricks
fill 339 93 465 339 94 465 minecraft:pink_terracotta
setblock 339 93 504 minecraft:red_nether_bricks
fill 340 93 464 340 96 464 minecraft:pink_terracotta
setblock 340 93 503 minecraft:red_nether_bricks
fill 340 93 504 340 96 504 minecraft:pink_terracotta
setblock 341 93 502 minecraft:red_nether_bricks
fill 341 93 503 341 95 503 minecraft:pink_terracotta
setblock 342 93 502 minecraft:pink_terracotta
setblock 344 93 504 minecraft:red_nether_bricks
fill 345 93 504 345 94 504 minecraft:pink_terracotta
setblock 348 93 504 minecraft:white_concrete
fill 351 93 504 353 93 504 minecraft:pink_terracotta
fill 352 93 464 353 93 464 minecraft:pink_terracotta
setblock 354 93 464 minecraft:red_nether_bricks
setblock 354 93 504 minecraft:red_nether_bricks
fill 355 93 464 355 96 464 minecraft:pink_terracotta
setblock 355 93 503 minecraft:red_nether_bricks
fill 355 93 504 358 93 504 minecraft:pink_terracotta
fill 356 93 503 356 95 503 minecraft:pink_terracotta
setblock 358 93 465 minecraft:red_nether_bricks
fill 358 93 466 358 96 466 minecraft:pink_terracotta
setblock 359 93 464 minecraft:red_nether_bricks
fill 359 93 465 359 96 465 minecraft:pink_terracotta
setblock 359 93 504 minecraft:red_nether_bricks
fill 360 93 464 360 96 464 minecraft:pink_terracotta
setblock 360 93 503 minecraft:red_nether_bricks
fill 360 93 504 360 96 504 minecraft:pink_terracotta
setblock 361 93 466 minecraft:pink_terracotta
fill 361 93 503 361 94 503 minecraft:pink_terracotta
setblock 363 93 465 minecraft:red_nether_bricks
setblock 364 93 464 minecraft:red_nether_bricks
fill 364 93 465 364 96 465 minecraft:pink_terracotta
setblock 364 93 504 minecraft:red_nether_bricks
fill 365 93 464 365 96 464 minecraft:pink_terracotta
fill 365 93 504 365 96 504 minecraft:pink_terracotta
setblock 369 93 464 minecraft:red_nether_bricks
fill 369 93 465 369 96 465 minecraft:pink_terracotta
setblock 369 93 504 minecraft:red_nether_bricks
fill 370 93 464 370 96 464 minecraft:pink_terracotta
setblock 370 93 468 minecraft:red_nether_bricks
setblock 370 93 490 minecraft:white_concrete
setblock 370 93 503 minecraft:red_nether_bricks
fill 370 93 504 370 96 504 minecraft:pink_terracotta
fill 330 94 464 332 94 464 minecraft:pink_terracotta
setblock 330 94 466 minecraft:pink_terracotta
setblock 330 94 484 minecraft:white_concrete
setblock 330 94 498 minecraft:pink_terracotta
setblock 330 94 501 minecraft:pink_terracotta
setblock 330 94 502 minecraft:red_nether_bricks
fill 330 94 503 330 97 503 minecraft:pink_terracotta
setblock 331 94 501 minecraft:red_nether_bricks
fill 331 94 502 331 97 502 minecraft:pink_terracotta
setblock 333 94 464 minecraft:red_nether_bricks
setblock 333 94 504 minecraft:red_nether_bricks
fill 334 94 464 334 97 464 minecraft:pink_terracotta
setblock 334 94 503 minecraft:red_nether_bricks
fill 334 94 504 334 97 504 minecraft:pink_terracotta
setblock 335 94 502 minecraft:red_nether_bricks
fill 335 94 503 335 97 503 minecraft:pink_terracotta
fill 336 94 502 336 96 502 minecraft:pink_terracotta
setblock 337 94 465 minecraft:red_nether_bricks
setblock 338 94 464 minecraft:red_nether_bricks
fill 338 94 465 338 95 465 minecraft:pink_terracotta
fill 338 94 501 338 114 501 minecraft:red_nether_bricks
setblock 338 94 504 minecraft:red_nether_bricks
fill 339 94 464 339 97 464 minecraft:pink_terracotta
setblock 339 94 503 minecraft:red_nether_bricks
fill 339 94 504 339 97 504 minecraft:pink_terracotta
setblock 340 94 502 minecraft:red_nether_bricks
fill 340 94 503 340 96 503 minecraft:pink_terracotta
setblock 343 94 504 minecraft:red_nether_bricks
fill 344 94 504 344 95 504 minecraft:pink_terracotta
setblock 346 94 464 minecraft:white_concrete
setblock 352 94 464 minecraft:pink_terracotta
setblock 352 94 504 minecraft:pink_terracotta
setblock 353 94 464 minecraft:red_nether_bricks
setblock 353 94 504 minecraft:red_nether_bricks
fill 354 94 464 354 96 465 minecraft:pink_terracotta
fill 354 94 504 357 94 504 minecraft:pink_terracotta
setblock 355 94 503 minecraft:pink_terracotta
setblock 357 94 465 minecraft:red_nether_bricks
fill 357 94 466 357 97 466 minecraft:pink_terracotta
setblock 358 94 464 minecraft:red_nether_bricks
fill 358 94 465 358 97 465 minecraft:pink_terracotta
setblock 358 94 504 minecraft:red_nether_bricks
fill 359 94 464 359 97 464 minecraft:pink_terracotta
setblock 359 94 503 minecraft:red_nether_bricks
fill 359 94 504 359 97 504 minecraft:pink_terracotta
fill 360 94 503 360 95 503 minecraft:pink_terracotta
setblock 361 94 466 minecraft:red_nether_bricks
setblock 362 94 465 minecraft:red_nether_bricks
setblock 363 94 464 minecraft:red_nether_bricks
fill 363 94 465 363 97 465 minecraft:pink_terracotta
setblock 363 94 504 minecraft:red_nether_bricks
fill 364 94 464 364 97 464 minecraft:pink_terracotta
fill 364 94 504 364 97 504 minecraft:pink_terracotta
setblock 368 94 464 minecraft:red_nether_bricks
setblock 368 94 504 minecraft:red_nether_bricks
fill 369 94 464 369 97 464 minecraft:pink_terracotta
fill 369 94 504 369 97 504 minecraft:pink_terracotta
setblock 370 94 467 minecraft:red_nether_bricks
fill 370 94 468 370 97 468 minecraft:pink_terracotta
setblock 370 94 484 minecraft:white_concrete
setblock 370 94 502 minecraft:red_nether_bricks
fill 370 94 503 370 97 503 minecraft:pink_terracotta
fill 330 95 464 331 95 464 minecraft:pink_terracotta
setblock 330 95 466 minecraft:red_nether_bricks
setblock 330 95 471 minecraft:white_concrete
setblock 330 95 485 minecraft:pink_terracotta
setblock 330 95 490 minecraft:white_concrete
setblock 330 95 501 minecraft:red_nether_bricks
fill 330 95 502 330 98 502 minecraft:pink_terracotta
setblock 331 95 500 minecraft:red_nether_bricks
fill 331 95 501 331 98 501 minecraft:pink_terracotta
setblock 332 95 464 minecraft:red_nether_bricks
setblock 332 95 504 minecraft:red_nether_bricks
fill 333 95 464 333 97 465 minecraft:pink_terracotta
setblock 333 95 503 minecraft:red_nether_bricks
fill 333 95 504 333 98 504 minecraft:pink_terracotta
setblock 334 95 502 minecraft:red_nether_bricks
fill 334 95 503 334 98 503 minecraft:pink_terracotta
fill 335 95 502 335 97 502 minecraft:pink_terracotta
setblock 336 95 465 minecraft:red_nether_bricks
setblock 337 95 464 minecraft:red_nether_bricks
fill 337 95 465 337 98 465 minecraft:pink_terracotta
setblock 337 95 504 minecraft:red_nether_bricks
fill 338 95 464 338 98 464 minecraft:pink_terracotta
setblock 338 95 503 minecraft:red_nether_bricks
fill 338 95 504 338 98 504 minecraft:pink_terracotta
setblock 339 95 502 minecraft:red_nether_bricks
fill 339 95 503 339 97 503 minecraft:pink_terracotta
setblock 342 95 464 minecraft:red_nether_bricks
setblock 342 95 504 minecraft:red_nether_bricks
setblock 343 95 504 minecraft:pink_terracotta
setblock 351 95 464 minecraft:pink_terracotta
setblock 352 95 464 minecraft:red_nether_bricks
setblock 352 95 504 minecraft:red_nether_bricks
fill 353 95 464 353 97 465 minecraft:pink_terracotta
fill 353 95 504 356 95 504 minecraft:pink_terracotta
setblock 356 95 465 minecraft:red_nether_bricks
fill 356 95 466 356 98 466 minecraft:pink_terracotta
setblock 357 95 464 minecraft:red_nether_bricks
fill 357 95 465 357 98 465 minecraft:pink_terracotta
setblock 357 95 504 minecraft:red_nether_bricks
fill 358 95 464 358 98 464 minecraft:pink_terracotta
setblock 358 95 503 minecraft:red_nether_bricks
fill 358 95 504 358 98 504 minecraft:pink_terracotta
setblock 359 95 503 minecraft:pink_terracotta
setblock 360 95 466 minecraft:red_nether_bricks
setblock 361 95 465 minecraft:red_nether_bricks
setblock 362 95 464 minecraft:red_nether_bricks
fill 362 95 465 362 98 465 minecraft:pink_terracotta
setblock 362 95 504 minecraft:red_nether_bricks
fill 363 95 464 363 98 464 minecraft:pink_terracotta
fill 363 95 504 363 98 504 minecraft:pink_terracotta
setblock 366 95 465 minecraft:red_nether_bricks
setblock 367 95 464 minecraft:red_nether_bricks
setblock 367 95 504 minecraft:red_nether_bricks
fill 368 95 464 368 98 464 minecraft:pink_terracotta
fill 368 95 504 368 98 504 minecraft:pink_terracotta
setblock 370 95 466 minecraft:red_nether_bricks
fill 370 95 467 370 98 467 minecraft:pink_terracotta
fill 370 95 472 370 96 472 minecraft:white_concrete
setblock 370 95 478 minecraft:white_concrete
setblock 370 95 497 minecraft:white_concrete
setblock 370 95 501 minecraft:red_nether_bricks
fill 370 95 502 370 98 502 minecraft:pink_terracotta
setblock 330 96 464 minecraft:pink_terracotta
setblock 330 96 465 minecraft:red_nether_bricks
fill 330 96 466 330 99 466 minecraft:pink_terracotta
setblock 330 96 477 minecraft:white_concrete
setblock 330 96 484 minecraft:pink_terracotta
setblock 330 96 485 minecraft:red_nether_bricks
fill 330 96 486 330 97 488 minecraft:pink_terracotta
setblock 330 96 496 minecraft:white_concrete
setblock 330 96 500 minecraft:red_nether_bricks
fill 330 96 501 330 99 501 minecraft:pink_terracotta
setblock 331 96 464 minecraft:red_nether_bricks
setblock 331 96 504 minecraft:red_nether_bricks
fill 332 96 464 332 99 464 minecraft:pink_terracotta
setblock 332 96 503 minecraft:red_nether_bricks
fill 332 96 504 332 99 504 minecraft:pink_terracotta
setblock 333 96 502 minecraft:red_nether_bricks
fill 333 96 503 333 99 503 minecraft:pink_terracotta
setblock 334 96 502 minecraft:pink_terracotta
setblock 335 96 465 minecraft:red_nether_bricks
setblock 336 96 464 minecraft:red_nether_bricks
fill 336 96 465 336 99 465 minecraft:pink_terracotta
setblock 336 96 504 minecraft:red_nether_bricks
fill 337 96 464 337 99 464 minecraft:pink_terracotta
setblock 337 96 503 minecraft:red_nether_bricks
fill 337 96 504 337 99 504 minecraft:pink_terracotta
fill 338 96 503 338 98 503 minecraft:pink_terracotta
setblock 341 96 464 minecraft:red_nether_bricks
setblock 341 96 504 minecraft:red_nether_bricks
setblock 342 96 504 minecraft:pink_terracotta
setblock 347 96 504 minecraft:white_concrete
setblock 351 96 464 minecraft:red_nether_bricks
fill 352 96 464 352 99 464 minecraft:pink_terracotta
fill 352 96 504 355 96 504 minecraft:pink_terracotta
setblock 355 96 465 minecraft:red_nether_bricks
setblock 356 96 464 minecraft:red_nether_bricks
fill 356 96 465 356 99 465 minecraft:pink_terracotta
setblock 356 96 504 minecraft:red_nether_bricks
fill 357 96 464 357 99 464 minecraft:pink_terracotta
fill 357 96 504 357 99 504 minecraft:pink_terracotta
setblock 359 96 466 minecraft:red_nether_bricks
setblock 360 96 465 minecraft:red_nether_bricks
fill 360 96 466 360 99 466 minecraft:pink_terracotta
setblock 361 96 464 minecraft:red_nether_bricks
fill 361 96 465 361 99 465 minecraft:pink_terracotta
setblock 361 96 504 minecraft:red_nether_bricks
fill 362 96 464 362 99 464 minecraft:pink_terracotta
fill 362 96 504 362 99 504 minecraft:pink_terracotta
setblock 365 96 465 minecraft:red_nether_bricks
setblock 366 96 464 minecraft:red_nether_bricks
fill 366 96 465 366 99 465 minecraft:pink_terracotta
setblock 366 96 504 minecraft:red_nether_bricks
fill 367 96 464 367 99 464 minecraft:pink_terracotta
fill 367 96 504 367 99 504 minecraft:pink_terracotta
fill 368 96 465 368 97 465 minecraft:pink_terracotta
setblock 370 96 465 minecraft:red_nether_bricks
fill 370 96 466 370 99 466 minecraft:pink_terracotta
setblock 370 96 491 minecraft:white_concrete
fill 370 96 501 370 99 501 minecraft:pink_terracotta
setblock 330 97 464 minecraft:red_nether_bricks
fill 330 97 465 330 100 465 minecraft:pink_terracotta
fill 330 97 467 330 98 467 minecraft:pink_terracotta
setblock 330 97 483 minecraft:white_concrete
setblock 330 97 484 minecraft:red_nether_bricks
fill 330 97 485 330 100 485 minecraft:pink_terracotta
setblock 330 97 489 minecraft:red_nether_bricks
fill 330 97 490 330 99 491 minecraft:pink_terracotta
setblock 330 97 499 minecraft:red_nether_bricks
fill 330 97 500 330 100 500 minecraft:pink_terracotta
setblock 330 97 504 minecraft:red_nether_bricks
fill 331 97 464 331 100 464 minecraft:pink_terracotta
fill 331 97 486 331 97 487 minecraft:pink_terracotta
setblock 331 97 488 minecraft:red_nether_bricks
setblock 331 97 503 minecraft:red_nether_bricks
fill 331 97 504 331 100 504 minecraft:pink_terracotta
fill 332 97 465 332 98 465 minecraft:pink_terracotta
setblock 332 97 466 minecraft:light[level=12]
setblock 332 97 474 minecraft:light[level=12]
setblock 332 97 482 minecraft:light[level=12]
setblock 332 97 490 minecraft:light[level=12]
setblock 332 97 498 minecraft:light[level=12]
fill 332 97 503 332 100 503 minecraft:pink_terracotta
setblock 334 97 465 minecraft:red_nether_bricks
setblock 335 97 464 minecraft:red_nether_bricks
fill 335 97 465 335 100 465 minecraft:pink_terracotta
setblock 335 97 504 minecraft:red_nether_bricks
fill 336 97 464 336 100 464 minecraft:pink_terracotta
setblock 336 97 503 minecraft:red_nether_bricks
fill 336 97 504 336 100 504 minecraft:pink_terracotta
fill 337 97 503 337 100 503 minecraft:pink_terracotta
setblock 340 97 464 minecraft:red_nether_bricks
setblock 340 97 466 minecraft:light[level=12]
setblock 340 97 474 minecraft:light[level=12]
setblock 340 97 482 minecraft:light[level=12]
setblock 340 97 490 minecraft:light[level=12]
setblock 340 97 498 minecraft:light[level=12]
setblock 340 97 504 minecraft:red_nether_bricks
setblock 341 97 504 minecraft:pink_terracotta
setblock 347 97 464 minecraft:white_concrete
setblock 348 97 466 minecraft:light[level=12]
setblock 348 97 474 minecraft:light[level=12]
setblock 348 97 482 minecraft:light[level=12]
setblock 348 97 490 minecraft:light[level=12]
setblock 348 97 498 minecraft:light[level=12]
setblock 350 97 464 minecraft:red_nether_bricks
fill 351 97 464 351 100 464 minecraft:pink_terracotta
fill 352 97 465 352 98 465 minecraft:pink_terracotta
fill 352 97 504 354 97 504 minecraft:pink_terracotta
setblock 354 97 464 minecraft:pink_terracotta
setblock 354 97 465 minecraft:red_nether_bricks
fill 354 97 466 355 99 466 minecraft:pink_terracotta
setblock 355 97 464 minecraft:red_nether_bricks
fill 355 97 465 355 100 465 minecraft:pink_terracotta
setblock 355 97 504 minecraft:red_nether_bricks
fill 356 97 464 356 100 464 minecraft:pink_terracotta
setblock 356 97 474 minecraft:light[level=12]
setblock 356 97 482 minecraft:light[level=12]
setblock 356 97 490 minecraft:light[level=12]
setblock 356 97 498 minecraft:light[level=12]
fill 356 97 504 356 100 504 minecraft:pink_terracotta
setblock 358 97 466 minecraft:red_nether_bricks
setblock 359 97 465 minecraft:red_nether_bricks
fill 359 97 466 359 100 466 minecraft:pink_terracotta
setblock 360 97 464 minecraft:red_nether_bricks
fill 360 97 465 360 100 465 minecraft:pink_terracotta
setblock 360 97 504 minecraft:red_nether_bricks
fill 361 97 464 361 100 464 minecraft:pink_terracotta
fill 361 97 504 361 100 504 minecraft:pink_terracotta
setblock 364 97 465 minecraft:red_nether_bricks
setblock 364 97 466 minecraft:light[level=12]
setblock 364 97 474 minecraft:light[level=12]
setblock 364 97 482 minecraft:light[level=12]
setblock 364 97 490 minecraft:light[level=12]
setblock 364 97 498 minecraft:light[level=12]
setblock 365 97 464 minecraft:red_nether_bricks
fill 365 97 465 365 100 465 minecraft:pink_terracotta
setblock 365 97 504 minecraft:red_nether_bricks
fill 366 97 464 366 100 464 minecraft:pink_terracotta
fill 366 97 504 366 100 504 minecraft:pink_terracotta
fill 367 97 465 367 98 465 minecraft:pink_terracotta
setblock 369 97 465 minecraft:red_nether_bricks
fill 369 97 466 369 100 466 minecraft:pink_terracotta
setblock 370 97 464 minecraft:red_nether_bricks
fill 370 97 465 370 100 465 minecraft:pink_terracotta
setblock 370 97 469 minecraft:red_nether_bricks
setblock 370 97 485 minecraft:white_concrete
setblock 370 97 504 minecraft:red_nether_bricks
fill 330 98 464 330 101 464 minecraft:pink_terracotta
setblock 330 98 468 minecraft:red_nether_bricks
fill 330 98 470 330 99 470 minecraft:white_concrete
setblock 330 98 483 minecraft:red_nether_bricks
fill 330 98 484 330 101 484 minecraft:pink_terracotta
fill 330 98 486 330 98 487 minecraft:pink_terracotta
setblock 330 98 488 minecraft:red_nether_bricks
fill 330 98 489 331 100 489 minecraft:pink_terracotta
setblock 330 98 492 minecraft:pink_terracotta
setblock 330 98 493 minecraft:red_nether_bricks
fill 330 98 494 330 100 495 minecraft:pink_terracotta
setblock 330 98 497 minecraft:pink_terracotta
setblock 330 98 498 minecraft:red_nether_bricks
fill 330 98 499 330 101 499 minecraft:pink_terracotta
setblock 330 98 503 minecraft:red_nether_bricks
fill 330 98 504 330 101 504 minecraft:pink_terracotta
fill 331 98 465 331 99 465 minecraft:pink_terracotta
fill 331 98 485 331 98 486 minecraft:pink_terracotta
setblock 331 98 487 minecraft:red_nether_bricks
fill 331 98 488 331 101 488 minecraft:pink_terracotta
fill 331 98 490 331 98 491 minecraft:pink_terracotta
setblock 331 98 502 minecraft:red_nether_bricks
fill 331 98 503 331 101 503 minecraft:pink_terracotta
setblock 333 98 464 minecraft:pink_terracotta
setblock 333 98 465 minecraft:red_nether_bricks
setblock 334 98 464 minecraft:red_nether_bricks
fill 334 98 465 334 101 465 minecraft:pink_terracotta
setblock 334 98 504 minecraft:red_nether_bricks
fill 335 98 464 335 101 464 minecraft:pink_terracotta
setblock 335 98 503 minecraft:red_nether_bricks
fill 335 98 504 335 101 504 minecraft:pink_terracotta
fill 336 98 503 336 101 503 minecraft:pink_terracotta
setblock 339 98 464 minecraft:red_nether_bricks
setblock 339 98 504 minecraft:red_nether_bricks
fill 340 98 464 340 100 464 minecraft:pink_terracotta
fill 340 98 504 340 99 504 minecraft:pink_terracotta
setblock 341 98 464 minecraft:white_concrete
setblock 349 98 464 minecraft:red_nether_bricks
fill 350 98 464 350 101 464 minecraft:pink_terracotta
fill 351 98 465 351 99 465 minecraft:pink_terracotta
fill 352 98 504 353 98 504 minecraft:pink_terracotta
setblock 353 98 464 minecraft:pink_terracotta
setblock 353 98 465 minecraft:red_nether_bricks
fill 353 98 466 353 101 466 minecraft:pink_terracotta
setblock 354 98 464 minecraft:red_nether_bricks
fill 354 98 465 354 101 465 minecraft:pink_terracotta
setblock 354 98 504 minecraft:red_nether_bricks
fill 355 98 464 355 101 464 minecraft:pink_terracotta
fill 355 98 504 355 101 504 minecraft:pink_terracotta
setblock 357 98 466 minecraft:red_nether_bricks
setblock 358 98 465 minecraft:red_nether_bricks
fill 358 98 466 358 101 466 minecraft:pink_terracotta
setblock 359 98 464 minecraft:red_nether_bricks
fill 359 98 465 359 101 465 minecraft:pink_terracotta
setblock 359 98 504 minecraft:red_nether_bricks
fill 360 98 464 360 101 464 minecraft:pink_terracotta
fill 360 98 504 360 101 504 minecraft:pink_terracotta
setblock 363 98 465 minecraft:red_nether_bricks
setblock 364 98 464 minecraft:red_nether_bricks
fill 364 98 465 364 101 465 minecraft:pink_terracotta
fill 365 98 464 365 101 464 minecraft:pink_terracotta
setblock 368 98 465 minecraft:red_nether_bricks
setblock 369 98 464 minecraft:red_nether_bricks
fill 369 98 465 369 101 465 minecraft:pink_terracotta
fill 369 98 467 369 99 467 minecraft:pink_terracotta
setblock 369 98 504 minecraft:red_nether_bricks
fill 370 98 464 370 101 464 minecraft:pink_terracotta
setblock 370 98 468 minecraft:red_nether_bricks
fill 370 98 469 370 100 470 minecraft:pink_terracotta
setblock 370 98 479 minecraft:white_concrete
setblock 370 98 498 minecraft:white_concrete
setblock 370 98 503 minecraft:red_nether_bricks
fill 370 98 504 370 101 504 minecraft:pink_terracotta
setblock 330 99 467 minecraft:red_nether_bricks
fill 330 99 468 330 101 469 minecraft:pink_terracotta
setblock 330 99 476 minecraft:white_concrete
fill 330 99 483 330 102 483 minecraft:pink_terracotta
setblock 330 99 486 minecraft:pink_terracotta
setblock 330 99 487 minecraft:red_nether_bricks
fill 330 99 488 330 102 488 minecraft:pink_terracotta
setblock 330 99 492 minecraft:red_nether_bricks
fill 330 99 493 331 101 493 minecraft:pink_terracotta
setblock 330 99 496 minecraft:pink_terracotta
setblock 330 99 497 minecraft:red_nether_bricks
fill 330 99 498 330 102 498 minecraft:pink_terracotta
setblock 330 99 502 minecraft:red_nether_bricks
fill 330 99 503 330 102 503 minecraft:pink_terracotta
setblock 331 99 466 minecraft:red_nether_bricks
fill 331 99 484 331 99 485 minecraft:pink_terracotta
setblock 331 99 486 minecraft:red_nether_bricks
fill 331 99 487 332 101 487 minecraft:pink_terracotta
setblock 331 99 490 minecraft:pink_terracotta
setblock 331 99 491 minecraft:red_nether_bricks
fill 331 99 492 331 102 492 minecraft:pink_terracotta
fill 331 99 494 331 100 494 minecraft:pink_terracotta
setblock 331 99 501 minecraft:red_nether_bricks
fill 331 99 502 331 102 502 minecraft:pink_terracotta
setblock 332 99 465 minecraft:red_nether_bricks
fill 332 99 486 332 102 486 minecraft:pink_terracotta
fill 332 99 488 332 99 489 minecraft:pink_terracotta
setblock 332 99 490 minecraft:red_nether_bricks
fill 332 99 491 332 102 491 minecraft:pink_terracotta
setblock 333 99 464 minecraft:red_nether_bricks
fill 333 99 465 333 102 465 minecraft:pink_terracotta
setblock 333 99 504 minecraft:red_nether_bricks
fill 334 99 464 334 102 464 minecraft:pink_terracotta
setblock 334 99 503 minecraft:red_nether_bricks
fill 334 99 504 334 102 504 minecraft:pink_terracotta
fill 335 99 503 335 102 503 minecraft:pink_terracotta
setblock 337 99 465 minecraft:red_nether_bricks
setblock 338 99 464 minecraft:red_nether_bricks
setblock 338 99 504 minecraft:red_nether_bricks
fill 339 99 464 339 102 464 minecraft:pink_terracotta
fill 339 99 504 339 101 504 minecraft:pink_terracotta
setblock 346 99 504 minecraft:white_concrete
setblock 348 99 464 minecraft:red_nether_bricks
fill 349 99 464 349 102 464 minecraft:pink_terracotta
fill 350 99 465 350 100 465 minecraft:pink_terracotta
setblock 352 99 465 minecraft:red_nether_bricks
fill 352 99 466 352 102 466 minecraft:pink_terracotta
setblock 352 99 504 minecraft:pink_terracotta
setblock 353 99 464 minecraft:red_nether_bricks
fill 353 99 465 353 102 465 minecraft:pink_terracotta
setblock 353 99 504 minecraft:red_nether_bricks
fill 354 99 464 354 102 464 minecraft:pink_terracotta
fill 354 99 504 354 102 504 minecraft:pink_terracotta
setblock 356 99 466 minecraft:red_nether_bricks
fill 356 99 467 356 102 467 minecraft:pink_terracotta
setblock 357 99 465 minecraft:red_nether_bricks
fill 357 99 466 357 102 466 minecraft:pink_terracotta
setblock 358 99 464 minecraft:red_nether_bricks
fill 358 99 465 358 102 465 minecraft:pink_terracotta
setblock 358 99 504 minecraft:red_nether_bricks
fill 359 99 464 359 102 464 minecraft:pink_terracotta
fill 359 99 504 359 102 504 minecraft:pink_terracotta
setblock 361 99 466 minecraft:red_nether_bricks
setblock 362 99 465 minecraft:red_nether_bricks
setblock 363 99 464 minecraft:red_nether_bricks
fill 363 99 465 363 102 465 minecraft:pink_terracotta
fill 364 99 464 364 102 464 minecraft:pink_terracotta
setblock 365 99 504 minecraft:white_concrete
setblock 367 99 465 minecraft:red_nether_bricks
setblock 368 99 464 minecraft:red_nether_bricks
fill 368 99 465 368 102 465 minecraft:pink_terracotta
setblock 368 99 504 minecraft:red_nether_bricks
fill 369 99 464 369 102 464 minecraft:pink_terracotta
setblock 369 99 468 minecraft:red_nether_bricks
fill 369 99 504 369 102 504 minecraft:pink_terracotta
setblock 370 99 467 minecraft:red_nether_bricks
fill 370 99 468 370 102 468 minecraft:pink_terracotta
setblock 370 99 471 minecraft:pink_terracotta
setblock 370 99 473 minecraft:white_concrete
fill 370 99 485 370 99 486 minecraft:pink_terracotta
setblock 370 99 487 minecraft:red_nether_bricks
fill 370 99 488 370 100 490 minecraft:pink_terracotta
setblock 370 99 492 minecraft:white_concrete
fill 370 99 500 370 100 500 minecraft:pink_terracotta
setblock 370 99 502 minecraft:red_nether_bricks
fill 370 99 503 370 102 503 minecraft:pink_terracotta
setblock 330 100 466 minecraft:red_nether_bricks
fill 330 100 467 331 102 467 minecraft:pink_terracotta
setblock 330 100 470 minecraft:pink_terracotta
fill 330 100 482 330 103 482 minecraft:pink_terracotta
setblock 330 100 486 minecraft:red_nether_bricks
fill 330 100 487 330 103 487 minecraft:pink_terracotta
setblock 330 100 490 minecraft:pink_terracotta
setblock 330 100 491 minecraft:red_nether_bricks
fill 330 100 492 330 103 492 minecraft:pink_terracotta
setblock 330 100 496 minecraft:red_nether_bricks
fill 330 100 497 331 102 497 minecraft:pink_terracotta
setblock 330 100 501 minecraft:red_nether_bricks
fill 330 100 502 330 103 502 minecraft:pink_terracotta
setblock 331 100 465 minecraft:red_nether_bricks
fill 331 100 466 331 103 466 minecraft:pink_terracotta
fill 331 100 468 331 101 468 minecraft:pink_terracotta
fill 331 100 483 331 100 484 minecraft:pink_terracotta
setblock 331 100 485 minecraft:red_nether_bricks
fill 331 100 486 331 103 486 minecraft:pink_terracotta
setblock 331 100 490 minecraft:red_nether_bricks
fill 331 100 491 331 103 491 minecraft:pink_terracotta
setblock 331 100 495 minecraft:red_nether_bricks
fill 331 100 496 331 103 496 minecraft:pink_terracotta
fill 331 100 498 331 100 499 minecraft:pink_terracotta
setblock 331 100 500 minecraft:red_nether_bricks
fill 331 100 501 331 103 501 minecraft:pink_terracotta
setblock 332 100 464 minecraft:red_nether_bricks
fill 332 100 465 332 103 465 minecraft:pink_terracotta
fill 332 100 485 332 103 485 minecraft:pink_terracotta
setblock 332 100 488 minecraft:pink_terracotta
setblock 332 100 489 minecraft:red_nether_bricks
fill 332 100 490 333 102 490 minecraft:pink_terracotta
fill 332 100 492 332 100 493 minecraft:pink_terracotta
setblock 332 100 494 minecraft:red_nether_bricks
setblock 332 100 504 minecraft:red_nether_bricks
fill 333 100 464 333 103 464 minecraft:pink_terracotta
setblock 333 100 487 minecraft:pink_terracotta
setblock 333 100 488 minecraft:red_nether_bricks
fill 333 100 489 333 103 489 minecraft:pink_terracotta
fill 333 100 491 333 101 491 minecraft:pink_terracotta
setblock 333 100 503 minecraft:red_nether_bricks
fill 333 100 504 333 103 504 minecraft:pink_terracotta
fill 334 100 503 334 103 503 minecraft:pink_terracotta
setblock 336 100 465 minecraft:red_nether_bricks
setblock 337 100 464 minecraft:red_nether_bricks
fill 337 100 465 337 102 465 minecraft:pink_terracotta
setblock 337 100 504 minecraft:red_nether_bricks
fill 338 100 464 338 103 464 minecraft:pink_terracotta
fill 338 100 504 338 102 504 minecraft:pink_terracotta
setblock 347 100 464 minecraft:red_nether_bricks
fill 348 100 464 348 103 464 minecraft:pink_terracotta
fill 349 100 465 349 101 465 minecraft:pink_terracotta
setblock 351 100 465 minecraft:red_nether_bricks
fill 351 100 466 351 103 466 minecraft:pink_terracotta
setblock 351 100 504 minecraft:pink_terracotta
setblock 352 100 464 minecraft:red_nether_bricks
fill 352 100 465 352 103 465 minecraft:pink_terracotta
setblock 352 100 504 minecraft:red_nether_bricks
fill 353 100 464 353 103 464 minecraft:pink_terracotta
setblock 353 100 467 minecraft:pink_terracotta
fill 353 100 504 353 103 504 minecraft:pink_terracotta
setblock 354 100 466 minecraft:pink_terracotta
setblock 354 100 467 minecraft:red_nether_bricks
setblock 355 100 466 minecraft:red_nether_bricks
fill 355 100 467 355 103 467 minecraft:pink_terracotta
setblock 356 100 465 minecraft:red_nether_bricks
fill 356 100 466 356 103 466 minecraft:pink_terracotta
setblock 357 100 464 minecraft:red_nether_bricks
fill 357 100 465 357 103 465 minecraft:pink_terracotta
fill 357 100 467 357 101 467 minecraft:pink_terracotta
setblock 357 100 504 minecraft:red_nether_bricks
fill 358 100 464 358 103 464 minecraft:pink_terracotta
fill 358 100 504 358 103 504 minecraft:pink_terracotta
setblock 360 100 466 minecraft:red_nether_bricks
fill 360 100 479 361 101 479 minecraft:pink_concrete
setblock 361 100 465 minecraft:red_nether_bricks
fill 361 100 466 361 103 466 minecraft:pink_terracotta
setblock 362 100 464 minecraft:red_nether_bricks
fill 362 100 465 362 103 465 minecraft:pink_terracotta
fill 363 100 464 363 103 464 minecraft:pink_terracotta
fill 365 100 504 365 101 504 minecraft:pink_terracotta
setblock 366 100 465 minecraft:red_nether_bricks
setblock 367 100 464 minecraft:red_nether_bricks
fill 367 100 465 367 103 465 minecraft:pink_terracotta
setblock 367 100 504 minecraft:red_nether_bricks
fill 368 100 464 368 103 464 minecraft:pink_terracotta
fill 368 100 504 368 103 504 minecraft:pink_terracotta
setblock 369 100 467 minecraft:red_nether_bricks
fill 369 100 468 369 102 469 minecraft:pink_terracotta
setblock 370 100 466 minecraft:red_nether_bricks
fill 370 100 467 370 103 467 minecraft:pink_terracotta
setblock 370 100 471 minecraft:red_nether_bricks
fill 370 100 472 370 103 472 minecraft:pink_terracotta
fill 370 100 484 370 100 485 minecraft:pink_terracotta
setblock 370 100 486 minecraft:red_nether_bricks
fill 370 100 487 370 103 487 minecraft:pink_terracotta
setblock 370 100 491 minecraft:red_nether_bricks
fill 370 100 492 370 100 495 minecraft:pink_terracotta
fill 370 100 499 370 101 499 minecraft:pink_terracotta
setblock 370 100 501 minecraft:red_nether_bricks
fill 370 100 502 370 103 502 minecraft:pink_terracotta
setblock 330 101 465 minecraft:red_nether_bricks
fill 330 101 466 330 104 466 minecraft:pink_terracotta
setblock 330 101 470 minecraft:red_nether_bricks
fill 330 101 471 330 103 472 minecraft:pink_terracotta
fill 330 101 481 330 104 481 minecraft:pink_terracotta
setblock 330 101 485 minecraft:red_nether_bricks
fill 330 101 486 330 104 486 minecraft:pink_terracotta
setblock 330 101 489 minecraft:pink_terracotta
setblock 330 101 490 minecraft:red_nether_bricks
fill 330 101 491 330 104 491 minecraft:pink_terracotta
setblock 330 101 494 minecraft:pink_terracotta
setblock 330 101 495 minecraft:red_nether_bricks
fill 330 101 496 330 104 496 minecraft:pink_terracotta
setblock 330 101 500 minecraft:red_nether_bricks
fill 330 101 501 330 104 501 minecraft:pink_terracotta
setblock 331 101 464 minecraft:red_nether_bricks
fill 331 101 465 331 104 465 minecraft:pink_terracotta
setblock 331 101 469 minecraft:red_nether_bricks
fill 331 101 470 331 104 470 minecraft:pink_terracotta
setblock 331 101 483 minecraft:pink_terracotta
setblock 331 101 484 minecraft:red_nether_bricks
fill 331 101 485 331 104 485 minecraft:pink_terracotta
setblock 331 101 489 minecraft:red_nether_bricks
fill 331 101 490 331 104 490 minecraft:pink_terracotta
setblock 331 101 494 minecraft:red_nether_bricks
fill 331 101 495 332 103 495 minecraft:pink_terracotta
setblock 331 101 498 minecraft:pink_terracotta
setblock 331 101 499 minecraft:red_nether_bricks
fill 331 101 500 331 104 500 minecraft:pink_terracotta
setblock 331 101 504 minecraft:red_nether_bricks
fill 332 101 464 332 104 464 minecraft:pink_terracotta
fill 332 101 484 332 104 484 minecraft:pink_terracotta
setblock 332 101 488 minecraft:red_nether_bricks
fill 332 101 489 332 104 489 minecraft:pink_terracotta
setblock 332 101 492 minecraft:pink_terracotta
setblock 332 101 493 minecraft:red_nether_bricks
fill 332 101 494 332 104 494 minecraft:pink_terracotta
fill 332 101 496 332 102 496 minecraft:pink_terracotta
setblock 332 101 503 minecraft:red_nether_bricks
fill 332 101 504 332 104 504 minecraft:pink_terracotta
setblock 333 101 486 minecraft:pink_terracotta
setblock 333 101 487 minecraft:red_nether_bricks
fill 333 101 488 333 104 488 minecraft:pink_terracotta
setblock 333 101 492 minecraft:red_nether_bricks
fill 333 101 493 333 104 493 minecraft:pink_terracotta
fill 333 101 503 333 104 503 minecraft:pink_terracotta
setblock 335 101 465 minecraft:red_nether_bricks
setblock 336 101 464 minecraft:red_nether_bricks
fill 336 101 465 336 103 465 minecraft:pink_terracotta
setblock 336 101 504 minecraft:red_nether_bricks
fill 337 101 464 337 104 464 minecraft:pink_terracotta
fill 337 101 493 337 102 493 minecraft:red_concrete
fill 337 101 504 337 103 504 minecraft:pink_terracotta
setblock 342 101 464 minecraft:white_concrete
fill 347 101 464 347 104 464 minecraft:pink_terracotta
fill 348 101 465 348 102 465 minecraft:pink_terracotta
setblock 350 101 465 minecraft:red_nether_bricks
fill 350 101 466 350 104 466 minecraft:pink_terracotta
setblock 351 101 464 minecraft:red_nether_bricks
fill 351 101 465 351 104 465 minecraft:pink_terracotta
setblock 351 101 504 minecraft:red_nether_bricks
fill 352 101 464 352 104 464 minecraft:pink_terracotta
setblock 352 101 467 minecraft:pink_terracotta
fill 352 101 504 352 104 504 minecraft:pink_terracotta
setblock 353 101 467 minecraft:red_nether_bricks
setblock 354 101 466 minecraft:red_nether_bricks
fill 354 101 467 354 104 467 minecraft:pink_terracotta
setblock 355 101 465 minecraft:red_nether_bricks
fill 355 101 466 355 104 466 minecraft:pink_terracotta
setblock 356 101 464 minecraft:red_nether_bricks
fill 356 101 465 356 104 465 minecraft:pink_terracotta
setblock 356 101 504 minecraft:red_nether_bricks
fill 357 101 464 357 104 464 minecraft:pink_terracotta
fill 357 101 504 357 104 504 minecraft:pink_terracotta
setblock 358 101 467 minecraft:red_nether_bricks
setblock 359 101 466 minecraft:red_nether_bricks
setblock 360 101 465 minecraft:red_nether_bricks
fill 360 101 466 360 104 466 minecraft:pink_terracotta
setblock 361 101 464 minecraft:red_nether_bricks
fill 361 101 465 361 104 465 minecraft:pink_terracotta
setblock 361 101 504 minecraft:red_nether_bricks
fill 362 101 464 362 104 464 minecraft:pink_terracotta
fill 362 101 466 362 102 466 minecraft:pink_terracotta
fill 364 101 504 364 102 504 minecraft:pink_terracotta
setblock 365 101 465 minecraft:red_nether_bricks
setblock 366 101 464 minecraft:red_nether_bricks
fill 366 101 465 366 104 465 minecraft:pink_terracotta
setblock 366 101 504 minecraft:red_nether_bricks
fill 367 101 464 367 104 464 minecraft:pink_terracotta
fill 367 101 466 368 101 466 minecraft:pink_terracotta
fill 367 101 504 367 104 504 minecraft:pink_terracotta
setblock 368 101 467 minecraft:red_nether_bricks
setblock 369 101 466 minecraft:red_nether_bricks
fill 369 101 467 369 104 467 minecraft:pink_terracotta
setblock 369 101 470 minecraft:pink_terracotta
fill 369 101 489 370 101 489 minecraft:pink_terracotta
fill 369 101 503 369 103 503 minecraft:pink_terracotta
setblock 370 101 465 minecraft:red_nether_bricks
fill 370 101 466 370 104 466 minecraft:pink_terracotta
setblock 370 101 469 minecraft:pink_terracotta
setblock 370 101 470 minecraft:red_nether_bricks
fill 370 101 471 370 104 471 minecraft:pink_terracotta
fill 370 101 473 370 102 473 minecraft:pink_terracotta
setblock 370 101 480 minecraft:white_concrete
fill 370 101 483 370 101 484 minecraft:pink_terracotta
setblock 370 101 485 minecraft:red_nether_bricks
fill 370 101 486 370 104 486 minecraft:pink_terracotta
fill 370 101 488 370 102 488 minecraft:pink_terracotta
setblock 370 101 490 minecraft:red_nether_bricks
fill 370 101 491 370 101 494 minecraft:pink_terracotta
setblock 370 101 495 minecraft:red_nether_bricks
fill 370 101 496 370 102 498 minecraft:pink_terracotta
setblock 370 101 500 minecraft:red_nether_bricks
fill 370 101 501 370 104 501 minecraft:pink_terracotta
setblock 330 102 464 minecraft:red_nether_bricks
fill 330 102 465 330 105 465 minecraft:pink_terracotta
setblock 330 102 468 minecraft:pink_terracotta
setblock 330 102 469 minecraft:red_nether_bricks
fill 330 102 470 330 105 470 minecraft:pink_terracotta
setblock 330 102 473 minecraft:pink_terracotta
setblock 330 102 474 minecraft:red_nether_bricks
setblock 330 102 484 minecraft:red_nether_bricks
fill 330 102 485 330 105 485 minecraft:pink_terracotta
setblock 330 102 489 minecraft:red_nether_bricks
fill 330 102 490 330 105 490 minecraft:pink_terracotta
setblock 330 102 493 minecraft:pink_terracotta
setblock 330 102 494 minecraft:red_nether_bricks
fill 330 102 495 330 105 495 minecraft:pink_terracotta
setblock 330 102 499 minecraft:red_nether_bricks
fill 330 102 500 330 105 500 minecraft:pink_terracotta
setblock 330 102 504 minecraft:red_nether_bricks
fill 331 102 464 331 105 464 minecraft:pink_terracotta
setblock 331 102 468 minecraft:red_nether_bricks
fill 331 102 469 331 105 469 minecraft:pink_terracotta
fill 331 102 471 331 103 471 minecraft:pink_terracotta
setblock 331 102 482 minecraft:pink_terracotta
setblock 331 102 483 minecraft:red_nether_bricks
fill 331 102 484 331 105 484 minecraft:pink_terracotta
setblock 331 102 487 minecraft:pink_terracotta
setblock 331 102 488 minecraft:red_nether_bricks
fill 331 102 489 331 105 489 minecraft:pink_terracotta
setblock 331 102 493 minecraft:red_nether_bricks
fill 331 102 494 331 105 494 minecraft:pink_terracotta
setblock 331 102 498 minecraft:red_nether_bricks
fill 331 102 499 331 105 499 minecraft:pink_terracotta
setblock 331 102 503 minecraft:red_nether_bricks
fill 331 102 504 331 105 504 minecraft:pink_terracotta
setblock 332 102 466 minecraft:pink_terracotta
setblock 332 102 467 minecraft:red_nether_bricks
fill 332 102 468 332 105 468 minecraft:pink_terracotta
setblock 332 102 487 minecraft:red_nether_bricks
fill 332 102 488 332 105 488 minecraft:pink_terracotta
setblock 332 102 492 minecraft:red_nether_bricks
fill 332 102 493 332 105 493 minecraft:pink_terracotta
setblock 332 102 497 minecraft:red_nether_bricks
fill 332 102 498 332 105 498 minecraft:pink_terracotta
fill 332 102 503 332 105 503 minecraft:pink_terracotta
setblock 333 102 466 minecraft:red_nether_bricks
setblock 333 102 486 minecraft:red_nether_bricks
fill 333 102 487 333 105 487 minecraft:pink_terracotta
setblock 333 102 491 minecraft:red_nether_bricks
fill 333 102 492 333 105 492 minecraft:pink_terracotta
fill 333 102 494 333 103 494 minecraft:pink_terracotta
setblock 334 102 465 minecraft:red_nether_bricks
setblock 334 102 489 minecraft:pink_terracotta
setblock 334 102 490 minecraft:red_nether_bricks
setblock 335 102 464 minecraft:red_nether_bricks
fill 335 102 465 335 104 465 minecraft:pink_terracotta
setblock 335 102 504 minecraft:red_nether_bricks
fill 336 102 464 336 105 464 minecraft:pink_terracotta
fill 336 102 504 336 104 504 minecraft:pink_terracotta
setblock 339 102 504 minecraft:white_concrete
fill 346 102 464 346 105 464 minecraft:pink_terracotta
setblock 349 102 465 minecraft:red_nether_bricks
fill 349 102 466 349 105 466 minecraft:pink_terracotta
setblock 350 102 464 minecraft:red_nether_bricks
fill 350 102 465 350 105 465 minecraft:pink_terracotta
setblock 350 102 504 minecraft:red_nether_bricks
fill 351 102 464 351 105 464 minecraft:pink_terracotta
setblock 351 102 467 minecraft:pink_terracotta
fill 351 102 504 351 105 504 minecraft:pink_terracotta
setblock 352 102 467 minecraft:red_nether_bricks
setblock 353 102 466 minecraft:red_nether_bricks
fill 353 102 467 353 105 467 minecraft:pink_terracotta
setblock 354 102 465 minecraft:red_nether_bricks
fill 354 102 466 354 105 466 minecraft:pink_terracotta
setblock 355 102 464 minecraft:red_nether_bricks
fill 355 102 465 355 105 465 minecraft:pink_terracotta
setblock 355 102 504 minecraft:red_nether_bricks
fill 356 102 464 356 105 464 minecraft:pink_terracotta
fill 356 102 504 356 105 504 minecraft:pink_terracotta
setblock 357 102 467 minecraft:red_nether_bricks
setblock 358 102 466 minecraft:red_nether_bricks
fill 358 102 467 358 103 467 minecraft:pink_terracotta
setblock 359 102 465 minecraft:red_nether_bricks
fill 359 102 466 359 105 466 minecraft:pink_terracotta
setblock 360 102 464 minecraft:red_nether_bricks
fill 360 102 465 360 105 465 minecraft:pink_terracotta
setblock 360 102 504 minecraft:red_nether_bricks
fill 361 102 464 361 105 464 minecraft:pink_terracotta
setblock 361 102 504 minecraft:pink_terracotta
setblock 364 102 465 minecraft:red_nether_bricks
setblock 365 102 464 minecraft:red_nether_bricks
fill 365 102 465 365 105 465 minecraft:pink_terracotta
setblock 365 102 504 minecraft:red_nether_bricks
fill 366 102 464 366 105 464 minecraft:pink_terracotta
fill 366 102 466 367 102 466 minecraft:pink_terracotta
fill 366 102 504 366 105 504 minecraft:pink_terracotta
setblock 368 102 466 minecraft:red_nether_bricks
fill 368 102 467 368 103 469 minecraft:pink_terracotta
fill 368 102 503 368 104 503 minecraft:pink_terracotta
setblock 369 102 465 minecraft:red_nether_bricks
fill 369 102 466 369 105 466 minecraft:pink_terracotta
setblock 369 102 470 minecraft:red_nether_bricks
fill 369 102 471 369 104 472 minecraft:pink_terracotta
fill 369 102 487 369 102 489 minecraft:pink_terracotta
setblock 369 102 490 minecraft:red_nether_bricks
fill 369 102 491 369 102 494 minecraft:pink_terracotta
fill 369 102 502 369 104 502 minecraft:pink_terracotta
setblock 370 102 464 minecraft:red_nether_bricks
fill 370 102 465 370 105 465 minecraft:pink_terracotta
setblock 370 102 469 minecraft:red_nether_bricks
fill 370 102 470 370 105 470 minecraft:pink_terracotta
setblock 370 102 474 minecraft:red_nether_bricks
setblock 370 102 483 minecraft:pink_terracotta
setblock 370 102 484 minecraft:red_nether_bricks
fill 370 102 485 370 105 485 minecraft:pink_terracotta
setblock 370 102 489 minecraft:red_nether_bricks
fill 370 102 490 370 102 493 minecraft:pink_terracotta
setblock 370 102 494 minecraft:red_nether_bricks
fill 370 102 495 370 105 495 minecraft:pink_terracotta
setblock 370 102 499 minecraft:red_nether_bricks
fill 370 102 500 370 105 500 minecraft:pink_terracotta
setblock 370 102 504 minecraft:red_nether_bricks
fill 330 103 464 330 106 464 minecraft:pink_terracotta
setblock 330 103 467 minecraft:pink_terracotta
setblock 330 103 468 minecraft:red_nether_bricks
fill 330 103 469 330 106 469 minecraft:pink_terracotta
setblock 330 103 473 minecraft:red_nether_bricks
fill 330 103 474 330 103 477 minecraft:pink_terracotta
setblock 330 103 478 minecraft:red_nether_bricks
fill 330 103 479 330 105 480 minecraft:pink_terracotta
setblock 330 103 483 minecraft:red_nether_bricks
fill 330 103 484 330 106 484 minecraft:pink_terracotta
setblock 330 103 488 minecraft:red_nether_bricks
fill 330 103 489 330 106 489 minecraft:pink_terracotta
setblock 330 103 493 minecraft:red_nether_bricks
fill 330 103 494 330 106 494 minecraft:pink_terracotta
setblock 330 103 497 minecraft:pink_terracotta
setblock 330 103 498 minecraft:red_nether_bricks
fill 330 103 499 330 106 499 minecraft:pink_terracotta
setblock 330 103 503 minecraft:red_nether_bricks
fill 330 103 504 330 106 504 minecraft:pink_terracotta
setblock 331 103 467 minecraft:red_nether_bricks
fill 331 103 468 331 106 468 minecraft:pink_terracotta
setblock 331 103 472 minecraft:red_nether_bricks
fill 331 103 473 331 106 473 minecraft:pink_terracotta
setblock 331 103 482 minecraft:red_nether_bricks
fill 331 103 483 331 106 483 minecraft:pink_terracotta
setblock 331 103 487 minecraft:red_nether_bricks
fill 331 103 488 331 106 488 minecraft:pink_terracotta
setblock 331 103 492 minecraft:red_nether_bricks
fill 331 103 493 331 106 493 minecraft:pink_terracotta
setblock 331 103 497 minecraft:red_nether_bricks
fill 331 103 498 331 106 498 minecraft:pink_terracotta
setblock 331 103 502 minecraft:red_nether_bricks
fill 331 103 503 331 106 503 minecraft:pink_terracotta
setblock 332 103 466 minecraft:red_nether_bricks
fill 332 103 467 332 104 467 minecraft:pink_terracotta
fill 332 103 469 332 104 469 minecraft:pink_terracotta
setblock 332 103 486 minecraft:red_nether_bricks
fill 332 103 487 332 106 487 minecraft:pink_terracotta
setblock 332 103 490 minecraft:pink_terracotta
setblock 332 103 491 minecraft:red_nether_bricks
fill 332 103 492 332 106 492 minecraft:pink_terracotta
setblock 332 103 496 minecraft:red_nether_bricks
fill 332 103 497 332 106 497 minecraft:pink_terracotta
fill 332 103 499 332 104 499 minecraft:pink_terracotta
setblock 333 103 465 minecraft:red_nether_bricks
setblock 333 103 466 minecraft:pink_terracotta
fill 333 103 486 333 104 486 minecraft:pink_terracotta
setblock 333 103 490 minecraft:red_nether_bricks
fill 333 103 491 334 105 491 minecraft:pink_terracotta
setblock 333 103 495 minecraft:red_nether_bricks
setblock 334 103 464 minecraft:red_nether_bricks
fill 334 103 465 334 105 465 minecraft:pink_terracotta
setblock 334 103 489 minecraft:red_nether_bricks
fill 334 103 490 334 105 490 minecraft:pink_terracotta
fill 334 103 492 334 104 492 minecraft:pink_terracotta
setblock 334 103 504 minecraft:red_nether_bricks
fill 335 103 464 335 105 464 minecraft:pink_terracotta
setblock 335 103 503 minecraft:red_nether_bricks
fill 335 103 504 335 105 504 minecraft:pink_terracotta
fill 345 103 464 345 105 464 minecraft:pink_terracotta
setblock 345 103 504 minecraft:white_concrete
setblock 347 103 465 minecraft:pink_terracotta
setblock 348 103 465 minecraft:red_nether_bricks
fill 348 103 466 348 106 466 minecraft:pink_terracotta
setblock 349 103 464 minecraft:red_nether_bricks
fill 349 103 465 349 106 465 minecraft:pink_terracotta
fill 350 103 464 350 106 464 minecraft:pink_terracotta
setblock 350 103 467 minecraft:pink_terracotta
fill 350 103 504 350 106 504 minecraft:pink_terracotta
setblock 351 103 467 minecraft:red_nether_bricks
setblock 352 103 466 minecraft:red_nether_bricks
fill 352 103 467 352 106 467 minecraft:pink_terracotta
setblock 353 103 465 minecraft:red_nether_bricks
fill 353 103 466 353 106 466 minecraft:pink_terracotta
fill 353 103 468 354 103 468 minecraft:pink_terracotta
setblock 354 103 464 minecraft:red_nether_bricks
fill 354 103 465 354 106 465 minecraft:pink_terracotta
setblock 354 103 504 minecraft:red_nether_bricks
fill 355 103 464 355 106 464 minecraft:pink_terracotta
setblock 355 103 468 minecraft:red_nether_bricks
fill 355 103 504 355 106 504 minecraft:pink_terracotta
setblock 356 103 467 minecraft:red_nether_bricks
setblock 357 103 466 minecraft:red_nether_bricks
fill 357 103 467 357 104 467 minecraft:pink_terracotta
setblock 358 103 465 minecraft:red_nether_bricks
fill 358 103 466 358 105 466 minecraft:pink_terracotta
setblock 359 103 464 minecraft:red_nether_bricks
fill 359 103 465 359 106 465 minecraft:pink_terracotta
setblock 359 103 504 minecraft:red_nether_bricks
fill 360 103 464 360 106 464 minecraft:pink_terracotta
setblock 360 103 504 minecraft:pink_terracotta
setblock 362 103 466 minecraft:red_nether_bricks
setblock 363 103 465 minecraft:red_nether_bricks
setblock 363 103 504 minecraft:pink_terracotta
setblock 364 103 464 minecraft:red_nether_bricks
fill 364 103 465 364 106 465 minecraft:pink_terracotta
setblock 364 103 504 minecraft:red_nether_bricks
fill 365 103 464 365 106 464 minecraft:pink_terracotta
fill 365 103 466 366 103 466 minecraft:pink_terracotta
fill 365 103 504 365 106 504 minecraft:pink_terracotta
setblock 367 103 466 minecraft:red_nether_bricks
setblock 368 103 465 minecraft:red_nether_bricks
fill 368 103 466 368 106 466 minecraft:pink_terracotta
setblock 368 103 470 minecraft:red_nether_bricks
setblock 369 103 464 minecraft:red_nether_bricks
fill 369 103 465 369 106 465 minecraft:pink_terracotta
setblock 369 103 468 minecraft:pink_terracotta
setblock 369 103 469 minecraft:red_nether_bricks
fill 369 103 470 369 106 470 minecraft:pink_terracotta
setblock 369 103 473 minecraft:pink_terracotta
fill 369 103 486 369 103 488 minecraft:pink_terracotta
setblock 369 103 489 minecraft:red_nether_bricks
fill 369 103 490 369 103 493 minecraft:pink_terracotta
setblock 369 103 494 minecraft:red_nether_bricks
fill 369 103 495 369 103 498 minecraft:pink_terracotta
setblock 369 103 499 minecraft:red_nether_bricks
fill 369 103 500 369 105 501 minecraft:pink_terracotta
setblock 369 103 504 minecraft:red_nether_bricks
fill 370 103 464 370 106 464 minecraft:pink_terracotta
setblock 370 103 468 minecraft:red_nether_bricks
fill 370 103 469 370 106 469 minecraft:pink_terracotta
setblock 370 103 473 minecraft:red_nether_bricks
fill 370 103 474 370 104 476 minecraft:pink_terracotta
setblock 370 103 482 minecraft:pink_terracotta
setblock 370 103 483 minecraft:red_nether_bricks
fill 370 103 484 370 106 484 minecraft:pink_terracotta
setblock 370 103 488 minecraft:red_nether_bricks
fill 370 103 489 370 103 492 minecraft:pink_terracotta
setblock 370 103 493 minecraft:red_nether_bricks
fill 370 103 494 370 106 494 minecraft:pink_terracotta
fill 370 103 496 370 103 497 minecraft:pink_terracotta
setblock 370 103 498 minecraft:red_nether_bricks
fill 370 103 499 370 106 499 minecraft:pink_terracotta
setblock 370 103 503 minecraft:red_nether_bricks
fill 370 103 504 370 106 504 minecraft:pink_terracotta
setblock 330 104 467 minecraft:red_nether_bricks
fill 330 104 468 330 107 468 minecraft:pink_terracotta
setblock 330 104 471 minecraft:pink_terracotta
setblock 330 104 472 minecraft:red_nether_bricks
fill 330 104 473 330 104 476 minecraft:pink_terracotta
setblock 330 104 477 minecraft:red_nether_bricks
fill 330 104 478 330 107 478 minecraft:pink_terracotta
setblock 330 104 482 minecraft:red_nether_bricks
fill 330 104 483 330 107 483 minecraft:pink_terracotta
setblock 330 104 487 minecraft:red_nether_bricks
fill 330 104 488 330 107 488 minecraft:pink_terracotta
setblock 330 104 492 minecraft:red_nether_bricks
fill 330 104 493 330 107 493 minecraft:pink_terracotta
setblock 330 104 497 minecraft:red_nether_bricks
fill 330 104 498 330 107 498 minecraft:pink_terracotta
setblock 330 104 502 minecraft:red_nether_bricks
fill 330 104 503 330 107 503 minecraft:pink_terracotta
setblock 331 104 466 minecraft:red_nether_bricks
fill 331 104 467 331 107 467 minecraft:pink_terracotta
setblock 331 104 471 minecraft:red_nether_bricks
fill 331 104 472 331 107 472 minecraft:pink_terracotta
fill 331 104 474 331 105 474 minecraft:pink_terracotta
fill 331 104 482 331 106 482 minecraft:pink_terracotta
setblock 331 104 486 minecraft:red_nether_bricks
fill 331 104 487 331 107 487 minecraft:pink_terracotta
setblock 331 104 491 minecraft:red_nether_bricks
fill 331 104 492 331 107 492 minecraft:pink_terracotta
setblock 331 104 495 minecraft:pink_terracotta
setblock 331 104 496 minecraft:red_nether_bricks
fill 331 104 497 331 107 497 minecraft:pink_terracotta
setblock 331 104 501 minecraft:red_nether_bricks
fill 331 104 502 331 107 502 minecraft:pink_terracotta
setblock 332 104 465 minecraft:red_nether_bricks
setblock 332 104 466 minecraft:pink_terracotta
setblock 332 104 470 minecraft:red_nether_bricks
fill 332 104 471 332 106 471 minecraft:pink_terracotta
setblock 332 104 485 minecraft:red_nether_bricks
fill 332 104 486 332 107 486 minecraft:pink_terracotta
setblock 332 104 490 minecraft:red_nether_bricks
fill 332 104 491 332 107 491 minecraft:pink_terracotta
setblock 332 104 495 minecraft:red_nether_bricks
fill 332 104 496 333 106 496 minecraft:pink_terracotta
setblock 333 104 464 minecraft:red_nether_bricks
fill 333 104 465 333 105 465 minecraft:pink_terracotta
setblock 333 104 489 minecraft:red_nether_bricks
fill 333 104 490 333 107 490 minecraft:pink_terracotta
setblock 333 104 494 minecraft:red_nether_bricks
fill 333 104 495 333 107 495 minecraft:pink_terracotta
setblock 333 104 504 minecraft:red_nether_bricks
fill 334 104 464 334 106 464 minecraft:pink_terracotta
setblock 334 104 489 minecraft:pink_terracotta
setblock 334 104 503 minecraft:red_nether_bricks
fill 334 104 504 334 106 504 minecraft:pink_terracotta
fill 343 104 464 343 105 464 minecraft:white_concrete
setblock 347 104 465 minecraft:red_nether_bricks
setblock 348 104 464 minecraft:red_nether_bricks
fill 348 104 465 348 107 465 minecraft:pink_terracotta
fill 349 104 464 349 107 464 minecraft:pink_terracotta
setblock 349 104 467 minecraft:pink_terracotta
setblock 350 104 467 minecraft:red_nether_bricks
setblock 351 104 466 minecraft:red_nether_bricks
fill 351 104 467 351 107 467 minecraft:pink_terracotta
setblock 352 104 465 minecraft:red_nether_bricks
fill 352 104 466 352 107 466 minecraft:pink_terracotta
fill 352 104 468 353 104 468 minecraft:pink_terracotta
setblock 353 104 464 minecraft:red_nether_bricks
fill 353 104 465 353 107 465 minecraft:pink_terracotta
setblock 353 104 504 minecraft:red_nether_bricks
fill 354 104 464 354 107 464 minecraft:pink_terracotta
setblock 354 104 468 minecraft:red_nether_bricks
fill 354 104 504 354 106 504 minecraft:pink_terracotta
setblock 355 104 467 minecraft:red_nether_bricks
setblock 356 104 466 minecraft:red_nether_bricks
fill 356 104 467 356 105 467 minecraft:pink_terracotta
setblock 357 104 465 minecraft:red_nether_bricks
fill 357 104 466 357 106 466 minecraft:pink_terracotta
setblock 358 104 464 minecraft:red_nether_bricks
fill 358 104 465 358 106 465 minecraft:pink_terracotta
setblock 358 104 504 minecraft:red_nether_bricks
fill 359 104 464 359 107 464 minecraft:pink_terracotta
setblock 361 104 466 minecraft:red_nether_bricks
setblock 362 104 465 minecraft:red_nether_bricks
setblock 363 104 464 minecraft:red_nether_bricks
fill 363 104 465 363 106 465 minecraft:pink_terracotta
fill 364 104 464 364 107 464 minecraft:pink_terracotta
fill 364 104 504 364 107 504 minecraft:pink_terracotta
setblock 365 104 466 minecraft:pink_terracotta
setblock 366 104 466 minecraft:red_nether_bricks
setblock 367 104 465 minecraft:red_nether_bricks
fill 367 104 466 367 106 466 minecraft:pink_terracotta
fill 367 104 503 367 105 503 minecraft:pink_terracotta
setblock 368 104 464 minecraft:red_nether_bricks
fill 368 104 465 368 107 465 minecraft:pink_terracotta
fill 368 104 467 368 104 468 minecraft:pink_terracotta
setblock 368 104 469 minecraft:red_nether_bricks
fill 368 104 470 368 106 471 minecraft:pink_terracotta
fill 368 104 491 368 104 493 minecraft:pink_terracotta
setblock 368 104 504 minecraft:red_nether_bricks
fill 369 104 464 369 107 464 minecraft:pink_terracotta
setblock 369 104 468 minecraft:red_nether_bricks
fill 369 104 469 369 107 469 minecraft:pink_terracotta
setblock 369 104 473 minecraft:red_nether_bricks
fill 369 104 474 369 107 474 minecraft:pink_terracotta
fill 369 104 486 369 104 487 minecraft:pink_terracotta
setblock 369 104 488 minecraft:red_nether_bricks
fill 369 104 489 369 104 492 minecraft:pink_terracotta
setblock 369 104 493 minecraft:red_nether_bricks
fill 369 104 494 369 104 497 minecraft:pink_terracotta
setblock 369 104 498 minecraft:red_nether_bricks
fill 369 104 499 369 107 499 minecraft:pink_terracotta
setblock 369 104 503 minecraft:red_nether_bricks
fill 369 104 504 369 107 504 minecraft:pink_terracotta
setblock 370 104 467 minecraft:red_nether_bricks
fill 370 104 468 370 107 468 minecraft:pink_terracotta
setblock 370 104 472 minecraft:red_nether_bricks
fill 370 104 473 370 107 473 minecraft:pink_terracotta
setblock 370 104 477 minecraft:red_nether_bricks
setblock 370 104 482 minecraft:red_nether_bricks
fill 370 104 483 370 106 483 minecraft:pink_terracotta
setblock 370 104 487 minecraft:red_nether_bricks
fill 370 104 488 370 104 491 minecraft:pink_terracotta
setblock 370 104 492 minecraft:red_nether_bricks
fill 370 104 493 370 107 493 minecraft:pink_terracotta
setblock 370 104 496 minecraft:pink_terracotta
setblock 370 104 497 minecraft:red_nether_bricks
fill 370 104 498 370 107 498 minecraft:pink_terracotta
setblock 370 104 502 minecraft:red_nether_bricks
fill 370 104 503 370 107 503 minecraft:pink_terracotta
setblock 330 105 466 minecraft:red_nether_bricks
fill 330 105 467 330 108 467 minecraft:pink_terracotta
setblock 330 105 471 minecraft:red_nether_bricks
fill 330 105 472 330 105 475 minecraft:pink_terracotta
setblock 330 105 476 minecraft:red_nether_bricks
fill 330 105 477 330 108 477 minecraft:pink_terracotta
setblock 330 105 481 minecraft:red_nether_bricks
fill 330 105 482 330 108 482 minecraft:pink_terracotta
setblock 330 105 486 minecraft:red_nether_bricks
fill 330 105 487 330 108 487 minecraft:pink_terracotta
setblock 330 105 491 minecraft:red_nether_bricks
fill 330 105 492 330 108 492 minecraft:pink_terracotta
setblock 330 105 496 minecraft:red_nether_bricks
fill 330 105 497 330 108 497 minecraft:pink_terracotta
setblock 330 105 501 minecraft:red_nether_bricks
fill 330 105 502 330 108 502 minecraft:pink_terracotta
setblock 331 105 465 minecraft:red_nether_bricks
fill 331 105 466 331 106 466 minecraft:pink_terracotta
setblock 331 105 470 minecraft:red_nether_bricks
fill 331 105 471 331 108 471 minecraft:pink_terracotta
setblock 331 105 475 minecraft:red_nether_bricks
fill 331 105 476 331 108 476 minecraft:pink_terracotta
setblock 331 105 485 minecraft:red_nether_bricks
fill 331 105 486 331 108 486 minecraft:pink_terracotta
setblock 331 105 490 minecraft:red_nether_bricks
fill 331 105 491 331 108 491 minecraft:pink_terracotta
setblock 331 105 495 minecraft:red_nether_bricks
fill 331 105 496 331 108 496 minecraft:pink_terracotta
setblock 331 105 500 minecraft:red_nether_bricks
fill 331 105 501 331 108 501 minecraft:pink_terracotta
setblock 332 105 464 minecraft:red_nether_bricks
fill 332 105 465 332 106 465 minecraft:pink_terracotta
setblock 332 105 466 minecraft:light[level=12]
setblock 332 105 469 minecraft:red_nether_bricks
fill 332 105 470 332 106 470 minecraft:pink_terracotta
setblock 332 105 474 minecraft:light[level=12]
setblock 332 105 482 minecraft:light[level=12]
setblock 332 105 484 minecraft:red_nether_bricks
fill 332 105 485 332 106 485 minecraft:pink_terracotta
setblock 332 105 489 minecraft:red_nether_bricks
fill 332 105 490 332 108 490 minecraft:pink_terracotta
setblock 332 105 494 minecraft:red_nether_bricks
fill 332 105 495 332 108 495 minecraft:pink_terracotta
setblock 332 105 499 minecraft:red_nether_bricks
setblock 332 105 504 minecraft:red_nether_bricks
fill 333 105 464 333 107 464 minecraft:pink_terracotta
setblock 333 105 488 minecraft:red_nether_bricks
fill 333 105 489 333 107 489 minecraft:pink_terracotta
setblock 333 105 493 minecraft:red_nether_bricks
fill 333 105 494 333 108 494 minecraft:pink_terracotta
setblock 333 105 503 minecraft:red_nether_bricks
fill 333 105 504 333 107 504 minecraft:pink_terracotta
setblock 334 105 492 minecraft:red_nether_bricks
setblock 337 105 464 minecraft:white_concrete
setblock 338 105 504 minecraft:white_concrete
setblock 340 105 466 minecraft:light[level=12]
setblock 340 105 474 minecraft:light[level=12]
setblock 340 105 482 minecraft:light[level=12]
setblock 340 105 490 minecraft:light[level=12]
setblock 340 105 498 minecraft:light[level=12]
setblock 347 105 464 minecraft:red_nether_bricks
fill 347 105 465 347 108 465 minecraft:pink_terracotta
fill 348 105 464 348 108 464 minecraft:pink_terracotta
setblock 348 105 474 minecraft:light[level=12]
setblock 348 105 482 minecraft:light[level=12]
setblock 348 105 490 minecraft:light[level=12]
setblock 348 105 498 minecraft:light[level=12]
setblock 349 105 467 minecraft:red_nether_bricks
setblock 350 105 466 minecraft:red_nether_bricks
fill 350 105 467 350 107 467 minecraft:pink_terracotta
setblock 351 105 465 minecraft:red_nether_bricks
fill 351 105 466 351 108 466 minecraft:pink_terracotta
setblock 352 105 464 minecraft:red_nether_bricks
fill 352 105 465 352 108 465 minecraft:pink_terracotta
setblock 352 105 468 minecraft:pink_terracotta
setblock 352 105 504 minecraft:red_nether_bricks
fill 353 105 464 353 108 464 minecraft:pink_terracotta
setblock 353 105 468 minecraft:red_nether_bricks
fill 353 105 504 353 107 504 minecraft:pink_terracotta
setblock 354 105 467 minecraft:red_nether_bricks
setblock 355 105 466 minecraft:red_nether_bricks
fill 355 105 467 355 106 467 minecraft:pink_terracotta
setblock 356 105 465 minecraft:red_nether_bricks
fill 356 105 466 356 106 466 minecraft:pink_terracotta
setblock 356 105 474 minecraft:light[level=12]
setblock 356 105 482 minecraft:light[level=12]
setblock 356 105 490 minecraft:light[level=12]
setblock 356 105 498 minecraft:light[level=12]
setblock 357 105 464 minecraft:red_nether_bricks
fill 357 105 465 357 107 465 minecraft:pink_terracotta
setblock 357 105 504 minecraft:red_nether_bricks
fill 358 105 464 358 108 464 minecraft:pink_terracotta
setblock 361 105 465 minecraft:red_nether_bricks
setblock 362 105 464 minecraft:red_nether_bricks
fill 362 105 465 362 106 465 minecraft:pink_terracotta
fill 363 105 464 363 108 464 minecraft:pink_terracotta
setblock 364 105 466 minecraft:light[level=12]
setblock 364 105 474 minecraft:light[level=12]
setblock 364 105 482 minecraft:light[level=12]
setblock 364 105 490 minecraft:light[level=12]
setblock 364 105 498 minecraft:light[level=12]
setblock 366 105 465 minecraft:red_nether_bricks
setblock 366 105 466 minecraft:pink_terracotta
setblock 367 105 464 minecraft:red_nether_bricks
fill 367 105 465 367 108 465 minecraft:pink_terracotta
setblock 367 105 504 minecraft:red_nether_bricks
fill 368 105 464 368 108 464 minecraft:pink_terracotta
setblock 368 105 467 minecraft:pink_terracotta
setblock 368 105 468 minecraft:red_nether_bricks
fill 368 105 469 368 107 469 minecraft:pink_terracotta
fill 368 105 490 368 105 492 minecraft:pink_terracotta
setblock 368 105 493 minecraft:red_nether_bricks
fill 368 105 494 369 105 496 minecraft:pink_terracotta
setblock 368 105 503 minecraft:red_nether_bricks
fill 368 105 504 368 108 504 minecraft:pink_terracotta
setblock 369 105 467 minecraft:red_nether_bricks
fill 369 105 468 369 108 468 minecraft:pink_terracotta
setblock 369 105 471 minecraft:pink_terracotta
setblock 369 105 472 minecraft:red_nether_bricks
fill 369 105 473 369 108 473 minecraft:pink_terracotta
setblock 369 105 486 minecraft:pink_terracotta
setblock 369 105 487 minecraft:red_nether_bricks
fill 369 105 488 369 105 491 minecraft:pink_terracotta
setblock 369 105 492 minecraft:red_nether_bricks
fill 369 105 493 369 108 493 minecraft:pink_terracotta
setblock 369 105 497 minecraft:red_nether_bricks
fill 369 105 498 369 108 498 minecraft:pink_terracotta
setblock 369 105 502 minecraft:red_nether_bricks
fill 369 105 503 369 108 503 minecraft:pink_terracotta
setblock 370 105 466 minecraft:red_nether_bricks
fill 370 105 467 370 108 467 minecraft:pink_terracotta
setblock 370 105 471 minecraft:red_nether_bricks
fill 370 105 472 370 108 472 minecraft:pink_terracotta
fill 370 105 474 370 105 475 minecraft:pink_terracotta
setblock 370 105 476 minecraft:red_nether_bricks
fill 370 105 477 370 107 478 minecraft:pink_terracotta
setblock 370 105 481 minecraft:white_concrete
setblock 370 105 482 minecraft:pink_terracotta
setblock 370 105 486 minecraft:red_nether_bricks
fill 370 105 487 370 105 490 minecraft:pink_terracotta
setblock 370 105 491 minecraft:red_nether_bricks
fill 370 105 492 370 108 492 minecraft:pink_terracotta
setblock 370 105 496 minecraft:red_nether_bricks
fill 370 105 497 370 108 497 minecraft:pink_terracotta
setblock 370 105 501 minecraft:red_nether_bricks
fill 370 105 502 370 108 502 minecraft:pink_terracotta
setblock 330 106 465 minecraft:red_nether_bricks
fill 330 106 466 330 109 466 minecraft:pink_terracotta
setblock 330 106 470 minecraft:red_nether_bricks
fill 330 106 471 330 106 474 minecraft:pink_terracotta
setblock 330 106 475 minecraft:red_nether_bricks
fill 330 106 476 330 109 476 minecraft:pink_terracotta
setblock 330 106 479 minecraft:pink_terracotta
setblock 330 106 480 minecraft:red_nether_bricks
fill 330 106 481 330 109 481 minecraft:pink_terracotta
setblock 330 106 485 minecraft:red_nether_bricks
fill 330 106 486 330 109 486 minecraft:pink_terracotta
setblock 330 106 490 minecraft:red_nether_bricks
fill 330 106 491 330 109 491 minecraft:pink_terracotta
setblock 330 106 495 minecraft:red_nether_bricks
fill 330 106 496 330 109 496 minecraft:pink_terracotta
setblock 330 106 500 minecraft:red_nether_bricks
fill 330 106 501 330 109 501 minecraft:pink_terracotta
setblock 331 106 464 minecraft:red_nether_bricks
setblock 331 106 465 minecraft:pink_terracotta
setblock 331 106 469 minecraft:red_nether_bricks
fill 331 106 470 331 109 470 minecraft:pink_terracotta
setblock 331 106 474 minecraft:red_nether_bricks
fill 331 106 475 331 109 475 minecraft:pink_terracotta
fill 331 106 477 331 107 477 minecraft:pink_terracotta
setblock 331 106 484 minecraft:red_nether_bricks
fill 331 106 485 331 109 485 minecraft:pink_terracotta
setblock 331 106 489 minecraft:red_nether_bricks
fill 331 106 490 331 109 490 minecraft:pink_terracotta
setblock 331 106 494 minecraft:red_nether_bricks
fill 331 106 495 331 109 495 minecraft:pink_terracotta
setblock 331 106 499 minecraft:red_nether_bricks
fill 331 106 500 331 109 500 minecraft:pink_terracotta
setblock 331 106 504 minecraft:red_nether_bricks
fill 332 106 464 332 107 464 minecraft:pink_terracotta
setblock 332 106 488 minecraft:red_nether_bricks
fill 332 106 489 332 109 489 minecraft:pink_terracotta
setblock 332 106 493 minecraft:red_nether_bricks
fill 332 106 494 332 109 494 minecraft:pink_terracotta
setblock 332 106 498 minecraft:red_nether_bricks
fill 332 106 499 332 107 499 minecraft:pink_terracotta
setblock 332 106 503 minecraft:red_nether_bricks
fill 332 106 504 332 108 504 minecraft:pink_terracotta
setblock 333 106 488 minecraft:pink_terracotta
setblock 333 106 491 minecraft:pink_terracotta
setblock 333 106 492 minecraft:red_nether_bricks
fill 333 106 493 333 108 493 minecraft:pink_terracotta
setblock 344 106 504 minecraft:white_concrete
setblock 346 106 464 minecraft:red_nether_bricks
fill 347 106 464 347 109 464 minecraft:pink_terracotta
setblock 349 106 466 minecraft:red_nether_bricks
setblock 349 106 467 minecraft:pink_terracotta
setblock 350 106 465 minecraft:red_nether_bricks
fill 350 106 466 350 108 466 minecraft:pink_terracotta
setblock 351 106 464 minecraft:red_nether_bricks
fill 351 106 465 351 109 465 minecraft:pink_terracotta
setblock 351 106 504 minecraft:red_nether_bricks
fill 352 106 464 352 109 464 minecraft:pink_terracotta
fill 352 106 504 352 107 504 minecraft:pink_terracotta
setblock 353 106 467 minecraft:red_nether_bricks
setblock 354 106 466 minecraft:red_nether_bricks
setblock 354 106 467 minecraft:pink_terracotta
setblock 355 106 465 minecraft:red_nether_bricks
fill 355 106 466 355 107 466 minecraft:pink_terracotta
setblock 356 106 464 minecraft:red_nether_bricks
fill 356 106 465 356 107 465 minecraft:pink_terracotta
fill 357 106 464 357 108 464 minecraft:pink_terracotta
setblock 360 106 465 minecraft:red_nether_bricks
setblock 361 106 464 minecraft:red_nether_bricks
setblock 361 106 465 minecraft:pink_terracotta
fill 362 106 464 362 108 464 minecraft:pink_terracotta
setblock 363 106 504 minecraft:white_concrete
setblock 365 106 465 minecraft:red_nether_bricks
setblock 366 106 464 minecraft:red_nether_bricks
fill 366 106 465 366 108 465 minecraft:pink_terracotta
setblock 366 106 504 minecraft:red_nether_bricks
fill 367 106 464 367 109 464 minecraft:pink_terracotta
setblock 367 106 503 minecraft:red_nether_bricks
fill 367 106 504 367 109 504 minecraft:pink_terracotta
setblock 368 106 467 minecraft:red_nether_bricks
fill 368 106 468 368 107 468 minecraft:pink_terracotta
fill 368 106 490 368 106 491 minecraft:pink_terracotta
setblock 368 106 492 minecraft:red_nether_bricks
fill 368 106 493 368 106 496 minecraft:pink_terracotta
setblock 368 106 497 minecraft:red_nether_bricks
fill 368 106 503 368 109 503 minecraft:pink_terracotta
setblock 369 106 466 minecraft:red_nether_bricks
fill 369 106 467 369 109 467 minecraft:pink_terracotta
setblock 369 106 471 minecraft:red_nether_bricks
fill 369 106 472 369 109 472 minecraft:pink_terracotta
setblock 369 106 475 minecraft:pink_terracotta
fill 369 106 487 369 106 490 minecraft:pink_terracotta
setblock 369 106 491 minecraft:red_nether_bricks
fill 369 106 492 369 109 492 minecraft:pink_terracotta
fill 369 106 494 369 106 495 minecraft:pink_terracotta
setblock 369 106 496 minecraft:red_nether_bricks
fill 369 106 497 369 109 497 minecraft:pink_terracotta
setblock 369 106 500 minecraft:pink_terracotta
setblock 369 106 501 minecraft:red_nether_bricks
fill 369 106 502 369 109 502 minecraft:pink_terracotta
setblock 370 106 465 minecraft:red_nether_bricks
fill 370 106 466 370 109 466 minecraft:pink_terracotta
setblock 370 106 470 minecraft:red_nether_bricks
fill 370 106 471 370 109 471 minecraft:pink_terracotta
setblock 370 106 474 minecraft:pink_terracotta
setblock 370 106 475 minecraft:red_nether_bricks
fill 370 106 476 370 109 476 minecraft:pink_terracotta
setblock 370 106 485 minecraft:red_nether_bricks
fill 370 106 486 370 106 489 minecraft:pink_terracotta
setblock 370 106 490 minecraft:red_nether_bricks
fill 370 106 491 370 109 491 minecraft:pink_terracotta
setblock 370 106 495 minecraft:red_nether_bricks
fill 370 106 496 370 109 496 minecraft:pink_terracotta
setblock 370 106 500 minecraft:red_nether_bricks
fill 370 106 501 370 109 501 minecraft:pink_terracotta
setblock 330 107 464 minecraft:red_nether_bricks
fill 330 107 465 330 108 465 minecraft:pink_terracotta
setblock 330 107 469 minecraft:red_nether_bricks
fill 330 107 470 330 107 473 minecraft:pink_terracotta
setblock 330 107 474 minecraft:red_nether_bricks
fill 330 107 475 330 110 475 minecraft:pink_terracotta
setblock 330 107 479 minecraft:red_nether_bricks
fill 330 107 480 330 110 480 minecraft:pink_terracotta
setblock 330 107 484 minecraft:red_nether_bricks
fill 330 107 485 330 110 485 minecraft:pink_terracotta
setblock 330 107 489 minecraft:red_nether_bricks
fill 330 107 490 330 110 490 minecraft:pink_terracotta
setblock 330 107 494 minecraft:red_nether_bricks
fill 330 107 495 330 110 495 minecraft:pink_terracotta
setblock 330 107 499 minecraft:red_nether_bricks
fill 330 107 500 330 110 500 minecraft:pink_terracotta
setblock 330 107 504 minecraft:red_nether_bricks
setblock 331 107 464 minecraft:pink_terracotta
setblock 331 107 468 minecraft:red_nether_bricks
fill 331 107 469 331 108 469 minecraft:pink_terracotta
setblock 331 107 473 minecraft:red_nether_bricks
fill 331 107 474 331 110 474 minecraft:pink_terracotta
setblock 331 107 483 minecraft:red_nether_bricks
fill 331 107 484 331 108 484 minecraft:pink_terracotta
setblock 331 107 488 minecraft:red_nether_bricks
fill 331 107 489 331 110 489 minecraft:pink_terracotta
setblock 331 107 493 minecraft:red_nether_bricks
fill 331 107 494 331 110 494 minecraft:pink_terracotta
setblock 331 107 498 minecraft:red_nether_bricks
fill 331 107 499 331 110 499 minecraft:pink_terracotta
setblock 331 107 503 minecraft:red_nether_bricks
fill 331 107 504 331 109 504 minecraft:pink_terracotta
setblock 332 107 487 minecraft:red_nether_bricks
fill 332 107 488 332 108 488 minecraft:pink_terracotta
setblock 332 107 492 minecraft:red_nether_bricks
fill 332 107 493 332 110 493 minecraft:pink_terracotta
setblock 332 107 496 minecraft:pink_terracotta
setblock 332 107 497 minecraft:red_nether_bricks
fill 332 107 498 332 109 498 minecraft:pink_terracotta
setblock 333 107 491 minecraft:red_nether_bricks
fill 333 107 492 333 108 492 minecraft:pink_terracotta
fill 346 107 464 346 109 464 minecraft:pink_terracotta
setblock 348 107 466 minecraft:red_nether_bricks
setblock 349 107 465 minecraft:red_nether_bricks
fill 349 107 466 349 108 466 minecraft:pink_terracotta
setblock 350 107 464 minecraft:red_nether_bricks
fill 350 107 465 350 110 465 minecraft:pink_terracotta
setblock 350 107 504 minecraft:red_nether_bricks
fill 351 107 464 351 110 464 minecraft:pink_terracotta
setblock 351 107 504 minecraft:pink_terracotta
setblock 352 107 467 minecraft:red_nether_bricks
setblock 353 107 466 minecraft:red_nether_bricks
setblock 353 107 467 minecraft:pink_terracotta
setblock 354 107 465 minecraft:red_nether_bricks
setblock 354 107 466 minecraft:pink_terracotta
setblock 355 107 464 minecraft:red_nether_bricks
fill 355 107 465 355 108 465 minecraft:pink_terracotta
fill 356 107 464 356 109 464 minecraft:pink_terracotta
setblock 360 107 464 minecraft:red_nether_bricks
setblock 361 107 464 minecraft:pink_terracotta
setblock 365 107 464 minecraft:red_nether_bricks
setblock 365 107 465 minecraft:pink_terracotta
setblock 365 107 504 minecraft:red_nether_bricks
fill 366 107 464 366 110 464 minecraft:pink_terracotta
fill 366 107 504 366 110 504 minecraft:pink_terracotta
fill 367 107 503 367 110 503 minecraft:pink_terracotta
setblock 368 107 467 minecraft:pink_terracotta
setblock 368 107 470 minecraft:pink_terracotta
setblock 368 107 471 minecraft:red_nether_bricks
setblock 368 107 490 minecraft:pink_terracotta
setblock 368 107 491 minecraft:red_nether_bricks
fill 368 107 492 368 107 495 minecraft:pink_terracotta
setblock 368 107 496 minecraft:red_nether_bricks
fill 368 107 497 368 108 499 minecraft:pink_terracotta
setblock 369 107 465 minecraft:red_nether_bricks
fill 369 107 466 369 109 466 minecraft:pink_terracotta
setblock 369 107 470 minecraft:red_nether_bricks
fill 369 107 471 369 110 471 minecraft:pink_terracotta
setblock 369 107 475 minecraft:red_nether_bricks
fill 369 107 487 369 107 489 minecraft:pink_terracotta
setblock 369 107 490 minecraft:red_nether_bricks
fill 369 107 491 369 110 491 minecraft:pink_terracotta
setblock 369 107 494 minecraft:pink_terracotta
setblock 369 107 495 minecraft:red_nether_bricks
fill 369 107 496 369 110 496 minecraft:pink_terracotta
setblock 369 107 500 minecraft:red_nether_bricks
fill 369 107 501 369 110 501 minecraft:pink_terracotta
setblock 370 107 464 minecraft:red_nether_bricks
fill 370 107 465 370 110 465 minecraft:pink_terracotta
setblock 370 107 469 minecraft:red_nether_bricks
fill 370 107 470 370 110 470 minecraft:pink_terracotta
setblock 370 107 474 minecraft:red_nether_bricks
fill 370 107 475 370 110 475 minecraft:pink_terracotta
setblock 370 107 484 minecraft:red_nether_bricks
fill 370 107 485 370 107 488 minecraft:pink_terracotta
setblock 370 107 489 minecraft:red_nether_bricks
fill 370 107 490 370 110 490 minecraft:pink_terracotta
setblock 370 107 494 minecraft:red_nether_bricks
fill 370 107 495 370 110 495 minecraft:pink_terracotta
setblock 370 107 499 minecraft:red_nether_bricks
fill 370 107 500 370 110 500 minecraft:pink_terracotta
setblock 370 107 504 minecraft:red_nether_bricks
setblock 330 108 464 minecraft:pink_terracotta
setblock 330 108 468 minecraft:red_nether_bricks
fill 330 108 469 330 108 472 minecraft:pink_terracotta
setblock 330 108 473 minecraft:red_nether_bricks
fill 330 108 474 330 111 474 minecraft:pink_terracotta
setblock 330 108 478 minecraft:red_nether_bricks
fill 330 108 479 330 111 479 minecraft:pink_terracotta
setblock 330 108 483 minecraft:red_nether_bricks
fill 330 108 484 330 111 484 minecraft:pink_terracotta
setblock 330 108 488 minecraft:red_nether_bricks
fill 330 108 489 330 111 489 minecraft:pink_terracotta
setblock 330 108 493 minecraft:red_nether_bricks
fill 330 108 494 330 111 494 minecraft:pink_terracotta
setblock 330 108 498 minecraft:red_nether_bricks
fill 330 108 499 330 111 499 minecraft:pink_terracotta
setblock 330 108 503 minecraft:red_nether_bricks
fill 330 108 504 330 110 504 minecraft:pink_terracotta
setblock 331 108 468 minecraft:pink_terracotta
setblock 331 108 472 minecraft:red_nether_bricks
fill 331 108 473 331 111 473 minecraft:pink_terracotta
setblock 331 108 477 minecraft:red_nether_bricks
setblock 331 108 487 minecraft:red_nether_bricks
fill 331 108 488 331 111 488 minecraft:pink_terracotta
setblock 331 108 492 minecraft:red_nether_bricks
fill 331 108 493 331 111 493 minecraft:pink_terracotta
setblock 331 108 497 minecraft:red_nether_bricks
fill 331 108 498 331 111 498 minecraft:pink_terracotta
setblock 332 108 487 minecraft:pink_terracotta
setblock 332 108 491 minecraft:red_nether_bricks
fill 332 108 492 332 111 492 minecraft:pink_terracotta
setblock 332 108 496 minecraft:red_nether_bricks
fill 332 108 497 332 110 497 minecraft:pink_terracotta
setblock 333 108 491 minecraft:pink_terracotta
setblock 337 108 504 minecraft:white_concrete
setblock 344 108 464 minecraft:white_concrete
setblock 348 108 465 minecraft:red_nether_bricks
setblock 349 108 464 minecraft:red_nether_bricks
fill 349 108 465 349 110 465 minecraft:pink_terracotta
fill 350 108 464 350 111 464 minecraft:pink_terracotta
setblock 352 108 466 minecraft:red_nether_bricks
setblock 353 108 465 minecraft:red_nether_bricks
setblock 353 108 466 minecraft:pink_terracotta
setblock 354 108 464 minecraft:red_nether_bricks
setblock 354 108 465 minecraft:pink_terracotta
fill 355 108 464 355 109 464 minecraft:pink_terracotta
fill 356 108 498 356 109 499 minecraft:pink_concrete
setblock 356 108 504 minecraft:white_concrete
setblock 364 108 464 minecraft:red_nether_bricks
setblock 364 108 504 minecraft:red_nether_bricks
fill 365 108 464 365 111 464 minecraft:pink_terracotta
fill 365 108 504 365 111 504 minecraft:pink_terracotta
setblock 368 108 465 minecraft:red_nether_bricks
fill 368 108 491 368 108 494 minecraft:pink_terracotta
setblock 368 108 495 minecraft:red_nether_bricks
fill 368 108 496 368 111 496 minecraft:pink_terracotta
setblock 369 108 464 minecraft:red_nether_bricks
setblock 369 108 465 minecraft:pink_terracotta
setblock 369 108 469 minecraft:red_nether_bricks
fill 369 108 470 369 110 470 minecraft:pink_terracotta
setblock 369 108 474 minecraft:red_nether_bricks
fill 369 108 475 369 111 475 minecraft:pink_terracotta
setblock 369 108 488 minecraft:pink_terracotta
setblock 369 108 489 minecraft:red_nether_bricks
fill 369 108 490 369 111 490 minecraft:pink_terracotta
setblock 369 108 494 minecraft:red_nether_bricks
fill 369 108 495 369 111 495 minecraft:pink_terracotta
setblock 369 108 499 minecraft:red_nether_bricks
fill 369 108 500 369 111 500 minecraft:pink_terracotta
setblock 369 108 504 minecraft:red_nether_bricks
fill 370 108 464 370 110 464 minecraft:pink_terracotta
setblock 370 108 468 minecraft:red_nether_bricks
fill 370 108 469 370 111 469 minecraft:pink_terracotta
setblock 370 108 473 minecraft:red_nether_bricks
fill 370 108 474 370 111 474 minecraft:pink_terracotta
setblock 370 108 477 minecraft:pink_terracotta
setblock 370 108 478 minecraft:red_nether_bricks
setblock 370 108 482 minecraft:white_concrete
fill 370 108 485 370 108 487 minecraft:pink_terracotta
setblock 370 108 488 minecraft:red_nether_bricks
fill 370 108 489 370 111 489 minecraft:pink_terracotta
setblock 370 108 493 minecraft:red_nether_bricks
fill 370 108 494 370 111 494 minecraft:pink_terracotta
setblock 370 108 498 minecraft:red_nether_bricks
fill 370 108 499 370 111 499 minecraft:pink_terracotta
setblock 370 108 503 minecraft:red_nether_bricks
fill 370 108 504 370 111 504 minecraft:pink_terracotta
setblock 330 109 467 minecraft:red_nether_bricks
fill 330 109 468 330 109 471 minecraft:pink_terracotta
setblock 330 109 472 minecraft:red_nether_bricks
fill 330 109 473 330 112 473 minecraft:pink_terracotta
setblock 330 109 477 minecraft:red_nether_bricks
fill 330 109 478 330 112 478 minecraft:pink_terracotta
setblock 330 109 482 minecraft:red_nether_bricks
fill 330 109 483 330 112 483 minecraft:pink_terracotta
setblock 330 109 487 minecraft:red_nether_bricks
fill 330 109 488 330 112 488 minecraft:pink_terracotta
setblock 330 109 492 minecraft:red_nether_bricks
fill 330 109 493 330 112 493 minecraft:pink_terracotta
setblock 330 109 497 minecraft:red_nether_bricks
fill 330 109 498 330 112 498 minecraft:pink_terracotta
setblock 330 109 502 minecraft:red_nether_bricks
fill 330 109 503 330 112 503 minecraft:pink_terracotta
setblock 331 109 471 minecraft:red_nether_bricks
fill 331 109 472 331 110 472 minecraft:pink_terracotta
setblock 331 109 476 minecraft:red_nether_bricks
fill 331 109 477 331 112 477 minecraft:pink_terracotta
setblock 331 109 486 minecraft:red_nether_bricks
fill 331 109 487 331 110 487 minecraft:pink_terracotta
setblock 331 109 491 minecraft:red_nether_bricks
fill 331 109 492 331 112 492 minecraft:pink_terracotta
setblock 331 109 496 minecraft:red_nether_bricks
fill 331 109 497 331 112 497 minecraft:pink_terracotta
setblock 331 109 501 minecraft:red_nether_bricks
setblock 332 109 490 minecraft:red_nether_bricks
fill 332 109 491 332 110 491 minecraft:pink_terracotta
setblock 332 109 495 minecraft:red_nether_bricks
fill 332 109 496 332 111 496 minecraft:pink_terracotta
setblock 338 109 464 minecraft:white_concrete
setblock 343 109 504 minecraft:white_concrete
setblock 348 109 464 minecraft:red_nether_bricks
setblock 348 109 465 minecraft:pink_terracotta
fill 349 109 464 349 112 464 minecraft:pink_terracotta
setblock 352 109 465 minecraft:red_nether_bricks
setblock 353 109 464 minecraft:red_nether_bricks
setblock 353 109 465 minecraft:pink_terracotta
fill 354 109 464 354 110 464 minecraft:pink_terracotta
setblock 357 109 464 minecraft:white_concrete
setblock 362 109 504 minecraft:white_concrete
setblock 364 109 464 minecraft:pink_terracotta
fill 364 109 504 364 112 504 minecraft:pink_terracotta
setblock 368 109 464 minecraft:red_nether_bricks
fill 368 109 491 368 109 493 minecraft:pink_terracotta
setblock 368 109 494 minecraft:red_nether_bricks
fill 368 109 495 368 112 495 minecraft:pink_terracotta
fill 368 109 497 368 109 498 minecraft:pink_terracotta
setblock 368 109 499 minecraft:red_nether_bricks
fill 368 109 500 368 112 500 minecraft:pink_terracotta
setblock 368 109 504 minecraft:red_nether_bricks
fill 369 109 464 369 111 464 minecraft:pink_terracotta
setblock 369 109 468 minecraft:red_nether_bricks
fill 369 109 469 369 110 469 minecraft:pink_terracotta
setblock 369 109 473 minecraft:red_nether_bricks
fill 369 109 474 369 112 474 minecraft:pink_terracotta
setblock 369 109 488 minecraft:red_nether_bricks
fill 369 109 489 369 110 489 minecraft:pink_terracotta
setblock 369 109 493 minecraft:red_nether_bricks
fill 369 109 494 369 112 494 minecraft:pink_terracotta
setblock 369 109 498 minecraft:red_nether_bricks
fill 369 109 499 369 112 499 minecraft:pink_terracotta
setblock 369 109 503 minecraft:red_nether_bricks
fill 369 109 504 369 112 504 minecraft:pink_terracotta
setblock 370 109 467 minecraft:red_nether_bricks
fill 370 109 468 370 111 468 minecraft:pink_terracotta
setblock 370 109 472 minecraft:red_nether_bricks
fill 370 109 473 370 112 473 minecraft:pink_terracotta
setblock 370 109 477 minecraft:red_nether_bricks
fill 370 109 478 370 112 478 minecraft:pink_terracotta
setblock 370 109 486 minecraft:pink_terracotta
setblock 370 109 487 minecraft:red_nether_bricks
fill 370 109 488 370 112 488 minecraft:pink_terracotta
setblock 370 109 492 minecraft:red_nether_bricks
fill 370 109 493 370 112 493 minecraft:pink_terracotta
setblock 370 109 497 minecraft:red_nether_bricks
fill 370 109 498 370 112 498 minecraft:pink_terracotta
setblock 370 109 502 minecraft:red_nether_bricks
fill 370 109 503 370 112 503 minecraft:pink_terracotta
fill 330 110 468 330 110 470 minecraft:pink_terracotta
setblock 330 110 471 minecraft:red_nether_bricks
fill 330 110 472 330 113 472 minecraft:pink_terracotta
setblock 330 110 476 minecraft:red_nether_bricks
fill 330 110 477 330 113 477 minecraft:pink_terracotta
setblock 330 110 481 minecraft:red_nether_bricks
fill 330 110 482 330 113 482 minecraft:pink_terracotta
setblock 330 110 486 minecraft:red_nether_bricks
fill 330 110 487 330 113 487 minecraft:pink_terracotta
setblock 330 110 491 minecraft:red_nether_bricks
fill 330 110 492 330 113 492 minecraft:pink_terracotta
setblock 330 110 496 minecraft:red_nether_bricks
fill 330 110 497 330 113 497 minecraft:pink_terracotta
setblock 330 110 501 minecraft:red_nether_bricks
fill 330 110 502 330 113 502 minecraft:pink_terracotta
setblock 331 110 475 minecraft:red_nether_bricks
fill 331 110 476 331 113 476 minecraft:pink_terracotta
fill 331 110 478 331 111 478 minecraft:pink_terracotta
setblock 331 110 490 minecraft:red_nether_bricks
fill 331 110 491 331 113 491 minecraft:pink_terracotta
setblock 331 110 495 minecraft:red_nether_bricks
fill 331 110 496 331 113 496 minecraft:pink_terracotta
setblock 331 110 500 minecraft:red_nether_bricks
setblock 332 110 464 minecraft:white_concrete
setblock 332 110 490 minecraft:pink_terracotta
setblock 332 110 494 minecraft:red_nether_bricks
fill 332 110 495 332 112 495 minecraft:pink_terracotta
setblock 347 110 464 minecraft:red_nether_bricks
fill 348 110 464 348 113 464 minecraft:pink_terracotta
setblock 349 110 504 minecraft:white_concrete
setblock 351 110 465 minecraft:red_nether_bricks
setblock 352 110 464 minecraft:red_nether_bricks
fill 353 110 464 353 111 464 minecraft:pink_terracotta
fill 366 110 503 366 111 503 minecraft:pink_terracotta
setblock 367 110 464 minecraft:red_nether_bricks
setblock 367 110 504 minecraft:red_nether_bricks
fill 368 110 464 368 113 464 minecraft:pink_terracotta
setblock 368 110 492 minecraft:pink_terracotta
setblock 368 110 493 minecraft:red_nether_bricks
fill 368 110 494 368 113 494 minecraft:pink_terracotta
setblock 368 110 497 minecraft:pink_terracotta
setblock 368 110 498 minecraft:red_nether_bricks
fill 368 110 499 368 113 499 minecraft:pink_terracotta
setblock 368 110 503 minecraft:red_nether_bricks
fill 368 110 504 368 113 504 minecraft:pink_terracotta
setblock 369 110 472 minecraft:red_nether_bricks
fill 369 110 473 369 112 473 minecraft:pink_terracotta
setblock 369 110 492 minecraft:red_nether_bricks
fill 369 110 493 369 113 493 minecraft:pink_terracotta
setblock 369 110 497 minecraft:red_nether_bricks
fill 369 110 498 369 113 498 minecraft:pink_terracotta
setblock 369 110 502 minecraft:red_nether_bricks
fill 369 110 503 369 113 503 minecraft:pink_terracotta
setblock 370 110 466 minecraft:red_nether_bricks
fill 370 110 467 370 111 467 minecraft:pink_terracotta
setblock 370 110 471 minecraft:red_nether_bricks
fill 370 110 472 370 113 472 minecraft:pink_terracotta
setblock 370 110 476 minecraft:red_nether_bricks
fill 370 110 477 370 113 477 minecraft:pink_terracotta
fill 370 110 479 370 111 479 minecraft:pink_terracotta
setblock 370 110 486 minecraft:red_nether_bricks
fill 370 110 487 370 113 487 minecraft:pink_terracotta
setblock 370 110 491 minecraft:red_nether_bricks
fill 370 110 492 370 113 492 minecraft:pink_terracotta
setblock 370 110 496 minecraft:red_nether_bricks
fill 370 110 497 370 113 497 minecraft:pink_terracotta
setblock 370 110 501 minecraft:red_nether_bricks
fill 370 110 502 370 113 502 minecraft:pink_terracotta
setblock 330 111 469 minecraft:pink_terracotta
setblock 330 111 470 minecraft:red_nether_bricks
fill 330 111 471 330 114 471 minecraft:pink_terracotta
setblock 330 111 475 minecraft:red_nether_bricks
fill 330 111 476 330 114 476 minecraft:pink_terracotta
setblock 330 111 480 minecraft:red_nether_bricks
fill 330 111 481 330 114 481 minecraft:pink_terracotta
setblock 330 111 485 minecraft:red_nether_bricks
fill 330 111 486 330 114 486 minecraft:pink_terracotta
setblock 330 111 490 minecraft:red_nether_bricks
fill 330 111 491 330 114 491 minecraft:pink_terracotta
setblock 330 111 495 minecraft:red_nether_bricks
fill 330 111 496 330 114 496 minecraft:pink_terracotta
setblock 330 111 500 minecraft:red_nether_bricks
fill 330 111 501 330 114 501 minecraft:pink_terracotta
setblock 330 111 504 minecraft:white_concrete
setblock 331 111 474 minecraft:red_nether_bricks
fill 331 111 475 331 114 475 minecraft:pink_terracotta
setblock 331 111 489 minecraft:red_nether_bricks
fill 331 111 490 331 113 490 minecraft:pink_terracotta
setblock 331 111 494 minecraft:red_nether_bricks
fill 331 111 495 331 114 495 minecraft:pink_terracotta
setblock 331 111 499 minecraft:red_nether_bricks
fill 331 111 500 331 114 500 minecraft:pink_terracotta
setblock 332 111 493 minecraft:red_nether_bricks
setblock 332 111 494 minecraft:pink_terracotta
fill 336 111 499 336 111 501 minecraft:white_concrete
fill 337 111 499 339 111 499 minecraft:white_concrete
fill 337 111 502 338 111 502 minecraft:white_concrete
fill 339 111 500 339 111 501 minecraft:white_concrete
setblock 345 111 464 minecraft:white_concrete
setblock 346 111 464 minecraft:red_nether_bricks
fill 347 111 464 347 114 464 minecraft:pink_terracotta
setblock 351 111 464 minecraft:red_nether_bricks
fill 352 111 464 352 114 464 minecraft:pink_terracotta
setblock 355 111 504 minecraft:white_concrete
fill 361 111 478 361 111 481 minecraft:white_concrete
fill 362 111 478 364 111 478 minecraft:white_concrete
fill 362 111 482 364 111 482 minecraft:white_concrete
fill 363 111 504 363 113 504 minecraft:pink_terracotta
fill 364 111 479 364 112 481 minecraft:white_concrete
fill 365 111 479 365 111 480 minecraft:white_concrete
setblock 366 111 464 minecraft:red_nether_bricks
setblock 366 111 504 minecraft:red_nether_bricks
fill 367 111 464 367 114 464 minecraft:pink_terracotta
setblock 367 111 503 minecraft:red_nether_bricks
fill 367 111 504 367 114 504 minecraft:pink_terracotta
setblock 368 111 492 minecraft:red_nether_bricks
fill 368 111 493 368 114 493 minecraft:pink_terracotta
setblock 368 111 497 minecraft:red_nether_bricks
fill 368 111 498 368 114 498 minecraft:pink_terracotta
setblock 368 111 501 minecraft:pink_terracotta
fill 368 111 503 368 114 503 minecraft:pink_terracotta
setblock 369 111 471 minecraft:red_nether_bricks
setblock 369 111 472 minecraft:pink_terracotta
setblock 369 111 491 minecraft:red_nether_bricks
fill 369 111 492 369 114 492 minecraft:pink_terracotta
setblock 369 111 496 minecraft:red_nether_bricks
fill 369 111 497 369 114 497 minecraft:pink_terracotta
setblock 369 111 501 minecraft:red_nether_bricks
fill 369 111 502 369 114 502 minecraft:pink_terracotta
setblock 370 111 464 minecraft:white_concrete
setblock 370 111 470 minecraft:red_nether_bricks
fill 370 111 471 370 114 471 minecraft:pink_terracotta
setblock 370 111 475 minecraft:red_nether_bricks
fill 370 111 476 370 114 476 minecraft:pink_terracotta
setblock 370 111 483 minecraft:white_concrete
setblock 370 111 490 minecraft:red_nether_bricks
fill 370 111 491 370 114 491 minecraft:pink_terracotta
setblock 370 111 495 minecraft:red_nether_bricks
fill 370 111 496 370 114 496 minecraft:pink_terracotta
setblock 370 111 500 minecraft:red_nether_bricks
fill 370 111 501 370 114 501 minecraft:pink_terracotta
setblock 330 112 466 minecraft:white_concrete
setblock 330 112 470 minecraft:pink_terracotta
setblock 330 112 474 minecraft:red_nether_bricks
fill 330 112 475 330 114 475 minecraft:pink_terracotta
setblock 330 112 479 minecraft:red_nether_bricks
fill 330 112 480 330 114 480 minecraft:pink_terracotta
setblock 330 112 484 minecraft:red_nether_bricks
fill 330 112 485 330 114 485 minecraft:pink_terracotta
setblock 330 112 489 minecraft:red_nether_bricks
fill 330 112 490 330 114 490 minecraft:pink_terracotta
setblock 330 112 494 minecraft:red_nether_bricks
fill 330 112 495 330 114 495 minecraft:pink_terracotta
setblock 330 112 499 minecraft:red_nether_bricks
fill 330 112 500 330 114 500 minecraft:pink_terracotta
setblock 331 112 473 minecraft:red_nether_bricks
fill 331 112 474 331 114 474 minecraft:pink_terracotta
setblock 331 112 478 minecraft:red_nether_bricks
fill 331 112 479 331 114 479 minecraft:pink_terracotta
setblock 331 112 489 minecraft:pink_terracotta
setblock 331 112 493 minecraft:red_nether_bricks
fill 331 112 494 331 114 494 minecraft:pink_terracotta
setblock 331 112 498 minecraft:red_nether_bricks
fill 331 112 499 331 114 499 minecraft:pink_terracotta
fill 335 112 487 335 113 488 minecraft:pink_concrete
setblock 336 112 500 minecraft:white_concrete
setblock 336 112 504 minecraft:white_concrete
fill 337 112 499 338 113 499 minecraft:white_concrete
setblock 339 112 464 minecraft:white_concrete
setblock 339 112 500 minecraft:white_concrete
fill 346 112 464 346 114 464 minecraft:pink_terracotta
setblock 350 112 464 minecraft:red_nether_bricks
fill 351 112 464 351 114 464 minecraft:pink_terracotta
fill 361 112 479 361 112 481 minecraft:white_concrete
setblock 361 112 504 minecraft:white_concrete
fill 362 112 478 363 112 478 minecraft:white_concrete
fill 362 112 504 362 114 504 minecraft:pink_terracotta
setblock 363 112 482 minecraft:white_concrete
setblock 364 112 464 minecraft:white_concrete
fill 364 112 503 365 112 503 minecraft:pink_terracotta
setblock 365 112 464 minecraft:red_nether_bricks
setblock 365 112 504 minecraft:red_nether_bricks
fill 366 112 464 366 114 464 minecraft:pink_terracotta
setblock 366 112 503 minecraft:red_nether_bricks
fill 366 112 504 366 114 504 minecraft:pink_terracotta
setblock 367 112 496 minecraft:pink_terracotta
setblock 367 112 497 minecraft:red_nether_bricks
fill 367 112 498 367 114 498 minecraft:pink_terracotta
setblock 367 112 502 minecraft:red_nether_bricks
fill 367 112 503 367 114 503 minecraft:pink_terracotta
fill 368 112 492 368 114 492 minecraft:pink_terracotta
setblock 368 112 496 minecraft:red_nether_bricks
fill 368 112 497 368 114 497 minecraft:pink_terracotta
setblock 368 112 501 minecraft:red_nether_bricks
fill 368 112 502 368 114 502 minecraft:pink_terracotta
setblock 369 112 475 minecraft:red_nether_bricks
fill 369 112 476 369 114 476 minecraft:pink_terracotta
setblock 369 112 490 minecraft:red_nether_bricks
fill 369 112 491 369 114 491 minecraft:pink_terracotta
setblock 369 112 495 minecraft:red_nether_bricks
fill 369 112 496 369 114 496 minecraft:pink_terracotta
setblock 369 112 500 minecraft:red_nether_bricks
fill 369 112 501 369 114 501 minecraft:pink_terracotta
setblock 370 112 469 minecraft:red_nether_bricks
fill 370 112 470 370 113 470 minecraft:pink_terracotta
setblock 370 112 474 minecraft:red_nether_bricks
fill 370 112 475 370 114 475 minecraft:pink_terracotta
setblock 370 112 479 minecraft:red_nether_bricks
fill 370 112 480 370 114 480 minecraft:pink_terracotta
setblock 370 112 489 minecraft:red_nether_bricks
fill 370 112 490 370 114 490 minecraft:pink_terracotta
setblock 370 112 494 minecraft:red_nether_bricks
fill 370 112 495 370 114 495 minecraft:pink_terracotta
setblock 370 112 499 minecraft:red_nether_bricks
fill 370 112 500 370 114 500 minecraft:pink_terracotta
setblock 370 112 504 minecraft:red_nether_bricks
setblock 330 113 473 minecraft:red_nether_bricks
fill 330 113 474 330 114 474 minecraft:pink_terracotta
setblock 330 113 478 minecraft:red_nether_bricks
fill 330 113 479 330 114 479 minecraft:pink_terracotta
setblock 330 113 483 minecraft:red_nether_bricks
fill 330 113 484 330 114 484 minecraft:pink_terracotta
setblock 330 113 488 minecraft:red_nether_bricks
fill 330 113 489 330 114 489 minecraft:pink_terracotta
setblock 330 113 493 minecraft:red_nether_bricks
fill 330 113 494 330 114 494 minecraft:pink_terracotta
setblock 330 113 498 minecraft:red_nether_bricks
fill 330 113 499 330 114 499 minecraft:pink_terracotta
setblock 330 113 503 minecraft:red_nether_bricks
setblock 331 113 477 minecraft:red_nether_bricks
fill 331 113 478 331 114 478 minecraft:pink_terracotta
fill 331 113 480 331 113 481 minecraft:pink_terracotta
setblock 331 113 492 minecraft:red_nether_bricks
fill 331 113 493 331 114 493 minecraft:pink_terracotta
setblock 331 113 497 minecraft:red_nether_bricks
fill 331 113 498 331 114 498 minecraft:pink_terracotta
setblock 332 113 466 minecraft:light[level=12]
setblock 332 113 474 minecraft:light[level=12]
setblock 332 113 482 minecraft:light[level=12]
setblock 332 113 490 minecraft:light[level=12]
setblock 332 113 498 minecraft:light[level=12]
setblock 333 113 464 minecraft:white_concrete
setblock 340 113 466 minecraft:light[level=12]
setblock 340 113 474 minecraft:light[level=12]
setblock 340 113 482 minecraft:light[level=12]
setblock 340 113 490 minecraft:light[level=12]
setblock 340 113 498 minecraft:light[level=12]
setblock 342 113 504 minecraft:white_concrete
fill 345 113 464 345 114 464 minecraft:pink_terracotta
fill 347 113 504 348 113 504 minecraft:pink_terracotta
setblock 348 113 466 minecraft:light[level=12]
setblock 348 113 474 minecraft:light[level=12]
setblock 348 113 482 minecraft:light[level=12]
setblock 348 113 490 minecraft:light[level=12]
setblock 348 113 498 minecraft:light[level=12]
setblock 349 113 464 minecraft:red_nether_bricks
setblock 349 113 504 minecraft:red_nether_bricks
fill 350 113 464 350 114 464 minecraft:pink_terracotta
fill 350 113 504 350 114 504 minecraft:pink_terracotta
setblock 356 113 466 minecraft:light[level=12]
setblock 356 113 474 minecraft:light[level=12]
setblock 356 113 482 minecraft:light[level=12]
setblock 356 113 490 minecraft:light[level=12]
setblock 356 113 498 minecraft:light[level=12]
setblock 358 113 464 minecraft:white_concrete
setblock 361 113 480 minecraft:white_concrete
fill 361 113 504 361 114 504 minecraft:pink_terracotta
fill 363 113 503 364 113 503 minecraft:pink_terracotta
setblock 364 113 464 minecraft:red_nether_bricks
setblock 364 113 466 minecraft:light[level=12]
setblock 364 113 474 minecraft:light[level=12]
fill 364 113 479 364 113 480 minecraft:white_concrete
setblock 364 113 482 minecraft:light[level=12]
setblock 364 113 490 minecraft:light[level=12]
setblock 364 113 498 minecraft:light[level=12]
setblock 364 113 504 minecraft:red_nether_bricks
fill 365 113 464 365 114 464 minecraft:pink_terracotta
setblock 365 113 502 minecraft:pink_terracotta
setblock 365 113 503 minecraft:red_nether_bricks
fill 365 113 504 365 114 504 minecraft:pink_terracotta
setblock 366 113 502 minecraft:red_nether_bricks
fill 366 113 503 366 114 503 minecraft:pink_terracotta
setblock 367 113 495 minecraft:pink_terracotta
setblock 367 113 496 minecraft:red_nether_bricks
fill 367 113 497 367 114 497 minecraft:pink_terracotta
fill 367 113 499 367 113 500 minecraft:pink_terracotta
fill 367 113 502 367 114 502 minecraft:pink_terracotta
setblock 368 113 495 minecraft:red_nether_bricks
fill 368 113 496 368 114 496 minecraft:pink_terracotta
setblock 368 113 500 minecraft:red_nether_bricks
fill 368 113 501 368 114 501 minecraft:pink_terracotta
setblock 369 113 474 minecraft:red_nether_bricks
fill 369 113 475 369 114 475 minecraft:pink_terracotta
fill 369 113 477 369 114 477 minecraft:pink_terracotta
fill 369 113 490 369 114 490 minecraft:pink_terracotta
setblock 369 113 494 minecraft:red_nether_bricks
fill 369 113 495 369 114 495 minecraft:pink_terracotta
setblock 369 113 499 minecraft:red_nether_bricks
fill 369 113 500 369 114 500 minecraft:pink_terracotta
setblock 369 113 504 minecraft:red_nether_bricks
setblock 370 113 473 minecraft:red_nether_bricks
fill 370 113 474 370 114 474 minecraft:pink_terracotta
setblock 370 113 478 minecraft:red_nether_bricks
fill 370 113 479 370 114 479 minecraft:pink_terracotta
fill 370 113 481 370 113 482 minecraft:pink_terracotta
setblock 370 113 488 minecraft:red_nether_bricks
fill 370 113 489 370 114 489 minecraft:pink_terracotta
setblock 370 113 493 minecraft:red_nether_bricks
fill 370 113 494 370 114 494 minecraft:pink_terracotta
setblock 370 113 498 minecraft:red_nether_bricks
fill 370 113 499 370 114 499 minecraft:pink_terracotta
setblock 370 113 503 minecraft:red_nether_bricks
fill 370 113 504 370 114 504 minecraft:pink_terracotta
setblock 330 114 472 minecraft:red_nether_bricks
setblock 330 114 473 minecraft:pink_terracotta
setblock 330 114 477 minecraft:red_nether_bricks
setblock 330 114 478 minecraft:pink_terracotta
setblock 330 114 482 minecraft:red_nether_bricks
setblock 330 114 483 minecraft:pink_terracotta
setblock 330 114 487 minecraft:red_nether_bricks
setblock 330 114 488 minecraft:pink_terracotta
setblock 330 114 492 minecraft:red_nether_bricks
setblock 330 114 493 minecraft:pink_terracotta
setblock 330 114 497 minecraft:red_nether_bricks
setblock 330 114 498 minecraft:pink_terracotta
setblock 330 114 502 minecraft:red_nether_bricks
fill 330 114 503 330 114 504 minecraft:pink_terracotta
setblock 331 114 476 minecraft:red_nether_bricks
setblock 331 114 477 minecraft:pink_terracotta
setblock 331 114 480 minecraft:pink_terracotta
setblock 331 114 481 minecraft:red_nether_bricks
setblock 331 114 482 minecraft:pink_terracotta
setblock 331 114 491 minecraft:red_nether_bricks
setblock 331 114 492 minecraft:pink_terracotta
setblock 331 114 496 minecraft:red_nether_bricks
setblock 331 114 497 minecraft:pink_terracotta
setblock 344 114 464 minecraft:pink_terracotta
fill 345 114 504 347 114 504 minecraft:pink_terracotta
setblock 347 114 465 minecraft:red_nether_bricks
schedule function dropper:buildpart/115_3 1t
