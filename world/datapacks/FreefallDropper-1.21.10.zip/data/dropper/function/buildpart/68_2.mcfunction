fill 417 87 292 417 90 292 minecraft:red_terracotta
setblock 417 87 296 minecraft:stripped_oak_log
fill 417 87 297 417 90 297 minecraft:red_terracotta
setblock 417 87 301 minecraft:stripped_oak_log
fill 417 87 302 417 90 302 minecraft:red_terracotta
setblock 417 87 306 minecraft:stripped_oak_log
fill 417 87 307 417 90 307 minecraft:red_terracotta
setblock 417 87 311 minecraft:stripped_oak_log
fill 376 88 275 376 91 317 minecraft:red_terracotta
fill 377 88 275 380 88 276 minecraft:red_terracotta
setblock 377 88 280 minecraft:stripped_oak_log
fill 377 88 281 377 91 281 minecraft:red_terracotta
setblock 377 88 285 minecraft:stripped_oak_log
fill 377 88 286 377 91 286 minecraft:red_terracotta
setblock 377 88 290 minecraft:stripped_oak_log
fill 377 88 291 377 91 291 minecraft:red_terracotta
setblock 377 88 295 minecraft:stripped_oak_log
setblock 377 88 300 minecraft:stripped_oak_log
fill 377 88 301 377 91 301 minecraft:red_terracotta
setblock 377 88 305 minecraft:stripped_oak_log
fill 377 88 306 377 91 306 minecraft:red_terracotta
setblock 377 88 310 minecraft:stripped_oak_log
fill 377 88 311 377 91 311 minecraft:red_terracotta
fill 377 88 313 377 88 314 minecraft:red_terracotta
setblock 377 88 315 minecraft:stripped_oak_log
fill 377 88 316 378 90 317 minecraft:red_terracotta
setblock 378 88 279 minecraft:stripped_oak_log
fill 378 88 280 378 91 280 minecraft:red_terracotta
setblock 378 88 284 minecraft:stripped_oak_log
fill 378 88 285 378 91 285 minecraft:red_terracotta
setblock 378 88 289 minecraft:stripped_oak_log
fill 378 88 290 378 91 290 minecraft:red_terracotta
setblock 378 88 304 minecraft:stripped_oak_log
fill 378 88 305 378 91 305 minecraft:red_terracotta
setblock 378 88 308 minecraft:red_terracotta
setblock 378 88 309 minecraft:stripped_oak_log
setblock 379 88 279 minecraft:red_terracotta
setblock 379 88 283 minecraft:stripped_oak_log
fill 379 88 284 379 91 284 minecraft:red_terracotta
fill 379 88 317 418 91 317 minecraft:red_terracotta
setblock 380 88 277 minecraft:stripped_oak_log
fill 381 88 275 418 91 275 minecraft:red_terracotta
setblock 381 88 276 minecraft:stripped_oak_log
fill 382 88 276 382 91 276 minecraft:red_terracotta
fill 388 88 277 388 92 277 minecraft:brown_terracotta
setblock 389 88 276 minecraft:brown_terracotta
fill 389 88 278 389 92 278 minecraft:brown_terracotta
setblock 390 88 276 minecraft:red_terracotta
fill 390 88 277 390 92 277 minecraft:brown_terracotta
setblock 390 88 316 minecraft:red_terracotta
setblock 391 88 276 minecraft:stripped_oak_log
setblock 391 88 316 minecraft:stripped_oak_log
fill 392 88 276 392 91 276 minecraft:red_terracotta
setblock 392 88 315 minecraft:stripped_oak_log
fill 392 88 316 392 91 316 minecraft:red_terracotta
fill 393 88 315 393 91 315 minecraft:red_terracotta
setblock 396 88 276 minecraft:stripped_oak_log
setblock 396 88 316 minecraft:stripped_oak_log
fill 397 88 276 397 90 276 minecraft:red_terracotta
setblock 397 88 315 minecraft:stripped_oak_log
fill 397 88 316 397 91 316 minecraft:red_terracotta
fill 398 88 315 398 91 315 minecraft:red_terracotta
fill 399 88 282 399 94 284 minecraft:brown_terracotta
fill 400 88 281 402 94 281 minecraft:brown_terracotta
fill 401 88 285 401 94 285 minecraft:brown_terracotta
fill 403 88 283 403 94 283 minecraft:brown_terracotta
fill 414 88 276 414 89 276 minecraft:red_terracotta
fill 414 88 284 414 89 286 minecraft:red_terracotta
fill 415 88 280 415 88 281 minecraft:red_terracotta
setblock 415 88 282 minecraft:stripped_oak_log
fill 415 88 283 415 91 283 minecraft:red_terracotta
fill 415 88 285 415 88 286 minecraft:red_terracotta
setblock 415 88 287 minecraft:stripped_oak_log
fill 415 88 288 415 91 288 minecraft:red_terracotta
fill 415 88 290 415 88 291 minecraft:red_terracotta
setblock 415 88 302 minecraft:stripped_oak_log
fill 415 88 303 415 91 303 minecraft:red_terracotta
setblock 415 88 307 minecraft:stripped_oak_log
setblock 416 88 276 minecraft:stripped_oak_log
setblock 416 88 281 minecraft:stripped_oak_log
fill 416 88 282 416 91 282 minecraft:red_terracotta
setblock 416 88 286 minecraft:stripped_oak_log
fill 416 88 287 416 91 287 minecraft:red_terracotta
setblock 416 88 290 minecraft:red_terracotta
setblock 416 88 291 minecraft:stripped_oak_log
fill 416 88 292 416 91 292 minecraft:red_terracotta
setblock 416 88 296 minecraft:stripped_oak_log
fill 416 88 297 416 91 297 minecraft:red_terracotta
setblock 416 88 301 minecraft:stripped_oak_log
fill 416 88 302 416 91 302 minecraft:red_terracotta
setblock 416 88 306 minecraft:stripped_oak_log
fill 416 88 307 416 91 307 minecraft:red_terracotta
setblock 416 88 310 minecraft:red_terracotta
fill 417 88 276 418 91 276 minecraft:red_terracotta
setblock 417 88 280 minecraft:stripped_oak_log
fill 417 88 281 418 91 281 minecraft:red_terracotta
setblock 417 88 285 minecraft:stripped_oak_log
fill 417 88 286 418 91 286 minecraft:red_terracotta
setblock 417 88 290 minecraft:stripped_oak_log
fill 417 88 291 418 91 291 minecraft:red_terracotta
setblock 417 88 295 minecraft:stripped_oak_log
fill 417 88 296 418 91 296 minecraft:red_terracotta
setblock 417 88 300 minecraft:stripped_oak_log
fill 417 88 301 418 91 301 minecraft:red_terracotta
setblock 417 88 305 minecraft:stripped_oak_log
fill 417 88 306 418 91 306 minecraft:red_terracotta
fill 417 88 309 418 88 309 minecraft:red_terracotta
setblock 417 88 310 minecraft:stripped_oak_log
fill 417 88 311 418 90 312 minecraft:red_terracotta
fill 418 88 277 418 91 280 minecraft:red_terracotta
fill 418 88 282 418 91 285 minecraft:red_terracotta
fill 418 88 287 418 91 290 minecraft:red_terracotta
fill 418 88 292 418 91 295 minecraft:red_terracotta
fill 418 88 297 418 91 300 minecraft:red_terracotta
fill 418 88 302 418 91 305 minecraft:red_terracotta
fill 418 88 307 418 91 308 minecraft:red_terracotta
fill 418 88 310 418 91 310 minecraft:red_terracotta
fill 418 88 313 418 91 316 minecraft:red_terracotta
fill 377 89 275 379 89 276 minecraft:red_terracotta
setblock 377 89 279 minecraft:stripped_oak_log
fill 377 89 280 377 92 280 minecraft:red_terracotta
setblock 377 89 284 minecraft:stripped_oak_log
fill 377 89 285 377 92 285 minecraft:red_terracotta
setblock 377 89 289 minecraft:stripped_oak_log
fill 377 89 290 377 92 290 minecraft:red_terracotta
setblock 377 89 294 minecraft:stripped_oak_log
fill 377 89 295 377 92 295 minecraft:red_terracotta
setblock 377 89 299 minecraft:stripped_oak_log
fill 377 89 300 377 90 300 minecraft:red_terracotta
setblock 377 89 304 minecraft:stripped_oak_log
fill 377 89 305 377 92 305 minecraft:red_terracotta
setblock 377 89 309 minecraft:stripped_oak_log
fill 377 89 310 378 91 310 minecraft:red_terracotta
setblock 377 89 313 minecraft:red_terracotta
setblock 377 89 314 minecraft:stripped_oak_log
fill 377 89 315 377 92 315 minecraft:red_terracotta
setblock 378 89 278 minecraft:stripped_oak_log
fill 378 89 279 378 92 279 minecraft:red_terracotta
setblock 378 89 283 minecraft:stripped_oak_log
fill 378 89 284 378 92 284 minecraft:red_terracotta
setblock 378 89 288 minecraft:stripped_oak_log
fill 378 89 289 378 92 289 minecraft:red_terracotta
fill 378 89 291 378 90 291 minecraft:red_terracotta
setblock 378 89 304 minecraft:red_terracotta
setblock 378 89 308 minecraft:stripped_oak_log
fill 378 89 309 378 92 309 minecraft:red_terracotta
fill 378 89 311 378 90 311 minecraft:red_terracotta
setblock 379 89 277 minecraft:stripped_oak_log
setblock 379 89 278 minecraft:light[level=12]
setblock 379 89 282 minecraft:stripped_oak_log
fill 379 89 283 379 91 283 minecraft:red_terracotta
setblock 379 89 287 minecraft:stripped_oak_log
setblock 379 89 292 minecraft:light[level=12]
setblock 379 89 299 minecraft:light[level=12]
setblock 379 89 306 minecraft:light[level=12]
setblock 379 89 313 minecraft:light[level=12]
setblock 379 89 316 minecraft:red_terracotta
fill 380 89 275 380 91 275 minecraft:red_terracotta
setblock 380 89 276 minecraft:stripped_oak_log
setblock 380 89 277 minecraft:red_terracotta
setblock 380 89 316 minecraft:stripped_oak_log
fill 381 89 276 381 92 276 minecraft:red_terracotta
setblock 386 89 278 minecraft:light[level=12]
setblock 386 89 285 minecraft:light[level=12]
setblock 386 89 292 minecraft:light[level=12]
setblock 386 89 299 minecraft:light[level=12]
setblock 386 89 306 minecraft:light[level=12]
setblock 386 89 313 minecraft:light[level=12]
fill 388 89 316 389 89 316 minecraft:red_terracotta
setblock 389 89 276 minecraft:red_terracotta
setblock 390 89 276 minecraft:stripped_oak_log
setblock 390 89 316 minecraft:stripped_oak_log
fill 391 89 276 391 92 276 minecraft:red_terracotta
setblock 391 89 315 minecraft:stripped_oak_log
fill 391 89 316 391 92 316 minecraft:red_terracotta
fill 392 89 315 392 92 315 minecraft:red_terracotta
setblock 393 89 278 minecraft:light[level=12]
setblock 393 89 285 minecraft:light[level=12]
setblock 393 89 292 minecraft:light[level=12]
setblock 393 89 299 minecraft:light[level=12]
setblock 393 89 306 minecraft:light[level=12]
setblock 393 89 313 minecraft:light[level=12]
fill 393 89 314 396 89 314 minecraft:red_terracotta
setblock 395 89 276 minecraft:stripped_oak_log
setblock 395 89 316 minecraft:stripped_oak_log
fill 396 89 276 396 92 276 minecraft:red_terracotta
setblock 396 89 315 minecraft:stripped_oak_log
fill 396 89 316 396 92 316 minecraft:red_terracotta
fill 397 89 315 397 92 315 minecraft:red_terracotta
fill 399 89 281 399 94 281 minecraft:brown_terracotta
setblock 400 89 278 minecraft:light[level=12]
fill 400 89 285 400 94 285 minecraft:brown_terracotta
setblock 400 89 292 minecraft:light[level=12]
setblock 400 89 299 minecraft:light[level=12]
setblock 400 89 306 minecraft:light[level=12]
setblock 400 89 313 minecraft:light[level=12]
fill 402 89 285 402 94 285 minecraft:brown_terracotta
fill 403 89 282 403 94 282 minecraft:brown_terracotta
fill 403 89 284 403 94 284 minecraft:brown_terracotta
setblock 407 89 278 minecraft:light[level=12]
setblock 407 89 285 minecraft:light[level=12]
setblock 407 89 292 minecraft:light[level=12]
setblock 407 89 299 minecraft:light[level=12]
setblock 407 89 306 minecraft:light[level=12]
setblock 407 89 313 minecraft:light[level=12]
setblock 414 89 278 minecraft:light[level=12]
fill 414 89 283 414 92 283 minecraft:red_terracotta
setblock 414 89 287 minecraft:stripped_oak_log
fill 414 89 288 414 91 289 minecraft:red_terracotta
setblock 414 89 292 minecraft:light[level=12]
setblock 414 89 299 minecraft:light[level=12]
setblock 414 89 306 minecraft:light[level=12]
setblock 414 89 313 minecraft:light[level=12]
setblock 415 89 276 minecraft:stripped_oak_log
setblock 415 89 280 minecraft:red_terracotta
setblock 415 89 281 minecraft:stripped_oak_log
fill 415 89 282 415 92 282 minecraft:red_terracotta
setblock 415 89 285 minecraft:red_terracotta
setblock 415 89 286 minecraft:stripped_oak_log
fill 415 89 287 415 92 287 minecraft:red_terracotta
setblock 415 89 290 minecraft:red_terracotta
setblock 415 89 291 minecraft:stripped_oak_log
fill 415 89 292 415 91 293 minecraft:red_terracotta
fill 415 89 302 415 90 302 minecraft:red_terracotta
setblock 415 89 306 minecraft:stripped_oak_log
fill 415 89 307 415 91 308 minecraft:red_terracotta
fill 416 89 276 416 92 276 minecraft:red_terracotta
setblock 416 89 280 minecraft:stripped_oak_log
fill 416 89 281 416 92 281 minecraft:red_terracotta
setblock 416 89 285 minecraft:stripped_oak_log
fill 416 89 286 416 92 286 minecraft:red_terracotta
setblock 416 89 290 minecraft:stripped_oak_log
fill 416 89 291 416 92 291 minecraft:red_terracotta
setblock 416 89 295 minecraft:stripped_oak_log
fill 416 89 296 416 92 296 minecraft:red_terracotta
setblock 416 89 300 minecraft:stripped_oak_log
fill 416 89 301 416 92 301 minecraft:red_terracotta
setblock 416 89 305 minecraft:stripped_oak_log
fill 416 89 306 416 92 306 minecraft:red_terracotta
setblock 416 89 310 minecraft:stripped_oak_log
fill 416 89 311 416 92 311 minecraft:red_terracotta
setblock 417 89 279 minecraft:stripped_oak_log
fill 417 89 280 417 92 280 minecraft:red_terracotta
setblock 417 89 284 minecraft:stripped_oak_log
fill 417 89 285 417 92 285 minecraft:red_terracotta
setblock 417 89 289 minecraft:stripped_oak_log
fill 417 89 290 417 92 290 minecraft:red_terracotta
setblock 417 89 294 minecraft:stripped_oak_log
fill 417 89 295 417 92 295 minecraft:red_terracotta
setblock 417 89 299 minecraft:stripped_oak_log
fill 417 89 300 417 92 300 minecraft:red_terracotta
setblock 417 89 304 minecraft:stripped_oak_log
fill 417 89 305 417 92 305 minecraft:red_terracotta
setblock 417 89 309 minecraft:stripped_oak_log
fill 417 89 310 417 92 310 minecraft:red_terracotta
setblock 417 89 313 minecraft:red_terracotta
fill 418 89 309 418 91 309 minecraft:red_terracotta
fill 377 90 275 378 90 276 minecraft:red_terracotta
setblock 377 90 278 minecraft:stripped_oak_log
fill 377 90 279 377 93 279 minecraft:red_terracotta
setblock 377 90 283 minecraft:stripped_oak_log
fill 377 90 284 377 93 284 minecraft:red_terracotta
setblock 377 90 288 minecraft:stripped_oak_log
fill 377 90 289 377 93 289 minecraft:red_terracotta
setblock 377 90 293 minecraft:stripped_oak_log
fill 377 90 294 377 93 294 minecraft:red_terracotta
setblock 377 90 303 minecraft:stripped_oak_log
fill 377 90 304 377 93 304 minecraft:red_terracotta
setblock 377 90 307 minecraft:red_terracotta
setblock 377 90 308 minecraft:stripped_oak_log
fill 377 90 309 377 93 309 minecraft:red_terracotta
setblock 377 90 313 minecraft:stripped_oak_log
fill 377 90 314 377 93 314 minecraft:red_terracotta
setblock 378 90 277 minecraft:stripped_oak_log
fill 378 90 278 378 93 278 minecraft:red_terracotta
setblock 378 90 282 minecraft:stripped_oak_log
fill 378 90 283 378 93 283 minecraft:red_terracotta
setblock 378 90 287 minecraft:stripped_oak_log
fill 378 90 288 379 91 288 minecraft:red_terracotta
setblock 378 90 307 minecraft:stripped_oak_log
fill 378 90 308 378 93 308 minecraft:red_terracotta
setblock 378 90 312 minecraft:stripped_oak_log
fill 378 90 313 378 93 313 minecraft:red_terracotta
fill 379 90 275 379 91 275 minecraft:red_terracotta
setblock 379 90 276 minecraft:stripped_oak_log
fill 379 90 277 379 91 277 minecraft:red_terracotta
setblock 379 90 281 minecraft:stripped_oak_log
fill 379 90 282 379 91 282 minecraft:red_terracotta
setblock 379 90 286 minecraft:stripped_oak_log
fill 379 90 287 379 92 287 minecraft:red_terracotta
setblock 379 90 316 minecraft:stripped_oak_log
fill 380 90 276 380 93 276 minecraft:red_terracotta
fill 380 90 316 381 92 316 minecraft:red_terracotta
fill 386 90 316 388 90 316 minecraft:red_terracotta
setblock 388 90 276 minecraft:red_terracotta
fill 388 90 278 388 92 278 minecraft:brown_terracotta
setblock 389 90 276 minecraft:stripped_oak_log
setblock 389 90 315 minecraft:red_terracotta
setblock 389 90 316 minecraft:stripped_oak_log
fill 390 90 276 390 93 276 minecraft:red_terracotta
fill 390 90 278 390 92 278 minecraft:brown_terracotta
setblock 390 90 315 minecraft:stripped_oak_log
fill 390 90 316 390 93 316 minecraft:red_terracotta
setblock 391 90 314 minecraft:stripped_oak_log
fill 391 90 315 391 93 315 minecraft:red_terracotta
fill 392 90 314 395 90 314 minecraft:red_terracotta
setblock 394 90 276 minecraft:stripped_oak_log
setblock 394 90 316 minecraft:stripped_oak_log
fill 395 90 276 395 93 276 minecraft:red_terracotta
setblock 395 90 315 minecraft:stripped_oak_log
fill 395 90 316 395 93 316 minecraft:red_terracotta
setblock 396 90 314 minecraft:stripped_oak_log
fill 396 90 315 396 93 315 minecraft:red_terracotta
fill 397 90 314 397 93 314 minecraft:red_terracotta
fill 398 90 282 398 94 284 minecraft:brown_terracotta
fill 399 90 285 399 94 285 minecraft:brown_terracotta
setblock 399 90 316 minecraft:stripped_oak_log
fill 400 90 280 402 94 280 minecraft:brown_terracotta
fill 400 90 316 400 92 316 minecraft:red_terracotta
fill 401 90 286 401 94 286 minecraft:brown_terracotta
fill 403 90 281 403 94 281 minecraft:brown_terracotta
fill 403 90 285 403 94 285 minecraft:brown_terracotta
fill 404 90 283 404 94 283 minecraft:brown_terracotta
setblock 413 90 276 minecraft:red_terracotta
setblock 414 90 276 minecraft:stripped_oak_log
fill 414 90 284 414 90 285 minecraft:red_terracotta
setblock 414 90 286 minecraft:stripped_oak_log
fill 414 90 287 414 93 287 minecraft:red_terracotta
setblock 414 90 290 minecraft:red_terracotta
setblock 414 90 291 minecraft:stripped_oak_log
fill 415 90 276 415 92 277 minecraft:red_terracotta
setblock 415 90 280 minecraft:stripped_oak_log
fill 415 90 281 415 93 281 minecraft:red_terracotta
setblock 415 90 285 minecraft:stripped_oak_log
fill 415 90 286 415 93 286 minecraft:red_terracotta
setblock 415 90 290 minecraft:stripped_oak_log
fill 415 90 291 415 93 291 minecraft:red_terracotta
setblock 415 90 294 minecraft:red_terracotta
setblock 415 90 305 minecraft:stripped_oak_log
fill 415 90 306 415 92 306 minecraft:red_terracotta
setblock 415 90 309 minecraft:red_terracotta
fill 415 90 316 416 92 316 minecraft:red_terracotta
fill 416 90 277 416 91 277 minecraft:red_terracotta
setblock 416 90 279 minecraft:stripped_oak_log
fill 416 90 280 416 93 280 minecraft:red_terracotta
setblock 416 90 284 minecraft:stripped_oak_log
fill 416 90 285 416 93 285 minecraft:red_terracotta
setblock 416 90 289 minecraft:stripped_oak_log
fill 416 90 290 416 93 290 minecraft:red_terracotta
setblock 416 90 294 minecraft:stripped_oak_log
fill 416 90 295 416 93 295 minecraft:red_terracotta
setblock 416 90 299 minecraft:stripped_oak_log
fill 416 90 300 416 91 300 minecraft:red_terracotta
setblock 416 90 304 minecraft:stripped_oak_log
fill 416 90 305 416 93 305 minecraft:red_terracotta
setblock 416 90 308 minecraft:red_terracotta
setblock 416 90 309 minecraft:stripped_oak_log
fill 416 90 310 416 93 310 minecraft:red_terracotta
fill 416 90 312 416 91 312 minecraft:red_terracotta
setblock 417 90 278 minecraft:stripped_oak_log
fill 417 90 279 417 93 279 minecraft:red_terracotta
setblock 417 90 283 minecraft:stripped_oak_log
fill 417 90 284 417 93 284 minecraft:red_terracotta
setblock 417 90 288 minecraft:stripped_oak_log
fill 417 90 289 417 93 289 minecraft:red_terracotta
setblock 417 90 293 minecraft:stripped_oak_log
fill 417 90 294 417 93 294 minecraft:red_terracotta
setblock 417 90 298 minecraft:stripped_oak_log
fill 417 90 299 417 93 299 minecraft:red_terracotta
setblock 417 90 303 minecraft:stripped_oak_log
fill 417 90 304 417 93 304 minecraft:red_terracotta
setblock 417 90 308 minecraft:stripped_oak_log
fill 417 90 309 417 93 309 minecraft:red_terracotta
setblock 417 90 313 minecraft:stripped_oak_log
fill 417 90 314 417 92 315 minecraft:red_terracotta
fill 377 91 275 377 91 276 minecraft:red_terracotta
setblock 377 91 277 minecraft:stripped_oak_log
fill 377 91 278 377 94 278 minecraft:red_terracotta
setblock 377 91 282 minecraft:stripped_oak_log
fill 377 91 283 377 94 283 minecraft:red_terracotta
setblock 377 91 287 minecraft:stripped_oak_log
fill 377 91 288 377 94 288 minecraft:red_terracotta
setblock 377 91 292 minecraft:stripped_oak_log
fill 377 91 293 377 94 293 minecraft:red_terracotta
setblock 377 91 302 minecraft:stripped_oak_log
fill 377 91 303 377 92 303 minecraft:red_terracotta
setblock 377 91 307 minecraft:stripped_oak_log
fill 377 91 308 377 94 308 minecraft:red_terracotta
setblock 377 91 312 minecraft:stripped_oak_log
fill 377 91 313 377 94 313 minecraft:red_terracotta
fill 377 91 316 377 91 317 minecraft:red_terracotta
setblock 378 91 275 minecraft:red_terracotta
setblock 378 91 276 minecraft:stripped_oak_log
fill 378 91 277 378 93 277 minecraft:red_terracotta
setblock 378 91 281 minecraft:stripped_oak_log
fill 378 91 282 378 94 282 minecraft:red_terracotta
setblock 378 91 286 minecraft:stripped_oak_log
fill 378 91 287 378 94 287 minecraft:red_terracotta
setblock 378 91 291 minecraft:stripped_oak_log
setblock 378 91 306 minecraft:stripped_oak_log
fill 378 91 307 378 93 307 minecraft:red_terracotta
setblock 378 91 311 minecraft:stripped_oak_log
fill 378 91 312 378 94 312 minecraft:red_terracotta
fill 378 91 314 378 92 314 minecraft:red_terracotta
setblock 378 91 316 minecraft:stripped_oak_log
setblock 378 91 317 minecraft:red_terracotta
fill 379 91 276 379 94 276 minecraft:red_terracotta
setblock 379 91 285 minecraft:stripped_oak_log
fill 379 91 286 379 92 286 minecraft:red_terracotta
fill 379 91 316 379 94 316 minecraft:red_terracotta
fill 381 91 299 381 94 299 minecraft:iron_bars
setblock 382 91 316 minecraft:red_terracotta
setblock 383 91 316 minecraft:stripped_oak_log
fill 384 91 316 387 91 316 minecraft:red_terracotta
setblock 387 91 276 minecraft:red_terracotta
fill 387 91 315 388 91 315 minecraft:red_terracotta
setblock 388 91 276 minecraft:stripped_oak_log
setblock 388 91 316 minecraft:stripped_oak_log
fill 389 91 276 389 94 276 minecraft:red_terracotta
setblock 389 91 314 minecraft:red_terracotta
setblock 389 91 315 minecraft:stripped_oak_log
fill 389 91 316 389 94 316 minecraft:red_terracotta
setblock 390 91 314 minecraft:stripped_oak_log
fill 390 91 315 390 94 315 minecraft:red_terracotta
fill 391 91 314 394 91 314 minecraft:red_terracotta
fill 392 91 313 395 91 313 minecraft:red_terracotta
setblock 393 91 276 minecraft:stripped_oak_log
setblock 393 91 316 minecraft:stripped_oak_log
fill 394 91 276 394 94 276 minecraft:red_terracotta
setblock 394 91 315 minecraft:stripped_oak_log
fill 394 91 316 394 94 316 minecraft:red_terracotta
setblock 395 91 314 minecraft:stripped_oak_log
fill 395 91 315 395 94 315 minecraft:red_terracotta
fill 396 91 314 396 94 314 minecraft:red_terracotta
fill 398 91 281 398 94 281 minecraft:brown_terracotta
fill 398 91 285 398 94 285 minecraft:brown_terracotta
setblock 398 91 316 minecraft:stripped_oak_log
fill 399 91 280 399 94 280 minecraft:brown_terracotta
fill 399 91 286 400 94 286 minecraft:brown_terracotta
fill 399 91 316 399 94 316 minecraft:red_terracotta
fill 402 91 286 402 94 286 minecraft:brown_terracotta
fill 403 91 280 403 94 280 minecraft:brown_terracotta
fill 404 91 281 404 94 282 minecraft:brown_terracotta
fill 404 91 284 404 94 284 minecraft:brown_terracotta
setblock 412 91 276 minecraft:red_terracotta
setblock 412 91 316 minecraft:red_terracotta
setblock 413 91 276 minecraft:stripped_oak_log
setblock 413 91 286 minecraft:stripped_oak_log
fill 413 91 287 413 93 288 minecraft:red_terracotta
setblock 413 91 316 minecraft:stripped_oak_log
fill 414 91 276 414 93 277 minecraft:red_terracotta
setblock 414 91 282 minecraft:red_terracotta
setblock 414 91 284 minecraft:red_terracotta
setblock 414 91 285 minecraft:stripped_oak_log
fill 414 91 286 414 94 286 minecraft:red_terracotta
setblock 414 91 290 minecraft:stripped_oak_log
fill 414 91 291 414 93 292 minecraft:red_terracotta
fill 414 91 316 414 94 316 minecraft:red_terracotta
fill 415 91 280 415 92 280 minecraft:red_terracotta
setblock 415 91 284 minecraft:stripped_oak_log
fill 415 91 285 415 94 285 minecraft:red_terracotta
setblock 415 91 289 minecraft:stripped_oak_log
fill 415 91 290 415 94 290 minecraft:red_terracotta
setblock 415 91 294 minecraft:stripped_oak_log
fill 415 91 295 415 94 295 minecraft:red_terracotta
setblock 415 91 304 minecraft:stripped_oak_log
fill 415 91 305 415 92 305 minecraft:red_terracotta
setblock 415 91 309 minecraft:stripped_oak_log
fill 415 91 310 415 93 310 minecraft:red_terracotta
setblock 416 91 278 minecraft:stripped_oak_log
fill 416 91 279 416 94 279 minecraft:red_terracotta
setblock 416 91 283 minecraft:stripped_oak_log
fill 416 91 284 416 94 284 minecraft:red_terracotta
setblock 416 91 288 minecraft:stripped_oak_log
fill 416 91 289 416 94 289 minecraft:red_terracotta
setblock 416 91 293 minecraft:stripped_oak_log
fill 416 91 294 416 94 294 minecraft:red_terracotta
setblock 416 91 298 minecraft:stripped_oak_log
fill 416 91 299 416 92 299 minecraft:red_terracotta
setblock 416 91 303 minecraft:stripped_oak_log
fill 416 91 304 416 93 304 minecraft:red_terracotta
setblock 416 91 308 minecraft:stripped_oak_log
fill 416 91 309 416 94 309 minecraft:red_terracotta
setblock 416 91 313 minecraft:stripped_oak_log
setblock 417 91 277 minecraft:stripped_oak_log
fill 417 91 278 417 94 278 minecraft:red_terracotta
setblock 417 91 282 minecraft:stripped_oak_log
fill 417 91 283 417 94 283 minecraft:red_terracotta
setblock 417 91 287 minecraft:stripped_oak_log
fill 417 91 288 417 94 288 minecraft:red_terracotta
setblock 417 91 292 minecraft:stripped_oak_log
fill 417 91 293 417 94 293 minecraft:red_terracotta
setblock 417 91 297 minecraft:stripped_oak_log
fill 417 91 298 417 94 298 minecraft:red_terracotta
setblock 417 91 302 minecraft:stripped_oak_log
fill 417 91 303 417 93 303 minecraft:red_terracotta
setblock 417 91 307 minecraft:stripped_oak_log
fill 417 91 308 417 94 308 minecraft:red_terracotta
fill 417 91 311 418 91 311 minecraft:red_terracotta
setblock 417 91 312 minecraft:stripped_oak_log
fill 417 91 313 417 94 313 minecraft:red_terracotta
setblock 417 91 316 minecraft:red_terracotta
setblock 418 91 312 minecraft:red_terracotta
fill 376 92 275 376 95 317 minecraft:yellow_terracotta
fill 377 92 275 418 95 275 minecraft:yellow_terracotta
setblock 377 92 276 minecraft:stripped_oak_log
fill 377 92 277 377 95 277 minecraft:red_terracotta
setblock 377 92 281 minecraft:stripped_oak_log
fill 377 92 282 377 95 282 minecraft:red_terracotta
setblock 377 92 286 minecraft:stripped_oak_log
fill 377 92 287 377 95 287 minecraft:red_terracotta
setblock 377 92 291 minecraft:stripped_oak_log
fill 377 92 292 377 95 292 minecraft:red_terracotta
setblock 377 92 302 minecraft:red_terracotta
setblock 377 92 306 minecraft:stripped_oak_log
fill 377 92 307 377 95 307 minecraft:red_terracotta
setblock 377 92 310 minecraft:red_terracotta
setblock 377 92 311 minecraft:stripped_oak_log
fill 377 92 312 377 95 312 minecraft:red_terracotta
setblock 377 92 316 minecraft:stripped_oak_log
fill 377 92 317 418 95 317 minecraft:yellow_terracotta
fill 378 92 276 378 95 276 minecraft:red_terracotta
setblock 378 92 280 minecraft:stripped_oak_log
fill 378 92 281 378 93 281 minecraft:red_terracotta
setblock 378 92 285 minecraft:stripped_oak_log
fill 378 92 286 378 95 286 minecraft:red_terracotta
fill 378 92 288 378 93 288 minecraft:red_terracotta
setblock 378 92 290 minecraft:stripped_oak_log
fill 378 92 291 378 94 291 minecraft:red_terracotta
setblock 378 92 306 minecraft:red_terracotta
setblock 378 92 310 minecraft:stripped_oak_log
fill 378 92 311 378 95 311 minecraft:red_terracotta
setblock 378 92 315 minecraft:stripped_oak_log
fill 378 92 316 378 95 316 minecraft:red_terracotta
setblock 379 92 284 minecraft:stripped_oak_log
setblock 379 92 285 minecraft:red_terracotta
fill 379 92 315 379 95 315 minecraft:red_terracotta
setblock 382 92 276 minecraft:stripped_oak_log
setblock 382 92 316 minecraft:stripped_oak_log
fill 383 92 316 386 92 316 minecraft:red_terracotta
fill 386 92 315 387 92 315 minecraft:red_terracotta
setblock 387 92 276 minecraft:stripped_oak_log
setblock 387 92 316 minecraft:stripped_oak_log
fill 388 92 276 388 95 276 minecraft:red_terracotta
setblock 388 92 314 minecraft:red_terracotta
setblock 388 92 315 minecraft:stripped_oak_log
fill 388 92 316 388 95 316 minecraft:red_terracotta
setblock 389 92 314 minecraft:stripped_oak_log
fill 389 92 315 389 95 315 minecraft:red_terracotta
setblock 390 92 313 minecraft:stripped_oak_log
fill 390 92 314 393 92 314 minecraft:red_terracotta
fill 391 92 313 394 92 313 minecraft:red_terracotta
setblock 392 92 276 minecraft:stripped_oak_log
setblock 392 92 316 minecraft:stripped_oak_log
fill 393 92 276 393 95 276 minecraft:red_terracotta
setblock 393 92 315 minecraft:stripped_oak_log
fill 393 92 316 393 95 316 minecraft:red_terracotta
setblock 394 92 314 minecraft:stripped_oak_log
fill 394 92 315 394 95 315 minecraft:red_terracotta
setblock 395 92 313 minecraft:stripped_oak_log
fill 395 92 314 395 95 314 minecraft:red_terracotta
fill 396 92 313 396 93 313 minecraft:red_terracotta
fill 397 92 281 397 94 284 minecraft:brown_terracotta
setblock 397 92 316 minecraft:stripped_oak_log
fill 398 92 280 398 94 280 minecraft:brown_terracotta
fill 398 92 286 398 94 286 minecraft:brown_terracotta
setblock 398 92 315 minecraft:stripped_oak_log
fill 398 92 316 398 95 316 minecraft:red_terracotta
fill 399 92 279 402 94 279 minecraft:brown_terracotta
fill 401 92 287 401 94 287 minecraft:brown_terracotta
fill 403 92 286 403 94 286 minecraft:brown_terracotta
fill 404 92 280 404 94 280 minecraft:brown_terracotta
fill 404 92 285 404 94 285 minecraft:brown_terracotta
fill 405 92 283 405 94 283 minecraft:brown_terracotta
setblock 411 92 276 minecraft:red_terracotta
setblock 411 92 316 minecraft:red_terracotta
setblock 412 92 276 minecraft:stripped_oak_log
setblock 412 92 316 minecraft:stripped_oak_log
fill 413 92 276 413 95 276 minecraft:red_terracotta
fill 413 92 286 413 93 286 minecraft:red_terracotta
setblock 413 92 289 minecraft:red_terracotta
setblock 413 92 290 minecraft:stripped_oak_log
fill 413 92 316 413 95 316 minecraft:red_terracotta
setblock 414 92 284 minecraft:stripped_oak_log
fill 414 92 285 414 95 285 minecraft:red_terracotta
setblock 414 92 288 minecraft:red_terracotta
setblock 414 92 289 minecraft:stripped_oak_log
fill 414 92 290 414 95 290 minecraft:red_terracotta
setblock 414 92 293 minecraft:red_terracotta
setblock 415 92 283 minecraft:stripped_oak_log
fill 415 92 284 415 95 284 minecraft:red_terracotta
setblock 415 92 288 minecraft:stripped_oak_log
fill 415 92 289 415 95 289 minecraft:red_terracotta
setblock 415 92 292 minecraft:red_terracotta
setblock 415 92 293 minecraft:stripped_oak_log
fill 415 92 294 415 95 294 minecraft:red_terracotta
setblock 415 92 307 minecraft:red_terracotta
setblock 415 92 308 minecraft:stripped_oak_log
fill 415 92 309 415 93 309 minecraft:red_terracotta
setblock 416 92 277 minecraft:stripped_oak_log
fill 416 92 278 416 94 278 minecraft:red_terracotta
setblock 416 92 282 minecraft:stripped_oak_log
fill 416 92 283 416 95 283 minecraft:red_terracotta
setblock 416 92 287 minecraft:stripped_oak_log
fill 416 92 288 416 95 288 minecraft:red_terracotta
setblock 416 92 292 minecraft:stripped_oak_log
fill 416 92 293 416 95 293 minecraft:red_terracotta
setblock 416 92 297 minecraft:stripped_oak_log
setblock 416 92 298 minecraft:red_terracotta
setblock 416 92 302 minecraft:stripped_oak_log
setblock 416 92 303 minecraft:red_terracotta
setblock 416 92 307 minecraft:stripped_oak_log
fill 416 92 308 416 94 308 minecraft:red_terracotta
setblock 416 92 312 minecraft:stripped_oak_log
fill 416 92 313 416 95 313 minecraft:red_terracotta
setblock 417 92 276 minecraft:stripped_oak_log
fill 417 92 277 417 95 277 minecraft:red_terracotta
setblock 417 92 281 minecraft:stripped_oak_log
fill 417 92 282 417 95 282 minecraft:red_terracotta
setblock 417 92 286 minecraft:stripped_oak_log
fill 417 92 287 417 95 287 minecraft:red_terracotta
setblock 417 92 291 minecraft:stripped_oak_log
fill 417 92 292 417 95 292 minecraft:red_terracotta
setblock 417 92 296 minecraft:stripped_oak_log
fill 417 92 297 417 95 297 minecraft:red_terracotta
setblock 417 92 301 minecraft:stripped_oak_log
fill 417 92 302 417 93 302 minecraft:red_terracotta
setblock 417 92 306 minecraft:stripped_oak_log
fill 417 92 307 417 95 307 minecraft:red_terracotta
setblock 417 92 311 minecraft:stripped_oak_log
fill 417 92 312 417 95 312 minecraft:red_terracotta
setblock 417 92 316 minecraft:stripped_oak_log
fill 418 92 276 418 95 316 minecraft:yellow_terracotta
fill 377 93 276 377 96 276 minecraft:red_terracotta
setblock 377 93 280 minecraft:stripped_oak_log
fill 377 93 281 377 96 281 minecraft:red_terracotta
setblock 377 93 285 minecraft:stripped_oak_log
fill 377 93 286 377 96 286 minecraft:red_terracotta
setblock 377 93 290 minecraft:stripped_oak_log
fill 377 93 291 377 96 291 minecraft:red_terracotta
setblock 377 93 295 minecraft:stripped_oak_log
setblock 377 93 305 minecraft:stripped_oak_log
fill 377 93 306 377 95 306 minecraft:red_terracotta
setblock 377 93 310 minecraft:stripped_oak_log
fill 377 93 311 377 96 311 minecraft:red_terracotta
setblock 377 93 315 minecraft:stripped_oak_log
fill 377 93 316 377 96 316 minecraft:red_terracotta
setblock 378 93 279 minecraft:stripped_oak_log
setblock 378 93 280 minecraft:red_terracotta
setblock 378 93 284 minecraft:stripped_oak_log
fill 378 93 285 378 94 285 minecraft:red_terracotta
setblock 378 93 289 minecraft:stripped_oak_log
fill 378 93 290 378 95 290 minecraft:red_terracotta
setblock 378 93 309 minecraft:stripped_oak_log
fill 378 93 310 378 95 310 minecraft:red_terracotta
setblock 378 93 314 minecraft:stripped_oak_log
fill 378 93 315 378 96 315 minecraft:red_terracotta
setblock 380 93 316 minecraft:red_terracotta
setblock 381 93 276 minecraft:stripped_oak_log
setblock 381 93 316 minecraft:stripped_oak_log
fill 382 93 316 385 93 316 minecraft:red_terracotta
fill 384 93 315 386 93 315 minecraft:red_terracotta
setblock 386 93 276 minecraft:stripped_oak_log
setblock 386 93 316 minecraft:stripped_oak_log
fill 387 93 276 387 96 276 minecraft:red_terracotta
setblock 387 93 314 minecraft:red_terracotta
setblock 387 93 315 minecraft:stripped_oak_log
fill 387 93 316 387 96 316 minecraft:red_terracotta
setblock 388 93 314 minecraft:stripped_oak_log
fill 388 93 315 388 96 315 minecraft:red_terracotta
setblock 389 93 313 minecraft:stripped_oak_log
fill 389 93 314 392 93 314 minecraft:red_terracotta
fill 390 93 313 393 93 313 minecraft:red_terracotta
setblock 391 93 276 minecraft:stripped_oak_log
setblock 391 93 316 minecraft:stripped_oak_log
fill 392 93 276 392 96 276 minecraft:red_terracotta
fill 392 93 312 393 94 312 minecraft:red_terracotta
setblock 392 93 315 minecraft:stripped_oak_log
fill 392 93 316 392 96 316 minecraft:red_terracotta
setblock 393 93 314 minecraft:stripped_oak_log
fill 393 93 315 393 96 315 minecraft:red_terracotta
setblock 394 93 313 minecraft:stripped_oak_log
fill 394 93 314 394 96 314 minecraft:red_terracotta
fill 395 93 313 395 95 313 minecraft:red_terracotta
setblock 396 93 316 minecraft:stripped_oak_log
fill 397 93 280 397 94 280 minecraft:brown_terracotta
fill 397 93 285 397 94 285 minecraft:brown_terracotta
setblock 397 93 315 minecraft:stripped_oak_log
fill 397 93 316 397 96 316 minecraft:red_terracotta
fill 398 93 279 398 94 279 minecraft:brown_terracotta
fill 398 93 315 398 94 315 minecraft:red_terracotta
fill 399 93 287 400 94 287 minecraft:brown_terracotta
fill 402 93 287 403 94 287 minecraft:brown_terracotta
fill 403 93 279 403 94 279 minecraft:brown_terracotta
fill 404 93 286 404 94 286 minecraft:brown_terracotta
fill 405 93 281 405 94 282 minecraft:brown_terracotta
fill 405 93 284 405 94 285 minecraft:brown_terracotta
fill 409 93 316 410 93 316 minecraft:red_terracotta
setblock 410 93 276 minecraft:red_terracotta
setblock 411 93 276 minecraft:stripped_oak_log
setblock 411 93 316 minecraft:stripped_oak_log
fill 412 93 276 412 96 276 minecraft:red_terracotta
setblock 412 93 315 minecraft:stripped_oak_log
fill 412 93 316 412 96 316 minecraft:red_terracotta
fill 413 93 277 413 94 277 minecraft:red_terracotta
setblock 413 93 289 minecraft:stripped_oak_log
fill 413 93 290 413 95 290 minecraft:red_terracotta
fill 413 93 315 415 94 315 minecraft:red_terracotta
setblock 414 93 283 minecraft:stripped_oak_log
fill 414 93 284 414 94 284 minecraft:red_terracotta
setblock 414 93 288 minecraft:stripped_oak_log
fill 414 93 289 414 96 289 minecraft:red_terracotta
setblock 414 93 293 minecraft:stripped_oak_log
setblock 415 93 276 minecraft:red_terracotta
setblock 415 93 277 minecraft:stripped_oak_log
setblock 415 93 282 minecraft:stripped_oak_log
fill 415 93 283 415 95 283 minecraft:red_terracotta
setblock 415 93 287 minecraft:stripped_oak_log
fill 415 93 288 415 96 288 minecraft:red_terracotta
setblock 415 93 292 minecraft:stripped_oak_log
fill 415 93 293 415 96 293 minecraft:red_terracotta
setblock 415 93 308 minecraft:red_terracotta
setblock 415 93 316 minecraft:red_terracotta
setblock 416 93 276 minecraft:stripped_oak_log
setblock 416 93 277 minecraft:red_terracotta
setblock 416 93 281 minecraft:stripped_oak_log
fill 416 93 282 416 96 282 minecraft:red_terracotta
setblock 416 93 286 minecraft:stripped_oak_log
fill 416 93 287 416 96 287 minecraft:red_terracotta
setblock 416 93 291 minecraft:stripped_oak_log
fill 416 93 292 416 96 292 minecraft:red_terracotta
setblock 416 93 296 minecraft:stripped_oak_log
setblock 416 93 297 minecraft:red_terracotta
setblock 416 93 306 minecraft:stripped_oak_log
setblock 416 93 307 minecraft:red_terracotta
setblock 416 93 311 minecraft:stripped_oak_log
fill 416 93 312 416 95 312 minecraft:red_terracotta
fill 416 93 314 417 93 314 minecraft:red_terracotta
setblock 416 93 316 minecraft:stripped_oak_log
fill 417 93 276 417 96 276 minecraft:red_terracotta
setblock 417 93 280 minecraft:stripped_oak_log
fill 417 93 281 417 96 281 minecraft:red_terracotta
setblock 417 93 285 minecraft:stripped_oak_log
fill 417 93 286 417 96 286 minecraft:red_terracotta
setblock 417 93 290 minecraft:stripped_oak_log
fill 417 93 291 417 96 291 minecraft:red_terracotta
setblock 417 93 295 minecraft:stripped_oak_log
fill 417 93 296 417 96 296 minecraft:red_terracotta
setblock 417 93 300 minecraft:stripped_oak_log
setblock 417 93 301 minecraft:red_terracotta
setblock 417 93 305 minecraft:stripped_oak_log
fill 417 93 306 417 94 306 minecraft:red_terracotta
setblock 417 93 310 minecraft:stripped_oak_log
fill 417 93 311 417 96 311 minecraft:red_terracotta
setblock 417 93 315 minecraft:stripped_oak_log
fill 417 93 316 417 96 316 minecraft:red_terracotta
setblock 377 94 279 minecraft:stripped_oak_log
fill 377 94 280 377 96 280 minecraft:red_terracotta
setblock 377 94 284 minecraft:stripped_oak_log
fill 377 94 285 377 96 285 minecraft:red_terracotta
setblock 377 94 289 minecraft:stripped_oak_log
fill 377 94 290 377 97 290 minecraft:red_terracotta
setblock 377 94 294 minecraft:stripped_oak_log
setblock 377 94 305 minecraft:red_terracotta
setblock 377 94 309 minecraft:stripped_oak_log
fill 377 94 310 377 97 310 minecraft:red_terracotta
setblock 377 94 314 minecraft:stripped_oak_log
fill 377 94 315 377 97 315 minecraft:red_terracotta
setblock 378 94 283 minecraft:stripped_oak_log
setblock 378 94 284 minecraft:red_terracotta
setblock 378 94 288 minecraft:stripped_oak_log
fill 378 94 289 378 95 289 minecraft:red_terracotta
setblock 378 94 308 minecraft:stripped_oak_log
setblock 378 94 309 minecraft:red_terracotta
setblock 378 94 313 minecraft:stripped_oak_log
fill 378 94 314 378 97 314 minecraft:red_terracotta
setblock 380 94 276 minecraft:stripped_oak_log
setblock 380 94 315 minecraft:red_terracotta
setblock 380 94 316 minecraft:stripped_oak_log
setblock 381 94 276 minecraft:red_terracotta
fill 381 94 316 384 94 316 minecraft:red_terracotta
fill 383 94 315 385 94 315 minecraft:red_terracotta
setblock 385 94 316 minecraft:stripped_oak_log
fill 386 94 276 386 97 276 minecraft:red_terracotta
setblock 386 94 314 minecraft:red_terracotta
setblock 386 94 315 minecraft:stripped_oak_log
fill 386 94 316 386 97 316 minecraft:red_terracotta
setblock 387 94 314 minecraft:stripped_oak_log
fill 387 94 315 387 97 315 minecraft:red_terracotta
setblock 388 94 313 minecraft:stripped_oak_log
fill 388 94 314 391 94 314 minecraft:red_terracotta
fill 389 94 313 392 94 313 minecraft:red_terracotta
setblock 390 94 276 minecraft:stripped_oak_log
setblock 390 94 316 minecraft:stripped_oak_log
fill 391 94 276 391 97 276 minecraft:red_terracotta
setblock 391 94 312 minecraft:red_terracotta
setblock 391 94 315 minecraft:stripped_oak_log
fill 391 94 316 391 97 316 minecraft:red_terracotta
setblock 392 94 314 minecraft:stripped_oak_log
fill 392 94 315 392 97 315 minecraft:red_terracotta
setblock 393 94 313 minecraft:stripped_oak_log
fill 393 94 314 393 97 314 minecraft:red_terracotta
fill 394 94 313 394 96 313 minecraft:red_terracotta
setblock 395 94 276 minecraft:stripped_oak_log
setblock 395 94 316 minecraft:stripped_oak_log
fill 396 94 281 396 94 284 minecraft:brown_terracotta
setblock 396 94 315 minecraft:stripped_oak_log
fill 396 94 316 396 97 316 minecraft:red_terracotta
setblock 397 94 286 minecraft:brown_terracotta
setblock 397 94 314 minecraft:stripped_oak_log
fill 397 94 315 397 96 315 minecraft:red_terracotta
setblock 398 94 287 minecraft:brown_terracotta
fill 399 94 278 402 94 278 minecraft:brown_terracotta
setblock 401 94 288 minecraft:brown_terracotta
setblock 404 94 279 minecraft:brown_terracotta
setblock 405 94 280 minecraft:brown_terracotta
setblock 406 94 283 minecraft:brown_terracotta
setblock 409 94 316 minecraft:red_terracotta
setblock 410 94 276 minecraft:stripped_oak_log
setblock 410 94 316 minecraft:stripped_oak_log
fill 411 94 276 411 97 276 minecraft:red_terracotta
setblock 411 94 315 minecraft:stripped_oak_log
fill 411 94 316 411 97 316 minecraft:red_terracotta
fill 412 94 315 412 97 315 minecraft:red_terracotta
setblock 413 94 287 minecraft:red_terracotta
setblock 413 94 288 minecraft:stripped_oak_log
fill 413 94 289 413 95 289 minecraft:red_terracotta
setblock 414 94 276 minecraft:red_terracotta
setblock 414 94 277 minecraft:stripped_oak_log
setblock 414 94 287 minecraft:stripped_oak_log
fill 414 94 288 414 96 288 minecraft:red_terracotta
setblock 414 94 291 minecraft:red_terracotta
setblock 414 94 292 minecraft:stripped_oak_log
fill 414 94 293 414 95 293 minecraft:red_terracotta
fill 414 94 305 416 94 307 minecraft:terracotta
setblock 415 94 276 minecraft:stripped_oak_log
setblock 415 94 277 minecraft:red_terracotta
setblock 415 94 282 minecraft:red_terracotta
setblock 415 94 286 minecraft:stripped_oak_log
fill 415 94 287 415 97 287 minecraft:red_terracotta
setblock 415 94 291 minecraft:stripped_oak_log
fill 415 94 292 415 97 292 minecraft:red_terracotta
setblock 415 94 316 minecraft:stripped_oak_log
fill 416 94 276 416 97 276 minecraft:red_terracotta
setblock 416 94 280 minecraft:stripped_oak_log
fill 416 94 281 416 95 281 minecraft:red_terracotta
setblock 416 94 285 minecraft:stripped_oak_log
fill 416 94 286 416 97 286 minecraft:red_terracotta
setblock 416 94 290 minecraft:stripped_oak_log
fill 416 94 291 416 97 291 minecraft:red_terracotta
setblock 416 94 295 minecraft:stripped_oak_log
setblock 416 94 296 minecraft:red_terracotta
setblock 416 94 310 minecraft:stripped_oak_log
fill 416 94 311 416 95 311 minecraft:red_terracotta
setblock 416 94 314 minecraft:red_terracotta
fill 416 94 316 416 97 316 minecraft:red_terracotta
setblock 417 94 279 minecraft:stripped_oak_log
fill 417 94 280 417 96 280 minecraft:red_terracotta
setblock 417 94 284 minecraft:stripped_oak_log
fill 417 94 285 417 97 285 minecraft:red_terracotta
setblock 417 94 289 minecraft:stripped_oak_log
fill 417 94 290 417 97 290 minecraft:red_terracotta
setblock 417 94 294 minecraft:stripped_oak_log
fill 417 94 295 417 97 295 minecraft:red_terracotta
setblock 417 94 304 minecraft:stripped_oak_log
setblock 417 94 305 minecraft:red_terracotta
setblock 417 94 309 minecraft:stripped_oak_log
fill 417 94 310 417 96 310 minecraft:red_terracotta
setblock 417 94 314 minecraft:stripped_oak_log
fill 417 94 315 417 97 315 minecraft:red_terracotta
setblock 377 95 278 minecraft:stripped_oak_log
fill 377 95 279 377 96 279 minecraft:red_terracotta
setblock 377 95 283 minecraft:stripped_oak_log
fill 377 95 284 377 96 284 minecraft:red_terracotta
setblock 377 95 288 minecraft:stripped_oak_log
fill 377 95 289 377 97 289 minecraft:red_terracotta
setblock 377 95 293 minecraft:stripped_oak_log
setblock 377 95 294 minecraft:red_terracotta
fill 377 95 295 381 95 303 minecraft:brown_terracotta
setblock 377 95 308 minecraft:stripped_oak_log
fill 377 95 309 377 97 309 minecraft:red_terracotta
setblock 377 95 313 minecraft:stripped_oak_log
fill 377 95 314 377 98 314 minecraft:red_terracotta
setblock 378 95 287 minecraft:stripped_oak_log
setblock 378 95 288 minecraft:red_terracotta
setblock 378 95 312 minecraft:stripped_oak_log
fill 378 95 313 378 97 313 minecraft:red_terracotta
setblock 379 95 276 minecraft:stripped_oak_log
setblock 379 95 278 minecraft:light[level=15]
setblock 379 95 285 minecraft:light[level=12]
setblock 379 95 286 minecraft:light[level=15]
setblock 379 95 292 minecraft:light[level=12]
setblock 379 95 294 minecraft:light[level=15]
setblock 379 95 306 minecraft:light[level=12]
setblock 379 95 310 minecraft:light[level=15]
setblock 379 95 313 minecraft:light[level=12]
setblock 379 95 316 minecraft:stripped_oak_log
setblock 380 95 276 minecraft:red_terracotta
setblock 380 95 315 minecraft:stripped_oak_log
fill 380 95 316 383 95 316 minecraft:red_terracotta
fill 382 95 315 384 95 315 minecraft:red_terracotta
setblock 384 95 316 minecraft:stripped_oak_log
setblock 385 95 315 minecraft:stripped_oak_log
fill 385 95 316 385 98 316 minecraft:red_terracotta
setblock 386 95 278 minecraft:light[level=12]
setblock 386 95 285 minecraft:light[level=12]
setblock 386 95 292 minecraft:light[level=12]
setblock 386 95 299 minecraft:light[level=12]
setblock 386 95 306 minecraft:light[level=12]
setblock 386 95 313 minecraft:light[level=12]
setblock 386 95 314 minecraft:stripped_oak_log
fill 386 95 315 386 98 315 minecraft:red_terracotta
setblock 387 95 278 minecraft:light[level=15]
setblock 387 95 286 minecraft:light[level=15]
setblock 387 95 294 minecraft:light[level=15]
setblock 387 95 302 minecraft:light[level=15]
setblock 387 95 310 minecraft:light[level=15]
fill 387 95 314 390 95 314 minecraft:red_terracotta
fill 388 95 313 391 95 313 minecraft:red_terracotta
setblock 389 95 276 minecraft:stripped_oak_log
setblock 389 95 316 minecraft:stripped_oak_log
fill 390 95 276 390 98 276 minecraft:red_terracotta
setblock 390 95 315 minecraft:stripped_oak_log
fill 390 95 316 390 98 316 minecraft:red_terracotta
setblock 391 95 314 minecraft:stripped_oak_log
fill 391 95 315 391 98 315 minecraft:red_terracotta
setblock 392 95 313 minecraft:stripped_oak_log
fill 392 95 314 392 98 314 minecraft:red_terracotta
setblock 393 95 278 minecraft:light[level=12]
setblock 393 95 285 minecraft:light[level=12]
setblock 393 95 292 minecraft:light[level=12]
setblock 393 95 299 minecraft:light[level=12]
setblock 393 95 306 minecraft:light[level=12]
fill 393 95 313 393 97 313 minecraft:red_terracotta
setblock 394 95 276 minecraft:stripped_oak_log
setblock 394 95 316 minecraft:stripped_oak_log
setblock 395 95 278 minecraft:light[level=15]
setblock 395 95 286 minecraft:light[level=15]
setblock 395 95 302 minecraft:light[level=15]
setblock 395 95 310 minecraft:light[level=15]
setblock 395 95 315 minecraft:stripped_oak_log
fill 395 95 316 395 98 316 minecraft:red_terracotta
setblock 396 95 314 minecraft:stripped_oak_log
fill 396 95 315 396 97 315 minecraft:red_terracotta
fill 399 95 283 399 98 283 minecraft:stripped_oak_log
setblock 399 95 316 minecraft:stripped_oak_log
setblock 400 95 278 minecraft:light[level=12]
setblock 400 95 285 minecraft:light[level=12]
setblock 400 95 292 minecraft:light[level=12]
setblock 400 95 299 minecraft:light[level=12]
setblock 400 95 306 minecraft:light[level=12]
setblock 400 95 313 minecraft:light[level=12]
fill 401 95 281 401 97 281 minecraft:stripped_oak_log
fill 402 95 284 402 97 284 minecraft:stripped_oak_log
setblock 403 95 278 minecraft:light[level=15]
setblock 403 95 286 minecraft:light[level=15]
setblock 403 95 294 minecraft:light[level=15]
setblock 403 95 302 minecraft:light[level=15]
setblock 403 95 310 minecraft:light[level=15]
setblock 407 95 278 minecraft:light[level=12]
setblock 407 95 285 minecraft:light[level=12]
setblock 407 95 292 minecraft:light[level=12]
setblock 407 95 299 minecraft:light[level=12]
setblock 407 95 306 minecraft:light[level=12]
setblock 407 95 313 minecraft:light[level=12]
setblock 408 95 316 minecraft:red_terracotta
setblock 409 95 276 minecraft:stripped_oak_log
setblock 409 95 316 minecraft:stripped_oak_log
fill 410 95 276 410 98 276 minecraft:red_terracotta
setblock 410 95 315 minecraft:stripped_oak_log
fill 410 95 316 410 98 316 minecraft:red_terracotta
setblock 411 95 278 minecraft:light[level=15]
setblock 411 95 286 minecraft:light[level=15]
setblock 411 95 294 minecraft:light[level=15]
setblock 411 95 302 minecraft:light[level=15]
setblock 411 95 310 minecraft:light[level=15]
fill 411 95 315 411 98 315 minecraft:red_terracotta
fill 413 95 315 414 95 315 minecraft:red_terracotta
setblock 414 95 276 minecraft:stripped_oak_log
setblock 414 95 278 minecraft:light[level=12]
setblock 414 95 286 minecraft:stripped_oak_log
fill 414 95 287 414 96 287 minecraft:red_terracotta
setblock 414 95 291 minecraft:stripped_oak_log
fill 414 95 292 414 96 292 minecraft:red_terracotta
setblock 414 95 299 minecraft:light[level=12]
setblock 414 95 306 minecraft:light[level=12]
setblock 414 95 313 minecraft:light[level=12]
setblock 414 95 316 minecraft:stripped_oak_log
fill 415 95 276 415 98 276 minecraft:red_terracotta
setblock 415 95 285 minecraft:stripped_oak_log
fill 415 95 286 415 97 286 minecraft:red_terracotta
setblock 415 95 290 minecraft:stripped_oak_log
fill 415 95 291 415 98 291 minecraft:red_terracotta
fill 415 95 306 415 101 306 minecraft:green_concrete
fill 415 95 316 415 98 316 minecraft:red_terracotta
setblock 416 95 280 minecraft:red_terracotta
setblock 416 95 284 minecraft:stripped_oak_log
fill 416 95 285 416 97 285 minecraft:red_terracotta
setblock 416 95 289 minecraft:stripped_oak_log
fill 416 95 290 416 98 290 minecraft:red_terracotta
setblock 416 95 294 minecraft:stripped_oak_log
fill 416 95 295 416 96 295 minecraft:red_terracotta
setblock 416 95 309 minecraft:stripped_oak_log
setblock 416 95 310 minecraft:red_terracotta
setblock 417 95 278 minecraft:stripped_oak_log
fill 417 95 279 417 96 279 minecraft:red_terracotta
setblock 417 95 283 minecraft:stripped_oak_log
fill 417 95 284 417 98 284 minecraft:red_terracotta
setblock 417 95 288 minecraft:stripped_oak_log
fill 417 95 289 417 98 289 minecraft:red_terracotta
setblock 417 95 293 minecraft:stripped_oak_log
fill 417 95 294 417 98 294 minecraft:red_terracotta
setblock 417 95 308 minecraft:stripped_oak_log
fill 417 95 309 417 96 309 minecraft:red_terracotta
setblock 417 95 313 minecraft:stripped_oak_log
fill 417 95 314 417 98 314 minecraft:red_terracotta
fill 376 96 275 376 96 317 minecraft:white_terracotta
fill 377 96 275 418 99 275 minecraft:white_terracotta
setblock 377 96 277 minecraft:stripped_oak_log
setblock 377 96 278 minecraft:red_terracotta
setblock 377 96 282 minecraft:stripped_oak_log
setblock 377 96 283 minecraft:red_terracotta
setblock 377 96 287 minecraft:stripped_oak_log
fill 377 96 288 377 97 288 minecraft:red_terracotta
setblock 377 96 292 minecraft:stripped_oak_log
setblock 377 96 293 minecraft:red_terracotta
fill 377 96 295 381 96 303 minecraft:stripped_oak_log
setblock 377 96 308 minecraft:red_terracotta
setblock 377 96 312 minecraft:stripped_oak_log
fill 377 96 313 377 99 313 minecraft:red_terracotta
fill 377 96 317 418 99 317 minecraft:white_terracotta
setblock 378 96 276 minecraft:stripped_oak_log
setblock 378 96 311 minecraft:stripped_oak_log
setblock 378 96 312 minecraft:red_terracotta
setblock 378 96 316 minecraft:stripped_oak_log
setblock 379 96 276 minecraft:red_terracotta
setblock 379 96 315 minecraft:stripped_oak_log
fill 379 96 316 382 96 316 minecraft:red_terracotta
fill 381 96 315 383 96 315 minecraft:red_terracotta
setblock 383 96 316 minecraft:stripped_oak_log
setblock 384 96 315 minecraft:stripped_oak_log
fill 384 96 316 384 99 316 minecraft:red_terracotta
setblock 385 96 314 minecraft:stripped_oak_log
fill 385 96 315 385 99 315 minecraft:red_terracotta
fill 386 96 314 389 96 314 minecraft:red_terracotta
setblock 388 96 276 minecraft:stripped_oak_log
fill 388 96 313 390 96 313 minecraft:red_terracotta
setblock 388 96 316 minecraft:stripped_oak_log
fill 389 96 276 389 99 276 minecraft:red_terracotta
setblock 389 96 315 minecraft:stripped_oak_log
fill 389 96 316 389 99 316 minecraft:red_terracotta
setblock 390 96 314 minecraft:stripped_oak_log
fill 390 96 315 390 99 315 minecraft:red_terracotta
setblock 391 96 313 minecraft:stripped_oak_log
fill 391 96 314 391 99 314 minecraft:red_terracotta
fill 392 96 313 392 97 313 minecraft:red_terracotta
setblock 393 96 276 minecraft:stripped_oak_log
setblock 393 96 316 minecraft:stripped_oak_log
setblock 394 96 315 minecraft:stripped_oak_log
fill 394 96 316 394 99 316 minecraft:red_terracotta
setblock 395 96 314 minecraft:stripped_oak_log
fill 395 96 315 395 99 315 minecraft:red_terracotta
setblock 398 96 316 minecraft:stripped_oak_log
setblock 407 96 316 minecraft:red_terracotta
setblock 408 96 316 minecraft:stripped_oak_log
fill 409 96 276 409 99 276 minecraft:red_terracotta
fill 409 96 316 409 99 316 minecraft:red_terracotta
fill 410 96 315 410 99 315 minecraft:red_terracotta
setblock 413 96 276 minecraft:stripped_oak_log
setblock 413 96 315 minecraft:red_terracotta
setblock 413 96 316 minecraft:stripped_oak_log
fill 414 96 276 414 99 276 minecraft:red_terracotta
setblock 414 96 290 minecraft:stripped_oak_log
setblock 414 96 291 minecraft:red_terracotta
setblock 414 96 315 minecraft:stripped_oak_log
fill 414 96 316 414 99 316 minecraft:red_terracotta
setblock 415 96 285 minecraft:red_terracotta
setblock 415 96 289 minecraft:stripped_oak_log
fill 415 96 290 415 98 290 minecraft:red_terracotta
setblock 415 96 294 minecraft:stripped_oak_log
setblock 416 96 283 minecraft:stripped_oak_log
fill 416 96 284 416 97 284 minecraft:red_terracotta
setblock 416 96 288 minecraft:stripped_oak_log
fill 416 96 289 416 99 289 minecraft:red_terracotta
setblock 416 96 293 minecraft:stripped_oak_log
fill 416 96 294 416 97 294 minecraft:red_terracotta
setblock 417 96 277 minecraft:stripped_oak_log
setblock 417 96 278 minecraft:red_terracotta
setblock 417 96 282 minecraft:stripped_oak_log
fill 417 96 283 417 97 283 minecraft:red_terracotta
setblock 417 96 287 minecraft:stripped_oak_log
fill 417 96 288 417 99 288 minecraft:red_terracotta
setblock 417 96 292 minecraft:stripped_oak_log
fill 417 96 293 417 99 293 minecraft:red_terracotta
setblock 417 96 312 minecraft:stripped_oak_log
fill 417 96 313 417 98 313 minecraft:red_terracotta
fill 418 96 276 418 99 316 minecraft:white_terracotta
fill 376 97 275 376 99 297 minecraft:white_terracotta
fill 376 97 298 376 100 300 minecraft:shroomlight
fill 376 97 301 376 99 317 minecraft:white_terracotta
setblock 377 97 276 minecraft:stripped_oak_log
setblock 377 97 277 minecraft:red_terracotta
setblock 377 97 286 minecraft:stripped_oak_log
setblock 377 97 287 minecraft:red_terracotta
setblock 377 97 291 minecraft:stripped_oak_log
setblock 377 97 292 minecraft:red_terracotta
setblock 377 97 311 minecraft:stripped_oak_log
fill 377 97 312 377 100 312 minecraft:red_terracotta
setblock 377 97 316 minecraft:stripped_oak_log
fill 378 97 276 378 100 276 minecraft:red_terracotta
setblock 378 97 315 minecraft:stripped_oak_log
fill 378 97 316 381 97 316 minecraft:red_terracotta
fill 381 97 295 381 97 303 minecraft:orange_terracotta
fill 381 97 315 382 97 315 minecraft:red_terracotta
setblock 382 97 316 minecraft:stripped_oak_log
setblock 383 97 315 minecraft:stripped_oak_log
fill 383 97 316 383 100 316 minecraft:red_terracotta
fill 384 97 315 384 100 315 minecraft:red_terracotta
fill 385 97 276 385 98 276 minecraft:red_terracotta
fill 385 97 314 388 97 314 minecraft:red_terracotta
setblock 387 97 276 minecraft:stripped_oak_log
setblock 387 97 316 minecraft:stripped_oak_log
fill 388 97 276 388 100 276 minecraft:red_terracotta
fill 388 97 313 389 97 313 minecraft:red_terracotta
setblock 388 97 315 minecraft:stripped_oak_log
fill 388 97 316 388 100 316 minecraft:red_terracotta
setblock 389 97 314 minecraft:stripped_oak_log
fill 389 97 315 389 100 315 minecraft:red_terracotta
setblock 390 97 313 minecraft:stripped_oak_log
fill 390 97 314 390 100 314 minecraft:red_terracotta
fill 391 97 313 391 98 313 minecraft:red_terracotta
setblock 392 97 276 minecraft:stripped_oak_log
setblock 392 97 316 minecraft:stripped_oak_log
setblock 393 97 276 minecraft:red_terracotta
setblock 393 97 315 minecraft:stripped_oak_log
fill 393 97 316 393 100 316 minecraft:red_terracotta
setblock 394 97 314 minecraft:stripped_oak_log
fill 394 97 315 394 100 315 minecraft:red_terracotta
setblock 395 97 314 minecraft:red_terracotta
setblock 397 97 316 minecraft:stripped_oak_log
setblock 407 97 316 minecraft:stripped_oak_log
fill 408 97 276 408 100 276 minecraft:red_terracotta
fill 408 97 316 408 100 316 minecraft:red_terracotta
setblock 412 97 276 minecraft:stripped_oak_log
setblock 412 97 316 minecraft:stripped_oak_log
fill 413 97 276 413 100 276 minecraft:red_terracotta
setblock 413 97 315 minecraft:stripped_oak_log
fill 413 97 316 413 100 316 minecraft:red_terracotta
setblock 414 97 290 minecraft:red_terracotta
setblock 415 97 288 minecraft:stripped_oak_log
fill 415 97 289 415 98 289 minecraft:red_terracotta
setblock 415 97 293 minecraft:stripped_oak_log
setblock 416 97 287 minecraft:stripped_oak_log
fill 416 97 288 416 98 288 minecraft:red_terracotta
setblock 416 97 292 minecraft:stripped_oak_log
fill 416 97 293 416 99 293 minecraft:red_terracotta
setblock 417 97 276 minecraft:stripped_oak_log
setblock 417 97 277 minecraft:red_terracotta
setblock 417 97 281 minecraft:stripped_oak_log
setblock 417 97 282 minecraft:red_terracotta
setblock 417 97 286 minecraft:stripped_oak_log
fill 417 97 287 417 99 287 minecraft:red_terracotta
setblock 417 97 291 minecraft:stripped_oak_log
fill 417 97 292 417 100 292 minecraft:red_terracotta
setblock 417 97 311 minecraft:stripped_oak_log
setblock 417 97 312 minecraft:red_terracotta
setblock 417 97 316 minecraft:stripped_oak_log
fill 377 98 276 377 101 276 minecraft:red_terracotta
setblock 377 98 310 minecraft:stripped_oak_log
fill 377 98 311 377 100 311 minecraft:red_terracotta
setblock 377 98 315 minecraft:stripped_oak_log
fill 377 98 316 380 98 316 minecraft:red_terracotta
setblock 381 98 295 minecraft:stripped_oak_log
setblock 381 98 299 minecraft:stripped_oak_log
setblock 381 98 303 minecraft:stripped_oak_log
setblock 381 98 315 minecraft:red_terracotta
setblock 381 98 316 minecraft:stripped_oak_log
setblock 382 98 315 minecraft:stripped_oak_log
fill 382 98 316 382 101 316 minecraft:red_terracotta
fill 383 98 315 383 101 315 minecraft:red_terracotta
fill 385 98 314 387 98 314 minecraft:red_terracotta
setblock 386 98 276 minecraft:stripped_oak_log
setblock 386 98 316 minecraft:stripped_oak_log
fill 387 98 276 387 101 276 minecraft:red_terracotta
setblock 387 98 315 minecraft:stripped_oak_log
fill 387 98 316 387 101 316 minecraft:red_terracotta
setblock 388 98 313 minecraft:red_terracotta
setblock 388 98 314 minecraft:stripped_oak_log
fill 388 98 315 388 101 315 minecraft:red_terracotta
setblock 389 98 313 minecraft:stripped_oak_log
fill 389 98 314 389 101 314 minecraft:red_terracotta
fill 390 98 313 390 99 313 minecraft:red_terracotta
setblock 391 98 276 minecraft:stripped_oak_log
setblock 391 98 316 minecraft:stripped_oak_log
fill 392 98 276 392 101 276 minecraft:red_terracotta
setblock 392 98 315 minecraft:stripped_oak_log
fill 392 98 316 392 101 316 minecraft:red_terracotta
setblock 393 98 314 minecraft:stripped_oak_log
fill 393 98 315 393 101 315 minecraft:red_terracotta
setblock 394 98 314 minecraft:red_terracotta
setblock 396 98 316 minecraft:stripped_oak_log
setblock 397 98 316 minecraft:red_terracotta
setblock 406 98 316 minecraft:stripped_oak_log
fill 407 98 316 407 101 316 minecraft:red_terracotta
fill 409 98 315 409 100 315 minecraft:red_terracotta
setblock 411 98 276 minecraft:stripped_oak_log
setblock 411 98 316 minecraft:stripped_oak_log
fill 412 98 276 412 101 276 minecraft:red_terracotta
setblock 412 98 315 minecraft:stripped_oak_log
fill 412 98 316 412 101 316 minecraft:red_terracotta
fill 415 98 307 415 100 307 minecraft:green_concrete
setblock 416 98 276 minecraft:stripped_oak_log
setblock 416 98 286 minecraft:stripped_oak_log
setblock 416 98 287 minecraft:red_terracotta
setblock 416 98 291 minecraft:stripped_oak_log
fill 416 98 292 416 99 292 minecraft:red_terracotta
setblock 416 98 316 minecraft:stripped_oak_log
fill 417 98 276 417 101 276 minecraft:red_terracotta
setblock 417 98 285 minecraft:stripped_oak_log
fill 417 98 286 417 99 286 minecraft:red_terracotta
setblock 417 98 290 minecraft:stripped_oak_log
fill 417 98 291 417 101 291 minecraft:red_terracotta
setblock 417 98 295 minecraft:stripped_oak_log
setblock 417 98 315 minecraft:stripped_oak_log
fill 417 98 316 417 101 316 minecraft:red_terracotta
setblock 377 99 314 minecraft:stripped_oak_log
fill 377 99 315 377 101 316 minecraft:red_terracotta
fill 378 99 316 379 99 316 minecraft:red_terracotta
setblock 380 99 315 minecraft:red_terracotta
setblock 380 99 316 minecraft:stripped_oak_log
setblock 381 99 315 minecraft:stripped_oak_log
fill 381 99 316 381 102 316 minecraft:red_terracotta
fill 382 99 315 382 102 315 minecraft:red_terracotta
setblock 384 99 276 minecraft:red_terracotta
fill 384 99 314 386 99 314 minecraft:red_terracotta
setblock 385 99 276 minecraft:stripped_oak_log
setblock 385 99 316 minecraft:stripped_oak_log
fill 386 99 276 386 102 276 minecraft:red_terracotta
setblock 386 99 315 minecraft:stripped_oak_log
fill 386 99 316 386 102 316 minecraft:red_terracotta
setblock 387 99 314 minecraft:stripped_oak_log
fill 387 99 315 387 102 315 minecraft:red_terracotta
setblock 388 99 313 minecraft:stripped_oak_log
fill 388 99 314 388 102 314 minecraft:red_terracotta
fill 389 99 313 389 101 313 minecraft:red_terracotta
setblock 390 99 276 minecraft:stripped_oak_log
setblock 390 99 316 minecraft:stripped_oak_log
fill 391 99 276 391 102 276 minecraft:red_terracotta
setblock 391 99 315 minecraft:stripped_oak_log
fill 391 99 316 391 102 316 minecraft:red_terracotta
setblock 392 99 314 minecraft:stripped_oak_log
fill 392 99 315 392 102 315 minecraft:red_terracotta
setblock 393 99 314 minecraft:red_terracotta
setblock 395 99 316 minecraft:stripped_oak_log
fill 396 99 316 396 102 316 minecraft:red_terracotta
fill 406 99 316 406 102 316 minecraft:red_terracotta
fill 407 99 276 407 101 276 minecraft:red_terracotta
setblock 410 99 276 minecraft:stripped_oak_log
setblock 410 99 316 minecraft:stripped_oak_log
fill 411 99 276 411 102 276 minecraft:red_terracotta
setblock 411 99 315 minecraft:stripped_oak_log
fill 411 99 316 411 102 316 minecraft:red_terracotta
fill 412 99 315 412 102 315 minecraft:red_terracotta
setblock 415 99 276 minecraft:stripped_oak_log
setblock 415 99 316 minecraft:stripped_oak_log
fill 416 99 276 416 102 276 minecraft:red_terracotta
setblock 416 99 290 minecraft:stripped_oak_log
setblock 416 99 291 minecraft:red_terracotta
fill 416 99 316 416 102 316 minecraft:red_terracotta
setblock 417 99 289 minecraft:stripped_oak_log
fill 417 99 290 417 101 290 minecraft:red_terracotta
setblock 417 99 294 minecraft:stripped_oak_log
fill 417 99 315 417 102 315 minecraft:red_terracotta
fill 376 100 275 376 103 297 minecraft:terracotta
fill 376 100 301 376 103 317 minecraft:terracotta
fill 377 100 275 418 103 275 minecraft:terracotta
setblock 377 100 313 minecraft:stripped_oak_log
fill 377 100 314 377 103 314 minecraft:red_terracotta
fill 377 100 317 418 103 317 minecraft:terracotta
setblock 378 100 316 minecraft:red_terracotta
setblock 379 100 315 minecraft:red_terracotta
setblock 379 100 316 minecraft:stripped_oak_log
setblock 380 100 315 minecraft:stripped_oak_log
fill 380 100 316 380 103 316 minecraft:red_terracotta
fill 381 100 276 383 100 276 minecraft:red_terracotta
fill 381 100 315 381 103 315 minecraft:red_terracotta
setblock 384 100 276 minecraft:stripped_oak_log
fill 384 100 314 385 100 314 minecraft:red_terracotta
setblock 384 100 316 minecraft:stripped_oak_log
fill 385 100 276 385 103 276 minecraft:red_terracotta
setblock 385 100 315 minecraft:stripped_oak_log
fill 385 100 316 385 103 316 minecraft:red_terracotta
setblock 386 100 314 minecraft:stripped_oak_log
fill 386 100 315 386 103 315 minecraft:red_terracotta
fill 387 100 314 387 103 314 minecraft:red_terracotta
fill 388 100 313 388 103 313 minecraft:red_terracotta
setblock 389 100 276 minecraft:stripped_oak_log
setblock 389 100 316 minecraft:stripped_oak_log
fill 390 100 276 390 103 276 minecraft:red_terracotta
setblock 390 100 315 minecraft:stripped_oak_log
fill 390 100 316 390 103 316 minecraft:red_terracotta
setblock 391 100 314 minecraft:stripped_oak_log
fill 391 100 315 391 103 315 minecraft:red_terracotta
fill 392 100 314 392 101 314 minecraft:red_terracotta
setblock 394 100 316 minecraft:stripped_oak_log
fill 395 100 316 395 103 316 minecraft:red_terracotta
fill 405 100 316 405 103 316 minecraft:red_terracotta
fill 406 100 276 406 102 276 minecraft:red_terracotta
fill 408 100 315 408 101 315 minecraft:red_terracotta
setblock 409 100 276 minecraft:stripped_oak_log
fill 409 100 277 412 100 277 minecraft:red_terracotta
setblock 409 100 316 minecraft:stripped_oak_log
fill 410 100 276 410 103 276 minecraft:red_terracotta
setblock 410 100 315 minecraft:stripped_oak_log
fill 410 100 316 410 103 316 minecraft:red_terracotta
fill 411 100 315 411 103 315 minecraft:red_terracotta
setblock 414 100 276 minecraft:stripped_oak_log
setblock 414 100 316 minecraft:stripped_oak_log
fill 415 100 276 415 103 276 minecraft:red_terracotta
fill 415 100 316 415 103 316 minecraft:red_terracotta
setblock 417 100 277 minecraft:red_terracotta
setblock 417 100 288 minecraft:stripped_oak_log
setblock 417 100 289 minecraft:red_terracotta
setblock 417 100 293 minecraft:stripped_oak_log
fill 417 100 294 417 103 294 minecraft:red_terracotta
fill 418 100 276 418 103 316 minecraft:terracotta
fill 376 101 298 376 103 300 minecraft:terracotta
setblock 377 101 277 minecraft:stripped_oak_log
setblock 377 101 312 minecraft:stripped_oak_log
fill 377 101 313 377 104 313 minecraft:red_terracotta
setblock 378 101 276 minecraft:stripped_oak_log
setblock 378 101 315 minecraft:red_terracotta
setblock 378 101 316 minecraft:stripped_oak_log
fill 379 101 276 382 101 276 minecraft:red_terracotta
setblock 379 101 278 minecraft:light[level=12]
setblock 379 101 285 minecraft:light[level=12]
setblock 379 101 292 minecraft:light[level=12]
setblock 379 101 299 minecraft:light[level=12]
setblock 379 101 306 minecraft:light[level=12]
setblock 379 101 313 minecraft:light[level=12]
setblock 379 101 315 minecraft:stripped_oak_log
fill 379 101 316 379 104 316 minecraft:red_terracotta
fill 380 101 315 380 104 315 minecraft:red_terracotta
setblock 383 101 276 minecraft:stripped_oak_log
fill 383 101 314 384 101 314 minecraft:red_terracotta
setblock 383 101 316 minecraft:stripped_oak_log
fill 384 101 276 384 104 276 minecraft:red_terracotta
setblock 384 101 315 minecraft:stripped_oak_log
fill 384 101 316 384 104 316 minecraft:red_terracotta
setblock 385 101 314 minecraft:stripped_oak_log
fill 385 101 315 385 104 315 minecraft:red_terracotta
setblock 386 101 278 minecraft:light[level=12]
setblock 386 101 285 minecraft:light[level=12]
setblock 386 101 292 minecraft:light[level=12]
setblock 386 101 299 minecraft:light[level=12]
setblock 386 101 306 minecraft:light[level=12]
setblock 386 101 313 minecraft:light[level=12]
fill 386 101 314 386 104 314 minecraft:red_terracotta
fill 387 101 313 387 104 313 minecraft:red_terracotta
setblock 388 101 276 minecraft:stripped_oak_log
setblock 388 101 316 minecraft:stripped_oak_log
fill 389 101 276 389 104 276 minecraft:red_terracotta
setblock 389 101 315 minecraft:stripped_oak_log
fill 389 101 316 389 104 316 minecraft:red_terracotta
setblock 390 101 314 minecraft:stripped_oak_log
fill 390 101 315 390 104 315 minecraft:red_terracotta
fill 391 101 314 391 103 314 minecraft:red_terracotta
setblock 393 101 278 minecraft:light[level=12]
setblock 393 101 285 minecraft:light[level=12]
setblock 393 101 292 minecraft:light[level=12]
setblock 393 101 299 minecraft:light[level=12]
setblock 393 101 306 minecraft:light[level=12]
setblock 393 101 313 minecraft:light[level=12]
setblock 393 101 316 minecraft:stripped_oak_log
setblock 394 101 315 minecraft:stripped_oak_log
fill 394 101 316 394 104 316 minecraft:red_terracotta
setblock 400 101 278 minecraft:light[level=12]
setblock 400 101 285 minecraft:light[level=12]
setblock 400 101 292 minecraft:light[level=12]
setblock 400 101 299 minecraft:light[level=12]
setblock 400 101 306 minecraft:light[level=12]
setblock 400 101 313 minecraft:light[level=12]
fill 404 101 276 405 103 276 minecraft:red_terracotta
fill 404 101 316 404 104 316 minecraft:red_terracotta
setblock 407 101 277 minecraft:stripped_oak_log
setblock 407 101 278 minecraft:light[level=12]
setblock 407 101 285 minecraft:light[level=12]
setblock 407 101 292 minecraft:light[level=12]
setblock 407 101 299 minecraft:light[level=12]
setblock 407 101 306 minecraft:light[level=12]
setblock 407 101 313 minecraft:light[level=12]
fill 407 101 315 407 102 315 minecraft:red_terracotta
setblock 408 101 276 minecraft:stripped_oak_log
fill 408 101 277 411 101 277 minecraft:red_terracotta
setblock 408 101 316 minecraft:stripped_oak_log
fill 409 101 276 409 104 276 minecraft:red_terracotta
setblock 409 101 315 minecraft:stripped_oak_log
fill 409 101 316 409 104 316 minecraft:red_terracotta
fill 410 101 315 410 104 315 minecraft:red_terracotta
setblock 412 101 277 minecraft:stripped_oak_log
setblock 413 101 276 minecraft:stripped_oak_log
fill 413 101 277 413 104 277 minecraft:red_terracotta
setblock 413 101 316 minecraft:stripped_oak_log
fill 414 101 276 414 104 276 minecraft:red_terracotta
setblock 414 101 278 minecraft:light[level=12]
setblock 414 101 285 minecraft:light[level=12]
setblock 414 101 292 minecraft:light[level=12]
fill 414 101 299 416 102 299 minecraft:iron_bars
setblock 414 101 306 minecraft:light[level=12]
setblock 414 101 313 minecraft:light[level=12]
fill 414 101 316 414 104 316 minecraft:red_terracotta
setblock 417 101 277 minecraft:stripped_oak_log
fill 417 101 278 417 104 278 minecraft:red_terracotta
setblock 417 101 292 minecraft:stripped_oak_log
fill 417 101 293 417 104 293 minecraft:red_terracotta
setblock 377 102 276 minecraft:stripped_oak_log
fill 377 102 277 377 105 277 minecraft:red_terracotta
fill 377 102 312 377 105 312 minecraft:red_terracotta
setblock 377 102 315 minecraft:red_terracotta
setblock 377 102 316 minecraft:stripped_oak_log
fill 378 102 276 381 102 276 minecraft:red_terracotta
setblock 378 102 314 minecraft:red_terracotta
setblock 378 102 315 minecraft:stripped_oak_log
fill 378 102 316 378 105 316 minecraft:red_terracotta
fill 379 102 291 379 103 291 minecraft:brown_terracotta
fill 379 102 294 379 103 294 minecraft:brown_terracotta
fill 379 102 315 379 105 315 minecraft:red_terracotta
setblock 382 102 276 minecraft:stripped_oak_log
fill 382 102 301 382 105 301 minecraft:iron_bars
fill 382 102 314 383 102 314 minecraft:red_terracotta
setblock 382 102 316 minecraft:stripped_oak_log
fill 383 102 276 383 105 276 minecraft:red_terracotta
setblock 383 102 315 minecraft:stripped_oak_log
fill 383 102 316 383 105 316 minecraft:red_terracotta
setblock 384 102 314 minecraft:stripped_oak_log
fill 384 102 315 384 105 315 minecraft:red_terracotta
setblock 385 102 277 minecraft:red_terracotta
fill 385 102 314 385 105 314 minecraft:red_terracotta
setblock 386 102 277 minecraft:stripped_oak_log
setblock 387 102 276 minecraft:stripped_oak_log
fill 387 102 277 388 104 277 minecraft:red_terracotta
setblock 387 102 316 minecraft:stripped_oak_log
fill 388 102 276 388 105 276 minecraft:red_terracotta
setblock 388 102 315 minecraft:stripped_oak_log
fill 388 102 316 388 105 316 minecraft:red_terracotta
setblock 389 102 314 minecraft:stripped_oak_log
fill 389 102 315 389 105 315 minecraft:red_terracotta
fill 390 102 314 390 105 314 minecraft:red_terracotta
setblock 392 102 276 minecraft:stripped_oak_log
setblock 392 102 316 minecraft:stripped_oak_log
setblock 393 102 315 minecraft:stripped_oak_log
fill 393 102 316 393 105 316 minecraft:red_terracotta
fill 398 102 311 398 107 311 minecraft:stripped_oak_log
setblock 402 102 316 minecraft:stripped_oak_log
fill 403 102 276 403 105 276 minecraft:red_terracotta
fill 403 102 316 403 105 316 minecraft:red_terracotta
setblock 406 102 277 minecraft:stripped_oak_log
fill 406 102 315 406 103 315 minecraft:red_terracotta
setblock 407 102 276 minecraft:stripped_oak_log
fill 407 102 277 410 102 277 minecraft:red_terracotta
setblock 407 102 316 minecraft:stripped_oak_log
fill 408 102 276 408 105 276 minecraft:red_terracotta
setblock 408 102 315 minecraft:stripped_oak_log
fill 408 102 316 408 105 316 minecraft:red_terracotta
fill 409 102 315 409 105 315 minecraft:red_terracotta
fill 410 102 313 410 103 313 minecraft:brown_terracotta
setblock 411 102 277 minecraft:stripped_oak_log
setblock 412 102 276 minecraft:stripped_oak_log
fill 412 102 277 412 105 277 minecraft:red_terracotta
setblock 412 102 316 minecraft:stripped_oak_log
fill 413 102 276 413 105 276 minecraft:red_terracotta
fill 413 102 316 413 105 316 minecraft:red_terracotta
fill 414 102 277 415 102 277 minecraft:red_terracotta
setblock 417 102 276 minecraft:stripped_oak_log
fill 417 102 277 417 105 277 minecraft:red_terracotta
fill 417 102 279 417 103 279 minecraft:red_terracotta
setblock 417 102 291 minecraft:stripped_oak_log
fill 417 102 292 417 103 292 minecraft:red_terracotta
setblock 417 102 316 minecraft:stripped_oak_log
fill 377 103 276 380 103 276 minecraft:red_terracotta
fill 377 103 278 377 104 278 minecraft:red_terracotta
setblock 377 103 315 minecraft:stripped_oak_log
fill 377 103 316 377 106 316 minecraft:red_terracotta
fill 378 103 291 378 104 291 minecraft:brown_terracotta
fill 378 103 294 378 104 294 minecraft:brown_terracotta
setblock 378 103 314 minecraft:stripped_oak_log
fill 378 103 315 378 106 315 minecraft:red_terracotta
setblock 379 103 278 minecraft:light[level=15]
setblock 379 103 286 minecraft:light[level=15]
setblock 379 103 302 minecraft:light[level=15]
setblock 379 103 310 minecraft:light[level=15]
setblock 381 103 276 minecraft:stripped_oak_log
setblock 381 103 316 minecraft:stripped_oak_log
fill 382 103 276 382 105 277 minecraft:red_terracotta
setblock 382 103 314 minecraft:red_terracotta
setblock 382 103 315 minecraft:stripped_oak_log
fill 382 103 316 382 106 316 minecraft:red_terracotta
fill 383 103 277 384 103 277 minecraft:red_terracotta
setblock 383 103 314 minecraft:stripped_oak_log
fill 383 103 315 383 106 315 minecraft:red_terracotta
fill 384 103 314 384 106 314 minecraft:red_terracotta
setblock 385 103 277 minecraft:stripped_oak_log
setblock 386 103 276 minecraft:stripped_oak_log
fill 386 103 277 386 106 277 minecraft:red_terracotta
fill 386 103 313 386 105 313 minecraft:red_terracotta
setblock 386 103 316 minecraft:stripped_oak_log
fill 387 103 276 387 106 276 minecraft:red_terracotta
setblock 387 103 278 minecraft:light[level=15]
setblock 387 103 286 minecraft:light[level=15]
setblock 387 103 294 minecraft:light[level=15]
setblock 387 103 302 minecraft:light[level=15]
setblock 387 103 310 minecraft:light[level=15]
setblock 387 103 315 minecraft:stripped_oak_log
fill 387 103 316 387 106 316 minecraft:red_terracotta
setblock 388 103 314 minecraft:stripped_oak_log
fill 388 103 315 388 106 315 minecraft:red_terracotta
setblock 389 103 277 minecraft:red_terracotta
fill 389 103 314 389 106 314 minecraft:red_terracotta
setblock 391 103 276 minecraft:stripped_oak_log
setblock 391 103 316 minecraft:stripped_oak_log
fill 392 103 276 393 105 276 minecraft:red_terracotta
setblock 392 103 315 minecraft:stripped_oak_log
fill 392 103 316 392 106 316 minecraft:red_terracotta
fill 393 103 315 393 104 315 minecraft:red_terracotta
setblock 395 103 278 minecraft:light[level=15]
setblock 395 103 286 minecraft:light[level=15]
setblock 395 103 302 minecraft:light[level=15]
setblock 395 103 310 minecraft:light[level=15]
setblock 396 103 316 minecraft:stripped_oak_log
setblock 401 103 316 minecraft:stripped_oak_log
fill 402 103 276 402 106 276 minecraft:red_terracotta
fill 402 103 316 402 106 316 minecraft:red_terracotta
setblock 403 103 278 minecraft:light[level=15]
setblock 403 103 286 minecraft:light[level=15]
setblock 403 103 294 minecraft:light[level=15]
setblock 403 103 302 minecraft:light[level=15]
setblock 403 103 310 minecraft:light[level=15]
setblock 404 103 277 minecraft:red_terracotta
setblock 405 103 277 minecraft:stripped_oak_log
fill 405 103 315 405 104 315 minecraft:red_terracotta
setblock 406 103 276 minecraft:stripped_oak_log
fill 406 103 277 409 103 277 minecraft:red_terracotta
setblock 406 103 316 minecraft:stripped_oak_log
fill 407 103 276 407 106 276 minecraft:red_terracotta
fill 407 103 278 408 103 278 minecraft:red_terracotta
setblock 407 103 315 minecraft:stripped_oak_log
fill 407 103 316 407 106 316 minecraft:red_terracotta
fill 408 103 315 408 106 315 minecraft:red_terracotta
setblock 409 103 278 minecraft:stripped_oak_log
setblock 410 103 277 minecraft:stripped_oak_log
fill 410 103 278 411 105 278 minecraft:red_terracotta
fill 410 103 314 410 104 314 minecraft:brown_terracotta
setblock 411 103 276 minecraft:stripped_oak_log
fill 411 103 277 411 106 277 minecraft:red_terracotta
setblock 411 103 286 minecraft:light[level=15]
setblock 411 103 294 minecraft:light[level=15]
setblock 411 103 302 minecraft:light[level=15]
setblock 411 103 310 minecraft:light[level=15]
setblock 411 103 316 minecraft:stripped_oak_log
fill 412 103 276 412 106 276 minecraft:red_terracotta
setblock 412 103 315 minecraft:stripped_oak_log
fill 412 103 316 412 106 316 minecraft:red_terracotta
setblock 414 103 277 minecraft:red_terracotta
setblock 415 103 277 minecraft:stripped_oak_log
setblock 416 103 276 minecraft:stripped_oak_log
fill 416 103 277 416 106 277 minecraft:red_terracotta
setblock 416 103 316 minecraft:stripped_oak_log
fill 417 103 276 417 106 276 minecraft:red_terracotta
setblock 417 103 280 minecraft:stripped_oak_log
setblock 417 103 295 minecraft:stripped_oak_log
setblock 417 103 314 minecraft:red_terracotta
setblock 417 103 315 minecraft:stripped_oak_log
fill 417 103 316 417 106 316 minecraft:red_terracotta
fill 376 104 275 376 107 317 minecraft:brown_terracotta
fill 377 104 275 418 107 275 minecraft:brown_terracotta
fill 377 104 276 379 104 276 minecraft:red_terracotta
setblock 377 104 279 minecraft:stripped_oak_log
fill 377 104 291 377 105 291 minecraft:brown_terracotta
fill 377 104 294 377 105 294 minecraft:brown_terracotta
fill 377 104 311 377 106 311 minecraft:red_terracotta
setblock 377 104 314 minecraft:stripped_oak_log
fill 377 104 315 377 107 315 minecraft:red_terracotta
fill 377 104 317 418 107 317 minecraft:brown_terracotta
setblock 378 104 277 minecraft:red_terracotta
setblock 378 104 313 minecraft:stripped_oak_log
fill 378 104 314 378 107 314 minecraft:red_terracotta
setblock 379 104 277 minecraft:stripped_oak_log
setblock 380 104 276 minecraft:stripped_oak_log
fill 380 104 277 381 106 277 minecraft:red_terracotta
setblock 380 104 316 minecraft:stripped_oak_log
fill 381 104 276 381 107 276 minecraft:red_terracotta
setblock 381 104 314 minecraft:red_terracotta
setblock 381 104 315 minecraft:stripped_oak_log
fill 381 104 316 381 107 316 minecraft:red_terracotta
setblock 382 104 314 minecraft:stripped_oak_log
fill 382 104 315 382 107 315 minecraft:red_terracotta
setblock 383 104 277 minecraft:red_terracotta
fill 383 104 314 383 107 314 minecraft:red_terracotta
setblock 384 104 277 minecraft:stripped_oak_log
setblock 385 104 276 minecraft:stripped_oak_log
fill 385 104 277 385 107 277 minecraft:red_terracotta
fill 385 104 313 385 105 313 minecraft:red_terracotta
setblock 385 104 316 minecraft:stripped_oak_log
fill 386 104 276 386 107 276 minecraft:red_terracotta
setblock 386 104 315 minecraft:stripped_oak_log
fill 386 104 316 386 107 316 minecraft:red_terracotta
setblock 387 104 314 minecraft:stripped_oak_log
fill 387 104 315 387 107 315 minecraft:red_terracotta
fill 388 104 314 388 107 314 minecraft:red_terracotta
setblock 389 104 277 minecraft:stripped_oak_log
setblock 390 104 276 minecraft:stripped_oak_log
fill 390 104 277 390 107 277 minecraft:red_terracotta
setblock 390 104 316 minecraft:stripped_oak_log
fill 391 104 276 391 107 276 minecraft:red_terracotta
setblock 391 104 315 minecraft:stripped_oak_log
fill 391 104 316 391 107 316 minecraft:red_terracotta
fill 392 104 315 392 106 315 minecraft:red_terracotta
setblock 395 104 316 minecraft:stripped_oak_log
fill 396 104 316 396 105 316 minecraft:red_terracotta
setblock 400 104 276 minecraft:stripped_oak_log
setblock 400 104 316 minecraft:stripped_oak_log
fill 401 104 276 401 107 276 minecraft:red_terracotta
fill 401 104 316 401 107 316 minecraft:red_terracotta
setblock 403 104 277 minecraft:red_terracotta
setblock 404 104 276 minecraft:red_terracotta
setblock 404 104 277 minecraft:stripped_oak_log
fill 404 104 315 404 105 315 minecraft:red_terracotta
setblock 405 104 276 minecraft:stripped_oak_log
fill 405 104 277 407 104 278 minecraft:red_terracotta
setblock 405 104 316 minecraft:stripped_oak_log
fill 406 104 276 406 107 276 minecraft:red_terracotta
setblock 406 104 315 minecraft:stripped_oak_log
fill 406 104 316 406 107 316 minecraft:red_terracotta
fill 407 104 315 407 107 315 minecraft:red_terracotta
setblock 408 104 277 minecraft:red_terracotta
setblock 408 104 278 minecraft:stripped_oak_log
setblock 409 104 277 minecraft:stripped_oak_log
fill 409 104 278 409 107 278 minecraft:red_terracotta
setblock 410 104 276 minecraft:stripped_oak_log
fill 410 104 277 410 107 277 minecraft:red_terracotta
setblock 410 104 316 minecraft:stripped_oak_log
fill 411 104 276 411 107 276 minecraft:red_terracotta
setblock 411 104 315 minecraft:stripped_oak_log
fill 411 104 316 411 107 316 minecraft:red_terracotta
setblock 412 104 278 minecraft:red_terracotta
fill 412 104 315 412 105 315 minecraft:red_terracotta
setblock 414 104 277 minecraft:stripped_oak_log
setblock 415 104 276 minecraft:stripped_oak_log
fill 415 104 277 415 107 277 minecraft:red_terracotta
setblock 415 104 316 minecraft:stripped_oak_log
fill 416 104 276 416 107 276 minecraft:red_terracotta
fill 416 104 278 416 104 279 minecraft:red_terracotta
fill 416 104 316 416 107 316 minecraft:red_terracotta
setblock 417 104 279 minecraft:stripped_oak_log
fill 417 104 280 417 106 281 minecraft:red_terracotta
setblock 417 104 294 minecraft:stripped_oak_log
fill 417 104 295 417 106 296 minecraft:red_terracotta
setblock 417 104 314 minecraft:stripped_oak_log
fill 417 104 315 417 107 315 minecraft:red_terracotta
fill 418 104 276 418 107 316 minecraft:brown_terracotta
fill 377 105 276 378 105 276 minecraft:red_terracotta
setblock 377 105 278 minecraft:stripped_oak_log
fill 377 105 279 377 107 280 minecraft:red_terracotta
setblock 377 105 297 minecraft:red_terracotta
setblock 377 105 298 minecraft:stripped_oak_log
setblock 377 105 313 minecraft:stripped_oak_log
fill 377 105 314 377 108 314 minecraft:red_terracotta
setblock 378 105 277 minecraft:stripped_oak_log
fill 378 105 278 378 108 278 minecraft:red_terracotta
fill 378 105 313 378 108 313 minecraft:red_terracotta
setblock 379 105 276 minecraft:stripped_oak_log
fill 379 105 277 379 108 277 minecraft:red_terracotta
setblock 379 105 278 minecraft:shroomlight
setblock 379 105 284 minecraft:shroomlight
setblock 379 105 290 minecraft:shroomlight
setblock 379 105 296 minecraft:shroomlight
setblock 379 105 302 minecraft:shroomlight
setblock 379 105 308 minecraft:shroomlight
setblock 379 105 314 minecraft:shroomlight
setblock 379 105 316 minecraft:stripped_oak_log
fill 380 105 276 380 108 276 minecraft:red_terracotta
setblock 380 105 314 minecraft:red_terracotta
setblock 380 105 315 minecraft:stripped_oak_log
fill 380 105 316 380 108 316 minecraft:red_terracotta
setblock 381 105 314 minecraft:stripped_oak_log
fill 381 105 315 381 108 315 minecraft:red_terracotta
fill 382 105 314 382 108 314 minecraft:red_terracotta
setblock 383 105 277 minecraft:stripped_oak_log
setblock 384 105 276 minecraft:stripped_oak_log
fill 384 105 277 384 108 277 minecraft:red_terracotta
setblock 384 105 316 minecraft:stripped_oak_log
fill 385 105 276 385 108 276 minecraft:red_terracotta
fill 385 105 278 385 106 278 minecraft:red_terracotta
setblock 385 105 315 minecraft:stripped_oak_log
fill 385 105 316 385 108 316 minecraft:red_terracotta
setblock 386 105 314 minecraft:stripped_oak_log
fill 386 105 315 386 108 315 minecraft:red_terracotta
setblock 387 105 277 minecraft:red_terracotta
fill 387 105 314 387 108 314 minecraft:red_terracotta
setblock 388 105 277 minecraft:stripped_oak_log
setblock 389 105 276 minecraft:stripped_oak_log
fill 389 105 277 389 108 277 minecraft:red_terracotta
setblock 389 105 316 minecraft:stripped_oak_log
fill 390 105 276 390 108 276 minecraft:red_terracotta
setblock 390 105 315 minecraft:stripped_oak_log
fill 390 105 316 390 108 316 minecraft:red_terracotta
setblock 391 105 278 minecraft:shroomlight
setblock 391 105 314 minecraft:shroomlight
fill 391 105 315 391 107 315 minecraft:red_terracotta
setblock 394 105 276 minecraft:stripped_oak_log
setblock 394 105 316 minecraft:stripped_oak_log
fill 395 105 316 395 106 316 minecraft:red_terracotta
setblock 397 105 278 minecraft:shroomlight
fill 397 105 311 397 107 311 minecraft:stripped_oak_log
setblock 397 105 314 minecraft:shroomlight
setblock 398 105 276 minecraft:red_terracotta
fill 398 105 310 398 107 310 minecraft:stripped_oak_log
fill 398 105 312 398 107 312 minecraft:stripped_oak_log
setblock 399 105 276 minecraft:stripped_oak_log
fill 399 105 311 399 107 311 minecraft:stripped_oak_log
setblock 399 105 316 minecraft:stripped_oak_log
fill 400 105 276 400 108 276 minecraft:red_terracotta
fill 400 105 316 400 108 316 minecraft:red_terracotta
fill 401 105 277 402 105 277 minecraft:red_terracotta
setblock 403 105 277 minecraft:stripped_oak_log
setblock 403 105 278 minecraft:shroomlight
setblock 403 105 314 minecraft:shroomlight
fill 403 105 315 403 106 315 minecraft:red_terracotta
setblock 404 105 276 minecraft:stripped_oak_log
fill 404 105 277 406 105 278 minecraft:red_terracotta
setblock 404 105 316 minecraft:stripped_oak_log
fill 405 105 276 405 108 276 minecraft:red_terracotta
setblock 405 105 315 minecraft:stripped_oak_log
fill 405 105 316 405 108 316 minecraft:red_terracotta
fill 406 105 315 406 108 315 minecraft:red_terracotta
setblock 407 105 277 minecraft:red_terracotta
setblock 407 105 278 minecraft:stripped_oak_log
setblock 408 105 277 minecraft:stripped_oak_log
fill 408 105 278 408 108 278 minecraft:red_terracotta
setblock 409 105 276 minecraft:stripped_oak_log
fill 409 105 277 409 108 277 minecraft:red_terracotta
setblock 409 105 314 minecraft:shroomlight
setblock 409 105 316 minecraft:stripped_oak_log
fill 410 105 276 410 108 276 minecraft:red_terracotta
setblock 410 105 315 minecraft:stripped_oak_log
fill 410 105 316 410 108 316 minecraft:red_terracotta
fill 411 105 315 411 106 315 minecraft:red_terracotta
setblock 412 105 278 minecraft:stripped_oak_log
setblock 413 105 277 minecraft:stripped_oak_log
fill 413 105 278 413 108 278 minecraft:red_terracotta
setblock 414 105 276 minecraft:stripped_oak_log
fill 414 105 277 414 108 277 minecraft:red_terracotta
setblock 414 105 316 minecraft:stripped_oak_log
fill 415 105 276 415 108 276 minecraft:red_terracotta
setblock 415 105 278 minecraft:shroomlight
setblock 415 105 284 minecraft:shroomlight
setblock 415 105 290 minecraft:shroomlight
setblock 415 105 296 minecraft:shroomlight
setblock 415 105 302 minecraft:shroomlight
setblock 415 105 308 minecraft:shroomlight
setblock 415 105 314 minecraft:shroomlight
fill 415 105 316 415 108 316 minecraft:red_terracotta
setblock 416 105 278 minecraft:red_terracotta
setblock 416 105 279 minecraft:stripped_oak_log
fill 416 105 280 416 108 280 minecraft:red_terracotta
setblock 417 105 278 minecraft:stripped_oak_log
fill 417 105 279 417 108 279 minecraft:red_terracotta
setblock 417 105 282 minecraft:red_terracotta
fill 417 105 294 417 106 294 minecraft:red_terracotta
setblock 417 105 297 minecraft:red_terracotta
fill 417 105 314 417 108 314 minecraft:red_terracotta
setblock 377 106 276 minecraft:red_terracotta
setblock 377 106 277 minecraft:stripped_oak_log
fill 377 106 278 377 109 278 minecraft:red_terracotta
setblock 377 106 281 minecraft:red_terracotta
fill 377 106 282 379 106 295 minecraft:stripped_oak_log
setblock 377 106 296 minecraft:red_terracotta
fill 377 106 297 379 106 297 minecraft:stripped_oak_log
fill 377 106 298 377 106 301 minecraft:red_terracotta
fill 377 106 302 379 106 310 minecraft:stripped_oak_log
fill 377 106 312 379 106 312 minecraft:stripped_oak_log
fill 377 106 313 377 109 313 minecraft:red_terracotta
setblock 378 106 276 minecraft:stripped_oak_log
fill 378 106 277 378 109 277 minecraft:red_terracotta
fill 378 106 279 379 106 281 minecraft:stripped_oak_log
fill 378 106 296 379 106 296 minecraft:stripped_oak_log
fill 378 106 298 379 106 301 minecraft:stripped_oak_log
fill 378 106 311 379 106 311 minecraft:stripped_oak_log
setblock 378 106 316 minecraft:stripped_oak_log
fill 379 106 276 379 109 276 minecraft:red_terracotta
fill 379 106 278 381 106 278 minecraft:stripped_oak_log
fill 379 106 313 379 106 315 minecraft:stripped_oak_log
fill 379 106 316 379 109 316 minecraft:red_terracotta
fill 380 106 297 382 106 305 minecraft:brown_terracotta
setblock 380 106 314 minecraft:stripped_oak_log
fill 380 106 315 380 109 315 minecraft:red_terracotta
fill 381 106 314 381 109 314 minecraft:red_terracotta
setblock 382 106 276 minecraft:red_terracotta
setblock 382 106 277 minecraft:stripped_oak_log
fill 382 106 278 384 107 278 minecraft:red_terracotta
setblock 383 106 276 minecraft:stripped_oak_log
fill 383 106 277 383 109 277 minecraft:red_terracotta
setblock 383 106 316 minecraft:stripped_oak_log
fill 384 106 276 384 109 276 minecraft:red_terracotta
setblock 384 106 315 minecraft:stripped_oak_log
fill 384 106 316 384 109 316 minecraft:red_terracotta
setblock 385 106 314 minecraft:stripped_oak_log
fill 385 106 315 385 109 315 minecraft:red_terracotta
setblock 386 106 278 minecraft:stripped_oak_log
fill 386 106 314 386 108 314 minecraft:red_terracotta
setblock 387 106 277 minecraft:stripped_oak_log
fill 387 106 278 387 107 278 minecraft:red_terracotta
setblock 388 106 276 minecraft:stripped_oak_log
fill 388 106 277 388 109 277 minecraft:red_terracotta
fill 388 106 278 401 106 278 minecraft:stripped_oak_log
setblock 388 106 316 minecraft:stripped_oak_log
fill 389 106 276 389 109 276 minecraft:red_terracotta
setblock 389 106 315 minecraft:stripped_oak_log
fill 389 106 316 389 109 316 minecraft:red_terracotta
fill 390 106 314 416 106 314 minecraft:stripped_oak_log
fill 390 106 315 390 107 315 minecraft:red_terracotta
fill 391 106 277 399 106 277 minecraft:stripped_oak_log
setblock 392 106 276 minecraft:red_terracotta
setblock 393 106 276 minecraft:stripped_oak_log
fill 393 106 315 393 106 316 minecraft:stripped_oak_log
fill 394 106 276 397 106 276 minecraft:red_terracotta
fill 394 106 315 402 106 315 minecraft:stripped_oak_log
fill 394 106 316 394 107 316 minecraft:red_terracotta
fill 396 106 316 398 106 316 minecraft:stripped_oak_log
fill 397 106 310 397 107 310 minecraft:stripped_oak_log
fill 397 106 312 397 107 312 minecraft:stripped_oak_log
setblock 398 106 276 minecraft:stripped_oak_log
fill 399 106 276 399 109 276 minecraft:red_terracotta
fill 399 106 310 399 107 310 minecraft:stripped_oak_log
fill 399 106 312 399 107 312 minecraft:stripped_oak_log
fill 399 106 316 399 108 316 minecraft:red_terracotta
fill 400 106 277 401 106 277 minecraft:red_terracotta
setblock 402 106 277 minecraft:stripped_oak_log
fill 402 106 278 405 106 278 minecraft:red_terracotta
setblock 403 106 276 minecraft:stripped_oak_log
fill 403 106 277 406 106 277 minecraft:red_terracotta
setblock 403 106 316 minecraft:stripped_oak_log
fill 404 106 276 404 109 276 minecraft:red_terracotta
setblock 404 106 315 minecraft:stripped_oak_log
fill 404 106 316 404 109 316 minecraft:red_terracotta
setblock 405 106 279 minecraft:stripped_oak_log
fill 405 106 315 405 108 315 minecraft:red_terracotta
setblock 406 106 278 minecraft:stripped_oak_log
fill 406 106 279 409 106 279 minecraft:red_terracotta
setblock 407 106 277 minecraft:stripped_oak_log
fill 407 106 278 407 109 278 minecraft:red_terracotta
setblock 408 106 276 minecraft:stripped_oak_log
fill 408 106 277 408 109 277 minecraft:red_terracotta
setblock 408 106 316 minecraft:stripped_oak_log
fill 409 106 276 409 109 276 minecraft:red_terracotta
setblock 409 106 315 minecraft:stripped_oak_log
fill 409 106 316 409 109 316 minecraft:red_terracotta
setblock 410 106 278 minecraft:red_terracotta
fill 410 106 315 410 107 315 minecraft:red_terracotta
setblock 411 106 278 minecraft:stripped_oak_log
setblock 412 106 277 minecraft:stripped_oak_log
fill 412 106 278 412 109 278 minecraft:red_terracotta
fill 412 106 315 416 106 315 minecraft:stripped_oak_log
setblock 413 106 276 minecraft:stripped_oak_log
fill 413 106 277 413 109 277 minecraft:red_terracotta
setblock 413 106 316 minecraft:stripped_oak_log
fill 414 106 276 414 109 276 minecraft:red_terracotta
fill 414 106 278 415 106 278 minecraft:red_terracotta
fill 414 106 316 414 109 316 minecraft:red_terracotta
fill 415 106 279 415 106 313 minecraft:stripped_oak_log
setblock 416 106 278 minecraft:stripped_oak_log
fill 416 106 279 416 109 279 minecraft:red_terracotta
fill 416 106 281 416 107 281 minecraft:red_terracotta
fill 416 106 282 416 106 313 minecraft:stripped_oak_log
setblock 417 106 277 minecraft:stripped_oak_log
fill 417 106 278 417 109 278 minecraft:red_terracotta
setblock 417 106 282 minecraft:stripped_oak_log
fill 417 106 283 417 109 283 minecraft:red_terracotta
fill 417 106 284 417 106 293 minecraft:stripped_oak_log
setblock 417 106 297 minecraft:stripped_oak_log
fill 417 106 298 417 109 298 minecraft:red_terracotta
fill 417 106 299 417 106 313 minecraft:stripped_oak_log
setblock 377 107 276 minecraft:stripped_oak_log
fill 377 107 277 377 110 277 minecraft:red_terracotta
setblock 377 107 281 minecraft:stripped_oak_log
setblock 377 107 296 minecraft:stripped_oak_log
fill 377 107 297 377 107 300 minecraft:red_terracotta
fill 377 107 301 378 107 301 minecraft:stripped_oak_log
fill 377 107 302 377 108 304 minecraft:red_terracotta
fill 377 107 305 378 107 305 minecraft:stripped_oak_log
setblock 377 107 311 minecraft:stripped_oak_log
fill 377 107 312 377 110 312 minecraft:red_terracotta
setblock 377 107 316 minecraft:stripped_oak_log
fill 378 107 276 378 110 276 minecraft:red_terracotta
setblock 378 107 279 minecraft:red_terracotta
fill 378 107 297 378 107 300 minecraft:stripped_oak_log
fill 378 107 302 378 107 304 minecraft:stripped_oak_log
setblock 378 107 315 minecraft:stripped_oak_log
fill 378 107 316 378 110 316 minecraft:red_terracotta
fill 379 107 278 379 107 314 minecraft:orange_terracotta
fill 379 107 315 379 110 315 minecraft:red_terracotta
setblock 380 107 277 minecraft:red_terracotta
setblock 380 107 278 minecraft:orange_terracotta
fill 380 107 297 382 107 305 minecraft:stripped_oak_log
fill 380 107 314 380 108 314 minecraft:red_terracotta
setblock 381 107 277 minecraft:stripped_oak_log
fill 381 107 278 381 109 278 minecraft:red_terracotta
setblock 382 107 276 minecraft:stripped_oak_log
fill 382 107 277 382 110 277 minecraft:red_terracotta
setblock 382 107 316 minecraft:stripped_oak_log
fill 383 107 276 383 110 276 minecraft:red_terracotta
setblock 383 107 315 minecraft:stripped_oak_log
fill 383 107 316 383 110 316 minecraft:red_terracotta
setblock 384 107 314 minecraft:stripped_oak_log
fill 384 107 315 384 110 315 minecraft:red_terracotta
setblock 385 107 278 minecraft:stripped_oak_log
fill 385 107 314 385 109 314 minecraft:red_terracotta
setblock 386 107 277 minecraft:stripped_oak_log
fill 386 107 278 386 108 278 minecraft:red_terracotta
setblock 386 107 285 minecraft:light[level=12]
setblock 386 107 292 minecraft:light[level=12]
setblock 386 107 299 minecraft:light[level=12]
setblock 386 107 306 minecraft:light[level=12]
setblock 386 107 313 minecraft:light[level=12]
setblock 387 107 276 minecraft:stripped_oak_log
fill 387 107 277 387 110 277 minecraft:red_terracotta
setblock 387 107 316 minecraft:stripped_oak_log
fill 388 107 276 388 110 276 minecraft:red_terracotta
fill 388 107 278 400 107 278 minecraft:orange_terracotta
setblock 388 107 315 minecraft:stripped_oak_log
fill 388 107 316 388 110 316 minecraft:red_terracotta
fill 389 107 314 415 107 314 minecraft:orange_terracotta
fill 389 107 315 389 108 315 minecraft:red_terracotta
setblock 392 107 276 minecraft:stripped_oak_log
setblock 392 107 316 minecraft:stripped_oak_log
fill 393 107 276 396 107 276 minecraft:red_terracotta
setblock 393 107 285 minecraft:light[level=12]
setblock 393 107 292 minecraft:light[level=12]
setblock 393 107 299 minecraft:light[level=12]
setblock 393 107 306 minecraft:light[level=12]
setblock 393 107 313 minecraft:light[level=12]
setblock 393 107 316 minecraft:red_terracotta
setblock 397 107 276 minecraft:stripped_oak_log
fill 398 107 276 398 110 276 minecraft:red_terracotta
fill 399 107 277 400 107 277 minecraft:red_terracotta
setblock 400 107 285 minecraft:light[level=12]
setblock 400 107 292 minecraft:light[level=12]
setblock 400 107 299 minecraft:light[level=12]
setblock 400 107 306 minecraft:light[level=12]
setblock 400 107 313 minecraft:light[level=12]
setblock 401 107 277 minecraft:stripped_oak_log
fill 401 107 278 404 107 278 minecraft:red_terracotta
setblock 402 107 276 minecraft:stripped_oak_log
fill 402 107 277 405 107 277 minecraft:red_terracotta
setblock 402 107 316 minecraft:stripped_oak_log
fill 403 107 276 403 110 276 minecraft:red_terracotta
setblock 403 107 315 minecraft:stripped_oak_log
fill 403 107 316 403 110 316 minecraft:red_terracotta
setblock 404 107 279 minecraft:stripped_oak_log
fill 404 107 315 404 108 315 minecraft:red_terracotta
setblock 405 107 278 minecraft:stripped_oak_log
fill 405 107 279 408 107 279 minecraft:red_terracotta
setblock 406 107 277 minecraft:stripped_oak_log
fill 406 107 278 406 110 278 minecraft:red_terracotta
setblock 407 107 276 minecraft:stripped_oak_log
fill 407 107 277 407 110 277 minecraft:red_terracotta
setblock 407 107 285 minecraft:light[level=12]
setblock 407 107 292 minecraft:light[level=12]
setblock 407 107 299 minecraft:light[level=12]
setblock 407 107 306 minecraft:light[level=12]
setblock 407 107 313 minecraft:light[level=12]
setblock 407 107 316 minecraft:stripped_oak_log
fill 408 107 276 408 110 276 minecraft:red_terracotta
setblock 408 107 315 minecraft:stripped_oak_log
fill 408 107 316 408 110 316 minecraft:red_terracotta
setblock 409 107 279 minecraft:stripped_oak_log
setblock 409 107 315 minecraft:red_terracotta
setblock 410 107 278 minecraft:stripped_oak_log
fill 410 107 279 410 108 279 minecraft:red_terracotta
setblock 411 107 277 minecraft:stripped_oak_log
fill 411 107 278 411 110 278 minecraft:red_terracotta
setblock 412 107 276 minecraft:stripped_oak_log
fill 412 107 277 412 110 277 minecraft:red_terracotta
setblock 412 107 316 minecraft:stripped_oak_log
fill 413 107 276 413 110 276 minecraft:red_terracotta
fill 413 107 316 413 109 316 minecraft:red_terracotta
setblock 414 107 278 minecraft:red_terracotta
setblock 414 107 285 minecraft:light[level=12]
setblock 414 107 292 minecraft:light[level=12]
setblock 414 107 299 minecraft:light[level=12]
setblock 414 107 306 minecraft:light[level=12]
setblock 414 107 313 minecraft:light[level=12]
setblock 415 107 278 minecraft:stripped_oak_log
fill 415 107 279 415 107 313 minecraft:orange_terracotta
setblock 416 107 277 minecraft:stripped_oak_log
fill 416 107 278 416 110 278 minecraft:red_terracotta
setblock 417 107 276 minecraft:stripped_oak_log
fill 417 107 277 417 110 277 minecraft:red_terracotta
setblock 417 107 280 minecraft:red_terracotta
setblock 417 107 281 minecraft:stripped_oak_log
fill 417 107 282 417 110 282 minecraft:red_terracotta
fill 417 107 284 417 108 284 minecraft:red_terracotta
setblock 417 107 295 minecraft:red_terracotta
setblock 417 107 296 minecraft:stripped_oak_log
fill 417 107 297 417 108 297 minecraft:red_terracotta
fill 417 107 299 417 108 299 minecraft:red_terracotta
setblock 417 107 316 minecraft:stripped_oak_log
fill 376 108 275 376 111 299 minecraft:light_gray_terracotta
fill 376 108 300 376 111 302 minecraft:shroomlight
fill 376 108 303 376 111 317 minecraft:light_gray_terracotta
fill 377 108 275 418 111 275 minecraft:light_gray_terracotta
fill 377 108 276 377 111 276 minecraft:red_terracotta
setblock 377 108 279 minecraft:red_terracotta
setblock 377 108 280 minecraft:stripped_oak_log
fill 377 108 281 377 110 282 minecraft:red_terracotta
fill 377 108 296 377 108 299 minecraft:red_terracotta
setblock 377 108 300 minecraft:stripped_oak_log
fill 377 108 301 378 110 301 minecraft:red_terracotta
setblock 377 108 305 minecraft:stripped_oak_log
fill 377 108 306 377 111 306 minecraft:red_terracotta
setblock 377 108 310 minecraft:stripped_oak_log
fill 377 108 311 377 111 311 minecraft:red_terracotta
setblock 377 108 315 minecraft:stripped_oak_log
fill 377 108 316 377 111 316 minecraft:red_terracotta
fill 377 108 317 418 111 317 minecraft:light_gray_terracotta
setblock 378 108 279 minecraft:stripped_oak_log
fill 378 108 280 378 111 280 minecraft:red_terracotta
setblock 378 108 298 minecraft:red_terracotta
setblock 378 108 299 minecraft:stripped_oak_log
fill 378 108 300 378 111 300 minecraft:red_terracotta
fill 378 108 302 378 108 303 minecraft:red_terracotta
setblock 378 108 314 minecraft:stripped_oak_log
fill 378 108 315 378 110 315 minecraft:red_terracotta
setblock 380 108 277 minecraft:stripped_oak_log
setblock 380 108 278 minecraft:red_terracotta
setblock 381 108 276 minecraft:stripped_oak_log
fill 381 108 277 381 111 277 minecraft:red_terracotta
setblock 381 108 316 minecraft:stripped_oak_log
fill 382 108 276 382 111 276 minecraft:red_terracotta
fill 382 108 278 383 108 278 minecraft:red_terracotta
fill 382 108 297 382 108 305 minecraft:orange_terracotta
setblock 382 108 315 minecraft:stripped_oak_log
fill 382 108 316 382 111 316 minecraft:red_terracotta
setblock 383 108 314 minecraft:stripped_oak_log
fill 383 108 315 383 111 315 minecraft:red_terracotta
setblock 384 108 278 minecraft:stripped_oak_log
fill 384 108 314 384 109 314 minecraft:red_terracotta
setblock 385 108 277 minecraft:stripped_oak_log
fill 385 108 278 385 109 278 minecraft:red_terracotta
setblock 386 108 276 minecraft:stripped_oak_log
fill 386 108 277 386 111 277 minecraft:red_terracotta
setblock 386 108 316 minecraft:stripped_oak_log
fill 387 108 276 387 111 276 minecraft:red_terracotta
setblock 387 108 315 minecraft:stripped_oak_log
fill 387 108 316 387 111 316 minecraft:red_terracotta
fill 388 108 315 388 109 315 minecraft:red_terracotta
setblock 390 108 277 minecraft:stripped_oak_log
setblock 391 108 276 minecraft:stripped_oak_log
setblock 391 108 316 minecraft:stripped_oak_log
fill 392 108 276 395 108 276 minecraft:red_terracotta
setblock 392 108 316 minecraft:red_terracotta
setblock 396 108 276 minecraft:stripped_oak_log
fill 397 108 276 397 111 276 minecraft:red_terracotta
setblock 399 108 277 minecraft:red_terracotta
setblock 400 108 277 minecraft:stripped_oak_log
setblock 401 108 276 minecraft:stripped_oak_log
fill 401 108 277 403 108 278 minecraft:red_terracotta
setblock 401 108 316 minecraft:stripped_oak_log
fill 402 108 276 402 111 276 minecraft:red_terracotta
fill 402 108 316 402 111 316 minecraft:red_terracotta
setblock 403 108 279 minecraft:stripped_oak_log
setblock 404 108 277 minecraft:red_terracotta
setblock 404 108 278 minecraft:stripped_oak_log
fill 404 108 279 407 108 279 minecraft:red_terracotta
setblock 405 108 277 minecraft:stripped_oak_log
fill 405 108 278 405 111 278 minecraft:red_terracotta
setblock 406 108 276 minecraft:stripped_oak_log
fill 406 108 277 406 111 277 minecraft:red_terracotta
setblock 406 108 316 minecraft:stripped_oak_log
fill 407 108 276 407 111 276 minecraft:red_terracotta
setblock 407 108 315 minecraft:stripped_oak_log
fill 407 108 316 407 111 316 minecraft:red_terracotta
setblock 408 108 279 minecraft:stripped_oak_log
setblock 408 108 315 minecraft:red_terracotta
setblock 409 108 278 minecraft:stripped_oak_log
fill 409 108 279 409 109 279 minecraft:red_terracotta
setblock 410 108 277 minecraft:stripped_oak_log
fill 410 108 278 410 111 278 minecraft:red_terracotta
setblock 411 108 276 minecraft:stripped_oak_log
fill 411 108 277 411 111 277 minecraft:red_terracotta
setblock 411 108 316 minecraft:stripped_oak_log
fill 412 108 276 412 111 276 minecraft:red_terracotta
fill 412 108 316 412 109 316 minecraft:red_terracotta
setblock 414 108 278 minecraft:stripped_oak_log
setblock 415 108 277 minecraft:stripped_oak_log
fill 415 108 278 415 109 278 minecraft:red_terracotta
setblock 416 108 276 minecraft:stripped_oak_log
fill 416 108 277 416 111 277 minecraft:red_terracotta
setblock 416 108 281 minecraft:stripped_oak_log
setblock 416 108 316 minecraft:stripped_oak_log
fill 417 108 276 417 111 276 minecraft:red_terracotta
setblock 417 108 280 minecraft:stripped_oak_log
fill 417 108 281 417 111 281 minecraft:red_terracotta
setblock 417 108 300 minecraft:stripped_oak_log
setblock 417 108 315 minecraft:stripped_oak_log
fill 417 108 316 417 111 316 minecraft:red_terracotta
fill 418 108 276 418 111 316 minecraft:light_gray_terracotta
setblock 377 109 279 minecraft:stripped_oak_log
fill 377 109 280 377 112 280 minecraft:red_terracotta
fill 377 109 296 377 109 298 minecraft:red_terracotta
setblock 377 109 299 minecraft:stripped_oak_log
fill 377 109 300 377 112 300 minecraft:red_terracotta
fill 377 109 302 377 109 303 minecraft:red_terracotta
setblock 377 109 304 minecraft:stripped_oak_log
fill 377 109 305 378 111 305 minecraft:red_terracotta
fill 377 109 307 377 109 308 minecraft:red_terracotta
setblock 377 109 309 minecraft:stripped_oak_log
fill 377 109 310 377 112 310 minecraft:red_terracotta
setblock 377 109 314 minecraft:stripped_oak_log
fill 377 109 315 377 112 315 minecraft:red_terracotta
setblock 378 109 278 minecraft:stripped_oak_log
fill 378 109 279 378 112 279 minecraft:red_terracotta
setblock 378 109 298 minecraft:stripped_oak_log
fill 378 109 299 378 112 299 minecraft:red_terracotta
setblock 378 109 302 minecraft:red_terracotta
setblock 378 109 303 minecraft:stripped_oak_log
fill 378 109 304 378 112 304 minecraft:red_terracotta
setblock 378 109 314 minecraft:red_terracotta
setblock 379 109 277 minecraft:stripped_oak_log
setblock 380 109 276 minecraft:stripped_oak_log
fill 380 109 277 380 112 277 minecraft:red_terracotta
setblock 380 109 316 minecraft:stripped_oak_log
fill 381 109 276 381 112 276 minecraft:red_terracotta
setblock 381 109 315 minecraft:stripped_oak_log
fill 381 109 316 381 112 316 minecraft:red_terracotta
setblock 382 109 278 minecraft:red_terracotta
setblock 382 109 297 minecraft:stripped_oak_log
setblock 382 109 301 minecraft:stripped_oak_log
setblock 382 109 305 minecraft:stripped_oak_log
setblock 382 109 314 minecraft:stripped_oak_log
fill 382 109 315 382 112 315 minecraft:red_terracotta
setblock 383 109 278 minecraft:stripped_oak_log
setblock 383 109 314 minecraft:red_terracotta
setblock 384 109 277 minecraft:stripped_oak_log
fill 384 109 278 384 110 278 minecraft:red_terracotta
setblock 385 109 276 minecraft:stripped_oak_log
fill 385 109 277 385 111 277 minecraft:red_terracotta
setblock 385 109 316 minecraft:stripped_oak_log
fill 386 109 276 386 112 276 minecraft:red_terracotta
setblock 386 109 315 minecraft:stripped_oak_log
fill 386 109 316 386 112 316 minecraft:red_terracotta
setblock 387 109 315 minecraft:red_terracotta
setblock 390 109 276 minecraft:stripped_oak_log
setblock 390 109 316 minecraft:stripped_oak_log
setblock 391 109 276 minecraft:red_terracotta
setblock 396 109 276 minecraft:red_terracotta
setblock 399 109 277 minecraft:stripped_oak_log
setblock 400 109 276 minecraft:stripped_oak_log
fill 400 109 277 402 109 278 minecraft:red_terracotta
setblock 400 109 316 minecraft:stripped_oak_log
fill 401 109 276 401 112 276 minecraft:red_terracotta
fill 401 109 316 401 110 316 minecraft:red_terracotta
setblock 403 109 277 minecraft:red_terracotta
setblock 403 109 278 minecraft:stripped_oak_log
fill 403 109 279 406 109 279 minecraft:red_terracotta
setblock 404 109 277 minecraft:stripped_oak_log
fill 404 109 278 404 112 278 minecraft:red_terracotta
setblock 405 109 276 minecraft:stripped_oak_log
fill 405 109 277 405 112 277 minecraft:red_terracotta
setblock 405 109 316 minecraft:stripped_oak_log
fill 406 109 276 406 112 276 minecraft:red_terracotta
fill 406 109 316 406 111 316 minecraft:red_terracotta
setblock 407 109 279 minecraft:stripped_oak_log
setblock 408 109 278 minecraft:stripped_oak_log
fill 408 109 279 408 110 279 minecraft:red_terracotta
setblock 409 109 277 minecraft:stripped_oak_log
fill 409 109 278 409 111 278 minecraft:red_terracotta
setblock 410 109 276 minecraft:stripped_oak_log
fill 410 109 277 410 112 277 minecraft:red_terracotta
setblock 410 109 316 minecraft:stripped_oak_log
fill 411 109 276 411 112 276 minecraft:red_terracotta
setblock 411 109 316 minecraft:red_terracotta
setblock 413 109 278 minecraft:stripped_oak_log
setblock 414 109 277 minecraft:stripped_oak_log
setblock 414 109 278 minecraft:red_terracotta
setblock 415 109 276 minecraft:stripped_oak_log
fill 415 109 277 415 112 277 minecraft:red_terracotta
setblock 415 109 316 minecraft:stripped_oak_log
fill 416 109 276 416 112 276 minecraft:red_terracotta
setblock 416 109 280 minecraft:stripped_oak_log
fill 416 109 281 416 111 282 minecraft:red_terracotta
fill 416 109 316 416 111 316 minecraft:red_terracotta
setblock 417 109 279 minecraft:stripped_oak_log
fill 417 109 280 417 112 280 minecraft:red_terracotta
setblock 417 109 284 minecraft:stripped_oak_log
setblock 417 109 299 minecraft:stripped_oak_log
fill 417 109 300 417 111 301 minecraft:red_terracotta
setblock 417 109 314 minecraft:stripped_oak_log
fill 417 109 315 417 111 315 minecraft:red_terracotta
setblock 377 110 278 minecraft:stripped_oak_log
fill 377 110 279 377 113 279 minecraft:red_terracotta
setblock 377 110 297 minecraft:red_terracotta
setblock 377 110 298 minecraft:stripped_oak_log
fill 377 110 299 377 113 299 minecraft:red_terracotta
setblock 377 110 302 minecraft:red_terracotta
setblock 377 110 303 minecraft:stripped_oak_log
fill 377 110 304 377 113 304 minecraft:red_terracotta
setblock 377 110 307 minecraft:red_terracotta
setblock 377 110 308 minecraft:stripped_oak_log
fill 377 110 309 377 113 309 minecraft:red_terracotta
setblock 377 110 313 minecraft:stripped_oak_log
fill 377 110 314 377 113 314 minecraft:red_terracotta
setblock 378 110 277 minecraft:stripped_oak_log
fill 378 110 278 378 112 278 minecraft:red_terracotta
setblock 378 110 298 minecraft:red_terracotta
setblock 378 110 302 minecraft:stripped_oak_log
fill 378 110 303 379 112 303 minecraft:red_terracotta
setblock 378 110 306 minecraft:red_terracotta
setblock 379 110 276 minecraft:stripped_oak_log
fill 379 110 277 379 112 277 minecraft:red_terracotta
setblock 379 110 300 minecraft:red_terracotta
setblock 379 110 301 minecraft:stripped_oak_log
fill 379 110 302 379 113 302 minecraft:red_terracotta
setblock 379 110 316 minecraft:stripped_oak_log
fill 380 110 276 380 113 276 minecraft:red_terracotta
setblock 380 110 315 minecraft:stripped_oak_log
fill 380 110 316 380 113 316 minecraft:red_terracotta
fill 381 110 315 381 112 315 minecraft:red_terracotta
setblock 382 110 278 minecraft:stripped_oak_log
setblock 383 110 277 minecraft:stripped_oak_log
setblock 383 110 278 minecraft:red_terracotta
setblock 384 110 276 minecraft:stripped_oak_log
fill 384 110 277 384 112 277 minecraft:red_terracotta
setblock 384 110 316 minecraft:stripped_oak_log
fill 385 110 276 385 113 276 minecraft:red_terracotta
setblock 385 110 315 minecraft:stripped_oak_log
fill 385 110 316 385 113 316 minecraft:red_terracotta
setblock 386 110 315 minecraft:red_terracotta
setblock 389 110 276 minecraft:stripped_oak_log
setblock 389 110 316 minecraft:stripped_oak_log
setblock 399 110 276 minecraft:stripped_oak_log
fill 399 110 277 402 110 277 minecraft:red_terracotta
fill 400 110 276 400 113 276 minecraft:red_terracotta
fill 400 110 278 401 110 278 minecraft:red_terracotta
setblock 402 110 278 minecraft:stripped_oak_log
fill 402 110 279 405 110 279 minecraft:red_terracotta
setblock 403 110 277 minecraft:stripped_oak_log
fill 403 110 278 403 113 278 minecraft:red_terracotta
setblock 404 110 276 minecraft:stripped_oak_log
fill 404 110 277 404 113 277 minecraft:red_terracotta
setblock 404 110 316 minecraft:stripped_oak_log
fill 405 110 276 405 113 276 minecraft:red_terracotta
fill 405 110 316 405 111 316 minecraft:red_terracotta
setblock 406 110 279 minecraft:stripped_oak_log
setblock 407 110 278 minecraft:stripped_oak_log
setblock 407 110 279 minecraft:red_terracotta
setblock 408 110 277 minecraft:stripped_oak_log
fill 408 110 278 408 112 278 minecraft:red_terracotta
setblock 409 110 276 minecraft:stripped_oak_log
fill 409 110 277 409 113 277 minecraft:red_terracotta
setblock 409 110 316 minecraft:stripped_oak_log
fill 410 110 276 410 113 276 minecraft:red_terracotta
setblock 410 110 316 minecraft:red_terracotta
setblock 413 110 277 minecraft:stripped_oak_log
fill 413 110 290 415 110 292 minecraft:terracotta
setblock 414 110 276 minecraft:stripped_oak_log
fill 414 110 277 414 112 277 minecraft:red_terracotta
fill 415 110 276 415 113 276 minecraft:red_terracotta
setblock 415 110 316 minecraft:red_terracotta
setblock 416 110 279 minecraft:stripped_oak_log
fill 416 110 280 416 113 280 minecraft:red_terracotta
setblock 417 110 278 minecraft:stripped_oak_log
fill 417 110 279 417 113 279 minecraft:red_terracotta
setblock 417 110 283 minecraft:stripped_oak_log
fill 417 110 284 417 113 284 minecraft:red_terracotta
setblock 417 110 299 minecraft:red_terracotta
setblock 417 110 302 minecraft:red_terracotta
setblock 377 111 277 minecraft:stripped_oak_log
fill 377 111 278 377 114 278 minecraft:red_terracotta
setblock 377 111 281 minecraft:red_terracotta
setblock 377 111 282 minecraft:stripped_oak_log
setblock 377 111 297 minecraft:stripped_oak_log
fill 377 111 298 377 114 298 minecraft:red_terracotta
setblock 377 111 301 minecraft:red_terracotta
setblock 377 111 302 minecraft:stripped_oak_log
fill 377 111 303 377 114 303 minecraft:red_terracotta
setblock 377 111 307 minecraft:stripped_oak_log
fill 377 111 308 377 114 308 minecraft:red_terracotta
setblock 377 111 312 minecraft:stripped_oak_log
fill 377 111 313 377 114 313 minecraft:red_terracotta
setblock 378 111 276 minecraft:stripped_oak_log
setblock 378 111 277 minecraft:red_terracotta
setblock 378 111 301 minecraft:stripped_oak_log
fill 378 111 302 378 114 302 minecraft:red_terracotta
setblock 378 111 306 minecraft:stripped_oak_log
fill 378 111 307 378 114 307 minecraft:red_terracotta
setblock 378 111 316 minecraft:stripped_oak_log
fill 379 111 276 379 114 276 minecraft:red_terracotta
setblock 379 111 278 minecraft:light[level=15]
setblock 379 111 286 minecraft:light[level=15]
setblock 379 111 294 minecraft:light[level=15]
setblock 379 111 300 minecraft:stripped_oak_log
fill 379 111 301 379 114 301 minecraft:red_terracotta
setblock 379 111 304 minecraft:red_terracotta
setblock 379 111 310 minecraft:light[level=15]
setblock 379 111 315 minecraft:stripped_oak_log
fill 379 111 316 379 114 316 minecraft:red_terracotta
fill 380 111 315 380 112 315 minecraft:red_terracotta
setblock 382 111 277 minecraft:stripped_oak_log
setblock 383 111 276 minecraft:stripped_oak_log
fill 383 111 277 383 112 277 minecraft:red_terracotta
setblock 383 111 316 minecraft:stripped_oak_log
fill 384 111 276 384 113 276 minecraft:red_terracotta
setblock 384 111 315 minecraft:stripped_oak_log
fill 384 111 316 384 113 316 minecraft:red_terracotta
setblock 385 111 315 minecraft:red_terracotta
setblock 387 111 278 minecraft:light[level=15]
setblock 387 111 286 minecraft:light[level=15]
setblock 387 111 294 minecraft:light[level=15]
setblock 387 111 302 minecraft:light[level=15]
setblock 387 111 310 minecraft:light[level=15]
setblock 388 111 276 minecraft:stripped_oak_log
setblock 395 111 278 minecraft:light[level=15]
setblock 395 111 286 minecraft:light[level=15]
setblock 395 111 302 minecraft:light[level=15]
setblock 395 111 310 minecraft:light[level=15]
setblock 398 111 276 minecraft:stripped_oak_log
fill 399 111 276 399 113 277 minecraft:red_terracotta
fill 400 111 277 400 111 278 minecraft:red_terracotta
setblock 401 111 277 minecraft:red_terracotta
setblock 401 111 278 minecraft:stripped_oak_log
setblock 402 111 277 minecraft:stripped_oak_log
fill 402 111 278 402 114 278 minecraft:red_terracotta
setblock 403 111 276 minecraft:stripped_oak_log
fill 403 111 277 403 114 277 minecraft:red_terracotta
fill 403 111 279 404 111 279 minecraft:red_terracotta
setblock 403 111 286 minecraft:light[level=15]
setblock 403 111 294 minecraft:light[level=15]
setblock 403 111 302 minecraft:light[level=15]
setblock 403 111 310 minecraft:light[level=15]
setblock 403 111 316 minecraft:stripped_oak_log
fill 404 111 276 404 114 276 minecraft:red_terracotta
setblock 404 111 316 minecraft:red_terracotta
setblock 405 111 279 minecraft:stripped_oak_log
setblock 406 111 278 minecraft:stripped_oak_log
setblock 406 111 279 minecraft:red_terracotta
setblock 407 111 277 minecraft:stripped_oak_log
fill 407 111 278 407 112 278 minecraft:red_terracotta
setblock 408 111 276 minecraft:stripped_oak_log
fill 408 111 277 408 113 277 minecraft:red_terracotta
fill 409 111 276 409 114 276 minecraft:red_terracotta
setblock 411 111 278 minecraft:light[level=15]
setblock 411 111 286 minecraft:light[level=15]
fill 411 111 288 417 112 288 minecraft:stripped_oak_log
setblock 411 111 294 minecraft:light[level=15]
setblock 411 111 302 minecraft:light[level=15]
setblock 411 111 310 minecraft:light[level=15]
setblock 412 111 277 minecraft:stripped_oak_log
setblock 413 111 276 minecraft:stripped_oak_log
setblock 413 111 277 minecraft:red_terracotta
fill 414 111 276 414 114 276 minecraft:red_terracotta
fill 414 111 291 414 117 291 minecraft:green_concrete
fill 415 111 287 417 112 287 minecraft:stripped_oak_log
setblock 416 111 278 minecraft:stripped_oak_log
fill 416 111 279 416 114 279 minecraft:red_terracotta
setblock 417 111 277 minecraft:stripped_oak_log
fill 417 111 278 417 114 278 minecraft:red_terracotta
setblock 417 111 282 minecraft:stripped_oak_log
fill 417 111 283 417 114 283 minecraft:red_terracotta
setblock 417 111 302 minecraft:stripped_oak_log
fill 417 111 303 417 114 303 minecraft:red_terracotta
fill 376 112 275 376 115 317 minecraft:orange_terracotta
fill 377 112 275 418 115 275 minecraft:orange_terracotta
setblock 377 112 276 minecraft:stripped_oak_log
fill 377 112 277 377 115 277 minecraft:red_terracotta
setblock 377 112 281 minecraft:stripped_oak_log
fill 377 112 282 377 115 282 minecraft:red_terracotta
setblock 377 112 301 minecraft:stripped_oak_log
fill 377 112 302 377 115 302 minecraft:red_terracotta
setblock 377 112 305 minecraft:red_terracotta
setblock 377 112 306 minecraft:stripped_oak_log
fill 377 112 307 377 115 307 minecraft:red_terracotta
setblock 377 112 311 minecraft:stripped_oak_log
fill 377 112 312 377 115 312 minecraft:red_terracotta
setblock 377 112 316 minecraft:stripped_oak_log
fill 377 112 317 418 115 317 minecraft:orange_terracotta
fill 378 112 276 378 115 276 minecraft:red_terracotta
setblock 378 112 300 minecraft:stripped_oak_log
fill 378 112 301 378 115 301 minecraft:red_terracotta
setblock 378 112 305 minecraft:stripped_oak_log
fill 378 112 306 379 114 306 minecraft:red_terracotta
fill 378 112 308 378 113 308 minecraft:red_terracotta
fill 378 112 316 378 115 316 minecraft:red_terracotta
setblock 379 112 304 minecraft:stripped_oak_log
fill 379 112 305 379 115 305 minecraft:red_terracotta
setblock 381 112 277 minecraft:stripped_oak_log
setblock 382 112 276 minecraft:stripped_oak_log
setblock 382 112 277 minecraft:red_terracotta
setblock 382 112 316 minecraft:stripped_oak_log
fill 383 112 276 383 114 276 minecraft:red_terracotta
setblock 383 112 315 minecraft:stripped_oak_log
fill 383 112 316 383 115 316 minecraft:red_terracotta
fill 397 112 289 407 112 289 minecraft:stripped_oak_log
fill 398 112 276 398 115 276 minecraft:red_terracotta
setblock 400 112 277 minecraft:red_terracotta
setblock 400 112 278 minecraft:stripped_oak_log
fill 400 112 288 408 113 288 minecraft:stripped_oak_log
setblock 401 112 277 minecraft:stripped_oak_log
fill 401 112 278 401 115 278 minecraft:red_terracotta
setblock 402 112 276 minecraft:stripped_oak_log
fill 402 112 277 402 115 277 minecraft:red_terracotta
fill 403 112 276 403 115 276 minecraft:red_terracotta
setblock 403 112 279 minecraft:red_terracotta
setblock 404 112 279 minecraft:stripped_oak_log
setblock 405 112 278 minecraft:stripped_oak_log
setblock 406 112 277 minecraft:stripped_oak_log
fill 406 112 278 406 113 278 minecraft:red_terracotta
setblock 407 112 276 minecraft:stripped_oak_log
fill 407 112 277 407 114 277 minecraft:red_terracotta
fill 408 112 276 408 115 276 minecraft:red_terracotta
setblock 411 112 277 minecraft:stripped_oak_log
setblock 412 112 276 minecraft:stripped_oak_log
setblock 412 112 277 minecraft:red_terracotta
fill 412 112 287 414 112 287 minecraft:stripped_oak_log
fill 413 112 276 413 115 276 minecraft:red_terracotta
setblock 416 112 277 minecraft:stripped_oak_log
fill 416 112 278 416 115 278 minecraft:red_terracotta
setblock 416 112 281 minecraft:red_terracotta
setblock 416 112 282 minecraft:stripped_oak_log
setblock 417 112 276 minecraft:stripped_oak_log
fill 417 112 277 417 115 277 minecraft:red_terracotta
setblock 417 112 281 minecraft:stripped_oak_log
fill 417 112 282 417 115 282 minecraft:red_terracotta
setblock 417 112 285 minecraft:red_terracotta
setblock 417 112 301 minecraft:stripped_oak_log
fill 417 112 302 417 115 302 minecraft:red_terracotta
fill 417 112 304 417 112 305 minecraft:red_terracotta
setblock 417 112 316 minecraft:stripped_oak_log
fill 418 112 276 418 115 316 minecraft:orange_terracotta
fill 377 113 276 377 116 276 minecraft:red_terracotta
setblock 377 113 280 minecraft:stripped_oak_log
fill 377 113 281 377 116 281 minecraft:red_terracotta
fill 377 113 283 377 114 283 minecraft:red_terracotta
setblock 377 113 300 minecraft:stripped_oak_log
fill 377 113 301 377 116 301 minecraft:red_terracotta
setblock 377 113 305 minecraft:stripped_oak_log
fill 377 113 306 377 116 306 minecraft:red_terracotta
setblock 377 113 310 minecraft:stripped_oak_log
fill 377 113 311 377 116 311 minecraft:red_terracotta
setblock 377 113 315 minecraft:stripped_oak_log
fill 377 113 316 377 116 316 minecraft:red_terracotta
setblock 378 113 299 minecraft:stripped_oak_log
fill 378 113 300 378 116 300 minecraft:red_terracotta
setblock 378 113 303 minecraft:red_terracotta
setblock 378 113 304 minecraft:stripped_oak_log
fill 378 113 305 378 116 305 minecraft:red_terracotta
setblock 378 113 309 minecraft:stripped_oak_log
setblock 379 113 278 minecraft:light[level=12]
setblock 379 113 285 minecraft:light[level=12]
setblock 379 113 292 minecraft:light[level=12]
setblock 379 113 299 minecraft:light[level=12]
setblock 379 113 303 minecraft:stripped_oak_log
fill 379 113 304 379 116 304 minecraft:red_terracotta
setblock 379 113 307 minecraft:red_terracotta
setblock 379 113 313 minecraft:light[level=12]
setblock 381 113 276 minecraft:stripped_oak_log
setblock 381 113 277 minecraft:red_terracotta
setblock 381 113 316 minecraft:stripped_oak_log
fill 382 113 276 382 115 276 minecraft:red_terracotta
fill 382 113 316 382 116 316 minecraft:red_terracotta
fill 385 113 289 405 113 289 minecraft:stripped_oak_log
setblock 386 113 278 minecraft:light[level=12]
setblock 386 113 285 minecraft:light[level=12]
setblock 386 113 292 minecraft:light[level=12]
setblock 386 113 299 minecraft:light[level=12]
setblock 386 113 306 minecraft:light[level=12]
setblock 386 113 313 minecraft:light[level=12]
fill 387 113 290 391 113 290 minecraft:stripped_oak_log
setblock 393 113 278 minecraft:light[level=12]
setblock 393 113 285 minecraft:light[level=12]
setblock 393 113 292 minecraft:light[level=12]
setblock 393 113 299 minecraft:light[level=12]
setblock 393 113 306 minecraft:light[level=12]
setblock 393 113 313 minecraft:light[level=12]
fill 394 113 288 399 113 288 minecraft:stripped_oak_log
setblock 400 113 277 minecraft:stripped_oak_log
setblock 400 113 278 minecraft:light[level=12]
setblock 400 113 285 minecraft:light[level=12]
setblock 400 113 292 minecraft:light[level=12]
setblock 400 113 299 minecraft:light[level=12]
setblock 400 113 306 minecraft:light[level=12]
setblock 400 113 313 minecraft:light[level=12]
setblock 401 113 276 minecraft:stripped_oak_log
fill 401 113 277 401 116 277 minecraft:red_terracotta
fill 402 113 276 402 116 276 minecraft:red_terracotta
setblock 404 113 278 minecraft:stripped_oak_log
setblock 405 113 277 minecraft:stripped_oak_log
fill 405 113 278 405 114 278 minecraft:red_terracotta
setblock 406 113 276 minecraft:stripped_oak_log
fill 406 113 277 406 115 277 minecraft:red_terracotta
schedule function dropper:buildpart/68_3 1t
