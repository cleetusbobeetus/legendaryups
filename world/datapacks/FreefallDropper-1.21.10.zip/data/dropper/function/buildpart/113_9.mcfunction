fill 252 242 464 254 242 465 minecraft:brown_terracotta
setblock 252 242 503 minecraft:bone_block
fill 252 242 504 255 242 504 minecraft:brown_terracotta
fill 253 242 503 256 242 503 minecraft:brown_terracotta
setblock 255 242 464 minecraft:brown_terracotta
setblock 255 242 465 minecraft:bone_block
fill 255 242 502 257 242 502 minecraft:brown_terracotta
setblock 256 242 464 minecraft:bone_block
fill 256 242 465 256 245 465 minecraft:brown_terracotta
setblock 256 242 504 minecraft:bone_block
fill 257 242 464 257 245 464 minecraft:brown_terracotta
fill 257 242 501 258 242 501 minecraft:brown_terracotta
setblock 257 242 503 minecraft:bone_block
fill 257 242 504 257 245 504 minecraft:brown_terracotta
setblock 258 242 502 minecraft:bone_block
fill 258 242 503 258 245 503 minecraft:brown_terracotta
setblock 259 242 501 minecraft:bone_block
fill 259 242 502 259 245 502 minecraft:brown_terracotta
setblock 260 242 465 minecraft:bone_block
fill 260 242 501 260 243 501 minecraft:brown_terracotta
setblock 261 242 464 minecraft:bone_block
fill 261 242 465 261 245 465 minecraft:brown_terracotta
setblock 261 242 504 minecraft:bone_block
fill 262 242 464 262 245 464 minecraft:brown_terracotta
setblock 262 242 503 minecraft:bone_block
fill 262 242 504 262 245 504 minecraft:brown_terracotta
setblock 263 242 502 minecraft:bone_block
fill 263 242 503 263 245 503 minecraft:brown_terracotta
setblock 264 242 501 minecraft:bone_block
fill 264 242 502 264 244 502 minecraft:brown_terracotta
setblock 266 242 464 minecraft:bone_block
setblock 266 242 504 minecraft:bone_block
setblock 267 242 464 minecraft:brown_terracotta
setblock 267 242 503 minecraft:bone_block
fill 267 242 504 270 242 504 minecraft:brown_terracotta
fill 268 242 503 268 243 503 minecraft:brown_terracotta
setblock 271 242 504 minecraft:bone_block
setblock 272 242 503 minecraft:bone_block
fill 272 242 504 272 245 504 minecraft:brown_terracotta
fill 273 242 503 273 243 503 minecraft:brown_terracotta
fill 275 242 478 275 242 479 minecraft:brown_terracotta
setblock 275 242 480 minecraft:bone_block
fill 275 242 481 275 245 481 minecraft:brown_terracotta
setblock 275 242 484 minecraft:brown_terracotta
setblock 275 242 485 minecraft:bone_block
fill 275 242 486 275 245 486 minecraft:brown_terracotta
setblock 275 242 489 minecraft:brown_terracotta
setblock 275 242 496 minecraft:brown_terracotta
setblock 275 242 500 minecraft:bone_block
fill 275 242 501 275 244 501 minecraft:brown_terracotta
setblock 276 242 464 minecraft:bone_block
setblock 276 242 474 minecraft:bone_block
fill 276 242 475 276 245 475 minecraft:brown_terracotta
setblock 276 242 479 minecraft:bone_block
fill 276 242 480 276 245 480 minecraft:brown_terracotta
setblock 276 242 484 minecraft:bone_block
fill 276 242 485 276 245 485 minecraft:brown_terracotta
setblock 276 242 489 minecraft:bone_block
fill 276 242 490 276 245 490 minecraft:brown_terracotta
setblock 276 242 494 minecraft:bone_block
fill 276 242 495 276 245 495 minecraft:brown_terracotta
setblock 276 242 499 minecraft:bone_block
fill 276 242 500 276 245 500 minecraft:brown_terracotta
setblock 276 242 504 minecraft:bone_block
fill 236 243 464 236 246 464 minecraft:brown_terracotta
fill 236 243 466 236 243 467 minecraft:brown_terracotta
setblock 236 243 468 minecraft:bone_block
fill 236 243 469 236 246 469 minecraft:brown_terracotta
setblock 236 243 473 minecraft:bone_block
fill 236 243 474 236 243 477 minecraft:brown_terracotta
setblock 236 243 478 minecraft:bone_block
fill 236 243 479 236 243 482 minecraft:brown_terracotta
setblock 236 243 483 minecraft:bone_block
fill 236 243 484 236 246 484 minecraft:brown_terracotta
setblock 236 243 488 minecraft:bone_block
fill 236 243 489 236 246 489 minecraft:brown_terracotta
setblock 236 243 498 minecraft:bone_block
fill 236 243 499 236 244 499 minecraft:brown_terracotta
setblock 236 243 502 minecraft:brown_terracotta
setblock 236 243 503 minecraft:bone_block
fill 236 243 504 236 246 504 minecraft:brown_terracotta
setblock 237 243 466 minecraft:brown_terracotta
setblock 237 243 467 minecraft:bone_block
fill 237 243 473 237 244 473 minecraft:brown_terracotta
setblock 237 243 477 minecraft:bone_block
fill 237 243 478 237 246 478 minecraft:brown_terracotta
setblock 237 243 482 minecraft:bone_block
fill 237 243 483 237 246 483 minecraft:brown_terracotta
setblock 237 243 487 minecraft:bone_block
fill 237 243 488 237 246 488 minecraft:brown_terracotta
setblock 237 243 502 minecraft:bone_block
fill 237 243 503 237 244 503 minecraft:brown_terracotta
setblock 238 243 476 minecraft:bone_block
fill 238 243 477 238 244 477 minecraft:brown_terracotta
setblock 238 243 481 minecraft:bone_block
fill 238 243 482 238 246 482 minecraft:brown_terracotta
setblock 238 243 486 minecraft:bone_block
fill 238 243 487 238 246 487 minecraft:brown_terracotta
setblock 239 243 465 minecraft:bone_block
setblock 239 243 480 minecraft:bone_block
fill 239 243 481 239 244 481 minecraft:brown_terracotta
setblock 240 243 464 minecraft:bone_block
fill 240 243 465 240 246 465 minecraft:brown_terracotta
setblock 240 243 504 minecraft:bone_block
fill 241 243 464 241 246 464 minecraft:brown_terracotta
setblock 241 243 503 minecraft:bone_block
fill 241 243 504 241 246 504 minecraft:brown_terracotta
setblock 242 243 503 minecraft:brown_terracotta
setblock 244 243 465 minecraft:bone_block
setblock 245 243 464 minecraft:bone_block
fill 245 243 465 245 246 465 minecraft:brown_terracotta
setblock 245 243 504 minecraft:bone_block
fill 246 243 464 249 243 464 minecraft:brown_terracotta
fill 246 243 504 249 243 504 minecraft:brown_terracotta
setblock 250 243 464 minecraft:bone_block
setblock 250 243 504 minecraft:bone_block
fill 251 243 464 254 243 464 minecraft:brown_terracotta
fill 251 243 504 254 243 504 minecraft:brown_terracotta
fill 252 243 465 253 243 465 minecraft:brown_terracotta
fill 252 243 503 255 243 503 minecraft:brown_terracotta
setblock 254 243 465 minecraft:bone_block
setblock 255 243 464 minecraft:bone_block
fill 255 243 465 255 246 465 minecraft:brown_terracotta
fill 255 243 502 256 243 502 minecraft:brown_terracotta
setblock 255 243 504 minecraft:bone_block
fill 256 243 464 256 246 464 minecraft:brown_terracotta
setblock 256 243 503 minecraft:bone_block
fill 256 243 504 256 246 504 minecraft:brown_terracotta
setblock 257 243 502 minecraft:bone_block
fill 257 243 503 257 246 503 minecraft:brown_terracotta
setblock 258 243 501 minecraft:bone_block
fill 258 243 502 258 246 502 minecraft:brown_terracotta
setblock 259 243 465 minecraft:bone_block
setblock 259 243 501 minecraft:brown_terracotta
setblock 260 243 464 minecraft:bone_block
fill 260 243 465 260 246 465 minecraft:brown_terracotta
setblock 260 243 504 minecraft:bone_block
fill 261 243 464 261 246 464 minecraft:brown_terracotta
setblock 261 243 503 minecraft:bone_block
fill 261 243 504 261 246 504 minecraft:brown_terracotta
setblock 262 243 502 minecraft:bone_block
fill 262 243 503 262 246 503 minecraft:brown_terracotta
fill 263 243 502 263 244 502 minecraft:brown_terracotta
setblock 265 243 464 minecraft:bone_block
setblock 265 243 504 minecraft:bone_block
setblock 266 243 464 minecraft:brown_terracotta
setblock 266 243 503 minecraft:bone_block
fill 266 243 504 269 243 504 minecraft:brown_terracotta
fill 267 243 503 267 244 503 minecraft:brown_terracotta
setblock 270 243 504 minecraft:bone_block
fill 271 243 504 271 246 504 minecraft:brown_terracotta
fill 274 243 483 274 243 484 minecraft:brown_terracotta
setblock 275 243 464 minecraft:bone_block
setblock 275 243 478 minecraft:brown_terracotta
setblock 275 243 479 minecraft:bone_block
fill 275 243 480 275 246 480 minecraft:brown_terracotta
setblock 275 243 484 minecraft:bone_block
fill 275 243 485 275 246 485 minecraft:brown_terracotta
setblock 275 243 489 minecraft:bone_block
fill 275 243 490 275 246 490 minecraft:brown_terracotta
setblock 275 243 499 minecraft:bone_block
fill 275 243 500 275 244 500 minecraft:brown_terracotta
setblock 275 243 504 minecraft:bone_block
fill 276 243 464 276 245 465 minecraft:brown_terracotta
setblock 276 243 478 minecraft:bone_block
fill 276 243 479 276 246 479 minecraft:brown_terracotta
setblock 276 243 483 minecraft:bone_block
fill 276 243 484 276 246 484 minecraft:brown_terracotta
setblock 276 243 488 minecraft:bone_block
fill 276 243 489 276 246 489 minecraft:brown_terracotta
setblock 276 243 493 minecraft:bone_block
fill 276 243 494 276 246 494 minecraft:brown_terracotta
setblock 276 243 498 minecraft:bone_block
fill 276 243 499 276 246 499 minecraft:brown_terracotta
setblock 276 243 503 minecraft:bone_block
fill 276 243 504 276 246 504 minecraft:brown_terracotta
setblock 236 244 466 minecraft:brown_terracotta
setblock 236 244 467 minecraft:bone_block
fill 236 244 468 237 246 468 minecraft:brown_terracotta
setblock 236 244 472 minecraft:bone_block
fill 236 244 473 236 244 476 minecraft:brown_terracotta
setblock 236 244 477 minecraft:bone_block
fill 236 244 478 236 244 481 minecraft:brown_terracotta
setblock 236 244 482 minecraft:bone_block
fill 236 244 483 236 247 483 minecraft:brown_terracotta
setblock 236 244 487 minecraft:bone_block
fill 236 244 488 236 247 488 minecraft:brown_terracotta
setblock 236 244 502 minecraft:bone_block
fill 236 244 503 236 247 503 minecraft:brown_terracotta
setblock 237 244 466 minecraft:bone_block
fill 237 244 467 237 247 467 minecraft:brown_terracotta
setblock 237 244 476 minecraft:bone_block
fill 237 244 477 237 247 477 minecraft:brown_terracotta
setblock 237 244 481 minecraft:bone_block
fill 237 244 482 237 247 482 minecraft:brown_terracotta
setblock 237 244 486 minecraft:bone_block
fill 237 244 487 237 247 487 minecraft:brown_terracotta
setblock 237 244 502 minecraft:brown_terracotta
setblock 238 244 464 minecraft:brown_terracotta
setblock 238 244 465 minecraft:bone_block
setblock 238 244 476 minecraft:brown_terracotta
setblock 238 244 480 minecraft:bone_block
fill 238 244 481 238 247 481 minecraft:brown_terracotta
setblock 238 244 485 minecraft:bone_block
fill 238 244 486 238 247 486 minecraft:brown_terracotta
fill 238 244 501 238 245 501 minecraft:soul_soil
setblock 239 244 464 minecraft:bone_block
fill 239 244 465 239 247 465 minecraft:brown_terracotta
setblock 239 244 480 minecraft:brown_terracotta
fill 239 244 502 239 245 502 minecraft:soul_soil
setblock 239 244 504 minecraft:bone_block
fill 240 244 464 240 247 464 minecraft:brown_terracotta
setblock 240 244 503 minecraft:bone_block
fill 240 244 504 240 247 504 minecraft:brown_terracotta
setblock 241 244 503 minecraft:brown_terracotta
setblock 243 244 465 minecraft:bone_block
setblock 244 244 464 minecraft:bone_block
fill 244 244 465 244 247 465 minecraft:brown_terracotta
setblock 244 244 504 minecraft:bone_block
fill 245 244 464 248 244 464 minecraft:brown_terracotta
fill 245 244 504 248 244 504 minecraft:brown_terracotta
fill 247 244 480 247 245 480 minecraft:bone_block
setblock 249 244 464 minecraft:bone_block
setblock 249 244 504 minecraft:bone_block
fill 250 244 464 253 244 464 minecraft:brown_terracotta
fill 250 244 504 253 244 504 minecraft:brown_terracotta
fill 251 244 465 252 244 465 minecraft:brown_terracotta
fill 252 244 503 254 244 503 minecraft:brown_terracotta
setblock 253 244 465 minecraft:bone_block
setblock 254 244 464 minecraft:bone_block
fill 254 244 465 254 247 465 minecraft:brown_terracotta
setblock 254 244 504 minecraft:bone_block
fill 255 244 464 255 247 464 minecraft:brown_terracotta
setblock 255 244 502 minecraft:brown_terracotta
setblock 255 244 503 minecraft:bone_block
fill 255 244 504 255 247 504 minecraft:brown_terracotta
setblock 256 244 502 minecraft:bone_block
fill 256 244 503 256 247 503 minecraft:brown_terracotta
fill 257 244 502 257 247 502 minecraft:brown_terracotta
setblock 258 244 465 minecraft:bone_block
setblock 259 244 464 minecraft:bone_block
fill 259 244 465 259 247 465 minecraft:brown_terracotta
setblock 259 244 504 minecraft:bone_block
fill 260 244 464 260 247 464 minecraft:brown_terracotta
setblock 260 244 503 minecraft:bone_block
fill 260 244 504 260 247 504 minecraft:brown_terracotta
setblock 261 244 502 minecraft:bone_block
fill 261 244 503 261 247 503 minecraft:brown_terracotta
fill 262 244 502 262 245 502 minecraft:brown_terracotta
setblock 264 244 464 minecraft:bone_block
setblock 264 244 504 minecraft:bone_block
fill 265 244 464 265 245 464 minecraft:brown_terracotta
setblock 265 244 503 minecraft:bone_block
fill 265 244 504 268 244 504 minecraft:brown_terracotta
setblock 266 244 503 minecraft:brown_terracotta
setblock 269 244 504 minecraft:bone_block
fill 270 244 504 270 247 504 minecraft:brown_terracotta
setblock 274 244 483 minecraft:brown_terracotta
setblock 274 244 484 minecraft:bone_block
fill 274 244 485 274 247 485 minecraft:brown_terracotta
setblock 274 244 504 minecraft:bone_block
fill 275 244 464 275 247 464 minecraft:brown_terracotta
setblock 275 244 478 minecraft:bone_block
fill 275 244 479 275 247 479 minecraft:brown_terracotta
setblock 275 244 483 minecraft:bone_block
fill 275 244 484 275 247 484 minecraft:brown_terracotta
setblock 275 244 487 minecraft:brown_terracotta
setblock 275 244 488 minecraft:bone_block
fill 275 244 489 275 247 489 minecraft:brown_terracotta
setblock 275 244 503 minecraft:bone_block
fill 275 244 504 275 247 504 minecraft:brown_terracotta
setblock 276 244 466 minecraft:brown_terracotta
setblock 276 244 477 minecraft:bone_block
fill 276 244 478 276 247 478 minecraft:brown_terracotta
setblock 276 244 482 minecraft:bone_block
fill 276 244 483 276 247 483 minecraft:brown_terracotta
setblock 276 244 487 minecraft:bone_block
fill 276 244 488 276 247 488 minecraft:brown_terracotta
setblock 276 244 492 minecraft:bone_block
fill 276 244 493 276 247 493 minecraft:brown_terracotta
setblock 276 244 497 minecraft:bone_block
fill 276 244 498 276 247 498 minecraft:brown_terracotta
setblock 276 244 502 minecraft:bone_block
fill 276 244 503 276 247 503 minecraft:brown_terracotta
setblock 236 245 465 minecraft:brown_terracotta
setblock 236 245 466 minecraft:bone_block
fill 236 245 467 236 248 467 minecraft:brown_terracotta
setblock 236 245 471 minecraft:bone_block
fill 236 245 472 236 245 475 minecraft:brown_terracotta
setblock 236 245 476 minecraft:bone_block
fill 236 245 477 236 245 480 minecraft:brown_terracotta
setblock 236 245 481 minecraft:bone_block
fill 236 245 482 236 248 482 minecraft:brown_terracotta
setblock 236 245 486 minecraft:bone_block
fill 236 245 487 236 248 487 minecraft:brown_terracotta
setblock 236 245 491 minecraft:bone_block
setblock 236 245 501 minecraft:bone_block
fill 236 245 502 236 248 502 minecraft:brown_terracotta
setblock 237 245 465 minecraft:bone_block
fill 237 245 466 237 248 466 minecraft:brown_terracotta
setblock 237 245 469 minecraft:brown_terracotta
setblock 237 245 475 minecraft:bone_block
fill 237 245 476 237 248 476 minecraft:brown_terracotta
setblock 237 245 480 minecraft:bone_block
fill 237 245 481 237 248 481 minecraft:brown_terracotta
setblock 237 245 485 minecraft:bone_block
fill 237 245 486 237 248 486 minecraft:brown_terracotta
fill 237 245 501 237 245 503 minecraft:soul_soil
setblock 238 245 464 minecraft:bone_block
fill 238 245 465 238 248 465 minecraft:brown_terracotta
setblock 238 245 479 minecraft:bone_block
fill 238 245 480 238 247 480 minecraft:brown_terracotta
setblock 238 245 484 minecraft:bone_block
fill 238 245 485 238 248 485 minecraft:brown_terracotta
setblock 238 245 504 minecraft:bone_block
fill 239 245 464 239 248 464 minecraft:brown_terracotta
setblock 239 245 501 minecraft:soul_soil
setblock 239 245 503 minecraft:bone_block
fill 239 245 504 239 248 504 minecraft:brown_terracotta
setblock 242 245 465 minecraft:bone_block
setblock 243 245 464 minecraft:bone_block
fill 243 245 465 243 248 465 minecraft:brown_terracotta
setblock 243 245 504 minecraft:bone_block
fill 244 245 464 247 245 464 minecraft:brown_terracotta
fill 244 245 504 247 245 504 minecraft:brown_terracotta
setblock 248 245 464 minecraft:bone_block
setblock 248 245 504 minecraft:bone_block
fill 249 245 464 252 245 464 minecraft:brown_terracotta
fill 249 245 504 252 245 504 minecraft:brown_terracotta
setblock 251 245 465 minecraft:brown_terracotta
setblock 252 245 465 minecraft:bone_block
fill 252 245 503 253 245 503 minecraft:brown_terracotta
setblock 253 245 464 minecraft:bone_block
fill 253 245 465 253 248 465 minecraft:brown_terracotta
setblock 253 245 504 minecraft:bone_block
fill 254 245 464 254 248 464 minecraft:brown_terracotta
setblock 254 245 503 minecraft:bone_block
fill 254 245 504 254 248 504 minecraft:brown_terracotta
setblock 255 245 502 minecraft:bone_block
fill 255 245 503 255 248 503 minecraft:brown_terracotta
fill 256 245 502 256 248 502 minecraft:brown_terracotta
setblock 257 245 465 minecraft:bone_block
fill 257 245 466 257 248 466 minecraft:brown_terracotta
setblock 258 245 464 minecraft:bone_block
fill 258 245 465 258 248 465 minecraft:brown_terracotta
setblock 258 245 504 minecraft:bone_block
fill 259 245 464 259 248 464 minecraft:brown_terracotta
setblock 259 245 503 minecraft:bone_block
fill 259 245 504 259 248 504 minecraft:brown_terracotta
setblock 260 245 502 minecraft:bone_block
fill 260 245 503 260 248 503 minecraft:brown_terracotta
fill 261 245 502 261 246 502 minecraft:brown_terracotta
setblock 262 245 465 minecraft:bone_block
setblock 263 245 464 minecraft:bone_block
setblock 263 245 504 minecraft:bone_block
fill 264 245 464 264 248 464 minecraft:brown_terracotta
setblock 264 245 503 minecraft:bone_block
fill 264 245 504 267 245 504 minecraft:brown_terracotta
setblock 265 245 503 minecraft:brown_terracotta
setblock 268 245 504 minecraft:bone_block
fill 269 245 504 269 248 504 minecraft:brown_terracotta
setblock 273 245 504 minecraft:bone_block
fill 274 245 464 274 248 464 minecraft:brown_terracotta
setblock 274 245 482 minecraft:brown_terracotta
setblock 274 245 483 minecraft:bone_block
fill 274 245 484 274 248 484 minecraft:brown_terracotta
fill 274 245 486 274 246 486 minecraft:brown_terracotta
fill 274 245 504 274 248 504 minecraft:brown_terracotta
setblock 275 245 482 minecraft:bone_block
fill 275 245 483 275 248 483 minecraft:brown_terracotta
setblock 275 245 487 minecraft:bone_block
fill 275 245 488 275 248 488 minecraft:brown_terracotta
setblock 275 245 491 minecraft:brown_terracotta
setblock 275 245 502 minecraft:bone_block
setblock 275 245 503 minecraft:brown_terracotta
setblock 276 245 466 minecraft:bone_block
fill 276 245 467 276 248 467 minecraft:brown_terracotta
setblock 276 245 476 minecraft:bone_block
fill 276 245 477 276 248 477 minecraft:brown_terracotta
setblock 276 245 481 minecraft:bone_block
fill 276 245 482 276 248 482 minecraft:brown_terracotta
setblock 276 245 486 minecraft:bone_block
fill 276 245 487 276 248 487 minecraft:brown_terracotta
setblock 276 245 491 minecraft:bone_block
fill 276 245 492 276 248 492 minecraft:brown_terracotta
setblock 276 245 496 minecraft:bone_block
fill 276 245 497 276 248 497 minecraft:brown_terracotta
setblock 276 245 501 minecraft:bone_block
fill 276 245 502 276 248 502 minecraft:brown_terracotta
setblock 236 246 465 minecraft:bone_block
fill 236 246 466 236 249 466 minecraft:brown_terracotta
setblock 236 246 470 minecraft:bone_block
fill 236 246 471 236 246 474 minecraft:brown_terracotta
setblock 236 246 475 minecraft:bone_block
fill 236 246 476 236 246 479 minecraft:brown_terracotta
setblock 236 246 480 minecraft:bone_block
fill 236 246 481 236 249 481 minecraft:brown_terracotta
setblock 236 246 485 minecraft:bone_block
fill 236 246 486 236 249 486 minecraft:brown_terracotta
setblock 236 246 490 minecraft:bone_block
fill 236 246 491 236 248 492 minecraft:brown_terracotta
fill 236 246 501 236 247 501 minecraft:brown_terracotta
setblock 237 246 464 minecraft:bone_block
fill 237 246 465 237 249 465 minecraft:brown_terracotta
setblock 237 246 469 minecraft:bone_block
fill 237 246 470 237 246 473 minecraft:brown_terracotta
setblock 237 246 474 minecraft:bone_block
fill 237 246 475 237 249 475 minecraft:brown_terracotta
setblock 237 246 479 minecraft:bone_block
fill 237 246 480 237 249 480 minecraft:brown_terracotta
setblock 237 246 484 minecraft:bone_block
fill 237 246 485 237 249 485 minecraft:brown_terracotta
setblock 237 246 489 minecraft:bone_block
setblock 237 246 504 minecraft:bone_block
fill 238 246 464 238 249 464 minecraft:brown_terracotta
fill 238 246 466 239 246 466 minecraft:brown_terracotta
setblock 238 246 479 minecraft:brown_terracotta
setblock 238 246 483 minecraft:bone_block
fill 238 246 484 238 249 484 minecraft:brown_terracotta
fill 238 246 504 238 249 504 minecraft:brown_terracotta
setblock 241 246 465 minecraft:bone_block
setblock 242 246 464 minecraft:bone_block
fill 242 246 465 242 249 465 minecraft:brown_terracotta
setblock 242 246 504 minecraft:bone_block
fill 243 246 464 246 246 464 minecraft:brown_terracotta
fill 243 246 504 245 246 504 minecraft:brown_terracotta
setblock 247 246 464 minecraft:bone_block
setblock 247 246 504 minecraft:bone_block
fill 248 246 464 251 246 464 minecraft:brown_terracotta
fill 248 246 504 251 246 504 minecraft:brown_terracotta
fill 249 246 465 250 246 465 minecraft:brown_terracotta
setblock 251 246 465 minecraft:bone_block
setblock 252 246 464 minecraft:bone_block
fill 252 246 465 252 249 465 minecraft:brown_terracotta
setblock 252 246 503 minecraft:brown_terracotta
setblock 252 246 504 minecraft:bone_block
fill 253 246 464 253 249 464 minecraft:brown_terracotta
setblock 253 246 503 minecraft:bone_block
fill 253 246 504 253 249 504 minecraft:brown_terracotta
fill 254 246 503 254 249 503 minecraft:brown_terracotta
setblock 255 246 466 minecraft:bone_block
fill 255 246 502 255 249 502 minecraft:brown_terracotta
setblock 256 246 465 minecraft:bone_block
fill 256 246 466 256 249 466 minecraft:brown_terracotta
setblock 257 246 464 minecraft:bone_block
fill 257 246 465 257 249 465 minecraft:brown_terracotta
setblock 257 246 504 minecraft:bone_block
fill 258 246 464 258 249 464 minecraft:brown_terracotta
setblock 258 246 503 minecraft:bone_block
fill 258 246 504 258 249 504 minecraft:brown_terracotta
setblock 259 246 502 minecraft:bone_block
fill 259 246 503 259 249 503 minecraft:brown_terracotta
fill 260 246 502 260 247 502 minecraft:brown_terracotta
setblock 261 246 465 minecraft:bone_block
setblock 262 246 464 minecraft:bone_block
setblock 262 246 504 minecraft:bone_block
fill 263 246 464 263 249 464 minecraft:brown_terracotta
setblock 263 246 503 minecraft:bone_block
fill 263 246 504 266 246 504 minecraft:brown_terracotta
setblock 264 246 503 minecraft:brown_terracotta
setblock 267 246 504 minecraft:bone_block
fill 268 246 504 268 247 504 minecraft:brown_terracotta
setblock 272 246 504 minecraft:bone_block
fill 273 246 464 273 249 464 minecraft:brown_terracotta
fill 273 246 504 273 249 504 minecraft:brown_terracotta
setblock 274 246 482 minecraft:bone_block
fill 274 246 483 274 249 483 minecraft:brown_terracotta
setblock 274 246 487 minecraft:bone_block
fill 274 246 488 274 249 488 minecraft:brown_terracotta
setblock 275 246 481 minecraft:bone_block
fill 275 246 482 275 249 482 minecraft:brown_terracotta
setblock 275 246 486 minecraft:bone_block
fill 275 246 487 275 249 487 minecraft:brown_terracotta
setblock 275 246 491 minecraft:bone_block
setblock 276 246 464 minecraft:brown_terracotta
setblock 276 246 465 minecraft:bone_block
fill 276 246 466 276 249 466 minecraft:brown_terracotta
fill 276 246 468 276 247 468 minecraft:brown_terracotta
setblock 276 246 475 minecraft:bone_block
fill 276 246 476 276 249 476 minecraft:brown_terracotta
setblock 276 246 480 minecraft:bone_block
fill 276 246 481 276 249 481 minecraft:brown_terracotta
setblock 276 246 485 minecraft:bone_block
fill 276 246 486 276 249 486 minecraft:brown_terracotta
setblock 276 246 490 minecraft:bone_block
fill 276 246 491 276 249 491 minecraft:brown_terracotta
setblock 276 246 495 minecraft:bone_block
fill 276 246 496 276 249 496 minecraft:brown_terracotta
setblock 276 246 500 minecraft:bone_block
fill 276 246 501 276 249 501 minecraft:brown_terracotta
setblock 236 247 464 minecraft:bone_block
fill 236 247 465 236 250 465 minecraft:brown_terracotta
setblock 236 247 468 minecraft:brown_terracotta
setblock 236 247 469 minecraft:bone_block
fill 236 247 470 236 247 473 minecraft:brown_terracotta
setblock 236 247 474 minecraft:bone_block
fill 236 247 475 236 247 478 minecraft:brown_terracotta
setblock 236 247 479 minecraft:bone_block
fill 236 247 480 236 250 480 minecraft:brown_terracotta
setblock 236 247 484 minecraft:bone_block
fill 236 247 485 236 250 485 minecraft:brown_terracotta
setblock 236 247 489 minecraft:bone_block
fill 236 247 490 237 249 490 minecraft:brown_terracotta
setblock 236 247 504 minecraft:bone_block
fill 237 247 464 237 250 464 minecraft:brown_terracotta
setblock 237 247 468 minecraft:bone_block
fill 237 247 469 237 247 472 minecraft:brown_terracotta
setblock 237 247 473 minecraft:bone_block
fill 237 247 474 237 250 474 minecraft:brown_terracotta
setblock 237 247 478 minecraft:bone_block
fill 237 247 479 237 250 479 minecraft:brown_terracotta
setblock 237 247 483 minecraft:bone_block
fill 237 247 484 237 250 484 minecraft:brown_terracotta
setblock 237 247 488 minecraft:bone_block
fill 237 247 489 237 250 489 minecraft:brown_terracotta
fill 237 247 504 237 250 504 minecraft:brown_terracotta
setblock 238 247 466 minecraft:brown_terracotta
setblock 238 247 467 minecraft:bone_block
setblock 238 247 482 minecraft:bone_block
fill 238 247 483 238 250 483 minecraft:brown_terracotta
setblock 238 247 487 minecraft:bone_block
setblock 239 247 466 minecraft:bone_block
setblock 240 247 465 minecraft:bone_block
fill 240 247 466 240 250 466 minecraft:brown_terracotta
setblock 241 247 464 minecraft:bone_block
fill 241 247 465 241 250 465 minecraft:brown_terracotta
setblock 241 247 504 minecraft:bone_block
fill 242 247 464 245 247 464 minecraft:brown_terracotta
fill 242 247 504 244 247 504 minecraft:brown_terracotta
setblock 245 247 465 minecraft:bone_block
setblock 246 247 464 minecraft:bone_block
fill 246 247 465 249 247 465 minecraft:brown_terracotta
fill 247 247 464 250 247 464 minecraft:brown_terracotta
fill 247 247 504 250 247 504 minecraft:brown_terracotta
setblock 250 247 465 minecraft:bone_block
setblock 251 247 464 minecraft:bone_block
fill 251 247 465 251 250 465 minecraft:brown_terracotta
setblock 251 247 504 minecraft:bone_block
fill 252 247 464 252 250 464 minecraft:brown_terracotta
setblock 252 247 503 minecraft:bone_block
fill 252 247 504 252 250 504 minecraft:brown_terracotta
fill 253 247 503 253 250 503 minecraft:brown_terracotta
setblock 254 247 466 minecraft:bone_block
setblock 255 247 465 minecraft:bone_block
fill 255 247 466 255 250 466 minecraft:brown_terracotta
setblock 256 247 464 minecraft:bone_block
fill 256 247 465 256 250 465 minecraft:brown_terracotta
setblock 256 247 504 minecraft:bone_block
fill 257 247 464 257 250 464 minecraft:brown_terracotta
setblock 257 247 503 minecraft:bone_block
fill 257 247 504 257 250 504 minecraft:brown_terracotta
setblock 258 247 466 minecraft:brown_terracotta
setblock 258 247 502 minecraft:bone_block
fill 258 247 503 258 250 503 minecraft:brown_terracotta
fill 259 247 502 259 248 502 minecraft:brown_terracotta
setblock 260 247 465 minecraft:bone_block
setblock 261 247 464 minecraft:bone_block
fill 261 247 465 261 250 465 minecraft:brown_terracotta
setblock 261 247 504 minecraft:bone_block
fill 262 247 464 262 250 464 minecraft:brown_terracotta
setblock 262 247 503 minecraft:bone_block
fill 262 247 504 265 247 504 minecraft:brown_terracotta
setblock 263 247 503 minecraft:brown_terracotta
setblock 266 247 504 minecraft:bone_block
fill 267 247 504 267 248 504 minecraft:brown_terracotta
setblock 271 247 504 minecraft:bone_block
fill 272 247 504 272 250 504 minecraft:brown_terracotta
fill 274 247 482 274 250 482 minecraft:brown_terracotta
setblock 274 247 486 minecraft:bone_block
fill 274 247 487 274 250 487 minecraft:brown_terracotta
fill 274 247 489 274 248 489 minecraft:brown_terracotta
setblock 275 247 480 minecraft:bone_block
fill 275 247 481 275 250 481 minecraft:brown_terracotta
setblock 275 247 485 minecraft:bone_block
fill 275 247 486 275 250 486 minecraft:brown_terracotta
setblock 275 247 490 minecraft:bone_block
fill 275 247 491 275 249 492 minecraft:brown_terracotta
setblock 276 247 464 minecraft:bone_block
fill 276 247 465 276 250 465 minecraft:brown_terracotta
setblock 276 247 469 minecraft:bone_block
fill 276 247 470 276 249 471 minecraft:brown_terracotta
setblock 276 247 474 minecraft:bone_block
fill 276 247 475 276 250 475 minecraft:brown_terracotta
setblock 276 247 479 minecraft:bone_block
fill 276 247 480 276 250 480 minecraft:brown_terracotta
setblock 276 247 484 minecraft:bone_block
fill 276 247 485 276 250 485 minecraft:brown_terracotta
setblock 276 247 489 minecraft:bone_block
fill 276 247 490 276 250 490 minecraft:brown_terracotta
setblock 276 247 494 minecraft:bone_block
fill 276 247 495 276 250 495 minecraft:brown_terracotta
setblock 276 247 499 minecraft:bone_block
fill 276 247 500 276 250 500 minecraft:brown_terracotta
setblock 276 247 504 minecraft:bone_block
fill 236 248 464 236 251 464 minecraft:brown_terracotta
setblock 236 248 468 minecraft:bone_block
fill 236 248 469 236 248 472 minecraft:brown_terracotta
setblock 236 248 473 minecraft:bone_block
fill 236 248 474 236 248 477 minecraft:brown_terracotta
setblock 236 248 478 minecraft:bone_block
fill 236 248 479 236 251 479 minecraft:brown_terracotta
setblock 236 248 483 minecraft:bone_block
fill 236 248 484 236 251 484 minecraft:brown_terracotta
setblock 236 248 488 minecraft:bone_block
fill 236 248 489 236 251 489 minecraft:brown_terracotta
setblock 236 248 493 minecraft:bone_block
setblock 236 248 503 minecraft:bone_block
fill 236 248 504 236 251 504 minecraft:brown_terracotta
setblock 237 248 467 minecraft:bone_block
fill 237 248 468 237 248 471 minecraft:brown_terracotta
setblock 237 248 472 minecraft:bone_block
fill 237 248 473 237 251 473 minecraft:brown_terracotta
setblock 237 248 477 minecraft:bone_block
fill 237 248 478 237 251 478 minecraft:brown_terracotta
setblock 237 248 482 minecraft:bone_block
fill 237 248 483 237 251 483 minecraft:brown_terracotta
setblock 237 248 487 minecraft:bone_block
fill 237 248 488 237 251 488 minecraft:brown_terracotta
setblock 238 248 466 minecraft:bone_block
fill 238 248 467 238 249 469 minecraft:brown_terracotta
setblock 238 248 474 minecraft:light[level=12]
setblock 238 248 481 minecraft:bone_block
fill 238 248 482 238 249 482 minecraft:brown_terracotta
setblock 238 248 486 minecraft:bone_block
fill 238 248 487 238 251 487 minecraft:brown_terracotta
setblock 238 248 490 minecraft:light[level=12]
setblock 238 248 498 minecraft:light[level=12]
setblock 239 248 465 minecraft:bone_block
fill 239 248 466 239 251 466 minecraft:brown_terracotta
setblock 240 248 464 minecraft:bone_block
fill 240 248 465 240 251 465 minecraft:brown_terracotta
setblock 240 248 504 minecraft:bone_block
fill 241 248 464 244 248 464 minecraft:brown_terracotta
fill 241 248 466 241 249 466 minecraft:brown_terracotta
fill 241 248 504 243 249 504 minecraft:brown_terracotta
setblock 244 248 465 minecraft:bone_block
setblock 245 248 464 minecraft:bone_block
fill 245 248 465 248 248 465 minecraft:brown_terracotta
fill 246 248 464 249 248 464 minecraft:brown_terracotta
setblock 246 248 466 minecraft:light[level=12]
setblock 246 248 474 minecraft:light[level=12]
setblock 246 248 482 minecraft:light[level=12]
setblock 246 248 490 minecraft:light[level=12]
setblock 246 248 498 minecraft:light[level=12]
fill 247 248 504 249 248 504 minecraft:brown_terracotta
setblock 249 248 465 minecraft:bone_block
setblock 250 248 464 minecraft:bone_block
fill 250 248 465 250 251 465 minecraft:brown_terracotta
setblock 250 248 504 minecraft:bone_block
fill 251 248 464 251 251 464 minecraft:brown_terracotta
setblock 251 248 503 minecraft:bone_block
fill 251 248 504 251 251 504 minecraft:brown_terracotta
setblock 252 248 466 minecraft:brown_terracotta
fill 252 248 503 252 251 503 minecraft:brown_terracotta
setblock 253 248 466 minecraft:bone_block
setblock 254 248 465 minecraft:bone_block
fill 254 248 466 254 251 466 minecraft:brown_terracotta
setblock 254 248 474 minecraft:light[level=12]
setblock 254 248 482 minecraft:light[level=12]
setblock 254 248 490 minecraft:light[level=12]
setblock 254 248 498 minecraft:light[level=12]
setblock 255 248 464 minecraft:bone_block
fill 255 248 465 255 251 465 minecraft:brown_terracotta
setblock 255 248 504 minecraft:bone_block
fill 256 248 464 256 251 464 minecraft:brown_terracotta
setblock 256 248 503 minecraft:bone_block
fill 256 248 504 256 251 504 minecraft:brown_terracotta
setblock 257 248 502 minecraft:bone_block
fill 257 248 503 257 251 503 minecraft:brown_terracotta
setblock 258 248 466 minecraft:bone_block
fill 258 248 502 258 250 502 minecraft:brown_terracotta
setblock 259 248 465 minecraft:bone_block
setblock 260 248 464 minecraft:bone_block
fill 260 248 465 260 251 465 minecraft:brown_terracotta
setblock 260 248 504 minecraft:bone_block
fill 261 248 464 261 251 464 minecraft:brown_terracotta
setblock 261 248 503 minecraft:bone_block
fill 261 248 504 264 248 504 minecraft:brown_terracotta
setblock 262 248 466 minecraft:light[level=12]
setblock 262 248 474 minecraft:light[level=12]
setblock 262 248 482 minecraft:light[level=12]
setblock 262 248 490 minecraft:light[level=12]
setblock 262 248 498 minecraft:light[level=12]
fill 262 248 503 262 249 503 minecraft:brown_terracotta
setblock 265 248 504 minecraft:bone_block
fill 266 248 504 266 249 504 minecraft:brown_terracotta
setblock 270 248 466 minecraft:light[level=12]
setblock 270 248 474 minecraft:light[level=12]
setblock 270 248 482 minecraft:light[level=12]
setblock 270 248 490 minecraft:light[level=12]
setblock 270 248 498 minecraft:light[level=12]
setblock 270 248 504 minecraft:bone_block
fill 271 248 464 272 250 464 minecraft:brown_terracotta
fill 271 248 504 271 251 504 minecraft:brown_terracotta
setblock 274 248 485 minecraft:bone_block
fill 274 248 486 274 251 486 minecraft:brown_terracotta
setblock 274 248 490 minecraft:bone_block
setblock 275 248 464 minecraft:bone_block
fill 275 248 465 275 249 467 minecraft:brown_terracotta
setblock 275 248 478 minecraft:brown_terracotta
setblock 275 248 479 minecraft:bone_block
fill 275 248 480 275 251 480 minecraft:brown_terracotta
setblock 275 248 484 minecraft:bone_block
fill 275 248 485 275 251 485 minecraft:brown_terracotta
setblock 275 248 489 minecraft:bone_block
fill 275 248 490 275 251 490 minecraft:brown_terracotta
setblock 275 248 493 minecraft:brown_terracotta
setblock 275 248 504 minecraft:bone_block
fill 276 248 464 276 251 464 minecraft:brown_terracotta
setblock 276 248 468 minecraft:bone_block
fill 276 248 469 276 251 469 minecraft:brown_terracotta
setblock 276 248 472 minecraft:brown_terracotta
setblock 276 248 473 minecraft:bone_block
fill 276 248 474 276 251 474 minecraft:brown_terracotta
setblock 276 248 478 minecraft:bone_block
fill 276 248 479 276 251 479 minecraft:brown_terracotta
setblock 276 248 483 minecraft:bone_block
fill 276 248 484 276 251 484 minecraft:brown_terracotta
setblock 276 248 488 minecraft:bone_block
fill 276 248 489 276 251 489 minecraft:brown_terracotta
setblock 276 248 493 minecraft:bone_block
fill 276 248 494 276 251 494 minecraft:brown_terracotta
setblock 276 248 498 minecraft:bone_block
fill 276 248 499 276 251 499 minecraft:brown_terracotta
setblock 276 248 503 minecraft:bone_block
fill 276 248 504 276 251 504 minecraft:brown_terracotta
setblock 236 249 467 minecraft:bone_block
fill 236 249 468 236 249 471 minecraft:brown_terracotta
setblock 236 249 472 minecraft:bone_block
fill 236 249 473 236 249 476 minecraft:brown_terracotta
setblock 236 249 477 minecraft:bone_block
fill 236 249 478 236 252 478 minecraft:brown_terracotta
setblock 236 249 482 minecraft:bone_block
fill 236 249 483 236 252 483 minecraft:brown_terracotta
setblock 236 249 487 minecraft:bone_block
fill 236 249 488 236 252 488 minecraft:brown_terracotta
setblock 236 249 491 minecraft:brown_terracotta
setblock 236 249 492 minecraft:bone_block
fill 236 249 493 236 251 494 minecraft:brown_terracotta
setblock 236 249 502 minecraft:bone_block
fill 236 249 503 236 252 503 minecraft:brown_terracotta
setblock 237 249 466 minecraft:bone_block
fill 237 249 467 237 249 470 minecraft:brown_terracotta
setblock 237 249 471 minecraft:bone_block
fill 237 249 472 237 252 472 minecraft:brown_terracotta
setblock 237 249 476 minecraft:bone_block
fill 237 249 477 237 252 477 minecraft:brown_terracotta
setblock 237 249 481 minecraft:bone_block
fill 237 249 482 237 252 482 minecraft:brown_terracotta
setblock 237 249 486 minecraft:bone_block
fill 237 249 487 237 252 487 minecraft:brown_terracotta
setblock 237 249 491 minecraft:bone_block
setblock 238 249 465 minecraft:bone_block
fill 238 249 466 238 252 466 minecraft:brown_terracotta
setblock 238 249 470 minecraft:bone_block
setblock 238 249 485 minecraft:bone_block
fill 238 249 486 238 251 486 minecraft:brown_terracotta
setblock 239 249 464 minecraft:bone_block
fill 239 249 465 239 252 465 minecraft:brown_terracotta
setblock 239 249 504 minecraft:bone_block
fill 240 249 464 243 249 464 minecraft:brown_terracotta
fill 240 249 504 240 252 504 minecraft:brown_terracotta
setblock 243 249 465 minecraft:bone_block
setblock 244 249 464 minecraft:bone_block
fill 244 249 465 247 249 465 minecraft:brown_terracotta
fill 245 249 464 248 249 464 minecraft:brown_terracotta
fill 246 249 504 248 249 504 minecraft:brown_terracotta
setblock 248 249 465 minecraft:bone_block
setblock 249 249 464 minecraft:bone_block
fill 249 249 465 249 252 465 minecraft:brown_terracotta
setblock 249 249 504 minecraft:bone_block
fill 250 249 464 250 252 464 minecraft:brown_terracotta
fill 250 249 466 251 249 466 minecraft:brown_terracotta
fill 250 249 504 250 252 504 minecraft:brown_terracotta
fill 251 249 503 251 252 503 minecraft:brown_terracotta
setblock 252 249 466 minecraft:bone_block
setblock 253 249 465 minecraft:bone_block
fill 253 249 466 253 252 466 minecraft:brown_terracotta
setblock 254 249 464 minecraft:bone_block
fill 254 249 465 254 252 465 minecraft:brown_terracotta
fill 254 249 502 254 250 502 minecraft:brown_terracotta
setblock 254 249 504 minecraft:bone_block
fill 255 249 464 255 252 464 minecraft:brown_terracotta
setblock 255 249 503 minecraft:bone_block
fill 255 249 504 255 252 504 minecraft:brown_terracotta
setblock 256 249 502 minecraft:bone_block
fill 256 249 503 256 252 503 minecraft:brown_terracotta
setblock 257 249 466 minecraft:bone_block
fill 257 249 502 257 252 502 minecraft:brown_terracotta
setblock 258 249 465 minecraft:bone_block
fill 258 249 466 258 252 466 minecraft:brown_terracotta
setblock 259 249 464 minecraft:bone_block
fill 259 249 465 259 252 465 minecraft:brown_terracotta
setblock 259 249 504 minecraft:bone_block
fill 260 249 464 260 252 464 minecraft:brown_terracotta
setblock 260 249 503 minecraft:bone_block
fill 260 249 504 263 249 504 minecraft:brown_terracotta
fill 261 249 503 261 251 503 minecraft:brown_terracotta
setblock 264 249 464 minecraft:bone_block
setblock 264 249 504 minecraft:bone_block
fill 265 249 504 265 251 504 minecraft:brown_terracotta
setblock 269 249 504 minecraft:bone_block
fill 270 249 464 270 252 464 minecraft:brown_terracotta
fill 270 249 504 270 252 504 minecraft:brown_terracotta
setblock 273 249 465 minecraft:bone_block
setblock 273 249 485 minecraft:bone_block
fill 273 249 486 273 250 488 minecraft:brown_terracotta
setblock 274 249 464 minecraft:bone_block
fill 274 249 465 274 252 465 minecraft:brown_terracotta
fill 274 249 481 274 251 481 minecraft:brown_terracotta
setblock 274 249 484 minecraft:bone_block
fill 274 249 485 274 252 485 minecraft:brown_terracotta
setblock 274 249 489 minecraft:bone_block
fill 274 249 490 274 251 491 minecraft:brown_terracotta
setblock 274 249 504 minecraft:bone_block
fill 275 249 464 275 252 464 minecraft:brown_terracotta
setblock 275 249 468 minecraft:bone_block
fill 275 249 469 275 251 470 minecraft:brown_terracotta
setblock 275 249 478 minecraft:bone_block
fill 275 249 479 275 252 479 minecraft:brown_terracotta
setblock 275 249 483 minecraft:bone_block
fill 275 249 484 275 252 484 minecraft:brown_terracotta
setblock 275 249 488 minecraft:bone_block
fill 275 249 489 275 252 489 minecraft:brown_terracotta
setblock 275 249 493 minecraft:bone_block
fill 275 249 494 275 252 494 minecraft:brown_terracotta
fill 275 249 504 275 252 504 minecraft:brown_terracotta
setblock 276 249 467 minecraft:bone_block
fill 276 249 468 276 252 468 minecraft:brown_terracotta
setblock 276 249 472 minecraft:bone_block
fill 276 249 473 276 252 473 minecraft:brown_terracotta
setblock 276 249 477 minecraft:bone_block
fill 276 249 478 276 252 478 minecraft:brown_terracotta
setblock 276 249 482 minecraft:bone_block
fill 276 249 483 276 252 483 minecraft:brown_terracotta
setblock 276 249 487 minecraft:bone_block
fill 276 249 488 276 252 488 minecraft:brown_terracotta
setblock 276 249 492 minecraft:bone_block
fill 276 249 493 276 252 493 minecraft:brown_terracotta
setblock 276 249 497 minecraft:bone_block
fill 276 249 498 276 252 498 minecraft:brown_terracotta
setblock 276 249 502 minecraft:bone_block
fill 276 249 503 276 252 503 minecraft:brown_terracotta
setblock 236 250 466 minecraft:bone_block
fill 236 250 467 236 250 470 minecraft:brown_terracotta
setblock 236 250 471 minecraft:bone_block
fill 236 250 472 236 250 475 minecraft:brown_terracotta
setblock 236 250 476 minecraft:bone_block
fill 236 250 477 236 253 477 minecraft:brown_terracotta
setblock 236 250 481 minecraft:bone_block
fill 236 250 482 236 253 482 minecraft:brown_terracotta
setblock 236 250 486 minecraft:bone_block
fill 236 250 487 236 253 487 minecraft:brown_terracotta
setblock 236 250 490 minecraft:brown_terracotta
setblock 236 250 491 minecraft:bone_block
fill 236 250 492 236 253 492 minecraft:brown_terracotta
setblock 236 250 495 minecraft:brown_terracotta
fill 236 250 502 236 253 502 minecraft:brown_terracotta
setblock 237 250 465 minecraft:bone_block
fill 237 250 466 237 250 469 minecraft:brown_terracotta
setblock 237 250 470 minecraft:bone_block
fill 237 250 471 238 252 471 minecraft:brown_terracotta
setblock 237 250 475 minecraft:bone_block
fill 237 250 476 237 253 476 minecraft:brown_terracotta
setblock 237 250 480 minecraft:bone_block
fill 237 250 481 237 253 481 minecraft:brown_terracotta
setblock 237 250 485 minecraft:bone_block
fill 237 250 486 237 253 486 minecraft:brown_terracotta
setblock 237 250 490 minecraft:bone_block
fill 237 250 491 237 253 491 minecraft:brown_terracotta
setblock 238 250 464 minecraft:bone_block
fill 238 250 465 238 253 465 minecraft:brown_terracotta
fill 238 250 467 238 250 468 minecraft:brown_terracotta
setblock 238 250 469 minecraft:bone_block
fill 238 250 470 238 253 470 minecraft:brown_terracotta
fill 238 250 472 238 251 472 minecraft:brown_terracotta
setblock 238 250 484 minecraft:bone_block
fill 238 250 485 238 251 485 minecraft:brown_terracotta
setblock 238 250 488 minecraft:brown_terracotta
setblock 238 250 504 minecraft:bone_block
fill 239 250 464 242 250 464 minecraft:brown_terracotta
fill 239 250 504 239 253 504 minecraft:brown_terracotta
setblock 241 250 466 minecraft:bone_block
fill 241 250 504 242 250 504 minecraft:brown_terracotta
setblock 242 250 465 minecraft:bone_block
fill 242 250 466 242 253 466 minecraft:brown_terracotta
setblock 243 250 464 minecraft:bone_block
fill 243 250 465 246 250 465 minecraft:brown_terracotta
fill 244 250 464 247 250 464 minecraft:brown_terracotta
fill 245 250 504 247 250 504 minecraft:brown_terracotta
setblock 247 250 465 minecraft:bone_block
setblock 248 250 464 minecraft:bone_block
fill 248 250 465 248 252 466 minecraft:brown_terracotta
fill 248 250 502 248 256 502 minecraft:soul_soil
setblock 248 250 504 minecraft:bone_block
fill 249 250 464 249 253 464 minecraft:brown_terracotta
fill 249 250 466 250 250 466 minecraft:brown_terracotta
fill 249 250 504 249 253 504 minecraft:brown_terracotta
fill 250 250 503 250 253 503 minecraft:brown_terracotta
setblock 251 250 466 minecraft:bone_block
setblock 252 250 465 minecraft:bone_block
fill 252 250 466 252 253 466 minecraft:brown_terracotta
setblock 253 250 464 minecraft:bone_block
fill 253 250 465 253 253 465 minecraft:brown_terracotta
setblock 253 250 504 minecraft:bone_block
fill 254 250 464 254 253 464 minecraft:brown_terracotta
setblock 254 250 503 minecraft:bone_block
fill 254 250 504 254 253 504 minecraft:brown_terracotta
setblock 255 250 502 minecraft:bone_block
fill 255 250 503 255 253 503 minecraft:brown_terracotta
setblock 256 250 466 minecraft:bone_block
fill 256 250 502 256 253 502 minecraft:brown_terracotta
setblock 257 250 465 minecraft:bone_block
fill 257 250 466 257 253 466 minecraft:brown_terracotta
setblock 258 250 464 minecraft:bone_block
fill 258 250 465 258 253 465 minecraft:brown_terracotta
setblock 258 250 504 minecraft:bone_block
fill 259 250 464 259 253 464 minecraft:brown_terracotta
setblock 259 250 503 minecraft:bone_block
fill 259 250 504 262 250 504 minecraft:brown_terracotta
fill 260 250 503 260 252 503 minecraft:brown_terracotta
setblock 263 250 464 minecraft:bone_block
setblock 263 250 504 minecraft:bone_block
setblock 264 250 464 minecraft:brown_terracotta
fill 264 250 504 264 252 504 minecraft:brown_terracotta
fill 269 250 464 269 253 464 minecraft:brown_terracotta
fill 269 250 504 269 253 504 minecraft:brown_terracotta
setblock 272 250 465 minecraft:bone_block
setblock 273 250 464 minecraft:bone_block
fill 273 250 465 273 253 465 minecraft:brown_terracotta
setblock 273 250 484 minecraft:bone_block
fill 273 250 485 273 253 485 minecraft:brown_terracotta
setblock 273 250 489 minecraft:bone_block
fill 273 250 490 273 253 490 minecraft:brown_terracotta
setblock 273 250 504 minecraft:bone_block
fill 274 250 464 274 253 464 minecraft:brown_terracotta
setblock 274 250 483 minecraft:bone_block
fill 274 250 484 274 253 484 minecraft:brown_terracotta
setblock 274 250 488 minecraft:bone_block
fill 274 250 489 274 253 489 minecraft:brown_terracotta
setblock 274 250 492 minecraft:brown_terracotta
setblock 274 250 493 minecraft:bone_block
fill 274 250 504 274 253 504 minecraft:brown_terracotta
fill 275 250 465 275 250 466 minecraft:brown_terracotta
setblock 275 250 467 minecraft:bone_block
fill 275 250 468 275 253 468 minecraft:brown_terracotta
setblock 275 250 471 minecraft:brown_terracotta
setblock 275 250 472 minecraft:bone_block
fill 275 250 473 275 250 476 minecraft:brown_terracotta
setblock 275 250 477 minecraft:bone_block
fill 275 250 478 275 253 478 minecraft:brown_terracotta
setblock 275 250 482 minecraft:bone_block
fill 275 250 483 275 253 483 minecraft:brown_terracotta
setblock 275 250 487 minecraft:bone_block
fill 275 250 488 275 253 488 minecraft:brown_terracotta
setblock 275 250 491 minecraft:brown_terracotta
setblock 275 250 492 minecraft:bone_block
fill 275 250 493 275 253 493 minecraft:brown_terracotta
fill 275 250 495 275 251 495 minecraft:brown_terracotta
setblock 276 250 466 minecraft:bone_block
fill 276 250 467 276 253 467 minecraft:brown_terracotta
setblock 276 250 470 minecraft:brown_terracotta
setblock 276 250 471 minecraft:bone_block
fill 276 250 472 276 253 472 minecraft:brown_terracotta
setblock 276 250 476 minecraft:bone_block
fill 276 250 477 276 253 477 minecraft:brown_terracotta
setblock 276 250 481 minecraft:bone_block
fill 276 250 482 276 253 482 minecraft:brown_terracotta
setblock 276 250 486 minecraft:bone_block
fill 276 250 487 276 253 487 minecraft:brown_terracotta
setblock 276 250 491 minecraft:bone_block
fill 276 250 492 276 253 492 minecraft:brown_terracotta
setblock 276 250 496 minecraft:bone_block
fill 276 250 497 276 253 497 minecraft:brown_terracotta
setblock 276 250 501 minecraft:bone_block
fill 276 250 502 276 253 502 minecraft:brown_terracotta
setblock 236 251 465 minecraft:bone_block
fill 236 251 466 236 251 469 minecraft:brown_terracotta
setblock 236 251 470 minecraft:bone_block
fill 236 251 471 236 251 474 minecraft:brown_terracotta
setblock 236 251 475 minecraft:bone_block
fill 236 251 476 236 254 476 minecraft:brown_terracotta
setblock 236 251 480 minecraft:bone_block
fill 236 251 481 236 254 481 minecraft:brown_terracotta
setblock 236 251 485 minecraft:bone_block
fill 236 251 486 236 254 486 minecraft:brown_terracotta
setblock 236 251 490 minecraft:bone_block
fill 236 251 491 236 254 491 minecraft:brown_terracotta
setblock 236 251 495 minecraft:bone_block
fill 236 251 496 236 254 496 minecraft:brown_terracotta
setblock 237 251 464 minecraft:bone_block
fill 237 251 465 237 251 468 minecraft:brown_terracotta
setblock 237 251 469 minecraft:bone_block
fill 237 251 470 237 254 470 minecraft:brown_terracotta
setblock 237 251 474 minecraft:bone_block
fill 237 251 475 237 254 475 minecraft:brown_terracotta
setblock 237 251 479 minecraft:bone_block
fill 237 251 480 237 253 480 minecraft:brown_terracotta
setblock 237 251 484 minecraft:bone_block
fill 237 251 485 237 254 485 minecraft:brown_terracotta
setblock 237 251 489 minecraft:bone_block
fill 237 251 490 237 254 490 minecraft:brown_terracotta
fill 237 251 492 237 252 492 minecraft:brown_terracotta
setblock 237 251 504 minecraft:bone_block
fill 238 251 464 241 251 464 minecraft:brown_terracotta
setblock 238 251 467 minecraft:brown_terracotta
setblock 238 251 468 minecraft:bone_block
fill 238 251 469 238 254 469 minecraft:brown_terracotta
setblock 238 251 473 minecraft:bone_block
setblock 238 251 488 minecraft:bone_block
fill 238 251 504 238 254 504 minecraft:brown_terracotta
setblock 239 251 467 minecraft:bone_block
fill 239 251 468 239 253 468 minecraft:brown_terracotta
fill 239 251 492 240 252 493 minecraft:bone_block
setblock 240 251 466 minecraft:bone_block
setblock 241 251 465 minecraft:bone_block
fill 241 251 466 241 254 466 minecraft:brown_terracotta
setblock 241 251 504 minecraft:brown_terracotta
setblock 242 251 464 minecraft:bone_block
fill 242 251 465 245 251 465 minecraft:brown_terracotta
setblock 242 251 504 minecraft:bone_block
fill 243 251 464 246 251 464 minecraft:brown_terracotta
fill 243 251 466 243 252 466 minecraft:brown_terracotta
fill 245 251 504 246 251 504 minecraft:brown_terracotta
setblock 246 251 465 minecraft:bone_block
fill 246 251 466 247 253 466 minecraft:brown_terracotta
setblock 247 251 464 minecraft:bone_block
fill 247 251 465 247 254 465 minecraft:brown_terracotta
setblock 247 251 504 minecraft:bone_block
fill 248 251 464 248 254 464 minecraft:brown_terracotta
fill 248 251 504 248 254 504 minecraft:brown_terracotta
setblock 249 251 466 minecraft:brown_terracotta
setblock 250 251 466 minecraft:bone_block
setblock 251 251 465 minecraft:bone_block
fill 251 251 466 251 254 466 minecraft:brown_terracotta
setblock 252 251 464 minecraft:bone_block
fill 252 251 465 252 254 465 minecraft:brown_terracotta
fill 252 251 467 253 251 467 minecraft:brown_terracotta
setblock 252 251 504 minecraft:bone_block
fill 253 251 464 253 254 464 minecraft:brown_terracotta
setblock 253 251 502 minecraft:brown_terracotta
setblock 253 251 503 minecraft:bone_block
fill 253 251 504 253 254 504 minecraft:brown_terracotta
setblock 254 251 467 minecraft:bone_block
setblock 254 251 502 minecraft:bone_block
fill 254 251 503 254 254 503 minecraft:brown_terracotta
setblock 255 251 466 minecraft:bone_block
fill 255 251 467 255 253 467 minecraft:brown_terracotta
fill 255 251 502 255 254 502 minecraft:brown_terracotta
setblock 256 251 465 minecraft:bone_block
fill 256 251 466 256 254 466 minecraft:brown_terracotta
setblock 257 251 464 minecraft:bone_block
fill 257 251 465 257 254 465 minecraft:brown_terracotta
setblock 257 251 504 minecraft:bone_block
fill 258 251 464 258 254 464 minecraft:brown_terracotta
setblock 258 251 503 minecraft:bone_block
fill 258 251 504 261 251 504 minecraft:brown_terracotta
fill 259 251 503 259 253 503 minecraft:brown_terracotta
setblock 261 251 465 minecraft:bone_block
setblock 262 251 464 minecraft:bone_block
setblock 262 251 504 minecraft:bone_block
fill 263 251 464 263 252 464 minecraft:brown_terracotta
fill 263 251 504 263 252 504 minecraft:brown_terracotta
fill 268 251 464 268 254 464 minecraft:brown_terracotta
fill 268 251 504 268 252 504 minecraft:brown_terracotta
setblock 271 251 464 minecraft:brown_terracotta
setblock 271 251 465 minecraft:bone_block
setblock 272 251 464 minecraft:bone_block
fill 272 251 465 272 254 465 minecraft:brown_terracotta
setblock 272 251 504 minecraft:bone_block
fill 273 251 464 273 254 464 minecraft:brown_terracotta
fill 273 251 484 273 254 484 minecraft:brown_terracotta
fill 273 251 486 273 251 487 minecraft:brown_terracotta
setblock 273 251 488 minecraft:bone_block
fill 273 251 489 273 254 489 minecraft:brown_terracotta
fill 273 251 491 273 252 491 minecraft:brown_terracotta
fill 273 251 504 273 254 504 minecraft:brown_terracotta
setblock 274 251 466 minecraft:brown_terracotta
setblock 274 251 467 minecraft:bone_block
fill 274 251 468 274 252 470 minecraft:brown_terracotta
fill 274 251 480 274 252 480 minecraft:brown_terracotta
setblock 274 251 482 minecraft:bone_block
fill 274 251 483 274 254 483 minecraft:brown_terracotta
setblock 274 251 487 minecraft:bone_block
fill 274 251 488 274 254 488 minecraft:brown_terracotta
setblock 274 251 492 minecraft:bone_block
fill 274 251 493 274 253 494 minecraft:brown_terracotta
setblock 275 251 465 minecraft:brown_terracotta
setblock 275 251 466 minecraft:bone_block
fill 275 251 467 275 254 467 minecraft:brown_terracotta
setblock 275 251 471 minecraft:bone_block
fill 275 251 472 275 251 475 minecraft:brown_terracotta
setblock 275 251 476 minecraft:bone_block
fill 275 251 477 275 254 477 minecraft:brown_terracotta
setblock 275 251 481 minecraft:bone_block
fill 275 251 482 275 254 482 minecraft:brown_terracotta
setblock 275 251 486 minecraft:bone_block
fill 275 251 487 275 254 487 minecraft:brown_terracotta
setblock 275 251 491 minecraft:bone_block
fill 275 251 492 275 254 492 minecraft:brown_terracotta
setblock 275 251 496 minecraft:bone_block
setblock 276 251 465 minecraft:bone_block
fill 276 251 466 276 254 466 minecraft:brown_terracotta
setblock 276 251 470 minecraft:bone_block
fill 276 251 471 276 254 471 minecraft:brown_terracotta
setblock 276 251 475 minecraft:bone_block
fill 276 251 476 276 254 476 minecraft:brown_terracotta
setblock 276 251 480 minecraft:bone_block
fill 276 251 481 276 254 481 minecraft:brown_terracotta
setblock 276 251 485 minecraft:bone_block
fill 276 251 486 276 254 486 minecraft:brown_terracotta
setblock 276 251 490 minecraft:bone_block
fill 276 251 491 276 254 491 minecraft:brown_terracotta
setblock 276 251 495 minecraft:bone_block
fill 276 251 496 276 254 496 minecraft:brown_terracotta
setblock 276 251 500 minecraft:bone_block
fill 276 251 501 276 253 501 minecraft:brown_terracotta
setblock 236 252 464 minecraft:bone_block
fill 236 252 465 236 252 468 minecraft:brown_terracotta
setblock 236 252 469 minecraft:bone_block
fill 236 252 470 236 252 473 minecraft:brown_terracotta
setblock 236 252 474 minecraft:bone_block
fill 236 252 475 236 255 475 minecraft:brown_terracotta
setblock 236 252 479 minecraft:bone_block
fill 236 252 480 236 255 480 minecraft:brown_terracotta
setblock 236 252 484 minecraft:bone_block
fill 236 252 485 236 255 485 minecraft:brown_terracotta
setblock 236 252 489 minecraft:bone_block
fill 236 252 490 236 255 490 minecraft:brown_terracotta
setblock 236 252 493 minecraft:brown_terracotta
setblock 236 252 494 minecraft:bone_block
fill 236 252 495 236 255 495 minecraft:brown_terracotta
fill 236 252 497 236 253 497 minecraft:brown_terracotta
setblock 236 252 504 minecraft:bone_block
fill 237 252 464 237 252 467 minecraft:brown_terracotta
setblock 237 252 468 minecraft:bone_block
fill 237 252 469 237 255 469 minecraft:brown_terracotta
setblock 237 252 473 minecraft:bone_block
fill 237 252 474 237 255 474 minecraft:brown_terracotta
setblock 237 252 478 minecraft:bone_block
fill 237 252 479 237 253 479 minecraft:brown_terracotta
setblock 237 252 483 minecraft:bone_block
fill 237 252 484 237 254 484 minecraft:brown_terracotta
setblock 237 252 488 minecraft:bone_block
fill 237 252 489 237 255 489 minecraft:brown_terracotta
setblock 237 252 493 minecraft:bone_block
fill 237 252 504 237 254 504 minecraft:brown_terracotta
fill 238 252 464 240 252 464 minecraft:brown_terracotta
setblock 238 252 467 minecraft:bone_block
fill 238 252 468 238 255 468 minecraft:brown_terracotta
setblock 238 252 472 minecraft:bone_block
fill 238 252 473 238 255 473 minecraft:brown_terracotta
setblock 239 252 466 minecraft:bone_block
fill 239 252 467 239 253 467 minecraft:brown_terracotta
fill 239 252 469 239 253 469 minecraft:brown_terracotta
setblock 240 252 465 minecraft:bone_block
fill 240 252 466 240 255 466 minecraft:brown_terracotta
setblock 241 252 464 minecraft:bone_block
fill 241 252 465 244 252 465 minecraft:brown_terracotta
setblock 241 252 504 minecraft:bone_block
fill 242 252 464 245 252 464 minecraft:brown_terracotta
setblock 244 252 466 minecraft:bone_block
setblock 245 252 465 minecraft:bone_block
fill 245 252 466 245 254 466 minecraft:brown_terracotta
setblock 245 252 504 minecraft:brown_terracotta
setblock 246 252 464 minecraft:bone_block
fill 246 252 465 246 255 465 minecraft:brown_terracotta
setblock 246 252 504 minecraft:bone_block
fill 247 252 464 247 255 464 minecraft:brown_terracotta
fill 247 252 504 247 255 504 minecraft:brown_terracotta
setblock 249 252 466 minecraft:bone_block
fill 249 252 503 249 254 503 minecraft:brown_terracotta
setblock 250 252 465 minecraft:bone_block
fill 250 252 466 250 254 467 minecraft:brown_terracotta
setblock 251 252 464 minecraft:bone_block
fill 251 252 465 251 255 465 minecraft:brown_terracotta
fill 251 252 467 252 252 467 minecraft:brown_terracotta
setblock 251 252 504 minecraft:bone_block
fill 252 252 464 252 255 464 minecraft:brown_terracotta
setblock 252 252 502 minecraft:brown_terracotta
setblock 252 252 503 minecraft:bone_block
fill 252 252 504 252 255 504 minecraft:brown_terracotta
setblock 253 252 467 minecraft:bone_block
setblock 253 252 502 minecraft:bone_block
fill 253 252 503 253 255 503 minecraft:brown_terracotta
setblock 254 252 466 minecraft:bone_block
fill 254 252 467 254 254 467 minecraft:brown_terracotta
fill 254 252 502 254 255 502 minecraft:brown_terracotta
setblock 255 252 465 minecraft:bone_block
fill 255 252 466 255 255 466 minecraft:brown_terracotta
setblock 256 252 464 minecraft:bone_block
fill 256 252 465 256 255 465 minecraft:brown_terracotta
setblock 256 252 504 minecraft:bone_block
fill 257 252 464 257 255 464 minecraft:brown_terracotta
setblock 257 252 503 minecraft:bone_block
fill 257 252 504 260 252 504 minecraft:brown_terracotta
fill 258 252 503 258 254 503 minecraft:brown_terracotta
setblock 260 252 465 minecraft:bone_block
setblock 261 252 464 minecraft:bone_block
setblock 261 252 504 minecraft:bone_block
fill 262 252 464 262 253 464 minecraft:brown_terracotta
fill 262 252 504 262 253 504 minecraft:brown_terracotta
setblock 270 252 465 minecraft:bone_block
setblock 271 252 464 minecraft:bone_block
fill 271 252 465 271 255 465 minecraft:brown_terracotta
setblock 271 252 504 minecraft:bone_block
fill 272 252 464 272 255 464 minecraft:brown_terracotta
fill 272 252 504 272 255 504 minecraft:brown_terracotta
setblock 273 252 466 minecraft:brown_terracotta
fill 273 252 483 273 253 483 minecraft:brown_terracotta
setblock 273 252 486 minecraft:brown_terracotta
setblock 273 252 487 minecraft:bone_block
fill 273 252 488 273 255 488 minecraft:brown_terracotta
setblock 273 252 492 minecraft:bone_block
setblock 274 252 466 minecraft:bone_block
fill 274 252 467 274 255 467 minecraft:brown_terracotta
setblock 274 252 471 minecraft:bone_block
fill 274 252 472 275 253 473 minecraft:brown_terracotta
setblock 274 252 481 minecraft:bone_block
fill 274 252 482 274 255 482 minecraft:brown_terracotta
setblock 274 252 486 minecraft:bone_block
fill 274 252 487 274 255 487 minecraft:brown_terracotta
setblock 274 252 490 minecraft:brown_terracotta
setblock 274 252 491 minecraft:bone_block
fill 274 252 492 274 255 492 minecraft:brown_terracotta
setblock 275 252 465 minecraft:bone_block
fill 275 252 466 275 255 466 minecraft:brown_terracotta
setblock 275 252 469 minecraft:brown_terracotta
setblock 275 252 470 minecraft:bone_block
fill 275 252 471 275 255 471 minecraft:brown_terracotta
setblock 275 252 474 minecraft:brown_terracotta
setblock 275 252 475 minecraft:bone_block
fill 275 252 476 275 255 476 minecraft:brown_terracotta
setblock 275 252 480 minecraft:bone_block
fill 275 252 481 275 255 481 minecraft:brown_terracotta
setblock 275 252 485 minecraft:bone_block
fill 275 252 486 275 255 486 minecraft:brown_terracotta
setblock 275 252 490 minecraft:bone_block
fill 275 252 491 275 255 491 minecraft:brown_terracotta
setblock 275 252 495 minecraft:bone_block
fill 275 252 496 275 254 497 minecraft:brown_terracotta
setblock 276 252 464 minecraft:bone_block
fill 276 252 465 276 255 465 minecraft:brown_terracotta
setblock 276 252 469 minecraft:bone_block
fill 276 252 470 276 255 470 minecraft:brown_terracotta
setblock 276 252 474 minecraft:bone_block
fill 276 252 475 276 255 475 minecraft:brown_terracotta
setblock 276 252 479 minecraft:bone_block
fill 276 252 480 276 255 480 minecraft:brown_terracotta
setblock 276 252 484 minecraft:bone_block
fill 276 252 485 276 255 485 minecraft:brown_terracotta
setblock 276 252 489 minecraft:bone_block
fill 276 252 490 276 255 490 minecraft:brown_terracotta
setblock 276 252 494 minecraft:bone_block
fill 276 252 495 276 255 495 minecraft:brown_terracotta
setblock 276 252 499 minecraft:bone_block
fill 276 252 500 276 253 500 minecraft:brown_terracotta
setblock 276 252 504 minecraft:bone_block
fill 236 253 464 236 253 467 minecraft:brown_terracotta
setblock 236 253 468 minecraft:bone_block
fill 236 253 469 236 253 472 minecraft:brown_terracotta
setblock 236 253 473 minecraft:bone_block
fill 236 253 474 236 256 474 minecraft:brown_terracotta
setblock 236 253 478 minecraft:bone_block
fill 236 253 479 236 256 479 minecraft:brown_terracotta
setblock 236 253 483 minecraft:bone_block
fill 236 253 484 236 256 484 minecraft:brown_terracotta
setblock 236 253 488 minecraft:bone_block
fill 236 253 489 236 256 489 minecraft:brown_terracotta
setblock 236 253 493 minecraft:bone_block
fill 236 253 494 236 256 494 minecraft:brown_terracotta
setblock 236 253 503 minecraft:bone_block
fill 236 253 504 236 255 504 minecraft:brown_terracotta
fill 237 253 464 237 253 466 minecraft:brown_terracotta
setblock 237 253 467 minecraft:bone_block
fill 237 253 468 237 256 468 minecraft:brown_terracotta
setblock 237 253 471 minecraft:brown_terracotta
setblock 237 253 472 minecraft:bone_block
fill 237 253 473 237 256 473 minecraft:brown_terracotta
setblock 237 253 477 minecraft:bone_block
fill 237 253 478 237 254 478 minecraft:brown_terracotta
setblock 237 253 482 minecraft:bone_block
fill 237 253 483 237 254 483 minecraft:brown_terracotta
setblock 237 253 487 minecraft:bone_block
fill 237 253 488 237 255 488 minecraft:brown_terracotta
setblock 237 253 492 minecraft:bone_block
fill 237 253 493 237 254 493 minecraft:brown_terracotta
fill 238 253 464 239 253 464 minecraft:brown_terracotta
setblock 238 253 466 minecraft:bone_block
fill 238 253 467 238 256 467 minecraft:brown_terracotta
setblock 238 253 471 minecraft:bone_block
fill 238 253 472 238 256 472 minecraft:brown_terracotta
fill 238 253 474 238 254 474 minecraft:brown_terracotta
setblock 239 253 465 minecraft:bone_block
fill 239 253 466 239 255 466 minecraft:brown_terracotta
setblock 240 253 464 minecraft:bone_block
fill 240 253 465 243 253 465 minecraft:brown_terracotta
setblock 240 253 504 minecraft:bone_block
fill 241 253 464 244 253 464 minecraft:brown_terracotta
setblock 243 253 466 minecraft:bone_block
setblock 244 253 465 minecraft:bone_block
fill 244 253 466 244 254 466 minecraft:brown_terracotta
setblock 245 253 464 minecraft:bone_block
fill 245 253 465 245 256 465 minecraft:brown_terracotta
setblock 245 253 504 minecraft:bone_block
fill 246 253 464 246 256 464 minecraft:brown_terracotta
fill 246 253 504 246 256 504 minecraft:brown_terracotta
setblock 248 253 465 minecraft:brown_terracotta
setblock 248 253 466 minecraft:bone_block
setblock 249 253 465 minecraft:bone_block
fill 249 253 466 249 254 467 minecraft:brown_terracotta
setblock 250 253 464 minecraft:bone_block
fill 250 253 465 250 256 465 minecraft:brown_terracotta
setblock 250 253 504 minecraft:bone_block
fill 251 253 464 251 256 464 minecraft:brown_terracotta
setblock 251 253 467 minecraft:brown_terracotta
setblock 251 253 503 minecraft:bone_block
fill 251 253 504 251 256 504 minecraft:brown_terracotta
setblock 252 253 467 minecraft:bone_block
setblock 252 253 502 minecraft:bone_block
fill 252 253 503 252 256 503 minecraft:brown_terracotta
setblock 253 253 466 minecraft:bone_block
fill 253 253 467 253 254 467 minecraft:brown_terracotta
fill 253 253 502 253 255 502 minecraft:brown_terracotta
setblock 254 253 465 minecraft:bone_block
fill 254 253 466 254 256 466 minecraft:brown_terracotta
setblock 255 253 464 minecraft:bone_block
fill 255 253 465 255 256 465 minecraft:brown_terracotta
setblock 255 253 504 minecraft:bone_block
fill 256 253 464 256 256 464 minecraft:brown_terracotta
setblock 256 253 503 minecraft:bone_block
fill 256 253 504 259 253 504 minecraft:brown_terracotta
fill 257 253 503 257 255 503 minecraft:brown_terracotta
setblock 259 253 465 minecraft:bone_block
setblock 260 253 464 minecraft:bone_block
setblock 260 253 465 minecraft:brown_terracotta
setblock 260 253 504 minecraft:bone_block
fill 261 253 464 261 254 464 minecraft:brown_terracotta
fill 261 253 504 261 254 504 minecraft:brown_terracotta
fill 263 253 502 263 261 502 minecraft:soul_soil
setblock 267 253 464 minecraft:brown_terracotta
setblock 270 253 464 minecraft:bone_block
fill 270 253 465 270 255 465 minecraft:brown_terracotta
setblock 270 253 504 minecraft:bone_block
fill 271 253 464 271 256 464 minecraft:brown_terracotta
fill 271 253 504 271 255 504 minecraft:brown_terracotta
setblock 272 253 466 minecraft:brown_terracotta
fill 272 253 488 272 254 490 minecraft:brown_terracotta
setblock 273 253 466 minecraft:bone_block
setblock 273 253 486 minecraft:bone_block
fill 273 253 487 273 256 487 minecraft:brown_terracotta
setblock 273 253 491 minecraft:bone_block
fill 273 253 492 273 255 493 minecraft:brown_terracotta
setblock 274 253 465 minecraft:bone_block
fill 274 253 466 274 255 466 minecraft:brown_terracotta
fill 274 253 468 274 253 469 minecraft:brown_terracotta
setblock 274 253 470 minecraft:bone_block
fill 274 253 471 274 256 471 minecraft:brown_terracotta
setblock 274 253 474 minecraft:brown_terracotta
setblock 274 253 475 minecraft:bone_block
fill 274 253 476 274 256 476 minecraft:brown_terracotta
setblock 274 253 479 minecraft:brown_terracotta
setblock 274 253 480 minecraft:bone_block
fill 274 253 481 274 255 481 minecraft:brown_terracotta
setblock 274 253 485 minecraft:bone_block
fill 274 253 486 274 256 486 minecraft:brown_terracotta
setblock 274 253 490 minecraft:bone_block
fill 274 253 491 274 256 491 minecraft:brown_terracotta
setblock 274 253 495 minecraft:bone_block
setblock 275 253 464 minecraft:bone_block
fill 275 253 465 275 256 465 minecraft:brown_terracotta
setblock 275 253 469 minecraft:bone_block
fill 275 253 470 275 256 470 minecraft:brown_terracotta
setblock 275 253 474 minecraft:bone_block
fill 275 253 475 275 256 475 minecraft:brown_terracotta
setblock 275 253 479 minecraft:bone_block
fill 275 253 480 275 256 480 minecraft:brown_terracotta
setblock 275 253 484 minecraft:bone_block
fill 275 253 485 275 256 485 minecraft:brown_terracotta
setblock 275 253 489 minecraft:bone_block
fill 275 253 490 275 256 490 minecraft:brown_terracotta
setblock 275 253 494 minecraft:bone_block
fill 275 253 495 275 256 495 minecraft:brown_terracotta
setblock 275 253 504 minecraft:bone_block
fill 276 253 464 276 256 464 minecraft:brown_terracotta
setblock 276 253 468 minecraft:bone_block
fill 276 253 469 276 256 469 minecraft:brown_terracotta
setblock 276 253 473 minecraft:bone_block
fill 276 253 474 276 256 474 minecraft:brown_terracotta
setblock 276 253 478 minecraft:bone_block
fill 276 253 479 276 256 479 minecraft:brown_terracotta
setblock 276 253 483 minecraft:bone_block
fill 276 253 484 276 256 484 minecraft:brown_terracotta
setblock 276 253 488 minecraft:bone_block
fill 276 253 489 276 256 489 minecraft:brown_terracotta
setblock 276 253 493 minecraft:bone_block
fill 276 253 494 276 256 494 minecraft:brown_terracotta
setblock 276 253 498 minecraft:bone_block
fill 276 253 499 276 254 499 minecraft:brown_terracotta
setblock 276 253 503 minecraft:bone_block
fill 276 253 504 276 254 504 minecraft:brown_terracotta
fill 236 254 464 236 254 466 minecraft:brown_terracotta
setblock 236 254 467 minecraft:bone_block
fill 236 254 468 236 254 471 minecraft:brown_terracotta
setblock 236 254 472 minecraft:bone_block
fill 236 254 473 236 257 473 minecraft:brown_terracotta
setblock 236 254 477 minecraft:bone_block
fill 236 254 478 236 257 478 minecraft:brown_terracotta
setblock 236 254 482 minecraft:bone_block
fill 236 254 483 236 256 483 minecraft:brown_terracotta
setblock 236 254 487 minecraft:bone_block
fill 236 254 488 236 257 488 minecraft:brown_terracotta
setblock 236 254 492 minecraft:bone_block
fill 236 254 493 236 257 493 minecraft:brown_terracotta
setblock 236 254 497 minecraft:bone_block
setblock 236 254 503 minecraft:brown_terracotta
fill 237 254 464 237 254 465 minecraft:brown_terracotta
setblock 237 254 466 minecraft:bone_block
fill 237 254 467 237 257 467 minecraft:brown_terracotta
setblock 237 254 471 minecraft:bone_block
fill 237 254 472 237 257 472 minecraft:brown_terracotta
setblock 237 254 476 minecraft:bone_block
fill 237 254 477 237 255 477 minecraft:brown_terracotta
setblock 237 254 486 minecraft:bone_block
fill 237 254 487 237 255 487 minecraft:brown_terracotta
setblock 237 254 491 minecraft:bone_block
fill 237 254 492 237 255 492 minecraft:brown_terracotta
setblock 238 254 464 minecraft:brown_terracotta
setblock 238 254 465 minecraft:bone_block
fill 238 254 466 238 256 466 minecraft:brown_terracotta
setblock 238 254 470 minecraft:bone_block
fill 238 254 471 238 257 471 minecraft:brown_terracotta
setblock 239 254 464 minecraft:bone_block
fill 239 254 465 242 254 465 minecraft:brown_terracotta
fill 240 254 464 243 254 464 minecraft:brown_terracotta
setblock 242 254 466 minecraft:bone_block
setblock 243 254 465 minecraft:bone_block
setblock 244 254 464 minecraft:bone_block
fill 244 254 465 244 256 465 minecraft:brown_terracotta
fill 245 254 464 245 257 464 minecraft:brown_terracotta
fill 245 254 504 245 255 504 minecraft:brown_terracotta
setblock 246 254 466 minecraft:brown_terracotta
setblock 247 254 466 minecraft:bone_block
fill 247 254 502 247 256 502 minecraft:soul_soil
setblock 248 254 465 minecraft:bone_block
fill 248 254 466 248 256 466 minecraft:brown_terracotta
fill 248 254 501 248 256 501 minecraft:soul_soil
fill 248 254 503 248 255 503 minecraft:brown_terracotta
setblock 249 254 464 minecraft:bone_block
fill 249 254 465 249 257 465 minecraft:brown_terracotta
fill 249 254 502 249 256 502 minecraft:soul_soil
setblock 249 254 504 minecraft:bone_block
fill 250 254 464 250 257 464 minecraft:brown_terracotta
setblock 250 254 503 minecraft:bone_block
fill 250 254 504 250 257 504 minecraft:brown_terracotta
setblock 251 254 467 minecraft:bone_block
fill 251 254 503 251 257 503 minecraft:brown_terracotta
setblock 252 254 466 minecraft:bone_block
fill 252 254 467 252 255 467 minecraft:brown_terracotta
fill 252 254 502 252 255 502 minecraft:brown_terracotta
setblock 253 254 465 minecraft:bone_block
fill 253 254 466 253 256 466 minecraft:brown_terracotta
setblock 254 254 464 minecraft:bone_block
fill 254 254 465 254 257 465 minecraft:brown_terracotta
setblock 254 254 504 minecraft:bone_block
fill 255 254 464 255 257 464 minecraft:brown_terracotta
setblock 255 254 503 minecraft:bone_block
fill 255 254 504 258 254 504 minecraft:brown_terracotta
fill 256 254 503 256 256 503 minecraft:brown_terracotta
setblock 257 254 466 minecraft:bone_block
setblock 258 254 465 minecraft:bone_block
setblock 259 254 464 minecraft:bone_block
setblock 259 254 465 minecraft:brown_terracotta
setblock 259 254 504 minecraft:bone_block
setblock 260 254 464 minecraft:brown_terracotta
fill 260 254 504 260 255 504 minecraft:brown_terracotta
setblock 269 254 464 minecraft:bone_block
setblock 269 254 504 minecraft:bone_block
fill 270 254 464 270 257 464 minecraft:brown_terracotta
fill 270 254 504 270 255 504 minecraft:brown_terracotta
setblock 272 254 466 minecraft:bone_block
setblock 273 254 465 minecraft:bone_block
fill 273 254 466 273 255 466 minecraft:brown_terracotta
setblock 273 254 485 minecraft:bone_block
fill 273 254 486 273 255 486 minecraft:brown_terracotta
setblock 273 254 490 minecraft:bone_block
fill 273 254 491 273 257 491 minecraft:brown_terracotta
setblock 274 254 464 minecraft:bone_block
fill 274 254 465 274 256 465 minecraft:brown_terracotta
setblock 274 254 468 minecraft:brown_terracotta
setblock 274 254 469 minecraft:bone_block
fill 274 254 470 274 257 470 minecraft:brown_terracotta
fill 274 254 472 274 254 473 minecraft:brown_terracotta
setblock 274 254 474 minecraft:bone_block
fill 274 254 475 274 257 475 minecraft:brown_terracotta
fill 274 254 477 274 254 478 minecraft:brown_terracotta
setblock 274 254 479 minecraft:bone_block
fill 274 254 480 274 255 480 minecraft:brown_terracotta
setblock 274 254 484 minecraft:bone_block
fill 274 254 485 274 256 485 minecraft:brown_terracotta
setblock 274 254 489 minecraft:bone_block
fill 274 254 490 274 257 490 minecraft:brown_terracotta
setblock 274 254 493 minecraft:brown_terracotta
setblock 274 254 494 minecraft:bone_block
fill 274 254 495 274 256 495 minecraft:brown_terracotta
setblock 274 254 504 minecraft:bone_block
fill 275 254 464 275 257 464 minecraft:brown_terracotta
setblock 275 254 468 minecraft:bone_block
fill 275 254 469 275 257 469 minecraft:brown_terracotta
setblock 275 254 472 minecraft:brown_terracotta
setblock 275 254 473 minecraft:bone_block
fill 275 254 474 275 257 474 minecraft:brown_terracotta
setblock 275 254 478 minecraft:bone_block
fill 275 254 479 275 257 479 minecraft:brown_terracotta
setblock 275 254 483 minecraft:bone_block
fill 275 254 484 275 257 484 minecraft:brown_terracotta
setblock 275 254 488 minecraft:bone_block
fill 275 254 489 275 257 489 minecraft:brown_terracotta
setblock 275 254 493 minecraft:bone_block
fill 275 254 494 275 257 494 minecraft:brown_terracotta
setblock 275 254 504 minecraft:brown_terracotta
setblock 276 254 467 minecraft:bone_block
fill 276 254 468 276 257 468 minecraft:brown_terracotta
setblock 276 254 472 minecraft:bone_block
fill 276 254 473 276 257 473 minecraft:brown_terracotta
setblock 276 254 477 minecraft:bone_block
fill 276 254 478 276 257 478 minecraft:brown_terracotta
setblock 276 254 482 minecraft:bone_block
fill 276 254 483 276 257 483 minecraft:brown_terracotta
setblock 276 254 487 minecraft:bone_block
fill 276 254 488 276 257 488 minecraft:brown_terracotta
setblock 276 254 492 minecraft:bone_block
fill 276 254 493 276 257 493 minecraft:brown_terracotta
setblock 276 254 497 minecraft:bone_block
fill 276 254 498 276 256 498 minecraft:brown_terracotta
fill 236 255 464 236 255 465 minecraft:brown_terracotta
setblock 236 255 466 minecraft:bone_block
fill 236 255 467 236 255 470 minecraft:brown_terracotta
setblock 236 255 471 minecraft:bone_block
fill 236 255 472 236 258 472 minecraft:brown_terracotta
setblock 236 255 476 minecraft:bone_block
fill 236 255 477 236 258 477 minecraft:brown_terracotta
setblock 236 255 481 minecraft:bone_block
fill 236 255 482 236 256 482 minecraft:brown_terracotta
setblock 236 255 486 minecraft:bone_block
fill 236 255 487 236 257 487 minecraft:brown_terracotta
setblock 236 255 491 minecraft:bone_block
fill 236 255 492 236 258 492 minecraft:brown_terracotta
setblock 236 255 496 minecraft:bone_block
fill 236 255 497 236 256 497 minecraft:brown_terracotta
setblock 237 255 464 minecraft:brown_terracotta
setblock 237 255 465 minecraft:bone_block
fill 237 255 466 237 258 466 minecraft:brown_terracotta
setblock 237 255 470 minecraft:bone_block
fill 237 255 471 237 258 471 minecraft:brown_terracotta
setblock 237 255 475 minecraft:bone_block
fill 237 255 476 237 257 476 minecraft:brown_terracotta
setblock 237 255 490 minecraft:bone_block
setblock 237 255 491 minecraft:brown_terracotta
setblock 238 255 464 minecraft:bone_block
fill 238 255 465 241 255 465 minecraft:brown_terracotta
setblock 238 255 469 minecraft:bone_block
fill 238 255 470 238 257 470 minecraft:brown_terracotta
fill 239 255 464 242 255 464 minecraft:brown_terracotta
setblock 242 255 465 minecraft:bone_block
setblock 243 255 464 minecraft:bone_block
fill 243 255 465 243 256 465 minecraft:brown_terracotta
fill 244 255 464 244 258 464 minecraft:brown_terracotta
setblock 246 255 466 minecraft:bone_block
setblock 247 255 465 minecraft:bone_block
fill 247 255 466 247 256 466 minecraft:brown_terracotta
setblock 248 255 464 minecraft:bone_block
fill 248 255 465 248 258 465 minecraft:brown_terracotta
setblock 248 255 504 minecraft:bone_block
fill 249 255 464 249 258 464 minecraft:brown_terracotta
fill 249 255 466 250 255 466 minecraft:brown_terracotta
setblock 249 255 503 minecraft:bone_block
fill 249 255 504 249 258 504 minecraft:brown_terracotta
setblock 250 255 467 minecraft:bone_block
fill 250 255 503 250 258 503 minecraft:brown_terracotta
setblock 251 255 466 minecraft:bone_block
setblock 251 255 467 minecraft:brown_terracotta
setblock 252 255 465 minecraft:bone_block
fill 252 255 466 252 257 466 minecraft:brown_terracotta
setblock 253 255 464 minecraft:bone_block
fill 253 255 465 253 257 465 minecraft:brown_terracotta
setblock 253 255 504 minecraft:bone_block
fill 254 255 464 254 258 464 minecraft:brown_terracotta
setblock 254 255 503 minecraft:bone_block
fill 254 255 504 257 255 504 minecraft:brown_terracotta
fill 255 255 503 255 257 503 minecraft:brown_terracotta
setblock 257 255 465 minecraft:bone_block
setblock 258 255 464 minecraft:bone_block
setblock 258 255 504 minecraft:bone_block
setblock 259 255 464 minecraft:brown_terracotta
setblock 259 255 504 minecraft:brown_terracotta
setblock 268 255 464 minecraft:bone_block
fill 269 255 464 269 256 464 minecraft:brown_terracotta
setblock 272 255 465 minecraft:bone_block
setblock 272 255 466 minecraft:brown_terracotta
setblock 273 255 464 minecraft:bone_block
fill 273 255 465 273 257 465 minecraft:brown_terracotta
fill 273 255 470 273 256 472 minecraft:brown_terracotta
setblock 273 255 485 minecraft:brown_terracotta
setblock 273 255 489 minecraft:bone_block
fill 273 255 490 273 257 490 minecraft:brown_terracotta
setblock 273 255 504 minecraft:bone_block
fill 274 255 464 274 258 464 minecraft:brown_terracotta
setblock 274 255 468 minecraft:bone_block
fill 274 255 469 274 258 469 minecraft:brown_terracotta
setblock 274 255 472 minecraft:brown_terracotta
setblock 274 255 473 minecraft:bone_block
fill 274 255 474 274 258 474 minecraft:brown_terracotta
setblock 274 255 477 minecraft:brown_terracotta
setblock 274 255 478 minecraft:bone_block
setblock 274 255 479 minecraft:brown_terracotta
setblock 274 255 483 minecraft:bone_block
fill 274 255 484 274 256 484 minecraft:brown_terracotta
setblock 274 255 488 minecraft:bone_block
fill 274 255 489 274 258 489 minecraft:brown_terracotta
setblock 274 255 493 minecraft:bone_block
fill 274 255 494 274 257 494 minecraft:brown_terracotta
setblock 274 255 504 minecraft:brown_terracotta
setblock 275 255 467 minecraft:bone_block
fill 275 255 468 275 258 468 minecraft:brown_terracotta
setblock 275 255 472 minecraft:bone_block
fill 275 255 473 275 258 473 minecraft:brown_terracotta
setblock 275 255 477 minecraft:bone_block
fill 275 255 478 275 258 478 minecraft:brown_terracotta
setblock 275 255 482 minecraft:bone_block
fill 275 255 483 275 257 483 minecraft:brown_terracotta
setblock 275 255 487 minecraft:bone_block
fill 275 255 488 275 258 488 minecraft:brown_terracotta
setblock 275 255 492 minecraft:bone_block
fill 275 255 493 275 258 493 minecraft:brown_terracotta
setblock 275 255 496 minecraft:brown_terracotta
setblock 275 255 497 minecraft:bone_block
setblock 276 255 466 minecraft:bone_block
fill 276 255 467 276 258 467 minecraft:brown_terracotta
setblock 276 255 471 minecraft:bone_block
fill 276 255 472 276 258 472 minecraft:brown_terracotta
setblock 276 255 476 minecraft:bone_block
fill 276 255 477 276 258 477 minecraft:brown_terracotta
setblock 276 255 481 minecraft:bone_block
fill 276 255 482 276 258 482 minecraft:brown_terracotta
setblock 276 255 486 minecraft:bone_block
fill 276 255 487 276 258 487 minecraft:brown_terracotta
setblock 276 255 491 minecraft:bone_block
fill 276 255 492 276 258 492 minecraft:brown_terracotta
setblock 276 255 496 minecraft:bone_block
fill 276 255 497 276 258 497 minecraft:brown_terracotta
setblock 236 256 464 minecraft:brown_terracotta
setblock 236 256 465 minecraft:bone_block
fill 236 256 466 236 256 469 minecraft:brown_terracotta
setblock 236 256 470 minecraft:bone_block
fill 236 256 471 236 259 471 minecraft:brown_terracotta
setblock 236 256 475 minecraft:bone_block
fill 236 256 476 236 259 476 minecraft:brown_terracotta
setblock 236 256 480 minecraft:bone_block
setblock 236 256 481 minecraft:brown_terracotta
setblock 236 256 485 minecraft:bone_block
fill 236 256 486 236 257 486 minecraft:brown_terracotta
setblock 236 256 490 minecraft:bone_block
fill 236 256 491 236 258 491 minecraft:brown_terracotta
setblock 236 256 495 minecraft:bone_block
fill 236 256 496 236 257 496 minecraft:brown_terracotta
setblock 237 256 464 minecraft:bone_block
fill 237 256 465 240 256 465 minecraft:brown_terracotta
setblock 237 256 469 minecraft:bone_block
fill 237 256 470 237 259 470 minecraft:brown_terracotta
setblock 237 256 474 minecraft:bone_block
fill 237 256 475 237 258 475 minecraft:brown_terracotta
fill 238 256 464 241 256 464 minecraft:brown_terracotta
setblock 238 256 468 minecraft:bone_block
fill 238 256 469 238 257 469 minecraft:brown_terracotta
setblock 238 256 473 minecraft:bone_block
setblock 238 256 474 minecraft:light[level=12]
setblock 238 256 482 minecraft:light[level=12]
setblock 238 256 490 minecraft:light[level=12]
setblock 238 256 498 minecraft:light[level=12]
setblock 241 256 465 minecraft:bone_block
setblock 242 256 464 minecraft:bone_block
setblock 242 256 465 minecraft:brown_terracotta
fill 243 256 464 243 258 464 minecraft:brown_terracotta
setblock 246 256 465 minecraft:bone_block
setblock 246 256 466 minecraft:light[level=12]
setblock 246 256 474 minecraft:light[level=12]
setblock 246 256 482 minecraft:light[level=12]
setblock 246 256 490 minecraft:light[level=12]
setblock 246 256 498 minecraft:light[level=12]
setblock 247 256 464 minecraft:bone_block
fill 247 256 465 247 258 465 minecraft:brown_terracotta
setblock 247 256 501 minecraft:soul_soil
setblock 247 256 503 minecraft:soul_soil
setblock 247 256 504 minecraft:bone_block
fill 248 256 464 248 259 464 minecraft:brown_terracotta
setblock 248 256 503 minecraft:bone_block
fill 248 256 504 248 259 504 minecraft:brown_terracotta
setblock 249 256 466 minecraft:brown_terracotta
setblock 249 256 501 minecraft:soul_soil
fill 249 256 503 249 259 503 minecraft:brown_terracotta
setblock 250 256 466 minecraft:bone_block
setblock 251 256 465 minecraft:bone_block
fill 251 256 466 251 257 466 minecraft:brown_terracotta
setblock 252 256 464 minecraft:bone_block
fill 252 256 465 252 258 465 minecraft:brown_terracotta
setblock 252 256 504 minecraft:bone_block
fill 253 256 464 253 259 464 minecraft:brown_terracotta
setblock 253 256 503 minecraft:bone_block
fill 253 256 504 256 256 504 minecraft:brown_terracotta
setblock 254 256 474 minecraft:light[level=12]
setblock 254 256 482 minecraft:light[level=12]
setblock 254 256 490 minecraft:light[level=12]
setblock 254 256 498 minecraft:light[level=12]
fill 254 256 503 254 257 503 minecraft:brown_terracotta
setblock 256 256 465 minecraft:bone_block
setblock 257 256 464 minecraft:bone_block
setblock 257 256 504 minecraft:bone_block
setblock 258 256 464 minecraft:brown_terracotta
setblock 258 256 504 minecraft:brown_terracotta
setblock 262 256 466 minecraft:light[level=12]
setblock 262 256 474 minecraft:light[level=12]
setblock 262 256 482 minecraft:light[level=12]
setblock 262 256 490 minecraft:light[level=12]
setblock 262 256 498 minecraft:light[level=12]
setblock 270 256 466 minecraft:light[level=12]
setblock 270 256 474 minecraft:light[level=12]
setblock 270 256 482 minecraft:light[level=12]
setblock 270 256 490 minecraft:light[level=12]
setblock 270 256 498 minecraft:light[level=12]
setblock 271 256 465 minecraft:bone_block
setblock 272 256 464 minecraft:bone_block
setblock 272 256 465 minecraft:brown_terracotta
fill 273 256 464 273 258 464 minecraft:brown_terracotta
setblock 273 256 488 minecraft:bone_block
setblock 273 256 489 minecraft:brown_terracotta
setblock 273 256 492 minecraft:brown_terracotta
setblock 273 256 493 minecraft:bone_block
setblock 274 256 467 minecraft:bone_block
fill 274 256 468 274 257 468 minecraft:brown_terracotta
setblock 274 256 472 minecraft:bone_block
fill 274 256 473 274 259 473 minecraft:brown_terracotta
setblock 274 256 477 minecraft:bone_block
setblock 274 256 478 minecraft:brown_terracotta
setblock 274 256 483 minecraft:brown_terracotta
setblock 274 256 487 minecraft:bone_block
fill 274 256 488 274 257 488 minecraft:brown_terracotta
setblock 274 256 492 minecraft:bone_block
fill 274 256 493 274 258 493 minecraft:brown_terracotta
setblock 275 256 466 minecraft:bone_block
fill 275 256 467 275 258 467 minecraft:brown_terracotta
setblock 275 256 471 minecraft:bone_block
fill 275 256 472 275 259 472 minecraft:brown_terracotta
setblock 275 256 476 minecraft:bone_block
fill 275 256 477 275 259 477 minecraft:brown_terracotta
setblock 275 256 481 minecraft:bone_block
fill 275 256 482 275 257 482 minecraft:brown_terracotta
setblock 275 256 486 minecraft:bone_block
fill 275 256 487 275 258 487 minecraft:brown_terracotta
setblock 275 256 491 minecraft:bone_block
fill 275 256 492 275 259 492 minecraft:brown_terracotta
setblock 275 256 496 minecraft:bone_block
setblock 276 256 465 minecraft:bone_block
fill 276 256 466 276 259 466 minecraft:brown_terracotta
setblock 276 256 470 minecraft:bone_block
fill 276 256 471 276 259 471 minecraft:brown_terracotta
setblock 276 256 475 minecraft:bone_block
fill 276 256 476 276 259 476 minecraft:brown_terracotta
setblock 276 256 480 minecraft:bone_block
fill 276 256 481 276 259 481 minecraft:brown_terracotta
setblock 276 256 485 minecraft:bone_block
fill 276 256 486 276 258 486 minecraft:brown_terracotta
setblock 276 256 490 minecraft:bone_block
fill 276 256 491 276 259 491 minecraft:brown_terracotta
setblock 276 256 495 minecraft:bone_block
fill 276 256 496 276 259 496 minecraft:brown_terracotta
setblock 236 257 464 minecraft:bone_block
fill 236 257 465 236 257 468 minecraft:brown_terracotta
setblock 236 257 469 minecraft:bone_block
fill 236 257 470 236 260 470 minecraft:brown_terracotta
setblock 236 257 474 minecraft:bone_block
fill 236 257 475 236 260 475 minecraft:brown_terracotta
setblock 236 257 479 minecraft:bone_block
setblock 236 257 480 minecraft:brown_terracotta
setblock 236 257 489 minecraft:bone_block
fill 236 257 490 236 258 490 minecraft:brown_terracotta
setblock 236 257 494 minecraft:bone_block
fill 236 257 495 236 258 495 minecraft:brown_terracotta
fill 237 257 464 238 257 465 minecraft:brown_terracotta
setblock 237 257 468 minecraft:bone_block
fill 237 257 469 237 259 469 minecraft:brown_terracotta
setblock 237 257 473 minecraft:bone_block
fill 237 257 474 237 260 474 minecraft:brown_terracotta
setblock 238 257 468 minecraft:brown_terracotta
setblock 238 257 472 minecraft:bone_block
fill 239 257 464 240 257 464 minecraft:brown_terracotta
setblock 241 257 464 minecraft:bone_block
setblock 242 257 464 minecraft:brown_terracotta
setblock 245 257 465 minecraft:bone_block
setblock 246 257 464 minecraft:bone_block
setblock 246 257 465 minecraft:brown_terracotta
setblock 246 257 504 minecraft:bone_block
fill 247 257 464 247 260 464 minecraft:brown_terracotta
fill 247 257 504 247 260 504 minecraft:brown_terracotta
setblock 248 257 503 minecraft:brown_terracotta
setblock 249 257 466 minecraft:bone_block
setblock 250 257 465 minecraft:bone_block
setblock 250 257 466 minecraft:brown_terracotta
setblock 251 257 464 minecraft:bone_block
fill 251 257 465 251 258 465 minecraft:brown_terracotta
setblock 251 257 504 minecraft:bone_block
fill 252 257 464 252 260 464 minecraft:brown_terracotta
setblock 252 257 503 minecraft:bone_block
fill 252 257 504 255 257 504 minecraft:brown_terracotta
fill 253 257 503 253 258 503 minecraft:brown_terracotta
setblock 256 257 464 minecraft:bone_block
setblock 256 257 504 minecraft:bone_block
setblock 257 257 504 minecraft:brown_terracotta
fill 268 257 484 268 258 484 minecraft:soul_soil
setblock 271 257 464 minecraft:bone_block
fill 272 257 464 272 258 464 minecraft:brown_terracotta
setblock 274 257 471 minecraft:bone_block
fill 274 257 472 274 260 472 minecraft:brown_terracotta
setblock 274 257 476 minecraft:bone_block
fill 274 257 477 274 258 477 minecraft:brown_terracotta
setblock 274 257 486 minecraft:bone_block
setblock 274 257 487 minecraft:brown_terracotta
setblock 274 257 491 minecraft:bone_block
fill 274 257 492 274 258 492 minecraft:brown_terracotta
setblock 275 257 466 minecraft:brown_terracotta
setblock 275 257 470 minecraft:bone_block
fill 275 257 471 275 260 471 minecraft:brown_terracotta
setblock 275 257 475 minecraft:bone_block
fill 275 257 476 275 260 476 minecraft:brown_terracotta
setblock 275 257 480 minecraft:bone_block
setblock 275 257 481 minecraft:brown_terracotta
setblock 275 257 485 minecraft:bone_block
fill 275 257 486 275 258 486 minecraft:brown_terracotta
setblock 275 257 490 minecraft:bone_block
fill 275 257 491 275 259 491 minecraft:brown_terracotta
setblock 275 257 495 minecraft:bone_block
setblock 275 257 496 minecraft:brown_terracotta
setblock 276 257 464 minecraft:bone_block
fill 276 257 465 276 258 465 minecraft:brown_terracotta
setblock 276 257 469 minecraft:bone_block
fill 276 257 470 276 260 470 minecraft:brown_terracotta
setblock 276 257 474 minecraft:bone_block
fill 276 257 475 276 260 475 minecraft:brown_terracotta
setblock 276 257 479 minecraft:bone_block
fill 276 257 480 276 260 480 minecraft:brown_terracotta
setblock 276 257 484 minecraft:bone_block
fill 276 257 485 276 258 485 minecraft:brown_terracotta
setblock 276 257 489 minecraft:bone_block
fill 276 257 490 276 259 490 minecraft:brown_terracotta
setblock 276 257 494 minecraft:bone_block
fill 276 257 495 276 260 495 minecraft:brown_terracotta
fill 236 258 464 236 258 467 minecraft:brown_terracotta
setblock 236 258 468 minecraft:bone_block
fill 236 258 469 236 261 469 minecraft:brown_terracotta
setblock 236 258 473 minecraft:bone_block
fill 236 258 474 236 261 474 minecraft:brown_terracotta
setblock 236 258 478 minecraft:bone_block
setblock 236 258 493 minecraft:bone_block
setblock 236 258 494 minecraft:brown_terracotta
fill 237 258 464 238 258 464 minecraft:brown_terracotta
setblock 237 258 467 minecraft:bone_block
fill 237 258 468 237 259 468 minecraft:brown_terracotta
setblock 237 258 472 minecraft:bone_block
fill 237 258 473 237 261 473 minecraft:brown_terracotta
setblock 245 258 464 minecraft:bone_block
fill 246 258 464 246 261 464 minecraft:brown_terracotta
fill 246 258 504 246 261 504 minecraft:brown_terracotta
setblock 249 258 465 minecraft:bone_block
setblock 250 258 464 minecraft:bone_block
fill 250 258 465 250 259 465 minecraft:brown_terracotta
setblock 250 258 504 minecraft:bone_block
fill 251 258 464 251 261 464 minecraft:brown_terracotta
setblock 251 258 503 minecraft:bone_block
fill 251 258 504 254 258 504 minecraft:brown_terracotta
fill 252 258 503 252 261 503 minecraft:brown_terracotta
setblock 255 258 464 minecraft:bone_block
setblock 255 258 504 minecraft:bone_block
setblock 256 258 504 minecraft:brown_terracotta
fill 262 258 502 262 261 502 minecraft:soul_soil
fill 263 258 501 263 261 501 minecraft:soul_soil
fill 263 258 503 263 261 503 minecraft:soul_soil
fill 264 258 502 264 261 502 minecraft:soul_soil
setblock 271 258 464 minecraft:brown_terracotta
setblock 274 258 470 minecraft:bone_block
fill 274 258 471 274 260 471 minecraft:brown_terracotta
setblock 274 258 475 minecraft:bone_block
fill 274 258 476 274 261 476 minecraft:brown_terracotta
setblock 274 258 490 minecraft:bone_block
setblock 274 258 491 minecraft:brown_terracotta
setblock 275 258 469 minecraft:bone_block
fill 275 258 470 275 261 470 minecraft:brown_terracotta
setblock 275 258 474 minecraft:bone_block
fill 275 258 475 275 261 475 minecraft:brown_terracotta
setblock 275 258 479 minecraft:bone_block
setblock 275 258 480 minecraft:brown_terracotta
setblock 275 258 489 minecraft:bone_block
fill 275 258 490 275 259 490 minecraft:brown_terracotta
setblock 275 258 494 minecraft:bone_block
setblock 275 258 495 minecraft:brown_terracotta
setblock 276 258 468 minecraft:bone_block
fill 276 258 469 276 261 469 minecraft:brown_terracotta
setblock 276 258 473 minecraft:bone_block
fill 276 258 474 276 261 474 minecraft:brown_terracotta
setblock 276 258 478 minecraft:bone_block
fill 276 258 479 276 261 479 minecraft:brown_terracotta
setblock 276 258 483 minecraft:bone_block
setblock 276 258 484 minecraft:brown_terracotta
setblock 276 258 488 minecraft:bone_block
fill 276 258 489 276 259 489 minecraft:brown_terracotta
setblock 276 258 493 minecraft:bone_block
fill 276 258 494 276 260 494 minecraft:brown_terracotta
fill 236 259 464 236 259 466 minecraft:brown_terracotta
setblock 236 259 467 minecraft:bone_block
fill 236 259 468 236 262 468 minecraft:brown_terracotta
setblock 236 259 472 minecraft:bone_block
fill 236 259 473 236 262 473 minecraft:brown_terracotta
setblock 236 259 477 minecraft:bone_block
setblock 236 259 478 minecraft:brown_terracotta
setblock 237 259 471 minecraft:bone_block
fill 237 259 472 237 261 472 minecraft:brown_terracotta
setblock 244 259 464 minecraft:bone_block
fill 245 259 464 245 262 464 minecraft:brown_terracotta
setblock 248 259 465 minecraft:bone_block
fill 248 259 503 248 260 503 minecraft:brown_terracotta
setblock 249 259 464 minecraft:bone_block
setblock 249 259 465 minecraft:brown_terracotta
setblock 249 259 504 minecraft:bone_block
fill 250 259 464 250 262 464 minecraft:brown_terracotta
setblock 250 259 503 minecraft:bone_block
fill 250 259 504 253 259 504 minecraft:brown_terracotta
fill 251 259 503 251 262 503 minecraft:brown_terracotta
setblock 254 259 504 minecraft:bone_block
setblock 255 259 504 minecraft:brown_terracotta
setblock 274 259 470 minecraft:brown_terracotta
setblock 274 259 474 minecraft:bone_block
fill 274 259 475 274 262 475 minecraft:brown_terracotta
setblock 275 259 468 minecraft:bone_block
fill 275 259 469 275 260 469 minecraft:brown_terracotta
setblock 275 259 473 minecraft:bone_block
fill 275 259 474 275 262 474 minecraft:brown_terracotta
setblock 275 259 478 minecraft:bone_block
setblock 275 259 479 minecraft:brown_terracotta
setblock 275 259 493 minecraft:bone_block
setblock 275 259 494 minecraft:brown_terracotta
setblock 276 259 467 minecraft:bone_block
fill 276 259 468 276 261 468 minecraft:brown_terracotta
setblock 276 259 472 minecraft:bone_block
fill 276 259 473 276 262 473 minecraft:brown_terracotta
setblock 276 259 477 minecraft:bone_block
fill 276 259 478 276 262 478 minecraft:brown_terracotta
setblock 276 259 487 minecraft:bone_block
setblock 276 259 488 minecraft:brown_terracotta
setblock 276 259 492 minecraft:bone_block
fill 276 259 493 276 260 493 minecraft:brown_terracotta
setblock 236 260 466 minecraft:bone_block
fill 236 260 467 236 261 467 minecraft:brown_terracotta
setblock 236 260 471 minecraft:bone_block
fill 236 260 472 236 263 472 minecraft:brown_terracotta
setblock 236 260 476 minecraft:bone_block
fill 236 260 477 236 263 477 minecraft:brown_terracotta
setblock 237 260 470 minecraft:bone_block
setblock 237 260 471 minecraft:brown_terracotta
fill 245 260 504 245 262 504 minecraft:brown_terracotta
setblock 248 260 464 minecraft:bone_block
setblock 248 260 504 minecraft:bone_block
fill 249 260 464 249 263 464 minecraft:brown_terracotta
setblock 249 260 503 minecraft:bone_block
fill 249 260 504 252 260 504 minecraft:brown_terracotta
fill 250 260 503 250 263 503 minecraft:brown_terracotta
setblock 253 260 504 minecraft:bone_block
fill 254 260 504 254 261 504 minecraft:brown_terracotta
fill 262 260 501 262 261 501 minecraft:soul_soil
fill 262 260 503 262 261 503 minecraft:soul_soil
fill 264 260 501 264 261 501 minecraft:soul_soil
fill 264 260 503 264 261 503 minecraft:soul_soil
setblock 274 260 473 minecraft:bone_block
fill 274 260 474 274 263 474 minecraft:brown_terracotta
setblock 275 260 472 minecraft:bone_block
fill 275 260 473 275 263 473 minecraft:brown_terracotta
setblock 275 260 477 minecraft:bone_block
fill 275 260 478 275 263 478 minecraft:brown_terracotta
setblock 276 260 467 minecraft:brown_terracotta
setblock 276 260 471 minecraft:bone_block
fill 276 260 472 276 263 472 minecraft:brown_terracotta
setblock 276 260 476 minecraft:bone_block
fill 276 260 477 276 263 477 minecraft:brown_terracotta
setblock 276 260 491 minecraft:bone_block
setblock 276 260 492 minecraft:brown_terracotta
setblock 236 261 470 minecraft:bone_block
fill 236 261 471 236 264 471 minecraft:brown_terracotta
setblock 236 261 475 minecraft:bone_block
fill 236 261 476 236 264 476 minecraft:brown_terracotta
fill 245 261 497 249 262 501 minecraft:soul_soil
setblock 247 261 464 minecraft:bone_block
setblock 247 261 502 minecraft:soul_soil
setblock 247 261 503 minecraft:brown_terracotta
setblock 247 261 504 minecraft:bone_block
fill 248 261 464 248 264 464 minecraft:brown_terracotta
setblock 248 261 503 minecraft:bone_block
fill 248 261 504 251 261 504 minecraft:brown_terracotta
fill 249 261 503 249 264 503 minecraft:brown_terracotta
setblock 252 261 504 minecraft:bone_block
fill 253 261 504 253 264 504 minecraft:brown_terracotta
setblock 274 261 472 minecraft:bone_block
fill 274 261 473 274 264 473 minecraft:brown_terracotta
setblock 275 261 471 minecraft:bone_block
fill 275 261 472 275 264 472 minecraft:brown_terracotta
setblock 275 261 476 minecraft:bone_block
fill 275 261 477 275 264 477 minecraft:brown_terracotta
setblock 276 261 470 minecraft:bone_block
fill 276 261 471 276 264 471 minecraft:brown_terracotta
setblock 276 261 475 minecraft:bone_block
fill 276 261 476 276 264 476 minecraft:brown_terracotta
setblock 276 261 480 minecraft:bone_block
setblock 236 262 469 minecraft:bone_block
fill 236 262 470 236 265 470 minecraft:brown_terracotta
setblock 236 262 474 minecraft:bone_block
fill 236 262 475 236 265 475 minecraft:brown_terracotta
fill 243 262 504 244 263 504 minecraft:brown_terracotta
fill 245 262 503 246 262 503 minecraft:brown_terracotta
setblock 246 262 464 minecraft:bone_block
setblock 246 262 504 minecraft:bone_block
fill 247 262 464 247 265 464 minecraft:brown_terracotta
setblock 247 262 503 minecraft:bone_block
fill 247 262 504 250 262 504 minecraft:brown_terracotta
setblock 248 262 502 minecraft:bone_block
fill 248 262 503 248 265 503 minecraft:brown_terracotta
fill 249 262 502 249 265 502 minecraft:brown_terracotta
setblock 251 262 504 minecraft:bone_block
setblock 252 262 503 minecraft:bone_block
fill 252 262 504 252 265 504 minecraft:brown_terracotta
setblock 274 262 476 minecraft:bone_block
fill 274 262 477 274 265 477 minecraft:brown_terracotta
setblock 275 262 470 minecraft:bone_block
fill 275 262 471 275 265 471 minecraft:brown_terracotta
setblock 275 262 475 minecraft:bone_block
fill 275 262 476 275 265 476 minecraft:brown_terracotta
setblock 275 262 479 minecraft:brown_terracotta
setblock 276 262 469 minecraft:bone_block
fill 276 262 470 276 265 470 minecraft:brown_terracotta
setblock 276 262 474 minecraft:bone_block
fill 276 262 475 276 265 475 minecraft:brown_terracotta
setblock 276 262 479 minecraft:bone_block
fill 276 262 480 276 265 480 minecraft:brown_terracotta
setblock 236 263 468 minecraft:bone_block
fill 236 263 469 236 265 469 minecraft:brown_terracotta
setblock 236 263 473 minecraft:bone_block
fill 236 263 474 236 266 474 minecraft:brown_terracotta
setblock 236 263 478 minecraft:bone_block
fill 242 263 504 242 265 504 minecraft:brown_terracotta
fill 243 263 464 244 263 464 minecraft:brown_terracotta
fill 243 263 498 245 264 498 minecraft:bone_block
fill 243 263 500 245 264 500 minecraft:bone_block
fill 244 263 499 244 264 499 minecraft:bone_block
fill 244 263 503 245 263 503 minecraft:brown_terracotta
setblock 245 263 464 minecraft:bone_block
setblock 245 263 504 minecraft:bone_block
fill 246 263 464 246 266 464 minecraft:brown_terracotta
setblock 246 263 502 minecraft:brown_terracotta
setblock 246 263 503 minecraft:bone_block
fill 246 263 504 249 263 504 minecraft:brown_terracotta
setblock 247 263 502 minecraft:bone_block
fill 247 263 503 247 266 503 minecraft:brown_terracotta
fill 248 263 502 248 266 502 minecraft:brown_terracotta
setblock 250 263 464 minecraft:bone_block
fill 250 263 502 251 263 502 minecraft:brown_terracotta
setblock 250 263 504 minecraft:bone_block
setblock 251 263 503 minecraft:bone_block
fill 251 263 504 251 266 504 minecraft:brown_terracotta
fill 252 263 503 252 266 503 minecraft:brown_terracotta
setblock 254 263 504 minecraft:brown_terracotta
setblock 274 263 475 minecraft:bone_block
fill 274 263 476 274 266 476 minecraft:brown_terracotta
setblock 275 263 474 minecraft:bone_block
fill 275 263 475 275 266 475 minecraft:brown_terracotta
setblock 275 263 479 minecraft:bone_block
fill 276 263 469 276 266 469 minecraft:brown_terracotta
setblock 276 263 473 minecraft:bone_block
fill 276 263 474 276 266 474 minecraft:brown_terracotta
setblock 276 263 478 minecraft:bone_block
fill 276 263 479 276 266 479 minecraft:brown_terracotta
fill 276 263 481 276 264 481 minecraft:brown_terracotta
setblock 236 264 472 minecraft:bone_block
fill 236 264 473 236 267 473 minecraft:brown_terracotta
setblock 236 264 477 minecraft:bone_block
fill 236 264 478 236 267 478 minecraft:brown_terracotta
setblock 236 264 497 minecraft:bone_block
fill 236 264 498 236 265 500 minecraft:brown_terracotta
setblock 238 264 466 minecraft:light[level=12]
setblock 238 264 474 minecraft:light[level=12]
setblock 238 264 482 minecraft:light[level=12]
setblock 238 264 490 minecraft:light[level=12]
setblock 238 264 498 minecraft:light[level=12]
fill 240 264 504 241 266 504 minecraft:brown_terracotta
fill 242 264 464 243 264 464 minecraft:brown_terracotta
fill 242 264 503 244 264 503 minecraft:brown_terracotta
setblock 243 264 504 minecraft:brown_terracotta
setblock 244 264 464 minecraft:bone_block
fill 244 264 502 245 264 502 minecraft:brown_terracotta
setblock 244 264 504 minecraft:bone_block
fill 245 264 464 245 267 464 minecraft:brown_terracotta
fill 245 264 499 246 265 499 minecraft:bone_block
setblock 245 264 503 minecraft:bone_block
fill 245 264 504 248 264 504 minecraft:brown_terracotta
setblock 246 264 466 minecraft:light[level=12]
setblock 246 264 474 minecraft:light[level=12]
setblock 246 264 482 minecraft:light[level=12]
setblock 246 264 490 minecraft:light[level=12]
setblock 246 264 498 minecraft:light[level=12]
setblock 246 264 502 minecraft:bone_block
fill 246 264 503 246 267 503 minecraft:brown_terracotta
setblock 247 264 501 minecraft:bone_block
fill 247 264 502 247 267 502 minecraft:brown_terracotta
fill 248 264 501 249 266 501 minecraft:brown_terracotta
setblock 249 264 464 minecraft:bone_block
setblock 249 264 504 minecraft:bone_block
fill 250 264 464 250 267 464 minecraft:brown_terracotta
setblock 250 264 502 minecraft:brown_terracotta
setblock 250 264 503 minecraft:bone_block
fill 250 264 504 250 267 504 minecraft:brown_terracotta
setblock 251 264 502 minecraft:bone_block
fill 251 264 503 251 267 503 minecraft:brown_terracotta
fill 253 264 503 253 265 503 minecraft:brown_terracotta
setblock 254 264 466 minecraft:light[level=12]
setblock 254 264 474 minecraft:light[level=12]
setblock 254 264 482 minecraft:light[level=12]
setblock 254 264 490 minecraft:light[level=12]
setblock 254 264 498 minecraft:light[level=12]
setblock 254 264 504 minecraft:bone_block
setblock 262 264 466 minecraft:light[level=12]
setblock 262 264 474 minecraft:light[level=12]
setblock 262 264 482 minecraft:light[level=12]
setblock 262 264 490 minecraft:light[level=12]
setblock 262 264 498 minecraft:light[level=12]
fill 266 264 504 268 264 504 minecraft:brown_terracotta
setblock 269 264 504 minecraft:bone_block
setblock 270 264 466 minecraft:light[level=12]
setblock 270 264 474 minecraft:light[level=12]
setblock 270 264 482 minecraft:light[level=12]
setblock 270 264 490 minecraft:light[level=12]
setblock 270 264 498 minecraft:light[level=12]
setblock 274 264 474 minecraft:bone_block
fill 274 264 475 274 267 475 minecraft:brown_terracotta
setblock 274 264 478 minecraft:brown_terracotta
setblock 275 264 473 minecraft:bone_block
fill 275 264 474 275 267 474 minecraft:brown_terracotta
setblock 275 264 478 minecraft:bone_block
fill 275 264 479 275 266 480 minecraft:brown_terracotta
setblock 276 264 472 minecraft:bone_block
fill 276 264 473 276 267 473 minecraft:brown_terracotta
setblock 276 264 477 minecraft:bone_block
fill 276 264 478 276 267 478 minecraft:brown_terracotta
setblock 236 265 471 minecraft:bone_block
fill 236 265 472 236 268 472 minecraft:brown_terracotta
setblock 236 265 476 minecraft:bone_block
fill 236 265 477 236 268 477 minecraft:brown_terracotta
fill 236 265 479 236 266 479 minecraft:brown_terracotta
fill 236 265 497 236 268 497 minecraft:brown_terracotta
setblock 236 265 501 minecraft:bone_block
fill 236 265 502 236 267 503 minecraft:brown_terracotta
setblock 238 265 504 minecraft:bone_block
fill 239 265 504 239 268 504 minecraft:brown_terracotta
fill 240 265 464 242 265 464 minecraft:brown_terracotta
fill 241 265 503 243 265 503 minecraft:brown_terracotta
fill 242 265 502 244 265 502 minecraft:brown_terracotta
setblock 243 265 464 minecraft:bone_block
setblock 243 265 504 minecraft:bone_block
fill 244 265 464 244 268 464 minecraft:brown_terracotta
fill 244 265 501 245 265 501 minecraft:brown_terracotta
setblock 244 265 503 minecraft:bone_block
fill 244 265 504 247 265 504 minecraft:brown_terracotta
setblock 245 265 502 minecraft:bone_block
fill 245 265 503 245 268 503 minecraft:brown_terracotta
setblock 246 265 501 minecraft:bone_block
fill 246 265 502 246 268 502 minecraft:brown_terracotta
fill 247 265 499 247 266 499 minecraft:bone_block
fill 247 265 501 247 268 501 minecraft:brown_terracotta
setblock 248 265 464 minecraft:bone_block
setblock 248 265 504 minecraft:bone_block
fill 249 265 464 249 268 464 minecraft:brown_terracotta
setblock 249 265 503 minecraft:bone_block
fill 249 265 504 249 268 504 minecraft:brown_terracotta
setblock 250 265 501 minecraft:brown_terracotta
setblock 250 265 502 minecraft:bone_block
fill 250 265 503 250 268 503 minecraft:brown_terracotta
fill 251 265 502 252 267 502 minecraft:brown_terracotta
setblock 253 265 504 minecraft:bone_block
fill 254 265 504 254 268 504 minecraft:brown_terracotta
fill 264 265 504 267 265 504 minecraft:brown_terracotta
setblock 267 265 464 minecraft:brown_terracotta
setblock 268 265 464 minecraft:bone_block
setblock 268 265 504 minecraft:bone_block
fill 269 265 464 270 267 464 minecraft:brown_terracotta
fill 269 265 504 270 267 504 minecraft:brown_terracotta
fill 274 265 474 274 266 474 minecraft:brown_terracotta
setblock 274 265 478 minecraft:bone_block
setblock 275 265 472 minecraft:bone_block
fill 275 265 473 275 268 473 minecraft:brown_terracotta
setblock 275 265 477 minecraft:bone_block
fill 275 265 478 275 268 478 minecraft:brown_terracotta
setblock 276 265 471 minecraft:bone_block
fill 276 265 472 276 268 472 minecraft:brown_terracotta
setblock 276 265 476 minecraft:bone_block
fill 276 265 477 276 268 477 minecraft:brown_terracotta
setblock 276 265 481 minecraft:bone_block
fill 276 265 482 276 268 482 minecraft:brown_terracotta
setblock 236 266 464 minecraft:brown_terracotta
setblock 236 266 470 minecraft:bone_block
fill 236 266 471 236 267 471 minecraft:brown_terracotta
setblock 236 266 475 minecraft:bone_block
fill 236 266 476 236 269 476 minecraft:brown_terracotta
setblock 236 266 480 minecraft:bone_block
fill 236 266 496 236 268 496 minecraft:brown_terracotta
fill 236 266 498 236 266 499 minecraft:brown_terracotta
setblock 236 266 500 minecraft:bone_block
fill 236 266 501 236 269 501 minecraft:brown_terracotta
setblock 236 266 504 minecraft:brown_terracotta
setblock 237 266 464 minecraft:bone_block
setblock 237 266 504 minecraft:bone_block
fill 238 266 464 241 266 464 minecraft:brown_terracotta
fill 238 266 504 238 269 504 minecraft:brown_terracotta
fill 239 266 503 242 266 503 minecraft:brown_terracotta
fill 241 266 502 243 266 502 minecraft:brown_terracotta
setblock 242 266 464 minecraft:bone_block
setblock 242 266 504 minecraft:bone_block
fill 243 266 464 243 269 464 minecraft:brown_terracotta
fill 243 266 501 244 266 501 minecraft:brown_terracotta
setblock 243 266 503 minecraft:bone_block
fill 243 266 504 246 266 504 minecraft:brown_terracotta
fill 244 266 465 245 266 465 minecraft:brown_terracotta
setblock 244 266 502 minecraft:bone_block
fill 244 266 503 244 269 503 minecraft:brown_terracotta
setblock 245 266 501 minecraft:bone_block
fill 245 266 502 245 269 502 minecraft:brown_terracotta
setblock 246 266 465 minecraft:bone_block
setblock 246 266 500 minecraft:bone_block
fill 246 266 501 246 269 501 minecraft:brown_terracotta
setblock 247 266 464 minecraft:bone_block
fill 247 266 465 247 269 465 minecraft:brown_terracotta
fill 247 266 500 248 268 500 minecraft:brown_terracotta
setblock 247 266 504 minecraft:bone_block
fill 248 266 464 248 269 464 minecraft:brown_terracotta
fill 248 266 499 249 267 499 minecraft:bone_block
setblock 248 266 503 minecraft:bone_block
fill 248 266 504 248 269 504 minecraft:brown_terracotta
setblock 249 266 502 minecraft:bone_block
fill 249 266 503 249 269 503 minecraft:brown_terracotta
setblock 250 266 501 minecraft:bone_block
fill 250 266 502 250 269 502 minecraft:brown_terracotta
fill 251 266 501 251 267 501 minecraft:brown_terracotta
setblock 252 266 504 minecraft:bone_block
setblock 253 266 503 minecraft:bone_block
fill 253 266 504 253 269 504 minecraft:brown_terracotta
fill 254 266 503 254 269 503 minecraft:brown_terracotta
fill 255 266 504 255 267 504 minecraft:brown_terracotta
setblock 261 266 504 minecraft:brown_terracotta
setblock 262 266 504 minecraft:bone_block
fill 263 266 504 266 266 504 minecraft:brown_terracotta
fill 264 266 503 267 266 503 minecraft:brown_terracotta
fill 265 266 464 266 266 464 minecraft:brown_terracotta
setblock 267 266 464 minecraft:bone_block
setblock 267 266 504 minecraft:bone_block
fill 268 266 464 268 269 464 minecraft:brown_terracotta
setblock 268 266 503 minecraft:bone_block
fill 268 266 504 268 269 504 minecraft:brown_terracotta
fill 269 266 503 269 269 503 minecraft:brown_terracotta
setblock 271 266 464 minecraft:brown_terracotta
setblock 271 266 504 minecraft:brown_terracotta
setblock 272 266 464 minecraft:bone_block
setblock 274 266 477 minecraft:bone_block
fill 274 266 478 274 268 479 minecraft:brown_terracotta
fill 275 266 472 275 267 472 minecraft:brown_terracotta
setblock 275 266 476 minecraft:bone_block
fill 275 266 477 275 269 477 minecraft:brown_terracotta
setblock 275 266 481 minecraft:bone_block
setblock 276 266 470 minecraft:bone_block
fill 276 266 471 276 269 471 minecraft:brown_terracotta
setblock 276 266 475 minecraft:bone_block
fill 276 266 476 276 269 476 minecraft:brown_terracotta
setblock 276 266 480 minecraft:bone_block
fill 276 266 481 276 269 481 minecraft:brown_terracotta
setblock 236 267 464 minecraft:bone_block
fill 236 267 465 236 270 465 minecraft:brown_terracotta
setblock 236 267 470 minecraft:brown_terracotta
setblock 236 267 474 minecraft:bone_block
fill 236 267 475 236 269 475 minecraft:brown_terracotta
setblock 236 267 479 minecraft:bone_block
fill 236 267 480 236 270 480 minecraft:brown_terracotta
setblock 236 267 498 minecraft:brown_terracotta
setblock 236 267 499 minecraft:bone_block
fill 236 267 500 237 269 500 minecraft:brown_terracotta
setblock 236 267 504 minecraft:bone_block
fill 237 267 464 240 267 464 minecraft:brown_terracotta
fill 237 267 499 237 270 499 minecraft:brown_terracotta
fill 237 267 501 237 267 502 minecraft:brown_terracotta
setblock 237 267 503 minecraft:bone_block
fill 237 267 504 237 270 504 minecraft:brown_terracotta
fill 238 267 503 241 267 503 minecraft:brown_terracotta
fill 240 267 502 242 267 502 minecraft:brown_terracotta
setblock 240 267 504 minecraft:brown_terracotta
setblock 241 267 464 minecraft:bone_block
setblock 241 267 504 minecraft:bone_block
fill 242 267 464 242 269 465 minecraft:brown_terracotta
fill 242 267 501 243 267 501 minecraft:brown_terracotta
setblock 242 267 503 minecraft:bone_block
fill 242 267 504 245 267 504 minecraft:brown_terracotta
fill 243 267 465 244 267 465 minecraft:brown_terracotta
setblock 243 267 502 minecraft:bone_block
fill 243 267 503 243 270 503 minecraft:brown_terracotta
setblock 244 267 500 minecraft:brown_terracotta
setblock 244 267 501 minecraft:bone_block
fill 244 267 502 244 270 502 minecraft:brown_terracotta
setblock 245 267 465 minecraft:bone_block
setblock 245 267 500 minecraft:bone_block
fill 245 267 501 245 270 501 minecraft:brown_terracotta
setblock 246 267 464 minecraft:bone_block
fill 246 267 465 246 270 465 minecraft:brown_terracotta
fill 246 267 500 246 270 500 minecraft:brown_terracotta
setblock 246 267 504 minecraft:bone_block
fill 247 267 464 247 270 464 minecraft:brown_terracotta
setblock 247 267 503 minecraft:bone_block
fill 247 267 504 247 270 504 minecraft:brown_terracotta
setblock 248 267 501 minecraft:brown_terracotta
setblock 248 267 502 minecraft:bone_block
fill 248 267 503 248 270 503 minecraft:brown_terracotta
fill 249 267 498 251 268 498 minecraft:bone_block
fill 249 267 500 249 267 501 minecraft:bone_block
fill 249 267 502 249 270 502 minecraft:brown_terracotta
fill 250 267 499 250 268 500 minecraft:bone_block
fill 250 267 501 250 269 501 minecraft:brown_terracotta
fill 251 267 500 251 268 500 minecraft:bone_block
setblock 251 267 504 minecraft:bone_block
setblock 252 267 503 minecraft:bone_block
fill 252 267 504 252 270 504 minecraft:brown_terracotta
fill 253 267 503 253 270 503 minecraft:brown_terracotta
setblock 256 267 504 minecraft:bone_block
fill 257 267 504 260 267 504 minecraft:brown_terracotta
setblock 261 267 504 minecraft:bone_block
setblock 262 267 503 minecraft:bone_block
fill 262 267 504 265 267 504 minecraft:brown_terracotta
fill 263 267 503 266 267 503 minecraft:brown_terracotta
fill 264 267 464 265 267 464 minecraft:brown_terracotta
fill 265 267 502 266 268 502 minecraft:brown_terracotta
setblock 266 267 464 minecraft:bone_block
setblock 266 267 504 minecraft:bone_block
fill 267 267 464 267 270 464 minecraft:brown_terracotta
setblock 267 267 503 minecraft:bone_block
fill 267 267 504 267 270 504 minecraft:brown_terracotta
fill 268 267 503 268 270 503 minecraft:brown_terracotta
fill 270 267 503 270 268 503 minecraft:brown_terracotta
setblock 271 267 464 minecraft:bone_block
setblock 271 267 504 minecraft:bone_block
fill 272 267 464 273 269 464 minecraft:brown_terracotta
fill 272 267 504 272 270 504 minecraft:brown_terracotta
setblock 274 267 476 minecraft:bone_block
fill 274 267 477 274 268 477 minecraft:brown_terracotta
setblock 275 267 475 minecraft:bone_block
fill 275 267 476 275 270 476 minecraft:brown_terracotta
setblock 275 267 479 minecraft:brown_terracotta
setblock 275 267 480 minecraft:bone_block
fill 275 267 481 275 270 481 minecraft:brown_terracotta
setblock 276 267 469 minecraft:bone_block
fill 276 267 470 276 269 470 minecraft:brown_terracotta
setblock 276 267 474 minecraft:bone_block
fill 276 267 475 276 270 475 minecraft:brown_terracotta
setblock 276 267 479 minecraft:bone_block
fill 276 267 480 276 270 480 minecraft:brown_terracotta
setblock 276 267 483 minecraft:brown_terracotta
setblock 276 267 499 minecraft:bone_block
fill 276 267 500 276 268 502 minecraft:brown_terracotta
fill 236 268 464 239 268 464 minecraft:brown_terracotta
fill 236 268 466 236 269 466 minecraft:brown_terracotta
setblock 236 268 473 minecraft:bone_block
fill 236 268 474 236 269 474 minecraft:brown_terracotta
setblock 236 268 478 minecraft:bone_block
fill 236 268 479 236 271 479 minecraft:brown_terracotta
fill 236 268 481 236 269 481 minecraft:brown_terracotta
setblock 236 268 498 minecraft:bone_block
fill 236 268 499 236 271 499 minecraft:brown_terracotta
setblock 236 268 502 minecraft:brown_terracotta
setblock 236 268 503 minecraft:bone_block
fill 236 268 504 236 271 504 minecraft:brown_terracotta
fill 237 268 498 237 270 498 minecraft:brown_terracotta
setblock 237 268 501 minecraft:brown_terracotta
setblock 237 268 502 minecraft:bone_block
fill 237 268 503 240 268 503 minecraft:brown_terracotta
setblock 238 268 501 minecraft:bone_block
fill 238 268 502 241 268 502 minecraft:brown_terracotta
setblock 240 268 464 minecraft:bone_block
setblock 240 268 504 minecraft:bone_block
fill 241 268 464 241 270 465 minecraft:brown_terracotta
fill 241 268 501 242 268 501 minecraft:brown_terracotta
setblock 241 268 503 minecraft:bone_block
fill 241 268 504 244 268 504 minecraft:brown_terracotta
setblock 242 268 502 minecraft:bone_block
fill 242 268 503 242 271 503 minecraft:brown_terracotta
setblock 243 268 465 minecraft:brown_terracotta
setblock 243 268 501 minecraft:bone_block
fill 243 268 502 243 271 502 minecraft:brown_terracotta
setblock 244 268 465 minecraft:bone_block
setblock 244 268 500 minecraft:bone_block
fill 244 268 501 244 271 501 minecraft:brown_terracotta
setblock 245 268 464 minecraft:bone_block
fill 245 268 465 245 271 465 minecraft:brown_terracotta
fill 245 268 500 245 270 500 minecraft:brown_terracotta
setblock 245 268 504 minecraft:bone_block
fill 246 268 464 246 271 464 minecraft:brown_terracotta
setblock 246 268 503 minecraft:bone_block
fill 246 268 504 246 271 504 minecraft:brown_terracotta
setblock 247 268 502 minecraft:bone_block
fill 247 268 503 247 271 503 minecraft:brown_terracotta
setblock 248 268 501 minecraft:bone_block
fill 248 268 502 248 271 502 minecraft:brown_terracotta
setblock 249 268 500 minecraft:bone_block
fill 249 268 501 249 270 501 minecraft:brown_terracotta
setblock 250 268 464 minecraft:bone_block
setblock 250 268 504 minecraft:bone_block
setblock 251 268 502 minecraft:brown_terracotta
setblock 251 268 503 minecraft:bone_block
fill 251 268 504 251 271 504 minecraft:brown_terracotta
setblock 252 268 502 minecraft:bone_block
fill 252 268 503 252 271 503 minecraft:brown_terracotta
setblock 255 268 504 minecraft:bone_block
fill 256 268 504 259 268 504 minecraft:brown_terracotta
setblock 260 268 503 minecraft:brown_terracotta
setblock 260 268 504 minecraft:bone_block
setblock 261 268 503 minecraft:bone_block
fill 261 268 504 264 268 504 minecraft:brown_terracotta
fill 262 268 464 264 268 464 minecraft:brown_terracotta
fill 262 268 503 265 268 503 minecraft:brown_terracotta
fill 263 268 502 264 270 502 minecraft:brown_terracotta
setblock 265 268 464 minecraft:bone_block
setblock 265 268 504 minecraft:bone_block
fill 266 268 464 266 271 464 minecraft:brown_terracotta
setblock 266 268 503 minecraft:bone_block
fill 266 268 504 266 271 504 minecraft:brown_terracotta
setblock 267 268 502 minecraft:bone_block
fill 267 268 503 267 271 503 minecraft:brown_terracotta
setblock 269 268 464 minecraft:brown_terracotta
setblock 269 268 504 minecraft:brown_terracotta
setblock 270 268 464 minecraft:bone_block
setblock 270 268 504 minecraft:bone_block
fill 271 268 464 271 271 464 minecraft:brown_terracotta
fill 271 268 504 271 271 504 minecraft:brown_terracotta
fill 273 268 504 274 268 504 minecraft:brown_terracotta
setblock 274 268 464 minecraft:brown_terracotta
setblock 274 268 476 minecraft:brown_terracotta
setblock 275 268 464 minecraft:bone_block
setblock 275 268 474 minecraft:bone_block
fill 275 268 475 275 269 475 minecraft:brown_terracotta
setblock 275 268 479 minecraft:bone_block
fill 275 268 480 275 271 480 minecraft:brown_terracotta
fill 276 268 464 276 270 465 minecraft:brown_terracotta
fill 276 268 469 276 269 469 minecraft:brown_terracotta
setblock 276 268 473 minecraft:bone_block
fill 276 268 474 276 271 474 minecraft:brown_terracotta
setblock 276 268 478 minecraft:bone_block
fill 276 268 479 276 271 479 minecraft:brown_terracotta
setblock 276 268 483 minecraft:bone_block
fill 276 268 499 276 269 499 minecraft:brown_terracotta
setblock 276 268 503 minecraft:bone_block
fill 276 268 504 276 271 504 minecraft:brown_terracotta
fill 236 269 464 238 269 464 minecraft:brown_terracotta
setblock 236 269 477 minecraft:bone_block
fill 236 269 478 236 271 478 minecraft:brown_terracotta
setblock 236 269 497 minecraft:bone_block
fill 236 269 498 236 272 498 minecraft:brown_terracotta
setblock 236 269 502 minecraft:bone_block
fill 236 269 503 239 269 503 minecraft:brown_terracotta
setblock 237 269 501 minecraft:bone_block
fill 237 269 502 240 269 502 minecraft:brown_terracotta
setblock 238 269 500 minecraft:bone_block
fill 238 269 501 238 272 501 minecraft:brown_terracotta
setblock 239 269 464 minecraft:bone_block
setblock 239 269 504 minecraft:bone_block
fill 240 269 464 240 271 465 minecraft:brown_terracotta
fill 240 269 501 241 269 501 minecraft:brown_terracotta
setblock 240 269 503 minecraft:bone_block
fill 240 269 504 243 269 504 minecraft:brown_terracotta
setblock 241 269 502 minecraft:bone_block
fill 241 269 503 241 272 503 minecraft:brown_terracotta
setblock 242 269 501 minecraft:bone_block
fill 242 269 502 242 272 502 minecraft:brown_terracotta
setblock 243 269 465 minecraft:bone_block
setblock 243 269 500 minecraft:bone_block
fill 243 269 501 243 272 501 minecraft:brown_terracotta
setblock 244 269 464 minecraft:bone_block
fill 244 269 465 244 272 465 minecraft:brown_terracotta
fill 244 269 500 244 270 500 minecraft:brown_terracotta
setblock 244 269 504 minecraft:bone_block
fill 245 269 464 245 272 464 minecraft:brown_terracotta
setblock 245 269 503 minecraft:bone_block
fill 245 269 504 245 272 504 minecraft:brown_terracotta
setblock 246 269 502 minecraft:bone_block
fill 246 269 503 246 272 503 minecraft:brown_terracotta
schedule function dropper:buildpart/113_10 1t
