setblock 321 187 204 minecraft:polished_blackstone
fill 321 187 205 321 190 205 minecraft:red_nether_bricks
setblock 321 187 208 minecraft:red_nether_bricks
setblock 321 187 209 minecraft:polished_blackstone
fill 321 187 210 321 190 210 minecraft:red_nether_bricks
fill 321 187 223 321 189 223 minecraft:red_nether_bricks
fill 322 187 184 322 187 187 minecraft:red_nether_bricks
setblock 322 187 188 minecraft:polished_blackstone
fill 322 187 189 322 190 189 minecraft:red_nether_bricks
fill 322 187 199 322 190 199 minecraft:red_nether_bricks
setblock 322 187 203 minecraft:polished_blackstone
fill 322 187 204 322 190 204 minecraft:red_nether_bricks
setblock 322 187 208 minecraft:polished_blackstone
fill 322 187 209 322 190 209 minecraft:red_nether_bricks
setblock 322 187 212 minecraft:red_nether_bricks
setblock 322 187 213 minecraft:polished_blackstone
setblock 322 187 223 minecraft:nether_bricks
setblock 323 187 182 minecraft:polished_blackstone
fill 323 187 183 323 190 183 minecraft:red_nether_bricks
setblock 323 187 187 minecraft:polished_blackstone
fill 323 187 188 323 190 188 minecraft:red_nether_bricks
setblock 323 187 191 minecraft:red_nether_bricks
setblock 323 187 192 minecraft:polished_blackstone
fill 323 187 193 324 189 193 minecraft:red_nether_bricks
setblock 323 187 197 minecraft:polished_blackstone
fill 323 187 198 324 189 198 minecraft:red_nether_bricks
setblock 323 187 202 minecraft:polished_blackstone
fill 323 187 203 323 190 203 minecraft:red_nether_bricks
setblock 323 187 207 minecraft:polished_blackstone
fill 323 187 208 324 189 208 minecraft:red_nether_bricks
setblock 323 187 212 minecraft:polished_blackstone
fill 323 187 213 323 190 213 minecraft:red_nether_bricks
fill 323 187 216 324 187 216 minecraft:red_nether_bricks
setblock 323 187 222 minecraft:polished_blackstone
fill 323 187 223 324 189 223 minecraft:red_nether_bricks
fill 324 187 190 324 189 190 minecraft:red_nether_bricks
setblock 324 187 191 minecraft:nether_bricks
fill 324 187 192 324 189 192 minecraft:red_nether_bricks
setblock 324 187 194 minecraft:nether_bricks
fill 324 187 195 324 189 197 minecraft:red_nether_bricks
fill 324 187 199 324 187 202 minecraft:red_nether_bricks
fill 324 187 204 324 189 204 minecraft:red_nether_bricks
setblock 324 187 205 minecraft:nether_bricks
fill 324 187 206 324 189 206 minecraft:red_nether_bricks
setblock 324 187 207 minecraft:nether_bricks
setblock 324 187 215 minecraft:nether_bricks
fill 324 187 217 324 189 217 minecraft:red_nether_bricks
fill 324 187 220 324 189 220 minecraft:red_nether_bricks
setblock 282 188 181 minecraft:nether_bricks
fill 282 188 182 282 189 184 minecraft:red_nether_bricks
setblock 282 188 193 minecraft:nether_bricks
fill 282 188 194 282 189 194 minecraft:red_nether_bricks
setblock 282 188 195 minecraft:nether_bricks
fill 282 188 196 282 190 196 minecraft:red_nether_bricks
setblock 282 188 198 minecraft:nether_bricks
fill 282 188 199 282 189 203 minecraft:red_nether_bricks
setblock 282 188 212 minecraft:nether_bricks
fill 282 188 213 282 189 213 minecraft:red_nether_bricks
setblock 282 188 214 minecraft:nether_bricks
fill 282 188 215 282 189 216 minecraft:red_nether_bricks
setblock 282 188 219 minecraft:nether_bricks
fill 282 188 220 282 189 222 minecraft:red_nether_bricks
fill 283 188 182 283 191 182 minecraft:red_nether_bricks
setblock 283 188 186 minecraft:polished_blackstone
fill 283 188 187 283 188 190 minecraft:red_nether_bricks
setblock 283 188 191 minecraft:polished_blackstone
fill 283 188 192 283 191 192 minecraft:red_nether_bricks
setblock 283 188 195 minecraft:red_nether_bricks
setblock 283 188 196 minecraft:polished_blackstone
fill 283 188 197 283 191 197 minecraft:red_nether_bricks
setblock 283 188 201 minecraft:polished_blackstone
fill 283 188 202 283 191 202 minecraft:red_nether_bricks
setblock 283 188 206 minecraft:polished_blackstone
fill 283 188 207 283 191 207 minecraft:red_nether_bricks
setblock 283 188 210 minecraft:red_nether_bricks
setblock 283 188 211 minecraft:polished_blackstone
fill 283 188 212 283 191 212 minecraft:red_nether_bricks
setblock 283 188 215 minecraft:red_nether_bricks
fill 283 188 222 283 189 222 minecraft:red_nether_bricks
setblock 284 188 181 minecraft:nether_bricks
setblock 284 188 185 minecraft:polished_blackstone
fill 284 188 186 284 191 186 minecraft:red_nether_bricks
setblock 284 188 189 minecraft:red_nether_bricks
setblock 284 188 190 minecraft:polished_blackstone
fill 284 188 191 284 191 191 minecraft:red_nether_bricks
setblock 284 188 195 minecraft:polished_blackstone
fill 284 188 196 285 188 196 minecraft:red_nether_bricks
fill 284 188 198 284 189 198 minecraft:red_nether_bricks
setblock 284 188 200 minecraft:polished_blackstone
fill 284 188 201 284 191 201 minecraft:red_nether_bricks
setblock 284 188 205 minecraft:polished_blackstone
fill 284 188 206 284 191 206 minecraft:red_nether_bricks
setblock 284 188 209 minecraft:red_nether_bricks
setblock 284 188 210 minecraft:polished_blackstone
fill 284 188 211 284 191 211 minecraft:red_nether_bricks
setblock 285 188 184 minecraft:polished_blackstone
fill 285 188 185 285 191 185 minecraft:red_nether_bricks
setblock 285 188 189 minecraft:polished_blackstone
fill 285 188 190 285 191 190 minecraft:red_nether_bricks
setblock 285 188 194 minecraft:polished_blackstone
fill 285 188 195 285 191 195 minecraft:red_nether_bricks
setblock 285 188 200 minecraft:red_nether_bricks
setblock 285 188 204 minecraft:polished_blackstone
fill 285 188 205 285 190 205 minecraft:red_nether_bricks
setblock 285 188 209 minecraft:polished_blackstone
fill 285 188 210 285 190 210 minecraft:red_nether_bricks
setblock 285 188 216 minecraft:light[level=14]
setblock 286 188 183 minecraft:polished_blackstone
fill 286 188 184 286 191 184 minecraft:red_nether_bricks
setblock 286 188 188 minecraft:polished_blackstone
fill 286 188 189 286 191 189 minecraft:red_nether_bricks
setblock 286 188 192 minecraft:red_nether_bricks
setblock 287 188 182 minecraft:polished_blackstone
fill 287 188 183 287 191 183 minecraft:red_nether_bricks
setblock 287 188 186 minecraft:red_nether_bricks
setblock 287 188 187 minecraft:polished_blackstone
fill 287 188 188 287 189 188 minecraft:red_nether_bricks
setblock 287 188 222 minecraft:polished_blackstone
fill 288 188 181 288 189 182 minecraft:red_nether_bricks
setblock 288 188 186 minecraft:polished_blackstone
fill 288 188 222 291 188 222 minecraft:red_nether_bricks
setblock 289 188 185 minecraft:polished_blackstone
setblock 289 188 186 minecraft:red_nether_bricks
setblock 290 188 184 minecraft:polished_blackstone
fill 290 188 185 290 189 185 minecraft:red_nether_bricks
setblock 291 188 183 minecraft:polished_blackstone
fill 291 188 184 291 190 184 minecraft:red_nether_bricks
fill 292 188 181 292 189 181 minecraft:red_nether_bricks
setblock 292 188 182 minecraft:polished_blackstone
fill 292 188 183 292 191 183 minecraft:red_nether_bricks
setblock 292 188 222 minecraft:polished_blackstone
fill 292 188 223 292 189 223 minecraft:red_nether_bricks
setblock 293 188 181 minecraft:nether_bricks
fill 293 188 182 293 191 182 minecraft:red_nether_bricks
setblock 293 188 192 minecraft:light[level=14]
setblock 293 188 200 minecraft:light[level=14]
setblock 293 188 208 minecraft:light[level=14]
setblock 293 188 216 minecraft:light[level=14]
fill 293 188 222 293 189 222 minecraft:red_nether_bricks
setblock 293 188 223 minecraft:nether_bricks
fill 294 188 181 296 189 181 minecraft:red_nether_bricks
fill 294 188 223 295 189 223 minecraft:red_nether_bricks
setblock 295 188 184 minecraft:polished_blackstone
setblock 296 188 183 minecraft:polished_blackstone
setblock 296 188 184 minecraft:red_nether_bricks
setblock 297 188 182 minecraft:polished_blackstone
fill 297 188 183 297 190 183 minecraft:red_nether_bricks
setblock 297 188 222 minecraft:polished_blackstone
fill 297 188 223 301 189 223 minecraft:red_nether_bricks
fill 298 188 181 298 189 182 minecraft:red_nether_bricks
fill 298 188 222 298 191 222 minecraft:red_nether_bricks
setblock 299 188 184 minecraft:red_nether_bricks
setblock 300 188 184 minecraft:polished_blackstone
setblock 301 188 183 minecraft:polished_blackstone
fill 301 188 184 304 188 184 minecraft:red_nether_bricks
setblock 301 188 192 minecraft:light[level=14]
setblock 301 188 200 minecraft:light[level=14]
setblock 301 188 216 minecraft:light[level=14]
setblock 302 188 182 minecraft:polished_blackstone
fill 302 188 183 302 191 183 minecraft:red_nether_bricks
setblock 302 188 222 minecraft:polished_blackstone
setblock 302 188 223 minecraft:nether_bricks
fill 303 188 182 303 191 182 minecraft:red_nether_bricks
setblock 303 188 221 minecraft:polished_blackstone
fill 303 188 222 303 189 223 minecraft:red_nether_bricks
fill 304 188 181 304 189 181 minecraft:red_nether_bricks
setblock 304 188 220 minecraft:polished_blackstone
fill 304 188 221 304 191 221 minecraft:red_nether_bricks
fill 304 188 223 305 189 223 minecraft:red_nether_bricks
setblock 305 188 184 minecraft:polished_blackstone
fill 305 188 185 306 188 185 minecraft:red_nether_bricks
fill 305 188 220 305 189 220 minecraft:red_nether_bricks
setblock 306 188 183 minecraft:polished_blackstone
fill 306 188 184 306 190 184 minecraft:red_nether_bricks
setblock 307 188 182 minecraft:polished_blackstone
fill 307 188 183 307 191 183 minecraft:red_nether_bricks
setblock 307 188 222 minecraft:polished_blackstone
fill 308 188 182 308 191 182 minecraft:red_nether_bricks
setblock 308 188 221 minecraft:polished_blackstone
fill 308 188 222 308 191 222 minecraft:red_nether_bricks
setblock 309 188 192 minecraft:light[level=14]
setblock 309 188 200 minecraft:light[level=14]
setblock 309 188 208 minecraft:light[level=14]
setblock 309 188 216 minecraft:light[level=14]
fill 309 188 221 309 190 221 minecraft:red_nether_bricks
fill 309 188 223 309 189 223 minecraft:red_nether_bricks
setblock 310 188 223 minecraft:nether_bricks
fill 311 188 181 311 189 181 minecraft:red_nether_bricks
setblock 311 188 183 minecraft:polished_blackstone
fill 311 188 223 314 189 223 minecraft:red_nether_bricks
setblock 312 188 182 minecraft:polished_blackstone
setblock 312 188 183 minecraft:red_nether_bricks
setblock 312 188 222 minecraft:polished_blackstone
setblock 313 188 182 minecraft:red_nether_bricks
setblock 313 188 222 minecraft:red_nether_bricks
fill 315 188 181 315 189 181 minecraft:red_nether_bricks
setblock 316 188 181 minecraft:nether_bricks
setblock 317 188 184 minecraft:light[level=14]
setblock 317 188 192 minecraft:light[level=14]
setblock 317 188 200 minecraft:light[level=14]
setblock 317 188 208 minecraft:light[level=14]
setblock 317 188 216 minecraft:light[level=14]
fill 318 188 181 318 190 181 minecraft:red_nether_bricks
setblock 318 188 223 minecraft:nether_bricks
setblock 319 188 181 minecraft:nether_bricks
fill 320 188 181 320 189 181 minecraft:red_nether_bricks
fill 320 188 223 320 189 223 minecraft:red_nether_bricks
setblock 321 188 182 minecraft:red_nether_bricks
setblock 321 188 203 minecraft:polished_blackstone
fill 321 188 204 321 190 204 minecraft:red_nether_bricks
setblock 321 188 208 minecraft:polished_blackstone
fill 321 188 209 321 191 209 minecraft:red_nether_bricks
fill 321 188 211 321 189 211 minecraft:red_nether_bricks
setblock 322 188 181 minecraft:nether_bricks
setblock 322 188 182 minecraft:polished_blackstone
fill 322 188 183 322 188 186 minecraft:red_nether_bricks
setblock 322 188 187 minecraft:polished_blackstone
fill 322 188 188 322 191 188 minecraft:red_nether_bricks
fill 322 188 190 322 188 191 minecraft:red_nether_bricks
setblock 322 188 192 minecraft:polished_blackstone
fill 322 188 198 322 191 198 minecraft:red_nether_bricks
setblock 322 188 202 minecraft:polished_blackstone
fill 322 188 203 322 191 203 minecraft:red_nether_bricks
setblock 322 188 207 minecraft:polished_blackstone
fill 322 188 208 322 191 208 minecraft:red_nether_bricks
setblock 322 188 212 minecraft:polished_blackstone
fill 322 188 213 322 190 214 minecraft:red_nether_bricks
fill 322 188 223 322 191 223 minecraft:red_nether_bricks
fill 323 188 181 323 189 182 minecraft:red_nether_bricks
setblock 323 188 186 minecraft:polished_blackstone
fill 323 188 187 324 189 187 minecraft:red_nether_bricks
setblock 323 188 191 minecraft:polished_blackstone
fill 323 188 192 323 191 192 minecraft:red_nether_bricks
setblock 323 188 195 minecraft:red_nether_bricks
setblock 323 188 196 minecraft:polished_blackstone
fill 323 188 197 323 191 197 minecraft:red_nether_bricks
setblock 323 188 201 minecraft:polished_blackstone
fill 323 188 202 324 189 202 minecraft:red_nether_bricks
setblock 323 188 206 minecraft:polished_blackstone
fill 323 188 207 324 189 207 minecraft:red_nether_bricks
setblock 323 188 211 minecraft:polished_blackstone
fill 323 188 212 323 191 212 minecraft:red_nether_bricks
setblock 323 188 216 minecraft:polished_blackstone
fill 323 188 217 323 191 217 minecraft:red_nether_bricks
setblock 323 188 222 minecraft:red_nether_bricks
fill 324 188 181 324 189 181 minecraft:red_nether_bricks
fill 324 188 184 324 189 184 minecraft:red_nether_bricks
setblock 324 188 185 minecraft:nether_bricks
fill 324 188 186 324 190 186 minecraft:red_nether_bricks
fill 324 188 191 324 189 191 minecraft:red_nether_bricks
fill 324 188 194 324 189 194 minecraft:red_nether_bricks
setblock 324 188 199 minecraft:nether_bricks
fill 324 188 200 324 189 201 minecraft:red_nether_bricks
fill 324 188 205 324 189 205 minecraft:red_nether_bricks
fill 324 188 215 324 189 216 minecraft:red_nether_bricks
setblock 282 189 181 minecraft:red_nether_bricks
setblock 282 189 193 minecraft:red_nether_bricks
setblock 282 189 195 minecraft:red_nether_bricks
setblock 282 189 198 minecraft:red_nether_bricks
setblock 282 189 212 minecraft:red_nether_bricks
setblock 282 189 214 minecraft:red_nether_bricks
setblock 282 189 219 minecraft:red_nether_bricks
setblock 283 189 185 minecraft:polished_blackstone
fill 283 189 186 283 189 189 minecraft:red_nether_bricks
setblock 283 189 190 minecraft:polished_blackstone
fill 283 189 191 283 192 191 minecraft:red_nether_bricks
setblock 283 189 195 minecraft:polished_blackstone
fill 283 189 196 284 191 196 minecraft:red_nether_bricks
setblock 283 189 200 minecraft:polished_blackstone
fill 283 189 201 283 192 201 minecraft:red_nether_bricks
setblock 283 189 205 minecraft:polished_blackstone
fill 283 189 206 283 192 206 minecraft:red_nether_bricks
setblock 283 189 210 minecraft:polished_blackstone
fill 283 189 211 283 192 211 minecraft:red_nether_bricks
setblock 283 189 215 minecraft:polished_blackstone
setblock 284 189 181 minecraft:red_nether_bricks
setblock 284 189 184 minecraft:polished_blackstone
fill 284 189 185 284 192 185 minecraft:red_nether_bricks
setblock 284 189 189 minecraft:polished_blackstone
fill 284 189 190 284 192 190 minecraft:red_nether_bricks
setblock 284 189 193 minecraft:red_nether_bricks
setblock 284 189 194 minecraft:polished_blackstone
fill 284 189 195 284 192 195 minecraft:red_nether_bricks
setblock 284 189 199 minecraft:polished_blackstone
fill 284 189 200 284 191 200 minecraft:red_nether_bricks
setblock 284 189 204 minecraft:polished_blackstone
fill 284 189 205 284 192 205 minecraft:red_nether_bricks
setblock 284 189 209 minecraft:polished_blackstone
fill 284 189 210 284 192 210 minecraft:red_nether_bricks
setblock 284 189 213 minecraft:red_nether_bricks
setblock 285 189 183 minecraft:polished_blackstone
fill 285 189 184 285 192 184 minecraft:red_nether_bricks
setblock 285 189 188 minecraft:polished_blackstone
fill 285 189 189 285 192 189 minecraft:red_nether_bricks
setblock 285 189 193 minecraft:polished_blackstone
fill 285 189 194 285 192 194 minecraft:red_nether_bricks
setblock 285 189 203 minecraft:polished_blackstone
setblock 285 189 204 minecraft:red_nether_bricks
setblock 285 189 208 minecraft:polished_blackstone
fill 285 189 209 285 190 209 minecraft:red_nether_bricks
setblock 286 189 182 minecraft:polished_blackstone
fill 286 189 183 286 192 183 minecraft:red_nether_bricks
setblock 286 189 187 minecraft:polished_blackstone
fill 286 189 188 286 192 188 minecraft:red_nether_bricks
setblock 286 189 192 minecraft:polished_blackstone
setblock 286 189 222 minecraft:polished_blackstone
fill 287 189 182 287 192 182 minecraft:red_nether_bricks
setblock 287 189 186 minecraft:polished_blackstone
setblock 287 189 187 minecraft:red_nether_bricks
fill 287 189 222 290 189 222 minecraft:red_nether_bricks
setblock 288 189 185 minecraft:polished_blackstone
setblock 288 189 186 minecraft:red_nether_bricks
fill 289 189 181 290 189 182 minecraft:red_nether_bricks
setblock 289 189 184 minecraft:polished_blackstone
fill 289 189 185 289 190 185 minecraft:red_nether_bricks
setblock 290 189 183 minecraft:polished_blackstone
fill 290 189 184 290 191 184 minecraft:red_nether_bricks
setblock 291 189 181 minecraft:red_nether_bricks
setblock 291 189 182 minecraft:polished_blackstone
fill 291 189 183 291 191 183 minecraft:red_nether_bricks
setblock 291 189 185 minecraft:red_nether_bricks
setblock 291 189 222 minecraft:polished_blackstone
fill 292 189 182 292 192 182 minecraft:red_nether_bricks
setblock 292 189 222 minecraft:red_nether_bricks
setblock 293 189 181 minecraft:red_nether_bricks
setblock 293 189 223 minecraft:red_nether_bricks
setblock 294 189 184 minecraft:polished_blackstone
setblock 295 189 183 minecraft:polished_blackstone
setblock 296 189 182 minecraft:polished_blackstone
fill 296 189 183 296 190 183 minecraft:red_nether_bricks
fill 297 189 182 297 192 182 minecraft:red_nether_bricks
setblock 297 189 222 minecraft:red_nether_bricks
setblock 300 189 183 minecraft:polished_blackstone
fill 300 189 184 303 189 184 minecraft:red_nether_bricks
setblock 301 189 182 minecraft:polished_blackstone
fill 301 189 183 301 192 183 minecraft:red_nether_bricks
setblock 301 189 222 minecraft:polished_blackstone
fill 302 189 182 302 192 182 minecraft:red_nether_bricks
setblock 302 189 221 minecraft:polished_blackstone
fill 302 189 222 302 189 223 minecraft:red_nether_bricks
fill 303 189 221 303 192 221 minecraft:red_nether_bricks
setblock 304 189 184 minecraft:polished_blackstone
setblock 305 189 183 minecraft:polished_blackstone
fill 305 189 184 305 190 184 minecraft:red_nether_bricks
setblock 306 189 182 minecraft:polished_blackstone
fill 306 189 183 306 191 183 minecraft:red_nether_bricks
setblock 306 189 222 minecraft:polished_blackstone
fill 307 189 182 307 192 182 minecraft:red_nether_bricks
setblock 307 189 221 minecraft:polished_blackstone
fill 307 189 222 307 192 222 minecraft:red_nether_bricks
fill 308 189 221 308 190 221 minecraft:red_nether_bricks
fill 310 189 183 310 190 183 minecraft:polished_blackstone
setblock 310 189 223 minecraft:red_nether_bricks
setblock 311 189 182 minecraft:polished_blackstone
setblock 311 189 222 minecraft:polished_blackstone
setblock 312 189 182 minecraft:red_nether_bricks
setblock 312 189 222 minecraft:red_nether_bricks
setblock 316 189 181 minecraft:red_nether_bricks
setblock 318 189 223 minecraft:red_nether_bricks
setblock 319 189 181 minecraft:red_nether_bricks
setblock 321 189 182 minecraft:polished_blackstone
setblock 321 189 203 minecraft:red_nether_bricks
setblock 321 189 207 minecraft:polished_blackstone
fill 321 189 208 321 192 208 minecraft:red_nether_bricks
fill 322 189 181 322 189 182 minecraft:red_nether_bricks
fill 322 189 184 322 189 185 minecraft:red_nether_bricks
setblock 322 189 186 minecraft:polished_blackstone
fill 322 189 187 322 192 187 minecraft:red_nether_bricks
setblock 322 189 190 minecraft:red_nether_bricks
setblock 322 189 191 minecraft:polished_blackstone
fill 322 189 192 322 189 195 minecraft:red_nether_bricks
setblock 322 189 201 minecraft:polished_blackstone
fill 322 189 202 322 192 202 minecraft:red_nether_bricks
setblock 322 189 206 minecraft:polished_blackstone
fill 322 189 207 322 192 207 minecraft:red_nether_bricks
setblock 322 189 211 minecraft:polished_blackstone
fill 322 189 212 322 192 212 minecraft:red_nether_bricks
setblock 323 189 185 minecraft:polished_blackstone
fill 323 189 186 323 192 186 minecraft:red_nether_bricks
setblock 323 189 190 minecraft:polished_blackstone
fill 323 189 191 323 192 191 minecraft:red_nether_bricks
setblock 323 189 195 minecraft:polished_blackstone
fill 323 189 196 323 192 196 minecraft:red_nether_bricks
setblock 323 189 200 minecraft:polished_blackstone
fill 323 189 201 323 192 201 minecraft:red_nether_bricks
setblock 323 189 205 minecraft:polished_blackstone
fill 323 189 206 323 192 206 minecraft:red_nether_bricks
setblock 323 189 210 minecraft:polished_blackstone
fill 323 189 211 323 192 211 minecraft:red_nether_bricks
setblock 323 189 214 minecraft:red_nether_bricks
setblock 323 189 215 minecraft:polished_blackstone
fill 323 189 216 323 192 216 minecraft:red_nether_bricks
setblock 324 189 185 minecraft:red_nether_bricks
setblock 324 189 199 minecraft:red_nether_bricks
fill 282 190 181 282 190 189 minecraft:nether_bricks
fill 282 190 191 282 191 195 minecraft:nether_bricks
fill 282 190 197 282 190 223 minecraft:nether_bricks
fill 283 190 181 298 190 181 minecraft:nether_bricks
setblock 283 190 184 minecraft:polished_blackstone
fill 283 190 185 283 190 188 minecraft:red_nether_bricks
setblock 283 190 189 minecraft:polished_blackstone
fill 283 190 190 283 193 190 minecraft:red_nether_bricks
setblock 283 190 194 minecraft:polished_blackstone
fill 283 190 195 283 193 195 minecraft:red_nether_bricks
setblock 283 190 199 minecraft:polished_blackstone
fill 283 190 200 283 193 200 minecraft:red_nether_bricks
setblock 283 190 204 minecraft:polished_blackstone
fill 283 190 205 283 193 205 minecraft:red_nether_bricks
setblock 283 190 209 minecraft:polished_blackstone
fill 283 190 210 283 193 210 minecraft:red_nether_bricks
setblock 283 190 213 minecraft:red_nether_bricks
setblock 283 190 214 minecraft:polished_blackstone
fill 283 190 215 283 192 216 minecraft:red_nether_bricks
fill 283 190 223 290 190 223 minecraft:nether_bricks
setblock 284 190 183 minecraft:polished_blackstone
fill 284 190 184 284 193 184 minecraft:red_nether_bricks
setblock 284 190 188 minecraft:polished_blackstone
fill 284 190 189 284 193 189 minecraft:red_nether_bricks
setblock 284 190 193 minecraft:polished_blackstone
fill 284 190 194 284 193 194 minecraft:red_nether_bricks
setblock 284 190 198 minecraft:polished_blackstone
fill 284 190 199 284 191 199 minecraft:red_nether_bricks
setblock 284 190 203 minecraft:polished_blackstone
fill 284 190 204 284 191 204 minecraft:red_nether_bricks
setblock 284 190 208 minecraft:polished_blackstone
fill 284 190 209 284 193 209 minecraft:red_nether_bricks
setblock 284 190 213 minecraft:polished_blackstone
setblock 285 190 182 minecraft:polished_blackstone
fill 285 190 183 285 193 183 minecraft:red_nether_bricks
setblock 285 190 187 minecraft:polished_blackstone
fill 285 190 188 285 193 188 minecraft:red_nether_bricks
setblock 285 190 191 minecraft:red_nether_bricks
setblock 285 190 192 minecraft:polished_blackstone
fill 285 190 193 285 193 193 minecraft:red_nether_bricks
setblock 285 190 207 minecraft:polished_blackstone
setblock 285 190 208 minecraft:red_nether_bricks
setblock 285 190 222 minecraft:polished_blackstone
fill 286 190 182 286 193 182 minecraft:red_nether_bricks
setblock 286 190 186 minecraft:polished_blackstone
fill 286 190 187 286 192 187 minecraft:red_nether_bricks
setblock 286 190 191 minecraft:polished_blackstone
fill 286 190 192 286 191 192 minecraft:red_nether_bricks
fill 286 190 222 289 190 222 minecraft:red_nether_bricks
setblock 287 190 185 minecraft:polished_blackstone
fill 288 190 182 289 190 182 minecraft:red_nether_bricks
setblock 288 190 184 minecraft:polished_blackstone
setblock 288 190 185 minecraft:red_nether_bricks
setblock 289 190 183 minecraft:polished_blackstone
fill 289 190 184 289 191 184 minecraft:red_nether_bricks
setblock 290 190 182 minecraft:polished_blackstone
fill 290 190 183 290 192 183 minecraft:red_nether_bricks
setblock 290 190 222 minecraft:polished_blackstone
fill 291 190 182 291 192 182 minecraft:red_nether_bricks
fill 292 190 223 294 307 223 minecraft:nether_bricks
setblock 294 190 183 minecraft:polished_blackstone
setblock 295 190 182 minecraft:polished_blackstone
setblock 295 190 183 minecraft:red_nether_bricks
setblock 295 190 223 minecraft:red_nether_bricks
fill 296 190 182 296 192 182 minecraft:red_nether_bricks
fill 296 190 223 321 190 223 minecraft:nether_bricks
fill 298 190 182 298 191 182 minecraft:red_nether_bricks
fill 299 190 181 299 191 181 minecraft:red_nether_bricks
setblock 299 190 183 minecraft:polished_blackstone
fill 300 190 181 309 307 181 minecraft:nether_bricks
setblock 300 190 182 minecraft:polished_blackstone
fill 300 190 183 300 191 183 minecraft:red_nether_bricks
setblock 300 190 222 minecraft:polished_blackstone
fill 301 190 182 301 193 182 minecraft:red_nether_bricks
fill 301 190 184 302 190 184 minecraft:red_nether_bricks
setblock 301 190 221 minecraft:polished_blackstone
fill 301 190 222 303 191 222 minecraft:red_nether_bricks
fill 302 190 221 302 193 221 minecraft:red_nether_bricks
setblock 303 190 184 minecraft:polished_blackstone
setblock 304 190 183 minecraft:polished_blackstone
setblock 304 190 184 minecraft:red_nether_bricks
setblock 305 190 182 minecraft:polished_blackstone
fill 305 190 183 305 192 183 minecraft:red_nether_bricks
setblock 305 190 222 minecraft:polished_blackstone
fill 306 190 182 306 193 182 minecraft:red_nether_bricks
setblock 306 190 221 minecraft:polished_blackstone
fill 306 190 222 306 193 222 minecraft:red_nether_bricks
fill 307 190 221 307 191 221 minecraft:red_nether_bricks
setblock 309 190 183 minecraft:polished_blackstone
setblock 310 190 182 minecraft:polished_blackstone
fill 310 190 184 310 190 185 minecraft:polished_blackstone
setblock 310 190 222 minecraft:polished_blackstone
fill 311 190 181 313 307 181 minecraft:nether_bricks
setblock 311 190 182 minecraft:red_nether_bricks
fill 311 190 183 312 190 183 minecraft:polished_blackstone
fill 311 190 185 312 190 185 minecraft:polished_blackstone
setblock 311 190 222 minecraft:red_nether_bricks
setblock 312 190 184 minecraft:polished_blackstone
setblock 314 190 181 minecraft:red_nether_bricks
fill 315 190 181 317 191 181 minecraft:nether_bricks
fill 319 190 181 324 190 181 minecraft:nether_bricks
fill 321 190 182 323 190 182 minecraft:red_nether_bricks
setblock 321 190 206 minecraft:polished_blackstone
fill 321 190 207 321 193 207 minecraft:red_nether_bricks
setblock 321 190 211 minecraft:polished_blackstone
fill 321 190 212 321 192 212 minecraft:red_nether_bricks
setblock 322 190 184 minecraft:red_nether_bricks
setblock 322 190 185 minecraft:polished_blackstone
fill 322 190 186 322 193 186 minecraft:red_nether_bricks
setblock 322 190 190 minecraft:polished_blackstone
fill 322 190 191 322 190 194 minecraft:red_nether_bricks
setblock 322 190 195 minecraft:polished_blackstone
fill 322 190 196 322 192 197 minecraft:red_nether_bricks
setblock 322 190 200 minecraft:polished_blackstone
fill 322 190 201 322 193 201 minecraft:red_nether_bricks
setblock 322 190 205 minecraft:polished_blackstone
fill 322 190 206 322 193 206 minecraft:red_nether_bricks
setblock 322 190 210 minecraft:polished_blackstone
fill 322 190 211 322 193 211 minecraft:red_nether_bricks
setblock 323 190 184 minecraft:polished_blackstone
fill 323 190 185 323 193 185 minecraft:red_nether_bricks
fill 323 190 187 323 191 187 minecraft:red_nether_bricks
setblock 323 190 189 minecraft:polished_blackstone
fill 323 190 190 323 193 190 minecraft:red_nether_bricks
setblock 323 190 193 minecraft:red_nether_bricks
setblock 323 190 194 minecraft:polished_blackstone
fill 323 190 195 323 193 195 minecraft:red_nether_bricks
setblock 323 190 198 minecraft:red_nether_bricks
setblock 323 190 199 minecraft:polished_blackstone
fill 323 190 200 323 193 200 minecraft:red_nether_bricks
fill 323 190 202 323 191 202 minecraft:red_nether_bricks
setblock 323 190 204 minecraft:polished_blackstone
fill 323 190 205 323 193 205 minecraft:red_nether_bricks
fill 323 190 207 323 190 208 minecraft:red_nether_bricks
setblock 323 190 209 minecraft:polished_blackstone
fill 323 190 210 323 193 210 minecraft:red_nether_bricks
setblock 323 190 214 minecraft:polished_blackstone
fill 323 190 215 323 193 215 minecraft:red_nether_bricks
setblock 323 190 223 minecraft:red_nether_bricks
fill 324 190 183 324 307 185 minecraft:nether_bricks
fill 324 190 187 324 190 211 minecraft:nether_bricks
setblock 324 190 212 minecraft:red_nether_bricks
fill 324 190 213 324 307 215 minecraft:nether_bricks
setblock 324 190 216 minecraft:red_nether_bricks
fill 324 190 217 324 190 220 minecraft:nether_bricks
setblock 324 190 221 minecraft:red_nether_bricks
fill 324 190 222 324 190 223 minecraft:nether_bricks
fill 282 191 181 282 191 186 minecraft:nether_bricks
fill 282 191 187 283 191 187 minecraft:red_nether_bricks
fill 282 191 188 282 307 190 minecraft:nether_bricks
fill 282 191 196 282 307 196 minecraft:nether_bricks
setblock 282 191 197 minecraft:red_nether_bricks
fill 282 191 198 282 191 201 minecraft:nether_bricks
setblock 282 191 202 minecraft:red_nether_bricks
fill 282 191 203 282 307 204 minecraft:nether_bricks
fill 282 191 205 282 191 206 minecraft:red_nether_bricks
fill 282 191 207 282 307 209 minecraft:nether_bricks
setblock 282 191 210 minecraft:red_nether_bricks
fill 282 191 211 282 307 219 minecraft:nether_bricks
setblock 282 191 220 minecraft:red_nether_bricks
fill 282 191 221 282 307 223 minecraft:nether_bricks
setblock 283 191 181 minecraft:nether_bricks
setblock 283 191 183 minecraft:polished_blackstone
fill 283 191 184 283 192 186 minecraft:red_nether_bricks
setblock 283 191 188 minecraft:polished_blackstone
fill 283 191 189 283 194 189 minecraft:red_nether_bricks
setblock 283 191 193 minecraft:polished_blackstone
fill 283 191 194 283 194 194 minecraft:red_nether_bricks
setblock 283 191 198 minecraft:polished_blackstone
fill 283 191 199 283 194 199 minecraft:red_nether_bricks
setblock 283 191 203 minecraft:polished_blackstone
fill 283 191 204 283 194 204 minecraft:red_nether_bricks
setblock 283 191 208 minecraft:polished_blackstone
fill 283 191 209 283 194 209 minecraft:red_nether_bricks
setblock 283 191 213 minecraft:polished_blackstone
fill 283 191 214 283 194 214 minecraft:red_nether_bricks
setblock 283 191 223 minecraft:red_nether_bricks
setblock 284 191 181 minecraft:red_nether_bricks
setblock 284 191 182 minecraft:polished_blackstone
fill 284 191 183 284 194 183 minecraft:red_nether_bricks
setblock 284 191 187 minecraft:polished_blackstone
fill 284 191 188 284 194 188 minecraft:red_nether_bricks
setblock 284 191 192 minecraft:polished_blackstone
fill 284 191 193 284 194 193 minecraft:red_nether_bricks
setblock 284 191 197 minecraft:polished_blackstone
fill 284 191 198 284 192 198 minecraft:red_nether_bricks
setblock 284 191 202 minecraft:polished_blackstone
setblock 284 191 203 minecraft:red_nether_bricks
setblock 284 191 207 minecraft:polished_blackstone
fill 284 191 208 284 193 208 minecraft:red_nether_bricks
setblock 284 191 212 minecraft:polished_blackstone
fill 284 191 213 284 194 213 minecraft:red_nether_bricks
setblock 284 191 222 minecraft:polished_blackstone
fill 284 191 223 291 191 223 minecraft:nether_bricks
fill 285 191 181 291 191 181 minecraft:nether_bricks
fill 285 191 182 285 194 182 minecraft:red_nether_bricks
setblock 285 191 186 minecraft:polished_blackstone
fill 285 191 187 285 194 187 minecraft:red_nether_bricks
setblock 285 191 191 minecraft:polished_blackstone
fill 285 191 192 285 194 192 minecraft:red_nether_bricks
fill 285 191 222 288 191 222 minecraft:red_nether_bricks
setblock 286 191 185 minecraft:polished_blackstone
fill 286 191 186 286 192 186 minecraft:red_nether_bricks
setblock 286 191 190 minecraft:polished_blackstone
fill 286 191 191 286 192 191 minecraft:red_nether_bricks
setblock 287 191 184 minecraft:polished_blackstone
setblock 287 191 185 minecraft:red_nether_bricks
setblock 288 191 182 minecraft:red_nether_bricks
setblock 288 191 183 minecraft:polished_blackstone
fill 288 191 184 288 192 184 minecraft:red_nether_bricks
setblock 289 191 182 minecraft:polished_blackstone
fill 289 191 183 289 192 183 minecraft:red_nether_bricks
fill 290 191 182 290 193 182 minecraft:red_nether_bricks
setblock 292 191 181 minecraft:red_nether_bricks
setblock 293 191 181 minecraft:nether_bricks
fill 294 191 181 294 192 181 minecraft:red_nether_bricks
setblock 294 191 182 minecraft:polished_blackstone
fill 295 191 181 297 307 181 minecraft:nether_bricks
setblock 295 191 182 minecraft:red_nether_bricks
fill 295 191 223 300 191 223 minecraft:nether_bricks
setblock 298 191 181 minecraft:red_nether_bricks
setblock 299 191 182 minecraft:polished_blackstone
setblock 299 191 183 minecraft:red_nether_bricks
setblock 299 191 222 minecraft:polished_blackstone
fill 300 191 182 300 194 182 minecraft:red_nether_bricks
fill 300 191 222 300 194 222 minecraft:red_nether_bricks
setblock 301 191 223 minecraft:red_nether_bricks
fill 302 191 223 314 191 223 minecraft:nether_bricks
setblock 303 191 183 minecraft:polished_blackstone
setblock 304 191 182 minecraft:polished_blackstone
fill 304 191 183 304 192 183 minecraft:red_nether_bricks
setblock 304 191 222 minecraft:polished_blackstone
fill 305 191 182 305 193 182 minecraft:red_nether_bricks
setblock 305 191 221 minecraft:polished_blackstone
fill 305 191 222 305 194 222 minecraft:red_nether_bricks
fill 306 191 221 306 192 221 minecraft:red_nether_bricks
setblock 309 191 182 minecraft:polished_blackstone
setblock 309 191 222 minecraft:polished_blackstone
fill 310 191 181 310 307 181 minecraft:nether_bricks
setblock 310 191 222 minecraft:red_nether_bricks
fill 314 191 181 314 307 181 minecraft:nether_bricks
setblock 315 191 223 minecraft:red_nether_bricks
fill 316 191 223 321 307 223 minecraft:nether_bricks
fill 318 191 181 318 307 181 minecraft:nether_bricks
setblock 319 191 181 minecraft:red_nether_bricks
fill 320 191 181 324 307 181 minecraft:nether_bricks
fill 321 191 205 321 192 205 minecraft:polished_blackstone
fill 321 191 206 321 192 206 minecraft:red_nether_bricks
setblock 321 191 210 minecraft:polished_blackstone
fill 321 191 211 321 194 211 minecraft:red_nether_bricks
fill 322 191 182 323 191 182 minecraft:red_nether_bricks
fill 322 191 185 322 193 185 minecraft:red_nether_bricks
setblock 322 191 189 minecraft:polished_blackstone
fill 322 191 190 322 191 193 minecraft:red_nether_bricks
setblock 322 191 194 minecraft:polished_blackstone
fill 322 191 195 322 194 195 minecraft:red_nether_bricks
setblock 322 191 199 minecraft:polished_blackstone
fill 322 191 200 322 194 200 minecraft:red_nether_bricks
setblock 322 191 204 minecraft:polished_blackstone
fill 322 191 205 322 194 205 minecraft:red_nether_bricks
setblock 322 191 209 minecraft:polished_blackstone
fill 322 191 210 322 194 210 minecraft:red_nether_bricks
setblock 322 191 213 minecraft:red_nether_bricks
setblock 322 191 214 minecraft:polished_blackstone
setblock 323 191 183 minecraft:polished_blackstone
fill 323 191 184 323 194 184 minecraft:red_nether_bricks
setblock 323 191 188 minecraft:polished_blackstone
fill 323 191 189 323 194 189 minecraft:red_nether_bricks
setblock 323 191 193 minecraft:polished_blackstone
fill 323 191 194 323 194 194 minecraft:red_nether_bricks
setblock 323 191 198 minecraft:polished_blackstone
fill 323 191 199 323 194 199 minecraft:red_nether_bricks
setblock 323 191 203 minecraft:polished_blackstone
fill 323 191 204 323 194 204 minecraft:red_nether_bricks
setblock 323 191 207 minecraft:red_nether_bricks
setblock 323 191 208 minecraft:polished_blackstone
fill 323 191 209 323 194 209 minecraft:red_nether_bricks
setblock 323 191 213 minecraft:polished_blackstone
fill 323 191 214 323 194 214 minecraft:red_nether_bricks
fill 323 191 223 323 307 223 minecraft:nether_bricks
fill 324 191 182 324 307 182 minecraft:nether_bricks
fill 324 191 186 324 307 195 minecraft:nether_bricks
setblock 324 191 196 minecraft:red_nether_bricks
fill 324 191 197 324 307 202 minecraft:nether_bricks
setblock 324 191 203 minecraft:red_nether_bricks
fill 324 191 204 324 191 212 minecraft:nether_bricks
fill 324 191 216 324 307 217 minecraft:nether_bricks
setblock 324 191 218 minecraft:red_nether_bricks
fill 324 191 219 324 307 222 minecraft:nether_bricks
setblock 324 191 223 minecraft:red_nether_bricks
fill 282 192 181 283 192 181 minecraft:red_nether_bricks
fill 282 192 182 282 307 183 minecraft:nether_bricks
setblock 282 192 184 minecraft:red_nether_bricks
fill 282 192 185 282 307 187 minecraft:nether_bricks
setblock 282 192 191 minecraft:red_nether_bricks
fill 282 192 192 282 307 195 minecraft:nether_bricks
fill 282 192 197 282 307 198 minecraft:nether_bricks
setblock 282 192 199 minecraft:red_nether_bricks
fill 282 192 200 282 307 202 minecraft:nether_bricks
fill 282 192 205 282 307 206 minecraft:nether_bricks
fill 282 192 210 282 307 210 minecraft:nether_bricks
fill 282 192 220 282 307 220 minecraft:nether_bricks
setblock 283 192 182 minecraft:polished_blackstone
fill 283 192 183 283 195 183 minecraft:red_nether_bricks
setblock 283 192 187 minecraft:polished_blackstone
fill 283 192 188 283 195 188 minecraft:red_nether_bricks
setblock 283 192 192 minecraft:polished_blackstone
fill 283 192 193 283 195 193 minecraft:red_nether_bricks
setblock 283 192 196 minecraft:red_nether_bricks
setblock 283 192 197 minecraft:polished_blackstone
fill 283 192 198 283 195 198 minecraft:red_nether_bricks
setblock 283 192 202 minecraft:polished_blackstone
fill 283 192 203 283 194 203 minecraft:red_nether_bricks
setblock 283 192 207 minecraft:polished_blackstone
fill 283 192 208 283 195 208 minecraft:red_nether_bricks
setblock 283 192 212 minecraft:polished_blackstone
fill 283 192 213 283 195 213 minecraft:red_nether_bricks
fill 283 192 223 286 307 223 minecraft:nether_bricks
fill 284 192 181 288 307 181 minecraft:nether_bricks
fill 284 192 182 284 195 182 minecraft:red_nether_bricks
setblock 284 192 186 minecraft:polished_blackstone
fill 284 192 187 284 195 187 minecraft:red_nether_bricks
setblock 284 192 191 minecraft:polished_blackstone
fill 284 192 192 284 195 192 minecraft:red_nether_bricks
setblock 284 192 196 minecraft:polished_blackstone
fill 284 192 197 284 195 197 minecraft:red_nether_bricks
setblock 284 192 206 minecraft:polished_blackstone
fill 284 192 207 284 193 207 minecraft:red_nether_bricks
setblock 284 192 211 minecraft:polished_blackstone
fill 284 192 212 284 195 212 minecraft:red_nether_bricks
setblock 285 192 185 minecraft:polished_blackstone
fill 285 192 186 285 195 186 minecraft:red_nether_bricks
setblock 285 192 190 minecraft:polished_blackstone
fill 285 192 191 285 195 191 minecraft:red_nether_bricks
setblock 286 192 184 minecraft:polished_blackstone
setblock 286 192 189 minecraft:polished_blackstone
fill 286 192 190 286 193 190 minecraft:red_nether_bricks
setblock 287 192 183 minecraft:polished_blackstone
setblock 287 192 184 minecraft:red_nether_bricks
setblock 287 192 223 minecraft:red_nether_bricks
setblock 288 192 182 minecraft:polished_blackstone
fill 288 192 183 288 193 183 minecraft:red_nether_bricks
fill 288 192 223 291 307 223 minecraft:nether_bricks
fill 289 192 181 289 192 182 minecraft:red_nether_bricks
fill 290 192 181 292 307 181 minecraft:nether_bricks
setblock 293 192 181 minecraft:red_nether_bricks
setblock 293 192 182 minecraft:polished_blackstone
fill 294 192 185 294 193 186 minecraft:blackstone
fill 295 192 223 295 307 223 minecraft:nether_bricks
setblock 296 192 223 minecraft:red_nether_bricks
fill 297 192 223 298 307 223 minecraft:nether_bricks
fill 298 192 181 299 307 181 minecraft:nether_bricks
setblock 298 192 182 minecraft:polished_blackstone
fill 299 192 182 299 195 182 minecraft:red_nether_bricks
fill 299 192 222 299 192 223 minecraft:red_nether_bricks
fill 300 192 223 305 307 223 minecraft:nether_bricks
fill 301 192 222 302 192 222 minecraft:red_nether_bricks
setblock 302 192 183 minecraft:polished_blackstone
fill 302 192 211 302 193 212 minecraft:blackstone
setblock 303 192 182 minecraft:polished_blackstone
setblock 303 192 183 minecraft:red_nether_bricks
setblock 303 192 222 minecraft:polished_blackstone
fill 304 192 182 304 194 182 minecraft:red_nether_bricks
setblock 304 192 221 minecraft:polished_blackstone
fill 304 192 222 304 195 222 minecraft:red_nether_bricks
fill 305 192 221 305 193 221 minecraft:red_nether_bricks
setblock 306 192 223 minecraft:red_nether_bricks
fill 307 192 223 311 307 223 minecraft:nether_bricks
setblock 308 192 222 minecraft:polished_blackstone
setblock 312 192 223 minecraft:red_nether_bricks
fill 313 192 223 315 307 223 minecraft:nether_bricks
fill 315 192 181 315 307 181 minecraft:nether_bricks
setblock 316 192 181 minecraft:red_nether_bricks
fill 317 192 181 317 307 181 minecraft:nether_bricks
fill 317 192 203 317 192 205 minecraft:polished_blackstone
fill 318 192 202 320 192 202 minecraft:polished_blackstone
fill 318 192 206 320 192 206 minecraft:polished_blackstone
fill 319 192 181 319 307 181 minecraft:nether_bricks
fill 321 192 203 321 192 204 minecraft:polished_blackstone
setblock 321 192 209 minecraft:polished_blackstone
fill 321 192 210 321 194 210 minecraft:red_nether_bricks
setblock 322 192 188 minecraft:polished_blackstone
fill 322 192 189 322 192 192 minecraft:red_nether_bricks
setblock 322 192 193 minecraft:polished_blackstone
fill 322 192 194 322 195 194 minecraft:red_nether_bricks
setblock 322 192 198 minecraft:polished_blackstone
fill 322 192 199 322 195 199 minecraft:red_nether_bricks
setblock 322 192 203 minecraft:polished_blackstone
fill 322 192 204 322 195 204 minecraft:red_nether_bricks
setblock 322 192 208 minecraft:polished_blackstone
fill 322 192 209 322 195 209 minecraft:red_nether_bricks
setblock 322 192 213 minecraft:polished_blackstone
fill 322 192 214 322 194 215 minecraft:red_nether_bricks
fill 322 192 223 322 307 223 minecraft:nether_bricks
setblock 323 192 182 minecraft:polished_blackstone
fill 323 192 183 323 195 183 minecraft:red_nether_bricks
setblock 323 192 187 minecraft:polished_blackstone
fill 323 192 188 323 195 188 minecraft:red_nether_bricks
setblock 323 192 192 minecraft:polished_blackstone
fill 323 192 193 323 195 193 minecraft:red_nether_bricks
setblock 323 192 197 minecraft:polished_blackstone
fill 323 192 198 323 195 198 minecraft:red_nether_bricks
setblock 323 192 202 minecraft:polished_blackstone
fill 323 192 203 323 195 203 minecraft:red_nether_bricks
setblock 323 192 207 minecraft:polished_blackstone
fill 323 192 208 323 195 208 minecraft:red_nether_bricks
setblock 323 192 212 minecraft:polished_blackstone
fill 323 192 213 323 195 213 minecraft:red_nether_bricks
setblock 323 192 217 minecraft:polished_blackstone
fill 324 192 196 324 307 196 minecraft:nether_bricks
fill 324 192 203 324 307 209 minecraft:nether_bricks
setblock 324 192 210 minecraft:red_nether_bricks
fill 324 192 211 324 307 211 minecraft:nether_bricks
setblock 324 192 212 minecraft:red_nether_bricks
fill 324 192 218 324 307 218 minecraft:nether_bricks
fill 324 192 223 324 307 223 minecraft:nether_bricks
fill 282 193 181 283 307 181 minecraft:nether_bricks
fill 282 193 184 282 307 184 minecraft:nether_bricks
fill 282 193 191 282 307 191 minecraft:nether_bricks
fill 282 193 199 282 307 199 minecraft:nether_bricks
fill 283 193 182 283 196 182 minecraft:red_nether_bricks
fill 283 193 184 283 193 185 minecraft:red_nether_bricks
setblock 283 193 186 minecraft:polished_blackstone
fill 283 193 187 283 196 187 minecraft:red_nether_bricks
setblock 283 193 191 minecraft:polished_blackstone
fill 283 193 192 283 196 192 minecraft:red_nether_bricks
setblock 283 193 196 minecraft:polished_blackstone
fill 283 193 197 283 196 197 minecraft:red_nether_bricks
setblock 283 193 201 minecraft:polished_blackstone
fill 283 193 202 283 194 202 minecraft:red_nether_bricks
setblock 283 193 206 minecraft:polished_blackstone
fill 283 193 207 283 196 207 minecraft:red_nether_bricks
setblock 283 193 211 minecraft:polished_blackstone
fill 283 193 212 283 196 212 minecraft:red_nether_bricks
setblock 283 193 215 minecraft:red_nether_bricks
setblock 283 193 216 minecraft:polished_blackstone
fill 283 193 217 283 196 217 minecraft:red_nether_bricks
setblock 284 193 185 minecraft:polished_blackstone
fill 284 193 186 284 196 186 minecraft:red_nether_bricks
setblock 284 193 190 minecraft:polished_blackstone
fill 284 193 191 284 196 191 minecraft:red_nether_bricks
setblock 284 193 195 minecraft:polished_blackstone
fill 284 193 196 284 196 196 minecraft:red_nether_bricks
setblock 284 193 210 minecraft:polished_blackstone
fill 284 193 211 284 194 211 minecraft:red_nether_bricks
setblock 285 193 184 minecraft:polished_blackstone
fill 285 193 185 285 194 185 minecraft:red_nether_bricks
setblock 285 193 189 minecraft:polished_blackstone
fill 285 193 190 285 196 190 minecraft:red_nether_bricks
setblock 285 193 194 minecraft:polished_blackstone
setblock 286 193 183 minecraft:polished_blackstone
setblock 286 193 184 minecraft:red_nether_bricks
setblock 286 193 188 minecraft:polished_blackstone
setblock 286 193 189 minecraft:red_nether_bricks
setblock 287 193 182 minecraft:polished_blackstone
setblock 287 193 183 minecraft:red_nether_bricks
fill 287 193 223 287 307 223 minecraft:nether_bricks
fill 288 193 182 289 194 182 minecraft:red_nether_bricks
fill 289 193 181 289 307 181 minecraft:nether_bricks
fill 293 193 181 294 307 181 minecraft:nether_bricks
fill 296 193 223 296 307 223 minecraft:nether_bricks
setblock 298 193 182 minecraft:red_nether_bricks
fill 299 193 222 299 195 222 minecraft:red_nether_bricks
fill 299 193 223 299 307 223 minecraft:nether_bricks
setblock 301 193 222 minecraft:red_nether_bricks
setblock 302 193 182 minecraft:polished_blackstone
setblock 302 193 222 minecraft:polished_blackstone
fill 303 193 182 303 195 182 minecraft:red_nether_bricks
setblock 303 193 221 minecraft:polished_blackstone
fill 303 193 222 303 196 222 minecraft:red_nether_bricks
fill 304 193 221 304 196 221 minecraft:red_nether_bricks
fill 306 193 223 306 307 223 minecraft:nether_bricks
setblock 307 193 222 minecraft:polished_blackstone
fill 312 193 223 312 307 223 minecraft:nether_bricks
fill 316 193 181 316 307 181 minecraft:nether_bricks
fill 321 193 190 321 193 192 minecraft:red_nether_bricks
setblock 321 193 208 minecraft:polished_blackstone
fill 321 193 209 321 194 209 minecraft:red_nether_bricks
setblock 322 193 187 minecraft:polished_blackstone
fill 322 193 188 322 193 191 minecraft:red_nether_bricks
setblock 322 193 192 minecraft:polished_blackstone
fill 322 193 193 322 196 193 minecraft:red_nether_bricks
setblock 322 193 196 minecraft:red_nether_bricks
setblock 322 193 197 minecraft:polished_blackstone
fill 322 193 198 322 196 198 minecraft:red_nether_bricks
setblock 322 193 202 minecraft:polished_blackstone
fill 322 193 203 322 194 203 minecraft:red_nether_bricks
setblock 322 193 207 minecraft:polished_blackstone
fill 322 193 208 322 196 208 minecraft:red_nether_bricks
setblock 322 193 212 minecraft:polished_blackstone
fill 322 193 213 322 196 213 minecraft:red_nether_bricks
setblock 323 193 182 minecraft:red_nether_bricks
setblock 323 193 186 minecraft:polished_blackstone
fill 323 193 187 323 196 187 minecraft:red_nether_bricks
setblock 323 193 191 minecraft:polished_blackstone
fill 323 193 192 323 196 192 minecraft:red_nether_bricks
setblock 323 193 196 minecraft:polished_blackstone
fill 323 193 197 323 196 197 minecraft:red_nether_bricks
setblock 323 193 201 minecraft:polished_blackstone
fill 323 193 202 323 196 202 minecraft:red_nether_bricks
setblock 323 193 206 minecraft:polished_blackstone
fill 323 193 207 323 196 207 minecraft:red_nether_bricks
setblock 323 193 211 minecraft:polished_blackstone
fill 323 193 212 323 196 212 minecraft:red_nether_bricks
setblock 323 193 216 minecraft:polished_blackstone
fill 323 193 217 323 196 217 minecraft:red_nether_bricks
fill 324 193 210 324 307 210 minecraft:nether_bricks
fill 324 193 212 324 307 212 minecraft:nether_bricks
setblock 283 194 184 minecraft:red_nether_bricks
setblock 283 194 185 minecraft:polished_blackstone
fill 283 194 186 283 197 186 minecraft:red_nether_bricks
setblock 283 194 190 minecraft:polished_blackstone
fill 283 194 191 283 197 191 minecraft:red_nether_bricks
setblock 283 194 195 minecraft:polished_blackstone
fill 283 194 196 283 197 196 minecraft:red_nether_bricks
setblock 283 194 200 minecraft:polished_blackstone
fill 283 194 201 283 197 201 minecraft:red_nether_bricks
setblock 283 194 205 minecraft:polished_blackstone
fill 283 194 206 283 195 206 minecraft:red_nether_bricks
setblock 283 194 210 minecraft:polished_blackstone
fill 283 194 211 283 197 211 minecraft:red_nether_bricks
setblock 283 194 215 minecraft:polished_blackstone
fill 283 194 216 283 197 216 minecraft:red_nether_bricks
setblock 284 194 184 minecraft:polished_blackstone
fill 284 194 185 284 197 185 minecraft:red_nether_bricks
setblock 284 194 189 minecraft:polished_blackstone
fill 284 194 190 284 197 190 minecraft:red_nether_bricks
setblock 284 194 194 minecraft:polished_blackstone
fill 284 194 195 284 197 195 minecraft:red_nether_bricks
setblock 284 194 210 minecraft:red_nether_bricks
setblock 285 194 183 minecraft:polished_blackstone
setblock 285 194 188 minecraft:polished_blackstone
fill 285 194 189 285 197 189 minecraft:red_nether_bricks
setblock 285 194 193 minecraft:polished_blackstone
fill 285 194 194 285 197 194 minecraft:red_nether_bricks
setblock 286 194 182 minecraft:polished_blackstone
setblock 286 194 183 minecraft:red_nether_bricks
fill 287 194 182 287 197 182 minecraft:red_nether_bricks
setblock 301 194 182 minecraft:polished_blackstone
setblock 301 194 221 minecraft:red_nether_bricks
setblock 301 194 222 minecraft:polished_blackstone
fill 302 194 182 302 197 182 minecraft:red_nether_bricks
setblock 302 194 221 minecraft:polished_blackstone
fill 302 194 222 302 197 222 minecraft:red_nether_bricks
fill 303 194 221 303 197 221 minecraft:red_nether_bricks
setblock 306 194 222 minecraft:polished_blackstone
setblock 307 194 222 minecraft:red_nether_bricks
fill 321 194 189 321 194 191 minecraft:red_nether_bricks
setblock 321 194 192 minecraft:polished_blackstone
fill 321 194 193 321 196 194 minecraft:red_nether_bricks
setblock 322 194 186 minecraft:polished_blackstone
fill 322 194 187 322 194 190 minecraft:red_nether_bricks
setblock 322 194 191 minecraft:polished_blackstone
fill 322 194 192 322 197 192 minecraft:red_nether_bricks
setblock 322 194 196 minecraft:polished_blackstone
fill 322 194 197 322 197 197 minecraft:red_nether_bricks
setblock 322 194 201 minecraft:polished_blackstone
setblock 322 194 202 minecraft:red_nether_bricks
setblock 322 194 206 minecraft:polished_blackstone
fill 322 194 207 322 197 207 minecraft:red_nether_bricks
setblock 322 194 211 minecraft:polished_blackstone
fill 322 194 212 322 197 212 minecraft:red_nether_bricks
setblock 323 194 185 minecraft:polished_blackstone
fill 323 194 186 323 197 186 minecraft:red_nether_bricks
setblock 323 194 190 minecraft:polished_blackstone
fill 323 194 191 323 197 191 minecraft:red_nether_bricks
setblock 323 194 195 minecraft:polished_blackstone
fill 323 194 196 323 197 196 minecraft:red_nether_bricks
setblock 323 194 200 minecraft:polished_blackstone
fill 323 194 201 323 197 201 minecraft:red_nether_bricks
setblock 323 194 205 minecraft:polished_blackstone
fill 323 194 206 323 197 206 minecraft:red_nether_bricks
setblock 323 194 210 minecraft:polished_blackstone
fill 323 194 211 323 197 211 minecraft:red_nether_bricks
setblock 323 194 215 minecraft:polished_blackstone
fill 323 194 216 323 197 216 minecraft:red_nether_bricks
setblock 283 195 184 minecraft:polished_blackstone
fill 283 195 185 283 198 185 minecraft:red_nether_bricks
setblock 283 195 189 minecraft:polished_blackstone
fill 283 195 190 283 198 190 minecraft:red_nether_bricks
setblock 283 195 194 minecraft:polished_blackstone
fill 283 195 195 283 198 195 minecraft:red_nether_bricks
setblock 283 195 199 minecraft:polished_blackstone
fill 283 195 200 283 198 200 minecraft:red_nether_bricks
setblock 283 195 205 minecraft:red_nether_bricks
setblock 283 195 209 minecraft:polished_blackstone
fill 283 195 210 283 198 210 minecraft:red_nether_bricks
setblock 283 195 214 minecraft:polished_blackstone
fill 283 195 215 283 198 215 minecraft:red_nether_bricks
setblock 283 195 218 minecraft:red_nether_bricks
setblock 284 195 183 minecraft:polished_blackstone
fill 284 195 184 284 198 184 minecraft:red_nether_bricks
setblock 284 195 188 minecraft:polished_blackstone
fill 284 195 189 284 198 189 minecraft:red_nether_bricks
setblock 284 195 193 minecraft:polished_blackstone
fill 284 195 194 284 198 194 minecraft:red_nether_bricks
setblock 284 195 213 minecraft:polished_blackstone
setblock 285 195 182 minecraft:polished_blackstone
setblock 285 195 183 minecraft:red_nether_bricks
setblock 285 195 187 minecraft:polished_blackstone
fill 285 195 188 285 197 188 minecraft:red_nether_bricks
setblock 285 195 192 minecraft:polished_blackstone
fill 285 195 193 285 198 193 minecraft:red_nether_bricks
fill 286 195 182 286 198 182 minecraft:red_nether_bricks
setblock 288 195 182 minecraft:red_nether_bricks
fill 298 195 222 298 196 222 minecraft:red_nether_bricks
setblock 300 195 182 minecraft:polished_blackstone
setblock 300 195 221 minecraft:red_nether_bricks
setblock 300 195 222 minecraft:polished_blackstone
fill 301 195 182 301 198 182 minecraft:red_nether_bricks
setblock 301 195 221 minecraft:polished_blackstone
fill 301 195 222 301 198 222 minecraft:red_nether_bricks
fill 302 195 221 302 198 221 minecraft:red_nether_bricks
setblock 305 195 222 minecraft:polished_blackstone
fill 306 195 222 306 198 222 minecraft:red_nether_bricks
fill 310 195 183 310 195 185 minecraft:polished_blackstone
fill 311 195 183 312 195 183 minecraft:polished_blackstone
fill 311 195 185 312 195 185 minecraft:polished_blackstone
setblock 312 195 184 minecraft:polished_blackstone
fill 321 195 189 321 195 190 minecraft:red_nether_bricks
setblock 321 195 191 minecraft:polished_blackstone
fill 321 195 192 321 198 192 minecraft:red_nether_bricks
setblock 321 195 195 minecraft:red_nether_bricks
setblock 321 195 196 minecraft:polished_blackstone
setblock 321 195 211 minecraft:polished_blackstone
fill 322 195 186 322 195 189 minecraft:red_nether_bricks
setblock 322 195 190 minecraft:polished_blackstone
fill 322 195 191 322 198 191 minecraft:red_nether_bricks
setblock 322 195 195 minecraft:polished_blackstone
fill 322 195 196 322 198 196 minecraft:red_nether_bricks
setblock 322 195 200 minecraft:polished_blackstone
fill 322 195 201 322 198 201 minecraft:red_nether_bricks
setblock 322 195 205 minecraft:polished_blackstone
fill 322 195 206 322 198 206 minecraft:red_nether_bricks
setblock 322 195 210 minecraft:polished_blackstone
fill 322 195 211 322 198 211 minecraft:red_nether_bricks
setblock 322 195 214 minecraft:red_nether_bricks
setblock 322 195 215 minecraft:polished_blackstone
setblock 323 195 184 minecraft:polished_blackstone
fill 323 195 185 323 198 185 minecraft:red_nether_bricks
setblock 323 195 189 minecraft:polished_blackstone
fill 323 195 190 323 198 190 minecraft:red_nether_bricks
setblock 323 195 194 minecraft:polished_blackstone
fill 323 195 195 323 198 195 minecraft:red_nether_bricks
setblock 323 195 199 minecraft:polished_blackstone
fill 323 195 200 323 198 200 minecraft:red_nether_bricks
setblock 323 195 204 minecraft:polished_blackstone
fill 323 195 205 323 198 205 minecraft:red_nether_bricks
setblock 323 195 209 minecraft:polished_blackstone
fill 323 195 210 323 198 210 minecraft:red_nether_bricks
setblock 323 195 214 minecraft:polished_blackstone
fill 323 195 215 323 198 215 minecraft:red_nether_bricks
setblock 323 195 218 minecraft:red_nether_bricks
setblock 283 196 183 minecraft:polished_blackstone
fill 283 196 184 283 199 184 minecraft:red_nether_bricks
setblock 283 196 188 minecraft:polished_blackstone
fill 283 196 189 283 199 189 minecraft:red_nether_bricks
setblock 283 196 193 minecraft:polished_blackstone
fill 283 196 194 283 199 194 minecraft:red_nether_bricks
setblock 283 196 198 minecraft:polished_blackstone
fill 283 196 199 283 199 199 minecraft:red_nether_bricks
setblock 283 196 208 minecraft:polished_blackstone
fill 283 196 209 283 199 209 minecraft:red_nether_bricks
setblock 283 196 213 minecraft:polished_blackstone
fill 283 196 214 284 198 214 minecraft:red_nether_bricks
setblock 283 196 218 minecraft:polished_blackstone
fill 283 196 219 283 198 220 minecraft:red_nether_bricks
setblock 284 196 182 minecraft:polished_blackstone
fill 284 196 183 284 199 183 minecraft:red_nether_bricks
setblock 284 196 187 minecraft:polished_blackstone
fill 284 196 188 284 199 188 minecraft:red_nether_bricks
setblock 284 196 192 minecraft:polished_blackstone
fill 284 196 193 284 199 193 minecraft:red_nether_bricks
setblock 284 196 197 minecraft:polished_blackstone
fill 284 196 213 284 199 213 minecraft:red_nether_bricks
fill 285 196 182 285 199 182 minecraft:red_nether_bricks
setblock 285 196 184 minecraft:light[level=14]
setblock 285 196 187 minecraft:red_nether_bricks
setblock 285 196 191 minecraft:polished_blackstone
fill 285 196 192 285 199 192 minecraft:red_nether_bricks
setblock 285 196 200 minecraft:light[level=14]
setblock 285 196 208 minecraft:light[level=14]
setblock 285 196 216 minecraft:light[level=14]
setblock 293 196 184 minecraft:light[level=14]
setblock 293 196 192 minecraft:light[level=14]
setblock 293 196 200 minecraft:light[level=14]
setblock 293 196 208 minecraft:light[level=14]
setblock 293 196 216 minecraft:light[level=14]
fill 297 196 222 297 197 222 minecraft:red_nether_bricks
setblock 299 196 182 minecraft:polished_blackstone
setblock 299 196 221 minecraft:red_nether_bricks
setblock 299 196 222 minecraft:polished_blackstone
fill 300 196 182 300 199 182 minecraft:red_nether_bricks
setblock 300 196 221 minecraft:polished_blackstone
fill 300 196 222 300 199 222 minecraft:red_nether_bricks
setblock 301 196 184 minecraft:light[level=14]
setblock 301 196 192 minecraft:light[level=14]
setblock 301 196 200 minecraft:light[level=14]
setblock 301 196 208 minecraft:light[level=14]
setblock 301 196 216 minecraft:light[level=14]
fill 301 196 221 301 199 221 minecraft:red_nether_bricks
setblock 304 196 222 minecraft:polished_blackstone
fill 305 196 222 305 199 222 minecraft:red_nether_bricks
setblock 309 196 184 minecraft:light[level=14]
setblock 309 196 192 minecraft:light[level=14]
setblock 309 196 200 minecraft:light[level=14]
setblock 309 196 208 minecraft:light[level=14]
setblock 309 196 216 minecraft:light[level=14]
setblock 317 196 184 minecraft:light[level=14]
setblock 317 196 192 minecraft:light[level=14]
setblock 317 196 200 minecraft:light[level=14]
setblock 317 196 208 minecraft:light[level=14]
setblock 317 196 216 minecraft:light[level=14]
setblock 321 196 189 minecraft:red_nether_bricks
setblock 321 196 190 minecraft:polished_blackstone
fill 321 196 191 321 199 191 minecraft:red_nether_bricks
setblock 321 196 195 minecraft:polished_blackstone
fill 321 196 196 321 198 197 minecraft:red_nether_bricks
fill 322 196 186 322 196 188 minecraft:red_nether_bricks
setblock 322 196 189 minecraft:polished_blackstone
fill 322 196 190 322 199 190 minecraft:red_nether_bricks
setblock 322 196 194 minecraft:polished_blackstone
fill 322 196 195 322 199 195 minecraft:red_nether_bricks
setblock 322 196 199 minecraft:polished_blackstone
fill 322 196 200 322 199 200 minecraft:red_nether_bricks
fill 322 196 202 322 197 202 minecraft:red_nether_bricks
fill 322 196 205 322 199 205 minecraft:red_nether_bricks
setblock 322 196 209 minecraft:polished_blackstone
fill 322 196 210 322 199 210 minecraft:red_nether_bricks
setblock 322 196 214 minecraft:polished_blackstone
fill 322 196 215 322 198 216 minecraft:red_nether_bricks
setblock 323 196 183 minecraft:polished_blackstone
fill 323 196 184 323 199 184 minecraft:red_nether_bricks
setblock 323 196 188 minecraft:polished_blackstone
fill 323 196 189 323 199 189 minecraft:red_nether_bricks
setblock 323 196 193 minecraft:polished_blackstone
fill 323 196 194 323 199 194 minecraft:red_nether_bricks
setblock 323 196 198 minecraft:polished_blackstone
fill 323 196 199 323 199 199 minecraft:red_nether_bricks
setblock 323 196 203 minecraft:polished_blackstone
fill 323 196 204 323 199 204 minecraft:red_nether_bricks
setblock 323 196 208 minecraft:polished_blackstone
fill 323 196 209 323 199 209 minecraft:red_nether_bricks
setblock 323 196 213 minecraft:polished_blackstone
fill 323 196 214 323 199 214 minecraft:red_nether_bricks
setblock 323 196 218 minecraft:polished_blackstone
fill 323 196 219 323 199 219 minecraft:red_nether_bricks
setblock 283 197 182 minecraft:polished_blackstone
fill 283 197 183 283 200 183 minecraft:red_nether_bricks
setblock 283 197 187 minecraft:polished_blackstone
fill 283 197 188 283 200 188 minecraft:red_nether_bricks
setblock 283 197 192 minecraft:polished_blackstone
fill 283 197 193 283 200 193 minecraft:red_nether_bricks
setblock 283 197 197 minecraft:polished_blackstone
fill 283 197 198 284 199 198 minecraft:red_nether_bricks
setblock 283 197 208 minecraft:red_nether_bricks
setblock 283 197 212 minecraft:polished_blackstone
fill 283 197 213 283 200 213 minecraft:red_nether_bricks
setblock 283 197 217 minecraft:polished_blackstone
fill 283 197 218 283 200 218 minecraft:red_nether_bricks
setblock 283 197 221 minecraft:red_nether_bricks
setblock 283 197 222 minecraft:polished_blackstone
fill 284 197 182 284 200 182 minecraft:red_nether_bricks
setblock 284 197 186 minecraft:polished_blackstone
fill 284 197 187 284 200 187 minecraft:red_nether_bricks
setblock 284 197 191 minecraft:polished_blackstone
fill 284 197 192 284 200 192 minecraft:red_nether_bricks
setblock 284 197 196 minecraft:polished_blackstone
fill 284 197 197 284 200 197 minecraft:red_nether_bricks
setblock 284 197 215 minecraft:red_nether_bricks
setblock 284 197 216 minecraft:polished_blackstone
fill 284 197 222 285 199 222 minecraft:red_nether_bricks
setblock 285 197 190 minecraft:polished_blackstone
fill 285 197 191 285 200 191 minecraft:red_nether_bricks
fill 295 197 222 296 198 222 minecraft:red_nether_bricks
fill 297 197 221 298 197 221 minecraft:red_nether_bricks
setblock 298 197 182 minecraft:polished_blackstone
setblock 298 197 222 minecraft:polished_blackstone
fill 299 197 182 299 200 182 minecraft:red_nether_bricks
setblock 299 197 221 minecraft:polished_blackstone
fill 299 197 222 299 200 222 minecraft:red_nether_bricks
setblock 300 197 220 minecraft:polished_blackstone
fill 300 197 221 300 200 221 minecraft:red_nether_bricks
fill 301 197 220 303 198 220 minecraft:red_nether_bricks
setblock 303 197 222 minecraft:polished_blackstone
setblock 304 197 221 minecraft:polished_blackstone
fill 304 197 222 304 200 222 minecraft:red_nether_bricks
fill 305 197 221 305 200 221 minecraft:red_nether_bricks
fill 320 197 193 320 197 194 minecraft:red_nether_bricks
setblock 321 197 189 minecraft:polished_blackstone
fill 321 197 190 321 200 190 minecraft:red_nether_bricks
setblock 321 197 193 minecraft:red_nether_bricks
setblock 321 197 194 minecraft:polished_blackstone
fill 321 197 195 321 200 195 minecraft:red_nether_bricks
setblock 321 197 198 minecraft:red_nether_bricks
setblock 321 197 199 minecraft:polished_blackstone
fill 321 197 212 321 197 213 minecraft:red_nether_bricks
fill 322 197 186 322 197 187 minecraft:red_nether_bricks
setblock 322 197 188 minecraft:polished_blackstone
fill 322 197 189 322 200 189 minecraft:red_nether_bricks
setblock 322 197 193 minecraft:polished_blackstone
fill 322 197 194 322 200 194 minecraft:red_nether_bricks
setblock 322 197 198 minecraft:polished_blackstone
fill 322 197 199 322 200 199 minecraft:red_nether_bricks
setblock 322 197 203 minecraft:polished_blackstone
fill 322 197 204 322 200 204 minecraft:red_nether_bricks
setblock 322 197 208 minecraft:polished_blackstone
fill 322 197 209 322 200 209 minecraft:red_nether_bricks
setblock 322 197 213 minecraft:polished_blackstone
fill 322 197 214 322 200 214 minecraft:red_nether_bricks
setblock 322 197 217 minecraft:red_nether_bricks
fill 323 197 183 323 200 183 minecraft:red_nether_bricks
setblock 323 197 187 minecraft:polished_blackstone
fill 323 197 188 323 200 188 minecraft:red_nether_bricks
setblock 323 197 192 minecraft:polished_blackstone
fill 323 197 193 323 200 193 minecraft:red_nether_bricks
setblock 323 197 197 minecraft:polished_blackstone
fill 323 197 198 323 200 198 minecraft:red_nether_bricks
setblock 323 197 202 minecraft:polished_blackstone
fill 323 197 203 323 200 203 minecraft:red_nether_bricks
setblock 323 197 207 minecraft:polished_blackstone
fill 323 197 208 323 200 208 minecraft:red_nether_bricks
setblock 323 197 212 minecraft:polished_blackstone
fill 323 197 213 323 200 213 minecraft:red_nether_bricks
setblock 323 197 217 minecraft:polished_blackstone
fill 323 197 218 323 200 218 minecraft:red_nether_bricks
fill 323 197 220 323 198 220 minecraft:red_nether_bricks
fill 283 198 182 283 201 182 minecraft:red_nether_bricks
setblock 283 198 186 minecraft:polished_blackstone
fill 283 198 187 283 201 187 minecraft:red_nether_bricks
setblock 283 198 191 minecraft:polished_blackstone
fill 283 198 192 283 201 192 minecraft:red_nether_bricks
setblock 283 198 196 minecraft:polished_blackstone
fill 283 198 197 283 201 197 minecraft:red_nether_bricks
setblock 283 198 201 minecraft:polished_blackstone
fill 283 198 202 283 201 202 minecraft:red_nether_bricks
setblock 283 198 211 minecraft:polished_blackstone
fill 283 198 212 283 201 212 minecraft:red_nether_bricks
setblock 283 198 216 minecraft:polished_blackstone
fill 283 198 217 284 200 217 minecraft:red_nether_bricks
setblock 283 198 221 minecraft:polished_blackstone
fill 283 198 222 283 201 222 minecraft:red_nether_bricks
setblock 284 198 185 minecraft:polished_blackstone
fill 284 198 186 284 201 186 minecraft:red_nether_bricks
setblock 284 198 190 minecraft:polished_blackstone
fill 284 198 191 284 201 191 minecraft:red_nether_bricks
setblock 284 198 195 minecraft:polished_blackstone
fill 284 198 196 284 201 196 minecraft:red_nether_bricks
setblock 284 198 215 minecraft:polished_blackstone
fill 284 198 216 284 201 216 minecraft:red_nether_bricks
fill 284 198 218 284 198 219 minecraft:red_nether_bricks
setblock 285 198 189 minecraft:polished_blackstone
fill 285 198 190 285 199 190 minecraft:red_nether_bricks
setblock 285 198 194 minecraft:polished_blackstone
fill 285 198 195 285 200 195 minecraft:red_nether_bricks
setblock 286 198 222 minecraft:red_nether_bricks
setblock 287 198 182 minecraft:polished_blackstone
fill 293 198 222 294 200 222 minecraft:red_nether_bricks
fill 296 198 221 297 198 221 minecraft:red_nether_bricks
setblock 297 198 182 minecraft:polished_blackstone
setblock 297 198 222 minecraft:polished_blackstone
fill 298 198 182 298 201 182 minecraft:red_nether_bricks
setblock 298 198 220 minecraft:red_nether_bricks
setblock 298 198 221 minecraft:polished_blackstone
fill 298 198 222 298 201 222 minecraft:red_nether_bricks
setblock 299 198 220 minecraft:polished_blackstone
fill 299 198 221 299 201 221 minecraft:red_nether_bricks
fill 300 198 220 300 201 220 minecraft:red_nether_bricks
fill 301 198 219 301 201 219 minecraft:red_nether_bricks
setblock 302 198 182 minecraft:polished_blackstone
setblock 302 198 222 minecraft:polished_blackstone
setblock 303 198 221 minecraft:polished_blackstone
fill 303 198 222 303 201 222 minecraft:red_nether_bricks
setblock 304 198 220 minecraft:polished_blackstone
fill 304 198 221 304 201 221 minecraft:red_nether_bricks
fill 320 198 191 320 198 193 minecraft:red_nether_bricks
setblock 320 198 194 minecraft:polished_blackstone
fill 320 198 195 320 199 197 minecraft:red_nether_bricks
setblock 321 198 182 minecraft:red_nether_bricks
setblock 321 198 188 minecraft:polished_blackstone
fill 321 198 189 321 201 189 minecraft:red_nether_bricks
setblock 321 198 193 minecraft:polished_blackstone
fill 321 198 194 321 201 194 minecraft:red_nether_bricks
setblock 321 198 198 minecraft:polished_blackstone
fill 321 198 199 321 200 200 minecraft:red_nether_bricks
setblock 321 198 212 minecraft:red_nether_bricks
setblock 321 198 213 minecraft:polished_blackstone
fill 321 198 214 321 201 214 minecraft:red_nether_bricks
setblock 322 198 182 minecraft:polished_blackstone
setblock 322 198 186 minecraft:red_nether_bricks
setblock 322 198 187 minecraft:polished_blackstone
fill 322 198 188 322 201 188 minecraft:red_nether_bricks
setblock 322 198 192 minecraft:polished_blackstone
fill 322 198 193 322 201 193 minecraft:red_nether_bricks
setblock 322 198 197 minecraft:polished_blackstone
fill 322 198 198 322 201 198 minecraft:red_nether_bricks
setblock 322 198 202 minecraft:polished_blackstone
fill 322 198 203 322 201 203 minecraft:red_nether_bricks
setblock 322 198 207 minecraft:polished_blackstone
fill 322 198 208 322 200 208 minecraft:red_nether_bricks
setblock 322 198 212 minecraft:polished_blackstone
fill 322 198 213 322 201 213 minecraft:red_nether_bricks
setblock 322 198 217 minecraft:polished_blackstone
fill 322 198 218 322 201 218 minecraft:red_nether_bricks
fill 323 198 182 323 201 182 minecraft:red_nether_bricks
setblock 323 198 186 minecraft:polished_blackstone
fill 323 198 187 323 201 187 minecraft:red_nether_bricks
setblock 323 198 191 minecraft:polished_blackstone
fill 323 198 192 323 201 192 minecraft:red_nether_bricks
setblock 323 198 196 minecraft:polished_blackstone
fill 323 198 197 323 201 197 minecraft:red_nether_bricks
setblock 323 198 201 minecraft:polished_blackstone
fill 323 198 202 323 201 202 minecraft:red_nether_bricks
setblock 323 198 206 minecraft:polished_blackstone
fill 323 198 207 323 201 207 minecraft:red_nether_bricks
setblock 323 198 211 minecraft:polished_blackstone
fill 323 198 212 323 201 212 minecraft:red_nether_bricks
setblock 323 198 216 minecraft:polished_blackstone
fill 323 198 217 323 201 217 minecraft:red_nether_bricks
setblock 323 198 221 minecraft:polished_blackstone
setblock 283 199 185 minecraft:polished_blackstone
fill 283 199 186 283 202 186 minecraft:red_nether_bricks
setblock 283 199 190 minecraft:polished_blackstone
fill 283 199 191 283 202 191 minecraft:red_nether_bricks
setblock 283 199 195 minecraft:polished_blackstone
fill 283 199 196 283 202 196 minecraft:red_nether_bricks
setblock 283 199 200 minecraft:polished_blackstone
fill 283 199 201 283 202 201 minecraft:red_nether_bricks
setblock 283 199 210 minecraft:polished_blackstone
fill 283 199 211 283 202 211 minecraft:red_nether_bricks
setblock 283 199 214 minecraft:red_nether_bricks
setblock 283 199 215 minecraft:polished_blackstone
fill 283 199 216 283 202 216 minecraft:red_nether_bricks
setblock 283 199 219 minecraft:red_nether_bricks
setblock 283 199 220 minecraft:polished_blackstone
fill 283 199 221 284 201 221 minecraft:red_nether_bricks
setblock 284 199 184 minecraft:polished_blackstone
fill 284 199 185 284 202 185 minecraft:red_nether_bricks
setblock 284 199 189 minecraft:polished_blackstone
fill 284 199 190 284 202 190 minecraft:red_nether_bricks
setblock 284 199 194 minecraft:polished_blackstone
fill 284 199 195 284 202 195 minecraft:red_nether_bricks
setblock 284 199 199 minecraft:polished_blackstone
setblock 284 199 214 minecraft:polished_blackstone
fill 284 199 215 284 202 215 minecraft:red_nether_bricks
setblock 284 199 218 minecraft:red_nether_bricks
setblock 284 199 219 minecraft:polished_blackstone
fill 284 199 220 284 202 220 minecraft:red_nether_bricks
setblock 285 199 189 minecraft:red_nether_bricks
setblock 285 199 193 minecraft:polished_blackstone
fill 285 199 194 285 201 194 minecraft:red_nether_bricks
setblock 286 199 182 minecraft:polished_blackstone
setblock 286 199 222 minecraft:polished_blackstone
fill 287 199 182 287 202 182 minecraft:red_nether_bricks
fill 287 199 222 290 199 222 minecraft:red_nether_bricks
setblock 291 199 222 minecraft:polished_blackstone
fill 292 199 222 292 202 222 minecraft:red_nether_bricks
fill 294 199 221 296 199 221 minecraft:red_nether_bricks
setblock 295 199 182 minecraft:red_nether_bricks
setblock 295 199 222 minecraft:red_nether_bricks
setblock 296 199 182 minecraft:polished_blackstone
fill 296 199 220 297 199 220 minecraft:red_nether_bricks
setblock 296 199 222 minecraft:polished_blackstone
fill 297 199 182 297 202 182 minecraft:red_nether_bricks
setblock 297 199 221 minecraft:polished_blackstone
fill 297 199 222 297 202 222 minecraft:red_nether_bricks
setblock 298 199 219 minecraft:red_nether_bricks
setblock 298 199 220 minecraft:polished_blackstone
fill 298 199 221 298 202 221 minecraft:red_nether_bricks
setblock 299 199 219 minecraft:polished_blackstone
fill 299 199 220 299 202 220 minecraft:red_nether_bricks
fill 300 199 219 300 202 219 minecraft:red_nether_bricks
setblock 301 199 182 minecraft:polished_blackstone
fill 301 199 220 302 199 220 minecraft:red_nether_bricks
setblock 301 199 222 minecraft:polished_blackstone
fill 302 199 182 302 202 182 minecraft:red_nether_bricks
fill 302 199 219 303 199 219 minecraft:red_nether_bricks
setblock 302 199 221 minecraft:polished_blackstone
fill 302 199 222 302 202 222 minecraft:red_nether_bricks
setblock 303 199 220 minecraft:polished_blackstone
fill 303 199 221 303 202 221 minecraft:red_nether_bricks
fill 304 199 220 304 202 220 minecraft:red_nether_bricks
setblock 306 199 222 minecraft:polished_blackstone
fill 307 199 222 307 202 222 minecraft:red_nether_bricks
fill 317 199 203 317 199 205 minecraft:polished_blackstone
fill 318 199 202 320 199 202 minecraft:polished_blackstone
fill 318 199 206 320 199 206 minecraft:polished_blackstone
fill 319 199 222 320 199 222 minecraft:red_nether_bricks
setblock 320 199 182 minecraft:red_nether_bricks
fill 320 199 191 320 199 192 minecraft:red_nether_bricks
setblock 320 199 193 minecraft:polished_blackstone
fill 320 199 194 320 202 194 minecraft:red_nether_bricks
setblock 320 199 198 minecraft:polished_blackstone
setblock 321 199 182 minecraft:polished_blackstone
fill 321 199 188 321 202 188 minecraft:red_nether_bricks
setblock 321 199 192 minecraft:polished_blackstone
fill 321 199 193 321 202 193 minecraft:red_nether_bricks
setblock 321 199 196 minecraft:red_nether_bricks
setblock 321 199 197 minecraft:polished_blackstone
fill 321 199 198 321 202 198 minecraft:red_nether_bricks
setblock 321 199 201 minecraft:red_nether_bricks
fill 321 199 203 321 199 205 minecraft:polished_blackstone
setblock 321 199 212 minecraft:polished_blackstone
fill 321 199 213 321 200 213 minecraft:red_nether_bricks
fill 321 199 215 321 199 216 minecraft:red_nether_bricks
setblock 321 199 222 minecraft:polished_blackstone
fill 322 199 182 322 202 182 minecraft:red_nether_bricks
setblock 322 199 185 minecraft:red_nether_bricks
setblock 322 199 186 minecraft:polished_blackstone
fill 322 199 187 322 202 187 minecraft:red_nether_bricks
setblock 322 199 191 minecraft:polished_blackstone
fill 322 199 192 322 202 192 minecraft:red_nether_bricks
setblock 322 199 196 minecraft:polished_blackstone
fill 322 199 197 322 202 197 minecraft:red_nether_bricks
setblock 322 199 201 minecraft:polished_blackstone
fill 322 199 202 322 202 202 minecraft:red_nether_bricks
setblock 322 199 206 minecraft:polished_blackstone
setblock 322 199 207 minecraft:red_nether_bricks
setblock 322 199 211 minecraft:polished_blackstone
fill 322 199 212 322 202 212 minecraft:red_nether_bricks
setblock 322 199 215 minecraft:red_nether_bricks
setblock 322 199 216 minecraft:polished_blackstone
fill 322 199 217 322 202 217 minecraft:red_nether_bricks
fill 322 199 219 322 200 219 minecraft:red_nether_bricks
fill 322 199 222 323 201 222 minecraft:red_nether_bricks
setblock 323 199 185 minecraft:polished_blackstone
fill 323 199 186 323 202 186 minecraft:red_nether_bricks
setblock 323 199 190 minecraft:polished_blackstone
fill 323 199 191 323 202 191 minecraft:red_nether_bricks
setblock 323 199 195 minecraft:polished_blackstone
fill 323 199 196 323 202 196 minecraft:red_nether_bricks
setblock 323 199 200 minecraft:polished_blackstone
fill 323 199 201 323 202 201 minecraft:red_nether_bricks
setblock 323 199 205 minecraft:polished_blackstone
fill 323 199 206 323 202 206 minecraft:red_nether_bricks
setblock 323 199 210 minecraft:polished_blackstone
fill 323 199 211 323 202 211 minecraft:red_nether_bricks
setblock 323 199 215 minecraft:polished_blackstone
fill 323 199 216 323 202 216 minecraft:red_nether_bricks
setblock 323 199 220 minecraft:polished_blackstone
fill 323 199 221 323 202 221 minecraft:red_nether_bricks
setblock 283 200 184 minecraft:polished_blackstone
fill 283 200 185 283 203 185 minecraft:red_nether_bricks
setblock 283 200 189 minecraft:polished_blackstone
fill 283 200 190 283 203 190 minecraft:red_nether_bricks
setblock 283 200 194 minecraft:polished_blackstone
fill 283 200 195 283 203 195 minecraft:red_nether_bricks
setblock 283 200 198 minecraft:red_nether_bricks
setblock 283 200 199 minecraft:polished_blackstone
fill 283 200 200 283 203 200 minecraft:red_nether_bricks
setblock 283 200 210 minecraft:red_nether_bricks
setblock 283 200 214 minecraft:polished_blackstone
fill 283 200 215 283 203 215 minecraft:red_nether_bricks
setblock 283 200 219 minecraft:polished_blackstone
fill 283 200 220 283 203 220 minecraft:red_nether_bricks
setblock 284 200 183 minecraft:polished_blackstone
fill 284 200 184 284 202 184 minecraft:red_nether_bricks
setblock 284 200 188 minecraft:polished_blackstone
fill 284 200 189 284 202 189 minecraft:red_nether_bricks
setblock 284 200 193 minecraft:polished_blackstone
fill 284 200 194 284 203 194 minecraft:red_nether_bricks
setblock 284 200 198 minecraft:polished_blackstone
fill 284 200 199 284 203 199 minecraft:red_nether_bricks
fill 284 200 214 284 201 214 minecraft:red_nether_bricks
setblock 284 200 218 minecraft:polished_blackstone
fill 284 200 219 284 203 219 minecraft:red_nether_bricks
setblock 284 200 222 minecraft:red_nether_bricks
setblock 285 200 182 minecraft:polished_blackstone
setblock 285 200 192 minecraft:polished_blackstone
fill 285 200 193 285 201 193 minecraft:red_nether_bricks
setblock 285 200 221 minecraft:red_nether_bricks
setblock 285 200 222 minecraft:polished_blackstone
fill 286 200 182 286 203 182 minecraft:red_nether_bricks
setblock 286 200 221 minecraft:polished_blackstone
fill 286 200 222 289 200 222 minecraft:red_nether_bricks
fill 288 200 182 288 201 182 minecraft:red_nether_bricks
setblock 290 200 222 minecraft:polished_blackstone
fill 291 200 222 291 203 222 minecraft:red_nether_bricks
fill 292 200 221 295 200 221 minecraft:red_nether_bricks
fill 293 200 182 294 200 182 minecraft:red_nether_bricks
fill 294 200 220 296 200 220 minecraft:red_nether_bricks
setblock 295 200 182 minecraft:polished_blackstone
setblock 295 200 222 minecraft:polished_blackstone
fill 296 200 182 296 203 182 minecraft:red_nether_bricks
fill 296 200 219 297 200 219 minecraft:red_nether_bricks
setblock 296 200 221 minecraft:polished_blackstone
fill 296 200 222 296 203 222 minecraft:red_nether_bricks
setblock 297 200 220 minecraft:polished_blackstone
fill 297 200 221 297 203 221 minecraft:red_nether_bricks
setblock 298 200 219 minecraft:polished_blackstone
fill 298 200 220 298 203 220 minecraft:red_nether_bricks
setblock 299 200 218 minecraft:polished_blackstone
fill 299 200 219 299 203 219 minecraft:red_nether_bricks
setblock 300 200 182 minecraft:polished_blackstone
fill 300 200 218 301 202 218 minecraft:red_nether_bricks
setblock 300 200 222 minecraft:polished_blackstone
fill 301 200 182 301 203 182 minecraft:red_nether_bricks
setblock 301 200 220 minecraft:red_nether_bricks
setblock 301 200 221 minecraft:polished_blackstone
fill 301 200 222 301 203 222 minecraft:red_nether_bricks
setblock 302 200 219 minecraft:red_nether_bricks
setblock 302 200 220 minecraft:polished_blackstone
fill 302 200 221 302 203 221 minecraft:red_nether_bricks
fill 303 200 182 303 201 182 minecraft:red_nether_bricks
setblock 303 200 219 minecraft:polished_blackstone
fill 303 200 220 303 203 220 minecraft:red_nether_bricks
fill 305 200 220 305 201 220 minecraft:red_nether_bricks
setblock 305 200 222 minecraft:polished_blackstone
setblock 306 200 221 minecraft:polished_blackstone
fill 306 200 222 306 203 222 minecraft:red_nether_bricks
fill 310 200 183 310 200 185 minecraft:polished_blackstone
fill 311 200 183 312 200 183 minecraft:polished_blackstone
fill 311 200 185 312 200 185 minecraft:polished_blackstone
setblock 312 200 184 minecraft:polished_blackstone
fill 316 200 222 319 200 222 minecraft:red_nether_bricks
fill 318 200 182 319 200 182 minecraft:red_nether_bricks
fill 319 200 194 319 201 196 minecraft:red_nether_bricks
fill 319 200 221 320 200 221 minecraft:red_nether_bricks
setblock 320 200 182 minecraft:polished_blackstone
fill 320 200 190 320 200 191 minecraft:red_nether_bricks
setblock 320 200 192 minecraft:polished_blackstone
fill 320 200 193 320 203 193 minecraft:red_nether_bricks
fill 320 200 195 320 200 196 minecraft:red_nether_bricks
setblock 320 200 197 minecraft:polished_blackstone
fill 320 200 198 320 201 200 minecraft:red_nether_bricks
setblock 320 200 222 minecraft:polished_blackstone
fill 321 200 182 321 203 182 minecraft:red_nether_bricks
setblock 321 200 191 minecraft:polished_blackstone
fill 321 200 192 321 203 192 minecraft:red_nether_bricks
setblock 321 200 196 minecraft:polished_blackstone
fill 321 200 197 321 203 197 minecraft:red_nether_bricks
setblock 321 200 201 minecraft:polished_blackstone
fill 321 200 202 321 203 202 minecraft:red_nether_bricks
setblock 321 200 215 minecraft:red_nether_bricks
setblock 321 200 216 minecraft:polished_blackstone
fill 321 200 217 321 202 217 minecraft:red_nether_bricks
setblock 321 200 221 minecraft:polished_blackstone
fill 321 200 222 321 203 222 minecraft:red_nether_bricks
setblock 322 200 185 minecraft:polished_blackstone
fill 322 200 186 322 203 186 minecraft:red_nether_bricks
setblock 322 200 190 minecraft:polished_blackstone
fill 322 200 191 322 203 191 minecraft:red_nether_bricks
setblock 322 200 195 minecraft:polished_blackstone
fill 322 200 196 322 203 196 minecraft:red_nether_bricks
setblock 322 200 200 minecraft:polished_blackstone
fill 322 200 201 322 203 201 minecraft:red_nether_bricks
setblock 322 200 205 minecraft:polished_blackstone
setblock 322 200 210 minecraft:polished_blackstone
fill 322 200 211 322 201 211 minecraft:red_nether_bricks
setblock 322 200 215 minecraft:polished_blackstone
fill 322 200 216 322 203 216 minecraft:red_nether_bricks
setblock 322 200 220 minecraft:polished_blackstone
setblock 323 200 184 minecraft:polished_blackstone
fill 323 200 185 323 203 185 minecraft:red_nether_bricks
setblock 323 200 189 minecraft:polished_blackstone
fill 323 200 190 323 203 190 minecraft:red_nether_bricks
setblock 323 200 194 minecraft:polished_blackstone
fill 323 200 195 323 203 195 minecraft:red_nether_bricks
setblock 323 200 199 minecraft:polished_blackstone
fill 323 200 200 323 203 200 minecraft:red_nether_bricks
setblock 323 200 204 minecraft:polished_blackstone
fill 323 200 205 323 203 205 minecraft:red_nether_bricks
setblock 323 200 209 minecraft:polished_blackstone
fill 323 200 210 323 202 210 minecraft:red_nether_bricks
setblock 323 200 214 minecraft:polished_blackstone
fill 323 200 215 323 203 215 minecraft:red_nether_bricks
setblock 323 200 219 minecraft:polished_blackstone
fill 323 200 220 323 203 220 minecraft:red_nether_bricks
setblock 283 201 183 minecraft:polished_blackstone
fill 283 201 184 283 204 184 minecraft:red_nether_bricks
setblock 283 201 188 minecraft:polished_blackstone
fill 283 201 189 283 204 189 minecraft:red_nether_bricks
setblock 283 201 193 minecraft:polished_blackstone
fill 283 201 194 283 204 194 minecraft:red_nether_bricks
setblock 283 201 198 minecraft:polished_blackstone
fill 283 201 199 283 204 199 minecraft:red_nether_bricks
setblock 283 201 203 minecraft:polished_blackstone
setblock 283 201 213 minecraft:polished_blackstone
fill 283 201 214 283 204 214 minecraft:red_nether_bricks
setblock 283 201 217 minecraft:red_nether_bricks
setblock 283 201 218 minecraft:polished_blackstone
fill 283 201 219 283 204 219 minecraft:red_nether_bricks
setblock 284 201 182 minecraft:polished_blackstone
fill 284 201 183 284 204 183 minecraft:red_nether_bricks
setblock 284 201 187 minecraft:polished_blackstone
fill 284 201 188 284 202 188 minecraft:red_nether_bricks
setblock 284 201 192 minecraft:polished_blackstone
fill 284 201 193 284 203 193 minecraft:red_nether_bricks
setblock 284 201 197 minecraft:polished_blackstone
fill 284 201 198 284 204 198 minecraft:red_nether_bricks
setblock 284 201 217 minecraft:polished_blackstone
fill 284 201 218 284 204 218 minecraft:red_nether_bricks
setblock 284 201 222 minecraft:polished_blackstone
fill 285 201 182 285 204 182 minecraft:red_nether_bricks
setblock 285 201 221 minecraft:polished_blackstone
fill 285 201 222 288 201 222 minecraft:red_nether_bricks
fill 286 201 221 289 201 221 minecraft:red_nether_bricks
setblock 289 201 182 minecraft:polished_blackstone
setblock 289 201 222 minecraft:polished_blackstone
fill 290 201 182 293 201 182 minecraft:red_nether_bricks
setblock 290 201 221 minecraft:polished_blackstone
fill 290 201 222 290 204 222 minecraft:red_nether_bricks
fill 291 201 221 294 201 221 minecraft:red_nether_bricks
fill 293 201 220 295 201 220 minecraft:red_nether_bricks
setblock 293 201 222 minecraft:red_nether_bricks
setblock 294 201 182 minecraft:polished_blackstone
setblock 294 201 222 minecraft:polished_blackstone
fill 295 201 182 295 204 182 minecraft:red_nether_bricks
fill 295 201 219 296 201 219 minecraft:red_nether_bricks
setblock 295 201 221 minecraft:polished_blackstone
fill 295 201 222 295 204 222 minecraft:red_nether_bricks
setblock 296 201 220 minecraft:polished_blackstone
fill 296 201 221 296 204 221 minecraft:red_nether_bricks
setblock 297 201 218 minecraft:red_nether_bricks
setblock 297 201 219 minecraft:polished_blackstone
fill 297 201 220 297 204 220 minecraft:red_nether_bricks
setblock 298 201 218 minecraft:polished_blackstone
fill 298 201 219 298 204 219 minecraft:red_nether_bricks
setblock 299 201 182 minecraft:polished_blackstone
fill 299 201 218 299 204 218 minecraft:red_nether_bricks
setblock 299 201 222 minecraft:polished_blackstone
fill 300 201 182 300 204 182 minecraft:red_nether_bricks
setblock 300 201 221 minecraft:polished_blackstone
fill 300 201 222 300 204 222 minecraft:red_nether_bricks
setblock 301 201 220 minecraft:polished_blackstone
fill 301 201 221 301 204 221 minecraft:red_nether_bricks
setblock 302 201 219 minecraft:polished_blackstone
fill 302 201 220 302 204 220 minecraft:red_nether_bricks
fill 303 201 219 303 202 219 minecraft:red_nether_bricks
setblock 304 201 222 minecraft:polished_blackstone
setblock 305 201 221 minecraft:polished_blackstone
fill 305 201 222 305 204 222 minecraft:red_nether_bricks
fill 306 201 221 306 203 221 minecraft:red_nether_bricks
setblock 314 201 222 minecraft:polished_blackstone
fill 315 201 222 318 201 222 minecraft:red_nether_bricks
fill 317 201 182 318 201 182 minecraft:red_nether_bricks
fill 317 201 221 319 201 221 minecraft:red_nether_bricks
setblock 319 201 182 minecraft:polished_blackstone
setblock 319 201 197 minecraft:polished_blackstone
fill 319 201 198 319 204 198 minecraft:red_nether_bricks
setblock 319 201 222 minecraft:polished_blackstone
fill 320 201 182 320 203 183 minecraft:red_nether_bricks
setblock 320 201 190 minecraft:red_nether_bricks
setblock 320 201 191 minecraft:polished_blackstone
fill 320 201 192 320 203 192 minecraft:red_nether_bricks
setblock 320 201 195 minecraft:red_nether_bricks
setblock 320 201 196 minecraft:polished_blackstone
fill 320 201 197 320 204 197 minecraft:red_nether_bricks
setblock 320 201 221 minecraft:polished_blackstone
fill 320 201 222 320 204 222 minecraft:red_nether_bricks
fill 321 201 183 322 201 183 minecraft:red_nether_bricks
setblock 321 201 190 minecraft:polished_blackstone
fill 321 201 191 321 204 191 minecraft:red_nether_bricks
setblock 321 201 195 minecraft:polished_blackstone
fill 321 201 196 321 204 196 minecraft:red_nether_bricks
setblock 321 201 199 minecraft:red_nether_bricks
setblock 321 201 200 minecraft:polished_blackstone
fill 321 201 201 321 204 201 minecraft:red_nether_bricks
setblock 321 201 215 minecraft:polished_blackstone
fill 321 201 216 321 202 216 minecraft:red_nether_bricks
fill 321 201 218 321 202 218 minecraft:red_nether_bricks
fill 321 201 221 322 203 221 minecraft:red_nether_bricks
setblock 322 201 184 minecraft:polished_blackstone
fill 322 201 185 322 204 185 minecraft:red_nether_bricks
setblock 322 201 189 minecraft:polished_blackstone
fill 322 201 190 322 204 190 minecraft:red_nether_bricks
setblock 322 201 194 minecraft:polished_blackstone
fill 322 201 195 322 204 195 minecraft:red_nether_bricks
setblock 322 201 199 minecraft:polished_blackstone
fill 322 201 200 322 204 200 minecraft:red_nether_bricks
setblock 322 201 204 minecraft:polished_blackstone
setblock 322 201 205 minecraft:red_nether_bricks
setblock 322 201 210 minecraft:red_nether_bricks
setblock 322 201 214 minecraft:polished_blackstone
fill 322 201 215 322 203 215 minecraft:red_nether_bricks
setblock 322 201 219 minecraft:polished_blackstone
fill 322 201 220 322 204 220 minecraft:red_nether_bricks
setblock 323 201 183 minecraft:polished_blackstone
fill 323 201 184 323 204 184 minecraft:red_nether_bricks
setblock 323 201 188 minecraft:polished_blackstone
fill 323 201 189 323 204 189 minecraft:red_nether_bricks
setblock 323 201 193 minecraft:polished_blackstone
fill 323 201 194 323 204 194 minecraft:red_nether_bricks
setblock 323 201 198 minecraft:polished_blackstone
fill 323 201 199 323 204 199 minecraft:red_nether_bricks
setblock 323 201 203 minecraft:polished_blackstone
fill 323 201 204 323 204 204 minecraft:red_nether_bricks
setblock 323 201 208 minecraft:polished_blackstone
fill 323 201 209 323 202 209 minecraft:red_nether_bricks
setblock 323 201 213 minecraft:polished_blackstone
fill 323 201 214 323 204 214 minecraft:red_nether_bricks
setblock 323 201 218 minecraft:polished_blackstone
fill 323 201 219 323 204 219 minecraft:red_nether_bricks
setblock 283 202 182 minecraft:polished_blackstone
fill 283 202 183 283 205 183 minecraft:red_nether_bricks
setblock 283 202 187 minecraft:polished_blackstone
fill 283 202 188 283 205 188 minecraft:red_nether_bricks
setblock 283 202 192 minecraft:polished_blackstone
fill 283 202 193 283 205 193 minecraft:red_nether_bricks
setblock 283 202 197 minecraft:polished_blackstone
fill 283 202 198 283 205 198 minecraft:red_nether_bricks
setblock 283 202 202 minecraft:polished_blackstone
setblock 283 202 203 minecraft:red_nether_bricks
setblock 283 202 212 minecraft:polished_blackstone
fill 283 202 213 283 203 213 minecraft:red_nether_bricks
setblock 283 202 217 minecraft:polished_blackstone
fill 283 202 218 283 205 218 minecraft:red_nether_bricks
setblock 283 202 221 minecraft:red_nether_bricks
setblock 283 202 222 minecraft:polished_blackstone
fill 284 202 182 284 205 182 minecraft:red_nether_bricks
setblock 284 202 186 minecraft:polished_blackstone
setblock 284 202 187 minecraft:red_nether_bricks
setblock 284 202 191 minecraft:polished_blackstone
fill 284 202 192 284 203 192 minecraft:red_nether_bricks
setblock 284 202 196 minecraft:polished_blackstone
fill 284 202 197 284 204 197 minecraft:red_nether_bricks
setblock 284 202 216 minecraft:polished_blackstone
fill 284 202 217 284 204 217 minecraft:red_nether_bricks
setblock 284 202 221 minecraft:polished_blackstone
fill 284 202 222 287 202 222 minecraft:red_nether_bricks
fill 285 202 221 288 202 221 minecraft:red_nether_bricks
setblock 288 202 182 minecraft:polished_blackstone
setblock 288 202 222 minecraft:polished_blackstone
fill 289 202 182 292 202 182 minecraft:red_nether_bricks
setblock 289 202 221 minecraft:polished_blackstone
fill 289 202 222 289 205 222 minecraft:red_nether_bricks
fill 290 202 221 293 202 221 minecraft:red_nether_bricks
fill 291 202 220 294 202 220 minecraft:red_nether_bricks
setblock 293 202 182 minecraft:polished_blackstone
setblock 293 202 222 minecraft:polished_blackstone
fill 294 202 182 294 205 182 minecraft:red_nether_bricks
fill 294 202 219 295 202 219 minecraft:red_nether_bricks
setblock 294 202 221 minecraft:polished_blackstone
fill 294 202 222 294 205 222 minecraft:red_nether_bricks
setblock 295 202 220 minecraft:polished_blackstone
fill 295 202 221 295 205 221 minecraft:red_nether_bricks
setblock 296 202 219 minecraft:polished_blackstone
fill 296 202 220 296 205 220 minecraft:red_nether_bricks
setblock 297 202 183 minecraft:polished_blackstone
setblock 297 202 218 minecraft:polished_blackstone
fill 297 202 219 297 205 219 minecraft:red_nether_bricks
setblock 298 202 182 minecraft:polished_blackstone
fill 298 202 183 298 204 183 minecraft:red_nether_bricks
fill 298 202 218 298 204 218 minecraft:red_nether_bricks
setblock 298 202 222 minecraft:polished_blackstone
fill 299 202 182 299 205 182 minecraft:red_nether_bricks
setblock 299 202 221 minecraft:polished_blackstone
fill 299 202 222 299 205 222 minecraft:red_nether_bricks
setblock 300 202 220 minecraft:polished_blackstone
fill 300 202 221 300 205 221 minecraft:red_nether_bricks
setblock 301 202 219 minecraft:polished_blackstone
fill 301 202 220 301 205 220 minecraft:red_nether_bricks
fill 302 202 219 302 204 219 minecraft:red_nether_bricks
setblock 303 202 182 minecraft:polished_blackstone
setblock 303 202 222 minecraft:polished_blackstone
setblock 304 202 221 minecraft:polished_blackstone
fill 304 202 222 304 205 222 minecraft:red_nether_bricks
setblock 305 202 220 minecraft:polished_blackstone
fill 305 202 221 305 204 221 minecraft:red_nether_bricks
setblock 308 202 222 minecraft:polished_blackstone
setblock 313 202 222 minecraft:polished_blackstone
fill 314 202 222 317 202 222 minecraft:red_nether_bricks
fill 315 202 221 318 202 221 minecraft:red_nether_bricks
fill 316 202 182 317 202 182 minecraft:red_nether_bricks
setblock 318 202 182 minecraft:polished_blackstone
setblock 318 202 222 minecraft:polished_blackstone
fill 319 202 182 319 204 183 minecraft:red_nether_bricks
fill 319 202 194 319 202 195 minecraft:red_nether_bricks
setblock 319 202 196 minecraft:polished_blackstone
fill 319 202 197 319 204 197 minecraft:red_nether_bricks
setblock 319 202 221 minecraft:polished_blackstone
fill 319 202 222 319 205 222 minecraft:red_nether_bricks
fill 320 202 191 320 203 191 minecraft:red_nether_bricks
setblock 320 202 195 minecraft:polished_blackstone
fill 320 202 196 320 205 196 minecraft:red_nether_bricks
fill 320 202 198 320 202 199 minecraft:red_nether_bricks
setblock 320 202 200 minecraft:polished_blackstone
fill 320 202 201 320 204 201 minecraft:red_nether_bricks
fill 320 202 221 320 205 221 minecraft:red_nether_bricks
setblock 321 202 183 minecraft:red_nether_bricks
setblock 321 202 189 minecraft:polished_blackstone
fill 321 202 190 321 204 190 minecraft:red_nether_bricks
setblock 321 202 194 minecraft:polished_blackstone
fill 321 202 195 321 205 195 minecraft:red_nether_bricks
setblock 321 202 199 minecraft:polished_blackstone
fill 321 202 200 321 205 200 minecraft:red_nether_bricks
setblock 321 202 203 minecraft:red_nether_bricks
setblock 322 202 183 minecraft:polished_blackstone
fill 322 202 184 322 204 184 minecraft:red_nether_bricks
setblock 322 202 188 minecraft:polished_blackstone
fill 322 202 189 322 205 189 minecraft:red_nether_bricks
setblock 322 202 193 minecraft:polished_blackstone
fill 322 202 194 322 205 194 minecraft:red_nether_bricks
setblock 322 202 198 minecraft:polished_blackstone
fill 322 202 199 322 205 199 minecraft:red_nether_bricks
setblock 322 202 203 minecraft:polished_blackstone
fill 322 202 204 322 204 204 minecraft:red_nether_bricks
setblock 322 202 213 minecraft:polished_blackstone
fill 322 202 214 322 203 214 minecraft:red_nether_bricks
setblock 322 202 218 minecraft:polished_blackstone
fill 322 202 219 322 205 219 minecraft:red_nether_bricks
setblock 322 202 222 minecraft:red_nether_bricks
setblock 323 202 182 minecraft:polished_blackstone
fill 323 202 183 323 205 183 minecraft:red_nether_bricks
setblock 323 202 187 minecraft:polished_blackstone
fill 323 202 188 323 205 188 minecraft:red_nether_bricks
setblock 323 202 192 minecraft:polished_blackstone
fill 323 202 193 323 205 193 minecraft:red_nether_bricks
setblock 323 202 197 minecraft:polished_blackstone
fill 323 202 198 323 205 198 minecraft:red_nether_bricks
setblock 323 202 202 minecraft:polished_blackstone
fill 323 202 203 323 205 203 minecraft:red_nether_bricks
setblock 323 202 207 minecraft:polished_blackstone
setblock 323 202 208 minecraft:red_nether_bricks
setblock 323 202 212 minecraft:polished_blackstone
fill 323 202 213 323 203 213 minecraft:red_nether_bricks
setblock 323 202 217 minecraft:polished_blackstone
fill 323 202 218 323 205 218 minecraft:red_nether_bricks
setblock 323 202 222 minecraft:polished_blackstone
fill 283 203 182 283 206 182 minecraft:red_nether_bricks
setblock 283 203 186 minecraft:polished_blackstone
fill 283 203 187 283 205 187 minecraft:red_nether_bricks
setblock 283 203 191 minecraft:polished_blackstone
fill 283 203 192 283 205 192 minecraft:red_nether_bricks
setblock 283 203 196 minecraft:polished_blackstone
fill 283 203 197 283 206 197 minecraft:red_nether_bricks
setblock 283 203 201 minecraft:polished_blackstone
fill 283 203 202 283 204 202 minecraft:red_nether_bricks
setblock 283 203 216 minecraft:polished_blackstone
fill 283 203 217 283 206 217 minecraft:red_nether_bricks
setblock 283 203 221 minecraft:polished_blackstone
fill 283 203 222 286 203 222 minecraft:red_nether_bricks
setblock 284 203 190 minecraft:polished_blackstone
setblock 284 203 191 minecraft:red_nether_bricks
setblock 284 203 195 minecraft:polished_blackstone
fill 284 203 196 284 204 196 minecraft:red_nether_bricks
setblock 284 203 216 minecraft:red_nether_bricks
setblock 284 203 220 minecraft:polished_blackstone
fill 284 203 221 287 203 221 minecraft:red_nether_bricks
setblock 287 203 182 minecraft:polished_blackstone
setblock 287 203 222 minecraft:polished_blackstone
fill 288 203 182 291 203 182 minecraft:red_nether_bricks
setblock 288 203 221 minecraft:polished_blackstone
fill 288 203 222 288 206 222 minecraft:red_nether_bricks
fill 289 203 221 292 203 221 minecraft:red_nether_bricks
fill 290 203 220 293 203 220 minecraft:red_nether_bricks
setblock 292 203 182 minecraft:polished_blackstone
setblock 292 203 222 minecraft:polished_blackstone
fill 293 203 182 293 206 182 minecraft:red_nether_bricks
fill 293 203 219 294 203 219 minecraft:red_nether_bricks
setblock 293 203 221 minecraft:polished_blackstone
fill 293 203 222 293 206 222 minecraft:red_nether_bricks
setblock 294 203 220 minecraft:polished_blackstone
fill 294 203 221 294 206 221 minecraft:red_nether_bricks
setblock 295 203 219 minecraft:polished_blackstone
fill 295 203 220 295 206 220 minecraft:red_nether_bricks
setblock 296 203 183 minecraft:polished_blackstone
setblock 296 203 218 minecraft:polished_blackstone
fill 296 203 219 296 206 219 minecraft:red_nether_bricks
setblock 297 203 182 minecraft:polished_blackstone
fill 297 203 183 297 205 183 minecraft:red_nether_bricks
fill 297 203 218 297 204 218 minecraft:red_nether_bricks
setblock 297 203 222 minecraft:polished_blackstone
fill 298 203 182 298 206 182 minecraft:red_nether_bricks
setblock 298 203 221 minecraft:polished_blackstone
fill 298 203 222 298 206 222 minecraft:red_nether_bricks
setblock 299 203 220 minecraft:polished_blackstone
fill 299 203 221 299 206 221 minecraft:red_nether_bricks
setblock 300 203 218 minecraft:red_nether_bricks
setblock 300 203 219 minecraft:polished_blackstone
fill 300 203 220 300 206 220 minecraft:red_nether_bricks
fill 301 203 219 301 205 219 minecraft:red_nether_bricks
setblock 302 203 182 minecraft:polished_blackstone
setblock 302 203 222 minecraft:polished_blackstone
setblock 303 203 221 minecraft:polished_blackstone
fill 303 203 222 303 206 222 minecraft:red_nether_bricks
setblock 304 203 220 minecraft:polished_blackstone
fill 304 203 221 304 205 221 minecraft:red_nether_bricks
setblock 307 203 222 minecraft:polished_blackstone
fill 308 203 222 308 204 222 minecraft:red_nether_bricks
setblock 311 203 222 minecraft:red_nether_bricks
setblock 312 203 222 minecraft:polished_blackstone
fill 313 203 222 316 203 222 minecraft:red_nether_bricks
fill 314 203 221 317 203 221 minecraft:red_nether_bricks
fill 315 203 182 316 203 182 minecraft:red_nether_bricks
setblock 317 203 182 minecraft:polished_blackstone
setblock 317 203 222 minecraft:polished_blackstone
fill 318 203 182 318 205 183 minecraft:red_nether_bricks
setblock 318 203 220 minecraft:red_nether_bricks
setblock 318 203 221 minecraft:polished_blackstone
fill 318 203 222 318 206 222 minecraft:red_nether_bricks
setblock 319 203 194 minecraft:red_nether_bricks
setblock 319 203 195 minecraft:polished_blackstone
fill 319 203 196 319 204 196 minecraft:red_nether_bricks
setblock 319 203 199 minecraft:red_nether_bricks
setblock 319 203 220 minecraft:polished_blackstone
fill 319 203 221 319 206 221 minecraft:red_nether_bricks
setblock 320 203 194 minecraft:polished_blackstone
fill 320 203 195 320 205 195 minecraft:red_nether_bricks
setblock 320 203 198 minecraft:red_nether_bricks
setblock 320 203 199 minecraft:polished_blackstone
fill 320 203 200 320 205 200 minecraft:red_nether_bricks
setblock 321 203 183 minecraft:polished_blackstone
setblock 321 203 189 minecraft:red_nether_bricks
setblock 321 203 193 minecraft:polished_blackstone
fill 321 203 194 321 206 194 minecraft:red_nether_bricks
setblock 321 203 198 minecraft:polished_blackstone
fill 321 203 199 321 206 199 minecraft:red_nether_bricks
setblock 321 203 203 minecraft:polished_blackstone
setblock 322 203 182 minecraft:polished_blackstone
fill 322 203 183 322 205 183 minecraft:red_nether_bricks
setblock 322 203 187 minecraft:polished_blackstone
fill 322 203 188 322 204 188 minecraft:red_nether_bricks
setblock 322 203 192 minecraft:polished_blackstone
fill 322 203 193 322 206 193 minecraft:red_nether_bricks
setblock 322 203 197 minecraft:polished_blackstone
fill 322 203 198 322 206 198 minecraft:red_nether_bricks
setblock 322 203 202 minecraft:polished_blackstone
fill 322 203 203 322 205 203 minecraft:red_nether_bricks
setblock 322 203 217 minecraft:polished_blackstone
fill 322 203 218 322 204 218 minecraft:red_nether_bricks
setblock 322 203 222 minecraft:polished_blackstone
fill 323 203 182 323 206 182 minecraft:red_nether_bricks
setblock 323 203 186 minecraft:polished_blackstone
fill 323 203 187 323 206 187 minecraft:red_nether_bricks
setblock 323 203 191 minecraft:polished_blackstone
fill 323 203 192 323 206 192 minecraft:red_nether_bricks
setblock 323 203 196 minecraft:polished_blackstone
fill 323 203 197 323 206 197 minecraft:red_nether_bricks
setblock 323 203 201 minecraft:polished_blackstone
fill 323 203 202 323 206 202 minecraft:red_nether_bricks
setblock 323 203 206 minecraft:polished_blackstone
setblock 323 203 212 minecraft:red_nether_bricks
setblock 323 203 216 minecraft:polished_blackstone
fill 323 203 217 323 205 217 minecraft:red_nether_bricks
setblock 323 203 221 minecraft:polished_blackstone
fill 323 203 222 323 206 222 minecraft:red_nether_bricks
setblock 283 204 185 minecraft:polished_blackstone
fill 283 204 186 283 206 186 minecraft:red_nether_bricks
setblock 283 204 190 minecraft:polished_blackstone
fill 283 204 191 283 205 191 minecraft:red_nether_bricks
setblock 283 204 195 minecraft:polished_blackstone
fill 283 204 196 283 206 196 minecraft:red_nether_bricks
setblock 283 204 200 minecraft:polished_blackstone
fill 283 204 201 283 206 201 minecraft:red_nether_bricks
setblock 283 204 215 minecraft:polished_blackstone
fill 283 204 216 283 206 216 minecraft:red_nether_bricks
setblock 283 204 220 minecraft:polished_blackstone
fill 283 204 221 285 204 222 minecraft:red_nether_bricks
setblock 284 204 194 minecraft:polished_blackstone
setblock 284 204 195 minecraft:red_nether_bricks
setblock 284 204 219 minecraft:polished_blackstone
fill 284 204 220 284 207 220 minecraft:red_nether_bricks
setblock 285 204 184 minecraft:light[level=14]
setblock 285 204 192 minecraft:light[level=14]
setblock 285 204 200 minecraft:light[level=14]
setblock 285 204 208 minecraft:light[level=14]
setblock 285 204 216 minecraft:light[level=14]
setblock 286 204 182 minecraft:polished_blackstone
setblock 286 204 221 minecraft:red_nether_bricks
setblock 286 204 222 minecraft:polished_blackstone
fill 287 204 182 290 204 182 minecraft:red_nether_bricks
setblock 287 204 221 minecraft:polished_blackstone
fill 287 204 222 287 207 222 minecraft:red_nether_bricks
fill 288 204 221 291 204 221 minecraft:red_nether_bricks
fill 290 204 220 292 204 220 minecraft:red_nether_bricks
setblock 291 204 182 minecraft:polished_blackstone
setblock 291 204 222 minecraft:polished_blackstone
fill 292 204 182 292 207 182 minecraft:red_nether_bricks
setblock 292 204 221 minecraft:polished_blackstone
fill 292 204 222 292 207 222 minecraft:red_nether_bricks
setblock 293 204 184 minecraft:light[level=14]
setblock 293 204 192 minecraft:light[level=14]
setblock 293 204 200 minecraft:light[level=14]
setblock 293 204 208 minecraft:light[level=14]
setblock 293 204 216 minecraft:light[level=14]
setblock 293 204 219 minecraft:red_nether_bricks
setblock 293 204 220 minecraft:polished_blackstone
fill 293 204 221 293 207 221 minecraft:red_nether_bricks
setblock 294 204 219 minecraft:polished_blackstone
fill 294 204 220 294 207 220 minecraft:red_nether_bricks
setblock 295 204 183 minecraft:polished_blackstone
fill 295 204 219 295 207 219 minecraft:red_nether_bricks
setblock 296 204 182 minecraft:polished_blackstone
fill 296 204 183 296 207 183 minecraft:red_nether_bricks
setblock 296 204 218 minecraft:red_nether_bricks
setblock 296 204 222 minecraft:polished_blackstone
fill 297 204 182 297 207 182 minecraft:red_nether_bricks
setblock 297 204 221 minecraft:polished_blackstone
fill 297 204 222 297 207 222 minecraft:red_nether_bricks
setblock 298 204 220 minecraft:polished_blackstone
fill 298 204 221 298 207 221 minecraft:red_nether_bricks
setblock 299 204 219 minecraft:polished_blackstone
fill 299 204 220 299 207 220 minecraft:red_nether_bricks
fill 300 204 219 300 205 219 minecraft:red_nether_bricks
setblock 301 204 182 minecraft:polished_blackstone
setblock 301 204 184 minecraft:light[level=14]
setblock 301 204 192 minecraft:light[level=14]
setblock 301 204 200 minecraft:light[level=14]
setblock 301 204 208 minecraft:light[level=14]
setblock 301 204 216 minecraft:light[level=14]
setblock 301 204 222 minecraft:polished_blackstone
setblock 302 204 182 minecraft:red_nether_bricks
setblock 302 204 221 minecraft:polished_blackstone
fill 302 204 222 302 207 222 minecraft:red_nether_bricks
setblock 303 204 220 minecraft:polished_blackstone
fill 303 204 221 303 206 221 minecraft:red_nether_bricks
setblock 306 204 222 minecraft:polished_blackstone
fill 307 204 222 307 205 222 minecraft:red_nether_bricks
setblock 309 204 184 minecraft:light[level=14]
setblock 309 204 192 minecraft:light[level=14]
setblock 309 204 200 minecraft:light[level=14]
setblock 309 204 208 minecraft:light[level=14]
setblock 309 204 216 minecraft:light[level=14]
setblock 310 204 222 minecraft:red_nether_bricks
setblock 311 204 222 minecraft:polished_blackstone
fill 312 204 222 315 204 222 minecraft:red_nether_bricks
fill 314 204 182 315 204 182 minecraft:red_nether_bricks
fill 314 204 221 316 204 221 minecraft:red_nether_bricks
setblock 316 204 182 minecraft:polished_blackstone
setblock 316 204 222 minecraft:polished_blackstone
fill 317 204 182 317 206 183 minecraft:red_nether_bricks
setblock 317 204 184 minecraft:light[level=14]
setblock 317 204 192 minecraft:light[level=14]
setblock 317 204 200 minecraft:light[level=14]
setblock 317 204 208 minecraft:light[level=14]
setblock 317 204 216 minecraft:light[level=14]
setblock 317 204 221 minecraft:polished_blackstone
fill 317 204 222 317 207 222 minecraft:red_nether_bricks
setblock 318 204 220 minecraft:polished_blackstone
fill 318 204 221 318 207 221 minecraft:red_nether_bricks
setblock 320 204 182 minecraft:red_nether_bricks
setblock 320 204 183 minecraft:polished_blackstone
setblock 320 204 193 minecraft:polished_blackstone
fill 320 204 194 320 205 194 minecraft:red_nether_bricks
setblock 320 204 198 minecraft:polished_blackstone
fill 320 204 199 320 206 199 minecraft:red_nether_bricks
setblock 321 204 182 minecraft:polished_blackstone
fill 321 204 183 321 207 183 minecraft:red_nether_bricks
setblock 321 204 192 minecraft:polished_blackstone
fill 321 204 193 321 205 193 minecraft:red_nether_bricks
setblock 321 204 197 minecraft:polished_blackstone
fill 321 204 198 321 207 198 minecraft:red_nether_bricks
setblock 321 204 202 minecraft:polished_blackstone
setblock 321 204 221 minecraft:red_nether_bricks
setblock 321 204 222 minecraft:polished_blackstone
fill 322 204 182 322 207 182 minecraft:red_nether_bricks
setblock 322 204 186 minecraft:polished_blackstone
setblock 322 204 187 minecraft:red_nether_bricks
setblock 322 204 191 minecraft:polished_blackstone
fill 322 204 192 322 206 192 minecraft:red_nether_bricks
setblock 322 204 196 minecraft:polished_blackstone
fill 322 204 197 322 207 197 minecraft:red_nether_bricks
setblock 322 204 201 minecraft:polished_blackstone
fill 322 204 202 322 207 202 minecraft:red_nether_bricks
setblock 322 204 217 minecraft:red_nether_bricks
setblock 322 204 221 minecraft:polished_blackstone
fill 322 204 222 322 207 222 minecraft:red_nether_bricks
setblock 323 204 185 minecraft:polished_blackstone
fill 323 204 186 323 207 186 minecraft:red_nether_bricks
setblock 323 204 190 minecraft:polished_blackstone
fill 323 204 191 323 207 191 minecraft:red_nether_bricks
setblock 323 204 195 minecraft:polished_blackstone
fill 323 204 196 323 207 196 minecraft:red_nether_bricks
setblock 323 204 200 minecraft:polished_blackstone
fill 323 204 201 323 207 201 minecraft:red_nether_bricks
setblock 323 204 205 minecraft:polished_blackstone
setblock 323 204 215 minecraft:polished_blackstone
fill 323 204 216 323 205 216 minecraft:red_nether_bricks
setblock 323 204 220 minecraft:polished_blackstone
fill 323 204 221 323 207 221 minecraft:red_nether_bricks
setblock 283 205 184 minecraft:polished_blackstone
fill 283 205 185 283 207 185 minecraft:red_nether_bricks
setblock 283 205 189 minecraft:polished_blackstone
setblock 283 205 190 minecraft:red_nether_bricks
setblock 283 205 194 minecraft:polished_blackstone
fill 283 205 195 283 206 195 minecraft:red_nether_bricks
setblock 283 205 199 minecraft:polished_blackstone
fill 283 205 200 283 206 200 minecraft:red_nether_bricks
setblock 283 205 215 minecraft:red_nether_bricks
setblock 283 205 219 minecraft:polished_blackstone
fill 283 205 220 283 206 222 minecraft:red_nether_bricks
setblock 284 205 218 minecraft:polished_blackstone
fill 284 205 219 284 206 219 minecraft:red_nether_bricks
fill 284 205 221 284 205 222 minecraft:red_nether_bricks
setblock 285 205 182 minecraft:polished_blackstone
setblock 285 205 221 minecraft:red_nether_bricks
setblock 285 205 222 minecraft:polished_blackstone
fill 286 205 182 289 205 182 minecraft:red_nether_bricks
setblock 286 205 221 minecraft:polished_blackstone
fill 286 205 222 286 208 222 minecraft:red_nether_bricks
fill 287 205 221 290 205 221 minecraft:red_nether_bricks
setblock 290 205 182 minecraft:polished_blackstone
fill 290 205 220 291 205 220 minecraft:red_nether_bricks
setblock 290 205 222 minecraft:polished_blackstone
fill 291 205 182 291 208 182 minecraft:red_nether_bricks
setblock 291 205 221 minecraft:polished_blackstone
fill 291 205 222 291 208 222 minecraft:red_nether_bricks
setblock 292 205 220 minecraft:polished_blackstone
fill 292 205 221 292 208 221 minecraft:red_nether_bricks
setblock 293 205 219 minecraft:polished_blackstone
fill 293 205 220 293 208 220 minecraft:red_nether_bricks
fill 294 205 219 294 207 219 minecraft:red_nether_bricks
setblock 295 205 182 minecraft:polished_blackstone
fill 295 205 183 295 208 183 minecraft:red_nether_bricks
setblock 295 205 222 minecraft:polished_blackstone
fill 296 205 182 296 208 182 minecraft:red_nether_bricks
setblock 296 205 221 minecraft:polished_blackstone
fill 296 205 222 296 208 222 minecraft:red_nether_bricks
setblock 297 205 220 minecraft:polished_blackstone
fill 297 205 221 297 208 221 minecraft:red_nether_bricks
setblock 298 205 219 minecraft:polished_blackstone
fill 298 205 220 298 208 220 minecraft:red_nether_bricks
fill 299 205 219 299 206 219 minecraft:red_nether_bricks
setblock 300 205 182 minecraft:polished_blackstone
setblock 300 205 222 minecraft:polished_blackstone
fill 301 205 182 301 206 182 minecraft:red_nether_bricks
setblock 301 205 221 minecraft:polished_blackstone
fill 301 205 222 301 208 222 minecraft:red_nether_bricks
setblock 302 205 220 minecraft:polished_blackstone
fill 302 205 221 302 207 221 minecraft:red_nether_bricks
setblock 303 205 220 minecraft:red_nether_bricks
setblock 305 205 222 minecraft:polished_blackstone
fill 306 205 222 306 206 222 minecraft:red_nether_bricks
fill 310 205 183 310 205 185 minecraft:polished_blackstone
setblock 310 205 222 minecraft:polished_blackstone
fill 311 205 183 312 205 183 minecraft:polished_blackstone
fill 311 205 185 312 205 185 minecraft:polished_blackstone
fill 311 205 222 314 205 222 minecraft:red_nether_bricks
setblock 312 205 184 minecraft:polished_blackstone
fill 313 205 182 314 205 182 minecraft:red_nether_bricks
fill 314 205 221 315 205 221 minecraft:red_nether_bricks
setblock 315 205 182 minecraft:polished_blackstone
setblock 315 205 222 minecraft:polished_blackstone
fill 316 205 182 316 207 183 minecraft:red_nether_bricks
setblock 316 205 221 minecraft:polished_blackstone
fill 316 205 222 316 208 222 minecraft:red_nether_bricks
fill 317 205 221 317 208 221 minecraft:red_nether_bricks
setblock 319 205 182 minecraft:red_nether_bricks
setblock 319 205 183 minecraft:polished_blackstone
setblock 320 205 182 minecraft:polished_blackstone
fill 320 205 183 320 208 183 minecraft:red_nether_bricks
setblock 320 205 197 minecraft:polished_blackstone
fill 320 205 198 320 206 198 minecraft:red_nether_bricks
setblock 320 205 222 minecraft:polished_blackstone
fill 321 205 182 321 208 182 minecraft:red_nether_bricks
setblock 321 205 192 minecraft:red_nether_bricks
setblock 321 205 196 minecraft:polished_blackstone
fill 321 205 197 321 207 197 minecraft:red_nether_bricks
setblock 321 205 201 minecraft:polished_blackstone
setblock 321 205 202 minecraft:red_nether_bricks
setblock 321 205 221 minecraft:polished_blackstone
fill 321 205 222 321 208 222 minecraft:red_nether_bricks
setblock 322 205 190 minecraft:polished_blackstone
setblock 322 205 191 minecraft:red_nether_bricks
setblock 322 205 195 minecraft:polished_blackstone
fill 322 205 196 322 207 196 minecraft:red_nether_bricks
setblock 322 205 200 minecraft:polished_blackstone
fill 322 205 201 322 207 201 minecraft:red_nether_bricks
setblock 322 205 220 minecraft:polished_blackstone
setblock 322 205 221 minecraft:red_nether_bricks
setblock 323 205 184 minecraft:polished_blackstone
fill 323 205 185 323 208 185 minecraft:red_nether_bricks
setblock 323 205 189 minecraft:polished_blackstone
fill 323 205 190 323 206 190 minecraft:red_nether_bricks
setblock 323 205 194 minecraft:polished_blackstone
fill 323 205 195 323 208 195 minecraft:red_nether_bricks
setblock 323 205 199 minecraft:polished_blackstone
fill 323 205 200 323 208 200 minecraft:red_nether_bricks
setblock 323 205 204 minecraft:polished_blackstone
setblock 323 205 219 minecraft:polished_blackstone
fill 323 205 220 323 207 220 minecraft:red_nether_bricks
setblock 283 206 183 minecraft:polished_blackstone
fill 283 206 184 283 209 184 minecraft:red_nether_bricks
setblock 283 206 193 minecraft:polished_blackstone
setblock 283 206 194 minecraft:red_nether_bricks
setblock 283 206 198 minecraft:polished_blackstone
setblock 283 206 199 minecraft:red_nether_bricks
setblock 283 206 218 minecraft:polished_blackstone
fill 283 206 219 283 209 219 minecraft:red_nether_bricks
setblock 284 206 182 minecraft:polished_blackstone
setblock 284 206 221 minecraft:red_nether_bricks
setblock 284 206 222 minecraft:polished_blackstone
fill 285 206 182 288 206 182 minecraft:red_nether_bricks
setblock 285 206 221 minecraft:polished_blackstone
fill 285 206 222 285 209 222 minecraft:red_nether_bricks
fill 286 206 221 289 206 221 minecraft:red_nether_bricks
setblock 289 206 182 minecraft:polished_blackstone
setblock 289 206 222 minecraft:polished_blackstone
fill 290 206 182 290 209 182 minecraft:red_nether_bricks
setblock 290 206 220 minecraft:red_nether_bricks
setblock 290 206 221 minecraft:polished_blackstone
fill 290 206 222 290 209 222 minecraft:red_nether_bricks
setblock 291 206 220 minecraft:polished_blackstone
fill 291 206 221 291 209 221 minecraft:red_nether_bricks
fill 292 206 220 292 209 220 minecraft:red_nether_bricks
setblock 293 206 219 minecraft:red_nether_bricks
setblock 294 206 182 minecraft:polished_blackstone
fill 294 206 183 294 209 183 minecraft:red_nether_bricks
setblock 294 206 222 minecraft:polished_blackstone
fill 295 206 182 295 209 182 minecraft:red_nether_bricks
setblock 295 206 221 minecraft:polished_blackstone
fill 295 206 222 295 209 222 minecraft:red_nether_bricks
setblock 296 206 220 minecraft:polished_blackstone
fill 296 206 221 296 209 221 minecraft:red_nether_bricks
setblock 297 206 219 minecraft:polished_blackstone
fill 297 206 220 297 209 220 minecraft:red_nether_bricks
fill 298 206 219 298 207 219 minecraft:red_nether_bricks
setblock 299 206 182 minecraft:polished_blackstone
setblock 299 206 222 minecraft:polished_blackstone
fill 300 206 182 300 208 182 minecraft:red_nether_bricks
setblock 300 206 221 minecraft:polished_blackstone
fill 300 206 222 300 209 222 minecraft:red_nether_bricks
setblock 301 206 220 minecraft:polished_blackstone
fill 301 206 221 301 208 221 minecraft:red_nether_bricks
setblock 304 206 222 minecraft:polished_blackstone
setblock 305 206 222 minecraft:red_nether_bricks
fill 310 206 222 313 206 222 minecraft:red_nether_bricks
setblock 313 206 182 minecraft:red_nether_bricks
setblock 314 206 182 minecraft:polished_blackstone
setblock 314 206 221 minecraft:red_nether_bricks
setblock 314 206 222 minecraft:polished_blackstone
fill 315 206 182 315 209 182 minecraft:red_nether_bricks
setblock 315 206 221 minecraft:polished_blackstone
fill 315 206 222 315 209 222 minecraft:red_nether_bricks
fill 316 206 221 316 209 221 minecraft:red_nether_bricks
fill 317 206 203 317 206 205 minecraft:polished_blackstone
setblock 318 206 182 minecraft:red_nether_bricks
setblock 318 206 183 minecraft:polished_blackstone
fill 318 206 202 320 206 202 minecraft:polished_blackstone
fill 318 206 206 320 206 206 minecraft:polished_blackstone
setblock 319 206 182 minecraft:polished_blackstone
fill 319 206 183 319 209 183 minecraft:red_nether_bricks
setblock 319 206 222 minecraft:polished_blackstone
fill 320 206 182 320 209 182 minecraft:red_nether_bricks
setblock 320 206 197 minecraft:red_nether_bricks
setblock 320 206 221 minecraft:polished_blackstone
fill 320 206 222 320 209 222 minecraft:red_nether_bricks
setblock 321 206 195 minecraft:polished_blackstone
setblock 321 206 196 minecraft:red_nether_bricks
setblock 321 206 200 minecraft:polished_blackstone
setblock 321 206 201 minecraft:red_nether_bricks
fill 321 206 203 321 206 205 minecraft:polished_blackstone
setblock 321 206 221 minecraft:red_nether_bricks
setblock 322 206 194 minecraft:polished_blackstone
fill 322 206 195 322 207 195 minecraft:red_nether_bricks
setblock 322 206 199 minecraft:polished_blackstone
fill 322 206 200 322 208 200 minecraft:red_nether_bricks
setblock 323 206 183 minecraft:polished_blackstone
fill 323 206 184 323 209 184 minecraft:red_nether_bricks
setblock 323 206 188 minecraft:polished_blackstone
setblock 323 206 189 minecraft:red_nether_bricks
setblock 323 206 193 minecraft:polished_blackstone
fill 323 206 194 323 208 194 minecraft:red_nether_bricks
setblock 323 206 198 minecraft:polished_blackstone
fill 323 206 199 323 209 199 minecraft:red_nether_bricks
setblock 323 206 203 minecraft:polished_blackstone
setblock 323 206 218 minecraft:polished_blackstone
setblock 323 206 219 minecraft:red_nether_bricks
setblock 283 207 182 minecraft:polished_blackstone
fill 283 207 183 283 210 183 minecraft:red_nether_bricks
setblock 283 207 217 minecraft:polished_blackstone
fill 283 207 218 283 208 218 minecraft:red_nether_bricks
fill 283 207 220 283 207 221 minecraft:red_nether_bricks
setblock 283 207 222 minecraft:polished_blackstone
fill 284 207 182 287 207 182 minecraft:red_nether_bricks
setblock 284 207 221 minecraft:polished_blackstone
fill 284 207 222 284 210 222 minecraft:red_nether_bricks
fill 285 207 221 288 207 221 minecraft:red_nether_bricks
setblock 288 207 182 minecraft:polished_blackstone
setblock 288 207 222 minecraft:polished_blackstone
fill 289 207 182 289 210 182 minecraft:red_nether_bricks
setblock 289 207 221 minecraft:polished_blackstone
fill 289 207 222 289 210 222 minecraft:red_nether_bricks
setblock 290 207 220 minecraft:polished_blackstone
fill 290 207 221 290 210 221 minecraft:red_nether_bricks
fill 291 207 220 291 210 220 minecraft:red_nether_bricks
setblock 293 207 182 minecraft:polished_blackstone
setblock 293 207 222 minecraft:polished_blackstone
fill 294 207 182 294 210 182 minecraft:red_nether_bricks
setblock 294 207 221 minecraft:polished_blackstone
fill 294 207 222 294 210 222 minecraft:red_nether_bricks
setblock 295 207 220 minecraft:polished_blackstone
fill 295 207 221 295 210 221 minecraft:red_nether_bricks
setblock 296 207 219 minecraft:polished_blackstone
fill 296 207 220 296 210 220 minecraft:red_nether_bricks
setblock 297 207 219 minecraft:red_nether_bricks
setblock 298 207 182 minecraft:polished_blackstone
setblock 298 207 222 minecraft:polished_blackstone
fill 299 207 182 299 210 182 minecraft:red_nether_bricks
setblock 299 207 221 minecraft:polished_blackstone
fill 299 207 222 299 210 222 minecraft:red_nether_bricks
setblock 300 207 220 minecraft:polished_blackstone
fill 300 207 221 300 209 221 minecraft:red_nether_bricks
setblock 303 207 222 minecraft:polished_blackstone
setblock 304 207 222 minecraft:red_nether_bricks
fill 311 207 222 312 207 222 minecraft:red_nether_bricks
setblock 312 207 182 minecraft:red_nether_bricks
setblock 313 207 182 minecraft:polished_blackstone
setblock 313 207 222 minecraft:polished_blackstone
fill 314 207 182 314 210 182 minecraft:red_nether_bricks
setblock 314 207 221 minecraft:polished_blackstone
fill 314 207 222 314 210 222 minecraft:red_nether_bricks
fill 315 207 183 315 208 183 minecraft:red_nether_bricks
fill 315 207 221 315 209 221 minecraft:red_nether_bricks
setblock 317 207 182 minecraft:red_nether_bricks
setblock 317 207 183 minecraft:polished_blackstone
setblock 318 207 182 minecraft:polished_blackstone
fill 318 207 183 318 210 183 minecraft:red_nether_bricks
setblock 318 207 222 minecraft:polished_blackstone
fill 319 207 182 319 210 182 minecraft:red_nether_bricks
setblock 319 207 221 minecraft:polished_blackstone
fill 319 207 222 319 210 222 minecraft:red_nether_bricks
setblock 320 207 221 minecraft:red_nether_bricks
setblock 321 207 199 minecraft:polished_blackstone
setblock 321 207 200 minecraft:red_nether_bricks
setblock 322 207 194 minecraft:red_nether_bricks
setblock 322 207 198 minecraft:polished_blackstone
fill 322 207 199 322 208 199 minecraft:red_nether_bricks
setblock 323 207 182 minecraft:polished_blackstone
fill 323 207 183 323 210 183 minecraft:red_nether_bricks
setblock 323 207 192 minecraft:polished_blackstone
setblock 323 207 193 minecraft:red_nether_bricks
setblock 323 207 197 minecraft:polished_blackstone
fill 323 207 198 323 209 198 minecraft:red_nether_bricks
setblock 323 207 202 minecraft:polished_blackstone
setblock 323 207 203 minecraft:red_nether_bricks
setblock 323 207 222 minecraft:polished_blackstone
fill 283 208 182 286 208 182 minecraft:red_nether_bricks
setblock 283 208 220 minecraft:red_nether_bricks
setblock 283 208 221 minecraft:polished_blackstone
fill 283 208 222 283 211 222 minecraft:red_nether_bricks
fill 286 208 221 287 208 221 minecraft:red_nether_bricks
setblock 287 208 182 minecraft:polished_blackstone
setblock 287 208 222 minecraft:polished_blackstone
fill 288 208 182 288 211 182 minecraft:red_nether_bricks
setblock 288 208 221 minecraft:polished_blackstone
fill 288 208 222 288 211 222 minecraft:red_nether_bricks
fill 289 208 221 289 211 221 minecraft:red_nether_bricks
setblock 292 208 182 minecraft:polished_blackstone
setblock 292 208 222 minecraft:polished_blackstone
fill 293 208 182 293 210 183 minecraft:red_nether_bricks
setblock 293 208 221 minecraft:polished_blackstone
fill 293 208 222 293 211 222 minecraft:red_nether_bricks
setblock 294 208 220 minecraft:polished_blackstone
fill 294 208 221 294 211 221 minecraft:red_nether_bricks
fill 295 208 220 295 211 220 minecraft:red_nether_bricks
setblock 296 208 183 minecraft:polished_blackstone
setblock 297 208 182 minecraft:polished_blackstone
setblock 297 208 222 minecraft:polished_blackstone
fill 298 208 182 298 211 182 minecraft:red_nether_bricks
setblock 298 208 221 minecraft:polished_blackstone
fill 298 208 222 298 211 222 minecraft:red_nether_bricks
setblock 299 208 220 minecraft:polished_blackstone
fill 299 208 221 299 211 221 minecraft:red_nether_bricks
setblock 302 208 222 minecraft:polished_blackstone
setblock 303 208 222 minecraft:red_nether_bricks
setblock 311 208 222 minecraft:red_nether_bricks
setblock 312 208 182 minecraft:polished_blackstone
setblock 312 208 222 minecraft:polished_blackstone
fill 313 208 182 313 211 182 minecraft:red_nether_bricks
fill 313 208 222 313 211 222 minecraft:red_nether_bricks
fill 314 208 183 314 209 183 minecraft:red_nether_bricks
setblock 314 208 221 minecraft:red_nether_bricks
setblock 316 208 182 minecraft:red_nether_bricks
setblock 316 208 183 minecraft:polished_blackstone
setblock 317 208 182 minecraft:polished_blackstone
fill 317 208 183 317 211 183 minecraft:red_nether_bricks
setblock 317 208 222 minecraft:polished_blackstone
fill 318 208 182 318 211 182 minecraft:red_nether_bricks
setblock 318 208 221 minecraft:polished_blackstone
fill 318 208 222 318 211 222 minecraft:red_nether_bricks
setblock 321 208 183 minecraft:polished_blackstone
setblock 322 208 182 minecraft:polished_blackstone
setblock 322 208 197 minecraft:polished_blackstone
setblock 322 208 198 minecraft:red_nether_bricks
setblock 322 208 222 minecraft:polished_blackstone
fill 323 208 182 323 211 182 minecraft:red_nether_bricks
setblock 323 208 196 minecraft:polished_blackstone
fill 323 208 197 323 209 197 minecraft:red_nether_bricks
setblock 323 208 201 minecraft:polished_blackstone
fill 323 208 202 323 209 202 minecraft:red_nether_bricks
setblock 323 208 221 minecraft:polished_blackstone
fill 323 208 222 323 211 222 minecraft:red_nether_bricks
fill 283 209 182 285 209 182 minecraft:red_nether_bricks
setblock 283 209 220 minecraft:polished_blackstone
fill 283 209 221 283 211 221 minecraft:red_nether_bricks
setblock 286 209 182 minecraft:polished_blackstone
setblock 286 209 222 minecraft:polished_blackstone
fill 287 209 182 287 211 182 minecraft:red_nether_bricks
setblock 287 209 221 minecraft:polished_blackstone
fill 287 209 222 287 211 222 minecraft:red_nether_bricks
fill 288 209 221 288 211 221 minecraft:red_nether_bricks
setblock 291 209 182 minecraft:polished_blackstone
setblock 291 209 222 minecraft:polished_blackstone
fill 292 209 182 292 211 183 minecraft:red_nether_bricks
setblock 292 209 221 minecraft:polished_blackstone
fill 292 209 222 292 211 222 minecraft:red_nether_bricks
setblock 293 209 220 minecraft:polished_blackstone
fill 293 209 221 293 211 221 minecraft:red_nether_bricks
fill 294 209 220 294 211 220 minecraft:red_nether_bricks
setblock 295 209 183 minecraft:polished_blackstone
setblock 296 209 182 minecraft:polished_blackstone
fill 296 209 183 296 211 183 minecraft:red_nether_bricks
setblock 296 209 222 minecraft:polished_blackstone
fill 297 209 182 297 211 182 minecraft:red_nether_bricks
setblock 297 209 221 minecraft:polished_blackstone
fill 297 209 222 297 211 222 minecraft:red_nether_bricks
setblock 298 209 220 minecraft:polished_blackstone
fill 298 209 221 298 211 221 minecraft:red_nether_bricks
setblock 301 209 222 minecraft:polished_blackstone
fill 302 209 222 302 210 222 minecraft:red_nether_bricks
setblock 310 209 222 minecraft:red_nether_bricks
setblock 311 209 182 minecraft:polished_blackstone
setblock 311 209 222 minecraft:polished_blackstone
fill 312 209 182 312 211 182 minecraft:red_nether_bricks
fill 312 209 222 312 211 222 minecraft:red_nether_bricks
fill 313 209 183 313 210 183 minecraft:red_nether_bricks
setblock 315 209 183 minecraft:polished_blackstone
setblock 316 209 182 minecraft:polished_blackstone
fill 316 209 183 316 211 183 minecraft:red_nether_bricks
setblock 316 209 222 minecraft:polished_blackstone
fill 317 209 182 317 211 182 minecraft:red_nether_bricks
fill 317 209 222 317 211 222 minecraft:red_nether_bricks
setblock 320 209 183 minecraft:polished_blackstone
setblock 321 209 182 minecraft:polished_blackstone
fill 321 209 183 321 211 183 minecraft:red_nether_bricks
setblock 321 209 222 minecraft:polished_blackstone
fill 322 209 182 322 211 182 minecraft:red_nether_bricks
fill 322 209 222 322 211 222 minecraft:red_nether_bricks
setblock 323 209 185 minecraft:polished_blackstone
setblock 323 209 200 minecraft:polished_blackstone
setblock 323 209 201 minecraft:red_nether_bricks
fill 283 210 182 284 210 182 minecraft:red_nether_bricks
setblock 283 210 184 minecraft:polished_blackstone
fill 283 210 220 283 211 220 minecraft:red_nether_bricks
setblock 285 210 182 minecraft:polished_blackstone
setblock 285 210 222 minecraft:polished_blackstone
fill 286 210 182 286 211 182 minecraft:red_nether_bricks
fill 286 210 222 286 211 222 minecraft:red_nether_bricks
fill 287 210 221 287 211 221 minecraft:red_nether_bricks
setblock 290 210 182 minecraft:polished_blackstone
fill 290 210 183 291 211 183 minecraft:red_nether_bricks
setblock 290 210 222 minecraft:polished_blackstone
fill 291 210 182 291 211 182 minecraft:red_nether_bricks
setblock 291 210 221 minecraft:polished_blackstone
fill 291 210 222 291 211 222 minecraft:red_nether_bricks
setblock 292 210 220 minecraft:polished_blackstone
fill 292 210 221 292 211 221 minecraft:red_nether_bricks
fill 293 210 220 293 211 220 minecraft:red_nether_bricks
setblock 294 210 183 minecraft:polished_blackstone
setblock 295 210 182 minecraft:polished_blackstone
fill 295 210 183 295 211 183 minecraft:red_nether_bricks
setblock 295 210 222 minecraft:polished_blackstone
fill 296 210 182 296 211 182 minecraft:red_nether_bricks
setblock 296 210 221 minecraft:polished_blackstone
fill 296 210 222 296 211 222 minecraft:red_nether_bricks
setblock 297 210 220 minecraft:polished_blackstone
fill 297 210 221 297 211 221 minecraft:red_nether_bricks
setblock 300 210 222 minecraft:polished_blackstone
fill 301 210 222 301 211 222 minecraft:red_nether_bricks
fill 310 210 182 310 210 185 minecraft:polished_blackstone
setblock 310 210 222 minecraft:polished_blackstone
fill 311 210 182 311 211 182 minecraft:red_nether_bricks
setblock 311 210 183 minecraft:polished_blackstone
fill 311 210 185 312 210 185 minecraft:polished_blackstone
fill 311 210 222 311 211 222 minecraft:red_nether_bricks
fill 312 210 183 312 211 183 minecraft:red_nether_bricks
setblock 312 210 184 minecraft:polished_blackstone
setblock 314 210 183 minecraft:polished_blackstone
setblock 315 210 182 minecraft:polished_blackstone
fill 315 210 183 315 211 183 minecraft:red_nether_bricks
setblock 315 210 222 minecraft:polished_blackstone
fill 316 210 182 316 211 182 minecraft:red_nether_bricks
fill 316 210 222 316 211 222 minecraft:red_nether_bricks
setblock 319 210 183 minecraft:polished_blackstone
setblock 320 210 182 minecraft:polished_blackstone
fill 320 210 183 320 211 183 minecraft:red_nether_bricks
setblock 320 210 222 minecraft:polished_blackstone
fill 321 210 182 321 211 182 minecraft:red_nether_bricks
fill 321 210 222 321 211 222 minecraft:red_nether_bricks
setblock 323 210 184 minecraft:polished_blackstone
fill 323 210 185 323 211 186 minecraft:red_nether_bricks
setblock 323 210 200 minecraft:red_nether_bricks
setblock 283 211 182 minecraft:red_nether_bricks
setblock 283 211 183 minecraft:polished_blackstone
fill 283 211 184 283 211 185 minecraft:red_nether_bricks
setblock 284 211 182 minecraft:polished_blackstone
setblock 284 211 222 minecraft:polished_blackstone
setblock 285 211 182 minecraft:red_nether_bricks
setblock 285 211 222 minecraft:red_nether_bricks
setblock 286 211 221 minecraft:red_nether_bricks
setblock 288 211 183 minecraft:polished_blackstone
setblock 289 211 182 minecraft:polished_blackstone
setblock 289 211 183 minecraft:red_nether_bricks
setblock 289 211 222 minecraft:polished_blackstone
setblock 290 211 182 minecraft:red_nether_bricks
setblock 290 211 220 minecraft:red_nether_bricks
setblock 290 211 221 minecraft:polished_blackstone
setblock 290 211 222 minecraft:red_nether_bricks
setblock 291 211 220 minecraft:polished_blackstone
setblock 291 211 221 minecraft:red_nether_bricks
setblock 292 211 220 minecraft:red_nether_bricks
setblock 293 211 182 minecraft:red_nether_bricks
setblock 293 211 183 minecraft:polished_blackstone
setblock 294 211 182 minecraft:polished_blackstone
schedule function dropper:buildpart/42_9 1t
