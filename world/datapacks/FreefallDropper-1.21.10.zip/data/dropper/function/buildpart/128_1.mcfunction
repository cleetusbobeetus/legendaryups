setblock 404 172 538 minecraft:blackstone
setblock 404 172 546 minecraft:black_concrete
fill 406 172 525 406 173 526 minecraft:blackstone
fill 406 172 538 406 173 539 minecraft:blackstone
fill 406 173 524 407 174 524 minecraft:blackstone
fill 406 173 540 407 174 540 minecraft:blackstone
fill 407 173 525 407 174 525 minecraft:blackstone
fill 407 173 539 407 174 539 minecraft:blackstone
setblock 406 174 525 minecraft:blackstone
setblock 406 174 539 minecraft:blackstone
fill 391 175 545 392 176 545 minecraft:white_wool
setblock 407 175 524 minecraft:blackstone
setblock 407 175 540 minecraft:blackstone
fill 398 177 517 398 178 517 minecraft:white_stained_glass
setblock 379 178 513 minecraft:light[level=14]
setblock 379 178 521 minecraft:light[level=14]
setblock 379 178 529 minecraft:light[level=14]
setblock 379 178 537 minecraft:light[level=14]
setblock 379 178 545 minecraft:light[level=14]
setblock 387 178 513 minecraft:light[level=14]
setblock 387 178 521 minecraft:light[level=14]
setblock 387 178 529 minecraft:light[level=14]
setblock 387 178 537 minecraft:light[level=14]
setblock 387 178 545 minecraft:light[level=14]
fill 388 178 531 388 179 532 minecraft:white_wool
fill 389 178 531 389 179 531 minecraft:white_wool
setblock 395 178 513 minecraft:light[level=14]
setblock 395 178 521 minecraft:light[level=14]
setblock 395 178 529 minecraft:light[level=14]
setblock 395 178 537 minecraft:light[level=14]
setblock 395 178 545 minecraft:light[level=14]
setblock 403 178 513 minecraft:light[level=14]
setblock 403 178 521 minecraft:light[level=14]
setblock 403 178 529 minecraft:light[level=14]
setblock 403 178 537 minecraft:light[level=14]
setblock 403 178 545 minecraft:light[level=14]
setblock 411 178 513 minecraft:light[level=14]
setblock 411 178 521 minecraft:light[level=14]
setblock 411 178 529 minecraft:light[level=14]
setblock 411 178 537 minecraft:light[level=14]
setblock 411 178 545 minecraft:light[level=14]
fill 398 179 517 398 186 517 minecraft:smooth_quartz
fill 397 180 517 397 186 517 minecraft:smooth_quartz
fill 398 180 516 398 186 516 minecraft:smooth_quartz
fill 397 181 516 397 186 516 minecraft:smooth_quartz
fill 397 181 518 398 186 518 minecraft:smooth_quartz
fill 399 181 516 399 186 517 minecraft:smooth_quartz
fill 396 182 517 396 186 517 minecraft:smooth_quartz
fill 398 182 515 398 186 515 minecraft:smooth_quartz
fill 399 182 518 399 186 518 minecraft:smooth_quartz
fill 396 183 516 396 186 516 minecraft:smooth_quartz
fill 396 183 518 396 186 518 minecraft:smooth_quartz
fill 397 183 515 397 186 515 minecraft:smooth_quartz
fill 397 183 519 398 186 519 minecraft:smooth_quartz
fill 399 183 515 399 186 515 minecraft:smooth_quartz
fill 400 183 516 400 186 517 minecraft:smooth_quartz
fill 396 184 515 396 186 515 minecraft:smooth_quartz
fill 396 184 519 396 186 519 minecraft:smooth_quartz
fill 399 184 519 399 186 519 minecraft:smooth_quartz
fill 400 184 515 400 186 515 minecraft:smooth_quartz
fill 400 184 518 400 186 518 minecraft:smooth_quartz
fill 395 185 516 395 186 518 minecraft:smooth_quartz
fill 397 185 514 399 186 514 minecraft:smooth_quartz
fill 397 185 520 399 186 520 minecraft:smooth_quartz
fill 400 185 519 400 186 519 minecraft:smooth_quartz
fill 401 185 516 401 186 518 minecraft:smooth_quartz
setblock 379 186 513 minecraft:light[level=14]
setblock 379 186 521 minecraft:light[level=14]
setblock 379 186 529 minecraft:light[level=14]
setblock 379 186 537 minecraft:light[level=14]
setblock 379 186 545 minecraft:light[level=14]
setblock 387 186 513 minecraft:light[level=14]
setblock 387 186 521 minecraft:light[level=14]
setblock 387 186 529 minecraft:light[level=14]
setblock 387 186 537 minecraft:light[level=14]
setblock 387 186 545 minecraft:light[level=14]
setblock 395 186 513 minecraft:light[level=14]
setblock 395 186 515 minecraft:smooth_quartz
setblock 395 186 519 minecraft:smooth_quartz
setblock 395 186 521 minecraft:light[level=14]
setblock 395 186 529 minecraft:light[level=14]
setblock 395 186 537 minecraft:light[level=14]
setblock 395 186 545 minecraft:light[level=14]
setblock 396 186 514 minecraft:smooth_quartz
setblock 396 186 520 minecraft:smooth_quartz
setblock 400 186 514 minecraft:smooth_quartz
setblock 400 186 520 minecraft:smooth_quartz
setblock 401 186 515 minecraft:smooth_quartz
setblock 401 186 519 minecraft:smooth_quartz
setblock 403 186 513 minecraft:light[level=14]
setblock 403 186 521 minecraft:light[level=14]
setblock 403 186 529 minecraft:light[level=14]
setblock 403 186 537 minecraft:light[level=14]
setblock 403 186 545 minecraft:light[level=14]
setblock 411 186 513 minecraft:light[level=14]
setblock 411 186 521 minecraft:light[level=14]
setblock 411 186 529 minecraft:light[level=14]
setblock 411 186 537 minecraft:light[level=14]
setblock 411 186 545 minecraft:light[level=14]
fill 388 187 537 389 188 537 minecraft:white_wool
fill 389 187 536 389 188 536 minecraft:white_wool
fill 389 187 538 389 188 538 minecraft:white_wool
fill 398 187 517 398 190 517 minecraft:quartz_pillar
fill 411 188 531 412 189 532 minecraft:white_wool
fill 396 190 517 397 192 517 minecraft:flowering_azalea_leaves[persistent=true]
fill 397 190 516 399 192 516 minecraft:flowering_azalea_leaves[persistent=true]
fill 397 190 518 399 192 518 minecraft:flowering_azalea_leaves[persistent=true]
fill 398 190 515 398 192 515 minecraft:flowering_azalea_leaves[persistent=true]
fill 399 190 517 399 192 517 minecraft:flowering_azalea_leaves[persistent=true]
fill 409 190 545 409 191 545 minecraft:white_wool
setblock 396 191 516 minecraft:flowering_azalea_leaves[persistent=true]
setblock 396 191 518 minecraft:flowering_azalea_leaves[persistent=true]
setblock 397 191 515 minecraft:flowering_azalea_leaves[persistent=true]
fill 397 191 519 398 191 519 minecraft:flowering_azalea_leaves[persistent=true]
fill 398 191 517 398 192 517 minecraft:flowering_azalea_leaves[persistent=true]
setblock 399 191 515 minecraft:flowering_azalea_leaves[persistent=true]
fill 400 191 516 400 191 517 minecraft:flowering_azalea_leaves[persistent=true]
fill 407 192 539 408 193 539 minecraft:white_wool
fill 376 194 513 376 197 514 minecraft:light_blue_concrete
setblock 376 194 515 minecraft:white_concrete
fill 376 194 516 376 197 516 minecraft:light_blue_concrete
setblock 376 194 518 minecraft:white_concrete
fill 376 194 543 376 198 543 minecraft:light_blue_concrete
setblock 376 194 544 minecraft:white_concrete
fill 376 194 545 376 197 548 minecraft:light_blue_concrete
setblock 379 194 513 minecraft:light[level=14]
setblock 379 194 521 minecraft:light[level=14]
setblock 379 194 529 minecraft:light[level=14]
setblock 379 194 537 minecraft:light[level=14]
setblock 379 194 545 minecraft:light[level=14]
setblock 382 194 510 minecraft:white_concrete
setblock 387 194 513 minecraft:light[level=14]
setblock 387 194 521 minecraft:light[level=14]
setblock 387 194 529 minecraft:light[level=14]
setblock 387 194 537 minecraft:light[level=14]
setblock 387 194 545 minecraft:light[level=14]
setblock 388 194 510 minecraft:white_concrete
fill 388 194 552 390 197 552 minecraft:light_blue_concrete
fill 389 194 510 400 194 510 minecraft:light_blue_concrete
setblock 391 194 552 minecraft:white_concrete
setblock 395 194 513 minecraft:light[level=14]
setblock 395 194 521 minecraft:light[level=14]
setblock 395 194 529 minecraft:light[level=14]
setblock 395 194 537 minecraft:light[level=14]
setblock 395 194 545 minecraft:light[level=14]
fill 399 194 543 399 195 543 minecraft:white_stained_glass
setblock 403 194 513 minecraft:light[level=14]
setblock 403 194 521 minecraft:light[level=14]
setblock 403 194 529 minecraft:light[level=14]
setblock 403 194 537 minecraft:light[level=14]
setblock 403 194 545 minecraft:light[level=14]
setblock 407 194 510 minecraft:white_concrete
fill 408 194 510 408 197 510 minecraft:light_blue_concrete
setblock 411 194 513 minecraft:light[level=14]
setblock 411 194 521 minecraft:light[level=14]
setblock 411 194 529 minecraft:light[level=14]
setblock 411 194 537 minecraft:light[level=14]
setblock 411 194 545 minecraft:light[level=14]
fill 412 194 552 412 195 552 minecraft:white_concrete
fill 415 194 552 416 197 552 minecraft:light_blue_concrete
fill 417 194 552 417 195 552 minecraft:white_concrete
fill 418 194 512 418 197 513 minecraft:light_blue_concrete
setblock 418 194 514 minecraft:white_concrete
fill 418 194 515 418 197 516 minecraft:light_blue_concrete
fill 418 194 523 418 195 523 minecraft:white_concrete
fill 418 194 524 418 198 524 minecraft:light_blue_concrete
fill 418 194 529 418 197 530 minecraft:light_blue_concrete
setblock 418 194 531 minecraft:white_concrete
fill 418 194 532 418 197 533 minecraft:light_blue_concrete
setblock 418 194 534 minecraft:white_concrete
fill 418 194 540 418 195 540 minecraft:white_concrete
fill 418 194 552 418 198 552 minecraft:light_blue_concrete
setblock 376 195 510 minecraft:light_blue_concrete
fill 376 195 511 376 196 511 minecraft:white_concrete
setblock 376 195 515 minecraft:light_blue_concrete
fill 376 195 518 376 197 518 minecraft:light_blue_concrete
setblock 376 195 519 minecraft:white_concrete
fill 376 195 520 376 195 522 minecraft:light_blue_concrete
setblock 376 195 523 minecraft:white_concrete
fill 376 195 524 376 197 525 minecraft:light_blue_concrete
fill 376 195 544 376 197 544 minecraft:light_blue_concrete
fill 377 195 552 378 197 552 minecraft:light_blue_concrete
setblock 379 195 552 minecraft:white_concrete
fill 382 195 510 382 199 510 minecraft:light_blue_concrete
setblock 383 195 510 minecraft:white_concrete
fill 384 195 510 384 197 510 minecraft:light_blue_concrete
fill 388 195 510 391 195 510 minecraft:light_blue_concrete
fill 391 195 552 391 197 552 minecraft:light_blue_concrete
setblock 392 195 510 minecraft:white_concrete
fill 393 195 510 400 195 510 minecraft:light_blue_concrete
fill 393 195 552 393 196 552 minecraft:white_concrete
fill 394 195 552 395 197 552 minecraft:light_blue_concrete
fill 402 195 510 402 197 510 minecraft:light_blue_concrete
setblock 403 195 510 minecraft:white_concrete
fill 404 195 510 404 197 510 minecraft:light_blue_concrete
setblock 405 195 552 minecraft:white_concrete
setblock 406 195 510 minecraft:white_concrete
fill 407 195 510 407 197 510 minecraft:light_blue_concrete
setblock 410 195 510 minecraft:white_concrete
fill 411 195 510 412 195 510 minecraft:light_blue_concrete
setblock 413 195 552 minecraft:white_concrete
setblock 416 195 510 minecraft:white_concrete
fill 417 195 510 417 197 510 minecraft:light_blue_concrete
fill 418 195 514 418 197 514 minecraft:light_blue_concrete
fill 418 195 531 418 197 531 minecraft:light_blue_concrete
fill 418 195 534 418 198 534 minecraft:light_blue_concrete
fill 418 195 544 418 195 546 minecraft:light_blue_concrete
setblock 418 195 547 minecraft:white_concrete
fill 418 195 548 418 197 549 minecraft:light_blue_concrete
setblock 376 196 510 minecraft:white_concrete
setblock 376 196 515 minecraft:white_concrete
fill 376 196 519 376 197 520 minecraft:light_blue_concrete
setblock 376 196 521 minecraft:white_concrete
fill 376 196 522 376 197 523 minecraft:light_blue_concrete
fill 376 196 532 376 197 532 minecraft:light_blue_concrete
setblock 376 196 533 minecraft:white_concrete
setblock 376 196 541 minecraft:white_concrete
fill 376 196 542 376 197 542 minecraft:light_blue_concrete
fill 379 196 552 379 197 552 minecraft:light_blue_concrete
fill 383 196 510 383 197 510 minecraft:light_blue_concrete
fill 388 196 510 390 197 510 minecraft:light_blue_concrete
setblock 391 196 510 minecraft:white_concrete
fill 392 196 510 393 197 510 minecraft:light_blue_concrete
setblock 394 196 510 minecraft:white_concrete
fill 395 196 510 400 197 510 minecraft:light_blue_concrete
fill 398 196 543 399 204 543 minecraft:smooth_quartz
fill 401 196 552 403 197 552 minecraft:light_blue_concrete
fill 403 196 510 403 197 510 minecraft:light_blue_concrete
setblock 404 196 552 minecraft:white_concrete
fill 405 196 552 405 197 552 minecraft:light_blue_concrete
fill 406 196 510 406 197 510 minecraft:light_blue_concrete
setblock 407 196 552 minecraft:white_concrete
fill 408 196 552 409 197 552 minecraft:light_blue_concrete
fill 410 196 510 411 197 510 minecraft:light_blue_concrete
setblock 410 196 552 minecraft:white_concrete
fill 411 196 552 413 197 552 minecraft:light_blue_concrete
setblock 412 196 510 minecraft:white_concrete
fill 414 196 510 414 197 510 minecraft:light_blue_concrete
setblock 415 196 510 minecraft:white_concrete
fill 416 196 510 416 197 510 minecraft:light_blue_concrete
fill 417 196 552 417 197 552 minecraft:light_blue_concrete
setblock 418 196 510 minecraft:white_concrete
setblock 418 196 518 minecraft:white_concrete
fill 418 196 519 418 197 521 minecraft:light_blue_concrete
setblock 418 196 522 minecraft:white_concrete
fill 418 196 523 418 197 523 minecraft:light_blue_concrete
fill 418 196 536 418 197 537 minecraft:light_blue_concrete
setblock 418 196 538 minecraft:white_concrete
fill 418 196 540 418 197 540 minecraft:light_blue_concrete
fill 418 196 544 418 196 545 minecraft:white_concrete
fill 418 196 546 418 197 547 minecraft:light_blue_concrete
fill 376 197 510 376 197 511 minecraft:light_blue_concrete
setblock 376 197 515 minecraft:light_blue_concrete
setblock 376 197 521 minecraft:light_blue_concrete
setblock 376 197 533 minecraft:light_blue_concrete
fill 376 197 541 376 198 541 minecraft:light_blue_concrete
fill 383 197 529 384 198 530 minecraft:white_wool
setblock 391 197 510 minecraft:light_blue_concrete
setblock 393 197 552 minecraft:light_blue_concrete
setblock 394 197 510 minecraft:light_blue_concrete
fill 404 197 552 404 200 552 minecraft:light_blue_concrete
setblock 407 197 552 minecraft:light_blue_concrete
setblock 410 197 552 minecraft:light_blue_concrete
setblock 412 197 510 minecraft:light_blue_concrete
setblock 415 197 510 minecraft:light_blue_concrete
fill 418 197 510 418 200 510 minecraft:light_blue_concrete
setblock 418 197 518 minecraft:light_blue_concrete
setblock 418 197 522 minecraft:light_blue_concrete
setblock 418 197 538 minecraft:light_blue_concrete
fill 418 197 544 418 197 545 minecraft:light_blue_concrete
fill 376 198 510 376 199 512 minecraft:white_concrete
setblock 376 198 513 minecraft:light_blue_concrete
fill 376 198 514 376 199 516 minecraft:white_concrete
fill 376 198 518 376 198 540 minecraft:white_concrete
fill 376 198 542 376 199 542 minecraft:white_concrete
fill 376 198 544 376 308 544 minecraft:white_concrete
fill 376 198 545 376 199 545 minecraft:light_blue_concrete
fill 376 198 546 376 199 552 minecraft:white_concrete
fill 377 198 510 381 308 510 minecraft:white_concrete
setblock 377 198 552 minecraft:light_blue_concrete
fill 378 198 552 403 198 552 minecraft:white_concrete
fill 383 198 510 396 198 510 minecraft:white_concrete
fill 397 198 510 398 198 510 minecraft:light_blue_concrete
fill 398 198 542 399 204 542 minecraft:smooth_quartz
fill 398 198 544 399 204 544 minecraft:smooth_quartz
fill 399 198 510 417 198 510 minecraft:white_concrete
fill 405 198 552 412 198 552 minecraft:white_concrete
fill 406 198 526 407 199 526 minecraft:white_wool
setblock 413 198 552 minecraft:light_blue_concrete
fill 414 198 552 414 308 552 minecraft:white_concrete
setblock 415 198 552 minecraft:light_blue_concrete
fill 416 198 552 417 308 552 minecraft:white_concrete
fill 418 198 511 418 308 515 minecraft:white_concrete
setblock 418 198 516 minecraft:light_blue_concrete
fill 418 198 517 418 308 519 minecraft:white_concrete
setblock 418 198 520 minecraft:light_blue_concrete
fill 418 198 521 418 308 523 minecraft:white_concrete
fill 418 198 525 418 199 533 minecraft:white_concrete
fill 418 198 535 418 199 541 minecraft:white_concrete
fill 418 198 543 418 198 551 minecraft:white_concrete
fill 376 199 513 376 308 513 minecraft:white_concrete
fill 376 199 517 376 199 523 minecraft:white_concrete
fill 376 199 524 376 199 525 minecraft:light_blue_concrete
fill 376 199 526 376 199 541 minecraft:white_concrete
fill 376 199 543 376 308 543 minecraft:white_concrete
fill 377 199 552 389 199 552 minecraft:white_concrete
fill 383 199 510 387 199 510 minecraft:white_concrete
fill 388 199 510 390 199 510 minecraft:light_blue_concrete
setblock 390 199 552 minecraft:light_blue_concrete
fill 391 199 510 416 199 510 minecraft:white_concrete
fill 391 199 552 403 199 552 minecraft:white_concrete
fill 397 199 543 397 204 544 minecraft:smooth_quartz
fill 400 199 543 400 204 544 minecraft:smooth_quartz
fill 405 199 552 409 199 552 minecraft:white_concrete
fill 410 199 552 410 200 552 minecraft:light_blue_concrete
fill 411 199 552 413 308 552 minecraft:white_concrete
fill 415 199 552 415 308 552 minecraft:white_concrete
fill 417 199 510 417 200 510 minecraft:light_blue_concrete
fill 418 199 516 418 308 516 minecraft:white_concrete
fill 418 199 520 418 308 520 minecraft:white_concrete
fill 418 199 524 418 308 524 minecraft:white_concrete
fill 418 199 534 418 308 534 minecraft:white_concrete
fill 418 199 543 418 199 547 minecraft:white_concrete
fill 418 199 548 418 199 549 minecraft:light_blue_concrete
fill 418 199 550 418 199 552 minecraft:white_concrete
setblock 376 200 510 minecraft:light_blue_concrete
fill 376 200 511 376 308 511 minecraft:white_concrete
setblock 376 200 512 minecraft:light_blue_concrete
fill 376 200 514 376 308 514 minecraft:white_concrete
setblock 376 200 515 minecraft:light_blue_concrete
fill 376 200 516 376 308 517 minecraft:white_concrete
setblock 376 200 518 minecraft:light_blue_concrete
fill 376 200 519 376 308 522 minecraft:white_concrete
setblock 376 200 523 minecraft:light_blue_concrete
fill 376 200 524 376 308 540 minecraft:white_concrete
fill 376 200 541 376 200 542 minecraft:light_blue_concrete
fill 376 200 545 376 308 547 minecraft:white_concrete
setblock 376 200 548 minecraft:light_blue_concrete
fill 376 200 549 376 308 552 minecraft:white_concrete
fill 377 200 552 379 308 552 minecraft:white_concrete
setblock 380 200 552 minecraft:light_blue_concrete
fill 381 200 552 394 308 552 minecraft:white_concrete
fill 382 200 510 383 308 510 minecraft:white_concrete
setblock 384 200 510 minecraft:light_blue_concrete
fill 385 200 510 389 308 510 minecraft:white_concrete
setblock 390 200 510 minecraft:light_blue_concrete
fill 391 200 510 391 308 510 minecraft:white_concrete
setblock 392 200 510 minecraft:light_blue_concrete
fill 393 200 510 402 308 510 minecraft:white_concrete
setblock 395 200 552 minecraft:light_blue_concrete
fill 396 200 552 403 308 552 minecraft:white_concrete
fill 397 200 542 397 204 542 minecraft:smooth_quartz
fill 398 200 541 399 204 541 minecraft:smooth_quartz
fill 398 200 545 399 204 545 minecraft:smooth_quartz
fill 400 200 542 400 204 542 minecraft:smooth_quartz
setblock 403 200 510 minecraft:light_blue_concrete
fill 404 200 510 407 308 510 minecraft:white_concrete
fill 405 200 552 405 308 552 minecraft:white_concrete
fill 406 200 552 407 200 552 minecraft:light_blue_concrete
setblock 408 200 510 minecraft:light_blue_concrete
fill 408 200 552 409 308 552 minecraft:white_concrete
fill 409 200 510 409 308 510 minecraft:white_concrete
setblock 410 200 510 minecraft:light_blue_concrete
fill 411 200 510 416 308 510 minecraft:white_concrete
fill 418 200 525 418 308 528 minecraft:white_concrete
setblock 418 200 529 minecraft:light_blue_concrete
fill 418 200 530 418 308 532 minecraft:white_concrete
setblock 418 200 533 minecraft:light_blue_concrete
fill 418 200 535 418 308 535 minecraft:white_concrete
setblock 418 200 536 minecraft:light_blue_concrete
fill 418 200 537 418 308 539 minecraft:white_concrete
setblock 418 200 540 minecraft:light_blue_concrete
fill 418 200 541 418 308 544 minecraft:white_concrete
fill 418 200 545 418 200 546 minecraft:light_blue_concrete
fill 418 200 547 418 308 551 minecraft:white_concrete
setblock 418 200 552 minecraft:light_blue_concrete
fill 376 201 510 376 308 510 minecraft:white_concrete
fill 376 201 512 376 308 512 minecraft:white_concrete
fill 376 201 515 376 308 515 minecraft:white_concrete
fill 376 201 518 376 308 518 minecraft:white_concrete
fill 376 201 523 376 308 523 minecraft:white_concrete
fill 376 201 541 376 308 542 minecraft:white_concrete
fill 376 201 548 376 308 548 minecraft:white_concrete
fill 380 201 552 380 308 552 minecraft:white_concrete
fill 384 201 510 384 308 510 minecraft:white_concrete
fill 390 201 510 390 308 510 minecraft:white_concrete
fill 392 201 510 392 308 510 minecraft:white_concrete
fill 395 201 552 395 308 552 minecraft:white_concrete
fill 396 201 543 396 204 544 minecraft:smooth_quartz
fill 397 201 541 397 204 541 minecraft:smooth_quartz
fill 397 201 545 397 204 545 minecraft:smooth_quartz
fill 400 201 541 400 204 541 minecraft:smooth_quartz
fill 400 201 545 400 204 545 minecraft:smooth_quartz
fill 401 201 542 401 204 544 minecraft:smooth_quartz
fill 403 201 510 403 308 510 minecraft:white_concrete
fill 404 201 552 404 308 552 minecraft:white_concrete
fill 406 201 552 407 308 552 minecraft:white_concrete
fill 408 201 510 408 308 510 minecraft:white_concrete
fill 410 201 510 410 308 510 minecraft:white_concrete
fill 410 201 552 410 308 552 minecraft:white_concrete
fill 417 201 510 418 308 510 minecraft:white_concrete
fill 418 201 529 418 308 529 minecraft:white_concrete
fill 418 201 533 418 308 533 minecraft:white_concrete
fill 418 201 536 418 308 536 minecraft:white_concrete
fill 418 201 540 418 308 540 minecraft:white_concrete
fill 418 201 545 418 308 546 minecraft:white_concrete
fill 418 201 552 418 308 552 minecraft:white_concrete
setblock 379 202 513 minecraft:light[level=14]
setblock 379 202 521 minecraft:light[level=14]
setblock 379 202 529 minecraft:light[level=14]
setblock 379 202 537 minecraft:light[level=14]
setblock 379 202 545 minecraft:light[level=14]
setblock 387 202 513 minecraft:light[level=14]
setblock 387 202 521 minecraft:light[level=14]
setblock 387 202 529 minecraft:light[level=14]
setblock 387 202 537 minecraft:light[level=14]
setblock 387 202 545 minecraft:light[level=14]
setblock 395 202 513 minecraft:light[level=14]
setblock 395 202 521 minecraft:light[level=14]
setblock 395 202 529 minecraft:light[level=14]
setblock 395 202 537 minecraft:light[level=14]
setblock 395 202 545 minecraft:light[level=14]
fill 396 202 542 396 204 542 minecraft:smooth_quartz
fill 396 202 545 396 204 545 minecraft:smooth_quartz
fill 397 202 546 400 204 546 minecraft:smooth_quartz
fill 398 202 540 399 204 540 minecraft:smooth_quartz
fill 401 202 545 401 204 545 minecraft:smooth_quartz
setblock 403 202 513 minecraft:light[level=14]
setblock 403 202 521 minecraft:light[level=14]
setblock 403 202 529 minecraft:light[level=14]
setblock 403 202 537 minecraft:light[level=14]
setblock 403 202 545 minecraft:light[level=14]
setblock 411 202 513 minecraft:light[level=14]
setblock 411 202 521 minecraft:light[level=14]
setblock 411 202 529 minecraft:light[level=14]
setblock 411 202 537 minecraft:light[level=14]
setblock 411 202 545 minecraft:light[level=14]
fill 395 203 543 395 204 544 minecraft:smooth_quartz
fill 396 203 541 396 204 541 minecraft:smooth_quartz
fill 397 203 540 397 204 540 minecraft:smooth_quartz
fill 400 203 540 400 204 540 minecraft:smooth_quartz
fill 401 203 541 401 204 541 minecraft:smooth_quartz
fill 402 203 542 402 204 544 minecraft:smooth_quartz
fill 395 204 541 395 204 542 minecraft:smooth_quartz
setblock 395 204 545 minecraft:smooth_quartz
setblock 396 204 540 minecraft:smooth_quartz
setblock 396 204 546 minecraft:smooth_quartz
fill 397 204 547 400 204 547 minecraft:smooth_quartz
setblock 399 204 539 minecraft:smooth_quartz
setblock 401 204 540 minecraft:smooth_quartz
setblock 401 204 546 minecraft:smooth_quartz
setblock 402 204 541 minecraft:smooth_quartz
setblock 402 204 545 minecraft:smooth_quartz
fill 392 205 514 392 206 514 minecraft:white_wool
fill 398 205 543 399 207 543 minecraft:quartz_pillar
fill 397 208 542 400 210 544 minecraft:flowering_azalea_leaves[persistent=true]
fill 398 208 545 399 210 545 minecraft:flowering_azalea_leaves[persistent=true]
fill 398 209 541 399 209 541 minecraft:flowering_azalea_leaves[persistent=true]
setblock 400 209 545 minecraft:flowering_azalea_leaves[persistent=true]
setblock 379 210 513 minecraft:light[level=14]
setblock 379 210 521 minecraft:light[level=14]
setblock 379 210 529 minecraft:light[level=14]
setblock 379 210 537 minecraft:light[level=14]
setblock 379 210 545 minecraft:light[level=14]
setblock 387 210 513 minecraft:light[level=14]
setblock 387 210 521 minecraft:light[level=14]
setblock 387 210 529 minecraft:light[level=14]
setblock 387 210 537 minecraft:light[level=14]
setblock 387 210 545 minecraft:light[level=14]
setblock 395 210 513 minecraft:light[level=14]
setblock 395 210 521 minecraft:light[level=14]
setblock 395 210 529 minecraft:light[level=14]
setblock 395 210 537 minecraft:light[level=14]
setblock 395 210 545 minecraft:light[level=14]
setblock 403 210 513 minecraft:light[level=14]
setblock 403 210 521 minecraft:light[level=14]
setblock 403 210 529 minecraft:light[level=14]
setblock 403 210 537 minecraft:light[level=14]
setblock 403 210 545 minecraft:light[level=14]
setblock 411 210 513 minecraft:light[level=14]
setblock 411 210 521 minecraft:light[level=14]
setblock 411 210 529 minecraft:light[level=14]
setblock 411 210 537 minecraft:light[level=14]
setblock 411 210 545 minecraft:light[level=14]
fill 405 215 534 406 216 534 minecraft:white_wool
fill 387 216 522 389 217 523 minecraft:white_wool
setblock 379 218 513 minecraft:light[level=14]
setblock 379 218 521 minecraft:light[level=14]
setblock 379 218 529 minecraft:light[level=14]
setblock 379 218 537 minecraft:light[level=14]
setblock 379 218 545 minecraft:light[level=14]
setblock 387 218 513 minecraft:light[level=14]
setblock 387 218 521 minecraft:light[level=14]
setblock 387 218 529 minecraft:light[level=14]
setblock 387 218 537 minecraft:light[level=14]
setblock 387 218 545 minecraft:light[level=14]
setblock 395 218 513 minecraft:light[level=14]
setblock 395 218 521 minecraft:light[level=14]
setblock 395 218 529 minecraft:light[level=14]
setblock 395 218 537 minecraft:light[level=14]
setblock 395 218 545 minecraft:light[level=14]
setblock 403 218 513 minecraft:light[level=14]
setblock 403 218 521 minecraft:light[level=14]
setblock 403 218 529 minecraft:light[level=14]
setblock 403 218 537 minecraft:light[level=14]
setblock 403 218 545 minecraft:light[level=14]
setblock 411 218 513 minecraft:light[level=14]
setblock 411 218 521 minecraft:light[level=14]
setblock 411 218 529 minecraft:light[level=14]
setblock 411 218 537 minecraft:light[level=14]
setblock 411 218 545 minecraft:light[level=14]
fill 389 224 528 389 226 530 minecraft:gold_block
fill 389 224 531 393 224 531 minecraft:white_wool
fill 389 224 532 389 226 534 minecraft:gold_block
fill 390 224 526 390 226 527 minecraft:gold_block
fill 390 224 528 394 224 530 minecraft:white_wool
fill 390 224 532 394 224 534 minecraft:white_wool
fill 390 224 535 390 226 536 minecraft:gold_block
fill 391 224 525 391 226 526 minecraft:gold_block
fill 391 224 527 401 225 527 minecraft:white_wool
fill 391 224 535 401 225 535 minecraft:white_wool
fill 391 224 536 391 226 537 minecraft:gold_block
fill 392 224 525 392 226 525 minecraft:gold_block
fill 392 224 526 400 225 526 minecraft:white_wool
fill 392 224 536 400 225 536 minecraft:white_wool
fill 392 224 537 392 226 537 minecraft:gold_block
fill 393 224 524 395 226 524 minecraft:gold_block
fill 393 224 525 399 225 525 minecraft:white_wool
fill 393 224 537 399 225 537 minecraft:white_wool
fill 393 224 538 395 226 538 minecraft:gold_block
fill 395 224 528 395 224 529 minecraft:white_wool
fill 395 224 533 395 224 534 minecraft:white_wool
fill 396 224 524 396 225 524 minecraft:white_wool
fill 396 224 528 402 224 528 minecraft:white_wool
fill 396 224 534 402 224 534 minecraft:white_wool
fill 396 224 538 396 225 538 minecraft:white_wool
fill 397 224 524 399 226 524 minecraft:gold_block
fill 397 224 529 402 224 529 minecraft:white_wool
fill 397 224 533 402 224 533 minecraft:white_wool
fill 397 224 538 399 226 538 minecraft:gold_block
fill 398 224 530 402 224 530 minecraft:white_wool
fill 398 224 532 402 224 532 minecraft:white_wool
fill 399 224 531 403 224 531 minecraft:white_wool
fill 400 224 525 401 226 525 minecraft:gold_block
fill 400 224 537 401 226 537 minecraft:gold_block
fill 401 224 526 402 226 526 minecraft:gold_block
fill 401 224 536 402 226 536 minecraft:gold_block
fill 402 224 527 402 226 527 minecraft:gold_block
fill 402 224 535 402 226 535 minecraft:gold_block
fill 403 224 528 403 226 530 minecraft:gold_block
fill 403 224 532 403 226 534 minecraft:gold_block
fill 377 225 511 387 225 551 minecraft:white_wool
fill 388 225 511 388 225 528 minecraft:white_wool
fill 388 225 529 388 225 533 minecraft:gold_block
fill 388 225 534 388 225 551 minecraft:white_wool
fill 389 225 511 389 225 526 minecraft:white_wool
setblock 389 225 527 minecraft:gold_block
fill 389 225 531 392 225 531 minecraft:white_wool
setblock 389 225 535 minecraft:gold_block
fill 389 225 536 389 225 551 minecraft:white_wool
fill 390 225 511 390 225 525 minecraft:white_wool
fill 390 225 528 392 225 530 minecraft:white_wool
fill 390 225 532 392 225 534 minecraft:white_wool
fill 390 225 537 390 225 551 minecraft:white_wool
fill 391 225 511 391 225 524 minecraft:white_wool
fill 391 225 538 391 225 551 minecraft:white_wool
fill 392 225 511 393 225 523 minecraft:white_wool
setblock 392 225 524 minecraft:gold_block
setblock 392 225 538 minecraft:gold_block
fill 392 225 539 393 225 551 minecraft:white_wool
fill 393 225 528 393 225 529 minecraft:white_wool
fill 393 225 530 393 225 532 minecraft:pearlescent_froglight
fill 393 225 533 393 225 534 minecraft:white_wool
fill 394 225 511 417 225 522 minecraft:white_wool
fill 394 225 523 398 225 523 minecraft:gold_block
setblock 394 225 528 minecraft:white_wool
fill 394 225 529 394 225 530 minecraft:pearlescent_froglight
fill 394 225 532 394 225 533 minecraft:pearlescent_froglight
setblock 394 225 534 minecraft:white_wool
fill 394 225 539 398 225 539 minecraft:gold_block
fill 394 225 540 417 225 551 minecraft:white_wool
fill 395 225 528 395 225 529 minecraft:pearlescent_froglight
fill 395 225 533 395 225 534 minecraft:pearlescent_froglight
fill 396 225 528 397 225 528 minecraft:pearlescent_froglight
fill 396 225 534 397 225 534 minecraft:pearlescent_froglight
fill 397 225 529 398 225 529 minecraft:pearlescent_froglight
fill 397 225 533 398 225 533 minecraft:pearlescent_froglight
fill 398 225 528 402 225 528 minecraft:white_wool
fill 398 225 530 399 225 530 minecraft:pearlescent_froglight
fill 398 225 532 399 225 532 minecraft:pearlescent_froglight
fill 398 225 534 402 225 534 minecraft:white_wool
fill 399 225 523 417 225 523 minecraft:white_wool
fill 399 225 529 402 225 529 minecraft:white_wool
setblock 399 225 531 minecraft:pearlescent_froglight
fill 399 225 533 402 225 533 minecraft:white_wool
fill 399 225 539 417 225 539 minecraft:white_wool
setblock 400 225 524 minecraft:gold_block
fill 400 225 530 402 225 532 minecraft:white_wool
setblock 400 225 538 minecraft:gold_block
fill 401 225 524 417 225 524 minecraft:white_wool
fill 401 225 538 417 225 538 minecraft:white_wool
fill 402 225 525 417 225 525 minecraft:white_wool
fill 402 225 537 417 225 537 minecraft:white_wool
fill 403 225 526 417 225 526 minecraft:white_wool
setblock 403 225 527 minecraft:gold_block
setblock 403 225 531 minecraft:white_wool
setblock 403 225 535 minecraft:gold_block
fill 403 225 536 417 225 536 minecraft:white_wool
fill 404 225 527 417 225 528 minecraft:white_wool
fill 404 225 529 404 225 533 minecraft:gold_block
fill 404 225 534 417 225 535 minecraft:white_wool
fill 405 225 529 417 225 533 minecraft:white_wool
setblock 379 226 513 minecraft:light[level=14]
setblock 379 226 521 minecraft:light[level=14]
setblock 379 226 529 minecraft:light[level=14]
setblock 379 226 537 minecraft:light[level=14]
setblock 379 226 545 minecraft:light[level=14]
setblock 387 226 513 minecraft:light[level=14]
setblock 387 226 521 minecraft:light[level=14]
setblock 387 226 529 minecraft:light[level=14]
setblock 387 226 537 minecraft:light[level=14]
setblock 387 226 545 minecraft:light[level=14]
setblock 389 226 531 minecraft:gold_block
fill 390 226 528 390 226 530 minecraft:gold_block
fill 390 226 532 390 226 534 minecraft:gold_block
setblock 391 226 527 minecraft:gold_block
setblock 391 226 535 minecraft:gold_block
setblock 392 226 526 minecraft:gold_block
setblock 392 226 536 minecraft:gold_block
fill 393 226 525 395 226 525 minecraft:gold_block
fill 393 226 537 395 226 537 minecraft:gold_block
setblock 395 226 513 minecraft:light[level=14]
setblock 395 226 521 minecraft:light[level=14]
setblock 395 226 529 minecraft:light[level=14]
setblock 395 226 545 minecraft:light[level=14]
setblock 396 226 524 minecraft:gold_block
setblock 396 226 538 minecraft:gold_block
fill 397 226 525 399 226 525 minecraft:gold_block
fill 397 226 537 399 226 537 minecraft:gold_block
setblock 400 226 526 minecraft:gold_block
setblock 400 226 536 minecraft:gold_block
setblock 401 226 527 minecraft:gold_block
setblock 401 226 535 minecraft:gold_block
fill 402 226 528 402 226 530 minecraft:gold_block
fill 402 226 532 402 226 534 minecraft:gold_block
setblock 403 226 513 minecraft:light[level=14]
setblock 403 226 521 minecraft:light[level=14]
setblock 403 226 531 minecraft:gold_block
setblock 403 226 537 minecraft:light[level=14]
setblock 403 226 545 minecraft:light[level=14]
setblock 411 226 513 minecraft:light[level=14]
setblock 411 226 521 minecraft:light[level=14]
setblock 411 226 529 minecraft:light[level=14]
setblock 411 226 537 minecraft:light[level=14]
setblock 411 226 545 minecraft:light[level=14]
fill 379 229 513 379 229 516 minecraft:smooth_quartz
setblock 380 229 513 minecraft:smooth_quartz
fill 380 229 514 382 273 516 minecraft:quartz_pillar
setblock 381 229 512 minecraft:smooth_quartz
fill 381 229 513 381 273 513 minecraft:quartz_pillar
setblock 381 229 517 minecraft:smooth_quartz
fill 382 229 513 383 229 513 minecraft:smooth_quartz
fill 383 229 514 383 229 516 minecraft:smooth_quartz
fill 382 230 526 382 231 526 minecraft:white_stained_glass
fill 382 232 525 382 241 526 minecraft:smooth_quartz
setblock 379 234 513 minecraft:light[level=14]
setblock 379 234 521 minecraft:light[level=14]
setblock 379 234 529 minecraft:light[level=14]
setblock 379 234 537 minecraft:light[level=14]
setblock 379 234 545 minecraft:light[level=14]
fill 381 234 525 381 241 526 minecraft:smooth_quartz
fill 383 234 525 383 241 526 minecraft:smooth_quartz
setblock 387 234 513 minecraft:light[level=14]
setblock 387 234 521 minecraft:light[level=14]
setblock 387 234 529 minecraft:light[level=14]
setblock 387 234 537 minecraft:light[level=14]
setblock 387 234 545 minecraft:light[level=14]
setblock 395 234 513 minecraft:light[level=14]
setblock 395 234 521 minecraft:light[level=14]
setblock 395 234 529 minecraft:light[level=14]
setblock 395 234 537 minecraft:light[level=14]
setblock 395 234 545 minecraft:light[level=14]
setblock 403 234 513 minecraft:light[level=14]
setblock 403 234 521 minecraft:light[level=14]
setblock 403 234 529 minecraft:light[level=14]
setblock 403 234 537 minecraft:light[level=14]
setblock 403 234 545 minecraft:light[level=14]
setblock 411 234 513 minecraft:light[level=14]
setblock 411 234 521 minecraft:light[level=14]
setblock 411 234 529 minecraft:light[level=14]
setblock 411 234 537 minecraft:light[level=14]
setblock 411 234 545 minecraft:light[level=14]
fill 381 235 527 383 241 527 minecraft:smooth_quartz
fill 382 235 524 383 241 524 minecraft:smooth_quartz
fill 380 236 525 380 241 526 minecraft:smooth_quartz
fill 381 236 524 381 241 524 minecraft:smooth_quartz
fill 384 236 525 384 241 526 minecraft:smooth_quartz
fill 379 237 513 379 237 516 minecraft:smooth_quartz
setblock 380 237 513 minecraft:smooth_quartz
fill 380 237 524 380 241 524 minecraft:smooth_quartz
fill 380 237 527 380 241 527 minecraft:smooth_quartz
setblock 381 237 512 minecraft:smooth_quartz
setblock 381 237 517 minecraft:smooth_quartz
fill 381 237 523 383 241 523 minecraft:smooth_quartz
fill 381 237 528 383 241 528 minecraft:smooth_quartz
fill 382 237 513 383 237 513 minecraft:smooth_quartz
fill 383 237 514 383 237 516 minecraft:smooth_quartz
fill 384 237 524 384 241 524 minecraft:smooth_quartz
fill 384 237 527 384 241 527 minecraft:smooth_quartz
fill 379 238 525 379 241 526 minecraft:smooth_quartz
fill 380 238 523 380 241 523 minecraft:smooth_quartz
fill 380 238 528 380 241 528 minecraft:smooth_quartz
fill 384 238 523 384 241 523 minecraft:smooth_quartz
fill 384 238 528 384 241 528 minecraft:smooth_quartz
fill 385 238 524 385 241 527 minecraft:smooth_quartz
fill 379 239 524 379 241 524 minecraft:smooth_quartz
fill 379 239 527 379 241 527 minecraft:smooth_quartz
fill 381 239 522 383 241 522 minecraft:smooth_quartz
fill 381 239 529 383 241 529 minecraft:smooth_quartz
fill 391 239 544 391 240 544 minecraft:white_stained_glass
fill 378 240 525 378 241 526 minecraft:smooth_quartz
fill 379 240 523 379 241 523 minecraft:smooth_quartz
fill 379 240 528 379 241 528 minecraft:smooth_quartz
fill 380 240 522 380 241 522 minecraft:smooth_quartz
fill 380 240 529 380 241 529 minecraft:smooth_quartz
fill 384 240 522 384 241 522 minecraft:smooth_quartz
fill 384 240 529 384 241 529 minecraft:smooth_quartz
fill 385 240 523 385 241 523 minecraft:smooth_quartz
fill 385 240 528 385 241 528 minecraft:smooth_quartz
fill 386 240 524 386 241 527 minecraft:smooth_quartz
setblock 378 241 524 minecraft:smooth_quartz
fill 378 241 527 378 241 528 minecraft:smooth_quartz
setblock 379 241 522 minecraft:smooth_quartz
setblock 379 241 529 minecraft:smooth_quartz
fill 381 241 521 383 241 521 minecraft:smooth_quartz
fill 381 241 530 383 241 530 minecraft:smooth_quartz
setblock 385 241 522 minecraft:smooth_quartz
setblock 385 241 529 minecraft:smooth_quartz
setblock 386 241 523 minecraft:smooth_quartz
setblock 386 241 528 minecraft:smooth_quartz
fill 391 241 544 391 250 544 minecraft:smooth_quartz
fill 396 241 516 396 242 516 minecraft:white_wool
setblock 379 242 513 minecraft:light[level=14]
setblock 379 242 521 minecraft:light[level=14]
setblock 379 242 529 minecraft:light[level=14]
setblock 379 242 537 minecraft:light[level=14]
setblock 379 242 545 minecraft:light[level=14]
fill 382 242 525 382 244 526 minecraft:quartz_pillar
setblock 387 242 513 minecraft:light[level=14]
setblock 387 242 521 minecraft:light[level=14]
setblock 387 242 529 minecraft:light[level=14]
setblock 387 242 537 minecraft:light[level=14]
setblock 387 242 545 minecraft:light[level=14]
fill 391 242 543 391 250 543 minecraft:smooth_quartz
fill 391 242 545 391 250 545 minecraft:smooth_quartz
fill 392 242 544 392 250 544 minecraft:smooth_quartz
setblock 395 242 513 minecraft:light[level=14]
setblock 395 242 521 minecraft:light[level=14]
setblock 395 242 529 minecraft:light[level=14]
setblock 395 242 537 minecraft:light[level=14]
setblock 395 242 545 minecraft:light[level=14]
setblock 403 242 513 minecraft:light[level=14]
setblock 403 242 521 minecraft:light[level=14]
setblock 403 242 529 minecraft:light[level=14]
setblock 403 242 537 minecraft:light[level=14]
setblock 403 242 545 minecraft:light[level=14]
setblock 411 242 513 minecraft:light[level=14]
setblock 411 242 521 minecraft:light[level=14]
setblock 411 242 529 minecraft:light[level=14]
setblock 411 242 537 minecraft:light[level=14]
setblock 411 242 545 minecraft:light[level=14]
fill 390 243 543 390 250 545 minecraft:smooth_quartz
fill 392 243 543 392 250 543 minecraft:smooth_quartz
fill 392 243 545 392 250 545 minecraft:smooth_quartz
fill 385 244 544 389 245 548 minecraft:smooth_quartz
fill 387 244 549 387 244 550 minecraft:smooth_quartz
fill 393 244 544 393 250 544 minecraft:smooth_quartz
fill 402 244 546 402 245 546 minecraft:white_stained_glass
fill 379 245 513 379 245 516 minecraft:smooth_quartz
setblock 380 245 513 minecraft:smooth_quartz
setblock 381 245 512 minecraft:smooth_quartz
setblock 381 245 517 minecraft:smooth_quartz
fill 381 245 524 383 247 527 minecraft:flowering_azalea_leaves[persistent=true]
fill 382 245 513 383 245 513 minecraft:smooth_quartz
fill 383 245 514 383 245 516 minecraft:smooth_quartz
fill 384 245 525 384 247 526 minecraft:flowering_azalea_leaves[persistent=true]
fill 389 245 543 389 250 543 minecraft:smooth_quartz
fill 390 245 542 392 250 542 minecraft:smooth_quartz
fill 390 245 546 392 250 546 minecraft:smooth_quartz
fill 393 245 543 393 250 543 minecraft:smooth_quartz
fill 393 245 545 393 250 545 minecraft:smooth_quartz
fill 380 246 525 380 246 526 minecraft:flowering_azalea_leaves[persistent=true]
fill 387 246 546 387 249 546 minecraft:quartz_pillar
fill 389 246 542 389 250 542 minecraft:smooth_quartz
fill 389 246 544 389 250 546 minecraft:smooth_quartz
fill 393 246 542 393 250 542 minecraft:smooth_quartz
fill 393 246 546 393 250 546 minecraft:smooth_quartz
fill 394 246 544 394 250 544 minecraft:smooth_quartz
fill 402 246 546 402 257 546 minecraft:smooth_quartz
fill 388 247 543 388 250 545 minecraft:smooth_quartz
fill 390 247 541 392 250 541 minecraft:smooth_quartz
fill 390 247 547 392 250 547 minecraft:smooth_quartz
fill 394 247 543 394 250 543 minecraft:smooth_quartz
fill 394 247 545 394 250 545 minecraft:smooth_quartz
fill 401 247 546 401 257 546 minecraft:smooth_quartz
fill 402 247 545 402 257 545 minecraft:smooth_quartz
fill 388 248 542 388 250 542 minecraft:smooth_quartz
fill 388 248 546 388 250 546 minecraft:smooth_quartz
fill 389 248 541 389 250 541 minecraft:smooth_quartz
fill 389 248 547 389 250 547 minecraft:smooth_quartz
fill 393 248 541 393 250 541 minecraft:smooth_quartz
fill 393 248 547 393 250 547 minecraft:smooth_quartz
fill 394 248 542 394 250 542 minecraft:smooth_quartz
fill 394 248 546 394 250 546 minecraft:smooth_quartz
fill 401 248 545 401 257 545 minecraft:smooth_quartz
fill 401 248 547 402 257 547 minecraft:smooth_quartz
fill 403 248 545 403 257 546 minecraft:smooth_quartz
fill 387 249 543 387 250 545 minecraft:smooth_quartz
fill 388 249 541 388 250 541 minecraft:smooth_quartz
fill 388 249 547 388 250 547 minecraft:smooth_quartz
fill 390 249 540 392 250 540 minecraft:smooth_quartz
fill 390 249 548 392 250 548 minecraft:smooth_quartz
fill 394 249 541 394 250 541 minecraft:smooth_quartz
fill 394 249 547 394 250 547 minecraft:smooth_quartz
fill 395 249 543 395 250 545 minecraft:smooth_quartz
fill 400 249 546 400 257 546 minecraft:smooth_quartz
fill 402 249 544 402 257 544 minecraft:smooth_quartz
fill 403 249 547 403 257 547 minecraft:smooth_quartz
setblock 379 250 513 minecraft:light[level=14]
setblock 379 250 521 minecraft:light[level=14]
setblock 379 250 529 minecraft:light[level=14]
setblock 379 250 537 minecraft:light[level=14]
setblock 379 250 545 minecraft:light[level=14]
fill 385 250 546 386 253 546 minecraft:gold_block
fill 386 250 545 386 253 545 minecraft:gold_block
fill 386 250 547 387 253 547 minecraft:gold_block
setblock 387 250 513 minecraft:light[level=14]
setblock 387 250 521 minecraft:light[level=14]
setblock 387 250 529 minecraft:light[level=14]
setblock 387 250 537 minecraft:light[level=14]
setblock 387 250 542 minecraft:smooth_quartz
setblock 387 250 546 minecraft:smooth_quartz
fill 387 250 548 387 253 548 minecraft:gold_block
setblock 389 250 540 minecraft:smooth_quartz
setblock 389 250 548 minecraft:smooth_quartz
setblock 393 250 540 minecraft:smooth_quartz
setblock 393 250 548 minecraft:smooth_quartz
setblock 395 250 513 minecraft:light[level=14]
setblock 395 250 521 minecraft:light[level=14]
setblock 395 250 529 minecraft:light[level=14]
setblock 395 250 537 minecraft:light[level=14]
setblock 395 250 542 minecraft:smooth_quartz
setblock 395 250 546 minecraft:smooth_quartz
fill 400 250 545 400 257 545 minecraft:smooth_quartz
fill 400 250 547 400 257 547 minecraft:smooth_quartz
fill 401 250 544 401 257 544 minecraft:smooth_quartz
fill 401 250 548 403 257 548 minecraft:smooth_quartz
setblock 403 250 513 minecraft:light[level=14]
setblock 403 250 521 minecraft:light[level=14]
setblock 403 250 529 minecraft:light[level=14]
setblock 403 250 537 minecraft:light[level=14]
fill 403 250 544 403 257 544 minecraft:smooth_quartz
fill 404 250 545 404 257 547 minecraft:smooth_quartz
setblock 411 250 513 minecraft:light[level=14]
setblock 411 250 521 minecraft:light[level=14]
setblock 411 250 529 minecraft:light[level=14]
setblock 411 250 537 minecraft:light[level=14]
setblock 411 250 545 minecraft:light[level=14]
fill 385 251 545 385 252 545 minecraft:gold_block
fill 385 251 547 385 252 547 minecraft:gold_block
fill 386 251 544 388 252 544 minecraft:gold_block
fill 386 251 548 386 252 548 minecraft:gold_block
fill 387 251 545 389 252 546 minecraft:gold_block
fill 388 251 547 388 252 548 minecraft:gold_block
fill 389 251 547 389 252 547 minecraft:gold_block
fill 391 251 544 391 254 544 minecraft:quartz_pillar
fill 399 251 546 399 257 546 minecraft:smooth_quartz
fill 400 251 544 400 257 544 minecraft:smooth_quartz
fill 400 251 548 400 257 548 minecraft:smooth_quartz
fill 402 251 543 402 257 543 minecraft:smooth_quartz
fill 404 251 544 404 257 544 minecraft:smooth_quartz
fill 399 252 544 399 257 545 minecraft:smooth_quartz
fill 399 252 547 399 257 547 minecraft:smooth_quartz
fill 400 252 543 401 257 543 minecraft:smooth_quartz
fill 401 252 549 403 257 549 minecraft:smooth_quartz
fill 403 252 543 403 257 543 minecraft:smooth_quartz
fill 404 252 548 404 257 548 minecraft:smooth_quartz
fill 405 252 545 405 257 547 minecraft:smooth_quartz
fill 379 253 513 379 253 516 minecraft:smooth_quartz
setblock 380 253 513 minecraft:smooth_quartz
setblock 381 253 512 minecraft:smooth_quartz
setblock 381 253 517 minecraft:smooth_quartz
fill 382 253 513 383 253 513 minecraft:smooth_quartz
fill 383 253 514 383 253 516 minecraft:smooth_quartz
fill 387 253 544 387 253 546 minecraft:gold_block
fill 388 253 545 388 253 547 minecraft:gold_block
setblock 389 253 546 minecraft:gold_block
fill 398 253 541 398 254 541 minecraft:white_wool
fill 398 253 545 398 257 546 minecraft:smooth_quartz
fill 399 253 548 399 257 548 minecraft:smooth_quartz
fill 400 253 549 400 257 549 minecraft:smooth_quartz
fill 401 253 542 402 257 542 minecraft:smooth_quartz
fill 404 253 543 404 257 543 minecraft:smooth_quartz
fill 404 253 549 404 257 549 minecraft:smooth_quartz
fill 405 253 544 405 257 544 minecraft:smooth_quartz
fill 405 253 548 405 257 548 minecraft:smooth_quartz
setblock 387 254 546 minecraft:gold_block
fill 390 254 543 390 256 545 minecraft:flowering_azalea_leaves[persistent=true]
fill 391 254 543 392 256 543 minecraft:flowering_azalea_leaves[persistent=true]
fill 391 254 545 392 256 545 minecraft:flowering_azalea_leaves[persistent=true]
fill 392 254 544 393 256 544 minecraft:flowering_azalea_leaves[persistent=true]
fill 398 254 544 398 257 544 minecraft:smooth_quartz
fill 398 254 547 398 257 548 minecraft:smooth_quartz
fill 399 254 543 399 257 543 minecraft:smooth_quartz
fill 399 254 549 399 257 549 minecraft:smooth_quartz
fill 400 254 542 400 257 542 minecraft:smooth_quartz
fill 401 254 550 403 257 550 minecraft:smooth_quartz
fill 403 254 542 404 257 542 minecraft:smooth_quartz
fill 405 254 543 405 257 543 minecraft:smooth_quartz
fill 405 254 549 405 257 549 minecraft:smooth_quartz
fill 406 254 545 406 257 547 minecraft:smooth_quartz
fill 389 255 543 389 255 545 minecraft:flowering_azalea_leaves[persistent=true]
fill 390 255 542 392 255 542 minecraft:flowering_azalea_leaves[persistent=true]
fill 390 255 546 392 255 546 minecraft:flowering_azalea_leaves[persistent=true]
fill 391 255 544 391 256 544 minecraft:flowering_azalea_leaves[persistent=true]
setblock 393 255 543 minecraft:flowering_azalea_leaves[persistent=true]
setblock 393 255 545 minecraft:flowering_azalea_leaves[persistent=true]
fill 397 255 545 397 257 547 minecraft:smooth_quartz
fill 398 255 543 398 257 543 minecraft:smooth_quartz
fill 398 255 549 398 257 549 minecraft:smooth_quartz
fill 399 255 542 399 257 542 minecraft:smooth_quartz
fill 400 255 550 400 257 550 minecraft:smooth_quartz
fill 401 255 541 402 257 541 minecraft:smooth_quartz
fill 404 255 550 404 257 550 minecraft:smooth_quartz
fill 405 255 542 405 257 542 minecraft:smooth_quartz
fill 406 255 544 406 257 544 minecraft:smooth_quartz
fill 406 255 548 406 257 548 minecraft:smooth_quartz
fill 397 256 544 397 257 544 minecraft:smooth_quartz
fill 397 256 548 397 257 548 minecraft:smooth_quartz
fill 398 256 542 398 257 542 minecraft:smooth_quartz
fill 399 256 550 399 257 550 minecraft:smooth_quartz
fill 400 256 541 400 257 541 minecraft:smooth_quartz
fill 400 256 551 403 257 551 minecraft:smooth_quartz
fill 403 256 541 404 257 541 minecraft:smooth_quartz
fill 405 256 550 405 257 550 minecraft:smooth_quartz
fill 406 256 543 406 257 543 minecraft:smooth_quartz
fill 406 256 549 406 257 549 minecraft:smooth_quartz
fill 407 256 544 407 257 547 minecraft:smooth_quartz
fill 396 257 545 396 257 547 minecraft:smooth_quartz
setblock 397 257 543 minecraft:smooth_quartz
setblock 397 257 549 minecraft:smooth_quartz
setblock 398 257 550 minecraft:smooth_quartz
setblock 399 257 541 minecraft:smooth_quartz
setblock 399 257 551 minecraft:smooth_quartz
fill 401 257 540 403 257 540 minecraft:smooth_quartz
setblock 404 257 551 minecraft:smooth_quartz
setblock 405 257 541 minecraft:smooth_quartz
setblock 406 257 542 minecraft:smooth_quartz
setblock 406 257 550 minecraft:smooth_quartz
setblock 407 257 543 minecraft:smooth_quartz
setblock 407 257 548 minecraft:smooth_quartz
setblock 379 258 513 minecraft:light[level=14]
setblock 379 258 521 minecraft:light[level=14]
setblock 379 258 529 minecraft:light[level=14]
setblock 379 258 537 minecraft:light[level=14]
setblock 379 258 545 minecraft:light[level=14]
setblock 387 258 513 minecraft:light[level=14]
setblock 387 258 521 minecraft:light[level=14]
setblock 387 258 529 minecraft:light[level=14]
setblock 387 258 537 minecraft:light[level=14]
setblock 387 258 545 minecraft:light[level=14]
setblock 395 258 513 minecraft:light[level=14]
setblock 395 258 521 minecraft:light[level=14]
setblock 395 258 529 minecraft:light[level=14]
setblock 395 258 537 minecraft:light[level=14]
setblock 395 258 545 minecraft:light[level=14]
fill 402 258 546 402 261 546 minecraft:quartz_pillar
setblock 403 258 513 minecraft:light[level=14]
setblock 403 258 521 minecraft:light[level=14]
setblock 403 258 529 minecraft:light[level=14]
setblock 403 258 537 minecraft:light[level=14]
setblock 403 258 545 minecraft:light[level=14]
setblock 411 258 513 minecraft:light[level=14]
setblock 411 258 521 minecraft:light[level=14]
setblock 411 258 529 minecraft:light[level=14]
setblock 411 258 537 minecraft:light[level=14]
setblock 411 258 545 minecraft:light[level=14]
fill 387 259 529 387 260 529 minecraft:white_wool
fill 408 259 530 410 260 531 minecraft:white_wool
fill 385 260 542 385 261 542 minecraft:white_wool
fill 379 261 513 379 261 516 minecraft:smooth_quartz
setblock 380 261 513 minecraft:smooth_quartz
setblock 381 261 512 minecraft:smooth_quartz
setblock 381 261 517 minecraft:smooth_quartz
fill 382 261 513 383 261 513 minecraft:smooth_quartz
fill 383 261 514 383 261 516 minecraft:smooth_quartz
fill 400 261 546 401 263 546 minecraft:flowering_azalea_leaves[persistent=true]
fill 401 261 545 403 263 545 minecraft:flowering_azalea_leaves[persistent=true]
fill 401 261 547 403 263 547 minecraft:flowering_azalea_leaves[persistent=true]
fill 402 261 544 402 263 544 minecraft:flowering_azalea_leaves[persistent=true]
fill 403 261 546 403 263 546 minecraft:flowering_azalea_leaves[persistent=true]
setblock 400 262 545 minecraft:flowering_azalea_leaves[persistent=true]
setblock 400 262 547 minecraft:flowering_azalea_leaves[persistent=true]
setblock 401 262 544 minecraft:flowering_azalea_leaves[persistent=true]
fill 401 262 548 402 262 548 minecraft:flowering_azalea_leaves[persistent=true]
fill 402 262 546 402 263 546 minecraft:flowering_azalea_leaves[persistent=true]
setblock 403 262 544 minecraft:flowering_azalea_leaves[persistent=true]
fill 404 262 545 404 262 546 minecraft:flowering_azalea_leaves[persistent=true]
fill 394 263 548 395 264 548 minecraft:white_wool
fill 395 263 547 395 264 547 minecraft:white_wool
setblock 379 266 513 minecraft:light[level=14]
setblock 379 266 521 minecraft:light[level=14]
setblock 379 266 529 minecraft:light[level=14]
setblock 379 266 537 minecraft:light[level=14]
setblock 379 266 545 minecraft:light[level=14]
setblock 387 266 513 minecraft:light[level=14]
setblock 387 266 521 minecraft:light[level=14]
setblock 387 266 529 minecraft:light[level=14]
setblock 387 266 537 minecraft:light[level=14]
setblock 387 266 545 minecraft:light[level=14]
setblock 395 266 513 minecraft:light[level=14]
setblock 395 266 521 minecraft:light[level=14]
setblock 395 266 529 minecraft:light[level=14]
setblock 395 266 537 minecraft:light[level=14]
setblock 395 266 545 minecraft:light[level=14]
setblock 403 266 513 minecraft:light[level=14]
setblock 403 266 521 minecraft:light[level=14]
setblock 403 266 529 minecraft:light[level=14]
setblock 403 266 537 minecraft:light[level=14]
setblock 403 266 545 minecraft:light[level=14]
fill 406 266 525 407 267 526 minecraft:white_wool
setblock 411 266 513 minecraft:light[level=14]
setblock 411 266 521 minecraft:light[level=14]
setblock 411 266 529 minecraft:light[level=14]
setblock 411 266 537 minecraft:light[level=14]
setblock 411 266 545 minecraft:light[level=14]
fill 389 268 539 390 269 540 minecraft:white_wool
fill 379 269 513 379 269 516 minecraft:smooth_quartz
setblock 380 269 513 minecraft:smooth_quartz
setblock 381 269 512 minecraft:smooth_quartz
setblock 381 269 517 minecraft:smooth_quartz
fill 382 269 513 383 269 513 minecraft:smooth_quartz
fill 383 269 514 383 269 516 minecraft:smooth_quartz
fill 379 272 514 379 273 515 minecraft:gold_block
fill 380 272 513 380 273 513 minecraft:gold_block
fill 382 272 513 382 273 513 minecraft:gold_block
fill 383 272 514 383 273 515 minecraft:gold_block
setblock 379 274 513 minecraft:light[level=14]
setblock 379 274 521 minecraft:light[level=14]
setblock 379 274 529 minecraft:light[level=14]
setblock 379 274 537 minecraft:light[level=14]
setblock 379 274 545 minecraft:light[level=14]
setblock 387 274 513 minecraft:light[level=14]
setblock 387 274 521 minecraft:light[level=14]
setblock 387 274 529 minecraft:light[level=14]
setblock 387 274 537 minecraft:light[level=14]
setblock 387 274 545 minecraft:light[level=14]
setblock 395 274 513 minecraft:light[level=14]
setblock 395 274 521 minecraft:light[level=14]
setblock 395 274 529 minecraft:light[level=14]
setblock 395 274 537 minecraft:light[level=14]
setblock 395 274 545 minecraft:light[level=14]
setblock 403 274 513 minecraft:light[level=14]
setblock 403 274 521 minecraft:light[level=14]
setblock 403 274 529 minecraft:light[level=14]
setblock 403 274 537 minecraft:light[level=14]
setblock 403 274 545 minecraft:light[level=14]
setblock 411 274 513 minecraft:light[level=14]
setblock 411 274 521 minecraft:light[level=14]
setblock 411 274 529 minecraft:light[level=14]
setblock 411 274 537 minecraft:light[level=14]
setblock 411 274 545 minecraft:light[level=14]
fill 377 279 511 377 280 514 minecraft:white_concrete
fill 377 279 515 377 280 529 minecraft:white_wool
fill 377 279 530 377 280 535 minecraft:white_concrete
fill 377 279 536 377 280 550 minecraft:white_wool
fill 377 279 551 379 280 551 minecraft:white_concrete
fill 378 279 511 378 280 512 minecraft:white_concrete
fill 378 279 513 378 280 527 minecraft:white_wool
fill 378 279 528 378 280 533 minecraft:white_concrete
fill 378 279 534 378 280 548 minecraft:white_wool
fill 378 279 549 380 280 550 minecraft:white_concrete
fill 379 279 511 379 280 525 minecraft:white_wool
fill 379 279 526 379 280 531 minecraft:white_concrete
fill 379 279 532 379 280 546 minecraft:white_wool
fill 379 279 547 381 280 548 minecraft:white_concrete
fill 380 279 511 380 280 523 minecraft:white_wool
fill 380 279 524 380 280 529 minecraft:white_concrete
fill 380 279 530 380 280 544 minecraft:white_wool
fill 380 279 545 382 280 546 minecraft:white_concrete
fill 380 279 551 387 280 551 minecraft:white_wool
fill 381 279 511 381 280 521 minecraft:white_wool
fill 381 279 522 381 280 527 minecraft:white_concrete
fill 381 279 528 381 280 542 minecraft:white_wool
fill 381 279 543 383 280 544 minecraft:white_concrete
fill 381 279 549 387 280 550 minecraft:white_wool
fill 382 279 511 382 280 519 minecraft:white_wool
fill 382 279 520 382 280 525 minecraft:white_concrete
fill 382 279 526 382 280 540 minecraft:white_wool
fill 382 279 541 384 280 542 minecraft:white_concrete
fill 382 279 547 388 280 548 minecraft:white_wool
fill 383 279 511 383 280 517 minecraft:white_wool
fill 383 279 518 383 280 523 minecraft:white_concrete
fill 383 279 524 383 280 538 minecraft:white_wool
fill 383 279 539 385 280 540 minecraft:white_concrete
fill 383 279 545 389 280 546 minecraft:white_wool
fill 384 279 511 384 280 515 minecraft:white_wool
fill 384 279 516 384 280 521 minecraft:white_concrete
fill 384 279 522 384 280 536 minecraft:white_wool
fill 384 279 537 386 280 538 minecraft:white_concrete
fill 384 279 543 390 280 544 minecraft:white_wool
fill 385 279 511 385 280 513 minecraft:white_wool
fill 385 279 514 385 280 519 minecraft:white_concrete
fill 385 279 520 385 280 534 minecraft:white_wool
fill 385 279 535 387 280 536 minecraft:white_concrete
fill 385 279 541 391 280 542 minecraft:white_wool
fill 386 279 511 386 280 511 minecraft:white_wool
fill 386 279 512 386 280 517 minecraft:white_concrete
fill 386 279 518 386 280 532 minecraft:white_wool
fill 386 279 533 388 280 534 minecraft:white_concrete
fill 386 279 539 392 280 540 minecraft:white_wool
fill 387 279 511 387 280 515 minecraft:white_concrete
fill 387 279 516 387 280 530 minecraft:white_wool
fill 387 279 531 389 280 532 minecraft:white_concrete
fill 387 279 537 393 280 538 minecraft:white_wool
fill 388 279 511 388 280 513 minecraft:white_concrete
fill 388 279 514 388 280 528 minecraft:white_wool
fill 388 279 529 390 280 530 minecraft:white_concrete
fill 388 279 535 394 280 536 minecraft:white_wool
fill 388 279 549 388 280 549 minecraft:white_wool
fill 388 279 550 390 280 551 minecraft:white_concrete
fill 389 279 511 389 280 511 minecraft:white_concrete
fill 389 279 512 389 280 526 minecraft:white_wool
fill 389 279 527 391 280 528 minecraft:white_concrete
fill 389 279 533 395 280 534 minecraft:white_wool
fill 389 279 547 389 280 547 minecraft:white_wool
fill 389 279 548 391 280 549 minecraft:white_concrete
fill 390 279 511 390 280 524 minecraft:white_wool
fill 390 279 525 392 280 526 minecraft:white_concrete
fill 390 279 531 396 280 532 minecraft:white_wool
fill 390 279 545 390 280 545 minecraft:white_wool
fill 390 279 546 392 280 547 minecraft:white_concrete
fill 391 279 511 391 280 522 minecraft:white_wool
fill 391 279 523 393 280 524 minecraft:white_concrete
fill 391 279 529 396 279 530 minecraft:white_wool
fill 391 279 543 391 280 543 minecraft:white_wool
fill 391 279 544 393 280 545 minecraft:white_concrete
fill 391 279 550 397 280 551 minecraft:white_wool
fill 392 279 511 392 280 520 minecraft:white_wool
fill 392 279 521 394 280 522 minecraft:white_concrete
fill 392 279 527 397 279 528 minecraft:white_wool
fill 392 279 541 392 280 541 minecraft:white_wool
fill 392 279 542 394 280 543 minecraft:white_concrete
fill 392 279 548 398 280 549 minecraft:white_wool
fill 393 279 511 393 280 518 minecraft:white_wool
fill 393 279 519 395 280 520 minecraft:white_concrete
fill 393 279 525 399 279 526 minecraft:white_wool
fill 393 279 539 393 280 539 minecraft:white_wool
fill 393 279 540 395 280 541 minecraft:white_concrete
fill 393 279 546 399 280 547 minecraft:white_wool
fill 394 279 511 394 280 516 minecraft:white_wool
fill 394 279 517 396 280 518 minecraft:white_concrete
fill 394 279 523 400 280 524 minecraft:white_wool
fill 394 279 537 394 280 537 minecraft:white_wool
fill 394 279 538 396 280 539 minecraft:white_concrete
fill 394 279 544 400 280 545 minecraft:white_wool
fill 395 279 511 395 280 514 minecraft:white_wool
fill 395 279 515 397 280 516 minecraft:white_concrete
fill 395 279 521 401 280 522 minecraft:white_wool
fill 395 279 535 395 280 535 minecraft:white_wool
fill 395 279 536 397 280 537 minecraft:white_concrete
fill 395 279 542 401 280 543 minecraft:white_wool
fill 396 279 511 396 280 512 minecraft:white_wool
fill 396 279 513 398 280 514 minecraft:white_concrete
fill 396 279 519 402 280 520 minecraft:white_wool
fill 396 279 533 396 280 533 minecraft:white_wool
fill 396 279 534 398 280 535 minecraft:white_concrete
fill 396 279 540 402 280 541 minecraft:white_wool
fill 397 279 511 399 280 512 minecraft:white_concrete
fill 397 279 517 403 280 518 minecraft:white_wool
fill 397 279 530 397 279 531 minecraft:white_wool
fill 397 279 532 399 279 533 minecraft:white_concrete
fill 397 279 538 403 280 539 minecraft:white_wool
fill 398 279 515 404 280 516 minecraft:white_wool
setblock 398 279 527 minecraft:white_wool
setblock 398 279 531 minecraft:white_concrete
fill 398 279 536 404 280 537 minecraft:white_wool
fill 398 279 550 398 280 550 minecraft:white_wool
fill 398 279 551 400 280 551 minecraft:white_concrete
fill 399 279 513 405 280 514 minecraft:white_wool
fill 399 279 534 405 280 535 minecraft:white_wool
fill 399 279 548 399 280 548 minecraft:white_wool
fill 399 279 549 401 280 550 minecraft:white_concrete
fill 400 279 511 406 280 512 minecraft:white_wool
fill 400 279 525 400 280 525 minecraft:white_wool
fill 400 279 526 402 279 527 minecraft:white_concrete
setblock 400 279 531 minecraft:white_concrete
fill 400 279 532 406 279 533 minecraft:white_wool
fill 400 279 546 400 280 546 minecraft:white_wool
fill 400 279 547 402 280 548 minecraft:white_concrete
fill 401 279 523 401 280 523 minecraft:white_wool
fill 401 279 524 403 280 525 minecraft:white_concrete
setblock 401 279 528 minecraft:white_concrete
fill 401 279 530 407 279 531 minecraft:white_wool
fill 401 279 544 401 280 544 minecraft:white_wool
fill 401 279 545 403 280 546 minecraft:white_concrete
fill 401 279 551 408 280 551 minecraft:white_wool
fill 402 279 521 402 280 521 minecraft:white_wool
fill 402 279 522 404 280 523 minecraft:white_concrete
fill 402 279 528 408 279 529 minecraft:white_wool
fill 402 279 542 402 280 542 minecraft:white_wool
fill 402 279 543 404 280 544 minecraft:white_concrete
fill 402 279 549 408 280 550 minecraft:white_wool
fill 403 279 519 403 280 519 minecraft:white_wool
fill 403 279 520 405 280 521 minecraft:white_concrete
fill 403 279 526 409 280 527 minecraft:white_wool
fill 403 279 540 403 280 540 minecraft:white_wool
fill 403 279 541 405 280 542 minecraft:white_concrete
fill 403 279 547 409 280 548 minecraft:white_wool
fill 404 279 517 404 280 517 minecraft:white_wool
fill 404 279 518 406 280 519 minecraft:white_concrete
fill 404 279 524 410 280 525 minecraft:white_wool
fill 404 279 538 404 280 538 minecraft:white_wool
fill 404 279 539 406 280 540 minecraft:white_concrete
fill 404 279 545 410 280 546 minecraft:white_wool
fill 405 279 515 405 280 515 minecraft:white_wool
fill 405 279 516 407 280 517 minecraft:white_concrete
fill 405 279 522 411 280 523 minecraft:white_wool
fill 405 279 536 405 280 536 minecraft:white_wool
fill 405 279 537 407 280 538 minecraft:white_concrete
fill 405 279 543 411 280 544 minecraft:white_wool
fill 406 279 513 406 280 513 minecraft:white_wool
fill 406 279 514 408 280 515 minecraft:white_concrete
fill 406 279 520 412 280 521 minecraft:white_wool
fill 406 279 534 406 280 534 minecraft:white_wool
fill 406 279 535 408 280 536 minecraft:white_concrete
fill 406 279 541 412 280 542 minecraft:white_wool
fill 407 279 511 407 280 511 minecraft:white_wool
fill 407 279 512 409 280 513 minecraft:white_concrete
fill 407 279 518 413 280 519 minecraft:white_wool
fill 407 279 532 407 280 532 minecraft:white_wool
fill 407 279 533 409 280 534 minecraft:white_concrete
fill 407 279 539 413 280 540 minecraft:white_wool
fill 408 279 511 410 280 511 minecraft:white_concrete
fill 408 279 516 414 280 517 minecraft:white_wool
fill 408 279 530 408 280 530 minecraft:white_wool
fill 408 279 531 410 280 532 minecraft:white_concrete
fill 408 279 537 414 280 538 minecraft:white_wool
fill 409 279 514 415 280 515 minecraft:white_wool
fill 409 279 528 409 280 528 minecraft:white_wool
fill 409 279 529 411 280 530 minecraft:white_concrete
fill 409 279 535 415 280 536 minecraft:white_wool
fill 409 279 549 409 280 549 minecraft:white_wool
fill 409 279 550 411 280 551 minecraft:white_concrete
fill 410 279 512 416 280 513 minecraft:white_wool
fill 410 279 526 410 280 526 minecraft:white_wool
fill 410 279 527 412 280 528 minecraft:white_concrete
fill 410 279 533 416 280 534 minecraft:white_wool
fill 410 279 547 410 280 547 minecraft:white_wool
fill 410 279 548 412 280 549 minecraft:white_concrete
fill 411 279 511 417 280 511 minecraft:white_wool
fill 411 279 524 411 280 524 minecraft:white_wool
fill 411 279 525 413 280 526 minecraft:white_concrete
fill 411 279 531 417 280 532 minecraft:white_wool
fill 411 279 545 411 280 545 minecraft:white_wool
fill 411 279 546 413 280 547 minecraft:white_concrete
fill 412 279 522 412 280 522 minecraft:white_wool
fill 412 279 523 414 280 524 minecraft:white_concrete
fill 412 279 529 417 280 530 minecraft:white_wool
fill 412 279 543 412 280 543 minecraft:white_wool
fill 412 279 544 414 280 545 minecraft:white_concrete
fill 412 279 550 417 280 551 minecraft:white_wool
fill 413 279 520 413 280 520 minecraft:white_wool
fill 413 279 521 415 280 522 minecraft:white_concrete
fill 413 279 527 417 280 528 minecraft:white_wool
fill 413 279 541 413 280 541 minecraft:white_wool
fill 413 279 542 415 280 543 minecraft:white_concrete
fill 413 279 548 417 280 549 minecraft:white_wool
fill 414 279 518 414 280 518 minecraft:white_wool
fill 414 279 519 416 280 520 minecraft:white_concrete
fill 414 279 525 417 280 526 minecraft:white_wool
fill 414 279 539 414 280 539 minecraft:white_wool
fill 414 279 540 416 280 541 minecraft:white_concrete
fill 414 279 546 417 280 547 minecraft:white_wool
fill 415 279 516 415 280 516 minecraft:white_wool
fill 415 279 517 417 280 518 minecraft:white_concrete
fill 415 279 523 417 280 524 minecraft:white_wool
fill 415 279 537 415 280 537 minecraft:white_wool
fill 415 279 538 417 280 539 minecraft:white_concrete
fill 415 279 544 417 280 545 minecraft:white_wool
fill 416 279 514 416 280 514 minecraft:white_wool
fill 416 279 515 417 280 516 minecraft:white_concrete
fill 416 279 521 417 280 522 minecraft:white_wool
fill 416 279 535 416 280 535 minecraft:white_wool
fill 416 279 536 417 280 537 minecraft:white_concrete
fill 416 279 542 417 280 543 minecraft:white_wool
fill 417 279 512 417 280 512 minecraft:white_wool
fill 417 279 513 417 280 514 minecraft:white_concrete
fill 417 279 519 417 280 520 minecraft:white_wool
fill 417 279 533 417 280 533 minecraft:white_wool
fill 417 279 534 417 280 535 minecraft:white_concrete
fill 417 279 540 417 280 541 minecraft:white_wool
fill 391 280 529 395 280 530 minecraft:white_wool
fill 392 280 527 395 280 528 minecraft:white_wool
fill 393 280 525 397 280 526 minecraft:white_wool
setblock 396 280 527 minecraft:white_wool
fill 396 280 528 396 280 530 minecraft:pearlescent_froglight
fill 397 280 527 397 280 528 minecraft:pearlescent_froglight
fill 397 280 530 397 280 531 minecraft:pearlescent_froglight
fill 397 280 532 397 280 533 minecraft:white_concrete
fill 398 280 525 399 280 525 minecraft:white_wool
fill 398 280 526 398 280 527 minecraft:pearlescent_froglight
fill 398 280 531 398 280 532 minecraft:pearlescent_froglight
fill 398 280 533 399 280 533 minecraft:white_concrete
fill 399 280 526 400 280 526 minecraft:pearlescent_froglight
fill 399 280 532 400 280 532 minecraft:pearlescent_froglight
fill 400 280 527 401 280 527 minecraft:pearlescent_froglight
fill 400 280 531 401 280 531 minecraft:pearlescent_froglight
fill 400 280 533 406 280 533 minecraft:white_wool
fill 401 280 526 402 280 526 minecraft:white_concrete
fill 401 280 528 402 280 528 minecraft:pearlescent_froglight
fill 401 280 530 402 280 530 minecraft:pearlescent_froglight
fill 401 280 532 406 280 532 minecraft:white_wool
setblock 402 280 527 minecraft:white_concrete
setblock 402 280 529 minecraft:pearlescent_froglight
fill 402 280 531 407 280 531 minecraft:white_wool
fill 403 280 528 407 280 530 minecraft:white_wool
fill 408 280 528 408 280 529 minecraft:white_wool
setblock 379 282 513 minecraft:light[level=14]
setblock 379 282 521 minecraft:light[level=14]
setblock 379 282 529 minecraft:light[level=14]
setblock 379 282 537 minecraft:light[level=14]
setblock 379 282 545 minecraft:light[level=14]
setblock 387 282 513 minecraft:light[level=14]
setblock 387 282 521 minecraft:light[level=14]
setblock 387 282 529 minecraft:light[level=14]
setblock 387 282 537 minecraft:light[level=14]
setblock 387 282 545 minecraft:light[level=14]
setblock 395 282 513 minecraft:light[level=14]
setblock 395 282 521 minecraft:light[level=14]
setblock 395 282 529 minecraft:light[level=14]
setblock 395 282 537 minecraft:light[level=14]
setblock 395 282 545 minecraft:light[level=14]
setblock 403 282 513 minecraft:light[level=14]
setblock 403 282 521 minecraft:light[level=14]
setblock 403 282 529 minecraft:light[level=14]
setblock 403 282 537 minecraft:light[level=14]
setblock 403 282 545 minecraft:light[level=14]
setblock 411 282 513 minecraft:light[level=14]
setblock 411 282 521 minecraft:light[level=14]
setblock 411 282 529 minecraft:light[level=14]
setblock 411 282 537 minecraft:light[level=14]
setblock 411 282 545 minecraft:light[level=14]
fill 379 284 526 380 284 526 minecraft:white_wool
setblock 380 284 514 minecraft:smooth_quartz
fill 380 284 515 383 300 516 minecraft:quartz_pillar
setblock 380 284 517 minecraft:smooth_quartz
setblock 380 284 525 minecraft:white_wool
setblock 380 284 527 minecraft:white_wool
fill 381 284 514 382 300 514 minecraft:quartz_pillar
fill 381 284 517 382 300 517 minecraft:quartz_pillar
fill 381 284 518 382 284 518 minecraft:smooth_quartz
setblock 383 284 514 minecraft:smooth_quartz
setblock 383 284 517 minecraft:smooth_quartz
fill 384 284 515 384 284 516 minecraft:smooth_quartz
setblock 401 284 515 minecraft:white_wool
setblock 379 290 513 minecraft:light[level=14]
setblock 379 290 521 minecraft:light[level=14]
setblock 379 290 529 minecraft:light[level=14]
setblock 379 290 537 minecraft:light[level=14]
setblock 379 290 545 minecraft:light[level=14]
setblock 387 290 513 minecraft:light[level=14]
setblock 387 290 521 minecraft:light[level=14]
setblock 387 290 529 minecraft:light[level=14]
setblock 387 290 537 minecraft:light[level=14]
setblock 387 290 545 minecraft:light[level=14]
setblock 395 290 513 minecraft:light[level=14]
setblock 395 290 521 minecraft:light[level=14]
setblock 395 290 529 minecraft:light[level=14]
setblock 395 290 537 minecraft:light[level=14]
setblock 395 290 545 minecraft:light[level=14]
setblock 403 290 513 minecraft:light[level=14]
setblock 403 290 521 minecraft:light[level=14]
setblock 403 290 529 minecraft:light[level=14]
setblock 403 290 537 minecraft:light[level=14]
setblock 403 290 545 minecraft:light[level=14]
setblock 411 290 513 minecraft:light[level=14]
setblock 411 290 521 minecraft:light[level=14]
setblock 411 290 529 minecraft:light[level=14]
setblock 411 290 537 minecraft:light[level=14]
setblock 411 290 545 minecraft:light[level=14]
setblock 380 292 514 minecraft:smooth_quartz
setblock 380 292 517 minecraft:smooth_quartz
fill 381 292 518 382 292 518 minecraft:smooth_quartz
setblock 383 292 514 minecraft:smooth_quartz
setblock 383 292 517 minecraft:smooth_quartz
fill 384 292 515 384 292 516 minecraft:smooth_quartz
fill 397 293 548 399 294 548 minecraft:white_wool
fill 398 293 547 398 294 547 minecraft:white_wool
fill 398 293 549 398 294 549 minecraft:white_wool
setblock 379 298 513 minecraft:light[level=14]
setblock 379 298 521 minecraft:light[level=14]
setblock 379 298 529 minecraft:light[level=14]
setblock 379 298 537 minecraft:light[level=14]
setblock 379 298 545 minecraft:light[level=14]
setblock 387 298 513 minecraft:light[level=14]
setblock 387 298 521 minecraft:light[level=14]
setblock 387 298 529 minecraft:light[level=14]
setblock 387 298 537 minecraft:light[level=14]
setblock 387 298 545 minecraft:light[level=14]
setblock 395 298 513 minecraft:light[level=14]
setblock 395 298 521 minecraft:light[level=14]
setblock 395 298 529 minecraft:light[level=14]
setblock 395 298 537 minecraft:light[level=14]
setblock 395 298 545 minecraft:light[level=14]
setblock 403 298 513 minecraft:light[level=14]
setblock 403 298 521 minecraft:light[level=14]
setblock 403 298 529 minecraft:light[level=14]
setblock 403 298 537 minecraft:light[level=14]
setblock 403 298 545 minecraft:light[level=14]
setblock 411 298 513 minecraft:light[level=14]
setblock 411 298 521 minecraft:light[level=14]
setblock 411 298 529 minecraft:light[level=14]
setblock 411 298 537 minecraft:light[level=14]
setblock 411 298 545 minecraft:light[level=14]
fill 380 299 514 380 300 514 minecraft:gold_block
fill 380 299 517 380 300 517 minecraft:gold_block
fill 382 299 518 382 300 518 minecraft:gold_block
fill 383 299 514 383 300 514 minecraft:gold_block
fill 383 299 517 383 300 517 minecraft:gold_block
fill 384 299 516 384 300 516 minecraft:gold_block
