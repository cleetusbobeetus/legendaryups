fill 47 178 641 47 185 641 minecraft:black_concrete
setblock 48 178 621 minecraft:sea_lantern
setblock 48 178 623 minecraft:sea_lantern
setblock 48 178 625 minecraft:sea_lantern
setblock 48 178 627 minecraft:sea_lantern
setblock 48 178 629 minecraft:sea_lantern
setblock 48 178 631 minecraft:sea_lantern
setblock 48 178 633 minecraft:sea_lantern
setblock 49 178 622 minecraft:sea_lantern
setblock 49 178 624 minecraft:sea_lantern
setblock 49 178 626 minecraft:sea_lantern
setblock 49 178 628 minecraft:sea_lantern
setblock 49 178 630 minecraft:sea_lantern
setblock 49 178 632 minecraft:sea_lantern
setblock 50 178 621 minecraft:sea_lantern
setblock 50 178 623 minecraft:sea_lantern
setblock 50 178 625 minecraft:sea_lantern
setblock 50 178 627 minecraft:sea_lantern
setblock 50 178 629 minecraft:sea_lantern
setblock 50 178 631 minecraft:sea_lantern
setblock 50 178 633 minecraft:sea_lantern
fill 50 178 646 50 185 646 minecraft:black_concrete
setblock 51 178 622 minecraft:sea_lantern
setblock 51 178 624 minecraft:sea_lantern
setblock 51 178 626 minecraft:sea_lantern
setblock 51 178 628 minecraft:sea_lantern
setblock 51 178 630 minecraft:sea_lantern
setblock 51 178 632 minecraft:sea_lantern
setblock 52 178 621 minecraft:sea_lantern
setblock 52 178 623 minecraft:sea_lantern
setblock 52 178 625 minecraft:sea_lantern
setblock 52 178 627 minecraft:sea_lantern
setblock 52 178 629 minecraft:sea_lantern
setblock 52 178 631 minecraft:sea_lantern
setblock 52 178 633 minecraft:sea_lantern
setblock 53 178 622 minecraft:sea_lantern
setblock 53 178 624 minecraft:sea_lantern
setblock 53 178 626 minecraft:sea_lantern
setblock 53 178 628 minecraft:sea_lantern
setblock 53 178 630 minecraft:sea_lantern
setblock 53 178 632 minecraft:sea_lantern
fill 54 178 604 54 185 604 minecraft:black_concrete
setblock 54 178 621 minecraft:sea_lantern
setblock 54 178 623 minecraft:sea_lantern
setblock 54 178 625 minecraft:sea_lantern
setblock 54 178 627 minecraft:sea_lantern
setblock 54 178 629 minecraft:sea_lantern
setblock 54 178 631 minecraft:sea_lantern
setblock 54 178 633 minecraft:sea_lantern
fill 58 178 646 58 185 646 minecraft:black_concrete
fill 62 178 604 62 185 604 minecraft:black_concrete
fill 66 178 646 66 185 646 minecraft:black_concrete
fill 70 178 604 70 185 604 minecraft:black_concrete
fill 74 178 646 74 185 646 minecraft:black_concrete
setblock 76 178 605 minecraft:sea_lantern
setblock 76 178 607 minecraft:sea_lantern
setblock 76 178 609 minecraft:sea_lantern
setblock 76 178 611 minecraft:sea_lantern
setblock 77 178 606 minecraft:sea_lantern
setblock 77 178 608 minecraft:sea_lantern
setblock 77 178 610 minecraft:sea_lantern
fill 78 178 604 78 185 604 minecraft:black_concrete
setblock 78 178 605 minecraft:sea_lantern
setblock 78 178 607 minecraft:sea_lantern
setblock 78 178 609 minecraft:sea_lantern
setblock 78 178 611 minecraft:sea_lantern
setblock 79 178 606 minecraft:sea_lantern
setblock 79 178 608 minecraft:sea_lantern
setblock 79 178 610 minecraft:sea_lantern
setblock 80 178 605 minecraft:sea_lantern
setblock 80 178 607 minecraft:sea_lantern
setblock 80 178 609 minecraft:sea_lantern
setblock 80 178 611 minecraft:sea_lantern
setblock 81 178 606 minecraft:sea_lantern
setblock 81 178 608 minecraft:sea_lantern
setblock 81 178 610 minecraft:sea_lantern
setblock 82 178 605 minecraft:sea_lantern
setblock 82 178 607 minecraft:sea_lantern
setblock 82 178 609 minecraft:sea_lantern
setblock 82 178 611 minecraft:sea_lantern
fill 82 178 646 82 185 646 minecraft:black_concrete
setblock 83 178 606 minecraft:sea_lantern
setblock 83 178 608 minecraft:sea_lantern
setblock 83 178 610 minecraft:sea_lantern
setblock 84 178 605 minecraft:sea_lantern
setblock 84 178 607 minecraft:sea_lantern
setblock 84 178 609 minecraft:sea_lantern
setblock 84 178 611 minecraft:sea_lantern
fill 86 178 604 86 185 604 minecraft:black_concrete
fill 89 178 609 89 185 609 minecraft:black_concrete
fill 89 178 617 89 185 617 minecraft:black_concrete
fill 89 178 625 89 185 625 minecraft:black_concrete
fill 89 178 633 89 185 633 minecraft:black_concrete
fill 89 178 641 89 185 641 minecraft:black_concrete
fill 48 179 621 48 180 621 minecraft:light_gray_concrete
fill 48 179 623 48 180 623 minecraft:light_gray_concrete
fill 48 179 625 48 180 625 minecraft:light_gray_concrete
fill 48 179 627 48 180 627 minecraft:light_gray_concrete
fill 48 179 629 48 180 629 minecraft:light_gray_concrete
fill 48 179 631 48 180 631 minecraft:light_gray_concrete
fill 48 179 633 48 180 633 minecraft:light_gray_concrete
fill 49 179 622 49 180 622 minecraft:light_gray_concrete
fill 49 179 624 49 180 624 minecraft:light_gray_concrete
fill 49 179 626 49 180 626 minecraft:light_gray_concrete
fill 49 179 628 49 180 628 minecraft:light_gray_concrete
fill 49 179 630 49 180 630 minecraft:light_gray_concrete
fill 49 179 632 49 180 632 minecraft:light_gray_concrete
fill 50 179 621 50 180 621 minecraft:light_gray_concrete
fill 50 179 623 50 180 623 minecraft:light_gray_concrete
fill 50 179 625 50 180 625 minecraft:light_gray_concrete
fill 50 179 627 50 180 627 minecraft:light_gray_concrete
fill 50 179 629 50 180 629 minecraft:light_gray_concrete
fill 50 179 631 50 180 631 minecraft:light_gray_concrete
fill 50 179 633 50 180 633 minecraft:light_gray_concrete
fill 51 179 622 51 180 622 minecraft:light_gray_concrete
fill 51 179 624 51 180 624 minecraft:light_gray_concrete
fill 51 179 626 51 180 626 minecraft:light_gray_concrete
fill 51 179 628 51 180 628 minecraft:light_gray_concrete
fill 51 179 630 51 180 630 minecraft:light_gray_concrete
fill 51 179 632 51 180 632 minecraft:light_gray_concrete
fill 52 179 621 52 180 621 minecraft:light_gray_concrete
fill 52 179 623 52 180 623 minecraft:light_gray_concrete
fill 52 179 625 52 180 625 minecraft:light_gray_concrete
fill 52 179 627 52 180 627 minecraft:light_gray_concrete
fill 52 179 629 52 180 629 minecraft:light_gray_concrete
fill 52 179 631 52 180 631 minecraft:light_gray_concrete
fill 52 179 633 52 180 633 minecraft:light_gray_concrete
fill 53 179 622 53 180 622 minecraft:light_gray_concrete
fill 53 179 624 53 180 624 minecraft:light_gray_concrete
fill 53 179 626 53 180 626 minecraft:light_gray_concrete
fill 53 179 628 53 180 628 minecraft:light_gray_concrete
fill 53 179 630 53 180 630 minecraft:light_gray_concrete
fill 53 179 632 53 180 632 minecraft:light_gray_concrete
fill 54 179 621 54 180 621 minecraft:light_gray_concrete
fill 54 179 623 54 180 623 minecraft:light_gray_concrete
fill 54 179 625 54 180 625 minecraft:light_gray_concrete
fill 54 179 627 54 180 627 minecraft:light_gray_concrete
fill 54 179 629 54 180 629 minecraft:light_gray_concrete
fill 54 179 631 54 180 631 minecraft:light_gray_concrete
fill 54 179 633 54 180 633 minecraft:light_gray_concrete
fill 76 179 605 76 180 605 minecraft:light_gray_concrete
fill 76 179 607 76 180 607 minecraft:light_gray_concrete
fill 76 179 609 76 180 609 minecraft:light_gray_concrete
fill 76 179 611 76 180 611 minecraft:light_gray_concrete
fill 77 179 606 77 180 606 minecraft:light_gray_concrete
fill 77 179 608 77 180 608 minecraft:light_gray_concrete
fill 77 179 610 77 180 610 minecraft:light_gray_concrete
fill 78 179 605 78 180 605 minecraft:light_gray_concrete
fill 78 179 607 78 180 607 minecraft:light_gray_concrete
fill 78 179 609 78 180 609 minecraft:light_gray_concrete
fill 78 179 611 78 180 611 minecraft:light_gray_concrete
fill 79 179 606 79 180 606 minecraft:light_gray_concrete
fill 79 179 608 79 180 608 minecraft:light_gray_concrete
fill 79 179 610 79 180 610 minecraft:light_gray_concrete
fill 80 179 605 80 180 605 minecraft:light_gray_concrete
fill 80 179 607 80 180 607 minecraft:light_gray_concrete
fill 80 179 609 80 180 609 minecraft:light_gray_concrete
fill 80 179 611 80 180 611 minecraft:light_gray_concrete
fill 81 179 606 81 180 606 minecraft:light_gray_concrete
fill 81 179 608 81 180 608 minecraft:light_gray_concrete
fill 81 179 610 81 180 610 minecraft:light_gray_concrete
fill 82 179 605 82 180 605 minecraft:light_gray_concrete
fill 82 179 607 82 180 607 minecraft:light_gray_concrete
fill 82 179 609 82 180 609 minecraft:light_gray_concrete
fill 82 179 611 82 180 611 minecraft:light_gray_concrete
fill 83 179 606 83 180 606 minecraft:light_gray_concrete
fill 83 179 608 83 180 608 minecraft:light_gray_concrete
fill 83 179 610 83 180 610 minecraft:light_gray_concrete
fill 84 179 605 84 180 605 minecraft:light_gray_concrete
fill 84 179 607 84 180 607 minecraft:light_gray_concrete
fill 84 179 609 84 180 609 minecraft:light_gray_concrete
fill 84 179 611 84 180 611 minecraft:light_gray_concrete
setblock 48 181 621 minecraft:sea_lantern
setblock 48 181 623 minecraft:sea_lantern
setblock 48 181 625 minecraft:sea_lantern
setblock 48 181 627 minecraft:sea_lantern
setblock 48 181 629 minecraft:sea_lantern
setblock 48 181 631 minecraft:sea_lantern
setblock 48 181 633 minecraft:sea_lantern
setblock 49 181 622 minecraft:sea_lantern
setblock 49 181 624 minecraft:sea_lantern
setblock 49 181 626 minecraft:sea_lantern
setblock 49 181 628 minecraft:sea_lantern
setblock 49 181 630 minecraft:sea_lantern
setblock 49 181 632 minecraft:sea_lantern
setblock 50 181 621 minecraft:sea_lantern
setblock 50 181 623 minecraft:sea_lantern
setblock 50 181 625 minecraft:sea_lantern
setblock 50 181 627 minecraft:sea_lantern
setblock 50 181 629 minecraft:sea_lantern
setblock 50 181 631 minecraft:sea_lantern
setblock 50 181 633 minecraft:sea_lantern
setblock 51 181 622 minecraft:sea_lantern
setblock 51 181 624 minecraft:sea_lantern
setblock 51 181 626 minecraft:sea_lantern
setblock 51 181 628 minecraft:sea_lantern
setblock 51 181 630 minecraft:sea_lantern
setblock 51 181 632 minecraft:sea_lantern
setblock 52 181 621 minecraft:sea_lantern
setblock 52 181 623 minecraft:sea_lantern
setblock 52 181 625 minecraft:sea_lantern
setblock 52 181 627 minecraft:sea_lantern
setblock 52 181 629 minecraft:sea_lantern
setblock 52 181 631 minecraft:sea_lantern
setblock 52 181 633 minecraft:sea_lantern
setblock 53 181 622 minecraft:sea_lantern
setblock 53 181 624 minecraft:sea_lantern
setblock 53 181 626 minecraft:sea_lantern
setblock 53 181 628 minecraft:sea_lantern
setblock 53 181 630 minecraft:sea_lantern
setblock 53 181 632 minecraft:sea_lantern
setblock 54 181 621 minecraft:sea_lantern
setblock 54 181 623 minecraft:sea_lantern
setblock 54 181 625 minecraft:sea_lantern
setblock 54 181 627 minecraft:sea_lantern
setblock 54 181 629 minecraft:sea_lantern
setblock 54 181 631 minecraft:sea_lantern
setblock 54 181 633 minecraft:sea_lantern
setblock 76 181 605 minecraft:sea_lantern
setblock 76 181 607 minecraft:sea_lantern
setblock 76 181 609 minecraft:sea_lantern
setblock 76 181 611 minecraft:sea_lantern
setblock 77 181 606 minecraft:sea_lantern
setblock 77 181 608 minecraft:sea_lantern
setblock 77 181 610 minecraft:sea_lantern
setblock 78 181 605 minecraft:sea_lantern
setblock 78 181 607 minecraft:sea_lantern
setblock 78 181 609 minecraft:sea_lantern
setblock 78 181 611 minecraft:sea_lantern
setblock 79 181 606 minecraft:sea_lantern
setblock 79 181 608 minecraft:sea_lantern
setblock 79 181 610 minecraft:sea_lantern
setblock 80 181 605 minecraft:sea_lantern
setblock 80 181 607 minecraft:sea_lantern
setblock 80 181 609 minecraft:sea_lantern
setblock 80 181 611 minecraft:sea_lantern
setblock 81 181 606 minecraft:sea_lantern
setblock 81 181 608 minecraft:sea_lantern
setblock 81 181 610 minecraft:sea_lantern
setblock 82 181 605 minecraft:sea_lantern
setblock 82 181 607 minecraft:sea_lantern
setblock 82 181 609 minecraft:sea_lantern
setblock 82 181 611 minecraft:sea_lantern
setblock 83 181 606 minecraft:sea_lantern
setblock 83 181 608 minecraft:sea_lantern
setblock 83 181 610 minecraft:sea_lantern
setblock 84 181 605 minecraft:sea_lantern
setblock 84 181 607 minecraft:sea_lantern
setblock 84 181 609 minecraft:sea_lantern
setblock 84 181 611 minecraft:sea_lantern
fill 48 182 605 48 183 610 minecraft:light_gray_concrete
fill 48 182 613 49 182 618 minecraft:light_gray_concrete
fill 48 182 621 48 183 621 minecraft:light_gray_concrete
fill 48 182 623 48 183 623 minecraft:light_gray_concrete
fill 48 182 625 48 183 625 minecraft:light_gray_concrete
fill 48 182 627 48 183 627 minecraft:light_gray_concrete
fill 48 182 629 48 183 629 minecraft:light_gray_concrete
fill 48 182 631 48 183 631 minecraft:light_gray_concrete
fill 48 182 633 48 183 634 minecraft:light_gray_concrete
fill 48 182 637 49 182 642 minecraft:light_gray_concrete
fill 48 182 645 53 183 645 minecraft:light_gray_concrete
fill 49 182 606 49 182 612 minecraft:light_gray_concrete
fill 49 182 619 49 182 620 minecraft:light_gray_concrete
fill 49 182 622 49 183 622 minecraft:light_gray_concrete
fill 49 182 624 49 183 624 minecraft:light_gray_concrete
fill 49 182 626 49 183 626 minecraft:light_gray_concrete
fill 49 182 628 49 183 628 minecraft:light_gray_concrete
fill 49 182 630 49 183 630 minecraft:light_gray_concrete
fill 49 182 632 49 183 632 minecraft:light_gray_concrete
fill 49 182 634 49 182 636 minecraft:light_gray_concrete
fill 49 182 643 49 182 644 minecraft:light_gray_concrete
fill 50 182 606 75 182 606 minecraft:light_gray_concrete
fill 50 182 621 50 183 621 minecraft:light_gray_concrete
fill 50 182 623 50 183 623 minecraft:light_gray_concrete
fill 50 182 625 50 183 625 minecraft:light_gray_concrete
fill 50 182 627 50 183 627 minecraft:light_gray_concrete
fill 50 182 629 50 183 629 minecraft:light_gray_concrete
fill 50 182 631 50 183 631 minecraft:light_gray_concrete
fill 50 182 633 50 183 633 minecraft:light_gray_concrete
fill 50 182 644 88 182 644 minecraft:light_gray_concrete
fill 51 182 605 56 183 605 minecraft:light_gray_concrete
fill 51 182 622 51 183 622 minecraft:light_gray_concrete
fill 51 182 624 51 183 624 minecraft:light_gray_concrete
fill 51 182 626 51 183 626 minecraft:light_gray_concrete
fill 51 182 628 51 183 628 minecraft:light_gray_concrete
fill 51 182 630 51 183 630 minecraft:light_gray_concrete
fill 51 182 632 51 183 632 minecraft:light_gray_concrete
fill 52 182 621 52 183 621 minecraft:light_gray_concrete
fill 52 182 623 52 183 623 minecraft:light_gray_concrete
fill 52 182 625 52 183 625 minecraft:light_gray_concrete
fill 52 182 627 52 183 627 minecraft:light_gray_concrete
fill 52 182 629 52 183 629 minecraft:light_gray_concrete
fill 52 182 631 52 183 631 minecraft:light_gray_concrete
fill 52 182 633 52 183 633 minecraft:light_gray_concrete
fill 53 182 622 53 183 622 minecraft:light_gray_concrete
fill 53 182 624 53 183 624 minecraft:light_gray_concrete
fill 53 182 626 53 183 626 minecraft:light_gray_concrete
fill 53 182 628 53 183 628 minecraft:light_gray_concrete
fill 53 182 630 53 183 630 minecraft:light_gray_concrete
fill 53 182 632 53 183 632 minecraft:light_gray_concrete
fill 54 182 621 54 183 621 minecraft:light_gray_concrete
fill 54 182 623 54 183 623 minecraft:light_gray_concrete
fill 54 182 625 54 183 625 minecraft:light_gray_concrete
fill 54 182 627 54 183 627 minecraft:light_gray_concrete
fill 54 182 629 54 183 629 minecraft:light_gray_concrete
fill 54 182 631 54 183 631 minecraft:light_gray_concrete
fill 54 182 633 54 183 633 minecraft:light_gray_concrete
fill 56 182 645 61 183 645 minecraft:light_gray_concrete
fill 57 182 637 58 183 637 minecraft:glass
fill 58 182 636 58 183 636 minecraft:glass
fill 58 182 638 58 183 638 minecraft:glass
fill 59 182 605 64 183 605 minecraft:light_gray_concrete
fill 64 182 645 69 183 645 minecraft:light_gray_concrete
fill 67 182 605 72 183 605 minecraft:light_gray_concrete
fill 72 182 645 77 183 645 minecraft:light_gray_concrete
fill 75 182 605 76 183 605 minecraft:light_gray_concrete
fill 76 182 607 76 183 607 minecraft:light_gray_concrete
fill 76 182 609 76 183 609 minecraft:light_gray_concrete
fill 76 182 611 76 183 611 minecraft:light_gray_concrete
fill 77 182 606 77 183 606 minecraft:light_gray_concrete
fill 77 182 608 77 183 608 minecraft:light_gray_concrete
fill 77 182 610 77 183 610 minecraft:light_gray_concrete
fill 78 182 605 78 183 605 minecraft:light_gray_concrete
fill 78 182 607 78 183 607 minecraft:light_gray_concrete
fill 78 182 609 78 183 609 minecraft:light_gray_concrete
fill 78 182 611 78 183 611 minecraft:light_gray_concrete
fill 79 182 606 79 183 606 minecraft:light_gray_concrete
fill 79 182 608 79 183 608 minecraft:light_gray_concrete
fill 79 182 610 79 183 610 minecraft:light_gray_concrete
fill 80 182 605 80 183 605 minecraft:light_gray_concrete
fill 80 182 607 80 183 607 minecraft:light_gray_concrete
fill 80 182 609 80 183 609 minecraft:light_gray_concrete
fill 80 182 611 80 183 611 minecraft:light_gray_concrete
fill 80 182 645 85 183 645 minecraft:light_gray_concrete
fill 81 182 606 81 183 606 minecraft:light_gray_concrete
fill 81 182 608 81 183 608 minecraft:light_gray_concrete
fill 81 182 610 81 183 610 minecraft:light_gray_concrete
fill 82 182 605 82 183 605 minecraft:light_gray_concrete
fill 82 182 607 82 183 607 minecraft:light_gray_concrete
fill 82 182 609 82 183 609 minecraft:light_gray_concrete
fill 82 182 611 82 183 611 minecraft:light_gray_concrete
fill 83 182 606 83 183 606 minecraft:light_gray_concrete
fill 83 182 608 83 183 608 minecraft:light_gray_concrete
fill 83 182 610 83 183 610 minecraft:light_gray_concrete
fill 84 182 605 88 183 605 minecraft:light_gray_concrete
fill 84 182 607 84 183 607 minecraft:light_gray_concrete
fill 84 182 609 84 183 609 minecraft:light_gray_concrete
fill 84 182 611 84 183 611 minecraft:light_gray_concrete
fill 85 182 606 87 182 606 minecraft:light_gray_concrete
fill 87 182 607 87 182 643 minecraft:light_gray_concrete
fill 88 182 608 88 183 613 minecraft:light_gray_concrete
fill 88 182 616 88 183 621 minecraft:light_gray_concrete
fill 88 182 624 88 183 629 minecraft:light_gray_concrete
fill 88 182 632 88 183 637 minecraft:light_gray_concrete
fill 88 182 640 88 183 643 minecraft:light_gray_concrete
fill 88 182 645 88 183 645 minecraft:light_gray_concrete
fill 48 183 613 48 183 618 minecraft:light_gray_concrete
fill 48 183 637 48 183 642 minecraft:light_gray_concrete
setblock 88 183 644 minecraft:light_gray_concrete
setblock 48 184 621 minecraft:sea_lantern
setblock 48 184 623 minecraft:sea_lantern
setblock 48 184 625 minecraft:sea_lantern
setblock 48 184 627 minecraft:sea_lantern
setblock 48 184 629 minecraft:sea_lantern
setblock 48 184 631 minecraft:sea_lantern
setblock 48 184 633 minecraft:sea_lantern
setblock 49 184 622 minecraft:sea_lantern
setblock 49 184 624 minecraft:sea_lantern
setblock 49 184 626 minecraft:sea_lantern
setblock 49 184 628 minecraft:sea_lantern
setblock 49 184 630 minecraft:sea_lantern
setblock 49 184 632 minecraft:sea_lantern
setblock 50 184 607 minecraft:light[level=14]
setblock 50 184 615 minecraft:light[level=14]
setblock 50 184 621 minecraft:sea_lantern
setblock 50 184 623 minecraft:sea_lantern
setblock 50 184 625 minecraft:sea_lantern
setblock 50 184 627 minecraft:sea_lantern
setblock 50 184 629 minecraft:sea_lantern
setblock 50 184 631 minecraft:sea_lantern
setblock 50 184 633 minecraft:sea_lantern
setblock 50 184 639 minecraft:light[level=14]
setblock 51 184 622 minecraft:sea_lantern
setblock 51 184 624 minecraft:sea_lantern
setblock 51 184 626 minecraft:sea_lantern
setblock 51 184 628 minecraft:sea_lantern
setblock 51 184 630 minecraft:sea_lantern
setblock 51 184 632 minecraft:sea_lantern
setblock 52 184 621 minecraft:sea_lantern
setblock 52 184 623 minecraft:sea_lantern
setblock 52 184 625 minecraft:sea_lantern
setblock 52 184 627 minecraft:sea_lantern
setblock 52 184 629 minecraft:sea_lantern
setblock 52 184 631 minecraft:sea_lantern
setblock 52 184 633 minecraft:sea_lantern
setblock 53 184 622 minecraft:sea_lantern
setblock 53 184 624 minecraft:sea_lantern
setblock 53 184 626 minecraft:sea_lantern
setblock 53 184 628 minecraft:sea_lantern
setblock 53 184 630 minecraft:sea_lantern
setblock 53 184 632 minecraft:sea_lantern
setblock 54 184 621 minecraft:sea_lantern
setblock 54 184 623 minecraft:sea_lantern
setblock 54 184 625 minecraft:sea_lantern
setblock 54 184 627 minecraft:sea_lantern
setblock 54 184 629 minecraft:sea_lantern
setblock 54 184 631 minecraft:sea_lantern
setblock 54 184 633 minecraft:sea_lantern
setblock 58 184 607 minecraft:light[level=14]
setblock 58 184 615 minecraft:light[level=14]
setblock 58 184 623 minecraft:light[level=14]
setblock 58 184 631 minecraft:light[level=14]
setblock 58 184 639 minecraft:light[level=14]
setblock 66 184 607 minecraft:light[level=14]
setblock 66 184 615 minecraft:light[level=14]
setblock 66 184 623 minecraft:light[level=14]
setblock 66 184 631 minecraft:light[level=14]
setblock 66 184 639 minecraft:light[level=14]
setblock 74 184 607 minecraft:light[level=14]
setblock 74 184 615 minecraft:light[level=14]
setblock 74 184 623 minecraft:light[level=14]
setblock 74 184 631 minecraft:light[level=14]
setblock 74 184 639 minecraft:light[level=14]
setblock 76 184 605 minecraft:sea_lantern
setblock 76 184 607 minecraft:sea_lantern
setblock 76 184 609 minecraft:sea_lantern
setblock 76 184 611 minecraft:sea_lantern
setblock 77 184 606 minecraft:sea_lantern
setblock 77 184 608 minecraft:sea_lantern
setblock 77 184 610 minecraft:sea_lantern
setblock 78 184 605 minecraft:sea_lantern
setblock 78 184 607 minecraft:sea_lantern
setblock 78 184 609 minecraft:sea_lantern
setblock 78 184 611 minecraft:sea_lantern
setblock 79 184 606 minecraft:sea_lantern
setblock 79 184 608 minecraft:sea_lantern
setblock 79 184 610 minecraft:sea_lantern
setblock 80 184 605 minecraft:sea_lantern
setblock 80 184 607 minecraft:sea_lantern
setblock 80 184 609 minecraft:sea_lantern
setblock 80 184 611 minecraft:sea_lantern
setblock 81 184 606 minecraft:sea_lantern
setblock 81 184 608 minecraft:sea_lantern
setblock 81 184 610 minecraft:sea_lantern
setblock 82 184 605 minecraft:sea_lantern
setblock 82 184 607 minecraft:sea_lantern
setblock 82 184 609 minecraft:sea_lantern
setblock 82 184 611 minecraft:sea_lantern
setblock 82 184 615 minecraft:light[level=14]
setblock 82 184 623 minecraft:light[level=14]
setblock 82 184 631 minecraft:light[level=14]
setblock 82 184 639 minecraft:light[level=14]
setblock 83 184 606 minecraft:sea_lantern
setblock 83 184 608 minecraft:sea_lantern
setblock 83 184 610 minecraft:sea_lantern
setblock 84 184 605 minecraft:sea_lantern
setblock 84 184 607 minecraft:sea_lantern
setblock 84 184 609 minecraft:sea_lantern
setblock 84 184 611 minecraft:sea_lantern
fill 48 185 621 48 186 621 minecraft:light_gray_concrete
fill 48 185 623 48 186 623 minecraft:light_gray_concrete
fill 48 185 625 48 186 625 minecraft:light_gray_concrete
fill 48 185 627 48 186 627 minecraft:light_gray_concrete
fill 48 185 629 48 186 629 minecraft:light_gray_concrete
fill 48 185 631 48 186 631 minecraft:light_gray_concrete
fill 48 185 633 48 186 633 minecraft:light_gray_concrete
fill 49 185 622 49 186 622 minecraft:light_gray_concrete
fill 49 185 624 49 186 624 minecraft:light_gray_concrete
fill 49 185 626 49 186 626 minecraft:light_gray_concrete
fill 49 185 628 49 186 628 minecraft:light_gray_concrete
fill 49 185 630 49 186 630 minecraft:light_gray_concrete
fill 49 185 632 49 186 632 minecraft:light_gray_concrete
fill 50 185 621 50 186 621 minecraft:light_gray_concrete
fill 50 185 623 50 186 623 minecraft:light_gray_concrete
fill 50 185 625 50 186 625 minecraft:light_gray_concrete
fill 50 185 627 50 186 627 minecraft:light_gray_concrete
fill 50 185 629 50 186 629 minecraft:light_gray_concrete
fill 50 185 631 50 186 631 minecraft:light_gray_concrete
fill 50 185 633 50 186 633 minecraft:light_gray_concrete
fill 51 185 622 51 186 622 minecraft:light_gray_concrete
fill 51 185 624 51 186 624 minecraft:light_gray_concrete
fill 51 185 626 51 186 626 minecraft:light_gray_concrete
fill 51 185 628 51 186 628 minecraft:light_gray_concrete
fill 51 185 630 51 186 630 minecraft:light_gray_concrete
fill 51 185 632 51 186 632 minecraft:light_gray_concrete
fill 52 185 621 52 186 621 minecraft:light_gray_concrete
fill 52 185 623 52 186 623 minecraft:light_gray_concrete
fill 52 185 625 52 186 625 minecraft:light_gray_concrete
fill 52 185 627 52 186 627 minecraft:light_gray_concrete
fill 52 185 629 52 186 629 minecraft:light_gray_concrete
fill 52 185 631 52 186 631 minecraft:light_gray_concrete
fill 52 185 633 52 186 633 minecraft:light_gray_concrete
fill 53 185 622 53 186 622 minecraft:light_gray_concrete
fill 53 185 624 53 186 624 minecraft:light_gray_concrete
fill 53 185 626 53 186 626 minecraft:light_gray_concrete
fill 53 185 628 53 186 628 minecraft:light_gray_concrete
fill 53 185 630 53 186 630 minecraft:light_gray_concrete
fill 53 185 632 53 186 632 minecraft:light_gray_concrete
fill 54 185 621 54 186 621 minecraft:light_gray_concrete
fill 54 185 623 54 186 623 minecraft:light_gray_concrete
fill 54 185 625 54 186 625 minecraft:light_gray_concrete
fill 54 185 627 54 186 627 minecraft:light_gray_concrete
fill 54 185 629 54 186 629 minecraft:light_gray_concrete
fill 54 185 631 54 186 631 minecraft:light_gray_concrete
fill 54 185 633 54 186 633 minecraft:light_gray_concrete
fill 76 185 605 76 186 605 minecraft:light_gray_concrete
fill 76 185 607 76 186 607 minecraft:light_gray_concrete
fill 76 185 609 76 186 609 minecraft:light_gray_concrete
fill 76 185 611 76 186 611 minecraft:light_gray_concrete
fill 77 185 606 77 186 606 minecraft:light_gray_concrete
fill 77 185 608 77 186 608 minecraft:light_gray_concrete
fill 77 185 610 77 186 610 minecraft:light_gray_concrete
fill 78 185 605 78 186 605 minecraft:light_gray_concrete
fill 78 185 607 78 186 607 minecraft:light_gray_concrete
fill 78 185 609 78 186 609 minecraft:light_gray_concrete
fill 78 185 611 78 186 611 minecraft:light_gray_concrete
fill 79 185 606 79 186 606 minecraft:light_gray_concrete
fill 79 185 608 79 186 608 minecraft:light_gray_concrete
fill 79 185 610 79 186 610 minecraft:light_gray_concrete
fill 80 185 605 80 186 605 minecraft:light_gray_concrete
fill 80 185 607 80 186 607 minecraft:light_gray_concrete
fill 80 185 609 80 186 609 minecraft:light_gray_concrete
fill 80 185 611 80 186 611 minecraft:light_gray_concrete
fill 80 185 620 80 186 620 minecraft:magenta_concrete
fill 81 185 606 81 186 606 minecraft:light_gray_concrete
fill 81 185 608 81 186 608 minecraft:light_gray_concrete
fill 81 185 610 81 186 610 minecraft:light_gray_concrete
fill 82 185 605 82 186 605 minecraft:light_gray_concrete
fill 82 185 607 82 186 607 minecraft:light_gray_concrete
fill 82 185 609 82 186 609 minecraft:light_gray_concrete
fill 82 185 611 82 186 611 minecraft:light_gray_concrete
fill 83 185 606 83 186 606 minecraft:light_gray_concrete
fill 83 185 608 83 186 608 minecraft:light_gray_concrete
fill 83 185 610 83 186 610 minecraft:light_gray_concrete
fill 84 185 605 84 186 605 minecraft:light_gray_concrete
fill 84 185 607 84 186 607 minecraft:light_gray_concrete
fill 84 185 609 84 186 609 minecraft:light_gray_concrete
fill 84 185 611 84 186 611 minecraft:light_gray_concrete
fill 47 186 609 47 191 609 minecraft:sea_lantern
fill 47 186 617 47 191 617 minecraft:sea_lantern
fill 47 186 625 47 191 625 minecraft:sea_lantern
fill 47 186 633 47 191 633 minecraft:sea_lantern
fill 47 186 641 47 191 641 minecraft:sea_lantern
fill 50 186 646 50 191 646 minecraft:sea_lantern
fill 54 186 604 54 191 604 minecraft:sea_lantern
fill 58 186 646 58 191 646 minecraft:sea_lantern
fill 62 186 604 62 191 604 minecraft:sea_lantern
fill 66 186 646 66 191 646 minecraft:sea_lantern
fill 70 186 604 70 191 604 minecraft:sea_lantern
fill 74 186 646 74 191 646 minecraft:sea_lantern
fill 78 186 604 78 191 604 minecraft:sea_lantern
fill 82 186 646 82 191 646 minecraft:sea_lantern
fill 86 186 604 86 191 604 minecraft:sea_lantern
fill 89 186 609 89 191 609 minecraft:sea_lantern
fill 89 186 617 89 191 617 minecraft:sea_lantern
fill 89 186 625 89 191 625 minecraft:sea_lantern
fill 89 186 633 89 191 633 minecraft:sea_lantern
fill 89 186 641 89 191 641 minecraft:sea_lantern
setblock 48 187 621 minecraft:sea_lantern
setblock 48 187 623 minecraft:sea_lantern
setblock 48 187 625 minecraft:sea_lantern
setblock 48 187 627 minecraft:sea_lantern
setblock 48 187 629 minecraft:sea_lantern
setblock 48 187 631 minecraft:sea_lantern
setblock 48 187 633 minecraft:sea_lantern
setblock 49 187 622 minecraft:sea_lantern
setblock 49 187 624 minecraft:sea_lantern
setblock 49 187 626 minecraft:sea_lantern
setblock 49 187 628 minecraft:sea_lantern
setblock 49 187 630 minecraft:sea_lantern
setblock 49 187 632 minecraft:sea_lantern
setblock 50 187 621 minecraft:sea_lantern
setblock 50 187 623 minecraft:sea_lantern
setblock 50 187 625 minecraft:sea_lantern
setblock 50 187 627 minecraft:sea_lantern
setblock 50 187 629 minecraft:sea_lantern
setblock 50 187 631 minecraft:sea_lantern
setblock 50 187 633 minecraft:sea_lantern
setblock 51 187 622 minecraft:sea_lantern
setblock 51 187 624 minecraft:sea_lantern
setblock 51 187 626 minecraft:sea_lantern
setblock 51 187 628 minecraft:sea_lantern
setblock 51 187 630 minecraft:sea_lantern
setblock 51 187 632 minecraft:sea_lantern
setblock 52 187 621 minecraft:sea_lantern
setblock 52 187 623 minecraft:sea_lantern
setblock 52 187 625 minecraft:sea_lantern
setblock 52 187 627 minecraft:sea_lantern
setblock 52 187 629 minecraft:sea_lantern
setblock 52 187 631 minecraft:sea_lantern
setblock 52 187 633 minecraft:sea_lantern
setblock 53 187 622 minecraft:sea_lantern
setblock 53 187 624 minecraft:sea_lantern
setblock 53 187 626 minecraft:sea_lantern
setblock 53 187 628 minecraft:sea_lantern
setblock 53 187 630 minecraft:sea_lantern
setblock 53 187 632 minecraft:sea_lantern
setblock 54 187 621 minecraft:sea_lantern
setblock 54 187 623 minecraft:sea_lantern
setblock 54 187 625 minecraft:sea_lantern
setblock 54 187 627 minecraft:sea_lantern
setblock 54 187 629 minecraft:sea_lantern
setblock 54 187 631 minecraft:sea_lantern
setblock 54 187 633 minecraft:sea_lantern
setblock 76 187 605 minecraft:sea_lantern
setblock 76 187 607 minecraft:sea_lantern
setblock 76 187 609 minecraft:sea_lantern
setblock 76 187 611 minecraft:sea_lantern
setblock 77 187 606 minecraft:sea_lantern
setblock 77 187 608 minecraft:sea_lantern
setblock 77 187 610 minecraft:sea_lantern
setblock 78 187 605 minecraft:sea_lantern
setblock 78 187 607 minecraft:sea_lantern
setblock 78 187 609 minecraft:sea_lantern
setblock 78 187 611 minecraft:sea_lantern
setblock 79 187 606 minecraft:sea_lantern
setblock 79 187 608 minecraft:sea_lantern
setblock 79 187 610 minecraft:sea_lantern
setblock 80 187 605 minecraft:sea_lantern
setblock 80 187 607 minecraft:sea_lantern
setblock 80 187 609 minecraft:sea_lantern
setblock 80 187 611 minecraft:sea_lantern
setblock 81 187 606 minecraft:sea_lantern
setblock 81 187 608 minecraft:sea_lantern
setblock 81 187 610 minecraft:sea_lantern
setblock 82 187 605 minecraft:sea_lantern
setblock 82 187 607 minecraft:sea_lantern
setblock 82 187 609 minecraft:sea_lantern
setblock 82 187 611 minecraft:sea_lantern
setblock 83 187 606 minecraft:sea_lantern
setblock 83 187 608 minecraft:sea_lantern
setblock 83 187 610 minecraft:sea_lantern
setblock 84 187 605 minecraft:sea_lantern
setblock 84 187 607 minecraft:sea_lantern
setblock 84 187 609 minecraft:sea_lantern
setblock 84 187 611 minecraft:sea_lantern
fill 48 188 621 48 189 621 minecraft:light_gray_concrete
fill 48 188 623 48 189 623 minecraft:light_gray_concrete
fill 48 188 625 48 189 625 minecraft:light_gray_concrete
fill 48 188 627 48 225 627 minecraft:light_gray_concrete
fill 48 188 629 48 189 629 minecraft:light_gray_concrete
fill 48 188 631 48 189 631 minecraft:light_gray_concrete
fill 48 188 633 48 189 633 minecraft:light_gray_concrete
fill 49 188 622 49 189 622 minecraft:light_gray_concrete
fill 49 188 624 49 189 624 minecraft:light_gray_concrete
fill 49 188 626 49 189 626 minecraft:light_gray_concrete
fill 49 188 628 49 189 628 minecraft:light_gray_concrete
fill 49 188 630 49 189 630 minecraft:light_gray_concrete
fill 49 188 632 49 189 632 minecraft:light_gray_concrete
fill 50 188 621 50 189 621 minecraft:light_gray_concrete
fill 50 188 623 50 189 623 minecraft:light_gray_concrete
fill 50 188 625 50 189 625 minecraft:light_gray_concrete
fill 50 188 627 50 189 627 minecraft:light_gray_concrete
fill 50 188 629 50 189 629 minecraft:light_gray_concrete
fill 50 188 631 50 189 631 minecraft:light_gray_concrete
fill 50 188 633 50 189 633 minecraft:light_gray_concrete
fill 51 188 622 51 189 622 minecraft:light_gray_concrete
fill 51 188 624 51 189 624 minecraft:light_gray_concrete
fill 51 188 626 51 189 626 minecraft:light_gray_concrete
fill 51 188 628 51 189 628 minecraft:light_gray_concrete
fill 51 188 630 51 189 630 minecraft:light_gray_concrete
fill 51 188 632 51 189 632 minecraft:light_gray_concrete
fill 52 188 621 52 189 621 minecraft:light_gray_concrete
fill 52 188 623 52 189 623 minecraft:light_gray_concrete
fill 52 188 625 52 189 625 minecraft:light_gray_concrete
fill 52 188 627 52 189 627 minecraft:light_gray_concrete
fill 52 188 629 52 189 629 minecraft:light_gray_concrete
fill 52 188 631 52 189 631 minecraft:light_gray_concrete
fill 52 188 633 52 189 633 minecraft:light_gray_concrete
fill 53 188 622 53 189 622 minecraft:light_gray_concrete
fill 53 188 624 53 189 624 minecraft:light_gray_concrete
fill 53 188 626 53 189 626 minecraft:light_gray_concrete
fill 53 188 628 53 189 628 minecraft:light_gray_concrete
fill 53 188 630 53 189 630 minecraft:light_gray_concrete
fill 53 188 632 53 189 632 minecraft:light_gray_concrete
fill 54 188 621 54 189 621 minecraft:light_gray_concrete
fill 54 188 623 54 189 623 minecraft:light_gray_concrete
fill 54 188 625 54 189 625 minecraft:light_gray_concrete
fill 54 188 627 54 189 627 minecraft:light_gray_concrete
fill 54 188 629 54 189 629 minecraft:light_gray_concrete
fill 54 188 631 54 189 631 minecraft:light_gray_concrete
fill 54 188 633 54 189 633 minecraft:light_gray_concrete
fill 76 188 605 76 189 605 minecraft:light_gray_concrete
fill 76 188 607 76 189 607 minecraft:light_gray_concrete
fill 76 188 609 76 189 609 minecraft:light_gray_concrete
fill 76 188 611 76 189 611 minecraft:light_gray_concrete
fill 77 188 606 77 189 606 minecraft:light_gray_concrete
fill 77 188 608 77 189 608 minecraft:light_gray_concrete
fill 77 188 610 77 189 610 minecraft:light_gray_concrete
fill 78 188 605 78 189 605 minecraft:light_gray_concrete
fill 78 188 607 78 189 607 minecraft:light_gray_concrete
fill 78 188 609 78 189 609 minecraft:light_gray_concrete
fill 78 188 611 78 189 611 minecraft:light_gray_concrete
fill 79 188 606 79 189 606 minecraft:light_gray_concrete
fill 79 188 608 79 189 608 minecraft:light_gray_concrete
fill 79 188 610 79 189 610 minecraft:light_gray_concrete
fill 80 188 605 80 189 605 minecraft:light_gray_concrete
fill 80 188 607 80 189 607 minecraft:light_gray_concrete
fill 80 188 609 80 189 609 minecraft:light_gray_concrete
fill 80 188 611 80 189 611 minecraft:light_gray_concrete
fill 81 188 606 81 189 606 minecraft:light_gray_concrete
fill 81 188 608 81 189 608 minecraft:light_gray_concrete
fill 81 188 610 81 189 610 minecraft:light_gray_concrete
fill 82 188 605 82 189 605 minecraft:light_gray_concrete
fill 82 188 607 82 189 607 minecraft:light_gray_concrete
fill 82 188 609 82 189 609 minecraft:light_gray_concrete
fill 82 188 611 82 189 611 minecraft:light_gray_concrete
fill 83 188 606 83 189 606 minecraft:light_gray_concrete
fill 83 188 608 83 189 608 minecraft:light_gray_concrete
fill 83 188 610 83 189 610 minecraft:light_gray_concrete
fill 84 188 605 84 189 605 minecraft:light_gray_concrete
fill 84 188 607 84 189 607 minecraft:light_gray_concrete
fill 84 188 609 84 189 609 minecraft:light_gray_concrete
fill 84 188 611 84 189 611 minecraft:light_gray_concrete
setblock 76 190 605 minecraft:sea_lantern
setblock 76 190 607 minecraft:sea_lantern
setblock 76 190 609 minecraft:sea_lantern
setblock 76 190 611 minecraft:sea_lantern
setblock 77 190 606 minecraft:sea_lantern
setblock 77 190 608 minecraft:sea_lantern
setblock 77 190 610 minecraft:sea_lantern
setblock 78 190 605 minecraft:sea_lantern
setblock 78 190 607 minecraft:sea_lantern
setblock 78 190 609 minecraft:sea_lantern
setblock 78 190 611 minecraft:sea_lantern
setblock 79 190 606 minecraft:sea_lantern
setblock 79 190 608 minecraft:sea_lantern
setblock 79 190 610 minecraft:sea_lantern
setblock 80 190 605 minecraft:sea_lantern
setblock 80 190 607 minecraft:sea_lantern
setblock 80 190 609 minecraft:sea_lantern
setblock 80 190 611 minecraft:sea_lantern
setblock 81 190 606 minecraft:sea_lantern
setblock 81 190 608 minecraft:sea_lantern
setblock 81 190 610 minecraft:sea_lantern
setblock 82 190 605 minecraft:sea_lantern
setblock 82 190 607 minecraft:sea_lantern
setblock 82 190 609 minecraft:sea_lantern
setblock 82 190 611 minecraft:sea_lantern
setblock 83 190 606 minecraft:sea_lantern
setblock 83 190 608 minecraft:sea_lantern
setblock 83 190 610 minecraft:sea_lantern
setblock 84 190 605 minecraft:sea_lantern
setblock 84 190 607 minecraft:sea_lantern
setblock 84 190 609 minecraft:sea_lantern
setblock 84 190 611 minecraft:sea_lantern
fill 76 191 605 76 193 605 minecraft:light_gray_concrete
fill 76 191 607 76 193 607 minecraft:light_gray_concrete
fill 76 191 609 76 193 609 minecraft:light_gray_concrete
fill 76 191 611 76 193 611 minecraft:light_gray_concrete
fill 77 191 606 77 193 606 minecraft:light_gray_concrete
fill 77 191 608 77 193 608 minecraft:light_gray_concrete
fill 77 191 610 77 193 610 minecraft:light_gray_concrete
fill 78 191 605 78 193 605 minecraft:light_gray_concrete
fill 78 191 607 78 193 607 minecraft:light_gray_concrete
fill 78 191 609 78 193 609 minecraft:light_gray_concrete
fill 78 191 611 78 193 611 minecraft:light_gray_concrete
fill 79 191 606 79 193 606 minecraft:light_gray_concrete
fill 79 191 608 79 193 608 minecraft:light_gray_concrete
fill 79 191 610 79 193 610 minecraft:light_gray_concrete
fill 80 191 605 80 193 605 minecraft:light_gray_concrete
fill 80 191 607 80 193 607 minecraft:light_gray_concrete
fill 80 191 609 80 193 609 minecraft:light_gray_concrete
fill 80 191 611 80 193 611 minecraft:light_gray_concrete
fill 81 191 606 81 193 606 minecraft:light_gray_concrete
fill 81 191 608 81 193 608 minecraft:light_gray_concrete
fill 81 191 610 81 193 610 minecraft:light_gray_concrete
fill 81 191 631 82 192 632 minecraft:glass
fill 82 191 605 82 225 605 minecraft:light_gray_concrete
fill 82 191 607 82 193 607 minecraft:light_gray_concrete
fill 82 191 609 82 193 609 minecraft:light_gray_concrete
fill 82 191 611 82 193 611 minecraft:light_gray_concrete
fill 83 191 606 83 193 606 minecraft:light_gray_concrete
fill 83 191 608 83 193 608 minecraft:light_gray_concrete
fill 83 191 610 83 193 610 minecraft:light_gray_concrete
fill 84 191 605 84 193 605 minecraft:light_gray_concrete
fill 84 191 607 84 193 607 minecraft:light_gray_concrete
fill 84 191 609 84 193 609 minecraft:light_gray_concrete
fill 84 191 611 84 193 611 minecraft:light_gray_concrete
fill 47 192 609 47 199 609 minecraft:black_concrete
fill 47 192 617 47 199 617 minecraft:black_concrete
fill 47 192 625 47 199 625 minecraft:black_concrete
fill 47 192 633 47 199 633 minecraft:black_concrete
fill 47 192 641 47 199 641 minecraft:black_concrete
setblock 50 192 607 minecraft:light[level=14]
setblock 50 192 615 minecraft:light[level=14]
setblock 50 192 623 minecraft:light[level=14]
setblock 50 192 631 minecraft:light[level=14]
setblock 50 192 639 minecraft:light[level=14]
fill 50 192 646 50 199 646 minecraft:black_concrete
fill 54 192 604 54 199 604 minecraft:black_concrete
setblock 58 192 607 minecraft:light[level=14]
setblock 58 192 615 minecraft:light[level=14]
setblock 58 192 623 minecraft:light[level=14]
setblock 58 192 631 minecraft:light[level=14]
setblock 58 192 639 minecraft:light[level=14]
fill 58 192 646 58 199 646 minecraft:black_concrete
fill 62 192 604 62 199 604 minecraft:black_concrete
setblock 66 192 607 minecraft:light[level=14]
setblock 66 192 615 minecraft:light[level=14]
setblock 66 192 623 minecraft:light[level=14]
setblock 66 192 631 minecraft:light[level=14]
setblock 66 192 639 minecraft:light[level=14]
fill 66 192 646 66 199 646 minecraft:black_concrete
fill 70 192 604 70 199 604 minecraft:black_concrete
setblock 74 192 607 minecraft:light[level=14]
setblock 74 192 615 minecraft:light[level=14]
setblock 74 192 623 minecraft:light[level=14]
setblock 74 192 631 minecraft:light[level=14]
setblock 74 192 639 minecraft:light[level=14]
fill 74 192 646 74 199 646 minecraft:black_concrete
fill 78 192 604 78 199 604 minecraft:black_concrete
setblock 82 192 615 minecraft:light[level=14]
setblock 82 192 623 minecraft:light[level=14]
setblock 82 192 639 minecraft:light[level=14]
fill 82 192 646 82 199 646 minecraft:black_concrete
fill 86 192 604 86 199 604 minecraft:black_concrete
fill 89 192 609 89 199 609 minecraft:black_concrete
fill 89 192 617 89 199 617 minecraft:black_concrete
fill 89 192 625 89 199 625 minecraft:black_concrete
fill 89 192 633 89 199 633 minecraft:black_concrete
fill 89 192 641 89 199 641 minecraft:black_concrete
fill 73 195 642 74 196 642 minecraft:glass
fill 83 195 624 83 200 624 minecraft:magenta_concrete
fill 48 196 605 48 197 610 minecraft:light_gray_concrete
fill 48 196 613 49 196 618 minecraft:light_gray_concrete
fill 48 196 621 49 196 626 minecraft:light_gray_concrete
fill 48 196 629 49 196 634 minecraft:light_gray_concrete
fill 48 196 637 49 196 642 minecraft:light_gray_concrete
fill 48 196 645 53 197 645 minecraft:light_gray_concrete
fill 49 196 606 49 196 612 minecraft:light_gray_concrete
fill 49 196 619 49 196 620 minecraft:light_gray_concrete
fill 49 196 627 49 196 628 minecraft:light_gray_concrete
fill 49 196 635 49 196 636 minecraft:light_gray_concrete
fill 49 196 643 49 196 644 minecraft:light_gray_concrete
fill 50 196 606 87 196 606 minecraft:light_gray_concrete
fill 50 196 644 88 196 644 minecraft:light_gray_concrete
fill 51 196 605 56 197 605 minecraft:light_gray_concrete
fill 56 196 645 61 197 645 minecraft:light_gray_concrete
fill 57 196 607 57 201 607 minecraft:magenta_concrete
fill 59 196 605 64 197 605 minecraft:light_gray_concrete
fill 64 196 645 69 197 645 minecraft:light_gray_concrete
fill 67 196 605 72 197 605 minecraft:light_gray_concrete
fill 72 196 645 77 197 645 minecraft:light_gray_concrete
fill 75 196 605 80 197 605 minecraft:light_gray_concrete
fill 80 196 645 85 197 645 minecraft:light_gray_concrete
fill 82 196 624 82 200 624 minecraft:magenta_concrete
fill 83 196 605 88 197 605 minecraft:light_gray_concrete
fill 83 196 623 83 200 623 minecraft:magenta_concrete
fill 83 196 625 83 200 625 minecraft:magenta_concrete
fill 87 196 607 87 196 643 minecraft:light_gray_concrete
fill 88 196 608 88 197 613 minecraft:light_gray_concrete
fill 88 196 616 88 197 621 minecraft:light_gray_concrete
fill 88 196 624 88 197 629 minecraft:light_gray_concrete
fill 88 196 632 88 197 637 minecraft:light_gray_concrete
fill 88 196 640 88 197 643 minecraft:light_gray_concrete
fill 88 196 645 88 197 645 minecraft:light_gray_concrete
fill 48 197 613 48 197 618 minecraft:light_gray_concrete
fill 48 197 621 48 197 626 minecraft:light_gray_concrete
fill 48 197 629 48 197 634 minecraft:light_gray_concrete
fill 48 197 637 48 197 642 minecraft:light_gray_concrete
fill 81 197 624 81 200 624 minecraft:magenta_concrete
fill 82 197 623 82 200 623 minecraft:magenta_concrete
fill 82 197 625 82 200 625 minecraft:magenta_concrete
fill 84 197 623 84 200 625 minecraft:magenta_concrete
setblock 88 197 644 minecraft:light_gray_concrete
fill 57 198 606 57 201 606 minecraft:magenta_concrete
fill 81 198 623 81 200 623 minecraft:magenta_concrete
fill 81 198 625 81 200 625 minecraft:magenta_concrete
fill 82 198 622 84 200 622 minecraft:magenta_concrete
fill 82 198 626 84 200 626 minecraft:magenta_concrete
fill 85 198 623 85 200 625 minecraft:magenta_concrete
fill 56 199 606 56 201 607 minecraft:magenta_concrete
fill 57 199 608 57 201 608 minecraft:magenta_concrete
fill 58 199 606 58 201 607 minecraft:magenta_concrete
fill 80 199 623 80 200 625 minecraft:magenta_concrete
fill 81 199 622 81 200 622 minecraft:magenta_concrete
fill 81 199 626 81 200 626 minecraft:magenta_concrete
fill 82 199 621 84 200 621 minecraft:magenta_concrete
fill 82 199 627 84 200 627 minecraft:magenta_concrete
fill 85 199 622 85 200 622 minecraft:magenta_concrete
fill 85 199 626 85 200 626 minecraft:magenta_concrete
fill 86 199 624 86 200 624 minecraft:magenta_concrete
fill 47 200 609 47 205 609 minecraft:sea_lantern
fill 47 200 617 47 205 617 minecraft:sea_lantern
fill 47 200 625 47 205 625 minecraft:sea_lantern
fill 47 200 633 47 205 633 minecraft:sea_lantern
fill 47 200 641 47 205 641 minecraft:sea_lantern
setblock 50 200 607 minecraft:light[level=14]
setblock 50 200 615 minecraft:light[level=14]
setblock 50 200 623 minecraft:light[level=14]
setblock 50 200 631 minecraft:light[level=14]
setblock 50 200 639 minecraft:light[level=14]
fill 50 200 646 50 205 646 minecraft:sea_lantern
fill 54 200 604 54 205 604 minecraft:sea_lantern
setblock 58 200 615 minecraft:light[level=14]
setblock 58 200 623 minecraft:light[level=14]
setblock 58 200 631 minecraft:light[level=14]
setblock 58 200 639 minecraft:light[level=14]
fill 58 200 646 58 205 646 minecraft:sea_lantern
fill 62 200 604 62 205 604 minecraft:sea_lantern
setblock 66 200 607 minecraft:light[level=14]
setblock 66 200 615 minecraft:light[level=14]
setblock 66 200 623 minecraft:light[level=14]
setblock 66 200 631 minecraft:light[level=14]
setblock 66 200 639 minecraft:light[level=14]
fill 66 200 646 66 205 646 minecraft:sea_lantern
fill 70 200 604 70 205 604 minecraft:sea_lantern
setblock 74 200 607 minecraft:light[level=14]
setblock 74 200 615 minecraft:light[level=14]
setblock 74 200 623 minecraft:light[level=14]
setblock 74 200 631 minecraft:light[level=14]
setblock 74 200 639 minecraft:light[level=14]
fill 74 200 646 74 205 646 minecraft:sea_lantern
fill 78 200 604 78 205 604 minecraft:sea_lantern
fill 79 200 623 79 200 625 minecraft:magenta_concrete
setblock 80 200 622 minecraft:magenta_concrete
setblock 80 200 626 minecraft:magenta_concrete
setblock 81 200 621 minecraft:magenta_concrete
setblock 81 200 627 minecraft:magenta_concrete
setblock 82 200 607 minecraft:light[level=14]
setblock 82 200 615 minecraft:light[level=14]
setblock 82 200 631 minecraft:light[level=14]
setblock 82 200 639 minecraft:light[level=14]
fill 82 200 646 82 205 646 minecraft:sea_lantern
setblock 83 200 620 minecraft:magenta_concrete
setblock 83 200 628 minecraft:magenta_concrete
setblock 85 200 621 minecraft:magenta_concrete
setblock 85 200 627 minecraft:magenta_concrete
fill 86 200 604 86 205 604 minecraft:sea_lantern
fill 86 200 622 86 200 623 minecraft:magenta_concrete
fill 86 200 625 86 200 626 minecraft:magenta_concrete
fill 89 200 609 89 205 609 minecraft:sea_lantern
fill 89 200 617 89 205 617 minecraft:sea_lantern
fill 89 200 625 89 205 625 minecraft:sea_lantern
fill 89 200 633 89 205 633 minecraft:sea_lantern
fill 89 200 641 89 205 641 minecraft:sea_lantern
fill 47 201 604 47 204 606 minecraft:black_concrete
setblock 47 201 607 minecraft:gray_concrete
fill 47 201 608 47 202 608 minecraft:black_concrete
fill 47 201 642 47 202 643 minecraft:gray_concrete
fill 47 201 644 47 201 645 minecraft:black_concrete
fill 47 201 646 48 201 646 minecraft:gray_concrete
fill 48 201 604 49 204 604 minecraft:black_concrete
fill 49 201 646 49 204 646 minecraft:black_concrete
setblock 50 201 604 minecraft:gray_concrete
fill 51 201 604 52 204 604 minecraft:black_concrete
setblock 56 201 608 minecraft:magenta_concrete
setblock 58 201 608 minecraft:magenta_concrete
setblock 64 201 604 minecraft:gray_concrete
fill 65 201 604 67 204 604 minecraft:black_concrete
setblock 65 201 646 minecraft:gray_concrete
setblock 76 201 604 minecraft:gray_concrete
fill 77 201 646 78 201 646 minecraft:gray_concrete
fill 78 201 619 87 201 629 minecraft:light_gray_concrete
fill 79 201 614 79 202 615 minecraft:gray_concrete
fill 88 201 619 88 201 621 minecraft:light_gray_concrete
fill 88 201 624 88 201 629 minecraft:light_gray_concrete
fill 89 201 629 89 201 630 minecraft:black_concrete
setblock 89 201 631 minecraft:gray_concrete
setblock 89 201 637 minecraft:gray_concrete
setblock 89 201 642 minecraft:gray_concrete
fill 47 202 607 47 204 607 minecraft:black_concrete
fill 47 202 629 47 204 630 minecraft:black_concrete
setblock 47 202 631 minecraft:gray_concrete
setblock 47 202 632 minecraft:black_concrete
fill 47 202 639 47 204 639 minecraft:black_concrete
setblock 47 202 640 minecraft:gray_concrete
fill 47 202 644 47 204 644 minecraft:black_concrete
setblock 47 202 645 minecraft:gray_concrete
fill 47 202 646 48 204 646 minecraft:black_concrete
setblock 50 202 604 minecraft:black_concrete
fill 52 202 646 52 204 646 minecraft:black_concrete
fill 53 202 604 53 203 604 minecraft:gray_concrete
fill 53 202 605 56 204 609 minecraft:light_gray_concrete
setblock 53 202 646 minecraft:gray_concrete
fill 54 202 646 55 202 646 minecraft:black_concrete
fill 57 202 606 61 204 609 minecraft:light_gray_concrete
setblock 57 202 646 minecraft:gray_concrete
fill 59 202 605 61 204 605 minecraft:light_gray_concrete
setblock 63 202 604 minecraft:gray_concrete
fill 64 202 604 64 204 604 minecraft:black_concrete
fill 65 202 646 65 204 646 minecraft:black_concrete
setblock 69 202 604 minecraft:gray_concrete
fill 71 202 604 71 204 604 minecraft:black_concrete
setblock 72 202 604 minecraft:gray_concrete
fill 73 202 604 73 204 604 minecraft:black_concrete
fill 76 202 604 76 204 604 minecraft:black_concrete
fill 77 202 646 78 202 646 minecraft:black_concrete
setblock 78 202 619 minecraft:sea_lantern
fill 78 202 620 78 225 620 minecraft:light_gray_concrete
setblock 78 202 621 minecraft:sea_lantern
fill 78 202 622 78 225 622 minecraft:light_gray_concrete
setblock 78 202 623 minecraft:sea_lantern
fill 78 202 624 78 225 624 minecraft:light_gray_concrete
setblock 78 202 625 minecraft:sea_lantern
fill 78 202 626 78 225 626 minecraft:light_gray_concrete
setblock 78 202 627 minecraft:sea_lantern
fill 78 202 628 78 225 628 minecraft:light_gray_concrete
setblock 78 202 629 minecraft:sea_lantern
fill 79 202 619 79 225 619 minecraft:light_gray_concrete
setblock 79 202 620 minecraft:sea_lantern
fill 79 202 621 79 225 621 minecraft:light_gray_concrete
setblock 79 202 622 minecraft:sea_lantern
fill 79 202 623 79 225 623 minecraft:light_gray_concrete
setblock 79 202 624 minecraft:sea_lantern
fill 79 202 625 79 225 625 minecraft:light_gray_concrete
setblock 79 202 626 minecraft:sea_lantern
fill 79 202 627 79 225 627 minecraft:light_gray_concrete
setblock 79 202 628 minecraft:sea_lantern
fill 79 202 629 79 225 629 minecraft:light_gray_concrete
setblock 80 202 619 minecraft:sea_lantern
fill 80 202 620 80 225 620 minecraft:light_gray_concrete
setblock 80 202 621 minecraft:sea_lantern
fill 80 202 622 80 225 622 minecraft:light_gray_concrete
setblock 80 202 623 minecraft:sea_lantern
fill 80 202 624 80 225 624 minecraft:light_gray_concrete
setblock 80 202 625 minecraft:sea_lantern
fill 80 202 626 80 225 626 minecraft:light_gray_concrete
setblock 80 202 627 minecraft:sea_lantern
fill 80 202 628 80 225 628 minecraft:light_gray_concrete
setblock 80 202 629 minecraft:sea_lantern
fill 81 202 619 81 225 619 minecraft:light_gray_concrete
setblock 81 202 620 minecraft:sea_lantern
fill 81 202 621 81 225 621 minecraft:light_gray_concrete
setblock 81 202 622 minecraft:sea_lantern
fill 81 202 623 81 225 623 minecraft:light_gray_concrete
setblock 81 202 624 minecraft:sea_lantern
fill 81 202 625 81 225 625 minecraft:light_gray_concrete
setblock 81 202 626 minecraft:sea_lantern
fill 81 202 627 81 225 627 minecraft:light_gray_concrete
setblock 81 202 628 minecraft:sea_lantern
fill 81 202 629 81 225 629 minecraft:light_gray_concrete
setblock 82 202 619 minecraft:sea_lantern
fill 82 202 620 82 225 620 minecraft:light_gray_concrete
setblock 82 202 621 minecraft:sea_lantern
fill 82 202 622 82 225 622 minecraft:light_gray_concrete
setblock 82 202 623 minecraft:sea_lantern
fill 82 202 624 82 225 624 minecraft:light_gray_concrete
setblock 82 202 625 minecraft:sea_lantern
fill 82 202 626 82 225 626 minecraft:light_gray_concrete
setblock 82 202 627 minecraft:sea_lantern
fill 82 202 628 82 225 628 minecraft:light_gray_concrete
setblock 82 202 629 minecraft:sea_lantern
setblock 83 202 604 minecraft:gray_concrete
fill 83 202 619 83 225 619 minecraft:light_gray_concrete
setblock 83 202 620 minecraft:sea_lantern
fill 83 202 621 83 225 621 minecraft:light_gray_concrete
setblock 83 202 622 minecraft:sea_lantern
fill 83 202 623 83 225 623 minecraft:light_gray_concrete
setblock 83 202 624 minecraft:sea_lantern
fill 83 202 625 83 225 625 minecraft:light_gray_concrete
setblock 83 202 626 minecraft:sea_lantern
fill 83 202 627 83 225 627 minecraft:light_gray_concrete
setblock 83 202 628 minecraft:sea_lantern
fill 83 202 629 83 225 629 minecraft:light_gray_concrete
fill 83 202 646 83 205 646 minecraft:black_concrete
fill 84 202 604 85 202 604 minecraft:black_concrete
setblock 84 202 619 minecraft:sea_lantern
fill 84 202 620 84 225 620 minecraft:light_gray_concrete
setblock 84 202 621 minecraft:sea_lantern
fill 84 202 622 84 225 622 minecraft:light_gray_concrete
setblock 84 202 623 minecraft:sea_lantern
fill 84 202 624 84 225 624 minecraft:light_gray_concrete
setblock 84 202 625 minecraft:sea_lantern
fill 84 202 626 84 225 626 minecraft:light_gray_concrete
setblock 84 202 627 minecraft:sea_lantern
fill 84 202 628 84 225 628 minecraft:light_gray_concrete
setblock 84 202 629 minecraft:sea_lantern
setblock 84 202 646 minecraft:gray_concrete
fill 85 202 619 85 225 619 minecraft:light_gray_concrete
setblock 85 202 620 minecraft:sea_lantern
fill 85 202 621 85 225 621 minecraft:light_gray_concrete
setblock 85 202 622 minecraft:sea_lantern
fill 85 202 623 85 225 623 minecraft:light_gray_concrete
setblock 85 202 624 minecraft:sea_lantern
fill 85 202 625 85 225 625 minecraft:light_gray_concrete
setblock 85 202 626 minecraft:sea_lantern
fill 85 202 627 85 225 627 minecraft:light_gray_concrete
setblock 85 202 628 minecraft:sea_lantern
fill 85 202 629 85 225 629 minecraft:light_gray_concrete
setblock 86 202 619 minecraft:sea_lantern
fill 86 202 620 86 225 620 minecraft:light_gray_concrete
setblock 86 202 621 minecraft:sea_lantern
fill 86 202 622 86 225 622 minecraft:light_gray_concrete
setblock 86 202 623 minecraft:sea_lantern
fill 86 202 624 86 225 624 minecraft:light_gray_concrete
setblock 86 202 625 minecraft:sea_lantern
fill 86 202 626 86 225 626 minecraft:light_gray_concrete
setblock 86 202 627 minecraft:sea_lantern
fill 86 202 628 86 225 628 minecraft:light_gray_concrete
setblock 86 202 629 minecraft:sea_lantern
fill 87 202 619 87 225 619 minecraft:light_gray_concrete
setblock 87 202 620 minecraft:sea_lantern
fill 87 202 621 87 225 621 minecraft:light_gray_concrete
setblock 87 202 622 minecraft:sea_lantern
fill 87 202 623 87 225 623 minecraft:light_gray_concrete
setblock 87 202 624 minecraft:sea_lantern
fill 87 202 625 87 225 625 minecraft:light_gray_concrete
setblock 87 202 626 minecraft:sea_lantern
fill 87 202 627 87 225 627 minecraft:light_gray_concrete
setblock 87 202 628 minecraft:sea_lantern
fill 87 202 629 87 225 629 minecraft:light_gray_concrete
setblock 88 202 619 minecraft:sea_lantern
fill 88 202 620 88 225 620 minecraft:light_gray_concrete
setblock 88 202 621 minecraft:sea_lantern
fill 88 202 622 88 225 622 minecraft:light_gray_concrete
setblock 88 202 623 minecraft:sea_lantern
fill 88 202 624 88 225 624 minecraft:light_gray_concrete
setblock 88 202 625 minecraft:sea_lantern
fill 88 202 626 88 225 626 minecraft:light_gray_concrete
setblock 88 202 627 minecraft:sea_lantern
fill 88 202 628 88 225 628 minecraft:light_gray_concrete
setblock 88 202 629 minecraft:sea_lantern
fill 89 202 604 89 202 606 minecraft:black_concrete
setblock 89 202 607 minecraft:gray_concrete
setblock 89 202 621 minecraft:gray_concrete
fill 89 202 629 89 204 629 minecraft:black_concrete
setblock 89 202 630 minecraft:gray_concrete
fill 89 202 631 89 204 631 minecraft:black_concrete
fill 89 202 637 89 205 637 minecraft:black_concrete
setblock 89 202 642 minecraft:black_concrete
setblock 47 203 608 minecraft:gray_concrete
fill 47 203 611 47 204 613 minecraft:black_concrete
fill 47 203 614 47 203 615 minecraft:gray_concrete
fill 47 203 616 47 204 616 minecraft:black_concrete
fill 47 203 631 47 204 631 minecraft:black_concrete
setblock 47 203 632 minecraft:gray_concrete
fill 47 203 640 47 204 640 minecraft:black_concrete
fill 47 203 642 47 204 643 minecraft:black_concrete
fill 47 203 645 47 204 645 minecraft:black_concrete
setblock 50 203 604 minecraft:gray_concrete
fill 53 203 646 53 204 646 minecraft:black_concrete
setblock 54 203 646 minecraft:gray_concrete
setblock 55 203 604 minecraft:gray_concrete
fill 55 203 646 55 205 646 minecraft:black_concrete
fill 56 203 604 57 204 604 minecraft:black_concrete
fill 57 203 646 57 204 646 minecraft:black_concrete
setblock 58 203 604 minecraft:gray_concrete
fill 59 203 604 60 204 604 minecraft:black_concrete
setblock 61 203 604 minecraft:gray_concrete
fill 63 203 604 63 204 604 minecraft:black_concrete
fill 69 203 604 69 204 604 minecraft:black_concrete
fill 72 203 604 72 204 604 minecraft:black_concrete
fill 73 203 611 73 204 611 minecraft:gray_concrete
fill 74 203 604 74 204 604 minecraft:black_concrete
setblock 75 203 604 minecraft:gray_concrete
setblock 77 203 604 minecraft:gray_concrete
fill 77 203 646 77 204 646 minecraft:black_concrete
fill 78 203 619 78 204 619 minecraft:light_gray_concrete
fill 78 203 621 78 204 621 minecraft:light_gray_concrete
fill 78 203 623 78 204 623 minecraft:light_gray_concrete
fill 78 203 625 78 204 625 minecraft:light_gray_concrete
fill 78 203 627 78 204 627 minecraft:light_gray_concrete
fill 78 203 629 78 204 629 minecraft:light_gray_concrete
setblock 78 203 646 minecraft:gray_concrete
fill 79 203 620 79 204 620 minecraft:light_gray_concrete
fill 79 203 622 79 204 622 minecraft:light_gray_concrete
fill 79 203 624 79 204 624 minecraft:light_gray_concrete
fill 79 203 626 79 204 626 minecraft:light_gray_concrete
fill 79 203 628 79 204 628 minecraft:light_gray_concrete
fill 80 203 619 80 204 619 minecraft:light_gray_concrete
fill 80 203 621 80 204 621 minecraft:light_gray_concrete
fill 80 203 623 80 204 623 minecraft:light_gray_concrete
fill 80 203 625 80 204 625 minecraft:light_gray_concrete
fill 80 203 627 80 204 627 minecraft:light_gray_concrete
fill 80 203 629 80 204 629 minecraft:light_gray_concrete
fill 81 203 620 81 204 620 minecraft:light_gray_concrete
fill 81 203 622 81 204 622 minecraft:light_gray_concrete
fill 81 203 624 81 204 624 minecraft:light_gray_concrete
fill 81 203 626 81 204 626 minecraft:light_gray_concrete
fill 81 203 628 81 204 628 minecraft:light_gray_concrete
fill 82 203 619 82 204 619 minecraft:light_gray_concrete
fill 82 203 621 82 204 621 minecraft:light_gray_concrete
fill 82 203 623 82 204 623 minecraft:light_gray_concrete
fill 82 203 625 82 204 625 minecraft:light_gray_concrete
fill 82 203 627 82 204 627 minecraft:light_gray_concrete
fill 82 203 629 82 204 629 minecraft:light_gray_concrete
fill 83 203 604 83 204 604 minecraft:black_concrete
fill 83 203 620 83 204 620 minecraft:light_gray_concrete
fill 83 203 622 83 204 622 minecraft:light_gray_concrete
fill 83 203 624 83 204 624 minecraft:light_gray_concrete
fill 83 203 626 83 204 626 minecraft:light_gray_concrete
fill 83 203 628 83 204 628 minecraft:light_gray_concrete
setblock 84 203 604 minecraft:gray_concrete
fill 84 203 619 84 204 619 minecraft:light_gray_concrete
fill 84 203 621 84 204 621 minecraft:light_gray_concrete
fill 84 203 623 84 204 623 minecraft:light_gray_concrete
fill 84 203 625 84 204 625 minecraft:light_gray_concrete
fill 84 203 627 84 204 627 minecraft:light_gray_concrete
fill 84 203 629 84 204 629 minecraft:light_gray_concrete
fill 84 203 646 84 204 646 minecraft:black_concrete
fill 85 203 604 85 204 604 minecraft:black_concrete
fill 85 203 620 85 204 620 minecraft:light_gray_concrete
fill 85 203 622 85 204 622 minecraft:light_gray_concrete
fill 85 203 624 85 204 624 minecraft:light_gray_concrete
fill 85 203 626 85 204 626 minecraft:light_gray_concrete
fill 85 203 628 85 204 628 minecraft:light_gray_concrete
fill 86 203 619 86 204 619 minecraft:light_gray_concrete
fill 86 203 621 86 204 621 minecraft:light_gray_concrete
fill 86 203 623 86 204 623 minecraft:light_gray_concrete
fill 86 203 625 86 204 625 minecraft:light_gray_concrete
fill 86 203 627 86 204 627 minecraft:light_gray_concrete
fill 86 203 629 86 204 629 minecraft:light_gray_concrete
fill 87 203 620 87 204 620 minecraft:light_gray_concrete
fill 87 203 622 87 204 622 minecraft:light_gray_concrete
fill 87 203 624 87 204 624 minecraft:light_gray_concrete
fill 87 203 626 87 204 626 minecraft:light_gray_concrete
fill 87 203 628 87 204 628 minecraft:light_gray_concrete
fill 88 203 619 88 204 619 minecraft:light_gray_concrete
fill 88 203 621 88 204 621 minecraft:light_gray_concrete
fill 88 203 623 88 204 623 minecraft:light_gray_concrete
fill 88 203 625 88 204 625 minecraft:light_gray_concrete
fill 88 203 627 88 204 627 minecraft:light_gray_concrete
fill 88 203 629 88 204 629 minecraft:light_gray_concrete
fill 89 203 604 89 204 605 minecraft:black_concrete
setblock 89 203 606 minecraft:gray_concrete
fill 89 203 607 89 204 607 minecraft:black_concrete
fill 89 203 621 89 204 621 minecraft:black_concrete
fill 89 203 630 89 204 630 minecraft:black_concrete
setblock 89 203 638 minecraft:gray_concrete
setblock 89 203 642 minecraft:gray_concrete
fill 89 203 644 89 205 644 minecraft:black_concrete
setblock 89 203 645 minecraft:gray_concrete
setblock 47 204 608 minecraft:black_concrete
fill 47 204 614 47 204 615 minecraft:black_concrete
setblock 47 204 632 minecraft:black_concrete
setblock 50 204 604 minecraft:black_concrete
fill 51 204 617 51 209 617 minecraft:magenta_concrete
setblock 53 204 604 minecraft:black_concrete
setblock 54 204 646 minecraft:black_concrete
setblock 55 204 604 minecraft:black_concrete
setblock 58 204 604 minecraft:black_concrete
setblock 61 204 604 minecraft:black_concrete
fill 66 204 636 68 205 636 minecraft:magenta_concrete
fill 67 204 635 67 205 635 minecraft:magenta_concrete
fill 67 204 637 67 205 637 minecraft:magenta_concrete
setblock 75 204 604 minecraft:black_concrete
fill 77 204 604 77 206 604 minecraft:black_concrete
fill 78 204 646 78 205 646 minecraft:black_concrete
setblock 84 204 604 minecraft:black_concrete
setblock 89 204 606 minecraft:black_concrete
setblock 89 204 638 minecraft:black_concrete
setblock 89 204 642 minecraft:black_concrete
setblock 89 204 645 minecraft:black_concrete
fill 47 205 604 47 307 608 minecraft:gray_concrete
fill 47 205 611 47 205 614 minecraft:gray_concrete
setblock 47 205 615 minecraft:black_concrete
fill 47 205 616 47 307 616 minecraft:gray_concrete
fill 47 205 618 47 307 619 minecraft:gray_concrete
setblock 47 205 620 minecraft:black_concrete
fill 47 205 621 47 205 624 minecraft:gray_concrete
fill 47 205 627 47 307 628 minecraft:gray_concrete
setblock 47 205 629 minecraft:black_concrete
fill 47 205 630 47 307 632 minecraft:gray_concrete
fill 47 205 635 47 205 640 minecraft:gray_concrete
fill 47 205 642 47 206 646 minecraft:gray_concrete
fill 48 205 604 53 206 604 minecraft:gray_concrete
fill 48 205 646 49 307 646 minecraft:gray_concrete
fill 50 205 608 50 210 608 minecraft:magenta_concrete
fill 51 205 646 54 307 646 minecraft:gray_concrete
fill 52 205 617 52 209 617 minecraft:magenta_concrete
fill 53 205 605 53 225 605 minecraft:light_gray_concrete
setblock 53 205 606 minecraft:sea_lantern
fill 53 205 607 53 225 607 minecraft:light_gray_concrete
setblock 53 205 608 minecraft:sea_lantern
fill 53 205 609 53 225 609 minecraft:light_gray_concrete
setblock 54 205 605 minecraft:sea_lantern
fill 54 205 606 54 225 606 minecraft:light_gray_concrete
setblock 54 205 607 minecraft:sea_lantern
fill 54 205 608 54 225 608 minecraft:light_gray_concrete
setblock 54 205 609 minecraft:sea_lantern
fill 55 205 604 55 307 604 minecraft:gray_concrete
fill 55 205 605 55 225 605 minecraft:light_gray_concrete
setblock 55 205 606 minecraft:sea_lantern
fill 55 205 607 55 225 607 minecraft:light_gray_concrete
setblock 55 205 608 minecraft:sea_lantern
fill 55 205 609 55 225 609 minecraft:light_gray_concrete
setblock 56 205 604 minecraft:black_concrete
setblock 56 205 605 minecraft:sea_lantern
fill 56 205 606 56 225 606 minecraft:light_gray_concrete
setblock 56 205 607 minecraft:sea_lantern
fill 56 205 608 56 225 608 minecraft:light_gray_concrete
setblock 56 205 609 minecraft:sea_lantern
fill 56 205 646 57 307 646 minecraft:gray_concrete
fill 57 205 604 59 307 604 minecraft:gray_concrete
fill 57 205 605 57 225 605 minecraft:light_gray_concrete
setblock 57 205 606 minecraft:sea_lantern
fill 57 205 607 57 225 607 minecraft:light_gray_concrete
setblock 57 205 608 minecraft:sea_lantern
fill 57 205 609 57 225 609 minecraft:light_gray_concrete
setblock 58 205 605 minecraft:sea_lantern
fill 58 205 606 58 225 606 minecraft:light_gray_concrete
setblock 58 205 607 minecraft:sea_lantern
fill 58 205 608 58 225 608 minecraft:light_gray_concrete
setblock 58 205 609 minecraft:sea_lantern
fill 59 205 605 59 225 605 minecraft:light_gray_concrete
setblock 59 205 606 minecraft:sea_lantern
fill 59 205 607 59 225 607 minecraft:light_gray_concrete
setblock 59 205 608 minecraft:sea_lantern
fill 59 205 609 59 225 609 minecraft:light_gray_concrete
fill 59 205 646 63 205 646 minecraft:gray_concrete
setblock 60 205 604 minecraft:black_concrete
setblock 60 205 605 minecraft:sea_lantern
fill 60 205 606 60 225 606 minecraft:light_gray_concrete
setblock 60 205 607 minecraft:sea_lantern
fill 60 205 608 60 225 608 minecraft:light_gray_concrete
setblock 60 205 609 minecraft:sea_lantern
fill 61 205 604 61 307 604 minecraft:gray_concrete
fill 61 205 605 61 225 605 minecraft:light_gray_concrete
setblock 61 205 606 minecraft:sea_lantern
fill 61 205 607 61 225 607 minecraft:light_gray_concrete
setblock 61 205 608 minecraft:sea_lantern
fill 61 205 609 61 225 609 minecraft:light_gray_concrete
fill 63 205 604 69 205 604 minecraft:gray_concrete
fill 65 205 646 65 307 646 minecraft:gray_concrete
fill 67 205 646 73 307 646 minecraft:gray_concrete
fill 71 205 604 76 205 604 minecraft:gray_concrete
fill 75 205 646 77 307 646 minecraft:gray_concrete
setblock 78 205 619 minecraft:sea_lantern
setblock 78 205 621 minecraft:sea_lantern
setblock 78 205 623 minecraft:sea_lantern
setblock 78 205 625 minecraft:sea_lantern
setblock 78 205 627 minecraft:sea_lantern
setblock 78 205 629 minecraft:sea_lantern
fill 79 205 604 80 307 604 minecraft:gray_concrete
setblock 79 205 620 minecraft:sea_lantern
setblock 79 205 622 minecraft:sea_lantern
setblock 79 205 624 minecraft:sea_lantern
setblock 79 205 626 minecraft:sea_lantern
setblock 79 205 628 minecraft:sea_lantern
fill 79 205 646 80 307 646 minecraft:gray_concrete
setblock 80 205 619 minecraft:sea_lantern
setblock 80 205 621 minecraft:sea_lantern
setblock 80 205 623 minecraft:sea_lantern
setblock 80 205 625 minecraft:sea_lantern
setblock 80 205 627 minecraft:sea_lantern
setblock 80 205 629 minecraft:sea_lantern
setblock 81 205 620 minecraft:sea_lantern
setblock 81 205 622 minecraft:sea_lantern
setblock 81 205 624 minecraft:sea_lantern
setblock 81 205 626 minecraft:sea_lantern
setblock 81 205 628 minecraft:sea_lantern
setblock 81 205 646 minecraft:black_concrete
setblock 82 205 619 minecraft:sea_lantern
setblock 82 205 621 minecraft:sea_lantern
setblock 82 205 623 minecraft:sea_lantern
setblock 82 205 625 minecraft:sea_lantern
setblock 82 205 627 minecraft:sea_lantern
setblock 82 205 629 minecraft:sea_lantern
fill 83 205 604 85 205 604 minecraft:gray_concrete
setblock 83 205 620 minecraft:sea_lantern
setblock 83 205 622 minecraft:sea_lantern
setblock 83 205 624 minecraft:sea_lantern
setblock 83 205 626 minecraft:sea_lantern
setblock 83 205 628 minecraft:sea_lantern
setblock 84 205 619 minecraft:sea_lantern
setblock 84 205 621 minecraft:sea_lantern
setblock 84 205 623 minecraft:sea_lantern
setblock 84 205 625 minecraft:sea_lantern
setblock 84 205 627 minecraft:sea_lantern
setblock 84 205 629 minecraft:sea_lantern
fill 84 205 646 88 205 646 minecraft:gray_concrete
setblock 85 205 620 minecraft:sea_lantern
setblock 85 205 622 minecraft:sea_lantern
setblock 85 205 624 minecraft:sea_lantern
setblock 85 205 626 minecraft:sea_lantern
setblock 85 205 628 minecraft:sea_lantern
setblock 86 205 619 minecraft:sea_lantern
setblock 86 205 621 minecraft:sea_lantern
setblock 86 205 623 minecraft:sea_lantern
setblock 86 205 625 minecraft:sea_lantern
setblock 86 205 627 minecraft:sea_lantern
setblock 86 205 629 minecraft:sea_lantern
fill 87 205 604 89 307 604 minecraft:gray_concrete
setblock 87 205 620 minecraft:sea_lantern
setblock 87 205 622 minecraft:sea_lantern
setblock 87 205 624 minecraft:sea_lantern
setblock 87 205 626 minecraft:sea_lantern
setblock 87 205 628 minecraft:sea_lantern
setblock 88 205 619 minecraft:sea_lantern
setblock 88 205 621 minecraft:sea_lantern
setblock 88 205 623 minecraft:sea_lantern
setblock 88 205 625 minecraft:sea_lantern
setblock 88 205 627 minecraft:sea_lantern
setblock 88 205 629 minecraft:sea_lantern
fill 89 205 605 89 307 608 minecraft:gray_concrete
fill 89 205 610 89 206 614 minecraft:gray_concrete
setblock 89 205 615 minecraft:black_concrete
fill 89 205 616 89 307 616 minecraft:gray_concrete
fill 89 205 618 89 205 621 minecraft:gray_concrete
setblock 89 205 623 minecraft:gray_concrete
fill 89 205 624 89 206 624 minecraft:black_concrete
fill 89 205 626 89 205 632 minecraft:gray_concrete
fill 89 205 634 89 307 634 minecraft:gray_concrete
fill 89 205 635 89 206 635 minecraft:black_concrete
fill 89 205 636 89 307 636 minecraft:gray_concrete
fill 89 205 638 89 307 640 minecraft:gray_concrete
fill 89 205 642 89 206 643 minecraft:gray_concrete
fill 89 205 645 89 307 645 minecraft:gray_concrete
fill 47 206 609 47 213 611 minecraft:gray_concrete
setblock 47 206 612 minecraft:black_concrete
fill 47 206 613 47 206 615 minecraft:gray_concrete
setblock 47 206 617 minecraft:black_concrete
fill 47 206 620 47 307 620 minecraft:gray_concrete
setblock 47 206 621 minecraft:black_concrete
fill 47 206 622 47 307 622 minecraft:gray_concrete
fill 47 206 623 47 206 624 minecraft:black_concrete
fill 47 206 625 47 213 626 minecraft:gray_concrete
fill 47 206 629 47 307 629 minecraft:gray_concrete
fill 47 206 633 47 213 636 minecraft:gray_concrete
setblock 47 206 637 minecraft:black_concrete
fill 47 206 638 47 213 641 minecraft:gray_concrete
fill 50 206 617 50 209 617 minecraft:magenta_concrete
fill 50 206 646 50 213 646 minecraft:gray_concrete
fill 51 206 616 52 209 616 minecraft:magenta_concrete
fill 51 206 618 52 209 618 minecraft:magenta_concrete
fill 53 206 606 53 207 606 minecraft:light_gray_concrete
fill 53 206 608 53 207 608 minecraft:light_gray_concrete
fill 54 206 604 54 213 604 minecraft:gray_concrete
fill 54 206 605 54 207 605 minecraft:light_gray_concrete
fill 54 206 607 54 207 607 minecraft:light_gray_concrete
fill 54 206 609 54 207 609 minecraft:light_gray_concrete
fill 55 206 606 55 207 606 minecraft:light_gray_concrete
fill 55 206 608 55 207 608 minecraft:light_gray_concrete
fill 55 206 646 55 307 646 minecraft:gray_concrete
setblock 56 206 604 minecraft:gray_concrete
fill 56 206 605 56 207 605 minecraft:light_gray_concrete
fill 56 206 607 56 207 607 minecraft:light_gray_concrete
fill 56 206 609 56 207 609 minecraft:light_gray_concrete
fill 57 206 606 57 207 606 minecraft:light_gray_concrete
fill 57 206 608 57 207 608 minecraft:light_gray_concrete
fill 58 206 605 58 207 605 minecraft:light_gray_concrete
fill 58 206 607 58 207 607 minecraft:light_gray_concrete
fill 58 206 609 58 207 609 minecraft:light_gray_concrete
fill 58 206 646 58 213 646 minecraft:gray_concrete
fill 59 206 606 59 207 606 minecraft:light_gray_concrete
fill 59 206 608 59 207 608 minecraft:light_gray_concrete
setblock 59 206 646 minecraft:black_concrete
fill 60 206 604 60 307 604 minecraft:gray_concrete
fill 60 206 605 60 207 605 minecraft:light_gray_concrete
fill 60 206 607 60 207 607 minecraft:light_gray_concrete
fill 60 206 609 60 207 609 minecraft:light_gray_concrete
fill 60 206 646 64 206 646 minecraft:gray_concrete
fill 61 206 606 61 207 606 minecraft:light_gray_concrete
fill 61 206 608 61 207 608 minecraft:light_gray_concrete
fill 62 206 604 68 213 604 minecraft:gray_concrete
fill 66 206 646 66 213 646 minecraft:gray_concrete
setblock 69 206 604 minecraft:black_concrete
fill 70 206 604 71 206 604 minecraft:gray_concrete
fill 72 206 604 72 207 604 minecraft:black_concrete
fill 73 206 604 76 206 604 minecraft:gray_concrete
setblock 74 206 646 minecraft:black_concrete
fill 78 206 604 78 213 604 minecraft:gray_concrete
fill 78 206 619 78 207 619 minecraft:light_gray_concrete
fill 78 206 621 78 207 621 minecraft:light_gray_concrete
fill 78 206 623 78 207 623 minecraft:light_gray_concrete
fill 78 206 625 78 207 625 minecraft:light_gray_concrete
fill 78 206 627 78 207 627 minecraft:light_gray_concrete
fill 78 206 629 78 207 629 minecraft:light_gray_concrete
setblock 78 206 646 minecraft:gray_concrete
fill 79 206 620 79 207 620 minecraft:light_gray_concrete
fill 79 206 622 79 207 622 minecraft:light_gray_concrete
fill 79 206 624 79 207 624 minecraft:light_gray_concrete
fill 79 206 626 79 207 626 minecraft:light_gray_concrete
fill 79 206 628 79 207 628 minecraft:light_gray_concrete
fill 80 206 619 80 207 619 minecraft:light_gray_concrete
fill 80 206 621 80 207 621 minecraft:light_gray_concrete
fill 80 206 623 80 207 623 minecraft:light_gray_concrete
fill 80 206 625 80 207 625 minecraft:light_gray_concrete
fill 80 206 627 80 207 627 minecraft:light_gray_concrete
fill 80 206 629 80 207 629 minecraft:light_gray_concrete
fill 81 206 604 82 307 604 minecraft:gray_concrete
fill 81 206 620 81 207 620 minecraft:light_gray_concrete
fill 81 206 622 81 207 622 minecraft:light_gray_concrete
fill 81 206 624 81 207 624 minecraft:light_gray_concrete
fill 81 206 626 81 207 626 minecraft:light_gray_concrete
fill 81 206 628 81 207 628 minecraft:light_gray_concrete
fill 81 206 646 83 213 646 minecraft:gray_concrete
fill 82 206 619 82 207 619 minecraft:light_gray_concrete
fill 82 206 621 82 207 621 minecraft:light_gray_concrete
fill 82 206 623 82 207 623 minecraft:light_gray_concrete
fill 82 206 625 82 207 625 minecraft:light_gray_concrete
fill 82 206 627 82 207 627 minecraft:light_gray_concrete
fill 82 206 629 82 207 629 minecraft:light_gray_concrete
setblock 83 206 604 minecraft:black_concrete
fill 83 206 620 83 207 620 minecraft:light_gray_concrete
fill 83 206 622 83 207 622 minecraft:light_gray_concrete
fill 83 206 624 83 207 624 minecraft:light_gray_concrete
fill 83 206 626 83 207 626 minecraft:light_gray_concrete
fill 83 206 628 83 207 628 minecraft:light_gray_concrete
fill 84 206 604 86 206 604 minecraft:gray_concrete
fill 84 206 619 84 207 619 minecraft:light_gray_concrete
fill 84 206 621 84 207 621 minecraft:light_gray_concrete
fill 84 206 623 84 207 623 minecraft:light_gray_concrete
fill 84 206 625 84 207 625 minecraft:light_gray_concrete
fill 84 206 627 84 207 627 minecraft:light_gray_concrete
fill 84 206 629 84 207 629 minecraft:light_gray_concrete
setblock 84 206 646 minecraft:black_concrete
fill 85 206 620 85 207 620 minecraft:light_gray_concrete
fill 85 206 622 85 207 622 minecraft:light_gray_concrete
fill 85 206 624 85 207 624 minecraft:light_gray_concrete
fill 85 206 626 85 207 626 minecraft:light_gray_concrete
fill 85 206 628 85 207 628 minecraft:light_gray_concrete
fill 85 206 646 88 307 646 minecraft:gray_concrete
fill 86 206 619 86 207 619 minecraft:light_gray_concrete
fill 86 206 621 86 207 621 minecraft:light_gray_concrete
fill 86 206 623 86 207 623 minecraft:light_gray_concrete
fill 86 206 625 86 207 625 minecraft:light_gray_concrete
fill 86 206 627 86 207 627 minecraft:light_gray_concrete
fill 86 206 629 86 207 629 minecraft:light_gray_concrete
fill 87 206 620 87 207 620 minecraft:light_gray_concrete
fill 87 206 622 87 207 622 minecraft:light_gray_concrete
fill 87 206 624 87 207 624 minecraft:light_gray_concrete
fill 87 206 626 87 207 626 minecraft:light_gray_concrete
fill 87 206 628 87 207 628 minecraft:light_gray_concrete
fill 88 206 619 88 207 619 minecraft:light_gray_concrete
fill 88 206 621 88 207 621 minecraft:light_gray_concrete
fill 88 206 623 88 207 623 minecraft:light_gray_concrete
fill 88 206 625 88 207 625 minecraft:light_gray_concrete
fill 88 206 627 88 207 627 minecraft:light_gray_concrete
fill 88 206 629 88 207 629 minecraft:light_gray_concrete
fill 89 206 609 89 213 609 minecraft:gray_concrete
fill 89 206 615 89 307 615 minecraft:gray_concrete
fill 89 206 617 89 213 617 minecraft:gray_concrete
fill 89 206 618 89 207 618 minecraft:black_concrete
fill 89 206 619 89 206 622 minecraft:gray_concrete
setblock 89 206 623 minecraft:black_concrete
fill 89 206 625 89 213 625 minecraft:gray_concrete
setblock 89 206 626 minecraft:black_concrete
fill 89 206 627 89 206 633 minecraft:gray_concrete
fill 89 206 637 89 307 637 minecraft:gray_concrete
fill 89 206 641 89 213 641 minecraft:gray_concrete
fill 89 206 644 89 307 644 minecraft:gray_concrete
fill 47 207 612 47 307 613 minecraft:gray_concrete
setblock 47 207 614 minecraft:black_concrete
fill 47 207 615 47 307 615 minecraft:gray_concrete
fill 47 207 617 47 213 617 minecraft:gray_concrete
fill 47 207 621 47 307 621 minecraft:gray_concrete
setblock 47 207 623 minecraft:black_concrete
fill 47 207 624 47 307 624 minecraft:gray_concrete
fill 47 207 637 47 307 637 minecraft:gray_concrete
fill 47 207 642 47 307 642 minecraft:gray_concrete
setblock 47 207 643 minecraft:black_concrete
fill 47 207 644 47 307 646 minecraft:gray_concrete
setblock 48 207 604 minecraft:black_concrete
fill 49 207 604 53 213 604 minecraft:gray_concrete
fill 49 207 608 49 209 608 minecraft:magenta_concrete
fill 50 207 616 50 209 616 minecraft:magenta_concrete
fill 50 207 618 50 209 618 minecraft:magenta_concrete
fill 51 207 615 51 209 615 minecraft:magenta_concrete
fill 51 207 619 51 209 619 minecraft:magenta_concrete
fill 53 207 616 53 209 618 minecraft:magenta_concrete
setblock 56 207 604 minecraft:black_concrete
fill 59 207 646 63 307 646 minecraft:gray_concrete
setblock 64 207 646 minecraft:black_concrete
fill 69 207 604 69 307 604 minecraft:gray_concrete
setblock 70 207 604 minecraft:black_concrete
fill 71 207 604 71 307 604 minecraft:gray_concrete
setblock 73 207 604 minecraft:black_concrete
fill 74 207 604 77 307 604 minecraft:gray_concrete
fill 74 207 646 74 213 646 minecraft:gray_concrete
setblock 78 207 646 minecraft:black_concrete
fill 83 207 604 84 307 604 minecraft:gray_concrete
fill 84 207 646 84 307 646 minecraft:gray_concrete
setblock 85 207 604 minecraft:black_concrete
fill 86 207 604 86 213 604 minecraft:gray_concrete
setblock 89 207 610 minecraft:black_concrete
fill 89 207 611 89 307 614 minecraft:gray_concrete
fill 89 207 619 89 307 620 minecraft:gray_concrete
setblock 89 207 621 minecraft:black_concrete
fill 89 207 622 89 307 624 minecraft:gray_concrete
fill 89 207 626 89 307 630 minecraft:gray_concrete
setblock 89 207 631 minecraft:black_concrete
fill 89 207 632 89 213 633 minecraft:gray_concrete
fill 89 207 635 89 307 635 minecraft:gray_concrete
setblock 89 207 642 minecraft:black_concrete
fill 89 207 643 89 307 643 minecraft:gray_concrete
fill 89 207 646 89 307 646 minecraft:gray_concrete
fill 47 208 614 47 307 614 minecraft:gray_concrete
fill 47 208 623 47 307 623 minecraft:gray_concrete
fill 47 208 643 47 307 643 minecraft:gray_concrete
fill 48 208 604 48 307 604 minecraft:gray_concrete
fill 49 208 607 50 209 607 minecraft:magenta_concrete
fill 49 208 609 50 209 609 minecraft:magenta_concrete
fill 49 208 616 49 209 618 minecraft:magenta_concrete
fill 50 208 615 50 209 615 minecraft:magenta_concrete
fill 50 208 619 50 209 619 minecraft:magenta_concrete
setblock 50 208 623 minecraft:light[level=14]
setblock 50 208 631 minecraft:light[level=14]
setblock 50 208 639 minecraft:light[level=14]
fill 51 208 608 51 210 608 minecraft:magenta_concrete
fill 52 208 615 52 209 615 minecraft:magenta_concrete
fill 52 208 619 52 209 619 minecraft:magenta_concrete
setblock 53 208 606 minecraft:sea_lantern
setblock 53 208 608 minecraft:sea_lantern
setblock 54 208 605 minecraft:sea_lantern
setblock 54 208 607 minecraft:sea_lantern
setblock 54 208 609 minecraft:sea_lantern
setblock 55 208 606 minecraft:sea_lantern
setblock 55 208 608 minecraft:sea_lantern
fill 56 208 604 56 307 604 minecraft:gray_concrete
setblock 56 208 605 minecraft:sea_lantern
setblock 56 208 607 minecraft:sea_lantern
setblock 56 208 609 minecraft:sea_lantern
setblock 57 208 606 minecraft:sea_lantern
setblock 57 208 608 minecraft:sea_lantern
setblock 58 208 605 minecraft:sea_lantern
setblock 58 208 607 minecraft:sea_lantern
setblock 58 208 609 minecraft:sea_lantern
setblock 58 208 615 minecraft:light[level=14]
setblock 58 208 623 minecraft:light[level=14]
setblock 58 208 631 minecraft:light[level=14]
setblock 58 208 639 minecraft:light[level=14]
setblock 59 208 606 minecraft:sea_lantern
setblock 59 208 608 minecraft:sea_lantern
setblock 60 208 605 minecraft:sea_lantern
setblock 60 208 607 minecraft:sea_lantern
setblock 60 208 609 minecraft:sea_lantern
setblock 61 208 606 minecraft:sea_lantern
setblock 61 208 608 minecraft:sea_lantern
fill 64 208 646 64 307 646 minecraft:gray_concrete
setblock 66 208 607 minecraft:light[level=14]
setblock 66 208 615 minecraft:light[level=14]
setblock 66 208 623 minecraft:light[level=14]
setblock 66 208 631 minecraft:light[level=14]
setblock 66 208 639 minecraft:light[level=14]
fill 70 208 604 70 213 604 minecraft:gray_concrete
fill 72 208 604 73 307 604 minecraft:gray_concrete
setblock 74 208 607 minecraft:light[level=14]
setblock 74 208 615 minecraft:light[level=14]
setblock 74 208 623 minecraft:light[level=14]
setblock 74 208 631 minecraft:light[level=14]
setblock 74 208 639 minecraft:light[level=14]
setblock 78 208 619 minecraft:sea_lantern
setblock 78 208 621 minecraft:sea_lantern
setblock 78 208 623 minecraft:sea_lantern
setblock 78 208 625 minecraft:sea_lantern
setblock 78 208 627 minecraft:sea_lantern
setblock 78 208 629 minecraft:sea_lantern
fill 78 208 646 78 307 646 minecraft:gray_concrete
setblock 79 208 620 minecraft:sea_lantern
setblock 79 208 622 minecraft:sea_lantern
setblock 79 208 624 minecraft:sea_lantern
setblock 79 208 626 minecraft:sea_lantern
setblock 79 208 628 minecraft:sea_lantern
setblock 80 208 619 minecraft:sea_lantern
setblock 80 208 621 minecraft:sea_lantern
setblock 80 208 623 minecraft:sea_lantern
setblock 80 208 625 minecraft:sea_lantern
setblock 80 208 627 minecraft:sea_lantern
setblock 80 208 629 minecraft:sea_lantern
setblock 81 208 620 minecraft:sea_lantern
setblock 81 208 622 minecraft:sea_lantern
setblock 81 208 624 minecraft:sea_lantern
setblock 81 208 626 minecraft:sea_lantern
setblock 81 208 628 minecraft:sea_lantern
setblock 82 208 607 minecraft:light[level=14]
setblock 82 208 615 minecraft:light[level=14]
setblock 82 208 619 minecraft:sea_lantern
setblock 82 208 621 minecraft:sea_lantern
setblock 82 208 623 minecraft:sea_lantern
setblock 82 208 625 minecraft:sea_lantern
setblock 82 208 627 minecraft:sea_lantern
setblock 82 208 629 minecraft:sea_lantern
setblock 82 208 631 minecraft:light[level=14]
setblock 82 208 639 minecraft:light[level=14]
setblock 83 208 620 minecraft:sea_lantern
setblock 83 208 622 minecraft:sea_lantern
setblock 83 208 624 minecraft:sea_lantern
setblock 83 208 626 minecraft:sea_lantern
setblock 83 208 628 minecraft:sea_lantern
setblock 84 208 619 minecraft:sea_lantern
setblock 84 208 621 minecraft:sea_lantern
setblock 84 208 623 minecraft:sea_lantern
setblock 84 208 625 minecraft:sea_lantern
setblock 84 208 627 minecraft:sea_lantern
setblock 84 208 629 minecraft:sea_lantern
fill 85 208 604 85 307 604 minecraft:gray_concrete
setblock 85 208 620 minecraft:sea_lantern
setblock 85 208 622 minecraft:sea_lantern
setblock 85 208 624 minecraft:sea_lantern
setblock 85 208 626 minecraft:sea_lantern
setblock 85 208 628 minecraft:sea_lantern
setblock 86 208 619 minecraft:sea_lantern
setblock 86 208 621 minecraft:sea_lantern
setblock 86 208 623 minecraft:sea_lantern
setblock 86 208 625 minecraft:sea_lantern
setblock 86 208 627 minecraft:sea_lantern
setblock 86 208 629 minecraft:sea_lantern
setblock 87 208 620 minecraft:sea_lantern
setblock 87 208 622 minecraft:sea_lantern
setblock 87 208 624 minecraft:sea_lantern
setblock 87 208 626 minecraft:sea_lantern
setblock 87 208 628 minecraft:sea_lantern
setblock 88 208 619 minecraft:sea_lantern
setblock 88 208 621 minecraft:sea_lantern
setblock 88 208 623 minecraft:sea_lantern
setblock 88 208 625 minecraft:sea_lantern
setblock 88 208 627 minecraft:sea_lantern
setblock 88 208 629 minecraft:sea_lantern
fill 89 208 610 89 307 610 minecraft:gray_concrete
fill 89 208 618 89 307 618 minecraft:gray_concrete
fill 89 208 621 89 307 621 minecraft:gray_concrete
fill 89 208 631 89 307 631 minecraft:gray_concrete
fill 89 208 642 89 307 642 minecraft:gray_concrete
setblock 49 209 615 minecraft:magenta_concrete
setblock 49 209 619 minecraft:magenta_concrete
fill 51 209 614 52 209 614 minecraft:magenta_concrete
fill 51 209 620 52 209 620 minecraft:magenta_concrete
fill 53 209 606 53 210 606 minecraft:light_gray_concrete
fill 53 209 608 53 210 608 minecraft:light_gray_concrete
setblock 53 209 615 minecraft:magenta_concrete
setblock 53 209 619 minecraft:magenta_concrete
fill 54 209 605 54 210 605 minecraft:light_gray_concrete
fill 54 209 607 54 210 607 minecraft:light_gray_concrete
fill 54 209 609 54 210 609 minecraft:light_gray_concrete
fill 54 209 616 54 209 618 minecraft:magenta_concrete
fill 55 209 606 55 210 606 minecraft:light_gray_concrete
fill 55 209 608 55 210 608 minecraft:light_gray_concrete
fill 56 209 605 56 210 605 minecraft:light_gray_concrete
fill 56 209 607 56 210 607 minecraft:light_gray_concrete
fill 56 209 609 56 210 609 minecraft:light_gray_concrete
fill 57 209 606 57 210 606 minecraft:light_gray_concrete
fill 57 209 608 57 210 608 minecraft:light_gray_concrete
fill 58 209 605 58 210 605 minecraft:light_gray_concrete
fill 58 209 607 58 210 607 minecraft:light_gray_concrete
fill 58 209 609 58 210 609 minecraft:light_gray_concrete
fill 59 209 606 59 210 606 minecraft:light_gray_concrete
fill 59 209 608 59 210 608 minecraft:light_gray_concrete
fill 60 209 605 60 210 605 minecraft:light_gray_concrete
fill 60 209 607 60 210 607 minecraft:light_gray_concrete
fill 60 209 609 60 210 609 minecraft:light_gray_concrete
fill 61 209 606 61 210 606 minecraft:light_gray_concrete
fill 61 209 608 61 210 608 minecraft:light_gray_concrete
fill 78 209 619 78 210 619 minecraft:light_gray_concrete
fill 78 209 621 78 210 621 minecraft:light_gray_concrete
fill 78 209 623 78 210 623 minecraft:light_gray_concrete
fill 78 209 625 78 210 625 minecraft:light_gray_concrete
fill 78 209 627 78 210 627 minecraft:light_gray_concrete
fill 78 209 629 78 210 629 minecraft:light_gray_concrete
fill 79 209 620 79 210 620 minecraft:light_gray_concrete
fill 79 209 622 79 210 622 minecraft:light_gray_concrete
fill 79 209 624 79 210 624 minecraft:light_gray_concrete
fill 79 209 626 79 210 626 minecraft:light_gray_concrete
fill 79 209 628 79 210 628 minecraft:light_gray_concrete
fill 80 209 619 80 210 619 minecraft:light_gray_concrete
fill 80 209 621 80 210 621 minecraft:light_gray_concrete
fill 80 209 623 80 210 623 minecraft:light_gray_concrete
fill 80 209 625 80 210 625 minecraft:light_gray_concrete
fill 80 209 627 80 210 627 minecraft:light_gray_concrete
fill 80 209 629 80 210 629 minecraft:light_gray_concrete
fill 81 209 620 81 210 620 minecraft:light_gray_concrete
fill 81 209 622 81 210 622 minecraft:light_gray_concrete
fill 81 209 624 81 210 624 minecraft:light_gray_concrete
fill 81 209 626 81 210 626 minecraft:light_gray_concrete
fill 81 209 628 81 210 628 minecraft:light_gray_concrete
fill 82 209 619 82 210 619 minecraft:light_gray_concrete
fill 82 209 621 82 210 621 minecraft:light_gray_concrete
fill 82 209 623 82 210 623 minecraft:light_gray_concrete
fill 82 209 625 82 210 625 minecraft:light_gray_concrete
fill 82 209 627 82 210 627 minecraft:light_gray_concrete
fill 82 209 629 82 210 629 minecraft:light_gray_concrete
fill 83 209 620 83 210 620 minecraft:light_gray_concrete
fill 83 209 622 83 210 622 minecraft:light_gray_concrete
fill 83 209 624 83 210 624 minecraft:light_gray_concrete
fill 83 209 626 83 210 626 minecraft:light_gray_concrete
fill 83 209 628 83 210 628 minecraft:light_gray_concrete
fill 84 209 619 84 210 619 minecraft:light_gray_concrete
fill 84 209 621 84 210 621 minecraft:light_gray_concrete
fill 84 209 623 84 210 623 minecraft:light_gray_concrete
fill 84 209 625 84 210 625 minecraft:light_gray_concrete
fill 84 209 627 84 210 627 minecraft:light_gray_concrete
fill 84 209 629 84 210 629 minecraft:light_gray_concrete
fill 85 209 620 85 210 620 minecraft:light_gray_concrete
fill 85 209 622 85 210 622 minecraft:light_gray_concrete
fill 85 209 624 85 210 624 minecraft:light_gray_concrete
fill 85 209 626 85 210 626 minecraft:light_gray_concrete
fill 85 209 628 85 210 628 minecraft:light_gray_concrete
fill 86 209 619 86 210 619 minecraft:light_gray_concrete
fill 86 209 621 86 210 621 minecraft:light_gray_concrete
fill 86 209 623 86 210 623 minecraft:light_gray_concrete
fill 86 209 625 86 210 625 minecraft:light_gray_concrete
fill 86 209 627 86 210 627 minecraft:light_gray_concrete
fill 86 209 629 86 210 629 minecraft:light_gray_concrete
fill 87 209 620 87 210 620 minecraft:light_gray_concrete
fill 87 209 622 87 210 622 minecraft:light_gray_concrete
fill 87 209 624 87 210 624 minecraft:light_gray_concrete
fill 87 209 626 87 210 626 minecraft:light_gray_concrete
fill 87 209 628 87 210 628 minecraft:light_gray_concrete
fill 88 209 619 88 210 619 minecraft:light_gray_concrete
fill 88 209 621 88 210 621 minecraft:light_gray_concrete
fill 88 209 623 88 210 623 minecraft:light_gray_concrete
fill 88 209 625 88 210 625 minecraft:light_gray_concrete
fill 88 209 627 88 210 627 minecraft:light_gray_concrete
fill 88 209 629 88 210 629 minecraft:light_gray_concrete
fill 48 210 605 48 213 610 minecraft:light_gray_concrete
fill 48 210 613 55 210 618 minecraft:light_gray_concrete
fill 48 210 621 49 210 626 minecraft:light_gray_concrete
fill 48 210 629 49 210 634 minecraft:light_gray_concrete
fill 48 210 637 49 210 642 minecraft:light_gray_concrete
fill 48 210 645 53 211 645 minecraft:light_gray_concrete
fill 49 210 606 49 210 612 minecraft:light_gray_concrete
fill 49 210 619 55 210 620 minecraft:light_gray_concrete
fill 49 210 627 49 210 628 minecraft:light_gray_concrete
fill 49 210 635 49 210 636 minecraft:light_gray_concrete
fill 49 210 643 49 210 644 minecraft:light_gray_concrete
fill 50 210 606 52 213 606 minecraft:light_gray_concrete
fill 50 210 607 51 210 607 minecraft:magenta_concrete
fill 50 210 609 51 210 609 minecraft:magenta_concrete
fill 50 210 612 55 210 612 minecraft:light_gray_concrete
fill 50 210 621 55 210 622 minecraft:light_gray_concrete
fill 50 210 644 88 210 644 minecraft:light_gray_concrete
fill 51 210 605 52 213 605 minecraft:light_gray_concrete
fill 56 210 645 61 211 645 minecraft:light_gray_concrete
fill 62 210 605 64 210 606 minecraft:light_gray_concrete
fill 64 210 645 69 211 645 minecraft:light_gray_concrete
fill 65 210 606 87 210 606 minecraft:light_gray_concrete
fill 67 210 605 72 211 605 minecraft:light_gray_concrete
fill 72 210 645 77 211 645 minecraft:light_gray_concrete
fill 75 210 605 80 211 605 minecraft:light_gray_concrete
fill 80 210 645 85 211 645 minecraft:light_gray_concrete
fill 83 210 605 88 211 605 minecraft:light_gray_concrete
fill 87 210 607 87 210 618 minecraft:light_gray_concrete
fill 87 210 630 87 210 643 minecraft:light_gray_concrete
fill 88 210 608 88 211 613 minecraft:light_gray_concrete
fill 88 210 616 88 211 618 minecraft:light_gray_concrete
fill 88 210 632 88 211 637 minecraft:light_gray_concrete
fill 88 210 640 88 211 643 minecraft:light_gray_concrete
fill 88 210 645 88 211 645 minecraft:light_gray_concrete
setblock 48 211 613 minecraft:sea_lantern
fill 48 211 614 48 225 614 minecraft:light_gray_concrete
setblock 48 211 615 minecraft:sea_lantern
fill 48 211 616 48 225 616 minecraft:light_gray_concrete
setblock 48 211 617 minecraft:sea_lantern
fill 48 211 618 48 225 618 minecraft:light_gray_concrete
setblock 48 211 619 minecraft:sea_lantern
fill 48 211 620 48 225 620 minecraft:light_gray_concrete
setblock 48 211 621 minecraft:sea_lantern
fill 48 211 622 48 211 626 minecraft:light_gray_concrete
fill 48 211 629 48 211 634 minecraft:light_gray_concrete
fill 48 211 637 48 211 642 minecraft:light_gray_concrete
fill 49 211 606 49 213 611 minecraft:light_gray_concrete
setblock 49 211 612 minecraft:sea_lantern
fill 49 211 613 49 225 613 minecraft:light_gray_concrete
setblock 49 211 614 minecraft:sea_lantern
fill 49 211 615 49 225 615 minecraft:light_gray_concrete
setblock 49 211 616 minecraft:sea_lantern
fill 49 211 617 49 225 617 minecraft:light_gray_concrete
setblock 49 211 618 minecraft:sea_lantern
fill 49 211 619 49 225 619 minecraft:light_gray_concrete
setblock 49 211 620 minecraft:sea_lantern
fill 49 211 621 49 225 621 minecraft:light_gray_concrete
setblock 49 211 622 minecraft:sea_lantern
fill 50 211 607 50 213 612 minecraft:light_gray_concrete
setblock 50 211 613 minecraft:sea_lantern
fill 50 211 614 50 225 614 minecraft:light_gray_concrete
setblock 50 211 615 minecraft:sea_lantern
fill 50 211 616 50 225 616 minecraft:light_gray_concrete
setblock 50 211 617 minecraft:sea_lantern
fill 50 211 618 50 225 618 minecraft:light_gray_concrete
setblock 50 211 619 minecraft:sea_lantern
fill 50 211 620 50 225 620 minecraft:light_gray_concrete
setblock 50 211 621 minecraft:sea_lantern
fill 50 211 622 50 225 622 minecraft:light_gray_concrete
fill 51 211 607 52 213 611 minecraft:light_gray_concrete
setblock 51 211 612 minecraft:sea_lantern
fill 51 211 613 51 225 613 minecraft:light_gray_concrete
setblock 51 211 614 minecraft:sea_lantern
fill 51 211 615 51 225 615 minecraft:light_gray_concrete
setblock 51 211 616 minecraft:sea_lantern
fill 51 211 617 51 225 617 minecraft:light_gray_concrete
setblock 51 211 618 minecraft:sea_lantern
fill 51 211 619 51 225 619 minecraft:light_gray_concrete
setblock 51 211 620 minecraft:sea_lantern
fill 51 211 621 51 225 621 minecraft:light_gray_concrete
setblock 51 211 622 minecraft:sea_lantern
fill 52 211 612 52 225 612 minecraft:light_gray_concrete
setblock 52 211 613 minecraft:sea_lantern
fill 52 211 614 52 225 614 minecraft:light_gray_concrete
setblock 52 211 615 minecraft:sea_lantern
fill 52 211 616 52 225 616 minecraft:light_gray_concrete
setblock 52 211 617 minecraft:sea_lantern
fill 52 211 618 52 225 618 minecraft:light_gray_concrete
setblock 52 211 619 minecraft:sea_lantern
fill 52 211 620 52 225 620 minecraft:light_gray_concrete
setblock 52 211 621 minecraft:sea_lantern
fill 52 211 622 52 225 622 minecraft:light_gray_concrete
setblock 53 211 606 minecraft:sea_lantern
setblock 53 211 608 minecraft:sea_lantern
setblock 53 211 612 minecraft:sea_lantern
fill 53 211 613 53 225 613 minecraft:light_gray_concrete
setblock 53 211 614 minecraft:sea_lantern
fill 53 211 615 53 225 615 minecraft:light_gray_concrete
setblock 53 211 616 minecraft:sea_lantern
fill 53 211 617 53 225 617 minecraft:light_gray_concrete
setblock 53 211 618 minecraft:sea_lantern
fill 53 211 619 53 225 619 minecraft:light_gray_concrete
setblock 53 211 620 minecraft:sea_lantern
fill 53 211 621 53 225 621 minecraft:light_gray_concrete
setblock 53 211 622 minecraft:sea_lantern
setblock 54 211 605 minecraft:sea_lantern
setblock 54 211 607 minecraft:sea_lantern
setblock 54 211 609 minecraft:sea_lantern
fill 54 211 612 54 225 612 minecraft:light_gray_concrete
setblock 54 211 613 minecraft:sea_lantern
fill 54 211 614 54 225 614 minecraft:light_gray_concrete
setblock 54 211 615 minecraft:sea_lantern
fill 54 211 616 54 225 616 minecraft:light_gray_concrete
setblock 54 211 617 minecraft:sea_lantern
fill 54 211 618 54 225 618 minecraft:light_gray_concrete
setblock 54 211 619 minecraft:sea_lantern
fill 54 211 620 54 225 620 minecraft:light_gray_concrete
setblock 54 211 621 minecraft:sea_lantern
fill 54 211 622 54 225 622 minecraft:light_gray_concrete
setblock 55 211 606 minecraft:sea_lantern
setblock 55 211 608 minecraft:sea_lantern
setblock 55 211 612 minecraft:sea_lantern
fill 55 211 613 55 225 613 minecraft:light_gray_concrete
setblock 55 211 614 minecraft:sea_lantern
fill 55 211 615 55 225 615 minecraft:light_gray_concrete
setblock 55 211 616 minecraft:sea_lantern
fill 55 211 617 55 225 617 minecraft:light_gray_concrete
setblock 55 211 618 minecraft:sea_lantern
fill 55 211 619 55 225 619 minecraft:light_gray_concrete
setblock 55 211 620 minecraft:sea_lantern
fill 55 211 621 55 225 621 minecraft:light_gray_concrete
setblock 55 211 622 minecraft:sea_lantern
setblock 56 211 605 minecraft:sea_lantern
setblock 56 211 607 minecraft:sea_lantern
setblock 56 211 609 minecraft:sea_lantern
setblock 57 211 606 minecraft:sea_lantern
setblock 57 211 608 minecraft:sea_lantern
setblock 58 211 605 minecraft:sea_lantern
setblock 58 211 607 minecraft:sea_lantern
setblock 58 211 609 minecraft:sea_lantern
setblock 59 211 606 minecraft:sea_lantern
setblock 59 211 608 minecraft:sea_lantern
setblock 60 211 605 minecraft:sea_lantern
setblock 60 211 607 minecraft:sea_lantern
setblock 60 211 609 minecraft:sea_lantern
setblock 61 211 606 minecraft:sea_lantern
setblock 61 211 608 minecraft:sea_lantern
fill 62 211 605 64 211 605 minecraft:light_gray_concrete
setblock 78 211 619 minecraft:sea_lantern
setblock 78 211 621 minecraft:sea_lantern
setblock 78 211 623 minecraft:sea_lantern
setblock 78 211 625 minecraft:sea_lantern
setblock 78 211 627 minecraft:sea_lantern
setblock 78 211 629 minecraft:sea_lantern
setblock 79 211 620 minecraft:sea_lantern
setblock 79 211 622 minecraft:sea_lantern
setblock 79 211 624 minecraft:sea_lantern
setblock 79 211 626 minecraft:sea_lantern
setblock 79 211 628 minecraft:sea_lantern
setblock 80 211 619 minecraft:sea_lantern
setblock 80 211 621 minecraft:sea_lantern
setblock 80 211 623 minecraft:sea_lantern
setblock 80 211 625 minecraft:sea_lantern
setblock 80 211 627 minecraft:sea_lantern
setblock 80 211 629 minecraft:sea_lantern
setblock 81 211 620 minecraft:sea_lantern
setblock 81 211 622 minecraft:sea_lantern
setblock 81 211 624 minecraft:sea_lantern
setblock 81 211 626 minecraft:sea_lantern
setblock 81 211 628 minecraft:sea_lantern
setblock 82 211 619 minecraft:sea_lantern
setblock 82 211 621 minecraft:sea_lantern
setblock 82 211 623 minecraft:sea_lantern
setblock 82 211 625 minecraft:sea_lantern
setblock 82 211 627 minecraft:sea_lantern
setblock 82 211 629 minecraft:sea_lantern
setblock 83 211 620 minecraft:sea_lantern
setblock 83 211 622 minecraft:sea_lantern
setblock 83 211 624 minecraft:sea_lantern
setblock 83 211 626 minecraft:sea_lantern
setblock 83 211 628 minecraft:sea_lantern
setblock 84 211 619 minecraft:sea_lantern
setblock 84 211 621 minecraft:sea_lantern
setblock 84 211 623 minecraft:sea_lantern
setblock 84 211 625 minecraft:sea_lantern
setblock 84 211 627 minecraft:sea_lantern
setblock 84 211 629 minecraft:sea_lantern
setblock 85 211 620 minecraft:sea_lantern
setblock 85 211 622 minecraft:sea_lantern
setblock 85 211 624 minecraft:sea_lantern
setblock 85 211 626 minecraft:sea_lantern
setblock 85 211 628 minecraft:sea_lantern
setblock 86 211 619 minecraft:sea_lantern
setblock 86 211 621 minecraft:sea_lantern
setblock 86 211 623 minecraft:sea_lantern
setblock 86 211 625 minecraft:sea_lantern
setblock 86 211 627 minecraft:sea_lantern
setblock 86 211 629 minecraft:sea_lantern
setblock 87 211 620 minecraft:sea_lantern
setblock 87 211 622 minecraft:sea_lantern
setblock 87 211 624 minecraft:sea_lantern
setblock 87 211 626 minecraft:sea_lantern
setblock 87 211 628 minecraft:sea_lantern
setblock 88 211 619 minecraft:sea_lantern
setblock 88 211 621 minecraft:sea_lantern
setblock 88 211 623 minecraft:sea_lantern
setblock 88 211 625 minecraft:sea_lantern
setblock 88 211 627 minecraft:sea_lantern
setblock 88 211 629 minecraft:sea_lantern
setblock 88 211 644 minecraft:light_gray_concrete
fill 48 212 613 48 213 613 minecraft:light_gray_concrete
fill 48 212 615 48 213 615 minecraft:light_gray_concrete
fill 48 212 617 48 213 617 minecraft:light_gray_concrete
fill 48 212 619 48 213 619 minecraft:light_gray_concrete
fill 48 212 621 48 213 622 minecraft:light_gray_concrete
fill 49 212 612 49 213 612 minecraft:light_gray_concrete
fill 49 212 614 49 213 614 minecraft:light_gray_concrete
fill 49 212 616 49 213 616 minecraft:light_gray_concrete
fill 49 212 618 49 213 618 minecraft:light_gray_concrete
fill 49 212 620 49 213 620 minecraft:light_gray_concrete
fill 49 212 622 49 213 622 minecraft:light_gray_concrete
fill 50 212 613 50 213 613 minecraft:light_gray_concrete
fill 50 212 615 50 213 615 minecraft:light_gray_concrete
fill 50 212 617 50 213 617 minecraft:light_gray_concrete
fill 50 212 619 50 213 619 minecraft:light_gray_concrete
fill 50 212 621 50 213 621 minecraft:light_gray_concrete
fill 51 212 612 51 213 612 minecraft:light_gray_concrete
fill 51 212 614 51 213 614 minecraft:light_gray_concrete
fill 51 212 616 51 213 616 minecraft:light_gray_concrete
fill 51 212 618 51 213 618 minecraft:light_gray_concrete
fill 51 212 620 51 213 620 minecraft:light_gray_concrete
fill 51 212 622 51 213 622 minecraft:light_gray_concrete
fill 52 212 613 52 213 613 minecraft:light_gray_concrete
fill 52 212 615 52 213 615 minecraft:light_gray_concrete
fill 52 212 617 52 213 617 minecraft:light_gray_concrete
fill 52 212 619 52 213 619 minecraft:light_gray_concrete
fill 52 212 621 52 213 621 minecraft:light_gray_concrete
fill 53 212 606 53 213 606 minecraft:light_gray_concrete
fill 53 212 608 53 213 608 minecraft:light_gray_concrete
fill 53 212 612 53 213 612 minecraft:light_gray_concrete
fill 53 212 614 53 213 614 minecraft:light_gray_concrete
fill 53 212 616 53 213 616 minecraft:light_gray_concrete
fill 53 212 618 53 213 618 minecraft:light_gray_concrete
fill 53 212 620 53 213 620 minecraft:light_gray_concrete
fill 53 212 622 53 213 622 minecraft:light_gray_concrete
fill 54 212 605 54 213 605 minecraft:light_gray_concrete
fill 54 212 607 54 213 607 minecraft:light_gray_concrete
fill 54 212 609 54 213 609 minecraft:light_gray_concrete
fill 54 212 613 54 213 613 minecraft:light_gray_concrete
fill 54 212 615 54 213 615 minecraft:light_gray_concrete
fill 54 212 617 54 213 617 minecraft:light_gray_concrete
fill 54 212 619 54 213 619 minecraft:light_gray_concrete
fill 54 212 621 54 213 621 minecraft:light_gray_concrete
fill 55 212 606 55 213 606 minecraft:light_gray_concrete
fill 55 212 608 55 213 608 minecraft:light_gray_concrete
fill 55 212 612 55 213 612 minecraft:light_gray_concrete
fill 55 212 614 55 213 614 minecraft:light_gray_concrete
fill 55 212 616 55 213 616 minecraft:light_gray_concrete
fill 55 212 618 55 213 618 minecraft:light_gray_concrete
fill 55 212 620 55 213 620 minecraft:light_gray_concrete
fill 55 212 622 55 213 622 minecraft:light_gray_concrete
fill 56 212 605 56 213 605 minecraft:light_gray_concrete
fill 56 212 607 56 213 607 minecraft:light_gray_concrete
fill 56 212 609 56 213 609 minecraft:light_gray_concrete
fill 57 212 606 57 213 606 minecraft:light_gray_concrete
fill 57 212 608 57 213 608 minecraft:light_gray_concrete
fill 58 212 605 58 213 605 minecraft:light_gray_concrete
fill 58 212 607 58 213 607 minecraft:light_gray_concrete
fill 58 212 609 58 213 609 minecraft:light_gray_concrete
fill 59 212 606 59 213 606 minecraft:light_gray_concrete
fill 59 212 608 59 213 608 minecraft:light_gray_concrete
fill 60 212 605 60 213 605 minecraft:light_gray_concrete
fill 60 212 607 60 213 607 minecraft:light_gray_concrete
fill 60 212 609 60 213 609 minecraft:light_gray_concrete
fill 61 212 606 61 213 606 minecraft:light_gray_concrete
fill 61 212 608 61 213 608 minecraft:light_gray_concrete
fill 78 212 619 78 213 619 minecraft:light_gray_concrete
fill 78 212 621 78 213 621 minecraft:light_gray_concrete
fill 78 212 623 78 213 623 minecraft:light_gray_concrete
fill 78 212 625 78 213 625 minecraft:light_gray_concrete
fill 78 212 627 78 213 627 minecraft:light_gray_concrete
fill 78 212 629 78 213 629 minecraft:light_gray_concrete
fill 79 212 620 79 213 620 minecraft:light_gray_concrete
fill 79 212 622 79 213 622 minecraft:light_gray_concrete
fill 79 212 624 79 213 624 minecraft:light_gray_concrete
fill 79 212 626 79 213 626 minecraft:light_gray_concrete
fill 79 212 628 79 213 628 minecraft:light_gray_concrete
fill 80 212 619 80 213 619 minecraft:light_gray_concrete
fill 80 212 621 80 213 621 minecraft:light_gray_concrete
fill 80 212 623 80 213 623 minecraft:light_gray_concrete
fill 80 212 625 80 213 625 minecraft:light_gray_concrete
fill 80 212 627 80 213 627 minecraft:light_gray_concrete
fill 80 212 629 80 213 629 minecraft:light_gray_concrete
fill 81 212 620 81 213 620 minecraft:light_gray_concrete
fill 81 212 622 81 213 622 minecraft:light_gray_concrete
fill 81 212 624 81 213 624 minecraft:light_gray_concrete
fill 81 212 626 81 213 626 minecraft:light_gray_concrete
fill 81 212 628 81 213 628 minecraft:light_gray_concrete
fill 82 212 619 82 213 619 minecraft:light_gray_concrete
fill 82 212 621 82 213 621 minecraft:light_gray_concrete
fill 82 212 623 82 213 623 minecraft:light_gray_concrete
fill 82 212 625 82 213 625 minecraft:light_gray_concrete
fill 82 212 627 82 213 627 minecraft:light_gray_concrete
fill 82 212 629 82 213 629 minecraft:light_gray_concrete
fill 83 212 620 83 213 620 minecraft:light_gray_concrete
fill 83 212 622 83 213 622 minecraft:light_gray_concrete
fill 83 212 624 83 213 624 minecraft:light_gray_concrete
fill 83 212 626 83 213 626 minecraft:light_gray_concrete
fill 83 212 628 83 213 628 minecraft:light_gray_concrete
fill 84 212 619 84 213 619 minecraft:light_gray_concrete
fill 84 212 621 84 213 621 minecraft:light_gray_concrete
fill 84 212 623 84 213 623 minecraft:light_gray_concrete
fill 84 212 625 84 213 625 minecraft:light_gray_concrete
fill 84 212 627 84 213 627 minecraft:light_gray_concrete
fill 84 212 629 84 213 629 minecraft:light_gray_concrete
fill 85 212 620 85 213 620 minecraft:light_gray_concrete
fill 85 212 622 85 213 622 minecraft:light_gray_concrete
fill 85 212 624 85 213 624 minecraft:light_gray_concrete
fill 85 212 626 85 213 626 minecraft:light_gray_concrete
fill 85 212 628 85 213 628 minecraft:light_gray_concrete
fill 86 212 619 86 213 619 minecraft:light_gray_concrete
fill 86 212 621 86 213 621 minecraft:light_gray_concrete
fill 86 212 623 86 213 623 minecraft:light_gray_concrete
fill 86 212 625 86 213 625 minecraft:light_gray_concrete
fill 86 212 627 86 213 627 minecraft:light_gray_concrete
fill 86 212 629 86 213 629 minecraft:light_gray_concrete
fill 87 212 620 87 213 620 minecraft:light_gray_concrete
fill 87 212 622 87 213 622 minecraft:light_gray_concrete
fill 87 212 624 87 213 624 minecraft:light_gray_concrete
fill 87 212 626 87 213 626 minecraft:light_gray_concrete
fill 87 212 628 87 213 628 minecraft:light_gray_concrete
fill 88 212 619 88 213 619 minecraft:light_gray_concrete
fill 88 212 621 88 213 621 minecraft:light_gray_concrete
fill 88 212 623 88 213 623 minecraft:light_gray_concrete
fill 88 212 625 88 213 625 minecraft:light_gray_concrete
fill 88 212 627 88 213 627 minecraft:light_gray_concrete
fill 88 212 629 88 213 629 minecraft:light_gray_concrete
fill 47 214 609 48 214 609 minecraft:sea_lantern
fill 47 214 610 47 307 611 minecraft:gray_concrete
fill 47 214 617 48 214 617 minecraft:sea_lantern
fill 47 214 625 47 219 625 minecraft:sea_lantern
fill 47 214 626 47 307 626 minecraft:gray_concrete
fill 47 214 633 47 219 633 minecraft:sea_lantern
fill 47 214 634 47 307 636 minecraft:gray_concrete
fill 47 214 638 47 307 640 minecraft:gray_concrete
fill 47 214 641 47 219 641 minecraft:sea_lantern
setblock 48 214 605 minecraft:sea_lantern
fill 48 214 606 48 225 606 minecraft:light_gray_concrete
setblock 48 214 607 minecraft:sea_lantern
fill 48 214 608 48 225 608 minecraft:light_gray_concrete
fill 48 214 610 48 225 610 minecraft:light_gray_concrete
setblock 48 214 611 minecraft:sea_lantern
fill 48 214 612 48 225 612 minecraft:light_gray_concrete
setblock 48 214 613 minecraft:sea_lantern
setblock 48 214 615 minecraft:sea_lantern
setblock 48 214 619 minecraft:sea_lantern
setblock 48 214 621 minecraft:sea_lantern
fill 48 214 622 48 225 622 minecraft:light_gray_concrete
setblock 49 214 604 minecraft:sea_lantern
fill 49 214 605 49 225 605 minecraft:light_gray_concrete
setblock 49 214 606 minecraft:sea_lantern
fill 49 214 607 49 225 607 minecraft:light_gray_concrete
setblock 49 214 608 minecraft:sea_lantern
fill 49 214 609 49 225 609 minecraft:light_gray_concrete
setblock 49 214 610 minecraft:sea_lantern
fill 49 214 611 49 225 611 minecraft:light_gray_concrete
setblock 49 214 612 minecraft:sea_lantern
setblock 49 214 614 minecraft:sea_lantern
setblock 49 214 616 minecraft:sea_lantern
setblock 49 214 618 minecraft:sea_lantern
setblock 49 214 620 minecraft:sea_lantern
setblock 49 214 622 minecraft:sea_lantern
fill 50 214 604 50 307 604 minecraft:gray_concrete
setblock 50 214 605 minecraft:sea_lantern
fill 50 214 606 50 225 606 minecraft:light_gray_concrete
setblock 50 214 607 minecraft:sea_lantern
fill 50 214 608 50 225 608 minecraft:light_gray_concrete
setblock 50 214 609 minecraft:sea_lantern
fill 50 214 610 50 225 610 minecraft:light_gray_concrete
setblock 50 214 611 minecraft:sea_lantern
fill 50 214 612 50 225 612 minecraft:light_gray_concrete
setblock 50 214 613 minecraft:sea_lantern
setblock 50 214 615 minecraft:sea_lantern
setblock 50 214 617 minecraft:sea_lantern
setblock 50 214 619 minecraft:sea_lantern
setblock 50 214 621 minecraft:sea_lantern
fill 50 214 646 50 219 646 minecraft:sea_lantern
setblock 51 214 604 minecraft:sea_lantern
fill 51 214 605 51 225 605 minecraft:light_gray_concrete
setblock 51 214 606 minecraft:sea_lantern
fill 51 214 607 51 225 607 minecraft:light_gray_concrete
setblock 51 214 608 minecraft:sea_lantern
fill 51 214 609 51 225 609 minecraft:light_gray_concrete
setblock 51 214 610 minecraft:sea_lantern
fill 51 214 611 51 225 611 minecraft:light_gray_concrete
setblock 51 214 612 minecraft:sea_lantern
setblock 51 214 614 minecraft:sea_lantern
setblock 51 214 616 minecraft:sea_lantern
setblock 51 214 618 minecraft:sea_lantern
setblock 51 214 620 minecraft:sea_lantern
setblock 51 214 622 minecraft:sea_lantern
fill 52 214 604 53 307 604 minecraft:gray_concrete
setblock 52 214 605 minecraft:sea_lantern
fill 52 214 606 52 225 606 minecraft:light_gray_concrete
setblock 52 214 607 minecraft:sea_lantern
fill 52 214 608 52 225 608 minecraft:light_gray_concrete
setblock 52 214 609 minecraft:sea_lantern
fill 52 214 610 52 225 610 minecraft:light_gray_concrete
setblock 52 214 611 minecraft:sea_lantern
setblock 52 214 613 minecraft:sea_lantern
setblock 52 214 615 minecraft:sea_lantern
setblock 52 214 617 minecraft:sea_lantern
setblock 52 214 619 minecraft:sea_lantern
setblock 52 214 621 minecraft:sea_lantern
setblock 53 214 606 minecraft:sea_lantern
setblock 53 214 608 minecraft:sea_lantern
setblock 53 214 612 minecraft:sea_lantern
setblock 53 214 614 minecraft:sea_lantern
setblock 53 214 616 minecraft:sea_lantern
setblock 53 214 618 minecraft:sea_lantern
setblock 53 214 620 minecraft:sea_lantern
setblock 53 214 622 minecraft:sea_lantern
fill 54 214 604 54 214 605 minecraft:sea_lantern
setblock 54 214 607 minecraft:sea_lantern
setblock 54 214 609 minecraft:sea_lantern
setblock 54 214 613 minecraft:sea_lantern
setblock 54 214 615 minecraft:sea_lantern
setblock 54 214 617 minecraft:sea_lantern
setblock 54 214 619 minecraft:sea_lantern
setblock 54 214 621 minecraft:sea_lantern
setblock 55 214 606 minecraft:sea_lantern
setblock 55 214 608 minecraft:sea_lantern
setblock 55 214 612 minecraft:sea_lantern
setblock 55 214 614 minecraft:sea_lantern
setblock 55 214 616 minecraft:sea_lantern
setblock 55 214 618 minecraft:sea_lantern
setblock 55 214 620 minecraft:sea_lantern
setblock 55 214 622 minecraft:sea_lantern
setblock 56 214 605 minecraft:sea_lantern
setblock 56 214 607 minecraft:sea_lantern
setblock 56 214 609 minecraft:sea_lantern
setblock 57 214 606 minecraft:sea_lantern
setblock 57 214 608 minecraft:sea_lantern
setblock 58 214 605 minecraft:sea_lantern
setblock 58 214 607 minecraft:sea_lantern
setblock 58 214 609 minecraft:sea_lantern
fill 58 214 646 58 219 646 minecraft:sea_lantern
setblock 59 214 606 minecraft:sea_lantern
setblock 59 214 608 minecraft:sea_lantern
setblock 60 214 605 minecraft:sea_lantern
setblock 60 214 607 minecraft:sea_lantern
setblock 60 214 609 minecraft:sea_lantern
setblock 61 214 606 minecraft:sea_lantern
setblock 61 214 608 minecraft:sea_lantern
fill 62 214 604 62 219 604 minecraft:sea_lantern
fill 63 214 604 68 307 604 minecraft:gray_concrete
fill 66 214 646 66 219 646 minecraft:sea_lantern
fill 70 214 604 70 219 604 minecraft:sea_lantern
fill 74 214 646 74 219 646 minecraft:sea_lantern
fill 78 214 604 78 219 604 minecraft:sea_lantern
setblock 78 214 619 minecraft:sea_lantern
setblock 78 214 621 minecraft:sea_lantern
setblock 78 214 623 minecraft:sea_lantern
setblock 78 214 625 minecraft:sea_lantern
setblock 78 214 627 minecraft:sea_lantern
setblock 78 214 629 minecraft:sea_lantern
setblock 79 214 620 minecraft:sea_lantern
setblock 79 214 622 minecraft:sea_lantern
setblock 79 214 624 minecraft:sea_lantern
setblock 79 214 626 minecraft:sea_lantern
setblock 79 214 628 minecraft:sea_lantern
setblock 80 214 619 minecraft:sea_lantern
setblock 80 214 621 minecraft:sea_lantern
setblock 80 214 623 minecraft:sea_lantern
setblock 80 214 625 minecraft:sea_lantern
setblock 80 214 627 minecraft:sea_lantern
setblock 80 214 629 minecraft:sea_lantern
setblock 81 214 620 minecraft:sea_lantern
setblock 81 214 622 minecraft:sea_lantern
setblock 81 214 624 minecraft:sea_lantern
setblock 81 214 626 minecraft:sea_lantern
setblock 81 214 628 minecraft:sea_lantern
fill 81 214 646 81 307 646 minecraft:gray_concrete
setblock 82 214 619 minecraft:sea_lantern
setblock 82 214 621 minecraft:sea_lantern
setblock 82 214 623 minecraft:sea_lantern
setblock 82 214 625 minecraft:sea_lantern
setblock 82 214 627 minecraft:sea_lantern
setblock 82 214 629 minecraft:sea_lantern
fill 82 214 646 82 219 646 minecraft:sea_lantern
setblock 83 214 620 minecraft:sea_lantern
setblock 83 214 622 minecraft:sea_lantern
setblock 83 214 624 minecraft:sea_lantern
setblock 83 214 626 minecraft:sea_lantern
setblock 83 214 628 minecraft:sea_lantern
fill 83 214 646 83 307 646 minecraft:gray_concrete
setblock 84 214 619 minecraft:sea_lantern
setblock 84 214 621 minecraft:sea_lantern
setblock 84 214 623 minecraft:sea_lantern
setblock 84 214 625 minecraft:sea_lantern
setblock 84 214 627 minecraft:sea_lantern
setblock 84 214 629 minecraft:sea_lantern
setblock 85 214 620 minecraft:sea_lantern
setblock 85 214 622 minecraft:sea_lantern
setblock 85 214 624 minecraft:sea_lantern
setblock 85 214 626 minecraft:sea_lantern
setblock 85 214 628 minecraft:sea_lantern
fill 86 214 604 86 219 604 minecraft:sea_lantern
setblock 86 214 619 minecraft:sea_lantern
setblock 86 214 621 minecraft:sea_lantern
setblock 86 214 623 minecraft:sea_lantern
setblock 86 214 625 minecraft:sea_lantern
setblock 86 214 627 minecraft:sea_lantern
setblock 86 214 629 minecraft:sea_lantern
setblock 87 214 620 minecraft:sea_lantern
setblock 87 214 622 minecraft:sea_lantern
setblock 87 214 624 minecraft:sea_lantern
setblock 87 214 626 minecraft:sea_lantern
setblock 87 214 628 minecraft:sea_lantern
setblock 88 214 619 minecraft:sea_lantern
setblock 88 214 621 minecraft:sea_lantern
setblock 88 214 623 minecraft:sea_lantern
fill 88 214 625 89 214 625 minecraft:sea_lantern
setblock 88 214 627 minecraft:sea_lantern
setblock 88 214 629 minecraft:sea_lantern
fill 89 214 609 89 219 609 minecraft:sea_lantern
fill 89 214 617 89 219 617 minecraft:sea_lantern
fill 89 214 632 89 307 632 minecraft:gray_concrete
fill 89 214 633 89 219 633 minecraft:sea_lantern
fill 89 214 641 89 219 641 minecraft:sea_lantern
fill 47 215 609 47 219 609 minecraft:sea_lantern
fill 47 215 617 47 219 617 minecraft:sea_lantern
fill 48 215 605 48 216 605 minecraft:light_gray_concrete
fill 48 215 607 48 216 607 minecraft:light_gray_concrete
fill 48 215 609 48 216 609 minecraft:light_gray_concrete
fill 48 215 611 48 216 611 minecraft:light_gray_concrete
fill 48 215 613 48 216 613 minecraft:light_gray_concrete
fill 48 215 615 48 216 615 minecraft:light_gray_concrete
fill 48 215 617 48 216 617 minecraft:light_gray_concrete
fill 48 215 619 48 216 619 minecraft:light_gray_concrete
fill 48 215 621 48 216 621 minecraft:light_gray_concrete
fill 49 215 604 49 216 604 minecraft:gray_concrete
fill 49 215 606 49 216 606 minecraft:light_gray_concrete
fill 49 215 608 49 216 608 minecraft:light_gray_concrete
fill 49 215 610 49 216 610 minecraft:light_gray_concrete
fill 49 215 612 49 216 612 minecraft:light_gray_concrete
fill 49 215 614 49 216 614 minecraft:light_gray_concrete
fill 49 215 616 49 216 616 minecraft:light_gray_concrete
fill 49 215 618 49 216 618 minecraft:light_gray_concrete
fill 49 215 620 49 216 620 minecraft:light_gray_concrete
fill 49 215 622 49 216 622 minecraft:light_gray_concrete
fill 50 215 605 50 216 605 minecraft:light_gray_concrete
fill 50 215 607 50 216 607 minecraft:light_gray_concrete
fill 50 215 609 50 216 609 minecraft:light_gray_concrete
fill 50 215 611 50 216 611 minecraft:light_gray_concrete
fill 50 215 613 50 216 613 minecraft:light_gray_concrete
fill 50 215 615 50 216 615 minecraft:light_gray_concrete
fill 50 215 617 50 216 617 minecraft:light_gray_concrete
fill 50 215 619 50 216 619 minecraft:light_gray_concrete
fill 50 215 621 50 216 621 minecraft:light_gray_concrete
fill 51 215 604 51 216 604 minecraft:gray_concrete
fill 51 215 606 51 216 606 minecraft:light_gray_concrete
fill 51 215 608 51 216 608 minecraft:light_gray_concrete
fill 51 215 610 51 216 610 minecraft:light_gray_concrete
fill 51 215 612 51 216 612 minecraft:light_gray_concrete
fill 51 215 614 51 216 614 minecraft:light_gray_concrete
fill 51 215 616 51 216 616 minecraft:light_gray_concrete
fill 51 215 618 51 216 618 minecraft:light_gray_concrete
fill 51 215 620 51 216 620 minecraft:light_gray_concrete
fill 51 215 622 51 216 622 minecraft:light_gray_concrete
fill 52 215 605 52 216 605 minecraft:light_gray_concrete
fill 52 215 607 52 216 607 minecraft:light_gray_concrete
fill 52 215 609 52 216 609 minecraft:light_gray_concrete
fill 52 215 611 52 216 611 minecraft:light_gray_concrete
fill 52 215 613 52 216 613 minecraft:light_gray_concrete
fill 52 215 615 52 216 615 minecraft:light_gray_concrete
fill 52 215 617 52 216 617 minecraft:light_gray_concrete
fill 52 215 619 52 216 619 minecraft:light_gray_concrete
fill 52 215 621 52 216 621 minecraft:light_gray_concrete
fill 53 215 606 53 216 606 minecraft:light_gray_concrete
fill 53 215 608 53 216 608 minecraft:light_gray_concrete
fill 53 215 612 53 216 612 minecraft:light_gray_concrete
fill 53 215 614 53 216 614 minecraft:light_gray_concrete
fill 53 215 616 53 216 616 minecraft:light_gray_concrete
fill 53 215 618 53 216 618 minecraft:light_gray_concrete
fill 53 215 620 53 216 620 minecraft:light_gray_concrete
fill 53 215 622 53 216 622 minecraft:light_gray_concrete
fill 54 215 604 54 219 604 minecraft:sea_lantern
fill 54 215 605 54 216 605 minecraft:light_gray_concrete
fill 54 215 607 54 216 607 minecraft:light_gray_concrete
fill 54 215 609 54 216 609 minecraft:light_gray_concrete
fill 54 215 613 54 216 613 minecraft:light_gray_concrete
fill 54 215 615 54 216 615 minecraft:light_gray_concrete
fill 54 215 617 54 216 617 minecraft:light_gray_concrete
fill 54 215 619 54 216 619 minecraft:light_gray_concrete
fill 54 215 621 54 216 621 minecraft:light_gray_concrete
fill 55 215 606 55 216 606 minecraft:light_gray_concrete
fill 55 215 608 55 216 608 minecraft:light_gray_concrete
fill 55 215 612 55 216 612 minecraft:light_gray_concrete
fill 55 215 614 55 216 614 minecraft:light_gray_concrete
fill 55 215 616 55 216 616 minecraft:light_gray_concrete
fill 55 215 618 55 216 618 minecraft:light_gray_concrete
fill 55 215 620 55 216 620 minecraft:light_gray_concrete
fill 55 215 622 55 216 622 minecraft:light_gray_concrete
fill 56 215 605 56 216 605 minecraft:light_gray_concrete
fill 56 215 607 56 216 607 minecraft:light_gray_concrete
fill 56 215 609 56 216 609 minecraft:light_gray_concrete
fill 57 215 606 57 216 606 minecraft:light_gray_concrete
fill 57 215 608 57 216 608 minecraft:light_gray_concrete
fill 58 215 605 58 216 605 minecraft:light_gray_concrete
fill 58 215 607 58 216 607 minecraft:light_gray_concrete
fill 58 215 609 58 216 609 minecraft:light_gray_concrete
fill 59 215 606 59 216 606 minecraft:light_gray_concrete
fill 59 215 608 59 216 608 minecraft:light_gray_concrete
fill 60 215 605 60 216 605 minecraft:light_gray_concrete
fill 60 215 607 60 216 607 minecraft:light_gray_concrete
fill 60 215 609 60 216 609 minecraft:light_gray_concrete
fill 61 215 606 61 216 606 minecraft:light_gray_concrete
fill 61 215 608 61 216 608 minecraft:light_gray_concrete
fill 78 215 619 78 216 619 minecraft:light_gray_concrete
fill 78 215 621 78 216 621 minecraft:light_gray_concrete
fill 78 215 623 78 216 623 minecraft:light_gray_concrete
fill 78 215 625 78 216 625 minecraft:light_gray_concrete
fill 78 215 627 78 216 627 minecraft:light_gray_concrete
fill 78 215 629 78 216 629 minecraft:light_gray_concrete
fill 79 215 620 79 216 620 minecraft:light_gray_concrete
fill 79 215 622 79 216 622 minecraft:light_gray_concrete
fill 79 215 624 79 216 624 minecraft:light_gray_concrete
fill 79 215 626 79 216 626 minecraft:light_gray_concrete
fill 79 215 628 79 216 628 minecraft:light_gray_concrete
fill 80 215 619 80 216 619 minecraft:light_gray_concrete
fill 80 215 621 80 216 621 minecraft:light_gray_concrete
fill 80 215 623 80 216 623 minecraft:light_gray_concrete
fill 80 215 625 80 216 625 minecraft:light_gray_concrete
fill 80 215 627 80 216 627 minecraft:light_gray_concrete
fill 80 215 629 80 216 629 minecraft:light_gray_concrete
fill 81 215 620 81 216 620 minecraft:light_gray_concrete
fill 81 215 622 81 216 622 minecraft:light_gray_concrete
fill 81 215 624 81 216 624 minecraft:light_gray_concrete
fill 81 215 626 81 216 626 minecraft:light_gray_concrete
fill 81 215 628 81 216 628 minecraft:light_gray_concrete
fill 82 215 619 82 216 619 minecraft:light_gray_concrete
fill 82 215 621 82 216 621 minecraft:light_gray_concrete
fill 82 215 623 82 216 623 minecraft:light_gray_concrete
fill 82 215 625 82 216 625 minecraft:light_gray_concrete
fill 82 215 627 82 216 627 minecraft:light_gray_concrete
fill 82 215 629 82 216 629 minecraft:light_gray_concrete
fill 83 215 620 83 216 620 minecraft:light_gray_concrete
fill 83 215 622 83 216 622 minecraft:light_gray_concrete
fill 83 215 624 83 216 624 minecraft:light_gray_concrete
fill 83 215 626 83 216 626 minecraft:light_gray_concrete
fill 83 215 628 83 216 628 minecraft:light_gray_concrete
fill 84 215 619 84 216 619 minecraft:light_gray_concrete
fill 84 215 621 84 216 621 minecraft:light_gray_concrete
fill 84 215 623 84 216 623 minecraft:light_gray_concrete
fill 84 215 625 84 216 625 minecraft:light_gray_concrete
fill 84 215 627 84 216 627 minecraft:light_gray_concrete
fill 84 215 629 84 216 629 minecraft:light_gray_concrete
fill 85 215 620 85 216 620 minecraft:light_gray_concrete
fill 85 215 622 85 216 622 minecraft:light_gray_concrete
fill 85 215 624 85 216 624 minecraft:light_gray_concrete
fill 85 215 626 85 216 626 minecraft:light_gray_concrete
fill 85 215 628 85 216 628 minecraft:light_gray_concrete
fill 86 215 619 86 216 619 minecraft:light_gray_concrete
fill 86 215 621 86 216 621 minecraft:light_gray_concrete
fill 86 215 623 86 216 623 minecraft:light_gray_concrete
fill 86 215 625 86 216 625 minecraft:light_gray_concrete
fill 86 215 627 86 216 627 minecraft:light_gray_concrete
fill 86 215 629 86 216 629 minecraft:light_gray_concrete
fill 87 215 620 87 216 620 minecraft:light_gray_concrete
fill 87 215 622 87 216 622 minecraft:light_gray_concrete
fill 87 215 624 87 216 624 minecraft:light_gray_concrete
fill 87 215 626 87 216 626 minecraft:light_gray_concrete
fill 87 215 628 87 216 628 minecraft:light_gray_concrete
fill 88 215 619 88 216 619 minecraft:light_gray_concrete
fill 88 215 621 88 216 621 minecraft:light_gray_concrete
fill 88 215 623 88 216 623 minecraft:light_gray_concrete
fill 88 215 625 88 216 625 minecraft:light_gray_concrete
fill 88 215 627 88 216 627 minecraft:light_gray_concrete
fill 88 215 629 88 216 629 minecraft:light_gray_concrete
fill 89 215 625 89 219 625 minecraft:sea_lantern
setblock 50 216 623 minecraft:light[level=14]
setblock 50 216 631 minecraft:light[level=14]
setblock 50 216 639 minecraft:light[level=14]
setblock 58 216 615 minecraft:light[level=14]
setblock 58 216 623 minecraft:light[level=14]
setblock 58 216 631 minecraft:light[level=14]
setblock 58 216 639 minecraft:light[level=14]
setblock 66 216 607 minecraft:light[level=14]
setblock 66 216 615 minecraft:light[level=14]
setblock 66 216 631 minecraft:light[level=14]
setblock 66 216 639 minecraft:light[level=14]
setblock 74 216 607 minecraft:light[level=14]
setblock 74 216 615 minecraft:light[level=14]
setblock 74 216 623 minecraft:light[level=14]
setblock 74 216 631 minecraft:light[level=14]
setblock 74 216 639 minecraft:light[level=14]
setblock 82 216 607 minecraft:light[level=14]
setblock 82 216 615 minecraft:light[level=14]
setblock 82 216 631 minecraft:light[level=14]
setblock 82 216 639 minecraft:light[level=14]
setblock 48 217 605 minecraft:sea_lantern
setblock 48 217 607 minecraft:sea_lantern
setblock 48 217 609 minecraft:sea_lantern
schedule function dropper:buildpart/145_3 1t
