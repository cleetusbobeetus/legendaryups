setblock 88 300 591 minecraft:cobbled_deepslate
setblock 88 300 595 minecraft:calcite
setblock 88 300 596 minecraft:cobbled_deepslate
