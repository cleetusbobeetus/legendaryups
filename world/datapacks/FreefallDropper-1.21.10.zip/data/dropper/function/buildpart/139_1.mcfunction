fill 370 59 567 370 62 567 minecraft:green_terracotta
setblock 370 59 571 minecraft:oak_log
fill 370 59 572 370 62 572 minecraft:green_terracotta
fill 370 59 574 370 60 574 minecraft:green_terracotta
setblock 370 59 581 minecraft:oak_log
fill 370 59 582 370 60 582 minecraft:green_terracotta
setblock 370 59 586 minecraft:oak_log
fill 370 59 587 370 62 587 minecraft:green_terracotta
setblock 370 59 591 minecraft:oak_log
fill 370 59 592 370 62 592 minecraft:green_terracotta
setblock 370 59 596 minecraft:oak_log
fill 370 59 597 370 62 597 minecraft:green_terracotta
setblock 330 60 560 minecraft:oak_log
setblock 330 60 561 minecraft:green_terracotta
setblock 330 60 565 minecraft:oak_log
fill 330 60 566 330 63 566 minecraft:green_terracotta
setblock 330 60 570 minecraft:oak_log
fill 330 60 571 330 63 571 minecraft:green_terracotta
setblock 330 60 575 minecraft:oak_log
fill 330 60 576 330 60 579 minecraft:green_terracotta
setblock 330 60 580 minecraft:oak_log
fill 330 60 581 330 60 584 minecraft:green_terracotta
setblock 330 60 585 minecraft:oak_log
fill 330 60 586 330 60 589 minecraft:green_terracotta
setblock 330 60 590 minecraft:oak_log
fill 330 60 591 330 63 591 minecraft:green_terracotta
setblock 330 60 595 minecraft:oak_log
fill 330 60 596 330 63 596 minecraft:green_terracotta
setblock 331 60 565 minecraft:green_terracotta
setblock 331 60 569 minecraft:oak_log
fill 331 60 570 331 61 570 minecraft:green_terracotta
setblock 331 60 584 minecraft:oak_log
fill 331 60 585 331 60 588 minecraft:green_terracotta
setblock 331 60 589 minecraft:oak_log
fill 331 60 590 331 63 590 minecraft:green_terracotta
setblock 331 60 594 minecraft:oak_log
fill 331 60 595 331 63 595 minecraft:green_terracotta
setblock 332 60 588 minecraft:oak_log
fill 332 60 589 332 63 589 minecraft:green_terracotta
setblock 332 60 593 minecraft:oak_log
fill 332 60 594 332 61 594 minecraft:green_terracotta
setblock 332 60 598 minecraft:oak_log
fill 333 60 598 333 61 598 minecraft:green_terracotta
setblock 336 60 558 minecraft:oak_leaves[persistent=true]
setblock 339 60 598 minecraft:oak_leaves[persistent=true]
setblock 352 60 558 minecraft:oak_log
setblock 361 60 558 minecraft:oak_leaves[persistent=true]
setblock 363 60 558 minecraft:green_terracotta
setblock 364 60 598 minecraft:oak_leaves[persistent=true]
setblock 366 60 559 minecraft:oak_log
setblock 367 60 558 minecraft:oak_log
fill 367 60 559 367 61 559 minecraft:green_terracotta
setblock 367 60 598 minecraft:oak_log
fill 368 60 558 368 63 558 minecraft:green_terracotta
setblock 368 60 563 minecraft:green_terracotta
setblock 368 60 567 minecraft:oak_log
fill 368 60 568 368 61 568 minecraft:green_terracotta
fill 368 60 588 368 60 591 minecraft:green_terracotta
setblock 368 60 592 minecraft:oak_log
fill 368 60 593 368 62 594 minecraft:green_terracotta
setblock 368 60 597 minecraft:oak_log
fill 368 60 598 368 63 598 minecraft:green_terracotta
setblock 369 60 561 minecraft:oak_log
fill 369 60 562 369 61 562 minecraft:green_terracotta
setblock 369 60 566 minecraft:oak_log
fill 369 60 567 369 63 567 minecraft:green_terracotta
setblock 369 60 571 minecraft:oak_log
fill 369 60 572 369 61 572 minecraft:green_terracotta
setblock 369 60 586 minecraft:oak_log
fill 369 60 587 369 63 587 minecraft:green_terracotta
setblock 369 60 590 minecraft:green_terracotta
setblock 369 60 591 minecraft:oak_log
fill 369 60 592 369 63 592 minecraft:green_terracotta
setblock 369 60 596 minecraft:oak_log
fill 369 60 597 369 63 597 minecraft:green_terracotta
setblock 370 60 560 minecraft:oak_log
fill 370 60 561 370 63 561 minecraft:green_terracotta
setblock 370 60 565 minecraft:oak_log
fill 370 60 566 370 63 566 minecraft:green_terracotta
setblock 370 60 570 minecraft:oak_log
fill 370 60 571 370 63 571 minecraft:green_terracotta
setblock 370 60 585 minecraft:oak_log
fill 370 60 586 370 63 586 minecraft:green_terracotta
setblock 370 60 590 minecraft:oak_log
fill 370 60 591 370 63 591 minecraft:green_terracotta
setblock 370 60 595 minecraft:oak_log
fill 370 60 596 370 63 596 minecraft:green_terracotta
setblock 330 61 564 minecraft:oak_log
fill 330 61 565 330 62 565 minecraft:green_terracotta
setblock 330 61 569 minecraft:oak_log
fill 330 61 570 330 64 570 minecraft:green_terracotta
setblock 330 61 574 minecraft:oak_log
fill 330 61 575 330 63 576 minecraft:green_terracotta
setblock 330 61 579 minecraft:oak_log
fill 330 61 580 330 61 583 minecraft:green_terracotta
setblock 330 61 584 minecraft:oak_log
fill 330 61 585 330 61 588 minecraft:green_terracotta
setblock 330 61 589 minecraft:oak_log
fill 330 61 590 330 64 590 minecraft:green_terracotta
setblock 330 61 594 minecraft:oak_log
fill 330 61 595 330 64 595 minecraft:green_terracotta
fill 331 61 565 331 81 566 minecraft:oak_log
setblock 331 61 568 minecraft:oak_log
setblock 331 61 569 minecraft:green_terracotta
setblock 331 61 583 minecraft:oak_log
fill 331 61 584 331 61 587 minecraft:green_terracotta
setblock 331 61 588 minecraft:oak_log
fill 331 61 589 331 64 589 minecraft:green_terracotta
setblock 331 61 593 minecraft:oak_log
fill 331 61 594 331 64 594 minecraft:green_terracotta
setblock 331 61 598 minecraft:oak_log
setblock 332 61 587 minecraft:oak_log
fill 332 61 588 332 62 588 minecraft:green_terracotta
setblock 332 61 592 minecraft:oak_log
fill 332 61 593 332 63 593 minecraft:green_terracotta
fill 332 61 598 332 64 598 minecraft:green_terracotta
fill 341 61 588 341 62 588 minecraft:glowstone
setblock 345 61 598 minecraft:oak_leaves[persistent=true]
setblock 355 61 558 minecraft:oak_leaves[persistent=true]
fill 357 61 581 358 62 582 minecraft:oak_leaves[persistent=true]
fill 359 61 581 359 62 581 minecraft:oak_leaves[persistent=true]
fill 364 61 598 364 62 598 minecraft:green_terracotta
setblock 366 61 558 minecraft:oak_log
setblock 366 61 597 minecraft:green_terracotta
setblock 366 61 598 minecraft:oak_log
fill 367 61 558 367 64 558 minecraft:green_terracotta
setblock 367 61 597 minecraft:oak_log
fill 367 61 598 367 64 598 minecraft:green_terracotta
setblock 368 61 566 minecraft:oak_log
setblock 368 61 567 minecraft:green_terracotta
fill 368 61 589 368 61 590 minecraft:green_terracotta
setblock 368 61 591 minecraft:oak_log
fill 368 61 592 368 64 592 minecraft:green_terracotta
setblock 368 61 595 minecraft:green_terracotta
fill 368 61 597 368 64 597 minecraft:green_terracotta
setblock 369 61 560 minecraft:oak_log
setblock 369 61 561 minecraft:green_terracotta
setblock 369 61 565 minecraft:oak_log
fill 369 61 566 369 63 566 minecraft:green_terracotta
setblock 369 61 570 minecraft:oak_log
fill 369 61 571 369 64 571 minecraft:green_terracotta
fill 369 61 586 369 62 586 minecraft:green_terracotta
setblock 369 61 590 minecraft:oak_log
fill 369 61 591 369 64 591 minecraft:green_terracotta
setblock 369 61 595 minecraft:oak_log
fill 369 61 596 369 64 596 minecraft:green_terracotta
setblock 370 61 559 minecraft:oak_log
fill 370 61 560 370 63 560 minecraft:green_terracotta
setblock 370 61 564 minecraft:oak_log
fill 370 61 565 370 64 565 minecraft:green_terracotta
setblock 370 61 569 minecraft:oak_log
fill 370 61 570 370 64 570 minecraft:green_terracotta
setblock 370 61 574 minecraft:oak_log
setblock 370 61 584 minecraft:oak_log
fill 370 61 585 370 64 585 minecraft:green_terracotta
setblock 370 61 589 minecraft:oak_log
fill 370 61 590 370 64 590 minecraft:green_terracotta
setblock 370 61 594 minecraft:oak_log
fill 370 61 595 370 64 595 minecraft:green_terracotta
setblock 330 62 564 minecraft:green_terracotta
setblock 330 62 568 minecraft:oak_log
fill 330 62 569 330 65 569 minecraft:green_terracotta
setblock 330 62 573 minecraft:oak_log
fill 330 62 574 330 65 574 minecraft:green_terracotta
fill 330 62 580 330 62 582 minecraft:green_terracotta
setblock 330 62 583 minecraft:oak_log
fill 330 62 584 330 62 587 minecraft:green_terracotta
setblock 330 62 588 minecraft:oak_log
fill 330 62 589 330 65 589 minecraft:green_terracotta
setblock 330 62 593 minecraft:oak_log
fill 330 62 594 330 65 594 minecraft:green_terracotta
setblock 330 62 598 minecraft:oak_log
fill 331 62 584 331 62 586 minecraft:green_terracotta
setblock 331 62 587 minecraft:oak_log
fill 331 62 588 331 65 588 minecraft:green_terracotta
setblock 331 62 592 minecraft:oak_log
fill 331 62 593 331 65 593 minecraft:green_terracotta
setblock 331 62 597 minecraft:oak_log
fill 331 62 598 331 65 598 minecraft:green_terracotta
setblock 332 62 591 minecraft:oak_log
fill 332 62 592 332 64 592 minecraft:green_terracotta
fill 345 62 591 345 72 591 minecraft:iron_block
setblock 349 62 558 minecraft:oak_leaves[persistent=true]
setblock 351 62 598 minecraft:oak_leaves[persistent=true]
fill 363 62 558 363 63 558 minecraft:green_terracotta
setblock 365 62 558 minecraft:oak_log
setblock 365 62 597 minecraft:green_terracotta
setblock 365 62 598 minecraft:oak_log
fill 366 62 558 366 65 558 minecraft:green_terracotta
setblock 366 62 597 minecraft:oak_log
fill 366 62 598 366 65 598 minecraft:green_terracotta
fill 367 62 597 367 65 597 minecraft:green_terracotta
setblock 368 62 589 minecraft:green_terracotta
setblock 368 62 590 minecraft:oak_log
fill 368 62 591 368 65 591 minecraft:green_terracotta
setblock 368 62 595 minecraft:oak_log
fill 368 62 596 368 65 596 minecraft:green_terracotta
setblock 369 62 564 minecraft:oak_log
fill 369 62 565 369 63 565 minecraft:green_terracotta
setblock 369 62 569 minecraft:oak_log
fill 369 62 570 369 65 570 minecraft:green_terracotta
setblock 369 62 589 minecraft:oak_log
fill 369 62 590 369 65 590 minecraft:green_terracotta
setblock 369 62 594 minecraft:oak_log
fill 369 62 595 369 65 595 minecraft:green_terracotta
setblock 370 62 558 minecraft:oak_log
fill 370 62 559 370 65 559 minecraft:green_terracotta
setblock 370 62 563 minecraft:oak_log
fill 370 62 564 370 64 564 minecraft:green_terracotta
setblock 370 62 568 minecraft:oak_log
fill 370 62 569 370 65 569 minecraft:green_terracotta
setblock 370 62 573 minecraft:oak_log
fill 370 62 574 370 65 574 minecraft:green_terracotta
setblock 370 62 581 minecraft:oak_leaves[persistent=true]
setblock 370 62 584 minecraft:green_terracotta
setblock 370 62 588 minecraft:oak_log
fill 370 62 589 370 65 589 minecraft:green_terracotta
setblock 370 62 593 minecraft:oak_log
fill 370 62 594 370 65 594 minecraft:green_terracotta
setblock 370 62 598 minecraft:oak_log
setblock 330 63 562 minecraft:oak_leaves[persistent=true]
setblock 330 63 567 minecraft:oak_log
fill 330 63 568 330 66 568 minecraft:green_terracotta
setblock 330 63 572 minecraft:oak_log
fill 330 63 573 330 66 573 minecraft:green_terracotta
setblock 330 63 577 minecraft:oak_log
setblock 330 63 581 minecraft:green_terracotta
setblock 330 63 582 minecraft:oak_log
fill 330 63 583 330 63 586 minecraft:green_terracotta
setblock 330 63 587 minecraft:oak_log
fill 330 63 588 330 66 588 minecraft:green_terracotta
setblock 330 63 592 minecraft:oak_log
fill 330 63 593 330 66 593 minecraft:green_terracotta
setblock 330 63 597 minecraft:oak_log
fill 330 63 598 330 66 598 minecraft:green_terracotta
setblock 331 63 585 minecraft:green_terracotta
setblock 331 63 586 minecraft:oak_log
fill 331 63 587 331 66 587 minecraft:green_terracotta
setblock 331 63 591 minecraft:oak_log
fill 331 63 592 331 66 592 minecraft:green_terracotta
setblock 331 63 596 minecraft:oak_log
fill 331 63 597 331 66 597 minecraft:green_terracotta
setblock 332 63 590 minecraft:oak_log
fill 332 63 591 332 64 591 minecraft:green_terracotta
fill 335 63 583 335 64 583 minecraft:glowstone
setblock 338 63 598 minecraft:oak_leaves[persistent=true]
fill 341 63 588 341 73 588 minecraft:dark_oak_log
setblock 343 63 558 minecraft:oak_leaves[persistent=true]
setblock 357 63 598 minecraft:oak_leaves[persistent=true]
setblock 362 63 558 minecraft:oak_leaves[persistent=true]
setblock 363 63 598 minecraft:green_terracotta
setblock 364 63 558 minecraft:oak_log
setblock 364 63 597 minecraft:green_terracotta
setblock 364 63 598 minecraft:oak_log
fill 365 63 558 365 66 558 minecraft:green_terracotta
setblock 365 63 597 minecraft:oak_log
fill 365 63 598 365 66 598 minecraft:green_terracotta
setblock 366 63 596 minecraft:oak_log
fill 366 63 597 366 66 597 minecraft:green_terracotta
fill 367 63 596 367 66 596 minecraft:green_terracotta
setblock 368 63 589 minecraft:oak_log
fill 368 63 590 368 66 590 minecraft:green_terracotta
setblock 368 63 593 minecraft:green_terracotta
setblock 368 63 594 minecraft:oak_log
fill 368 63 595 368 66 595 minecraft:green_terracotta
setblock 369 63 558 minecraft:oak_log
setblock 369 63 568 minecraft:oak_log
fill 369 63 569 369 65 569 minecraft:green_terracotta
setblock 369 63 588 minecraft:oak_log
fill 369 63 589 369 66 589 minecraft:green_terracotta
setblock 369 63 593 minecraft:oak_log
fill 369 63 594 369 66 594 minecraft:green_terracotta
setblock 369 63 598 minecraft:oak_log
fill 370 63 558 370 66 558 minecraft:green_terracotta
setblock 370 63 562 minecraft:oak_log
setblock 370 63 563 minecraft:green_terracotta
setblock 370 63 567 minecraft:oak_log
fill 370 63 568 370 66 568 minecraft:green_terracotta
setblock 370 63 572 minecraft:oak_log
fill 370 63 573 370 66 573 minecraft:green_terracotta
setblock 370 63 575 minecraft:oak_leaves[persistent=true]
setblock 370 63 587 minecraft:oak_log
fill 370 63 588 370 66 588 minecraft:green_terracotta
setblock 370 63 592 minecraft:oak_log
fill 370 63 593 370 66 593 minecraft:green_terracotta
setblock 370 63 597 minecraft:oak_log
fill 370 63 598 370 66 598 minecraft:green_terracotta
setblock 330 64 567 minecraft:green_terracotta
setblock 330 64 571 minecraft:oak_log
fill 330 64 572 330 67 572 minecraft:green_terracotta
setblock 330 64 575 minecraft:green_terracotta
setblock 330 64 576 minecraft:oak_log
fill 330 64 577 330 64 580 minecraft:green_terracotta
setblock 330 64 581 minecraft:oak_log
fill 330 64 582 330 64 585 minecraft:green_terracotta
setblock 330 64 586 minecraft:oak_log
fill 330 64 587 330 67 587 minecraft:green_terracotta
setblock 330 64 591 minecraft:oak_log
fill 330 64 592 330 67 592 minecraft:green_terracotta
setblock 330 64 596 minecraft:oak_log
fill 330 64 597 330 67 597 minecraft:green_terracotta
fill 331 64 558 331 65 558 minecraft:oak_leaves[persistent=true]
setblock 331 64 586 minecraft:green_terracotta
setblock 331 64 590 minecraft:oak_log
fill 331 64 591 331 67 591 minecraft:green_terracotta
setblock 331 64 595 minecraft:oak_log
fill 331 64 596 331 67 596 minecraft:green_terracotta
setblock 337 64 558 minecraft:oak_leaves[persistent=true]
setblock 344 64 598 minecraft:oak_leaves[persistent=true]
setblock 356 64 558 minecraft:oak_leaves[persistent=true]
fill 361 64 598 362 64 598 minecraft:green_terracotta
setblock 362 64 558 minecraft:green_terracotta
setblock 363 64 558 minecraft:oak_log
setblock 363 64 597 minecraft:green_terracotta
setblock 363 64 598 minecraft:oak_log
fill 364 64 558 364 67 558 minecraft:green_terracotta
setblock 364 64 597 minecraft:oak_log
fill 364 64 598 364 67 598 minecraft:green_terracotta
setblock 365 64 596 minecraft:oak_log
fill 365 64 597 365 67 597 minecraft:green_terracotta
fill 366 64 596 366 67 596 minecraft:green_terracotta
setblock 368 64 558 minecraft:oak_log
setblock 368 64 593 minecraft:oak_log
fill 368 64 594 368 67 594 minecraft:green_terracotta
setblock 368 64 598 minecraft:oak_log
fill 369 64 558 369 67 558 minecraft:green_terracotta
setblock 369 64 567 minecraft:oak_log
setblock 369 64 568 minecraft:green_terracotta
setblock 369 64 572 minecraft:oak_log
setblock 369 64 587 minecraft:oak_log
fill 369 64 588 369 67 588 minecraft:green_terracotta
setblock 369 64 592 minecraft:oak_log
fill 369 64 593 369 67 593 minecraft:green_terracotta
setblock 369 64 597 minecraft:oak_log
fill 369 64 598 369 67 598 minecraft:green_terracotta
setblock 370 64 566 minecraft:oak_log
fill 370 64 567 370 66 567 minecraft:green_terracotta
setblock 370 64 571 minecraft:oak_log
fill 370 64 572 370 67 572 minecraft:green_terracotta
setblock 370 64 575 minecraft:green_terracotta
setblock 370 64 586 minecraft:oak_log
fill 370 64 587 370 67 587 minecraft:green_terracotta
setblock 370 64 591 minecraft:oak_log
fill 370 64 592 370 67 592 minecraft:green_terracotta
setblock 370 64 596 minecraft:oak_log
fill 370 64 597 370 67 597 minecraft:green_terracotta
setblock 330 65 570 minecraft:oak_log
fill 330 65 571 330 68 571 minecraft:green_terracotta
setblock 330 65 575 minecraft:oak_log
fill 330 65 576 330 65 579 minecraft:green_terracotta
setblock 330 65 580 minecraft:oak_log
fill 330 65 581 330 65 584 minecraft:green_terracotta
setblock 330 65 585 minecraft:oak_log
fill 330 65 586 330 68 586 minecraft:green_terracotta
setblock 330 65 590 minecraft:oak_log
fill 330 65 591 330 68 591 minecraft:green_terracotta
setblock 330 65 595 minecraft:oak_log
fill 330 65 596 330 68 596 minecraft:green_terracotta
setblock 331 65 589 minecraft:oak_log
fill 331 65 590 331 68 590 minecraft:green_terracotta
setblock 331 65 594 minecraft:oak_log
fill 331 65 595 331 68 595 minecraft:green_terracotta
setblock 332 65 560 minecraft:light[level=14]
setblock 332 65 568 minecraft:light[level=14]
setblock 332 65 576 minecraft:light[level=14]
setblock 332 65 584 minecraft:light[level=14]
setblock 332 65 592 minecraft:light[level=14]
setblock 332 65 598 minecraft:oak_log
fill 335 65 582 335 73 583 minecraft:dark_oak_log
fill 339 65 585 339 66 586 minecraft:glowstone
setblock 340 65 560 minecraft:light[level=14]
setblock 340 65 568 minecraft:light[level=14]
setblock 340 65 576 minecraft:light[level=14]
setblock 340 65 584 minecraft:light[level=14]
setblock 340 65 592 minecraft:light[level=14]
fill 341 65 587 342 73 587 minecraft:dark_oak_log
fill 341 65 589 341 73 589 minecraft:dark_oak_log
fill 342 65 588 342 73 588 minecraft:dark_oak_log
fill 344 65 598 346 65 598 minecraft:green_terracotta
setblock 346 65 558 minecraft:green_terracotta
setblock 347 65 558 minecraft:oak_log
setblock 347 65 598 minecraft:oak_log
fill 348 65 558 350 66 558 minecraft:green_terracotta
setblock 348 65 560 minecraft:light[level=14]
setblock 348 65 568 minecraft:light[level=14]
setblock 348 65 576 minecraft:light[level=14]
setblock 348 65 584 minecraft:light[level=14]
setblock 348 65 592 minecraft:light[level=14]
fill 348 65 598 349 67 598 minecraft:green_terracotta
setblock 350 65 598 minecraft:oak_leaves[persistent=true]
setblock 356 65 560 minecraft:light[level=14]
setblock 356 65 568 minecraft:light[level=14]
setblock 356 65 576 minecraft:light[level=14]
setblock 356 65 584 minecraft:light[level=14]
setblock 356 65 592 minecraft:light[level=14]
fill 360 65 598 361 65 598 minecraft:green_terracotta
setblock 361 65 558 minecraft:green_terracotta
setblock 362 65 558 minecraft:oak_log
setblock 362 65 597 minecraft:green_terracotta
setblock 362 65 598 minecraft:oak_log
fill 363 65 558 363 68 558 minecraft:green_terracotta
setblock 363 65 597 minecraft:oak_log
fill 363 65 598 363 68 598 minecraft:green_terracotta
setblock 364 65 560 minecraft:light[level=14]
setblock 364 65 568 minecraft:light[level=14]
setblock 364 65 576 minecraft:light[level=14]
setblock 364 65 584 minecraft:light[level=14]
setblock 364 65 592 minecraft:light[level=14]
setblock 364 65 596 minecraft:oak_log
fill 364 65 597 364 68 597 minecraft:green_terracotta
setblock 365 65 559 minecraft:green_terracotta
fill 365 65 596 365 68 596 minecraft:green_terracotta
setblock 366 65 559 minecraft:oak_log
setblock 367 65 558 minecraft:oak_log
setblock 367 65 593 minecraft:oak_log
fill 367 65 594 367 67 595 minecraft:green_terracotta
setblock 367 65 598 minecraft:oak_log
fill 368 65 558 368 68 558 minecraft:green_terracotta
setblock 368 65 592 minecraft:oak_log
fill 368 65 593 368 68 593 minecraft:green_terracotta
setblock 368 65 597 minecraft:oak_log
fill 368 65 598 368 68 598 minecraft:green_terracotta
setblock 369 65 571 minecraft:oak_log
fill 369 65 572 369 68 572 minecraft:green_terracotta
setblock 369 65 591 minecraft:oak_log
fill 369 65 592 369 68 592 minecraft:green_terracotta
setblock 369 65 596 minecraft:oak_log
fill 369 65 597 369 68 597 minecraft:green_terracotta
setblock 370 65 563 minecraft:oak_leaves[persistent=true]
setblock 370 65 566 minecraft:green_terracotta
setblock 370 65 570 minecraft:oak_log
fill 370 65 571 370 68 571 minecraft:green_terracotta
setblock 370 65 575 minecraft:oak_log
fill 370 65 576 370 68 576 minecraft:green_terracotta
setblock 370 65 582 minecraft:oak_leaves[persistent=true]
setblock 370 65 585 minecraft:oak_log
fill 370 65 586 370 68 586 minecraft:green_terracotta
setblock 370 65 590 minecraft:oak_log
fill 370 65 591 370 68 591 minecraft:green_terracotta
setblock 370 65 595 minecraft:oak_log
fill 370 65 596 370 68 596 minecraft:green_terracotta
setblock 330 66 569 minecraft:oak_log
fill 330 66 570 330 69 570 minecraft:green_terracotta
setblock 330 66 574 minecraft:oak_log
fill 330 66 575 330 66 578 minecraft:green_terracotta
setblock 330 66 579 minecraft:oak_log
fill 330 66 580 330 66 583 minecraft:green_terracotta
setblock 330 66 584 minecraft:oak_log
fill 330 66 585 330 69 585 minecraft:green_terracotta
setblock 330 66 589 minecraft:oak_log
fill 330 66 590 330 69 590 minecraft:green_terracotta
setblock 330 66 594 minecraft:oak_log
fill 330 66 595 330 69 595 minecraft:green_terracotta
setblock 331 66 573 minecraft:oak_log
fill 331 66 574 331 68 575 minecraft:green_terracotta
setblock 331 66 588 minecraft:oak_log
fill 331 66 589 331 68 589 minecraft:green_terracotta
setblock 331 66 593 minecraft:oak_log
fill 331 66 594 331 69 594 minecraft:green_terracotta
setblock 331 66 598 minecraft:oak_log
fill 332 66 598 332 69 598 minecraft:green_terracotta
fill 334 66 583 334 73 583 minecraft:dark_oak_log
fill 340 66 587 340 73 589 minecraft:dark_oak_log
fill 342 66 589 342 73 589 minecraft:dark_oak_log
fill 342 66 598 345 66 598 minecraft:green_terracotta
fill 344 66 558 345 66 558 minecraft:green_terracotta
fill 345 66 597 346 66 597 minecraft:green_terracotta
setblock 346 66 558 minecraft:oak_log
setblock 346 66 598 minecraft:oak_log
fill 347 66 558 347 69 558 minecraft:green_terracotta
setblock 347 66 597 minecraft:oak_log
fill 347 66 598 347 69 598 minecraft:green_terracotta
setblock 350 66 598 minecraft:green_terracotta
setblock 351 66 558 minecraft:oak_log
setblock 351 66 598 minecraft:oak_log
setblock 356 66 598 minecraft:oak_leaves[persistent=true]
fill 358 66 598 360 66 598 minecraft:green_terracotta
fill 359 66 558 360 66 558 minecraft:green_terracotta
fill 360 66 597 361 66 597 minecraft:green_terracotta
setblock 361 66 558 minecraft:oak_log
setblock 361 66 598 minecraft:oak_log
fill 362 66 558 362 69 558 minecraft:green_terracotta
setblock 362 66 596 minecraft:green_terracotta
setblock 362 66 597 minecraft:oak_log
fill 362 66 598 362 69 598 minecraft:green_terracotta
fill 363 66 559 364 66 559 minecraft:green_terracotta
setblock 363 66 596 minecraft:oak_log
fill 363 66 597 363 69 597 minecraft:green_terracotta
fill 364 66 596 364 69 596 minecraft:green_terracotta
setblock 365 66 559 minecraft:oak_log
fill 365 66 595 366 68 595 minecraft:green_terracotta
setblock 366 66 558 minecraft:oak_log
fill 366 66 559 367 68 559 minecraft:green_terracotta
setblock 366 66 598 minecraft:oak_log
fill 367 66 558 367 69 558 minecraft:green_terracotta
setblock 367 66 592 minecraft:oak_log
fill 367 66 593 367 69 593 minecraft:green_terracotta
setblock 367 66 597 minecraft:oak_log
fill 367 66 598 367 69 598 minecraft:green_terracotta
setblock 368 66 591 minecraft:oak_log
fill 368 66 592 368 69 592 minecraft:green_terracotta
setblock 368 66 596 minecraft:oak_log
fill 368 66 597 368 69 597 minecraft:green_terracotta
setblock 369 66 570 minecraft:oak_log
fill 369 66 571 369 67 571 minecraft:green_terracotta
fill 369 66 573 369 67 573 minecraft:green_terracotta
setblock 369 66 590 minecraft:oak_log
fill 369 66 591 369 69 591 minecraft:green_terracotta
setblock 369 66 595 minecraft:oak_log
fill 369 66 596 369 69 596 minecraft:green_terracotta
setblock 370 66 559 minecraft:oak_log
setblock 370 66 569 minecraft:oak_log
fill 370 66 570 370 69 570 minecraft:green_terracotta
setblock 370 66 574 minecraft:oak_log
fill 370 66 575 370 69 575 minecraft:green_terracotta
fill 370 66 577 370 67 577 minecraft:green_terracotta
fill 370 66 585 370 69 585 minecraft:green_terracotta
setblock 370 66 589 minecraft:oak_log
fill 370 66 590 370 69 590 minecraft:green_terracotta
setblock 370 66 594 minecraft:oak_log
fill 370 66 595 370 69 595 minecraft:green_terracotta
setblock 330 67 561 minecraft:oak_leaves[persistent=true]
setblock 330 67 568 minecraft:oak_log
fill 330 67 569 330 69 569 minecraft:green_terracotta
setblock 330 67 573 minecraft:oak_log
fill 330 67 574 330 67 577 minecraft:green_terracotta
setblock 330 67 578 minecraft:oak_log
fill 330 67 579 330 67 582 minecraft:green_terracotta
setblock 330 67 583 minecraft:oak_log
fill 330 67 584 330 70 584 minecraft:green_terracotta
setblock 330 67 588 minecraft:oak_log
fill 330 67 589 330 70 589 minecraft:green_terracotta
setblock 330 67 593 minecraft:oak_log
fill 330 67 594 330 70 594 minecraft:green_terracotta
setblock 330 67 598 minecraft:oak_log
setblock 331 67 572 minecraft:oak_log
fill 331 67 573 331 70 573 minecraft:green_terracotta
setblock 331 67 576 minecraft:green_terracotta
setblock 331 67 577 minecraft:oak_log
setblock 331 67 588 minecraft:green_terracotta
setblock 331 67 592 minecraft:oak_log
fill 331 67 593 331 70 593 minecraft:green_terracotta
setblock 331 67 597 minecraft:oak_log
fill 331 67 598 331 70 598 minecraft:green_terracotta
fill 333 67 598 333 68 598 minecraft:green_terracotta
fill 334 67 582 334 73 582 minecraft:dark_oak_log
fill 335 67 584 335 73 584 minecraft:dark_oak_log
fill 336 67 582 336 73 583 minecraft:dark_oak_log
setblock 337 67 598 minecraft:oak_leaves[persistent=true]
setblock 338 67 558 minecraft:oak_leaves[persistent=true]
setblock 340 67 598 minecraft:oak_log
fill 341 67 586 342 73 586 minecraft:dark_oak_log
fill 341 67 590 341 73 590 minecraft:dark_oak_log
fill 341 67 598 344 67 598 minecraft:green_terracotta
fill 342 67 558 344 67 558 minecraft:green_terracotta
fill 343 67 587 343 73 589 minecraft:dark_oak_log
fill 343 67 597 345 67 597 minecraft:green_terracotta
setblock 345 67 558 minecraft:oak_log
setblock 345 67 598 minecraft:oak_log
fill 346 67 558 346 70 558 minecraft:green_terracotta
setblock 346 67 597 minecraft:oak_log
fill 346 67 598 346 70 598 minecraft:green_terracotta
fill 347 67 597 348 69 597 minecraft:green_terracotta
fill 348 67 558 349 67 558 minecraft:green_terracotta
setblock 350 67 558 minecraft:oak_log
setblock 350 67 598 minecraft:oak_log
fill 351 67 558 354 67 558 minecraft:green_terracotta
fill 351 67 598 353 68 598 minecraft:green_terracotta
setblock 355 67 558 minecraft:oak_log
setblock 355 67 598 minecraft:oak_log
fill 356 67 558 359 67 558 minecraft:green_terracotta
fill 356 67 598 359 67 598 minecraft:green_terracotta
fill 359 67 597 360 67 597 minecraft:green_terracotta
setblock 360 67 558 minecraft:oak_log
setblock 360 67 598 minecraft:oak_log
fill 361 67 558 361 69 559 minecraft:green_terracotta
setblock 361 67 596 minecraft:green_terracotta
setblock 361 67 597 minecraft:oak_log
fill 361 67 598 361 70 598 minecraft:green_terracotta
fill 362 67 559 363 67 559 minecraft:green_terracotta
setblock 362 67 596 minecraft:oak_log
fill 362 67 597 362 70 597 minecraft:green_terracotta
setblock 363 67 595 minecraft:oak_log
fill 363 67 596 363 70 596 minecraft:green_terracotta
setblock 364 67 559 minecraft:oak_log
fill 364 67 595 364 70 595 minecraft:green_terracotta
setblock 365 67 558 minecraft:oak_log
fill 365 67 559 365 70 559 minecraft:green_terracotta
setblock 365 67 598 minecraft:oak_log
fill 366 67 558 366 70 558 minecraft:green_terracotta
setblock 366 67 597 minecraft:oak_log
fill 366 67 598 366 70 598 minecraft:green_terracotta
fill 367 67 592 367 69 592 minecraft:green_terracotta
setblock 367 67 596 minecraft:oak_log
fill 367 67 597 367 70 597 minecraft:green_terracotta
setblock 368 67 559 minecraft:green_terracotta
setblock 368 67 590 minecraft:oak_log
fill 368 67 591 368 70 591 minecraft:green_terracotta
setblock 368 67 595 minecraft:oak_log
fill 368 67 596 368 70 596 minecraft:green_terracotta
setblock 369 67 574 minecraft:oak_log
fill 369 67 575 369 70 575 minecraft:green_terracotta
setblock 369 67 589 minecraft:oak_log
fill 369 67 590 369 70 590 minecraft:green_terracotta
setblock 369 67 594 minecraft:oak_log
fill 369 67 595 369 70 595 minecraft:green_terracotta
setblock 370 67 558 minecraft:oak_log
fill 370 67 559 370 70 559 minecraft:green_terracotta
setblock 370 67 568 minecraft:oak_log
fill 370 67 569 370 68 569 minecraft:green_terracotta
setblock 370 67 573 minecraft:oak_log
fill 370 67 574 370 70 574 minecraft:green_terracotta
setblock 370 67 578 minecraft:oak_log
setblock 370 67 588 minecraft:oak_log
fill 370 67 589 370 70 589 minecraft:green_terracotta
setblock 370 67 593 minecraft:oak_log
fill 370 67 594 370 70 594 minecraft:green_terracotta
setblock 370 67 598 minecraft:oak_log
setblock 330 68 567 minecraft:oak_leaves[persistent=true]
setblock 330 68 572 minecraft:oak_log
fill 330 68 573 330 68 576 minecraft:green_terracotta
setblock 330 68 577 minecraft:oak_log
fill 330 68 578 330 68 581 minecraft:green_terracotta
setblock 330 68 582 minecraft:oak_log
fill 330 68 583 330 71 583 minecraft:green_terracotta
setblock 330 68 587 minecraft:oak_log
fill 330 68 588 330 71 588 minecraft:green_terracotta
setblock 330 68 592 minecraft:oak_log
fill 330 68 593 330 71 593 minecraft:green_terracotta
setblock 330 68 597 minecraft:oak_log
fill 330 68 598 330 71 598 minecraft:green_terracotta
fill 331 68 572 331 70 572 minecraft:green_terracotta
setblock 331 68 576 minecraft:oak_log
fill 331 68 577 331 69 579 minecraft:green_terracotta
setblock 331 68 591 minecraft:oak_log
fill 331 68 592 331 70 592 minecraft:green_terracotta
setblock 331 68 596 minecraft:oak_log
fill 331 68 597 332 70 597 minecraft:green_terracotta
setblock 332 68 558 minecraft:oak_leaves[persistent=true]
fill 333 68 583 333 73 583 minecraft:dark_oak_log
fill 334 68 581 336 73 581 minecraft:dark_oak_log
fill 334 68 584 334 73 584 minecraft:dark_oak_log
setblock 334 68 598 minecraft:oak_log
fill 336 68 584 336 73 584 minecraft:dark_oak_log
fill 337 68 598 338 68 598 minecraft:green_terracotta
fill 339 68 587 339 73 589 minecraft:dark_oak_log
setblock 339 68 598 minecraft:oak_log
fill 340 68 586 340 73 586 minecraft:dark_oak_log
fill 340 68 590 340 73 590 minecraft:dark_oak_log
fill 340 68 598 343 68 598 minecraft:green_terracotta
fill 341 68 558 343 68 558 minecraft:green_terracotta
fill 341 68 597 344 68 597 minecraft:green_terracotta
fill 342 68 590 342 73 590 minecraft:dark_oak_log
fill 343 68 586 343 73 586 minecraft:dark_oak_log
setblock 344 68 558 minecraft:oak_log
fill 344 68 559 347 68 559 minecraft:green_terracotta
setblock 344 68 598 minecraft:oak_log
fill 345 68 558 345 71 558 minecraft:green_terracotta
setblock 345 68 597 minecraft:oak_log
fill 345 68 598 345 71 598 minecraft:green_terracotta
fill 346 68 597 346 71 597 minecraft:green_terracotta
setblock 348 68 558 minecraft:green_terracotta
setblock 348 68 559 minecraft:oak_log
setblock 348 68 598 minecraft:green_terracotta
setblock 349 68 558 minecraft:oak_log
fill 349 68 559 349 71 559 minecraft:green_terracotta
setblock 349 68 597 minecraft:green_terracotta
setblock 349 68 598 minecraft:oak_log
fill 350 68 558 353 68 558 minecraft:green_terracotta
fill 350 68 598 350 71 598 minecraft:green_terracotta
setblock 354 68 558 minecraft:oak_log
setblock 354 68 598 minecraft:oak_log
fill 355 68 558 358 68 558 minecraft:green_terracotta
fill 355 68 598 358 68 598 minecraft:green_terracotta
fill 357 68 597 359 68 597 minecraft:green_terracotta
setblock 359 68 558 minecraft:oak_log
fill 359 68 559 360 70 559 minecraft:green_terracotta
setblock 359 68 598 minecraft:oak_log
fill 360 68 558 360 71 558 minecraft:green_terracotta
setblock 360 68 596 minecraft:green_terracotta
setblock 360 68 597 minecraft:oak_log
fill 360 68 598 360 71 598 minecraft:green_terracotta
setblock 361 68 596 minecraft:oak_log
fill 361 68 597 361 71 597 minecraft:green_terracotta
setblock 362 68 559 minecraft:green_terracotta
setblock 362 68 595 minecraft:oak_log
fill 362 68 596 362 71 596 minecraft:green_terracotta
setblock 363 68 559 minecraft:oak_log
fill 363 68 595 363 71 595 minecraft:green_terracotta
setblock 364 68 558 minecraft:oak_log
fill 364 68 559 364 71 559 minecraft:green_terracotta
setblock 364 68 598 minecraft:oak_log
fill 365 68 558 365 71 558 minecraft:green_terracotta
setblock 365 68 597 minecraft:oak_log
fill 365 68 598 365 71 598 minecraft:green_terracotta
setblock 366 68 596 minecraft:oak_log
fill 366 68 597 366 71 597 minecraft:green_terracotta
setblock 367 68 594 minecraft:green_terracotta
setblock 367 68 595 minecraft:oak_log
fill 367 68 596 367 71 596 minecraft:green_terracotta
setblock 368 68 559 minecraft:oak_log
fill 368 68 590 368 69 590 minecraft:green_terracotta
setblock 368 68 594 minecraft:oak_log
fill 368 68 595 368 71 595 minecraft:green_terracotta
setblock 369 68 558 minecraft:oak_log
setblock 369 68 573 minecraft:oak_log
fill 369 68 574 369 70 574 minecraft:green_terracotta
fill 369 68 576 369 69 576 minecraft:green_terracotta
setblock 369 68 588 minecraft:oak_log
fill 369 68 589 369 70 589 minecraft:green_terracotta
setblock 369 68 593 minecraft:oak_log
fill 369 68 594 369 71 594 minecraft:green_terracotta
setblock 369 68 598 minecraft:oak_log
fill 370 68 558 370 71 558 minecraft:green_terracotta
setblock 370 68 564 minecraft:oak_leaves[persistent=true]
setblock 370 68 572 minecraft:oak_log
fill 370 68 573 370 71 573 minecraft:green_terracotta
setblock 370 68 577 minecraft:oak_log
fill 370 68 578 370 69 580 minecraft:green_terracotta
setblock 370 68 583 minecraft:oak_leaves[persistent=true]
setblock 370 68 587 minecraft:oak_log
fill 370 68 588 370 71 588 minecraft:green_terracotta
setblock 370 68 592 minecraft:oak_log
fill 370 68 593 370 71 593 minecraft:green_terracotta
setblock 370 68 597 minecraft:oak_log
fill 370 68 598 370 71 598 minecraft:green_terracotta
setblock 330 69 571 minecraft:oak_log
fill 330 69 572 330 69 575 minecraft:green_terracotta
setblock 330 69 576 minecraft:oak_log
fill 330 69 577 330 69 580 minecraft:green_terracotta
setblock 330 69 581 minecraft:oak_log
fill 330 69 582 330 72 582 minecraft:green_terracotta
setblock 330 69 586 minecraft:oak_log
fill 330 69 587 330 72 587 minecraft:green_terracotta
setblock 330 69 591 minecraft:oak_log
fill 330 69 592 330 72 592 minecraft:green_terracotta
setblock 330 69 596 minecraft:oak_log
fill 330 69 597 330 72 597 minecraft:green_terracotta
setblock 331 69 574 minecraft:green_terracotta
setblock 331 69 575 minecraft:oak_log
fill 331 69 576 331 72 576 minecraft:green_terracotta
setblock 331 69 580 minecraft:oak_log
setblock 331 69 590 minecraft:oak_log
fill 331 69 591 331 70 591 minecraft:green_terracotta
setblock 331 69 595 minecraft:oak_log
fill 331 69 596 331 71 596 minecraft:green_terracotta
fill 333 69 582 333 73 582 minecraft:dark_oak_log
fill 333 69 584 333 73 584 minecraft:dark_oak_log
setblock 333 69 598 minecraft:oak_log
fill 334 69 598 337 69 598 minecraft:green_terracotta
fill 335 69 585 335 73 585 minecraft:dark_oak_log
fill 337 69 582 337 73 583 minecraft:dark_oak_log
setblock 338 69 598 minecraft:oak_log
fill 339 69 558 342 69 558 minecraft:green_terracotta
fill 339 69 586 339 73 586 minecraft:dark_oak_log
fill 339 69 590 339 73 590 minecraft:dark_oak_log
setblock 339 69 597 minecraft:oak_log
fill 339 69 598 342 69 598 minecraft:green_terracotta
fill 340 69 585 342 73 585 minecraft:dark_oak_log
fill 340 69 597 343 69 597 minecraft:green_terracotta
setblock 342 69 559 minecraft:oak_log
setblock 343 69 558 minecraft:oak_log
fill 343 69 559 346 69 559 minecraft:green_terracotta
fill 343 69 590 343 73 590 minecraft:dark_oak_log
fill 343 69 596 344 69 596 minecraft:green_terracotta
setblock 343 69 598 minecraft:oak_log
fill 344 69 558 344 72 558 minecraft:green_terracotta
fill 344 69 587 344 73 589 minecraft:dark_oak_log
setblock 344 69 597 minecraft:oak_log
fill 344 69 598 344 72 598 minecraft:green_terracotta
setblock 345 69 596 minecraft:oak_log
fill 345 69 597 345 72 597 minecraft:green_terracotta
fill 346 69 596 346 70 596 minecraft:green_terracotta
setblock 347 69 559 minecraft:oak_log
setblock 348 69 558 minecraft:oak_log
fill 348 69 559 348 72 559 minecraft:green_terracotta
setblock 348 69 598 minecraft:oak_log
fill 349 69 558 352 69 558 minecraft:green_terracotta
setblock 349 69 597 minecraft:oak_log
fill 349 69 598 349 72 598 minecraft:green_terracotta
fill 350 69 559 350 70 559 minecraft:green_terracotta
fill 350 69 597 350 71 597 minecraft:green_terracotta
fill 351 69 598 352 69 598 minecraft:green_terracotta
setblock 353 69 558 minecraft:oak_log
setblock 353 69 598 minecraft:oak_log
fill 354 69 558 357 69 558 minecraft:green_terracotta
fill 354 69 598 357 69 598 minecraft:green_terracotta
fill 356 69 597 358 69 597 minecraft:green_terracotta
setblock 357 69 559 minecraft:oak_log
setblock 358 69 558 minecraft:oak_log
fill 358 69 559 358 72 559 minecraft:green_terracotta
setblock 358 69 598 minecraft:oak_log
fill 359 69 558 359 72 558 minecraft:green_terracotta
setblock 359 69 596 minecraft:green_terracotta
setblock 359 69 597 minecraft:oak_log
fill 359 69 598 359 72 598 minecraft:green_terracotta
setblock 360 69 596 minecraft:oak_log
fill 360 69 597 360 72 597 minecraft:green_terracotta
setblock 361 69 595 minecraft:oak_log
fill 361 69 596 361 72 596 minecraft:green_terracotta
setblock 362 69 559 minecraft:oak_log
fill 362 69 560 364 70 560 minecraft:green_terracotta
fill 362 69 595 362 72 595 minecraft:green_terracotta
setblock 363 69 558 minecraft:oak_log
fill 363 69 559 363 72 559 minecraft:green_terracotta
setblock 363 69 598 minecraft:oak_log
fill 364 69 558 364 72 558 minecraft:green_terracotta
setblock 364 69 597 minecraft:oak_log
fill 364 69 598 364 72 598 minecraft:green_terracotta
setblock 365 69 595 minecraft:green_terracotta
setblock 365 69 596 minecraft:oak_log
fill 365 69 597 365 72 597 minecraft:green_terracotta
setblock 366 69 559 minecraft:green_terracotta
setblock 366 69 595 minecraft:oak_log
fill 366 69 596 366 72 596 minecraft:green_terracotta
setblock 367 69 559 minecraft:oak_log
setblock 367 69 594 minecraft:oak_log
fill 367 69 595 367 72 595 minecraft:green_terracotta
setblock 368 69 558 minecraft:oak_log
fill 368 69 559 368 72 559 minecraft:green_terracotta
setblock 368 69 593 minecraft:oak_log
fill 368 69 594 368 72 594 minecraft:green_terracotta
setblock 368 69 598 minecraft:oak_log
fill 369 69 558 369 72 558 minecraft:green_terracotta
setblock 369 69 572 minecraft:oak_log
fill 369 69 573 369 70 573 minecraft:green_terracotta
setblock 369 69 577 minecraft:oak_log
fill 369 69 578 369 72 578 minecraft:green_terracotta
setblock 369 69 588 minecraft:green_terracotta
setblock 369 69 592 minecraft:oak_log
fill 369 69 593 369 72 593 minecraft:green_terracotta
setblock 369 69 597 minecraft:oak_log
fill 369 69 598 369 72 598 minecraft:green_terracotta
setblock 370 69 560 minecraft:green_terracotta
setblock 370 69 571 minecraft:oak_log
fill 370 69 572 370 71 572 minecraft:green_terracotta
setblock 370 69 576 minecraft:oak_log
fill 370 69 577 370 72 577 minecraft:green_terracotta
setblock 370 69 581 minecraft:oak_log
fill 370 69 582 370 70 584 minecraft:green_terracotta
setblock 370 69 586 minecraft:oak_log
fill 370 69 587 370 72 587 minecraft:green_terracotta
setblock 370 69 591 minecraft:oak_log
fill 370 69 592 370 72 592 minecraft:green_terracotta
setblock 370 69 596 minecraft:oak_log
fill 370 69 597 370 72 597 minecraft:green_terracotta
setblock 330 70 560 minecraft:oak_leaves[persistent=true]
setblock 330 70 570 minecraft:oak_log
fill 330 70 571 330 70 574 minecraft:green_terracotta
setblock 330 70 575 minecraft:oak_log
fill 330 70 576 330 70 579 minecraft:green_terracotta
setblock 330 70 580 minecraft:oak_log
fill 330 70 581 331 72 581 minecraft:green_terracotta
setblock 330 70 585 minecraft:oak_log
fill 330 70 586 330 73 586 minecraft:green_terracotta
setblock 330 70 590 minecraft:oak_log
fill 330 70 591 330 72 591 minecraft:green_terracotta
setblock 330 70 595 minecraft:oak_log
fill 330 70 596 330 73 596 minecraft:green_terracotta
setblock 331 70 574 minecraft:oak_log
fill 331 70 575 331 73 575 minecraft:green_terracotta
fill 331 70 577 331 70 578 minecraft:green_terracotta
setblock 331 70 579 minecraft:oak_log
fill 331 70 580 331 73 580 minecraft:green_terracotta
setblock 331 70 594 minecraft:oak_log
fill 331 70 595 331 71 595 minecraft:green_terracotta
setblock 332 70 598 minecraft:oak_log
fill 333 70 581 333 73 581 minecraft:dark_oak_log
fill 333 70 598 336 70 598 minecraft:green_terracotta
fill 334 70 580 336 73 580 minecraft:dark_oak_log
fill 334 70 585 334 73 585 minecraft:dark_oak_log
fill 336 70 585 336 73 585 minecraft:dark_oak_log
fill 337 70 581 337 73 581 minecraft:dark_oak_log
fill 337 70 584 337 73 584 minecraft:dark_oak_log
setblock 337 70 598 minecraft:oak_log
fill 338 70 558 341 70 558 minecraft:green_terracotta
fill 338 70 587 338 73 589 minecraft:dark_oak_log
setblock 338 70 597 minecraft:oak_log
fill 338 70 598 341 70 598 minecraft:green_terracotta
fill 339 70 585 339 73 585 minecraft:dark_oak_log
fill 339 70 597 342 70 597 minecraft:green_terracotta
fill 340 70 591 342 73 591 minecraft:dark_oak_log
setblock 341 70 559 minecraft:oak_log
setblock 342 70 558 minecraft:oak_log
fill 342 70 559 345 70 559 minecraft:green_terracotta
fill 342 70 596 343 70 596 minecraft:green_terracotta
setblock 342 70 598 minecraft:oak_log
fill 343 70 558 343 73 558 minecraft:green_terracotta
fill 343 70 585 343 73 585 minecraft:dark_oak_log
setblock 343 70 597 minecraft:oak_log
fill 343 70 598 343 73 598 minecraft:green_terracotta
fill 344 70 586 344 73 586 minecraft:dark_oak_log
fill 344 70 590 344 73 590 minecraft:dark_oak_log
setblock 344 70 596 minecraft:oak_log
fill 344 70 597 344 73 597 minecraft:green_terracotta
fill 345 70 596 345 71 596 minecraft:green_terracotta
setblock 346 70 559 minecraft:oak_log
setblock 347 70 558 minecraft:oak_log
fill 347 70 559 347 73 559 minecraft:green_terracotta
setblock 347 70 597 minecraft:green_terracotta
setblock 347 70 598 minecraft:oak_log
fill 348 70 558 351 70 558 minecraft:green_terracotta
setblock 348 70 597 minecraft:oak_log
fill 348 70 598 348 73 598 minecraft:green_terracotta
fill 349 70 597 349 72 597 minecraft:green_terracotta
setblock 351 70 559 minecraft:oak_log
fill 351 70 597 351 70 598 minecraft:green_terracotta
setblock 352 70 558 minecraft:oak_log
fill 352 70 559 352 73 559 minecraft:green_terracotta
setblock 352 70 598 minecraft:oak_log
fill 353 70 558 356 70 558 minecraft:green_terracotta
fill 353 70 598 356 70 598 minecraft:green_terracotta
fill 354 70 597 357 70 597 minecraft:green_terracotta
setblock 355 70 559 minecraft:green_terracotta
setblock 356 70 559 minecraft:oak_log
setblock 357 70 558 minecraft:oak_log
fill 357 70 559 357 73 559 minecraft:green_terracotta
setblock 357 70 598 minecraft:oak_log
fill 358 70 558 358 73 558 minecraft:green_terracotta
setblock 358 70 596 minecraft:green_terracotta
setblock 358 70 597 minecraft:oak_log
fill 358 70 598 358 73 598 minecraft:green_terracotta
setblock 359 70 596 minecraft:oak_log
fill 359 70 597 359 73 597 minecraft:green_terracotta
setblock 360 70 560 minecraft:oak_log
fill 360 70 596 360 73 596 minecraft:green_terracotta
setblock 361 70 558 minecraft:green_terracotta
setblock 361 70 559 minecraft:oak_log
fill 361 70 560 361 73 560 minecraft:green_terracotta
fill 361 70 595 361 73 595 minecraft:green_terracotta
setblock 362 70 558 minecraft:oak_log
fill 362 70 559 362 73 559 minecraft:green_terracotta
setblock 362 70 598 minecraft:oak_log
fill 363 70 558 363 73 558 minecraft:green_terracotta
setblock 363 70 597 minecraft:oak_log
fill 363 70 598 363 73 598 minecraft:green_terracotta
setblock 364 70 596 minecraft:oak_log
fill 364 70 597 364 73 597 minecraft:green_terracotta
setblock 365 70 560 minecraft:oak_log
setblock 365 70 595 minecraft:oak_log
fill 365 70 596 365 73 596 minecraft:green_terracotta
setblock 366 70 559 minecraft:oak_log
fill 366 70 595 366 72 595 minecraft:green_terracotta
setblock 367 70 558 minecraft:oak_log
fill 367 70 559 367 73 559 minecraft:green_terracotta
setblock 367 70 593 minecraft:oak_log
fill 367 70 594 367 71 594 minecraft:green_terracotta
setblock 367 70 598 minecraft:oak_log
fill 368 70 558 368 73 558 minecraft:green_terracotta
setblock 368 70 592 minecraft:oak_log
fill 368 70 593 368 72 593 minecraft:green_terracotta
setblock 368 70 597 minecraft:oak_log
fill 368 70 598 368 73 598 minecraft:green_terracotta
setblock 369 70 576 minecraft:oak_log
fill 369 70 577 369 72 577 minecraft:green_terracotta
fill 369 70 579 370 70 579 minecraft:green_terracotta
setblock 369 70 591 minecraft:oak_log
fill 369 70 592 369 72 592 minecraft:green_terracotta
setblock 369 70 596 minecraft:oak_log
fill 369 70 597 369 73 597 minecraft:green_terracotta
setblock 370 70 560 minecraft:oak_log
setblock 370 70 571 minecraft:green_terracotta
setblock 370 70 575 minecraft:oak_log
fill 370 70 576 370 73 576 minecraft:green_terracotta
fill 370 70 578 370 71 578 minecraft:green_terracotta
setblock 370 70 580 minecraft:oak_log
fill 370 70 581 370 73 581 minecraft:green_terracotta
setblock 370 70 585 minecraft:oak_log
fill 370 70 586 370 72 586 minecraft:green_terracotta
setblock 370 70 590 minecraft:oak_log
fill 370 70 591 370 73 591 minecraft:green_terracotta
setblock 370 70 595 minecraft:oak_log
fill 370 70 596 370 73 596 minecraft:green_terracotta
setblock 330 71 566 minecraft:oak_leaves[persistent=true]
fill 330 71 570 330 71 573 minecraft:green_terracotta
setblock 330 71 574 minecraft:oak_log
fill 330 71 575 330 71 578 minecraft:green_terracotta
setblock 330 71 579 minecraft:oak_log
fill 330 71 580 330 74 580 minecraft:green_terracotta
setblock 330 71 584 minecraft:oak_log
fill 330 71 585 330 74 585 minecraft:green_terracotta
setblock 330 71 589 minecraft:oak_log
fill 330 71 590 330 72 590 minecraft:green_terracotta
setblock 330 71 594 minecraft:oak_log
fill 330 71 595 330 73 595 minecraft:green_terracotta
setblock 331 71 573 minecraft:oak_log
fill 331 71 574 331 72 574 minecraft:green_terracotta
setblock 331 71 577 minecraft:green_terracotta
setblock 331 71 578 minecraft:oak_log
fill 331 71 579 331 74 579 minecraft:green_terracotta
setblock 331 71 582 minecraft:green_terracotta
setblock 331 71 594 minecraft:green_terracotta
setblock 331 71 597 minecraft:green_terracotta
setblock 331 71 598 minecraft:oak_log
fill 332 71 581 332 73 584 minecraft:dark_oak_log
fill 332 71 598 335 71 598 minecraft:green_terracotta
setblock 333 71 558 minecraft:oak_leaves[persistent=true]
fill 333 71 580 333 73 580 minecraft:dark_oak_log
fill 333 71 585 333 73 585 minecraft:dark_oak_log
setblock 336 71 598 minecraft:oak_log
fill 337 71 558 340 71 558 minecraft:green_terracotta
fill 337 71 580 337 73 580 minecraft:dark_oak_log
fill 337 71 585 337 73 585 minecraft:dark_oak_log
fill 337 71 598 340 71 598 minecraft:green_terracotta
fill 338 71 582 338 73 583 minecraft:dark_oak_log
fill 338 71 586 338 73 586 minecraft:dark_oak_log
fill 338 71 590 338 73 590 minecraft:dark_oak_log
fill 338 71 597 341 71 597 minecraft:green_terracotta
fill 339 71 591 339 73 591 minecraft:dark_oak_log
setblock 340 71 559 minecraft:oak_log
fill 340 71 584 342 73 584 minecraft:dark_oak_log
setblock 341 71 558 minecraft:oak_log
fill 341 71 559 344 71 559 minecraft:green_terracotta
setblock 341 71 598 minecraft:oak_log
fill 342 71 558 342 74 558 minecraft:green_terracotta
setblock 342 71 596 minecraft:green_terracotta
setblock 342 71 597 minecraft:oak_log
fill 342 71 598 342 74 598 minecraft:green_terracotta
setblock 343 71 560 minecraft:green_terracotta
fill 343 71 591 343 73 591 minecraft:dark_oak_log
setblock 343 71 596 minecraft:oak_log
fill 343 71 597 343 74 597 minecraft:green_terracotta
setblock 344 71 560 minecraft:oak_log
fill 344 71 585 344 73 585 minecraft:dark_oak_log
setblock 344 71 596 minecraft:green_terracotta
setblock 345 71 559 minecraft:oak_log
fill 345 71 560 346 73 560 minecraft:green_terracotta
fill 345 71 587 345 73 589 minecraft:dark_oak_log
setblock 346 71 558 minecraft:oak_log
fill 346 71 559 346 74 559 minecraft:green_terracotta
setblock 346 71 598 minecraft:oak_log
fill 347 71 558 350 71 558 minecraft:green_terracotta
setblock 347 71 597 minecraft:oak_log
fill 347 71 598 347 74 598 minecraft:green_terracotta
fill 348 71 597 348 72 597 minecraft:green_terracotta
setblock 350 71 559 minecraft:oak_log
setblock 351 71 558 minecraft:oak_log
fill 351 71 559 351 74 559 minecraft:green_terracotta
setblock 351 71 598 minecraft:oak_log
fill 352 71 558 355 71 558 minecraft:green_terracotta
fill 352 71 598 355 71 598 minecraft:green_terracotta
fill 353 71 559 354 71 559 minecraft:green_terracotta
fill 354 71 597 356 71 597 minecraft:green_terracotta
setblock 355 71 559 minecraft:oak_log
setblock 356 71 558 minecraft:oak_log
fill 356 71 559 356 74 559 minecraft:green_terracotta
setblock 356 71 598 minecraft:oak_log
fill 357 71 558 357 74 558 minecraft:green_terracotta
setblock 357 71 597 minecraft:oak_log
fill 357 71 598 357 74 598 minecraft:green_terracotta
setblock 358 71 596 minecraft:oak_log
fill 358 71 597 358 74 597 minecraft:green_terracotta
setblock 359 71 559 minecraft:green_terracotta
setblock 359 71 560 minecraft:oak_log
fill 359 71 596 359 74 596 minecraft:green_terracotta
setblock 360 71 559 minecraft:oak_log
fill 360 71 560 360 74 560 minecraft:green_terracotta
fill 360 71 595 360 72 595 minecraft:green_terracotta
setblock 361 71 558 minecraft:oak_log
fill 361 71 559 361 74 559 minecraft:green_terracotta
setblock 361 71 598 minecraft:oak_log
fill 362 71 558 362 74 558 minecraft:green_terracotta
fill 362 71 560 363 71 560 minecraft:green_terracotta
setblock 362 71 597 minecraft:oak_log
fill 362 71 598 362 74 598 minecraft:green_terracotta
setblock 363 71 596 minecraft:oak_log
fill 363 71 597 363 74 597 minecraft:green_terracotta
setblock 364 71 560 minecraft:oak_log
setblock 364 71 595 minecraft:oak_log
fill 364 71 596 364 74 596 minecraft:green_terracotta
setblock 365 71 559 minecraft:oak_log
fill 365 71 560 365 72 560 minecraft:green_terracotta
fill 365 71 595 365 73 595 minecraft:green_terracotta
setblock 366 71 558 minecraft:oak_log
fill 366 71 559 366 74 559 minecraft:green_terracotta
setblock 366 71 598 minecraft:oak_log
fill 367 71 558 367 74 558 minecraft:green_terracotta
setblock 367 71 597 minecraft:oak_log
fill 367 71 598 367 74 598 minecraft:green_terracotta
setblock 368 71 592 minecraft:green_terracotta
setblock 368 71 596 minecraft:oak_log
fill 368 71 597 368 74 597 minecraft:green_terracotta
setblock 369 71 575 minecraft:oak_log
fill 369 71 576 369 72 576 minecraft:green_terracotta
setblock 369 71 579 minecraft:green_terracotta
setblock 369 71 580 minecraft:oak_log
setblock 369 71 590 minecraft:oak_log
fill 369 71 591 369 72 591 minecraft:green_terracotta
setblock 369 71 595 minecraft:oak_log
fill 369 71 596 369 74 596 minecraft:green_terracotta
setblock 370 71 559 minecraft:oak_log
setblock 370 71 560 minecraft:green_terracotta
setblock 370 71 565 minecraft:oak_leaves[persistent=true]
setblock 370 71 574 minecraft:oak_log
fill 370 71 575 370 73 575 minecraft:green_terracotta
setblock 370 71 579 minecraft:oak_log
fill 370 71 580 370 74 580 minecraft:green_terracotta
fill 370 71 582 370 71 583 minecraft:green_terracotta
setblock 370 71 584 minecraft:oak_log
fill 370 71 585 370 73 585 minecraft:green_terracotta
setblock 370 71 589 minecraft:oak_log
fill 370 71 590 370 73 590 minecraft:green_terracotta
setblock 370 71 594 minecraft:oak_log
fill 370 71 595 370 74 595 minecraft:green_terracotta
fill 330 72 571 330 72 572 minecraft:green_terracotta
setblock 330 72 573 minecraft:oak_log
fill 330 72 574 330 72 577 minecraft:green_terracotta
setblock 330 72 578 minecraft:oak_log
fill 330 72 579 330 75 579 minecraft:green_terracotta
setblock 330 72 583 minecraft:oak_log
fill 330 72 584 330 75 584 minecraft:green_terracotta
setblock 330 72 588 minecraft:oak_log
setblock 330 72 589 minecraft:green_terracotta
setblock 330 72 593 minecraft:oak_log
fill 330 72 594 330 73 594 minecraft:green_terracotta
setblock 330 72 598 minecraft:oak_log
setblock 331 72 577 minecraft:oak_log
fill 331 72 578 331 75 578 minecraft:green_terracotta
setblock 331 72 582 minecraft:oak_log
fill 331 72 598 334 72 598 minecraft:green_terracotta
fill 332 72 585 332 73 585 minecraft:dark_oak_log
fill 334 72 579 336 73 579 minecraft:dark_oak_log
fill 334 72 586 337 73 586 minecraft:dark_oak_log
setblock 335 72 598 minecraft:oak_log
fill 336 72 558 339 72 558 minecraft:green_terracotta
fill 336 72 598 339 72 598 minecraft:green_terracotta
fill 337 72 587 337 73 589 minecraft:dark_oak_log
fill 338 72 581 338 73 581 minecraft:dark_oak_log
fill 338 72 584 338 73 585 minecraft:dark_oak_log
fill 338 72 591 338 73 591 minecraft:dark_oak_log
fill 338 72 597 340 72 597 minecraft:green_terracotta
setblock 339 72 559 minecraft:oak_log
fill 339 72 584 339 73 584 minecraft:dark_oak_log
setblock 340 72 558 minecraft:oak_log
fill 340 72 559 343 72 559 minecraft:green_terracotta
fill 340 72 592 343 73 592 minecraft:dark_oak_log
setblock 340 72 598 minecraft:oak_log
fill 341 72 558 341 75 558 minecraft:green_terracotta
setblock 341 72 597 minecraft:oak_log
fill 341 72 598 341 75 598 minecraft:green_terracotta
setblock 342 72 560 minecraft:green_terracotta
fill 342 72 597 342 75 597 minecraft:green_terracotta
setblock 343 72 560 minecraft:oak_log
fill 343 72 584 343 73 584 minecraft:dark_oak_log
setblock 344 72 559 minecraft:oak_log
fill 344 72 560 344 75 560 minecraft:green_terracotta
fill 344 72 591 344 73 591 minecraft:dark_oak_log
setblock 345 72 558 minecraft:oak_log
fill 345 72 559 345 75 559 minecraft:green_terracotta
fill 345 72 586 345 73 586 minecraft:dark_oak_log
fill 345 72 590 345 73 590 minecraft:dark_oak_log
setblock 345 72 598 minecraft:oak_log
fill 346 72 558 349 72 558 minecraft:green_terracotta
setblock 346 72 597 minecraft:oak_log
fill 346 72 598 346 75 598 minecraft:green_terracotta
fill 347 72 597 347 73 597 minecraft:green_terracotta
setblock 349 72 559 minecraft:oak_log
setblock 350 72 558 minecraft:oak_log
fill 350 72 559 350 75 559 minecraft:green_terracotta
setblock 350 72 598 minecraft:oak_log
fill 351 72 558 354 72 558 minecraft:green_terracotta
fill 351 72 598 354 72 598 minecraft:green_terracotta
setblock 353 72 559 minecraft:green_terracotta
setblock 354 72 559 minecraft:oak_log
fill 354 72 597 355 72 597 minecraft:green_terracotta
setblock 355 72 558 minecraft:oak_log
fill 355 72 559 355 75 559 minecraft:green_terracotta
setblock 355 72 598 minecraft:oak_log
fill 356 72 558 356 75 558 minecraft:green_terracotta
setblock 356 72 597 minecraft:oak_log
fill 356 72 598 356 75 598 minecraft:green_terracotta
setblock 357 72 596 minecraft:oak_log
fill 357 72 597 357 75 597 minecraft:green_terracotta
setblock 358 72 560 minecraft:oak_log
fill 358 72 596 358 75 596 minecraft:green_terracotta
setblock 359 72 559 minecraft:oak_log
fill 359 72 560 359 75 560 minecraft:green_terracotta
setblock 360 72 558 minecraft:oak_log
fill 360 72 559 360 75 559 minecraft:green_terracotta
setblock 360 72 598 minecraft:oak_log
fill 361 72 558 361 75 558 minecraft:green_terracotta
setblock 361 72 597 minecraft:oak_log
fill 361 72 598 361 75 598 minecraft:green_terracotta
setblock 362 72 560 minecraft:green_terracotta
setblock 362 72 596 minecraft:oak_log
fill 362 72 597 362 75 597 minecraft:green_terracotta
setblock 363 72 560 minecraft:oak_log
setblock 363 72 595 minecraft:oak_log
fill 363 72 596 363 75 596 minecraft:green_terracotta
setblock 364 72 559 minecraft:oak_log
fill 364 72 560 364 74 560 minecraft:green_terracotta
fill 364 72 595 364 73 595 minecraft:green_terracotta
setblock 365 72 558 minecraft:oak_log
fill 365 72 559 365 75 559 minecraft:green_terracotta
setblock 365 72 598 minecraft:oak_log
fill 366 72 558 366 75 558 minecraft:green_terracotta
setblock 366 72 597 minecraft:oak_log
fill 366 72 598 366 75 598 minecraft:green_terracotta
setblock 367 72 596 minecraft:oak_log
fill 367 72 597 367 75 597 minecraft:green_terracotta
setblock 368 72 595 minecraft:oak_log
fill 368 72 596 368 73 596 minecraft:green_terracotta
setblock 369 72 579 minecraft:oak_log
setblock 369 72 580 minecraft:green_terracotta
setblock 369 72 594 minecraft:oak_log
fill 369 72 595 369 74 595 minecraft:green_terracotta
setblock 370 72 558 minecraft:oak_log
fill 370 72 559 370 73 559 minecraft:green_terracotta
setblock 370 72 573 minecraft:oak_log
setblock 370 72 574 minecraft:green_terracotta
setblock 370 72 578 minecraft:oak_log
fill 370 72 579 370 75 579 minecraft:green_terracotta
setblock 370 72 582 minecraft:green_terracotta
setblock 370 72 583 minecraft:oak_log
fill 370 72 584 370 75 584 minecraft:green_terracotta
setblock 370 72 588 minecraft:oak_log
fill 370 72 589 370 73 589 minecraft:green_terracotta
setblock 370 72 593 minecraft:oak_log
fill 370 72 594 370 75 594 minecraft:green_terracotta
setblock 370 72 598 minecraft:oak_log
setblock 330 73 559 minecraft:oak_leaves[persistent=true]
setblock 330 73 572 minecraft:oak_log
fill 330 73 573 330 73 576 minecraft:green_terracotta
setblock 330 73 577 minecraft:oak_log
fill 330 73 578 330 76 578 minecraft:green_terracotta
setblock 330 73 581 minecraft:green_terracotta
setblock 330 73 582 minecraft:oak_log
fill 330 73 583 330 76 583 minecraft:green_terracotta
setblock 330 73 593 minecraft:green_terracotta
setblock 330 73 597 minecraft:oak_log
fill 330 73 598 333 73 598 minecraft:green_terracotta
setblock 331 73 576 minecraft:oak_log
fill 331 73 577 331 75 577 minecraft:green_terracotta
setblock 331 73 581 minecraft:oak_log
fill 331 73 582 331 74 582 minecraft:green_terracotta
fill 331 73 583 331 73 584 minecraft:dark_oak_log
setblock 332 73 560 minecraft:light[level=14]
setblock 332 73 568 minecraft:light[level=14]
setblock 332 73 576 minecraft:light[level=14]
setblock 332 73 580 minecraft:dark_oak_log
setblock 332 73 592 minecraft:light[level=14]
setblock 333 73 579 minecraft:dark_oak_log
setblock 333 73 586 minecraft:dark_oak_log
setblock 334 73 598 minecraft:oak_log
fill 335 73 558 338 73 558 minecraft:green_terracotta
fill 335 73 598 338 73 598 minecraft:green_terracotta
setblock 337 73 579 minecraft:dark_oak_log
setblock 337 73 590 minecraft:dark_oak_log
setblock 338 73 559 minecraft:oak_log
setblock 338 73 580 minecraft:dark_oak_log
fill 338 73 597 339 73 597 minecraft:green_terracotta
setblock 339 73 558 minecraft:oak_log
fill 339 73 559 342 73 559 minecraft:green_terracotta
fill 339 73 582 339 73 583 minecraft:dark_oak_log
setblock 339 73 592 minecraft:dark_oak_log
setblock 339 73 598 minecraft:oak_log
fill 340 73 558 340 76 558 minecraft:green_terracotta
setblock 340 73 560 minecraft:light[level=14]
setblock 340 73 568 minecraft:light[level=14]
setblock 340 73 576 minecraft:light[level=14]
fill 340 73 583 342 73 583 minecraft:dark_oak_log
setblock 340 73 597 minecraft:oak_log
fill 340 73 598 340 76 598 minecraft:green_terracotta
setblock 341 73 560 minecraft:green_terracotta
fill 341 73 597 341 75 597 minecraft:green_terracotta
setblock 342 73 560 minecraft:oak_log
setblock 343 73 559 minecraft:oak_log
fill 343 73 560 343 76 560 minecraft:green_terracotta
setblock 344 73 558 minecraft:oak_log
fill 344 73 559 344 76 559 minecraft:green_terracotta
setblock 344 73 584 minecraft:dark_oak_log
setblock 344 73 592 minecraft:dark_oak_log
setblock 344 73 598 minecraft:oak_log
fill 345 73 558 348 73 558 minecraft:green_terracotta
setblock 345 73 585 minecraft:dark_oak_log
setblock 345 73 591 minecraft:dark_oak_log
setblock 345 73 597 minecraft:oak_log
fill 345 73 598 345 76 598 minecraft:green_terracotta
fill 346 73 587 346 73 589 minecraft:dark_oak_log
setblock 346 73 597 minecraft:green_terracotta
setblock 348 73 559 minecraft:oak_log
setblock 348 73 560 minecraft:light[level=14]
setblock 348 73 568 minecraft:light[level=14]
setblock 348 73 576 minecraft:light[level=14]
setblock 348 73 584 minecraft:light[level=14]
setblock 348 73 592 minecraft:light[level=14]
setblock 349 73 558 minecraft:oak_log
fill 349 73 559 349 76 559 minecraft:green_terracotta
setblock 349 73 598 minecraft:oak_log
fill 350 73 558 353 73 558 minecraft:green_terracotta
fill 350 73 598 353 73 598 minecraft:green_terracotta
setblock 353 73 559 minecraft:oak_log
setblock 354 73 558 minecraft:oak_log
fill 354 73 559 354 76 559 minecraft:green_terracotta
setblock 354 73 597 minecraft:green_terracotta
setblock 354 73 598 minecraft:oak_log
fill 355 73 558 355 76 558 minecraft:green_terracotta
setblock 355 73 597 minecraft:oak_log
fill 355 73 598 355 76 598 minecraft:green_terracotta
setblock 356 73 560 minecraft:light[level=14]
setblock 356 73 568 minecraft:light[level=14]
setblock 356 73 576 minecraft:light[level=14]
setblock 356 73 584 minecraft:light[level=14]
setblock 356 73 592 minecraft:light[level=14]
fill 356 73 597 356 76 597 minecraft:green_terracotta
setblock 357 73 560 minecraft:oak_log
setblock 358 73 559 minecraft:oak_log
fill 358 73 560 358 76 560 minecraft:green_terracotta
setblock 359 73 558 minecraft:oak_log
fill 359 73 559 359 76 559 minecraft:green_terracotta
setblock 359 73 598 minecraft:oak_log
fill 360 73 558 360 76 558 minecraft:green_terracotta
setblock 360 73 597 minecraft:oak_log
fill 360 73 598 360 76 598 minecraft:green_terracotta
setblock 361 73 596 minecraft:oak_log
fill 361 73 597 361 76 597 minecraft:green_terracotta
setblock 362 73 560 minecraft:oak_log
setblock 362 73 595 minecraft:oak_log
fill 362 73 596 362 76 596 minecraft:green_terracotta
setblock 363 73 559 minecraft:oak_log
fill 363 73 560 363 75 560 minecraft:green_terracotta
setblock 363 73 595 minecraft:green_terracotta
setblock 364 73 558 minecraft:oak_log
fill 364 73 559 364 76 559 minecraft:green_terracotta
setblock 364 73 568 minecraft:light[level=14]
setblock 364 73 576 minecraft:light[level=14]
setblock 364 73 584 minecraft:light[level=14]
setblock 364 73 592 minecraft:light[level=14]
setblock 364 73 598 minecraft:oak_log
fill 365 73 558 365 76 558 minecraft:green_terracotta
setblock 365 73 597 minecraft:oak_log
fill 365 73 598 365 76 598 minecraft:green_terracotta
setblock 366 73 596 minecraft:oak_log
fill 366 73 597 366 76 597 minecraft:green_terracotta
fill 367 73 596 367 74 596 minecraft:green_terracotta
setblock 368 73 595 minecraft:green_terracotta
setblock 369 73 558 minecraft:oak_log
setblock 369 73 578 minecraft:oak_log
setblock 369 73 579 minecraft:green_terracotta
setblock 369 73 593 minecraft:oak_log
setblock 369 73 594 minecraft:green_terracotta
setblock 369 73 598 minecraft:oak_log
fill 370 73 558 370 74 558 minecraft:green_terracotta
setblock 370 73 577 minecraft:oak_log
fill 370 73 578 370 76 578 minecraft:green_terracotta
setblock 370 73 582 minecraft:oak_log
fill 370 73 583 370 76 583 minecraft:green_terracotta
setblock 370 73 592 minecraft:oak_log
fill 370 73 593 370 74 593 minecraft:green_terracotta
setblock 370 73 597 minecraft:oak_log
fill 370 73 598 370 76 598 minecraft:green_terracotta
setblock 330 74 565 minecraft:oak_leaves[persistent=true]
fill 330 74 573 330 74 575 minecraft:green_terracotta
setblock 330 74 576 minecraft:oak_log
fill 330 74 577 330 77 577 minecraft:green_terracotta
setblock 330 74 581 minecraft:oak_log
fill 330 74 582 330 77 582 minecraft:green_terracotta
setblock 330 74 596 minecraft:oak_log
fill 330 74 597 330 74 598 minecraft:green_terracotta
setblock 331 74 576 minecraft:green_terracotta
setblock 331 74 580 minecraft:oak_log
fill 331 74 581 331 77 581 minecraft:green_terracotta
fill 334 74 558 334 75 558 minecraft:oak_leaves[persistent=true]
fill 335 74 558 337 74 558 minecraft:green_terracotta
fill 335 74 582 335 76 583 minecraft:oak_log
fill 335 74 598 337 74 598 minecraft:green_terracotta
setblock 338 74 558 minecraft:oak_log
fill 338 74 559 341 74 559 minecraft:green_terracotta
setblock 338 74 598 minecraft:oak_log
fill 339 74 558 339 77 558 minecraft:green_terracotta
setblock 339 74 597 minecraft:oak_log
fill 339 74 598 339 77 598 minecraft:green_terracotta
setblock 340 74 560 minecraft:green_terracotta
setblock 340 74 597 minecraft:green_terracotta
setblock 341 74 560 minecraft:oak_log
fill 341 74 588 341 77 588 minecraft:oak_log
setblock 342 74 559 minecraft:oak_log
fill 342 74 560 342 77 560 minecraft:green_terracotta
setblock 343 74 558 minecraft:oak_log
fill 343 74 559 343 77 559 minecraft:green_terracotta
setblock 343 74 598 minecraft:oak_log
fill 344 74 558 347 74 558 minecraft:green_terracotta
setblock 344 74 597 minecraft:oak_log
fill 344 74 598 344 77 598 minecraft:green_terracotta
setblock 345 74 560 minecraft:green_terracotta
fill 345 74 591 345 80 591 minecraft:iron_block
setblock 345 74 597 minecraft:green_terracotta
setblock 346 74 560 minecraft:oak_log
setblock 347 74 559 minecraft:oak_log
setblock 348 74 558 minecraft:oak_log
fill 348 74 559 348 77 559 minecraft:green_terracotta
setblock 348 74 598 minecraft:oak_log
fill 349 74 558 352 74 558 minecraft:green_terracotta
fill 349 74 598 352 74 598 minecraft:green_terracotta
setblock 352 74 559 minecraft:oak_log
setblock 353 74 558 minecraft:oak_log
fill 353 74 559 353 77 559 minecraft:green_terracotta
setblock 353 74 598 minecraft:oak_log
fill 354 74 558 354 77 558 minecraft:green_terracotta
fill 354 74 598 354 77 598 minecraft:green_terracotta
fill 355 74 597 355 76 597 minecraft:green_terracotta
setblock 357 74 559 minecraft:oak_log
fill 357 74 560 357 77 560 minecraft:green_terracotta
setblock 358 74 558 minecraft:oak_log
fill 358 74 559 358 77 559 minecraft:green_terracotta
setblock 358 74 598 minecraft:oak_log
fill 359 74 558 359 77 558 minecraft:green_terracotta
setblock 359 74 597 minecraft:oak_log
fill 359 74 598 359 77 598 minecraft:green_terracotta
setblock 360 74 596 minecraft:oak_log
fill 360 74 597 360 77 597 minecraft:green_terracotta
setblock 361 74 560 minecraft:oak_log
fill 361 74 596 361 77 596 minecraft:green_terracotta
setblock 362 74 559 minecraft:oak_log
fill 362 74 560 362 77 560 minecraft:green_terracotta
setblock 363 74 558 minecraft:oak_log
fill 363 74 559 363 77 559 minecraft:green_terracotta
setblock 363 74 598 minecraft:oak_log
fill 364 74 558 364 77 558 minecraft:green_terracotta
setblock 364 74 597 minecraft:oak_log
fill 364 74 598 364 77 598 minecraft:green_terracotta
setblock 365 74 596 minecraft:oak_log
fill 365 74 597 365 77 597 minecraft:green_terracotta
setblock 366 74 596 minecraft:green_terracotta
setblock 367 74 559 minecraft:oak_log
setblock 368 74 558 minecraft:oak_log
setblock 368 74 598 minecraft:oak_log
fill 369 74 558 369 75 558 minecraft:green_terracotta
setblock 369 74 597 minecraft:oak_log
fill 369 74 598 369 77 598 minecraft:green_terracotta
setblock 370 74 572 minecraft:oak_leaves[persistent=true]
setblock 370 74 576 minecraft:oak_log
fill 370 74 577 370 75 577 minecraft:green_terracotta
setblock 370 74 581 minecraft:oak_log
fill 370 74 582 370 77 582 minecraft:green_terracotta
setblock 370 74 591 minecraft:oak_leaves[persistent=true]
setblock 370 74 592 minecraft:green_terracotta
setblock 370 74 596 minecraft:oak_log
fill 370 74 597 370 76 597 minecraft:green_terracotta
setblock 330 75 571 minecraft:oak_leaves[persistent=true]
setblock 330 75 574 minecraft:green_terracotta
setblock 330 75 575 minecraft:oak_log
fill 330 75 576 330 78 576 minecraft:green_terracotta
setblock 330 75 580 minecraft:oak_log
fill 330 75 581 330 78 581 minecraft:green_terracotta
setblock 330 75 585 minecraft:oak_log
setblock 330 75 590 minecraft:oak_leaves[persistent=true]
setblock 331 75 579 minecraft:oak_log
fill 331 75 580 331 78 580 minecraft:green_terracotta
fill 335 75 558 336 75 558 minecraft:green_terracotta
setblock 336 75 598 minecraft:green_terracotta
setblock 337 75 558 minecraft:oak_log
fill 337 75 559 340 75 559 minecraft:green_terracotta
setblock 337 75 598 minecraft:oak_log
fill 338 75 558 338 78 558 minecraft:green_terracotta
fill 338 75 598 338 78 598 minecraft:green_terracotta
setblock 340 75 560 minecraft:oak_log
setblock 341 75 559 minecraft:oak_log
fill 341 75 560 341 78 560 minecraft:green_terracotta
setblock 342 75 558 minecraft:oak_log
fill 342 75 559 342 78 559 minecraft:green_terracotta
setblock 342 75 598 minecraft:oak_log
fill 343 75 558 346 75 558 minecraft:green_terracotta
fill 343 75 598 343 78 598 minecraft:green_terracotta
setblock 345 75 560 minecraft:oak_log
setblock 346 75 559 minecraft:oak_log
setblock 347 75 558 minecraft:oak_log
fill 347 75 559 347 78 559 minecraft:green_terracotta
setblock 347 75 598 minecraft:oak_log
fill 348 75 558 351 75 558 minecraft:green_terracotta
fill 348 75 598 351 75 598 minecraft:green_terracotta
setblock 351 75 559 minecraft:oak_log
setblock 352 75 558 minecraft:oak_log
fill 352 75 559 352 78 559 minecraft:green_terracotta
setblock 352 75 598 minecraft:oak_log
fill 353 75 558 353 78 558 minecraft:green_terracotta
fill 353 75 598 353 78 598 minecraft:green_terracotta
setblock 356 75 559 minecraft:oak_log
setblock 357 75 558 minecraft:oak_log
fill 357 75 559 357 78 559 minecraft:green_terracotta
setblock 357 75 598 minecraft:oak_log
fill 358 75 558 358 78 558 minecraft:green_terracotta
setblock 358 75 597 minecraft:oak_log
fill 358 75 598 358 78 598 minecraft:green_terracotta
setblock 359 75 596 minecraft:oak_log
fill 359 75 597 359 78 597 minecraft:green_terracotta
setblock 360 75 560 minecraft:oak_log
fill 360 75 596 360 77 596 minecraft:green_terracotta
setblock 361 75 559 minecraft:oak_log
fill 361 75 560 361 78 560 minecraft:green_terracotta
setblock 362 75 558 minecraft:oak_log
fill 362 75 559 362 78 559 minecraft:green_terracotta
setblock 362 75 598 minecraft:oak_log
fill 363 75 558 363 78 558 minecraft:green_terracotta
setblock 363 75 597 minecraft:oak_log
fill 363 75 598 363 78 598 minecraft:green_terracotta
setblock 364 75 596 minecraft:oak_log
fill 364 75 597 364 78 597 minecraft:green_terracotta
setblock 365 75 596 minecraft:green_terracotta
setblock 366 75 559 minecraft:oak_log
setblock 367 75 558 minecraft:oak_log
setblock 367 75 598 minecraft:oak_log
fill 368 75 558 368 76 558 minecraft:green_terracotta
setblock 368 75 597 minecraft:oak_log
fill 368 75 598 368 78 598 minecraft:green_terracotta
setblock 369 75 597 minecraft:green_terracotta
fill 370 75 560 370 76 560 minecraft:oak_leaves[persistent=true]
setblock 370 75 566 minecraft:oak_leaves[persistent=true]
setblock 370 75 580 minecraft:oak_log
fill 370 75 581 370 78 581 minecraft:green_terracotta
setblock 370 75 585 minecraft:oak_leaves[persistent=true]
setblock 370 75 595 minecraft:oak_log
fill 370 75 596 370 76 596 minecraft:green_terracotta
setblock 330 76 575 minecraft:green_terracotta
setblock 330 76 579 minecraft:oak_log
fill 330 76 580 330 79 580 minecraft:green_terracotta
setblock 330 76 584 minecraft:oak_log
setblock 330 76 596 minecraft:oak_leaves[persistent=true]
setblock 331 76 578 minecraft:oak_log
fill 331 76 579 331 79 579 minecraft:green_terracotta
setblock 335 76 558 minecraft:green_terracotta
setblock 336 76 558 minecraft:oak_log
setblock 336 76 598 minecraft:oak_log
fill 337 76 558 337 78 559 minecraft:green_terracotta
fill 337 76 598 337 79 598 minecraft:green_terracotta
fill 338 76 559 339 76 559 minecraft:green_terracotta
setblock 339 76 560 minecraft:oak_log
setblock 340 76 559 minecraft:oak_log
fill 340 76 560 340 79 560 minecraft:green_terracotta
setblock 341 76 558 minecraft:oak_log
fill 341 76 559 341 79 559 minecraft:green_terracotta
setblock 341 76 598 minecraft:oak_log
fill 342 76 558 345 76 558 minecraft:green_terracotta
fill 342 76 598 342 79 598 minecraft:green_terracotta
setblock 344 76 560 minecraft:oak_log
setblock 345 76 559 minecraft:oak_log
setblock 346 76 558 minecraft:oak_log
fill 346 76 559 346 79 559 minecraft:green_terracotta
setblock 346 76 598 minecraft:oak_log
fill 347 76 558 350 76 558 minecraft:green_terracotta
setblock 347 76 598 minecraft:green_terracotta
setblock 350 76 559 minecraft:oak_log
setblock 351 76 558 minecraft:oak_log
fill 351 76 559 351 79 559 minecraft:green_terracotta
setblock 351 76 598 minecraft:oak_log
fill 352 76 558 352 79 558 minecraft:green_terracotta
fill 352 76 598 352 79 598 minecraft:green_terracotta
setblock 355 76 559 minecraft:oak_log
setblock 356 76 558 minecraft:oak_log
fill 356 76 559 356 78 560 minecraft:green_terracotta
setblock 356 76 598 minecraft:oak_log
fill 357 76 558 357 79 558 minecraft:green_terracotta
setblock 357 76 597 minecraft:oak_log
fill 357 76 598 357 79 598 minecraft:green_terracotta
fill 358 76 597 358 79 597 minecraft:green_terracotta
setblock 359 76 560 minecraft:oak_log
setblock 359 76 596 minecraft:green_terracotta
setblock 360 76 559 minecraft:oak_log
fill 360 76 560 360 79 560 minecraft:green_terracotta
fill 360 76 563 360 84 563 minecraft:iron_block
setblock 361 76 558 minecraft:oak_log
fill 361 76 559 361 79 559 minecraft:green_terracotta
setblock 361 76 598 minecraft:oak_log
fill 362 76 558 362 79 558 minecraft:green_terracotta
setblock 362 76 597 minecraft:oak_log
fill 362 76 598 362 79 598 minecraft:green_terracotta
setblock 363 76 596 minecraft:oak_log
fill 363 76 597 363 79 597 minecraft:green_terracotta
setblock 364 76 596 minecraft:green_terracotta
setblock 365 76 559 minecraft:oak_log
setblock 366 76 558 minecraft:oak_log
setblock 366 76 598 minecraft:oak_log
fill 367 76 558 367 77 558 minecraft:green_terracotta
setblock 367 76 597 minecraft:oak_log
fill 367 76 598 367 78 598 minecraft:green_terracotta
setblock 370 76 579 minecraft:oak_log
fill 370 76 580 370 79 580 minecraft:green_terracotta
setblock 370 76 584 minecraft:oak_log
setblock 330 77 558 minecraft:oak_leaves[persistent=true]
setblock 330 77 578 minecraft:oak_log
fill 330 77 579 330 80 579 minecraft:green_terracotta
setblock 330 77 583 minecraft:oak_log
fill 330 77 584 330 79 585 minecraft:green_terracotta
setblock 331 77 578 minecraft:green_terracotta
setblock 331 77 582 minecraft:oak_log
fill 333 77 582 336 79 583 minecraft:oak_leaves[persistent=true]
setblock 334 77 558 minecraft:green_terracotta
fill 334 77 581 336 79 581 minecraft:oak_leaves[persistent=true]
fill 334 77 584 336 79 584 minecraft:oak_leaves[persistent=true]
setblock 334 77 598 minecraft:oak_leaves[persistent=true]
setblock 335 77 558 minecraft:oak_log
fill 336 77 558 336 79 559 minecraft:green_terracotta
setblock 338 77 559 minecraft:green_terracotta
setblock 339 77 559 minecraft:oak_log
fill 339 77 560 339 80 560 minecraft:green_terracotta
setblock 340 77 558 minecraft:oak_log
fill 340 77 559 340 80 559 minecraft:green_terracotta
fill 340 77 587 340 79 589 minecraft:oak_leaves[persistent=true]
setblock 340 77 598 minecraft:oak_log
fill 341 77 558 344 77 558 minecraft:green_terracotta
fill 341 77 586 341 79 587 minecraft:oak_leaves[persistent=true]
fill 341 77 589 342 79 589 minecraft:oak_leaves[persistent=true]
fill 341 77 598 341 80 598 minecraft:green_terracotta
fill 342 77 587 342 79 588 minecraft:oak_leaves[persistent=true]
setblock 343 77 560 minecraft:oak_log
fill 343 77 588 343 79 588 minecraft:oak_leaves[persistent=true]
setblock 344 77 559 minecraft:oak_log
fill 344 77 560 344 80 560 minecraft:green_terracotta
setblock 345 77 558 minecraft:oak_log
fill 345 77 559 345 80 559 minecraft:green_terracotta
setblock 345 77 598 minecraft:oak_log
fill 346 77 558 349 77 558 minecraft:green_terracotta
setblock 349 77 559 minecraft:oak_log
setblock 350 77 558 minecraft:oak_log
fill 350 77 559 350 80 559 minecraft:green_terracotta
fill 351 77 558 351 80 558 minecraft:green_terracotta
setblock 354 77 559 minecraft:oak_log
setblock 355 77 558 minecraft:oak_log
fill 355 77 559 355 80 559 minecraft:green_terracotta
setblock 355 77 598 minecraft:oak_log
fill 356 77 558 356 80 558 minecraft:green_terracotta
setblock 356 77 597 minecraft:oak_log
fill 356 77 598 356 80 598 minecraft:green_terracotta
fill 357 77 597 357 80 597 minecraft:green_terracotta
setblock 358 77 560 minecraft:oak_log
setblock 359 77 559 minecraft:oak_log
fill 359 77 560 359 80 560 minecraft:green_terracotta
setblock 360 77 558 minecraft:oak_log
fill 360 77 559 360 80 559 minecraft:green_terracotta
setblock 360 77 598 minecraft:oak_log
fill 361 77 558 361 80 558 minecraft:green_terracotta
setblock 361 77 597 minecraft:oak_log
fill 361 77 598 361 80 598 minecraft:green_terracotta
setblock 362 77 596 minecraft:oak_log
fill 362 77 597 362 80 597 minecraft:green_terracotta
setblock 364 77 559 minecraft:oak_log
setblock 365 77 558 minecraft:oak_log
setblock 365 77 559 minecraft:green_terracotta
setblock 365 77 598 minecraft:oak_log
fill 366 77 558 366 79 558 minecraft:green_terracotta
fill 366 77 598 366 80 598 minecraft:green_terracotta
setblock 370 77 573 minecraft:oak_leaves[persistent=true]
setblock 370 77 578 minecraft:oak_log
fill 370 77 579 370 80 579 minecraft:green_terracotta
setblock 370 77 583 minecraft:oak_log
fill 370 77 584 370 79 585 minecraft:green_terracotta
setblock 370 77 592 minecraft:oak_leaves[persistent=true]
setblock 330 78 564 minecraft:oak_leaves[persistent=true]
fill 330 78 570 330 79 570 minecraft:oak_leaves[persistent=true]
setblock 330 78 577 minecraft:oak_log
fill 330 78 578 330 81 578 minecraft:green_terracotta
setblock 330 78 582 minecraft:oak_log
fill 330 78 583 330 81 583 minecraft:green_terracotta
setblock 330 78 589 minecraft:oak_leaves[persistent=true]
setblock 331 78 581 minecraft:oak_log
fill 331 78 582 331 81 582 minecraft:green_terracotta
setblock 333 78 584 minecraft:oak_leaves[persistent=true]
setblock 334 78 558 minecraft:oak_log
fill 335 78 558 335 81 558 minecraft:green_terracotta
fill 337 78 582 337 78 583 minecraft:oak_leaves[persistent=true]
setblock 338 78 559 minecraft:oak_log
fill 338 78 560 338 81 560 minecraft:green_terracotta
setblock 339 78 558 minecraft:oak_log
fill 339 78 559 339 81 559 minecraft:green_terracotta
fill 339 78 587 339 78 588 minecraft:oak_leaves[persistent=true]
setblock 339 78 598 minecraft:oak_log
fill 340 78 558 343 78 558 minecraft:green_terracotta
setblock 340 78 586 minecraft:oak_leaves[persistent=true]
fill 340 78 598 340 81 598 minecraft:green_terracotta
fill 341 78 588 341 79 588 minecraft:oak_leaves[persistent=true]
fill 341 78 590 342 78 590 minecraft:oak_leaves[persistent=true]
fill 341 78 593 342 79 593 minecraft:oak_leaves[persistent=true]
setblock 342 78 560 minecraft:oak_log
setblock 342 78 586 minecraft:oak_leaves[persistent=true]
setblock 343 78 559 minecraft:oak_log
fill 343 78 560 343 81 560 minecraft:green_terracotta
setblock 343 78 587 minecraft:oak_leaves[persistent=true]
setblock 343 78 589 minecraft:oak_leaves[persistent=true]
setblock 344 78 558 minecraft:oak_log
fill 344 78 559 344 81 559 minecraft:green_terracotta
fill 344 78 590 344 79 591 minecraft:glowstone
fill 345 78 558 348 78 558 minecraft:green_terracotta
fill 345 78 590 345 79 590 minecraft:glowstone
setblock 346 78 598 minecraft:oak_leaves[persistent=true]
setblock 348 78 559 minecraft:oak_log
setblock 349 78 558 minecraft:oak_log
fill 349 78 559 349 81 559 minecraft:green_terracotta
fill 350 78 558 350 81 558 minecraft:green_terracotta
setblock 353 78 559 minecraft:oak_log
setblock 354 78 558 minecraft:oak_log
fill 354 78 559 354 81 559 minecraft:green_terracotta
setblock 354 78 598 minecraft:oak_log
fill 355 78 558 355 81 558 minecraft:green_terracotta
fill 355 78 560 355 79 560 minecraft:green_terracotta
fill 355 78 598 355 81 598 minecraft:green_terracotta
fill 356 78 597 356 81 597 minecraft:green_terracotta
setblock 357 78 560 minecraft:oak_log
setblock 358 78 559 minecraft:oak_log
fill 358 78 560 358 81 560 minecraft:green_terracotta
setblock 359 78 558 minecraft:oak_log
fill 359 78 559 359 81 559 minecraft:green_terracotta
setblock 359 78 598 minecraft:oak_log
fill 360 78 558 360 81 558 minecraft:green_terracotta
setblock 360 78 597 minecraft:oak_log
fill 360 78 598 360 81 598 minecraft:green_terracotta
fill 361 78 597 361 81 597 minecraft:green_terracotta
setblock 363 78 559 minecraft:oak_log
setblock 364 78 558 minecraft:oak_log
setblock 364 78 559 minecraft:green_terracotta
setblock 364 78 598 minecraft:oak_log
fill 365 78 558 365 81 558 minecraft:green_terracotta
fill 365 78 598 365 81 598 minecraft:green_terracotta
setblock 370 78 567 minecraft:oak_leaves[persistent=true]
setblock 370 78 582 minecraft:oak_log
fill 370 78 583 370 81 583 minecraft:green_terracotta
setblock 370 78 586 minecraft:green_terracotta
setblock 330 79 576 minecraft:oak_log
fill 330 79 577 330 82 577 minecraft:green_terracotta
setblock 330 79 581 minecraft:oak_log
fill 330 79 582 330 82 582 minecraft:green_terracotta
setblock 330 79 586 minecraft:oak_log
setblock 330 79 595 minecraft:oak_leaves[persistent=true]
fill 331 79 578 331 80 578 minecraft:green_terracotta
setblock 331 79 580 minecraft:oak_log
fill 331 79 581 331 82 581 minecraft:green_terracotta
fill 331 79 583 331 80 583 minecraft:green_terracotta
setblock 333 79 558 minecraft:oak_log
fill 334 79 558 334 82 558 minecraft:green_terracotta
fill 335 79 559 335 80 559 minecraft:green_terracotta
setblock 337 79 558 minecraft:green_terracotta
setblock 337 79 559 minecraft:oak_log
fill 337 79 560 337 82 560 minecraft:green_terracotta
setblock 338 79 558 minecraft:oak_log
fill 338 79 559 338 82 559 minecraft:green_terracotta
setblock 338 79 598 minecraft:oak_log
fill 339 79 558 342 79 558 minecraft:green_terracotta
fill 339 79 598 339 82 598 minecraft:green_terracotta
setblock 341 79 560 minecraft:oak_log
setblock 342 79 559 minecraft:oak_log
fill 342 79 560 342 82 560 minecraft:green_terracotta
setblock 343 79 558 minecraft:oak_log
fill 343 79 559 343 82 559 minecraft:green_terracotta
fill 344 79 558 347 79 558 minecraft:green_terracotta
setblock 347 79 559 minecraft:oak_log
setblock 348 79 558 minecraft:oak_log
fill 348 79 559 348 82 559 minecraft:green_terracotta
fill 349 79 558 349 82 558 minecraft:green_terracotta
setblock 352 79 559 minecraft:oak_log
setblock 353 79 558 minecraft:oak_log
fill 353 79 559 353 82 559 minecraft:green_terracotta
setblock 353 79 598 minecraft:oak_log
fill 354 79 558 354 82 558 minecraft:green_terracotta
fill 354 79 560 354 80 560 minecraft:green_terracotta
fill 354 79 598 354 82 598 minecraft:green_terracotta
fill 355 79 597 355 82 597 minecraft:green_terracotta
setblock 356 79 559 minecraft:green_terracotta
setblock 356 79 560 minecraft:oak_log
setblock 357 79 559 minecraft:oak_log
fill 357 79 560 357 82 560 minecraft:green_terracotta
setblock 358 79 558 minecraft:oak_log
fill 358 79 559 358 82 559 minecraft:green_terracotta
setblock 358 79 598 minecraft:oak_log
fill 359 79 558 359 82 558 minecraft:green_terracotta
setblock 359 79 597 minecraft:oak_log
fill 359 79 598 359 82 598 minecraft:green_terracotta
fill 360 79 597 360 82 597 minecraft:green_terracotta
setblock 361 79 560 minecraft:oak_log
setblock 362 79 559 minecraft:oak_log
setblock 363 79 558 minecraft:oak_log
fill 363 79 559 363 81 559 minecraft:green_terracotta
setblock 363 79 598 minecraft:oak_log
fill 364 79 558 364 82 558 minecraft:green_terracotta
fill 364 79 598 364 82 598 minecraft:green_terracotta
setblock 370 79 561 minecraft:oak_leaves[persistent=true]
fill 370 79 578 370 81 578 minecraft:green_terracotta
setblock 370 79 581 minecraft:oak_log
fill 370 79 582 370 82 582 minecraft:green_terracotta
setblock 370 79 586 minecraft:oak_log
fill 370 79 587 370 82 587 minecraft:green_terracotta
fill 330 80 576 330 83 576 minecraft:green_terracotta
setblock 330 80 580 minecraft:oak_log
fill 330 80 581 330 83 581 minecraft:green_terracotta
setblock 330 80 584 minecraft:green_terracotta
setblock 330 80 585 minecraft:oak_log
fill 330 80 586 330 82 587 minecraft:green_terracotta
setblock 331 80 579 minecraft:oak_log
fill 331 80 580 331 83 580 minecraft:green_terracotta
setblock 331 80 584 minecraft:oak_log
fill 333 80 558 333 83 558 minecraft:green_terracotta
setblock 333 80 598 minecraft:oak_leaves[persistent=true]
fill 334 80 559 334 81 559 minecraft:green_terracotta
setblock 336 80 558 minecraft:green_terracotta
setblock 336 80 559 minecraft:oak_log
fill 336 80 560 336 83 560 minecraft:green_terracotta
setblock 337 80 558 minecraft:oak_log
fill 337 80 559 337 83 559 minecraft:green_terracotta
setblock 337 80 598 minecraft:oak_log
fill 338 80 558 341 80 558 minecraft:green_terracotta
fill 338 80 598 338 83 598 minecraft:green_terracotta
setblock 340 80 560 minecraft:oak_log
setblock 341 80 559 minecraft:oak_log
fill 341 80 560 341 83 560 minecraft:green_terracotta
setblock 342 80 558 minecraft:oak_log
fill 342 80 559 342 83 559 minecraft:green_terracotta
fill 343 80 558 346 80 558 minecraft:green_terracotta
setblock 346 80 559 minecraft:oak_log
setblock 347 80 558 minecraft:oak_log
fill 347 80 559 347 83 559 minecraft:green_terracotta
fill 348 80 558 348 83 558 minecraft:green_terracotta
setblock 351 80 559 minecraft:oak_log
setblock 352 80 558 minecraft:oak_log
fill 352 80 559 352 83 559 minecraft:green_terracotta
setblock 352 80 598 minecraft:oak_log
fill 353 80 558 353 83 558 minecraft:green_terracotta
fill 353 80 560 353 81 560 minecraft:green_terracotta
fill 353 80 598 353 83 598 minecraft:green_terracotta
setblock 355 80 560 minecraft:oak_log
setblock 356 80 559 minecraft:oak_log
fill 356 80 560 356 83 560 minecraft:green_terracotta
setblock 357 80 558 minecraft:oak_log
fill 357 80 559 357 83 559 minecraft:green_terracotta
setblock 357 80 598 minecraft:oak_log
fill 358 80 558 358 83 558 minecraft:green_terracotta
setblock 358 80 597 minecraft:oak_log
fill 358 80 598 358 83 598 minecraft:green_terracotta
fill 359 80 597 359 83 597 minecraft:green_terracotta
setblock 360 80 560 minecraft:oak_log
setblock 361 80 559 minecraft:oak_log
fill 361 80 560 361 81 560 minecraft:green_terracotta
setblock 362 80 558 minecraft:oak_log
fill 362 80 559 362 83 559 minecraft:green_terracotta
setblock 362 80 598 minecraft:oak_log
fill 363 80 558 363 83 558 minecraft:green_terracotta
setblock 363 80 597 minecraft:oak_log
fill 363 80 598 363 83 598 minecraft:green_terracotta
setblock 367 80 558 minecraft:oak_leaves[persistent=true]
fill 369 80 582 369 81 584 minecraft:green_terracotta
setblock 370 80 574 minecraft:oak_leaves[persistent=true]
setblock 370 80 580 minecraft:oak_log
fill 370 80 581 370 83 581 minecraft:green_terracotta
setblock 370 80 584 minecraft:green_terracotta
setblock 370 80 585 minecraft:oak_log
fill 370 80 586 370 83 586 minecraft:green_terracotta
fill 370 80 588 370 81 588 minecraft:green_terracotta
fill 330 81 560 330 81 563 minecraft:green_terracotta
setblock 330 81 564 minecraft:oak_log
fill 330 81 565 330 84 565 minecraft:green_terracotta
fill 330 81 575 330 84 575 minecraft:green_terracotta
setblock 330 81 579 minecraft:oak_log
fill 330 81 580 330 84 580 minecraft:green_terracotta
setblock 330 81 584 minecraft:oak_log
fill 330 81 585 331 83 585 minecraft:green_terracotta
setblock 330 81 588 minecraft:green_terracotta
setblock 331 81 578 minecraft:oak_log
fill 331 81 579 331 84 579 minecraft:green_terracotta
setblock 331 81 583 minecraft:oak_log
fill 331 81 584 331 84 584 minecraft:green_terracotta
fill 331 81 586 331 82 586 minecraft:green_terracotta
fill 332 81 558 332 84 558 minecraft:green_terracotta
setblock 332 81 560 minecraft:light[level=14]
setblock 332 81 568 minecraft:light[level=14]
setblock 332 81 576 minecraft:light[level=14]
setblock 332 81 581 minecraft:green_terracotta
setblock 332 81 582 minecraft:oak_log
fill 332 81 583 332 84 583 minecraft:green_terracotta
setblock 332 81 584 minecraft:light[level=14]
setblock 332 81 592 minecraft:light[level=14]
fill 333 81 559 333 82 559 minecraft:green_terracotta
setblock 335 81 559 minecraft:oak_log
fill 335 81 560 335 84 560 minecraft:green_terracotta
setblock 336 81 558 minecraft:oak_log
fill 336 81 559 336 84 559 minecraft:green_terracotta
setblock 336 81 598 minecraft:oak_log
fill 337 81 558 340 81 558 minecraft:green_terracotta
setblock 337 81 561 minecraft:green_terracotta
fill 337 81 598 337 84 598 minecraft:green_terracotta
setblock 338 81 561 minecraft:oak_log
setblock 339 81 560 minecraft:oak_log
fill 339 81 561 340 83 561 minecraft:green_terracotta
setblock 340 81 559 minecraft:oak_log
fill 340 81 560 340 84 560 minecraft:green_terracotta
setblock 340 81 568 minecraft:light[level=14]
setblock 340 81 576 minecraft:light[level=14]
setblock 340 81 584 minecraft:light[level=14]
setblock 340 81 592 minecraft:light[level=14]
setblock 341 81 558 minecraft:oak_log
fill 341 81 559 341 84 559 minecraft:green_terracotta
setblock 341 81 598 minecraft:oak_log
fill 342 81 558 345 81 558 minecraft:green_terracotta
setblock 344 81 560 minecraft:oak_log
setblock 345 81 559 minecraft:oak_log
setblock 346 81 558 minecraft:oak_log
fill 346 81 559 346 84 559 minecraft:green_terracotta
fill 347 81 558 347 84 558 minecraft:green_terracotta
setblock 348 81 560 minecraft:light[level=14]
setblock 348 81 568 minecraft:light[level=14]
setblock 348 81 576 minecraft:light[level=14]
setblock 348 81 584 minecraft:light[level=14]
setblock 348 81 592 minecraft:light[level=14]
setblock 350 81 559 minecraft:oak_log
setblock 351 81 558 minecraft:oak_log
fill 351 81 559 351 84 559 minecraft:green_terracotta
setblock 351 81 598 minecraft:oak_log
fill 352 81 558 352 84 558 minecraft:green_terracotta
fill 352 81 560 352 82 560 minecraft:green_terracotta
fill 352 81 598 352 84 598 minecraft:green_terracotta
setblock 354 81 560 minecraft:oak_log
fill 354 81 597 354 83 597 minecraft:green_terracotta
setblock 355 81 559 minecraft:oak_log
fill 355 81 560 355 84 560 minecraft:green_terracotta
setblock 356 81 558 minecraft:oak_log
fill 356 81 559 356 84 559 minecraft:green_terracotta
setblock 356 81 568 minecraft:light[level=14]
setblock 356 81 576 minecraft:light[level=14]
setblock 356 81 584 minecraft:light[level=14]
setblock 356 81 592 minecraft:light[level=14]
setblock 356 81 598 minecraft:oak_log
fill 357 81 558 357 84 558 minecraft:green_terracotta
setblock 357 81 597 minecraft:oak_log
fill 357 81 598 357 84 598 minecraft:green_terracotta
fill 358 81 597 358 84 597 minecraft:green_terracotta
setblock 359 81 560 minecraft:oak_log
setblock 360 81 559 minecraft:oak_log
fill 360 81 560 360 83 560 minecraft:green_terracotta
setblock 361 81 558 minecraft:oak_log
fill 361 81 559 361 84 559 minecraft:green_terracotta
setblock 361 81 598 minecraft:oak_log
fill 362 81 558 362 84 558 minecraft:green_terracotta
setblock 362 81 597 minecraft:oak_log
fill 362 81 598 362 84 598 minecraft:green_terracotta
setblock 364 81 560 minecraft:light[level=14]
setblock 364 81 568 minecraft:light[level=14]
setblock 364 81 576 minecraft:light[level=14]
setblock 364 81 584 minecraft:light[level=14]
setblock 364 81 592 minecraft:light[level=14]
fill 369 81 581 369 84 581 minecraft:green_terracotta
setblock 369 81 585 minecraft:oak_log
fill 369 81 586 369 84 586 minecraft:green_terracotta
setblock 370 81 568 minecraft:oak_leaves[persistent=true]
setblock 370 81 579 minecraft:oak_log
fill 370 81 580 370 84 580 minecraft:green_terracotta
setblock 370 81 584 minecraft:oak_log
fill 370 81 585 370 84 585 minecraft:green_terracotta
setblock 370 81 589 minecraft:oak_log
fill 370 81 590 370 84 590 minecraft:green_terracotta
setblock 370 81 593 minecraft:oak_leaves[persistent=true]
fill 330 82 559 330 82 562 minecraft:green_terracotta
setblock 330 82 563 minecraft:oak_log
fill 330 82 564 331 84 564 minecraft:green_terracotta
fill 330 82 566 330 82 567 minecraft:green_terracotta
setblock 330 82 568 minecraft:oak_log
fill 330 82 569 330 85 569 minecraft:green_terracotta
fill 330 82 574 330 85 574 minecraft:green_terracotta
setblock 330 82 578 minecraft:oak_log
fill 330 82 579 330 85 579 minecraft:green_terracotta
setblock 330 82 583 minecraft:oak_log
fill 330 82 584 330 85 584 minecraft:green_terracotta
setblock 330 82 588 minecraft:oak_log
fill 330 82 589 330 85 589 minecraft:green_terracotta
setblock 330 82 594 minecraft:oak_leaves[persistent=true]
fill 331 82 558 331 85 558 minecraft:green_terracotta
setblock 331 82 561 minecraft:green_terracotta
setblock 331 82 562 minecraft:oak_log
fill 331 82 563 331 85 563 minecraft:green_terracotta
fill 331 82 565 331 82 566 minecraft:green_terracotta
setblock 331 82 577 minecraft:oak_log
fill 331 82 578 331 85 578 minecraft:green_terracotta
setblock 331 82 582 minecraft:oak_log
fill 331 82 583 331 85 583 minecraft:green_terracotta
setblock 331 82 587 minecraft:oak_log
setblock 332 82 580 minecraft:green_terracotta
setblock 332 82 581 minecraft:oak_log
fill 332 82 582 332 85 582 minecraft:green_terracotta
fill 332 82 584 332 82 585 minecraft:green_terracotta
setblock 334 82 559 minecraft:oak_log
fill 334 82 560 334 85 560 minecraft:green_terracotta
setblock 335 82 558 minecraft:oak_log
fill 335 82 559 335 85 559 minecraft:green_terracotta
fill 336 82 558 339 82 558 minecraft:green_terracotta
setblock 336 82 561 minecraft:green_terracotta
fill 336 82 598 336 85 598 minecraft:green_terracotta
setblock 337 82 561 minecraft:oak_log
setblock 338 82 560 minecraft:oak_log
fill 338 82 561 338 85 561 minecraft:green_terracotta
setblock 339 82 559 minecraft:oak_log
fill 339 82 560 339 85 560 minecraft:green_terracotta
setblock 340 82 558 minecraft:oak_log
fill 340 82 559 340 85 559 minecraft:green_terracotta
setblock 340 82 598 minecraft:oak_log
fill 341 82 558 344 82 558 minecraft:green_terracotta
setblock 341 82 561 minecraft:green_terracotta
setblock 343 82 560 minecraft:oak_log
setblock 344 82 559 minecraft:oak_log
fill 344 82 560 344 83 560 minecraft:green_terracotta
setblock 345 82 558 minecraft:oak_log
fill 345 82 559 345 85 559 minecraft:green_terracotta
setblock 345 82 598 minecraft:oak_leaves[persistent=true]
fill 346 82 558 346 85 558 minecraft:green_terracotta
setblock 349 82 559 minecraft:oak_log
setblock 350 82 558 minecraft:oak_log
fill 350 82 559 350 85 559 minecraft:green_terracotta
setblock 350 82 598 minecraft:oak_log
fill 351 82 558 351 85 558 minecraft:green_terracotta
fill 351 82 560 351 83 560 minecraft:green_terracotta
fill 351 82 598 351 85 598 minecraft:green_terracotta
setblock 353 82 560 minecraft:oak_log
fill 353 82 597 353 84 597 minecraft:green_terracotta
setblock 354 82 559 minecraft:oak_log
fill 354 82 560 354 85 560 minecraft:green_terracotta
setblock 355 82 558 minecraft:oak_log
fill 355 82 559 355 85 559 minecraft:green_terracotta
fill 355 82 561 356 82 561 minecraft:green_terracotta
setblock 355 82 598 minecraft:oak_log
fill 356 82 558 356 85 558 minecraft:green_terracotta
setblock 356 82 597 minecraft:oak_log
fill 356 82 598 356 85 598 minecraft:green_terracotta
setblock 357 82 561 minecraft:oak_log
fill 357 82 597 357 85 597 minecraft:green_terracotta
setblock 358 82 560 minecraft:oak_log
setblock 359 82 559 minecraft:oak_log
fill 359 82 560 359 84 560 minecraft:green_terracotta
setblock 360 82 558 minecraft:oak_log
fill 360 82 559 360 85 559 minecraft:green_terracotta
setblock 360 82 598 minecraft:oak_log
fill 361 82 558 361 85 558 minecraft:green_terracotta
setblock 361 82 597 minecraft:oak_log
fill 361 82 598 361 85 598 minecraft:green_terracotta
setblock 362 82 597 minecraft:green_terracotta
setblock 365 82 598 minecraft:oak_log
fill 369 82 580 369 85 580 minecraft:green_terracotta
fill 369 82 582 369 82 583 minecraft:green_terracotta
setblock 369 82 584 minecraft:oak_log
fill 369 82 585 369 85 585 minecraft:green_terracotta
fill 369 82 587 369 82 588 minecraft:green_terracotta
setblock 370 82 562 minecraft:oak_leaves[persistent=true]
setblock 370 82 577 minecraft:green_terracotta
setblock 370 82 578 minecraft:oak_log
fill 370 82 579 370 85 579 minecraft:green_terracotta
setblock 370 82 583 minecraft:oak_log
fill 370 82 584 370 85 584 minecraft:green_terracotta
setblock 370 82 588 minecraft:oak_log
fill 370 82 589 370 85 589 minecraft:green_terracotta
fill 370 82 591 370 83 591 minecraft:green_terracotta
setblock 370 82 598 minecraft:oak_leaves[persistent=true]
fill 330 83 559 330 83 561 minecraft:green_terracotta
setblock 330 83 562 minecraft:oak_log
fill 330 83 563 330 86 563 minecraft:green_terracotta
setblock 330 83 566 minecraft:green_terracotta
setblock 330 83 567 minecraft:oak_log
fill 330 83 568 331 85 568 minecraft:green_terracotta
fill 330 83 570 330 83 571 minecraft:green_terracotta
setblock 330 83 572 minecraft:oak_log
fill 330 83 573 330 86 573 minecraft:green_terracotta
setblock 330 83 577 minecraft:oak_log
fill 330 83 578 330 86 578 minecraft:green_terracotta
setblock 330 83 582 minecraft:oak_log
fill 330 83 583 330 86 583 minecraft:green_terracotta
setblock 330 83 586 minecraft:green_terracotta
setblock 330 83 587 minecraft:oak_log
fill 330 83 588 331 85 588 minecraft:green_terracotta
fill 330 83 590 330 84 590 minecraft:green_terracotta
setblock 331 83 560 minecraft:green_terracotta
setblock 331 83 561 minecraft:oak_log
fill 331 83 562 332 85 562 minecraft:green_terracotta
setblock 331 83 565 minecraft:green_terracotta
setblock 331 83 566 minecraft:oak_log
fill 331 83 567 332 85 567 minecraft:green_terracotta
fill 331 83 569 331 83 570 minecraft:green_terracotta
setblock 331 83 576 minecraft:oak_log
fill 331 83 577 331 86 577 minecraft:green_terracotta
setblock 331 83 581 minecraft:oak_log
fill 331 83 582 331 86 582 minecraft:green_terracotta
setblock 331 83 586 minecraft:oak_log
fill 331 83 587 331 86 587 minecraft:green_terracotta
setblock 332 83 559 minecraft:green_terracotta
fill 332 83 563 332 83 564 minecraft:green_terracotta
fill 332 83 566 332 86 566 minecraft:green_terracotta
setblock 332 83 579 minecraft:green_terracotta
setblock 332 83 580 minecraft:oak_log
fill 332 83 581 332 86 581 minecraft:green_terracotta
setblock 332 83 584 minecraft:green_terracotta
setblock 332 83 585 minecraft:oak_log
fill 332 83 586 332 86 586 minecraft:green_terracotta
setblock 332 83 598 minecraft:oak_leaves[persistent=true]
setblock 333 83 559 minecraft:oak_log
fill 333 83 560 333 86 560 minecraft:green_terracotta
setblock 333 83 566 minecraft:oak_log
setblock 334 83 558 minecraft:oak_log
fill 334 83 559 334 86 559 minecraft:green_terracotta
fill 335 83 558 338 83 558 minecraft:green_terracotta
setblock 335 83 561 minecraft:green_terracotta
fill 335 83 598 335 86 598 minecraft:green_terracotta
setblock 336 83 561 minecraft:oak_log
setblock 337 83 560 minecraft:oak_log
fill 337 83 561 337 86 561 minecraft:green_terracotta
setblock 338 83 559 minecraft:oak_log
fill 338 83 560 338 86 560 minecraft:green_terracotta
setblock 339 83 558 minecraft:oak_log
fill 339 83 559 339 86 559 minecraft:green_terracotta
setblock 339 83 598 minecraft:oak_log
fill 340 83 558 343 83 558 minecraft:green_terracotta
fill 340 83 598 340 84 598 minecraft:green_terracotta
setblock 341 83 561 minecraft:oak_log
setblock 342 83 560 minecraft:oak_log
setblock 343 83 559 minecraft:oak_log
fill 343 83 560 343 84 560 minecraft:green_terracotta
setblock 344 83 558 minecraft:oak_log
fill 344 83 559 344 86 559 minecraft:green_terracotta
fill 345 83 558 345 86 558 minecraft:green_terracotta
setblock 348 83 559 minecraft:oak_log
setblock 349 83 558 minecraft:oak_log
fill 349 83 559 349 86 559 minecraft:green_terracotta
fill 350 83 558 350 86 558 minecraft:green_terracotta
fill 350 83 560 350 84 560 minecraft:green_terracotta
fill 350 83 598 350 86 598 minecraft:green_terracotta
setblock 352 83 560 minecraft:oak_log
setblock 353 83 559 minecraft:oak_log
fill 353 83 560 353 86 560 minecraft:green_terracotta
setblock 354 83 558 minecraft:oak_log
fill 354 83 559 354 86 559 minecraft:green_terracotta
fill 354 83 561 355 83 561 minecraft:green_terracotta
setblock 354 83 598 minecraft:oak_log
fill 355 83 558 355 86 558 minecraft:green_terracotta
setblock 355 83 597 minecraft:oak_log
fill 355 83 598 355 86 598 minecraft:green_terracotta
setblock 356 83 561 minecraft:oak_log
fill 356 83 597 356 86 597 minecraft:green_terracotta
setblock 357 83 560 minecraft:oak_log
setblock 357 83 561 minecraft:green_terracotta
fill 357 83 596 358 85 596 minecraft:green_terracotta
setblock 358 83 559 minecraft:oak_log
fill 358 83 560 358 85 560 minecraft:green_terracotta
setblock 359 83 558 minecraft:oak_log
fill 359 83 559 359 86 559 minecraft:green_terracotta
setblock 359 83 598 minecraft:oak_log
fill 360 83 558 360 86 558 minecraft:green_terracotta
setblock 360 83 597 minecraft:oak_log
fill 360 83 598 360 86 598 minecraft:green_terracotta
fill 361 83 597 361 84 597 minecraft:green_terracotta
setblock 364 83 558 minecraft:oak_log
setblock 364 83 598 minecraft:oak_log
setblock 368 83 558 minecraft:oak_leaves[persistent=true]
setblock 368 83 584 minecraft:oak_log
fill 368 83 585 368 86 585 minecraft:green_terracotta
setblock 369 83 582 minecraft:green_terracotta
setblock 369 83 583 minecraft:oak_log
fill 369 83 584 369 86 584 minecraft:green_terracotta
setblock 369 83 587 minecraft:green_terracotta
setblock 369 83 588 minecraft:oak_log
fill 369 83 589 369 86 589 minecraft:green_terracotta
setblock 370 83 561 minecraft:green_terracotta
setblock 370 83 562 minecraft:oak_log
fill 370 83 563 370 83 566 minecraft:green_terracotta
setblock 370 83 577 minecraft:oak_log
fill 370 83 578 370 86 578 minecraft:green_terracotta
setblock 370 83 582 minecraft:oak_log
fill 370 83 583 370 86 583 minecraft:green_terracotta
setblock 370 83 587 minecraft:oak_log
fill 370 83 588 370 86 588 minecraft:green_terracotta
setblock 370 83 592 minecraft:oak_log
fill 330 84 558 330 84 560 minecraft:green_terracotta
setblock 330 84 561 minecraft:oak_log
fill 330 84 562 330 87 562 minecraft:green_terracotta
setblock 330 84 566 minecraft:oak_log
fill 330 84 567 330 87 567 minecraft:green_terracotta
setblock 330 84 570 minecraft:green_terracotta
setblock 330 84 571 minecraft:oak_log
fill 330 84 572 331 86 572 minecraft:green_terracotta
setblock 330 84 576 minecraft:oak_log
fill 330 84 577 330 87 577 minecraft:green_terracotta
setblock 330 84 581 minecraft:oak_log
fill 330 84 582 330 87 582 minecraft:green_terracotta
setblock 330 84 585 minecraft:green_terracotta
setblock 330 84 586 minecraft:oak_log
fill 330 84 587 330 87 587 minecraft:green_terracotta
setblock 330 84 591 minecraft:oak_log
setblock 331 84 560 minecraft:oak_log
fill 331 84 561 332 86 561 minecraft:green_terracotta
setblock 331 84 565 minecraft:oak_log
fill 331 84 566 331 87 566 minecraft:green_terracotta
setblock 331 84 569 minecraft:green_terracotta
setblock 331 84 570 minecraft:oak_log
fill 331 84 571 331 87 571 minecraft:green_terracotta
fill 331 84 573 331 84 574 minecraft:green_terracotta
setblock 331 84 575 minecraft:oak_log
fill 331 84 576 331 87 576 minecraft:green_terracotta
setblock 331 84 580 minecraft:oak_log
fill 331 84 581 331 87 581 minecraft:green_terracotta
setblock 331 84 585 minecraft:oak_log
fill 331 84 586 331 87 586 minecraft:green_terracotta
setblock 331 84 589 minecraft:green_terracotta
setblock 332 84 559 minecraft:oak_log
setblock 332 84 563 minecraft:green_terracotta
setblock 332 84 564 minecraft:oak_log
fill 332 84 565 333 86 565 minecraft:green_terracotta
setblock 332 84 568 minecraft:green_terracotta
setblock 332 84 569 minecraft:oak_log
fill 332 84 570 332 87 570 minecraft:green_terracotta
fill 332 84 573 332 85 575 minecraft:oak_leaves[persistent=true]
setblock 332 84 579 minecraft:oak_log
fill 332 84 580 332 86 580 minecraft:green_terracotta
setblock 332 84 584 minecraft:oak_log
fill 332 84 585 332 87 585 minecraft:green_terracotta
fill 332 84 587 332 85 587 minecraft:green_terracotta
setblock 333 84 558 minecraft:oak_log
fill 333 84 559 333 87 559 minecraft:green_terracotta
setblock 333 84 563 minecraft:oak_log
fill 333 84 564 333 87 564 minecraft:green_terracotta
fill 333 84 566 333 84 567 minecraft:green_terracotta
fill 333 84 574 333 85 574 minecraft:oak_leaves[persistent=true]
fill 334 84 558 337 84 558 minecraft:green_terracotta
setblock 334 84 561 minecraft:green_terracotta
fill 334 84 598 334 87 598 minecraft:green_terracotta
setblock 335 84 561 minecraft:oak_log
setblock 336 84 560 minecraft:oak_log
fill 336 84 561 336 86 561 minecraft:green_terracotta
setblock 337 84 559 minecraft:oak_log
fill 337 84 560 337 87 560 minecraft:green_terracotta
setblock 338 84 558 minecraft:oak_log
fill 338 84 559 338 87 559 minecraft:green_terracotta
setblock 338 84 598 minecraft:oak_log
fill 339 84 558 342 84 558 minecraft:green_terracotta
setblock 339 84 561 minecraft:green_terracotta
fill 339 84 598 339 85 598 minecraft:green_terracotta
setblock 340 84 561 minecraft:oak_log
setblock 341 84 560 minecraft:oak_log
setblock 342 84 559 minecraft:oak_log
fill 342 84 560 342 85 560 minecraft:green_terracotta
setblock 343 84 558 minecraft:oak_log
fill 343 84 559 343 86 559 minecraft:green_terracotta
fill 344 84 558 344 87 558 minecraft:green_terracotta
setblock 347 84 559 minecraft:oak_log
setblock 348 84 558 minecraft:oak_log
fill 348 84 559 348 87 559 minecraft:green_terracotta
fill 349 84 558 349 87 558 minecraft:green_terracotta
setblock 349 84 560 minecraft:green_terracotta
fill 349 84 598 349 87 598 minecraft:green_terracotta
setblock 351 84 560 minecraft:oak_log
setblock 352 84 559 minecraft:oak_log
fill 352 84 560 352 87 560 minecraft:green_terracotta
fill 352 84 597 352 85 597 minecraft:green_terracotta
setblock 353 84 558 minecraft:oak_log
fill 353 84 559 353 87 559 minecraft:green_terracotta
fill 353 84 561 354 84 561 minecraft:green_terracotta
setblock 353 84 598 minecraft:oak_log
fill 354 84 558 354 87 558 minecraft:green_terracotta
setblock 354 84 597 minecraft:oak_log
fill 354 84 598 354 87 598 minecraft:green_terracotta
setblock 355 84 561 minecraft:oak_log
setblock 355 84 596 minecraft:oak_log
fill 355 84 597 355 87 597 minecraft:green_terracotta
setblock 356 84 560 minecraft:oak_log
setblock 356 84 561 minecraft:green_terracotta
fill 356 84 596 356 87 596 minecraft:green_terracotta
setblock 357 84 559 minecraft:oak_log
fill 357 84 560 357 86 560 minecraft:green_terracotta
setblock 358 84 558 minecraft:oak_log
fill 358 84 559 358 86 559 minecraft:green_terracotta
setblock 358 84 598 minecraft:oak_log
fill 359 84 558 359 87 558 minecraft:green_terracotta
setblock 359 84 597 minecraft:oak_log
fill 359 84 598 359 87 598 minecraft:green_terracotta
fill 360 84 597 360 86 597 minecraft:green_terracotta
setblock 363 84 558 minecraft:oak_log
setblock 363 84 598 minecraft:oak_log
setblock 368 84 583 minecraft:oak_log
fill 368 84 584 368 87 584 minecraft:green_terracotta
fill 368 84 586 368 84 587 minecraft:green_terracotta
setblock 369 84 582 minecraft:oak_log
fill 369 84 583 369 87 583 minecraft:green_terracotta
setblock 369 84 587 minecraft:oak_log
fill 369 84 588 369 87 588 minecraft:green_terracotta
fill 369 84 590 369 85 590 minecraft:green_terracotta
setblock 370 84 560 minecraft:green_terracotta
setblock 370 84 561 minecraft:oak_log
fill 370 84 562 370 84 565 minecraft:green_terracotta
setblock 370 84 566 minecraft:oak_log
fill 370 84 567 370 85 569 minecraft:green_terracotta
setblock 370 84 575 minecraft:oak_leaves[persistent=true]
setblock 370 84 576 minecraft:oak_log
fill 370 84 577 370 87 577 minecraft:green_terracotta
setblock 370 84 581 minecraft:oak_log
fill 370 84 582 370 87 582 minecraft:green_terracotta
setblock 370 84 586 minecraft:oak_log
fill 370 84 587 370 87 587 minecraft:green_terracotta
setblock 370 84 591 minecraft:oak_log
fill 370 84 592 370 86 593 minecraft:green_terracotta
setblock 370 84 594 minecraft:oak_leaves[persistent=true]
fill 330 85 558 330 85 559 minecraft:green_terracotta
setblock 330 85 560 minecraft:oak_log
fill 330 85 561 330 88 561 minecraft:green_terracotta
setblock 330 85 564 minecraft:green_terracotta
setblock 330 85 565 minecraft:oak_log
fill 330 85 566 330 88 566 minecraft:green_terracotta
setblock 330 85 570 minecraft:oak_log
fill 330 85 571 330 88 571 minecraft:green_terracotta
setblock 330 85 575 minecraft:oak_log
fill 330 85 576 330 88 576 minecraft:green_terracotta
setblock 330 85 580 minecraft:oak_log
fill 330 85 581 330 88 581 minecraft:green_terracotta
setblock 330 85 585 minecraft:oak_log
fill 330 85 586 330 88 586 minecraft:green_terracotta
setblock 330 85 590 minecraft:oak_log
fill 330 85 591 330 87 592 minecraft:green_terracotta
setblock 331 85 559 minecraft:oak_log
fill 331 85 560 331 88 560 minecraft:green_terracotta
setblock 331 85 564 minecraft:oak_log
fill 331 85 565 331 88 565 minecraft:green_terracotta
setblock 331 85 569 minecraft:oak_log
fill 331 85 570 331 88 570 minecraft:green_terracotta
setblock 331 85 573 minecraft:green_terracotta
setblock 331 85 574 minecraft:oak_log
fill 331 85 575 331 88 575 minecraft:green_terracotta
setblock 331 85 579 minecraft:oak_log
fill 331 85 580 331 88 580 minecraft:green_terracotta
setblock 331 85 584 minecraft:oak_log
fill 331 85 585 331 88 585 minecraft:green_terracotta
setblock 331 85 589 minecraft:oak_log
fill 331 85 590 331 88 590 minecraft:green_terracotta
setblock 332 85 558 minecraft:oak_log
fill 332 85 559 332 88 559 minecraft:green_terracotta
setblock 332 85 563 minecraft:oak_log
fill 332 85 564 332 88 564 minecraft:green_terracotta
setblock 332 85 568 minecraft:oak_log
fill 332 85 569 333 87 569 minecraft:green_terracotta
fill 332 85 571 332 85 572 minecraft:green_terracotta
setblock 332 85 579 minecraft:green_terracotta
setblock 332 85 583 minecraft:oak_log
fill 332 85 584 332 88 584 minecraft:green_terracotta
setblock 332 85 588 minecraft:oak_log
fill 333 85 558 336 85 558 minecraft:green_terracotta
setblock 333 85 562 minecraft:oak_log
fill 333 85 563 333 88 563 minecraft:green_terracotta
setblock 333 85 566 minecraft:green_terracotta
setblock 333 85 567 minecraft:oak_log
fill 333 85 568 333 88 568 minecraft:green_terracotta
setblock 334 85 561 minecraft:oak_log
setblock 335 85 560 minecraft:oak_log
fill 335 85 561 335 86 561 minecraft:green_terracotta
setblock 336 85 559 minecraft:oak_log
fill 336 85 560 336 88 560 minecraft:green_terracotta
setblock 337 85 558 minecraft:oak_log
fill 337 85 559 337 88 559 minecraft:green_terracotta
setblock 337 85 598 minecraft:oak_log
fill 338 85 558 341 85 558 minecraft:green_terracotta
fill 338 85 598 338 86 598 minecraft:green_terracotta
setblock 339 85 561 minecraft:oak_log
setblock 340 85 560 minecraft:oak_log
setblock 341 85 559 minecraft:oak_log
setblock 341 85 560 minecraft:green_terracotta
setblock 342 85 558 minecraft:oak_log
fill 342 85 559 342 86 559 minecraft:green_terracotta
fill 343 85 558 343 87 558 minecraft:green_terracotta
setblock 344 85 598 minecraft:oak_leaves[persistent=true]
setblock 346 85 559 minecraft:oak_log
setblock 347 85 558 minecraft:oak_log
fill 347 85 559 347 86 559 minecraft:green_terracotta
fill 348 85 558 348 88 558 minecraft:green_terracotta
setblock 350 85 560 minecraft:oak_log
setblock 351 85 559 minecraft:oak_log
fill 351 85 560 351 87 560 minecraft:green_terracotta
fill 351 85 597 351 86 597 minecraft:green_terracotta
setblock 352 85 558 minecraft:oak_log
fill 352 85 559 352 88 559 minecraft:green_terracotta
setblock 352 85 598 minecraft:oak_log
fill 353 85 558 353 88 558 minecraft:green_terracotta
setblock 353 85 597 minecraft:oak_log
fill 353 85 598 353 88 598 minecraft:green_terracotta
setblock 354 85 561 minecraft:oak_log
setblock 354 85 596 minecraft:oak_log
fill 354 85 597 354 88 597 minecraft:green_terracotta
setblock 355 85 560 minecraft:oak_log
setblock 355 85 561 minecraft:green_terracotta
fill 355 85 596 355 88 596 minecraft:green_terracotta
setblock 356 85 559 minecraft:oak_log
fill 356 85 560 356 86 560 minecraft:green_terracotta
setblock 357 85 558 minecraft:oak_log
fill 357 85 559 357 87 559 minecraft:green_terracotta
setblock 357 85 598 minecraft:oak_log
fill 358 85 558 358 88 558 minecraft:green_terracotta
setblock 358 85 597 minecraft:oak_log
fill 358 85 598 358 88 598 minecraft:green_terracotta
fill 359 85 597 359 87 597 minecraft:green_terracotta
setblock 362 85 558 minecraft:oak_log
setblock 362 85 598 minecraft:oak_log
setblock 363 85 598 minecraft:green_terracotta
fill 368 85 583 368 86 583 minecraft:green_terracotta
setblock 368 85 586 minecraft:green_terracotta
setblock 368 85 587 minecraft:oak_log
fill 368 85 588 368 88 588 minecraft:green_terracotta
setblock 369 85 581 minecraft:oak_log
fill 369 85 582 369 88 582 minecraft:green_terracotta
setblock 369 85 586 minecraft:oak_log
fill 369 85 587 369 88 587 minecraft:green_terracotta
setblock 369 85 591 minecraft:oak_log
setblock 370 85 560 minecraft:oak_log
fill 370 85 561 370 85 564 minecraft:green_terracotta
setblock 370 85 565 minecraft:oak_log
fill 370 85 566 370 88 566 minecraft:green_terracotta
setblock 370 85 570 minecraft:oak_log
fill 370 85 571 370 85 574 minecraft:green_terracotta
setblock 370 85 575 minecraft:oak_log
fill 370 85 576 370 88 576 minecraft:green_terracotta
setblock 370 85 580 minecraft:oak_log
fill 370 85 581 370 88 581 minecraft:green_terracotta
setblock 370 85 585 minecraft:oak_log
fill 370 85 586 370 88 586 minecraft:green_terracotta
setblock 370 85 590 minecraft:oak_log
fill 370 85 591 370 88 591 minecraft:green_terracotta
setblock 370 85 594 minecraft:green_terracotta
setblock 330 86 558 minecraft:green_terracotta
setblock 330 86 559 minecraft:oak_log
fill 330 86 560 330 89 560 minecraft:green_terracotta
setblock 330 86 564 minecraft:oak_log
fill 330 86 565 330 89 565 minecraft:green_terracotta
setblock 330 86 568 minecraft:green_terracotta
setblock 330 86 569 minecraft:oak_log
fill 330 86 570 330 89 570 minecraft:green_terracotta
setblock 330 86 574 minecraft:oak_log
fill 330 86 575 330 89 575 minecraft:green_terracotta
setblock 330 86 579 minecraft:oak_log
fill 330 86 580 330 89 580 minecraft:green_terracotta
setblock 330 86 584 minecraft:oak_log
fill 330 86 585 330 89 585 minecraft:green_terracotta
setblock 330 86 588 minecraft:green_terracotta
setblock 330 86 589 minecraft:oak_log
fill 330 86 590 330 89 590 minecraft:green_terracotta
setblock 330 86 593 minecraft:oak_leaves[persistent=true]
setblock 331 86 558 minecraft:oak_log
setblock 331 86 559 minecraft:green_terracotta
setblock 331 86 562 minecraft:green_terracotta
setblock 331 86 563 minecraft:oak_log
fill 331 86 564 331 89 564 minecraft:green_terracotta
setblock 331 86 567 minecraft:green_terracotta
setblock 331 86 568 minecraft:oak_log
fill 331 86 569 331 89 569 minecraft:green_terracotta
setblock 331 86 573 minecraft:oak_log
fill 331 86 574 331 89 574 minecraft:green_terracotta
setblock 331 86 578 minecraft:oak_log
fill 331 86 579 331 88 579 minecraft:green_terracotta
setblock 331 86 583 minecraft:oak_log
fill 331 86 584 331 89 584 minecraft:green_terracotta
setblock 331 86 588 minecraft:oak_log
fill 331 86 589 331 89 589 minecraft:green_terracotta
fill 331 86 591 331 87 591 minecraft:green_terracotta
fill 332 86 558 335 86 558 minecraft:green_terracotta
setblock 332 86 562 minecraft:oak_log
fill 332 86 563 332 89 563 minecraft:green_terracotta
setblock 332 86 567 minecraft:oak_log
fill 332 86 568 332 89 568 minecraft:green_terracotta
setblock 332 86 571 minecraft:green_terracotta
setblock 332 86 572 minecraft:oak_log
fill 332 86 573 332 89 573 minecraft:green_terracotta
setblock 332 86 582 minecraft:oak_log
fill 332 86 583 332 87 583 minecraft:green_terracotta
setblock 332 86 587 minecraft:oak_log
fill 332 86 588 332 88 588 minecraft:green_terracotta
setblock 333 86 562 minecraft:green_terracotta
setblock 333 86 566 minecraft:oak_log
fill 333 86 567 334 87 567 minecraft:green_terracotta
setblock 333 86 570 minecraft:green_terracotta
setblock 334 86 560 minecraft:oak_log
setblock 334 86 561 minecraft:green_terracotta
setblock 334 86 565 minecraft:oak_log
fill 334 86 566 334 87 566 minecraft:green_terracotta
setblock 335 86 559 minecraft:oak_log
fill 335 86 560 335 88 560 minecraft:green_terracotta
setblock 336 86 558 minecraft:oak_log
fill 336 86 559 336 89 559 minecraft:green_terracotta
setblock 336 86 598 minecraft:oak_log
fill 337 86 558 340 86 558 minecraft:green_terracotta
setblock 337 86 598 minecraft:green_terracotta
setblock 338 86 561 minecraft:oak_log
setblock 339 86 560 minecraft:oak_log
setblock 340 86 559 minecraft:oak_log
setblock 340 86 560 minecraft:green_terracotta
setblock 341 86 558 minecraft:oak_log
fill 341 86 559 341 87 559 minecraft:green_terracotta
fill 342 86 558 342 88 558 minecraft:green_terracotta
fill 342 86 560 342 88 560 minecraft:oak_leaves[persistent=true]
setblock 346 86 558 minecraft:oak_log
setblock 346 86 559 minecraft:green_terracotta
fill 347 86 558 347 89 558 minecraft:green_terracotta
fill 348 86 598 348 88 598 minecraft:green_terracotta
setblock 350 86 559 minecraft:oak_log
setblock 350 86 560 minecraft:green_terracotta
setblock 351 86 558 minecraft:oak_log
fill 351 86 559 351 89 559 minecraft:green_terracotta
setblock 351 86 598 minecraft:oak_log
fill 352 86 558 352 89 558 minecraft:green_terracotta
setblock 352 86 597 minecraft:oak_log
fill 352 86 598 352 89 598 minecraft:green_terracotta
fill 353 86 597 353 89 597 minecraft:green_terracotta
setblock 354 86 560 minecraft:oak_log
fill 354 86 596 354 89 596 minecraft:green_terracotta
setblock 355 86 559 minecraft:oak_log
fill 355 86 560 355 87 560 minecraft:green_terracotta
setblock 356 86 558 minecraft:oak_log
fill 356 86 559 356 88 559 minecraft:green_terracotta
setblock 356 86 598 minecraft:oak_log
schedule function dropper:buildpart/139_2 1t
