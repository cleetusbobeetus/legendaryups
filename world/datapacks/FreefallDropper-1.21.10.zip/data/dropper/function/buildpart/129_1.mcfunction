fill 465 117 548 465 141 548 minecraft:black_concrete
setblock 465 117 549 minecraft:white_concrete
fill 465 117 550 465 137 551 minecraft:black_concrete
fill 423 118 518 423 119 518 minecraft:gold_block
fill 423 118 533 423 141 533 minecraft:black_concrete
fill 423 118 534 423 119 534 minecraft:gold_block
fill 423 118 550 423 119 550 minecraft:gold_block
fill 426 118 552 426 141 552 minecraft:black_concrete
fill 427 118 510 427 119 510 minecraft:gold_block
fill 429 118 552 429 124 552 minecraft:black_concrete
fill 430 118 545 431 123 547 minecraft:gold_block
fill 431 118 544 433 123 544 minecraft:gold_block
fill 431 118 548 433 123 548 minecraft:gold_block
fill 432 118 545 434 123 545 minecraft:gold_block
fill 432 118 547 434 123 547 minecraft:gold_block
fill 432 118 552 432 120 552 minecraft:black_concrete
fill 433 118 546 434 123 546 minecraft:gold_block
fill 437 118 552 437 119 552 minecraft:gold_block
fill 443 118 510 443 119 510 minecraft:gold_block
fill 447 118 510 447 139 510 minecraft:black_concrete
fill 453 118 552 453 119 552 minecraft:gold_block
fill 459 118 510 459 119 510 minecraft:gold_block
fill 465 118 519 465 119 519 minecraft:black_concrete
fill 465 118 520 465 119 520 minecraft:gold_block
fill 465 118 536 465 119 536 minecraft:gold_block
fill 465 118 549 465 141 549 minecraft:black_concrete
fill 429 119 545 429 122 547 minecraft:gold_block
fill 430 119 544 430 122 544 minecraft:gold_block
fill 430 119 548 430 122 548 minecraft:gold_block
fill 431 119 543 433 122 543 minecraft:gold_block
fill 431 119 549 433 122 549 minecraft:gold_block
fill 434 119 544 434 122 544 minecraft:gold_block
fill 434 119 548 434 122 548 minecraft:gold_block
fill 435 119 545 435 122 547 minecraft:gold_block
setblock 463 119 552 minecraft:light_blue_stained_glass
setblock 465 119 529 minecraft:white_concrete
fill 423 120 518 423 126 518 minecraft:black_concrete
fill 423 120 534 423 126 534 minecraft:black_concrete
fill 423 120 550 423 126 550 minecraft:black_concrete
setblock 423 120 551 minecraft:light_blue_stained_glass
fill 427 120 510 427 126 510 minecraft:black_concrete
fill 437 120 552 437 126 552 minecraft:black_concrete
fill 443 120 510 443 126 510 minecraft:black_concrete
fill 453 120 552 453 126 552 minecraft:black_concrete
fill 459 120 510 459 126 510 minecraft:black_concrete
fill 463 120 552 463 139 552 minecraft:black_concrete
setblock 465 120 519 minecraft:light_blue_stained_glass
fill 465 120 520 465 126 520 minecraft:black_concrete
fill 465 120 529 465 143 529 minecraft:black_concrete
fill 465 120 536 465 126 536 minecraft:black_concrete
fill 423 121 522 423 141 522 minecraft:black_concrete
setblock 423 121 523 minecraft:white_concrete
fill 423 121 524 423 141 524 minecraft:black_concrete
fill 423 121 551 423 141 551 minecraft:black_concrete
setblock 432 121 552 minecraft:white_concrete
setblock 443 121 552 minecraft:sea_lantern
fill 444 121 552 444 141 552 minecraft:black_concrete
setblock 451 121 552 minecraft:sea_lantern
fill 465 121 519 465 138 519 minecraft:black_concrete
fill 423 122 523 423 138 523 minecraft:black_concrete
setblock 426 122 513 minecraft:light[level=14]
setblock 426 122 521 minecraft:light[level=14]
setblock 426 122 529 minecraft:light[level=14]
setblock 426 122 537 minecraft:light[level=14]
setblock 426 122 545 minecraft:light[level=14]
fill 432 122 552 432 141 552 minecraft:black_concrete
setblock 433 122 552 minecraft:sea_lantern
setblock 434 122 513 minecraft:light[level=14]
setblock 434 122 521 minecraft:light[level=14]
setblock 434 122 529 minecraft:light[level=14]
setblock 434 122 537 minecraft:light[level=14]
setblock 442 122 513 minecraft:light[level=14]
setblock 442 122 521 minecraft:light[level=14]
setblock 442 122 529 minecraft:light[level=14]
setblock 442 122 537 minecraft:light[level=14]
setblock 442 122 545 minecraft:light[level=14]
fill 443 122 552 443 124 552 minecraft:black_concrete
setblock 450 122 513 minecraft:light[level=14]
setblock 450 122 521 minecraft:light[level=14]
setblock 450 122 529 minecraft:light[level=14]
setblock 450 122 537 minecraft:light[level=14]
setblock 450 122 545 minecraft:light[level=14]
fill 451 122 552 451 141 552 minecraft:black_concrete
setblock 458 122 513 minecraft:light[level=14]
setblock 458 122 521 minecraft:light[level=14]
setblock 458 122 529 minecraft:light[level=14]
setblock 458 122 537 minecraft:light[level=14]
setblock 458 122 545 minecraft:light[level=14]
setblock 465 122 539 minecraft:white_concrete
fill 433 123 552 433 139 552 minecraft:black_concrete
setblock 439 123 510 minecraft:light_blue_stained_glass
setblock 457 123 552 minecraft:light_blue_stained_glass
fill 458 123 552 458 124 552 minecraft:black_concrete
fill 465 123 539 465 141 539 minecraft:black_concrete
setblock 423 124 517 minecraft:light_blue_stained_glass
fill 439 124 510 439 132 510 minecraft:black_concrete
fill 457 124 552 457 130 552 minecraft:black_concrete
setblock 458 124 510 minecraft:sea_lantern
setblock 465 124 525 minecraft:light_blue_stained_glass
fill 465 124 526 465 130 526 minecraft:black_concrete
fill 423 125 517 423 142 517 minecraft:black_concrete
fill 427 125 526 427 126 536 minecraft:waxed_cut_copper
fill 428 125 523 428 126 530 minecraft:waxed_cut_copper
fill 428 125 532 428 126 539 minecraft:waxed_cut_copper
fill 429 125 522 429 126 525 minecraft:waxed_cut_copper
fill 429 125 537 429 126 540 minecraft:waxed_cut_copper
setblock 429 125 552 minecraft:light_blue_stained_glass
fill 430 125 520 430 126 523 minecraft:waxed_cut_copper
fill 430 125 539 430 126 542 minecraft:waxed_cut_copper
fill 431 125 519 431 126 521 minecraft:waxed_cut_copper
fill 431 125 541 431 126 543 minecraft:waxed_cut_copper
fill 432 125 518 432 126 520 minecraft:waxed_cut_copper
fill 432 125 542 432 126 544 minecraft:waxed_cut_copper
fill 433 125 517 433 126 519 minecraft:waxed_cut_copper
fill 433 125 543 433 126 545 minecraft:waxed_cut_copper
fill 434 125 517 434 126 518 minecraft:waxed_cut_copper
fill 434 125 544 434 126 545 minecraft:waxed_cut_copper
fill 435 125 516 436 126 517 minecraft:waxed_cut_copper
fill 435 125 545 436 126 546 minecraft:waxed_cut_copper
fill 436 125 515 443 126 515 minecraft:waxed_cut_copper
fill 436 125 547 443 126 547 minecraft:waxed_cut_copper
fill 437 125 516 438 126 516 minecraft:waxed_cut_copper
fill 437 125 546 438 126 546 minecraft:waxed_cut_copper
fill 439 125 514 449 126 514 minecraft:waxed_cut_copper
fill 439 125 548 449 126 548 minecraft:waxed_cut_copper
setblock 443 125 552 minecraft:white_concrete
fill 445 125 515 452 126 515 minecraft:waxed_cut_copper
fill 445 125 547 452 126 547 minecraft:waxed_cut_copper
fill 450 125 516 453 126 516 minecraft:waxed_cut_copper
fill 450 125 546 453 126 546 minecraft:waxed_cut_copper
fill 452 125 517 455 126 517 minecraft:waxed_cut_copper
fill 452 125 545 455 126 545 minecraft:waxed_cut_copper
fill 454 125 518 456 126 518 minecraft:waxed_cut_copper
fill 454 125 544 456 126 544 minecraft:waxed_cut_copper
fill 455 125 519 457 126 519 minecraft:waxed_cut_copper
fill 455 125 543 457 126 543 minecraft:waxed_cut_copper
fill 456 125 520 458 126 520 minecraft:waxed_cut_copper
fill 456 125 542 458 126 542 minecraft:waxed_cut_copper
fill 457 125 521 458 126 521 minecraft:waxed_cut_copper
fill 457 125 541 458 126 541 minecraft:waxed_cut_copper
fill 458 125 510 458 141 510 minecraft:black_concrete
fill 458 125 522 459 126 523 minecraft:waxed_cut_copper
fill 458 125 539 459 126 540 minecraft:waxed_cut_copper
setblock 458 125 552 minecraft:sea_lantern
fill 459 125 524 460 126 525 minecraft:waxed_cut_copper
fill 459 125 537 460 126 538 minecraft:waxed_cut_copper
fill 460 125 523 460 126 523 minecraft:waxed_cut_copper
fill 460 125 526 461 126 530 minecraft:waxed_cut_copper
fill 460 125 532 461 126 536 minecraft:waxed_cut_copper
fill 460 125 539 460 126 539 minecraft:waxed_cut_copper
fill 461 125 531 461 126 531 minecraft:waxed_cut_copper
fill 465 125 525 465 134 525 minecraft:black_concrete
fill 429 126 552 429 141 552 minecraft:black_concrete
setblock 440 126 510 minecraft:white_concrete
fill 443 126 552 443 141 552 minecraft:black_concrete
fill 458 126 552 458 133 552 minecraft:black_concrete
setblock 465 126 541 minecraft:light_blue_stained_glass
fill 423 127 518 423 128 518 minecraft:gold_block
fill 423 127 534 423 128 534 minecraft:gold_block
fill 423 127 550 423 128 550 minecraft:gold_block
fill 427 127 510 427 128 510 minecraft:gold_block
fill 437 127 552 437 128 552 minecraft:gold_block
fill 440 127 510 440 141 510 minecraft:black_concrete
fill 443 127 510 443 128 510 minecraft:gold_block
fill 453 127 552 453 128 552 minecraft:gold_block
fill 454 127 516 454 127 517 minecraft:sea_lantern
setblock 455 127 517 minecraft:sea_lantern
setblock 456 127 518 minecraft:sea_lantern
setblock 457 127 519 minecraft:sea_lantern
fill 458 127 520 458 127 521 minecraft:sea_lantern
fill 459 127 510 459 128 510 minecraft:gold_block
fill 459 127 521 459 127 522 minecraft:sea_lantern
fill 460 127 523 460 127 524 minecraft:sea_lantern
setblock 461 127 525 minecraft:sea_lantern
setblock 465 127 518 minecraft:white_concrete
fill 465 127 520 465 128 520 minecraft:gold_block
fill 465 127 536 465 128 536 minecraft:gold_block
fill 465 127 541 465 139 541 minecraft:black_concrete
setblock 423 128 521 minecraft:light_blue_stained_glass
fill 424 128 544 426 129 544 minecraft:waxed_copper_block
setblock 449 128 552 minecraft:sea_lantern
setblock 460 128 552 minecraft:sea_lantern
setblock 462 128 510 minecraft:sea_lantern
setblock 465 128 517 minecraft:light_blue_stained_glass
fill 465 128 518 465 141 518 minecraft:black_concrete
setblock 465 128 524 minecraft:white_concrete
fill 423 129 518 423 131 518 minecraft:black_concrete
fill 423 129 521 423 137 521 minecraft:black_concrete
fill 423 129 534 423 135 534 minecraft:black_concrete
fill 423 129 550 423 135 550 minecraft:black_concrete
fill 427 129 510 427 135 510 minecraft:black_concrete
fill 437 129 552 437 135 552 minecraft:black_concrete
fill 443 129 510 443 135 510 minecraft:black_concrete
fill 449 129 552 449 141 552 minecraft:black_concrete
fill 453 129 552 453 135 552 minecraft:black_concrete
fill 459 129 510 459 135 510 minecraft:black_concrete
fill 460 129 552 460 141 552 minecraft:black_concrete
fill 462 129 510 462 131 510 minecraft:black_concrete
fill 465 129 517 465 141 517 minecraft:black_concrete
fill 465 129 520 465 135 520 minecraft:black_concrete
fill 465 129 524 465 141 524 minecraft:black_concrete
fill 465 129 536 465 135 536 minecraft:black_concrete
fill 424 130 552 424 141 552 minecraft:black_concrete
setblock 425 130 552 minecraft:sea_lantern
setblock 426 130 513 minecraft:light[level=14]
setblock 426 130 521 minecraft:light[level=14]
setblock 426 130 529 minecraft:light[level=14]
setblock 426 130 537 minecraft:light[level=14]
setblock 426 130 545 minecraft:light[level=14]
setblock 434 130 513 minecraft:light[level=14]
setblock 434 130 521 minecraft:light[level=14]
setblock 434 130 529 minecraft:light[level=14]
setblock 434 130 537 minecraft:light[level=14]
setblock 434 130 545 minecraft:light[level=14]
setblock 442 130 513 minecraft:light[level=14]
setblock 442 130 521 minecraft:light[level=14]
setblock 442 130 529 minecraft:light[level=14]
setblock 442 130 537 minecraft:light[level=14]
setblock 442 130 545 minecraft:light[level=14]
setblock 450 130 513 minecraft:light[level=14]
setblock 450 130 521 minecraft:light[level=14]
setblock 450 130 529 minecraft:light[level=14]
setblock 450 130 537 minecraft:light[level=14]
setblock 450 130 545 minecraft:light[level=14]
setblock 458 130 513 minecraft:light[level=14]
setblock 458 130 521 minecraft:light[level=14]
setblock 458 130 529 minecraft:light[level=14]
setblock 458 130 537 minecraft:light[level=14]
setblock 458 130 545 minecraft:light[level=14]
fill 425 131 552 425 141 552 minecraft:black_concrete
fill 454 131 518 455 136 519 minecraft:yellow_concrete
fill 455 131 520 455 136 520 minecraft:yellow_concrete
setblock 457 131 552 minecraft:sea_lantern
setblock 465 131 526 minecraft:white_concrete
setblock 423 132 518 minecraft:white_concrete
setblock 423 132 535 minecraft:sea_lantern
fill 423 132 536 423 138 538 minecraft:black_concrete
setblock 434 132 510 minecraft:sea_lantern
fill 453 132 518 453 135 520 minecraft:yellow_concrete
fill 454 132 517 456 135 517 minecraft:yellow_concrete
fill 454 132 520 454 135 521 minecraft:yellow_concrete
fill 455 132 521 455 135 521 minecraft:yellow_concrete
fill 456 132 518 456 135 520 minecraft:yellow_concrete
setblock 456 132 552 minecraft:white_concrete
fill 457 132 519 457 135 519 minecraft:yellow_concrete
fill 457 132 552 457 137 552 minecraft:black_concrete
setblock 462 132 510 minecraft:white_concrete
fill 465 132 526 465 140 526 minecraft:black_concrete
fill 423 133 518 423 135 518 minecraft:black_concrete
setblock 423 133 527 minecraft:light_blue_stained_glass
fill 423 133 535 423 137 535 minecraft:black_concrete
fill 434 133 510 434 139 510 minecraft:black_concrete
setblock 439 133 510 minecraft:sea_lantern
fill 452 133 519 452 134 519 minecraft:yellow_concrete
fill 453 133 517 453 134 517 minecraft:yellow_concrete
fill 453 133 521 453 134 521 minecraft:yellow_concrete
fill 456 133 521 456 134 521 minecraft:yellow_concrete
fill 456 133 552 456 142 552 minecraft:black_concrete
fill 457 133 518 457 134 518 minecraft:yellow_concrete
fill 457 133 520 457 134 520 minecraft:yellow_concrete
fill 462 133 510 462 141 510 minecraft:black_concrete
setblock 465 133 535 minecraft:white_concrete
setblock 423 134 512 minecraft:light_blue_stained_glass
fill 423 134 527 423 138 527 minecraft:black_concrete
fill 439 134 510 439 138 510 minecraft:black_concrete
setblock 449 134 510 minecraft:white_concrete
setblock 458 134 552 minecraft:sea_lantern
fill 465 134 535 465 141 535 minecraft:black_concrete
fill 423 135 512 423 139 512 minecraft:black_concrete
setblock 423 135 549 minecraft:light_blue_stained_glass
setblock 429 135 510 minecraft:sea_lantern
fill 449 135 510 449 141 510 minecraft:black_concrete
fill 458 135 552 458 141 552 minecraft:black_concrete
setblock 465 135 525 minecraft:light_blue_stained_glass
fill 423 136 518 423 137 518 minecraft:gold_block
fill 423 136 534 423 137 534 minecraft:gold_block
fill 423 136 549 423 137 549 minecraft:black_concrete
fill 423 136 550 423 137 550 minecraft:gold_block
fill 427 136 510 427 137 510 minecraft:gold_block
fill 429 136 510 429 141 510 minecraft:black_concrete
fill 437 136 552 437 137 552 minecraft:gold_block
setblock 439 136 552 minecraft:sea_lantern
fill 443 136 510 443 137 510 minecraft:gold_block
setblock 447 136 552 minecraft:white_concrete
fill 453 136 552 453 137 552 minecraft:gold_block
fill 459 136 510 459 137 510 minecraft:gold_block
fill 465 136 520 465 137 520 minecraft:gold_block
fill 465 136 525 465 137 525 minecraft:black_concrete
fill 465 136 536 465 137 536 minecraft:gold_block
fill 423 137 510 423 141 510 minecraft:black_concrete
setblock 423 137 511 minecraft:white_concrete
setblock 431 137 510 minecraft:sea_lantern
setblock 436 137 552 minecraft:light_blue_stained_glass
fill 439 137 552 439 139 552 minecraft:black_concrete
fill 447 137 552 447 141 552 minecraft:black_concrete
fill 423 138 511 423 141 511 minecraft:black_concrete
setblock 423 138 513 minecraft:sea_lantern
fill 423 138 518 423 141 518 minecraft:black_concrete
setblock 423 138 521 minecraft:blue_concrete
fill 423 138 534 423 141 534 minecraft:black_concrete
setblock 423 138 535 minecraft:blue_concrete
setblock 423 138 539 minecraft:blue_concrete
setblock 423 138 543 minecraft:blue_concrete
setblock 423 138 544 minecraft:white_concrete
fill 423 138 545 423 141 545 minecraft:black_concrete
setblock 423 138 549 minecraft:light_blue_stained_glass
fill 423 138 550 423 141 550 minecraft:black_concrete
setblock 425 138 510 minecraft:blue_concrete
setblock 426 138 513 minecraft:light[level=14]
setblock 426 138 521 minecraft:light[level=14]
setblock 426 138 529 minecraft:light[level=14]
setblock 426 138 537 minecraft:light[level=14]
setblock 426 138 545 minecraft:light[level=14]
fill 427 138 510 427 141 510 minecraft:black_concrete
fill 431 138 510 431 139 510 minecraft:black_concrete
setblock 434 138 513 minecraft:light[level=14]
setblock 434 138 521 minecraft:light[level=14]
setblock 434 138 529 minecraft:light[level=14]
setblock 434 138 537 minecraft:light[level=14]
setblock 434 138 545 minecraft:light[level=14]
setblock 435 138 510 minecraft:sea_lantern
fill 436 138 510 437 138 510 minecraft:blue_concrete
fill 436 138 552 437 139 552 minecraft:black_concrete
setblock 438 138 552 minecraft:blue_concrete
setblock 441 138 552 minecraft:blue_concrete
setblock 442 138 510 minecraft:blue_concrete
setblock 442 138 513 minecraft:light[level=14]
setblock 442 138 521 minecraft:light[level=14]
setblock 442 138 529 minecraft:light[level=14]
setblock 442 138 537 minecraft:light[level=14]
setblock 442 138 545 minecraft:light[level=14]
fill 442 138 552 442 141 552 minecraft:black_concrete
fill 443 138 510 443 141 510 minecraft:black_concrete
setblock 445 138 552 minecraft:sea_lantern
setblock 446 138 510 minecraft:blue_concrete
setblock 448 138 552 minecraft:blue_concrete
setblock 450 138 513 minecraft:light[level=14]
setblock 450 138 521 minecraft:light[level=14]
setblock 450 138 529 minecraft:light[level=14]
setblock 450 138 537 minecraft:light[level=14]
setblock 450 138 545 minecraft:light[level=14]
setblock 451 138 510 minecraft:blue_concrete
setblock 453 138 552 minecraft:light_blue_stained_glass
setblock 457 138 552 minecraft:blue_concrete
setblock 458 138 513 minecraft:light[level=14]
setblock 458 138 521 minecraft:light[level=14]
setblock 458 138 529 minecraft:light[level=14]
setblock 458 138 537 minecraft:light[level=14]
setblock 458 138 545 minecraft:light[level=14]
fill 459 138 510 459 141 510 minecraft:black_concrete
setblock 459 138 552 minecraft:blue_concrete
fill 463 138 510 465 138 510 minecraft:blue_concrete
setblock 465 138 512 minecraft:blue_concrete
setblock 465 138 520 minecraft:blue_concrete
setblock 465 138 525 minecraft:blue_concrete
setblock 465 138 536 minecraft:blue_concrete
setblock 465 138 547 minecraft:blue_concrete
setblock 465 138 550 minecraft:blue_concrete
fill 465 138 551 465 139 551 minecraft:black_concrete
setblock 423 139 513 minecraft:blue_concrete
fill 423 139 515 423 140 515 minecraft:blue_concrete
setblock 423 139 519 minecraft:light_blue_stained_glass
fill 423 139 521 423 141 521 minecraft:black_concrete
setblock 423 139 523 minecraft:blue_concrete
setblock 423 139 527 minecraft:blue_concrete
setblock 423 139 531 minecraft:sea_lantern
fill 423 139 535 423 141 535 minecraft:black_concrete
fill 423 139 536 423 140 536 minecraft:blue_concrete
fill 423 139 537 423 141 539 minecraft:black_concrete
fill 423 139 543 423 139 544 minecraft:black_concrete
fill 423 139 549 423 141 549 minecraft:black_concrete
fill 425 139 510 425 141 510 minecraft:black_concrete
setblock 431 139 552 minecraft:sea_lantern
fill 435 139 510 437 139 510 minecraft:black_concrete
setblock 438 139 552 minecraft:black_concrete
setblock 439 139 510 minecraft:blue_concrete
fill 441 139 552 441 141 552 minecraft:black_concrete
fill 442 139 510 442 141 510 minecraft:black_concrete
setblock 444 139 510 minecraft:blue_concrete
fill 445 139 552 445 141 552 minecraft:black_concrete
fill 446 139 510 446 141 510 minecraft:black_concrete
fill 448 139 552 448 141 552 minecraft:black_concrete
fill 451 139 510 451 142 510 minecraft:black_concrete
setblock 452 139 510 minecraft:blue_concrete
fill 453 139 552 453 141 552 minecraft:black_concrete
fill 455 139 510 456 139 510 minecraft:blue_concrete
fill 457 139 552 457 142 552 minecraft:black_concrete
setblock 459 139 552 minecraft:black_concrete
fill 463 139 510 465 141 510 minecraft:black_concrete
setblock 464 139 552 minecraft:blue_concrete
fill 465 139 512 465 141 512 minecraft:black_concrete
setblock 465 139 519 minecraft:blue_concrete
fill 465 139 520 465 141 520 minecraft:black_concrete
fill 465 139 525 465 141 525 minecraft:black_concrete
fill 465 139 536 465 141 536 minecraft:black_concrete
setblock 465 139 547 minecraft:white_concrete
fill 465 139 550 465 141 550 minecraft:black_concrete
fill 465 139 552 465 141 552 minecraft:black_concrete
setblock 423 140 512 minecraft:blue_concrete
fill 423 140 513 423 141 513 minecraft:black_concrete
fill 423 140 519 423 141 519 minecraft:black_concrete
fill 423 140 523 423 142 523 minecraft:black_concrete
setblock 423 140 526 minecraft:blue_concrete
fill 423 140 527 423 141 527 minecraft:black_concrete
fill 423 140 531 423 141 531 minecraft:black_concrete
fill 423 140 543 423 141 543 minecraft:black_concrete
setblock 423 140 544 minecraft:blue_concrete
setblock 423 140 546 minecraft:blue_concrete
setblock 423 140 552 minecraft:blue_concrete
setblock 426 140 510 minecraft:blue_concrete
setblock 427 140 552 minecraft:blue_concrete
fill 431 140 510 434 140 510 minecraft:blue_concrete
fill 431 140 552 431 141 552 minecraft:black_concrete
setblock 433 140 552 minecraft:blue_concrete
setblock 434 140 552 minecraft:sea_lantern
fill 435 140 510 435 141 510 minecraft:black_concrete
setblock 436 140 510 minecraft:blue_concrete
fill 436 140 552 436 141 552 minecraft:black_concrete
fill 437 140 510 437 141 510 minecraft:black_concrete
fill 437 140 552 439 140 552 minecraft:blue_concrete
fill 439 140 510 439 141 510 minecraft:black_concrete
fill 444 140 510 444 141 510 minecraft:black_concrete
setblock 446 140 552 minecraft:blue_concrete
setblock 447 140 510 minecraft:blue_concrete
setblock 450 140 552 minecraft:blue_concrete
fill 452 140 510 452 142 510 minecraft:black_concrete
fill 455 140 510 456 141 510 minecraft:black_concrete
setblock 459 140 552 minecraft:blue_concrete
fill 460 140 510 461 140 510 minecraft:blue_concrete
setblock 463 140 552 minecraft:blue_concrete
fill 464 140 552 464 141 552 minecraft:black_concrete
setblock 465 140 515 minecraft:blue_concrete
fill 465 140 519 465 141 519 minecraft:black_concrete
setblock 465 140 541 minecraft:blue_concrete
setblock 465 140 546 minecraft:blue_concrete
fill 465 140 547 465 141 547 minecraft:black_concrete
setblock 465 140 551 minecraft:blue_concrete
setblock 423 141 512 minecraft:black_concrete
setblock 423 141 515 minecraft:black_concrete
setblock 423 141 525 minecraft:sea_lantern
setblock 423 141 526 minecraft:black_concrete
fill 423 141 536 423 142 536 minecraft:black_concrete
setblock 423 141 544 minecraft:black_concrete
setblock 423 141 546 minecraft:black_concrete
setblock 423 141 552 minecraft:black_concrete
setblock 426 141 510 minecraft:black_concrete
setblock 427 141 552 minecraft:black_concrete
fill 431 141 510 434 141 510 minecraft:black_concrete
fill 433 141 552 434 141 552 minecraft:black_concrete
setblock 436 141 510 minecraft:black_concrete
fill 437 141 552 439 141 552 minecraft:black_concrete
setblock 446 141 552 minecraft:black_concrete
setblock 447 141 510 minecraft:black_concrete
setblock 450 141 552 minecraft:black_concrete
setblock 459 141 552 minecraft:black_concrete
fill 460 141 510 461 141 510 minecraft:black_concrete
fill 463 141 552 463 142 552 minecraft:black_concrete
setblock 465 141 515 minecraft:black_concrete
setblock 465 141 526 minecraft:white_concrete
setblock 465 141 541 minecraft:black_concrete
setblock 465 141 546 minecraft:black_concrete
fill 465 141 551 465 142 551 minecraft:black_concrete
fill 423 142 510 423 143 515 minecraft:blue_concrete
fill 423 142 518 423 143 520 minecraft:blue_concrete
setblock 423 142 521 minecraft:white_concrete
fill 423 142 522 423 154 522 minecraft:blue_concrete
fill 423 142 524 423 142 535 minecraft:blue_concrete
fill 423 142 537 423 142 552 minecraft:blue_concrete
fill 424 142 510 431 142 510 minecraft:blue_concrete
fill 424 142 552 433 142 552 minecraft:blue_concrete
setblock 432 142 510 minecraft:black_concrete
fill 433 142 510 434 142 510 minecraft:blue_concrete
setblock 434 142 552 minecraft:black_concrete
setblock 435 142 510 minecraft:sea_lantern
fill 435 142 552 455 142 552 minecraft:blue_concrete
fill 436 142 510 450 143 510 minecraft:blue_concrete
fill 453 142 510 455 200 510 minecraft:blue_concrete
setblock 456 142 510 minecraft:black_concrete
fill 457 142 510 462 144 510 minecraft:blue_concrete
fill 458 142 552 462 143 552 minecraft:blue_concrete
fill 463 142 510 464 142 510 minecraft:black_concrete
fill 464 142 552 465 159 552 minecraft:blue_concrete
fill 465 142 510 465 142 526 minecraft:blue_concrete
fill 465 142 528 465 180 528 minecraft:blue_concrete
fill 465 142 530 465 220 530 minecraft:blue_concrete
setblock 465 142 531 minecraft:light_blue_stained_glass
fill 465 142 532 465 167 532 minecraft:blue_concrete
fill 465 142 534 465 144 537 minecraft:blue_concrete
fill 465 142 539 465 169 539 minecraft:blue_concrete
fill 465 142 541 465 150 550 minecraft:blue_concrete
fill 423 143 516 423 221 517 minecraft:blue_concrete
fill 423 143 521 423 221 521 minecraft:blue_concrete
fill 423 143 523 423 143 526 minecraft:blue_concrete
setblock 423 143 527 minecraft:black_concrete
fill 423 143 528 423 158 528 minecraft:blue_concrete
fill 423 143 529 423 143 530 minecraft:black_concrete
fill 423 143 531 423 192 533 minecraft:blue_concrete
fill 423 143 534 423 144 534 minecraft:black_concrete
fill 423 143 535 423 143 536 minecraft:blue_concrete
setblock 423 143 537 minecraft:black_concrete
fill 423 143 538 423 224 539 minecraft:blue_concrete
setblock 423 143 540 minecraft:black_concrete
setblock 423 143 541 minecraft:light_blue_stained_glass
fill 423 143 542 423 143 546 minecraft:blue_concrete
setblock 423 143 547 minecraft:black_concrete
fill 423 143 548 423 144 552 minecraft:blue_concrete
setblock 424 143 510 minecraft:black_concrete
setblock 424 143 552 minecraft:black_concrete
fill 425 143 510 425 172 510 minecraft:blue_concrete
fill 425 143 552 429 147 552 minecraft:blue_concrete
setblock 426 143 510 minecraft:black_concrete
fill 427 143 510 432 143 510 minecraft:blue_concrete
setblock 430 143 552 minecraft:black_concrete
fill 431 143 552 435 163 552 minecraft:blue_concrete
setblock 433 143 510 minecraft:black_concrete
fill 434 143 510 435 195 510 minecraft:blue_concrete
setblock 436 143 552 minecraft:black_concrete
fill 437 143 552 439 144 552 minecraft:blue_concrete
setblock 440 143 552 minecraft:black_concrete
fill 441 143 552 444 148 552 minecraft:blue_concrete
setblock 445 143 552 minecraft:black_concrete
fill 446 143 552 449 143 552 minecraft:blue_concrete
setblock 450 143 552 minecraft:black_concrete
fill 451 143 510 452 143 510 minecraft:blue_concrete
fill 451 143 552 453 144 552 minecraft:blue_concrete
setblock 454 143 552 minecraft:black_concrete
fill 455 143 552 457 159 552 minecraft:blue_concrete
fill 456 143 510 456 220 510 minecraft:blue_concrete
fill 463 143 510 465 170 510 minecraft:blue_concrete
fill 463 143 552 463 221 552 minecraft:blue_concrete
fill 465 143 511 465 143 523 minecraft:blue_concrete
setblock 465 143 524 minecraft:black_concrete
fill 465 143 525 465 144 527 minecraft:blue_concrete
fill 465 143 531 465 191 531 minecraft:blue_concrete
fill 465 143 533 465 189 533 minecraft:blue_concrete
setblock 465 143 538 minecraft:blue_concrete
fill 465 143 540 465 224 540 minecraft:blue_concrete
fill 465 143 551 465 224 551 minecraft:blue_concrete
fill 423 144 510 423 145 514 minecraft:blue_concrete
setblock 423 144 515 minecraft:black_concrete
fill 423 144 518 423 144 519 minecraft:blue_concrete
setblock 423 144 520 minecraft:black_concrete
fill 423 144 523 423 163 523 minecraft:blue_concrete
setblock 423 144 524 minecraft:black_concrete
fill 423 144 525 423 157 527 minecraft:blue_concrete
fill 423 144 529 423 155 530 minecraft:blue_concrete
setblock 423 144 535 minecraft:black_concrete
fill 423 144 536 423 175 537 minecraft:blue_concrete
fill 423 144 540 423 157 541 minecraft:blue_concrete
setblock 423 144 542 minecraft:light_blue_stained_glass
fill 423 144 543 423 151 547 minecraft:blue_concrete
fill 424 144 510 424 157 510 minecraft:blue_concrete
fill 424 144 552 424 198 552 minecraft:blue_concrete
fill 426 144 510 431 144 510 minecraft:blue_concrete
fill 430 144 552 430 193 552 minecraft:blue_concrete
setblock 432 144 510 minecraft:black_concrete
fill 433 144 510 433 220 510 minecraft:blue_concrete
setblock 436 144 510 minecraft:black_concrete
fill 436 144 552 436 224 552 minecraft:blue_concrete
fill 437 144 510 451 144 510 minecraft:blue_concrete
fill 440 144 552 440 177 552 minecraft:blue_concrete
fill 445 144 552 445 158 552 minecraft:blue_concrete
setblock 446 144 552 minecraft:sea_lantern
fill 447 144 552 450 158 552 minecraft:blue_concrete
setblock 452 144 510 minecraft:light_blue_stained_glass
fill 454 144 552 454 162 552 minecraft:blue_concrete
fill 458 144 552 458 163 552 minecraft:blue_concrete
setblock 459 144 552 minecraft:black_concrete
setblock 460 144 552 minecraft:sea_lantern
setblock 461 144 552 minecraft:blue_concrete
setblock 462 144 552 minecraft:light_blue_stained_glass
fill 465 144 511 465 162 513 minecraft:blue_concrete
setblock 465 144 514 minecraft:black_concrete
fill 465 144 515 465 224 516 minecraft:blue_concrete
setblock 465 144 517 minecraft:black_concrete
fill 465 144 518 465 144 524 minecraft:blue_concrete
fill 465 144 529 465 224 529 minecraft:blue_concrete
setblock 465 144 538 minecraft:black_concrete
fill 423 145 515 423 215 515 minecraft:blue_concrete
fill 423 145 518 423 146 518 minecraft:gold_block
fill 423 145 519 423 176 520 minecraft:blue_concrete
fill 423 145 524 423 221 524 minecraft:blue_concrete
fill 423 145 534 423 146 534 minecraft:gold_block
fill 423 145 535 423 189 535 minecraft:blue_concrete
fill 423 145 542 423 224 542 minecraft:blue_concrete
fill 423 145 548 423 146 549 minecraft:blue_concrete
fill 423 145 550 423 146 550 minecraft:gold_block
fill 423 145 551 423 154 552 minecraft:blue_concrete
fill 426 145 510 426 219 510 minecraft:blue_concrete
fill 427 145 510 427 146 510 minecraft:gold_block
fill 428 145 510 432 165 510 minecraft:blue_concrete
fill 436 145 510 442 148 510 minecraft:blue_concrete
fill 437 145 552 437 146 552 minecraft:gold_block
fill 438 145 552 439 173 552 minecraft:blue_concrete
fill 443 145 510 443 146 510 minecraft:gold_block
fill 444 145 510 452 149 510 minecraft:blue_concrete
fill 446 145 552 446 161 552 minecraft:blue_concrete
fill 451 145 552 452 190 552 minecraft:blue_concrete
fill 453 145 552 453 146 552 minecraft:gold_block
fill 457 145 510 458 147 510 minecraft:blue_concrete
fill 459 145 510 459 146 510 minecraft:gold_block
fill 459 145 552 460 199 552 minecraft:blue_concrete
fill 460 145 510 462 159 510 minecraft:blue_concrete
setblock 461 145 552 minecraft:sea_lantern
fill 462 145 552 462 169 552 minecraft:blue_concrete
fill 465 145 514 465 169 514 minecraft:blue_concrete
fill 465 145 517 465 171 519 minecraft:blue_concrete
fill 465 145 520 465 146 520 minecraft:gold_block
fill 465 145 521 465 153 526 minecraft:blue_concrete
setblock 465 145 527 minecraft:white_concrete
fill 465 145 534 465 149 535 minecraft:blue_concrete
fill 465 145 536 465 146 536 minecraft:gold_block
fill 465 145 537 465 147 538 minecraft:blue_concrete
fill 423 146 510 423 151 511 minecraft:blue_concrete
setblock 423 146 512 minecraft:sea_lantern
fill 423 146 513 423 151 514 minecraft:blue_concrete
setblock 426 146 513 minecraft:light[level=14]
setblock 426 146 521 minecraft:light[level=14]
setblock 426 146 529 minecraft:light[level=14]
setblock 426 146 537 minecraft:light[level=14]
setblock 426 146 545 minecraft:light[level=14]
setblock 434 146 513 minecraft:light[level=14]
setblock 434 146 521 minecraft:light[level=14]
setblock 434 146 529 minecraft:light[level=14]
setblock 434 146 537 minecraft:light[level=14]
setblock 434 146 545 minecraft:light[level=14]
setblock 442 146 513 minecraft:light[level=14]
setblock 442 146 521 minecraft:light[level=14]
setblock 442 146 529 minecraft:light[level=14]
setblock 442 146 537 minecraft:light[level=14]
setblock 442 146 545 minecraft:light[level=14]
setblock 450 146 513 minecraft:light[level=14]
setblock 450 146 521 minecraft:light[level=14]
setblock 450 146 529 minecraft:light[level=14]
setblock 450 146 537 minecraft:light[level=14]
setblock 450 146 545 minecraft:light[level=14]
setblock 458 146 513 minecraft:light[level=14]
setblock 458 146 521 minecraft:light[level=14]
setblock 458 146 529 minecraft:light[level=14]
setblock 458 146 537 minecraft:light[level=14]
setblock 458 146 545 minecraft:light[level=14]
fill 461 146 552 461 189 552 minecraft:blue_concrete
fill 465 146 527 465 224 527 minecraft:blue_concrete
fill 423 147 512 423 154 512 minecraft:blue_concrete
fill 423 147 518 423 161 518 minecraft:blue_concrete
fill 423 147 534 423 161 534 minecraft:blue_concrete
fill 423 147 548 423 150 548 minecraft:blue_concrete
setblock 423 147 549 minecraft:sea_lantern
fill 423 147 550 423 161 550 minecraft:blue_concrete
fill 427 147 510 427 161 510 minecraft:blue_concrete
fill 437 147 552 437 157 552 minecraft:blue_concrete
fill 443 147 510 443 161 510 minecraft:blue_concrete
fill 453 147 552 453 161 552 minecraft:blue_concrete
setblock 459 147 510 minecraft:blue_concrete
fill 465 147 520 465 161 520 minecraft:blue_concrete
fill 465 147 536 465 161 536 minecraft:blue_concrete
fill 423 148 549 423 152 549 minecraft:blue_concrete
fill 425 148 552 428 173 552 minecraft:blue_concrete
setblock 429 148 552 minecraft:light_blue_stained_glass
setblock 457 148 510 minecraft:white_concrete
fill 458 148 510 458 222 510 minecraft:blue_concrete
setblock 459 148 510 minecraft:sea_lantern
fill 465 148 537 465 196 537 minecraft:blue_concrete
setblock 465 148 538 minecraft:sea_lantern
fill 429 149 552 429 153 552 minecraft:blue_concrete
setblock 436 149 510 minecraft:blue_concrete
setblock 437 149 510 minecraft:white_concrete
fill 438 149 510 442 152 510 minecraft:blue_concrete
setblock 441 149 552 minecraft:light_blue_stained_glass
fill 442 149 552 444 170 552 minecraft:blue_concrete
fill 457 149 510 457 200 510 minecraft:blue_concrete
fill 459 149 510 459 161 510 minecraft:blue_concrete
setblock 465 149 538 minecraft:light_blue_stained_glass
setblock 436 150 510 minecraft:white_concrete
fill 437 150 510 437 160 510 minecraft:blue_concrete
fill 441 150 552 441 178 552 minecraft:blue_concrete
fill 444 150 510 447 167 510 minecraft:blue_concrete
setblock 448 150 510 minecraft:light_blue_stained_glass
fill 449 150 510 452 216 510 minecraft:blue_concrete
setblock 465 150 534 minecraft:white_concrete
fill 465 150 535 465 171 535 minecraft:blue_concrete
fill 465 150 538 465 200 538 minecraft:blue_concrete
setblock 423 151 548 minecraft:white_concrete
fill 436 151 510 436 194 510 minecraft:blue_concrete
fill 448 151 510 448 221 510 minecraft:blue_concrete
fill 465 151 534 465 224 534 minecraft:blue_concrete
fill 465 151 541 465 157 546 minecraft:blue_concrete
setblock 465 151 547 minecraft:light_blue_stained_glass
fill 465 151 548 465 160 550 minecraft:blue_concrete
fill 423 152 510 423 222 510 minecraft:blue_concrete
setblock 423 152 511 minecraft:sea_lantern
setblock 423 152 513 minecraft:sea_lantern
fill 423 152 514 423 205 514 minecraft:blue_concrete
fill 423 152 543 423 171 544 minecraft:blue_concrete
setblock 423 152 545 minecraft:sea_lantern
fill 423 152 546 423 165 548 minecraft:blue_concrete
fill 465 152 547 465 184 547 minecraft:blue_concrete
setblock 423 153 511 minecraft:blue_concrete
fill 423 153 513 423 188 513 minecraft:blue_concrete
fill 423 153 545 423 187 545 minecraft:blue_concrete
setblock 423 153 549 minecraft:white_concrete
fill 436 153 527 438 153 529 minecraft:redstone_block
fill 438 153 510 440 159 510 minecraft:blue_concrete
fill 440 153 535 442 153 537 minecraft:redstone_block
setblock 441 153 510 minecraft:light_blue_stained_glass
fill 442 153 510 442 193 510 minecraft:blue_concrete
fill 443 153 526 445 153 528 minecraft:redstone_block
setblock 423 154 511 minecraft:light_blue_stained_glass
fill 423 154 549 423 184 549 minecraft:blue_concrete
setblock 426 154 513 minecraft:light[level=14]
setblock 426 154 521 minecraft:light[level=14]
setblock 426 154 529 minecraft:light[level=14]
fill 426 154 531 439 154 531 minecraft:blue_concrete
setblock 426 154 537 minecraft:light[level=14]
setblock 426 154 545 minecraft:light[level=14]
fill 429 154 524 431 155 524 minecraft:blue_concrete
fill 429 154 530 439 154 530 minecraft:blue_concrete
fill 429 154 532 439 154 532 minecraft:blue_concrete
fill 429 154 538 431 155 538 minecraft:blue_concrete
setblock 429 154 552 minecraft:light_blue_stained_glass
fill 430 154 525 433 155 525 minecraft:blue_concrete
fill 430 154 537 433 155 537 minecraft:blue_concrete
fill 431 154 526 435 154 526 minecraft:blue_concrete
fill 431 154 536 435 154 536 minecraft:blue_concrete
fill 432 154 527 435 154 527 minecraft:blue_concrete
fill 432 154 535 439 154 535 minecraft:blue_concrete
fill 433 154 528 435 154 528 minecraft:blue_concrete
fill 433 154 534 449 154 534 minecraft:blue_concrete
setblock 434 154 513 minecraft:light[level=14]
fill 434 154 519 434 155 521 minecraft:blue_concrete
setblock 434 154 529 minecraft:light[level=14]
setblock 434 154 537 minecraft:light[level=14]
fill 434 154 541 434 155 543 minecraft:blue_concrete
setblock 434 154 545 minecraft:light[level=14]
fill 435 154 520 435 155 523 minecraft:blue_concrete
setblock 435 154 529 minecraft:blue_concrete
fill 435 154 533 447 154 533 minecraft:blue_concrete
fill 435 154 539 435 155 542 minecraft:blue_concrete
fill 436 154 521 436 154 525 minecraft:blue_concrete
fill 436 154 537 436 154 541 minecraft:blue_concrete
fill 437 154 522 437 154 526 minecraft:blue_concrete
fill 437 154 536 437 154 540 minecraft:blue_concrete
fill 438 154 523 438 154 526 minecraft:blue_concrete
fill 438 154 536 438 154 539 minecraft:blue_concrete
fill 439 154 525 442 154 529 minecraft:blue_concrete
fill 439 154 536 439 154 537 minecraft:blue_concrete
fill 440 154 519 442 154 524 minecraft:blue_concrete
fill 440 154 538 442 154 543 minecraft:blue_concrete
setblock 441 154 510 minecraft:sea_lantern
fill 441 154 516 441 155 518 minecraft:blue_concrete
fill 441 154 544 441 155 546 minecraft:blue_concrete
setblock 442 154 513 minecraft:light[level=14]
setblock 442 154 537 minecraft:light[level=14]
setblock 442 154 545 minecraft:light[level=14]
fill 443 154 525 446 154 525 minecraft:blue_concrete
fill 443 154 529 447 154 532 minecraft:blue_concrete
fill 443 154 535 445 154 537 minecraft:blue_concrete
fill 444 154 523 446 154 524 minecraft:blue_concrete
fill 444 154 538 446 154 539 minecraft:blue_concrete
fill 445 154 522 447 155 522 minecraft:blue_concrete
fill 445 154 540 447 155 540 minecraft:blue_concrete
fill 446 154 521 448 155 521 minecraft:blue_concrete
fill 446 154 527 449 154 528 minecraft:blue_concrete
fill 446 154 535 450 154 535 minecraft:blue_concrete
fill 446 154 537 446 155 537 minecraft:blue_concrete
fill 446 154 541 448 155 541 minecraft:blue_concrete
fill 447 154 520 448 155 520 minecraft:blue_concrete
fill 447 154 523 447 155 523 minecraft:blue_concrete
fill 447 154 526 451 154 526 minecraft:blue_concrete
fill 447 154 536 451 154 536 minecraft:blue_concrete
fill 447 154 539 447 155 539 minecraft:blue_concrete
fill 447 154 542 448 155 542 minecraft:blue_concrete
fill 448 154 519 448 155 519 minecraft:blue_concrete
fill 448 154 530 453 154 532 minecraft:blue_concrete
fill 448 154 543 448 155 543 minecraft:blue_concrete
fill 449 154 525 452 155 525 minecraft:blue_concrete
fill 449 154 537 452 155 537 minecraft:blue_concrete
setblock 450 154 513 minecraft:light[level=14]
setblock 450 154 521 minecraft:light[level=14]
fill 450 154 527 450 155 527 minecraft:blue_concrete
setblock 450 154 529 minecraft:light[level=14]
setblock 450 154 545 minecraft:light[level=14]
fill 451 154 524 453 155 524 minecraft:blue_concrete
fill 451 154 538 453 155 538 minecraft:blue_concrete
fill 454 154 531 456 155 531 minecraft:blue_concrete
setblock 458 154 513 minecraft:light[level=14]
setblock 458 154 521 minecraft:light[level=14]
setblock 458 154 529 minecraft:light[level=14]
setblock 458 154 537 minecraft:light[level=14]
setblock 458 154 545 minecraft:light[level=14]
setblock 465 154 521 minecraft:sea_lantern
fill 465 154 522 465 158 526 minecraft:blue_concrete
fill 423 155 511 423 182 511 minecraft:blue_concrete
setblock 423 155 512 minecraft:sea_lantern
setblock 423 155 522 minecraft:white_concrete
setblock 423 155 551 minecraft:sea_lantern
fill 423 155 552 423 222 552 minecraft:blue_concrete
fill 424 155 511 425 155 551 minecraft:black_concrete
fill 426 155 511 428 155 530 minecraft:black_concrete
fill 426 155 531 430 155 531 minecraft:blue_concrete
fill 426 155 532 428 155 551 minecraft:black_concrete
fill 429 155 511 433 155 523 minecraft:black_concrete
fill 429 155 525 429 155 529 minecraft:black_concrete
fill 429 155 530 433 155 530 minecraft:blue_concrete
fill 429 155 532 433 155 532 minecraft:blue_concrete
fill 429 155 533 429 155 537 minecraft:black_concrete
fill 429 155 539 433 155 551 minecraft:black_concrete
fill 429 155 552 429 183 552 minecraft:blue_concrete
fill 430 155 526 430 155 529 minecraft:black_concrete
fill 430 155 533 430 155 536 minecraft:black_concrete
fill 431 155 526 432 155 526 minecraft:blue_concrete
fill 431 155 527 431 155 529 minecraft:black_concrete
fill 431 155 531 436 155 531 minecraft:black_concrete
fill 431 155 533 431 155 535 minecraft:black_concrete
fill 431 155 536 432 155 536 minecraft:blue_concrete
fill 432 155 524 435 155 524 minecraft:black_concrete
setblock 432 155 527 minecraft:blue_concrete
fill 432 155 528 432 155 529 minecraft:black_concrete
fill 432 155 533 432 155 534 minecraft:black_concrete
setblock 432 155 535 minecraft:blue_concrete
fill 432 155 538 435 155 538 minecraft:black_concrete
fill 433 155 526 433 155 527 minecraft:black_concrete
setblock 433 155 528 minecraft:blue_concrete
fill 433 155 529 434 155 529 minecraft:black_concrete
fill 433 155 533 434 155 533 minecraft:black_concrete
setblock 433 155 534 minecraft:blue_concrete
fill 433 155 535 433 155 536 minecraft:black_concrete
fill 434 155 511 440 155 518 minecraft:black_concrete
fill 434 155 522 434 155 523 minecraft:black_concrete
fill 434 155 525 435 155 525 minecraft:black_concrete
setblock 434 155 526 minecraft:blue_concrete
fill 434 155 527 434 155 528 minecraft:black_concrete
setblock 434 155 530 minecraft:black_concrete
fill 434 155 532 437 155 532 minecraft:black_concrete
fill 434 155 534 436 155 535 minecraft:black_concrete
fill 434 155 536 435 155 536 minecraft:blue_concrete
fill 434 155 537 435 155 537 minecraft:black_concrete
fill 434 155 539 434 155 540 minecraft:black_concrete
fill 434 155 544 440 155 551 minecraft:black_concrete
fill 435 155 519 439 155 519 minecraft:black_concrete
fill 435 155 526 435 155 530 minecraft:sea_lantern
setblock 435 155 533 minecraft:blue_concrete
fill 435 155 543 439 155 543 minecraft:black_concrete
fill 436 155 520 439 155 520 minecraft:black_concrete
fill 436 155 521 436 155 522 minecraft:blue_concrete
fill 436 155 523 437 155 523 minecraft:black_concrete
fill 436 155 524 436 155 525 minecraft:blue_concrete
fill 436 155 526 439 155 526 minecraft:sea_lantern
fill 436 155 527 438 155 529 minecraft:black_concrete
fill 436 155 530 439 155 530 minecraft:sea_lantern
fill 436 155 533 437 155 533 minecraft:black_concrete
fill 436 155 536 438 155 536 minecraft:black_concrete
fill 436 155 537 436 155 538 minecraft:blue_concrete
fill 436 155 539 437 155 539 minecraft:black_concrete
fill 436 155 540 436 155 541 minecraft:blue_concrete
fill 436 155 542 439 155 542 minecraft:black_concrete
fill 437 155 521 439 155 521 minecraft:black_concrete
setblock 437 155 522 minecraft:blue_concrete
fill 437 155 524 438 155 525 minecraft:black_concrete
fill 437 155 531 438 155 531 minecraft:gold_block
fill 437 155 534 438 155 534 minecraft:black_concrete
setblock 437 155 535 minecraft:blue_concrete
fill 437 155 537 438 155 538 minecraft:black_concrete
setblock 437 155 540 minecraft:blue_concrete
fill 437 155 541 439 155 541 minecraft:black_concrete
fill 438 155 522 439 155 522 minecraft:black_concrete
setblock 438 155 523 minecraft:blue_concrete
fill 438 155 532 438 155 533 minecraft:gold_block
setblock 438 155 535 minecraft:black_concrete
setblock 438 155 539 minecraft:blue_concrete
fill 438 155 540 439 155 540 minecraft:black_concrete
fill 439 155 523 439 155 524 minecraft:black_concrete
setblock 439 155 525 minecraft:blue_concrete
fill 439 155 527 439 155 529 minecraft:sea_lantern
fill 439 155 531 439 155 538 minecraft:sea_lantern
setblock 439 155 539 minecraft:black_concrete
fill 440 155 519 440 155 523 minecraft:blue_concrete
fill 440 155 524 440 155 527 minecraft:black_concrete
fill 440 155 528 441 155 528 minecraft:gold_block
fill 440 155 529 446 155 529 minecraft:sea_lantern
fill 440 155 533 443 155 534 minecraft:sea_lantern
fill 440 155 535 442 155 537 minecraft:black_concrete
fill 440 155 538 443 155 538 minecraft:sea_lantern
fill 440 155 539 440 155 543 minecraft:blue_concrete
fill 441 155 510 441 224 510 minecraft:blue_concrete
fill 441 155 511 464 155 515 minecraft:black_concrete
fill 441 155 519 442 155 520 minecraft:blue_concrete
fill 441 155 521 441 155 526 minecraft:black_concrete
setblock 441 155 527 minecraft:gold_block
fill 441 155 539 441 155 541 minecraft:black_concrete
fill 441 155 542 442 155 543 minecraft:blue_concrete
fill 441 155 547 464 155 551 minecraft:black_concrete
fill 442 155 516 464 155 518 minecraft:black_concrete
fill 442 155 521 442 155 523 minecraft:blue_concrete
fill 442 155 524 445 155 524 minecraft:black_concrete
fill 442 155 525 442 155 528 minecraft:sea_lantern
fill 442 155 539 442 155 541 minecraft:blue_concrete
fill 442 155 544 464 155 546 minecraft:black_concrete
fill 443 155 519 443 155 523 minecraft:black_concrete
fill 443 155 525 446 155 525 minecraft:sea_lantern
fill 443 155 526 445 155 528 minecraft:black_concrete
fill 443 155 530 443 155 532 minecraft:sea_lantern
fill 443 155 535 443 155 537 minecraft:sea_lantern
fill 443 155 539 443 155 543 minecraft:black_concrete
fill 444 155 519 444 155 522 minecraft:black_concrete
setblock 444 155 523 minecraft:blue_concrete
fill 444 155 530 444 155 533 minecraft:gold_block
fill 444 155 534 444 155 538 minecraft:black_concrete
setblock 444 155 539 minecraft:blue_concrete
fill 444 155 540 444 155 543 minecraft:black_concrete
fill 445 155 519 445 155 521 minecraft:black_concrete
fill 445 155 523 446 155 523 minecraft:black_concrete
fill 445 155 530 448 155 530 minecraft:black_concrete
setblock 445 155 531 minecraft:gold_block
fill 445 155 532 446 155 534 minecraft:black_concrete
setblock 445 155 535 minecraft:blue_concrete
fill 445 155 536 445 155 539 minecraft:black_concrete
fill 445 155 541 445 155 543 minecraft:black_concrete
fill 446 155 519 446 155 520 minecraft:black_concrete
setblock 446 155 524 minecraft:blue_concrete
fill 446 155 526 446 155 528 minecraft:sea_lantern
fill 446 155 531 451 155 531 minecraft:black_concrete
fill 446 155 535 446 155 536 minecraft:black_concrete
setblock 446 155 538 minecraft:blue_concrete
setblock 446 155 539 minecraft:black_concrete
fill 446 155 542 446 155 543 minecraft:black_concrete
setblock 447 155 519 minecraft:black_concrete
fill 447 155 524 448 155 525 minecraft:black_concrete
fill 447 155 526 448 155 526 minecraft:blue_concrete
fill 447 155 527 448 155 528 minecraft:black_concrete
setblock 447 155 529 minecraft:blue_concrete
fill 447 155 532 448 155 532 minecraft:black_concrete
setblock 447 155 533 minecraft:blue_concrete
fill 447 155 534 448 155 535 minecraft:black_concrete
fill 447 155 536 448 155 536 minecraft:blue_concrete
fill 447 155 537 448 155 538 minecraft:black_concrete
setblock 447 155 543 minecraft:black_concrete
fill 448 155 522 464 155 523 minecraft:black_concrete
fill 448 155 529 464 155 529 minecraft:black_concrete
fill 448 155 533 464 155 533 minecraft:black_concrete
fill 448 155 539 464 155 540 minecraft:black_concrete
fill 449 155 519 464 155 521 minecraft:black_concrete
fill 449 155 524 450 155 524 minecraft:black_concrete
fill 449 155 526 449 155 527 minecraft:black_concrete
setblock 449 155 528 minecraft:blue_concrete
fill 449 155 530 453 155 530 minecraft:blue_concrete
fill 449 155 532 453 155 532 minecraft:blue_concrete
setblock 449 155 534 minecraft:blue_concrete
fill 449 155 535 449 155 536 minecraft:black_concrete
fill 449 155 538 450 155 538 minecraft:black_concrete
fill 449 155 541 464 155 543 minecraft:black_concrete
fill 450 155 526 451 155 526 minecraft:blue_concrete
fill 450 155 528 464 155 528 minecraft:black_concrete
fill 450 155 534 464 155 534 minecraft:black_concrete
fill 450 155 535 450 155 536 minecraft:blue_concrete
fill 451 155 527 464 155 527 minecraft:black_concrete
fill 451 155 535 464 155 535 minecraft:black_concrete
setblock 451 155 536 minecraft:blue_concrete
fill 452 155 526 464 155 526 minecraft:black_concrete
fill 452 155 531 453 155 531 minecraft:blue_concrete
fill 452 155 536 464 155 536 minecraft:black_concrete
fill 453 155 525 464 155 525 minecraft:black_concrete
fill 453 155 537 464 155 537 minecraft:black_concrete
fill 454 155 524 464 155 524 minecraft:black_concrete
fill 454 155 530 464 155 530 minecraft:black_concrete
fill 454 155 532 464 155 532 minecraft:black_concrete
fill 454 155 538 464 155 538 minecraft:black_concrete
fill 457 155 531 464 155 531 minecraft:black_concrete
fill 465 155 521 465 190 521 minecraft:blue_concrete
fill 423 156 512 423 225 512 minecraft:blue_concrete
fill 423 156 522 423 194 522 minecraft:blue_concrete
setblock 423 156 529 minecraft:light_blue_stained_glass
fill 423 156 530 423 224 530 minecraft:blue_concrete
fill 423 156 551 423 221 551 minecraft:blue_concrete
fill 439 156 530 439 156 532 minecraft:lime_stained_glass
fill 440 156 529 442 156 529 minecraft:lime_stained_glass
fill 440 156 533 442 156 533 minecraft:lime_stained_glass
fill 443 156 530 443 156 532 minecraft:lime_stained_glass
fill 423 157 529 423 225 529 minecraft:blue_concrete
fill 430 157 529 438 157 533 minecraft:light_gray_concrete
fill 431 157 526 451 157 528 minecraft:light_gray_concrete
fill 431 157 534 451 157 536 minecraft:light_gray_concrete
fill 432 157 525 450 160 525 minecraft:light_gray_concrete
fill 432 157 537 450 160 537 minecraft:light_gray_concrete
fill 433 157 524 449 160 524 minecraft:light_gray_concrete
fill 433 157 538 449 160 538 minecraft:light_gray_concrete
fill 434 157 523 448 160 523 minecraft:light_gray_concrete
fill 434 157 539 448 160 539 minecraft:light_gray_concrete
fill 435 157 522 447 160 522 minecraft:light_gray_concrete
fill 435 157 540 447 160 540 minecraft:light_gray_concrete
fill 436 157 521 446 160 521 minecraft:light_gray_concrete
fill 436 157 541 446 160 541 minecraft:light_gray_concrete
fill 439 157 520 443 160 520 minecraft:light_gray_concrete
fill 439 157 529 439 157 530 minecraft:light_gray_concrete
fill 439 157 532 439 157 533 minecraft:light_gray_concrete
fill 439 157 542 443 160 542 minecraft:light_gray_concrete
setblock 440 157 529 minecraft:light_gray_concrete
setblock 440 157 533 minecraft:light_gray_concrete
fill 442 157 529 452 157 529 minecraft:light_gray_concrete
fill 442 157 533 452 157 533 minecraft:light_gray_concrete
fill 443 157 530 452 157 530 minecraft:light_gray_concrete
fill 443 157 532 452 157 532 minecraft:light_gray_concrete
fill 444 157 531 452 157 531 minecraft:light_gray_concrete
fill 423 158 525 423 198 525 minecraft:blue_concrete
setblock 423 158 526 minecraft:white_concrete
fill 423 158 527 423 182 527 minecraft:blue_concrete
fill 423 158 540 423 180 540 minecraft:blue_concrete
setblock 423 158 541 minecraft:light_blue_stained_glass
setblock 424 158 510 minecraft:sea_lantern
fill 428 158 527 428 159 535 minecraft:sea_lantern
fill 429 158 525 429 159 528 minecraft:sea_lantern
fill 429 158 529 437 158 533 minecraft:light_gray_concrete
fill 429 158 534 429 159 537 minecraft:sea_lantern
fill 430 158 523 430 159 525 minecraft:sea_lantern
fill 430 158 526 440 158 528 minecraft:light_gray_concrete
fill 430 158 534 440 158 536 minecraft:light_gray_concrete
fill 430 158 537 430 159 539 minecraft:sea_lantern
fill 431 158 522 431 159 523 minecraft:sea_lantern
fill 431 158 524 431 159 525 minecraft:light_gray_concrete
fill 431 158 537 431 159 538 minecraft:light_gray_concrete
fill 431 158 539 431 159 540 minecraft:sea_lantern
fill 432 158 521 432 159 522 minecraft:sea_lantern
fill 432 158 523 432 159 524 minecraft:light_gray_concrete
fill 432 158 538 432 159 539 minecraft:light_gray_concrete
fill 432 158 540 432 159 541 minecraft:sea_lantern
fill 433 158 520 433 159 521 minecraft:sea_lantern
fill 433 158 522 433 159 523 minecraft:light_gray_concrete
fill 433 158 539 433 159 540 minecraft:light_gray_concrete
fill 433 158 541 433 159 542 minecraft:sea_lantern
fill 434 158 520 435 159 520 minecraft:sea_lantern
fill 434 158 521 434 159 522 minecraft:light_gray_concrete
fill 434 158 540 434 159 541 minecraft:light_gray_concrete
fill 434 158 542 435 159 542 minecraft:sea_lantern
fill 435 158 519 438 159 519 minecraft:sea_lantern
fill 435 158 521 435 159 521 minecraft:light_gray_concrete
fill 435 158 541 435 159 541 minecraft:light_gray_concrete
fill 435 158 543 438 159 543 minecraft:sea_lantern
fill 436 158 520 438 159 520 minecraft:light_gray_concrete
fill 436 158 542 438 159 542 minecraft:light_gray_concrete
fill 437 158 518 445 159 518 minecraft:sea_lantern
fill 437 158 544 445 159 544 minecraft:sea_lantern
setblock 437 158 552 minecraft:white_concrete
fill 438 158 529 438 158 530 minecraft:light_gray_concrete
fill 438 158 531 438 161 531 minecraft:light_blue_stained_glass
fill 438 158 532 438 158 533 minecraft:light_gray_concrete
fill 439 158 519 443 159 519 minecraft:light_gray_concrete
fill 439 158 529 439 160 529 minecraft:light_blue_stained_glass
fill 439 158 533 439 160 533 minecraft:light_blue_stained_glass
fill 439 158 543 443 159 543 minecraft:light_gray_concrete
fill 441 158 526 452 158 527 minecraft:light_gray_concrete
fill 441 158 528 441 161 528 minecraft:light_blue_stained_glass
fill 441 158 534 441 161 534 minecraft:light_blue_stained_glass
fill 441 158 535 452 158 536 minecraft:light_gray_concrete
fill 442 158 528 452 158 528 minecraft:light_gray_concrete
fill 442 158 534 452 158 534 minecraft:light_gray_concrete
fill 443 158 529 443 160 529 minecraft:light_blue_stained_glass
fill 443 158 533 443 160 533 minecraft:light_blue_stained_glass
fill 444 158 519 447 159 519 minecraft:sea_lantern
fill 444 158 520 446 159 520 minecraft:light_gray_concrete
fill 444 158 529 453 158 530 minecraft:light_gray_concrete
fill 444 158 531 444 161 531 minecraft:light_blue_stained_glass
fill 444 158 532 453 158 533 minecraft:light_gray_concrete
fill 444 158 542 446 159 542 minecraft:light_gray_concrete
fill 444 158 543 447 159 543 minecraft:sea_lantern
fill 445 158 531 453 158 531 minecraft:light_gray_concrete
fill 447 158 520 449 159 520 minecraft:sea_lantern
fill 447 158 521 448 159 521 minecraft:light_gray_concrete
fill 447 158 541 448 159 541 minecraft:light_gray_concrete
fill 447 158 542 449 159 542 minecraft:sea_lantern
fill 448 158 522 449 159 522 minecraft:light_gray_concrete
fill 448 158 540 449 159 540 minecraft:light_gray_concrete
fill 449 158 521 450 159 521 minecraft:sea_lantern
fill 449 158 523 450 159 523 minecraft:light_gray_concrete
fill 449 158 539 450 159 539 minecraft:light_gray_concrete
fill 449 158 541 450 159 541 minecraft:sea_lantern
fill 450 158 522 451 159 522 minecraft:sea_lantern
fill 450 158 524 451 159 524 minecraft:light_gray_concrete
fill 450 158 538 451 159 538 minecraft:light_gray_concrete
fill 450 158 540 451 159 540 minecraft:sea_lantern
fill 451 158 523 452 159 523 minecraft:sea_lantern
fill 451 158 525 451 159 525 minecraft:light_gray_concrete
fill 451 158 537 451 159 537 minecraft:light_gray_concrete
fill 451 158 539 452 159 539 minecraft:sea_lantern
fill 452 158 524 452 159 525 minecraft:sea_lantern
fill 452 158 537 452 159 538 minecraft:sea_lantern
fill 453 158 525 453 159 528 minecraft:sea_lantern
fill 453 158 534 453 159 537 minecraft:sea_lantern
fill 454 158 527 454 159 535 minecraft:sea_lantern
fill 465 158 541 465 184 544 minecraft:blue_concrete
setblock 465 158 545 minecraft:sea_lantern
fill 465 158 546 465 222 546 minecraft:blue_concrete
fill 423 159 526 423 221 526 minecraft:blue_concrete
setblock 423 159 528 minecraft:white_concrete
fill 423 159 541 423 176 541 minecraft:blue_concrete
fill 424 159 510 424 181 510 minecraft:blue_concrete
fill 426 159 535 427 201 537 minecraft:waxed_copper_block
fill 428 159 536 428 201 537 minecraft:waxed_copper_block
fill 429 159 529 436 159 533 minecraft:light_gray_concrete
fill 430 159 526 437 159 528 minecraft:light_gray_concrete
fill 430 159 534 437 159 536 minecraft:light_gray_concrete
fill 437 159 529 437 163 533 minecraft:light_blue_stained_glass
fill 437 159 552 437 161 552 minecraft:blue_concrete
fill 438 159 526 438 159 527 minecraft:light_gray_concrete
fill 438 159 528 438 162 530 minecraft:light_blue_stained_glass
fill 438 159 532 438 162 534 minecraft:light_blue_stained_glass
fill 438 159 535 438 159 536 minecraft:light_gray_concrete
fill 439 159 526 452 159 526 minecraft:light_gray_concrete
fill 439 159 527 440 162 528 minecraft:light_blue_stained_glass
fill 439 159 534 440 162 535 minecraft:light_blue_stained_glass
fill 439 159 536 452 159 536 minecraft:light_gray_concrete
fill 441 159 527 443 163 527 minecraft:light_blue_stained_glass
fill 441 159 535 443 163 535 minecraft:light_blue_stained_glass
fill 442 159 528 444 162 528 minecraft:light_blue_stained_glass
fill 442 159 534 444 162 534 minecraft:light_blue_stained_glass
fill 444 159 527 452 159 527 minecraft:light_gray_concrete
fill 444 159 529 445 162 530 minecraft:light_blue_stained_glass
fill 444 159 532 445 162 533 minecraft:light_blue_stained_glass
fill 444 159 535 452 159 535 minecraft:light_gray_concrete
fill 445 159 528 452 159 528 minecraft:light_gray_concrete
fill 445 159 531 445 163 531 minecraft:light_blue_stained_glass
fill 445 159 534 452 159 534 minecraft:light_gray_concrete
setblock 445 159 552 minecraft:white_concrete
fill 446 159 529 453 159 533 minecraft:light_gray_concrete
fill 447 159 552 448 222 552 minecraft:blue_concrete
setblock 449 159 552 minecraft:light_blue_stained_glass
fill 450 159 552 450 224 552 minecraft:blue_concrete
fill 452 159 514 454 218 514 minecraft:waxed_copper_block
fill 453 159 513 453 218 513 minecraft:waxed_copper_block
fill 453 159 515 453 218 515 minecraft:waxed_copper_block
fill 465 159 522 465 163 524 minecraft:blue_concrete
setblock 465 159 525 minecraft:sea_lantern
fill 465 159 526 465 184 526 minecraft:blue_concrete
fill 465 159 545 465 222 545 minecraft:blue_concrete
fill 423 160 528 423 224 528 minecraft:blue_concrete
fill 428 160 535 428 201 535 minecraft:waxed_copper_block
fill 430 160 529 435 160 533 minecraft:light_gray_concrete
fill 431 160 526 436 160 528 minecraft:light_gray_concrete
fill 431 160 534 436 160 536 minecraft:light_gray_concrete
fill 436 160 529 436 162 533 minecraft:light_blue_stained_glass
fill 437 160 526 438 160 526 minecraft:light_gray_concrete
fill 437 160 527 437 162 528 minecraft:light_blue_stained_glass
fill 437 160 534 437 162 535 minecraft:light_blue_stained_glass
fill 437 160 536 438 160 536 minecraft:light_gray_concrete
fill 438 160 510 438 165 510 minecraft:blue_concrete
fill 438 160 527 438 162 527 minecraft:light_blue_stained_glass
fill 438 160 535 438 162 535 minecraft:light_blue_stained_glass
setblock 439 160 510 minecraft:sea_lantern
fill 439 160 526 443 162 526 minecraft:light_blue_stained_glass
fill 439 160 536 443 162 536 minecraft:light_blue_stained_glass
fill 440 160 510 440 193 510 minecraft:blue_concrete
fill 444 160 526 451 160 526 minecraft:light_gray_concrete
fill 444 160 527 445 162 527 minecraft:light_blue_stained_glass
fill 444 160 535 445 162 535 minecraft:light_blue_stained_glass
fill 444 160 536 451 160 536 minecraft:light_gray_concrete
fill 445 160 528 445 162 528 minecraft:light_blue_stained_glass
fill 445 160 534 445 162 534 minecraft:light_blue_stained_glass
fill 445 160 552 445 220 552 minecraft:blue_concrete
fill 446 160 527 451 160 528 minecraft:light_gray_concrete
fill 446 160 529 446 162 533 minecraft:light_blue_stained_glass
fill 446 160 534 451 160 535 minecraft:light_gray_concrete
fill 447 160 529 452 160 533 minecraft:light_gray_concrete
fill 449 160 552 449 216 552 minecraft:blue_concrete
fill 455 160 552 455 198 552 minecraft:blue_concrete
setblock 456 160 552 minecraft:white_concrete
fill 457 160 552 457 161 552 minecraft:blue_concrete
fill 460 160 510 461 174 510 minecraft:blue_concrete
setblock 462 160 510 minecraft:light_blue_stained_glass
setblock 464 160 552 minecraft:white_concrete
fill 465 160 525 465 224 525 minecraft:blue_concrete
fill 465 160 552 465 224 552 minecraft:blue_concrete
fill 425 161 535 425 161 537 minecraft:waxed_cut_copper
fill 426 161 534 428 161 534 minecraft:waxed_cut_copper
fill 426 161 538 428 161 538 minecraft:waxed_cut_copper
fill 429 161 535 429 161 537 minecraft:waxed_cut_copper
setblock 435 161 531 minecraft:light_blue_stained_glass
setblock 436 161 528 minecraft:light_blue_stained_glass
setblock 436 161 534 minecraft:light_blue_stained_glass
setblock 437 161 510 minecraft:white_concrete
setblock 438 161 526 minecraft:light_blue_stained_glass
setblock 438 161 536 minecraft:light_blue_stained_glass
fill 439 161 510 439 170 510 minecraft:blue_concrete
setblock 441 161 525 minecraft:light_blue_stained_glass
setblock 441 161 537 minecraft:light_blue_stained_glass
setblock 444 161 526 minecraft:light_blue_stained_glass
setblock 444 161 536 minecraft:light_blue_stained_glass
setblock 446 161 528 minecraft:light_blue_stained_glass
setblock 446 161 534 minecraft:light_blue_stained_glass
setblock 447 161 531 minecraft:light_blue_stained_glass
setblock 452 161 513 minecraft:waxed_cut_copper
setblock 452 161 515 minecraft:waxed_cut_copper
setblock 454 161 513 minecraft:waxed_cut_copper
setblock 454 161 515 minecraft:waxed_cut_copper
fill 456 161 552 456 224 552 minecraft:blue_concrete
fill 462 161 510 462 187 510 minecraft:blue_concrete
fill 464 161 552 464 165 552 minecraft:blue_concrete
setblock 465 161 548 minecraft:sea_lantern
fill 465 161 549 465 193 550 minecraft:blue_concrete
fill 423 162 518 423 164 518 minecraft:gold_block
fill 423 162 534 423 164 534 minecraft:gold_block
fill 423 162 550 423 164 550 minecraft:gold_block
setblock 426 162 513 minecraft:light[level=14]
setblock 426 162 521 minecraft:light[level=14]
setblock 426 162 529 minecraft:light[level=14]
setblock 426 162 545 minecraft:light[level=14]
fill 427 162 510 427 164 510 minecraft:gold_block
setblock 434 162 513 minecraft:light[level=14]
setblock 434 162 521 minecraft:light[level=14]
setblock 434 162 529 minecraft:light[level=14]
setblock 434 162 537 minecraft:light[level=14]
setblock 434 162 545 minecraft:light[level=14]
fill 437 162 510 437 169 510 minecraft:blue_concrete
fill 437 162 552 437 164 552 minecraft:gold_block
setblock 442 162 513 minecraft:light[level=14]
setblock 442 162 521 minecraft:light[level=14]
setblock 442 162 537 minecraft:light[level=14]
setblock 442 162 545 minecraft:light[level=14]
fill 443 162 510 443 164 510 minecraft:gold_block
setblock 446 162 552 minecraft:light_blue_stained_glass
setblock 450 162 513 minecraft:light[level=14]
setblock 450 162 521 minecraft:light[level=14]
setblock 450 162 529 minecraft:light[level=14]
setblock 450 162 537 minecraft:light[level=14]
setblock 450 162 545 minecraft:light[level=14]
fill 453 162 552 453 164 552 minecraft:gold_block
setblock 457 162 552 minecraft:sea_lantern
setblock 458 162 513 minecraft:light[level=14]
setblock 458 162 521 minecraft:light[level=14]
setblock 458 162 529 minecraft:light[level=14]
setblock 458 162 537 minecraft:light[level=14]
setblock 458 162 545 minecraft:light[level=14]
fill 459 162 510 459 164 510 minecraft:gold_block
fill 465 162 520 465 164 520 minecraft:gold_block
fill 465 162 536 465 164 536 minecraft:gold_block
fill 465 162 548 465 177 548 minecraft:blue_concrete
fill 424 163 535 425 164 537 minecraft:waxed_copper_block
fill 438 163 528 438 163 529 minecraft:light_blue_stained_glass
fill 438 163 533 438 163 534 minecraft:light_blue_stained_glass
fill 439 163 527 439 163 528 minecraft:light_blue_stained_glass
fill 439 163 534 439 163 535 minecraft:light_blue_stained_glass
setblock 440 163 527 minecraft:light_blue_stained_glass
setblock 440 163 535 minecraft:light_blue_stained_glass
fill 443 163 528 444 163 528 minecraft:light_blue_stained_glass
fill 443 163 534 444 163 534 minecraft:light_blue_stained_glass
fill 444 163 529 445 163 529 minecraft:light_blue_stained_glass
fill 444 163 533 445 163 533 minecraft:light_blue_stained_glass
setblock 445 163 530 minecraft:light_blue_stained_glass
setblock 445 163 532 minecraft:light_blue_stained_glass
fill 446 163 552 446 220 552 minecraft:blue_concrete
setblock 454 163 552 minecraft:white_concrete
fill 457 163 552 457 224 552 minecraft:blue_concrete
setblock 465 163 511 minecraft:white_concrete
fill 465 163 512 465 194 513 minecraft:blue_concrete
setblock 423 164 523 minecraft:light_blue_stained_glass
fill 427 164 522 431 171 524 minecraft:yellow_concrete
fill 428 164 521 430 171 521 minecraft:yellow_concrete
fill 428 164 525 430 171 525 minecraft:yellow_concrete
setblock 429 164 536 minecraft:sea_lantern
fill 431 164 552 431 220 552 minecraft:blue_concrete
setblock 432 164 552 minecraft:white_concrete
fill 433 164 552 435 171 552 minecraft:blue_concrete
fill 454 164 552 454 182 552 minecraft:blue_concrete
setblock 458 164 552 minecraft:sea_lantern
fill 465 164 511 465 224 511 minecraft:blue_concrete
fill 465 164 522 465 165 523 minecraft:blue_concrete
fill 465 164 524 465 165 524 minecraft:white_concrete
setblock 423 165 518 minecraft:sea_lantern
fill 423 165 523 423 188 523 minecraft:blue_concrete
fill 423 165 534 423 170 534 minecraft:blue_concrete
fill 423 165 550 423 170 550 minecraft:blue_concrete
fill 426 165 522 426 170 524 minecraft:yellow_concrete
fill 427 165 510 427 170 510 minecraft:blue_concrete
fill 427 165 521 427 170 521 minecraft:yellow_concrete
fill 427 165 525 427 170 526 minecraft:yellow_concrete
fill 428 165 520 430 170 520 minecraft:yellow_concrete
fill 428 165 526 431 170 526 minecraft:yellow_concrete
fill 431 165 521 431 170 521 minecraft:yellow_concrete
fill 431 165 525 432 170 525 minecraft:yellow_concrete
fill 432 165 522 432 170 524 minecraft:yellow_concrete
fill 432 165 552 432 222 552 minecraft:blue_concrete
fill 437 165 552 437 170 552 minecraft:blue_concrete
fill 443 165 510 443 170 510 minecraft:blue_concrete
fill 453 165 552 453 170 552 minecraft:blue_concrete
fill 458 165 552 458 167 552 minecraft:blue_concrete
fill 459 165 510 459 170 510 minecraft:blue_concrete
fill 465 165 520 465 170 520 minecraft:blue_concrete
fill 465 165 536 465 170 536 minecraft:blue_concrete
fill 423 166 518 423 170 518 minecraft:blue_concrete
fill 423 166 546 423 224 546 minecraft:blue_concrete
setblock 423 166 547 minecraft:sea_lantern
fill 423 166 548 423 221 548 minecraft:blue_concrete
fill 426 166 521 426 169 521 minecraft:yellow_concrete
fill 426 166 525 426 169 525 minecraft:yellow_concrete
fill 427 166 520 427 169 520 minecraft:yellow_concrete
setblock 428 166 510 minecraft:white_concrete
fill 428 166 527 430 169 527 minecraft:yellow_concrete
fill 429 166 510 432 182 510 minecraft:blue_concrete
fill 431 166 520 431 169 520 minecraft:yellow_concrete
fill 432 166 521 432 169 521 minecraft:yellow_concrete
fill 432 166 526 432 169 526 minecraft:yellow_concrete
fill 433 166 523 433 169 524 minecraft:yellow_concrete
setblock 438 166 510 minecraft:light_blue_stained_glass
setblock 464 166 552 minecraft:white_concrete
fill 465 166 522 465 224 522 minecraft:blue_concrete
setblock 465 166 523 minecraft:light_blue_stained_glass
fill 465 166 524 465 170 524 minecraft:blue_concrete
fill 423 167 547 423 208 547 minecraft:blue_concrete
fill 425 167 522 425 168 524 minecraft:yellow_concrete
fill 425 167 535 425 167 537 minecraft:waxed_cut_copper
fill 426 167 526 426 168 526 minecraft:yellow_concrete
fill 426 167 534 428 167 534 minecraft:waxed_cut_copper
fill 426 167 538 428 167 538 minecraft:waxed_cut_copper
fill 427 167 527 427 168 527 minecraft:yellow_concrete
fill 427 167 548 427 168 550 minecraft:waxed_copper_block
fill 428 167 510 428 224 510 minecraft:blue_concrete
fill 429 167 519 429 168 519 minecraft:yellow_concrete
fill 429 167 535 429 167 537 minecraft:waxed_cut_copper
fill 431 167 527 431 168 527 minecraft:yellow_concrete
fill 433 167 522 433 168 522 minecraft:yellow_concrete
fill 433 167 525 433 168 525 minecraft:yellow_concrete
fill 438 167 510 438 170 510 minecraft:blue_concrete
setblock 452 167 513 minecraft:waxed_cut_copper
setblock 452 167 515 minecraft:waxed_cut_copper
setblock 454 167 513 minecraft:waxed_cut_copper
setblock 454 167 515 minecraft:waxed_cut_copper
fill 464 167 552 464 221 552 minecraft:blue_concrete
setblock 465 167 523 minecraft:white_concrete
fill 444 168 510 446 220 510 minecraft:blue_concrete
setblock 447 168 510 minecraft:sea_lantern
setblock 458 168 552 minecraft:sea_lantern
fill 465 168 523 465 224 523 minecraft:blue_concrete
setblock 465 168 532 minecraft:sea_lantern
fill 447 169 510 447 224 510 minecraft:blue_concrete
fill 458 169 552 458 187 552 minecraft:blue_concrete
fill 465 169 532 465 224 532 minecraft:blue_concrete
setblock 426 170 513 minecraft:light[level=14]
setblock 426 170 521 minecraft:light[level=14]
setblock 426 170 529 minecraft:light[level=14]
setblock 426 170 545 minecraft:light[level=14]
setblock 434 170 513 minecraft:light[level=14]
setblock 434 170 521 minecraft:light[level=14]
setblock 434 170 529 minecraft:light[level=14]
setblock 434 170 537 minecraft:light[level=14]
setblock 434 170 545 minecraft:light[level=14]
setblock 437 170 510 minecraft:light_blue_stained_glass
setblock 442 170 513 minecraft:light[level=14]
setblock 442 170 521 minecraft:light[level=14]
setblock 442 170 529 minecraft:light[level=14]
setblock 442 170 537 minecraft:light[level=14]
setblock 442 170 545 minecraft:light[level=14]
setblock 450 170 513 minecraft:light[level=14]
setblock 450 170 521 minecraft:light[level=14]
setblock 450 170 529 minecraft:light[level=14]
setblock 450 170 537 minecraft:light[level=14]
setblock 450 170 545 minecraft:light[level=14]
setblock 458 170 513 minecraft:light[level=14]
setblock 458 170 521 minecraft:light[level=14]
setblock 458 170 529 minecraft:light[level=14]
setblock 458 170 537 minecraft:light[level=14]
setblock 458 170 545 minecraft:light[level=14]
setblock 462 170 552 minecraft:white_concrete
setblock 465 170 514 minecraft:white_concrete
setblock 465 170 539 minecraft:sea_lantern
fill 423 171 518 423 173 518 minecraft:gold_block
fill 423 171 534 423 173 534 minecraft:gold_block
fill 423 171 550 423 173 550 minecraft:gold_block
fill 427 171 510 427 173 510 minecraft:gold_block
fill 437 171 510 437 221 510 minecraft:blue_concrete
fill 437 171 552 437 173 552 minecraft:gold_block
setblock 438 171 510 minecraft:light_blue_stained_glass
setblock 439 171 510 minecraft:white_concrete
setblock 442 171 552 minecraft:white_concrete
fill 443 171 510 443 173 510 minecraft:gold_block
setblock 443 171 552 minecraft:light_blue_stained_glass
fill 444 171 552 444 224 552 minecraft:blue_concrete
fill 453 171 552 453 173 552 minecraft:gold_block
fill 459 171 510 459 173 510 minecraft:gold_block
fill 462 171 552 462 224 552 minecraft:blue_concrete
fill 463 171 510 463 202 510 minecraft:blue_concrete
setblock 464 171 510 minecraft:white_concrete
fill 465 171 510 465 224 510 minecraft:blue_concrete
fill 465 171 514 465 225 514 minecraft:blue_concrete
fill 465 171 520 465 173 520 minecraft:gold_block
setblock 465 171 524 minecraft:light_blue_stained_glass
fill 465 171 536 465 173 536 minecraft:gold_block
fill 465 171 539 465 224 539 minecraft:blue_concrete
setblock 423 172 543 minecraft:sea_lantern
fill 423 172 544 423 222 544 minecraft:blue_concrete
fill 433 172 552 433 221 552 minecraft:blue_concrete
setblock 434 172 552 minecraft:light_blue_stained_glass
fill 435 172 552 435 183 552 minecraft:blue_concrete
fill 438 172 510 439 204 510 minecraft:blue_concrete
fill 442 172 552 443 212 552 minecraft:blue_concrete
fill 464 172 510 464 185 510 minecraft:blue_concrete
fill 465 172 517 465 224 517 minecraft:blue_concrete
setblock 465 172 518 minecraft:light_blue_stained_glass
fill 465 172 519 465 224 519 minecraft:blue_concrete
fill 465 172 524 465 215 524 minecraft:blue_concrete
setblock 465 172 535 minecraft:white_concrete
fill 423 173 543 423 176 543 minecraft:blue_concrete
setblock 425 173 510 minecraft:light_blue_stained_glass
fill 425 173 535 425 173 537 minecraft:waxed_cut_copper
fill 426 173 534 428 173 534 minecraft:waxed_cut_copper
fill 426 173 538 428 173 538 minecraft:waxed_cut_copper
fill 429 173 535 429 173 537 minecraft:waxed_cut_copper
fill 434 173 552 434 210 552 minecraft:blue_concrete
setblock 452 173 513 minecraft:waxed_cut_copper
setblock 452 173 515 minecraft:waxed_cut_copper
setblock 454 173 513 minecraft:waxed_cut_copper
setblock 454 173 515 minecraft:waxed_cut_copper
fill 465 173 518 465 204 518 minecraft:blue_concrete
fill 465 173 535 465 224 535 minecraft:blue_concrete
fill 423 174 518 423 176 518 minecraft:blue_concrete
fill 423 174 534 423 179 534 minecraft:blue_concrete
fill 423 174 550 423 179 550 minecraft:blue_concrete
fill 425 174 510 425 178 510 minecraft:blue_concrete
fill 425 174 552 425 209 552 minecraft:blue_concrete
setblock 426 174 552 minecraft:sea_lantern
fill 427 174 510 427 179 510 minecraft:blue_concrete
fill 427 174 552 428 180 552 minecraft:blue_concrete
fill 437 174 552 437 179 552 minecraft:blue_concrete
setblock 438 174 552 minecraft:light_blue_stained_glass
setblock 439 174 552 minecraft:sea_lantern
fill 443 174 510 443 179 510 minecraft:blue_concrete
fill 453 174 552 453 179 552 minecraft:blue_concrete
fill 459 174 510 459 179 510 minecraft:blue_concrete
fill 465 174 520 465 179 520 minecraft:blue_concrete
fill 465 174 536 465 179 536 minecraft:blue_concrete
fill 426 175 552 426 195 552 minecraft:blue_concrete
fill 438 175 552 439 213 552 minecraft:blue_concrete
setblock 460 175 510 minecraft:blue_concrete
setblock 461 175 510 minecraft:white_concrete
setblock 423 176 536 minecraft:sea_lantern
fill 423 176 537 423 222 537 minecraft:blue_concrete
fill 457 176 535 461 177 539 minecraft:polished_blackstone
setblock 460 176 510 minecraft:light_blue_stained_glass
fill 461 176 510 461 224 510 minecraft:blue_concrete
fill 462 176 537 463 176 537 minecraft:polished_blackstone
setblock 423 177 518 minecraft:light_blue_stained_glass
setblock 423 177 519 minecraft:white_concrete
fill 423 177 520 423 226 520 minecraft:blue_concrete
fill 423 177 536 423 225 536 minecraft:blue_concrete
setblock 423 177 541 minecraft:white_concrete
setblock 423 177 543 minecraft:white_concrete
fill 460 177 510 460 221 510 minecraft:blue_concrete
fill 423 178 518 423 179 519 minecraft:blue_concrete
fill 423 178 541 423 224 541 minecraft:blue_concrete
fill 423 178 543 423 186 543 minecraft:blue_concrete
setblock 426 178 513 minecraft:light[level=14]
setblock 426 178 521 minecraft:light[level=14]
setblock 426 178 529 minecraft:light[level=14]
setblock 426 178 545 minecraft:light[level=14]
setblock 434 178 513 minecraft:light[level=14]
setblock 434 178 521 minecraft:light[level=14]
setblock 434 178 529 minecraft:light[level=14]
setblock 434 178 537 minecraft:light[level=14]
setblock 434 178 545 minecraft:light[level=14]
setblock 440 178 552 minecraft:sea_lantern
setblock 442 178 513 minecraft:light[level=14]
setblock 442 178 521 minecraft:light[level=14]
setblock 442 178 529 minecraft:light[level=14]
setblock 442 178 537 minecraft:light[level=14]
setblock 442 178 545 minecraft:light[level=14]
setblock 450 178 513 minecraft:light[level=14]
setblock 450 178 521 minecraft:light[level=14]
setblock 450 178 529 minecraft:light[level=14]
setblock 450 178 537 minecraft:light[level=14]
setblock 450 178 545 minecraft:light[level=14]
setblock 458 178 513 minecraft:light[level=14]
setblock 458 178 521 minecraft:light[level=14]
setblock 458 178 529 minecraft:light[level=14]
setblock 458 178 537 minecraft:light[level=14]
setblock 458 178 545 minecraft:light[level=14]
setblock 465 178 548 minecraft:sea_lantern
setblock 425 179 510 minecraft:sea_lantern
fill 425 179 535 425 179 537 minecraft:waxed_cut_copper
fill 426 179 534 428 179 534 minecraft:waxed_cut_copper
fill 426 179 538 428 179 538 minecraft:waxed_cut_copper
fill 429 179 535 429 179 537 minecraft:waxed_cut_copper
fill 440 179 552 440 224 552 minecraft:blue_concrete
setblock 441 179 552 minecraft:sea_lantern
setblock 452 179 513 minecraft:waxed_cut_copper
setblock 452 179 515 minecraft:waxed_cut_copper
setblock 454 179 513 minecraft:waxed_cut_copper
setblock 454 179 515 minecraft:waxed_cut_copper
fill 457 179 520 461 180 524 minecraft:polished_blackstone
fill 459 179 537 459 186 537 minecraft:gold_block
fill 462 179 522 463 179 522 minecraft:polished_blackstone
fill 465 179 548 465 186 548 minecraft:blue_concrete
fill 423 180 518 423 182 518 minecraft:gold_block
fill 423 180 519 423 224 519 minecraft:blue_concrete
fill 423 180 534 423 182 534 minecraft:gold_block
fill 423 180 550 423 182 550 minecraft:gold_block
fill 425 180 510 425 181 510 minecraft:blue_concrete
fill 427 180 510 427 182 510 minecraft:gold_block
fill 437 180 552 437 182 552 minecraft:gold_block
fill 441 180 552 441 224 552 minecraft:blue_concrete
fill 443 180 510 443 182 510 minecraft:gold_block
fill 453 180 552 453 182 552 minecraft:gold_block
fill 457 180 536 458 185 538 minecraft:gold_block
fill 458 180 535 460 185 535 minecraft:gold_block
fill 458 180 539 460 185 539 minecraft:gold_block
fill 459 180 510 459 182 510 minecraft:gold_block
fill 459 180 536 461 185 536 minecraft:gold_block
fill 459 180 538 461 185 538 minecraft:gold_block
fill 460 180 537 461 185 537 minecraft:gold_block
fill 465 180 520 465 182 520 minecraft:gold_block
fill 465 180 536 465 182 536 minecraft:gold_block
setblock 423 181 540 minecraft:sea_lantern
setblock 427 181 552 minecraft:white_concrete
fill 428 181 552 428 210 552 minecraft:blue_concrete
fill 456 181 536 456 184 538 minecraft:gold_block
fill 457 181 535 457 184 535 minecraft:gold_block
fill 457 181 539 457 184 539 minecraft:gold_block
fill 458 181 534 460 184 534 minecraft:gold_block
fill 458 181 540 460 184 540 minecraft:gold_block
fill 461 181 535 461 184 535 minecraft:gold_block
fill 461 181 539 461 184 539 minecraft:gold_block
fill 462 181 536 462 184 538 minecraft:gold_block
setblock 465 181 528 minecraft:light_blue_stained_glass
fill 423 182 540 423 224 540 minecraft:blue_concrete
setblock 424 182 510 minecraft:white_concrete
setblock 425 182 510 minecraft:light_blue_stained_glass
fill 427 182 552 427 184 552 minecraft:blue_concrete
fill 459 182 522 459 189 522 minecraft:gold_block
fill 465 182 528 465 225 528 minecraft:blue_concrete
setblock 423 183 511 minecraft:white_concrete
fill 423 183 518 423 188 518 minecraft:blue_concrete
setblock 423 183 527 minecraft:sea_lantern
fill 423 183 534 423 188 534 minecraft:blue_concrete
fill 423 183 550 423 188 550 minecraft:blue_concrete
fill 424 183 510 425 188 510 minecraft:blue_concrete
fill 427 183 510 427 188 510 minecraft:blue_concrete
fill 429 183 510 429 205 510 minecraft:blue_concrete
setblock 430 183 510 minecraft:sea_lantern
fill 431 183 510 432 183 510 minecraft:blue_concrete
fill 437 183 552 437 188 552 minecraft:blue_concrete
fill 443 183 510 443 188 510 minecraft:blue_concrete
fill 453 183 552 453 188 552 minecraft:blue_concrete
setblock 454 183 552 minecraft:light_blue_stained_glass
fill 457 183 521 458 188 523 minecraft:gold_block
fill 458 183 520 460 188 520 minecraft:gold_block
fill 458 183 524 460 188 524 minecraft:gold_block
fill 459 183 510 459 188 510 minecraft:blue_concrete
fill 459 183 521 461 188 521 minecraft:gold_block
fill 459 183 523 461 188 523 minecraft:gold_block
fill 460 183 522 461 188 522 minecraft:gold_block
fill 465 183 520 465 188 520 minecraft:blue_concrete
fill 465 183 536 465 184 536 minecraft:blue_concrete
fill 423 184 511 423 221 511 minecraft:blue_concrete
fill 423 184 527 423 221 527 minecraft:blue_concrete
setblock 429 184 552 minecraft:light_blue_stained_glass
fill 430 184 510 431 222 510 minecraft:blue_concrete
setblock 432 184 510 minecraft:white_concrete
setblock 435 184 552 minecraft:white_concrete
fill 454 184 552 454 206 552 minecraft:blue_concrete
fill 456 184 521 456 187 523 minecraft:gold_block
fill 457 184 520 457 187 520 minecraft:gold_block
fill 457 184 524 457 187 524 minecraft:gold_block
fill 458 184 519 460 187 519 minecraft:gold_block
fill 458 184 525 460 187 525 minecraft:gold_block
fill 461 184 520 461 187 520 minecraft:gold_block
fill 461 184 524 461 187 524 minecraft:gold_block
fill 462 184 521 462 187 523 minecraft:gold_block
setblock 423 185 549 minecraft:light_blue_stained_glass
fill 425 185 535 425 185 537 minecraft:waxed_cut_copper
fill 426 185 534 428 185 534 minecraft:waxed_cut_copper
fill 426 185 538 428 185 538 minecraft:waxed_cut_copper
setblock 427 185 552 minecraft:light_blue_stained_glass
fill 429 185 535 429 185 537 minecraft:waxed_cut_copper
fill 429 185 552 429 186 552 minecraft:blue_concrete
fill 432 185 510 432 220 510 minecraft:blue_concrete
fill 435 185 552 435 218 552 minecraft:blue_concrete
setblock 452 185 513 minecraft:waxed_cut_copper
setblock 452 185 515 minecraft:waxed_cut_copper
setblock 454 185 513 minecraft:waxed_cut_copper
setblock 454 185 515 minecraft:waxed_cut_copper
setblock 465 185 526 minecraft:sea_lantern
setblock 465 185 536 minecraft:light_blue_stained_glass
fill 465 185 541 465 196 542 minecraft:blue_concrete
setblock 465 185 543 minecraft:sea_lantern
fill 465 185 544 465 211 544 minecraft:blue_concrete
setblock 465 185 547 minecraft:light_blue_stained_glass
fill 423 186 549 423 222 549 minecraft:blue_concrete
setblock 426 186 513 minecraft:light[level=14]
setblock 426 186 521 minecraft:light[level=14]
setblock 426 186 529 minecraft:light[level=14]
setblock 426 186 545 minecraft:light[level=14]
fill 427 186 552 427 224 552 minecraft:blue_concrete
setblock 434 186 513 minecraft:light[level=14]
setblock 434 186 521 minecraft:light[level=14]
setblock 434 186 529 minecraft:light[level=14]
setblock 434 186 537 minecraft:light[level=14]
setblock 434 186 545 minecraft:light[level=14]
setblock 442 186 513 minecraft:light[level=14]
setblock 442 186 521 minecraft:light[level=14]
setblock 442 186 529 minecraft:light[level=14]
setblock 442 186 537 minecraft:light[level=14]
setblock 442 186 545 minecraft:light[level=14]
setblock 450 186 513 minecraft:light[level=14]
setblock 450 186 521 minecraft:light[level=14]
setblock 450 186 529 minecraft:light[level=14]
setblock 450 186 537 minecraft:light[level=14]
setblock 450 186 545 minecraft:light[level=14]
setblock 458 186 513 minecraft:light[level=14]
setblock 458 186 529 minecraft:light[level=14]
setblock 458 186 537 minecraft:light[level=14]
setblock 458 186 545 minecraft:light[level=14]
setblock 464 186 510 minecraft:sea_lantern
fill 465 186 526 465 213 526 minecraft:blue_concrete
fill 465 186 536 465 188 536 minecraft:blue_concrete
fill 465 186 543 465 224 543 minecraft:blue_concrete
fill 465 186 547 465 217 547 minecraft:blue_concrete
setblock 423 187 543 minecraft:white_concrete
setblock 429 187 552 minecraft:light_blue_stained_glass
fill 464 187 510 464 224 510 minecraft:blue_concrete
setblock 465 187 548 minecraft:white_concrete
fill 423 188 543 423 222 543 minecraft:blue_concrete
setblock 423 188 545 minecraft:sea_lantern
fill 429 188 552 429 220 552 minecraft:blue_concrete
setblock 458 188 552 minecraft:light_blue_stained_glass
setblock 462 188 510 minecraft:sea_lantern
fill 465 188 548 465 195 548 minecraft:blue_concrete
setblock 423 189 513 minecraft:white_concrete
fill 423 189 518 423 191 518 minecraft:gold_block
setblock 423 189 523 minecraft:sea_lantern
fill 423 189 534 423 191 534 minecraft:gold_block
fill 423 189 545 423 190 545 minecraft:blue_concrete
fill 423 189 550 423 191 550 minecraft:gold_block
fill 424 189 510 424 224 510 minecraft:blue_concrete
setblock 425 189 510 minecraft:white_concrete
fill 427 189 510 427 191 510 minecraft:gold_block
fill 437 189 552 437 191 552 minecraft:gold_block
fill 443 189 510 443 191 510 minecraft:gold_block
fill 453 189 552 453 191 552 minecraft:gold_block
fill 458 189 552 458 224 552 minecraft:blue_concrete
fill 459 189 510 459 191 510 minecraft:gold_block
fill 462 189 510 462 206 510 minecraft:blue_concrete
fill 465 189 520 465 191 520 minecraft:gold_block
fill 465 189 536 465 191 536 minecraft:gold_block
fill 423 190 513 423 221 513 minecraft:blue_concrete
fill 423 190 523 423 225 523 minecraft:blue_concrete
setblock 423 190 535 minecraft:light_blue_stained_glass
fill 425 190 510 425 191 510 minecraft:blue_concrete
setblock 461 190 552 minecraft:white_concrete
setblock 465 190 533 minecraft:light_blue_stained_glass
fill 423 191 535 423 224 535 minecraft:blue_concrete
setblock 423 191 545 minecraft:white_concrete
fill 425 191 535 425 191 537 minecraft:waxed_cut_copper
fill 426 191 534 428 191 534 minecraft:waxed_cut_copper
fill 426 191 538 428 191 538 minecraft:waxed_cut_copper
fill 429 191 535 429 191 537 minecraft:waxed_cut_copper
fill 451 191 552 451 203 552 minecraft:blue_concrete
setblock 452 191 513 minecraft:waxed_cut_copper
setblock 452 191 515 minecraft:waxed_cut_copper
setblock 452 191 552 minecraft:white_concrete
setblock 454 191 513 minecraft:waxed_cut_copper
setblock 454 191 515 minecraft:waxed_cut_copper
fill 461 191 552 461 199 552 minecraft:blue_concrete
setblock 465 191 521 minecraft:sea_lantern
fill 465 191 533 465 220 533 minecraft:blue_concrete
fill 423 192 518 423 197 518 minecraft:blue_concrete
fill 423 192 534 423 197 534 minecraft:blue_concrete
fill 423 192 545 423 208 545 minecraft:blue_concrete
fill 423 192 550 423 197 550 minecraft:blue_concrete
setblock 425 192 510 minecraft:light_blue_stained_glass
fill 427 192 510 427 197 510 minecraft:blue_concrete
fill 437 192 552 437 195 552 minecraft:blue_concrete
fill 443 192 510 443 197 510 minecraft:blue_concrete
setblock 452 192 552 minecraft:blue_concrete
setblock 453 192 552 minecraft:light_blue_stained_glass
fill 459 192 510 459 197 510 minecraft:blue_concrete
fill 465 192 520 465 196 521 minecraft:blue_concrete
setblock 465 192 531 minecraft:light_blue_stained_glass
setblock 465 192 536 minecraft:blue_concrete
fill 423 193 531 423 221 532 minecraft:blue_concrete
setblock 423 193 533 minecraft:light_blue_stained_glass
fill 425 193 510 425 213 510 minecraft:blue_concrete
setblock 452 193 552 minecraft:white_concrete
fill 453 193 552 453 197 552 minecraft:blue_concrete
fill 465 193 531 465 195 531 minecraft:blue_concrete
setblock 465 193 536 minecraft:white_concrete
fill 423 194 533 423 225 533 minecraft:blue_concrete
setblock 426 194 513 minecraft:light[level=14]
setblock 426 194 521 minecraft:light[level=14]
setblock 426 194 529 minecraft:light[level=14]
setblock 426 194 545 minecraft:light[level=14]
setblock 430 194 552 minecraft:light_blue_stained_glass
setblock 434 194 513 minecraft:light[level=14]
setblock 434 194 521 minecraft:light[level=14]
setblock 434 194 529 minecraft:light[level=14]
setblock 434 194 537 minecraft:light[level=14]
setblock 434 194 545 minecraft:light[level=14]
setblock 440 194 510 minecraft:light_blue_stained_glass
setblock 442 194 510 minecraft:sea_lantern
setblock 442 194 513 minecraft:light[level=14]
setblock 442 194 521 minecraft:light[level=14]
setblock 442 194 529 minecraft:light[level=14]
setblock 442 194 537 minecraft:light[level=14]
setblock 442 194 545 minecraft:light[level=14]
setblock 450 194 513 minecraft:light[level=14]
setblock 450 194 521 minecraft:light[level=14]
setblock 450 194 529 minecraft:light[level=14]
setblock 450 194 537 minecraft:light[level=14]
setblock 450 194 545 minecraft:light[level=14]
fill 452 194 552 452 217 552 minecraft:blue_concrete
setblock 458 194 513 minecraft:light[level=14]
setblock 458 194 521 minecraft:light[level=14]
setblock 458 194 529 minecraft:light[level=14]
setblock 458 194 537 minecraft:light[level=14]
setblock 458 194 545 minecraft:light[level=14]
fill 465 194 536 465 197 536 minecraft:blue_concrete
setblock 465 194 549 minecraft:white_concrete
fill 465 194 550 465 217 550 minecraft:blue_concrete
setblock 423 195 522 minecraft:white_concrete
fill 430 195 552 430 220 552 minecraft:blue_concrete
setblock 436 195 510 minecraft:light_blue_stained_glass
fill 440 195 510 440 224 510 minecraft:blue_concrete
fill 442 195 510 442 214 510 minecraft:blue_concrete
fill 465 195 512 465 225 512 minecraft:blue_concrete
setblock 465 195 513 minecraft:white_concrete
fill 465 195 549 465 197 549 minecraft:blue_concrete
fill 423 196 522 423 197 522 minecraft:blue_concrete
setblock 426 196 552 minecraft:sea_lantern
fill 434 196 510 434 208 510 minecraft:blue_concrete
setblock 435 196 510 minecraft:light_blue_stained_glass
fill 436 196 510 436 220 510 minecraft:blue_concrete
setblock 437 196 552 minecraft:light_blue_stained_glass
fill 465 196 513 465 204 513 minecraft:blue_concrete
setblock 465 196 531 minecraft:white_concrete
setblock 465 196 548 minecraft:sea_lantern
fill 425 197 535 425 197 537 minecraft:waxed_cut_copper
fill 426 197 534 428 197 534 minecraft:waxed_cut_copper
fill 426 197 538 428 197 538 minecraft:waxed_cut_copper
fill 426 197 552 426 224 552 minecraft:blue_concrete
fill 429 197 535 429 197 537 minecraft:waxed_cut_copper
fill 435 197 510 435 222 510 minecraft:blue_concrete
setblock 437 197 552 minecraft:blue_concrete
setblock 452 197 513 minecraft:waxed_cut_copper
setblock 452 197 515 minecraft:waxed_cut_copper
setblock 454 197 513 minecraft:waxed_cut_copper
setblock 454 197 515 minecraft:waxed_cut_copper
setblock 465 197 520 minecraft:blue_concrete
setblock 465 197 521 minecraft:sea_lantern
fill 465 197 531 465 206 531 minecraft:blue_concrete
setblock 465 197 537 minecraft:light_blue_stained_glass
setblock 465 197 541 minecraft:white_concrete
fill 465 197 542 465 221 542 minecraft:blue_concrete
fill 465 197 548 465 224 548 minecraft:blue_concrete
fill 423 198 518 423 200 518 minecraft:gold_block
setblock 423 198 522 minecraft:white_concrete
fill 423 198 534 423 200 534 minecraft:gold_block
fill 423 198 550 423 200 550 minecraft:gold_block
fill 427 198 510 427 200 510 minecraft:gold_block
fill 437 198 552 437 200 552 minecraft:gold_block
fill 443 198 510 443 200 510 minecraft:gold_block
fill 453 198 552 453 200 552 minecraft:gold_block
fill 459 198 510 459 200 510 minecraft:gold_block
fill 465 198 520 465 200 520 minecraft:gold_block
fill 465 198 521 465 224 521 minecraft:blue_concrete
fill 465 198 536 465 200 536 minecraft:gold_block
fill 465 198 537 465 225 537 minecraft:blue_concrete
fill 465 198 541 465 224 541 minecraft:blue_concrete
setblock 465 198 549 minecraft:light_blue_stained_glass
fill 423 199 522 423 215 522 minecraft:blue_concrete
setblock 423 199 525 minecraft:sea_lantern
setblock 424 199 552 minecraft:white_concrete
setblock 455 199 552 minecraft:white_concrete
fill 465 199 549 465 222 549 minecraft:blue_concrete
fill 423 200 525 423 224 525 minecraft:blue_concrete
fill 424 200 552 424 224 552 minecraft:blue_concrete
fill 455 200 552 455 224 552 minecraft:blue_concrete
fill 459 200 552 459 214 552 minecraft:blue_concrete
fill 460 200 552 461 200 552 minecraft:sea_lantern
fill 423 201 518 423 206 518 minecraft:blue_concrete
fill 423 201 534 423 206 534 minecraft:blue_concrete
fill 423 201 550 423 206 550 minecraft:blue_concrete
fill 427 201 510 427 206 510 minecraft:blue_concrete
fill 437 201 552 437 205 552 minecraft:blue_concrete
fill 443 201 510 443 206 510 minecraft:blue_concrete
setblock 453 201 510 minecraft:sea_lantern
fill 453 201 552 453 206 552 minecraft:blue_concrete
fill 454 201 510 455 205 510 minecraft:blue_concrete
setblock 457 201 510 minecraft:white_concrete
fill 459 201 510 459 206 510 minecraft:blue_concrete
fill 460 201 552 461 206 552 minecraft:blue_concrete
fill 465 201 520 465 206 520 minecraft:blue_concrete
fill 465 201 536 465 206 536 minecraft:blue_concrete
setblock 465 201 538 minecraft:light_blue_stained_glass
setblock 426 202 513 minecraft:light[level=14]
setblock 426 202 521 minecraft:light[level=14]
setblock 426 202 529 minecraft:light[level=14]
fill 426 202 535 426 218 537 minecraft:waxed_copper_block
setblock 426 202 545 minecraft:light[level=14]
fill 427 202 527 427 203 535 minecraft:waxed_cut_copper
fill 427 202 536 427 203 537 minecraft:waxed_copper_block
fill 428 202 524 428 203 527 minecraft:waxed_cut_copper
fill 428 202 535 428 203 538 minecraft:waxed_cut_copper
fill 429 202 522 429 203 524 minecraft:waxed_cut_copper
fill 429 202 538 429 203 540 minecraft:waxed_cut_copper
fill 430 202 521 430 203 522 minecraft:waxed_cut_copper
fill 430 202 540 430 203 541 minecraft:waxed_cut_copper
fill 431 202 520 431 203 521 minecraft:waxed_cut_copper
fill 431 202 541 431 203 542 minecraft:waxed_cut_copper
fill 432 202 519 432 203 519 minecraft:waxed_cut_copper
fill 432 202 543 432 203 543 minecraft:waxed_cut_copper
fill 433 202 518 434 203 518 minecraft:waxed_cut_copper
fill 433 202 544 434 203 544 minecraft:waxed_cut_copper
setblock 434 202 513 minecraft:light[level=14]
fill 434 202 517 435 203 517 minecraft:waxed_cut_copper
setblock 434 202 521 minecraft:light[level=14]
setblock 434 202 529 minecraft:light[level=14]
setblock 434 202 537 minecraft:light[level=14]
fill 434 202 545 435 203 545 minecraft:waxed_cut_copper
fill 435 202 516 437 203 516 minecraft:waxed_cut_copper
fill 435 202 546 437 203 546 minecraft:waxed_cut_copper
fill 437 202 515 440 203 515 minecraft:waxed_cut_copper
fill 437 202 547 440 203 547 minecraft:waxed_cut_copper
fill 440 202 514 448 203 514 minecraft:waxed_cut_copper
fill 440 202 548 448 203 548 minecraft:waxed_cut_copper
setblock 442 202 513 minecraft:light[level=14]
setblock 442 202 521 minecraft:light[level=14]
setblock 442 202 529 minecraft:light[level=14]
setblock 442 202 537 minecraft:light[level=14]
setblock 442 202 545 minecraft:light[level=14]
fill 448 202 515 451 203 515 minecraft:waxed_cut_copper
fill 448 202 547 451 203 547 minecraft:waxed_cut_copper
setblock 450 202 513 minecraft:light[level=14]
setblock 450 202 521 minecraft:light[level=14]
setblock 450 202 529 minecraft:light[level=14]
setblock 450 202 537 minecraft:light[level=14]
setblock 450 202 545 minecraft:light[level=14]
fill 451 202 516 453 203 516 minecraft:waxed_cut_copper
fill 451 202 546 453 203 546 minecraft:waxed_cut_copper
fill 453 202 510 453 224 510 minecraft:blue_concrete
fill 453 202 517 454 203 517 minecraft:waxed_cut_copper
fill 453 202 545 454 203 545 minecraft:waxed_cut_copper
fill 454 202 518 455 203 518 minecraft:waxed_cut_copper
fill 454 202 544 455 203 544 minecraft:waxed_cut_copper
fill 456 202 519 456 203 519 minecraft:waxed_cut_copper
fill 456 202 543 456 203 543 minecraft:waxed_cut_copper
fill 457 202 510 457 221 510 minecraft:blue_concrete
fill 457 202 520 457 203 521 minecraft:waxed_cut_copper
fill 457 202 541 457 203 542 minecraft:waxed_cut_copper
setblock 458 202 513 minecraft:light[level=14]
fill 458 202 521 458 203 522 minecraft:waxed_cut_copper
setblock 458 202 529 minecraft:light[level=14]
setblock 458 202 537 minecraft:light[level=14]
fill 458 202 540 458 203 541 minecraft:waxed_cut_copper
setblock 458 202 545 minecraft:light[level=14]
fill 459 202 522 459 203 524 minecraft:waxed_cut_copper
fill 459 202 538 459 203 540 minecraft:waxed_cut_copper
fill 460 202 524 460 203 527 minecraft:waxed_cut_copper
fill 460 202 535 460 203 538 minecraft:waxed_cut_copper
fill 461 202 527 461 203 535 minecraft:waxed_cut_copper
fill 465 202 538 465 224 538 minecraft:blue_concrete
fill 425 203 535 425 203 537 minecraft:waxed_cut_copper
setblock 426 203 534 minecraft:waxed_cut_copper
fill 426 203 538 427 203 538 minecraft:waxed_cut_copper
setblock 428 203 534 minecraft:waxed_cut_copper
fill 429 203 535 429 203 537 minecraft:waxed_cut_copper
setblock 452 203 513 minecraft:waxed_cut_copper
setblock 452 203 515 minecraft:waxed_cut_copper
setblock 454 203 513 minecraft:waxed_cut_copper
setblock 454 203 515 minecraft:waxed_cut_copper
setblock 463 203 510 minecraft:sea_lantern
fill 426 204 530 426 204 532 minecraft:sea_lantern
fill 427 204 525 427 204 529 minecraft:sea_lantern
fill 427 204 533 427 204 537 minecraft:sea_lantern
fill 428 204 523 428 204 524 minecraft:sea_lantern
fill 428 204 535 428 218 537 minecraft:waxed_copper_block
fill 428 204 538 428 204 539 minecraft:sea_lantern
setblock 429 204 522 minecraft:sea_lantern
fill 429 204 540 429 204 541 minecraft:sea_lantern
fill 430 204 541 430 204 542 minecraft:sea_lantern
setblock 431 204 543 minecraft:sea_lantern
setblock 432 204 544 minecraft:sea_lantern
fill 433 204 545 434 204 545 minecraft:sea_lantern
fill 434 204 546 435 204 546 minecraft:sea_lantern
fill 436 204 547 437 204 547 minecraft:sea_lantern
fill 438 204 548 442 204 548 minecraft:sea_lantern
fill 443 204 549 445 204 549 minecraft:sea_lantern
fill 446 204 548 450 204 548 minecraft:sea_lantern
fill 451 204 547 452 204 547 minecraft:sea_lantern
setblock 451 204 552 minecraft:white_concrete
fill 453 204 546 454 204 546 minecraft:sea_lantern
fill 454 204 545 455 204 545 minecraft:sea_lantern
setblock 456 204 544 minecraft:sea_lantern
setblock 457 204 543 minecraft:sea_lantern
fill 458 204 541 458 204 542 minecraft:sea_lantern
fill 459 204 540 459 204 541 minecraft:sea_lantern
fill 460 204 538 460 204 539 minecraft:sea_lantern
setblock 461 204 537 minecraft:sea_lantern
fill 463 204 510 463 220 510 minecraft:blue_concrete
fill 427 205 535 427 218 537 minecraft:waxed_copper_block
fill 438 205 510 438 224 510 minecraft:blue_concrete
setblock 439 205 510 minecraft:light_blue_stained_glass
fill 451 205 552 451 224 552 minecraft:blue_concrete
setblock 465 205 513 minecraft:white_concrete
setblock 465 205 518 minecraft:sea_lantern
setblock 423 206 514 minecraft:light_blue_stained_glass
setblock 429 206 510 minecraft:white_concrete
setblock 437 206 552 minecraft:sea_lantern
fill 439 206 510 439 224 510 minecraft:blue_concrete
fill 454 206 510 454 224 510 minecraft:blue_concrete
setblock 455 206 510 minecraft:sea_lantern
fill 465 206 513 465 221 513 minecraft:blue_concrete
fill 465 206 518 465 211 518 minecraft:blue_concrete
fill 423 207 514 423 224 514 minecraft:blue_concrete
fill 423 207 518 423 209 518 minecraft:gold_block
fill 423 207 534 423 209 534 minecraft:gold_block
fill 423 207 550 423 209 550 minecraft:gold_block
fill 427 207 510 427 209 510 minecraft:gold_block
fill 429 207 510 429 224 510 minecraft:blue_concrete
fill 437 207 552 437 209 552 minecraft:gold_block
fill 443 207 510 443 209 510 minecraft:gold_block
fill 453 207 552 453 209 552 minecraft:gold_block
setblock 454 207 552 minecraft:sea_lantern
fill 455 207 510 455 224 510 minecraft:blue_concrete
fill 459 207 510 459 209 510 minecraft:gold_block
setblock 460 207 552 minecraft:white_concrete
fill 461 207 552 461 224 552 minecraft:blue_concrete
setblock 462 207 510 minecraft:light_blue_stained_glass
fill 465 207 520 465 209 520 minecraft:gold_block
setblock 465 207 531 minecraft:white_concrete
fill 465 207 536 465 209 536 minecraft:gold_block
fill 453 208 511 453 209 512 minecraft:waxed_copper_block
fill 454 208 552 454 224 552 minecraft:blue_concrete
fill 460 208 552 460 224 552 minecraft:blue_concrete
fill 462 208 510 462 220 510 minecraft:blue_concrete
fill 465 208 531 465 224 531 minecraft:blue_concrete
setblock 423 209 545 minecraft:white_concrete
setblock 423 209 547 minecraft:white_concrete
fill 425 209 535 425 209 537 minecraft:waxed_cut_copper
fill 426 209 534 428 209 534 minecraft:waxed_cut_copper
fill 426 209 538 428 209 538 minecraft:waxed_cut_copper
fill 429 209 535 429 209 537 minecraft:waxed_cut_copper
setblock 434 209 510 minecraft:sea_lantern
setblock 452 209 513 minecraft:waxed_cut_copper
setblock 452 209 515 minecraft:waxed_cut_copper
setblock 453 209 516 minecraft:sea_lantern
setblock 454 209 513 minecraft:waxed_cut_copper
setblock 454 209 515 minecraft:waxed_cut_copper
fill 423 210 518 423 215 518 minecraft:blue_concrete
fill 423 210 534 423 215 534 minecraft:blue_concrete
fill 423 210 545 423 224 545 minecraft:blue_concrete
fill 423 210 547 423 224 547 minecraft:blue_concrete
fill 423 210 550 423 215 550 minecraft:blue_concrete
setblock 425 210 552 minecraft:white_concrete
setblock 426 210 513 minecraft:light[level=14]
setblock 426 210 521 minecraft:light[level=14]
setblock 426 210 529 minecraft:light[level=14]
setblock 426 210 545 minecraft:light[level=14]
fill 427 210 510 427 215 510 minecraft:blue_concrete
fill 434 210 510 434 215 510 minecraft:blue_concrete
setblock 434 210 513 minecraft:light[level=14]
setblock 434 210 521 minecraft:light[level=14]
setblock 434 210 529 minecraft:light[level=14]
setblock 434 210 537 minecraft:light[level=14]
setblock 434 210 545 minecraft:light[level=14]
fill 437 210 552 437 215 552 minecraft:blue_concrete
setblock 442 210 513 minecraft:light[level=14]
setblock 442 210 521 minecraft:light[level=14]
setblock 442 210 529 minecraft:light[level=14]
setblock 442 210 537 minecraft:light[level=14]
setblock 442 210 545 minecraft:light[level=14]
setblock 443 210 510 minecraft:blue_concrete
setblock 450 210 513 minecraft:light[level=14]
setblock 450 210 521 minecraft:light[level=14]
setblock 450 210 529 minecraft:light[level=14]
setblock 450 210 537 minecraft:light[level=14]
setblock 450 210 545 minecraft:light[level=14]
fill 453 210 552 453 215 552 minecraft:blue_concrete
setblock 458 210 513 minecraft:light[level=14]
setblock 458 210 521 minecraft:light[level=14]
setblock 458 210 529 minecraft:light[level=14]
setblock 458 210 537 minecraft:light[level=14]
setblock 458 210 545 minecraft:light[level=14]
fill 459 210 510 459 215 510 minecraft:blue_concrete
fill 465 210 520 465 215 520 minecraft:blue_concrete
fill 465 210 536 465 212 536 minecraft:blue_concrete
fill 425 211 552 425 222 552 minecraft:blue_concrete
setblock 428 211 552 minecraft:white_concrete
setblock 434 211 552 minecraft:light_blue_stained_glass
setblock 443 211 510 minecraft:white_concrete
fill 428 212 552 428 224 552 minecraft:blue_concrete
fill 434 212 552 434 224 552 minecraft:blue_concrete
fill 443 212 510 443 215 510 minecraft:blue_concrete
setblock 465 212 518 minecraft:white_concrete
setblock 465 212 544 minecraft:sea_lantern
setblock 442 213 552 minecraft:light_blue_stained_glass
fill 443 213 552 443 224 552 minecraft:blue_concrete
fill 465 213 518 465 224 518 minecraft:blue_concrete
setblock 465 213 536 minecraft:white_concrete
fill 465 213 544 465 220 544 minecraft:blue_concrete
setblock 425 214 510 minecraft:sea_lantern
fill 438 214 552 438 222 552 minecraft:blue_concrete
setblock 439 214 552 minecraft:light_blue_stained_glass
fill 442 214 552 442 224 552 minecraft:blue_concrete
setblock 465 214 526 minecraft:white_concrete
fill 465 214 536 465 215 536 minecraft:blue_concrete
fill 425 215 510 425 224 510 minecraft:blue_concrete
fill 425 215 535 425 215 537 minecraft:waxed_cut_copper
fill 426 215 534 428 215 534 minecraft:waxed_cut_copper
fill 426 215 538 428 215 538 minecraft:waxed_cut_copper
fill 429 215 535 429 215 537 minecraft:waxed_cut_copper
fill 439 215 552 439 220 552 minecraft:blue_concrete
setblock 442 215 510 minecraft:white_concrete
setblock 452 215 513 minecraft:waxed_cut_copper
setblock 452 215 515 minecraft:waxed_cut_copper
setblock 454 215 513 minecraft:waxed_cut_copper
setblock 454 215 515 minecraft:waxed_cut_copper
setblock 459 215 552 minecraft:sea_lantern
fill 465 215 526 465 224 526 minecraft:blue_concrete
setblock 423 216 515 minecraft:light_blue_stained_glass
fill 423 216 518 423 218 518 minecraft:gold_block
setblock 423 216 522 minecraft:sea_lantern
fill 423 216 534 423 218 534 minecraft:gold_block
fill 423 216 550 423 218 550 minecraft:gold_block
fill 427 216 510 427 218 510 minecraft:gold_block
setblock 434 216 510 minecraft:white_concrete
fill 437 216 552 437 218 552 minecraft:gold_block
fill 442 216 510 442 224 510 minecraft:blue_concrete
fill 443 216 510 443 218 510 minecraft:gold_block
fill 453 216 552 453 218 552 minecraft:gold_block
fill 459 216 510 459 218 510 minecraft:gold_block
fill 459 216 552 459 217 552 minecraft:blue_concrete
fill 465 216 520 465 218 520 minecraft:gold_block
setblock 465 216 524 minecraft:sea_lantern
fill 465 216 536 465 218 536 minecraft:gold_block
fill 423 217 515 423 224 515 minecraft:blue_concrete
fill 423 217 522 423 222 522 minecraft:blue_concrete
fill 434 217 510 434 220 510 minecraft:blue_concrete
fill 449 217 510 451 221 510 minecraft:blue_concrete
setblock 449 217 552 minecraft:light_blue_stained_glass
setblock 452 217 510 minecraft:light_blue_stained_glass
fill 465 217 524 465 221 524 minecraft:blue_concrete
setblock 426 218 513 minecraft:light[level=14]
setblock 426 218 521 minecraft:light[level=14]
setblock 426 218 529 minecraft:light[level=14]
setblock 426 218 545 minecraft:light[level=14]
setblock 434 218 513 minecraft:light[level=14]
setblock 434 218 521 minecraft:light[level=14]
setblock 434 218 529 minecraft:light[level=14]
setblock 434 218 537 minecraft:light[level=14]
setblock 434 218 545 minecraft:light[level=14]
setblock 442 218 513 minecraft:light[level=14]
setblock 442 218 521 minecraft:light[level=14]
setblock 442 218 529 minecraft:light[level=14]
setblock 442 218 537 minecraft:light[level=14]
setblock 442 218 545 minecraft:light[level=14]
fill 449 218 552 449 224 552 minecraft:blue_concrete
setblock 450 218 513 minecraft:light[level=14]
setblock 450 218 521 minecraft:light[level=14]
setblock 450 218 529 minecraft:light[level=14]
setblock 450 218 537 minecraft:light[level=14]
setblock 450 218 545 minecraft:light[level=14]
fill 452 218 510 452 224 510 minecraft:blue_concrete
setblock 452 218 552 minecraft:white_concrete
setblock 458 218 513 minecraft:light[level=14]
setblock 458 218 521 minecraft:light[level=14]
setblock 458 218 529 minecraft:light[level=14]
setblock 458 218 537 minecraft:light[level=14]
setblock 458 218 545 minecraft:light[level=14]
setblock 459 218 552 minecraft:white_concrete
setblock 465 218 547 minecraft:white_concrete
setblock 465 218 550 minecraft:sea_lantern
fill 423 219 518 423 224 518 minecraft:blue_concrete
fill 423 219 534 423 221 534 minecraft:blue_concrete
fill 423 219 550 423 224 550 minecraft:blue_concrete
fill 427 219 510 427 221 510 minecraft:blue_concrete
setblock 435 219 552 minecraft:light_blue_stained_glass
fill 437 219 552 437 224 552 minecraft:blue_concrete
fill 443 219 510 443 224 510 minecraft:blue_concrete
fill 452 219 552 453 224 552 minecraft:blue_concrete
fill 459 219 510 459 224 510 minecraft:blue_concrete
fill 459 219 552 459 222 552 minecraft:blue_concrete
fill 465 219 520 465 221 520 minecraft:blue_concrete
fill 465 219 536 465 223 536 minecraft:blue_concrete
fill 465 219 547 465 221 547 minecraft:blue_concrete
fill 465 219 550 465 224 550 minecraft:blue_concrete
setblock 426 220 510 minecraft:sea_lantern
fill 435 220 552 435 224 552 minecraft:blue_concrete
fill 426 221 510 426 224 510 minecraft:blue_concrete
fill 429 221 552 431 221 552 minecraft:black_concrete
fill 432 221 510 432 222 510 minecraft:black_concrete
setblock 433 221 510 minecraft:light_blue_stained_glass
setblock 434 221 510 minecraft:sea_lantern
setblock 436 221 510 minecraft:black_concrete
setblock 439 221 552 minecraft:black_concrete
fill 444 221 510 445 221 510 minecraft:black_concrete
fill 445 221 552 446 221 552 minecraft:black_concrete
fill 446 221 510 446 224 510 minecraft:blue_concrete
setblock 456 221 510 minecraft:black_concrete
fill 462 221 510 463 221 510 minecraft:black_concrete
setblock 465 221 530 minecraft:black_concrete
setblock 465 221 533 minecraft:black_concrete
setblock 465 221 544 minecraft:black_concrete
setblock 423 222 511 minecraft:light_blue_stained_glass
setblock 423 222 513 minecraft:black_concrete
fill 423 222 516 423 224 516 minecraft:blue_concrete
setblock 423 222 517 minecraft:black_concrete
fill 423 222 521 423 223 521 minecraft:black_concrete
setblock 423 222 524 minecraft:black_concrete
fill 423 222 526 423 222 527 minecraft:black_concrete
setblock 423 222 531 minecraft:black_concrete
fill 423 222 532 423 224 532 minecraft:blue_concrete
setblock 423 222 534 minecraft:black_concrete
setblock 423 222 548 minecraft:black_concrete
setblock 423 222 551 minecraft:black_concrete
setblock 427 222 510 minecraft:black_concrete
fill 429 222 552 429 224 552 minecraft:blue_concrete
setblock 430 222 552 minecraft:black_concrete
fill 431 222 552 431 224 552 minecraft:blue_concrete
fill 433 222 510 434 224 510 minecraft:blue_concrete
setblock 433 222 552 minecraft:black_concrete
fill 436 222 510 436 224 510 minecraft:blue_concrete
setblock 437 222 510 minecraft:black_concrete
fill 439 222 552 439 224 552 minecraft:blue_concrete
fill 444 222 510 445 224 510 minecraft:blue_concrete
fill 445 222 552 446 224 552 minecraft:blue_concrete
fill 448 222 510 448 223 510 minecraft:black_concrete
fill 449 222 510 449 224 510 minecraft:blue_concrete
setblock 450 222 510 minecraft:black_concrete
setblock 451 222 510 minecraft:blue_concrete
fill 456 222 510 456 224 510 minecraft:blue_concrete
setblock 457 222 510 minecraft:black_concrete
setblock 460 222 510 minecraft:black_concrete
fill 462 222 510 463 224 510 minecraft:blue_concrete
setblock 463 222 552 minecraft:black_concrete
setblock 464 222 552 minecraft:white_concrete
setblock 465 222 513 minecraft:black_concrete
setblock 465 222 520 minecraft:black_concrete
setblock 465 222 524 minecraft:light_blue_stained_glass
fill 465 222 530 465 224 530 minecraft:blue_concrete
fill 465 222 533 465 225 533 minecraft:blue_concrete
setblock 465 222 542 minecraft:black_concrete
fill 465 222 544 465 224 544 minecraft:blue_concrete
setblock 465 222 547 minecraft:black_concrete
setblock 423 223 510 minecraft:black_concrete
fill 423 223 511 423 224 511 minecraft:blue_concrete
fill 423 223 513 423 224 513 minecraft:blue_concrete
fill 423 223 517 423 224 517 minecraft:blue_concrete
setblock 423 223 522 minecraft:black_concrete
fill 423 223 524 423 224 524 minecraft:blue_concrete
fill 423 223 526 423 224 527 minecraft:blue_concrete
fill 423 223 531 423 224 531 minecraft:blue_concrete
fill 423 223 534 423 224 534 minecraft:blue_concrete
setblock 423 223 537 minecraft:black_concrete
fill 423 223 543 423 223 544 minecraft:black_concrete
fill 423 223 548 423 224 548 minecraft:blue_concrete
setblock 423 223 549 minecraft:black_concrete
fill 423 223 551 423 224 551 minecraft:blue_concrete
setblock 423 223 552 minecraft:black_concrete
setblock 425 223 552 minecraft:black_concrete
fill 427 223 510 427 224 510 minecraft:blue_concrete
setblock 430 223 510 minecraft:black_concrete
fill 430 223 552 430 225 552 minecraft:blue_concrete
fill 431 223 510 432 224 510 minecraft:blue_concrete
setblock 432 223 552 minecraft:black_concrete
fill 433 223 552 433 225 552 minecraft:blue_concrete
setblock 435 223 510 minecraft:black_concrete
fill 437 223 510 437 224 510 minecraft:blue_concrete
setblock 437 223 533 minecraft:waxed_copper_block
setblock 438 223 552 minecraft:black_concrete
setblock 444 223 526 minecraft:waxed_copper_block
setblock 444 223 540 minecraft:waxed_copper_block
fill 447 223 552 447 224 552 minecraft:blue_concrete
setblock 448 223 552 minecraft:white_concrete
fill 450 223 510 450 225 510 minecraft:blue_concrete
setblock 451 223 510 minecraft:black_concrete
setblock 451 223 533 minecraft:waxed_copper_block
fill 457 223 510 457 224 510 minecraft:blue_concrete
setblock 458 223 510 minecraft:black_concrete
setblock 459 223 552 minecraft:black_concrete
fill 460 223 510 460 224 510 minecraft:blue_concrete
fill 463 223 552 464 224 552 minecraft:blue_concrete
fill 465 223 513 465 224 513 minecraft:blue_concrete
fill 465 223 520 465 224 520 minecraft:blue_concrete
fill 465 223 524 465 225 524 minecraft:blue_concrete
fill 465 223 542 465 224 542 minecraft:blue_concrete
setblock 465 223 545 minecraft:black_concrete
setblock 465 223 546 minecraft:white_concrete
fill 465 223 547 465 225 547 minecraft:blue_concrete
setblock 465 223 549 minecraft:black_concrete
setblock 423 224 510 minecraft:blue_concrete
fill 423 224 521 423 224 522 minecraft:blue_concrete
setblock 423 224 537 minecraft:blue_concrete
fill 423 224 543 423 224 544 minecraft:blue_concrete
setblock 423 224 549 minecraft:blue_concrete
setblock 423 224 552 minecraft:blue_concrete
fill 425 224 552 425 225 552 minecraft:blue_concrete
setblock 430 224 510 minecraft:blue_concrete
setblock 432 224 552 minecraft:blue_concrete
fill 435 224 510 435 225 510 minecraft:blue_concrete
fill 436 224 530 436 226 536 minecraft:waxed_copper_block
fill 437 224 528 437 226 532 minecraft:waxed_copper_block
fill 437 224 533 441 224 533 minecraft:light_blue_stained_glass
fill 437 224 534 437 226 538 minecraft:waxed_copper_block
fill 438 224 527 438 226 529 minecraft:waxed_copper_block
fill 438 224 530 442 224 532 minecraft:light_blue_stained_glass
fill 438 224 534 442 224 536 minecraft:light_blue_stained_glass
fill 438 224 537 438 226 539 minecraft:waxed_copper_block
setblock 438 224 552 minecraft:blue_concrete
fill 439 224 526 439 226 528 minecraft:waxed_copper_block
fill 439 224 529 449 225 529 minecraft:light_blue_stained_glass
fill 439 224 537 449 225 537 minecraft:light_blue_stained_glass
fill 439 224 538 439 226 540 minecraft:waxed_copper_block
fill 440 224 526 440 226 527 minecraft:waxed_copper_block
fill 440 224 528 448 225 528 minecraft:light_blue_stained_glass
fill 440 224 538 448 225 538 minecraft:light_blue_stained_glass
fill 440 224 539 440 226 540 minecraft:waxed_copper_block
fill 441 224 525 443 226 526 minecraft:waxed_copper_block
fill 441 224 527 447 225 527 minecraft:light_blue_stained_glass
fill 441 224 539 447 225 539 minecraft:light_blue_stained_glass
fill 441 224 540 443 226 541 minecraft:waxed_copper_block
fill 443 224 530 443 224 531 minecraft:light_blue_stained_glass
fill 443 224 535 443 224 536 minecraft:light_blue_stained_glass
fill 444 224 525 447 226 525 minecraft:waxed_copper_block
fill 444 224 526 444 225 526 minecraft:light_blue_stained_glass
fill 444 224 530 450 224 530 minecraft:light_blue_stained_glass
fill 444 224 536 450 224 536 minecraft:light_blue_stained_glass
fill 444 224 540 444 225 540 minecraft:light_blue_stained_glass
fill 444 224 541 447 226 541 minecraft:waxed_copper_block
fill 445 224 526 449 226 526 minecraft:waxed_copper_block
fill 445 224 531 450 224 531 minecraft:light_blue_stained_glass
fill 445 224 535 450 224 535 minecraft:light_blue_stained_glass
fill 445 224 540 449 226 540 minecraft:waxed_copper_block
fill 446 224 532 450 224 532 minecraft:light_blue_stained_glass
fill 446 224 534 450 224 534 minecraft:light_blue_stained_glass
fill 447 224 533 451 224 533 minecraft:light_blue_stained_glass
setblock 448 224 510 minecraft:blue_concrete
fill 448 224 527 450 226 527 minecraft:waxed_copper_block
fill 448 224 539 450 226 539 minecraft:waxed_copper_block
setblock 448 224 552 minecraft:blue_concrete
fill 449 224 528 451 226 528 minecraft:waxed_copper_block
fill 449 224 538 451 226 538 minecraft:waxed_copper_block
fill 450 224 529 451 226 529 minecraft:waxed_copper_block
fill 450 224 537 451 226 537 minecraft:waxed_copper_block
setblock 451 224 510 minecraft:blue_concrete
fill 451 224 530 452 226 532 minecraft:waxed_copper_block
fill 451 224 534 452 226 536 minecraft:waxed_copper_block
fill 452 224 533 452 226 533 minecraft:waxed_copper_block
setblock 458 224 510 minecraft:blue_concrete
setblock 459 224 552 minecraft:blue_concrete
setblock 465 224 536 minecraft:sea_lantern
fill 465 224 545 465 224 546 minecraft:blue_concrete
setblock 465 224 549 minecraft:blue_concrete
fill 423 225 510 434 225 511 minecraft:black_concrete
fill 423 225 513 464 225 514 minecraft:black_concrete
setblock 423 225 515 minecraft:light_blue_stained_glass
fill 423 225 516 465 225 519 minecraft:black_concrete
fill 423 225 521 465 225 522 minecraft:black_concrete
fill 423 225 524 436 225 528 minecraft:black_concrete
fill 423 225 530 435 225 532 minecraft:black_concrete
fill 423 225 534 435 225 535 minecraft:black_concrete
fill 423 225 537 435 225 538 minecraft:black_concrete
setblock 423 225 539 minecraft:blue_concrete
fill 423 225 540 424 225 552 minecraft:black_concrete
fill 424 225 512 464 225 512 minecraft:black_concrete
fill 424 225 515 465 225 515 minecraft:black_concrete
fill 424 225 520 465 225 520 minecraft:black_concrete
fill 424 225 523 465 225 523 minecraft:black_concrete
fill 424 225 529 435 225 529 minecraft:black_concrete
fill 424 225 533 434 225 533 minecraft:black_concrete
fill 424 225 536 435 225 536 minecraft:black_concrete
fill 424 225 539 437 225 539 minecraft:black_concrete
fill 425 225 540 438 225 551 minecraft:black_concrete
fill 426 225 552 429 234 552 minecraft:black_concrete
fill 431 225 552 432 226 552 minecraft:black_concrete
fill 434 225 552 436 232 552 minecraft:black_concrete
fill 435 225 511 465 225 511 minecraft:black_concrete
setblock 435 225 533 minecraft:waxed_copper_block
fill 436 225 510 437 283 510 minecraft:black_concrete
setblock 436 225 529 minecraft:waxed_copper_block
setblock 436 225 537 minecraft:waxed_copper_block
setblock 436 225 538 minecraft:black_concrete
fill 437 225 524 437 225 527 minecraft:black_concrete
fill 437 225 533 440 225 533 minecraft:light_blue_stained_glass
setblock 437 225 552 minecraft:sea_lantern
setblock 438 225 510 minecraft:white_concrete
fill 438 225 524 438 225 526 minecraft:black_concrete
fill 438 225 530 440 225 532 minecraft:light_blue_stained_glass
fill 438 225 534 440 225 536 minecraft:light_blue_stained_glass
fill 438 225 552 452 225 552 minecraft:black_concrete
fill 439 225 510 449 226 510 minecraft:black_concrete
fill 439 225 524 439 225 525 minecraft:black_concrete
fill 439 225 541 439 225 551 minecraft:black_concrete
fill 440 225 524 443 225 524 minecraft:black_concrete
setblock 440 225 525 minecraft:waxed_copper_block
setblock 440 225 541 minecraft:waxed_copper_block
fill 440 225 542 443 225 551 minecraft:black_concrete
fill 441 225 530 441 225 531 minecraft:light_blue_stained_glass
fill 441 225 532 441 225 534 minecraft:sea_lantern
fill 441 225 535 441 225 536 minecraft:light_blue_stained_glass
setblock 442 225 530 minecraft:light_blue_stained_glass
fill 442 225 531 442 225 532 minecraft:sea_lantern
fill 442 225 534 442 225 535 minecraft:sea_lantern
setblock 442 225 536 minecraft:light_blue_stained_glass
fill 443 225 530 443 225 531 minecraft:sea_lantern
fill 443 225 535 443 225 536 minecraft:sea_lantern
setblock 444 225 524 minecraft:waxed_copper_block
fill 444 225 530 445 225 530 minecraft:sea_lantern
fill 444 225 536 445 225 536 minecraft:sea_lantern
setblock 444 225 542 minecraft:waxed_copper_block
fill 444 225 543 464 225 551 minecraft:black_concrete
fill 445 225 524 464 225 524 minecraft:black_concrete
fill 445 225 531 446 225 531 minecraft:sea_lantern
fill 445 225 535 446 225 535 minecraft:sea_lantern
fill 445 225 542 465 225 542 minecraft:black_concrete
fill 446 225 530 450 225 530 minecraft:light_blue_stained_glass
fill 446 225 532 447 225 532 minecraft:sea_lantern
fill 446 225 534 447 225 534 minecraft:sea_lantern
fill 446 225 536 450 225 536 minecraft:light_blue_stained_glass
fill 447 225 531 450 225 531 minecraft:light_blue_stained_glass
setblock 447 225 533 minecraft:sea_lantern
fill 447 225 535 450 225 535 minecraft:light_blue_stained_glass
setblock 448 225 525 minecraft:waxed_copper_block
fill 448 225 532 450 225 534 minecraft:light_blue_stained_glass
setblock 448 225 541 minecraft:waxed_copper_block
fill 449 225 525 465 225 525 minecraft:black_concrete
fill 449 225 541 465 225 541 minecraft:black_concrete
fill 450 225 526 465 225 526 minecraft:black_concrete
fill 450 225 540 465 225 540 minecraft:black_concrete
fill 451 225 510 461 225 510 minecraft:black_concrete
fill 451 225 527 465 225 527 minecraft:black_concrete
setblock 451 225 533 minecraft:light_blue_stained_glass
fill 451 225 539 465 225 539 minecraft:black_concrete
fill 452 225 528 464 225 528 minecraft:black_concrete
setblock 452 225 529 minecraft:waxed_copper_block
setblock 452 225 537 minecraft:waxed_copper_block
fill 452 225 538 465 225 538 minecraft:black_concrete
fill 453 225 529 465 225 532 minecraft:black_concrete
setblock 453 225 533 minecraft:waxed_copper_block
fill 453 225 534 464 225 537 minecraft:black_concrete
fill 453 225 552 453 226 552 minecraft:blue_concrete
fill 454 225 533 464 225 533 minecraft:black_concrete
fill 454 225 552 462 225 552 minecraft:black_concrete
setblock 462 225 510 minecraft:blue_concrete
fill 463 225 510 465 226 510 minecraft:black_concrete
setblock 463 225 552 minecraft:blue_concrete
fill 464 225 552 465 272 552 minecraft:black_concrete
fill 465 225 513 465 298 513 minecraft:black_concrete
fill 465 225 534 465 226 536 minecraft:black_concrete
fill 465 225 543 465 225 546 minecraft:black_concrete
fill 465 225 548 465 226 551 minecraft:black_concrete
setblock 423 226 510 minecraft:blue_concrete
setblock 423 226 511 minecraft:light_blue_stained_glass
fill 423 226 512 423 227 515 minecraft:black_concrete
setblock 423 226 516 minecraft:blue_concrete
fill 423 226 517 423 233 519 minecraft:black_concrete
fill 423 226 521 423 227 521 minecraft:blue_concrete
fill 423 226 522 423 226 538 minecraft:black_concrete
setblock 423 226 539 minecraft:white_concrete
fill 423 226 540 423 226 541 minecraft:blue_concrete
fill 423 226 542 423 226 545 minecraft:black_concrete
setblock 423 226 546 minecraft:blue_concrete
fill 423 226 547 423 284 549 minecraft:black_concrete
setblock 423 226 550 minecraft:blue_concrete
fill 423 226 551 423 226 552 minecraft:black_concrete
fill 424 226 510 430 231 510 minecraft:black_concrete
fill 424 226 552 425 235 552 minecraft:black_concrete
setblock 426 226 513 minecraft:light[level=14]
setblock 426 226 521 minecraft:light[level=14]
setblock 426 226 529 minecraft:light[level=14]
setblock 426 226 537 minecraft:light[level=14]
setblock 426 226 545 minecraft:light[level=14]
fill 430 226 552 430 259 552 minecraft:black_concrete
setblock 431 226 510 minecraft:blue_concrete
fill 432 226 510 435 229 510 minecraft:black_concrete
fill 433 226 552 433 301 552 minecraft:black_concrete
setblock 434 226 513 minecraft:light[level=14]
setblock 434 226 521 minecraft:light[level=14]
setblock 434 226 529 minecraft:light[level=14]
setblock 434 226 537 minecraft:light[level=14]
setblock 434 226 545 minecraft:light[level=14]
fill 437 226 533 438 226 533 minecraft:waxed_copper_block
fill 437 226 552 448 228 552 minecraft:black_concrete
setblock 438 226 510 minecraft:blue_concrete
fill 438 226 530 438 226 532 minecraft:waxed_copper_block
fill 438 226 534 438 226 536 minecraft:waxed_copper_block
fill 439 226 529 439 226 531 minecraft:waxed_copper_block
fill 439 226 535 439 226 537 minecraft:waxed_copper_block
fill 440 226 528 440 226 529 minecraft:waxed_copper_block
fill 440 226 537 440 226 538 minecraft:waxed_copper_block
fill 441 226 527 442 226 528 minecraft:waxed_copper_block
fill 441 226 538 442 226 539 minecraft:waxed_copper_block
setblock 442 226 513 minecraft:light[level=14]
setblock 442 226 521 minecraft:light[level=14]
setblock 442 226 529 minecraft:light[level=14]
setblock 442 226 537 minecraft:light[level=14]
setblock 442 226 545 minecraft:light[level=14]
fill 443 226 527 447 226 527 minecraft:waxed_copper_block
fill 443 226 539 447 226 539 minecraft:waxed_copper_block
fill 444 226 526 444 227 526 minecraft:waxed_copper_block
fill 444 226 540 444 227 540 minecraft:waxed_copper_block
fill 446 226 528 448 226 528 minecraft:waxed_copper_block
fill 446 226 538 448 226 538 minecraft:waxed_copper_block
fill 448 226 529 449 226 529 minecraft:waxed_copper_block
fill 448 226 537 449 226 537 minecraft:waxed_copper_block
fill 449 226 530 450 226 531 minecraft:waxed_copper_block
fill 449 226 535 450 226 536 minecraft:waxed_copper_block
setblock 449 226 552 minecraft:blue_concrete
fill 450 226 510 452 258 510 minecraft:black_concrete
setblock 450 226 513 minecraft:light[level=14]
setblock 450 226 521 minecraft:light[level=14]
fill 450 226 532 450 226 534 minecraft:waxed_copper_block
setblock 450 226 545 minecraft:light[level=14]
fill 450 226 552 452 226 552 minecraft:black_concrete
fill 451 226 533 451 227 533 minecraft:waxed_copper_block
setblock 453 226 510 minecraft:blue_concrete
fill 454 226 510 462 226 510 minecraft:black_concrete
fill 454 226 552 457 290 552 minecraft:black_concrete
setblock 458 226 513 minecraft:light[level=14]
setblock 458 226 521 minecraft:light[level=14]
setblock 458 226 529 minecraft:light[level=14]
setblock 458 226 537 minecraft:light[level=14]
setblock 458 226 545 minecraft:light[level=14]
setblock 458 226 552 minecraft:blue_concrete
fill 459 226 552 463 226 552 minecraft:black_concrete
fill 465 226 511 465 226 512 minecraft:black_concrete
fill 465 226 514 465 226 528 minecraft:black_concrete
fill 465 226 529 465 226 530 minecraft:blue_concrete
fill 465 226 531 465 254 533 minecraft:black_concrete
fill 465 226 537 465 228 543 minecraft:black_concrete
setblock 465 226 544 minecraft:blue_concrete
fill 465 226 545 465 226 547 minecraft:black_concrete
fill 423 227 510 423 269 511 minecraft:black_concrete
fill 423 227 516 423 238 516 minecraft:black_concrete
fill 423 227 520 423 229 520 minecraft:black_concrete
fill 423 227 522 423 256 524 minecraft:black_concrete
setblock 423 227 525 minecraft:blue_concrete
fill 423 227 526 423 239 526 minecraft:black_concrete
setblock 423 227 527 minecraft:blue_concrete
fill 423 227 528 423 230 535 minecraft:black_concrete
setblock 423 227 536 minecraft:white_concrete
fill 423 227 537 423 296 537 minecraft:black_concrete
setblock 423 227 538 minecraft:blue_concrete
fill 423 227 539 423 233 543 minecraft:black_concrete
setblock 423 227 544 minecraft:blue_concrete
fill 423 227 545 423 231 546 minecraft:black_concrete
fill 423 227 550 423 233 550 minecraft:black_concrete
setblock 423 227 551 minecraft:sea_lantern
fill 423 227 552 423 307 552 minecraft:black_concrete
fill 431 227 510 431 278 510 minecraft:black_concrete
fill 431 227 552 431 291 552 minecraft:black_concrete
setblock 432 227 552 minecraft:blue_concrete
setblock 437 227 533 minecraft:waxed_copper_block
fill 438 227 510 441 234 510 minecraft:black_concrete
setblock 442 227 510 minecraft:blue_concrete
fill 443 227 510 443 233 510 minecraft:black_concrete
fill 444 227 510 445 227 510 minecraft:blue_concrete
setblock 446 227 510 minecraft:white_concrete
fill 447 227 510 449 232 510 minecraft:black_concrete
fill 449 227 552 450 236 552 minecraft:black_concrete
setblock 451 227 552 minecraft:light_blue_stained_glass
fill 452 227 552 453 233 552 minecraft:black_concrete
fill 453 227 510 455 244 510 minecraft:black_concrete
setblock 456 227 510 minecraft:blue_concrete
fill 457 227 510 463 233 510 minecraft:black_concrete
fill 458 227 552 461 231 552 minecraft:black_concrete
setblock 462 227 552 minecraft:blue_concrete
fill 463 227 552 463 232 552 minecraft:black_concrete
setblock 464 227 510 minecraft:blue_concrete
fill 465 227 510 465 252 511 minecraft:black_concrete
setblock 465 227 512 minecraft:light_blue_stained_glass
fill 465 227 514 465 233 522 minecraft:black_concrete
setblock 465 227 523 minecraft:white_concrete
fill 465 227 524 465 237 530 minecraft:black_concrete
fill 465 227 534 465 235 535 minecraft:black_concrete
setblock 465 227 536 minecraft:blue_concrete
fill 465 227 544 465 231 546 minecraft:black_concrete
fill 465 227 547 465 227 549 minecraft:blue_concrete
fill 465 227 550 465 252 551 minecraft:black_concrete
fill 423 228 512 423 242 513 minecraft:black_concrete
setblock 423 228 514 minecraft:white_concrete
fill 423 228 515 423 307 515 minecraft:black_concrete
fill 423 228 521 423 307 521 minecraft:black_concrete
fill 423 228 525 423 260 525 minecraft:black_concrete
fill 423 228 527 423 259 527 minecraft:black_concrete
fill 423 228 536 423 255 536 minecraft:black_concrete
fill 423 228 538 423 307 538 minecraft:black_concrete
fill 423 228 544 423 252 544 minecraft:black_concrete
fill 423 228 551 423 271 551 minecraft:black_concrete
fill 432 228 552 432 232 552 minecraft:black_concrete
fill 442 228 510 442 239 510 minecraft:black_concrete
fill 444 228 510 446 262 510 minecraft:black_concrete
fill 451 228 552 451 235 552 minecraft:black_concrete
fill 456 228 510 456 307 510 minecraft:black_concrete
fill 462 228 552 462 307 552 minecraft:black_concrete
fill 464 228 510 464 307 510 minecraft:black_concrete
setblock 465 228 512 minecraft:sea_lantern
fill 465 228 523 465 307 523 minecraft:black_concrete
fill 465 228 536 465 233 536 minecraft:black_concrete
fill 465 228 547 465 235 549 minecraft:black_concrete
fill 423 229 514 423 245 514 minecraft:black_concrete
fill 437 229 552 439 233 552 minecraft:black_concrete
setblock 440 229 552 minecraft:white_concrete
fill 441 229 552 448 240 552 minecraft:black_concrete
fill 465 229 512 465 307 512 minecraft:black_concrete
fill 465 229 537 465 238 538 minecraft:black_concrete
schedule function dropper:buildpart/129_2 1t
