setblock 416 193 280 minecraft:red_terracotta
fill 416 193 292 416 193 295 minecraft:red_terracotta
setblock 416 193 296 minecraft:stripped_oak_log
fill 416 193 297 416 196 297 minecraft:red_terracotta
setblock 416 193 300 minecraft:red_terracotta
setblock 416 193 301 minecraft:stripped_oak_log
fill 416 193 302 416 193 305 minecraft:red_terracotta
setblock 416 193 306 minecraft:stripped_oak_log
fill 416 193 307 416 196 307 minecraft:red_terracotta
setblock 416 193 311 minecraft:stripped_oak_log
fill 416 193 312 416 196 312 minecraft:red_terracotta
setblock 416 193 316 minecraft:stripped_oak_log
fill 417 193 276 417 196 276 minecraft:red_terracotta
setblock 417 193 280 minecraft:stripped_oak_log
fill 417 193 281 417 196 281 minecraft:red_terracotta
fill 417 193 283 417 194 283 minecraft:red_terracotta
fill 417 193 287 417 195 287 minecraft:red_terracotta
setblock 417 193 290 minecraft:stripped_oak_log
fill 417 193 291 417 196 291 minecraft:red_terracotta
setblock 417 193 295 minecraft:stripped_oak_log
fill 417 193 296 417 196 296 minecraft:red_terracotta
setblock 417 193 300 minecraft:stripped_oak_log
fill 417 193 301 417 196 301 minecraft:red_terracotta
setblock 417 193 305 minecraft:stripped_oak_log
fill 417 193 306 417 196 306 minecraft:red_terracotta
setblock 417 193 310 minecraft:stripped_oak_log
fill 417 193 311 417 196 311 minecraft:red_terracotta
setblock 417 193 315 minecraft:stripped_oak_log
fill 417 193 316 417 196 316 minecraft:red_terracotta
setblock 377 194 279 minecraft:stripped_oak_log
fill 377 194 280 378 196 280 minecraft:red_terracotta
setblock 377 194 283 minecraft:red_terracotta
setblock 377 194 284 minecraft:stripped_oak_log
fill 377 194 285 377 197 285 minecraft:red_terracotta
setblock 377 194 289 minecraft:stripped_oak_log
fill 377 194 290 377 194 293 minecraft:red_terracotta
setblock 377 194 294 minecraft:stripped_oak_log
fill 377 194 295 377 197 295 minecraft:red_terracotta
setblock 377 194 299 minecraft:stripped_oak_log
fill 377 194 300 377 197 300 minecraft:red_terracotta
setblock 377 194 304 minecraft:stripped_oak_log
fill 377 194 305 377 197 305 minecraft:red_terracotta
setblock 377 194 309 minecraft:stripped_oak_log
fill 377 194 310 377 197 310 minecraft:red_terracotta
setblock 377 194 314 minecraft:stripped_oak_log
fill 377 194 315 377 197 315 minecraft:red_terracotta
setblock 378 194 277 minecraft:red_terracotta
setblock 378 194 278 minecraft:stripped_oak_log
fill 378 194 279 378 197 279 minecraft:red_terracotta
setblock 378 194 288 minecraft:stripped_oak_log
fill 378 194 289 378 196 289 minecraft:red_terracotta
setblock 378 194 293 minecraft:stripped_oak_log
fill 378 194 294 378 197 294 minecraft:red_terracotta
setblock 378 194 298 minecraft:stripped_oak_log
fill 378 194 299 378 197 299 minecraft:red_terracotta
setblock 378 194 303 minecraft:stripped_oak_log
fill 378 194 304 378 197 304 minecraft:red_terracotta
setblock 378 194 308 minecraft:stripped_oak_log
fill 378 194 309 378 197 309 minecraft:red_terracotta
setblock 378 194 313 minecraft:stripped_oak_log
fill 378 194 314 378 197 314 minecraft:red_terracotta
setblock 379 194 277 minecraft:stripped_oak_log
setblock 379 194 292 minecraft:stripped_oak_log
fill 379 194 293 379 197 293 minecraft:red_terracotta
setblock 379 194 296 minecraft:red_terracotta
setblock 379 194 297 minecraft:stripped_oak_log
fill 379 194 298 379 197 298 minecraft:red_terracotta
setblock 379 194 302 minecraft:stripped_oak_log
fill 379 194 303 379 197 303 minecraft:red_terracotta
setblock 379 194 306 minecraft:red_terracotta
fill 379 194 307 379 208 307 minecraft:stripped_oak_log
fill 379 194 309 379 208 309 minecraft:stripped_oak_log
setblock 379 194 312 minecraft:stripped_oak_log
fill 379 194 313 379 195 313 minecraft:red_terracotta
setblock 380 194 276 minecraft:stripped_oak_log
fill 380 194 277 380 197 277 minecraft:red_terracotta
setblock 380 194 296 minecraft:stripped_oak_log
fill 380 194 297 380 197 297 minecraft:red_terracotta
setblock 380 194 300 minecraft:red_terracotta
setblock 380 194 301 minecraft:stripped_oak_log
setblock 380 194 316 minecraft:stripped_oak_log
fill 381 194 276 381 197 276 minecraft:red_terracotta
setblock 381 194 315 minecraft:stripped_oak_log
fill 381 194 316 381 197 316 minecraft:red_terracotta
fill 382 194 315 382 195 315 minecraft:red_terracotta
setblock 385 194 276 minecraft:stripped_oak_log
setblock 385 194 316 minecraft:stripped_oak_log
fill 386 194 276 389 194 276 minecraft:red_terracotta
setblock 386 194 316 minecraft:red_terracotta
setblock 390 194 276 minecraft:stripped_oak_log
setblock 390 194 316 minecraft:stripped_oak_log
fill 391 194 276 391 196 277 minecraft:red_terracotta
fill 391 194 316 391 197 316 minecraft:red_terracotta
fill 392 194 277 393 194 277 minecraft:red_terracotta
setblock 394 194 277 minecraft:stripped_oak_log
fill 394 194 278 394 197 278 minecraft:red_terracotta
setblock 395 194 276 minecraft:stripped_oak_log
fill 395 194 277 395 197 277 minecraft:red_terracotta
setblock 395 194 316 minecraft:stripped_oak_log
fill 396 194 276 396 197 276 minecraft:red_terracotta
setblock 396 194 315 minecraft:stripped_oak_log
fill 396 194 316 396 197 316 minecraft:red_terracotta
setblock 397 194 279 minecraft:stripped_oak_log
fill 397 194 315 397 197 315 minecraft:red_terracotta
setblock 398 194 277 minecraft:red_terracotta
setblock 398 194 278 minecraft:stripped_oak_log
fill 398 194 279 398 197 279 minecraft:red_terracotta
setblock 398 194 314 minecraft:red_terracotta
setblock 399 194 277 minecraft:stripped_oak_log
fill 399 194 278 402 194 278 minecraft:red_terracotta
setblock 400 194 276 minecraft:stripped_oak_log
fill 400 194 277 400 197 277 minecraft:red_terracotta
fill 400 194 279 400 195 279 minecraft:red_terracotta
setblock 400 194 316 minecraft:stripped_oak_log
fill 401 194 276 401 197 276 minecraft:red_terracotta
fill 401 194 279 401 200 279 minecraft:green_concrete
setblock 401 194 314 minecraft:red_terracotta
setblock 401 194 315 minecraft:stripped_oak_log
fill 401 194 316 401 197 316 minecraft:red_terracotta
fill 402 194 315 402 197 315 minecraft:red_terracotta
setblock 403 194 278 minecraft:stripped_oak_log
setblock 404 194 277 minecraft:stripped_oak_log
fill 404 194 278 404 197 278 minecraft:red_terracotta
setblock 405 194 276 minecraft:stripped_oak_log
fill 405 194 277 408 194 277 minecraft:red_terracotta
setblock 405 194 316 minecraft:stripped_oak_log
fill 406 194 276 409 194 276 minecraft:red_terracotta
setblock 406 194 315 minecraft:stripped_oak_log
fill 406 194 316 406 197 316 minecraft:red_terracotta
fill 407 194 315 407 196 315 minecraft:red_terracotta
setblock 409 194 277 minecraft:stripped_oak_log
setblock 410 194 276 minecraft:stripped_oak_log
fill 410 194 277 410 197 277 minecraft:red_terracotta
setblock 410 194 316 minecraft:stripped_oak_log
fill 411 194 276 411 197 276 minecraft:red_terracotta
setblock 411 194 315 minecraft:stripped_oak_log
fill 411 194 316 411 197 316 minecraft:red_terracotta
setblock 412 194 314 minecraft:stripped_oak_log
fill 412 194 315 412 197 315 minecraft:red_terracotta
fill 413 194 314 413 197 314 minecraft:red_terracotta
setblock 414 194 276 minecraft:red_terracotta
setblock 414 194 277 minecraft:stripped_oak_log
fill 414 194 278 415 196 278 minecraft:red_terracotta
setblock 415 194 276 minecraft:stripped_oak_log
fill 415 194 277 415 197 277 minecraft:red_terracotta
setblock 415 194 311 minecraft:stripped_oak_log
fill 415 194 312 415 197 312 minecraft:red_terracotta
setblock 415 194 316 minecraft:stripped_oak_log
fill 416 194 276 416 197 276 minecraft:red_terracotta
setblock 416 194 280 minecraft:stripped_oak_log
fill 416 194 292 416 194 294 minecraft:red_terracotta
setblock 416 194 295 minecraft:stripped_oak_log
fill 416 194 296 416 197 296 minecraft:red_terracotta
setblock 416 194 300 minecraft:stripped_oak_log
fill 416 194 301 416 194 304 minecraft:red_terracotta
setblock 416 194 305 minecraft:stripped_oak_log
fill 416 194 306 416 197 306 minecraft:red_terracotta
setblock 416 194 310 minecraft:stripped_oak_log
fill 416 194 311 416 197 311 minecraft:red_terracotta
setblock 416 194 315 minecraft:stripped_oak_log
fill 416 194 316 416 197 316 minecraft:red_terracotta
setblock 417 194 279 minecraft:stripped_oak_log
fill 417 194 280 417 197 280 minecraft:red_terracotta
setblock 417 194 284 minecraft:stripped_oak_log
fill 417 194 285 417 197 285 minecraft:red_terracotta
setblock 417 194 289 minecraft:stripped_oak_log
fill 417 194 290 417 197 290 minecraft:red_terracotta
setblock 417 194 294 minecraft:stripped_oak_log
fill 417 194 295 417 197 295 minecraft:red_terracotta
setblock 417 194 299 minecraft:stripped_oak_log
fill 417 194 300 417 197 300 minecraft:red_terracotta
setblock 417 194 303 minecraft:red_terracotta
setblock 417 194 304 minecraft:stripped_oak_log
fill 417 194 305 417 197 305 minecraft:red_terracotta
setblock 417 194 309 minecraft:stripped_oak_log
fill 417 194 310 417 197 310 minecraft:red_terracotta
setblock 417 194 314 minecraft:stripped_oak_log
fill 417 194 315 417 197 315 minecraft:red_terracotta
setblock 377 195 278 minecraft:stripped_oak_log
fill 377 195 279 377 198 279 minecraft:red_terracotta
setblock 377 195 283 minecraft:stripped_oak_log
fill 377 195 284 377 198 284 minecraft:red_terracotta
setblock 377 195 288 minecraft:stripped_oak_log
fill 377 195 289 377 195 292 minecraft:red_terracotta
setblock 377 195 293 minecraft:stripped_oak_log
fill 377 195 294 377 198 294 minecraft:red_terracotta
setblock 377 195 298 minecraft:stripped_oak_log
fill 377 195 299 377 198 299 minecraft:red_terracotta
setblock 377 195 303 minecraft:stripped_oak_log
fill 377 195 304 377 198 304 minecraft:red_terracotta
setblock 377 195 308 minecraft:stripped_oak_log
fill 377 195 309 377 198 309 minecraft:red_terracotta
setblock 377 195 313 minecraft:stripped_oak_log
fill 377 195 314 377 198 314 minecraft:red_terracotta
setblock 378 195 277 minecraft:stripped_oak_log
fill 378 195 278 378 198 278 minecraft:red_terracotta
setblock 378 195 281 minecraft:red_terracotta
setblock 378 195 288 minecraft:red_terracotta
setblock 378 195 292 minecraft:stripped_oak_log
fill 378 195 293 378 198 293 minecraft:red_terracotta
setblock 378 195 297 minecraft:stripped_oak_log
fill 378 195 298 378 198 298 minecraft:red_terracotta
setblock 378 195 302 minecraft:stripped_oak_log
fill 378 195 303 378 198 303 minecraft:red_terracotta
setblock 378 195 307 minecraft:stripped_oak_log
fill 378 195 308 378 198 308 minecraft:red_terracotta
setblock 378 195 312 minecraft:stripped_oak_log
fill 378 195 313 378 197 313 minecraft:red_terracotta
setblock 379 195 276 minecraft:stripped_oak_log
fill 379 195 277 379 198 277 minecraft:red_terracotta
setblock 379 195 291 minecraft:stripped_oak_log
fill 379 195 292 379 196 292 minecraft:red_terracotta
setblock 379 195 296 minecraft:stripped_oak_log
fill 379 195 297 379 198 297 minecraft:red_terracotta
setblock 379 195 301 minecraft:stripped_oak_log
fill 379 195 302 380 195 302 minecraft:red_terracotta
setblock 379 195 306 minecraft:stripped_oak_log
fill 379 195 310 379 208 311 minecraft:stripped_oak_log
setblock 379 195 312 minecraft:red_terracotta
setblock 379 195 316 minecraft:stripped_oak_log
fill 380 195 276 380 198 276 minecraft:red_terracotta
setblock 380 195 295 minecraft:stripped_oak_log
fill 380 195 296 380 197 296 minecraft:red_terracotta
setblock 380 195 300 minecraft:stripped_oak_log
fill 380 195 301 380 197 301 minecraft:red_terracotta
setblock 380 195 315 minecraft:stripped_oak_log
fill 380 195 316 380 198 316 minecraft:red_terracotta
fill 381 195 315 381 196 315 minecraft:red_terracotta
setblock 384 195 276 minecraft:stripped_oak_log
setblock 384 195 316 minecraft:stripped_oak_log
fill 385 195 276 388 195 276 minecraft:red_terracotta
setblock 385 195 316 minecraft:red_terracotta
setblock 389 195 276 minecraft:stripped_oak_log
fill 390 195 276 390 197 277 minecraft:red_terracotta
setblock 390 195 316 minecraft:red_terracotta
setblock 392 195 277 minecraft:red_terracotta
setblock 393 195 277 minecraft:stripped_oak_log
fill 393 195 278 393 198 278 minecraft:red_terracotta
setblock 394 195 276 minecraft:stripped_oak_log
fill 394 195 277 394 198 277 minecraft:red_terracotta
setblock 394 195 316 minecraft:stripped_oak_log
fill 395 195 276 395 198 276 minecraft:red_terracotta
setblock 395 195 279 minecraft:red_terracotta
setblock 395 195 315 minecraft:stripped_oak_log
fill 395 195 316 395 198 316 minecraft:red_terracotta
setblock 396 195 279 minecraft:stripped_oak_log
fill 396 195 315 396 198 315 minecraft:red_terracotta
setblock 397 195 277 minecraft:red_terracotta
setblock 397 195 278 minecraft:stripped_oak_log
fill 397 195 279 397 198 279 minecraft:red_terracotta
setblock 398 195 277 minecraft:stripped_oak_log
fill 398 195 278 401 195 278 minecraft:red_terracotta
setblock 399 195 276 minecraft:stripped_oak_log
fill 399 195 277 399 198 277 minecraft:red_terracotta
setblock 399 195 316 minecraft:stripped_oak_log
fill 400 195 276 400 198 276 minecraft:red_terracotta
setblock 400 195 315 minecraft:stripped_oak_log
fill 400 195 316 400 198 316 minecraft:red_terracotta
fill 401 195 315 401 197 315 minecraft:red_terracotta
setblock 402 195 278 minecraft:stripped_oak_log
setblock 403 195 277 minecraft:stripped_oak_log
fill 403 195 278 403 198 278 minecraft:red_terracotta
setblock 404 195 276 minecraft:stripped_oak_log
fill 404 195 277 407 195 277 minecraft:red_terracotta
setblock 404 195 316 minecraft:stripped_oak_log
fill 405 195 276 408 195 276 minecraft:red_terracotta
setblock 405 195 315 minecraft:stripped_oak_log
fill 405 195 316 405 198 316 minecraft:red_terracotta
fill 406 195 315 406 196 315 minecraft:red_terracotta
setblock 408 195 277 minecraft:stripped_oak_log
setblock 409 195 276 minecraft:stripped_oak_log
fill 409 195 277 409 198 277 minecraft:red_terracotta
setblock 409 195 316 minecraft:stripped_oak_log
fill 410 195 276 410 198 276 minecraft:red_terracotta
setblock 410 195 315 minecraft:stripped_oak_log
fill 410 195 316 410 198 316 minecraft:red_terracotta
fill 411 195 315 411 198 315 minecraft:red_terracotta
setblock 412 195 277 minecraft:red_terracotta
fill 412 195 314 412 196 314 minecraft:red_terracotta
setblock 413 195 277 minecraft:stripped_oak_log
fill 413 195 278 413 198 278 minecraft:red_terracotta
setblock 414 195 276 minecraft:stripped_oak_log
fill 414 195 277 414 198 277 minecraft:red_terracotta
setblock 414 195 316 minecraft:stripped_oak_log
fill 415 195 276 415 198 276 minecraft:red_terracotta
setblock 415 195 279 minecraft:red_terracotta
fill 415 195 296 415 195 299 minecraft:red_terracotta
setblock 415 195 300 minecraft:stripped_oak_log
fill 415 195 301 416 197 301 minecraft:red_terracotta
fill 415 195 311 415 196 311 minecraft:red_terracotta
setblock 415 195 315 minecraft:stripped_oak_log
fill 415 195 316 415 198 316 minecraft:red_terracotta
setblock 416 195 278 minecraft:red_terracotta
setblock 416 195 279 minecraft:stripped_oak_log
fill 416 195 280 416 197 281 minecraft:red_terracotta
fill 416 195 292 416 195 293 minecraft:red_terracotta
setblock 416 195 294 minecraft:stripped_oak_log
fill 416 195 295 416 198 295 minecraft:red_terracotta
setblock 416 195 298 minecraft:red_terracotta
setblock 416 195 299 minecraft:stripped_oak_log
fill 416 195 300 416 198 300 minecraft:red_terracotta
fill 416 195 302 416 195 303 minecraft:red_terracotta
setblock 416 195 304 minecraft:stripped_oak_log
fill 416 195 305 416 198 305 minecraft:red_terracotta
setblock 416 195 309 minecraft:stripped_oak_log
fill 416 195 310 416 198 310 minecraft:red_terracotta
setblock 416 195 314 minecraft:stripped_oak_log
fill 416 195 315 416 198 315 minecraft:red_terracotta
setblock 417 195 278 minecraft:stripped_oak_log
fill 417 195 279 417 198 279 minecraft:red_terracotta
setblock 417 195 283 minecraft:stripped_oak_log
fill 417 195 284 417 198 284 minecraft:red_terracotta
setblock 417 195 286 minecraft:red_terracotta
setblock 417 195 288 minecraft:stripped_oak_log
fill 417 195 289 417 196 289 minecraft:red_terracotta
setblock 417 195 293 minecraft:stripped_oak_log
fill 417 195 294 417 198 294 minecraft:red_terracotta
setblock 417 195 298 minecraft:stripped_oak_log
fill 417 195 299 417 198 299 minecraft:red_terracotta
setblock 417 195 303 minecraft:stripped_oak_log
fill 417 195 304 417 198 304 minecraft:red_terracotta
setblock 417 195 308 minecraft:stripped_oak_log
fill 417 195 309 417 198 309 minecraft:red_terracotta
setblock 417 195 313 minecraft:stripped_oak_log
fill 417 195 314 417 198 314 minecraft:red_terracotta
fill 376 196 275 376 199 317 minecraft:orange_terracotta
fill 377 196 275 418 199 275 minecraft:orange_terracotta
setblock 377 196 276 minecraft:red_terracotta
setblock 377 196 277 minecraft:stripped_oak_log
fill 377 196 278 377 199 278 minecraft:red_terracotta
setblock 377 196 281 minecraft:red_terracotta
setblock 377 196 282 minecraft:stripped_oak_log
fill 377 196 283 377 199 283 minecraft:red_terracotta
setblock 377 196 287 minecraft:stripped_oak_log
fill 377 196 288 377 196 291 minecraft:red_terracotta
setblock 377 196 292 minecraft:stripped_oak_log
fill 377 196 293 377 199 293 minecraft:red_terracotta
setblock 377 196 297 minecraft:stripped_oak_log
fill 377 196 298 377 199 298 minecraft:red_terracotta
setblock 377 196 302 minecraft:stripped_oak_log
fill 377 196 303 377 199 303 minecraft:red_terracotta
setblock 377 196 307 minecraft:stripped_oak_log
fill 377 196 308 377 199 308 minecraft:red_terracotta
setblock 377 196 312 minecraft:stripped_oak_log
fill 377 196 313 377 199 313 minecraft:red_terracotta
fill 377 196 317 418 199 317 minecraft:orange_terracotta
setblock 378 196 276 minecraft:stripped_oak_log
fill 378 196 277 378 199 277 minecraft:red_terracotta
setblock 378 196 281 minecraft:stripped_oak_log
setblock 378 196 291 minecraft:stripped_oak_log
fill 378 196 292 378 199 292 minecraft:red_terracotta
setblock 378 196 296 minecraft:stripped_oak_log
fill 378 196 297 378 199 297 minecraft:red_terracotta
setblock 378 196 301 minecraft:stripped_oak_log
fill 378 196 302 379 198 302 minecraft:red_terracotta
setblock 378 196 305 minecraft:red_terracotta
setblock 378 196 306 minecraft:stripped_oak_log
fill 378 196 307 378 199 307 minecraft:red_terracotta
setblock 378 196 311 minecraft:stripped_oak_log
fill 378 196 312 378 197 312 minecraft:red_terracotta
setblock 378 196 316 minecraft:stripped_oak_log
fill 379 196 276 379 199 276 minecraft:red_terracotta
setblock 379 196 295 minecraft:stripped_oak_log
fill 379 196 296 379 199 296 minecraft:red_terracotta
setblock 379 196 300 minecraft:stripped_oak_log
fill 379 196 301 379 199 301 minecraft:red_terracotta
setblock 379 196 305 minecraft:stripped_oak_log
setblock 379 196 315 minecraft:stripped_oak_log
fill 379 196 316 379 199 316 minecraft:red_terracotta
setblock 380 196 294 minecraft:stripped_oak_log
setblock 380 196 295 minecraft:red_terracotta
setblock 380 196 299 minecraft:stripped_oak_log
fill 380 196 300 380 198 300 minecraft:red_terracotta
fill 380 196 315 380 197 315 minecraft:red_terracotta
setblock 381 196 277 minecraft:red_terracotta
setblock 382 196 277 minecraft:stripped_oak_log
setblock 383 196 276 minecraft:stripped_oak_log
setblock 383 196 316 minecraft:stripped_oak_log
fill 384 196 276 387 196 276 minecraft:red_terracotta
setblock 384 196 316 minecraft:red_terracotta
setblock 388 196 276 minecraft:stripped_oak_log
fill 389 196 276 389 199 276 minecraft:red_terracotta
setblock 392 196 277 minecraft:stripped_oak_log
fill 392 196 278 392 199 278 minecraft:red_terracotta
setblock 393 196 276 minecraft:stripped_oak_log
fill 393 196 277 393 199 277 minecraft:red_terracotta
setblock 393 196 316 minecraft:stripped_oak_log
fill 394 196 276 394 199 276 minecraft:red_terracotta
setblock 394 196 315 minecraft:stripped_oak_log
fill 394 196 316 394 199 316 minecraft:red_terracotta
setblock 395 196 278 minecraft:red_terracotta
setblock 395 196 279 minecraft:stripped_oak_log
fill 395 196 315 395 198 315 minecraft:red_terracotta
setblock 396 196 278 minecraft:stripped_oak_log
fill 396 196 279 396 199 279 minecraft:red_terracotta
setblock 397 196 277 minecraft:stripped_oak_log
fill 397 196 278 400 196 278 minecraft:red_terracotta
setblock 398 196 276 minecraft:stripped_oak_log
fill 398 196 277 398 199 277 minecraft:red_terracotta
setblock 398 196 316 minecraft:stripped_oak_log
fill 399 196 276 399 199 276 minecraft:red_terracotta
setblock 399 196 315 minecraft:stripped_oak_log
fill 399 196 316 399 199 316 minecraft:red_terracotta
setblock 400 196 279 minecraft:stripped_oak_log
fill 400 196 315 400 198 315 minecraft:red_terracotta
setblock 401 196 278 minecraft:stripped_oak_log
setblock 402 196 277 minecraft:stripped_oak_log
fill 402 196 278 402 199 278 minecraft:red_terracotta
setblock 403 196 276 minecraft:stripped_oak_log
fill 403 196 277 406 196 277 minecraft:red_terracotta
setblock 403 196 316 minecraft:stripped_oak_log
fill 404 196 276 407 196 276 minecraft:red_terracotta
setblock 404 196 315 minecraft:stripped_oak_log
fill 404 196 316 404 199 316 minecraft:red_terracotta
setblock 405 196 315 minecraft:red_terracotta
setblock 407 196 277 minecraft:stripped_oak_log
setblock 408 196 276 minecraft:stripped_oak_log
fill 408 196 277 408 199 277 minecraft:red_terracotta
setblock 408 196 316 minecraft:stripped_oak_log
fill 409 196 276 409 199 276 minecraft:red_terracotta
setblock 409 196 315 minecraft:stripped_oak_log
fill 409 196 316 409 199 316 minecraft:red_terracotta
fill 410 196 315 410 198 315 minecraft:red_terracotta
setblock 412 196 277 minecraft:stripped_oak_log
fill 412 196 278 412 198 278 minecraft:red_terracotta
setblock 413 196 276 minecraft:stripped_oak_log
fill 413 196 277 413 199 277 minecraft:red_terracotta
setblock 413 196 316 minecraft:stripped_oak_log
fill 414 196 276 414 199 276 minecraft:red_terracotta
setblock 414 196 315 minecraft:stripped_oak_log
fill 414 196 316 414 199 316 minecraft:red_terracotta
setblock 415 196 279 minecraft:stripped_oak_log
fill 415 196 296 415 196 298 minecraft:red_terracotta
setblock 415 196 299 minecraft:stripped_oak_log
fill 415 196 300 415 199 300 minecraft:red_terracotta
fill 415 196 302 415 196 303 minecraft:red_terracotta
setblock 415 196 314 minecraft:stripped_oak_log
fill 415 196 315 415 199 315 minecraft:red_terracotta
setblock 416 196 278 minecraft:stripped_oak_log
fill 416 196 279 416 199 279 minecraft:red_terracotta
setblock 416 196 292 minecraft:red_terracotta
setblock 416 196 293 minecraft:stripped_oak_log
fill 416 196 294 416 198 294 minecraft:red_terracotta
setblock 416 196 298 minecraft:stripped_oak_log
fill 416 196 299 416 199 299 minecraft:red_terracotta
setblock 416 196 302 minecraft:red_terracotta
setblock 416 196 303 minecraft:stripped_oak_log
fill 416 196 304 416 199 304 minecraft:red_terracotta
setblock 416 196 308 minecraft:stripped_oak_log
fill 416 196 309 416 199 309 minecraft:red_terracotta
setblock 416 196 313 minecraft:stripped_oak_log
fill 416 196 314 416 199 314 minecraft:red_terracotta
setblock 417 196 277 minecraft:stripped_oak_log
fill 417 196 278 417 199 278 minecraft:red_terracotta
setblock 417 196 282 minecraft:stripped_oak_log
fill 417 196 283 417 199 283 minecraft:red_terracotta
setblock 417 196 288 minecraft:red_terracotta
setblock 417 196 292 minecraft:stripped_oak_log
fill 417 196 293 417 199 293 minecraft:red_terracotta
setblock 417 196 297 minecraft:stripped_oak_log
fill 417 196 298 417 199 298 minecraft:red_terracotta
setblock 417 196 302 minecraft:stripped_oak_log
fill 417 196 303 417 199 303 minecraft:red_terracotta
setblock 417 196 307 minecraft:stripped_oak_log
fill 417 196 308 417 199 308 minecraft:red_terracotta
setblock 417 196 312 minecraft:stripped_oak_log
fill 417 196 313 417 199 313 minecraft:red_terracotta
fill 418 196 276 418 199 316 minecraft:orange_terracotta
setblock 377 197 276 minecraft:stripped_oak_log
fill 377 197 277 377 200 277 minecraft:red_terracotta
setblock 377 197 280 minecraft:red_terracotta
setblock 377 197 281 minecraft:stripped_oak_log
fill 377 197 282 377 200 282 minecraft:red_terracotta
setblock 377 197 286 minecraft:stripped_oak_log
fill 377 197 287 377 197 290 minecraft:red_terracotta
setblock 377 197 291 minecraft:stripped_oak_log
fill 377 197 292 377 200 292 minecraft:red_terracotta
setblock 377 197 296 minecraft:stripped_oak_log
fill 377 197 297 377 200 297 minecraft:red_terracotta
setblock 377 197 301 minecraft:stripped_oak_log
fill 377 197 302 377 200 302 minecraft:red_terracotta
setblock 377 197 306 minecraft:stripped_oak_log
fill 377 197 307 377 200 307 minecraft:red_terracotta
setblock 377 197 311 minecraft:stripped_oak_log
fill 377 197 312 377 199 312 minecraft:red_terracotta
setblock 377 197 316 minecraft:stripped_oak_log
fill 378 197 276 378 200 276 minecraft:red_terracotta
setblock 378 197 280 minecraft:stripped_oak_log
fill 378 197 281 378 198 281 minecraft:red_terracotta
setblock 378 197 290 minecraft:stripped_oak_log
fill 378 197 291 378 198 291 minecraft:red_terracotta
setblock 378 197 295 minecraft:stripped_oak_log
fill 378 197 296 378 200 296 minecraft:red_terracotta
setblock 378 197 300 minecraft:stripped_oak_log
fill 378 197 301 378 200 301 minecraft:red_terracotta
setblock 378 197 305 minecraft:stripped_oak_log
fill 378 197 306 378 200 306 minecraft:red_terracotta
fill 378 197 310 378 208 310 minecraft:stripped_oak_log
setblock 378 197 311 minecraft:red_terracotta
setblock 378 197 315 minecraft:stripped_oak_log
fill 378 197 316 378 199 316 minecraft:red_terracotta
setblock 379 197 278 minecraft:light[level=12]
setblock 379 197 285 minecraft:light[level=12]
setblock 379 197 292 minecraft:light[level=12]
setblock 379 197 294 minecraft:stripped_oak_log
fill 379 197 295 379 199 295 minecraft:red_terracotta
setblock 379 197 299 minecraft:stripped_oak_log
fill 379 197 300 379 200 300 minecraft:red_terracotta
setblock 379 197 304 minecraft:stripped_oak_log
setblock 379 197 305 minecraft:red_terracotta
setblock 379 197 306 minecraft:light[level=12]
setblock 379 197 313 minecraft:light[level=12]
setblock 379 197 315 minecraft:red_terracotta
setblock 380 197 298 minecraft:stripped_oak_log
fill 380 197 299 380 198 299 minecraft:red_terracotta
setblock 381 197 277 minecraft:stripped_oak_log
setblock 382 197 276 minecraft:stripped_oak_log
setblock 382 197 316 minecraft:stripped_oak_log
fill 383 197 276 386 197 276 minecraft:red_terracotta
fill 384 197 279 384 200 279 minecraft:iron_bars
setblock 386 197 278 minecraft:light[level=12]
setblock 386 197 285 minecraft:light[level=12]
setblock 386 197 292 minecraft:light[level=12]
setblock 386 197 299 minecraft:light[level=12]
setblock 386 197 306 minecraft:light[level=12]
setblock 386 197 313 minecraft:light[level=12]
setblock 387 197 276 minecraft:stripped_oak_log
fill 388 197 276 388 200 276 minecraft:red_terracotta
fill 389 197 277 389 198 277 minecraft:red_terracotta
setblock 391 197 276 minecraft:red_terracotta
setblock 391 197 277 minecraft:stripped_oak_log
setblock 392 197 276 minecraft:stripped_oak_log
fill 392 197 277 392 200 277 minecraft:red_terracotta
setblock 392 197 316 minecraft:stripped_oak_log
fill 393 197 276 393 200 276 minecraft:red_terracotta
setblock 393 197 285 minecraft:light[level=12]
setblock 393 197 292 minecraft:light[level=12]
setblock 393 197 299 minecraft:light[level=12]
setblock 393 197 306 minecraft:light[level=12]
setblock 393 197 313 minecraft:light[level=12]
fill 393 197 316 393 200 316 minecraft:red_terracotta
setblock 394 197 279 minecraft:stripped_oak_log
setblock 394 197 315 minecraft:red_terracotta
setblock 395 197 278 minecraft:stripped_oak_log
fill 395 197 279 395 200 279 minecraft:red_terracotta
setblock 396 197 277 minecraft:stripped_oak_log
fill 396 197 278 399 197 278 minecraft:red_terracotta
setblock 397 197 276 minecraft:stripped_oak_log
fill 397 197 277 397 200 277 minecraft:red_terracotta
setblock 397 197 316 minecraft:stripped_oak_log
fill 398 197 276 398 200 276 minecraft:red_terracotta
setblock 398 197 315 minecraft:stripped_oak_log
fill 398 197 316 398 200 316 minecraft:red_terracotta
setblock 399 197 279 minecraft:stripped_oak_log
fill 399 197 315 399 198 315 minecraft:red_terracotta
setblock 400 197 278 minecraft:stripped_oak_log
fill 400 197 279 400 198 279 minecraft:red_terracotta
setblock 400 197 285 minecraft:light[level=12]
setblock 400 197 292 minecraft:light[level=12]
setblock 400 197 299 minecraft:light[level=12]
setblock 400 197 313 minecraft:light[level=12]
setblock 401 197 277 minecraft:stripped_oak_log
fill 401 197 278 401 200 278 minecraft:red_terracotta
setblock 402 197 276 minecraft:stripped_oak_log
fill 402 197 277 405 197 277 minecraft:red_terracotta
fill 402 197 279 402 199 279 minecraft:green_concrete
setblock 402 197 316 minecraft:stripped_oak_log
fill 403 197 276 406 197 276 minecraft:red_terracotta
setblock 403 197 315 minecraft:stripped_oak_log
fill 403 197 316 403 199 316 minecraft:red_terracotta
setblock 406 197 277 minecraft:stripped_oak_log
setblock 407 197 276 minecraft:stripped_oak_log
fill 407 197 277 407 199 277 minecraft:red_terracotta
setblock 407 197 278 minecraft:light[level=12]
setblock 407 197 285 minecraft:light[level=12]
setblock 407 197 292 minecraft:light[level=12]
setblock 407 197 299 minecraft:light[level=12]
setblock 407 197 306 minecraft:light[level=12]
setblock 407 197 313 minecraft:light[level=12]
setblock 407 197 316 minecraft:stripped_oak_log
fill 408 197 276 408 200 276 minecraft:red_terracotta
fill 408 197 316 408 200 316 minecraft:red_terracotta
setblock 409 197 315 minecraft:red_terracotta
setblock 411 197 277 minecraft:stripped_oak_log
setblock 412 197 276 minecraft:stripped_oak_log
fill 412 197 277 412 200 277 minecraft:red_terracotta
setblock 412 197 316 minecraft:stripped_oak_log
fill 413 197 276 413 200 276 minecraft:red_terracotta
setblock 413 197 315 minecraft:stripped_oak_log
fill 413 197 316 413 200 316 minecraft:red_terracotta
setblock 414 197 278 minecraft:red_terracotta
setblock 414 197 285 minecraft:light[level=12]
setblock 414 197 292 minecraft:light[level=12]
setblock 414 197 299 minecraft:light[level=12]
setblock 414 197 306 minecraft:light[level=12]
setblock 414 197 313 minecraft:light[level=12]
setblock 414 197 314 minecraft:stripped_oak_log
fill 414 197 315 414 200 315 minecraft:red_terracotta
setblock 415 197 278 minecraft:stripped_oak_log
fill 415 197 279 415 198 279 minecraft:red_terracotta
fill 415 197 296 415 197 297 minecraft:red_terracotta
setblock 415 197 298 minecraft:stripped_oak_log
fill 415 197 299 415 200 299 minecraft:red_terracotta
setblock 415 197 302 minecraft:red_terracotta
setblock 415 197 303 minecraft:stripped_oak_log
fill 415 197 304 415 200 304 minecraft:red_terracotta
setblock 415 197 313 minecraft:stripped_oak_log
fill 415 197 314 415 198 314 minecraft:red_terracotta
setblock 416 197 277 minecraft:stripped_oak_log
fill 416 197 278 416 200 278 minecraft:red_terracotta
setblock 416 197 282 minecraft:stripped_oak_log
setblock 416 197 293 minecraft:red_terracotta
setblock 416 197 297 minecraft:stripped_oak_log
fill 416 197 298 416 200 298 minecraft:red_terracotta
setblock 416 197 302 minecraft:stripped_oak_log
fill 416 197 303 416 200 303 minecraft:red_terracotta
setblock 416 197 307 minecraft:stripped_oak_log
fill 416 197 308 416 200 308 minecraft:red_terracotta
setblock 416 197 312 minecraft:stripped_oak_log
fill 416 197 313 416 200 313 minecraft:red_terracotta
setblock 417 197 276 minecraft:stripped_oak_log
fill 417 197 277 417 200 277 minecraft:red_terracotta
setblock 417 197 281 minecraft:stripped_oak_log
fill 417 197 282 417 200 282 minecraft:red_terracotta
setblock 417 197 291 minecraft:stripped_oak_log
fill 417 197 292 417 199 292 minecraft:red_terracotta
setblock 417 197 296 minecraft:stripped_oak_log
fill 417 197 297 417 200 297 minecraft:red_terracotta
setblock 417 197 301 minecraft:stripped_oak_log
fill 417 197 302 417 200 302 minecraft:red_terracotta
setblock 417 197 306 minecraft:stripped_oak_log
fill 417 197 307 417 200 307 minecraft:red_terracotta
setblock 417 197 311 minecraft:stripped_oak_log
fill 417 197 312 417 200 312 minecraft:red_terracotta
setblock 417 197 316 minecraft:stripped_oak_log
fill 377 198 276 377 201 276 minecraft:red_terracotta
setblock 377 198 280 minecraft:stripped_oak_log
fill 377 198 281 377 201 281 minecraft:red_terracotta
setblock 377 198 285 minecraft:stripped_oak_log
fill 377 198 286 377 198 289 minecraft:red_terracotta
setblock 377 198 290 minecraft:stripped_oak_log
fill 377 198 291 377 201 291 minecraft:red_terracotta
setblock 377 198 295 minecraft:stripped_oak_log
fill 377 198 296 377 201 296 minecraft:red_terracotta
setblock 377 198 300 minecraft:stripped_oak_log
fill 377 198 301 377 201 301 minecraft:red_terracotta
setblock 377 198 305 minecraft:stripped_oak_log
fill 377 198 306 377 201 306 minecraft:red_terracotta
setblock 377 198 310 minecraft:stripped_oak_log
fill 377 198 311 377 200 311 minecraft:red_terracotta
setblock 377 198 315 minecraft:stripped_oak_log
fill 377 198 316 377 200 316 minecraft:red_terracotta
setblock 378 198 279 minecraft:stripped_oak_log
fill 378 198 280 378 199 280 minecraft:red_terracotta
setblock 378 198 294 minecraft:stripped_oak_log
fill 378 198 295 378 201 295 minecraft:red_terracotta
setblock 378 198 299 minecraft:stripped_oak_log
fill 378 198 300 378 201 300 minecraft:red_terracotta
setblock 378 198 304 minecraft:stripped_oak_log
fill 378 198 305 378 201 305 minecraft:red_terracotta
fill 378 198 309 378 208 309 minecraft:stripped_oak_log
setblock 378 198 315 minecraft:red_terracotta
setblock 379 198 294 minecraft:red_terracotta
setblock 379 198 298 minecraft:stripped_oak_log
fill 379 198 299 379 201 299 minecraft:red_terracotta
setblock 379 198 303 minecraft:stripped_oak_log
fill 379 198 304 379 199 304 minecraft:red_terracotta
setblock 380 198 277 minecraft:stripped_oak_log
setblock 380 198 298 minecraft:red_terracotta
setblock 381 198 276 minecraft:stripped_oak_log
setblock 381 198 316 minecraft:stripped_oak_log
fill 382 198 276 383 198 276 minecraft:red_terracotta
fill 387 198 276 387 199 276 minecraft:red_terracotta
setblock 390 198 276 minecraft:red_terracotta
setblock 390 198 277 minecraft:stripped_oak_log
setblock 391 198 276 minecraft:stripped_oak_log
fill 391 198 277 391 200 278 minecraft:red_terracotta
fill 392 198 276 392 201 276 minecraft:red_terracotta
fill 392 198 316 392 200 316 minecraft:red_terracotta
setblock 394 198 278 minecraft:stripped_oak_log
fill 394 198 279 394 201 279 minecraft:red_terracotta
setblock 395 198 277 minecraft:stripped_oak_log
fill 395 198 278 398 198 278 minecraft:red_terracotta
setblock 396 198 276 minecraft:stripped_oak_log
fill 396 198 277 396 201 277 minecraft:red_terracotta
setblock 396 198 316 minecraft:stripped_oak_log
fill 397 198 276 397 201 276 minecraft:red_terracotta
setblock 397 198 315 minecraft:stripped_oak_log
fill 397 198 316 397 201 316 minecraft:red_terracotta
setblock 398 198 279 minecraft:stripped_oak_log
setblock 398 198 315 minecraft:red_terracotta
setblock 399 198 278 minecraft:stripped_oak_log
fill 399 198 279 399 199 279 minecraft:red_terracotta
setblock 400 198 277 minecraft:stripped_oak_log
fill 400 198 278 400 201 278 minecraft:red_terracotta
setblock 401 198 276 minecraft:stripped_oak_log
fill 401 198 277 404 198 277 minecraft:red_terracotta
setblock 401 198 316 minecraft:stripped_oak_log
fill 402 198 276 405 198 276 minecraft:red_terracotta
fill 402 198 316 402 200 316 minecraft:red_terracotta
setblock 405 198 277 minecraft:stripped_oak_log
setblock 406 198 276 minecraft:stripped_oak_log
fill 406 198 277 406 199 277 minecraft:red_terracotta
setblock 406 198 316 minecraft:stripped_oak_log
fill 407 198 276 407 201 276 minecraft:red_terracotta
fill 407 198 316 407 200 316 minecraft:red_terracotta
setblock 410 198 277 minecraft:stripped_oak_log
setblock 411 198 276 minecraft:stripped_oak_log
fill 411 198 277 411 201 277 minecraft:red_terracotta
setblock 411 198 316 minecraft:stripped_oak_log
fill 412 198 276 412 201 276 minecraft:red_terracotta
setblock 412 198 315 minecraft:stripped_oak_log
fill 412 198 316 412 201 316 minecraft:red_terracotta
fill 413 198 315 413 201 315 minecraft:red_terracotta
setblock 414 198 278 minecraft:stripped_oak_log
setblock 414 198 314 minecraft:red_terracotta
setblock 415 198 277 minecraft:stripped_oak_log
fill 415 198 278 415 199 278 minecraft:red_terracotta
setblock 415 198 297 minecraft:stripped_oak_log
fill 415 198 298 415 200 298 minecraft:red_terracotta
setblock 415 198 301 minecraft:red_terracotta
setblock 415 198 302 minecraft:stripped_oak_log
fill 415 198 303 415 201 303 minecraft:red_terracotta
fill 415 198 305 415 199 305 minecraft:red_terracotta
setblock 415 198 313 minecraft:red_terracotta
setblock 416 198 276 minecraft:stripped_oak_log
fill 416 198 277 416 201 277 minecraft:red_terracotta
setblock 416 198 280 minecraft:red_terracotta
setblock 416 198 281 minecraft:stripped_oak_log
setblock 416 198 282 minecraft:red_terracotta
setblock 416 198 296 minecraft:stripped_oak_log
fill 416 198 297 416 201 297 minecraft:red_terracotta
setblock 416 198 301 minecraft:stripped_oak_log
fill 416 198 302 416 201 302 minecraft:red_terracotta
setblock 416 198 306 minecraft:stripped_oak_log
fill 416 198 307 416 201 307 minecraft:red_terracotta
setblock 416 198 311 minecraft:stripped_oak_log
fill 416 198 312 416 200 312 minecraft:red_terracotta
setblock 416 198 316 minecraft:stripped_oak_log
fill 417 198 276 417 201 276 minecraft:red_terracotta
setblock 417 198 280 minecraft:stripped_oak_log
fill 417 198 281 417 201 281 minecraft:red_terracotta
setblock 417 198 291 minecraft:red_terracotta
setblock 417 198 295 minecraft:stripped_oak_log
fill 417 198 296 417 201 296 minecraft:red_terracotta
setblock 417 198 300 minecraft:stripped_oak_log
fill 417 198 301 417 201 301 minecraft:red_terracotta
setblock 417 198 305 minecraft:stripped_oak_log
fill 417 198 306 417 201 306 minecraft:red_terracotta
setblock 417 198 310 minecraft:stripped_oak_log
fill 417 198 311 417 201 311 minecraft:red_terracotta
setblock 417 198 315 minecraft:stripped_oak_log
fill 417 198 316 417 201 316 minecraft:red_terracotta
setblock 377 199 279 minecraft:stripped_oak_log
fill 377 199 280 377 202 280 minecraft:red_terracotta
setblock 377 199 284 minecraft:stripped_oak_log
fill 377 199 285 377 199 288 minecraft:red_terracotta
setblock 377 199 289 minecraft:stripped_oak_log
fill 377 199 290 377 202 290 minecraft:red_terracotta
setblock 377 199 294 minecraft:stripped_oak_log
fill 377 199 295 377 202 295 minecraft:red_terracotta
setblock 377 199 299 minecraft:stripped_oak_log
fill 377 199 300 377 202 300 minecraft:red_terracotta
setblock 377 199 304 minecraft:stripped_oak_log
fill 377 199 305 377 202 305 minecraft:red_terracotta
setblock 377 199 309 minecraft:stripped_oak_log
fill 377 199 310 377 201 310 minecraft:red_terracotta
setblock 377 199 314 minecraft:stripped_oak_log
fill 377 199 315 377 200 315 minecraft:red_terracotta
setblock 378 199 278 minecraft:stripped_oak_log
setblock 378 199 279 minecraft:red_terracotta
setblock 378 199 293 minecraft:stripped_oak_log
fill 378 199 294 378 200 294 minecraft:red_terracotta
setblock 378 199 298 minecraft:stripped_oak_log
fill 378 199 299 378 202 299 minecraft:red_terracotta
setblock 378 199 302 minecraft:red_terracotta
setblock 378 199 303 minecraft:stripped_oak_log
fill 378 199 304 378 202 304 minecraft:red_terracotta
fill 378 199 308 378 208 308 minecraft:stripped_oak_log
setblock 379 199 278 minecraft:light[level=15]
setblock 379 199 286 minecraft:light[level=15]
setblock 379 199 294 minecraft:light[level=15]
setblock 379 199 297 minecraft:stripped_oak_log
fill 379 199 298 379 200 298 minecraft:red_terracotta
setblock 379 199 302 minecraft:stripped_oak_log
fill 379 199 303 379 200 303 minecraft:red_terracotta
setblock 380 199 276 minecraft:stripped_oak_log
setblock 381 199 276 minecraft:red_terracotta
setblock 387 199 278 minecraft:light[level=15]
setblock 387 199 294 minecraft:light[level=15]
setblock 387 199 302 minecraft:light[level=15]
setblock 387 199 310 minecraft:light[level=15]
setblock 389 199 277 minecraft:stripped_oak_log
setblock 390 199 276 minecraft:stripped_oak_log
fill 390 199 277 390 202 277 minecraft:red_terracotta
fill 391 199 276 391 202 276 minecraft:red_terracotta
setblock 393 199 278 minecraft:stripped_oak_log
fill 393 199 279 393 202 279 minecraft:red_terracotta
setblock 394 199 277 minecraft:stripped_oak_log
fill 394 199 278 397 199 278 minecraft:red_terracotta
setblock 395 199 276 minecraft:stripped_oak_log
fill 395 199 277 395 202 277 minecraft:red_terracotta
setblock 395 199 286 minecraft:light[level=15]
setblock 395 199 294 minecraft:light[level=15]
setblock 395 199 302 minecraft:light[level=15]
setblock 395 199 310 minecraft:light[level=15]
setblock 395 199 316 minecraft:stripped_oak_log
fill 396 199 276 396 202 276 minecraft:red_terracotta
fill 396 199 316 396 202 316 minecraft:red_terracotta
setblock 397 199 279 minecraft:stripped_oak_log
setblock 398 199 278 minecraft:stripped_oak_log
fill 398 199 279 398 200 279 minecraft:red_terracotta
setblock 399 199 277 minecraft:stripped_oak_log
fill 399 199 278 399 202 278 minecraft:red_terracotta
setblock 400 199 276 minecraft:stripped_oak_log
fill 400 199 277 403 199 277 minecraft:red_terracotta
setblock 400 199 316 minecraft:stripped_oak_log
fill 401 199 276 404 199 276 minecraft:red_terracotta
fill 401 199 316 401 200 316 minecraft:red_terracotta
setblock 403 199 278 minecraft:light[level=15]
setblock 403 199 286 minecraft:light[level=15]
setblock 403 199 294 minecraft:light[level=15]
setblock 403 199 302 minecraft:light[level=15]
setblock 403 199 310 minecraft:light[level=15]
setblock 404 199 277 minecraft:stripped_oak_log
setblock 405 199 276 minecraft:stripped_oak_log
setblock 405 199 277 minecraft:red_terracotta
setblock 405 199 316 minecraft:stripped_oak_log
fill 406 199 276 406 202 276 minecraft:red_terracotta
setblock 406 199 316 minecraft:red_terracotta
setblock 409 199 277 minecraft:stripped_oak_log
setblock 410 199 276 minecraft:stripped_oak_log
fill 410 199 277 410 202 277 minecraft:red_terracotta
setblock 410 199 316 minecraft:stripped_oak_log
fill 411 199 276 411 202 276 minecraft:red_terracotta
setblock 411 199 278 minecraft:light[level=15]
setblock 411 199 286 minecraft:light[level=15]
setblock 411 199 294 minecraft:light[level=15]
setblock 411 199 302 minecraft:light[level=15]
setblock 411 199 310 minecraft:light[level=15]
setblock 411 199 315 minecraft:stripped_oak_log
fill 411 199 316 411 202 316 minecraft:red_terracotta
fill 412 199 315 412 202 315 minecraft:red_terracotta
setblock 413 199 278 minecraft:stripped_oak_log
setblock 414 199 277 minecraft:stripped_oak_log
setblock 414 199 278 minecraft:red_terracotta
setblock 415 199 276 minecraft:stripped_oak_log
fill 415 199 277 415 202 277 minecraft:red_terracotta
setblock 415 199 297 minecraft:red_terracotta
setblock 415 199 301 minecraft:stripped_oak_log
fill 415 199 302 415 202 302 minecraft:red_terracotta
setblock 415 199 306 minecraft:stripped_oak_log
setblock 415 199 316 minecraft:stripped_oak_log
fill 416 199 276 416 202 276 minecraft:red_terracotta
setblock 416 199 280 minecraft:stripped_oak_log
fill 416 199 281 416 202 281 minecraft:red_terracotta
setblock 416 199 295 minecraft:stripped_oak_log
fill 416 199 296 416 201 296 minecraft:red_terracotta
setblock 416 199 300 minecraft:stripped_oak_log
fill 416 199 301 416 202 301 minecraft:red_terracotta
setblock 416 199 305 minecraft:stripped_oak_log
fill 416 199 306 416 202 306 minecraft:red_terracotta
setblock 416 199 310 minecraft:stripped_oak_log
fill 416 199 311 416 202 311 minecraft:red_terracotta
setblock 416 199 315 minecraft:stripped_oak_log
fill 416 199 316 416 202 316 minecraft:red_terracotta
setblock 417 199 279 minecraft:stripped_oak_log
fill 417 199 280 417 202 280 minecraft:red_terracotta
setblock 417 199 284 minecraft:stripped_oak_log
setblock 417 199 294 minecraft:stripped_oak_log
fill 417 199 295 417 202 295 minecraft:red_terracotta
setblock 417 199 299 minecraft:stripped_oak_log
fill 417 199 300 417 202 300 minecraft:red_terracotta
setblock 417 199 304 minecraft:stripped_oak_log
fill 417 199 305 417 202 305 minecraft:red_terracotta
setblock 417 199 309 minecraft:stripped_oak_log
fill 417 199 310 417 202 310 minecraft:red_terracotta
setblock 417 199 314 minecraft:stripped_oak_log
fill 417 199 315 417 202 315 minecraft:red_terracotta
fill 376 200 275 376 203 317 minecraft:red_terracotta
fill 377 200 275 418 202 275 minecraft:red_terracotta
setblock 377 200 278 minecraft:stripped_oak_log
fill 377 200 279 377 203 279 minecraft:red_terracotta
setblock 377 200 283 minecraft:stripped_oak_log
fill 377 200 284 377 200 287 minecraft:red_terracotta
setblock 377 200 288 minecraft:stripped_oak_log
fill 377 200 289 377 203 289 minecraft:red_terracotta
setblock 377 200 293 minecraft:stripped_oak_log
fill 377 200 294 377 203 294 minecraft:red_terracotta
setblock 377 200 298 minecraft:stripped_oak_log
fill 377 200 299 377 203 299 minecraft:red_terracotta
setblock 377 200 303 minecraft:stripped_oak_log
fill 377 200 304 377 203 304 minecraft:red_terracotta
setblock 377 200 308 minecraft:stripped_oak_log
fill 377 200 309 377 203 309 minecraft:red_terracotta
setblock 377 200 314 minecraft:red_terracotta
fill 377 200 317 418 203 317 minecraft:red_terracotta
setblock 378 200 293 minecraft:red_terracotta
setblock 378 200 297 minecraft:stripped_oak_log
fill 378 200 298 378 203 298 minecraft:red_terracotta
setblock 378 200 302 minecraft:stripped_oak_log
fill 378 200 303 378 203 303 minecraft:red_terracotta
setblock 379 200 276 minecraft:stripped_oak_log
setblock 379 200 297 minecraft:red_terracotta
setblock 379 200 301 minecraft:stripped_oak_log
fill 379 200 302 379 201 302 minecraft:red_terracotta
setblock 389 200 276 minecraft:stripped_oak_log
fill 389 200 277 389 203 277 minecraft:red_terracotta
fill 390 200 276 390 203 276 minecraft:red_terracotta
setblock 392 200 278 minecraft:stripped_oak_log
setblock 393 200 277 minecraft:stripped_oak_log
fill 393 200 278 396 200 278 minecraft:red_terracotta
setblock 394 200 276 minecraft:stripped_oak_log
fill 394 200 277 394 203 277 minecraft:red_terracotta
setblock 394 200 316 minecraft:stripped_oak_log
fill 395 200 276 395 203 276 minecraft:red_terracotta
fill 395 200 316 395 203 316 minecraft:red_terracotta
setblock 396 200 279 minecraft:stripped_oak_log
setblock 397 200 278 minecraft:stripped_oak_log
fill 397 200 279 397 201 279 minecraft:red_terracotta
setblock 398 200 277 minecraft:stripped_oak_log
fill 398 200 278 398 203 278 minecraft:red_terracotta
setblock 399 200 276 minecraft:stripped_oak_log
fill 399 200 277 402 200 277 minecraft:red_terracotta
setblock 399 200 316 minecraft:stripped_oak_log
fill 400 200 276 403 200 276 minecraft:red_terracotta
fill 400 200 316 400 201 316 minecraft:red_terracotta
setblock 403 200 277 minecraft:stripped_oak_log
setblock 404 200 276 minecraft:stripped_oak_log
setblock 404 200 277 minecraft:red_terracotta
fill 405 200 276 405 203 276 minecraft:red_terracotta
setblock 408 200 277 minecraft:stripped_oak_log
setblock 409 200 276 minecraft:stripped_oak_log
fill 409 200 277 409 201 277 minecraft:red_terracotta
setblock 409 200 316 minecraft:stripped_oak_log
fill 410 200 276 410 203 276 minecraft:red_terracotta
fill 410 200 316 410 203 316 minecraft:red_terracotta
setblock 411 200 315 minecraft:red_terracotta
setblock 413 200 277 minecraft:stripped_oak_log
setblock 414 200 276 minecraft:stripped_oak_log
fill 414 200 277 414 203 277 minecraft:red_terracotta
setblock 414 200 316 minecraft:stripped_oak_log
fill 415 200 276 415 203 276 minecraft:red_terracotta
setblock 415 200 300 minecraft:stripped_oak_log
fill 415 200 301 415 203 301 minecraft:red_terracotta
setblock 415 200 305 minecraft:stripped_oak_log
fill 415 200 306 415 203 306 minecraft:red_terracotta
setblock 415 200 315 minecraft:stripped_oak_log
fill 415 200 316 415 203 316 minecraft:red_terracotta
setblock 416 200 279 minecraft:stripped_oak_log
fill 416 200 280 416 202 280 minecraft:red_terracotta
setblock 416 200 295 minecraft:red_terracotta
setblock 416 200 299 minecraft:stripped_oak_log
fill 416 200 300 416 203 300 minecraft:red_terracotta
setblock 416 200 304 minecraft:stripped_oak_log
fill 416 200 305 416 203 305 minecraft:red_terracotta
setblock 416 200 309 minecraft:stripped_oak_log
fill 416 200 310 416 203 310 minecraft:red_terracotta
setblock 416 200 314 minecraft:stripped_oak_log
fill 416 200 315 416 201 315 minecraft:red_terracotta
setblock 417 200 278 minecraft:stripped_oak_log
fill 417 200 279 418 203 279 minecraft:red_terracotta
setblock 417 200 283 minecraft:stripped_oak_log
fill 417 200 284 418 203 284 minecraft:red_terracotta
setblock 417 200 293 minecraft:stripped_oak_log
fill 417 200 294 418 201 294 minecraft:red_terracotta
setblock 417 200 298 minecraft:stripped_oak_log
fill 417 200 299 418 203 299 minecraft:red_terracotta
setblock 417 200 303 minecraft:stripped_oak_log
fill 417 200 304 418 203 304 minecraft:red_terracotta
setblock 417 200 308 minecraft:stripped_oak_log
fill 417 200 309 418 203 309 minecraft:red_terracotta
setblock 417 200 313 minecraft:stripped_oak_log
fill 417 200 314 418 203 314 minecraft:red_terracotta
fill 418 200 276 418 203 278 minecraft:red_terracotta
fill 418 200 280 418 203 283 minecraft:red_terracotta
fill 418 200 285 418 203 293 minecraft:red_terracotta
fill 418 200 295 418 203 298 minecraft:red_terracotta
fill 418 200 300 418 203 303 minecraft:red_terracotta
fill 418 200 305 418 203 308 minecraft:red_terracotta
fill 418 200 310 418 203 313 minecraft:red_terracotta
fill 418 200 315 418 203 316 minecraft:red_terracotta
setblock 377 201 277 minecraft:stripped_oak_log
fill 377 201 278 377 204 278 minecraft:red_terracotta
setblock 377 201 282 minecraft:stripped_oak_log
fill 377 201 283 377 201 286 minecraft:red_terracotta
setblock 377 201 287 minecraft:stripped_oak_log
fill 377 201 288 377 204 288 minecraft:red_terracotta
setblock 377 201 292 minecraft:stripped_oak_log
fill 377 201 293 377 204 293 minecraft:red_terracotta
setblock 377 201 297 minecraft:stripped_oak_log
fill 377 201 298 377 204 298 minecraft:red_terracotta
setblock 377 201 302 minecraft:stripped_oak_log
fill 377 201 303 377 204 303 minecraft:red_terracotta
setblock 377 201 307 minecraft:stripped_oak_log
fill 377 201 308 377 204 308 minecraft:red_terracotta
setblock 378 201 276 minecraft:stripped_oak_log
setblock 378 201 296 minecraft:stripped_oak_log
fill 378 201 297 378 203 297 minecraft:red_terracotta
setblock 378 201 301 minecraft:stripped_oak_log
fill 378 201 302 378 204 302 minecraft:red_terracotta
setblock 378 201 306 minecraft:stripped_oak_log
fill 379 201 276 387 201 279 minecraft:brown_terracotta
setblock 379 201 300 minecraft:stripped_oak_log
setblock 379 201 301 minecraft:red_terracotta
setblock 388 201 276 minecraft:stripped_oak_log
fill 388 201 277 388 201 279 minecraft:brown_terracotta
fill 389 201 276 389 204 276 minecraft:red_terracotta
fill 389 201 278 389 201 279 minecraft:brown_terracotta
setblock 391 201 277 minecraft:red_terracotta
setblock 391 201 278 minecraft:stripped_oak_log
setblock 392 201 277 minecraft:stripped_oak_log
fill 392 201 278 395 201 278 minecraft:red_terracotta
setblock 393 201 276 minecraft:stripped_oak_log
fill 393 201 277 393 204 277 minecraft:red_terracotta
setblock 393 201 316 minecraft:stripped_oak_log
fill 394 201 276 394 204 276 minecraft:red_terracotta
fill 394 201 316 394 204 316 minecraft:red_terracotta
setblock 395 201 279 minecraft:stripped_oak_log
setblock 396 201 278 minecraft:stripped_oak_log
fill 396 201 279 396 202 279 minecraft:red_terracotta
setblock 397 201 277 minecraft:stripped_oak_log
fill 397 201 278 397 204 278 minecraft:red_terracotta
setblock 398 201 276 minecraft:stripped_oak_log
fill 398 201 277 401 201 277 minecraft:red_terracotta
setblock 398 201 316 minecraft:stripped_oak_log
fill 399 201 276 402 201 276 minecraft:red_terracotta
setblock 399 201 316 minecraft:red_terracotta
setblock 402 201 277 minecraft:stripped_oak_log
setblock 403 201 276 minecraft:stripped_oak_log
fill 404 201 276 404 203 276 minecraft:red_terracotta
setblock 408 201 276 minecraft:stripped_oak_log
setblock 408 201 316 minecraft:stripped_oak_log
fill 409 201 276 409 204 276 minecraft:red_terracotta
fill 409 201 316 409 204 316 minecraft:red_terracotta
setblock 412 201 277 minecraft:stripped_oak_log
setblock 413 201 276 minecraft:stripped_oak_log
fill 413 201 277 413 204 277 minecraft:red_terracotta
setblock 413 201 316 minecraft:stripped_oak_log
fill 414 201 276 414 204 276 minecraft:red_terracotta
setblock 414 201 315 minecraft:stripped_oak_log
fill 414 201 316 414 204 316 minecraft:red_terracotta
setblock 415 201 299 minecraft:stripped_oak_log
fill 415 201 300 415 204 300 minecraft:red_terracotta
setblock 415 201 304 minecraft:stripped_oak_log
fill 415 201 305 415 204 305 minecraft:red_terracotta
fill 415 201 307 415 202 307 minecraft:red_terracotta
fill 415 201 315 415 202 315 minecraft:red_terracotta
setblock 416 201 278 minecraft:stripped_oak_log
fill 416 201 279 416 202 279 minecraft:red_terracotta
setblock 416 201 298 minecraft:stripped_oak_log
fill 416 201 299 416 204 299 minecraft:red_terracotta
setblock 416 201 303 minecraft:stripped_oak_log
fill 416 201 304 416 204 304 minecraft:red_terracotta
setblock 416 201 308 minecraft:stripped_oak_log
fill 416 201 309 416 204 309 minecraft:red_terracotta
setblock 416 201 314 minecraft:red_terracotta
setblock 417 201 277 minecraft:stripped_oak_log
fill 417 201 278 417 204 278 minecraft:red_terracotta
setblock 417 201 282 minecraft:stripped_oak_log
fill 417 201 283 417 204 283 minecraft:red_terracotta
setblock 417 201 297 minecraft:stripped_oak_log
fill 417 201 298 417 204 298 minecraft:red_terracotta
setblock 417 201 302 minecraft:stripped_oak_log
fill 417 201 303 417 204 303 minecraft:red_terracotta
setblock 417 201 307 minecraft:stripped_oak_log
fill 417 201 308 417 204 308 minecraft:red_terracotta
setblock 417 201 312 minecraft:stripped_oak_log
fill 417 201 313 417 204 313 minecraft:red_terracotta
setblock 377 202 277 minecraft:red_terracotta
setblock 377 202 281 minecraft:stripped_oak_log
fill 377 202 282 377 202 285 minecraft:red_terracotta
setblock 377 202 286 minecraft:stripped_oak_log
fill 377 202 287 377 205 287 minecraft:red_terracotta
setblock 377 202 291 minecraft:stripped_oak_log
fill 377 202 292 377 205 292 minecraft:red_terracotta
setblock 377 202 296 minecraft:stripped_oak_log
fill 377 202 297 377 205 297 minecraft:red_terracotta
setblock 377 202 301 minecraft:stripped_oak_log
fill 377 202 302 377 205 302 minecraft:red_terracotta
setblock 377 202 306 minecraft:stripped_oak_log
fill 377 202 307 377 205 307 minecraft:red_terracotta
setblock 378 202 296 minecraft:red_terracotta
setblock 378 202 300 minecraft:stripped_oak_log
fill 378 202 301 378 205 301 minecraft:red_terracotta
setblock 378 202 305 minecraft:stripped_oak_log
fill 378 202 306 378 205 306 minecraft:red_terracotta
fill 379 202 276 387 202 279 minecraft:stripped_oak_log
fill 388 202 276 388 205 276 minecraft:red_terracotta
fill 388 202 277 388 202 279 minecraft:stripped_oak_log
fill 389 202 278 389 202 279 minecraft:stripped_oak_log
setblock 391 202 277 minecraft:stripped_oak_log
fill 391 202 278 394 202 278 minecraft:red_terracotta
setblock 392 202 276 minecraft:stripped_oak_log
fill 392 202 277 392 205 277 minecraft:red_terracotta
fill 393 202 276 393 205 276 minecraft:red_terracotta
fill 393 202 316 393 205 316 minecraft:red_terracotta
setblock 394 202 279 minecraft:stripped_oak_log
setblock 395 202 278 minecraft:stripped_oak_log
fill 395 202 279 395 204 279 minecraft:red_terracotta
setblock 396 202 277 minecraft:stripped_oak_log
fill 396 202 278 396 205 278 minecraft:red_terracotta
setblock 397 202 276 minecraft:stripped_oak_log
fill 397 202 277 400 202 277 minecraft:red_terracotta
setblock 397 202 316 minecraft:stripped_oak_log
fill 398 202 276 401 202 276 minecraft:red_terracotta
setblock 398 202 316 minecraft:red_terracotta
setblock 401 202 277 minecraft:stripped_oak_log
setblock 402 202 276 minecraft:stripped_oak_log
fill 403 202 276 403 204 276 minecraft:red_terracotta
setblock 407 202 276 minecraft:stripped_oak_log
fill 408 202 276 408 205 276 minecraft:red_terracotta
fill 408 202 316 408 205 316 minecraft:red_terracotta
setblock 411 202 277 minecraft:stripped_oak_log
setblock 412 202 276 minecraft:stripped_oak_log
fill 412 202 277 412 205 277 minecraft:red_terracotta
setblock 412 202 316 minecraft:stripped_oak_log
fill 413 202 276 413 205 276 minecraft:red_terracotta
setblock 413 202 315 minecraft:stripped_oak_log
fill 413 202 316 413 205 316 minecraft:red_terracotta
fill 414 202 315 414 205 315 minecraft:red_terracotta
fill 415 202 299 415 205 299 minecraft:red_terracotta
setblock 415 202 303 minecraft:stripped_oak_log
fill 415 202 304 415 205 304 minecraft:red_terracotta
setblock 416 202 278 minecraft:red_terracotta
setblock 416 202 297 minecraft:stripped_oak_log
fill 416 202 298 416 205 298 minecraft:red_terracotta
setblock 416 202 302 minecraft:stripped_oak_log
fill 416 202 303 416 205 303 minecraft:red_terracotta
setblock 416 202 307 minecraft:stripped_oak_log
fill 416 202 308 416 205 308 minecraft:red_terracotta
setblock 417 202 276 minecraft:stripped_oak_log
fill 417 202 277 417 204 277 minecraft:red_terracotta
setblock 417 202 281 minecraft:stripped_oak_log
fill 417 202 282 417 205 282 minecraft:red_terracotta
setblock 417 202 296 minecraft:stripped_oak_log
fill 417 202 297 417 205 297 minecraft:red_terracotta
setblock 417 202 301 minecraft:stripped_oak_log
fill 417 202 302 417 205 302 minecraft:red_terracotta
setblock 417 202 306 minecraft:stripped_oak_log
fill 417 202 307 417 205 307 minecraft:red_terracotta
setblock 417 202 311 minecraft:stripped_oak_log
fill 417 202 312 417 205 312 minecraft:red_terracotta
setblock 417 202 316 minecraft:stripped_oak_log
fill 418 202 294 418 203 294 minecraft:red_terracotta
fill 377 203 275 382 203 275 minecraft:red_terracotta
setblock 377 203 280 minecraft:stripped_oak_log
fill 377 203 281 377 203 284 minecraft:red_terracotta
setblock 377 203 285 minecraft:stripped_oak_log
fill 377 203 286 377 206 286 minecraft:red_terracotta
setblock 377 203 290 minecraft:stripped_oak_log
fill 377 203 291 377 206 291 minecraft:red_terracotta
setblock 377 203 295 minecraft:stripped_oak_log
fill 377 203 296 377 206 296 minecraft:red_terracotta
setblock 377 203 300 minecraft:stripped_oak_log
fill 377 203 301 377 206 301 minecraft:red_terracotta
setblock 377 203 305 minecraft:stripped_oak_log
fill 377 203 306 377 206 306 minecraft:red_terracotta
setblock 378 203 299 minecraft:stripped_oak_log
fill 378 203 300 378 206 300 minecraft:red_terracotta
setblock 378 203 304 minecraft:stripped_oak_log
fill 378 203 305 378 206 305 minecraft:red_terracotta
setblock 379 203 278 minecraft:light[level=12]
fill 379 203 279 389 203 279 minecraft:orange_terracotta
setblock 379 203 285 minecraft:light[level=12]
setblock 379 203 292 minecraft:light[level=12]
setblock 379 203 299 minecraft:light[level=12]
setblock 379 203 306 minecraft:light[level=12]
setblock 379 203 313 minecraft:light[level=12]
fill 383 203 275 385 206 275 minecraft:shroomlight
fill 386 203 275 418 203 275 minecraft:red_terracotta
setblock 386 203 278 minecraft:light[level=12]
setblock 386 203 285 minecraft:light[level=12]
setblock 386 203 292 minecraft:light[level=12]
setblock 386 203 299 minecraft:light[level=12]
setblock 386 203 306 minecraft:light[level=12]
setblock 386 203 313 minecraft:light[level=12]
setblock 390 203 277 minecraft:stripped_oak_log
fill 390 203 278 393 203 278 minecraft:red_terracotta
setblock 391 203 276 minecraft:stripped_oak_log
fill 391 203 277 391 206 277 minecraft:red_terracotta
fill 392 203 276 392 206 276 minecraft:red_terracotta
setblock 392 203 279 minecraft:red_terracotta
setblock 393 203 279 minecraft:stripped_oak_log
setblock 393 203 285 minecraft:light[level=12]
setblock 393 203 292 minecraft:light[level=12]
setblock 393 203 299 minecraft:light[level=12]
setblock 393 203 306 minecraft:light[level=12]
setblock 393 203 313 minecraft:light[level=12]
setblock 394 203 278 minecraft:stripped_oak_log
fill 394 203 279 394 206 279 minecraft:red_terracotta
setblock 395 203 277 minecraft:stripped_oak_log
fill 395 203 278 395 206 278 minecraft:red_terracotta
setblock 396 203 276 minecraft:stripped_oak_log
fill 396 203 277 399 203 277 minecraft:red_terracotta
setblock 396 203 316 minecraft:stripped_oak_log
fill 397 203 276 400 203 276 minecraft:red_terracotta
fill 397 203 316 397 206 316 minecraft:red_terracotta
setblock 400 203 277 minecraft:stripped_oak_log
setblock 400 203 278 minecraft:light[level=12]
setblock 400 203 285 minecraft:light[level=12]
setblock 400 203 292 minecraft:light[level=12]
setblock 400 203 299 minecraft:light[level=12]
setblock 400 203 313 minecraft:light[level=12]
setblock 401 203 276 minecraft:stripped_oak_log
fill 402 203 276 402 206 276 minecraft:red_terracotta
setblock 406 203 276 minecraft:stripped_oak_log
fill 407 203 276 407 206 276 minecraft:red_terracotta
setblock 407 203 278 minecraft:light[level=12]
setblock 407 203 285 minecraft:light[level=12]
setblock 407 203 292 minecraft:light[level=12]
setblock 407 203 299 minecraft:light[level=12]
setblock 407 203 306 minecraft:light[level=12]
setblock 407 203 313 minecraft:light[level=12]
setblock 410 203 277 minecraft:stripped_oak_log
setblock 411 203 276 minecraft:stripped_oak_log
fill 411 203 277 411 206 277 minecraft:red_terracotta
setblock 411 203 316 minecraft:stripped_oak_log
fill 412 203 276 412 206 276 minecraft:red_terracotta
setblock 412 203 315 minecraft:stripped_oak_log
fill 412 203 316 412 206 316 minecraft:red_terracotta
fill 413 203 315 413 206 315 minecraft:red_terracotta
setblock 414 203 278 minecraft:light[level=12]
setblock 414 203 285 minecraft:light[level=12]
setblock 414 203 292 minecraft:light[level=12]
setblock 414 203 299 minecraft:light[level=12]
setblock 414 203 303 minecraft:stripped_oak_log
fill 414 203 304 414 206 304 minecraft:red_terracotta
setblock 414 203 306 minecraft:light[level=12]
setblock 414 203 313 minecraft:light[level=12]
setblock 415 203 302 minecraft:stripped_oak_log
fill 415 203 303 415 206 303 minecraft:red_terracotta
setblock 415 203 307 minecraft:stripped_oak_log
fill 415 203 308 415 206 308 minecraft:red_terracotta
setblock 416 203 276 minecraft:stripped_oak_log
fill 416 203 297 416 204 297 minecraft:red_terracotta
setblock 416 203 301 minecraft:stripped_oak_log
fill 416 203 302 416 206 302 minecraft:red_terracotta
setblock 416 203 306 minecraft:stripped_oak_log
fill 416 203 307 416 206 307 minecraft:red_terracotta
setblock 416 203 311 minecraft:stripped_oak_log
setblock 416 203 316 minecraft:stripped_oak_log
setblock 417 203 276 minecraft:red_terracotta
setblock 417 203 280 minecraft:stripped_oak_log
fill 417 203 281 417 206 281 minecraft:red_terracotta
setblock 417 203 285 minecraft:stripped_oak_log
setblock 417 203 295 minecraft:stripped_oak_log
fill 417 203 296 417 206 296 minecraft:red_terracotta
setblock 417 203 300 minecraft:stripped_oak_log
fill 417 203 301 417 206 301 minecraft:red_terracotta
setblock 417 203 305 minecraft:stripped_oak_log
fill 417 203 306 417 206 306 minecraft:red_terracotta
setblock 417 203 310 minecraft:stripped_oak_log
fill 417 203 311 417 206 311 minecraft:red_terracotta
setblock 417 203 315 minecraft:stripped_oak_log
setblock 417 203 316 minecraft:red_terracotta
fill 376 204 275 376 207 317 minecraft:yellow_terracotta
fill 377 204 275 382 207 275 minecraft:yellow_terracotta
setblock 377 204 279 minecraft:stripped_oak_log
fill 377 204 280 377 204 283 minecraft:red_terracotta
setblock 377 204 284 minecraft:stripped_oak_log
fill 377 204 285 377 207 285 minecraft:red_terracotta
setblock 377 204 289 minecraft:stripped_oak_log
fill 377 204 290 377 207 290 minecraft:red_terracotta
setblock 377 204 294 minecraft:stripped_oak_log
fill 377 204 295 377 207 295 minecraft:red_terracotta
setblock 377 204 299 minecraft:stripped_oak_log
fill 377 204 300 377 207 300 minecraft:red_terracotta
setblock 377 204 304 minecraft:stripped_oak_log
fill 377 204 305 377 207 305 minecraft:red_terracotta
setblock 377 204 309 minecraft:stripped_oak_log
fill 377 204 317 418 207 317 minecraft:yellow_terracotta
setblock 378 204 298 minecraft:stripped_oak_log
fill 378 204 299 378 206 299 minecraft:red_terracotta
setblock 378 204 303 minecraft:stripped_oak_log
fill 378 204 304 378 207 304 minecraft:red_terracotta
setblock 379 204 279 minecraft:stripped_oak_log
setblock 384 204 279 minecraft:stripped_oak_log
fill 386 204 275 418 207 275 minecraft:yellow_terracotta
fill 387 204 276 387 206 276 minecraft:red_terracotta
setblock 388 204 277 minecraft:red_terracotta
setblock 389 204 277 minecraft:stripped_oak_log
setblock 389 204 279 minecraft:stripped_oak_log
setblock 390 204 276 minecraft:stripped_oak_log
fill 390 204 277 390 206 278 minecraft:red_terracotta
fill 391 204 276 391 207 276 minecraft:red_terracotta
fill 391 204 278 392 204 278 minecraft:red_terracotta
setblock 392 204 279 minecraft:stripped_oak_log
fill 392 204 316 392 206 316 minecraft:red_terracotta
setblock 393 204 278 minecraft:stripped_oak_log
fill 393 204 279 393 207 279 minecraft:red_terracotta
setblock 394 204 277 minecraft:stripped_oak_log
fill 394 204 278 394 207 278 minecraft:red_terracotta
setblock 395 204 276 minecraft:stripped_oak_log
fill 395 204 277 398 204 277 minecraft:red_terracotta
setblock 395 204 316 minecraft:stripped_oak_log
fill 396 204 276 399 204 276 minecraft:red_terracotta
fill 396 204 316 396 207 316 minecraft:red_terracotta
setblock 399 204 277 minecraft:stripped_oak_log
setblock 400 204 276 minecraft:stripped_oak_log
fill 401 204 276 401 207 276 minecraft:red_terracotta
setblock 405 204 276 minecraft:stripped_oak_log
fill 406 204 276 406 207 276 minecraft:red_terracotta
fill 407 204 316 407 206 316 minecraft:red_terracotta
setblock 410 204 276 minecraft:stripped_oak_log
fill 410 204 277 410 207 277 minecraft:red_terracotta
setblock 410 204 316 minecraft:stripped_oak_log
fill 411 204 276 411 207 276 minecraft:red_terracotta
setblock 411 204 315 minecraft:stripped_oak_log
fill 411 204 316 411 207 316 minecraft:red_terracotta
fill 412 204 315 412 207 315 minecraft:red_terracotta
setblock 414 204 302 minecraft:stripped_oak_log
fill 414 204 303 414 207 303 minecraft:red_terracotta
fill 414 204 305 414 204 306 minecraft:red_terracotta
setblock 415 204 276 minecraft:stripped_oak_log
setblock 415 204 301 minecraft:stripped_oak_log
fill 415 204 302 415 207 302 minecraft:red_terracotta
setblock 415 204 306 minecraft:stripped_oak_log
fill 415 204 307 415 207 307 minecraft:red_terracotta
fill 415 204 309 415 205 309 minecraft:red_terracotta
setblock 415 204 316 minecraft:stripped_oak_log
setblock 416 204 276 minecraft:red_terracotta
setblock 416 204 300 minecraft:stripped_oak_log
fill 416 204 301 416 207 301 minecraft:red_terracotta
setblock 416 204 305 minecraft:stripped_oak_log
fill 416 204 306 416 207 306 minecraft:red_terracotta
setblock 416 204 310 minecraft:stripped_oak_log
fill 416 204 311 416 207 311 minecraft:red_terracotta
fill 416 204 316 416 207 316 minecraft:red_terracotta
setblock 417 204 279 minecraft:stripped_oak_log
fill 417 204 280 417 207 280 minecraft:red_terracotta
setblock 417 204 284 minecraft:stripped_oak_log
fill 417 204 285 417 206 286 minecraft:red_terracotta
fill 417 204 295 417 207 295 minecraft:red_terracotta
setblock 417 204 299 minecraft:stripped_oak_log
fill 417 204 300 417 207 300 minecraft:red_terracotta
setblock 417 204 304 minecraft:stripped_oak_log
fill 417 204 305 417 207 305 minecraft:red_terracotta
setblock 417 204 309 minecraft:stripped_oak_log
fill 417 204 310 417 207 310 minecraft:red_terracotta
setblock 417 204 314 minecraft:stripped_oak_log
fill 418 204 276 418 207 316 minecraft:yellow_terracotta
setblock 377 205 278 minecraft:stripped_oak_log
fill 377 205 279 377 205 282 minecraft:red_terracotta
setblock 377 205 283 minecraft:stripped_oak_log
fill 377 205 284 378 207 284 minecraft:red_terracotta
setblock 377 205 288 minecraft:stripped_oak_log
fill 377 205 289 377 208 289 minecraft:red_terracotta
setblock 377 205 293 minecraft:stripped_oak_log
fill 377 205 294 377 208 294 minecraft:red_terracotta
setblock 377 205 298 minecraft:stripped_oak_log
fill 377 205 299 377 208 299 minecraft:red_terracotta
setblock 377 205 303 minecraft:stripped_oak_log
fill 377 205 304 377 208 304 minecraft:red_terracotta
setblock 377 205 308 minecraft:stripped_oak_log
fill 377 205 309 377 207 310 minecraft:red_terracotta
fill 377 205 311 378 205 312 minecraft:orange_terracotta
setblock 378 205 282 minecraft:stripped_oak_log
fill 378 205 283 378 208 283 minecraft:red_terracotta
fill 378 205 285 378 205 286 minecraft:red_terracotta
setblock 378 205 298 minecraft:red_terracotta
setblock 378 205 302 minecraft:stripped_oak_log
fill 378 205 303 378 208 303 minecraft:red_terracotta
setblock 378 205 307 minecraft:orange_terracotta
fill 378 205 313 382 205 313 minecraft:orange_terracotta
fill 379 205 291 381 205 293 minecraft:terracotta
fill 379 205 305 383 205 306 minecraft:orange_terracotta
fill 379 205 312 383 205 312 minecraft:orange_terracotta
setblock 380 205 304 minecraft:orange_terracotta
fill 382 205 307 384 205 307 minecraft:orange_terracotta
fill 382 205 311 384 205 311 minecraft:orange_terracotta
fill 383 205 308 384 205 310 minecraft:orange_terracotta
fill 384 205 283 386 205 286 minecraft:orange_terracotta
fill 385 205 282 388 205 282 minecraft:orange_terracotta
fill 385 205 287 387 205 288 minecraft:orange_terracotta
fill 386 205 281 392 205 281 minecraft:orange_terracotta
fill 386 205 289 392 205 289 minecraft:orange_terracotta
fill 387 205 280 391 205 280 minecraft:orange_terracotta
setblock 388 205 277 minecraft:stripped_oak_log
fill 388 205 288 393 205 288 minecraft:orange_terracotta
fill 388 205 290 390 205 290 minecraft:orange_terracotta
setblock 389 205 276 minecraft:stripped_oak_log
fill 389 205 277 389 207 278 minecraft:red_terracotta
fill 390 205 276 390 208 276 minecraft:red_terracotta
fill 390 205 282 393 205 282 minecraft:orange_terracotta
setblock 391 205 278 minecraft:red_terracotta
setblock 391 205 279 minecraft:stripped_oak_log
fill 391 205 287 393 205 287 minecraft:orange_terracotta
fill 391 205 316 391 207 316 minecraft:red_terracotta
setblock 392 205 278 minecraft:stripped_oak_log
fill 392 205 279 392 208 279 minecraft:red_terracotta
fill 392 205 283 394 205 286 minecraft:orange_terracotta
setblock 393 205 277 minecraft:stripped_oak_log
fill 393 205 278 393 208 278 minecraft:red_terracotta
setblock 394 205 276 minecraft:stripped_oak_log
fill 394 205 277 397 205 277 minecraft:red_terracotta
fill 394 205 306 396 205 310 minecraft:orange_terracotta
setblock 394 205 316 minecraft:stripped_oak_log
fill 395 205 276 398 205 276 minecraft:red_terracotta
fill 395 205 305 403 205 305 minecraft:orange_terracotta
fill 395 205 311 397 205 312 minecraft:orange_terracotta
fill 395 205 316 395 208 316 minecraft:red_terracotta
fill 396 205 304 402 205 304 minecraft:orange_terracotta
fill 396 205 313 402 205 313 minecraft:orange_terracotta
setblock 397 205 278 minecraft:stripped_oak_log
fill 397 205 306 397 207 306 minecraft:orange_terracotta
setblock 398 205 277 minecraft:stripped_oak_log
fill 398 205 303 401 205 303 minecraft:orange_terracotta
fill 398 205 312 403 205 312 minecraft:orange_terracotta
setblock 399 205 276 minecraft:stripped_oak_log
setblock 399 205 277 minecraft:red_terracotta
fill 399 205 314 400 205 314 minecraft:orange_terracotta
fill 400 205 276 400 208 276 minecraft:red_terracotta
fill 401 205 306 404 205 306 minecraft:orange_terracotta
fill 401 205 311 404 205 311 minecraft:orange_terracotta
fill 402 205 307 404 205 307 minecraft:orange_terracotta
fill 402 205 310 404 205 310 minecraft:orange_terracotta
fill 403 205 308 404 205 309 minecraft:orange_terracotta
fill 405 205 276 405 208 276 minecraft:red_terracotta
fill 406 205 316 406 207 316 minecraft:red_terracotta
setblock 409 205 276 minecraft:stripped_oak_log
setblock 409 205 316 minecraft:stripped_oak_log
fill 410 205 276 410 208 276 minecraft:red_terracotta
setblock 410 205 315 minecraft:stripped_oak_log
fill 410 205 316 410 208 316 minecraft:red_terracotta
fill 411 205 315 411 208 315 minecraft:red_terracotta
setblock 413 205 277 minecraft:stripped_oak_log
setblock 414 205 276 minecraft:stripped_oak_log
fill 414 205 302 414 208 302 minecraft:red_terracotta
setblock 414 205 305 minecraft:red_terracotta
setblock 414 205 306 minecraft:stripped_oak_log
fill 414 205 307 414 208 307 minecraft:red_terracotta
setblock 414 205 316 minecraft:stripped_oak_log
fill 415 205 276 415 206 276 minecraft:red_terracotta
setblock 415 205 300 minecraft:stripped_oak_log
fill 415 205 301 415 208 301 minecraft:red_terracotta
setblock 415 205 305 minecraft:stripped_oak_log
fill 415 205 306 415 208 306 minecraft:red_terracotta
setblock 415 205 310 minecraft:stripped_oak_log
fill 415 205 316 415 208 316 minecraft:red_terracotta
fill 416 205 282 416 205 283 minecraft:red_terracotta
setblock 416 205 299 minecraft:stripped_oak_log
fill 416 205 300 416 208 300 minecraft:red_terracotta
setblock 416 205 304 minecraft:stripped_oak_log
fill 416 205 305 416 208 305 minecraft:red_terracotta
setblock 416 205 309 minecraft:stripped_oak_log
fill 416 205 310 416 208 310 minecraft:red_terracotta
fill 416 205 312 416 206 312 minecraft:red_terracotta
setblock 417 205 278 minecraft:stripped_oak_log
fill 417 205 279 417 206 279 minecraft:red_terracotta
setblock 417 205 283 minecraft:stripped_oak_log
fill 417 205 284 417 208 284 minecraft:red_terracotta
setblock 417 205 287 minecraft:red_terracotta
setblock 417 205 298 minecraft:stripped_oak_log
fill 417 205 299 417 208 299 minecraft:red_terracotta
setblock 417 205 303 minecraft:stripped_oak_log
fill 417 205 304 417 208 304 minecraft:red_terracotta
setblock 417 205 308 minecraft:stripped_oak_log
fill 417 205 309 417 208 309 minecraft:red_terracotta
setblock 417 205 313 minecraft:stripped_oak_log
fill 417 205 314 417 208 314 minecraft:red_terracotta
fill 377 206 279 377 206 281 minecraft:red_terracotta
setblock 377 206 282 minecraft:stripped_oak_log
fill 377 206 283 377 208 283 minecraft:red_terracotta
setblock 377 206 287 minecraft:stripped_oak_log
fill 377 206 288 378 208 288 minecraft:red_terracotta
setblock 377 206 292 minecraft:stripped_oak_log
fill 377 206 293 377 208 293 minecraft:red_terracotta
setblock 377 206 297 minecraft:stripped_oak_log
fill 377 206 298 377 208 298 minecraft:red_terracotta
setblock 377 206 302 minecraft:stripped_oak_log
fill 377 206 303 377 208 303 minecraft:red_terracotta
setblock 377 206 307 minecraft:stripped_oak_log
fill 377 206 308 377 208 308 minecraft:red_terracotta
fill 377 206 311 378 206 311 minecraft:orange_terracotta
fill 378 206 282 378 208 282 minecraft:red_terracotta
setblock 378 206 285 minecraft:red_terracotta
setblock 378 206 286 minecraft:stripped_oak_log
fill 378 206 287 378 208 287 minecraft:red_terracotta
setblock 378 206 301 minecraft:stripped_oak_log
fill 378 206 302 378 208 302 minecraft:red_terracotta
setblock 378 206 306 minecraft:stripped_oak_log
fill 378 206 307 378 208 307 minecraft:red_terracotta
fill 378 206 312 382 206 312 minecraft:orange_terracotta
fill 379 206 305 381 206 306 minecraft:orange_terracotta
fill 380 206 292 380 212 292 minecraft:green_concrete
fill 382 206 306 382 206 307 minecraft:orange_terracotta
fill 382 206 311 383 206 311 minecraft:orange_terracotta
fill 383 206 307 383 206 310 minecraft:orange_terracotta
fill 384 206 308 384 206 309 minecraft:orange_terracotta
fill 385 206 283 386 206 286 minecraft:orange_terracotta
fill 386 206 276 386 207 276 minecraft:red_terracotta
fill 386 206 282 388 206 282 minecraft:orange_terracotta
fill 386 206 287 387 206 288 minecraft:orange_terracotta
setblock 387 206 277 minecraft:stripped_oak_log
fill 387 206 281 391 206 281 minecraft:orange_terracotta
setblock 388 206 276 minecraft:stripped_oak_log
fill 388 206 277 388 208 278 minecraft:red_terracotta
fill 388 206 288 390 206 289 minecraft:orange_terracotta
fill 389 206 276 389 208 276 minecraft:red_terracotta
setblock 390 206 279 minecraft:stripped_oak_log
fill 390 206 282 392 206 282 minecraft:orange_terracotta
fill 390 206 316 390 208 316 minecraft:red_terracotta
setblock 391 206 278 minecraft:stripped_oak_log
fill 391 206 279 391 208 279 minecraft:red_terracotta
fill 391 206 287 392 206 288 minecraft:orange_terracotta
setblock 392 206 277 minecraft:stripped_oak_log
fill 392 206 278 392 208 278 minecraft:red_terracotta
fill 392 206 283 393 206 286 minecraft:orange_terracotta
setblock 393 206 276 minecraft:stripped_oak_log
fill 393 206 277 396 206 277 minecraft:red_terracotta
setblock 393 206 316 minecraft:stripped_oak_log
fill 394 206 276 397 206 276 minecraft:red_terracotta
fill 394 206 316 394 208 316 minecraft:red_terracotta
fill 395 206 306 396 206 310 minecraft:orange_terracotta
setblock 396 206 278 minecraft:stripped_oak_log
fill 396 206 305 402 206 305 minecraft:orange_terracotta
fill 396 206 311 397 206 311 minecraft:orange_terracotta
setblock 397 206 277 minecraft:stripped_oak_log
fill 397 206 312 402 206 312 minecraft:orange_terracotta
setblock 398 206 276 minecraft:stripped_oak_log
setblock 398 206 277 minecraft:red_terracotta
fill 398 206 304 401 206 304 minecraft:orange_terracotta
fill 398 206 313 400 206 313 minecraft:orange_terracotta
fill 399 206 276 399 208 276 minecraft:red_terracotta
fill 401 206 306 403 206 306 minecraft:orange_terracotta
fill 401 206 311 403 206 311 minecraft:orange_terracotta
fill 402 206 307 403 206 307 minecraft:orange_terracotta
fill 402 206 310 403 206 310 minecraft:orange_terracotta
fill 403 206 308 403 207 309 minecraft:orange_terracotta
fill 404 206 276 404 208 276 minecraft:red_terracotta
fill 405 206 316 405 208 316 minecraft:red_terracotta
setblock 408 206 276 minecraft:stripped_oak_log
setblock 408 206 315 minecraft:red_terracotta
setblock 408 206 316 minecraft:stripped_oak_log
fill 409 206 276 409 208 277 minecraft:red_terracotta
setblock 409 206 315 minecraft:stripped_oak_log
fill 409 206 316 409 208 316 minecraft:red_terracotta
fill 410 206 315 410 208 315 minecraft:red_terracotta
setblock 412 206 277 minecraft:stripped_oak_log
setblock 413 206 276 minecraft:stripped_oak_log
setblock 413 206 316 minecraft:stripped_oak_log
fill 414 206 276 414 208 276 minecraft:red_terracotta
setblock 414 206 305 minecraft:stripped_oak_log
fill 414 206 306 414 208 306 minecraft:red_terracotta
fill 414 206 308 414 206 309 minecraft:red_terracotta
setblock 414 206 315 minecraft:stripped_oak_log
fill 414 206 316 414 208 316 minecraft:red_terracotta
fill 415 206 300 415 208 300 minecraft:red_terracotta
setblock 415 206 304 minecraft:stripped_oak_log
fill 415 206 305 415 208 305 minecraft:red_terracotta
setblock 415 206 309 minecraft:stripped_oak_log
fill 415 206 310 415 208 310 minecraft:red_terracotta
setblock 416 206 282 minecraft:red_terracotta
setblock 416 206 283 minecraft:stripped_oak_log
fill 416 206 284 416 208 285 minecraft:red_terracotta
setblock 416 206 298 minecraft:stripped_oak_log
fill 416 206 299 416 208 299 minecraft:red_terracotta
setblock 416 206 303 minecraft:stripped_oak_log
fill 416 206 304 416 208 304 minecraft:red_terracotta
setblock 416 206 308 minecraft:stripped_oak_log
fill 416 206 309 416 208 309 minecraft:red_terracotta
setblock 417 206 282 minecraft:stripped_oak_log
fill 417 206 283 417 208 283 minecraft:red_terracotta
setblock 417 206 287 minecraft:stripped_oak_log
fill 417 206 288 417 208 289 minecraft:red_terracotta
setblock 417 206 297 minecraft:stripped_oak_log
fill 417 206 298 417 208 298 minecraft:red_terracotta
setblock 417 206 302 minecraft:stripped_oak_log
fill 417 206 303 417 208 303 minecraft:red_terracotta
setblock 417 206 307 minecraft:stripped_oak_log
fill 417 206 308 417 208 308 minecraft:red_terracotta
setblock 417 206 312 minecraft:stripped_oak_log
fill 417 206 313 417 208 313 minecraft:red_terracotta
fill 377 207 279 377 207 280 minecraft:red_terracotta
setblock 377 207 281 minecraft:stripped_oak_log
fill 377 207 282 377 208 282 minecraft:red_terracotta
setblock 377 207 286 minecraft:stripped_oak_log
fill 377 207 287 377 208 287 minecraft:red_terracotta
setblock 377 207 291 minecraft:stripped_oak_log
fill 377 207 292 377 208 292 minecraft:red_terracotta
setblock 377 207 296 minecraft:stripped_oak_log
fill 377 207 297 377 208 297 minecraft:red_terracotta
setblock 377 207 301 minecraft:stripped_oak_log
fill 377 207 302 377 208 302 minecraft:red_terracotta
setblock 377 207 306 minecraft:stripped_oak_log
fill 377 207 307 377 208 307 minecraft:red_terracotta
setblock 377 207 311 minecraft:stripped_oak_log
setblock 378 207 285 minecraft:stripped_oak_log
fill 378 207 286 378 208 286 minecraft:red_terracotta
setblock 378 207 289 minecraft:red_terracotta
setblock 378 207 300 minecraft:stripped_oak_log
fill 378 207 301 378 208 301 minecraft:red_terracotta
setblock 378 207 305 minecraft:stripped_oak_log
fill 378 207 306 378 208 306 minecraft:red_terracotta
setblock 378 207 311 minecraft:orange_terracotta
setblock 379 207 278 minecraft:light[level=15]
setblock 379 207 286 minecraft:light[level=15]
setblock 379 207 294 minecraft:light[level=15]
setblock 379 207 302 minecraft:light[level=15]
fill 379 207 306 381 207 306 minecraft:orange_terracotta
setblock 380 207 312 minecraft:orange_terracotta
setblock 382 207 307 minecraft:orange_terracotta
setblock 382 207 311 minecraft:orange_terracotta
fill 383 207 275 385 207 275 minecraft:yellow_terracotta
fill 383 207 308 383 207 310 minecraft:orange_terracotta
fill 385 207 276 385 208 276 minecraft:red_terracotta
fill 386 207 283 386 207 286 minecraft:orange_terracotta
setblock 387 207 276 minecraft:stripped_oak_log
fill 387 207 277 387 208 277 minecraft:red_terracotta
setblock 387 207 278 minecraft:light[level=15]
fill 387 207 282 388 207 282 minecraft:orange_terracotta
setblock 387 207 287 minecraft:orange_terracotta
setblock 387 207 294 minecraft:light[level=15]
setblock 387 207 302 minecraft:light[level=15]
setblock 387 207 310 minecraft:light[level=15]
fill 388 207 276 388 208 276 minecraft:red_terracotta
fill 388 207 288 390 207 288 minecraft:orange_terracotta
fill 389 207 316 389 208 316 minecraft:red_terracotta
setblock 390 207 277 minecraft:red_terracotta
setblock 390 207 278 minecraft:stripped_oak_log
fill 390 207 279 390 208 279 minecraft:red_terracotta
fill 390 207 282 391 207 282 minecraft:orange_terracotta
setblock 391 207 277 minecraft:stripped_oak_log
fill 391 207 278 391 208 278 minecraft:red_terracotta
setblock 391 207 287 minecraft:orange_terracotta
setblock 392 207 276 minecraft:stripped_oak_log
fill 392 207 277 395 207 277 minecraft:red_terracotta
fill 392 207 283 392 207 286 minecraft:orange_terracotta
setblock 392 207 316 minecraft:stripped_oak_log
fill 393 207 276 396 207 276 minecraft:red_terracotta
fill 393 207 316 393 208 316 minecraft:red_terracotta
setblock 395 207 278 minecraft:stripped_oak_log
setblock 395 207 286 minecraft:light[level=15]
setblock 395 207 294 minecraft:light[level=15]
setblock 395 207 302 minecraft:light[level=15]
setblock 395 207 310 minecraft:light[level=15]
setblock 396 207 277 minecraft:stripped_oak_log
fill 396 207 307 396 207 310 minecraft:orange_terracotta
setblock 397 207 276 minecraft:stripped_oak_log
fill 397 207 277 397 208 277 minecraft:red_terracotta
setblock 397 207 311 minecraft:orange_terracotta
setblock 397 207 316 minecraft:stripped_oak_log
fill 398 207 276 398 208 276 minecraft:red_terracotta
fill 398 207 305 401 207 305 minecraft:orange_terracotta
fill 398 207 312 400 207 312 minecraft:orange_terracotta
fill 398 207 316 398 208 316 minecraft:red_terracotta
fill 401 207 306 402 207 306 minecraft:orange_terracotta
fill 401 207 311 402 207 311 minecraft:orange_terracotta
setblock 402 207 307 minecraft:orange_terracotta
setblock 402 207 310 minecraft:orange_terracotta
setblock 403 207 278 minecraft:light[level=15]
setblock 403 207 286 minecraft:light[level=15]
setblock 403 207 294 minecraft:light[level=15]
setblock 403 207 302 minecraft:light[level=15]
setblock 403 207 310 minecraft:light[level=15]
fill 404 207 316 404 208 316 minecraft:red_terracotta
setblock 407 207 276 minecraft:stripped_oak_log
setblock 407 207 315 minecraft:red_terracotta
setblock 407 207 316 minecraft:stripped_oak_log
fill 408 207 276 408 208 276 minecraft:red_terracotta
setblock 408 207 315 minecraft:stripped_oak_log
fill 408 207 316 408 208 316 minecraft:red_terracotta
fill 409 207 315 409 208 315 minecraft:red_terracotta
fill 410 207 314 411 208 314 minecraft:red_terracotta
setblock 411 207 277 minecraft:stripped_oak_log
setblock 411 207 278 minecraft:light[level=15]
setblock 411 207 286 minecraft:light[level=15]
setblock 411 207 294 minecraft:light[level=15]
setblock 411 207 302 minecraft:light[level=15]
setblock 411 207 310 minecraft:light[level=15]
setblock 412 207 276 minecraft:stripped_oak_log
setblock 412 207 316 minecraft:stripped_oak_log
fill 413 207 276 413 208 276 minecraft:red_terracotta
setblock 413 207 305 minecraft:stripped_oak_log
fill 413 207 306 413 208 306 minecraft:red_terracotta
setblock 413 207 315 minecraft:stripped_oak_log
fill 413 207 316 413 208 316 minecraft:red_terracotta
setblock 414 207 304 minecraft:stripped_oak_log
fill 414 207 305 414 208 305 minecraft:red_terracotta
setblock 414 207 308 minecraft:red_terracotta
setblock 414 207 309 minecraft:stripped_oak_log
fill 414 207 315 414 208 315 minecraft:red_terracotta
setblock 415 207 303 minecraft:stripped_oak_log
fill 415 207 304 415 208 304 minecraft:red_terracotta
setblock 415 207 308 minecraft:stripped_oak_log
fill 415 207 309 415 208 309 minecraft:red_terracotta
fill 415 207 311 415 208 311 minecraft:red_terracotta
setblock 416 207 282 minecraft:stripped_oak_log
fill 416 207 283 416 208 283 minecraft:red_terracotta
setblock 416 207 286 minecraft:red_terracotta
setblock 416 207 287 minecraft:stripped_oak_log
fill 416 207 298 416 208 298 minecraft:red_terracotta
setblock 416 207 302 minecraft:stripped_oak_log
fill 416 207 303 416 208 303 minecraft:red_terracotta
setblock 416 207 307 minecraft:stripped_oak_log
fill 416 207 308 416 208 308 minecraft:red_terracotta
setblock 416 207 312 minecraft:stripped_oak_log
setblock 417 207 281 minecraft:stripped_oak_log
fill 417 207 282 417 208 282 minecraft:red_terracotta
setblock 417 207 285 minecraft:red_terracotta
setblock 417 207 286 minecraft:stripped_oak_log
fill 417 207 287 417 208 287 minecraft:red_terracotta
setblock 417 207 290 minecraft:red_terracotta
setblock 417 207 291 minecraft:stripped_oak_log
fill 417 207 292 417 208 294 minecraft:red_terracotta
setblock 417 207 296 minecraft:stripped_oak_log
fill 417 207 297 417 208 297 minecraft:red_terracotta
setblock 417 207 301 minecraft:stripped_oak_log
fill 417 207 302 417 208 302 minecraft:red_terracotta
setblock 417 207 306 minecraft:stripped_oak_log
fill 417 207 307 417 208 307 minecraft:red_terracotta
setblock 417 207 311 minecraft:stripped_oak_log
fill 417 207 312 417 208 312 minecraft:red_terracotta
fill 376 208 275 376 211 317 minecraft:white_terracotta
fill 377 208 275 418 211 275 minecraft:white_terracotta
setblock 377 208 279 minecraft:red_terracotta
setblock 377 208 280 minecraft:stripped_oak_log
setblock 377 208 281 minecraft:red_terracotta
setblock 377 208 284 minecraft:red_terracotta
setblock 377 208 285 minecraft:stripped_oak_log
setblock 377 208 286 minecraft:red_terracotta
setblock 377 208 290 minecraft:stripped_oak_log
setblock 377 208 291 minecraft:red_terracotta
setblock 377 208 295 minecraft:stripped_oak_log
setblock 377 208 296 minecraft:red_terracotta
setblock 377 208 300 minecraft:stripped_oak_log
setblock 377 208 301 minecraft:red_terracotta
setblock 377 208 305 minecraft:stripped_oak_log
setblock 377 208 306 minecraft:red_terracotta
setblock 377 208 309 minecraft:red_terracotta
setblock 377 208 310 minecraft:stripped_oak_log
setblock 377 208 311 minecraft:red_terracotta
fill 377 208 317 418 211 317 minecraft:white_terracotta
setblock 378 208 284 minecraft:stripped_oak_log
setblock 378 208 285 minecraft:red_terracotta
setblock 378 208 289 minecraft:stripped_oak_log
setblock 378 208 290 minecraft:red_terracotta
setblock 378 208 304 minecraft:stripped_oak_log
setblock 378 208 305 minecraft:red_terracotta
setblock 386 208 276 minecraft:stripped_oak_log
setblock 386 208 277 minecraft:red_terracotta
setblock 387 208 276 minecraft:red_terracotta
setblock 388 208 316 minecraft:red_terracotta
setblock 389 208 277 minecraft:red_terracotta
setblock 389 208 278 minecraft:stripped_oak_log
setblock 389 208 279 minecraft:red_terracotta
setblock 390 208 277 minecraft:stripped_oak_log
setblock 390 208 278 minecraft:red_terracotta
setblock 391 208 276 minecraft:stripped_oak_log
fill 391 208 277 394 208 277 minecraft:red_terracotta
setblock 391 208 315 minecraft:red_terracotta
setblock 391 208 316 minecraft:stripped_oak_log
fill 392 208 276 395 208 276 minecraft:red_terracotta
setblock 392 208 315 minecraft:stripped_oak_log
setblock 392 208 316 minecraft:red_terracotta
setblock 393 208 315 minecraft:red_terracotta
setblock 394 208 278 minecraft:stripped_oak_log
setblock 395 208 277 minecraft:stripped_oak_log
setblock 395 208 278 minecraft:red_terracotta
setblock 396 208 276 minecraft:stripped_oak_log
setblock 396 208 277 minecraft:red_terracotta
setblock 396 208 316 minecraft:stripped_oak_log
setblock 397 208 276 minecraft:red_terracotta
setblock 397 208 316 minecraft:red_terracotta
fill 402 208 316 403 208 316 minecraft:red_terracotta
setblock 403 208 276 minecraft:red_terracotta
setblock 406 208 276 minecraft:stripped_oak_log
setblock 406 208 315 minecraft:red_terracotta
setblock 406 208 316 minecraft:stripped_oak_log
setblock 407 208 276 minecraft:red_terracotta
setblock 407 208 315 minecraft:stripped_oak_log
setblock 407 208 316 minecraft:red_terracotta
setblock 408 208 314 minecraft:stripped_oak_log
setblock 408 208 315 minecraft:red_terracotta
setblock 409 208 314 minecraft:red_terracotta
setblock 410 208 277 minecraft:stripped_oak_log
setblock 411 208 276 minecraft:stripped_oak_log
setblock 411 208 316 minecraft:stripped_oak_log
setblock 412 208 276 minecraft:red_terracotta
setblock 412 208 314 minecraft:red_terracotta
setblock 412 208 315 minecraft:stripped_oak_log
setblock 412 208 316 minecraft:red_terracotta
setblock 413 208 305 minecraft:red_terracotta
setblock 413 208 307 minecraft:red_terracotta
setblock 413 208 315 minecraft:red_terracotta
setblock 414 208 303 minecraft:stripped_oak_log
setblock 414 208 304 minecraft:red_terracotta
setblock 414 208 308 minecraft:stripped_oak_log
fill 414 208 309 414 208 310 minecraft:red_terracotta
setblock 415 208 302 minecraft:stripped_oak_log
setblock 415 208 303 minecraft:red_terracotta
setblock 415 208 307 minecraft:stripped_oak_log
setblock 415 208 308 minecraft:red_terracotta
setblock 416 208 286 minecraft:stripped_oak_log
fill 416 208 287 416 208 288 minecraft:red_terracotta
setblock 416 208 301 minecraft:stripped_oak_log
setblock 416 208 302 minecraft:red_terracotta
setblock 416 208 306 minecraft:stripped_oak_log
setblock 416 208 307 minecraft:red_terracotta
setblock 416 208 311 minecraft:stripped_oak_log
fill 416 208 312 416 208 313 minecraft:red_terracotta
setblock 417 208 281 minecraft:red_terracotta
setblock 417 208 285 minecraft:stripped_oak_log
setblock 417 208 286 minecraft:red_terracotta
setblock 417 208 290 minecraft:stripped_oak_log
setblock 417 208 291 minecraft:red_terracotta
setblock 417 208 295 minecraft:stripped_oak_log
setblock 417 208 296 minecraft:red_terracotta
setblock 417 208 300 minecraft:stripped_oak_log
setblock 417 208 301 minecraft:red_terracotta
setblock 417 208 305 minecraft:stripped_oak_log
setblock 417 208 306 minecraft:red_terracotta
setblock 417 208 310 minecraft:stripped_oak_log
setblock 417 208 311 minecraft:red_terracotta
fill 418 208 276 418 211 316 minecraft:white_terracotta
setblock 379 209 278 minecraft:light[level=12]
setblock 379 209 285 minecraft:light[level=12]
setblock 379 209 292 minecraft:light[level=12]
setblock 379 209 299 minecraft:light[level=12]
setblock 379 209 306 minecraft:light[level=12]
setblock 379 209 313 minecraft:light[level=12]
fill 380 209 293 380 211 293 minecraft:green_concrete
setblock 386 209 278 minecraft:light[level=12]
setblock 386 209 285 minecraft:light[level=12]
setblock 386 209 292 minecraft:light[level=12]
setblock 386 209 299 minecraft:light[level=12]
setblock 386 209 306 minecraft:light[level=12]
setblock 386 209 313 minecraft:light[level=12]
setblock 393 209 278 minecraft:light[level=12]
setblock 393 209 285 minecraft:light[level=12]
setblock 393 209 292 minecraft:light[level=12]
setblock 393 209 299 minecraft:light[level=12]
setblock 393 209 306 minecraft:light[level=12]
setblock 393 209 313 minecraft:light[level=12]
setblock 400 209 278 minecraft:light[level=12]
setblock 400 209 285 minecraft:light[level=12]
setblock 400 209 292 minecraft:light[level=12]
setblock 400 209 299 minecraft:light[level=12]
setblock 400 209 306 minecraft:light[level=12]
setblock 400 209 313 minecraft:light[level=12]
setblock 407 209 278 minecraft:light[level=12]
setblock 407 209 285 minecraft:light[level=12]
setblock 407 209 292 minecraft:light[level=12]
setblock 407 209 299 minecraft:light[level=12]
setblock 407 209 306 minecraft:light[level=12]
setblock 407 209 313 minecraft:light[level=12]
setblock 414 209 278 minecraft:light[level=12]
setblock 414 209 285 minecraft:light[level=12]
setblock 414 209 292 minecraft:light[level=12]
setblock 414 209 299 minecraft:light[level=12]
setblock 414 209 306 minecraft:light[level=12]
setblock 414 209 313 minecraft:light[level=12]
fill 376 212 275 376 215 317 minecraft:terracotta
fill 377 212 275 418 215 275 minecraft:terracotta
fill 377 212 317 418 215 317 minecraft:terracotta
fill 418 212 276 418 215 316 minecraft:terracotta
fill 386 214 278 388 214 280 minecraft:terracotta
fill 387 214 298 392 214 298 minecraft:dark_oak_planks
fill 388 214 294 393 214 297 minecraft:dark_oak_planks
fill 388 214 299 393 214 302 minecraft:dark_oak_planks
fill 389 214 293 403 214 293 minecraft:dark_oak_planks
fill 389 214 303 403 214 303 minecraft:dark_oak_planks
fill 390 214 292 402 214 292 minecraft:dark_oak_planks
fill 390 214 304 402 214 304 minecraft:dark_oak_planks
fill 391 214 291 401 214 291 minecraft:dark_oak_planks
fill 391 214 305 401 214 305 minecraft:dark_oak_planks
fill 392 214 290 400 214 290 minecraft:dark_oak_planks
fill 392 214 306 400 214 306 minecraft:dark_oak_planks
fill 394 214 294 395 214 295 minecraft:dark_oak_planks
fill 394 214 301 395 214 302 minecraft:dark_oak_planks
setblock 396 214 289 minecraft:dark_oak_planks
fill 396 214 294 404 214 294 minecraft:dark_oak_planks
fill 396 214 302 404 214 302 minecraft:dark_oak_planks
setblock 396 214 307 minecraft:dark_oak_planks
fill 397 214 295 404 214 295 minecraft:dark_oak_planks
fill 397 214 301 404 214 301 minecraft:dark_oak_planks
fill 399 214 296 404 214 297 minecraft:dark_oak_planks
fill 399 214 299 404 214 300 minecraft:dark_oak_planks
fill 400 214 298 405 214 298 minecraft:dark_oak_planks
fill 377 215 276 417 215 277 minecraft:smooth_sandstone
fill 377 215 278 417 215 278 minecraft:sandstone
fill 377 215 279 386 215 280 minecraft:smooth_sandstone
fill 377 215 281 417 215 281 minecraft:sandstone
fill 377 215 282 417 215 283 minecraft:smooth_sandstone
fill 377 215 284 417 215 284 minecraft:sandstone
fill 377 215 285 417 215 286 minecraft:smooth_sandstone
fill 377 215 287 417 215 287 minecraft:sandstone
fill 377 215 288 395 215 289 minecraft:smooth_sandstone
fill 377 215 290 391 215 290 minecraft:sandstone
fill 377 215 291 389 215 292 minecraft:smooth_sandstone
fill 377 215 293 388 215 293 minecraft:sandstone
fill 377 215 294 387 215 295 minecraft:smooth_sandstone
fill 377 215 296 387 215 296 minecraft:sandstone
fill 377 215 297 386 215 298 minecraft:smooth_sandstone
fill 377 215 299 387 215 299 minecraft:sandstone
fill 377 215 300 387 215 301 minecraft:smooth_sandstone
fill 377 215 302 387 215 302 minecraft:sandstone
fill 377 215 303 388 215 304 minecraft:smooth_sandstone
fill 377 215 305 390 215 305 minecraft:sandstone
fill 377 215 306 391 215 307 minecraft:smooth_sandstone
fill 377 215 308 417 215 308 minecraft:sandstone
fill 377 215 309 417 215 310 minecraft:smooth_sandstone
fill 377 215 311 417 215 311 minecraft:sandstone
fill 377 215 312 417 215 313 minecraft:smooth_sandstone
fill 377 215 314 417 215 314 minecraft:sandstone
fill 377 215 315 417 215 316 minecraft:smooth_sandstone
fill 387 215 279 387 221 279 minecraft:green_concrete
fill 387 215 280 417 215 280 minecraft:smooth_sandstone
setblock 387 215 297 minecraft:smooth_sandstone
setblock 387 215 298 minecraft:iron_block
fill 388 215 279 417 215 279 minecraft:smooth_sandstone
fill 388 215 294 388 215 296 minecraft:iron_block
fill 388 215 297 388 215 299 minecraft:dark_oak_planks
fill 388 215 300 388 215 302 minecraft:iron_block
setblock 389 215 293 minecraft:iron_block
setblock 389 215 294 minecraft:dark_oak_planks
fill 389 215 295 392 215 295 minecraft:smooth_sandstone
setblock 389 215 296 minecraft:spruce_planks
fill 389 215 297 391 215 298 minecraft:smooth_sandstone
fill 389 215 299 391 215 299 minecraft:sandstone
setblock 389 215 300 minecraft:spruce_planks
fill 389 215 301 392 215 301 minecraft:smooth_sandstone
setblock 389 215 302 minecraft:dark_oak_planks
setblock 389 215 303 minecraft:iron_block
setblock 389 215 304 minecraft:smooth_sandstone
setblock 390 215 291 minecraft:smooth_sandstone
setblock 390 215 292 minecraft:iron_block
setblock 390 215 293 minecraft:sandstone
fill 390 215 294 391 215 294 minecraft:smooth_sandstone
setblock 390 215 296 minecraft:dark_oak_planks
setblock 390 215 300 minecraft:dark_oak_planks
fill 390 215 302 391 215 302 minecraft:sandstone
setblock 390 215 303 minecraft:smooth_sandstone
setblock 390 215 304 minecraft:iron_block
setblock 391 215 291 minecraft:iron_block
fill 391 215 292 393 215 292 minecraft:smooth_sandstone
setblock 391 215 293 minecraft:spruce_planks
fill 391 215 296 392 215 296 minecraft:sandstone
fill 391 215 300 392 215 300 minecraft:smooth_sandstone
setblock 391 215 303 minecraft:spruce_planks
fill 391 215 304 393 215 304 minecraft:smooth_sandstone
setblock 391 215 305 minecraft:iron_block
fill 392 215 290 394 215 290 minecraft:iron_block
setblock 392 215 291 minecraft:dark_oak_planks
fill 392 215 293 400 215 293 minecraft:sandstone
setblock 392 215 294 minecraft:spruce_planks
fill 392 215 297 393 215 297 minecraft:ochre_froglight
setblock 392 215 298 minecraft:smooth_sandstone
fill 392 215 299 393 215 299 minecraft:ochre_froglight
setblock 392 215 302 minecraft:spruce_planks
fill 392 215 303 400 215 303 minecraft:smooth_sandstone
setblock 392 215 305 minecraft:dark_oak_planks
fill 392 215 306 394 215 306 minecraft:iron_block
fill 392 215 307 395 215 307 minecraft:smooth_sandstone
setblock 393 215 291 minecraft:smooth_sandstone
fill 393 215 294 394 215 294 minecraft:smooth_sandstone
fill 393 215 295 393 215 296 minecraft:ochre_froglight
fill 393 215 300 393 215 301 minecraft:ochre_froglight
fill 393 215 302 394 215 302 minecraft:sandstone
setblock 393 215 305 minecraft:sandstone
setblock 394 215 291 minecraft:spruce_planks
setblock 394 215 292 minecraft:dark_oak_planks
fill 394 215 295 395 215 295 minecraft:ochre_froglight
fill 394 215 301 395 215 301 minecraft:ochre_froglight
setblock 394 215 304 minecraft:dark_oak_planks
setblock 394 215 305 minecraft:spruce_planks
fill 395 215 290 397 215 290 minecraft:dark_oak_planks
fill 395 215 291 397 215 292 minecraft:smooth_sandstone
setblock 395 215 294 minecraft:ochre_froglight
setblock 395 215 302 minecraft:ochre_froglight
fill 395 215 304 397 215 304 minecraft:smooth_sandstone
fill 395 215 305 397 215 305 minecraft:sandstone
fill 395 215 306 397 215 306 minecraft:dark_oak_planks
fill 396 215 288 417 215 288 minecraft:smooth_sandstone
setblock 396 215 289 minecraft:iron_block
setblock 396 215 294 minecraft:smooth_sandstone
setblock 396 215 302 minecraft:smooth_sandstone
setblock 396 215 307 minecraft:iron_block
fill 397 215 289 417 215 289 minecraft:smooth_sandstone
fill 397 215 294 397 215 295 minecraft:ochre_froglight
fill 397 215 301 397 215 302 minecraft:ochre_froglight
fill 397 215 307 417 215 307 minecraft:smooth_sandstone
fill 398 215 290 400 215 290 minecraft:iron_block
setblock 398 215 291 minecraft:spruce_planks
setblock 398 215 292 minecraft:dark_oak_planks
fill 398 215 294 399 215 294 minecraft:smooth_sandstone
fill 398 215 295 399 215 295 minecraft:ochre_froglight
fill 398 215 301 399 215 301 minecraft:ochre_froglight
fill 398 215 302 399 215 302 minecraft:sandstone
setblock 398 215 304 minecraft:dark_oak_planks
setblock 398 215 305 minecraft:spruce_planks
fill 398 215 306 400 215 306 minecraft:iron_block
fill 399 215 291 399 215 292 minecraft:smooth_sandstone
fill 399 215 296 399 215 297 minecraft:ochre_froglight
fill 399 215 299 399 215 300 minecraft:ochre_froglight
fill 399 215 304 401 215 304 minecraft:smooth_sandstone
setblock 399 215 305 minecraft:sandstone
setblock 400 215 291 minecraft:dark_oak_planks
fill 400 215 292 401 215 292 minecraft:smooth_sandstone
setblock 400 215 294 minecraft:spruce_planks
fill 400 215 295 403 215 295 minecraft:smooth_sandstone
fill 400 215 296 401 215 296 minecraft:sandstone
setblock 400 215 297 minecraft:ochre_froglight
fill 400 215 298 403 215 298 minecraft:smooth_sandstone
setblock 400 215 299 minecraft:ochre_froglight
fill 400 215 300 401 215 301 minecraft:smooth_sandstone
setblock 400 215 302 minecraft:spruce_planks
setblock 400 215 305 minecraft:dark_oak_planks
fill 401 215 290 417 215 290 minecraft:sandstone
setblock 401 215 291 minecraft:iron_block
setblock 401 215 293 minecraft:spruce_planks
fill 401 215 294 402 215 294 minecraft:smooth_sandstone
fill 401 215 297 403 215 297 minecraft:smooth_sandstone
fill 401 215 299 403 215 299 minecraft:sandstone
fill 401 215 302 402 215 302 minecraft:sandstone
setblock 401 215 303 minecraft:spruce_planks
setblock 401 215 305 minecraft:iron_block
fill 401 215 306 417 215 306 minecraft:smooth_sandstone
fill 402 215 291 417 215 291 minecraft:smooth_sandstone
setblock 402 215 292 minecraft:iron_block
setblock 402 215 293 minecraft:sandstone
setblock 402 215 296 minecraft:dark_oak_planks
setblock 402 215 300 minecraft:dark_oak_planks
fill 402 215 301 403 215 301 minecraft:smooth_sandstone
setblock 402 215 303 minecraft:smooth_sandstone
setblock 402 215 304 minecraft:iron_block
fill 402 215 305 417 215 305 minecraft:sandstone
fill 403 215 292 417 215 292 minecraft:smooth_sandstone
setblock 403 215 293 minecraft:iron_block
setblock 403 215 294 minecraft:dark_oak_planks
setblock 403 215 296 minecraft:spruce_planks
setblock 403 215 300 minecraft:spruce_planks
setblock 403 215 302 minecraft:dark_oak_planks
setblock 403 215 303 minecraft:iron_block
fill 403 215 304 417 215 304 minecraft:smooth_sandstone
fill 404 215 293 417 215 293 minecraft:sandstone
fill 404 215 294 404 215 296 minecraft:iron_block
fill 404 215 297 404 215 299 minecraft:dark_oak_planks
fill 404 215 300 404 215 302 minecraft:iron_block
fill 404 215 303 417 215 303 minecraft:smooth_sandstone
fill 405 215 294 417 215 295 minecraft:smooth_sandstone
fill 405 215 296 417 215 296 minecraft:sandstone
fill 405 215 297 417 215 297 minecraft:smooth_sandstone
setblock 405 215 298 minecraft:iron_block
fill 405 215 299 417 215 299 minecraft:sandstone
fill 405 215 300 417 215 301 minecraft:smooth_sandstone
fill 405 215 302 417 215 302 minecraft:sandstone
fill 406 215 298 417 215 298 minecraft:smooth_sandstone
fill 376 216 275 376 219 317 minecraft:brown_terracotta
fill 377 216 275 418 219 275 minecraft:brown_terracotta
fill 377 216 317 418 219 317 minecraft:brown_terracotta
fill 387 216 289 387 217 289 minecraft:bone_block
fill 387 216 298 387 222 298 minecraft:bone_block
fill 387 216 307 387 217 307 minecraft:bone_block
fill 390 216 289 390 217 289 minecraft:bone_block
fill 390 216 298 390 222 298 minecraft:bone_block
fill 390 216 307 390 217 307 minecraft:bone_block
fill 393 216 289 393 217 289 minecraft:bone_block
fill 393 216 307 393 217 307 minecraft:bone_block
fill 396 216 289 396 217 289 minecraft:bone_block
fill 396 216 307 396 217 307 minecraft:bone_block
fill 399 216 289 399 217 289 minecraft:bone_block
fill 399 216 307 399 217 307 minecraft:bone_block
fill 402 216 289 402 217 289 minecraft:bone_block
fill 402 216 298 402 222 298 minecraft:bone_block
fill 402 216 307 402 217 307 minecraft:bone_block
fill 405 216 289 405 217 289 minecraft:bone_block
fill 405 216 298 405 222 298 minecraft:bone_block
fill 405 216 307 405 217 307 minecraft:bone_block
fill 418 216 276 418 219 316 minecraft:brown_terracotta
fill 387 218 290 387 219 290 minecraft:bone_block
fill 387 218 306 387 219 306 minecraft:bone_block
fill 388 218 279 388 219 279 minecraft:green_concrete
fill 390 218 290 390 219 290 minecraft:bone_block
fill 390 218 306 390 219 306 minecraft:bone_block
fill 393 218 290 393 219 290 minecraft:bone_block
fill 393 218 298 393 222 298 minecraft:bone_block
fill 393 218 306 393 219 306 minecraft:bone_block
fill 396 218 290 396 219 290 minecraft:bone_block
fill 396 218 306 396 219 306 minecraft:bone_block
fill 399 218 290 399 219 290 minecraft:bone_block
fill 399 218 298 399 222 298 minecraft:bone_block
fill 399 218 306 399 219 306 minecraft:bone_block
fill 402 218 290 402 219 290 minecraft:bone_block
fill 402 218 306 402 219 306 minecraft:bone_block
fill 405 218 290 405 219 290 minecraft:bone_block
fill 405 218 306 405 219 306 minecraft:bone_block
fill 377 219 285 377 219 288 minecraft:red_terracotta
setblock 377 219 289 minecraft:stripped_oak_log
fill 377 219 290 377 219 293 minecraft:red_terracotta
setblock 377 219 294 minecraft:stripped_oak_log
fill 377 219 295 377 220 297 minecraft:red_terracotta
fill 378 219 276 379 219 276 minecraft:red_terracotta
fill 378 219 277 380 219 284 minecraft:stripped_oak_log
fill 378 219 288 382 219 288 minecraft:stripped_oak_log
fill 378 219 289 378 219 292 minecraft:red_terracotta
fill 378 219 293 382 219 293 minecraft:stripped_oak_log
fill 378 219 294 378 221 295 minecraft:red_terracotta
fill 378 219 296 382 219 296 minecraft:stripped_oak_log
fill 378 219 316 379 219 316 minecraft:red_terracotta
fill 379 219 289 382 219 292 minecraft:stripped_oak_log
fill 379 219 294 382 220 295 minecraft:stripped_oak_log
setblock 380 219 276 minecraft:stripped_oak_log
setblock 380 219 316 minecraft:stripped_oak_log
fill 381 219 276 383 219 277 minecraft:red_terracotta
fill 381 219 278 386 219 284 minecraft:stripped_oak_log
setblock 381 219 315 minecraft:stripped_oak_log
fill 381 219 316 384 219 316 minecraft:red_terracotta
fill 382 219 315 385 219 315 minecraft:red_terracotta
setblock 384 219 276 minecraft:red_terracotta
setblock 384 219 277 minecraft:stripped_oak_log
fill 384 219 314 386 219 314 minecraft:red_terracotta
setblock 385 219 276 minecraft:stripped_oak_log
fill 385 219 277 388 219 277 minecraft:red_terracotta
setblock 385 219 316 minecraft:stripped_oak_log
fill 386 219 276 389 219 276 minecraft:red_terracotta
setblock 386 219 315 minecraft:stripped_oak_log
fill 386 219 316 389 219 316 minecraft:red_terracotta
fill 387 219 278 390 219 278 minecraft:stripped_oak_log
fill 387 219 280 390 219 284 minecraft:stripped_oak_log
setblock 387 219 314 minecraft:stripped_oak_log
fill 387 219 315 390 219 315 minecraft:red_terracotta
fill 388 219 314 389 221 314 minecraft:red_terracotta
fill 389 219 277 390 219 277 minecraft:stripped_oak_log
fill 389 219 279 390 219 279 minecraft:stripped_oak_log
setblock 390 219 276 minecraft:stripped_oak_log
setblock 390 219 316 minecraft:stripped_oak_log
fill 391 219 276 394 219 276 minecraft:red_terracotta
setblock 391 219 315 minecraft:stripped_oak_log
fill 391 219 316 394 219 316 minecraft:red_terracotta
fill 392 219 315 395 219 315 minecraft:red_terracotta
setblock 395 219 316 minecraft:stripped_oak_log
setblock 396 219 315 minecraft:stripped_oak_log
fill 396 219 316 399 219 316 minecraft:red_terracotta
fill 397 219 315 400 219 315 minecraft:red_terracotta
fill 398 219 276 399 219 276 minecraft:red_terracotta
fill 399 219 314 401 219 314 minecraft:red_terracotta
fill 400 219 276 400 219 282 minecraft:stripped_oak_log
setblock 400 219 316 minecraft:stripped_oak_log
fill 401 219 276 404 219 276 minecraft:red_terracotta
fill 401 219 277 408 219 282 minecraft:stripped_oak_log
setblock 401 219 315 minecraft:stripped_oak_log
fill 401 219 316 404 219 316 minecraft:red_terracotta
setblock 402 219 313 minecraft:red_terracotta
setblock 402 219 314 minecraft:stripped_oak_log
fill 402 219 315 405 219 315 minecraft:red_terracotta
setblock 403 219 313 minecraft:stripped_oak_log
fill 403 219 314 406 219 314 minecraft:red_terracotta
fill 404 219 313 406 220 313 minecraft:red_terracotta
setblock 405 219 276 minecraft:stripped_oak_log
setblock 405 219 316 minecraft:stripped_oak_log
fill 406 219 276 408 219 276 minecraft:red_terracotta
setblock 406 219 315 minecraft:stripped_oak_log
fill 406 219 316 409 219 316 minecraft:red_terracotta
setblock 407 219 314 minecraft:stripped_oak_log
fill 407 219 315 410 219 315 minecraft:red_terracotta
fill 408 219 314 408 221 314 minecraft:red_terracotta
fill 409 219 276 412 219 276 minecraft:stripped_oak_log
fill 409 219 277 411 219 279 minecraft:terracotta
fill 409 219 280 412 219 282 minecraft:stripped_oak_log
setblock 410 219 316 minecraft:stripped_oak_log
fill 411 219 302 417 219 314 minecraft:stripped_oak_log
fill 411 219 316 412 221 316 minecraft:red_terracotta
fill 412 219 277 412 219 279 minecraft:stripped_oak_log
fill 416 219 291 416 219 294 minecraft:red_terracotta
setblock 416 219 295 minecraft:stripped_oak_log
fill 417 219 287 417 219 288 minecraft:red_terracotta
setblock 417 219 289 minecraft:stripped_oak_log
fill 417 219 290 417 219 293 minecraft:red_terracotta
setblock 417 219 294 minecraft:stripped_oak_log
fill 417 219 295 417 219 298 minecraft:red_terracotta
setblock 417 219 299 minecraft:stripped_oak_log
fill 376 220 275 376 223 317 minecraft:light_gray_terracotta
fill 377 220 275 418 223 275 minecraft:light_gray_terracotta
fill 377 220 276 377 220 277 minecraft:red_terracotta
fill 377 220 278 378 220 278 minecraft:stripped_oak_log
fill 377 220 284 377 220 287 minecraft:red_terracotta
setblock 377 220 288 minecraft:stripped_oak_log
fill 377 220 289 377 220 292 minecraft:red_terracotta
setblock 377 220 293 minecraft:stripped_oak_log
fill 377 220 294 377 223 294 minecraft:red_terracotta
setblock 377 220 298 minecraft:stripped_oak_log
fill 377 220 314 377 221 316 minecraft:red_terracotta
fill 377 220 317 418 223 317 minecraft:light_gray_terracotta
setblock 378 220 276 minecraft:red_terracotta
setblock 378 220 277 minecraft:shroomlight
setblock 378 220 279 minecraft:shroomlight
fill 378 220 280 378 222 280 minecraft:stripped_oak_log
setblock 378 220 281 minecraft:shroomlight
fill 378 220 282 378 221 282 minecraft:stripped_oak_log
setblock 378 220 283 minecraft:shroomlight
fill 378 220 284 378 221 284 minecraft:stripped_oak_log
setblock 378 220 287 minecraft:stripped_oak_log
fill 378 220 288 378 220 291 minecraft:red_terracotta
setblock 378 220 292 minecraft:stripped_oak_log
fill 378 220 293 379 222 293 minecraft:red_terracotta
setblock 378 220 296 minecraft:red_terracotta
setblock 378 220 316 minecraft:red_terracotta
setblock 379 220 276 minecraft:shroomlight
fill 379 220 277 379 223 277 minecraft:red_terracotta
setblock 379 220 278 minecraft:shroomlight
fill 379 220 279 379 222 279 minecraft:stripped_oak_log
setblock 379 220 280 minecraft:shroomlight
fill 379 220 281 379 222 281 minecraft:stripped_oak_log
setblock 379 220 282 minecraft:shroomlight
fill 379 220 283 379 223 283 minecraft:stripped_oak_log
setblock 379 220 284 minecraft:shroomlight
fill 379 220 288 382 220 289 minecraft:stripped_oak_log
setblock 379 220 290 minecraft:red_terracotta
fill 379 220 291 382 220 291 minecraft:stripped_oak_log
fill 379 220 292 379 223 292 minecraft:red_terracotta
fill 379 220 296 382 221 296 minecraft:stripped_oak_log
setblock 379 220 316 minecraft:stripped_oak_log
fill 380 220 276 380 223 276 minecraft:red_terracotta
setblock 380 220 277 minecraft:shroomlight
setblock 380 220 278 minecraft:stripped_oak_log
setblock 380 220 279 minecraft:shroomlight
fill 380 220 280 380 223 280 minecraft:stripped_oak_log
setblock 380 220 281 minecraft:shroomlight
fill 380 220 282 380 242 282 minecraft:stripped_oak_log
setblock 380 220 283 minecraft:shroomlight
fill 380 220 284 380 242 284 minecraft:stripped_oak_log
fill 380 220 290 382 231 290 minecraft:stripped_oak_log
fill 380 220 292 382 231 293 minecraft:stripped_oak_log
setblock 380 220 315 minecraft:stripped_oak_log
fill 380 220 316 383 220 316 minecraft:red_terracotta
setblock 381 220 276 minecraft:shroomlight
fill 381 220 277 381 221 277 minecraft:red_terracotta
setblock 381 220 278 minecraft:shroomlight
fill 381 220 279 381 222 279 minecraft:stripped_oak_log
setblock 381 220 280 minecraft:shroomlight
fill 381 220 281 381 242 281 minecraft:stripped_oak_log
setblock 381 220 282 minecraft:shroomlight
fill 381 220 283 381 242 283 minecraft:stripped_oak_log
setblock 381 220 284 minecraft:shroomlight
fill 381 220 315 384 220 315 minecraft:red_terracotta
fill 382 220 276 382 221 276 minecraft:red_terracotta
setblock 382 220 277 minecraft:shroomlight
setblock 382 220 278 minecraft:stripped_oak_log
setblock 382 220 279 minecraft:shroomlight
fill 382 220 280 382 242 280 minecraft:stripped_oak_log
setblock 382 220 281 minecraft:shroomlight
fill 382 220 282 382 242 282 minecraft:stripped_oak_log
setblock 382 220 283 minecraft:shroomlight
fill 382 220 284 382 242 284 minecraft:stripped_oak_log
fill 382 220 314 385 220 314 minecraft:red_terracotta
setblock 383 220 276 minecraft:shroomlight
setblock 383 220 277 minecraft:stripped_oak_log
setblock 383 220 278 minecraft:shroomlight
fill 383 220 279 383 223 279 minecraft:stripped_oak_log
setblock 383 220 280 minecraft:shroomlight
fill 383 220 281 383 242 281 minecraft:stripped_oak_log
setblock 383 220 282 minecraft:shroomlight
fill 383 220 283 383 242 283 minecraft:stripped_oak_log
setblock 383 220 284 minecraft:shroomlight
setblock 384 220 276 minecraft:stripped_oak_log
setblock 384 220 277 minecraft:shroomlight
fill 384 220 278 384 222 278 minecraft:red_terracotta
setblock 384 220 279 minecraft:shroomlight
fill 384 220 280 384 242 280 minecraft:stripped_oak_log
setblock 384 220 281 minecraft:shroomlight
fill 384 220 282 384 242 282 minecraft:stripped_oak_log
setblock 384 220 283 minecraft:shroomlight
fill 384 220 284 384 242 284 minecraft:stripped_oak_log
setblock 384 220 316 minecraft:stripped_oak_log
setblock 385 220 276 minecraft:shroomlight
fill 385 220 277 385 222 277 minecraft:red_terracotta
setblock 385 220 278 minecraft:shroomlight
fill 385 220 279 385 242 279 minecraft:stripped_oak_log
setblock 385 220 280 minecraft:shroomlight
fill 385 220 281 385 242 281 minecraft:stripped_oak_log
setblock 385 220 282 minecraft:shroomlight
fill 385 220 283 385 242 283 minecraft:stripped_oak_log
setblock 385 220 284 minecraft:shroomlight
setblock 385 220 315 minecraft:stripped_oak_log
fill 385 220 316 388 220 316 minecraft:red_terracotta
fill 386 220 276 386 222 276 minecraft:red_terracotta
setblock 386 220 277 minecraft:shroomlight
setblock 386 220 278 minecraft:red_terracotta
setblock 386 220 279 minecraft:shroomlight
fill 386 220 280 386 242 280 minecraft:stripped_oak_log
setblock 386 220 281 minecraft:shroomlight
fill 386 220 282 386 242 282 minecraft:stripped_oak_log
setblock 386 220 283 minecraft:shroomlight
fill 386 220 284 386 242 284 minecraft:stripped_oak_log
setblock 386 220 314 minecraft:stripped_oak_log
fill 386 220 315 389 220 315 minecraft:red_terracotta
setblock 387 220 276 minecraft:shroomlight
setblock 387 220 277 minecraft:red_terracotta
setblock 387 220 278 minecraft:shroomlight
setblock 387 220 280 minecraft:shroomlight
fill 387 220 281 387 242 281 minecraft:stripped_oak_log
setblock 387 220 282 minecraft:shroomlight
fill 387 220 283 387 242 283 minecraft:stripped_oak_log
setblock 387 220 284 minecraft:shroomlight
fill 387 220 291 387 221 291 minecraft:bone_block
fill 387 220 305 387 221 305 minecraft:bone_block
fill 387 220 314 387 223 314 minecraft:red_terracotta
setblock 388 220 276 minecraft:red_terracotta
setblock 388 220 277 minecraft:shroomlight
fill 388 220 278 388 221 278 minecraft:stripped_oak_log
setblock 388 220 279 minecraft:shroomlight
fill 388 220 280 388 242 280 minecraft:stripped_oak_log
setblock 388 220 281 minecraft:shroomlight
fill 388 220 282 388 242 282 minecraft:stripped_oak_log
setblock 388 220 283 minecraft:shroomlight
fill 388 220 284 388 242 284 minecraft:stripped_oak_log
setblock 389 220 276 minecraft:shroomlight
fill 389 220 277 389 223 277 minecraft:red_terracotta
setblock 389 220 278 minecraft:shroomlight
fill 389 220 279 389 231 279 minecraft:stripped_oak_log
setblock 389 220 280 minecraft:shroomlight
fill 389 220 281 389 242 281 minecraft:stripped_oak_log
setblock 389 220 282 minecraft:shroomlight
fill 389 220 283 389 242 283 minecraft:stripped_oak_log
setblock 389 220 284 minecraft:shroomlight
setblock 389 220 316 minecraft:stripped_oak_log
fill 390 220 276 393 220 276 minecraft:red_terracotta
setblock 390 220 277 minecraft:shroomlight
fill 390 220 278 390 231 278 minecraft:stripped_oak_log
setblock 390 220 279 minecraft:shroomlight
fill 390 220 280 390 242 280 minecraft:stripped_oak_log
setblock 390 220 281 minecraft:shroomlight
fill 390 220 282 390 242 282 minecraft:stripped_oak_log
setblock 390 220 283 minecraft:shroomlight
fill 390 220 284 390 242 284 minecraft:stripped_oak_log
fill 390 220 291 390 221 291 minecraft:bone_block
fill 390 220 305 390 221 305 minecraft:bone_block
setblock 390 220 315 minecraft:stripped_oak_log
fill 390 220 316 393 220 316 minecraft:red_terracotta
fill 391 220 315 394 220 315 minecraft:red_terracotta
fill 393 220 291 393 221 291 minecraft:bone_block
fill 393 220 305 393 221 305 minecraft:bone_block
setblock 394 220 276 minecraft:stripped_oak_log
setblock 394 220 316 minecraft:stripped_oak_log
fill 395 220 276 398 220 276 minecraft:red_terracotta
setblock 395 220 315 minecraft:stripped_oak_log
fill 395 220 316 398 220 316 minecraft:red_terracotta
fill 396 220 291 396 221 291 minecraft:bone_block
fill 396 220 305 396 221 305 minecraft:bone_block
fill 396 220 315 399 220 315 minecraft:red_terracotta
fill 397 220 314 400 220 314 minecraft:red_terracotta
setblock 399 220 276 minecraft:stripped_oak_log
fill 399 220 291 399 221 291 minecraft:bone_block
fill 399 220 305 399 221 305 minecraft:bone_block
setblock 399 220 316 minecraft:stripped_oak_log
fill 400 220 276 400 223 276 minecraft:red_terracotta
setblock 400 220 277 minecraft:shroomlight
fill 400 220 278 400 238 278 minecraft:stripped_oak_log
setblock 400 220 279 minecraft:shroomlight
fill 400 220 280 400 238 280 minecraft:stripped_oak_log
setblock 400 220 281 minecraft:shroomlight
fill 400 220 282 400 238 282 minecraft:stripped_oak_log
setblock 400 220 315 minecraft:stripped_oak_log
fill 400 220 316 403 220 316 minecraft:red_terracotta
setblock 401 220 276 minecraft:shroomlight
setblock 401 220 277 minecraft:stripped_oak_log
setblock 401 220 278 minecraft:shroomlight
fill 401 220 279 401 238 279 minecraft:stripped_oak_log
setblock 401 220 280 minecraft:shroomlight
fill 401 220 281 401 238 281 minecraft:stripped_oak_log
setblock 401 220 282 minecraft:shroomlight
setblock 401 220 313 minecraft:red_terracotta
setblock 401 220 314 minecraft:stripped_oak_log
fill 401 220 315 404 220 315 minecraft:red_terracotta
fill 402 220 276 402 221 276 minecraft:red_terracotta
setblock 402 220 277 minecraft:shroomlight
fill 402 220 278 402 238 278 minecraft:stripped_oak_log
setblock 402 220 279 minecraft:shroomlight
fill 402 220 280 402 238 280 minecraft:stripped_oak_log
setblock 402 220 281 minecraft:shroomlight
fill 402 220 282 402 238 282 minecraft:stripped_oak_log
fill 402 220 291 402 221 291 minecraft:bone_block
fill 402 220 305 402 221 305 minecraft:bone_block
setblock 402 220 313 minecraft:stripped_oak_log
fill 402 220 314 405 220 314 minecraft:red_terracotta
setblock 403 220 276 minecraft:shroomlight
setblock 403 220 277 minecraft:stripped_oak_log
setblock 403 220 278 minecraft:shroomlight
fill 403 220 279 403 238 279 minecraft:stripped_oak_log
setblock 403 220 280 minecraft:shroomlight
fill 403 220 281 403 238 281 minecraft:stripped_oak_log
setblock 403 220 282 minecraft:shroomlight
fill 403 220 313 403 223 313 minecraft:red_terracotta
setblock 404 220 276 minecraft:stripped_oak_log
setblock 404 220 277 minecraft:shroomlight
fill 404 220 278 404 238 278 minecraft:stripped_oak_log
setblock 404 220 279 minecraft:shroomlight
fill 404 220 280 404 238 280 minecraft:stripped_oak_log
setblock 404 220 281 minecraft:shroomlight
fill 404 220 282 404 238 282 minecraft:stripped_oak_log
setblock 404 220 316 minecraft:stripped_oak_log
setblock 405 220 276 minecraft:shroomlight
setblock 405 220 277 minecraft:stripped_oak_log
setblock 405 220 278 minecraft:shroomlight
fill 405 220 279 405 238 279 minecraft:stripped_oak_log
setblock 405 220 280 minecraft:shroomlight
fill 405 220 281 405 238 281 minecraft:stripped_oak_log
setblock 405 220 282 minecraft:shroomlight
fill 405 220 291 405 221 291 minecraft:bone_block
fill 405 220 305 405 221 305 minecraft:bone_block
setblock 405 220 315 minecraft:stripped_oak_log
fill 405 220 316 408 220 316 minecraft:red_terracotta
fill 406 220 276 406 222 276 minecraft:red_terracotta
setblock 406 220 277 minecraft:shroomlight
fill 406 220 278 406 238 278 minecraft:stripped_oak_log
setblock 406 220 279 minecraft:shroomlight
fill 406 220 280 406 238 280 minecraft:stripped_oak_log
setblock 406 220 281 minecraft:shroomlight
fill 406 220 282 406 238 282 minecraft:stripped_oak_log
setblock 406 220 314 minecraft:stripped_oak_log
fill 406 220 315 409 220 315 minecraft:red_terracotta
setblock 407 220 276 minecraft:shroomlight
fill 407 220 277 407 238 277 minecraft:stripped_oak_log
setblock 407 220 278 minecraft:shroomlight
fill 407 220 279 407 238 279 minecraft:stripped_oak_log
setblock 407 220 280 minecraft:shroomlight
fill 407 220 281 407 238 281 minecraft:stripped_oak_log
setblock 407 220 282 minecraft:shroomlight
fill 407 220 314 407 223 314 minecraft:red_terracotta
setblock 408 220 276 minecraft:red_terracotta
setblock 408 220 277 minecraft:shroomlight
fill 408 220 278 408 238 278 minecraft:stripped_oak_log
setblock 408 220 279 minecraft:shroomlight
fill 408 220 280 408 238 280 minecraft:stripped_oak_log
setblock 408 220 281 minecraft:shroomlight
fill 408 220 282 408 238 282 minecraft:stripped_oak_log
fill 408 220 298 411 226 299 minecraft:bone_block
setblock 409 220 276 minecraft:shroomlight
fill 409 220 277 409 238 277 minecraft:stripped_oak_log
setblock 409 220 278 minecraft:shroomlight
fill 409 220 279 409 238 279 minecraft:stripped_oak_log
setblock 409 220 280 minecraft:shroomlight
fill 409 220 281 409 238 281 minecraft:stripped_oak_log
setblock 409 220 282 minecraft:shroomlight
fill 409 220 297 410 227 297 minecraft:bone_block
fill 409 220 300 409 227 300 minecraft:bone_block
setblock 409 220 316 minecraft:stripped_oak_log
fill 410 220 276 410 221 276 minecraft:stripped_oak_log
setblock 410 220 277 minecraft:shroomlight
fill 410 220 278 410 226 278 minecraft:green_concrete
setblock 410 220 279 minecraft:shroomlight
fill 410 220 280 410 238 280 minecraft:stripped_oak_log
setblock 410 220 281 minecraft:shroomlight
fill 410 220 282 410 238 282 minecraft:stripped_oak_log
setblock 410 220 315 minecraft:stripped_oak_log
fill 410 220 316 410 223 316 minecraft:red_terracotta
setblock 411 220 276 minecraft:shroomlight
fill 411 220 277 411 237 277 minecraft:stripped_oak_log
setblock 411 220 278 minecraft:shroomlight
fill 411 220 279 411 238 279 minecraft:stripped_oak_log
setblock 411 220 280 minecraft:shroomlight
fill 411 220 281 411 238 281 minecraft:stripped_oak_log
setblock 411 220 282 minecraft:shroomlight
setblock 411 220 302 minecraft:shroomlight
fill 411 220 303 411 229 303 minecraft:stripped_oak_log
setblock 411 220 304 minecraft:shroomlight
fill 411 220 305 411 229 305 minecraft:stripped_oak_log
setblock 411 220 306 minecraft:shroomlight
fill 411 220 307 411 229 307 minecraft:stripped_oak_log
setblock 411 220 308 minecraft:shroomlight
fill 411 220 309 411 229 309 minecraft:stripped_oak_log
setblock 411 220 310 minecraft:shroomlight
fill 411 220 311 411 229 311 minecraft:stripped_oak_log
setblock 411 220 312 minecraft:shroomlight
fill 411 220 313 411 229 313 minecraft:stripped_oak_log
setblock 411 220 314 minecraft:shroomlight
fill 412 220 276 412 223 276 minecraft:stripped_oak_log
setblock 412 220 277 minecraft:shroomlight
fill 412 220 278 412 238 278 minecraft:stripped_oak_log
setblock 412 220 279 minecraft:shroomlight
fill 412 220 280 412 238 280 minecraft:stripped_oak_log
setblock 412 220 281 minecraft:shroomlight
fill 412 220 282 412 238 282 minecraft:stripped_oak_log
fill 412 220 302 412 229 302 minecraft:stripped_oak_log
setblock 412 220 303 minecraft:shroomlight
fill 412 220 304 412 229 304 minecraft:stripped_oak_log
setblock 412 220 305 minecraft:shroomlight
fill 412 220 306 412 229 306 minecraft:stripped_oak_log
setblock 412 220 307 minecraft:shroomlight
fill 412 220 308 412 229 308 minecraft:stripped_oak_log
setblock 412 220 309 minecraft:shroomlight
fill 412 220 310 412 229 310 minecraft:stripped_oak_log
setblock 412 220 311 minecraft:shroomlight
fill 412 220 312 412 229 312 minecraft:stripped_oak_log
setblock 412 220 313 minecraft:shroomlight
fill 412 220 314 412 229 314 minecraft:stripped_oak_log
setblock 413 220 302 minecraft:shroomlight
fill 413 220 303 413 237 303 minecraft:stripped_oak_log
setblock 413 220 304 minecraft:shroomlight
fill 413 220 305 413 237 305 minecraft:stripped_oak_log
setblock 413 220 306 minecraft:shroomlight
fill 413 220 307 413 237 307 minecraft:stripped_oak_log
setblock 413 220 308 minecraft:shroomlight
fill 413 220 309 413 237 309 minecraft:stripped_oak_log
setblock 413 220 310 minecraft:shroomlight
fill 413 220 311 413 237 311 minecraft:stripped_oak_log
setblock 413 220 312 minecraft:shroomlight
fill 413 220 313 413 237 313 minecraft:stripped_oak_log
schedule function dropper:buildpart/68_7 1t
