setblock 70 182 596 minecraft:calcite
fill 70 182 597 70 185 597 minecraft:cobbled_deepslate
setblock 71 182 560 minecraft:calcite
fill 71 182 596 71 185 596 minecraft:cobbled_deepslate
setblock 72 182 559 minecraft:calcite
setblock 73 182 558 minecraft:calcite
setblock 73 182 559 minecraft:cobbled_deepslate
setblock 73 182 597 minecraft:cobbled_deepslate
setblock 73 182 598 minecraft:calcite
fill 74 182 558 74 183 558 minecraft:cobbled_deepslate
setblock 74 182 597 minecraft:calcite
fill 74 182 598 74 185 598 minecraft:cobbled_deepslate
fill 75 182 597 75 183 597 minecraft:cobbled_deepslate
setblock 77 182 598 minecraft:cobbled_deepslate
setblock 78 182 598 minecraft:calcite
fill 79 182 598 79 185 598 minecraft:cobbled_deepslate
fill 82 182 597 83 182 597 minecraft:cobbled_deepslate
setblock 83 182 598 minecraft:calcite
setblock 84 182 597 minecraft:calcite
fill 84 182 598 84 185 598 minecraft:cobbled_deepslate
fill 85 182 587 85 183 587 minecraft:cobbled_deepslate
fill 85 182 589 85 182 590 minecraft:cobbled_deepslate
setblock 85 182 591 minecraft:calcite
fill 85 182 592 85 184 593 minecraft:cobbled_deepslate
setblock 85 182 596 minecraft:calcite
fill 85 182 597 85 185 597 minecraft:cobbled_deepslate
fill 86 182 583 86 182 584 minecraft:cobbled_deepslate
setblock 86 182 585 minecraft:calcite
fill 86 182 586 86 185 586 minecraft:cobbled_deepslate
setblock 86 182 590 minecraft:calcite
fill 86 182 591 86 185 591 minecraft:cobbled_deepslate
fill 86 182 593 86 182 594 minecraft:cobbled_deepslate
setblock 86 182 595 minecraft:calcite
fill 86 182 596 86 185 596 minecraft:cobbled_deepslate
setblock 87 182 564 minecraft:calcite
fill 87 182 565 87 184 565 minecraft:cobbled_deepslate
setblock 87 182 568 minecraft:cobbled_deepslate
setblock 87 182 569 minecraft:calcite
fill 87 182 570 87 185 570 minecraft:cobbled_deepslate
setblock 87 182 573 minecraft:cobbled_deepslate
setblock 87 182 574 minecraft:calcite
fill 87 182 575 87 182 578 minecraft:cobbled_deepslate
setblock 87 182 579 minecraft:calcite
fill 87 182 580 87 182 583 minecraft:cobbled_deepslate
setblock 87 182 584 minecraft:calcite
fill 87 182 585 87 185 585 minecraft:cobbled_deepslate
setblock 87 182 589 minecraft:calcite
fill 87 182 590 87 185 590 minecraft:cobbled_deepslate
setblock 87 182 594 minecraft:calcite
fill 87 182 595 87 185 595 minecraft:cobbled_deepslate
setblock 88 182 558 minecraft:calcite
fill 88 182 559 88 183 559 minecraft:cobbled_deepslate
setblock 88 182 563 minecraft:calcite
fill 88 182 564 88 185 564 minecraft:cobbled_deepslate
setblock 88 182 568 minecraft:calcite
fill 88 182 569 88 185 569 minecraft:cobbled_deepslate
setblock 88 182 573 minecraft:calcite
fill 88 182 574 88 185 574 minecraft:cobbled_deepslate
setblock 88 182 578 minecraft:calcite
fill 88 182 579 88 185 579 minecraft:cobbled_deepslate
setblock 88 182 583 minecraft:calcite
fill 88 182 584 88 185 584 minecraft:cobbled_deepslate
setblock 88 182 588 minecraft:calcite
fill 88 182 589 88 185 589 minecraft:cobbled_deepslate
setblock 88 182 593 minecraft:calcite
fill 88 182 594 88 185 594 minecraft:cobbled_deepslate
setblock 88 182 598 minecraft:calcite
setblock 48 183 562 minecraft:calcite
fill 48 183 563 48 183 566 minecraft:cobbled_deepslate
setblock 48 183 567 minecraft:calcite
fill 48 183 568 48 183 571 minecraft:cobbled_deepslate
setblock 48 183 572 minecraft:calcite
fill 48 183 573 48 183 576 minecraft:cobbled_deepslate
setblock 48 183 577 minecraft:calcite
fill 48 183 578 48 186 578 minecraft:cobbled_deepslate
setblock 48 183 582 minecraft:calcite
fill 48 183 583 48 186 583 minecraft:cobbled_deepslate
setblock 48 183 587 minecraft:calcite
fill 48 183 588 48 186 588 minecraft:cobbled_deepslate
setblock 48 183 592 minecraft:calcite
fill 48 183 593 48 186 593 minecraft:cobbled_deepslate
setblock 48 183 597 minecraft:calcite
fill 48 183 598 48 186 598 minecraft:cobbled_deepslate
fill 49 183 562 49 183 565 minecraft:cobbled_deepslate
setblock 49 183 566 minecraft:calcite
fill 49 183 567 49 186 567 minecraft:cobbled_deepslate
setblock 49 183 571 minecraft:calcite
fill 49 183 572 49 186 572 minecraft:cobbled_deepslate
setblock 49 183 576 minecraft:calcite
fill 49 183 577 49 186 577 minecraft:cobbled_deepslate
setblock 49 183 581 minecraft:calcite
fill 49 183 582 49 185 582 minecraft:cobbled_deepslate
setblock 49 183 586 minecraft:calcite
fill 49 183 587 49 185 587 minecraft:cobbled_deepslate
setblock 49 183 591 minecraft:calcite
fill 49 183 592 49 186 592 minecraft:cobbled_deepslate
setblock 49 183 596 minecraft:calcite
setblock 50 183 565 minecraft:calcite
fill 50 183 566 50 184 566 minecraft:cobbled_deepslate
setblock 50 183 570 minecraft:calcite
fill 50 183 571 50 186 571 minecraft:cobbled_deepslate
setblock 50 183 575 minecraft:calcite
fill 50 183 576 50 185 576 minecraft:cobbled_deepslate
setblock 50 183 585 minecraft:calcite
setblock 50 183 586 minecraft:cobbled_deepslate
setblock 50 183 590 minecraft:calcite
fill 50 183 591 50 184 591 minecraft:cobbled_deepslate
setblock 51 183 569 minecraft:calcite
fill 51 183 570 51 184 570 minecraft:cobbled_deepslate
setblock 62 183 558 minecraft:calcite
fill 63 183 558 66 183 558 minecraft:cobbled_deepslate
fill 63 183 598 66 183 598 minecraft:cobbled_deepslate
fill 65 183 597 67 183 597 minecraft:cobbled_deepslate
setblock 66 183 559 minecraft:calcite
setblock 66 183 560 minecraft:cobbled_deepslate
setblock 67 183 558 minecraft:calcite
fill 67 183 559 67 186 559 minecraft:cobbled_deepslate
fill 67 183 596 68 183 596 minecraft:cobbled_deepslate
setblock 67 183 598 minecraft:calcite
fill 68 183 558 68 186 558 minecraft:cobbled_deepslate
setblock 68 183 597 minecraft:calcite
fill 68 183 598 68 186 598 minecraft:cobbled_deepslate
setblock 69 183 596 minecraft:calcite
fill 69 183 597 69 186 597 minecraft:cobbled_deepslate
fill 70 183 596 70 186 596 minecraft:cobbled_deepslate
setblock 71 183 559 minecraft:calcite
setblock 72 183 558 minecraft:calcite
setblock 72 183 559 minecraft:cobbled_deepslate
setblock 72 183 596 minecraft:cobbled_deepslate
setblock 72 183 598 minecraft:calcite
fill 73 183 558 73 184 558 minecraft:cobbled_deepslate
setblock 73 183 597 minecraft:calcite
fill 73 183 598 73 186 598 minecraft:cobbled_deepslate
fill 74 183 597 74 185 597 minecraft:cobbled_deepslate
setblock 77 183 598 minecraft:calcite
fill 78 183 598 78 186 598 minecraft:cobbled_deepslate
fill 81 183 597 81 183 598 minecraft:cobbled_deepslate
setblock 82 183 597 minecraft:cobbled_deepslate
setblock 82 183 598 minecraft:calcite
setblock 83 183 597 minecraft:calcite
fill 83 183 598 83 186 598 minecraft:cobbled_deepslate
setblock 84 183 596 minecraft:calcite
fill 84 183 597 84 186 597 minecraft:cobbled_deepslate
setblock 85 183 589 minecraft:cobbled_deepslate
setblock 85 183 590 minecraft:calcite
fill 85 183 591 85 186 591 minecraft:cobbled_deepslate
setblock 85 183 594 minecraft:cobbled_deepslate
fill 85 183 596 85 186 596 minecraft:cobbled_deepslate
setblock 86 183 569 minecraft:calcite
fill 86 183 570 86 184 571 minecraft:cobbled_deepslate
setblock 86 183 584 minecraft:calcite
fill 86 183 585 86 185 585 minecraft:cobbled_deepslate
setblock 86 183 589 minecraft:calcite
fill 86 183 590 86 186 590 minecraft:cobbled_deepslate
setblock 86 183 593 minecraft:cobbled_deepslate
setblock 86 183 594 minecraft:calcite
fill 86 183 595 86 186 595 minecraft:cobbled_deepslate
setblock 87 183 558 minecraft:calcite
setblock 87 183 564 minecraft:cobbled_deepslate
setblock 87 183 568 minecraft:calcite
fill 87 183 569 87 186 569 minecraft:cobbled_deepslate
setblock 87 183 573 minecraft:calcite
fill 87 183 574 87 183 577 minecraft:cobbled_deepslate
setblock 87 183 578 minecraft:calcite
fill 87 183 579 87 183 582 minecraft:cobbled_deepslate
setblock 87 183 583 minecraft:calcite
fill 87 183 584 87 186 584 minecraft:cobbled_deepslate
setblock 87 183 588 minecraft:calcite
fill 87 183 589 87 186 589 minecraft:cobbled_deepslate
setblock 87 183 593 minecraft:calcite
fill 87 183 594 87 186 594 minecraft:cobbled_deepslate
setblock 87 183 598 minecraft:calcite
setblock 88 183 558 minecraft:cobbled_deepslate
setblock 88 183 562 minecraft:calcite
fill 88 183 563 88 184 563 minecraft:cobbled_deepslate
setblock 88 183 567 minecraft:calcite
fill 88 183 568 88 186 568 minecraft:cobbled_deepslate
setblock 88 183 572 minecraft:calcite
fill 88 183 573 88 186 573 minecraft:cobbled_deepslate
setblock 88 183 577 minecraft:calcite
fill 88 183 578 88 186 578 minecraft:cobbled_deepslate
setblock 88 183 582 minecraft:calcite
fill 88 183 583 88 186 583 minecraft:cobbled_deepslate
setblock 88 183 587 minecraft:calcite
fill 88 183 588 88 186 588 minecraft:cobbled_deepslate
setblock 88 183 592 minecraft:calcite
fill 88 183 593 88 186 593 minecraft:cobbled_deepslate
setblock 88 183 597 minecraft:calcite
fill 88 183 598 88 186 598 minecraft:cobbled_deepslate
setblock 48 184 561 minecraft:calcite
fill 48 184 562 48 184 565 minecraft:cobbled_deepslate
setblock 48 184 566 minecraft:calcite
fill 48 184 567 48 184 570 minecraft:cobbled_deepslate
setblock 48 184 571 minecraft:calcite
fill 48 184 572 48 184 575 minecraft:cobbled_deepslate
setblock 48 184 576 minecraft:calcite
fill 48 184 577 48 187 577 minecraft:cobbled_deepslate
setblock 48 184 581 minecraft:calcite
fill 48 184 582 48 187 582 minecraft:cobbled_deepslate
setblock 48 184 586 minecraft:calcite
fill 48 184 587 48 187 587 minecraft:cobbled_deepslate
setblock 48 184 591 minecraft:calcite
fill 48 184 592 48 187 592 minecraft:cobbled_deepslate
setblock 48 184 596 minecraft:calcite
fill 48 184 597 48 187 597 minecraft:cobbled_deepslate
fill 49 184 563 49 184 564 minecraft:cobbled_deepslate
setblock 49 184 565 minecraft:calcite
fill 49 184 566 49 186 566 minecraft:cobbled_deepslate
setblock 49 184 570 minecraft:calcite
fill 49 184 571 49 187 571 minecraft:cobbled_deepslate
setblock 49 184 575 minecraft:calcite
fill 49 184 576 49 187 576 minecraft:cobbled_deepslate
setblock 49 184 580 minecraft:calcite
fill 49 184 581 49 185 581 minecraft:cobbled_deepslate
setblock 49 184 585 minecraft:calcite
fill 49 184 586 49 185 586 minecraft:cobbled_deepslate
setblock 49 184 590 minecraft:calcite
fill 49 184 591 49 186 591 minecraft:cobbled_deepslate
setblock 49 184 595 minecraft:calcite
setblock 49 184 596 minecraft:cobbled_deepslate
setblock 50 184 560 minecraft:light[level=14]
setblock 50 184 569 minecraft:calcite
fill 50 184 570 50 187 570 minecraft:cobbled_deepslate
setblock 50 184 574 minecraft:calcite
fill 50 184 575 50 187 575 minecraft:cobbled_deepslate
setblock 50 184 584 minecraft:light[level=14]
setblock 50 184 589 minecraft:calcite
setblock 50 184 590 minecraft:cobbled_deepslate
setblock 51 184 569 minecraft:cobbled_deepslate
setblock 58 184 560 minecraft:light[level=14]
setblock 58 184 568 minecraft:light[level=14]
setblock 58 184 576 minecraft:light[level=14]
setblock 58 184 584 minecraft:light[level=14]
setblock 58 184 592 minecraft:light[level=14]
fill 62 184 558 65 184 558 minecraft:cobbled_deepslate
fill 62 184 598 65 184 598 minecraft:cobbled_deepslate
fill 64 184 597 66 184 597 minecraft:cobbled_deepslate
setblock 65 184 559 minecraft:calcite
setblock 66 184 558 minecraft:calcite
fill 66 184 559 66 187 559 minecraft:cobbled_deepslate
setblock 66 184 560 minecraft:light[level=14]
setblock 66 184 568 minecraft:light[level=14]
setblock 66 184 576 minecraft:light[level=14]
setblock 66 184 584 minecraft:light[level=14]
setblock 66 184 592 minecraft:light[level=14]
fill 66 184 596 67 184 596 minecraft:cobbled_deepslate
setblock 66 184 598 minecraft:calcite
fill 67 184 558 67 187 558 minecraft:cobbled_deepslate
setblock 67 184 597 minecraft:calcite
fill 67 184 598 67 187 598 minecraft:cobbled_deepslate
setblock 68 184 596 minecraft:calcite
fill 68 184 597 68 187 597 minecraft:cobbled_deepslate
fill 69 184 596 69 187 596 minecraft:cobbled_deepslate
setblock 70 184 559 minecraft:calcite
setblock 71 184 558 minecraft:calcite
setblock 71 184 559 minecraft:cobbled_deepslate
setblock 71 184 598 minecraft:calcite
fill 72 184 558 72 186 558 minecraft:cobbled_deepslate
setblock 72 184 597 minecraft:calcite
fill 72 184 598 72 187 598 minecraft:cobbled_deepslate
fill 73 184 597 73 187 597 minecraft:cobbled_deepslate
setblock 74 184 560 minecraft:light[level=14]
setblock 74 184 568 minecraft:light[level=14]
setblock 74 184 576 minecraft:light[level=14]
setblock 74 184 584 minecraft:light[level=14]
setblock 74 184 592 minecraft:light[level=14]
setblock 76 184 598 minecraft:calcite
fill 77 184 598 77 187 598 minecraft:cobbled_deepslate
setblock 81 184 597 minecraft:cobbled_deepslate
setblock 81 184 598 minecraft:calcite
setblock 82 184 560 minecraft:light[level=14]
setblock 82 184 568 minecraft:light[level=14]
setblock 82 184 576 minecraft:light[level=14]
setblock 82 184 584 minecraft:light[level=14]
setblock 82 184 592 minecraft:light[level=14]
setblock 82 184 597 minecraft:calcite
fill 82 184 598 82 187 598 minecraft:cobbled_deepslate
setblock 83 184 596 minecraft:calcite
fill 83 184 597 83 187 597 minecraft:cobbled_deepslate
fill 84 184 596 84 187 596 minecraft:cobbled_deepslate
setblock 85 184 589 minecraft:calcite
fill 85 184 590 85 186 590 minecraft:cobbled_deepslate
setblock 85 184 594 minecraft:calcite
setblock 86 184 572 minecraft:cobbled_deepslate
setblock 86 184 584 minecraft:cobbled_deepslate
setblock 86 184 588 minecraft:calcite
fill 86 184 589 86 187 589 minecraft:cobbled_deepslate
setblock 86 184 593 minecraft:calcite
fill 86 184 594 86 187 594 minecraft:cobbled_deepslate
setblock 86 184 598 minecraft:calcite
setblock 87 184 567 minecraft:calcite
fill 87 184 568 87 187 568 minecraft:cobbled_deepslate
setblock 87 184 572 minecraft:calcite
fill 87 184 573 87 184 576 minecraft:cobbled_deepslate
setblock 87 184 577 minecraft:calcite
fill 87 184 578 87 184 581 minecraft:cobbled_deepslate
setblock 87 184 582 minecraft:calcite
fill 87 184 583 87 187 583 minecraft:cobbled_deepslate
setblock 87 184 587 minecraft:calcite
fill 87 184 588 87 187 588 minecraft:cobbled_deepslate
setblock 87 184 592 minecraft:calcite
fill 87 184 593 87 187 593 minecraft:cobbled_deepslate
setblock 87 184 597 minecraft:calcite
fill 87 184 598 87 187 598 minecraft:cobbled_deepslate
setblock 88 184 562 minecraft:cobbled_deepslate
setblock 88 184 566 minecraft:calcite
fill 88 184 567 88 187 567 minecraft:cobbled_deepslate
setblock 88 184 571 minecraft:calcite
fill 88 184 572 88 187 572 minecraft:cobbled_deepslate
setblock 88 184 576 minecraft:calcite
fill 88 184 577 88 187 577 minecraft:cobbled_deepslate
setblock 88 184 581 minecraft:calcite
fill 88 184 582 88 187 582 minecraft:cobbled_deepslate
setblock 88 184 586 minecraft:calcite
fill 88 184 587 88 187 587 minecraft:cobbled_deepslate
setblock 88 184 591 minecraft:calcite
fill 88 184 592 88 187 592 minecraft:cobbled_deepslate
setblock 88 184 596 minecraft:calcite
fill 88 184 597 88 187 597 minecraft:cobbled_deepslate
fill 48 185 562 48 185 564 minecraft:cobbled_deepslate
setblock 48 185 565 minecraft:calcite
fill 48 185 566 48 185 569 minecraft:cobbled_deepslate
setblock 48 185 570 minecraft:calcite
fill 48 185 571 48 185 574 minecraft:cobbled_deepslate
setblock 48 185 575 minecraft:calcite
fill 48 185 576 48 188 576 minecraft:cobbled_deepslate
setblock 48 185 580 minecraft:calcite
fill 48 185 581 48 188 581 minecraft:cobbled_deepslate
setblock 48 185 585 minecraft:calcite
fill 48 185 586 48 188 586 minecraft:cobbled_deepslate
setblock 48 185 590 minecraft:calcite
fill 48 185 591 48 188 591 minecraft:cobbled_deepslate
setblock 48 185 595 minecraft:calcite
fill 48 185 596 48 188 596 minecraft:cobbled_deepslate
setblock 49 185 564 minecraft:calcite
setblock 49 185 565 minecraft:cobbled_deepslate
setblock 49 185 569 minecraft:calcite
fill 49 185 570 49 188 570 minecraft:cobbled_deepslate
setblock 49 185 574 minecraft:calcite
fill 49 185 575 49 188 575 minecraft:cobbled_deepslate
setblock 49 185 579 minecraft:calcite
setblock 49 185 580 minecraft:cobbled_deepslate
setblock 49 185 584 minecraft:calcite
setblock 49 185 585 minecraft:cobbled_deepslate
setblock 49 185 589 minecraft:calcite
fill 49 185 590 49 186 590 minecraft:cobbled_deepslate
setblock 49 185 594 minecraft:calcite
setblock 49 185 595 minecraft:cobbled_deepslate
setblock 50 185 568 minecraft:calcite
fill 50 185 569 50 186 569 minecraft:cobbled_deepslate
setblock 50 185 573 minecraft:calcite
fill 50 185 574 50 188 574 minecraft:cobbled_deepslate
fill 61 185 558 64 185 558 minecraft:cobbled_deepslate
fill 62 185 598 64 185 598 minecraft:cobbled_deepslate
setblock 64 185 559 minecraft:calcite
fill 64 185 597 65 185 597 minecraft:cobbled_deepslate
setblock 65 185 558 minecraft:calcite
fill 65 185 559 65 188 559 minecraft:cobbled_deepslate
setblock 65 185 598 minecraft:calcite
fill 66 185 558 66 188 558 minecraft:cobbled_deepslate
setblock 66 185 596 minecraft:cobbled_deepslate
setblock 66 185 597 minecraft:calcite
fill 66 185 598 66 188 598 minecraft:cobbled_deepslate
setblock 67 185 596 minecraft:calcite
fill 67 185 597 67 188 597 minecraft:cobbled_deepslate
fill 68 185 596 68 188 596 minecraft:cobbled_deepslate
setblock 69 185 559 minecraft:calcite
setblock 70 185 558 minecraft:calcite
setblock 70 185 559 minecraft:cobbled_deepslate
setblock 70 185 598 minecraft:calcite
fill 71 185 558 71 188 558 minecraft:cobbled_deepslate
setblock 71 185 597 minecraft:calcite
fill 71 185 598 71 188 598 minecraft:cobbled_deepslate
fill 72 185 597 72 188 597 minecraft:cobbled_deepslate
setblock 75 185 598 minecraft:calcite
fill 76 185 598 76 188 598 minecraft:cobbled_deepslate
setblock 80 185 597 minecraft:cobbled_deepslate
setblock 80 185 598 minecraft:calcite
setblock 81 185 597 minecraft:calcite
fill 81 185 598 81 188 598 minecraft:cobbled_deepslate
fill 82 185 597 82 188 597 minecraft:cobbled_deepslate
fill 83 185 596 83 188 596 minecraft:cobbled_deepslate
setblock 85 185 589 minecraft:cobbled_deepslate
setblock 85 185 592 minecraft:cobbled_deepslate
setblock 85 185 593 minecraft:calcite
fill 85 185 594 85 186 594 minecraft:cobbled_deepslate
setblock 85 185 598 minecraft:calcite
setblock 86 185 571 minecraft:cobbled_deepslate
setblock 86 185 572 minecraft:calcite
fill 86 185 573 87 187 573 minecraft:cobbled_deepslate
setblock 86 185 587 minecraft:calcite
fill 86 185 588 86 187 588 minecraft:cobbled_deepslate
setblock 86 185 592 minecraft:calcite
fill 86 185 593 86 188 593 minecraft:cobbled_deepslate
setblock 86 185 597 minecraft:calcite
fill 86 185 598 86 188 598 minecraft:cobbled_deepslate
setblock 87 185 567 minecraft:cobbled_deepslate
setblock 87 185 571 minecraft:calcite
fill 87 185 572 87 188 572 minecraft:cobbled_deepslate
fill 87 185 574 87 185 575 minecraft:cobbled_deepslate
setblock 87 185 576 minecraft:calcite
fill 87 185 577 87 185 580 minecraft:cobbled_deepslate
setblock 87 185 581 minecraft:calcite
fill 87 185 582 87 188 582 minecraft:cobbled_deepslate
setblock 87 185 586 minecraft:calcite
fill 87 185 587 87 188 587 minecraft:cobbled_deepslate
setblock 87 185 591 minecraft:calcite
fill 87 185 592 87 188 592 minecraft:cobbled_deepslate
setblock 87 185 596 minecraft:calcite
fill 87 185 597 87 188 597 minecraft:cobbled_deepslate
setblock 88 185 565 minecraft:calcite
fill 88 185 566 88 187 566 minecraft:cobbled_deepslate
setblock 88 185 570 minecraft:calcite
fill 88 185 571 88 188 571 minecraft:cobbled_deepslate
setblock 88 185 575 minecraft:calcite
fill 88 185 576 88 188 576 minecraft:cobbled_deepslate
setblock 88 185 580 minecraft:calcite
fill 88 185 581 88 188 581 minecraft:cobbled_deepslate
setblock 88 185 585 minecraft:calcite
fill 88 185 586 88 188 586 minecraft:cobbled_deepslate
setblock 88 185 590 minecraft:calcite
fill 88 185 591 88 188 591 minecraft:cobbled_deepslate
setblock 88 185 595 minecraft:calcite
fill 88 185 596 88 188 596 minecraft:cobbled_deepslate
setblock 48 186 563 minecraft:cobbled_deepslate
setblock 48 186 564 minecraft:calcite
fill 48 186 565 48 186 568 minecraft:cobbled_deepslate
setblock 48 186 569 minecraft:calcite
fill 48 186 570 48 186 573 minecraft:cobbled_deepslate
setblock 48 186 574 minecraft:calcite
fill 48 186 575 48 189 575 minecraft:cobbled_deepslate
setblock 48 186 579 minecraft:calcite
fill 48 186 580 48 189 580 minecraft:cobbled_deepslate
setblock 48 186 584 minecraft:calcite
fill 48 186 585 48 188 585 minecraft:cobbled_deepslate
setblock 48 186 589 minecraft:calcite
fill 48 186 590 48 189 590 minecraft:cobbled_deepslate
setblock 48 186 594 minecraft:calcite
fill 48 186 595 48 189 595 minecraft:cobbled_deepslate
setblock 49 186 568 minecraft:calcite
fill 49 186 569 49 189 569 minecraft:cobbled_deepslate
setblock 49 186 573 minecraft:calcite
fill 49 186 574 49 189 574 minecraft:cobbled_deepslate
setblock 49 186 578 minecraft:calcite
fill 49 186 579 49 187 579 minecraft:cobbled_deepslate
setblock 49 186 588 minecraft:calcite
setblock 49 186 589 minecraft:cobbled_deepslate
setblock 49 186 593 minecraft:calcite
setblock 49 186 594 minecraft:cobbled_deepslate
setblock 50 186 568 minecraft:cobbled_deepslate
setblock 50 186 572 minecraft:calcite
fill 50 186 573 50 189 573 minecraft:cobbled_deepslate
fill 61 186 558 63 186 558 minecraft:cobbled_deepslate
fill 61 186 598 63 186 598 minecraft:cobbled_deepslate
fill 63 186 597 64 186 597 minecraft:cobbled_deepslate
setblock 64 186 558 minecraft:calcite
fill 64 186 559 64 189 559 minecraft:cobbled_deepslate
setblock 64 186 598 minecraft:calcite
fill 65 186 558 65 189 558 minecraft:cobbled_deepslate
setblock 65 186 596 minecraft:cobbled_deepslate
setblock 65 186 597 minecraft:calcite
fill 65 186 598 65 189 598 minecraft:cobbled_deepslate
setblock 66 186 596 minecraft:calcite
fill 66 186 597 66 189 597 minecraft:cobbled_deepslate
fill 67 186 596 67 189 596 minecraft:cobbled_deepslate
setblock 68 186 559 minecraft:calcite
setblock 69 186 558 minecraft:calcite
setblock 69 186 559 minecraft:cobbled_deepslate
setblock 69 186 598 minecraft:calcite
fill 70 186 558 70 189 558 minecraft:cobbled_deepslate
setblock 70 186 597 minecraft:calcite
fill 70 186 598 70 189 598 minecraft:cobbled_deepslate
fill 71 186 597 71 189 597 minecraft:cobbled_deepslate
setblock 74 186 598 minecraft:calcite
fill 75 186 598 75 189 598 minecraft:cobbled_deepslate
setblock 79 186 598 minecraft:calcite
setblock 80 186 597 minecraft:calcite
fill 80 186 598 80 189 598 minecraft:cobbled_deepslate
fill 81 186 597 81 189 597 minecraft:cobbled_deepslate
fill 82 186 596 82 189 596 minecraft:cobbled_deepslate
setblock 84 186 598 minecraft:calcite
setblock 85 186 592 minecraft:calcite
fill 85 186 593 85 187 593 minecraft:cobbled_deepslate
setblock 85 186 597 minecraft:calcite
fill 85 186 598 85 189 598 minecraft:cobbled_deepslate
setblock 86 186 571 minecraft:calcite
fill 86 186 572 86 189 572 minecraft:cobbled_deepslate
fill 86 186 574 87 186 574 minecraft:cobbled_deepslate
setblock 86 186 586 minecraft:calcite
fill 86 186 587 86 187 587 minecraft:cobbled_deepslate
setblock 86 186 591 minecraft:calcite
fill 86 186 592 86 189 592 minecraft:cobbled_deepslate
setblock 86 186 596 minecraft:calcite
fill 86 186 597 86 189 597 minecraft:cobbled_deepslate
setblock 87 186 570 minecraft:calcite
fill 87 186 571 87 189 571 minecraft:cobbled_deepslate
setblock 87 186 575 minecraft:calcite
fill 87 186 576 87 186 579 minecraft:cobbled_deepslate
setblock 87 186 580 minecraft:calcite
fill 87 186 581 87 189 581 minecraft:cobbled_deepslate
setblock 87 186 585 minecraft:calcite
fill 87 186 586 87 189 586 minecraft:cobbled_deepslate
setblock 87 186 590 minecraft:calcite
fill 87 186 591 87 189 591 minecraft:cobbled_deepslate
setblock 87 186 595 minecraft:calcite
fill 87 186 596 87 189 596 minecraft:cobbled_deepslate
setblock 88 186 565 minecraft:cobbled_deepslate
setblock 88 186 569 minecraft:calcite
fill 88 186 570 88 189 570 minecraft:cobbled_deepslate
setblock 88 186 574 minecraft:calcite
fill 88 186 575 88 189 575 minecraft:cobbled_deepslate
setblock 88 186 579 minecraft:calcite
fill 88 186 580 88 189 580 minecraft:cobbled_deepslate
setblock 88 186 584 minecraft:calcite
fill 88 186 585 88 189 585 minecraft:cobbled_deepslate
setblock 88 186 589 minecraft:calcite
fill 88 186 590 88 189 590 minecraft:cobbled_deepslate
setblock 88 186 594 minecraft:calcite
fill 88 186 595 88 189 595 minecraft:cobbled_deepslate
fill 48 187 564 48 187 567 minecraft:cobbled_deepslate
setblock 48 187 568 minecraft:calcite
fill 48 187 569 48 187 572 minecraft:cobbled_deepslate
setblock 48 187 573 minecraft:calcite
fill 48 187 574 48 190 574 minecraft:cobbled_deepslate
setblock 48 187 578 minecraft:calcite
fill 48 187 579 48 190 579 minecraft:cobbled_deepslate
setblock 48 187 583 minecraft:calcite
fill 48 187 584 48 188 584 minecraft:cobbled_deepslate
setblock 48 187 588 minecraft:calcite
fill 48 187 589 48 188 589 minecraft:cobbled_deepslate
setblock 48 187 593 minecraft:calcite
fill 48 187 594 48 190 594 minecraft:cobbled_deepslate
setblock 48 187 598 minecraft:calcite
setblock 49 187 567 minecraft:calcite
fill 49 187 568 49 189 568 minecraft:cobbled_deepslate
setblock 49 187 572 minecraft:calcite
fill 49 187 573 49 190 573 minecraft:cobbled_deepslate
setblock 49 187 577 minecraft:calcite
fill 49 187 578 49 190 578 minecraft:cobbled_deepslate
setblock 50 187 571 minecraft:calcite
fill 50 187 572 50 188 572 minecraft:cobbled_deepslate
fill 60 187 558 62 187 558 minecraft:cobbled_deepslate
fill 61 187 598 62 187 598 minecraft:cobbled_deepslate
fill 62 187 597 63 187 597 minecraft:cobbled_deepslate
setblock 63 187 558 minecraft:calcite
fill 63 187 559 63 190 559 minecraft:cobbled_deepslate
setblock 63 187 598 minecraft:calcite
fill 64 187 558 64 190 558 minecraft:cobbled_deepslate
setblock 64 187 597 minecraft:calcite
fill 64 187 598 64 190 598 minecraft:cobbled_deepslate
setblock 65 187 596 minecraft:calcite
fill 65 187 597 65 190 597 minecraft:cobbled_deepslate
fill 66 187 596 66 190 596 minecraft:cobbled_deepslate
setblock 67 187 559 minecraft:calcite
setblock 68 187 558 minecraft:calcite
setblock 68 187 559 minecraft:cobbled_deepslate
setblock 68 187 598 minecraft:calcite
fill 69 187 558 69 190 558 minecraft:cobbled_deepslate
setblock 69 187 597 minecraft:calcite
fill 69 187 598 69 190 598 minecraft:cobbled_deepslate
setblock 70 187 596 minecraft:calcite
fill 70 187 597 70 190 597 minecraft:cobbled_deepslate
setblock 73 187 598 minecraft:calcite
fill 74 187 598 74 190 598 minecraft:cobbled_deepslate
setblock 78 187 598 minecraft:calcite
setblock 79 187 597 minecraft:calcite
fill 79 187 598 79 190 598 minecraft:cobbled_deepslate
fill 80 187 597 80 190 597 minecraft:cobbled_deepslate
setblock 83 187 598 minecraft:calcite
setblock 84 187 597 minecraft:calcite
fill 84 187 598 84 190 598 minecraft:cobbled_deepslate
setblock 85 187 592 minecraft:cobbled_deepslate
setblock 85 187 596 minecraft:calcite
fill 85 187 597 85 190 597 minecraft:cobbled_deepslate
setblock 86 187 574 minecraft:cobbled_deepslate
setblock 86 187 575 minecraft:calcite
setblock 86 187 590 minecraft:calcite
fill 86 187 591 86 190 591 minecraft:cobbled_deepslate
setblock 86 187 595 minecraft:calcite
fill 86 187 596 86 190 596 minecraft:cobbled_deepslate
setblock 87 187 569 minecraft:calcite
fill 87 187 570 87 190 570 minecraft:cobbled_deepslate
setblock 87 187 574 minecraft:calcite
fill 87 187 575 87 187 578 minecraft:cobbled_deepslate
setblock 87 187 579 minecraft:calcite
fill 87 187 580 87 190 580 minecraft:cobbled_deepslate
setblock 87 187 584 minecraft:calcite
fill 87 187 585 87 188 585 minecraft:cobbled_deepslate
setblock 87 187 589 minecraft:calcite
fill 87 187 590 87 190 590 minecraft:cobbled_deepslate
setblock 87 187 594 minecraft:calcite
fill 87 187 595 87 190 595 minecraft:cobbled_deepslate
setblock 88 187 568 minecraft:calcite
fill 88 187 569 88 190 569 minecraft:cobbled_deepslate
setblock 88 187 573 minecraft:calcite
fill 88 187 574 88 190 574 minecraft:cobbled_deepslate
setblock 88 187 578 minecraft:calcite
fill 88 187 579 88 190 579 minecraft:cobbled_deepslate
setblock 88 187 583 minecraft:calcite
fill 88 187 584 88 190 584 minecraft:cobbled_deepslate
setblock 88 187 588 minecraft:calcite
fill 88 187 589 88 190 589 minecraft:cobbled_deepslate
setblock 88 187 593 minecraft:calcite
fill 88 187 594 88 190 594 minecraft:cobbled_deepslate
setblock 88 187 598 minecraft:calcite
fill 48 188 565 48 188 566 minecraft:cobbled_deepslate
setblock 48 188 567 minecraft:calcite
fill 48 188 568 48 188 571 minecraft:cobbled_deepslate
setblock 48 188 572 minecraft:calcite
fill 48 188 573 48 191 573 minecraft:cobbled_deepslate
setblock 48 188 577 minecraft:calcite
fill 48 188 578 48 191 578 minecraft:cobbled_deepslate
setblock 48 188 582 minecraft:calcite
setblock 48 188 583 minecraft:cobbled_deepslate
setblock 48 188 587 minecraft:calcite
setblock 48 188 588 minecraft:cobbled_deepslate
setblock 48 188 592 minecraft:calcite
fill 48 188 593 48 191 593 minecraft:cobbled_deepslate
setblock 48 188 597 minecraft:calcite
fill 48 188 598 48 191 598 minecraft:cobbled_deepslate
setblock 49 188 571 minecraft:calcite
fill 49 188 572 49 191 572 minecraft:cobbled_deepslate
setblock 49 188 576 minecraft:calcite
fill 49 188 577 49 191 577 minecraft:cobbled_deepslate
setblock 50 188 571 minecraft:cobbled_deepslate
fill 60 188 558 61 188 558 minecraft:cobbled_deepslate
fill 60 188 598 61 188 598 minecraft:cobbled_deepslate
setblock 62 188 558 minecraft:calcite
setblock 62 188 597 minecraft:cobbled_deepslate
setblock 62 188 598 minecraft:calcite
fill 63 188 558 63 191 558 minecraft:cobbled_deepslate
setblock 63 188 597 minecraft:calcite
fill 63 188 598 63 191 598 minecraft:cobbled_deepslate
setblock 64 188 596 minecraft:calcite
fill 64 188 597 64 191 597 minecraft:cobbled_deepslate
fill 65 188 596 65 191 596 minecraft:cobbled_deepslate
setblock 66 188 559 minecraft:calcite
setblock 67 188 558 minecraft:calcite
fill 67 188 559 67 191 559 minecraft:cobbled_deepslate
setblock 67 188 598 minecraft:calcite
fill 68 188 558 68 191 558 minecraft:cobbled_deepslate
setblock 68 188 597 minecraft:calcite
fill 68 188 598 68 191 598 minecraft:cobbled_deepslate
setblock 69 188 596 minecraft:calcite
fill 69 188 597 69 191 597 minecraft:cobbled_deepslate
setblock 72 188 598 minecraft:calcite
setblock 73 188 597 minecraft:calcite
fill 73 188 598 73 191 598 minecraft:cobbled_deepslate
setblock 77 188 598 minecraft:calcite
setblock 78 188 597 minecraft:calcite
fill 78 188 598 78 191 598 minecraft:cobbled_deepslate
fill 79 188 597 79 191 597 minecraft:cobbled_deepslate
fill 81 188 596 81 190 596 minecraft:cobbled_deepslate
setblock 82 188 598 minecraft:calcite
setblock 83 188 597 minecraft:calcite
fill 83 188 598 83 191 598 minecraft:cobbled_deepslate
setblock 84 188 596 minecraft:calcite
fill 84 188 597 84 191 597 minecraft:cobbled_deepslate
fill 85 188 596 85 191 596 minecraft:cobbled_deepslate
setblock 86 188 573 minecraft:cobbled_deepslate
setblock 86 188 574 minecraft:calcite
fill 86 188 575 87 189 576 minecraft:cobbled_deepslate
setblock 86 188 589 minecraft:calcite
fill 86 188 590 86 189 590 minecraft:cobbled_deepslate
setblock 86 188 594 minecraft:calcite
fill 86 188 595 86 191 595 minecraft:cobbled_deepslate
setblock 87 188 569 minecraft:cobbled_deepslate
setblock 87 188 573 minecraft:calcite
fill 87 188 574 87 191 574 minecraft:cobbled_deepslate
setblock 87 188 577 minecraft:cobbled_deepslate
setblock 87 188 578 minecraft:calcite
fill 87 188 579 87 191 579 minecraft:cobbled_deepslate
setblock 87 188 583 minecraft:calcite
setblock 87 188 584 minecraft:cobbled_deepslate
setblock 87 188 588 minecraft:calcite
fill 87 188 589 87 191 589 minecraft:cobbled_deepslate
setblock 87 188 593 minecraft:calcite
fill 87 188 594 87 191 594 minecraft:cobbled_deepslate
setblock 87 188 598 minecraft:calcite
setblock 88 188 567 minecraft:calcite
fill 88 188 568 88 191 568 minecraft:cobbled_deepslate
setblock 88 188 572 minecraft:calcite
fill 88 188 573 88 191 573 minecraft:cobbled_deepslate
setblock 88 188 577 minecraft:calcite
fill 88 188 578 88 191 578 minecraft:cobbled_deepslate
setblock 88 188 582 minecraft:calcite
fill 88 188 583 88 191 583 minecraft:cobbled_deepslate
setblock 88 188 587 minecraft:calcite
fill 88 188 588 88 191 588 minecraft:cobbled_deepslate
setblock 88 188 592 minecraft:calcite
fill 88 188 593 88 191 593 minecraft:cobbled_deepslate
setblock 88 188 597 minecraft:calcite
fill 88 188 598 88 191 598 minecraft:cobbled_deepslate
setblock 48 189 565 minecraft:cobbled_deepslate
setblock 48 189 566 minecraft:calcite
fill 48 189 567 48 189 570 minecraft:cobbled_deepslate
setblock 48 189 571 minecraft:calcite
fill 48 189 572 48 192 572 minecraft:cobbled_deepslate
setblock 48 189 576 minecraft:calcite
fill 48 189 577 48 192 577 minecraft:cobbled_deepslate
setblock 48 189 581 minecraft:calcite
fill 48 189 582 48 192 582 minecraft:cobbled_deepslate
setblock 48 189 591 minecraft:calcite
fill 48 189 592 48 190 592 minecraft:cobbled_deepslate
setblock 48 189 596 minecraft:calcite
fill 48 189 597 48 192 597 minecraft:cobbled_deepslate
setblock 49 189 570 minecraft:calcite
fill 49 189 571 49 192 571 minecraft:cobbled_deepslate
setblock 49 189 575 minecraft:calcite
fill 49 189 576 49 192 576 minecraft:cobbled_deepslate
setblock 50 189 574 minecraft:calcite
fill 58 189 558 60 189 558 minecraft:cobbled_deepslate
fill 59 189 598 60 189 598 minecraft:cobbled_deepslate
setblock 61 189 558 minecraft:calcite
fill 61 189 559 62 191 559 minecraft:cobbled_deepslate
setblock 61 189 597 minecraft:cobbled_deepslate
setblock 61 189 598 minecraft:calcite
fill 62 189 558 62 192 558 minecraft:cobbled_deepslate
setblock 62 189 597 minecraft:calcite
fill 62 189 598 62 192 598 minecraft:cobbled_deepslate
setblock 63 189 596 minecraft:calcite
fill 63 189 597 63 192 597 minecraft:cobbled_deepslate
fill 64 189 596 64 192 596 minecraft:cobbled_deepslate
setblock 65 189 559 minecraft:calcite
setblock 66 189 558 minecraft:calcite
fill 66 189 559 66 192 559 minecraft:cobbled_deepslate
setblock 66 189 598 minecraft:calcite
fill 67 189 558 67 192 558 minecraft:cobbled_deepslate
setblock 67 189 597 minecraft:calcite
fill 67 189 598 67 192 598 minecraft:cobbled_deepslate
setblock 68 189 596 minecraft:calcite
fill 68 189 597 68 192 597 minecraft:cobbled_deepslate
fill 69 189 596 69 192 596 minecraft:cobbled_deepslate
setblock 71 189 558 minecraft:calcite
setblock 71 189 598 minecraft:calcite
setblock 72 189 597 minecraft:calcite
fill 72 189 598 72 192 598 minecraft:cobbled_deepslate
fill 73 189 597 74 191 597 minecraft:cobbled_deepslate
setblock 76 189 597 minecraft:cobbled_deepslate
setblock 76 189 598 minecraft:calcite
setblock 77 189 597 minecraft:calcite
fill 77 189 598 77 192 598 minecraft:cobbled_deepslate
fill 78 189 597 78 192 597 minecraft:cobbled_deepslate
fill 80 189 596 80 191 596 minecraft:cobbled_deepslate
setblock 81 189 598 minecraft:calcite
setblock 82 189 597 minecraft:calcite
fill 82 189 598 82 192 598 minecraft:cobbled_deepslate
setblock 83 189 596 minecraft:calcite
fill 83 189 597 83 192 597 minecraft:cobbled_deepslate
fill 84 189 596 84 192 596 minecraft:cobbled_deepslate
setblock 86 189 573 minecraft:calcite
fill 86 189 574 86 192 574 minecraft:cobbled_deepslate
setblock 86 189 577 minecraft:cobbled_deepslate
setblock 86 189 578 minecraft:calcite
setblock 86 189 593 minecraft:calcite
fill 86 189 594 86 192 594 minecraft:cobbled_deepslate
setblock 86 189 598 minecraft:calcite
setblock 87 189 572 minecraft:calcite
fill 87 189 573 87 192 573 minecraft:cobbled_deepslate
setblock 87 189 577 minecraft:calcite
fill 87 189 578 87 192 578 minecraft:cobbled_deepslate
setblock 87 189 582 minecraft:calcite
setblock 87 189 587 minecraft:calcite
fill 87 189 588 87 190 588 minecraft:cobbled_deepslate
setblock 87 189 592 minecraft:calcite
fill 87 189 593 87 192 593 minecraft:cobbled_deepslate
setblock 87 189 597 minecraft:calcite
fill 87 189 598 87 192 598 minecraft:cobbled_deepslate
setblock 88 189 571 minecraft:calcite
fill 88 189 572 88 192 572 minecraft:cobbled_deepslate
setblock 88 189 576 minecraft:calcite
fill 88 189 577 88 192 577 minecraft:cobbled_deepslate
setblock 88 189 581 minecraft:calcite
fill 88 189 582 88 192 582 minecraft:cobbled_deepslate
setblock 88 189 586 minecraft:calcite
fill 88 189 587 88 192 587 minecraft:cobbled_deepslate
setblock 88 189 591 minecraft:calcite
fill 88 189 592 88 192 592 minecraft:cobbled_deepslate
setblock 88 189 596 minecraft:calcite
fill 88 189 597 88 192 597 minecraft:cobbled_deepslate
fill 48 190 566 48 190 569 minecraft:cobbled_deepslate
setblock 48 190 570 minecraft:calcite
fill 48 190 571 48 193 571 minecraft:cobbled_deepslate
setblock 48 190 575 minecraft:calcite
fill 48 190 576 48 193 576 minecraft:cobbled_deepslate
setblock 48 190 580 minecraft:calcite
fill 48 190 581 48 193 581 minecraft:cobbled_deepslate
fill 48 190 583 50 191 583 minecraft:light_blue_stained_glass
setblock 48 190 595 minecraft:calcite
fill 48 190 596 48 193 596 minecraft:cobbled_deepslate
setblock 49 190 569 minecraft:calcite
fill 49 190 570 49 193 570 minecraft:cobbled_deepslate
setblock 49 190 574 minecraft:calcite
fill 49 190 575 49 193 575 minecraft:cobbled_deepslate
setblock 49 190 579 minecraft:calcite
fill 49 190 581 50 194 582 minecraft:light_blue_stained_glass
fill 51 190 582 54 191 582 minecraft:light_blue_stained_glass
fill 57 190 558 59 190 558 minecraft:cobbled_deepslate
fill 58 190 598 59 190 598 minecraft:cobbled_deepslate
setblock 60 190 558 minecraft:calcite
fill 60 190 559 60 193 559 minecraft:cobbled_deepslate
setblock 60 190 597 minecraft:cobbled_deepslate
setblock 60 190 598 minecraft:calcite
fill 61 190 558 61 193 558 minecraft:cobbled_deepslate
setblock 61 190 597 minecraft:calcite
fill 61 190 598 61 193 598 minecraft:cobbled_deepslate
setblock 62 190 596 minecraft:calcite
fill 62 190 597 62 193 597 minecraft:cobbled_deepslate
fill 63 190 596 63 193 596 minecraft:cobbled_deepslate
setblock 64 190 559 minecraft:calcite
setblock 65 190 558 minecraft:calcite
fill 65 190 559 65 193 559 minecraft:cobbled_deepslate
setblock 65 190 598 minecraft:calcite
fill 66 190 558 66 193 558 minecraft:cobbled_deepslate
setblock 66 190 597 minecraft:calcite
fill 66 190 598 66 193 598 minecraft:cobbled_deepslate
setblock 67 190 596 minecraft:calcite
fill 67 190 597 67 193 597 minecraft:cobbled_deepslate
setblock 68 190 559 minecraft:cobbled_deepslate
fill 68 190 596 68 193 596 minecraft:cobbled_deepslate
setblock 70 190 558 minecraft:calcite
setblock 70 190 598 minecraft:calcite
fill 71 190 558 71 193 558 minecraft:cobbled_deepslate
setblock 71 190 597 minecraft:calcite
fill 71 190 598 71 193 598 minecraft:cobbled_deepslate
fill 72 190 597 72 193 597 minecraft:cobbled_deepslate
setblock 75 190 597 minecraft:cobbled_deepslate
setblock 75 190 598 minecraft:calcite
setblock 76 190 597 minecraft:calcite
fill 76 190 598 76 193 598 minecraft:cobbled_deepslate
fill 77 190 597 77 193 597 minecraft:cobbled_deepslate
fill 79 190 596 79 192 596 minecraft:cobbled_deepslate
setblock 80 190 598 minecraft:calcite
setblock 81 190 597 minecraft:calcite
fill 81 190 598 81 193 598 minecraft:cobbled_deepslate
fill 82 190 558 84 190 558 minecraft:cobbled_deepslate
setblock 82 190 596 minecraft:calcite
fill 82 190 597 82 193 597 minecraft:cobbled_deepslate
fill 83 190 596 83 193 596 minecraft:cobbled_deepslate
setblock 85 190 558 minecraft:calcite
setblock 85 190 598 minecraft:calcite
setblock 86 190 572 minecraft:calcite
fill 86 190 573 86 193 573 minecraft:cobbled_deepslate
fill 86 190 575 86 190 576 minecraft:cobbled_deepslate
setblock 86 190 577 minecraft:calcite
fill 86 190 578 86 192 579 minecraft:cobbled_deepslate
setblock 86 190 592 minecraft:calcite
fill 86 190 593 86 191 593 minecraft:cobbled_deepslate
setblock 86 190 597 minecraft:calcite
fill 86 190 598 86 193 598 minecraft:cobbled_deepslate
setblock 87 190 571 minecraft:calcite
fill 87 190 572 87 193 572 minecraft:cobbled_deepslate
setblock 87 190 575 minecraft:cobbled_deepslate
setblock 87 190 576 minecraft:calcite
fill 87 190 577 87 193 577 minecraft:cobbled_deepslate
setblock 87 190 581 minecraft:calcite
fill 87 190 582 87 192 583 minecraft:cobbled_deepslate
setblock 87 190 591 minecraft:calcite
fill 87 190 592 87 193 592 minecraft:cobbled_deepslate
setblock 87 190 596 minecraft:calcite
fill 87 190 597 87 193 597 minecraft:cobbled_deepslate
setblock 88 190 570 minecraft:calcite
fill 88 190 571 88 193 571 minecraft:cobbled_deepslate
setblock 88 190 575 minecraft:calcite
fill 88 190 576 88 193 576 minecraft:cobbled_deepslate
setblock 88 190 580 minecraft:calcite
fill 88 190 581 88 193 581 minecraft:cobbled_deepslate
setblock 88 190 585 minecraft:calcite
fill 88 190 586 88 193 586 minecraft:cobbled_deepslate
setblock 88 190 590 minecraft:calcite
fill 88 190 591 88 193 591 minecraft:cobbled_deepslate
setblock 88 190 595 minecraft:calcite
fill 88 190 596 88 193 596 minecraft:cobbled_deepslate
setblock 48 191 558 minecraft:cobbled_deepslate
setblock 48 191 559 minecraft:calcite
fill 48 191 566 48 191 568 minecraft:cobbled_deepslate
setblock 48 191 569 minecraft:calcite
fill 48 191 570 48 194 570 minecraft:cobbled_deepslate
setblock 48 191 574 minecraft:calcite
fill 48 191 575 48 194 575 minecraft:cobbled_deepslate
setblock 48 191 579 minecraft:calcite
fill 48 191 580 48 194 580 minecraft:cobbled_deepslate
fill 48 191 584 50 193 584 minecraft:light_blue_stained_glass
setblock 48 191 594 minecraft:calcite
fill 48 191 595 48 194 595 minecraft:cobbled_deepslate
setblock 49 191 569 minecraft:cobbled_deepslate
setblock 49 191 573 minecraft:calcite
fill 49 191 574 49 194 574 minecraft:cobbled_deepslate
setblock 49 191 578 minecraft:calcite
fill 49 191 579 49 194 579 minecraft:cobbled_deepslate
fill 49 191 580 50 192 580 minecraft:light_blue_stained_glass
setblock 49 191 598 minecraft:calcite
fill 51 191 581 53 191 581 minecraft:light_blue_stained_glass
fill 51 191 583 53 191 583 minecraft:light_blue_stained_glass
fill 55 191 558 58 191 558 minecraft:cobbled_deepslate
fill 56 191 598 58 191 598 minecraft:cobbled_deepslate
setblock 59 191 558 minecraft:calcite
fill 59 191 559 59 194 559 minecraft:cobbled_deepslate
setblock 59 191 597 minecraft:cobbled_deepslate
setblock 59 191 598 minecraft:calcite
fill 60 191 558 60 194 558 minecraft:cobbled_deepslate
setblock 60 191 597 minecraft:calcite
fill 60 191 598 60 194 598 minecraft:cobbled_deepslate
setblock 61 191 596 minecraft:calcite
fill 61 191 597 61 194 597 minecraft:cobbled_deepslate
fill 62 191 596 62 194 596 minecraft:cobbled_deepslate
setblock 63 191 559 minecraft:calcite
fill 63 191 560 63 194 560 minecraft:cobbled_deepslate
setblock 64 191 558 minecraft:calcite
fill 64 191 559 64 194 559 minecraft:cobbled_deepslate
setblock 64 191 598 minecraft:calcite
fill 65 191 558 65 194 558 minecraft:cobbled_deepslate
setblock 65 191 597 minecraft:calcite
fill 65 191 598 65 194 598 minecraft:cobbled_deepslate
setblock 66 191 596 minecraft:calcite
fill 66 191 597 66 194 597 minecraft:cobbled_deepslate
fill 67 191 596 67 194 596 minecraft:cobbled_deepslate
setblock 68 191 559 minecraft:calcite
setblock 69 191 558 minecraft:calcite
setblock 69 191 598 minecraft:calcite
fill 70 191 558 70 194 558 minecraft:cobbled_deepslate
setblock 70 191 597 minecraft:calcite
fill 70 191 598 70 194 598 minecraft:cobbled_deepslate
fill 71 191 597 71 194 597 minecraft:cobbled_deepslate
setblock 74 191 598 minecraft:calcite
setblock 75 191 597 minecraft:calcite
fill 75 191 598 75 194 598 minecraft:cobbled_deepslate
fill 76 191 597 76 194 597 minecraft:cobbled_deepslate
fill 78 191 596 78 193 596 minecraft:cobbled_deepslate
setblock 79 191 558 minecraft:calcite
setblock 79 191 598 minecraft:calcite
fill 80 191 558 83 191 558 minecraft:cobbled_deepslate
setblock 80 191 597 minecraft:calcite
fill 80 191 598 80 194 598 minecraft:cobbled_deepslate
setblock 81 191 596 minecraft:calcite
fill 81 191 597 81 194 597 minecraft:cobbled_deepslate
fill 82 191 596 82 194 596 minecraft:cobbled_deepslate
setblock 84 191 558 minecraft:calcite
setblock 84 191 598 minecraft:calcite
fill 85 191 558 86 193 558 minecraft:cobbled_deepslate
setblock 85 191 597 minecraft:calcite
fill 85 191 598 85 194 598 minecraft:cobbled_deepslate
fill 86 191 572 86 193 572 minecraft:cobbled_deepslate
setblock 86 191 575 minecraft:cobbled_deepslate
setblock 86 191 576 minecraft:calcite
fill 86 191 577 86 194 577 minecraft:cobbled_deepslate
setblock 86 191 580 minecraft:cobbled_deepslate
setblock 86 191 596 minecraft:calcite
fill 86 191 597 86 194 597 minecraft:cobbled_deepslate
setblock 87 191 570 minecraft:calcite
fill 87 191 571 87 194 571 minecraft:cobbled_deepslate
setblock 87 191 575 minecraft:calcite
fill 87 191 576 87 194 576 minecraft:cobbled_deepslate
setblock 87 191 580 minecraft:calcite
fill 87 191 581 87 194 581 minecraft:cobbled_deepslate
setblock 87 191 584 minecraft:cobbled_deepslate
setblock 87 191 590 minecraft:calcite
fill 87 191 591 87 192 591 minecraft:cobbled_deepslate
setblock 87 191 595 minecraft:calcite
fill 87 191 596 87 194 596 minecraft:cobbled_deepslate
setblock 88 191 569 minecraft:calcite
fill 88 191 570 88 194 570 minecraft:cobbled_deepslate
setblock 88 191 574 minecraft:calcite
fill 88 191 575 88 194 575 minecraft:cobbled_deepslate
setblock 88 191 579 minecraft:calcite
fill 88 191 580 88 194 580 minecraft:cobbled_deepslate
setblock 88 191 584 minecraft:calcite
fill 88 191 585 88 194 585 minecraft:cobbled_deepslate
setblock 88 191 589 minecraft:calcite
fill 88 191 590 88 194 590 minecraft:cobbled_deepslate
setblock 88 191 594 minecraft:calcite
fill 88 191 595 88 194 595 minecraft:cobbled_deepslate
setblock 48 192 558 minecraft:calcite
fill 48 192 559 48 193 561 minecraft:cobbled_deepslate
fill 48 192 565 48 192 567 minecraft:cobbled_deepslate
setblock 48 192 568 minecraft:calcite
fill 48 192 569 48 195 569 minecraft:cobbled_deepslate
setblock 48 192 573 minecraft:calcite
fill 48 192 574 48 195 574 minecraft:cobbled_deepslate
setblock 48 192 578 minecraft:calcite
fill 48 192 579 48 195 579 minecraft:cobbled_deepslate
setblock 48 192 583 minecraft:calcite
setblock 48 192 594 minecraft:cobbled_deepslate
setblock 48 192 598 minecraft:calcite
fill 49 192 558 52 192 558 minecraft:cobbled_deepslate
setblock 49 192 572 minecraft:calcite
fill 49 192 573 49 195 573 minecraft:cobbled_deepslate
setblock 49 192 577 minecraft:calcite
fill 49 192 578 49 195 578 minecraft:cobbled_deepslate
fill 49 192 583 52 192 583 minecraft:light_blue_stained_glass
fill 49 192 598 49 195 598 minecraft:cobbled_deepslate
setblock 50 192 560 minecraft:light[level=14]
setblock 50 192 568 minecraft:light[level=14]
setblock 50 192 576 minecraft:light[level=14]
setblock 50 192 592 minecraft:light[level=14]
fill 51 192 581 52 192 582 minecraft:light_blue_stained_glass
setblock 53 192 558 minecraft:calcite
setblock 53 192 582 minecraft:light_blue_stained_glass
fill 54 192 558 57 192 558 minecraft:cobbled_deepslate
fill 55 192 598 57 192 598 minecraft:cobbled_deepslate
setblock 57 192 559 minecraft:calcite
setblock 58 192 558 minecraft:calcite
fill 58 192 559 58 195 559 minecraft:cobbled_deepslate
setblock 58 192 560 minecraft:light[level=14]
setblock 58 192 568 minecraft:light[level=14]
setblock 58 192 576 minecraft:light[level=14]
setblock 58 192 584 minecraft:light[level=14]
setblock 58 192 592 minecraft:light[level=14]
setblock 58 192 597 minecraft:cobbled_deepslate
setblock 58 192 598 minecraft:calcite
fill 59 192 558 59 195 558 minecraft:cobbled_deepslate
setblock 59 192 597 minecraft:calcite
fill 59 192 598 59 195 598 minecraft:cobbled_deepslate
setblock 60 192 560 minecraft:cobbled_deepslate
setblock 60 192 596 minecraft:calcite
fill 60 192 597 60 195 597 minecraft:cobbled_deepslate
setblock 61 192 559 minecraft:cobbled_deepslate
setblock 61 192 560 minecraft:calcite
fill 61 192 596 61 195 596 minecraft:cobbled_deepslate
setblock 62 192 559 minecraft:calcite
fill 62 192 560 62 195 560 minecraft:cobbled_deepslate
setblock 63 192 558 minecraft:calcite
fill 63 192 559 63 195 559 minecraft:cobbled_deepslate
setblock 63 192 598 minecraft:calcite
fill 64 192 558 64 195 558 minecraft:cobbled_deepslate
fill 64 192 560 65 192 560 minecraft:cobbled_deepslate
setblock 64 192 597 minecraft:calcite
fill 64 192 598 64 195 598 minecraft:cobbled_deepslate
setblock 65 192 596 minecraft:calcite
fill 65 192 597 65 195 597 minecraft:cobbled_deepslate
setblock 66 192 560 minecraft:light[level=14]
setblock 66 192 568 minecraft:light[level=14]
setblock 66 192 576 minecraft:light[level=14]
setblock 66 192 584 minecraft:light[level=14]
setblock 66 192 592 minecraft:light[level=14]
fill 66 192 596 66 195 596 minecraft:cobbled_deepslate
setblock 67 192 559 minecraft:calcite
setblock 68 192 558 minecraft:calcite
fill 68 192 559 68 195 559 minecraft:cobbled_deepslate
setblock 68 192 598 minecraft:calcite
fill 69 192 558 69 195 558 minecraft:cobbled_deepslate
setblock 69 192 597 minecraft:calcite
fill 69 192 598 69 195 598 minecraft:cobbled_deepslate
setblock 70 192 596 minecraft:calcite
fill 70 192 597 70 195 597 minecraft:cobbled_deepslate
setblock 72 192 558 minecraft:cobbled_deepslate
setblock 73 192 558 minecraft:calcite
setblock 73 192 597 minecraft:cobbled_deepslate
setblock 73 192 598 minecraft:calcite
setblock 74 192 560 minecraft:light[level=14]
setblock 74 192 568 minecraft:light[level=14]
setblock 74 192 576 minecraft:light[level=14]
setblock 74 192 584 minecraft:light[level=14]
setblock 74 192 592 minecraft:light[level=14]
setblock 74 192 597 minecraft:calcite
fill 74 192 598 74 195 598 minecraft:cobbled_deepslate
fill 75 192 597 75 195 597 minecraft:cobbled_deepslate
fill 76 192 558 77 192 558 minecraft:cobbled_deepslate
fill 77 192 596 77 194 596 minecraft:cobbled_deepslate
setblock 78 192 558 minecraft:calcite
setblock 78 192 598 minecraft:calcite
fill 79 192 558 82 192 558 minecraft:cobbled_deepslate
setblock 79 192 597 minecraft:calcite
fill 79 192 598 79 195 598 minecraft:cobbled_deepslate
setblock 80 192 596 minecraft:calcite
fill 80 192 597 80 195 597 minecraft:cobbled_deepslate
fill 81 192 596 81 195 596 minecraft:cobbled_deepslate
setblock 82 192 560 minecraft:light[level=14]
setblock 82 192 568 minecraft:light[level=14]
setblock 82 192 576 minecraft:light[level=14]
setblock 82 192 584 minecraft:light[level=14]
setblock 82 192 592 minecraft:light[level=14]
fill 82 192 595 82 193 595 minecraft:cobbled_deepslate
setblock 83 192 558 minecraft:calcite
setblock 83 192 598 minecraft:calcite
fill 84 192 558 84 195 558 minecraft:cobbled_deepslate
setblock 84 192 597 minecraft:calcite
fill 84 192 598 84 195 598 minecraft:cobbled_deepslate
setblock 85 192 575 minecraft:cobbled_deepslate
setblock 85 192 576 minecraft:calcite
fill 85 192 577 85 194 578 minecraft:cobbled_deepslate
setblock 85 192 596 minecraft:calcite
fill 85 192 597 85 195 597 minecraft:cobbled_deepslate
setblock 86 192 575 minecraft:calcite
fill 86 192 576 86 195 576 minecraft:cobbled_deepslate
setblock 86 192 580 minecraft:calcite
fill 86 192 581 86 194 582 minecraft:cobbled_deepslate
setblock 86 192 595 minecraft:calcite
fill 86 192 596 86 193 596 minecraft:cobbled_deepslate
setblock 87 192 558 minecraft:cobbled_deepslate
setblock 87 192 570 minecraft:cobbled_deepslate
setblock 87 192 574 minecraft:calcite
fill 87 192 575 87 195 575 minecraft:cobbled_deepslate
setblock 87 192 579 minecraft:calcite
fill 87 192 580 87 195 580 minecraft:cobbled_deepslate
setblock 87 192 584 minecraft:calcite
setblock 87 192 594 minecraft:calcite
fill 87 192 595 87 194 595 minecraft:cobbled_deepslate
fill 88 192 569 88 195 569 minecraft:cobbled_deepslate
setblock 88 192 573 minecraft:calcite
fill 88 192 574 88 195 574 minecraft:cobbled_deepslate
setblock 88 192 578 minecraft:calcite
fill 88 192 579 88 195 579 minecraft:cobbled_deepslate
setblock 88 192 583 minecraft:calcite
fill 88 192 584 88 195 584 minecraft:cobbled_deepslate
setblock 88 192 588 minecraft:calcite
fill 88 192 589 88 194 589 minecraft:cobbled_deepslate
setblock 88 192 593 minecraft:calcite
fill 88 192 594 88 195 594 minecraft:cobbled_deepslate
setblock 88 192 598 minecraft:calcite
fill 48 193 558 51 193 558 minecraft:cobbled_deepslate
setblock 48 193 562 minecraft:calcite
fill 48 193 563 48 193 566 minecraft:cobbled_deepslate
setblock 48 193 567 minecraft:calcite
fill 48 193 568 48 196 568 minecraft:cobbled_deepslate
setblock 48 193 572 minecraft:calcite
fill 48 193 573 48 196 573 minecraft:cobbled_deepslate
setblock 48 193 577 minecraft:calcite
fill 48 193 578 48 196 578 minecraft:cobbled_deepslate
setblock 48 193 582 minecraft:calcite
fill 48 193 583 48 196 583 minecraft:cobbled_deepslate
setblock 48 193 597 minecraft:calcite
fill 48 193 598 48 196 598 minecraft:cobbled_deepslate
setblock 49 193 571 minecraft:calcite
fill 49 193 572 49 195 572 minecraft:cobbled_deepslate
setblock 49 193 576 minecraft:calcite
fill 49 193 577 49 196 577 minecraft:cobbled_deepslate
setblock 49 193 580 minecraft:cobbled_deepslate
fill 49 193 583 51 193 583 minecraft:light_blue_stained_glass
setblock 50 193 580 minecraft:light_blue_stained_glass
fill 50 193 598 51 193 598 minecraft:cobbled_deepslate
fill 51 193 581 51 193 582 minecraft:light_blue_stained_glass
setblock 52 193 558 minecraft:calcite
setblock 52 193 582 minecraft:light_blue_stained_glass
setblock 52 193 598 minecraft:calcite
fill 53 193 558 56 193 558 minecraft:cobbled_deepslate
fill 53 193 598 56 193 598 minecraft:cobbled_deepslate
setblock 55 193 559 minecraft:cobbled_deepslate
setblock 56 193 559 minecraft:calcite
fill 56 193 597 57 193 597 minecraft:cobbled_deepslate
setblock 57 193 558 minecraft:calcite
fill 57 193 559 57 196 559 minecraft:cobbled_deepslate
setblock 57 193 598 minecraft:calcite
fill 58 193 558 58 196 558 minecraft:cobbled_deepslate
fill 58 193 560 59 193 560 minecraft:cobbled_deepslate
setblock 58 193 597 minecraft:calcite
fill 58 193 598 58 196 598 minecraft:cobbled_deepslate
setblock 59 193 596 minecraft:calcite
fill 59 193 597 59 196 597 minecraft:cobbled_deepslate
setblock 60 193 560 minecraft:calcite
fill 60 193 596 60 196 596 minecraft:cobbled_deepslate
setblock 61 193 559 minecraft:calcite
fill 61 193 560 61 196 560 minecraft:cobbled_deepslate
setblock 62 193 558 minecraft:calcite
fill 62 193 559 62 196 559 minecraft:cobbled_deepslate
setblock 62 193 598 minecraft:calcite
fill 63 193 558 63 196 558 minecraft:cobbled_deepslate
setblock 63 193 597 minecraft:calcite
fill 63 193 598 63 196 598 minecraft:cobbled_deepslate
setblock 64 193 560 minecraft:cobbled_deepslate
setblock 64 193 596 minecraft:calcite
fill 64 193 597 64 196 597 minecraft:cobbled_deepslate
setblock 65 193 560 minecraft:calcite
fill 65 193 596 65 196 596 minecraft:cobbled_deepslate
setblock 66 193 559 minecraft:calcite
fill 66 193 560 66 196 560 minecraft:cobbled_deepslate
setblock 67 193 558 minecraft:calcite
fill 67 193 559 67 196 559 minecraft:cobbled_deepslate
setblock 67 193 598 minecraft:calcite
fill 68 193 558 68 196 558 minecraft:cobbled_deepslate
setblock 68 193 597 minecraft:calcite
fill 68 193 598 68 196 598 minecraft:cobbled_deepslate
fill 69 193 559 69 194 559 minecraft:cobbled_deepslate
setblock 69 193 596 minecraft:calcite
fill 69 193 597 69 196 597 minecraft:cobbled_deepslate
setblock 70 193 596 minecraft:cobbled_deepslate
setblock 72 193 558 minecraft:calcite
setblock 72 193 598 minecraft:calcite
fill 73 193 558 76 193 558 minecraft:cobbled_deepslate
setblock 73 193 597 minecraft:calcite
fill 73 193 598 73 196 598 minecraft:cobbled_deepslate
fill 74 193 597 74 196 597 minecraft:cobbled_deepslate
fill 76 193 596 76 195 596 minecraft:cobbled_deepslate
setblock 77 193 558 minecraft:calcite
setblock 77 193 598 minecraft:calcite
fill 78 193 558 81 193 558 minecraft:cobbled_deepslate
setblock 78 193 597 minecraft:calcite
fill 78 193 598 78 196 598 minecraft:cobbled_deepslate
setblock 79 193 596 minecraft:calcite
fill 79 193 597 79 196 597 minecraft:cobbled_deepslate
fill 80 193 596 80 196 596 minecraft:cobbled_deepslate
setblock 81 193 559 minecraft:calcite
fill 81 193 595 81 194 595 minecraft:cobbled_deepslate
setblock 82 193 558 minecraft:calcite
fill 82 193 559 84 194 559 minecraft:cobbled_deepslate
setblock 82 193 598 minecraft:calcite
fill 83 193 558 83 196 558 minecraft:cobbled_deepslate
setblock 83 193 597 minecraft:calcite
fill 83 193 598 83 196 598 minecraft:cobbled_deepslate
setblock 84 193 596 minecraft:calcite
fill 84 193 597 84 196 597 minecraft:cobbled_deepslate
setblock 85 193 575 minecraft:calcite
fill 85 193 576 85 196 576 minecraft:cobbled_deepslate
setblock 85 193 579 minecraft:cobbled_deepslate
setblock 85 193 580 minecraft:calcite
fill 85 193 596 85 194 596 minecraft:cobbled_deepslate
setblock 86 193 574 minecraft:calcite
fill 86 193 575 86 196 575 minecraft:cobbled_deepslate
setblock 86 193 578 minecraft:cobbled_deepslate
setblock 86 193 579 minecraft:calcite
fill 86 193 580 86 196 580 minecraft:cobbled_deepslate
setblock 86 193 583 minecraft:cobbled_deepslate
setblock 87 193 558 minecraft:calcite
setblock 87 193 573 minecraft:calcite
fill 87 193 574 87 196 574 minecraft:cobbled_deepslate
setblock 87 193 578 minecraft:calcite
fill 87 193 579 87 196 579 minecraft:cobbled_deepslate
setblock 87 193 582 minecraft:cobbled_deepslate
setblock 87 193 583 minecraft:calcite
fill 87 193 584 87 195 585 minecraft:cobbled_deepslate
setblock 87 193 593 minecraft:calcite
fill 87 193 594 87 194 594 minecraft:cobbled_deepslate
setblock 87 193 598 minecraft:calcite
fill 88 193 558 88 195 559 minecraft:cobbled_deepslate
setblock 88 193 572 minecraft:calcite
fill 88 193 573 88 196 573 minecraft:cobbled_deepslate
setblock 88 193 577 minecraft:calcite
fill 88 193 578 88 196 578 minecraft:cobbled_deepslate
setblock 88 193 582 minecraft:calcite
fill 88 193 583 88 196 583 minecraft:cobbled_deepslate
setblock 88 193 587 minecraft:calcite
fill 88 193 588 88 194 588 minecraft:cobbled_deepslate
setblock 88 193 592 minecraft:calcite
fill 88 193 593 88 195 593 minecraft:cobbled_deepslate
setblock 88 193 597 minecraft:calcite
fill 88 193 598 88 196 598 minecraft:cobbled_deepslate
fill 48 194 558 48 194 560 minecraft:cobbled_deepslate
setblock 48 194 561 minecraft:calcite
fill 48 194 562 48 194 565 minecraft:cobbled_deepslate
setblock 48 194 566 minecraft:calcite
fill 48 194 567 48 197 567 minecraft:cobbled_deepslate
setblock 48 194 571 minecraft:calcite
fill 48 194 572 48 197 572 minecraft:cobbled_deepslate
setblock 48 194 576 minecraft:calcite
fill 48 194 577 48 197 577 minecraft:cobbled_deepslate
setblock 48 194 581 minecraft:calcite
fill 48 194 582 48 197 582 minecraft:cobbled_deepslate
fill 48 194 584 49 194 584 minecraft:light_blue_stained_glass
setblock 48 194 596 minecraft:calcite
fill 48 194 597 48 196 597 minecraft:cobbled_deepslate
fill 49 194 558 50 194 558 minecraft:cobbled_deepslate
setblock 49 194 571 minecraft:cobbled_deepslate
setblock 49 194 575 minecraft:calcite
fill 49 194 576 49 197 576 minecraft:cobbled_deepslate
setblock 49 194 580 minecraft:calcite
fill 49 194 583 50 194 583 minecraft:light_blue_stained_glass
setblock 50 194 598 minecraft:cobbled_deepslate
setblock 51 194 558 minecraft:calcite
setblock 51 194 598 minecraft:calcite
fill 52 194 558 55 194 558 minecraft:cobbled_deepslate
fill 52 194 598 55 194 598 minecraft:cobbled_deepslate
fill 53 194 559 54 194 559 minecraft:cobbled_deepslate
setblock 55 194 559 minecraft:calcite
setblock 56 194 558 minecraft:calcite
fill 56 194 559 56 197 559 minecraft:cobbled_deepslate
setblock 56 194 597 minecraft:cobbled_deepslate
setblock 56 194 598 minecraft:calcite
fill 57 194 558 57 197 558 minecraft:cobbled_deepslate
fill 57 194 560 58 194 560 minecraft:cobbled_deepslate
setblock 57 194 597 minecraft:calcite
fill 57 194 598 57 197 598 minecraft:cobbled_deepslate
setblock 58 194 596 minecraft:calcite
fill 58 194 597 58 197 597 minecraft:cobbled_deepslate
setblock 59 194 560 minecraft:calcite
fill 59 194 596 59 197 596 minecraft:cobbled_deepslate
setblock 60 194 559 minecraft:calcite
fill 60 194 560 60 197 560 minecraft:cobbled_deepslate
setblock 61 194 558 minecraft:calcite
fill 61 194 559 61 197 559 minecraft:cobbled_deepslate
setblock 61 194 598 minecraft:calcite
fill 62 194 558 62 197 558 minecraft:cobbled_deepslate
setblock 62 194 597 minecraft:calcite
fill 62 194 598 62 197 598 minecraft:cobbled_deepslate
setblock 63 194 596 minecraft:calcite
fill 63 194 597 63 197 597 minecraft:cobbled_deepslate
setblock 64 194 560 minecraft:calcite
fill 64 194 596 64 197 596 minecraft:cobbled_deepslate
setblock 65 194 559 minecraft:calcite
fill 65 194 560 65 197 560 minecraft:cobbled_deepslate
setblock 66 194 558 minecraft:calcite
fill 66 194 559 66 197 559 minecraft:cobbled_deepslate
setblock 66 194 598 minecraft:calcite
fill 67 194 558 67 197 558 minecraft:cobbled_deepslate
setblock 67 194 597 minecraft:calcite
fill 67 194 598 67 197 598 minecraft:cobbled_deepslate
setblock 68 194 596 minecraft:calcite
fill 68 194 597 68 197 597 minecraft:cobbled_deepslate
fill 69 194 596 69 195 596 minecraft:cobbled_deepslate
setblock 71 194 558 minecraft:calcite
setblock 71 194 598 minecraft:calcite
fill 72 194 558 75 194 558 minecraft:cobbled_deepslate
setblock 72 194 597 minecraft:calcite
fill 72 194 598 72 197 598 minecraft:cobbled_deepslate
fill 73 194 597 73 197 597 minecraft:cobbled_deepslate
fill 75 194 596 75 196 596 minecraft:cobbled_deepslate
setblock 76 194 558 minecraft:calcite
setblock 76 194 598 minecraft:calcite
fill 77 194 558 80 194 558 minecraft:cobbled_deepslate
setblock 77 194 597 minecraft:calcite
fill 77 194 598 77 197 598 minecraft:cobbled_deepslate
fill 78 194 559 79 194 559 minecraft:cobbled_deepslate
setblock 78 194 596 minecraft:calcite
fill 78 194 597 78 197 597 minecraft:cobbled_deepslate
fill 79 194 596 79 197 596 minecraft:cobbled_deepslate
setblock 80 194 559 minecraft:calcite
setblock 80 194 595 minecraft:cobbled_deepslate
setblock 81 194 558 minecraft:calcite
fill 81 194 559 81 197 559 minecraft:cobbled_deepslate
setblock 81 194 598 minecraft:calcite
fill 82 194 558 82 197 558 minecraft:cobbled_deepslate
setblock 82 194 597 minecraft:calcite
fill 82 194 598 82 197 598 minecraft:cobbled_deepslate
setblock 83 194 596 minecraft:calcite
fill 83 194 597 83 197 597 minecraft:cobbled_deepslate
fill 84 194 596 84 195 596 minecraft:cobbled_deepslate
setblock 85 194 558 minecraft:cobbled_deepslate
setblock 85 194 559 minecraft:calcite
fill 85 194 575 85 195 575 minecraft:cobbled_deepslate
setblock 85 194 579 minecraft:calcite
fill 85 194 580 85 196 581 minecraft:cobbled_deepslate
setblock 86 194 558 minecraft:calcite
setblock 86 194 573 minecraft:calcite
fill 86 194 574 86 196 574 minecraft:cobbled_deepslate
setblock 86 194 578 minecraft:calcite
fill 86 194 579 86 197 579 minecraft:cobbled_deepslate
setblock 86 194 583 minecraft:calcite
setblock 86 194 598 minecraft:calcite
fill 87 194 558 87 197 558 minecraft:cobbled_deepslate
setblock 87 194 572 minecraft:calcite
fill 87 194 573 87 197 573 minecraft:cobbled_deepslate
setblock 87 194 577 minecraft:calcite
fill 87 194 578 87 197 578 minecraft:cobbled_deepslate
setblock 87 194 582 minecraft:calcite
fill 87 194 583 87 197 583 minecraft:cobbled_deepslate
setblock 87 194 597 minecraft:calcite
fill 87 194 598 87 197 598 minecraft:cobbled_deepslate
setblock 88 194 560 minecraft:cobbled_deepslate
setblock 88 194 571 minecraft:calcite
fill 88 194 572 88 197 572 minecraft:cobbled_deepslate
setblock 88 194 576 minecraft:calcite
fill 88 194 577 88 197 577 minecraft:cobbled_deepslate
setblock 88 194 581 minecraft:calcite
fill 88 194 582 88 197 582 minecraft:cobbled_deepslate
setblock 88 194 586 minecraft:calcite
fill 88 194 587 88 196 587 minecraft:cobbled_deepslate
setblock 88 194 591 minecraft:calcite
setblock 88 194 592 minecraft:cobbled_deepslate
setblock 88 194 596 minecraft:calcite
fill 88 194 597 88 196 597 minecraft:cobbled_deepslate
fill 48 195 558 48 195 559 minecraft:cobbled_deepslate
setblock 48 195 560 minecraft:calcite
fill 48 195 561 48 195 564 minecraft:cobbled_deepslate
setblock 48 195 565 minecraft:calcite
fill 48 195 566 48 198 566 minecraft:cobbled_deepslate
setblock 48 195 570 minecraft:calcite
fill 48 195 571 48 198 571 minecraft:cobbled_deepslate
setblock 48 195 575 minecraft:calcite
fill 48 195 576 48 198 576 minecraft:cobbled_deepslate
setblock 48 195 580 minecraft:calcite
fill 48 195 581 48 198 581 minecraft:cobbled_deepslate
setblock 48 195 596 minecraft:cobbled_deepslate
setblock 49 195 558 minecraft:cobbled_deepslate
setblock 49 195 559 minecraft:calcite
fill 49 195 560 49 198 560 minecraft:cobbled_deepslate
setblock 49 195 574 minecraft:calcite
fill 49 195 575 49 197 575 minecraft:cobbled_deepslate
setblock 49 195 579 minecraft:calcite
fill 49 195 580 49 197 580 minecraft:cobbled_deepslate
fill 49 195 581 49 195 583 minecraft:light_blue_stained_glass
setblock 50 195 558 minecraft:calcite
fill 50 195 559 53 195 559 minecraft:cobbled_deepslate
setblock 50 195 598 minecraft:calcite
fill 51 195 558 54 195 558 minecraft:cobbled_deepslate
fill 51 195 598 54 195 598 minecraft:cobbled_deepslate
setblock 54 195 559 minecraft:calcite
setblock 55 195 558 minecraft:calcite
fill 55 195 559 55 197 560 minecraft:cobbled_deepslate
setblock 55 195 597 minecraft:cobbled_deepslate
setblock 55 195 598 minecraft:calcite
fill 56 195 558 56 198 558 minecraft:cobbled_deepslate
fill 56 195 560 57 195 560 minecraft:cobbled_deepslate
setblock 56 195 597 minecraft:calcite
fill 56 195 598 56 198 598 minecraft:cobbled_deepslate
fill 57 195 597 57 198 597 minecraft:cobbled_deepslate
setblock 58 195 560 minecraft:calcite
fill 58 195 596 58 198 596 minecraft:cobbled_deepslate
setblock 59 195 559 minecraft:calcite
fill 59 195 560 59 197 561 minecraft:cobbled_deepslate
setblock 60 195 558 minecraft:calcite
fill 60 195 559 60 198 559 minecraft:cobbled_deepslate
fill 60 195 561 61 195 561 minecraft:cobbled_deepslate
setblock 60 195 598 minecraft:calcite
fill 61 195 558 61 198 558 minecraft:cobbled_deepslate
setblock 61 195 597 minecraft:calcite
fill 61 195 598 61 198 598 minecraft:cobbled_deepslate
setblock 62 195 561 minecraft:calcite
setblock 62 195 596 minecraft:calcite
fill 62 195 597 62 198 597 minecraft:cobbled_deepslate
setblock 63 195 560 minecraft:calcite
fill 63 195 561 63 197 561 minecraft:cobbled_deepslate
fill 63 195 596 63 198 596 minecraft:cobbled_deepslate
setblock 64 195 559 minecraft:calcite
fill 64 195 560 64 198 560 minecraft:cobbled_deepslate
setblock 65 195 558 minecraft:calcite
fill 65 195 559 65 198 559 minecraft:cobbled_deepslate
setblock 65 195 598 minecraft:calcite
fill 66 195 558 66 198 558 minecraft:cobbled_deepslate
setblock 66 195 597 minecraft:calcite
fill 66 195 598 66 198 598 minecraft:cobbled_deepslate
setblock 67 195 596 minecraft:calcite
fill 67 195 597 67 198 597 minecraft:cobbled_deepslate
setblock 68 195 596 minecraft:cobbled_deepslate
setblock 69 195 559 minecraft:calcite
setblock 70 195 558 minecraft:calcite
fill 70 195 559 70 196 559 minecraft:cobbled_deepslate
setblock 70 195 598 minecraft:calcite
fill 71 195 558 74 195 558 minecraft:cobbled_deepslate
setblock 71 195 597 minecraft:calcite
fill 71 195 598 71 198 598 minecraft:cobbled_deepslate
fill 72 195 597 72 198 597 minecraft:cobbled_deepslate
setblock 75 195 558 minecraft:calcite
setblock 75 195 598 minecraft:calcite
fill 76 195 558 78 195 559 minecraft:cobbled_deepslate
setblock 76 195 597 minecraft:calcite
fill 76 195 598 76 198 598 minecraft:cobbled_deepslate
setblock 77 195 596 minecraft:calcite
fill 77 195 597 77 198 597 minecraft:cobbled_deepslate
fill 78 195 596 78 198 596 minecraft:cobbled_deepslate
setblock 79 195 558 minecraft:cobbled_deepslate
setblock 79 195 559 minecraft:calcite
setblock 80 195 558 minecraft:calcite
fill 80 195 559 80 198 559 minecraft:cobbled_deepslate
setblock 80 195 598 minecraft:calcite
fill 81 195 558 81 198 558 minecraft:cobbled_deepslate
setblock 81 195 597 minecraft:calcite
fill 81 195 598 81 198 598 minecraft:cobbled_deepslate
fill 82 195 559 83 195 559 minecraft:cobbled_deepslate
setblock 82 195 596 minecraft:calcite
fill 82 195 597 82 198 597 minecraft:cobbled_deepslate
fill 83 195 596 83 196 596 minecraft:cobbled_deepslate
setblock 84 195 559 minecraft:calcite
setblock 85 195 558 minecraft:calcite
fill 85 195 559 86 196 559 minecraft:cobbled_deepslate
setblock 85 195 577 minecraft:cobbled_deepslate
setblock 85 195 578 minecraft:calcite
fill 85 195 579 85 198 579 minecraft:cobbled_deepslate
setblock 85 195 582 minecraft:cobbled_deepslate
setblock 85 195 598 minecraft:calcite
fill 86 195 558 86 198 558 minecraft:cobbled_deepslate
setblock 86 195 573 minecraft:cobbled_deepslate
setblock 86 195 577 minecraft:calcite
fill 86 195 578 86 198 578 minecraft:cobbled_deepslate
setblock 86 195 581 minecraft:cobbled_deepslate
setblock 86 195 582 minecraft:calcite
fill 86 195 583 86 196 584 minecraft:cobbled_deepslate
setblock 86 195 597 minecraft:calcite
fill 86 195 598 86 198 598 minecraft:cobbled_deepslate
setblock 87 195 571 minecraft:calcite
fill 87 195 572 87 196 572 minecraft:cobbled_deepslate
setblock 87 195 576 minecraft:calcite
fill 87 195 577 87 198 577 minecraft:cobbled_deepslate
setblock 87 195 581 minecraft:calcite
fill 87 195 582 87 198 582 minecraft:cobbled_deepslate
setblock 87 195 596 minecraft:calcite
setblock 87 195 597 minecraft:cobbled_deepslate
setblock 88 195 560 minecraft:calcite
fill 88 195 561 88 198 561 minecraft:cobbled_deepslate
setblock 88 195 570 minecraft:calcite
fill 88 195 571 88 197 571 minecraft:cobbled_deepslate
setblock 88 195 575 minecraft:calcite
fill 88 195 576 88 198 576 minecraft:cobbled_deepslate
setblock 88 195 580 minecraft:calcite
fill 88 195 581 88 198 581 minecraft:cobbled_deepslate
setblock 88 195 585 minecraft:calcite
fill 88 195 586 88 198 586 minecraft:cobbled_deepslate
setblock 88 195 595 minecraft:calcite
fill 88 195 596 88 196 596 minecraft:cobbled_deepslate
fill 47 196 557 47 198 557 minecraft:deepslate
fill 47 196 558 48 196 558 minecraft:cobbled_deepslate
setblock 47 196 564 minecraft:cobbled_deepslate
setblock 47 196 565 minecraft:deepslate
fill 47 196 566 47 196 569 minecraft:cobbled_deepslate
fill 47 196 590 47 197 591 minecraft:cobbled_deepslate
setblock 47 196 592 minecraft:deepslate
setblock 48 196 559 minecraft:calcite
fill 48 196 560 48 196 563 minecraft:cobbled_deepslate
setblock 48 196 564 minecraft:calcite
fill 48 196 565 48 199 565 minecraft:cobbled_deepslate
setblock 48 196 569 minecraft:calcite
fill 48 196 570 48 197 570 minecraft:cobbled_deepslate
setblock 48 196 574 minecraft:calcite
fill 48 196 575 48 199 575 minecraft:cobbled_deepslate
setblock 48 196 579 minecraft:calcite
fill 48 196 580 48 199 580 minecraft:cobbled_deepslate
setblock 48 196 584 minecraft:calcite
setblock 49 196 558 minecraft:calcite
fill 49 196 559 52 196 559 minecraft:cobbled_deepslate
fill 49 196 561 49 197 561 minecraft:cobbled_deepslate
setblock 49 196 573 minecraft:calcite
setblock 49 196 574 minecraft:cobbled_deepslate
setblock 49 196 578 minecraft:calcite
fill 49 196 579 49 197 579 minecraft:cobbled_deepslate
setblock 49 196 598 minecraft:calcite
fill 49 196 599 50 196 599 minecraft:deepslate
fill 50 196 558 53 196 558 minecraft:cobbled_deepslate
fill 50 196 598 53 196 598 minecraft:cobbled_deepslate
fill 53 196 557 53 199 557 minecraft:cobbled_deepslate
setblock 53 196 559 minecraft:calcite
fill 53 196 599 54 199 599 minecraft:cobbled_deepslate
setblock 54 196 557 minecraft:deepslate
setblock 54 196 558 minecraft:calcite
fill 54 196 559 54 198 560 minecraft:cobbled_deepslate
setblock 54 196 598 minecraft:calcite
fill 55 196 558 55 199 558 minecraft:cobbled_deepslate
setblock 55 196 597 minecraft:calcite
fill 55 196 598 55 199 598 minecraft:cobbled_deepslate
setblock 55 196 599 minecraft:deepslate
setblock 56 196 560 minecraft:cobbled_deepslate
fill 56 196 597 56 199 597 minecraft:cobbled_deepslate
fill 56 196 599 62 196 599 minecraft:cobbled_deepslate
setblock 57 196 560 minecraft:calcite
fill 57 196 561 58 198 561 minecraft:cobbled_deepslate
setblock 58 196 559 minecraft:calcite
fill 58 196 560 58 199 560 minecraft:cobbled_deepslate
fill 59 196 557 71 196 557 minecraft:cobbled_deepslate
setblock 59 196 558 minecraft:calcite
fill 59 196 559 59 199 559 minecraft:cobbled_deepslate
setblock 59 196 598 minecraft:calcite
fill 60 196 558 60 199 558 minecraft:cobbled_deepslate
setblock 60 196 561 minecraft:cobbled_deepslate
setblock 60 196 597 minecraft:calcite
fill 60 196 598 60 199 598 minecraft:cobbled_deepslate
setblock 61 196 561 minecraft:calcite
setblock 61 196 596 minecraft:calcite
fill 61 196 597 61 199 597 minecraft:cobbled_deepslate
setblock 62 196 560 minecraft:calcite
fill 62 196 561 62 198 561 minecraft:cobbled_deepslate
fill 62 196 596 62 198 596 minecraft:cobbled_deepslate
setblock 63 196 559 minecraft:calcite
fill 63 196 560 63 199 560 minecraft:cobbled_deepslate
setblock 64 196 558 minecraft:calcite
fill 64 196 559 64 199 559 minecraft:cobbled_deepslate
setblock 64 196 598 minecraft:calcite
fill 65 196 558 65 199 558 minecraft:cobbled_deepslate
setblock 65 196 597 minecraft:calcite
fill 65 196 598 65 199 598 minecraft:cobbled_deepslate
setblock 66 196 596 minecraft:calcite
fill 66 196 597 66 199 597 minecraft:cobbled_deepslate
fill 66 196 599 66 199 599 minecraft:cobbled_deepslate
setblock 67 196 596 minecraft:cobbled_deepslate
setblock 67 196 599 minecraft:deepslate
setblock 68 196 559 minecraft:calcite
fill 68 196 599 80 196 599 minecraft:cobbled_deepslate
setblock 69 196 558 minecraft:calcite
fill 69 196 559 69 197 559 minecraft:cobbled_deepslate
setblock 69 196 598 minecraft:calcite
fill 70 196 558 73 196 558 minecraft:cobbled_deepslate
setblock 70 196 597 minecraft:calcite
fill 70 196 598 70 199 598 minecraft:cobbled_deepslate
fill 71 196 597 71 198 597 minecraft:cobbled_deepslate
fill 72 196 557 72 197 557 minecraft:deepslate
fill 73 196 557 73 199 557 minecraft:cobbled_deepslate
setblock 74 196 558 minecraft:calcite
setblock 74 196 598 minecraft:calcite
fill 75 196 558 77 196 559 minecraft:cobbled_deepslate
setblock 75 196 597 minecraft:calcite
fill 75 196 598 75 199 598 minecraft:cobbled_deepslate
setblock 76 196 596 minecraft:calcite
fill 76 196 597 76 199 597 minecraft:cobbled_deepslate
fill 77 196 596 77 198 596 minecraft:cobbled_deepslate
setblock 78 196 558 minecraft:cobbled_deepslate
setblock 78 196 559 minecraft:calcite
setblock 79 196 558 minecraft:calcite
fill 79 196 559 79 199 559 minecraft:cobbled_deepslate
setblock 79 196 598 minecraft:calcite
fill 80 196 557 81 196 557 minecraft:deepslate
fill 80 196 558 80 199 558 minecraft:cobbled_deepslate
setblock 80 196 597 minecraft:calcite
fill 80 196 598 80 199 598 minecraft:cobbled_deepslate
setblock 81 196 596 minecraft:calcite
fill 81 196 597 81 199 597 minecraft:cobbled_deepslate
setblock 82 196 559 minecraft:cobbled_deepslate
fill 82 196 596 82 197 596 minecraft:cobbled_deepslate
setblock 83 196 559 minecraft:calcite
setblock 84 196 558 minecraft:calcite
fill 84 196 559 84 198 559 minecraft:cobbled_deepslate
setblock 84 196 598 minecraft:calcite
setblock 85 196 557 minecraft:deepslate
fill 85 196 558 85 199 558 minecraft:cobbled_deepslate
setblock 85 196 577 minecraft:calcite
fill 85 196 578 85 197 578 minecraft:cobbled_deepslate
setblock 85 196 582 minecraft:calcite
setblock 85 196 597 minecraft:calcite
fill 85 196 598 85 199 598 minecraft:cobbled_deepslate
setblock 86 196 576 minecraft:calcite
fill 86 196 577 86 198 577 minecraft:cobbled_deepslate
setblock 86 196 581 minecraft:calcite
fill 86 196 582 86 199 582 minecraft:cobbled_deepslate
fill 86 196 589 88 201 591 minecraft:light_blue_stained_glass
setblock 86 196 597 minecraft:cobbled_deepslate
setblock 87 196 575 minecraft:calcite
fill 87 196 576 87 199 576 minecraft:cobbled_deepslate
setblock 87 196 580 minecraft:calcite
fill 87 196 581 87 199 581 minecraft:cobbled_deepslate
setblock 87 196 584 minecraft:cobbled_deepslate
setblock 87 196 585 minecraft:calcite
setblock 88 196 558 minecraft:cobbled_deepslate
setblock 88 196 559 minecraft:calcite
fill 88 196 560 88 199 560 minecraft:cobbled_deepslate
fill 88 196 562 88 197 562 minecraft:cobbled_deepslate
fill 88 196 570 88 197 570 minecraft:cobbled_deepslate
setblock 88 196 574 minecraft:calcite
fill 88 196 575 88 199 575 minecraft:cobbled_deepslate
setblock 88 196 579 minecraft:calcite
fill 88 196 580 88 199 580 minecraft:cobbled_deepslate
setblock 88 196 584 minecraft:calcite
fill 88 196 585 89 199 585 minecraft:cobbled_deepslate
fill 89 196 576 89 196 578 minecraft:cobbled_deepslate
setblock 89 196 579 minecraft:deepslate
fill 89 196 584 89 199 584 minecraft:cobbled_deepslate
setblock 89 196 586 minecraft:deepslate
setblock 89 196 588 minecraft:deepslate
fill 89 196 589 89 200 589 minecraft:cobbled_deepslate
fill 47 197 558 47 200 558 minecraft:cobbled_deepslate
setblock 47 197 564 minecraft:deepslate
fill 47 197 565 47 197 568 minecraft:cobbled_deepslate
setblock 47 197 569 minecraft:deepslate
fill 47 197 574 48 199 574 minecraft:cobbled_deepslate
setblock 47 197 575 minecraft:deepslate
fill 47 197 592 47 199 592 minecraft:cobbled_deepslate
fill 47 197 594 47 197 595 minecraft:deepslate
fill 47 197 596 47 199 596 minecraft:cobbled_deepslate
setblock 47 197 597 minecraft:deepslate
fill 47 197 598 47 197 599 minecraft:cobbled_deepslate
setblock 48 197 557 minecraft:deepslate
setblock 48 197 558 minecraft:calcite
fill 48 197 559 48 197 562 minecraft:cobbled_deepslate
setblock 48 197 563 minecraft:calcite
fill 48 197 564 48 200 564 minecraft:cobbled_deepslate
setblock 48 197 568 minecraft:calcite
setblock 48 197 569 minecraft:cobbled_deepslate
setblock 48 197 573 minecraft:calcite
setblock 48 197 578 minecraft:calcite
fill 48 197 579 48 200 579 minecraft:cobbled_deepslate
setblock 48 197 583 minecraft:calcite
setblock 48 197 598 minecraft:calcite
fill 49 197 557 49 199 559 minecraft:cobbled_deepslate
setblock 49 197 562 minecraft:calcite
setblock 49 197 577 minecraft:calcite
setblock 49 197 578 minecraft:cobbled_deepslate
fill 49 197 598 50 197 599 minecraft:cobbled_deepslate
fill 50 197 557 50 198 557 minecraft:deepslate
fill 50 197 558 51 197 559 minecraft:cobbled_deepslate
fill 51 197 557 51 199 557 minecraft:cobbled_deepslate
fill 51 197 598 52 197 598 minecraft:cobbled_deepslate
setblock 51 197 599 minecraft:deepslate
setblock 52 197 558 minecraft:cobbled_deepslate
setblock 52 197 559 minecraft:calcite
fill 52 197 599 52 199 599 minecraft:cobbled_deepslate
setblock 53 197 558 minecraft:calcite
fill 53 197 559 53 199 560 minecraft:cobbled_deepslate
setblock 53 197 598 minecraft:calcite
fill 54 197 557 54 199 558 minecraft:cobbled_deepslate
fill 54 197 598 54 200 598 minecraft:cobbled_deepslate
fill 55 197 597 55 199 597 minecraft:cobbled_deepslate
fill 55 197 599 58 199 599 minecraft:cobbled_deepslate
setblock 56 197 560 minecraft:calcite
fill 56 197 561 56 200 561 minecraft:cobbled_deepslate
setblock 57 197 559 minecraft:calcite
fill 57 197 560 57 200 560 minecraft:cobbled_deepslate
setblock 58 197 558 minecraft:calcite
fill 58 197 559 58 200 559 minecraft:cobbled_deepslate
setblock 58 197 598 minecraft:calcite
fill 59 197 557 59 197 558 minecraft:cobbled_deepslate
setblock 59 197 597 minecraft:calcite
fill 59 197 598 59 200 598 minecraft:cobbled_deepslate
fill 59 197 599 60 197 599 minecraft:deepslate
fill 60 197 557 67 199 557 minecraft:cobbled_deepslate
setblock 60 197 561 minecraft:calcite
setblock 60 197 596 minecraft:calcite
fill 60 197 597 60 200 597 minecraft:cobbled_deepslate
setblock 61 197 560 minecraft:calcite
fill 61 197 561 61 199 561 minecraft:cobbled_deepslate
fill 61 197 596 61 199 596 minecraft:cobbled_deepslate
fill 61 197 599 62 197 599 minecraft:cobbled_deepslate
setblock 62 197 559 minecraft:calcite
fill 62 197 560 62 200 560 minecraft:cobbled_deepslate
setblock 63 197 558 minecraft:calcite
fill 63 197 559 63 200 559 minecraft:cobbled_deepslate
setblock 63 197 598 minecraft:calcite
fill 64 197 558 64 200 558 minecraft:cobbled_deepslate
setblock 64 197 597 minecraft:calcite
fill 64 197 598 64 200 598 minecraft:cobbled_deepslate
setblock 65 197 596 minecraft:calcite
fill 65 197 597 65 199 597 minecraft:cobbled_deepslate
setblock 65 197 599 minecraft:deepslate
setblock 66 197 560 minecraft:calcite
setblock 66 197 596 minecraft:cobbled_deepslate
setblock 67 197 559 minecraft:calcite
fill 67 197 599 73 197 599 minecraft:cobbled_deepslate
fill 68 197 557 69 197 557 minecraft:deepslate
setblock 68 197 558 minecraft:calcite
fill 68 197 559 68 198 559 minecraft:cobbled_deepslate
setblock 68 197 598 minecraft:calcite
fill 69 197 558 72 197 558 minecraft:cobbled_deepslate
setblock 69 197 597 minecraft:calcite
fill 69 197 598 69 200 598 minecraft:cobbled_deepslate
fill 70 197 557 71 199 557 minecraft:cobbled_deepslate
fill 70 197 597 70 198 597 minecraft:cobbled_deepslate
setblock 73 197 558 minecraft:calcite
setblock 73 197 598 minecraft:calcite
setblock 74 197 557 minecraft:deepslate
fill 74 197 558 76 197 559 minecraft:cobbled_deepslate
setblock 74 197 597 minecraft:calcite
fill 74 197 598 74 200 598 minecraft:cobbled_deepslate
setblock 74 197 599 minecraft:deepslate
fill 75 197 557 75 199 557 minecraft:cobbled_deepslate
fill 75 197 597 75 200 597 minecraft:cobbled_deepslate
fill 75 197 599 80 199 599 minecraft:cobbled_deepslate
setblock 76 197 596 minecraft:cobbled_deepslate
setblock 77 197 558 minecraft:cobbled_deepslate
setblock 77 197 559 minecraft:calcite
setblock 78 197 558 minecraft:calcite
fill 78 197 559 78 200 559 minecraft:cobbled_deepslate
setblock 78 197 598 minecraft:calcite
fill 79 197 558 79 200 558 minecraft:cobbled_deepslate
setblock 79 197 597 minecraft:calcite
fill 79 197 598 79 200 598 minecraft:cobbled_deepslate
fill 80 197 557 81 199 557 minecraft:cobbled_deepslate
setblock 80 197 596 minecraft:calcite
fill 80 197 597 80 200 597 minecraft:cobbled_deepslate
setblock 81 197 596 minecraft:cobbled_deepslate
setblock 82 197 559 minecraft:calcite
setblock 83 197 558 minecraft:calcite
fill 83 197 559 83 199 559 minecraft:cobbled_deepslate
setblock 83 197 598 minecraft:calcite
fill 84 197 558 84 200 558 minecraft:cobbled_deepslate
setblock 84 197 597 minecraft:calcite
fill 84 197 598 84 199 598 minecraft:cobbled_deepslate
fill 85 197 557 85 199 557 minecraft:cobbled_deepslate
fill 85 197 559 85 198 559 minecraft:cobbled_deepslate
setblock 85 197 577 minecraft:cobbled_deepslate
setblock 85 197 580 minecraft:cobbled_deepslate
setblock 85 197 581 minecraft:calcite
setblock 85 197 582 minecraft:cobbled_deepslate
fill 85 197 589 85 200 591 minecraft:light_blue_stained_glass
setblock 85 197 597 minecraft:cobbled_deepslate
setblock 86 197 575 minecraft:calcite
fill 86 197 576 86 198 576 minecraft:cobbled_deepslate
setblock 86 197 580 minecraft:calcite
fill 86 197 581 86 199 581 minecraft:cobbled_deepslate
fill 86 197 583 86 198 583 minecraft:cobbled_deepslate
fill 86 197 588 88 200 588 minecraft:light_blue_stained_glass
fill 86 197 592 88 200 592 minecraft:light_blue_stained_glass
setblock 87 197 574 minecraft:calcite
fill 87 197 575 87 198 575 minecraft:cobbled_deepslate
setblock 87 197 579 minecraft:calcite
fill 87 197 580 87 200 580 minecraft:cobbled_deepslate
setblock 87 197 584 minecraft:calcite
setblock 87 197 585 minecraft:cobbled_deepslate
setblock 88 197 558 minecraft:calcite
fill 88 197 559 88 199 559 minecraft:cobbled_deepslate
setblock 88 197 573 minecraft:calcite
fill 88 197 574 88 199 574 minecraft:cobbled_deepslate
setblock 88 197 578 minecraft:calcite
fill 88 197 579 89 199 579 minecraft:cobbled_deepslate
setblock 88 197 583 minecraft:calcite
fill 88 197 584 88 200 584 minecraft:cobbled_deepslate
setblock 88 197 598 minecraft:calcite
fill 89 197 558 89 199 558 minecraft:cobbled_deepslate
setblock 89 197 559 minecraft:deepslate
fill 89 197 560 89 199 564 minecraft:cobbled_deepslate
fill 89 197 567 89 199 568 minecraft:cobbled_deepslate
setblock 89 197 569 minecraft:deepslate
setblock 89 197 571 minecraft:deepslate
fill 89 197 576 89 197 577 minecraft:cobbled_deepslate
setblock 89 197 578 minecraft:deepslate
setblock 89 197 580 minecraft:deepslate
fill 89 197 586 89 199 586 minecraft:cobbled_deepslate
fill 89 197 588 89 199 588 minecraft:cobbled_deepslate
setblock 89 197 592 minecraft:deepslate
fill 89 197 597 89 199 597 minecraft:cobbled_deepslate
setblock 89 197 598 minecraft:deepslate
fill 47 198 564 47 199 565 minecraft:cobbled_deepslate
setblock 47 198 566 minecraft:deepslate
fill 47 198 567 47 199 569 minecraft:cobbled_deepslate
setblock 47 198 573 minecraft:deepslate
fill 47 198 575 47 199 575 minecraft:cobbled_deepslate
fill 47 198 587 47 199 587 minecraft:cobbled_deepslate
setblock 47 198 588 minecraft:deepslate
fill 47 198 590 47 199 590 minecraft:cobbled_deepslate
setblock 47 198 591 minecraft:deepslate
fill 47 198 594 47 199 595 minecraft:cobbled_deepslate
fill 47 198 597 47 199 598 minecraft:cobbled_deepslate
setblock 47 198 599 minecraft:deepslate
fill 48 198 557 48 198 561 minecraft:cobbled_deepslate
setblock 48 198 562 minecraft:calcite
fill 48 198 563 48 201 563 minecraft:cobbled_deepslate
setblock 48 198 567 minecraft:calcite
setblock 48 198 572 minecraft:calcite
setblock 48 198 573 minecraft:cobbled_deepslate
setblock 48 198 577 minecraft:calcite
fill 48 198 578 48 200 578 minecraft:cobbled_deepslate
setblock 48 198 582 minecraft:calcite
fill 48 198 583 48 199 583 minecraft:cobbled_deepslate
setblock 49 198 561 minecraft:calcite
fill 49 198 562 49 201 562 minecraft:cobbled_deepslate
fill 49 198 599 49 199 599 minecraft:cobbled_deepslate
fill 50 198 558 50 198 559 minecraft:cobbled_deepslate
setblock 50 198 599 minecraft:deepslate
setblock 51 198 558 minecraft:cobbled_deepslate
setblock 51 198 559 minecraft:calcite
fill 51 198 598 51 198 599 minecraft:cobbled_deepslate
setblock 52 198 558 minecraft:calcite
fill 52 198 559 52 200 560 minecraft:cobbled_deepslate
setblock 52 198 598 minecraft:calcite
fill 53 198 558 53 201 558 minecraft:cobbled_deepslate
fill 53 198 598 53 201 598 minecraft:cobbled_deepslate
setblock 55 198 559 minecraft:cobbled_deepslate
setblock 55 198 560 minecraft:calcite
setblock 56 198 559 minecraft:calcite
fill 56 198 560 56 201 560 minecraft:cobbled_deepslate
setblock 57 198 558 minecraft:calcite
fill 57 198 559 57 201 559 minecraft:cobbled_deepslate
setblock 57 198 598 minecraft:calcite
fill 58 198 558 59 200 558 minecraft:cobbled_deepslate
setblock 58 198 597 minecraft:calcite
fill 58 198 598 58 201 598 minecraft:cobbled_deepslate
setblock 59 198 557 minecraft:deepslate
setblock 59 198 560 minecraft:cobbled_deepslate
setblock 59 198 561 minecraft:calcite
setblock 59 198 596 minecraft:calcite
fill 59 198 597 59 201 597 minecraft:cobbled_deepslate
fill 59 198 599 60 199 599 minecraft:cobbled_deepslate
setblock 60 198 560 minecraft:calcite
fill 60 198 561 60 200 561 minecraft:cobbled_deepslate
fill 60 198 596 60 199 596 minecraft:cobbled_deepslate
setblock 61 198 559 minecraft:calcite
fill 61 198 560 61 201 560 minecraft:cobbled_deepslate
setblock 61 198 599 minecraft:deepslate
setblock 62 198 558 minecraft:calcite
fill 62 198 559 62 201 559 minecraft:cobbled_deepslate
setblock 62 198 598 minecraft:calcite
fill 62 198 599 62 199 599 minecraft:cobbled_deepslate
fill 63 198 558 63 201 558 minecraft:cobbled_deepslate
setblock 63 198 597 minecraft:calcite
fill 63 198 598 63 201 598 minecraft:cobbled_deepslate
setblock 64 198 596 minecraft:calcite
fill 64 198 597 64 200 597 minecraft:cobbled_deepslate
setblock 65 198 560 minecraft:calcite
fill 65 198 599 65 199 599 minecraft:cobbled_deepslate
setblock 66 198 559 minecraft:calcite
setblock 67 198 558 minecraft:calcite
fill 67 198 559 67 199 559 minecraft:cobbled_deepslate
setblock 67 198 598 minecraft:calcite
fill 67 198 599 68 199 599 minecraft:cobbled_deepslate
setblock 68 198 557 minecraft:deepslate
fill 68 198 558 71 198 558 minecraft:cobbled_deepslate
setblock 68 198 597 minecraft:calcite
fill 68 198 598 68 201 598 minecraft:cobbled_deepslate
fill 69 198 557 69 199 557 minecraft:cobbled_deepslate
setblock 69 198 597 minecraft:cobbled_deepslate
setblock 69 198 599 minecraft:deepslate
fill 70 198 599 74 199 599 minecraft:cobbled_deepslate
fill 72 198 557 72 199 557 minecraft:cobbled_deepslate
setblock 72 198 558 minecraft:calcite
setblock 72 198 598 minecraft:calcite
fill 73 198 558 76 198 558 minecraft:cobbled_deepslate
setblock 73 198 597 minecraft:calcite
fill 73 198 598 73 201 598 minecraft:cobbled_deepslate
fill 74 198 557 74 199 557 minecraft:cobbled_deepslate
fill 74 198 559 75 198 559 minecraft:cobbled_deepslate
fill 74 198 597 74 199 597 minecraft:cobbled_deepslate
fill 76 198 557 78 199 557 minecraft:cobbled_deepslate
setblock 76 198 559 minecraft:calcite
setblock 77 198 558 minecraft:calcite
fill 77 198 559 77 201 559 minecraft:cobbled_deepslate
setblock 77 198 598 minecraft:calcite
fill 78 198 558 78 201 558 minecraft:cobbled_deepslate
setblock 78 198 597 minecraft:calcite
fill 78 198 598 78 201 598 minecraft:cobbled_deepslate
setblock 79 198 557 minecraft:deepslate
setblock 79 198 596 minecraft:calcite
fill 79 198 597 79 200 597 minecraft:cobbled_deepslate
setblock 80 198 596 minecraft:cobbled_deepslate
setblock 81 198 559 minecraft:calcite
setblock 82 198 558 minecraft:calcite
fill 82 198 559 82 200 559 minecraft:cobbled_deepslate
setblock 82 198 598 minecraft:calcite
fill 83 198 558 83 201 558 minecraft:cobbled_deepslate
fill 83 198 590 84 199 590 minecraft:light_blue_stained_glass
setblock 83 198 597 minecraft:calcite
fill 83 198 598 83 200 598 minecraft:cobbled_deepslate
setblock 84 198 557 minecraft:deepslate
fill 84 198 589 84 199 589 minecraft:light_blue_stained_glass
fill 84 198 591 84 199 591 minecraft:light_blue_stained_glass
setblock 85 198 580 minecraft:calcite
setblock 85 198 581 minecraft:cobbled_deepslate
fill 85 198 588 85 199 588 minecraft:light_blue_stained_glass
fill 85 198 592 85 199 592 minecraft:light_blue_stained_glass
setblock 86 198 579 minecraft:calcite
fill 86 198 580 86 199 580 minecraft:cobbled_deepslate
setblock 87 198 558 minecraft:calcite
setblock 87 198 574 minecraft:cobbled_deepslate
setblock 87 198 578 minecraft:calcite
fill 87 198 579 87 200 579 minecraft:cobbled_deepslate
setblock 87 198 583 minecraft:calcite
fill 87 198 584 87 199 584 minecraft:cobbled_deepslate
fill 87 198 587 87 199 587 minecraft:light_blue_stained_glass
fill 87 198 593 87 199 593 minecraft:light_blue_stained_glass
fill 88 198 558 88 199 558 minecraft:cobbled_deepslate
setblock 88 198 562 minecraft:calcite
fill 88 198 563 88 201 563 minecraft:cobbled_deepslate
setblock 88 198 572 minecraft:calcite
fill 88 198 573 88 199 573 minecraft:cobbled_deepslate
setblock 88 198 577 minecraft:calcite
fill 88 198 578 89 199 578 minecraft:cobbled_deepslate
setblock 88 198 582 minecraft:calcite
fill 88 198 583 88 201 583 minecraft:cobbled_deepslate
fill 89 198 559 89 199 559 minecraft:cobbled_deepslate
fill 89 198 569 89 199 569 minecraft:cobbled_deepslate
fill 89 198 571 89 200 571 minecraft:cobbled_deepslate
setblock 89 198 576 minecraft:deepslate
fill 89 198 577 89 199 577 minecraft:cobbled_deepslate
fill 89 198 580 89 199 580 minecraft:cobbled_deepslate
setblock 89 198 587 minecraft:deepslate
fill 89 198 592 89 199 592 minecraft:cobbled_deepslate
setblock 89 198 593 minecraft:deepslate
fill 89 198 598 89 199 598 minecraft:cobbled_deepslate
fill 47 199 557 48 199 557 minecraft:cobbled_deepslate
setblock 47 199 566 minecraft:cobbled_deepslate
setblock 47 199 573 minecraft:cobbled_deepslate
setblock 47 199 588 minecraft:cobbled_deepslate
setblock 47 199 591 minecraft:cobbled_deepslate
setblock 47 199 599 minecraft:cobbled_deepslate
fill 48 199 558 48 199 560 minecraft:cobbled_deepslate
setblock 48 199 561 minecraft:calcite
fill 48 199 562 48 202 562 minecraft:cobbled_deepslate
setblock 48 199 566 minecraft:calcite
setblock 48 199 576 minecraft:calcite
fill 48 199 577 48 200 577 minecraft:cobbled_deepslate
setblock 48 199 581 minecraft:calcite
fill 48 199 582 48 200 582 minecraft:cobbled_deepslate
setblock 49 199 560 minecraft:calcite
fill 49 199 561 49 202 561 minecraft:cobbled_deepslate
fill 50 199 557 50 199 558 minecraft:cobbled_deepslate
setblock 50 199 559 minecraft:calcite
fill 50 199 599 51 199 599 minecraft:cobbled_deepslate
setblock 51 199 558 minecraft:calcite
fill 51 199 559 51 202 559 minecraft:cobbled_deepslate
fill 52 199 558 52 202 558 minecraft:cobbled_deepslate
setblock 52 199 598 minecraft:cobbled_deepslate
setblock 54 199 559 minecraft:cobbled_deepslate
setblock 54 199 560 minecraft:calcite
setblock 55 199 559 minecraft:calcite
fill 55 199 560 55 201 561 minecraft:cobbled_deepslate
setblock 56 199 558 minecraft:calcite
fill 56 199 559 56 202 559 minecraft:cobbled_deepslate
setblock 56 199 598 minecraft:calcite
fill 57 199 558 57 202 558 minecraft:cobbled_deepslate
setblock 57 199 561 minecraft:cobbled_deepslate
setblock 57 199 597 minecraft:calcite
fill 57 199 598 57 202 598 minecraft:cobbled_deepslate
setblock 58 199 561 minecraft:calcite
fill 58 199 597 58 202 597 minecraft:cobbled_deepslate
setblock 59 199 557 minecraft:cobbled_deepslate
setblock 59 199 560 minecraft:calcite
fill 59 199 561 59 201 561 minecraft:cobbled_deepslate
setblock 60 199 559 minecraft:calcite
fill 60 199 560 60 202 560 minecraft:cobbled_deepslate
setblock 61 199 558 minecraft:calcite
fill 61 199 559 61 202 559 minecraft:cobbled_deepslate
setblock 61 199 598 minecraft:calcite
fill 61 199 599 61 200 599 minecraft:cobbled_deepslate
fill 62 199 558 62 202 558 minecraft:cobbled_deepslate
setblock 62 199 597 minecraft:calcite
fill 62 199 598 62 202 598 minecraft:cobbled_deepslate
fill 63 199 597 63 200 597 minecraft:cobbled_deepslate
setblock 64 199 560 minecraft:calcite
setblock 65 199 559 minecraft:calcite
setblock 66 199 558 minecraft:calcite
fill 66 199 559 66 200 559 minecraft:cobbled_deepslate
setblock 66 199 598 minecraft:calcite
fill 67 199 558 70 199 558 minecraft:cobbled_deepslate
setblock 67 199 597 minecraft:calcite
fill 67 199 598 67 201 598 minecraft:cobbled_deepslate
setblock 68 199 557 minecraft:cobbled_deepslate
setblock 69 199 599 minecraft:cobbled_deepslate
setblock 71 199 558 minecraft:calcite
setblock 71 199 598 minecraft:calcite
fill 72 199 558 75 199 558 minecraft:cobbled_deepslate
fill 72 199 598 72 202 598 minecraft:cobbled_deepslate
setblock 73 199 597 minecraft:cobbled_deepslate
setblock 75 199 559 minecraft:calcite
setblock 76 199 558 minecraft:calcite
fill 76 199 559 76 201 559 minecraft:cobbled_deepslate
setblock 76 199 598 minecraft:calcite
fill 77 199 558 77 202 558 minecraft:cobbled_deepslate
setblock 77 199 597 minecraft:calcite
fill 77 199 598 77 202 598 minecraft:cobbled_deepslate
fill 78 199 597 78 200 597 minecraft:cobbled_deepslate
setblock 79 199 557 minecraft:cobbled_deepslate
setblock 80 199 559 minecraft:calcite
setblock 81 199 558 minecraft:calcite
fill 81 199 559 81 200 559 minecraft:cobbled_deepslate
setblock 81 199 598 minecraft:calcite
fill 82 199 558 82 202 558 minecraft:cobbled_deepslate
setblock 82 199 597 minecraft:calcite
fill 82 199 598 82 200 598 minecraft:cobbled_deepslate
setblock 84 199 557 minecraft:cobbled_deepslate
setblock 86 199 558 minecraft:calcite
setblock 86 199 578 minecraft:calcite
setblock 86 199 579 minecraft:cobbled_deepslate
setblock 87 199 558 minecraft:cobbled_deepslate
setblock 87 199 577 minecraft:calcite
fill 87 199 578 87 200 578 minecraft:cobbled_deepslate
setblock 87 199 582 minecraft:calcite
fill 87 199 583 87 200 583 minecraft:cobbled_deepslate
setblock 88 199 561 minecraft:calcite
fill 88 199 562 88 202 562 minecraft:cobbled_deepslate
setblock 88 199 576 minecraft:calcite
fill 88 199 577 88 201 577 minecraft:cobbled_deepslate
setblock 88 199 581 minecraft:calcite
fill 88 199 582 88 202 582 minecraft:cobbled_deepslate
setblock 89 199 576 minecraft:cobbled_deepslate
setblock 89 199 587 minecraft:cobbled_deepslate
setblock 89 199 593 minecraft:cobbled_deepslate
setblock 47 200 557 minecraft:cobbled_deepslate
fill 47 200 559 47 200 570 minecraft:deepslate
fill 47 200 571 47 200 572 minecraft:cobbled_deepslate
fill 47 200 573 47 278 580 minecraft:deepslate
fill 47 200 581 48 200 581 minecraft:cobbled_deepslate
fill 47 200 582 47 201 599 minecraft:deepslate
fill 48 200 557 56 201 557 minecraft:deepslate
fill 48 200 558 48 200 559 minecraft:cobbled_deepslate
setblock 48 200 560 minecraft:calcite
fill 48 200 561 48 203 561 minecraft:cobbled_deepslate
setblock 48 200 565 minecraft:calcite
fill 48 200 566 48 203 566 minecraft:cobbled_deepslate
setblock 48 200 580 minecraft:calcite
setblock 49 200 558 minecraft:cobbled_deepslate
setblock 49 200 559 minecraft:calcite
fill 49 200 560 49 203 560 minecraft:cobbled_deepslate
setblock 49 200 563 minecraft:cobbled_deepslate
fill 49 200 599 52 200 599 minecraft:deepslate
setblock 50 200 558 minecraft:calcite
fill 50 200 559 50 203 559 minecraft:cobbled_deepslate
setblock 50 200 560 minecraft:light[level=14]
setblock 50 200 568 minecraft:light[level=14]
setblock 50 200 576 minecraft:light[level=14]
setblock 50 200 584 minecraft:light[level=14]
setblock 50 200 592 minecraft:light[level=14]
fill 51 200 558 51 203 558 minecraft:cobbled_deepslate
setblock 53 200 559 minecraft:cobbled_deepslate
setblock 53 200 560 minecraft:calcite
setblock 53 200 599 minecraft:cobbled_deepslate
setblock 54 200 558 minecraft:cobbled_deepslate
setblock 54 200 559 minecraft:calcite
fill 54 200 560 54 203 560 minecraft:cobbled_deepslate
fill 54 200 599 60 200 599 minecraft:deepslate
setblock 55 200 558 minecraft:calcite
fill 55 200 559 55 203 559 minecraft:cobbled_deepslate
setblock 55 200 598 minecraft:calcite
fill 56 200 558 56 203 558 minecraft:cobbled_deepslate
setblock 56 200 597 minecraft:calcite
fill 56 200 598 56 203 598 minecraft:cobbled_deepslate
setblock 57 200 561 minecraft:calcite
fill 57 200 597 57 203 597 minecraft:cobbled_deepslate
fill 58 200 557 89 200 557 minecraft:deepslate
setblock 58 200 560 minecraft:calcite
fill 58 200 561 58 202 561 minecraft:cobbled_deepslate
setblock 58 200 568 minecraft:light[level=14]
setblock 58 200 576 minecraft:light[level=14]
setblock 58 200 584 minecraft:light[level=14]
setblock 58 200 592 minecraft:light[level=14]
setblock 59 200 559 minecraft:calcite
fill 59 200 560 59 203 560 minecraft:cobbled_deepslate
setblock 60 200 558 minecraft:calcite
fill 60 200 559 60 203 559 minecraft:cobbled_deepslate
setblock 60 200 598 minecraft:calcite
fill 61 200 558 61 203 558 minecraft:cobbled_deepslate
setblock 61 200 597 minecraft:calcite
fill 61 200 598 61 203 598 minecraft:cobbled_deepslate
fill 62 200 597 62 201 597 minecraft:cobbled_deepslate
fill 62 200 599 76 200 599 minecraft:deepslate
setblock 63 200 560 minecraft:calcite
setblock 64 200 559 minecraft:calcite
setblock 65 200 558 minecraft:calcite
setblock 65 200 559 minecraft:cobbled_deepslate
setblock 65 200 598 minecraft:calcite
fill 66 200 558 69 200 558 minecraft:cobbled_deepslate
setblock 66 200 560 minecraft:light[level=14]
setblock 66 200 568 minecraft:light[level=14]
setblock 66 200 576 minecraft:light[level=14]
setblock 66 200 584 minecraft:light[level=14]
setblock 66 200 592 minecraft:light[level=14]
fill 66 200 598 66 201 598 minecraft:cobbled_deepslate
setblock 70 200 558 minecraft:calcite
setblock 70 200 598 minecraft:calcite
fill 71 200 558 74 200 558 minecraft:cobbled_deepslate
fill 71 200 598 71 201 598 minecraft:cobbled_deepslate
setblock 74 200 560 minecraft:light[level=14]
setblock 74 200 568 minecraft:light[level=14]
setblock 74 200 576 minecraft:light[level=14]
setblock 74 200 584 minecraft:light[level=14]
setblock 74 200 592 minecraft:light[level=14]
setblock 75 200 558 minecraft:calcite
setblock 75 200 559 minecraft:cobbled_deepslate
setblock 75 200 598 minecraft:calcite
fill 76 200 558 76 203 558 minecraft:cobbled_deepslate
setblock 76 200 597 minecraft:calcite
fill 76 200 598 76 203 598 minecraft:cobbled_deepslate
setblock 77 200 597 minecraft:cobbled_deepslate
setblock 77 200 599 minecraft:cobbled_deepslate
fill 78 200 599 89 200 599 minecraft:deepslate
setblock 79 200 559 minecraft:calcite
setblock 80 200 558 minecraft:calcite
fill 80 200 559 80 201 559 minecraft:cobbled_deepslate
setblock 80 200 598 minecraft:calcite
fill 81 200 558 81 202 558 minecraft:cobbled_deepslate
fill 81 200 598 81 201 598 minecraft:cobbled_deepslate
setblock 82 200 560 minecraft:light[level=14]
setblock 82 200 568 minecraft:light[level=14]
setblock 82 200 576 minecraft:light[level=14]
setblock 82 200 584 minecraft:light[level=14]
setblock 82 200 592 minecraft:light[level=14]
setblock 84 200 590 minecraft:light_blue_stained_glass
setblock 85 200 558 minecraft:calcite
setblock 87 200 577 minecraft:cobbled_deepslate
setblock 87 200 581 minecraft:calcite
fill 87 200 582 87 201 582 minecraft:cobbled_deepslate
setblock 88 200 560 minecraft:calcite
fill 88 200 561 88 203 561 minecraft:cobbled_deepslate
setblock 88 200 575 minecraft:calcite
fill 88 200 576 88 201 576 minecraft:cobbled_deepslate
fill 88 200 578 88 200 579 minecraft:cobbled_deepslate
setblock 88 200 580 minecraft:calcite
fill 88 200 581 88 203 581 minecraft:cobbled_deepslate
setblock 88 200 585 minecraft:calcite
fill 89 200 558 89 201 570 minecraft:deepslate
fill 89 200 572 89 200 588 minecraft:deepslate
fill 89 200 590 89 200 598 minecraft:deepslate
fill 47 201 557 47 201 559 minecraft:deepslate
fill 47 201 560 48 201 560 minecraft:cobbled_deepslate
fill 47 201 561 47 201 571 minecraft:deepslate
setblock 47 201 572 minecraft:cobbled_deepslate
setblock 47 201 581 minecraft:cobbled_deepslate
setblock 48 201 558 minecraft:cobbled_deepslate
setblock 48 201 559 minecraft:calcite
setblock 48 201 564 minecraft:calcite
fill 48 201 565 48 204 565 minecraft:cobbled_deepslate
setblock 48 201 599 minecraft:deepslate
setblock 49 201 558 minecraft:calcite
setblock 49 201 559 minecraft:cobbled_deepslate
setblock 49 201 563 minecraft:calcite
setblock 49 201 599 minecraft:cobbled_deepslate
fill 50 201 558 50 204 558 minecraft:cobbled_deepslate
fill 50 201 599 56 307 599 minecraft:deepslate
setblock 52 201 559 minecraft:cobbled_deepslate
setblock 52 201 560 minecraft:calcite
setblock 53 201 559 minecraft:calcite
fill 53 201 560 53 204 560 minecraft:cobbled_deepslate
setblock 54 201 558 minecraft:calcite
fill 54 201 559 54 204 559 minecraft:cobbled_deepslate
setblock 54 201 598 minecraft:calcite
fill 55 201 558 55 204 558 minecraft:cobbled_deepslate
fill 55 201 598 55 204 598 minecraft:cobbled_deepslate
setblock 56 201 561 minecraft:calcite
setblock 56 201 597 minecraft:cobbled_deepslate
fill 57 201 557 59 307 557 minecraft:deepslate
setblock 57 201 560 minecraft:calcite
fill 57 201 561 57 203 561 minecraft:cobbled_deepslate
setblock 57 201 599 minecraft:cobbled_deepslate
setblock 58 201 558 minecraft:cobbled_deepslate
setblock 58 201 559 minecraft:calcite
fill 58 201 560 58 204 560 minecraft:cobbled_deepslate
fill 58 201 599 68 201 599 minecraft:deepslate
setblock 59 201 558 minecraft:calcite
fill 59 201 559 59 204 559 minecraft:cobbled_deepslate
setblock 59 201 598 minecraft:calcite
fill 60 201 557 60 201 558 minecraft:cobbled_deepslate
setblock 60 201 597 minecraft:calcite
fill 60 201 598 60 204 598 minecraft:cobbled_deepslate
fill 61 201 557 64 201 557 minecraft:deepslate
setblock 61 201 597 minecraft:cobbled_deepslate
setblock 62 201 560 minecraft:calcite
setblock 63 201 559 minecraft:calcite
setblock 64 201 558 minecraft:calcite
setblock 64 201 559 minecraft:cobbled_deepslate
setblock 64 201 598 minecraft:calcite
fill 65 201 557 65 201 558 minecraft:cobbled_deepslate
fill 65 201 598 65 202 598 minecraft:cobbled_deepslate
fill 66 201 557 67 307 557 minecraft:deepslate
fill 66 201 558 68 201 558 minecraft:cobbled_deepslate
fill 68 201 557 69 201 557 minecraft:cobbled_deepslate
setblock 69 201 598 minecraft:calcite
fill 69 201 599 69 202 599 minecraft:cobbled_deepslate
fill 70 201 557 75 307 557 minecraft:deepslate
setblock 70 201 598 minecraft:cobbled_deepslate
fill 70 201 599 71 201 599 minecraft:deepslate
fill 71 201 558 73 201 558 minecraft:cobbled_deepslate
setblock 72 201 599 minecraft:cobbled_deepslate
fill 73 201 599 74 307 599 minecraft:deepslate
setblock 74 201 558 minecraft:calcite
setblock 74 201 598 minecraft:calcite
fill 75 201 558 75 204 558 minecraft:cobbled_deepslate
fill 75 201 598 75 201 599 minecraft:cobbled_deepslate
setblock 76 201 557 minecraft:cobbled_deepslate
fill 76 201 599 85 201 599 minecraft:deepslate
fill 77 201 557 84 307 557 minecraft:deepslate
setblock 78 201 559 minecraft:calcite
setblock 79 201 558 minecraft:calcite
setblock 79 201 559 minecraft:cobbled_deepslate
setblock 79 201 598 minecraft:calcite
fill 80 201 558 80 203 558 minecraft:cobbled_deepslate
fill 80 201 598 80 202 598 minecraft:cobbled_deepslate
setblock 85 201 557 minecraft:cobbled_deepslate
fill 86 201 557 89 307 557 minecraft:deepslate
setblock 86 201 599 minecraft:cobbled_deepslate
setblock 87 201 580 minecraft:calcite
setblock 87 201 581 minecraft:cobbled_deepslate
fill 87 201 599 89 201 599 minecraft:deepslate
setblock 88 201 578 minecraft:cobbled_deepslate
setblock 88 201 579 minecraft:calcite
fill 88 201 580 89 201 580 minecraft:cobbled_deepslate
setblock 88 201 584 minecraft:calcite
fill 88 201 585 89 201 585 minecraft:cobbled_deepslate
fill 89 201 571 89 201 579 minecraft:deepslate
fill 89 201 581 89 307 583 minecraft:deepslate
setblock 89 201 584 minecraft:cobbled_deepslate
fill 89 201 586 89 201 593 minecraft:deepslate
setblock 89 201 594 minecraft:cobbled_deepslate
fill 89 201 595 89 307 598 minecraft:deepslate
fill 47 202 557 48 202 557 minecraft:cobbled_deepslate
fill 47 202 558 47 307 566 minecraft:deepslate
setblock 47 202 567 minecraft:cobbled_deepslate
fill 47 202 568 47 278 572 minecraft:deepslate
fill 47 202 581 47 278 582 minecraft:deepslate
setblock 47 202 583 minecraft:cobbled_deepslate
fill 47 202 584 47 278 586 minecraft:deepslate
setblock 47 202 587 minecraft:cobbled_deepslate
fill 47 202 588 47 307 595 minecraft:deepslate
fill 47 202 596 47 202 597 minecraft:cobbled_deepslate
fill 47 202 598 47 307 599 minecraft:deepslate
setblock 48 202 558 minecraft:calcite
fill 48 202 559 48 204 560 minecraft:cobbled_deepslate
setblock 48 202 563 minecraft:calcite
fill 48 202 564 48 205 564 minecraft:cobbled_deepslate
setblock 48 202 599 minecraft:cobbled_deepslate
fill 49 202 557 56 307 557 minecraft:deepslate
fill 49 202 558 49 205 558 minecraft:cobbled_deepslate
setblock 49 202 562 minecraft:calcite
fill 49 202 563 49 205 563 minecraft:cobbled_deepslate
fill 49 202 599 49 307 599 minecraft:deepslate
setblock 52 202 559 minecraft:calcite
fill 52 202 560 52 205 560 minecraft:cobbled_deepslate
setblock 53 202 558 minecraft:calcite
fill 53 202 559 53 205 559 minecraft:cobbled_deepslate
setblock 53 202 598 minecraft:calcite
fill 54 202 558 54 205 558 minecraft:cobbled_deepslate
fill 54 202 598 54 205 598 minecraft:cobbled_deepslate
setblock 55 202 560 minecraft:cobbled_deepslate
setblock 55 202 561 minecraft:calcite
setblock 56 202 560 minecraft:calcite
fill 56 202 561 56 205 561 minecraft:cobbled_deepslate
setblock 57 202 559 minecraft:calcite
fill 57 202 560 57 205 560 minecraft:cobbled_deepslate
fill 57 202 599 58 307 599 minecraft:deepslate
setblock 58 202 558 minecraft:calcite
fill 58 202 559 58 205 559 minecraft:cobbled_deepslate
setblock 58 202 598 minecraft:calcite
fill 59 202 558 60 204 558 minecraft:cobbled_deepslate
setblock 59 202 597 minecraft:calcite
fill 59 202 598 59 202 599 minecraft:cobbled_deepslate
fill 60 202 557 60 307 557 minecraft:deepslate
setblock 60 202 597 minecraft:cobbled_deepslate
setblock 60 202 599 minecraft:cobbled_deepslate
setblock 61 202 557 minecraft:cobbled_deepslate
setblock 61 202 560 minecraft:calcite
fill 61 202 599 68 307 599 minecraft:deepslate
fill 62 202 557 65 278 557 minecraft:deepslate
setblock 62 202 559 minecraft:calcite
setblock 63 202 558 minecraft:calcite
setblock 63 202 559 minecraft:cobbled_deepslate
setblock 63 202 598 minecraft:calcite
fill 64 202 558 66 202 558 minecraft:cobbled_deepslate
setblock 64 202 598 minecraft:cobbled_deepslate
fill 68 202 557 69 307 557 minecraft:deepslate
fill 70 202 599 70 307 599 minecraft:deepslate
setblock 71 202 599 minecraft:cobbled_deepslate
fill 72 202 599 72 307 599 minecraft:deepslate
setblock 73 202 558 minecraft:calcite
setblock 73 202 598 minecraft:calcite
fill 74 202 558 74 205 558 minecraft:cobbled_deepslate
fill 74 202 598 75 204 598 minecraft:cobbled_deepslate
fill 75 202 599 79 307 599 minecraft:deepslate
fill 76 202 557 76 307 557 minecraft:deepslate
setblock 77 202 559 minecraft:calcite
setblock 78 202 558 minecraft:calcite
setblock 78 202 559 minecraft:cobbled_deepslate
setblock 78 202 598 minecraft:calcite
fill 79 202 558 79 204 558 minecraft:cobbled_deepslate
setblock 79 202 598 minecraft:cobbled_deepslate
fill 80 202 599 81 202 599 minecraft:cobbled_deepslate
fill 82 202 599 88 307 599 minecraft:deepslate
fill 85 202 557 85 307 557 minecraft:deepslate
setblock 88 202 563 minecraft:calcite
fill 88 202 564 88 205 564 minecraft:cobbled_deepslate
setblock 88 202 578 minecraft:calcite
fill 88 202 579 88 203 580 minecraft:cobbled_deepslate
setblock 88 202 583 minecraft:calcite
fill 88 202 584 88 202 585 minecraft:cobbled_deepslate
fill 89 202 558 89 307 567 minecraft:deepslate
setblock 89 202 568 minecraft:cobbled_deepslate
fill 89 202 569 89 307 570 minecraft:deepslate
setblock 89 202 571 minecraft:cobbled_deepslate
fill 89 202 572 89 307 580 minecraft:deepslate
fill 89 202 584 89 307 587 minecraft:deepslate
setblock 89 202 588 minecraft:cobbled_deepslate
fill 89 202 589 89 307 594 minecraft:deepslate
setblock 89 202 599 minecraft:cobbled_deepslate
fill 47 203 557 48 307 557 minecraft:deepslate
fill 47 203 567 47 307 567 minecraft:deepslate
fill 47 203 583 47 278 583 minecraft:deepslate
fill 47 203 587 47 307 587 minecraft:deepslate
fill 47 203 596 47 307 597 minecraft:deepslate
fill 48 203 558 48 206 558 minecraft:cobbled_deepslate
setblock 48 203 562 minecraft:calcite
fill 48 203 563 48 206 563 minecraft:cobbled_deepslate
setblock 48 203 567 minecraft:calcite
fill 48 203 599 48 307 599 minecraft:deepslate
setblock 49 203 561 minecraft:calcite
fill 49 203 562 49 206 562 minecraft:cobbled_deepslate
fill 49 203 564 49 204 564 minecraft:cobbled_deepslate
setblock 51 203 559 minecraft:calcite
setblock 52 203 558 minecraft:calcite
fill 52 203 559 52 206 559 minecraft:cobbled_deepslate
fill 53 203 558 53 206 558 minecraft:cobbled_deepslate
fill 53 203 598 53 206 598 minecraft:cobbled_deepslate
setblock 55 203 560 minecraft:calcite
fill 55 203 561 55 206 561 minecraft:cobbled_deepslate
setblock 56 203 559 minecraft:calcite
fill 56 203 560 56 206 560 minecraft:cobbled_deepslate
setblock 57 203 558 minecraft:calcite
fill 57 203 559 57 206 559 minecraft:cobbled_deepslate
setblock 57 203 598 minecraft:calcite
fill 58 203 558 58 206 558 minecraft:cobbled_deepslate
setblock 58 203 597 minecraft:calcite
fill 58 203 598 59 205 598 minecraft:cobbled_deepslate
setblock 59 203 597 minecraft:cobbled_deepslate
fill 59 203 599 60 307 599 minecraft:deepslate
setblock 60 203 560 minecraft:calcite
fill 61 203 557 61 307 557 minecraft:deepslate
setblock 61 203 559 minecraft:calcite
setblock 62 203 558 minecraft:calcite
setblock 62 203 559 minecraft:cobbled_deepslate
setblock 62 203 598 minecraft:calcite
fill 63 203 558 64 203 558 minecraft:cobbled_deepslate
setblock 63 203 598 minecraft:cobbled_deepslate
fill 69 203 599 69 307 599 minecraft:deepslate
fill 71 203 599 71 307 599 minecraft:deepslate
setblock 73 203 558 minecraft:cobbled_deepslate
fill 73 203 598 73 206 598 minecraft:cobbled_deepslate
setblock 77 203 558 minecraft:calcite
setblock 77 203 598 minecraft:calcite
fill 78 203 558 78 205 558 minecraft:cobbled_deepslate
setblock 78 203 598 minecraft:cobbled_deepslate
fill 80 203 599 81 307 599 minecraft:deepslate
fill 81 203 596 83 206 598 minecraft:light_blue_stained_glass
fill 82 203 595 82 206 595 minecraft:light_blue_stained_glass
setblock 88 203 562 minecraft:calcite
fill 88 203 563 88 206 563 minecraft:cobbled_deepslate
fill 88 203 565 88 203 566 minecraft:cobbled_deepslate
setblock 88 203 582 minecraft:calcite
fill 88 203 583 88 205 584 minecraft:cobbled_deepslate
fill 89 203 568 89 307 568 minecraft:deepslate
fill 89 203 571 89 307 571 minecraft:deepslate
fill 89 203 588 89 307 588 minecraft:deepslate
fill 89 203 599 89 307 599 minecraft:deepslate
setblock 48 204 561 minecraft:calcite
fill 48 204 562 48 207 562 minecraft:cobbled_deepslate
setblock 48 204 566 minecraft:calcite
fill 48 204 567 48 206 568 minecraft:cobbled_deepslate
setblock 49 204 560 minecraft:calcite
fill 49 204 561 49 207 561 minecraft:cobbled_deepslate
setblock 49 204 565 minecraft:calcite
setblock 50 204 559 minecraft:calcite
setblock 51 204 558 minecraft:calcite
fill 51 204 559 51 207 559 minecraft:cobbled_deepslate
fill 52 204 558 52 207 558 minecraft:cobbled_deepslate
setblock 54 204 560 minecraft:calcite
setblock 55 204 559 minecraft:calcite
fill 55 204 560 55 207 560 minecraft:cobbled_deepslate
setblock 56 204 558 minecraft:calcite
fill 56 204 559 56 207 559 minecraft:cobbled_deepslate
setblock 56 204 598 minecraft:calcite
fill 57 204 558 57 207 558 minecraft:cobbled_deepslate
fill 57 204 598 57 207 598 minecraft:cobbled_deepslate
setblock 59 204 560 minecraft:calcite
setblock 60 204 559 minecraft:calcite
setblock 61 204 558 minecraft:calcite
fill 61 204 559 61 205 559 minecraft:cobbled_deepslate
setblock 61 204 598 minecraft:calcite
fill 62 204 558 63 204 558 minecraft:cobbled_deepslate
fill 62 204 598 62 205 598 minecraft:cobbled_deepslate
setblock 76 204 558 minecraft:calcite
setblock 76 204 598 minecraft:calcite
fill 77 204 558 77 207 558 minecraft:cobbled_deepslate
setblock 77 204 598 minecraft:cobbled_deepslate
fill 80 204 596 80 205 598 minecraft:light_blue_stained_glass
fill 81 204 594 81 206 595 minecraft:light_blue_stained_glass
fill 82 204 593 82 206 594 minecraft:light_blue_stained_glass
fill 83 204 594 83 206 595 minecraft:light_blue_stained_glass
fill 84 204 596 84 205 598 minecraft:light_blue_stained_glass
setblock 88 204 561 minecraft:calcite
fill 88 204 562 88 207 562 minecraft:cobbled_deepslate
setblock 88 204 565 minecraft:cobbled_deepslate
setblock 88 204 566 minecraft:calcite
fill 88 204 567 88 207 567 minecraft:cobbled_deepslate
setblock 88 204 580 minecraft:cobbled_deepslate
setblock 88 204 581 minecraft:calcite
fill 88 204 582 88 207 582 minecraft:cobbled_deepslate
setblock 88 204 585 minecraft:cobbled_deepslate
setblock 48 205 559 minecraft:cobbled_deepslate
setblock 48 205 560 minecraft:calcite
fill 48 205 561 48 208 561 minecraft:cobbled_deepslate
setblock 48 205 565 minecraft:calcite
fill 48 205 566 49 207 566 minecraft:cobbled_deepslate
setblock 48 205 569 minecraft:cobbled_deepslate
setblock 49 205 559 minecraft:calcite
fill 49 205 560 49 208 560 minecraft:cobbled_deepslate
setblock 49 205 564 minecraft:calcite
fill 49 205 565 49 208 565 minecraft:cobbled_deepslate
fill 49 205 567 49 206 567 minecraft:cobbled_deepslate
setblock 50 205 558 minecraft:calcite
fill 50 205 559 50 208 559 minecraft:cobbled_deepslate
setblock 50 205 562 minecraft:cobbled_deepslate
setblock 50 205 563 minecraft:calcite
fill 50 205 564 50 208 564 minecraft:cobbled_deepslate
fill 51 205 558 51 208 558 minecraft:cobbled_deepslate
fill 51 205 560 51 206 560 minecraft:cobbled_deepslate
fill 52 205 598 52 207 598 minecraft:cobbled_deepslate
setblock 53 205 560 minecraft:calcite
setblock 54 205 559 minecraft:calcite
fill 54 205 560 54 207 561 minecraft:cobbled_deepslate
setblock 55 205 558 minecraft:calcite
fill 55 205 559 55 208 559 minecraft:cobbled_deepslate
setblock 55 205 598 minecraft:calcite
fill 56 205 558 56 208 558 minecraft:cobbled_deepslate
setblock 56 205 597 minecraft:calcite
fill 56 205 598 56 208 598 minecraft:cobbled_deepslate
fill 57 205 597 57 208 597 minecraft:cobbled_deepslate
setblock 58 205 560 minecraft:calcite
setblock 59 205 558 minecraft:cobbled_deepslate
setblock 59 205 559 minecraft:calcite
setblock 59 205 560 minecraft:cobbled_deepslate
setblock 60 205 558 minecraft:calcite
fill 60 205 559 60 206 559 minecraft:cobbled_deepslate
setblock 60 205 598 minecraft:calcite
fill 61 205 558 62 206 558 minecraft:cobbled_deepslate
fill 61 205 598 61 208 598 minecraft:cobbled_deepslate
fill 73 205 558 73 206 558 minecraft:cobbled_deepslate
setblock 74 205 598 minecraft:cobbled_deepslate
setblock 75 205 558 minecraft:calcite
setblock 75 205 598 minecraft:calcite
fill 76 205 558 76 208 558 minecraft:cobbled_deepslate
fill 76 205 598 76 208 598 minecraft:cobbled_deepslate
fill 81 205 593 81 206 593 minecraft:light_blue_stained_glass
fill 82 205 591 82 206 592 minecraft:light_blue_stained_glass
fill 83 205 593 83 206 593 minecraft:light_blue_stained_glass
fill 88 205 561 88 208 561 minecraft:cobbled_deepslate
setblock 88 205 565 minecraft:calcite
fill 88 205 566 88 208 566 minecraft:cobbled_deepslate
fill 88 205 568 88 205 569 minecraft:cobbled_deepslate
fill 88 205 581 88 208 581 minecraft:cobbled_deepslate
setblock 88 205 585 minecraft:calcite
fill 88 205 586 88 208 586 minecraft:cobbled_deepslate
setblock 48 206 559 minecraft:calcite
fill 48 206 560 48 209 560 minecraft:cobbled_deepslate
setblock 48 206 564 minecraft:calcite
fill 48 206 565 48 209 565 minecraft:cobbled_deepslate
setblock 48 206 569 minecraft:calcite
fill 48 206 570 48 209 570 minecraft:cobbled_deepslate
setblock 49 206 558 minecraft:calcite
fill 49 206 559 49 209 559 minecraft:cobbled_deepslate
setblock 49 206 563 minecraft:calcite
fill 49 206 564 49 209 564 minecraft:cobbled_deepslate
setblock 49 206 568 minecraft:calcite
fill 50 206 558 50 209 558 minecraft:cobbled_deepslate
setblock 50 206 561 minecraft:cobbled_deepslate
schedule function dropper:buildpart/133_8 1t
