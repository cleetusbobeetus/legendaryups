fill 209 181 340 210 182 342 minecraft:hay_block
fill 209 181 360 210 182 362 minecraft:hay_block
fill 210 181 348 211 181 348 minecraft:green_concrete
setblock 210 181 349 minecraft:hay_block
setblock 210 181 353 minecraft:hay_block
fill 210 181 354 211 181 354 minecraft:green_concrete
fill 211 181 340 214 182 340 minecraft:green_concrete
fill 211 181 341 213 182 342 minecraft:hay_block
fill 211 181 344 212 182 344 minecraft:green_concrete
fill 211 181 347 214 182 347 minecraft:hay_block
fill 211 181 349 212 181 349 minecraft:green_concrete
fill 211 181 350 211 181 352 minecraft:hay_block
fill 211 181 353 212 181 353 minecraft:green_concrete
fill 211 181 355 214 182 355 minecraft:hay_block
fill 211 181 358 212 182 358 minecraft:green_concrete
fill 211 181 360 213 182 361 minecraft:hay_block
fill 211 181 362 214 182 362 minecraft:green_concrete
setblock 211 181 364 minecraft:pearlescent_froglight
fill 212 181 339 229 182 339 minecraft:hay_block
fill 212 181 343 216 182 343 minecraft:hay_block
fill 212 181 348 214 182 348 minecraft:hay_block
fill 212 181 350 212 182 352 minecraft:green_concrete
fill 212 181 354 214 182 354 minecraft:hay_block
fill 212 181 359 216 182 359 minecraft:hay_block
fill 212 181 363 229 182 363 minecraft:hay_block
fill 213 181 344 216 182 344 minecraft:hay_block
fill 213 181 345 214 182 345 minecraft:green_concrete
fill 213 181 349 215 182 353 minecraft:hay_block
fill 213 181 357 214 182 357 minecraft:green_concrete
fill 213 181 358 216 182 358 minecraft:hay_block
fill 214 181 341 215 182 341 minecraft:green_concrete
fill 214 181 342 214 182 342 minecraft:hay_block
fill 214 181 346 214 182 346 minecraft:green_concrete
fill 214 181 356 214 182 356 minecraft:green_concrete
fill 214 181 360 214 182 360 minecraft:hay_block
fill 214 181 361 215 182 361 minecraft:green_concrete
fill 215 181 340 229 182 340 minecraft:hay_block
fill 215 181 342 216 182 342 minecraft:green_concrete
fill 215 181 345 217 182 346 minecraft:hay_block
fill 215 181 347 215 182 348 minecraft:green_concrete
fill 215 181 354 215 182 355 minecraft:green_concrete
fill 215 181 356 217 182 357 minecraft:hay_block
fill 215 181 360 216 182 360 minecraft:green_concrete
fill 215 181 362 229 182 362 minecraft:hay_block
fill 216 181 341 229 182 341 minecraft:hay_block
fill 216 181 347 218 182 347 minecraft:hay_block
fill 216 181 348 216 182 354 minecraft:green_concrete
fill 216 181 355 218 182 355 minecraft:hay_block
fill 216 181 361 229 182 361 minecraft:hay_block
fill 217 181 342 229 182 342 minecraft:hay_block
fill 217 181 343 217 182 344 minecraft:green_concrete
fill 217 181 348 218 182 354 minecraft:hay_block
fill 217 181 358 217 182 359 minecraft:green_concrete
fill 217 181 360 229 182 360 minecraft:hay_block
fill 218 181 343 229 182 343 minecraft:hay_block
fill 218 181 344 218 182 345 minecraft:green_concrete
fill 218 181 346 218 182 346 minecraft:hay_block
fill 218 181 356 218 182 356 minecraft:hay_block
fill 218 181 357 218 182 358 minecraft:green_concrete
fill 218 181 359 229 182 359 minecraft:hay_block
fill 219 181 344 229 182 344 minecraft:hay_block
fill 219 181 345 219 182 348 minecraft:green_concrete
fill 219 181 349 219 182 353 minecraft:hay_block
fill 219 181 354 219 182 357 minecraft:green_concrete
fill 219 181 358 229 182 358 minecraft:hay_block
fill 220 181 345 229 182 347 minecraft:hay_block
fill 220 181 348 220 182 354 minecraft:green_concrete
fill 220 181 355 229 182 357 minecraft:hay_block
fill 221 181 348 229 182 354 minecraft:hay_block
fill 230 181 344 230 185 344 minecraft:black_concrete
setblock 230 181 345 minecraft:ochre_froglight
setblock 230 181 361 minecraft:pearlescent_froglight
fill 188 182 348 188 187 348 minecraft:black_concrete
setblock 205 182 348 minecraft:green_concrete
fill 205 182 349 205 182 353 minecraft:verdant_froglight
setblock 205 182 354 minecraft:green_concrete
setblock 206 182 347 minecraft:green_concrete
fill 206 182 348 206 182 349 minecraft:verdant_froglight
fill 206 182 353 206 182 354 minecraft:verdant_froglight
setblock 206 182 355 minecraft:green_concrete
fill 207 182 348 210 182 348 minecraft:verdant_froglight
fill 207 182 354 210 182 354 minecraft:verdant_froglight
fill 210 182 349 211 182 349 minecraft:verdant_froglight
fill 210 182 353 211 182 353 minecraft:verdant_froglight
setblock 211 182 348 minecraft:green_concrete
fill 211 182 350 211 182 352 minecraft:verdant_froglight
setblock 211 182 354 minecraft:green_concrete
fill 211 182 364 211 283 364 minecraft:black_concrete
setblock 212 182 349 minecraft:green_concrete
setblock 212 182 353 minecraft:green_concrete
setblock 214 182 364 minecraft:white_concrete
setblock 230 182 343 minecraft:pearlescent_froglight
fill 230 182 345 230 308 345 minecraft:black_concrete
setblock 230 182 351 minecraft:pearlescent_froglight
setblock 230 182 355 minecraft:sea_lantern
setblock 230 182 357 minecraft:ochre_froglight
fill 230 182 361 230 279 361 minecraft:black_concrete
setblock 188 183 335 minecraft:sea_lantern
setblock 188 183 356 minecraft:white_concrete
setblock 189 183 364 minecraft:ochre_froglight
fill 202 183 353 202 183 357 minecraft:white_concrete
fill 203 183 353 204 183 353 minecraft:white_concrete
fill 203 183 354 203 183 355 minecraft:black_concrete
fill 203 183 356 204 183 357 minecraft:white_concrete
fill 204 183 354 204 183 355 minecraft:white_concrete
setblock 207 183 364 minecraft:white_concrete
fill 214 183 364 214 197 364 minecraft:black_concrete
setblock 230 183 339 minecraft:white_concrete
fill 230 183 343 230 197 343 minecraft:black_concrete
fill 230 183 351 230 209 351 minecraft:black_concrete
fill 230 183 355 230 207 355 minecraft:black_concrete
fill 230 183 357 230 203 357 minecraft:black_concrete
setblock 188 184 334 minecraft:sea_lantern
fill 188 184 335 188 217 335 minecraft:black_concrete
fill 188 184 356 188 194 356 minecraft:black_concrete
fill 189 184 364 189 209 364 minecraft:black_concrete
fill 207 184 364 207 280 364 minecraft:black_concrete
setblock 219 184 364 minecraft:ochre_froglight
setblock 222 184 364 minecraft:white_concrete
setblock 225 184 322 minecraft:sea_lantern
setblock 227 184 364 minecraft:pearlescent_froglight
fill 230 184 339 230 206 339 minecraft:black_concrete
setblock 188 185 327 minecraft:pearlescent_froglight
fill 188 185 334 188 246 334 minecraft:black_concrete
setblock 191 185 325 minecraft:light[level=12]
setblock 191 185 332 minecraft:light[level=12]
setblock 191 185 339 minecraft:light[level=12]
setblock 191 185 346 minecraft:light[level=12]
setblock 191 185 353 minecraft:light[level=12]
setblock 191 185 360 minecraft:light[level=12]
setblock 191 185 364 minecraft:sea_lantern
setblock 196 185 322 minecraft:sea_lantern
setblock 198 185 325 minecraft:light[level=12]
setblock 198 185 332 minecraft:light[level=12]
setblock 198 185 339 minecraft:light[level=12]
setblock 198 185 346 minecraft:light[level=12]
setblock 198 185 353 minecraft:light[level=12]
setblock 198 185 360 minecraft:light[level=12]
setblock 201 185 322 minecraft:sea_lantern
setblock 205 185 325 minecraft:light[level=12]
setblock 205 185 332 minecraft:light[level=12]
setblock 205 185 339 minecraft:light[level=12]
setblock 205 185 346 minecraft:light[level=12]
setblock 205 185 353 minecraft:light[level=12]
setblock 205 185 360 minecraft:light[level=12]
setblock 212 185 325 minecraft:light[level=12]
setblock 212 185 332 minecraft:light[level=12]
setblock 212 185 339 minecraft:light[level=12]
setblock 212 185 346 minecraft:light[level=12]
setblock 212 185 353 minecraft:light[level=12]
setblock 212 185 360 minecraft:light[level=12]
setblock 213 185 322 minecraft:sea_lantern
setblock 219 185 325 minecraft:light[level=12]
setblock 219 185 332 minecraft:light[level=12]
setblock 219 185 339 minecraft:light[level=12]
setblock 219 185 346 minecraft:light[level=12]
setblock 219 185 353 minecraft:light[level=12]
setblock 219 185 360 minecraft:light[level=12]
fill 219 185 364 219 207 364 minecraft:black_concrete
fill 222 185 364 222 219 364 minecraft:black_concrete
fill 225 185 322 225 217 322 minecraft:black_concrete
setblock 226 185 325 minecraft:light[level=12]
setblock 226 185 332 minecraft:light[level=12]
setblock 226 185 339 minecraft:light[level=12]
setblock 226 185 346 minecraft:light[level=12]
setblock 226 185 353 minecraft:light[level=12]
setblock 226 185 360 minecraft:light[level=12]
setblock 226 185 364 minecraft:ochre_froglight
fill 227 185 364 227 198 364 minecraft:black_concrete
fill 188 186 327 188 222 327 minecraft:black_concrete
fill 191 186 364 191 207 364 minecraft:black_concrete
fill 196 186 322 196 234 322 minecraft:black_concrete
fill 201 186 322 201 189 322 minecraft:black_concrete
fill 213 186 322 213 212 322 minecraft:black_concrete
fill 226 186 364 226 211 364 minecraft:black_concrete
setblock 230 186 332 minecraft:white_concrete
setblock 230 186 337 minecraft:pearlescent_froglight
setblock 230 186 344 minecraft:white_concrete
setblock 188 187 331 minecraft:white_concrete
setblock 221 187 364 minecraft:sea_lantern
setblock 230 187 323 minecraft:pearlescent_froglight
fill 230 187 332 230 228 332 minecraft:black_concrete
fill 230 187 337 230 301 337 minecraft:black_concrete
fill 230 187 344 230 189 344 minecraft:black_concrete
setblock 230 187 354 minecraft:ochre_froglight
setblock 188 188 326 minecraft:white_concrete
fill 188 188 331 188 247 331 minecraft:black_concrete
setblock 188 188 333 minecraft:pearlescent_froglight
setblock 188 188 348 minecraft:white_concrete
setblock 208 188 322 minecraft:pearlescent_froglight
fill 221 188 364 221 207 364 minecraft:black_concrete
setblock 224 188 364 minecraft:pearlescent_froglight
fill 230 188 323 230 226 323 minecraft:black_concrete
fill 230 188 354 230 199 354 minecraft:black_concrete
fill 188 189 326 188 200 326 minecraft:black_concrete
fill 188 189 333 188 218 333 minecraft:black_concrete
setblock 188 189 344 minecraft:white_concrete
fill 188 189 348 188 197 348 minecraft:black_concrete
setblock 191 189 325 minecraft:light[level=15]
setblock 191 189 333 minecraft:light[level=15]
setblock 191 189 341 minecraft:light[level=15]
setblock 191 189 349 minecraft:light[level=15]
setblock 191 189 357 minecraft:light[level=15]
setblock 199 189 325 minecraft:light[level=15]
setblock 199 189 333 minecraft:light[level=15]
setblock 199 189 341 minecraft:light[level=15]
setblock 199 189 349 minecraft:light[level=15]
setblock 199 189 357 minecraft:light[level=15]
setblock 207 189 325 minecraft:light[level=15]
setblock 207 189 333 minecraft:light[level=15]
setblock 207 189 341 minecraft:light[level=15]
setblock 207 189 349 minecraft:light[level=15]
setblock 207 189 357 minecraft:light[level=15]
fill 208 189 322 208 224 322 minecraft:black_concrete
setblock 215 189 325 minecraft:light[level=15]
setblock 215 189 333 minecraft:light[level=15]
setblock 215 189 341 minecraft:light[level=15]
setblock 215 189 349 minecraft:light[level=15]
setblock 215 189 357 minecraft:light[level=15]
fill 216 189 364 216 225 364 minecraft:black_concrete
setblock 217 189 364 minecraft:ochre_froglight
setblock 223 189 325 minecraft:light[level=15]
setblock 223 189 333 minecraft:light[level=15]
setblock 223 189 341 minecraft:light[level=15]
setblock 223 189 349 minecraft:light[level=15]
setblock 223 189 357 minecraft:light[level=15]
fill 224 189 364 224 202 364 minecraft:black_concrete
setblock 230 189 334 minecraft:white_concrete
setblock 230 189 350 minecraft:ochre_froglight
setblock 188 190 324 minecraft:pearlescent_froglight
fill 188 190 344 188 235 344 minecraft:black_concrete
fill 191 190 341 192 191 345 minecraft:light_gray_concrete
fill 192 190 337 192 191 340 minecraft:light_gray_concrete
fill 192 190 346 192 191 349 minecraft:light_gray_concrete
fill 193 190 335 193 191 337 minecraft:light_gray_concrete
fill 193 190 349 193 191 351 minecraft:light_gray_concrete
fill 194 190 333 194 191 335 minecraft:light_gray_concrete
fill 194 190 351 194 191 353 minecraft:light_gray_concrete
fill 195 190 332 195 191 333 minecraft:light_gray_concrete
fill 195 190 353 195 191 354 minecraft:light_gray_concrete
fill 196 190 331 196 191 332 minecraft:light_gray_concrete
fill 196 190 354 196 191 355 minecraft:light_gray_concrete
fill 197 190 330 197 191 331 minecraft:light_gray_concrete
fill 197 190 355 197 191 356 minecraft:light_gray_concrete
fill 198 190 329 198 191 330 minecraft:light_gray_concrete
fill 198 190 356 198 191 357 minecraft:light_gray_concrete
fill 199 190 328 199 191 329 minecraft:light_gray_concrete
fill 199 190 357 199 191 358 minecraft:light_gray_concrete
fill 200 190 328 201 191 328 minecraft:light_gray_concrete
fill 200 190 358 201 191 358 minecraft:light_gray_concrete
setblock 201 190 322 minecraft:pearlescent_froglight
fill 201 190 327 203 191 327 minecraft:light_gray_concrete
fill 201 190 359 203 191 359 minecraft:light_gray_concrete
fill 203 190 326 215 191 326 minecraft:light_gray_concrete
fill 203 190 360 215 191 360 minecraft:light_gray_concrete
fill 207 190 325 211 191 325 minecraft:light_gray_concrete
fill 207 190 361 211 191 361 minecraft:light_gray_concrete
fill 215 190 327 217 191 327 minecraft:light_gray_concrete
fill 215 190 359 217 191 359 minecraft:light_gray_concrete
fill 217 190 328 219 191 328 minecraft:light_gray_concrete
fill 217 190 358 219 191 358 minecraft:light_gray_concrete
fill 217 190 364 217 202 364 minecraft:black_concrete
fill 218 190 345 219 191 346 minecraft:gray_concrete
fill 219 190 329 220 191 329 minecraft:light_gray_concrete
fill 219 190 357 220 191 357 minecraft:light_gray_concrete
fill 220 190 330 221 191 330 minecraft:light_gray_concrete
fill 220 190 346 220 191 346 minecraft:gray_concrete
fill 220 190 356 221 191 356 minecraft:light_gray_concrete
fill 221 190 331 222 191 331 minecraft:light_gray_concrete
fill 221 190 355 222 191 355 minecraft:light_gray_concrete
fill 222 190 332 223 191 332 minecraft:light_gray_concrete
fill 222 190 354 223 191 354 minecraft:light_gray_concrete
fill 223 190 333 224 191 333 minecraft:light_gray_concrete
fill 223 190 353 224 191 353 minecraft:light_gray_concrete
fill 224 190 334 224 191 335 minecraft:light_gray_concrete
fill 224 190 351 224 191 352 minecraft:light_gray_concrete
fill 225 190 335 225 191 337 minecraft:light_gray_concrete
fill 225 190 349 225 191 351 minecraft:light_gray_concrete
fill 226 190 337 226 191 349 minecraft:light_gray_concrete
fill 227 190 341 227 191 345 minecraft:light_gray_concrete
fill 230 190 334 230 223 334 minecraft:black_concrete
setblock 230 190 344 minecraft:ochre_froglight
fill 230 190 350 230 193 350 minecraft:black_concrete
fill 188 191 324 188 206 324 minecraft:black_concrete
setblock 188 191 357 minecraft:pearlescent_froglight
setblock 188 191 359 minecraft:pearlescent_froglight
setblock 191 191 325 minecraft:light[level=12]
setblock 191 191 332 minecraft:light[level=12]
setblock 191 191 339 minecraft:light[level=12]
setblock 191 191 346 minecraft:light[level=12]
setblock 191 191 353 minecraft:light[level=12]
setblock 191 191 360 minecraft:light[level=12]
setblock 198 191 325 minecraft:light[level=12]
setblock 198 191 332 minecraft:light[level=12]
setblock 198 191 339 minecraft:light[level=12]
setblock 198 191 346 minecraft:light[level=12]
setblock 198 191 353 minecraft:light[level=12]
setblock 198 191 360 minecraft:light[level=12]
setblock 199 191 322 minecraft:sea_lantern
setblock 200 191 364 minecraft:sea_lantern
fill 201 191 322 201 230 322 minecraft:black_concrete
setblock 205 191 325 minecraft:light[level=12]
setblock 205 191 332 minecraft:light[level=12]
setblock 205 191 339 minecraft:light[level=12]
setblock 205 191 346 minecraft:light[level=12]
setblock 205 191 353 minecraft:light[level=12]
setblock 212 191 325 minecraft:light[level=12]
setblock 212 191 332 minecraft:light[level=12]
setblock 212 191 339 minecraft:light[level=12]
setblock 212 191 346 minecraft:light[level=12]
setblock 212 191 353 minecraft:light[level=12]
fill 218 191 337 218 192 338 minecraft:end_stone
setblock 219 191 325 minecraft:light[level=12]
setblock 219 191 332 minecraft:light[level=12]
setblock 219 191 339 minecraft:light[level=12]
setblock 219 191 353 minecraft:light[level=12]
setblock 219 191 360 minecraft:light[level=12]
setblock 226 191 325 minecraft:light[level=12]
setblock 226 191 332 minecraft:light[level=12]
setblock 226 191 353 minecraft:light[level=12]
setblock 226 191 360 minecraft:light[level=12]
fill 230 191 344 230 199 344 minecraft:black_concrete
setblock 188 192 346 minecraft:sea_lantern
fill 188 192 357 188 193 357 minecraft:black_concrete
fill 188 192 359 188 198 359 minecraft:black_concrete
fill 191 192 339 191 192 347 minecraft:verdant_froglight
fill 192 192 336 192 192 338 minecraft:verdant_froglight
fill 192 192 348 192 192 350 minecraft:verdant_froglight
fill 193 192 334 193 192 335 minecraft:verdant_froglight
fill 193 192 351 193 192 352 minecraft:verdant_froglight
setblock 194 192 333 minecraft:verdant_froglight
setblock 194 192 353 minecraft:verdant_froglight
fill 195 192 331 195 192 332 minecraft:verdant_froglight
fill 195 192 354 195 192 355 minecraft:verdant_froglight
fill 196 192 330 196 192 331 minecraft:verdant_froglight
fill 196 192 355 196 192 356 minecraft:verdant_froglight
fill 197 192 329 197 192 330 minecraft:verdant_froglight
fill 197 192 356 197 192 357 minecraft:verdant_froglight
setblock 198 192 329 minecraft:verdant_froglight
setblock 198 192 357 minecraft:verdant_froglight
fill 199 192 322 199 201 322 minecraft:black_concrete
setblock 199 192 328 minecraft:verdant_froglight
setblock 199 192 358 minecraft:verdant_froglight
fill 200 192 327 201 192 327 minecraft:verdant_froglight
fill 200 192 359 201 192 359 minecraft:verdant_froglight
fill 200 192 364 200 201 364 minecraft:black_concrete
fill 202 192 326 204 192 326 minecraft:verdant_froglight
fill 202 192 360 204 192 360 minecraft:verdant_froglight
fill 205 192 325 213 192 325 minecraft:verdant_froglight
fill 205 192 361 213 192 361 minecraft:verdant_froglight
fill 214 192 326 216 192 326 minecraft:verdant_froglight
fill 214 192 360 216 192 360 minecraft:verdant_froglight
fill 217 192 327 218 192 327 minecraft:verdant_froglight
fill 217 192 359 218 192 359 minecraft:verdant_froglight
setblock 218 192 322 minecraft:pearlescent_froglight
setblock 219 192 328 minecraft:verdant_froglight
setblock 219 192 358 minecraft:verdant_froglight
fill 220 192 329 221 192 329 minecraft:verdant_froglight
fill 220 192 357 221 192 357 minecraft:verdant_froglight
fill 221 192 330 222 192 330 minecraft:verdant_froglight
fill 221 192 356 222 192 356 minecraft:verdant_froglight
setblock 222 192 322 minecraft:sea_lantern
fill 222 192 355 223 192 355 minecraft:verdant_froglight
fill 223 192 331 223 192 332 minecraft:verdant_froglight
setblock 223 192 354 minecraft:verdant_froglight
setblock 224 192 333 minecraft:verdant_froglight
setblock 224 192 353 minecraft:verdant_froglight
fill 225 192 334 225 192 335 minecraft:verdant_froglight
fill 225 192 351 225 192 352 minecraft:verdant_froglight
fill 226 192 336 226 192 338 minecraft:verdant_froglight
fill 226 192 348 226 192 350 minecraft:verdant_froglight
fill 227 192 339 227 192 347 minecraft:verdant_froglight
setblock 230 192 359 minecraft:sea_lantern
fill 188 193 346 188 237 346 minecraft:black_concrete
fill 207 193 354 209 194 354 minecraft:gray_concrete
fill 208 193 355 208 194 355 minecraft:gray_concrete
fill 218 193 322 218 278 322 minecraft:black_concrete
setblock 219 193 322 minecraft:pearlescent_froglight
fill 222 193 322 222 206 322 minecraft:black_concrete
setblock 230 193 335 minecraft:white_concrete
fill 230 193 359 230 225 359 minecraft:black_concrete
setblock 188 194 353 minecraft:white_concrete
setblock 188 194 357 minecraft:pearlescent_froglight
fill 219 194 322 219 196 322 minecraft:black_concrete
setblock 227 194 322 minecraft:ochre_froglight
fill 230 194 335 230 213 335 minecraft:black_concrete
setblock 230 194 350 minecraft:pearlescent_froglight
setblock 230 194 352 minecraft:sea_lantern
fill 188 195 353 188 206 353 minecraft:black_concrete
setblock 188 195 356 minecraft:white_concrete
fill 188 195 357 188 206 357 minecraft:black_concrete
setblock 199 195 364 minecraft:sea_lantern
fill 220 195 345 220 196 345 minecraft:lime_stained_glass
fill 227 195 322 227 209 322 minecraft:black_concrete
setblock 230 195 342 minecraft:sea_lantern
fill 230 195 350 230 208 350 minecraft:black_concrete
fill 230 195 352 230 300 352 minecraft:black_concrete
setblock 230 195 360 minecraft:ochre_froglight
setblock 188 196 343 minecraft:ochre_froglight
fill 188 196 356 188 220 356 minecraft:black_concrete
fill 199 196 364 199 308 364 minecraft:black_concrete
setblock 202 196 322 minecraft:pearlescent_froglight
setblock 208 196 364 minecraft:sea_lantern
fill 222 196 330 222 197 330 minecraft:end_stone
fill 230 196 342 230 199 342 minecraft:black_concrete
fill 230 196 360 230 224 360 minecraft:black_concrete
fill 188 197 343 188 207 343 minecraft:black_concrete
setblock 191 197 325 minecraft:light[level=15]
setblock 191 197 332 minecraft:light[level=12]
setblock 191 197 333 minecraft:light[level=15]
setblock 191 197 339 minecraft:light[level=12]
setblock 191 197 341 minecraft:light[level=15]
setblock 191 197 346 minecraft:light[level=12]
setblock 191 197 349 minecraft:light[level=15]
setblock 191 197 353 minecraft:light[level=12]
setblock 191 197 357 minecraft:light[level=15]
setblock 191 197 360 minecraft:light[level=12]
setblock 198 197 325 minecraft:light[level=12]
setblock 198 197 332 minecraft:light[level=12]
setblock 198 197 339 minecraft:light[level=12]
setblock 198 197 346 minecraft:light[level=12]
setblock 198 197 353 minecraft:light[level=12]
setblock 198 197 360 minecraft:light[level=12]
setblock 199 197 325 minecraft:light[level=15]
setblock 199 197 333 minecraft:light[level=15]
setblock 199 197 341 minecraft:light[level=15]
setblock 199 197 349 minecraft:light[level=15]
setblock 199 197 357 minecraft:light[level=15]
setblock 202 197 322 minecraft:sea_lantern
setblock 205 197 325 minecraft:light[level=12]
setblock 205 197 332 minecraft:light[level=12]
setblock 205 197 339 minecraft:light[level=12]
setblock 205 197 346 minecraft:light[level=12]
setblock 205 197 353 minecraft:light[level=12]
setblock 205 197 360 minecraft:light[level=12]
setblock 207 197 325 minecraft:light[level=15]
setblock 207 197 333 minecraft:light[level=15]
setblock 207 197 341 minecraft:light[level=15]
setblock 207 197 349 minecraft:light[level=15]
setblock 207 197 357 minecraft:light[level=15]
fill 208 197 364 208 202 364 minecraft:black_concrete
setblock 212 197 325 minecraft:light[level=12]
setblock 212 197 332 minecraft:light[level=12]
setblock 212 197 339 minecraft:light[level=12]
setblock 212 197 346 minecraft:light[level=12]
setblock 212 197 353 minecraft:light[level=12]
setblock 212 197 360 minecraft:light[level=12]
setblock 215 197 325 minecraft:light[level=15]
setblock 215 197 333 minecraft:light[level=15]
setblock 215 197 341 minecraft:light[level=15]
setblock 215 197 349 minecraft:light[level=15]
setblock 215 197 357 minecraft:light[level=15]
setblock 219 197 322 minecraft:sea_lantern
setblock 219 197 325 minecraft:light[level=12]
setblock 219 197 332 minecraft:light[level=12]
setblock 219 197 339 minecraft:light[level=12]
setblock 219 197 346 minecraft:light[level=12]
setblock 219 197 353 minecraft:light[level=12]
setblock 219 197 360 minecraft:light[level=12]
fill 220 197 345 220 203 345 minecraft:gray_concrete
setblock 223 197 325 minecraft:light[level=15]
setblock 223 197 333 minecraft:light[level=15]
setblock 223 197 341 minecraft:light[level=15]
setblock 223 197 349 minecraft:light[level=15]
setblock 223 197 357 minecraft:light[level=15]
setblock 226 197 325 minecraft:light[level=12]
setblock 226 197 332 minecraft:light[level=12]
setblock 226 197 339 minecraft:light[level=12]
setblock 226 197 346 minecraft:light[level=12]
setblock 226 197 353 minecraft:light[level=12]
setblock 226 197 360 minecraft:light[level=12]
setblock 230 197 338 minecraft:ochre_froglight
setblock 230 197 348 minecraft:ochre_froglight
setblock 230 197 358 minecraft:pearlescent_froglight
setblock 188 198 348 minecraft:ochre_froglight
fill 202 198 322 202 273 322 minecraft:black_concrete
fill 205 198 333 205 199 333 minecraft:lime_stained_glass
setblock 210 198 364 minecraft:ochre_froglight
fill 213 198 334 213 199 334 minecraft:end_stone
setblock 214 198 364 minecraft:ochre_froglight
fill 219 198 322 219 288 322 minecraft:black_concrete
fill 220 198 346 220 203 346 minecraft:gray_concrete
fill 221 198 345 221 203 345 minecraft:gray_concrete
fill 230 198 338 230 252 338 minecraft:black_concrete
setblock 230 198 343 minecraft:white_concrete
fill 230 198 348 230 308 348 minecraft:black_concrete
fill 230 198 358 230 252 358 minecraft:black_concrete
setblock 188 199 347 minecraft:white_concrete
fill 188 199 348 188 282 348 minecraft:black_concrete
setblock 188 199 354 minecraft:white_concrete
setblock 188 199 359 minecraft:white_concrete
setblock 195 199 322 minecraft:pearlescent_froglight
setblock 210 199 364 minecraft:white_concrete
fill 214 199 364 214 276 364 minecraft:black_concrete
fill 220 199 344 220 203 344 minecraft:gray_concrete
fill 221 199 346 221 203 346 minecraft:gray_concrete
setblock 227 199 364 minecraft:white_concrete
setblock 230 199 331 minecraft:sea_lantern
fill 230 199 343 230 245 343 minecraft:black_concrete
fill 188 200 347 188 205 347 minecraft:black_concrete
fill 188 200 354 188 248 354 minecraft:black_concrete
fill 188 200 359 188 263 359 minecraft:black_concrete
fill 192 200 343 192 201 343 minecraft:end_stone
setblock 195 200 322 minecraft:black_concrete
fill 205 200 333 205 207 333 minecraft:gray_concrete
fill 210 200 364 210 201 364 minecraft:black_concrete
fill 219 200 345 219 203 346 minecraft:gray_concrete
fill 220 200 347 220 203 347 minecraft:gray_concrete
fill 221 200 344 221 203 344 minecraft:gray_concrete
fill 222 200 345 222 203 345 minecraft:gray_concrete
setblock 223 200 364 minecraft:ochre_froglight
fill 227 200 364 227 225 364 minecraft:black_concrete
fill 230 200 331 230 220 331 minecraft:black_concrete
setblock 230 200 342 minecraft:pearlescent_froglight
setblock 230 200 344 minecraft:pearlescent_froglight
setblock 230 200 354 minecraft:white_concrete
setblock 188 201 326 minecraft:sea_lantern
setblock 195 201 322 minecraft:pearlescent_froglight
fill 219 201 344 219 203 344 minecraft:gray_concrete
fill 219 201 347 219 203 347 minecraft:gray_concrete
fill 221 201 347 221 203 347 minecraft:gray_concrete
fill 222 201 344 222 203 344 minecraft:gray_concrete
fill 222 201 346 222 203 346 minecraft:gray_concrete
setblock 223 201 364 minecraft:black_concrete
fill 230 201 342 230 235 342 minecraft:black_concrete
fill 230 201 344 230 234 344 minecraft:black_concrete
fill 230 201 354 230 218 354 minecraft:black_concrete
fill 188 202 326 188 237 326 minecraft:black_concrete
setblock 188 202 338 minecraft:ochre_froglight
fill 195 202 322 195 212 322 minecraft:black_concrete
setblock 199 202 322 minecraft:ochre_froglight
setblock 200 202 364 minecraft:ochre_froglight
fill 204 202 333 204 207 334 minecraft:gray_concrete
fill 205 202 334 205 207 334 minecraft:gray_concrete
setblock 206 202 364 minecraft:pearlescent_froglight
setblock 210 202 322 minecraft:ochre_froglight
setblock 210 202 364 minecraft:sea_lantern
setblock 214 202 322 minecraft:ochre_froglight
fill 218 202 344 218 203 346 minecraft:gray_concrete
fill 219 202 343 221 203 343 minecraft:gray_concrete
fill 222 202 347 222 203 347 minecraft:gray_concrete
fill 223 202 345 223 203 345 minecraft:gray_concrete
setblock 223 202 364 minecraft:white_concrete
fill 188 203 338 188 237 338 minecraft:black_concrete
setblock 191 203 325 minecraft:light[level=12]
setblock 191 203 332 minecraft:light[level=12]
setblock 191 203 339 minecraft:light[level=12]
setblock 191 203 346 minecraft:light[level=12]
setblock 191 203 353 minecraft:light[level=12]
setblock 191 203 360 minecraft:light[level=12]
setblock 198 203 322 minecraft:sea_lantern
setblock 198 203 325 minecraft:light[level=12]
setblock 198 203 332 minecraft:light[level=12]
setblock 198 203 339 minecraft:light[level=12]
setblock 198 203 346 minecraft:light[level=12]
setblock 198 203 353 minecraft:light[level=12]
setblock 198 203 360 minecraft:light[level=12]
fill 199 203 322 199 234 322 minecraft:black_concrete
fill 200 203 364 200 240 364 minecraft:black_concrete
setblock 205 203 325 minecraft:light[level=12]
fill 205 203 332 205 207 332 minecraft:gray_concrete
setblock 205 203 339 minecraft:light[level=12]
setblock 205 203 346 minecraft:light[level=12]
setblock 205 203 353 minecraft:light[level=12]
setblock 205 203 360 minecraft:light[level=12]
fill 206 203 333 206 207 334 minecraft:gray_concrete
fill 206 203 364 206 245 364 minecraft:black_concrete
setblock 208 203 364 minecraft:sea_lantern
fill 210 203 322 210 221 322 minecraft:black_concrete
fill 210 203 364 210 221 364 minecraft:black_concrete
setblock 212 203 325 minecraft:light[level=12]
setblock 212 203 332 minecraft:light[level=12]
setblock 212 203 339 minecraft:light[level=12]
setblock 212 203 346 minecraft:light[level=12]
setblock 212 203 353 minecraft:light[level=12]
setblock 212 203 360 minecraft:light[level=12]
fill 214 203 322 214 226 322 minecraft:black_concrete
setblock 217 203 364 minecraft:white_concrete
setblock 218 203 347 minecraft:gray_concrete
setblock 219 203 325 minecraft:light[level=12]
setblock 219 203 332 minecraft:light[level=12]
setblock 219 203 339 minecraft:light[level=12]
fill 219 203 348 221 203 348 minecraft:gray_concrete
setblock 219 203 353 minecraft:light[level=12]
setblock 219 203 360 minecraft:light[level=12]
setblock 222 203 343 minecraft:gray_concrete
setblock 223 203 344 minecraft:gray_concrete
setblock 223 203 346 minecraft:gray_concrete
fill 223 203 364 223 233 364 minecraft:black_concrete
setblock 224 203 364 minecraft:white_concrete
setblock 226 203 325 minecraft:light[level=12]
setblock 226 203 332 minecraft:light[level=12]
setblock 226 203 339 minecraft:light[level=12]
setblock 226 203 346 minecraft:light[level=12]
setblock 226 203 353 minecraft:light[level=12]
setblock 226 203 360 minecraft:light[level=12]
setblock 230 203 340 minecraft:pearlescent_froglight
setblock 188 204 332 minecraft:pearlescent_froglight
setblock 193 204 322 minecraft:pearlescent_froglight
fill 198 204 322 198 255 322 minecraft:black_concrete
fill 203 204 333 203 207 334 minecraft:gray_concrete
fill 204 204 332 204 207 332 minecraft:gray_concrete
fill 204 204 335 205 207 335 minecraft:gray_concrete
setblock 206 204 322 minecraft:white_concrete
fill 206 204 332 206 207 332 minecraft:gray_concrete
fill 208 204 364 208 207 364 minecraft:black_concrete
fill 217 204 364 217 249 364 minecraft:black_concrete
fill 218 204 325 218 210 325 minecraft:lime_concrete
fill 220 204 344 220 204 346 minecraft:lime_stained_glass
fill 221 204 345 221 205 346 minecraft:lime_stained_glass
fill 224 204 364 224 296 364 minecraft:black_concrete
fill 230 204 340 230 206 340 minecraft:black_concrete
setblock 230 204 357 minecraft:white_concrete
fill 230 204 362 230 206 362 minecraft:black_concrete
setblock 230 204 363 minecraft:sea_lantern
setblock 188 205 332 minecraft:black_concrete
setblock 188 205 350 minecraft:sea_lantern
setblock 191 205 325 minecraft:light[level=15]
setblock 191 205 333 minecraft:light[level=15]
setblock 191 205 341 minecraft:light[level=15]
setblock 191 205 349 minecraft:light[level=15]
setblock 191 205 357 minecraft:light[level=15]
fill 192 205 358 192 213 358 minecraft:lime_concrete
fill 193 205 322 193 216 322 minecraft:black_concrete
setblock 196 205 364 minecraft:ochre_froglight
setblock 199 205 325 minecraft:light[level=15]
setblock 199 205 333 minecraft:light[level=15]
setblock 199 205 341 minecraft:light[level=15]
setblock 199 205 349 minecraft:light[level=15]
setblock 199 205 357 minecraft:light[level=15]
fill 203 205 332 203 207 332 minecraft:gray_concrete
fill 203 205 335 203 207 335 minecraft:gray_concrete
fill 205 205 331 205 207 331 minecraft:gray_concrete
fill 206 205 322 206 210 322 minecraft:black_concrete
fill 206 205 335 206 207 335 minecraft:gray_concrete
setblock 207 205 325 minecraft:light[level=15]
fill 207 205 333 207 207 334 minecraft:gray_concrete
setblock 207 205 341 minecraft:light[level=15]
setblock 207 205 349 minecraft:light[level=15]
setblock 207 205 357 minecraft:light[level=15]
setblock 215 205 325 minecraft:light[level=15]
setblock 215 205 333 minecraft:light[level=15]
setblock 215 205 341 minecraft:light[level=15]
setblock 215 205 349 minecraft:light[level=15]
setblock 215 205 357 minecraft:light[level=15]
fill 220 205 345 220 205 346 minecraft:lime_stained_glass
setblock 223 205 325 minecraft:light[level=15]
setblock 223 205 333 minecraft:light[level=15]
setblock 223 205 341 minecraft:light[level=15]
setblock 223 205 349 minecraft:light[level=15]
setblock 223 205 357 minecraft:light[level=15]
setblock 230 205 333 minecraft:ochre_froglight
setblock 230 205 353 minecraft:sea_lantern
fill 230 205 357 230 259 357 minecraft:black_concrete
fill 230 205 363 230 241 363 minecraft:black_concrete
setblock 188 206 332 minecraft:white_concrete
setblock 188 206 347 minecraft:sea_lantern
fill 188 206 350 188 228 350 minecraft:black_concrete
fill 196 206 364 196 272 364 minecraft:black_concrete
fill 202 206 333 202 207 334 minecraft:gray_concrete
fill 204 206 331 204 207 331 minecraft:gray_concrete
fill 204 206 336 205 207 336 minecraft:gray_concrete
fill 206 206 331 206 207 331 minecraft:gray_concrete
fill 207 206 332 207 207 332 minecraft:gray_concrete
fill 207 206 335 207 207 335 minecraft:gray_concrete
fill 218 206 324 218 210 324 minecraft:lime_concrete
fill 220 206 345 221 206 345 minecraft:lime_stained_glass
fill 230 206 333 230 308 333 minecraft:black_concrete
fill 230 206 353 230 308 353 minecraft:black_concrete
setblock 188 207 324 minecraft:ochre_froglight
fill 188 207 332 188 289 332 minecraft:black_concrete
fill 188 207 347 188 295 347 minecraft:black_concrete
setblock 188 207 353 minecraft:sea_lantern
setblock 188 207 357 minecraft:ochre_froglight
fill 191 207 358 191 211 358 minecraft:lime_concrete
fill 192 207 357 192 213 357 minecraft:lime_concrete
fill 193 207 358 193 213 358 minecraft:lime_concrete
fill 195 207 358 195 213 358 minecraft:lime_concrete
setblock 202 207 332 minecraft:gray_concrete
setblock 202 207 335 minecraft:gray_concrete
setblock 203 207 331 minecraft:gray_concrete
setblock 203 207 336 minecraft:gray_concrete
setblock 206 207 336 minecraft:gray_concrete
setblock 216 207 322 minecraft:white_concrete
fill 217 207 324 217 210 325 minecraft:lime_concrete
fill 218 207 326 218 210 326 minecraft:lime_concrete
fill 219 207 324 219 210 325 minecraft:lime_concrete
setblock 220 207 345 minecraft:lime_stained_glass
setblock 222 207 322 minecraft:pearlescent_froglight
setblock 230 207 339 minecraft:sea_lantern
setblock 230 207 340 minecraft:pearlescent_froglight
fill 230 207 346 230 232 346 minecraft:black_concrete
setblock 230 207 347 minecraft:white_concrete
setblock 230 207 362 minecraft:white_concrete
fill 188 208 324 188 234 324 minecraft:black_concrete
setblock 188 208 343 minecraft:ochre_froglight
fill 188 208 353 188 224 353 minecraft:black_concrete
fill 188 208 357 188 215 357 minecraft:black_concrete
fill 191 208 357 191 211 357 minecraft:lime_concrete
fill 191 208 359 193 211 359 minecraft:lime_concrete
setblock 191 208 364 minecraft:white_concrete
fill 193 208 357 193 213 357 minecraft:lime_concrete
fill 195 208 359 195 213 359 minecraft:lime_concrete
setblock 198 208 364 minecraft:ochre_froglight
fill 204 208 333 205 209 334 minecraft:lime_stained_glass
setblock 208 208 364 minecraft:white_concrete
fill 216 208 322 216 236 322 minecraft:black_concrete
setblock 219 208 364 minecraft:white_concrete
setblock 220 208 322 minecraft:pearlescent_froglight
setblock 221 208 364 minecraft:white_concrete
fill 222 208 322 222 270 322 minecraft:black_concrete
fill 226 208 359 226 214 359 minecraft:lime_concrete
fill 230 208 339 230 259 340 minecraft:black_concrete
fill 230 208 347 230 212 347 minecraft:black_concrete
setblock 230 208 355 minecraft:sea_lantern
fill 230 208 362 230 226 362 minecraft:black_concrete
fill 188 209 343 188 214 343 minecraft:black_concrete
fill 190 209 358 190 211 358 minecraft:lime_concrete
setblock 191 209 325 minecraft:light[level=12]
setblock 191 209 332 minecraft:light[level=12]
setblock 191 209 339 minecraft:light[level=12]
setblock 191 209 346 minecraft:light[level=12]
setblock 191 209 353 minecraft:light[level=12]
fill 191 209 356 193 211 356 minecraft:lime_concrete
setblock 191 209 360 minecraft:light[level=12]
fill 191 209 364 191 213 364 minecraft:black_concrete
fill 194 209 357 194 213 359 minecraft:lime_concrete
fill 195 209 357 196 213 357 minecraft:lime_concrete
fill 196 209 358 196 213 359 minecraft:lime_concrete
setblock 198 209 325 minecraft:light[level=12]
setblock 198 209 332 minecraft:light[level=12]
setblock 198 209 339 minecraft:light[level=12]
setblock 198 209 346 minecraft:light[level=12]
setblock 198 209 353 minecraft:light[level=12]
setblock 198 209 360 minecraft:light[level=12]
fill 198 209 364 198 244 364 minecraft:black_concrete
setblock 205 209 325 minecraft:light[level=12]
setblock 205 209 332 minecraft:light[level=12]
setblock 205 209 339 minecraft:light[level=12]
setblock 205 209 346 minecraft:light[level=12]
setblock 205 209 353 minecraft:light[level=12]
setblock 205 209 360 minecraft:light[level=12]
fill 208 209 364 208 251 364 minecraft:black_concrete
setblock 212 209 325 minecraft:light[level=12]
setblock 212 209 332 minecraft:light[level=12]
setblock 212 209 339 minecraft:light[level=12]
setblock 212 209 346 minecraft:light[level=12]
setblock 212 209 353 minecraft:light[level=12]
setblock 212 209 360 minecraft:light[level=12]
fill 217 209 326 217 210 326 minecraft:lime_concrete
fill 218 209 323 218 210 323 minecraft:lime_concrete
fill 219 209 326 219 210 326 minecraft:lime_concrete
setblock 219 209 332 minecraft:light[level=12]
setblock 219 209 339 minecraft:light[level=12]
setblock 219 209 346 minecraft:light[level=12]
setblock 219 209 353 minecraft:light[level=12]
setblock 219 209 360 minecraft:light[level=12]
fill 219 209 364 219 279 364 minecraft:black_concrete
fill 220 209 322 220 217 322 minecraft:black_concrete
setblock 221 209 322 minecraft:white_concrete
fill 221 209 364 221 284 364 minecraft:black_concrete
setblock 226 209 325 minecraft:light[level=12]
setblock 226 209 332 minecraft:light[level=12]
setblock 226 209 339 minecraft:light[level=12]
setblock 226 209 346 minecraft:light[level=12]
setblock 226 209 353 minecraft:light[level=12]
setblock 226 209 360 minecraft:light[level=12]
setblock 230 209 350 minecraft:pearlescent_froglight
fill 230 209 355 230 232 355 minecraft:black_concrete
setblock 189 210 364 minecraft:pearlescent_froglight
fill 190 210 357 190 211 357 minecraft:lime_concrete
fill 190 210 359 190 211 359 minecraft:lime_concrete
fill 191 210 360 196 211 360 minecraft:lime_concrete
fill 195 210 356 195 213 356 minecraft:lime_concrete
fill 197 210 358 197 213 359 minecraft:lime_concrete
fill 204 210 333 205 210 333 minecraft:lime_stained_glass
setblock 205 210 334 minecraft:lime_stained_glass
fill 205 210 335 205 211 336 minecraft:gray_concrete
fill 213 210 323 215 210 327 minecraft:light_gray_concrete
fill 213 210 355 213 211 355 minecraft:end_stone
fill 216 210 323 216 228 323 minecraft:light_gray_concrete
fill 216 210 324 216 210 325 minecraft:lime_concrete
fill 216 210 326 216 210 327 minecraft:light_gray_concrete
setblock 217 210 323 minecraft:lime_concrete
setblock 217 210 327 minecraft:light_gray_concrete
setblock 218 210 327 minecraft:lime_concrete
setblock 219 210 323 minecraft:lime_concrete
fill 219 210 327 223 210 327 minecraft:light_gray_concrete
fill 220 210 323 223 210 323 minecraft:light_gray_concrete
fill 220 210 324 220 210 325 minecraft:lime_concrete
fill 220 210 326 223 210 326 minecraft:light_gray_concrete
fill 221 210 322 221 230 322 minecraft:black_concrete
fill 221 210 324 223 210 325 minecraft:light_gray_concrete
fill 225 210 359 225 214 359 minecraft:lime_concrete
fill 226 210 358 226 214 358 minecraft:lime_concrete
fill 226 210 360 226 214 360 minecraft:lime_concrete
setblock 227 210 322 minecraft:ochre_froglight
fill 230 210 350 230 280 350 minecraft:black_concrete
setblock 230 210 351 minecraft:white_concrete
fill 189 211 353 189 213 363 minecraft:light_gray_concrete
fill 189 211 364 189 214 364 minecraft:black_concrete
fill 190 211 353 190 213 355 minecraft:light_gray_concrete
setblock 190 211 356 minecraft:lime_concrete
fill 190 211 360 190 213 363 minecraft:light_gray_concrete
fill 191 211 353 195 212 354 minecraft:light_gray_concrete
fill 191 211 355 193 211 355 minecraft:lime_concrete
fill 191 211 361 193 211 363 minecraft:light_gray_concrete
fill 194 211 355 195 211 355 minecraft:light_gray_concrete
fill 194 211 356 194 213 356 minecraft:lime_concrete
fill 194 211 361 196 213 361 minecraft:lime_concrete
fill 194 211 362 195 212 363 minecraft:light_gray_concrete
fill 196 211 356 196 213 356 minecraft:lime_concrete
fill 197 211 357 197 213 357 minecraft:lime_concrete
fill 197 211 360 197 213 360 minecraft:lime_concrete
setblock 206 211 322 minecraft:pearlescent_froglight
setblock 213 211 323 minecraft:verdant_froglight
fill 213 211 324 213 228 324 minecraft:light_gray_concrete
setblock 213 211 325 minecraft:verdant_froglight
fill 213 211 326 213 228 326 minecraft:light_gray_concrete
setblock 213 211 327 minecraft:verdant_froglight
fill 214 211 323 214 228 323 minecraft:light_gray_concrete
setblock 214 211 324 minecraft:verdant_froglight
fill 214 211 325 214 228 325 minecraft:light_gray_concrete
setblock 214 211 326 minecraft:verdant_froglight
fill 214 211 327 214 228 327 minecraft:light_gray_concrete
setblock 215 211 323 minecraft:verdant_froglight
fill 215 211 324 215 228 324 minecraft:light_gray_concrete
setblock 215 211 325 minecraft:verdant_froglight
fill 215 211 326 215 228 326 minecraft:light_gray_concrete
setblock 215 211 327 minecraft:verdant_froglight
setblock 216 211 324 minecraft:verdant_froglight
fill 216 211 325 216 228 325 minecraft:light_gray_concrete
setblock 216 211 326 minecraft:verdant_froglight
fill 216 211 327 216 228 327 minecraft:light_gray_concrete
setblock 217 211 323 minecraft:verdant_froglight
fill 217 211 324 217 228 324 minecraft:light_gray_concrete
setblock 217 211 325 minecraft:verdant_froglight
fill 217 211 326 217 228 326 minecraft:light_gray_concrete
setblock 217 211 327 minecraft:verdant_froglight
fill 218 211 323 218 228 323 minecraft:light_gray_concrete
setblock 218 211 324 minecraft:verdant_froglight
fill 218 211 325 218 228 325 minecraft:light_gray_concrete
setblock 218 211 326 minecraft:verdant_froglight
fill 218 211 327 218 228 327 minecraft:light_gray_concrete
setblock 219 211 323 minecraft:verdant_froglight
fill 219 211 324 219 228 324 minecraft:light_gray_concrete
setblock 219 211 325 minecraft:verdant_froglight
fill 219 211 326 219 228 326 minecraft:light_gray_concrete
setblock 219 211 327 minecraft:verdant_froglight
fill 220 211 323 220 228 323 minecraft:light_gray_concrete
setblock 220 211 324 minecraft:verdant_froglight
fill 220 211 325 220 228 325 minecraft:light_gray_concrete
setblock 220 211 326 minecraft:verdant_froglight
fill 220 211 327 220 228 327 minecraft:light_gray_concrete
setblock 221 211 323 minecraft:verdant_froglight
fill 221 211 324 221 228 324 minecraft:light_gray_concrete
setblock 221 211 325 minecraft:verdant_froglight
fill 221 211 326 221 228 326 minecraft:light_gray_concrete
setblock 221 211 327 minecraft:verdant_froglight
fill 222 211 323 222 228 323 minecraft:light_gray_concrete
setblock 222 211 324 minecraft:verdant_froglight
fill 222 211 325 222 228 325 minecraft:light_gray_concrete
setblock 222 211 326 minecraft:verdant_froglight
fill 222 211 327 222 228 327 minecraft:light_gray_concrete
setblock 223 211 323 minecraft:verdant_froglight
fill 223 211 324 223 228 324 minecraft:light_gray_concrete
setblock 223 211 325 minecraft:verdant_froglight
fill 223 211 326 223 228 326 minecraft:light_gray_concrete
setblock 223 211 327 minecraft:verdant_froglight
fill 225 211 358 225 214 358 minecraft:lime_concrete
fill 225 211 360 225 214 360 minecraft:lime_concrete
fill 227 211 322 227 257 322 minecraft:black_concrete
fill 227 211 359 227 214 359 minecraft:lime_concrete
fill 230 211 351 230 236 351 minecraft:black_concrete
fill 190 212 356 191 212 359 minecraft:light_gray_concrete
fill 191 212 355 193 212 355 minecraft:light_gray_concrete
fill 191 212 360 191 213 363 minecraft:light_gray_concrete
setblock 192 212 356 minecraft:light_gray_concrete
fill 192 212 359 193 213 360 minecraft:lime_concrete
fill 192 212 361 192 212 363 minecraft:light_gray_concrete
fill 193 212 356 193 213 356 minecraft:lime_concrete
fill 193 212 361 193 213 361 minecraft:lime_concrete
fill 193 212 362 193 212 363 minecraft:light_gray_concrete
fill 194 212 355 196 213 355 minecraft:lime_concrete
fill 194 212 360 196 213 360 minecraft:lime_concrete
fill 197 212 356 197 213 356 minecraft:lime_concrete
fill 197 212 361 197 213 361 minecraft:lime_concrete
setblock 197 212 364 minecraft:ochre_froglight
fill 198 212 357 198 213 360 minecraft:lime_concrete
fill 206 212 322 206 271 322 minecraft:black_concrete
setblock 211 212 322 minecraft:white_concrete
fill 213 212 323 213 213 323 minecraft:light_gray_concrete
fill 213 212 325 213 213 325 minecraft:light_gray_concrete
fill 213 212 327 213 213 327 minecraft:light_gray_concrete
fill 214 212 324 214 213 324 minecraft:light_gray_concrete
fill 214 212 326 214 213 326 minecraft:light_gray_concrete
fill 215 212 323 215 213 323 minecraft:light_gray_concrete
fill 215 212 325 215 213 325 minecraft:light_gray_concrete
fill 215 212 327 215 213 327 minecraft:light_gray_concrete
fill 216 212 324 216 213 324 minecraft:light_gray_concrete
fill 216 212 326 216 213 326 minecraft:light_gray_concrete
fill 217 212 323 217 213 323 minecraft:light_gray_concrete
fill 217 212 325 217 213 325 minecraft:light_gray_concrete
fill 217 212 327 217 213 327 minecraft:light_gray_concrete
fill 218 212 324 218 213 324 minecraft:light_gray_concrete
fill 218 212 326 218 213 326 minecraft:light_gray_concrete
fill 219 212 323 219 213 323 minecraft:light_gray_concrete
fill 219 212 325 219 213 325 minecraft:light_gray_concrete
fill 219 212 327 219 213 327 minecraft:light_gray_concrete
fill 220 212 324 220 213 324 minecraft:light_gray_concrete
fill 220 212 326 220 213 326 minecraft:light_gray_concrete
fill 221 212 323 221 213 323 minecraft:light_gray_concrete
fill 221 212 325 221 213 325 minecraft:light_gray_concrete
fill 221 212 327 221 213 327 minecraft:light_gray_concrete
fill 222 212 324 222 213 324 minecraft:light_gray_concrete
fill 222 212 326 222 213 326 minecraft:light_gray_concrete
setblock 223 212 322 minecraft:sea_lantern
fill 223 212 323 223 213 323 minecraft:light_gray_concrete
fill 223 212 325 223 213 325 minecraft:light_gray_concrete
fill 223 212 327 223 213 327 minecraft:light_gray_concrete
fill 224 212 359 224 214 359 minecraft:lime_concrete
setblock 226 212 364 minecraft:sea_lantern
fill 227 212 358 227 214 358 minecraft:lime_concrete
fill 227 212 360 227 214 360 minecraft:lime_concrete
fill 190 213 356 190 213 359 minecraft:light_gray_concrete
setblock 191 213 325 minecraft:light[level=15]
setblock 191 213 333 minecraft:light[level=15]
setblock 191 213 341 minecraft:light[level=15]
setblock 191 213 349 minecraft:light[level=15]
fill 191 213 353 191 213 356 minecraft:light_gray_concrete
fill 191 213 357 191 213 359 minecraft:lime_concrete
fill 192 213 353 192 213 355 minecraft:light_gray_concrete
setblock 192 213 356 minecraft:lime_concrete
setblock 192 213 361 minecraft:lime_concrete
fill 192 213 362 192 213 363 minecraft:light_gray_concrete
fill 193 213 353 194 213 354 minecraft:light_gray_concrete
setblock 193 213 355 minecraft:lime_concrete
fill 193 213 362 197 213 362 minecraft:lime_concrete
fill 193 213 363 201 213 363 minecraft:light_gray_concrete
setblock 195 213 322 minecraft:ochre_froglight
setblock 195 213 353 minecraft:light_gray_concrete
setblock 195 213 354 minecraft:lime_concrete
fill 196 213 334 197 214 334 minecraft:end_stone
fill 196 213 354 201 228 354 minecraft:light_gray_concrete
setblock 197 213 355 minecraft:lime_concrete
fill 197 213 364 197 254 364 minecraft:black_concrete
fill 198 213 355 201 228 355 minecraft:light_gray_concrete
setblock 198 213 356 minecraft:lime_concrete
setblock 198 213 361 minecraft:lime_concrete
fill 198 213 362 201 228 362 minecraft:light_gray_concrete
setblock 199 213 325 minecraft:light[level=15]
setblock 199 213 333 minecraft:light[level=15]
setblock 199 213 341 minecraft:light[level=15]
setblock 199 213 349 minecraft:light[level=15]
fill 199 213 356 201 228 356 minecraft:light_gray_concrete
fill 199 213 357 199 213 359 minecraft:lime_concrete
fill 199 213 360 201 228 361 minecraft:light_gray_concrete
fill 200 213 357 201 228 359 minecraft:light_gray_concrete
setblock 207 213 325 minecraft:light[level=15]
setblock 207 213 333 minecraft:light[level=15]
setblock 207 213 341 minecraft:light[level=15]
setblock 207 213 349 minecraft:light[level=15]
setblock 207 213 357 minecraft:light[level=15]
fill 211 213 322 211 216 322 minecraft:black_concrete
setblock 213 213 322 minecraft:white_concrete
setblock 215 213 333 minecraft:light[level=15]
setblock 215 213 341 minecraft:light[level=15]
setblock 215 213 349 minecraft:light[level=15]
setblock 215 213 357 minecraft:light[level=15]
setblock 220 213 364 minecraft:white_concrete
fill 223 213 322 223 280 322 minecraft:black_concrete
setblock 223 213 333 minecraft:light[level=15]
setblock 223 213 341 minecraft:light[level=15]
setblock 223 213 349 minecraft:light[level=15]
setblock 223 213 357 minecraft:light[level=15]
fill 224 213 358 224 214 358 minecraft:lime_concrete
fill 224 213 360 224 214 360 minecraft:lime_concrete
fill 225 213 357 226 214 357 minecraft:lime_concrete
fill 225 213 361 226 214 361 minecraft:lime_concrete
fill 226 213 364 226 231 364 minecraft:black_concrete
fill 228 213 359 228 214 359 minecraft:lime_concrete
setblock 230 213 347 minecraft:pearlescent_froglight
setblock 188 214 362 minecraft:white_concrete
setblock 189 214 353 minecraft:verdant_froglight
fill 189 214 354 189 228 354 minecraft:light_gray_concrete
setblock 189 214 355 minecraft:verdant_froglight
fill 189 214 356 189 228 356 minecraft:light_gray_concrete
setblock 189 214 357 minecraft:verdant_froglight
fill 189 214 358 189 228 358 minecraft:light_gray_concrete
setblock 189 214 359 minecraft:verdant_froglight
fill 189 214 360 189 228 360 minecraft:light_gray_concrete
setblock 189 214 361 minecraft:verdant_froglight
fill 189 214 362 189 228 362 minecraft:light_gray_concrete
setblock 189 214 363 minecraft:verdant_froglight
fill 190 214 353 190 228 353 minecraft:light_gray_concrete
setblock 190 214 354 minecraft:verdant_froglight
fill 190 214 355 190 228 355 minecraft:light_gray_concrete
setblock 190 214 356 minecraft:verdant_froglight
fill 190 214 357 190 228 357 minecraft:light_gray_concrete
setblock 190 214 358 minecraft:verdant_froglight
fill 190 214 359 190 228 359 minecraft:light_gray_concrete
setblock 190 214 360 minecraft:verdant_froglight
fill 190 214 361 190 228 361 minecraft:light_gray_concrete
setblock 190 214 362 minecraft:verdant_froglight
fill 190 214 363 190 228 363 minecraft:light_gray_concrete
setblock 191 214 353 minecraft:verdant_froglight
fill 191 214 354 191 228 354 minecraft:light_gray_concrete
setblock 191 214 355 minecraft:verdant_froglight
fill 191 214 356 191 228 356 minecraft:light_gray_concrete
setblock 191 214 357 minecraft:verdant_froglight
fill 191 214 358 191 228 358 minecraft:light_gray_concrete
setblock 191 214 359 minecraft:verdant_froglight
fill 191 214 360 191 228 360 minecraft:light_gray_concrete
setblock 191 214 361 minecraft:verdant_froglight
fill 191 214 362 191 228 362 minecraft:light_gray_concrete
setblock 191 214 363 minecraft:verdant_froglight
setblock 191 214 364 minecraft:sea_lantern
fill 192 214 353 192 228 353 minecraft:light_gray_concrete
setblock 192 214 354 minecraft:verdant_froglight
fill 192 214 355 192 228 355 minecraft:light_gray_concrete
setblock 192 214 356 minecraft:verdant_froglight
fill 192 214 357 192 228 357 minecraft:light_gray_concrete
setblock 192 214 358 minecraft:verdant_froglight
fill 192 214 359 192 228 359 minecraft:light_gray_concrete
setblock 192 214 360 minecraft:verdant_froglight
fill 192 214 361 192 228 361 minecraft:light_gray_concrete
setblock 192 214 362 minecraft:verdant_froglight
fill 192 214 363 192 228 363 minecraft:light_gray_concrete
setblock 193 214 353 minecraft:verdant_froglight
fill 193 214 354 193 228 354 minecraft:light_gray_concrete
setblock 193 214 355 minecraft:verdant_froglight
fill 193 214 356 193 228 356 minecraft:light_gray_concrete
setblock 193 214 357 minecraft:verdant_froglight
fill 193 214 358 193 228 358 minecraft:light_gray_concrete
setblock 193 214 359 minecraft:verdant_froglight
fill 193 214 360 193 228 360 minecraft:light_gray_concrete
setblock 193 214 361 minecraft:verdant_froglight
fill 193 214 362 193 228 362 minecraft:light_gray_concrete
setblock 193 214 363 minecraft:verdant_froglight
fill 194 214 353 194 228 353 minecraft:light_gray_concrete
setblock 194 214 354 minecraft:verdant_froglight
fill 194 214 355 194 228 355 minecraft:light_gray_concrete
setblock 194 214 356 minecraft:verdant_froglight
fill 194 214 357 194 228 357 minecraft:light_gray_concrete
setblock 194 214 358 minecraft:verdant_froglight
fill 194 214 359 194 228 359 minecraft:light_gray_concrete
setblock 194 214 360 minecraft:verdant_froglight
fill 194 214 361 194 228 361 minecraft:light_gray_concrete
setblock 194 214 362 minecraft:verdant_froglight
fill 194 214 363 194 228 363 minecraft:light_gray_concrete
fill 195 214 322 195 219 322 minecraft:black_concrete
setblock 195 214 353 minecraft:verdant_froglight
fill 195 214 354 195 228 354 minecraft:light_gray_concrete
setblock 195 214 355 minecraft:verdant_froglight
fill 195 214 356 198 228 356 minecraft:light_gray_concrete
setblock 195 214 357 minecraft:verdant_froglight
fill 195 214 358 199 228 358 minecraft:light_gray_concrete
setblock 195 214 359 minecraft:verdant_froglight
fill 195 214 360 198 228 360 minecraft:light_gray_concrete
setblock 195 214 361 minecraft:verdant_froglight
fill 195 214 362 197 228 362 minecraft:light_gray_concrete
setblock 195 214 363 minecraft:verdant_froglight
fill 196 214 355 197 228 355 minecraft:light_gray_concrete
fill 196 214 357 199 228 357 minecraft:light_gray_concrete
fill 196 214 359 199 228 359 minecraft:light_gray_concrete
fill 196 214 361 198 228 361 minecraft:light_gray_concrete
fill 196 214 363 201 228 363 minecraft:light_gray_concrete
fill 213 214 322 213 245 322 minecraft:black_concrete
setblock 213 214 323 minecraft:verdant_froglight
setblock 213 214 325 minecraft:verdant_froglight
setblock 213 214 327 minecraft:verdant_froglight
setblock 214 214 324 minecraft:verdant_froglight
setblock 214 214 326 minecraft:verdant_froglight
setblock 215 214 323 minecraft:verdant_froglight
setblock 215 214 325 minecraft:verdant_froglight
setblock 215 214 327 minecraft:verdant_froglight
setblock 216 214 324 minecraft:verdant_froglight
setblock 216 214 326 minecraft:verdant_froglight
setblock 217 214 323 minecraft:verdant_froglight
setblock 217 214 325 minecraft:verdant_froglight
setblock 217 214 327 minecraft:verdant_froglight
setblock 218 214 324 minecraft:verdant_froglight
setblock 218 214 326 minecraft:verdant_froglight
setblock 219 214 323 minecraft:verdant_froglight
setblock 219 214 325 minecraft:verdant_froglight
setblock 219 214 327 minecraft:verdant_froglight
setblock 220 214 324 minecraft:verdant_froglight
setblock 220 214 326 minecraft:verdant_froglight
fill 220 214 364 220 220 364 minecraft:black_concrete
setblock 221 214 323 minecraft:verdant_froglight
setblock 221 214 325 minecraft:verdant_froglight
setblock 221 214 327 minecraft:verdant_froglight
setblock 222 214 324 minecraft:verdant_froglight
setblock 222 214 326 minecraft:verdant_froglight
setblock 223 214 323 minecraft:verdant_froglight
setblock 223 214 325 minecraft:verdant_froglight
setblock 223 214 327 minecraft:verdant_froglight
fill 223 214 344 224 215 345 minecraft:gray_concrete
fill 223 214 355 223 216 358 minecraft:light_gray_concrete
setblock 223 214 359 minecraft:lime_concrete
fill 223 214 360 223 216 363 minecraft:light_gray_concrete
fill 224 214 355 229 216 356 minecraft:light_gray_concrete
setblock 224 214 357 minecraft:lime_concrete
setblock 224 214 361 minecraft:lime_concrete
fill 224 214 362 229 216 363 minecraft:light_gray_concrete
setblock 227 214 357 minecraft:lime_concrete
setblock 227 214 361 minecraft:lime_concrete
fill 228 214 357 229 216 357 minecraft:light_gray_concrete
setblock 228 214 358 minecraft:lime_concrete
setblock 228 214 360 minecraft:lime_concrete
fill 228 214 361 229 216 361 minecraft:light_gray_concrete
fill 229 214 358 229 216 360 minecraft:light_gray_concrete
setblock 230 214 335 minecraft:white_concrete
fill 230 214 347 230 290 347 minecraft:black_concrete
setblock 230 214 356 minecraft:ochre_froglight
setblock 188 215 343 minecraft:ochre_froglight
fill 188 215 352 188 216 352 minecraft:pearlescent_froglight
setblock 188 215 360 minecraft:ochre_froglight
fill 188 215 362 188 308 362 minecraft:black_concrete
fill 189 215 353 189 216 353 minecraft:light_gray_concrete
fill 189 215 355 189 216 355 minecraft:light_gray_concrete
fill 189 215 357 189 216 357 minecraft:light_gray_concrete
fill 189 215 359 189 216 359 minecraft:light_gray_concrete
fill 189 215 361 189 216 361 minecraft:light_gray_concrete
fill 189 215 363 189 216 363 minecraft:light_gray_concrete
setblock 189 215 364 minecraft:white_concrete
fill 190 215 354 190 216 354 minecraft:light_gray_concrete
fill 190 215 356 190 216 356 minecraft:light_gray_concrete
fill 190 215 358 190 216 358 minecraft:light_gray_concrete
fill 190 215 360 190 216 360 minecraft:light_gray_concrete
fill 190 215 362 190 216 362 minecraft:light_gray_concrete
setblock 191 215 325 minecraft:light[level=12]
setblock 191 215 332 minecraft:light[level=12]
setblock 191 215 339 minecraft:light[level=12]
setblock 191 215 346 minecraft:light[level=12]
fill 191 215 353 191 216 353 minecraft:light_gray_concrete
fill 191 215 355 191 216 355 minecraft:light_gray_concrete
fill 191 215 357 191 216 357 minecraft:light_gray_concrete
fill 191 215 359 191 216 359 minecraft:light_gray_concrete
fill 191 215 361 191 216 361 minecraft:light_gray_concrete
fill 191 215 363 191 216 363 minecraft:light_gray_concrete
fill 191 215 364 191 296 364 minecraft:black_concrete
fill 192 215 354 192 216 354 minecraft:light_gray_concrete
fill 192 215 356 192 216 356 minecraft:light_gray_concrete
fill 192 215 358 192 216 358 minecraft:light_gray_concrete
fill 192 215 360 192 216 360 minecraft:light_gray_concrete
fill 192 215 362 192 216 362 minecraft:light_gray_concrete
fill 193 215 353 193 216 353 minecraft:light_gray_concrete
fill 193 215 355 193 216 355 minecraft:light_gray_concrete
fill 193 215 357 193 216 357 minecraft:light_gray_concrete
fill 193 215 359 193 216 359 minecraft:light_gray_concrete
fill 193 215 361 193 216 361 minecraft:light_gray_concrete
fill 193 215 363 193 216 363 minecraft:light_gray_concrete
setblock 193 215 364 minecraft:sea_lantern
fill 194 215 354 194 216 354 minecraft:light_gray_concrete
fill 194 215 356 194 216 356 minecraft:light_gray_concrete
fill 194 215 358 194 216 358 minecraft:light_gray_concrete
fill 194 215 360 194 216 360 minecraft:light_gray_concrete
fill 194 215 362 194 216 362 minecraft:light_gray_concrete
fill 195 215 353 195 216 353 minecraft:light_gray_concrete
fill 195 215 355 195 216 355 minecraft:light_gray_concrete
fill 195 215 357 195 216 357 minecraft:light_gray_concrete
fill 195 215 359 195 216 359 minecraft:light_gray_concrete
fill 195 215 361 195 216 361 minecraft:light_gray_concrete
fill 195 215 363 195 216 363 minecraft:light_gray_concrete
setblock 198 215 325 minecraft:light[level=12]
setblock 198 215 332 minecraft:light[level=12]
setblock 198 215 339 minecraft:light[level=12]
setblock 198 215 346 minecraft:light[level=12]
setblock 198 215 353 minecraft:light[level=12]
setblock 205 215 325 minecraft:light[level=12]
setblock 205 215 332 minecraft:light[level=12]
setblock 205 215 339 minecraft:light[level=12]
setblock 205 215 346 minecraft:light[level=12]
setblock 205 215 353 minecraft:light[level=12]
setblock 205 215 360 minecraft:light[level=12]
setblock 212 215 325 minecraft:light[level=12]
setblock 212 215 332 minecraft:light[level=12]
setblock 212 215 339 minecraft:light[level=12]
setblock 212 215 346 minecraft:light[level=12]
setblock 212 215 353 minecraft:light[level=12]
setblock 212 215 360 minecraft:light[level=12]
fill 213 215 323 213 216 323 minecraft:light_gray_concrete
fill 213 215 325 213 216 325 minecraft:light_gray_concrete
fill 213 215 327 213 216 327 minecraft:light_gray_concrete
fill 214 215 324 214 216 324 minecraft:light_gray_concrete
fill 214 215 326 214 216 326 minecraft:light_gray_concrete
setblock 215 215 322 minecraft:white_concrete
fill 215 215 323 215 216 323 minecraft:light_gray_concrete
fill 215 215 325 215 216 325 minecraft:light_gray_concrete
fill 215 215 327 215 216 327 minecraft:light_gray_concrete
fill 216 215 324 216 216 324 minecraft:light_gray_concrete
fill 216 215 326 216 216 326 minecraft:light_gray_concrete
fill 217 215 323 217 216 323 minecraft:light_gray_concrete
fill 217 215 325 217 216 325 minecraft:light_gray_concrete
fill 217 215 327 217 216 327 minecraft:light_gray_concrete
fill 218 215 324 218 216 324 minecraft:light_gray_concrete
fill 218 215 326 218 216 326 minecraft:light_gray_concrete
fill 219 215 323 219 216 323 minecraft:light_gray_concrete
fill 219 215 325 219 216 325 minecraft:light_gray_concrete
fill 219 215 327 219 216 327 minecraft:light_gray_concrete
setblock 219 215 332 minecraft:light[level=12]
setblock 219 215 339 minecraft:light[level=12]
setblock 219 215 346 minecraft:light[level=12]
setblock 219 215 353 minecraft:light[level=12]
setblock 219 215 360 minecraft:light[level=12]
fill 220 215 324 220 216 324 minecraft:light_gray_concrete
fill 220 215 326 220 216 326 minecraft:light_gray_concrete
fill 221 215 323 221 216 323 minecraft:light_gray_concrete
fill 221 215 325 221 216 325 minecraft:light_gray_concrete
fill 221 215 327 221 216 327 minecraft:light_gray_concrete
fill 222 215 324 222 216 324 minecraft:light_gray_concrete
fill 222 215 326 222 216 326 minecraft:light_gray_concrete
fill 223 215 323 223 216 323 minecraft:light_gray_concrete
fill 223 215 325 223 216 325 minecraft:light_gray_concrete
fill 223 215 327 223 216 327 minecraft:light_gray_concrete
fill 223 215 359 228 216 359 minecraft:light_gray_concrete
fill 224 215 357 227 216 358 minecraft:light_gray_concrete
fill 224 215 360 227 216 361 minecraft:light_gray_concrete
setblock 226 215 325 minecraft:light[level=12]
setblock 226 215 332 minecraft:light[level=12]
setblock 226 215 339 minecraft:light[level=12]
setblock 226 215 346 minecraft:light[level=12]
setblock 226 215 353 minecraft:light[level=12]
fill 228 215 358 228 216 358 minecraft:light_gray_concrete
fill 228 215 360 228 216 360 minecraft:light_gray_concrete
fill 230 215 335 230 219 335 minecraft:black_concrete
fill 230 215 356 230 267 356 minecraft:black_concrete
fill 188 216 343 188 256 343 minecraft:black_concrete
setblock 188 216 357 minecraft:ochre_froglight
fill 188 216 360 188 230 360 minecraft:black_concrete
fill 189 216 364 189 239 364 minecraft:black_concrete
fill 193 216 364 193 276 364 minecraft:black_concrete
setblock 194 216 322 minecraft:pearlescent_froglight
fill 215 216 322 215 246 322 minecraft:black_concrete
fill 188 217 352 188 233 352 minecraft:black_concrete
fill 188 217 357 188 231 357 minecraft:black_concrete
setblock 189 217 353 minecraft:verdant_froglight
setblock 189 217 355 minecraft:verdant_froglight
setblock 189 217 357 minecraft:verdant_froglight
setblock 189 217 359 minecraft:verdant_froglight
setblock 189 217 361 minecraft:verdant_froglight
setblock 189 217 363 minecraft:verdant_froglight
setblock 190 217 354 minecraft:verdant_froglight
setblock 190 217 356 minecraft:verdant_froglight
setblock 190 217 358 minecraft:verdant_froglight
setblock 190 217 360 minecraft:verdant_froglight
setblock 190 217 362 minecraft:verdant_froglight
setblock 190 217 364 minecraft:ochre_froglight
setblock 191 217 353 minecraft:verdant_froglight
setblock 191 217 355 minecraft:verdant_froglight
setblock 191 217 357 minecraft:verdant_froglight
setblock 191 217 359 minecraft:verdant_froglight
setblock 191 217 361 minecraft:verdant_froglight
setblock 191 217 363 minecraft:verdant_froglight
setblock 192 217 354 minecraft:verdant_froglight
setblock 192 217 356 minecraft:verdant_froglight
setblock 192 217 358 minecraft:verdant_froglight
setblock 192 217 360 minecraft:verdant_froglight
setblock 192 217 362 minecraft:verdant_froglight
setblock 193 217 322 minecraft:white_concrete
setblock 193 217 353 minecraft:verdant_froglight
setblock 193 217 355 minecraft:verdant_froglight
setblock 193 217 357 minecraft:verdant_froglight
setblock 193 217 359 minecraft:verdant_froglight
setblock 193 217 361 minecraft:verdant_froglight
setblock 193 217 363 minecraft:verdant_froglight
fill 194 217 322 194 245 322 minecraft:black_concrete
setblock 194 217 354 minecraft:verdant_froglight
setblock 194 217 356 minecraft:verdant_froglight
setblock 194 217 358 minecraft:verdant_froglight
setblock 194 217 360 minecraft:verdant_froglight
setblock 194 217 362 minecraft:verdant_froglight
setblock 195 217 353 minecraft:verdant_froglight
setblock 195 217 355 minecraft:verdant_froglight
setblock 195 217 357 minecraft:verdant_froglight
setblock 195 217 359 minecraft:verdant_froglight
setblock 195 217 361 minecraft:verdant_froglight
setblock 195 217 363 minecraft:verdant_froglight
setblock 211 217 322 minecraft:pearlescent_froglight
setblock 213 217 323 minecraft:verdant_froglight
setblock 213 217 325 minecraft:verdant_froglight
setblock 213 217 327 minecraft:verdant_froglight
setblock 214 217 324 minecraft:verdant_froglight
setblock 214 217 326 minecraft:verdant_froglight
setblock 215 217 323 minecraft:verdant_froglight
setblock 215 217 325 minecraft:verdant_froglight
setblock 215 217 327 minecraft:verdant_froglight
setblock 216 217 324 minecraft:verdant_froglight
setblock 216 217 326 minecraft:verdant_froglight
setblock 217 217 323 minecraft:verdant_froglight
setblock 217 217 325 minecraft:verdant_froglight
setblock 217 217 327 minecraft:verdant_froglight
setblock 218 217 324 minecraft:verdant_froglight
setblock 218 217 326 minecraft:verdant_froglight
setblock 219 217 323 minecraft:verdant_froglight
setblock 219 217 325 minecraft:verdant_froglight
setblock 219 217 327 minecraft:verdant_froglight
setblock 220 217 324 minecraft:verdant_froglight
setblock 220 217 326 minecraft:verdant_froglight
setblock 221 217 323 minecraft:verdant_froglight
setblock 221 217 325 minecraft:verdant_froglight
setblock 221 217 327 minecraft:verdant_froglight
setblock 222 217 324 minecraft:verdant_froglight
setblock 222 217 326 minecraft:verdant_froglight
setblock 223 217 323 minecraft:verdant_froglight
setblock 223 217 325 minecraft:verdant_froglight
setblock 223 217 327 minecraft:verdant_froglight
setblock 223 217 355 minecraft:verdant_froglight
fill 223 217 356 223 228 356 minecraft:light_gray_concrete
setblock 223 217 357 minecraft:verdant_froglight
fill 223 217 358 223 228 358 minecraft:light_gray_concrete
setblock 223 217 359 minecraft:verdant_froglight
fill 223 217 360 223 228 360 minecraft:light_gray_concrete
setblock 223 217 361 minecraft:verdant_froglight
fill 223 217 362 223 228 362 minecraft:light_gray_concrete
setblock 223 217 363 minecraft:verdant_froglight
setblock 224 217 322 minecraft:ochre_froglight
fill 224 217 355 224 228 355 minecraft:light_gray_concrete
setblock 224 217 356 minecraft:verdant_froglight
fill 224 217 357 224 228 357 minecraft:light_gray_concrete
setblock 224 217 358 minecraft:verdant_froglight
fill 224 217 359 224 228 359 minecraft:light_gray_concrete
setblock 224 217 360 minecraft:verdant_froglight
fill 224 217 361 224 228 361 minecraft:light_gray_concrete
setblock 224 217 362 minecraft:verdant_froglight
fill 224 217 363 224 228 363 minecraft:light_gray_concrete
setblock 225 217 355 minecraft:verdant_froglight
fill 225 217 356 225 228 356 minecraft:light_gray_concrete
setblock 225 217 357 minecraft:verdant_froglight
fill 225 217 358 225 228 358 minecraft:light_gray_concrete
setblock 225 217 359 minecraft:verdant_froglight
fill 225 217 360 225 228 360 minecraft:light_gray_concrete
setblock 225 217 361 minecraft:verdant_froglight
fill 225 217 362 225 228 362 minecraft:light_gray_concrete
setblock 225 217 363 minecraft:verdant_froglight
fill 226 217 355 226 228 355 minecraft:light_gray_concrete
setblock 226 217 356 minecraft:verdant_froglight
fill 226 217 357 226 228 357 minecraft:light_gray_concrete
setblock 226 217 358 minecraft:verdant_froglight
fill 226 217 359 226 228 359 minecraft:light_gray_concrete
setblock 226 217 360 minecraft:verdant_froglight
fill 226 217 361 226 228 361 minecraft:light_gray_concrete
setblock 226 217 362 minecraft:verdant_froglight
fill 226 217 363 226 228 363 minecraft:light_gray_concrete
setblock 227 217 355 minecraft:verdant_froglight
fill 227 217 356 227 228 356 minecraft:light_gray_concrete
setblock 227 217 357 minecraft:verdant_froglight
fill 227 217 358 227 228 358 minecraft:light_gray_concrete
setblock 227 217 359 minecraft:verdant_froglight
fill 227 217 360 227 228 360 minecraft:light_gray_concrete
setblock 227 217 361 minecraft:verdant_froglight
fill 227 217 362 227 228 362 minecraft:light_gray_concrete
setblock 227 217 363 minecraft:verdant_froglight
fill 228 217 355 228 228 355 minecraft:light_gray_concrete
setblock 228 217 356 minecraft:verdant_froglight
fill 228 217 357 228 228 357 minecraft:light_gray_concrete
setblock 228 217 358 minecraft:verdant_froglight
fill 228 217 359 228 228 359 minecraft:light_gray_concrete
setblock 228 217 360 minecraft:verdant_froglight
fill 228 217 361 228 228 361 minecraft:light_gray_concrete
setblock 228 217 362 minecraft:verdant_froglight
fill 228 217 363 228 228 363 minecraft:light_gray_concrete
setblock 229 217 355 minecraft:verdant_froglight
fill 229 217 356 229 228 356 minecraft:light_gray_concrete
setblock 229 217 357 minecraft:verdant_froglight
fill 229 217 358 229 228 358 minecraft:light_gray_concrete
setblock 229 217 359 minecraft:verdant_froglight
fill 229 217 360 229 228 360 minecraft:light_gray_concrete
setblock 229 217 361 minecraft:verdant_froglight
fill 229 217 362 229 228 362 minecraft:light_gray_concrete
setblock 229 217 363 minecraft:verdant_froglight
setblock 188 218 335 minecraft:ochre_froglight
setblock 188 218 340 minecraft:ochre_froglight
fill 189 218 353 189 219 353 minecraft:light_gray_concrete
fill 189 218 355 189 219 355 minecraft:light_gray_concrete
fill 189 218 357 189 219 357 minecraft:light_gray_concrete
fill 189 218 359 189 219 359 minecraft:light_gray_concrete
fill 189 218 361 189 219 361 minecraft:light_gray_concrete
fill 189 218 363 189 219 363 minecraft:light_gray_concrete
fill 190 218 354 190 219 354 minecraft:light_gray_concrete
fill 190 218 356 190 219 356 minecraft:light_gray_concrete
fill 190 218 358 190 219 358 minecraft:light_gray_concrete
fill 190 218 360 190 219 360 minecraft:light_gray_concrete
fill 190 218 362 190 219 362 minecraft:light_gray_concrete
setblock 190 218 364 minecraft:black_concrete
fill 191 218 353 191 219 353 minecraft:light_gray_concrete
fill 191 218 355 191 219 355 minecraft:light_gray_concrete
fill 191 218 357 191 219 357 minecraft:light_gray_concrete
fill 191 218 359 191 219 359 minecraft:light_gray_concrete
fill 191 218 361 191 219 361 minecraft:light_gray_concrete
fill 191 218 363 191 219 363 minecraft:light_gray_concrete
fill 192 218 354 192 219 354 minecraft:light_gray_concrete
fill 192 218 356 192 219 356 minecraft:light_gray_concrete
fill 192 218 358 192 219 358 minecraft:light_gray_concrete
fill 192 218 360 192 219 360 minecraft:light_gray_concrete
fill 192 218 362 192 219 362 minecraft:light_gray_concrete
fill 193 218 322 193 269 322 minecraft:black_concrete
fill 193 218 353 193 219 353 minecraft:light_gray_concrete
fill 193 218 355 193 219 355 minecraft:light_gray_concrete
fill 193 218 357 193 219 357 minecraft:light_gray_concrete
fill 193 218 359 193 219 359 minecraft:light_gray_concrete
fill 193 218 361 193 219 361 minecraft:light_gray_concrete
fill 193 218 363 193 219 363 minecraft:light_gray_concrete
fill 194 218 354 194 219 354 minecraft:light_gray_concrete
fill 194 218 356 194 219 356 minecraft:light_gray_concrete
fill 194 218 358 194 219 358 minecraft:light_gray_concrete
fill 194 218 360 194 219 360 minecraft:light_gray_concrete
fill 194 218 362 194 219 362 minecraft:light_gray_concrete
fill 195 218 353 195 219 353 minecraft:light_gray_concrete
fill 195 218 355 195 219 355 minecraft:light_gray_concrete
fill 195 218 357 195 219 357 minecraft:light_gray_concrete
fill 195 218 359 195 219 359 minecraft:light_gray_concrete
fill 195 218 361 195 219 361 minecraft:light_gray_concrete
fill 195 218 363 195 219 363 minecraft:light_gray_concrete
setblock 209 218 322 minecraft:ochre_froglight
setblock 211 218 322 minecraft:black_concrete
fill 213 218 323 213 219 323 minecraft:light_gray_concrete
fill 213 218 325 213 219 325 minecraft:light_gray_concrete
fill 213 218 327 213 219 327 minecraft:light_gray_concrete
fill 214 218 324 214 219 324 minecraft:light_gray_concrete
fill 214 218 326 214 219 326 minecraft:light_gray_concrete
fill 215 218 323 215 219 323 minecraft:light_gray_concrete
fill 215 218 325 215 219 325 minecraft:light_gray_concrete
fill 215 218 327 215 219 327 minecraft:light_gray_concrete
fill 216 218 324 216 219 324 minecraft:light_gray_concrete
fill 216 218 326 216 219 326 minecraft:light_gray_concrete
fill 217 218 323 217 219 323 minecraft:light_gray_concrete
fill 217 218 325 217 219 325 minecraft:light_gray_concrete
fill 217 218 327 217 219 327 minecraft:light_gray_concrete
fill 218 218 324 218 219 324 minecraft:light_gray_concrete
fill 218 218 326 218 219 326 minecraft:light_gray_concrete
fill 219 218 323 219 219 323 minecraft:light_gray_concrete
fill 219 218 325 219 219 325 minecraft:light_gray_concrete
fill 219 218 327 219 219 327 minecraft:light_gray_concrete
setblock 220 218 322 minecraft:ochre_froglight
fill 220 218 324 220 219 324 minecraft:light_gray_concrete
fill 220 218 326 220 219 326 minecraft:light_gray_concrete
fill 221 218 323 221 219 323 minecraft:light_gray_concrete
fill 221 218 325 221 219 325 minecraft:light_gray_concrete
fill 221 218 327 221 219 327 minecraft:light_gray_concrete
fill 222 218 324 222 219 324 minecraft:light_gray_concrete
fill 222 218 326 222 219 326 minecraft:light_gray_concrete
fill 223 218 323 223 219 323 minecraft:light_gray_concrete
fill 223 218 325 223 219 325 minecraft:light_gray_concrete
fill 223 218 327 223 219 327 minecraft:light_gray_concrete
fill 223 218 355 223 219 355 minecraft:light_gray_concrete
fill 223 218 357 223 219 357 minecraft:light_gray_concrete
fill 223 218 359 223 219 359 minecraft:light_gray_concrete
fill 223 218 361 223 219 361 minecraft:light_gray_concrete
fill 223 218 363 223 219 363 minecraft:light_gray_concrete
fill 224 218 322 224 261 322 minecraft:black_concrete
fill 224 218 356 224 219 356 minecraft:light_gray_concrete
fill 224 218 358 224 219 358 minecraft:light_gray_concrete
fill 224 218 360 224 219 360 minecraft:light_gray_concrete
fill 224 218 362 224 219 362 minecraft:light_gray_concrete
setblock 225 218 322 minecraft:ochre_froglight
fill 225 218 355 225 219 355 minecraft:light_gray_concrete
fill 225 218 357 225 219 357 minecraft:light_gray_concrete
fill 225 218 359 225 219 359 minecraft:light_gray_concrete
fill 225 218 361 225 219 361 minecraft:light_gray_concrete
fill 225 218 363 225 219 363 minecraft:light_gray_concrete
fill 226 218 356 226 219 356 minecraft:light_gray_concrete
fill 226 218 358 226 219 358 minecraft:light_gray_concrete
fill 226 218 360 226 219 360 minecraft:light_gray_concrete
fill 226 218 362 226 219 362 minecraft:light_gray_concrete
fill 227 218 355 227 219 355 minecraft:light_gray_concrete
fill 227 218 357 227 219 357 minecraft:light_gray_concrete
fill 227 218 359 227 219 359 minecraft:light_gray_concrete
fill 227 218 361 227 219 361 minecraft:light_gray_concrete
fill 227 218 363 227 219 363 minecraft:light_gray_concrete
fill 228 218 356 228 219 356 minecraft:light_gray_concrete
fill 228 218 358 228 219 358 minecraft:light_gray_concrete
fill 228 218 360 228 219 360 minecraft:light_gray_concrete
fill 228 218 362 228 219 362 minecraft:light_gray_concrete
fill 229 218 355 229 219 355 minecraft:light_gray_concrete
fill 229 218 357 229 219 357 minecraft:light_gray_concrete
fill 229 218 359 229 219 359 minecraft:light_gray_concrete
fill 229 218 361 229 219 361 minecraft:light_gray_concrete
fill 229 218 363 229 219 363 minecraft:light_gray_concrete
setblock 230 218 326 minecraft:white_concrete
setblock 188 219 333 minecraft:sea_lantern
fill 188 219 335 188 308 335 minecraft:black_concrete
fill 188 219 340 188 305 340 minecraft:black_concrete
setblock 190 219 364 minecraft:pearlescent_froglight
fill 209 219 322 209 259 322 minecraft:black_concrete
setblock 211 219 322 minecraft:sea_lantern
fill 220 219 322 220 243 322 minecraft:black_concrete
fill 225 219 322 225 230 322 minecraft:black_concrete
fill 230 219 326 230 223 326 minecraft:black_concrete
setblock 230 219 354 minecraft:sea_lantern
fill 188 220 333 188 222 333 minecraft:black_concrete
setblock 188 220 351 minecraft:sea_lantern
setblock 189 220 322 minecraft:pearlescent_froglight
setblock 189 220 353 minecraft:verdant_froglight
setblock 189 220 355 minecraft:verdant_froglight
setblock 189 220 357 minecraft:verdant_froglight
setblock 189 220 359 minecraft:verdant_froglight
setblock 189 220 361 minecraft:verdant_froglight
setblock 189 220 363 minecraft:verdant_froglight
setblock 190 220 354 minecraft:verdant_froglight
setblock 190 220 356 minecraft:verdant_froglight
setblock 190 220 358 minecraft:verdant_froglight
setblock 190 220 360 minecraft:verdant_froglight
setblock 190 220 362 minecraft:verdant_froglight
fill 190 220 364 190 244 364 minecraft:black_concrete
setblock 191 220 353 minecraft:verdant_froglight
setblock 191 220 355 minecraft:verdant_froglight
setblock 191 220 357 minecraft:verdant_froglight
setblock 191 220 359 minecraft:verdant_froglight
setblock 191 220 361 minecraft:verdant_froglight
setblock 191 220 363 minecraft:verdant_froglight
setblock 192 220 354 minecraft:verdant_froglight
setblock 192 220 356 minecraft:verdant_froglight
setblock 192 220 358 minecraft:verdant_froglight
setblock 192 220 360 minecraft:verdant_froglight
setblock 192 220 362 minecraft:verdant_froglight
setblock 193 220 353 minecraft:verdant_froglight
setblock 193 220 355 minecraft:verdant_froglight
setblock 193 220 357 minecraft:verdant_froglight
setblock 193 220 359 minecraft:verdant_froglight
setblock 193 220 361 minecraft:verdant_froglight
setblock 193 220 363 minecraft:verdant_froglight
setblock 194 220 354 minecraft:verdant_froglight
setblock 194 220 356 minecraft:verdant_froglight
setblock 194 220 358 minecraft:verdant_froglight
setblock 194 220 360 minecraft:verdant_froglight
setblock 194 220 362 minecraft:verdant_froglight
setblock 195 220 322 minecraft:pearlescent_froglight
setblock 195 220 353 minecraft:verdant_froglight
setblock 195 220 355 minecraft:verdant_froglight
setblock 195 220 357 minecraft:verdant_froglight
setblock 195 220 359 minecraft:verdant_froglight
setblock 195 220 361 minecraft:verdant_froglight
setblock 195 220 363 minecraft:verdant_froglight
setblock 203 220 364 minecraft:ochre_froglight
fill 211 220 322 211 222 322 minecraft:black_concrete
setblock 213 220 323 minecraft:verdant_froglight
setblock 213 220 325 minecraft:verdant_froglight
setblock 213 220 327 minecraft:verdant_froglight
setblock 214 220 324 minecraft:verdant_froglight
setblock 214 220 326 minecraft:verdant_froglight
setblock 215 220 323 minecraft:verdant_froglight
setblock 215 220 325 minecraft:verdant_froglight
setblock 215 220 327 minecraft:verdant_froglight
setblock 216 220 324 minecraft:verdant_froglight
setblock 216 220 326 minecraft:verdant_froglight
setblock 217 220 323 minecraft:verdant_froglight
setblock 217 220 325 minecraft:verdant_froglight
setblock 217 220 327 minecraft:verdant_froglight
setblock 218 220 324 minecraft:verdant_froglight
setblock 218 220 326 minecraft:verdant_froglight
setblock 219 220 323 minecraft:verdant_froglight
setblock 219 220 325 minecraft:verdant_froglight
setblock 219 220 327 minecraft:verdant_froglight
setblock 220 220 324 minecraft:verdant_froglight
setblock 220 220 326 minecraft:verdant_froglight
setblock 221 220 323 minecraft:verdant_froglight
setblock 221 220 325 minecraft:verdant_froglight
setblock 221 220 327 minecraft:verdant_froglight
setblock 222 220 324 minecraft:verdant_froglight
setblock 222 220 326 minecraft:verdant_froglight
setblock 222 220 364 minecraft:pearlescent_froglight
setblock 223 220 323 minecraft:verdant_froglight
setblock 223 220 325 minecraft:verdant_froglight
setblock 223 220 327 minecraft:verdant_froglight
setblock 223 220 355 minecraft:verdant_froglight
setblock 223 220 357 minecraft:verdant_froglight
setblock 223 220 359 minecraft:verdant_froglight
setblock 223 220 361 minecraft:verdant_froglight
setblock 223 220 363 minecraft:verdant_froglight
setblock 224 220 356 minecraft:verdant_froglight
setblock 224 220 358 minecraft:verdant_froglight
setblock 224 220 360 minecraft:verdant_froglight
setblock 224 220 362 minecraft:verdant_froglight
setblock 225 220 355 minecraft:verdant_froglight
setblock 225 220 357 minecraft:verdant_froglight
setblock 225 220 359 minecraft:verdant_froglight
setblock 225 220 361 minecraft:verdant_froglight
setblock 225 220 363 minecraft:verdant_froglight
setblock 226 220 356 minecraft:verdant_froglight
setblock 226 220 358 minecraft:verdant_froglight
setblock 226 220 360 minecraft:verdant_froglight
setblock 226 220 362 minecraft:verdant_froglight
setblock 227 220 355 minecraft:verdant_froglight
setblock 227 220 357 minecraft:verdant_froglight
setblock 227 220 359 minecraft:verdant_froglight
setblock 227 220 361 minecraft:verdant_froglight
setblock 227 220 363 minecraft:verdant_froglight
setblock 228 220 356 minecraft:verdant_froglight
setblock 228 220 358 minecraft:verdant_froglight
setblock 228 220 360 minecraft:verdant_froglight
setblock 228 220 362 minecraft:verdant_froglight
setblock 229 220 355 minecraft:verdant_froglight
setblock 229 220 357 minecraft:verdant_froglight
setblock 229 220 359 minecraft:verdant_froglight
setblock 229 220 361 minecraft:verdant_froglight
setblock 229 220 363 minecraft:verdant_froglight
setblock 230 220 325 minecraft:ochre_froglight
setblock 230 220 335 minecraft:sea_lantern
fill 230 220 354 230 273 354 minecraft:black_concrete
fill 188 221 351 188 227 351 minecraft:black_concrete
setblock 188 221 356 minecraft:sea_lantern
setblock 188 221 363 minecraft:ochre_froglight
fill 188 221 364 188 308 364 minecraft:black_concrete
fill 189 221 322 189 227 322 minecraft:black_concrete
fill 189 221 353 189 222 353 minecraft:light_gray_concrete
fill 189 221 355 189 222 355 minecraft:light_gray_concrete
fill 189 221 357 189 222 357 minecraft:light_gray_concrete
fill 189 221 359 189 222 359 minecraft:light_gray_concrete
fill 189 221 361 189 222 361 minecraft:light_gray_concrete
fill 189 221 363 189 222 363 minecraft:light_gray_concrete
fill 190 221 354 190 222 354 minecraft:light_gray_concrete
fill 190 221 356 190 222 356 minecraft:light_gray_concrete
fill 190 221 358 190 222 358 minecraft:light_gray_concrete
fill 190 221 360 190 222 360 minecraft:light_gray_concrete
fill 190 221 362 190 222 362 minecraft:light_gray_concrete
setblock 191 221 322 minecraft:sea_lantern
setblock 191 221 325 minecraft:light[level=15]
setblock 191 221 332 minecraft:light[level=12]
setblock 191 221 333 minecraft:light[level=15]
setblock 191 221 339 minecraft:light[level=12]
setblock 191 221 341 minecraft:light[level=15]
setblock 191 221 346 minecraft:light[level=12]
setblock 191 221 349 minecraft:light[level=15]
fill 191 221 353 191 222 353 minecraft:light_gray_concrete
fill 191 221 355 191 222 355 minecraft:light_gray_concrete
fill 191 221 357 191 222 357 minecraft:light_gray_concrete
fill 191 221 359 191 222 359 minecraft:light_gray_concrete
fill 191 221 361 191 222 361 minecraft:light_gray_concrete
fill 191 221 363 191 222 363 minecraft:light_gray_concrete
fill 192 221 354 192 222 354 minecraft:light_gray_concrete
fill 192 221 356 192 222 356 minecraft:light_gray_concrete
fill 192 221 358 192 222 358 minecraft:light_gray_concrete
fill 192 221 360 192 222 360 minecraft:light_gray_concrete
fill 192 221 362 192 222 362 minecraft:light_gray_concrete
setblock 192 221 364 minecraft:pearlescent_froglight
fill 193 221 353 193 222 353 minecraft:light_gray_concrete
fill 193 221 355 193 222 355 minecraft:light_gray_concrete
fill 193 221 357 193 222 357 minecraft:light_gray_concrete
fill 193 221 359 193 222 359 minecraft:light_gray_concrete
fill 193 221 361 193 222 361 minecraft:light_gray_concrete
fill 193 221 363 193 222 363 minecraft:light_gray_concrete
fill 194 221 354 194 222 354 minecraft:light_gray_concrete
fill 194 221 356 194 222 356 minecraft:light_gray_concrete
fill 194 221 358 194 222 358 minecraft:light_gray_concrete
fill 194 221 360 194 222 360 minecraft:light_gray_concrete
fill 194 221 362 194 222 362 minecraft:light_gray_concrete
fill 195 221 322 195 223 322 minecraft:black_concrete
fill 195 221 353 195 222 353 minecraft:light_gray_concrete
fill 195 221 355 195 222 355 minecraft:light_gray_concrete
fill 195 221 357 195 222 357 minecraft:light_gray_concrete
fill 195 221 359 195 222 359 minecraft:light_gray_concrete
fill 195 221 361 195 222 361 minecraft:light_gray_concrete
fill 195 221 363 195 222 363 minecraft:light_gray_concrete
setblock 198 221 325 minecraft:light[level=12]
setblock 198 221 332 minecraft:light[level=12]
setblock 198 221 339 minecraft:light[level=12]
setblock 198 221 346 minecraft:light[level=12]
setblock 198 221 353 minecraft:light[level=12]
setblock 199 221 325 minecraft:light[level=15]
setblock 199 221 333 minecraft:light[level=15]
setblock 199 221 341 minecraft:light[level=15]
setblock 199 221 349 minecraft:light[level=15]
fill 203 221 364 203 263 364 minecraft:black_concrete
setblock 205 221 325 minecraft:light[level=12]
setblock 205 221 332 minecraft:light[level=12]
setblock 205 221 339 minecraft:light[level=12]
setblock 205 221 346 minecraft:light[level=12]
setblock 205 221 353 minecraft:light[level=12]
setblock 205 221 360 minecraft:light[level=12]
setblock 207 221 325 minecraft:light[level=15]
setblock 207 221 333 minecraft:light[level=15]
setblock 207 221 341 minecraft:light[level=15]
setblock 207 221 349 minecraft:light[level=15]
setblock 207 221 357 minecraft:light[level=15]
setblock 212 221 325 minecraft:light[level=12]
setblock 212 221 332 minecraft:light[level=12]
setblock 212 221 339 minecraft:light[level=12]
setblock 212 221 346 minecraft:light[level=12]
setblock 212 221 353 minecraft:light[level=12]
setblock 212 221 360 minecraft:light[level=12]
fill 213 221 323 213 222 323 minecraft:light_gray_concrete
fill 213 221 325 213 222 325 minecraft:light_gray_concrete
fill 213 221 327 213 222 327 minecraft:light_gray_concrete
fill 214 221 324 214 222 324 minecraft:light_gray_concrete
fill 214 221 326 214 222 326 minecraft:light_gray_concrete
fill 215 221 323 215 222 323 minecraft:light_gray_concrete
fill 215 221 325 215 222 325 minecraft:light_gray_concrete
fill 215 221 327 215 222 327 minecraft:light_gray_concrete
setblock 215 221 333 minecraft:light[level=15]
setblock 215 221 341 minecraft:light[level=15]
setblock 215 221 349 minecraft:light[level=15]
setblock 215 221 357 minecraft:light[level=15]
fill 216 221 324 216 222 324 minecraft:light_gray_concrete
fill 216 221 326 216 222 326 minecraft:light_gray_concrete
fill 217 221 323 217 222 323 minecraft:light_gray_concrete
fill 217 221 325 217 222 325 minecraft:light_gray_concrete
fill 217 221 327 217 222 327 minecraft:light_gray_concrete
fill 218 221 324 218 222 324 minecraft:light_gray_concrete
fill 218 221 326 218 222 326 minecraft:light_gray_concrete
fill 219 221 323 219 222 323 minecraft:light_gray_concrete
fill 219 221 325 219 222 325 minecraft:light_gray_concrete
fill 219 221 327 219 222 327 minecraft:light_gray_concrete
setblock 219 221 332 minecraft:light[level=12]
setblock 219 221 339 minecraft:light[level=12]
setblock 219 221 346 minecraft:light[level=12]
setblock 219 221 353 minecraft:light[level=12]
setblock 219 221 360 minecraft:light[level=12]
fill 220 221 324 220 222 324 minecraft:light_gray_concrete
fill 220 221 326 220 222 326 minecraft:light_gray_concrete
setblock 220 221 364 minecraft:ochre_froglight
fill 221 221 323 221 222 323 minecraft:light_gray_concrete
fill 221 221 325 221 222 325 minecraft:light_gray_concrete
fill 221 221 327 221 222 327 minecraft:light_gray_concrete
fill 222 221 324 222 222 324 minecraft:light_gray_concrete
fill 222 221 326 222 222 326 minecraft:light_gray_concrete
fill 222 221 364 222 268 364 minecraft:black_concrete
fill 223 221 323 223 222 323 minecraft:light_gray_concrete
fill 223 221 325 223 222 325 minecraft:light_gray_concrete
fill 223 221 327 223 222 327 minecraft:light_gray_concrete
setblock 223 221 333 minecraft:light[level=15]
setblock 223 221 341 minecraft:light[level=15]
setblock 223 221 349 minecraft:light[level=15]
fill 223 221 355 223 222 355 minecraft:light_gray_concrete
fill 223 221 357 223 222 357 minecraft:light_gray_concrete
fill 223 221 359 223 222 359 minecraft:light_gray_concrete
fill 223 221 361 223 222 361 minecraft:light_gray_concrete
fill 223 221 363 223 222 363 minecraft:light_gray_concrete
fill 224 221 356 224 222 356 minecraft:light_gray_concrete
fill 224 221 358 224 222 358 minecraft:light_gray_concrete
fill 224 221 360 224 222 360 minecraft:light_gray_concrete
fill 224 221 362 224 222 362 minecraft:light_gray_concrete
fill 225 221 355 225 222 355 minecraft:light_gray_concrete
fill 225 221 357 225 222 357 minecraft:light_gray_concrete
fill 225 221 359 225 222 359 minecraft:light_gray_concrete
fill 225 221 361 225 222 361 minecraft:light_gray_concrete
fill 225 221 363 225 222 363 minecraft:light_gray_concrete
setblock 226 221 325 minecraft:light[level=12]
setblock 226 221 332 minecraft:light[level=12]
setblock 226 221 339 minecraft:light[level=12]
setblock 226 221 346 minecraft:light[level=12]
setblock 226 221 353 minecraft:light[level=12]
fill 226 221 356 226 222 356 minecraft:light_gray_concrete
fill 226 221 358 226 222 358 minecraft:light_gray_concrete
fill 226 221 360 226 222 360 minecraft:light_gray_concrete
fill 226 221 362 226 222 362 minecraft:light_gray_concrete
fill 227 221 355 227 222 355 minecraft:light_gray_concrete
fill 227 221 357 227 222 357 minecraft:light_gray_concrete
fill 227 221 359 227 222 359 minecraft:light_gray_concrete
fill 227 221 361 227 222 361 minecraft:light_gray_concrete
fill 227 221 363 227 222 363 minecraft:light_gray_concrete
fill 228 221 356 228 222 356 minecraft:light_gray_concrete
fill 228 221 358 228 222 358 minecraft:light_gray_concrete
fill 228 221 360 228 222 360 minecraft:light_gray_concrete
fill 228 221 362 228 222 362 minecraft:light_gray_concrete
fill 229 221 355 229 222 355 minecraft:light_gray_concrete
fill 229 221 357 229 222 357 minecraft:light_gray_concrete
fill 229 221 359 229 222 359 minecraft:light_gray_concrete
fill 229 221 361 229 222 361 minecraft:light_gray_concrete
fill 229 221 363 229 222 363 minecraft:light_gray_concrete
fill 230 221 325 230 226 325 minecraft:black_concrete
setblock 230 221 329 minecraft:pearlescent_froglight
setblock 230 221 331 minecraft:ochre_froglight
fill 230 221 335 230 224 335 minecraft:black_concrete
fill 188 222 356 188 308 356 minecraft:black_concrete
fill 188 222 363 188 240 363 minecraft:black_concrete
fill 191 222 322 191 233 322 minecraft:black_concrete
fill 192 222 364 192 238 364 minecraft:black_concrete
setblock 210 222 322 minecraft:ochre_froglight
setblock 210 222 364 minecraft:sea_lantern
fill 220 222 364 220 226 364 minecraft:black_concrete
fill 230 222 329 230 253 329 minecraft:black_concrete
fill 230 222 331 230 308 331 minecraft:black_concrete
setblock 188 223 327 minecraft:ochre_froglight
setblock 188 223 329 minecraft:pearlescent_froglight
setblock 188 223 333 minecraft:white_concrete
setblock 189 223 353 minecraft:verdant_froglight
setblock 189 223 355 minecraft:verdant_froglight
setblock 189 223 357 minecraft:verdant_froglight
setblock 189 223 359 minecraft:verdant_froglight
setblock 189 223 361 minecraft:verdant_froglight
setblock 189 223 363 minecraft:verdant_froglight
setblock 190 223 354 minecraft:verdant_froglight
setblock 190 223 356 minecraft:verdant_froglight
setblock 190 223 358 minecraft:verdant_froglight
setblock 190 223 360 minecraft:verdant_froglight
setblock 190 223 362 minecraft:verdant_froglight
setblock 191 223 353 minecraft:verdant_froglight
setblock 191 223 355 minecraft:verdant_froglight
setblock 191 223 357 minecraft:verdant_froglight
setblock 191 223 359 minecraft:verdant_froglight
setblock 191 223 361 minecraft:verdant_froglight
setblock 191 223 363 minecraft:verdant_froglight
setblock 192 223 354 minecraft:verdant_froglight
setblock 192 223 356 minecraft:verdant_froglight
setblock 192 223 358 minecraft:verdant_froglight
setblock 192 223 360 minecraft:verdant_froglight
setblock 192 223 362 minecraft:verdant_froglight
setblock 193 223 353 minecraft:verdant_froglight
setblock 193 223 355 minecraft:verdant_froglight
setblock 193 223 357 minecraft:verdant_froglight
setblock 193 223 359 minecraft:verdant_froglight
setblock 193 223 361 minecraft:verdant_froglight
setblock 193 223 363 minecraft:verdant_froglight
setblock 194 223 354 minecraft:verdant_froglight
setblock 194 223 356 minecraft:verdant_froglight
setblock 194 223 358 minecraft:verdant_froglight
setblock 194 223 360 minecraft:verdant_froglight
setblock 194 223 362 minecraft:verdant_froglight
setblock 195 223 353 minecraft:verdant_froglight
setblock 195 223 355 minecraft:verdant_froglight
setblock 195 223 357 minecraft:verdant_froglight
setblock 195 223 359 minecraft:verdant_froglight
setblock 195 223 361 minecraft:verdant_froglight
setblock 195 223 363 minecraft:verdant_froglight
setblock 202 223 364 minecraft:sea_lantern
fill 210 223 322 210 279 322 minecraft:black_concrete
fill 210 223 364 210 248 364 minecraft:black_concrete
setblock 211 223 322 minecraft:sea_lantern
setblock 213 223 323 minecraft:verdant_froglight
setblock 213 223 325 minecraft:verdant_froglight
setblock 213 223 327 minecraft:verdant_froglight
setblock 214 223 324 minecraft:verdant_froglight
setblock 214 223 326 minecraft:verdant_froglight
setblock 215 223 323 minecraft:verdant_froglight
setblock 215 223 325 minecraft:verdant_froglight
setblock 215 223 327 minecraft:verdant_froglight
setblock 216 223 324 minecraft:verdant_froglight
setblock 216 223 326 minecraft:verdant_froglight
setblock 217 223 323 minecraft:verdant_froglight
setblock 217 223 325 minecraft:verdant_froglight
setblock 217 223 327 minecraft:verdant_froglight
setblock 218 223 324 minecraft:verdant_froglight
setblock 218 223 326 minecraft:verdant_froglight
setblock 219 223 323 minecraft:verdant_froglight
setblock 219 223 325 minecraft:verdant_froglight
setblock 219 223 327 minecraft:verdant_froglight
setblock 220 223 324 minecraft:verdant_froglight
setblock 220 223 326 minecraft:verdant_froglight
setblock 221 223 323 minecraft:verdant_froglight
setblock 221 223 325 minecraft:verdant_froglight
setblock 221 223 327 minecraft:verdant_froglight
setblock 222 223 324 minecraft:verdant_froglight
setblock 222 223 326 minecraft:verdant_froglight
setblock 223 223 323 minecraft:verdant_froglight
setblock 223 223 325 minecraft:verdant_froglight
setblock 223 223 327 minecraft:verdant_froglight
setblock 223 223 355 minecraft:verdant_froglight
setblock 223 223 357 minecraft:verdant_froglight
setblock 223 223 359 minecraft:verdant_froglight
setblock 223 223 361 minecraft:verdant_froglight
setblock 223 223 363 minecraft:verdant_froglight
setblock 224 223 356 minecraft:verdant_froglight
setblock 224 223 358 minecraft:verdant_froglight
setblock 224 223 360 minecraft:verdant_froglight
setblock 224 223 362 minecraft:verdant_froglight
setblock 225 223 355 minecraft:verdant_froglight
setblock 225 223 357 minecraft:verdant_froglight
setblock 225 223 359 minecraft:verdant_froglight
setblock 225 223 361 minecraft:verdant_froglight
setblock 225 223 363 minecraft:verdant_froglight
setblock 226 223 356 minecraft:verdant_froglight
setblock 226 223 358 minecraft:verdant_froglight
setblock 226 223 360 minecraft:verdant_froglight
setblock 226 223 362 minecraft:verdant_froglight
setblock 227 223 355 minecraft:verdant_froglight
setblock 227 223 357 minecraft:verdant_froglight
setblock 227 223 359 minecraft:verdant_froglight
setblock 227 223 361 minecraft:verdant_froglight
setblock 227 223 363 minecraft:verdant_froglight
setblock 228 223 356 minecraft:verdant_froglight
setblock 228 223 358 minecraft:verdant_froglight
setblock 228 223 360 minecraft:verdant_froglight
setblock 228 223 362 minecraft:verdant_froglight
setblock 229 223 355 minecraft:verdant_froglight
setblock 229 223 357 minecraft:verdant_froglight
setblock 229 223 359 minecraft:verdant_froglight
setblock 229 223 361 minecraft:verdant_froglight
setblock 229 223 363 minecraft:verdant_froglight
setblock 230 223 349 minecraft:sea_lantern
fill 188 224 327 188 270 327 minecraft:black_concrete
fill 188 224 329 188 259 329 minecraft:black_concrete
fill 188 224 333 188 239 333 minecraft:black_concrete
fill 189 224 353 189 225 353 minecraft:light_gray_concrete
fill 189 224 355 189 225 355 minecraft:light_gray_concrete
fill 189 224 357 189 225 357 minecraft:light_gray_concrete
fill 189 224 359 189 225 359 minecraft:light_gray_concrete
fill 189 224 361 189 225 361 minecraft:light_gray_concrete
fill 189 224 363 189 225 363 minecraft:light_gray_concrete
fill 190 224 354 190 225 354 minecraft:light_gray_concrete
fill 190 224 356 190 225 356 minecraft:light_gray_concrete
fill 190 224 358 190 225 358 minecraft:light_gray_concrete
fill 190 224 360 190 225 360 minecraft:light_gray_concrete
fill 190 224 362 190 225 362 minecraft:light_gray_concrete
fill 191 224 353 191 225 353 minecraft:light_gray_concrete
fill 191 224 355 191 225 355 minecraft:light_gray_concrete
fill 191 224 357 191 225 357 minecraft:light_gray_concrete
fill 191 224 359 191 225 359 minecraft:light_gray_concrete
fill 191 224 361 191 225 361 minecraft:light_gray_concrete
fill 191 224 363 191 225 363 minecraft:light_gray_concrete
fill 192 224 354 192 225 354 minecraft:light_gray_concrete
fill 192 224 356 192 225 356 minecraft:light_gray_concrete
fill 192 224 358 192 225 358 minecraft:light_gray_concrete
fill 192 224 360 192 225 360 minecraft:light_gray_concrete
fill 192 224 362 192 225 362 minecraft:light_gray_concrete
fill 193 224 353 193 225 353 minecraft:light_gray_concrete
fill 193 224 355 193 225 355 minecraft:light_gray_concrete
fill 193 224 357 193 225 357 minecraft:light_gray_concrete
fill 193 224 359 193 225 359 minecraft:light_gray_concrete
fill 193 224 361 193 225 361 minecraft:light_gray_concrete
fill 193 224 363 193 225 363 minecraft:light_gray_concrete
fill 194 224 354 194 225 354 minecraft:light_gray_concrete
fill 194 224 356 194 225 356 minecraft:light_gray_concrete
fill 194 224 358 194 225 358 minecraft:light_gray_concrete
fill 194 224 360 194 225 360 minecraft:light_gray_concrete
fill 194 224 362 194 225 362 minecraft:light_gray_concrete
setblock 195 224 322 minecraft:sea_lantern
fill 195 224 353 195 225 353 minecraft:light_gray_concrete
fill 195 224 355 195 225 355 minecraft:light_gray_concrete
fill 195 224 357 195 225 357 minecraft:light_gray_concrete
fill 195 224 359 195 225 359 minecraft:light_gray_concrete
fill 195 224 361 195 225 361 minecraft:light_gray_concrete
fill 195 224 363 195 225 363 minecraft:light_gray_concrete
fill 196 224 340 197 231 340 minecraft:lime_stained_glass
fill 197 224 339 197 231 339 minecraft:lime_stained_glass
setblock 201 224 364 minecraft:white_concrete
setblock 202 224 364 minecraft:black_concrete
setblock 203 224 322 minecraft:sea_lantern
fill 211 224 322 211 290 322 minecraft:black_concrete
fill 213 224 323 213 225 323 minecraft:light_gray_concrete
fill 213 224 325 213 225 325 minecraft:light_gray_concrete
fill 213 224 327 213 225 327 minecraft:light_gray_concrete
fill 214 224 324 214 225 324 minecraft:light_gray_concrete
fill 214 224 326 214 225 326 minecraft:light_gray_concrete
fill 215 224 323 215 225 323 minecraft:light_gray_concrete
fill 215 224 325 215 225 325 minecraft:light_gray_concrete
fill 215 224 327 215 225 327 minecraft:light_gray_concrete
fill 216 224 324 216 225 324 minecraft:light_gray_concrete
fill 216 224 326 216 225 326 minecraft:light_gray_concrete
fill 217 224 323 217 225 323 minecraft:light_gray_concrete
fill 217 224 325 217 225 325 minecraft:light_gray_concrete
fill 217 224 327 217 225 327 minecraft:light_gray_concrete
fill 218 224 324 218 225 324 minecraft:light_gray_concrete
fill 218 224 326 218 225 326 minecraft:light_gray_concrete
fill 219 224 323 219 225 323 minecraft:light_gray_concrete
fill 219 224 325 219 225 325 minecraft:light_gray_concrete
fill 219 224 327 219 225 327 minecraft:light_gray_concrete
fill 220 224 324 220 225 324 minecraft:light_gray_concrete
fill 220 224 326 220 225 326 minecraft:light_gray_concrete
fill 221 224 323 221 225 323 minecraft:light_gray_concrete
fill 221 224 325 221 225 325 minecraft:light_gray_concrete
fill 221 224 327 221 225 327 minecraft:light_gray_concrete
fill 222 224 324 222 225 324 minecraft:light_gray_concrete
fill 222 224 326 222 225 326 minecraft:light_gray_concrete
fill 223 224 323 223 225 323 minecraft:light_gray_concrete
fill 223 224 325 223 225 325 minecraft:light_gray_concrete
fill 223 224 327 223 225 327 minecraft:light_gray_concrete
fill 223 224 355 223 225 355 minecraft:light_gray_concrete
fill 223 224 357 223 225 357 minecraft:light_gray_concrete
fill 223 224 359 223 225 359 minecraft:light_gray_concrete
fill 223 224 361 223 225 361 minecraft:light_gray_concrete
fill 223 224 363 223 225 363 minecraft:light_gray_concrete
fill 224 224 356 224 225 356 minecraft:light_gray_concrete
fill 224 224 358 224 225 358 minecraft:light_gray_concrete
fill 224 224 360 224 225 360 minecraft:light_gray_concrete
fill 224 224 362 224 225 362 minecraft:light_gray_concrete
fill 225 224 355 225 225 355 minecraft:light_gray_concrete
fill 225 224 357 225 225 357 minecraft:light_gray_concrete
fill 225 224 359 225 225 359 minecraft:light_gray_concrete
fill 225 224 361 225 225 361 minecraft:light_gray_concrete
fill 225 224 363 225 225 363 minecraft:light_gray_concrete
setblock 225 224 364 minecraft:white_concrete
setblock 226 224 322 minecraft:white_concrete
fill 226 224 356 226 225 356 minecraft:light_gray_concrete
fill 226 224 358 226 225 358 minecraft:light_gray_concrete
fill 226 224 360 226 225 360 minecraft:light_gray_concrete
fill 226 224 362 226 225 362 minecraft:light_gray_concrete
fill 227 224 355 227 225 355 minecraft:light_gray_concrete
fill 227 224 357 227 225 357 minecraft:light_gray_concrete
fill 227 224 359 227 225 359 minecraft:light_gray_concrete
fill 227 224 361 227 225 361 minecraft:light_gray_concrete
fill 227 224 363 227 225 363 minecraft:light_gray_concrete
fill 228 224 356 228 225 356 minecraft:light_gray_concrete
fill 228 224 358 228 225 358 minecraft:light_gray_concrete
fill 228 224 360 228 225 360 minecraft:light_gray_concrete
fill 228 224 362 228 225 362 minecraft:light_gray_concrete
fill 229 224 355 229 225 355 minecraft:light_gray_concrete
fill 229 224 357 229 225 357 minecraft:light_gray_concrete
fill 229 224 359 229 225 359 minecraft:light_gray_concrete
fill 229 224 361 229 225 361 minecraft:light_gray_concrete
fill 229 224 363 229 225 363 minecraft:light_gray_concrete
setblock 230 224 326 minecraft:ochre_froglight
setblock 230 224 334 minecraft:pearlescent_froglight
fill 230 224 349 230 238 349 minecraft:black_concrete
setblock 188 225 353 minecraft:white_concrete
fill 195 225 322 195 250 322 minecraft:black_concrete
fill 196 225 339 196 230 339 minecraft:lime_stained_glass
fill 196 225 341 197 230 341 minecraft:lime_stained_glass
fill 201 225 364 201 267 364 minecraft:black_concrete
setblock 202 225 364 minecraft:pearlescent_froglight
fill 203 225 322 203 306 322 minecraft:black_concrete
setblock 208 225 322 minecraft:pearlescent_froglight
fill 225 225 364 225 261 364 minecraft:black_concrete
fill 226 225 322 226 290 322 minecraft:black_concrete
setblock 230 225 324 minecraft:white_concrete
fill 230 225 326 230 236 326 minecraft:black_concrete
fill 230 225 334 230 257 334 minecraft:black_concrete
setblock 230 225 335 minecraft:white_concrete
setblock 230 225 360 minecraft:sea_lantern
setblock 188 226 341 minecraft:white_concrete
fill 188 226 353 188 269 353 minecraft:black_concrete
setblock 189 226 353 minecraft:verdant_froglight
setblock 189 226 355 minecraft:verdant_froglight
setblock 189 226 357 minecraft:verdant_froglight
setblock 189 226 359 minecraft:verdant_froglight
setblock 189 226 361 minecraft:verdant_froglight
setblock 189 226 363 minecraft:verdant_froglight
setblock 190 226 354 minecraft:verdant_froglight
setblock 190 226 356 minecraft:verdant_froglight
setblock 190 226 358 minecraft:verdant_froglight
setblock 190 226 360 minecraft:verdant_froglight
setblock 190 226 362 minecraft:verdant_froglight
setblock 191 226 353 minecraft:verdant_froglight
setblock 191 226 355 minecraft:verdant_froglight
setblock 191 226 357 minecraft:verdant_froglight
setblock 191 226 359 minecraft:verdant_froglight
setblock 191 226 361 minecraft:verdant_froglight
setblock 191 226 363 minecraft:verdant_froglight
setblock 192 226 354 minecraft:verdant_froglight
setblock 192 226 356 minecraft:verdant_froglight
setblock 192 226 358 minecraft:verdant_froglight
setblock 192 226 360 minecraft:verdant_froglight
setblock 192 226 362 minecraft:verdant_froglight
setblock 193 226 353 minecraft:verdant_froglight
setblock 193 226 355 minecraft:verdant_froglight
setblock 193 226 357 minecraft:verdant_froglight
setblock 193 226 359 minecraft:verdant_froglight
setblock 193 226 361 minecraft:verdant_froglight
setblock 193 226 363 minecraft:verdant_froglight
setblock 194 226 354 minecraft:verdant_froglight
setblock 194 226 356 minecraft:verdant_froglight
setblock 194 226 358 minecraft:verdant_froglight
setblock 194 226 360 minecraft:verdant_froglight
setblock 194 226 362 minecraft:verdant_froglight
setblock 195 226 353 minecraft:verdant_froglight
setblock 195 226 355 minecraft:verdant_froglight
setblock 195 226 357 minecraft:verdant_froglight
setblock 195 226 359 minecraft:verdant_froglight
setblock 195 226 361 minecraft:verdant_froglight
setblock 195 226 363 minecraft:verdant_froglight
setblock 202 226 364 minecraft:white_concrete
fill 208 226 322 208 246 322 minecraft:black_concrete
setblock 213 226 323 minecraft:verdant_froglight
setblock 213 226 325 minecraft:verdant_froglight
setblock 213 226 327 minecraft:verdant_froglight
setblock 214 226 324 minecraft:verdant_froglight
setblock 214 226 326 minecraft:verdant_froglight
setblock 215 226 323 minecraft:verdant_froglight
setblock 215 226 325 minecraft:verdant_froglight
setblock 215 226 327 minecraft:verdant_froglight
setblock 216 226 324 minecraft:verdant_froglight
setblock 216 226 326 minecraft:verdant_froglight
setblock 216 226 364 minecraft:white_concrete
setblock 217 226 323 minecraft:verdant_froglight
setblock 217 226 325 minecraft:verdant_froglight
setblock 217 226 327 minecraft:verdant_froglight
setblock 218 226 324 minecraft:verdant_froglight
setblock 218 226 326 minecraft:verdant_froglight
setblock 219 226 323 minecraft:verdant_froglight
setblock 219 226 325 minecraft:verdant_froglight
setblock 219 226 327 minecraft:verdant_froglight
setblock 220 226 324 minecraft:verdant_froglight
setblock 220 226 326 minecraft:verdant_froglight
setblock 221 226 323 minecraft:verdant_froglight
setblock 221 226 325 minecraft:verdant_froglight
setblock 221 226 327 minecraft:verdant_froglight
setblock 222 226 324 minecraft:verdant_froglight
setblock 222 226 326 minecraft:verdant_froglight
setblock 223 226 323 minecraft:verdant_froglight
setblock 223 226 325 minecraft:verdant_froglight
setblock 223 226 327 minecraft:verdant_froglight
setblock 223 226 355 minecraft:verdant_froglight
setblock 223 226 357 minecraft:verdant_froglight
setblock 223 226 359 minecraft:verdant_froglight
setblock 223 226 361 minecraft:verdant_froglight
setblock 223 226 363 minecraft:verdant_froglight
setblock 224 226 356 minecraft:verdant_froglight
setblock 224 226 358 minecraft:verdant_froglight
setblock 224 226 360 minecraft:verdant_froglight
setblock 224 226 362 minecraft:verdant_froglight
setblock 225 226 355 minecraft:verdant_froglight
setblock 225 226 357 minecraft:verdant_froglight
setblock 225 226 359 minecraft:verdant_froglight
setblock 225 226 361 minecraft:verdant_froglight
setblock 225 226 363 minecraft:verdant_froglight
setblock 226 226 356 minecraft:verdant_froglight
setblock 226 226 358 minecraft:verdant_froglight
setblock 226 226 360 minecraft:verdant_froglight
setblock 226 226 362 minecraft:verdant_froglight
fill 227 226 340 228 227 341 minecraft:end_stone
setblock 227 226 355 minecraft:verdant_froglight
setblock 227 226 357 minecraft:verdant_froglight
setblock 227 226 359 minecraft:verdant_froglight
setblock 227 226 361 minecraft:verdant_froglight
setblock 227 226 363 minecraft:verdant_froglight
setblock 227 226 364 minecraft:pearlescent_froglight
fill 228 226 342 228 227 342 minecraft:end_stone
setblock 228 226 356 minecraft:verdant_froglight
setblock 228 226 358 minecraft:verdant_froglight
setblock 228 226 360 minecraft:verdant_froglight
setblock 228 226 362 minecraft:verdant_froglight
setblock 229 226 355 minecraft:verdant_froglight
setblock 229 226 357 minecraft:verdant_froglight
setblock 229 226 359 minecraft:verdant_froglight
setblock 229 226 361 minecraft:verdant_froglight
setblock 229 226 363 minecraft:verdant_froglight
fill 230 226 324 230 261 324 minecraft:black_concrete
fill 230 226 335 230 257 335 minecraft:black_concrete
setblock 230 226 359 minecraft:sea_lantern
fill 230 226 360 230 263 360 minecraft:black_concrete
fill 188 227 341 188 232 341 minecraft:black_concrete
fill 189 227 353 189 228 353 minecraft:light_gray_concrete
fill 189 227 355 189 228 355 minecraft:light_gray_concrete
fill 189 227 357 189 228 357 minecraft:light_gray_concrete
fill 189 227 359 189 228 359 minecraft:light_gray_concrete
fill 189 227 361 189 228 361 minecraft:light_gray_concrete
fill 189 227 363 189 228 363 minecraft:light_gray_concrete
fill 190 227 354 190 228 354 minecraft:light_gray_concrete
fill 190 227 356 190 228 356 minecraft:light_gray_concrete
fill 190 227 358 190 228 358 minecraft:light_gray_concrete
fill 190 227 360 190 228 360 minecraft:light_gray_concrete
fill 190 227 362 190 228 362 minecraft:light_gray_concrete
setblock 191 227 325 minecraft:light[level=12]
setblock 191 227 332 minecraft:light[level=12]
setblock 191 227 339 minecraft:light[level=12]
setblock 191 227 346 minecraft:light[level=12]
fill 191 227 353 191 228 353 minecraft:light_gray_concrete
fill 191 227 355 191 228 355 minecraft:light_gray_concrete
fill 191 227 357 191 228 357 minecraft:light_gray_concrete
fill 191 227 359 191 228 359 minecraft:light_gray_concrete
fill 191 227 361 191 228 361 minecraft:light_gray_concrete
fill 191 227 363 191 228 363 minecraft:light_gray_concrete
fill 192 227 354 192 228 354 minecraft:light_gray_concrete
fill 192 227 356 192 228 356 minecraft:light_gray_concrete
fill 192 227 358 192 228 358 minecraft:light_gray_concrete
fill 192 227 360 192 228 360 minecraft:light_gray_concrete
fill 192 227 362 192 228 362 minecraft:light_gray_concrete
fill 193 227 353 193 228 353 minecraft:light_gray_concrete
fill 193 227 355 193 228 355 minecraft:light_gray_concrete
fill 193 227 357 193 228 357 minecraft:light_gray_concrete
fill 193 227 359 193 228 359 minecraft:light_gray_concrete
fill 193 227 361 193 228 361 minecraft:light_gray_concrete
fill 193 227 363 193 228 363 minecraft:light_gray_concrete
fill 194 227 354 194 228 354 minecraft:light_gray_concrete
fill 194 227 356 194 228 356 minecraft:light_gray_concrete
fill 194 227 358 194 228 358 minecraft:light_gray_concrete
fill 194 227 360 194 228 360 minecraft:light_gray_concrete
fill 194 227 362 194 228 362 minecraft:light_gray_concrete
fill 195 227 353 195 228 353 minecraft:light_gray_concrete
fill 195 227 355 195 228 355 minecraft:light_gray_concrete
fill 195 227 357 195 228 357 minecraft:light_gray_concrete
fill 195 227 359 195 228 359 minecraft:light_gray_concrete
fill 195 227 361 195 228 361 minecraft:light_gray_concrete
fill 195 227 363 195 228 363 minecraft:light_gray_concrete
setblock 198 227 325 minecraft:light[level=12]
setblock 198 227 332 minecraft:light[level=12]
setblock 198 227 339 minecraft:light[level=12]
setblock 198 227 346 minecraft:light[level=12]
setblock 198 227 353 minecraft:light[level=12]
setblock 202 227 364 minecraft:black_concrete
setblock 205 227 325 minecraft:light[level=12]
setblock 205 227 332 minecraft:light[level=12]
setblock 205 227 339 minecraft:light[level=12]
setblock 205 227 346 minecraft:light[level=12]
setblock 205 227 353 minecraft:light[level=12]
setblock 205 227 360 minecraft:light[level=12]
fill 209 227 331 210 228 332 minecraft:gray_concrete
setblock 212 227 325 minecraft:light[level=12]
setblock 212 227 332 minecraft:light[level=12]
setblock 212 227 339 minecraft:light[level=12]
setblock 212 227 346 minecraft:light[level=12]
setblock 212 227 353 minecraft:light[level=12]
setblock 212 227 360 minecraft:light[level=12]
fill 213 227 323 213 228 323 minecraft:light_gray_concrete
fill 213 227 325 213 228 325 minecraft:light_gray_concrete
fill 213 227 327 213 228 327 minecraft:light_gray_concrete
setblock 214 227 322 minecraft:ochre_froglight
fill 214 227 324 214 228 324 minecraft:light_gray_concrete
fill 214 227 326 214 228 326 minecraft:light_gray_concrete
fill 215 227 323 215 228 323 minecraft:light_gray_concrete
fill 215 227 325 215 228 325 minecraft:light_gray_concrete
fill 215 227 327 215 228 327 minecraft:light_gray_concrete
fill 216 227 324 216 228 324 minecraft:light_gray_concrete
fill 216 227 326 216 228 326 minecraft:light_gray_concrete
fill 216 227 364 216 288 364 minecraft:black_concrete
fill 217 227 323 217 228 323 minecraft:light_gray_concrete
fill 217 227 325 217 228 325 minecraft:light_gray_concrete
fill 217 227 327 217 228 327 minecraft:light_gray_concrete
fill 218 227 324 218 228 324 minecraft:light_gray_concrete
fill 218 227 326 218 228 326 minecraft:light_gray_concrete
fill 219 227 323 219 228 323 minecraft:light_gray_concrete
fill 219 227 325 219 228 325 minecraft:light_gray_concrete
fill 219 227 327 219 228 327 minecraft:light_gray_concrete
setblock 219 227 332 minecraft:light[level=12]
setblock 219 227 339 minecraft:light[level=12]
setblock 219 227 346 minecraft:light[level=12]
setblock 219 227 353 minecraft:light[level=12]
setblock 219 227 360 minecraft:light[level=12]
fill 220 227 324 220 228 324 minecraft:light_gray_concrete
fill 220 227 326 220 228 326 minecraft:light_gray_concrete
setblock 220 227 364 minecraft:ochre_froglight
fill 221 227 323 221 228 323 minecraft:light_gray_concrete
fill 221 227 325 221 228 325 minecraft:light_gray_concrete
fill 221 227 327 221 228 327 minecraft:light_gray_concrete
fill 222 227 324 222 228 324 minecraft:light_gray_concrete
fill 222 227 326 222 228 326 minecraft:light_gray_concrete
fill 223 227 323 223 228 323 minecraft:light_gray_concrete
fill 223 227 325 223 228 325 minecraft:light_gray_concrete
fill 223 227 327 223 228 327 minecraft:light_gray_concrete
fill 223 227 355 223 228 355 minecraft:light_gray_concrete
fill 223 227 357 223 228 357 minecraft:light_gray_concrete
fill 223 227 359 223 228 359 minecraft:light_gray_concrete
fill 223 227 361 223 228 361 minecraft:light_gray_concrete
fill 223 227 363 223 228 363 minecraft:light_gray_concrete
fill 224 227 356 224 228 356 minecraft:light_gray_concrete
fill 224 227 358 224 228 358 minecraft:light_gray_concrete
fill 224 227 360 224 228 360 minecraft:light_gray_concrete
fill 224 227 362 224 228 362 minecraft:light_gray_concrete
fill 225 227 355 225 228 355 minecraft:light_gray_concrete
fill 225 227 357 225 228 357 minecraft:light_gray_concrete
fill 225 227 359 225 228 359 minecraft:light_gray_concrete
fill 225 227 361 225 228 361 minecraft:light_gray_concrete
fill 225 227 363 225 228 363 minecraft:light_gray_concrete
setblock 226 227 325 minecraft:light[level=12]
setblock 226 227 332 minecraft:light[level=12]
setblock 226 227 339 minecraft:light[level=12]
setblock 226 227 346 minecraft:light[level=12]
setblock 226 227 353 minecraft:light[level=12]
fill 226 227 356 226 228 356 minecraft:light_gray_concrete
fill 226 227 358 226 228 358 minecraft:light_gray_concrete
fill 226 227 360 226 228 360 minecraft:light_gray_concrete
fill 226 227 362 226 228 362 minecraft:light_gray_concrete
fill 227 227 355 227 228 355 minecraft:light_gray_concrete
fill 227 227 357 227 228 357 minecraft:light_gray_concrete
fill 227 227 359 227 228 359 minecraft:light_gray_concrete
fill 227 227 361 227 228 361 minecraft:light_gray_concrete
fill 227 227 363 227 228 363 minecraft:light_gray_concrete
fill 227 227 364 227 240 364 minecraft:black_concrete
fill 228 227 356 228 228 356 minecraft:light_gray_concrete
fill 228 227 358 228 228 358 minecraft:light_gray_concrete
fill 228 227 360 228 228 360 minecraft:light_gray_concrete
fill 228 227 362 228 228 362 minecraft:light_gray_concrete
fill 229 227 355 229 228 355 minecraft:light_gray_concrete
fill 229 227 357 229 228 357 minecraft:light_gray_concrete
fill 229 227 359 229 228 359 minecraft:light_gray_concrete
fill 229 227 361 229 228 361 minecraft:light_gray_concrete
fill 229 227 363 229 228 363 minecraft:light_gray_concrete
setblock 230 227 323 minecraft:white_concrete
setblock 230 227 325 minecraft:ochre_froglight
fill 230 227 359 230 308 359 minecraft:black_concrete
setblock 230 227 362 minecraft:pearlescent_froglight
setblock 188 228 349 minecraft:white_concrete
setblock 188 228 351 minecraft:ochre_froglight
setblock 189 228 322 minecraft:ochre_froglight
setblock 202 228 364 minecraft:ochre_froglight
fill 214 228 322 214 234 322 minecraft:black_concrete
fill 220 228 364 220 268 364 minecraft:black_concrete
fill 230 228 323 230 231 323 minecraft:black_concrete
fill 230 228 325 230 271 325 minecraft:black_concrete
fill 230 228 362 230 280 362 minecraft:black_concrete
fill 188 229 349 188 243 349 minecraft:black_concrete
setblock 188 229 350 minecraft:sea_lantern
fill 188 229 351 188 236 351 minecraft:black_concrete
setblock 188 229 358 minecraft:sea_lantern
fill 189 229 322 189 251 322 minecraft:black_concrete
setblock 191 229 325 minecraft:light[level=15]
setblock 191 229 333 minecraft:light[level=15]
setblock 191 229 341 minecraft:light[level=15]
setblock 191 229 349 minecraft:light[level=15]
setblock 191 229 357 minecraft:light[level=15]
setblock 199 229 325 minecraft:light[level=15]
setblock 199 229 333 minecraft:light[level=15]
setblock 199 229 341 minecraft:light[level=15]
setblock 199 229 349 minecraft:light[level=15]
setblock 199 229 357 minecraft:light[level=15]
fill 202 229 364 202 252 364 minecraft:black_concrete
setblock 207 229 325 minecraft:light[level=15]
setblock 207 229 333 minecraft:light[level=15]
setblock 207 229 341 minecraft:light[level=15]
setblock 207 229 349 minecraft:light[level=15]
setblock 207 229 357 minecraft:light[level=15]
setblock 215 229 325 minecraft:light[level=15]
setblock 215 229 333 minecraft:light[level=15]
setblock 215 229 341 minecraft:light[level=15]
setblock 215 229 349 minecraft:light[level=15]
setblock 215 229 357 minecraft:light[level=15]
setblock 223 229 325 minecraft:light[level=15]
setblock 223 229 333 minecraft:light[level=15]
setblock 223 229 341 minecraft:light[level=15]
setblock 223 229 349 minecraft:light[level=15]
setblock 223 229 357 minecraft:light[level=15]
setblock 230 229 332 minecraft:white_concrete
fill 188 230 350 188 263 350 minecraft:black_concrete
fill 188 230 358 188 308 358 minecraft:black_concrete
setblock 229 230 322 minecraft:sea_lantern
fill 230 230 332 230 231 332 minecraft:black_concrete
setblock 188 231 360 minecraft:sea_lantern
setblock 201 231 322 minecraft:sea_lantern
setblock 221 231 322 minecraft:sea_lantern
setblock 225 231 322 minecraft:white_concrete
fill 229 231 322 229 240 322 minecraft:black_concrete
setblock 188 232 357 minecraft:sea_lantern
fill 188 232 360 188 243 360 minecraft:black_concrete
fill 196 232 338 198 232 342 minecraft:white_concrete
fill 201 232 322 201 308 322 minecraft:black_concrete
fill 221 232 322 221 246 322 minecraft:black_concrete
fill 225 232 322 225 251 322 minecraft:black_concrete
setblock 226 232 364 minecraft:white_concrete
setblock 230 232 323 minecraft:sea_lantern
setblock 230 232 332 minecraft:white_concrete
setblock 188 233 341 minecraft:white_concrete
fill 188 233 357 188 299 357 minecraft:black_concrete
setblock 191 233 325 minecraft:light[level=12]
setblock 191 233 332 minecraft:light[level=12]
setblock 191 233 339 minecraft:light[level=12]
setblock 191 233 346 minecraft:light[level=12]
setblock 191 233 353 minecraft:light[level=12]
setblock 191 233 360 minecraft:light[level=12]
fill 196 233 338 196 233 342 minecraft:white_concrete
fill 197 233 338 198 233 338 minecraft:white_concrete
fill 197 233 339 197 233 340 minecraft:black_concrete
fill 197 233 341 198 233 342 minecraft:white_concrete
setblock 198 233 325 minecraft:light[level=12]
setblock 198 233 332 minecraft:light[level=12]
fill 198 233 339 198 233 340 minecraft:white_concrete
setblock 198 233 346 minecraft:light[level=12]
setblock 198 233 353 minecraft:light[level=12]
setblock 198 233 360 minecraft:light[level=12]
setblock 205 233 325 minecraft:light[level=12]
setblock 205 233 332 minecraft:light[level=12]
setblock 205 233 339 minecraft:light[level=12]
setblock 205 233 346 minecraft:light[level=12]
setblock 205 233 353 minecraft:light[level=12]
setblock 205 233 360 minecraft:light[level=12]
setblock 212 233 325 minecraft:light[level=12]
setblock 212 233 332 minecraft:light[level=12]
setblock 212 233 339 minecraft:light[level=12]
setblock 212 233 346 minecraft:light[level=12]
setblock 212 233 353 minecraft:light[level=12]
setblock 212 233 360 minecraft:light[level=12]
setblock 219 233 325 minecraft:light[level=12]
setblock 219 233 332 minecraft:light[level=12]
setblock 219 233 339 minecraft:light[level=12]
setblock 219 233 346 minecraft:light[level=12]
setblock 219 233 353 minecraft:light[level=12]
setblock 219 233 360 minecraft:light[level=12]
setblock 226 233 325 minecraft:light[level=12]
setblock 226 233 332 minecraft:light[level=12]
setblock 226 233 339 minecraft:light[level=12]
setblock 226 233 346 minecraft:light[level=12]
setblock 226 233 353 minecraft:light[level=12]
setblock 226 233 360 minecraft:light[level=12]
fill 226 233 364 226 263 364 minecraft:black_concrete
setblock 230 233 323 minecraft:black_concrete
fill 230 233 332 230 247 332 minecraft:black_concrete
setblock 230 233 346 minecraft:ochre_froglight
setblock 230 233 355 minecraft:white_concrete
fill 188 234 341 188 238 341 minecraft:black_concrete
setblock 188 234 345 minecraft:white_concrete
setblock 188 234 352 minecraft:white_concrete
setblock 188 234 361 minecraft:pearlescent_froglight
setblock 191 234 322 minecraft:pearlescent_froglight
fill 202 234 344 202 236 352 minecraft:iron_block
fill 203 234 343 203 236 345 minecraft:iron_block
fill 203 234 346 203 235 346 minecraft:magenta_stained_glass
fill 203 234 347 203 235 348 minecraft:purple_stained_glass
fill 203 234 349 203 235 349 minecraft:magenta_stained_glass
fill 203 234 350 204 235 350 minecraft:purple_stained_glass
fill 203 234 351 203 236 353 minecraft:iron_block
fill 204 234 342 204 236 343 minecraft:iron_block
fill 204 234 344 204 235 344 minecraft:purple_stained_glass
fill 204 234 345 204 235 345 minecraft:magenta_stained_glass
fill 204 234 346 204 235 347 minecraft:purple_stained_glass
fill 204 234 348 204 235 348 minecraft:magenta_stained_glass
fill 204 234 349 205 235 349 minecraft:purple_stained_glass
fill 204 234 351 204 235 351 minecraft:magenta_stained_glass
fill 204 234 352 205 235 352 minecraft:purple_stained_glass
fill 204 234 353 204 236 354 minecraft:iron_block
fill 205 234 341 205 236 342 minecraft:iron_block
fill 205 234 343 205 235 343 minecraft:purple_stained_glass
fill 205 234 344 205 235 344 minecraft:magenta_stained_glass
fill 205 234 345 205 235 346 minecraft:purple_stained_glass
fill 205 234 347 205 235 347 minecraft:magenta_stained_glass
fill 205 234 348 206 235 348 minecraft:purple_stained_glass
fill 205 234 350 205 235 350 minecraft:magenta_stained_glass
fill 205 234 351 206 235 351 minecraft:purple_stained_glass
fill 205 234 353 205 235 353 minecraft:magenta_stained_glass
fill 205 234 354 205 236 355 minecraft:iron_block
fill 206 234 340 207 236 341 minecraft:iron_block
fill 206 234 342 206 235 342 minecraft:purple_stained_glass
fill 206 234 343 206 235 343 minecraft:magenta_stained_glass
fill 206 234 344 206 235 345 minecraft:purple_stained_glass
fill 206 234 346 206 235 346 minecraft:magenta_stained_glass
fill 206 234 347 207 234 347 minecraft:purple_stained_glass
fill 206 234 349 206 235 349 minecraft:magenta_stained_glass
fill 206 234 350 207 234 350 minecraft:purple_stained_glass
fill 206 234 352 206 235 352 minecraft:magenta_stained_glass
fill 206 234 353 206 235 354 minecraft:purple_stained_glass
fill 206 234 355 207 236 356 minecraft:iron_block
fill 207 234 342 207 235 342 minecraft:magenta_stained_glass
fill 207 234 343 207 235 344 minecraft:purple_stained_glass
fill 207 234 345 207 235 345 minecraft:magenta_stained_glass
fill 207 234 346 208 234 346 minecraft:purple_stained_glass
setblock 207 234 348 minecraft:magenta_stained_glass
setblock 207 234 349 minecraft:purple_stained_glass
fill 207 234 351 207 235 351 minecraft:magenta_stained_glass
fill 207 234 352 207 235 353 minecraft:purple_stained_glass
fill 207 234 354 207 235 354 minecraft:magenta_stained_glass
fill 208 234 340 214 236 340 minecraft:iron_block
fill 208 234 341 208 235 341 minecraft:magenta_stained_glass
fill 208 234 342 208 235 343 minecraft:purple_stained_glass
fill 208 234 344 208 235 344 minecraft:magenta_stained_glass
fill 208 234 345 209 234 345 minecraft:purple_stained_glass
setblock 208 234 350 minecraft:magenta_stained_glass
fill 208 234 351 208 234 352 minecraft:purple_stained_glass
fill 208 234 353 208 235 353 minecraft:magenta_stained_glass
fill 208 234 354 208 235 355 minecraft:purple_stained_glass
fill 208 234 356 214 236 356 minecraft:iron_block
fill 209 234 341 209 235 342 minecraft:purple_stained_glass
fill 209 234 343 209 235 343 minecraft:magenta_stained_glass
fill 209 234 344 210 235 344 minecraft:purple_stained_glass
setblock 209 234 351 minecraft:purple_stained_glass
fill 209 234 352 209 235 352 minecraft:magenta_stained_glass
fill 209 234 353 209 235 354 minecraft:purple_stained_glass
fill 209 234 355 209 235 355 minecraft:magenta_stained_glass
fill 210 234 341 210 235 341 minecraft:purple_stained_glass
fill 210 234 342 210 235 342 minecraft:magenta_stained_glass
fill 210 234 343 211 235 343 minecraft:purple_stained_glass
setblock 210 234 345 minecraft:magenta_stained_glass
setblock 210 234 351 minecraft:magenta_stained_glass
fill 210 234 352 210 235 353 minecraft:purple_stained_glass
fill 210 234 354 210 235 354 minecraft:magenta_stained_glass
fill 210 234 355 211 235 355 minecraft:purple_stained_glass
fill 211 234 341 211 235 341 minecraft:magenta_stained_glass
fill 211 234 342 212 235 342 minecraft:purple_stained_glass
fill 211 234 344 211 235 344 minecraft:magenta_stained_glass
fill 211 234 345 212 234 345 minecraft:purple_stained_glass
fill 211 234 351 211 234 352 minecraft:purple_stained_glass
fill 211 234 353 211 235 353 minecraft:magenta_stained_glass
fill 211 234 354 212 235 354 minecraft:purple_stained_glass
fill 212 234 341 212 235 341 minecraft:purple_stained_glass
fill 212 234 343 212 235 343 minecraft:magenta_stained_glass
fill 212 234 344 213 235 344 minecraft:purple_stained_glass
setblock 212 234 346 minecraft:magenta_stained_glass
fill 212 234 350 212 234 351 minecraft:purple_stained_glass
fill 212 234 352 212 235 352 minecraft:magenta_stained_glass
fill 212 234 353 213 235 353 minecraft:purple_stained_glass
fill 212 234 355 212 235 355 minecraft:magenta_stained_glass
fill 213 234 341 215 236 341 minecraft:iron_block
fill 213 234 342 213 235 342 minecraft:magenta_stained_glass
fill 213 234 343 214 235 343 minecraft:purple_stained_glass
fill 213 234 345 213 235 345 minecraft:magenta_stained_glass
fill 213 234 346 213 234 347 minecraft:purple_stained_glass
setblock 213 234 348 minecraft:magenta_stained_glass
fill 213 234 349 213 234 350 minecraft:purple_stained_glass
fill 213 234 351 213 235 351 minecraft:magenta_stained_glass
fill 213 234 352 214 235 352 minecraft:purple_stained_glass
fill 213 234 354 213 235 354 minecraft:magenta_stained_glass
fill 213 234 355 215 236 355 minecraft:iron_block
fill 214 234 342 214 235 342 minecraft:purple_stained_glass
fill 214 234 344 214 235 344 minecraft:magenta_stained_glass
fill 214 234 345 214 235 346 minecraft:purple_stained_glass
fill 214 234 347 214 235 347 minecraft:magenta_stained_glass
fill 214 234 348 214 235 349 minecraft:purple_stained_glass
fill 214 234 350 214 235 350 minecraft:magenta_stained_glass
fill 214 234 351 215 235 351 minecraft:purple_stained_glass
fill 214 234 353 214 235 353 minecraft:magenta_stained_glass
fill 214 234 354 214 235 354 minecraft:purple_stained_glass
fill 215 234 342 216 236 342 minecraft:iron_block
fill 215 234 343 215 235 343 minecraft:magenta_stained_glass
fill 215 234 344 215 235 345 minecraft:purple_stained_glass
fill 215 234 346 215 235 346 minecraft:magenta_stained_glass
fill 215 234 347 215 235 348 minecraft:purple_stained_glass
fill 215 234 349 215 235 349 minecraft:magenta_stained_glass
fill 215 234 350 216 235 350 minecraft:purple_stained_glass
fill 215 234 352 215 235 352 minecraft:magenta_stained_glass
fill 215 234 353 215 235 353 minecraft:purple_stained_glass
fill 215 234 354 216 236 354 minecraft:iron_block
fill 216 234 343 217 236 343 minecraft:iron_block
fill 216 234 344 216 235 344 minecraft:purple_stained_glass
fill 216 234 345 216 235 345 minecraft:magenta_stained_glass
fill 216 234 346 216 235 347 minecraft:purple_stained_glass
fill 216 234 348 216 235 348 minecraft:magenta_stained_glass
fill 216 234 349 217 235 349 minecraft:purple_stained_glass
fill 216 234 351 216 235 351 minecraft:magenta_stained_glass
fill 216 234 352 216 235 352 minecraft:purple_stained_glass
fill 216 234 353 217 236 353 minecraft:iron_block
fill 217 234 344 218 236 345 minecraft:iron_block
fill 217 234 346 217 235 346 minecraft:purple_stained_glass
schedule function dropper:buildpart/76_2 1t
