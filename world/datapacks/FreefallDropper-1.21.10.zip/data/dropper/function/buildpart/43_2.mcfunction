fill 371 56 212 371 61 213 minecraft:smooth_basalt
fill 371 56 214 371 56 215 minecraft:bone_block
fill 371 56 223 371 57 223 minecraft:bone_block
setblock 329 57 190 minecraft:bone_block
setblock 329 57 193 minecraft:bone_block
fill 329 57 194 329 60 194 minecraft:smooth_basalt
setblock 329 57 201 minecraft:bone_block
fill 329 57 205 329 60 205 minecraft:smooth_basalt
fill 329 57 221 329 57 222 minecraft:bone_block
setblock 331 57 223 minecraft:bone_block
setblock 332 57 184 minecraft:light[level=12]
setblock 332 57 192 minecraft:light[level=12]
setblock 332 57 200 minecraft:light[level=12]
setblock 332 57 208 minecraft:light[level=12]
setblock 332 57 216 minecraft:light[level=12]
fill 332 57 223 332 60 223 minecraft:smooth_basalt
fill 340 57 181 341 59 181 minecraft:smooth_basalt
setblock 340 57 184 minecraft:light[level=12]
setblock 340 57 192 minecraft:light[level=12]
setblock 340 57 200 minecraft:light[level=12]
setblock 340 57 208 minecraft:light[level=12]
setblock 340 57 216 minecraft:light[level=12]
fill 343 57 223 343 60 223 minecraft:smooth_basalt
setblock 345 57 181 minecraft:bone_block
setblock 348 57 184 minecraft:light[level=12]
setblock 348 57 192 minecraft:light[level=12]
setblock 348 57 200 minecraft:light[level=12]
setblock 348 57 208 minecraft:light[level=12]
setblock 348 57 216 minecraft:light[level=12]
setblock 348 57 223 minecraft:bone_block
setblock 356 57 181 minecraft:bone_block
setblock 356 57 184 minecraft:light[level=12]
setblock 356 57 192 minecraft:light[level=12]
setblock 356 57 200 minecraft:light[level=12]
setblock 356 57 208 minecraft:light[level=12]
setblock 356 57 216 minecraft:light[level=12]
setblock 359 57 223 minecraft:bone_block
fill 361 57 181 361 59 181 minecraft:smooth_basalt
fill 363 57 223 364 60 223 minecraft:smooth_basalt
setblock 364 57 184 minecraft:light[level=12]
setblock 364 57 192 minecraft:light[level=12]
setblock 364 57 200 minecraft:light[level=12]
setblock 364 57 208 minecraft:light[level=12]
setblock 364 57 216 minecraft:light[level=12]
fill 371 57 182 371 60 182 minecraft:smooth_basalt
setblock 371 57 183 minecraft:bone_block
fill 371 57 186 371 57 187 minecraft:bone_block
fill 371 57 203 371 60 203 minecraft:smooth_basalt
setblock 371 57 207 minecraft:bone_block
fill 371 57 214 371 60 214 minecraft:smooth_basalt
setblock 371 57 215 minecraft:bone_block
setblock 371 57 218 minecraft:bone_block
fill 329 58 181 329 61 182 minecraft:smooth_basalt
fill 329 58 188 329 59 188 minecraft:bone_block
fill 329 58 190 329 63 190 minecraft:smooth_basalt
fill 329 58 191 329 58 192 minecraft:bone_block
fill 329 58 193 329 62 193 minecraft:smooth_basalt
fill 329 58 199 329 59 200 minecraft:bone_block
fill 329 58 201 329 63 202 minecraft:smooth_basalt
fill 329 58 211 329 58 212 minecraft:bone_block
fill 329 58 213 329 63 214 minecraft:smooth_basalt
fill 329 58 220 329 59 220 minecraft:bone_block
fill 329 58 221 329 62 222 minecraft:smooth_basalt
setblock 329 58 223 minecraft:bone_block
fill 331 58 223 331 63 223 minecraft:smooth_basalt
fill 332 58 181 333 63 181 minecraft:smooth_basalt
fill 334 58 181 335 58 181 minecraft:bone_block
fill 337 58 223 338 59 223 minecraft:bone_block
fill 339 58 223 340 63 223 minecraft:smooth_basalt
fill 342 58 181 342 61 181 minecraft:smooth_basalt
setblock 343 58 181 minecraft:bone_block
fill 344 58 181 345 63 181 minecraft:smooth_basalt
fill 346 58 181 347 59 181 minecraft:bone_block
fill 348 58 223 348 63 223 minecraft:smooth_basalt
fill 349 58 223 350 58 223 minecraft:bone_block
fill 351 58 223 352 61 223 minecraft:smooth_basalt
fill 352 58 181 353 60 181 minecraft:smooth_basalt
fill 354 58 181 355 58 181 minecraft:bone_block
fill 356 58 181 356 62 181 minecraft:smooth_basalt
fill 357 58 223 358 59 223 minecraft:bone_block
fill 358 58 181 358 59 181 minecraft:bone_block
fill 358 58 194 359 59 195 minecraft:calcite
setblock 359 58 181 minecraft:smooth_basalt
fill 359 58 223 360 63 223 minecraft:smooth_basalt
setblock 361 58 223 minecraft:bone_block
fill 364 58 181 365 62 181 minecraft:smooth_basalt
fill 366 58 181 367 59 181 minecraft:bone_block
fill 369 58 223 370 59 223 minecraft:bone_block
fill 371 58 183 371 60 183 minecraft:smooth_basalt
setblock 371 58 185 minecraft:bone_block
fill 371 58 186 371 60 187 minecraft:smooth_basalt
fill 371 58 188 371 59 188 minecraft:bone_block
fill 371 58 194 371 63 195 minecraft:smooth_basalt
fill 371 58 196 371 58 197 minecraft:bone_block
fill 371 58 206 371 61 207 minecraft:smooth_basalt
fill 371 58 208 371 59 209 minecraft:bone_block
fill 371 58 215 371 63 215 minecraft:smooth_basalt
fill 371 58 216 371 58 217 minecraft:bone_block
fill 371 58 218 371 63 218 minecraft:smooth_basalt
fill 371 58 220 371 59 220 minecraft:bone_block
fill 371 58 223 371 63 223 minecraft:smooth_basalt
setblock 329 59 187 minecraft:bone_block
fill 329 59 191 329 62 192 minecraft:smooth_basalt
setblock 329 59 208 minecraft:bone_block
setblock 329 59 211 minecraft:bone_block
fill 329 59 212 329 62 212 minecraft:smooth_basalt
setblock 329 59 219 minecraft:bone_block
fill 329 59 223 329 60 223 minecraft:smooth_basalt
fill 334 59 181 334 62 181 minecraft:smooth_basalt
setblock 335 59 181 minecraft:bone_block
setblock 338 59 181 minecraft:bone_block
fill 343 59 181 343 61 181 minecraft:smooth_basalt
fill 345 59 223 346 59 223 minecraft:bone_block
setblock 349 59 223 minecraft:bone_block
fill 350 59 223 350 62 223 minecraft:smooth_basalt
fill 354 59 181 354 61 181 minecraft:smooth_basalt
setblock 355 59 181 minecraft:bone_block
fill 355 59 209 357 60 209 minecraft:bone_block
fill 356 59 208 356 60 208 minecraft:bone_block
fill 356 59 210 356 60 210 minecraft:bone_block
setblock 359 59 181 minecraft:bone_block
fill 361 59 223 361 62 223 minecraft:smooth_basalt
setblock 366 59 223 minecraft:bone_block
setblock 370 59 181 minecraft:bone_block
fill 371 59 181 371 61 181 minecraft:smooth_basalt
fill 371 59 185 371 62 185 minecraft:smooth_basalt
setblock 371 59 189 minecraft:bone_block
fill 371 59 196 371 61 196 minecraft:smooth_basalt
setblock 371 59 197 minecraft:bone_block
setblock 371 59 200 minecraft:bone_block
fill 371 59 216 371 60 217 minecraft:smooth_basalt
setblock 371 59 221 minecraft:bone_block
fill 329 60 185 329 61 186 minecraft:bone_block
fill 329 60 187 329 60 188 minecraft:smooth_basalt
setblock 329 60 189 minecraft:bone_block
fill 329 60 197 329 61 198 minecraft:bone_block
fill 329 60 199 329 60 200 minecraft:smooth_basalt
fill 329 60 206 329 61 206 minecraft:bone_block
fill 329 60 208 329 61 208 minecraft:smooth_basalt
fill 329 60 209 329 60 210 minecraft:bone_block
fill 329 60 211 329 65 211 minecraft:smooth_basalt
fill 329 60 217 329 61 218 minecraft:bone_block
fill 329 60 219 329 64 220 minecraft:smooth_basalt
fill 330 60 182 332 60 182 minecraft:polished_basalt
fill 330 60 184 330 60 186 minecraft:polished_basalt
fill 330 60 188 330 60 190 minecraft:polished_basalt
fill 330 60 192 330 60 194 minecraft:polished_basalt
fill 330 60 196 330 60 198 minecraft:polished_basalt
fill 330 60 200 330 60 202 minecraft:polished_basalt
fill 330 60 204 330 60 206 minecraft:polished_basalt
fill 330 60 208 330 60 210 minecraft:polished_basalt
fill 330 60 212 330 60 214 minecraft:polished_basalt
fill 330 60 216 330 60 218 minecraft:polished_basalt
fill 330 60 220 330 60 222 minecraft:polished_basalt
fill 332 60 222 334 60 222 minecraft:polished_basalt
fill 334 60 182 336 60 182 minecraft:polished_basalt
fill 335 60 181 335 64 181 minecraft:smooth_basalt
fill 335 60 223 336 60 223 minecraft:bone_block
fill 336 60 181 337 60 181 minecraft:bone_block
fill 336 60 222 338 60 222 minecraft:polished_basalt
fill 337 60 223 338 61 223 minecraft:smooth_basalt
fill 338 60 181 338 64 181 minecraft:smooth_basalt
fill 338 60 182 340 60 182 minecraft:polished_basalt
fill 340 60 181 340 61 181 minecraft:bone_block
fill 340 60 222 342 60 222 minecraft:polished_basalt
setblock 341 60 181 minecraft:smooth_basalt
fill 342 60 182 344 60 182 minecraft:polished_basalt
fill 344 60 222 346 60 222 minecraft:polished_basalt
fill 344 60 223 344 61 223 minecraft:bone_block
fill 345 60 223 346 61 223 minecraft:smooth_basalt
fill 346 60 181 347 61 181 minecraft:smooth_basalt
fill 346 60 182 348 60 182 minecraft:polished_basalt
setblock 347 60 223 minecraft:bone_block
fill 348 60 181 349 61 181 minecraft:bone_block
fill 348 60 222 350 60 222 minecraft:polished_basalt
fill 349 60 223 349 64 223 minecraft:smooth_basalt
fill 350 60 182 352 60 182 minecraft:polished_basalt
fill 352 60 222 354 60 222 minecraft:polished_basalt
fill 354 60 182 356 60 182 minecraft:polished_basalt
fill 355 60 181 355 62 181 minecraft:smooth_basalt
fill 355 60 223 356 61 223 minecraft:bone_block
fill 356 60 222 358 60 222 minecraft:polished_basalt
setblock 357 60 181 minecraft:bone_block
fill 357 60 223 358 64 223 minecraft:smooth_basalt
fill 358 60 181 359 64 181 minecraft:smooth_basalt
fill 358 60 182 360 60 182 minecraft:polished_basalt
fill 360 60 181 361 61 181 minecraft:bone_block
fill 360 60 222 362 60 222 minecraft:polished_basalt
fill 362 60 182 364 60 182 minecraft:polished_basalt
fill 364 60 222 366 60 222 minecraft:polished_basalt
fill 366 60 181 367 60 181 minecraft:smooth_basalt
fill 366 60 182 368 60 182 minecraft:polished_basalt
fill 366 60 223 366 64 223 minecraft:smooth_basalt
fill 367 60 223 368 60 223 minecraft:bone_block
fill 368 60 181 369 60 181 minecraft:bone_block
fill 368 60 222 370 60 222 minecraft:polished_basalt
fill 369 60 223 370 61 223 minecraft:smooth_basalt
fill 370 60 181 370 61 181 minecraft:smooth_basalt
fill 370 60 182 370 60 184 minecraft:polished_basalt
fill 370 60 186 370 60 188 minecraft:polished_basalt
fill 370 60 190 370 60 192 minecraft:polished_basalt
fill 370 60 194 370 60 196 minecraft:polished_basalt
fill 370 60 198 370 60 200 minecraft:polished_basalt
fill 370 60 202 370 60 204 minecraft:polished_basalt
fill 370 60 206 370 60 208 minecraft:polished_basalt
fill 370 60 210 370 60 212 minecraft:polished_basalt
fill 370 60 214 370 60 216 minecraft:polished_basalt
fill 370 60 218 370 60 220 minecraft:polished_basalt
fill 371 60 188 371 64 189 minecraft:smooth_basalt
fill 371 60 190 371 61 191 minecraft:bone_block
fill 371 60 197 371 64 197 minecraft:smooth_basalt
fill 371 60 198 371 60 199 minecraft:bone_block
fill 371 60 200 371 64 200 minecraft:smooth_basalt
fill 371 60 202 371 61 202 minecraft:bone_block
fill 371 60 208 371 62 209 minecraft:smooth_basalt
fill 371 60 210 371 61 211 minecraft:bone_block
setblock 371 60 219 minecraft:bone_block
fill 371 60 220 371 64 221 minecraft:smooth_basalt
fill 371 60 222 371 61 222 minecraft:bone_block
setblock 329 61 187 minecraft:calcite
fill 329 61 188 329 64 189 minecraft:smooth_basalt
setblock 329 61 194 minecraft:bone_block
fill 329 61 199 329 65 199 minecraft:smooth_basalt
setblock 329 61 200 minecraft:calcite
setblock 329 61 205 minecraft:bone_block
fill 329 61 209 329 61 210 minecraft:calcite
setblock 329 61 223 minecraft:calcite
setblock 332 61 223 minecraft:bone_block
setblock 335 61 223 minecraft:bone_block
fill 336 61 181 337 61 181 minecraft:smooth_basalt
fill 336 61 223 336 64 223 minecraft:smooth_basalt
setblock 341 61 181 minecraft:bone_block
setblock 343 61 223 minecraft:bone_block
setblock 347 61 223 minecraft:calcite
setblock 352 61 181 minecraft:bone_block
setblock 353 61 181 minecraft:smooth_basalt
setblock 353 61 223 minecraft:calcite
setblock 354 61 223 minecraft:smooth_basalt
fill 357 61 181 357 64 181 minecraft:smooth_basalt
fill 363 61 223 364 61 223 minecraft:bone_block
fill 366 61 181 366 64 181 minecraft:smooth_basalt
setblock 367 61 181 minecraft:calcite
setblock 367 61 223 minecraft:bone_block
fill 368 61 181 368 64 181 minecraft:smooth_basalt
fill 368 61 223 368 62 223 minecraft:smooth_basalt
setblock 369 61 181 minecraft:bone_block
fill 371 61 182 371 61 183 minecraft:bone_block
setblock 371 61 186 minecraft:calcite
fill 371 61 187 371 63 187 minecraft:smooth_basalt
fill 371 61 198 371 61 199 minecraft:smooth_basalt
setblock 371 61 203 minecraft:bone_block
setblock 371 61 214 minecraft:bone_block
fill 371 61 216 371 62 216 minecraft:smooth_basalt
setblock 371 61 217 minecraft:calcite
fill 371 61 219 371 64 219 minecraft:smooth_basalt
fill 329 62 181 329 63 181 minecraft:smooth_basalt
setblock 329 62 182 minecraft:calcite
fill 329 62 183 329 63 184 minecraft:bone_block
fill 329 62 185 329 64 187 minecraft:smooth_basalt
fill 329 62 194 329 64 194 minecraft:smooth_basalt
fill 329 62 195 329 62 196 minecraft:bone_block
fill 329 62 197 329 64 198 minecraft:smooth_basalt
fill 329 62 200 329 64 200 minecraft:smooth_basalt
fill 329 62 203 329 63 204 minecraft:bone_block
fill 329 62 205 329 64 206 minecraft:smooth_basalt
setblock 329 62 207 minecraft:bone_block
setblock 329 62 208 minecraft:calcite
fill 329 62 209 329 64 209 minecraft:smooth_basalt
setblock 329 62 210 minecraft:calcite
fill 329 62 215 329 63 216 minecraft:bone_block
fill 329 62 217 329 64 218 minecraft:smooth_basalt
setblock 329 62 223 minecraft:smooth_basalt
fill 330 62 181 331 63 181 minecraft:bone_block
fill 330 62 223 330 63 223 minecraft:bone_block
setblock 332 62 223 minecraft:calcite
fill 333 62 223 334 62 223 minecraft:bone_block
fill 335 62 223 335 64 223 minecraft:smooth_basalt
setblock 336 62 181 minecraft:calcite
fill 337 62 181 337 64 181 minecraft:smooth_basalt
setblock 337 62 223 minecraft:calcite
fill 338 62 223 338 64 223 minecraft:smooth_basalt
setblock 339 62 181 minecraft:bone_block
fill 340 62 181 341 64 181 minecraft:smooth_basalt
fill 341 62 223 342 63 223 minecraft:bone_block
fill 342 62 181 343 63 181 minecraft:bone_block
fill 343 62 223 344 64 223 minecraft:smooth_basalt
setblock 345 62 223 minecraft:calcite
fill 346 62 181 346 64 181 minecraft:smooth_basalt
fill 346 62 223 347 64 223 minecraft:smooth_basalt
setblock 347 62 181 minecraft:calcite
fill 348 62 181 349 64 181 minecraft:smooth_basalt
fill 350 62 181 351 62 181 minecraft:bone_block
fill 351 62 223 351 63 223 minecraft:smooth_basalt
fill 352 62 181 352 63 181 minecraft:smooth_basalt
setblock 352 62 223 minecraft:calcite
fill 353 62 181 354 62 181 minecraft:calcite
fill 353 62 223 354 62 223 minecraft:bone_block
fill 355 62 223 356 62 223 minecraft:smooth_basalt
fill 360 62 181 361 62 181 minecraft:smooth_basalt
fill 362 62 181 363 63 181 minecraft:bone_block
fill 362 62 223 362 63 223 minecraft:bone_block
fill 363 62 223 364 64 223 minecraft:smooth_basalt
setblock 365 62 223 minecraft:bone_block
fill 367 62 181 367 64 181 minecraft:smooth_basalt
fill 367 62 223 367 64 223 minecraft:smooth_basalt
setblock 369 62 181 minecraft:calcite
fill 369 62 223 369 64 223 minecraft:smooth_basalt
fill 370 62 181 371 62 181 minecraft:bone_block
fill 370 62 223 370 63 223 minecraft:calcite
fill 371 62 182 371 63 183 minecraft:smooth_basalt
fill 371 62 184 371 63 184 minecraft:bone_block
fill 371 62 186 371 63 186 minecraft:smooth_basalt
fill 371 62 190 371 64 191 minecraft:smooth_basalt
fill 371 62 192 371 63 193 minecraft:bone_block
setblock 371 62 196 minecraft:calcite
fill 371 62 198 371 64 198 minecraft:smooth_basalt
setblock 371 62 199 minecraft:calcite
setblock 371 62 201 minecraft:bone_block
fill 371 62 202 371 64 202 minecraft:smooth_basalt
setblock 371 62 203 minecraft:calcite
fill 371 62 204 371 63 205 minecraft:bone_block
setblock 371 62 206 minecraft:calcite
fill 371 62 207 371 63 207 minecraft:smooth_basalt
fill 371 62 210 371 64 211 minecraft:smooth_basalt
fill 371 62 212 371 62 213 minecraft:bone_block
fill 371 62 214 371 64 214 minecraft:smooth_basalt
setblock 371 62 217 minecraft:smooth_basalt
fill 371 62 222 371 64 222 minecraft:smooth_basalt
setblock 329 63 182 minecraft:smooth_basalt
fill 329 63 191 329 63 192 minecraft:bone_block
setblock 329 63 193 minecraft:calcite
setblock 329 63 195 minecraft:bone_block
fill 329 63 196 329 65 196 minecraft:smooth_basalt
fill 329 63 207 329 64 208 minecraft:smooth_basalt
fill 329 63 210 329 64 210 minecraft:smooth_basalt
setblock 329 63 212 minecraft:bone_block
setblock 329 63 221 minecraft:smooth_basalt
setblock 329 63 222 minecraft:calcite
setblock 329 63 223 minecraft:bone_block
fill 332 63 223 332 64 223 minecraft:smooth_basalt
fill 333 63 223 334 63 223 minecraft:calcite
setblock 334 63 181 minecraft:bone_block
fill 336 63 181 336 64 181 minecraft:smooth_basalt
fill 337 63 223 337 64 223 minecraft:smooth_basalt
fill 339 63 181 339 64 181 minecraft:smooth_basalt
fill 345 63 223 345 64 223 minecraft:smooth_basalt
fill 347 63 181 347 64 181 minecraft:smooth_basalt
fill 350 63 181 350 64 181 minecraft:smooth_basalt
setblock 350 63 223 minecraft:bone_block
setblock 351 63 181 minecraft:bone_block
setblock 352 63 223 minecraft:smooth_basalt
setblock 353 63 181 minecraft:smooth_basalt
setblock 353 63 223 minecraft:bone_block
fill 354 63 181 355 63 181 minecraft:bone_block
fill 354 63 223 354 64 223 minecraft:smooth_basalt
setblock 355 63 223 minecraft:calcite
setblock 356 63 181 minecraft:calcite
fill 356 63 223 356 64 223 minecraft:smooth_basalt
fill 360 63 181 360 64 181 minecraft:smooth_basalt
setblock 361 63 181 minecraft:calcite
setblock 361 63 223 minecraft:bone_block
setblock 364 63 181 minecraft:smooth_basalt
setblock 365 63 181 minecraft:calcite
fill 365 63 223 365 64 223 minecraft:smooth_basalt
setblock 368 63 223 minecraft:calcite
fill 369 63 181 371 64 181 minecraft:smooth_basalt
setblock 371 63 185 minecraft:bone_block
setblock 371 63 196 minecraft:bone_block
fill 371 63 199 371 64 199 minecraft:smooth_basalt
fill 371 63 201 371 64 201 minecraft:smooth_basalt
fill 371 63 203 371 64 203 minecraft:smooth_basalt
setblock 371 63 206 minecraft:smooth_basalt
fill 371 63 208 371 64 208 minecraft:smooth_basalt
setblock 371 63 209 minecraft:calcite
fill 371 63 212 371 64 212 minecraft:smooth_basalt
setblock 371 63 213 minecraft:bone_block
fill 371 63 216 371 63 217 minecraft:bone_block
fill 329 64 181 329 64 182 minecraft:bone_block
fill 329 64 183 329 64 184 minecraft:smooth_basalt
fill 329 64 190 329 65 190 minecraft:bone_block
fill 329 64 191 329 64 192 minecraft:smooth_basalt
setblock 329 64 193 minecraft:bone_block
setblock 329 64 195 minecraft:smooth_basalt
fill 329 64 201 329 65 202 minecraft:bone_block
fill 329 64 203 329 64 204 minecraft:smooth_basalt
setblock 329 64 212 minecraft:smooth_basalt
fill 329 64 213 329 64 214 minecraft:bone_block
fill 329 64 215 329 64 216 minecraft:smooth_basalt
fill 329 64 221 329 65 222 minecraft:bone_block
fill 329 64 223 330 64 223 minecraft:smooth_basalt
fill 330 64 181 331 64 181 minecraft:smooth_basalt
setblock 331 64 223 minecraft:bone_block
fill 332 64 181 333 64 181 minecraft:bone_block
fill 333 64 223 334 64 223 minecraft:smooth_basalt
setblock 334 64 181 minecraft:smooth_basalt
fill 339 64 223 340 65 223 minecraft:bone_block
fill 341 64 223 342 64 223 minecraft:smooth_basalt
fill 342 64 181 343 64 181 minecraft:smooth_basalt
fill 344 64 181 345 65 181 minecraft:bone_block
fill 348 64 223 348 65 223 minecraft:bone_block
setblock 350 64 223 minecraft:smooth_basalt
fill 351 64 181 351 65 181 minecraft:smooth_basalt
fill 351 64 223 352 64 223 minecraft:bone_block
fill 352 64 181 353 64 181 minecraft:bone_block
setblock 353 64 223 minecraft:smooth_basalt
fill 354 64 181 355 64 181 minecraft:smooth_basalt
setblock 355 64 223 minecraft:smooth_basalt
fill 356 64 181 356 65 181 minecraft:bone_block
fill 359 64 223 360 65 223 minecraft:bone_block
fill 361 64 181 363 64 181 minecraft:smooth_basalt
fill 361 64 223 362 64 223 minecraft:smooth_basalt
fill 364 64 181 365 65 181 minecraft:bone_block
setblock 368 64 223 minecraft:smooth_basalt
setblock 370 64 223 minecraft:smooth_basalt
fill 371 64 182 371 65 182 minecraft:smooth_basalt
setblock 371 64 183 minecraft:bone_block
fill 371 64 184 371 64 185 minecraft:smooth_basalt
fill 371 64 186 371 65 187 minecraft:bone_block
fill 371 64 192 371 64 193 minecraft:smooth_basalt
fill 371 64 194 371 64 195 minecraft:bone_block
fill 371 64 196 371 66 196 minecraft:smooth_basalt
fill 371 64 204 371 64 205 minecraft:smooth_basalt
fill 371 64 206 371 65 207 minecraft:bone_block
setblock 371 64 209 minecraft:smooth_basalt
fill 371 64 213 371 65 213 minecraft:smooth_basalt
setblock 371 64 215 minecraft:bone_block
fill 371 64 216 371 64 217 minecraft:smooth_basalt
fill 371 64 218 371 65 218 minecraft:bone_block
fill 371 64 223 371 65 223 minecraft:bone_block
setblock 329 65 181 minecraft:bone_block
fill 329 65 182 329 65 187 minecraft:calcite
setblock 329 65 188 minecraft:smooth_basalt
setblock 329 65 189 minecraft:bone_block
fill 329 65 191 329 69 191 minecraft:calcite
setblock 329 65 192 minecraft:smooth_basalt
fill 329 65 193 329 65 195 minecraft:calcite
fill 329 65 197 329 65 198 minecraft:calcite
setblock 329 65 200 minecraft:calcite
fill 329 65 203 329 65 205 minecraft:calcite
setblock 329 65 206 minecraft:smooth_basalt
fill 329 65 207 329 65 208 minecraft:calcite
fill 329 65 209 329 65 210 minecraft:bone_block
fill 329 65 212 329 69 212 minecraft:calcite
setblock 329 65 213 minecraft:bone_block
fill 329 65 214 329 67 217 minecraft:calcite
setblock 329 65 218 minecraft:smooth_basalt
fill 329 65 219 329 65 220 minecraft:calcite
setblock 329 65 223 minecraft:smooth_basalt
fill 330 65 181 332 68 181 minecraft:calcite
fill 330 65 223 335 66 223 minecraft:calcite
setblock 332 65 184 minecraft:light[level=12]
setblock 332 65 192 minecraft:light[level=12]
setblock 332 65 200 minecraft:light[level=12]
setblock 332 65 208 minecraft:light[level=12]
setblock 332 65 216 minecraft:light[level=12]
setblock 333 65 181 minecraft:bone_block
fill 334 65 181 335 65 181 minecraft:calcite
fill 336 65 181 337 65 181 minecraft:bone_block
setblock 336 65 223 minecraft:bone_block
fill 337 65 223 338 65 223 minecraft:calcite
fill 338 65 181 343 65 181 minecraft:calcite
setblock 340 65 184 minecraft:light[level=12]
setblock 340 65 192 minecraft:light[level=12]
setblock 340 65 200 minecraft:light[level=12]
setblock 340 65 208 minecraft:light[level=12]
setblock 340 65 216 minecraft:light[level=12]
fill 341 65 223 346 65 223 minecraft:calcite
fill 346 65 181 350 65 181 minecraft:calcite
setblock 347 65 223 minecraft:bone_block
setblock 348 65 184 minecraft:light[level=12]
setblock 348 65 192 minecraft:light[level=12]
setblock 348 65 200 minecraft:light[level=12]
setblock 348 65 208 minecraft:light[level=12]
setblock 348 65 216 minecraft:light[level=12]
fill 349 65 223 358 65 223 minecraft:calcite
fill 352 65 181 355 65 181 minecraft:calcite
setblock 356 65 184 minecraft:light[level=12]
setblock 356 65 192 minecraft:light[level=12]
setblock 356 65 200 minecraft:light[level=12]
setblock 356 65 208 minecraft:light[level=12]
setblock 356 65 216 minecraft:light[level=12]
setblock 357 65 181 minecraft:bone_block
fill 358 65 181 363 65 181 minecraft:calcite
fill 361 65 223 362 69 223 minecraft:calcite
setblock 363 65 223 minecraft:smooth_basalt
setblock 364 65 184 minecraft:light[level=12]
setblock 364 65 192 minecraft:light[level=12]
setblock 364 65 200 minecraft:light[level=12]
setblock 364 65 208 minecraft:light[level=12]
setblock 364 65 216 minecraft:light[level=12]
fill 364 65 223 367 65 223 minecraft:calcite
fill 366 65 181 367 65 181 minecraft:calcite
setblock 368 65 181 minecraft:bone_block
setblock 368 65 223 minecraft:bone_block
fill 369 65 181 371 65 181 minecraft:calcite
fill 369 65 223 370 65 223 minecraft:calcite
fill 371 65 183 371 65 185 minecraft:calcite
fill 371 65 188 371 65 194 minecraft:calcite
setblock 371 65 195 minecraft:bone_block
setblock 371 65 197 minecraft:calcite
fill 371 65 198 371 65 199 minecraft:bone_block
fill 371 65 200 371 65 205 minecraft:calcite
fill 371 65 208 371 65 212 minecraft:calcite
fill 371 65 214 371 67 214 minecraft:calcite
setblock 371 65 215 minecraft:smooth_basalt
fill 371 65 216 371 69 216 minecraft:calcite
setblock 371 65 217 minecraft:smooth_basalt
setblock 371 65 219 minecraft:bone_block
fill 371 65 220 371 65 222 minecraft:calcite
fill 329 66 181 329 68 183 minecraft:calcite
fill 329 66 184 329 66 185 minecraft:smooth_basalt
fill 329 66 186 329 67 186 minecraft:calcite
fill 329 66 187 329 67 188 minecraft:bone_block
setblock 329 66 189 minecraft:smooth_basalt
fill 329 66 190 329 71 190 minecraft:calcite
fill 329 66 192 329 67 194 minecraft:calcite
setblock 329 66 195 minecraft:smooth_basalt
setblock 329 66 196 minecraft:calcite
setblock 329 66 197 minecraft:smooth_basalt
setblock 329 66 198 minecraft:calcite
fill 329 66 199 329 66 200 minecraft:bone_block
fill 329 66 201 329 71 201 minecraft:calcite
setblock 329 66 202 minecraft:smooth_basalt
fill 329 66 203 329 66 204 minecraft:calcite
setblock 329 66 205 minecraft:smooth_basalt
fill 329 66 206 329 66 207 minecraft:calcite
fill 329 66 208 329 67 208 minecraft:bone_block
fill 329 66 209 329 71 210 minecraft:calcite
setblock 329 66 211 minecraft:bone_block
fill 329 66 213 329 71 213 minecraft:calcite
setblock 329 66 218 minecraft:calcite
fill 329 66 219 329 67 220 minecraft:bone_block
fill 329 66 221 329 69 223 minecraft:calcite
fill 330 66 182 332 66 182 minecraft:polished_basalt
fill 330 66 184 330 66 186 minecraft:polished_basalt
fill 330 66 188 330 66 190 minecraft:polished_basalt
fill 330 66 192 330 66 194 minecraft:polished_basalt
fill 330 66 196 330 66 198 minecraft:polished_basalt
fill 330 66 200 330 66 202 minecraft:polished_basalt
fill 330 66 204 330 66 206 minecraft:polished_basalt
fill 330 66 208 330 66 210 minecraft:polished_basalt
fill 330 66 212 330 66 214 minecraft:polished_basalt
fill 330 66 216 330 66 218 minecraft:polished_basalt
fill 330 66 220 330 66 222 minecraft:polished_basalt
fill 332 66 222 334 66 222 minecraft:polished_basalt
fill 333 66 181 334 69 181 minecraft:calcite
fill 334 66 182 336 66 182 minecraft:polished_basalt
setblock 335 66 181 minecraft:bone_block
fill 336 66 181 337 66 181 minecraft:calcite
fill 336 66 222 338 66 222 minecraft:polished_basalt
fill 336 66 223 336 71 223 minecraft:calcite
fill 337 66 223 338 66 223 minecraft:bone_block
fill 338 66 181 338 67 181 minecraft:bone_block
fill 338 66 182 340 66 182 minecraft:polished_basalt
fill 339 66 181 340 66 181 minecraft:calcite
fill 339 66 223 344 67 223 minecraft:calcite
fill 340 66 222 342 66 222 minecraft:polished_basalt
setblock 341 66 181 minecraft:smooth_basalt
fill 342 66 181 342 69 181 minecraft:calcite
fill 342 66 182 344 66 182 minecraft:polished_basalt
setblock 343 66 181 minecraft:smooth_basalt
fill 344 66 181 345 71 181 minecraft:calcite
fill 344 66 222 346 66 222 minecraft:polished_basalt
fill 345 66 223 346 67 223 minecraft:bone_block
fill 346 66 181 347 66 181 minecraft:bone_block
fill 346 66 182 348 66 182 minecraft:polished_basalt
fill 347 66 223 348 66 223 minecraft:calcite
fill 348 66 181 349 67 181 minecraft:calcite
fill 348 66 222 350 66 222 minecraft:polished_basalt
setblock 349 66 223 minecraft:bone_block
setblock 350 66 181 minecraft:smooth_basalt
fill 350 66 182 352 66 182 minecraft:polished_basalt
fill 350 66 223 356 66 223 minecraft:calcite
fill 351 66 181 354 66 181 minecraft:calcite
fill 352 66 222 354 66 222 minecraft:polished_basalt
fill 354 66 182 356 66 182 minecraft:polished_basalt
setblock 355 66 181 minecraft:bone_block
fill 356 66 181 357 71 181 minecraft:calcite
fill 356 66 222 358 66 222 minecraft:polished_basalt
fill 357 66 223 358 67 223 minecraft:bone_block
fill 358 66 181 359 67 181 minecraft:bone_block
fill 358 66 182 360 66 182 minecraft:polished_basalt
fill 359 66 223 360 71 223 minecraft:calcite
fill 360 66 181 365 66 181 minecraft:calcite
fill 360 66 222 362 66 222 minecraft:polished_basalt
fill 362 66 182 364 66 182 minecraft:polished_basalt
fill 363 66 223 365 66 223 minecraft:calcite
fill 364 66 222 366 66 222 minecraft:polished_basalt
fill 366 66 181 367 66 181 minecraft:bone_block
fill 366 66 182 368 66 182 minecraft:polished_basalt
fill 366 66 223 366 67 223 minecraft:bone_block
fill 367 66 223 368 66 223 minecraft:calcite
fill 368 66 181 369 67 181 minecraft:calcite
fill 368 66 222 370 66 222 minecraft:polished_basalt
fill 369 66 223 370 66 223 minecraft:bone_block
fill 370 66 181 370 67 181 minecraft:bone_block
fill 370 66 182 370 66 184 minecraft:polished_basalt
fill 370 66 186 370 66 188 minecraft:polished_basalt
fill 370 66 190 370 66 192 minecraft:polished_basalt
fill 370 66 194 370 66 196 minecraft:polished_basalt
fill 370 66 198 370 66 200 minecraft:polished_basalt
fill 370 66 202 370 66 204 minecraft:polished_basalt
fill 370 66 206 370 66 208 minecraft:polished_basalt
fill 370 66 210 370 66 212 minecraft:polished_basalt
fill 370 66 214 370 66 216 minecraft:polished_basalt
fill 370 66 218 370 66 220 minecraft:polished_basalt
fill 371 66 181 371 66 182 minecraft:calcite
setblock 371 66 183 minecraft:smooth_basalt
fill 371 66 184 371 66 187 minecraft:calcite
fill 371 66 188 371 67 189 minecraft:bone_block
fill 371 66 190 371 66 195 minecraft:calcite
setblock 371 66 197 minecraft:bone_block
fill 371 66 198 371 71 199 minecraft:calcite
fill 371 66 200 371 67 200 minecraft:bone_block
fill 371 66 201 371 66 202 minecraft:smooth_basalt
fill 371 66 203 371 66 205 minecraft:calcite
setblock 371 66 206 minecraft:smooth_basalt
fill 371 66 207 371 71 207 minecraft:calcite
fill 371 66 208 371 66 209 minecraft:bone_block
setblock 371 66 210 minecraft:smooth_basalt
fill 371 66 211 371 66 213 minecraft:calcite
setblock 371 66 215 minecraft:calcite
fill 371 66 217 371 66 219 minecraft:calcite
fill 371 66 220 371 67 221 minecraft:bone_block
fill 371 66 222 371 67 223 minecraft:calcite
fill 329 67 184 329 67 185 minecraft:calcite
fill 329 67 189 329 71 189 minecraft:calcite
fill 329 67 195 329 69 195 minecraft:calcite
setblock 329 67 196 minecraft:bone_block
setblock 329 67 197 minecraft:calcite
setblock 329 67 198 minecraft:smooth_basalt
setblock 329 67 199 minecraft:bone_block
fill 329 67 200 329 70 200 minecraft:calcite
fill 329 67 202 329 69 203 minecraft:calcite
setblock 329 67 204 minecraft:smooth_basalt
setblock 329 67 205 minecraft:calcite
setblock 329 67 206 minecraft:smooth_basalt
setblock 329 67 207 minecraft:bone_block
fill 329 67 211 329 70 211 minecraft:calcite
setblock 329 67 218 minecraft:smooth_basalt
setblock 330 67 223 minecraft:smooth_basalt
fill 331 67 223 332 67 223 minecraft:calcite
fill 333 67 223 334 67 223 minecraft:bone_block
fill 335 67 181 335 70 181 minecraft:calcite
setblock 335 67 223 minecraft:calcite
setblock 336 67 181 minecraft:smooth_basalt
fill 337 67 181 337 71 181 minecraft:calcite
setblock 337 67 223 minecraft:bone_block
fill 338 67 223 338 70 223 minecraft:calcite
setblock 339 67 181 minecraft:bone_block
fill 340 67 181 341 67 181 minecraft:calcite
fill 343 67 181 343 69 181 minecraft:calcite
fill 346 67 181 346 70 181 minecraft:calcite
setblock 347 67 181 minecraft:bone_block
setblock 347 67 223 minecraft:smooth_basalt
fill 348 67 223 353 68 223 minecraft:calcite
setblock 350 67 181 minecraft:bone_block
fill 351 67 181 352 67 181 minecraft:calcite
setblock 353 67 181 minecraft:smooth_basalt
fill 354 67 181 355 69 181 minecraft:calcite
setblock 354 67 223 minecraft:bone_block
fill 355 67 223 356 67 223 minecraft:calcite
setblock 360 67 181 minecraft:smooth_basalt
fill 361 67 181 366 67 181 minecraft:calcite
fill 363 67 223 364 67 223 minecraft:calcite
setblock 365 67 223 minecraft:bone_block
setblock 367 67 181 minecraft:bone_block
setblock 367 67 223 minecraft:smooth_basalt
fill 368 67 223 370 70 223 minecraft:calcite
setblock 371 67 181 minecraft:bone_block
fill 371 67 182 371 67 183 minecraft:calcite
setblock 371 67 184 minecraft:smooth_basalt
fill 371 67 185 371 69 187 minecraft:calcite
fill 371 67 190 371 67 191 minecraft:calcite
setblock 371 67 192 minecraft:bone_block
fill 371 67 193 371 68 197 minecraft:calcite
setblock 371 67 201 minecraft:bone_block
setblock 371 67 202 minecraft:smooth_basalt
setblock 371 67 203 minecraft:calcite
setblock 371 67 204 minecraft:smooth_basalt
fill 371 67 205 371 69 206 minecraft:calcite
fill 371 67 208 371 70 208 minecraft:calcite
setblock 371 67 209 minecraft:bone_block
setblock 371 67 210 minecraft:calcite
setblock 371 67 211 minecraft:smooth_basalt
setblock 371 67 212 minecraft:bone_block
fill 371 67 213 371 69 213 minecraft:calcite
setblock 371 67 215 minecraft:smooth_basalt
setblock 371 67 217 minecraft:smooth_basalt
fill 371 67 218 371 71 219 minecraft:calcite
fill 329 68 184 329 69 184 minecraft:calcite
fill 329 68 185 329 69 186 minecraft:bone_block
fill 329 68 187 329 73 188 minecraft:calcite
fill 329 68 192 329 68 193 minecraft:calcite
fill 329 68 194 329 69 194 minecraft:bone_block
fill 329 68 196 329 73 196 minecraft:calcite
fill 329 68 197 329 68 198 minecraft:bone_block
fill 329 68 199 329 73 199 minecraft:calcite
fill 329 68 204 329 69 204 minecraft:calcite
fill 329 68 205 329 69 206 minecraft:bone_block
fill 329 68 207 329 73 208 minecraft:calcite
fill 329 68 214 329 68 216 minecraft:calcite
fill 329 68 217 329 68 218 minecraft:bone_block
fill 329 68 219 329 73 220 minecraft:calcite
fill 330 68 223 331 68 223 minecraft:calcite
fill 332 68 223 332 69 223 minecraft:bone_block
fill 333 68 223 334 73 223 minecraft:calcite
setblock 335 68 223 minecraft:bone_block
fill 336 68 181 336 71 181 minecraft:calcite
fill 337 68 223 337 73 223 minecraft:calcite
fill 338 68 181 339 73 181 minecraft:calcite
fill 339 68 223 342 69 223 minecraft:calcite
fill 340 68 181 341 69 181 minecraft:bone_block
fill 343 68 223 344 69 223 minecraft:bone_block
fill 345 68 223 347 71 223 minecraft:calcite
fill 347 68 181 347 73 181 minecraft:calcite
fill 348 68 181 349 68 181 minecraft:bone_block
fill 350 68 181 351 69 181 minecraft:calcite
fill 352 68 181 352 69 181 minecraft:bone_block
setblock 353 68 181 minecraft:calcite
fill 354 68 223 354 73 223 minecraft:calcite
fill 355 68 223 356 68 223 minecraft:bone_block
fill 357 68 223 358 73 223 minecraft:calcite
fill 358 68 181 359 73 181 minecraft:calcite
fill 360 68 181 361 69 181 minecraft:bone_block
fill 362 68 181 368 68 181 minecraft:calcite
fill 363 68 223 364 69 223 minecraft:bone_block
fill 365 68 223 366 73 223 minecraft:calcite
setblock 367 68 223 minecraft:bone_block
setblock 369 68 181 minecraft:bone_block
fill 370 68 181 371 73 181 minecraft:calcite
fill 371 68 182 371 69 183 minecraft:bone_block
fill 371 68 184 371 69 184 minecraft:calcite
fill 371 68 188 371 73 189 minecraft:calcite
fill 371 68 190 371 68 191 minecraft:bone_block
fill 371 68 192 371 69 192 minecraft:calcite
fill 371 68 200 371 73 201 minecraft:calcite
fill 371 68 202 371 69 203 minecraft:bone_block
fill 371 68 204 371 69 204 minecraft:calcite
fill 371 68 209 371 73 209 minecraft:calcite
fill 371 68 210 371 68 211 minecraft:bone_block
fill 371 68 212 371 73 212 minecraft:calcite
fill 371 68 214 371 69 214 minecraft:bone_block
setblock 371 68 215 minecraft:calcite
fill 371 68 217 371 69 217 minecraft:calcite
fill 371 68 220 371 73 221 minecraft:calcite
fill 371 68 222 371 69 222 minecraft:bone_block
fill 371 68 223 371 71 223 minecraft:calcite
fill 329 69 181 331 69 181 minecraft:calcite
setblock 329 69 182 minecraft:bone_block
setblock 329 69 183 minecraft:calcite
setblock 329 69 192 minecraft:calcite
setblock 329 69 193 minecraft:bone_block
fill 329 69 197 329 72 198 minecraft:calcite
setblock 329 69 214 minecraft:bone_block
fill 329 69 215 329 69 216 minecraft:calcite
setblock 329 69 217 minecraft:bone_block
fill 329 69 218 329 72 218 minecraft:calcite
setblock 330 69 223 minecraft:calcite
setblock 331 69 223 minecraft:bone_block
setblock 332 69 181 minecraft:bone_block
fill 335 69 223 335 72 223 minecraft:calcite
fill 348 69 181 349 72 181 minecraft:calcite
fill 348 69 223 350 69 223 minecraft:calcite
fill 351 69 223 352 69 223 minecraft:bone_block
setblock 353 69 181 minecraft:bone_block
setblock 353 69 223 minecraft:calcite
setblock 355 69 223 minecraft:bone_block
fill 356 69 223 356 72 223 minecraft:calcite
fill 362 69 181 363 69 181 minecraft:calcite
setblock 364 69 181 minecraft:bone_block
fill 365 69 181 369 70 181 minecraft:calcite
fill 366 69 199 367 70 200 minecraft:bone_block
fill 367 69 223 367 72 223 minecraft:calcite
fill 371 69 190 371 72 190 minecraft:calcite
setblock 371 69 191 minecraft:bone_block
setblock 371 69 193 minecraft:calcite
fill 371 69 194 371 69 195 minecraft:bone_block
fill 371 69 196 371 69 197 minecraft:calcite
fill 371 69 210 371 72 211 minecraft:calcite
setblock 371 69 215 minecraft:bone_block
fill 329 70 181 329 71 182 minecraft:calcite
fill 329 70 183 329 70 184 minecraft:bone_block
fill 329 70 185 329 75 186 minecraft:calcite
fill 329 70 191 329 71 192 minecraft:bone_block
fill 329 70 193 329 75 194 minecraft:calcite
setblock 329 70 195 minecraft:bone_block
fill 329 70 202 329 71 202 minecraft:calcite
fill 329 70 203 329 71 204 minecraft:bone_block
fill 329 70 205 329 75 206 minecraft:calcite
fill 329 70 212 329 71 212 minecraft:bone_block
fill 329 70 214 329 75 214 minecraft:calcite
fill 329 70 215 329 70 216 minecraft:bone_block
fill 329 70 217 329 75 217 minecraft:calcite
fill 329 70 221 329 71 222 minecraft:calcite
fill 329 70 223 330 71 223 minecraft:bone_block
fill 330 70 181 331 70 181 minecraft:bone_block
fill 331 70 223 332 75 223 minecraft:calcite
fill 332 70 181 333 71 181 minecraft:calcite
fill 334 70 181 334 71 181 minecraft:bone_block
fill 339 70 223 340 71 223 minecraft:calcite
fill 340 70 181 341 75 181 minecraft:calcite
fill 341 70 223 342 70 223 minecraft:bone_block
fill 342 70 181 343 71 181 minecraft:bone_block
fill 343 70 223 344 75 223 minecraft:calcite
fill 348 70 223 349 70 223 minecraft:calcite
fill 350 70 181 350 73 181 minecraft:calcite
fill 350 70 223 350 71 223 minecraft:bone_block
setblock 351 70 181 minecraft:bone_block
fill 351 70 223 352 75 223 minecraft:calcite
fill 352 70 181 353 75 181 minecraft:calcite
setblock 353 70 223 minecraft:bone_block
fill 354 70 181 355 71 181 minecraft:bone_block
fill 355 70 223 355 75 223 minecraft:calcite
fill 360 70 181 361 75 181 minecraft:calcite
fill 361 70 223 362 71 223 minecraft:bone_block
fill 362 70 181 363 70 181 minecraft:bone_block
fill 363 70 223 364 75 223 minecraft:calcite
fill 364 70 181 364 71 181 minecraft:calcite
fill 371 70 182 371 75 183 minecraft:calcite
fill 371 70 184 371 71 185 minecraft:bone_block
fill 371 70 186 371 71 187 minecraft:calcite
fill 371 70 191 371 75 191 minecraft:calcite
fill 371 70 192 371 70 193 minecraft:bone_block
fill 371 70 194 371 71 195 minecraft:calcite
fill 371 70 196 371 71 196 minecraft:bone_block
setblock 371 70 197 minecraft:calcite
fill 371 70 202 371 75 203 minecraft:calcite
fill 371 70 204 371 71 205 minecraft:bone_block
fill 371 70 206 371 71 206 minecraft:calcite
setblock 371 70 213 minecraft:bone_block
fill 371 70 214 371 75 215 minecraft:calcite
fill 371 70 216 371 71 217 minecraft:bone_block
fill 371 70 222 371 75 222 minecraft:calcite
setblock 329 71 183 minecraft:bone_block
fill 329 71 184 329 74 184 minecraft:calcite
fill 329 71 195 329 74 195 minecraft:calcite
setblock 329 71 200 minecraft:bone_block
setblock 329 71 211 minecraft:bone_block
fill 329 71 215 329 74 216 minecraft:calcite
fill 330 71 181 331 74 181 minecraft:calcite
setblock 335 71 181 minecraft:bone_block
setblock 338 71 223 minecraft:bone_block
setblock 341 71 223 minecraft:bone_block
fill 342 71 223 342 74 223 minecraft:calcite
setblock 346 71 181 minecraft:bone_block
setblock 348 71 223 minecraft:calcite
setblock 349 71 223 minecraft:bone_block
fill 351 71 181 351 74 181 minecraft:calcite
fill 353 71 223 353 74 223 minecraft:calcite
fill 362 71 181 362 74 181 minecraft:calcite
setblock 363 71 181 minecraft:bone_block
setblock 365 71 181 minecraft:calcite
fill 366 71 181 367 71 181 minecraft:bone_block
fill 368 71 181 369 71 181 minecraft:calcite
setblock 368 71 223 minecraft:calcite
fill 369 71 223 370 71 223 minecraft:bone_block
fill 371 71 192 371 73 193 minecraft:calcite
setblock 371 71 197 minecraft:bone_block
setblock 371 71 208 minecraft:bone_block
fill 371 71 213 371 74 213 minecraft:calcite
setblock 329 72 181 minecraft:bone_block
fill 329 72 182 329 75 183 minecraft:calcite
fill 329 72 189 329 73 190 minecraft:bone_block
fill 329 72 191 329 77 192 minecraft:calcite
fill 329 72 200 329 77 200 minecraft:calcite
fill 329 72 201 329 72 202 minecraft:bone_block
fill 329 72 203 329 77 204 minecraft:calcite
fill 329 72 209 329 73 210 minecraft:bone_block
fill 329 72 211 329 77 212 minecraft:calcite
setblock 329 72 213 minecraft:bone_block
fill 329 72 221 329 73 222 minecraft:bone_block
fill 329 72 223 330 77 223 minecraft:calcite
fill 330 72 182 332 72 182 minecraft:polished_basalt
fill 330 72 184 330 72 186 minecraft:polished_basalt
fill 330 72 188 330 72 190 minecraft:polished_basalt
fill 330 72 192 330 72 194 minecraft:polished_basalt
fill 330 72 196 330 72 198 minecraft:polished_basalt
fill 330 72 200 330 72 202 minecraft:polished_basalt
fill 330 72 204 330 72 206 minecraft:polished_basalt
fill 330 72 208 330 72 210 minecraft:polished_basalt
fill 330 72 212 330 72 214 minecraft:polished_basalt
fill 330 72 216 330 72 218 minecraft:polished_basalt
fill 330 72 220 330 72 222 minecraft:polished_basalt
fill 332 72 181 332 75 181 minecraft:calcite
fill 332 72 222 334 72 222 minecraft:polished_basalt
setblock 333 72 181 minecraft:bone_block
fill 334 72 181 335 77 181 minecraft:calcite
fill 334 72 182 336 72 182 minecraft:polished_basalt
fill 336 72 181 337 73 181 minecraft:bone_block
fill 336 72 222 338 72 222 minecraft:polished_basalt
fill 336 72 223 336 73 223 minecraft:bone_block
fill 338 72 182 340 72 182 minecraft:polished_basalt
fill 338 72 223 338 77 223 minecraft:calcite
fill 339 72 223 340 72 223 minecraft:bone_block
fill 340 72 222 342 72 222 minecraft:polished_basalt
fill 341 72 223 341 77 223 minecraft:calcite
fill 342 72 181 343 77 181 minecraft:calcite
fill 342 72 182 344 72 182 minecraft:polished_basalt
fill 344 72 181 345 72 181 minecraft:bone_block
fill 344 72 222 346 72 222 minecraft:polished_basalt
fill 345 72 223 346 73 223 minecraft:calcite
fill 346 72 181 346 77 181 minecraft:calcite
fill 346 72 182 348 72 182 minecraft:polished_basalt
fill 347 72 223 348 73 223 minecraft:bone_block
fill 348 72 222 350 72 222 minecraft:polished_basalt
fill 349 72 223 350 77 223 minecraft:calcite
fill 350 72 182 352 72 182 minecraft:polished_basalt
fill 352 72 222 354 72 222 minecraft:polished_basalt
fill 354 72 181 355 77 181 minecraft:calcite
fill 354 72 182 356 72 182 minecraft:polished_basalt
fill 356 72 181 357 73 181 minecraft:bone_block
fill 356 72 222 358 72 222 minecraft:polished_basalt
fill 358 72 182 360 72 182 minecraft:polished_basalt
fill 359 72 223 360 72 223 minecraft:bone_block
fill 360 72 222 362 72 222 minecraft:polished_basalt
fill 361 72 223 362 77 223 minecraft:calcite
fill 362 72 182 364 72 182 minecraft:polished_basalt
fill 363 72 181 363 77 181 minecraft:calcite
fill 364 72 181 365 72 181 minecraft:bone_block
fill 364 72 222 366 72 222 minecraft:polished_basalt
fill 366 72 181 367 73 181 minecraft:calcite
fill 366 72 182 368 72 182 minecraft:polished_basalt
fill 368 72 181 368 73 181 minecraft:bone_block
fill 368 72 222 370 72 222 minecraft:polished_basalt
fill 368 72 223 368 73 223 minecraft:bone_block
setblock 369 72 181 minecraft:calcite
fill 369 72 223 370 77 223 minecraft:calcite
fill 370 72 182 370 72 184 minecraft:polished_basalt
fill 370 72 186 370 72 188 minecraft:polished_basalt
fill 370 72 190 370 72 192 minecraft:polished_basalt
fill 370 72 194 370 72 196 minecraft:polished_basalt
fill 370 72 198 370 72 200 minecraft:polished_basalt
fill 370 72 202 370 72 204 minecraft:polished_basalt
fill 370 72 206 370 72 208 minecraft:polished_basalt
fill 370 72 210 370 72 212 minecraft:polished_basalt
fill 370 72 214 370 72 216 minecraft:polished_basalt
fill 370 72 218 370 72 220 minecraft:polished_basalt
fill 371 72 184 371 77 185 minecraft:calcite
fill 371 72 186 371 73 187 minecraft:bone_block
fill 371 72 194 371 75 194 minecraft:calcite
setblock 371 72 195 minecraft:bone_block
fill 371 72 196 371 77 197 minecraft:calcite
fill 371 72 198 371 73 199 minecraft:bone_block
fill 371 72 204 371 74 205 minecraft:calcite
fill 371 72 206 371 72 207 minecraft:bone_block
fill 371 72 208 371 77 208 minecraft:calcite
fill 371 72 216 371 77 217 minecraft:calcite
fill 371 72 218 371 73 219 minecraft:bone_block
setblock 371 72 223 minecraft:bone_block
fill 329 73 181 329 76 181 minecraft:calcite
fill 329 73 197 329 73 198 minecraft:bone_block
setblock 329 73 201 minecraft:bone_block
fill 329 73 202 329 76 202 minecraft:calcite
fill 329 73 213 329 76 213 minecraft:calcite
setblock 329 73 218 minecraft:bone_block
setblock 332 73 184 minecraft:light[level=12]
setblock 332 73 192 minecraft:light[level=12]
setblock 332 73 200 minecraft:light[level=12]
setblock 332 73 208 minecraft:light[level=12]
setblock 332 73 216 minecraft:light[level=12]
fill 333 73 181 333 76 181 minecraft:calcite
setblock 335 73 223 minecraft:bone_block
fill 339 73 223 340 76 223 minecraft:calcite
setblock 340 73 184 minecraft:light[level=12]
setblock 340 73 192 minecraft:light[level=12]
setblock 340 73 200 minecraft:light[level=12]
setblock 340 73 208 minecraft:light[level=12]
setblock 340 73 216 minecraft:light[level=12]
fill 344 73 181 344 76 181 minecraft:calcite
setblock 345 73 181 minecraft:bone_block
fill 348 73 181 349 73 181 minecraft:bone_block
setblock 348 73 184 minecraft:light[level=12]
setblock 348 73 192 minecraft:light[level=12]
setblock 348 73 200 minecraft:light[level=12]
setblock 348 73 208 minecraft:light[level=12]
setblock 348 73 216 minecraft:light[level=12]
setblock 356 73 184 minecraft:light[level=12]
setblock 356 73 192 minecraft:light[level=12]
setblock 356 73 200 minecraft:light[level=12]
setblock 356 73 208 minecraft:light[level=12]
setblock 356 73 216 minecraft:light[level=12]
setblock 356 73 223 minecraft:bone_block
setblock 359 73 223 minecraft:bone_block
fill 360 73 223 360 76 223 minecraft:calcite
fill 364 73 181 365 75 181 minecraft:calcite
setblock 364 73 184 minecraft:light[level=12]
setblock 364 73 192 minecraft:light[level=12]
setblock 364 73 200 minecraft:light[level=12]
setblock 364 73 208 minecraft:light[level=12]
setblock 364 73 216 minecraft:light[level=12]
setblock 367 73 223 minecraft:bone_block
setblock 369 73 181 minecraft:bone_block
setblock 371 73 190 minecraft:bone_block
fill 371 73 195 371 75 195 minecraft:calcite
fill 371 73 206 371 76 206 minecraft:calcite
setblock 371 73 207 minecraft:bone_block
fill 371 73 210 371 73 211 minecraft:bone_block
fill 371 73 223 371 76 223 minecraft:calcite
fill 329 74 187 329 74 188 minecraft:bone_block
fill 329 74 189 329 79 190 minecraft:calcite
fill 329 74 196 329 75 196 minecraft:bone_block
fill 329 74 197 329 79 198 minecraft:calcite
setblock 329 74 199 minecraft:bone_block
fill 329 74 201 329 79 201 minecraft:calcite
fill 329 74 207 329 75 208 minecraft:bone_block
fill 329 74 209 329 79 210 minecraft:calcite
fill 329 74 218 329 79 218 minecraft:calcite
fill 329 74 219 329 74 220 minecraft:bone_block
fill 329 74 221 329 79 222 minecraft:calcite
fill 333 74 223 334 75 223 minecraft:bone_block
fill 335 74 223 336 79 223 minecraft:calcite
fill 336 74 181 337 79 181 minecraft:calcite
setblock 337 74 223 minecraft:bone_block
fill 338 74 181 339 75 181 minecraft:bone_block
fill 345 74 181 345 79 181 minecraft:calcite
fill 345 74 223 346 75 223 minecraft:bone_block
setblock 347 74 181 minecraft:bone_block
fill 347 74 223 348 79 223 minecraft:calcite
fill 348 74 181 349 79 181 minecraft:calcite
fill 350 74 181 350 75 181 minecraft:bone_block
fill 354 74 223 354 75 223 minecraft:bone_block
fill 356 74 181 357 79 181 minecraft:calcite
fill 356 74 223 356 79 223 minecraft:calcite
fill 357 74 223 358 74 223 minecraft:bone_block
fill 358 74 181 359 74 181 minecraft:bone_block
fill 359 74 223 359 79 223 minecraft:calcite
fill 365 74 223 366 75 223 minecraft:bone_block
fill 366 74 181 366 77 181 minecraft:calcite
setblock 367 74 181 minecraft:bone_block
fill 367 74 223 368 79 223 minecraft:calcite
fill 368 74 181 369 79 181 minecraft:calcite
fill 370 74 181 371 75 181 minecraft:bone_block
fill 371 74 186 371 76 187 minecraft:calcite
fill 371 74 188 371 74 189 minecraft:bone_block
fill 371 74 190 371 79 190 minecraft:calcite
fill 371 74 192 371 75 192 minecraft:bone_block
setblock 371 74 193 minecraft:calcite
fill 371 74 198 371 79 199 minecraft:calcite
fill 371 74 200 371 75 201 minecraft:bone_block
fill 371 74 207 371 76 207 minecraft:calcite
setblock 371 74 209 minecraft:bone_block
fill 371 74 210 371 79 211 minecraft:calcite
fill 371 74 212 371 75 212 minecraft:bone_block
fill 371 74 218 371 79 219 minecraft:calcite
fill 371 74 220 371 74 221 minecraft:bone_block
setblock 329 75 184 minecraft:bone_block
setblock 329 75 187 minecraft:bone_block
fill 329 75 188 329 78 188 minecraft:calcite
setblock 329 75 195 minecraft:bone_block
fill 329 75 199 329 78 199 minecraft:calcite
fill 329 75 215 329 75 216 minecraft:bone_block
setblock 329 75 219 minecraft:bone_block
fill 329 75 220 329 78 220 minecraft:calcite
fill 330 75 181 331 75 181 minecraft:bone_block
fill 337 75 223 337 78 223 minecraft:calcite
setblock 342 75 223 minecraft:bone_block
fill 347 75 181 347 78 181 minecraft:calcite
setblock 351 75 181 minecraft:bone_block
setblock 353 75 223 minecraft:bone_block
fill 357 75 223 358 78 223 minecraft:calcite
fill 358 75 181 358 78 181 minecraft:calcite
setblock 359 75 181 minecraft:bone_block
setblock 362 75 181 minecraft:bone_block
fill 367 75 181 367 77 181 minecraft:calcite
fill 371 75 188 371 78 188 minecraft:calcite
setblock 371 75 189 minecraft:bone_block
setblock 371 75 193 minecraft:bone_block
setblock 371 75 204 minecraft:bone_block
fill 371 75 205 371 77 205 minecraft:calcite
fill 371 75 209 371 78 209 minecraft:calcite
setblock 371 75 213 minecraft:bone_block
fill 371 75 220 371 78 220 minecraft:calcite
setblock 371 75 221 minecraft:bone_block
fill 329 76 182 329 77 182 minecraft:bone_block
fill 329 76 183 329 77 184 minecraft:calcite
fill 329 76 185 329 76 186 minecraft:bone_block
fill 329 76 187 329 81 187 minecraft:calcite
fill 329 76 193 329 77 194 minecraft:bone_block
fill 329 76 195 329 81 196 minecraft:calcite
fill 329 76 205 329 76 206 minecraft:bone_block
fill 329 76 207 329 81 208 minecraft:calcite
fill 329 76 214 329 77 214 minecraft:bone_block
fill 329 76 215 329 81 216 minecraft:calcite
setblock 329 76 217 minecraft:bone_block
fill 329 76 219 329 81 219 minecraft:calcite
fill 330 76 181 331 81 181 minecraft:calcite
fill 331 76 223 332 77 223 minecraft:bone_block
fill 332 76 181 332 77 181 minecraft:bone_block
fill 333 76 223 334 81 223 minecraft:calcite
fill 338 76 181 339 81 181 minecraft:calcite
fill 340 76 181 341 76 181 minecraft:bone_block
fill 342 76 223 342 81 223 minecraft:calcite
fill 343 76 223 344 76 223 minecraft:bone_block
fill 345 76 223 346 81 223 minecraft:calcite
fill 350 76 181 351 81 181 minecraft:calcite
fill 351 76 223 352 77 223 minecraft:bone_block
fill 352 76 181 353 77 181 minecraft:bone_block
fill 353 76 223 354 81 223 minecraft:calcite
setblock 355 76 223 minecraft:bone_block
fill 359 76 181 359 81 181 minecraft:calcite
fill 360 76 181 361 76 181 minecraft:bone_block
fill 362 76 181 362 81 181 minecraft:calcite
fill 363 76 223 364 77 223 minecraft:bone_block
fill 364 76 181 364 77 181 minecraft:bone_block
setblock 365 76 181 minecraft:calcite
fill 365 76 223 366 81 223 minecraft:calcite
fill 370 76 181 371 81 181 minecraft:calcite
fill 371 76 182 371 77 183 minecraft:bone_block
fill 371 76 189 371 78 189 minecraft:calcite
setblock 371 76 191 minecraft:bone_block
fill 371 76 192 371 81 193 minecraft:calcite
fill 371 76 194 371 77 195 minecraft:bone_block
fill 371 76 200 371 81 201 minecraft:calcite
fill 371 76 202 371 76 203 minecraft:bone_block
fill 371 76 204 371 77 204 minecraft:calcite
fill 371 76 212 371 81 213 minecraft:calcite
fill 371 76 214 371 77 215 minecraft:bone_block
fill 371 76 221 371 81 221 minecraft:calcite
setblock 371 76 222 minecraft:bone_block
setblock 329 77 181 minecraft:bone_block
fill 329 77 185 329 80 186 minecraft:calcite
setblock 329 77 202 minecraft:bone_block
setblock 329 77 205 minecraft:bone_block
fill 329 77 206 329 80 206 minecraft:calcite
setblock 329 77 213 minecraft:bone_block
fill 329 77 217 329 80 217 minecraft:calcite
setblock 333 77 181 minecraft:bone_block
fill 339 77 223 340 77 223 minecraft:bone_block
fill 340 77 181 340 80 181 minecraft:calcite
setblock 341 77 181 minecraft:bone_block
setblock 343 77 223 minecraft:bone_block
setblock 344 77 181 minecraft:bone_block
fill 344 77 223 344 80 223 minecraft:calcite
fill 355 77 223 355 80 223 minecraft:calcite
fill 357 77 217 358 78 217 minecraft:calcite
fill 360 77 181 361 80 181 minecraft:calcite
setblock 360 77 223 minecraft:bone_block
setblock 365 77 181 minecraft:bone_block
setblock 371 77 186 minecraft:bone_block
fill 371 77 187 371 79 187 minecraft:calcite
fill 371 77 191 371 80 191 minecraft:calcite
fill 371 77 202 371 80 202 minecraft:calcite
setblock 371 77 203 minecraft:bone_block
fill 371 77 206 371 77 207 minecraft:bone_block
fill 371 77 222 371 80 222 minecraft:calcite
setblock 371 77 223 minecraft:bone_block
fill 329 78 181 329 83 182 minecraft:calcite
setblock 329 78 183 minecraft:bone_block
fill 329 78 184 329 81 184 minecraft:calcite
fill 329 78 191 329 79 192 minecraft:bone_block
fill 329 78 193 329 83 194 minecraft:calcite
fill 329 78 200 329 79 200 minecraft:bone_block
fill 329 78 202 329 83 202 minecraft:calcite
fill 329 78 203 329 78 204 minecraft:bone_block
fill 329 78 205 329 83 205 minecraft:calcite
fill 329 78 211 329 79 212 minecraft:bone_block
fill 329 78 213 329 83 214 minecraft:calcite
fill 329 78 223 330 78 223 minecraft:bone_block
fill 330 78 182 332 78 182 minecraft:polished_basalt
fill 330 78 184 330 78 186 minecraft:polished_basalt
fill 330 78 188 330 78 190 minecraft:polished_basalt
fill 330 78 192 330 78 194 minecraft:polished_basalt
fill 330 78 196 330 78 198 minecraft:polished_basalt
fill 330 78 200 330 78 202 minecraft:polished_basalt
fill 330 78 204 330 78 206 minecraft:polished_basalt
fill 330 78 208 330 78 210 minecraft:polished_basalt
fill 330 78 212 330 78 214 minecraft:polished_basalt
fill 330 78 216 330 78 218 minecraft:polished_basalt
fill 330 78 220 330 78 222 minecraft:polished_basalt
fill 331 78 223 332 83 223 minecraft:calcite
fill 332 78 181 333 83 181 minecraft:calcite
fill 332 78 222 334 78 222 minecraft:polished_basalt
fill 334 78 181 335 79 181 minecraft:bone_block
fill 334 78 182 336 78 182 minecraft:polished_basalt
fill 336 78 222 338 78 222 minecraft:polished_basalt
fill 338 78 182 340 78 182 minecraft:polished_basalt
fill 338 78 223 338 79 223 minecraft:bone_block
fill 339 78 223 340 83 223 minecraft:calcite
fill 340 78 222 342 78 222 minecraft:polished_basalt
fill 341 78 181 341 83 181 minecraft:calcite
setblock 341 78 223 minecraft:bone_block
fill 342 78 181 343 78 181 minecraft:bone_block
fill 342 78 182 344 78 182 minecraft:polished_basalt
fill 343 78 223 343 83 223 minecraft:calcite
fill 344 78 181 344 83 181 minecraft:calcite
fill 344 78 222 346 78 222 minecraft:polished_basalt
fill 346 78 181 346 79 181 minecraft:bone_block
fill 346 78 182 348 78 182 minecraft:polished_basalt
fill 348 78 222 350 78 222 minecraft:polished_basalt
fill 349 78 223 350 79 223 minecraft:bone_block
fill 350 78 182 352 78 182 minecraft:polished_basalt
fill 351 78 223 352 83 223 minecraft:calcite
fill 352 78 181 353 83 181 minecraft:calcite
fill 352 78 222 354 78 222 minecraft:polished_basalt
fill 354 78 181 355 79 181 minecraft:bone_block
fill 354 78 182 356 78 182 minecraft:polished_basalt
fill 356 78 222 358 78 222 minecraft:polished_basalt
fill 358 78 182 360 78 182 minecraft:polished_basalt
fill 360 78 222 362 78 222 minecraft:polished_basalt
fill 360 78 223 360 83 223 minecraft:calcite
fill 361 78 223 362 78 223 minecraft:bone_block
fill 362 78 182 364 78 182 minecraft:polished_basalt
setblock 363 78 181 minecraft:bone_block
fill 363 78 223 364 83 223 minecraft:calcite
fill 364 78 181 365 83 181 minecraft:calcite
fill 364 78 222 366 78 222 minecraft:polished_basalt
fill 366 78 181 367 79 181 minecraft:bone_block
fill 366 78 182 368 78 182 minecraft:polished_basalt
fill 368 78 222 370 78 222 minecraft:polished_basalt
fill 369 78 223 370 79 223 minecraft:bone_block
fill 370 78 182 370 78 184 minecraft:polished_basalt
fill 370 78 186 370 78 188 minecraft:polished_basalt
fill 370 78 190 370 78 192 minecraft:polished_basalt
fill 370 78 194 370 78 196 minecraft:polished_basalt
fill 370 78 198 370 78 200 minecraft:polished_basalt
fill 370 78 202 370 78 204 minecraft:polished_basalt
fill 370 78 206 370 78 208 minecraft:polished_basalt
fill 370 78 210 370 78 212 minecraft:polished_basalt
fill 370 78 214 370 78 216 minecraft:polished_basalt
fill 370 78 218 370 78 220 minecraft:polished_basalt
fill 371 78 182 371 83 183 minecraft:calcite
fill 371 78 184 371 78 185 minecraft:bone_block
fill 371 78 186 371 79 186 minecraft:calcite
fill 371 78 194 371 83 195 minecraft:calcite
fill 371 78 196 371 79 197 minecraft:bone_block
fill 371 78 203 371 83 203 minecraft:calcite
fill 371 78 204 371 78 205 minecraft:bone_block
fill 371 78 206 371 79 207 minecraft:calcite
fill 371 78 208 371 79 208 minecraft:bone_block
fill 371 78 214 371 83 215 minecraft:calcite
fill 371 78 216 371 79 217 minecraft:bone_block
fill 371 78 223 371 83 223 minecraft:calcite
fill 329 79 183 329 82 183 minecraft:calcite
setblock 329 79 188 minecraft:bone_block
setblock 329 79 199 minecraft:bone_block
fill 329 79 203 329 82 204 minecraft:calcite
setblock 329 79 220 minecraft:bone_block
setblock 329 79 223 minecraft:bone_block
fill 330 79 223 330 82 223 minecraft:calcite
setblock 337 79 223 minecraft:bone_block
fill 341 79 223 341 82 223 minecraft:calcite
fill 342 79 181 343 82 181 minecraft:calcite
setblock 347 79 181 minecraft:bone_block
fill 357 79 223 358 79 223 minecraft:bone_block
setblock 358 79 181 minecraft:bone_block
setblock 361 79 223 minecraft:bone_block
fill 362 79 223 362 82 223 minecraft:calcite
fill 363 79 181 363 82 181 minecraft:calcite
fill 371 79 184 371 82 184 minecraft:calcite
setblock 371 79 185 minecraft:bone_block
fill 371 79 188 371 79 189 minecraft:bone_block
fill 371 79 204 371 81 205 minecraft:calcite
setblock 371 79 209 minecraft:bone_block
setblock 371 79 220 minecraft:bone_block
fill 329 80 188 329 85 188 minecraft:calcite
fill 329 80 189 329 80 190 minecraft:bone_block
fill 329 80 191 329 85 192 minecraft:calcite
fill 329 80 197 329 81 198 minecraft:bone_block
fill 329 80 199 329 85 200 minecraft:calcite
setblock 329 80 201 minecraft:bone_block
fill 329 80 209 329 81 210 minecraft:bone_block
fill 329 80 211 329 85 212 minecraft:calcite
fill 329 80 218 329 81 218 minecraft:bone_block
fill 329 80 220 329 85 220 minecraft:calcite
fill 329 80 221 329 80 222 minecraft:bone_block
fill 329 80 223 329 85 223 minecraft:calcite
fill 334 80 181 335 85 181 minecraft:calcite
fill 335 80 223 336 81 223 minecraft:bone_block
fill 336 80 181 337 81 181 minecraft:bone_block
fill 337 80 223 338 85 223 minecraft:calcite
setblock 345 80 181 minecraft:bone_block
fill 346 80 181 347 85 181 minecraft:calcite
fill 347 80 223 348 80 223 minecraft:bone_block
fill 348 80 181 349 81 181 minecraft:bone_block
fill 349 80 223 350 85 223 minecraft:calcite
fill 354 80 181 355 85 181 minecraft:calcite
fill 356 80 181 357 80 181 minecraft:bone_block
fill 356 80 223 356 81 223 minecraft:bone_block
fill 357 80 223 358 85 223 minecraft:calcite
fill 358 80 181 358 85 181 minecraft:calcite
setblock 359 80 223 minecraft:bone_block
fill 361 80 223 361 85 223 minecraft:calcite
fill 366 80 181 367 85 181 minecraft:calcite
fill 367 80 223 368 81 223 minecraft:bone_block
fill 368 80 181 369 81 181 minecraft:bone_block
fill 369 80 223 370 85 223 minecraft:calcite
fill 371 80 185 371 85 185 minecraft:calcite
fill 371 80 186 371 80 187 minecraft:bone_block
fill 371 80 188 371 81 189 minecraft:calcite
fill 371 80 190 371 81 190 minecraft:bone_block
fill 371 80 196 371 85 197 minecraft:calcite
fill 371 80 198 371 81 199 minecraft:bone_block
fill 371 80 206 371 83 206 minecraft:calcite
setblock 371 80 207 minecraft:bone_block
fill 371 80 208 371 85 209 minecraft:calcite
fill 371 80 210 371 81 211 minecraft:bone_block
fill 371 80 216 371 82 217 minecraft:calcite
fill 371 80 218 371 80 219 minecraft:bone_block
fill 371 80 220 371 85 220 minecraft:calcite
fill 329 81 185 329 81 186 minecraft:bone_block
setblock 329 81 189 minecraft:bone_block
fill 329 81 190 329 84 190 minecraft:calcite
fill 329 81 201 329 84 201 minecraft:calcite
setblock 329 81 206 minecraft:bone_block
setblock 329 81 217 minecraft:bone_block
fill 329 81 221 329 84 222 minecraft:calcite
setblock 332 81 184 minecraft:light[level=12]
setblock 332 81 192 minecraft:light[level=12]
setblock 332 81 200 minecraft:light[level=12]
setblock 332 81 208 minecraft:light[level=12]
setblock 332 81 216 minecraft:light[level=12]
setblock 340 81 181 minecraft:bone_block
setblock 340 81 184 minecraft:light[level=12]
setblock 340 81 192 minecraft:light[level=12]
setblock 340 81 200 minecraft:light[level=12]
setblock 340 81 208 minecraft:light[level=12]
setblock 340 81 216 minecraft:light[level=12]
setblock 344 81 223 minecraft:bone_block
fill 345 81 181 345 84 181 minecraft:calcite
setblock 347 81 223 minecraft:bone_block
setblock 348 81 184 minecraft:light[level=12]
setblock 348 81 192 minecraft:light[level=12]
setblock 348 81 200 minecraft:light[level=12]
setblock 348 81 208 minecraft:light[level=12]
setblock 348 81 216 minecraft:light[level=12]
fill 348 81 223 348 84 223 minecraft:calcite
setblock 355 81 223 minecraft:bone_block
fill 356 81 181 356 84 181 minecraft:calcite
setblock 356 81 184 minecraft:light[level=12]
setblock 356 81 192 minecraft:light[level=12]
setblock 356 81 200 minecraft:light[level=12]
setblock 356 81 208 minecraft:light[level=12]
setblock 356 81 216 minecraft:light[level=12]
setblock 357 81 181 minecraft:bone_block
fill 359 81 223 359 84 223 minecraft:calcite
fill 360 81 181 361 81 181 minecraft:bone_block
setblock 364 81 184 minecraft:light[level=12]
setblock 364 81 192 minecraft:light[level=12]
setblock 364 81 200 minecraft:light[level=12]
setblock 364 81 208 minecraft:light[level=12]
setblock 364 81 216 minecraft:light[level=12]
fill 371 81 186 371 83 187 minecraft:calcite
setblock 371 81 191 minecraft:bone_block
setblock 371 81 202 minecraft:bone_block
fill 371 81 207 371 83 207 minecraft:calcite
fill 371 81 218 371 84 218 minecraft:calcite
setblock 371 81 219 minecraft:bone_block
setblock 371 81 222 minecraft:bone_block
fill 329 82 184 329 83 184 minecraft:bone_block
fill 329 82 185 329 87 186 minecraft:calcite
setblock 329 82 187 minecraft:bone_block
fill 329 82 189 329 87 189 minecraft:calcite
fill 329 82 195 329 83 196 minecraft:bone_block
fill 329 82 197 329 87 198 minecraft:calcite
fill 329 82 206 329 87 206 minecraft:calcite
fill 329 82 207 329 82 208 minecraft:bone_block
fill 329 82 209 329 87 210 minecraft:calcite
fill 329 82 215 329 83 216 minecraft:bone_block
fill 329 82 217 329 87 218 minecraft:calcite
setblock 329 82 219 minecraft:bone_block
fill 330 82 181 331 83 181 minecraft:bone_block
fill 333 82 223 334 83 223 minecraft:bone_block
fill 335 82 223 336 87 223 minecraft:calcite
fill 336 82 181 337 87 181 minecraft:calcite
fill 338 82 181 339 82 181 minecraft:bone_block
fill 340 82 181 340 87 181 minecraft:calcite
fill 342 82 223 342 83 223 minecraft:bone_block
fill 344 82 223 344 87 223 minecraft:calcite
fill 345 82 223 346 82 223 minecraft:bone_block
fill 347 82 223 347 87 223 minecraft:calcite
fill 348 82 181 349 87 181 minecraft:calcite
fill 350 82 181 351 83 181 minecraft:bone_block
fill 353 82 223 354 83 223 minecraft:bone_block
fill 355 82 223 356 87 223 minecraft:calcite
fill 357 82 181 357 87 181 minecraft:calcite
setblock 359 82 181 minecraft:bone_block
fill 360 82 181 361 87 181 minecraft:calcite
fill 362 82 181 362 83 181 minecraft:bone_block
fill 365 82 223 366 82 223 minecraft:bone_block
fill 367 82 223 368 87 223 minecraft:calcite
fill 368 82 181 369 87 181 minecraft:calcite
fill 370 82 181 371 82 181 minecraft:bone_block
fill 371 82 188 371 85 188 minecraft:calcite
setblock 371 82 189 minecraft:bone_block
fill 371 82 190 371 87 191 minecraft:calcite
fill 371 82 192 371 83 193 minecraft:bone_block
fill 371 82 198 371 84 199 minecraft:calcite
fill 371 82 200 371 82 201 minecraft:bone_block
fill 371 82 202 371 87 202 minecraft:calcite
fill 371 82 204 371 83 204 minecraft:bone_block
setblock 371 82 205 minecraft:calcite
fill 371 82 210 371 87 211 minecraft:calcite
fill 371 82 212 371 83 213 minecraft:bone_block
fill 371 82 219 371 84 219 minecraft:calcite
setblock 371 82 221 minecraft:bone_block
fill 371 82 222 371 87 222 minecraft:calcite
setblock 329 83 183 minecraft:bone_block
fill 329 83 187 329 86 187 minecraft:calcite
fill 329 83 203 329 83 204 minecraft:bone_block
setblock 329 83 207 minecraft:bone_block
fill 329 83 208 329 86 208 minecraft:calcite
fill 329 83 219 329 86 219 minecraft:calcite
setblock 330 83 223 minecraft:bone_block
fill 338 83 181 338 86 181 minecraft:calcite
setblock 339 83 181 minecraft:bone_block
setblock 341 83 223 minecraft:bone_block
fill 342 83 181 343 83 181 minecraft:bone_block
fill 345 83 223 346 86 223 minecraft:calcite
fill 359 83 181 359 86 181 minecraft:calcite
setblock 362 83 223 minecraft:bone_block
setblock 363 83 181 minecraft:bone_block
setblock 365 83 223 minecraft:bone_block
fill 366 83 223 366 86 223 minecraft:calcite
fill 370 83 181 370 86 181 minecraft:calcite
setblock 371 83 181 minecraft:bone_block
setblock 371 83 184 minecraft:bone_block
fill 371 83 189 371 85 189 minecraft:calcite
fill 371 83 200 371 86 200 minecraft:calcite
setblock 371 83 201 minecraft:bone_block
setblock 371 83 205 minecraft:bone_block
setblock 371 83 216 minecraft:bone_block
fill 371 83 217 371 85 217 minecraft:calcite
fill 371 83 221 371 86 221 minecraft:calcite
fill 329 84 181 329 85 182 minecraft:bone_block
fill 329 84 183 329 89 184 minecraft:calcite
fill 329 84 193 329 84 194 minecraft:bone_block
fill 329 84 195 329 89 196 minecraft:calcite
fill 329 84 202 329 85 202 minecraft:bone_block
fill 329 84 203 329 89 204 minecraft:calcite
setblock 329 84 205 minecraft:bone_block
fill 329 84 207 329 89 207 minecraft:calcite
fill 329 84 213 329 85 214 minecraft:bone_block
fill 329 84 215 329 89 216 minecraft:calcite
fill 330 84 181 331 89 181 minecraft:calcite
fill 330 84 182 332 84 182 minecraft:polished_basalt
fill 330 84 184 330 84 186 minecraft:polished_basalt
fill 330 84 188 330 84 190 minecraft:polished_basalt
fill 330 84 192 330 84 194 minecraft:polished_basalt
fill 330 84 196 330 84 198 minecraft:polished_basalt
fill 330 84 200 330 84 202 minecraft:polished_basalt
fill 330 84 204 330 84 206 minecraft:polished_basalt
fill 330 84 208 330 84 210 minecraft:polished_basalt
fill 330 84 212 330 84 214 minecraft:polished_basalt
fill 330 84 216 330 84 218 minecraft:polished_basalt
fill 330 84 220 330 84 222 minecraft:polished_basalt
fill 330 84 223 330 89 223 minecraft:calcite
fill 331 84 223 332 84 223 minecraft:bone_block
fill 332 84 181 333 85 181 minecraft:bone_block
fill 332 84 222 334 84 222 minecraft:polished_basalt
fill 333 84 223 334 89 223 minecraft:calcite
fill 334 84 182 336 84 182 minecraft:polished_basalt
fill 336 84 222 338 84 222 minecraft:polished_basalt
fill 338 84 182 340 84 182 minecraft:polished_basalt
fill 339 84 181 339 89 181 minecraft:calcite
fill 339 84 223 340 85 223 minecraft:bone_block
fill 340 84 222 342 84 222 minecraft:polished_basalt
setblock 341 84 181 minecraft:bone_block
fill 341 84 223 342 89 223 minecraft:calcite
fill 342 84 181 343 89 181 minecraft:calcite
fill 342 84 182 344 84 182 minecraft:polished_basalt
setblock 343 84 223 minecraft:bone_block
fill 344 84 181 344 85 181 minecraft:bone_block
fill 344 84 222 346 84 222 minecraft:polished_basalt
fill 346 84 182 348 84 182 minecraft:polished_basalt
fill 348 84 222 350 84 222 minecraft:polished_basalt
fill 350 84 181 351 89 181 minecraft:calcite
fill 350 84 182 352 84 182 minecraft:polished_basalt
fill 351 84 223 352 85 223 minecraft:bone_block
fill 352 84 181 353 84 181 minecraft:bone_block
fill 352 84 222 354 84 222 minecraft:polished_basalt
fill 353 84 223 354 89 223 minecraft:calcite
fill 354 84 182 356 84 182 minecraft:polished_basalt
fill 356 84 222 358 84 222 minecraft:polished_basalt
fill 358 84 182 360 84 182 minecraft:polished_basalt
fill 360 84 222 362 84 222 minecraft:polished_basalt
fill 360 84 223 360 85 223 minecraft:bone_block
fill 362 84 181 363 89 181 minecraft:calcite
fill 362 84 182 364 84 182 minecraft:polished_basalt
fill 362 84 223 362 89 223 minecraft:calcite
fill 363 84 223 364 84 223 minecraft:bone_block
fill 364 84 181 365 85 181 minecraft:bone_block
fill 364 84 222 366 84 222 minecraft:polished_basalt
fill 365 84 223 365 89 223 minecraft:calcite
fill 366 84 182 368 84 182 minecraft:polished_basalt
fill 368 84 222 370 84 222 minecraft:polished_basalt
fill 370 84 182 370 84 184 minecraft:polished_basalt
fill 370 84 186 370 84 188 minecraft:polished_basalt
fill 370 84 190 370 84 192 minecraft:polished_basalt
fill 370 84 194 370 84 196 minecraft:polished_basalt
fill 370 84 198 370 84 200 minecraft:polished_basalt
fill 370 84 202 370 84 204 minecraft:polished_basalt
fill 370 84 206 370 84 208 minecraft:polished_basalt
fill 370 84 210 370 84 212 minecraft:polished_basalt
fill 370 84 214 370 84 216 minecraft:polished_basalt
fill 370 84 218 370 84 220 minecraft:polished_basalt
fill 371 84 181 371 89 181 minecraft:calcite
fill 371 84 182 371 84 183 minecraft:bone_block
fill 371 84 184 371 89 184 minecraft:calcite
fill 371 84 186 371 85 186 minecraft:bone_block
setblock 371 84 187 minecraft:calcite
fill 371 84 192 371 89 193 minecraft:calcite
fill 371 84 194 371 85 195 minecraft:bone_block
fill 371 84 201 371 86 201 minecraft:calcite
setblock 371 84 203 minecraft:bone_block
fill 371 84 204 371 89 205 minecraft:calcite
fill 371 84 206 371 85 207 minecraft:bone_block
fill 371 84 212 371 89 213 minecraft:calcite
fill 371 84 214 371 84 215 minecraft:bone_block
fill 371 84 216 371 85 216 minecraft:calcite
fill 371 84 223 371 85 223 minecraft:bone_block
setblock 329 85 190 minecraft:bone_block
setblock 329 85 193 minecraft:bone_block
fill 329 85 194 329 88 194 minecraft:calcite
setblock 329 85 201 minecraft:bone_block
fill 329 85 205 329 88 205 minecraft:calcite
fill 329 85 221 329 85 222 minecraft:bone_block
setblock 331 85 223 minecraft:bone_block
fill 332 85 223 332 88 223 minecraft:calcite
fill 341 85 181 341 88 181 minecraft:calcite
fill 343 85 223 343 88 223 minecraft:calcite
setblock 345 85 181 minecraft:bone_block
setblock 348 85 223 minecraft:bone_block
fill 352 85 181 352 88 181 minecraft:calcite
setblock 353 85 181 minecraft:bone_block
setblock 356 85 181 minecraft:bone_block
setblock 359 85 223 minecraft:bone_block
fill 363 85 223 364 88 223 minecraft:calcite
fill 371 85 182 371 88 183 minecraft:calcite
setblock 371 85 187 minecraft:bone_block
setblock 371 85 198 minecraft:bone_block
fill 371 85 199 371 87 199 minecraft:calcite
fill 371 85 203 371 88 203 minecraft:calcite
fill 371 85 214 371 88 214 minecraft:calcite
setblock 371 85 215 minecraft:bone_block
fill 371 85 218 371 85 219 minecraft:bone_block
fill 329 86 181 329 91 182 minecraft:calcite
fill 329 86 188 329 87 188 minecraft:bone_block
fill 329 86 190 329 91 190 minecraft:calcite
fill 329 86 191 329 86 192 minecraft:bone_block
fill 329 86 193 329 91 193 minecraft:calcite
fill 329 86 199 329 87 200 minecraft:bone_block
fill 329 86 201 329 91 202 minecraft:calcite
fill 329 86 211 329 86 212 minecraft:bone_block
fill 329 86 213 329 91 214 minecraft:calcite
fill 329 86 220 329 87 220 minecraft:bone_block
fill 329 86 221 329 91 222 minecraft:calcite
setblock 329 86 223 minecraft:bone_block
fill 331 86 223 331 91 223 minecraft:calcite
fill 332 86 181 333 91 181 minecraft:calcite
fill 334 86 181 335 86 181 minecraft:bone_block
fill 337 86 223 338 87 223 minecraft:bone_block
fill 339 86 223 340 91 223 minecraft:calcite
fill 344 86 181 345 91 181 minecraft:calcite
fill 346 86 181 347 87 181 minecraft:bone_block
fill 348 86 223 348 91 223 minecraft:calcite
fill 349 86 223 350 86 223 minecraft:bone_block
fill 351 86 223 352 91 223 minecraft:calcite
fill 353 86 181 353 91 181 minecraft:calcite
fill 354 86 181 355 86 181 minecraft:bone_block
fill 356 86 181 356 91 181 minecraft:calcite
fill 357 86 223 358 87 223 minecraft:bone_block
fill 358 86 181 358 87 181 minecraft:bone_block
fill 359 86 223 360 91 223 minecraft:calcite
setblock 361 86 223 minecraft:bone_block
fill 364 86 181 365 91 181 minecraft:calcite
fill 366 86 181 367 87 181 minecraft:bone_block
fill 369 86 223 370 87 223 minecraft:bone_block
setblock 371 86 185 minecraft:bone_block
fill 371 86 186 371 91 187 minecraft:calcite
fill 371 86 188 371 87 189 minecraft:bone_block
fill 371 86 194 371 91 195 minecraft:calcite
fill 371 86 196 371 86 197 minecraft:bone_block
fill 371 86 198 371 87 198 minecraft:calcite
fill 371 86 206 371 91 207 minecraft:calcite
fill 371 86 208 371 87 209 minecraft:bone_block
fill 371 86 215 371 91 215 minecraft:calcite
fill 371 86 216 371 86 217 minecraft:bone_block
fill 371 86 218 371 87 219 minecraft:calcite
fill 371 86 220 371 87 220 minecraft:bone_block
fill 371 86 223 371 91 223 minecraft:calcite
setblock 329 87 187 minecraft:bone_block
fill 329 87 191 329 90 192 minecraft:calcite
setblock 329 87 208 minecraft:bone_block
setblock 329 87 211 minecraft:bone_block
fill 329 87 212 329 90 212 minecraft:calcite
setblock 329 87 219 minecraft:bone_block
fill 329 87 223 329 90 223 minecraft:calcite
fill 334 87 181 334 90 181 minecraft:calcite
setblock 335 87 181 minecraft:bone_block
setblock 338 87 181 minecraft:bone_block
fill 345 87 223 346 87 223 minecraft:bone_block
setblock 349 87 223 minecraft:bone_block
fill 350 87 223 350 90 223 minecraft:calcite
fill 354 87 181 355 90 181 minecraft:calcite
setblock 359 87 181 minecraft:bone_block
fill 361 87 223 361 90 223 minecraft:calcite
setblock 366 87 223 minecraft:bone_block
setblock 370 87 181 minecraft:bone_block
fill 371 87 185 371 90 185 minecraft:calcite
fill 371 87 196 371 90 196 minecraft:calcite
setblock 371 87 197 minecraft:bone_block
fill 371 87 200 371 87 201 minecraft:bone_block
fill 371 87 216 371 89 217 minecraft:calcite
setblock 371 87 221 minecraft:bone_block
fill 329 88 185 329 89 186 minecraft:bone_block
fill 329 88 187 329 93 188 minecraft:calcite
setblock 329 88 189 minecraft:bone_block
fill 329 88 197 329 89 198 minecraft:bone_block
fill 329 88 199 329 93 200 minecraft:calcite
fill 329 88 206 329 89 206 minecraft:bone_block
fill 329 88 208 329 93 208 minecraft:calcite
fill 329 88 209 329 88 210 minecraft:bone_block
fill 329 88 211 329 93 211 minecraft:calcite
fill 329 88 217 329 89 218 minecraft:bone_block
fill 329 88 219 329 93 220 minecraft:calcite
fill 335 88 181 335 93 181 minecraft:calcite
fill 335 88 223 336 88 223 minecraft:bone_block
fill 336 88 181 337 88 181 minecraft:bone_block
fill 337 88 223 338 93 223 minecraft:calcite
fill 338 88 181 338 93 181 minecraft:calcite
fill 340 88 181 340 89 181 minecraft:bone_block
fill 344 88 223 344 89 223 minecraft:bone_block
fill 345 88 223 346 93 223 minecraft:calcite
fill 346 88 181 347 93 181 minecraft:calcite
setblock 347 88 223 minecraft:bone_block
fill 348 88 181 349 89 181 minecraft:bone_block
fill 349 88 223 349 93 223 minecraft:calcite
fill 355 88 223 356 89 223 minecraft:bone_block
setblock 357 88 181 minecraft:bone_block
fill 357 88 223 358 93 223 minecraft:calcite
fill 358 88 181 359 93 181 minecraft:calcite
fill 360 88 181 361 89 181 minecraft:bone_block
fill 366 88 181 367 93 181 minecraft:calcite
fill 366 88 223 366 93 223 minecraft:calcite
fill 367 88 223 368 88 223 minecraft:bone_block
fill 368 88 181 369 88 181 minecraft:bone_block
fill 369 88 223 370 90 223 minecraft:calcite
fill 370 88 181 370 93 181 minecraft:calcite
fill 371 88 188 371 93 189 minecraft:calcite
fill 371 88 190 371 89 191 minecraft:bone_block
fill 371 88 197 371 93 197 minecraft:calcite
fill 371 88 198 371 88 199 minecraft:bone_block
fill 371 88 200 371 89 201 minecraft:calcite
fill 371 88 202 371 89 202 minecraft:bone_block
fill 371 88 208 371 93 209 minecraft:calcite
fill 371 88 210 371 89 211 minecraft:bone_block
fill 371 88 218 371 91 218 minecraft:calcite
setblock 371 88 219 minecraft:bone_block
fill 371 88 220 371 93 221 minecraft:calcite
fill 371 88 222 371 89 222 minecraft:bone_block
fill 329 89 189 329 92 189 minecraft:calcite
setblock 329 89 194 minecraft:bone_block
setblock 329 89 205 minecraft:bone_block
fill 329 89 209 329 92 210 minecraft:calcite
setblock 332 89 184 minecraft:light[level=12]
setblock 332 89 192 minecraft:light[level=12]
setblock 332 89 200 minecraft:light[level=12]
setblock 332 89 208 minecraft:light[level=12]
setblock 332 89 216 minecraft:light[level=12]
setblock 332 89 223 minecraft:bone_block
setblock 335 89 223 minecraft:bone_block
fill 336 89 181 337 92 181 minecraft:calcite
fill 336 89 223 336 92 223 minecraft:calcite
setblock 340 89 184 minecraft:light[level=12]
setblock 340 89 192 minecraft:light[level=12]
setblock 340 89 200 minecraft:light[level=12]
setblock 340 89 208 minecraft:light[level=12]
setblock 340 89 216 minecraft:light[level=12]
setblock 341 89 181 minecraft:bone_block
setblock 343 89 223 minecraft:bone_block
fill 347 89 223 347 92 223 minecraft:calcite
setblock 348 89 184 minecraft:light[level=12]
setblock 348 89 192 minecraft:light[level=12]
setblock 348 89 200 minecraft:light[level=12]
setblock 348 89 208 minecraft:light[level=12]
setblock 348 89 216 minecraft:light[level=12]
setblock 352 89 181 minecraft:bone_block
setblock 356 89 184 minecraft:light[level=12]
setblock 356 89 192 minecraft:light[level=12]
setblock 356 89 200 minecraft:light[level=12]
setblock 356 89 208 minecraft:light[level=12]
setblock 356 89 216 minecraft:light[level=12]
fill 357 89 181 357 92 181 minecraft:calcite
fill 363 89 223 364 89 223 minecraft:bone_block
setblock 364 89 184 minecraft:light[level=12]
setblock 364 89 192 minecraft:light[level=12]
setblock 364 89 200 minecraft:light[level=12]
setblock 364 89 208 minecraft:light[level=12]
setblock 364 89 216 minecraft:light[level=12]
setblock 367 89 223 minecraft:bone_block
fill 368 89 181 368 92 181 minecraft:calcite
fill 368 89 223 368 92 223 minecraft:calcite
setblock 369 89 181 minecraft:bone_block
fill 371 89 182 371 89 183 minecraft:bone_block
fill 371 89 198 371 91 199 minecraft:calcite
setblock 371 89 203 minecraft:bone_block
setblock 371 89 214 minecraft:bone_block
fill 371 89 219 371 91 219 minecraft:calcite
fill 329 90 183 329 91 184 minecraft:bone_block
fill 329 90 185 329 95 186 minecraft:calcite
fill 329 90 194 329 95 194 minecraft:calcite
fill 329 90 195 329 90 196 minecraft:bone_block
fill 329 90 197 329 95 198 minecraft:calcite
fill 329 90 203 329 91 204 minecraft:bone_block
fill 329 90 205 329 95 206 minecraft:calcite
setblock 329 90 207 minecraft:bone_block
fill 329 90 215 329 91 216 minecraft:bone_block
fill 329 90 217 329 95 218 minecraft:calcite
fill 330 90 181 331 91 181 minecraft:bone_block
fill 330 90 182 332 90 182 minecraft:polished_basalt
fill 330 90 184 330 90 186 minecraft:polished_basalt
fill 330 90 188 330 90 190 minecraft:polished_basalt
fill 330 90 192 330 90 194 minecraft:polished_basalt
fill 330 90 196 330 90 198 minecraft:polished_basalt
fill 330 90 200 330 90 202 minecraft:polished_basalt
fill 330 90 204 330 90 206 minecraft:polished_basalt
fill 330 90 208 330 90 210 minecraft:polished_basalt
fill 330 90 212 330 90 214 minecraft:polished_basalt
fill 330 90 216 330 90 218 minecraft:polished_basalt
fill 330 90 220 330 90 222 minecraft:polished_basalt
fill 330 90 223 330 91 223 minecraft:bone_block
fill 332 90 222 334 90 222 minecraft:polished_basalt
fill 332 90 223 332 95 223 minecraft:calcite
fill 333 90 223 334 90 223 minecraft:bone_block
fill 334 90 182 336 90 182 minecraft:polished_basalt
fill 335 90 223 335 95 223 minecraft:calcite
fill 336 90 222 338 90 222 minecraft:polished_basalt
fill 338 90 182 340 90 182 minecraft:polished_basalt
setblock 339 90 181 minecraft:bone_block
fill 340 90 181 341 95 181 minecraft:calcite
fill 340 90 222 342 90 222 minecraft:polished_basalt
fill 341 90 223 342 91 223 minecraft:bone_block
fill 342 90 181 343 91 181 minecraft:bone_block
fill 342 90 182 344 90 182 minecraft:polished_basalt
fill 343 90 223 344 95 223 minecraft:calcite
fill 344 90 222 346 90 222 minecraft:polished_basalt
fill 346 90 182 348 90 182 minecraft:polished_basalt
fill 348 90 181 349 95 181 minecraft:calcite
fill 348 90 222 350 90 222 minecraft:polished_basalt
fill 350 90 181 351 90 181 minecraft:bone_block
fill 350 90 182 352 90 182 minecraft:polished_basalt
fill 352 90 181 352 95 181 minecraft:calcite
fill 352 90 222 354 90 222 minecraft:polished_basalt
fill 353 90 223 354 90 223 minecraft:bone_block
fill 354 90 182 356 90 182 minecraft:polished_basalt
fill 355 90 223 356 95 223 minecraft:calcite
fill 356 90 222 358 90 222 minecraft:polished_basalt
fill 358 90 182 360 90 182 minecraft:polished_basalt
fill 360 90 181 361 95 181 minecraft:calcite
fill 360 90 222 362 90 222 minecraft:polished_basalt
fill 362 90 181 363 91 181 minecraft:bone_block
fill 362 90 182 364 90 182 minecraft:polished_basalt
fill 362 90 223 362 91 223 minecraft:bone_block
fill 363 90 223 364 95 223 minecraft:calcite
fill 364 90 222 366 90 222 minecraft:polished_basalt
setblock 365 90 223 minecraft:bone_block
fill 366 90 182 368 90 182 minecraft:polished_basalt
fill 367 90 223 367 92 223 minecraft:calcite
fill 368 90 222 370 90 222 minecraft:polished_basalt
fill 369 90 181 369 95 181 minecraft:calcite
fill 370 90 182 370 90 184 minecraft:polished_basalt
fill 370 90 186 370 90 188 minecraft:polished_basalt
fill 370 90 190 370 90 192 minecraft:polished_basalt
fill 370 90 194 370 90 196 minecraft:polished_basalt
fill 370 90 198 370 90 200 minecraft:polished_basalt
fill 370 90 202 370 90 204 minecraft:polished_basalt
fill 370 90 206 370 90 208 minecraft:polished_basalt
fill 370 90 210 370 90 212 minecraft:polished_basalt
fill 370 90 214 370 90 216 minecraft:polished_basalt
fill 370 90 218 370 90 220 minecraft:polished_basalt
setblock 371 90 181 minecraft:bone_block
fill 371 90 182 371 95 183 minecraft:calcite
fill 371 90 184 371 91 184 minecraft:bone_block
fill 371 90 190 371 95 191 minecraft:calcite
fill 371 90 192 371 90 193 minecraft:bone_block
fill 371 90 200 371 93 200 minecraft:calcite
setblock 371 90 201 minecraft:bone_block
fill 371 90 202 371 95 203 minecraft:calcite
fill 371 90 204 371 91 205 minecraft:bone_block
fill 371 90 210 371 92 211 minecraft:calcite
fill 371 90 212 371 90 213 minecraft:bone_block
fill 371 90 214 371 95 214 minecraft:calcite
fill 371 90 216 371 91 216 minecraft:bone_block
setblock 371 90 217 minecraft:calcite
fill 371 90 222 371 95 222 minecraft:calcite
fill 329 91 191 329 91 192 minecraft:bone_block
setblock 329 91 195 minecraft:bone_block
fill 329 91 196 329 94 196 minecraft:calcite
fill 329 91 207 329 94 207 minecraft:calcite
setblock 329 91 212 minecraft:bone_block
setblock 329 91 223 minecraft:bone_block
fill 333 91 223 334 94 223 minecraft:calcite
setblock 334 91 181 minecraft:bone_block
fill 339 91 181 339 94 181 minecraft:calcite
fill 350 91 181 350 94 181 minecraft:calcite
setblock 350 91 223 minecraft:bone_block
setblock 351 91 181 minecraft:bone_block
setblock 353 91 223 minecraft:bone_block
fill 354 91 181 355 91 181 minecraft:bone_block
fill 354 91 223 354 94 223 minecraft:calcite
setblock 361 91 223 minecraft:bone_block
fill 365 91 223 365 94 223 minecraft:calcite
fill 369 91 223 369 93 223 minecraft:calcite
setblock 370 91 223 minecraft:bone_block
fill 371 91 181 371 94 181 minecraft:calcite
setblock 371 91 185 minecraft:bone_block
fill 371 91 192 371 94 192 minecraft:calcite
setblock 371 91 193 minecraft:bone_block
setblock 371 91 196 minecraft:bone_block
fill 371 91 201 371 93 201 minecraft:calcite
fill 371 91 212 371 94 212 minecraft:calcite
setblock 371 91 213 minecraft:bone_block
setblock 371 91 217 minecraft:bone_block
fill 329 92 181 329 92 182 minecraft:bone_block
fill 329 92 183 329 109 184 minecraft:calcite
fill 329 92 190 329 93 190 minecraft:bone_block
fill 329 92 191 329 106 192 minecraft:calcite
setblock 329 92 193 minecraft:bone_block
fill 329 92 195 329 109 195 minecraft:calcite
fill 329 92 201 329 93 202 minecraft:bone_block
fill 329 92 203 329 110 204 minecraft:calcite
fill 329 92 212 329 106 212 minecraft:calcite
fill 329 92 213 329 92 214 minecraft:bone_block
fill 329 92 215 329 109 216 minecraft:calcite
fill 329 92 221 329 93 222 minecraft:bone_block
fill 329 92 223 330 106 223 minecraft:calcite
fill 330 92 181 331 109 181 minecraft:calcite
setblock 331 92 223 minecraft:bone_block
fill 332 92 181 333 92 181 minecraft:bone_block
fill 334 92 181 334 106 181 minecraft:calcite
fill 339 92 223 340 93 223 minecraft:bone_block
fill 341 92 223 342 109 223 minecraft:calcite
fill 342 92 181 343 110 181 minecraft:calcite
fill 344 92 181 345 93 181 minecraft:bone_block
fill 348 92 223 348 93 223 minecraft:bone_block
fill 350 92 223 350 106 223 minecraft:calcite
fill 351 92 181 351 109 181 minecraft:calcite
fill 351 92 223 352 92 223 minecraft:bone_block
setblock 353 92 181 minecraft:bone_block
fill 353 92 223 353 109 223 minecraft:calcite
fill 354 92 181 355 106 181 minecraft:calcite
fill 356 92 181 356 93 181 minecraft:bone_block
fill 359 92 223 360 93 223 minecraft:bone_block
fill 361 92 223 362 106 223 minecraft:calcite
fill 362 92 181 363 109 181 minecraft:calcite
fill 364 92 181 365 92 181 minecraft:bone_block
fill 370 92 223 370 93 223 minecraft:calcite
fill 371 92 184 371 106 185 minecraft:calcite
fill 371 92 186 371 93 187 minecraft:bone_block
fill 371 92 193 371 109 193 minecraft:calcite
fill 371 92 194 371 92 195 minecraft:bone_block
fill 371 92 196 371 106 196 minecraft:calcite
fill 371 92 198 371 93 198 minecraft:bone_block
setblock 371 92 199 minecraft:calcite
fill 371 92 204 371 109 205 minecraft:calcite
fill 371 92 206 371 93 207 minecraft:bone_block
fill 371 92 213 371 94 213 minecraft:calcite
setblock 371 92 215 minecraft:bone_block
fill 371 92 216 371 106 217 minecraft:calcite
fill 371 92 218 371 93 219 minecraft:bone_block
fill 371 92 223 371 93 223 minecraft:bone_block
setblock 329 93 181 minecraft:bone_block
fill 329 93 182 329 111 182 minecraft:calcite
setblock 329 93 189 minecraft:bone_block
fill 329 93 193 329 111 193 minecraft:calcite
fill 329 93 209 329 93 210 minecraft:bone_block
setblock 329 93 213 minecraft:bone_block
fill 329 93 214 329 111 214 minecraft:calcite
fill 331 93 223 331 111 223 minecraft:calcite
fill 332 93 181 332 111 181 minecraft:calcite
setblock 333 93 181 minecraft:bone_block
fill 336 93 181 337 93 181 minecraft:bone_block
setblock 336 93 223 minecraft:bone_block
setblock 347 93 223 minecraft:bone_block
fill 351 93 223 352 111 223 minecraft:calcite
fill 353 93 181 353 111 181 minecraft:calcite
setblock 357 93 181 minecraft:bone_block
fill 364 93 181 364 111 181 minecraft:calcite
setblock 365 93 181 minecraft:bone_block
fill 367 93 223 368 93 223 minecraft:bone_block
setblock 368 93 181 minecraft:bone_block
fill 371 93 194 371 111 195 minecraft:calcite
setblock 371 93 199 minecraft:bone_block
setblock 371 93 210 minecraft:bone_block
fill 371 93 211 371 95 211 minecraft:calcite
fill 371 93 215 371 111 215 minecraft:calcite
fill 329 94 181 329 111 181 minecraft:calcite
fill 329 94 187 329 95 188 minecraft:bone_block
fill 329 94 189 329 107 190 minecraft:calcite
fill 329 94 199 329 94 200 minecraft:bone_block
fill 329 94 201 329 107 202 minecraft:calcite
fill 329 94 208 329 95 208 minecraft:bone_block
fill 329 94 209 329 107 210 minecraft:calcite
setblock 329 94 211 minecraft:bone_block
fill 329 94 213 329 111 213 minecraft:calcite
fill 329 94 219 329 95 220 minecraft:bone_block
fill 329 94 221 329 107 222 minecraft:calcite
fill 333 94 181 333 111 181 minecraft:calcite
setblock 335 94 181 minecraft:bone_block
fill 336 94 181 337 107 181 minecraft:calcite
fill 336 94 223 336 107 223 minecraft:calcite
fill 337 94 223 338 94 223 minecraft:bone_block
fill 338 94 181 338 95 181 minecraft:bone_block
fill 339 94 223 340 111 223 minecraft:calcite
fill 344 94 181 345 107 181 minecraft:calcite
fill 345 94 223 346 95 223 minecraft:bone_block
fill 346 94 181 347 94 181 minecraft:bone_block
fill 347 94 223 348 107 223 minecraft:calcite
setblock 349 94 223 minecraft:bone_block
fill 356 94 181 357 107 181 minecraft:calcite
fill 357 94 223 358 95 223 minecraft:bone_block
fill 358 94 181 359 95 181 minecraft:bone_block
fill 359 94 223 360 107 223 minecraft:calcite
fill 365 94 181 365 111 181 minecraft:calcite
fill 366 94 181 367 94 181 minecraft:bone_block
fill 366 94 223 366 95 223 minecraft:bone_block
fill 367 94 223 368 95 223 minecraft:calcite
fill 368 94 181 368 107 181 minecraft:calcite
fill 369 94 223 370 94 223 minecraft:bone_block
fill 370 94 181 370 95 181 minecraft:bone_block
fill 371 94 186 371 107 187 minecraft:calcite
fill 371 94 188 371 95 189 minecraft:bone_block
setblock 371 94 197 minecraft:bone_block
fill 371 94 198 371 107 199 minecraft:calcite
fill 371 94 200 371 95 201 minecraft:bone_block
fill 371 94 206 371 111 207 minecraft:calcite
fill 371 94 208 371 94 209 minecraft:bone_block
fill 371 94 210 371 95 210 minecraft:calcite
fill 371 94 218 371 107 219 minecraft:calcite
fill 371 94 220 371 95 221 minecraft:bone_block
fill 371 94 223 371 111 223 minecraft:calcite
setblock 329 95 196 minecraft:bone_block
setblock 329 95 199 minecraft:bone_block
fill 329 95 200 329 106 200 minecraft:calcite
setblock 329 95 207 minecraft:bone_block
fill 329 95 211 329 106 211 minecraft:calcite
fill 333 95 223 334 95 223 minecraft:bone_block
fill 335 95 181 335 106 181 minecraft:calcite
setblock 337 95 223 minecraft:bone_block
fill 338 95 223 338 106 223 minecraft:calcite
setblock 339 95 181 minecraft:bone_block
fill 346 95 181 346 106 181 minecraft:calcite
setblock 347 95 181 minecraft:bone_block
fill 349 95 223 349 106 223 minecraft:calcite
setblock 350 95 181 minecraft:bone_block
setblock 354 95 223 minecraft:bone_block
setblock 365 95 223 minecraft:bone_block
fill 366 95 181 367 106 181 minecraft:calcite
fill 369 95 223 370 106 223 minecraft:calcite
setblock 371 95 181 minecraft:bone_block
setblock 371 95 192 minecraft:bone_block
fill 371 95 197 371 106 197 minecraft:calcite
fill 371 95 208 371 106 208 minecraft:calcite
setblock 371 95 209 minecraft:bone_block
fill 371 95 212 371 95 213 minecraft:bone_block
fill 329 96 185 329 96 186 minecraft:bone_block
fill 329 96 187 329 106 188 minecraft:calcite
setblock 329 96 194 minecraft:bone_block
fill 329 96 196 329 109 196 minecraft:calcite
fill 329 96 197 329 96 198 minecraft:bone_block
fill 329 96 199 329 106 199 minecraft:calcite
fill 329 96 205 329 96 206 minecraft:bone_block
fill 329 96 207 329 109 208 minecraft:calcite
fill 329 96 217 329 96 218 minecraft:bone_block
fill 329 96 219 329 106 220 minecraft:calcite
fill 330 96 182 332 96 182 minecraft:polished_basalt
fill 330 96 184 330 96 186 minecraft:polished_basalt
fill 330 96 188 330 96 190 minecraft:polished_basalt
fill 330 96 192 330 96 194 minecraft:polished_basalt
fill 330 96 196 330 96 198 minecraft:polished_basalt
fill 330 96 200 330 96 202 minecraft:polished_basalt
fill 330 96 204 330 96 206 minecraft:polished_basalt
fill 330 96 208 330 96 210 minecraft:polished_basalt
fill 330 96 212 330 96 214 minecraft:polished_basalt
fill 330 96 216 330 96 218 minecraft:polished_basalt
fill 330 96 220 330 96 222 minecraft:polished_basalt
fill 332 96 222 334 96 222 minecraft:polished_basalt
setblock 332 96 223 minecraft:bone_block
fill 333 96 223 334 109 223 minecraft:calcite
fill 334 96 182 336 96 182 minecraft:polished_basalt
setblock 335 96 223 minecraft:bone_block
fill 336 96 222 338 96 222 minecraft:polished_basalt
fill 337 96 223 337 106 223 minecraft:calcite
fill 338 96 181 339 109 181 minecraft:calcite
fill 338 96 182 340 96 182 minecraft:polished_basalt
fill 340 96 181 341 96 181 minecraft:bone_block
fill 340 96 222 342 96 222 minecraft:polished_basalt
fill 342 96 182 344 96 182 minecraft:polished_basalt
fill 343 96 223 344 96 223 minecraft:bone_block
fill 344 96 222 346 96 222 minecraft:polished_basalt
fill 345 96 223 346 106 223 minecraft:calcite
fill 346 96 182 348 96 182 minecraft:polished_basalt
fill 347 96 181 347 106 181 minecraft:calcite
fill 348 96 181 349 96 181 minecraft:bone_block
fill 348 96 222 350 96 222 minecraft:polished_basalt
fill 350 96 181 350 109 181 minecraft:calcite
fill 350 96 182 352 96 182 minecraft:polished_basalt
setblock 352 96 181 minecraft:bone_block
fill 352 96 222 354 96 222 minecraft:polished_basalt
fill 354 96 182 356 96 182 minecraft:polished_basalt
fill 354 96 223 354 109 223 minecraft:calcite
fill 355 96 223 356 96 223 minecraft:bone_block
fill 356 96 222 358 96 222 minecraft:polished_basalt
fill 357 96 223 358 106 223 minecraft:calcite
fill 358 96 181 359 106 181 minecraft:calcite
fill 358 96 182 360 96 182 minecraft:polished_basalt
fill 360 96 181 361 96 181 minecraft:bone_block
fill 360 96 222 362 96 222 minecraft:polished_basalt
fill 362 96 182 364 96 182 minecraft:polished_basalt
fill 363 96 223 364 96 223 minecraft:bone_block
fill 364 96 222 366 96 222 minecraft:polished_basalt
fill 365 96 223 366 109 223 minecraft:calcite
fill 366 96 182 368 96 182 minecraft:polished_basalt
setblock 367 96 223 minecraft:bone_block
fill 368 96 222 370 96 222 minecraft:polished_basalt
fill 368 96 223 368 107 223 minecraft:calcite
setblock 369 96 181 minecraft:bone_block
fill 370 96 181 371 109 181 minecraft:calcite
fill 370 96 182 370 96 184 minecraft:polished_basalt
fill 370 96 186 370 96 188 minecraft:polished_basalt
fill 370 96 190 370 96 192 minecraft:polished_basalt
fill 370 96 194 370 96 196 minecraft:polished_basalt
fill 370 96 198 370 96 200 minecraft:polished_basalt
fill 370 96 202 370 96 204 minecraft:polished_basalt
fill 370 96 206 370 96 208 minecraft:polished_basalt
fill 370 96 210 370 96 212 minecraft:polished_basalt
fill 370 96 214 370 96 216 minecraft:polished_basalt
fill 370 96 218 370 96 220 minecraft:polished_basalt
fill 371 96 182 371 96 183 minecraft:bone_block
fill 371 96 188 371 106 189 minecraft:calcite
fill 371 96 190 371 96 191 minecraft:bone_block
fill 371 96 192 371 109 192 minecraft:calcite
fill 371 96 200 371 109 201 minecraft:calcite
fill 371 96 202 371 96 203 minecraft:bone_block
fill 371 96 209 371 106 209 minecraft:calcite
fill 371 96 210 371 96 211 minecraft:bone_block
fill 371 96 212 371 109 213 minecraft:calcite
setblock 371 96 214 minecraft:bone_block
fill 371 96 220 371 106 221 minecraft:calcite
setblock 371 96 222 minecraft:bone_block
fill 329 97 185 329 108 186 minecraft:calcite
fill 329 97 194 329 111 194 minecraft:calcite
fill 329 97 197 329 107 198 minecraft:calcite
fill 329 97 205 329 108 206 minecraft:calcite
fill 329 97 217 329 107 218 minecraft:calcite
setblock 332 97 184 minecraft:light[level=12]
setblock 332 97 192 minecraft:light[level=12]
setblock 332 97 200 minecraft:light[level=12]
setblock 332 97 208 minecraft:light[level=12]
setblock 332 97 216 minecraft:light[level=12]
fill 332 97 223 332 111 223 minecraft:calcite
fill 335 97 223 335 107 223 minecraft:calcite
fill 340 97 181 341 108 181 minecraft:calcite
setblock 340 97 184 minecraft:light[level=12]
setblock 340 97 192 minecraft:light[level=12]
setblock 340 97 200 minecraft:light[level=12]
setblock 340 97 208 minecraft:light[level=12]
setblock 340 97 216 minecraft:light[level=12]
fill 343 97 223 344 108 223 minecraft:calcite
fill 348 97 181 349 107 181 minecraft:calcite
setblock 348 97 184 minecraft:light[level=12]
setblock 348 97 192 minecraft:light[level=12]
setblock 348 97 200 minecraft:light[level=12]
setblock 348 97 208 minecraft:light[level=12]
setblock 348 97 216 minecraft:light[level=12]
fill 352 97 181 352 111 181 minecraft:calcite
fill 355 97 223 356 107 223 minecraft:calcite
setblock 356 97 184 minecraft:light[level=12]
setblock 356 97 192 minecraft:light[level=12]
setblock 356 97 200 minecraft:light[level=12]
setblock 356 97 208 minecraft:light[level=12]
setblock 356 97 216 minecraft:light[level=12]
fill 360 97 181 361 108 181 minecraft:calcite
fill 363 97 223 364 108 223 minecraft:calcite
setblock 364 97 184 minecraft:light[level=12]
setblock 364 97 192 minecraft:light[level=12]
setblock 364 97 200 minecraft:light[level=12]
setblock 364 97 208 minecraft:light[level=12]
setblock 364 97 216 minecraft:light[level=12]
fill 367 97 223 367 107 223 minecraft:calcite
fill 369 97 181 369 107 181 minecraft:calcite
fill 371 97 182 371 111 183 minecraft:calcite
fill 371 97 190 371 107 191 minecraft:calcite
fill 371 97 202 371 108 203 minecraft:calcite
fill 371 97 210 371 107 211 minecraft:calcite
fill 371 97 214 371 111 214 minecraft:calcite
fill 371 97 222 371 107 222 minecraft:calcite
fill 330 102 182 331 103 222 minecraft:smooth_basalt
fill 332 102 182 332 103 222 minecraft:bone_block
fill 333 102 182 334 103 222 minecraft:smooth_basalt
fill 335 102 182 335 103 222 minecraft:bone_block
fill 336 102 182 337 103 222 minecraft:smooth_basalt
fill 338 102 182 338 103 222 minecraft:bone_block
fill 339 102 182 340 103 222 minecraft:smooth_basalt
fill 341 102 182 341 103 222 minecraft:bone_block
fill 342 102 182 343 103 222 minecraft:smooth_basalt
fill 344 102 182 344 103 222 minecraft:bone_block
fill 345 102 182 346 102 222 minecraft:smooth_basalt
fill 347 102 182 347 102 198 minecraft:bone_block
fill 347 102 200 347 102 222 minecraft:bone_block
fill 348 102 182 349 102 196 minecraft:smooth_basalt
fill 348 102 202 349 102 222 minecraft:smooth_basalt
fill 350 102 182 350 102 195 minecraft:bone_block
fill 350 102 203 350 102 222 minecraft:bone_block
fill 351 102 182 352 102 196 minecraft:smooth_basalt
fill 351 102 202 352 102 222 minecraft:smooth_basalt
fill 353 102 182 353 102 198 minecraft:bone_block
fill 353 102 200 353 102 222 minecraft:bone_block
fill 354 102 182 355 102 222 minecraft:smooth_basalt
fill 356 102 182 356 103 222 minecraft:bone_block
fill 357 102 182 358 103 222 minecraft:smooth_basalt
fill 359 102 182 359 103 222 minecraft:bone_block
fill 360 102 182 361 103 222 minecraft:smooth_basalt
fill 362 102 182 362 103 222 minecraft:bone_block
fill 363 102 182 364 103 222 minecraft:smooth_basalt
fill 365 102 182 365 103 222 minecraft:bone_block
fill 366 102 182 367 103 222 minecraft:smooth_basalt
fill 368 102 182 368 103 222 minecraft:bone_block
fill 369 102 182 370 103 222 minecraft:smooth_basalt
fill 345 103 182 345 103 222 minecraft:smooth_basalt
fill 346 103 182 346 103 197 minecraft:smooth_basalt
fill 346 103 198 346 103 200 minecraft:ochre_froglight
fill 346 103 201 346 103 222 minecraft:smooth_basalt
fill 347 103 182 347 103 195 minecraft:bone_block
fill 347 103 196 347 103 198 minecraft:ochre_froglight
fill 347 103 200 347 103 202 minecraft:ochre_froglight
fill 347 103 203 347 103 222 minecraft:bone_block
fill 348 103 182 348 103 195 minecraft:smooth_basalt
fill 348 103 196 349 103 196 minecraft:ochre_froglight
fill 348 103 202 349 103 202 minecraft:ochre_froglight
fill 348 103 203 348 103 222 minecraft:smooth_basalt
fill 349 103 182 349 103 194 minecraft:smooth_basalt
fill 349 103 195 351 103 195 minecraft:ochre_froglight
fill 349 103 203 351 103 203 minecraft:ochre_froglight
fill 349 103 204 349 103 222 minecraft:smooth_basalt
fill 350 103 182 350 103 194 minecraft:bone_block
fill 350 103 204 350 103 222 minecraft:bone_block
fill 351 103 182 352 103 194 minecraft:smooth_basalt
fill 351 103 196 353 103 196 minecraft:ochre_froglight
fill 351 103 202 353 103 202 minecraft:ochre_froglight
fill 351 103 204 352 103 222 minecraft:smooth_basalt
setblock 352 103 195 minecraft:smooth_basalt
setblock 352 103 203 minecraft:smooth_basalt
fill 353 103 182 353 103 195 minecraft:bone_block
fill 353 103 197 353 103 198 minecraft:ochre_froglight
fill 353 103 200 353 103 201 minecraft:ochre_froglight
fill 353 103 203 353 103 222 minecraft:bone_block
fill 354 103 182 355 103 197 minecraft:smooth_basalt
fill 354 103 198 354 103 200 minecraft:ochre_froglight
fill 354 103 201 355 103 222 minecraft:smooth_basalt
fill 355 103 198 355 103 200 minecraft:smooth_basalt
setblock 332 105 184 minecraft:light[level=12]
setblock 332 105 192 minecraft:light[level=12]
setblock 332 105 200 minecraft:light[level=12]
setblock 332 105 208 minecraft:light[level=12]
setblock 332 105 216 minecraft:light[level=12]
setblock 340 105 184 minecraft:light[level=12]
setblock 340 105 192 minecraft:light[level=12]
setblock 340 105 200 minecraft:light[level=12]
setblock 340 105 208 minecraft:light[level=12]
setblock 340 105 216 minecraft:light[level=12]
setblock 348 105 184 minecraft:light[level=12]
setblock 348 105 192 minecraft:light[level=12]
setblock 348 105 208 minecraft:light[level=12]
setblock 348 105 216 minecraft:light[level=12]
setblock 356 105 184 minecraft:light[level=12]
setblock 356 105 192 minecraft:light[level=12]
setblock 356 105 200 minecraft:light[level=12]
setblock 356 105 208 minecraft:light[level=12]
setblock 356 105 216 minecraft:light[level=12]
setblock 364 105 184 minecraft:light[level=12]
setblock 364 105 192 minecraft:light[level=12]
setblock 364 105 200 minecraft:light[level=12]
setblock 364 105 208 minecraft:light[level=12]
setblock 364 105 216 minecraft:light[level=12]
fill 329 107 187 329 109 187 minecraft:calcite
setblock 329 107 188 minecraft:bone_block
fill 329 107 191 329 107 192 minecraft:bone_block
fill 329 107 199 329 107 200 minecraft:bone_block
fill 329 107 211 329 107 212 minecraft:bone_block
fill 329 107 219 329 109 219 minecraft:calcite
setblock 329 107 220 minecraft:bone_block
setblock 329 107 223 minecraft:bone_block
fill 330 107 223 330 110 223 minecraft:calcite
fill 334 107 181 335 107 181 minecraft:bone_block
fill 337 107 223 338 107 223 minecraft:bone_block
fill 345 107 223 345 109 223 minecraft:calcite
fill 346 107 181 347 107 181 minecraft:bone_block
setblock 346 107 223 minecraft:bone_block
fill 349 107 223 350 107 223 minecraft:bone_block
fill 354 107 181 355 107 181 minecraft:bone_block
fill 357 107 223 358 107 223 minecraft:bone_block
setblock 358 107 181 minecraft:bone_block
fill 359 107 181 359 109 181 minecraft:calcite
setblock 361 107 223 minecraft:bone_block
fill 362 107 223 362 110 223 minecraft:calcite
fill 366 107 181 367 107 181 minecraft:bone_block
fill 369 107 223 370 107 223 minecraft:bone_block
fill 371 107 184 371 110 184 minecraft:calcite
setblock 371 107 185 minecraft:bone_block
fill 371 107 188 371 107 189 minecraft:bone_block
fill 371 107 196 371 107 197 minecraft:bone_block
fill 371 107 208 371 107 209 minecraft:bone_block
fill 371 107 216 371 110 216 minecraft:calcite
setblock 371 107 217 minecraft:bone_block
setblock 371 107 220 minecraft:bone_block
fill 371 107 221 371 109 221 minecraft:calcite
fill 329 108 188 329 113 188 minecraft:calcite
fill 329 108 189 329 108 190 minecraft:bone_block
fill 329 108 191 329 113 192 minecraft:calcite
fill 329 108 197 329 109 198 minecraft:bone_block
fill 329 108 199 329 113 200 minecraft:calcite
setblock 329 108 201 minecraft:bone_block
fill 329 108 202 329 111 202 minecraft:calcite
fill 329 108 209 329 109 210 minecraft:bone_block
fill 329 108 211 329 113 212 minecraft:calcite
setblock 329 108 217 minecraft:calcite
fill 329 108 218 329 109 218 minecraft:bone_block
fill 329 108 220 329 113 220 minecraft:calcite
fill 329 108 221 329 108 222 minecraft:bone_block
fill 329 108 223 329 113 223 minecraft:calcite
fill 330 108 182 332 108 182 minecraft:polished_basalt
fill 330 108 184 330 108 186 minecraft:polished_basalt
fill 330 108 188 330 108 190 minecraft:polished_basalt
fill 330 108 192 330 108 194 minecraft:polished_basalt
fill 330 108 196 330 108 198 minecraft:polished_basalt
fill 330 108 200 330 108 202 minecraft:polished_basalt
fill 330 108 204 330 108 206 minecraft:polished_basalt
fill 330 108 208 330 108 210 minecraft:polished_basalt
fill 330 108 212 330 108 214 minecraft:polished_basalt
fill 330 108 216 330 108 218 minecraft:polished_basalt
fill 330 108 220 330 108 222 minecraft:polished_basalt
fill 332 108 222 334 108 222 minecraft:polished_basalt
fill 334 108 181 335 113 181 minecraft:calcite
fill 334 108 182 336 108 182 minecraft:polished_basalt
fill 335 108 223 336 109 223 minecraft:bone_block
fill 336 108 181 337 109 181 minecraft:bone_block
fill 336 108 222 338 108 222 minecraft:polished_basalt
fill 337 108 223 338 113 223 minecraft:calcite
fill 338 108 182 340 108 182 minecraft:polished_basalt
fill 340 108 222 342 108 222 minecraft:polished_basalt
fill 342 108 182 344 108 182 minecraft:polished_basalt
fill 344 108 181 344 111 181 minecraft:calcite
fill 344 108 222 346 108 222 minecraft:polished_basalt
setblock 345 108 181 minecraft:bone_block
fill 346 108 181 347 113 181 minecraft:calcite
fill 346 108 182 348 108 182 minecraft:polished_basalt
fill 346 108 223 346 109 223 minecraft:calcite
fill 347 108 223 348 108 223 minecraft:bone_block
fill 348 108 181 349 109 181 minecraft:bone_block
fill 348 108 222 350 108 222 minecraft:polished_basalt
fill 349 108 223 350 113 223 minecraft:calcite
fill 350 108 182 352 108 182 minecraft:polished_basalt
fill 352 108 222 354 108 222 minecraft:polished_basalt
fill 354 108 181 355 113 181 minecraft:calcite
fill 354 108 182 356 108 182 minecraft:polished_basalt
fill 355 108 223 356 109 223 minecraft:bone_block
fill 356 108 181 357 108 181 minecraft:bone_block
fill 356 108 222 358 108 222 minecraft:polished_basalt
fill 357 108 223 358 113 223 minecraft:calcite
fill 358 108 181 358 113 181 minecraft:calcite
fill 358 108 182 360 108 182 minecraft:polished_basalt
fill 359 108 189 360 109 190 minecraft:calcite
setblock 359 108 223 minecraft:bone_block
fill 360 108 222 362 108 222 minecraft:polished_basalt
fill 360 108 223 361 110 223 minecraft:calcite
fill 362 108 182 364 108 182 minecraft:polished_basalt
fill 364 108 222 366 108 222 minecraft:polished_basalt
fill 366 108 181 367 113 181 minecraft:calcite
fill 366 108 182 368 108 182 minecraft:polished_basalt
fill 367 108 223 368 109 223 minecraft:bone_block
fill 368 108 181 369 109 181 minecraft:bone_block
fill 368 108 222 370 108 222 minecraft:polished_basalt
fill 369 108 223 370 113 223 minecraft:calcite
fill 370 108 182 370 108 184 minecraft:polished_basalt
fill 370 108 186 370 108 188 minecraft:polished_basalt
fill 370 108 190 370 108 192 minecraft:polished_basalt
fill 370 108 194 370 108 196 minecraft:polished_basalt
fill 370 108 198 370 108 200 minecraft:polished_basalt
fill 370 108 202 370 108 204 minecraft:polished_basalt
fill 370 108 206 370 108 208 minecraft:polished_basalt
fill 370 108 210 370 108 212 minecraft:polished_basalt
fill 370 108 214 370 108 216 minecraft:polished_basalt
fill 370 108 218 370 108 220 minecraft:polished_basalt
fill 371 108 185 371 111 186 minecraft:calcite
setblock 371 108 187 minecraft:bone_block
fill 371 108 188 371 113 189 minecraft:calcite
fill 371 108 190 371 109 190 minecraft:bone_block
setblock 371 108 191 minecraft:calcite
fill 371 108 196 371 113 197 minecraft:calcite
fill 371 108 198 371 108 199 minecraft:bone_block
fill 371 108 208 371 113 209 minecraft:calcite
fill 371 108 210 371 109 211 minecraft:bone_block
fill 371 108 217 371 113 217 minecraft:calcite
fill 371 108 218 371 108 219 minecraft:bone_block
fill 371 108 220 371 113 220 minecraft:calcite
fill 371 108 222 371 109 222 minecraft:bone_block
fill 329 109 185 329 109 186 minecraft:bone_block
setblock 329 109 189 minecraft:bone_block
fill 329 109 190 329 112 190 minecraft:calcite
fill 329 109 201 329 112 201 minecraft:calcite
fill 329 109 205 329 111 205 minecraft:calcite
setblock 329 109 206 minecraft:bone_block
setblock 329 109 217 minecraft:bone_block
fill 329 109 221 329 112 222 minecraft:calcite
setblock 340 109 181 minecraft:bone_block
fill 341 109 181 341 111 181 minecraft:calcite
fill 343 109 223 344 109 223 minecraft:bone_block
fill 345 109 181 345 112 181 minecraft:calcite
setblock 347 109 223 minecraft:bone_block
fill 348 109 223 348 112 223 minecraft:calcite
fill 356 109 181 356 112 181 minecraft:calcite
setblock 357 109 181 minecraft:bone_block
fill 359 109 223 359 112 223 minecraft:calcite
fill 360 109 181 361 109 181 minecraft:bone_block
fill 363 109 223 363 111 223 minecraft:calcite
setblock 364 109 223 minecraft:bone_block
fill 371 109 187 371 112 187 minecraft:calcite
setblock 371 109 191 minecraft:bone_block
fill 371 109 198 371 112 198 minecraft:calcite
setblock 371 109 199 minecraft:bone_block
setblock 371 109 202 minecraft:bone_block
fill 371 109 203 371 111 203 minecraft:calcite
fill 371 109 218 371 112 219 minecraft:calcite
setblock 329 110 183 minecraft:calcite
fill 329 110 184 329 111 184 minecraft:bone_block
fill 329 110 185 329 115 186 minecraft:calcite
setblock 329 110 187 minecraft:bone_block
fill 329 110 189 329 115 189 minecraft:calcite
fill 329 110 195 329 111 196 minecraft:bone_block
fill 329 110 197 329 115 198 minecraft:calcite
fill 329 110 206 329 115 206 minecraft:calcite
fill 329 110 207 329 110 208 minecraft:bone_block
fill 329 110 209 329 115 210 minecraft:calcite
fill 329 110 215 329 111 216 minecraft:bone_block
fill 329 110 217 329 115 218 minecraft:calcite
setblock 329 110 219 minecraft:bone_block
fill 330 110 181 331 111 181 minecraft:bone_block
fill 333 110 223 334 111 223 minecraft:bone_block
fill 335 110 223 336 115 223 minecraft:calcite
fill 336 110 181 337 115 181 minecraft:calcite
fill 338 110 181 339 110 181 minecraft:bone_block
fill 340 110 181 340 115 181 minecraft:calcite
setblock 341 110 223 minecraft:calcite
fill 342 110 223 342 111 223 minecraft:bone_block
fill 343 110 223 344 111 223 minecraft:calcite
fill 345 110 223 346 110 223 minecraft:bone_block
fill 347 110 223 347 115 223 minecraft:calcite
fill 348 110 181 349 115 181 minecraft:calcite
fill 350 110 181 351 111 181 minecraft:bone_block
fill 353 110 223 354 111 223 minecraft:bone_block
fill 355 110 223 356 115 223 minecraft:calcite
fill 357 110 181 357 115 181 minecraft:calcite
setblock 359 110 181 minecraft:bone_block
fill 360 110 181 361 115 181 minecraft:calcite
fill 362 110 181 362 111 181 minecraft:bone_block
setblock 363 110 181 minecraft:calcite
fill 364 110 223 364 111 223 minecraft:calcite
fill 365 110 223 366 110 223 minecraft:bone_block
fill 367 110 223 368 115 223 minecraft:calcite
fill 368 110 181 369 115 181 minecraft:calcite
fill 370 110 181 371 110 181 minecraft:bone_block
fill 371 110 190 371 115 191 minecraft:calcite
fill 371 110 192 371 111 193 minecraft:bone_block
fill 371 110 199 371 115 199 minecraft:calcite
fill 371 110 200 371 110 201 minecraft:bone_block
fill 371 110 202 371 115 202 minecraft:calcite
fill 371 110 204 371 111 204 minecraft:bone_block
setblock 371 110 205 minecraft:calcite
fill 371 110 210 371 115 211 minecraft:calcite
fill 371 110 212 371 111 213 minecraft:bone_block
setblock 371 110 221 minecraft:bone_block
fill 371 110 222 371 115 222 minecraft:calcite
setblock 329 111 183 minecraft:bone_block
fill 329 111 187 329 114 187 minecraft:calcite
fill 329 111 203 329 111 204 minecraft:bone_block
setblock 329 111 207 minecraft:bone_block
fill 329 111 208 329 114 208 minecraft:calcite
fill 329 111 219 329 114 219 minecraft:calcite
setblock 330 111 223 minecraft:bone_block
fill 338 111 181 338 114 181 minecraft:calcite
setblock 339 111 181 minecraft:bone_block
setblock 341 111 223 minecraft:bone_block
fill 342 111 181 343 111 181 minecraft:bone_block
fill 345 111 223 346 113 223 minecraft:calcite
fill 359 111 181 359 114 181 minecraft:calcite
setblock 360 111 223 minecraft:calcite
fill 361 111 223 362 111 223 minecraft:bone_block
setblock 363 111 181 minecraft:bone_block
setblock 365 111 223 minecraft:bone_block
fill 366 111 223 366 114 223 minecraft:calcite
fill 370 111 181 370 114 181 minecraft:calcite
setblock 371 111 181 minecraft:bone_block
setblock 371 111 184 minecraft:bone_block
fill 371 111 200 371 114 201 minecraft:calcite
setblock 371 111 205 minecraft:bone_block
setblock 371 111 216 minecraft:bone_block
fill 371 111 221 371 114 221 minecraft:calcite
fill 329 112 181 329 113 182 minecraft:bone_block
fill 329 112 183 329 117 184 minecraft:calcite
fill 329 112 193 329 112 194 minecraft:bone_block
fill 329 112 195 329 117 196 minecraft:calcite
fill 329 112 202 329 113 202 minecraft:bone_block
fill 329 112 203 329 117 204 minecraft:calcite
setblock 329 112 205 minecraft:bone_block
fill 329 112 207 329 117 207 minecraft:calcite
fill 329 112 213 329 113 214 minecraft:bone_block
fill 329 112 215 329 117 216 minecraft:calcite
fill 330 112 181 331 117 181 minecraft:calcite
fill 330 112 223 330 117 223 minecraft:calcite
fill 331 112 223 332 112 223 minecraft:bone_block
fill 332 112 181 333 113 181 minecraft:bone_block
fill 333 112 223 334 114 223 minecraft:calcite
fill 339 112 181 339 117 181 minecraft:calcite
fill 339 112 223 340 113 223 minecraft:bone_block
setblock 341 112 181 minecraft:bone_block
fill 341 112 223 342 117 223 minecraft:calcite
fill 342 112 181 343 117 181 minecraft:calcite
fill 342 112 217 342 113 218 minecraft:bone_block
setblock 343 112 223 minecraft:bone_block
fill 344 112 181 344 113 181 minecraft:bone_block
fill 344 112 223 344 115 223 minecraft:calcite
fill 350 112 181 351 117 181 minecraft:calcite
fill 351 112 223 352 113 223 minecraft:bone_block
fill 352 112 181 353 112 181 minecraft:bone_block
fill 353 112 223 354 117 223 minecraft:calcite
fill 360 112 223 360 113 223 minecraft:bone_block
fill 361 112 223 362 113 223 minecraft:calcite
fill 362 112 181 363 117 181 minecraft:calcite
fill 363 112 223 364 112 223 minecraft:bone_block
fill 364 112 181 365 113 181 minecraft:bone_block
fill 365 112 223 365 117 223 minecraft:calcite
fill 371 112 181 371 117 181 minecraft:calcite
fill 371 112 182 371 112 183 minecraft:bone_block
fill 371 112 184 371 113 185 minecraft:calcite
fill 371 112 186 371 113 186 minecraft:bone_block
fill 371 112 192 371 117 193 minecraft:calcite
fill 371 112 194 371 113 195 minecraft:bone_block
setblock 371 112 203 minecraft:bone_block
fill 371 112 204 371 117 205 minecraft:calcite
fill 371 112 206 371 113 207 minecraft:bone_block
fill 371 112 212 371 117 213 minecraft:calcite
fill 371 112 214 371 112 215 minecraft:bone_block
fill 371 112 216 371 117 216 minecraft:calcite
fill 371 112 223 371 113 223 minecraft:bone_block
setblock 329 113 190 minecraft:bone_block
setblock 329 113 193 minecraft:bone_block
fill 329 113 194 329 116 194 minecraft:calcite
setblock 329 113 201 minecraft:bone_block
fill 329 113 205 329 116 205 minecraft:calcite
fill 329 113 221 329 113 222 minecraft:bone_block
setblock 331 113 223 minecraft:bone_block
setblock 332 113 184 minecraft:light[level=12]
setblock 332 113 192 minecraft:light[level=12]
setblock 332 113 200 minecraft:light[level=12]
setblock 332 113 208 minecraft:light[level=12]
setblock 332 113 216 minecraft:light[level=12]
fill 332 113 223 332 116 223 minecraft:calcite
setblock 340 113 184 minecraft:light[level=12]
setblock 340 113 192 minecraft:light[level=12]
setblock 340 113 200 minecraft:light[level=12]
setblock 340 113 208 minecraft:light[level=12]
setblock 340 113 216 minecraft:light[level=12]
fill 341 113 181 341 116 181 minecraft:calcite
fill 343 113 223 343 115 223 minecraft:calcite
setblock 345 113 181 minecraft:bone_block
setblock 348 113 184 minecraft:light[level=12]
setblock 348 113 192 minecraft:light[level=12]
setblock 348 113 200 minecraft:light[level=12]
setblock 348 113 208 minecraft:light[level=12]
setblock 348 113 216 minecraft:light[level=12]
setblock 348 113 223 minecraft:bone_block
fill 352 113 181 352 116 181 minecraft:calcite
setblock 353 113 181 minecraft:bone_block
setblock 356 113 181 minecraft:bone_block
setblock 356 113 184 minecraft:light[level=12]
setblock 356 113 192 minecraft:light[level=12]
setblock 356 113 200 minecraft:light[level=12]
setblock 356 113 208 minecraft:light[level=12]
setblock 356 113 216 minecraft:light[level=12]
setblock 359 113 223 minecraft:bone_block
fill 363 113 223 364 115 223 minecraft:calcite
setblock 364 113 184 minecraft:light[level=12]
setblock 364 113 192 minecraft:light[level=12]
setblock 364 113 200 minecraft:light[level=12]
setblock 364 113 208 minecraft:light[level=12]
setblock 364 113 216 minecraft:light[level=12]
fill 371 113 182 371 116 183 minecraft:calcite
setblock 371 113 187 minecraft:bone_block
setblock 371 113 198 minecraft:bone_block
fill 371 113 203 371 116 203 minecraft:calcite
fill 371 113 214 371 116 214 minecraft:calcite
setblock 371 113 215 minecraft:bone_block
fill 371 113 218 371 113 219 minecraft:bone_block
fill 329 114 181 329 119 182 minecraft:calcite
fill 329 114 188 329 115 188 minecraft:bone_block
fill 329 114 190 329 119 190 minecraft:calcite
fill 329 114 191 329 114 192 minecraft:bone_block
fill 329 114 193 329 119 193 minecraft:calcite
schedule function dropper:buildpart/43_3 1t
