fill 534 242 512 534 243 512 minecraft:gray_concrete
fill 534 242 516 535 243 518 minecraft:black_concrete
fill 534 242 519 534 243 519 minecraft:gray_concrete
fill 534 242 523 539 243 523 minecraft:black_concrete
fill 534 242 526 534 243 526 minecraft:gray_concrete
fill 534 242 530 534 242 532 minecraft:black_concrete
fill 534 242 533 534 243 533 minecraft:gray_concrete
fill 534 242 537 534 242 539 minecraft:black_concrete
setblock 534 242 540 minecraft:gray_concrete
fill 534 242 544 539 243 544 minecraft:black_concrete
fill 534 242 547 534 243 547 minecraft:gray_concrete
fill 534 242 551 539 243 551 minecraft:black_concrete
fill 535 242 510 535 243 510 minecraft:blue_concrete
fill 535 242 512 536 243 514 minecraft:black_concrete
fill 535 242 515 535 243 515 minecraft:gray_concrete
fill 535 242 519 536 243 521 minecraft:black_concrete
fill 535 242 522 535 243 522 minecraft:gray_concrete
fill 535 242 526 536 242 528 minecraft:black_concrete
fill 535 242 532 535 242 535 minecraft:black_concrete
setblock 535 242 536 minecraft:gray_concrete
fill 535 242 540 536 242 542 minecraft:black_concrete
fill 535 242 543 535 243 543 minecraft:gray_concrete
fill 535 242 547 540 243 547 minecraft:black_concrete
fill 535 242 550 535 243 550 minecraft:gray_concrete
fill 536 242 511 536 243 511 minecraft:gray_concrete
fill 536 242 515 537 243 517 minecraft:black_concrete
fill 536 242 518 536 243 518 minecraft:gray_concrete
fill 536 242 522 541 243 522 minecraft:black_concrete
fill 536 242 525 536 243 525 minecraft:gray_concrete
setblock 536 242 532 minecraft:gray_concrete
fill 536 242 533 536 242 536 minecraft:black_concrete
fill 536 242 543 541 243 543 minecraft:black_concrete
fill 536 242 546 536 243 546 minecraft:gray_concrete
fill 536 242 550 541 243 550 minecraft:black_concrete
fill 537 242 511 538 243 513 minecraft:black_concrete
fill 537 242 514 537 243 514 minecraft:gray_concrete
fill 537 242 518 538 243 520 minecraft:black_concrete
fill 537 242 521 537 243 521 minecraft:gray_concrete
fill 537 242 525 538 243 527 minecraft:black_concrete
setblock 537 242 528 minecraft:gray_concrete
fill 537 242 532 537 242 534 minecraft:black_concrete
setblock 537 242 535 minecraft:gray_concrete
fill 537 242 536 541 242 536 minecraft:black_concrete
fill 537 242 540 538 242 541 minecraft:black_concrete
fill 537 242 542 537 243 542 minecraft:gray_concrete
fill 537 242 546 542 243 546 minecraft:black_concrete
fill 537 242 549 537 243 549 minecraft:gray_concrete
fill 537 242 552 537 243 552 minecraft:blue_concrete
fill 538 242 514 539 243 516 minecraft:black_concrete
fill 538 242 517 538 243 517 minecraft:gray_concrete
fill 538 242 521 543 243 521 minecraft:black_concrete
fill 538 242 524 538 243 524 minecraft:gray_concrete
fill 538 242 528 539 242 530 minecraft:black_concrete
setblock 538 242 531 minecraft:gray_concrete
fill 538 242 532 541 242 532 minecraft:black_concrete
fill 538 242 537 539 242 537 minecraft:black_concrete
setblock 538 242 538 minecraft:gray_concrete
fill 538 242 539 540 242 539 minecraft:black_concrete
fill 538 242 542 543 243 542 minecraft:black_concrete
fill 538 242 545 538 243 545 minecraft:gray_concrete
fill 538 242 549 543 243 549 minecraft:black_concrete
fill 539 242 511 540 243 512 minecraft:black_concrete
fill 539 242 513 539 243 513 minecraft:gray_concrete
fill 539 242 517 540 243 519 minecraft:black_concrete
fill 539 242 520 539 243 520 minecraft:gray_concrete
fill 539 242 524 540 243 526 minecraft:black_concrete
fill 539 242 527 539 243 527 minecraft:gray_concrete
fill 539 242 531 541 242 531 minecraft:black_concrete
fill 539 242 538 540 242 538 minecraft:black_concrete
fill 539 242 540 540 242 540 minecraft:black_concrete
fill 539 242 541 539 243 541 minecraft:gray_concrete
fill 539 242 545 544 243 545 minecraft:black_concrete
fill 539 242 548 539 243 548 minecraft:gray_concrete
fill 540 242 513 541 243 515 minecraft:black_concrete
fill 540 242 516 540 243 516 minecraft:gray_concrete
fill 540 242 520 545 243 520 minecraft:black_concrete
fill 540 242 523 540 243 523 minecraft:gray_concrete
fill 540 242 527 541 242 529 minecraft:black_concrete
fill 540 242 530 540 243 530 minecraft:gray_concrete
setblock 540 242 537 minecraft:gray_concrete
fill 540 242 541 545 243 541 minecraft:black_concrete
fill 540 242 544 540 243 544 minecraft:gray_concrete
fill 540 242 548 545 243 548 minecraft:black_concrete
fill 540 242 551 540 243 551 minecraft:gray_concrete
fill 541 242 510 542 243 510 minecraft:blue_concrete
fill 541 242 511 542 243 511 minecraft:black_concrete
fill 541 242 512 541 243 512 minecraft:gray_concrete
fill 541 242 516 542 243 518 minecraft:black_concrete
fill 541 242 519 541 243 519 minecraft:gray_concrete
fill 541 242 523 542 243 525 minecraft:black_concrete
fill 541 242 526 541 243 526 minecraft:gray_concrete
setblock 541 242 530 minecraft:black_concrete
setblock 541 242 533 minecraft:gray_concrete
fill 541 242 534 543 242 535 minecraft:black_concrete
setblock 541 242 540 minecraft:gray_concrete
fill 541 242 544 546 243 544 minecraft:black_concrete
fill 541 242 547 541 243 547 minecraft:gray_concrete
fill 541 242 551 542 242 552 minecraft:black_concrete
fill 542 242 512 543 243 514 minecraft:black_concrete
fill 542 242 515 542 243 515 minecraft:gray_concrete
fill 542 242 519 547 243 519 minecraft:black_concrete
fill 542 242 522 542 243 522 minecraft:gray_concrete
fill 542 242 526 543 243 528 minecraft:black_concrete
setblock 542 242 529 minecraft:gray_concrete
fill 542 242 533 547 242 533 minecraft:black_concrete
setblock 542 242 536 minecraft:gray_concrete
fill 542 242 540 547 242 540 minecraft:black_concrete
fill 542 242 543 542 243 543 minecraft:gray_concrete
fill 542 242 547 547 243 547 minecraft:black_concrete
fill 542 242 550 542 243 550 minecraft:gray_concrete
fill 543 242 511 543 243 511 minecraft:gray_concrete
fill 543 242 515 544 243 517 minecraft:black_concrete
fill 543 242 518 543 243 518 minecraft:gray_concrete
fill 543 242 522 544 243 524 minecraft:black_concrete
fill 543 242 525 543 243 525 minecraft:gray_concrete
fill 543 242 529 548 242 529 minecraft:black_concrete
fill 543 242 536 548 242 536 minecraft:black_concrete
fill 543 242 543 548 243 543 minecraft:black_concrete
fill 543 242 546 543 243 546 minecraft:gray_concrete
fill 543 242 550 546 243 551 minecraft:black_concrete
fill 544 242 511 545 243 513 minecraft:black_concrete
fill 544 242 514 544 243 514 minecraft:gray_concrete
fill 544 242 518 549 243 518 minecraft:black_concrete
fill 544 242 521 544 243 521 minecraft:gray_concrete
fill 544 242 525 545 243 527 minecraft:black_concrete
fill 544 242 528 544 243 528 minecraft:gray_concrete
fill 544 242 534 545 243 534 minecraft:black_concrete
fill 544 242 535 544 243 535 minecraft:gray_concrete
fill 544 242 537 544 242 539 minecraft:black_concrete
fill 544 242 542 544 243 542 minecraft:gray_concrete
fill 544 242 546 549 243 546 minecraft:black_concrete
fill 544 242 549 544 243 549 minecraft:gray_concrete
fill 545 242 510 545 243 510 minecraft:blue_concrete
fill 545 242 514 546 243 516 minecraft:black_concrete
fill 545 242 517 545 243 517 minecraft:gray_concrete
fill 545 242 521 546 243 523 minecraft:black_concrete
fill 545 242 524 545 243 524 minecraft:gray_concrete
fill 545 242 528 550 243 528 minecraft:black_concrete
fill 545 242 530 546 242 530 minecraft:black_concrete
setblock 545 242 531 minecraft:gray_concrete
fill 545 242 532 549 242 532 minecraft:black_concrete
fill 545 242 535 550 243 535 minecraft:black_concrete
fill 545 242 537 546 243 537 minecraft:black_concrete
fill 545 242 538 545 243 538 minecraft:gray_concrete
fill 545 242 539 549 243 539 minecraft:black_concrete
fill 545 242 542 550 243 542 minecraft:black_concrete
fill 545 242 545 545 243 545 minecraft:gray_concrete
fill 545 242 549 550 243 549 minecraft:black_concrete
fill 546 242 511 547 243 512 minecraft:black_concrete
fill 546 242 513 546 243 513 minecraft:gray_concrete
fill 546 242 517 551 243 517 minecraft:black_concrete
fill 546 242 520 546 243 520 minecraft:gray_concrete
fill 546 242 524 547 243 526 minecraft:black_concrete
fill 546 242 527 546 243 527 minecraft:gray_concrete
fill 546 242 531 551 243 531 minecraft:black_concrete
fill 546 242 534 546 243 534 minecraft:gray_concrete
fill 546 242 538 551 243 538 minecraft:black_concrete
fill 546 242 541 546 243 541 minecraft:gray_concrete
fill 546 242 545 551 243 545 minecraft:black_concrete
fill 546 242 548 546 243 548 minecraft:gray_concrete
fill 547 242 513 548 243 515 minecraft:black_concrete
fill 547 242 516 547 243 516 minecraft:gray_concrete
fill 547 242 520 548 243 522 minecraft:black_concrete
fill 547 242 523 547 243 523 minecraft:gray_concrete
fill 547 242 527 552 243 527 minecraft:black_concrete
fill 547 242 530 547 243 530 minecraft:gray_concrete
fill 547 242 534 552 243 534 minecraft:black_concrete
fill 547 242 537 547 243 537 minecraft:gray_concrete
fill 547 242 541 552 243 541 minecraft:black_concrete
fill 547 242 544 547 243 544 minecraft:gray_concrete
fill 547 242 548 552 243 548 minecraft:black_concrete
fill 547 242 550 548 243 550 minecraft:black_concrete
fill 547 242 551 547 243 551 minecraft:gray_concrete
fill 547 242 552 548 242 552 minecraft:black_concrete
fill 548 242 511 549 243 511 minecraft:black_concrete
fill 548 242 512 548 243 512 minecraft:gray_concrete
fill 548 242 516 553 243 516 minecraft:black_concrete
fill 548 242 519 548 243 519 minecraft:gray_concrete
fill 548 242 523 549 243 525 minecraft:black_concrete
fill 548 242 526 548 243 526 minecraft:gray_concrete
fill 548 242 530 553 243 530 minecraft:black_concrete
fill 548 242 533 548 243 533 minecraft:gray_concrete
fill 548 242 537 553 243 537 minecraft:black_concrete
fill 548 242 540 548 243 540 minecraft:gray_concrete
fill 548 242 544 553 243 544 minecraft:black_concrete
fill 548 242 547 548 243 547 minecraft:gray_concrete
fill 548 242 551 553 243 551 minecraft:black_concrete
fill 549 242 512 550 243 514 minecraft:black_concrete
fill 549 242 515 549 243 515 minecraft:gray_concrete
fill 549 242 519 550 243 521 minecraft:black_concrete
fill 549 242 522 549 243 522 minecraft:gray_concrete
fill 549 242 526 554 243 526 minecraft:black_concrete
fill 549 242 529 549 243 529 minecraft:gray_concrete
fill 549 242 533 554 243 533 minecraft:black_concrete
fill 549 242 536 549 243 536 minecraft:gray_concrete
fill 549 242 540 554 243 540 minecraft:black_concrete
fill 549 242 543 549 243 543 minecraft:gray_concrete
fill 549 242 547 554 243 547 minecraft:black_concrete
fill 549 242 550 549 243 550 minecraft:gray_concrete
fill 549 242 552 549 243 552 minecraft:blue_concrete
fill 550 242 511 550 243 511 minecraft:gray_concrete
fill 550 242 515 555 243 515 minecraft:black_concrete
fill 550 242 518 550 243 518 minecraft:gray_concrete
fill 550 242 522 551 243 524 minecraft:black_concrete
fill 550 242 525 550 243 525 minecraft:gray_concrete
fill 550 242 529 555 243 529 minecraft:black_concrete
fill 550 242 532 550 243 532 minecraft:gray_concrete
fill 550 242 536 555 243 536 minecraft:black_concrete
fill 550 242 539 550 243 539 minecraft:gray_concrete
fill 550 242 543 555 243 543 minecraft:black_concrete
fill 550 242 546 550 243 546 minecraft:gray_concrete
fill 550 242 550 555 243 550 minecraft:black_concrete
fill 551 242 510 551 243 510 minecraft:blue_concrete
fill 551 242 511 552 243 513 minecraft:black_concrete
fill 551 242 514 551 243 514 minecraft:gray_concrete
fill 551 242 518 552 243 520 minecraft:black_concrete
fill 551 242 521 551 243 521 minecraft:gray_concrete
fill 551 242 525 556 243 525 minecraft:black_concrete
fill 551 242 528 551 243 528 minecraft:gray_concrete
fill 551 242 532 556 243 532 minecraft:black_concrete
fill 551 242 535 551 243 535 minecraft:gray_concrete
fill 551 242 539 556 243 539 minecraft:black_concrete
fill 551 242 542 551 243 542 minecraft:gray_concrete
fill 551 242 546 556 243 546 minecraft:black_concrete
fill 551 242 549 551 243 549 minecraft:gray_concrete
fill 552 242 514 557 243 514 minecraft:black_concrete
fill 552 242 517 552 243 517 minecraft:gray_concrete
fill 552 242 521 553 243 523 minecraft:black_concrete
fill 552 242 524 552 243 524 minecraft:gray_concrete
fill 552 242 528 557 243 528 minecraft:black_concrete
fill 552 242 531 552 243 531 minecraft:gray_concrete
fill 552 242 535 557 243 535 minecraft:black_concrete
fill 552 242 538 552 243 538 minecraft:gray_concrete
fill 552 242 542 557 243 542 minecraft:black_concrete
fill 552 242 545 552 243 545 minecraft:gray_concrete
fill 552 242 549 557 243 549 minecraft:black_concrete
fill 553 242 511 554 243 512 minecraft:black_concrete
fill 553 242 513 553 243 513 minecraft:gray_concrete
fill 553 242 517 554 243 519 minecraft:black_concrete
fill 553 242 520 553 243 520 minecraft:gray_concrete
fill 553 242 524 558 243 524 minecraft:black_concrete
fill 553 242 527 553 243 527 minecraft:gray_concrete
fill 553 242 531 558 243 531 minecraft:black_concrete
fill 553 242 534 553 243 534 minecraft:gray_concrete
fill 553 242 538 558 243 538 minecraft:black_concrete
fill 553 242 541 553 243 541 minecraft:gray_concrete
fill 553 242 545 558 243 545 minecraft:black_concrete
fill 553 242 548 553 243 548 minecraft:gray_concrete
fill 553 242 552 553 243 552 minecraft:blue_concrete
fill 554 242 513 558 243 513 minecraft:black_concrete
fill 554 242 516 554 243 516 minecraft:gray_concrete
fill 554 242 520 555 243 522 minecraft:black_concrete
fill 554 242 523 554 243 523 minecraft:gray_concrete
fill 554 242 527 558 243 527 minecraft:black_concrete
fill 554 242 530 554 243 530 minecraft:gray_concrete
fill 554 242 534 558 243 534 minecraft:black_concrete
fill 554 242 537 554 243 537 minecraft:gray_concrete
fill 554 242 541 558 243 541 minecraft:black_concrete
fill 554 242 544 554 243 544 minecraft:gray_concrete
fill 554 242 548 558 243 548 minecraft:black_concrete
fill 554 242 551 554 243 551 minecraft:gray_concrete
fill 555 242 510 555 243 510 minecraft:blue_concrete
fill 555 242 511 556 243 511 minecraft:black_concrete
fill 555 242 512 555 243 512 minecraft:gray_concrete
fill 555 242 516 556 243 518 minecraft:black_concrete
fill 555 242 519 555 243 519 minecraft:gray_concrete
fill 555 242 523 558 243 523 minecraft:black_concrete
fill 555 242 526 555 243 526 minecraft:gray_concrete
fill 555 242 530 558 243 530 minecraft:black_concrete
fill 555 242 533 555 243 533 minecraft:gray_concrete
fill 555 242 537 559 242 537 minecraft:black_concrete
fill 555 242 540 555 243 540 minecraft:gray_concrete
fill 555 242 544 558 243 544 minecraft:black_concrete
fill 555 242 547 555 243 547 minecraft:gray_concrete
fill 555 242 551 558 243 551 minecraft:black_concrete
setblock 555 242 552 minecraft:white_concrete
fill 556 242 512 558 243 512 minecraft:black_concrete
fill 556 242 515 556 243 515 minecraft:gray_concrete
fill 556 242 519 557 243 521 minecraft:black_concrete
fill 556 242 522 556 243 522 minecraft:gray_concrete
fill 556 242 526 558 243 526 minecraft:black_concrete
fill 556 242 529 556 243 529 minecraft:gray_concrete
fill 556 242 533 558 243 533 minecraft:black_concrete
fill 556 242 536 556 243 536 minecraft:gray_concrete
fill 556 242 540 558 243 540 minecraft:black_concrete
fill 556 242 543 556 243 543 minecraft:gray_concrete
fill 556 242 547 558 243 547 minecraft:black_concrete
fill 556 242 550 556 243 550 minecraft:gray_concrete
fill 557 242 511 557 243 511 minecraft:gray_concrete
fill 557 242 515 558 243 517 minecraft:black_concrete
fill 557 242 518 557 243 518 minecraft:gray_concrete
fill 557 242 522 558 243 522 minecraft:black_concrete
fill 557 242 525 557 243 525 minecraft:gray_concrete
fill 557 242 529 558 243 529 minecraft:black_concrete
fill 557 242 532 557 243 532 minecraft:gray_concrete
fill 557 242 536 558 243 536 minecraft:black_concrete
fill 557 242 539 557 243 539 minecraft:gray_concrete
fill 557 242 543 558 243 543 minecraft:black_concrete
fill 557 242 546 557 243 546 minecraft:gray_concrete
fill 557 242 550 558 243 550 minecraft:black_concrete
fill 558 242 511 559 242 511 minecraft:black_concrete
fill 558 242 514 558 243 514 minecraft:gray_concrete
fill 558 242 518 558 243 520 minecraft:black_concrete
fill 558 242 521 558 243 521 minecraft:gray_concrete
fill 558 242 525 558 243 525 minecraft:black_concrete
fill 558 242 528 558 243 528 minecraft:gray_concrete
fill 558 242 532 558 243 532 minecraft:black_concrete
fill 558 242 535 558 243 535 minecraft:gray_concrete
fill 558 242 539 558 243 539 minecraft:black_concrete
fill 558 242 542 558 243 542 minecraft:gray_concrete
fill 558 242 546 559 242 546 minecraft:black_concrete
fill 558 242 549 558 243 549 minecraft:gray_concrete
fill 558 242 552 558 243 552 minecraft:blue_concrete
fill 559 242 512 559 243 512 minecraft:blue_concrete
setblock 559 242 515 minecraft:shroomlight
fill 559 242 516 559 243 516 minecraft:blue_concrete
fill 559 242 524 559 243 524 minecraft:blue_concrete
fill 559 242 539 559 243 539 minecraft:blue_concrete
setblock 517 243 519 minecraft:blue_concrete
fill 517 243 526 517 243 527 minecraft:blue_concrete
setblock 517 243 531 minecraft:blue_concrete
fill 517 243 534 517 243 535 minecraft:blue_concrete
fill 518 243 531 523 243 531 minecraft:black_concrete
fill 519 243 510 519 245 510 minecraft:blue_concrete
setblock 526 243 510 minecraft:blue_concrete
fill 530 243 552 531 244 552 minecraft:blue_concrete
setblock 533 243 510 minecraft:white_concrete
fill 533 243 527 533 243 529 minecraft:black_concrete
fill 533 243 534 533 243 536 minecraft:black_concrete
fill 534 243 527 536 243 527 minecraft:black_concrete
fill 534 243 528 534 243 532 minecraft:shroomlight
fill 534 243 534 536 243 535 minecraft:black_concrete
fill 534 243 536 534 243 540 minecraft:shroomlight
fill 535 243 526 536 243 526 minecraft:black_concrete
fill 535 243 528 538 243 528 minecraft:shroomlight
fill 535 243 529 537 243 531 minecraft:black_concrete
fill 535 243 532 541 243 532 minecraft:shroomlight
fill 535 243 533 536 243 533 minecraft:black_concrete
fill 535 243 536 544 243 536 minecraft:shroomlight
fill 535 243 537 537 243 539 minecraft:black_concrete
fill 535 243 540 538 243 540 minecraft:shroomlight
fill 535 243 541 536 243 542 minecraft:black_concrete
fill 537 243 533 537 243 535 minecraft:shroomlight
fill 537 243 541 538 243 541 minecraft:black_concrete
fill 538 243 529 538 243 531 minecraft:shroomlight
fill 538 243 537 538 243 539 minecraft:shroomlight
fill 539 243 528 539 243 531 minecraft:black_concrete
fill 539 243 537 539 243 540 minecraft:black_concrete
fill 540 243 527 540 243 529 minecraft:black_concrete
setblock 540 243 531 minecraft:black_concrete
fill 540 243 537 540 243 540 minecraft:shroomlight
fill 541 243 527 541 243 528 minecraft:black_concrete
fill 541 243 529 541 243 531 minecraft:shroomlight
fill 541 243 533 541 243 535 minecraft:shroomlight
fill 541 243 537 543 243 539 minecraft:black_concrete
fill 541 243 540 544 243 540 minecraft:shroomlight
fill 541 243 551 542 243 551 minecraft:black_concrete
setblock 541 243 552 minecraft:shroomlight
fill 542 243 529 545 243 529 minecraft:shroomlight
fill 542 243 530 544 243 532 minecraft:black_concrete
fill 542 243 533 545 243 533 minecraft:shroomlight
fill 542 243 534 543 243 535 minecraft:black_concrete
setblock 542 243 552 minecraft:blue_concrete
fill 544 243 537 544 243 539 minecraft:shroomlight
fill 545 243 530 545 243 532 minecraft:shroomlight
fill 545 243 536 548 243 536 minecraft:black_concrete
fill 545 243 540 547 243 540 minecraft:black_concrete
fill 546 243 529 546 243 530 minecraft:black_concrete
fill 546 243 532 547 243 533 minecraft:black_concrete
fill 547 243 529 548 243 529 minecraft:black_concrete
fill 547 243 552 548 243 552 minecraft:blue_concrete
setblock 548 243 510 minecraft:white_concrete
fill 548 243 532 549 243 532 minecraft:black_concrete
setblock 550 243 552 minecraft:magma_block
fill 555 243 537 558 243 537 minecraft:black_concrete
setblock 555 243 552 minecraft:blue_concrete
setblock 558 243 510 minecraft:magma_block
setblock 558 243 511 minecraft:black_concrete
setblock 558 243 546 minecraft:black_concrete
setblock 559 243 511 minecraft:blue_concrete
fill 559 243 515 559 244 515 minecraft:blue_concrete
setblock 559 243 537 minecraft:blue_concrete
setblock 559 243 546 minecraft:blue_concrete
fill 517 244 510 517 244 513 minecraft:black_concrete
fill 517 244 515 517 246 520 minecraft:black_concrete
fill 517 244 522 517 252 522 minecraft:black_concrete
setblock 517 244 523 minecraft:magma_block
fill 517 244 524 517 245 525 minecraft:black_concrete
setblock 517 244 526 minecraft:blue_concrete
fill 517 244 527 517 244 547 minecraft:black_concrete
fill 517 244 549 517 251 552 minecraft:black_concrete
fill 518 244 510 518 307 510 minecraft:black_concrete
fill 518 244 552 521 245 552 minecraft:black_concrete
fill 520 244 510 527 245 510 minecraft:black_concrete
setblock 522 244 552 minecraft:blue_concrete
fill 523 244 552 529 244 552 minecraft:black_concrete
fill 529 244 510 529 307 510 minecraft:black_concrete
setblock 530 244 510 minecraft:shroomlight
fill 531 244 510 556 244 510 minecraft:black_concrete
fill 532 244 552 535 250 552 minecraft:black_concrete
setblock 536 244 552 minecraft:blue_concrete
fill 537 244 552 559 244 552 minecraft:black_concrete
setblock 558 244 510 minecraft:blue_concrete
fill 559 244 510 559 286 512 minecraft:black_concrete
fill 559 244 514 559 275 514 minecraft:black_concrete
fill 559 244 516 559 244 528 minecraft:black_concrete
setblock 559 244 529 minecraft:blue_concrete
fill 559 244 530 559 244 549 minecraft:black_concrete
fill 559 244 551 559 296 551 minecraft:black_concrete
fill 517 245 510 517 245 511 minecraft:blue_concrete
fill 517 245 512 517 251 514 minecraft:black_concrete
setblock 517 245 521 minecraft:black_concrete
fill 517 245 523 517 252 523 minecraft:black_concrete
fill 517 245 526 517 245 530 minecraft:black_concrete
setblock 517 245 531 minecraft:blue_concrete
fill 517 245 532 517 278 533 minecraft:black_concrete
setblock 517 245 534 minecraft:blue_concrete
fill 517 245 535 517 245 539 minecraft:black_concrete
setblock 517 245 540 minecraft:blue_concrete
fill 517 245 541 517 261 548 minecraft:black_concrete
fill 522 245 552 522 246 552 minecraft:black_concrete
setblock 523 245 552 minecraft:blue_concrete
fill 524 245 552 531 245 552 minecraft:black_concrete
setblock 528 245 510 minecraft:black_concrete
fill 530 245 510 538 250 510 minecraft:black_concrete
fill 536 245 552 546 245 552 minecraft:black_concrete
setblock 539 245 510 minecraft:blue_concrete
fill 540 245 510 542 253 510 minecraft:black_concrete
setblock 543 245 510 minecraft:blue_concrete
fill 544 245 510 555 245 510 minecraft:black_concrete
setblock 547 245 552 minecraft:blue_concrete
fill 548 245 552 553 245 552 minecraft:black_concrete
fill 554 245 552 555 245 552 minecraft:blue_concrete
setblock 556 245 510 minecraft:magma_block
fill 556 245 552 556 264 552 minecraft:black_concrete
fill 557 245 510 558 279 510 minecraft:black_concrete
setblock 557 245 552 minecraft:shroomlight
fill 558 245 552 559 245 552 minecraft:black_concrete
fill 559 245 513 559 265 513 minecraft:black_concrete
fill 559 245 515 559 256 517 minecraft:black_concrete
setblock 559 245 518 minecraft:blue_concrete
fill 559 245 519 559 245 547 minecraft:black_concrete
setblock 559 245 548 minecraft:blue_concrete
fill 559 245 549 559 254 550 minecraft:black_concrete
fill 517 246 510 517 307 511 minecraft:black_concrete
setblock 517 246 521 minecraft:blue_concrete
fill 517 246 524 517 296 524 minecraft:black_concrete
setblock 517 246 525 minecraft:blue_concrete
fill 517 246 526 517 261 526 minecraft:black_concrete
setblock 517 246 527 minecraft:blue_concrete
fill 517 246 528 517 307 528 minecraft:black_concrete
setblock 517 246 529 minecraft:white_concrete
fill 517 246 530 517 289 531 minecraft:black_concrete
fill 517 246 534 517 251 534 minecraft:black_concrete
setblock 517 246 535 minecraft:blue_concrete
fill 517 246 536 517 255 539 minecraft:black_concrete
setblock 517 246 540 minecraft:white_concrete
fill 518 246 552 519 268 552 minecraft:black_concrete
fill 519 246 510 523 251 510 minecraft:black_concrete
setblock 520 246 513 minecraft:light[level=14]
setblock 520 246 521 minecraft:light[level=14]
setblock 520 246 529 minecraft:light[level=14]
setblock 520 246 537 minecraft:light[level=14]
setblock 520 246 545 minecraft:light[level=14]
fill 520 246 552 521 246 552 minecraft:blue_concrete
fill 523 246 552 530 247 552 minecraft:black_concrete
setblock 524 246 510 minecraft:shroomlight
fill 525 246 510 527 248 510 minecraft:black_concrete
setblock 528 246 510 minecraft:blue_concrete
setblock 528 246 513 minecraft:light[level=14]
setblock 528 246 521 minecraft:light[level=14]
setblock 528 246 529 minecraft:light[level=14]
setblock 528 246 537 minecraft:light[level=14]
setblock 528 246 545 minecraft:light[level=14]
setblock 531 246 552 minecraft:blue_concrete
setblock 536 246 513 minecraft:light[level=14]
setblock 536 246 521 minecraft:light[level=14]
setblock 536 246 529 minecraft:light[level=14]
setblock 536 246 537 minecraft:light[level=14]
setblock 536 246 545 minecraft:light[level=14]
fill 536 246 552 542 265 552 minecraft:black_concrete
fill 539 246 510 539 284 510 minecraft:black_concrete
fill 543 246 510 543 252 510 minecraft:black_concrete
fill 543 246 552 544 246 552 minecraft:blue_concrete
setblock 544 246 510 minecraft:shroomlight
setblock 544 246 513 minecraft:light[level=14]
setblock 544 246 521 minecraft:light[level=14]
setblock 544 246 529 minecraft:light[level=14]
setblock 544 246 537 minecraft:light[level=14]
setblock 544 246 545 minecraft:light[level=14]
fill 545 246 510 550 248 510 minecraft:black_concrete
fill 545 246 552 548 251 552 minecraft:black_concrete
fill 549 246 552 550 246 552 minecraft:blue_concrete
setblock 551 246 510 minecraft:blue_concrete
fill 551 246 552 553 257 552 minecraft:black_concrete
fill 552 246 510 552 252 510 minecraft:black_concrete
setblock 552 246 513 minecraft:light[level=14]
setblock 552 246 521 minecraft:light[level=14]
setblock 552 246 529 minecraft:light[level=14]
setblock 552 246 537 minecraft:light[level=14]
setblock 552 246 545 minecraft:light[level=14]
setblock 553 246 510 minecraft:blue_concrete
fill 554 246 510 556 261 510 minecraft:black_concrete
setblock 554 246 552 minecraft:blue_concrete
fill 555 246 552 555 307 552 minecraft:black_concrete
fill 557 246 552 558 307 552 minecraft:black_concrete
fill 559 246 518 559 251 522 minecraft:black_concrete
setblock 559 246 523 minecraft:blue_concrete
fill 559 246 524 559 256 531 minecraft:black_concrete
setblock 559 246 532 minecraft:blue_concrete
fill 559 246 533 559 251 537 minecraft:black_concrete
setblock 559 246 538 minecraft:blue_concrete
fill 559 246 539 559 247 542 minecraft:black_concrete
setblock 559 246 543 minecraft:blue_concrete
fill 559 246 544 559 267 546 minecraft:black_concrete
setblock 559 246 547 minecraft:blue_concrete
fill 559 246 548 559 250 548 minecraft:black_concrete
setblock 559 246 552 minecraft:blue_concrete
fill 517 247 515 517 247 519 minecraft:black_concrete
setblock 517 247 520 minecraft:white_concrete
fill 517 247 521 517 251 521 minecraft:black_concrete
fill 517 247 525 517 248 525 minecraft:black_concrete
setblock 517 247 527 minecraft:white_concrete
fill 517 247 529 517 267 529 minecraft:black_concrete
fill 517 247 535 517 261 535 minecraft:black_concrete
fill 517 247 540 517 307 540 minecraft:black_concrete
fill 520 247 552 521 249 552 minecraft:black_concrete
setblock 522 247 552 minecraft:white_concrete
fill 524 247 510 524 253 510 minecraft:black_concrete
fill 528 247 510 528 307 510 minecraft:black_concrete
fill 531 247 552 531 251 552 minecraft:black_concrete
fill 543 247 552 544 307 552 minecraft:black_concrete
fill 544 247 510 544 253 510 minecraft:black_concrete
fill 549 247 552 550 267 552 minecraft:black_concrete
fill 551 247 510 551 263 510 minecraft:black_concrete
setblock 553 247 510 minecraft:magma_block
fill 554 247 552 554 307 552 minecraft:black_concrete
fill 559 247 523 559 307 523 minecraft:black_concrete
fill 559 247 532 559 279 532 minecraft:black_concrete
fill 559 247 538 559 261 538 minecraft:black_concrete
fill 559 247 543 559 289 543 minecraft:black_concrete
fill 559 247 547 559 261 547 minecraft:black_concrete
fill 559 247 552 559 307 552 minecraft:black_concrete
fill 517 248 515 517 275 516 minecraft:black_concrete
setblock 517 248 517 minecraft:magma_block
fill 517 248 518 517 251 520 minecraft:black_concrete
fill 517 248 527 517 261 527 minecraft:black_concrete
fill 522 248 552 528 250 552 minecraft:black_concrete
setblock 529 248 552 minecraft:magma_block
fill 530 248 552 530 256 552 minecraft:black_concrete
fill 553 248 510 553 251 510 minecraft:black_concrete
setblock 559 248 539 minecraft:white_concrete
fill 559 248 540 559 263 542 minecraft:black_concrete
setblock 517 249 517 minecraft:shroomlight
setblock 517 249 525 minecraft:white_concrete
fill 525 249 510 525 307 510 minecraft:black_concrete
setblock 526 249 510 minecraft:magma_block
fill 527 249 510 527 281 510 minecraft:black_concrete
fill 529 249 552 529 279 552 minecraft:black_concrete
fill 545 249 510 545 257 510 minecraft:black_concrete
setblock 546 249 510 minecraft:shroomlight
fill 547 249 510 550 289 510 minecraft:black_concrete
fill 552 249 524 552 250 524 minecraft:magma_block
fill 559 249 539 559 250 539 minecraft:black_concrete
fill 517 250 517 517 307 517 minecraft:black_concrete
fill 517 250 525 517 282 525 minecraft:black_concrete
fill 520 250 552 520 293 552 minecraft:black_concrete
setblock 521 250 552 minecraft:magma_block
fill 526 250 510 526 280 510 minecraft:black_concrete
fill 546 250 510 546 255 510 minecraft:black_concrete
fill 521 251 552 521 279 552 minecraft:black_concrete
setblock 522 251 552 minecraft:white_concrete
fill 523 251 552 528 251 552 minecraft:black_concrete
fill 530 251 510 535 257 510 minecraft:black_concrete
fill 532 251 552 532 307 552 minecraft:black_concrete
setblock 533 251 552 minecraft:shroomlight
fill 534 251 552 535 287 552 minecraft:black_concrete
setblock 536 251 510 minecraft:shroomlight
fill 537 251 510 538 251 510 minecraft:black_concrete
fill 552 251 524 552 261 525 minecraft:blackstone
fill 555 251 523 555 252 523 minecraft:blackstone
setblock 559 251 539 minecraft:shroomlight
setblock 559 251 548 minecraft:white_concrete
fill 517 252 512 517 266 513 minecraft:black_concrete
setblock 517 252 514 minecraft:white_concrete
fill 517 252 518 517 254 518 minecraft:orange_concrete
fill 517 252 519 517 274 520 minecraft:black_concrete
setblock 517 252 521 minecraft:magma_block
fill 517 252 534 517 254 534 minecraft:orange_concrete
fill 517 252 549 517 255 549 minecraft:black_concrete
fill 517 252 550 517 254 550 minecraft:orange_concrete
fill 517 252 551 517 273 552 minecraft:black_concrete
fill 519 252 510 520 290 510 minecraft:black_concrete
fill 521 252 510 521 254 510 minecraft:orange_concrete
fill 522 252 510 523 261 510 minecraft:black_concrete
fill 522 252 552 527 253 552 minecraft:black_concrete
fill 528 252 537 528 253 539 minecraft:red_terracotta
setblock 528 252 552 minecraft:magma_block
fill 529 252 538 529 253 538 minecraft:red_terracotta
fill 529 252 547 529 253 547 minecraft:red_terracotta
fill 531 252 552 531 254 552 minecraft:orange_concrete
fill 533 252 552 533 273 552 minecraft:black_concrete
fill 536 252 510 536 295 510 minecraft:black_concrete
fill 537 252 510 537 254 510 minecraft:orange_concrete
fill 538 252 510 538 307 510 minecraft:black_concrete
fill 545 252 552 546 265 552 minecraft:black_concrete
fill 547 252 552 547 254 552 minecraft:orange_concrete
fill 548 252 552 548 266 552 minecraft:black_concrete
fill 553 252 510 553 254 510 minecraft:orange_concrete
fill 559 252 518 559 273 519 minecraft:black_concrete
fill 559 252 520 559 254 520 minecraft:orange_concrete
fill 559 252 521 559 272 522 minecraft:black_concrete
fill 559 252 533 559 253 535 minecraft:black_concrete
fill 559 252 536 559 254 536 minecraft:orange_concrete
fill 559 252 537 559 293 537 minecraft:black_concrete
fill 559 252 539 559 280 539 minecraft:black_concrete
fill 559 252 548 559 307 548 minecraft:black_concrete
fill 517 253 514 517 307 514 minecraft:black_concrete
fill 517 253 521 517 307 521 minecraft:black_concrete
setblock 517 253 522 minecraft:magma_block
setblock 517 253 523 minecraft:shroomlight
setblock 528 253 552 minecraft:shroomlight
setblock 543 253 510 minecraft:magma_block
fill 551 253 524 551 261 525 minecraft:blackstone
setblock 552 253 510 minecraft:magma_block
fill 552 253 523 552 261 523 minecraft:blackstone
fill 553 253 524 553 261 525 minecraft:blackstone
fill 517 254 522 517 267 523 minecraft:black_concrete
setblock 520 254 513 minecraft:light[level=14]
setblock 520 254 521 minecraft:light[level=14]
setblock 520 254 529 minecraft:light[level=14]
setblock 520 254 537 minecraft:light[level=14]
setblock 520 254 545 minecraft:light[level=14]
fill 522 254 552 526 296 552 minecraft:black_concrete
setblock 524 254 510 minecraft:white_concrete
fill 527 254 552 528 254 552 minecraft:white_concrete
setblock 528 254 513 minecraft:light[level=14]
setblock 528 254 521 minecraft:light[level=14]
setblock 528 254 529 minecraft:light[level=14]
setblock 528 254 537 minecraft:light[level=14]
setblock 528 254 545 minecraft:light[level=14]
setblock 536 254 513 minecraft:light[level=14]
setblock 536 254 521 minecraft:light[level=14]
setblock 536 254 529 minecraft:light[level=14]
setblock 536 254 537 minecraft:light[level=14]
setblock 536 254 545 minecraft:light[level=14]
fill 540 254 510 540 281 510 minecraft:black_concrete
setblock 541 254 510 minecraft:shroomlight
fill 542 254 510 543 271 510 minecraft:black_concrete
setblock 544 254 510 minecraft:magma_block
setblock 544 254 513 minecraft:light[level=14]
setblock 544 254 521 minecraft:light[level=14]
setblock 544 254 529 minecraft:light[level=14]
setblock 544 254 537 minecraft:light[level=14]
setblock 544 254 545 minecraft:light[level=14]
fill 551 254 523 551 261 523 minecraft:blackstone
fill 551 254 526 553 261 526 minecraft:blackstone
fill 552 254 510 552 276 510 minecraft:black_concrete
setblock 552 254 513 minecraft:light[level=14]
setblock 552 254 521 minecraft:light[level=14]
setblock 552 254 529 minecraft:light[level=14]
setblock 552 254 537 minecraft:light[level=14]
setblock 552 254 545 minecraft:light[level=14]
fill 553 254 523 553 261 523 minecraft:blackstone
fill 554 254 524 554 261 525 minecraft:blackstone
setblock 559 254 533 minecraft:shroomlight
fill 559 254 534 559 307 535 minecraft:black_concrete
fill 517 255 518 517 257 518 minecraft:black_concrete
fill 517 255 534 517 260 534 minecraft:black_concrete
fill 517 255 550 517 260 550 minecraft:black_concrete
fill 521 255 510 521 258 510 minecraft:black_concrete
fill 524 255 510 524 305 510 minecraft:black_concrete
fill 527 255 552 528 303 552 minecraft:black_concrete
fill 531 255 552 531 260 552 minecraft:black_concrete
fill 537 255 510 537 260 510 minecraft:black_concrete
fill 541 255 510 541 307 510 minecraft:black_concrete
fill 544 255 510 544 257 510 minecraft:black_concrete
setblock 547 255 552 minecraft:black_concrete
fill 550 255 524 550 261 525 minecraft:blackstone
fill 552 255 522 552 261 522 minecraft:blackstone
fill 553 255 510 553 260 510 minecraft:black_concrete
fill 554 255 523 554 261 523 minecraft:blackstone
fill 554 255 526 554 261 526 minecraft:blackstone
fill 559 255 520 559 260 520 minecraft:black_concrete
fill 559 255 533 559 261 533 minecraft:black_concrete
fill 559 255 536 559 260 536 minecraft:black_concrete
fill 559 255 549 559 304 549 minecraft:black_concrete
setblock 559 255 550 minecraft:white_concrete
fill 517 256 536 517 267 536 minecraft:black_concrete
fill 517 256 537 517 257 537 minecraft:white_concrete
fill 517 256 538 517 294 539 minecraft:black_concrete
setblock 517 256 549 minecraft:magma_block
setblock 546 256 510 minecraft:shroomlight
setblock 547 256 552 minecraft:shroomlight
fill 550 256 523 550 261 523 minecraft:blackstone
fill 550 256 526 550 261 526 minecraft:blackstone
fill 551 256 522 551 261 522 minecraft:blackstone
fill 551 256 527 553 261 527 minecraft:blackstone
fill 553 256 522 553 261 522 minecraft:blackstone
fill 555 256 524 555 261 525 minecraft:blackstone
fill 559 256 550 559 260 550 minecraft:black_concrete
fill 517 257 549 517 264 549 minecraft:black_concrete
setblock 530 257 552 minecraft:shroomlight
fill 546 257 510 546 306 510 minecraft:black_concrete
fill 547 257 552 547 260 552 minecraft:black_concrete
fill 549 257 523 549 261 526 minecraft:blackstone
fill 550 257 522 550 261 522 minecraft:blackstone
fill 550 257 527 550 261 527 minecraft:blackstone
fill 552 257 521 552 261 521 minecraft:blackstone
fill 552 257 539 552 258 539 minecraft:magma_block
fill 554 257 522 554 261 522 minecraft:blackstone
fill 554 257 527 554 261 527 minecraft:blackstone
fill 555 257 523 555 261 523 minecraft:blackstone
fill 555 257 526 555 261 526 minecraft:blackstone
fill 559 257 515 559 305 516 minecraft:black_concrete
setblock 559 257 517 minecraft:magma_block
fill 559 257 524 559 262 530 minecraft:black_concrete
setblock 559 257 531 minecraft:shroomlight
setblock 517 258 518 minecraft:white_concrete
setblock 517 258 537 minecraft:black_concrete
fill 530 258 510 532 260 510 minecraft:black_concrete
fill 530 258 552 530 307 552 minecraft:black_concrete
setblock 533 258 510 minecraft:magma_block
fill 534 258 510 535 278 510 minecraft:black_concrete
setblock 544 258 510 minecraft:magma_block
setblock 545 258 510 minecraft:shroomlight
fill 549 258 522 549 261 522 minecraft:blackstone
fill 549 258 527 549 261 527 minecraft:blackstone
fill 551 258 521 551 261 521 minecraft:blackstone
fill 551 258 528 553 261 528 minecraft:blackstone
fill 551 258 552 552 288 552 minecraft:black_concrete
fill 553 258 521 554 261 521 minecraft:blackstone
setblock 553 258 552 minecraft:magma_block
fill 555 258 522 555 261 522 minecraft:blackstone
fill 555 258 527 555 261 527 minecraft:blackstone
fill 556 258 524 556 261 525 minecraft:blackstone
fill 559 258 517 559 284 517 minecraft:black_concrete
fill 559 258 531 559 269 531 minecraft:black_concrete
fill 517 259 518 517 260 518 minecraft:black_concrete
setblock 517 259 537 minecraft:white_concrete
setblock 521 259 510 minecraft:shroomlight
fill 533 259 510 533 270 510 minecraft:black_concrete
fill 544 259 510 545 269 510 minecraft:black_concrete
fill 548 259 523 548 261 526 minecraft:blackstone
fill 550 259 521 550 261 521 minecraft:blackstone
fill 550 259 528 550 261 528 minecraft:blackstone
fill 552 259 520 552 261 520 minecraft:blackstone
fill 552 259 539 552 268 539 minecraft:blackstone
fill 553 259 552 553 274 552 minecraft:black_concrete
fill 554 259 528 554 261 528 minecraft:blackstone
fill 556 259 523 556 261 523 minecraft:blackstone
fill 556 259 526 556 261 526 minecraft:blackstone
fill 517 260 537 517 263 537 minecraft:black_concrete
setblock 521 260 510 minecraft:black_concrete
fill 548 260 522 548 261 522 minecraft:blackstone
fill 548 260 527 548 261 527 minecraft:blackstone
fill 549 260 521 549 261 521 minecraft:blackstone
fill 549 260 528 549 261 528 minecraft:blackstone
fill 550 260 520 551 261 520 minecraft:blackstone
fill 551 260 529 554 261 529 minecraft:blackstone
fill 553 260 520 554 261 520 minecraft:blackstone
fill 555 260 521 555 261 521 minecraft:blackstone
fill 555 260 528 555 261 528 minecraft:blackstone
fill 556 260 522 556 261 522 minecraft:blackstone
fill 556 260 527 556 261 527 minecraft:blackstone
fill 557 260 524 557 261 525 minecraft:blackstone
fill 517 261 518 517 263 518 minecraft:orange_concrete
fill 517 261 534 517 263 534 minecraft:orange_concrete
fill 517 261 550 517 263 550 minecraft:orange_concrete
fill 521 261 510 521 263 510 minecraft:orange_concrete
fill 530 261 510 531 293 510 minecraft:black_concrete
fill 531 261 552 531 263 552 minecraft:orange_concrete
setblock 532 261 510 minecraft:white_concrete
fill 536 261 542 536 262 542 minecraft:magma_block
fill 537 261 510 537 263 510 minecraft:orange_concrete
fill 547 261 523 547 261 526 minecraft:blackstone
fill 547 261 552 547 263 552 minecraft:orange_concrete
setblock 548 261 521 minecraft:blackstone
setblock 548 261 528 minecraft:blackstone
setblock 549 261 520 minecraft:blackstone
fill 549 261 529 550 261 529 minecraft:blackstone
fill 551 261 539 551 268 540 minecraft:blackstone
setblock 552 261 519 minecraft:blackstone
fill 552 261 540 552 268 540 minecraft:blackstone
fill 553 261 510 553 263 510 minecraft:orange_concrete
setblock 555 261 520 minecraft:blackstone
setblock 555 261 529 minecraft:blackstone
setblock 556 261 521 minecraft:blackstone
setblock 556 261 528 minecraft:blackstone
setblock 557 261 523 minecraft:blackstone
setblock 557 261 526 minecraft:blackstone
fill 559 261 520 559 263 520 minecraft:orange_concrete
fill 559 261 536 559 263 536 minecraft:orange_concrete
setblock 559 261 550 minecraft:white_concrete
setblock 517 262 526 minecraft:white_concrete
setblock 517 262 527 minecraft:magma_block
setblock 517 262 535 minecraft:shroomlight
setblock 517 262 541 minecraft:magma_block
fill 517 262 542 517 265 548 minecraft:black_concrete
setblock 520 262 513 minecraft:light[level=14]
setblock 520 262 521 minecraft:light[level=14]
setblock 520 262 529 minecraft:light[level=14]
setblock 520 262 537 minecraft:light[level=14]
setblock 520 262 545 minecraft:light[level=14]
fill 522 262 510 522 283 510 minecraft:black_concrete
setblock 523 262 510 minecraft:white_concrete
setblock 528 262 513 minecraft:light[level=14]
setblock 528 262 521 minecraft:light[level=14]
setblock 528 262 529 minecraft:light[level=14]
setblock 528 262 537 minecraft:light[level=14]
setblock 528 262 545 minecraft:light[level=14]
fill 532 262 510 532 285 510 minecraft:black_concrete
setblock 536 262 513 minecraft:light[level=14]
setblock 536 262 521 minecraft:light[level=14]
setblock 536 262 529 minecraft:light[level=14]
setblock 536 262 537 minecraft:light[level=14]
setblock 536 262 545 minecraft:light[level=14]
setblock 544 262 513 minecraft:light[level=14]
setblock 544 262 521 minecraft:light[level=14]
setblock 544 262 529 minecraft:light[level=14]
setblock 544 262 537 minecraft:light[level=14]
setblock 544 262 545 minecraft:light[level=14]
fill 551 262 524 553 262 525 minecraft:magma_block
fill 551 262 538 552 268 538 minecraft:blackstone
setblock 552 262 513 minecraft:light[level=14]
setblock 552 262 521 minecraft:light[level=14]
setblock 552 262 529 minecraft:light[level=14]
setblock 552 262 537 minecraft:light[level=14]
setblock 552 262 545 minecraft:light[level=14]
fill 553 262 539 553 268 540 minecraft:blackstone
setblock 554 262 510 minecraft:white_concrete
fill 555 262 510 556 274 510 minecraft:black_concrete
setblock 559 262 533 minecraft:shroomlight
setblock 559 262 538 minecraft:shroomlight
setblock 559 262 547 minecraft:white_concrete
fill 559 262 550 559 307 550 minecraft:black_concrete
fill 517 263 526 517 293 527 minecraft:black_concrete
fill 517 263 535 517 279 535 minecraft:black_concrete
fill 517 263 541 517 287 541 minecraft:black_concrete
fill 523 263 510 523 307 510 minecraft:black_concrete
fill 550 263 538 550 268 540 minecraft:blackstone
fill 551 263 541 552 268 541 minecraft:blackstone
fill 552 263 524 552 265 525 minecraft:magma_block
setblock 553 263 524 minecraft:magma_block
fill 553 263 538 553 268 538 minecraft:blackstone
fill 554 263 510 554 307 510 minecraft:black_concrete
fill 559 263 524 559 268 529 minecraft:black_concrete
setblock 559 263 530 minecraft:white_concrete
fill 559 263 533 559 307 533 minecraft:black_concrete
fill 559 263 538 559 286 538 minecraft:black_concrete
fill 559 263 547 559 307 547 minecraft:black_concrete
fill 517 264 518 517 269 518 minecraft:black_concrete
fill 517 264 534 517 269 534 minecraft:black_concrete
setblock 517 264 537 minecraft:shroomlight
fill 517 264 550 517 269 550 minecraft:black_concrete
fill 521 264 510 521 269 510 minecraft:black_concrete
fill 531 264 552 531 269 552 minecraft:black_concrete
fill 537 264 510 537 269 510 minecraft:black_concrete
fill 547 264 552 547 269 552 minecraft:black_concrete
fill 550 264 541 550 268 541 minecraft:blackstone
setblock 551 264 510 minecraft:shroomlight
fill 551 264 537 552 268 537 minecraft:blackstone
fill 553 264 510 553 269 510 minecraft:black_concrete
fill 553 264 541 553 268 541 minecraft:blackstone
fill 554 264 539 554 268 540 minecraft:blackstone
fill 559 264 520 559 269 520 minecraft:black_concrete
fill 559 264 530 559 307 530 minecraft:black_concrete
fill 559 264 536 559 268 536 minecraft:black_concrete
fill 559 264 540 559 265 541 minecraft:black_concrete
setblock 559 264 542 minecraft:shroomlight
fill 517 265 537 517 272 537 minecraft:black_concrete
setblock 517 265 549 minecraft:white_concrete
fill 549 265 529 549 266 529 minecraft:magma_block
fill 549 265 538 549 268 540 minecraft:blackstone
fill 550 265 537 550 268 537 minecraft:blackstone
fill 551 265 510 551 307 510 minecraft:black_concrete
fill 551 265 542 552 268 542 minecraft:blackstone
fill 553 265 537 553 268 537 minecraft:blackstone
fill 554 265 538 554 268 538 minecraft:blackstone
fill 554 265 541 554 268 541 minecraft:blackstone
setblock 556 265 552 minecraft:magma_block
fill 559 265 542 559 307 542 minecraft:black_concrete
fill 517 266 542 517 266 546 minecraft:black_concrete
setblock 517 266 547 minecraft:white_concrete
fill 517 266 548 517 277 549 minecraft:black_concrete
fill 533 266 521 534 267 522 minecraft:blackstone
fill 536 266 552 541 271 552 minecraft:black_concrete
setblock 542 266 552 minecraft:shroomlight
fill 545 266 552 545 305 552 minecraft:black_concrete
setblock 546 266 552 minecraft:magma_block
fill 549 266 537 549 268 537 minecraft:blackstone
fill 549 266 541 549 268 541 minecraft:blackstone
fill 550 266 542 550 268 542 minecraft:blackstone
fill 551 266 536 553 268 536 minecraft:blackstone
fill 553 266 529 554 267 530 minecraft:blackstone
fill 553 266 542 553 268 542 minecraft:blackstone
fill 554 266 537 554 268 537 minecraft:blackstone
fill 555 266 538 555 268 540 minecraft:blackstone
fill 556 266 552 556 304 552 minecraft:black_concrete
setblock 559 266 513 minecraft:magma_block
setblock 559 266 540 minecraft:black_concrete
setblock 559 266 541 minecraft:shroomlight
setblock 517 267 512 minecraft:white_concrete
fill 517 267 513 517 307 513 minecraft:black_concrete
setblock 517 267 542 minecraft:magma_block
fill 517 267 543 517 281 547 minecraft:black_concrete
fill 542 267 552 542 269 552 minecraft:black_concrete
fill 546 267 552 546 307 552 minecraft:black_concrete
fill 548 267 538 548 268 540 minecraft:blackstone
setblock 548 267 552 minecraft:white_concrete
fill 549 267 542 549 268 542 minecraft:blackstone
fill 550 267 536 550 268 536 minecraft:blackstone
fill 551 267 543 553 268 543 minecraft:blackstone
fill 554 267 536 554 268 536 minecraft:blackstone
fill 554 267 542 554 268 542 minecraft:blackstone
fill 555 267 537 555 268 537 minecraft:blackstone
fill 555 267 541 555 268 541 minecraft:blackstone
fill 559 267 513 559 273 513 minecraft:black_concrete
setblock 559 267 540 minecraft:shroomlight
fill 559 267 541 559 307 541 minecraft:black_concrete
fill 517 268 512 517 299 512 minecraft:black_concrete
fill 517 268 522 517 286 522 minecraft:black_concrete
setblock 517 268 523 minecraft:shroomlight
setblock 517 268 529 minecraft:white_concrete
setblock 517 268 536 minecraft:magma_block
fill 517 268 542 517 292 542 minecraft:black_concrete
setblock 548 268 537 minecraft:blackstone
setblock 548 268 541 minecraft:blackstone
fill 548 268 552 548 272 552 minecraft:black_concrete
setblock 549 268 536 minecraft:blackstone
setblock 549 268 552 minecraft:white_concrete
setblock 550 268 543 minecraft:blackstone
fill 550 268 552 550 307 552 minecraft:black_concrete
fill 551 268 535 553 268 535 minecraft:blackstone
setblock 554 268 543 minecraft:blackstone
setblock 555 268 542 minecraft:blackstone
fill 556 268 538 556 268 540 minecraft:blackstone
fill 559 268 540 559 307 540 minecraft:black_concrete
setblock 559 268 544 minecraft:white_concrete
fill 559 268 545 559 286 546 minecraft:black_concrete
fill 517 269 523 517 307 523 minecraft:black_concrete
fill 517 269 529 517 273 529 minecraft:black_concrete
fill 517 269 536 517 276 536 minecraft:black_concrete
setblock 518 269 552 minecraft:white_concrete
fill 519 269 552 519 305 552 minecraft:black_concrete
fill 549 269 552 549 288 552 minecraft:black_concrete
fill 551 269 539 552 270 540 minecraft:magma_block
setblock 552 269 538 minecraft:magma_block
setblock 559 269 524 minecraft:magma_block
fill 559 269 525 559 275 529 minecraft:black_concrete
setblock 559 269 536 minecraft:magma_block
fill 559 269 544 559 289 544 minecraft:black_concrete
fill 517 270 518 517 272 518 minecraft:orange_concrete
fill 517 270 534 517 272 534 minecraft:orange_concrete
fill 517 270 550 517 272 550 minecraft:orange_concrete
fill 518 270 552 518 307 552 minecraft:black_concrete
setblock 520 270 513 minecraft:light[level=14]
setblock 520 270 521 minecraft:light[level=14]
setblock 520 270 529 minecraft:light[level=14]
setblock 520 270 537 minecraft:light[level=14]
setblock 520 270 545 minecraft:light[level=14]
fill 521 270 510 521 272 510 minecraft:orange_concrete
setblock 528 270 513 minecraft:light[level=14]
setblock 528 270 521 minecraft:light[level=14]
setblock 528 270 529 minecraft:light[level=14]
setblock 528 270 537 minecraft:light[level=14]
setblock 528 270 545 minecraft:light[level=14]
fill 531 270 552 531 272 552 minecraft:orange_concrete
setblock 536 270 513 minecraft:light[level=14]
setblock 536 270 521 minecraft:light[level=14]
setblock 536 270 529 minecraft:light[level=14]
setblock 536 270 537 minecraft:light[level=14]
setblock 536 270 545 minecraft:light[level=14]
fill 537 270 510 537 272 510 minecraft:orange_concrete
setblock 542 270 552 minecraft:magma_block
fill 544 270 510 544 271 510 minecraft:black_concrete
setblock 544 270 513 minecraft:light[level=14]
setblock 544 270 521 minecraft:light[level=14]
setblock 544 270 529 minecraft:light[level=14]
setblock 544 270 537 minecraft:light[level=14]
setblock 544 270 545 minecraft:light[level=14]
setblock 545 270 510 minecraft:white_concrete
fill 547 270 552 547 272 552 minecraft:orange_concrete
setblock 552 270 513 minecraft:light[level=14]
setblock 552 270 521 minecraft:light[level=14]
setblock 552 270 529 minecraft:light[level=14]
setblock 552 270 537 minecraft:light[level=14]
setblock 552 270 545 minecraft:light[level=14]
fill 553 270 510 553 272 510 minecraft:orange_concrete
fill 559 270 520 559 272 520 minecraft:orange_concrete
fill 559 270 524 559 307 524 minecraft:black_concrete
setblock 559 270 531 minecraft:white_concrete
fill 559 270 536 559 272 536 minecraft:orange_concrete
setblock 533 271 510 minecraft:shroomlight
fill 542 271 552 542 307 552 minecraft:black_concrete
fill 545 271 510 545 295 510 minecraft:black_concrete
fill 551 271 539 552 271 539 minecraft:magma_block
fill 559 271 531 559 307 531 minecraft:black_concrete
fill 533 272 510 533 307 510 minecraft:black_concrete
fill 536 272 552 538 280 552 minecraft:black_concrete
fill 537 272 530 538 272 533 minecraft:orange_terracotta
fill 538 272 529 540 272 529 minecraft:orange_terracotta
fill 538 272 534 540 272 534 minecraft:orange_terracotta
fill 539 272 530 539 272 531 minecraft:orange_terracotta
setblock 539 272 552 minecraft:shroomlight
fill 540 272 530 541 272 530 minecraft:orange_terracotta
fill 540 272 552 541 307 552 minecraft:black_concrete
setblock 541 272 531 minecraft:orange_terracotta
setblock 541 272 533 minecraft:orange_terracotta
setblock 542 272 510 minecraft:shroomlight
fill 543 272 510 543 307 510 minecraft:black_concrete
setblock 544 272 510 minecraft:shroomlight
setblock 552 272 539 minecraft:magma_block
fill 517 273 518 517 287 518 minecraft:black_concrete
fill 517 273 534 517 287 534 minecraft:black_concrete
setblock 517 273 537 minecraft:shroomlight
fill 517 273 550 517 287 550 minecraft:black_concrete
fill 521 273 510 521 287 510 minecraft:black_concrete
fill 531 273 552 531 287 552 minecraft:black_concrete
fill 535 273 530 536 273 533 minecraft:orange_terracotta
fill 536 273 528 537 273 529 minecraft:orange_terracotta
fill 536 273 534 537 273 535 minecraft:orange_terracotta
fill 537 273 510 537 287 510 minecraft:black_concrete
fill 537 273 530 538 277 533 minecraft:red_terracotta
fill 538 273 527 540 273 528 minecraft:orange_terracotta
fill 538 273 529 540 279 529 minecraft:red_terracotta
fill 538 273 534 540 277 534 minecraft:red_terracotta
fill 538 273 535 540 273 536 minecraft:orange_terracotta
fill 539 273 530 539 277 531 minecraft:red_terracotta
fill 539 273 552 539 307 552 minecraft:black_concrete
fill 540 273 530 541 277 530 minecraft:red_terracotta
fill 541 273 528 542 273 529 minecraft:orange_terracotta
fill 541 273 531 541 277 531 minecraft:red_terracotta
fill 541 273 533 541 277 533 minecraft:red_terracotta
fill 541 273 534 542 273 535 minecraft:orange_terracotta
fill 542 273 510 542 303 510 minecraft:black_concrete
fill 542 273 530 543 273 533 minecraft:orange_terracotta
fill 544 273 510 544 307 510 minecraft:black_concrete
fill 547 273 552 547 287 552 minecraft:black_concrete
setblock 548 273 552 minecraft:shroomlight
fill 553 273 510 553 287 510 minecraft:black_concrete
fill 559 273 520 559 287 520 minecraft:black_concrete
setblock 559 273 521 minecraft:shroomlight
fill 559 273 522 559 307 522 minecraft:black_concrete
fill 559 273 536 559 284 536 minecraft:black_concrete
setblock 517 274 529 minecraft:white_concrete
fill 517 274 537 517 282 537 minecraft:black_concrete
setblock 517 274 551 minecraft:shroomlight
fill 517 274 552 517 307 552 minecraft:black_concrete
setblock 533 274 552 minecraft:magma_block
fill 534 274 529 534 274 534 minecraft:orange_terracotta
fill 535 274 528 535 274 529 minecraft:orange_terracotta
fill 535 274 530 536 285 533 minecraft:red_terracotta
fill 535 274 534 535 274 535 minecraft:orange_terracotta
fill 536 274 527 537 274 527 minecraft:orange_terracotta
fill 536 274 528 537 285 529 minecraft:red_terracotta
fill 536 274 534 537 285 535 minecraft:red_terracotta
fill 536 274 536 537 274 536 minecraft:orange_terracotta
fill 538 274 526 540 274 526 minecraft:orange_terracotta
fill 538 274 527 540 285 528 minecraft:red_terracotta
fill 538 274 535 540 279 536 minecraft:red_terracotta
fill 538 274 537 540 274 537 minecraft:orange_terracotta
fill 541 274 527 542 274 527 minecraft:orange_terracotta
fill 541 274 528 542 279 529 minecraft:red_terracotta
fill 541 274 534 542 279 535 minecraft:red_terracotta
fill 541 274 536 542 274 536 minecraft:orange_terracotta
fill 542 274 530 543 277 533 minecraft:red_terracotta
fill 543 274 528 543 274 529 minecraft:orange_terracotta
fill 543 274 534 543 274 535 minecraft:orange_terracotta
fill 544 274 529 544 274 534 minecraft:orange_terracotta
fill 548 274 552 548 307 552 minecraft:black_concrete
setblock 559 274 513 minecraft:shroomlight
setblock 559 274 518 minecraft:shroomlight
fill 559 274 519 559 289 519 minecraft:black_concrete
fill 559 274 521 559 277 521 minecraft:black_concrete
fill 517 275 519 517 307 519 minecraft:black_concrete
setblock 517 275 520 minecraft:magma_block
fill 517 275 529 517 307 529 minecraft:black_concrete
fill 517 275 551 517 307 551 minecraft:black_concrete
fill 533 275 529 533 275 534 minecraft:orange_terracotta
fill 533 275 552 533 303 552 minecraft:black_concrete
setblock 534 275 528 minecraft:orange_terracotta
fill 534 275 529 534 284 534 minecraft:red_terracotta
setblock 534 275 535 minecraft:orange_terracotta
setblock 535 275 527 minecraft:orange_terracotta
fill 535 275 528 535 284 529 minecraft:red_terracotta
fill 535 275 534 535 284 535 minecraft:red_terracotta
setblock 535 275 536 minecraft:orange_terracotta
fill 536 275 526 537 275 526 minecraft:orange_terracotta
fill 536 275 527 537 284 527 minecraft:red_terracotta
fill 536 275 536 537 284 536 minecraft:red_terracotta
fill 536 275 537 537 275 537 minecraft:orange_terracotta
fill 538 275 525 540 276 525 minecraft:orange_terracotta
fill 538 275 526 540 284 526 minecraft:red_terracotta
fill 538 275 537 540 284 537 minecraft:red_terracotta
fill 538 275 538 540 276 538 minecraft:orange_terracotta
fill 539 275 533 539 277 533 minecraft:red_terracotta
fill 541 275 526 542 275 526 minecraft:orange_terracotta
fill 541 275 527 542 284 527 minecraft:red_terracotta
fill 541 275 536 542 284 536 minecraft:red_terracotta
fill 541 275 537 542 275 537 minecraft:orange_terracotta
setblock 543 275 527 minecraft:orange_terracotta
fill 543 275 528 543 284 529 minecraft:red_terracotta
fill 543 275 534 543 284 535 minecraft:red_terracotta
setblock 543 275 536 minecraft:orange_terracotta
setblock 544 275 528 minecraft:orange_terracotta
fill 544 275 529 544 284 534 minecraft:red_terracotta
setblock 544 275 535 minecraft:orange_terracotta
fill 545 275 529 545 275 534 minecraft:orange_terracotta
setblock 553 275 552 minecraft:white_concrete
fill 555 275 510 555 307 510 minecraft:black_concrete
setblock 556 275 510 minecraft:shroomlight
fill 559 275 513 559 287 513 minecraft:black_concrete
fill 559 275 518 559 290 518 minecraft:black_concrete
setblock 517 276 515 minecraft:magma_block
fill 517 276 516 517 290 516 minecraft:black_concrete
fill 517 276 520 517 307 520 minecraft:black_concrete
fill 532 276 530 532 283 533 minecraft:orange_terracotta
fill 533 276 528 533 276 529 minecraft:orange_terracotta
fill 533 276 530 533 283 533 minecraft:red_terracotta
fill 533 276 534 533 276 535 minecraft:orange_terracotta
setblock 534 276 527 minecraft:orange_terracotta
fill 534 276 528 534 283 528 minecraft:red_terracotta
fill 534 276 535 534 283 535 minecraft:red_terracotta
setblock 534 276 536 minecraft:orange_terracotta
fill 535 276 526 535 277 526 minecraft:orange_terracotta
fill 535 276 527 535 283 527 minecraft:red_terracotta
fill 535 276 536 535 283 536 minecraft:red_terracotta
fill 535 276 537 535 277 537 minecraft:orange_terracotta
fill 536 276 525 537 277 525 minecraft:orange_terracotta
fill 536 276 526 537 283 526 minecraft:red_terracotta
fill 536 276 537 537 283 537 minecraft:red_terracotta
fill 536 276 538 537 277 538 minecraft:orange_terracotta
fill 541 276 525 542 277 525 minecraft:orange_terracotta
fill 541 276 526 542 283 526 minecraft:red_terracotta
fill 541 276 537 542 283 537 minecraft:red_terracotta
fill 541 276 538 542 277 538 minecraft:orange_terracotta
fill 543 276 526 543 277 526 minecraft:orange_terracotta
fill 543 276 527 543 283 527 minecraft:red_terracotta
fill 543 276 536 543 283 536 minecraft:red_terracotta
fill 543 276 537 543 277 537 minecraft:orange_terracotta
setblock 544 276 527 minecraft:orange_terracotta
fill 544 276 528 544 283 528 minecraft:red_terracotta
fill 544 276 535 544 283 535 minecraft:red_terracotta
setblock 544 276 536 minecraft:orange_terracotta
fill 545 276 528 545 276 529 minecraft:orange_terracotta
fill 545 276 530 545 283 533 minecraft:red_terracotta
fill 545 276 534 545 276 535 minecraft:orange_terracotta
fill 546 276 530 546 283 533 minecraft:orange_terracotta
fill 553 276 552 553 289 552 minecraft:black_concrete
fill 556 276 510 556 295 510 minecraft:black_concrete
setblock 559 276 514 minecraft:white_concrete
fill 559 276 525 559 299 525 minecraft:black_concrete
setblock 559 276 526 minecraft:white_concrete
fill 559 276 527 559 293 529 minecraft:black_concrete
fill 517 277 515 517 289 515 minecraft:black_concrete
setblock 517 277 536 minecraft:magma_block
fill 532 277 529 532 282 529 minecraft:orange_terracotta
fill 532 277 534 532 282 534 minecraft:orange_terracotta
fill 533 277 527 533 277 528 minecraft:orange_terracotta
fill 533 277 529 533 282 529 minecraft:red_terracotta
fill 533 277 534 533 282 534 minecraft:red_terracotta
fill 533 277 535 533 277 536 minecraft:orange_terracotta
fill 534 277 526 534 282 526 minecraft:orange_terracotta
fill 534 277 527 534 282 527 minecraft:red_terracotta
fill 534 277 536 534 282 536 minecraft:red_terracotta
fill 534 277 537 534 282 537 minecraft:orange_terracotta
fill 538 277 524 540 282 524 minecraft:orange_terracotta
fill 538 277 525 540 282 525 minecraft:red_terracotta
fill 538 277 538 540 282 538 minecraft:red_terracotta
fill 538 277 539 540 282 539 minecraft:orange_terracotta
fill 544 277 526 544 282 526 minecraft:orange_terracotta
fill 544 277 527 544 282 527 minecraft:red_terracotta
fill 544 277 536 544 282 536 minecraft:red_terracotta
fill 544 277 537 544 282 537 minecraft:orange_terracotta
fill 545 277 527 545 277 528 minecraft:orange_terracotta
fill 545 277 529 545 282 529 minecraft:red_terracotta
fill 545 277 534 545 282 534 minecraft:red_terracotta
fill 545 277 535 545 277 536 minecraft:orange_terracotta
fill 546 277 529 546 282 529 minecraft:orange_terracotta
fill 546 277 534 546 282 534 minecraft:orange_terracotta
setblock 552 277 510 minecraft:magma_block
fill 559 277 514 559 307 514 minecraft:black_concrete
fill 559 277 526 559 307 526 minecraft:black_concrete
fill 517 278 536 517 307 536 minecraft:black_concrete
setblock 517 278 548 minecraft:shroomlight
fill 517 278 549 517 295 549 minecraft:black_concrete
setblock 520 278 513 minecraft:light[level=14]
setblock 520 278 521 minecraft:light[level=14]
setblock 520 278 529 minecraft:light[level=14]
setblock 520 278 537 minecraft:light[level=14]
setblock 520 278 545 minecraft:light[level=14]
setblock 528 278 513 minecraft:light[level=14]
setblock 528 278 521 minecraft:light[level=14]
setblock 528 278 529 minecraft:light[level=14]
setblock 528 278 537 minecraft:light[level=14]
setblock 528 278 545 minecraft:light[level=14]
fill 532 278 528 532 281 528 minecraft:orange_terracotta
fill 532 278 535 532 281 535 minecraft:orange_terracotta
fill 533 278 527 533 282 527 minecraft:orange_terracotta
fill 533 278 528 533 281 528 minecraft:red_terracotta
fill 533 278 535 533 281 535 minecraft:red_terracotta
fill 533 278 536 533 282 536 minecraft:orange_terracotta
fill 535 278 525 536 281 525 minecraft:orange_terracotta
fill 535 278 526 535 281 526 minecraft:red_terracotta
fill 535 278 537 535 281 537 minecraft:red_terracotta
fill 535 278 538 536 281 538 minecraft:orange_terracotta
setblock 536 278 513 minecraft:light[level=14]
setblock 536 278 521 minecraft:light[level=14]
setblock 536 278 545 minecraft:light[level=14]
fill 537 278 524 537 281 524 minecraft:orange_terracotta
fill 537 278 525 537 281 525 minecraft:red_terracotta
fill 537 278 530 537 279 533 minecraft:red_terracotta
fill 537 278 538 537 281 538 minecraft:red_terracotta
fill 537 278 539 537 281 539 minecraft:orange_terracotta
fill 538 278 530 538 279 531 minecraft:red_terracotta
fill 538 278 533 538 279 534 minecraft:red_terracotta
fill 539 278 530 539 279 530 minecraft:red_terracotta
fill 539 278 534 539 279 534 minecraft:red_terracotta
fill 541 278 524 541 281 524 minecraft:orange_terracotta
fill 541 278 525 541 281 525 minecraft:red_terracotta
fill 541 278 530 543 279 530 minecraft:red_terracotta
fill 541 278 538 541 281 538 minecraft:red_terracotta
fill 541 278 539 541 281 539 minecraft:orange_terracotta
fill 542 278 525 543 281 525 minecraft:orange_terracotta
fill 542 278 531 543 279 531 minecraft:red_terracotta
fill 542 278 533 543 279 533 minecraft:red_terracotta
fill 542 278 538 543 281 538 minecraft:orange_terracotta
fill 543 278 526 543 281 526 minecraft:red_terracotta
fill 543 278 532 543 279 532 minecraft:red_terracotta
fill 543 278 537 543 281 537 minecraft:red_terracotta
setblock 544 278 513 minecraft:light[level=14]
setblock 544 278 521 minecraft:light[level=14]
setblock 544 278 545 minecraft:light[level=14]
fill 545 278 527 545 282 527 minecraft:orange_terracotta
fill 545 278 528 545 281 528 minecraft:red_terracotta
fill 545 278 535 545 281 535 minecraft:red_terracotta
fill 545 278 536 545 282 536 minecraft:orange_terracotta
fill 546 278 528 546 281 528 minecraft:orange_terracotta
fill 546 278 535 546 281 535 minecraft:orange_terracotta
fill 552 278 510 552 307 510 minecraft:black_concrete
setblock 552 278 513 minecraft:light[level=14]
setblock 552 278 521 minecraft:light[level=14]
setblock 552 278 529 minecraft:light[level=14]
setblock 552 278 537 minecraft:light[level=14]
setblock 552 278 545 minecraft:light[level=14]
setblock 559 278 521 minecraft:magma_block
setblock 517 279 532 minecraft:magma_block
fill 517 279 533 517 307 533 minecraft:black_concrete
fill 517 279 548 517 294 548 minecraft:black_concrete
fill 534 279 510 534 307 510 minecraft:black_concrete
setblock 535 279 510 minecraft:shroomlight
fill 559 279 521 559 307 521 minecraft:black_concrete
fill 517 280 532 531 280 532 minecraft:black_concrete
setblock 517 280 535 minecraft:magma_block
fill 518 280 511 531 280 531 minecraft:black_concrete
fill 518 280 533 531 280 551 minecraft:black_concrete
setblock 521 280 552 minecraft:magma_block
setblock 529 280 552 minecraft:magma_block
fill 532 280 511 532 280 527 minecraft:black_concrete
fill 532 280 536 532 280 551 minecraft:black_concrete
fill 533 280 511 533 280 526 minecraft:black_concrete
fill 533 280 537 533 280 551 minecraft:black_concrete
fill 534 280 511 534 280 525 minecraft:black_concrete
fill 534 280 538 534 280 551 minecraft:black_concrete
fill 535 280 510 535 280 524 minecraft:black_concrete
fill 535 280 539 536 280 551 minecraft:black_concrete
fill 536 280 511 536 280 524 minecraft:black_concrete
fill 537 280 511 558 280 523 minecraft:black_concrete
fill 537 280 530 537 286 530 minecraft:red_terracotta
fill 537 280 531 537 280 533 minecraft:shroomlight
fill 537 280 540 558 280 551 minecraft:black_concrete
fill 538 280 529 538 286 529 minecraft:red_terracotta
fill 538 280 530 538 280 531 minecraft:shroomlight
fill 538 280 533 538 280 534 minecraft:shroomlight
fill 538 280 535 538 285 536 minecraft:red_terracotta
fill 539 280 529 539 280 530 minecraft:shroomlight
fill 539 280 534 539 280 535 minecraft:shroomlight
fill 539 280 536 540 285 536 minecraft:red_terracotta
fill 540 280 529 541 280 529 minecraft:shroomlight
fill 540 280 535 541 280 535 minecraft:shroomlight
fill 541 280 528 542 285 528 minecraft:red_terracotta
fill 541 280 530 542 280 530 minecraft:shroomlight
fill 541 280 534 542 280 534 minecraft:shroomlight
fill 542 280 524 558 280 524 minecraft:black_concrete
fill 542 280 529 542 285 529 minecraft:red_terracotta
fill 542 280 531 543 280 531 minecraft:shroomlight
fill 542 280 533 543 280 533 minecraft:shroomlight
fill 542 280 535 542 285 535 minecraft:red_terracotta
fill 542 280 539 558 280 539 minecraft:black_concrete
fill 543 280 530 543 285 530 minecraft:red_terracotta
setblock 543 280 532 minecraft:shroomlight
fill 544 280 525 558 280 525 minecraft:black_concrete
fill 544 280 538 558 280 538 minecraft:black_concrete
fill 545 280 526 558 280 526 minecraft:black_concrete
fill 545 280 537 558 280 537 minecraft:black_concrete
fill 546 280 527 558 280 527 minecraft:black_concrete
fill 546 280 536 558 280 536 minecraft:black_concrete
fill 547 280 528 558 280 535 minecraft:black_concrete
fill 557 280 510 557 305 510 minecraft:black_concrete
setblock 558 280 510 minecraft:magma_block
setblock 559 280 532 minecraft:magma_block
fill 517 281 532 517 307 532 minecraft:black_concrete
fill 517 281 535 517 294 535 minecraft:black_concrete
fill 521 281 552 521 307 552 minecraft:black_concrete
setblock 526 281 510 minecraft:shroomlight
fill 529 281 552 529 307 552 minecraft:black_concrete
fill 535 281 510 535 285 510 minecraft:black_concrete
fill 536 281 552 536 307 552 minecraft:black_concrete
fill 537 281 531 537 286 533 minecraft:red_terracotta
setblock 537 281 552 minecraft:white_concrete
fill 538 281 530 538 286 531 minecraft:red_terracotta
fill 538 281 533 538 286 534 minecraft:red_terracotta
fill 538 281 552 538 283 552 minecraft:black_concrete
fill 539 281 529 539 286 530 minecraft:red_terracotta
fill 539 281 534 539 285 535 minecraft:red_terracotta
fill 540 281 529 541 285 529 minecraft:red_terracotta
fill 540 281 535 541 285 535 minecraft:red_terracotta
fill 541 281 530 542 285 530 minecraft:red_terracotta
fill 541 281 534 542 285 534 minecraft:red_terracotta
fill 542 281 531 543 285 531 minecraft:red_terracotta
fill 542 281 533 543 285 533 minecraft:red_terracotta
fill 543 281 532 543 285 532 minecraft:red_terracotta
fill 558 281 510 558 291 510 minecraft:black_concrete
fill 559 281 532 559 307 532 minecraft:black_concrete
setblock 559 281 539 minecraft:shroomlight
fill 517 282 543 517 307 543 minecraft:black_concrete
setblock 517 282 544 minecraft:white_concrete
fill 517 282 545 517 282 547 minecraft:black_concrete
fill 526 282 510 526 307 510 minecraft:black_concrete
setblock 527 282 510 minecraft:white_concrete
fill 533 282 528 533 283 528 minecraft:orange_terracotta
fill 533 282 535 533 283 535 minecraft:orange_terracotta
fill 535 282 526 535 283 526 minecraft:orange_terracotta
fill 535 282 537 535 283 537 minecraft:orange_terracotta
fill 536 282 525 537 283 525 minecraft:orange_terracotta
fill 536 282 538 537 283 538 minecraft:orange_terracotta
fill 537 282 552 537 307 552 minecraft:black_concrete
setblock 540 282 510 minecraft:magma_block
fill 541 282 525 542 283 525 minecraft:orange_terracotta
fill 541 282 538 542 283 538 minecraft:orange_terracotta
fill 543 282 526 543 283 526 minecraft:orange_terracotta
fill 543 282 537 543 283 537 minecraft:orange_terracotta
fill 545 282 528 545 283 528 minecraft:orange_terracotta
fill 545 282 535 545 283 535 minecraft:orange_terracotta
fill 559 282 539 559 307 539 minecraft:black_concrete
setblock 517 283 525 minecraft:magma_block
setblock 517 283 537 minecraft:shroomlight
fill 517 283 544 517 291 545 minecraft:black_concrete
setblock 517 283 546 minecraft:white_concrete
fill 517 283 547 517 307 547 minecraft:black_concrete
fill 527 283 510 527 307 510 minecraft:black_concrete
fill 533 283 529 533 284 529 minecraft:orange_terracotta
fill 533 283 534 533 284 534 minecraft:orange_terracotta
setblock 534 283 527 minecraft:orange_terracotta
setblock 534 283 536 minecraft:orange_terracotta
fill 538 283 525 540 284 525 minecraft:orange_terracotta
fill 538 283 532 538 286 532 minecraft:red_terracotta
fill 538 283 538 540 284 538 minecraft:orange_terracotta
fill 539 283 531 539 286 531 minecraft:red_terracotta
fill 539 283 533 539 286 533 minecraft:red_terracotta
fill 540 283 510 540 307 510 minecraft:black_concrete
fill 540 283 530 540 286 530 minecraft:red_terracotta
fill 540 283 534 540 286 534 minecraft:red_terracotta
fill 541 283 531 541 286 531 minecraft:red_terracotta
fill 541 283 533 541 286 533 minecraft:red_terracotta
fill 542 283 532 542 285 532 minecraft:red_terracotta
setblock 544 283 527 minecraft:orange_terracotta
setblock 544 283 536 minecraft:orange_terracotta
fill 545 283 529 545 284 529 minecraft:orange_terracotta
fill 545 283 534 545 284 534 minecraft:orange_terracotta
fill 517 284 525 517 306 525 minecraft:black_concrete
fill 517 284 537 517 307 537 minecraft:black_concrete
fill 517 284 546 517 307 546 minecraft:black_concrete
setblock 522 284 510 minecraft:shroomlight
fill 533 284 530 533 284 533 minecraft:orange_terracotta
setblock 534 284 528 minecraft:orange_terracotta
setblock 534 284 535 minecraft:orange_terracotta
setblock 535 284 527 minecraft:orange_terracotta
setblock 535 284 536 minecraft:orange_terracotta
fill 536 284 526 537 284 526 minecraft:orange_terracotta
fill 536 284 537 537 284 537 minecraft:orange_terracotta
setblock 538 284 552 minecraft:white_concrete
fill 541 284 526 542 284 526 minecraft:orange_terracotta
fill 541 284 537 542 284 537 minecraft:orange_terracotta
setblock 543 284 527 minecraft:orange_terracotta
setblock 543 284 536 minecraft:orange_terracotta
setblock 544 284 528 minecraft:orange_terracotta
setblock 544 284 535 minecraft:orange_terracotta
fill 545 284 530 545 284 533 minecraft:orange_terracotta
fill 522 285 510 522 293 510 minecraft:black_concrete
fill 534 285 529 534 285 534 minecraft:orange_terracotta
fill 535 285 528 535 285 529 minecraft:orange_terracotta
fill 535 285 534 535 285 535 minecraft:orange_terracotta
fill 536 285 527 537 285 527 minecraft:orange_terracotta
fill 536 285 536 537 285 536 minecraft:orange_terracotta
fill 538 285 526 540 285 526 minecraft:orange_terracotta
fill 538 285 537 540 285 537 minecraft:orange_terracotta
fill 538 285 552 538 307 552 minecraft:black_concrete
setblock 539 285 510 minecraft:shroomlight
fill 541 285 527 542 285 527 minecraft:orange_terracotta
fill 541 285 536 542 285 536 minecraft:orange_terracotta
fill 543 285 528 543 285 529 minecraft:orange_terracotta
fill 543 285 534 543 285 535 minecraft:orange_terracotta
fill 544 285 529 544 285 534 minecraft:orange_terracotta
setblock 559 285 517 minecraft:magma_block
setblock 559 285 536 minecraft:magma_block
setblock 520 286 513 minecraft:light[level=14]
setblock 520 286 521 minecraft:light[level=14]
setblock 520 286 529 minecraft:light[level=14]
setblock 520 286 537 minecraft:light[level=14]
setblock 520 286 545 minecraft:light[level=14]
setblock 528 286 513 minecraft:light[level=14]
setblock 528 286 521 minecraft:light[level=14]
setblock 528 286 529 minecraft:light[level=14]
setblock 528 286 537 minecraft:light[level=14]
setblock 528 286 545 minecraft:light[level=14]
setblock 532 286 510 minecraft:white_concrete
setblock 535 286 510 minecraft:magma_block
fill 535 286 530 536 286 533 minecraft:orange_terracotta
setblock 536 286 513 minecraft:light[level=14]
setblock 536 286 521 minecraft:light[level=14]
fill 536 286 528 537 286 529 minecraft:orange_terracotta
fill 536 286 534 537 286 535 minecraft:orange_terracotta
setblock 536 286 537 minecraft:light[level=14]
setblock 536 286 545 minecraft:light[level=14]
fill 538 286 527 540 286 528 minecraft:orange_terracotta
fill 538 286 535 540 286 536 minecraft:orange_terracotta
fill 539 286 510 539 299 510 minecraft:black_concrete
setblock 539 286 534 minecraft:red_terracotta
setblock 540 286 529 minecraft:red_terracotta
fill 541 286 528 542 286 529 minecraft:orange_terracotta
setblock 541 286 530 minecraft:red_terracotta
fill 541 286 534 542 286 535 minecraft:orange_terracotta
fill 542 286 530 543 286 533 minecraft:orange_terracotta
setblock 544 286 513 minecraft:light[level=14]
setblock 544 286 521 minecraft:light[level=14]
setblock 544 286 529 minecraft:light[level=14]
setblock 544 286 537 minecraft:light[level=14]
setblock 544 286 545 minecraft:light[level=14]
setblock 552 286 513 minecraft:light[level=14]
setblock 552 286 521 minecraft:light[level=14]
setblock 552 286 529 minecraft:light[level=14]
setblock 552 286 537 minecraft:light[level=14]
setblock 552 286 545 minecraft:light[level=14]
fill 559 286 517 559 297 517 minecraft:black_concrete
fill 559 286 536 559 287 536 minecraft:black_concrete
setblock 517 287 522 minecraft:shroomlight
fill 532 287 510 532 307 510 minecraft:black_concrete
fill 535 287 510 535 307 510 minecraft:black_concrete
fill 537 287 530 538 287 533 minecraft:orange_terracotta
fill 538 287 529 540 287 529 minecraft:orange_terracotta
fill 538 287 534 540 287 534 minecraft:orange_terracotta
fill 539 287 530 539 287 531 minecraft:orange_terracotta
setblock 539 287 533 minecraft:orange_terracotta
fill 540 287 530 541 287 530 minecraft:orange_terracotta
setblock 541 287 531 minecraft:orange_terracotta
setblock 541 287 533 minecraft:orange_terracotta
fill 559 287 510 559 307 511 minecraft:black_concrete
setblock 559 287 512 minecraft:white_concrete
setblock 559 287 538 minecraft:white_concrete
setblock 559 287 545 minecraft:shroomlight
fill 559 287 546 559 307 546 minecraft:black_concrete
fill 517 288 518 517 290 518 minecraft:orange_concrete
fill 517 288 522 517 289 522 minecraft:black_concrete
fill 517 288 534 517 290 534 minecraft:orange_concrete
setblock 517 288 541 minecraft:shroomlight
fill 517 288 550 517 290 550 minecraft:orange_concrete
fill 521 288 510 521 290 510 minecraft:orange_concrete
fill 531 288 552 531 290 552 minecraft:orange_concrete
fill 533 288 541 533 289 541 minecraft:magma_block
setblock 534 288 552 minecraft:magma_block
fill 535 288 552 535 289 552 minecraft:black_concrete
fill 537 288 510 537 290 510 minecraft:orange_concrete
fill 547 288 552 547 290 552 minecraft:orange_concrete
fill 553 288 510 553 290 510 minecraft:orange_concrete
fill 559 288 512 559 298 512 minecraft:black_concrete
setblock 559 288 513 minecraft:magma_block
fill 559 288 520 559 290 520 minecraft:orange_concrete
fill 559 288 536 559 290 536 minecraft:orange_concrete
fill 559 288 538 559 296 538 minecraft:black_concrete
fill 559 288 545 559 307 545 minecraft:black_concrete
fill 517 289 541 517 307 541 minecraft:black_concrete
fill 534 289 552 534 304 552 minecraft:black_concrete
setblock 549 289 552 minecraft:white_concrete
setblock 551 289 552 minecraft:white_concrete
fill 552 289 535 552 290 535 minecraft:magma_block
fill 552 289 552 552 307 552 minecraft:black_concrete
fill 559 289 513 559 307 513 minecraft:black_concrete
setblock 517 290 515 minecraft:white_concrete
setblock 517 290 522 minecraft:white_concrete
setblock 517 290 530 minecraft:white_concrete
fill 517 290 531 517 298 531 minecraft:black_concrete
fill 533 290 541 533 296 541 minecraft:blackstone
setblock 535 290 552 minecraft:white_concrete
fill 547 290 510 548 307 510 minecraft:black_concrete
setblock 549 290 510 minecraft:magma_block
fill 549 290 552 549 307 552 minecraft:black_concrete
fill 550 290 510 550 307 510 minecraft:black_concrete
fill 551 290 552 551 294 552 minecraft:black_concrete
setblock 553 290 552 minecraft:magma_block
setblock 559 290 519 minecraft:magma_block
setblock 559 290 543 minecraft:white_concrete
setblock 559 290 544 minecraft:shroomlight
fill 517 291 515 517 304 515 minecraft:black_concrete
setblock 517 291 516 minecraft:magma_block
fill 517 291 518 517 296 518 minecraft:black_concrete
fill 517 291 522 517 307 522 minecraft:black_concrete
fill 517 291 530 517 294 530 minecraft:black_concrete
fill 517 291 534 517 296 534 minecraft:black_concrete
fill 517 291 550 517 296 550 minecraft:black_concrete
setblock 519 291 510 minecraft:shroomlight
fill 520 291 510 521 296 510 minecraft:black_concrete
fill 531 291 552 531 296 552 minecraft:black_concrete
fill 533 291 540 533 296 540 minecraft:blackstone
fill 535 291 552 535 307 552 minecraft:black_concrete
fill 537 291 510 537 296 510 minecraft:black_concrete
fill 547 291 552 547 296 552 minecraft:black_concrete
fill 549 291 510 549 301 510 minecraft:black_concrete
fill 553 291 510 553 296 510 minecraft:black_concrete
fill 553 291 552 553 307 552 minecraft:black_concrete
setblock 559 291 518 minecraft:magma_block
fill 559 291 519 559 292 520 minecraft:black_concrete
fill 559 291 536 559 296 536 minecraft:black_concrete
fill 559 291 543 559 307 544 minecraft:black_concrete
fill 517 292 516 517 295 516 minecraft:black_concrete
fill 517 292 544 517 307 544 minecraft:black_concrete
setblock 517 292 545 minecraft:shroomlight
fill 519 292 510 519 307 510 minecraft:black_concrete
fill 529 292 515 529 293 515 minecraft:magma_block
fill 532 292 540 532 296 541 minecraft:blackstone
fill 534 292 540 534 296 541 minecraft:blackstone
setblock 558 292 510 minecraft:shroomlight
fill 559 292 518 559 307 518 minecraft:black_concrete
setblock 517 293 542 minecraft:magma_block
setblock 517 293 545 minecraft:magma_block
fill 529 293 522 529 294 523 minecraft:blue_concrete
fill 532 293 542 534 296 542 minecraft:blackstone
fill 533 293 539 533 296 539 minecraft:blackstone
fill 538 293 548 538 294 549 minecraft:magma_block
fill 558 293 510 558 307 510 minecraft:black_concrete
setblock 559 293 519 minecraft:shroomlight
fill 559 293 520 559 296 520 minecraft:black_concrete
fill 517 294 526 517 307 526 minecraft:black_concrete
setblock 517 294 527 minecraft:shroomlight
fill 517 294 542 517 307 542 minecraft:black_concrete
fill 517 294 545 517 301 545 minecraft:black_concrete
setblock 520 294 513 minecraft:light[level=14]
setblock 520 294 521 minecraft:light[level=14]
setblock 520 294 529 minecraft:light[level=14]
setblock 520 294 537 minecraft:light[level=14]
setblock 520 294 545 minecraft:light[level=14]
setblock 520 294 552 minecraft:magma_block
setblock 522 294 510 minecraft:white_concrete
setblock 528 294 513 minecraft:light[level=14]
setblock 528 294 521 minecraft:light[level=14]
setblock 528 294 529 minecraft:light[level=14]
setblock 528 294 537 minecraft:light[level=14]
setblock 528 294 545 minecraft:light[level=14]
setblock 530 294 510 minecraft:white_concrete
fill 531 294 510 531 307 510 minecraft:black_concrete
fill 531 294 540 531 296 541 minecraft:blackstone
fill 532 294 539 532 296 539 minecraft:blackstone
fill 534 294 539 534 296 539 minecraft:blackstone
fill 535 294 540 535 296 541 minecraft:blackstone
setblock 536 294 513 minecraft:light[level=14]
setblock 536 294 521 minecraft:light[level=14]
setblock 536 294 529 minecraft:light[level=14]
setblock 536 294 537 minecraft:light[level=14]
setblock 536 294 545 minecraft:light[level=14]
setblock 544 294 513 minecraft:light[level=14]
setblock 544 294 521 minecraft:light[level=14]
setblock 544 294 529 minecraft:light[level=14]
setblock 544 294 537 minecraft:light[level=14]
setblock 544 294 545 minecraft:light[level=14]
setblock 552 294 513 minecraft:light[level=14]
setblock 552 294 521 minecraft:light[level=14]
setblock 552 294 529 minecraft:light[level=14]
setblock 552 294 537 minecraft:light[level=14]
setblock 552 294 545 minecraft:light[level=14]
fill 559 294 519 559 307 519 minecraft:black_concrete
setblock 559 294 527 minecraft:white_concrete
fill 559 294 528 559 297 529 minecraft:black_concrete
setblock 559 294 537 minecraft:white_concrete
fill 517 295 527 517 307 527 minecraft:black_concrete
setblock 517 295 530 minecraft:magma_block
setblock 517 295 535 minecraft:magma_block
fill 517 295 538 517 307 538 minecraft:black_concrete
setblock 517 295 539 minecraft:magma_block
setblock 517 295 548 minecraft:magma_block
fill 520 295 552 520 307 552 minecraft:black_concrete
fill 522 295 510 522 307 510 minecraft:black_concrete
fill 530 295 510 530 307 510 minecraft:black_concrete
fill 531 295 539 531 296 539 minecraft:blackstone
fill 531 295 542 531 296 542 minecraft:blackstone
fill 532 295 543 534 296 543 minecraft:blackstone
fill 533 295 538 533 296 538 minecraft:blackstone
fill 535 295 539 535 296 539 minecraft:blackstone
fill 535 295 542 535 296 542 minecraft:blackstone
setblock 551 295 552 minecraft:shroomlight
fill 559 295 527 559 307 527 minecraft:black_concrete
fill 559 295 537 559 307 537 minecraft:black_concrete
setblock 517 296 516 minecraft:white_concrete
fill 517 296 530 517 307 530 minecraft:black_concrete
fill 517 296 535 517 307 535 minecraft:black_concrete
fill 517 296 539 517 307 539 minecraft:black_concrete
fill 517 296 548 517 307 548 minecraft:black_concrete
setblock 517 296 549 minecraft:shroomlight
fill 530 296 540 530 296 541 minecraft:blackstone
setblock 531 296 543 minecraft:blackstone
setblock 532 296 538 minecraft:blackstone
setblock 534 296 538 minecraft:blackstone
setblock 536 296 510 minecraft:white_concrete
setblock 536 296 541 minecraft:blackstone
setblock 545 296 510 minecraft:magma_block
fill 551 296 552 551 307 552 minecraft:black_concrete
setblock 556 296 510 minecraft:magma_block
fill 517 297 516 517 307 516 minecraft:black_concrete
fill 517 297 518 517 299 518 minecraft:orange_concrete
setblock 517 297 524 minecraft:magma_block
fill 517 297 534 517 299 534 minecraft:orange_concrete
fill 517 297 549 517 304 549 minecraft:black_concrete
fill 517 297 550 517 299 550 minecraft:orange_concrete
fill 520 297 510 520 307 510 minecraft:black_concrete
fill 521 297 510 521 299 510 minecraft:orange_concrete
fill 522 297 552 524 307 552 minecraft:black_concrete
setblock 525 297 552 minecraft:shroomlight
fill 526 297 552 526 307 552 minecraft:black_concrete
fill 531 297 552 531 299 552 minecraft:orange_concrete
fill 532 297 540 534 297 541 minecraft:magma_block
fill 536 297 510 536 305 510 minecraft:black_concrete
fill 537 297 510 537 299 510 minecraft:orange_concrete
fill 545 297 510 545 298 510 minecraft:black_concrete
fill 547 297 552 547 299 552 minecraft:orange_concrete
fill 553 297 510 553 299 510 minecraft:orange_concrete
fill 556 297 510 556 306 510 minecraft:black_concrete
fill 559 297 520 559 299 520 minecraft:orange_concrete
fill 559 297 536 559 299 536 minecraft:orange_concrete
setblock 559 297 538 minecraft:shroomlight
setblock 559 297 551 minecraft:magma_block
fill 517 298 524 517 307 524 minecraft:black_concrete
fill 525 298 552 525 307 552 minecraft:black_concrete
fill 532 298 541 533 298 541 minecraft:magma_block
fill 533 298 540 533 299 540 minecraft:magma_block
setblock 559 298 517 minecraft:shroomlight
setblock 559 298 528 minecraft:white_concrete
fill 559 298 529 559 307 529 minecraft:black_concrete
fill 559 298 538 559 306 538 minecraft:black_concrete
fill 559 298 551 559 307 551 minecraft:black_concrete
setblock 517 299 531 minecraft:white_concrete
fill 528 299 544 529 300 544 minecraft:blackstone
fill 533 299 541 533 300 541 minecraft:magma_block
setblock 545 299 510 minecraft:white_concrete
setblock 559 299 512 minecraft:shroomlight
fill 559 299 517 559 307 517 minecraft:black_concrete
fill 559 299 528 559 307 528 minecraft:black_concrete
setblock 517 300 512 minecraft:shroomlight
fill 517 300 518 517 307 518 minecraft:black_concrete
fill 517 300 531 517 307 531 minecraft:black_concrete
fill 517 300 534 517 307 534 minecraft:black_concrete
fill 517 300 550 517 307 550 minecraft:black_concrete
fill 521 300 510 521 307 510 minecraft:black_concrete
fill 531 300 552 531 307 552 minecraft:black_concrete
fill 537 300 510 537 307 510 minecraft:black_concrete
setblock 539 300 510 minecraft:magma_block
fill 545 300 510 545 307 510 minecraft:black_concrete
fill 547 300 552 547 307 552 minecraft:black_concrete
fill 553 300 510 553 307 510 minecraft:black_concrete
fill 559 300 512 559 307 512 minecraft:black_concrete
fill 559 300 520 559 307 520 minecraft:black_concrete
setblock 559 300 525 minecraft:magma_block
fill 559 300 536 559 307 536 minecraft:black_concrete
fill 517 301 512 517 307 512 minecraft:black_concrete
fill 539 301 510 539 307 510 minecraft:black_concrete
fill 559 301 525 559 307 525 minecraft:black_concrete
setblock 517 302 545 minecraft:magma_block
setblock 520 302 513 minecraft:light[level=14]
setblock 520 302 521 minecraft:light[level=14]
setblock 520 302 529 minecraft:light[level=14]
setblock 520 302 537 minecraft:light[level=14]
setblock 520 302 545 minecraft:light[level=14]
setblock 528 302 513 minecraft:light[level=14]
setblock 528 302 521 minecraft:light[level=14]
setblock 528 302 529 minecraft:light[level=14]
setblock 528 302 537 minecraft:light[level=14]
setblock 528 302 545 minecraft:light[level=14]
setblock 536 302 513 minecraft:light[level=14]
setblock 536 302 521 minecraft:light[level=14]
setblock 536 302 529 minecraft:light[level=14]
setblock 536 302 537 minecraft:light[level=14]
setblock 536 302 545 minecraft:light[level=14]
setblock 544 302 513 minecraft:light[level=14]
setblock 544 302 521 minecraft:light[level=14]
setblock 544 302 529 minecraft:light[level=14]
setblock 544 302 537 minecraft:light[level=14]
setblock 544 302 545 minecraft:light[level=14]
setblock 549 302 510 minecraft:white_concrete
setblock 552 302 513 minecraft:light[level=14]
setblock 552 302 521 minecraft:light[level=14]
setblock 552 302 529 minecraft:light[level=14]
setblock 552 302 537 minecraft:light[level=14]
setblock 552 302 545 minecraft:light[level=14]
fill 517 303 545 517 307 545 minecraft:black_concrete
fill 549 303 510 549 307 510 minecraft:black_concrete
setblock 527 304 552 minecraft:shroomlight
fill 528 304 552 528 307 552 minecraft:black_concrete
setblock 533 304 552 minecraft:magma_block
setblock 542 304 510 minecraft:magma_block
setblock 517 305 515 minecraft:shroomlight
setblock 517 305 549 minecraft:white_concrete
fill 527 305 552 527 307 552 minecraft:black_concrete
fill 533 305 552 533 307 552 minecraft:black_concrete
setblock 534 305 552 minecraft:magma_block
fill 542 305 510 542 307 510 minecraft:black_concrete
setblock 556 305 552 minecraft:magma_block
fill 559 305 549 559 306 549 minecraft:white_concrete
fill 517 306 515 517 307 515 minecraft:black_concrete
fill 517 306 549 517 307 549 minecraft:black_concrete
setblock 519 306 552 minecraft:shroomlight
setblock 524 306 510 minecraft:magma_block
fill 534 306 552 534 307 552 minecraft:black_concrete
setblock 536 306 510 minecraft:magma_block
setblock 545 306 552 minecraft:shroomlight
fill 556 306 552 556 307 552 minecraft:black_concrete
setblock 557 306 510 minecraft:magma_block
fill 559 306 515 559 307 515 minecraft:black_concrete
setblock 559 306 516 minecraft:white_concrete
setblock 517 307 525 minecraft:magma_block
setblock 519 307 552 minecraft:black_concrete
setblock 524 307 510 minecraft:black_concrete
setblock 536 307 510 minecraft:black_concrete
setblock 545 307 552 minecraft:black_concrete
setblock 546 307 510 minecraft:white_concrete
setblock 556 307 510 minecraft:magma_block
setblock 557 307 510 minecraft:black_concrete
setblock 559 307 516 minecraft:black_concrete
setblock 559 307 538 minecraft:white_concrete
setblock 559 307 549 minecraft:black_concrete
