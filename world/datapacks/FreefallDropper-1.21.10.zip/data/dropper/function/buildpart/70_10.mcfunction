fill 483 236 276 486 236 276 minecraft:deepslate_tiles
setblock 483 236 315 minecraft:cobbled_deepslate
fill 483 236 316 486 236 316 minecraft:deepslate_tiles
setblock 484 236 313 minecraft:deepslate_tiles
setblock 484 236 314 minecraft:cobbled_deepslate
fill 484 236 315 487 236 315 minecraft:deepslate_tiles
setblock 485 236 313 minecraft:cobbled_deepslate
fill 485 236 314 488 236 314 minecraft:deepslate_tiles
setblock 486 236 277 minecraft:cobbled_deepslate
fill 486 236 313 486 237 313 minecraft:deepslate_tiles
setblock 487 236 276 minecraft:cobbled_deepslate
fill 487 236 277 487 239 277 minecraft:deepslate_tiles
setblock 487 236 316 minecraft:cobbled_deepslate
fill 488 236 276 488 239 276 minecraft:deepslate_tiles
setblock 488 236 315 minecraft:cobbled_deepslate
fill 488 236 316 491 236 316 minecraft:deepslate_tiles
setblock 489 236 314 minecraft:cobbled_deepslate
fill 489 236 315 489 239 315 minecraft:deepslate_tiles
setblock 490 236 313 minecraft:cobbled_deepslate
fill 490 236 314 490 238 314 minecraft:deepslate_tiles
setblock 491 236 277 minecraft:cobbled_deepslate
setblock 492 236 276 minecraft:cobbled_deepslate
setblock 492 236 316 minecraft:cobbled_deepslate
fill 493 236 276 493 239 276 minecraft:deepslate_tiles
setblock 493 236 315 minecraft:cobbled_deepslate
fill 493 236 316 493 239 316 minecraft:deepslate_tiles
fill 494 236 315 494 237 315 minecraft:deepslate_tiles
setblock 497 236 316 minecraft:cobbled_deepslate
fill 498 236 316 501 236 316 minecraft:deepslate_tiles
setblock 501 236 276 minecraft:deepslate_tiles
setblock 502 236 276 minecraft:cobbled_deepslate
setblock 502 236 316 minecraft:cobbled_deepslate
fill 503 236 276 506 236 276 minecraft:deepslate_tiles
fill 503 236 316 506 236 316 minecraft:deepslate_tiles
fill 504 236 277 505 236 277 minecraft:deepslate_tiles
fill 504 236 315 507 236 315 minecraft:deepslate_tiles
setblock 506 236 277 minecraft:cobbled_deepslate
fill 506 236 278 509 236 278 minecraft:deepslate_tiles
setblock 507 236 276 minecraft:cobbled_deepslate
fill 507 236 277 510 236 277 minecraft:deepslate_tiles
fill 507 236 314 508 236 314 minecraft:deepslate_tiles
setblock 507 236 316 minecraft:cobbled_deepslate
fill 508 236 276 508 239 276 minecraft:deepslate_tiles
fill 508 236 288 508 236 289 minecraft:deepslate_tiles
setblock 508 236 290 minecraft:cobbled_deepslate
fill 508 236 291 508 238 291 minecraft:deepslate_tiles
fill 508 236 293 508 236 294 minecraft:deepslate_tiles
setblock 508 236 295 minecraft:cobbled_deepslate
fill 508 236 296 508 237 296 minecraft:deepslate_tiles
setblock 508 236 315 minecraft:cobbled_deepslate
fill 508 236 316 508 239 316 minecraft:deepslate_tiles
setblock 509 236 279 minecraft:cobbled_deepslate
fill 509 236 280 509 236 283 minecraft:deepslate_tiles
setblock 509 236 284 minecraft:cobbled_deepslate
fill 509 236 285 509 237 285 minecraft:deepslate_tiles
setblock 509 236 289 minecraft:cobbled_deepslate
fill 509 236 290 509 239 290 minecraft:deepslate_tiles
setblock 509 236 293 minecraft:deepslate_tiles
setblock 509 236 294 minecraft:cobbled_deepslate
fill 509 236 295 509 239 295 minecraft:deepslate_tiles
setblock 509 236 298 minecraft:deepslate_tiles
setblock 509 236 313 minecraft:deepslate_tiles
setblock 509 236 314 minecraft:cobbled_deepslate
fill 509 236 315 509 239 315 minecraft:deepslate_tiles
setblock 510 236 278 minecraft:cobbled_deepslate
fill 510 236 279 510 236 282 minecraft:deepslate_tiles
setblock 510 236 283 minecraft:cobbled_deepslate
fill 510 236 284 510 239 284 minecraft:deepslate_tiles
setblock 510 236 288 minecraft:cobbled_deepslate
fill 510 236 289 510 239 289 minecraft:deepslate_tiles
setblock 510 236 293 minecraft:cobbled_deepslate
fill 510 236 294 510 239 294 minecraft:deepslate_tiles
setblock 510 236 297 minecraft:deepslate_tiles
setblock 510 236 298 minecraft:cobbled_deepslate
fill 510 236 299 510 239 299 minecraft:deepslate_tiles
setblock 510 236 313 minecraft:cobbled_deepslate
fill 510 236 314 510 239 314 minecraft:deepslate_tiles
setblock 511 236 277 minecraft:cobbled_deepslate
fill 511 236 278 511 236 281 minecraft:deepslate_tiles
setblock 511 236 282 minecraft:cobbled_deepslate
fill 511 236 283 511 239 283 minecraft:deepslate_tiles
setblock 511 236 287 minecraft:cobbled_deepslate
fill 511 236 288 511 239 288 minecraft:deepslate_tiles
setblock 511 236 292 minecraft:cobbled_deepslate
fill 511 236 293 511 239 293 minecraft:deepslate_tiles
setblock 511 236 297 minecraft:cobbled_deepslate
fill 511 236 298 511 239 298 minecraft:deepslate_tiles
setblock 511 236 302 minecraft:cobbled_deepslate
setblock 511 236 303 minecraft:deepslate_tiles
setblock 511 236 307 minecraft:cobbled_deepslate
fill 511 236 308 511 237 308 minecraft:deepslate_tiles
setblock 511 236 312 minecraft:cobbled_deepslate
fill 511 236 313 511 239 313 minecraft:deepslate_tiles
fill 470 237 275 470 308 275 minecraft:deepslate_tiles
setblock 470 237 276 minecraft:white_wool
fill 470 237 277 472 238 278 minecraft:deepslate_tiles
setblock 471 237 276 minecraft:cobbled_deepslate
fill 471 237 279 471 237 280 minecraft:deepslate_tiles
setblock 471 237 281 minecraft:cobbled_deepslate
fill 471 237 282 471 237 285 minecraft:deepslate_tiles
setblock 471 237 286 minecraft:cobbled_deepslate
fill 471 237 287 471 238 287 minecraft:deepslate_tiles
setblock 471 237 291 minecraft:cobbled_deepslate
fill 471 237 292 471 239 292 minecraft:deepslate_tiles
setblock 471 237 296 minecraft:cobbled_deepslate
fill 471 237 297 471 240 297 minecraft:deepslate_tiles
setblock 471 237 300 minecraft:deepslate_tiles
setblock 471 237 301 minecraft:cobbled_deepslate
fill 471 237 302 471 237 305 minecraft:deepslate_tiles
setblock 471 237 306 minecraft:cobbled_deepslate
fill 471 237 307 471 237 310 minecraft:deepslate_tiles
setblock 471 237 311 minecraft:cobbled_deepslate
fill 471 237 312 471 237 315 minecraft:deepslate_tiles
setblock 471 237 316 minecraft:cobbled_deepslate
fill 472 237 276 472 240 276 minecraft:deepslate_tiles
setblock 472 237 279 minecraft:deepslate_tiles
setblock 472 237 280 minecraft:cobbled_deepslate
setblock 472 237 290 minecraft:cobbled_deepslate
setblock 472 237 291 minecraft:deepslate_tiles
setblock 472 237 295 minecraft:cobbled_deepslate
fill 472 237 296 472 238 296 minecraft:deepslate_tiles
setblock 472 237 309 minecraft:deepslate_tiles
setblock 472 237 310 minecraft:cobbled_deepslate
fill 472 237 311 472 239 311 minecraft:deepslate_tiles
setblock 472 237 314 minecraft:deepslate_tiles
setblock 472 237 315 minecraft:cobbled_deepslate
fill 472 237 316 475 237 316 minecraft:deepslate_tiles
setblock 473 237 278 minecraft:light[level=13]
setblock 473 237 286 minecraft:light[level=13]
setblock 473 237 294 minecraft:light[level=13]
setblock 473 237 302 minecraft:light[level=13]
setblock 473 237 310 minecraft:light[level=13]
setblock 473 237 314 minecraft:cobbled_deepslate
fill 473 237 315 476 237 315 minecraft:deepslate_tiles
fill 474 237 314 474 238 314 minecraft:deepslate_tiles
setblock 475 237 277 minecraft:cobbled_deepslate
setblock 476 237 276 minecraft:cobbled_deepslate
setblock 476 237 316 minecraft:cobbled_deepslate
fill 477 237 276 480 237 276 minecraft:deepslate_tiles
setblock 477 237 315 minecraft:cobbled_deepslate
fill 477 237 316 480 237 316 minecraft:deepslate_tiles
setblock 478 237 314 minecraft:cobbled_deepslate
fill 478 237 315 481 237 315 minecraft:deepslate_tiles
fill 479 237 314 482 237 314 minecraft:deepslate_tiles
setblock 481 237 276 minecraft:cobbled_deepslate
setblock 481 237 278 minecraft:light[level=13]
setblock 481 237 286 minecraft:light[level=13]
setblock 481 237 294 minecraft:light[level=13]
setblock 481 237 302 minecraft:light[level=13]
setblock 481 237 310 minecraft:light[level=13]
setblock 481 237 316 minecraft:cobbled_deepslate
fill 482 237 276 485 237 276 minecraft:deepslate_tiles
setblock 482 237 315 minecraft:cobbled_deepslate
fill 482 237 316 485 237 316 minecraft:deepslate_tiles
setblock 483 237 314 minecraft:cobbled_deepslate
fill 483 237 315 486 237 315 minecraft:deepslate_tiles
fill 484 237 314 487 237 314 minecraft:deepslate_tiles
setblock 485 237 277 minecraft:cobbled_deepslate
setblock 485 237 313 minecraft:deepslate_tiles
setblock 486 237 276 minecraft:cobbled_deepslate
fill 486 237 277 486 240 277 minecraft:deepslate_tiles
setblock 486 237 316 minecraft:cobbled_deepslate
fill 487 237 276 487 240 276 minecraft:deepslate_tiles
setblock 487 237 315 minecraft:cobbled_deepslate
fill 487 237 316 490 237 316 minecraft:deepslate_tiles
fill 488 237 277 489 237 277 minecraft:deepslate_tiles
setblock 488 237 314 minecraft:cobbled_deepslate
fill 488 237 315 488 240 315 minecraft:deepslate_tiles
setblock 489 237 278 minecraft:light[level=13]
setblock 489 237 286 minecraft:light[level=13]
setblock 489 237 302 minecraft:light[level=13]
setblock 489 237 310 minecraft:light[level=13]
setblock 489 237 313 minecraft:cobbled_deepslate
fill 489 237 314 489 239 314 minecraft:deepslate_tiles
setblock 490 237 277 minecraft:cobbled_deepslate
setblock 491 237 276 minecraft:cobbled_deepslate
setblock 491 237 277 minecraft:deepslate_tiles
setblock 491 237 316 minecraft:cobbled_deepslate
fill 492 237 276 492 240 276 minecraft:deepslate_tiles
setblock 492 237 315 minecraft:cobbled_deepslate
fill 492 237 316 492 240 316 minecraft:deepslate_tiles
fill 493 237 315 493 238 315 minecraft:deepslate_tiles
setblock 496 237 316 minecraft:cobbled_deepslate
setblock 497 237 278 minecraft:light[level=13]
setblock 497 237 286 minecraft:light[level=13]
setblock 497 237 294 minecraft:light[level=13]
setblock 497 237 302 minecraft:light[level=13]
setblock 497 237 310 minecraft:light[level=13]
fill 497 237 316 500 237 316 minecraft:deepslate_tiles
setblock 500 237 276 minecraft:deepslate_tiles
setblock 501 237 276 minecraft:cobbled_deepslate
setblock 501 237 316 minecraft:cobbled_deepslate
fill 502 237 276 505 237 276 minecraft:deepslate_tiles
fill 502 237 316 505 237 316 minecraft:deepslate_tiles
fill 503 237 277 504 237 277 minecraft:deepslate_tiles
fill 504 237 315 506 237 315 minecraft:deepslate_tiles
setblock 505 237 277 minecraft:cobbled_deepslate
fill 505 237 278 508 237 278 minecraft:deepslate_tiles
setblock 505 237 286 minecraft:light[level=13]
setblock 505 237 294 minecraft:light[level=13]
setblock 505 237 302 minecraft:light[level=13]
setblock 505 237 310 minecraft:light[level=13]
fill 505 237 313 505 240 313 minecraft:cobbled_deepslate
setblock 506 237 276 minecraft:cobbled_deepslate
fill 506 237 277 509 237 277 minecraft:deepslate_tiles
fill 506 237 312 506 240 312 minecraft:cobbled_deepslate
fill 506 237 314 506 240 314 minecraft:cobbled_deepslate
setblock 506 237 316 minecraft:cobbled_deepslate
fill 507 237 276 507 240 276 minecraft:deepslate_tiles
fill 507 237 313 507 240 313 minecraft:cobbled_deepslate
setblock 507 237 314 minecraft:deepslate_tiles
setblock 507 237 315 minecraft:cobbled_deepslate
fill 507 237 316 507 240 316 minecraft:deepslate_tiles
setblock 508 237 289 minecraft:cobbled_deepslate
setblock 508 237 290 minecraft:deepslate_tiles
setblock 508 237 293 minecraft:deepslate_tiles
setblock 508 237 294 minecraft:cobbled_deepslate
fill 508 237 295 508 238 295 minecraft:deepslate_tiles
setblock 508 237 314 minecraft:cobbled_deepslate
fill 508 237 315 508 240 315 minecraft:deepslate_tiles
setblock 509 237 278 minecraft:cobbled_deepslate
fill 509 237 279 509 237 282 minecraft:deepslate_tiles
setblock 509 237 283 minecraft:cobbled_deepslate
setblock 509 237 284 minecraft:deepslate_tiles
setblock 509 237 288 minecraft:cobbled_deepslate
fill 509 237 289 509 238 289 minecraft:deepslate_tiles
setblock 509 237 293 minecraft:cobbled_deepslate
fill 509 237 294 509 240 294 minecraft:deepslate_tiles
setblock 509 237 298 minecraft:cobbled_deepslate
setblock 509 237 313 minecraft:cobbled_deepslate
fill 509 237 314 509 238 314 minecraft:deepslate_tiles
setblock 510 237 276 minecraft:deepslate_tiles
setblock 510 237 277 minecraft:cobbled_deepslate
fill 510 237 278 510 237 281 minecraft:deepslate_tiles
setblock 510 237 282 minecraft:cobbled_deepslate
fill 510 237 283 510 240 283 minecraft:deepslate_tiles
setblock 510 237 287 minecraft:cobbled_deepslate
fill 510 237 288 510 239 288 minecraft:deepslate_tiles
setblock 510 237 292 minecraft:cobbled_deepslate
fill 510 237 293 510 240 293 minecraft:deepslate_tiles
setblock 510 237 297 minecraft:cobbled_deepslate
fill 510 237 298 510 240 298 minecraft:deepslate_tiles
setblock 510 237 312 minecraft:cobbled_deepslate
fill 510 237 313 510 239 313 minecraft:deepslate_tiles
setblock 511 237 276 minecraft:cobbled_deepslate
fill 511 237 277 511 237 280 minecraft:deepslate_tiles
setblock 511 237 281 minecraft:cobbled_deepslate
fill 511 237 282 511 240 282 minecraft:deepslate_tiles
setblock 511 237 286 minecraft:cobbled_deepslate
fill 511 237 287 511 240 287 minecraft:deepslate_tiles
setblock 511 237 291 minecraft:cobbled_deepslate
fill 511 237 292 511 240 292 minecraft:deepslate_tiles
setblock 511 237 296 minecraft:cobbled_deepslate
fill 511 237 297 511 240 297 minecraft:deepslate_tiles
setblock 511 237 301 minecraft:cobbled_deepslate
fill 511 237 302 511 238 302 minecraft:deepslate_tiles
setblock 511 237 311 minecraft:cobbled_deepslate
fill 511 237 312 511 240 312 minecraft:deepslate_tiles
setblock 511 237 316 minecraft:cobbled_deepslate
fill 470 238 276 471 241 276 minecraft:deepslate_tiles
setblock 471 238 279 minecraft:deepslate_tiles
setblock 471 238 280 minecraft:cobbled_deepslate
fill 471 238 281 471 238 284 minecraft:deepslate_tiles
setblock 471 238 285 minecraft:cobbled_deepslate
setblock 471 238 286 minecraft:deepslate_tiles
setblock 471 238 290 minecraft:cobbled_deepslate
fill 471 238 291 471 239 291 minecraft:deepslate_tiles
setblock 471 238 295 minecraft:cobbled_deepslate
fill 471 238 296 471 241 296 minecraft:deepslate_tiles
setblock 471 238 300 minecraft:cobbled_deepslate
fill 471 238 301 471 238 303 minecraft:deepslate_tiles
fill 471 238 306 471 238 309 minecraft:deepslate_tiles
setblock 471 238 310 minecraft:cobbled_deepslate
fill 471 238 311 471 238 314 minecraft:deepslate_tiles
setblock 471 238 315 minecraft:cobbled_deepslate
fill 471 238 316 474 238 316 minecraft:deepslate_tiles
setblock 472 238 279 minecraft:cobbled_deepslate
setblock 472 238 280 minecraft:deepslate_tiles
setblock 472 238 294 minecraft:cobbled_deepslate
setblock 472 238 295 minecraft:deepslate_tiles
setblock 472 238 310 minecraft:deepslate_tiles
setblock 472 238 314 minecraft:cobbled_deepslate
fill 472 238 315 475 238 315 minecraft:deepslate_tiles
setblock 473 238 313 minecraft:cobbled_deepslate
setblock 473 238 314 minecraft:deepslate_tiles
setblock 474 238 277 minecraft:cobbled_deepslate
setblock 475 238 276 minecraft:cobbled_deepslate
setblock 475 238 277 minecraft:deepslate_tiles
setblock 475 238 316 minecraft:cobbled_deepslate
fill 476 238 276 479 238 276 minecraft:deepslate_tiles
setblock 476 238 315 minecraft:cobbled_deepslate
fill 476 238 316 479 238 316 minecraft:deepslate_tiles
fill 477 238 315 480 238 315 minecraft:deepslate_tiles
setblock 480 238 276 minecraft:cobbled_deepslate
setblock 480 238 316 minecraft:cobbled_deepslate
fill 481 238 276 484 238 276 minecraft:deepslate_tiles
setblock 481 238 314 minecraft:deepslate_tiles
setblock 481 238 315 minecraft:cobbled_deepslate
fill 481 238 316 484 238 316 minecraft:deepslate_tiles
setblock 482 238 314 minecraft:cobbled_deepslate
fill 482 238 315 485 238 315 minecraft:deepslate_tiles
fill 483 238 314 486 238 314 minecraft:deepslate_tiles
setblock 484 238 277 minecraft:cobbled_deepslate
setblock 485 238 276 minecraft:cobbled_deepslate
fill 485 238 277 485 241 277 minecraft:deepslate_tiles
setblock 485 238 316 minecraft:cobbled_deepslate
fill 486 238 276 486 241 276 minecraft:deepslate_tiles
setblock 486 238 315 minecraft:cobbled_deepslate
fill 486 238 316 489 238 316 minecraft:deepslate_tiles
setblock 487 238 314 minecraft:cobbled_deepslate
fill 487 238 315 487 241 315 minecraft:deepslate_tiles
setblock 488 238 277 minecraft:deepslate_tiles
fill 488 238 314 488 239 314 minecraft:deepslate_tiles
setblock 489 238 277 minecraft:cobbled_deepslate
setblock 490 238 276 minecraft:cobbled_deepslate
fill 490 238 277 490 239 277 minecraft:deepslate_tiles
setblock 490 238 316 minecraft:cobbled_deepslate
fill 491 238 276 491 241 276 minecraft:deepslate_tiles
setblock 491 238 315 minecraft:cobbled_deepslate
fill 491 238 316 491 241 316 minecraft:deepslate_tiles
fill 492 238 315 492 239 315 minecraft:deepslate_tiles
setblock 494 238 276 minecraft:deepslate_tiles
setblock 495 238 276 minecraft:cobbled_deepslate
setblock 495 238 316 minecraft:cobbled_deepslate
setblock 496 238 316 minecraft:deepslate_tiles
fill 497 238 275 498 238 275 minecraft:redstone_block
setblock 499 238 276 minecraft:deepslate_tiles
setblock 500 238 276 minecraft:cobbled_deepslate
setblock 500 238 316 minecraft:cobbled_deepslate
fill 501 238 276 504 238 276 minecraft:deepslate_tiles
fill 501 238 316 504 238 316 minecraft:deepslate_tiles
fill 502 238 277 503 238 277 minecraft:deepslate_tiles
setblock 504 238 277 minecraft:cobbled_deepslate
fill 504 238 315 505 238 315 minecraft:deepslate_tiles
setblock 505 238 276 minecraft:cobbled_deepslate
fill 505 238 277 507 238 278 minecraft:deepslate_tiles
setblock 505 238 316 minecraft:cobbled_deepslate
fill 506 238 276 506 241 276 minecraft:deepslate_tiles
setblock 506 238 315 minecraft:cobbled_deepslate
fill 506 238 316 506 241 316 minecraft:deepslate_tiles
fill 507 238 315 507 241 315 minecraft:deepslate_tiles
setblock 508 238 277 minecraft:deepslate_tiles
setblock 508 238 278 minecraft:cobbled_deepslate
setblock 508 238 293 minecraft:cobbled_deepslate
setblock 508 238 294 minecraft:deepslate_tiles
setblock 508 238 314 minecraft:deepslate_tiles
setblock 509 238 277 minecraft:cobbled_deepslate
fill 509 238 278 509 238 281 minecraft:deepslate_tiles
setblock 509 238 282 minecraft:cobbled_deepslate
setblock 509 238 283 minecraft:deepslate_tiles
setblock 509 238 287 minecraft:cobbled_deepslate
setblock 509 238 288 minecraft:deepslate_tiles
setblock 509 238 292 minecraft:cobbled_deepslate
fill 509 238 293 509 239 293 minecraft:deepslate_tiles
setblock 509 238 297 minecraft:cobbled_deepslate
setblock 509 238 298 minecraft:deepslate_tiles
setblock 510 238 276 minecraft:cobbled_deepslate
fill 510 238 277 510 238 280 minecraft:deepslate_tiles
setblock 510 238 281 minecraft:cobbled_deepslate
fill 510 238 282 510 241 282 minecraft:deepslate_tiles
setblock 510 238 286 minecraft:cobbled_deepslate
fill 510 238 287 510 239 287 minecraft:deepslate_tiles
setblock 510 238 291 minecraft:cobbled_deepslate
fill 510 238 292 510 240 292 minecraft:deepslate_tiles
setblock 510 238 296 minecraft:cobbled_deepslate
fill 510 238 297 510 241 297 minecraft:deepslate_tiles
setblock 510 238 312 minecraft:deepslate_tiles
setblock 510 238 316 minecraft:cobbled_deepslate
fill 511 238 276 511 238 279 minecraft:deepslate_tiles
setblock 511 238 280 minecraft:cobbled_deepslate
fill 511 238 281 511 241 281 minecraft:deepslate_tiles
setblock 511 238 285 minecraft:cobbled_deepslate
fill 511 238 286 511 240 286 minecraft:deepslate_tiles
setblock 511 238 290 minecraft:cobbled_deepslate
fill 511 238 291 511 241 291 minecraft:deepslate_tiles
setblock 511 238 295 minecraft:cobbled_deepslate
fill 511 238 296 511 241 296 minecraft:deepslate_tiles
setblock 511 238 300 minecraft:cobbled_deepslate
fill 511 238 301 511 240 301 minecraft:deepslate_tiles
setblock 511 238 310 minecraft:cobbled_deepslate
fill 511 238 311 511 239 311 minecraft:deepslate_tiles
setblock 511 238 315 minecraft:cobbled_deepslate
fill 511 238 316 511 241 316 minecraft:deepslate_tiles
fill 470 239 277 471 239 278 minecraft:deepslate_tiles
setblock 471 239 279 minecraft:cobbled_deepslate
fill 471 239 280 471 239 283 minecraft:deepslate_tiles
setblock 471 239 290 minecraft:deepslate_tiles
setblock 471 239 294 minecraft:cobbled_deepslate
fill 471 239 295 471 241 295 minecraft:deepslate_tiles
setblock 471 239 299 minecraft:cobbled_deepslate
fill 471 239 300 471 239 302 minecraft:deepslate_tiles
setblock 471 239 308 minecraft:deepslate_tiles
setblock 471 239 309 minecraft:cobbled_deepslate
fill 471 239 310 471 239 313 minecraft:deepslate_tiles
setblock 471 239 314 minecraft:cobbled_deepslate
fill 471 239 315 473 239 316 minecraft:deepslate_tiles
setblock 472 239 277 minecraft:deepslate_tiles
setblock 472 239 278 minecraft:cobbled_deepslate
fill 472 239 279 472 240 279 minecraft:deepslate_tiles
setblock 472 239 313 minecraft:cobbled_deepslate
fill 472 239 314 472 241 314 minecraft:deepslate_tiles
setblock 473 239 277 minecraft:cobbled_deepslate
setblock 474 239 276 minecraft:cobbled_deepslate
setblock 474 239 277 minecraft:deepslate_tiles
setblock 474 239 315 minecraft:deepslate_tiles
setblock 474 239 316 minecraft:cobbled_deepslate
fill 475 239 276 478 239 276 minecraft:deepslate_tiles
setblock 475 239 315 minecraft:cobbled_deepslate
fill 475 239 316 478 239 316 minecraft:deepslate_tiles
fill 476 239 315 479 239 315 minecraft:deepslate_tiles
setblock 479 239 276 minecraft:cobbled_deepslate
setblock 479 239 316 minecraft:cobbled_deepslate
fill 480 239 276 483 239 276 minecraft:deepslate_tiles
setblock 480 239 315 minecraft:cobbled_deepslate
fill 480 239 316 483 239 316 minecraft:deepslate_tiles
fill 481 239 315 484 239 315 minecraft:deepslate_tiles
fill 482 239 314 485 239 314 minecraft:deepslate_tiles
setblock 484 239 276 minecraft:cobbled_deepslate
fill 484 239 277 484 242 277 minecraft:deepslate_tiles
setblock 484 239 316 minecraft:cobbled_deepslate
fill 485 239 276 485 242 276 minecraft:deepslate_tiles
setblock 485 239 315 minecraft:cobbled_deepslate
fill 485 239 316 488 239 316 minecraft:deepslate_tiles
setblock 486 239 314 minecraft:cobbled_deepslate
fill 486 239 315 486 242 315 minecraft:deepslate_tiles
fill 487 239 314 487 240 314 minecraft:deepslate_tiles
setblock 488 239 277 minecraft:cobbled_deepslate
setblock 489 239 276 minecraft:cobbled_deepslate
fill 489 239 277 489 240 277 minecraft:deepslate_tiles
setblock 489 239 316 minecraft:cobbled_deepslate
fill 490 239 276 490 242 276 minecraft:deepslate_tiles
setblock 490 239 315 minecraft:cobbled_deepslate
fill 490 239 316 490 242 316 minecraft:deepslate_tiles
setblock 491 239 315 minecraft:deepslate_tiles
setblock 494 239 276 minecraft:cobbled_deepslate
setblock 494 239 316 minecraft:cobbled_deepslate
fill 497 239 275 498 257 275 minecraft:deepslate_tiles
setblock 499 239 276 minecraft:cobbled_deepslate
fill 500 239 276 503 239 276 minecraft:deepslate_tiles
fill 501 239 316 503 239 316 minecraft:deepslate_tiles
setblock 502 239 277 minecraft:deepslate_tiles
setblock 503 239 277 minecraft:cobbled_deepslate
setblock 504 239 276 minecraft:cobbled_deepslate
fill 504 239 277 506 239 278 minecraft:deepslate_tiles
setblock 504 239 315 minecraft:deepslate_tiles
setblock 504 239 316 minecraft:cobbled_deepslate
fill 505 239 276 505 242 276 minecraft:deepslate_tiles
fill 505 239 312 505 240 312 minecraft:cobbled_deepslate
fill 505 239 314 505 239 315 minecraft:cobbled_deepslate
fill 505 239 316 505 242 316 minecraft:deepslate_tiles
fill 506 239 315 506 241 315 minecraft:deepslate_tiles
setblock 507 239 277 minecraft:deepslate_tiles
setblock 507 239 278 minecraft:cobbled_deepslate
fill 507 239 312 507 240 312 minecraft:cobbled_deepslate
fill 507 239 314 507 240 314 minecraft:cobbled_deepslate
setblock 508 239 277 minecraft:cobbled_deepslate
fill 508 239 278 511 239 278 minecraft:deepslate_tiles
setblock 509 239 276 minecraft:cobbled_deepslate
fill 509 239 277 511 240 277 minecraft:deepslate_tiles
fill 509 239 279 509 239 280 minecraft:deepslate_tiles
setblock 509 239 281 minecraft:cobbled_deepslate
setblock 509 239 282 minecraft:deepslate_tiles
setblock 509 239 291 minecraft:cobbled_deepslate
setblock 509 239 292 minecraft:deepslate_tiles
setblock 509 239 296 minecraft:cobbled_deepslate
setblock 509 239 297 minecraft:deepslate_tiles
setblock 509 239 316 minecraft:cobbled_deepslate
fill 510 239 276 511 241 276 minecraft:deepslate_tiles
setblock 510 239 279 minecraft:deepslate_tiles
setblock 510 239 280 minecraft:cobbled_deepslate
fill 510 239 281 510 242 281 minecraft:deepslate_tiles
setblock 510 239 285 minecraft:cobbled_deepslate
setblock 510 239 286 minecraft:deepslate_tiles
setblock 510 239 290 minecraft:cobbled_deepslate
fill 510 239 291 510 240 291 minecraft:deepslate_tiles
setblock 510 239 295 minecraft:cobbled_deepslate
fill 510 239 296 510 241 296 minecraft:deepslate_tiles
setblock 510 239 315 minecraft:cobbled_deepslate
fill 510 239 316 510 242 316 minecraft:deepslate_tiles
setblock 511 239 279 minecraft:cobbled_deepslate
fill 511 239 280 511 242 280 minecraft:deepslate_tiles
setblock 511 239 284 minecraft:cobbled_deepslate
fill 511 239 285 511 241 285 minecraft:deepslate_tiles
setblock 511 239 289 minecraft:cobbled_deepslate
fill 511 239 290 511 240 290 minecraft:deepslate_tiles
setblock 511 239 294 minecraft:cobbled_deepslate
fill 511 239 295 511 242 295 minecraft:deepslate_tiles
setblock 511 239 299 minecraft:cobbled_deepslate
fill 511 239 300 511 241 300 minecraft:deepslate_tiles
setblock 511 239 314 minecraft:cobbled_deepslate
fill 511 239 315 511 242 315 minecraft:deepslate_tiles
fill 470 240 277 470 308 278 minecraft:deepslate_tiles
fill 470 240 311 471 241 311 minecraft:deepslate_tiles
setblock 470 240 312 minecraft:redstone_block
fill 470 240 313 470 255 316 minecraft:deepslate_tiles
setblock 471 240 277 minecraft:deepslate_tiles
setblock 471 240 278 minecraft:cobbled_deepslate
fill 471 240 279 471 240 282 minecraft:deepslate_tiles
setblock 471 240 293 minecraft:cobbled_deepslate
setblock 471 240 294 minecraft:deepslate_tiles
setblock 471 240 298 minecraft:cobbled_deepslate
fill 471 240 299 471 241 301 minecraft:deepslate_tiles
setblock 471 240 310 minecraft:deepslate_tiles
setblock 471 240 312 minecraft:deepslate_tiles
setblock 471 240 313 minecraft:cobbled_deepslate
fill 471 240 314 471 241 316 minecraft:deepslate_tiles
setblock 472 240 277 minecraft:cobbled_deepslate
fill 472 240 278 472 241 278 minecraft:deepslate_tiles
setblock 472 240 313 minecraft:deepslate_tiles
fill 472 240 315 472 240 316 minecraft:deepslate_tiles
setblock 473 240 276 minecraft:cobbled_deepslate
fill 473 240 277 473 241 277 minecraft:deepslate_tiles
setblock 473 240 315 minecraft:deepslate_tiles
setblock 473 240 316 minecraft:cobbled_deepslate
fill 474 240 276 477 240 276 minecraft:deepslate_tiles
setblock 474 240 315 minecraft:cobbled_deepslate
fill 474 240 316 477 240 316 minecraft:deepslate_tiles
fill 475 240 315 478 240 315 minecraft:deepslate_tiles
setblock 478 240 276 minecraft:cobbled_deepslate
setblock 478 240 316 minecraft:cobbled_deepslate
fill 479 240 276 482 240 276 minecraft:deepslate_tiles
setblock 479 240 315 minecraft:cobbled_deepslate
fill 479 240 316 482 240 316 minecraft:deepslate_tiles
fill 480 240 315 483 240 315 minecraft:deepslate_tiles
setblock 483 240 276 minecraft:cobbled_deepslate
fill 483 240 277 483 243 277 minecraft:deepslate_tiles
fill 483 240 314 484 240 314 minecraft:deepslate_tiles
setblock 483 240 316 minecraft:cobbled_deepslate
fill 484 240 276 484 243 276 minecraft:deepslate_tiles
setblock 484 240 315 minecraft:cobbled_deepslate
fill 484 240 316 487 240 316 minecraft:deepslate_tiles
setblock 485 240 314 minecraft:cobbled_deepslate
fill 485 240 315 485 243 315 minecraft:deepslate_tiles
setblock 486 240 314 minecraft:deepslate_tiles
setblock 487 240 277 minecraft:cobbled_deepslate
setblock 488 240 276 minecraft:cobbled_deepslate
fill 488 240 277 488 241 277 minecraft:deepslate_tiles
setblock 488 240 316 minecraft:cobbled_deepslate
fill 489 240 276 489 243 276 minecraft:deepslate_tiles
setblock 489 240 315 minecraft:cobbled_deepslate
fill 489 240 316 489 243 316 minecraft:deepslate_tiles
setblock 490 240 315 minecraft:deepslate_tiles
setblock 493 240 276 minecraft:cobbled_deepslate
setblock 493 240 316 minecraft:cobbled_deepslate
fill 499 240 276 502 240 276 minecraft:deepslate_tiles
setblock 501 240 277 minecraft:deepslate_tiles
fill 501 240 316 502 240 316 minecraft:deepslate_tiles
setblock 502 240 277 minecraft:cobbled_deepslate
setblock 503 240 276 minecraft:cobbled_deepslate
fill 503 240 277 506 240 277 minecraft:deepslate_tiles
setblock 503 240 316 minecraft:cobbled_deepslate
fill 504 240 276 504 243 276 minecraft:deepslate_tiles
fill 504 240 278 505 240 278 minecraft:deepslate_tiles
fill 504 240 316 504 243 316 minecraft:deepslate_tiles
setblock 505 240 314 minecraft:cobbled_deepslate
fill 505 240 315 505 241 315 minecraft:deepslate_tiles
setblock 506 240 278 minecraft:cobbled_deepslate
setblock 507 240 277 minecraft:cobbled_deepslate
fill 507 240 278 510 240 278 minecraft:deepslate_tiles
setblock 508 240 276 minecraft:cobbled_deepslate
fill 508 240 277 508 243 277 minecraft:deepslate_tiles
setblock 508 240 316 minecraft:cobbled_deepslate
fill 509 240 276 509 243 276 minecraft:deepslate_tiles
setblock 509 240 279 minecraft:deepslate_tiles
setblock 509 240 280 minecraft:cobbled_deepslate
fill 509 240 281 509 242 281 minecraft:deepslate_tiles
setblock 509 240 295 minecraft:cobbled_deepslate
setblock 509 240 296 minecraft:deepslate_tiles
setblock 509 240 315 minecraft:cobbled_deepslate
fill 509 240 316 509 243 316 minecraft:deepslate_tiles
setblock 510 240 279 minecraft:cobbled_deepslate
fill 510 240 280 510 243 280 minecraft:deepslate_tiles
setblock 510 240 284 minecraft:cobbled_deepslate
setblock 510 240 290 minecraft:deepslate_tiles
setblock 510 240 294 minecraft:cobbled_deepslate
fill 510 240 295 510 241 295 minecraft:deepslate_tiles
setblock 510 240 299 minecraft:cobbled_deepslate
setblock 510 240 314 minecraft:cobbled_deepslate
fill 510 240 315 510 241 315 minecraft:deepslate_tiles
setblock 511 240 278 minecraft:cobbled_deepslate
fill 511 240 279 511 243 279 minecraft:deepslate_tiles
setblock 511 240 283 minecraft:cobbled_deepslate
fill 511 240 284 511 242 284 minecraft:deepslate_tiles
setblock 511 240 288 minecraft:cobbled_deepslate
setblock 511 240 289 minecraft:deepslate_tiles
setblock 511 240 293 minecraft:cobbled_deepslate
fill 511 240 294 511 241 294 minecraft:deepslate_tiles
setblock 511 240 298 minecraft:cobbled_deepslate
fill 511 240 299 511 242 299 minecraft:deepslate_tiles
setblock 511 240 313 minecraft:cobbled_deepslate
fill 511 240 314 511 242 314 minecraft:deepslate_tiles
fill 470 241 312 470 308 312 minecraft:deepslate_tiles
setblock 471 241 277 minecraft:cobbled_deepslate
fill 471 241 278 471 241 281 minecraft:deepslate_tiles
setblock 471 241 297 minecraft:cobbled_deepslate
fill 471 241 298 471 242 298 minecraft:deepslate_tiles
setblock 471 241 312 minecraft:cobbled_deepslate
fill 471 241 313 471 243 313 minecraft:deepslate_tiles
setblock 472 241 276 minecraft:cobbled_deepslate
fill 472 241 277 472 242 277 minecraft:deepslate_tiles
setblock 472 241 315 minecraft:deepslate_tiles
setblock 472 241 316 minecraft:cobbled_deepslate
fill 473 241 276 476 241 276 minecraft:deepslate_tiles
setblock 473 241 278 minecraft:light[level=12]
setblock 473 241 285 minecraft:light[level=12]
setblock 473 241 292 minecraft:light[level=12]
setblock 473 241 299 minecraft:light[level=12]
setblock 473 241 306 minecraft:light[level=12]
setblock 473 241 313 minecraft:light[level=12]
setblock 473 241 315 minecraft:cobbled_deepslate
fill 473 241 316 476 241 316 minecraft:deepslate_tiles
fill 474 241 299 475 242 300 minecraft:white_wool
setblock 477 241 276 minecraft:cobbled_deepslate
setblock 477 241 316 minecraft:cobbled_deepslate
fill 478 241 276 481 241 276 minecraft:deepslate_tiles
fill 478 241 316 481 241 316 minecraft:deepslate_tiles
setblock 480 241 278 minecraft:light[level=12]
setblock 480 241 285 minecraft:light[level=12]
setblock 480 241 292 minecraft:light[level=12]
setblock 480 241 299 minecraft:light[level=12]
setblock 480 241 306 minecraft:light[level=12]
setblock 480 241 313 minecraft:light[level=12]
fill 480 241 315 482 241 315 minecraft:deepslate_tiles
setblock 482 241 276 minecraft:cobbled_deepslate
setblock 482 241 316 minecraft:cobbled_deepslate
fill 483 241 276 483 244 276 minecraft:deepslate_tiles
setblock 483 241 315 minecraft:cobbled_deepslate
fill 483 241 316 486 241 316 minecraft:deepslate_tiles
fill 484 241 315 484 244 315 minecraft:deepslate_tiles
setblock 486 241 277 minecraft:cobbled_deepslate
setblock 487 241 276 minecraft:cobbled_deepslate
fill 487 241 277 487 242 277 minecraft:deepslate_tiles
setblock 487 241 278 minecraft:light[level=12]
setblock 487 241 285 minecraft:light[level=12]
setblock 487 241 292 minecraft:light[level=12]
setblock 487 241 299 minecraft:light[level=12]
setblock 487 241 306 minecraft:light[level=12]
setblock 487 241 313 minecraft:light[level=12]
setblock 487 241 316 minecraft:cobbled_deepslate
fill 488 241 276 488 244 276 minecraft:deepslate_tiles
setblock 488 241 315 minecraft:cobbled_deepslate
fill 488 241 316 488 244 316 minecraft:deepslate_tiles
setblock 489 241 315 minecraft:deepslate_tiles
setblock 492 241 276 minecraft:cobbled_deepslate
setblock 494 241 278 minecraft:light[level=12]
setblock 494 241 285 minecraft:light[level=12]
setblock 494 241 292 minecraft:light[level=12]
setblock 494 241 299 minecraft:light[level=12]
setblock 494 241 306 minecraft:light[level=12]
setblock 494 241 313 minecraft:light[level=12]
fill 499 241 276 501 241 276 minecraft:deepslate_tiles
setblock 501 241 277 minecraft:cobbled_deepslate
fill 501 241 278 502 242 282 minecraft:black_concrete
setblock 501 241 285 minecraft:light[level=12]
setblock 501 241 292 minecraft:light[level=12]
setblock 501 241 299 minecraft:light[level=12]
setblock 501 241 306 minecraft:light[level=12]
setblock 501 241 313 minecraft:light[level=12]
setblock 502 241 276 minecraft:cobbled_deepslate
fill 502 241 277 505 241 277 minecraft:deepslate_tiles
setblock 502 241 316 minecraft:cobbled_deepslate
fill 503 241 276 503 244 276 minecraft:deepslate_tiles
fill 503 241 278 504 241 278 minecraft:deepslate_tiles
fill 503 241 279 505 242 282 minecraft:black_concrete
fill 503 241 316 503 244 316 minecraft:deepslate_tiles
setblock 505 241 278 minecraft:cobbled_deepslate
setblock 506 241 277 minecraft:cobbled_deepslate
fill 506 241 278 509 241 278 minecraft:deepslate_tiles
setblock 507 241 276 minecraft:cobbled_deepslate
fill 507 241 277 507 244 277 minecraft:deepslate_tiles
setblock 507 241 316 minecraft:cobbled_deepslate
fill 508 241 276 508 244 276 minecraft:deepslate_tiles
setblock 508 241 285 minecraft:light[level=12]
setblock 508 241 292 minecraft:light[level=12]
setblock 508 241 299 minecraft:light[level=12]
setblock 508 241 306 minecraft:light[level=12]
setblock 508 241 313 minecraft:light[level=12]
setblock 508 241 315 minecraft:cobbled_deepslate
fill 508 241 316 508 244 316 minecraft:deepslate_tiles
fill 509 241 277 510 241 277 minecraft:deepslate_tiles
setblock 509 241 279 minecraft:cobbled_deepslate
fill 509 241 280 509 244 280 minecraft:deepslate_tiles
setblock 509 241 315 minecraft:deepslate_tiles
setblock 510 241 278 minecraft:cobbled_deepslate
fill 510 241 279 510 244 279 minecraft:deepslate_tiles
setblock 510 241 283 minecraft:cobbled_deepslate
setblock 510 241 294 minecraft:deepslate_tiles
setblock 511 241 277 minecraft:cobbled_deepslate
fill 511 241 278 511 244 278 minecraft:deepslate_tiles
setblock 511 241 282 minecraft:cobbled_deepslate
fill 511 241 283 511 244 283 minecraft:deepslate_tiles
setblock 511 241 292 minecraft:cobbled_deepslate
setblock 511 241 293 minecraft:deepslate_tiles
setblock 511 241 297 minecraft:cobbled_deepslate
fill 511 241 298 511 242 298 minecraft:deepslate_tiles
setblock 511 241 313 minecraft:deepslate_tiles
fill 470 242 276 470 308 276 minecraft:deepslate_tiles
fill 470 242 311 470 308 311 minecraft:deepslate_tiles
setblock 471 242 276 minecraft:cobbled_deepslate
fill 471 242 277 471 242 280 minecraft:deepslate_tiles
setblock 471 242 281 minecraft:cobbled_deepslate
fill 471 242 299 471 242 300 minecraft:deepslate_tiles
setblock 471 242 312 minecraft:deepslate_tiles
fill 471 242 314 471 242 315 minecraft:deepslate_tiles
setblock 471 242 316 minecraft:cobbled_deepslate
fill 472 242 276 475 242 276 minecraft:deepslate_tiles
fill 472 242 316 475 242 316 minecraft:deepslate_tiles
fill 473 242 284 473 249 284 minecraft:black_concrete
setblock 476 242 276 minecraft:cobbled_deepslate
setblock 476 242 316 minecraft:cobbled_deepslate
fill 477 242 276 480 242 276 minecraft:deepslate_tiles
fill 477 242 316 480 242 316 minecraft:deepslate_tiles
setblock 481 242 276 minecraft:cobbled_deepslate
setblock 481 242 315 minecraft:deepslate_tiles
setblock 481 242 316 minecraft:cobbled_deepslate
fill 482 242 276 482 245 276 minecraft:deepslate_tiles
setblock 482 242 315 minecraft:cobbled_deepslate
fill 482 242 316 485 242 316 minecraft:deepslate_tiles
fill 483 242 315 483 244 315 minecraft:deepslate_tiles
setblock 485 242 277 minecraft:cobbled_deepslate
setblock 486 242 276 minecraft:cobbled_deepslate
fill 486 242 277 486 245 277 minecraft:deepslate_tiles
setblock 486 242 316 minecraft:cobbled_deepslate
fill 487 242 276 487 245 276 minecraft:deepslate_tiles
setblock 487 242 315 minecraft:cobbled_deepslate
fill 487 242 316 487 245 316 minecraft:deepslate_tiles
setblock 491 242 276 minecraft:cobbled_deepslate
fill 498 242 276 500 242 276 minecraft:deepslate_tiles
setblock 500 242 277 minecraft:cobbled_deepslate
setblock 501 242 276 minecraft:cobbled_deepslate
fill 501 242 277 504 242 277 minecraft:deepslate_tiles
fill 502 242 276 502 245 276 minecraft:deepslate_tiles
fill 502 242 316 502 245 316 minecraft:deepslate_tiles
setblock 503 242 278 minecraft:deepslate_tiles
setblock 504 242 278 minecraft:cobbled_deepslate
setblock 505 242 277 minecraft:cobbled_deepslate
fill 505 242 278 508 242 278 minecraft:deepslate_tiles
setblock 506 242 276 minecraft:cobbled_deepslate
fill 506 242 277 506 245 277 minecraft:deepslate_tiles
setblock 506 242 316 minecraft:cobbled_deepslate
fill 507 242 276 507 245 276 minecraft:deepslate_tiles
setblock 507 242 315 minecraft:cobbled_deepslate
fill 507 242 316 507 245 316 minecraft:deepslate_tiles
setblock 508 242 315 minecraft:deepslate_tiles
setblock 509 242 277 minecraft:deepslate_tiles
setblock 509 242 278 minecraft:cobbled_deepslate
fill 509 242 279 509 245 279 minecraft:deepslate_tiles
setblock 510 242 276 minecraft:deepslate_tiles
setblock 510 242 277 minecraft:cobbled_deepslate
fill 510 242 278 510 245 278 minecraft:deepslate_tiles
setblock 510 242 282 minecraft:cobbled_deepslate
setblock 511 242 276 minecraft:cobbled_deepslate
fill 511 242 277 511 245 277 minecraft:deepslate_tiles
setblock 511 242 281 minecraft:cobbled_deepslate
fill 511 242 282 511 245 282 minecraft:deepslate_tiles
setblock 511 242 296 minecraft:cobbled_deepslate
setblock 511 242 297 minecraft:deepslate_tiles
setblock 511 242 316 minecraft:cobbled_deepslate
fill 471 243 276 471 243 279 minecraft:deepslate_tiles
setblock 471 243 280 minecraft:cobbled_deepslate
setblock 471 243 281 minecraft:deepslate_tiles
setblock 471 243 299 minecraft:deepslate_tiles
setblock 471 243 300 minecraft:cobbled_deepslate
setblock 471 243 314 minecraft:deepslate_tiles
setblock 471 243 315 minecraft:cobbled_deepslate
fill 471 243 316 474 243 316 minecraft:deepslate_tiles
fill 472 243 276 474 243 276 minecraft:deepslate_tiles
setblock 475 243 276 minecraft:cobbled_deepslate
setblock 475 243 316 minecraft:cobbled_deepslate
fill 476 243 276 479 243 276 minecraft:deepslate_tiles
fill 476 243 316 479 243 316 minecraft:deepslate_tiles
setblock 480 243 276 minecraft:cobbled_deepslate
setblock 480 243 316 minecraft:cobbled_deepslate
fill 481 243 276 481 246 276 minecraft:deepslate_tiles
fill 481 243 316 484 243 316 minecraft:deepslate_tiles
setblock 482 243 315 minecraft:deepslate_tiles
setblock 484 243 277 minecraft:cobbled_deepslate
setblock 485 243 276 minecraft:cobbled_deepslate
fill 485 243 277 485 246 277 minecraft:deepslate_tiles
setblock 485 243 316 minecraft:cobbled_deepslate
fill 486 243 276 486 246 276 minecraft:deepslate_tiles
fill 486 243 316 486 246 316 minecraft:deepslate_tiles
setblock 490 243 276 minecraft:cobbled_deepslate
fill 498 243 276 499 243 276 minecraft:deepslate_tiles
setblock 500 243 276 minecraft:cobbled_deepslate
fill 500 243 277 503 243 277 minecraft:deepslate_tiles
fill 501 243 276 501 246 276 minecraft:deepslate_tiles
setblock 502 243 278 minecraft:deepslate_tiles
setblock 503 243 278 minecraft:cobbled_deepslate
fill 503 243 280 503 247 280 minecraft:bone_block
setblock 504 243 277 minecraft:cobbled_deepslate
fill 504 243 278 507 243 278 minecraft:deepslate_tiles
setblock 505 243 276 minecraft:cobbled_deepslate
fill 505 243 277 505 246 277 minecraft:deepslate_tiles
fill 505 243 279 506 243 279 minecraft:deepslate_tiles
setblock 505 243 316 minecraft:cobbled_deepslate
fill 506 243 276 506 246 276 minecraft:deepslate_tiles
fill 506 243 316 506 246 316 minecraft:deepslate_tiles
setblock 508 243 278 minecraft:cobbled_deepslate
setblock 509 243 277 minecraft:cobbled_deepslate
fill 509 243 278 509 246 278 minecraft:deepslate_tiles
setblock 510 243 276 minecraft:cobbled_deepslate
fill 510 243 277 510 246 277 minecraft:deepslate_tiles
setblock 510 243 281 minecraft:cobbled_deepslate
fill 510 243 282 510 246 282 minecraft:deepslate_tiles
setblock 510 243 316 minecraft:cobbled_deepslate
fill 511 243 276 511 246 276 minecraft:deepslate_tiles
setblock 511 243 280 minecraft:cobbled_deepslate
fill 511 243 281 511 246 281 minecraft:deepslate_tiles
setblock 511 243 315 minecraft:cobbled_deepslate
fill 511 243 316 511 246 316 minecraft:deepslate_tiles
fill 471 244 276 471 244 278 minecraft:deepslate_tiles
setblock 471 244 279 minecraft:cobbled_deepslate
fill 471 244 280 471 247 280 minecraft:deepslate_tiles
fill 471 244 300 471 245 302 minecraft:deepslate_tiles
setblock 471 244 314 minecraft:cobbled_deepslate
fill 471 244 315 471 246 316 minecraft:deepslate_tiles
fill 472 244 276 473 244 276 minecraft:deepslate_tiles
fill 472 244 316 473 244 316 minecraft:deepslate_tiles
setblock 474 244 276 minecraft:cobbled_deepslate
setblock 474 244 316 minecraft:cobbled_deepslate
fill 475 244 316 478 244 316 minecraft:deepslate_tiles
fill 477 244 276 478 244 276 minecraft:deepslate_tiles
setblock 479 244 276 minecraft:cobbled_deepslate
setblock 479 244 316 minecraft:cobbled_deepslate
fill 480 244 276 480 247 276 minecraft:deepslate_tiles
fill 480 244 316 483 244 316 minecraft:deepslate_tiles
setblock 483 244 277 minecraft:cobbled_deepslate
setblock 484 244 275 minecraft:white_wool
setblock 484 244 276 minecraft:cobbled_deepslate
fill 484 244 277 484 247 277 minecraft:deepslate_tiles
setblock 484 244 316 minecraft:cobbled_deepslate
fill 485 244 276 485 247 276 minecraft:deepslate_tiles
fill 485 244 316 485 247 316 minecraft:deepslate_tiles
setblock 489 244 276 minecraft:cobbled_deepslate
setblock 498 244 276 minecraft:deepslate_tiles
setblock 499 244 276 minecraft:cobbled_deepslate
fill 499 244 277 502 244 277 minecraft:deepslate_tiles
fill 500 244 276 500 247 276 minecraft:deepslate_tiles
setblock 501 244 278 minecraft:deepslate_tiles
fill 501 244 279 502 244 281 minecraft:bone_block
fill 501 244 282 501 245 282 minecraft:white_wool
setblock 502 244 278 minecraft:cobbled_deepslate
fill 502 244 282 504 247 282 minecraft:bone_block
setblock 503 244 277 minecraft:cobbled_deepslate
fill 503 244 278 506 244 278 minecraft:deepslate_tiles
setblock 503 244 279 minecraft:bone_block
fill 503 244 281 505 247 281 minecraft:bone_block
setblock 504 244 276 minecraft:cobbled_deepslate
fill 504 244 277 504 247 277 minecraft:deepslate_tiles
fill 504 244 279 505 244 279 minecraft:deepslate_tiles
fill 504 244 280 505 247 280 minecraft:bone_block
setblock 504 244 316 minecraft:cobbled_deepslate
fill 505 244 276 505 247 276 minecraft:deepslate_tiles
fill 505 244 316 505 247 316 minecraft:deepslate_tiles
setblock 506 244 279 minecraft:cobbled_deepslate
setblock 507 244 278 minecraft:cobbled_deepslate
fill 507 244 279 507 247 279 minecraft:deepslate_tiles
setblock 508 244 277 minecraft:cobbled_deepslate
fill 508 244 278 508 247 278 minecraft:deepslate_tiles
setblock 509 244 276 minecraft:cobbled_deepslate
fill 509 244 277 509 247 277 minecraft:deepslate_tiles
setblock 509 244 281 minecraft:cobbled_deepslate
setblock 509 244 316 minecraft:cobbled_deepslate
fill 510 244 276 510 247 276 minecraft:deepslate_tiles
setblock 510 244 280 minecraft:cobbled_deepslate
fill 510 244 281 510 247 281 minecraft:deepslate_tiles
fill 510 244 316 510 247 316 minecraft:deepslate_tiles
setblock 511 244 279 minecraft:cobbled_deepslate
fill 511 244 280 511 247 280 minecraft:deepslate_tiles
fill 471 245 276 471 245 277 minecraft:deepslate_tiles
setblock 471 245 278 minecraft:cobbled_deepslate
fill 471 245 279 471 248 279 minecraft:deepslate_tiles
fill 471 245 281 471 246 281 minecraft:deepslate_tiles
setblock 471 245 303 minecraft:cobbled_deepslate
fill 471 245 304 471 248 304 minecraft:deepslate_tiles
setblock 472 245 276 minecraft:deepslate_tiles
setblock 472 245 316 minecraft:deepslate_tiles
setblock 473 245 276 minecraft:cobbled_deepslate
setblock 473 245 278 minecraft:light[level=13]
setblock 473 245 286 minecraft:light[level=13]
setblock 473 245 294 minecraft:light[level=13]
setblock 473 245 302 minecraft:light[level=13]
setblock 473 245 310 minecraft:light[level=13]
setblock 473 245 316 minecraft:cobbled_deepslate
fill 474 245 316 477 245 316 minecraft:deepslate_tiles
setblock 477 245 276 minecraft:deepslate_tiles
setblock 478 245 276 minecraft:cobbled_deepslate
setblock 478 245 316 minecraft:cobbled_deepslate
fill 479 245 276 479 248 276 minecraft:deepslate_tiles
fill 479 245 316 482 245 316 minecraft:deepslate_tiles
setblock 481 245 278 minecraft:light[level=13]
setblock 481 245 286 minecraft:light[level=13]
setblock 481 245 294 minecraft:light[level=13]
setblock 481 245 302 minecraft:light[level=13]
setblock 481 245 310 minecraft:light[level=13]
setblock 482 245 277 minecraft:cobbled_deepslate
setblock 483 245 276 minecraft:cobbled_deepslate
fill 483 245 277 483 248 277 minecraft:deepslate_tiles
setblock 483 245 316 minecraft:cobbled_deepslate
fill 484 245 275 484 248 276 minecraft:deepslate_tiles
fill 484 245 316 484 248 316 minecraft:deepslate_tiles
fill 487 245 317 492 245 317 minecraft:deepslate_tiles
setblock 488 245 276 minecraft:cobbled_deepslate
setblock 489 245 276 minecraft:deepslate_tiles
setblock 489 245 278 minecraft:light[level=13]
setblock 489 245 286 minecraft:light[level=13]
setblock 489 245 302 minecraft:light[level=13]
setblock 489 245 310 minecraft:light[level=13]
setblock 493 245 317 minecraft:redstone_block
setblock 497 245 276 minecraft:deepslate_tiles
setblock 497 245 278 minecraft:light[level=13]
setblock 497 245 286 minecraft:light[level=13]
setblock 497 245 294 minecraft:light[level=13]
setblock 497 245 302 minecraft:light[level=13]
setblock 497 245 310 minecraft:light[level=13]
setblock 498 245 276 minecraft:cobbled_deepslate
fill 499 245 276 499 247 277 minecraft:deepslate_tiles
fill 500 245 277 500 245 278 minecraft:deepslate_tiles
setblock 501 245 277 minecraft:deepslate_tiles
setblock 501 245 278 minecraft:cobbled_deepslate
fill 501 245 279 501 245 281 minecraft:bone_block
setblock 502 245 277 minecraft:cobbled_deepslate
fill 502 245 278 504 245 279 minecraft:deepslate_tiles
fill 502 245 280 502 247 281 minecraft:bone_block
setblock 503 245 276 minecraft:cobbled_deepslate
fill 503 245 277 503 248 277 minecraft:deepslate_tiles
setblock 503 245 316 minecraft:cobbled_deepslate
fill 504 245 276 504 248 276 minecraft:deepslate_tiles
fill 504 245 316 504 248 316 minecraft:deepslate_tiles
setblock 505 245 278 minecraft:deepslate_tiles
setblock 505 245 279 minecraft:cobbled_deepslate
setblock 505 245 286 minecraft:light[level=13]
setblock 505 245 294 minecraft:light[level=13]
setblock 505 245 302 minecraft:light[level=13]
setblock 505 245 310 minecraft:light[level=13]
setblock 506 245 278 minecraft:cobbled_deepslate
fill 506 245 279 506 248 279 minecraft:deepslate_tiles
setblock 507 245 277 minecraft:cobbled_deepslate
fill 507 245 278 507 248 278 minecraft:deepslate_tiles
setblock 508 245 276 minecraft:cobbled_deepslate
fill 508 245 277 508 248 277 minecraft:deepslate_tiles
setblock 508 245 316 minecraft:cobbled_deepslate
fill 509 245 276 509 248 276 minecraft:deepslate_tiles
setblock 509 245 280 minecraft:cobbled_deepslate
fill 509 245 281 509 248 281 minecraft:deepslate_tiles
fill 509 245 316 509 248 316 minecraft:deepslate_tiles
setblock 510 245 279 minecraft:cobbled_deepslate
fill 510 245 280 510 248 280 minecraft:deepslate_tiles
setblock 511 245 278 minecraft:cobbled_deepslate
fill 511 245 279 511 248 279 minecraft:deepslate_tiles
setblock 511 245 283 minecraft:cobbled_deepslate
fill 511 245 284 511 248 284 minecraft:deepslate_tiles
fill 512 245 308 512 308 310 minecraft:deepslate_tiles
setblock 512 245 311 minecraft:white_wool
setblock 471 246 276 minecraft:deepslate_tiles
setblock 471 246 277 minecraft:cobbled_deepslate
fill 471 246 278 471 249 278 minecraft:deepslate_tiles
fill 471 246 299 471 246 301 minecraft:deepslate_tiles
setblock 471 246 302 minecraft:cobbled_deepslate
fill 471 246 303 471 249 303 minecraft:deepslate_tiles
fill 471 246 305 471 246 306 minecraft:deepslate_tiles
setblock 472 246 276 minecraft:cobbled_deepslate
fill 472 246 284 472 249 284 minecraft:black_concrete
setblock 472 246 316 minecraft:cobbled_deepslate
fill 473 246 276 473 247 276 minecraft:deepslate_tiles
fill 473 246 283 473 249 283 minecraft:black_concrete
fill 473 246 285 473 249 285 minecraft:black_concrete
fill 474 246 284 474 249 284 minecraft:black_concrete
fill 474 246 302 474 254 302 minecraft:black_concrete
fill 475 246 316 476 246 316 minecraft:deepslate_tiles
setblock 476 246 276 minecraft:deepslate_tiles
setblock 477 246 276 minecraft:cobbled_deepslate
setblock 477 246 316 minecraft:cobbled_deepslate
fill 478 246 276 478 249 276 minecraft:deepslate_tiles
fill 478 246 316 481 246 316 minecraft:deepslate_tiles
setblock 481 246 277 minecraft:cobbled_deepslate
setblock 482 246 276 minecraft:cobbled_deepslate
fill 482 246 277 482 249 277 minecraft:deepslate_tiles
setblock 482 246 316 minecraft:cobbled_deepslate
fill 483 246 276 483 249 276 minecraft:deepslate_tiles
fill 483 246 316 483 249 316 minecraft:deepslate_tiles
setblock 487 246 276 minecraft:cobbled_deepslate
fill 487 246 317 489 271 317 minecraft:deepslate_tiles
fill 488 246 276 488 247 276 minecraft:deepslate_tiles
setblock 490 246 317 minecraft:redstone_block
fill 491 246 317 493 248 317 minecraft:deepslate_tiles
setblock 496 246 276 minecraft:deepslate_tiles
setblock 497 246 276 minecraft:cobbled_deepslate
fill 498 246 276 498 248 277 minecraft:deepslate_tiles
setblock 499 246 278 minecraft:deepslate_tiles
setblock 500 246 277 minecraft:deepslate_tiles
setblock 500 246 278 minecraft:cobbled_deepslate
setblock 501 246 277 minecraft:cobbled_deepslate
fill 501 246 278 503 246 279 minecraft:deepslate_tiles
fill 501 246 280 501 247 281 minecraft:bone_block
setblock 501 246 316 minecraft:deepslate_tiles
setblock 502 246 276 minecraft:cobbled_deepslate
fill 502 246 277 502 249 277 minecraft:deepslate_tiles
setblock 502 246 316 minecraft:cobbled_deepslate
fill 503 246 276 503 249 276 minecraft:deepslate_tiles
fill 503 246 316 503 249 316 minecraft:deepslate_tiles
setblock 504 246 278 minecraft:deepslate_tiles
setblock 504 246 279 minecraft:cobbled_deepslate
setblock 505 246 278 minecraft:cobbled_deepslate
fill 505 246 279 505 249 279 minecraft:deepslate_tiles
setblock 506 246 277 minecraft:cobbled_deepslate
fill 506 246 278 506 249 278 minecraft:deepslate_tiles
fill 506 246 283 506 254 283 minecraft:cobbled_deepslate
setblock 507 246 276 minecraft:cobbled_deepslate
fill 507 246 277 507 249 277 minecraft:deepslate_tiles
setblock 507 246 316 minecraft:cobbled_deepslate
fill 508 246 276 508 249 276 minecraft:deepslate_tiles
fill 508 246 316 508 249 316 minecraft:deepslate_tiles
setblock 509 246 279 minecraft:cobbled_deepslate
fill 509 246 280 509 249 280 minecraft:deepslate_tiles
setblock 510 246 278 minecraft:cobbled_deepslate
fill 510 246 279 510 249 279 minecraft:deepslate_tiles
setblock 510 246 283 minecraft:cobbled_deepslate
setblock 511 246 277 minecraft:cobbled_deepslate
fill 511 246 278 511 249 278 minecraft:deepslate_tiles
setblock 511 246 282 minecraft:cobbled_deepslate
fill 511 246 283 511 249 283 minecraft:deepslate_tiles
setblock 512 246 278 minecraft:redstone_block
fill 512 246 311 512 308 311 minecraft:deepslate_tiles
fill 470 247 295 470 308 296 minecraft:deepslate_tiles
setblock 470 247 297 minecraft:white_wool
fill 470 247 298 470 308 300 minecraft:deepslate_tiles
fill 470 247 304 470 269 305 minecraft:deepslate_tiles
setblock 470 247 306 minecraft:white_wool
fill 470 247 307 471 250 307 minecraft:deepslate_tiles
setblock 471 247 276 minecraft:cobbled_deepslate
fill 471 247 277 471 249 277 minecraft:deepslate_tiles
setblock 471 247 281 minecraft:cobbled_deepslate
fill 471 247 282 471 250 282 minecraft:deepslate_tiles
fill 471 247 299 471 247 300 minecraft:deepslate_tiles
setblock 471 247 301 minecraft:cobbled_deepslate
fill 471 247 302 471 250 302 minecraft:deepslate_tiles
setblock 471 247 305 minecraft:deepslate_tiles
setblock 471 247 306 minecraft:cobbled_deepslate
fill 471 247 308 471 249 308 minecraft:deepslate_tiles
setblock 471 247 315 minecraft:deepslate_tiles
setblock 471 247 316 minecraft:cobbled_deepslate
fill 472 247 276 472 248 276 minecraft:deepslate_tiles
fill 472 247 283 472 249 283 minecraft:black_concrete
fill 472 247 285 472 249 285 minecraft:black_concrete
fill 472 247 316 472 249 316 minecraft:deepslate_tiles
setblock 473 247 278 minecraft:light[level=12]
setblock 473 247 292 minecraft:light[level=12]
setblock 473 247 299 minecraft:light[level=12]
setblock 473 247 306 minecraft:light[level=12]
setblock 473 247 313 minecraft:light[level=12]
fill 474 247 283 474 249 283 minecraft:black_concrete
fill 474 247 285 474 249 285 minecraft:black_concrete
setblock 475 247 316 minecraft:deepslate_tiles
setblock 476 247 276 minecraft:cobbled_deepslate
setblock 476 247 316 minecraft:cobbled_deepslate
fill 477 247 276 477 250 276 minecraft:deepslate_tiles
fill 477 247 316 480 247 316 minecraft:deepslate_tiles
setblock 480 247 277 minecraft:cobbled_deepslate
setblock 480 247 278 minecraft:light[level=12]
setblock 480 247 285 minecraft:light[level=12]
setblock 480 247 292 minecraft:light[level=12]
setblock 480 247 299 minecraft:light[level=12]
setblock 480 247 306 minecraft:light[level=12]
setblock 480 247 313 minecraft:light[level=12]
setblock 481 247 276 minecraft:cobbled_deepslate
fill 481 247 277 481 250 277 minecraft:deepslate_tiles
setblock 481 247 316 minecraft:cobbled_deepslate
fill 482 247 276 482 250 276 minecraft:deepslate_tiles
fill 482 247 316 482 250 316 minecraft:deepslate_tiles
setblock 485 247 277 minecraft:cobbled_deepslate
setblock 486 247 276 minecraft:cobbled_deepslate
setblock 486 247 316 minecraft:cobbled_deepslate
fill 487 247 276 487 249 276 minecraft:deepslate_tiles
setblock 487 247 278 minecraft:light[level=12]
setblock 487 247 285 minecraft:light[level=12]
setblock 487 247 292 minecraft:light[level=12]
setblock 487 247 299 minecraft:light[level=12]
setblock 487 247 306 minecraft:light[level=12]
setblock 487 247 313 minecraft:light[level=12]
fill 490 247 317 490 271 317 minecraft:deepslate_tiles
setblock 494 247 278 minecraft:light[level=12]
setblock 494 247 285 minecraft:light[level=12]
setblock 494 247 292 minecraft:light[level=12]
setblock 494 247 299 minecraft:light[level=12]
setblock 494 247 306 minecraft:light[level=12]
setblock 494 247 313 minecraft:light[level=12]
setblock 496 247 276 minecraft:cobbled_deepslate
fill 497 247 276 497 249 277 minecraft:deepslate_tiles
setblock 498 247 278 minecraft:deepslate_tiles
setblock 499 247 278 minecraft:cobbled_deepslate
setblock 500 247 277 minecraft:cobbled_deepslate
fill 500 247 278 502 247 279 minecraft:deepslate_tiles
setblock 500 247 316 minecraft:deepslate_tiles
setblock 501 247 276 minecraft:cobbled_deepslate
fill 501 247 277 501 250 277 minecraft:deepslate_tiles
setblock 501 247 285 minecraft:light[level=12]
setblock 501 247 292 minecraft:light[level=12]
setblock 501 247 299 minecraft:light[level=12]
setblock 501 247 306 minecraft:light[level=12]
setblock 501 247 313 minecraft:light[level=12]
setblock 501 247 316 minecraft:cobbled_deepslate
fill 502 247 276 502 250 276 minecraft:deepslate_tiles
fill 502 247 316 502 250 316 minecraft:deepslate_tiles
setblock 503 247 278 minecraft:deepslate_tiles
setblock 503 247 279 minecraft:cobbled_deepslate
setblock 504 247 278 minecraft:cobbled_deepslate
fill 504 247 279 504 250 279 minecraft:deepslate_tiles
setblock 505 247 277 minecraft:cobbled_deepslate
fill 505 247 278 505 250 278 minecraft:deepslate_tiles
setblock 506 247 276 minecraft:cobbled_deepslate
fill 506 247 277 506 250 277 minecraft:deepslate_tiles
setblock 506 247 316 minecraft:cobbled_deepslate
fill 507 247 276 507 250 276 minecraft:deepslate_tiles
fill 507 247 316 507 250 316 minecraft:deepslate_tiles
setblock 508 247 285 minecraft:light[level=12]
setblock 508 247 292 minecraft:light[level=12]
setblock 508 247 299 minecraft:light[level=12]
setblock 508 247 306 minecraft:light[level=12]
setblock 508 247 313 minecraft:light[level=12]
setblock 509 247 278 minecraft:cobbled_deepslate
fill 509 247 279 509 249 279 minecraft:deepslate_tiles
setblock 509 247 282 minecraft:deepslate_tiles
setblock 510 247 277 minecraft:cobbled_deepslate
fill 510 247 278 510 250 278 minecraft:deepslate_tiles
setblock 510 247 282 minecraft:cobbled_deepslate
fill 510 247 283 510 250 283 minecraft:deepslate_tiles
setblock 511 247 276 minecraft:cobbled_deepslate
fill 511 247 277 511 250 277 minecraft:deepslate_tiles
setblock 511 247 281 minecraft:cobbled_deepslate
fill 511 247 282 511 250 282 minecraft:deepslate_tiles
setblock 511 247 285 minecraft:deepslate_tiles
setblock 511 247 316 minecraft:cobbled_deepslate
fill 512 247 278 512 308 278 minecraft:deepslate_tiles
setblock 512 247 301 minecraft:redstone_block
fill 470 248 297 470 308 297 minecraft:deepslate_tiles
fill 470 248 306 472 250 306 minecraft:deepslate_tiles
fill 471 248 276 471 249 276 minecraft:deepslate_tiles
setblock 471 248 280 minecraft:cobbled_deepslate
fill 471 248 281 471 251 281 minecraft:deepslate_tiles
setblock 471 248 299 minecraft:deepslate_tiles
setblock 471 248 300 minecraft:cobbled_deepslate
fill 471 248 301 471 251 301 minecraft:deepslate_tiles
setblock 471 248 305 minecraft:cobbled_deepslate
setblock 471 248 309 minecraft:deepslate_tiles
setblock 471 248 310 minecraft:cobbled_deepslate
fill 471 248 316 471 249 316 minecraft:deepslate_tiles
fill 472 248 302 472 248 303 minecraft:deepslate_tiles
setblock 472 248 304 minecraft:cobbled_deepslate
fill 472 248 305 472 251 305 minecraft:deepslate_tiles
setblock 474 248 316 minecraft:deepslate_tiles
setblock 475 248 276 minecraft:cobbled_deepslate
setblock 475 248 316 minecraft:cobbled_deepslate
fill 476 248 276 476 251 276 minecraft:deepslate_tiles
fill 476 248 316 479 248 316 minecraft:deepslate_tiles
setblock 479 248 277 minecraft:cobbled_deepslate
setblock 480 248 276 minecraft:cobbled_deepslate
fill 480 248 277 480 251 277 minecraft:deepslate_tiles
setblock 480 248 316 minecraft:cobbled_deepslate
fill 481 248 276 481 251 276 minecraft:deepslate_tiles
setblock 481 248 315 minecraft:cobbled_deepslate
fill 481 248 316 481 251 316 minecraft:deepslate_tiles
setblock 484 248 277 minecraft:cobbled_deepslate
setblock 485 248 276 minecraft:cobbled_deepslate
setblock 485 248 277 minecraft:deepslate_tiles
setblock 485 248 316 minecraft:cobbled_deepslate
fill 486 248 276 486 250 276 minecraft:deepslate_tiles
setblock 495 248 276 minecraft:cobbled_deepslate
fill 496 248 276 496 250 277 minecraft:deepslate_tiles
setblock 498 248 278 minecraft:cobbled_deepslate
setblock 499 248 276 minecraft:deepslate_tiles
setblock 499 248 277 minecraft:cobbled_deepslate
fill 499 248 278 501 248 279 minecraft:deepslate_tiles
setblock 500 248 276 minecraft:cobbled_deepslate
fill 500 248 277 500 251 277 minecraft:deepslate_tiles
setblock 500 248 316 minecraft:cobbled_deepslate
fill 501 248 276 501 251 276 minecraft:deepslate_tiles
fill 501 248 316 501 251 316 minecraft:deepslate_tiles
setblock 502 248 278 minecraft:deepslate_tiles
setblock 502 248 279 minecraft:cobbled_deepslate
fill 502 248 280 504 249 280 minecraft:deepslate_tiles
setblock 503 248 278 minecraft:cobbled_deepslate
fill 503 248 279 503 251 279 minecraft:deepslate_tiles
setblock 504 248 277 minecraft:cobbled_deepslate
fill 504 248 278 504 251 278 minecraft:deepslate_tiles
setblock 505 248 276 minecraft:cobbled_deepslate
fill 505 248 277 505 251 277 minecraft:deepslate_tiles
setblock 505 248 316 minecraft:cobbled_deepslate
fill 506 248 276 506 251 276 minecraft:deepslate_tiles
fill 506 248 316 506 251 316 minecraft:deepslate_tiles
setblock 507 248 279 minecraft:cobbled_deepslate
setblock 508 248 278 minecraft:cobbled_deepslate
setblock 509 248 277 minecraft:cobbled_deepslate
fill 509 248 278 509 249 278 minecraft:deepslate_tiles
setblock 509 248 282 minecraft:cobbled_deepslate
setblock 510 248 276 minecraft:cobbled_deepslate
fill 510 248 277 510 250 277 minecraft:deepslate_tiles
setblock 510 248 281 minecraft:cobbled_deepslate
fill 510 248 282 510 251 282 minecraft:deepslate_tiles
fill 510 248 284 510 249 284 minecraft:deepslate_tiles
setblock 510 248 316 minecraft:cobbled_deepslate
fill 511 248 276 511 251 276 minecraft:deepslate_tiles
setblock 511 248 280 minecraft:cobbled_deepslate
fill 511 248 281 511 251 281 minecraft:deepslate_tiles
setblock 511 248 285 minecraft:cobbled_deepslate
fill 511 248 302 511 248 304 minecraft:deepslate_tiles
setblock 511 248 305 minecraft:cobbled_deepslate
fill 511 248 316 511 249 316 minecraft:deepslate_tiles
fill 512 248 301 512 253 301 minecraft:deepslate_tiles
setblock 471 249 279 minecraft:cobbled_deepslate
fill 471 249 280 471 251 280 minecraft:deepslate_tiles
setblock 471 249 283 minecraft:deepslate_tiles
setblock 471 249 299 minecraft:cobbled_deepslate
fill 471 249 300 471 252 300 minecraft:deepslate_tiles
setblock 471 249 304 minecraft:cobbled_deepslate
fill 471 249 305 471 252 305 minecraft:deepslate_tiles
setblock 471 249 309 minecraft:cobbled_deepslate
fill 471 249 310 471 250 312 minecraft:deepslate_tiles
fill 472 249 301 472 249 302 minecraft:deepslate_tiles
setblock 472 249 303 minecraft:cobbled_deepslate
fill 472 249 304 472 252 304 minecraft:deepslate_tiles
setblock 472 249 307 minecraft:deepslate_tiles
setblock 472 249 308 minecraft:cobbled_deepslate
setblock 473 249 316 minecraft:deepslate_tiles
setblock 474 249 316 minecraft:cobbled_deepslate
setblock 475 249 276 minecraft:deepslate_tiles
fill 475 249 301 475 265 301 minecraft:white_wool
fill 475 249 316 478 249 316 minecraft:deepslate_tiles
setblock 479 249 276 minecraft:cobbled_deepslate
fill 479 249 277 479 250 277 minecraft:deepslate_tiles
setblock 479 249 316 minecraft:cobbled_deepslate
fill 480 249 276 480 252 276 minecraft:deepslate_tiles
setblock 480 249 315 minecraft:cobbled_deepslate
fill 480 249 316 480 252 316 minecraft:deepslate_tiles
fill 481 249 315 481 250 315 minecraft:deepslate_tiles
setblock 483 249 277 minecraft:cobbled_deepslate
fill 484 249 275 484 301 275 minecraft:deepslate_tiles
setblock 484 249 276 minecraft:cobbled_deepslate
setblock 484 249 277 minecraft:deepslate_tiles
setblock 484 249 316 minecraft:cobbled_deepslate
fill 485 249 276 485 250 276 minecraft:deepslate_tiles
setblock 485 249 316 minecraft:deepslate_tiles
fill 491 249 317 492 257 317 minecraft:deepslate_tiles
setblock 493 249 317 minecraft:redstone_block
setblock 494 249 276 minecraft:cobbled_deepslate
fill 495 249 276 495 252 276 minecraft:deepslate_tiles
setblock 497 249 278 minecraft:cobbled_deepslate
setblock 498 249 276 minecraft:deepslate_tiles
setblock 498 249 277 minecraft:cobbled_deepslate
fill 498 249 278 501 249 278 minecraft:deepslate_tiles
fill 498 249 292 511 249 292 minecraft:cobbled_deepslate
setblock 499 249 276 minecraft:cobbled_deepslate
fill 499 249 277 499 252 277 minecraft:deepslate_tiles
fill 499 249 279 500 249 279 minecraft:deepslate_tiles
setblock 499 249 316 minecraft:cobbled_deepslate
fill 500 249 276 500 252 276 minecraft:deepslate_tiles
fill 500 249 316 500 252 316 minecraft:deepslate_tiles
setblock 501 249 279 minecraft:cobbled_deepslate
fill 501 249 280 501 251 280 minecraft:deepslate_tiles
setblock 502 249 278 minecraft:cobbled_deepslate
fill 502 249 279 502 252 279 minecraft:deepslate_tiles
setblock 503 249 277 minecraft:cobbled_deepslate
fill 503 249 278 503 252 278 minecraft:deepslate_tiles
setblock 504 249 276 minecraft:cobbled_deepslate
fill 504 249 277 504 252 277 minecraft:deepslate_tiles
setblock 504 249 316 minecraft:cobbled_deepslate
fill 505 249 276 505 252 276 minecraft:deepslate_tiles
fill 505 249 280 508 249 280 minecraft:cobbled_deepslate
fill 505 249 316 505 252 316 minecraft:deepslate_tiles
setblock 506 249 279 minecraft:cobbled_deepslate
setblock 507 249 278 minecraft:cobbled_deepslate
setblock 508 249 277 minecraft:cobbled_deepslate
fill 508 249 278 508 250 278 minecraft:deepslate_tiles
setblock 509 249 276 minecraft:cobbled_deepslate
fill 509 249 277 509 251 277 minecraft:deepslate_tiles
setblock 509 249 281 minecraft:cobbled_deepslate
fill 509 249 282 509 250 282 minecraft:deepslate_tiles
setblock 509 249 316 minecraft:cobbled_deepslate
fill 510 249 276 510 252 276 minecraft:deepslate_tiles
setblock 510 249 280 minecraft:cobbled_deepslate
fill 510 249 281 510 252 281 minecraft:deepslate_tiles
fill 510 249 316 510 250 316 minecraft:deepslate_tiles
setblock 511 249 279 minecraft:cobbled_deepslate
fill 511 249 280 511 252 280 minecraft:deepslate_tiles
setblock 511 249 284 minecraft:cobbled_deepslate
fill 511 249 285 511 251 286 minecraft:deepslate_tiles
fill 511 249 301 511 249 303 minecraft:deepslate_tiles
setblock 511 249 304 minecraft:cobbled_deepslate
fill 511 249 305 511 249 308 minecraft:deepslate_tiles
setblock 471 250 278 minecraft:cobbled_deepslate
fill 471 250 279 471 251 279 minecraft:deepslate_tiles
fill 471 250 283 471 250 284 minecraft:cobbled_deepslate
fill 471 250 288 510 251 288 minecraft:cobbled_deepslate
fill 471 250 292 485 250 292 minecraft:cobbled_deepslate
fill 471 250 296 471 251 296 minecraft:cobbled_deepslate
fill 471 250 299 471 251 299 minecraft:deepslate_tiles
setblock 471 250 303 minecraft:cobbled_deepslate
fill 471 250 304 471 253 304 minecraft:deepslate_tiles
setblock 471 250 308 minecraft:cobbled_deepslate
fill 471 250 309 472 252 309 minecraft:deepslate_tiles
setblock 471 250 313 minecraft:cobbled_deepslate
fill 471 250 314 471 253 314 minecraft:deepslate_tiles
fill 472 250 280 499 250 280 minecraft:cobbled_deepslate
fill 472 250 284 472 251 284 minecraft:cobbled_deepslate
fill 472 250 300 475 251 300 minecraft:cobbled_deepslate
setblock 472 250 301 minecraft:deepslate_tiles
setblock 472 250 302 minecraft:cobbled_deepslate
fill 472 250 303 473 252 303 minecraft:deepslate_tiles
setblock 472 250 307 minecraft:cobbled_deepslate
fill 472 250 308 472 253 308 minecraft:deepslate_tiles
fill 472 250 312 472 251 312 minecraft:cobbled_deepslate
fill 473 250 302 473 254 302 minecraft:black_concrete
fill 473 250 304 473 250 305 minecraft:deepslate_tiles
setblock 473 250 306 minecraft:cobbled_deepslate
fill 473 250 308 511 250 308 minecraft:cobbled_deepslate
setblock 473 250 316 minecraft:cobbled_deepslate
fill 474 250 301 474 254 301 minecraft:black_concrete
fill 474 250 303 474 254 303 minecraft:black_concrete
fill 474 250 304 510 251 304 minecraft:cobbled_deepslate
fill 474 250 316 477 250 316 minecraft:deepslate_tiles
fill 475 250 302 475 252 302 minecraft:black_concrete
setblock 478 250 276 minecraft:cobbled_deepslate
setblock 478 250 316 minecraft:cobbled_deepslate
fill 479 250 276 479 253 276 minecraft:deepslate_tiles
setblock 479 250 315 minecraft:cobbled_deepslate
fill 479 250 316 479 253 316 minecraft:deepslate_tiles
fill 480 250 315 480 251 315 minecraft:deepslate_tiles
setblock 482 250 277 minecraft:cobbled_deepslate
setblock 483 250 276 minecraft:cobbled_deepslate
setblock 483 250 277 minecraft:deepslate_tiles
setblock 483 250 316 minecraft:cobbled_deepslate
fill 484 250 276 484 251 276 minecraft:deepslate_tiles
setblock 484 250 316 minecraft:deepslate_tiles
fill 485 250 275 486 291 275 minecraft:deepslate_tiles
setblock 487 250 275 minecraft:redstone_block
fill 488 250 275 488 288 275 minecraft:deepslate_tiles
fill 493 250 292 500 250 292 minecraft:cobbled_deepslate
fill 493 250 317 493 308 317 minecraft:deepslate_tiles
fill 494 250 276 494 252 276 minecraft:deepslate_tiles
setblock 495 250 317 minecraft:redstone_block
setblock 497 250 276 minecraft:deepslate_tiles
setblock 497 250 277 minecraft:cobbled_deepslate
fill 497 250 278 500 250 278 minecraft:deepslate_tiles
setblock 498 250 276 minecraft:cobbled_deepslate
fill 498 250 277 498 253 277 minecraft:deepslate_tiles
fill 498 250 279 499 250 279 minecraft:deepslate_tiles
fill 499 250 276 499 253 276 minecraft:deepslate_tiles
fill 499 250 316 499 253 316 minecraft:deepslate_tiles
setblock 500 250 279 minecraft:cobbled_deepslate
fill 500 250 280 500 251 280 minecraft:deepslate_tiles
setblock 501 250 278 minecraft:cobbled_deepslate
fill 501 250 279 501 253 279 minecraft:deepslate_tiles
setblock 502 250 277 minecraft:cobbled_deepslate
fill 502 250 278 502 253 278 minecraft:deepslate_tiles
fill 502 250 280 503 250 280 minecraft:deepslate_tiles
setblock 503 250 276 minecraft:cobbled_deepslate
fill 503 250 277 503 253 277 minecraft:deepslate_tiles
setblock 503 250 316 minecraft:cobbled_deepslate
fill 504 250 276 504 253 276 minecraft:deepslate_tiles
setblock 504 250 280 minecraft:cobbled_deepslate
fill 504 250 316 504 253 316 minecraft:deepslate_tiles
setblock 505 250 279 minecraft:cobbled_deepslate
setblock 506 250 278 minecraft:cobbled_deepslate
setblock 506 250 279 minecraft:deepslate_tiles
setblock 507 250 277 minecraft:cobbled_deepslate
fill 507 250 278 507 251 278 minecraft:deepslate_tiles
fill 507 250 290 507 252 290 minecraft:black_concrete
setblock 508 250 276 minecraft:cobbled_deepslate
fill 508 250 277 508 251 277 minecraft:deepslate_tiles
setblock 508 250 316 minecraft:cobbled_deepslate
fill 509 250 276 509 252 276 minecraft:deepslate_tiles
setblock 509 250 280 minecraft:cobbled_deepslate
setblock 509 250 281 minecraft:deepslate_tiles
setblock 509 250 316 minecraft:deepslate_tiles
setblock 510 250 279 minecraft:cobbled_deepslate
fill 510 250 280 510 252 280 minecraft:deepslate_tiles
setblock 510 250 284 minecraft:cobbled_deepslate
setblock 511 250 278 minecraft:cobbled_deepslate
fill 511 250 279 511 253 279 minecraft:deepslate_tiles
setblock 511 250 283 minecraft:cobbled_deepslate
fill 511 250 284 511 253 284 minecraft:deepslate_tiles
setblock 511 250 302 minecraft:deepslate_tiles
setblock 511 250 303 minecraft:cobbled_deepslate
fill 511 250 304 511 250 307 minecraft:deepslate_tiles
fill 511 250 309 511 252 310 minecraft:deepslate_tiles
fill 470 251 306 470 293 307 minecraft:deepslate_tiles
setblock 471 251 282 minecraft:cobbled_deepslate
fill 471 251 283 471 252 284 minecraft:deepslate_tiles
setblock 471 251 292 minecraft:cobbled_deepslate
setblock 471 251 302 minecraft:cobbled_deepslate
fill 471 251 303 471 254 303 minecraft:deepslate_tiles
setblock 471 251 306 minecraft:deepslate_tiles
setblock 471 251 307 minecraft:cobbled_deepslate
fill 471 251 308 471 254 308 minecraft:deepslate_tiles
fill 471 251 310 471 251 311 minecraft:deepslate_tiles
setblock 471 251 312 minecraft:cobbled_deepslate
fill 471 251 313 471 254 313 minecraft:deepslate_tiles
setblock 472 251 280 minecraft:cobbled_deepslate
fill 472 251 296 486 251 296 minecraft:cobbled_deepslate
setblock 472 251 301 minecraft:cobbled_deepslate
fill 472 251 302 472 254 302 minecraft:deepslate_tiles
setblock 472 251 306 minecraft:cobbled_deepslate
fill 472 251 307 473 253 307 minecraft:deepslate_tiles
setblock 472 251 310 minecraft:deepslate_tiles
fill 473 251 284 509 251 284 minecraft:cobbled_deepslate
setblock 473 251 304 minecraft:deepslate_tiles
setblock 473 251 305 minecraft:cobbled_deepslate
fill 473 251 306 473 254 306 minecraft:deepslate_tiles
setblock 473 251 308 minecraft:cobbled_deepslate
fill 473 251 312 506 251 312 minecraft:cobbled_deepslate
fill 474 251 316 476 251 316 minecraft:deepslate_tiles
fill 476 251 300 511 251 300 minecraft:cobbled_deepslate
setblock 477 251 276 minecraft:cobbled_deepslate
setblock 477 251 316 minecraft:cobbled_deepslate
fill 478 251 276 478 252 276 minecraft:deepslate_tiles
fill 478 251 316 478 254 316 minecraft:deepslate_tiles
setblock 479 251 315 minecraft:deepslate_tiles
setblock 481 251 277 minecraft:cobbled_deepslate
setblock 482 251 276 minecraft:cobbled_deepslate
setblock 482 251 316 minecraft:cobbled_deepslate
fill 483 251 276 483 252 276 minecraft:deepslate_tiles
setblock 483 251 316 minecraft:deepslate_tiles
fill 487 251 275 487 308 275 minecraft:deepslate_tiles
fill 492 251 296 501 251 296 minecraft:cobbled_deepslate
setblock 495 251 277 minecraft:deepslate_tiles
fill 495 251 317 495 308 317 minecraft:deepslate_tiles
setblock 496 251 276 minecraft:deepslate_tiles
setblock 496 251 277 minecraft:cobbled_deepslate
setblock 497 251 276 minecraft:cobbled_deepslate
fill 497 251 277 497 253 278 minecraft:deepslate_tiles
fill 498 251 276 498 254 276 minecraft:deepslate_tiles
fill 498 251 278 498 251 279 minecraft:deepslate_tiles
fill 498 251 316 498 254 316 minecraft:deepslate_tiles
setblock 499 251 278 minecraft:deepslate_tiles
setblock 499 251 279 minecraft:cobbled_deepslate
setblock 500 251 278 minecraft:cobbled_deepslate
fill 500 251 279 500 253 279 minecraft:deepslate_tiles
setblock 501 251 277 minecraft:cobbled_deepslate
fill 501 251 278 501 254 278 minecraft:deepslate_tiles
setblock 502 251 276 minecraft:cobbled_deepslate
fill 502 251 277 502 254 277 minecraft:deepslate_tiles
setblock 502 251 280 minecraft:deepslate_tiles
setblock 502 251 316 minecraft:cobbled_deepslate
fill 503 251 276 503 254 276 minecraft:deepslate_tiles
fill 503 251 316 503 254 316 minecraft:deepslate_tiles
setblock 504 251 279 minecraft:cobbled_deepslate
setblock 505 251 278 minecraft:cobbled_deepslate
setblock 505 251 279 minecraft:deepslate_tiles
fill 505 251 283 505 254 283 minecraft:cobbled_deepslate
setblock 506 251 277 minecraft:cobbled_deepslate
setblock 506 251 278 minecraft:deepslate_tiles
fill 506 251 282 506 254 282 minecraft:cobbled_deepslate
setblock 507 251 276 minecraft:cobbled_deepslate
fill 507 251 277 507 252 277 minecraft:deepslate_tiles
setblock 507 251 283 minecraft:cobbled_deepslate
setblock 507 251 316 minecraft:cobbled_deepslate
fill 508 251 276 508 253 276 minecraft:deepslate_tiles
setblock 508 251 316 minecraft:deepslate_tiles
setblock 510 251 278 minecraft:cobbled_deepslate
setblock 510 251 279 minecraft:deepslate_tiles
setblock 510 251 283 minecraft:cobbled_deepslate
setblock 510 251 284 minecraft:deepslate_tiles
setblock 511 251 277 minecraft:cobbled_deepslate
fill 511 251 278 511 253 278 minecraft:deepslate_tiles
setblock 511 251 282 minecraft:cobbled_deepslate
fill 511 251 283 511 254 283 minecraft:deepslate_tiles
setblock 511 251 302 minecraft:cobbled_deepslate
fill 511 251 303 511 251 306 minecraft:deepslate_tiles
setblock 511 251 307 minecraft:cobbled_deepslate
fill 511 251 308 511 254 308 minecraft:deepslate_tiles
setblock 511 251 311 minecraft:deepslate_tiles
setblock 471 252 282 minecraft:deepslate_tiles
setblock 471 252 301 minecraft:cobbled_deepslate
fill 471 252 302 471 255 302 minecraft:deepslate_tiles
setblock 471 252 306 minecraft:cobbled_deepslate
fill 471 252 307 471 255 307 minecraft:deepslate_tiles
setblock 471 252 310 minecraft:deepslate_tiles
setblock 471 252 311 minecraft:cobbled_deepslate
fill 471 252 312 471 255 312 minecraft:deepslate_tiles
setblock 472 252 301 minecraft:deepslate_tiles
setblock 472 252 305 minecraft:cobbled_deepslate
fill 472 252 306 472 255 306 minecraft:deepslate_tiles
setblock 472 252 310 minecraft:cobbled_deepslate
fill 472 252 311 472 255 311 minecraft:deepslate_tiles
fill 473 252 301 473 254 301 minecraft:black_concrete
setblock 473 252 304 minecraft:cobbled_deepslate
fill 473 252 305 473 255 305 minecraft:deepslate_tiles
setblock 473 252 308 minecraft:deepslate_tiles
fill 474 252 316 475 252 316 minecraft:deepslate_tiles
fill 475 252 276 475 253 280 minecraft:white_wool
setblock 475 252 303 minecraft:black_concrete
setblock 476 252 316 minecraft:cobbled_deepslate
setblock 477 252 276 minecraft:deepslate_tiles
fill 477 252 316 477 255 316 minecraft:deepslate_tiles
fill 479 252 277 479 253 277 minecraft:white_wool
setblock 481 252 276 minecraft:cobbled_deepslate
setblock 481 252 316 minecraft:cobbled_deepslate
setblock 482 252 276 minecraft:deepslate_tiles
setblock 482 252 316 minecraft:deepslate_tiles
fill 487 252 276 487 253 277 minecraft:white_wool
fill 491 252 276 491 253 277 minecraft:white_wool
fill 495 252 277 495 252 315 minecraft:white_wool
setblock 496 252 276 minecraft:cobbled_deepslate
fill 496 252 277 496 254 277 minecraft:deepslate_tiles
fill 497 252 276 497 255 276 minecraft:deepslate_tiles
setblock 498 252 278 minecraft:deepslate_tiles
setblock 498 252 279 minecraft:cobbled_deepslate
setblock 499 252 278 minecraft:cobbled_deepslate
fill 499 252 279 499 253 279 minecraft:deepslate_tiles
fill 499 252 296 511 252 296 minecraft:cobbled_deepslate
setblock 500 252 277 minecraft:cobbled_deepslate
fill 500 252 278 500 254 278 minecraft:deepslate_tiles
setblock 501 252 276 minecraft:cobbled_deepslate
fill 501 252 277 501 255 277 minecraft:deepslate_tiles
setblock 501 252 316 minecraft:cobbled_deepslate
fill 502 252 276 502 255 276 minecraft:deepslate_tiles
fill 502 252 316 502 255 316 minecraft:deepslate_tiles
setblock 503 252 279 minecraft:cobbled_deepslate
setblock 504 252 278 minecraft:cobbled_deepslate
fill 504 252 312 510 252 312 minecraft:cobbled_deepslate
setblock 505 252 277 minecraft:cobbled_deepslate
setblock 505 252 278 minecraft:deepslate_tiles
setblock 506 252 276 minecraft:cobbled_deepslate
setblock 506 252 277 minecraft:deepslate_tiles
fill 506 252 284 510 252 284 minecraft:cobbled_deepslate
setblock 506 252 316 minecraft:cobbled_deepslate
fill 507 252 276 507 253 276 minecraft:deepslate_tiles
fill 507 252 278 507 253 283 minecraft:white_wool
setblock 507 252 316 minecraft:deepslate_tiles
setblock 510 252 282 minecraft:cobbled_deepslate
setblock 510 252 283 minecraft:deepslate_tiles
setblock 511 252 276 minecraft:cobbled_deepslate
setblock 511 252 277 minecraft:deepslate_tiles
setblock 511 252 281 minecraft:cobbled_deepslate
fill 511 252 282 511 254 282 minecraft:deepslate_tiles
setblock 511 252 285 minecraft:deepslate_tiles
setblock 511 252 286 minecraft:cobbled_deepslate
fill 511 252 303 511 252 305 minecraft:deepslate_tiles
setblock 511 252 306 minecraft:cobbled_deepslate
fill 511 252 307 511 255 307 minecraft:deepslate_tiles
setblock 511 252 311 minecraft:cobbled_deepslate
fill 511 252 312 511 254 313 minecraft:deepslate_tiles
setblock 471 253 300 minecraft:cobbled_deepslate
fill 471 253 301 471 254 301 minecraft:deepslate_tiles
setblock 471 253 305 minecraft:cobbled_deepslate
fill 471 253 306 471 256 306 minecraft:deepslate_tiles
setblock 471 253 309 minecraft:deepslate_tiles
setblock 471 253 310 minecraft:cobbled_deepslate
fill 471 253 311 471 256 311 minecraft:deepslate_tiles
setblock 472 253 303 minecraft:deepslate_tiles
setblock 472 253 304 minecraft:cobbled_deepslate
fill 472 253 305 472 256 305 minecraft:deepslate_tiles
setblock 472 253 309 minecraft:cobbled_deepslate
fill 472 253 310 472 256 310 minecraft:deepslate_tiles
setblock 473 253 278 minecraft:light[level=13]
setblock 473 253 285 minecraft:light[level=12]
setblock 473 253 286 minecraft:light[level=13]
setblock 473 253 292 minecraft:light[level=12]
setblock 473 253 294 minecraft:light[level=13]
setblock 473 253 299 minecraft:light[level=12]
fill 473 253 303 473 254 303 minecraft:black_concrete
fill 473 253 304 473 254 304 minecraft:deepslate_tiles
setblock 473 253 308 minecraft:cobbled_deepslate
fill 473 253 309 473 256 309 minecraft:deepslate_tiles
setblock 473 253 310 minecraft:light[level=13]
setblock 473 253 313 minecraft:light[level=12]
setblock 474 253 316 minecraft:deepslate_tiles
fill 475 253 281 475 253 300 minecraft:white_wool
fill 475 253 302 475 253 315 minecraft:white_wool
setblock 475 253 316 minecraft:cobbled_deepslate
fill 476 253 316 476 256 316 minecraft:deepslate_tiles
fill 479 253 278 479 253 313 minecraft:white_wool
setblock 480 253 276 minecraft:cobbled_deepslate
setblock 480 253 278 minecraft:light[level=12]
setblock 480 253 285 minecraft:light[level=12]
setblock 480 253 292 minecraft:light[level=12]
setblock 480 253 299 minecraft:light[level=12]
setblock 480 253 306 minecraft:light[level=12]
setblock 480 253 313 minecraft:light[level=12]
setblock 480 253 316 minecraft:cobbled_deepslate
setblock 481 253 278 minecraft:light[level=13]
setblock 481 253 286 minecraft:light[level=13]
setblock 481 253 294 minecraft:light[level=13]
setblock 481 253 302 minecraft:light[level=13]
setblock 481 253 310 minecraft:light[level=13]
setblock 481 253 316 minecraft:deepslate_tiles
fill 483 253 276 483 253 305 minecraft:white_wool
fill 487 253 278 487 253 290 minecraft:white_wool
setblock 487 253 292 minecraft:light[level=12]
fill 487 253 297 487 253 309 minecraft:white_wool
setblock 487 253 313 minecraft:light[level=12]
setblock 489 253 278 minecraft:light[level=13]
setblock 489 253 286 minecraft:light[level=13]
setblock 489 253 302 minecraft:light[level=13]
setblock 489 253 310 minecraft:light[level=13]
fill 491 253 278 491 253 290 minecraft:white_wool
fill 491 253 297 491 253 312 minecraft:white_wool
setblock 494 253 278 minecraft:light[level=12]
setblock 494 253 285 minecraft:light[level=12]
setblock 494 253 292 minecraft:light[level=12]
setblock 494 253 299 minecraft:light[level=12]
setblock 494 253 306 minecraft:light[level=12]
setblock 494 253 313 minecraft:light[level=12]
setblock 495 253 276 minecraft:cobbled_deepslate
fill 495 253 277 495 253 305 minecraft:white_wool
fill 496 253 276 496 256 276 minecraft:deepslate_tiles
setblock 497 253 286 minecraft:light[level=13]
setblock 497 253 294 minecraft:light[level=13]
setblock 497 253 302 minecraft:light[level=13]
setblock 497 253 310 minecraft:light[level=13]
setblock 498 253 278 minecraft:cobbled_deepslate
setblock 499 253 277 minecraft:cobbled_deepslate
fill 499 253 278 499 254 278 minecraft:deepslate_tiles
fill 499 253 280 499 253 315 minecraft:white_wool
setblock 500 253 276 minecraft:cobbled_deepslate
fill 500 253 277 500 256 277 minecraft:deepslate_tiles
setblock 500 253 316 minecraft:cobbled_deepslate
fill 501 253 276 501 256 276 minecraft:deepslate_tiles
setblock 501 253 285 minecraft:light[level=12]
setblock 501 253 292 minecraft:light[level=12]
setblock 501 253 299 minecraft:light[level=12]
setblock 501 253 306 minecraft:light[level=12]
setblock 501 253 313 minecraft:light[level=12]
fill 501 253 316 501 256 316 minecraft:deepslate_tiles
setblock 503 253 278 minecraft:cobbled_deepslate
fill 503 253 279 503 253 303 minecraft:white_wool
setblock 504 253 277 minecraft:cobbled_deepslate
setblock 505 253 276 minecraft:cobbled_deepslate
setblock 505 253 277 minecraft:deepslate_tiles
setblock 505 253 278 minecraft:light[level=13]
fill 505 253 282 505 254 282 minecraft:cobbled_deepslate
fill 505 253 284 506 254 284 minecraft:cobbled_deepslate
setblock 505 253 286 minecraft:light[level=13]
setblock 505 253 294 minecraft:light[level=13]
setblock 505 253 302 minecraft:light[level=13]
setblock 505 253 310 minecraft:light[level=13]
setblock 505 253 316 minecraft:cobbled_deepslate
fill 506 253 276 506 254 276 minecraft:deepslate_tiles
setblock 506 253 316 minecraft:deepslate_tiles
setblock 507 253 277 minecraft:white_wool
fill 507 253 284 507 253 315 minecraft:white_wool
setblock 508 253 278 minecraft:light[level=12]
setblock 508 253 285 minecraft:light[level=12]
setblock 508 253 292 minecraft:light[level=12]
setblock 508 253 299 minecraft:light[level=12]
setblock 508 253 306 minecraft:light[level=12]
setblock 508 253 313 minecraft:light[level=12]
fill 510 253 275 510 308 275 minecraft:deepslate_tiles
setblock 511 253 275 minecraft:redstone_block
setblock 511 253 280 minecraft:cobbled_deepslate
fill 511 253 281 511 254 281 minecraft:deepslate_tiles
setblock 511 253 285 minecraft:cobbled_deepslate
fill 511 253 286 511 254 286 minecraft:deepslate_tiles
fill 511 253 303 511 253 304 minecraft:deepslate_tiles
setblock 511 253 305 minecraft:cobbled_deepslate
fill 511 253 306 511 256 306 minecraft:deepslate_tiles
setblock 511 253 309 minecraft:deepslate_tiles
setblock 511 253 310 minecraft:cobbled_deepslate
fill 511 253 311 511 256 311 minecraft:deepslate_tiles
fill 512 253 275 512 308 275 minecraft:deepslate_tiles
setblock 470 254 281 minecraft:redstone_block
setblock 471 254 304 minecraft:cobbled_deepslate
fill 471 254 305 471 257 305 minecraft:deepslate_tiles
setblock 471 254 309 minecraft:cobbled_deepslate
fill 471 254 310 471 257 310 minecraft:deepslate_tiles
setblock 471 254 314 minecraft:cobbled_deepslate
setblock 472 254 303 minecraft:cobbled_deepslate
fill 472 254 304 472 257 304 minecraft:deepslate_tiles
setblock 472 254 307 minecraft:deepslate_tiles
setblock 472 254 308 minecraft:cobbled_deepslate
fill 472 254 309 472 257 309 minecraft:deepslate_tiles
setblock 473 254 307 minecraft:cobbled_deepslate
fill 473 254 308 473 257 308 minecraft:deepslate_tiles
setblock 474 254 275 minecraft:redstone_block
fill 475 254 302 475 254 303 minecraft:black_concrete
fill 475 254 316 475 257 316 minecraft:deepslate_tiles
fill 479 254 310 479 254 315 minecraft:white_wool
setblock 479 254 316 minecraft:cobbled_deepslate
setblock 480 254 316 minecraft:deepslate_tiles
fill 483 254 303 483 254 316 minecraft:white_wool
fill 487 254 307 487 254 315 minecraft:white_wool
fill 491 254 310 491 254 315 minecraft:white_wool
fill 495 254 276 495 257 276 minecraft:deepslate_tiles
setblock 497 254 277 minecraft:deepslate_tiles
setblock 498 254 277 minecraft:cobbled_deepslate
setblock 498 254 278 minecraft:deepslate_tiles
setblock 499 254 276 minecraft:cobbled_deepslate
fill 499 254 277 499 257 277 minecraft:deepslate_tiles
setblock 499 254 316 minecraft:cobbled_deepslate
fill 500 254 276 500 257 276 minecraft:deepslate_tiles
fill 500 254 316 500 257 316 minecraft:deepslate_tiles
setblock 503 254 277 minecraft:cobbled_deepslate
fill 503 254 302 503 254 315 minecraft:white_wool
setblock 504 254 276 minecraft:cobbled_deepslate
setblock 504 254 277 minecraft:deepslate_tiles
setblock 504 254 316 minecraft:cobbled_deepslate
fill 505 254 276 505 255 276 minecraft:deepslate_tiles
setblock 505 254 316 minecraft:deepslate_tiles
fill 507 254 282 507 254 284 minecraft:cobbled_deepslate
fill 507 254 290 507 260 290 minecraft:black_concrete
fill 511 254 275 511 308 275 minecraft:deepslate_tiles
setblock 511 254 284 minecraft:cobbled_deepslate
fill 511 254 285 511 255 285 minecraft:deepslate_tiles
setblock 511 254 304 minecraft:cobbled_deepslate
fill 511 254 305 511 257 305 minecraft:deepslate_tiles
setblock 511 254 309 minecraft:cobbled_deepslate
fill 511 254 310 511 257 310 minecraft:deepslate_tiles
setblock 511 254 314 minecraft:cobbled_deepslate
setblock 512 254 301 minecraft:redstone_block
fill 470 255 281 470 308 281 minecraft:deepslate_tiles
setblock 471 255 303 minecraft:cobbled_deepslate
fill 471 255 304 471 258 304 minecraft:deepslate_tiles
setblock 471 255 308 minecraft:cobbled_deepslate
fill 471 255 309 471 258 309 minecraft:deepslate_tiles
setblock 471 255 313 minecraft:cobbled_deepslate
fill 471 255 314 471 258 314 minecraft:deepslate_tiles
fill 472 255 303 472 256 303 minecraft:deepslate_tiles
setblock 472 255 307 minecraft:cobbled_deepslate
fill 472 255 308 472 258 308 minecraft:deepslate_tiles
setblock 472 255 312 minecraft:cobbled_deepslate
setblock 473 255 306 minecraft:cobbled_deepslate
fill 473 255 307 473 258 307 minecraft:deepslate_tiles
setblock 473 255 310 minecraft:deepslate_tiles
fill 474 255 275 474 308 275 minecraft:deepslate_tiles
setblock 478 255 316 minecraft:cobbled_deepslate
setblock 479 255 316 minecraft:deepslate_tiles
setblock 497 255 277 minecraft:cobbled_deepslate
setblock 497 255 316 minecraft:deepslate_tiles
setblock 498 255 276 minecraft:cobbled_deepslate
fill 498 255 277 498 258 277 minecraft:deepslate_tiles
setblock 498 255 316 minecraft:cobbled_deepslate
fill 499 255 276 499 258 276 minecraft:deepslate_tiles
fill 499 255 316 499 258 316 minecraft:deepslate_tiles
setblock 502 255 277 minecraft:cobbled_deepslate
setblock 503 255 276 minecraft:cobbled_deepslate
setblock 503 255 316 minecraft:cobbled_deepslate
setblock 504 255 276 minecraft:deepslate_tiles
setblock 511 255 284 minecraft:deepslate_tiles
setblock 511 255 304 minecraft:deepslate_tiles
setblock 511 255 308 minecraft:cobbled_deepslate
fill 511 255 309 511 258 309 minecraft:deepslate_tiles
setblock 511 255 312 minecraft:deepslate_tiles
setblock 511 255 313 minecraft:cobbled_deepslate
fill 511 255 314 511 258 314 minecraft:deepslate_tiles
fill 512 255 301 512 308 301 minecraft:deepslate_tiles
fill 470 256 313 470 260 315 minecraft:deepslate_tiles
setblock 470 256 316 minecraft:redstone_block
setblock 471 256 302 minecraft:cobbled_deepslate
fill 471 256 303 471 259 303 minecraft:deepslate_tiles
setblock 471 256 307 minecraft:cobbled_deepslate
fill 471 256 308 471 259 308 minecraft:deepslate_tiles
setblock 471 256 312 minecraft:cobbled_deepslate
fill 471 256 313 471 259 313 minecraft:deepslate_tiles
setblock 472 256 306 minecraft:cobbled_deepslate
fill 472 256 307 472 259 307 minecraft:deepslate_tiles
setblock 472 256 311 minecraft:cobbled_deepslate
fill 472 256 312 472 259 312 minecraft:deepslate_tiles
setblock 473 256 305 minecraft:cobbled_deepslate
fill 473 256 306 473 259 306 minecraft:deepslate_tiles
setblock 473 256 310 minecraft:cobbled_deepslate
setblock 477 256 316 minecraft:cobbled_deepslate
fill 478 256 316 478 259 316 minecraft:deepslate_tiles
setblock 497 256 276 minecraft:cobbled_deepslate
fill 497 256 277 497 259 277 minecraft:deepslate_tiles
setblock 497 256 316 minecraft:cobbled_deepslate
fill 498 256 276 498 259 276 minecraft:deepslate_tiles
fill 498 256 316 498 259 316 minecraft:deepslate_tiles
setblock 502 256 276 minecraft:cobbled_deepslate
setblock 502 256 316 minecraft:cobbled_deepslate
setblock 503 256 276 minecraft:deepslate_tiles
fill 503 256 316 503 259 316 minecraft:deepslate_tiles
setblock 511 256 307 minecraft:cobbled_deepslate
fill 511 256 308 511 259 308 minecraft:deepslate_tiles
setblock 511 256 312 minecraft:cobbled_deepslate
fill 511 256 313 511 259 313 minecraft:deepslate_tiles
fill 511 256 315 511 257 315 minecraft:deepslate_tiles
fill 470 257 316 470 272 316 minecraft:deepslate_tiles
fill 471 257 302 471 260 302 minecraft:deepslate_tiles
setblock 471 257 306 minecraft:cobbled_deepslate
fill 471 257 307 471 260 307 minecraft:deepslate_tiles
setblock 471 257 311 minecraft:cobbled_deepslate
fill 471 257 312 471 260 312 minecraft:deepslate_tiles
setblock 472 257 305 minecraft:cobbled_deepslate
fill 472 257 306 472 260 306 minecraft:deepslate_tiles
setblock 472 257 310 minecraft:cobbled_deepslate
fill 472 257 311 472 260 311 minecraft:deepslate_tiles
fill 472 257 313 472 258 313 minecraft:deepslate_tiles
setblock 473 257 309 minecraft:cobbled_deepslate
fill 473 257 310 473 260 310 minecraft:deepslate_tiles
fill 474 257 316 474 258 316 minecraft:deepslate_tiles
setblock 476 257 316 minecraft:cobbled_deepslate
fill 477 257 316 477 260 316 minecraft:deepslate_tiles
fill 494 257 276 494 258 276 minecraft:deepslate_tiles
setblock 496 257 276 minecraft:cobbled_deepslate
setblock 496 257 316 minecraft:cobbled_deepslate
fill 497 257 276 497 260 276 minecraft:deepslate_tiles
fill 497 257 316 497 260 316 minecraft:deepslate_tiles
setblock 501 257 276 minecraft:cobbled_deepslate
setblock 501 257 316 minecraft:cobbled_deepslate
fill 502 257 276 502 260 276 minecraft:deepslate_tiles
fill 502 257 316 502 260 316 minecraft:deepslate_tiles
fill 506 257 290 506 260 290 minecraft:black_concrete
fill 507 257 289 507 260 289 minecraft:black_concrete
fill 507 257 291 507 260 291 minecraft:black_concrete
fill 508 257 290 508 260 290 minecraft:black_concrete
fill 510 257 310 510 258 310 minecraft:deepslate_tiles
setblock 511 257 306 minecraft:cobbled_deepslate
fill 511 257 307 511 260 307 minecraft:deepslate_tiles
setblock 511 257 311 minecraft:cobbled_deepslate
fill 511 257 312 511 260 312 minecraft:deepslate_tiles
setblock 511 257 316 minecraft:cobbled_deepslate
fill 471 258 288 471 258 289 minecraft:deepslate_tiles
setblock 471 258 290 minecraft:cobbled_deepslate
fill 471 258 291 471 261 291 minecraft:deepslate_tiles
setblock 471 258 305 minecraft:cobbled_deepslate
fill 471 258 306 471 261 306 minecraft:deepslate_tiles
setblock 471 258 310 minecraft:cobbled_deepslate
fill 471 258 311 471 261 311 minecraft:deepslate_tiles
setblock 471 258 315 minecraft:cobbled_deepslate
setblock 472 258 304 minecraft:cobbled_deepslate
fill 472 258 305 472 261 305 minecraft:deepslate_tiles
setblock 472 258 309 minecraft:cobbled_deepslate
fill 472 258 310 472 261 310 minecraft:deepslate_tiles
fill 472 258 316 473 259 316 minecraft:deepslate_tiles
setblock 473 258 308 minecraft:cobbled_deepslate
fill 473 258 309 473 261 309 minecraft:deepslate_tiles
fill 473 258 311 473 259 311 minecraft:deepslate_tiles
setblock 475 258 316 minecraft:cobbled_deepslate
fill 476 258 316 476 261 316 minecraft:deepslate_tiles
setblock 491 258 317 minecraft:white_wool
fill 492 258 317 492 308 317 minecraft:deepslate_tiles
setblock 495 258 276 minecraft:cobbled_deepslate
setblock 495 258 316 minecraft:cobbled_deepslate
fill 496 258 276 496 261 276 minecraft:deepslate_tiles
fill 496 258 316 496 261 316 minecraft:deepslate_tiles
setblock 497 258 275 minecraft:white_wool
fill 498 258 275 498 308 275 minecraft:deepslate_tiles
setblock 500 258 276 minecraft:cobbled_deepslate
setblock 500 258 316 minecraft:cobbled_deepslate
fill 501 258 276 501 261 276 minecraft:deepslate_tiles
fill 501 258 316 501 261 316 minecraft:deepslate_tiles
fill 510 258 309 510 259 309 minecraft:deepslate_tiles
setblock 510 258 311 minecraft:cobbled_deepslate
fill 510 258 312 510 261 312 minecraft:deepslate_tiles
setblock 510 258 316 minecraft:cobbled_deepslate
setblock 511 258 305 minecraft:cobbled_deepslate
fill 511 258 306 511 261 306 minecraft:deepslate_tiles
setblock 511 258 310 minecraft:cobbled_deepslate
fill 511 258 311 511 261 311 minecraft:deepslate_tiles
setblock 511 258 315 minecraft:cobbled_deepslate
fill 511 258 316 511 261 316 minecraft:deepslate_tiles
fill 471 259 287 471 259 288 minecraft:deepslate_tiles
setblock 471 259 289 minecraft:cobbled_deepslate
fill 471 259 290 472 261 290 minecraft:deepslate_tiles
fill 471 259 292 471 259 293 minecraft:deepslate_tiles
setblock 471 259 294 minecraft:cobbled_deepslate
setblock 471 259 304 minecraft:cobbled_deepslate
fill 471 259 305 471 262 305 minecraft:deepslate_tiles
setblock 471 259 309 minecraft:cobbled_deepslate
fill 471 259 310 471 262 310 minecraft:deepslate_tiles
setblock 471 259 314 minecraft:cobbled_deepslate
fill 471 259 315 471 261 316 minecraft:deepslate_tiles
fill 472 259 289 472 262 289 minecraft:deepslate_tiles
fill 472 259 291 472 260 291 minecraft:deepslate_tiles
fill 472 259 304 472 262 304 minecraft:deepslate_tiles
setblock 472 259 308 minecraft:cobbled_deepslate
fill 472 259 309 472 262 309 minecraft:deepslate_tiles
setblock 472 259 313 minecraft:cobbled_deepslate
fill 472 259 314 472 262 314 minecraft:deepslate_tiles
setblock 473 259 278 minecraft:light[level=12]
setblock 473 259 285 minecraft:light[level=12]
setblock 473 259 292 minecraft:light[level=12]
setblock 473 259 299 minecraft:light[level=12]
setblock 473 259 307 minecraft:cobbled_deepslate
fill 473 259 308 473 262 308 minecraft:deepslate_tiles
setblock 473 259 312 minecraft:cobbled_deepslate
setblock 473 259 313 minecraft:light[level=12]
fill 473 259 315 474 259 315 minecraft:deepslate_tiles
fill 473 259 317 474 308 317 minecraft:deepslate_tiles
setblock 474 259 316 minecraft:cobbled_deepslate
setblock 475 259 315 minecraft:cobbled_deepslate
fill 475 259 316 475 262 316 minecraft:deepslate_tiles
setblock 475 259 317 minecraft:redstone_block
fill 476 259 315 476 262 315 minecraft:deepslate_tiles
setblock 480 259 278 minecraft:light[level=12]
setblock 480 259 285 minecraft:light[level=12]
setblock 480 259 292 minecraft:light[level=12]
setblock 480 259 299 minecraft:light[level=12]
setblock 480 259 306 minecraft:light[level=12]
setblock 480 259 313 minecraft:light[level=12]
setblock 487 259 278 minecraft:light[level=12]
setblock 487 259 285 minecraft:light[level=12]
setblock 487 259 292 minecraft:light[level=12]
setblock 487 259 299 minecraft:light[level=12]
setblock 487 259 306 minecraft:light[level=12]
setblock 487 259 313 minecraft:light[level=12]
fill 491 259 317 491 263 317 minecraft:deepslate_tiles
setblock 493 259 276 minecraft:deepslate_tiles
setblock 494 259 276 minecraft:cobbled_deepslate
setblock 494 259 278 minecraft:light[level=12]
setblock 494 259 285 minecraft:light[level=12]
setblock 494 259 292 minecraft:light[level=12]
setblock 494 259 299 minecraft:light[level=12]
setblock 494 259 306 minecraft:light[level=12]
setblock 494 259 313 minecraft:light[level=12]
setblock 494 259 316 minecraft:cobbled_deepslate
fill 495 259 276 495 262 276 minecraft:deepslate_tiles
fill 495 259 316 495 262 316 minecraft:deepslate_tiles
fill 496 259 277 496 260 277 minecraft:deepslate_tiles
fill 496 259 315 499 259 315 minecraft:deepslate_tiles
fill 497 259 275 497 308 275 minecraft:deepslate_tiles
setblock 498 259 277 minecraft:cobbled_deepslate
setblock 499 259 276 minecraft:cobbled_deepslate
setblock 499 259 316 minecraft:cobbled_deepslate
fill 500 259 276 500 262 276 minecraft:deepslate_tiles
setblock 500 259 315 minecraft:cobbled_deepslate
fill 500 259 316 500 262 316 minecraft:deepslate_tiles
setblock 501 259 278 minecraft:light[level=12]
setblock 501 259 285 minecraft:light[level=12]
setblock 501 259 292 minecraft:light[level=12]
setblock 501 259 299 minecraft:light[level=12]
setblock 501 259 306 minecraft:light[level=12]
setblock 501 259 313 minecraft:light[level=12]
setblock 504 259 316 minecraft:cobbled_deepslate
setblock 508 259 278 minecraft:light[level=12]
setblock 508 259 285 minecraft:light[level=12]
setblock 508 259 292 minecraft:light[level=12]
setblock 508 259 299 minecraft:light[level=12]
setblock 508 259 306 minecraft:light[level=12]
setblock 508 259 313 minecraft:light[level=12]
setblock 508 259 316 minecraft:deepslate_tiles
setblock 509 259 316 minecraft:cobbled_deepslate
fill 510 259 308 510 260 308 minecraft:deepslate_tiles
setblock 510 259 310 minecraft:cobbled_deepslate
fill 510 259 311 510 262 311 minecraft:deepslate_tiles
fill 510 259 313 510 259 314 minecraft:deepslate_tiles
fill 510 259 316 510 262 316 minecraft:deepslate_tiles
fill 511 259 305 511 262 305 minecraft:deepslate_tiles
setblock 511 259 309 minecraft:cobbled_deepslate
fill 511 259 310 511 262 310 minecraft:deepslate_tiles
setblock 511 259 314 minecraft:cobbled_deepslate
fill 511 259 315 511 262 315 minecraft:deepslate_tiles
setblock 512 259 303 minecraft:redstone_block
setblock 471 260 275 minecraft:redstone_block
fill 471 260 286 471 260 287 minecraft:deepslate_tiles
setblock 471 260 288 minecraft:cobbled_deepslate
fill 471 260 289 471 263 289 minecraft:deepslate_tiles
setblock 471 260 292 minecraft:deepslate_tiles
setblock 471 260 293 minecraft:cobbled_deepslate
fill 471 260 294 471 260 297 minecraft:deepslate_tiles
setblock 471 260 298 minecraft:cobbled_deepslate
fill 471 260 299 471 261 301 minecraft:deepslate_tiles
setblock 471 260 303 minecraft:cobbled_deepslate
fill 471 260 304 471 263 304 minecraft:deepslate_tiles
setblock 471 260 308 minecraft:cobbled_deepslate
fill 471 260 309 471 263 309 minecraft:deepslate_tiles
setblock 471 260 313 minecraft:cobbled_deepslate
fill 471 260 314 471 263 314 minecraft:deepslate_tiles
fill 472 260 288 472 263 288 minecraft:deepslate_tiles
setblock 472 260 292 minecraft:cobbled_deepslate
fill 472 260 293 472 261 295 minecraft:deepslate_tiles
fill 472 260 303 472 263 303 minecraft:deepslate_tiles
setblock 472 260 307 minecraft:cobbled_deepslate
fill 472 260 308 472 263 308 minecraft:deepslate_tiles
setblock 472 260 312 minecraft:cobbled_deepslate
fill 472 260 313 473 262 313 minecraft:deepslate_tiles
fill 472 260 315 472 260 316 minecraft:deepslate_tiles
setblock 473 260 291 minecraft:cobbled_deepslate
setblock 473 260 306 minecraft:cobbled_deepslate
fill 473 260 307 473 263 307 minecraft:deepslate_tiles
setblock 473 260 311 minecraft:cobbled_deepslate
fill 473 260 312 473 263 312 minecraft:deepslate_tiles
setblock 473 260 315 minecraft:deepslate_tiles
setblock 473 260 316 minecraft:cobbled_deepslate
setblock 474 260 315 minecraft:cobbled_deepslate
fill 474 260 316 474 263 316 minecraft:deepslate_tiles
fill 475 260 315 475 263 315 minecraft:deepslate_tiles
fill 475 260 317 475 308 317 minecraft:deepslate_tiles
fill 477 260 315 477 261 315 minecraft:deepslate_tiles
setblock 478 260 316 minecraft:cobbled_deepslate
fill 479 260 316 479 263 316 minecraft:deepslate_tiles
setblock 492 260 276 minecraft:deepslate_tiles
setblock 492 260 316 minecraft:deepslate_tiles
setblock 493 260 276 minecraft:cobbled_deepslate
setblock 493 260 316 minecraft:cobbled_deepslate
fill 494 260 276 494 262 277 minecraft:deepslate_tiles
setblock 494 260 315 minecraft:cobbled_deepslate
fill 494 260 316 494 263 316 minecraft:deepslate_tiles
fill 495 260 277 495 261 277 minecraft:deepslate_tiles
fill 495 260 315 498 260 315 minecraft:deepslate_tiles
setblock 497 260 277 minecraft:cobbled_deepslate
setblock 498 260 276 minecraft:cobbled_deepslate
fill 498 260 277 499 262 277 minecraft:deepslate_tiles
setblock 498 260 316 minecraft:cobbled_deepslate
fill 499 260 276 499 263 276 minecraft:deepslate_tiles
setblock 499 260 315 minecraft:cobbled_deepslate
fill 499 260 316 499 263 316 minecraft:deepslate_tiles
fill 500 260 315 502 261 315 minecraft:deepslate_tiles
setblock 503 260 316 minecraft:cobbled_deepslate
fill 504 260 316 507 260 316 minecraft:deepslate_tiles
setblock 508 260 316 minecraft:cobbled_deepslate
setblock 509 260 315 minecraft:cobbled_deepslate
fill 509 260 316 509 263 316 minecraft:deepslate_tiles
fill 510 260 307 510 261 307 minecraft:deepslate_tiles
setblock 510 260 309 minecraft:cobbled_deepslate
fill 510 260 310 510 263 310 minecraft:deepslate_tiles
setblock 510 260 313 minecraft:deepslate_tiles
setblock 510 260 314 minecraft:cobbled_deepslate
fill 510 260 315 510 263 315 minecraft:deepslate_tiles
setblock 511 260 287 minecraft:deepslate_tiles
setblock 511 260 288 minecraft:cobbled_deepslate
fill 511 260 289 511 261 291 minecraft:deepslate_tiles
fill 511 260 304 511 263 304 minecraft:deepslate_tiles
setblock 511 260 308 minecraft:cobbled_deepslate
fill 511 260 309 511 263 309 minecraft:deepslate_tiles
setblock 511 260 313 minecraft:cobbled_deepslate
fill 511 260 314 511 263 314 minecraft:deepslate_tiles
setblock 512 260 288 minecraft:redstone_block
fill 512 260 289 512 270 289 minecraft:deepslate_tiles
fill 512 260 303 512 308 303 minecraft:deepslate_tiles
setblock 470 261 313 minecraft:white_wool
fill 470 261 314 470 263 315 minecraft:deepslate_tiles
fill 471 261 275 471 308 275 minecraft:deepslate_tiles
fill 471 261 285 471 261 286 minecraft:deepslate_tiles
setblock 471 261 287 minecraft:cobbled_deepslate
fill 471 261 288 471 264 288 minecraft:deepslate_tiles
setblock 471 261 292 minecraft:cobbled_deepslate
fill 471 261 293 471 261 296 minecraft:deepslate_tiles
setblock 471 261 297 minecraft:cobbled_deepslate
fill 471 261 298 472 263 298 minecraft:deepslate_tiles
setblock 471 261 302 minecraft:cobbled_deepslate
fill 471 261 303 471 264 303 minecraft:deepslate_tiles
setblock 471 261 307 minecraft:cobbled_deepslate
fill 471 261 308 471 264 308 minecraft:deepslate_tiles
setblock 471 261 312 minecraft:cobbled_deepslate
fill 471 261 313 471 264 313 minecraft:deepslate_tiles
fill 472 261 287 472 264 287 minecraft:deepslate_tiles
setblock 472 261 291 minecraft:cobbled_deepslate
fill 472 261 292 473 263 292 minecraft:deepslate_tiles
setblock 472 261 296 minecraft:cobbled_deepslate
fill 472 261 297 472 264 297 minecraft:deepslate_tiles
fill 472 261 299 472 261 300 minecraft:deepslate_tiles
setblock 472 261 301 minecraft:cobbled_deepslate
fill 472 261 302 472 264 302 minecraft:deepslate_tiles
setblock 472 261 306 minecraft:cobbled_deepslate
fill 472 261 307 472 264 307 minecraft:deepslate_tiles
setblock 472 261 311 minecraft:cobbled_deepslate
fill 472 261 312 472 264 312 minecraft:deepslate_tiles
setblock 472 261 315 minecraft:deepslate_tiles
setblock 472 261 316 minecraft:cobbled_deepslate
setblock 473 261 278 minecraft:light[level=13]
setblock 473 261 286 minecraft:light[level=13]
setblock 473 261 289 minecraft:deepslate_tiles
setblock 473 261 290 minecraft:cobbled_deepslate
fill 473 261 291 473 264 291 minecraft:deepslate_tiles
fill 473 261 293 473 261 294 minecraft:deepslate_tiles
setblock 473 261 295 minecraft:cobbled_deepslate
setblock 473 261 302 minecraft:light[level=13]
setblock 473 261 305 minecraft:cobbled_deepslate
fill 473 261 306 473 264 306 minecraft:deepslate_tiles
setblock 473 261 310 minecraft:cobbled_deepslate
fill 473 261 311 473 264 311 minecraft:deepslate_tiles
setblock 473 261 314 minecraft:deepslate_tiles
setblock 473 261 315 minecraft:cobbled_deepslate
fill 473 261 316 473 264 316 minecraft:deepslate_tiles
setblock 474 261 314 minecraft:cobbled_deepslate
fill 474 261 315 474 264 315 minecraft:deepslate_tiles
fill 475 261 314 476 263 314 minecraft:deepslate_tiles
setblock 477 261 316 minecraft:cobbled_deepslate
setblock 478 261 315 minecraft:cobbled_deepslate
fill 478 261 316 478 264 316 minecraft:deepslate_tiles
setblock 481 261 278 minecraft:light[level=13]
setblock 481 261 286 minecraft:light[level=13]
setblock 481 261 294 minecraft:light[level=13]
setblock 481 261 302 minecraft:light[level=13]
setblock 481 261 310 minecraft:light[level=13]
setblock 489 261 278 minecraft:light[level=13]
setblock 489 261 286 minecraft:light[level=13]
setblock 489 261 302 minecraft:light[level=13]
setblock 489 261 310 minecraft:light[level=13]
fill 490 261 276 491 261 276 minecraft:deepslate_tiles
setblock 491 261 316 minecraft:deepslate_tiles
setblock 492 261 276 minecraft:cobbled_deepslate
setblock 492 261 315 minecraft:deepslate_tiles
setblock 492 261 316 minecraft:cobbled_deepslate
fill 493 261 276 493 263 277 minecraft:deepslate_tiles
setblock 493 261 315 minecraft:cobbled_deepslate
fill 493 261 316 493 264 316 minecraft:deepslate_tiles
fill 494 261 315 497 261 315 minecraft:deepslate_tiles
fill 495 261 314 498 261 314 minecraft:deepslate_tiles
setblock 496 261 277 minecraft:cobbled_deepslate
fill 496 261 306 496 264 307 minecraft:white_terracotta
setblock 497 261 276 minecraft:cobbled_deepslate
fill 497 261 277 497 264 277 minecraft:deepslate_tiles
setblock 497 261 278 minecraft:light[level=13]
setblock 497 261 286 minecraft:light[level=13]
setblock 497 261 294 minecraft:light[level=13]
setblock 497 261 302 minecraft:light[level=13]
fill 497 261 307 497 264 307 minecraft:white_terracotta
setblock 497 261 310 minecraft:light[level=13]
setblock 497 261 316 minecraft:cobbled_deepslate
fill 498 261 276 498 264 276 minecraft:deepslate_tiles
setblock 498 261 315 minecraft:cobbled_deepslate
fill 498 261 316 498 264 316 minecraft:deepslate_tiles
setblock 499 261 314 minecraft:cobbled_deepslate
fill 499 261 315 499 264 315 minecraft:deepslate_tiles
setblock 502 261 276 minecraft:cobbled_deepslate
setblock 502 261 316 minecraft:cobbled_deepslate
fill 503 261 276 503 264 276 minecraft:deepslate_tiles
setblock 503 261 315 minecraft:cobbled_deepslate
fill 503 261 316 506 261 316 minecraft:deepslate_tiles
fill 504 261 315 507 261 315 minecraft:deepslate_tiles
setblock 505 261 278 minecraft:light[level=13]
setblock 505 261 286 minecraft:light[level=13]
setblock 505 261 294 minecraft:light[level=13]
setblock 505 261 302 minecraft:light[level=13]
setblock 505 261 310 minecraft:light[level=13]
setblock 507 261 316 minecraft:cobbled_deepslate
setblock 508 261 315 minecraft:cobbled_deepslate
fill 508 261 316 508 264 316 minecraft:deepslate_tiles
fill 509 261 311 509 261 313 minecraft:deepslate_tiles
fill 509 261 315 509 264 315 minecraft:deepslate_tiles
setblock 510 261 308 minecraft:cobbled_deepslate
fill 510 261 309 510 264 309 minecraft:deepslate_tiles
setblock 510 261 313 minecraft:cobbled_deepslate
fill 510 261 314 510 264 314 minecraft:deepslate_tiles
setblock 511 261 276 minecraft:deepslate_tiles
setblock 511 261 286 minecraft:deepslate_tiles
setblock 511 261 287 minecraft:cobbled_deepslate
fill 511 261 288 512 264 288 minecraft:deepslate_tiles
setblock 511 261 292 minecraft:cobbled_deepslate
fill 511 261 293 511 262 295 minecraft:deepslate_tiles
fill 511 261 303 511 264 303 minecraft:deepslate_tiles
setblock 511 261 307 minecraft:cobbled_deepslate
fill 511 261 308 511 264 308 minecraft:deepslate_tiles
setblock 511 261 312 minecraft:cobbled_deepslate
fill 511 261 313 511 264 313 minecraft:deepslate_tiles
fill 470 262 313 470 308 313 minecraft:deepslate_tiles
setblock 471 262 285 minecraft:deepslate_tiles
setblock 471 262 286 minecraft:cobbled_deepslate
fill 471 262 287 471 265 287 minecraft:deepslate_tiles
setblock 471 262 290 minecraft:deepslate_tiles
setblock 471 262 291 minecraft:cobbled_deepslate
fill 471 262 292 471 262 295 minecraft:deepslate_tiles
setblock 471 262 296 minecraft:cobbled_deepslate
fill 471 262 297 471 265 297 minecraft:deepslate_tiles
fill 471 262 299 471 262 300 minecraft:deepslate_tiles
setblock 471 262 301 minecraft:cobbled_deepslate
fill 471 262 302 471 265 302 minecraft:deepslate_tiles
setblock 471 262 306 minecraft:cobbled_deepslate
fill 471 262 307 471 265 307 minecraft:deepslate_tiles
setblock 471 262 311 minecraft:cobbled_deepslate
fill 471 262 312 471 265 312 minecraft:deepslate_tiles
setblock 471 262 315 minecraft:deepslate_tiles
setblock 471 262 316 minecraft:cobbled_deepslate
fill 472 262 286 472 265 286 minecraft:deepslate_tiles
setblock 472 262 290 minecraft:cobbled_deepslate
fill 472 262 291 472 265 291 minecraft:deepslate_tiles
fill 472 262 293 472 262 294 minecraft:deepslate_tiles
setblock 472 262 295 minecraft:cobbled_deepslate
fill 472 262 296 473 264 296 minecraft:deepslate_tiles
setblock 472 262 299 minecraft:deepslate_tiles
setblock 472 262 300 minecraft:cobbled_deepslate
fill 472 262 301 472 265 301 minecraft:deepslate_tiles
setblock 472 262 305 minecraft:cobbled_deepslate
fill 472 262 306 472 265 306 minecraft:deepslate_tiles
setblock 472 262 310 minecraft:cobbled_deepslate
fill 472 262 311 472 265 311 minecraft:deepslate_tiles
setblock 472 262 315 minecraft:cobbled_deepslate
fill 472 262 316 472 265 316 minecraft:deepslate_tiles
fill 473 262 276 475 262 276 minecraft:deepslate_tiles
setblock 473 262 288 minecraft:deepslate_tiles
setblock 473 262 289 minecraft:cobbled_deepslate
fill 473 262 290 474 264 290 minecraft:deepslate_tiles
setblock 473 262 293 minecraft:deepslate_tiles
setblock 473 262 294 minecraft:cobbled_deepslate
fill 473 262 295 473 265 295 minecraft:deepslate_tiles
fill 473 262 297 473 262 298 minecraft:deepslate_tiles
fill 473 262 305 473 265 305 minecraft:deepslate_tiles
setblock 473 262 309 minecraft:cobbled_deepslate
fill 473 262 310 474 263 310 minecraft:deepslate_tiles
setblock 473 262 314 minecraft:cobbled_deepslate
fill 473 262 315 473 265 315 minecraft:deepslate_tiles
fill 474 262 291 474 262 292 minecraft:deepslate_tiles
setblock 474 262 293 minecraft:cobbled_deepslate
fill 474 262 294 474 265 294 minecraft:deepslate_tiles
fill 474 262 311 474 262 312 minecraft:deepslate_tiles
fill 474 262 314 474 265 314 minecraft:deepslate_tiles
setblock 476 262 276 minecraft:cobbled_deepslate
setblock 476 262 316 minecraft:cobbled_deepslate
fill 477 262 276 477 265 276 minecraft:deepslate_tiles
setblock 477 262 315 minecraft:cobbled_deepslate
fill 477 262 316 477 265 316 minecraft:deepslate_tiles
fill 478 262 315 478 265 315 minecraft:deepslate_tiles
setblock 480 262 316 minecraft:deepslate_tiles
fill 489 262 276 490 262 276 minecraft:deepslate_tiles
fill 489 262 316 490 262 316 minecraft:deepslate_tiles
setblock 491 262 276 minecraft:cobbled_deepslate
fill 491 262 277 492 264 277 minecraft:deepslate_tiles
setblock 491 262 315 minecraft:deepslate_tiles
setblock 491 262 316 minecraft:cobbled_deepslate
fill 492 262 276 492 265 276 minecraft:deepslate_tiles
setblock 492 262 315 minecraft:cobbled_deepslate
fill 492 262 316 492 265 316 minecraft:deepslate_tiles
setblock 493 262 314 minecraft:cobbled_deepslate
fill 493 262 315 496 262 315 minecraft:deepslate_tiles
fill 494 262 314 497 262 314 minecraft:deepslate_tiles
setblock 495 262 277 minecraft:cobbled_deepslate
fill 495 262 306 495 263 307 minecraft:white_terracotta
setblock 496 262 276 minecraft:cobbled_deepslate
fill 496 262 277 496 265 277 minecraft:deepslate_tiles
fill 496 262 308 496 263 308 minecraft:white_terracotta
setblock 496 262 316 minecraft:cobbled_deepslate
fill 497 262 276 497 265 276 minecraft:deepslate_tiles
fill 497 262 306 497 263 306 minecraft:white_terracotta
setblock 497 262 315 minecraft:cobbled_deepslate
fill 497 262 316 497 265 316 minecraft:deepslate_tiles
setblock 498 262 314 minecraft:cobbled_deepslate
fill 498 262 315 498 265 315 minecraft:deepslate_tiles
fill 499 262 314 500 264 314 minecraft:deepslate_tiles
setblock 500 262 277 minecraft:cobbled_deepslate
fill 500 262 315 501 262 315 minecraft:deepslate_tiles
setblock 501 262 276 minecraft:cobbled_deepslate
setblock 501 262 316 minecraft:cobbled_deepslate
fill 502 262 276 502 265 276 minecraft:deepslate_tiles
setblock 502 262 315 minecraft:cobbled_deepslate
fill 502 262 316 505 262 316 minecraft:deepslate_tiles
fill 503 262 315 506 262 315 minecraft:deepslate_tiles
fill 504 262 276 504 263 276 minecraft:deepslate_tiles
setblock 506 262 316 minecraft:cobbled_deepslate
setblock 507 262 315 minecraft:cobbled_deepslate
fill 507 262 316 507 265 316 minecraft:deepslate_tiles
setblock 508 262 314 minecraft:cobbled_deepslate
fill 508 262 315 508 265 315 minecraft:deepslate_tiles
fill 509 262 276 510 262 276 minecraft:deepslate_tiles
fill 509 262 310 509 262 312 minecraft:deepslate_tiles
setblock 509 262 313 minecraft:cobbled_deepslate
fill 509 262 314 509 265 314 minecraft:deepslate_tiles
setblock 510 262 306 minecraft:deepslate_tiles
setblock 510 262 307 minecraft:cobbled_deepslate
fill 510 262 308 510 265 308 minecraft:deepslate_tiles
setblock 510 262 312 minecraft:cobbled_deepslate
fill 510 262 313 510 265 313 minecraft:deepslate_tiles
setblock 511 262 276 minecraft:cobbled_deepslate
fill 511 262 277 511 265 277 minecraft:deepslate_tiles
setblock 511 262 286 minecraft:cobbled_deepslate
fill 511 262 287 511 265 287 minecraft:deepslate_tiles
fill 511 262 289 511 262 290 minecraft:deepslate_tiles
setblock 511 262 291 minecraft:cobbled_deepslate
fill 511 262 292 511 265 292 minecraft:deepslate_tiles
setblock 511 262 296 minecraft:cobbled_deepslate
fill 511 262 297 511 262 300 minecraft:deepslate_tiles
setblock 511 262 301 minecraft:cobbled_deepslate
fill 511 262 302 511 265 302 minecraft:deepslate_tiles
setblock 511 262 306 minecraft:cobbled_deepslate
fill 511 262 307 511 265 307 minecraft:deepslate_tiles
setblock 511 262 311 minecraft:cobbled_deepslate
fill 511 262 312 511 265 312 minecraft:deepslate_tiles
setblock 511 262 316 minecraft:cobbled_deepslate
fill 471 263 276 474 263 276 minecraft:deepslate_tiles
setblock 471 263 284 minecraft:deepslate_tiles
setblock 471 263 285 minecraft:cobbled_deepslate
fill 471 263 286 471 266 286 minecraft:deepslate_tiles
setblock 471 263 290 minecraft:cobbled_deepslate
fill 471 263 291 471 263 294 minecraft:deepslate_tiles
setblock 471 263 295 minecraft:cobbled_deepslate
fill 471 263 296 471 266 296 minecraft:deepslate_tiles
setblock 471 263 299 minecraft:deepslate_tiles
setblock 471 263 300 minecraft:cobbled_deepslate
fill 471 263 301 471 266 301 minecraft:deepslate_tiles
setblock 471 263 305 minecraft:cobbled_deepslate
fill 471 263 306 471 266 306 minecraft:deepslate_tiles
setblock 471 263 310 minecraft:cobbled_deepslate
fill 471 263 311 471 266 311 minecraft:deepslate_tiles
setblock 471 263 315 minecraft:cobbled_deepslate
fill 471 263 316 471 266 316 minecraft:deepslate_tiles
setblock 472 263 289 minecraft:cobbled_deepslate
fill 472 263 290 472 266 290 minecraft:deepslate_tiles
setblock 472 263 293 minecraft:deepslate_tiles
setblock 472 263 294 minecraft:cobbled_deepslate
fill 472 263 295 472 266 295 minecraft:deepslate_tiles
setblock 472 263 299 minecraft:cobbled_deepslate
fill 472 263 300 473 265 300 minecraft:deepslate_tiles
setblock 472 263 304 minecraft:cobbled_deepslate
fill 472 263 305 472 266 305 minecraft:deepslate_tiles
setblock 472 263 309 minecraft:cobbled_deepslate
fill 472 263 310 472 266 310 minecraft:deepslate_tiles
setblock 472 263 313 minecraft:deepslate_tiles
setblock 472 263 314 minecraft:cobbled_deepslate
fill 472 263 315 472 266 315 minecraft:deepslate_tiles
setblock 473 263 287 minecraft:deepslate_tiles
setblock 473 263 288 minecraft:cobbled_deepslate
fill 473 263 289 474 265 289 minecraft:deepslate_tiles
setblock 473 263 293 minecraft:cobbled_deepslate
fill 473 263 294 473 266 294 minecraft:deepslate_tiles
setblock 473 263 297 minecraft:deepslate_tiles
setblock 473 263 298 minecraft:cobbled_deepslate
fill 473 263 299 473 266 299 minecraft:deepslate_tiles
fill 473 263 301 473 264 301 minecraft:deepslate_tiles
fill 473 263 304 473 265 304 minecraft:deepslate_tiles
setblock 473 263 308 minecraft:cobbled_deepslate
fill 473 263 309 473 266 309 minecraft:deepslate_tiles
setblock 473 263 313 minecraft:cobbled_deepslate
fill 473 263 314 473 266 314 minecraft:deepslate_tiles
setblock 474 263 291 minecraft:deepslate_tiles
setblock 474 263 292 minecraft:cobbled_deepslate
fill 474 263 293 474 266 293 minecraft:deepslate_tiles
fill 474 263 295 474 263 296 minecraft:deepslate_tiles
setblock 474 263 297 minecraft:cobbled_deepslate
setblock 474 263 311 minecraft:deepslate_tiles
setblock 474 263 312 minecraft:cobbled_deepslate
fill 474 263 313 474 264 313 minecraft:deepslate_tiles
setblock 475 263 276 minecraft:cobbled_deepslate
setblock 475 263 316 minecraft:cobbled_deepslate
fill 476 263 276 476 266 276 minecraft:deepslate_tiles
setblock 476 263 315 minecraft:cobbled_deepslate
fill 476 263 316 476 266 316 minecraft:deepslate_tiles
setblock 477 263 314 minecraft:cobbled_deepslate
fill 477 263 315 477 266 315 minecraft:deepslate_tiles
fill 478 263 276 478 264 276 minecraft:deepslate_tiles
setblock 480 263 316 minecraft:cobbled_deepslate
fill 487 263 276 489 263 276 minecraft:deepslate_tiles
fill 487 263 316 489 263 316 minecraft:deepslate_tiles
fill 489 263 315 490 263 315 minecraft:deepslate_tiles
setblock 490 263 276 minecraft:cobbled_deepslate
fill 490 263 277 490 266 277 minecraft:deepslate_tiles
setblock 490 263 316 minecraft:cobbled_deepslate
fill 491 263 276 491 266 276 minecraft:deepslate_tiles
setblock 491 263 315 minecraft:cobbled_deepslate
fill 491 263 316 491 266 316 minecraft:deepslate_tiles
setblock 492 263 314 minecraft:cobbled_deepslate
fill 492 263 315 495 263 315 minecraft:deepslate_tiles
setblock 493 263 278 minecraft:cobbled_deepslate
fill 493 263 314 496 263 314 minecraft:deepslate_tiles
setblock 494 263 276 minecraft:deepslate_tiles
setblock 494 263 277 minecraft:cobbled_deepslate
fill 494 263 278 496 264 278 minecraft:deepslate_tiles
setblock 495 263 276 minecraft:cobbled_deepslate
fill 495 263 277 495 266 277 minecraft:deepslate_tiles
setblock 495 263 316 minecraft:cobbled_deepslate
fill 496 263 276 496 266 276 minecraft:deepslate_tiles
setblock 496 263 315 minecraft:cobbled_deepslate
fill 496 263 316 496 266 316 minecraft:deepslate_tiles
setblock 497 263 314 minecraft:cobbled_deepslate
fill 497 263 315 497 266 315 minecraft:deepslate_tiles
setblock 498 263 277 minecraft:deepslate_tiles
fill 498 263 314 498 266 314 minecraft:deepslate_tiles
setblock 499 263 277 minecraft:cobbled_deepslate
setblock 500 263 276 minecraft:cobbled_deepslate
fill 500 263 277 500 266 277 minecraft:deepslate_tiles
setblock 500 263 315 minecraft:deepslate_tiles
setblock 500 263 316 minecraft:cobbled_deepslate
fill 501 263 276 501 266 276 minecraft:deepslate_tiles
setblock 501 263 314 minecraft:deepslate_tiles
setblock 501 263 315 minecraft:cobbled_deepslate
fill 501 263 316 504 263 316 minecraft:deepslate_tiles
fill 502 263 315 505 263 315 minecraft:deepslate_tiles
setblock 505 263 276 minecraft:cobbled_deepslate
setblock 505 263 316 minecraft:cobbled_deepslate
fill 506 263 276 509 263 276 minecraft:deepslate_tiles
setblock 506 263 314 minecraft:deepslate_tiles
setblock 506 263 315 minecraft:cobbled_deepslate
fill 506 263 316 506 266 316 minecraft:deepslate_tiles
setblock 507 263 314 minecraft:cobbled_deepslate
fill 507 263 315 507 266 315 minecraft:deepslate_tiles
fill 508 263 314 508 266 314 minecraft:deepslate_tiles
fill 509 263 309 509 263 311 minecraft:deepslate_tiles
setblock 509 263 312 minecraft:cobbled_deepslate
fill 509 263 313 509 266 313 minecraft:deepslate_tiles
setblock 510 263 276 minecraft:cobbled_deepslate
setblock 510 263 290 minecraft:deepslate_tiles
setblock 510 263 291 minecraft:cobbled_deepslate
fill 510 263 292 510 264 294 minecraft:deepslate_tiles
setblock 510 263 306 minecraft:cobbled_deepslate
fill 510 263 307 510 266 307 minecraft:deepslate_tiles
setblock 510 263 311 minecraft:cobbled_deepslate
fill 510 263 312 510 266 312 minecraft:deepslate_tiles
setblock 510 263 316 minecraft:cobbled_deepslate
fill 511 263 276 511 266 276 minecraft:deepslate_tiles
fill 511 263 278 511 264 278 minecraft:deepslate_tiles
setblock 511 263 285 minecraft:cobbled_deepslate
fill 511 263 286 511 266 286 minecraft:deepslate_tiles
setblock 511 263 289 minecraft:deepslate_tiles
setblock 511 263 290 minecraft:cobbled_deepslate
fill 511 263 291 511 266 291 minecraft:deepslate_tiles
fill 511 263 293 511 263 294 minecraft:deepslate_tiles
setblock 511 263 295 minecraft:cobbled_deepslate
fill 511 263 296 511 263 299 minecraft:deepslate_tiles
setblock 511 263 300 minecraft:cobbled_deepslate
fill 511 263 301 511 266 301 minecraft:deepslate_tiles
setblock 511 263 305 minecraft:cobbled_deepslate
fill 511 263 306 511 266 306 minecraft:deepslate_tiles
setblock 511 263 310 minecraft:cobbled_deepslate
fill 511 263 311 511 266 311 minecraft:deepslate_tiles
setblock 511 263 315 minecraft:cobbled_deepslate
fill 511 263 316 511 266 316 minecraft:deepslate_tiles
setblock 470 264 314 minecraft:redstone_block
fill 470 264 315 471 267 315 minecraft:deepslate_tiles
fill 471 264 276 471 264 278 minecraft:deepslate_tiles
setblock 471 264 283 minecraft:deepslate_tiles
setblock 471 264 284 minecraft:cobbled_deepslate
fill 471 264 285 471 267 285 minecraft:deepslate_tiles
setblock 471 264 289 minecraft:cobbled_deepslate
fill 471 264 290 471 264 293 minecraft:deepslate_tiles
setblock 471 264 294 minecraft:cobbled_deepslate
fill 471 264 295 471 267 295 minecraft:deepslate_tiles
setblock 471 264 298 minecraft:deepslate_tiles
setblock 471 264 299 minecraft:cobbled_deepslate
fill 471 264 300 471 267 300 minecraft:deepslate_tiles
setblock 471 264 304 minecraft:cobbled_deepslate
fill 471 264 305 471 267 305 minecraft:deepslate_tiles
setblock 471 264 309 minecraft:cobbled_deepslate
fill 471 264 310 471 267 310 minecraft:deepslate_tiles
setblock 471 264 314 minecraft:cobbled_deepslate
fill 472 264 276 473 264 276 minecraft:deepslate_tiles
setblock 472 264 288 minecraft:cobbled_deepslate
fill 472 264 289 472 267 289 minecraft:deepslate_tiles
setblock 472 264 292 minecraft:deepslate_tiles
setblock 472 264 293 minecraft:cobbled_deepslate
fill 472 264 294 472 267 294 minecraft:deepslate_tiles
setblock 472 264 298 minecraft:cobbled_deepslate
fill 472 264 299 472 267 299 minecraft:deepslate_tiles
setblock 472 264 303 minecraft:cobbled_deepslate
fill 472 264 304 472 267 304 minecraft:deepslate_tiles
setblock 472 264 308 minecraft:cobbled_deepslate
fill 472 264 309 472 267 309 minecraft:deepslate_tiles
setblock 472 264 313 minecraft:cobbled_deepslate
fill 472 264 314 472 267 314 minecraft:deepslate_tiles
setblock 473 264 287 minecraft:cobbled_deepslate
fill 473 264 288 473 266 288 minecraft:deepslate_tiles
setblock 473 264 292 minecraft:cobbled_deepslate
fill 473 264 293 473 267 293 minecraft:deepslate_tiles
setblock 473 264 297 minecraft:cobbled_deepslate
fill 473 264 298 474 266 298 minecraft:deepslate_tiles
setblock 473 264 302 minecraft:cobbled_deepslate
fill 473 264 303 473 266 303 minecraft:deepslate_tiles
setblock 473 264 307 minecraft:cobbled_deepslate
fill 473 264 308 473 266 308 minecraft:deepslate_tiles
fill 473 264 310 473 265 310 minecraft:deepslate_tiles
setblock 473 264 312 minecraft:cobbled_deepslate
fill 473 264 313 473 267 313 minecraft:deepslate_tiles
setblock 474 264 276 minecraft:cobbled_deepslate
setblock 474 264 291 minecraft:cobbled_deepslate
fill 474 264 292 474 267 292 minecraft:deepslate_tiles
setblock 474 264 295 minecraft:deepslate_tiles
setblock 474 264 296 minecraft:cobbled_deepslate
fill 474 264 297 474 267 297 minecraft:deepslate_tiles
fill 474 264 299 474 264 303 minecraft:black_concrete
setblock 474 264 312 minecraft:deepslate_tiles
setblock 474 264 316 minecraft:cobbled_deepslate
fill 475 264 276 475 267 276 minecraft:deepslate_tiles
fill 475 264 293 475 265 293 minecraft:deepslate_tiles
fill 475 264 299 477 265 300 minecraft:black_concrete
fill 475 264 302 477 265 303 minecraft:black_concrete
setblock 475 264 314 minecraft:deepslate_tiles
setblock 475 264 315 minecraft:cobbled_deepslate
fill 475 264 316 475 267 316 minecraft:deepslate_tiles
fill 476 264 301 477 265 301 minecraft:black_concrete
setblock 476 264 314 minecraft:cobbled_deepslate
fill 476 264 315 476 267 315 minecraft:deepslate_tiles
setblock 479 264 276 minecraft:cobbled_deepslate
setblock 479 264 316 minecraft:cobbled_deepslate
fill 480 264 316 481 266 316 minecraft:deepslate_tiles
fill 485 264 276 488 264 276 minecraft:deepslate_tiles
fill 486 264 316 488 264 316 minecraft:deepslate_tiles
setblock 488 264 277 minecraft:cobbled_deepslate
fill 488 264 315 489 264 315 minecraft:deepslate_tiles
setblock 489 264 276 minecraft:cobbled_deepslate
fill 489 264 277 489 267 277 minecraft:deepslate_tiles
setblock 489 264 316 minecraft:cobbled_deepslate
fill 490 264 276 490 267 276 minecraft:deepslate_tiles
setblock 490 264 315 minecraft:cobbled_deepslate
fill 490 264 316 490 267 316 minecraft:deepslate_tiles
setblock 491 264 278 minecraft:deepslate_tiles
setblock 491 264 314 minecraft:cobbled_deepslate
fill 491 264 315 494 264 315 minecraft:deepslate_tiles
setblock 491 264 317 minecraft:white_wool
setblock 492 264 275 minecraft:redstone_block
setblock 492 264 278 minecraft:cobbled_deepslate
fill 492 264 314 495 264 314 minecraft:deepslate_tiles
fill 493 264 275 493 264 276 minecraft:deepslate_tiles
setblock 493 264 277 minecraft:cobbled_deepslate
fill 493 264 278 493 267 278 minecraft:deepslate_tiles
fill 494 264 275 495 308 275 minecraft:deepslate_tiles
setblock 494 264 276 minecraft:cobbled_deepslate
fill 494 264 277 494 267 277 minecraft:deepslate_tiles
setblock 494 264 316 minecraft:cobbled_deepslate
fill 495 264 276 495 267 276 minecraft:deepslate_tiles
setblock 495 264 315 minecraft:cobbled_deepslate
fill 495 264 316 495 267 316 minecraft:deepslate_tiles
setblock 496 264 314 minecraft:cobbled_deepslate
fill 496 264 315 496 267 315 minecraft:deepslate_tiles
setblock 497 264 278 minecraft:cobbled_deepslate
fill 497 264 314 497 267 314 minecraft:deepslate_tiles
setblock 498 264 277 minecraft:cobbled_deepslate
setblock 499 264 276 minecraft:cobbled_deepslate
fill 499 264 277 499 267 277 minecraft:deepslate_tiles
setblock 499 264 316 minecraft:cobbled_deepslate
fill 500 264 276 500 267 276 minecraft:deepslate_tiles
schedule function dropper:buildpart/70_11 1t
