setblock 131 231 287 minecraft:magma_block
setblock 131 231 305 minecraft:magma_block
setblock 132 231 291 minecraft:basalt
fill 132 231 294 132 232 294 minecraft:basalt
setblock 132 231 300 minecraft:basalt
fill 94 232 275 94 233 276 minecraft:red_concrete
fill 94 232 277 94 233 278 minecraft:white_concrete
fill 94 232 279 94 233 279 minecraft:red_concrete
fill 94 232 281 94 233 282 minecraft:white_concrete
fill 94 232 283 94 233 284 minecraft:red_concrete
fill 94 232 285 94 233 286 minecraft:white_concrete
fill 94 232 287 94 233 287 minecraft:red_concrete
fill 94 232 289 94 233 290 minecraft:white_concrete
fill 94 232 291 94 233 292 minecraft:red_concrete
fill 94 232 293 94 233 294 minecraft:white_concrete
fill 94 232 295 94 233 295 minecraft:red_concrete
fill 94 232 297 94 233 298 minecraft:white_concrete
fill 94 232 299 94 233 300 minecraft:red_concrete
fill 94 232 301 94 233 302 minecraft:white_concrete
fill 94 232 303 94 233 303 minecraft:red_concrete
fill 94 232 305 94 233 306 minecraft:white_concrete
fill 94 232 307 94 233 308 minecraft:red_concrete
fill 94 232 309 94 233 310 minecraft:white_concrete
fill 94 232 311 94 233 311 minecraft:red_concrete
fill 94 232 313 94 233 314 minecraft:white_concrete
fill 94 232 315 94 233 316 minecraft:red_concrete
fill 95 232 275 95 233 275 minecraft:red_concrete
fill 95 232 286 95 232 306 minecraft:basalt
fill 95 232 307 95 272 307 minecraft:red_terracotta
fill 95 232 317 95 233 317 minecraft:red_concrete
fill 96 232 275 97 233 275 minecraft:white_concrete
fill 96 232 308 98 232 308 minecraft:basalt
fill 96 232 317 96 233 317 minecraft:white_concrete
setblock 97 232 309 minecraft:magma_block
fill 98 232 275 99 233 275 minecraft:red_concrete
setblock 98 232 282 minecraft:basalt
fill 98 232 295 99 239 295 minecraft:basalt
fill 98 232 298 99 238 298 minecraft:basalt
fill 98 232 309 98 232 310 minecraft:basalt
fill 98 232 317 99 233 317 minecraft:red_concrete
fill 99 232 290 99 238 290 minecraft:basalt
fill 99 232 294 99 240 294 minecraft:basalt
fill 99 232 296 99 240 297 minecraft:basalt
fill 99 232 302 99 238 302 minecraft:basalt
fill 99 232 310 104 232 310 minecraft:basalt
fill 99 232 312 99 232 313 minecraft:brown_terracotta
fill 100 232 275 100 233 275 minecraft:white_concrete
fill 100 232 280 104 232 280 minecraft:basalt
setblock 100 232 290 minecraft:magma_block
fill 100 232 291 100 240 292 minecraft:basalt
fill 100 232 300 100 240 301 minecraft:basalt
setblock 100 232 302 minecraft:magma_block
fill 100 232 313 100 232 314 minecraft:brown_terracotta
fill 100 232 317 101 233 317 minecraft:white_concrete
fill 101 232 288 101 239 289 minecraft:basalt
fill 101 232 303 101 239 303 minecraft:basalt
fill 101 232 313 101 272 313 minecraft:red_terracotta
fill 101 232 314 102 232 314 minecraft:brown_terracotta
fill 102 232 275 103 233 275 minecraft:red_concrete
fill 102 232 288 102 240 288 minecraft:basalt
fill 102 232 304 102 240 304 minecraft:basalt
setblock 102 232 313 minecraft:basalt
fill 102 232 317 103 233 317 minecraft:red_concrete
fill 103 232 287 103 240 287 minecraft:basalt
fill 103 232 305 103 240 305 minecraft:basalt
fill 104 232 275 105 233 275 minecraft:white_concrete
fill 104 232 286 104 240 286 minecraft:basalt
fill 104 232 306 104 240 306 minecraft:basalt
fill 104 232 317 104 233 317 minecraft:white_concrete
fill 105 232 285 105 240 285 minecraft:basalt
fill 105 232 307 105 240 307 minecraft:basalt
fill 106 232 275 107 233 275 minecraft:red_concrete
setblock 106 232 315 minecraft:magma_block
fill 106 232 317 107 233 317 minecraft:red_concrete
fill 107 232 283 107 239 284 minecraft:basalt
fill 107 232 308 108 240 308 minecraft:basalt
setblock 107 232 315 minecraft:basalt
fill 108 232 275 108 233 275 minecraft:white_concrete
fill 108 232 284 108 240 284 minecraft:basalt
fill 108 232 317 109 233 317 minecraft:white_concrete
fill 109 232 315 114 232 315 minecraft:basalt
fill 109 232 316 109 272 316 minecraft:red_terracotta
fill 110 232 275 111 233 275 minecraft:red_concrete
fill 110 232 276 114 232 276 minecraft:basalt
fill 110 232 282 110 238 283 minecraft:basalt
fill 110 232 309 114 238 309 minecraft:basalt
fill 110 232 316 111 232 316 minecraft:basalt
fill 110 232 317 111 233 317 minecraft:red_concrete
fill 111 232 283 111 240 283 minecraft:basalt
fill 112 232 275 113 233 275 minecraft:white_concrete
setblock 112 232 283 minecraft:magma_block
setblock 112 232 316 minecraft:magma_block
fill 112 232 317 112 233 317 minecraft:white_concrete
fill 113 232 283 114 240 283 minecraft:basalt
setblock 113 232 316 minecraft:basalt
fill 114 232 275 115 233 275 minecraft:red_concrete
fill 114 232 317 115 233 317 minecraft:red_concrete
fill 115 232 277 118 232 277 minecraft:basalt
setblock 115 232 309 minecraft:magma_block
setblock 115 232 315 minecraft:magma_block
fill 116 232 275 116 233 275 minecraft:white_concrete
fill 116 232 283 116 239 284 minecraft:basalt
fill 116 232 308 116 239 309 minecraft:basalt
setblock 116 232 315 minecraft:basalt
fill 116 232 317 117 233 317 minecraft:white_concrete
fill 117 232 284 117 240 284 minecraft:basalt
fill 117 232 308 117 240 308 minecraft:basalt
fill 117 232 316 118 239 316 minecraft:red_terracotta
fill 118 232 275 119 233 275 minecraft:red_concrete
fill 118 232 279 122 232 279 minecraft:basalt
setblock 118 232 284 minecraft:magma_block
setblock 118 232 308 minecraft:magma_block
fill 118 232 312 123 232 312 minecraft:basalt
fill 118 232 317 119 233 317 minecraft:red_concrete
fill 119 232 285 119 239 285 minecraft:basalt
fill 119 232 307 119 240 307 minecraft:basalt
fill 120 232 275 121 233 275 minecraft:white_concrete
fill 120 232 286 120 240 286 minecraft:basalt
fill 120 232 306 129 232 306 minecraft:basalt
fill 120 232 314 121 232 314 minecraft:basalt
fill 120 232 317 120 233 317 minecraft:white_concrete
fill 121 232 281 125 232 281 minecraft:basalt
fill 121 232 287 122 239 287 minecraft:basalt
fill 121 232 305 122 239 305 minecraft:basalt
fill 121 232 311 125 232 311 minecraft:basalt
fill 122 232 275 123 233 275 minecraft:red_concrete
fill 122 232 288 122 240 288 minecraft:basalt
fill 122 232 304 122 240 304 minecraft:basalt
fill 122 232 317 123 233 317 minecraft:red_concrete
fill 123 232 289 123 240 289 minecraft:basalt
fill 123 232 303 123 240 303 minecraft:basalt
fill 124 232 275 124 233 275 minecraft:white_concrete
fill 124 232 283 127 232 283 minecraft:basalt
setblock 124 232 291 minecraft:magma_block
fill 124 232 292 125 239 292 minecraft:basalt
setblock 124 232 300 minecraft:magma_block
fill 124 232 301 125 239 301 minecraft:basalt
fill 124 232 307 128 232 307 minecraft:basalt
fill 124 232 310 126 232 310 minecraft:basalt
setblock 124 232 312 minecraft:magma_block
fill 124 232 317 125 233 317 minecraft:white_concrete
fill 125 232 294 125 239 298 minecraft:basalt
fill 126 232 275 127 233 275 minecraft:red_concrete
setblock 126 232 282 minecraft:basalt
fill 126 232 285 128 232 285 minecraft:basalt
fill 126 232 317 127 233 317 minecraft:red_concrete
fill 128 232 275 129 233 275 minecraft:white_concrete
fill 128 232 317 128 233 317 minecraft:white_concrete
setblock 129 232 286 minecraft:basalt
fill 129 232 288 129 232 290 minecraft:basalt
fill 129 232 302 129 232 304 minecraft:basalt
fill 130 232 275 131 233 275 minecraft:red_concrete
setblock 130 232 288 minecraft:basalt
setblock 130 232 289 minecraft:magma_block
fill 130 232 290 131 232 290 minecraft:basalt
fill 130 232 293 131 233 293 minecraft:basalt
fill 130 232 296 132 232 296 minecraft:basalt
fill 130 232 299 131 233 299 minecraft:basalt
fill 130 232 302 130 232 303 minecraft:basalt
setblock 130 232 304 minecraft:magma_block
fill 130 232 317 131 233 317 minecraft:red_concrete
setblock 131 232 302 minecraft:basalt
fill 132 232 275 132 233 275 minecraft:white_concrete
setblock 132 232 297 minecraft:basalt
fill 132 232 317 133 233 317 minecraft:white_concrete
fill 134 232 275 135 233 275 minecraft:red_concrete
fill 134 232 317 135 233 317 minecraft:red_concrete
fill 136 232 276 136 233 276 minecraft:red_concrete
fill 136 232 277 136 233 278 minecraft:white_concrete
fill 136 232 279 136 233 279 minecraft:red_concrete
fill 136 232 281 136 233 282 minecraft:white_concrete
fill 136 232 283 136 233 284 minecraft:red_concrete
fill 136 232 285 136 233 286 minecraft:white_concrete
fill 136 232 287 136 233 287 minecraft:red_concrete
fill 136 232 289 136 233 290 minecraft:white_concrete
fill 136 232 291 136 233 292 minecraft:red_concrete
fill 136 232 293 136 233 294 minecraft:white_concrete
fill 136 232 295 136 233 295 minecraft:red_concrete
fill 136 232 297 136 233 298 minecraft:white_concrete
fill 136 232 299 136 233 300 minecraft:red_concrete
fill 136 232 301 136 233 302 minecraft:white_concrete
fill 136 232 303 136 233 303 minecraft:red_concrete
fill 136 232 305 136 233 306 minecraft:white_concrete
fill 136 232 307 136 233 308 minecraft:red_concrete
fill 136 232 309 136 233 310 minecraft:white_concrete
fill 136 232 311 136 233 311 minecraft:red_concrete
fill 136 232 313 136 233 314 minecraft:white_concrete
fill 136 232 315 136 233 316 minecraft:red_concrete
fill 136 232 317 136 233 317 minecraft:white_concrete
fill 95 233 287 95 233 305 minecraft:basalt
fill 95 233 306 95 272 306 minecraft:red_terracotta
fill 97 233 284 98 233 285 minecraft:basalt
fill 97 233 308 98 233 308 minecraft:basalt
fill 98 233 283 103 233 283 minecraft:basalt
setblock 98 233 309 minecraft:basalt
setblock 99 233 310 minecraft:magma_block
fill 100 233 281 101 233 281 minecraft:basalt
fill 100 233 290 101 239 290 minecraft:basalt
fill 100 233 293 100 240 299 minecraft:basalt
fill 100 233 302 101 239 302 minecraft:basalt
fill 100 233 310 101 233 311 minecraft:basalt
fill 100 233 312 101 272 312 minecraft:red_terracotta
fill 101 233 291 101 241 291 minecraft:basalt
fill 101 233 301 101 241 301 minecraft:basalt
fill 102 233 280 104 233 280 minecraft:basalt
fill 102 233 289 102 241 289 minecraft:basalt
setblock 102 233 303 minecraft:magma_block
fill 102 233 310 104 235 310 minecraft:basalt
setblock 102 233 312 minecraft:magma_block
fill 103 233 279 107 233 279 minecraft:basalt
fill 103 233 288 103 241 288 minecraft:basalt
fill 103 233 304 103 240 304 minecraft:basalt
fill 103 233 312 107 234 312 minecraft:basalt
fill 104 233 287 104 241 287 minecraft:basalt
fill 104 233 305 104 241 305 minecraft:basalt
fill 105 233 286 105 241 286 minecraft:basalt
fill 105 233 306 105 241 306 minecraft:basalt
fill 106 233 278 110 233 278 minecraft:basalt
fill 106 233 285 107 233 285 minecraft:basalt
fill 106 233 307 107 240 307 minecraft:basalt
fill 106 233 314 110 233 314 minecraft:basalt
fill 109 233 277 113 233 277 minecraft:basalt
fill 109 233 284 113 233 284 minecraft:basalt
fill 109 233 308 113 233 308 minecraft:basalt
fill 109 233 315 110 233 315 minecraft:basalt
fill 110 233 316 110 272 316 minecraft:red_terracotta
setblock 111 233 315 minecraft:magma_block
fill 112 233 276 113 257 276 minecraft:red_terracotta
fill 112 233 278 118 233 278 minecraft:basalt
fill 112 233 283 112 240 283 minecraft:basalt
fill 112 233 314 115 233 315 minecraft:basalt
setblock 114 233 284 minecraft:magma_block
setblock 114 233 308 minecraft:magma_block
setblock 115 233 277 minecraft:basalt
fill 115 233 284 115 240 284 minecraft:basalt
fill 115 233 308 115 239 309 minecraft:basalt
fill 115 233 313 121 233 313 minecraft:basalt
fill 116 233 314 118 233 314 minecraft:basalt
fill 117 233 285 118 240 285 minecraft:basalt
setblock 117 233 307 minecraft:magma_block
fill 118 233 279 119 234 279 minecraft:basalt
fill 118 233 284 118 239 284 minecraft:basalt
fill 118 233 307 118 239 308 minecraft:basalt
fill 118 233 312 122 233 312 minecraft:basalt
fill 119 233 286 119 241 286 minecraft:basalt
fill 119 233 306 128 233 306 minecraft:basalt
setblock 120 233 279 minecraft:magma_block
fill 120 233 287 120 241 287 minecraft:basalt
fill 120 233 305 120 241 305 minecraft:basalt
setblock 121 233 279 minecraft:basalt
fill 121 233 281 122 234 281 minecraft:basalt
fill 121 233 288 121 241 288 minecraft:basalt
fill 121 233 304 121 240 304 minecraft:basalt
fill 121 233 311 122 234 311 minecraft:basalt
fill 122 233 289 122 241 289 minecraft:basalt
fill 122 233 303 122 241 303 minecraft:basalt
setblock 123 233 281 minecraft:magma_block
fill 123 233 284 127 233 284 minecraft:basalt
setblock 123 233 290 minecraft:magma_block
fill 123 233 291 124 240 291 minecraft:basalt
fill 123 233 301 123 241 301 minecraft:basalt
setblock 123 233 302 minecraft:magma_block
fill 123 233 308 127 233 308 minecraft:basalt
setblock 123 233 311 minecraft:magma_block
setblock 124 233 281 minecraft:basalt
fill 124 233 283 125 234 283 minecraft:basalt
fill 124 233 287 129 233 287 minecraft:basalt
fill 124 233 293 124 240 300 minecraft:basalt
fill 124 233 307 127 233 307 minecraft:basalt
fill 124 233 310 124 233 311 minecraft:basalt
setblock 125 233 310 minecraft:basalt
setblock 126 233 283 minecraft:magma_block
fill 126 233 285 127 233 285 minecraft:basalt
setblock 126 233 309 minecraft:basalt
setblock 129 233 288 minecraft:magma_block
fill 129 233 289 129 234 292 minecraft:basalt
fill 129 233 300 130 233 302 minecraft:basalt
setblock 129 233 303 minecraft:magma_block
fill 129 233 304 129 233 305 minecraft:basalt
fill 130 233 290 130 233 292 minecraft:basalt
fill 130 233 296 131 233 296 minecraft:basalt
fill 94 234 275 94 235 276 minecraft:white_concrete
fill 94 234 277 94 235 278 minecraft:red_concrete
fill 94 234 279 94 235 280 minecraft:white_concrete
fill 94 234 281 94 235 282 minecraft:red_concrete
fill 94 234 283 94 235 284 minecraft:white_concrete
fill 94 234 285 94 235 286 minecraft:red_concrete
fill 94 234 287 94 235 288 minecraft:white_concrete
fill 94 234 289 94 235 290 minecraft:red_concrete
fill 94 234 291 94 235 292 minecraft:white_concrete
fill 94 234 293 94 235 294 minecraft:red_concrete
fill 94 234 295 94 235 296 minecraft:white_concrete
fill 94 234 297 94 235 298 minecraft:red_concrete
fill 94 234 299 94 235 300 minecraft:white_concrete
fill 94 234 301 94 235 302 minecraft:red_concrete
fill 94 234 303 94 235 304 minecraft:white_concrete
fill 94 234 305 94 235 306 minecraft:red_concrete
fill 94 234 307 94 235 308 minecraft:white_concrete
fill 94 234 309 94 235 310 minecraft:red_concrete
fill 94 234 311 94 235 312 minecraft:white_concrete
fill 94 234 313 94 235 314 minecraft:red_concrete
fill 94 234 315 94 235 316 minecraft:white_concrete
fill 95 234 275 95 235 275 minecraft:white_concrete
setblock 95 234 289 minecraft:magma_block
fill 95 234 290 95 234 291 minecraft:basalt
setblock 95 234 292 minecraft:magma_block
fill 95 234 293 95 235 300 minecraft:basalt
setblock 95 234 301 minecraft:magma_block
fill 95 234 302 95 234 303 minecraft:basalt
fill 95 234 317 95 235 317 minecraft:white_concrete
fill 96 234 275 97 235 275 minecraft:red_concrete
fill 96 234 305 98 234 305 minecraft:basalt
fill 96 234 317 97 235 317 minecraft:red_concrete
setblock 97 234 278 minecraft:light[level=15]
fill 97 234 306 98 234 306 minecraft:basalt
setblock 97 234 310 minecraft:light[level=15]
fill 98 234 275 99 235 275 minecraft:white_concrete
setblock 98 234 285 minecraft:magma_block
fill 98 234 307 100 234 307 minecraft:basalt
fill 98 234 317 99 235 317 minecraft:white_concrete
fill 99 234 283 103 234 283 minecraft:basalt
fill 100 234 275 101 235 275 minecraft:red_concrete
fill 100 234 311 101 272 311 minecraft:red_terracotta
fill 100 234 317 101 235 317 minecraft:red_concrete
fill 101 234 282 104 234 282 minecraft:basalt
fill 101 234 292 101 241 292 minecraft:basalt
setblock 101 234 293 minecraft:magma_block
setblock 101 234 299 minecraft:magma_block
fill 101 234 300 101 241 300 minecraft:basalt
setblock 101 234 310 minecraft:basalt
fill 102 234 275 103 235 275 minecraft:white_concrete
fill 102 234 290 102 241 290 minecraft:basalt
fill 102 234 302 102 241 303 minecraft:basalt
fill 102 234 312 102 272 312 minecraft:red_terracotta
fill 102 234 317 103 235 317 minecraft:white_concrete
setblock 103 234 280 minecraft:basalt
fill 103 234 289 103 242 289 minecraft:basalt
setblock 103 234 303 minecraft:basalt
fill 104 234 275 105 235 275 minecraft:red_concrete
setblock 104 234 280 minecraft:magma_block
fill 104 234 288 104 242 288 minecraft:basalt
setblock 104 234 304 minecraft:magma_block
fill 104 234 317 105 235 317 minecraft:red_concrete
setblock 105 234 278 minecraft:light[level=15]
fill 105 234 279 106 234 279 minecraft:basalt
fill 105 234 287 105 241 287 minecraft:basalt
setblock 105 234 294 minecraft:light[level=15]
setblock 105 234 302 minecraft:light[level=15]
fill 105 234 305 105 241 305 minecraft:basalt
fill 106 234 275 107 235 275 minecraft:white_concrete
fill 106 234 285 106 240 286 minecraft:basalt
fill 106 234 306 106 240 306 minecraft:basalt
fill 106 234 317 107 235 317 minecraft:white_concrete
setblock 107 234 279 minecraft:magma_block
setblock 107 234 285 minecraft:magma_block
fill 108 234 275 109 235 275 minecraft:red_concrete
fill 108 234 285 109 241 285 minecraft:basalt
fill 108 234 307 109 234 307 minecraft:basalt
fill 108 234 317 109 235 317 minecraft:red_concrete
fill 109 234 278 109 234 279 minecraft:basalt
fill 109 234 284 109 240 284 minecraft:basalt
fill 109 234 308 109 240 308 minecraft:basalt
setblock 109 234 314 minecraft:basalt
fill 110 234 275 111 235 275 minecraft:white_concrete
setblock 110 234 278 minecraft:magma_block
fill 110 234 279 115 234 279 minecraft:basalt
setblock 110 234 284 minecraft:magma_block
setblock 110 234 308 minecraft:magma_block
setblock 110 234 314 minecraft:magma_block
fill 110 234 317 111 235 317 minecraft:white_concrete
fill 111 234 284 114 241 284 minecraft:basalt
fill 111 234 308 114 241 308 minecraft:basalt
fill 112 234 275 113 235 275 minecraft:red_concrete
fill 112 234 278 115 234 278 minecraft:basalt
fill 112 234 314 115 234 314 minecraft:basalt
fill 112 234 317 113 235 317 minecraft:red_concrete
setblock 113 234 286 minecraft:light[level=15]
setblock 113 234 294 minecraft:light[level=15]
setblock 113 234 302 minecraft:light[level=15]
fill 114 234 275 115 235 275 minecraft:white_concrete
fill 114 234 317 115 235 317 minecraft:white_concrete
fill 115 234 280 121 234 280 minecraft:basalt
fill 115 234 285 115 240 285 minecraft:basalt
fill 115 234 307 117 241 307 minecraft:basalt
fill 115 234 313 119 234 313 minecraft:basalt
fill 116 234 275 117 235 275 minecraft:red_concrete
setblock 116 234 279 minecraft:magma_block
setblock 116 234 285 minecraft:magma_block
fill 116 234 317 117 235 317 minecraft:red_concrete
fill 118 234 275 119 235 275 minecraft:white_concrete
fill 118 234 286 118 241 286 minecraft:basalt
fill 118 234 306 127 234 306 minecraft:basalt
fill 118 234 312 121 234 312 minecraft:basalt
fill 118 234 317 119 235 317 minecraft:white_concrete
setblock 119 234 287 minecraft:magma_block
setblock 119 234 305 minecraft:magma_block
fill 120 234 275 121 235 275 minecraft:red_concrete
fill 120 234 282 123 234 282 minecraft:basalt
fill 120 234 288 120 241 288 minecraft:basalt
fill 120 234 304 120 242 304 minecraft:basalt
fill 120 234 317 121 235 317 minecraft:red_concrete
setblock 121 234 278 minecraft:light[level=15]
fill 121 234 289 121 242 289 minecraft:basalt
setblock 121 234 294 minecraft:light[level=15]
setblock 121 234 302 minecraft:light[level=15]
setblock 121 234 303 minecraft:basalt
fill 121 234 309 124 234 309 minecraft:basalt
fill 122 234 275 123 235 275 minecraft:white_concrete
fill 122 234 290 123 240 290 minecraft:basalt
fill 122 234 302 123 240 302 minecraft:basalt
fill 122 234 317 123 235 317 minecraft:white_concrete
fill 123 234 284 125 234 284 minecraft:basalt
fill 123 234 292 123 241 293 minecraft:basalt
fill 123 234 299 123 241 300 minecraft:basalt
fill 123 234 308 125 234 308 minecraft:basalt
fill 124 234 275 125 235 275 minecraft:red_concrete
fill 124 234 286 127 234 287 minecraft:basalt
fill 124 234 307 126 234 307 minecraft:basalt
fill 124 234 317 125 235 317 minecraft:red_concrete
setblock 125 234 309 minecraft:magma_block
fill 126 234 275 127 235 275 minecraft:white_concrete
setblock 126 234 285 minecraft:basalt
fill 126 234 304 127 234 305 minecraft:basalt
fill 126 234 317 127 235 317 minecraft:white_concrete
fill 128 234 275 129 235 275 minecraft:red_concrete
setblock 128 234 287 minecraft:magma_block
setblock 128 234 304 minecraft:basalt
setblock 128 234 305 minecraft:magma_block
fill 128 234 317 129 235 317 minecraft:red_concrete
setblock 129 234 278 minecraft:light[level=15]
setblock 129 234 286 minecraft:light[level=15]
fill 129 234 294 130 234 295 minecraft:basalt
fill 129 234 297 130 234 298 minecraft:basalt
fill 129 234 300 129 234 303 minecraft:basalt
setblock 129 234 310 minecraft:light[level=15]
fill 130 234 275 131 235 275 minecraft:white_concrete
setblock 130 234 293 minecraft:basalt
setblock 130 234 296 minecraft:basalt
setblock 130 234 299 minecraft:basalt
fill 130 234 317 131 235 317 minecraft:white_concrete
fill 132 234 275 133 235 275 minecraft:red_concrete
fill 132 234 317 133 235 317 minecraft:red_concrete
fill 134 234 275 135 235 275 minecraft:white_concrete
fill 134 234 317 135 235 317 minecraft:white_concrete
fill 136 234 276 136 235 276 minecraft:white_concrete
fill 136 234 277 136 235 278 minecraft:red_concrete
fill 136 234 279 136 235 280 minecraft:white_concrete
fill 136 234 281 136 235 282 minecraft:red_concrete
fill 136 234 283 136 235 284 minecraft:white_concrete
fill 136 234 285 136 235 286 minecraft:red_concrete
fill 136 234 287 136 235 288 minecraft:white_concrete
fill 136 234 289 136 235 290 minecraft:red_concrete
fill 136 234 291 136 235 292 minecraft:white_concrete
fill 136 234 293 136 235 294 minecraft:red_concrete
fill 136 234 295 136 235 296 minecraft:white_concrete
fill 136 234 297 136 235 298 minecraft:red_concrete
fill 136 234 299 136 235 300 minecraft:white_concrete
fill 136 234 301 136 235 302 minecraft:red_concrete
fill 136 234 303 136 235 304 minecraft:white_concrete
fill 136 234 305 136 235 306 minecraft:red_concrete
fill 136 234 307 136 235 308 minecraft:white_concrete
fill 136 234 309 136 235 310 minecraft:red_concrete
fill 136 234 311 136 235 312 minecraft:white_concrete
fill 136 234 313 136 235 314 minecraft:red_concrete
fill 136 234 315 136 235 316 minecraft:white_concrete
fill 136 234 317 136 235 317 minecraft:red_concrete
fill 95 235 290 95 272 291 minecraft:red_terracotta
setblock 95 235 292 minecraft:basalt
setblock 97 235 287 minecraft:magma_block
fill 97 235 288 98 235 288 minecraft:basalt
setblock 97 235 305 minecraft:magma_block
fill 98 235 286 98 235 287 minecraft:basalt
fill 98 235 305 98 235 306 minecraft:basalt
fill 99 235 286 99 236 286 minecraft:basalt
fill 99 235 307 100 235 307 minecraft:basalt
fill 100 235 284 101 235 284 minecraft:basalt
fill 100 235 308 101 235 308 minecraft:basalt
fill 101 235 283 103 235 283 minecraft:basalt
fill 101 235 293 101 242 299 minecraft:basalt
fill 101 235 309 103 235 309 minecraft:basalt
fill 101 235 310 101 272 310 minecraft:red_terracotta
fill 102 235 282 104 235 282 minecraft:basalt
fill 102 235 291 102 241 292 minecraft:basalt
fill 102 235 300 102 241 301 minecraft:basalt
fill 102 235 311 102 272 311 minecraft:red_terracotta
fill 103 235 281 106 235 281 minecraft:basalt
fill 103 235 290 103 242 290 minecraft:basalt
fill 103 235 302 103 242 302 minecraft:basalt
setblock 103 235 303 minecraft:magma_block
fill 103 235 311 106 235 311 minecraft:basalt
fill 104 235 304 104 242 304 minecraft:basalt
fill 105 235 312 107 235 312 minecraft:basalt
setblock 106 235 287 minecraft:magma_block
setblock 106 235 305 minecraft:magma_block
fill 107 235 285 107 241 286 minecraft:basalt
fill 107 235 306 108 235 306 minecraft:basalt
fill 108 235 286 108 241 286 minecraft:basalt
fill 108 235 307 108 241 307 minecraft:basalt
setblock 108 235 313 minecraft:basalt
fill 109 235 279 111 235 279 minecraft:basalt
setblock 109 235 307 minecraft:magma_block
setblock 109 235 313 minecraft:magma_block
fill 110 235 284 110 241 285 minecraft:basalt
fill 110 235 307 110 241 308 minecraft:basalt
fill 110 235 313 113 235 313 minecraft:basalt
fill 111 235 285 111 241 285 minecraft:basalt
fill 111 235 307 114 242 307 minecraft:basalt
setblock 112 235 279 minecraft:magma_block
setblock 112 235 285 minecraft:magma_block
fill 113 235 279 116 235 279 minecraft:basalt
fill 113 235 285 114 242 285 minecraft:basalt
fill 115 235 280 117 235 280 minecraft:basalt
fill 115 235 313 116 235 313 minecraft:basalt
fill 116 235 285 116 241 286 minecraft:basalt
fill 116 235 306 126 235 306 minecraft:basalt
fill 117 235 286 117 241 286 minecraft:basalt
setblock 118 235 280 minecraft:magma_block
fill 118 235 287 119 242 287 minecraft:basalt
fill 118 235 305 119 242 305 minecraft:basalt
fill 118 235 312 119 235 312 minecraft:basalt
setblock 119 235 280 minecraft:basalt
fill 120 235 282 122 235 282 minecraft:basalt
setblock 121 235 281 minecraft:basalt
fill 121 235 290 121 242 290 minecraft:basalt
fill 121 235 302 121 242 302 minecraft:basalt
setblock 121 235 303 minecraft:magma_block
fill 121 235 309 123 235 309 minecraft:basalt
setblock 121 235 311 minecraft:basalt
fill 122 235 291 122 242 292 minecraft:basalt
fill 122 235 300 122 242 301 minecraft:basalt
fill 123 235 284 123 236 284 minecraft:basalt
fill 123 235 294 123 235 298 minecraft:basalt
fill 123 235 308 123 236 308 minecraft:basalt
setblock 124 235 284 minecraft:magma_block
fill 124 235 286 126 235 287 minecraft:basalt
fill 124 235 307 125 235 307 minecraft:basalt
setblock 124 235 308 minecraft:magma_block
fill 126 235 304 126 236 305 minecraft:basalt
fill 127 235 287 127 235 291 minecraft:basalt
setblock 127 235 304 minecraft:magma_block
setblock 127 235 305 minecraft:basalt
fill 128 235 289 128 235 291 minecraft:basalt
setblock 129 235 292 minecraft:basalt
fill 129 235 294 129 235 295 minecraft:basalt
fill 129 235 297 129 235 298 minecraft:basalt
setblock 129 235 300 minecraft:basalt
fill 94 236 275 94 237 276 minecraft:red_concrete
fill 94 236 277 94 237 278 minecraft:white_concrete
fill 94 236 279 94 237 280 minecraft:red_concrete
fill 94 236 281 94 237 282 minecraft:white_concrete
fill 94 236 283 94 237 284 minecraft:red_concrete
fill 94 236 285 94 237 286 minecraft:white_concrete
fill 94 236 287 94 237 288 minecraft:red_concrete
fill 94 236 289 94 237 290 minecraft:white_concrete
fill 94 236 291 94 237 292 minecraft:red_concrete
fill 94 236 293 94 237 294 minecraft:white_concrete
fill 94 236 295 94 237 296 minecraft:red_concrete
fill 94 236 297 94 237 298 minecraft:white_concrete
fill 94 236 299 94 237 300 minecraft:red_concrete
fill 94 236 301 94 237 302 minecraft:white_concrete
fill 94 236 303 94 237 304 minecraft:red_concrete
fill 94 236 305 94 237 306 minecraft:white_concrete
fill 94 236 307 94 237 308 minecraft:red_concrete
fill 94 236 309 94 237 310 minecraft:white_concrete
fill 94 236 311 94 237 312 minecraft:red_concrete
fill 94 236 313 94 237 314 minecraft:white_concrete
fill 94 236 315 94 237 316 minecraft:red_concrete
fill 95 236 275 95 237 275 minecraft:red_concrete
fill 95 236 298 95 272 299 minecraft:red_terracotta
fill 95 236 317 95 237 317 minecraft:red_concrete
fill 96 236 275 97 237 275 minecraft:white_concrete
setblock 96 236 292 minecraft:magma_block
setblock 96 236 295 minecraft:magma_block
setblock 96 236 298 minecraft:magma_block
fill 96 236 317 97 237 317 minecraft:white_concrete
setblock 97 236 278 minecraft:light[level=12]
setblock 97 236 285 minecraft:light[level=12]
fill 97 236 290 97 236 292 minecraft:basalt
fill 97 236 302 97 236 303 minecraft:basalt
setblock 97 236 306 minecraft:light[level=12]
setblock 97 236 313 minecraft:light[level=12]
fill 98 236 275 99 237 275 minecraft:red_concrete
fill 98 236 287 98 236 288 minecraft:basalt
fill 98 236 304 98 236 305 minecraft:basalt
fill 98 236 317 99 237 317 minecraft:red_concrete
setblock 99 236 306 minecraft:magma_block
fill 100 236 275 101 237 275 minecraft:white_concrete
fill 100 236 306 100 236 307 minecraft:basalt
fill 100 236 317 101 237 317 minecraft:white_concrete
setblock 101 236 284 minecraft:basalt
setblock 101 236 308 minecraft:basalt
fill 102 236 275 103 237 275 minecraft:red_concrete
fill 102 236 283 103 236 283 minecraft:basalt
setblock 102 236 293 minecraft:magma_block
fill 102 236 294 102 241 294 minecraft:basalt
fill 102 236 298 102 242 298 minecraft:basalt
setblock 102 236 299 minecraft:magma_block
fill 102 236 309 103 236 309 minecraft:basalt
fill 102 236 317 103 237 317 minecraft:red_concrete
fill 103 236 282 104 236 282 minecraft:basalt
fill 103 236 291 103 242 291 minecraft:basalt
fill 103 236 301 103 242 301 minecraft:basalt
fill 103 236 303 104 242 303 minecraft:basalt
fill 103 236 310 104 236 310 minecraft:basalt
fill 104 236 275 105 237 275 minecraft:white_concrete
setblock 104 236 278 minecraft:light[level=12]
fill 104 236 289 104 242 289 minecraft:basalt
setblock 104 236 292 minecraft:light[level=12]
setblock 104 236 299 minecraft:light[level=12]
setblock 104 236 313 minecraft:light[level=12]
fill 104 236 317 105 237 317 minecraft:white_concrete
fill 105 236 281 106 236 281 minecraft:basalt
fill 105 236 288 105 242 288 minecraft:basalt
setblock 105 236 304 minecraft:magma_block
fill 105 236 311 106 236 311 minecraft:basalt
fill 106 236 275 107 237 275 minecraft:red_concrete
fill 106 236 287 107 236 287 minecraft:basalt
fill 106 236 305 107 236 305 minecraft:basalt
fill 106 236 317 107 237 317 minecraft:red_concrete
fill 107 236 306 107 242 306 minecraft:basalt
fill 108 236 275 109 237 275 minecraft:white_concrete
fill 108 236 280 113 236 280 minecraft:basalt
setblock 108 236 306 minecraft:magma_block
fill 108 236 311 110 237 311 minecraft:basalt
setblock 108 236 312 minecraft:magma_block
fill 108 236 317 109 237 317 minecraft:white_concrete
fill 109 236 286 110 236 286 minecraft:basalt
fill 109 236 306 109 242 307 minecraft:basalt
fill 109 236 312 110 236 312 minecraft:basalt
fill 110 236 275 111 237 275 minecraft:red_concrete
fill 110 236 306 110 242 306 minecraft:basalt
fill 110 236 317 111 237 317 minecraft:red_concrete
setblock 111 236 278 minecraft:light[level=12]
setblock 111 236 292 minecraft:light[level=12]
setblock 111 236 299 minecraft:light[level=12]
setblock 111 236 306 minecraft:light[level=12]
setblock 111 236 313 minecraft:light[level=12]
fill 112 236 275 113 237 275 minecraft:white_concrete
fill 112 236 285 112 242 285 minecraft:basalt
fill 112 236 317 113 237 317 minecraft:white_concrete
fill 114 236 275 115 237 275 minecraft:red_concrete
setblock 114 236 280 minecraft:magma_block
fill 114 236 281 114 237 281 minecraft:basalt
setblock 114 236 286 minecraft:magma_block
fill 114 236 306 125 236 306 minecraft:basalt
fill 114 236 311 114 236 312 minecraft:basalt
fill 114 236 317 115 237 317 minecraft:red_concrete
fill 115 236 280 116 236 280 minecraft:basalt
fill 115 236 286 115 242 286 minecraft:basalt
fill 116 236 275 117 237 275 minecraft:white_concrete
setblock 116 236 312 minecraft:basalt
fill 116 236 317 117 237 317 minecraft:white_concrete
fill 117 236 287 117 242 287 minecraft:basalt
fill 117 236 305 117 242 305 minecraft:basalt
fill 118 236 275 119 237 275 minecraft:red_concrete
setblock 118 236 278 minecraft:light[level=12]
setblock 118 236 292 minecraft:light[level=12]
setblock 118 236 299 minecraft:light[level=12]
setblock 118 236 313 minecraft:light[level=12]
fill 118 236 317 119 237 317 minecraft:red_concrete
fill 119 236 288 119 242 288 minecraft:basalt
fill 119 236 304 119 242 304 minecraft:basalt
fill 120 236 275 121 237 275 minecraft:white_concrete
fill 120 236 282 121 236 282 minecraft:basalt
fill 120 236 289 120 242 289 minecraft:basalt
fill 120 236 303 121 241 303 minecraft:basalt
fill 120 236 310 121 236 310 minecraft:basalt
fill 120 236 317 121 237 317 minecraft:white_concrete
fill 121 236 291 121 242 291 minecraft:basalt
fill 121 236 301 121 242 301 minecraft:basalt
fill 121 236 309 122 236 309 minecraft:basalt
fill 122 236 275 123 237 275 minecraft:red_concrete
fill 122 236 293 122 236 294 minecraft:basalt
fill 122 236 298 122 242 299 minecraft:basalt
fill 122 236 317 123 237 317 minecraft:red_concrete
fill 123 236 294 123 242 294 minecraft:basalt
setblock 123 236 295 minecraft:magma_block
fill 123 236 296 123 241 298 minecraft:basalt
fill 124 236 275 125 237 275 minecraft:white_concrete
fill 124 236 285 124 236 287 minecraft:basalt
setblock 124 236 307 minecraft:basalt
fill 124 236 317 125 237 317 minecraft:white_concrete
setblock 125 236 278 minecraft:light[level=12]
setblock 125 236 285 minecraft:light[level=12]
fill 125 236 286 125 236 288 minecraft:basalt
setblock 125 236 313 minecraft:light[level=12]
fill 126 236 275 127 237 275 minecraft:red_concrete
setblock 126 236 287 minecraft:basalt
setblock 126 236 288 minecraft:magma_block
fill 126 236 317 127 237 317 minecraft:red_concrete
fill 127 236 289 127 236 291 minecraft:basalt
fill 127 236 301 127 236 303 minecraft:basalt
fill 128 236 275 129 237 275 minecraft:white_concrete
fill 128 236 317 129 237 317 minecraft:white_concrete
fill 130 236 275 131 237 275 minecraft:red_concrete
fill 130 236 317 131 237 317 minecraft:red_concrete
fill 132 236 275 133 237 275 minecraft:white_concrete
setblock 132 236 278 minecraft:light[level=12]
setblock 132 236 285 minecraft:light[level=12]
setblock 132 236 292 minecraft:light[level=12]
setblock 132 236 299 minecraft:light[level=12]
setblock 132 236 306 minecraft:light[level=12]
setblock 132 236 313 minecraft:light[level=12]
fill 132 236 317 133 237 317 minecraft:white_concrete
fill 134 236 275 135 237 275 minecraft:red_concrete
fill 134 236 317 135 237 317 minecraft:red_concrete
fill 136 236 276 136 237 276 minecraft:red_concrete
fill 136 236 277 136 237 278 minecraft:white_concrete
fill 136 236 279 136 237 280 minecraft:red_concrete
fill 136 236 281 136 237 282 minecraft:white_concrete
fill 136 236 283 136 237 284 minecraft:red_concrete
fill 136 236 285 136 237 286 minecraft:white_concrete
fill 136 236 287 136 237 288 minecraft:red_concrete
fill 136 236 289 136 237 290 minecraft:white_concrete
fill 136 236 291 136 237 292 minecraft:red_concrete
fill 136 236 293 136 237 294 minecraft:white_concrete
fill 136 236 295 136 237 296 minecraft:red_concrete
fill 136 236 297 136 237 298 minecraft:white_concrete
fill 136 236 299 136 237 300 minecraft:red_concrete
fill 136 236 301 136 237 302 minecraft:white_concrete
fill 136 236 303 136 237 304 minecraft:red_concrete
fill 136 236 305 136 237 306 minecraft:white_concrete
fill 136 236 307 136 237 308 minecraft:red_concrete
fill 136 236 309 136 237 310 minecraft:white_concrete
fill 136 236 311 136 237 312 minecraft:red_concrete
fill 136 236 313 136 237 314 minecraft:white_concrete
fill 136 236 315 136 237 316 minecraft:red_concrete
fill 136 236 317 136 237 317 minecraft:white_concrete
fill 97 237 291 98 237 292 minecraft:basalt
setblock 98 237 290 minecraft:magma_block
fill 98 237 300 98 238 301 minecraft:basalt
setblock 98 237 302 minecraft:magma_block
fill 100 237 306 101 237 306 minecraft:basalt
setblock 101 237 307 minecraft:magma_block
fill 102 237 293 103 237 293 minecraft:basalt
fill 102 237 295 102 241 297 minecraft:basalt
fill 102 237 299 103 237 299 minecraft:basalt
setblock 103 237 283 minecraft:basalt
fill 103 237 292 103 242 292 minecraft:basalt
fill 103 237 300 103 242 300 minecraft:basalt
setblock 103 237 309 minecraft:basalt
fill 104 237 290 104 242 290 minecraft:basalt
fill 104 237 302 104 242 302 minecraft:basalt
setblock 104 237 309 minecraft:magma_block
fill 105 237 289 105 242 289 minecraft:basalt
fill 105 237 303 105 242 304 minecraft:basalt
fill 105 237 309 105 238 309 minecraft:basalt
fill 106 237 287 106 242 288 minecraft:basalt
fill 106 237 304 106 242 305 minecraft:basalt
setblock 107 237 281 minecraft:magma_block
fill 107 237 282 107 238 282 minecraft:basalt
setblock 107 237 287 minecraft:magma_block
fill 107 237 292 107 238 292 minecraft:yellow_wool
setblock 107 237 305 minecraft:magma_block
fill 107 237 310 107 238 310 minecraft:basalt
setblock 107 237 311 minecraft:magma_block
fill 108 237 287 109 242 287 minecraft:basalt
fill 108 237 305 108 242 306 minecraft:basalt
fill 109 237 286 109 242 286 minecraft:basalt
fill 109 237 305 109 242 305 minecraft:basalt
setblock 110 237 286 minecraft:magma_block
fill 111 237 286 114 242 286 minecraft:basalt
fill 111 237 306 112 241 306 minecraft:basalt
setblock 113 237 306 minecraft:magma_block
fill 113 237 311 115 237 311 minecraft:basalt
fill 114 237 306 124 237 306 minecraft:basalt
fill 115 237 287 115 242 287 minecraft:basalt
fill 115 237 305 115 242 305 minecraft:basalt
setblock 116 237 281 minecraft:magma_block
fill 116 237 282 116 238 282 minecraft:basalt
setblock 116 237 287 minecraft:magma_block
setblock 116 237 305 minecraft:magma_block
fill 116 237 310 116 238 310 minecraft:basalt
setblock 116 237 311 minecraft:magma_block
setblock 117 237 281 minecraft:basalt
setblock 117 237 311 minecraft:basalt
fill 118 237 288 118 242 288 minecraft:basalt
fill 118 237 295 119 240 297 minecraft:red_terracotta
fill 118 237 304 118 242 304 minecraft:basalt
setblock 119 237 289 minecraft:magma_block
fill 119 237 303 119 242 303 minecraft:basalt
fill 119 237 309 119 238 309 minecraft:basalt
setblock 119 237 310 minecraft:magma_block
fill 120 237 290 120 242 290 minecraft:basalt
fill 120 237 302 120 242 302 minecraft:basalt
setblock 121 237 283 minecraft:basalt
fill 121 237 292 121 237 293 minecraft:basalt
fill 121 237 299 121 237 300 minecraft:basalt
setblock 121 237 309 minecraft:basalt
fill 122 237 293 122 242 293 minecraft:basalt
setblock 122 237 294 minecraft:magma_block
fill 122 237 295 122 242 296 minecraft:basalt
setblock 122 237 297 minecraft:magma_block
fill 122 237 312 122 240 312 minecraft:iron_block
fill 123 237 295 123 242 295 minecraft:basalt
fill 124 237 286 124 237 287 minecraft:basalt
setblock 124 237 305 minecraft:basalt
setblock 125 237 287 minecraft:magma_block
setblock 125 237 288 minecraft:basalt
setblock 125 237 305 minecraft:magma_block
fill 127 237 291 127 237 293 minecraft:basalt
fill 127 237 298 127 237 301 minecraft:basalt
fill 94 238 275 94 239 276 minecraft:white_concrete
fill 94 238 277 94 239 278 minecraft:red_concrete
fill 94 238 279 94 239 280 minecraft:white_concrete
fill 94 238 281 94 239 282 minecraft:red_concrete
fill 94 238 283 94 239 284 minecraft:white_concrete
fill 94 238 285 94 239 286 minecraft:red_concrete
fill 94 238 287 94 239 288 minecraft:white_concrete
fill 94 238 289 94 239 290 minecraft:red_concrete
fill 94 238 291 94 239 292 minecraft:white_concrete
fill 94 238 293 94 239 294 minecraft:red_concrete
fill 94 238 295 94 239 296 minecraft:white_concrete
fill 94 238 297 94 239 298 minecraft:red_concrete
fill 94 238 299 94 239 300 minecraft:white_concrete
fill 94 238 301 94 239 302 minecraft:red_concrete
fill 94 238 303 94 239 304 minecraft:white_concrete
fill 94 238 305 94 239 306 minecraft:red_concrete
fill 94 238 307 94 239 308 minecraft:white_concrete
fill 94 238 309 94 239 310 minecraft:red_concrete
fill 94 238 311 94 239 312 minecraft:white_concrete
fill 94 238 313 94 239 314 minecraft:red_concrete
fill 94 238 315 94 239 316 minecraft:white_concrete
fill 95 238 275 95 239 275 minecraft:white_concrete
fill 95 238 276 95 239 281 minecraft:red_terracotta
fill 95 238 284 96 238 289 minecraft:red_terracotta
fill 95 238 292 96 238 297 minecraft:red_terracotta
fill 95 238 300 96 238 305 minecraft:red_terracotta
fill 95 238 308 96 238 313 minecraft:red_terracotta
fill 95 238 316 100 239 316 minecraft:red_terracotta
fill 95 238 317 95 239 317 minecraft:white_concrete
fill 96 238 275 97 239 275 minecraft:red_concrete
fill 96 238 277 96 238 283 minecraft:red_terracotta
fill 96 238 290 96 238 291 minecraft:red_terracotta
fill 96 238 298 96 238 299 minecraft:red_terracotta
fill 96 238 306 96 238 307 minecraft:red_terracotta
fill 96 238 314 96 238 315 minecraft:red_terracotta
fill 96 238 317 97 239 317 minecraft:red_concrete
fill 97 238 277 134 238 277 minecraft:red_terracotta
fill 97 238 315 135 238 315 minecraft:red_terracotta
fill 98 238 275 99 239 275 minecraft:white_concrete
fill 98 238 276 103 239 276 minecraft:red_terracotta
fill 98 238 291 98 238 292 minecraft:basalt
fill 98 238 317 99 239 317 minecraft:white_concrete
fill 100 238 275 101 239 275 minecraft:red_concrete
setblock 100 238 288 minecraft:magma_block
fill 100 238 289 100 239 289 minecraft:basalt
fill 100 238 317 101 239 317 minecraft:red_concrete
setblock 101 238 306 minecraft:basalt
fill 102 238 275 103 239 275 minecraft:white_concrete
fill 102 238 293 102 242 293 minecraft:basalt
fill 102 238 299 102 242 299 minecraft:basalt
fill 102 238 317 103 239 317 minecraft:white_concrete
setblock 103 238 285 minecraft:basalt
setblock 103 238 293 minecraft:magma_block
fill 103 238 294 103 242 295 minecraft:basalt
setblock 103 238 296 minecraft:magma_block
fill 103 238 297 103 242 298 minecraft:basalt
setblock 103 238 299 minecraft:magma_block
setblock 103 238 307 minecraft:basalt
fill 103 238 316 108 239 316 minecraft:red_terracotta
fill 104 238 275 105 239 275 minecraft:red_concrete
fill 104 238 291 104 242 292 minecraft:basalt
fill 104 238 300 104 242 301 minecraft:basalt
fill 104 238 317 105 239 317 minecraft:red_concrete
fill 105 238 290 105 241 290 minecraft:basalt
fill 105 238 302 105 241 302 minecraft:basalt
fill 106 238 275 107 239 275 minecraft:white_concrete
fill 106 238 276 111 239 276 minecraft:red_terracotta
setblock 106 238 283 minecraft:magma_block
fill 106 238 284 106 239 284 minecraft:basalt
setblock 106 238 289 minecraft:magma_block
fill 106 238 303 106 242 303 minecraft:basalt
setblock 106 238 309 minecraft:basalt
fill 106 238 317 107 239 317 minecraft:white_concrete
fill 107 238 287 107 242 288 minecraft:basalt
fill 107 238 304 107 242 305 minecraft:basalt
fill 108 238 275 109 239 275 minecraft:red_concrete
fill 108 238 288 108 242 288 minecraft:basalt
fill 108 238 304 108 241 304 minecraft:basalt
fill 108 238 317 109 239 317 minecraft:red_concrete
setblock 109 238 282 minecraft:magma_block
fill 110 238 275 111 239 275 minecraft:white_concrete
fill 110 238 286 110 242 287 minecraft:basalt
fill 110 238 305 111 242 305 minecraft:basalt
fill 110 238 317 111 239 317 minecraft:white_concrete
fill 111 238 287 111 242 287 minecraft:basalt
fill 111 238 316 116 239 316 minecraft:red_terracotta
fill 112 238 275 113 239 275 minecraft:red_concrete
setblock 112 238 287 minecraft:magma_block
setblock 112 238 305 minecraft:magma_block
fill 112 238 310 114 238 310 minecraft:basalt
fill 112 238 317 113 239 317 minecraft:red_concrete
fill 113 238 287 114 241 287 minecraft:basalt
fill 113 238 305 114 241 306 minecraft:basalt
fill 114 238 275 115 239 275 minecraft:white_concrete
fill 114 238 276 119 239 276 minecraft:red_terracotta
fill 114 238 317 115 239 317 minecraft:white_concrete
fill 115 238 306 123 238 306 minecraft:basalt
setblock 115 238 310 minecraft:magma_block
fill 116 238 275 117 239 275 minecraft:red_concrete
fill 116 238 287 116 242 288 minecraft:basalt
fill 116 238 304 116 242 305 minecraft:basalt
fill 116 238 317 117 239 317 minecraft:red_concrete
fill 117 238 288 117 242 288 minecraft:basalt
fill 117 238 304 117 241 304 minecraft:basalt
fill 117 238 309 117 239 309 minecraft:basalt
fill 118 238 275 119 239 275 minecraft:white_concrete
fill 118 238 289 119 242 289 minecraft:basalt
fill 118 238 294 119 239 294 minecraft:brown_terracotta
setblock 118 238 303 minecraft:magma_block
setblock 118 238 309 minecraft:magma_block
fill 118 238 317 119 239 317 minecraft:white_concrete
fill 119 238 283 119 238 284 minecraft:basalt
fill 119 238 290 119 242 290 minecraft:basalt
fill 119 238 302 119 242 302 minecraft:basalt
fill 119 238 308 120 238 308 minecraft:basalt
fill 119 238 316 124 239 316 minecraft:red_terracotta
fill 120 238 275 121 239 275 minecraft:red_concrete
setblock 120 238 284 minecraft:basalt
fill 120 238 291 120 238 292 minecraft:basalt
fill 120 238 295 120 239 297 minecraft:brown_terracotta
fill 120 238 300 120 241 301 minecraft:basalt
fill 120 238 317 121 239 317 minecraft:red_concrete
fill 121 238 292 121 242 292 minecraft:basalt
setblock 121 238 293 minecraft:magma_block
fill 121 238 294 121 242 295 minecraft:basalt
setblock 121 238 296 minecraft:magma_block
fill 121 238 297 121 242 298 minecraft:basalt
setblock 121 238 299 minecraft:magma_block
fill 121 238 300 121 242 300 minecraft:basalt
fill 122 238 275 123 239 275 minecraft:white_concrete
fill 122 238 276 127 239 276 minecraft:red_terracotta
fill 122 238 294 122 242 294 minecraft:basalt
fill 122 238 297 122 242 297 minecraft:basalt
fill 122 238 317 123 239 317 minecraft:white_concrete
fill 124 238 275 125 239 275 minecraft:red_concrete
fill 124 238 303 124 239 303 minecraft:basalt
setblock 124 238 304 minecraft:magma_block
fill 124 238 317 125 239 317 minecraft:red_concrete
fill 126 238 275 127 239 275 minecraft:white_concrete
fill 126 238 317 127 239 317 minecraft:white_concrete
fill 127 238 316 132 239 316 minecraft:red_terracotta
fill 128 238 275 129 239 275 minecraft:red_concrete
fill 128 238 317 129 239 317 minecraft:red_concrete
fill 130 238 275 131 239 275 minecraft:white_concrete
fill 130 238 276 135 239 276 minecraft:red_terracotta
fill 130 238 317 131 239 317 minecraft:white_concrete
fill 132 238 275 133 239 275 minecraft:red_concrete
fill 132 238 317 133 239 317 minecraft:red_concrete
fill 134 238 275 135 239 275 minecraft:white_concrete
fill 134 238 278 134 238 314 minecraft:red_terracotta
fill 134 238 317 135 239 317 minecraft:white_concrete
fill 135 238 279 135 239 284 minecraft:red_terracotta
fill 135 238 287 135 239 292 minecraft:red_terracotta
fill 135 238 295 135 239 300 minecraft:red_terracotta
fill 135 238 303 135 239 308 minecraft:red_terracotta
fill 135 238 311 135 239 314 minecraft:red_terracotta
fill 135 238 316 135 239 316 minecraft:red_terracotta
fill 136 238 276 136 239 276 minecraft:white_concrete
fill 136 238 277 136 239 278 minecraft:red_concrete
fill 136 238 279 136 239 280 minecraft:white_concrete
fill 136 238 281 136 239 282 minecraft:red_concrete
fill 136 238 283 136 239 284 minecraft:white_concrete
fill 136 238 285 136 239 286 minecraft:red_concrete
fill 136 238 287 136 239 288 minecraft:white_concrete
fill 136 238 289 136 239 290 minecraft:red_concrete
fill 136 238 291 136 239 292 minecraft:white_concrete
fill 136 238 293 136 239 294 minecraft:red_concrete
fill 136 238 295 136 239 296 minecraft:white_concrete
fill 136 238 297 136 239 298 minecraft:red_concrete
fill 136 238 299 136 239 300 minecraft:white_concrete
fill 136 238 301 136 239 302 minecraft:red_concrete
fill 136 238 303 136 239 304 minecraft:white_concrete
fill 136 238 305 136 239 306 minecraft:red_concrete
fill 136 238 307 136 239 308 minecraft:white_concrete
fill 136 238 309 136 239 310 minecraft:red_concrete
fill 136 238 311 136 239 312 minecraft:white_concrete
fill 136 238 313 136 239 314 minecraft:red_concrete
fill 136 238 315 136 239 316 minecraft:white_concrete
fill 136 238 317 136 239 317 minecraft:red_concrete
fill 95 239 284 95 239 289 minecraft:red_terracotta
fill 95 239 292 95 239 297 minecraft:red_terracotta
fill 95 239 300 95 239 305 minecraft:red_terracotta
fill 95 239 308 95 239 313 minecraft:red_terracotta
setblock 99 239 292 minecraft:basalt
setblock 99 239 293 minecraft:magma_block
fill 99 239 298 99 240 298 minecraft:basalt
setblock 99 239 299 minecraft:magma_block
setblock 99 239 300 minecraft:basalt
setblock 100 239 303 minecraft:basalt
setblock 102 239 287 minecraft:basalt
fill 103 239 293 104 242 293 minecraft:basalt
fill 103 239 296 103 242 296 minecraft:basalt
fill 103 239 299 104 242 299 minecraft:basalt
fill 104 239 294 104 242 294 minecraft:basalt
fill 104 239 298 104 242 298 minecraft:basalt
setblock 105 239 284 minecraft:basalt
setblock 105 239 291 minecraft:magma_block
fill 105 239 301 105 242 301 minecraft:basalt
setblock 105 239 308 minecraft:basalt
fill 106 239 289 106 242 290 minecraft:basalt
fill 106 239 302 106 242 302 minecraft:basalt
fill 107 239 289 107 242 289 minecraft:basalt
fill 107 239 303 107 242 303 minecraft:basalt
fill 109 239 288 110 239 288 minecraft:basalt
fill 109 239 304 110 242 304 minecraft:basalt
fill 110 239 283 110 240 283 minecraft:basalt
fill 110 239 309 113 239 309 minecraft:basalt
fill 111 239 282 113 239 282 minecraft:basalt
setblock 111 239 310 minecraft:magma_block
fill 112 239 287 112 242 287 minecraft:basalt
fill 112 239 305 112 242 305 minecraft:basalt
fill 112 239 310 113 239 310 minecraft:basalt
setblock 114 239 288 minecraft:magma_block
fill 114 239 304 115 242 304 minecraft:basalt
setblock 114 239 309 minecraft:magma_block
fill 115 239 288 115 242 288 minecraft:basalt
fill 115 239 306 121 239 306 minecraft:basalt
setblock 117 239 283 minecraft:basalt
fill 117 239 289 117 241 289 minecraft:basalt
setblock 117 239 294 minecraft:brown_terracotta
fill 117 239 303 118 242 303 minecraft:basalt
fill 118 239 290 118 242 290 minecraft:basalt
fill 118 239 298 119 239 298 minecraft:brown_terracotta
fill 118 239 302 118 242 302 minecraft:basalt
setblock 119 239 284 minecraft:basalt
fill 119 239 291 120 241 291 minecraft:basalt
fill 119 239 301 119 242 301 minecraft:basalt
setblock 119 239 308 minecraft:basalt
setblock 120 239 292 minecraft:magma_block
fill 120 239 293 120 241 294 minecraft:basalt
setblock 120 239 298 minecraft:magma_block
fill 120 239 299 121 242 299 minecraft:basalt
setblock 120 239 307 minecraft:magma_block
fill 121 239 293 121 242 293 minecraft:basalt
fill 121 239 296 121 242 296 minecraft:basalt
setblock 123 239 288 minecraft:magma_block
setblock 124 239 289 minecraft:basalt
setblock 124 239 302 minecraft:basalt
setblock 125 239 291 minecraft:basalt
setblock 125 239 293 minecraft:basalt
setblock 126 239 295 minecraft:basalt
setblock 126 239 296 minecraft:magma_block
setblock 126 239 297 minecraft:basalt
setblock 135 239 315 minecraft:red_terracotta
fill 94 240 275 94 241 276 minecraft:red_concrete
fill 94 240 277 94 241 278 minecraft:white_concrete
fill 94 240 279 94 241 280 minecraft:red_concrete
fill 94 240 281 94 241 282 minecraft:white_concrete
fill 94 240 283 94 241 284 minecraft:red_concrete
fill 94 240 285 94 241 286 minecraft:white_concrete
fill 94 240 287 94 241 288 minecraft:red_concrete
fill 94 240 289 94 241 290 minecraft:white_concrete
fill 94 240 291 94 241 292 minecraft:red_concrete
fill 94 240 293 94 241 294 minecraft:white_concrete
fill 94 240 295 94 241 296 minecraft:red_concrete
fill 94 240 297 94 241 298 minecraft:white_concrete
fill 94 240 299 94 241 300 minecraft:red_concrete
fill 94 240 301 94 241 302 minecraft:white_concrete
fill 94 240 303 94 241 304 minecraft:red_concrete
fill 94 240 305 94 241 306 minecraft:white_concrete
fill 94 240 307 94 241 308 minecraft:red_concrete
fill 94 240 309 94 241 310 minecraft:white_concrete
fill 94 240 311 94 241 312 minecraft:red_concrete
fill 94 240 313 94 241 314 minecraft:white_concrete
fill 94 240 315 94 241 316 minecraft:red_concrete
fill 95 240 275 95 241 275 minecraft:red_concrete
fill 95 240 317 95 241 317 minecraft:red_concrete
fill 96 240 275 97 241 275 minecraft:white_concrete
fill 96 240 317 97 241 317 minecraft:white_concrete
fill 98 240 275 99 241 275 minecraft:red_concrete
fill 98 240 317 99 241 317 minecraft:red_concrete
setblock 99 240 295 minecraft:basalt
fill 100 240 275 101 241 275 minecraft:white_concrete
fill 100 240 317 101 241 317 minecraft:white_concrete
fill 101 240 289 101 240 290 minecraft:basalt
setblock 101 240 302 minecraft:basalt
setblock 101 240 303 minecraft:magma_block
fill 102 240 275 103 241 275 minecraft:red_concrete
fill 102 240 317 103 241 317 minecraft:red_concrete
fill 104 240 275 105 241 275 minecraft:white_concrete
fill 104 240 295 104 242 295 minecraft:basalt
setblock 104 240 296 minecraft:magma_block
fill 104 240 297 104 242 297 minecraft:basalt
fill 104 240 317 105 241 317 minecraft:white_concrete
fill 105 240 291 105 241 293 minecraft:basalt
fill 105 240 299 105 241 300 minecraft:basalt
fill 106 240 275 107 241 275 minecraft:red_concrete
fill 106 240 291 106 242 291 minecraft:basalt
fill 106 240 301 106 242 301 minecraft:basalt
fill 106 240 317 107 241 317 minecraft:red_concrete
setblock 107 240 284 minecraft:basalt
fill 107 240 290 107 242 290 minecraft:basalt
fill 107 240 302 107 242 302 minecraft:basalt
fill 108 240 275 109 241 275 minecraft:white_concrete
fill 108 240 289 109 241 289 minecraft:basalt
fill 108 240 303 109 242 303 minecraft:basalt
fill 108 240 317 109 241 317 minecraft:white_concrete
fill 109 240 288 109 242 288 minecraft:basalt
fill 110 240 275 111 241 275 minecraft:red_concrete
setblock 110 240 288 minecraft:magma_block
setblock 110 240 309 minecraft:magma_block
fill 110 240 317 111 241 317 minecraft:red_concrete
fill 111 240 288 114 241 288 minecraft:basalt
fill 111 240 304 113 242 304 minecraft:basalt
fill 111 240 309 114 240 309 minecraft:basalt
fill 112 240 275 113 241 275 minecraft:white_concrete
fill 112 240 317 113 241 317 minecraft:white_concrete
fill 113 240 312 114 241 312 minecraft:brown_terracotta
fill 114 240 275 115 241 275 minecraft:red_concrete
fill 114 240 317 115 241 317 minecraft:red_concrete
fill 115 240 289 115 242 289 minecraft:basalt
fill 115 240 303 116 240 303 minecraft:basalt
fill 115 240 306 120 240 306 minecraft:basalt
fill 115 240 308 116 240 308 minecraft:basalt
setblock 115 240 315 minecraft:iron_block
fill 116 240 275 117 241 275 minecraft:white_concrete
setblock 116 240 284 minecraft:basalt
setblock 116 240 289 minecraft:magma_block
setblock 116 240 314 minecraft:iron_block
fill 116 240 315 118 240 315 minecraft:black_concrete
setblock 116 240 316 minecraft:iron_block
fill 116 240 317 116 241 317 minecraft:white_concrete
fill 117 240 290 117 242 290 minecraft:basalt
fill 117 240 302 117 242 302 minecraft:basalt
setblock 117 240 313 minecraft:iron_block
setblock 117 240 314 minecraft:black_concrete
setblock 117 240 316 minecraft:black_concrete
setblock 117 240 317 minecraft:iron_block
fill 118 240 275 119 241 275 minecraft:red_concrete
fill 118 240 291 118 242 291 minecraft:basalt
fill 118 240 301 118 242 301 minecraft:basalt
setblock 118 240 307 minecraft:basalt
setblock 118 240 314 minecraft:iron_block
setblock 118 240 316 minecraft:iron_block
fill 118 240 317 119 241 317 minecraft:red_concrete
setblock 119 240 285 minecraft:magma_block
fill 119 240 292 119 242 293 minecraft:basalt
fill 119 240 299 119 242 299 minecraft:basalt
setblock 119 240 300 minecraft:magma_block
setblock 119 240 315 minecraft:iron_block
fill 120 240 275 121 241 275 minecraft:white_concrete
fill 120 240 292 120 242 292 minecraft:basalt
fill 120 240 295 120 241 298 minecraft:basalt
fill 120 240 317 121 241 317 minecraft:white_concrete
setblock 121 240 287 minecraft:basalt
setblock 121 240 305 minecraft:basalt
fill 122 240 275 123 241 275 minecraft:red_concrete
fill 122 240 317 123 241 317 minecraft:red_concrete
fill 124 240 275 125 241 275 minecraft:white_concrete
setblock 124 240 292 minecraft:basalt
setblock 124 240 301 minecraft:basalt
fill 124 240 317 125 241 317 minecraft:white_concrete
setblock 125 240 294 minecraft:basalt
setblock 125 240 295 minecraft:magma_block
fill 125 240 296 125 240 297 minecraft:basalt
setblock 125 240 298 minecraft:magma_block
fill 126 240 275 127 241 275 minecraft:red_concrete
fill 126 240 317 127 241 317 minecraft:red_concrete
fill 128 240 275 129 241 275 minecraft:white_concrete
fill 128 240 317 129 241 317 minecraft:white_concrete
fill 130 240 275 131 241 275 minecraft:red_concrete
fill 130 240 317 131 241 317 minecraft:red_concrete
fill 132 240 275 133 241 275 minecraft:white_concrete
fill 132 240 317 133 241 317 minecraft:white_concrete
fill 134 240 275 135 241 275 minecraft:red_concrete
fill 134 240 317 135 241 317 minecraft:red_concrete
fill 136 240 276 136 241 276 minecraft:red_concrete
fill 136 240 277 136 241 278 minecraft:white_concrete
fill 136 240 279 136 241 280 minecraft:red_concrete
fill 136 240 281 136 241 282 minecraft:white_concrete
fill 136 240 283 136 241 284 minecraft:red_concrete
fill 136 240 285 136 241 286 minecraft:white_concrete
fill 136 240 287 136 241 288 minecraft:red_concrete
fill 136 240 289 136 241 290 minecraft:white_concrete
fill 136 240 291 136 241 292 minecraft:red_concrete
fill 136 240 293 136 241 294 minecraft:white_concrete
fill 136 240 295 136 241 296 minecraft:red_concrete
fill 136 240 297 136 241 298 minecraft:white_concrete
fill 136 240 299 136 241 300 minecraft:red_concrete
fill 136 240 301 136 241 302 minecraft:white_concrete
fill 136 240 303 136 241 304 minecraft:red_concrete
fill 136 240 305 136 241 306 minecraft:white_concrete
fill 136 240 307 136 241 308 minecraft:red_concrete
fill 136 240 309 136 241 310 minecraft:white_concrete
fill 136 240 311 136 241 312 minecraft:red_concrete
fill 136 240 313 136 241 314 minecraft:white_concrete
fill 136 240 315 136 241 316 minecraft:red_concrete
fill 136 240 317 136 241 317 minecraft:white_concrete
fill 95 241 285 101 241 285 minecraft:brown_terracotta
fill 97 241 283 101 242 284 minecraft:brown_terracotta
fill 97 241 286 101 242 287 minecraft:brown_terracotta
fill 100 241 294 100 241 295 minecraft:basalt
setblock 100 241 296 minecraft:magma_block
fill 100 241 297 100 241 298 minecraft:basalt
setblock 103 241 304 minecraft:magma_block
fill 104 241 296 105 241 296 minecraft:basalt
fill 105 241 294 105 241 295 minecraft:basalt
fill 105 241 297 105 241 298 minecraft:basalt
setblock 106 241 286 minecraft:basalt
fill 106 241 292 106 242 292 minecraft:basalt
setblock 106 241 300 minecraft:magma_block
setblock 106 241 306 minecraft:magma_block
setblock 107 241 291 minecraft:basalt
setblock 107 241 301 minecraft:basalt
setblock 107 241 307 minecraft:basalt
fill 108 241 290 108 242 290 minecraft:basalt
fill 108 241 302 108 242 302 minecraft:basalt
fill 110 241 288 110 242 289 minecraft:basalt
fill 110 241 303 114 241 303 minecraft:basalt
setblock 111 241 289 minecraft:basalt
fill 112 241 289 112 242 289 minecraft:magma_block
fill 113 241 289 114 241 289 minecraft:basalt
setblock 115 241 285 minecraft:magma_block
setblock 115 241 303 minecraft:magma_block
fill 115 241 306 119 241 306 minecraft:basalt
fill 116 241 289 116 242 290 minecraft:basalt
fill 116 241 302 116 242 303 minecraft:basalt
setblock 117 241 285 minecraft:basalt
setblock 117 241 291 minecraft:basalt
setblock 117 241 301 minecraft:basalt
fill 117 241 316 118 272 316 minecraft:red_terracotta
setblock 117 241 317 minecraft:white_concrete
fill 118 241 292 118 242 292 minecraft:basalt
fill 118 241 295 118 241 297 minecraft:red_terracotta
fill 118 241 300 119 242 300 minecraft:basalt
fill 118 241 312 126 241 315 minecraft:brown_terracotta
fill 119 241 294 119 241 298 minecraft:basalt
setblock 121 241 304 minecraft:magma_block
setblock 122 241 290 minecraft:basalt
setblock 122 241 302 minecraft:basalt
setblock 123 241 291 minecraft:basalt
setblock 124 241 294 minecraft:magma_block
fill 124 241 295 124 241 296 minecraft:basalt
setblock 124 241 297 minecraft:magma_block
setblock 124 241 298 minecraft:basalt
fill 94 242 275 94 243 276 minecraft:white_concrete
fill 94 242 277 94 243 278 minecraft:red_concrete
fill 94 242 279 94 243 279 minecraft:white_concrete
fill 94 242 280 94 247 280 minecraft:shroomlight
fill 94 242 281 94 243 282 minecraft:red_concrete
fill 94 242 283 94 243 284 minecraft:white_concrete
fill 94 242 285 94 243 286 minecraft:red_concrete
fill 94 242 287 94 243 287 minecraft:white_concrete
fill 94 242 288 94 247 288 minecraft:shroomlight
fill 94 242 289 94 243 290 minecraft:red_concrete
fill 94 242 291 94 243 292 minecraft:white_concrete
fill 94 242 293 94 243 294 minecraft:red_concrete
fill 94 242 295 94 243 295 minecraft:white_concrete
fill 94 242 296 94 247 296 minecraft:shroomlight
fill 94 242 297 94 243 298 minecraft:red_concrete
fill 94 242 299 94 243 300 minecraft:white_concrete
fill 94 242 301 94 243 302 minecraft:red_concrete
fill 94 242 303 94 243 303 minecraft:white_concrete
fill 94 242 304 94 247 304 minecraft:shroomlight
fill 94 242 305 94 243 306 minecraft:red_concrete
fill 94 242 307 94 243 308 minecraft:white_concrete
fill 94 242 309 94 243 310 minecraft:red_concrete
fill 94 242 311 94 243 311 minecraft:white_concrete
fill 94 242 312 94 247 312 minecraft:shroomlight
fill 94 242 313 94 243 314 minecraft:red_concrete
fill 94 242 315 94 243 316 minecraft:white_concrete
fill 95 242 275 95 243 275 minecraft:white_concrete
fill 95 242 317 95 243 317 minecraft:white_concrete
fill 96 242 275 97 243 275 minecraft:red_concrete
fill 96 242 317 96 243 317 minecraft:red_concrete
setblock 97 242 278 minecraft:light[level=15]
fill 97 242 285 101 242 285 minecraft:brown_terracotta
setblock 97 242 292 minecraft:light[level=12]
setblock 97 242 294 minecraft:light[level=15]
setblock 97 242 299 minecraft:light[level=12]
setblock 97 242 302 minecraft:light[level=15]
setblock 97 242 306 minecraft:light[level=12]
setblock 97 242 310 minecraft:light[level=15]
setblock 97 242 313 minecraft:light[level=12]
fill 97 242 317 97 247 317 minecraft:shroomlight
fill 98 242 275 99 243 275 minecraft:white_concrete
fill 98 242 317 99 243 317 minecraft:white_concrete
fill 100 242 275 100 243 275 minecraft:red_concrete
fill 100 242 317 101 243 317 minecraft:red_concrete
fill 101 242 275 101 247 275 minecraft:shroomlight
fill 102 242 275 103 243 275 minecraft:white_concrete
setblock 102 242 291 minecraft:magma_block
setblock 102 242 292 minecraft:basalt
setblock 102 242 294 minecraft:magma_block
fill 102 242 295 102 242 296 minecraft:basalt
setblock 102 242 297 minecraft:magma_block
setblock 102 242 300 minecraft:magma_block
setblock 102 242 301 minecraft:basalt
fill 102 242 317 103 243 317 minecraft:white_concrete
fill 104 242 275 105 243 275 minecraft:red_concrete
setblock 104 242 278 minecraft:light[level=12]
setblock 104 242 285 minecraft:light[level=12]
setblock 104 242 296 minecraft:basalt
setblock 104 242 306 minecraft:light[level=12]
setblock 104 242 311 minecraft:iron_block
setblock 104 242 313 minecraft:light[level=12]
fill 104 242 317 104 243 317 minecraft:red_concrete
setblock 105 242 278 minecraft:light[level=15]
setblock 105 242 286 minecraft:light[level=15]
setblock 105 242 287 minecraft:magma_block
setblock 105 242 290 minecraft:magma_block
fill 105 242 291 105 242 292 minecraft:basalt
fill 105 242 293 106 242 293 minecraft:magma_block
setblock 105 242 294 minecraft:basalt
fill 105 242 295 105 242 297 minecraft:magma_block
setblock 105 242 298 minecraft:basalt
fill 105 242 299 106 242 299 minecraft:magma_block
fill 105 242 300 106 242 300 minecraft:basalt
setblock 105 242 302 minecraft:magma_block
setblock 105 242 305 minecraft:magma_block
setblock 105 242 310 minecraft:iron_block
fill 105 242 311 107 242 311 minecraft:black_concrete
setblock 105 242 312 minecraft:iron_block
fill 105 242 317 105 247 317 minecraft:shroomlight
fill 106 242 275 107 243 275 minecraft:white_concrete
fill 106 242 294 106 242 295 minecraft:magma_block
fill 106 242 297 106 242 298 minecraft:magma_block
setblock 106 242 309 minecraft:iron_block
setblock 106 242 310 minecraft:black_concrete
setblock 106 242 312 minecraft:black_concrete
setblock 106 242 313 minecraft:iron_block
fill 106 242 317 107 243 317 minecraft:white_concrete
setblock 107 242 286 minecraft:basalt
fill 107 242 291 107 242 292 minecraft:magma_block
fill 107 242 300 107 242 301 minecraft:magma_block
setblock 107 242 310 minecraft:iron_block
setblock 107 242 312 minecraft:iron_block
fill 108 242 275 108 243 275 minecraft:red_concrete
setblock 108 242 286 minecraft:magma_block
setblock 108 242 289 minecraft:magma_block
setblock 108 242 291 minecraft:magma_block
setblock 108 242 301 minecraft:magma_block
setblock 108 242 304 minecraft:magma_block
setblock 108 242 311 minecraft:iron_block
fill 108 242 317 109 243 317 minecraft:red_concrete
fill 109 242 275 109 247 275 minecraft:shroomlight
fill 109 242 285 110 242 285 minecraft:basalt
setblock 109 242 289 minecraft:basalt
fill 109 242 290 111 242 290 minecraft:magma_block
fill 109 242 302 111 242 302 minecraft:magma_block
fill 110 242 275 111 243 275 minecraft:white_concrete
setblock 110 242 303 minecraft:basalt
setblock 110 242 307 minecraft:basalt
fill 110 242 317 111 243 317 minecraft:white_concrete
setblock 111 242 278 minecraft:light[level=12]
setblock 111 242 285 minecraft:magma_block
fill 111 242 288 111 242 289 minecraft:magma_block
setblock 111 242 292 minecraft:light[level=12]
setblock 111 242 299 minecraft:light[level=12]
fill 111 242 303 113 242 303 minecraft:magma_block
setblock 111 242 306 minecraft:magma_block
setblock 111 242 313 minecraft:light[level=12]
fill 112 242 275 113 243 275 minecraft:red_concrete
fill 112 242 288 114 242 288 minecraft:basalt
fill 112 242 306 117 242 306 minecraft:basalt
fill 112 242 317 112 243 317 minecraft:red_concrete
setblock 113 242 278 minecraft:light[level=15]
setblock 113 242 287 minecraft:basalt
fill 113 242 289 113 242 290 minecraft:magma_block
setblock 113 242 294 minecraft:light[level=15]
fill 113 242 302 115 242 302 minecraft:magma_block
setblock 113 242 305 minecraft:basalt
setblock 113 242 310 minecraft:light[level=15]
fill 113 242 317 113 247 317 minecraft:shroomlight
fill 114 242 275 115 243 275 minecraft:white_concrete
setblock 114 242 287 minecraft:magma_block
setblock 114 242 289 minecraft:basalt
fill 114 242 290 115 242 290 minecraft:magma_block
fill 114 242 303 115 242 303 minecraft:basalt
setblock 114 242 305 minecraft:magma_block
fill 114 242 317 115 243 317 minecraft:white_concrete
setblock 115 242 285 minecraft:basalt
setblock 115 242 307 minecraft:basalt
fill 116 242 275 116 243 275 minecraft:red_concrete
setblock 116 242 286 minecraft:basalt
fill 116 242 291 117 242 291 minecraft:magma_block
fill 116 242 301 117 242 301 minecraft:magma_block
fill 116 242 317 117 243 317 minecraft:red_concrete
fill 117 242 275 117 247 275 minecraft:shroomlight
setblock 117 242 286 minecraft:magma_block
setblock 117 242 289 minecraft:magma_block
setblock 117 242 292 minecraft:magma_block
setblock 117 242 300 minecraft:magma_block
setblock 117 242 304 minecraft:magma_block
fill 118 242 275 119 243 275 minecraft:white_concrete
setblock 118 242 278 minecraft:light[level=12]
setblock 118 242 285 minecraft:light[level=12]
fill 118 242 293 118 242 295 minecraft:magma_block
fill 118 242 296 118 244 296 minecraft:red_terracotta
fill 118 242 297 118 242 299 minecraft:magma_block
setblock 118 242 306 minecraft:light[level=12]
fill 118 242 312 126 242 315 minecraft:red_terracotta
fill 118 242 317 119 243 317 minecraft:white_concrete
setblock 119 242 291 minecraft:basalt
setblock 119 242 294 minecraft:basalt
fill 119 242 295 119 242 297 minecraft:magma_block
fill 119 242 298 120 242 298 minecraft:basalt
fill 120 242 275 121 243 275 minecraft:red_concrete
setblock 120 242 288 minecraft:magma_block
setblock 120 242 291 minecraft:magma_block
setblock 120 242 293 minecraft:basalt
setblock 120 242 294 minecraft:magma_block
fill 120 242 295 120 242 296 minecraft:basalt
setblock 120 242 297 minecraft:magma_block
setblock 120 242 300 minecraft:magma_block
setblock 120 242 301 minecraft:basalt
setblock 120 242 303 minecraft:magma_block
fill 120 242 317 120 243 317 minecraft:red_concrete
setblock 121 242 278 minecraft:light[level=15]
setblock 121 242 286 minecraft:light[level=15]
setblock 121 242 303 minecraft:basalt
setblock 121 242 310 minecraft:light[level=15]
fill 121 242 317 121 247 317 minecraft:shroomlight
fill 122 242 275 123 243 275 minecraft:white_concrete
fill 122 242 317 123 243 317 minecraft:white_concrete
setblock 123 242 293 minecraft:magma_block
setblock 123 242 296 minecraft:magma_block
fill 123 242 297 123 242 298 minecraft:basalt
setblock 123 242 299 minecraft:magma_block
fill 124 242 275 124 243 275 minecraft:red_concrete
fill 124 242 317 125 243 317 minecraft:red_concrete
fill 125 242 275 125 247 275 minecraft:shroomlight
setblock 125 242 278 minecraft:light[level=12]
setblock 125 242 285 minecraft:light[level=12]
setblock 125 242 292 minecraft:light[level=12]
setblock 125 242 299 minecraft:light[level=12]
setblock 125 242 306 minecraft:light[level=12]
fill 126 242 275 127 243 275 minecraft:white_concrete
fill 126 242 317 127 243 317 minecraft:white_concrete
fill 128 242 275 129 243 275 minecraft:red_concrete
fill 128 242 317 128 243 317 minecraft:red_concrete
setblock 129 242 278 minecraft:light[level=15]
setblock 129 242 286 minecraft:light[level=15]
setblock 129 242 294 minecraft:light[level=15]
setblock 129 242 302 minecraft:light[level=15]
setblock 129 242 310 minecraft:light[level=15]
fill 129 242 317 129 247 317 minecraft:shroomlight
fill 130 242 275 131 243 275 minecraft:white_concrete
fill 130 242 317 131 243 317 minecraft:white_concrete
fill 132 242 275 132 243 275 minecraft:red_concrete
setblock 132 242 278 minecraft:light[level=12]
setblock 132 242 285 minecraft:light[level=12]
setblock 132 242 292 minecraft:light[level=12]
setblock 132 242 299 minecraft:light[level=12]
setblock 132 242 306 minecraft:light[level=12]
setblock 132 242 313 minecraft:light[level=12]
fill 132 242 317 133 243 317 minecraft:red_concrete
fill 133 242 275 133 247 275 minecraft:shroomlight
fill 134 242 275 135 243 275 minecraft:white_concrete
fill 134 242 317 135 243 317 minecraft:white_concrete
fill 136 242 276 136 243 276 minecraft:white_concrete
fill 136 242 277 136 243 278 minecraft:red_concrete
fill 136 242 279 136 243 279 minecraft:white_concrete
fill 136 242 280 136 247 280 minecraft:shroomlight
fill 136 242 281 136 243 282 minecraft:red_concrete
fill 136 242 283 136 243 284 minecraft:white_concrete
fill 136 242 285 136 243 286 minecraft:red_concrete
fill 136 242 287 136 243 287 minecraft:white_concrete
fill 136 242 288 136 247 288 minecraft:shroomlight
fill 136 242 289 136 243 290 minecraft:red_concrete
fill 136 242 291 136 243 292 minecraft:white_concrete
fill 136 242 293 136 243 294 minecraft:red_concrete
fill 136 242 295 136 243 295 minecraft:white_concrete
fill 136 242 296 136 247 296 minecraft:shroomlight
fill 136 242 297 136 243 298 minecraft:red_concrete
fill 136 242 299 136 243 300 minecraft:white_concrete
fill 136 242 301 136 243 302 minecraft:red_concrete
fill 136 242 303 136 243 303 minecraft:white_concrete
fill 136 242 304 136 247 304 minecraft:shroomlight
fill 136 242 305 136 243 306 minecraft:red_concrete
fill 136 242 307 136 243 308 minecraft:white_concrete
fill 136 242 309 136 243 310 minecraft:red_concrete
fill 136 242 311 136 243 311 minecraft:white_concrete
fill 136 242 312 136 247 312 minecraft:shroomlight
fill 136 242 313 136 243 314 minecraft:red_concrete
fill 136 242 315 136 243 316 minecraft:white_concrete
fill 136 242 317 136 243 317 minecraft:red_concrete
fill 98 243 278 98 244 278 minecraft:brown_terracotta
fill 98 243 307 98 244 307 minecraft:brown_terracotta
fill 99 243 285 99 246 285 minecraft:red_terracotta
fill 113 243 279 113 244 279 minecraft:brown_terracotta
fill 118 243 295 119 260 295 minecraft:red_terracotta
fill 118 243 312 126 243 312 minecraft:yellow_concrete
fill 119 243 296 119 259 297 minecraft:red_terracotta
fill 121 243 316 123 246 316 minecraft:shroomlight
fill 130 243 279 130 244 279 minecraft:brown_terracotta
fill 130 243 312 130 244 312 minecraft:brown_terracotta
fill 131 243 313 131 244 313 minecraft:brown_terracotta
fill 94 244 275 94 245 276 minecraft:red_concrete
fill 94 244 277 94 245 278 minecraft:white_concrete
fill 94 244 279 94 245 279 minecraft:red_concrete
fill 94 244 281 94 245 282 minecraft:white_concrete
fill 94 244 283 94 245 284 minecraft:red_concrete
fill 94 244 285 94 245 286 minecraft:white_concrete
fill 94 244 287 94 245 287 minecraft:red_concrete
fill 94 244 289 94 245 290 minecraft:white_concrete
fill 94 244 291 94 245 292 minecraft:red_concrete
fill 94 244 293 94 245 294 minecraft:white_concrete
fill 94 244 295 94 245 295 minecraft:red_concrete
fill 94 244 297 94 245 298 minecraft:white_concrete
fill 94 244 299 94 245 300 minecraft:red_concrete
fill 94 244 301 94 245 302 minecraft:white_concrete
fill 94 244 303 94 245 303 minecraft:red_concrete
fill 94 244 305 94 245 306 minecraft:white_concrete
fill 94 244 307 94 245 308 minecraft:red_concrete
fill 94 244 309 94 245 310 minecraft:white_concrete
fill 94 244 311 94 245 311 minecraft:red_concrete
fill 94 244 313 94 245 314 minecraft:white_concrete
fill 94 244 315 94 245 316 minecraft:red_concrete
fill 95 244 275 95 245 275 minecraft:red_concrete
fill 95 244 317 95 245 317 minecraft:red_concrete
fill 96 244 275 97 245 275 minecraft:white_concrete
fill 96 244 317 96 245 317 minecraft:white_concrete
fill 97 244 278 97 245 278 minecraft:brown_terracotta
fill 97 244 307 97 245 307 minecraft:brown_terracotta
fill 98 244 275 99 245 275 minecraft:red_concrete
fill 98 244 317 99 245 317 minecraft:red_concrete
fill 100 244 275 100 245 275 minecraft:white_concrete
fill 100 244 317 101 245 317 minecraft:white_concrete
fill 102 244 275 103 245 275 minecraft:red_concrete
fill 102 244 317 103 245 317 minecraft:red_concrete
fill 104 244 275 105 245 275 minecraft:white_concrete
fill 104 244 317 104 245 317 minecraft:white_concrete
fill 106 244 275 107 245 275 minecraft:red_concrete
fill 106 244 317 107 245 317 minecraft:red_concrete
fill 108 244 275 108 245 275 minecraft:white_concrete
fill 108 244 317 109 245 317 minecraft:white_concrete
fill 110 244 275 111 245 275 minecraft:red_concrete
fill 110 244 317 111 245 317 minecraft:red_concrete
fill 112 244 275 113 245 275 minecraft:white_concrete
fill 112 244 317 112 245 317 minecraft:white_concrete
fill 113 244 278 113 245 278 minecraft:brown_terracotta
fill 114 244 275 115 245 275 minecraft:red_concrete
fill 114 244 317 115 245 317 minecraft:red_concrete
fill 116 244 275 116 245 275 minecraft:white_concrete
fill 116 244 317 117 245 317 minecraft:white_concrete
fill 118 244 275 119 245 275 minecraft:red_concrete
setblock 118 244 312 minecraft:red_terracotta
fill 118 244 317 119 245 317 minecraft:red_concrete
fill 120 244 275 121 245 275 minecraft:white_concrete
fill 120 244 317 120 245 317 minecraft:white_concrete
fill 122 244 275 123 245 275 minecraft:red_concrete
setblock 122 244 312 minecraft:red_terracotta
fill 122 244 317 123 245 317 minecraft:red_concrete
fill 124 244 275 124 245 275 minecraft:white_concrete
fill 124 244 317 125 245 317 minecraft:white_concrete
fill 126 244 275 127 245 275 minecraft:red_concrete
setblock 126 244 312 minecraft:red_terracotta
fill 126 244 317 127 245 317 minecraft:red_concrete
fill 128 244 275 129 245 275 minecraft:white_concrete
fill 128 244 317 128 245 317 minecraft:white_concrete
fill 130 244 275 131 245 275 minecraft:red_concrete
fill 130 244 278 130 245 278 minecraft:brown_terracotta
fill 130 244 313 130 245 313 minecraft:brown_terracotta
fill 130 244 317 131 245 317 minecraft:red_concrete
fill 132 244 275 132 245 275 minecraft:white_concrete
fill 132 244 313 132 245 313 minecraft:brown_terracotta
fill 132 244 317 133 245 317 minecraft:white_concrete
fill 134 244 275 135 245 275 minecraft:red_concrete
fill 134 244 317 135 245 317 minecraft:red_concrete
fill 136 244 276 136 245 276 minecraft:red_concrete
fill 136 244 277 136 245 278 minecraft:white_concrete
fill 136 244 279 136 245 279 minecraft:red_concrete
fill 136 244 281 136 245 282 minecraft:white_concrete
fill 136 244 283 136 245 284 minecraft:red_concrete
fill 136 244 285 136 245 286 minecraft:white_concrete
fill 136 244 287 136 245 287 minecraft:red_concrete
fill 136 244 289 136 245 290 minecraft:white_concrete
fill 136 244 291 136 245 292 minecraft:red_concrete
fill 136 244 293 136 245 294 minecraft:white_concrete
fill 136 244 295 136 245 295 minecraft:red_concrete
fill 136 244 297 136 245 298 minecraft:white_concrete
fill 136 244 299 136 245 300 minecraft:red_concrete
fill 136 244 301 136 245 302 minecraft:white_concrete
fill 136 244 303 136 245 303 minecraft:red_concrete
fill 136 244 305 136 245 306 minecraft:white_concrete
fill 136 244 307 136 245 308 minecraft:red_concrete
fill 136 244 309 136 245 310 minecraft:white_concrete
fill 136 244 311 136 245 311 minecraft:red_concrete
fill 136 244 313 136 245 314 minecraft:white_concrete
fill 136 244 315 136 245 316 minecraft:red_concrete
fill 136 244 317 136 245 317 minecraft:white_concrete
fill 96 245 278 96 246 278 minecraft:brown_terracotta
fill 96 245 307 96 246 307 minecraft:brown_terracotta
fill 113 245 277 113 246 277 minecraft:brown_terracotta
fill 130 245 277 130 246 277 minecraft:brown_terracotta
fill 130 245 314 130 246 314 minecraft:brown_terracotta
fill 133 245 313 133 246 313 minecraft:brown_terracotta
fill 94 246 275 94 247 276 minecraft:white_concrete
fill 94 246 277 94 247 278 minecraft:red_concrete
fill 94 246 279 94 247 279 minecraft:white_concrete
fill 94 246 281 94 247 282 minecraft:red_concrete
fill 94 246 283 94 247 284 minecraft:white_concrete
fill 94 246 285 94 247 286 minecraft:red_concrete
fill 94 246 287 94 247 287 minecraft:white_concrete
fill 94 246 289 94 247 290 minecraft:red_concrete
fill 94 246 291 94 247 292 minecraft:white_concrete
fill 94 246 293 94 247 294 minecraft:red_concrete
fill 94 246 295 94 247 295 minecraft:white_concrete
fill 94 246 297 94 247 298 minecraft:red_concrete
fill 94 246 299 94 247 300 minecraft:white_concrete
fill 94 246 301 94 247 302 minecraft:red_concrete
fill 94 246 303 94 247 303 minecraft:white_concrete
fill 94 246 305 94 247 306 minecraft:red_concrete
fill 94 246 307 94 247 308 minecraft:white_concrete
fill 94 246 309 94 247 310 minecraft:red_concrete
fill 94 246 311 94 247 311 minecraft:white_concrete
fill 94 246 313 94 247 314 minecraft:red_concrete
fill 94 246 315 94 247 316 minecraft:white_concrete
fill 95 246 275 95 247 275 minecraft:white_concrete
fill 95 246 278 95 247 278 minecraft:brown_terracotta
fill 95 246 317 95 247 317 minecraft:white_concrete
fill 96 246 275 97 247 275 minecraft:red_concrete
fill 96 246 317 96 247 317 minecraft:red_concrete
fill 98 246 275 99 247 275 minecraft:white_concrete
fill 98 246 317 99 247 317 minecraft:white_concrete
fill 100 246 275 100 247 275 minecraft:red_concrete
fill 100 246 317 101 247 317 minecraft:red_concrete
fill 102 246 275 103 247 275 minecraft:white_concrete
fill 102 246 317 103 247 317 minecraft:white_concrete
fill 104 246 275 105 247 275 minecraft:red_concrete
fill 104 246 317 104 247 317 minecraft:red_concrete
fill 106 246 275 107 247 275 minecraft:white_concrete
fill 106 246 317 107 247 317 minecraft:white_concrete
fill 108 246 275 108 247 275 minecraft:red_concrete
fill 108 246 317 109 247 317 minecraft:red_concrete
fill 110 246 275 111 247 275 minecraft:white_concrete
fill 110 246 317 111 247 317 minecraft:white_concrete
fill 112 246 275 113 247 275 minecraft:red_concrete
fill 112 246 317 112 247 317 minecraft:red_concrete
fill 114 246 275 115 247 275 minecraft:white_concrete
fill 114 246 317 115 247 317 minecraft:white_concrete
fill 116 246 275 116 247 275 minecraft:red_concrete
fill 116 246 317 117 247 317 minecraft:red_concrete
fill 118 246 275 119 247 275 minecraft:white_concrete
fill 118 246 317 119 247 317 minecraft:white_concrete
fill 120 246 275 121 247 275 minecraft:red_concrete
fill 120 246 317 120 247 317 minecraft:red_concrete
fill 122 246 275 123 247 275 minecraft:white_concrete
fill 122 246 317 123 247 317 minecraft:white_concrete
fill 124 246 275 124 247 275 minecraft:red_concrete
fill 124 246 317 125 247 317 minecraft:red_concrete
fill 126 246 275 127 247 275 minecraft:white_concrete
fill 126 246 317 127 247 317 minecraft:white_concrete
fill 128 246 275 129 247 275 minecraft:red_concrete
fill 128 246 317 128 247 317 minecraft:red_concrete
fill 130 246 275 131 247 275 minecraft:white_concrete
fill 130 246 276 130 247 276 minecraft:brown_terracotta
fill 130 246 315 130 247 315 minecraft:brown_terracotta
fill 130 246 317 131 247 317 minecraft:white_concrete
fill 132 246 275 132 247 275 minecraft:red_concrete
fill 132 246 317 133 247 317 minecraft:red_concrete
fill 134 246 275 135 247 275 minecraft:white_concrete
fill 134 246 313 134 247 313 minecraft:brown_terracotta
fill 134 246 317 135 247 317 minecraft:white_concrete
fill 136 246 276 136 247 276 minecraft:white_concrete
fill 136 246 277 136 247 278 minecraft:red_concrete
fill 136 246 279 136 247 279 minecraft:white_concrete
fill 136 246 281 136 247 282 minecraft:red_concrete
fill 136 246 283 136 247 284 minecraft:white_concrete
fill 136 246 285 136 247 286 minecraft:red_concrete
fill 136 246 287 136 247 287 minecraft:white_concrete
fill 136 246 289 136 247 290 minecraft:red_concrete
fill 136 246 291 136 247 292 minecraft:white_concrete
fill 136 246 293 136 247 294 minecraft:red_concrete
fill 136 246 295 136 247 295 minecraft:white_concrete
fill 136 246 297 136 247 298 minecraft:red_concrete
fill 136 246 299 136 247 300 minecraft:white_concrete
fill 136 246 301 136 247 302 minecraft:red_concrete
fill 136 246 303 136 247 303 minecraft:white_concrete
fill 136 246 305 136 247 306 minecraft:red_concrete
fill 136 246 307 136 247 308 minecraft:white_concrete
fill 136 246 309 136 247 310 minecraft:red_concrete
fill 136 246 311 136 247 311 minecraft:white_concrete
fill 136 246 313 136 247 314 minecraft:red_concrete
fill 136 246 315 136 247 316 minecraft:white_concrete
fill 136 246 317 136 247 317 minecraft:red_concrete
fill 97 247 285 101 247 285 minecraft:yellow_concrete
setblock 98 247 283 minecraft:shroomlight
fill 98 247 284 100 247 284 minecraft:yellow_concrete
fill 98 247 286 100 250 286 minecraft:yellow_concrete
setblock 98 247 289 minecraft:shroomlight
setblock 98 247 295 minecraft:shroomlight
setblock 98 247 301 minecraft:shroomlight
setblock 98 247 307 minecraft:shroomlight
setblock 98 247 313 minecraft:shroomlight
fill 99 247 283 99 250 283 minecraft:yellow_concrete
fill 99 247 287 99 250 287 minecraft:yellow_concrete
setblock 102 247 279 minecraft:shroomlight
setblock 104 247 313 minecraft:shroomlight
setblock 108 247 279 minecraft:shroomlight
setblock 110 247 313 minecraft:shroomlight
setblock 114 247 279 minecraft:shroomlight
setblock 116 247 313 minecraft:shroomlight
setblock 120 247 279 minecraft:shroomlight
setblock 122 247 313 minecraft:shroomlight
setblock 126 247 279 minecraft:shroomlight
setblock 128 247 313 minecraft:shroomlight
setblock 132 247 279 minecraft:shroomlight
setblock 132 247 285 minecraft:shroomlight
setblock 132 247 291 minecraft:shroomlight
setblock 132 247 297 minecraft:shroomlight
setblock 132 247 303 minecraft:shroomlight
setblock 132 247 309 minecraft:shroomlight
fill 94 248 275 94 249 276 minecraft:red_concrete
fill 94 248 277 94 249 278 minecraft:white_concrete
fill 94 248 279 94 249 280 minecraft:red_concrete
fill 94 248 281 94 249 282 minecraft:white_concrete
fill 94 248 283 94 249 284 minecraft:red_concrete
fill 94 248 285 94 249 286 minecraft:white_concrete
fill 94 248 287 94 249 288 minecraft:red_concrete
fill 94 248 289 94 249 290 minecraft:white_concrete
fill 94 248 291 94 249 292 minecraft:red_concrete
fill 94 248 293 94 249 294 minecraft:white_concrete
fill 94 248 295 94 249 296 minecraft:red_concrete
fill 94 248 297 94 249 298 minecraft:white_concrete
fill 94 248 299 94 249 300 minecraft:red_concrete
fill 94 248 301 94 249 302 minecraft:white_concrete
fill 94 248 303 94 249 304 minecraft:red_concrete
fill 94 248 305 94 249 306 minecraft:white_concrete
fill 94 248 307 94 249 308 minecraft:red_concrete
fill 94 248 309 94 249 310 minecraft:white_concrete
fill 94 248 311 94 249 312 minecraft:red_concrete
fill 94 248 313 94 249 314 minecraft:white_concrete
fill 94 248 315 94 249 316 minecraft:red_concrete
fill 95 248 275 95 249 275 minecraft:red_concrete
setblock 95 248 276 minecraft:red_terracotta
fill 95 248 278 95 248 279 minecraft:red_terracotta
fill 95 248 281 96 248 281 minecraft:red_terracotta
fill 95 248 284 95 248 285 minecraft:red_terracotta
fill 95 248 287 95 248 288 minecraft:red_terracotta
fill 95 248 293 95 248 294 minecraft:red_terracotta
fill 95 248 296 95 248 297 minecraft:red_terracotta
setblock 95 248 300 minecraft:red_terracotta
fill 95 248 302 95 248 303 minecraft:red_terracotta
fill 95 248 305 96 248 305 minecraft:red_terracotta
fill 95 248 308 95 248 309 minecraft:red_terracotta
fill 95 248 311 95 248 312 minecraft:red_terracotta
fill 95 248 317 95 249 317 minecraft:red_concrete
fill 96 248 275 97 249 275 minecraft:white_concrete
fill 96 248 277 96 248 278 minecraft:red_terracotta
fill 96 248 280 97 248 280 minecraft:red_terracotta
fill 96 248 283 96 248 284 minecraft:red_terracotta
fill 96 248 286 96 248 287 minecraft:red_terracotta
fill 96 248 289 96 248 290 minecraft:red_terracotta
fill 96 248 292 96 248 293 minecraft:red_terracotta
fill 96 248 295 96 248 296 minecraft:red_terracotta
fill 96 248 298 96 248 299 minecraft:red_terracotta
fill 96 248 301 96 248 302 minecraft:red_terracotta
fill 96 248 304 97 248 304 minecraft:red_terracotta
fill 96 248 307 96 248 308 minecraft:red_terracotta
fill 96 248 310 96 248 311 minecraft:red_terracotta
fill 96 248 313 96 248 314 minecraft:red_terracotta
fill 96 248 316 97 248 316 minecraft:red_terracotta
fill 96 248 317 97 249 317 minecraft:white_concrete
setblock 97 248 277 minecraft:red_terracotta
setblock 97 248 278 minecraft:light[level=12]
fill 97 248 279 98 248 279 minecraft:red_terracotta
fill 97 248 282 97 248 283 minecraft:red_terracotta
fill 97 248 284 97 249 284 minecraft:yellow_concrete
fill 97 248 285 97 248 286 minecraft:red_terracotta
fill 97 248 288 97 248 289 minecraft:red_terracotta
fill 97 248 291 97 248 292 minecraft:red_terracotta
fill 97 248 294 97 248 295 minecraft:red_terracotta
fill 97 248 297 97 248 298 minecraft:red_terracotta
setblock 97 248 299 minecraft:light[level=12]
fill 97 248 300 97 248 301 minecraft:red_terracotta
fill 97 248 303 98 248 303 minecraft:red_terracotta
fill 97 248 306 97 248 307 minecraft:red_terracotta
fill 97 248 309 97 248 310 minecraft:red_terracotta
fill 97 248 312 97 248 313 minecraft:red_terracotta
fill 97 248 315 98 248 315 minecraft:red_terracotta
fill 98 248 275 99 249 275 minecraft:red_concrete
setblock 98 248 276 minecraft:red_terracotta
fill 98 248 278 99 248 278 minecraft:red_terracotta
fill 98 248 281 98 248 282 minecraft:red_terracotta
fill 98 248 283 98 249 283 minecraft:yellow_concrete
fill 98 248 284 98 248 285 minecraft:red_terracotta
fill 98 248 287 98 248 288 minecraft:red_terracotta
fill 98 248 290 98 248 291 minecraft:red_terracotta
fill 98 248 293 98 248 294 minecraft:red_terracotta
fill 98 248 296 98 248 297 minecraft:red_terracotta
fill 98 248 299 98 248 300 minecraft:red_terracotta
setblock 98 248 302 minecraft:red_terracotta
fill 98 248 305 98 248 306 minecraft:red_terracotta
fill 98 248 308 98 248 309 minecraft:red_terracotta
fill 98 248 311 98 248 312 minecraft:red_terracotta
fill 98 248 314 99 248 314 minecraft:red_terracotta
fill 98 248 317 99 249 317 minecraft:red_concrete
fill 99 248 277 100 248 277 minecraft:red_terracotta
fill 99 248 284 101 249 285 minecraft:yellow_concrete
fill 99 248 313 100 248 313 minecraft:red_terracotta
fill 99 248 316 100 248 316 minecraft:red_terracotta
fill 100 248 275 101 249 275 minecraft:white_concrete
fill 100 248 276 101 248 276 minecraft:red_terracotta
fill 100 248 279 101 248 279 minecraft:red_terracotta
fill 100 248 283 100 249 283 minecraft:yellow_concrete
fill 100 248 287 100 249 287 minecraft:yellow_concrete
fill 100 248 315 101 248 315 minecraft:red_terracotta
fill 100 248 317 101 249 317 minecraft:white_concrete
fill 101 248 278 102 248 278 minecraft:red_terracotta
fill 101 248 286 101 249 286 minecraft:yellow_concrete
fill 101 248 314 102 248 314 minecraft:red_terracotta
fill 102 248 275 103 249 275 minecraft:red_concrete
fill 102 248 277 103 248 277 minecraft:red_terracotta
fill 102 248 313 103 248 313 minecraft:red_terracotta
fill 102 248 317 103 249 317 minecraft:red_concrete
setblock 103 248 276 minecraft:red_terracotta
fill 103 248 279 104 248 279 minecraft:red_terracotta
fill 103 248 315 103 248 316 minecraft:red_terracotta
fill 104 248 275 105 249 275 minecraft:white_concrete
fill 104 248 278 105 248 278 minecraft:red_terracotta
setblock 104 248 285 minecraft:light[level=12]
setblock 104 248 292 minecraft:light[level=12]
setblock 104 248 299 minecraft:light[level=12]
setblock 104 248 306 minecraft:light[level=12]
setblock 104 248 313 minecraft:light[level=12]
fill 104 248 314 104 248 315 minecraft:red_terracotta
fill 104 248 317 105 249 317 minecraft:white_concrete
fill 105 248 277 106 248 277 minecraft:red_terracotta
fill 105 248 313 105 248 314 minecraft:red_terracotta
fill 105 248 316 106 248 316 minecraft:red_terracotta
fill 106 248 275 107 249 275 minecraft:red_concrete
fill 106 248 276 107 248 276 minecraft:red_terracotta
fill 106 248 279 107 248 279 minecraft:red_terracotta
setblock 106 248 313 minecraft:red_terracotta
fill 106 248 315 107 248 315 minecraft:red_terracotta
fill 106 248 317 107 249 317 minecraft:red_concrete
fill 107 248 278 108 248 278 minecraft:red_terracotta
fill 107 248 314 108 248 314 minecraft:red_terracotta
fill 108 248 275 109 249 275 minecraft:white_concrete
fill 108 248 277 109 248 277 minecraft:red_terracotta
fill 108 248 313 109 248 313 minecraft:red_terracotta
setblock 108 248 316 minecraft:red_terracotta
fill 108 248 317 109 249 317 minecraft:white_concrete
fill 109 248 276 110 248 276 minecraft:red_terracotta
fill 109 248 279 110 248 279 minecraft:red_terracotta
fill 109 248 315 110 248 315 minecraft:red_terracotta
fill 110 248 275 111 249 275 minecraft:red_concrete
fill 110 248 278 111 248 278 minecraft:red_terracotta
fill 110 248 314 111 248 314 minecraft:red_terracotta
fill 110 248 317 111 249 317 minecraft:red_concrete
fill 111 248 277 112 248 277 minecraft:red_terracotta
setblock 111 248 285 minecraft:light[level=12]
setblock 111 248 292 minecraft:light[level=12]
setblock 111 248 299 minecraft:light[level=12]
setblock 111 248 306 minecraft:light[level=12]
fill 111 248 313 112 248 313 minecraft:red_terracotta
fill 111 248 316 112 248 316 minecraft:red_terracotta
fill 112 248 275 113 249 275 minecraft:white_concrete
fill 112 248 279 113 248 279 minecraft:red_terracotta
fill 112 248 315 113 248 315 minecraft:red_terracotta
fill 112 248 317 113 249 317 minecraft:white_concrete
fill 113 248 278 114 248 278 minecraft:red_terracotta
fill 113 248 314 114 248 314 minecraft:red_terracotta
fill 114 248 275 115 249 275 minecraft:red_concrete
fill 114 248 277 115 248 277 minecraft:red_terracotta
fill 114 248 313 115 248 313 minecraft:red_terracotta
fill 114 248 316 115 248 316 minecraft:red_terracotta
fill 114 248 317 115 249 317 minecraft:red_concrete
fill 115 248 276 116 248 276 minecraft:red_terracotta
fill 115 248 279 116 248 279 minecraft:red_terracotta
fill 115 248 315 116 248 315 minecraft:red_terracotta
fill 116 248 275 117 249 275 minecraft:white_concrete
fill 116 248 278 117 248 278 minecraft:red_terracotta
fill 116 248 314 117 248 314 minecraft:red_terracotta
fill 116 248 317 117 249 317 minecraft:white_concrete
fill 117 248 277 118 248 277 minecraft:red_terracotta
fill 117 248 313 118 248 313 minecraft:red_terracotta
fill 118 248 275 119 249 275 minecraft:red_concrete
fill 118 248 276 119 248 276 minecraft:red_terracotta
setblock 118 248 278 minecraft:light[level=12]
fill 118 248 279 119 248 279 minecraft:red_terracotta
setblock 118 248 285 minecraft:light[level=12]
setblock 118 248 292 minecraft:light[level=12]
setblock 118 248 299 minecraft:light[level=12]
setblock 118 248 306 minecraft:light[level=12]
fill 118 248 315 119 248 315 minecraft:red_terracotta
fill 118 248 317 119 249 317 minecraft:red_concrete
fill 119 248 278 120 248 278 minecraft:red_terracotta
fill 119 248 314 120 248 314 minecraft:red_terracotta
fill 120 248 275 121 249 275 minecraft:white_concrete
fill 120 248 277 121 248 277 minecraft:red_terracotta
fill 120 248 313 121 248 313 minecraft:red_terracotta
fill 120 248 316 121 248 316 minecraft:red_terracotta
fill 120 248 317 121 249 317 minecraft:white_concrete
fill 121 248 279 122 248 279 minecraft:red_terracotta
fill 121 248 315 122 248 315 minecraft:red_terracotta
fill 122 248 275 123 249 275 minecraft:red_concrete
setblock 122 248 276 minecraft:red_terracotta
fill 122 248 278 123 248 278 minecraft:red_terracotta
fill 122 248 314 123 248 314 minecraft:red_terracotta
fill 122 248 317 123 249 317 minecraft:red_concrete
fill 123 248 277 124 248 277 minecraft:red_terracotta
fill 123 248 313 124 248 313 minecraft:red_terracotta
fill 123 248 316 124 248 316 minecraft:red_terracotta
fill 124 248 275 125 249 275 minecraft:white_concrete
fill 124 248 276 125 248 276 minecraft:red_terracotta
fill 124 248 279 125 248 279 minecraft:red_terracotta
fill 124 248 315 125 248 315 minecraft:red_terracotta
fill 124 248 317 125 249 317 minecraft:white_concrete
fill 125 248 278 126 248 278 minecraft:red_terracotta
setblock 125 248 285 minecraft:light[level=12]
setblock 125 248 292 minecraft:light[level=12]
setblock 125 248 299 minecraft:light[level=12]
setblock 125 248 306 minecraft:light[level=12]
setblock 125 248 313 minecraft:light[level=12]
fill 125 248 314 126 248 314 minecraft:red_terracotta
fill 126 248 275 127 249 275 minecraft:red_concrete
fill 126 248 277 127 248 277 minecraft:red_terracotta
fill 126 248 313 127 248 313 minecraft:red_terracotta
fill 126 248 317 127 249 317 minecraft:red_concrete
setblock 127 248 276 minecraft:red_terracotta
fill 127 248 279 128 248 279 minecraft:red_terracotta
fill 127 248 315 127 248 316 minecraft:red_terracotta
fill 128 248 275 129 249 275 minecraft:white_concrete
fill 128 248 278 129 248 278 minecraft:red_terracotta
fill 128 248 314 128 248 315 minecraft:red_terracotta
fill 128 248 317 129 249 317 minecraft:white_concrete
fill 129 248 277 130 248 277 minecraft:red_terracotta
fill 129 248 313 129 248 314 minecraft:red_terracotta
fill 129 248 316 130 248 316 minecraft:red_terracotta
fill 130 248 275 131 249 275 minecraft:red_concrete
fill 130 248 276 131 248 276 minecraft:red_terracotta
fill 130 248 279 131 248 279 minecraft:red_terracotta
setblock 130 248 313 minecraft:red_terracotta
fill 130 248 315 131 248 315 minecraft:red_terracotta
fill 130 248 317 131 249 317 minecraft:red_concrete
fill 131 248 278 132 248 278 minecraft:red_terracotta
fill 131 248 314 132 248 314 minecraft:red_terracotta
fill 132 248 275 133 249 275 minecraft:white_concrete
fill 132 248 277 133 248 277 minecraft:red_terracotta
fill 132 248 280 132 248 281 minecraft:red_terracotta
fill 132 248 283 132 248 284 minecraft:red_terracotta
setblock 132 248 285 minecraft:light[level=12]
fill 132 248 286 132 248 287 minecraft:red_terracotta
fill 132 248 289 132 248 290 minecraft:red_terracotta
fill 132 248 292 132 248 293 minecraft:red_terracotta
fill 132 248 295 132 248 296 minecraft:red_terracotta
fill 132 248 298 132 248 299 minecraft:red_terracotta
fill 132 248 301 132 248 302 minecraft:red_terracotta
fill 132 248 304 132 248 305 minecraft:red_terracotta
setblock 132 248 306 minecraft:light[level=12]
fill 132 248 307 132 248 308 minecraft:red_terracotta
fill 132 248 310 132 248 311 minecraft:red_terracotta
fill 132 248 313 133 248 313 minecraft:red_terracotta
setblock 132 248 316 minecraft:red_terracotta
fill 132 248 317 133 249 317 minecraft:white_concrete
fill 133 248 276 134 248 276 minecraft:red_terracotta
fill 133 248 279 133 248 280 minecraft:red_terracotta
fill 133 248 282 133 248 283 minecraft:red_terracotta
fill 133 248 285 133 248 286 minecraft:red_terracotta
fill 133 248 288 133 248 289 minecraft:red_terracotta
fill 133 248 291 133 248 292 minecraft:red_terracotta
fill 133 248 294 133 248 295 minecraft:red_terracotta
fill 133 248 297 133 248 298 minecraft:red_terracotta
fill 133 248 300 133 248 301 minecraft:red_terracotta
fill 133 248 303 133 248 304 minecraft:red_terracotta
fill 133 248 306 133 248 307 minecraft:red_terracotta
fill 133 248 309 133 248 310 minecraft:red_terracotta
fill 133 248 312 134 248 312 minecraft:red_terracotta
fill 133 248 315 134 248 315 minecraft:red_terracotta
fill 134 248 275 135 249 275 minecraft:red_concrete
fill 134 248 278 134 248 279 minecraft:red_terracotta
fill 134 248 281 134 248 282 minecraft:red_terracotta
fill 134 248 284 134 248 285 minecraft:red_terracotta
fill 134 248 287 134 248 288 minecraft:red_terracotta
fill 134 248 290 134 248 291 minecraft:red_terracotta
fill 134 248 293 134 248 294 minecraft:red_terracotta
fill 134 248 296 134 248 297 minecraft:red_terracotta
fill 134 248 299 134 248 300 minecraft:red_terracotta
fill 134 248 302 134 248 303 minecraft:red_terracotta
fill 134 248 305 134 248 306 minecraft:red_terracotta
fill 134 248 308 134 248 309 minecraft:red_terracotta
fill 134 248 311 135 248 311 minecraft:red_terracotta
fill 134 248 314 135 248 314 minecraft:red_terracotta
fill 134 248 317 135 249 317 minecraft:red_concrete
fill 135 248 280 135 248 281 minecraft:red_terracotta
fill 135 248 283 135 248 284 minecraft:red_terracotta
setblock 135 248 287 minecraft:red_terracotta
fill 135 248 289 135 248 290 minecraft:red_terracotta
setblock 135 248 292 minecraft:red_terracotta
fill 135 248 295 135 248 296 minecraft:red_terracotta
fill 135 248 298 135 248 299 minecraft:red_terracotta
fill 135 248 304 135 248 305 minecraft:red_terracotta
fill 135 248 307 135 248 308 minecraft:red_terracotta
setblock 135 248 313 minecraft:red_terracotta
setblock 135 248 316 minecraft:red_terracotta
fill 136 248 276 136 249 276 minecraft:red_concrete
fill 136 248 277 136 249 278 minecraft:white_concrete
fill 136 248 279 136 249 280 minecraft:red_concrete
fill 136 248 281 136 249 282 minecraft:white_concrete
fill 136 248 283 136 249 284 minecraft:red_concrete
fill 136 248 285 136 249 286 minecraft:white_concrete
fill 136 248 287 136 249 288 minecraft:red_concrete
fill 136 248 289 136 249 290 minecraft:white_concrete
fill 136 248 291 136 249 292 minecraft:red_concrete
fill 136 248 293 136 249 294 minecraft:white_concrete
fill 136 248 295 136 249 296 minecraft:red_concrete
fill 136 248 297 136 249 298 minecraft:white_concrete
fill 136 248 299 136 249 300 minecraft:red_concrete
fill 136 248 301 136 249 302 minecraft:white_concrete
fill 136 248 303 136 249 304 minecraft:red_concrete
fill 136 248 305 136 249 306 minecraft:white_concrete
fill 136 248 307 136 249 308 minecraft:red_concrete
fill 136 248 309 136 249 310 minecraft:white_concrete
fill 136 248 311 136 249 312 minecraft:red_concrete
fill 136 248 313 136 249 314 minecraft:white_concrete
fill 136 248 315 136 249 316 minecraft:red_concrete
fill 136 248 317 136 249 317 minecraft:white_concrete
fill 97 249 285 97 249 286 minecraft:yellow_concrete
fill 98 249 279 98 249 282 minecraft:yellow_concrete
fill 98 249 284 98 250 285 minecraft:yellow_concrete
fill 98 249 287 98 249 313 minecraft:yellow_concrete
fill 99 249 279 132 249 279 minecraft:yellow_concrete
fill 99 249 313 100 249 313 minecraft:yellow_concrete
fill 102 249 313 132 249 313 minecraft:yellow_concrete
fill 132 249 280 132 249 312 minecraft:yellow_concrete
fill 94 250 275 94 251 276 minecraft:white_concrete
fill 94 250 277 94 251 278 minecraft:red_concrete
fill 94 250 279 94 251 280 minecraft:white_concrete
fill 94 250 281 94 251 282 minecraft:red_concrete
fill 94 250 283 94 251 284 minecraft:white_concrete
fill 94 250 285 94 251 286 minecraft:red_concrete
fill 94 250 287 94 251 288 minecraft:white_concrete
fill 94 250 289 94 251 290 minecraft:red_concrete
fill 94 250 291 94 251 292 minecraft:white_concrete
fill 94 250 293 94 251 294 minecraft:red_concrete
fill 94 250 295 94 251 296 minecraft:white_concrete
fill 94 250 297 94 251 298 minecraft:red_concrete
fill 94 250 299 94 251 300 minecraft:white_concrete
fill 94 250 301 94 251 302 minecraft:red_concrete
fill 94 250 303 94 251 304 minecraft:white_concrete
fill 94 250 305 94 251 306 minecraft:red_concrete
fill 94 250 307 94 251 308 minecraft:white_concrete
fill 94 250 309 94 251 310 minecraft:red_concrete
fill 94 250 311 94 251 312 minecraft:white_concrete
fill 94 250 313 94 251 314 minecraft:red_concrete
fill 94 250 315 94 251 316 minecraft:white_concrete
fill 95 250 275 95 251 275 minecraft:white_concrete
fill 95 250 317 95 251 317 minecraft:white_concrete
fill 96 250 275 97 251 275 minecraft:red_concrete
fill 96 250 317 97 251 317 minecraft:red_concrete
setblock 97 250 278 minecraft:light[level=15]
setblock 97 250 285 minecraft:yellow_concrete
setblock 97 250 286 minecraft:light[level=15]
setblock 97 250 294 minecraft:light[level=15]
setblock 97 250 302 minecraft:light[level=15]
setblock 97 250 310 minecraft:light[level=15]
fill 98 250 275 99 251 275 minecraft:white_concrete
fill 98 250 317 99 251 317 minecraft:white_concrete
fill 99 250 284 100 250 285 minecraft:yellow_concrete
fill 100 250 275 101 251 275 minecraft:red_concrete
fill 100 250 317 101 251 317 minecraft:red_concrete
setblock 101 250 285 minecraft:yellow_concrete
fill 102 250 275 103 251 275 minecraft:white_concrete
fill 102 250 317 103 251 317 minecraft:white_concrete
fill 104 250 275 105 251 275 minecraft:red_concrete
fill 104 250 317 105 251 317 minecraft:red_concrete
setblock 105 250 278 minecraft:light[level=15]
setblock 105 250 286 minecraft:light[level=15]
setblock 105 250 294 minecraft:light[level=15]
setblock 105 250 302 minecraft:light[level=15]
setblock 105 250 310 minecraft:light[level=15]
fill 106 250 275 107 251 275 minecraft:white_concrete
fill 106 250 317 107 251 317 minecraft:white_concrete
fill 108 250 275 109 251 275 minecraft:red_concrete
fill 108 250 317 109 251 317 minecraft:red_concrete
fill 110 250 275 111 251 275 minecraft:white_concrete
fill 110 250 317 111 251 317 minecraft:white_concrete
fill 112 250 275 113 251 275 minecraft:red_concrete
fill 112 250 317 113 251 317 minecraft:red_concrete
setblock 113 250 278 minecraft:light[level=15]
setblock 113 250 286 minecraft:light[level=15]
setblock 113 250 294 minecraft:light[level=15]
setblock 113 250 302 minecraft:light[level=15]
setblock 113 250 310 minecraft:light[level=15]
fill 114 250 275 115 251 275 minecraft:white_concrete
fill 114 250 317 115 251 317 minecraft:white_concrete
fill 116 250 275 117 251 275 minecraft:red_concrete
fill 116 250 317 117 251 317 minecraft:red_concrete
fill 118 250 275 119 251 275 minecraft:white_concrete
fill 118 250 317 119 251 317 minecraft:white_concrete
fill 120 250 275 121 251 275 minecraft:red_concrete
fill 120 250 317 121 251 317 minecraft:red_concrete
setblock 121 250 278 minecraft:light[level=15]
setblock 121 250 286 minecraft:light[level=15]
setblock 121 250 294 minecraft:light[level=15]
setblock 121 250 302 minecraft:light[level=15]
setblock 121 250 310 minecraft:light[level=15]
fill 122 250 275 123 251 275 minecraft:white_concrete
fill 122 250 317 123 251 317 minecraft:white_concrete
fill 124 250 275 125 251 275 minecraft:red_concrete
fill 124 250 296 124 251 297 minecraft:brown_terracotta
fill 124 250 317 125 251 317 minecraft:red_concrete
fill 126 250 275 127 251 275 minecraft:white_concrete
fill 126 250 317 127 251 317 minecraft:white_concrete
fill 128 250 275 129 251 275 minecraft:red_concrete
fill 128 250 317 129 251 317 minecraft:red_concrete
setblock 129 250 278 minecraft:light[level=15]
setblock 129 250 286 minecraft:light[level=15]
setblock 129 250 294 minecraft:light[level=15]
setblock 129 250 302 minecraft:light[level=15]
setblock 129 250 310 minecraft:light[level=15]
fill 130 250 275 131 251 275 minecraft:white_concrete
fill 130 250 317 131 251 317 minecraft:white_concrete
fill 132 250 275 133 251 275 minecraft:red_concrete
fill 132 250 317 133 251 317 minecraft:red_concrete
fill 134 250 275 135 251 275 minecraft:white_concrete
fill 134 250 317 135 251 317 minecraft:white_concrete
fill 136 250 276 136 251 276 minecraft:white_concrete
fill 136 250 277 136 251 278 minecraft:red_concrete
fill 136 250 279 136 251 280 minecraft:white_concrete
fill 136 250 281 136 251 282 minecraft:red_concrete
fill 136 250 283 136 251 284 minecraft:white_concrete
fill 136 250 285 136 251 286 minecraft:red_concrete
fill 136 250 287 136 251 288 minecraft:white_concrete
fill 136 250 289 136 251 290 minecraft:red_concrete
fill 136 250 291 136 251 292 minecraft:white_concrete
fill 136 250 293 136 251 294 minecraft:red_concrete
fill 136 250 295 136 251 296 minecraft:white_concrete
fill 136 250 297 136 251 298 minecraft:red_concrete
fill 136 250 299 136 251 300 minecraft:white_concrete
fill 136 250 301 136 251 302 minecraft:red_concrete
fill 136 250 303 136 251 304 minecraft:white_concrete
fill 136 250 305 136 251 306 minecraft:red_concrete
fill 136 250 307 136 251 308 minecraft:white_concrete
fill 136 250 309 136 251 310 minecraft:red_concrete
fill 136 250 311 136 251 312 minecraft:white_concrete
fill 136 250 313 136 251 314 minecraft:red_concrete
fill 136 250 315 136 251 316 minecraft:white_concrete
fill 136 250 317 136 251 317 minecraft:red_concrete
setblock 99 251 285 minecraft:yellow_concrete
fill 94 252 275 94 253 276 minecraft:red_concrete
fill 94 252 277 94 253 278 minecraft:white_concrete
fill 94 252 279 94 253 280 minecraft:red_concrete
fill 94 252 281 94 253 282 minecraft:white_concrete
fill 94 252 283 94 253 284 minecraft:red_concrete
fill 94 252 285 94 253 286 minecraft:white_concrete
fill 94 252 287 94 253 288 minecraft:red_concrete
fill 94 252 289 94 253 290 minecraft:white_concrete
fill 94 252 291 94 253 292 minecraft:red_concrete
fill 94 252 293 94 253 294 minecraft:white_concrete
fill 94 252 295 94 253 296 minecraft:red_concrete
fill 94 252 297 94 253 298 minecraft:white_concrete
fill 94 252 299 94 253 300 minecraft:red_concrete
fill 94 252 301 94 253 302 minecraft:white_concrete
fill 94 252 303 94 253 304 minecraft:red_concrete
fill 94 252 305 94 253 306 minecraft:white_concrete
fill 94 252 307 94 253 308 minecraft:red_concrete
fill 94 252 309 94 253 310 minecraft:white_concrete
fill 94 252 311 94 253 312 minecraft:red_concrete
fill 94 252 313 94 253 314 minecraft:white_concrete
fill 94 252 315 94 253 316 minecraft:red_concrete
fill 95 252 275 95 253 275 minecraft:red_concrete
fill 95 252 276 95 253 281 minecraft:red_terracotta
fill 95 252 284 96 252 289 minecraft:red_terracotta
fill 95 252 292 96 252 297 minecraft:red_terracotta
fill 95 252 300 96 252 305 minecraft:red_terracotta
fill 95 252 308 96 252 313 minecraft:red_terracotta
fill 95 252 316 100 253 316 minecraft:red_terracotta
fill 95 252 317 95 253 317 minecraft:red_concrete
fill 96 252 275 97 253 275 minecraft:white_concrete
fill 96 252 277 96 252 283 minecraft:red_terracotta
fill 96 252 290 96 252 291 minecraft:red_terracotta
fill 96 252 298 96 252 299 minecraft:red_terracotta
fill 96 252 306 96 252 307 minecraft:red_terracotta
fill 96 252 314 96 252 315 minecraft:red_terracotta
fill 96 252 317 97 253 317 minecraft:white_concrete
fill 97 252 277 134 252 277 minecraft:red_terracotta
fill 97 252 315 135 252 315 minecraft:red_terracotta
fill 98 252 275 99 253 275 minecraft:red_concrete
fill 98 252 276 103 253 276 minecraft:red_terracotta
fill 98 252 317 99 253 317 minecraft:red_concrete
fill 100 252 275 101 253 275 minecraft:white_concrete
fill 100 252 317 101 253 317 minecraft:white_concrete
fill 102 252 275 103 253 275 minecraft:red_concrete
fill 102 252 317 103 253 317 minecraft:red_concrete
fill 103 252 316 108 253 316 minecraft:red_terracotta
fill 104 252 275 105 253 275 minecraft:white_concrete
fill 104 252 317 105 253 317 minecraft:white_concrete
fill 106 252 275 107 253 275 minecraft:red_concrete
fill 106 252 276 111 253 276 minecraft:red_terracotta
fill 106 252 317 107 253 317 minecraft:red_concrete
fill 108 252 275 109 253 275 minecraft:white_concrete
fill 108 252 317 109 253 317 minecraft:white_concrete
fill 110 252 275 111 253 275 minecraft:red_concrete
fill 110 252 317 111 253 317 minecraft:red_concrete
fill 111 252 316 116 253 316 minecraft:red_terracotta
fill 112 252 275 113 253 275 minecraft:white_concrete
fill 112 252 317 113 253 317 minecraft:white_concrete
fill 114 252 275 115 253 275 minecraft:red_concrete
fill 114 252 276 119 253 276 minecraft:red_terracotta
fill 114 252 317 115 253 317 minecraft:red_concrete
fill 116 252 275 117 253 275 minecraft:white_concrete
fill 116 252 317 117 253 317 minecraft:white_concrete
fill 118 252 275 119 253 275 minecraft:red_concrete
fill 118 252 317 119 253 317 minecraft:red_concrete
fill 119 252 316 124 253 316 minecraft:red_terracotta
fill 120 252 275 121 253 275 minecraft:white_concrete
fill 120 252 317 121 253 317 minecraft:white_concrete
fill 122 252 275 123 253 275 minecraft:red_concrete
fill 122 252 276 127 253 276 minecraft:red_terracotta
fill 122 252 317 123 253 317 minecraft:red_concrete
fill 124 252 275 125 253 275 minecraft:white_concrete
fill 124 252 317 125 253 317 minecraft:white_concrete
fill 126 252 275 127 253 275 minecraft:red_concrete
fill 126 252 317 127 253 317 minecraft:red_concrete
fill 127 252 316 132 253 316 minecraft:red_terracotta
fill 128 252 275 129 253 275 minecraft:white_concrete
fill 128 252 317 129 253 317 minecraft:white_concrete
fill 130 252 275 131 253 275 minecraft:red_concrete
fill 130 252 276 135 253 276 minecraft:red_terracotta
fill 130 252 317 131 253 317 minecraft:red_concrete
fill 131 252 298 131 255 298 minecraft:iron_block
fill 132 252 275 133 253 275 minecraft:white_concrete
fill 132 252 317 133 253 317 minecraft:white_concrete
fill 134 252 275 135 253 275 minecraft:red_concrete
fill 134 252 278 134 252 314 minecraft:red_terracotta
fill 134 252 317 135 253 317 minecraft:red_concrete
fill 135 252 279 135 253 284 minecraft:red_terracotta
fill 135 252 287 135 253 292 minecraft:red_terracotta
fill 135 252 295 135 253 300 minecraft:red_terracotta
fill 135 252 303 135 253 308 minecraft:red_terracotta
fill 135 252 311 135 253 314 minecraft:red_terracotta
fill 135 252 316 135 253 316 minecraft:red_terracotta
fill 136 252 276 136 253 276 minecraft:red_concrete
fill 136 252 277 136 253 278 minecraft:white_concrete
fill 136 252 279 136 253 280 minecraft:red_concrete
fill 136 252 281 136 253 282 minecraft:white_concrete
fill 136 252 283 136 253 284 minecraft:red_concrete
fill 136 252 285 136 253 286 minecraft:white_concrete
fill 136 252 287 136 253 288 minecraft:red_concrete
fill 136 252 289 136 253 290 minecraft:white_concrete
fill 136 252 291 136 253 292 minecraft:red_concrete
fill 136 252 293 136 253 294 minecraft:white_concrete
fill 136 252 295 136 253 296 minecraft:red_concrete
fill 136 252 297 136 253 298 minecraft:white_concrete
fill 136 252 299 136 253 300 minecraft:red_concrete
fill 136 252 301 136 253 302 minecraft:white_concrete
fill 136 252 303 136 253 304 minecraft:red_concrete
fill 136 252 305 136 253 306 minecraft:white_concrete
fill 136 252 307 136 253 308 minecraft:red_concrete
fill 136 252 309 136 253 310 minecraft:white_concrete
fill 136 252 311 136 253 312 minecraft:red_concrete
fill 136 252 313 136 253 314 minecraft:white_concrete
fill 136 252 315 136 253 316 minecraft:red_concrete
fill 136 252 317 136 253 317 minecraft:white_concrete
fill 95 253 284 95 253 289 minecraft:red_terracotta
fill 95 253 292 95 253 297 minecraft:red_terracotta
fill 95 253 300 95 253 305 minecraft:red_terracotta
fill 95 253 308 95 253 313 minecraft:red_terracotta
setblock 135 253 315 minecraft:red_terracotta
fill 94 254 275 94 255 276 minecraft:white_concrete
fill 94 254 277 94 255 278 minecraft:red_concrete
fill 94 254 279 94 255 280 minecraft:white_concrete
fill 94 254 281 94 255 282 minecraft:red_concrete
fill 94 254 283 94 255 284 minecraft:white_concrete
fill 94 254 285 94 255 286 minecraft:red_concrete
fill 94 254 287 94 255 288 minecraft:white_concrete
fill 94 254 289 94 255 290 minecraft:red_concrete
fill 94 254 291 94 255 292 minecraft:white_concrete
fill 94 254 293 94 255 294 minecraft:red_concrete
fill 94 254 295 94 255 296 minecraft:white_concrete
fill 94 254 297 94 255 298 minecraft:red_concrete
fill 94 254 299 94 255 300 minecraft:white_concrete
fill 94 254 301 94 255 302 minecraft:red_concrete
fill 94 254 303 94 255 304 minecraft:white_concrete
fill 94 254 305 94 255 306 minecraft:red_concrete
fill 94 254 307 94 255 308 minecraft:white_concrete
fill 94 254 309 94 255 310 minecraft:red_concrete
fill 94 254 311 94 255 312 minecraft:white_concrete
fill 94 254 313 94 255 314 minecraft:red_concrete
fill 94 254 315 94 255 316 minecraft:white_concrete
fill 95 254 275 95 255 275 minecraft:white_concrete
fill 95 254 317 95 255 317 minecraft:white_concrete
fill 96 254 275 97 255 275 minecraft:red_concrete
fill 96 254 317 97 255 317 minecraft:red_concrete
setblock 97 254 278 minecraft:light[level=12]
setblock 97 254 285 minecraft:light[level=12]
setblock 97 254 292 minecraft:light[level=12]
setblock 97 254 299 minecraft:light[level=12]
setblock 97 254 306 minecraft:light[level=12]
setblock 97 254 313 minecraft:light[level=12]
fill 98 254 275 99 255 275 minecraft:white_concrete
fill 98 254 317 99 255 317 minecraft:white_concrete
fill 100 254 275 101 255 275 minecraft:red_concrete
fill 100 254 317 101 255 317 minecraft:red_concrete
fill 102 254 275 103 255 275 minecraft:white_concrete
fill 102 254 317 103 255 317 minecraft:white_concrete
fill 104 254 275 105 255 275 minecraft:red_concrete
setblock 104 254 278 minecraft:light[level=12]
setblock 104 254 285 minecraft:light[level=12]
setblock 104 254 292 minecraft:light[level=12]
setblock 104 254 299 minecraft:light[level=12]
setblock 104 254 306 minecraft:light[level=12]
setblock 104 254 313 minecraft:light[level=12]
fill 104 254 317 105 255 317 minecraft:red_concrete
fill 106 254 275 107 255 275 minecraft:white_concrete
fill 106 254 317 107 255 317 minecraft:white_concrete
fill 108 254 275 109 255 275 minecraft:red_concrete
fill 108 254 317 109 255 317 minecraft:red_concrete
fill 110 254 275 111 255 275 minecraft:white_concrete
fill 110 254 317 111 255 317 minecraft:white_concrete
setblock 111 254 278 minecraft:light[level=12]
setblock 111 254 285 minecraft:light[level=12]
setblock 111 254 292 minecraft:light[level=12]
setblock 111 254 299 minecraft:light[level=12]
setblock 111 254 306 minecraft:light[level=12]
setblock 111 254 313 minecraft:light[level=12]
fill 112 254 275 113 255 275 minecraft:red_concrete
fill 112 254 317 113 255 317 minecraft:red_concrete
fill 114 254 275 115 255 275 minecraft:white_concrete
fill 114 254 317 115 255 317 minecraft:white_concrete
fill 116 254 275 117 255 275 minecraft:red_concrete
fill 116 254 317 117 255 317 minecraft:red_concrete
fill 118 254 275 119 255 275 minecraft:white_concrete
setblock 118 254 278 minecraft:light[level=12]
setblock 118 254 285 minecraft:light[level=12]
setblock 118 254 292 minecraft:light[level=12]
setblock 118 254 299 minecraft:light[level=12]
setblock 118 254 306 minecraft:light[level=12]
setblock 118 254 313 minecraft:light[level=12]
fill 118 254 317 119 255 317 minecraft:white_concrete
fill 120 254 275 121 255 275 minecraft:red_concrete
fill 120 254 317 121 255 317 minecraft:red_concrete
fill 122 254 275 123 255 275 minecraft:white_concrete
fill 122 254 317 123 255 317 minecraft:white_concrete
fill 124 254 275 125 255 275 minecraft:red_concrete
fill 124 254 317 125 255 317 minecraft:red_concrete
setblock 125 254 278 minecraft:light[level=12]
setblock 125 254 285 minecraft:light[level=12]
setblock 125 254 292 minecraft:light[level=12]
setblock 125 254 299 minecraft:light[level=12]
setblock 125 254 306 minecraft:light[level=12]
setblock 125 254 313 minecraft:light[level=12]
fill 126 254 275 127 255 275 minecraft:white_concrete
fill 126 254 317 127 255 317 minecraft:white_concrete
fill 128 254 275 129 255 275 minecraft:red_concrete
fill 128 254 317 129 255 317 minecraft:red_concrete
fill 130 254 275 131 255 275 minecraft:white_concrete
fill 130 254 317 131 255 317 minecraft:white_concrete
fill 132 254 275 133 255 275 minecraft:red_concrete
setblock 132 254 278 minecraft:light[level=12]
setblock 132 254 285 minecraft:light[level=12]
setblock 132 254 292 minecraft:light[level=12]
setblock 132 254 299 minecraft:light[level=12]
setblock 132 254 306 minecraft:light[level=12]
setblock 132 254 313 minecraft:light[level=12]
fill 132 254 317 133 255 317 minecraft:red_concrete
fill 134 254 275 135 255 275 minecraft:white_concrete
fill 134 254 317 135 255 317 minecraft:white_concrete
fill 136 254 276 136 255 276 minecraft:white_concrete
fill 136 254 277 136 255 278 minecraft:red_concrete
fill 136 254 279 136 255 280 minecraft:white_concrete
fill 136 254 281 136 255 282 minecraft:red_concrete
fill 136 254 283 136 255 284 minecraft:white_concrete
fill 136 254 285 136 255 286 minecraft:red_concrete
fill 136 254 287 136 255 288 minecraft:white_concrete
fill 136 254 289 136 255 290 minecraft:red_concrete
fill 136 254 291 136 255 292 minecraft:white_concrete
fill 136 254 293 136 255 294 minecraft:red_concrete
fill 136 254 295 136 255 296 minecraft:white_concrete
fill 136 254 297 136 255 298 minecraft:red_concrete
fill 136 254 299 136 255 300 minecraft:white_concrete
fill 136 254 301 136 255 302 minecraft:red_concrete
fill 136 254 303 136 255 304 minecraft:white_concrete
fill 136 254 305 136 255 306 minecraft:red_concrete
fill 136 254 307 136 255 308 minecraft:white_concrete
fill 136 254 309 136 255 310 minecraft:red_concrete
fill 136 254 311 136 255 312 minecraft:white_concrete
fill 136 254 313 136 255 314 minecraft:red_concrete
fill 136 254 315 136 255 316 minecraft:white_concrete
fill 136 254 317 136 255 317 minecraft:red_concrete
fill 125 255 296 125 256 296 minecraft:yellow_wool
fill 94 256 275 94 257 276 minecraft:red_concrete
fill 94 256 277 94 257 278 minecraft:white_concrete
fill 94 256 279 94 257 279 minecraft:red_concrete
fill 94 256 280 94 261 280 minecraft:shroomlight
fill 94 256 281 94 257 282 minecraft:white_concrete
fill 94 256 283 94 257 284 minecraft:red_concrete
fill 94 256 285 94 257 286 minecraft:white_concrete
fill 94 256 287 94 257 287 minecraft:red_concrete
fill 94 256 288 94 261 288 minecraft:shroomlight
fill 94 256 289 94 257 290 minecraft:white_concrete
fill 94 256 291 94 257 292 minecraft:red_concrete
fill 94 256 293 94 257 294 minecraft:white_concrete
fill 94 256 295 94 257 295 minecraft:red_concrete
fill 94 256 296 94 261 296 minecraft:shroomlight
fill 94 256 297 94 257 298 minecraft:white_concrete
fill 94 256 299 94 257 300 minecraft:red_concrete
fill 94 256 301 94 257 302 minecraft:white_concrete
fill 94 256 303 94 257 303 minecraft:red_concrete
fill 94 256 304 94 261 304 minecraft:shroomlight
fill 94 256 305 94 257 306 minecraft:white_concrete
fill 94 256 307 94 257 308 minecraft:red_concrete
fill 94 256 309 94 257 310 minecraft:white_concrete
fill 94 256 311 94 257 311 minecraft:red_concrete
fill 94 256 312 94 261 312 minecraft:shroomlight
fill 94 256 313 94 257 314 minecraft:white_concrete
fill 94 256 315 94 257 316 minecraft:red_concrete
fill 95 256 275 95 257 275 minecraft:red_concrete
fill 95 256 317 95 257 317 minecraft:red_concrete
fill 96 256 275 97 257 275 minecraft:white_concrete
fill 96 256 317 96 257 317 minecraft:white_concrete
fill 97 256 317 97 261 317 minecraft:shroomlight
fill 98 256 275 99 257 275 minecraft:red_concrete
fill 98 256 317 99 257 317 minecraft:red_concrete
fill 100 256 275 100 257 275 minecraft:white_concrete
fill 100 256 317 101 257 317 minecraft:white_concrete
fill 101 256 275 101 261 275 minecraft:shroomlight
fill 102 256 275 103 257 275 minecraft:red_concrete
fill 102 256 317 103 257 317 minecraft:red_concrete
fill 104 256 275 105 257 275 minecraft:white_concrete
fill 104 256 317 104 257 317 minecraft:white_concrete
fill 105 256 317 105 261 317 minecraft:shroomlight
fill 106 256 275 107 257 275 minecraft:red_concrete
fill 106 256 317 107 257 317 minecraft:red_concrete
fill 108 256 275 108 257 275 minecraft:white_concrete
fill 108 256 317 109 257 317 minecraft:white_concrete
fill 109 256 275 109 261 275 minecraft:shroomlight
fill 110 256 275 111 257 275 minecraft:red_concrete
fill 110 256 317 111 257 317 minecraft:red_concrete
fill 112 256 275 113 257 275 minecraft:white_concrete
fill 112 256 317 112 257 317 minecraft:white_concrete
fill 113 256 317 113 261 317 minecraft:shroomlight
fill 114 256 275 115 257 275 minecraft:red_concrete
fill 114 256 317 115 257 317 minecraft:red_concrete
fill 116 256 275 116 257 275 minecraft:white_concrete
fill 116 256 317 117 257 317 minecraft:white_concrete
fill 117 256 275 117 261 275 minecraft:shroomlight
fill 118 256 275 119 257 275 minecraft:red_concrete
fill 118 256 317 119 257 317 minecraft:red_concrete
fill 120 256 275 121 257 275 minecraft:white_concrete
fill 120 256 317 120 257 317 minecraft:white_concrete
fill 121 256 317 121 261 317 minecraft:shroomlight
fill 122 256 275 123 257 275 minecraft:red_concrete
fill 122 256 317 123 257 317 minecraft:red_concrete
fill 124 256 275 124 257 275 minecraft:white_concrete
fill 124 256 317 125 257 317 minecraft:white_concrete
fill 125 256 275 125 261 275 minecraft:shroomlight
fill 126 256 275 127 257 275 minecraft:red_concrete
fill 126 256 317 127 257 317 minecraft:red_concrete
fill 128 256 275 129 257 275 minecraft:white_concrete
fill 128 256 317 128 257 317 minecraft:white_concrete
fill 129 256 317 129 261 317 minecraft:shroomlight
fill 130 256 275 131 257 275 minecraft:red_concrete
fill 130 256 317 131 257 317 minecraft:red_concrete
fill 131 256 294 134 256 302 minecraft:brown_terracotta
fill 132 256 275 132 257 275 minecraft:white_concrete
fill 132 256 317 133 257 317 minecraft:white_concrete
fill 133 256 275 133 261 275 minecraft:shroomlight
fill 134 256 275 135 257 275 minecraft:red_concrete
fill 134 256 317 135 257 317 minecraft:red_concrete
fill 136 256 276 136 257 276 minecraft:red_concrete
fill 136 256 277 136 257 278 minecraft:white_concrete
fill 136 256 279 136 257 279 minecraft:red_concrete
fill 136 256 280 136 261 280 minecraft:shroomlight
fill 136 256 281 136 257 282 minecraft:white_concrete
fill 136 256 283 136 257 284 minecraft:red_concrete
fill 136 256 285 136 257 286 minecraft:white_concrete
fill 136 256 287 136 257 287 minecraft:red_concrete
fill 136 256 288 136 261 288 minecraft:shroomlight
fill 136 256 289 136 257 290 minecraft:white_concrete
fill 136 256 291 136 257 292 minecraft:red_concrete
fill 136 256 293 136 257 294 minecraft:white_concrete
fill 136 256 295 136 257 295 minecraft:red_concrete
fill 136 256 296 136 261 296 minecraft:shroomlight
fill 136 256 297 136 257 298 minecraft:white_concrete
fill 136 256 299 136 257 300 minecraft:red_concrete
fill 136 256 301 136 257 302 minecraft:white_concrete
fill 136 256 303 136 257 303 minecraft:red_concrete
fill 136 256 304 136 261 304 minecraft:shroomlight
fill 136 256 305 136 257 306 minecraft:white_concrete
fill 136 256 307 136 257 308 minecraft:red_concrete
fill 136 256 309 136 257 310 minecraft:white_concrete
fill 136 256 311 136 257 311 minecraft:red_concrete
fill 136 256 312 136 261 312 minecraft:shroomlight
fill 136 256 313 136 257 314 minecraft:white_concrete
fill 136 256 315 136 257 316 minecraft:red_concrete
fill 136 256 317 136 257 317 minecraft:white_concrete
fill 131 257 294 134 257 302 minecraft:red_terracotta
fill 94 258 275 94 259 276 minecraft:white_concrete
fill 94 258 277 94 259 278 minecraft:red_concrete
fill 94 258 279 94 259 279 minecraft:white_concrete
fill 94 258 281 94 259 282 minecraft:red_concrete
fill 94 258 283 94 259 284 minecraft:white_concrete
fill 94 258 285 94 259 286 minecraft:red_concrete
fill 94 258 287 94 259 287 minecraft:white_concrete
fill 94 258 289 94 259 290 minecraft:red_concrete
fill 94 258 291 94 259 292 minecraft:white_concrete
fill 94 258 293 94 259 294 minecraft:red_concrete
fill 94 258 295 94 259 295 minecraft:white_concrete
fill 94 258 297 94 259 298 minecraft:red_concrete
fill 94 258 299 94 259 300 minecraft:white_concrete
fill 94 258 301 94 259 302 minecraft:red_concrete
fill 94 258 303 94 259 303 minecraft:white_concrete
fill 94 258 305 94 259 306 minecraft:red_concrete
schedule function dropper:buildpart/62_6 1t
