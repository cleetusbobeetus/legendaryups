setblock 498 131 264 minecraft:magenta_concrete
fill 499 131 259 500 131 260 minecraft:shroomlight
fill 499 131 268 500 131 269 minecraft:shroomlight
fill 500 131 261 500 131 267 minecraft:shroomlight
fill 501 131 262 501 131 266 minecraft:shroomlight
fill 508 131 229 509 131 230 minecraft:white_concrete
fill 508 131 232 508 135 233 minecraft:white_concrete
fill 508 131 265 509 131 266 minecraft:white_concrete
fill 508 131 268 508 135 269 minecraft:white_concrete
setblock 510 131 229 minecraft:white_concrete
fill 510 131 230 511 134 230 minecraft:red_concrete
setblock 510 131 265 minecraft:white_concrete
fill 510 131 266 511 134 266 minecraft:red_concrete
fill 472 132 229 472 132 230 minecraft:white_concrete
fill 472 132 265 472 132 266 minecraft:white_concrete
fill 473 132 229 473 136 230 minecraft:red_concrete
fill 473 132 232 473 136 233 minecraft:white_concrete
fill 473 132 265 473 136 266 minecraft:red_concrete
fill 473 132 268 473 136 269 minecraft:white_concrete
fill 474 132 229 474 135 229 minecraft:red_concrete
fill 474 132 265 474 135 265 minecraft:red_concrete
fill 508 132 229 508 132 230 minecraft:white_concrete
fill 508 132 265 508 132 266 minecraft:white_concrete
fill 509 132 229 509 136 230 minecraft:red_concrete
fill 509 132 232 509 136 233 minecraft:white_concrete
fill 509 132 265 509 136 266 minecraft:red_concrete
fill 509 132 268 509 136 269 minecraft:white_concrete
fill 510 132 229 510 135 229 minecraft:red_concrete
fill 510 132 265 510 135 265 minecraft:red_concrete
fill 472 133 229 472 137 229 minecraft:red_concrete
setblock 472 133 230 minecraft:white_concrete
fill 472 133 265 472 137 265 minecraft:red_concrete
setblock 472 133 266 minecraft:white_concrete
setblock 473 133 239 minecraft:light[level=15]
setblock 473 133 247 minecraft:light[level=15]
setblock 473 133 255 minecraft:light[level=15]
setblock 473 133 263 minecraft:light[level=15]
fill 474 133 232 474 137 233 minecraft:white_concrete
fill 474 133 268 474 137 269 minecraft:white_concrete
setblock 475 133 232 minecraft:red_concrete
setblock 475 133 268 minecraft:red_concrete
setblock 481 133 231 minecraft:light[level=15]
setblock 481 133 239 minecraft:light[level=15]
setblock 481 133 247 minecraft:light[level=15]
setblock 481 133 255 minecraft:light[level=15]
setblock 481 133 263 minecraft:light[level=15]
setblock 489 133 231 minecraft:light[level=15]
setblock 489 133 239 minecraft:light[level=15]
setblock 489 133 247 minecraft:light[level=15]
setblock 489 133 255 minecraft:light[level=15]
setblock 497 133 231 minecraft:light[level=15]
setblock 497 133 239 minecraft:light[level=15]
setblock 497 133 247 minecraft:light[level=15]
setblock 497 133 255 minecraft:light[level=15]
setblock 505 133 231 minecraft:light[level=15]
setblock 505 133 239 minecraft:light[level=15]
setblock 505 133 247 minecraft:light[level=15]
setblock 505 133 255 minecraft:light[level=15]
setblock 505 133 263 minecraft:light[level=15]
fill 508 133 229 508 137 229 minecraft:red_concrete
setblock 508 133 230 minecraft:white_concrete
fill 508 133 265 508 137 265 minecraft:red_concrete
setblock 508 133 266 minecraft:white_concrete
fill 510 133 232 510 137 233 minecraft:white_concrete
fill 510 133 268 510 137 269 minecraft:white_concrete
setblock 511 133 232 minecraft:red_concrete
setblock 511 133 268 minecraft:red_concrete
fill 471 134 230 472 137 230 minecraft:red_concrete
fill 471 134 266 472 137 266 minecraft:red_concrete
fill 475 134 232 475 138 232 minecraft:white_concrete
fill 475 134 268 475 138 268 minecraft:white_concrete
fill 507 134 230 508 137 230 minecraft:red_concrete
fill 507 134 266 508 137 266 minecraft:red_concrete
fill 511 134 232 511 138 232 minecraft:white_concrete
fill 511 134 268 511 138 268 minecraft:white_concrete
fill 471 135 231 472 139 231 minecraft:red_concrete
setblock 471 135 232 minecraft:white_concrete
fill 471 135 267 472 139 267 minecraft:red_concrete
setblock 471 135 268 minecraft:white_concrete
fill 473 135 231 475 139 231 minecraft:white_concrete
fill 473 135 267 475 139 267 minecraft:white_concrete
setblock 474 135 230 minecraft:red_concrete
setblock 474 135 266 minecraft:red_concrete
fill 475 135 230 475 140 230 minecraft:white_concrete
fill 475 135 266 475 140 266 minecraft:white_concrete
fill 487 135 267 495 135 267 minecraft:magenta_concrete
fill 489 135 269 493 135 269 minecraft:magenta_concrete
fill 507 135 231 508 139 231 minecraft:red_concrete
setblock 507 135 232 minecraft:white_concrete
fill 507 135 267 508 139 267 minecraft:red_concrete
setblock 507 135 268 minecraft:white_concrete
fill 509 135 231 511 139 231 minecraft:white_concrete
fill 509 135 267 511 139 267 minecraft:white_concrete
setblock 510 135 230 minecraft:red_concrete
setblock 510 135 266 minecraft:red_concrete
fill 511 135 230 511 140 230 minecraft:white_concrete
fill 511 135 266 511 140 266 minecraft:white_concrete
fill 471 136 232 472 139 232 minecraft:red_concrete
fill 471 136 268 472 139 268 minecraft:red_concrete
setblock 472 136 233 minecraft:white_concrete
setblock 472 136 269 minecraft:white_concrete
setblock 473 136 238 minecraft:light[level=12]
setblock 473 136 245 minecraft:light[level=12]
setblock 473 136 252 minecraft:light[level=12]
setblock 473 136 259 minecraft:light[level=12]
fill 474 136 229 474 140 230 minecraft:white_concrete
fill 474 136 265 474 140 266 minecraft:white_concrete
setblock 480 136 231 minecraft:light[level=12]
setblock 480 136 238 minecraft:light[level=12]
setblock 480 136 245 minecraft:light[level=12]
setblock 480 136 252 minecraft:light[level=12]
setblock 480 136 259 minecraft:light[level=12]
setblock 480 136 266 minecraft:light[level=12]
setblock 487 136 231 minecraft:light[level=12]
setblock 487 136 238 minecraft:light[level=12]
setblock 487 136 245 minecraft:light[level=12]
setblock 487 136 252 minecraft:light[level=12]
setblock 487 136 259 minecraft:light[level=12]
fill 488 136 267 494 136 267 minecraft:magenta_concrete
fill 489 136 268 493 136 268 minecraft:magenta_concrete
setblock 494 136 231 minecraft:light[level=12]
setblock 494 136 238 minecraft:light[level=12]
setblock 494 136 245 minecraft:light[level=12]
setblock 494 136 252 minecraft:light[level=12]
setblock 494 136 259 minecraft:light[level=12]
setblock 501 136 231 minecraft:light[level=12]
setblock 501 136 238 minecraft:light[level=12]
setblock 501 136 245 minecraft:light[level=12]
setblock 501 136 252 minecraft:light[level=12]
setblock 501 136 259 minecraft:light[level=12]
setblock 501 136 266 minecraft:light[level=12]
fill 507 136 232 508 139 232 minecraft:red_concrete
fill 507 136 268 508 139 268 minecraft:red_concrete
setblock 508 136 233 minecraft:white_concrete
setblock 508 136 238 minecraft:light[level=12]
setblock 508 136 245 minecraft:light[level=12]
setblock 508 136 252 minecraft:light[level=12]
setblock 508 136 259 minecraft:light[level=12]
setblock 508 136 269 minecraft:white_concrete
fill 510 136 229 510 140 230 minecraft:white_concrete
fill 510 136 265 510 140 266 minecraft:white_concrete
fill 472 137 233 473 140 233 minecraft:red_concrete
fill 472 137 269 473 140 269 minecraft:red_concrete
fill 473 137 229 473 141 230 minecraft:white_concrete
fill 473 137 232 473 141 232 minecraft:red_concrete
fill 473 137 265 473 141 266 minecraft:white_concrete
fill 473 137 268 473 141 268 minecraft:red_concrete
fill 489 137 267 493 137 267 minecraft:magenta_concrete
fill 508 137 233 509 140 233 minecraft:red_concrete
fill 508 137 269 509 140 269 minecraft:red_concrete
fill 509 137 229 509 141 230 minecraft:white_concrete
fill 509 137 232 509 141 232 minecraft:red_concrete
fill 509 137 265 509 141 266 minecraft:white_concrete
fill 509 137 268 509 141 268 minecraft:red_concrete
setblock 471 138 230 minecraft:red_concrete
setblock 471 138 266 minecraft:red_concrete
fill 472 138 229 472 142 230 minecraft:white_concrete
fill 472 138 265 472 142 266 minecraft:white_concrete
setblock 474 138 232 minecraft:white_concrete
fill 474 138 233 474 142 233 minecraft:red_concrete
setblock 474 138 268 minecraft:white_concrete
fill 474 138 269 474 142 269 minecraft:red_concrete
setblock 507 138 230 minecraft:red_concrete
setblock 507 138 266 minecraft:red_concrete
fill 508 138 229 508 142 230 minecraft:white_concrete
fill 508 138 265 508 142 266 minecraft:white_concrete
setblock 510 138 232 minecraft:white_concrete
fill 510 138 233 510 142 233 minecraft:red_concrete
setblock 510 138 268 minecraft:white_concrete
fill 510 138 269 510 142 269 minecraft:red_concrete
fill 471 139 230 471 143 230 minecraft:white_concrete
fill 471 139 266 471 143 266 minecraft:white_concrete
fill 474 139 232 475 142 232 minecraft:red_concrete
fill 474 139 268 475 142 268 minecraft:red_concrete
fill 507 139 230 507 143 230 minecraft:white_concrete
fill 507 139 266 507 143 266 minecraft:white_concrete
fill 510 139 232 511 142 232 minecraft:red_concrete
fill 510 139 268 511 142 268 minecraft:red_concrete
fill 471 140 231 471 144 232 minecraft:white_concrete
fill 471 140 267 471 144 268 minecraft:white_concrete
fill 472 140 231 472 144 231 minecraft:white_concrete
setblock 472 140 232 minecraft:red_concrete
fill 472 140 267 472 144 267 minecraft:white_concrete
setblock 472 140 268 minecraft:red_concrete
fill 473 140 231 475 144 231 minecraft:red_concrete
setblock 473 140 239 minecraft:light[level=15]
setblock 473 140 247 minecraft:light[level=15]
setblock 473 140 255 minecraft:light[level=15]
setblock 473 140 263 minecraft:light[level=15]
fill 473 140 267 475 144 267 minecraft:red_concrete
setblock 481 140 231 minecraft:light[level=15]
setblock 481 140 239 minecraft:light[level=15]
setblock 481 140 247 minecraft:light[level=15]
setblock 481 140 255 minecraft:light[level=15]
setblock 481 140 263 minecraft:light[level=15]
setblock 489 140 231 minecraft:light[level=15]
setblock 489 140 239 minecraft:light[level=15]
setblock 489 140 247 minecraft:light[level=15]
setblock 489 140 255 minecraft:light[level=15]
setblock 489 140 263 minecraft:light[level=15]
setblock 497 140 231 minecraft:light[level=15]
setblock 497 140 239 minecraft:light[level=15]
setblock 497 140 247 minecraft:light[level=15]
setblock 497 140 255 minecraft:light[level=15]
setblock 497 140 263 minecraft:light[level=15]
setblock 505 140 231 minecraft:light[level=15]
setblock 505 140 239 minecraft:light[level=15]
setblock 505 140 247 minecraft:light[level=15]
setblock 505 140 255 minecraft:light[level=15]
setblock 505 140 263 minecraft:light[level=15]
fill 507 140 231 507 144 232 minecraft:white_concrete
fill 507 140 267 507 144 268 minecraft:white_concrete
fill 508 140 231 508 144 231 minecraft:white_concrete
setblock 508 140 232 minecraft:red_concrete
fill 508 140 267 508 144 267 minecraft:white_concrete
setblock 508 140 268 minecraft:red_concrete
fill 509 140 231 511 144 231 minecraft:red_concrete
fill 509 140 267 511 144 267 minecraft:red_concrete
fill 472 141 232 472 145 233 minecraft:white_concrete
fill 472 141 268 472 145 269 minecraft:white_concrete
setblock 473 141 233 minecraft:red_concrete
setblock 473 141 269 minecraft:red_concrete
setblock 474 141 229 minecraft:white_concrete
fill 474 141 230 475 144 230 minecraft:red_concrete
setblock 474 141 265 minecraft:white_concrete
fill 474 141 266 475 144 266 minecraft:red_concrete
fill 508 141 232 508 145 233 minecraft:white_concrete
fill 508 141 268 508 145 269 minecraft:white_concrete
setblock 509 141 233 minecraft:red_concrete
setblock 509 141 269 minecraft:red_concrete
setblock 510 141 229 minecraft:white_concrete
fill 510 141 230 511 144 230 minecraft:red_concrete
setblock 510 141 265 minecraft:white_concrete
fill 510 141 266 511 144 266 minecraft:red_concrete
fill 473 142 229 473 146 230 minecraft:red_concrete
fill 473 142 232 473 146 233 minecraft:white_concrete
setblock 473 142 238 minecraft:light[level=12]
setblock 473 142 245 minecraft:light[level=12]
setblock 473 142 252 minecraft:light[level=12]
setblock 473 142 259 minecraft:light[level=12]
fill 473 142 265 473 146 266 minecraft:red_concrete
fill 473 142 268 473 146 269 minecraft:white_concrete
fill 474 142 229 474 145 229 minecraft:red_concrete
fill 474 142 265 474 145 265 minecraft:red_concrete
setblock 480 142 231 minecraft:light[level=12]
setblock 480 142 238 minecraft:light[level=12]
setblock 480 142 245 minecraft:light[level=12]
setblock 480 142 252 minecraft:light[level=12]
setblock 480 142 259 minecraft:light[level=12]
setblock 480 142 266 minecraft:light[level=12]
setblock 487 142 231 minecraft:light[level=12]
setblock 487 142 238 minecraft:light[level=12]
setblock 487 142 245 minecraft:light[level=12]
setblock 487 142 252 minecraft:light[level=12]
setblock 487 142 259 minecraft:light[level=12]
setblock 487 142 266 minecraft:light[level=12]
setblock 494 142 231 minecraft:light[level=12]
setblock 494 142 238 minecraft:light[level=12]
setblock 494 142 245 minecraft:light[level=12]
setblock 494 142 252 minecraft:light[level=12]
setblock 494 142 259 minecraft:light[level=12]
setblock 494 142 266 minecraft:light[level=12]
setblock 501 142 231 minecraft:light[level=12]
setblock 501 142 238 minecraft:light[level=12]
setblock 501 142 245 minecraft:light[level=12]
setblock 501 142 252 minecraft:light[level=12]
setblock 501 142 259 minecraft:light[level=12]
setblock 501 142 266 minecraft:light[level=12]
setblock 508 142 238 minecraft:light[level=12]
setblock 508 142 245 minecraft:light[level=12]
setblock 508 142 252 minecraft:light[level=12]
setblock 508 142 259 minecraft:light[level=12]
fill 509 142 229 509 146 230 minecraft:red_concrete
fill 509 142 232 509 146 233 minecraft:white_concrete
fill 509 142 265 509 146 266 minecraft:red_concrete
fill 509 142 268 509 146 269 minecraft:white_concrete
fill 510 142 229 510 145 229 minecraft:red_concrete
fill 510 142 265 510 145 265 minecraft:red_concrete
fill 472 143 229 472 146 229 minecraft:red_concrete
setblock 472 143 230 minecraft:white_concrete
fill 472 143 265 472 146 265 minecraft:red_concrete
setblock 472 143 266 minecraft:white_concrete
fill 474 143 232 474 147 233 minecraft:white_concrete
fill 474 143 268 474 146 269 minecraft:white_concrete
setblock 475 143 232 minecraft:red_concrete
setblock 475 143 268 minecraft:red_concrete
fill 486 143 255 486 144 255 minecraft:light_blue_concrete
fill 508 143 229 508 146 229 minecraft:red_concrete
setblock 508 143 230 minecraft:white_concrete
fill 508 143 265 508 147 265 minecraft:red_concrete
setblock 508 143 266 minecraft:white_concrete
fill 510 143 232 510 146 233 minecraft:white_concrete
fill 510 143 268 510 146 269 minecraft:white_concrete
setblock 511 143 232 minecraft:red_concrete
setblock 511 143 268 minecraft:red_concrete
fill 471 144 230 472 146 230 minecraft:red_concrete
fill 471 144 266 472 146 266 minecraft:red_concrete
fill 475 144 232 475 148 232 minecraft:white_concrete
fill 475 144 268 475 146 268 minecraft:white_concrete
fill 507 144 230 508 146 230 minecraft:red_concrete
fill 507 144 266 508 147 266 minecraft:red_concrete
fill 511 144 232 511 146 232 minecraft:white_concrete
fill 511 144 268 511 146 268 minecraft:white_concrete
fill 471 145 231 472 146 231 minecraft:red_concrete
setblock 471 145 232 minecraft:white_concrete
fill 471 145 267 472 146 267 minecraft:red_concrete
setblock 471 145 268 minecraft:white_concrete
fill 473 145 231 475 146 231 minecraft:white_concrete
fill 473 145 267 475 146 267 minecraft:white_concrete
setblock 474 145 230 minecraft:red_concrete
setblock 474 145 266 minecraft:red_concrete
fill 475 145 230 475 146 230 minecraft:white_concrete
fill 475 145 266 475 148 266 minecraft:white_concrete
fill 507 145 231 508 146 231 minecraft:red_concrete
setblock 507 145 232 minecraft:white_concrete
fill 507 145 267 508 146 267 minecraft:red_concrete
setblock 507 145 268 minecraft:white_concrete
fill 509 145 231 511 146 231 minecraft:white_concrete
fill 509 145 267 511 146 267 minecraft:white_concrete
setblock 510 145 230 minecraft:red_concrete
setblock 510 145 266 minecraft:red_concrete
fill 511 145 230 511 146 230 minecraft:white_concrete
fill 511 145 266 511 146 266 minecraft:white_concrete
fill 471 146 232 472 146 232 minecraft:red_concrete
fill 471 146 268 472 146 268 minecraft:red_concrete
setblock 472 146 233 minecraft:white_concrete
setblock 472 146 269 minecraft:white_concrete
fill 474 146 229 474 146 230 minecraft:white_concrete
fill 474 146 265 474 150 266 minecraft:white_concrete
fill 477 146 251 479 147 251 minecraft:light_blue_concrete
fill 478 146 250 479 147 250 minecraft:light_blue_concrete
fill 507 146 232 508 149 232 minecraft:red_concrete
fill 507 146 268 508 146 268 minecraft:red_concrete
setblock 508 146 233 minecraft:white_concrete
setblock 508 146 269 minecraft:white_concrete
fill 510 146 229 510 146 230 minecraft:white_concrete
fill 510 146 265 510 146 266 minecraft:white_concrete
fill 471 147 229 473 147 269 minecraft:black_concrete
fill 474 147 229 511 147 231 minecraft:black_concrete
fill 474 147 267 511 147 269 minecraft:black_concrete
setblock 481 147 239 minecraft:light[level=15]
setblock 481 147 247 minecraft:light[level=15]
setblock 481 147 255 minecraft:light[level=15]
setblock 481 147 263 minecraft:light[level=15]
setblock 489 147 239 minecraft:light[level=15]
setblock 489 147 247 minecraft:light[level=15]
setblock 489 147 255 minecraft:light[level=15]
setblock 489 147 263 minecraft:light[level=15]
fill 496 147 260 496 148 263 minecraft:light_blue_concrete
setblock 497 147 239 minecraft:light[level=15]
setblock 497 147 247 minecraft:light[level=15]
setblock 497 147 255 minecraft:light[level=15]
fill 497 147 259 500 148 259 minecraft:light_blue_concrete
fill 497 147 263 497 148 264 minecraft:light_blue_concrete
fill 498 147 264 499 148 264 minecraft:light_blue_concrete
fill 499 147 263 500 148 263 minecraft:light_blue_concrete
fill 500 147 260 500 148 262 minecraft:light_blue_concrete
fill 501 147 261 501 148 262 minecraft:light_blue_concrete
setblock 505 147 239 minecraft:light[level=15]
setblock 505 147 247 minecraft:light[level=15]
setblock 505 147 255 minecraft:light[level=15]
setblock 505 147 263 minecraft:light[level=15]
fill 508 147 233 508 150 233 minecraft:red_concrete
fill 509 147 232 511 147 266 minecraft:black_concrete
fill 471 148 229 473 148 269 minecraft:gray_concrete
fill 474 148 229 475 148 231 minecraft:gray_concrete
setblock 474 148 232 minecraft:white_concrete
fill 474 148 233 474 152 233 minecraft:red_concrete
fill 474 148 267 475 148 269 minecraft:gray_concrete
fill 476 148 228 476 151 269 minecraft:brown_terracotta
fill 477 148 228 478 148 228 minecraft:light_blue_concrete
fill 477 148 229 511 148 231 minecraft:gray_concrete
fill 477 148 267 511 148 269 minecraft:gray_concrete
setblock 480 148 238 minecraft:light[level=12]
setblock 480 148 245 minecraft:light[level=12]
setblock 480 148 252 minecraft:light[level=12]
setblock 480 148 259 minecraft:light[level=12]
setblock 480 148 266 minecraft:light[level=12]
setblock 487 148 238 minecraft:light[level=12]
setblock 487 148 245 minecraft:light[level=12]
setblock 487 148 252 minecraft:light[level=12]
setblock 487 148 259 minecraft:light[level=12]
setblock 487 148 266 minecraft:light[level=12]
setblock 494 148 238 minecraft:light[level=12]
setblock 494 148 245 minecraft:light[level=12]
setblock 494 148 252 minecraft:light[level=12]
setblock 494 148 259 minecraft:light[level=12]
setblock 494 148 266 minecraft:light[level=12]
setblock 501 148 238 minecraft:light[level=12]
setblock 501 148 245 minecraft:light[level=12]
setblock 501 148 252 minecraft:light[level=12]
setblock 501 148 259 minecraft:light[level=12]
setblock 501 148 266 minecraft:light[level=12]
setblock 507 148 266 minecraft:red_concrete
setblock 508 148 238 minecraft:light[level=12]
setblock 508 148 245 minecraft:light[level=12]
setblock 508 148 252 minecraft:light[level=12]
setblock 508 148 259 minecraft:light[level=12]
fill 508 148 265 508 152 266 minecraft:white_concrete
fill 509 148 232 511 148 266 minecraft:gray_concrete
fill 471 149 230 474 150 230 minecraft:white_concrete
fill 471 149 231 472 149 232 minecraft:red_concrete
fill 471 149 235 471 150 235 minecraft:brown_concrete
fill 471 149 266 473 151 266 minecraft:white_concrete
fill 471 149 267 472 149 268 minecraft:red_concrete
fill 472 149 229 474 151 229 minecraft:white_concrete
fill 472 149 233 473 150 233 minecraft:red_concrete
setblock 472 149 245 minecraft:light_blue_concrete
fill 472 149 265 473 151 265 minecraft:white_concrete
fill 472 149 269 474 150 269 minecraft:red_concrete
fill 473 149 228 474 308 228 minecraft:white_concrete
fill 473 149 231 474 149 231 minecraft:white_concrete
fill 473 149 232 474 151 232 minecraft:red_concrete
setblock 473 149 262 minecraft:lime_concrete
fill 473 149 264 473 150 264 minecraft:brown_concrete
fill 473 149 267 474 149 267 minecraft:white_concrete
fill 473 149 268 474 151 268 minecraft:red_concrete
fill 475 149 228 475 150 269 minecraft:brown_terracotta
fill 476 149 270 476 150 270 minecraft:brown_terracotta
fill 477 149 228 477 150 269 minecraft:brown_terracotta
fill 477 149 270 478 308 270 minecraft:light_blue_concrete
fill 478 149 228 478 308 228 minecraft:light_blue_concrete
fill 481 149 269 481 150 269 minecraft:brown_concrete
fill 485 149 231 485 150 231 minecraft:brown_concrete
setblock 488 149 229 minecraft:red_concrete
fill 489 149 267 489 150 267 minecraft:brown_concrete
setblock 496 149 268 minecraft:yellow_concrete
fill 499 149 268 499 150 268 minecraft:brown_concrete
setblock 501 149 267 minecraft:magenta_concrete
setblock 503 149 267 minecraft:red_concrete
fill 507 149 230 507 150 230 minecraft:brown_concrete
fill 507 149 231 508 149 231 minecraft:red_concrete
fill 507 149 266 507 153 266 minecraft:white_concrete
fill 507 149 267 508 149 268 minecraft:red_concrete
fill 508 149 229 510 150 230 minecraft:white_concrete
fill 508 149 269 510 150 269 minecraft:red_concrete
fill 509 149 231 511 149 231 minecraft:white_concrete
fill 509 149 232 510 151 233 minecraft:red_concrete
fill 509 149 259 509 150 259 minecraft:brown_concrete
fill 509 149 265 510 149 267 minecraft:white_concrete
fill 509 149 268 511 151 268 minecraft:red_concrete
setblock 510 149 235 minecraft:red_concrete
fill 511 149 230 511 150 230 minecraft:white_concrete
fill 511 149 232 511 153 232 minecraft:red_concrete
setblock 511 149 237 minecraft:red_concrete
fill 511 149 266 511 149 267 minecraft:white_concrete
fill 471 150 231 471 154 232 minecraft:white_concrete
fill 471 150 267 471 154 268 minecraft:white_concrete
fill 472 150 231 472 154 231 minecraft:white_concrete
setblock 472 150 232 minecraft:red_concrete
fill 472 150 267 472 154 267 minecraft:white_concrete
setblock 472 150 268 minecraft:red_concrete
fill 473 150 231 474 154 231 minecraft:red_concrete
fill 473 150 267 474 154 267 minecraft:red_concrete
fill 507 150 231 507 154 232 minecraft:white_concrete
fill 507 150 267 507 154 268 minecraft:white_concrete
fill 508 150 231 508 154 231 minecraft:white_concrete
setblock 508 150 232 minecraft:red_concrete
fill 508 150 267 508 154 267 minecraft:white_concrete
setblock 508 150 268 minecraft:red_concrete
fill 509 150 231 511 150 231 minecraft:red_concrete
fill 509 150 265 510 150 266 minecraft:white_concrete
fill 509 150 267 511 154 267 minecraft:red_concrete
setblock 511 150 266 minecraft:white_concrete
fill 471 151 230 473 151 230 minecraft:white_concrete
fill 472 151 232 472 155 233 minecraft:white_concrete
fill 472 151 268 472 155 269 minecraft:white_concrete
setblock 473 151 233 minecraft:red_concrete
fill 473 151 269 474 151 269 minecraft:red_concrete
fill 474 151 230 475 154 230 minecraft:red_concrete
setblock 474 151 265 minecraft:white_concrete
fill 474 151 266 475 154 266 minecraft:red_concrete
fill 475 151 228 475 308 228 minecraft:white_concrete
fill 475 151 231 475 153 232 minecraft:red_concrete
fill 475 151 267 475 153 268 minecraft:red_concrete
fill 476 151 270 476 308 270 minecraft:light_blue_concrete
fill 477 151 228 477 308 228 minecraft:light_blue_concrete
fill 507 151 230 509 151 230 minecraft:white_concrete
fill 508 151 229 510 151 229 minecraft:white_concrete
fill 508 151 232 508 155 233 minecraft:white_concrete
fill 508 151 268 508 155 269 minecraft:white_concrete
fill 509 151 231 510 154 231 minecraft:red_concrete
fill 509 151 265 509 151 266 minecraft:white_concrete
fill 509 151 269 510 151 269 minecraft:red_concrete
fill 510 151 230 511 154 230 minecraft:red_concrete
setblock 510 151 265 minecraft:white_concrete
fill 510 151 266 511 154 266 minecraft:red_concrete
fill 511 151 231 511 155 231 minecraft:brown_terracotta
fill 471 152 230 472 153 230 minecraft:white_concrete
fill 471 152 261 471 158 261 minecraft:brown_concrete
fill 471 152 266 472 153 266 minecraft:white_concrete
setblock 472 152 229 minecraft:white_concrete
setblock 472 152 265 minecraft:white_concrete
fill 473 152 229 473 156 230 minecraft:red_concrete
fill 473 152 232 473 156 233 minecraft:white_concrete
fill 473 152 265 473 156 266 minecraft:red_concrete
fill 473 152 268 473 156 269 minecraft:white_concrete
fill 474 152 229 474 155 229 minecraft:red_concrete
setblock 474 152 232 minecraft:red_concrete
fill 474 152 265 474 155 265 minecraft:red_concrete
fill 474 152 268 474 152 269 minecraft:red_concrete
fill 476 152 228 476 308 228 minecraft:light_blue_concrete
fill 507 152 230 508 153 230 minecraft:white_concrete
setblock 508 152 229 minecraft:white_concrete
fill 509 152 229 509 156 230 minecraft:red_concrete
fill 509 152 232 509 156 233 minecraft:white_concrete
fill 509 152 265 509 156 266 minecraft:red_concrete
fill 509 152 268 509 156 269 minecraft:white_concrete
fill 510 152 229 510 155 229 minecraft:red_concrete
fill 510 152 232 510 152 233 minecraft:red_concrete
fill 510 152 265 510 155 265 minecraft:red_concrete
fill 510 152 268 510 152 269 minecraft:red_concrete
fill 511 152 268 511 153 268 minecraft:red_concrete
fill 472 153 229 472 157 229 minecraft:red_concrete
fill 472 153 265 472 157 265 minecraft:red_concrete
fill 474 153 232 474 157 233 minecraft:white_concrete
fill 474 153 268 474 157 269 minecraft:white_concrete
fill 508 153 229 508 157 229 minecraft:red_concrete
fill 508 153 265 508 157 265 minecraft:red_concrete
setblock 508 153 266 minecraft:white_concrete
fill 510 153 232 510 157 233 minecraft:white_concrete
fill 510 153 268 510 157 269 minecraft:white_concrete
fill 471 154 230 472 157 230 minecraft:red_concrete
fill 471 154 266 472 157 266 minecraft:red_concrete
setblock 473 154 238 minecraft:light[level=12]
setblock 473 154 239 minecraft:light[level=15]
setblock 473 154 245 minecraft:light[level=12]
setblock 473 154 247 minecraft:light[level=15]
setblock 473 154 252 minecraft:light[level=12]
setblock 473 154 255 minecraft:light[level=15]
setblock 473 154 259 minecraft:light[level=12]
setblock 473 154 263 minecraft:light[level=15]
setblock 475 154 231 minecraft:red_concrete
fill 475 154 232 475 158 232 minecraft:white_concrete
setblock 475 154 267 minecraft:red_concrete
fill 475 154 268 475 158 268 minecraft:white_concrete
setblock 480 154 231 minecraft:light[level=12]
setblock 480 154 238 minecraft:light[level=12]
setblock 480 154 245 minecraft:light[level=12]
setblock 480 154 252 minecraft:light[level=12]
setblock 480 154 259 minecraft:light[level=12]
setblock 480 154 266 minecraft:light[level=12]
setblock 481 154 231 minecraft:light[level=15]
setblock 481 154 239 minecraft:light[level=15]
setblock 481 154 247 minecraft:light[level=15]
setblock 481 154 255 minecraft:light[level=15]
setblock 481 154 263 minecraft:light[level=15]
setblock 487 154 231 minecraft:light[level=12]
setblock 487 154 238 minecraft:light[level=12]
setblock 487 154 245 minecraft:light[level=12]
setblock 487 154 252 minecraft:light[level=12]
setblock 487 154 259 minecraft:light[level=12]
setblock 487 154 266 minecraft:light[level=12]
setblock 489 154 231 minecraft:light[level=15]
setblock 489 154 239 minecraft:light[level=15]
setblock 489 154 247 minecraft:light[level=15]
setblock 489 154 255 minecraft:light[level=15]
setblock 489 154 263 minecraft:light[level=15]
setblock 494 154 231 minecraft:light[level=12]
setblock 494 154 238 minecraft:light[level=12]
setblock 494 154 245 minecraft:light[level=12]
setblock 494 154 252 minecraft:light[level=12]
setblock 494 154 259 minecraft:light[level=12]
setblock 494 154 266 minecraft:light[level=12]
setblock 497 154 231 minecraft:light[level=15]
setblock 497 154 239 minecraft:light[level=15]
setblock 497 154 247 minecraft:light[level=15]
setblock 497 154 255 minecraft:light[level=15]
setblock 497 154 263 minecraft:light[level=15]
setblock 501 154 231 minecraft:light[level=12]
setblock 501 154 238 minecraft:light[level=12]
setblock 501 154 245 minecraft:light[level=12]
setblock 501 154 252 minecraft:light[level=12]
setblock 501 154 259 minecraft:light[level=12]
setblock 501 154 266 minecraft:light[level=12]
setblock 505 154 231 minecraft:light[level=15]
setblock 505 154 239 minecraft:light[level=15]
setblock 505 154 247 minecraft:light[level=15]
setblock 505 154 255 minecraft:light[level=15]
setblock 505 154 263 minecraft:light[level=15]
fill 507 154 230 508 157 230 minecraft:red_concrete
fill 507 154 266 508 157 266 minecraft:red_concrete
setblock 508 154 238 minecraft:light[level=12]
setblock 508 154 245 minecraft:light[level=12]
setblock 508 154 252 minecraft:light[level=12]
setblock 508 154 259 minecraft:light[level=12]
fill 511 154 232 511 158 232 minecraft:white_concrete
fill 511 154 268 511 158 268 minecraft:white_concrete
fill 471 155 231 472 159 231 minecraft:red_concrete
setblock 471 155 232 minecraft:white_concrete
fill 471 155 267 472 159 267 minecraft:red_concrete
setblock 471 155 268 minecraft:white_concrete
fill 473 155 231 475 159 231 minecraft:white_concrete
fill 473 155 267 475 159 267 minecraft:white_concrete
setblock 474 155 230 minecraft:red_concrete
setblock 474 155 266 minecraft:red_concrete
fill 475 155 230 475 160 230 minecraft:white_concrete
fill 475 155 266 475 160 266 minecraft:white_concrete
fill 507 155 231 508 159 231 minecraft:red_concrete
setblock 507 155 232 minecraft:white_concrete
fill 507 155 267 508 159 267 minecraft:red_concrete
setblock 507 155 268 minecraft:white_concrete
fill 509 155 231 510 159 231 minecraft:white_concrete
fill 509 155 267 511 159 267 minecraft:white_concrete
setblock 510 155 230 minecraft:red_concrete
setblock 510 155 266 minecraft:red_concrete
fill 511 155 230 511 160 230 minecraft:white_concrete
fill 511 155 238 511 165 238 minecraft:brown_terracotta
fill 511 155 266 511 160 266 minecraft:white_concrete
fill 471 156 232 472 159 232 minecraft:red_concrete
fill 471 156 268 472 159 268 minecraft:red_concrete
setblock 472 156 233 minecraft:white_concrete
setblock 472 156 269 minecraft:white_concrete
fill 474 156 229 474 160 230 minecraft:white_concrete
fill 474 156 265 474 160 266 minecraft:white_concrete
fill 507 156 232 508 159 232 minecraft:red_concrete
fill 507 156 268 508 159 268 minecraft:red_concrete
setblock 508 156 233 minecraft:white_concrete
setblock 508 156 269 minecraft:white_concrete
fill 510 156 229 510 160 230 minecraft:white_concrete
fill 510 156 265 510 160 266 minecraft:white_concrete
fill 511 156 231 511 159 231 minecraft:white_concrete
fill 472 157 233 473 160 233 minecraft:red_concrete
fill 472 157 269 473 160 269 minecraft:red_concrete
fill 473 157 229 473 161 230 minecraft:white_concrete
fill 473 157 232 473 161 232 minecraft:red_concrete
fill 473 157 265 473 161 266 minecraft:white_concrete
fill 473 157 268 473 161 268 minecraft:red_concrete
fill 508 157 233 509 160 233 minecraft:red_concrete
fill 508 157 269 509 160 269 minecraft:red_concrete
fill 509 157 229 509 161 230 minecraft:white_concrete
fill 509 157 232 509 161 232 minecraft:red_concrete
fill 509 157 265 509 161 266 minecraft:white_concrete
fill 509 157 268 509 161 268 minecraft:red_concrete
setblock 471 158 230 minecraft:red_concrete
fill 471 158 260 471 166 260 minecraft:brown_concrete
setblock 471 158 266 minecraft:red_concrete
fill 472 158 229 472 162 230 minecraft:white_concrete
fill 472 158 265 472 162 266 minecraft:white_concrete
setblock 474 158 232 minecraft:white_concrete
fill 474 158 233 474 162 233 minecraft:red_concrete
setblock 474 158 268 minecraft:white_concrete
fill 474 158 269 474 162 269 minecraft:red_concrete
setblock 507 158 230 minecraft:red_concrete
setblock 507 158 266 minecraft:red_concrete
fill 508 158 229 508 162 230 minecraft:white_concrete
fill 508 158 265 508 162 266 minecraft:white_concrete
setblock 510 158 232 minecraft:white_concrete
fill 510 158 233 510 162 233 minecraft:red_concrete
setblock 510 158 268 minecraft:white_concrete
fill 510 158 269 510 162 269 minecraft:red_concrete
fill 511 158 257 511 169 257 minecraft:brown_concrete
fill 471 159 230 471 163 230 minecraft:white_concrete
fill 471 159 266 471 163 266 minecraft:white_concrete
fill 474 159 232 475 162 232 minecraft:red_concrete
fill 474 159 268 475 162 268 minecraft:red_concrete
fill 507 159 230 507 163 230 minecraft:white_concrete
fill 507 159 266 507 163 266 minecraft:white_concrete
fill 510 159 232 511 162 232 minecraft:red_concrete
fill 510 159 268 511 162 268 minecraft:red_concrete
fill 471 160 231 471 164 232 minecraft:white_concrete
fill 471 160 267 471 164 268 minecraft:white_concrete
fill 472 160 231 472 164 231 minecraft:white_concrete
setblock 472 160 232 minecraft:red_concrete
fill 472 160 267 472 164 267 minecraft:white_concrete
setblock 472 160 268 minecraft:red_concrete
fill 473 160 231 475 164 231 minecraft:red_concrete
setblock 473 160 238 minecraft:light[level=12]
setblock 473 160 245 minecraft:light[level=12]
setblock 473 160 252 minecraft:light[level=12]
setblock 473 160 259 minecraft:light[level=12]
fill 473 160 267 475 164 267 minecraft:red_concrete
setblock 480 160 231 minecraft:light[level=12]
setblock 480 160 238 minecraft:light[level=12]
setblock 480 160 245 minecraft:light[level=12]
setblock 480 160 252 minecraft:light[level=12]
setblock 480 160 259 minecraft:light[level=12]
setblock 480 160 266 minecraft:light[level=12]
setblock 487 160 231 minecraft:light[level=12]
setblock 487 160 238 minecraft:light[level=12]
setblock 487 160 245 minecraft:light[level=12]
setblock 487 160 252 minecraft:light[level=12]
setblock 487 160 259 minecraft:light[level=12]
setblock 487 160 266 minecraft:light[level=12]
setblock 494 160 231 minecraft:light[level=12]
setblock 494 160 238 minecraft:light[level=12]
setblock 494 160 245 minecraft:light[level=12]
setblock 494 160 252 minecraft:light[level=12]
setblock 494 160 259 minecraft:light[level=12]
setblock 494 160 266 minecraft:light[level=12]
setblock 501 160 231 minecraft:light[level=12]
setblock 501 160 238 minecraft:light[level=12]
setblock 501 160 245 minecraft:light[level=12]
setblock 501 160 252 minecraft:light[level=12]
setblock 501 160 259 minecraft:light[level=12]
setblock 501 160 266 minecraft:light[level=12]
fill 507 160 231 507 164 232 minecraft:white_concrete
fill 507 160 267 507 164 268 minecraft:white_concrete
fill 508 160 231 508 164 231 minecraft:white_concrete
setblock 508 160 232 minecraft:red_concrete
setblock 508 160 238 minecraft:light[level=12]
setblock 508 160 245 minecraft:light[level=12]
setblock 508 160 252 minecraft:light[level=12]
setblock 508 160 259 minecraft:light[level=12]
fill 508 160 267 508 164 267 minecraft:white_concrete
setblock 508 160 268 minecraft:red_concrete
fill 509 160 231 511 164 231 minecraft:red_concrete
fill 509 160 267 511 164 267 minecraft:red_concrete
fill 472 161 232 472 165 233 minecraft:white_concrete
fill 472 161 268 472 165 269 minecraft:white_concrete
setblock 473 161 233 minecraft:red_concrete
setblock 473 161 239 minecraft:light[level=15]
setblock 473 161 247 minecraft:light[level=15]
setblock 473 161 255 minecraft:light[level=15]
setblock 473 161 263 minecraft:light[level=15]
setblock 473 161 269 minecraft:red_concrete
setblock 474 161 229 minecraft:white_concrete
fill 474 161 230 475 164 230 minecraft:red_concrete
setblock 474 161 265 minecraft:white_concrete
fill 474 161 266 475 164 266 minecraft:red_concrete
setblock 481 161 231 minecraft:light[level=15]
setblock 481 161 239 minecraft:light[level=15]
setblock 481 161 247 minecraft:light[level=15]
setblock 481 161 255 minecraft:light[level=15]
setblock 481 161 263 minecraft:light[level=15]
setblock 489 161 231 minecraft:light[level=15]
setblock 489 161 239 minecraft:light[level=15]
setblock 489 161 247 minecraft:light[level=15]
setblock 489 161 255 minecraft:light[level=15]
setblock 489 161 263 minecraft:light[level=15]
setblock 497 161 231 minecraft:light[level=15]
setblock 497 161 239 minecraft:light[level=15]
setblock 497 161 247 minecraft:light[level=15]
setblock 497 161 255 minecraft:light[level=15]
setblock 497 161 263 minecraft:light[level=15]
setblock 505 161 231 minecraft:light[level=15]
setblock 505 161 239 minecraft:light[level=15]
setblock 505 161 247 minecraft:light[level=15]
setblock 505 161 255 minecraft:light[level=15]
setblock 505 161 263 minecraft:light[level=15]
fill 508 161 232 508 165 233 minecraft:white_concrete
fill 508 161 268 508 165 269 minecraft:white_concrete
setblock 509 161 233 minecraft:red_concrete
setblock 509 161 269 minecraft:red_concrete
setblock 510 161 229 minecraft:white_concrete
fill 510 161 230 511 164 230 minecraft:red_concrete
setblock 510 161 265 minecraft:white_concrete
fill 510 161 266 511 164 266 minecraft:red_concrete
fill 473 162 229 473 166 230 minecraft:red_concrete
fill 473 162 232 473 166 233 minecraft:white_concrete
fill 473 162 265 473 166 266 minecraft:red_concrete
fill 473 162 268 473 166 269 minecraft:white_concrete
fill 474 162 229 474 165 229 minecraft:red_concrete
fill 474 162 265 474 165 265 minecraft:red_concrete
fill 509 162 229 509 166 230 minecraft:red_concrete
fill 509 162 232 509 166 233 minecraft:white_concrete
fill 509 162 265 509 166 266 minecraft:red_concrete
fill 509 162 268 509 166 269 minecraft:white_concrete
fill 510 162 229 510 165 229 minecraft:red_concrete
fill 510 162 265 510 165 265 minecraft:red_concrete
fill 472 163 229 472 167 229 minecraft:red_concrete
setblock 472 163 230 minecraft:white_concrete
fill 472 163 265 472 167 265 minecraft:red_concrete
setblock 472 163 266 minecraft:white_concrete
fill 474 163 232 474 167 233 minecraft:white_concrete
fill 474 163 268 474 167 269 minecraft:white_concrete
setblock 475 163 232 minecraft:red_concrete
setblock 475 163 268 minecraft:red_concrete
fill 508 163 229 508 167 229 minecraft:red_concrete
setblock 508 163 230 minecraft:white_concrete
fill 508 163 265 508 167 265 minecraft:red_concrete
setblock 508 163 266 minecraft:white_concrete
fill 510 163 232 510 167 233 minecraft:white_concrete
fill 510 163 268 510 167 269 minecraft:white_concrete
setblock 511 163 232 minecraft:red_concrete
setblock 511 163 268 minecraft:red_concrete
fill 471 164 230 472 167 230 minecraft:red_concrete
fill 471 164 266 472 167 266 minecraft:red_concrete
fill 475 164 232 475 168 232 minecraft:white_concrete
fill 475 164 268 475 167 268 minecraft:white_concrete
fill 482 164 257 484 165 257 minecraft:yellow_concrete
fill 483 164 256 483 165 256 minecraft:yellow_concrete
fill 483 164 258 483 165 258 minecraft:yellow_concrete
fill 507 164 230 508 167 230 minecraft:red_concrete
fill 507 164 266 508 167 266 minecraft:red_concrete
fill 511 164 232 511 167 232 minecraft:white_concrete
fill 511 164 268 511 167 268 minecraft:white_concrete
fill 471 165 231 472 167 231 minecraft:red_concrete
setblock 471 165 232 minecraft:white_concrete
fill 471 165 267 472 167 267 minecraft:red_concrete
setblock 471 165 268 minecraft:white_concrete
fill 473 165 231 475 167 231 minecraft:white_concrete
fill 473 165 267 475 167 267 minecraft:white_concrete
setblock 474 165 230 minecraft:red_concrete
setblock 474 165 266 minecraft:red_concrete
fill 475 165 230 475 167 230 minecraft:white_concrete
fill 475 165 266 475 170 266 minecraft:white_concrete
fill 507 165 231 508 167 231 minecraft:red_concrete
setblock 507 165 232 minecraft:white_concrete
fill 507 165 267 508 167 267 minecraft:red_concrete
setblock 507 165 268 minecraft:white_concrete
fill 509 165 231 511 167 231 minecraft:white_concrete
fill 509 165 267 511 167 267 minecraft:white_concrete
setblock 510 165 230 minecraft:red_concrete
setblock 510 165 266 minecraft:red_concrete
fill 511 165 230 511 167 230 minecraft:white_concrete
fill 511 165 266 511 167 266 minecraft:white_concrete
fill 471 166 232 472 167 232 minecraft:red_concrete
fill 471 166 268 472 167 268 minecraft:red_concrete
setblock 472 166 233 minecraft:white_concrete
setblock 472 166 269 minecraft:white_concrete
setblock 473 166 238 minecraft:light[level=12]
setblock 473 166 245 minecraft:light[level=12]
setblock 473 166 252 minecraft:light[level=12]
setblock 473 166 259 minecraft:light[level=12]
fill 474 166 229 474 167 230 minecraft:white_concrete
fill 474 166 265 474 170 266 minecraft:white_concrete
setblock 480 166 231 minecraft:light[level=12]
setblock 480 166 238 minecraft:light[level=12]
setblock 480 166 245 minecraft:light[level=12]
setblock 480 166 252 minecraft:light[level=12]
setblock 480 166 259 minecraft:light[level=12]
setblock 480 166 266 minecraft:light[level=12]
setblock 487 166 231 minecraft:light[level=12]
setblock 487 166 238 minecraft:light[level=12]
setblock 487 166 245 minecraft:light[level=12]
setblock 487 166 252 minecraft:light[level=12]
setblock 487 166 259 minecraft:light[level=12]
setblock 487 166 266 minecraft:light[level=12]
setblock 494 166 231 minecraft:light[level=12]
setblock 494 166 238 minecraft:light[level=12]
setblock 494 166 245 minecraft:light[level=12]
setblock 494 166 252 minecraft:light[level=12]
setblock 494 166 259 minecraft:light[level=12]
setblock 494 166 266 minecraft:light[level=12]
setblock 501 166 231 minecraft:light[level=12]
setblock 501 166 238 minecraft:light[level=12]
setblock 501 166 245 minecraft:light[level=12]
setblock 501 166 252 minecraft:light[level=12]
setblock 501 166 259 minecraft:light[level=12]
setblock 501 166 266 minecraft:light[level=12]
fill 507 166 232 508 169 232 minecraft:red_concrete
fill 507 166 268 508 167 268 minecraft:red_concrete
setblock 508 166 233 minecraft:white_concrete
setblock 508 166 238 minecraft:light[level=12]
setblock 508 166 245 minecraft:light[level=12]
setblock 508 166 252 minecraft:light[level=12]
setblock 508 166 259 minecraft:light[level=12]
setblock 508 166 269 minecraft:white_concrete
fill 510 166 229 510 167 230 minecraft:white_concrete
fill 510 166 265 510 167 266 minecraft:white_concrete
fill 472 167 233 473 167 233 minecraft:red_concrete
fill 472 167 269 473 167 269 minecraft:red_concrete
fill 473 167 229 473 167 230 minecraft:white_concrete
setblock 473 167 232 minecraft:red_concrete
fill 473 167 265 473 167 266 minecraft:white_concrete
setblock 473 167 268 minecraft:red_concrete
fill 508 167 233 509 167 233 minecraft:red_concrete
fill 508 167 269 509 167 269 minecraft:red_concrete
fill 509 167 229 509 167 230 minecraft:white_concrete
setblock 509 167 232 minecraft:red_concrete
fill 509 167 265 509 167 266 minecraft:white_concrete
setblock 509 167 268 minecraft:red_concrete
fill 471 168 229 473 168 269 minecraft:black_concrete
fill 474 168 229 511 168 231 minecraft:black_concrete
setblock 474 168 232 minecraft:white_concrete
fill 474 168 233 474 172 233 minecraft:red_concrete
fill 474 168 267 511 168 269 minecraft:black_concrete
setblock 481 168 239 minecraft:light[level=15]
setblock 481 168 247 minecraft:light[level=15]
setblock 481 168 255 minecraft:light[level=15]
setblock 481 168 263 minecraft:light[level=15]
setblock 489 168 239 minecraft:light[level=15]
setblock 489 168 247 minecraft:light[level=15]
setblock 489 168 255 minecraft:light[level=15]
setblock 489 168 263 minecraft:light[level=15]
setblock 497 168 239 minecraft:light[level=15]
setblock 497 168 247 minecraft:light[level=15]
setblock 497 168 255 minecraft:light[level=15]
setblock 497 168 263 minecraft:light[level=15]
setblock 505 168 239 minecraft:light[level=15]
setblock 505 168 247 minecraft:light[level=15]
setblock 505 168 255 minecraft:light[level=15]
setblock 505 168 263 minecraft:light[level=15]
setblock 507 168 266 minecraft:red_concrete
fill 508 168 233 508 170 233 minecraft:red_concrete
fill 508 168 265 508 172 266 minecraft:white_concrete
fill 509 168 232 510 168 266 minecraft:black_concrete
fill 511 168 232 511 168 256 minecraft:black_concrete
fill 511 168 258 511 168 266 minecraft:black_concrete
fill 471 169 229 473 169 269 minecraft:gray_concrete
fill 474 169 229 511 169 231 minecraft:gray_concrete
fill 474 169 232 475 172 232 minecraft:red_concrete
fill 474 169 267 511 169 269 minecraft:gray_concrete
fill 507 169 266 507 173 266 minecraft:white_concrete
fill 509 169 232 510 169 266 minecraft:gray_concrete
fill 511 169 232 511 169 256 minecraft:gray_concrete
fill 511 169 258 511 169 266 minecraft:gray_concrete
fill 471 170 230 471 173 232 minecraft:white_concrete
fill 471 170 263 471 171 263 minecraft:brown_concrete
fill 471 170 266 471 173 268 minecraft:white_concrete
fill 472 170 229 472 172 231 minecraft:white_concrete
fill 472 170 232 473 170 233 minecraft:red_concrete
fill 472 170 237 472 171 237 minecraft:brown_concrete
setblock 472 170 259 minecraft:lime_concrete
fill 472 170 265 472 172 267 minecraft:white_concrete
fill 472 170 268 474 170 269 minecraft:red_concrete
fill 473 170 229 474 170 230 minecraft:white_concrete
fill 473 170 231 475 174 231 minecraft:red_concrete
fill 473 170 265 473 171 266 minecraft:white_concrete
fill 473 170 267 475 174 267 minecraft:red_concrete
setblock 475 170 230 minecraft:white_concrete
fill 475 170 268 475 173 268 minecraft:red_concrete
fill 477 170 267 477 171 267 minecraft:brown_concrete
fill 480 170 269 480 171 269 minecraft:brown_concrete
setblock 481 170 231 minecraft:light_blue_concrete
fill 483 170 229 483 171 229 minecraft:brown_concrete
setblock 488 170 229 minecraft:orange_concrete
fill 488 170 231 488 171 231 minecraft:brown_concrete
fill 497 170 231 497 171 231 minecraft:brown_concrete
setblock 500 170 229 minecraft:white_concrete
setblock 501 170 269 minecraft:light_blue_concrete
setblock 502 170 230 minecraft:red_concrete
setblock 502 170 267 minecraft:red_concrete
fill 507 170 230 507 173 232 minecraft:white_concrete
fill 507 170 267 507 174 268 minecraft:white_concrete
fill 508 170 229 508 172 231 minecraft:white_concrete
fill 508 170 232 511 170 232 minecraft:red_concrete
fill 508 170 267 508 174 267 minecraft:white_concrete
fill 508 170 268 510 170 269 minecraft:red_concrete
fill 509 170 229 510 170 230 minecraft:white_concrete
fill 509 170 231 511 174 231 minecraft:red_concrete
fill 509 170 233 510 171 233 minecraft:red_concrete
fill 509 170 265 510 170 266 minecraft:white_concrete
fill 509 170 267 511 174 267 minecraft:red_concrete
fill 510 170 235 510 171 235 minecraft:brown_concrete
setblock 511 170 230 minecraft:white_concrete
setblock 511 170 245 minecraft:red_concrete
setblock 511 170 266 minecraft:white_concrete
fill 511 170 268 511 173 268 minecraft:red_concrete
fill 472 171 232 472 175 233 minecraft:white_concrete
fill 472 171 268 472 175 269 minecraft:white_concrete
fill 473 171 229 473 171 230 minecraft:white_concrete
fill 473 171 232 473 171 233 minecraft:red_concrete
fill 473 171 268 474 171 269 minecraft:red_concrete
setblock 474 171 229 minecraft:white_concrete
fill 474 171 230 475 174 230 minecraft:red_concrete
setblock 474 171 265 minecraft:white_concrete
fill 474 171 266 475 174 266 minecraft:red_concrete
fill 508 171 232 508 175 233 minecraft:white_concrete
fill 508 171 268 508 175 269 minecraft:white_concrete
fill 509 171 229 509 171 230 minecraft:white_concrete
fill 509 171 232 511 171 232 minecraft:red_concrete
fill 509 171 265 509 171 266 minecraft:white_concrete
fill 509 171 268 510 171 269 minecraft:red_concrete
setblock 510 171 229 minecraft:white_concrete
fill 510 171 230 511 174 230 minecraft:red_concrete
setblock 510 171 265 minecraft:white_concrete
fill 510 171 266 511 174 266 minecraft:red_concrete
fill 473 172 229 473 176 230 minecraft:red_concrete
fill 473 172 232 473 176 233 minecraft:white_concrete
setblock 473 172 238 minecraft:light[level=12]
setblock 473 172 245 minecraft:light[level=12]
setblock 473 172 252 minecraft:light[level=12]
setblock 473 172 259 minecraft:light[level=12]
fill 473 172 265 473 176 266 minecraft:red_concrete
fill 473 172 268 473 176 269 minecraft:white_concrete
fill 474 172 229 474 175 229 minecraft:red_concrete
fill 474 172 265 474 175 265 minecraft:red_concrete
fill 474 172 268 474 172 269 minecraft:red_concrete
setblock 480 172 231 minecraft:light[level=12]
setblock 480 172 238 minecraft:light[level=12]
setblock 480 172 245 minecraft:light[level=12]
setblock 480 172 252 minecraft:light[level=12]
setblock 480 172 259 minecraft:light[level=12]
setblock 480 172 266 minecraft:light[level=12]
setblock 487 172 231 minecraft:light[level=12]
setblock 487 172 238 minecraft:light[level=12]
setblock 487 172 245 minecraft:light[level=12]
setblock 487 172 252 minecraft:light[level=12]
setblock 487 172 259 minecraft:light[level=12]
setblock 487 172 266 minecraft:light[level=12]
setblock 494 172 231 minecraft:light[level=12]
setblock 494 172 238 minecraft:light[level=12]
setblock 494 172 245 minecraft:light[level=12]
setblock 494 172 252 minecraft:light[level=12]
setblock 494 172 259 minecraft:light[level=12]
setblock 494 172 266 minecraft:light[level=12]
setblock 501 172 231 minecraft:light[level=12]
setblock 501 172 238 minecraft:light[level=12]
setblock 501 172 245 minecraft:light[level=12]
setblock 501 172 252 minecraft:light[level=12]
setblock 501 172 259 minecraft:light[level=12]
setblock 501 172 266 minecraft:light[level=12]
setblock 508 172 238 minecraft:light[level=12]
setblock 508 172 245 minecraft:light[level=12]
setblock 508 172 252 minecraft:light[level=12]
setblock 508 172 259 minecraft:light[level=12]
fill 509 172 229 509 176 230 minecraft:red_concrete
fill 509 172 232 509 176 233 minecraft:white_concrete
fill 509 172 265 509 176 266 minecraft:red_concrete
fill 509 172 268 509 176 269 minecraft:white_concrete
fill 510 172 229 510 175 229 minecraft:red_concrete
fill 510 172 232 510 172 233 minecraft:red_concrete
fill 510 172 265 510 175 265 minecraft:red_concrete
fill 510 172 268 510 172 269 minecraft:red_concrete
fill 511 172 232 511 173 232 minecraft:red_concrete
fill 472 173 229 472 177 229 minecraft:red_concrete
fill 472 173 230 472 173 231 minecraft:white_concrete
fill 472 173 265 472 177 265 minecraft:red_concrete
fill 472 173 266 472 173 267 minecraft:white_concrete
fill 474 173 232 474 177 233 minecraft:white_concrete
fill 474 173 268 474 177 269 minecraft:white_concrete
setblock 475 173 232 minecraft:red_concrete
fill 508 173 229 508 177 229 minecraft:red_concrete
fill 508 173 230 508 173 231 minecraft:white_concrete
fill 508 173 265 508 177 265 minecraft:red_concrete
setblock 508 173 266 minecraft:white_concrete
fill 510 173 232 510 177 233 minecraft:white_concrete
fill 510 173 268 510 177 269 minecraft:white_concrete
fill 471 174 230 472 177 230 minecraft:red_concrete
fill 471 174 231 471 174 232 minecraft:white_concrete
fill 471 174 266 472 177 266 minecraft:red_concrete
fill 471 174 267 471 174 268 minecraft:white_concrete
setblock 472 174 231 minecraft:white_concrete
setblock 472 174 267 minecraft:white_concrete
fill 475 174 232 475 178 232 minecraft:white_concrete
fill 475 174 268 475 178 268 minecraft:white_concrete
fill 501 174 253 503 174 256 minecraft:orange_terracotta
fill 502 174 252 507 174 252 minecraft:orange_terracotta
fill 502 174 257 507 174 257 minecraft:orange_terracotta
fill 503 174 251 506 174 251 minecraft:orange_terracotta
fill 503 174 258 506 174 258 minecraft:orange_terracotta
fill 504 174 253 508 174 253 minecraft:orange_terracotta
fill 504 174 256 508 174 256 minecraft:orange_terracotta
fill 506 174 254 508 174 255 minecraft:orange_terracotta
fill 507 174 230 508 177 230 minecraft:red_concrete
fill 507 174 231 507 174 232 minecraft:white_concrete
fill 507 174 266 508 177 266 minecraft:red_concrete
setblock 508 174 231 minecraft:white_concrete
fill 511 174 232 511 178 232 minecraft:white_concrete
fill 511 174 268 511 178 268 minecraft:white_concrete
fill 471 175 231 472 179 231 minecraft:red_concrete
setblock 471 175 232 minecraft:white_concrete
fill 471 175 267 472 179 267 minecraft:red_concrete
setblock 471 175 268 minecraft:white_concrete
fill 473 175 231 475 179 231 minecraft:white_concrete
setblock 473 175 239 minecraft:light[level=15]
setblock 473 175 247 minecraft:light[level=15]
setblock 473 175 255 minecraft:light[level=15]
setblock 473 175 263 minecraft:light[level=15]
fill 473 175 267 475 179 267 minecraft:white_concrete
setblock 474 175 230 minecraft:red_concrete
setblock 474 175 266 minecraft:red_concrete
fill 475 175 230 475 180 230 minecraft:white_concrete
fill 475 175 266 475 180 266 minecraft:white_concrete
setblock 481 175 231 minecraft:light[level=15]
setblock 481 175 239 minecraft:light[level=15]
setblock 481 175 247 minecraft:light[level=15]
setblock 481 175 255 minecraft:light[level=15]
setblock 481 175 263 minecraft:light[level=15]
setblock 489 175 231 minecraft:light[level=15]
setblock 489 175 239 minecraft:light[level=15]
setblock 489 175 247 minecraft:light[level=15]
setblock 489 175 255 minecraft:light[level=15]
setblock 489 175 263 minecraft:light[level=15]
setblock 497 175 231 minecraft:light[level=15]
setblock 497 175 239 minecraft:light[level=15]
setblock 497 175 247 minecraft:light[level=15]
setblock 497 175 255 minecraft:light[level=15]
setblock 497 175 263 minecraft:light[level=15]
fill 501 175 253 503 175 256 minecraft:pink_concrete
fill 502 175 252 507 175 252 minecraft:pink_concrete
fill 502 175 257 507 175 257 minecraft:pink_concrete
fill 503 175 251 506 175 251 minecraft:pink_concrete
fill 503 175 258 506 175 258 minecraft:pink_concrete
fill 504 175 253 508 175 253 minecraft:pink_concrete
fill 504 175 256 508 175 256 minecraft:pink_concrete
setblock 505 175 231 minecraft:light[level=15]
setblock 505 175 239 minecraft:light[level=15]
setblock 505 175 247 minecraft:light[level=15]
setblock 505 175 255 minecraft:light[level=15]
setblock 505 175 263 minecraft:light[level=15]
fill 506 175 254 508 175 255 minecraft:pink_concrete
fill 507 175 231 508 179 231 minecraft:red_concrete
setblock 507 175 232 minecraft:white_concrete
fill 507 175 267 508 179 267 minecraft:red_concrete
setblock 507 175 268 minecraft:white_concrete
fill 509 175 231 511 179 231 minecraft:white_concrete
fill 509 175 267 511 179 267 minecraft:white_concrete
setblock 510 175 230 minecraft:red_concrete
setblock 510 175 266 minecraft:red_concrete
fill 511 175 230 511 180 230 minecraft:white_concrete
fill 511 175 266 511 180 266 minecraft:white_concrete
fill 471 176 232 472 179 232 minecraft:red_concrete
fill 471 176 268 472 179 268 minecraft:red_concrete
setblock 472 176 233 minecraft:white_concrete
setblock 472 176 269 minecraft:white_concrete
fill 474 176 229 474 180 230 minecraft:white_concrete
fill 474 176 265 474 180 266 minecraft:white_concrete
fill 507 176 232 508 179 232 minecraft:red_concrete
fill 507 176 268 508 179 268 minecraft:red_concrete
setblock 508 176 233 minecraft:white_concrete
setblock 508 176 269 minecraft:white_concrete
fill 510 176 229 510 180 230 minecraft:white_concrete
fill 510 176 265 510 180 266 minecraft:white_concrete
fill 471 177 234 471 185 234 minecraft:brown_terracotta
fill 472 177 233 473 180 233 minecraft:red_concrete
fill 472 177 269 473 180 269 minecraft:red_concrete
fill 473 177 229 473 181 230 minecraft:white_concrete
fill 473 177 232 473 181 232 minecraft:red_concrete
fill 473 177 265 473 181 266 minecraft:white_concrete
fill 473 177 268 473 181 268 minecraft:red_concrete
fill 508 177 233 509 180 233 minecraft:red_concrete
fill 508 177 269 509 180 269 minecraft:red_concrete
fill 509 177 229 509 181 230 minecraft:white_concrete
fill 509 177 232 509 181 232 minecraft:red_concrete
fill 509 177 265 509 181 266 minecraft:white_concrete
fill 509 177 268 509 181 268 minecraft:red_concrete
setblock 471 178 230 minecraft:red_concrete
setblock 471 178 266 minecraft:red_concrete
fill 472 178 229 472 182 230 minecraft:white_concrete
fill 472 178 265 472 182 266 minecraft:white_concrete
setblock 473 178 238 minecraft:light[level=12]
setblock 473 178 245 minecraft:light[level=12]
setblock 473 178 252 minecraft:light[level=12]
setblock 473 178 259 minecraft:light[level=12]
setblock 474 178 232 minecraft:white_concrete
fill 474 178 233 474 182 233 minecraft:red_concrete
setblock 474 178 268 minecraft:white_concrete
fill 474 178 269 474 182 269 minecraft:red_concrete
setblock 480 178 231 minecraft:light[level=12]
setblock 480 178 238 minecraft:light[level=12]
setblock 480 178 245 minecraft:light[level=12]
setblock 480 178 252 minecraft:light[level=12]
setblock 480 178 259 minecraft:light[level=12]
setblock 480 178 266 minecraft:light[level=12]
setblock 487 178 231 minecraft:light[level=12]
setblock 487 178 238 minecraft:light[level=12]
setblock 487 178 245 minecraft:light[level=12]
setblock 487 178 252 minecraft:light[level=12]
setblock 487 178 259 minecraft:light[level=12]
setblock 487 178 266 minecraft:light[level=12]
setblock 494 178 231 minecraft:light[level=12]
setblock 494 178 238 minecraft:light[level=12]
setblock 494 178 245 minecraft:light[level=12]
setblock 494 178 252 minecraft:light[level=12]
setblock 494 178 259 minecraft:light[level=12]
setblock 494 178 266 minecraft:light[level=12]
setblock 501 178 231 minecraft:light[level=12]
setblock 501 178 238 minecraft:light[level=12]
setblock 501 178 245 minecraft:light[level=12]
setblock 501 178 252 minecraft:light[level=12]
setblock 501 178 259 minecraft:light[level=12]
setblock 501 178 266 minecraft:light[level=12]
setblock 507 178 230 minecraft:red_concrete
setblock 507 178 266 minecraft:red_concrete
fill 508 178 229 508 182 230 minecraft:white_concrete
setblock 508 178 238 minecraft:light[level=12]
setblock 508 178 245 minecraft:light[level=12]
setblock 508 178 252 minecraft:light[level=12]
setblock 508 178 259 minecraft:light[level=12]
fill 508 178 265 508 182 266 minecraft:white_concrete
setblock 510 178 232 minecraft:white_concrete
fill 510 178 233 510 182 233 minecraft:red_concrete
setblock 510 178 268 minecraft:white_concrete
fill 510 178 269 510 182 269 minecraft:red_concrete
fill 471 179 230 471 183 230 minecraft:white_concrete
fill 471 179 266 471 183 266 minecraft:white_concrete
fill 474 179 232 475 182 232 minecraft:red_concrete
fill 474 179 268 475 182 268 minecraft:red_concrete
fill 507 179 230 507 183 230 minecraft:white_concrete
fill 507 179 266 507 183 266 minecraft:white_concrete
fill 510 179 232 511 182 232 minecraft:red_concrete
fill 510 179 268 511 182 268 minecraft:red_concrete
fill 471 180 231 471 184 232 minecraft:white_concrete
fill 471 180 267 471 184 268 minecraft:white_concrete
fill 472 180 231 472 184 231 minecraft:white_concrete
setblock 472 180 232 minecraft:red_concrete
fill 472 180 267 472 184 267 minecraft:white_concrete
setblock 472 180 268 minecraft:red_concrete
fill 473 180 231 475 184 231 minecraft:red_concrete
fill 473 180 267 475 184 267 minecraft:red_concrete
fill 507 180 231 507 184 232 minecraft:white_concrete
fill 507 180 267 507 184 268 minecraft:white_concrete
fill 508 180 231 508 184 231 minecraft:white_concrete
setblock 508 180 232 minecraft:red_concrete
fill 508 180 267 508 184 267 minecraft:white_concrete
setblock 508 180 268 minecraft:red_concrete
fill 509 180 231 511 184 231 minecraft:red_concrete
fill 509 180 267 511 184 267 minecraft:red_concrete
fill 472 181 232 472 185 233 minecraft:white_concrete
fill 472 181 268 472 185 269 minecraft:white_concrete
setblock 473 181 233 minecraft:red_concrete
setblock 473 181 269 minecraft:red_concrete
setblock 474 181 229 minecraft:white_concrete
fill 474 181 230 475 184 230 minecraft:red_concrete
setblock 474 181 265 minecraft:white_concrete
fill 474 181 266 475 184 266 minecraft:red_concrete
fill 508 181 232 508 185 233 minecraft:white_concrete
fill 508 181 268 508 185 269 minecraft:white_concrete
setblock 509 181 233 minecraft:red_concrete
setblock 509 181 269 minecraft:red_concrete
setblock 510 181 229 minecraft:white_concrete
fill 510 181 230 511 184 230 minecraft:red_concrete
setblock 510 181 265 minecraft:white_concrete
fill 510 181 266 511 184 266 minecraft:red_concrete
fill 473 182 229 473 186 230 minecraft:red_concrete
fill 473 182 232 473 186 233 minecraft:white_concrete
setblock 473 182 239 minecraft:light[level=15]
setblock 473 182 247 minecraft:light[level=15]
setblock 473 182 255 minecraft:light[level=15]
setblock 473 182 263 minecraft:light[level=15]
fill 473 182 265 473 186 266 minecraft:red_concrete
fill 473 182 268 473 186 269 minecraft:white_concrete
fill 474 182 229 474 185 229 minecraft:red_concrete
fill 474 182 265 474 185 265 minecraft:red_concrete
setblock 481 182 231 minecraft:light[level=15]
setblock 481 182 239 minecraft:light[level=15]
setblock 481 182 247 minecraft:light[level=15]
setblock 481 182 255 minecraft:light[level=15]
setblock 481 182 263 minecraft:light[level=15]
setblock 489 182 231 minecraft:light[level=15]
setblock 489 182 239 minecraft:light[level=15]
setblock 489 182 247 minecraft:light[level=15]
setblock 489 182 255 minecraft:light[level=15]
setblock 489 182 263 minecraft:light[level=15]
setblock 497 182 231 minecraft:light[level=15]
setblock 497 182 239 minecraft:light[level=15]
setblock 497 182 247 minecraft:light[level=15]
setblock 497 182 255 minecraft:light[level=15]
setblock 497 182 263 minecraft:light[level=15]
setblock 505 182 231 minecraft:light[level=15]
setblock 505 182 239 minecraft:light[level=15]
setblock 505 182 247 minecraft:light[level=15]
setblock 505 182 255 minecraft:light[level=15]
setblock 505 182 263 minecraft:light[level=15]
fill 509 182 229 509 186 230 minecraft:red_concrete
fill 509 182 232 509 186 233 minecraft:white_concrete
fill 509 182 265 509 186 266 minecraft:red_concrete
fill 509 182 268 509 186 269 minecraft:white_concrete
fill 510 182 229 510 185 229 minecraft:red_concrete
fill 510 182 265 510 185 265 minecraft:red_concrete
fill 472 183 229 472 187 229 minecraft:red_concrete
setblock 472 183 230 minecraft:white_concrete
fill 472 183 265 472 187 265 minecraft:red_concrete
setblock 472 183 266 minecraft:white_concrete
fill 474 183 232 474 187 233 minecraft:white_concrete
fill 474 183 268 474 187 269 minecraft:white_concrete
setblock 475 183 232 minecraft:red_concrete
setblock 475 183 268 minecraft:red_concrete
fill 508 183 229 508 187 229 minecraft:red_concrete
setblock 508 183 230 minecraft:white_concrete
fill 508 183 265 508 187 265 minecraft:red_concrete
setblock 508 183 266 minecraft:white_concrete
fill 510 183 232 510 187 233 minecraft:white_concrete
fill 510 183 268 510 187 269 minecraft:white_concrete
setblock 511 183 232 minecraft:red_concrete
setblock 511 183 268 minecraft:red_concrete
fill 471 184 230 472 187 230 minecraft:red_concrete
fill 471 184 266 472 187 266 minecraft:red_concrete
setblock 473 184 238 minecraft:light[level=12]
setblock 473 184 245 minecraft:light[level=12]
setblock 473 184 252 minecraft:light[level=12]
setblock 473 184 259 minecraft:light[level=12]
fill 475 184 232 475 188 232 minecraft:white_concrete
fill 475 184 268 475 188 268 minecraft:white_concrete
setblock 480 184 231 minecraft:light[level=12]
setblock 480 184 238 minecraft:light[level=12]
setblock 480 184 245 minecraft:light[level=12]
setblock 480 184 252 minecraft:light[level=12]
setblock 480 184 259 minecraft:light[level=12]
setblock 480 184 266 minecraft:light[level=12]
setblock 487 184 231 minecraft:light[level=12]
setblock 487 184 238 minecraft:light[level=12]
setblock 487 184 245 minecraft:light[level=12]
setblock 487 184 252 minecraft:light[level=12]
setblock 487 184 259 minecraft:light[level=12]
setblock 487 184 266 minecraft:light[level=12]
setblock 494 184 231 minecraft:light[level=12]
setblock 494 184 238 minecraft:light[level=12]
setblock 494 184 245 minecraft:light[level=12]
setblock 494 184 252 minecraft:light[level=12]
setblock 494 184 259 minecraft:light[level=12]
setblock 494 184 266 minecraft:light[level=12]
setblock 501 184 231 minecraft:light[level=12]
setblock 501 184 238 minecraft:light[level=12]
setblock 501 184 245 minecraft:light[level=12]
setblock 501 184 252 minecraft:light[level=12]
setblock 501 184 259 minecraft:light[level=12]
setblock 501 184 266 minecraft:light[level=12]
fill 507 184 230 508 187 230 minecraft:red_concrete
fill 507 184 266 508 187 266 minecraft:red_concrete
setblock 508 184 238 minecraft:light[level=12]
setblock 508 184 245 minecraft:light[level=12]
setblock 508 184 252 minecraft:light[level=12]
setblock 508 184 259 minecraft:light[level=12]
fill 511 184 232 511 188 232 minecraft:white_concrete
fill 511 184 268 511 188 268 minecraft:white_concrete
fill 471 185 231 472 188 231 minecraft:red_concrete
setblock 471 185 232 minecraft:white_concrete
fill 471 185 267 472 188 267 minecraft:red_concrete
setblock 471 185 268 minecraft:white_concrete
fill 473 185 231 475 188 231 minecraft:white_concrete
fill 473 185 267 475 188 267 minecraft:white_concrete
setblock 474 185 230 minecraft:red_concrete
setblock 474 185 266 minecraft:red_concrete
fill 475 185 230 475 188 230 minecraft:white_concrete
fill 475 185 266 475 190 266 minecraft:white_concrete
fill 507 185 231 508 188 231 minecraft:red_concrete
setblock 507 185 232 minecraft:white_concrete
fill 507 185 267 508 188 267 minecraft:red_concrete
setblock 507 185 268 minecraft:white_concrete
fill 509 185 231 511 188 231 minecraft:white_concrete
fill 509 185 267 511 188 267 minecraft:white_concrete
setblock 510 185 230 minecraft:red_concrete
setblock 510 185 266 minecraft:red_concrete
fill 511 185 230 511 188 230 minecraft:white_concrete
fill 511 185 266 511 188 266 minecraft:white_concrete
fill 471 186 232 472 188 232 minecraft:red_concrete
fill 471 186 268 472 188 268 minecraft:red_concrete
setblock 472 186 233 minecraft:white_concrete
setblock 472 186 269 minecraft:white_concrete
fill 473 186 250 473 188 252 minecraft:brown_concrete
fill 473 186 255 484 187 255 minecraft:brown_concrete
fill 474 186 229 474 188 230 minecraft:white_concrete
fill 474 186 247 494 187 247 minecraft:brown_concrete
fill 474 186 251 481 188 252 minecraft:brown_concrete
fill 474 186 254 482 187 254 minecraft:brown_concrete
fill 474 186 256 474 188 256 minecraft:brown_concrete
fill 474 186 265 474 190 266 minecraft:white_concrete
fill 475 186 248 482 187 250 minecraft:brown_concrete
fill 475 186 253 482 187 253 minecraft:brown_concrete
fill 475 186 258 476 188 259 minecraft:brown_concrete
fill 476 186 244 491 188 244 minecraft:brown_concrete
fill 476 186 256 495 187 257 minecraft:brown_concrete
fill 477 186 243 477 188 243 minecraft:brown_concrete
fill 477 186 245 492 187 246 minecraft:brown_concrete
fill 477 186 258 493 187 258 minecraft:brown_concrete
fill 478 186 259 493 188 259 minecraft:brown_concrete
fill 478 186 261 479 188 262 minecraft:brown_concrete
fill 479 186 260 494 188 260 minecraft:brown_concrete
fill 480 186 241 480 188 243 minecraft:brown_concrete
fill 480 186 261 490 188 261 minecraft:brown_concrete
fill 481 186 242 488 188 243 minecraft:brown_concrete
fill 481 186 263 483 188 263 minecraft:brown_concrete
fill 482 186 251 482 187 251 minecraft:brown_concrete
fill 482 186 262 490 188 262 minecraft:brown_concrete
fill 482 186 264 482 188 264 minecraft:brown_concrete
fill 483 186 240 484 188 240 minecraft:brown_concrete
fill 483 186 248 484 187 249 minecraft:brown_concrete
fill 484 186 241 484 188 241 minecraft:brown_concrete
fill 485 186 248 494 187 248 minecraft:brown_concrete
fill 486 186 249 497 187 249 minecraft:brown_concrete
fill 486 186 255 495 187 255 minecraft:brown_concrete
fill 486 186 263 486 188 264 minecraft:brown_concrete
fill 487 186 241 489 188 241 minecraft:brown_concrete
fill 487 186 264 487 188 264 minecraft:brown_concrete
fill 488 186 240 488 188 240 minecraft:brown_concrete
fill 488 186 250 495 187 251 minecraft:brown_concrete
fill 488 186 253 495 187 254 minecraft:brown_concrete
fill 489 186 243 492 188 243 minecraft:brown_concrete
fill 489 186 252 497 187 252 minecraft:brown_concrete
fill 490 186 263 490 188 263 minecraft:brown_concrete
fill 491 186 242 492 188 242 minecraft:brown_concrete
fill 493 186 246 495 188 246 minecraft:brown_concrete
fill 493 186 261 493 188 261 minecraft:brown_concrete
fill 494 186 245 495 188 245 minecraft:brown_concrete
fill 496 186 248 496 188 248 minecraft:brown_concrete
fill 496 186 250 496 188 250 minecraft:brown_concrete
fill 496 186 253 497 188 253 minecraft:brown_concrete
fill 496 186 257 496 188 257 minecraft:brown_concrete
fill 497 186 254 497 188 254 minecraft:brown_concrete
fill 507 186 232 508 189 232 minecraft:red_concrete
fill 507 186 268 508 188 268 minecraft:red_concrete
setblock 508 186 233 minecraft:white_concrete
setblock 508 186 269 minecraft:white_concrete
fill 510 186 229 510 188 230 minecraft:white_concrete
fill 510 186 265 510 188 266 minecraft:white_concrete
fill 472 187 233 473 188 233 minecraft:red_concrete
fill 472 187 269 473 188 269 minecraft:red_concrete
fill 473 187 229 473 188 230 minecraft:white_concrete
fill 473 187 232 473 188 232 minecraft:red_concrete
fill 473 187 265 473 188 266 minecraft:white_concrete
fill 473 187 268 473 188 268 minecraft:red_concrete
fill 508 187 233 509 188 233 minecraft:red_concrete
fill 508 187 269 509 188 269 minecraft:red_concrete
fill 509 187 229 509 188 230 minecraft:white_concrete
fill 509 187 232 509 188 232 minecraft:red_concrete
fill 509 187 265 509 188 266 minecraft:white_concrete
fill 509 187 268 509 188 268 minecraft:red_concrete
setblock 471 188 229 minecraft:brown_terracotta
setblock 471 188 230 minecraft:red_concrete
setblock 471 188 233 minecraft:brown_terracotta
fill 471 188 234 511 188 234 minecraft:brown_concrete
fill 471 188 235 511 188 236 minecraft:brown_terracotta
fill 471 188 237 511 188 237 minecraft:brown_concrete
fill 471 188 238 511 188 239 minecraft:brown_terracotta
fill 471 188 240 482 188 240 minecraft:brown_concrete
fill 471 188 241 479 188 242 minecraft:brown_terracotta
fill 471 188 243 476 188 243 minecraft:brown_concrete
fill 471 188 244 475 188 245 minecraft:brown_terracotta
fill 471 188 246 481 188 246 minecraft:brown_concrete
fill 471 188 247 473 188 248 minecraft:brown_terracotta
fill 471 188 249 482 188 249 minecraft:brown_concrete
fill 471 188 250 472 188 251 minecraft:brown_terracotta
fill 471 188 252 472 188 252 minecraft:brown_concrete
fill 471 188 253 473 188 254 minecraft:brown_terracotta
fill 471 188 255 477 188 255 minecraft:brown_concrete
fill 471 188 256 473 188 257 minecraft:brown_terracotta
fill 471 188 258 474 188 258 minecraft:brown_concrete
fill 471 188 259 474 188 260 minecraft:brown_terracotta
fill 471 188 261 477 188 261 minecraft:brown_concrete
fill 471 188 262 477 188 263 minecraft:brown_terracotta
fill 471 188 264 481 188 264 minecraft:brown_concrete
setblock 471 188 265 minecraft:brown_terracotta
setblock 471 188 266 minecraft:red_concrete
setblock 471 188 269 minecraft:brown_terracotta
fill 472 188 229 472 188 230 minecraft:white_concrete
fill 472 188 265 472 188 266 minecraft:white_concrete
setblock 474 188 232 minecraft:white_concrete
fill 474 188 233 474 192 233 minecraft:red_concrete
fill 474 188 247 482 188 247 minecraft:brown_concrete
setblock 474 188 248 minecraft:brown_terracotta
setblock 474 188 250 minecraft:brown_terracotta
setblock 474 188 253 minecraft:brown_terracotta
fill 474 188 254 477 188 254 minecraft:brown_concrete
fill 474 188 257 475 188 257 minecraft:brown_terracotta
setblock 474 188 268 minecraft:white_concrete
setblock 474 188 269 minecraft:red_concrete
fill 475 188 229 507 188 229 minecraft:brown_terracotta
fill 475 188 233 507 188 233 minecraft:brown_terracotta
fill 475 188 248 482 188 248 minecraft:brown_concrete
fill 475 188 250 481 188 250 minecraft:brown_concrete
fill 475 188 253 477 188 253 minecraft:brown_concrete
setblock 475 188 256 minecraft:brown_terracotta
fill 475 188 260 478 188 260 minecraft:brown_terracotta
fill 475 188 265 507 188 265 minecraft:brown_terracotta
fill 475 188 269 507 188 269 minecraft:brown_terracotta
fill 476 188 230 506 188 230 minecraft:brown_terracotta
fill 476 188 231 506 188 231 minecraft:brown_concrete
fill 476 188 232 506 188 232 minecraft:brown_terracotta
setblock 476 188 245 minecraft:brown_terracotta
fill 476 188 256 478 188 257 minecraft:brown_concrete
fill 476 188 266 506 188 266 minecraft:brown_terracotta
fill 476 188 267 506 188 267 minecraft:brown_concrete
fill 476 188 268 506 188 268 minecraft:brown_terracotta
fill 477 188 245 481 188 245 minecraft:brown_concrete
fill 477 188 258 479 188 258 minecraft:brown_concrete
setblock 477 188 259 minecraft:brown_terracotta
fill 478 188 243 479 188 243 minecraft:brown_concrete
fill 478 188 253 481 188 255 minecraft:brown_terracotta
fill 478 188 263 480 188 263 minecraft:brown_terracotta
fill 479 188 256 482 188 257 minecraft:brown_terracotta
fill 480 188 258 481 188 258 minecraft:brown_terracotta
fill 480 188 262 481 188 262 minecraft:brown_terracotta
fill 481 188 241 483 188 241 minecraft:brown_terracotta
fill 482 188 245 488 188 246 minecraft:brown_terracotta
fill 482 188 250 482 188 251 minecraft:gold_block
fill 482 188 253 482 188 254 minecraft:gold_block
setblock 482 188 255 minecraft:brown_terracotta
fill 482 188 258 488 188 258 minecraft:brown_concrete
fill 483 188 247 484 188 248 minecraft:brown_terracotta
fill 483 188 249 484 188 249 minecraft:gold_block
fill 483 188 255 484 188 255 minecraft:gold_block
fill 483 188 256 487 188 257 minecraft:brown_concrete
fill 483 188 264 485 188 264 minecraft:brown_concrete
fill 484 188 263 485 188 263 minecraft:brown_terracotta
fill 485 188 240 487 188 240 minecraft:brown_concrete
fill 485 188 241 486 188 241 minecraft:brown_terracotta
fill 485 188 247 487 188 247 minecraft:brown_terracotta
setblock 485 188 248 minecraft:brown_concrete
fill 486 188 248 487 188 248 minecraft:brown_terracotta
fill 486 188 249 487 188 249 minecraft:gold_block
fill 486 188 255 487 188 255 minecraft:gold_block
fill 487 188 263 489 188 263 minecraft:brown_terracotta
fill 488 188 247 494 188 249 minecraft:brown_concrete
fill 488 188 250 488 188 251 minecraft:gold_block
fill 488 188 253 488 188 254 minecraft:gold_block
fill 488 188 255 491 188 257 minecraft:brown_terracotta
fill 488 188 264 511 188 264 minecraft:brown_concrete
fill 489 188 240 511 188 240 minecraft:brown_concrete
fill 489 188 242 490 188 242 minecraft:brown_terracotta
fill 489 188 245 492 188 246 minecraft:brown_concrete
fill 489 188 250 489 188 252 minecraft:brown_concrete
fill 489 188 253 492 188 254 minecraft:brown_terracotta
fill 489 188 258 490 188 258 minecraft:brown_terracotta
fill 490 188 241 511 188 241 minecraft:brown_terracotta
fill 490 188 250 495 188 251 minecraft:brown_concrete
fill 490 188 252 492 188 252 minecraft:brown_terracotta
fill 491 188 258 511 188 258 minecraft:brown_concrete
fill 491 188 261 492 188 261 minecraft:brown_concrete
fill 491 188 262 511 188 263 minecraft:brown_terracotta
fill 492 188 244 511 188 244 minecraft:brown_terracotta
setblock 492 188 255 minecraft:brown_terracotta
fill 492 188 256 495 188 257 minecraft:brown_concrete
fill 493 188 242 511 188 242 minecraft:brown_terracotta
fill 493 188 243 511 188 243 minecraft:brown_concrete
setblock 493 188 245 minecraft:brown_terracotta
fill 493 188 252 495 188 255 minecraft:brown_concrete
fill 494 188 259 511 188 259 minecraft:brown_terracotta
fill 494 188 261 511 188 261 minecraft:brown_concrete
fill 495 188 247 495 188 248 minecraft:brown_terracotta
fill 495 188 249 511 188 249 minecraft:brown_concrete
fill 495 188 260 511 188 260 minecraft:brown_terracotta
fill 496 188 245 511 188 245 minecraft:brown_terracotta
fill 496 188 246 511 188 246 minecraft:brown_concrete
fill 496 188 247 511 188 247 minecraft:brown_terracotta
fill 496 188 251 511 188 251 minecraft:brown_terracotta
fill 496 188 252 511 188 252 minecraft:brown_concrete
setblock 496 188 254 minecraft:brown_terracotta
fill 496 188 255 511 188 255 minecraft:brown_concrete
fill 496 188 256 511 188 256 minecraft:brown_terracotta
fill 497 188 248 511 188 248 minecraft:brown_terracotta
fill 497 188 250 511 188 250 minecraft:brown_terracotta
fill 497 188 257 511 188 257 minecraft:brown_terracotta
fill 498 188 253 511 188 254 minecraft:brown_terracotta
setblock 507 188 230 minecraft:red_concrete
setblock 507 188 266 minecraft:red_concrete
fill 508 188 229 508 188 230 minecraft:white_concrete
fill 508 188 265 508 192 266 minecraft:white_concrete
setblock 510 188 232 minecraft:white_concrete
setblock 510 188 233 minecraft:red_concrete
setblock 510 188 268 minecraft:white_concrete
setblock 510 188 269 minecraft:red_concrete
setblock 511 188 229 minecraft:brown_terracotta
setblock 511 188 233 minecraft:brown_terracotta
setblock 511 188 265 minecraft:brown_terracotta
setblock 511 188 269 minecraft:brown_terracotta
fill 471 189 229 473 189 269 minecraft:black_concrete
fill 474 189 229 511 189 231 minecraft:black_concrete
fill 474 189 232 475 192 232 minecraft:red_concrete
fill 474 189 267 511 189 269 minecraft:black_concrete
setblock 475 189 256 minecraft:white_terracotta
setblock 476 189 247 minecraft:white_terracotta
setblock 479 189 251 minecraft:white_terracotta
setblock 479 189 259 minecraft:white_terracotta
setblock 480 189 242 minecraft:white_terracotta
fill 480 189 244 481 189 244 minecraft:white_terracotta
setblock 481 189 239 minecraft:light[level=15]
setblock 481 189 247 minecraft:white_terracotta
fill 481 189 251 481 189 253 minecraft:ochre_froglight
setblock 481 189 255 minecraft:light[level=15]
setblock 481 189 258 minecraft:white_terracotta
setblock 481 189 263 minecraft:light[level=15]
fill 482 189 249 482 189 251 minecraft:ochre_froglight
fill 482 189 253 482 189 255 minecraft:ochre_froglight
setblock 482 189 256 minecraft:white_terracotta
setblock 482 189 259 minecraft:white_terracotta
setblock 482 189 262 minecraft:white_terracotta
fill 483 189 247 484 189 247 minecraft:white_terracotta
fill 483 189 249 484 189 249 minecraft:ochre_froglight
fill 483 189 255 484 189 255 minecraft:ochre_froglight
fill 484 189 245 484 189 246 minecraft:white_terracotta
fill 484 189 248 486 189 248 minecraft:ochre_froglight
fill 484 189 256 486 189 256 minecraft:ochre_froglight
setblock 485 189 257 minecraft:white_terracotta
setblock 486 189 244 minecraft:white_terracotta
setblock 486 189 247 minecraft:white_terracotta
fill 486 189 249 488 189 249 minecraft:ochre_froglight
fill 486 189 255 488 189 255 minecraft:ochre_froglight
setblock 488 189 242 minecraft:white_terracotta
fill 488 189 250 488 189 251 minecraft:ochre_froglight
fill 488 189 253 488 189 254 minecraft:ochre_froglight
setblock 489 189 239 minecraft:light[level=15]
setblock 489 189 244 minecraft:white_terracotta
setblock 489 189 247 minecraft:light[level=15]
setblock 489 189 250 minecraft:white_terracotta
fill 489 189 251 489 189 253 minecraft:ochre_froglight
setblock 489 189 254 minecraft:white_terracotta
setblock 489 189 255 minecraft:light[level=15]
setblock 489 189 263 minecraft:light[level=15]
setblock 491 189 245 minecraft:white_terracotta
setblock 491 189 251 minecraft:white_terracotta
setblock 491 189 255 minecraft:white_terracotta
setblock 495 189 253 minecraft:white_terracotta
setblock 497 189 239 minecraft:light[level=15]
setblock 497 189 247 minecraft:light[level=15]
setblock 497 189 255 minecraft:light[level=15]
setblock 497 189 263 minecraft:light[level=15]
setblock 505 189 239 minecraft:light[level=15]
setblock 505 189 247 minecraft:light[level=15]
setblock 505 189 255 minecraft:light[level=15]
setblock 505 189 263 minecraft:light[level=15]
fill 507 189 266 507 193 266 minecraft:white_concrete
fill 508 189 233 508 190 233 minecraft:red_concrete
fill 509 189 232 511 189 266 minecraft:black_concrete
fill 471 190 229 473 190 269 minecraft:gray_concrete
fill 474 190 229 511 190 231 minecraft:gray_concrete
fill 474 190 267 511 190 269 minecraft:gray_concrete
setblock 480 190 238 minecraft:light[level=12]
setblock 480 190 245 minecraft:light[level=12]
setblock 480 190 252 minecraft:light[level=12]
setblock 480 190 259 minecraft:light[level=12]
setblock 480 190 266 minecraft:light[level=12]
setblock 487 190 238 minecraft:light[level=12]
setblock 487 190 245 minecraft:light[level=12]
setblock 487 190 259 minecraft:light[level=12]
setblock 487 190 266 minecraft:light[level=12]
setblock 494 190 238 minecraft:light[level=12]
setblock 494 190 245 minecraft:light[level=12]
setblock 494 190 252 minecraft:light[level=12]
setblock 494 190 259 minecraft:light[level=12]
setblock 494 190 266 minecraft:light[level=12]
setblock 501 190 238 minecraft:light[level=12]
setblock 501 190 245 minecraft:light[level=12]
setblock 501 190 252 minecraft:light[level=12]
setblock 501 190 259 minecraft:light[level=12]
setblock 501 190 266 minecraft:light[level=12]
fill 507 190 232 507 195 232 minecraft:white_concrete
setblock 508 190 232 minecraft:red_concrete
setblock 508 190 238 minecraft:light[level=12]
setblock 508 190 245 minecraft:light[level=12]
setblock 508 190 252 minecraft:light[level=12]
setblock 508 190 259 minecraft:light[level=12]
fill 509 190 232 511 190 266 minecraft:gray_concrete
fill 471 191 230 472 193 232 minecraft:white_concrete
setblock 471 191 252 minecraft:white_concrete
setblock 471 191 255 minecraft:orange_concrete
setblock 471 191 264 minecraft:orange_concrete
fill 471 191 266 472 193 268 minecraft:white_concrete
fill 472 191 229 474 191 229 minecraft:white_concrete
fill 472 191 233 472 196 233 minecraft:white_concrete
fill 472 191 261 472 192 261 minecraft:brown_concrete
fill 472 191 265 474 191 265 minecraft:white_concrete
fill 472 191 269 472 196 269 minecraft:white_concrete
setblock 473 191 230 minecraft:white_concrete
fill 473 191 231 473 191 232 minecraft:red_concrete
setblock 473 191 233 minecraft:orange_concrete
fill 473 191 234 473 192 234 minecraft:brown_concrete
setblock 473 191 257 minecraft:orange_concrete
setblock 473 191 264 minecraft:orange_concrete
setblock 473 191 266 minecraft:white_concrete
fill 473 191 267 474 191 269 minecraft:red_concrete
fill 474 191 230 475 194 231 minecraft:red_concrete
fill 474 191 266 475 194 266 minecraft:red_concrete
fill 475 191 267 475 193 268 minecraft:red_concrete
fill 475 191 269 475 192 269 minecraft:brown_concrete
fill 477 191 267 477 192 267 minecraft:brown_concrete
setblock 486 191 267 minecraft:light_blue_concrete
setblock 495 191 268 minecraft:yellow_concrete
setblock 500 191 229 minecraft:light_blue_concrete
fill 507 191 230 508 193 231 minecraft:white_concrete
fill 507 191 267 508 194 268 minecraft:white_concrete
fill 508 191 229 510 191 229 minecraft:white_concrete
fill 508 191 232 508 195 233 minecraft:white_concrete
fill 508 191 269 508 196 269 minecraft:white_concrete
setblock 509 191 230 minecraft:white_concrete
fill 509 191 231 510 191 233 minecraft:red_concrete
fill 509 191 265 509 191 266 minecraft:white_concrete
fill 509 191 267 510 191 269 minecraft:red_concrete
fill 510 191 230 511 194 230 minecraft:red_concrete
fill 510 191 242 510 192 242 minecraft:brown_concrete
setblock 510 191 265 minecraft:white_concrete
fill 510 191 266 511 194 266 minecraft:red_concrete
fill 511 191 231 511 193 232 minecraft:red_concrete
setblock 511 191 240 minecraft:orange_concrete
fill 511 191 267 511 193 268 minecraft:red_concrete
setblock 472 192 229 minecraft:white_concrete
setblock 472 192 265 minecraft:white_concrete
fill 473 192 229 473 194 231 minecraft:red_concrete
fill 473 192 232 473 196 233 minecraft:white_concrete
fill 473 192 265 473 194 267 minecraft:red_concrete
fill 473 192 268 473 196 269 minecraft:white_concrete
fill 474 192 229 474 195 229 minecraft:red_concrete
fill 474 192 249 474 195 255 minecraft:iron_block
fill 474 192 265 474 195 265 minecraft:red_concrete
fill 474 192 267 474 192 269 minecraft:red_concrete
fill 475 192 247 475 195 248 minecraft:iron_block
fill 475 192 256 475 195 257 minecraft:iron_block
fill 476 192 245 476 195 246 minecraft:iron_block
fill 476 192 258 476 195 259 minecraft:iron_block
fill 477 192 244 477 192 245 minecraft:iron_block
fill 477 192 259 477 192 260 minecraft:iron_block
fill 478 192 243 478 195 244 minecraft:iron_block
fill 478 192 260 478 195 261 minecraft:iron_block
fill 479 192 243 479 195 243 minecraft:iron_block
fill 479 192 261 479 195 261 minecraft:iron_block
fill 480 192 242 481 195 242 minecraft:iron_block
fill 480 192 262 481 195 262 minecraft:iron_block
fill 482 192 241 488 195 241 minecraft:iron_block
fill 482 192 263 488 195 263 minecraft:iron_block
fill 489 192 242 490 195 242 minecraft:iron_block
fill 489 192 262 490 195 262 minecraft:iron_block
fill 491 192 243 492 195 243 minecraft:iron_block
fill 491 192 261 492 195 261 minecraft:iron_block
fill 492 192 244 493 192 244 minecraft:iron_block
fill 492 192 260 493 192 260 minecraft:iron_block
fill 493 192 245 494 195 245 minecraft:iron_block
fill 493 192 259 494 195 259 minecraft:iron_block
fill 494 192 246 494 195 246 minecraft:iron_block
fill 494 192 258 494 195 258 minecraft:iron_block
fill 495 192 247 495 195 248 minecraft:iron_block
fill 495 192 256 495 195 257 minecraft:iron_block
fill 496 192 249 496 195 255 minecraft:iron_block
setblock 508 192 229 minecraft:white_concrete
fill 509 192 229 509 194 231 minecraft:red_concrete
fill 509 192 232 509 196 233 minecraft:white_concrete
fill 509 192 265 509 194 267 minecraft:red_concrete
fill 509 192 268 509 196 269 minecraft:white_concrete
fill 510 192 229 510 195 229 minecraft:red_concrete
fill 510 192 231 510 192 233 minecraft:red_concrete
fill 510 192 265 510 195 265 minecraft:red_concrete
fill 510 192 267 510 192 269 minecraft:red_concrete
fill 471 193 233 471 198 233 minecraft:brown_concrete
fill 472 193 229 472 197 229 minecraft:red_concrete
fill 472 193 265 472 197 265 minecraft:red_concrete
fill 473 193 249 473 193 255 minecraft:iron_block
fill 474 193 232 474 197 233 minecraft:white_concrete
fill 474 193 247 474 194 248 minecraft:iron_block
fill 474 193 256 474 194 257 minecraft:iron_block
fill 474 193 267 474 194 267 minecraft:red_concrete
fill 474 193 268 474 197 269 minecraft:white_concrete
setblock 475 193 232 minecraft:red_concrete
fill 475 193 245 475 194 246 minecraft:iron_block
fill 475 193 249 475 194 255 minecraft:iron_block
fill 475 193 258 475 194 259 minecraft:iron_block
fill 476 193 244 476 194 244 minecraft:iron_block
fill 476 193 247 476 194 249 minecraft:iron_block
fill 476 193 255 476 194 257 minecraft:iron_block
fill 476 193 260 476 194 260 minecraft:iron_block
fill 477 193 243 477 194 243 minecraft:iron_block
fill 477 193 244 477 194 244 minecraft:light_gray_concrete
fill 477 193 245 477 194 246 minecraft:iron_block
fill 477 193 258 477 194 259 minecraft:iron_block
fill 477 193 260 477 194 260 minecraft:light_gray_concrete
fill 477 193 261 477 194 261 minecraft:iron_block
fill 478 193 242 479 194 242 minecraft:iron_block
fill 478 193 245 478 194 245 minecraft:light_gray_concrete
fill 478 193 259 478 194 259 minecraft:light_gray_concrete
fill 478 193 262 479 194 262 minecraft:iron_block
fill 479 193 244 479 194 244 minecraft:iron_block
fill 479 193 246 479 194 246 minecraft:light_gray_concrete
fill 479 193 258 479 194 258 minecraft:light_gray_concrete
fill 479 193 260 479 194 260 minecraft:iron_block
fill 480 193 241 481 194 241 minecraft:iron_block
fill 480 193 243 482 194 243 minecraft:iron_block
fill 480 193 247 480 194 247 minecraft:light_gray_concrete
fill 480 193 250 480 194 254 minecraft:white_concrete
fill 480 193 257 480 194 257 minecraft:light_gray_concrete
fill 480 193 261 482 194 261 minecraft:iron_block
fill 480 193 263 481 194 263 minecraft:iron_block
fill 481 193 248 481 194 248 minecraft:light_gray_concrete
fill 481 193 249 481 194 250 minecraft:white_concrete
fill 481 193 254 481 194 255 minecraft:white_concrete
fill 481 193 256 481 194 256 minecraft:light_gray_concrete
fill 482 193 240 488 194 240 minecraft:iron_block
fill 482 193 242 488 194 242 minecraft:iron_block
fill 482 193 248 483 194 248 minecraft:white_concrete
fill 482 193 256 483 194 256 minecraft:white_concrete
fill 482 193 262 488 194 262 minecraft:iron_block
fill 482 193 264 488 194 264 minecraft:iron_block
fill 483 193 247 487 194 247 minecraft:white_concrete
fill 483 193 257 487 194 257 minecraft:white_concrete
fill 487 193 248 488 194 248 minecraft:white_concrete
fill 487 193 256 488 194 256 minecraft:white_concrete
fill 488 193 243 490 194 243 minecraft:iron_block
fill 488 193 261 490 194 261 minecraft:iron_block
fill 489 193 241 490 194 241 minecraft:iron_block
fill 489 193 248 489 194 248 minecraft:light_gray_concrete
fill 489 193 249 489 194 250 minecraft:white_concrete
fill 489 193 254 489 194 255 minecraft:white_concrete
fill 489 193 256 489 194 256 minecraft:light_gray_concrete
fill 489 193 263 490 194 263 minecraft:iron_block
fill 490 193 247 490 194 247 minecraft:light_gray_concrete
fill 490 193 250 490 194 254 minecraft:white_concrete
fill 490 193 257 490 194 257 minecraft:light_gray_concrete
fill 491 193 242 492 194 242 minecraft:iron_block
fill 491 193 244 492 194 244 minecraft:iron_block
fill 491 193 246 491 194 246 minecraft:light_gray_concrete
fill 491 193 258 491 194 258 minecraft:light_gray_concrete
fill 491 193 260 492 194 260 minecraft:iron_block
fill 491 193 262 492 194 262 minecraft:iron_block
fill 492 193 245 492 194 245 minecraft:light_gray_concrete
fill 492 193 259 492 194 259 minecraft:light_gray_concrete
fill 493 193 243 493 194 243 minecraft:iron_block
fill 493 193 244 493 194 244 minecraft:light_gray_concrete
fill 493 193 246 493 194 246 minecraft:iron_block
fill 493 193 258 493 194 258 minecraft:iron_block
fill 493 193 260 493 194 260 minecraft:light_gray_concrete
fill 493 193 261 493 194 261 minecraft:iron_block
fill 494 193 244 494 194 244 minecraft:iron_block
fill 494 193 247 494 194 249 minecraft:iron_block
fill 494 193 255 494 194 257 minecraft:iron_block
fill 494 193 260 494 194 260 minecraft:iron_block
fill 495 193 245 495 194 246 minecraft:iron_block
fill 495 193 249 495 194 255 minecraft:iron_block
fill 495 193 258 495 194 259 minecraft:iron_block
fill 496 193 247 496 194 248 minecraft:iron_block
fill 496 193 256 496 194 257 minecraft:iron_block
fill 497 193 249 497 193 255 minecraft:iron_block
fill 508 193 229 508 197 229 minecraft:red_concrete
fill 508 193 265 508 197 265 minecraft:red_concrete
setblock 508 193 266 minecraft:white_concrete
fill 510 193 231 510 194 231 minecraft:red_concrete
fill 510 193 232 510 197 233 minecraft:white_concrete
fill 510 193 267 510 194 267 minecraft:red_concrete
fill 510 193 268 510 197 269 minecraft:white_concrete
fill 471 194 230 472 197 230 minecraft:red_concrete
fill 471 194 231 472 194 232 minecraft:white_concrete
fill 471 194 249 473 194 255 minecraft:blue_stained_glass
fill 471 194 266 472 197 266 minecraft:red_concrete
fill 471 194 267 472 194 268 minecraft:white_concrete
fill 475 194 232 475 198 232 minecraft:white_concrete
setblock 475 194 267 minecraft:red_concrete
fill 475 194 268 475 198 268 minecraft:white_concrete
fill 482 194 247 482 195 247 minecraft:lime_concrete
fill 482 194 249 482 195 249 minecraft:lime_concrete
fill 497 194 249 501 194 255 minecraft:blue_stained_glass
fill 500 194 243 500 195 243 minecraft:yellow_concrete
fill 507 194 230 508 197 230 minecraft:red_concrete
fill 507 194 231 508 194 231 minecraft:white_concrete
fill 507 194 266 508 197 266 minecraft:red_concrete
setblock 511 194 231 minecraft:red_concrete
fill 511 194 232 511 198 232 minecraft:white_concrete
setblock 511 194 267 minecraft:red_concrete
fill 511 194 268 511 198 268 minecraft:white_concrete
fill 471 195 231 472 199 231 minecraft:red_concrete
fill 471 195 232 472 195 232 minecraft:white_concrete
fill 471 195 267 472 199 267 minecraft:red_concrete
fill 471 195 268 472 195 268 minecraft:white_concrete
fill 473 195 229 473 196 230 minecraft:red_concrete
fill 473 195 231 475 199 231 minecraft:white_concrete
fill 473 195 265 473 196 266 minecraft:red_concrete
fill 473 195 267 475 199 267 minecraft:white_concrete
setblock 474 195 230 minecraft:red_concrete
setblock 474 195 266 minecraft:red_concrete
fill 475 195 230 475 200 230 minecraft:white_concrete
fill 475 195 266 475 200 266 minecraft:white_concrete
fill 477 195 244 477 195 245 minecraft:iron_block
fill 477 195 259 477 195 260 minecraft:iron_block
fill 482 195 248 483 195 248 minecraft:lime_concrete
setblock 483 195 247 minecraft:lime_concrete
fill 492 195 244 493 195 244 minecraft:iron_block
fill 492 195 260 493 195 260 minecraft:iron_block
fill 507 195 231 508 199 231 minecraft:red_concrete
fill 507 195 267 508 199 267 minecraft:red_concrete
fill 507 195 268 508 195 268 minecraft:white_concrete
fill 509 195 229 509 196 230 minecraft:red_concrete
fill 509 195 231 511 199 231 minecraft:white_concrete
fill 509 195 265 509 196 266 minecraft:red_concrete
fill 509 195 267 511 199 267 minecraft:white_concrete
setblock 510 195 230 minecraft:red_concrete
setblock 510 195 266 minecraft:red_concrete
fill 511 195 230 511 200 230 minecraft:white_concrete
fill 511 195 266 511 200 266 minecraft:white_concrete
fill 471 196 232 472 199 232 minecraft:red_concrete
fill 471 196 268 472 199 268 minecraft:red_concrete
setblock 473 196 238 minecraft:light[level=12]
setblock 473 196 239 minecraft:light[level=15]
setblock 473 196 245 minecraft:light[level=12]
setblock 473 196 247 minecraft:light[level=15]
setblock 473 196 252 minecraft:light[level=12]
setblock 473 196 255 minecraft:light[level=15]
setblock 473 196 259 minecraft:light[level=12]
setblock 473 196 263 minecraft:light[level=15]
fill 474 196 229 474 200 230 minecraft:white_concrete
fill 474 196 265 474 200 266 minecraft:white_concrete
setblock 480 196 231 minecraft:light[level=12]
setblock 480 196 238 minecraft:light[level=12]
setblock 480 196 245 minecraft:light[level=12]
setblock 480 196 252 minecraft:light[level=12]
setblock 480 196 259 minecraft:light[level=12]
setblock 480 196 266 minecraft:light[level=12]
setblock 481 196 231 minecraft:light[level=15]
setblock 481 196 239 minecraft:light[level=15]
setblock 481 196 247 minecraft:light[level=15]
setblock 481 196 255 minecraft:light[level=15]
setblock 481 196 263 minecraft:light[level=15]
setblock 487 196 231 minecraft:light[level=12]
setblock 487 196 238 minecraft:light[level=12]
setblock 487 196 245 minecraft:light[level=12]
setblock 487 196 252 minecraft:light[level=12]
setblock 487 196 259 minecraft:light[level=12]
setblock 487 196 266 minecraft:light[level=12]
setblock 489 196 231 minecraft:light[level=15]
setblock 489 196 239 minecraft:light[level=15]
setblock 489 196 247 minecraft:light[level=15]
setblock 489 196 255 minecraft:light[level=15]
setblock 489 196 263 minecraft:light[level=15]
setblock 494 196 231 minecraft:light[level=12]
setblock 494 196 238 minecraft:light[level=12]
setblock 494 196 245 minecraft:light[level=12]
setblock 494 196 252 minecraft:light[level=12]
setblock 494 196 259 minecraft:light[level=12]
setblock 494 196 266 minecraft:light[level=12]
setblock 497 196 231 minecraft:light[level=15]
setblock 497 196 239 minecraft:light[level=15]
setblock 497 196 247 minecraft:light[level=15]
setblock 497 196 255 minecraft:light[level=15]
setblock 497 196 263 minecraft:light[level=15]
setblock 501 196 231 minecraft:light[level=12]
setblock 501 196 238 minecraft:light[level=12]
setblock 501 196 245 minecraft:light[level=12]
setblock 501 196 252 minecraft:light[level=12]
setblock 501 196 259 minecraft:light[level=12]
setblock 501 196 266 minecraft:light[level=12]
setblock 505 196 231 minecraft:light[level=15]
setblock 505 196 239 minecraft:light[level=15]
setblock 505 196 247 minecraft:light[level=15]
setblock 505 196 255 minecraft:light[level=15]
setblock 505 196 263 minecraft:light[level=15]
fill 507 196 232 508 199 232 minecraft:red_concrete
fill 507 196 268 508 199 268 minecraft:red_concrete
setblock 508 196 233 minecraft:white_concrete
setblock 508 196 238 minecraft:light[level=12]
setblock 508 196 245 minecraft:light[level=12]
setblock 508 196 252 minecraft:light[level=12]
setblock 508 196 259 minecraft:light[level=12]
fill 510 196 229 510 200 230 minecraft:white_concrete
fill 510 196 265 510 200 266 minecraft:white_concrete
fill 472 197 233 473 200 233 minecraft:red_concrete
fill 472 197 269 473 200 269 minecraft:red_concrete
fill 473 197 229 473 201 230 minecraft:white_concrete
fill 473 197 232 473 201 232 minecraft:red_concrete
fill 473 197 265 473 201 266 minecraft:white_concrete
fill 473 197 268 473 201 268 minecraft:red_concrete
fill 508 197 233 509 200 233 minecraft:red_concrete
fill 508 197 269 509 200 269 minecraft:red_concrete
fill 509 197 229 509 201 230 minecraft:white_concrete
fill 509 197 232 509 201 232 minecraft:red_concrete
fill 509 197 265 509 201 266 minecraft:white_concrete
fill 509 197 268 509 201 268 minecraft:red_concrete
setblock 471 198 230 minecraft:red_concrete
setblock 471 198 266 minecraft:red_concrete
fill 472 198 229 472 202 230 minecraft:white_concrete
fill 472 198 265 472 202 266 minecraft:white_concrete
setblock 474 198 232 minecraft:white_concrete
fill 474 198 233 474 202 233 minecraft:red_concrete
setblock 474 198 268 minecraft:white_concrete
fill 474 198 269 474 202 269 minecraft:red_concrete
setblock 507 198 230 minecraft:red_concrete
setblock 507 198 266 minecraft:red_concrete
fill 508 198 229 508 202 230 minecraft:white_concrete
fill 508 198 265 508 202 266 minecraft:white_concrete
setblock 510 198 232 minecraft:white_concrete
fill 510 198 233 510 202 233 minecraft:red_concrete
setblock 510 198 268 minecraft:white_concrete
fill 510 198 269 510 202 269 minecraft:red_concrete
fill 471 199 230 471 203 230 minecraft:white_concrete
fill 471 199 266 471 203 266 minecraft:white_concrete
fill 474 199 232 475 202 232 minecraft:red_concrete
fill 474 199 268 475 202 268 minecraft:red_concrete
fill 507 199 230 507 203 230 minecraft:white_concrete
fill 507 199 266 507 203 266 minecraft:white_concrete
fill 510 199 232 511 202 232 minecraft:red_concrete
fill 510 199 268 511 202 268 minecraft:red_concrete
fill 471 200 231 471 204 232 minecraft:white_concrete
fill 471 200 267 471 204 268 minecraft:white_concrete
fill 472 200 231 472 204 231 minecraft:white_concrete
setblock 472 200 232 minecraft:red_concrete
fill 472 200 267 472 204 267 minecraft:white_concrete
setblock 472 200 268 minecraft:red_concrete
fill 473 200 231 475 204 231 minecraft:red_concrete
fill 473 200 267 475 204 267 minecraft:red_concrete
fill 482 200 233 484 213 234 minecraft:white_concrete
fill 483 200 232 483 214 232 minecraft:white_concrete
fill 483 200 235 484 212 235 minecraft:white_concrete
fill 507 200 231 507 204 232 minecraft:white_concrete
fill 507 200 267 507 204 268 minecraft:white_concrete
fill 508 200 231 508 204 231 minecraft:white_concrete
setblock 508 200 232 minecraft:red_concrete
fill 508 200 267 508 204 267 minecraft:white_concrete
setblock 508 200 268 minecraft:red_concrete
fill 509 200 231 511 204 231 minecraft:red_concrete
fill 509 200 267 511 204 267 minecraft:red_concrete
fill 472 201 232 472 205 233 minecraft:white_concrete
fill 472 201 268 472 205 269 minecraft:white_concrete
setblock 473 201 233 minecraft:red_concrete
setblock 473 201 269 minecraft:red_concrete
setblock 474 201 229 minecraft:white_concrete
fill 474 201 230 475 204 230 minecraft:red_concrete
setblock 474 201 265 minecraft:white_concrete
fill 474 201 266 475 204 266 minecraft:red_concrete
fill 481 201 233 481 202 234 minecraft:brown_terracotta
setblock 481 201 235 minecraft:yellow_concrete
fill 482 201 232 482 202 232 minecraft:brown_terracotta
fill 482 201 235 482 202 235 minecraft:brown_terracotta
fill 483 201 236 484 202 236 minecraft:brown_terracotta
fill 484 201 232 485 202 232 minecraft:brown_terracotta
fill 485 201 233 485 202 235 minecraft:brown_terracotta
fill 508 201 232 508 205 233 minecraft:white_concrete
fill 508 201 268 508 205 269 minecraft:white_concrete
setblock 509 201 233 minecraft:red_concrete
setblock 509 201 269 minecraft:red_concrete
setblock 510 201 229 minecraft:white_concrete
fill 510 201 230 511 204 230 minecraft:red_concrete
setblock 510 201 265 minecraft:white_concrete
fill 510 201 266 511 204 266 minecraft:red_concrete
fill 473 202 229 473 206 230 minecraft:red_concrete
fill 473 202 232 473 206 233 minecraft:white_concrete
setblock 473 202 238 minecraft:light[level=12]
setblock 473 202 245 minecraft:light[level=12]
setblock 473 202 252 minecraft:light[level=12]
setblock 473 202 259 minecraft:light[level=12]
fill 473 202 265 473 206 266 minecraft:red_concrete
fill 473 202 268 473 206 269 minecraft:white_concrete
fill 474 202 229 474 205 229 minecraft:red_concrete
fill 474 202 265 474 205 265 minecraft:red_concrete
setblock 480 202 231 minecraft:light[level=12]
setblock 480 202 238 minecraft:light[level=12]
setblock 480 202 245 minecraft:light[level=12]
setblock 480 202 252 minecraft:light[level=12]
setblock 480 202 259 minecraft:light[level=12]
setblock 480 202 266 minecraft:light[level=12]
setblock 481 202 232 minecraft:brown_terracotta
setblock 481 202 235 minecraft:brown_terracotta
fill 482 202 231 484 202 231 minecraft:brown_terracotta
setblock 482 202 236 minecraft:brown_terracotta
setblock 485 202 236 minecraft:brown_terracotta
fill 486 202 233 486 202 235 minecraft:brown_terracotta
setblock 487 202 231 minecraft:light[level=12]
setblock 487 202 238 minecraft:light[level=12]
setblock 487 202 245 minecraft:light[level=12]
setblock 487 202 259 minecraft:light[level=12]
setblock 487 202 266 minecraft:light[level=12]
setblock 494 202 231 minecraft:light[level=12]
setblock 494 202 238 minecraft:light[level=12]
setblock 494 202 245 minecraft:light[level=12]
setblock 494 202 252 minecraft:light[level=12]
setblock 494 202 259 minecraft:light[level=12]
setblock 494 202 266 minecraft:light[level=12]
setblock 501 202 231 minecraft:light[level=12]
setblock 501 202 238 minecraft:light[level=12]
setblock 501 202 245 minecraft:light[level=12]
setblock 501 202 252 minecraft:light[level=12]
setblock 501 202 259 minecraft:light[level=12]
setblock 501 202 266 minecraft:light[level=12]
setblock 508 202 238 minecraft:light[level=12]
setblock 508 202 245 minecraft:light[level=12]
setblock 508 202 252 minecraft:light[level=12]
setblock 508 202 259 minecraft:light[level=12]
fill 509 202 229 509 206 230 minecraft:red_concrete
fill 509 202 232 509 206 233 minecraft:white_concrete
fill 509 202 265 509 206 266 minecraft:red_concrete
fill 509 202 268 509 206 269 minecraft:white_concrete
fill 510 202 229 510 205 229 minecraft:red_concrete
fill 510 202 265 510 205 265 minecraft:red_concrete
fill 472 203 229 472 207 229 minecraft:red_concrete
setblock 472 203 230 minecraft:white_concrete
fill 472 203 265 472 207 265 minecraft:red_concrete
setblock 472 203 266 minecraft:white_concrete
setblock 473 203 239 minecraft:light[level=15]
setblock 473 203 247 minecraft:light[level=15]
setblock 473 203 255 minecraft:light[level=15]
setblock 473 203 263 minecraft:light[level=15]
fill 474 203 232 474 207 233 minecraft:white_concrete
fill 474 203 268 474 207 269 minecraft:white_concrete
setblock 475 203 232 minecraft:red_concrete
setblock 475 203 268 minecraft:red_concrete
setblock 481 203 231 minecraft:light[level=15]
setblock 481 203 239 minecraft:light[level=15]
setblock 481 203 247 minecraft:light[level=15]
setblock 481 203 255 minecraft:light[level=15]
setblock 481 203 263 minecraft:light[level=15]
setblock 489 203 231 minecraft:light[level=15]
setblock 489 203 239 minecraft:light[level=15]
setblock 489 203 247 minecraft:light[level=15]
setblock 489 203 255 minecraft:light[level=15]
setblock 489 203 263 minecraft:light[level=15]
setblock 497 203 231 minecraft:light[level=15]
setblock 497 203 239 minecraft:light[level=15]
setblock 497 203 247 minecraft:light[level=15]
setblock 497 203 255 minecraft:light[level=15]
setblock 497 203 263 minecraft:light[level=15]
setblock 505 203 231 minecraft:light[level=15]
setblock 505 203 239 minecraft:light[level=15]
setblock 505 203 247 minecraft:light[level=15]
setblock 505 203 255 minecraft:light[level=15]
setblock 505 203 263 minecraft:light[level=15]
fill 508 203 229 508 207 229 minecraft:red_concrete
setblock 508 203 230 minecraft:white_concrete
fill 508 203 265 508 207 265 minecraft:red_concrete
setblock 508 203 266 minecraft:white_concrete
fill 510 203 232 510 207 233 minecraft:white_concrete
fill 510 203 268 510 207 269 minecraft:white_concrete
setblock 511 203 232 minecraft:red_concrete
setblock 511 203 268 minecraft:red_concrete
fill 471 204 230 472 207 230 minecraft:red_concrete
fill 471 204 241 477 204 241 minecraft:brown_terracotta
fill 471 204 266 472 207 266 minecraft:red_concrete
fill 473 204 239 477 205 240 minecraft:brown_terracotta
fill 473 204 242 477 205 243 minecraft:brown_terracotta
fill 475 204 232 475 208 232 minecraft:white_concrete
fill 475 204 268 475 208 268 minecraft:white_concrete
fill 507 204 230 508 207 230 minecraft:red_concrete
fill 507 204 266 508 207 266 minecraft:red_concrete
fill 511 204 232 511 208 232 minecraft:white_concrete
fill 511 204 268 511 208 268 minecraft:white_concrete
fill 471 205 231 472 209 231 minecraft:red_concrete
setblock 471 205 232 minecraft:white_concrete
fill 471 205 267 472 209 267 minecraft:red_concrete
setblock 471 205 268 minecraft:white_concrete
fill 473 205 231 475 209 231 minecraft:white_concrete
fill 473 205 241 477 205 241 minecraft:brown_terracotta
fill 473 205 267 475 209 267 minecraft:white_concrete
setblock 474 205 230 minecraft:red_concrete
setblock 474 205 266 minecraft:red_concrete
fill 475 205 230 475 209 230 minecraft:white_concrete
fill 475 205 266 475 210 266 minecraft:white_concrete
fill 489 205 269 489 208 269 minecraft:brown_concrete
fill 507 205 231 508 209 231 minecraft:red_concrete
setblock 507 205 232 minecraft:white_concrete
fill 507 205 267 508 209 267 minecraft:red_concrete
setblock 507 205 268 minecraft:white_concrete
fill 509 205 231 511 209 231 minecraft:white_concrete
fill 509 205 267 511 209 267 minecraft:white_concrete
setblock 510 205 230 minecraft:red_concrete
setblock 510 205 266 minecraft:red_concrete
fill 511 205 230 511 209 230 minecraft:white_concrete
fill 511 205 266 511 209 266 minecraft:white_concrete
fill 471 206 232 472 209 232 minecraft:red_concrete
fill 471 206 268 472 209 268 minecraft:red_concrete
setblock 472 206 233 minecraft:white_concrete
setblock 472 206 269 minecraft:white_concrete
fill 474 206 229 474 209 230 minecraft:white_concrete
fill 474 206 241 476 212 241 minecraft:white_concrete
fill 474 206 265 474 210 266 minecraft:white_concrete
fill 475 206 240 475 212 240 minecraft:white_concrete
fill 475 206 242 475 212 242 minecraft:white_concrete
fill 507 206 232 508 209 232 minecraft:red_concrete
fill 507 206 268 508 209 268 minecraft:red_concrete
setblock 508 206 233 minecraft:white_concrete
setblock 508 206 269 minecraft:white_concrete
fill 510 206 229 510 209 230 minecraft:white_concrete
fill 510 206 265 510 209 266 minecraft:white_concrete
fill 472 207 233 473 209 233 minecraft:red_concrete
fill 472 207 269 473 209 269 minecraft:red_concrete
fill 473 207 229 473 209 230 minecraft:white_concrete
fill 473 207 232 473 209 232 minecraft:red_concrete
fill 473 207 265 473 209 266 minecraft:white_concrete
fill 473 207 268 473 209 268 minecraft:red_concrete
fill 508 207 233 509 209 233 minecraft:red_concrete
fill 508 207 269 509 209 269 minecraft:red_concrete
fill 509 207 229 509 209 230 minecraft:white_concrete
fill 509 207 232 509 209 232 minecraft:red_concrete
fill 509 207 265 509 209 266 minecraft:white_concrete
fill 509 207 268 509 209 268 minecraft:red_concrete
setblock 471 208 230 minecraft:red_concrete
setblock 471 208 266 minecraft:red_concrete
fill 472 208 229 472 209 230 minecraft:white_concrete
fill 472 208 265 472 209 266 minecraft:white_concrete
setblock 473 208 238 minecraft:light[level=12]
setblock 473 208 245 minecraft:light[level=12]
setblock 473 208 252 minecraft:light[level=12]
setblock 473 208 259 minecraft:light[level=12]
setblock 474 208 232 minecraft:white_concrete
fill 474 208 233 474 212 233 minecraft:red_concrete
setblock 474 208 268 minecraft:white_concrete
fill 474 208 269 474 209 269 minecraft:red_concrete
setblock 480 208 231 minecraft:light[level=12]
setblock 480 208 238 minecraft:light[level=12]
setblock 480 208 245 minecraft:light[level=12]
setblock 480 208 252 minecraft:light[level=12]
setblock 480 208 259 minecraft:light[level=12]
setblock 480 208 266 minecraft:light[level=12]
setblock 487 208 231 minecraft:light[level=12]
setblock 487 208 238 minecraft:light[level=12]
setblock 487 208 245 minecraft:light[level=12]
setblock 487 208 259 minecraft:light[level=12]
setblock 487 208 266 minecraft:light[level=12]
setblock 494 208 231 minecraft:light[level=12]
setblock 494 208 238 minecraft:light[level=12]
setblock 494 208 245 minecraft:light[level=12]
setblock 494 208 252 minecraft:light[level=12]
setblock 494 208 259 minecraft:light[level=12]
setblock 494 208 266 minecraft:light[level=12]
setblock 501 208 231 minecraft:light[level=12]
setblock 501 208 238 minecraft:light[level=12]
setblock 501 208 245 minecraft:light[level=12]
setblock 501 208 252 minecraft:light[level=12]
setblock 501 208 259 minecraft:light[level=12]
setblock 501 208 266 minecraft:light[level=12]
setblock 507 208 230 minecraft:red_concrete
setblock 507 208 266 minecraft:red_concrete
fill 508 208 229 508 209 230 minecraft:white_concrete
setblock 508 208 238 minecraft:light[level=12]
setblock 508 208 245 minecraft:light[level=12]
setblock 508 208 252 minecraft:light[level=12]
setblock 508 208 259 minecraft:light[level=12]
fill 508 208 265 508 212 266 minecraft:white_concrete
setblock 510 208 232 minecraft:white_concrete
fill 510 208 233 510 209 233 minecraft:red_concrete
setblock 510 208 268 minecraft:white_concrete
fill 510 208 269 510 209 269 minecraft:red_concrete
setblock 471 209 230 minecraft:white_concrete
setblock 471 209 266 minecraft:white_concrete
fill 474 209 232 475 212 232 minecraft:red_concrete
fill 474 209 268 475 209 268 minecraft:red_concrete
fill 475 209 269 475 221 269 minecraft:brown_terracotta
setblock 507 209 230 minecraft:white_concrete
fill 507 209 266 507 213 266 minecraft:white_concrete
fill 510 209 232 511 209 232 minecraft:red_concrete
fill 510 209 268 511 209 268 minecraft:red_concrete
fill 471 210 229 473 210 269 minecraft:black_concrete
fill 474 210 229 511 210 231 minecraft:black_concrete
fill 474 210 267 474 210 269 minecraft:black_concrete
fill 475 210 267 511 210 268 minecraft:black_concrete
fill 476 210 269 511 210 269 minecraft:black_concrete
setblock 481 210 239 minecraft:light[level=15]
setblock 481 210 247 minecraft:light[level=15]
setblock 481 210 255 minecraft:light[level=15]
setblock 481 210 263 minecraft:light[level=15]
setblock 489 210 239 minecraft:light[level=15]
setblock 489 210 247 minecraft:light[level=15]
setblock 489 210 255 minecraft:light[level=15]
setblock 489 210 263 minecraft:light[level=15]
setblock 497 210 239 minecraft:light[level=15]
setblock 497 210 247 minecraft:light[level=15]
setblock 497 210 255 minecraft:light[level=15]
setblock 497 210 263 minecraft:light[level=15]
setblock 505 210 239 minecraft:light[level=15]
setblock 505 210 247 minecraft:light[level=15]
setblock 505 210 255 minecraft:light[level=15]
setblock 505 210 263 minecraft:light[level=15]
fill 507 210 232 507 215 232 minecraft:white_concrete
fill 508 210 232 508 210 233 minecraft:red_concrete
fill 509 210 232 511 210 266 minecraft:black_concrete
fill 471 211 229 473 211 269 minecraft:gray_concrete
fill 474 211 229 511 211 231 minecraft:gray_concrete
fill 474 211 239 474 214 240 minecraft:magenta_concrete
fill 474 211 242 474 214 243 minecraft:magenta_concrete
setblock 474 211 265 minecraft:white_concrete
fill 474 211 266 475 214 266 minecraft:red_concrete
fill 474 211 267 474 211 269 minecraft:gray_concrete
fill 475 211 239 477 214 239 minecraft:magenta_concrete
fill 475 211 243 477 214 243 minecraft:magenta_concrete
fill 475 211 267 511 211 268 minecraft:gray_concrete
fill 476 211 240 477 214 240 minecraft:magenta_concrete
fill 476 211 242 477 214 242 minecraft:magenta_concrete
fill 476 211 269 511 211 269 minecraft:gray_concrete
fill 477 211 241 477 214 241 minecraft:magenta_concrete
fill 508 211 232 508 215 233 minecraft:white_concrete
fill 509 211 232 511 211 266 minecraft:gray_concrete
fill 471 212 230 472 213 232 minecraft:white_concrete
setblock 471 212 243 minecraft:white_concrete
fill 471 212 266 472 213 268 minecraft:white_concrete
setblock 472 212 229 minecraft:white_concrete
fill 472 212 233 473 216 233 minecraft:white_concrete
fill 472 212 239 473 213 243 minecraft:magenta_concrete
setblock 472 212 265 minecraft:white_concrete
fill 472 212 269 473 216 269 minecraft:white_concrete
fill 473 212 229 474 214 231 minecraft:red_concrete
fill 473 212 232 473 216 232 minecraft:white_concrete
fill 473 212 238 477 213 238 minecraft:magenta_concrete
fill 473 212 244 477 213 244 minecraft:magenta_concrete
fill 473 212 265 473 214 267 minecraft:red_concrete
fill 473 212 268 473 216 268 minecraft:white_concrete
fill 474 212 265 474 215 265 minecraft:red_concrete
fill 474 212 267 474 212 269 minecraft:red_concrete
fill 475 212 230 475 214 230 minecraft:red_concrete
setblock 475 212 231 minecraft:lime_concrete
fill 475 212 267 475 213 268 minecraft:red_concrete
fill 478 212 239 478 213 243 minecraft:magenta_concrete
fill 479 212 230 479 213 230 minecraft:brown_concrete
setblock 481 212 230 minecraft:white_concrete
fill 482 212 267 482 213 267 minecraft:brown_concrete
setblock 484 212 268 minecraft:lime_concrete
setblock 492 212 268 minecraft:lime_concrete
setblock 497 212 229 minecraft:yellow_concrete
setblock 497 212 231 minecraft:white_concrete
fill 503 212 231 503 213 231 minecraft:brown_concrete
fill 507 212 230 508 213 231 minecraft:white_concrete
fill 507 212 267 508 214 268 minecraft:white_concrete
setblock 508 212 229 minecraft:white_concrete
fill 508 212 269 509 216 269 minecraft:white_concrete
fill 509 212 229 510 214 231 minecraft:red_concrete
fill 509 212 232 509 216 233 minecraft:white_concrete
fill 509 212 265 510 214 267 minecraft:red_concrete
fill 509 212 268 509 216 268 minecraft:white_concrete
fill 510 212 232 510 212 233 minecraft:red_concrete
setblock 510 212 253 minecraft:magenta_concrete
fill 510 212 268 510 212 269 minecraft:red_concrete
fill 511 212 230 511 213 232 minecraft:red_concrete
setblock 511 212 256 minecraft:orange_concrete
fill 511 212 266 511 213 268 minecraft:red_concrete
setblock 470 213 234 minecraft:light_blue_concrete
fill 470 213 235 511 216 235 minecraft:brown_terracotta
setblock 470 213 236 minecraft:light_blue_concrete
fill 472 213 229 472 217 229 minecraft:red_concrete
fill 472 213 265 472 217 265 minecraft:red_concrete
fill 474 213 232 474 217 233 minecraft:white_concrete
fill 474 213 241 476 214 241 minecraft:magenta_concrete
fill 474 213 267 474 214 267 minecraft:red_concrete
fill 474 213 268 474 217 269 minecraft:white_concrete
fill 475 213 231 475 213 232 minecraft:red_concrete
fill 475 213 240 475 214 240 minecraft:magenta_concrete
fill 475 213 242 475 214 242 minecraft:magenta_concrete
setblock 484 213 268 minecraft:brown_concrete
fill 508 213 229 508 217 229 minecraft:red_concrete
fill 508 213 265 508 217 265 minecraft:red_concrete
setblock 508 213 266 minecraft:white_concrete
fill 510 213 232 510 217 233 minecraft:white_concrete
fill 510 213 268 510 217 269 minecraft:white_concrete
fill 470 214 234 511 215 234 minecraft:brown_terracotta
fill 470 214 236 511 215 236 minecraft:brown_terracotta
fill 471 214 230 472 217 230 minecraft:red_concrete
fill 471 214 231 472 214 232 minecraft:white_concrete
fill 471 214 266 472 217 266 minecraft:red_concrete
fill 471 214 267 472 214 268 minecraft:white_concrete
setblock 473 214 238 minecraft:light[level=12]
fill 473 214 239 473 214 243 minecraft:magenta_concrete
setblock 473 214 245 minecraft:light[level=12]
setblock 473 214 252 minecraft:light[level=12]
setblock 473 214 259 minecraft:light[level=12]
setblock 475 214 231 minecraft:red_concrete
fill 475 214 232 475 218 232 minecraft:white_concrete
setblock 475 214 267 minecraft:red_concrete
fill 475 214 268 475 218 268 minecraft:white_concrete
setblock 480 214 231 minecraft:light[level=12]
setblock 480 214 238 minecraft:light[level=12]
setblock 480 214 245 minecraft:light[level=12]
setblock 480 214 252 minecraft:light[level=12]
setblock 480 214 259 minecraft:light[level=12]
setblock 480 214 266 minecraft:light[level=12]
fill 482 214 233 484 214 233 minecraft:white_concrete
setblock 487 214 231 minecraft:light[level=12]
setblock 487 214 238 minecraft:light[level=12]
setblock 487 214 245 minecraft:light[level=12]
setblock 487 214 259 minecraft:light[level=12]
setblock 487 214 266 minecraft:light[level=12]
setblock 494 214 231 minecraft:light[level=12]
setblock 494 214 238 minecraft:light[level=12]
setblock 494 214 245 minecraft:light[level=12]
setblock 494 214 252 minecraft:light[level=12]
setblock 494 214 259 minecraft:light[level=12]
setblock 494 214 266 minecraft:light[level=12]
setblock 501 214 231 minecraft:light[level=12]
setblock 501 214 238 minecraft:light[level=12]
setblock 501 214 245 minecraft:light[level=12]
setblock 501 214 252 minecraft:light[level=12]
setblock 501 214 259 minecraft:light[level=12]
setblock 501 214 266 minecraft:light[level=12]
fill 507 214 230 508 217 230 minecraft:red_concrete
fill 507 214 231 508 214 231 minecraft:white_concrete
fill 507 214 266 508 217 266 minecraft:red_concrete
setblock 508 214 238 minecraft:light[level=12]
setblock 508 214 245 minecraft:light[level=12]
setblock 508 214 252 minecraft:light[level=12]
setblock 508 214 259 minecraft:light[level=12]
fill 511 214 230 511 214 231 minecraft:red_concrete
fill 511 214 232 511 218 232 minecraft:white_concrete
fill 511 214 266 511 214 267 minecraft:red_concrete
fill 511 214 268 511 218 268 minecraft:white_concrete
fill 512 214 234 512 308 234 minecraft:light_blue_concrete
fill 512 214 235 512 215 235 minecraft:brown_terracotta
fill 512 214 236 512 308 236 minecraft:light_blue_concrete
fill 471 215 231 472 219 231 minecraft:red_concrete
fill 471 215 232 472 215 232 minecraft:white_concrete
fill 471 215 267 472 219 267 minecraft:red_concrete
fill 471 215 268 472 215 268 minecraft:white_concrete
fill 473 215 229 474 215 230 minecraft:red_concrete
fill 473 215 231 475 219 231 minecraft:white_concrete
fill 473 215 265 473 216 266 minecraft:red_concrete
fill 473 215 267 475 219 267 minecraft:white_concrete
setblock 474 215 266 minecraft:red_concrete
fill 475 215 230 475 220 230 minecraft:white_concrete
fill 475 215 266 475 220 266 minecraft:white_concrete
fill 482 215 233 482 222 233 minecraft:white_concrete
fill 483 215 231 487 216 233 minecraft:brown_terracotta
fill 485 215 229 485 215 230 minecraft:brown_terracotta
fill 507 215 231 508 219 231 minecraft:red_concrete
fill 507 215 267 508 219 267 minecraft:red_concrete
fill 507 215 268 508 215 268 minecraft:white_concrete
fill 509 215 229 510 215 230 minecraft:red_concrete
fill 509 215 231 511 219 231 minecraft:white_concrete
fill 509 215 265 510 215 266 minecraft:red_concrete
fill 509 215 267 511 219 267 minecraft:white_concrete
fill 511 215 230 511 220 230 minecraft:white_concrete
fill 511 215 266 511 220 266 minecraft:white_concrete
fill 470 216 234 470 308 234 minecraft:light_blue_concrete
fill 470 216 236 470 308 236 minecraft:light_blue_concrete
fill 471 216 232 472 219 232 minecraft:red_concrete
fill 471 216 268 472 219 268 minecraft:red_concrete
fill 473 216 229 473 216 230 minecraft:red_concrete
fill 474 216 229 474 220 230 minecraft:white_concrete
fill 474 216 265 474 220 266 minecraft:white_concrete
fill 482 216 234 482 222 234 minecraft:white_concrete
fill 483 216 234 487 216 234 minecraft:brown_terracotta
fill 507 216 232 508 219 232 minecraft:red_concrete
fill 507 216 268 508 219 268 minecraft:red_concrete
setblock 508 216 233 minecraft:white_concrete
fill 509 216 229 509 216 230 minecraft:red_concrete
fill 509 216 265 509 216 266 minecraft:red_concrete
fill 510 216 229 510 220 230 minecraft:white_concrete
fill 510 216 265 510 220 266 minecraft:white_concrete
fill 512 216 235 512 308 235 minecraft:light_blue_concrete
fill 470 217 235 470 308 235 minecraft:light_blue_concrete
fill 472 217 233 473 220 233 minecraft:red_concrete
fill 472 217 269 473 220 269 minecraft:red_concrete
fill 473 217 229 473 221 230 minecraft:white_concrete
fill 473 217 232 473 221 232 minecraft:red_concrete
setblock 473 217 239 minecraft:light[level=15]
setblock 473 217 247 minecraft:light[level=15]
setblock 473 217 255 minecraft:light[level=15]
setblock 473 217 263 minecraft:light[level=15]
fill 473 217 265 473 221 266 minecraft:white_concrete
fill 473 217 268 473 221 268 minecraft:red_concrete
setblock 481 217 231 minecraft:light[level=15]
setblock 481 217 239 minecraft:light[level=15]
setblock 481 217 247 minecraft:light[level=15]
setblock 481 217 255 minecraft:light[level=15]
setblock 481 217 263 minecraft:light[level=15]
fill 483 217 232 483 221 235 minecraft:white_concrete
fill 484 217 233 484 221 235 minecraft:white_concrete
fill 485 217 232 485 223 234 minecraft:white_concrete
fill 486 217 233 486 223 233 minecraft:white_concrete
setblock 489 217 231 minecraft:light[level=15]
setblock 489 217 239 minecraft:light[level=15]
setblock 489 217 247 minecraft:light[level=15]
setblock 489 217 255 minecraft:light[level=15]
setblock 489 217 263 minecraft:light[level=15]
setblock 497 217 231 minecraft:light[level=15]
setblock 497 217 239 minecraft:light[level=15]
setblock 497 217 247 minecraft:light[level=15]
setblock 497 217 255 minecraft:light[level=15]
setblock 497 217 263 minecraft:light[level=15]
setblock 505 217 231 minecraft:light[level=15]
setblock 505 217 239 minecraft:light[level=15]
setblock 505 217 247 minecraft:light[level=15]
setblock 505 217 255 minecraft:light[level=15]
setblock 505 217 263 minecraft:light[level=15]
fill 508 217 233 509 220 233 minecraft:red_concrete
fill 508 217 269 509 220 269 minecraft:red_concrete
fill 509 217 229 509 221 230 minecraft:white_concrete
fill 509 217 232 509 221 232 minecraft:red_concrete
fill 509 217 265 509 221 266 minecraft:white_concrete
fill 509 217 268 509 221 268 minecraft:red_concrete
setblock 471 218 230 minecraft:red_concrete
setblock 471 218 266 minecraft:red_concrete
fill 472 218 229 472 222 230 minecraft:white_concrete
fill 472 218 265 472 222 266 minecraft:white_concrete
setblock 474 218 232 minecraft:white_concrete
fill 474 218 233 474 222 233 minecraft:red_concrete
setblock 474 218 268 minecraft:white_concrete
fill 474 218 269 474 222 269 minecraft:red_concrete
setblock 507 218 230 minecraft:red_concrete
setblock 507 218 266 minecraft:red_concrete
fill 508 218 229 508 222 230 minecraft:white_concrete
fill 508 218 265 508 222 266 minecraft:white_concrete
setblock 510 218 232 minecraft:white_concrete
fill 510 218 233 510 222 233 minecraft:red_concrete
setblock 510 218 268 minecraft:white_concrete
fill 510 218 269 510 222 269 minecraft:red_concrete
fill 471 219 230 471 223 230 minecraft:white_concrete
fill 471 219 266 471 223 266 minecraft:white_concrete
fill 474 219 232 475 222 232 minecraft:red_concrete
fill 474 219 268 475 222 268 minecraft:red_concrete
fill 507 219 230 507 223 230 minecraft:white_concrete
fill 507 219 266 507 223 266 minecraft:white_concrete
fill 510 219 232 511 222 232 minecraft:red_concrete
fill 510 219 268 511 222 268 minecraft:red_concrete
fill 471 220 231 471 224 232 minecraft:white_concrete
fill 471 220 267 471 224 268 minecraft:white_concrete
fill 472 220 231 472 224 231 minecraft:white_concrete
setblock 472 220 232 minecraft:red_concrete
fill 472 220 267 472 224 267 minecraft:white_concrete
setblock 472 220 268 minecraft:red_concrete
fill 473 220 231 475 224 231 minecraft:red_concrete
setblock 473 220 238 minecraft:light[level=12]
setblock 473 220 245 minecraft:light[level=12]
setblock 473 220 252 minecraft:light[level=12]
setblock 473 220 259 minecraft:light[level=12]
fill 473 220 267 475 224 267 minecraft:red_concrete
setblock 480 220 231 minecraft:light[level=12]
setblock 480 220 238 minecraft:light[level=12]
setblock 480 220 245 minecraft:light[level=12]
setblock 480 220 252 minecraft:light[level=12]
setblock 480 220 259 minecraft:light[level=12]
setblock 480 220 266 minecraft:light[level=12]
setblock 487 220 231 minecraft:light[level=12]
setblock 487 220 238 minecraft:light[level=12]
setblock 487 220 245 minecraft:light[level=12]
setblock 487 220 259 minecraft:light[level=12]
setblock 487 220 266 minecraft:light[level=12]
setblock 494 220 231 minecraft:light[level=12]
setblock 494 220 238 minecraft:light[level=12]
setblock 494 220 245 minecraft:light[level=12]
setblock 494 220 252 minecraft:light[level=12]
setblock 494 220 259 minecraft:light[level=12]
setblock 494 220 266 minecraft:light[level=12]
setblock 501 220 231 minecraft:light[level=12]
setblock 501 220 238 minecraft:light[level=12]
setblock 501 220 245 minecraft:light[level=12]
setblock 501 220 252 minecraft:light[level=12]
setblock 501 220 259 minecraft:light[level=12]
setblock 501 220 266 minecraft:light[level=12]
fill 507 220 231 507 224 232 minecraft:white_concrete
fill 507 220 267 507 224 268 minecraft:white_concrete
fill 508 220 231 508 224 231 minecraft:white_concrete
setblock 508 220 232 minecraft:red_concrete
setblock 508 220 238 minecraft:light[level=12]
setblock 508 220 245 minecraft:light[level=12]
setblock 508 220 252 minecraft:light[level=12]
setblock 508 220 259 minecraft:light[level=12]
fill 508 220 267 508 224 267 minecraft:white_concrete
setblock 508 220 268 minecraft:red_concrete
fill 509 220 231 511 224 231 minecraft:red_concrete
fill 509 220 267 511 224 267 minecraft:red_concrete
fill 472 221 232 472 225 233 minecraft:white_concrete
schedule function dropper:buildpart/58_3 1t
