fill 450 215 584 450 217 584 minecraft:basalt
fill 450 215 590 451 215 590 minecraft:basalt
fill 451 215 578 451 217 579 minecraft:basalt
fill 451 215 581 451 217 582 minecraft:basalt
setblock 455 215 574 minecraft:magma_block
setblock 455 215 575 minecraft:basalt
setblock 455 215 585 minecraft:basalt
setblock 455 215 586 minecraft:magma_block
setblock 456 215 581 minecraft:basalt
fill 457 215 559 457 216 560 minecraft:iron_block
setblock 436 216 575 minecraft:basalt
setblock 436 216 585 minecraft:magma_block
fill 438 216 578 438 217 578 minecraft:basalt
fill 438 216 581 438 217 581 minecraft:basalt
setblock 439 216 572 minecraft:magma_block
setblock 439 216 578 minecraft:magma_block
fill 439 216 580 439 217 580 minecraft:basalt
setblock 439 216 581 minecraft:magma_block
fill 440 216 576 440 217 577 minecraft:basalt
fill 440 216 583 440 217 583 minecraft:basalt
setblock 441 216 576 minecraft:basalt
setblock 441 216 584 minecraft:basalt
fill 442 216 575 442 217 575 minecraft:basalt
fill 442 216 585 442 217 585 minecraft:basalt
fill 443 216 570 444 216 570 minecraft:basalt
setblock 445 216 570 minecraft:magma_block
fill 445 216 574 446 217 574 minecraft:basalt
fill 445 216 586 446 217 586 minecraft:basalt
fill 448 216 570 449 216 570 minecraft:basalt
setblock 448 216 575 minecraft:magma_block
fill 448 216 585 449 217 585 minecraft:basalt
setblock 448 216 590 minecraft:magma_block
setblock 449 216 576 minecraft:basalt
setblock 449 216 584 minecraft:basalt
setblock 449 216 590 minecraft:basalt
fill 450 216 577 450 217 577 minecraft:basalt
fill 450 216 583 450 217 583 minecraft:basalt
setblock 451 216 580 minecraft:magma_block
setblock 453 216 573 minecraft:basalt
fill 453 216 585 453 217 585 minecraft:basalt
setblock 454 216 585 minecraft:magma_block
setblock 438 217 574 minecraft:magma_block
setblock 438 217 577 minecraft:magma_block
setblock 438 217 579 minecraft:basalt
setblock 438 217 580 minecraft:magma_block
setblock 438 217 583 minecraft:magma_block
setblock 438 217 586 minecraft:magma_block
setblock 439 217 578 minecraft:basalt
setblock 439 217 581 minecraft:basalt
fill 440 217 578 440 217 582 minecraft:magma_block
fill 441 217 571 441 217 572 minecraft:basalt
setblock 441 217 573 minecraft:magma_block
fill 441 217 576 441 217 577 minecraft:magma_block
fill 441 217 583 441 217 585 minecraft:magma_block
setblock 441 217 586 minecraft:basalt
setblock 441 217 588 minecraft:magma_block
setblock 441 217 589 minecraft:basalt
fill 442 217 572 443 217 572 minecraft:basalt
setblock 442 217 576 minecraft:magma_block
setblock 442 217 584 minecraft:magma_block
fill 443 217 575 447 217 575 minecraft:magma_block
fill 443 217 585 447 217 585 minecraft:magma_block
setblock 443 217 587 minecraft:basalt
setblock 444 217 572 minecraft:magma_block
setblock 444 217 587 minecraft:magma_block
setblock 445 217 572 minecraft:basalt
fill 445 217 587 447 217 587 minecraft:basalt
setblock 445 217 589 minecraft:basalt
setblock 447 217 571 minecraft:magma_block
setblock 447 217 574 minecraft:magma_block
setblock 447 217 586 minecraft:magma_block
setblock 447 217 589 minecraft:magma_block
setblock 448 217 575 minecraft:basalt
fill 448 217 576 450 217 576 minecraft:magma_block
fill 448 217 584 449 217 584 minecraft:magma_block
setblock 449 217 571 minecraft:basalt
setblock 449 217 577 minecraft:magma_block
setblock 449 217 583 minecraft:magma_block
setblock 449 217 589 minecraft:basalt
setblock 450 217 573 minecraft:magma_block
fill 450 217 578 450 217 582 minecraft:magma_block
setblock 450 217 585 minecraft:magma_block
setblock 450 217 588 minecraft:magma_block
setblock 451 217 573 minecraft:basalt
setblock 451 217 580 minecraft:basalt
setblock 452 217 587 minecraft:basalt
setblock 453 217 575 minecraft:magma_block
setblock 453 217 577 minecraft:basalt
setblock 453 217 578 minecraft:magma_block
fill 453 217 579 453 217 580 minecraft:basalt
setblock 453 217 581 minecraft:magma_block
fill 453 217 582 453 217 583 minecraft:basalt
setblock 453 217 584 minecraft:magma_block
setblock 454 217 576 minecraft:basalt
setblock 454 217 584 minecraft:basalt
fill 456 218 577 457 219 577 minecraft:red_concrete
setblock 426 219 560 minecraft:light[level=14]
setblock 426 219 568 minecraft:light[level=14]
setblock 426 219 576 minecraft:light[level=14]
setblock 426 219 584 minecraft:light[level=14]
setblock 426 219 592 minecraft:light[level=14]
setblock 434 219 560 minecraft:light[level=14]
setblock 434 219 568 minecraft:light[level=14]
setblock 434 219 576 minecraft:light[level=14]
setblock 434 219 584 minecraft:light[level=14]
setblock 434 219 592 minecraft:light[level=14]
setblock 442 219 560 minecraft:light[level=14]
setblock 442 219 568 minecraft:light[level=14]
setblock 442 219 576 minecraft:light[level=14]
setblock 442 219 584 minecraft:light[level=14]
setblock 442 219 592 minecraft:light[level=14]
fill 445 219 589 447 220 589 minecraft:purple_concrete
fill 446 219 588 447 220 588 minecraft:purple_concrete
setblock 450 219 560 minecraft:light[level=14]
setblock 450 219 568 minecraft:light[level=14]
setblock 450 219 576 minecraft:light[level=14]
setblock 450 219 584 minecraft:light[level=14]
setblock 450 219 592 minecraft:light[level=14]
fill 451 219 573 451 220 573 minecraft:orange_concrete
setblock 458 219 560 minecraft:light[level=14]
setblock 458 219 568 minecraft:light[level=14]
setblock 458 219 576 minecraft:light[level=14]
setblock 458 219 584 minecraft:light[level=14]
setblock 458 219 592 minecraft:light[level=14]
fill 423 220 562 423 227 562 minecraft:yellow_concrete
fill 423 220 570 423 227 570 minecraft:yellow_concrete
fill 423 220 578 423 227 578 minecraft:yellow_concrete
fill 423 220 586 423 227 586 minecraft:yellow_concrete
fill 423 220 594 423 227 594 minecraft:yellow_concrete
fill 426 220 599 426 227 599 minecraft:yellow_concrete
fill 430 220 557 430 227 557 minecraft:yellow_concrete
fill 434 220 599 434 227 599 minecraft:yellow_concrete
fill 438 220 557 438 227 557 minecraft:yellow_concrete
fill 442 220 599 442 227 599 minecraft:yellow_concrete
fill 446 220 557 446 227 557 minecraft:yellow_concrete
fill 450 220 599 450 227 599 minecraft:yellow_concrete
fill 454 220 557 454 227 557 minecraft:yellow_concrete
fill 458 220 599 458 227 599 minecraft:yellow_concrete
fill 462 220 557 462 227 557 minecraft:yellow_concrete
fill 465 220 562 465 227 562 minecraft:yellow_concrete
fill 465 220 570 465 227 570 minecraft:yellow_concrete
fill 465 220 578 465 227 578 minecraft:yellow_concrete
fill 465 220 586 465 227 586 minecraft:yellow_concrete
fill 465 220 594 465 227 594 minecraft:yellow_concrete
fill 453 221 575 453 222 575 minecraft:light_blue_concrete
fill 424 224 558 424 225 563 minecraft:white_concrete
fill 424 224 566 425 224 571 minecraft:white_concrete
fill 424 224 574 425 224 579 minecraft:white_concrete
fill 424 224 582 425 224 587 minecraft:white_concrete
fill 424 224 590 425 224 595 minecraft:white_concrete
fill 424 224 598 429 225 598 minecraft:white_concrete
fill 425 224 559 425 224 565 minecraft:white_concrete
fill 425 224 572 425 224 573 minecraft:white_concrete
fill 425 224 580 425 224 581 minecraft:white_concrete
fill 425 224 588 425 224 589 minecraft:white_concrete
fill 425 224 596 425 224 597 minecraft:white_concrete
fill 426 224 559 463 224 559 minecraft:white_concrete
fill 426 224 597 464 224 597 minecraft:white_concrete
fill 427 224 558 432 225 558 minecraft:white_concrete
fill 432 224 598 437 225 598 minecraft:white_concrete
fill 435 224 558 440 225 558 minecraft:white_concrete
fill 440 224 598 445 225 598 minecraft:white_concrete
fill 443 224 558 448 225 558 minecraft:white_concrete
fill 445 224 569 445 225 571 minecraft:yellow_concrete
fill 446 224 569 446 225 570 minecraft:yellow_concrete
fill 448 224 598 453 225 598 minecraft:white_concrete
fill 451 224 558 456 225 558 minecraft:white_concrete
fill 456 224 598 461 225 598 minecraft:white_concrete
fill 459 224 558 464 225 558 minecraft:white_concrete
fill 463 224 560 463 224 596 minecraft:white_concrete
fill 464 224 561 464 225 566 minecraft:white_concrete
fill 464 224 569 464 225 574 minecraft:white_concrete
fill 464 224 577 464 225 582 minecraft:white_concrete
fill 464 224 585 464 225 590 minecraft:white_concrete
fill 464 224 593 464 225 596 minecraft:white_concrete
fill 464 224 598 464 225 598 minecraft:white_concrete
fill 424 225 566 424 225 571 minecraft:white_concrete
fill 424 225 574 424 225 579 minecraft:white_concrete
fill 424 225 582 424 225 587 minecraft:white_concrete
fill 424 225 590 424 225 595 minecraft:white_concrete
fill 436 225 593 437 226 594 minecraft:orange_concrete
setblock 464 225 597 minecraft:white_concrete
setblock 426 227 560 minecraft:light[level=14]
setblock 426 227 568 minecraft:light[level=14]
setblock 426 227 576 minecraft:light[level=14]
setblock 426 227 584 minecraft:light[level=14]
setblock 426 227 592 minecraft:light[level=14]
setblock 434 227 560 minecraft:light[level=14]
setblock 434 227 568 minecraft:light[level=14]
setblock 434 227 576 minecraft:light[level=14]
setblock 434 227 584 minecraft:light[level=14]
setblock 434 227 592 minecraft:light[level=14]
setblock 442 227 560 minecraft:light[level=14]
setblock 442 227 568 minecraft:light[level=14]
setblock 442 227 576 minecraft:light[level=14]
setblock 442 227 584 minecraft:light[level=14]
setblock 442 227 592 minecraft:light[level=14]
setblock 450 227 560 minecraft:light[level=14]
setblock 450 227 568 minecraft:light[level=14]
setblock 450 227 576 minecraft:light[level=14]
setblock 450 227 584 minecraft:light[level=14]
setblock 450 227 592 minecraft:light[level=14]
setblock 458 227 560 minecraft:light[level=14]
setblock 458 227 568 minecraft:light[level=14]
setblock 458 227 576 minecraft:light[level=14]
setblock 458 227 584 minecraft:light[level=14]
setblock 458 227 592 minecraft:light[level=14]
fill 423 228 562 423 233 562 minecraft:sea_lantern
fill 423 228 570 423 233 570 minecraft:sea_lantern
fill 423 228 578 423 233 578 minecraft:sea_lantern
fill 423 228 586 423 233 586 minecraft:sea_lantern
fill 423 228 594 423 233 594 minecraft:sea_lantern
fill 426 228 599 426 233 599 minecraft:sea_lantern
fill 430 228 557 430 233 557 minecraft:sea_lantern
fill 434 228 599 434 233 599 minecraft:sea_lantern
fill 438 228 557 438 233 557 minecraft:sea_lantern
fill 442 228 599 442 233 599 minecraft:sea_lantern
fill 446 228 557 446 233 557 minecraft:sea_lantern
fill 450 228 599 450 233 599 minecraft:sea_lantern
fill 454 228 557 454 233 557 minecraft:sea_lantern
fill 458 228 599 458 233 599 minecraft:sea_lantern
fill 462 228 557 462 233 557 minecraft:sea_lantern
fill 465 228 562 465 233 562 minecraft:sea_lantern
fill 465 228 570 465 233 570 minecraft:sea_lantern
fill 465 228 578 465 233 578 minecraft:sea_lantern
fill 465 228 586 465 233 586 minecraft:sea_lantern
fill 465 228 594 465 233 594 minecraft:sea_lantern
fill 440 229 593 441 230 593 minecraft:red_concrete
fill 426 231 576 427 232 580 minecraft:white_concrete
fill 427 231 572 427 232 575 minecraft:white_concrete
fill 427 231 581 427 232 584 minecraft:white_concrete
fill 428 231 570 428 232 572 minecraft:white_concrete
fill 428 231 584 428 232 586 minecraft:white_concrete
fill 429 231 568 429 232 570 minecraft:white_concrete
fill 429 231 586 429 232 588 minecraft:white_concrete
fill 430 231 567 430 232 568 minecraft:white_concrete
fill 430 231 588 430 232 589 minecraft:white_concrete
fill 431 231 566 431 232 567 minecraft:white_concrete
fill 431 231 589 431 232 590 minecraft:white_concrete
fill 432 231 565 432 232 566 minecraft:white_concrete
fill 432 231 590 432 232 591 minecraft:white_concrete
fill 433 231 564 433 232 565 minecraft:white_concrete
fill 433 231 591 433 232 592 minecraft:white_concrete
fill 434 231 563 434 232 564 minecraft:white_concrete
fill 434 231 592 434 232 593 minecraft:white_concrete
fill 435 231 563 436 232 563 minecraft:white_concrete
fill 435 231 593 436 232 593 minecraft:white_concrete
fill 436 231 562 438 232 562 minecraft:white_concrete
fill 436 231 594 438 232 594 minecraft:white_concrete
fill 438 231 561 450 232 561 minecraft:white_concrete
fill 438 231 595 450 232 595 minecraft:white_concrete
fill 442 231 560 446 232 560 minecraft:white_concrete
fill 442 231 596 446 232 596 minecraft:white_concrete
fill 450 231 562 452 232 562 minecraft:white_concrete
fill 450 231 594 452 232 594 minecraft:white_concrete
fill 452 231 563 454 232 563 minecraft:white_concrete
fill 452 231 593 454 232 593 minecraft:white_concrete
fill 454 231 564 455 232 564 minecraft:white_concrete
fill 454 231 592 455 232 592 minecraft:white_concrete
fill 455 231 565 456 232 565 minecraft:white_concrete
fill 455 231 591 456 232 591 minecraft:white_concrete
fill 456 231 566 457 232 566 minecraft:white_concrete
fill 456 231 590 457 232 590 minecraft:white_concrete
fill 457 231 567 458 232 567 minecraft:white_concrete
fill 457 231 589 458 232 589 minecraft:white_concrete
fill 458 231 568 459 232 568 minecraft:white_concrete
fill 458 231 588 459 232 588 minecraft:white_concrete
fill 459 231 569 459 232 570 minecraft:white_concrete
fill 459 231 586 459 232 587 minecraft:white_concrete
fill 460 231 570 460 232 572 minecraft:white_concrete
fill 460 231 584 460 232 586 minecraft:white_concrete
fill 461 231 572 461 232 584 minecraft:white_concrete
fill 462 231 576 462 232 580 minecraft:white_concrete
fill 423 233 557 423 233 558 minecraft:orange_concrete
fill 423 233 559 423 236 559 minecraft:yellow_concrete
fill 423 233 560 423 233 561 minecraft:orange_concrete
setblock 423 233 566 minecraft:orange_concrete
setblock 423 233 583 minecraft:orange_concrete
fill 423 233 587 423 233 588 minecraft:orange_concrete
fill 423 233 589 423 236 589 minecraft:yellow_concrete
fill 424 233 557 424 236 557 minecraft:yellow_concrete
setblock 425 233 557 minecraft:orange_concrete
fill 426 233 557 426 236 557 minecraft:yellow_concrete
fill 426 233 574 426 233 580 minecraft:sea_lantern
fill 427 233 571 427 233 573 minecraft:sea_lantern
fill 427 233 599 429 236 599 minecraft:yellow_concrete
fill 428 233 569 428 233 570 minecraft:sea_lantern
setblock 429 233 568 minecraft:sea_lantern
fill 430 233 566 430 233 567 minecraft:sea_lantern
setblock 430 233 599 minecraft:orange_concrete
setblock 431 233 557 minecraft:orange_concrete
fill 431 233 565 431 233 566 minecraft:sea_lantern
fill 431 233 599 433 234 599 minecraft:yellow_concrete
fill 432 233 557 433 236 557 minecraft:yellow_concrete
fill 432 233 564 432 233 565 minecraft:sea_lantern
setblock 433 233 564 minecraft:sea_lantern
setblock 434 233 563 minecraft:sea_lantern
setblock 435 233 557 minecraft:orange_concrete
fill 435 233 562 436 233 562 minecraft:sea_lantern
fill 436 233 557 437 236 557 minecraft:yellow_concrete
fill 437 233 561 439 233 561 minecraft:sea_lantern
fill 440 233 560 448 233 560 minecraft:sea_lantern
fill 449 233 561 451 233 561 minecraft:sea_lantern
fill 452 233 562 453 233 562 minecraft:sea_lantern
setblock 453 233 557 minecraft:orange_concrete
setblock 454 233 563 minecraft:sea_lantern
fill 455 233 557 456 233 557 minecraft:orange_concrete
fill 455 233 564 456 233 564 minecraft:sea_lantern
fill 456 233 565 457 233 565 minecraft:sea_lantern
fill 457 233 557 457 236 557 minecraft:yellow_concrete
fill 457 233 566 458 233 566 minecraft:sea_lantern
setblock 458 233 567 minecraft:sea_lantern
fill 458 233 587 458 234 587 minecraft:blue_concrete
setblock 459 233 568 minecraft:sea_lantern
setblock 459 233 588 minecraft:sea_lantern
fill 460 233 569 460 233 570 minecraft:sea_lantern
fill 460 233 586 460 233 587 minecraft:sea_lantern
fill 461 233 571 461 233 573 minecraft:sea_lantern
fill 461 233 583 461 233 585 minecraft:sea_lantern
fill 462 233 574 462 233 582 minecraft:sea_lantern
fill 464 233 557 464 234 557 minecraft:yellow_concrete
setblock 465 233 557 minecraft:orange_concrete
fill 465 233 573 465 233 575 minecraft:yellow_concrete
fill 465 233 576 465 235 576 minecraft:orange_concrete
fill 465 233 577 465 236 577 minecraft:yellow_concrete
setblock 465 233 579 minecraft:orange_concrete
setblock 465 233 580 minecraft:yellow_concrete
setblock 465 233 585 minecraft:orange_concrete
fill 423 234 557 423 236 558 minecraft:yellow_concrete
fill 423 234 560 423 236 562 minecraft:yellow_concrete
fill 423 234 566 423 236 566 minecraft:yellow_concrete
fill 423 234 570 423 236 570 minecraft:yellow_concrete
setblock 423 234 571 minecraft:orange_concrete
fill 423 234 578 423 237 578 minecraft:yellow_concrete
setblock 423 234 583 minecraft:yellow_concrete
fill 423 234 586 423 236 588 minecraft:yellow_concrete
setblock 423 234 594 minecraft:yellow_concrete
fill 425 234 557 425 236 557 minecraft:yellow_concrete
fill 426 234 599 426 236 599 minecraft:yellow_concrete
fill 427 234 557 428 236 557 minecraft:yellow_concrete
setblock 429 234 557 minecraft:orange_concrete
fill 430 234 557 431 234 557 minecraft:yellow_concrete
fill 430 234 599 430 236 599 minecraft:yellow_concrete
fill 434 234 599 434 237 599 minecraft:yellow_concrete
fill 435 234 557 435 236 557 minecraft:yellow_concrete
fill 438 234 557 441 236 557 minecraft:yellow_concrete
setblock 442 234 557 minecraft:orange_concrete
fill 442 234 599 442 236 599 minecraft:yellow_concrete
fill 443 234 557 444 236 557 minecraft:yellow_concrete
fill 446 234 557 449 234 557 minecraft:yellow_concrete
setblock 450 234 557 minecraft:orange_concrete
fill 450 234 599 450 236 599 minecraft:yellow_concrete
fill 451 234 557 456 234 557 minecraft:yellow_concrete
fill 458 234 599 458 236 599 minecraft:yellow_concrete
fill 459 234 557 459 236 557 minecraft:yellow_concrete
setblock 460 234 557 minecraft:orange_concrete
fill 461 234 557 461 236 557 minecraft:yellow_concrete
setblock 462 234 557 minecraft:orange_concrete
setblock 465 234 557 minecraft:yellow_concrete
setblock 465 234 562 minecraft:orange_concrete
fill 465 234 570 465 236 570 minecraft:yellow_concrete
fill 465 234 571 465 235 571 minecraft:orange_concrete
fill 465 234 573 465 236 574 minecraft:yellow_concrete
setblock 465 234 575 minecraft:orange_concrete
fill 465 234 578 465 234 579 minecraft:yellow_concrete
setblock 465 234 580 minecraft:orange_concrete
fill 465 234 585 465 237 586 minecraft:yellow_concrete
fill 465 234 590 465 236 590 minecraft:yellow_concrete
setblock 465 234 591 minecraft:orange_concrete
fill 465 234 592 465 236 594 minecraft:yellow_concrete
setblock 465 234 598 minecraft:orange_concrete
fill 423 235 571 423 236 571 minecraft:yellow_concrete
setblock 423 235 583 minecraft:orange_concrete
setblock 423 235 594 minecraft:orange_concrete
setblock 426 235 560 minecraft:light[level=14]
setblock 426 235 568 minecraft:light[level=14]
setblock 426 235 576 minecraft:light[level=14]
setblock 426 235 584 minecraft:light[level=14]
setblock 426 235 592 minecraft:light[level=14]
fill 429 235 557 429 237 557 minecraft:yellow_concrete
setblock 430 235 557 minecraft:orange_concrete
fill 431 235 557 431 236 557 minecraft:yellow_concrete
fill 431 235 599 431 236 599 minecraft:yellow_concrete
setblock 432 235 599 minecraft:orange_concrete
fill 433 235 599 433 237 599 minecraft:yellow_concrete
setblock 434 235 560 minecraft:light[level=14]
setblock 434 235 568 minecraft:light[level=14]
setblock 434 235 576 minecraft:light[level=14]
setblock 434 235 584 minecraft:light[level=14]
setblock 434 235 592 minecraft:light[level=14]
fill 438 235 599 438 236 599 minecraft:yellow_concrete
fill 439 235 599 440 235 599 minecraft:orange_concrete
fill 442 235 557 442 236 557 minecraft:yellow_concrete
setblock 442 235 560 minecraft:light[level=14]
setblock 442 235 568 minecraft:light[level=14]
setblock 442 235 576 minecraft:light[level=14]
setblock 442 235 584 minecraft:light[level=14]
setblock 442 235 592 minecraft:light[level=14]
setblock 446 235 557 minecraft:orange_concrete
fill 447 235 557 447 236 557 minecraft:yellow_concrete
setblock 448 235 557 minecraft:orange_concrete
fill 449 235 557 450 236 557 minecraft:yellow_concrete
setblock 450 235 560 minecraft:light[level=14]
setblock 450 235 568 minecraft:light[level=14]
setblock 450 235 576 minecraft:light[level=14]
setblock 450 235 584 minecraft:light[level=14]
setblock 450 235 592 minecraft:light[level=14]
setblock 451 235 557 minecraft:orange_concrete
fill 452 235 557 453 236 557 minecraft:yellow_concrete
setblock 454 235 557 minecraft:orange_concrete
fill 455 235 557 456 237 557 minecraft:yellow_concrete
fill 455 235 599 455 236 599 minecraft:yellow_concrete
fill 456 235 599 457 235 599 minecraft:orange_concrete
setblock 458 235 560 minecraft:light[level=14]
setblock 458 235 568 minecraft:light[level=14]
setblock 458 235 576 minecraft:light[level=14]
setblock 458 235 584 minecraft:light[level=14]
setblock 458 235 592 minecraft:light[level=14]
fill 460 235 557 460 236 557 minecraft:yellow_concrete
fill 462 235 557 462 236 557 minecraft:yellow_concrete
fill 464 235 557 465 235 557 minecraft:orange_concrete
fill 465 235 562 465 236 562 minecraft:yellow_concrete
fill 465 235 567 465 236 568 minecraft:yellow_concrete
setblock 465 235 569 minecraft:orange_concrete
fill 465 235 575 465 236 575 minecraft:yellow_concrete
fill 465 235 578 465 236 578 minecraft:yellow_concrete
setblock 465 235 579 minecraft:orange_concrete
fill 465 235 580 465 236 580 minecraft:yellow_concrete
fill 465 235 591 465 236 591 minecraft:yellow_concrete
fill 465 235 598 465 236 598 minecraft:yellow_concrete
setblock 423 236 583 minecraft:yellow_concrete
setblock 423 236 594 minecraft:yellow_concrete
setblock 430 236 557 minecraft:yellow_concrete
setblock 432 236 599 minecraft:yellow_concrete
fill 439 236 599 440 236 599 minecraft:yellow_concrete
setblock 446 236 557 minecraft:yellow_concrete
setblock 448 236 557 minecraft:yellow_concrete
fill 451 236 557 451 237 557 minecraft:yellow_concrete
setblock 454 236 557 minecraft:yellow_concrete
fill 456 236 599 457 236 599 minecraft:yellow_concrete
fill 464 236 557 465 236 557 minecraft:yellow_concrete
setblock 465 236 569 minecraft:yellow_concrete
setblock 465 236 571 minecraft:yellow_concrete
setblock 465 236 576 minecraft:yellow_concrete
setblock 465 236 579 minecraft:yellow_concrete
fill 423 237 557 423 237 572 minecraft:orange_concrete
setblock 423 237 573 minecraft:yellow_concrete
fill 423 237 574 423 237 577 minecraft:orange_concrete
fill 423 237 579 423 272 580 minecraft:orange_concrete
setblock 423 237 581 minecraft:yellow_concrete
fill 423 237 582 423 238 599 minecraft:orange_concrete
fill 424 237 557 428 238 557 minecraft:orange_concrete
fill 426 237 576 427 238 580 minecraft:white_concrete
fill 426 237 599 432 237 599 minecraft:orange_concrete
fill 427 237 572 427 238 575 minecraft:white_concrete
fill 427 237 581 427 238 584 minecraft:white_concrete
fill 428 237 570 428 238 572 minecraft:white_concrete
fill 428 237 584 428 238 586 minecraft:white_concrete
fill 429 237 568 429 238 570 minecraft:white_concrete
fill 429 237 586 429 238 588 minecraft:white_concrete
fill 430 237 557 449 237 557 minecraft:orange_concrete
fill 430 237 567 430 238 568 minecraft:white_concrete
fill 430 237 588 430 238 589 minecraft:white_concrete
fill 431 237 566 431 238 567 minecraft:white_concrete
fill 431 237 589 431 238 590 minecraft:white_concrete
fill 432 237 565 432 238 566 minecraft:white_concrete
fill 432 237 590 432 238 591 minecraft:white_concrete
fill 433 237 564 433 238 565 minecraft:white_concrete
fill 433 237 577 433 238 577 minecraft:light_blue_concrete
fill 433 237 591 433 238 592 minecraft:white_concrete
fill 434 237 563 434 238 564 minecraft:white_concrete
fill 434 237 592 434 238 593 minecraft:white_concrete
fill 435 237 563 436 238 563 minecraft:white_concrete
fill 435 237 593 436 238 593 minecraft:white_concrete
fill 435 237 599 439 238 599 minecraft:orange_concrete
fill 436 237 562 438 238 562 minecraft:white_concrete
fill 436 237 594 438 238 594 minecraft:white_concrete
fill 438 237 561 450 238 561 minecraft:white_concrete
fill 438 237 595 450 238 595 minecraft:white_concrete
setblock 440 237 599 minecraft:yellow_concrete
fill 441 237 599 460 237 599 minecraft:orange_concrete
fill 442 237 560 446 238 560 minecraft:white_concrete
fill 442 237 596 446 238 596 minecraft:white_concrete
setblock 450 237 557 minecraft:yellow_concrete
fill 450 237 562 452 238 562 minecraft:white_concrete
fill 450 237 594 452 238 594 minecraft:white_concrete
fill 452 237 557 454 237 557 minecraft:orange_concrete
fill 452 237 563 454 238 563 minecraft:white_concrete
fill 452 237 593 454 238 593 minecraft:white_concrete
fill 454 237 564 455 238 564 minecraft:white_concrete
fill 454 237 592 455 238 592 minecraft:white_concrete
fill 455 237 565 456 238 565 minecraft:white_concrete
fill 455 237 591 456 238 591 minecraft:white_concrete
fill 456 237 566 457 238 566 minecraft:white_concrete
fill 456 237 590 457 238 590 minecraft:white_concrete
fill 457 237 557 465 237 557 minecraft:orange_concrete
fill 457 237 567 458 238 567 minecraft:white_concrete
fill 457 237 589 458 238 589 minecraft:white_concrete
fill 458 237 568 459 238 568 minecraft:white_concrete
fill 458 237 588 459 238 588 minecraft:white_concrete
fill 459 237 569 459 238 570 minecraft:white_concrete
fill 459 237 586 459 238 587 minecraft:white_concrete
fill 460 237 570 460 238 572 minecraft:white_concrete
fill 460 237 584 460 238 586 minecraft:white_concrete
fill 461 237 572 461 238 584 minecraft:white_concrete
setblock 461 237 599 minecraft:yellow_concrete
fill 462 237 576 462 238 580 minecraft:white_concrete
fill 462 237 599 465 237 599 minecraft:orange_concrete
fill 465 237 558 465 272 559 minecraft:orange_concrete
setblock 465 237 560 minecraft:yellow_concrete
fill 465 237 561 465 237 565 minecraft:orange_concrete
fill 465 237 567 465 237 573 minecraft:orange_concrete
setblock 465 237 574 minecraft:yellow_concrete
fill 465 237 575 465 237 584 minecraft:orange_concrete
fill 465 237 587 465 255 595 minecraft:orange_concrete
setblock 465 237 596 minecraft:yellow_concrete
fill 465 237 597 465 238 598 minecraft:orange_concrete
fill 423 238 557 423 238 558 minecraft:orange_concrete
setblock 423 238 559 minecraft:yellow_concrete
fill 423 238 560 423 270 561 minecraft:orange_concrete
setblock 423 238 562 minecraft:yellow_concrete
fill 423 238 563 423 272 563 minecraft:orange_concrete
setblock 423 238 564 minecraft:yellow_concrete
fill 423 238 565 423 272 565 minecraft:orange_concrete
fill 423 238 566 423 239 566 minecraft:yellow_concrete
fill 423 238 567 423 255 573 minecraft:orange_concrete
setblock 423 238 574 minecraft:yellow_concrete
fill 423 238 575 423 272 576 minecraft:orange_concrete
setblock 423 238 577 minecraft:yellow_concrete
fill 423 238 578 423 255 578 minecraft:orange_concrete
fill 423 238 581 423 269 581 minecraft:orange_concrete
fill 424 238 558 424 238 563 minecraft:white_concrete
fill 424 238 566 425 238 571 minecraft:white_concrete
fill 424 238 574 425 238 579 minecraft:white_concrete
fill 424 238 582 425 238 587 minecraft:white_concrete
fill 424 238 590 425 238 595 minecraft:white_concrete
fill 424 238 598 429 238 598 minecraft:white_concrete
fill 424 238 599 426 238 599 minecraft:orange_concrete
fill 425 238 559 425 238 565 minecraft:white_concrete
fill 425 238 572 425 238 573 minecraft:white_concrete
fill 425 238 580 425 238 581 minecraft:white_concrete
fill 425 238 588 425 238 589 minecraft:white_concrete
fill 425 238 596 425 238 597 minecraft:white_concrete
fill 426 238 559 463 238 559 minecraft:white_concrete
fill 426 238 597 464 238 597 minecraft:white_concrete
fill 427 238 558 432 238 558 minecraft:white_concrete
setblock 427 238 599 minecraft:yellow_concrete
fill 428 238 599 434 238 599 minecraft:orange_concrete
fill 429 238 557 429 272 557 minecraft:orange_concrete
fill 430 238 557 430 239 557 minecraft:yellow_concrete
fill 431 238 557 443 238 557 minecraft:orange_concrete
fill 432 238 598 437 238 598 minecraft:white_concrete
fill 435 238 558 440 238 558 minecraft:white_concrete
fill 440 238 598 445 238 598 minecraft:white_concrete
fill 440 238 599 441 270 599 minecraft:orange_concrete
setblock 442 238 599 minecraft:yellow_concrete
fill 443 238 558 448 238 558 minecraft:white_concrete
fill 443 238 599 464 238 599 minecraft:orange_concrete
setblock 444 238 557 minecraft:yellow_concrete
fill 445 238 557 453 238 557 minecraft:orange_concrete
fill 448 238 598 453 238 598 minecraft:white_concrete
fill 451 238 558 456 238 558 minecraft:white_concrete
setblock 454 238 557 minecraft:yellow_concrete
fill 455 238 557 464 238 557 minecraft:orange_concrete
fill 456 238 598 461 238 598 minecraft:white_concrete
fill 459 238 558 464 238 558 minecraft:white_concrete
fill 463 238 560 463 238 596 minecraft:white_concrete
fill 464 238 561 464 238 566 minecraft:white_concrete
fill 464 238 569 464 238 574 minecraft:white_concrete
fill 464 238 577 464 238 582 minecraft:white_concrete
fill 464 238 585 464 238 590 minecraft:white_concrete
fill 464 238 593 464 238 596 minecraft:white_concrete
setblock 464 238 598 minecraft:white_concrete
setblock 465 238 557 minecraft:yellow_concrete
fill 465 238 560 465 238 563 minecraft:orange_concrete
fill 465 238 564 465 239 564 minecraft:yellow_concrete
fill 465 238 565 465 272 565 minecraft:orange_concrete
fill 465 238 567 465 273 567 minecraft:orange_concrete
setblock 465 238 568 minecraft:yellow_concrete
fill 465 238 569 465 238 578 minecraft:orange_concrete
setblock 465 238 579 minecraft:yellow_concrete
fill 465 238 580 465 238 586 minecraft:orange_concrete
fill 465 238 596 465 268 596 minecraft:orange_concrete
setblock 465 238 599 minecraft:yellow_concrete
setblock 423 239 557 minecraft:yellow_concrete
fill 423 239 558 423 272 559 minecraft:orange_concrete
fill 423 239 562 423 255 562 minecraft:orange_concrete
fill 423 239 564 423 272 564 minecraft:orange_concrete
fill 423 239 574 423 272 574 minecraft:orange_concrete
fill 423 239 577 423 269 577 minecraft:orange_concrete
fill 423 239 582 423 255 587 minecraft:orange_concrete
setblock 423 239 588 minecraft:yellow_concrete
fill 423 239 589 423 255 599 minecraft:orange_concrete
fill 424 239 557 427 269 557 minecraft:orange_concrete
fill 424 239 599 425 270 599 minecraft:orange_concrete
setblock 426 239 599 minecraft:yellow_concrete
fill 427 239 599 432 272 599 minecraft:orange_concrete
setblock 428 239 557 minecraft:yellow_concrete
fill 431 239 557 437 268 557 minecraft:orange_concrete
setblock 433 239 599 minecraft:yellow_concrete
fill 434 239 599 438 255 599 minecraft:orange_concrete
setblock 438 239 557 minecraft:yellow_concrete
fill 439 239 557 446 255 557 minecraft:orange_concrete
setblock 439 239 599 minecraft:yellow_concrete
fill 442 239 599 457 255 599 minecraft:orange_concrete
setblock 447 239 557 minecraft:yellow_concrete
fill 448 239 557 458 255 557 minecraft:orange_concrete
setblock 458 239 599 minecraft:yellow_concrete
setblock 459 239 557 minecraft:yellow_concrete
fill 459 239 599 461 272 599 minecraft:orange_concrete
fill 460 239 557 461 272 557 minecraft:orange_concrete
setblock 462 239 557 minecraft:yellow_concrete
setblock 462 239 599 minecraft:yellow_concrete
fill 463 239 557 465 269 557 minecraft:orange_concrete
fill 463 239 599 465 268 599 minecraft:orange_concrete
fill 465 239 560 465 270 561 minecraft:orange_concrete
setblock 465 239 562 minecraft:yellow_concrete
fill 465 239 563 465 272 563 minecraft:orange_concrete
fill 465 239 566 465 268 566 minecraft:orange_concrete
fill 465 239 568 465 255 575 minecraft:orange_concrete
setblock 465 239 576 minecraft:yellow_concrete
fill 465 239 577 465 255 580 minecraft:orange_concrete
setblock 465 239 581 minecraft:yellow_concrete
fill 465 239 582 465 255 586 minecraft:orange_concrete
setblock 465 239 597 minecraft:yellow_concrete
fill 465 239 598 465 272 598 minecraft:orange_concrete
fill 423 240 557 423 268 557 minecraft:orange_concrete
fill 423 240 566 423 272 566 minecraft:orange_concrete
fill 423 240 588 423 272 588 minecraft:orange_concrete
fill 426 240 599 426 255 599 minecraft:orange_concrete
fill 428 240 557 428 272 557 minecraft:orange_concrete
fill 430 240 557 430 255 557 minecraft:orange_concrete
fill 433 240 599 433 272 599 minecraft:orange_concrete
fill 438 240 557 438 255 557 minecraft:orange_concrete
fill 439 240 599 439 268 599 minecraft:orange_concrete
fill 447 240 557 447 269 557 minecraft:orange_concrete
fill 458 240 599 458 255 599 minecraft:orange_concrete
fill 459 240 557 459 268 557 minecraft:orange_concrete
fill 462 240 557 462 255 557 minecraft:orange_concrete
fill 462 240 599 462 268 599 minecraft:orange_concrete
fill 465 240 562 465 255 562 minecraft:orange_concrete
fill 465 240 564 465 272 564 minecraft:orange_concrete
fill 465 240 576 465 272 576 minecraft:orange_concrete
fill 465 240 581 465 272 581 minecraft:orange_concrete
fill 465 240 597 465 272 597 minecraft:orange_concrete
setblock 426 243 560 minecraft:light[level=14]
setblock 426 243 568 minecraft:light[level=14]
setblock 426 243 576 minecraft:light[level=14]
setblock 426 243 584 minecraft:light[level=14]
setblock 426 243 592 minecraft:light[level=14]
setblock 434 243 560 minecraft:light[level=14]
setblock 434 243 568 minecraft:light[level=14]
setblock 434 243 576 minecraft:light[level=14]
setblock 434 243 584 minecraft:light[level=14]
setblock 434 243 592 minecraft:light[level=14]
fill 439 243 582 441 243 584 minecraft:redstone_block
setblock 442 243 560 minecraft:light[level=14]
setblock 442 243 568 minecraft:light[level=14]
fill 442 243 573 444 243 575 minecraft:redstone_block
setblock 442 243 576 minecraft:light[level=14]
setblock 442 243 584 minecraft:light[level=14]
setblock 442 243 592 minecraft:light[level=14]
fill 445 243 582 447 243 584 minecraft:redstone_block
setblock 450 243 560 minecraft:light[level=14]
setblock 450 243 568 minecraft:light[level=14]
setblock 450 243 576 minecraft:light[level=14]
setblock 450 243 584 minecraft:light[level=14]
setblock 450 243 592 minecraft:light[level=14]
setblock 458 243 560 minecraft:light[level=14]
setblock 458 243 568 minecraft:light[level=14]
setblock 458 243 576 minecraft:light[level=14]
setblock 458 243 584 minecraft:light[level=14]
setblock 458 243 592 minecraft:light[level=14]
fill 427 244 579 432 245 579 minecraft:yellow_concrete
fill 428 244 574 428 245 576 minecraft:purple_concrete
fill 428 244 577 433 245 578 minecraft:yellow_concrete
fill 428 244 580 428 245 584 minecraft:yellow_concrete
fill 429 244 572 429 245 575 minecraft:purple_concrete
fill 429 244 576 441 244 576 minecraft:yellow_concrete
fill 429 244 580 429 245 583 minecraft:yellow_concrete
fill 429 244 584 431 245 586 minecraft:purple_concrete
fill 430 244 570 430 245 571 minecraft:yellow_concrete
fill 430 244 572 431 245 574 minecraft:purple_concrete
fill 430 244 575 440 245 575 minecraft:yellow_concrete
fill 430 244 580 430 245 581 minecraft:yellow_concrete
fill 430 244 582 432 245 583 minecraft:purple_concrete
fill 430 244 587 431 245 588 minecraft:purple_concrete
fill 431 244 569 442 245 570 minecraft:yellow_concrete
fill 431 244 571 437 245 571 minecraft:purple_concrete
fill 431 244 580 431 245 580 minecraft:yellow_concrete
fill 431 244 581 434 245 581 minecraft:purple_concrete
fill 431 244 589 431 245 589 minecraft:purple_concrete
fill 432 244 568 441 245 568 minecraft:yellow_concrete
fill 432 244 572 439 245 573 minecraft:purple_concrete
fill 432 244 574 438 245 574 minecraft:yellow_concrete
fill 432 244 580 435 245 580 minecraft:purple_concrete
fill 432 244 584 432 245 584 minecraft:purple_concrete
fill 432 244 585 436 245 590 minecraft:yellow_concrete
fill 433 244 567 439 245 567 minecraft:yellow_concrete
fill 433 244 579 436 245 579 minecraft:purple_concrete
fill 433 244 582 433 245 582 minecraft:purple_concrete
fill 433 244 583 436 245 584 minecraft:yellow_concrete
fill 433 244 591 436 245 591 minecraft:yellow_concrete
fill 434 244 566 437 245 566 minecraft:yellow_concrete
fill 434 244 577 436 245 577 minecraft:yellow_concrete
fill 434 244 578 439 245 578 minecraft:purple_concrete
fill 434 244 582 437 245 582 minecraft:yellow_concrete
fill 434 244 592 437 245 592 minecraft:yellow_concrete
fill 435 244 581 438 244 581 minecraft:yellow_concrete
fill 436 244 565 442 245 565 minecraft:purple_concrete
fill 436 244 580 439 245 580 minecraft:yellow_concrete
fill 436 244 593 437 245 593 minecraft:yellow_concrete
fill 437 244 577 439 245 577 minecraft:purple_concrete
fill 437 244 579 439 245 579 minecraft:yellow_concrete
fill 437 244 583 437 245 583 minecraft:yellow_concrete
fill 437 244 584 438 244 591 minecraft:purple_concrete
fill 438 244 564 441 245 564 minecraft:purple_concrete
fill 438 244 566 443 245 566 minecraft:purple_concrete
fill 438 244 571 443 245 571 minecraft:yellow_concrete
fill 438 244 582 438 244 583 minecraft:purple_concrete
fill 438 244 592 441 245 593 minecraft:purple_concrete
fill 438 244 594 438 245 594 minecraft:yellow_concrete
fill 439 244 574 441 244 574 minecraft:purple_concrete
fill 439 244 581 440 244 581 minecraft:purple_concrete
fill 439 244 585 442 244 587 minecraft:yellow_concrete
fill 439 244 588 439 245 591 minecraft:purple_concrete
fill 439 244 594 443 245 594 minecraft:purple_concrete
fill 440 244 567 444 245 567 minecraft:purple_concrete
fill 440 244 572 444 244 572 minecraft:yellow_concrete
fill 440 244 573 440 245 573 minecraft:purple_concrete
fill 440 244 577 440 245 577 minecraft:yellow_concrete
fill 440 244 578 441 244 580 minecraft:white_concrete
fill 440 244 588 443 245 590 minecraft:yellow_concrete
fill 440 244 591 440 245 591 minecraft:purple_concrete
setblock 441 244 573 minecraft:yellow_concrete
setblock 441 244 575 minecraft:purple_concrete
fill 441 244 577 445 244 577 minecraft:white_concrete
fill 441 244 581 445 244 581 minecraft:white_concrete
fill 441 244 591 448 245 591 minecraft:yellow_concrete
fill 442 244 564 448 245 564 minecraft:yellow_concrete
fill 442 244 568 445 245 568 minecraft:purple_concrete
fill 442 244 576 444 244 576 minecraft:white_concrete
fill 442 244 582 444 244 582 minecraft:white_concrete
fill 442 244 583 443 244 584 minecraft:purple_concrete
fill 442 244 592 452 245 592 minecraft:yellow_concrete
fill 442 244 593 442 245 593 minecraft:purple_concrete
fill 443 244 563 443 245 563 minecraft:yellow_concrete
fill 443 244 565 449 245 565 minecraft:yellow_concrete
fill 443 244 569 445 245 569 minecraft:purple_concrete
fill 443 244 570 443 245 570 minecraft:yellow_concrete
fill 443 244 585 444 244 586 minecraft:purple_concrete
fill 443 244 587 443 245 587 minecraft:yellow_concrete
fill 443 244 593 450 245 593 minecraft:yellow_concrete
fill 443 244 595 443 245 595 minecraft:purple_concrete
fill 444 244 566 449 245 566 minecraft:yellow_concrete
fill 444 244 570 446 245 571 minecraft:purple_concrete
fill 444 244 583 444 244 584 minecraft:yellow_concrete
fill 444 244 587 446 245 588 minecraft:purple_concrete
fill 444 244 589 444 245 590 minecraft:yellow_concrete
fill 444 244 594 448 245 594 minecraft:yellow_concrete
fill 445 244 567 450 245 567 minecraft:yellow_concrete
fill 445 244 572 445 244 576 minecraft:purple_concrete
fill 445 244 578 446 244 580 minecraft:white_concrete
fill 445 244 585 457 244 585 minecraft:yellow_concrete
fill 445 244 586 445 245 586 minecraft:purple_concrete
fill 445 244 589 455 245 589 minecraft:purple_concrete
fill 445 244 590 446 245 590 minecraft:yellow_concrete
fill 446 244 568 450 245 569 minecraft:yellow_concrete
fill 446 244 572 446 245 575 minecraft:purple_concrete
fill 446 244 576 448 245 577 minecraft:yellow_concrete
fill 446 244 581 452 244 581 minecraft:yellow_concrete
fill 446 244 586 457 245 586 minecraft:yellow_concrete
fill 447 244 570 449 245 575 minecraft:yellow_concrete
fill 447 244 578 448 245 579 minecraft:purple_concrete
fill 447 244 580 453 245 580 minecraft:yellow_concrete
fill 447 244 587 456 245 587 minecraft:yellow_concrete
fill 447 244 588 448 245 588 minecraft:purple_concrete
fill 447 244 590 454 245 590 minecraft:purple_concrete
fill 448 244 582 454 244 583 minecraft:purple_concrete
fill 448 244 584 458 244 584 minecraft:yellow_concrete
fill 449 244 576 449 245 578 minecraft:purple_concrete
fill 449 244 579 455 245 579 minecraft:yellow_concrete
fill 449 244 588 455 245 588 minecraft:yellow_concrete
fill 449 244 591 453 245 591 minecraft:purple_concrete
fill 450 244 565 450 245 566 minecraft:purple_concrete
fill 450 244 570 450 245 573 minecraft:yellow_concrete
fill 450 244 574 450 245 577 minecraft:purple_concrete
fill 450 244 578 456 245 578 minecraft:yellow_concrete
fill 451 244 566 451 245 576 minecraft:purple_concrete
fill 451 244 577 456 245 577 minecraft:yellow_concrete
fill 452 244 566 452 245 575 minecraft:purple_concrete
fill 452 244 576 457 245 576 minecraft:yellow_concrete
fill 453 244 567 453 245 573 minecraft:purple_concrete
fill 453 244 574 457 245 575 minecraft:yellow_concrete
fill 453 244 581 457 245 581 minecraft:purple_concrete
fill 454 244 568 454 245 573 minecraft:yellow_concrete
fill 454 244 580 458 245 580 minecraft:purple_concrete
fill 455 244 569 455 245 573 minecraft:yellow_concrete
fill 455 244 582 456 245 582 minecraft:purple_concrete
fill 455 244 583 458 245 583 minecraft:yellow_concrete
fill 456 244 570 456 245 573 minecraft:yellow_concrete
fill 456 244 579 459 245 579 minecraft:purple_concrete
fill 456 244 588 456 245 588 minecraft:purple_concrete
fill 457 244 572 457 245 573 minecraft:yellow_concrete
fill 457 244 577 458 245 578 minecraft:purple_concrete
fill 457 244 582 458 245 582 minecraft:yellow_concrete
fill 458 244 574 458 245 574 minecraft:yellow_concrete
fill 458 244 575 458 245 576 minecraft:purple_concrete
fill 458 244 581 458 245 581 minecraft:yellow_concrete
fill 424 245 558 426 245 598 minecraft:white_concrete
fill 427 245 558 427 245 578 minecraft:white_concrete
fill 427 245 580 427 245 598 minecraft:white_concrete
fill 428 245 558 428 245 573 minecraft:white_concrete
fill 428 245 585 428 245 598 minecraft:white_concrete
fill 429 245 558 429 245 571 minecraft:white_concrete
fill 429 245 576 440 245 576 minecraft:yellow_concrete
fill 429 245 587 429 245 598 minecraft:white_concrete
fill 430 245 558 430 245 569 minecraft:white_concrete
fill 430 245 589 430 245 598 minecraft:white_concrete
fill 431 245 558 431 245 568 minecraft:white_concrete
fill 431 245 590 431 245 598 minecraft:white_concrete
fill 432 245 558 432 245 567 minecraft:white_concrete
fill 432 245 591 432 245 598 minecraft:white_concrete
fill 433 245 558 433 245 566 minecraft:white_concrete
fill 433 245 592 433 245 598 minecraft:white_concrete
fill 434 245 558 435 245 565 minecraft:white_concrete
fill 434 245 593 435 245 598 minecraft:white_concrete
fill 435 245 581 437 245 581 minecraft:yellow_concrete
fill 436 245 558 437 245 564 minecraft:white_concrete
fill 436 245 594 437 245 598 minecraft:white_concrete
fill 437 245 584 437 245 591 minecraft:purple_concrete
fill 438 245 558 442 245 563 minecraft:white_concrete
fill 438 245 581 438 245 585 minecraft:sea_lantern
fill 438 245 586 438 245 591 minecraft:purple_concrete
fill 438 245 595 442 245 598 minecraft:white_concrete
fill 439 245 574 440 245 574 minecraft:purple_concrete
fill 439 245 581 448 245 581 minecraft:sea_lantern
fill 439 245 582 441 245 584 minecraft:white_concrete
fill 439 245 585 442 245 585 minecraft:sea_lantern
fill 439 245 586 442 245 587 minecraft:yellow_concrete
setblock 440 245 572 minecraft:yellow_concrete
fill 440 245 578 440 245 580 minecraft:white_concrete
fill 441 245 572 441 245 580 minecraft:sea_lantern
fill 442 245 572 445 245 572 minecraft:sea_lantern
fill 442 245 573 444 245 575 minecraft:white_concrete
fill 442 245 576 445 245 577 minecraft:sea_lantern
fill 442 245 582 442 245 584 minecraft:sea_lantern
fill 443 245 558 464 245 562 minecraft:white_concrete
setblock 443 245 582 minecraft:white_concrete
fill 443 245 583 443 245 586 minecraft:purple_concrete
fill 443 245 596 464 245 598 minecraft:white_concrete
fill 444 245 563 464 245 563 minecraft:white_concrete
fill 444 245 582 444 245 585 minecraft:sea_lantern
setblock 444 245 586 minecraft:purple_concrete
fill 444 245 595 464 245 595 minecraft:white_concrete
fill 445 245 573 445 245 575 minecraft:sea_lantern
fill 445 245 578 445 245 580 minecraft:sea_lantern
fill 445 245 582 447 245 584 minecraft:white_concrete
fill 445 245 585 448 245 585 minecraft:sea_lantern
fill 446 245 578 446 245 580 minecraft:white_concrete
fill 448 245 582 448 245 584 minecraft:sea_lantern
fill 449 245 564 464 245 564 minecraft:white_concrete
fill 449 245 581 452 245 581 minecraft:yellow_concrete
fill 449 245 582 454 245 583 minecraft:purple_concrete
fill 449 245 584 457 245 585 minecraft:yellow_concrete
fill 449 245 594 464 245 594 minecraft:white_concrete
fill 451 245 565 464 245 565 minecraft:white_concrete
fill 451 245 593 464 245 593 minecraft:white_concrete
fill 453 245 566 464 245 566 minecraft:white_concrete
fill 453 245 592 464 245 592 minecraft:white_concrete
fill 454 245 567 464 245 567 minecraft:white_concrete
fill 454 245 591 464 245 591 minecraft:white_concrete
fill 455 245 568 464 245 568 minecraft:white_concrete
fill 455 245 590 464 245 590 minecraft:white_concrete
fill 456 245 569 464 245 569 minecraft:white_concrete
fill 456 245 589 464 245 589 minecraft:white_concrete
fill 457 245 570 464 245 571 minecraft:white_concrete
fill 457 245 587 464 245 588 minecraft:white_concrete
fill 458 245 572 464 245 573 minecraft:white_concrete
setblock 458 245 584 minecraft:yellow_concrete
fill 458 245 585 464 245 586 minecraft:white_concrete
fill 459 245 574 464 245 578 minecraft:white_concrete
fill 459 245 580 464 245 584 minecraft:white_concrete
fill 460 245 579 464 245 579 minecraft:white_concrete
fill 424 249 564 424 273 565 minecraft:white_concrete
fill 424 249 572 424 273 573 minecraft:white_concrete
fill 424 249 580 424 273 581 minecraft:white_concrete
fill 424 249 588 424 273 589 minecraft:white_concrete
fill 424 249 596 424 273 597 minecraft:white_concrete
fill 425 249 558 426 273 558 minecraft:white_concrete
fill 430 249 598 431 273 598 minecraft:white_concrete
fill 433 249 558 434 273 558 minecraft:white_concrete
fill 438 249 598 439 273 598 minecraft:white_concrete
fill 441 249 558 442 273 558 minecraft:white_concrete
fill 446 249 598 447 273 598 minecraft:white_concrete
fill 449 249 558 450 273 558 minecraft:white_concrete
fill 454 249 598 455 273 598 minecraft:white_concrete
fill 457 249 558 458 273 558 minecraft:white_concrete
fill 462 249 598 463 273 598 minecraft:white_concrete
fill 464 249 559 464 273 560 minecraft:white_concrete
fill 464 249 567 464 273 568 minecraft:white_concrete
fill 464 249 575 464 273 576 minecraft:white_concrete
fill 464 249 583 464 273 584 minecraft:white_concrete
fill 464 249 591 464 273 592 minecraft:white_concrete
setblock 426 251 560 minecraft:light[level=14]
setblock 426 251 568 minecraft:light[level=14]
setblock 426 251 576 minecraft:light[level=14]
setblock 426 251 584 minecraft:light[level=14]
setblock 426 251 592 minecraft:light[level=14]
setblock 434 251 560 minecraft:light[level=14]
setblock 434 251 568 minecraft:light[level=14]
setblock 434 251 576 minecraft:light[level=14]
setblock 434 251 584 minecraft:light[level=14]
setblock 434 251 592 minecraft:light[level=14]
setblock 442 251 560 minecraft:light[level=14]
setblock 442 251 568 minecraft:light[level=14]
setblock 442 251 576 minecraft:light[level=14]
setblock 442 251 584 minecraft:light[level=14]
setblock 442 251 592 minecraft:light[level=14]
setblock 450 251 560 minecraft:light[level=14]
setblock 450 251 568 minecraft:light[level=14]
setblock 450 251 576 minecraft:light[level=14]
setblock 450 251 584 minecraft:light[level=14]
setblock 450 251 592 minecraft:light[level=14]
setblock 458 251 560 minecraft:light[level=14]
setblock 458 251 568 minecraft:light[level=14]
setblock 458 251 576 minecraft:light[level=14]
setblock 458 251 584 minecraft:light[level=14]
setblock 458 251 592 minecraft:light[level=14]
fill 424 252 558 424 253 563 minecraft:white_concrete
fill 424 252 566 425 252 571 minecraft:white_concrete
fill 424 252 574 425 252 579 minecraft:white_concrete
fill 424 252 582 425 252 587 minecraft:white_concrete
fill 424 252 590 425 252 595 minecraft:white_concrete
fill 424 252 598 429 253 598 minecraft:white_concrete
fill 425 252 559 425 252 565 minecraft:white_concrete
fill 425 252 572 425 252 573 minecraft:white_concrete
fill 425 252 580 425 252 581 minecraft:white_concrete
fill 425 252 588 425 252 589 minecraft:white_concrete
fill 425 252 596 425 252 597 minecraft:white_concrete
fill 426 252 559 463 252 559 minecraft:white_concrete
fill 426 252 597 464 252 597 minecraft:white_concrete
fill 427 252 558 432 253 558 minecraft:white_concrete
fill 430 252 569 431 253 569 minecraft:orange_concrete
fill 432 252 598 437 253 598 minecraft:white_concrete
fill 435 252 558 440 253 558 minecraft:white_concrete
fill 440 252 598 445 253 598 minecraft:white_concrete
fill 443 252 558 448 253 558 minecraft:white_concrete
fill 448 252 598 453 253 598 minecraft:white_concrete
fill 451 252 558 456 253 558 minecraft:white_concrete
fill 456 252 598 461 253 598 minecraft:white_concrete
fill 459 252 558 464 253 558 minecraft:white_concrete
fill 463 252 560 463 252 596 minecraft:white_concrete
fill 464 252 561 464 253 566 minecraft:white_concrete
fill 464 252 569 464 253 574 minecraft:white_concrete
fill 464 252 577 464 253 582 minecraft:white_concrete
fill 464 252 585 464 253 590 minecraft:white_concrete
fill 464 252 593 464 253 596 minecraft:white_concrete
fill 464 252 598 464 253 598 minecraft:white_concrete
fill 424 253 566 424 253 571 minecraft:white_concrete
fill 424 253 574 424 253 579 minecraft:white_concrete
fill 424 253 582 424 253 587 minecraft:white_concrete
fill 424 253 590 424 253 595 minecraft:white_concrete
fill 432 253 565 433 254 566 minecraft:purple_concrete
fill 440 253 560 441 254 560 minecraft:yellow_concrete
setblock 464 253 597 minecraft:white_concrete
fill 434 254 573 435 255 573 minecraft:blue_concrete
fill 423 256 562 423 261 562 minecraft:sea_lantern
fill 423 256 567 423 272 569 minecraft:orange_concrete
fill 423 256 570 423 261 570 minecraft:sea_lantern
fill 423 256 571 423 272 573 minecraft:orange_concrete
fill 423 256 578 423 261 578 minecraft:sea_lantern
fill 423 256 582 423 268 585 minecraft:orange_concrete
fill 423 256 586 423 261 586 minecraft:sea_lantern
fill 423 256 587 423 272 587 minecraft:orange_concrete
fill 423 256 589 423 268 593 minecraft:orange_concrete
fill 423 256 594 423 261 594 minecraft:sea_lantern
fill 423 256 595 423 269 599 minecraft:orange_concrete
fill 426 256 599 426 261 599 minecraft:sea_lantern
fill 430 256 557 430 261 557 minecraft:sea_lantern
fill 434 256 599 434 261 599 minecraft:sea_lantern
fill 435 256 599 438 269 599 minecraft:orange_concrete
fill 438 256 557 438 261 557 minecraft:sea_lantern
fill 439 256 557 445 268 557 minecraft:orange_concrete
fill 442 256 599 442 261 599 minecraft:sea_lantern
fill 443 256 599 449 272 599 minecraft:orange_concrete
fill 446 256 557 446 261 557 minecraft:sea_lantern
fill 448 256 557 453 268 557 minecraft:orange_concrete
fill 450 256 599 450 261 599 minecraft:sea_lantern
fill 451 256 599 457 272 599 minecraft:orange_concrete
fill 454 256 557 454 261 557 minecraft:sea_lantern
fill 455 256 557 458 270 557 minecraft:orange_concrete
fill 458 256 599 458 261 599 minecraft:sea_lantern
fill 462 256 557 462 261 557 minecraft:sea_lantern
fill 465 256 562 465 261 562 minecraft:sea_lantern
fill 465 256 568 465 272 569 minecraft:orange_concrete
fill 465 256 570 465 261 570 minecraft:sea_lantern
fill 465 256 571 465 269 575 minecraft:orange_concrete
fill 465 256 577 465 269 577 minecraft:orange_concrete
fill 465 256 578 465 261 578 minecraft:sea_lantern
fill 465 256 579 465 268 580 minecraft:orange_concrete
fill 465 256 582 465 268 585 minecraft:orange_concrete
fill 465 256 586 465 261 586 minecraft:sea_lantern
fill 465 256 587 465 268 593 minecraft:orange_concrete
fill 465 256 594 465 261 594 minecraft:sea_lantern
fill 465 256 595 465 268 595 minecraft:orange_concrete
fill 431 257 582 431 258 582 minecraft:lime_concrete
fill 444 258 561 446 259 561 minecraft:blue_concrete
fill 445 258 560 445 259 560 minecraft:blue_concrete
fill 445 258 562 445 259 562 minecraft:blue_concrete
fill 448 258 563 449 259 564 minecraft:red_concrete
setblock 426 259 560 minecraft:light[level=14]
setblock 426 259 568 minecraft:light[level=14]
setblock 426 259 576 minecraft:light[level=14]
setblock 426 259 584 minecraft:light[level=14]
setblock 426 259 592 minecraft:light[level=14]
setblock 434 259 560 minecraft:light[level=14]
setblock 434 259 568 minecraft:light[level=14]
setblock 434 259 576 minecraft:light[level=14]
setblock 434 259 584 minecraft:light[level=14]
setblock 434 259 592 minecraft:light[level=14]
setblock 442 259 560 minecraft:light[level=14]
setblock 442 259 568 minecraft:light[level=14]
setblock 442 259 576 minecraft:light[level=14]
setblock 442 259 584 minecraft:light[level=14]
setblock 442 259 592 minecraft:light[level=14]
setblock 450 259 560 minecraft:light[level=14]
setblock 450 259 568 minecraft:light[level=14]
setblock 450 259 576 minecraft:light[level=14]
setblock 450 259 584 minecraft:light[level=14]
setblock 450 259 592 minecraft:light[level=14]
setblock 458 259 560 minecraft:light[level=14]
setblock 458 259 568 minecraft:light[level=14]
setblock 458 259 576 minecraft:light[level=14]
setblock 458 259 584 minecraft:light[level=14]
setblock 458 259 592 minecraft:light[level=14]
fill 423 262 562 423 269 562 minecraft:orange_concrete
fill 423 262 570 423 269 570 minecraft:orange_concrete
fill 423 262 578 423 269 578 minecraft:orange_concrete
fill 423 262 586 423 269 586 minecraft:orange_concrete
fill 423 262 594 423 269 594 minecraft:orange_concrete
fill 426 262 599 426 269 599 minecraft:orange_concrete
fill 430 262 557 430 269 557 minecraft:orange_concrete
fill 434 262 599 434 269 599 minecraft:orange_concrete
fill 438 262 557 438 269 557 minecraft:orange_concrete
fill 442 262 599 442 269 599 minecraft:orange_concrete
fill 446 262 557 446 269 557 minecraft:orange_concrete
fill 450 262 599 450 269 599 minecraft:orange_concrete
fill 454 262 557 454 269 557 minecraft:orange_concrete
fill 458 262 599 458 269 599 minecraft:orange_concrete
fill 462 262 557 462 269 557 minecraft:orange_concrete
fill 465 262 562 465 268 562 minecraft:orange_concrete
fill 465 262 570 465 269 570 minecraft:orange_concrete
fill 465 262 578 465 269 578 minecraft:orange_concrete
fill 465 262 586 465 269 586 minecraft:orange_concrete
fill 465 262 594 465 269 594 minecraft:orange_concrete
fill 431 265 584 432 266 585 minecraft:yellow_concrete
fill 459 265 584 460 266 585 minecraft:purple_concrete
fill 461 265 586 463 265 586 minecraft:iron_block
fill 424 266 558 424 267 563 minecraft:white_concrete
fill 424 266 566 425 266 571 minecraft:white_concrete
fill 424 266 574 425 266 579 minecraft:white_concrete
fill 424 266 582 425 266 587 minecraft:white_concrete
fill 424 266 590 425 266 595 minecraft:white_concrete
fill 424 266 598 429 267 598 minecraft:white_concrete
fill 425 266 559 425 266 565 minecraft:white_concrete
fill 425 266 572 425 266 573 minecraft:white_concrete
fill 425 266 580 425 266 581 minecraft:white_concrete
fill 425 266 588 425 266 589 minecraft:white_concrete
fill 425 266 596 425 266 597 minecraft:white_concrete
fill 426 266 559 463 266 559 minecraft:white_concrete
fill 426 266 597 464 266 597 minecraft:white_concrete
fill 427 266 558 432 267 558 minecraft:white_concrete
fill 432 266 598 437 267 598 minecraft:white_concrete
fill 435 266 558 440 267 558 minecraft:white_concrete
fill 440 266 598 445 267 598 minecraft:white_concrete
fill 443 266 558 448 267 558 minecraft:white_concrete
fill 448 266 598 453 267 598 minecraft:white_concrete
fill 451 266 558 456 267 558 minecraft:white_concrete
fill 456 266 598 461 267 598 minecraft:white_concrete
fill 459 266 558 464 267 558 minecraft:white_concrete
fill 459 266 572 460 267 572 minecraft:purple_concrete
fill 461 266 586 462 266 586 minecraft:iron_block
fill 463 266 560 463 266 596 minecraft:white_concrete
fill 464 266 561 464 267 566 minecraft:white_concrete
fill 464 266 569 464 267 574 minecraft:white_concrete
fill 464 266 577 464 267 582 minecraft:white_concrete
fill 464 266 585 464 267 590 minecraft:white_concrete
fill 464 266 593 464 267 596 minecraft:white_concrete
fill 464 266 598 464 267 598 minecraft:white_concrete
fill 424 267 566 424 267 571 minecraft:white_concrete
fill 424 267 574 424 267 579 minecraft:white_concrete
fill 424 267 582 424 267 587 minecraft:white_concrete
fill 424 267 590 424 267 595 minecraft:white_concrete
setblock 426 267 560 minecraft:light[level=14]
setblock 426 267 568 minecraft:light[level=14]
setblock 426 267 576 minecraft:light[level=14]
setblock 426 267 584 minecraft:light[level=14]
setblock 426 267 592 minecraft:light[level=14]
setblock 434 267 560 minecraft:light[level=14]
setblock 434 267 568 minecraft:light[level=14]
setblock 434 267 576 minecraft:light[level=14]
setblock 434 267 584 minecraft:light[level=14]
setblock 434 267 592 minecraft:light[level=14]
setblock 442 267 560 minecraft:light[level=14]
setblock 442 267 568 minecraft:light[level=14]
setblock 442 267 576 minecraft:light[level=14]
setblock 442 267 584 minecraft:light[level=14]
setblock 442 267 592 minecraft:light[level=14]
setblock 450 267 560 minecraft:light[level=14]
setblock 450 267 568 minecraft:light[level=14]
setblock 450 267 576 minecraft:light[level=14]
setblock 450 267 584 minecraft:light[level=14]
setblock 450 267 592 minecraft:light[level=14]
setblock 458 267 560 minecraft:light[level=14]
setblock 458 267 568 minecraft:light[level=14]
setblock 458 267 576 minecraft:light[level=14]
setblock 458 267 584 minecraft:light[level=14]
setblock 458 267 592 minecraft:light[level=14]
setblock 464 267 597 minecraft:white_concrete
setblock 423 269 557 minecraft:red_concrete
fill 423 269 582 423 272 583 minecraft:orange_concrete
setblock 423 269 584 minecraft:red_concrete
fill 423 269 585 423 272 585 minecraft:orange_concrete
fill 423 269 589 423 272 592 minecraft:orange_concrete
setblock 423 269 593 minecraft:red_concrete
fill 431 269 557 431 272 557 minecraft:orange_concrete
fill 432 269 557 432 270 557 minecraft:red_concrete
fill 433 269 557 433 272 557 minecraft:orange_concrete
setblock 434 269 557 minecraft:red_concrete
fill 435 269 557 437 270 557 minecraft:orange_concrete
fill 439 269 557 439 272 557 minecraft:orange_concrete
setblock 439 269 599 minecraft:red_concrete
setblock 440 269 557 minecraft:red_concrete
fill 441 269 557 445 270 557 minecraft:orange_concrete
fill 448 269 557 450 270 557 minecraft:orange_concrete
fill 451 269 557 452 269 557 minecraft:red_concrete
fill 453 269 557 453 272 557 minecraft:orange_concrete
setblock 459 269 557 minecraft:red_concrete
setblock 462 269 599 minecraft:red_concrete
setblock 463 269 599 minecraft:orange_concrete
setblock 464 269 599 minecraft:red_concrete
setblock 465 269 562 minecraft:red_concrete
setblock 465 269 566 minecraft:red_concrete
fill 465 269 579 465 272 579 minecraft:orange_concrete
setblock 465 269 580 minecraft:red_concrete
setblock 465 269 582 minecraft:red_concrete
fill 465 269 583 465 272 585 minecraft:orange_concrete
setblock 465 269 587 minecraft:orange_concrete
fill 465 269 588 465 269 589 minecraft:red_concrete
fill 465 269 590 465 272 593 minecraft:orange_concrete
fill 465 269 595 465 269 596 minecraft:red_concrete
fill 465 269 599 465 273 599 minecraft:orange_concrete
fill 423 270 557 426 272 557 minecraft:orange_concrete
fill 423 270 562 423 273 562 minecraft:sea_lantern
fill 423 270 570 423 273 570 minecraft:sea_lantern
setblock 423 270 577 minecraft:red_concrete
fill 423 270 578 423 273 578 minecraft:sea_lantern
setblock 423 270 581 minecraft:red_concrete
fill 423 270 584 423 272 584 minecraft:orange_concrete
fill 423 270 586 423 273 586 minecraft:sea_lantern
fill 423 270 593 423 272 593 minecraft:orange_concrete
fill 423 270 594 423 273 594 minecraft:sea_lantern
fill 423 270 595 423 270 597 minecraft:orange_concrete
setblock 423 270 598 minecraft:red_concrete
setblock 423 270 599 minecraft:orange_concrete
fill 426 270 599 426 273 599 minecraft:sea_lantern
setblock 427 270 557 minecraft:red_concrete
fill 430 270 557 430 273 557 minecraft:sea_lantern
setblock 434 270 557 minecraft:orange_concrete
fill 434 270 599 434 273 599 minecraft:sea_lantern
setblock 435 270 599 minecraft:red_concrete
fill 436 270 599 439 272 599 minecraft:orange_concrete
fill 438 270 557 438 273 557 minecraft:sea_lantern
fill 440 270 557 440 272 557 minecraft:orange_concrete
fill 442 270 599 442 273 599 minecraft:sea_lantern
fill 446 270 557 446 273 557 minecraft:sea_lantern
setblock 447 270 557 minecraft:red_concrete
fill 450 270 599 450 273 599 minecraft:sea_lantern
fill 451 270 557 451 271 557 minecraft:red_concrete
setblock 452 270 557 minecraft:orange_concrete
fill 454 270 557 454 273 557 minecraft:sea_lantern
fill 458 270 599 458 273 599 minecraft:sea_lantern
fill 459 270 557 459 272 557 minecraft:orange_concrete
fill 462 270 557 462 273 557 minecraft:sea_lantern
setblock 462 270 599 minecraft:orange_concrete
fill 463 270 557 464 272 557 minecraft:orange_concrete
setblock 463 270 599 minecraft:red_concrete
fill 464 270 599 464 273 599 minecraft:orange_concrete
setblock 465 270 557 minecraft:red_concrete
fill 465 270 562 465 273 562 minecraft:sea_lantern
fill 465 270 566 465 272 566 minecraft:orange_concrete
fill 465 270 570 465 273 570 minecraft:sea_lantern
setblock 465 270 571 minecraft:red_concrete
fill 465 270 572 465 272 575 minecraft:orange_concrete
setblock 465 270 577 minecraft:red_concrete
fill 465 270 578 465 273 578 minecraft:sea_lantern
fill 465 270 580 465 272 580 minecraft:orange_concrete
fill 465 270 582 465 272 582 minecraft:orange_concrete
fill 465 270 586 465 273 586 minecraft:sea_lantern
setblock 465 270 587 minecraft:red_concrete
fill 465 270 588 465 270 589 minecraft:orange_concrete
fill 465 270 594 465 273 594 minecraft:sea_lantern
fill 465 270 595 465 272 596 minecraft:orange_concrete
fill 423 271 560 423 272 560 minecraft:orange_concrete
setblock 423 271 561 minecraft:red_concrete
fill 423 271 577 423 272 577 minecraft:orange_concrete
fill 423 271 581 423 272 581 minecraft:orange_concrete
fill 423 271 595 423 272 596 minecraft:orange_concrete
setblock 423 271 597 minecraft:red_concrete
fill 423 271 598 423 272 598 minecraft:orange_concrete
setblock 423 271 599 minecraft:red_concrete
fill 424 271 599 424 272 599 minecraft:orange_concrete
setblock 425 271 599 minecraft:red_concrete
fill 427 271 557 427 272 557 minecraft:orange_concrete
fill 432 271 557 432 272 557 minecraft:orange_concrete
setblock 434 271 557 minecraft:red_concrete
fill 435 271 557 435 272 557 minecraft:orange_concrete
fill 435 271 599 435 273 599 minecraft:orange_concrete
setblock 436 271 557 minecraft:red_concrete
fill 437 271 557 437 272 557 minecraft:orange_concrete
setblock 440 271 599 minecraft:red_concrete
fill 441 271 557 443 272 557 minecraft:orange_concrete
fill 441 271 599 441 273 599 minecraft:orange_concrete
fill 444 271 557 445 271 557 minecraft:red_concrete
fill 447 271 557 448 272 557 minecraft:orange_concrete
setblock 449 271 557 minecraft:red_concrete
fill 450 271 557 450 272 557 minecraft:orange_concrete
setblock 452 271 557 minecraft:red_concrete
fill 455 271 557 456 272 557 minecraft:orange_concrete
setblock 457 271 557 minecraft:red_concrete
fill 458 271 557 458 272 557 minecraft:orange_concrete
setblock 462 271 599 minecraft:red_concrete
fill 463 271 599 463 272 599 minecraft:orange_concrete
fill 465 271 557 465 272 557 minecraft:orange_concrete
fill 465 271 560 465 272 560 minecraft:orange_concrete
setblock 465 271 561 minecraft:red_concrete
fill 465 271 571 465 272 571 minecraft:orange_concrete
fill 465 271 577 465 272 577 minecraft:orange_concrete
fill 465 271 587 465 272 588 minecraft:orange_concrete
setblock 465 271 589 minecraft:red_concrete
fill 423 272 561 423 273 561 minecraft:orange_concrete
fill 423 272 597 423 273 597 minecraft:orange_concrete
setblock 423 272 599 minecraft:orange_concrete
setblock 425 272 599 minecraft:orange_concrete
setblock 434 272 557 minecraft:orange_concrete
setblock 436 272 557 minecraft:orange_concrete
fill 440 272 599 440 273 599 minecraft:orange_concrete
fill 444 272 557 445 272 557 minecraft:orange_concrete
setblock 449 272 557 minecraft:orange_concrete
fill 451 272 557 452 272 557 minecraft:orange_concrete
fill 457 272 557 457 273 557 minecraft:orange_concrete
setblock 462 272 599 minecraft:orange_concrete
setblock 465 272 561 minecraft:orange_concrete
setblock 465 272 589 minecraft:orange_concrete
fill 423 273 557 423 274 560 minecraft:red_concrete
fill 423 273 563 423 273 566 minecraft:red_concrete
setblock 423 273 567 minecraft:orange_concrete
fill 423 273 568 423 274 569 minecraft:red_concrete
fill 423 273 571 423 307 574 minecraft:red_concrete
setblock 423 273 575 minecraft:orange_concrete
fill 423 273 576 423 307 577 minecraft:red_concrete
fill 423 273 579 423 273 585 minecraft:red_concrete
fill 423 273 587 423 274 593 minecraft:red_concrete
setblock 423 273 595 minecraft:orange_concrete
fill 423 273 596 423 307 596 minecraft:red_concrete
fill 423 273 598 423 274 599 minecraft:red_concrete
setblock 424 273 557 minecraft:orange_concrete
fill 424 273 599 425 274 599 minecraft:red_concrete
fill 425 273 557 429 274 557 minecraft:red_concrete
fill 427 273 599 431 307 599 minecraft:red_concrete
fill 431 273 557 437 307 557 minecraft:red_concrete
setblock 432 273 599 minecraft:orange_concrete
fill 433 273 599 433 307 599 minecraft:red_concrete
fill 436 273 599 439 307 599 minecraft:red_concrete
fill 439 273 557 440 273 557 minecraft:red_concrete
setblock 441 273 557 minecraft:orange_concrete
fill 442 273 557 445 307 557 minecraft:red_concrete
fill 443 273 599 449 273 599 minecraft:red_concrete
fill 447 273 557 451 273 557 minecraft:red_concrete
fill 451 273 599 456 307 599 minecraft:red_concrete
setblock 452 273 557 minecraft:orange_concrete
fill 453 273 557 453 307 557 minecraft:red_concrete
fill 455 273 557 456 273 557 minecraft:red_concrete
setblock 457 273 599 minecraft:orange_concrete
fill 458 273 557 461 307 557 minecraft:red_concrete
fill 459 273 599 463 274 599 minecraft:red_concrete
fill 463 273 557 465 274 557 minecraft:red_concrete
fill 465 273 558 465 307 561 minecraft:red_concrete
fill 465 273 563 465 273 566 minecraft:red_concrete
fill 465 273 568 465 307 569 minecraft:red_concrete
fill 465 273 571 465 307 571 minecraft:red_concrete
setblock 465 273 572 minecraft:orange_concrete
fill 465 273 573 465 274 577 minecraft:red_concrete
fill 465 273 579 465 273 583 minecraft:red_concrete
setblock 465 273 584 minecraft:orange_concrete
setblock 465 273 585 minecraft:red_concrete
fill 465 273 587 465 274 591 minecraft:red_concrete
setblock 465 273 592 minecraft:orange_concrete
setblock 465 273 593 minecraft:red_concrete
fill 465 273 595 465 307 595 minecraft:red_concrete
setblock 465 273 596 minecraft:orange_concrete
fill 465 273 597 465 274 598 minecraft:red_concrete
fill 423 274 561 423 274 563 minecraft:red_concrete
setblock 423 274 564 minecraft:orange_concrete
fill 423 274 565 423 307 565 minecraft:red_concrete
fill 423 274 566 423 275 566 minecraft:orange_concrete
fill 423 274 567 423 307 567 minecraft:red_concrete
fill 423 274 570 423 283 570 minecraft:red_concrete
fill 423 274 575 423 307 575 minecraft:red_concrete
fill 423 274 578 423 283 582 minecraft:red_concrete
setblock 423 274 583 minecraft:orange_concrete
fill 423 274 584 423 274 586 minecraft:red_concrete
fill 423 274 594 423 283 595 minecraft:red_concrete
fill 423 274 597 423 307 597 minecraft:red_concrete
fill 424 274 557 424 307 557 minecraft:red_concrete
fill 426 274 599 426 283 599 minecraft:red_concrete
setblock 430 274 557 minecraft:orange_concrete
fill 432 274 599 432 307 599 minecraft:red_concrete
fill 434 274 599 435 283 599 minecraft:red_concrete
fill 438 274 557 438 283 557 minecraft:red_concrete
setblock 439 274 557 minecraft:orange_concrete
fill 440 274 557 441 307 557 minecraft:red_concrete
fill 440 274 599 445 283 599 minecraft:red_concrete
fill 446 274 557 447 274 557 minecraft:red_concrete
setblock 446 274 599 minecraft:orange_concrete
fill 447 274 599 447 307 599 minecraft:red_concrete
setblock 448 274 557 minecraft:orange_concrete
setblock 448 274 599 minecraft:orange_concrete
fill 449 274 557 452 307 557 minecraft:red_concrete
fill 449 274 599 449 307 599 minecraft:red_concrete
setblock 450 274 599 minecraft:orange_concrete
fill 454 274 557 455 274 557 minecraft:red_concrete
setblock 456 274 557 minecraft:orange_concrete
fill 457 274 557 457 307 557 minecraft:red_concrete
fill 457 274 599 458 274 599 minecraft:red_concrete
fill 462 274 557 462 283 557 minecraft:red_concrete
fill 464 274 599 465 307 599 minecraft:red_concrete
fill 465 274 562 465 283 565 minecraft:red_concrete
setblock 465 274 566 minecraft:orange_concrete
fill 465 274 567 465 307 567 minecraft:red_concrete
fill 465 274 570 465 283 570 minecraft:red_concrete
fill 465 274 572 465 307 572 minecraft:red_concrete
fill 465 274 578 465 283 579 minecraft:red_concrete
setblock 465 274 580 minecraft:orange_concrete
fill 465 274 581 465 307 584 minecraft:red_concrete
fill 465 274 585 465 274 586 minecraft:orange_concrete
fill 465 274 592 465 307 592 minecraft:red_concrete
fill 465 274 593 465 274 594 minecraft:orange_concrete
fill 465 274 596 465 307 596 minecraft:red_concrete
setblock 423 275 557 minecraft:orange_concrete
fill 423 275 558 423 307 558 minecraft:red_concrete
setblock 423 275 559 minecraft:orange_concrete
fill 423 275 560 423 307 560 minecraft:red_concrete
setblock 423 275 561 minecraft:orange_concrete
fill 423 275 562 423 283 564 minecraft:red_concrete
setblock 423 275 568 minecraft:orange_concrete
fill 423 275 569 423 307 569 minecraft:red_concrete
fill 423 275 583 423 307 584 minecraft:red_concrete
setblock 423 275 585 minecraft:orange_concrete
fill 423 275 586 423 283 586 minecraft:red_concrete
fill 423 275 587 423 275 588 minecraft:orange_concrete
fill 423 275 589 423 307 590 minecraft:red_concrete
setblock 423 275 591 minecraft:orange_concrete
fill 423 275 592 423 307 593 minecraft:red_concrete
fill 423 275 598 423 307 598 minecraft:red_concrete
setblock 423 275 599 minecraft:orange_concrete
fill 424 275 599 424 307 599 minecraft:red_concrete
fill 425 275 557 426 307 557 minecraft:red_concrete
setblock 425 275 599 minecraft:orange_concrete
setblock 426 275 560 minecraft:light[level=14]
setblock 426 275 568 minecraft:light[level=14]
setblock 426 275 576 minecraft:light[level=14]
setblock 426 275 584 minecraft:light[level=14]
setblock 426 275 592 minecraft:light[level=14]
fill 427 275 557 428 275 557 minecraft:orange_concrete
fill 429 275 557 430 283 557 minecraft:red_concrete
setblock 434 275 560 minecraft:light[level=14]
setblock 434 275 568 minecraft:light[level=14]
setblock 434 275 576 minecraft:light[level=14]
setblock 434 275 584 minecraft:light[level=14]
setblock 434 275 592 minecraft:light[level=14]
fill 439 275 557 439 307 557 minecraft:red_concrete
setblock 442 275 560 minecraft:light[level=14]
setblock 442 275 568 minecraft:light[level=14]
setblock 442 275 576 minecraft:light[level=14]
setblock 442 275 584 minecraft:light[level=14]
setblock 442 275 592 minecraft:light[level=14]
fill 446 275 557 446 283 557 minecraft:red_concrete
fill 446 275 599 446 307 599 minecraft:red_concrete
setblock 447 275 557 minecraft:orange_concrete
fill 448 275 557 448 307 557 minecraft:red_concrete
fill 448 275 599 448 307 599 minecraft:red_concrete
setblock 450 275 560 minecraft:light[level=14]
setblock 450 275 568 minecraft:light[level=14]
setblock 450 275 576 minecraft:light[level=14]
setblock 450 275 584 minecraft:light[level=14]
setblock 450 275 592 minecraft:light[level=14]
fill 450 275 599 450 283 599 minecraft:red_concrete
fill 454 275 557 454 283 557 minecraft:red_concrete
setblock 455 275 557 minecraft:orange_concrete
fill 456 275 557 456 307 557 minecraft:red_concrete
fill 457 275 599 457 307 599 minecraft:red_concrete
setblock 458 275 560 minecraft:light[level=14]
setblock 458 275 568 minecraft:light[level=14]
setblock 458 275 576 minecraft:light[level=14]
setblock 458 275 584 minecraft:light[level=14]
setblock 458 275 592 minecraft:light[level=14]
setblock 458 275 599 minecraft:orange_concrete
fill 459 275 599 459 307 599 minecraft:red_concrete
setblock 460 275 599 minecraft:orange_concrete
fill 461 275 599 463 307 599 minecraft:red_concrete
fill 463 275 557 464 307 557 minecraft:red_concrete
setblock 465 275 557 minecraft:orange_concrete
fill 465 275 566 465 307 566 minecraft:red_concrete
fill 465 275 573 465 307 573 minecraft:red_concrete
setblock 465 275 574 minecraft:orange_concrete
fill 465 275 575 465 307 577 minecraft:red_concrete
fill 465 275 580 465 307 580 minecraft:red_concrete
fill 465 275 585 465 283 588 minecraft:red_concrete
setblock 465 275 589 minecraft:orange_concrete
fill 465 275 590 465 307 591 minecraft:red_concrete
fill 465 275 593 465 283 594 minecraft:red_concrete
setblock 465 275 597 minecraft:orange_concrete
fill 465 275 598 465 307 598 minecraft:red_concrete
fill 423 276 557 423 307 557 minecraft:red_concrete
fill 423 276 559 423 307 559 minecraft:red_concrete
fill 423 276 561 423 307 561 minecraft:red_concrete
fill 423 276 566 423 307 566 minecraft:red_concrete
fill 423 276 568 423 307 568 minecraft:red_concrete
fill 423 276 585 423 307 585 minecraft:red_concrete
fill 423 276 587 423 307 588 minecraft:red_concrete
fill 423 276 591 423 307 591 minecraft:red_concrete
fill 423 276 599 423 307 599 minecraft:red_concrete
fill 425 276 599 425 307 599 minecraft:red_concrete
fill 427 276 557 428 307 557 minecraft:red_concrete
fill 447 276 557 447 307 557 minecraft:red_concrete
fill 455 276 557 455 307 557 minecraft:red_concrete
fill 458 276 599 458 283 599 minecraft:red_concrete
fill 460 276 599 460 307 599 minecraft:red_concrete
fill 465 276 557 465 307 557 minecraft:red_concrete
fill 465 276 574 465 307 574 minecraft:red_concrete
fill 465 276 589 465 307 589 minecraft:red_concrete
fill 465 276 597 465 307 597 minecraft:red_concrete
fill 439 278 577 441 278 579 minecraft:redstone_block
fill 439 278 583 441 278 585 minecraft:redstone_block
fill 447 278 577 449 278 579 minecraft:redstone_block
fill 447 278 583 449 278 585 minecraft:redstone_block
fill 424 279 558 425 280 562 minecraft:blue_concrete
fill 424 279 563 425 279 568 minecraft:red_concrete
fill 424 279 569 425 279 574 minecraft:blue_concrete
fill 424 279 575 425 279 580 minecraft:red_concrete
fill 424 279 581 425 279 586 minecraft:blue_concrete
fill 424 279 587 425 279 592 minecraft:red_concrete
fill 424 279 593 425 279 598 minecraft:blue_concrete
fill 426 279 558 431 279 562 minecraft:red_concrete
fill 426 279 563 431 279 568 minecraft:blue_concrete
fill 426 279 569 431 279 574 minecraft:red_concrete
fill 426 279 575 431 279 580 minecraft:blue_concrete
fill 426 279 581 431 279 586 minecraft:red_concrete
fill 426 279 587 431 279 592 minecraft:blue_concrete
fill 426 279 593 431 279 598 minecraft:red_concrete
fill 432 279 558 437 279 562 minecraft:blue_concrete
fill 432 279 563 437 279 568 minecraft:red_concrete
fill 432 279 569 437 279 574 minecraft:blue_concrete
fill 432 279 575 437 279 580 minecraft:red_concrete
fill 432 279 581 437 279 586 minecraft:blue_concrete
fill 432 279 587 437 279 592 minecraft:red_concrete
fill 432 279 593 437 279 598 minecraft:blue_concrete
fill 438 279 558 443 279 562 minecraft:red_concrete
fill 438 279 563 443 279 568 minecraft:blue_concrete
fill 438 279 569 443 279 574 minecraft:red_concrete
fill 438 279 575 438 279 580 minecraft:blue_concrete
fill 438 279 581 438 279 586 minecraft:red_concrete
fill 438 279 587 443 279 592 minecraft:blue_concrete
fill 438 279 593 443 279 598 minecraft:red_concrete
fill 439 279 575 443 279 576 minecraft:blue_concrete
fill 439 279 580 442 279 580 minecraft:blue_concrete
fill 439 279 581 442 279 582 minecraft:red_concrete
fill 439 279 586 443 279 586 minecraft:red_concrete
fill 442 279 577 443 279 579 minecraft:blue_concrete
fill 442 279 583 443 279 585 minecraft:red_concrete
fill 444 279 558 449 279 562 minecraft:blue_concrete
fill 444 279 563 449 279 568 minecraft:red_concrete
fill 444 279 569 449 279 574 minecraft:blue_concrete
fill 444 279 575 446 279 579 minecraft:red_concrete
fill 444 279 583 446 279 586 minecraft:blue_concrete
fill 444 279 587 449 279 592 minecraft:red_concrete
fill 444 279 593 449 279 598 minecraft:blue_concrete
fill 446 279 580 449 279 580 minecraft:red_concrete
fill 446 279 581 449 279 582 minecraft:blue_concrete
fill 447 279 575 449 279 576 minecraft:red_concrete
fill 447 279 586 449 279 586 minecraft:blue_concrete
fill 450 279 558 455 279 562 minecraft:red_concrete
fill 450 279 563 455 279 568 minecraft:blue_concrete
fill 450 279 569 455 279 574 minecraft:red_concrete
fill 450 279 575 455 279 580 minecraft:blue_concrete
fill 450 279 581 455 279 586 minecraft:red_concrete
fill 450 279 587 455 279 592 minecraft:blue_concrete
fill 450 279 593 455 279 598 minecraft:red_concrete
fill 456 279 558 461 279 562 minecraft:blue_concrete
fill 456 279 563 461 279 568 minecraft:red_concrete
fill 456 279 569 461 279 574 minecraft:blue_concrete
fill 456 279 575 461 279 580 minecraft:red_concrete
fill 456 279 581 461 279 586 minecraft:blue_concrete
fill 456 279 587 461 279 592 minecraft:red_concrete
fill 456 279 593 461 279 598 minecraft:blue_concrete
fill 462 279 558 464 279 562 minecraft:red_concrete
fill 462 279 563 464 279 568 minecraft:blue_concrete
fill 462 279 569 464 279 574 minecraft:red_concrete
fill 462 279 575 464 279 580 minecraft:blue_concrete
fill 462 279 581 464 279 586 minecraft:red_concrete
fill 462 279 587 464 279 592 minecraft:blue_concrete
fill 462 279 593 464 279 598 minecraft:red_concrete
fill 424 280 563 464 280 563 minecraft:yellow_concrete
fill 424 280 564 425 280 568 minecraft:red_concrete
fill 424 280 569 464 280 569 minecraft:yellow_concrete
fill 424 280 570 425 280 574 minecraft:blue_concrete
fill 424 280 575 464 280 575 minecraft:yellow_concrete
fill 424 280 576 425 280 580 minecraft:red_concrete
fill 424 280 581 441 280 581 minecraft:yellow_concrete
fill 424 280 582 425 280 586 minecraft:blue_concrete
fill 424 280 587 464 280 587 minecraft:yellow_concrete
fill 424 280 588 425 280 592 minecraft:red_concrete
fill 424 280 593 464 280 593 minecraft:yellow_concrete
fill 424 280 594 425 280 598 minecraft:blue_concrete
fill 426 280 558 426 280 562 minecraft:yellow_concrete
fill 426 280 564 426 280 568 minecraft:yellow_concrete
fill 426 280 570 426 280 574 minecraft:yellow_concrete
fill 426 280 576 426 280 580 minecraft:yellow_concrete
fill 426 280 582 426 280 586 minecraft:yellow_concrete
fill 426 280 588 426 280 592 minecraft:yellow_concrete
fill 426 280 594 426 280 598 minecraft:yellow_concrete
fill 427 280 558 431 280 562 minecraft:red_concrete
fill 427 280 564 431 280 568 minecraft:blue_concrete
fill 427 280 570 431 280 574 minecraft:red_concrete
fill 427 280 576 431 280 580 minecraft:blue_concrete
fill 427 280 582 431 280 586 minecraft:red_concrete
fill 427 280 588 431 280 592 minecraft:blue_concrete
fill 427 280 594 431 280 598 minecraft:red_concrete
fill 432 280 558 432 280 562 minecraft:yellow_concrete
fill 432 280 564 432 280 568 minecraft:yellow_concrete
fill 432 280 570 432 280 574 minecraft:yellow_concrete
fill 432 280 576 432 280 580 minecraft:yellow_concrete
fill 432 280 582 432 280 586 minecraft:yellow_concrete
fill 432 280 588 432 280 592 minecraft:yellow_concrete
fill 432 280 594 432 280 598 minecraft:yellow_concrete
fill 433 280 558 437 280 562 minecraft:blue_concrete
fill 433 280 564 437 280 568 minecraft:red_concrete
fill 433 280 570 437 280 574 minecraft:blue_concrete
fill 433 280 576 437 280 580 minecraft:red_concrete
fill 433 280 582 437 280 586 minecraft:blue_concrete
fill 433 280 588 437 280 592 minecraft:red_concrete
fill 433 280 594 437 280 598 minecraft:blue_concrete
fill 438 280 558 438 280 562 minecraft:yellow_concrete
fill 438 280 564 438 280 568 minecraft:yellow_concrete
fill 438 280 570 438 280 574 minecraft:yellow_concrete
fill 438 280 576 438 280 580 minecraft:sea_lantern
fill 438 280 582 438 280 586 minecraft:sea_lantern
fill 438 280 588 438 280 592 minecraft:yellow_concrete
fill 438 280 594 438 280 598 minecraft:yellow_concrete
fill 439 280 558 443 280 562 minecraft:red_concrete
fill 439 280 564 443 280 568 minecraft:blue_concrete
fill 439 280 570 443 280 574 minecraft:red_concrete
fill 439 280 576 442 280 576 minecraft:sea_lantern
fill 439 280 577 441 280 579 minecraft:white_concrete
fill 439 280 580 442 280 580 minecraft:sea_lantern
fill 439 280 582 442 280 582 minecraft:sea_lantern
fill 439 280 583 441 280 585 minecraft:white_concrete
fill 439 280 586 442 280 586 minecraft:sea_lantern
fill 439 280 588 443 280 592 minecraft:blue_concrete
fill 439 280 594 443 280 598 minecraft:red_concrete
fill 442 280 577 442 280 579 minecraft:sea_lantern
setblock 442 280 581 minecraft:sea_lantern
fill 442 280 583 442 280 585 minecraft:sea_lantern
fill 443 280 576 443 280 578 minecraft:blue_concrete
fill 443 280 579 446 280 579 minecraft:sea_lantern
fill 443 280 583 446 280 583 minecraft:sea_lantern
fill 443 280 584 443 280 586 minecraft:red_concrete
fill 444 280 558 444 280 562 minecraft:yellow_concrete
fill 444 280 564 444 280 568 minecraft:yellow_concrete
fill 444 280 570 444 280 574 minecraft:yellow_concrete
fill 444 280 576 444 280 578 minecraft:yellow_concrete
fill 444 280 584 444 280 586 minecraft:yellow_concrete
fill 444 280 588 444 280 592 minecraft:yellow_concrete
fill 444 280 594 444 280 598 minecraft:yellow_concrete
fill 445 280 558 449 280 562 minecraft:blue_concrete
fill 445 280 564 449 280 568 minecraft:red_concrete
fill 445 280 570 449 280 574 minecraft:blue_concrete
fill 445 280 576 445 280 578 minecraft:red_concrete
fill 445 280 584 445 280 586 minecraft:blue_concrete
fill 445 280 588 449 280 592 minecraft:red_concrete
fill 445 280 594 449 280 598 minecraft:blue_concrete
fill 446 280 576 446 280 578 minecraft:sea_lantern
fill 446 280 580 446 280 582 minecraft:sea_lantern
fill 446 280 584 446 280 586 minecraft:sea_lantern
fill 447 280 576 450 280 576 minecraft:sea_lantern
fill 447 280 577 449 280 579 minecraft:white_concrete
fill 447 280 580 450 280 580 minecraft:sea_lantern
fill 447 280 581 464 280 581 minecraft:yellow_concrete
fill 447 280 582 450 280 582 minecraft:sea_lantern
fill 447 280 583 449 280 585 minecraft:white_concrete
fill 447 280 586 450 280 586 minecraft:sea_lantern
fill 450 280 558 450 280 562 minecraft:yellow_concrete
fill 450 280 564 450 280 568 minecraft:yellow_concrete
fill 450 280 570 450 280 574 minecraft:yellow_concrete
fill 450 280 577 450 280 579 minecraft:sea_lantern
fill 450 280 583 450 280 585 minecraft:sea_lantern
fill 450 280 588 450 280 592 minecraft:yellow_concrete
fill 450 280 594 450 280 598 minecraft:yellow_concrete
fill 451 280 558 455 280 562 minecraft:red_concrete
fill 451 280 564 455 280 568 minecraft:blue_concrete
fill 451 280 570 455 280 574 minecraft:red_concrete
fill 451 280 576 455 280 580 minecraft:blue_concrete
fill 451 280 582 455 280 586 minecraft:red_concrete
fill 451 280 588 455 280 592 minecraft:blue_concrete
fill 451 280 594 455 280 598 minecraft:red_concrete
fill 456 280 558 456 280 562 minecraft:yellow_concrete
fill 456 280 564 456 280 568 minecraft:yellow_concrete
fill 456 280 570 456 280 574 minecraft:yellow_concrete
fill 456 280 576 456 280 580 minecraft:yellow_concrete
fill 456 280 582 456 280 586 minecraft:yellow_concrete
fill 456 280 588 456 280 592 minecraft:yellow_concrete
fill 456 280 594 456 280 598 minecraft:yellow_concrete
fill 457 280 558 461 280 562 minecraft:blue_concrete
fill 457 280 564 461 280 568 minecraft:red_concrete
fill 457 280 570 461 280 574 minecraft:blue_concrete
fill 457 280 576 461 280 580 minecraft:red_concrete
fill 457 280 582 461 280 586 minecraft:blue_concrete
fill 457 280 588 461 280 592 minecraft:red_concrete
fill 457 280 594 461 280 598 minecraft:blue_concrete
fill 462 280 558 462 280 562 minecraft:yellow_concrete
fill 462 280 564 462 280 568 minecraft:yellow_concrete
fill 462 280 570 462 280 574 minecraft:yellow_concrete
fill 462 280 576 462 280 580 minecraft:yellow_concrete
fill 462 280 582 462 280 586 minecraft:yellow_concrete
fill 462 280 588 462 280 592 minecraft:yellow_concrete
fill 462 280 594 462 280 598 minecraft:yellow_concrete
fill 463 280 558 464 280 562 minecraft:red_concrete
fill 463 280 564 464 280 568 minecraft:blue_concrete
fill 463 280 570 464 280 574 minecraft:red_concrete
fill 463 280 576 464 280 580 minecraft:blue_concrete
fill 463 280 582 464 280 586 minecraft:red_concrete
fill 463 280 588 464 280 592 minecraft:blue_concrete
fill 463 280 594 464 280 598 minecraft:red_concrete
setblock 426 283 560 minecraft:light[level=14]
setblock 426 283 568 minecraft:light[level=14]
setblock 426 283 576 minecraft:light[level=14]
setblock 426 283 584 minecraft:light[level=14]
setblock 426 283 592 minecraft:light[level=14]
setblock 434 283 560 minecraft:light[level=14]
setblock 434 283 568 minecraft:light[level=14]
setblock 434 283 576 minecraft:light[level=14]
setblock 434 283 584 minecraft:light[level=14]
setblock 434 283 592 minecraft:light[level=14]
setblock 442 283 560 minecraft:light[level=14]
setblock 442 283 568 minecraft:light[level=14]
setblock 442 283 576 minecraft:light[level=14]
setblock 442 283 584 minecraft:light[level=14]
setblock 442 283 592 minecraft:light[level=14]
setblock 450 283 560 minecraft:light[level=14]
setblock 450 283 568 minecraft:light[level=14]
setblock 450 283 576 minecraft:light[level=14]
setblock 450 283 584 minecraft:light[level=14]
setblock 450 283 592 minecraft:light[level=14]
setblock 458 283 560 minecraft:light[level=14]
setblock 458 283 568 minecraft:light[level=14]
setblock 458 283 576 minecraft:light[level=14]
setblock 458 283 584 minecraft:light[level=14]
setblock 458 283 592 minecraft:light[level=14]
fill 423 284 562 423 289 562 minecraft:sea_lantern
fill 423 284 563 423 307 564 minecraft:red_concrete
fill 423 284 570 423 289 570 minecraft:sea_lantern
fill 423 284 578 423 289 578 minecraft:sea_lantern
fill 423 284 579 423 307 582 minecraft:red_concrete
fill 423 284 586 423 289 586 minecraft:sea_lantern
fill 423 284 594 423 289 594 minecraft:sea_lantern
fill 423 284 595 423 307 595 minecraft:red_concrete
fill 424 284 564 424 300 565 minecraft:white_concrete
fill 424 284 572 424 300 573 minecraft:white_concrete
fill 424 284 580 424 300 581 minecraft:white_concrete
fill 424 284 588 424 300 589 minecraft:white_concrete
fill 424 284 596 424 300 597 minecraft:white_concrete
fill 425 284 558 426 300 558 minecraft:white_concrete
fill 426 284 599 426 289 599 minecraft:sea_lantern
fill 429 284 557 429 307 557 minecraft:red_concrete
fill 430 284 557 430 289 557 minecraft:sea_lantern
fill 430 284 598 431 300 598 minecraft:white_concrete
fill 433 284 558 434 300 558 minecraft:white_concrete
fill 434 284 599 434 289 599 minecraft:sea_lantern
fill 435 284 599 435 307 599 minecraft:red_concrete
fill 438 284 557 438 289 557 minecraft:sea_lantern
fill 438 284 598 439 300 598 minecraft:white_concrete
fill 440 284 599 441 307 599 minecraft:red_concrete
fill 441 284 558 442 300 558 minecraft:white_concrete
fill 442 284 599 442 289 599 minecraft:sea_lantern
fill 443 284 599 445 307 599 minecraft:red_concrete
fill 446 284 557 446 289 557 minecraft:sea_lantern
fill 446 284 598 447 300 598 minecraft:white_concrete
fill 449 284 558 450 300 558 minecraft:white_concrete
fill 450 284 599 450 289 599 minecraft:sea_lantern
fill 454 284 557 454 289 557 minecraft:sea_lantern
fill 454 284 598 455 300 598 minecraft:white_concrete
fill 457 284 558 458 300 558 minecraft:white_concrete
fill 458 284 599 458 289 599 minecraft:sea_lantern
fill 462 284 557 462 289 557 minecraft:sea_lantern
fill 462 284 598 463 300 598 minecraft:white_concrete
fill 464 284 559 464 300 560 minecraft:white_concrete
fill 464 284 567 464 300 568 minecraft:white_concrete
fill 464 284 575 464 300 576 minecraft:white_concrete
fill 464 284 583 464 300 584 minecraft:white_concrete
fill 464 284 591 464 300 592 minecraft:white_concrete
fill 465 284 562 465 289 562 minecraft:sea_lantern
fill 465 284 563 465 307 565 minecraft:red_concrete
fill 465 284 570 465 289 570 minecraft:sea_lantern
fill 465 284 578 465 289 578 minecraft:sea_lantern
fill 465 284 579 465 307 579 minecraft:red_concrete
fill 465 284 585 465 307 585 minecraft:red_concrete
fill 465 284 586 465 289 586 minecraft:sea_lantern
fill 465 284 587 465 307 588 minecraft:red_concrete
fill 465 284 593 465 307 593 minecraft:red_concrete
fill 465 284 594 465 289 594 minecraft:sea_lantern
fill 423 290 562 423 297 562 minecraft:red_concrete
fill 423 290 570 423 297 570 minecraft:red_concrete
fill 423 290 578 423 297 578 minecraft:red_concrete
fill 423 290 586 423 297 586 minecraft:red_concrete
fill 423 290 594 423 297 594 minecraft:red_concrete
fill 426 290 599 426 297 599 minecraft:red_concrete
fill 430 290 557 430 297 557 minecraft:red_concrete
fill 434 290 599 434 297 599 minecraft:red_concrete
fill 438 290 557 438 297 557 minecraft:red_concrete
fill 442 290 599 442 297 599 minecraft:red_concrete
fill 444 290 587 444 291 587 minecraft:yellow_concrete
fill 446 290 557 446 297 557 minecraft:red_concrete
fill 450 290 599 450 297 599 minecraft:red_concrete
fill 454 290 557 454 297 557 minecraft:red_concrete
fill 458 290 599 458 297 599 minecraft:red_concrete
fill 462 290 557 462 297 557 minecraft:red_concrete
fill 465 290 562 465 297 562 minecraft:red_concrete
fill 465 290 570 465 297 570 minecraft:red_concrete
fill 465 290 578 465 297 578 minecraft:red_concrete
fill 465 290 586 465 297 586 minecraft:red_concrete
fill 465 290 594 465 297 594 minecraft:red_concrete
setblock 426 291 560 minecraft:light[level=14]
setblock 426 291 568 minecraft:light[level=14]
setblock 426 291 576 minecraft:light[level=14]
setblock 426 291 584 minecraft:light[level=14]
setblock 426 291 592 minecraft:light[level=14]
setblock 434 291 560 minecraft:light[level=14]
setblock 434 291 568 minecraft:light[level=14]
setblock 434 291 576 minecraft:light[level=14]
setblock 434 291 584 minecraft:light[level=14]
setblock 434 291 592 minecraft:light[level=14]
setblock 442 291 560 minecraft:light[level=14]
setblock 442 291 568 minecraft:light[level=14]
setblock 442 291 576 minecraft:light[level=14]
setblock 442 291 584 minecraft:light[level=14]
setblock 442 291 592 minecraft:light[level=14]
setblock 450 291 560 minecraft:light[level=14]
setblock 450 291 568 minecraft:light[level=14]
setblock 450 291 576 minecraft:light[level=14]
setblock 450 291 584 minecraft:light[level=14]
setblock 450 291 592 minecraft:light[level=14]
setblock 458 291 560 minecraft:light[level=14]
setblock 458 291 568 minecraft:light[level=14]
setblock 458 291 576 minecraft:light[level=14]
setblock 458 291 584 minecraft:light[level=14]
setblock 458 291 592 minecraft:light[level=14]
fill 424 293 569 426 293 569 minecraft:iron_block
fill 424 294 558 424 295 563 minecraft:white_concrete
fill 424 294 566 425 294 571 minecraft:white_concrete
fill 424 294 574 425 294 579 minecraft:white_concrete
fill 424 294 582 425 294 587 minecraft:white_concrete
fill 424 294 590 425 294 595 minecraft:white_concrete
fill 424 294 598 429 295 598 minecraft:white_concrete
fill 425 294 559 425 294 565 minecraft:white_concrete
fill 425 294 572 425 294 573 minecraft:white_concrete
fill 425 294 580 425 294 581 minecraft:white_concrete
fill 425 294 588 425 294 589 minecraft:white_concrete
fill 425 294 596 425 294 597 minecraft:white_concrete
fill 426 294 559 463 294 559 minecraft:white_concrete
setblock 426 294 569 minecraft:iron_block
fill 426 294 597 464 294 597 minecraft:white_concrete
fill 427 294 558 432 295 558 minecraft:white_concrete
fill 432 294 598 437 295 598 minecraft:white_concrete
fill 435 294 558 440 295 558 minecraft:white_concrete
fill 440 294 598 445 295 598 minecraft:white_concrete
fill 443 294 558 448 295 558 minecraft:white_concrete
fill 448 294 598 453 295 598 minecraft:white_concrete
fill 451 294 558 456 295 558 minecraft:white_concrete
fill 456 294 598 461 295 598 minecraft:white_concrete
fill 459 294 558 464 295 558 minecraft:white_concrete
fill 463 294 560 463 294 596 minecraft:white_concrete
fill 464 294 561 464 295 566 minecraft:white_concrete
fill 464 294 569 464 295 574 minecraft:white_concrete
fill 464 294 577 464 295 582 minecraft:white_concrete
fill 464 294 585 464 295 590 minecraft:white_concrete
fill 464 294 593 464 295 596 minecraft:white_concrete
fill 464 294 598 464 295 598 minecraft:white_concrete
fill 424 295 566 424 295 571 minecraft:white_concrete
fill 424 295 574 424 295 579 minecraft:white_concrete
fill 424 295 582 424 295 587 minecraft:white_concrete
fill 424 295 590 424 295 595 minecraft:white_concrete
setblock 464 295 597 minecraft:white_concrete
fill 441 296 595 441 297 597 minecraft:iron_block
fill 424 297 566 426 298 566 minecraft:iron_block
fill 423 298 562 423 300 562 minecraft:sea_lantern
fill 423 298 570 423 300 570 minecraft:sea_lantern
fill 423 298 578 423 300 578 minecraft:sea_lantern
fill 423 298 586 423 300 586 minecraft:sea_lantern
fill 423 298 594 423 300 594 minecraft:sea_lantern
fill 426 298 599 426 300 599 minecraft:sea_lantern
fill 430 298 557 430 300 557 minecraft:sea_lantern
fill 434 298 599 434 300 599 minecraft:sea_lantern
fill 436 298 569 436 299 569 minecraft:blue_concrete
fill 438 298 557 438 300 557 minecraft:sea_lantern
fill 442 298 599 442 300 599 minecraft:sea_lantern
fill 446 298 557 446 300 557 minecraft:sea_lantern
fill 450 298 599 450 300 599 minecraft:sea_lantern
fill 454 298 557 454 300 557 minecraft:sea_lantern
fill 458 298 599 458 300 599 minecraft:sea_lantern
fill 462 298 557 462 300 557 minecraft:sea_lantern
fill 465 298 562 465 300 562 minecraft:sea_lantern
fill 465 298 570 465 300 570 minecraft:sea_lantern
fill 465 298 578 465 300 578 minecraft:sea_lantern
fill 465 298 586 465 300 586 minecraft:sea_lantern
fill 465 298 594 465 300 594 minecraft:sea_lantern
setblock 426 299 560 minecraft:light[level=14]
setblock 426 299 568 minecraft:light[level=14]
setblock 426 299 576 minecraft:light[level=14]
setblock 426 299 584 minecraft:light[level=14]
setblock 426 299 592 minecraft:light[level=14]
fill 430 299 587 430 300 587 minecraft:light_blue_concrete
setblock 434 299 560 minecraft:light[level=14]
setblock 434 299 568 minecraft:light[level=14]
setblock 434 299 576 minecraft:light[level=14]
setblock 434 299 584 minecraft:light[level=14]
setblock 434 299 592 minecraft:light[level=14]
setblock 442 299 560 minecraft:light[level=14]
setblock 442 299 568 minecraft:light[level=14]
setblock 442 299 576 minecraft:light[level=14]
setblock 442 299 584 minecraft:light[level=14]
setblock 442 299 592 minecraft:light[level=14]
setblock 450 299 560 minecraft:light[level=14]
setblock 450 299 568 minecraft:light[level=14]
setblock 450 299 576 minecraft:light[level=14]
setblock 450 299 584 minecraft:light[level=14]
setblock 450 299 592 minecraft:light[level=14]
setblock 458 299 560 minecraft:light[level=14]
setblock 458 299 568 minecraft:light[level=14]
setblock 458 299 576 minecraft:light[level=14]
setblock 458 299 584 minecraft:light[level=14]
setblock 458 299 592 minecraft:light[level=14]
fill 423 301 562 423 307 562 minecraft:red_concrete
fill 423 301 570 423 307 570 minecraft:red_concrete
fill 423 301 578 423 307 578 minecraft:red_concrete
fill 423 301 586 423 307 586 minecraft:red_concrete
fill 423 301 594 423 307 594 minecraft:red_concrete
fill 426 301 599 426 307 599 minecraft:red_concrete
fill 430 301 557 430 307 557 minecraft:red_concrete
fill 434 301 599 434 307 599 minecraft:red_concrete
fill 438 301 557 438 307 557 minecraft:red_concrete
fill 442 301 599 442 307 599 minecraft:red_concrete
fill 446 301 557 446 307 557 minecraft:red_concrete
fill 450 301 599 450 307 599 minecraft:red_concrete
fill 454 301 557 454 307 557 minecraft:red_concrete
fill 458 301 599 458 307 599 minecraft:red_concrete
fill 462 301 557 462 307 557 minecraft:red_concrete
fill 465 301 562 465 307 562 minecraft:red_concrete
fill 465 301 570 465 307 570 minecraft:red_concrete
fill 465 301 578 465 307 578 minecraft:red_concrete
fill 465 301 586 465 307 586 minecraft:red_concrete
fill 465 301 594 465 307 594 minecraft:red_concrete
