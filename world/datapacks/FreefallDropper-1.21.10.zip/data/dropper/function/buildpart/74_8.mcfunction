fill 96 238 337 96 240 337 minecraft:stone
setblock 96 238 341 minecraft:stripped_spruce_log
fill 96 238 342 97 240 342 minecraft:stone
setblock 96 238 357 minecraft:stone
setblock 96 238 361 minecraft:stripped_spruce_log
setblock 97 238 335 minecraft:stripped_spruce_log
fill 97 238 336 97 240 336 minecraft:stone
setblock 97 238 340 minecraft:stripped_spruce_log
fill 97 238 341 97 241 341 minecraft:stone
setblock 98 238 322 minecraft:stone
setblock 99 238 323 minecraft:stripped_spruce_log
setblock 99 238 363 minecraft:stripped_spruce_log
fill 100 238 323 103 238 323 minecraft:stone
fill 100 238 363 103 238 363 minecraft:stone
fill 101 238 343 101 240 345 minecraft:cobbled_deepslate
fill 102 238 342 103 240 342 minecraft:cobbled_deepslate
fill 102 238 346 103 240 346 minecraft:cobbled_deepslate
setblock 102 238 364 minecraft:raw_gold_block
setblock 104 238 323 minecraft:stripped_spruce_log
setblock 104 238 363 minecraft:stripped_spruce_log
fill 105 238 323 108 238 323 minecraft:stone
fill 105 238 344 105 240 344 minecraft:cobbled_deepslate
setblock 105 238 362 minecraft:stripped_spruce_log
fill 105 238 363 108 238 363 minecraft:stone
setblock 105 238 364 minecraft:raw_gold_block
fill 106 238 362 109 238 362 minecraft:stone
setblock 106 238 364 minecraft:andesite
setblock 107 238 324 minecraft:stone
setblock 107 238 364 minecraft:stone
setblock 108 238 324 minecraft:stripped_spruce_log
fill 108 238 359 108 246 359 minecraft:stripped_spruce_log
fill 108 238 361 110 238 361 minecraft:stone
setblock 109 238 323 minecraft:stripped_spruce_log
fill 109 238 324 109 240 324 minecraft:stone
setblock 109 238 363 minecraft:stripped_spruce_log
fill 110 238 322 110 238 323 minecraft:stone
fill 110 238 360 111 238 360 minecraft:stone
setblock 110 238 362 minecraft:stripped_spruce_log
fill 110 238 363 113 238 363 minecraft:stone
fill 111 238 323 113 238 323 minecraft:stone
setblock 111 238 361 minecraft:stripped_spruce_log
fill 111 238 362 111 240 362 minecraft:stone
setblock 112 238 360 minecraft:stripped_spruce_log
fill 112 238 361 112 241 361 minecraft:stone
setblock 113 238 324 minecraft:stripped_spruce_log
fill 113 238 360 113 241 360 minecraft:stone
setblock 114 238 323 minecraft:stripped_spruce_log
fill 114 238 324 114 240 324 minecraft:stone
setblock 114 238 363 minecraft:stripped_spruce_log
fill 115 238 323 115 240 323 minecraft:stone
fill 115 238 363 115 240 363 minecraft:stone
setblock 115 238 364 minecraft:raw_gold_block
setblock 116 238 322 minecraft:stone
setblock 116 238 361 minecraft:stripped_spruce_log
fill 116 238 362 116 240 362 minecraft:stone
setblock 117 238 360 minecraft:stripped_spruce_log
fill 117 238 361 117 241 361 minecraft:stone
setblock 117 238 364 minecraft:stone
fill 118 238 364 119 238 364 minecraft:andesite
setblock 119 238 323 minecraft:stripped_spruce_log
setblock 119 238 363 minecraft:stripped_spruce_log
setblock 120 238 322 minecraft:stone
setblock 120 238 362 minecraft:stripped_spruce_log
fill 120 238 363 120 240 363 minecraft:stone
fill 121 238 360 121 239 360 minecraft:iron_bars
setblock 121 238 361 minecraft:stripped_spruce_log
fill 121 238 362 124 238 362 minecraft:stone
setblock 123 238 363 minecraft:stone
setblock 124 238 363 minecraft:stripped_spruce_log
setblock 125 238 362 minecraft:stripped_spruce_log
fill 125 238 363 125 240 363 minecraft:stone
setblock 126 238 322 minecraft:stone
setblock 126 238 361 minecraft:stripped_spruce_log
fill 126 238 362 129 238 362 minecraft:stone
setblock 126 238 364 minecraft:diamond_block
fill 127 238 361 130 238 361 minecraft:stone
setblock 128 238 363 minecraft:stone
setblock 129 238 323 minecraft:stripped_spruce_log
setblock 129 238 363 minecraft:stripped_spruce_log
fill 130 238 323 133 238 323 minecraft:stone
fill 130 238 360 131 238 360 minecraft:stone
setblock 130 238 362 minecraft:stripped_spruce_log
fill 130 238 363 130 240 363 minecraft:stone
setblock 131 238 361 minecraft:stripped_spruce_log
fill 131 238 362 131 240 362 minecraft:stone
fill 132 238 337 132 238 339 minecraft:stone
setblock 132 238 340 minecraft:stripped_spruce_log
fill 132 238 341 132 239 343 minecraft:stone
setblock 132 238 356 minecraft:stone
setblock 132 238 360 minecraft:stripped_spruce_log
fill 132 238 361 132 241 361 minecraft:stone
fill 133 238 322 133 239 322 minecraft:stone
setblock 133 238 334 minecraft:stripped_spruce_log
fill 133 238 335 133 241 335 minecraft:stone
setblock 133 238 338 minecraft:stone
setblock 133 238 339 minecraft:stripped_spruce_log
fill 133 238 340 133 241 340 minecraft:stone
setblock 133 238 344 minecraft:stripped_spruce_log
fill 133 238 345 133 241 345 minecraft:stone
fill 133 238 347 133 238 348 minecraft:stone
setblock 133 238 354 minecraft:stripped_spruce_log
fill 133 238 355 133 240 355 minecraft:stone
setblock 133 238 359 minecraft:stripped_spruce_log
fill 133 238 360 133 241 360 minecraft:stone
setblock 134 238 323 minecraft:stripped_spruce_log
fill 134 238 331 134 238 332 minecraft:stone
setblock 134 238 333 minecraft:stripped_spruce_log
fill 134 238 334 134 240 334 minecraft:stone
setblock 134 238 338 minecraft:stripped_spruce_log
fill 134 238 339 134 240 339 minecraft:stone
fill 134 238 344 134 240 344 minecraft:stone
setblock 134 238 348 minecraft:stripped_spruce_log
fill 134 238 349 134 240 349 minecraft:stone
setblock 134 238 353 minecraft:stripped_spruce_log
fill 134 238 354 134 240 354 minecraft:stone
setblock 134 238 358 minecraft:stripped_spruce_log
fill 134 238 359 134 240 359 minecraft:stone
setblock 134 238 363 minecraft:stripped_spruce_log
fill 135 238 323 135 240 324 minecraft:stone
fill 135 238 328 136 238 328 minecraft:stone
setblock 135 238 332 minecraft:stripped_spruce_log
fill 135 238 333 135 240 333 minecraft:stone
setblock 135 238 337 minecraft:stripped_spruce_log
fill 135 238 338 135 240 338 minecraft:stone
setblock 135 238 342 minecraft:stripped_spruce_log
fill 135 238 343 135 240 343 minecraft:stone
setblock 135 238 347 minecraft:stripped_spruce_log
fill 135 238 348 135 240 348 minecraft:stone
setblock 135 238 352 minecraft:stripped_spruce_log
fill 135 238 353 135 240 353 minecraft:stone
setblock 135 238 357 minecraft:stripped_spruce_log
fill 135 238 358 136 238 358 minecraft:stone
setblock 135 238 362 minecraft:stripped_spruce_log
fill 135 238 363 135 240 363 minecraft:stone
setblock 136 238 323 minecraft:stone
setblock 136 238 327 minecraft:stone
fill 136 238 329 136 241 329 minecraft:andesite
fill 136 238 355 136 238 356 minecraft:stone
fill 136 238 359 136 241 360 minecraft:andesite
setblock 136 238 361 minecraft:raw_iron_block
fill 94 239 322 94 241 322 minecraft:andesite
fill 94 239 323 95 239 324 minecraft:stone
fill 94 239 329 96 239 329 minecraft:stone
setblock 94 239 336 minecraft:stone
setblock 94 239 338 minecraft:diamond_block
fill 94 239 344 94 241 344 minecraft:andesite
fill 94 239 358 94 241 358 minecraft:andesite
fill 94 239 363 94 240 363 minecraft:stone
fill 94 239 364 94 242 364 minecraft:andesite
setblock 95 239 325 minecraft:stone
setblock 95 239 326 minecraft:stripped_spruce_log
fill 95 239 327 95 240 328 minecraft:stone
setblock 95 239 330 minecraft:stone
setblock 95 239 331 minecraft:stripped_spruce_log
fill 95 239 332 95 239 335 minecraft:stone
setblock 95 239 336 minecraft:stripped_spruce_log
fill 95 239 337 95 239 340 minecraft:stone
setblock 95 239 341 minecraft:stripped_spruce_log
fill 95 239 342 95 240 342 minecraft:stone
fill 95 239 344 95 239 345 minecraft:stone
setblock 95 239 346 minecraft:stripped_spruce_log
fill 95 239 347 95 240 347 minecraft:stone
setblock 95 239 351 minecraft:stripped_spruce_log
setblock 95 239 352 minecraft:stone
setblock 95 239 356 minecraft:stripped_spruce_log
fill 95 239 357 95 240 358 minecraft:stone
setblock 95 239 360 minecraft:stone
setblock 95 239 361 minecraft:stripped_spruce_log
fill 95 239 362 95 240 362 minecraft:stone
setblock 96 239 324 minecraft:glowstone
setblock 96 239 330 minecraft:stripped_spruce_log
fill 96 239 331 96 239 334 minecraft:stone
setblock 96 239 335 minecraft:stripped_spruce_log
fill 96 239 336 96 240 336 minecraft:stone
setblock 96 239 340 minecraft:stripped_spruce_log
fill 96 239 341 96 240 341 minecraft:stone
setblock 96 239 343 minecraft:glowstone
setblock 96 239 345 minecraft:stripped_spruce_log
setblock 96 239 360 minecraft:stripped_spruce_log
fill 96 239 361 96 240 361 minecraft:stone
setblock 96 239 362 minecraft:glowstone
setblock 97 239 334 minecraft:stripped_spruce_log
fill 97 239 335 97 240 335 minecraft:stone
setblock 97 239 339 minecraft:stripped_spruce_log
fill 97 239 340 97 241 340 minecraft:stone
fill 98 239 322 98 241 322 minecraft:andesite
setblock 98 239 323 minecraft:stripped_spruce_log
setblock 98 239 363 minecraft:stripped_spruce_log
fill 99 239 323 102 239 323 minecraft:stone
fill 99 239 363 102 239 363 minecraft:stone
fill 100 239 322 100 241 322 minecraft:andesite
setblock 101 239 322 minecraft:stone
setblock 102 239 364 minecraft:andesite
setblock 103 239 323 minecraft:stripped_spruce_log
setblock 103 239 363 minecraft:stripped_spruce_log
fill 104 239 323 107 239 323 minecraft:stone
fill 104 239 342 104 240 342 minecraft:cobbled_deepslate
fill 104 239 346 104 240 346 minecraft:cobbled_deepslate
setblock 104 239 362 minecraft:stripped_spruce_log
fill 104 239 363 104 240 364 minecraft:stone
fill 105 239 324 106 239 324 minecraft:stone
fill 105 239 343 105 240 343 minecraft:cobbled_deepslate
fill 105 239 345 105 240 345 minecraft:cobbled_deepslate
fill 105 239 362 107 239 363 minecraft:stone
fill 105 239 364 105 241 364 minecraft:andesite
fill 106 239 322 106 241 322 minecraft:andesite
setblock 106 239 364 minecraft:stone
setblock 107 239 322 minecraft:stone
setblock 107 239 324 minecraft:stripped_spruce_log
fill 107 239 361 109 239 361 minecraft:stone
fill 107 239 364 107 241 364 minecraft:andesite
fill 108 239 322 108 241 322 minecraft:andesite
setblock 108 239 323 minecraft:stripped_spruce_log
fill 108 239 324 108 240 324 minecraft:stone
setblock 108 239 362 minecraft:stone
setblock 108 239 363 minecraft:stripped_spruce_log
fill 109 239 323 112 239 323 minecraft:stone
fill 109 239 325 110 239 325 minecraft:stone
fill 109 239 360 110 239 360 minecraft:stone
setblock 109 239 362 minecraft:stripped_spruce_log
fill 109 239 363 112 239 363 minecraft:stone
fill 110 239 322 110 241 322 minecraft:andesite
setblock 110 239 361 minecraft:stripped_spruce_log
fill 110 239 362 110 240 362 minecraft:stone
setblock 111 239 325 minecraft:stripped_spruce_log
setblock 111 239 360 minecraft:stripped_spruce_log
fill 111 239 361 111 242 361 minecraft:stone
setblock 112 239 324 minecraft:stripped_spruce_log
fill 112 239 325 113 241 325 minecraft:stone
fill 112 239 360 112 242 360 minecraft:stone
setblock 112 239 364 minecraft:raw_iron_block
setblock 113 239 323 minecraft:stripped_spruce_log
fill 113 239 324 113 240 324 minecraft:stone
setblock 113 239 363 minecraft:stripped_spruce_log
fill 114 239 322 114 239 323 minecraft:stone
setblock 114 239 362 minecraft:stripped_spruce_log
fill 114 239 363 114 240 363 minecraft:stone
setblock 115 239 324 minecraft:glowstone
setblock 115 239 360 minecraft:stone
setblock 115 239 361 minecraft:stripped_spruce_log
setblock 115 239 362 minecraft:glowstone
fill 115 239 364 115 241 364 minecraft:andesite
fill 116 239 322 116 241 322 minecraft:andesite
setblock 116 239 360 minecraft:stripped_spruce_log
fill 116 239 361 116 242 361 minecraft:stone
fill 117 239 360 117 240 360 minecraft:stone
fill 117 239 364 118 241 364 minecraft:andesite
setblock 118 239 323 minecraft:stripped_spruce_log
setblock 118 239 363 minecraft:stripped_spruce_log
fill 119 239 323 119 240 323 minecraft:stone
setblock 119 239 362 minecraft:stripped_spruce_log
fill 119 239 363 119 239 364 minecraft:stone
fill 120 239 322 120 241 322 minecraft:andesite
setblock 120 239 361 minecraft:stripped_spruce_log
fill 120 239 362 123 239 362 minecraft:stone
fill 121 239 361 124 239 361 minecraft:stone
setblock 123 239 363 minecraft:stripped_spruce_log
setblock 124 239 362 minecraft:stripped_spruce_log
fill 124 239 363 124 240 363 minecraft:stone
setblock 125 239 361 minecraft:stripped_spruce_log
fill 125 239 362 128 239 362 minecraft:stone
fill 126 239 322 126 241 322 minecraft:andesite
fill 126 239 361 129 239 361 minecraft:stone
fill 126 239 364 126 241 364 minecraft:andesite
setblock 127 239 323 minecraft:stone
setblock 128 239 322 minecraft:stone
setblock 128 239 323 minecraft:stripped_spruce_log
setblock 128 239 363 minecraft:stripped_spruce_log
fill 129 239 323 132 239 323 minecraft:stone
fill 129 239 360 130 239 360 minecraft:stone
setblock 129 239 362 minecraft:stripped_spruce_log
fill 129 239 363 129 240 363 minecraft:stone
setblock 130 239 361 minecraft:stripped_spruce_log
fill 130 239 362 130 240 362 minecraft:stone
setblock 131 239 360 minecraft:stripped_spruce_log
fill 131 239 361 131 242 361 minecraft:stone
fill 132 239 336 132 239 338 minecraft:stone
setblock 132 239 339 minecraft:stripped_spruce_log
fill 132 239 340 132 242 340 minecraft:stone
setblock 132 239 344 minecraft:stripped_spruce_log
fill 132 239 357 132 239 358 minecraft:stone
setblock 132 239 359 minecraft:stripped_spruce_log
fill 132 239 360 132 240 360 minecraft:stone
setblock 133 239 323 minecraft:stripped_spruce_log
fill 133 239 334 133 240 334 minecraft:stone
setblock 133 239 338 minecraft:stripped_spruce_log
fill 133 239 339 133 242 339 minecraft:stone
setblock 133 239 342 minecraft:stone
setblock 133 239 343 minecraft:stripped_spruce_log
fill 133 239 344 133 242 344 minecraft:stone
setblock 133 239 347 minecraft:stone
setblock 133 239 348 minecraft:stripped_spruce_log
fill 133 239 349 133 241 349 minecraft:stone
setblock 133 239 353 minecraft:stripped_spruce_log
fill 133 239 354 133 240 354 minecraft:stone
setblock 133 239 358 minecraft:stripped_spruce_log
fill 133 239 359 133 241 359 minecraft:stone
setblock 133 239 363 minecraft:stripped_spruce_log
fill 134 239 323 134 240 323 minecraft:stone
setblock 134 239 324 minecraft:glowstone
setblock 134 239 331 minecraft:stone
setblock 134 239 332 minecraft:stripped_spruce_log
fill 134 239 333 134 240 333 minecraft:stone
setblock 134 239 337 minecraft:stripped_spruce_log
fill 134 239 338 134 240 338 minecraft:stone
setblock 134 239 342 minecraft:stripped_spruce_log
setblock 134 239 343 minecraft:glowstone
setblock 134 239 347 minecraft:stripped_spruce_log
fill 134 239 348 134 240 348 minecraft:stone
setblock 134 239 352 minecraft:stripped_spruce_log
fill 134 239 353 134 240 353 minecraft:stone
setblock 134 239 357 minecraft:stripped_spruce_log
fill 134 239 358 135 240 358 minecraft:stone
setblock 134 239 362 minecraft:glowstone
fill 134 239 363 134 240 363 minecraft:stone
setblock 135 239 322 minecraft:stone
setblock 135 239 325 minecraft:stone
setblock 135 239 326 minecraft:stripped_spruce_log
fill 135 239 327 135 240 328 minecraft:stone
setblock 135 239 331 minecraft:stripped_spruce_log
fill 135 239 332 135 240 332 minecraft:stone
setblock 135 239 336 minecraft:stripped_spruce_log
fill 135 239 337 135 240 337 minecraft:stone
setblock 135 239 341 minecraft:stripped_spruce_log
fill 135 239 342 135 240 342 minecraft:stone
setblock 135 239 346 minecraft:stripped_spruce_log
fill 135 239 347 135 240 347 minecraft:stone
setblock 135 239 351 minecraft:stripped_spruce_log
fill 135 239 352 135 240 352 minecraft:stone
setblock 135 239 356 minecraft:stripped_spruce_log
fill 135 239 357 135 240 357 minecraft:stone
setblock 135 239 361 minecraft:stripped_spruce_log
fill 135 239 362 135 240 362 minecraft:stone
fill 136 239 323 136 241 323 minecraft:andesite
fill 136 239 327 136 241 328 minecraft:andesite
setblock 136 239 333 minecraft:stone
fill 136 239 355 136 239 356 minecraft:andesite
setblock 136 239 358 minecraft:andesite
fill 136 239 361 136 241 361 minecraft:andesite
fill 94 240 323 95 240 323 minecraft:stone
fill 94 240 324 94 242 324 minecraft:andesite
fill 94 240 329 94 241 329 minecraft:andesite
fill 94 240 336 94 241 336 minecraft:andesite
fill 94 240 338 94 241 338 minecraft:andesite
setblock 94 240 351 minecraft:stone
setblock 94 240 355 minecraft:stone
setblock 94 240 357 minecraft:gold_block
setblock 94 240 359 minecraft:stone
setblock 95 240 324 minecraft:stone
setblock 95 240 325 minecraft:stripped_spruce_log
setblock 95 240 326 minecraft:stone
setblock 95 240 329 minecraft:stone
setblock 95 240 330 minecraft:stripped_spruce_log
fill 95 240 331 95 240 334 minecraft:stone
setblock 95 240 335 minecraft:stripped_spruce_log
fill 95 240 336 95 240 339 minecraft:stone
setblock 95 240 340 minecraft:stripped_spruce_log
setblock 95 240 341 minecraft:stone
setblock 95 240 344 minecraft:stone
setblock 95 240 345 minecraft:stripped_spruce_log
setblock 95 240 346 minecraft:stone
setblock 95 240 355 minecraft:stripped_spruce_log
setblock 95 240 356 minecraft:stone
setblock 95 240 360 minecraft:stripped_spruce_log
setblock 95 240 361 minecraft:stone
fill 96 240 324 96 241 324 minecraft:spruce_log
setblock 96 240 325 minecraft:stone
fill 96 240 330 96 240 333 minecraft:stone
setblock 96 240 334 minecraft:stripped_spruce_log
setblock 96 240 335 minecraft:stone
setblock 96 240 339 minecraft:stripped_spruce_log
setblock 96 240 340 minecraft:stone
fill 96 240 343 96 241 343 minecraft:spruce_log
setblock 96 240 344 minecraft:stripped_spruce_log
setblock 96 240 345 minecraft:stone
setblock 96 240 360 minecraft:stone
fill 96 240 362 96 241 362 minecraft:spruce_log
setblock 97 240 323 minecraft:stripped_spruce_log
setblock 97 240 324 minecraft:stone
setblock 97 240 325 minecraft:light[level=12]
setblock 97 240 332 minecraft:light[level=12]
setblock 97 240 338 minecraft:stripped_spruce_log
fill 97 240 339 97 241 339 minecraft:stone
setblock 97 240 346 minecraft:light[level=12]
setblock 97 240 353 minecraft:light[level=12]
setblock 97 240 360 minecraft:light[level=12]
setblock 97 240 362 minecraft:stone
setblock 97 240 363 minecraft:stripped_spruce_log
fill 98 240 323 101 240 323 minecraft:stone
fill 98 240 363 101 240 363 minecraft:stone
setblock 99 240 322 minecraft:stone
fill 100 240 343 100 240 345 minecraft:cobbled_deepslate
fill 101 240 322 101 241 322 minecraft:andesite
setblock 101 240 342 minecraft:cobbled_deepslate
setblock 101 240 346 minecraft:cobbled_deepslate
setblock 102 240 323 minecraft:stripped_spruce_log
fill 102 240 347 103 240 347 minecraft:cobbled_deepslate
setblock 102 240 363 minecraft:stripped_spruce_log
setblock 102 240 364 minecraft:stone
fill 103 240 323 105 240 324 minecraft:stone
setblock 103 240 341 minecraft:cobbled_deepslate
setblock 103 240 362 minecraft:stripped_spruce_log
setblock 103 240 363 minecraft:stone
setblock 104 240 325 minecraft:light[level=12]
setblock 104 240 332 minecraft:light[level=12]
setblock 104 240 339 minecraft:light[level=12]
setblock 104 240 353 minecraft:light[level=12]
setblock 104 240 360 minecraft:light[level=12]
fill 104 240 362 107 240 362 minecraft:stone
setblock 105 240 342 minecraft:cobbled_deepslate
setblock 105 240 346 minecraft:cobbled_deepslate
fill 105 240 363 106 240 363 minecraft:stone
setblock 106 240 323 minecraft:stone
setblock 106 240 324 minecraft:stripped_spruce_log
setblock 106 240 344 minecraft:cobbled_deepslate
fill 106 240 361 108 240 361 minecraft:stone
fill 106 240 364 106 241 364 minecraft:andesite
fill 107 240 322 107 242 322 minecraft:andesite
setblock 107 240 323 minecraft:stripped_spruce_log
setblock 107 240 324 minecraft:stone
setblock 107 240 363 minecraft:stripped_spruce_log
fill 108 240 323 111 240 323 minecraft:stone
fill 108 240 325 109 240 325 minecraft:stone
fill 108 240 360 109 240 360 minecraft:stone
setblock 108 240 362 minecraft:stripped_spruce_log
fill 108 240 363 111 240 363 minecraft:stone
setblock 109 240 361 minecraft:stripped_spruce_log
setblock 109 240 362 minecraft:stone
setblock 110 240 325 minecraft:stripped_spruce_log
setblock 110 240 360 minecraft:stripped_spruce_log
fill 110 240 361 110 243 361 minecraft:stone
setblock 111 240 324 minecraft:stripped_spruce_log
fill 111 240 325 111 243 325 minecraft:stone
setblock 111 240 332 minecraft:light[level=12]
setblock 111 240 339 minecraft:light[level=12]
setblock 111 240 346 minecraft:light[level=12]
setblock 111 240 353 minecraft:light[level=12]
fill 111 240 360 111 243 360 minecraft:stone
setblock 111 240 364 minecraft:gold_block
setblock 112 240 323 minecraft:stripped_spruce_log
setblock 112 240 324 minecraft:stone
setblock 112 240 363 minecraft:stripped_spruce_log
fill 112 240 364 112 241 364 minecraft:andesite
fill 113 240 323 114 240 323 minecraft:stone
setblock 113 240 362 minecraft:stripped_spruce_log
setblock 113 240 363 minecraft:stone
fill 114 240 322 114 242 322 minecraft:andesite
setblock 114 240 361 minecraft:stripped_spruce_log
setblock 114 240 362 minecraft:stone
fill 115 240 324 115 241 324 minecraft:spruce_log
setblock 115 240 360 minecraft:stripped_spruce_log
fill 115 240 361 115 243 361 minecraft:stone
fill 115 240 362 115 241 362 minecraft:spruce_log
setblock 116 240 323 minecraft:stone
setblock 116 240 324 minecraft:stripped_spruce_log
fill 116 240 358 116 241 359 minecraft:raw_gold_block
fill 116 240 360 116 241 360 minecraft:stone
setblock 117 240 323 minecraft:stripped_spruce_log
setblock 117 240 363 minecraft:stripped_spruce_log
setblock 118 240 323 minecraft:stone
setblock 118 240 325 minecraft:light[level=12]
setblock 118 240 332 minecraft:light[level=12]
setblock 118 240 339 minecraft:light[level=12]
setblock 118 240 346 minecraft:light[level=12]
setblock 118 240 353 minecraft:light[level=12]
setblock 118 240 360 minecraft:light[level=12]
setblock 118 240 362 minecraft:stripped_spruce_log
fill 118 240 363 119 240 363 minecraft:stone
setblock 119 240 361 minecraft:stripped_spruce_log
fill 119 240 362 122 240 362 minecraft:stone
fill 119 240 364 119 242 364 minecraft:andesite
setblock 120 240 323 minecraft:stone
fill 120 240 361 123 240 361 minecraft:stone
setblock 122 240 322 minecraft:stone
setblock 122 240 363 minecraft:stripped_spruce_log
setblock 122 240 364 minecraft:stone
setblock 123 240 362 minecraft:stripped_spruce_log
setblock 123 240 363 minecraft:stone
fill 123 240 364 124 241 364 minecraft:andesite
setblock 124 240 361 minecraft:stripped_spruce_log
fill 124 240 362 127 240 362 minecraft:stone
setblock 125 240 325 minecraft:light[level=12]
setblock 125 240 332 minecraft:light[level=12]
setblock 125 240 339 minecraft:light[level=12]
setblock 125 240 346 minecraft:light[level=12]
setblock 125 240 353 minecraft:light[level=12]
setblock 125 240 360 minecraft:light[level=12]
fill 125 240 361 128 240 361 minecraft:stone
setblock 126 240 323 minecraft:stone
setblock 127 240 322 minecraft:stone
setblock 127 240 323 minecraft:stripped_spruce_log
setblock 127 240 363 minecraft:stripped_spruce_log
fill 128 240 322 128 241 322 minecraft:andesite
fill 128 240 323 131 240 323 minecraft:stone
fill 128 240 360 129 240 360 minecraft:stone
setblock 128 240 362 minecraft:stripped_spruce_log
fill 128 240 363 128 240 364 minecraft:stone
setblock 129 240 361 minecraft:stripped_spruce_log
setblock 129 240 362 minecraft:stone
setblock 130 240 360 minecraft:stripped_spruce_log
fill 130 240 361 130 243 361 minecraft:stone
setblock 130 240 364 minecraft:stone
setblock 131 240 360 minecraft:stone
fill 131 240 364 131 242 364 minecraft:andesite
setblock 132 240 323 minecraft:stripped_spruce_log
setblock 132 240 325 minecraft:light[level=12]
setblock 132 240 332 minecraft:light[level=12]
fill 132 240 336 132 240 337 minecraft:stone
setblock 132 240 338 minecraft:stripped_spruce_log
fill 132 240 339 132 243 339 minecraft:stone
fill 132 240 341 132 240 342 minecraft:stone
setblock 132 240 343 minecraft:stripped_spruce_log
fill 132 240 344 132 242 345 minecraft:stone
setblock 132 240 346 minecraft:light[level=12]
setblock 132 240 353 minecraft:light[level=12]
setblock 132 240 359 minecraft:stone
setblock 132 240 363 minecraft:stripped_spruce_log
fill 133 240 322 133 241 322 minecraft:andesite
setblock 133 240 323 minecraft:stone
setblock 133 240 337 minecraft:stripped_spruce_log
fill 133 240 338 133 243 338 minecraft:stone
setblock 133 240 342 minecraft:stripped_spruce_log
fill 133 240 343 133 243 343 minecraft:stone
setblock 133 240 347 minecraft:stripped_spruce_log
fill 133 240 348 133 243 348 minecraft:stone
setblock 133 240 357 minecraft:stripped_spruce_log
fill 133 240 358 133 241 358 minecraft:stone
setblock 133 240 362 minecraft:stripped_spruce_log
setblock 133 240 363 minecraft:stone
fill 134 240 324 134 241 324 minecraft:spruce_log
setblock 134 240 332 minecraft:stone
setblock 134 240 336 minecraft:stripped_spruce_log
setblock 134 240 337 minecraft:stone
setblock 134 240 341 minecraft:stripped_spruce_log
setblock 134 240 342 minecraft:stone
fill 134 240 343 134 241 343 minecraft:spruce_log
setblock 134 240 346 minecraft:stripped_spruce_log
setblock 134 240 347 minecraft:stone
setblock 134 240 351 minecraft:stripped_spruce_log
setblock 134 240 352 minecraft:stone
setblock 134 240 356 minecraft:stripped_spruce_log
setblock 134 240 357 minecraft:stone
setblock 134 240 361 minecraft:stripped_spruce_log
fill 134 240 362 134 241 362 minecraft:spruce_log
fill 135 240 322 135 241 322 minecraft:andesite
setblock 135 240 325 minecraft:stripped_spruce_log
setblock 135 240 326 minecraft:stone
setblock 135 240 330 minecraft:stripped_spruce_log
setblock 135 240 331 minecraft:stone
setblock 135 240 335 minecraft:stripped_spruce_log
setblock 135 240 336 minecraft:stone
setblock 135 240 340 minecraft:stripped_spruce_log
setblock 135 240 341 minecraft:stone
setblock 135 240 345 minecraft:stripped_spruce_log
setblock 135 240 346 minecraft:stone
setblock 135 240 350 minecraft:stripped_spruce_log
setblock 135 240 351 minecraft:stone
setblock 135 240 355 minecraft:stripped_spruce_log
setblock 135 240 356 minecraft:stone
setblock 135 240 360 minecraft:stripped_spruce_log
setblock 135 240 361 minecraft:stone
setblock 136 240 325 minecraft:stone
fill 136 240 333 136 241 333 minecraft:andesite
setblock 136 240 355 minecraft:stone
fill 136 240 356 136 241 356 minecraft:andesite
setblock 136 240 358 minecraft:stone
setblock 136 240 362 minecraft:stone
setblock 94 241 323 minecraft:andesite
setblock 94 241 351 minecraft:andesite
setblock 94 241 355 minecraft:andesite
setblock 94 241 357 minecraft:diamond_block
setblock 94 241 359 minecraft:andesite
fill 94 241 363 94 242 363 minecraft:andesite
fill 95 241 323 95 241 363 minecraft:spruce_planks
fill 96 241 323 135 241 323 minecraft:spruce_planks
fill 96 241 325 96 241 342 minecraft:spruce_planks
fill 96 241 344 96 241 361 minecraft:spruce_planks
fill 96 241 363 135 241 363 minecraft:spruce_planks
fill 97 241 324 114 241 324 minecraft:spruce_planks
setblock 97 241 337 minecraft:stripped_spruce_log
setblock 97 241 338 minecraft:stone
fill 97 241 362 114 241 362 minecraft:spruce_planks
setblock 99 241 322 minecraft:andesite
fill 102 241 344 104 241 344 minecraft:raw_gold_block
setblock 102 241 364 minecraft:andesite
fill 103 241 343 103 242 343 minecraft:raw_gold_block
fill 103 241 345 103 242 345 minecraft:raw_gold_block
setblock 104 241 322 minecraft:raw_gold_block
setblock 104 241 364 minecraft:andesite
fill 105 241 361 107 241 361 minecraft:stone
fill 107 241 325 108 241 325 minecraft:stone
setblock 108 241 360 minecraft:stone
setblock 108 241 361 minecraft:stripped_spruce_log
setblock 109 241 325 minecraft:stripped_spruce_log
setblock 109 241 360 minecraft:stripped_spruce_log
fill 109 241 361 109 244 361 minecraft:stone
fill 110 241 325 110 244 325 minecraft:stone
fill 110 241 360 110 243 360 minecraft:stone
setblock 111 241 364 minecraft:andesite
setblock 113 241 361 minecraft:stripped_spruce_log
setblock 114 241 360 minecraft:stripped_spruce_log
fill 114 241 361 114 244 361 minecraft:stone
setblock 115 241 360 minecraft:stone
fill 116 241 324 133 241 324 minecraft:spruce_planks
setblock 116 241 357 minecraft:raw_gold_block
fill 116 241 362 133 241 362 minecraft:spruce_planks
setblock 118 241 361 minecraft:stripped_spruce_log
fill 119 241 361 121 241 361 minecraft:stone
setblock 122 241 322 minecraft:andesite
setblock 122 241 364 minecraft:andesite
setblock 123 241 361 minecraft:stripped_spruce_log
fill 124 241 361 127 241 361 minecraft:stone
setblock 127 241 322 minecraft:andesite
setblock 128 241 361 minecraft:stripped_spruce_log
setblock 128 241 364 minecraft:andesite
setblock 129 241 360 minecraft:stripped_spruce_log
fill 129 241 361 129 244 361 minecraft:stone
setblock 130 241 360 minecraft:stone
setblock 130 241 364 minecraft:andesite
fill 131 241 340 131 241 342 minecraft:stone
setblock 132 241 337 minecraft:stripped_spruce_log
fill 132 241 338 132 242 338 minecraft:stone
setblock 132 241 341 minecraft:stone
setblock 132 241 342 minecraft:stripped_spruce_log
fill 132 241 343 132 244 343 minecraft:stone
setblock 132 241 346 minecraft:stone
setblock 133 241 336 minecraft:stripped_spruce_log
fill 133 241 337 133 243 337 minecraft:stone
setblock 133 241 341 minecraft:stripped_spruce_log
fill 133 241 342 133 244 342 minecraft:stone
setblock 133 241 346 minecraft:stripped_spruce_log
fill 133 241 347 133 244 347 minecraft:stone
setblock 133 241 357 minecraft:stone
setblock 133 241 361 minecraft:stripped_spruce_log
fill 134 241 325 135 241 342 minecraft:spruce_planks
fill 134 241 344 135 241 361 minecraft:spruce_planks
setblock 135 241 324 minecraft:spruce_planks
setblock 135 241 343 minecraft:spruce_planks
setblock 135 241 362 minecraft:spruce_planks
setblock 136 241 325 minecraft:andesite
fill 136 241 355 136 244 355 minecraft:andesite
setblock 136 241 358 minecraft:raw_gold_block
fill 136 241 362 136 242 362 minecraft:andesite
fill 94 242 322 94 242 323 minecraft:stone
fill 94 242 325 94 243 330 minecraft:stone
fill 94 242 333 94 246 334 minecraft:stone
fill 94 242 336 94 242 338 minecraft:stone
setblock 94 242 339 minecraft:gold_block
fill 94 242 340 94 242 360 minecraft:stone
fill 94 242 362 95 242 362 minecraft:stone
fill 95 242 322 106 243 322 minecraft:stone
setblock 95 242 323 minecraft:stripped_spruce_log
fill 95 242 324 95 242 327 minecraft:stone
setblock 95 242 328 minecraft:stripped_spruce_log
fill 95 242 329 95 242 332 minecraft:stone
setblock 95 242 333 minecraft:stripped_spruce_log
fill 95 242 334 95 242 337 minecraft:stone
setblock 95 242 338 minecraft:stripped_spruce_log
fill 95 242 339 95 242 342 minecraft:stone
setblock 95 242 343 minecraft:stripped_spruce_log
fill 95 242 344 95 242 347 minecraft:stone
setblock 95 242 348 minecraft:stripped_spruce_log
setblock 95 242 358 minecraft:stripped_spruce_log
fill 95 242 359 95 242 361 minecraft:stone
setblock 95 242 363 minecraft:stripped_spruce_log
fill 95 242 364 109 242 364 minecraft:stone
fill 96 242 323 96 243 325 minecraft:stone
fill 96 242 334 96 242 336 minecraft:stone
setblock 96 242 337 minecraft:stripped_spruce_log
fill 96 242 338 96 242 341 minecraft:stone
setblock 96 242 342 minecraft:stripped_spruce_log
fill 96 242 343 96 243 344 minecraft:stone
fill 96 242 363 99 242 363 minecraft:stone
fill 97 242 323 98 242 324 minecraft:stone
setblock 97 242 325 minecraft:light[level=15]
setblock 97 242 333 minecraft:light[level=15]
setblock 97 242 341 minecraft:light[level=15]
setblock 97 242 349 minecraft:light[level=15]
setblock 97 242 357 minecraft:light[level=15]
setblock 99 242 323 minecraft:stone
setblock 100 242 323 minecraft:stripped_spruce_log
fill 100 242 324 103 242 324 minecraft:stone
setblock 100 242 363 minecraft:stripped_spruce_log
fill 101 242 323 104 242 323 minecraft:stone
fill 101 242 363 104 242 363 minecraft:stone
fill 102 242 344 103 242 344 minecraft:raw_gold_block
fill 102 242 362 105 242 362 minecraft:stone
setblock 104 242 324 minecraft:stripped_spruce_log
setblock 105 242 323 minecraft:stripped_spruce_log
fill 105 242 324 108 242 324 minecraft:stone
setblock 105 242 325 minecraft:light[level=15]
setblock 105 242 341 minecraft:light[level=15]
setblock 105 242 349 minecraft:light[level=15]
setblock 105 242 357 minecraft:light[level=15]
fill 105 242 361 106 242 361 minecraft:stone
setblock 105 242 363 minecraft:stripped_spruce_log
fill 106 242 323 109 242 323 minecraft:stone
fill 106 242 325 107 242 325 minecraft:stone
setblock 106 242 362 minecraft:stripped_spruce_log
fill 106 242 363 109 242 363 minecraft:stone
fill 107 242 359 107 246 359 minecraft:stripped_spruce_log
setblock 107 242 361 minecraft:stripped_spruce_log
fill 107 242 362 110 242 362 minecraft:stone
fill 108 242 322 112 242 322 minecraft:stone
setblock 108 242 325 minecraft:stripped_spruce_log
fill 108 242 358 108 246 358 minecraft:stripped_spruce_log
fill 108 242 360 108 246 360 minecraft:stripped_spruce_log
fill 108 242 361 108 245 361 minecraft:stone
setblock 109 242 324 minecraft:stripped_spruce_log
fill 109 242 325 109 245 325 minecraft:stone
fill 109 242 359 109 246 359 minecraft:stripped_spruce_log
fill 109 242 360 109 243 360 minecraft:stone
setblock 110 242 323 minecraft:stripped_spruce_log
fill 110 242 324 113 242 324 minecraft:stone
setblock 110 242 363 minecraft:stripped_spruce_log
fill 111 242 323 114 242 323 minecraft:stone
setblock 111 242 362 minecraft:stripped_spruce_log
fill 111 242 363 114 242 364 minecraft:stone
setblock 112 242 325 minecraft:stone
setblock 112 242 361 minecraft:stripped_spruce_log
fill 112 242 362 115 242 362 minecraft:stone
setblock 113 242 325 minecraft:light[level=15]
setblock 113 242 333 minecraft:light[level=15]
setblock 113 242 341 minecraft:light[level=15]
setblock 113 242 349 minecraft:light[level=15]
setblock 113 242 357 minecraft:light[level=15]
setblock 113 242 360 minecraft:stripped_spruce_log
fill 113 242 361 113 245 361 minecraft:stone
setblock 114 242 324 minecraft:stripped_spruce_log
setblock 114 242 360 minecraft:stone
fill 115 242 322 124 242 322 minecraft:stone
setblock 115 242 323 minecraft:stripped_spruce_log
fill 115 242 324 116 242 324 minecraft:stone
setblock 115 242 363 minecraft:stripped_spruce_log
fill 115 242 364 116 242 364 minecraft:stone
fill 116 242 323 119 242 323 minecraft:stone
setblock 116 242 362 minecraft:stripped_spruce_log
fill 116 242 363 119 242 363 minecraft:stone
setblock 117 242 361 minecraft:stripped_spruce_log
fill 117 242 362 120 242 362 minecraft:stone
setblock 117 242 364 minecraft:andesite
setblock 118 242 361 minecraft:stone
fill 118 242 364 118 308 364 minecraft:stone
setblock 120 242 323 minecraft:stripped_spruce_log
setblock 120 242 363 minecraft:stripped_spruce_log
fill 120 242 364 123 243 364 minecraft:stone
setblock 121 242 325 minecraft:light[level=15]
setblock 121 242 333 minecraft:light[level=15]
setblock 121 242 341 minecraft:light[level=15]
setblock 121 242 349 minecraft:light[level=15]
setblock 121 242 357 minecraft:light[level=15]
setblock 121 242 362 minecraft:stripped_spruce_log
fill 121 242 363 124 242 363 minecraft:stone
fill 122 242 362 125 242 362 minecraft:stone
fill 123 242 323 124 242 323 minecraft:stone
fill 124 242 361 126 242 361 minecraft:stone
setblock 124 242 364 minecraft:andesite
setblock 125 242 323 minecraft:stripped_spruce_log
setblock 125 242 363 minecraft:stripped_spruce_log
fill 125 242 364 128 242 364 minecraft:stone
fill 126 242 322 128 243 323 minecraft:stone
setblock 126 242 362 minecraft:stripped_spruce_log
fill 126 242 363 129 242 363 minecraft:stone
setblock 127 242 361 minecraft:stripped_spruce_log
fill 127 242 362 130 242 362 minecraft:stone
fill 128 242 361 128 244 361 minecraft:stone
setblock 129 242 322 minecraft:gold_block
setblock 129 242 323 minecraft:stone
setblock 129 242 324 minecraft:stripped_spruce_log
setblock 129 242 325 minecraft:light[level=15]
setblock 129 242 333 minecraft:light[level=15]
setblock 129 242 341 minecraft:light[level=15]
setblock 129 242 349 minecraft:light[level=15]
setblock 129 242 357 minecraft:light[level=15]
fill 130 242 322 133 242 322 minecraft:stone
setblock 130 242 323 minecraft:stripped_spruce_log
fill 130 242 324 133 242 324 minecraft:stone
setblock 130 242 363 minecraft:stripped_spruce_log
setblock 130 242 364 minecraft:stone
fill 131 242 323 134 242 323 minecraft:stone
setblock 131 242 341 minecraft:stone
setblock 131 242 342 minecraft:stripped_spruce_log
setblock 131 242 362 minecraft:stripped_spruce_log
fill 131 242 363 134 242 363 minecraft:stone
setblock 132 242 341 minecraft:stripped_spruce_log
fill 132 242 342 132 245 342 minecraft:stone
setblock 132 242 346 minecraft:stripped_spruce_log
setblock 132 242 361 minecraft:stripped_spruce_log
fill 132 242 362 135 242 362 minecraft:stone
fill 132 242 364 136 242 364 minecraft:stone
setblock 133 242 335 minecraft:stripped_spruce_log
fill 133 242 336 136 242 336 minecraft:stone
setblock 133 242 340 minecraft:stripped_spruce_log
fill 133 242 341 135 243 341 minecraft:stone
setblock 133 242 345 minecraft:stripped_spruce_log
fill 133 242 346 136 243 346 minecraft:stone
fill 133 242 361 136 242 361 minecraft:stone
setblock 134 242 333 minecraft:stone
setblock 134 242 334 minecraft:stripped_spruce_log
fill 134 242 335 136 243 335 minecraft:stone
fill 134 242 337 134 242 338 minecraft:stone
setblock 134 242 339 minecraft:stripped_spruce_log
fill 134 242 340 136 242 340 minecraft:stone
fill 134 242 342 134 242 343 minecraft:stone
setblock 134 242 344 minecraft:stripped_spruce_log
fill 134 242 345 136 244 345 minecraft:stone
fill 134 242 347 134 242 348 minecraft:stone
setblock 134 242 349 minecraft:stripped_spruce_log
fill 134 242 350 136 242 350 minecraft:stone
fill 134 242 357 134 242 358 minecraft:stone
setblock 134 242 359 minecraft:stripped_spruce_log
fill 134 242 360 136 242 360 minecraft:stone
fill 135 242 322 136 283 322 minecraft:stone
setblock 135 242 323 minecraft:stripped_spruce_log
fill 135 242 324 135 242 327 minecraft:stone
fill 135 242 330 135 242 332 minecraft:stone
setblock 135 242 333 minecraft:stripped_spruce_log
fill 135 242 334 136 244 334 minecraft:stone
fill 135 242 337 136 242 337 minecraft:stone
setblock 135 242 338 minecraft:stripped_spruce_log
fill 135 242 339 136 245 339 minecraft:stone
fill 135 242 342 136 242 342 minecraft:stone
setblock 135 242 343 minecraft:stripped_spruce_log
fill 135 242 344 136 245 344 minecraft:stone
fill 135 242 347 136 242 347 minecraft:stone
setblock 135 242 348 minecraft:stripped_spruce_log
fill 135 242 349 136 245 349 minecraft:stone
fill 135 242 351 136 242 352 minecraft:stone
setblock 135 242 353 minecraft:stripped_spruce_log
fill 135 242 354 135 242 357 minecraft:stone
setblock 135 242 358 minecraft:stripped_spruce_log
fill 135 242 359 136 243 359 minecraft:stone
setblock 135 242 363 minecraft:stripped_spruce_log
fill 136 242 323 136 246 326 minecraft:stone
setblock 136 242 327 minecraft:andesite
fill 136 242 328 136 243 330 minecraft:stone
setblock 136 242 332 minecraft:raw_gold_block
setblock 136 242 333 minecraft:stone
fill 136 242 338 136 255 338 minecraft:stone
fill 136 242 343 136 257 343 minecraft:stone
fill 136 242 348 136 248 348 minecraft:stone
fill 136 242 353 136 242 354 minecraft:stone
fill 136 242 356 136 266 356 minecraft:stone
setblock 136 242 358 minecraft:andesite
fill 136 242 363 136 254 363 minecraft:stone
setblock 94 243 322 minecraft:andesite
fill 94 243 323 95 245 324 minecraft:stone
fill 94 243 331 95 243 331 minecraft:stone
setblock 94 243 332 minecraft:raw_iron_block
fill 94 243 336 94 308 337 minecraft:stone
setblock 94 243 338 minecraft:andesite
fill 94 243 339 94 243 347 minecraft:stone
setblock 94 243 348 minecraft:raw_gold_block
fill 94 243 349 94 243 364 minecraft:stone
fill 95 243 325 95 243 326 minecraft:stone
setblock 95 243 327 minecraft:stripped_spruce_log
fill 95 243 328 95 244 330 minecraft:stone
setblock 95 243 332 minecraft:stripped_spruce_log
fill 95 243 333 95 243 336 minecraft:stone
setblock 95 243 337 minecraft:stripped_spruce_log
fill 95 243 338 95 243 341 minecraft:stone
setblock 95 243 342 minecraft:stripped_spruce_log
fill 95 243 343 95 243 346 minecraft:stone
setblock 95 243 347 minecraft:stripped_spruce_log
fill 95 243 360 95 243 361 minecraft:stone
setblock 95 243 362 minecraft:stripped_spruce_log
fill 95 243 363 98 243 364 minecraft:stone
setblock 96 243 336 minecraft:stripped_spruce_log
fill 96 243 337 96 243 340 minecraft:stone
setblock 96 243 341 minecraft:stripped_spruce_log
fill 96 243 342 96 244 342 minecraft:stone
fill 97 243 323 97 243 324 minecraft:stone
setblock 98 243 323 minecraft:stone
setblock 98 243 324 minecraft:stripped_spruce_log
setblock 99 243 323 minecraft:stripped_spruce_log
fill 99 243 324 102 243 324 minecraft:stone
setblock 99 243 363 minecraft:stripped_spruce_log
fill 99 243 364 99 308 364 minecraft:stone
fill 100 243 323 103 243 323 minecraft:stone
fill 100 243 363 103 243 363 minecraft:stone
setblock 100 243 364 minecraft:andesite
fill 101 243 364 102 263 364 minecraft:stone
fill 102 243 362 104 243 362 minecraft:stone
setblock 103 243 324 minecraft:stripped_spruce_log
fill 103 243 344 103 245 344 minecraft:raw_gold_block
setblock 103 243 364 minecraft:andesite
setblock 104 243 323 minecraft:stripped_spruce_log
fill 104 243 324 107 243 324 minecraft:stone
setblock 104 243 363 minecraft:stripped_spruce_log
fill 104 243 364 107 244 364 minecraft:stone
fill 105 243 323 108 243 323 minecraft:stone
fill 105 243 325 106 243 325 minecraft:stone
setblock 105 243 361 minecraft:stone
setblock 105 243 362 minecraft:stripped_spruce_log
fill 105 243 363 108 243 363 minecraft:stone
setblock 106 243 361 minecraft:stripped_spruce_log
fill 106 243 362 109 243 362 minecraft:stone
fill 107 243 322 109 253 322 minecraft:stone
setblock 107 243 325 minecraft:stripped_spruce_log
fill 107 243 361 107 246 361 minecraft:stone
setblock 108 243 324 minecraft:stripped_spruce_log
fill 108 243 325 108 246 325 minecraft:stone
setblock 108 243 364 minecraft:andesite
setblock 109 243 323 minecraft:stripped_spruce_log
fill 109 243 324 112 243 324 minecraft:stone
setblock 109 243 363 minecraft:stripped_spruce_log
fill 109 243 364 115 243 364 minecraft:stone
setblock 110 243 322 minecraft:andesite
fill 110 243 323 113 243 323 minecraft:stone
setblock 110 243 362 minecraft:stripped_spruce_log
fill 110 243 363 113 243 363 minecraft:stone
fill 111 243 322 114 308 322 minecraft:stone
setblock 111 243 361 minecraft:stripped_spruce_log
fill 111 243 362 114 243 362 minecraft:stone
setblock 112 243 325 minecraft:stripped_spruce_log
setblock 112 243 360 minecraft:stripped_spruce_log
fill 112 243 361 112 245 361 minecraft:stone
setblock 113 243 324 minecraft:stripped_spruce_log
setblock 114 243 323 minecraft:stripped_spruce_log
fill 114 243 324 115 243 324 minecraft:stone
setblock 114 243 363 minecraft:stripped_spruce_log
setblock 115 243 322 minecraft:andesite
fill 115 243 323 118 243 323 minecraft:stone
setblock 115 243 362 minecraft:stripped_spruce_log
fill 115 243 363 118 243 363 minecraft:stone
fill 116 243 322 122 243 322 minecraft:stone
setblock 116 243 361 minecraft:stripped_spruce_log
fill 116 243 362 119 243 362 minecraft:stone
setblock 116 243 364 minecraft:andesite
fill 117 243 364 117 282 364 minecraft:stone
setblock 119 243 323 minecraft:stripped_spruce_log
setblock 119 243 363 minecraft:stripped_spruce_log
fill 119 243 364 119 269 364 minecraft:stone
setblock 120 243 362 minecraft:stripped_spruce_log
fill 120 243 363 123 243 363 minecraft:stone
fill 121 243 362 124 243 362 minecraft:stone
setblock 123 243 322 minecraft:andesite
setblock 123 243 323 minecraft:stone
fill 124 243 322 125 264 322 minecraft:stone
setblock 124 243 323 minecraft:stripped_spruce_log
setblock 124 243 363 minecraft:stripped_spruce_log
fill 124 243 364 127 249 364 minecraft:stone
fill 125 243 323 125 246 323 minecraft:stone
setblock 125 243 361 minecraft:stone
setblock 125 243 362 minecraft:stripped_spruce_log
fill 125 243 363 128 243 363 minecraft:stone
setblock 126 243 361 minecraft:stripped_spruce_log
fill 126 243 362 129 243 362 minecraft:stone
fill 127 243 361 127 244 361 minecraft:stone
setblock 128 243 324 minecraft:stripped_spruce_log
setblock 128 243 364 minecraft:diamond_block
fill 129 243 322 129 258 322 minecraft:stone
setblock 129 243 323 minecraft:stripped_spruce_log
fill 129 243 324 132 243 324 minecraft:stone
setblock 129 243 363 minecraft:stripped_spruce_log
fill 129 243 364 129 300 364 minecraft:stone
setblock 130 243 322 minecraft:andesite
fill 130 243 323 133 243 323 minecraft:stone
setblock 130 243 362 minecraft:stripped_spruce_log
fill 130 243 363 133 243 363 minecraft:stone
setblock 130 243 364 minecraft:andesite
fill 131 243 322 133 270 322 minecraft:stone
setblock 131 243 361 minecraft:stripped_spruce_log
fill 131 243 362 134 243 362 minecraft:stone
fill 131 243 364 132 255 364 minecraft:stone
setblock 132 243 340 minecraft:stripped_spruce_log
fill 132 243 341 132 244 341 minecraft:stone
setblock 132 243 344 minecraft:stone
setblock 132 243 345 minecraft:stripped_spruce_log
setblock 132 243 346 minecraft:stone
setblock 133 243 339 minecraft:stripped_spruce_log
fill 133 243 340 135 244 340 minecraft:stone
setblock 133 243 344 minecraft:stripped_spruce_log
fill 133 243 345 133 246 345 minecraft:stone
setblock 133 243 364 minecraft:raw_gold_block
setblock 134 243 323 minecraft:stripped_spruce_log
fill 134 243 336 134 243 337 minecraft:stone
setblock 134 243 338 minecraft:stripped_spruce_log
fill 134 243 339 134 246 339 minecraft:stone
setblock 134 243 342 minecraft:stone
setblock 134 243 343 minecraft:stripped_spruce_log
fill 134 243 344 134 246 344 minecraft:stone
setblock 134 243 347 minecraft:stone
setblock 134 243 348 minecraft:stripped_spruce_log
setblock 134 243 349 minecraft:stone
fill 134 243 361 136 243 361 minecraft:stone
setblock 134 243 363 minecraft:stripped_spruce_log
fill 134 243 364 136 285 364 minecraft:stone
fill 135 243 323 135 243 326 minecraft:stone
setblock 135 243 332 minecraft:stripped_spruce_log
setblock 135 243 333 minecraft:stone
fill 135 243 336 136 243 336 minecraft:stone
setblock 135 243 337 minecraft:stripped_spruce_log
fill 135 243 338 135 246 338 minecraft:stone
setblock 135 243 342 minecraft:stripped_spruce_log
fill 135 243 343 135 246 343 minecraft:stone
setblock 135 243 347 minecraft:stripped_spruce_log
fill 135 243 348 135 246 348 minecraft:stone
fill 135 243 350 136 243 351 minecraft:stone
fill 135 243 358 136 243 358 minecraft:stone
fill 135 243 360 136 243 360 minecraft:stone
setblock 135 243 362 minecraft:stripped_spruce_log
fill 135 243 363 135 244 363 minecraft:stone
setblock 136 243 327 minecraft:stone
fill 136 243 331 136 297 332 minecraft:stone
setblock 136 243 333 minecraft:andesite
fill 136 243 337 136 244 337 minecraft:stone
setblock 136 243 340 minecraft:andesite
fill 136 243 341 136 308 341 minecraft:stone
fill 136 243 342 136 244 342 minecraft:andesite
setblock 136 243 347 minecraft:stone
fill 136 243 352 136 257 353 minecraft:stone
setblock 136 243 354 minecraft:raw_iron_block
fill 136 243 357 136 308 357 minecraft:stone
setblock 136 243 362 minecraft:stone
fill 94 244 322 104 251 322 minecraft:stone
setblock 94 244 325 minecraft:raw_gold_block
fill 94 244 326 94 268 326 minecraft:stone
setblock 94 244 327 minecraft:andesite
fill 94 244 328 94 253 332 minecraft:stone
fill 94 244 335 95 244 335 minecraft:stone
fill 94 244 338 95 245 338 minecraft:stone
setblock 94 244 339 minecraft:raw_gold_block
fill 94 244 340 94 249 352 minecraft:stone
fill 94 244 353 94 244 354 minecraft:andesite
fill 94 244 355 94 246 364 minecraft:stone
setblock 95 244 325 minecraft:stone
setblock 95 244 326 minecraft:stripped_spruce_log
fill 95 244 327 95 247 327 minecraft:stone
setblock 95 244 331 minecraft:stripped_spruce_log
fill 95 244 332 95 244 334 minecraft:stone
setblock 95 244 336 minecraft:stripped_spruce_log
fill 95 244 337 95 245 337 minecraft:stone
fill 95 244 339 95 244 340 minecraft:stone
setblock 95 244 341 minecraft:stripped_spruce_log
fill 95 244 342 95 244 345 minecraft:stone
setblock 95 244 346 minecraft:stripped_spruce_log
setblock 95 244 347 minecraft:stone
fill 95 244 362 95 244 364 minecraft:stone
fill 96 244 323 96 244 324 minecraft:stone
setblock 96 244 339 minecraft:stone
setblock 96 244 340 minecraft:stripped_spruce_log
setblock 96 244 341 minecraft:stone
fill 96 244 363 97 244 364 minecraft:stone
setblock 97 244 323 minecraft:stone
setblock 97 244 324 minecraft:stripped_spruce_log
fill 97 244 346 97 251 346 minecraft:cobbled_deepslate
setblock 98 244 323 minecraft:stripped_spruce_log
setblock 98 244 363 minecraft:stripped_spruce_log
fill 98 244 364 98 298 364 minecraft:stone
fill 99 244 323 101 244 324 minecraft:stone
fill 99 244 363 102 244 363 minecraft:stone
fill 100 244 364 100 308 364 minecraft:stone
setblock 102 244 323 minecraft:stone
setblock 102 244 324 minecraft:stripped_spruce_log
setblock 103 244 323 minecraft:stripped_spruce_log
fill 103 244 324 106 244 324 minecraft:stone
setblock 103 244 362 minecraft:stone
setblock 103 244 363 minecraft:stripped_spruce_log
fill 103 244 364 103 246 364 minecraft:stone
fill 104 244 323 107 244 323 minecraft:stone
setblock 104 244 362 minecraft:stripped_spruce_log
fill 104 244 363 107 244 363 minecraft:stone
setblock 105 244 322 minecraft:diamond_block
setblock 105 244 325 minecraft:stone
fill 105 244 362 108 244 362 minecraft:stone
fill 106 244 322 106 251 322 minecraft:stone
setblock 106 244 325 minecraft:stripped_spruce_log
fill 106 244 361 106 246 361 minecraft:stone
setblock 107 244 324 minecraft:stripped_spruce_log
fill 107 244 325 107 247 325 minecraft:stone
fill 107 244 358 107 246 358 minecraft:stripped_spruce_log
fill 107 244 360 107 246 360 minecraft:stripped_spruce_log
setblock 108 244 323 minecraft:stripped_spruce_log
fill 108 244 324 111 244 324 minecraft:stone
setblock 108 244 363 minecraft:stripped_spruce_log
fill 108 244 364 109 274 364 minecraft:stone
fill 109 244 323 112 244 323 minecraft:stone
fill 109 244 358 109 246 358 minecraft:stripped_spruce_log
fill 109 244 360 109 246 360 minecraft:stripped_spruce_log
setblock 109 244 362 minecraft:stripped_spruce_log
fill 109 244 363 112 244 363 minecraft:stone
fill 110 244 322 110 308 322 minecraft:stone
setblock 110 244 361 minecraft:stripped_spruce_log
fill 110 244 362 113 244 362 minecraft:stone
setblock 110 244 364 minecraft:andesite
setblock 111 244 325 minecraft:stripped_spruce_log
fill 111 244 361 111 246 361 minecraft:stone
fill 111 244 364 112 253 364 minecraft:stone
setblock 112 244 324 minecraft:stripped_spruce_log
setblock 113 244 323 minecraft:stripped_spruce_log
fill 113 244 324 114 245 324 minecraft:stone
fill 113 244 339 113 267 339 minecraft:stripped_spruce_log
setblock 113 244 363 minecraft:stripped_spruce_log
fill 113 244 364 114 244 364 minecraft:andesite
fill 114 244 323 117 244 323 minecraft:stone
setblock 114 244 362 minecraft:stripped_spruce_log
fill 114 244 363 117 244 363 minecraft:stone
fill 115 244 322 117 250 322 minecraft:stone
setblock 115 244 361 minecraft:stripped_spruce_log
fill 115 244 362 118 244 362 minecraft:stone
fill 115 244 364 116 250 364 minecraft:stone
setblock 118 244 322 minecraft:andesite
setblock 118 244 323 minecraft:stripped_spruce_log
setblock 118 244 363 minecraft:stripped_spruce_log
fill 119 244 322 123 268 322 minecraft:stone
setblock 119 244 362 minecraft:stripped_spruce_log
fill 119 244 363 122 244 363 minecraft:stone
fill 120 244 362 123 244 362 minecraft:stone
setblock 120 244 364 minecraft:andesite
fill 121 244 364 122 256 364 minecraft:stone
setblock 123 244 323 minecraft:stripped_spruce_log
setblock 123 244 363 minecraft:stripped_spruce_log
setblock 123 244 364 minecraft:andesite
fill 124 244 323 124 247 323 minecraft:stone
setblock 124 244 362 minecraft:stripped_spruce_log
fill 124 244 363 127 244 363 minecraft:stone
fill 125 244 362 128 244 362 minecraft:stone
fill 126 244 322 127 244 322 minecraft:andesite
fill 126 244 323 127 244 323 minecraft:stone
fill 128 244 322 128 265 322 minecraft:stone
setblock 128 244 323 minecraft:stripped_spruce_log
fill 128 244 324 131 244 324 minecraft:stone
setblock 128 244 363 minecraft:stripped_spruce_log
setblock 128 244 364 minecraft:andesite
fill 129 244 323 132 244 323 minecraft:stone
setblock 129 244 362 minecraft:stripped_spruce_log
fill 129 244 363 132 244 363 minecraft:stone
fill 130 244 322 130 261 322 minecraft:stone
fill 130 244 360 130 251 360 minecraft:stripped_spruce_log
fill 130 244 362 133 244 362 minecraft:stone
setblock 130 244 364 minecraft:stone
setblock 132 244 324 minecraft:stripped_spruce_log
setblock 132 244 340 minecraft:stone
setblock 132 244 344 minecraft:stripped_spruce_log
setblock 132 244 345 minecraft:stone
setblock 133 244 323 minecraft:stripped_spruce_log
setblock 133 244 338 minecraft:stripped_spruce_log
fill 133 244 339 133 245 339 minecraft:stone
fill 133 244 341 134 244 341 minecraft:stone
setblock 133 244 343 minecraft:stripped_spruce_log
fill 133 244 344 133 247 344 minecraft:stone
fill 133 244 346 134 244 346 minecraft:stone
setblock 133 244 363 minecraft:stripped_spruce_log
setblock 133 244 364 minecraft:andesite
fill 134 244 322 134 247 323 minecraft:stone
setblock 134 244 336 minecraft:stone
setblock 134 244 337 minecraft:stripped_spruce_log
fill 134 244 338 134 245 338 minecraft:stone
setblock 134 244 342 minecraft:stripped_spruce_log
fill 134 244 343 134 247 343 minecraft:stone
setblock 134 244 347 minecraft:stripped_spruce_log
fill 134 244 348 134 245 348 minecraft:stone
fill 134 244 363 134 245 363 minecraft:stone
fill 135 244 323 135 244 325 minecraft:stone
setblock 135 244 326 minecraft:stripped_spruce_log
setblock 135 244 335 minecraft:stone
setblock 135 244 336 minecraft:stripped_spruce_log
fill 135 244 337 135 246 337 minecraft:stone
setblock 135 244 341 minecraft:stripped_spruce_log
fill 135 244 342 135 247 342 minecraft:stone
setblock 135 244 346 minecraft:stripped_spruce_log
fill 135 244 347 135 247 347 minecraft:stone
fill 135 244 350 136 244 350 minecraft:stone
setblock 135 244 361 minecraft:stripped_spruce_log
setblock 135 244 362 minecraft:stone
setblock 136 244 327 minecraft:andesite
setblock 136 244 328 minecraft:raw_gold_block
fill 136 244 329 136 297 330 minecraft:stone
fill 136 244 333 136 308 333 minecraft:stone
setblock 136 244 335 minecraft:raw_iron_block
fill 136 244 336 136 308 336 minecraft:stone
fill 136 244 340 136 248 340 minecraft:stone
fill 136 244 346 136 308 346 minecraft:stone
setblock 136 244 347 minecraft:andesite
fill 136 244 351 136 247 351 minecraft:stone
fill 136 244 354 136 273 354 minecraft:stone
fill 136 244 358 136 270 361 minecraft:stone
setblock 136 244 362 minecraft:andesite
fill 94 245 325 94 283 325 minecraft:stone
fill 94 245 327 94 289 327 minecraft:stone
fill 94 245 335 94 308 335 minecraft:stone
fill 94 245 339 95 245 339 minecraft:stone
fill 94 245 353 94 245 354 minecraft:stone
setblock 95 245 325 minecraft:stripped_spruce_log
fill 95 245 326 95 248 326 minecraft:stone
fill 95 245 328 95 245 329 minecraft:stone
setblock 95 245 336 minecraft:stone
setblock 95 245 340 minecraft:stripped_spruce_log
fill 95 245 341 95 245 344 minecraft:stone
setblock 95 245 345 minecraft:stripped_spruce_log
setblock 95 245 346 minecraft:stone
fill 95 245 363 95 245 364 minecraft:stone
setblock 96 245 323 minecraft:stone
setblock 96 245 324 minecraft:stripped_spruce_log
fill 96 245 364 97 308 364 minecraft:stone
setblock 97 245 323 minecraft:stripped_spruce_log
fill 98 245 323 101 245 323 minecraft:stone
fill 99 245 324 100 245 324 minecraft:stone
fill 99 245 363 101 245 363 minecraft:stone
setblock 101 245 324 minecraft:stripped_spruce_log
setblock 102 245 323 minecraft:stripped_spruce_log
fill 102 245 324 105 245 324 minecraft:stone
setblock 102 245 363 minecraft:stripped_spruce_log
fill 103 245 323 106 245 323 minecraft:stone
setblock 103 245 362 minecraft:stripped_spruce_log
fill 103 245 363 106 245 363 minecraft:stone
setblock 104 245 325 minecraft:stone
fill 104 245 362 107 245 362 minecraft:stone
fill 104 245 364 106 254 364 minecraft:stone
fill 105 245 322 105 277 322 minecraft:stone
setblock 105 245 325 minecraft:stripped_spruce_log
setblock 106 245 324 minecraft:stripped_spruce_log
fill 106 245 325 106 248 325 minecraft:stone
setblock 107 245 323 minecraft:stripped_spruce_log
fill 107 245 324 110 245 324 minecraft:stone
setblock 107 245 363 minecraft:stripped_spruce_log
setblock 107 245 364 minecraft:gold_block
fill 108 245 323 111 245 323 minecraft:stone
setblock 108 245 362 minecraft:stripped_spruce_log
fill 108 245 363 111 245 363 minecraft:stone
setblock 109 245 361 minecraft:stripped_spruce_log
fill 109 245 362 112 245 362 minecraft:stone
setblock 110 245 325 minecraft:stripped_spruce_log
fill 110 245 361 110 246 361 minecraft:stone
fill 110 245 364 110 308 364 minecraft:stone
setblock 111 245 324 minecraft:stripped_spruce_log
setblock 111 245 325 minecraft:stone
setblock 112 245 323 minecraft:stripped_spruce_log
fill 112 245 324 112 248 324 minecraft:stone
setblock 112 245 363 minecraft:stripped_spruce_log
fill 113 245 323 116 245 323 minecraft:stone
setblock 113 245 362 minecraft:stripped_spruce_log
fill 113 245 363 114 247 364 minecraft:stone
fill 114 245 362 117 245 362 minecraft:stone
fill 115 245 363 116 245 363 minecraft:stone
setblock 117 245 323 minecraft:stripped_spruce_log
setblock 117 245 363 minecraft:stripped_spruce_log
fill 118 245 322 118 269 322 minecraft:stone
fill 118 245 363 121 245 363 minecraft:stone
fill 120 245 364 120 266 364 minecraft:stone
setblock 122 245 363 minecraft:stripped_spruce_log
fill 123 245 323 123 248 323 minecraft:stone
setblock 123 245 362 minecraft:stripped_spruce_log
fill 123 245 363 123 248 364 minecraft:stone
fill 124 245 362 126 245 363 minecraft:stone
fill 126 245 322 126 245 323 minecraft:stone
fill 127 245 322 127 308 322 minecraft:stone
setblock 127 245 323 minecraft:stripped_spruce_log
setblock 127 245 362 minecraft:stone
setblock 127 245 363 minecraft:stripped_spruce_log
fill 128 245 323 130 245 324 minecraft:stone
setblock 128 245 362 minecraft:stripped_spruce_log
fill 128 245 363 128 248 364 minecraft:stone
fill 129 245 362 131 245 363 minecraft:stone
setblock 130 245 364 minecraft:diamond_block
setblock 131 245 323 minecraft:stone
setblock 131 245 324 minecraft:stripped_spruce_log
setblock 132 245 323 minecraft:stripped_spruce_log
setblock 132 245 343 minecraft:stripped_spruce_log
setblock 132 245 344 minecraft:stone
setblock 132 245 363 minecraft:stripped_spruce_log
fill 133 245 323 133 248 323 minecraft:stone
fill 133 245 340 133 245 341 minecraft:stone
setblock 133 245 342 minecraft:stripped_spruce_log
fill 133 245 343 133 246 343 minecraft:stone
setblock 133 245 346 minecraft:stone
fill 133 245 363 133 246 364 minecraft:stone
setblock 134 245 337 minecraft:stone
setblock 134 245 340 minecraft:stone
setblock 134 245 341 minecraft:stripped_spruce_log
fill 134 245 342 134 248 342 minecraft:stone
setblock 134 245 345 minecraft:stone
setblock 134 245 346 minecraft:stripped_spruce_log
fill 134 245 347 134 247 347 minecraft:stone
fill 135 245 323 135 245 324 minecraft:stone
setblock 135 245 325 minecraft:stripped_spruce_log
setblock 135 245 335 minecraft:stripped_spruce_log
setblock 135 245 336 minecraft:stone
setblock 135 245 340 minecraft:stripped_spruce_log
fill 135 245 341 135 248 341 minecraft:stone
setblock 135 245 345 minecraft:stripped_spruce_log
fill 135 245 346 135 248 346 minecraft:stone
fill 136 245 327 136 272 328 minecraft:stone
fill 136 245 334 136 245 335 minecraft:stone
setblock 136 245 337 minecraft:gold_block
fill 136 245 342 136 275 342 minecraft:stone
fill 136 245 345 136 305 345 minecraft:stone
fill 136 245 347 136 308 347 minecraft:stone
fill 136 245 350 136 254 350 minecraft:stone
fill 136 245 355 136 304 355 minecraft:stone
fill 136 245 362 136 247 362 minecraft:stone
fill 94 246 323 94 278 324 minecraft:stone
fill 94 246 338 94 264 339 minecraft:stone
fill 94 246 353 94 308 353 minecraft:stone
setblock 94 246 354 minecraft:raw_iron_block
setblock 95 246 323 minecraft:stone
setblock 95 246 324 minecraft:stripped_spruce_log
fill 95 246 325 95 249 325 minecraft:stone
setblock 95 246 328 minecraft:stone
setblock 95 246 329 minecraft:stripped_spruce_log
setblock 95 246 339 minecraft:stripped_spruce_log
fill 95 246 340 95 246 343 minecraft:stone
setblock 95 246 344 minecraft:stripped_spruce_log
setblock 95 246 345 minecraft:stone
fill 95 246 364 95 264 364 minecraft:stone
setblock 96 246 323 minecraft:stripped_spruce_log
fill 97 246 323 100 246 323 minecraft:stone
setblock 97 246 325 minecraft:light[level=12]
setblock 97 246 332 minecraft:light[level=12]
setblock 97 246 339 minecraft:light[level=12]
setblock 97 246 353 minecraft:light[level=12]
setblock 97 246 360 minecraft:light[level=12]
setblock 99 246 324 minecraft:stone
setblock 100 246 324 minecraft:stripped_spruce_log
setblock 100 246 363 minecraft:stone
setblock 101 246 323 minecraft:stripped_spruce_log
fill 101 246 324 104 246 324 minecraft:stone
setblock 101 246 363 minecraft:stripped_spruce_log
fill 102 246 323 105 246 323 minecraft:stone
fill 102 246 363 105 246 363 minecraft:stone
setblock 103 246 325 minecraft:stone
fill 103 246 362 106 246 362 minecraft:stone
setblock 104 246 325 minecraft:stripped_spruce_log
setblock 104 246 332 minecraft:light[level=12]
setblock 104 246 339 minecraft:light[level=12]
setblock 104 246 346 minecraft:light[level=12]
setblock 104 246 353 minecraft:light[level=12]
setblock 104 246 360 minecraft:light[level=12]
setblock 105 246 324 minecraft:stripped_spruce_log
fill 105 246 325 105 249 325 minecraft:stone
setblock 106 246 323 minecraft:stripped_spruce_log
fill 106 246 324 109 246 324 minecraft:stone
setblock 106 246 359 minecraft:stripped_spruce_log
setblock 106 246 363 minecraft:stripped_spruce_log
fill 107 246 323 110 246 323 minecraft:stone
setblock 107 246 362 minecraft:stripped_spruce_log
fill 107 246 363 107 249 364 minecraft:stone
setblock 108 246 357 minecraft:stripped_spruce_log
setblock 108 246 361 minecraft:stripped_spruce_log
fill 108 246 362 110 246 363 minecraft:stone
setblock 109 246 325 minecraft:stripped_spruce_log
fill 109 246 361 109 247 361 minecraft:stone
setblock 110 246 324 minecraft:stripped_spruce_log
fill 110 246 325 110 247 325 minecraft:stone
setblock 110 246 359 minecraft:stripped_spruce_log
setblock 111 246 323 minecraft:stripped_spruce_log
fill 111 246 324 111 249 324 minecraft:stone
setblock 111 246 325 minecraft:light[level=12]
setblock 111 246 332 minecraft:light[level=12]
setblock 111 246 339 minecraft:light[level=12]
setblock 111 246 346 minecraft:light[level=12]
setblock 111 246 353 minecraft:light[level=12]
setblock 111 246 360 minecraft:light[level=12]
setblock 111 246 362 minecraft:stone
setblock 111 246 363 minecraft:stripped_spruce_log
fill 112 246 323 115 246 323 minecraft:stone
setblock 112 246 362 minecraft:stripped_spruce_log
fill 112 246 363 112 249 363 minecraft:stone
setblock 113 246 324 minecraft:stone
fill 113 246 362 115 246 362 minecraft:stone
setblock 115 246 363 minecraft:stone
setblock 116 246 323 minecraft:stripped_spruce_log
setblock 116 246 363 minecraft:stripped_spruce_log
fill 117 246 363 120 246 363 minecraft:stone
setblock 118 246 325 minecraft:light[level=12]
setblock 118 246 332 minecraft:light[level=12]
setblock 118 246 339 minecraft:light[level=12]
setblock 118 246 346 minecraft:light[level=12]
setblock 118 246 353 minecraft:light[level=12]
setblock 118 246 360 minecraft:light[level=12]
setblock 121 246 363 minecraft:stripped_spruce_log
fill 122 246 363 122 249 363 minecraft:stone
fill 124 246 362 125 246 363 minecraft:stone
setblock 125 246 325 minecraft:light[level=12]
setblock 125 246 332 minecraft:light[level=12]
setblock 125 246 339 minecraft:light[level=12]
setblock 125 246 346 minecraft:light[level=12]
setblock 125 246 353 minecraft:light[level=12]
setblock 125 246 360 minecraft:light[level=12]
fill 126 246 322 126 263 322 minecraft:stone
setblock 126 246 323 minecraft:stripped_spruce_log
setblock 126 246 362 minecraft:stone
setblock 126 246 363 minecraft:stripped_spruce_log
fill 127 246 323 129 246 324 minecraft:stone
setblock 127 246 362 minecraft:stripped_spruce_log
fill 127 246 363 127 249 363 minecraft:stone
fill 128 246 362 129 246 362 minecraft:stone
fill 129 246 363 130 246 363 minecraft:stone
setblock 130 246 323 minecraft:stone
setblock 130 246 324 minecraft:stripped_spruce_log
fill 130 246 364 130 290 364 minecraft:stone
setblock 131 246 323 minecraft:stripped_spruce_log
setblock 131 246 363 minecraft:stripped_spruce_log
fill 132 246 323 132 249 323 minecraft:stone
setblock 132 246 325 minecraft:light[level=12]
setblock 132 246 332 minecraft:light[level=12]
setblock 132 246 339 minecraft:light[level=12]
setblock 132 246 346 minecraft:light[level=12]
setblock 132 246 353 minecraft:light[level=12]
setblock 132 246 360 minecraft:light[level=12]
setblock 132 246 363 minecraft:stone
setblock 133 246 341 minecraft:stripped_spruce_log
setblock 133 246 342 minecraft:stone
setblock 133 246 346 minecraft:stripped_spruce_log
setblock 134 246 340 minecraft:stripped_spruce_log
fill 134 246 341 134 247 341 minecraft:stone
setblock 134 246 345 minecraft:stripped_spruce_log
fill 134 246 346 134 249 346 minecraft:stone
setblock 135 246 323 minecraft:stone
setblock 135 246 324 minecraft:stripped_spruce_log
fill 135 246 325 135 249 325 minecraft:stone
setblock 135 246 339 minecraft:stripped_spruce_log
fill 135 246 340 135 249 340 minecraft:stone
setblock 135 246 344 minecraft:stripped_spruce_log
fill 135 246 345 135 249 345 minecraft:stone
setblock 136 246 334 minecraft:raw_iron_block
fill 136 246 335 136 308 335 minecraft:stone
fill 136 246 337 136 257 337 minecraft:stone
fill 136 246 339 136 252 339 minecraft:stone
fill 136 246 344 136 297 344 minecraft:stone
fill 136 246 349 136 290 349 minecraft:stone
setblock 94 247 333 minecraft:raw_gold_block
fill 94 247 334 94 265 334 minecraft:stone
fill 94 247 354 94 258 357 minecraft:stone
setblock 94 247 358 minecraft:gold_block
fill 94 247 359 94 250 364 minecraft:stone
setblock 95 247 323 minecraft:stripped_spruce_log
fill 95 247 324 95 250 324 minecraft:stone
setblock 95 247 328 minecraft:stripped_spruce_log
fill 95 247 329 95 250 329 minecraft:stone
setblock 95 247 342 minecraft:stone
setblock 95 247 343 minecraft:stripped_spruce_log
setblock 95 247 344 minecraft:stone
fill 96 247 323 99 247 323 minecraft:stone
fill 96 247 346 96 251 346 minecraft:cobbled_deepslate
fill 97 247 345 97 253 345 minecraft:cobbled_deepslate
fill 97 247 347 97 251 347 minecraft:cobbled_deepslate
setblock 98 247 324 minecraft:stone
fill 98 247 346 98 251 346 minecraft:cobbled_deepslate
setblock 99 247 324 minecraft:stripped_spruce_log
setblock 100 247 323 minecraft:stripped_spruce_log
fill 100 247 324 103 247 324 minecraft:stone
setblock 100 247 363 minecraft:stripped_spruce_log
fill 101 247 323 104 247 323 minecraft:stone
fill 101 247 363 104 247 363 minecraft:stone
setblock 103 247 325 minecraft:stripped_spruce_log
fill 103 247 362 105 247 362 minecraft:stone
setblock 103 247 364 minecraft:gold_block
setblock 104 247 324 minecraft:stripped_spruce_log
fill 104 247 325 104 250 325 minecraft:stone
setblock 105 247 323 minecraft:stripped_spruce_log
fill 105 247 324 108 247 324 minecraft:stone
setblock 105 247 363 minecraft:stripped_spruce_log
fill 106 247 323 109 247 323 minecraft:stone
setblock 106 247 362 minecraft:stripped_spruce_log
fill 106 247 363 106 250 363 minecraft:stone
setblock 107 247 361 minecraft:stripped_spruce_log
fill 107 247 362 110 247 362 minecraft:stone
setblock 108 247 325 minecraft:stripped_spruce_log
setblock 108 247 361 minecraft:stone
fill 108 247 363 109 247 363 minecraft:stone
setblock 109 247 324 minecraft:stripped_spruce_log
fill 109 247 325 109 250 325 minecraft:stone
setblock 110 247 323 minecraft:stripped_spruce_log
fill 110 247 324 110 250 324 minecraft:stone
setblock 110 247 363 minecraft:stripped_spruce_log
fill 111 247 323 114 247 323 minecraft:stone
setblock 111 247 362 minecraft:stripped_spruce_log
fill 111 247 363 111 250 363 minecraft:stone
fill 112 247 339 112 267 339 minecraft:stripped_spruce_log
fill 112 247 362 113 247 362 minecraft:stone
setblock 115 247 323 minecraft:stripped_spruce_log
setblock 115 247 363 minecraft:stripped_spruce_log
fill 116 247 363 119 247 363 minecraft:stone
setblock 120 247 363 minecraft:stripped_spruce_log
fill 121 247 363 121 250 363 minecraft:stone
fill 122 247 323 122 249 323 minecraft:stone
setblock 124 247 363 minecraft:stone
setblock 125 247 323 minecraft:stripped_spruce_log
setblock 125 247 363 minecraft:stripped_spruce_log
fill 126 247 323 129 247 323 minecraft:stone
setblock 126 247 362 minecraft:stripped_spruce_log
fill 126 247 363 126 250 363 minecraft:stone
fill 127 247 324 128 247 324 minecraft:stone
setblock 127 247 362 minecraft:stone
setblock 129 247 324 minecraft:stripped_spruce_log
setblock 129 247 363 minecraft:stone
setblock 130 247 323 minecraft:stripped_spruce_log
fill 130 247 324 130 250 324 minecraft:stone
setblock 130 247 363 minecraft:stripped_spruce_log
fill 131 247 323 131 250 323 minecraft:stone
setblock 131 247 363 minecraft:stone
fill 133 247 364 133 275 364 minecraft:stone
setblock 134 247 340 minecraft:stone
setblock 134 247 344 minecraft:stripped_spruce_log
fill 134 247 345 134 250 345 minecraft:stone
fill 135 247 324 135 250 324 minecraft:stone
setblock 135 247 338 minecraft:stripped_spruce_log
fill 135 247 339 135 248 339 minecraft:stone
setblock 135 247 343 minecraft:stripped_spruce_log
fill 135 247 344 135 250 344 minecraft:stone
setblock 135 247 348 minecraft:stripped_spruce_log
fill 136 247 323 136 308 323 minecraft:stone
setblock 136 247 324 minecraft:gold_block
fill 136 247 325 136 254 326 minecraft:stone
fill 136 247 334 136 308 334 minecraft:stone
fill 94 248 333 94 308 333 minecraft:stone
fill 94 248 358 94 250 358 minecraft:stone
fill 95 248 323 98 248 323 minecraft:stone
setblock 95 248 327 minecraft:stripped_spruce_log
fill 95 248 328 95 251 328 minecraft:stone
fill 96 248 324 97 248 324 minecraft:stone
setblock 98 248 324 minecraft:stripped_spruce_log
setblock 99 248 323 minecraft:stripped_spruce_log
fill 99 248 324 102 248 324 minecraft:stone
fill 100 248 323 103 248 323 minecraft:stone
fill 100 248 363 103 248 363 minecraft:stone
setblock 102 248 325 minecraft:stripped_spruce_log
setblock 103 248 324 minecraft:stripped_spruce_log
fill 103 248 325 103 251 325 minecraft:stone
fill 103 248 362 104 248 362 minecraft:stone
fill 103 248 364 103 308 364 minecraft:stone
setblock 104 248 323 minecraft:stripped_spruce_log
fill 104 248 324 107 248 324 minecraft:stone
setblock 104 248 363 minecraft:stripped_spruce_log
fill 105 248 323 108 248 323 minecraft:stone
setblock 105 248 362 minecraft:stripped_spruce_log
fill 105 248 363 105 251 363 minecraft:stone
fill 106 248 362 109 248 362 minecraft:stone
setblock 107 248 325 minecraft:stripped_spruce_log
setblock 108 248 324 minecraft:stripped_spruce_log
fill 108 248 325 108 251 325 minecraft:stone
setblock 108 248 363 minecraft:stone
setblock 109 248 323 minecraft:stripped_spruce_log
fill 109 248 324 109 251 324 minecraft:stone
setblock 109 248 363 minecraft:stripped_spruce_log
fill 110 248 323 113 248 323 minecraft:stone
setblock 110 248 362 minecraft:stripped_spruce_log
fill 110 248 363 110 251 363 minecraft:stone
fill 111 248 362 112 248 362 minecraft:stone
fill 113 248 363 113 248 364 minecraft:stone
setblock 114 248 323 minecraft:stripped_spruce_log
setblock 114 248 363 minecraft:stripped_spruce_log
fill 114 248 364 114 292 364 minecraft:stone
setblock 115 248 323 minecraft:stone
fill 115 248 363 117 248 363 minecraft:stone
setblock 119 248 363 minecraft:stripped_spruce_log
fill 120 248 363 120 251 363 minecraft:stone
setblock 124 248 323 minecraft:stripped_spruce_log
setblock 124 248 363 minecraft:stripped_spruce_log
fill 125 248 323 128 248 323 minecraft:stone
fill 125 248 363 125 251 363 minecraft:stone
fill 126 248 324 127 248 324 minecraft:stone
setblock 128 248 324 minecraft:stripped_spruce_log
setblock 129 248 323 minecraft:stripped_spruce_log
fill 129 248 324 129 251 324 minecraft:stone
setblock 129 248 363 minecraft:stripped_spruce_log
fill 130 248 323 130 251 323 minecraft:stone
setblock 130 248 363 minecraft:stone
fill 134 248 322 134 263 322 minecraft:stone
setblock 134 248 323 minecraft:stripped_spruce_log
setblock 134 248 343 minecraft:stripped_spruce_log
fill 134 248 344 134 249 344 minecraft:stone
setblock 135 248 326 minecraft:stone
setblock 135 248 327 minecraft:stripped_spruce_log
setblock 135 248 342 minecraft:stripped_spruce_log
fill 135 248 343 135 251 343 minecraft:stone
setblock 135 248 347 minecraft:stripped_spruce_log
fill 135 248 348 135 251 348 minecraft:stone
fill 136 248 324 136 251 324 minecraft:stone
setblock 136 248 351 minecraft:raw_gold_block
setblock 136 248 362 minecraft:raw_iron_block
fill 95 249 323 97 249 323 minecraft:stone
setblock 95 249 326 minecraft:stripped_spruce_log
fill 95 249 327 95 252 327 minecraft:stone
setblock 95 249 330 minecraft:stone
setblock 96 249 324 minecraft:stone
setblock 96 249 325 minecraft:stripped_spruce_log
fill 96 249 326 96 252 326 minecraft:stone
fill 96 249 345 96 251 345 minecraft:cobbled_deepslate
fill 96 249 347 96 251 347 minecraft:cobbled_deepslate
setblock 97 249 324 minecraft:stripped_spruce_log
setblock 98 249 323 minecraft:stripped_spruce_log
fill 98 249 324 101 249 324 minecraft:stone
fill 98 249 345 98 252 345 minecraft:cobbled_deepslate
fill 98 249 347 98 251 347 minecraft:cobbled_deepslate
fill 99 249 323 102 249 323 minecraft:stone
fill 100 249 363 102 249 363 minecraft:stone
setblock 101 249 325 minecraft:stripped_spruce_log
setblock 102 249 324 minecraft:stripped_spruce_log
fill 102 249 325 102 252 325 minecraft:stone
setblock 103 249 323 minecraft:stripped_spruce_log
fill 103 249 324 106 249 324 minecraft:stone
setblock 103 249 362 minecraft:stone
setblock 103 249 363 minecraft:stripped_spruce_log
fill 104 249 323 107 249 323 minecraft:stone
setblock 104 249 362 minecraft:stripped_spruce_log
fill 104 249 363 104 252 363 minecraft:stone
fill 105 249 362 108 249 362 minecraft:stone
setblock 106 249 325 minecraft:stripped_spruce_log
setblock 107 249 324 minecraft:stripped_spruce_log
fill 107 249 325 107 252 325 minecraft:stone
setblock 108 249 323 minecraft:stripped_spruce_log
fill 108 249 324 108 252 324 minecraft:stone
setblock 108 249 363 minecraft:stripped_spruce_log
fill 109 249 323 112 249 323 minecraft:stone
setblock 109 249 362 minecraft:stripped_spruce_log
fill 109 249 363 109 252 363 minecraft:stone
fill 110 249 362 111 250 362 minecraft:stone
setblock 112 249 324 minecraft:stripped_spruce_log
setblock 113 249 323 minecraft:stripped_spruce_log
setblock 113 249 363 minecraft:stripped_spruce_log
fill 113 249 364 113 304 364 minecraft:stone
fill 114 249 323 114 250 323 minecraft:stone
fill 114 249 363 115 250 363 minecraft:stone
fill 116 249 356 116 250 356 minecraft:raw_gold_block
fill 121 249 323 121 250 323 minecraft:stone
setblock 123 249 323 minecraft:stripped_spruce_log
setblock 123 249 363 minecraft:stripped_spruce_log
fill 123 249 364 123 280 364 minecraft:stone
fill 124 249 323 127 249 323 minecraft:stone
fill 124 249 363 124 252 363 minecraft:stone
fill 125 249 324 126 249 324 minecraft:stone
setblock 127 249 324 minecraft:stripped_spruce_log
setblock 128 249 323 minecraft:stripped_spruce_log
fill 128 249 324 128 252 324 minecraft:stone
setblock 128 249 363 minecraft:stripped_spruce_log
fill 128 249 364 128 308 364 minecraft:stone
fill 129 249 323 129 252 323 minecraft:stone
fill 129 249 360 129 251 360 minecraft:stripped_spruce_log
fill 129 249 363 129 250 363 minecraft:stone
fill 130 249 359 130 251 359 minecraft:stripped_spruce_log
fill 130 249 361 130 251 361 minecraft:stripped_spruce_log
fill 131 249 336 131 255 336 minecraft:cobbled_deepslate
fill 131 249 360 131 250 360 minecraft:stripped_spruce_log
setblock 133 249 323 minecraft:stripped_spruce_log
fill 134 249 323 134 252 323 minecraft:stone
setblock 134 249 343 minecraft:stone
setblock 135 249 326 minecraft:stripped_spruce_log
fill 135 249 327 135 250 329 minecraft:stone
setblock 135 249 341 minecraft:stripped_spruce_log
fill 135 249 342 135 252 342 minecraft:stone
setblock 135 249 346 minecraft:stripped_spruce_log
fill 135 249 347 135 252 347 minecraft:stone
setblock 136 249 340 minecraft:raw_iron_block
setblock 136 249 348 minecraft:diamond_block
fill 136 249 351 136 263 351 minecraft:stone
fill 136 249 362 136 259 362 minecraft:stone
fill 94 250 340 94 278 342 minecraft:stone
setblock 94 250 343 minecraft:gold_block
fill 94 250 344 94 255 352 minecraft:stone
fill 95 250 323 96 250 323 minecraft:stone
setblock 95 250 325 minecraft:stripped_spruce_log
fill 95 250 326 95 253 326 minecraft:stone
setblock 95 250 330 minecraft:stripped_spruce_log
fill 95 250 331 95 253 331 minecraft:stone
fill 95 250 336 97 251 336 minecraft:iron_bars
setblock 96 250 324 minecraft:stripped_spruce_log
fill 96 250 325 96 253 325 minecraft:stone
fill 96 250 327 96 250 328 minecraft:stone
setblock 97 250 323 minecraft:stripped_spruce_log
fill 97 250 324 100 250 324 minecraft:stone
setblock 97 250 325 minecraft:light[level=15]
setblock 97 250 333 minecraft:light[level=15]
setblock 97 250 341 minecraft:light[level=15]
setblock 97 250 349 minecraft:light[level=15]
setblock 97 250 357 minecraft:light[level=15]
fill 98 250 323 101 250 323 minecraft:stone
fill 99 250 363 101 250 363 minecraft:stone
setblock 100 250 325 minecraft:stripped_spruce_log
setblock 101 250 324 minecraft:stripped_spruce_log
fill 101 250 325 101 253 325 minecraft:stone
setblock 102 250 323 minecraft:stripped_spruce_log
fill 102 250 324 105 250 324 minecraft:stone
setblock 102 250 362 minecraft:stone
setblock 102 250 363 minecraft:stripped_spruce_log
fill 103 250 323 106 250 323 minecraft:stone
setblock 103 250 362 minecraft:stripped_spruce_log
fill 103 250 363 103 253 363 minecraft:stone
setblock 104 250 326 minecraft:stripped_spruce_log
fill 104 250 362 107 250 362 minecraft:stone
setblock 105 250 325 minecraft:stripped_spruce_log
fill 105 250 326 105 253 326 minecraft:stone
setblock 105 250 341 minecraft:light[level=15]
setblock 105 250 349 minecraft:light[level=15]
setblock 105 250 357 minecraft:light[level=15]
setblock 106 250 324 minecraft:stripped_spruce_log
fill 106 250 325 106 253 325 minecraft:stone
setblock 107 250 323 minecraft:stripped_spruce_log
fill 107 250 324 107 253 324 minecraft:stone
setblock 107 250 363 minecraft:stripped_spruce_log
fill 107 250 364 107 308 364 minecraft:stone
fill 108 250 323 111 250 323 minecraft:stone
setblock 108 250 362 minecraft:stripped_spruce_log
fill 108 250 363 108 253 363 minecraft:stone
fill 109 250 362 109 253 362 minecraft:stone
setblock 111 250 324 minecraft:stripped_spruce_log
setblock 112 250 323 minecraft:stripped_spruce_log
setblock 112 250 363 minecraft:stripped_spruce_log
fill 113 250 323 113 252 323 minecraft:stone
setblock 113 250 325 minecraft:light[level=15]
setblock 113 250 333 minecraft:light[level=15]
setblock 113 250 341 minecraft:light[level=15]
setblock 113 250 349 minecraft:light[level=15]
setblock 113 250 357 minecraft:light[level=15]
fill 113 250 363 113 253 363 minecraft:stone
setblock 121 250 325 minecraft:light[level=15]
setblock 121 250 333 minecraft:light[level=15]
setblock 121 250 341 minecraft:light[level=15]
setblock 121 250 349 minecraft:light[level=15]
setblock 121 250 357 minecraft:light[level=15]
setblock 122 250 323 minecraft:stripped_spruce_log
setblock 122 250 363 minecraft:stripped_spruce_log
fill 123 250 323 126 250 323 minecraft:stone
fill 123 250 363 123 253 363 minecraft:stone
fill 124 250 324 125 250 324 minecraft:stone
fill 124 250 364 124 308 364 minecraft:stone
setblock 125 250 364 minecraft:raw_gold_block
setblock 126 250 324 minecraft:stripped_spruce_log
fill 126 250 364 127 275 364 minecraft:stone
setblock 127 250 323 minecraft:stripped_spruce_log
fill 127 250 324 127 253 324 minecraft:stone
setblock 127 250 363 minecraft:stripped_spruce_log
fill 128 250 323 128 253 323 minecraft:stone
fill 128 250 363 128 251 363 minecraft:stone
setblock 129 250 325 minecraft:light[level=15]
setblock 129 250 333 minecraft:light[level=15]
setblock 129 250 341 minecraft:light[level=15]
setblock 129 250 349 minecraft:light[level=15]
setblock 129 250 357 minecraft:light[level=15]
setblock 132 250 323 minecraft:stripped_spruce_log
fill 132 250 333 132 255 333 minecraft:iron_bars
fill 133 250 323 133 253 323 minecraft:stone
setblock 134 250 346 minecraft:stripped_spruce_log
fill 135 250 323 135 251 323 minecraft:stone
setblock 135 250 325 minecraft:stripped_spruce_log
fill 135 250 326 135 253 326 minecraft:stone
setblock 135 250 330 minecraft:stripped_spruce_log
fill 135 250 341 135 251 341 minecraft:stone
setblock 135 250 345 minecraft:stripped_spruce_log
fill 135 250 346 135 253 346 minecraft:stone
setblock 135 250 349 minecraft:stone
fill 136 250 340 136 295 340 minecraft:stone
fill 136 250 348 136 265 348 minecraft:stone
fill 94 251 343 94 257 343 minecraft:stone
setblock 94 251 358 minecraft:diamond_block
fill 94 251 359 94 262 361 minecraft:stone
setblock 94 251 362 minecraft:raw_gold_block
fill 94 251 363 94 299 364 minecraft:stone
setblock 95 251 323 minecraft:stone
setblock 95 251 324 minecraft:stripped_spruce_log
fill 95 251 325 95 254 325 minecraft:stone
setblock 95 251 329 minecraft:stripped_spruce_log
fill 95 251 330 95 254 330 minecraft:stone
fill 95 251 332 95 252 332 minecraft:stone
setblock 95 251 346 minecraft:cobbled_deepslate
setblock 96 251 323 minecraft:stripped_spruce_log
fill 96 251 324 96 254 324 minecraft:spruce_log
setblock 96 251 327 minecraft:stone
setblock 96 251 328 minecraft:stripped_spruce_log
fill 96 251 329 96 254 329 minecraft:stone
fill 96 251 343 96 254 343 minecraft:spruce_log
fill 96 251 362 96 254 362 minecraft:spruce_log
fill 97 251 323 99 251 324 minecraft:stone
setblock 97 251 344 minecraft:cobbled_deepslate
setblock 97 251 348 minecraft:cobbled_deepslate
setblock 98 251 325 minecraft:stone
fill 98 251 326 98 252 326 minecraft:cobbled_deepslate
fill 98 251 328 98 252 328 minecraft:cobbled_deepslate
fill 98 251 353 98 252 353 minecraft:cobbled_deepslate
fill 98 251 363 100 251 363 minecraft:stone
setblock 99 251 325 minecraft:stripped_spruce_log
setblock 99 251 346 minecraft:cobbled_deepslate
setblock 100 251 323 minecraft:stone
setblock 100 251 324 minecraft:stripped_spruce_log
fill 100 251 325 100 254 325 minecraft:stone
setblock 101 251 323 minecraft:stripped_spruce_log
fill 101 251 324 104 251 324 minecraft:stone
setblock 101 251 363 minecraft:stripped_spruce_log
fill 102 251 323 105 251 323 minecraft:stone
setblock 102 251 326 minecraft:stone
setblock 102 251 362 minecraft:stripped_spruce_log
fill 102 251 363 102 254 363 minecraft:stone
setblock 103 251 326 minecraft:stripped_spruce_log
fill 103 251 362 106 251 362 minecraft:stone
setblock 104 251 325 minecraft:stripped_spruce_log
fill 104 251 326 104 254 326 minecraft:stone
setblock 105 251 324 minecraft:stripped_spruce_log
fill 105 251 325 105 254 325 minecraft:stone
setblock 106 251 323 minecraft:stripped_spruce_log
fill 106 251 324 106 254 324 minecraft:stone
fill 106 251 326 106 252 326 minecraft:stone
setblock 106 251 363 minecraft:stripped_spruce_log
fill 107 251 323 110 251 323 minecraft:stone
setblock 107 251 362 minecraft:stripped_spruce_log
fill 107 251 363 107 254 363 minecraft:stone
fill 108 251 362 108 254 362 minecraft:stone
setblock 109 251 325 minecraft:stripped_spruce_log
setblock 110 251 324 minecraft:stripped_spruce_log
fill 110 251 362 110 252 362 minecraft:stone
setblock 111 251 323 minecraft:stripped_spruce_log
fill 111 251 324 111 252 324 minecraft:stone
setblock 111 251 363 minecraft:stripped_spruce_log
fill 112 251 323 112 253 323 minecraft:stone
fill 112 251 363 112 254 363 minecraft:stone
setblock 114 251 363 minecraft:stone
fill 115 251 322 115 263 322 minecraft:stone
fill 115 251 324 115 254 324 minecraft:spruce_log
fill 115 251 362 115 254 362 minecraft:spruce_log
setblock 115 251 364 minecraft:diamond_block
setblock 116 251 322 minecraft:gold_block
fill 116 251 356 116 260 356 minecraft:cobbled_deepslate
fill 116 251 364 116 264 364 minecraft:stone
fill 117 251 322 117 299 322 minecraft:stone
setblock 120 251 323 minecraft:stone
setblock 121 251 323 minecraft:stripped_spruce_log
setblock 121 251 363 minecraft:stripped_spruce_log
fill 122 251 323 125 251 323 minecraft:stone
fill 122 251 363 122 254 363 minecraft:stone
fill 123 251 324 124 251 324 minecraft:stone
setblock 125 251 324 minecraft:stripped_spruce_log
fill 125 251 364 125 273 364 minecraft:stone
setblock 126 251 323 minecraft:stripped_spruce_log
fill 126 251 324 126 254 324 minecraft:stone
setblock 126 251 363 minecraft:stripped_spruce_log
fill 127 251 323 127 254 323 minecraft:stone
fill 127 251 363 127 253 363 minecraft:stone
setblock 129 251 359 minecraft:stripped_spruce_log
setblock 129 251 361 minecraft:stripped_spruce_log
setblock 130 251 324 minecraft:stripped_spruce_log
setblock 131 251 323 minecraft:stripped_spruce_log
fill 131 251 345 131 252 346 minecraft:cobbled_deepslate
fill 131 251 354 131 252 354 minecraft:cobbled_deepslate
setblock 131 251 359 minecraft:stripped_spruce_log
fill 131 251 360 131 252 360 minecraft:cobbled_deepslate
setblock 131 251 361 minecraft:stripped_spruce_log
fill 132 251 323 132 254 323 minecraft:stone
fill 134 251 324 134 254 324 minecraft:spruce_log
fill 134 251 343 134 254 343 minecraft:spruce_log
fill 134 251 362 134 254 362 minecraft:spruce_log
setblock 135 251 324 minecraft:stripped_spruce_log
fill 135 251 325 135 254 325 minecraft:stone
fill 135 251 327 135 251 328 minecraft:stone
setblock 135 251 329 minecraft:stripped_spruce_log
fill 135 251 330 135 252 332 minecraft:stone
setblock 135 251 344 minecraft:stripped_spruce_log
fill 135 251 345 135 254 345 minecraft:stone
setblock 135 251 349 minecraft:stripped_spruce_log
fill 94 252 322 96 259 322 minecraft:stone
fill 94 252 358 94 308 358 minecraft:stone
fill 94 252 362 94 308 362 minecraft:stone
setblock 95 252 323 minecraft:stripped_spruce_log
fill 95 252 324 95 255 324 minecraft:stone
setblock 95 252 328 minecraft:stripped_spruce_log
fill 95 252 329 95 255 329 minecraft:stone
setblock 95 252 333 minecraft:stripped_spruce_log
fill 96 252 323 99 252 323 minecraft:stone
setblock 96 252 327 minecraft:stripped_spruce_log
fill 96 252 328 97 254 328 minecraft:stone
fill 96 252 330 96 253 330 minecraft:stone
setblock 97 252 322 minecraft:gold_block
fill 97 252 324 97 252 325 minecraft:stone
setblock 97 252 326 minecraft:stripped_spruce_log
fill 97 252 327 97 255 327 minecraft:stone
setblock 97 252 332 minecraft:light[level=12]
setblock 97 252 339 minecraft:light[level=12]
setblock 97 252 346 minecraft:light[level=12]
fill 97 252 353 97 253 353 minecraft:cobbled_deepslate
setblock 97 252 360 minecraft:light[level=12]
fill 98 252 322 104 263 322 minecraft:stone
setblock 98 252 324 minecraft:stone
setblock 98 252 325 minecraft:stripped_spruce_log
fill 98 252 363 99 252 363 minecraft:stone
setblock 99 252 324 minecraft:stripped_spruce_log
fill 99 252 325 99 255 325 minecraft:stone
setblock 100 252 323 minecraft:stripped_spruce_log
fill 100 252 324 103 252 324 minecraft:stone
setblock 100 252 363 minecraft:stripped_spruce_log
fill 101 252 323 104 252 323 minecraft:stone
setblock 101 252 326 minecraft:stone
setblock 101 252 362 minecraft:stripped_spruce_log
fill 101 252 363 101 255 363 minecraft:stone
setblock 102 252 326 minecraft:stripped_spruce_log
fill 102 252 362 105 252 362 minecraft:stone
setblock 103 252 325 minecraft:stripped_spruce_log
fill 103 252 326 103 255 326 minecraft:stone
setblock 104 252 324 minecraft:stripped_spruce_log
fill 104 252 325 104 255 325 minecraft:stone
setblock 104 252 332 minecraft:light[level=12]
setblock 104 252 339 minecraft:light[level=12]
setblock 104 252 346 minecraft:light[level=12]
setblock 104 252 353 minecraft:light[level=12]
setblock 104 252 360 minecraft:light[level=12]
setblock 105 252 323 minecraft:stripped_spruce_log
fill 105 252 324 105 255 324 minecraft:stone
setblock 105 252 363 minecraft:stripped_spruce_log
setblock 106 252 322 minecraft:diamond_block
fill 106 252 323 109 252 323 minecraft:stone
setblock 106 252 362 minecraft:stripped_spruce_log
fill 106 252 363 106 255 363 minecraft:stone
fill 107 252 362 107 255 362 minecraft:stone
setblock 108 252 325 minecraft:stripped_spruce_log
setblock 109 252 324 minecraft:stripped_spruce_log
setblock 110 252 323 minecraft:stripped_spruce_log
fill 110 252 324 110 253 324 minecraft:stone
setblock 110 252 363 minecraft:stripped_spruce_log
fill 111 252 323 111 254 323 minecraft:stone
setblock 111 252 325 minecraft:light[level=12]
setblock 111 252 332 minecraft:light[level=12]
setblock 111 252 339 minecraft:light[level=12]
setblock 111 252 346 minecraft:light[level=12]
setblock 111 252 353 minecraft:light[level=12]
setblock 111 252 360 minecraft:light[level=12]
fill 111 252 363 111 255 363 minecraft:stone
fill 115 252 364 115 259 364 minecraft:stone
fill 116 252 322 116 284 322 minecraft:stone
fill 117 252 356 117 260 356 minecraft:cobbled_deepslate
setblock 118 252 325 minecraft:light[level=12]
setblock 118 252 332 minecraft:light[level=12]
setblock 118 252 339 minecraft:light[level=12]
setblock 118 252 346 minecraft:light[level=12]
setblock 118 252 353 minecraft:light[level=12]
setblock 118 252 360 minecraft:light[level=12]
setblock 119 252 323 minecraft:stone
setblock 119 252 363 minecraft:stone
setblock 120 252 323 minecraft:stripped_spruce_log
setblock 120 252 363 minecraft:stripped_spruce_log
fill 121 252 323 124 252 323 minecraft:stone
fill 121 252 363 121 255 363 minecraft:stone
fill 122 252 324 123 252 324 minecraft:stone
setblock 124 252 324 minecraft:stripped_spruce_log
setblock 125 252 323 minecraft:stripped_spruce_log
fill 125 252 324 125 255 324 minecraft:stone
setblock 125 252 325 minecraft:light[level=12]
setblock 125 252 332 minecraft:light[level=12]
setblock 125 252 339 minecraft:light[level=12]
setblock 125 252 346 minecraft:light[level=12]
setblock 125 252 353 minecraft:light[level=12]
setblock 125 252 360 minecraft:light[level=12]
setblock 125 252 363 minecraft:stripped_spruce_log
fill 126 252 323 126 255 323 minecraft:stone
fill 126 252 363 126 254 363 minecraft:stone
setblock 129 252 324 minecraft:stripped_spruce_log
setblock 130 252 323 minecraft:stripped_spruce_log
fill 130 252 324 130 253 324 minecraft:stone
fill 130 252 336 130 255 336 minecraft:cobbled_deepslate
fill 131 252 323 131 255 323 minecraft:stone
fill 131 252 335 131 255 335 minecraft:cobbled_deepslate
fill 131 252 337 131 255 337 minecraft:cobbled_deepslate
setblock 132 252 325 minecraft:light[level=12]
setblock 132 252 332 minecraft:light[level=12]
fill 132 252 336 132 255 336 minecraft:cobbled_deepslate
setblock 132 252 339 minecraft:light[level=12]
fill 132 252 345 132 253 346 minecraft:cobbled_deepslate
setblock 132 252 353 minecraft:light[level=12]
fill 132 252 354 132 253 354 minecraft:cobbled_deepslate
fill 132 252 360 132 253 360 minecraft:cobbled_deepslate
fill 134 252 326 134 252 328 minecraft:stone
setblock 134 252 329 minecraft:stripped_spruce_log
fill 134 252 330 134 255 330 minecraft:stone
setblock 135 252 323 minecraft:stripped_spruce_log
fill 135 252 324 135 255 324 minecraft:stone
setblock 135 252 327 minecraft:stone
setblock 135 252 328 minecraft:stripped_spruce_log
fill 135 252 329 135 255 329 minecraft:stone
setblock 135 252 333 minecraft:stripped_spruce_log
fill 135 252 334 135 255 334 minecraft:stone
setblock 135 252 343 minecraft:stripped_spruce_log
fill 135 252 344 135 255 344 minecraft:stone
setblock 135 252 348 minecraft:stripped_spruce_log
fill 135 252 349 135 254 350 minecraft:stone
setblock 136 252 324 minecraft:raw_iron_block
fill 95 253 323 98 253 323 minecraft:stone
setblock 95 253 327 minecraft:stripped_spruce_log
fill 95 253 328 95 256 328 minecraft:stone
setblock 95 253 332 minecraft:stripped_spruce_log
fill 95 253 333 95 255 334 minecraft:stone
setblock 96 253 326 minecraft:stripped_spruce_log
fill 96 253 327 96 256 327 minecraft:stone
setblock 96 253 331 minecraft:stripped_spruce_log
fill 96 253 345 96 254 345 minecraft:cobbled_deepslate
fill 96 253 353 96 254 353 minecraft:cobbled_deepslate
fill 97 253 322 97 308 322 minecraft:stone
setblock 97 253 324 minecraft:stone
setblock 97 253 325 minecraft:stripped_spruce_log
fill 97 253 326 97 256 326 minecraft:stone
setblock 97 253 329 minecraft:stone
fill 97 253 363 98 253 363 minecraft:stone
setblock 98 253 324 minecraft:stripped_spruce_log
fill 98 253 325 98 256 325 minecraft:stone
setblock 99 253 323 minecraft:stripped_spruce_log
fill 99 253 324 102 253 324 minecraft:stone
setblock 99 253 363 minecraft:stripped_spruce_log
fill 100 253 323 103 253 323 minecraft:stone
setblock 100 253 326 minecraft:stone
setblock 100 253 362 minecraft:stripped_spruce_log
fill 100 253 363 100 256 363 minecraft:stone
setblock 101 253 326 minecraft:stripped_spruce_log
fill 101 253 362 104 253 362 minecraft:stone
setblock 102 253 325 minecraft:stripped_spruce_log
fill 102 253 326 102 256 326 minecraft:stone
setblock 103 253 324 minecraft:stripped_spruce_log
fill 103 253 325 103 256 325 minecraft:stone
setblock 104 253 323 minecraft:stripped_spruce_log
fill 104 253 324 104 256 324 minecraft:stone
fill 104 253 361 105 253 361 minecraft:stone
setblock 104 253 363 minecraft:stripped_spruce_log
fill 105 253 323 108 253 323 minecraft:stone
setblock 105 253 362 minecraft:stripped_spruce_log
fill 105 253 363 105 256 363 minecraft:stone
fill 106 253 322 106 273 322 minecraft:stone
setblock 106 253 326 minecraft:stripped_spruce_log
fill 106 253 362 106 256 362 minecraft:stone
setblock 107 253 325 minecraft:stripped_spruce_log
fill 107 253 357 108 254 361 minecraft:stripped_spruce_log
setblock 108 253 324 minecraft:stripped_spruce_log
setblock 108 253 325 minecraft:stone
fill 108 253 349 108 254 356 minecraft:stripped_spruce_log
setblock 109 253 323 minecraft:stripped_spruce_log
fill 109 253 324 109 254 324 minecraft:stone
fill 109 253 346 109 254 349 minecraft:stripped_spruce_log
setblock 109 253 363 minecraft:stripped_spruce_log
fill 110 253 323 110 255 323 minecraft:stone
fill 110 253 363 110 256 363 minecraft:stone
fill 116 253 357 117 260 357 minecraft:cobbled_deepslate
setblock 119 253 323 minecraft:stripped_spruce_log
setblock 119 253 363 minecraft:stripped_spruce_log
fill 120 253 323 123 253 323 minecraft:stone
fill 120 253 363 120 256 363 minecraft:stone
fill 121 253 324 122 253 324 minecraft:stone
setblock 123 253 324 minecraft:stripped_spruce_log
setblock 124 253 323 minecraft:stripped_spruce_log
fill 124 253 324 124 254 325 minecraft:stone
setblock 124 253 363 minecraft:stripped_spruce_log
fill 125 253 323 125 256 323 minecraft:stone
fill 125 253 325 126 253 325 minecraft:stone
fill 125 253 363 125 255 363 minecraft:stone
setblock 128 253 324 minecraft:stripped_spruce_log
setblock 129 253 323 minecraft:stripped_spruce_log
fill 129 253 324 129 254 324 minecraft:stone
fill 130 253 323 130 255 323 minecraft:stone
fill 133 253 345 133 254 346 minecraft:cobbled_deepslate
fill 133 253 354 133 254 354 minecraft:cobbled_deepslate
fill 133 253 360 133 254 360 minecraft:cobbled_deepslate
setblock 134 253 323 minecraft:stripped_spruce_log
fill 134 253 325 134 253 327 minecraft:stone
setblock 134 253 328 minecraft:stripped_spruce_log
fill 134 253 329 134 256 329 minecraft:stone
fill 134 253 331 134 253 332 minecraft:stone
fill 135 253 323 135 256 323 minecraft:stone
setblock 135 253 327 minecraft:stripped_spruce_log
fill 135 253 328 135 256 328 minecraft:stone
fill 135 253 330 135 253 331 minecraft:stone
setblock 135 253 332 minecraft:stripped_spruce_log
fill 135 253 333 135 256 333 minecraft:stone
fill 135 253 335 135 253 336 minecraft:stone
setblock 135 253 342 minecraft:stripped_spruce_log
fill 135 253 343 135 254 343 minecraft:stone
setblock 135 253 347 minecraft:stripped_spruce_log
fill 135 253 348 135 256 348 minecraft:stone
setblock 135 253 351 minecraft:stone
fill 136 253 324 136 295 324 minecraft:stone
setblock 136 253 339 minecraft:gold_block
fill 94 254 328 94 254 330 minecraft:stone
setblock 94 254 331 minecraft:gold_block
fill 94 254 332 96 256 332 minecraft:stone
fill 95 254 323 97 254 323 minecraft:stone
setblock 95 254 326 minecraft:stripped_spruce_log
fill 95 254 327 95 256 327 minecraft:stone
setblock 95 254 331 minecraft:stripped_spruce_log
fill 95 254 345 95 255 345 minecraft:cobbled_deepslate
fill 95 254 348 95 254 350 minecraft:stone
setblock 95 254 351 minecraft:stripped_spruce_log
setblock 95 254 353 minecraft:cobbled_deepslate
setblock 96 254 325 minecraft:stripped_spruce_log
fill 96 254 326 96 256 326 minecraft:stone
setblock 96 254 330 minecraft:stripped_spruce_log
fill 96 254 331 96 256 331 minecraft:stone
setblock 97 254 324 minecraft:stripped_spruce_log
fill 97 254 325 97 257 325 minecraft:stone
setblock 97 254 329 minecraft:stripped_spruce_log
fill 97 254 330 97 257 330 minecraft:stone
setblock 97 254 363 minecraft:stone
setblock 98 254 323 minecraft:stripped_spruce_log
fill 98 254 324 101 254 324 minecraft:stone
setblock 98 254 363 minecraft:stripped_spruce_log
fill 99 254 323 102 254 323 minecraft:stone
setblock 99 254 326 minecraft:stone
fill 99 254 363 99 256 363 minecraft:stone
setblock 100 254 326 minecraft:stripped_spruce_log
fill 100 254 362 103 254 362 minecraft:stone
setblock 101 254 325 minecraft:stripped_spruce_log
fill 101 254 326 101 256 326 minecraft:stone
setblock 102 254 324 minecraft:stripped_spruce_log
fill 102 254 325 102 257 325 minecraft:stone
setblock 103 254 323 minecraft:stripped_spruce_log
fill 103 254 324 103 256 324 minecraft:stone
fill 103 254 361 104 254 361 minecraft:stone
setblock 103 254 363 minecraft:stripped_spruce_log
fill 104 254 323 107 254 323 minecraft:stone
setblock 104 254 362 minecraft:stripped_spruce_log
fill 104 254 363 104 256 363 minecraft:stone
setblock 105 254 326 minecraft:stripped_spruce_log
setblock 105 254 361 minecraft:stripped_spruce_log
fill 105 254 362 105 256 362 minecraft:stone
setblock 106 254 325 minecraft:stripped_spruce_log
fill 107 254 322 108 262 322 minecraft:stone
setblock 107 254 324 minecraft:stripped_spruce_log
setblock 107 254 325 minecraft:stone
fill 107 254 355 107 254 356 minecraft:stripped_spruce_log
setblock 108 254 323 minecraft:stripped_spruce_log
fill 108 254 324 108 255 324 minecraft:stone
fill 108 254 344 108 254 348 minecraft:stripped_spruce_log
setblock 108 254 363 minecraft:stripped_spruce_log
setblock 109 254 322 minecraft:raw_iron_block
fill 109 254 323 109 256 323 minecraft:stone
fill 109 254 333 109 254 340 minecraft:stripped_spruce_log
fill 109 254 350 109 254 353 minecraft:stripped_spruce_log
setblock 109 254 362 minecraft:stripped_spruce_log
fill 109 254 363 109 256 363 minecraft:stone
fill 110 254 324 110 254 339 minecraft:stripped_spruce_log
fill 111 254 324 111 254 332 minecraft:stripped_spruce_log
fill 111 254 364 112 254 364 minecraft:diamond_block
fill 115 254 356 115 260 357 minecraft:cobbled_deepslate
fill 116 254 355 117 260 355 minecraft:cobbled_deepslate
setblock 118 254 323 minecraft:stripped_spruce_log
fill 118 254 356 118 260 356 minecraft:cobbled_deepslate
setblock 118 254 363 minecraft:stripped_spruce_log
fill 119 254 323 122 254 323 minecraft:stone
fill 119 254 363 119 256 363 minecraft:stone
setblock 121 254 324 minecraft:stone
setblock 122 254 324 minecraft:stripped_spruce_log
setblock 123 254 323 minecraft:stripped_spruce_log
fill 123 254 324 123 256 324 minecraft:stone
setblock 123 254 363 minecraft:stripped_spruce_log
fill 124 254 323 124 256 323 minecraft:stone
fill 124 254 363 124 256 363 minecraft:stone
setblock 125 254 325 minecraft:stone
setblock 127 254 324 minecraft:stripped_spruce_log
setblock 128 254 323 minecraft:stripped_spruce_log
setblock 128 254 324 minecraft:stone
fill 128 254 337 130 255 339 minecraft:iron_block
fill 129 254 323 129 255 323 minecraft:stone
fill 130 254 335 130 255 335 minecraft:cobbled_deepslate
fill 132 254 335 132 255 335 minecraft:cobbled_deepslate
fill 132 254 337 132 255 337 minecraft:cobbled_deepslate
setblock 133 254 323 minecraft:stripped_spruce_log
fill 134 254 323 134 256 323 minecraft:stone
fill 134 254 325 134 254 326 minecraft:stone
setblock 134 254 327 minecraft:stripped_spruce_log
fill 134 254 328 134 256 328 minecraft:stone
setblock 134 254 331 minecraft:stone
setblock 134 254 332 minecraft:stripped_spruce_log
fill 134 254 333 134 256 333 minecraft:stone
fill 134 254 345 134 255 346 minecraft:cobbled_deepslate
fill 134 254 354 134 255 354 minecraft:cobbled_deepslate
fill 134 254 360 134 255 360 minecraft:cobbled_deepslate
setblock 135 254 326 minecraft:stripped_spruce_log
fill 135 254 327 135 256 327 minecraft:stone
setblock 135 254 330 minecraft:stone
setblock 135 254 331 minecraft:stripped_spruce_log
fill 135 254 332 135 256 332 minecraft:stone
setblock 135 254 335 minecraft:stone
setblock 135 254 336 minecraft:stripped_spruce_log
fill 135 254 337 135 256 337 minecraft:stone
setblock 135 254 346 minecraft:stripped_spruce_log
fill 135 254 347 135 256 347 minecraft:stone
setblock 135 254 351 minecraft:stripped_spruce_log
fill 135 254 352 135 256 352 minecraft:stone
fill 136 254 339 136 289 339 minecraft:stone
setblock 94 255 328 minecraft:gold_block
fill 94 255 329 94 275 330 minecraft:stone
setblock 94 255 331 minecraft:diamond_block
fill 95 255 323 96 255 323 minecraft:stone
setblock 95 255 325 minecraft:stripped_spruce_log
fill 95 255 326 95 256 326 minecraft:stone
setblock 95 255 330 minecraft:stripped_spruce_log
fill 95 255 331 95 256 331 minecraft:stone
setblock 95 255 335 minecraft:stripped_spruce_log
fill 95 255 348 95 255 349 minecraft:stone
setblock 95 255 350 minecraft:stripped_spruce_log
fill 95 255 351 95 256 353 minecraft:stone
setblock 96 255 324 minecraft:glowstone
fill 96 255 325 96 256 325 minecraft:stone
setblock 96 255 328 minecraft:stone
setblock 96 255 329 minecraft:stripped_spruce_log
fill 96 255 330 96 256 330 minecraft:stone
setblock 96 255 333 minecraft:stone
setblock 96 255 343 minecraft:glowstone
setblock 96 255 362 minecraft:glowstone
setblock 96 255 363 minecraft:stone
setblock 97 255 323 minecraft:stripped_spruce_log
fill 97 255 324 100 255 324 minecraft:stone
setblock 97 255 328 minecraft:stripped_spruce_log
fill 97 255 329 97 258 329 minecraft:stone
fill 97 255 331 97 256 331 minecraft:stone
setblock 97 255 363 minecraft:stripped_spruce_log
fill 98 255 323 101 255 323 minecraft:stone
setblock 98 255 330 minecraft:shroomlight
setblock 98 255 336 minecraft:shroomlight
setblock 98 255 342 minecraft:shroomlight
setblock 98 255 348 minecraft:shroomlight
setblock 98 255 354 minecraft:shroomlight
setblock 98 255 360 minecraft:shroomlight
fill 98 255 363 98 256 363 minecraft:stone
fill 99 255 326 99 256 326 minecraft:stripped_spruce_log
fill 99 255 362 102 255 362 minecraft:stone
setblock 100 255 325 minecraft:stripped_spruce_log
fill 100 255 326 100 256 326 minecraft:stone
setblock 101 255 324 minecraft:stripped_spruce_log
fill 101 255 325 101 258 325 minecraft:stone
setblock 102 255 323 minecraft:stripped_spruce_log
fill 102 255 324 102 256 324 minecraft:stone
setblock 102 255 363 minecraft:stripped_spruce_log
fill 103 255 323 106 255 323 minecraft:stone
setblock 103 255 361 minecraft:stone
setblock 103 255 362 minecraft:stripped_spruce_log
fill 103 255 363 103 256 363 minecraft:stone
fill 104 255 326 104 256 326 minecraft:stripped_spruce_log
setblock 104 255 360 minecraft:shroomlight
setblock 104 255 361 minecraft:stripped_spruce_log
fill 104 255 362 104 256 362 minecraft:stone
setblock 104 255 364 minecraft:raw_iron_block
setblock 105 255 325 minecraft:stripped_spruce_log
setblock 105 255 361 minecraft:stone
fill 105 255 364 106 258 364 minecraft:stone
setblock 106 255 324 minecraft:stripped_spruce_log
setblock 106 255 325 minecraft:stone
setblock 107 255 323 minecraft:stripped_spruce_log
fill 107 255 324 107 256 324 minecraft:stone
fill 107 255 360 107 255 361 minecraft:stripped_dark_oak_log
setblock 107 255 363 minecraft:stripped_spruce_log
fill 108 255 323 108 256 323 minecraft:stone
setblock 108 255 326 minecraft:shroomlight
fill 108 255 349 108 255 360 minecraft:stripped_dark_oak_log
fill 108 255 362 108 256 362 minecraft:stripped_spruce_log
fill 108 255 363 108 256 363 minecraft:stone
fill 109 255 322 109 308 322 minecraft:stone
setblock 109 255 340 minecraft:stripped_spruce_log
fill 109 255 346 109 255 348 minecraft:stripped_dark_oak_log
fill 110 255 324 110 255 337 minecraft:stripped_spruce_log
setblock 110 255 360 minecraft:shroomlight
fill 111 255 323 111 255 329 minecraft:stripped_spruce_log
fill 111 255 364 112 291 364 minecraft:stone
setblock 114 255 326 minecraft:shroomlight
setblock 115 255 324 minecraft:glowstone
fill 115 255 355 115 260 355 minecraft:cobbled_deepslate
fill 115 255 358 117 260 358 minecraft:cobbled_deepslate
setblock 115 255 362 minecraft:glowstone
setblock 116 255 360 minecraft:shroomlight
fill 118 255 355 118 260 355 minecraft:cobbled_deepslate
fill 118 255 357 118 260 357 minecraft:cobbled_deepslate
fill 119 255 323 121 255 323 minecraft:stone
setblock 120 255 326 minecraft:shroomlight
fill 121 255 324 121 256 324 minecraft:stripped_spruce_log
setblock 122 255 323 minecraft:stripped_spruce_log
fill 122 255 324 122 256 324 minecraft:stone
setblock 122 255 360 minecraft:shroomlight
setblock 122 255 363 minecraft:stripped_spruce_log
fill 123 255 323 123 256 323 minecraft:stone
fill 123 255 363 123 256 363 minecraft:stone
fill 124 255 324 124 256 324 minecraft:stone
fill 126 255 324 126 256 324 minecraft:stripped_spruce_log
setblock 126 255 326 minecraft:shroomlight
setblock 127 255 323 minecraft:stripped_spruce_log
setblock 127 255 324 minecraft:stone
fill 127 255 325 127 255 326 minecraft:raw_gold_block
fill 128 255 323 128 256 323 minecraft:stone
setblock 128 255 324 minecraft:raw_gold_block
setblock 128 255 360 minecraft:shroomlight
setblock 132 255 326 minecraft:shroomlight
setblock 132 255 332 minecraft:shroomlight
setblock 132 255 338 minecraft:shroomlight
setblock 132 255 344 minecraft:shroomlight
setblock 132 255 350 minecraft:shroomlight
setblock 132 255 356 minecraft:shroomlight
setblock 133 255 323 minecraft:stone
setblock 134 255 324 minecraft:glowstone
setblock 134 255 325 minecraft:stone
setblock 134 255 326 minecraft:stripped_spruce_log
fill 134 255 327 134 256 327 minecraft:stone
setblock 134 255 331 minecraft:stripped_spruce_log
fill 134 255 332 134 256 332 minecraft:stone
fill 134 255 334 134 256 334 minecraft:stone
setblock 134 255 343 minecraft:glowstone
setblock 134 255 362 minecraft:glowstone
setblock 135 255 325 minecraft:stripped_spruce_log
fill 135 255 326 135 256 326 minecraft:stone
setblock 135 255 330 minecraft:stripped_spruce_log
fill 135 255 331 135 256 331 minecraft:stone
setblock 135 255 335 minecraft:stripped_spruce_log
fill 135 255 336 135 256 336 minecraft:stone
fill 135 255 338 135 256 338 minecraft:stone
fill 135 255 345 135 256 345 minecraft:stripped_spruce_log
fill 135 255 346 135 256 346 minecraft:stone
setblock 135 255 349 minecraft:stone
setblock 135 255 350 minecraft:stripped_spruce_log
fill 135 255 351 135 256 351 minecraft:stone
fill 135 255 353 135 256 353 minecraft:stone
fill 136 255 325 136 269 325 minecraft:stone
setblock 136 255 326 minecraft:diamond_block
setblock 136 255 350 minecraft:raw_gold_block
setblock 136 255 363 minecraft:raw_iron_block
fill 94 256 328 94 276 328 minecraft:stone
fill 94 256 331 94 265 331 minecraft:stone
fill 94 256 344 94 286 345 minecraft:stone
setblock 94 256 346 minecraft:diamond_block
fill 94 256 347 94 269 352 minecraft:stone
setblock 95 256 323 minecraft:stone
setblock 95 256 324 minecraft:stripped_spruce_log
setblock 95 256 325 minecraft:stone
setblock 95 256 329 minecraft:stripped_spruce_log
setblock 95 256 330 minecraft:stone
setblock 95 256 333 minecraft:stone
setblock 95 256 334 minecraft:stripped_spruce_log
setblock 95 256 335 minecraft:stone
fill 95 256 336 95 256 349 minecraft:stripped_spruce_log
setblock 95 256 350 minecraft:stone
fill 95 256 354 98 256 354 minecraft:stripped_spruce_log
setblock 95 256 355 minecraft:stone
fill 95 256 356 95 256 363 minecraft:stripped_spruce_log
setblock 96 256 323 minecraft:stripped_spruce_log
fill 96 256 324 96 257 324 minecraft:spruce_log
setblock 96 256 328 minecraft:stripped_spruce_log
setblock 96 256 329 minecraft:stone
fill 96 256 333 98 256 333 minecraft:stripped_spruce_log
setblock 96 256 334 minecraft:stone
fill 96 256 335 98 256 342 minecraft:stripped_spruce_log
fill 96 256 343 96 257 343 minecraft:spruce_log
fill 96 256 344 98 256 353 minecraft:stripped_spruce_log
fill 96 256 355 98 256 361 minecraft:stripped_spruce_log
fill 96 256 362 96 257 362 minecraft:spruce_log
setblock 96 256 363 minecraft:stripped_spruce_log
fill 97 256 323 99 256 324 minecraft:stone
fill 97 256 327 98 256 327 minecraft:stripped_spruce_log
fill 97 256 328 97 258 328 minecraft:stone
fill 97 256 332 98 256 332 minecraft:stripped_spruce_log
fill 97 256 334 98 256 334 minecraft:stripped_spruce_log
fill 97 256 343 98 256 343 minecraft:stripped_spruce_log
fill 97 256 362 98 256 362 minecraft:stripped_spruce_log
setblock 97 256 363 minecraft:stone
setblock 98 256 326 minecraft:stripped_spruce_log
fill 98 256 328 98 256 331 minecraft:stripped_spruce_log
setblock 99 256 325 minecraft:stripped_spruce_log
fill 99 256 360 101 256 361 minecraft:stripped_spruce_log
fill 99 256 362 101 256 362 minecraft:stone
setblock 100 256 323 minecraft:stone
setblock 100 256 324 minecraft:stripped_spruce_log
fill 100 256 325 100 258 325 minecraft:stone
setblock 101 256 323 minecraft:stripped_spruce_log
setblock 101 256 324 minecraft:stone
setblock 101 256 363 minecraft:stripped_spruce_log
fill 102 256 323 105 256 323 minecraft:stone
fill 102 256 360 135 256 360 minecraft:stripped_spruce_log
setblock 102 256 361 minecraft:stone
setblock 102 256 362 minecraft:stripped_spruce_log
setblock 102 256 363 minecraft:stone
setblock 103 256 326 minecraft:stripped_spruce_log
setblock 103 256 361 minecraft:stripped_spruce_log
setblock 103 256 362 minecraft:stone
setblock 104 256 325 minecraft:stripped_spruce_log
setblock 104 256 361 minecraft:stone
fill 104 256 364 104 273 364 minecraft:stone
setblock 105 256 324 minecraft:stripped_spruce_log
setblock 105 256 325 minecraft:stone
fill 105 256 326 133 256 326 minecraft:stripped_spruce_log
fill 105 256 361 135 256 361 minecraft:stripped_spruce_log
setblock 106 256 323 minecraft:stripped_spruce_log
setblock 106 256 324 minecraft:stone
fill 106 256 325 134 256 325 minecraft:stripped_spruce_log
setblock 106 256 363 minecraft:stripped_spruce_log
setblock 107 256 323 minecraft:stone
setblock 107 256 362 minecraft:stripped_spruce_log
setblock 107 256 363 minecraft:stone
fill 108 256 324 114 256 324 minecraft:stripped_spruce_log
fill 109 256 362 114 256 362 minecraft:stripped_spruce_log
fill 110 256 323 118 256 323 minecraft:stripped_spruce_log
fill 110 256 328 110 256 336 minecraft:stripped_dark_oak_log
setblock 111 256 327 minecraft:stripped_dark_oak_log
fill 111 256 363 118 256 363 minecraft:stripped_spruce_log
fill 114 256 356 114 260 357 minecraft:cobbled_deepslate
fill 115 256 324 115 257 324 minecraft:spruce_log
fill 115 256 354 117 260 354 minecraft:cobbled_deepslate
fill 115 256 362 115 257 362 minecraft:spruce_log
fill 116 256 324 120 256 324 minecraft:stripped_spruce_log
fill 116 256 362 133 256 362 minecraft:stripped_spruce_log
fill 118 256 358 118 260 358 minecraft:cobbled_deepslate
fill 119 256 323 120 256 323 minecraft:stone
fill 119 256 356 119 260 356 minecraft:cobbled_deepslate
setblock 121 256 323 minecraft:stripped_spruce_log
setblock 121 256 363 minecraft:stripped_spruce_log
setblock 122 256 323 minecraft:stone
setblock 122 256 363 minecraft:stone
setblock 125 256 324 minecraft:stripped_spruce_log
fill 125 256 363 135 256 363 minecraft:stripped_spruce_log
setblock 126 256 323 minecraft:stripped_spruce_log
setblock 127 256 323 minecraft:stone
fill 127 256 324 133 256 324 minecraft:stripped_spruce_log
setblock 127 256 327 minecraft:raw_gold_block
fill 128 256 337 130 256 339 minecraft:raw_gold_block
fill 129 256 323 133 256 323 minecraft:stripped_spruce_log
setblock 131 256 364 minecraft:diamond_block
fill 132 256 327 132 256 359 minecraft:stripped_spruce_log
fill 132 256 364 132 271 364 minecraft:stone
fill 133 256 327 133 256 329 minecraft:stripped_spruce_log
setblock 133 256 330 minecraft:stone
fill 133 256 331 133 256 359 minecraft:stripped_spruce_log
fill 134 256 324 134 257 324 minecraft:spruce_log
setblock 134 256 326 minecraft:stone
setblock 134 256 330 minecraft:stripped_spruce_log
setblock 134 256 331 minecraft:stone
fill 134 256 335 134 256 342 minecraft:stripped_spruce_log
fill 134 256 343 134 257 343 minecraft:spruce_log
fill 134 256 344 134 256 359 minecraft:stripped_spruce_log
fill 134 256 362 134 257 362 minecraft:spruce_log
setblock 135 256 324 minecraft:stripped_spruce_log
setblock 135 256 325 minecraft:stone
setblock 135 256 329 minecraft:stripped_spruce_log
setblock 135 256 330 minecraft:stone
setblock 135 256 334 minecraft:stripped_spruce_log
setblock 135 256 335 minecraft:stone
fill 135 256 339 135 256 344 minecraft:stripped_spruce_log
setblock 135 256 349 minecraft:stripped_spruce_log
fill 135 256 350 136 256 350 minecraft:stone
fill 135 256 354 135 256 359 minecraft:stripped_spruce_log
setblock 135 256 362 minecraft:stripped_spruce_log
fill 136 256 326 136 288 326 minecraft:stone
setblock 136 256 338 minecraft:diamond_block
fill 136 256 363 136 296 363 minecraft:stone
fill 94 257 332 94 290 332 minecraft:stone
fill 94 257 346 94 308 346 minecraft:stone
fill 95 257 323 95 257 363 minecraft:spruce_planks
fill 96 257 323 135 257 323 minecraft:spruce_planks
fill 96 257 325 96 257 342 minecraft:spruce_planks
fill 96 257 344 96 257 361 minecraft:spruce_planks
fill 96 257 363 135 257 363 minecraft:spruce_planks
fill 97 257 324 114 257 324 minecraft:spruce_planks
setblock 97 257 326 minecraft:stripped_spruce_log
fill 97 257 327 97 258 327 minecraft:stone
setblock 97 257 331 minecraft:stripped_spruce_log
fill 97 257 332 97 258 332 minecraft:stone
fill 97 257 362 114 257 362 minecraft:spruce_planks
setblock 98 257 325 minecraft:stripped_spruce_log
fill 98 257 326 98 257 360 minecraft:stripped_dark_oak_log
fill 99 257 325 99 258 325 minecraft:stone
fill 99 257 326 132 257 326 minecraft:stripped_dark_oak_log
fill 99 257 360 132 257 360 minecraft:stripped_dark_oak_log
setblock 102 257 361 minecraft:stripped_spruce_log
setblock 103 257 325 minecraft:stripped_spruce_log
setblock 103 257 361 minecraft:stone
setblock 104 257 325 minecraft:stone
fill 114 257 355 114 260 355 minecraft:cobbled_deepslate
fill 114 257 358 114 260 358 minecraft:cobbled_deepslate
fill 115 257 359 118 260 359 minecraft:cobbled_deepslate
fill 116 257 324 133 257 324 minecraft:spruce_planks
fill 116 257 362 133 257 362 minecraft:spruce_planks
fill 118 257 354 118 260 354 minecraft:cobbled_deepslate
fill 119 257 355 119 260 355 minecraft:cobbled_deepslate
fill 119 257 357 119 260 358 minecraft:cobbled_deepslate
fill 121 257 364 121 308 364 minecraft:stone
setblock 122 257 364 minecraft:raw_gold_block
fill 126 257 325 128 257 325 minecraft:raw_gold_block
fill 131 257 364 131 308 364 minecraft:stone
fill 132 257 327 132 257 359 minecraft:stripped_dark_oak_log
fill 134 257 325 135 257 342 minecraft:spruce_planks
fill 134 257 344 135 257 361 minecraft:spruce_planks
setblock 135 257 324 minecraft:spruce_planks
setblock 135 257 343 minecraft:spruce_planks
setblock 135 257 362 minecraft:spruce_planks
fill 136 257 338 136 308 338 minecraft:stone
fill 136 257 350 136 308 350 minecraft:stone
setblock 94 258 343 minecraft:raw_iron_block
fill 95 258 323 95 258 326 minecraft:stone
setblock 95 258 327 minecraft:stripped_spruce_log
fill 95 258 328 95 258 331 minecraft:stone
setblock 95 258 332 minecraft:stripped_spruce_log
fill 95 258 333 95 258 336 minecraft:stone
fill 95 258 350 95 258 351 minecraft:stone
setblock 95 258 352 minecraft:stripped_spruce_log
fill 95 258 353 95 258 356 minecraft:stone
setblock 95 258 357 minecraft:stripped_spruce_log
fill 95 258 358 95 261 358 minecraft:stone
fill 96 258 323 96 258 325 minecraft:stone
setblock 96 258 326 minecraft:stripped_spruce_log
fill 96 258 327 96 258 330 minecraft:stone
setblock 96 258 331 minecraft:stripped_spruce_log
fill 96 258 332 96 259 334 minecraft:stone
fill 96 258 353 96 258 355 minecraft:stone
fill 96 258 363 98 258 363 minecraft:stone
fill 97 258 323 97 258 324 minecraft:stone
setblock 97 258 325 minecraft:light[level=15]
setblock 97 258 330 minecraft:stripped_spruce_log
fill 97 258 331 97 259 331 minecraft:stone
setblock 97 258 333 minecraft:light[level=15]
setblock 97 258 339 minecraft:light[level=12]
setblock 97 258 341 minecraft:light[level=15]
setblock 97 258 346 minecraft:light[level=12]
setblock 97 258 349 minecraft:light[level=15]
setblock 97 258 353 minecraft:light[level=12]
schedule function dropper:buildpart/74_9 1t
