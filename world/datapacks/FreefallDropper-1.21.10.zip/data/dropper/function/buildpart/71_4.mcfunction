setblock 548 189 285 minecraft:light[level=12]
setblock 548 189 292 minecraft:light[level=12]
setblock 548 189 299 minecraft:light[level=12]
setblock 548 189 306 minecraft:light[level=12]
setblock 548 189 313 minecraft:light[level=12]
setblock 551 189 317 minecraft:white_concrete
fill 552 189 276 553 189 285 minecraft:red_concrete
fill 554 189 277 557 189 285 minecraft:red_concrete
setblock 555 189 275 minecraft:white_concrete
setblock 555 189 292 minecraft:light[level=12]
setblock 555 189 299 minecraft:light[level=12]
setblock 555 189 306 minecraft:light[level=12]
setblock 555 189 313 minecraft:light[level=12]
setblock 557 189 276 minecraft:red_concrete
setblock 559 189 275 minecraft:white_concrete
setblock 559 189 281 minecraft:white_concrete
setblock 559 189 285 minecraft:white_concrete
setblock 559 189 293 minecraft:white_concrete
setblock 559 189 297 minecraft:white_concrete
setblock 559 189 305 minecraft:white_concrete
setblock 559 189 309 minecraft:white_concrete
setblock 559 189 317 minecraft:white_concrete
setblock 517 190 276 minecraft:white_concrete
fill 517 190 277 517 197 277 minecraft:brown_terracotta
setblock 517 190 278 minecraft:white_concrete
setblock 517 190 280 minecraft:white_concrete
fill 517 190 285 517 197 285 minecraft:brown_terracotta
setblock 517 190 286 minecraft:white_concrete
setblock 517 190 288 minecraft:white_concrete
fill 517 190 289 517 197 289 minecraft:brown_terracotta
setblock 517 190 290 minecraft:white_concrete
setblock 517 190 292 minecraft:white_concrete
fill 517 190 297 517 197 297 minecraft:brown_terracotta
setblock 517 190 298 minecraft:white_concrete
setblock 517 190 300 minecraft:white_concrete
fill 517 190 301 517 197 301 minecraft:brown_terracotta
setblock 517 190 302 minecraft:white_concrete
setblock 517 190 304 minecraft:white_concrete
fill 517 190 309 517 197 309 minecraft:brown_terracotta
setblock 517 190 310 minecraft:white_concrete
setblock 517 190 312 minecraft:white_concrete
fill 517 190 313 517 197 313 minecraft:brown_terracotta
setblock 517 190 314 minecraft:white_concrete
setblock 517 190 316 minecraft:white_concrete
setblock 518 190 275 minecraft:white_concrete
fill 519 190 275 519 197 275 minecraft:brown_terracotta
setblock 520 190 275 minecraft:white_concrete
fill 520 190 296 520 191 296 minecraft:orange_terracotta
setblock 522 190 275 minecraft:white_concrete
setblock 522 190 317 minecraft:white_concrete
fill 523 190 275 523 197 275 minecraft:brown_terracotta
fill 523 190 317 523 197 317 minecraft:brown_terracotta
setblock 524 190 317 minecraft:white_concrete
setblock 526 190 317 minecraft:white_concrete
fill 527 190 317 527 197 317 minecraft:brown_terracotta
setblock 528 190 275 minecraft:white_concrete
setblock 528 190 317 minecraft:white_concrete
setblock 530 190 275 minecraft:white_concrete
fill 531 190 275 531 197 275 minecraft:brown_terracotta
setblock 532 190 275 minecraft:white_concrete
setblock 534 190 275 minecraft:white_concrete
setblock 534 190 317 minecraft:white_concrete
fill 535 190 275 535 197 275 minecraft:brown_terracotta
fill 535 190 317 535 197 317 minecraft:brown_terracotta
setblock 536 190 317 minecraft:white_concrete
setblock 538 190 317 minecraft:white_concrete
fill 539 190 317 539 197 317 minecraft:brown_terracotta
setblock 540 190 275 minecraft:white_concrete
setblock 540 190 317 minecraft:white_concrete
setblock 542 190 275 minecraft:white_concrete
fill 543 190 275 543 197 275 minecraft:brown_terracotta
fill 543 190 281 544 195 281 minecraft:brown_terracotta
setblock 544 190 275 minecraft:white_concrete
fill 544 190 283 544 195 283 minecraft:brown_terracotta
setblock 546 190 275 minecraft:white_concrete
setblock 546 190 317 minecraft:white_concrete
fill 547 190 275 547 197 275 minecraft:brown_terracotta
fill 547 190 317 547 197 317 minecraft:brown_terracotta
setblock 548 190 317 minecraft:white_concrete
setblock 550 190 317 minecraft:white_concrete
fill 551 190 317 551 197 317 minecraft:brown_terracotta
setblock 552 190 275 minecraft:white_concrete
setblock 552 190 317 minecraft:white_concrete
fill 553 190 276 553 190 284 minecraft:red_concrete
setblock 554 190 275 minecraft:white_concrete
fill 554 190 277 556 190 284 minecraft:red_concrete
fill 555 190 275 555 197 275 minecraft:brown_terracotta
setblock 556 190 275 minecraft:white_concrete
setblock 558 190 275 minecraft:white_concrete
setblock 558 190 317 minecraft:white_concrete
setblock 559 190 275 minecraft:brown_terracotta
setblock 559 190 280 minecraft:white_concrete
fill 559 190 281 559 197 281 minecraft:brown_terracotta
setblock 559 190 282 minecraft:white_concrete
setblock 559 190 284 minecraft:white_concrete
fill 559 190 285 559 197 285 minecraft:brown_terracotta
setblock 559 190 286 minecraft:white_concrete
setblock 559 190 292 minecraft:white_concrete
fill 559 190 293 559 197 293 minecraft:brown_terracotta
setblock 559 190 294 minecraft:white_concrete
setblock 559 190 296 minecraft:white_concrete
fill 559 190 297 559 197 297 minecraft:brown_terracotta
setblock 559 190 298 minecraft:white_concrete
setblock 559 190 304 minecraft:white_concrete
fill 559 190 305 559 197 305 minecraft:brown_terracotta
setblock 559 190 306 minecraft:white_concrete
setblock 559 190 308 minecraft:white_concrete
fill 559 190 309 559 197 309 minecraft:brown_terracotta
setblock 559 190 310 minecraft:white_concrete
setblock 559 190 316 minecraft:white_concrete
fill 559 190 317 559 197 317 minecraft:brown_terracotta
setblock 517 191 275 minecraft:white_concrete
fill 517 191 276 517 198 276 minecraft:brown_terracotta
fill 517 191 278 517 198 278 minecraft:brown_terracotta
setblock 517 191 279 minecraft:white_concrete
fill 517 191 280 517 198 280 minecraft:brown_terracotta
fill 517 191 286 517 198 286 minecraft:brown_terracotta
setblock 517 191 287 minecraft:white_concrete
fill 517 191 288 517 198 288 minecraft:brown_terracotta
fill 517 191 290 517 198 290 minecraft:brown_terracotta
setblock 517 191 291 minecraft:white_concrete
fill 517 191 292 517 198 292 minecraft:brown_terracotta
fill 517 191 298 517 198 298 minecraft:brown_terracotta
setblock 517 191 299 minecraft:white_concrete
fill 517 191 300 517 198 300 minecraft:brown_terracotta
fill 517 191 302 517 198 302 minecraft:brown_terracotta
setblock 517 191 303 minecraft:white_concrete
fill 517 191 304 517 198 304 minecraft:brown_terracotta
fill 517 191 310 517 198 310 minecraft:brown_terracotta
setblock 517 191 311 minecraft:white_concrete
fill 517 191 312 517 198 312 minecraft:brown_terracotta
fill 517 191 314 517 198 314 minecraft:brown_terracotta
setblock 517 191 315 minecraft:white_concrete
fill 517 191 316 517 198 316 minecraft:brown_terracotta
fill 518 191 275 518 198 275 minecraft:brown_terracotta
fill 520 191 275 520 198 275 minecraft:brown_terracotta
setblock 521 191 275 minecraft:white_concrete
setblock 521 191 317 minecraft:white_concrete
fill 522 191 275 522 198 275 minecraft:brown_terracotta
fill 522 191 317 522 198 317 minecraft:brown_terracotta
fill 524 191 317 524 198 317 minecraft:brown_terracotta
setblock 525 191 317 minecraft:white_concrete
fill 526 191 317 526 198 317 minecraft:brown_terracotta
fill 528 191 275 528 198 275 minecraft:brown_terracotta
fill 528 191 317 528 198 317 minecraft:brown_terracotta
setblock 529 191 275 minecraft:white_concrete
fill 530 191 275 530 198 275 minecraft:brown_terracotta
fill 532 191 275 532 198 275 minecraft:brown_terracotta
setblock 533 191 275 minecraft:white_concrete
setblock 533 191 317 minecraft:white_concrete
fill 534 191 275 534 198 275 minecraft:brown_terracotta
fill 534 191 317 534 198 317 minecraft:brown_terracotta
fill 536 191 317 536 198 317 minecraft:brown_terracotta
setblock 537 191 317 minecraft:white_concrete
fill 538 191 317 538 198 317 minecraft:brown_terracotta
fill 540 191 275 540 198 275 minecraft:brown_terracotta
fill 540 191 317 540 198 317 minecraft:brown_terracotta
setblock 541 191 275 minecraft:white_concrete
fill 542 191 275 542 198 275 minecraft:brown_terracotta
fill 542 191 282 542 195 282 minecraft:brown_terracotta
fill 543 191 283 543 195 283 minecraft:brown_terracotta
fill 544 191 275 544 198 275 minecraft:brown_terracotta
setblock 545 191 275 minecraft:white_concrete
fill 545 191 281 545 195 283 minecraft:brown_terracotta
setblock 545 191 317 minecraft:white_concrete
fill 546 191 275 546 198 275 minecraft:brown_terracotta
fill 546 191 317 546 198 317 minecraft:brown_terracotta
fill 548 191 317 548 198 317 minecraft:brown_terracotta
setblock 549 191 317 minecraft:white_concrete
fill 550 191 317 550 198 317 minecraft:brown_terracotta
fill 552 191 275 552 198 275 minecraft:brown_terracotta
fill 552 191 317 552 198 317 minecraft:brown_terracotta
setblock 553 191 275 minecraft:white_concrete
fill 553 191 280 553 218 280 minecraft:white_concrete
fill 554 191 275 554 198 275 minecraft:brown_terracotta
fill 554 191 277 555 191 283 minecraft:red_concrete
fill 556 191 275 556 198 275 minecraft:brown_terracotta
fill 556 191 279 556 218 281 minecraft:white_concrete
fill 556 191 282 556 194 284 minecraft:red_wool
setblock 557 191 275 minecraft:white_concrete
setblock 557 191 317 minecraft:white_concrete
fill 558 191 275 558 198 275 minecraft:brown_terracotta
fill 558 191 317 558 198 317 minecraft:brown_terracotta
setblock 559 191 275 minecraft:white_concrete
fill 559 191 280 559 198 280 minecraft:brown_terracotta
fill 559 191 282 559 198 282 minecraft:brown_terracotta
setblock 559 191 283 minecraft:white_concrete
fill 559 191 284 559 198 284 minecraft:brown_terracotta
fill 559 191 286 559 198 286 minecraft:brown_terracotta
setblock 559 191 287 minecraft:white_concrete
fill 559 191 292 559 198 292 minecraft:brown_terracotta
fill 559 191 294 559 198 294 minecraft:brown_terracotta
setblock 559 191 295 minecraft:white_concrete
fill 559 191 296 559 198 296 minecraft:brown_terracotta
fill 559 191 298 559 198 298 minecraft:brown_terracotta
setblock 559 191 299 minecraft:white_concrete
fill 559 191 304 559 198 304 minecraft:brown_terracotta
fill 559 191 306 559 198 306 minecraft:brown_terracotta
setblock 559 191 307 minecraft:white_concrete
fill 559 191 308 559 198 308 minecraft:brown_terracotta
fill 559 191 310 559 198 310 minecraft:brown_terracotta
setblock 559 191 311 minecraft:white_concrete
fill 559 191 316 559 198 316 minecraft:brown_terracotta
fill 517 192 275 517 199 275 minecraft:brown_terracotta
fill 517 192 279 517 199 279 minecraft:brown_terracotta
fill 517 192 281 517 197 281 minecraft:brown_terracotta
fill 517 192 282 517 192 283 minecraft:shroomlight
fill 517 192 284 517 198 284 minecraft:brown_terracotta
fill 517 192 287 517 199 287 minecraft:brown_terracotta
fill 517 192 291 517 199 291 minecraft:brown_terracotta
fill 517 192 293 517 197 293 minecraft:brown_terracotta
fill 517 192 294 517 192 295 minecraft:shroomlight
fill 517 192 296 517 198 296 minecraft:brown_terracotta
fill 517 192 299 517 199 299 minecraft:brown_terracotta
fill 517 192 303 517 199 303 minecraft:brown_terracotta
fill 517 192 305 517 197 305 minecraft:brown_terracotta
fill 517 192 306 517 192 307 minecraft:shroomlight
fill 517 192 308 517 198 308 minecraft:brown_terracotta
fill 517 192 311 517 199 311 minecraft:brown_terracotta
fill 517 192 315 517 199 315 minecraft:brown_terracotta
fill 517 192 317 517 197 317 minecraft:brown_terracotta
fill 518 192 294 522 192 298 minecraft:white_concrete
fill 518 192 317 519 192 317 minecraft:shroomlight
fill 520 192 317 521 198 317 minecraft:brown_terracotta
fill 521 192 275 521 199 275 minecraft:brown_terracotta
fill 524 192 275 524 198 275 minecraft:brown_terracotta
fill 525 192 275 526 192 275 minecraft:shroomlight
fill 525 192 317 525 199 317 minecraft:brown_terracotta
fill 527 192 275 527 197 275 minecraft:brown_terracotta
fill 529 192 275 529 199 275 minecraft:brown_terracotta
fill 529 192 317 529 199 317 minecraft:brown_terracotta
fill 530 192 317 531 192 317 minecraft:shroomlight
fill 532 192 317 533 198 317 minecraft:brown_terracotta
fill 533 192 275 533 199 275 minecraft:brown_terracotta
fill 536 192 275 536 198 275 minecraft:brown_terracotta
fill 537 192 275 538 192 275 minecraft:shroomlight
fill 537 192 317 537 199 317 minecraft:brown_terracotta
fill 539 192 275 539 197 275 minecraft:brown_terracotta
fill 541 192 275 541 199 275 minecraft:brown_terracotta
fill 541 192 317 541 199 317 minecraft:brown_terracotta
fill 542 192 281 542 195 281 minecraft:brown_terracotta
fill 542 192 283 542 195 283 minecraft:brown_terracotta
fill 542 192 317 543 192 317 minecraft:shroomlight
fill 543 192 280 544 195 280 minecraft:brown_terracotta
fill 544 192 284 544 195 284 minecraft:brown_terracotta
fill 544 192 317 545 198 317 minecraft:brown_terracotta
fill 545 192 275 545 199 275 minecraft:brown_terracotta
fill 548 192 275 548 198 275 minecraft:brown_terracotta
fill 549 192 275 550 192 275 minecraft:shroomlight
fill 549 192 317 549 199 317 minecraft:brown_terracotta
fill 551 192 275 551 197 275 minecraft:brown_terracotta
fill 553 192 275 553 199 275 minecraft:brown_terracotta
fill 553 192 317 553 199 317 minecraft:brown_terracotta
fill 554 192 278 555 192 282 minecraft:red_concrete
fill 554 192 317 555 192 317 minecraft:shroomlight
fill 556 192 317 557 198 317 minecraft:brown_terracotta
fill 557 192 275 557 199 275 minecraft:brown_terracotta
fill 559 192 275 559 197 276 minecraft:brown_terracotta
fill 559 192 277 559 192 278 minecraft:shroomlight
fill 559 192 279 559 199 279 minecraft:brown_terracotta
fill 559 192 283 559 199 283 minecraft:brown_terracotta
fill 559 192 287 559 198 288 minecraft:brown_terracotta
fill 559 192 289 559 192 290 minecraft:shroomlight
fill 559 192 291 559 199 291 minecraft:brown_terracotta
fill 559 192 295 559 199 295 minecraft:brown_terracotta
fill 559 192 299 559 198 300 minecraft:brown_terracotta
fill 559 192 301 559 192 302 minecraft:shroomlight
fill 559 192 303 559 199 303 minecraft:brown_terracotta
fill 559 192 307 559 199 307 minecraft:brown_terracotta
fill 559 192 311 559 198 312 minecraft:brown_terracotta
fill 559 192 313 559 192 314 minecraft:shroomlight
fill 559 192 315 559 199 315 minecraft:brown_terracotta
fill 517 193 282 517 198 283 minecraft:brown_terracotta
fill 517 193 294 517 198 295 minecraft:brown_terracotta
fill 517 193 306 517 198 307 minecraft:brown_terracotta
fill 518 193 298 521 193 298 minecraft:white_concrete
fill 518 193 317 519 197 317 minecraft:brown_terracotta
fill 519 193 294 521 193 297 minecraft:white_concrete
fill 525 193 275 526 198 275 minecraft:brown_terracotta
fill 530 193 317 531 197 317 minecraft:brown_terracotta
fill 537 193 275 538 198 275 minecraft:brown_terracotta
fill 542 193 280 542 195 280 minecraft:brown_terracotta
fill 542 193 317 543 197 317 minecraft:brown_terracotta
fill 543 193 284 543 195 284 minecraft:brown_terracotta
fill 545 193 280 545 195 280 minecraft:brown_terracotta
fill 545 193 284 545 195 284 minecraft:brown_terracotta
fill 546 193 281 546 195 283 minecraft:brown_terracotta
fill 549 193 275 550 198 275 minecraft:brown_terracotta
fill 554 193 279 555 218 281 minecraft:white_concrete
fill 554 193 317 555 197 317 minecraft:brown_terracotta
fill 559 193 277 559 197 278 minecraft:brown_terracotta
fill 559 193 289 559 197 290 minecraft:brown_terracotta
fill 559 193 301 559 197 302 minecraft:brown_terracotta
fill 559 193 313 559 197 314 minecraft:brown_terracotta
fill 518 194 298 518 218 298 minecraft:white_concrete
fill 520 194 294 520 194 298 minecraft:white_concrete
fill 541 194 281 541 195 283 minecraft:brown_terracotta
fill 542 194 284 542 195 284 minecraft:brown_terracotta
fill 543 194 279 544 195 279 minecraft:brown_terracotta
fill 546 194 280 546 195 280 minecraft:brown_terracotta
setblock 520 195 278 minecraft:light[level=15]
fill 520 195 279 520 195 281 minecraft:brown_terracotta
setblock 520 195 285 minecraft:light[level=12]
setblock 520 195 286 minecraft:light[level=15]
setblock 520 195 292 minecraft:light[level=12]
setblock 520 195 294 minecraft:light[level=15]
setblock 520 195 299 minecraft:light[level=12]
setblock 520 195 302 minecraft:light[level=15]
setblock 520 195 306 minecraft:light[level=12]
setblock 520 195 310 minecraft:light[level=15]
setblock 520 195 313 minecraft:light[level=12]
fill 521 195 278 523 195 278 minecraft:brown_terracotta
setblock 521 195 282 minecraft:brown_terracotta
setblock 523 195 282 minecraft:brown_terracotta
fill 524 195 279 524 195 281 minecraft:brown_terracotta
setblock 527 195 278 minecraft:light[level=12]
setblock 527 195 285 minecraft:light[level=12]
setblock 527 195 292 minecraft:light[level=12]
setblock 527 195 299 minecraft:light[level=12]
setblock 527 195 306 minecraft:light[level=12]
setblock 527 195 313 minecraft:light[level=12]
setblock 528 195 278 minecraft:light[level=15]
setblock 528 195 286 minecraft:light[level=15]
setblock 528 195 294 minecraft:light[level=15]
setblock 528 195 302 minecraft:light[level=15]
setblock 528 195 310 minecraft:light[level=15]
setblock 534 195 278 minecraft:light[level=12]
setblock 534 195 285 minecraft:light[level=12]
setblock 534 195 292 minecraft:light[level=12]
setblock 534 195 299 minecraft:light[level=12]
setblock 534 195 306 minecraft:light[level=12]
setblock 534 195 313 minecraft:light[level=12]
setblock 536 195 278 minecraft:light[level=15]
setblock 536 195 286 minecraft:light[level=15]
setblock 536 195 294 minecraft:light[level=15]
setblock 536 195 302 minecraft:light[level=15]
setblock 536 195 310 minecraft:light[level=15]
setblock 541 195 278 minecraft:light[level=12]
setblock 541 195 280 minecraft:brown_terracotta
setblock 541 195 284 minecraft:brown_terracotta
setblock 541 195 285 minecraft:light[level=12]
setblock 541 195 292 minecraft:light[level=12]
setblock 541 195 299 minecraft:light[level=12]
setblock 541 195 306 minecraft:light[level=12]
setblock 541 195 313 minecraft:light[level=12]
setblock 542 195 279 minecraft:brown_terracotta
fill 542 195 285 545 195 285 minecraft:brown_terracotta
setblock 544 195 278 minecraft:light[level=15]
setblock 544 195 286 minecraft:light[level=15]
setblock 544 195 294 minecraft:light[level=15]
setblock 544 195 302 minecraft:light[level=15]
setblock 544 195 310 minecraft:light[level=15]
setblock 545 195 279 minecraft:brown_terracotta
setblock 546 195 284 minecraft:brown_terracotta
fill 547 195 281 547 195 283 minecraft:brown_terracotta
setblock 548 195 278 minecraft:light[level=12]
setblock 548 195 285 minecraft:light[level=12]
setblock 548 195 292 minecraft:light[level=12]
setblock 548 195 299 minecraft:light[level=12]
setblock 548 195 306 minecraft:light[level=12]
setblock 548 195 313 minecraft:light[level=12]
setblock 552 195 278 minecraft:light[level=15]
setblock 552 195 286 minecraft:light[level=15]
setblock 552 195 294 minecraft:light[level=15]
setblock 552 195 302 minecraft:light[level=15]
setblock 552 195 310 minecraft:light[level=15]
fill 553 195 278 553 195 279 minecraft:brown_terracotta
setblock 553 195 281 minecraft:brown_terracotta
fill 554 195 278 556 195 278 minecraft:brown_terracotta
fill 554 195 282 556 195 282 minecraft:brown_terracotta
setblock 555 195 285 minecraft:light[level=12]
setblock 555 195 292 minecraft:light[level=12]
setblock 555 195 299 minecraft:light[level=12]
setblock 555 195 306 minecraft:light[level=12]
setblock 555 195 313 minecraft:light[level=12]
fill 556 195 283 556 196 285 minecraft:iron_block
fill 557 195 279 557 195 281 minecraft:brown_terracotta
fill 544 196 282 544 199 282 minecraft:white_concrete
setblock 556 196 282 minecraft:iron_block
setblock 517 198 277 minecraft:white_concrete
setblock 517 198 281 minecraft:white_concrete
setblock 517 198 285 minecraft:white_concrete
setblock 517 198 289 minecraft:white_concrete
setblock 517 198 293 minecraft:white_concrete
setblock 517 198 297 minecraft:white_concrete
setblock 517 198 301 minecraft:white_concrete
setblock 517 198 305 minecraft:white_concrete
setblock 517 198 309 minecraft:white_concrete
setblock 517 198 313 minecraft:white_concrete
setblock 517 198 317 minecraft:white_concrete
setblock 518 198 317 minecraft:brown_terracotta
setblock 519 198 275 minecraft:white_concrete
setblock 519 198 317 minecraft:white_concrete
setblock 523 198 275 minecraft:white_concrete
setblock 523 198 317 minecraft:white_concrete
setblock 527 198 275 minecraft:white_concrete
setblock 527 198 317 minecraft:white_concrete
setblock 530 198 317 minecraft:brown_terracotta
setblock 531 198 275 minecraft:white_concrete
setblock 531 198 317 minecraft:white_concrete
setblock 535 198 275 minecraft:white_concrete
setblock 535 198 317 minecraft:white_concrete
setblock 539 198 275 minecraft:white_concrete
setblock 539 198 317 minecraft:white_concrete
setblock 542 198 317 minecraft:brown_terracotta
setblock 543 198 275 minecraft:white_concrete
setblock 543 198 317 minecraft:white_concrete
setblock 547 198 275 minecraft:white_concrete
setblock 547 198 317 minecraft:white_concrete
setblock 551 198 275 minecraft:white_concrete
setblock 551 198 317 minecraft:white_concrete
setblock 554 198 317 minecraft:brown_terracotta
setblock 555 198 275 minecraft:white_concrete
setblock 555 198 317 minecraft:white_concrete
setblock 559 198 275 minecraft:white_concrete
setblock 559 198 276 minecraft:brown_terracotta
setblock 559 198 277 minecraft:white_concrete
setblock 559 198 278 minecraft:brown_terracotta
setblock 559 198 281 minecraft:white_concrete
setblock 559 198 285 minecraft:white_concrete
setblock 559 198 289 minecraft:white_concrete
setblock 559 198 290 minecraft:brown_terracotta
setblock 559 198 293 minecraft:white_concrete
setblock 559 198 297 minecraft:white_concrete
setblock 559 198 301 minecraft:white_concrete
setblock 559 198 302 minecraft:brown_terracotta
setblock 559 198 305 minecraft:white_concrete
setblock 559 198 309 minecraft:white_concrete
setblock 559 198 313 minecraft:white_concrete
setblock 559 198 314 minecraft:brown_terracotta
setblock 559 198 317 minecraft:white_concrete
setblock 517 199 276 minecraft:white_concrete
fill 517 199 277 517 206 277 minecraft:brown_terracotta
setblock 517 199 278 minecraft:white_concrete
setblock 517 199 280 minecraft:white_concrete
fill 517 199 281 517 205 281 minecraft:brown_terracotta
setblock 517 199 282 minecraft:white_concrete
setblock 517 199 283 minecraft:brown_terracotta
setblock 517 199 284 minecraft:white_concrete
fill 517 199 285 517 206 285 minecraft:brown_terracotta
setblock 517 199 286 minecraft:white_concrete
setblock 517 199 288 minecraft:white_concrete
fill 517 199 289 517 206 289 minecraft:brown_terracotta
setblock 517 199 290 minecraft:white_concrete
setblock 517 199 292 minecraft:white_concrete
fill 517 199 293 517 205 293 minecraft:brown_terracotta
setblock 517 199 294 minecraft:white_concrete
setblock 517 199 295 minecraft:brown_terracotta
setblock 517 199 296 minecraft:white_concrete
fill 517 199 297 517 206 297 minecraft:brown_terracotta
setblock 517 199 298 minecraft:white_concrete
setblock 517 199 300 minecraft:white_concrete
fill 517 199 301 517 206 301 minecraft:brown_terracotta
setblock 517 199 302 minecraft:white_concrete
setblock 517 199 304 minecraft:white_concrete
fill 517 199 305 517 205 305 minecraft:brown_terracotta
setblock 517 199 306 minecraft:white_concrete
setblock 517 199 307 minecraft:brown_terracotta
setblock 517 199 308 minecraft:white_concrete
fill 517 199 309 517 206 309 minecraft:brown_terracotta
setblock 517 199 310 minecraft:white_concrete
setblock 517 199 312 minecraft:white_concrete
fill 517 199 313 517 206 313 minecraft:brown_terracotta
setblock 517 199 314 minecraft:white_concrete
setblock 517 199 316 minecraft:white_concrete
setblock 517 199 317 minecraft:brown_terracotta
setblock 518 199 275 minecraft:white_concrete
setblock 518 199 317 minecraft:white_concrete
fill 519 199 275 519 206 275 minecraft:brown_terracotta
fill 519 199 317 519 205 317 minecraft:brown_terracotta
setblock 520 199 275 minecraft:white_concrete
setblock 520 199 317 minecraft:white_concrete
setblock 521 199 317 minecraft:brown_terracotta
setblock 522 199 275 minecraft:white_concrete
setblock 522 199 317 minecraft:white_concrete
fill 523 199 275 523 206 275 minecraft:brown_terracotta
fill 523 199 317 523 206 317 minecraft:brown_terracotta
setblock 524 199 275 minecraft:white_concrete
setblock 524 199 317 minecraft:white_concrete
setblock 525 199 275 minecraft:brown_terracotta
setblock 526 199 275 minecraft:white_concrete
setblock 526 199 317 minecraft:white_concrete
fill 527 199 275 527 205 275 minecraft:brown_terracotta
fill 527 199 317 527 206 317 minecraft:brown_terracotta
setblock 528 199 275 minecraft:white_concrete
setblock 528 199 317 minecraft:white_concrete
setblock 530 199 275 minecraft:white_concrete
setblock 530 199 317 minecraft:white_concrete
fill 531 199 275 531 206 275 minecraft:brown_terracotta
fill 531 199 317 531 205 317 minecraft:brown_terracotta
setblock 532 199 275 minecraft:white_concrete
setblock 532 199 317 minecraft:white_concrete
setblock 533 199 317 minecraft:brown_terracotta
setblock 534 199 275 minecraft:white_concrete
setblock 534 199 317 minecraft:white_concrete
fill 535 199 275 535 206 275 minecraft:brown_terracotta
fill 535 199 317 535 206 317 minecraft:brown_terracotta
setblock 536 199 275 minecraft:white_concrete
setblock 536 199 317 minecraft:white_concrete
setblock 537 199 275 minecraft:brown_terracotta
setblock 538 199 275 minecraft:white_concrete
setblock 538 199 317 minecraft:white_concrete
fill 539 199 275 539 205 275 minecraft:brown_terracotta
fill 539 199 317 539 206 317 minecraft:brown_terracotta
setblock 540 199 275 minecraft:white_concrete
setblock 540 199 317 minecraft:white_concrete
setblock 542 199 275 minecraft:white_concrete
fill 542 199 281 543 201 282 minecraft:spruce_leaves[persistent=true]
setblock 542 199 317 minecraft:white_concrete
fill 543 199 275 543 206 275 minecraft:brown_terracotta
fill 543 199 283 545 201 283 minecraft:spruce_leaves[persistent=true]
fill 543 199 317 543 205 317 minecraft:brown_terracotta
setblock 544 199 275 minecraft:white_concrete
fill 544 199 280 544 201 281 minecraft:spruce_leaves[persistent=true]
setblock 544 199 317 minecraft:white_concrete
fill 545 199 281 545 201 282 minecraft:spruce_leaves[persistent=true]
setblock 545 199 317 minecraft:brown_terracotta
setblock 546 199 275 minecraft:white_concrete
setblock 546 199 317 minecraft:white_concrete
fill 547 199 275 547 206 275 minecraft:brown_terracotta
fill 547 199 317 547 206 317 minecraft:brown_terracotta
setblock 548 199 275 minecraft:white_concrete
setblock 548 199 317 minecraft:white_concrete
setblock 549 199 275 minecraft:brown_terracotta
setblock 550 199 275 minecraft:white_concrete
setblock 550 199 317 minecraft:white_concrete
fill 551 199 275 551 205 275 minecraft:brown_terracotta
fill 551 199 317 551 206 317 minecraft:brown_terracotta
setblock 552 199 275 minecraft:white_concrete
setblock 552 199 317 minecraft:white_concrete
setblock 554 199 275 minecraft:white_concrete
setblock 554 199 317 minecraft:white_concrete
fill 555 199 275 555 206 275 minecraft:brown_terracotta
fill 555 199 317 555 205 317 minecraft:brown_terracotta
setblock 556 199 275 minecraft:white_concrete
setblock 556 199 317 minecraft:white_concrete
setblock 557 199 317 minecraft:brown_terracotta
setblock 558 199 275 minecraft:white_concrete
setblock 558 199 317 minecraft:white_concrete
setblock 559 199 275 minecraft:brown_terracotta
setblock 559 199 276 minecraft:white_concrete
fill 559 199 277 559 205 277 minecraft:brown_terracotta
setblock 559 199 278 minecraft:white_concrete
setblock 559 199 280 minecraft:white_concrete
fill 559 199 281 559 206 281 minecraft:brown_terracotta
setblock 559 199 282 minecraft:white_concrete
setblock 559 199 284 minecraft:white_concrete
fill 559 199 285 559 206 285 minecraft:brown_terracotta
setblock 559 199 286 minecraft:white_concrete
setblock 559 199 287 minecraft:brown_terracotta
setblock 559 199 288 minecraft:white_concrete
fill 559 199 289 559 205 289 minecraft:brown_terracotta
setblock 559 199 290 minecraft:white_concrete
setblock 559 199 292 minecraft:white_concrete
fill 559 199 293 559 206 293 minecraft:brown_terracotta
setblock 559 199 294 minecraft:white_concrete
setblock 559 199 296 minecraft:white_concrete
fill 559 199 297 559 206 297 minecraft:brown_terracotta
setblock 559 199 298 minecraft:white_concrete
setblock 559 199 299 minecraft:brown_terracotta
setblock 559 199 300 minecraft:white_concrete
fill 559 199 301 559 205 301 minecraft:brown_terracotta
setblock 559 199 302 minecraft:white_concrete
setblock 559 199 304 minecraft:white_concrete
fill 559 199 305 559 206 305 minecraft:brown_terracotta
setblock 559 199 306 minecraft:white_concrete
setblock 559 199 308 minecraft:white_concrete
fill 559 199 309 559 206 309 minecraft:brown_terracotta
setblock 559 199 310 minecraft:white_concrete
setblock 559 199 311 minecraft:brown_terracotta
setblock 559 199 312 minecraft:white_concrete
fill 559 199 313 559 205 313 minecraft:brown_terracotta
setblock 559 199 314 minecraft:white_concrete
setblock 559 199 316 minecraft:white_concrete
fill 559 199 317 559 206 317 minecraft:brown_terracotta
setblock 517 200 275 minecraft:white_concrete
fill 517 200 276 517 207 276 minecraft:brown_terracotta
fill 517 200 278 517 207 278 minecraft:brown_terracotta
setblock 517 200 279 minecraft:white_concrete
fill 517 200 280 517 207 280 minecraft:brown_terracotta
fill 517 200 282 517 205 282 minecraft:brown_terracotta
setblock 517 200 283 minecraft:white_concrete
fill 517 200 284 517 205 284 minecraft:brown_terracotta
fill 517 200 286 517 207 286 minecraft:brown_terracotta
setblock 517 200 287 minecraft:white_concrete
fill 517 200 288 517 207 288 minecraft:brown_terracotta
fill 517 200 290 517 207 290 minecraft:brown_terracotta
setblock 517 200 291 minecraft:white_concrete
fill 517 200 292 517 207 292 minecraft:brown_terracotta
fill 517 200 294 517 205 294 minecraft:brown_terracotta
setblock 517 200 295 minecraft:white_concrete
fill 517 200 296 517 205 296 minecraft:brown_terracotta
fill 517 200 298 517 207 298 minecraft:brown_terracotta
setblock 517 200 299 minecraft:white_concrete
fill 517 200 300 517 207 300 minecraft:brown_terracotta
fill 517 200 302 517 207 302 minecraft:brown_terracotta
setblock 517 200 303 minecraft:white_concrete
fill 517 200 304 517 207 304 minecraft:brown_terracotta
fill 517 200 306 517 205 306 minecraft:brown_terracotta
setblock 517 200 307 minecraft:white_concrete
fill 517 200 308 517 205 308 minecraft:brown_terracotta
fill 517 200 310 517 207 310 minecraft:brown_terracotta
setblock 517 200 311 minecraft:white_concrete
fill 517 200 312 517 207 312 minecraft:brown_terracotta
fill 517 200 314 517 207 314 minecraft:brown_terracotta
setblock 517 200 315 minecraft:white_concrete
fill 517 200 316 517 207 316 minecraft:brown_terracotta
setblock 517 200 317 minecraft:white_concrete
fill 518 200 275 518 207 275 minecraft:brown_terracotta
fill 518 200 317 518 205 317 minecraft:brown_terracotta
fill 519 200 285 519 205 287 minecraft:white_concrete
fill 519 200 297 519 205 299 minecraft:white_concrete
fill 519 200 309 519 205 311 minecraft:white_concrete
fill 520 200 275 520 207 275 minecraft:brown_terracotta
fill 520 200 317 520 205 317 minecraft:brown_terracotta
setblock 521 200 275 minecraft:white_concrete
setblock 521 200 317 minecraft:white_concrete
fill 522 200 275 522 207 275 minecraft:brown_terracotta
fill 522 200 317 522 207 317 minecraft:brown_terracotta
fill 524 200 275 524 205 275 minecraft:brown_terracotta
fill 524 200 317 524 207 317 minecraft:brown_terracotta
setblock 525 200 275 minecraft:white_concrete
fill 525 200 315 527 205 315 minecraft:white_concrete
setblock 525 200 317 minecraft:white_concrete
fill 526 200 275 526 205 275 minecraft:brown_terracotta
fill 526 200 317 526 207 317 minecraft:brown_terracotta
fill 528 200 275 528 207 275 minecraft:brown_terracotta
fill 528 200 317 528 207 317 minecraft:brown_terracotta
setblock 529 200 275 minecraft:white_concrete
fill 529 200 277 531 205 277 minecraft:white_concrete
setblock 529 200 317 minecraft:white_concrete
fill 530 200 275 530 207 275 minecraft:brown_terracotta
fill 530 200 317 530 205 317 minecraft:brown_terracotta
fill 532 200 275 532 207 275 minecraft:brown_terracotta
fill 532 200 317 532 205 317 minecraft:brown_terracotta
setblock 533 200 275 minecraft:white_concrete
setblock 533 200 317 minecraft:white_concrete
fill 534 200 275 534 207 275 minecraft:brown_terracotta
fill 534 200 317 534 207 317 minecraft:brown_terracotta
fill 536 200 275 536 205 275 minecraft:brown_terracotta
fill 536 200 317 536 207 317 minecraft:brown_terracotta
setblock 537 200 275 minecraft:white_concrete
fill 537 200 315 539 205 315 minecraft:white_concrete
setblock 537 200 317 minecraft:white_concrete
fill 538 200 275 538 205 275 minecraft:brown_terracotta
fill 538 200 317 538 207 317 minecraft:brown_terracotta
fill 540 200 275 540 207 275 minecraft:brown_terracotta
fill 540 200 317 540 207 317 minecraft:brown_terracotta
setblock 541 200 275 minecraft:white_concrete
fill 541 200 277 543 205 277 minecraft:white_concrete
setblock 541 200 317 minecraft:white_concrete
fill 542 200 275 542 207 275 minecraft:brown_terracotta
setblock 542 200 283 minecraft:spruce_leaves[persistent=true]
fill 542 200 317 542 205 317 minecraft:brown_terracotta
setblock 543 200 280 minecraft:spruce_leaves[persistent=true]
fill 543 200 284 544 200 284 minecraft:spruce_leaves[persistent=true]
fill 544 200 275 544 207 275 minecraft:brown_terracotta
fill 544 200 282 544 201 282 minecraft:spruce_leaves[persistent=true]
fill 544 200 317 544 205 317 minecraft:brown_terracotta
setblock 545 200 275 minecraft:white_concrete
setblock 545 200 280 minecraft:spruce_leaves[persistent=true]
setblock 545 200 317 minecraft:white_concrete
fill 546 200 275 546 207 275 minecraft:brown_terracotta
setblock 546 200 282 minecraft:spruce_leaves[persistent=true]
fill 546 200 317 546 207 317 minecraft:brown_terracotta
fill 548 200 275 548 205 275 minecraft:brown_terracotta
fill 548 200 298 548 201 299 minecraft:white_concrete
fill 548 200 317 548 207 317 minecraft:brown_terracotta
setblock 549 200 275 minecraft:white_concrete
fill 549 200 315 551 205 315 minecraft:white_concrete
setblock 549 200 317 minecraft:white_concrete
fill 550 200 275 550 205 275 minecraft:brown_terracotta
fill 550 200 317 550 207 317 minecraft:brown_terracotta
fill 552 200 275 552 207 275 minecraft:brown_terracotta
fill 552 200 317 552 207 317 minecraft:brown_terracotta
setblock 553 200 275 minecraft:white_concrete
fill 553 200 277 555 205 277 minecraft:white_concrete
setblock 553 200 317 minecraft:white_concrete
fill 554 200 275 554 207 275 minecraft:brown_terracotta
fill 554 200 317 554 205 317 minecraft:brown_terracotta
fill 556 200 275 556 207 275 minecraft:brown_terracotta
fill 556 200 317 556 205 317 minecraft:brown_terracotta
setblock 557 200 275 minecraft:white_concrete
fill 557 200 285 557 205 287 minecraft:white_concrete
fill 557 200 297 557 205 299 minecraft:white_concrete
fill 557 200 309 557 205 311 minecraft:white_concrete
setblock 557 200 317 minecraft:white_concrete
fill 558 200 275 558 207 275 minecraft:brown_terracotta
fill 558 200 317 558 207 317 minecraft:brown_terracotta
setblock 559 200 275 minecraft:white_concrete
fill 559 200 276 559 205 276 minecraft:brown_terracotta
fill 559 200 278 559 205 278 minecraft:brown_terracotta
setblock 559 200 279 minecraft:white_concrete
fill 559 200 280 559 207 280 minecraft:brown_terracotta
fill 559 200 282 559 207 282 minecraft:brown_terracotta
setblock 559 200 283 minecraft:white_concrete
fill 559 200 284 559 207 284 minecraft:brown_terracotta
fill 559 200 286 559 207 286 minecraft:brown_terracotta
setblock 559 200 287 minecraft:white_concrete
fill 559 200 288 559 205 288 minecraft:brown_terracotta
fill 559 200 290 559 205 290 minecraft:brown_terracotta
setblock 559 200 291 minecraft:white_concrete
fill 559 200 292 559 207 292 minecraft:brown_terracotta
fill 559 200 294 559 207 294 minecraft:brown_terracotta
setblock 559 200 295 minecraft:white_concrete
fill 559 200 296 559 207 296 minecraft:brown_terracotta
fill 559 200 298 559 207 298 minecraft:brown_terracotta
setblock 559 200 299 minecraft:white_concrete
fill 559 200 300 559 205 300 minecraft:brown_terracotta
fill 559 200 302 559 205 302 minecraft:brown_terracotta
setblock 559 200 303 minecraft:white_concrete
fill 559 200 304 559 207 304 minecraft:brown_terracotta
fill 559 200 306 559 207 306 minecraft:brown_terracotta
setblock 559 200 307 minecraft:white_concrete
fill 559 200 308 559 207 308 minecraft:brown_terracotta
fill 559 200 310 559 207 310 minecraft:brown_terracotta
setblock 559 200 311 minecraft:white_concrete
fill 559 200 312 559 205 312 minecraft:brown_terracotta
fill 559 200 314 559 205 314 minecraft:brown_terracotta
setblock 559 200 315 minecraft:white_concrete
fill 559 200 316 559 207 316 minecraft:brown_terracotta
fill 517 201 275 517 208 275 minecraft:brown_terracotta
fill 517 201 279 517 208 279 minecraft:brown_terracotta
fill 517 201 283 517 205 283 minecraft:brown_terracotta
fill 517 201 287 517 208 287 minecraft:brown_terracotta
fill 517 201 291 517 208 291 minecraft:brown_terracotta
fill 517 201 295 517 205 295 minecraft:brown_terracotta
fill 517 201 299 517 208 299 minecraft:brown_terracotta
fill 517 201 303 517 208 303 minecraft:brown_terracotta
fill 517 201 307 517 205 307 minecraft:brown_terracotta
fill 517 201 311 517 208 311 minecraft:brown_terracotta
fill 517 201 315 517 208 315 minecraft:brown_terracotta
fill 517 201 317 517 205 317 minecraft:brown_terracotta
setblock 520 201 278 minecraft:light[level=12]
setblock 520 201 285 minecraft:light[level=12]
setblock 520 201 292 minecraft:light[level=12]
setblock 520 201 299 minecraft:light[level=12]
setblock 520 201 306 minecraft:light[level=12]
setblock 520 201 313 minecraft:light[level=12]
fill 521 201 275 521 208 275 minecraft:brown_terracotta
fill 521 201 317 521 208 317 minecraft:brown_terracotta
fill 525 201 275 525 205 275 minecraft:brown_terracotta
fill 525 201 317 525 208 317 minecraft:brown_terracotta
setblock 527 201 278 minecraft:light[level=12]
setblock 527 201 285 minecraft:light[level=12]
setblock 527 201 292 minecraft:light[level=12]
setblock 527 201 299 minecraft:light[level=12]
setblock 527 201 306 minecraft:light[level=12]
setblock 527 201 313 minecraft:light[level=12]
fill 529 201 275 529 208 275 minecraft:brown_terracotta
fill 529 201 317 529 205 317 minecraft:brown_terracotta
fill 533 201 275 533 208 275 minecraft:brown_terracotta
fill 533 201 317 533 208 317 minecraft:brown_terracotta
setblock 534 201 278 minecraft:light[level=12]
setblock 534 201 285 minecraft:light[level=12]
setblock 534 201 292 minecraft:light[level=12]
setblock 534 201 299 minecraft:light[level=12]
setblock 534 201 306 minecraft:light[level=12]
setblock 534 201 313 minecraft:light[level=12]
fill 537 201 275 537 205 275 minecraft:brown_terracotta
fill 537 201 317 537 208 317 minecraft:brown_terracotta
fill 541 201 275 541 208 275 minecraft:brown_terracotta
setblock 541 201 278 minecraft:light[level=12]
setblock 541 201 285 minecraft:light[level=12]
setblock 541 201 292 minecraft:light[level=12]
setblock 541 201 299 minecraft:light[level=12]
setblock 541 201 306 minecraft:light[level=12]
setblock 541 201 313 minecraft:light[level=12]
fill 541 201 317 541 205 317 minecraft:brown_terracotta
fill 545 201 275 545 208 275 minecraft:brown_terracotta
fill 545 201 317 545 208 317 minecraft:brown_terracotta
setblock 548 201 278 minecraft:light[level=12]
setblock 548 201 285 minecraft:light[level=12]
setblock 548 201 292 minecraft:light[level=12]
setblock 548 201 306 minecraft:light[level=12]
setblock 548 201 313 minecraft:light[level=12]
fill 549 201 275 549 205 275 minecraft:brown_terracotta
fill 549 201 317 549 208 317 minecraft:brown_terracotta
fill 553 201 275 553 208 275 minecraft:brown_terracotta
fill 553 201 317 553 205 317 minecraft:brown_terracotta
setblock 555 201 278 minecraft:light[level=12]
setblock 555 201 285 minecraft:light[level=12]
setblock 555 201 292 minecraft:light[level=12]
setblock 555 201 299 minecraft:light[level=12]
setblock 555 201 306 minecraft:light[level=12]
setblock 555 201 313 minecraft:light[level=12]
fill 557 201 275 557 208 275 minecraft:brown_terracotta
fill 557 201 317 557 208 317 minecraft:brown_terracotta
fill 559 201 275 559 206 275 minecraft:brown_terracotta
fill 559 201 279 559 205 279 minecraft:brown_terracotta
fill 559 201 283 559 208 283 minecraft:brown_terracotta
fill 559 201 287 559 208 287 minecraft:brown_terracotta
fill 559 201 291 559 205 291 minecraft:brown_terracotta
fill 559 201 295 559 208 295 minecraft:brown_terracotta
fill 559 201 299 559 208 299 minecraft:brown_terracotta
fill 559 201 303 559 205 303 minecraft:brown_terracotta
fill 559 201 307 559 208 307 minecraft:brown_terracotta
fill 559 201 311 559 208 311 minecraft:brown_terracotta
fill 559 201 315 559 205 315 minecraft:brown_terracotta
fill 554 202 302 554 203 302 minecraft:white_concrete
setblock 520 203 278 minecraft:light[level=15]
fill 520 203 279 520 203 281 minecraft:brown_terracotta
setblock 520 203 286 minecraft:light[level=15]
setblock 520 203 294 minecraft:light[level=15]
setblock 520 203 302 minecraft:light[level=15]
setblock 520 203 310 minecraft:light[level=15]
fill 521 203 278 523 203 278 minecraft:brown_terracotta
setblock 521 203 282 minecraft:brown_terracotta
setblock 523 203 282 minecraft:brown_terracotta
fill 524 203 279 524 203 281 minecraft:brown_terracotta
setblock 528 203 278 minecraft:light[level=15]
setblock 528 203 286 minecraft:light[level=15]
setblock 528 203 294 minecraft:light[level=15]
setblock 528 203 302 minecraft:light[level=15]
setblock 528 203 310 minecraft:light[level=15]
setblock 536 203 278 minecraft:light[level=15]
setblock 536 203 286 minecraft:light[level=15]
setblock 536 203 294 minecraft:light[level=15]
setblock 536 203 302 minecraft:light[level=15]
setblock 536 203 310 minecraft:light[level=15]
setblock 544 203 278 minecraft:light[level=15]
setblock 544 203 286 minecraft:light[level=15]
setblock 544 203 294 minecraft:light[level=15]
setblock 544 203 302 minecraft:light[level=15]
setblock 544 203 310 minecraft:light[level=15]
setblock 552 203 278 minecraft:light[level=15]
setblock 552 203 286 minecraft:light[level=15]
setblock 552 203 294 minecraft:light[level=15]
setblock 552 203 302 minecraft:light[level=15]
setblock 552 203 310 minecraft:light[level=15]
fill 553 203 278 553 203 279 minecraft:brown_terracotta
setblock 553 203 281 minecraft:brown_terracotta
fill 554 203 278 556 203 278 minecraft:brown_terracotta
fill 554 203 282 556 203 282 minecraft:brown_terracotta
fill 557 203 279 557 203 281 minecraft:brown_terracotta
fill 529 204 314 529 213 314 minecraft:red_wool
fill 518 205 279 518 205 284 minecraft:brown_terracotta
fill 518 205 291 518 205 296 minecraft:brown_terracotta
fill 518 205 303 518 205 308 minecraft:brown_terracotta
fill 518 205 315 518 205 316 minecraft:brown_terracotta
fill 519 205 316 522 205 316 minecraft:brown_terracotta
fill 522 205 276 527 205 276 minecraft:brown_terracotta
fill 527 205 314 528 213 314 minecraft:red_wool
fill 529 205 316 534 205 316 minecraft:brown_terracotta
fill 530 205 314 531 213 314 minecraft:red_wool
fill 532 205 287 533 206 288 minecraft:red_concrete
fill 534 205 276 539 205 276 minecraft:brown_terracotta
fill 535 205 305 535 206 306 minecraft:red_concrete
fill 541 205 316 546 205 316 minecraft:brown_terracotta
fill 546 205 276 551 205 276 minecraft:brown_terracotta
fill 553 205 316 558 205 316 minecraft:brown_terracotta
fill 558 205 276 558 205 281 minecraft:brown_terracotta
fill 558 205 288 558 205 293 minecraft:brown_terracotta
fill 558 205 300 558 205 305 minecraft:brown_terracotta
fill 558 205 312 558 205 315 minecraft:brown_terracotta
fill 517 206 281 517 211 284 minecraft:shroomlight
fill 517 206 293 517 211 296 minecraft:shroomlight
fill 517 206 305 517 211 308 minecraft:shroomlight
fill 517 206 317 520 211 317 minecraft:shroomlight
fill 524 206 275 527 211 275 minecraft:shroomlight
fill 529 206 317 532 211 317 minecraft:shroomlight
fill 536 206 275 539 211 275 minecraft:shroomlight
fill 541 206 317 544 211 317 minecraft:shroomlight
fill 548 206 275 551 211 275 minecraft:shroomlight
fill 553 206 317 556 211 317 minecraft:shroomlight
fill 559 206 276 559 211 279 minecraft:shroomlight
fill 559 206 288 559 211 291 minecraft:shroomlight
fill 559 206 300 559 211 303 minecraft:shroomlight
fill 559 206 312 559 211 315 minecraft:shroomlight
setblock 517 207 277 minecraft:white_concrete
setblock 517 207 285 minecraft:white_concrete
setblock 517 207 289 minecraft:white_concrete
setblock 517 207 297 minecraft:white_concrete
setblock 517 207 301 minecraft:white_concrete
setblock 517 207 309 minecraft:white_concrete
setblock 517 207 313 minecraft:white_concrete
fill 518 207 283 522 207 287 minecraft:orange_terracotta
setblock 519 207 275 minecraft:white_concrete
setblock 520 207 278 minecraft:light[level=12]
setblock 520 207 292 minecraft:light[level=12]
setblock 520 207 299 minecraft:light[level=12]
setblock 520 207 306 minecraft:light[level=12]
setblock 520 207 313 minecraft:light[level=12]
setblock 523 207 275 minecraft:white_concrete
setblock 523 207 317 minecraft:white_concrete
setblock 527 207 278 minecraft:light[level=12]
setblock 527 207 285 minecraft:light[level=12]
setblock 527 207 292 minecraft:light[level=12]
setblock 527 207 299 minecraft:light[level=12]
setblock 527 207 306 minecraft:light[level=12]
setblock 527 207 313 minecraft:light[level=12]
setblock 527 207 317 minecraft:white_concrete
setblock 531 207 275 minecraft:white_concrete
fill 532 207 311 532 208 312 minecraft:white_concrete
setblock 534 207 278 minecraft:light[level=12]
setblock 534 207 285 minecraft:light[level=12]
setblock 534 207 292 minecraft:light[level=12]
setblock 534 207 299 minecraft:light[level=12]
setblock 534 207 306 minecraft:light[level=12]
setblock 534 207 313 minecraft:light[level=12]
setblock 535 207 275 minecraft:white_concrete
setblock 535 207 317 minecraft:white_concrete
setblock 539 207 317 minecraft:white_concrete
setblock 541 207 278 minecraft:light[level=12]
setblock 541 207 285 minecraft:light[level=12]
setblock 541 207 292 minecraft:light[level=12]
setblock 541 207 299 minecraft:light[level=12]
setblock 541 207 306 minecraft:light[level=12]
setblock 541 207 313 minecraft:light[level=12]
setblock 543 207 275 minecraft:white_concrete
setblock 547 207 275 minecraft:white_concrete
setblock 547 207 317 minecraft:white_concrete
setblock 548 207 278 minecraft:light[level=12]
setblock 548 207 285 minecraft:light[level=12]
setblock 548 207 292 minecraft:light[level=12]
setblock 548 207 299 minecraft:light[level=12]
setblock 548 207 306 minecraft:light[level=12]
setblock 548 207 313 minecraft:light[level=12]
setblock 551 207 317 minecraft:white_concrete
setblock 555 207 275 minecraft:white_concrete
setblock 555 207 278 minecraft:light[level=12]
setblock 555 207 285 minecraft:light[level=12]
setblock 555 207 292 minecraft:light[level=12]
setblock 555 207 299 minecraft:light[level=12]
setblock 555 207 306 minecraft:light[level=12]
setblock 555 207 313 minecraft:light[level=12]
setblock 559 207 275 minecraft:white_concrete
setblock 559 207 281 minecraft:white_concrete
setblock 559 207 285 minecraft:white_concrete
setblock 559 207 293 minecraft:white_concrete
setblock 559 207 297 minecraft:white_concrete
setblock 559 207 305 minecraft:white_concrete
setblock 559 207 309 minecraft:white_concrete
setblock 559 207 317 minecraft:white_concrete
setblock 517 208 276 minecraft:white_concrete
fill 517 208 277 517 215 277 minecraft:brown_terracotta
setblock 517 208 278 minecraft:white_concrete
setblock 517 208 280 minecraft:white_concrete
fill 517 208 285 517 215 285 minecraft:brown_terracotta
setblock 517 208 286 minecraft:white_concrete
setblock 517 208 288 minecraft:white_concrete
fill 517 208 289 517 215 289 minecraft:brown_terracotta
setblock 517 208 290 minecraft:white_concrete
setblock 517 208 292 minecraft:white_concrete
fill 517 208 297 517 215 297 minecraft:brown_terracotta
setblock 517 208 298 minecraft:white_concrete
setblock 517 208 300 minecraft:white_concrete
fill 517 208 301 517 215 301 minecraft:brown_terracotta
setblock 517 208 302 minecraft:white_concrete
setblock 517 208 304 minecraft:white_concrete
fill 517 208 309 517 215 309 minecraft:brown_terracotta
setblock 517 208 310 minecraft:white_concrete
setblock 517 208 312 minecraft:white_concrete
fill 517 208 313 517 215 313 minecraft:brown_terracotta
setblock 517 208 314 minecraft:white_concrete
setblock 517 208 316 minecraft:white_concrete
setblock 518 208 275 minecraft:white_concrete
fill 518 208 283 519 211 287 minecraft:orange_terracotta
fill 519 208 275 519 215 275 minecraft:brown_terracotta
setblock 520 208 275 minecraft:white_concrete
fill 520 208 283 522 211 284 minecraft:orange_terracotta
fill 520 208 285 520 209 285 minecraft:ochre_froglight
fill 520 208 286 522 211 287 minecraft:orange_terracotta
fill 521 208 285 522 211 285 minecraft:orange_terracotta
setblock 522 208 275 minecraft:white_concrete
setblock 522 208 317 minecraft:white_concrete
fill 523 208 275 523 215 275 minecraft:brown_terracotta
fill 523 208 317 523 215 317 minecraft:brown_terracotta
setblock 524 208 317 minecraft:white_concrete
setblock 526 208 317 minecraft:white_concrete
fill 527 208 317 527 215 317 minecraft:brown_terracotta
setblock 528 208 275 minecraft:white_concrete
setblock 528 208 317 minecraft:white_concrete
setblock 530 208 275 minecraft:white_concrete
fill 531 208 275 531 215 275 minecraft:brown_terracotta
setblock 532 208 275 minecraft:white_concrete
setblock 534 208 275 minecraft:white_concrete
setblock 534 208 317 minecraft:white_concrete
fill 535 208 275 535 215 275 minecraft:brown_terracotta
fill 535 208 317 535 215 317 minecraft:brown_terracotta
setblock 536 208 317 minecraft:white_concrete
setblock 538 208 317 minecraft:white_concrete
fill 539 208 317 539 215 317 minecraft:brown_terracotta
setblock 540 208 275 minecraft:white_concrete
setblock 540 208 317 minecraft:white_concrete
setblock 542 208 275 minecraft:white_concrete
fill 543 208 275 543 215 275 minecraft:brown_terracotta
setblock 544 208 275 minecraft:white_concrete
setblock 546 208 275 minecraft:white_concrete
setblock 546 208 317 minecraft:white_concrete
fill 547 208 275 547 215 275 minecraft:brown_terracotta
fill 547 208 317 547 215 317 minecraft:brown_terracotta
setblock 548 208 317 minecraft:white_concrete
setblock 550 208 317 minecraft:white_concrete
fill 551 208 317 551 215 317 minecraft:brown_terracotta
setblock 552 208 275 minecraft:white_concrete
setblock 552 208 317 minecraft:white_concrete
setblock 554 208 275 minecraft:white_concrete
fill 555 208 275 555 215 275 minecraft:brown_terracotta
setblock 556 208 275 minecraft:white_concrete
setblock 558 208 275 minecraft:white_concrete
setblock 558 208 317 minecraft:white_concrete
setblock 559 208 275 minecraft:brown_terracotta
setblock 559 208 280 minecraft:white_concrete
fill 559 208 281 559 215 281 minecraft:brown_terracotta
setblock 559 208 282 minecraft:white_concrete
setblock 559 208 284 minecraft:white_concrete
fill 559 208 285 559 215 285 minecraft:brown_terracotta
setblock 559 208 286 minecraft:white_concrete
setblock 559 208 292 minecraft:white_concrete
fill 559 208 293 559 215 293 minecraft:brown_terracotta
setblock 559 208 294 minecraft:white_concrete
setblock 559 208 296 minecraft:white_concrete
fill 559 208 297 559 215 297 minecraft:brown_terracotta
setblock 559 208 298 minecraft:white_concrete
setblock 559 208 304 minecraft:white_concrete
fill 559 208 305 559 215 305 minecraft:brown_terracotta
setblock 559 208 306 minecraft:white_concrete
setblock 559 208 308 minecraft:white_concrete
fill 559 208 309 559 215 309 minecraft:brown_terracotta
setblock 559 208 310 minecraft:white_concrete
setblock 559 208 316 minecraft:white_concrete
fill 559 208 317 559 215 317 minecraft:brown_terracotta
setblock 517 209 275 minecraft:white_concrete
fill 517 209 276 517 216 276 minecraft:brown_terracotta
fill 517 209 278 517 216 278 minecraft:brown_terracotta
setblock 517 209 279 minecraft:white_concrete
fill 517 209 280 517 216 280 minecraft:brown_terracotta
fill 517 209 286 517 216 286 minecraft:brown_terracotta
setblock 517 209 287 minecraft:white_concrete
fill 517 209 288 517 216 288 minecraft:brown_terracotta
fill 517 209 290 517 216 290 minecraft:brown_terracotta
setblock 517 209 291 minecraft:white_concrete
fill 517 209 292 517 216 292 minecraft:brown_terracotta
fill 517 209 298 517 216 298 minecraft:brown_terracotta
setblock 517 209 299 minecraft:white_concrete
fill 517 209 300 517 216 300 minecraft:brown_terracotta
fill 517 209 302 517 216 302 minecraft:brown_terracotta
setblock 517 209 303 minecraft:white_concrete
fill 517 209 304 517 216 304 minecraft:brown_terracotta
fill 517 209 310 517 216 310 minecraft:brown_terracotta
setblock 517 209 311 minecraft:white_concrete
fill 517 209 312 517 216 312 minecraft:brown_terracotta
fill 517 209 314 517 216 314 minecraft:brown_terracotta
setblock 517 209 315 minecraft:white_concrete
fill 517 209 316 517 216 316 minecraft:brown_terracotta
fill 518 209 275 518 216 275 minecraft:brown_terracotta
fill 518 209 290 522 209 294 minecraft:orange_terracotta
fill 520 209 275 520 216 275 minecraft:brown_terracotta
setblock 521 209 275 minecraft:white_concrete
setblock 521 209 317 minecraft:white_concrete
fill 522 209 275 522 216 275 minecraft:brown_terracotta
fill 522 209 317 522 216 317 minecraft:brown_terracotta
fill 524 209 317 524 216 317 minecraft:brown_terracotta
setblock 525 209 317 minecraft:white_concrete
fill 526 209 317 526 216 317 minecraft:brown_terracotta
fill 528 209 275 528 216 275 minecraft:brown_terracotta
fill 528 209 317 528 216 317 minecraft:brown_terracotta
setblock 529 209 275 minecraft:white_concrete
fill 530 209 275 530 216 275 minecraft:brown_terracotta
fill 532 209 275 532 216 275 minecraft:brown_terracotta
setblock 533 209 275 minecraft:white_concrete
setblock 533 209 317 minecraft:white_concrete
fill 534 209 275 534 216 275 minecraft:brown_terracotta
fill 534 209 317 534 216 317 minecraft:brown_terracotta
fill 536 209 317 536 216 317 minecraft:brown_terracotta
setblock 537 209 317 minecraft:white_concrete
fill 538 209 317 538 216 317 minecraft:brown_terracotta
fill 540 209 275 540 216 275 minecraft:brown_terracotta
fill 540 209 317 540 216 317 minecraft:brown_terracotta
setblock 541 209 275 minecraft:white_concrete
fill 542 209 275 542 216 275 minecraft:brown_terracotta
fill 544 209 275 544 216 275 minecraft:brown_terracotta
setblock 545 209 275 minecraft:white_concrete
setblock 545 209 317 minecraft:white_concrete
fill 546 209 275 546 216 275 minecraft:brown_terracotta
fill 546 209 317 546 216 317 minecraft:brown_terracotta
fill 548 209 317 548 216 317 minecraft:brown_terracotta
setblock 549 209 317 minecraft:white_concrete
fill 550 209 317 550 216 317 minecraft:brown_terracotta
fill 552 209 275 552 216 275 minecraft:brown_terracotta
fill 552 209 317 552 216 317 minecraft:brown_terracotta
setblock 553 209 275 minecraft:white_concrete
fill 554 209 275 554 216 275 minecraft:brown_terracotta
fill 556 209 275 556 216 275 minecraft:brown_terracotta
setblock 557 209 275 minecraft:white_concrete
setblock 557 209 317 minecraft:white_concrete
fill 558 209 275 558 216 275 minecraft:brown_terracotta
fill 558 209 317 558 216 317 minecraft:brown_terracotta
setblock 559 209 275 minecraft:white_concrete
fill 559 209 280 559 216 280 minecraft:brown_terracotta
fill 559 209 282 559 216 282 minecraft:brown_terracotta
setblock 559 209 283 minecraft:white_concrete
fill 559 209 284 559 216 284 minecraft:brown_terracotta
fill 559 209 286 559 216 286 minecraft:brown_terracotta
setblock 559 209 287 minecraft:white_concrete
fill 559 209 292 559 216 292 minecraft:brown_terracotta
fill 559 209 294 559 216 294 minecraft:brown_terracotta
setblock 559 209 295 minecraft:white_concrete
fill 559 209 296 559 216 296 minecraft:brown_terracotta
fill 559 209 298 559 216 298 minecraft:brown_terracotta
setblock 559 209 299 minecraft:white_concrete
fill 559 209 304 559 216 304 minecraft:brown_terracotta
fill 559 209 306 559 216 306 minecraft:brown_terracotta
setblock 559 209 307 minecraft:white_concrete
fill 559 209 308 559 216 308 minecraft:brown_terracotta
fill 559 209 310 559 216 310 minecraft:brown_terracotta
setblock 559 209 311 minecraft:white_concrete
fill 559 209 316 559 216 316 minecraft:brown_terracotta
fill 517 210 275 517 217 275 minecraft:brown_terracotta
fill 517 210 279 517 217 279 minecraft:brown_terracotta
fill 517 210 287 517 217 287 minecraft:brown_terracotta
fill 517 210 291 517 217 291 minecraft:brown_terracotta
fill 517 210 299 517 217 299 minecraft:brown_terracotta
fill 517 210 303 517 217 303 minecraft:brown_terracotta
fill 517 210 311 517 217 311 minecraft:brown_terracotta
fill 517 210 315 517 217 315 minecraft:brown_terracotta
fill 518 210 290 519 213 294 minecraft:orange_terracotta
fill 520 210 285 520 211 285 minecraft:orange_terracotta
fill 520 210 290 522 213 291 minecraft:orange_terracotta
fill 520 210 292 520 211 292 minecraft:ochre_froglight
fill 520 210 293 522 213 294 minecraft:orange_terracotta
fill 521 210 275 521 217 275 minecraft:brown_terracotta
fill 521 210 292 522 213 292 minecraft:orange_terracotta
fill 521 210 317 521 217 317 minecraft:brown_terracotta
fill 525 210 317 525 217 317 minecraft:brown_terracotta
fill 529 210 275 529 217 275 minecraft:brown_terracotta
fill 533 210 275 533 217 275 minecraft:brown_terracotta
fill 533 210 317 533 217 317 minecraft:brown_terracotta
fill 537 210 317 537 217 317 minecraft:brown_terracotta
fill 541 210 275 541 217 275 minecraft:brown_terracotta
fill 545 210 275 545 217 275 minecraft:brown_terracotta
fill 545 210 317 545 217 317 minecraft:brown_terracotta
fill 549 210 317 549 217 317 minecraft:brown_terracotta
fill 553 210 275 553 217 275 minecraft:brown_terracotta
fill 557 210 275 557 217 275 minecraft:brown_terracotta
fill 557 210 317 557 217 317 minecraft:brown_terracotta
fill 559 210 275 559 215 275 minecraft:brown_terracotta
fill 559 210 283 559 217 283 minecraft:brown_terracotta
fill 559 210 287 559 217 287 minecraft:brown_terracotta
fill 559 210 295 559 217 295 minecraft:brown_terracotta
fill 559 210 299 559 217 299 minecraft:brown_terracotta
fill 559 210 307 559 217 307 minecraft:brown_terracotta
fill 559 210 311 559 217 311 minecraft:brown_terracotta
setblock 520 211 278 minecraft:light[level=15]
fill 520 211 279 520 211 281 minecraft:brown_terracotta
setblock 520 211 302 minecraft:light[level=15]
setblock 520 211 310 minecraft:light[level=15]
fill 521 211 278 523 211 278 minecraft:brown_terracotta
setblock 521 211 282 minecraft:brown_terracotta
setblock 523 211 282 minecraft:brown_terracotta
fill 524 211 279 524 211 281 minecraft:brown_terracotta
setblock 528 211 278 minecraft:light[level=15]
setblock 528 211 286 minecraft:light[level=15]
setblock 528 211 294 minecraft:light[level=15]
setblock 528 211 302 minecraft:light[level=15]
setblock 528 211 310 minecraft:light[level=15]
setblock 536 211 278 minecraft:light[level=15]
setblock 536 211 286 minecraft:light[level=15]
setblock 536 211 294 minecraft:light[level=15]
setblock 536 211 302 minecraft:light[level=15]
setblock 536 211 310 minecraft:light[level=15]
setblock 544 211 278 minecraft:light[level=15]
setblock 544 211 286 minecraft:light[level=15]
setblock 544 211 294 minecraft:light[level=15]
setblock 544 211 302 minecraft:light[level=15]
setblock 544 211 310 minecraft:light[level=15]
setblock 552 211 278 minecraft:light[level=15]
setblock 552 211 286 minecraft:light[level=15]
setblock 552 211 294 minecraft:light[level=15]
setblock 552 211 302 minecraft:light[level=15]
setblock 552 211 310 minecraft:light[level=15]
fill 553 211 278 553 211 279 minecraft:brown_terracotta
setblock 553 211 281 minecraft:brown_terracotta
fill 554 211 278 556 211 278 minecraft:brown_terracotta
fill 554 211 282 556 211 282 minecraft:brown_terracotta
fill 557 211 279 557 211 281 minecraft:brown_terracotta
fill 517 212 281 517 215 281 minecraft:brown_terracotta
fill 517 212 282 517 212 283 minecraft:shroomlight
fill 517 212 284 517 216 284 minecraft:brown_terracotta
fill 517 212 293 517 215 293 minecraft:brown_terracotta
fill 517 212 294 517 212 295 minecraft:shroomlight
fill 517 212 296 517 216 296 minecraft:brown_terracotta
fill 517 212 305 517 215 305 minecraft:brown_terracotta
fill 517 212 306 517 212 307 minecraft:shroomlight
fill 517 212 308 517 216 308 minecraft:brown_terracotta
fill 517 212 317 517 215 317 minecraft:brown_terracotta
fill 518 212 283 522 212 287 minecraft:white_concrete
fill 518 212 317 519 212 317 minecraft:shroomlight
fill 520 212 292 520 213 292 minecraft:orange_terracotta
fill 520 212 317 520 216 317 minecraft:brown_terracotta
fill 524 212 275 524 216 275 minecraft:brown_terracotta
fill 525 212 275 526 212 275 minecraft:shroomlight
fill 527 212 275 527 215 275 minecraft:brown_terracotta
fill 529 212 317 529 217 317 minecraft:brown_terracotta
fill 530 212 317 531 212 317 minecraft:shroomlight
fill 532 212 317 532 216 317 minecraft:brown_terracotta
fill 536 212 275 536 216 275 minecraft:brown_terracotta
fill 537 212 275 538 212 275 minecraft:shroomlight
fill 539 212 275 539 215 275 minecraft:brown_terracotta
fill 541 212 317 541 217 317 minecraft:brown_terracotta
fill 542 212 317 543 212 317 minecraft:shroomlight
fill 544 212 317 544 216 317 minecraft:brown_terracotta
fill 548 212 275 548 216 275 minecraft:brown_terracotta
fill 549 212 275 550 212 275 minecraft:shroomlight
fill 551 212 275 551 215 275 minecraft:brown_terracotta
fill 553 212 317 553 217 317 minecraft:brown_terracotta
fill 554 212 317 555 212 317 minecraft:shroomlight
fill 556 212 317 556 216 317 minecraft:brown_terracotta
fill 559 212 276 559 216 276 minecraft:brown_terracotta
fill 559 212 277 559 212 278 minecraft:shroomlight
fill 559 212 279 559 217 279 minecraft:brown_terracotta
fill 559 212 288 559 216 288 minecraft:brown_terracotta
fill 559 212 289 559 212 290 minecraft:shroomlight
fill 559 212 291 559 217 291 minecraft:brown_terracotta
fill 559 212 300 559 216 300 minecraft:brown_terracotta
fill 559 212 301 559 212 302 minecraft:shroomlight
fill 559 212 303 559 217 303 minecraft:brown_terracotta
fill 559 212 312 559 216 312 minecraft:brown_terracotta
fill 559 212 313 559 212 314 minecraft:shroomlight
fill 559 212 315 559 217 315 minecraft:brown_terracotta
fill 517 213 282 517 216 283 minecraft:brown_terracotta
fill 517 213 294 517 216 295 minecraft:brown_terracotta
fill 517 213 306 517 216 307 minecraft:brown_terracotta
fill 518 213 286 521 213 287 minecraft:white_concrete
fill 518 213 317 519 215 317 minecraft:brown_terracotta
fill 519 213 283 521 213 285 minecraft:white_concrete
setblock 520 213 278 minecraft:light[level=12]
setblock 520 213 299 minecraft:light[level=12]
setblock 520 213 306 minecraft:light[level=12]
setblock 520 213 313 minecraft:light[level=12]
fill 525 213 275 526 216 275 minecraft:brown_terracotta
setblock 527 213 278 minecraft:light[level=12]
setblock 527 213 285 minecraft:light[level=12]
setblock 527 213 292 minecraft:light[level=12]
setblock 527 213 299 minecraft:light[level=12]
setblock 527 213 306 minecraft:light[level=12]
setblock 527 213 313 minecraft:light[level=12]
fill 530 213 317 531 215 317 minecraft:brown_terracotta
setblock 534 213 278 minecraft:light[level=12]
setblock 534 213 285 minecraft:light[level=12]
setblock 534 213 292 minecraft:light[level=12]
setblock 534 213 299 minecraft:light[level=12]
setblock 534 213 306 minecraft:light[level=12]
setblock 534 213 313 minecraft:light[level=12]
fill 537 213 275 538 216 275 minecraft:brown_terracotta
setblock 541 213 278 minecraft:light[level=12]
setblock 541 213 285 minecraft:light[level=12]
setblock 541 213 292 minecraft:light[level=12]
setblock 541 213 299 minecraft:light[level=12]
setblock 541 213 306 minecraft:light[level=12]
setblock 541 213 313 minecraft:light[level=12]
fill 542 213 317 543 215 317 minecraft:brown_terracotta
setblock 548 213 278 minecraft:light[level=12]
setblock 548 213 285 minecraft:light[level=12]
setblock 548 213 292 minecraft:light[level=12]
setblock 548 213 299 minecraft:light[level=12]
setblock 548 213 306 minecraft:light[level=12]
setblock 548 213 313 minecraft:light[level=12]
fill 549 213 275 550 216 275 minecraft:brown_terracotta
fill 554 213 317 555 215 317 minecraft:brown_terracotta
setblock 555 213 278 minecraft:light[level=12]
setblock 555 213 285 minecraft:light[level=12]
setblock 555 213 292 minecraft:light[level=12]
setblock 555 213 299 minecraft:light[level=12]
setblock 555 213 306 minecraft:light[level=12]
setblock 555 213 313 minecraft:light[level=12]
fill 559 213 277 559 215 278 minecraft:brown_terracotta
fill 559 213 289 559 215 290 minecraft:brown_terracotta
fill 559 213 301 559 215 302 minecraft:brown_terracotta
fill 559 213 313 559 215 314 minecraft:brown_terracotta
fill 518 214 286 518 218 287 minecraft:white_concrete
fill 518 214 290 522 214 294 minecraft:white_concrete
fill 520 214 283 520 214 287 minecraft:white_concrete
fill 526 214 314 532 215 314 minecraft:iron_block
fill 519 215 290 521 215 294 minecraft:white_concrete
fill 522 215 297 523 216 298 minecraft:lime_concrete
setblock 517 216 277 minecraft:white_concrete
setblock 517 216 281 minecraft:white_concrete
setblock 517 216 285 minecraft:white_concrete
setblock 517 216 289 minecraft:white_concrete
setblock 517 216 293 minecraft:white_concrete
setblock 517 216 297 minecraft:white_concrete
setblock 517 216 301 minecraft:white_concrete
setblock 517 216 305 minecraft:white_concrete
setblock 517 216 309 minecraft:white_concrete
setblock 517 216 313 minecraft:white_concrete
setblock 517 216 317 minecraft:white_concrete
setblock 518 216 317 minecraft:brown_terracotta
setblock 519 216 275 minecraft:white_concrete
setblock 519 216 317 minecraft:white_concrete
fill 520 216 290 520 216 294 minecraft:white_concrete
setblock 523 216 275 minecraft:white_concrete
setblock 523 216 317 minecraft:white_concrete
setblock 527 216 275 minecraft:white_concrete
setblock 527 216 317 minecraft:white_concrete
setblock 530 216 317 minecraft:brown_terracotta
setblock 531 216 275 minecraft:white_concrete
setblock 531 216 317 minecraft:white_concrete
setblock 535 216 275 minecraft:white_concrete
setblock 535 216 317 minecraft:white_concrete
setblock 539 216 275 minecraft:white_concrete
setblock 539 216 317 minecraft:white_concrete
setblock 542 216 317 minecraft:brown_terracotta
setblock 543 216 275 minecraft:white_concrete
setblock 543 216 317 minecraft:white_concrete
setblock 547 216 275 minecraft:white_concrete
setblock 547 216 317 minecraft:white_concrete
setblock 551 216 275 minecraft:white_concrete
setblock 551 216 317 minecraft:white_concrete
setblock 554 216 317 minecraft:brown_terracotta
setblock 555 216 275 minecraft:white_concrete
setblock 555 216 317 minecraft:white_concrete
setblock 559 216 275 minecraft:white_concrete
setblock 559 216 277 minecraft:white_concrete
setblock 559 216 278 minecraft:brown_terracotta
setblock 559 216 281 minecraft:white_concrete
setblock 559 216 285 minecraft:white_concrete
setblock 559 216 289 minecraft:white_concrete
setblock 559 216 290 minecraft:brown_terracotta
setblock 559 216 293 minecraft:white_concrete
setblock 559 216 297 minecraft:white_concrete
setblock 559 216 301 minecraft:white_concrete
setblock 559 216 302 minecraft:brown_terracotta
setblock 559 216 305 minecraft:white_concrete
setblock 559 216 309 minecraft:white_concrete
setblock 559 216 313 minecraft:white_concrete
setblock 559 216 314 minecraft:brown_terracotta
setblock 559 216 317 minecraft:white_concrete
setblock 517 217 276 minecraft:white_concrete
fill 517 217 277 517 224 277 minecraft:brown_terracotta
setblock 517 217 278 minecraft:white_concrete
setblock 517 217 280 minecraft:white_concrete
fill 517 217 281 517 224 281 minecraft:brown_terracotta
setblock 517 217 282 minecraft:white_concrete
setblock 517 217 283 minecraft:brown_terracotta
setblock 517 217 284 minecraft:white_concrete
fill 517 217 285 517 224 285 minecraft:brown_terracotta
setblock 517 217 286 minecraft:white_concrete
setblock 517 217 288 minecraft:white_concrete
fill 517 217 289 517 224 289 minecraft:brown_terracotta
setblock 517 217 290 minecraft:white_concrete
setblock 517 217 292 minecraft:white_concrete
fill 517 217 293 517 224 293 minecraft:brown_terracotta
setblock 517 217 294 minecraft:white_concrete
setblock 517 217 295 minecraft:brown_terracotta
setblock 517 217 296 minecraft:white_concrete
fill 517 217 297 517 224 297 minecraft:brown_terracotta
setblock 517 217 298 minecraft:white_concrete
setblock 517 217 300 minecraft:white_concrete
fill 517 217 301 517 224 301 minecraft:brown_terracotta
setblock 517 217 302 minecraft:white_concrete
setblock 517 217 304 minecraft:white_concrete
fill 517 217 305 517 224 305 minecraft:brown_terracotta
setblock 517 217 306 minecraft:white_concrete
setblock 517 217 307 minecraft:brown_terracotta
setblock 517 217 308 minecraft:white_concrete
fill 517 217 309 517 224 309 minecraft:brown_terracotta
setblock 517 217 310 minecraft:white_concrete
setblock 517 217 312 minecraft:white_concrete
fill 517 217 313 517 224 313 minecraft:brown_terracotta
setblock 517 217 314 minecraft:white_concrete
setblock 517 217 316 minecraft:white_concrete
setblock 517 217 317 minecraft:brown_terracotta
setblock 518 217 275 minecraft:white_concrete
setblock 518 217 317 minecraft:white_concrete
fill 519 217 275 519 224 275 minecraft:brown_terracotta
fill 519 217 317 519 224 317 minecraft:brown_terracotta
setblock 520 217 275 minecraft:white_concrete
fill 520 217 279 520 218 281 minecraft:red_concrete
setblock 520 217 317 minecraft:white_concrete
fill 521 217 282 521 218 282 minecraft:red_concrete
setblock 522 217 275 minecraft:white_concrete
fill 522 217 278 522 218 278 minecraft:red_concrete
setblock 522 217 317 minecraft:white_concrete
fill 523 217 275 523 224 275 minecraft:brown_terracotta
fill 523 217 282 523 218 282 minecraft:red_concrete
fill 523 217 317 523 224 317 minecraft:brown_terracotta
setblock 524 217 275 minecraft:white_concrete
fill 524 217 279 524 218 281 minecraft:red_concrete
setblock 524 217 317 minecraft:white_concrete
setblock 525 217 275 minecraft:brown_terracotta
setblock 526 217 275 minecraft:white_concrete
setblock 526 217 317 minecraft:white_concrete
fill 527 217 275 527 224 275 minecraft:brown_terracotta
fill 527 217 317 527 224 317 minecraft:brown_terracotta
setblock 528 217 275 minecraft:white_concrete
setblock 528 217 317 minecraft:white_concrete
setblock 530 217 275 minecraft:white_concrete
setblock 530 217 317 minecraft:white_concrete
fill 531 217 275 531 224 275 minecraft:brown_terracotta
fill 531 217 317 531 224 317 minecraft:brown_terracotta
setblock 532 217 275 minecraft:white_concrete
setblock 532 217 317 minecraft:white_concrete
setblock 534 217 275 minecraft:white_concrete
setblock 534 217 317 minecraft:white_concrete
fill 535 217 275 535 224 275 minecraft:brown_terracotta
fill 535 217 317 535 224 317 minecraft:brown_terracotta
setblock 536 217 275 minecraft:white_concrete
setblock 536 217 317 minecraft:white_concrete
setblock 537 217 275 minecraft:brown_terracotta
setblock 538 217 275 minecraft:white_concrete
setblock 538 217 317 minecraft:white_concrete
fill 539 217 275 539 224 275 minecraft:brown_terracotta
fill 539 217 317 539 224 317 minecraft:brown_terracotta
setblock 540 217 275 minecraft:white_concrete
setblock 540 217 317 minecraft:white_concrete
setblock 542 217 275 minecraft:white_concrete
setblock 542 217 317 minecraft:white_concrete
fill 543 217 275 543 224 275 minecraft:brown_terracotta
fill 543 217 317 543 224 317 minecraft:brown_terracotta
setblock 544 217 275 minecraft:white_concrete
fill 544 217 301 545 218 302 minecraft:lime_concrete
setblock 544 217 317 minecraft:white_concrete
setblock 546 217 275 minecraft:white_concrete
setblock 546 217 317 minecraft:white_concrete
fill 547 217 275 547 224 275 minecraft:brown_terracotta
fill 547 217 317 547 224 317 minecraft:brown_terracotta
setblock 548 217 275 minecraft:white_concrete
setblock 548 217 317 minecraft:white_concrete
setblock 549 217 275 minecraft:brown_terracotta
setblock 550 217 275 minecraft:white_concrete
setblock 550 217 317 minecraft:white_concrete
fill 551 217 275 551 224 275 minecraft:brown_terracotta
fill 551 217 317 551 224 317 minecraft:brown_terracotta
setblock 552 217 275 minecraft:white_concrete
setblock 552 217 317 minecraft:white_concrete
fill 553 217 279 553 218 279 minecraft:red_concrete
fill 553 217 281 553 218 281 minecraft:red_concrete
setblock 554 217 275 minecraft:white_concrete
fill 554 217 278 556 218 278 minecraft:red_concrete
fill 554 217 282 555 218 282 minecraft:red_concrete
setblock 554 217 317 minecraft:white_concrete
fill 555 217 275 555 224 275 minecraft:brown_terracotta
fill 555 217 317 555 224 317 minecraft:brown_terracotta
setblock 556 217 275 minecraft:white_concrete
setblock 556 217 317 minecraft:white_concrete
fill 557 217 280 557 218 280 minecraft:red_concrete
setblock 558 217 275 minecraft:white_concrete
setblock 558 217 317 minecraft:white_concrete
setblock 559 217 275 minecraft:brown_terracotta
setblock 559 217 276 minecraft:white_concrete
fill 559 217 277 559 224 277 minecraft:brown_terracotta
setblock 559 217 278 minecraft:white_concrete
setblock 559 217 280 minecraft:white_concrete
fill 559 217 281 559 224 281 minecraft:brown_terracotta
setblock 559 217 282 minecraft:white_concrete
setblock 559 217 284 minecraft:white_concrete
fill 559 217 285 559 224 285 minecraft:brown_terracotta
setblock 559 217 286 minecraft:white_concrete
setblock 559 217 288 minecraft:white_concrete
fill 559 217 289 559 224 289 minecraft:brown_terracotta
setblock 559 217 290 minecraft:white_concrete
setblock 559 217 292 minecraft:white_concrete
fill 559 217 293 559 224 293 minecraft:brown_terracotta
setblock 559 217 294 minecraft:white_concrete
setblock 559 217 296 minecraft:white_concrete
fill 559 217 297 559 224 297 minecraft:brown_terracotta
setblock 559 217 298 minecraft:white_concrete
setblock 559 217 300 minecraft:white_concrete
fill 559 217 301 559 224 301 minecraft:brown_terracotta
setblock 559 217 302 minecraft:white_concrete
setblock 559 217 304 minecraft:white_concrete
fill 559 217 305 559 224 305 minecraft:brown_terracotta
setblock 559 217 306 minecraft:white_concrete
setblock 559 217 308 minecraft:white_concrete
fill 559 217 309 559 224 309 minecraft:brown_terracotta
setblock 559 217 310 minecraft:white_concrete
setblock 559 217 312 minecraft:white_concrete
fill 559 217 313 559 224 313 minecraft:brown_terracotta
setblock 559 217 314 minecraft:white_concrete
setblock 559 217 316 minecraft:white_concrete
fill 559 217 317 559 224 317 minecraft:brown_terracotta
setblock 517 218 275 minecraft:white_concrete
fill 517 218 276 517 225 276 minecraft:brown_terracotta
fill 517 218 278 517 225 278 minecraft:brown_terracotta
setblock 517 218 279 minecraft:white_concrete
fill 517 218 280 517 225 280 minecraft:brown_terracotta
fill 517 218 282 517 225 282 minecraft:brown_terracotta
setblock 517 218 283 minecraft:white_concrete
fill 517 218 284 517 225 284 minecraft:brown_terracotta
fill 517 218 286 517 225 286 minecraft:brown_terracotta
setblock 517 218 287 minecraft:white_concrete
fill 517 218 288 517 225 288 minecraft:brown_terracotta
fill 517 218 290 517 225 290 minecraft:brown_terracotta
setblock 517 218 291 minecraft:white_concrete
fill 517 218 292 517 225 292 minecraft:brown_terracotta
fill 517 218 294 517 225 294 minecraft:brown_terracotta
setblock 517 218 295 minecraft:white_concrete
fill 517 218 296 517 225 296 minecraft:brown_terracotta
fill 517 218 298 517 225 298 minecraft:brown_terracotta
setblock 517 218 299 minecraft:white_concrete
fill 517 218 300 517 225 300 minecraft:brown_terracotta
fill 517 218 302 517 225 302 minecraft:brown_terracotta
setblock 517 218 303 minecraft:white_concrete
fill 517 218 304 517 225 304 minecraft:brown_terracotta
fill 517 218 306 517 225 306 minecraft:brown_terracotta
setblock 517 218 307 minecraft:white_concrete
fill 517 218 308 517 225 308 minecraft:brown_terracotta
fill 517 218 310 517 225 310 minecraft:brown_terracotta
setblock 517 218 311 minecraft:white_concrete
fill 517 218 312 517 225 312 minecraft:brown_terracotta
fill 517 218 314 517 225 314 minecraft:brown_terracotta
setblock 517 218 315 minecraft:white_concrete
fill 517 218 316 517 225 316 minecraft:brown_terracotta
setblock 517 218 317 minecraft:white_concrete
fill 518 218 275 518 225 275 minecraft:brown_terracotta
fill 518 218 317 518 225 317 minecraft:brown_terracotta
fill 520 218 275 520 225 275 minecraft:brown_terracotta
fill 520 218 317 520 225 317 minecraft:brown_terracotta
setblock 521 218 275 minecraft:white_concrete
setblock 521 218 317 minecraft:white_concrete
fill 522 218 275 522 225 275 minecraft:brown_terracotta
fill 522 218 317 522 225 317 minecraft:brown_terracotta
fill 524 218 275 524 225 275 minecraft:brown_terracotta
fill 524 218 317 524 225 317 minecraft:brown_terracotta
setblock 525 218 275 minecraft:white_concrete
setblock 525 218 317 minecraft:white_concrete
fill 526 218 275 526 225 275 minecraft:brown_terracotta
fill 526 218 317 526 225 317 minecraft:brown_terracotta
fill 528 218 275 528 225 275 minecraft:brown_terracotta
fill 528 218 317 528 225 317 minecraft:brown_terracotta
setblock 529 218 275 minecraft:white_concrete
setblock 529 218 317 minecraft:white_concrete
fill 530 218 275 530 225 275 minecraft:brown_terracotta
fill 530 218 317 530 225 317 minecraft:brown_terracotta
fill 532 218 275 532 225 275 minecraft:brown_terracotta
fill 532 218 317 532 225 317 minecraft:brown_terracotta
setblock 533 218 275 minecraft:white_concrete
setblock 533 218 317 minecraft:white_concrete
fill 534 218 275 534 225 275 minecraft:brown_terracotta
fill 534 218 317 534 225 317 minecraft:brown_terracotta
fill 536 218 275 536 225 275 minecraft:brown_terracotta
fill 536 218 317 536 225 317 minecraft:brown_terracotta
setblock 537 218 275 minecraft:white_concrete
setblock 537 218 317 minecraft:white_concrete
fill 538 218 275 538 225 275 minecraft:brown_terracotta
fill 538 218 317 538 225 317 minecraft:brown_terracotta
fill 540 218 275 540 225 275 minecraft:brown_terracotta
fill 540 218 317 540 225 317 minecraft:brown_terracotta
setblock 541 218 275 minecraft:white_concrete
setblock 541 218 317 minecraft:white_concrete
fill 542 218 275 542 225 275 minecraft:brown_terracotta
fill 542 218 317 542 225 317 minecraft:brown_terracotta
fill 544 218 275 544 225 275 minecraft:brown_terracotta
fill 544 218 317 544 225 317 minecraft:brown_terracotta
setblock 545 218 275 minecraft:white_concrete
setblock 545 218 317 minecraft:white_concrete
fill 546 218 275 546 225 275 minecraft:brown_terracotta
fill 546 218 317 546 225 317 minecraft:brown_terracotta
fill 548 218 275 548 225 275 minecraft:brown_terracotta
fill 548 218 317 548 225 317 minecraft:brown_terracotta
setblock 549 218 275 minecraft:white_concrete
setblock 549 218 317 minecraft:white_concrete
fill 550 218 275 550 225 275 minecraft:brown_terracotta
fill 550 218 317 550 225 317 minecraft:brown_terracotta
fill 552 218 275 552 225 275 minecraft:brown_terracotta
fill 552 218 317 552 225 317 minecraft:brown_terracotta
setblock 553 218 275 minecraft:white_concrete
setblock 553 218 317 minecraft:white_concrete
fill 554 218 275 554 225 275 minecraft:brown_terracotta
fill 554 218 317 554 225 317 minecraft:brown_terracotta
fill 556 218 275 556 225 275 minecraft:brown_terracotta
fill 556 218 317 556 225 317 minecraft:brown_terracotta
setblock 557 218 275 minecraft:white_concrete
setblock 557 218 317 minecraft:white_concrete
fill 558 218 275 558 225 275 minecraft:brown_terracotta
fill 558 218 317 558 225 317 minecraft:brown_terracotta
setblock 559 218 275 minecraft:white_concrete
fill 559 218 276 559 225 276 minecraft:brown_terracotta
fill 559 218 278 559 225 278 minecraft:brown_terracotta
setblock 559 218 279 minecraft:white_concrete
fill 559 218 280 559 225 280 minecraft:brown_terracotta
fill 559 218 282 559 225 282 minecraft:brown_terracotta
setblock 559 218 283 minecraft:white_concrete
fill 559 218 284 559 225 284 minecraft:brown_terracotta
fill 559 218 286 559 225 286 minecraft:brown_terracotta
setblock 559 218 287 minecraft:white_concrete
fill 559 218 288 559 225 288 minecraft:brown_terracotta
fill 559 218 290 559 225 290 minecraft:brown_terracotta
setblock 559 218 291 minecraft:white_concrete
fill 559 218 292 559 225 292 minecraft:brown_terracotta
fill 559 218 294 559 225 294 minecraft:brown_terracotta
setblock 559 218 295 minecraft:white_concrete
fill 559 218 296 559 225 296 minecraft:brown_terracotta
fill 559 218 298 559 225 298 minecraft:brown_terracotta
setblock 559 218 299 minecraft:white_concrete
fill 559 218 300 559 225 300 minecraft:brown_terracotta
fill 559 218 302 559 225 302 minecraft:brown_terracotta
setblock 559 218 303 minecraft:white_concrete
fill 559 218 304 559 225 304 minecraft:brown_terracotta
fill 559 218 306 559 225 306 minecraft:brown_terracotta
setblock 559 218 307 minecraft:white_concrete
fill 559 218 308 559 225 308 minecraft:brown_terracotta
fill 559 218 310 559 225 310 minecraft:brown_terracotta
setblock 559 218 311 minecraft:white_concrete
fill 559 218 312 559 225 312 minecraft:brown_terracotta
fill 559 218 314 559 225 314 minecraft:brown_terracotta
setblock 559 218 315 minecraft:white_concrete
fill 559 218 316 559 225 316 minecraft:brown_terracotta
fill 517 219 275 517 226 275 minecraft:brown_terracotta
fill 517 219 279 517 226 279 minecraft:brown_terracotta
fill 517 219 283 517 226 283 minecraft:brown_terracotta
fill 517 219 287 517 226 287 minecraft:brown_terracotta
fill 517 219 291 517 226 291 minecraft:brown_terracotta
fill 517 219 295 517 226 295 minecraft:brown_terracotta
fill 517 219 299 517 226 299 minecraft:brown_terracotta
fill 517 219 303 517 226 303 minecraft:brown_terracotta
fill 517 219 307 517 226 307 minecraft:brown_terracotta
fill 517 219 311 517 226 311 minecraft:brown_terracotta
fill 517 219 315 517 226 315 minecraft:brown_terracotta
fill 517 219 317 517 224 317 minecraft:brown_terracotta
setblock 520 219 278 minecraft:light[level=15]
setblock 520 219 285 minecraft:light[level=12]
setblock 520 219 286 minecraft:light[level=15]
setblock 520 219 292 minecraft:light[level=12]
setblock 520 219 294 minecraft:light[level=15]
setblock 520 219 299 minecraft:light[level=12]
setblock 520 219 302 minecraft:light[level=15]
setblock 520 219 306 minecraft:light[level=12]
setblock 520 219 310 minecraft:light[level=15]
setblock 520 219 313 minecraft:light[level=12]
fill 521 219 275 521 226 275 minecraft:brown_terracotta
fill 521 219 317 521 226 317 minecraft:brown_terracotta
fill 525 219 275 525 226 275 minecraft:brown_terracotta
fill 525 219 317 525 226 317 minecraft:brown_terracotta
setblock 527 219 278 minecraft:light[level=12]
setblock 527 219 285 minecraft:light[level=12]
setblock 527 219 292 minecraft:light[level=12]
setblock 527 219 299 minecraft:light[level=12]
setblock 527 219 306 minecraft:light[level=12]
setblock 527 219 313 minecraft:light[level=12]
setblock 528 219 278 minecraft:light[level=15]
setblock 528 219 286 minecraft:light[level=15]
setblock 528 219 294 minecraft:light[level=15]
setblock 528 219 302 minecraft:light[level=15]
setblock 528 219 310 minecraft:light[level=15]
fill 529 219 275 529 226 275 minecraft:brown_terracotta
fill 529 219 317 529 226 317 minecraft:brown_terracotta
fill 533 219 275 533 226 275 minecraft:brown_terracotta
fill 533 219 317 533 226 317 minecraft:brown_terracotta
setblock 534 219 278 minecraft:light[level=12]
setblock 534 219 285 minecraft:light[level=12]
setblock 534 219 292 minecraft:light[level=12]
setblock 534 219 299 minecraft:light[level=12]
setblock 534 219 306 minecraft:light[level=12]
setblock 534 219 313 minecraft:light[level=12]
setblock 536 219 278 minecraft:light[level=15]
setblock 536 219 286 minecraft:light[level=15]
setblock 536 219 294 minecraft:light[level=15]
setblock 536 219 302 minecraft:light[level=15]
setblock 536 219 310 minecraft:light[level=15]
fill 537 219 275 537 226 275 minecraft:brown_terracotta
fill 537 219 317 537 226 317 minecraft:brown_terracotta
fill 541 219 275 541 226 275 minecraft:brown_terracotta
setblock 541 219 278 minecraft:light[level=12]
setblock 541 219 285 minecraft:light[level=12]
setblock 541 219 292 minecraft:light[level=12]
setblock 541 219 299 minecraft:light[level=12]
setblock 541 219 306 minecraft:light[level=12]
setblock 541 219 313 minecraft:light[level=12]
fill 541 219 317 541 226 317 minecraft:brown_terracotta
setblock 544 219 278 minecraft:light[level=15]
setblock 544 219 286 minecraft:light[level=15]
setblock 544 219 294 minecraft:light[level=15]
setblock 544 219 302 minecraft:light[level=15]
setblock 544 219 310 minecraft:light[level=15]
fill 545 219 275 545 226 275 minecraft:brown_terracotta
fill 545 219 317 545 226 317 minecraft:brown_terracotta
setblock 548 219 278 minecraft:light[level=12]
setblock 548 219 285 minecraft:light[level=12]
setblock 548 219 292 minecraft:light[level=12]
setblock 548 219 299 minecraft:light[level=12]
setblock 548 219 306 minecraft:light[level=12]
setblock 548 219 313 minecraft:light[level=12]
fill 549 219 275 549 226 275 minecraft:brown_terracotta
fill 549 219 317 549 226 317 minecraft:brown_terracotta
setblock 552 219 278 minecraft:light[level=15]
setblock 552 219 286 minecraft:light[level=15]
setblock 552 219 294 minecraft:light[level=15]
setblock 552 219 302 minecraft:light[level=15]
setblock 552 219 310 minecraft:light[level=15]
fill 553 219 275 553 226 275 minecraft:brown_terracotta
fill 553 219 317 553 226 317 minecraft:brown_terracotta
setblock 555 219 278 minecraft:light[level=12]
setblock 555 219 285 minecraft:light[level=12]
setblock 555 219 292 minecraft:light[level=12]
setblock 555 219 299 minecraft:light[level=12]
setblock 555 219 306 minecraft:light[level=12]
setblock 555 219 313 minecraft:light[level=12]
fill 557 219 275 557 226 275 minecraft:brown_terracotta
fill 557 219 317 557 226 317 minecraft:brown_terracotta
fill 559 219 275 559 224 275 minecraft:brown_terracotta
fill 559 219 279 559 226 279 minecraft:brown_terracotta
fill 559 219 283 559 226 283 minecraft:brown_terracotta
fill 559 219 287 559 226 287 minecraft:brown_terracotta
fill 559 219 291 559 226 291 minecraft:brown_terracotta
fill 559 219 295 559 226 295 minecraft:brown_terracotta
fill 559 219 299 559 226 299 minecraft:brown_terracotta
fill 559 219 303 559 226 303 minecraft:brown_terracotta
fill 559 219 307 559 226 307 minecraft:brown_terracotta
fill 559 219 311 559 226 311 minecraft:brown_terracotta
fill 559 219 315 559 226 315 minecraft:brown_terracotta
fill 525 224 297 525 225 305 minecraft:green_wool
fill 526 224 296 526 225 298 minecraft:green_wool
fill 526 224 299 531 224 303 minecraft:white_stained_glass
fill 526 224 304 526 225 306 minecraft:green_wool
fill 527 224 294 527 225 296 minecraft:green_wool
fill 527 224 297 541 224 298 minecraft:white_stained_glass
fill 527 224 304 541 224 305 minecraft:white_stained_glass
fill 527 224 306 527 225 308 minecraft:green_wool
fill 528 224 294 529 225 294 minecraft:green_wool
fill 528 224 295 540 225 296 minecraft:white_stained_glass
fill 528 224 306 540 225 307 minecraft:white_stained_glass
fill 528 224 308 529 225 308 minecraft:green_wool
fill 529 224 293 531 225 293 minecraft:green_wool
fill 529 224 309 531 225 309 minecraft:green_wool
fill 530 224 292 538 225 292 minecraft:green_wool
fill 530 224 294 538 225 294 minecraft:white_stained_glass
fill 530 224 308 538 225 308 minecraft:white_stained_glass
fill 530 224 310 538 225 310 minecraft:green_wool
fill 532 224 293 536 225 293 minecraft:white_stained_glass
setblock 532 224 299 minecraft:white_stained_glass
setblock 532 224 303 minecraft:white_stained_glass
fill 532 224 309 536 225 309 minecraft:white_stained_glass
fill 536 224 299 542 224 299 minecraft:white_stained_glass
fill 536 224 303 542 224 303 minecraft:white_stained_glass
fill 537 224 293 539 225 293 minecraft:green_wool
fill 537 224 300 542 224 302 minecraft:white_stained_glass
fill 537 224 309 539 225 309 minecraft:green_wool
fill 539 224 294 541 225 294 minecraft:green_wool
fill 539 224 308 541 225 308 minecraft:green_wool
fill 541 224 295 541 225 296 minecraft:green_wool
fill 541 224 306 541 225 307 minecraft:green_wool
fill 542 224 296 542 225 298 minecraft:green_wool
fill 542 224 304 542 225 306 minecraft:green_wool
fill 543 224 297 543 225 305 minecraft:green_wool
setblock 517 225 277 minecraft:white_concrete
setblock 517 225 281 minecraft:white_concrete
setblock 517 225 285 minecraft:white_concrete
setblock 517 225 289 minecraft:white_concrete
setblock 517 225 293 minecraft:white_concrete
setblock 517 225 297 minecraft:white_concrete
setblock 517 225 301 minecraft:white_concrete
setblock 517 225 305 minecraft:white_concrete
setblock 517 225 309 minecraft:white_concrete
setblock 517 225 313 minecraft:white_concrete
setblock 517 225 317 minecraft:white_concrete
fill 518 225 276 523 225 316 minecraft:snow_block
setblock 519 225 275 minecraft:white_concrete
setblock 519 225 317 minecraft:white_concrete
setblock 523 225 275 minecraft:white_concrete
setblock 523 225 317 minecraft:white_concrete
fill 524 225 276 524 225 298 minecraft:snow_block
fill 524 225 299 524 225 303 minecraft:green_wool
fill 524 225 304 524 225 316 minecraft:snow_block
fill 525 225 276 525 225 295 minecraft:snow_block
setblock 525 225 296 minecraft:green_wool
setblock 525 225 306 minecraft:green_wool
fill 525 225 307 525 225 316 minecraft:snow_block
fill 526 225 276 526 225 294 minecraft:snow_block
setblock 526 225 295 minecraft:green_wool
fill 526 225 299 530 225 303 minecraft:white_stained_glass
setblock 526 225 307 minecraft:green_wool
fill 526 225 308 526 225 316 minecraft:snow_block
setblock 527 225 275 minecraft:white_concrete
fill 527 225 276 527 225 293 minecraft:snow_block
fill 527 225 297 531 225 298 minecraft:white_stained_glass
fill 527 225 304 531 225 305 minecraft:white_stained_glass
fill 527 225 309 527 225 316 minecraft:snow_block
setblock 527 225 317 minecraft:white_concrete
fill 528 225 276 528 225 292 minecraft:snow_block
setblock 528 225 293 minecraft:green_wool
setblock 528 225 309 minecraft:green_wool
fill 528 225 310 528 225 316 minecraft:snow_block
fill 529 225 276 531 225 291 minecraft:snow_block
setblock 529 225 292 minecraft:green_wool
setblock 529 225 310 minecraft:green_wool
fill 529 225 311 531 225 316 minecraft:snow_block
setblock 531 225 275 minecraft:white_concrete
setblock 531 225 299 minecraft:red_concrete
fill 531 225 300 531 225 302 minecraft:ochre_froglight
setblock 531 225 303 minecraft:red_concrete
setblock 531 225 317 minecraft:white_concrete
fill 532 225 276 558 225 290 minecraft:snow_block
fill 532 225 291 536 225 291 minecraft:green_wool
fill 532 225 297 541 225 297 minecraft:white_stained_glass
setblock 532 225 298 minecraft:red_concrete
setblock 532 225 299 minecraft:ochre_froglight
setblock 532 225 303 minecraft:ochre_froglight
setblock 532 225 304 minecraft:red_concrete
fill 532 225 305 541 225 305 minecraft:white_stained_glass
fill 532 225 311 536 225 311 minecraft:green_wool
fill 532 225 312 558 225 316 minecraft:snow_block
fill 533 225 298 535 225 298 minecraft:ochre_froglight
fill 533 225 304 535 225 304 minecraft:ochre_froglight
setblock 535 225 275 minecraft:white_concrete
setblock 535 225 317 minecraft:white_concrete
setblock 536 225 298 minecraft:red_concrete
setblock 536 225 299 minecraft:ochre_froglight
setblock 536 225 303 minecraft:ochre_froglight
setblock 536 225 304 minecraft:red_concrete
fill 537 225 291 558 225 291 minecraft:snow_block
fill 537 225 298 541 225 298 minecraft:white_stained_glass
setblock 537 225 299 minecraft:red_concrete
fill 537 225 300 537 225 302 minecraft:ochre_froglight
setblock 537 225 303 minecraft:red_concrete
fill 537 225 304 541 225 304 minecraft:white_stained_glass
fill 537 225 311 558 225 311 minecraft:snow_block
fill 538 225 299 542 225 303 minecraft:white_stained_glass
setblock 539 225 275 minecraft:white_concrete
setblock 539 225 292 minecraft:green_wool
setblock 539 225 310 minecraft:green_wool
setblock 539 225 317 minecraft:white_concrete
fill 540 225 292 558 225 292 minecraft:snow_block
setblock 540 225 293 minecraft:green_wool
setblock 540 225 309 minecraft:green_wool
fill 540 225 310 558 225 310 minecraft:snow_block
fill 541 225 293 558 225 293 minecraft:snow_block
fill 541 225 309 558 225 309 minecraft:snow_block
fill 542 225 294 558 225 294 minecraft:snow_block
setblock 542 225 295 minecraft:green_wool
setblock 542 225 307 minecraft:green_wool
fill 542 225 308 558 225 308 minecraft:snow_block
setblock 543 225 275 minecraft:white_concrete
fill 543 225 295 558 225 295 minecraft:snow_block
setblock 543 225 296 minecraft:green_wool
setblock 543 225 306 minecraft:green_wool
fill 543 225 307 558 225 307 minecraft:snow_block
setblock 543 225 317 minecraft:white_concrete
fill 544 225 296 558 225 298 minecraft:snow_block
fill 544 225 299 544 225 303 minecraft:green_wool
fill 544 225 304 558 225 306 minecraft:snow_block
fill 545 225 299 558 225 303 minecraft:snow_block
setblock 547 225 275 minecraft:white_concrete
setblock 547 225 317 minecraft:white_concrete
setblock 551 225 275 minecraft:white_concrete
setblock 551 225 317 minecraft:white_concrete
setblock 555 225 275 minecraft:white_concrete
setblock 555 225 317 minecraft:white_concrete
setblock 559 225 275 minecraft:white_concrete
setblock 559 225 277 minecraft:white_concrete
setblock 559 225 281 minecraft:white_concrete
setblock 559 225 285 minecraft:white_concrete
setblock 559 225 289 minecraft:white_concrete
setblock 559 225 293 minecraft:white_concrete
setblock 559 225 297 minecraft:white_concrete
setblock 559 225 301 minecraft:white_concrete
setblock 559 225 305 minecraft:white_concrete
setblock 559 225 309 minecraft:white_concrete
setblock 559 225 313 minecraft:white_concrete
setblock 559 225 317 minecraft:white_concrete
setblock 517 226 276 minecraft:white_concrete
fill 517 226 277 517 233 277 minecraft:brown_terracotta
setblock 517 226 278 minecraft:white_concrete
setblock 517 226 280 minecraft:white_concrete
fill 517 226 281 517 228 281 minecraft:brown_terracotta
setblock 517 226 282 minecraft:white_concrete
setblock 517 226 284 minecraft:white_concrete
fill 517 226 285 517 233 285 minecraft:brown_terracotta
setblock 517 226 286 minecraft:white_concrete
setblock 517 226 288 minecraft:white_concrete
fill 517 226 289 517 233 289 minecraft:brown_terracotta
setblock 517 226 290 minecraft:white_concrete
setblock 517 226 292 minecraft:white_concrete
fill 517 226 293 517 228 293 minecraft:brown_terracotta
setblock 517 226 294 minecraft:white_concrete
setblock 517 226 296 minecraft:white_concrete
fill 517 226 297 517 233 297 minecraft:brown_terracotta
setblock 517 226 298 minecraft:white_concrete
setblock 517 226 300 minecraft:white_concrete
fill 517 226 301 517 233 301 minecraft:brown_terracotta
setblock 517 226 302 minecraft:white_concrete
setblock 517 226 304 minecraft:white_concrete
fill 517 226 305 517 228 305 minecraft:brown_terracotta
setblock 517 226 306 minecraft:white_concrete
setblock 517 226 308 minecraft:white_concrete
fill 517 226 309 517 233 309 minecraft:brown_terracotta
setblock 517 226 310 minecraft:white_concrete
setblock 517 226 312 minecraft:white_concrete
fill 517 226 313 517 233 313 minecraft:brown_terracotta
setblock 517 226 314 minecraft:white_concrete
setblock 517 226 316 minecraft:white_concrete
setblock 517 226 317 minecraft:brown_terracotta
setblock 518 226 275 minecraft:white_concrete
setblock 518 226 317 minecraft:white_concrete
fill 519 226 275 519 233 275 minecraft:brown_terracotta
fill 519 226 317 519 228 317 minecraft:brown_terracotta
setblock 520 226 275 minecraft:white_concrete
setblock 520 226 317 minecraft:white_concrete
fill 521 226 292 529 234 310 minecraft:smooth_stone
setblock 522 226 275 minecraft:white_concrete
setblock 522 226 317 minecraft:white_concrete
fill 523 226 275 523 233 275 minecraft:brown_terracotta
fill 523 226 317 523 233 317 minecraft:brown_terracotta
setblock 524 226 275 minecraft:white_concrete
setblock 524 226 317 minecraft:white_concrete
setblock 526 226 275 minecraft:white_concrete
setblock 526 226 317 minecraft:white_concrete
fill 527 226 275 527 228 275 minecraft:brown_terracotta
fill 527 226 317 527 233 317 minecraft:brown_terracotta
setblock 528 226 275 minecraft:white_concrete
setblock 528 226 317 minecraft:white_concrete
setblock 530 226 275 minecraft:white_concrete
fill 530 226 292 530 234 310 minecraft:oak_planks
setblock 530 226 317 minecraft:white_concrete
fill 531 226 275 531 233 275 minecraft:brown_terracotta
fill 531 226 292 538 226 292 minecraft:green_wool
fill 531 226 293 532 227 293 minecraft:red_concrete
fill 531 226 294 533 226 294 minecraft:green_wool
fill 531 226 308 533 226 308 minecraft:green_wool
fill 531 226 309 532 227 309 minecraft:red_concrete
fill 531 226 310 538 226 310 minecraft:green_wool
fill 531 226 317 531 228 317 minecraft:brown_terracotta
setblock 532 226 275 minecraft:white_concrete
setblock 532 226 317 minecraft:white_concrete
fill 533 226 293 535 226 293 minecraft:green_wool
fill 533 226 309 535 226 309 minecraft:green_wool
setblock 534 226 275 minecraft:white_concrete
setblock 534 226 317 minecraft:white_concrete
fill 535 226 275 535 233 275 minecraft:brown_terracotta
fill 535 226 294 538 226 294 minecraft:green_wool
fill 535 226 308 538 226 308 minecraft:green_wool
fill 535 226 317 535 233 317 minecraft:brown_terracotta
setblock 536 226 275 minecraft:white_concrete
fill 536 226 293 537 227 293 minecraft:red_concrete
fill 536 226 309 537 227 309 minecraft:red_concrete
setblock 536 226 317 minecraft:white_concrete
setblock 538 226 275 minecraft:white_concrete
setblock 538 226 293 minecraft:green_wool
setblock 538 226 295 minecraft:green_wool
setblock 538 226 307 minecraft:green_wool
setblock 538 226 309 minecraft:green_wool
setblock 538 226 317 minecraft:white_concrete
fill 539 226 275 539 228 275 minecraft:brown_terracotta
fill 539 226 292 539 234 310 minecraft:oak_planks
fill 539 226 317 539 233 317 minecraft:brown_terracotta
setblock 540 226 275 minecraft:white_concrete
fill 540 226 292 547 234 310 minecraft:smooth_stone
setblock 540 226 317 minecraft:white_concrete
setblock 542 226 275 minecraft:white_concrete
setblock 542 226 317 minecraft:white_concrete
fill 543 226 275 543 233 275 minecraft:brown_terracotta
fill 543 226 317 543 228 317 minecraft:brown_terracotta
setblock 544 226 275 minecraft:white_concrete
setblock 544 226 317 minecraft:white_concrete
setblock 546 226 275 minecraft:white_concrete
setblock 546 226 317 minecraft:white_concrete
fill 547 226 275 547 233 275 minecraft:brown_terracotta
fill 547 226 317 547 233 317 minecraft:brown_terracotta
setblock 548 226 275 minecraft:white_concrete
setblock 548 226 317 minecraft:white_concrete
setblock 550 226 275 minecraft:white_concrete
setblock 550 226 317 minecraft:white_concrete
fill 551 226 275 551 228 275 minecraft:brown_terracotta
fill 551 226 317 551 233 317 minecraft:brown_terracotta
setblock 552 226 275 minecraft:white_concrete
setblock 552 226 317 minecraft:white_concrete
setblock 554 226 275 minecraft:white_concrete
setblock 554 226 317 minecraft:white_concrete
fill 555 226 275 555 233 275 minecraft:brown_terracotta
fill 555 226 317 555 228 317 minecraft:brown_terracotta
setblock 556 226 275 minecraft:white_concrete
setblock 556 226 317 minecraft:white_concrete
setblock 558 226 275 minecraft:white_concrete
setblock 558 226 317 minecraft:white_concrete
setblock 559 226 275 minecraft:brown_terracotta
setblock 559 226 276 minecraft:white_concrete
fill 559 226 277 559 228 277 minecraft:brown_terracotta
setblock 559 226 278 minecraft:white_concrete
setblock 559 226 280 minecraft:white_concrete
fill 559 226 281 559 233 281 minecraft:brown_terracotta
setblock 559 226 282 minecraft:white_concrete
setblock 559 226 284 minecraft:white_concrete
fill 559 226 285 559 233 285 minecraft:brown_terracotta
setblock 559 226 286 minecraft:white_concrete
setblock 559 226 288 minecraft:white_concrete
fill 559 226 289 559 228 289 minecraft:brown_terracotta
setblock 559 226 290 minecraft:white_concrete
setblock 559 226 292 minecraft:white_concrete
fill 559 226 293 559 233 293 minecraft:brown_terracotta
setblock 559 226 294 minecraft:white_concrete
setblock 559 226 296 minecraft:white_concrete
fill 559 226 297 559 233 297 minecraft:brown_terracotta
setblock 559 226 298 minecraft:white_concrete
setblock 559 226 300 minecraft:white_concrete
fill 559 226 301 559 228 301 minecraft:brown_terracotta
setblock 559 226 302 minecraft:white_concrete
setblock 559 226 304 minecraft:white_concrete
fill 559 226 305 559 233 305 minecraft:brown_terracotta
setblock 559 226 306 minecraft:white_concrete
setblock 559 226 308 minecraft:white_concrete
fill 559 226 309 559 233 309 minecraft:brown_terracotta
setblock 559 226 310 minecraft:white_concrete
setblock 559 226 312 minecraft:white_concrete
fill 559 226 313 559 228 313 minecraft:brown_terracotta
setblock 559 226 314 minecraft:white_concrete
setblock 559 226 316 minecraft:white_concrete
fill 559 226 317 559 233 317 minecraft:brown_terracotta
setblock 517 227 275 minecraft:white_concrete
fill 517 227 276 517 234 276 minecraft:brown_terracotta
fill 517 227 278 517 234 278 minecraft:brown_terracotta
setblock 517 227 279 minecraft:white_concrete
fill 517 227 280 517 234 280 minecraft:brown_terracotta
fill 517 227 282 517 228 282 minecraft:brown_terracotta
setblock 517 227 283 minecraft:white_concrete
fill 517 227 284 517 228 284 minecraft:brown_terracotta
fill 517 227 286 517 234 286 minecraft:brown_terracotta
setblock 517 227 287 minecraft:white_concrete
fill 517 227 288 517 234 288 minecraft:brown_terracotta
fill 517 227 290 517 234 290 minecraft:brown_terracotta
setblock 517 227 291 minecraft:white_concrete
fill 517 227 292 517 234 292 minecraft:brown_terracotta
fill 517 227 294 517 228 294 minecraft:brown_terracotta
setblock 517 227 295 minecraft:white_concrete
fill 517 227 296 517 228 296 minecraft:brown_terracotta
fill 517 227 298 517 234 298 minecraft:brown_terracotta
setblock 517 227 299 minecraft:white_concrete
fill 517 227 300 517 234 300 minecraft:brown_terracotta
fill 517 227 302 517 234 302 minecraft:brown_terracotta
setblock 517 227 303 minecraft:white_concrete
fill 517 227 304 517 234 304 minecraft:brown_terracotta
fill 517 227 306 517 228 306 minecraft:brown_terracotta
setblock 517 227 307 minecraft:white_concrete
fill 517 227 308 517 228 308 minecraft:brown_terracotta
fill 517 227 310 517 234 310 minecraft:brown_terracotta
setblock 517 227 311 minecraft:white_concrete
fill 517 227 312 517 234 312 minecraft:brown_terracotta
fill 517 227 314 517 234 314 minecraft:brown_terracotta
setblock 517 227 315 minecraft:white_concrete
fill 517 227 316 517 234 316 minecraft:brown_terracotta
setblock 517 227 317 minecraft:white_concrete
fill 518 227 275 518 234 275 minecraft:brown_terracotta
fill 518 227 317 518 228 317 minecraft:brown_terracotta
fill 520 227 275 520 234 275 minecraft:brown_terracotta
setblock 520 227 278 minecraft:light[level=15]
setblock 520 227 286 minecraft:light[level=15]
setblock 520 227 294 minecraft:light[level=15]
setblock 520 227 302 minecraft:light[level=15]
setblock 520 227 310 minecraft:light[level=15]
fill 520 227 317 520 228 317 minecraft:brown_terracotta
setblock 521 227 275 minecraft:white_concrete
setblock 521 227 317 minecraft:white_concrete
fill 522 227 275 522 234 275 minecraft:brown_terracotta
fill 522 227 317 522 234 317 minecraft:brown_terracotta
fill 524 227 275 524 228 275 minecraft:brown_terracotta
fill 524 227 317 524 234 317 minecraft:brown_terracotta
setblock 525 227 275 minecraft:white_concrete
setblock 525 227 317 minecraft:white_concrete
fill 526 227 275 526 228 275 minecraft:brown_terracotta
fill 526 227 317 526 234 317 minecraft:brown_terracotta
fill 528 227 275 528 234 275 minecraft:brown_terracotta
setblock 528 227 278 minecraft:light[level=15]
setblock 528 227 286 minecraft:light[level=15]
fill 528 227 317 528 234 317 minecraft:brown_terracotta
setblock 529 227 275 minecraft:white_concrete
setblock 529 227 317 minecraft:white_concrete
fill 530 227 275 530 234 275 minecraft:brown_terracotta
fill 530 227 317 530 228 317 minecraft:brown_terracotta
fill 532 227 275 532 234 275 minecraft:brown_terracotta
fill 532 227 317 532 228 317 minecraft:brown_terracotta
setblock 533 227 275 minecraft:white_concrete
setblock 533 227 317 minecraft:white_concrete
fill 534 227 275 534 234 275 minecraft:brown_terracotta
fill 534 227 317 534 234 317 minecraft:brown_terracotta
fill 536 227 275 536 228 275 minecraft:brown_terracotta
setblock 536 227 278 minecraft:light[level=15]
setblock 536 227 286 minecraft:light[level=15]
setblock 536 227 294 minecraft:light[level=15]
setblock 536 227 310 minecraft:light[level=15]
fill 536 227 317 536 234 317 minecraft:brown_terracotta
setblock 537 227 275 minecraft:white_concrete
setblock 537 227 317 minecraft:white_concrete
fill 538 227 275 538 228 275 minecraft:brown_terracotta
fill 538 227 317 538 234 317 minecraft:brown_terracotta
fill 540 227 275 540 234 275 minecraft:brown_terracotta
fill 540 227 317 540 234 317 minecraft:brown_terracotta
setblock 541 227 275 minecraft:white_concrete
setblock 541 227 317 minecraft:white_concrete
fill 542 227 275 542 234 275 minecraft:brown_terracotta
fill 542 227 317 542 228 317 minecraft:brown_terracotta
fill 544 227 275 544 234 275 minecraft:brown_terracotta
setblock 544 227 278 minecraft:light[level=15]
setblock 544 227 286 minecraft:light[level=15]
fill 544 227 317 544 228 317 minecraft:brown_terracotta
setblock 545 227 275 minecraft:white_concrete
setblock 545 227 317 minecraft:white_concrete
fill 546 227 275 546 234 275 minecraft:brown_terracotta
fill 546 227 317 546 234 317 minecraft:brown_terracotta
fill 548 227 275 548 228 275 minecraft:brown_terracotta
fill 548 227 317 548 234 317 minecraft:brown_terracotta
setblock 549 227 275 minecraft:white_concrete
setblock 549 227 317 minecraft:white_concrete
fill 550 227 275 550 228 275 minecraft:brown_terracotta
fill 550 227 317 550 234 317 minecraft:brown_terracotta
fill 552 227 275 552 234 275 minecraft:brown_terracotta
setblock 552 227 278 minecraft:light[level=15]
setblock 552 227 286 minecraft:light[level=15]
setblock 552 227 294 minecraft:light[level=15]
setblock 552 227 302 minecraft:light[level=15]
setblock 552 227 310 minecraft:light[level=15]
fill 552 227 317 552 234 317 minecraft:brown_terracotta
setblock 553 227 275 minecraft:white_concrete
setblock 553 227 317 minecraft:white_concrete
fill 554 227 275 554 234 275 minecraft:brown_terracotta
fill 554 227 317 554 228 317 minecraft:brown_terracotta
fill 556 227 275 556 234 275 minecraft:brown_terracotta
fill 556 227 317 556 228 317 minecraft:brown_terracotta
setblock 557 227 275 minecraft:white_concrete
setblock 557 227 317 minecraft:white_concrete
fill 558 227 275 558 234 275 minecraft:brown_terracotta
fill 558 227 317 558 234 317 minecraft:brown_terracotta
setblock 559 227 275 minecraft:white_concrete
fill 559 227 276 559 228 276 minecraft:brown_terracotta
fill 559 227 278 559 228 278 minecraft:brown_terracotta
setblock 559 227 279 minecraft:white_concrete
fill 559 227 280 559 234 280 minecraft:brown_terracotta
fill 559 227 282 559 234 282 minecraft:brown_terracotta
setblock 559 227 283 minecraft:white_concrete
fill 559 227 284 559 234 284 minecraft:brown_terracotta
fill 559 227 286 559 234 286 minecraft:brown_terracotta
setblock 559 227 287 minecraft:white_concrete
fill 559 227 288 559 228 288 minecraft:brown_terracotta
fill 559 227 290 559 228 290 minecraft:brown_terracotta
setblock 559 227 291 minecraft:white_concrete
fill 559 227 292 559 234 292 minecraft:brown_terracotta
fill 559 227 294 559 234 294 minecraft:brown_terracotta
setblock 559 227 295 minecraft:white_concrete
fill 559 227 296 559 234 296 minecraft:brown_terracotta
fill 559 227 298 559 234 298 minecraft:brown_terracotta
setblock 559 227 299 minecraft:white_concrete
fill 559 227 300 559 228 300 minecraft:brown_terracotta
fill 559 227 302 559 228 302 minecraft:brown_terracotta
setblock 559 227 303 minecraft:white_concrete
fill 559 227 304 559 234 304 minecraft:brown_terracotta
fill 559 227 306 559 234 306 minecraft:brown_terracotta
setblock 559 227 307 minecraft:white_concrete
fill 559 227 308 559 234 308 minecraft:brown_terracotta
fill 559 227 310 559 234 310 minecraft:brown_terracotta
setblock 559 227 311 minecraft:white_concrete
fill 559 227 312 559 228 312 minecraft:brown_terracotta
fill 559 227 314 559 228 314 minecraft:brown_terracotta
setblock 559 227 315 minecraft:white_concrete
fill 559 227 316 559 234 316 minecraft:brown_terracotta
fill 517 228 275 517 235 275 minecraft:brown_terracotta
fill 517 228 279 517 235 279 minecraft:brown_terracotta
setblock 517 228 283 minecraft:brown_terracotta
fill 517 228 287 517 235 287 minecraft:brown_terracotta
fill 517 228 291 517 235 291 minecraft:brown_terracotta
setblock 517 228 295 minecraft:brown_terracotta
fill 517 228 299 517 235 299 minecraft:brown_terracotta
fill 517 228 303 517 235 303 minecraft:brown_terracotta
setblock 517 228 307 minecraft:brown_terracotta
fill 517 228 311 517 235 311 minecraft:brown_terracotta
fill 517 228 315 517 235 315 minecraft:brown_terracotta
setblock 517 228 317 minecraft:brown_terracotta
fill 521 228 275 521 235 275 minecraft:brown_terracotta
fill 521 228 317 521 235 317 minecraft:brown_terracotta
setblock 525 228 275 minecraft:brown_terracotta
fill 525 228 317 525 235 317 minecraft:brown_terracotta
fill 529 228 275 529 235 275 minecraft:brown_terracotta
setblock 529 228 317 minecraft:brown_terracotta
fill 533 228 275 533 235 275 minecraft:brown_terracotta
fill 533 228 317 533 235 317 minecraft:brown_terracotta
setblock 537 228 275 minecraft:brown_terracotta
fill 537 228 317 537 235 317 minecraft:brown_terracotta
fill 541 228 275 541 235 275 minecraft:brown_terracotta
setblock 541 228 317 minecraft:brown_terracotta
fill 545 228 275 545 235 275 minecraft:brown_terracotta
fill 545 228 317 545 235 317 minecraft:brown_terracotta
setblock 549 228 275 minecraft:brown_terracotta
fill 549 228 317 549 235 317 minecraft:brown_terracotta
fill 553 228 275 553 235 275 minecraft:brown_terracotta
setblock 553 228 317 minecraft:brown_terracotta
fill 557 228 275 557 235 275 minecraft:brown_terracotta
fill 557 228 317 557 235 317 minecraft:brown_terracotta
fill 559 228 275 559 233 275 minecraft:brown_terracotta
setblock 559 228 279 minecraft:brown_terracotta
fill 559 228 283 559 235 283 minecraft:brown_terracotta
fill 559 228 287 559 235 287 minecraft:brown_terracotta
setblock 559 228 291 minecraft:brown_terracotta
fill 559 228 295 559 235 295 minecraft:brown_terracotta
fill 559 228 299 559 235 299 minecraft:brown_terracotta
setblock 559 228 303 minecraft:brown_terracotta
fill 559 228 307 559 235 307 minecraft:brown_terracotta
fill 559 228 311 559 235 311 minecraft:brown_terracotta
setblock 559 228 315 minecraft:brown_terracotta
fill 517 229 281 517 231 284 minecraft:shroomlight
fill 517 229 293 517 231 296 minecraft:shroomlight
fill 517 229 305 517 231 308 minecraft:shroomlight
fill 517 229 317 520 231 317 minecraft:shroomlight
fill 518 229 276 520 271 276 minecraft:white_concrete
fill 518 229 281 523 231 291 minecraft:white_concrete
fill 518 229 298 518 271 300 minecraft:white_concrete
fill 518 229 310 518 271 312 minecraft:white_concrete
fill 522 229 276 528 231 280 minecraft:white_concrete
fill 524 229 275 527 231 275 minecraft:shroomlight
fill 524 229 316 526 271 316 minecraft:white_concrete
fill 529 229 277 533 235 277 minecraft:red_wool
fill 529 229 317 532 231 317 minecraft:shroomlight
fill 530 229 276 532 271 276 minecraft:white_concrete
fill 536 229 275 539 231 275 minecraft:shroomlight
fill 536 229 316 538 242 316 minecraft:white_concrete
fill 541 229 317 544 231 317 minecraft:shroomlight
fill 542 229 276 544 271 276 minecraft:white_concrete
fill 548 229 275 551 231 275 minecraft:shroomlight
fill 548 229 316 550 258 316 minecraft:white_concrete
fill 553 229 317 556 231 317 minecraft:shroomlight
fill 554 229 276 556 271 276 minecraft:white_concrete
fill 558 229 284 558 271 286 minecraft:white_concrete
fill 558 229 296 558 271 298 minecraft:white_concrete
fill 558 229 308 558 271 310 minecraft:white_concrete
fill 559 229 276 559 231 279 minecraft:shroomlight
fill 559 229 288 559 231 291 minecraft:shroomlight
fill 559 229 300 559 231 303 minecraft:shroomlight
fill 559 229 312 559 231 315 minecraft:shroomlight
fill 534 230 284 534 231 284 minecraft:shroomlight
fill 545 230 290 546 231 291 minecraft:lime_concrete
setblock 520 231 278 minecraft:light[level=12]
setblock 520 231 292 minecraft:light[level=12]
setblock 520 231 299 minecraft:light[level=12]
setblock 520 231 306 minecraft:light[level=12]
setblock 520 231 313 minecraft:light[level=12]
setblock 527 231 285 minecraft:light[level=12]
setblock 527 231 313 minecraft:light[level=12]
setblock 534 231 278 minecraft:light[level=12]
setblock 534 231 285 minecraft:light[level=12]
setblock 534 231 292 minecraft:light[level=12]
setblock 534 231 299 minecraft:light[level=12]
setblock 534 231 306 minecraft:light[level=12]
setblock 534 231 313 minecraft:light[level=12]
setblock 541 231 278 minecraft:light[level=12]
setblock 541 231 285 minecraft:light[level=12]
setblock 541 231 313 minecraft:light[level=12]
setblock 548 231 278 minecraft:light[level=12]
setblock 548 231 285 minecraft:light[level=12]
setblock 548 231 292 minecraft:light[level=12]
setblock 548 231 299 minecraft:light[level=12]
setblock 548 231 306 minecraft:light[level=12]
setblock 548 231 313 minecraft:light[level=12]
setblock 555 231 278 minecraft:light[level=12]
setblock 555 231 285 minecraft:light[level=12]
setblock 555 231 292 minecraft:light[level=12]
setblock 555 231 299 minecraft:light[level=12]
setblock 555 231 306 minecraft:light[level=12]
setblock 555 231 313 minecraft:light[level=12]
fill 517 232 281 517 233 281 minecraft:brown_terracotta
fill 517 232 282 517 232 283 minecraft:shroomlight
fill 517 232 284 517 234 284 minecraft:brown_terracotta
fill 517 232 293 517 233 293 minecraft:brown_terracotta
fill 517 232 294 517 232 295 minecraft:shroomlight
fill 517 232 296 517 234 296 minecraft:brown_terracotta
fill 517 232 305 517 233 305 minecraft:brown_terracotta
fill 517 232 306 517 232 307 minecraft:shroomlight
fill 517 232 308 517 234 308 minecraft:brown_terracotta
fill 517 232 317 517 233 317 minecraft:brown_terracotta
fill 518 232 281 518 244 281 minecraft:white_concrete
setblock 518 232 282 minecraft:shroomlight
fill 518 232 283 518 244 283 minecraft:white_concrete
setblock 518 232 284 minecraft:shroomlight
fill 518 232 285 518 244 285 minecraft:white_concrete
setblock 518 232 286 minecraft:shroomlight
fill 518 232 287 518 271 287 minecraft:white_concrete
setblock 518 232 288 minecraft:shroomlight
fill 518 232 289 518 244 289 minecraft:white_concrete
setblock 518 232 290 minecraft:shroomlight
fill 518 232 291 518 244 291 minecraft:white_concrete
fill 518 232 317 519 232 317 minecraft:shroomlight
setblock 519 232 281 minecraft:shroomlight
fill 519 232 282 519 244 282 minecraft:white_concrete
setblock 519 232 283 minecraft:shroomlight
fill 519 232 284 519 244 284 minecraft:white_concrete
setblock 519 232 285 minecraft:shroomlight
fill 519 232 286 519 245 286 minecraft:white_concrete
setblock 519 232 287 minecraft:shroomlight
fill 519 232 288 519 244 288 minecraft:white_concrete
setblock 519 232 289 minecraft:shroomlight
fill 519 232 290 519 244 290 minecraft:white_concrete
setblock 519 232 291 minecraft:shroomlight
fill 520 232 281 520 244 281 minecraft:white_concrete
setblock 520 232 282 minecraft:shroomlight
fill 520 232 283 520 244 283 minecraft:white_concrete
setblock 520 232 284 minecraft:shroomlight
fill 520 232 285 520 244 285 minecraft:white_concrete
setblock 520 232 286 minecraft:shroomlight
fill 520 232 287 520 244 287 minecraft:white_concrete
setblock 520 232 288 minecraft:shroomlight
fill 520 232 289 520 244 289 minecraft:white_concrete
setblock 520 232 290 minecraft:shroomlight
fill 520 232 291 520 244 291 minecraft:white_concrete
fill 520 232 317 520 234 317 minecraft:brown_terracotta
setblock 521 232 281 minecraft:shroomlight
fill 521 232 282 521 244 282 minecraft:white_concrete
setblock 521 232 283 minecraft:shroomlight
fill 521 232 284 521 244 284 minecraft:white_concrete
setblock 521 232 285 minecraft:shroomlight
fill 521 232 286 521 244 286 minecraft:white_concrete
setblock 521 232 287 minecraft:shroomlight
fill 521 232 288 521 244 288 minecraft:white_concrete
setblock 521 232 289 minecraft:shroomlight
fill 521 232 290 521 244 290 minecraft:white_concrete
setblock 521 232 291 minecraft:shroomlight
setblock 522 232 276 minecraft:shroomlight
fill 522 232 277 522 242 277 minecraft:white_concrete
setblock 522 232 278 minecraft:shroomlight
fill 522 232 279 522 242 279 minecraft:white_concrete
setblock 522 232 280 minecraft:shroomlight
fill 522 232 281 522 244 281 minecraft:white_concrete
setblock 522 232 282 minecraft:shroomlight
fill 522 232 283 522 244 283 minecraft:white_concrete
setblock 522 232 284 minecraft:shroomlight
fill 522 232 285 522 244 285 minecraft:white_concrete
setblock 522 232 286 minecraft:shroomlight
fill 522 232 287 522 244 287 minecraft:white_concrete
setblock 522 232 288 minecraft:shroomlight
fill 522 232 289 522 244 289 minecraft:white_concrete
setblock 522 232 290 minecraft:shroomlight
fill 522 232 291 522 244 291 minecraft:white_concrete
fill 523 232 276 523 242 276 minecraft:white_concrete
setblock 523 232 277 minecraft:shroomlight
fill 523 232 278 523 242 278 minecraft:white_concrete
setblock 523 232 279 minecraft:shroomlight
fill 523 232 280 523 242 280 minecraft:white_concrete
setblock 523 232 281 minecraft:shroomlight
fill 523 232 282 523 244 282 minecraft:white_concrete
setblock 523 232 283 minecraft:shroomlight
fill 523 232 284 523 244 284 minecraft:white_concrete
setblock 523 232 285 minecraft:shroomlight
fill 523 232 286 523 244 286 minecraft:white_concrete
setblock 523 232 287 minecraft:shroomlight
fill 523 232 288 523 244 288 minecraft:white_concrete
setblock 523 232 289 minecraft:shroomlight
fill 523 232 290 523 244 290 minecraft:white_concrete
setblock 523 232 291 minecraft:shroomlight
fill 524 232 275 524 234 275 minecraft:brown_terracotta
setblock 524 232 276 minecraft:shroomlight
fill 524 232 277 524 242 277 minecraft:white_concrete
setblock 524 232 278 minecraft:shroomlight
fill 524 232 279 524 242 279 minecraft:white_concrete
setblock 524 232 280 minecraft:shroomlight
fill 525 232 275 526 232 275 minecraft:shroomlight
fill 525 232 276 525 242 276 minecraft:white_concrete
setblock 525 232 277 minecraft:shroomlight
fill 525 232 278 525 242 278 minecraft:white_concrete
setblock 525 232 279 minecraft:shroomlight
fill 525 232 280 525 242 280 minecraft:white_concrete
setblock 526 232 276 minecraft:shroomlight
fill 526 232 277 526 242 277 minecraft:white_concrete
setblock 526 232 278 minecraft:shroomlight
fill 526 232 279 526 242 279 minecraft:white_concrete
setblock 526 232 280 minecraft:shroomlight
fill 527 232 275 527 233 275 minecraft:brown_terracotta
fill 527 232 276 527 242 276 minecraft:white_concrete
setblock 527 232 277 minecraft:shroomlight
fill 527 232 278 527 242 278 minecraft:white_concrete
setblock 527 232 279 minecraft:shroomlight
fill 527 232 280 527 242 280 minecraft:white_concrete
setblock 528 232 276 minecraft:shroomlight
fill 528 232 277 528 242 277 minecraft:white_concrete
setblock 528 232 278 minecraft:shroomlight
fill 528 232 279 528 242 279 minecraft:white_concrete
setblock 528 232 280 minecraft:shroomlight
fill 529 232 317 529 235 317 minecraft:brown_terracotta
fill 530 232 317 531 232 317 minecraft:shroomlight
fill 532 232 317 532 234 317 minecraft:brown_terracotta
fill 534 232 283 534 238 284 minecraft:brown_terracotta
fill 536 232 275 536 234 275 minecraft:brown_terracotta
fill 537 232 275 538 232 275 minecraft:shroomlight
fill 539 232 275 539 233 275 minecraft:brown_terracotta
fill 541 232 317 541 235 317 minecraft:brown_terracotta
fill 542 232 317 543 232 317 minecraft:shroomlight
fill 544 232 317 544 234 317 minecraft:brown_terracotta
fill 548 232 275 548 234 275 minecraft:brown_terracotta
fill 549 232 275 550 232 275 minecraft:shroomlight
fill 550 232 285 550 233 285 minecraft:red_concrete
fill 551 232 275 551 233 275 minecraft:brown_terracotta
fill 553 232 317 553 235 317 minecraft:brown_terracotta
fill 554 232 317 555 232 317 minecraft:shroomlight
fill 556 232 317 556 234 317 minecraft:brown_terracotta
fill 559 232 276 559 234 276 minecraft:brown_terracotta
fill 559 232 277 559 232 278 minecraft:shroomlight
fill 559 232 279 559 235 279 minecraft:brown_terracotta
fill 559 232 288 559 234 288 minecraft:brown_terracotta
fill 559 232 289 559 232 290 minecraft:shroomlight
fill 559 232 291 559 235 291 minecraft:brown_terracotta
fill 559 232 300 559 234 300 minecraft:brown_terracotta
fill 559 232 301 559 232 302 minecraft:shroomlight
fill 559 232 303 559 235 303 minecraft:brown_terracotta
fill 559 232 312 559 234 312 minecraft:brown_terracotta
fill 559 232 313 559 232 314 minecraft:shroomlight
fill 559 232 315 559 235 315 minecraft:brown_terracotta
fill 517 233 282 517 234 283 minecraft:brown_terracotta
fill 517 233 294 517 234 295 minecraft:brown_terracotta
fill 517 233 306 517 234 307 minecraft:brown_terracotta
fill 518 233 282 518 234 282 minecraft:white_concrete
fill 518 233 284 518 234 284 minecraft:white_concrete
fill 518 233 286 518 234 286 minecraft:white_concrete
fill 518 233 288 518 234 288 minecraft:white_concrete
fill 518 233 290 518 234 290 minecraft:white_concrete
fill 518 233 317 519 233 317 minecraft:brown_terracotta
fill 519 233 281 519 234 281 minecraft:white_concrete
fill 519 233 283 519 234 283 minecraft:white_concrete
fill 519 233 285 519 234 285 minecraft:white_concrete
fill 519 233 287 519 234 287 minecraft:white_concrete
fill 519 233 289 519 234 289 minecraft:white_concrete
fill 519 233 291 519 234 291 minecraft:white_concrete
fill 520 233 282 520 234 282 minecraft:white_concrete
fill 520 233 284 520 234 284 minecraft:white_concrete
fill 520 233 286 520 234 286 minecraft:white_concrete
fill 520 233 288 520 234 288 minecraft:white_concrete
fill 520 233 290 520 234 290 minecraft:white_concrete
fill 521 233 281 521 234 281 minecraft:white_concrete
fill 521 233 283 521 234 283 minecraft:white_concrete
fill 521 233 285 521 234 285 minecraft:white_concrete
fill 521 233 287 521 234 287 minecraft:white_concrete
fill 521 233 289 521 234 289 minecraft:white_concrete
fill 521 233 291 521 234 291 minecraft:white_concrete
fill 522 233 276 522 234 276 minecraft:white_concrete
fill 522 233 278 522 234 278 minecraft:white_concrete
fill 522 233 280 522 234 280 minecraft:white_concrete
fill 522 233 282 522 234 282 minecraft:white_concrete
fill 522 233 284 522 234 284 minecraft:white_concrete
fill 522 233 286 522 234 286 minecraft:white_concrete
fill 522 233 288 522 234 288 minecraft:white_concrete
fill 522 233 290 522 234 290 minecraft:white_concrete
fill 523 233 277 523 234 277 minecraft:white_concrete
fill 523 233 279 523 234 279 minecraft:white_concrete
fill 523 233 281 523 234 281 minecraft:white_concrete
fill 523 233 283 523 234 283 minecraft:white_concrete
fill 523 233 285 523 234 285 minecraft:white_concrete
fill 523 233 287 523 234 287 minecraft:white_concrete
fill 523 233 289 523 234 289 minecraft:white_concrete
fill 523 233 291 523 234 291 minecraft:white_concrete
fill 524 233 276 524 234 276 minecraft:white_concrete
fill 524 233 278 524 234 278 minecraft:white_concrete
fill 524 233 280 524 234 280 minecraft:white_concrete
fill 525 233 275 526 234 275 minecraft:brown_terracotta
fill 525 233 277 525 234 277 minecraft:white_concrete
fill 525 233 279 525 234 279 minecraft:white_concrete
fill 526 233 276 526 234 276 minecraft:white_concrete
fill 526 233 278 526 234 278 minecraft:white_concrete
fill 526 233 280 526 234 280 minecraft:white_concrete
fill 527 233 277 527 234 277 minecraft:white_concrete
fill 527 233 279 527 234 279 minecraft:white_concrete
fill 528 233 276 528 234 276 minecraft:white_concrete
fill 528 233 278 528 234 278 minecraft:white_concrete
fill 528 233 280 528 234 280 minecraft:white_concrete
fill 530 233 317 531 233 317 minecraft:brown_terracotta
fill 537 233 275 538 234 275 minecraft:brown_terracotta
fill 542 233 317 543 233 317 minecraft:brown_terracotta
fill 549 233 275 550 234 275 minecraft:brown_terracotta
fill 554 233 317 555 233 317 minecraft:brown_terracotta
fill 559 233 277 559 233 278 minecraft:brown_terracotta
fill 559 233 289 559 233 290 minecraft:brown_terracotta
fill 559 233 301 559 233 302 minecraft:brown_terracotta
fill 559 233 313 559 233 314 minecraft:brown_terracotta
setblock 517 234 277 minecraft:white_concrete
setblock 517 234 281 minecraft:white_concrete
setblock 517 234 285 minecraft:white_concrete
setblock 517 234 289 minecraft:white_concrete
setblock 517 234 293 minecraft:white_concrete
setblock 517 234 297 minecraft:white_concrete
setblock 517 234 301 minecraft:white_concrete
setblock 517 234 305 minecraft:white_concrete
setblock 517 234 309 minecraft:white_concrete
fill 517 234 313 518 234 313 minecraft:white_concrete
setblock 517 234 317 minecraft:white_concrete
setblock 518 234 317 minecraft:brown_terracotta
setblock 519 234 275 minecraft:white_concrete
setblock 519 234 317 minecraft:white_concrete
setblock 523 234 275 minecraft:white_concrete
setblock 523 234 317 minecraft:white_concrete
setblock 527 234 275 minecraft:white_concrete
setblock 527 234 317 minecraft:white_concrete
setblock 530 234 317 minecraft:brown_terracotta
setblock 531 234 275 minecraft:white_concrete
setblock 531 234 317 minecraft:white_concrete
fill 533 234 283 533 238 284 minecraft:brown_terracotta
setblock 535 234 275 minecraft:white_concrete
fill 535 234 283 535 238 284 minecraft:brown_terracotta
setblock 535 234 317 minecraft:white_concrete
setblock 539 234 275 minecraft:white_concrete
setblock 539 234 317 minecraft:white_concrete
setblock 542 234 317 minecraft:brown_terracotta
setblock 543 234 275 minecraft:white_concrete
setblock 543 234 317 minecraft:white_concrete
setblock 547 234 275 minecraft:white_concrete
setblock 547 234 317 minecraft:white_concrete
setblock 551 234 275 minecraft:white_concrete
setblock 551 234 317 minecraft:white_concrete
setblock 554 234 317 minecraft:brown_terracotta
setblock 555 234 275 minecraft:white_concrete
setblock 555 234 317 minecraft:white_concrete
fill 557 234 311 558 235 313 minecraft:white_concrete
setblock 559 234 275 minecraft:white_concrete
setblock 559 234 277 minecraft:white_concrete
setblock 559 234 278 minecraft:brown_terracotta
setblock 559 234 281 minecraft:white_concrete
setblock 559 234 285 minecraft:white_concrete
setblock 559 234 289 minecraft:white_concrete
schedule function dropper:buildpart/71_5 1t
