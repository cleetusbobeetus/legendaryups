setblock 527 230 270 minecraft:magenta_terracotta
setblock 528 230 270 minecraft:light_gray_terracotta
setblock 531 230 228 minecraft:magenta_terracotta
setblock 531 230 270 minecraft:magenta_terracotta
setblock 535 230 228 minecraft:magenta_terracotta
setblock 535 230 270 minecraft:magenta_terracotta
setblock 539 230 228 minecraft:magenta_terracotta
setblock 539 230 270 minecraft:magenta_terracotta
fill 540 230 268 541 230 269 minecraft:dark_oak_planks
fill 542 230 268 543 230 268 minecraft:spruce_planks
setblock 543 230 228 minecraft:magenta_terracotta
setblock 543 230 270 minecraft:magenta_terracotta
fill 546 230 256 546 233 256 minecraft:white_stained_glass
setblock 547 230 228 minecraft:magenta_terracotta
setblock 547 230 270 minecraft:magenta_terracotta
fill 548 230 254 548 231 254 minecraft:white_stained_glass
fill 549 230 257 549 232 257 minecraft:white_stained_glass
setblock 551 230 228 minecraft:magenta_terracotta
setblock 551 230 270 minecraft:magenta_terracotta
setblock 555 230 228 minecraft:magenta_terracotta
setblock 555 230 270 minecraft:magenta_terracotta
setblock 559 230 228 minecraft:magenta_terracotta
setblock 559 230 230 minecraft:magenta_terracotta
setblock 559 230 234 minecraft:magenta_terracotta
setblock 559 230 238 minecraft:magenta_terracotta
setblock 559 230 242 minecraft:magenta_terracotta
setblock 559 230 246 minecraft:magenta_terracotta
setblock 559 230 250 minecraft:magenta_terracotta
setblock 559 230 254 minecraft:magenta_terracotta
setblock 559 230 258 minecraft:magenta_terracotta
setblock 559 230 262 minecraft:magenta_terracotta
setblock 559 230 266 minecraft:magenta_terracotta
setblock 559 230 270 minecraft:magenta_terracotta
fill 517 231 230 517 233 230 minecraft:purple_terracotta
fill 517 231 234 517 233 234 minecraft:purple_terracotta
fill 517 231 238 517 233 238 minecraft:purple_terracotta
fill 517 231 242 517 233 242 minecraft:purple_terracotta
fill 517 231 246 517 233 246 minecraft:purple_terracotta
fill 517 231 250 517 233 250 minecraft:purple_terracotta
fill 517 231 254 517 233 254 minecraft:purple_terracotta
fill 517 231 258 517 233 258 minecraft:purple_terracotta
fill 517 231 262 517 233 262 minecraft:purple_terracotta
fill 517 231 266 517 233 266 minecraft:purple_terracotta
setblock 517 231 270 minecraft:purple_terracotta
fill 519 231 228 519 233 228 minecraft:purple_terracotta
fill 519 231 270 519 233 270 minecraft:purple_terracotta
fill 523 231 228 523 233 228 minecraft:purple_terracotta
fill 523 231 270 523 233 270 minecraft:purple_terracotta
fill 527 231 228 527 233 228 minecraft:purple_terracotta
fill 527 231 270 528 233 270 minecraft:purple_terracotta
fill 531 231 228 531 233 228 minecraft:purple_terracotta
fill 531 231 270 531 233 270 minecraft:purple_terracotta
fill 535 231 228 535 233 228 minecraft:purple_terracotta
fill 535 231 270 535 233 270 minecraft:purple_terracotta
fill 539 231 228 539 233 228 minecraft:purple_terracotta
fill 539 231 270 539 233 270 minecraft:purple_terracotta
fill 542 231 268 543 231 269 minecraft:dark_oak_planks
fill 543 231 228 543 233 228 minecraft:purple_terracotta
fill 543 231 265 543 236 265 minecraft:iron_bars
fill 543 231 270 543 233 270 minecraft:purple_terracotta
fill 544 231 268 545 231 268 minecraft:spruce_planks
fill 546 231 255 546 232 255 minecraft:white_stained_glass
fill 546 231 257 546 232 257 minecraft:white_stained_glass
fill 547 231 228 547 233 228 minecraft:purple_terracotta
fill 547 231 254 547 232 254 minecraft:white_stained_glass
fill 547 231 270 547 233 270 minecraft:purple_terracotta
fill 548 231 258 548 232 258 minecraft:white_stained_glass
fill 550 231 256 550 232 256 minecraft:white_stained_glass
fill 551 231 228 551 233 228 minecraft:purple_terracotta
fill 551 231 270 551 233 270 minecraft:purple_terracotta
fill 555 231 228 555 233 228 minecraft:purple_terracotta
fill 555 231 270 555 233 270 minecraft:purple_terracotta
setblock 559 231 228 minecraft:purple_terracotta
fill 559 231 230 559 233 230 minecraft:purple_terracotta
fill 559 231 234 559 233 234 minecraft:purple_terracotta
fill 559 231 238 559 233 238 minecraft:purple_terracotta
fill 559 231 242 559 233 242 minecraft:purple_terracotta
fill 559 231 246 559 233 246 minecraft:purple_terracotta
fill 559 231 250 559 233 250 minecraft:purple_terracotta
fill 559 231 254 559 233 254 minecraft:purple_terracotta
fill 559 231 258 559 233 258 minecraft:purple_terracotta
fill 559 231 262 559 233 262 minecraft:purple_terracotta
fill 559 231 266 559 233 266 minecraft:purple_terracotta
fill 559 231 270 559 233 270 minecraft:purple_terracotta
setblock 517 232 228 minecraft:magenta_terracotta
setblock 517 232 232 minecraft:magenta_terracotta
setblock 517 232 236 minecraft:magenta_terracotta
setblock 517 232 240 minecraft:magenta_terracotta
setblock 517 232 244 minecraft:magenta_terracotta
setblock 517 232 248 minecraft:magenta_terracotta
setblock 517 232 252 minecraft:magenta_terracotta
setblock 517 232 256 minecraft:magenta_terracotta
setblock 517 232 260 minecraft:magenta_terracotta
setblock 517 232 264 minecraft:magenta_terracotta
setblock 517 232 268 minecraft:magenta_terracotta
setblock 517 232 270 minecraft:magenta_terracotta
setblock 521 232 228 minecraft:magenta_terracotta
setblock 521 232 270 minecraft:magenta_terracotta
setblock 525 232 228 minecraft:magenta_terracotta
setblock 525 232 270 minecraft:magenta_terracotta
setblock 529 232 228 minecraft:magenta_terracotta
setblock 529 232 270 minecraft:magenta_terracotta
setblock 533 232 228 minecraft:magenta_terracotta
setblock 533 232 270 minecraft:magenta_terracotta
setblock 537 232 228 minecraft:magenta_terracotta
setblock 537 232 270 minecraft:magenta_terracotta
setblock 541 232 228 minecraft:magenta_terracotta
setblock 541 232 270 minecraft:magenta_terracotta
fill 544 232 268 545 232 269 minecraft:dark_oak_planks
setblock 545 232 228 minecraft:magenta_terracotta
setblock 545 232 270 minecraft:magenta_terracotta
fill 546 232 268 547 232 268 minecraft:spruce_planks
fill 547 232 255 548 234 257 minecraft:white_concrete
setblock 548 232 254 minecraft:black_concrete
setblock 549 232 228 minecraft:magenta_terracotta
fill 549 232 255 549 234 256 minecraft:white_concrete
setblock 549 232 270 minecraft:magenta_terracotta
setblock 553 232 228 minecraft:magenta_terracotta
setblock 553 232 270 minecraft:magenta_terracotta
setblock 557 232 228 minecraft:magenta_terracotta
setblock 557 232 270 minecraft:magenta_terracotta
setblock 559 232 228 minecraft:magenta_terracotta
setblock 559 232 232 minecraft:magenta_terracotta
setblock 559 232 236 minecraft:magenta_terracotta
setblock 559 232 240 minecraft:magenta_terracotta
setblock 559 232 244 minecraft:magenta_terracotta
setblock 559 232 248 minecraft:magenta_terracotta
setblock 559 232 252 minecraft:magenta_terracotta
setblock 559 232 256 minecraft:magenta_terracotta
setblock 559 232 260 minecraft:magenta_terracotta
fill 559 232 263 559 278 263 minecraft:purple_terracotta
setblock 559 232 264 minecraft:magenta_terracotta
setblock 559 232 268 minecraft:magenta_terracotta
fill 517 233 228 517 235 228 minecraft:purple_terracotta
fill 517 233 232 517 235 232 minecraft:purple_terracotta
fill 517 233 236 517 235 236 minecraft:purple_terracotta
fill 517 233 240 517 235 240 minecraft:purple_terracotta
fill 517 233 244 517 235 244 minecraft:purple_terracotta
fill 517 233 248 517 235 248 minecraft:purple_terracotta
fill 517 233 252 517 235 252 minecraft:purple_terracotta
fill 517 233 256 517 235 256 minecraft:purple_terracotta
fill 517 233 260 517 235 260 minecraft:purple_terracotta
fill 517 233 264 517 235 264 minecraft:purple_terracotta
fill 517 233 268 517 235 268 minecraft:purple_terracotta
setblock 517 233 270 minecraft:purple_terracotta
setblock 520 233 231 minecraft:light[level=11]
setblock 520 233 239 minecraft:light[level=11]
setblock 520 233 247 minecraft:light[level=11]
setblock 520 233 255 minecraft:light[level=11]
setblock 520 233 263 minecraft:light[level=11]
fill 521 233 228 521 235 228 minecraft:purple_terracotta
fill 521 233 270 521 235 270 minecraft:purple_terracotta
fill 525 233 228 525 235 228 minecraft:purple_terracotta
fill 525 233 270 525 235 270 minecraft:purple_terracotta
setblock 528 233 231 minecraft:light[level=11]
setblock 528 233 239 minecraft:light[level=11]
setblock 528 233 247 minecraft:light[level=11]
setblock 528 233 255 minecraft:light[level=11]
setblock 528 233 263 minecraft:light[level=11]
fill 529 233 228 529 235 228 minecraft:purple_terracotta
fill 529 233 270 529 235 270 minecraft:purple_terracotta
fill 533 233 228 533 235 228 minecraft:purple_terracotta
fill 533 233 270 533 235 270 minecraft:purple_terracotta
setblock 536 233 231 minecraft:light[level=11]
setblock 536 233 233 minecraft:jack_o_lantern
setblock 536 233 239 minecraft:light[level=11]
setblock 536 233 247 minecraft:light[level=11]
setblock 536 233 255 minecraft:light[level=11]
setblock 536 233 263 minecraft:light[level=11]
fill 537 233 228 537 235 228 minecraft:purple_terracotta
fill 537 233 270 537 235 270 minecraft:purple_terracotta
fill 541 233 228 541 235 228 minecraft:purple_terracotta
fill 541 233 270 541 235 270 minecraft:purple_terracotta
setblock 544 233 231 minecraft:light[level=11]
setblock 544 233 239 minecraft:light[level=11]
setblock 544 233 247 minecraft:light[level=11]
setblock 544 233 255 minecraft:light[level=11]
setblock 544 233 263 minecraft:light[level=11]
fill 544 233 265 544 236 265 minecraft:iron_bars
fill 545 233 228 545 235 228 minecraft:purple_terracotta
fill 545 233 270 545 235 270 minecraft:purple_terracotta
fill 546 233 268 547 233 269 minecraft:dark_oak_planks
setblock 548 233 254 minecraft:white_stained_glass
fill 548 233 268 549 233 268 minecraft:spruce_planks
fill 549 233 228 549 235 228 minecraft:purple_terracotta
setblock 549 233 257 minecraft:white_concrete
fill 549 233 270 549 235 270 minecraft:purple_terracotta
setblock 552 233 231 minecraft:light[level=11]
setblock 552 233 239 minecraft:light[level=11]
setblock 552 233 247 minecraft:light[level=11]
setblock 552 233 255 minecraft:light[level=11]
setblock 552 233 263 minecraft:light[level=11]
fill 553 233 228 553 235 228 minecraft:purple_terracotta
fill 553 233 270 553 235 270 minecraft:purple_terracotta
fill 557 233 228 557 235 228 minecraft:purple_terracotta
fill 557 233 270 557 235 270 minecraft:purple_terracotta
setblock 559 233 228 minecraft:purple_terracotta
fill 559 233 232 559 235 232 minecraft:purple_terracotta
fill 559 233 236 559 235 236 minecraft:purple_terracotta
fill 559 233 240 559 235 240 minecraft:purple_terracotta
fill 559 233 244 559 235 244 minecraft:purple_terracotta
fill 559 233 248 559 235 248 minecraft:purple_terracotta
fill 559 233 252 559 235 252 minecraft:purple_terracotta
fill 559 233 256 559 235 256 minecraft:purple_terracotta
fill 559 233 260 559 235 260 minecraft:purple_terracotta
fill 559 233 264 559 235 264 minecraft:purple_terracotta
fill 559 233 268 559 235 268 minecraft:purple_terracotta
setblock 517 234 230 minecraft:magenta_terracotta
setblock 517 234 234 minecraft:magenta_terracotta
setblock 517 234 238 minecraft:magenta_terracotta
setblock 517 234 242 minecraft:magenta_terracotta
setblock 517 234 246 minecraft:magenta_terracotta
setblock 517 234 250 minecraft:magenta_terracotta
setblock 517 234 254 minecraft:magenta_terracotta
setblock 517 234 258 minecraft:magenta_terracotta
setblock 517 234 262 minecraft:magenta_terracotta
setblock 517 234 266 minecraft:magenta_terracotta
setblock 517 234 270 minecraft:magenta_terracotta
setblock 519 234 228 minecraft:magenta_terracotta
setblock 519 234 270 minecraft:magenta_terracotta
setblock 523 234 228 minecraft:magenta_terracotta
setblock 523 234 270 minecraft:magenta_terracotta
setblock 527 234 228 minecraft:magenta_terracotta
setblock 527 234 270 minecraft:magenta_terracotta
fill 528 234 270 528 251 270 minecraft:purple_terracotta
setblock 531 234 228 minecraft:magenta_terracotta
setblock 531 234 270 minecraft:magenta_terracotta
setblock 535 234 228 minecraft:magenta_terracotta
setblock 535 234 270 minecraft:magenta_terracotta
setblock 539 234 228 minecraft:magenta_terracotta
setblock 539 234 270 minecraft:magenta_terracotta
setblock 543 234 228 minecraft:magenta_terracotta
setblock 543 234 270 minecraft:magenta_terracotta
setblock 547 234 228 minecraft:magenta_terracotta
setblock 547 234 270 minecraft:magenta_terracotta
fill 548 234 268 549 234 269 minecraft:dark_oak_planks
fill 550 234 268 551 234 268 minecraft:spruce_planks
setblock 551 234 228 minecraft:magenta_terracotta
setblock 551 234 270 minecraft:magenta_terracotta
setblock 555 234 228 minecraft:magenta_terracotta
setblock 555 234 270 minecraft:magenta_terracotta
setblock 559 234 228 minecraft:magenta_terracotta
setblock 559 234 230 minecraft:magenta_terracotta
setblock 559 234 234 minecraft:magenta_terracotta
setblock 559 234 238 minecraft:magenta_terracotta
setblock 559 234 242 minecraft:magenta_terracotta
setblock 559 234 246 minecraft:magenta_terracotta
setblock 559 234 250 minecraft:magenta_terracotta
setblock 559 234 254 minecraft:magenta_terracotta
setblock 559 234 255 minecraft:black_terracotta
setblock 559 234 258 minecraft:magenta_terracotta
setblock 559 234 262 minecraft:magenta_terracotta
setblock 559 234 266 minecraft:magenta_terracotta
setblock 559 234 270 minecraft:magenta_terracotta
fill 517 235 230 517 237 230 minecraft:purple_terracotta
fill 517 235 234 517 237 234 minecraft:purple_terracotta
fill 517 235 238 517 237 238 minecraft:purple_terracotta
fill 517 235 242 517 237 242 minecraft:purple_terracotta
fill 517 235 246 517 237 246 minecraft:purple_terracotta
fill 517 235 250 517 237 250 minecraft:purple_terracotta
fill 517 235 254 517 237 254 minecraft:purple_terracotta
fill 517 235 258 517 237 258 minecraft:purple_terracotta
fill 517 235 262 517 237 262 minecraft:purple_terracotta
fill 517 235 266 517 237 266 minecraft:purple_terracotta
setblock 517 235 270 minecraft:purple_terracotta
fill 519 235 228 519 237 228 minecraft:purple_terracotta
fill 519 235 270 519 237 270 minecraft:purple_terracotta
setblock 520 235 231 minecraft:light[level=12]
setblock 520 235 238 minecraft:light[level=12]
setblock 520 235 245 minecraft:light[level=12]
setblock 520 235 252 minecraft:light[level=12]
setblock 520 235 259 minecraft:light[level=12]
setblock 520 235 266 minecraft:light[level=12]
fill 523 235 228 523 237 228 minecraft:purple_terracotta
fill 523 235 270 523 237 270 minecraft:purple_terracotta
fill 527 235 228 527 237 228 minecraft:purple_terracotta
setblock 527 235 231 minecraft:light[level=12]
setblock 527 235 238 minecraft:light[level=12]
setblock 527 235 245 minecraft:light[level=12]
setblock 527 235 252 minecraft:light[level=12]
setblock 527 235 259 minecraft:light[level=12]
setblock 527 235 266 minecraft:light[level=12]
fill 527 235 270 527 237 270 minecraft:purple_terracotta
fill 531 235 228 531 237 228 minecraft:purple_terracotta
fill 531 235 270 531 237 270 minecraft:purple_terracotta
setblock 534 235 231 minecraft:light[level=12]
setblock 534 235 238 minecraft:light[level=12]
setblock 534 235 245 minecraft:light[level=12]
setblock 534 235 252 minecraft:light[level=12]
setblock 534 235 259 minecraft:light[level=12]
setblock 534 235 266 minecraft:light[level=12]
fill 535 235 228 535 237 228 minecraft:purple_terracotta
fill 535 235 270 535 237 270 minecraft:purple_terracotta
fill 539 235 228 539 237 228 minecraft:purple_terracotta
fill 539 235 270 539 237 270 minecraft:purple_terracotta
setblock 541 235 231 minecraft:light[level=12]
setblock 541 235 238 minecraft:light[level=12]
setblock 541 235 245 minecraft:light[level=12]
setblock 541 235 252 minecraft:light[level=12]
setblock 541 235 259 minecraft:light[level=12]
setblock 541 235 266 minecraft:light[level=12]
fill 543 235 228 543 237 228 minecraft:purple_terracotta
fill 543 235 270 543 237 270 minecraft:purple_terracotta
fill 547 235 228 547 237 228 minecraft:purple_terracotta
fill 547 235 270 547 237 270 minecraft:purple_terracotta
setblock 548 235 231 minecraft:light[level=12]
setblock 548 235 238 minecraft:light[level=12]
setblock 548 235 245 minecraft:light[level=12]
setblock 548 235 252 minecraft:light[level=12]
setblock 548 235 259 minecraft:light[level=12]
setblock 548 235 266 minecraft:light[level=12]
fill 550 235 268 551 235 269 minecraft:dark_oak_planks
fill 551 235 228 551 237 228 minecraft:purple_terracotta
fill 551 235 270 551 237 270 minecraft:purple_terracotta
fill 552 235 268 553 235 268 minecraft:spruce_planks
fill 555 235 228 555 237 228 minecraft:purple_terracotta
setblock 555 235 231 minecraft:light[level=12]
setblock 555 235 238 minecraft:light[level=12]
setblock 555 235 245 minecraft:light[level=12]
setblock 555 235 252 minecraft:light[level=12]
setblock 555 235 259 minecraft:light[level=12]
setblock 555 235 266 minecraft:light[level=12]
fill 555 235 270 555 237 270 minecraft:purple_terracotta
setblock 559 235 228 minecraft:purple_terracotta
fill 559 235 230 559 237 230 minecraft:purple_terracotta
fill 559 235 234 559 237 234 minecraft:purple_terracotta
fill 559 235 238 559 237 238 minecraft:purple_terracotta
fill 559 235 242 559 237 242 minecraft:purple_terracotta
fill 559 235 246 559 237 246 minecraft:purple_terracotta
fill 559 235 250 559 237 250 minecraft:purple_terracotta
fill 559 235 254 559 237 255 minecraft:purple_terracotta
fill 559 235 258 559 237 258 minecraft:purple_terracotta
fill 559 235 262 559 237 262 minecraft:purple_terracotta
fill 559 235 266 559 237 266 minecraft:purple_terracotta
fill 559 235 270 559 237 270 minecraft:purple_terracotta
setblock 517 236 228 minecraft:magenta_terracotta
setblock 517 236 232 minecraft:magenta_terracotta
setblock 517 236 236 minecraft:magenta_terracotta
setblock 517 236 240 minecraft:magenta_terracotta
setblock 517 236 244 minecraft:magenta_terracotta
setblock 517 236 248 minecraft:magenta_terracotta
setblock 517 236 252 minecraft:magenta_terracotta
setblock 517 236 256 minecraft:magenta_terracotta
setblock 517 236 260 minecraft:magenta_terracotta
setblock 517 236 264 minecraft:magenta_terracotta
setblock 517 236 268 minecraft:magenta_terracotta
setblock 517 236 270 minecraft:magenta_terracotta
setblock 521 236 228 minecraft:magenta_terracotta
setblock 521 236 270 minecraft:magenta_terracotta
setblock 525 236 228 minecraft:magenta_terracotta
setblock 525 236 270 minecraft:magenta_terracotta
setblock 529 236 228 minecraft:magenta_terracotta
setblock 529 236 270 minecraft:magenta_terracotta
setblock 533 236 228 minecraft:magenta_terracotta
setblock 533 236 270 minecraft:magenta_terracotta
setblock 537 236 228 minecraft:magenta_terracotta
setblock 537 236 270 minecraft:magenta_terracotta
setblock 541 236 228 minecraft:magenta_terracotta
setblock 541 236 270 minecraft:magenta_terracotta
setblock 545 236 228 minecraft:magenta_terracotta
setblock 545 236 270 minecraft:magenta_terracotta
setblock 549 236 228 minecraft:magenta_terracotta
setblock 549 236 270 minecraft:magenta_terracotta
fill 552 236 268 553 236 269 minecraft:dark_oak_planks
setblock 553 236 228 minecraft:magenta_terracotta
setblock 553 236 270 minecraft:magenta_terracotta
fill 554 236 268 555 236 268 minecraft:spruce_planks
setblock 557 236 228 minecraft:magenta_terracotta
setblock 557 236 270 minecraft:magenta_terracotta
setblock 559 236 228 minecraft:magenta_terracotta
setblock 559 236 232 minecraft:magenta_terracotta
setblock 559 236 236 minecraft:magenta_terracotta
setblock 559 236 240 minecraft:magenta_terracotta
setblock 559 236 244 minecraft:magenta_terracotta
setblock 559 236 248 minecraft:magenta_terracotta
setblock 559 236 252 minecraft:magenta_terracotta
setblock 559 236 256 minecraft:magenta_terracotta
setblock 559 236 260 minecraft:magenta_terracotta
setblock 559 236 264 minecraft:magenta_terracotta
setblock 559 236 268 minecraft:magenta_terracotta
fill 517 237 228 517 239 228 minecraft:purple_terracotta
fill 517 237 232 517 239 232 minecraft:purple_terracotta
fill 517 237 236 517 239 236 minecraft:purple_terracotta
fill 517 237 240 517 239 240 minecraft:purple_terracotta
fill 517 237 244 517 239 244 minecraft:purple_terracotta
fill 517 237 248 517 239 248 minecraft:purple_terracotta
fill 517 237 252 517 239 252 minecraft:purple_terracotta
fill 517 237 256 517 239 256 minecraft:purple_terracotta
fill 517 237 260 517 239 260 minecraft:purple_terracotta
fill 517 237 264 517 239 264 minecraft:purple_terracotta
fill 517 237 268 517 239 268 minecraft:purple_terracotta
setblock 517 237 270 minecraft:purple_terracotta
fill 521 237 228 521 239 228 minecraft:purple_terracotta
fill 521 237 270 521 239 270 minecraft:purple_terracotta
fill 525 237 228 525 239 228 minecraft:purple_terracotta
fill 525 237 270 525 239 270 minecraft:purple_terracotta
fill 529 237 228 529 239 228 minecraft:purple_terracotta
fill 529 237 270 529 239 270 minecraft:purple_terracotta
fill 533 237 228 533 239 228 minecraft:purple_terracotta
fill 533 237 270 533 239 270 minecraft:purple_terracotta
fill 537 237 228 537 239 228 minecraft:purple_terracotta
fill 537 237 270 537 239 270 minecraft:purple_terracotta
fill 539 237 265 549 237 268 minecraft:dark_oak_planks
fill 541 237 228 541 239 228 minecraft:purple_terracotta
fill 541 237 270 541 239 270 minecraft:purple_terracotta
fill 545 237 228 545 239 228 minecraft:purple_terracotta
fill 545 237 270 545 239 270 minecraft:purple_terracotta
fill 549 237 228 549 239 228 minecraft:purple_terracotta
fill 549 237 270 549 239 270 minecraft:purple_terracotta
fill 553 237 228 553 239 228 minecraft:purple_terracotta
fill 553 237 270 553 239 270 minecraft:purple_terracotta
fill 554 237 268 555 237 269 minecraft:dark_oak_planks
fill 556 237 268 557 237 268 minecraft:spruce_planks
fill 557 237 228 557 239 228 minecraft:purple_terracotta
fill 557 237 270 557 239 270 minecraft:purple_terracotta
setblock 559 237 228 minecraft:purple_terracotta
fill 559 237 232 559 239 232 minecraft:purple_terracotta
fill 559 237 236 559 239 236 minecraft:purple_terracotta
fill 559 237 240 559 239 240 minecraft:purple_terracotta
fill 559 237 244 559 239 244 minecraft:purple_terracotta
fill 559 237 248 559 239 248 minecraft:purple_terracotta
fill 559 237 252 559 239 252 minecraft:purple_terracotta
fill 559 237 256 559 239 256 minecraft:purple_terracotta
fill 559 237 260 559 239 260 minecraft:purple_terracotta
fill 559 237 264 559 239 264 minecraft:purple_terracotta
fill 559 237 268 559 239 268 minecraft:purple_terracotta
setblock 517 238 230 minecraft:magenta_terracotta
setblock 517 238 234 minecraft:magenta_terracotta
setblock 517 238 238 minecraft:magenta_terracotta
setblock 517 238 242 minecraft:magenta_terracotta
setblock 517 238 246 minecraft:magenta_terracotta
setblock 517 238 250 minecraft:magenta_terracotta
setblock 517 238 254 minecraft:magenta_terracotta
setblock 517 238 258 minecraft:magenta_terracotta
setblock 517 238 259 minecraft:black_terracotta
setblock 517 238 262 minecraft:magenta_terracotta
setblock 517 238 266 minecraft:magenta_terracotta
setblock 517 238 270 minecraft:magenta_terracotta
setblock 519 238 228 minecraft:magenta_terracotta
setblock 519 238 270 minecraft:magenta_terracotta
setblock 523 238 228 minecraft:magenta_terracotta
setblock 523 238 270 minecraft:magenta_terracotta
setblock 527 238 228 minecraft:magenta_terracotta
setblock 527 238 270 minecraft:magenta_terracotta
setblock 531 238 228 minecraft:magenta_terracotta
setblock 531 238 270 minecraft:magenta_terracotta
setblock 535 238 228 minecraft:magenta_terracotta
setblock 535 238 270 minecraft:magenta_terracotta
setblock 539 238 228 minecraft:magenta_terracotta
fill 539 238 265 549 238 268 minecraft:stripped_dark_oak_log
setblock 539 238 270 minecraft:magenta_terracotta
setblock 543 238 228 minecraft:magenta_terracotta
setblock 543 238 270 minecraft:magenta_terracotta
setblock 547 238 228 minecraft:magenta_terracotta
setblock 547 238 270 minecraft:magenta_terracotta
setblock 551 238 228 minecraft:magenta_terracotta
setblock 551 238 270 minecraft:magenta_terracotta
setblock 555 238 228 minecraft:magenta_terracotta
setblock 555 238 270 minecraft:magenta_terracotta
fill 556 238 268 558 238 269 minecraft:dark_oak_planks
setblock 557 238 267 minecraft:spruce_planks
setblock 559 238 228 minecraft:magenta_terracotta
setblock 559 238 230 minecraft:magenta_terracotta
setblock 559 238 234 minecraft:magenta_terracotta
setblock 559 238 238 minecraft:magenta_terracotta
setblock 559 238 242 minecraft:magenta_terracotta
setblock 559 238 246 minecraft:magenta_terracotta
setblock 559 238 250 minecraft:magenta_terracotta
setblock 559 238 254 minecraft:magenta_terracotta
fill 559 238 255 559 278 255 minecraft:purple_terracotta
setblock 559 238 258 minecraft:magenta_terracotta
setblock 559 238 262 minecraft:magenta_terracotta
setblock 559 238 266 minecraft:magenta_terracotta
setblock 559 238 270 minecraft:magenta_terracotta
fill 517 239 230 517 241 230 minecraft:purple_terracotta
fill 517 239 234 517 241 234 minecraft:purple_terracotta
fill 517 239 238 517 241 238 minecraft:purple_terracotta
fill 517 239 242 517 241 242 minecraft:purple_terracotta
fill 517 239 246 517 241 246 minecraft:purple_terracotta
fill 517 239 250 517 241 250 minecraft:purple_terracotta
fill 517 239 254 517 241 254 minecraft:purple_terracotta
fill 517 239 258 517 241 259 minecraft:purple_terracotta
fill 517 239 262 517 241 262 minecraft:purple_terracotta
fill 517 239 266 517 241 266 minecraft:purple_terracotta
setblock 517 239 270 minecraft:purple_terracotta
setblock 519 239 228 minecraft:gray_terracotta
fill 519 239 270 519 241 270 minecraft:purple_terracotta
fill 523 239 228 523 241 228 minecraft:purple_terracotta
fill 523 239 270 523 241 270 minecraft:purple_terracotta
fill 527 239 228 527 241 228 minecraft:purple_terracotta
fill 527 239 270 527 241 270 minecraft:purple_terracotta
fill 531 239 228 531 241 228 minecraft:purple_terracotta
fill 531 239 270 531 241 270 minecraft:purple_terracotta
fill 535 239 228 535 241 228 minecraft:purple_terracotta
fill 535 239 270 535 241 270 minecraft:purple_terracotta
fill 539 239 228 539 241 228 minecraft:purple_terracotta
fill 539 239 265 549 239 265 minecraft:purple_concrete
fill 539 239 270 539 241 270 minecraft:purple_terracotta
fill 543 239 228 543 241 228 minecraft:purple_terracotta
fill 543 239 269 545 242 269 minecraft:jack_o_lantern
fill 543 239 270 543 241 270 minecraft:purple_terracotta
setblock 547 239 228 minecraft:purple_terracotta
fill 547 239 270 547 241 270 minecraft:purple_terracotta
fill 551 239 228 551 241 228 minecraft:purple_terracotta
fill 551 239 270 551 241 270 minecraft:purple_terracotta
fill 555 239 228 555 241 228 minecraft:purple_terracotta
fill 555 239 270 555 241 270 minecraft:purple_terracotta
fill 557 239 265 557 239 266 minecraft:spruce_planks
fill 557 239 267 558 239 269 minecraft:dark_oak_planks
setblock 559 239 228 minecraft:purple_terracotta
fill 559 239 230 559 241 230 minecraft:purple_terracotta
fill 559 239 234 559 241 234 minecraft:purple_terracotta
fill 559 239 238 559 241 238 minecraft:purple_terracotta
fill 559 239 242 559 241 242 minecraft:purple_terracotta
fill 559 239 246 559 241 246 minecraft:purple_terracotta
fill 559 239 250 559 241 250 minecraft:purple_terracotta
fill 559 239 254 559 241 254 minecraft:purple_terracotta
fill 559 239 258 559 241 258 minecraft:purple_terracotta
fill 559 239 262 559 241 262 minecraft:purple_terracotta
fill 559 239 266 559 241 266 minecraft:purple_terracotta
fill 559 239 270 559 241 270 minecraft:purple_terracotta
setblock 517 240 228 minecraft:magenta_terracotta
setblock 517 240 232 minecraft:magenta_terracotta
setblock 517 240 236 minecraft:magenta_terracotta
setblock 517 240 240 minecraft:magenta_terracotta
setblock 517 240 244 minecraft:magenta_terracotta
setblock 517 240 248 minecraft:magenta_terracotta
setblock 517 240 252 minecraft:magenta_terracotta
setblock 517 240 256 minecraft:magenta_terracotta
setblock 517 240 260 minecraft:magenta_terracotta
setblock 517 240 263 minecraft:gray_terracotta
setblock 517 240 264 minecraft:magenta_terracotta
setblock 517 240 268 minecraft:magenta_terracotta
setblock 517 240 270 minecraft:magenta_terracotta
fill 519 240 228 519 241 228 minecraft:purple_terracotta
setblock 521 240 228 minecraft:magenta_terracotta
setblock 521 240 270 minecraft:magenta_terracotta
setblock 525 240 228 minecraft:magenta_terracotta
setblock 525 240 270 minecraft:magenta_terracotta
setblock 529 240 228 minecraft:magenta_terracotta
setblock 529 240 270 minecraft:magenta_terracotta
setblock 533 240 228 minecraft:magenta_terracotta
setblock 533 240 270 minecraft:magenta_terracotta
fill 535 240 245 535 251 245 minecraft:iron_bars
fill 535 240 253 535 251 253 minecraft:iron_bars
setblock 537 240 228 minecraft:magenta_terracotta
setblock 537 240 270 minecraft:magenta_terracotta
setblock 539 240 265 minecraft:stripped_dark_oak_log
setblock 541 240 228 minecraft:magenta_terracotta
setblock 541 240 270 minecraft:magenta_terracotta
setblock 544 240 265 minecraft:stripped_dark_oak_log
setblock 545 240 228 minecraft:magenta_terracotta
setblock 545 240 270 minecraft:magenta_terracotta
setblock 547 240 228 minecraft:light_gray_terracotta
setblock 549 240 228 minecraft:magenta_terracotta
setblock 549 240 265 minecraft:stripped_dark_oak_log
setblock 549 240 270 minecraft:magenta_terracotta
setblock 553 240 228 minecraft:magenta_terracotta
setblock 553 240 270 minecraft:magenta_terracotta
setblock 557 240 228 minecraft:magenta_terracotta
fill 557 240 263 557 240 264 minecraft:spruce_planks
fill 557 240 265 558 240 266 minecraft:dark_oak_planks
setblock 557 240 270 minecraft:magenta_terracotta
setblock 559 240 228 minecraft:magenta_terracotta
setblock 559 240 232 minecraft:magenta_terracotta
setblock 559 240 236 minecraft:magenta_terracotta
setblock 559 240 240 minecraft:magenta_terracotta
setblock 559 240 244 minecraft:magenta_terracotta
setblock 559 240 248 minecraft:magenta_terracotta
setblock 559 240 252 minecraft:magenta_terracotta
setblock 559 240 256 minecraft:magenta_terracotta
setblock 559 240 260 minecraft:magenta_terracotta
setblock 559 240 264 minecraft:magenta_terracotta
setblock 559 240 268 minecraft:magenta_terracotta
fill 517 241 228 517 243 228 minecraft:purple_terracotta
fill 517 241 232 517 243 232 minecraft:purple_terracotta
fill 517 241 236 517 243 236 minecraft:purple_terracotta
fill 517 241 240 517 243 240 minecraft:purple_terracotta
fill 517 241 244 517 243 244 minecraft:purple_terracotta
fill 517 241 248 517 243 248 minecraft:purple_terracotta
setblock 517 241 252 minecraft:black_terracotta
fill 517 241 256 517 243 256 minecraft:purple_terracotta
fill 517 241 260 517 243 260 minecraft:purple_terracotta
fill 517 241 263 517 243 264 minecraft:purple_terracotta
fill 517 241 268 517 243 268 minecraft:purple_terracotta
setblock 517 241 270 minecraft:purple_terracotta
setblock 520 241 231 minecraft:light[level=11]
setblock 520 241 238 minecraft:light[level=12]
setblock 520 241 239 minecraft:light[level=11]
setblock 520 241 245 minecraft:light[level=12]
setblock 520 241 247 minecraft:light[level=11]
setblock 520 241 252 minecraft:light[level=12]
setblock 520 241 255 minecraft:light[level=11]
setblock 520 241 259 minecraft:light[level=12]
setblock 520 241 263 minecraft:light[level=11]
setblock 520 241 266 minecraft:light[level=12]
fill 521 241 228 521 243 228 minecraft:purple_terracotta
fill 521 241 270 521 243 270 minecraft:purple_terracotta
fill 525 241 228 525 243 228 minecraft:purple_terracotta
fill 525 241 270 525 243 270 minecraft:purple_terracotta
setblock 527 241 231 minecraft:light[level=12]
setblock 527 241 238 minecraft:light[level=12]
setblock 527 241 245 minecraft:light[level=12]
setblock 527 241 252 minecraft:light[level=12]
setblock 527 241 259 minecraft:light[level=12]
setblock 527 241 266 minecraft:light[level=12]
setblock 528 241 231 minecraft:light[level=11]
setblock 528 241 239 minecraft:light[level=11]
setblock 528 241 247 minecraft:light[level=11]
setblock 528 241 255 minecraft:light[level=11]
setblock 528 241 263 minecraft:light[level=11]
fill 529 241 228 529 243 228 minecraft:purple_terracotta
fill 529 241 270 529 243 270 minecraft:purple_terracotta
fill 533 241 228 533 243 228 minecraft:purple_terracotta
fill 533 241 270 533 243 270 minecraft:purple_terracotta
setblock 534 241 231 minecraft:light[level=12]
setblock 534 241 238 minecraft:light[level=12]
setblock 534 241 245 minecraft:light[level=12]
setblock 534 241 252 minecraft:light[level=12]
setblock 534 241 259 minecraft:light[level=12]
setblock 534 241 266 minecraft:light[level=12]
fill 535 241 269 539 241 269 minecraft:gold_block
setblock 536 241 231 minecraft:light[level=11]
setblock 536 241 239 minecraft:light[level=11]
setblock 536 241 247 minecraft:light[level=11]
setblock 536 241 255 minecraft:light[level=11]
setblock 536 241 263 minecraft:light[level=11]
fill 537 241 228 537 243 228 minecraft:purple_terracotta
fill 537 241 270 537 243 270 minecraft:purple_terracotta
fill 541 241 228 541 243 228 minecraft:purple_terracotta
setblock 541 241 231 minecraft:light[level=12]
setblock 541 241 238 minecraft:light[level=12]
setblock 541 241 245 minecraft:light[level=12]
setblock 541 241 252 minecraft:light[level=12]
setblock 541 241 259 minecraft:light[level=12]
setblock 541 241 266 minecraft:light[level=12]
fill 541 241 270 541 243 270 minecraft:purple_terracotta
setblock 544 241 231 minecraft:light[level=11]
setblock 544 241 239 minecraft:light[level=11]
setblock 544 241 247 minecraft:light[level=11]
setblock 544 241 255 minecraft:light[level=11]
setblock 544 241 263 minecraft:light[level=11]
fill 545 241 228 545 243 228 minecraft:purple_terracotta
fill 545 241 270 545 243 270 minecraft:purple_terracotta
setblock 547 241 228 minecraft:purple_terracotta
setblock 548 241 231 minecraft:light[level=12]
setblock 548 241 238 minecraft:light[level=12]
setblock 548 241 245 minecraft:light[level=12]
setblock 548 241 252 minecraft:light[level=12]
setblock 548 241 259 minecraft:light[level=12]
setblock 548 241 266 minecraft:light[level=12]
fill 549 241 228 549 243 228 minecraft:purple_terracotta
fill 549 241 270 549 243 270 minecraft:purple_terracotta
setblock 552 241 231 minecraft:light[level=11]
setblock 552 241 239 minecraft:light[level=11]
setblock 552 241 247 minecraft:light[level=11]
setblock 552 241 255 minecraft:light[level=11]
setblock 552 241 263 minecraft:light[level=11]
fill 553 241 228 553 243 228 minecraft:purple_terracotta
fill 553 241 270 553 243 270 minecraft:purple_terracotta
setblock 555 241 231 minecraft:light[level=12]
setblock 555 241 238 minecraft:light[level=12]
setblock 555 241 245 minecraft:light[level=12]
setblock 555 241 252 minecraft:light[level=12]
setblock 555 241 259 minecraft:light[level=12]
setblock 555 241 266 minecraft:light[level=12]
fill 557 241 228 557 243 228 minecraft:purple_terracotta
fill 557 241 261 557 241 262 minecraft:spruce_planks
fill 557 241 263 558 241 264 minecraft:dark_oak_planks
fill 557 241 270 557 243 270 minecraft:purple_terracotta
setblock 559 241 228 minecraft:purple_terracotta
fill 559 241 232 559 243 232 minecraft:purple_terracotta
fill 559 241 236 559 243 236 minecraft:purple_terracotta
fill 559 241 240 559 243 240 minecraft:purple_terracotta
fill 559 241 244 559 243 244 minecraft:purple_terracotta
fill 559 241 248 559 243 248 minecraft:purple_terracotta
fill 559 241 252 559 243 252 minecraft:purple_terracotta
fill 559 241 256 559 243 256 minecraft:purple_terracotta
fill 559 241 260 559 243 260 minecraft:purple_terracotta
fill 559 241 264 559 243 264 minecraft:purple_terracotta
fill 559 241 268 559 243 268 minecraft:purple_terracotta
setblock 517 242 230 minecraft:magenta_terracotta
setblock 517 242 234 minecraft:magenta_terracotta
setblock 517 242 238 minecraft:magenta_terracotta
setblock 517 242 242 minecraft:magenta_terracotta
setblock 517 242 246 minecraft:magenta_terracotta
setblock 517 242 250 minecraft:magenta_terracotta
fill 517 242 252 517 243 252 minecraft:purple_terracotta
setblock 517 242 254 minecraft:magenta_terracotta
setblock 517 242 258 minecraft:magenta_terracotta
fill 517 242 259 517 278 259 minecraft:purple_terracotta
setblock 517 242 262 minecraft:magenta_terracotta
setblock 517 242 266 minecraft:gray_terracotta
setblock 517 242 270 minecraft:magenta_terracotta
setblock 519 242 228 minecraft:magenta_terracotta
setblock 519 242 270 minecraft:magenta_terracotta
setblock 523 242 228 minecraft:magenta_terracotta
setblock 523 242 270 minecraft:magenta_terracotta
setblock 527 242 228 minecraft:magenta_terracotta
setblock 527 242 270 minecraft:magenta_terracotta
setblock 531 242 228 minecraft:magenta_terracotta
setblock 531 242 270 minecraft:magenta_terracotta
setblock 535 242 228 minecraft:magenta_terracotta
fill 535 242 269 535 247 269 minecraft:gold_block
setblock 535 242 270 minecraft:magenta_terracotta
fill 536 242 269 538 243 269 minecraft:brown_concrete
setblock 539 242 228 minecraft:magenta_terracotta
fill 539 242 269 539 247 269 minecraft:gold_block
setblock 539 242 270 minecraft:magenta_terracotta
fill 542 242 245 542 253 245 minecraft:iron_bars
fill 542 242 253 542 253 253 minecraft:iron_bars
setblock 543 242 228 minecraft:magenta_terracotta
setblock 543 242 270 minecraft:magenta_terracotta
setblock 547 242 228 minecraft:magenta_terracotta
setblock 547 242 270 minecraft:magenta_terracotta
setblock 551 242 228 minecraft:magenta_terracotta
setblock 551 242 270 minecraft:magenta_terracotta
setblock 555 242 228 minecraft:magenta_terracotta
setblock 555 242 270 minecraft:magenta_terracotta
fill 557 242 259 557 242 260 minecraft:spruce_planks
fill 557 242 261 558 242 262 minecraft:dark_oak_planks
setblock 559 242 228 minecraft:magenta_terracotta
setblock 559 242 230 minecraft:magenta_terracotta
setblock 559 242 234 minecraft:magenta_terracotta
setblock 559 242 238 minecraft:magenta_terracotta
setblock 559 242 242 minecraft:magenta_terracotta
setblock 559 242 246 minecraft:magenta_terracotta
setblock 559 242 250 minecraft:magenta_terracotta
setblock 559 242 254 minecraft:magenta_terracotta
setblock 559 242 258 minecraft:magenta_terracotta
setblock 559 242 262 minecraft:magenta_terracotta
setblock 559 242 266 minecraft:magenta_terracotta
setblock 559 242 270 minecraft:magenta_terracotta
fill 517 243 230 517 245 230 minecraft:purple_terracotta
fill 517 243 234 517 245 234 minecraft:purple_terracotta
fill 517 243 238 517 245 238 minecraft:purple_terracotta
fill 517 243 242 517 245 242 minecraft:purple_terracotta
fill 517 243 246 517 245 246 minecraft:purple_terracotta
fill 517 243 250 517 245 250 minecraft:purple_terracotta
setblock 517 243 253 minecraft:light_gray_terracotta
fill 517 243 254 517 245 254 minecraft:purple_terracotta
fill 517 243 258 517 245 258 minecraft:purple_terracotta
fill 517 243 262 517 245 262 minecraft:purple_terracotta
fill 517 243 266 517 244 266 minecraft:purple_terracotta
setblock 517 243 270 minecraft:purple_terracotta
fill 519 243 228 519 245 228 minecraft:purple_terracotta
fill 519 243 270 519 245 270 minecraft:purple_terracotta
fill 523 243 228 523 245 228 minecraft:purple_terracotta
fill 523 243 270 523 245 270 minecraft:purple_terracotta
fill 527 243 228 527 245 228 minecraft:purple_terracotta
fill 527 243 270 527 245 270 minecraft:purple_terracotta
fill 531 243 228 531 245 228 minecraft:purple_terracotta
fill 531 243 270 531 245 270 minecraft:purple_terracotta
setblock 534 243 228 minecraft:black_terracotta
fill 535 243 228 535 245 228 minecraft:purple_terracotta
fill 535 243 270 535 245 270 minecraft:purple_terracotta
fill 539 243 228 539 245 228 minecraft:purple_terracotta
fill 539 243 270 539 245 270 minecraft:purple_terracotta
fill 543 243 228 543 245 228 minecraft:purple_terracotta
fill 543 243 270 543 245 270 minecraft:purple_terracotta
setblock 544 243 270 minecraft:light_gray_terracotta
fill 547 243 228 547 245 228 minecraft:purple_terracotta
fill 547 243 270 547 245 270 minecraft:purple_terracotta
fill 551 243 228 551 245 228 minecraft:purple_terracotta
fill 551 243 270 551 245 270 minecraft:purple_terracotta
fill 555 243 228 555 245 228 minecraft:purple_terracotta
fill 555 243 270 555 245 270 minecraft:purple_terracotta
fill 557 243 257 557 243 258 minecraft:spruce_planks
fill 557 243 259 558 243 260 minecraft:dark_oak_planks
setblock 559 243 228 minecraft:purple_terracotta
fill 559 243 230 559 245 230 minecraft:purple_terracotta
fill 559 243 234 559 245 234 minecraft:purple_terracotta
fill 559 243 238 559 245 238 minecraft:purple_terracotta
fill 559 243 242 559 245 242 minecraft:purple_terracotta
fill 559 243 246 559 245 246 minecraft:purple_terracotta
fill 559 243 250 559 245 250 minecraft:purple_terracotta
fill 559 243 254 559 245 254 minecraft:purple_terracotta
fill 559 243 258 559 245 258 minecraft:purple_terracotta
fill 559 243 262 559 245 262 minecraft:purple_terracotta
fill 559 243 266 559 245 266 minecraft:purple_terracotta
fill 559 243 270 559 245 270 minecraft:purple_terracotta
setblock 517 244 228 minecraft:magenta_terracotta
setblock 517 244 232 minecraft:magenta_terracotta
setblock 517 244 236 minecraft:magenta_terracotta
setblock 517 244 240 minecraft:magenta_terracotta
setblock 517 244 244 minecraft:magenta_terracotta
setblock 517 244 248 minecraft:magenta_terracotta
setblock 517 244 252 minecraft:magenta_terracotta
fill 517 244 253 517 278 253 minecraft:purple_terracotta
setblock 517 244 256 minecraft:magenta_terracotta
setblock 517 244 260 minecraft:magenta_terracotta
fill 517 244 263 517 278 263 minecraft:purple_terracotta
setblock 517 244 264 minecraft:magenta_terracotta
setblock 517 244 268 minecraft:magenta_terracotta
setblock 517 244 270 minecraft:magenta_terracotta
setblock 521 244 228 minecraft:magenta_terracotta
setblock 521 244 270 minecraft:magenta_terracotta
setblock 525 244 228 minecraft:magenta_terracotta
setblock 525 244 270 minecraft:magenta_terracotta
setblock 529 244 228 minecraft:magenta_terracotta
setblock 529 244 270 minecraft:magenta_terracotta
setblock 533 244 228 minecraft:magenta_terracotta
setblock 533 244 270 minecraft:magenta_terracotta
fill 534 244 228 534 278 228 minecraft:purple_terracotta
fill 536 244 269 538 244 269 minecraft:pink_terracotta
setblock 537 244 228 minecraft:magenta_terracotta
setblock 537 244 270 minecraft:magenta_terracotta
setblock 541 244 228 minecraft:magenta_terracotta
setblock 541 244 270 minecraft:magenta_terracotta
fill 544 244 270 544 278 270 minecraft:purple_terracotta
setblock 545 244 228 minecraft:magenta_terracotta
setblock 545 244 270 minecraft:magenta_terracotta
setblock 548 244 270 minecraft:gray_terracotta
setblock 549 244 228 minecraft:magenta_terracotta
setblock 549 244 270 minecraft:magenta_terracotta
setblock 553 244 228 minecraft:magenta_terracotta
setblock 553 244 270 minecraft:magenta_terracotta
setblock 557 244 228 minecraft:magenta_terracotta
fill 557 244 255 557 244 256 minecraft:spruce_planks
fill 557 244 257 558 244 258 minecraft:dark_oak_planks
setblock 557 244 270 minecraft:magenta_terracotta
setblock 559 244 228 minecraft:magenta_terracotta
setblock 559 244 232 minecraft:magenta_terracotta
setblock 559 244 236 minecraft:magenta_terracotta
setblock 559 244 240 minecraft:magenta_terracotta
setblock 559 244 244 minecraft:magenta_terracotta
setblock 559 244 248 minecraft:magenta_terracotta
setblock 559 244 252 minecraft:magenta_terracotta
setblock 559 244 256 minecraft:magenta_terracotta
setblock 559 244 260 minecraft:magenta_terracotta
setblock 559 244 264 minecraft:magenta_terracotta
setblock 559 244 268 minecraft:magenta_terracotta
fill 517 245 228 517 247 228 minecraft:purple_terracotta
fill 517 245 232 517 247 232 minecraft:purple_terracotta
setblock 517 245 236 minecraft:purple_terracotta
fill 517 245 240 517 247 240 minecraft:purple_terracotta
fill 517 245 244 517 247 244 minecraft:purple_terracotta
fill 517 245 248 517 247 248 minecraft:purple_terracotta
fill 517 245 252 517 247 252 minecraft:purple_terracotta
fill 517 245 256 517 247 256 minecraft:purple_terracotta
fill 517 245 260 517 247 260 minecraft:purple_terracotta
fill 517 245 264 517 247 264 minecraft:purple_terracotta
setblock 517 245 266 minecraft:gray_terracotta
fill 517 245 268 517 247 268 minecraft:purple_terracotta
setblock 517 245 270 minecraft:purple_terracotta
fill 521 245 228 521 247 228 minecraft:purple_terracotta
fill 521 245 270 521 247 270 minecraft:purple_terracotta
fill 525 245 228 525 247 228 minecraft:purple_terracotta
fill 525 245 270 525 247 270 minecraft:purple_terracotta
fill 529 245 228 529 247 228 minecraft:purple_terracotta
fill 529 245 270 529 247 270 minecraft:purple_terracotta
fill 533 245 228 533 247 228 minecraft:purple_terracotta
fill 533 245 270 533 247 270 minecraft:purple_terracotta
setblock 536 245 269 minecraft:blue_concrete
fill 537 245 228 537 247 228 minecraft:purple_terracotta
fill 537 245 269 537 246 269 minecraft:pink_terracotta
fill 537 245 270 537 247 270 minecraft:purple_terracotta
setblock 538 245 269 minecraft:blue_concrete
fill 541 245 228 541 247 228 minecraft:purple_terracotta
fill 541 245 270 541 247 270 minecraft:purple_terracotta
fill 545 245 228 545 247 228 minecraft:purple_terracotta
fill 545 245 270 545 247 270 minecraft:purple_terracotta
fill 548 245 270 549 247 270 minecraft:purple_terracotta
fill 549 245 228 549 247 228 minecraft:purple_terracotta
fill 553 245 228 553 247 228 minecraft:purple_terracotta
fill 553 245 270 553 247 270 minecraft:purple_terracotta
fill 557 245 228 557 247 228 minecraft:purple_terracotta
fill 557 245 253 557 245 254 minecraft:spruce_planks
fill 557 245 255 558 245 256 minecraft:dark_oak_planks
fill 557 245 270 557 247 270 minecraft:purple_terracotta
setblock 559 245 228 minecraft:purple_terracotta
fill 559 245 232 559 247 232 minecraft:purple_terracotta
fill 559 245 236 559 247 236 minecraft:purple_terracotta
fill 559 245 240 559 247 240 minecraft:purple_terracotta
fill 559 245 244 559 247 244 minecraft:purple_terracotta
fill 559 245 248 559 247 248 minecraft:purple_terracotta
fill 559 245 252 559 247 252 minecraft:purple_terracotta
fill 559 245 256 559 247 256 minecraft:purple_terracotta
fill 559 245 260 559 247 260 minecraft:purple_terracotta
fill 559 245 264 559 247 264 minecraft:purple_terracotta
fill 559 245 268 559 247 268 minecraft:purple_terracotta
setblock 559 245 269 minecraft:black_terracotta
setblock 517 246 230 minecraft:magenta_terracotta
setblock 517 246 234 minecraft:magenta_terracotta
setblock 517 246 236 minecraft:gray_terracotta
setblock 517 246 238 minecraft:magenta_terracotta
setblock 517 246 242 minecraft:magenta_terracotta
setblock 517 246 246 minecraft:magenta_terracotta
setblock 517 246 250 minecraft:magenta_terracotta
setblock 517 246 254 minecraft:magenta_terracotta
setblock 517 246 258 minecraft:magenta_terracotta
setblock 517 246 262 minecraft:magenta_terracotta
setblock 517 246 266 minecraft:magenta_terracotta
setblock 517 246 270 minecraft:magenta_terracotta
setblock 519 246 228 minecraft:magenta_terracotta
setblock 519 246 270 minecraft:magenta_terracotta
setblock 523 246 228 minecraft:magenta_terracotta
setblock 523 246 270 minecraft:magenta_terracotta
setblock 527 246 228 minecraft:magenta_terracotta
setblock 527 246 270 minecraft:magenta_terracotta
setblock 531 246 228 minecraft:magenta_terracotta
setblock 531 246 270 minecraft:magenta_terracotta
setblock 535 246 228 minecraft:magenta_terracotta
setblock 535 246 270 minecraft:magenta_terracotta
setblock 536 246 269 minecraft:pink_terracotta
setblock 538 246 269 minecraft:pink_terracotta
setblock 539 246 228 minecraft:magenta_terracotta
setblock 539 246 270 minecraft:magenta_terracotta
setblock 543 246 228 minecraft:magenta_terracotta
setblock 543 246 270 minecraft:magenta_terracotta
setblock 547 246 228 minecraft:magenta_terracotta
setblock 547 246 270 minecraft:magenta_terracotta
setblock 551 246 228 minecraft:magenta_terracotta
setblock 551 246 270 minecraft:magenta_terracotta
setblock 555 246 228 minecraft:magenta_terracotta
setblock 555 246 270 minecraft:magenta_terracotta
fill 557 246 251 557 246 252 minecraft:spruce_planks
fill 557 246 253 558 246 254 minecraft:dark_oak_planks
setblock 559 246 228 minecraft:magenta_terracotta
setblock 559 246 230 minecraft:magenta_terracotta
setblock 559 246 234 minecraft:magenta_terracotta
setblock 559 246 238 minecraft:magenta_terracotta
setblock 559 246 242 minecraft:magenta_terracotta
setblock 559 246 246 minecraft:magenta_terracotta
setblock 559 246 250 minecraft:magenta_terracotta
setblock 559 246 254 minecraft:magenta_terracotta
setblock 559 246 258 minecraft:magenta_terracotta
setblock 559 246 262 minecraft:magenta_terracotta
setblock 559 246 266 minecraft:magenta_terracotta
fill 559 246 269 559 278 269 minecraft:purple_terracotta
setblock 559 246 270 minecraft:magenta_terracotta
fill 517 247 230 517 249 230 minecraft:purple_terracotta
setblock 517 247 231 minecraft:light_gray_terracotta
fill 517 247 234 517 249 234 minecraft:purple_terracotta
setblock 517 247 236 minecraft:purple_terracotta
fill 517 247 238 517 249 238 minecraft:purple_terracotta
fill 517 247 242 517 249 242 minecraft:purple_terracotta
fill 517 247 246 517 249 246 minecraft:purple_terracotta
fill 517 247 250 517 249 250 minecraft:purple_terracotta
fill 517 247 254 517 249 254 minecraft:purple_terracotta
fill 517 247 258 517 249 258 minecraft:purple_terracotta
fill 517 247 262 517 249 262 minecraft:purple_terracotta
fill 517 247 266 517 249 266 minecraft:purple_terracotta
setblock 517 247 270 minecraft:purple_terracotta
fill 519 247 228 519 249 228 minecraft:purple_terracotta
fill 519 247 270 519 249 270 minecraft:purple_terracotta
setblock 520 247 231 minecraft:light[level=12]
setblock 520 247 238 minecraft:light[level=12]
setblock 520 247 245 minecraft:light[level=12]
setblock 520 247 252 minecraft:light[level=12]
setblock 520 247 259 minecraft:light[level=12]
setblock 520 247 266 minecraft:light[level=12]
fill 523 247 228 523 249 228 minecraft:purple_terracotta
fill 523 247 270 523 249 270 minecraft:purple_terracotta
fill 527 247 228 527 249 228 minecraft:purple_terracotta
setblock 527 247 231 minecraft:light[level=12]
setblock 527 247 238 minecraft:light[level=12]
setblock 527 247 245 minecraft:light[level=12]
setblock 527 247 252 minecraft:light[level=12]
setblock 527 247 259 minecraft:light[level=12]
setblock 527 247 266 minecraft:light[level=12]
fill 527 247 270 527 249 270 minecraft:purple_terracotta
fill 531 247 228 531 249 228 minecraft:purple_terracotta
fill 531 247 270 531 249 270 minecraft:purple_terracotta
setblock 534 247 231 minecraft:light[level=12]
setblock 534 247 238 minecraft:light[level=12]
setblock 534 247 245 minecraft:light[level=12]
setblock 534 247 252 minecraft:light[level=12]
setblock 534 247 259 minecraft:light[level=12]
setblock 534 247 266 minecraft:light[level=12]
fill 535 247 228 535 249 228 minecraft:purple_terracotta
fill 535 247 270 535 249 270 minecraft:purple_terracotta
fill 536 247 269 538 247 269 minecraft:gold_block
fill 539 247 228 539 249 228 minecraft:purple_terracotta
fill 539 247 270 539 249 270 minecraft:purple_terracotta
setblock 541 247 231 minecraft:light[level=12]
setblock 541 247 238 minecraft:light[level=12]
setblock 541 247 245 minecraft:light[level=12]
setblock 541 247 252 minecraft:light[level=12]
setblock 541 247 259 minecraft:light[level=12]
setblock 541 247 266 minecraft:light[level=12]
fill 543 247 228 543 249 228 minecraft:purple_terracotta
fill 543 247 270 543 249 270 minecraft:purple_terracotta
fill 547 247 228 547 249 228 minecraft:purple_terracotta
fill 547 247 270 547 249 270 minecraft:purple_terracotta
setblock 548 247 231 minecraft:light[level=12]
setblock 548 247 238 minecraft:light[level=12]
setblock 548 247 245 minecraft:light[level=12]
setblock 548 247 252 minecraft:light[level=12]
setblock 548 247 259 minecraft:light[level=12]
setblock 548 247 266 minecraft:light[level=12]
fill 551 247 228 551 249 228 minecraft:purple_terracotta
fill 551 247 270 551 249 270 minecraft:purple_terracotta
fill 555 247 228 555 249 228 minecraft:purple_terracotta
setblock 555 247 231 minecraft:light[level=12]
setblock 555 247 238 minecraft:light[level=12]
setblock 555 247 245 minecraft:light[level=12]
setblock 555 247 252 minecraft:light[level=12]
setblock 555 247 259 minecraft:light[level=12]
setblock 555 247 266 minecraft:light[level=12]
fill 555 247 270 555 249 270 minecraft:purple_terracotta
fill 557 247 249 557 247 250 minecraft:spruce_planks
fill 557 247 251 558 247 252 minecraft:dark_oak_planks
setblock 559 247 228 minecraft:purple_terracotta
fill 559 247 230 559 249 230 minecraft:purple_terracotta
fill 559 247 234 559 249 234 minecraft:purple_terracotta
fill 559 247 238 559 249 238 minecraft:purple_terracotta
fill 559 247 242 559 249 242 minecraft:purple_terracotta
fill 559 247 246 559 249 246 minecraft:purple_terracotta
fill 559 247 250 559 249 250 minecraft:purple_terracotta
fill 559 247 254 559 249 254 minecraft:purple_terracotta
fill 559 247 258 559 249 258 minecraft:purple_terracotta
fill 559 247 262 559 249 262 minecraft:purple_terracotta
fill 559 247 266 559 249 266 minecraft:purple_terracotta
fill 559 247 270 559 249 270 minecraft:purple_terracotta
setblock 517 248 228 minecraft:magenta_terracotta
fill 517 248 231 517 278 231 minecraft:purple_terracotta
setblock 517 248 232 minecraft:magenta_terracotta
setblock 517 248 236 minecraft:magenta_terracotta
setblock 517 248 240 minecraft:magenta_terracotta
setblock 517 248 244 minecraft:magenta_terracotta
setblock 517 248 248 minecraft:magenta_terracotta
setblock 517 248 252 minecraft:magenta_terracotta
setblock 517 248 256 minecraft:magenta_terracotta
setblock 517 248 260 minecraft:magenta_terracotta
setblock 517 248 264 minecraft:magenta_terracotta
setblock 517 248 268 minecraft:magenta_terracotta
setblock 517 248 270 minecraft:magenta_terracotta
setblock 521 248 228 minecraft:magenta_terracotta
setblock 521 248 270 minecraft:magenta_terracotta
setblock 525 248 228 minecraft:magenta_terracotta
setblock 525 248 270 minecraft:magenta_terracotta
setblock 529 248 228 minecraft:magenta_terracotta
setblock 529 248 270 minecraft:magenta_terracotta
setblock 533 248 228 minecraft:magenta_terracotta
setblock 533 248 270 minecraft:magenta_terracotta
setblock 537 248 228 minecraft:magenta_terracotta
setblock 537 248 270 minecraft:magenta_terracotta
setblock 541 248 228 minecraft:magenta_terracotta
setblock 541 248 270 minecraft:magenta_terracotta
setblock 545 248 228 minecraft:magenta_terracotta
setblock 545 248 270 minecraft:magenta_terracotta
fill 548 248 270 548 278 270 minecraft:purple_terracotta
setblock 549 248 228 minecraft:magenta_terracotta
setblock 549 248 270 minecraft:magenta_terracotta
setblock 553 248 228 minecraft:magenta_terracotta
setblock 553 248 270 minecraft:magenta_terracotta
setblock 557 248 228 minecraft:magenta_terracotta
fill 557 248 247 557 248 248 minecraft:spruce_planks
fill 557 248 249 558 248 250 minecraft:dark_oak_planks
setblock 557 248 270 minecraft:magenta_terracotta
setblock 559 248 228 minecraft:magenta_terracotta
setblock 559 248 232 minecraft:magenta_terracotta
setblock 559 248 236 minecraft:magenta_terracotta
setblock 559 248 240 minecraft:magenta_terracotta
setblock 559 248 244 minecraft:magenta_terracotta
setblock 559 248 248 minecraft:magenta_terracotta
setblock 559 248 252 minecraft:magenta_terracotta
setblock 559 248 256 minecraft:magenta_terracotta
setblock 559 248 260 minecraft:magenta_terracotta
setblock 559 248 264 minecraft:magenta_terracotta
setblock 559 248 268 minecraft:magenta_terracotta
fill 517 249 228 517 251 228 minecraft:purple_terracotta
fill 517 249 232 517 251 232 minecraft:purple_terracotta
fill 517 249 236 517 251 236 minecraft:purple_terracotta
fill 517 249 240 517 251 240 minecraft:purple_terracotta
fill 517 249 244 517 251 244 minecraft:purple_terracotta
fill 517 249 248 517 251 248 minecraft:purple_terracotta
fill 517 249 252 517 251 252 minecraft:purple_terracotta
fill 517 249 256 517 251 256 minecraft:purple_terracotta
fill 517 249 260 517 251 260 minecraft:purple_terracotta
fill 517 249 264 517 251 264 minecraft:purple_terracotta
fill 517 249 268 517 251 268 minecraft:purple_terracotta
setblock 517 249 270 minecraft:purple_terracotta
setblock 520 249 231 minecraft:light[level=11]
setblock 520 249 239 minecraft:light[level=11]
setblock 520 249 247 minecraft:light[level=11]
setblock 520 249 255 minecraft:light[level=11]
setblock 520 249 263 minecraft:light[level=11]
fill 521 249 228 521 251 228 minecraft:purple_terracotta
fill 521 249 270 521 251 270 minecraft:purple_terracotta
fill 525 249 228 525 251 228 minecraft:purple_terracotta
fill 525 249 270 525 251 270 minecraft:purple_terracotta
setblock 528 249 231 minecraft:light[level=11]
setblock 528 249 239 minecraft:light[level=11]
setblock 528 249 247 minecraft:light[level=11]
setblock 528 249 255 minecraft:light[level=11]
setblock 528 249 263 minecraft:light[level=11]
fill 529 249 228 529 251 228 minecraft:purple_terracotta
fill 529 249 270 529 251 270 minecraft:purple_terracotta
fill 533 249 228 533 251 228 minecraft:purple_terracotta
fill 533 249 270 533 251 270 minecraft:purple_terracotta
setblock 536 249 231 minecraft:light[level=11]
setblock 536 249 239 minecraft:light[level=11]
setblock 536 249 247 minecraft:light[level=11]
setblock 536 249 255 minecraft:light[level=11]
setblock 536 249 263 minecraft:light[level=11]
fill 537 249 228 537 251 228 minecraft:purple_terracotta
fill 537 249 270 537 251 270 minecraft:purple_terracotta
fill 541 249 228 541 251 228 minecraft:purple_terracotta
fill 541 249 270 541 251 270 minecraft:purple_terracotta
setblock 544 249 231 minecraft:light[level=11]
setblock 544 249 239 minecraft:light[level=11]
setblock 544 249 247 minecraft:light[level=11]
setblock 544 249 255 minecraft:light[level=11]
setblock 544 249 263 minecraft:light[level=11]
fill 545 249 228 545 251 228 minecraft:purple_terracotta
fill 545 249 270 545 251 270 minecraft:purple_terracotta
fill 549 249 228 549 251 228 minecraft:purple_terracotta
fill 549 249 270 549 251 270 minecraft:purple_terracotta
setblock 552 249 231 minecraft:light[level=11]
setblock 552 249 239 minecraft:light[level=11]
setblock 552 249 247 minecraft:light[level=11]
setblock 552 249 255 minecraft:light[level=11]
setblock 552 249 263 minecraft:light[level=11]
fill 553 249 228 553 251 228 minecraft:purple_terracotta
fill 553 249 270 553 251 270 minecraft:purple_terracotta
fill 557 249 228 557 251 228 minecraft:purple_terracotta
fill 557 249 245 557 249 246 minecraft:spruce_planks
fill 557 249 247 558 249 248 minecraft:dark_oak_planks
fill 557 249 270 557 251 270 minecraft:purple_terracotta
setblock 559 249 228 minecraft:purple_terracotta
fill 559 249 232 559 251 232 minecraft:purple_terracotta
fill 559 249 236 559 251 236 minecraft:purple_terracotta
fill 559 249 240 559 251 240 minecraft:purple_terracotta
fill 559 249 244 559 251 244 minecraft:purple_terracotta
fill 559 249 248 559 251 248 minecraft:purple_terracotta
fill 559 249 252 559 251 252 minecraft:purple_terracotta
fill 559 249 256 559 251 256 minecraft:purple_terracotta
fill 559 249 260 559 251 260 minecraft:purple_terracotta
fill 559 249 264 559 251 264 minecraft:purple_terracotta
fill 559 249 268 559 251 268 minecraft:purple_terracotta
setblock 517 250 230 minecraft:magenta_terracotta
setblock 517 250 234 minecraft:magenta_terracotta
setblock 517 250 238 minecraft:magenta_terracotta
setblock 517 250 242 minecraft:magenta_terracotta
setblock 517 250 246 minecraft:magenta_terracotta
setblock 517 250 250 minecraft:magenta_terracotta
setblock 517 250 254 minecraft:magenta_terracotta
setblock 517 250 258 minecraft:magenta_terracotta
setblock 517 250 262 minecraft:magenta_terracotta
setblock 517 250 266 minecraft:magenta_terracotta
setblock 517 250 270 minecraft:magenta_terracotta
setblock 519 250 228 minecraft:magenta_terracotta
setblock 519 250 270 minecraft:magenta_terracotta
setblock 523 250 228 minecraft:magenta_terracotta
setblock 523 250 270 minecraft:magenta_terracotta
setblock 527 250 228 minecraft:magenta_terracotta
setblock 527 250 270 minecraft:magenta_terracotta
setblock 531 250 228 minecraft:magenta_terracotta
setblock 531 250 270 minecraft:magenta_terracotta
setblock 535 250 228 minecraft:magenta_terracotta
setblock 535 250 270 minecraft:magenta_terracotta
setblock 539 250 228 minecraft:magenta_terracotta
setblock 539 250 270 minecraft:magenta_terracotta
setblock 543 250 228 minecraft:magenta_terracotta
setblock 543 250 270 minecraft:magenta_terracotta
setblock 547 250 228 minecraft:magenta_terracotta
setblock 547 250 270 minecraft:magenta_terracotta
setblock 551 250 228 minecraft:magenta_terracotta
setblock 551 250 270 minecraft:magenta_terracotta
setblock 555 250 228 minecraft:magenta_terracotta
setblock 555 250 270 minecraft:magenta_terracotta
fill 557 250 243 557 250 244 minecraft:spruce_planks
fill 557 250 245 558 250 246 minecraft:dark_oak_planks
setblock 559 250 228 minecraft:magenta_terracotta
setblock 559 250 230 minecraft:magenta_terracotta
setblock 559 250 234 minecraft:magenta_terracotta
setblock 559 250 238 minecraft:magenta_terracotta
setblock 559 250 242 minecraft:magenta_terracotta
setblock 559 250 246 minecraft:magenta_terracotta
setblock 559 250 250 minecraft:magenta_terracotta
setblock 559 250 254 minecraft:magenta_terracotta
setblock 559 250 258 minecraft:magenta_terracotta
setblock 559 250 262 minecraft:magenta_terracotta
setblock 559 250 266 minecraft:magenta_terracotta
setblock 559 250 270 minecraft:magenta_terracotta
fill 517 251 230 517 253 230 minecraft:purple_terracotta
fill 517 251 234 517 253 234 minecraft:purple_terracotta
fill 517 251 238 517 253 238 minecraft:purple_terracotta
setblock 517 251 242 minecraft:black_terracotta
fill 517 251 246 517 253 246 minecraft:purple_terracotta
fill 517 251 250 517 253 250 minecraft:purple_terracotta
fill 517 251 254 517 253 254 minecraft:purple_terracotta
fill 517 251 258 517 253 258 minecraft:purple_terracotta
fill 517 251 262 517 253 262 minecraft:purple_terracotta
fill 517 251 266 517 253 266 minecraft:purple_terracotta
setblock 517 251 270 minecraft:purple_terracotta
fill 519 251 228 519 253 228 minecraft:purple_terracotta
fill 519 251 270 519 253 270 minecraft:purple_terracotta
fill 523 251 228 523 253 228 minecraft:purple_terracotta
fill 523 251 270 523 253 270 minecraft:purple_terracotta
fill 527 251 228 527 253 228 minecraft:purple_terracotta
fill 527 251 270 527 253 270 minecraft:purple_terracotta
fill 531 251 228 531 253 228 minecraft:purple_terracotta
fill 531 251 270 531 253 270 minecraft:purple_terracotta
fill 535 251 228 535 253 228 minecraft:purple_terracotta
fill 535 251 270 535 253 270 minecraft:purple_terracotta
fill 539 251 228 539 253 228 minecraft:purple_terracotta
fill 539 251 270 539 253 270 minecraft:purple_terracotta
fill 543 251 228 543 253 228 minecraft:purple_terracotta
fill 543 251 270 543 253 270 minecraft:purple_terracotta
fill 547 251 228 547 253 228 minecraft:purple_terracotta
fill 547 251 270 547 253 270 minecraft:purple_terracotta
fill 551 251 228 551 253 228 minecraft:purple_terracotta
fill 551 251 270 551 253 270 minecraft:purple_terracotta
fill 555 251 228 555 252 228 minecraft:purple_terracotta
fill 555 251 270 555 253 270 minecraft:purple_terracotta
fill 557 251 241 557 251 242 minecraft:spruce_planks
fill 557 251 243 558 251 244 minecraft:dark_oak_planks
setblock 559 251 228 minecraft:purple_terracotta
fill 559 251 230 559 253 230 minecraft:purple_terracotta
fill 559 251 234 559 253 234 minecraft:purple_terracotta
fill 559 251 238 559 253 238 minecraft:purple_terracotta
fill 559 251 242 559 253 242 minecraft:purple_terracotta
fill 559 251 246 559 253 246 minecraft:purple_terracotta
fill 559 251 250 559 253 250 minecraft:purple_terracotta
fill 559 251 254 559 253 254 minecraft:purple_terracotta
fill 559 251 258 559 253 258 minecraft:purple_terracotta
fill 559 251 262 559 253 262 minecraft:purple_terracotta
fill 559 251 266 559 253 266 minecraft:purple_terracotta
fill 559 251 270 559 253 270 minecraft:purple_terracotta
setblock 517 252 228 minecraft:magenta_terracotta
setblock 517 252 232 minecraft:magenta_terracotta
setblock 517 252 236 minecraft:magenta_terracotta
setblock 517 252 240 minecraft:magenta_terracotta
fill 517 252 242 517 253 242 minecraft:purple_terracotta
setblock 517 252 244 minecraft:magenta_terracotta
setblock 517 252 248 minecraft:magenta_terracotta
setblock 517 252 252 minecraft:magenta_terracotta
setblock 517 252 256 minecraft:magenta_terracotta
setblock 517 252 260 minecraft:magenta_terracotta
setblock 517 252 264 minecraft:magenta_terracotta
setblock 517 252 268 minecraft:magenta_terracotta
setblock 517 252 270 minecraft:magenta_terracotta
setblock 521 252 228 minecraft:magenta_terracotta
setblock 521 252 270 minecraft:magenta_terracotta
setblock 525 252 228 minecraft:magenta_terracotta
setblock 525 252 270 minecraft:magenta_terracotta
setblock 528 252 270 minecraft:light_gray_terracotta
setblock 529 252 228 minecraft:magenta_terracotta
setblock 529 252 270 minecraft:magenta_terracotta
setblock 533 252 228 minecraft:magenta_terracotta
setblock 533 252 270 minecraft:magenta_terracotta
setblock 537 252 228 minecraft:magenta_terracotta
setblock 537 252 270 minecraft:magenta_terracotta
setblock 541 252 228 minecraft:magenta_terracotta
setblock 541 252 270 minecraft:magenta_terracotta
setblock 545 252 228 minecraft:magenta_terracotta
setblock 545 252 270 minecraft:magenta_terracotta
setblock 549 252 228 minecraft:magenta_terracotta
setblock 549 252 270 minecraft:magenta_terracotta
setblock 553 252 228 minecraft:magenta_terracotta
setblock 553 252 270 minecraft:magenta_terracotta
setblock 557 252 228 minecraft:magenta_terracotta
fill 557 252 239 557 252 240 minecraft:spruce_planks
fill 557 252 241 558 252 242 minecraft:dark_oak_planks
setblock 557 252 270 minecraft:magenta_terracotta
setblock 559 252 228 minecraft:magenta_terracotta
setblock 559 252 232 minecraft:magenta_terracotta
setblock 559 252 236 minecraft:magenta_terracotta
setblock 559 252 240 minecraft:magenta_terracotta
setblock 559 252 244 minecraft:magenta_terracotta
setblock 559 252 248 minecraft:magenta_terracotta
setblock 559 252 252 minecraft:magenta_terracotta
setblock 559 252 256 minecraft:magenta_terracotta
setblock 559 252 260 minecraft:magenta_terracotta
setblock 559 252 264 minecraft:magenta_terracotta
setblock 559 252 268 minecraft:magenta_terracotta
fill 517 253 228 517 255 228 minecraft:purple_terracotta
fill 517 253 232 517 255 232 minecraft:purple_terracotta
fill 517 253 236 517 255 236 minecraft:purple_terracotta
fill 517 253 240 517 255 240 minecraft:purple_terracotta
fill 517 253 244 517 255 244 minecraft:purple_terracotta
fill 517 253 248 517 255 248 minecraft:purple_terracotta
fill 517 253 252 517 255 252 minecraft:purple_terracotta
fill 517 253 256 517 255 256 minecraft:purple_terracotta
fill 517 253 260 517 255 260 minecraft:purple_terracotta
fill 517 253 264 517 255 264 minecraft:purple_terracotta
fill 517 253 268 517 255 268 minecraft:purple_terracotta
setblock 517 253 270 minecraft:purple_terracotta
fill 518 253 255 524 253 255 minecraft:dark_oak_planks
setblock 520 253 231 minecraft:light[level=12]
setblock 520 253 238 minecraft:light[level=12]
setblock 520 253 245 minecraft:light[level=12]
setblock 520 253 252 minecraft:light[level=12]
fill 520 253 253 524 254 254 minecraft:dark_oak_planks
fill 520 253 256 524 254 257 minecraft:dark_oak_planks
setblock 520 253 259 minecraft:light[level=12]
setblock 520 253 266 minecraft:light[level=12]
fill 521 253 228 521 255 228 minecraft:purple_terracotta
fill 521 253 270 521 255 270 minecraft:purple_terracotta
fill 525 253 228 525 255 228 minecraft:purple_terracotta
fill 525 253 270 525 255 270 minecraft:purple_terracotta
setblock 527 253 231 minecraft:light[level=12]
setblock 527 253 238 minecraft:light[level=12]
setblock 527 253 245 minecraft:light[level=12]
setblock 527 253 252 minecraft:light[level=12]
setblock 527 253 259 minecraft:light[level=12]
setblock 527 253 266 minecraft:light[level=12]
fill 528 253 270 529 255 270 minecraft:purple_terracotta
fill 529 253 228 529 255 228 minecraft:purple_terracotta
fill 533 253 228 533 255 228 minecraft:purple_terracotta
fill 533 253 270 533 255 270 minecraft:purple_terracotta
setblock 534 253 231 minecraft:light[level=12]
setblock 534 253 238 minecraft:light[level=12]
setblock 534 253 245 minecraft:light[level=12]
setblock 534 253 252 minecraft:light[level=12]
setblock 534 253 259 minecraft:light[level=12]
setblock 534 253 266 minecraft:light[level=12]
fill 537 253 228 537 255 228 minecraft:purple_terracotta
fill 537 253 270 537 255 270 minecraft:purple_terracotta
fill 541 253 228 541 255 228 minecraft:purple_terracotta
setblock 541 253 231 minecraft:light[level=12]
setblock 541 253 238 minecraft:light[level=12]
setblock 541 253 245 minecraft:light[level=12]
setblock 541 253 252 minecraft:light[level=12]
setblock 541 253 259 minecraft:light[level=12]
setblock 541 253 266 minecraft:light[level=12]
fill 541 253 270 541 255 270 minecraft:purple_terracotta
fill 545 253 228 545 255 228 minecraft:purple_terracotta
fill 545 253 270 545 255 270 minecraft:purple_terracotta
setblock 548 253 231 minecraft:light[level=12]
setblock 548 253 238 minecraft:light[level=12]
setblock 548 253 245 minecraft:light[level=12]
setblock 548 253 252 minecraft:light[level=12]
setblock 548 253 259 minecraft:light[level=12]
setblock 548 253 266 minecraft:light[level=12]
fill 549 253 228 549 255 228 minecraft:purple_terracotta
fill 549 253 270 549 255 270 minecraft:purple_terracotta
fill 553 253 228 553 255 228 minecraft:purple_terracotta
fill 553 253 270 553 255 270 minecraft:purple_terracotta
setblock 555 253 228 minecraft:black_terracotta
setblock 555 253 231 minecraft:light[level=12]
setblock 555 253 238 minecraft:light[level=12]
setblock 555 253 245 minecraft:light[level=12]
setblock 555 253 252 minecraft:light[level=12]
setblock 555 253 259 minecraft:light[level=12]
setblock 555 253 266 minecraft:light[level=12]
fill 557 253 228 557 255 228 minecraft:purple_terracotta
fill 557 253 237 557 253 238 minecraft:spruce_planks
fill 557 253 239 558 253 240 minecraft:dark_oak_planks
fill 557 253 270 557 255 270 minecraft:purple_terracotta
setblock 559 253 228 minecraft:purple_terracotta
fill 559 253 232 559 255 232 minecraft:purple_terracotta
fill 559 253 236 559 255 236 minecraft:purple_terracotta
fill 559 253 240 559 255 240 minecraft:purple_terracotta
fill 559 253 244 559 255 244 minecraft:purple_terracotta
fill 559 253 248 559 255 248 minecraft:purple_terracotta
fill 559 253 252 559 255 252 minecraft:purple_terracotta
fill 559 253 256 559 255 256 minecraft:purple_terracotta
fill 559 253 260 559 255 260 minecraft:purple_terracotta
fill 559 253 264 559 255 264 minecraft:purple_terracotta
fill 559 253 268 559 255 268 minecraft:purple_terracotta
setblock 517 254 230 minecraft:magenta_terracotta
setblock 517 254 234 minecraft:magenta_terracotta
setblock 517 254 238 minecraft:magenta_terracotta
setblock 517 254 242 minecraft:magenta_terracotta
setblock 517 254 246 minecraft:magenta_terracotta
setblock 517 254 250 minecraft:magenta_terracotta
setblock 517 254 254 minecraft:magenta_terracotta
setblock 517 254 258 minecraft:magenta_terracotta
setblock 517 254 262 minecraft:magenta_terracotta
setblock 517 254 266 minecraft:magenta_terracotta
setblock 517 254 270 minecraft:magenta_terracotta
setblock 519 254 228 minecraft:magenta_terracotta
setblock 519 254 270 minecraft:magenta_terracotta
fill 520 254 255 524 254 255 minecraft:dark_oak_planks
setblock 523 254 228 minecraft:magenta_terracotta
setblock 523 254 270 minecraft:magenta_terracotta
setblock 527 254 228 minecraft:magenta_terracotta
setblock 527 254 270 minecraft:magenta_terracotta
setblock 531 254 228 minecraft:magenta_terracotta
setblock 531 254 270 minecraft:magenta_terracotta
setblock 535 254 228 minecraft:magenta_terracotta
setblock 535 254 270 minecraft:magenta_terracotta
setblock 539 254 228 minecraft:magenta_terracotta
setblock 539 254 270 minecraft:magenta_terracotta
setblock 543 254 228 minecraft:magenta_terracotta
setblock 543 254 270 minecraft:magenta_terracotta
setblock 544 254 228 minecraft:gray_terracotta
setblock 547 254 228 minecraft:magenta_terracotta
setblock 547 254 270 minecraft:magenta_terracotta
setblock 551 254 228 minecraft:magenta_terracotta
setblock 551 254 270 minecraft:magenta_terracotta
setblock 555 254 228 minecraft:magenta_terracotta
setblock 555 254 270 minecraft:magenta_terracotta
fill 557 254 235 557 254 236 minecraft:spruce_planks
fill 557 254 237 558 254 238 minecraft:dark_oak_planks
setblock 559 254 228 minecraft:magenta_terracotta
setblock 559 254 230 minecraft:magenta_terracotta
setblock 559 254 234 minecraft:magenta_terracotta
setblock 559 254 238 minecraft:magenta_terracotta
setblock 559 254 242 minecraft:magenta_terracotta
setblock 559 254 246 minecraft:magenta_terracotta
setblock 559 254 250 minecraft:magenta_terracotta
setblock 559 254 254 minecraft:magenta_terracotta
setblock 559 254 258 minecraft:magenta_terracotta
setblock 559 254 262 minecraft:magenta_terracotta
setblock 559 254 266 minecraft:magenta_terracotta
setblock 559 254 270 minecraft:magenta_terracotta
fill 517 255 230 517 257 230 minecraft:purple_terracotta
fill 517 255 234 517 257 234 minecraft:purple_terracotta
fill 517 255 238 517 257 238 minecraft:purple_terracotta
fill 517 255 242 517 257 242 minecraft:purple_terracotta
fill 517 255 246 517 257 246 minecraft:purple_terracotta
fill 517 255 250 517 257 250 minecraft:purple_terracotta
fill 517 255 254 517 257 254 minecraft:purple_terracotta
fill 517 255 258 517 257 258 minecraft:purple_terracotta
fill 517 255 262 517 257 262 minecraft:purple_terracotta
fill 517 255 266 517 257 266 minecraft:purple_terracotta
setblock 517 255 270 minecraft:purple_terracotta
fill 519 255 228 519 257 228 minecraft:purple_terracotta
fill 519 255 270 519 257 270 minecraft:purple_terracotta
fill 521 255 255 523 259 255 minecraft:stripped_dark_oak_log
fill 523 255 228 523 257 228 minecraft:purple_terracotta
fill 523 255 270 523 257 270 minecraft:purple_terracotta
fill 527 255 228 527 257 228 minecraft:purple_terracotta
fill 527 255 270 527 257 270 minecraft:purple_terracotta
fill 531 255 228 531 257 228 minecraft:purple_terracotta
fill 531 255 270 531 257 270 minecraft:purple_terracotta
fill 535 255 228 535 257 228 minecraft:purple_terracotta
fill 535 255 270 535 257 270 minecraft:purple_terracotta
fill 539 255 228 539 257 228 minecraft:purple_terracotta
fill 539 255 270 539 257 270 minecraft:purple_terracotta
fill 543 255 228 544 257 228 minecraft:purple_terracotta
fill 543 255 270 543 257 270 minecraft:purple_terracotta
fill 547 255 228 547 257 228 minecraft:purple_terracotta
fill 547 255 270 547 257 270 minecraft:purple_terracotta
fill 551 255 228 551 257 228 minecraft:purple_terracotta
fill 551 255 270 551 257 270 minecraft:purple_terracotta
fill 555 255 228 555 257 228 minecraft:purple_terracotta
fill 555 255 270 555 257 270 minecraft:purple_terracotta
fill 557 255 233 557 255 234 minecraft:spruce_planks
fill 557 255 235 558 255 236 minecraft:dark_oak_planks
setblock 559 255 228 minecraft:purple_terracotta
fill 559 255 230 559 257 230 minecraft:purple_terracotta
fill 559 255 234 559 257 234 minecraft:purple_terracotta
fill 559 255 238 559 257 238 minecraft:purple_terracotta
fill 559 255 242 559 257 242 minecraft:purple_terracotta
fill 559 255 246 559 257 246 minecraft:purple_terracotta
fill 559 255 250 559 257 250 minecraft:purple_terracotta
fill 559 255 254 559 257 254 minecraft:purple_terracotta
fill 559 255 258 559 257 258 minecraft:purple_terracotta
fill 559 255 262 559 257 262 minecraft:purple_terracotta
fill 559 255 266 559 257 266 minecraft:purple_terracotta
fill 559 255 270 559 257 270 minecraft:purple_terracotta
setblock 517 256 228 minecraft:magenta_terracotta
setblock 517 256 232 minecraft:magenta_terracotta
setblock 517 256 236 minecraft:magenta_terracotta
setblock 517 256 240 minecraft:magenta_terracotta
setblock 517 256 244 minecraft:magenta_terracotta
setblock 517 256 248 minecraft:magenta_terracotta
setblock 517 256 252 minecraft:magenta_terracotta
setblock 517 256 256 minecraft:magenta_terracotta
setblock 517 256 260 minecraft:magenta_terracotta
setblock 517 256 264 minecraft:magenta_terracotta
setblock 517 256 268 minecraft:magenta_terracotta
setblock 517 256 270 minecraft:magenta_terracotta
setblock 521 256 228 minecraft:magenta_terracotta
setblock 521 256 270 minecraft:magenta_terracotta
setblock 525 256 228 minecraft:magenta_terracotta
setblock 525 256 270 minecraft:magenta_terracotta
fill 528 256 270 528 278 270 minecraft:purple_terracotta
setblock 529 256 228 minecraft:magenta_terracotta
setblock 529 256 270 minecraft:magenta_terracotta
setblock 533 256 228 minecraft:magenta_terracotta
setblock 533 256 270 minecraft:magenta_terracotta
setblock 537 256 228 minecraft:magenta_terracotta
setblock 537 256 270 minecraft:magenta_terracotta
setblock 541 256 228 minecraft:magenta_terracotta
setblock 541 256 270 minecraft:magenta_terracotta
setblock 545 256 228 minecraft:magenta_terracotta
setblock 545 256 270 minecraft:magenta_terracotta
setblock 549 256 228 minecraft:magenta_terracotta
setblock 549 256 270 minecraft:magenta_terracotta
setblock 553 256 228 minecraft:magenta_terracotta
setblock 553 256 270 minecraft:magenta_terracotta
setblock 557 256 228 minecraft:magenta_terracotta
fill 557 256 231 557 256 232 minecraft:spruce_planks
fill 557 256 233 558 256 234 minecraft:dark_oak_planks
setblock 557 256 270 minecraft:magenta_terracotta
setblock 559 256 228 minecraft:magenta_terracotta
setblock 559 256 232 minecraft:magenta_terracotta
setblock 559 256 236 minecraft:magenta_terracotta
setblock 559 256 240 minecraft:magenta_terracotta
setblock 559 256 244 minecraft:magenta_terracotta
setblock 559 256 248 minecraft:magenta_terracotta
setblock 559 256 252 minecraft:magenta_terracotta
setblock 559 256 256 minecraft:magenta_terracotta
setblock 559 256 260 minecraft:magenta_terracotta
setblock 559 256 264 minecraft:magenta_terracotta
setblock 559 256 268 minecraft:magenta_terracotta
fill 517 257 228 517 259 228 minecraft:purple_terracotta
fill 517 257 232 517 259 232 minecraft:purple_terracotta
fill 517 257 236 517 259 236 minecraft:purple_terracotta
fill 517 257 240 517 259 240 minecraft:purple_terracotta
fill 517 257 244 517 259 244 minecraft:purple_terracotta
fill 517 257 248 517 259 248 minecraft:purple_terracotta
fill 517 257 252 517 259 252 minecraft:purple_terracotta
fill 517 257 256 517 259 256 minecraft:purple_terracotta
setblock 517 257 260 minecraft:purple_terracotta
fill 517 257 264 517 259 264 minecraft:purple_terracotta
fill 517 257 268 517 259 268 minecraft:purple_terracotta
setblock 517 257 270 minecraft:purple_terracotta
setblock 520 257 231 minecraft:light[level=11]
setblock 520 257 239 minecraft:light[level=11]
setblock 520 257 247 minecraft:light[level=11]
setblock 520 257 255 minecraft:light[level=11]
setblock 520 257 263 minecraft:light[level=11]
fill 521 257 228 521 259 228 minecraft:purple_terracotta
fill 521 257 270 521 259 270 minecraft:purple_terracotta
fill 525 257 228 525 259 228 minecraft:purple_terracotta
fill 525 257 270 525 259 270 minecraft:purple_terracotta
setblock 528 257 231 minecraft:light[level=11]
setblock 528 257 239 minecraft:light[level=11]
setblock 528 257 247 minecraft:light[level=11]
setblock 528 257 255 minecraft:light[level=11]
setblock 528 257 263 minecraft:light[level=11]
fill 529 257 228 529 259 228 minecraft:purple_terracotta
fill 529 257 270 529 259 270 minecraft:purple_terracotta
fill 533 257 228 533 259 228 minecraft:purple_terracotta
fill 533 257 270 533 259 270 minecraft:purple_terracotta
setblock 536 257 231 minecraft:light[level=11]
setblock 536 257 239 minecraft:light[level=11]
setblock 536 257 247 minecraft:light[level=11]
setblock 536 257 255 minecraft:light[level=11]
setblock 536 257 263 minecraft:light[level=11]
fill 537 257 228 537 259 228 minecraft:purple_terracotta
fill 537 257 270 537 259 270 minecraft:purple_terracotta
fill 541 257 228 541 259 228 minecraft:purple_terracotta
fill 541 257 229 545 257 229 minecraft:gold_block
fill 541 257 270 541 259 270 minecraft:purple_terracotta
setblock 544 257 231 minecraft:light[level=11]
setblock 544 257 239 minecraft:light[level=11]
setblock 544 257 247 minecraft:light[level=11]
setblock 544 257 255 minecraft:light[level=11]
setblock 544 257 263 minecraft:light[level=11]
fill 545 257 228 545 258 228 minecraft:purple_terracotta
fill 545 257 270 545 259 270 minecraft:purple_terracotta
fill 549 257 228 549 259 228 minecraft:purple_terracotta
fill 549 257 270 549 259 270 minecraft:purple_terracotta
setblock 552 257 231 minecraft:light[level=11]
setblock 552 257 239 minecraft:light[level=11]
setblock 552 257 247 minecraft:light[level=11]
setblock 552 257 255 minecraft:light[level=11]
setblock 552 257 263 minecraft:light[level=11]
fill 553 257 228 553 259 228 minecraft:purple_terracotta
fill 553 257 270 553 259 270 minecraft:purple_terracotta
fill 557 257 228 557 259 228 minecraft:purple_terracotta
setblock 557 257 230 minecraft:spruce_planks
fill 557 257 231 558 257 232 minecraft:dark_oak_planks
fill 557 257 270 557 259 270 minecraft:purple_terracotta
setblock 559 257 228 minecraft:purple_terracotta
fill 559 257 232 559 259 232 minecraft:purple_terracotta
fill 559 257 236 559 259 236 minecraft:purple_terracotta
fill 559 257 240 559 259 240 minecraft:purple_terracotta
fill 559 257 244 559 259 244 minecraft:purple_terracotta
fill 559 257 248 559 259 248 minecraft:purple_terracotta
fill 559 257 252 559 259 252 minecraft:purple_terracotta
fill 559 257 256 559 259 256 minecraft:purple_terracotta
fill 559 257 260 559 259 260 minecraft:purple_terracotta
fill 559 257 264 559 259 264 minecraft:purple_terracotta
fill 559 257 268 559 259 268 minecraft:purple_terracotta
setblock 517 258 230 minecraft:magenta_terracotta
setblock 517 258 234 minecraft:magenta_terracotta
setblock 517 258 238 minecraft:magenta_terracotta
setblock 517 258 242 minecraft:magenta_terracotta
setblock 517 258 246 minecraft:magenta_terracotta
setblock 517 258 250 minecraft:magenta_terracotta
setblock 517 258 254 minecraft:magenta_terracotta
setblock 517 258 258 minecraft:magenta_terracotta
setblock 517 258 260 minecraft:light_gray_terracotta
setblock 517 258 262 minecraft:magenta_terracotta
setblock 517 258 266 minecraft:magenta_terracotta
setblock 517 258 270 minecraft:magenta_terracotta
setblock 519 258 228 minecraft:magenta_terracotta
setblock 519 258 270 minecraft:magenta_terracotta
fill 522 258 254 522 259 254 minecraft:stripped_dark_oak_log
fill 522 258 256 522 259 256 minecraft:stripped_dark_oak_log
setblock 523 258 228 minecraft:magenta_terracotta
setblock 523 258 270 minecraft:magenta_terracotta
setblock 527 258 228 minecraft:magenta_terracotta
setblock 527 258 270 minecraft:magenta_terracotta
setblock 531 258 228 minecraft:magenta_terracotta
setblock 531 258 270 minecraft:magenta_terracotta
setblock 535 258 228 minecraft:magenta_terracotta
fill 535 258 229 539 258 229 minecraft:gold_block
setblock 535 258 270 minecraft:magenta_terracotta
setblock 539 258 228 minecraft:magenta_terracotta
setblock 539 258 270 minecraft:magenta_terracotta
fill 541 258 229 541 263 229 minecraft:gold_block
fill 542 258 229 544 259 229 minecraft:red_terracotta
setblock 543 258 228 minecraft:magenta_terracotta
setblock 543 258 270 minecraft:magenta_terracotta
fill 544 258 228 544 278 228 minecraft:purple_terracotta
fill 545 258 229 545 263 229 minecraft:gold_block
setblock 547 258 228 minecraft:magenta_terracotta
setblock 547 258 270 minecraft:magenta_terracotta
setblock 551 258 228 minecraft:magenta_terracotta
setblock 551 258 270 minecraft:magenta_terracotta
setblock 555 258 228 minecraft:magenta_terracotta
fill 555 258 230 556 258 230 minecraft:spruce_planks
setblock 555 258 270 minecraft:magenta_terracotta
fill 557 258 229 558 258 230 minecraft:dark_oak_planks
setblock 559 258 228 minecraft:magenta_terracotta
setblock 559 258 230 minecraft:magenta_terracotta
setblock 559 258 234 minecraft:magenta_terracotta
setblock 559 258 238 minecraft:magenta_terracotta
setblock 559 258 242 minecraft:magenta_terracotta
setblock 559 258 246 minecraft:magenta_terracotta
setblock 559 258 250 minecraft:magenta_terracotta
setblock 559 258 254 minecraft:magenta_terracotta
setblock 559 258 258 minecraft:magenta_terracotta
setblock 559 258 262 minecraft:magenta_terracotta
setblock 559 258 266 minecraft:magenta_terracotta
setblock 559 258 270 minecraft:magenta_terracotta
fill 517 259 230 517 261 230 minecraft:purple_terracotta
fill 517 259 234 517 261 234 minecraft:purple_terracotta
fill 517 259 238 517 261 238 minecraft:purple_terracotta
fill 517 259 242 517 261 242 minecraft:purple_terracotta
fill 517 259 246 517 261 246 minecraft:purple_terracotta
fill 517 259 250 517 261 250 minecraft:purple_terracotta
fill 517 259 254 517 261 254 minecraft:purple_terracotta
fill 517 259 258 517 261 258 minecraft:purple_terracotta
setblock 517 259 260 minecraft:purple_terracotta
fill 517 259 262 517 261 262 minecraft:purple_terracotta
fill 517 259 266 517 261 266 minecraft:purple_terracotta
setblock 517 259 270 minecraft:purple_terracotta
fill 519 259 228 519 261 228 minecraft:purple_terracotta
fill 519 259 270 519 261 270 minecraft:purple_terracotta
setblock 520 259 231 minecraft:light[level=12]
setblock 520 259 238 minecraft:light[level=12]
setblock 520 259 245 minecraft:light[level=12]
setblock 520 259 252 minecraft:light[level=12]
setblock 520 259 259 minecraft:light[level=12]
setblock 520 259 266 minecraft:light[level=12]
fill 523 259 228 523 261 228 minecraft:purple_terracotta
fill 523 259 270 523 261 270 minecraft:purple_terracotta
fill 527 259 228 527 261 228 minecraft:purple_terracotta
setblock 527 259 231 minecraft:light[level=12]
setblock 527 259 238 minecraft:light[level=12]
setblock 527 259 245 minecraft:light[level=12]
setblock 527 259 252 minecraft:light[level=12]
setblock 527 259 259 minecraft:light[level=12]
setblock 527 259 266 minecraft:light[level=12]
fill 527 259 270 527 261 270 minecraft:purple_terracotta
fill 531 259 228 531 261 228 minecraft:purple_terracotta
fill 531 259 270 531 261 270 minecraft:purple_terracotta
setblock 534 259 231 minecraft:light[level=12]
setblock 534 259 238 minecraft:light[level=12]
setblock 534 259 245 minecraft:light[level=12]
setblock 534 259 252 minecraft:light[level=12]
setblock 534 259 259 minecraft:light[level=12]
setblock 534 259 266 minecraft:light[level=12]
fill 535 259 228 535 261 228 minecraft:purple_terracotta
fill 535 259 229 535 264 229 minecraft:gold_block
fill 535 259 246 535 277 246 minecraft:iron_bars
fill 535 259 252 535 277 252 minecraft:iron_bars
fill 535 259 270 535 261 270 minecraft:purple_terracotta
fill 536 259 229 538 260 229 minecraft:brown_concrete
fill 539 259 228 539 261 228 minecraft:purple_terracotta
fill 539 259 229 539 264 229 minecraft:gold_block
fill 539 259 270 539 261 270 minecraft:purple_terracotta
setblock 541 259 231 minecraft:light[level=12]
setblock 541 259 238 minecraft:light[level=12]
setblock 541 259 245 minecraft:light[level=12]
setblock 541 259 252 minecraft:light[level=12]
setblock 541 259 259 minecraft:light[level=12]
setblock 541 259 266 minecraft:light[level=12]
fill 543 259 228 543 261 228 minecraft:purple_terracotta
fill 543 259 270 543 261 270 minecraft:purple_terracotta
setblock 545 259 228 minecraft:light_gray_terracotta
fill 547 259 228 547 261 228 minecraft:purple_terracotta
fill 547 259 270 547 261 270 minecraft:purple_terracotta
setblock 548 259 231 minecraft:light[level=12]
setblock 548 259 238 minecraft:light[level=12]
setblock 548 259 245 minecraft:light[level=12]
setblock 548 259 252 minecraft:light[level=12]
setblock 548 259 259 minecraft:light[level=12]
setblock 548 259 266 minecraft:light[level=12]
fill 551 259 228 551 261 228 minecraft:purple_terracotta
fill 551 259 270 551 261 270 minecraft:purple_terracotta
fill 553 259 230 554 259 230 minecraft:spruce_planks
fill 555 259 228 555 261 228 minecraft:purple_terracotta
fill 555 259 229 556 259 230 minecraft:dark_oak_planks
setblock 555 259 231 minecraft:light[level=12]
setblock 555 259 238 minecraft:light[level=12]
setblock 555 259 245 minecraft:light[level=12]
setblock 555 259 252 minecraft:light[level=12]
setblock 555 259 259 minecraft:light[level=12]
setblock 555 259 266 minecraft:light[level=12]
fill 555 259 270 555 261 270 minecraft:purple_terracotta
setblock 559 259 228 minecraft:purple_terracotta
fill 559 259 230 559 261 230 minecraft:purple_terracotta
fill 559 259 234 559 261 234 minecraft:purple_terracotta
fill 559 259 238 559 261 238 minecraft:purple_terracotta
fill 559 259 242 559 261 242 minecraft:purple_terracotta
fill 559 259 246 559 261 246 minecraft:purple_terracotta
fill 559 259 250 559 261 250 minecraft:purple_terracotta
fill 559 259 254 559 261 254 minecraft:purple_terracotta
fill 559 259 258 559 261 258 minecraft:purple_terracotta
fill 559 259 262 559 261 262 minecraft:purple_terracotta
fill 559 259 266 559 261 266 minecraft:purple_terracotta
fill 559 259 270 559 261 270 minecraft:purple_terracotta
setblock 517 260 228 minecraft:magenta_terracotta
setblock 517 260 232 minecraft:magenta_terracotta
setblock 517 260 236 minecraft:magenta_terracotta
setblock 517 260 240 minecraft:magenta_terracotta
setblock 517 260 244 minecraft:magenta_terracotta
setblock 517 260 248 minecraft:magenta_terracotta
setblock 517 260 252 minecraft:magenta_terracotta
setblock 517 260 256 minecraft:magenta_terracotta
setblock 517 260 260 minecraft:magenta_terracotta
setblock 517 260 264 minecraft:magenta_terracotta
setblock 517 260 268 minecraft:magenta_terracotta
setblock 517 260 270 minecraft:magenta_terracotta
setblock 521 260 228 minecraft:magenta_terracotta
setblock 521 260 270 minecraft:magenta_terracotta
setblock 525 260 228 minecraft:magenta_terracotta
setblock 525 260 270 minecraft:magenta_terracotta
setblock 529 260 228 minecraft:magenta_terracotta
setblock 529 260 270 minecraft:magenta_terracotta
setblock 533 260 228 minecraft:magenta_terracotta
setblock 533 260 270 minecraft:magenta_terracotta
setblock 537 260 228 minecraft:magenta_terracotta
setblock 537 260 270 minecraft:magenta_terracotta
setblock 541 260 228 minecraft:magenta_terracotta
setblock 541 260 270 minecraft:magenta_terracotta
fill 542 260 229 544 260 229 minecraft:white_terracotta
setblock 542 260 270 minecraft:gray_terracotta
setblock 545 260 228 minecraft:magenta_terracotta
setblock 545 260 270 minecraft:magenta_terracotta
setblock 549 260 228 minecraft:magenta_terracotta
setblock 549 260 270 minecraft:magenta_terracotta
fill 551 260 230 552 260 230 minecraft:spruce_planks
setblock 553 260 228 minecraft:magenta_terracotta
fill 553 260 229 554 260 230 minecraft:dark_oak_planks
setblock 553 260 270 minecraft:magenta_terracotta
setblock 557 260 228 minecraft:magenta_terracotta
setblock 557 260 270 minecraft:magenta_terracotta
setblock 559 260 228 minecraft:magenta_terracotta
setblock 559 260 232 minecraft:magenta_terracotta
setblock 559 260 236 minecraft:magenta_terracotta
setblock 559 260 240 minecraft:magenta_terracotta
setblock 559 260 244 minecraft:magenta_terracotta
setblock 559 260 248 minecraft:magenta_terracotta
setblock 559 260 252 minecraft:magenta_terracotta
setblock 559 260 256 minecraft:magenta_terracotta
setblock 559 260 260 minecraft:magenta_terracotta
setblock 559 260 264 minecraft:magenta_terracotta
setblock 559 260 268 minecraft:magenta_terracotta
fill 517 261 228 517 263 228 minecraft:purple_terracotta
fill 517 261 232 517 263 232 minecraft:purple_terracotta
fill 517 261 236 517 263 236 minecraft:purple_terracotta
fill 517 261 240 517 263 240 minecraft:purple_terracotta
fill 517 261 244 517 263 244 minecraft:purple_terracotta
fill 517 261 248 517 263 248 minecraft:purple_terracotta
fill 517 261 252 517 263 252 minecraft:purple_terracotta
fill 517 261 256 517 263 256 minecraft:purple_terracotta
fill 517 261 260 517 263 260 minecraft:purple_terracotta
fill 517 261 264 517 263 264 minecraft:purple_terracotta
fill 517 261 268 517 263 268 minecraft:purple_terracotta
setblock 517 261 270 minecraft:purple_terracotta
fill 521 261 228 521 263 228 minecraft:purple_terracotta
fill 521 261 270 521 263 270 minecraft:purple_terracotta
fill 525 261 228 525 263 228 minecraft:purple_terracotta
fill 525 261 270 525 263 270 minecraft:purple_terracotta
fill 529 261 228 529 263 228 minecraft:purple_terracotta
fill 529 261 270 529 263 270 minecraft:purple_terracotta
fill 533 261 228 533 263 228 minecraft:purple_terracotta
fill 533 261 270 533 263 270 minecraft:purple_terracotta
fill 536 261 229 538 261 229 minecraft:pink_terracotta
fill 537 261 228 537 263 228 minecraft:purple_terracotta
fill 537 261 270 537 263 270 minecraft:purple_terracotta
fill 541 261 228 541 263 228 minecraft:purple_terracotta
fill 541 261 270 542 263 270 minecraft:purple_terracotta
setblock 542 261 229 minecraft:black_concrete
fill 543 261 229 543 262 229 minecraft:white_terracotta
setblock 544 261 229 minecraft:black_concrete
fill 545 261 228 545 263 228 minecraft:purple_terracotta
fill 545 261 270 545 263 270 minecraft:purple_terracotta
fill 549 261 228 549 263 228 minecraft:purple_terracotta
fill 549 261 230 550 261 230 minecraft:spruce_planks
fill 549 261 270 549 263 270 minecraft:purple_terracotta
fill 551 261 229 552 261 230 minecraft:dark_oak_planks
fill 553 261 228 553 263 228 minecraft:purple_terracotta
fill 553 261 270 553 263 270 minecraft:purple_terracotta
fill 557 261 228 557 263 228 minecraft:purple_terracotta
fill 557 261 270 557 263 270 minecraft:purple_terracotta
setblock 559 261 228 minecraft:purple_terracotta
fill 559 261 232 559 263 232 minecraft:purple_terracotta
fill 559 261 236 559 263 236 minecraft:purple_terracotta
fill 559 261 240 559 263 240 minecraft:purple_terracotta
fill 559 261 244 559 263 244 minecraft:purple_terracotta
fill 559 261 248 559 263 248 minecraft:purple_terracotta
setblock 559 261 251 minecraft:black_terracotta
fill 559 261 252 559 263 252 minecraft:purple_terracotta
fill 559 261 256 559 263 256 minecraft:purple_terracotta
fill 559 261 260 559 263 260 minecraft:purple_terracotta
fill 559 261 264 559 263 264 minecraft:purple_terracotta
fill 559 261 268 559 263 268 minecraft:purple_terracotta
setblock 517 262 230 minecraft:magenta_terracotta
setblock 517 262 234 minecraft:magenta_terracotta
setblock 517 262 238 minecraft:magenta_terracotta
setblock 517 262 242 minecraft:magenta_terracotta
setblock 517 262 246 minecraft:magenta_terracotta
setblock 517 262 250 minecraft:magenta_terracotta
setblock 517 262 254 minecraft:magenta_terracotta
setblock 517 262 258 minecraft:magenta_terracotta
setblock 517 262 262 minecraft:magenta_terracotta
setblock 517 262 266 minecraft:magenta_terracotta
setblock 517 262 270 minecraft:magenta_terracotta
setblock 519 262 228 minecraft:magenta_terracotta
setblock 519 262 270 minecraft:magenta_terracotta
setblock 523 262 228 minecraft:magenta_terracotta
setblock 523 262 270 minecraft:magenta_terracotta
setblock 527 262 228 minecraft:magenta_terracotta
setblock 527 262 270 minecraft:magenta_terracotta
setblock 531 262 228 minecraft:magenta_terracotta
setblock 531 262 270 minecraft:magenta_terracotta
setblock 535 262 228 minecraft:magenta_terracotta
setblock 535 262 270 minecraft:magenta_terracotta
setblock 536 262 229 minecraft:blue_concrete
fill 537 262 229 537 263 229 minecraft:pink_terracotta
setblock 538 262 229 minecraft:blue_concrete
setblock 539 262 228 minecraft:magenta_terracotta
setblock 539 262 270 minecraft:magenta_terracotta
setblock 542 262 229 minecraft:white_terracotta
setblock 543 262 228 minecraft:magenta_terracotta
setblock 543 262 270 minecraft:magenta_terracotta
setblock 544 262 229 minecraft:white_terracotta
setblock 547 262 228 minecraft:magenta_terracotta
fill 547 262 230 548 262 230 minecraft:spruce_planks
setblock 547 262 270 minecraft:magenta_terracotta
fill 549 262 229 550 262 230 minecraft:dark_oak_planks
setblock 550 262 270 minecraft:gray_terracotta
setblock 551 262 228 minecraft:magenta_terracotta
setblock 551 262 270 minecraft:magenta_terracotta
setblock 555 262 228 minecraft:magenta_terracotta
setblock 555 262 270 minecraft:magenta_terracotta
setblock 559 262 228 minecraft:magenta_terracotta
setblock 559 262 230 minecraft:magenta_terracotta
setblock 559 262 234 minecraft:magenta_terracotta
setblock 559 262 238 minecraft:magenta_terracotta
setblock 559 262 242 minecraft:magenta_terracotta
setblock 559 262 246 minecraft:magenta_terracotta
setblock 559 262 250 minecraft:magenta_terracotta
fill 559 262 251 559 278 251 minecraft:purple_terracotta
setblock 559 262 254 minecraft:magenta_terracotta
setblock 559 262 258 minecraft:magenta_terracotta
setblock 559 262 262 minecraft:magenta_terracotta
setblock 559 262 266 minecraft:magenta_terracotta
setblock 559 262 270 minecraft:magenta_terracotta
fill 517 263 230 517 265 230 minecraft:purple_terracotta
fill 517 263 234 517 265 234 minecraft:purple_terracotta
fill 517 263 238 517 265 238 minecraft:purple_terracotta
fill 517 263 242 517 265 242 minecraft:purple_terracotta
fill 517 263 246 517 265 246 minecraft:purple_terracotta
fill 517 263 250 517 265 250 minecraft:purple_terracotta
fill 517 263 254 517 265 254 minecraft:purple_terracotta
fill 517 263 258 517 265 258 minecraft:purple_terracotta
fill 517 263 262 517 265 262 minecraft:purple_terracotta
fill 517 263 266 517 265 266 minecraft:purple_terracotta
setblock 517 263 270 minecraft:purple_terracotta
fill 519 263 228 519 265 228 minecraft:purple_terracotta
fill 519 263 270 519 265 270 minecraft:purple_terracotta
fill 523 263 228 523 265 228 minecraft:purple_terracotta
fill 523 263 270 523 265 270 minecraft:purple_terracotta
fill 527 263 228 527 265 228 minecraft:purple_terracotta
fill 527 263 270 527 265 270 minecraft:purple_terracotta
fill 531 263 228 531 265 228 minecraft:purple_terracotta
fill 531 263 270 531 265 270 minecraft:purple_terracotta
fill 535 263 228 535 265 228 minecraft:purple_terracotta
fill 535 263 270 535 265 270 minecraft:purple_terracotta
setblock 536 263 229 minecraft:pink_terracotta
setblock 538 263 229 minecraft:pink_terracotta
fill 539 263 228 539 265 228 minecraft:purple_terracotta
fill 539 263 270 539 265 270 minecraft:purple_terracotta
fill 542 263 229 544 263 229 minecraft:gold_block
fill 543 263 228 543 265 228 minecraft:purple_terracotta
fill 543 263 270 543 265 270 minecraft:purple_terracotta
fill 545 263 230 546 263 230 minecraft:spruce_planks
fill 547 263 228 547 265 228 minecraft:purple_terracotta
fill 547 263 229 548 263 230 minecraft:dark_oak_planks
fill 547 263 270 547 265 270 minecraft:purple_terracotta
fill 550 263 270 551 265 270 minecraft:purple_terracotta
fill 551 263 228 551 265 228 minecraft:purple_terracotta
fill 555 263 228 555 265 228 minecraft:purple_terracotta
fill 555 263 270 555 265 270 minecraft:purple_terracotta
setblock 559 263 228 minecraft:purple_terracotta
fill 559 263 230 559 265 230 minecraft:purple_terracotta
fill 559 263 234 559 265 234 minecraft:purple_terracotta
fill 559 263 238 559 265 238 minecraft:purple_terracotta
fill 559 263 242 559 265 242 minecraft:purple_terracotta
fill 559 263 246 559 265 246 minecraft:purple_terracotta
fill 559 263 250 559 265 250 minecraft:purple_terracotta
fill 559 263 254 559 265 254 minecraft:purple_terracotta
fill 559 263 258 559 265 258 minecraft:purple_terracotta
fill 559 263 262 559 265 262 minecraft:purple_terracotta
setblock 559 263 265 minecraft:black_terracotta
fill 559 263 266 559 265 266 minecraft:purple_terracotta
fill 559 263 270 559 265 270 minecraft:purple_terracotta
setblock 517 264 228 minecraft:magenta_terracotta
setblock 517 264 232 minecraft:magenta_terracotta
setblock 517 264 236 minecraft:magenta_terracotta
setblock 517 264 240 minecraft:magenta_terracotta
setblock 517 264 244 minecraft:magenta_terracotta
setblock 517 264 248 minecraft:magenta_terracotta
setblock 517 264 252 minecraft:magenta_terracotta
setblock 517 264 256 minecraft:magenta_terracotta
setblock 517 264 260 minecraft:magenta_terracotta
setblock 517 264 264 minecraft:magenta_terracotta
setblock 517 264 268 minecraft:magenta_terracotta
setblock 517 264 270 minecraft:magenta_terracotta
setblock 521 264 228 minecraft:magenta_terracotta
setblock 521 264 270 minecraft:magenta_terracotta
setblock 525 264 228 minecraft:magenta_terracotta
setblock 525 264 270 minecraft:magenta_terracotta
setblock 529 264 228 minecraft:magenta_terracotta
setblock 529 264 270 minecraft:magenta_terracotta
setblock 533 264 228 minecraft:magenta_terracotta
setblock 533 264 270 minecraft:magenta_terracotta
fill 536 264 229 538 264 229 minecraft:gold_block
setblock 537 264 228 minecraft:magenta_terracotta
setblock 537 264 270 minecraft:magenta_terracotta
setblock 541 264 228 minecraft:magenta_terracotta
setblock 541 264 270 minecraft:magenta_terracotta
fill 542 264 270 542 278 270 minecraft:purple_terracotta
fill 543 264 230 544 264 230 minecraft:spruce_planks
setblock 545 264 228 minecraft:magenta_terracotta
fill 545 264 229 546 264 230 minecraft:dark_oak_planks
setblock 545 264 270 minecraft:magenta_terracotta
setblock 549 264 228 minecraft:magenta_terracotta
setblock 549 264 270 minecraft:magenta_terracotta
setblock 553 264 228 minecraft:magenta_terracotta
setblock 553 264 270 minecraft:magenta_terracotta
setblock 557 264 228 minecraft:magenta_terracotta
setblock 557 264 270 minecraft:magenta_terracotta
setblock 559 264 228 minecraft:magenta_terracotta
setblock 559 264 232 minecraft:magenta_terracotta
setblock 559 264 236 minecraft:magenta_terracotta
setblock 559 264 240 minecraft:magenta_terracotta
setblock 559 264 244 minecraft:magenta_terracotta
setblock 559 264 248 minecraft:magenta_terracotta
setblock 559 264 252 minecraft:magenta_terracotta
setblock 559 264 256 minecraft:magenta_terracotta
setblock 559 264 260 minecraft:magenta_terracotta
setblock 559 264 264 minecraft:magenta_terracotta
fill 559 264 265 559 278 265 minecraft:purple_terracotta
setblock 559 264 268 minecraft:magenta_terracotta
fill 517 265 228 517 267 228 minecraft:purple_terracotta
fill 517 265 232 517 267 232 minecraft:purple_terracotta
fill 517 265 236 517 267 236 minecraft:purple_terracotta
fill 517 265 240 517 267 240 minecraft:purple_terracotta
fill 517 265 244 517 267 244 minecraft:purple_terracotta
fill 517 265 248 517 267 248 minecraft:purple_terracotta
fill 517 265 252 517 267 252 minecraft:purple_terracotta
fill 517 265 256 517 267 256 minecraft:purple_terracotta
fill 517 265 260 517 267 260 minecraft:purple_terracotta
fill 517 265 264 517 267 264 minecraft:purple_terracotta
fill 517 265 268 517 267 268 minecraft:purple_terracotta
setblock 517 265 270 minecraft:purple_terracotta
setblock 520 265 231 minecraft:light[level=11]
setblock 520 265 238 minecraft:light[level=12]
setblock 520 265 239 minecraft:light[level=11]
setblock 520 265 245 minecraft:light[level=12]
setblock 520 265 247 minecraft:light[level=11]
setblock 520 265 252 minecraft:light[level=12]
setblock 520 265 255 minecraft:light[level=11]
setblock 520 265 259 minecraft:light[level=12]
setblock 520 265 263 minecraft:light[level=11]
setblock 520 265 266 minecraft:light[level=12]
fill 521 265 228 521 267 228 minecraft:purple_terracotta
fill 521 265 270 521 267 270 minecraft:purple_terracotta
fill 525 265 228 525 267 228 minecraft:purple_terracotta
fill 525 265 270 525 267 270 minecraft:purple_terracotta
setblock 527 265 231 minecraft:light[level=12]
setblock 527 265 238 minecraft:light[level=12]
setblock 527 265 245 minecraft:light[level=12]
setblock 527 265 252 minecraft:light[level=12]
setblock 527 265 259 minecraft:light[level=12]
setblock 527 265 266 minecraft:light[level=12]
setblock 528 265 231 minecraft:light[level=11]
setblock 528 265 239 minecraft:light[level=11]
setblock 528 265 247 minecraft:light[level=11]
setblock 528 265 255 minecraft:light[level=11]
setblock 528 265 263 minecraft:light[level=11]
fill 529 265 228 529 267 228 minecraft:purple_terracotta
setblock 529 265 270 minecraft:purple_terracotta
fill 533 265 228 533 267 228 minecraft:purple_terracotta
fill 533 265 270 533 267 270 minecraft:purple_terracotta
setblock 534 265 231 minecraft:light[level=12]
setblock 534 265 238 minecraft:light[level=12]
setblock 534 265 245 minecraft:light[level=12]
setblock 534 265 252 minecraft:light[level=12]
setblock 534 265 259 minecraft:light[level=12]
setblock 534 265 266 minecraft:light[level=12]
setblock 536 265 231 minecraft:light[level=11]
setblock 536 265 239 minecraft:light[level=11]
setblock 536 265 247 minecraft:light[level=11]
setblock 536 265 255 minecraft:light[level=11]
setblock 536 265 263 minecraft:light[level=11]
fill 537 265 228 537 267 228 minecraft:purple_terracotta
fill 537 265 270 537 267 270 minecraft:purple_terracotta
setblock 540 265 270 minecraft:light_gray_terracotta
fill 541 265 228 541 267 228 minecraft:purple_terracotta
fill 541 265 230 542 265 230 minecraft:spruce_planks
setblock 541 265 231 minecraft:light[level=12]
setblock 541 265 238 minecraft:light[level=12]
setblock 541 265 245 minecraft:light[level=12]
fill 541 265 246 541 277 246 minecraft:iron_bars
fill 541 265 252 541 277 252 minecraft:iron_bars
setblock 541 265 259 minecraft:light[level=12]
setblock 541 265 266 minecraft:light[level=12]
fill 541 265 270 541 267 270 minecraft:purple_terracotta
fill 543 265 229 544 265 230 minecraft:dark_oak_planks
setblock 544 265 231 minecraft:light[level=11]
setblock 544 265 239 minecraft:light[level=11]
setblock 544 265 247 minecraft:light[level=11]
setblock 544 265 255 minecraft:light[level=11]
setblock 544 265 263 minecraft:light[level=11]
fill 545 265 228 545 267 228 minecraft:purple_terracotta
fill 545 265 270 545 267 270 minecraft:purple_terracotta
setblock 548 265 231 minecraft:light[level=12]
setblock 548 265 238 minecraft:light[level=12]
setblock 548 265 245 minecraft:light[level=12]
setblock 548 265 252 minecraft:light[level=12]
setblock 548 265 259 minecraft:light[level=12]
setblock 548 265 266 minecraft:light[level=12]
fill 549 265 228 549 267 228 minecraft:purple_terracotta
fill 549 265 270 549 267 270 minecraft:purple_terracotta
setblock 552 265 231 minecraft:light[level=11]
setblock 552 265 239 minecraft:light[level=11]
setblock 552 265 247 minecraft:light[level=11]
setblock 552 265 255 minecraft:light[level=11]
setblock 552 265 263 minecraft:light[level=11]
fill 553 265 228 553 267 228 minecraft:purple_terracotta
fill 553 265 270 553 267 270 minecraft:purple_terracotta
setblock 555 265 231 minecraft:light[level=12]
setblock 555 265 238 minecraft:light[level=12]
setblock 555 265 245 minecraft:light[level=12]
setblock 555 265 252 minecraft:light[level=12]
setblock 555 265 259 minecraft:light[level=12]
setblock 555 265 266 minecraft:light[level=12]
fill 557 265 228 557 267 228 minecraft:purple_terracotta
fill 557 265 270 557 267 270 minecraft:purple_terracotta
setblock 559 265 228 minecraft:purple_terracotta
fill 559 265 232 559 267 232 minecraft:purple_terracotta
fill 559 265 236 559 267 236 minecraft:purple_terracotta
fill 559 265 240 559 267 240 minecraft:purple_terracotta
fill 559 265 244 559 267 244 minecraft:purple_terracotta
fill 559 265 248 559 267 248 minecraft:purple_terracotta
fill 559 265 252 559 267 252 minecraft:purple_terracotta
fill 559 265 256 559 267 256 minecraft:purple_terracotta
fill 559 265 260 559 267 260 minecraft:purple_terracotta
fill 559 265 264 559 267 264 minecraft:purple_terracotta
fill 559 265 268 559 267 268 minecraft:purple_terracotta
setblock 517 266 230 minecraft:magenta_terracotta
setblock 517 266 234 minecraft:magenta_terracotta
setblock 517 266 238 minecraft:magenta_terracotta
setblock 517 266 242 minecraft:magenta_terracotta
setblock 517 266 246 minecraft:magenta_terracotta
setblock 517 266 250 minecraft:magenta_terracotta
setblock 517 266 254 minecraft:magenta_terracotta
setblock 517 266 258 minecraft:magenta_terracotta
setblock 517 266 262 minecraft:magenta_terracotta
setblock 517 266 266 minecraft:magenta_terracotta
setblock 517 266 270 minecraft:magenta_terracotta
setblock 519 266 228 minecraft:magenta_terracotta
setblock 519 266 270 minecraft:magenta_terracotta
setblock 523 266 228 minecraft:magenta_terracotta
setblock 523 266 270 minecraft:magenta_terracotta
setblock 527 266 228 minecraft:magenta_terracotta
setblock 527 266 270 minecraft:magenta_terracotta
setblock 529 266 270 minecraft:gray_terracotta
setblock 531 266 228 minecraft:magenta_terracotta
setblock 531 266 270 minecraft:magenta_terracotta
setblock 535 266 228 minecraft:magenta_terracotta
setblock 535 266 270 minecraft:magenta_terracotta
setblock 539 266 228 minecraft:magenta_terracotta
fill 539 266 230 540 266 230 minecraft:spruce_planks
setblock 539 266 270 minecraft:magenta_terracotta
fill 540 266 270 540 278 270 minecraft:purple_terracotta
fill 541 266 229 542 266 230 minecraft:dark_oak_planks
setblock 543 266 228 minecraft:magenta_terracotta
setblock 543 266 270 minecraft:magenta_terracotta
setblock 547 266 228 minecraft:magenta_terracotta
setblock 547 266 270 minecraft:magenta_terracotta
fill 550 266 270 550 278 270 minecraft:purple_terracotta
setblock 551 266 228 minecraft:magenta_terracotta
setblock 551 266 270 minecraft:magenta_terracotta
setblock 555 266 228 minecraft:magenta_terracotta
setblock 555 266 270 minecraft:magenta_terracotta
setblock 559 266 228 minecraft:magenta_terracotta
setblock 559 266 230 minecraft:magenta_terracotta
setblock 559 266 234 minecraft:magenta_terracotta
setblock 559 266 238 minecraft:magenta_terracotta
setblock 559 266 242 minecraft:magenta_terracotta
setblock 559 266 246 minecraft:magenta_terracotta
setblock 559 266 250 minecraft:magenta_terracotta
setblock 559 266 254 minecraft:magenta_terracotta
setblock 559 266 258 minecraft:magenta_terracotta
setblock 559 266 262 minecraft:magenta_terracotta
setblock 559 266 266 minecraft:magenta_terracotta
setblock 559 266 270 minecraft:magenta_terracotta
fill 517 267 230 517 269 230 minecraft:purple_terracotta
fill 517 267 234 517 269 234 minecraft:purple_terracotta
fill 517 267 238 517 269 238 minecraft:purple_terracotta
fill 517 267 242 517 269 242 minecraft:purple_terracotta
fill 517 267 246 517 269 246 minecraft:purple_terracotta
fill 517 267 250 517 269 250 minecraft:purple_terracotta
fill 517 267 254 517 269 254 minecraft:purple_terracotta
fill 517 267 258 517 269 258 minecraft:purple_terracotta
fill 517 267 262 517 269 262 minecraft:purple_terracotta
fill 517 267 266 517 269 266 minecraft:purple_terracotta
setblock 517 267 270 minecraft:purple_terracotta
fill 519 267 228 519 269 228 minecraft:purple_terracotta
fill 519 267 270 519 269 270 minecraft:purple_terracotta
fill 523 267 228 523 269 228 minecraft:purple_terracotta
fill 523 267 270 523 269 270 minecraft:purple_terracotta
fill 527 267 228 527 269 228 minecraft:purple_terracotta
fill 527 267 270 527 269 270 minecraft:purple_terracotta
setblock 529 267 270 minecraft:purple_terracotta
fill 531 267 228 531 269 228 minecraft:purple_terracotta
fill 531 267 270 531 269 270 minecraft:purple_terracotta
fill 535 267 228 535 269 228 minecraft:purple_terracotta
fill 535 267 270 535 269 270 minecraft:purple_terracotta
fill 537 267 230 538 267 230 minecraft:spruce_planks
fill 539 267 228 539 269 228 minecraft:purple_terracotta
fill 539 267 229 540 267 230 minecraft:dark_oak_planks
fill 539 267 270 539 269 270 minecraft:purple_terracotta
fill 543 267 228 543 269 228 minecraft:purple_terracotta
fill 543 267 270 543 269 270 minecraft:purple_terracotta
fill 547 267 228 547 269 228 minecraft:purple_terracotta
fill 547 267 270 547 269 270 minecraft:purple_terracotta
fill 551 267 228 551 269 228 minecraft:purple_terracotta
fill 551 267 270 551 269 270 minecraft:purple_terracotta
fill 555 267 228 555 269 228 minecraft:purple_terracotta
fill 555 267 270 555 269 270 minecraft:purple_terracotta
setblock 559 267 228 minecraft:purple_terracotta
fill 559 267 230 559 269 230 minecraft:purple_terracotta
fill 559 267 234 559 269 234 minecraft:purple_terracotta
fill 559 267 238 559 269 238 minecraft:purple_terracotta
fill 559 267 242 559 269 242 minecraft:purple_terracotta
fill 559 267 246 559 269 246 minecraft:purple_terracotta
fill 559 267 250 559 269 250 minecraft:purple_terracotta
fill 559 267 254 559 269 254 minecraft:purple_terracotta
fill 559 267 258 559 269 258 minecraft:purple_terracotta
fill 559 267 262 559 269 262 minecraft:purple_terracotta
fill 559 267 266 559 269 266 minecraft:purple_terracotta
fill 559 267 270 559 269 270 minecraft:purple_terracotta
setblock 517 268 228 minecraft:magenta_terracotta
setblock 517 268 232 minecraft:magenta_terracotta
setblock 517 268 236 minecraft:magenta_terracotta
setblock 517 268 240 minecraft:magenta_terracotta
setblock 517 268 244 minecraft:magenta_terracotta
setblock 517 268 248 minecraft:magenta_terracotta
setblock 517 268 252 minecraft:magenta_terracotta
setblock 517 268 256 minecraft:magenta_terracotta
setblock 517 268 260 minecraft:magenta_terracotta
setblock 517 268 264 minecraft:magenta_terracotta
setblock 517 268 268 minecraft:magenta_terracotta
setblock 517 268 270 minecraft:magenta_terracotta
setblock 521 268 228 minecraft:magenta_terracotta
setblock 521 268 270 minecraft:magenta_terracotta
setblock 525 268 228 minecraft:magenta_terracotta
setblock 525 268 270 minecraft:magenta_terracotta
setblock 529 268 228 minecraft:magenta_terracotta
setblock 529 268 270 minecraft:magenta_terracotta
setblock 533 268 228 minecraft:magenta_terracotta
setblock 533 268 270 minecraft:magenta_terracotta
fill 535 268 230 536 268 230 minecraft:spruce_planks
setblock 537 268 228 minecraft:magenta_terracotta
fill 537 268 229 538 268 230 minecraft:dark_oak_planks
setblock 537 268 270 minecraft:magenta_terracotta
setblock 541 268 228 minecraft:magenta_terracotta
setblock 541 268 270 minecraft:magenta_terracotta
setblock 545 268 228 minecraft:magenta_terracotta
setblock 545 268 270 minecraft:magenta_terracotta
setblock 549 268 228 minecraft:magenta_terracotta
setblock 549 268 270 minecraft:magenta_terracotta
setblock 553 268 228 minecraft:magenta_terracotta
setblock 553 268 270 minecraft:magenta_terracotta
setblock 557 268 228 minecraft:magenta_terracotta
setblock 557 268 270 minecraft:magenta_terracotta
setblock 559 268 228 minecraft:magenta_terracotta
setblock 559 268 232 minecraft:magenta_terracotta
setblock 559 268 236 minecraft:magenta_terracotta
setblock 559 268 240 minecraft:magenta_terracotta
setblock 559 268 244 minecraft:magenta_terracotta
setblock 559 268 248 minecraft:magenta_terracotta
setblock 559 268 252 minecraft:magenta_terracotta
setblock 559 268 256 minecraft:magenta_terracotta
setblock 559 268 260 minecraft:magenta_terracotta
setblock 559 268 264 minecraft:magenta_terracotta
setblock 559 268 268 minecraft:magenta_terracotta
fill 517 269 228 517 271 228 minecraft:purple_terracotta
fill 517 269 232 517 271 232 minecraft:purple_terracotta
fill 517 269 236 517 271 236 minecraft:purple_terracotta
fill 517 269 240 517 271 240 minecraft:purple_terracotta
fill 517 269 244 517 271 244 minecraft:purple_terracotta
fill 517 269 248 517 271 248 minecraft:purple_terracotta
setblock 517 269 252 minecraft:light_gray_terracotta
fill 517 269 256 517 271 256 minecraft:purple_terracotta
fill 517 269 260 517 271 260 minecraft:purple_terracotta
fill 517 269 264 517 271 264 minecraft:purple_terracotta
fill 517 269 268 517 271 268 minecraft:purple_terracotta
setblock 517 269 270 minecraft:purple_terracotta
fill 518 269 229 518 271 229 minecraft:dark_oak_planks
fill 518 269 230 518 270 268 minecraft:deepslate_tiles
fill 518 269 269 518 271 269 minecraft:dark_oak_planks
fill 519 269 229 534 269 229 minecraft:deepslate_tiles
fill 519 269 269 557 270 269 minecraft:deepslate_tiles
fill 521 269 228 521 271 228 minecraft:purple_terracotta
fill 521 269 270 521 271 270 minecraft:purple_terracotta
fill 525 269 228 525 271 228 minecraft:purple_terracotta
fill 525 269 270 525 271 270 minecraft:purple_terracotta
fill 529 269 228 529 271 228 minecraft:purple_terracotta
fill 529 269 270 529 271 270 minecraft:purple_terracotta
fill 533 269 228 533 271 228 minecraft:purple_terracotta
fill 533 269 230 534 269 230 minecraft:spruce_planks
fill 533 269 270 533 271 270 minecraft:purple_terracotta
fill 535 269 229 536 269 230 minecraft:dark_oak_planks
fill 537 269 228 537 271 228 minecraft:purple_terracotta
fill 537 269 229 557 270 229 minecraft:deepslate_tiles
fill 537 269 270 537 271 270 minecraft:purple_terracotta
fill 541 269 228 541 271 228 minecraft:purple_terracotta
fill 541 269 270 541 271 270 minecraft:purple_terracotta
fill 545 269 228 545 271 228 minecraft:purple_terracotta
fill 545 269 270 545 271 270 minecraft:purple_terracotta
fill 549 269 228 549 271 228 minecraft:purple_terracotta
fill 549 269 270 549 271 270 minecraft:purple_terracotta
fill 553 269 228 553 271 228 minecraft:purple_terracotta
fill 553 269 270 553 271 270 minecraft:purple_terracotta
fill 557 269 228 557 271 228 minecraft:purple_terracotta
fill 557 269 270 557 271 270 minecraft:purple_terracotta
fill 558 269 229 558 271 229 minecraft:dark_oak_planks
fill 558 269 230 558 270 268 minecraft:deepslate_tiles
fill 558 269 269 558 271 269 minecraft:dark_oak_planks
setblock 559 269 228 minecraft:purple_terracotta
fill 559 269 232 559 271 232 minecraft:purple_terracotta
fill 559 269 236 559 271 236 minecraft:purple_terracotta
fill 559 269 240 559 271 240 minecraft:purple_terracotta
fill 559 269 244 559 271 244 minecraft:purple_terracotta
fill 559 269 248 559 271 248 minecraft:purple_terracotta
fill 559 269 252 559 271 252 minecraft:purple_terracotta
fill 559 269 256 559 271 256 minecraft:purple_terracotta
fill 559 269 260 559 271 260 minecraft:purple_terracotta
fill 559 269 264 559 271 264 minecraft:purple_terracotta
fill 559 269 268 559 271 268 minecraft:purple_terracotta
setblock 517 270 230 minecraft:magenta_terracotta
setblock 517 270 234 minecraft:magenta_terracotta
setblock 517 270 238 minecraft:magenta_terracotta
setblock 517 270 242 minecraft:magenta_terracotta
setblock 517 270 246 minecraft:magenta_terracotta
setblock 517 270 250 minecraft:magenta_terracotta
fill 517 270 252 517 271 252 minecraft:purple_terracotta
setblock 517 270 254 minecraft:magenta_terracotta
setblock 517 270 258 minecraft:magenta_terracotta
setblock 517 270 262 minecraft:magenta_terracotta
setblock 517 270 266 minecraft:magenta_terracotta
setblock 517 270 270 minecraft:magenta_terracotta
setblock 519 270 228 minecraft:magenta_terracotta
fill 519 270 229 532 270 229 minecraft:deepslate_tiles
fill 519 270 230 519 272 230 minecraft:dark_oak_planks
fill 519 270 231 519 271 267 minecraft:deepslate_tiles
fill 519 270 268 519 272 268 minecraft:dark_oak_planks
setblock 519 270 270 minecraft:magenta_terracotta
fill 520 270 230 530 270 230 minecraft:deepslate_tiles
fill 520 270 268 556 271 268 minecraft:deepslate_tiles
setblock 523 270 228 minecraft:magenta_terracotta
setblock 523 270 270 minecraft:magenta_terracotta
setblock 527 270 228 minecraft:magenta_terracotta
setblock 527 270 270 minecraft:magenta_terracotta
setblock 531 270 228 minecraft:magenta_terracotta
fill 531 270 230 532 270 230 minecraft:spruce_planks
setblock 531 270 270 minecraft:magenta_terracotta
fill 533 270 229 534 270 230 minecraft:dark_oak_planks
setblock 535 270 228 minecraft:magenta_terracotta
fill 535 270 229 536 270 230 minecraft:deepslate_tiles
setblock 535 270 270 minecraft:magenta_terracotta
fill 537 270 230 556 271 230 minecraft:deepslate_tiles
setblock 539 270 228 minecraft:magenta_terracotta
setblock 539 270 270 minecraft:magenta_terracotta
setblock 543 270 228 minecraft:magenta_terracotta
setblock 543 270 270 minecraft:magenta_terracotta
setblock 547 270 228 minecraft:magenta_terracotta
setblock 547 270 270 minecraft:magenta_terracotta
setblock 551 270 228 minecraft:magenta_terracotta
setblock 551 270 270 minecraft:magenta_terracotta
setblock 555 270 228 minecraft:magenta_terracotta
setblock 555 270 270 minecraft:magenta_terracotta
fill 557 270 230 557 272 230 minecraft:dark_oak_planks
fill 557 270 231 557 271 267 minecraft:deepslate_tiles
fill 557 270 268 557 272 268 minecraft:dark_oak_planks
setblock 559 270 228 minecraft:magenta_terracotta
setblock 559 270 230 minecraft:magenta_terracotta
setblock 559 270 234 minecraft:magenta_terracotta
setblock 559 270 238 minecraft:magenta_terracotta
setblock 559 270 242 minecraft:magenta_terracotta
setblock 559 270 246 minecraft:magenta_terracotta
setblock 559 270 250 minecraft:magenta_terracotta
setblock 559 270 254 minecraft:magenta_terracotta
setblock 559 270 258 minecraft:magenta_terracotta
setblock 559 270 262 minecraft:magenta_terracotta
setblock 559 270 266 minecraft:magenta_terracotta
setblock 559 270 270 minecraft:magenta_terracotta
fill 517 271 230 517 273 230 minecraft:purple_terracotta
fill 517 271 234 517 273 234 minecraft:purple_terracotta
fill 517 271 238 517 273 238 minecraft:purple_terracotta
fill 517 271 242 517 273 242 minecraft:purple_terracotta
fill 517 271 246 517 273 246 minecraft:purple_terracotta
fill 517 271 250 517 273 250 minecraft:purple_terracotta
fill 517 271 254 517 273 254 minecraft:purple_terracotta
fill 517 271 258 517 273 258 minecraft:purple_terracotta
fill 517 271 262 517 273 262 minecraft:purple_terracotta
fill 517 271 266 517 273 266 minecraft:purple_terracotta
setblock 517 271 270 minecraft:purple_terracotta
fill 518 271 230 518 271 268 minecraft:polished_deepslate
fill 519 271 228 519 273 228 minecraft:purple_terracotta
fill 519 271 229 530 271 229 minecraft:polished_deepslate
fill 519 271 269 557 271 269 minecraft:polished_deepslate
fill 519 271 270 519 273 270 minecraft:purple_terracotta
fill 520 271 230 528 271 230 minecraft:deepslate_tiles
fill 520 271 231 520 273 231 minecraft:dark_oak_planks
fill 520 271 232 520 272 266 minecraft:deepslate_tiles
fill 520 271 267 520 273 267 minecraft:dark_oak_planks
fill 521 271 231 555 272 231 minecraft:deepslate_tiles
fill 521 271 232 521 273 232 minecraft:dark_oak_planks
fill 521 271 233 521 271 265 minecraft:polished_deepslate
fill 521 271 266 521 273 266 minecraft:dark_oak_planks
fill 521 271 267 555 272 267 minecraft:deepslate_tiles
fill 522 271 232 554 271 232 minecraft:polished_deepslate
fill 522 271 266 554 271 266 minecraft:polished_deepslate
fill 523 271 228 523 273 228 minecraft:purple_terracotta
fill 523 271 270 523 273 270 minecraft:purple_terracotta
fill 527 271 228 527 273 228 minecraft:purple_terracotta
setblock 527 271 238 minecraft:light[level=12]
setblock 527 271 245 minecraft:light[level=12]
setblock 527 271 252 minecraft:light[level=12]
setblock 527 271 259 minecraft:light[level=12]
fill 527 271 270 527 273 270 minecraft:purple_terracotta
fill 529 271 230 530 271 230 minecraft:spruce_planks
fill 531 271 228 531 273 228 minecraft:purple_terracotta
fill 531 271 229 532 271 230 minecraft:dark_oak_planks
fill 531 271 270 531 273 270 minecraft:purple_terracotta
fill 533 271 229 557 271 229 minecraft:polished_deepslate
fill 533 271 230 536 271 230 minecraft:deepslate_tiles
setblock 534 271 238 minecraft:light[level=12]
setblock 534 271 245 minecraft:light[level=12]
setblock 534 271 252 minecraft:light[level=12]
setblock 534 271 259 minecraft:light[level=12]
fill 535 271 228 535 273 228 minecraft:purple_terracotta
fill 535 271 270 535 273 270 minecraft:purple_terracotta
fill 539 271 228 539 273 228 minecraft:purple_terracotta
fill 539 271 270 539 273 270 minecraft:purple_terracotta
setblock 541 271 238 minecraft:light[level=12]
setblock 541 271 245 minecraft:light[level=12]
setblock 541 271 259 minecraft:light[level=12]
fill 543 271 228 543 273 228 minecraft:purple_terracotta
fill 543 271 270 543 273 270 minecraft:purple_terracotta
fill 547 271 228 547 273 228 minecraft:purple_terracotta
fill 547 271 270 547 273 270 minecraft:purple_terracotta
setblock 548 271 238 minecraft:light[level=12]
setblock 548 271 245 minecraft:light[level=12]
setblock 548 271 252 minecraft:light[level=12]
setblock 548 271 259 minecraft:light[level=12]
fill 551 271 228 551 273 228 minecraft:purple_terracotta
fill 551 271 270 551 273 270 minecraft:purple_terracotta
fill 555 271 228 555 273 228 minecraft:purple_terracotta
fill 555 271 232 555 273 232 minecraft:dark_oak_planks
fill 555 271 233 555 271 265 minecraft:polished_deepslate
fill 555 271 266 555 273 266 minecraft:dark_oak_planks
fill 555 271 270 555 273 270 minecraft:purple_terracotta
fill 556 271 231 556 273 231 minecraft:dark_oak_planks
fill 556 271 232 556 272 266 minecraft:deepslate_tiles
fill 556 271 267 556 273 267 minecraft:dark_oak_planks
fill 558 271 230 558 271 268 minecraft:polished_deepslate
setblock 559 271 228 minecraft:purple_terracotta
fill 559 271 230 559 273 230 minecraft:purple_terracotta
fill 559 271 234 559 273 234 minecraft:purple_terracotta
fill 559 271 238 559 273 238 minecraft:purple_terracotta
fill 559 271 242 559 273 242 minecraft:purple_terracotta
fill 559 271 246 559 273 246 minecraft:purple_terracotta
fill 559 271 250 559 273 250 minecraft:purple_terracotta
fill 559 271 254 559 273 254 minecraft:purple_terracotta
fill 559 271 258 559 273 258 minecraft:purple_terracotta
fill 559 271 262 559 273 262 minecraft:purple_terracotta
fill 559 271 266 559 273 266 minecraft:purple_terracotta
fill 559 271 270 559 273 270 minecraft:purple_terracotta
setblock 517 272 228 minecraft:magenta_terracotta
setblock 517 272 232 minecraft:magenta_terracotta
setblock 517 272 236 minecraft:magenta_terracotta
setblock 517 272 240 minecraft:magenta_terracotta
setblock 517 272 244 minecraft:magenta_terracotta
setblock 517 272 248 minecraft:magenta_terracotta
setblock 517 272 252 minecraft:magenta_terracotta
setblock 517 272 256 minecraft:magenta_terracotta
setblock 517 272 260 minecraft:magenta_terracotta
setblock 517 272 264 minecraft:magenta_terracotta
setblock 517 272 268 minecraft:magenta_terracotta
setblock 517 272 270 minecraft:magenta_terracotta
fill 519 272 231 519 272 267 minecraft:polished_deepslate
fill 520 272 230 526 272 230 minecraft:polished_deepslate
fill 520 272 268 556 272 268 minecraft:polished_deepslate
setblock 521 272 228 minecraft:magenta_terracotta
fill 521 272 233 521 273 265 minecraft:deepslate_tiles
setblock 521 272 270 minecraft:magenta_terracotta
fill 522 272 232 554 273 232 minecraft:deepslate_tiles
fill 522 272 233 522 274 233 minecraft:dark_oak_planks
fill 522 272 234 522 272 264 minecraft:polished_deepslate
fill 522 272 265 522 274 265 minecraft:dark_oak_planks
fill 522 272 266 554 273 266 minecraft:deepslate_tiles
fill 523 272 233 553 272 233 minecraft:polished_deepslate
fill 523 272 265 553 272 265 minecraft:polished_deepslate
setblock 525 272 228 minecraft:magenta_terracotta
setblock 525 272 270 minecraft:magenta_terracotta
fill 527 272 230 528 272 230 minecraft:spruce_planks
setblock 529 272 228 minecraft:magenta_terracotta
fill 529 272 229 530 272 230 minecraft:dark_oak_planks
setblock 529 272 270 minecraft:magenta_terracotta
fill 531 272 230 556 272 230 minecraft:polished_deepslate
setblock 533 272 228 minecraft:magenta_terracotta
setblock 533 272 270 minecraft:magenta_terracotta
setblock 537 272 228 minecraft:magenta_terracotta
setblock 537 272 270 minecraft:magenta_terracotta
setblock 541 272 228 minecraft:magenta_terracotta
setblock 541 272 270 minecraft:magenta_terracotta
setblock 545 272 228 minecraft:magenta_terracotta
setblock 545 272 270 minecraft:magenta_terracotta
setblock 549 272 228 minecraft:magenta_terracotta
setblock 549 272 270 minecraft:magenta_terracotta
setblock 553 272 228 minecraft:magenta_terracotta
setblock 553 272 270 minecraft:magenta_terracotta
fill 554 272 233 554 274 233 minecraft:dark_oak_planks
fill 554 272 234 554 272 264 minecraft:polished_deepslate
fill 554 272 265 554 274 265 minecraft:dark_oak_planks
fill 555 272 233 555 273 265 minecraft:deepslate_tiles
setblock 557 272 228 minecraft:magenta_terracotta
fill 557 272 231 557 272 267 minecraft:polished_deepslate
setblock 557 272 270 minecraft:magenta_terracotta
setblock 559 272 228 minecraft:magenta_terracotta
setblock 559 272 232 minecraft:magenta_terracotta
setblock 559 272 236 minecraft:magenta_terracotta
setblock 559 272 240 minecraft:magenta_terracotta
setblock 559 272 244 minecraft:magenta_terracotta
setblock 559 272 248 minecraft:magenta_terracotta
setblock 559 272 252 minecraft:magenta_terracotta
setblock 559 272 256 minecraft:magenta_terracotta
setblock 559 272 260 minecraft:magenta_terracotta
setblock 559 272 264 minecraft:magenta_terracotta
setblock 559 272 268 minecraft:magenta_terracotta
fill 517 273 228 517 275 228 minecraft:purple_terracotta
fill 517 273 232 517 275 232 minecraft:purple_terracotta
fill 517 273 236 517 275 236 minecraft:purple_terracotta
setblock 517 273 240 minecraft:black_terracotta
fill 517 273 244 517 275 244 minecraft:purple_terracotta
fill 517 273 248 517 275 248 minecraft:purple_terracotta
fill 517 273 252 517 275 252 minecraft:purple_terracotta
fill 517 273 256 517 275 256 minecraft:purple_terracotta
fill 517 273 260 517 275 260 minecraft:purple_terracotta
fill 517 273 264 517 275 264 minecraft:purple_terracotta
fill 517 273 268 517 275 268 minecraft:purple_terracotta
setblock 517 273 270 minecraft:purple_terracotta
fill 520 273 232 520 273 266 minecraft:polished_deepslate
fill 521 273 228 521 275 228 minecraft:purple_terracotta
fill 521 273 231 555 273 231 minecraft:polished_deepslate
fill 521 273 267 555 273 267 minecraft:polished_deepslate
fill 521 273 270 521 275 270 minecraft:purple_terracotta
fill 522 273 234 522 274 264 minecraft:deepslate_tiles
fill 523 273 233 553 274 233 minecraft:deepslate_tiles
fill 523 273 234 523 275 234 minecraft:dark_oak_planks
fill 523 273 235 523 273 263 minecraft:polished_deepslate
fill 523 273 264 523 275 264 minecraft:dark_oak_planks
fill 523 273 265 553 274 265 minecraft:deepslate_tiles
fill 524 273 234 552 273 234 minecraft:polished_deepslate
fill 524 273 264 552 273 264 minecraft:polished_deepslate
fill 525 273 228 525 275 228 minecraft:purple_terracotta
fill 525 273 230 526 273 230 minecraft:spruce_planks
fill 525 273 270 525 275 270 minecraft:purple_terracotta
fill 527 273 229 528 273 230 minecraft:dark_oak_planks
setblock 528 273 239 minecraft:light[level=11]
setblock 528 273 247 minecraft:light[level=11]
setblock 528 273 255 minecraft:light[level=11]
setblock 528 273 263 minecraft:light[level=11]
fill 529 273 228 529 275 228 minecraft:purple_terracotta
fill 529 273 270 529 275 270 minecraft:purple_terracotta
fill 533 273 228 533 275 228 minecraft:purple_terracotta
fill 533 273 270 533 275 270 minecraft:purple_terracotta
setblock 536 273 239 minecraft:light[level=11]
setblock 536 273 247 minecraft:light[level=11]
setblock 536 273 255 minecraft:light[level=11]
setblock 536 273 263 minecraft:light[level=11]
fill 537 273 228 537 275 228 minecraft:purple_terracotta
fill 537 273 270 537 275 270 minecraft:purple_terracotta
fill 541 273 228 541 275 228 minecraft:purple_terracotta
fill 541 273 270 541 275 270 minecraft:purple_terracotta
setblock 544 273 239 minecraft:light[level=11]
setblock 544 273 247 minecraft:light[level=11]
schedule function dropper:buildpart/59_5 1t
