fill 230 53 583 230 65 584 minecraft:white_concrete
fill 230 53 595 230 65 596 minecraft:white_concrete
fill 191 54 576 191 54 579 minecraft:quartz_block
fill 192 54 570 192 54 572 minecraft:gold_block
fill 192 54 573 192 54 575 minecraft:quartz_block
fill 192 54 580 192 54 582 minecraft:quartz_block
fill 192 54 583 192 54 585 minecraft:gold_block
fill 192 55 573 192 55 582 minecraft:gold_block
fill 227 57 589 227 71 589 minecraft:red_wool
fill 227 58 587 227 71 588 minecraft:red_wool
fill 227 58 590 227 71 591 minecraft:red_wool
setblock 191 59 560 minecraft:light[level=14]
setblock 191 59 568 minecraft:light[level=14]
setblock 191 59 576 minecraft:light[level=14]
setblock 191 59 584 minecraft:light[level=14]
setblock 191 59 592 minecraft:light[level=14]
setblock 199 59 560 minecraft:light[level=14]
setblock 199 59 568 minecraft:light[level=14]
setblock 199 59 576 minecraft:light[level=14]
setblock 199 59 584 minecraft:light[level=14]
setblock 199 59 592 minecraft:light[level=14]
setblock 207 59 560 minecraft:light[level=14]
setblock 207 59 568 minecraft:light[level=14]
setblock 207 59 576 minecraft:light[level=14]
setblock 207 59 584 minecraft:light[level=14]
setblock 207 59 592 minecraft:light[level=14]
setblock 215 59 560 minecraft:light[level=14]
setblock 215 59 568 minecraft:light[level=14]
setblock 215 59 576 minecraft:light[level=14]
setblock 215 59 584 minecraft:light[level=14]
setblock 215 59 592 minecraft:light[level=14]
setblock 223 59 560 minecraft:light[level=14]
setblock 223 59 568 minecraft:light[level=14]
setblock 223 59 576 minecraft:light[level=14]
setblock 223 59 584 minecraft:light[level=14]
setblock 223 59 592 minecraft:light[level=14]
fill 190 60 567 190 65 569 minecraft:quartz_block
fill 190 60 579 190 65 581 minecraft:quartz_block
fill 190 60 591 190 65 593 minecraft:quartz_block
fill 196 60 597 198 65 597 minecraft:quartz_block
fill 200 60 559 202 65 559 minecraft:quartz_block
fill 208 60 597 210 65 597 minecraft:quartz_block
fill 212 60 559 214 65 559 minecraft:quartz_block
fill 220 60 597 222 65 597 minecraft:quartz_block
fill 224 60 559 226 65 559 minecraft:quartz_block
fill 228 60 567 228 65 569 minecraft:quartz_block
fill 228 60 579 228 65 581 minecraft:quartz_block
fill 228 60 591 228 65 593 minecraft:quartz_block
fill 203 61 596 209 62 596 minecraft:gold_block
fill 202 63 573 202 64 574 minecraft:gold_block
fill 189 65 561 189 65 566 minecraft:yellow_terracotta
fill 189 65 573 189 65 578 minecraft:yellow_terracotta
fill 189 65 585 189 65 590 minecraft:yellow_terracotta
fill 189 65 597 189 65 598 minecraft:yellow_terracotta
fill 190 65 598 193 65 598 minecraft:yellow_terracotta
fill 193 65 558 198 65 558 minecraft:yellow_terracotta
fill 200 65 598 205 65 598 minecraft:yellow_terracotta
fill 205 65 558 210 65 558 minecraft:yellow_terracotta
fill 212 65 598 217 65 598 minecraft:yellow_terracotta
fill 217 65 558 222 65 558 minecraft:yellow_terracotta
fill 224 65 598 229 65 598 minecraft:yellow_terracotta
fill 229 65 558 229 65 563 minecraft:yellow_terracotta
fill 229 65 570 229 65 575 minecraft:yellow_terracotta
fill 229 65 582 229 65 587 minecraft:yellow_terracotta
fill 229 65 594 229 65 597 minecraft:yellow_terracotta
fill 188 66 563 188 71 566 minecraft:ochre_froglight
fill 188 66 575 188 71 578 minecraft:ochre_froglight
fill 188 66 587 188 71 590 minecraft:ochre_froglight
fill 188 66 599 191 71 599 minecraft:ochre_froglight
fill 195 66 557 198 71 557 minecraft:ochre_froglight
fill 200 66 599 203 71 599 minecraft:ochre_froglight
fill 207 66 557 210 71 557 minecraft:ochre_froglight
fill 212 66 599 215 71 599 minecraft:ochre_froglight
fill 219 66 557 222 71 557 minecraft:ochre_froglight
fill 224 66 599 227 71 599 minecraft:ochre_froglight
fill 230 66 558 230 71 561 minecraft:ochre_froglight
fill 230 66 570 230 71 573 minecraft:ochre_froglight
fill 230 66 582 230 71 585 minecraft:ochre_froglight
fill 230 66 594 230 71 597 minecraft:ochre_froglight
setblock 191 67 560 minecraft:light[level=14]
setblock 191 67 568 minecraft:light[level=14]
setblock 191 67 576 minecraft:light[level=14]
setblock 191 67 584 minecraft:light[level=14]
setblock 191 67 592 minecraft:light[level=14]
setblock 199 67 560 minecraft:light[level=14]
setblock 199 67 568 minecraft:light[level=14]
setblock 199 67 576 minecraft:light[level=14]
setblock 199 67 584 minecraft:light[level=14]
setblock 199 67 592 minecraft:light[level=14]
setblock 207 67 560 minecraft:light[level=14]
setblock 207 67 568 minecraft:light[level=14]
setblock 207 67 576 minecraft:light[level=14]
setblock 207 67 584 minecraft:light[level=14]
setblock 207 67 592 minecraft:light[level=14]
setblock 215 67 560 minecraft:light[level=14]
setblock 215 67 568 minecraft:light[level=14]
setblock 215 67 576 minecraft:light[level=14]
setblock 215 67 584 minecraft:light[level=14]
setblock 215 67 592 minecraft:light[level=14]
setblock 223 67 560 minecraft:light[level=14]
setblock 223 67 568 minecraft:light[level=14]
setblock 223 67 576 minecraft:light[level=14]
setblock 223 67 584 minecraft:light[level=14]
setblock 223 67 592 minecraft:light[level=14]
fill 188 72 563 188 87 563 minecraft:white_concrete
fill 188 72 564 188 72 565 minecraft:ochre_froglight
fill 188 72 566 188 87 566 minecraft:white_concrete
fill 188 72 575 188 87 575 minecraft:white_concrete
fill 188 72 576 188 72 577 minecraft:ochre_froglight
fill 188 72 578 188 87 578 minecraft:white_concrete
fill 188 72 587 188 87 587 minecraft:white_concrete
fill 188 72 588 188 72 589 minecraft:ochre_froglight
fill 188 72 590 188 87 590 minecraft:white_concrete
fill 188 72 599 188 87 599 minecraft:white_concrete
fill 189 72 599 190 72 599 minecraft:ochre_froglight
fill 191 72 599 191 87 599 minecraft:white_concrete
fill 195 72 557 195 87 557 minecraft:white_concrete
fill 196 72 557 197 72 557 minecraft:ochre_froglight
fill 198 72 557 198 87 557 minecraft:white_concrete
fill 200 72 599 200 87 599 minecraft:white_concrete
fill 201 72 599 202 72 599 minecraft:ochre_froglight
fill 203 72 599 203 87 599 minecraft:white_concrete
fill 207 72 557 207 87 557 minecraft:white_concrete
fill 208 72 557 209 72 557 minecraft:ochre_froglight
fill 210 72 557 210 87 557 minecraft:white_concrete
fill 212 72 599 212 87 599 minecraft:white_concrete
fill 213 72 599 214 72 599 minecraft:ochre_froglight
fill 215 72 599 215 87 599 minecraft:white_concrete
fill 219 72 557 219 87 557 minecraft:white_concrete
fill 220 72 557 221 72 557 minecraft:ochre_froglight
fill 222 72 557 222 87 557 minecraft:white_concrete
fill 224 72 599 224 87 599 minecraft:white_concrete
fill 225 72 599 226 72 599 minecraft:ochre_froglight
fill 227 72 586 227 73 592 minecraft:gold_block
fill 227 72 599 227 87 599 minecraft:white_concrete
fill 230 72 558 230 87 558 minecraft:white_concrete
fill 230 72 559 230 72 560 minecraft:ochre_froglight
fill 230 72 561 230 87 561 minecraft:white_concrete
fill 230 72 570 230 87 570 minecraft:white_concrete
fill 230 72 571 230 72 572 minecraft:ochre_froglight
fill 230 72 573 230 87 573 minecraft:white_concrete
fill 230 72 582 230 87 582 minecraft:white_concrete
fill 230 72 583 230 72 584 minecraft:ochre_froglight
fill 230 72 585 230 87 585 minecraft:white_concrete
fill 230 72 594 230 87 594 minecraft:white_concrete
fill 230 72 595 230 72 596 minecraft:ochre_froglight
fill 230 72 597 230 87 597 minecraft:white_concrete
fill 188 73 564 188 87 565 minecraft:white_concrete
fill 188 73 576 188 87 577 minecraft:white_concrete
fill 188 73 588 188 87 589 minecraft:white_concrete
fill 189 73 599 190 87 599 minecraft:white_concrete
fill 196 73 557 197 87 557 minecraft:white_concrete
fill 200 73 563 200 74 563 minecraft:gold_block
fill 201 73 599 202 87 599 minecraft:white_concrete
fill 208 73 557 209 87 557 minecraft:white_concrete
fill 213 73 599 214 87 599 minecraft:white_concrete
fill 220 73 557 221 87 557 minecraft:white_concrete
fill 225 73 599 226 87 599 minecraft:white_concrete
fill 230 73 559 230 87 560 minecraft:white_concrete
fill 230 73 571 230 87 572 minecraft:white_concrete
fill 230 73 583 230 87 584 minecraft:white_concrete
fill 230 73 595 230 87 596 minecraft:white_concrete
setblock 191 75 560 minecraft:light[level=14]
setblock 191 75 568 minecraft:light[level=14]
setblock 191 75 576 minecraft:light[level=14]
setblock 191 75 584 minecraft:light[level=14]
setblock 191 75 592 minecraft:light[level=14]
setblock 199 75 560 minecraft:light[level=14]
setblock 199 75 568 minecraft:light[level=14]
setblock 199 75 576 minecraft:light[level=14]
setblock 199 75 584 minecraft:light[level=14]
setblock 199 75 592 minecraft:light[level=14]
setblock 207 75 560 minecraft:light[level=14]
setblock 207 75 568 minecraft:light[level=14]
setblock 207 75 576 minecraft:light[level=14]
setblock 207 75 584 minecraft:light[level=14]
setblock 207 75 592 minecraft:light[level=14]
setblock 215 75 560 minecraft:light[level=14]
setblock 215 75 568 minecraft:light[level=14]
setblock 215 75 576 minecraft:light[level=14]
setblock 215 75 584 minecraft:light[level=14]
setblock 215 75 592 minecraft:light[level=14]
setblock 223 75 560 minecraft:light[level=14]
setblock 223 75 568 minecraft:light[level=14]
setblock 223 75 576 minecraft:light[level=14]
setblock 223 75 584 minecraft:light[level=14]
setblock 223 75 592 minecraft:light[level=14]
fill 224 75 577 225 76 578 minecraft:gold_block
setblock 203 82 578 minecraft:gold_block
fill 204 82 574 206 82 576 minecraft:redstone_block
fill 204 82 580 206 82 582 minecraft:redstone_block
setblock 209 82 572 minecraft:gold_block
setblock 209 82 584 minecraft:gold_block
fill 211 82 573 213 82 575 minecraft:redstone_block
fill 211 82 581 213 82 583 minecraft:redstone_block
setblock 215 82 578 minecraft:gold_block
setblock 191 83 560 minecraft:light[level=14]
setblock 191 83 568 minecraft:light[level=14]
setblock 191 83 576 minecraft:light[level=14]
setblock 191 83 584 minecraft:light[level=14]
setblock 191 83 592 minecraft:light[level=14]
setblock 199 83 560 minecraft:light[level=14]
setblock 199 83 568 minecraft:light[level=14]
setblock 199 83 576 minecraft:light[level=14]
setblock 199 83 584 minecraft:light[level=14]
setblock 199 83 592 minecraft:light[level=14]
fill 202 83 575 202 85 581 minecraft:gold_block
fill 203 83 574 203 83 577 minecraft:gold_block
fill 203 83 578 207 83 578 minecraft:quartz_block
fill 203 83 579 203 83 582 minecraft:gold_block
fill 204 83 573 205 83 573 minecraft:gold_block
fill 204 83 577 207 83 577 minecraft:quartz_block
fill 204 83 579 207 83 579 minecraft:quartz_block
fill 204 83 583 205 83 583 minecraft:gold_block
fill 205 83 572 208 85 572 minecraft:gold_block
fill 205 83 584 208 85 584 minecraft:gold_block
fill 206 83 571 212 85 571 minecraft:gold_block
fill 206 83 573 210 83 573 minecraft:quartz_block
fill 206 83 583 210 83 583 minecraft:quartz_block
fill 206 83 585 212 85 585 minecraft:gold_block
setblock 207 83 560 minecraft:light[level=14]
setblock 207 83 568 minecraft:light[level=14]
fill 207 83 574 210 83 576 minecraft:quartz_block
fill 207 83 580 210 83 582 minecraft:quartz_block
setblock 207 83 592 minecraft:light[level=14]
fill 209 83 572 209 84 572 minecraft:quartz_block
fill 209 83 584 209 84 584 minecraft:quartz_block
fill 210 83 572 213 83 572 minecraft:gold_block
fill 210 83 584 213 83 584 minecraft:gold_block
fill 211 83 576 214 83 580 minecraft:quartz_block
fill 214 83 573 214 83 574 minecraft:gold_block
setblock 214 83 575 minecraft:quartz_block
setblock 214 83 581 minecraft:quartz_block
fill 214 83 582 214 83 583 minecraft:gold_block
setblock 215 83 560 minecraft:light[level=14]
setblock 215 83 568 minecraft:light[level=14]
fill 215 83 574 215 85 577 minecraft:gold_block
fill 215 83 578 215 84 578 minecraft:quartz_block
fill 215 83 579 215 85 582 minecraft:gold_block
setblock 215 83 584 minecraft:light[level=14]
setblock 215 83 592 minecraft:light[level=14]
fill 216 83 575 216 85 581 minecraft:gold_block
setblock 223 83 560 minecraft:light[level=14]
setblock 223 83 568 minecraft:light[level=14]
setblock 223 83 576 minecraft:light[level=14]
setblock 223 83 584 minecraft:light[level=14]
setblock 223 83 592 minecraft:light[level=14]
fill 189 84 558 201 84 598 minecraft:gold_block
fill 202 84 558 202 84 574 minecraft:gold_block
fill 202 84 582 202 84 598 minecraft:gold_block
fill 203 84 558 204 84 572 minecraft:gold_block
fill 203 84 573 203 84 577 minecraft:ochre_froglight
fill 203 84 578 206 84 578 minecraft:quartz_block
fill 203 84 579 203 84 583 minecraft:ochre_froglight
fill 203 84 584 204 84 598 minecraft:gold_block
fill 204 84 573 207 84 573 minecraft:ochre_froglight
fill 204 84 574 206 84 576 minecraft:gold_block
fill 204 84 577 207 84 577 minecraft:ochre_froglight
fill 204 84 579 207 84 579 minecraft:ochre_froglight
fill 204 84 580 206 84 582 minecraft:gold_block
fill 204 84 583 207 84 583 minecraft:ochre_froglight
fill 205 84 558 205 84 571 minecraft:gold_block
fill 205 84 585 205 84 598 minecraft:gold_block
fill 206 84 558 229 84 570 minecraft:gold_block
fill 206 84 586 229 84 598 minecraft:gold_block
fill 207 84 574 207 84 576 minecraft:ochre_froglight
setblock 207 84 578 minecraft:ochre_froglight
fill 207 84 580 207 84 582 minecraft:ochre_froglight
fill 208 84 573 209 84 575 minecraft:quartz_block
fill 208 84 576 214 84 576 minecraft:ochre_froglight
fill 208 84 580 214 84 580 minecraft:ochre_froglight
fill 208 84 581 209 84 583 minecraft:quartz_block
fill 210 84 572 210 84 575 minecraft:ochre_froglight
fill 210 84 581 210 84 584 minecraft:ochre_froglight
fill 211 84 572 214 84 572 minecraft:ochre_froglight
fill 211 84 573 213 84 575 minecraft:gold_block
fill 211 84 577 211 84 579 minecraft:ochre_froglight
fill 211 84 581 213 84 583 minecraft:gold_block
fill 211 84 584 214 84 584 minecraft:ochre_froglight
fill 212 84 577 214 84 579 minecraft:quartz_block
fill 213 84 571 229 84 571 minecraft:gold_block
fill 213 84 585 229 84 585 minecraft:gold_block
fill 214 84 573 214 84 575 minecraft:ochre_froglight
fill 214 84 581 214 84 583 minecraft:ochre_froglight
fill 215 84 572 229 84 573 minecraft:gold_block
fill 215 84 583 229 84 584 minecraft:gold_block
fill 216 84 574 229 84 574 minecraft:gold_block
fill 216 84 582 229 84 582 minecraft:gold_block
fill 217 84 575 229 84 581 minecraft:gold_block
fill 203 85 574 204 85 582 minecraft:gold_block
fill 204 85 573 214 85 573 minecraft:gold_block
fill 204 85 583 214 85 583 minecraft:gold_block
fill 205 85 574 205 85 576 minecraft:gold_block
fill 205 85 580 205 85 582 minecraft:gold_block
fill 206 85 574 207 85 574 minecraft:gold_block
fill 206 85 582 207 85 582 minecraft:gold_block
fill 209 85 572 213 85 572 minecraft:gold_block
fill 209 85 584 213 85 584 minecraft:gold_block
fill 211 85 574 214 85 574 minecraft:gold_block
fill 211 85 582 214 85 582 minecraft:gold_block
fill 213 85 575 214 85 576 minecraft:gold_block
fill 213 85 580 214 85 581 minecraft:gold_block
fill 214 85 577 214 85 579 minecraft:gold_block
fill 215 85 578 215 86 578 minecraft:gold_block
setblock 203 86 578 minecraft:gold_block
setblock 209 86 572 minecraft:gold_block
setblock 209 86 584 minecraft:gold_block
fill 188 88 563 188 91 566 minecraft:ochre_froglight
fill 188 88 575 188 91 578 minecraft:ochre_froglight
fill 188 88 587 188 91 590 minecraft:ochre_froglight
fill 188 88 599 191 91 599 minecraft:ochre_froglight
fill 189 88 558 191 154 558 minecraft:quartz_block
fill 189 88 568 189 154 570 minecraft:quartz_block
fill 189 88 580 189 154 582 minecraft:quartz_block
fill 189 88 592 189 154 594 minecraft:quartz_block
fill 190 88 561 190 88 563 minecraft:yellow_terracotta
fill 191 88 560 193 88 560 minecraft:yellow_terracotta
fill 191 88 561 193 154 563 minecraft:quartz_block
fill 191 88 564 193 88 564 minecraft:yellow_terracotta
fill 192 88 592 192 88 593 minecraft:yellow_terracotta
fill 192 88 594 195 154 594 minecraft:quartz_block
setblock 192 88 595 minecraft:yellow_terracotta
fill 193 88 592 195 88 592 minecraft:yellow_terracotta
fill 193 88 593 195 154 593 minecraft:quartz_block
fill 193 88 595 194 154 595 minecraft:quartz_block
fill 193 88 596 194 88 596 minecraft:yellow_terracotta
fill 194 88 561 194 88 563 minecraft:yellow_terracotta
fill 195 88 557 198 91 557 minecraft:ochre_froglight
setblock 195 88 595 minecraft:yellow_terracotta
fill 195 88 598 197 154 598 minecraft:quartz_block
fill 196 88 593 196 88 594 minecraft:yellow_terracotta
fill 200 88 590 201 89 592 minecraft:gold_block
fill 200 88 599 203 91 599 minecraft:ochre_froglight
fill 201 88 558 203 154 558 minecraft:quartz_block
fill 207 88 557 210 91 557 minecraft:ochre_froglight
fill 207 88 598 209 154 598 minecraft:quartz_block
fill 212 88 599 215 91 599 minecraft:ochre_froglight
fill 213 88 558 215 154 558 minecraft:quartz_block
fill 219 88 557 222 91 557 minecraft:ochre_froglight
fill 219 88 598 221 154 598 minecraft:quartz_block
fill 222 88 593 222 88 594 minecraft:yellow_terracotta
setblock 223 88 592 minecraft:yellow_terracotta
fill 223 88 593 225 154 594 minecraft:quartz_block
setblock 223 88 595 minecraft:yellow_terracotta
fill 224 88 591 225 88 591 minecraft:yellow_terracotta
fill 224 88 592 225 154 592 minecraft:quartz_block
fill 224 88 595 224 154 595 minecraft:quartz_block
fill 224 88 599 227 91 599 minecraft:ochre_froglight
fill 225 88 558 227 154 558 minecraft:quartz_block
fill 225 88 595 226 88 595 minecraft:yellow_terracotta
setblock 226 88 592 minecraft:yellow_terracotta
fill 226 88 593 226 154 593 minecraft:quartz_block
setblock 226 88 594 minecraft:yellow_terracotta
fill 229 88 566 229 154 568 minecraft:quartz_block
fill 229 88 578 229 154 580 minecraft:quartz_block
fill 229 88 590 229 154 592 minecraft:quartz_block
fill 230 88 558 230 91 561 minecraft:ochre_froglight
fill 230 88 570 230 91 573 minecraft:ochre_froglight
fill 230 88 582 230 91 585 minecraft:ochre_froglight
fill 230 88 594 230 91 597 minecraft:ochre_froglight
setblock 188 89 557 minecraft:white_concrete
setblock 188 89 558 minecraft:yellow_terracotta
fill 188 89 559 188 92 562 minecraft:white_concrete
fill 188 89 567 188 90 568 minecraft:white_concrete
setblock 188 89 569 minecraft:yellow_terracotta
fill 188 89 570 188 92 574 minecraft:white_concrete
setblock 188 89 591 minecraft:yellow_terracotta
fill 188 89 592 188 89 596 minecraft:white_concrete
setblock 188 89 597 minecraft:yellow_terracotta
fill 188 89 598 188 92 598 minecraft:white_concrete
fill 199 89 557 203 89 557 minecraft:white_concrete
setblock 204 89 557 minecraft:yellow_terracotta
fill 204 89 599 206 90 599 minecraft:white_concrete
fill 205 89 557 206 92 557 minecraft:white_concrete
setblock 207 89 599 minecraft:yellow_terracotta
fill 208 89 599 211 92 599 minecraft:white_concrete
fill 211 89 557 211 93 557 minecraft:white_concrete
setblock 212 89 557 minecraft:yellow_terracotta
fill 213 89 557 218 89 557 minecraft:white_concrete
setblock 223 89 557 minecraft:yellow_terracotta
fill 224 89 557 230 89 557 minecraft:white_concrete
setblock 228 89 599 minecraft:yellow_terracotta
fill 229 89 599 229 93 599 minecraft:white_concrete
fill 230 89 562 230 89 567 minecraft:white_concrete
setblock 230 89 568 minecraft:yellow_terracotta
fill 230 89 569 230 92 569 minecraft:white_concrete
fill 230 89 574 230 92 575 minecraft:white_concrete
setblock 230 89 576 minecraft:yellow_terracotta
fill 230 89 577 230 92 577 minecraft:white_concrete
setblock 230 89 578 minecraft:yellow_terracotta
fill 230 89 579 230 92 581 minecraft:white_concrete
fill 230 89 586 230 92 589 minecraft:white_concrete
setblock 230 89 590 minecraft:yellow_terracotta
fill 230 89 591 230 90 593 minecraft:white_concrete
setblock 230 89 599 minecraft:yellow_terracotta
setblock 188 90 557 minecraft:yellow_terracotta
fill 188 90 558 188 92 558 minecraft:white_concrete
fill 188 90 569 188 93 569 minecraft:white_concrete
fill 188 90 591 188 92 592 minecraft:white_concrete
fill 188 90 593 188 91 593 minecraft:yellow_terracotta
setblock 188 90 594 minecraft:white_concrete
setblock 188 90 595 minecraft:yellow_terracotta
fill 188 90 596 188 92 597 minecraft:white_concrete
setblock 199 90 557 minecraft:yellow_terracotta
fill 200 90 557 204 92 557 minecraft:white_concrete
fill 207 90 599 207 92 599 minecraft:white_concrete
fill 212 90 557 215 90 557 minecraft:white_concrete
fill 216 90 557 217 90 557 minecraft:yellow_terracotta
fill 216 90 599 219 92 599 minecraft:white_concrete
fill 218 90 557 218 92 557 minecraft:white_concrete
setblock 220 90 599 minecraft:yellow_terracotta
fill 221 90 599 223 90 599 minecraft:white_concrete
fill 223 90 557 225 92 557 minecraft:white_concrete
setblock 226 90 557 minecraft:yellow_terracotta
fill 227 90 557 230 92 557 minecraft:white_concrete
fill 228 90 599 228 92 599 minecraft:white_concrete
fill 230 90 562 230 90 566 minecraft:white_concrete
setblock 230 90 567 minecraft:yellow_terracotta
fill 230 90 568 230 92 568 minecraft:white_concrete
fill 230 90 576 230 92 576 minecraft:white_concrete
setblock 230 90 578 minecraft:white_concrete
fill 230 90 590 230 93 590 minecraft:white_concrete
setblock 230 90 599 minecraft:white_concrete
fill 188 91 557 190 92 557 minecraft:white_concrete
setblock 188 91 567 minecraft:yellow_terracotta
fill 188 91 568 188 92 568 minecraft:white_concrete
setblock 188 91 579 minecraft:yellow_terracotta
fill 188 91 580 188 92 581 minecraft:white_concrete
setblock 188 91 582 minecraft:yellow_terracotta
fill 188 91 583 188 92 583 minecraft:white_concrete
setblock 188 91 584 minecraft:yellow_terracotta
fill 188 91 585 188 92 586 minecraft:white_concrete
setblock 188 91 594 minecraft:yellow_terracotta
fill 188 91 595 188 92 595 minecraft:white_concrete
setblock 191 91 557 minecraft:yellow_terracotta
setblock 191 91 560 minecraft:light[level=14]
setblock 191 91 568 minecraft:light[level=14]
setblock 191 91 576 minecraft:light[level=14]
setblock 191 91 584 minecraft:light[level=14]
setblock 191 91 592 minecraft:light[level=14]
fill 192 91 557 194 92 557 minecraft:white_concrete
fill 199 91 557 199 92 557 minecraft:white_concrete
setblock 199 91 560 minecraft:light[level=14]
setblock 199 91 568 minecraft:light[level=14]
setblock 199 91 576 minecraft:light[level=14]
setblock 199 91 584 minecraft:light[level=14]
setblock 199 91 592 minecraft:light[level=14]
fill 204 91 599 204 92 599 minecraft:white_concrete
setblock 205 91 599 minecraft:yellow_terracotta
fill 206 91 599 206 92 599 minecraft:white_concrete
setblock 207 91 560 minecraft:light[level=14]
setblock 207 91 568 minecraft:light[level=14]
setblock 207 91 576 minecraft:light[level=14]
setblock 207 91 584 minecraft:light[level=14]
setblock 207 91 592 minecraft:light[level=14]
setblock 212 91 557 minecraft:yellow_terracotta
fill 213 91 557 217 92 557 minecraft:white_concrete
setblock 215 91 560 minecraft:light[level=14]
setblock 215 91 568 minecraft:light[level=14]
setblock 215 91 576 minecraft:light[level=14]
setblock 215 91 584 minecraft:light[level=14]
setblock 215 91 592 minecraft:light[level=14]
fill 220 91 599 221 92 599 minecraft:white_concrete
setblock 222 91 599 minecraft:yellow_terracotta
setblock 223 91 560 minecraft:light[level=14]
setblock 223 91 568 minecraft:light[level=14]
setblock 223 91 576 minecraft:light[level=14]
setblock 223 91 584 minecraft:light[level=14]
setblock 223 91 592 minecraft:light[level=14]
fill 223 91 599 223 92 599 minecraft:white_concrete
fill 226 91 557 226 92 557 minecraft:white_concrete
fill 230 91 562 230 92 563 minecraft:white_concrete
fill 230 91 564 230 91 565 minecraft:yellow_terracotta
fill 230 91 566 230 92 567 minecraft:white_concrete
setblock 230 91 578 minecraft:yellow_terracotta
fill 230 91 591 230 92 592 minecraft:white_concrete
setblock 230 91 593 minecraft:yellow_terracotta
setblock 230 91 599 minecraft:yellow_terracotta
setblock 188 92 563 minecraft:white_concrete
fill 188 92 564 188 92 565 minecraft:ochre_froglight
fill 188 92 566 188 92 567 minecraft:white_concrete
setblock 188 92 575 minecraft:white_concrete
fill 188 92 576 188 92 577 minecraft:ochre_froglight
fill 188 92 578 188 92 579 minecraft:white_concrete
setblock 188 92 582 minecraft:white_concrete
setblock 188 92 584 minecraft:white_concrete
setblock 188 92 587 minecraft:white_concrete
fill 188 92 588 188 92 589 minecraft:ochre_froglight
setblock 188 92 590 minecraft:white_concrete
fill 188 92 593 188 92 594 minecraft:white_concrete
setblock 188 92 599 minecraft:white_concrete
fill 189 92 599 190 92 599 minecraft:ochre_froglight
fill 191 92 557 191 93 557 minecraft:white_concrete
setblock 191 92 599 minecraft:white_concrete
setblock 195 92 557 minecraft:white_concrete
fill 196 92 557 197 92 557 minecraft:ochre_froglight
setblock 198 92 557 minecraft:white_concrete
setblock 200 92 599 minecraft:white_concrete
fill 201 92 599 202 92 599 minecraft:ochre_froglight
setblock 203 92 599 minecraft:white_concrete
setblock 205 92 599 minecraft:white_concrete
setblock 207 92 557 minecraft:white_concrete
fill 208 92 557 209 92 557 minecraft:ochre_froglight
setblock 210 92 557 minecraft:white_concrete
setblock 212 92 557 minecraft:white_concrete
setblock 212 92 599 minecraft:white_concrete
fill 213 92 599 214 92 599 minecraft:ochre_froglight
setblock 215 92 599 minecraft:white_concrete
setblock 219 92 557 minecraft:white_concrete
fill 220 92 557 221 92 557 minecraft:ochre_froglight
setblock 222 92 557 minecraft:white_concrete
setblock 222 92 599 minecraft:white_concrete
setblock 224 92 599 minecraft:white_concrete
fill 225 92 599 226 92 599 minecraft:ochre_froglight
setblock 227 92 599 minecraft:white_concrete
setblock 230 92 558 minecraft:white_concrete
fill 230 92 559 230 92 560 minecraft:ochre_froglight
setblock 230 92 561 minecraft:white_concrete
fill 230 92 564 230 92 565 minecraft:white_concrete
setblock 230 92 570 minecraft:white_concrete
fill 230 92 571 230 92 572 minecraft:ochre_froglight
setblock 230 92 573 minecraft:white_concrete
setblock 230 92 578 minecraft:white_concrete
setblock 230 92 582 minecraft:white_concrete
fill 230 92 583 230 92 584 minecraft:ochre_froglight
setblock 230 92 585 minecraft:white_concrete
fill 230 92 593 230 92 594 minecraft:white_concrete
fill 230 92 595 230 92 596 minecraft:ochre_froglight
setblock 230 92 597 minecraft:white_concrete
setblock 230 92 599 minecraft:white_concrete
fill 188 93 557 188 93 568 minecraft:yellow_terracotta
fill 188 93 570 188 93 578 minecraft:yellow_terracotta
setblock 188 93 579 minecraft:white_concrete
fill 188 93 580 188 94 596 minecraft:yellow_terracotta
setblock 188 93 597 minecraft:white_concrete
fill 188 93 598 188 105 599 minecraft:yellow_terracotta
fill 189 93 557 190 94 557 minecraft:yellow_terracotta
setblock 189 93 599 minecraft:white_concrete
fill 190 93 599 220 93 599 minecraft:yellow_terracotta
fill 192 93 557 192 94 557 minecraft:white_concrete
fill 193 93 557 202 93 557 minecraft:yellow_terracotta
setblock 203 93 557 minecraft:white_concrete
fill 204 93 557 210 93 557 minecraft:yellow_terracotta
fill 212 93 557 228 93 557 minecraft:yellow_terracotta
setblock 221 93 599 minecraft:white_concrete
fill 222 93 599 225 93 599 minecraft:yellow_terracotta
setblock 226 93 599 minecraft:white_concrete
fill 227 93 599 228 94 599 minecraft:yellow_terracotta
setblock 229 93 557 minecraft:white_concrete
fill 230 93 557 230 93 570 minecraft:yellow_terracotta
fill 230 93 571 230 94 571 minecraft:white_concrete
fill 230 93 572 230 93 589 minecraft:yellow_terracotta
fill 230 93 591 230 93 599 minecraft:yellow_terracotta
fill 188 94 557 188 197 560 minecraft:yellow_terracotta
setblock 188 94 561 minecraft:white_concrete
fill 188 94 562 188 105 566 minecraft:yellow_terracotta
setblock 188 94 567 minecraft:white_concrete
fill 188 94 568 188 200 571 minecraft:yellow_terracotta
setblock 188 94 572 minecraft:white_concrete
fill 188 94 573 188 94 575 minecraft:yellow_terracotta
setblock 188 94 576 minecraft:white_concrete
fill 188 94 577 188 105 579 minecraft:yellow_terracotta
fill 188 94 597 188 197 597 minecraft:yellow_terracotta
fill 189 94 599 191 105 599 minecraft:yellow_terracotta
fill 191 94 557 191 200 557 minecraft:yellow_terracotta
setblock 192 94 599 minecraft:white_concrete
fill 193 94 557 193 197 557 minecraft:yellow_terracotta
fill 193 94 599 199 94 599 minecraft:yellow_terracotta
setblock 194 94 557 minecraft:white_concrete
fill 195 94 557 205 94 557 minecraft:yellow_terracotta
setblock 200 94 599 minecraft:white_concrete
fill 201 94 599 214 94 599 minecraft:yellow_terracotta
setblock 206 94 557 minecraft:white_concrete
fill 207 94 557 222 94 557 minecraft:yellow_terracotta
setblock 215 94 599 minecraft:white_concrete
fill 216 94 599 221 196 599 minecraft:yellow_terracotta
setblock 222 94 599 minecraft:white_concrete
setblock 223 94 557 minecraft:white_concrete
fill 223 94 599 223 201 599 minecraft:yellow_terracotta
fill 224 94 557 230 94 557 minecraft:yellow_terracotta
setblock 224 94 599 minecraft:white_concrete
fill 225 94 599 226 94 599 minecraft:yellow_terracotta
fill 229 94 599 229 200 599 minecraft:yellow_terracotta
fill 230 94 558 230 105 562 minecraft:yellow_terracotta
setblock 230 94 563 minecraft:white_concrete
fill 230 94 564 230 197 569 minecraft:yellow_terracotta
setblock 230 94 570 minecraft:white_concrete
setblock 230 94 572 minecraft:white_concrete
fill 230 94 573 230 94 583 minecraft:yellow_terracotta
fill 230 94 584 230 95 584 minecraft:white_concrete
fill 230 94 585 230 105 598 minecraft:yellow_terracotta
setblock 230 94 599 minecraft:white_concrete
fill 188 95 561 188 200 561 minecraft:yellow_terracotta
fill 188 95 567 188 198 567 minecraft:yellow_terracotta
fill 188 95 572 188 200 573 minecraft:yellow_terracotta
setblock 188 95 574 minecraft:white_concrete
fill 188 95 575 188 105 576 minecraft:yellow_terracotta
fill 188 95 580 188 197 582 minecraft:yellow_terracotta
fill 188 95 583 188 95 584 minecraft:white_concrete
fill 188 95 585 188 105 587 minecraft:yellow_terracotta
setblock 188 95 588 minecraft:white_concrete
fill 188 95 589 188 105 596 minecraft:yellow_terracotta
setblock 189 95 557 minecraft:white_concrete
fill 190 95 557 190 196 557 minecraft:yellow_terracotta
fill 192 95 557 192 200 557 minecraft:yellow_terracotta
fill 192 95 599 194 200 599 minecraft:yellow_terracotta
fill 194 95 557 201 105 557 minecraft:yellow_terracotta
setblock 195 95 599 minecraft:white_concrete
fill 196 95 599 196 200 599 minecraft:yellow_terracotta
setblock 197 95 599 minecraft:white_concrete
fill 198 95 599 198 198 599 minecraft:yellow_terracotta
setblock 199 95 599 minecraft:white_concrete
fill 200 95 599 205 105 599 minecraft:yellow_terracotta
setblock 202 95 557 minecraft:white_concrete
fill 202 95 585 203 96 586 minecraft:gold_block
fill 203 95 557 204 200 557 minecraft:yellow_terracotta
setblock 205 95 557 minecraft:white_concrete
fill 205 95 565 205 96 565 minecraft:raw_gold_block
fill 206 95 557 210 105 557 minecraft:yellow_terracotta
setblock 206 95 599 minecraft:white_concrete
fill 207 95 599 215 105 599 minecraft:yellow_terracotta
setblock 211 95 557 minecraft:white_concrete
fill 212 95 557 214 196 557 minecraft:yellow_terracotta
setblock 215 95 557 minecraft:white_concrete
fill 216 95 557 217 200 557 minecraft:yellow_terracotta
setblock 218 95 557 minecraft:white_concrete
fill 219 95 557 225 105 557 minecraft:yellow_terracotta
fill 222 95 599 222 197 599 minecraft:yellow_terracotta
fill 224 95 599 224 105 599 minecraft:yellow_terracotta
setblock 225 95 599 minecraft:white_concrete
setblock 226 95 557 minecraft:white_concrete
fill 226 95 599 226 105 599 minecraft:yellow_terracotta
fill 227 95 557 228 196 557 minecraft:yellow_terracotta
setblock 227 95 599 minecraft:white_concrete
fill 228 95 599 228 200 599 minecraft:yellow_terracotta
setblock 229 95 557 minecraft:white_concrete
fill 230 95 557 230 200 557 minecraft:yellow_terracotta
fill 230 95 563 230 200 563 minecraft:yellow_terracotta
fill 230 95 570 230 105 572 minecraft:yellow_terracotta
setblock 230 95 573 minecraft:white_concrete
fill 230 95 574 230 105 583 minecraft:yellow_terracotta
fill 230 95 599 230 200 599 minecraft:yellow_terracotta
fill 188 96 574 188 200 574 minecraft:yellow_terracotta
fill 188 96 583 188 200 584 minecraft:yellow_terracotta
fill 188 96 588 188 105 588 minecraft:yellow_terracotta
fill 189 96 557 189 201 557 minecraft:yellow_terracotta
fill 190 96 561 190 96 563 minecraft:yellow_terracotta
fill 191 96 560 193 96 560 minecraft:yellow_terracotta
fill 191 96 564 193 96 564 minecraft:yellow_terracotta
fill 192 96 592 192 96 593 minecraft:yellow_terracotta
setblock 192 96 595 minecraft:yellow_terracotta
fill 193 96 592 195 96 592 minecraft:yellow_terracotta
fill 193 96 596 194 96 596 minecraft:yellow_terracotta
fill 194 96 561 194 96 563 minecraft:yellow_terracotta
setblock 195 96 595 minecraft:yellow_terracotta
fill 195 96 599 195 200 599 minecraft:yellow_terracotta
fill 196 96 593 196 96 594 minecraft:yellow_terracotta
fill 197 96 599 197 196 599 minecraft:yellow_terracotta
fill 199 96 599 199 200 599 minecraft:yellow_terracotta
fill 202 96 557 202 200 557 minecraft:yellow_terracotta
fill 205 96 557 205 200 557 minecraft:yellow_terracotta
fill 206 96 599 206 196 599 minecraft:yellow_terracotta
fill 211 96 557 211 200 557 minecraft:yellow_terracotta
fill 215 96 557 215 200 557 minecraft:yellow_terracotta
fill 218 96 557 218 197 557 minecraft:yellow_terracotta
fill 222 96 593 222 96 594 minecraft:yellow_terracotta
setblock 223 96 592 minecraft:yellow_terracotta
setblock 223 96 595 minecraft:yellow_terracotta
fill 224 96 591 225 96 591 minecraft:yellow_terracotta
fill 225 96 595 226 96 595 minecraft:yellow_terracotta
fill 225 96 599 225 105 599 minecraft:yellow_terracotta
fill 226 96 557 226 200 557 minecraft:yellow_terracotta
setblock 226 96 592 minecraft:yellow_terracotta
setblock 226 96 594 minecraft:yellow_terracotta
fill 227 96 599 227 105 599 minecraft:yellow_terracotta
fill 229 96 557 229 200 557 minecraft:yellow_terracotta
fill 230 96 573 230 105 573 minecraft:yellow_terracotta
fill 230 96 584 230 105 584 minecraft:yellow_terracotta
fill 198 97 582 198 98 583 minecraft:gold_block
setblock 191 99 560 minecraft:light[level=14]
setblock 191 99 568 minecraft:light[level=14]
setblock 191 99 576 minecraft:light[level=14]
setblock 191 99 584 minecraft:light[level=14]
setblock 191 99 592 minecraft:light[level=14]
setblock 199 99 560 minecraft:light[level=14]
setblock 199 99 568 minecraft:light[level=14]
setblock 199 99 576 minecraft:light[level=14]
setblock 199 99 584 minecraft:light[level=14]
setblock 199 99 592 minecraft:light[level=14]
setblock 207 99 560 minecraft:light[level=14]
setblock 207 99 568 minecraft:light[level=14]
setblock 207 99 576 minecraft:light[level=14]
setblock 207 99 584 minecraft:light[level=14]
setblock 207 99 592 minecraft:light[level=14]
setblock 215 99 560 minecraft:light[level=14]
setblock 215 99 568 minecraft:light[level=14]
setblock 215 99 576 minecraft:light[level=14]
setblock 215 99 584 minecraft:light[level=14]
setblock 215 99 592 minecraft:light[level=14]
setblock 223 99 560 minecraft:light[level=14]
setblock 223 99 568 minecraft:light[level=14]
setblock 223 99 576 minecraft:light[level=14]
setblock 223 99 584 minecraft:light[level=14]
setblock 223 99 592 minecraft:light[level=14]
fill 190 100 567 190 105 569 minecraft:quartz_block
fill 190 100 579 190 105 581 minecraft:quartz_block
fill 190 100 591 190 105 593 minecraft:quartz_block
fill 196 100 597 198 105 597 minecraft:quartz_block
fill 200 100 559 202 105 559 minecraft:quartz_block
fill 208 100 597 210 105 597 minecraft:quartz_block
fill 212 100 559 214 105 559 minecraft:quartz_block
fill 220 100 597 222 105 597 minecraft:quartz_block
fill 224 100 559 226 105 559 minecraft:quartz_block
fill 228 100 567 228 105 569 minecraft:quartz_block
fill 228 100 579 228 105 581 minecraft:quartz_block
fill 228 100 591 228 105 593 minecraft:quartz_block
fill 190 104 561 190 104 563 minecraft:yellow_terracotta
fill 191 104 560 193 104 560 minecraft:yellow_terracotta
fill 191 104 564 193 104 564 minecraft:yellow_terracotta
fill 192 104 592 192 104 593 minecraft:yellow_terracotta
setblock 192 104 595 minecraft:yellow_terracotta
fill 193 104 592 195 104 592 minecraft:yellow_terracotta
fill 193 104 596 194 104 596 minecraft:yellow_terracotta
fill 194 104 561 194 104 563 minecraft:yellow_terracotta
setblock 195 104 595 minecraft:yellow_terracotta
fill 196 104 593 196 104 594 minecraft:yellow_terracotta
fill 222 104 593 222 104 594 minecraft:yellow_terracotta
setblock 223 104 592 minecraft:yellow_terracotta
setblock 223 104 595 minecraft:yellow_terracotta
fill 224 104 591 225 104 591 minecraft:yellow_terracotta
fill 225 104 595 226 104 595 minecraft:yellow_terracotta
setblock 226 104 592 minecraft:yellow_terracotta
setblock 226 104 594 minecraft:yellow_terracotta
fill 189 105 561 189 105 566 minecraft:yellow_terracotta
fill 189 105 573 189 105 578 minecraft:yellow_terracotta
fill 189 105 585 189 105 590 minecraft:yellow_terracotta
fill 189 105 597 189 105 598 minecraft:yellow_terracotta
fill 190 105 598 193 105 598 minecraft:yellow_terracotta
fill 193 105 558 198 105 558 minecraft:yellow_terracotta
fill 200 105 598 205 105 598 minecraft:yellow_terracotta
fill 205 105 558 210 105 558 minecraft:yellow_terracotta
fill 212 105 598 217 105 598 minecraft:yellow_terracotta
fill 217 105 558 222 105 558 minecraft:yellow_terracotta
fill 224 105 598 229 105 598 minecraft:yellow_terracotta
fill 229 105 558 229 105 563 minecraft:yellow_terracotta
fill 229 105 570 229 105 575 minecraft:yellow_terracotta
fill 229 105 582 229 105 587 minecraft:yellow_terracotta
fill 229 105 594 229 105 597 minecraft:yellow_terracotta
fill 188 106 562 188 200 562 minecraft:yellow_terracotta
fill 188 106 563 188 111 566 minecraft:ochre_froglight
fill 188 106 575 188 111 578 minecraft:ochre_froglight
fill 188 106 579 188 200 579 minecraft:yellow_terracotta
fill 188 106 585 188 196 586 minecraft:yellow_terracotta
fill 188 106 587 188 111 590 minecraft:ochre_froglight
fill 188 106 591 188 196 596 minecraft:yellow_terracotta
fill 188 106 598 188 197 598 minecraft:yellow_terracotta
fill 188 106 599 191 111 599 minecraft:ochre_froglight
fill 194 106 557 194 200 557 minecraft:yellow_terracotta
fill 195 106 557 198 111 557 minecraft:ochre_froglight
fill 199 106 557 201 197 557 minecraft:yellow_terracotta
fill 200 106 599 203 111 599 minecraft:ochre_froglight
fill 204 106 599 205 200 599 minecraft:yellow_terracotta
fill 206 106 557 206 200 557 minecraft:yellow_terracotta
fill 207 106 557 210 111 557 minecraft:ochre_froglight
fill 207 106 599 211 198 599 minecraft:yellow_terracotta
fill 212 106 599 215 111 599 minecraft:ochre_froglight
fill 219 106 557 222 111 557 minecraft:ochre_froglight
fill 223 106 557 225 198 557 minecraft:yellow_terracotta
fill 224 106 599 227 111 599 minecraft:ochre_froglight
fill 230 106 558 230 111 561 minecraft:ochre_froglight
fill 230 106 562 230 197 562 minecraft:yellow_terracotta
fill 230 106 570 230 111 573 minecraft:ochre_froglight
fill 230 106 574 230 197 581 minecraft:yellow_terracotta
fill 230 106 582 230 111 585 minecraft:ochre_froglight
fill 230 106 586 230 197 593 minecraft:yellow_terracotta
fill 230 106 594 230 111 597 minecraft:ochre_froglight
fill 230 106 598 230 201 598 minecraft:yellow_terracotta
setblock 191 107 560 minecraft:light[level=14]
setblock 191 107 568 minecraft:light[level=14]
setblock 191 107 576 minecraft:light[level=14]
setblock 191 107 584 minecraft:light[level=14]
setblock 191 107 592 minecraft:light[level=14]
setblock 199 107 560 minecraft:light[level=14]
setblock 199 107 568 minecraft:light[level=14]
setblock 199 107 576 minecraft:light[level=14]
setblock 199 107 584 minecraft:light[level=14]
setblock 199 107 592 minecraft:light[level=14]
setblock 207 107 560 minecraft:light[level=14]
setblock 207 107 568 minecraft:light[level=14]
setblock 207 107 576 minecraft:light[level=14]
setblock 207 107 584 minecraft:light[level=14]
setblock 207 107 592 minecraft:light[level=14]
setblock 215 107 560 minecraft:light[level=14]
setblock 215 107 568 minecraft:light[level=14]
setblock 215 107 576 minecraft:light[level=14]
setblock 215 107 584 minecraft:light[level=14]
setblock 215 107 592 minecraft:light[level=14]
setblock 223 107 560 minecraft:light[level=14]
setblock 223 107 568 minecraft:light[level=14]
setblock 223 107 576 minecraft:light[level=14]
setblock 223 107 584 minecraft:light[level=14]
setblock 223 107 592 minecraft:light[level=14]
fill 201 108 578 201 109 578 minecraft:gold_block
fill 188 112 563 188 125 563 minecraft:yellow_terracotta
fill 188 112 564 188 112 565 minecraft:ochre_froglight
fill 188 112 566 188 125 566 minecraft:yellow_terracotta
fill 188 112 575 188 125 575 minecraft:yellow_terracotta
fill 188 112 576 188 112 577 minecraft:ochre_froglight
fill 188 112 578 188 125 578 minecraft:yellow_terracotta
fill 188 112 587 188 125 587 minecraft:yellow_terracotta
fill 188 112 588 188 112 589 minecraft:ochre_froglight
fill 188 112 590 188 125 590 minecraft:yellow_terracotta
fill 188 112 599 188 125 599 minecraft:yellow_terracotta
fill 189 112 599 190 112 599 minecraft:ochre_froglight
fill 190 112 561 190 112 563 minecraft:yellow_terracotta
fill 191 112 560 193 112 560 minecraft:yellow_terracotta
fill 191 112 564 193 112 564 minecraft:yellow_terracotta
fill 191 112 599 191 125 599 minecraft:yellow_terracotta
fill 192 112 592 192 112 593 minecraft:yellow_terracotta
setblock 192 112 595 minecraft:yellow_terracotta
fill 193 112 592 195 112 592 minecraft:yellow_terracotta
fill 193 112 596 194 112 596 minecraft:yellow_terracotta
fill 194 112 561 194 112 563 minecraft:yellow_terracotta
fill 195 112 557 195 125 557 minecraft:yellow_terracotta
setblock 195 112 595 minecraft:yellow_terracotta
fill 196 112 557 197 112 557 minecraft:ochre_froglight
fill 196 112 593 196 112 594 minecraft:yellow_terracotta
fill 198 112 557 198 125 557 minecraft:yellow_terracotta
fill 200 112 599 200 125 599 minecraft:yellow_terracotta
fill 201 112 599 202 112 599 minecraft:ochre_froglight
fill 203 112 599 203 125 599 minecraft:yellow_terracotta
fill 207 112 557 207 125 557 minecraft:yellow_terracotta
fill 208 112 557 209 112 557 minecraft:ochre_froglight
fill 210 112 557 210 125 557 minecraft:yellow_terracotta
fill 212 112 599 212 125 599 minecraft:yellow_terracotta
fill 213 112 599 214 112 599 minecraft:ochre_froglight
fill 215 112 599 215 125 599 minecraft:yellow_terracotta
fill 219 112 557 219 125 557 minecraft:yellow_terracotta
fill 220 112 557 221 112 557 minecraft:ochre_froglight
fill 222 112 557 222 125 557 minecraft:yellow_terracotta
fill 222 112 593 222 112 594 minecraft:yellow_terracotta
setblock 223 112 592 minecraft:yellow_terracotta
setblock 223 112 595 minecraft:yellow_terracotta
fill 224 112 591 225 112 591 minecraft:yellow_terracotta
fill 224 112 599 224 125 599 minecraft:yellow_terracotta
fill 225 112 595 226 112 595 minecraft:yellow_terracotta
fill 225 112 599 226 112 599 minecraft:ochre_froglight
setblock 226 112 592 minecraft:yellow_terracotta
setblock 226 112 594 minecraft:yellow_terracotta
fill 227 112 599 227 125 599 minecraft:yellow_terracotta
fill 230 112 558 230 125 558 minecraft:yellow_terracotta
fill 230 112 559 230 112 560 minecraft:ochre_froglight
fill 230 112 561 230 125 561 minecraft:yellow_terracotta
fill 230 112 570 230 125 570 minecraft:yellow_terracotta
fill 230 112 571 230 112 572 minecraft:ochre_froglight
fill 230 112 573 230 125 573 minecraft:yellow_terracotta
fill 230 112 582 230 125 582 minecraft:yellow_terracotta
fill 230 112 583 230 112 584 minecraft:ochre_froglight
fill 230 112 585 230 125 585 minecraft:yellow_terracotta
fill 230 112 594 230 125 594 minecraft:yellow_terracotta
fill 230 112 595 230 112 596 minecraft:ochre_froglight
fill 230 112 597 230 125 597 minecraft:yellow_terracotta
fill 188 113 564 188 125 565 minecraft:yellow_terracotta
fill 188 113 576 188 125 577 minecraft:yellow_terracotta
fill 188 113 588 188 125 589 minecraft:yellow_terracotta
fill 189 113 599 190 125 599 minecraft:yellow_terracotta
fill 196 113 557 197 125 557 minecraft:yellow_terracotta
fill 201 113 599 202 125 599 minecraft:yellow_terracotta
fill 208 113 557 209 125 557 minecraft:yellow_terracotta
fill 213 113 599 214 125 599 minecraft:yellow_terracotta
fill 220 113 557 221 125 557 minecraft:yellow_terracotta
fill 225 113 599 226 125 599 minecraft:yellow_terracotta
fill 230 113 559 230 125 560 minecraft:yellow_terracotta
fill 230 113 571 230 125 572 minecraft:yellow_terracotta
fill 230 113 583 230 125 584 minecraft:yellow_terracotta
fill 230 113 595 230 125 596 minecraft:yellow_terracotta
setblock 191 115 560 minecraft:light[level=14]
setblock 191 115 568 minecraft:light[level=14]
setblock 191 115 576 minecraft:light[level=14]
setblock 191 115 584 minecraft:light[level=14]
setblock 191 115 592 minecraft:light[level=14]
setblock 199 115 560 minecraft:light[level=14]
setblock 199 115 568 minecraft:light[level=14]
setblock 199 115 576 minecraft:light[level=14]
setblock 199 115 584 minecraft:light[level=14]
setblock 199 115 592 minecraft:light[level=14]
setblock 207 115 560 minecraft:light[level=14]
setblock 207 115 568 minecraft:light[level=14]
setblock 207 115 576 minecraft:light[level=14]
setblock 207 115 584 minecraft:light[level=14]
setblock 207 115 592 minecraft:light[level=14]
setblock 215 115 560 minecraft:light[level=14]
setblock 215 115 568 minecraft:light[level=14]
setblock 215 115 576 minecraft:light[level=14]
setblock 215 115 584 minecraft:light[level=14]
setblock 215 115 592 minecraft:light[level=14]
setblock 223 115 560 minecraft:light[level=14]
setblock 223 115 568 minecraft:light[level=14]
setblock 223 115 576 minecraft:light[level=14]
setblock 223 115 584 minecraft:light[level=14]
setblock 223 115 592 minecraft:light[level=14]
fill 210 118 586 211 119 588 minecraft:raw_gold_block
fill 223 118 559 223 128 559 minecraft:red_wool
fill 221 119 559 222 128 559 minecraft:red_wool
fill 224 119 559 225 119 559 minecraft:red_wool
fill 190 120 561 190 120 563 minecraft:yellow_terracotta
fill 190 120 567 190 125 569 minecraft:quartz_block
fill 190 120 579 190 125 581 minecraft:quartz_block
fill 190 120 591 190 125 593 minecraft:quartz_block
fill 191 120 560 193 120 560 minecraft:yellow_terracotta
fill 191 120 564 193 120 564 minecraft:yellow_terracotta
fill 192 120 592 192 120 593 minecraft:yellow_terracotta
setblock 192 120 595 minecraft:yellow_terracotta
fill 193 120 592 195 120 592 minecraft:yellow_terracotta
fill 193 120 596 194 120 596 minecraft:yellow_terracotta
fill 194 120 561 194 120 563 minecraft:yellow_terracotta
setblock 195 120 595 minecraft:yellow_terracotta
fill 196 120 593 196 120 594 minecraft:yellow_terracotta
fill 196 120 597 198 125 597 minecraft:quartz_block
fill 197 120 571 197 121 571 minecraft:gold_block
fill 200 120 559 202 125 559 minecraft:quartz_block
fill 208 120 597 210 125 597 minecraft:quartz_block
fill 212 120 559 214 125 559 minecraft:quartz_block
fill 220 120 597 222 125 597 minecraft:quartz_block
fill 222 120 593 222 120 594 minecraft:yellow_terracotta
setblock 223 120 592 minecraft:yellow_terracotta
setblock 223 120 595 minecraft:yellow_terracotta
fill 224 120 559 226 125 559 minecraft:quartz_block
fill 224 120 591 225 120 591 minecraft:yellow_terracotta
fill 225 120 595 226 120 595 minecraft:yellow_terracotta
setblock 226 120 592 minecraft:yellow_terracotta
setblock 226 120 594 minecraft:yellow_terracotta
fill 228 120 567 228 125 569 minecraft:quartz_block
fill 228 120 579 228 125 581 minecraft:quartz_block
fill 228 120 591 228 125 593 minecraft:quartz_block
setblock 191 123 560 minecraft:light[level=14]
setblock 191 123 568 minecraft:light[level=14]
setblock 191 123 576 minecraft:light[level=14]
setblock 191 123 584 minecraft:light[level=14]
setblock 191 123 592 minecraft:light[level=14]
setblock 199 123 560 minecraft:light[level=14]
setblock 199 123 568 minecraft:light[level=14]
setblock 199 123 576 minecraft:light[level=14]
setblock 199 123 584 minecraft:light[level=14]
setblock 199 123 592 minecraft:light[level=14]
setblock 207 123 560 minecraft:light[level=14]
setblock 207 123 568 minecraft:light[level=14]
setblock 207 123 576 minecraft:light[level=14]
setblock 207 123 584 minecraft:light[level=14]
setblock 207 123 592 minecraft:light[level=14]
setblock 215 123 560 minecraft:light[level=14]
setblock 215 123 568 minecraft:light[level=14]
setblock 215 123 576 minecraft:light[level=14]
setblock 215 123 584 minecraft:light[level=14]
setblock 215 123 592 minecraft:light[level=14]
setblock 223 123 560 minecraft:light[level=14]
setblock 223 123 568 minecraft:light[level=14]
setblock 223 123 576 minecraft:light[level=14]
setblock 223 123 584 minecraft:light[level=14]
setblock 223 123 592 minecraft:light[level=14]
fill 204 124 585 205 125 585 minecraft:gold_block
fill 189 125 561 189 125 566 minecraft:yellow_terracotta
fill 189 125 573 189 125 578 minecraft:yellow_terracotta
fill 189 125 585 189 125 590 minecraft:yellow_terracotta
fill 189 125 597 189 125 598 minecraft:yellow_terracotta
fill 190 125 598 193 125 598 minecraft:yellow_terracotta
fill 193 125 558 198 125 558 minecraft:yellow_terracotta
fill 200 125 598 205 125 598 minecraft:yellow_terracotta
fill 205 125 558 210 125 558 minecraft:yellow_terracotta
fill 212 125 598 217 125 598 minecraft:yellow_terracotta
fill 217 125 558 222 125 558 minecraft:yellow_terracotta
fill 224 125 598 229 125 598 minecraft:yellow_terracotta
fill 229 125 558 229 125 563 minecraft:yellow_terracotta
fill 229 125 570 229 125 575 minecraft:yellow_terracotta
fill 229 125 582 229 125 587 minecraft:yellow_terracotta
fill 229 125 594 229 125 597 minecraft:yellow_terracotta
fill 188 126 563 188 131 566 minecraft:ochre_froglight
fill 188 126 575 188 131 578 minecraft:ochre_froglight
fill 188 126 587 188 131 590 minecraft:ochre_froglight
fill 188 126 599 191 131 599 minecraft:ochre_froglight
fill 195 126 557 198 131 557 minecraft:ochre_froglight
fill 200 126 599 203 131 599 minecraft:ochre_froglight
fill 201 126 580 201 127 580 minecraft:raw_gold_block
fill 207 126 557 210 131 557 minecraft:ochre_froglight
fill 212 126 599 215 131 599 minecraft:ochre_froglight
fill 219 126 557 222 131 557 minecraft:ochre_froglight
fill 224 126 559 225 128 559 minecraft:red_wool
fill 224 126 599 227 131 599 minecraft:ochre_froglight
fill 230 126 558 230 131 561 minecraft:ochre_froglight
fill 230 126 570 230 131 573 minecraft:ochre_froglight
fill 230 126 582 230 131 585 minecraft:ochre_froglight
fill 230 126 594 230 131 597 minecraft:ochre_froglight
fill 190 128 561 190 128 563 minecraft:yellow_terracotta
fill 191 128 560 193 128 560 minecraft:yellow_terracotta
fill 191 128 564 193 128 564 minecraft:yellow_terracotta
fill 192 128 592 192 128 593 minecraft:yellow_terracotta
setblock 192 128 595 minecraft:yellow_terracotta
fill 193 128 592 195 128 592 minecraft:yellow_terracotta
fill 193 128 596 194 128 596 minecraft:yellow_terracotta
fill 194 128 561 194 128 563 minecraft:yellow_terracotta
setblock 195 128 595 minecraft:yellow_terracotta
fill 196 128 593 196 128 594 minecraft:yellow_terracotta
fill 222 128 593 222 128 594 minecraft:yellow_terracotta
setblock 223 128 592 minecraft:yellow_terracotta
setblock 223 128 595 minecraft:yellow_terracotta
fill 224 128 591 225 128 591 minecraft:yellow_terracotta
fill 225 128 595 226 128 595 minecraft:yellow_terracotta
setblock 226 128 592 minecraft:yellow_terracotta
setblock 226 128 594 minecraft:yellow_terracotta
fill 220 129 559 226 130 559 minecraft:gold_block
setblock 191 131 560 minecraft:light[level=14]
setblock 191 131 568 minecraft:light[level=14]
setblock 191 131 576 minecraft:light[level=14]
setblock 191 131 584 minecraft:light[level=14]
setblock 191 131 592 minecraft:light[level=14]
setblock 199 131 560 minecraft:light[level=14]
setblock 199 131 568 minecraft:light[level=14]
setblock 199 131 576 minecraft:light[level=14]
setblock 199 131 584 minecraft:light[level=14]
setblock 199 131 592 minecraft:light[level=14]
setblock 207 131 560 minecraft:light[level=14]
setblock 207 131 568 minecraft:light[level=14]
setblock 207 131 576 minecraft:light[level=14]
setblock 207 131 584 minecraft:light[level=14]
setblock 207 131 592 minecraft:light[level=14]
setblock 215 131 560 minecraft:light[level=14]
setblock 215 131 568 minecraft:light[level=14]
setblock 215 131 576 minecraft:light[level=14]
setblock 215 131 584 minecraft:light[level=14]
setblock 215 131 592 minecraft:light[level=14]
setblock 223 131 560 minecraft:light[level=14]
setblock 223 131 568 minecraft:light[level=14]
setblock 223 131 576 minecraft:light[level=14]
setblock 223 131 584 minecraft:light[level=14]
setblock 223 131 592 minecraft:light[level=14]
fill 188 132 563 188 145 563 minecraft:yellow_terracotta
fill 188 132 564 188 132 565 minecraft:ochre_froglight
fill 188 132 566 188 145 566 minecraft:yellow_terracotta
fill 188 132 575 188 145 575 minecraft:yellow_terracotta
fill 188 132 576 188 132 577 minecraft:ochre_froglight
fill 188 132 578 188 145 578 minecraft:yellow_terracotta
fill 188 132 587 188 145 587 minecraft:yellow_terracotta
fill 188 132 588 188 132 589 minecraft:ochre_froglight
fill 188 132 590 188 145 590 minecraft:yellow_terracotta
fill 188 132 599 188 145 599 minecraft:yellow_terracotta
fill 189 132 599 190 132 599 minecraft:ochre_froglight
fill 191 132 599 191 145 599 minecraft:yellow_terracotta
fill 195 132 557 195 145 557 minecraft:yellow_terracotta
fill 196 132 557 197 132 557 minecraft:ochre_froglight
fill 198 132 557 198 145 557 minecraft:yellow_terracotta
fill 200 132 599 200 145 599 minecraft:yellow_terracotta
fill 201 132 599 202 132 599 minecraft:ochre_froglight
fill 203 132 599 203 145 599 minecraft:yellow_terracotta
fill 207 132 557 207 145 557 minecraft:yellow_terracotta
fill 208 132 557 209 132 557 minecraft:ochre_froglight
fill 210 132 557 210 145 557 minecraft:yellow_terracotta
fill 212 132 560 212 133 560 minecraft:raw_gold_block
fill 212 132 599 212 145 599 minecraft:yellow_terracotta
fill 213 132 599 214 132 599 minecraft:ochre_froglight
fill 215 132 599 215 145 599 minecraft:yellow_terracotta
fill 219 132 557 219 145 557 minecraft:yellow_terracotta
fill 220 132 557 221 132 557 minecraft:ochre_froglight
fill 222 132 557 222 145 557 minecraft:yellow_terracotta
fill 224 132 599 224 145 599 minecraft:yellow_terracotta
fill 225 132 599 226 132 599 minecraft:ochre_froglight
fill 227 132 599 227 145 599 minecraft:yellow_terracotta
fill 230 132 558 230 145 558 minecraft:yellow_terracotta
fill 230 132 559 230 132 560 minecraft:ochre_froglight
fill 230 132 561 230 145 561 minecraft:yellow_terracotta
fill 230 132 570 230 145 570 minecraft:yellow_terracotta
fill 230 132 571 230 132 572 minecraft:ochre_froglight
fill 230 132 573 230 145 573 minecraft:yellow_terracotta
fill 230 132 582 230 145 582 minecraft:yellow_terracotta
fill 230 132 583 230 132 584 minecraft:ochre_froglight
fill 230 132 585 230 145 585 minecraft:yellow_terracotta
fill 230 132 594 230 145 594 minecraft:yellow_terracotta
fill 230 132 595 230 132 596 minecraft:ochre_froglight
fill 230 132 597 230 145 597 minecraft:yellow_terracotta
fill 188 133 564 188 145 565 minecraft:yellow_terracotta
fill 188 133 576 188 145 577 minecraft:yellow_terracotta
fill 188 133 588 188 145 589 minecraft:yellow_terracotta
fill 189 133 599 190 145 599 minecraft:yellow_terracotta
fill 196 133 557 197 145 557 minecraft:yellow_terracotta
fill 201 133 599 202 145 599 minecraft:yellow_terracotta
fill 208 133 557 209 145 557 minecraft:yellow_terracotta
fill 213 133 599 214 145 599 minecraft:yellow_terracotta
fill 220 133 557 221 145 557 minecraft:yellow_terracotta
fill 225 133 599 226 145 599 minecraft:yellow_terracotta
fill 230 133 559 230 145 560 minecraft:yellow_terracotta
fill 230 133 571 230 145 572 minecraft:yellow_terracotta
fill 230 133 583 230 145 584 minecraft:yellow_terracotta
fill 230 133 595 230 145 596 minecraft:yellow_terracotta
fill 190 136 561 190 136 563 minecraft:yellow_terracotta
fill 191 136 560 193 136 560 minecraft:yellow_terracotta
fill 191 136 564 193 136 564 minecraft:yellow_terracotta
fill 192 136 592 192 136 593 minecraft:yellow_terracotta
setblock 192 136 595 minecraft:yellow_terracotta
fill 193 136 592 195 136 592 minecraft:yellow_terracotta
fill 193 136 596 194 136 596 minecraft:yellow_terracotta
fill 194 136 561 194 136 563 minecraft:yellow_terracotta
setblock 195 136 595 minecraft:yellow_terracotta
fill 196 136 593 196 136 594 minecraft:yellow_terracotta
fill 222 136 593 222 136 594 minecraft:yellow_terracotta
setblock 223 136 592 minecraft:yellow_terracotta
setblock 223 136 595 minecraft:yellow_terracotta
fill 224 136 591 225 136 591 minecraft:yellow_terracotta
fill 225 136 595 226 136 595 minecraft:yellow_terracotta
setblock 226 136 592 minecraft:yellow_terracotta
setblock 226 136 594 minecraft:yellow_terracotta
setblock 191 139 560 minecraft:light[level=14]
setblock 191 139 568 minecraft:light[level=14]
setblock 191 139 576 minecraft:light[level=14]
setblock 191 139 584 minecraft:light[level=14]
setblock 191 139 592 minecraft:light[level=14]
setblock 199 139 560 minecraft:light[level=14]
setblock 199 139 568 minecraft:light[level=14]
setblock 199 139 576 minecraft:light[level=14]
setblock 199 139 584 minecraft:light[level=14]
setblock 199 139 592 minecraft:light[level=14]
setblock 207 139 560 minecraft:light[level=14]
setblock 207 139 568 minecraft:light[level=14]
setblock 207 139 576 minecraft:light[level=14]
setblock 207 139 584 minecraft:light[level=14]
setblock 207 139 592 minecraft:light[level=14]
setblock 215 139 560 minecraft:light[level=14]
setblock 215 139 568 minecraft:light[level=14]
setblock 215 139 576 minecraft:light[level=14]
setblock 215 139 584 minecraft:light[level=14]
setblock 215 139 592 minecraft:light[level=14]
setblock 223 139 560 minecraft:light[level=14]
setblock 223 139 568 minecraft:light[level=14]
setblock 223 139 576 minecraft:light[level=14]
setblock 223 139 584 minecraft:light[level=14]
setblock 223 139 592 minecraft:light[level=14]
fill 190 140 567 190 145 569 minecraft:quartz_block
fill 190 140 579 190 145 581 minecraft:quartz_block
fill 190 140 591 190 145 593 minecraft:quartz_block
fill 196 140 597 198 145 597 minecraft:quartz_block
fill 200 140 559 202 145 559 minecraft:quartz_block
fill 208 140 597 210 145 597 minecraft:quartz_block
fill 212 140 559 214 145 559 minecraft:quartz_block
fill 220 140 597 222 145 597 minecraft:quartz_block
fill 224 140 559 226 145 559 minecraft:quartz_block
fill 228 140 567 228 145 569 minecraft:quartz_block
fill 228 140 579 228 145 581 minecraft:quartz_block
fill 228 140 591 228 145 593 minecraft:quartz_block
fill 190 144 561 190 144 563 minecraft:yellow_terracotta
fill 191 144 560 193 144 560 minecraft:yellow_terracotta
fill 191 144 564 193 144 564 minecraft:yellow_terracotta
fill 192 144 592 192 144 593 minecraft:yellow_terracotta
setblock 192 144 595 minecraft:yellow_terracotta
fill 193 144 592 195 144 592 minecraft:yellow_terracotta
fill 193 144 596 194 144 596 minecraft:yellow_terracotta
fill 194 144 561 194 144 563 minecraft:yellow_terracotta
setblock 195 144 595 minecraft:yellow_terracotta
fill 196 144 593 196 144 594 minecraft:yellow_terracotta
fill 222 144 593 222 144 594 minecraft:yellow_terracotta
setblock 223 144 592 minecraft:yellow_terracotta
setblock 223 144 595 minecraft:yellow_terracotta
fill 224 144 591 225 144 591 minecraft:yellow_terracotta
fill 225 144 595 226 144 595 minecraft:yellow_terracotta
setblock 226 144 592 minecraft:yellow_terracotta
setblock 226 144 594 minecraft:yellow_terracotta
fill 189 145 561 189 145 566 minecraft:yellow_terracotta
fill 189 145 573 189 145 578 minecraft:yellow_terracotta
fill 189 145 585 189 145 590 minecraft:yellow_terracotta
fill 189 145 597 189 145 598 minecraft:yellow_terracotta
fill 190 145 598 193 145 598 minecraft:yellow_terracotta
fill 193 145 558 198 145 558 minecraft:yellow_terracotta
fill 200 145 598 205 145 598 minecraft:yellow_terracotta
fill 205 145 558 210 145 558 minecraft:yellow_terracotta
fill 212 145 598 217 145 598 minecraft:yellow_terracotta
fill 217 145 558 222 145 558 minecraft:yellow_terracotta
fill 224 145 598 229 145 598 minecraft:yellow_terracotta
fill 229 145 558 229 145 563 minecraft:yellow_terracotta
fill 229 145 570 229 145 575 minecraft:yellow_terracotta
fill 229 145 582 229 145 587 minecraft:yellow_terracotta
fill 229 145 594 229 145 597 minecraft:yellow_terracotta
fill 188 146 563 188 151 566 minecraft:ochre_froglight
fill 188 146 575 188 151 578 minecraft:ochre_froglight
fill 188 146 587 188 151 590 minecraft:ochre_froglight
fill 188 146 599 191 151 599 minecraft:ochre_froglight
fill 195 146 557 198 151 557 minecraft:ochre_froglight
fill 200 146 599 203 151 599 minecraft:ochre_froglight
fill 207 146 557 210 151 557 minecraft:ochre_froglight
fill 212 146 599 215 151 599 minecraft:ochre_froglight
fill 219 146 557 222 151 557 minecraft:ochre_froglight
fill 224 146 599 227 151 599 minecraft:ochre_froglight
fill 230 146 558 230 151 561 minecraft:ochre_froglight
fill 230 146 570 230 151 573 minecraft:ochre_froglight
fill 230 146 582 230 151 585 minecraft:ochre_froglight
fill 230 146 594 230 151 597 minecraft:ochre_froglight
setblock 191 147 560 minecraft:light[level=14]
setblock 191 147 568 minecraft:light[level=14]
setblock 191 147 576 minecraft:light[level=14]
setblock 191 147 584 minecraft:light[level=14]
setblock 191 147 592 minecraft:light[level=14]
setblock 199 147 560 minecraft:light[level=14]
setblock 199 147 568 minecraft:light[level=14]
setblock 199 147 576 minecraft:light[level=14]
setblock 199 147 584 minecraft:light[level=14]
setblock 199 147 592 minecraft:light[level=14]
setblock 207 147 560 minecraft:light[level=14]
setblock 207 147 568 minecraft:light[level=14]
setblock 207 147 576 minecraft:light[level=14]
setblock 207 147 584 minecraft:light[level=14]
setblock 207 147 592 minecraft:light[level=14]
setblock 215 147 560 minecraft:light[level=14]
setblock 215 147 568 minecraft:light[level=14]
setblock 215 147 576 minecraft:light[level=14]
setblock 215 147 584 minecraft:light[level=14]
setblock 215 147 592 minecraft:light[level=14]
setblock 223 147 560 minecraft:light[level=14]
setblock 223 147 568 minecraft:light[level=14]
setblock 223 147 576 minecraft:light[level=14]
setblock 223 147 584 minecraft:light[level=14]
setblock 223 147 592 minecraft:light[level=14]
fill 188 152 563 188 165 563 minecraft:yellow_terracotta
fill 188 152 564 188 152 565 minecraft:ochre_froglight
fill 188 152 566 188 165 566 minecraft:yellow_terracotta
fill 188 152 575 188 165 575 minecraft:yellow_terracotta
fill 188 152 576 188 152 577 minecraft:ochre_froglight
fill 188 152 578 188 165 578 minecraft:yellow_terracotta
fill 188 152 587 188 165 587 minecraft:yellow_terracotta
fill 188 152 588 188 152 589 minecraft:ochre_froglight
fill 188 152 590 188 165 590 minecraft:yellow_terracotta
fill 188 152 599 188 165 599 minecraft:yellow_terracotta
fill 189 152 599 190 152 599 minecraft:ochre_froglight
fill 190 152 561 190 152 563 minecraft:yellow_terracotta
fill 191 152 560 193 152 560 minecraft:yellow_terracotta
fill 191 152 564 193 152 564 minecraft:yellow_terracotta
fill 191 152 599 191 165 599 minecraft:yellow_terracotta
fill 192 152 592 192 152 593 minecraft:yellow_terracotta
setblock 192 152 595 minecraft:yellow_terracotta
fill 193 152 592 195 152 592 minecraft:yellow_terracotta
fill 193 152 596 194 152 596 minecraft:yellow_terracotta
fill 194 152 561 194 152 563 minecraft:yellow_terracotta
fill 195 152 557 195 165 557 minecraft:yellow_terracotta
setblock 195 152 595 minecraft:yellow_terracotta
fill 196 152 557 197 152 557 minecraft:ochre_froglight
fill 196 152 593 196 152 594 minecraft:yellow_terracotta
fill 198 152 557 198 165 557 minecraft:yellow_terracotta
fill 200 152 599 200 165 599 minecraft:yellow_terracotta
fill 201 152 599 202 152 599 minecraft:ochre_froglight
fill 203 152 599 203 165 599 minecraft:yellow_terracotta
fill 207 152 557 207 165 557 minecraft:yellow_terracotta
fill 208 152 557 209 152 557 minecraft:ochre_froglight
fill 210 152 557 210 165 557 minecraft:yellow_terracotta
fill 212 152 599 212 165 599 minecraft:yellow_terracotta
fill 213 152 599 214 152 599 minecraft:ochre_froglight
fill 215 152 599 215 165 599 minecraft:yellow_terracotta
fill 219 152 557 219 165 557 minecraft:yellow_terracotta
fill 220 152 557 221 152 557 minecraft:ochre_froglight
fill 222 152 557 222 165 557 minecraft:yellow_terracotta
fill 222 152 593 222 152 594 minecraft:yellow_terracotta
setblock 223 152 592 minecraft:yellow_terracotta
setblock 223 152 595 minecraft:yellow_terracotta
fill 224 152 591 225 152 591 minecraft:yellow_terracotta
fill 224 152 599 224 165 599 minecraft:yellow_terracotta
fill 225 152 595 226 152 595 minecraft:yellow_terracotta
fill 225 152 599 226 152 599 minecraft:ochre_froglight
setblock 226 152 592 minecraft:yellow_terracotta
setblock 226 152 594 minecraft:yellow_terracotta
fill 227 152 599 227 165 599 minecraft:yellow_terracotta
fill 230 152 558 230 165 558 minecraft:yellow_terracotta
fill 230 152 559 230 152 560 minecraft:ochre_froglight
fill 230 152 561 230 165 561 minecraft:yellow_terracotta
fill 230 152 570 230 165 570 minecraft:yellow_terracotta
fill 230 152 571 230 152 572 minecraft:ochre_froglight
fill 230 152 573 230 165 573 minecraft:yellow_terracotta
fill 230 152 582 230 165 582 minecraft:yellow_terracotta
fill 230 152 583 230 152 584 minecraft:ochre_froglight
fill 230 152 585 230 165 585 minecraft:yellow_terracotta
fill 230 152 594 230 165 594 minecraft:yellow_terracotta
fill 230 152 595 230 152 596 minecraft:ochre_froglight
fill 230 152 597 230 165 597 minecraft:yellow_terracotta
fill 188 153 564 188 165 565 minecraft:yellow_terracotta
fill 188 153 576 188 165 577 minecraft:yellow_terracotta
fill 188 153 588 188 165 589 minecraft:yellow_terracotta
fill 189 153 599 190 165 599 minecraft:yellow_terracotta
fill 190 153 561 190 154 563 minecraft:gold_block
fill 191 153 560 193 154 560 minecraft:gold_block
fill 191 153 564 193 154 564 minecraft:gold_block
fill 192 153 593 192 154 593 minecraft:gold_block
fill 192 153 595 192 154 595 minecraft:gold_block
fill 193 153 592 195 154 592 minecraft:gold_block
fill 193 153 596 194 154 596 minecraft:gold_block
fill 194 153 561 194 154 563 minecraft:gold_block
fill 195 153 595 195 154 595 minecraft:gold_block
fill 196 153 557 197 165 557 minecraft:yellow_terracotta
fill 196 153 594 196 154 594 minecraft:gold_block
fill 201 153 599 202 165 599 minecraft:yellow_terracotta
fill 208 153 557 209 165 557 minecraft:yellow_terracotta
fill 213 153 599 214 165 599 minecraft:yellow_terracotta
fill 220 153 557 221 165 557 minecraft:yellow_terracotta
fill 222 153 593 222 154 593 minecraft:gold_block
fill 223 153 592 223 154 592 minecraft:gold_block
fill 223 153 595 223 154 595 minecraft:gold_block
fill 224 153 591 225 154 591 minecraft:gold_block
fill 225 153 595 225 154 595 minecraft:gold_block
fill 225 153 599 226 165 599 minecraft:yellow_terracotta
fill 226 153 592 226 154 592 minecraft:gold_block
fill 226 153 594 226 154 594 minecraft:gold_block
fill 230 153 559 230 165 560 minecraft:yellow_terracotta
fill 230 153 571 230 165 572 minecraft:yellow_terracotta
fill 230 153 583 230 165 584 minecraft:yellow_terracotta
fill 230 153 595 230 165 596 minecraft:yellow_terracotta
setblock 191 155 560 minecraft:light[level=14]
setblock 191 155 568 minecraft:light[level=14]
setblock 191 155 576 minecraft:light[level=14]
setblock 191 155 584 minecraft:light[level=14]
setblock 191 155 592 minecraft:light[level=14]
setblock 199 155 560 minecraft:light[level=14]
setblock 199 155 568 minecraft:light[level=14]
setblock 199 155 576 minecraft:light[level=14]
setblock 199 155 584 minecraft:light[level=14]
setblock 199 155 592 minecraft:light[level=14]
setblock 207 155 560 minecraft:light[level=14]
setblock 207 155 568 minecraft:light[level=14]
setblock 207 155 576 minecraft:light[level=14]
setblock 207 155 584 minecraft:light[level=14]
setblock 207 155 592 minecraft:light[level=14]
setblock 215 155 560 minecraft:light[level=14]
setblock 215 155 568 minecraft:light[level=14]
setblock 215 155 576 minecraft:light[level=14]
setblock 215 155 584 minecraft:light[level=14]
setblock 215 155 592 minecraft:light[level=14]
setblock 223 155 560 minecraft:light[level=14]
setblock 223 155 568 minecraft:light[level=14]
setblock 223 155 576 minecraft:light[level=14]
setblock 223 155 584 minecraft:light[level=14]
setblock 223 155 592 minecraft:light[level=14]
fill 204 159 575 206 159 577 minecraft:redstone_block
fill 204 159 583 206 159 585 minecraft:redstone_block
fill 212 159 578 214 159 580 minecraft:redstone_block
fill 194 160 580 201 160 580 minecraft:gold_block
fill 196 160 579 202 160 579 minecraft:gold_block
fill 196 160 581 202 160 581 minecraft:gold_block
fill 199 160 571 201 161 573 minecraft:gold_block
fill 199 160 578 203 160 578 minecraft:gold_block
fill 199 160 582 203 160 582 minecraft:gold_block
fill 199 160 587 201 161 589 minecraft:gold_block
fill 200 160 574 203 160 575 minecraft:gold_block
fill 200 160 585 203 160 586 minecraft:gold_block
fill 201 160 576 203 160 576 minecraft:gold_block
fill 201 160 584 203 160 584 minecraft:gold_block
fill 202 160 572 203 161 573 minecraft:gold_block
fill 202 160 577 203 160 577 minecraft:gold_block
fill 202 160 580 206 160 580 minecraft:dark_oak_planks
fill 202 160 583 203 160 583 minecraft:gold_block
fill 202 160 587 203 161 588 minecraft:gold_block
fill 203 160 579 206 160 579 minecraft:dark_oak_planks
fill 203 160 581 206 160 581 minecraft:dark_oak_planks
fill 204 160 573 204 160 574 minecraft:gold_block
fill 204 160 578 212 160 578 minecraft:dark_oak_planks
fill 204 160 582 212 160 582 minecraft:dark_oak_planks
fill 204 160 586 204 160 587 minecraft:gold_block
fill 205 160 574 216 160 574 minecraft:gold_block
fill 205 160 586 216 160 586 minecraft:gold_block
fill 206 160 571 210 160 573 minecraft:gold_block
fill 206 160 587 210 160 589 minecraft:gold_block
fill 207 160 568 209 161 570 minecraft:gold_block
fill 207 160 575 215 160 576 minecraft:gold_block
fill 207 160 577 209 161 577 minecraft:dark_oak_planks
fill 207 160 583 209 161 583 minecraft:dark_oak_planks
fill 207 160 584 215 160 585 minecraft:gold_block
fill 207 160 590 209 161 592 minecraft:gold_block
fill 208 160 566 208 161 567 minecraft:gold_block
fill 208 160 593 208 161 594 minecraft:gold_block
fill 210 160 577 214 160 577 minecraft:gold_block
fill 210 160 579 213 160 581 minecraft:dark_oak_planks
fill 210 160 583 214 160 583 minecraft:gold_block
fill 212 160 573 217 161 573 minecraft:gold_block
fill 212 160 587 217 161 587 minecraft:gold_block
fill 213 160 572 217 161 572 minecraft:gold_block
fill 213 160 582 217 160 582 minecraft:gold_block
fill 213 160 588 217 161 588 minecraft:gold_block
fill 214 160 580 214 161 580 minecraft:dark_oak_planks
fill 214 160 581 220 160 581 minecraft:gold_block
fill 215 160 571 217 161 571 minecraft:gold_block
fill 215 160 578 217 160 580 minecraft:gold_block
fill 215 160 589 217 161 589 minecraft:gold_block
fill 216 160 575 216 161 575 minecraft:gold_block
fill 216 160 585 216 161 585 minecraft:gold_block
fill 218 160 579 220 161 580 minecraft:gold_block
fill 221 160 580 222 161 580 minecraft:gold_block
fill 189 161 558 193 161 598 minecraft:yellow_terracotta
fill 194 161 558 195 161 579 minecraft:yellow_terracotta
fill 194 161 580 198 161 580 minecraft:gold_block
fill 194 161 581 195 161 598 minecraft:yellow_terracotta
fill 196 161 558 198 161 578 minecraft:yellow_terracotta
fill 196 161 579 198 161 579 minecraft:gold_block
fill 196 161 581 198 161 581 minecraft:gold_block
fill 196 161 582 198 161 598 minecraft:yellow_terracotta
fill 199 161 558 206 161 570 minecraft:yellow_terracotta
fill 199 161 574 199 161 577 minecraft:yellow_terracotta
fill 199 161 578 205 161 582 minecraft:dark_oak_planks
fill 199 161 583 199 161 586 minecraft:yellow_terracotta
fill 199 161 590 206 161 598 minecraft:yellow_terracotta
fill 200 161 574 201 161 575 minecraft:gold_block
fill 200 161 576 200 161 577 minecraft:yellow_terracotta
fill 200 161 583 200 161 584 minecraft:yellow_terracotta
fill 200 161 585 201 161 586 minecraft:gold_block
fill 201 161 576 202 161 576 minecraft:gold_block
fill 201 161 577 206 161 577 minecraft:dark_oak_planks
fill 201 161 583 206 161 583 minecraft:dark_oak_planks
fill 201 161 584 202 161 584 minecraft:gold_block
fill 202 161 571 205 161 571 minecraft:yellow_terracotta
fill 202 161 574 202 161 575 minecraft:emerald_block
fill 202 161 585 202 161 586 minecraft:emerald_block
fill 202 161 589 205 161 589 minecraft:yellow_terracotta
fill 203 161 574 203 161 575 minecraft:ochre_froglight
fill 203 161 576 213 161 576 minecraft:dark_oak_planks
fill 203 161 584 213 161 584 minecraft:dark_oak_planks
fill 203 161 585 203 161 586 minecraft:ochre_froglight
fill 204 161 572 205 161 572 minecraft:yellow_terracotta
setblock 204 161 573 minecraft:gold_block
fill 204 161 574 207 161 574 minecraft:ochre_froglight
fill 204 161 575 206 161 575 minecraft:yellow_terracotta
fill 204 161 585 206 161 585 minecraft:yellow_terracotta
fill 204 161 586 207 161 586 minecraft:ochre_froglight
setblock 204 161 587 minecraft:gold_block
fill 204 161 588 205 161 588 minecraft:yellow_terracotta
setblock 205 161 573 minecraft:yellow_terracotta
setblock 205 161 587 minecraft:yellow_terracotta
fill 206 161 571 206 161 573 minecraft:gold_block
setblock 206 161 578 minecraft:dark_oak_planks
fill 206 161 579 206 161 581 minecraft:sea_lantern
setblock 206 161 582 minecraft:dark_oak_planks
fill 206 161 587 206 161 589 minecraft:gold_block
fill 207 161 558 207 161 567 minecraft:yellow_terracotta
setblock 207 161 571 minecraft:gold_block
fill 207 161 572 209 161 573 minecraft:emerald_block
setblock 207 161 575 minecraft:ochre_froglight
fill 207 161 578 209 161 578 minecraft:sea_lantern
fill 207 161 582 209 161 582 minecraft:sea_lantern
setblock 207 161 585 minecraft:ochre_froglight
fill 207 161 587 209 161 588 minecraft:emerald_block
setblock 207 161 589 minecraft:gold_block
fill 207 161 593 207 161 598 minecraft:yellow_terracotta
fill 208 161 558 229 161 565 minecraft:yellow_terracotta
setblock 208 161 571 minecraft:emerald_block
fill 208 161 574 209 161 575 minecraft:emerald_block
fill 208 161 585 209 161 586 minecraft:emerald_block
setblock 208 161 589 minecraft:emerald_block
fill 208 161 595 229 161 598 minecraft:yellow_terracotta
fill 209 161 566 229 161 567 minecraft:yellow_terracotta
fill 209 161 571 210 161 571 minecraft:gold_block
fill 209 161 589 210 161 589 minecraft:gold_block
fill 209 161 593 229 161 594 minecraft:yellow_terracotta
fill 210 161 568 229 161 570 minecraft:yellow_terracotta
fill 210 161 572 210 161 575 minecraft:gold_block
fill 210 161 577 215 161 578 minecraft:dark_oak_planks
fill 210 161 579 210 161 581 minecraft:sea_lantern
fill 210 161 582 215 161 583 minecraft:dark_oak_planks
fill 210 161 585 210 161 588 minecraft:gold_block
fill 210 161 590 229 161 592 minecraft:yellow_terracotta
fill 211 161 571 211 161 573 minecraft:yellow_terracotta
fill 211 161 574 212 161 574 minecraft:gold_block
fill 211 161 575 214 161 575 minecraft:emerald_block
fill 211 161 579 213 161 581 minecraft:dark_oak_planks
fill 211 161 585 214 161 585 minecraft:emerald_block
fill 211 161 586 212 161 586 minecraft:gold_block
fill 211 161 587 211 161 589 minecraft:yellow_terracotta
fill 212 161 571 212 161 572 minecraft:yellow_terracotta
fill 212 161 588 212 161 589 minecraft:yellow_terracotta
fill 213 161 571 214 161 571 minecraft:yellow_terracotta
fill 213 161 574 214 161 574 minecraft:emerald_block
fill 213 161 586 214 161 586 minecraft:emerald_block
fill 213 161 589 214 161 589 minecraft:yellow_terracotta
fill 214 161 576 215 161 576 minecraft:gold_block
fill 214 161 579 217 161 579 minecraft:dark_oak_planks
fill 214 161 581 217 161 581 minecraft:dark_oak_planks
fill 214 161 584 215 161 584 minecraft:gold_block
fill 215 161 574 215 161 575 minecraft:gold_block
fill 215 161 580 217 161 580 minecraft:dark_oak_planks
fill 215 161 585 215 161 586 minecraft:gold_block
setblock 216 161 574 minecraft:gold_block
fill 216 161 576 229 161 577 minecraft:yellow_terracotta
fill 216 161 578 217 161 578 minecraft:dark_oak_planks
fill 216 161 582 217 161 582 minecraft:dark_oak_planks
fill 216 161 583 229 161 584 minecraft:yellow_terracotta
setblock 216 161 586 minecraft:gold_block
fill 217 161 574 229 161 575 minecraft:yellow_terracotta
fill 217 161 585 229 161 586 minecraft:yellow_terracotta
fill 218 161 571 229 161 573 minecraft:yellow_terracotta
fill 218 161 578 229 161 578 minecraft:yellow_terracotta
fill 218 161 581 220 161 581 minecraft:gold_block
fill 218 161 582 229 161 582 minecraft:yellow_terracotta
fill 218 161 587 229 161 589 minecraft:yellow_terracotta
fill 221 161 579 229 161 579 minecraft:yellow_terracotta
fill 221 161 581 229 161 581 minecraft:yellow_terracotta
fill 223 161 580 229 161 580 minecraft:yellow_terracotta
fill 196 162 580 198 162 580 minecraft:dark_oak_planks
fill 197 162 578 198 162 579 minecraft:dark_oak_planks
fill 197 162 581 198 162 582 minecraft:dark_oak_planks
fill 198 162 577 200 162 577 minecraft:dark_oak_planks
fill 198 162 583 200 162 583 minecraft:dark_oak_planks
fill 199 162 576 202 162 576 minecraft:dark_oak_planks
fill 199 162 584 202 162 584 minecraft:dark_oak_planks
fill 202 162 575 214 162 575 minecraft:dark_oak_planks
fill 202 162 585 214 162 585 minecraft:dark_oak_planks
fill 207 162 574 209 164 574 minecraft:dark_oak_planks
fill 207 162 586 209 164 586 minecraft:dark_oak_planks
fill 214 162 576 217 162 576 minecraft:dark_oak_planks
fill 214 162 584 217 162 584 minecraft:dark_oak_planks
fill 216 162 577 218 162 577 minecraft:dark_oak_planks
fill 216 162 583 218 162 583 minecraft:dark_oak_planks
fill 218 162 578 219 162 582 minecraft:dark_oak_planks
setblock 220 162 580 minecraft:dark_oak_planks
setblock 191 163 560 minecraft:light[level=14]
setblock 191 163 568 minecraft:light[level=14]
setblock 191 163 576 minecraft:light[level=14]
setblock 191 163 584 minecraft:light[level=14]
setblock 191 163 592 minecraft:light[level=14]
fill 195 163 579 195 164 581 minecraft:dark_oak_planks
fill 196 163 578 196 163 579 minecraft:dark_oak_planks
fill 196 163 581 196 163 582 minecraft:dark_oak_planks
setblock 197 163 577 minecraft:dark_oak_planks
setblock 197 163 583 minecraft:dark_oak_planks
fill 198 163 576 199 163 576 minecraft:dark_oak_planks
fill 198 163 584 199 163 584 minecraft:dark_oak_planks
setblock 199 163 560 minecraft:light[level=14]
setblock 199 163 568 minecraft:light[level=14]
setblock 199 163 592 minecraft:light[level=14]
fill 200 163 575 202 163 575 minecraft:dark_oak_planks
fill 200 163 585 202 163 585 minecraft:dark_oak_planks
fill 203 163 574 206 164 574 minecraft:dark_oak_planks
fill 203 163 586 206 164 586 minecraft:dark_oak_planks
setblock 207 163 560 minecraft:light[level=14]
setblock 207 163 568 minecraft:light[level=14]
setblock 207 163 576 minecraft:light[level=14]
setblock 207 163 584 minecraft:light[level=14]
setblock 207 163 592 minecraft:light[level=14]
fill 210 163 574 213 164 574 minecraft:dark_oak_planks
fill 210 163 586 213 164 586 minecraft:dark_oak_planks
fill 214 163 575 216 163 575 minecraft:dark_oak_planks
fill 214 163 585 216 163 585 minecraft:dark_oak_planks
setblock 215 163 560 minecraft:light[level=14]
setblock 215 163 568 minecraft:light[level=14]
setblock 215 163 576 minecraft:light[level=14]
setblock 215 163 584 minecraft:light[level=14]
setblock 215 163 592 minecraft:light[level=14]
fill 217 163 576 218 163 576 minecraft:dark_oak_planks
fill 217 163 584 218 163 584 minecraft:dark_oak_planks
setblock 219 163 577 minecraft:dark_oak_planks
setblock 219 163 583 minecraft:dark_oak_planks
fill 220 163 578 220 163 579 minecraft:dark_oak_planks
fill 220 163 581 220 163 582 minecraft:dark_oak_planks
fill 221 163 579 221 164 581 minecraft:dark_oak_planks
setblock 223 163 560 minecraft:light[level=14]
setblock 223 163 568 minecraft:light[level=14]
setblock 223 163 576 minecraft:light[level=14]
setblock 223 163 584 minecraft:light[level=14]
setblock 223 163 592 minecraft:light[level=14]
setblock 195 164 578 minecraft:dark_oak_planks
setblock 195 164 582 minecraft:dark_oak_planks
setblock 196 164 577 minecraft:dark_oak_planks
setblock 196 164 583 minecraft:dark_oak_planks
fill 197 164 576 198 164 576 minecraft:dark_oak_planks
fill 197 164 584 198 164 584 minecraft:dark_oak_planks
fill 199 164 575 200 164 575 minecraft:dark_oak_planks
fill 199 164 585 200 164 585 minecraft:dark_oak_planks
fill 201 164 574 202 164 574 minecraft:dark_oak_planks
fill 201 164 586 202 164 586 minecraft:dark_oak_planks
fill 214 164 574 215 164 574 minecraft:dark_oak_planks
fill 214 164 586 215 164 586 minecraft:dark_oak_planks
fill 216 164 575 217 164 575 minecraft:dark_oak_planks
fill 216 164 585 217 164 585 minecraft:dark_oak_planks
fill 218 164 576 219 164 576 minecraft:dark_oak_planks
fill 218 164 584 219 164 584 minecraft:dark_oak_planks
setblock 220 164 577 minecraft:dark_oak_planks
setblock 220 164 583 minecraft:dark_oak_planks
setblock 221 164 578 minecraft:dark_oak_planks
setblock 221 164 582 minecraft:dark_oak_planks
fill 189 165 558 191 220 558 minecraft:quartz_block
fill 189 165 561 189 165 566 minecraft:yellow_terracotta
fill 189 165 568 189 220 570 minecraft:quartz_block
fill 189 165 573 189 165 578 minecraft:yellow_terracotta
fill 189 165 580 189 220 582 minecraft:quartz_block
fill 189 165 585 189 165 590 minecraft:yellow_terracotta
fill 189 165 592 189 220 594 minecraft:quartz_block
fill 189 165 597 189 165 598 minecraft:yellow_terracotta
fill 190 165 567 190 165 569 minecraft:quartz_block
fill 190 165 579 190 165 581 minecraft:quartz_block
fill 190 165 591 190 165 593 minecraft:quartz_block
fill 190 165 598 193 165 598 minecraft:yellow_terracotta
fill 193 165 558 198 165 558 minecraft:yellow_terracotta
fill 193 165 559 201 165 564 minecraft:quartz_block
fill 195 165 578 204 165 582 minecraft:spruce_planks
fill 195 165 598 197 220 598 minecraft:quartz_block
fill 196 165 577 206 165 577 minecraft:spruce_planks
fill 196 165 583 206 165 583 minecraft:spruce_planks
fill 196 165 597 198 165 597 minecraft:quartz_block
fill 197 165 576 219 165 576 minecraft:spruce_planks
fill 197 165 584 219 165 584 minecraft:spruce_planks
fill 199 165 558 203 165 558 minecraft:quartz_block
fill 199 165 575 217 165 575 minecraft:spruce_planks
fill 199 165 585 217 165 585 minecraft:spruce_planks
fill 200 165 598 205 165 598 minecraft:yellow_terracotta
fill 201 165 574 215 165 574 minecraft:spruce_planks
fill 201 165 586 215 165 586 minecraft:spruce_planks
setblock 202 165 559 minecraft:quartz_block
fill 205 165 558 210 165 558 minecraft:yellow_terracotta
setblock 205 165 578 minecraft:spruce_planks
setblock 205 165 582 minecraft:spruce_planks
fill 207 165 598 209 220 598 minecraft:quartz_block
fill 208 165 597 210 165 597 minecraft:quartz_block
fill 210 165 577 220 165 577 minecraft:spruce_planks
fill 210 165 583 220 165 583 minecraft:spruce_planks
fill 211 165 578 221 165 578 minecraft:spruce_planks
fill 211 165 582 221 165 582 minecraft:spruce_planks
fill 212 165 559 214 165 559 minecraft:quartz_block
fill 212 165 579 221 165 581 minecraft:spruce_planks
fill 212 165 598 217 165 598 minecraft:yellow_terracotta
fill 213 165 558 215 220 558 minecraft:quartz_block
fill 217 165 558 222 165 558 minecraft:yellow_terracotta
fill 219 165 589 223 165 598 minecraft:quartz_block
fill 224 165 559 226 165 559 minecraft:quartz_block
fill 224 165 589 228 165 597 minecraft:quartz_block
fill 224 165 598 229 165 598 minecraft:yellow_terracotta
fill 225 165 558 227 220 558 minecraft:quartz_block
fill 228 165 567 228 165 569 minecraft:quartz_block
fill 228 165 579 228 165 581 minecraft:quartz_block
fill 229 165 558 229 165 563 minecraft:yellow_terracotta
fill 229 165 566 229 220 568 minecraft:quartz_block
fill 229 165 570 229 165 575 minecraft:yellow_terracotta
fill 229 165 578 229 220 580 minecraft:quartz_block
fill 229 165 582 229 165 587 minecraft:yellow_terracotta
fill 229 165 589 229 165 593 minecraft:quartz_block
fill 229 165 594 229 165 597 minecraft:yellow_terracotta
fill 188 166 563 188 171 566 minecraft:ochre_froglight
fill 188 166 575 188 171 578 minecraft:ochre_froglight
fill 188 166 587 188 171 590 minecraft:ochre_froglight
fill 188 166 599 191 171 599 minecraft:ochre_froglight
setblock 193 166 558 minecraft:ochre_froglight
fill 193 166 559 193 177 559 minecraft:quartz_block
setblock 193 166 560 minecraft:ochre_froglight
fill 193 166 561 193 177 561 minecraft:quartz_block
setblock 193 166 562 minecraft:ochre_froglight
fill 193 166 563 193 177 563 minecraft:quartz_block
setblock 193 166 564 minecraft:ochre_froglight
fill 194 166 558 194 177 558 minecraft:quartz_block
setblock 194 166 559 minecraft:ochre_froglight
fill 194 166 560 194 177 560 minecraft:quartz_block
setblock 194 166 561 minecraft:ochre_froglight
fill 194 166 562 194 177 562 minecraft:quartz_block
setblock 194 166 563 minecraft:ochre_froglight
fill 194 166 564 194 177 564 minecraft:quartz_block
fill 195 166 557 195 166 558 minecraft:ochre_froglight
fill 195 166 559 195 177 559 minecraft:quartz_block
setblock 195 166 560 minecraft:ochre_froglight
fill 195 166 561 195 177 561 minecraft:quartz_block
setblock 195 166 562 minecraft:ochre_froglight
fill 195 166 563 195 177 563 minecraft:quartz_block
setblock 195 166 564 minecraft:ochre_froglight
fill 196 166 557 198 171 557 minecraft:ochre_froglight
fill 196 166 558 196 177 558 minecraft:quartz_block
setblock 196 166 559 minecraft:ochre_froglight
fill 196 166 560 196 177 560 minecraft:quartz_block
setblock 196 166 561 minecraft:ochre_froglight
fill 196 166 562 196 177 562 minecraft:quartz_block
setblock 196 166 563 minecraft:ochre_froglight
fill 196 166 564 196 177 564 minecraft:quartz_block
setblock 197 166 558 minecraft:ochre_froglight
fill 197 166 559 197 177 559 minecraft:quartz_block
setblock 197 166 560 minecraft:ochre_froglight
fill 197 166 561 197 177 561 minecraft:quartz_block
setblock 197 166 562 minecraft:ochre_froglight
fill 197 166 563 197 177 563 minecraft:quartz_block
setblock 197 166 564 minecraft:ochre_froglight
fill 198 166 558 198 177 558 minecraft:quartz_block
setblock 198 166 559 minecraft:ochre_froglight
fill 198 166 560 198 177 560 minecraft:quartz_block
setblock 198 166 561 minecraft:ochre_froglight
fill 198 166 562 198 177 562 minecraft:quartz_block
setblock 198 166 563 minecraft:ochre_froglight
fill 198 166 564 198 177 564 minecraft:quartz_block
setblock 199 166 558 minecraft:ochre_froglight
fill 199 166 559 199 177 559 minecraft:quartz_block
setblock 199 166 560 minecraft:ochre_froglight
fill 199 166 561 199 177 561 minecraft:quartz_block
setblock 199 166 562 minecraft:ochre_froglight
fill 199 166 563 199 177 563 minecraft:quartz_block
setblock 199 166 564 minecraft:ochre_froglight
fill 200 166 558 200 177 558 minecraft:quartz_block
setblock 200 166 559 minecraft:ochre_froglight
fill 200 166 560 200 177 560 minecraft:quartz_block
setblock 200 166 561 minecraft:ochre_froglight
fill 200 166 562 200 177 562 minecraft:quartz_block
setblock 200 166 563 minecraft:ochre_froglight
fill 200 166 564 200 177 564 minecraft:quartz_block
fill 200 166 599 203 171 599 minecraft:ochre_froglight
setblock 201 166 558 minecraft:ochre_froglight
fill 201 166 559 201 177 559 minecraft:quartz_block
setblock 201 166 560 minecraft:ochre_froglight
fill 201 166 561 201 177 561 minecraft:quartz_block
setblock 201 166 562 minecraft:ochre_froglight
fill 201 166 563 201 177 563 minecraft:quartz_block
setblock 201 166 564 minecraft:ochre_froglight
fill 201 166 580 201 169 580 minecraft:stripped_dark_oak_log
fill 202 166 558 203 220 558 minecraft:quartz_block
fill 207 166 557 210 171 557 minecraft:ochre_froglight
fill 212 166 599 215 171 599 minecraft:ochre_froglight
fill 219 166 557 222 171 557 minecraft:ochre_froglight
fill 219 166 589 219 180 589 minecraft:quartz_block
setblock 219 166 590 minecraft:ochre_froglight
fill 219 166 591 219 180 591 minecraft:quartz_block
setblock 219 166 592 minecraft:ochre_froglight
fill 219 166 593 219 180 593 minecraft:quartz_block
setblock 219 166 594 minecraft:ochre_froglight
fill 219 166 595 219 180 595 minecraft:quartz_block
setblock 219 166 596 minecraft:ochre_froglight
fill 219 166 597 219 180 597 minecraft:quartz_block
setblock 219 166 598 minecraft:ochre_froglight
setblock 220 166 589 minecraft:ochre_froglight
fill 220 166 590 220 180 590 minecraft:quartz_block
setblock 220 166 591 minecraft:ochre_froglight
fill 220 166 592 220 180 592 minecraft:quartz_block
setblock 220 166 593 minecraft:ochre_froglight
fill 220 166 594 220 180 594 minecraft:quartz_block
setblock 220 166 595 minecraft:ochre_froglight
fill 220 166 596 220 180 596 minecraft:quartz_block
setblock 220 166 597 minecraft:ochre_froglight
fill 220 166 598 220 220 598 minecraft:quartz_block
fill 221 166 589 221 180 589 minecraft:quartz_block
setblock 221 166 590 minecraft:ochre_froglight
fill 221 166 591 221 180 591 minecraft:quartz_block
setblock 221 166 592 minecraft:ochre_froglight
fill 221 166 593 221 180 593 minecraft:quartz_block
setblock 221 166 594 minecraft:ochre_froglight
fill 221 166 595 221 180 595 minecraft:quartz_block
setblock 221 166 596 minecraft:ochre_froglight
fill 221 166 597 221 185 597 minecraft:quartz_block
setblock 221 166 598 minecraft:ochre_froglight
setblock 222 166 589 minecraft:ochre_froglight
fill 222 166 590 222 180 590 minecraft:quartz_block
setblock 222 166 591 minecraft:ochre_froglight
fill 222 166 592 222 180 592 minecraft:quartz_block
setblock 222 166 593 minecraft:ochre_froglight
fill 222 166 594 222 180 594 minecraft:quartz_block
setblock 222 166 595 minecraft:ochre_froglight
fill 222 166 596 222 180 596 minecraft:quartz_block
setblock 222 166 597 minecraft:ochre_froglight
fill 222 166 598 222 180 598 minecraft:quartz_block
fill 223 166 589 223 180 589 minecraft:quartz_block
setblock 223 166 590 minecraft:ochre_froglight
fill 223 166 591 223 180 591 minecraft:quartz_block
setblock 223 166 592 minecraft:ochre_froglight
fill 223 166 593 223 180 593 minecraft:quartz_block
setblock 223 166 594 minecraft:ochre_froglight
fill 223 166 595 223 180 595 minecraft:quartz_block
setblock 223 166 596 minecraft:ochre_froglight
fill 223 166 597 223 180 597 minecraft:quartz_block
setblock 223 166 598 minecraft:ochre_froglight
setblock 224 166 589 minecraft:ochre_froglight
fill 224 166 590 224 180 590 minecraft:quartz_block
setblock 224 166 591 minecraft:ochre_froglight
fill 224 166 592 224 180 592 minecraft:quartz_block
setblock 224 166 593 minecraft:ochre_froglight
fill 224 166 594 224 180 594 minecraft:quartz_block
setblock 224 166 595 minecraft:ochre_froglight
fill 224 166 596 224 180 596 minecraft:quartz_block
setblock 224 166 597 minecraft:ochre_froglight
fill 224 166 598 224 180 598 minecraft:quartz_block
fill 224 166 599 227 171 599 minecraft:ochre_froglight
fill 225 166 589 225 180 589 minecraft:quartz_block
setblock 225 166 590 minecraft:ochre_froglight
fill 225 166 591 225 180 591 minecraft:quartz_block
setblock 225 166 592 minecraft:ochre_froglight
fill 225 166 593 225 180 593 minecraft:quartz_block
setblock 225 166 594 minecraft:ochre_froglight
fill 225 166 595 225 180 595 minecraft:quartz_block
setblock 225 166 596 minecraft:ochre_froglight
fill 225 166 597 225 180 597 minecraft:quartz_block
setblock 225 166 598 minecraft:ochre_froglight
setblock 226 166 589 minecraft:ochre_froglight
fill 226 166 590 226 180 590 minecraft:quartz_block
setblock 226 166 591 minecraft:ochre_froglight
fill 226 166 592 226 180 592 minecraft:quartz_block
setblock 226 166 593 minecraft:ochre_froglight
fill 226 166 594 226 180 594 minecraft:quartz_block
setblock 226 166 595 minecraft:ochre_froglight
fill 226 166 596 226 180 596 minecraft:quartz_block
setblock 226 166 597 minecraft:ochre_froglight
fill 226 166 598 226 180 598 minecraft:quartz_block
fill 227 166 589 227 180 589 minecraft:quartz_block
setblock 227 166 590 minecraft:ochre_froglight
fill 227 166 591 227 180 591 minecraft:quartz_block
setblock 227 166 592 minecraft:ochre_froglight
fill 227 166 593 227 180 593 minecraft:quartz_block
setblock 227 166 594 minecraft:ochre_froglight
fill 227 166 595 227 180 595 minecraft:quartz_block
setblock 227 166 596 minecraft:ochre_froglight
fill 227 166 597 227 180 597 minecraft:quartz_block
setblock 227 166 598 minecraft:ochre_froglight
setblock 228 166 589 minecraft:ochre_froglight
fill 228 166 590 228 180 590 minecraft:quartz_block
setblock 228 166 591 minecraft:ochre_froglight
fill 228 166 592 228 185 592 minecraft:quartz_block
setblock 228 166 593 minecraft:ochre_froglight
fill 228 166 594 228 180 594 minecraft:quartz_block
setblock 228 166 595 minecraft:ochre_froglight
fill 228 166 596 228 180 596 minecraft:quartz_block
setblock 228 166 597 minecraft:ochre_froglight
fill 228 166 598 228 180 598 minecraft:quartz_block
fill 229 166 589 229 180 589 minecraft:quartz_block
setblock 229 166 590 minecraft:ochre_froglight
fill 229 166 591 229 220 591 minecraft:quartz_block
setblock 229 166 592 minecraft:ochre_froglight
fill 229 166 593 229 180 593 minecraft:quartz_block
fill 229 166 594 230 166 594 minecraft:ochre_froglight
fill 229 166 595 229 180 595 minecraft:quartz_block
fill 229 166 596 230 166 596 minecraft:ochre_froglight
fill 229 166 597 229 180 597 minecraft:quartz_block
setblock 229 166 598 minecraft:ochre_froglight
fill 230 166 558 230 171 561 minecraft:ochre_froglight
fill 230 166 570 230 171 573 minecraft:ochre_froglight
fill 230 166 582 230 171 585 minecraft:ochre_froglight
fill 230 166 595 230 172 595 minecraft:ochre_froglight
fill 230 166 597 230 171 597 minecraft:ochre_froglight
fill 193 167 558 193 168 558 minecraft:quartz_block
fill 193 167 560 193 168 560 minecraft:quartz_block
fill 193 167 562 193 168 562 minecraft:quartz_block
fill 193 167 564 193 168 564 minecraft:quartz_block
fill 194 167 559 194 168 559 minecraft:quartz_block
fill 194 167 561 194 168 561 minecraft:quartz_block
fill 194 167 563 194 168 563 minecraft:quartz_block
fill 195 167 557 195 171 557 minecraft:ochre_froglight
fill 195 167 558 195 168 558 minecraft:quartz_block
fill 195 167 560 195 168 560 minecraft:quartz_block
fill 195 167 562 195 168 562 minecraft:quartz_block
fill 195 167 564 195 168 564 minecraft:quartz_block
fill 196 167 559 196 168 559 minecraft:quartz_block
fill 196 167 561 196 168 561 minecraft:quartz_block
fill 196 167 563 196 168 563 minecraft:quartz_block
fill 197 167 558 197 168 558 minecraft:quartz_block
fill 197 167 560 197 168 560 minecraft:quartz_block
fill 197 167 562 197 168 562 minecraft:quartz_block
fill 197 167 564 197 168 564 minecraft:quartz_block
fill 198 167 559 198 168 559 minecraft:quartz_block
fill 198 167 561 198 168 561 minecraft:quartz_block
fill 198 167 563 198 168 563 minecraft:quartz_block
fill 199 167 558 199 168 558 minecraft:quartz_block
fill 199 167 560 199 168 560 minecraft:quartz_block
fill 199 167 562 199 168 562 minecraft:quartz_block
fill 199 167 564 199 168 564 minecraft:quartz_block
fill 200 167 559 200 168 559 minecraft:quartz_block
fill 200 167 561 200 168 561 minecraft:quartz_block
fill 200 167 563 200 168 563 minecraft:quartz_block
fill 201 167 558 201 168 558 minecraft:quartz_block
fill 201 167 560 201 168 560 minecraft:quartz_block
fill 201 167 562 201 168 562 minecraft:quartz_block
fill 201 167 564 201 168 564 minecraft:quartz_block
fill 219 167 590 219 168 590 minecraft:quartz_block
fill 219 167 592 219 168 592 minecraft:quartz_block
fill 219 167 594 219 168 594 minecraft:quartz_block
fill 219 167 596 219 168 596 minecraft:quartz_block
fill 219 167 598 219 168 598 minecraft:quartz_block
fill 220 167 589 220 168 589 minecraft:quartz_block
fill 220 167 591 220 168 591 minecraft:quartz_block
fill 220 167 593 220 168 593 minecraft:quartz_block
fill 220 167 595 220 168 595 minecraft:quartz_block
fill 220 167 597 220 168 597 minecraft:quartz_block
fill 221 167 590 221 168 590 minecraft:quartz_block
fill 221 167 592 221 168 592 minecraft:quartz_block
fill 221 167 594 221 168 594 minecraft:quartz_block
fill 221 167 596 221 168 596 minecraft:quartz_block
fill 221 167 598 221 168 598 minecraft:quartz_block
fill 222 167 589 222 168 589 minecraft:quartz_block
fill 222 167 591 222 168 591 minecraft:quartz_block
fill 222 167 593 222 168 593 minecraft:quartz_block
fill 222 167 595 222 168 595 minecraft:quartz_block
fill 222 167 597 222 168 597 minecraft:quartz_block
fill 223 167 590 223 168 590 minecraft:quartz_block
fill 223 167 592 223 168 592 minecraft:quartz_block
fill 223 167 594 223 168 594 minecraft:quartz_block
fill 223 167 596 223 168 596 minecraft:quartz_block
fill 223 167 598 223 168 598 minecraft:quartz_block
fill 224 167 589 224 168 589 minecraft:quartz_block
fill 224 167 591 224 168 591 minecraft:quartz_block
fill 224 167 593 224 168 593 minecraft:quartz_block
fill 224 167 595 224 168 595 minecraft:quartz_block
fill 224 167 597 224 168 597 minecraft:quartz_block
fill 225 167 590 225 168 590 minecraft:quartz_block
fill 225 167 592 225 168 592 minecraft:quartz_block
fill 225 167 594 225 168 594 minecraft:quartz_block
fill 225 167 596 225 168 596 minecraft:quartz_block
fill 225 167 598 225 168 598 minecraft:quartz_block
fill 226 167 589 226 168 589 minecraft:quartz_block
fill 226 167 591 226 168 591 minecraft:quartz_block
fill 226 167 593 226 168 593 minecraft:quartz_block
fill 226 167 595 226 168 595 minecraft:quartz_block
fill 226 167 597 226 168 597 minecraft:quartz_block
fill 227 167 590 227 168 590 minecraft:quartz_block
fill 227 167 592 227 168 592 minecraft:quartz_block
fill 227 167 594 227 168 594 minecraft:quartz_block
fill 227 167 596 227 168 596 minecraft:quartz_block
fill 227 167 598 227 168 598 minecraft:quartz_block
fill 228 167 589 228 168 589 minecraft:quartz_block
fill 228 167 591 228 168 591 minecraft:quartz_block
fill 228 167 593 228 168 593 minecraft:quartz_block
fill 228 167 595 228 168 595 minecraft:quartz_block
fill 228 167 597 228 168 597 minecraft:quartz_block
fill 229 167 590 229 168 590 minecraft:quartz_block
fill 229 167 592 229 168 592 minecraft:quartz_block
fill 229 167 594 229 168 594 minecraft:quartz_block
fill 229 167 596 229 168 596 minecraft:quartz_block
fill 229 167 598 229 168 598 minecraft:quartz_block
fill 230 167 594 230 171 594 minecraft:ochre_froglight
fill 230 167 596 230 172 596 minecraft:ochre_froglight
setblock 193 169 558 minecraft:ochre_froglight
setblock 193 169 560 minecraft:ochre_froglight
setblock 193 169 562 minecraft:ochre_froglight
setblock 193 169 564 minecraft:ochre_froglight
setblock 194 169 559 minecraft:ochre_froglight
setblock 194 169 561 minecraft:ochre_froglight
setblock 194 169 563 minecraft:ochre_froglight
setblock 195 169 558 minecraft:ochre_froglight
setblock 195 169 560 minecraft:ochre_froglight
setblock 195 169 562 minecraft:ochre_froglight
setblock 195 169 564 minecraft:ochre_froglight
fill 195 169 573 195 170 573 minecraft:raw_gold_block
setblock 196 169 559 minecraft:ochre_froglight
setblock 196 169 561 minecraft:ochre_froglight
setblock 196 169 563 minecraft:ochre_froglight
setblock 197 169 558 minecraft:ochre_froglight
setblock 197 169 560 minecraft:ochre_froglight
setblock 197 169 562 minecraft:ochre_froglight
setblock 197 169 564 minecraft:ochre_froglight
setblock 198 169 559 minecraft:ochre_froglight
setblock 198 169 561 minecraft:ochre_froglight
setblock 198 169 563 minecraft:ochre_froglight
setblock 199 169 558 minecraft:ochre_froglight
setblock 199 169 560 minecraft:ochre_froglight
setblock 199 169 562 minecraft:ochre_froglight
setblock 199 169 564 minecraft:ochre_froglight
setblock 200 169 559 minecraft:ochre_froglight
setblock 200 169 561 minecraft:ochre_froglight
setblock 200 169 563 minecraft:ochre_froglight
setblock 201 169 558 minecraft:ochre_froglight
setblock 201 169 560 minecraft:ochre_froglight
setblock 201 169 562 minecraft:ochre_froglight
setblock 201 169 564 minecraft:ochre_froglight
setblock 219 169 590 minecraft:ochre_froglight
setblock 219 169 592 minecraft:ochre_froglight
setblock 219 169 594 minecraft:ochre_froglight
setblock 219 169 596 minecraft:ochre_froglight
setblock 219 169 598 minecraft:ochre_froglight
setblock 220 169 589 minecraft:ochre_froglight
setblock 220 169 591 minecraft:ochre_froglight
setblock 220 169 593 minecraft:ochre_froglight
setblock 220 169 595 minecraft:ochre_froglight
setblock 220 169 597 minecraft:ochre_froglight
setblock 221 169 590 minecraft:ochre_froglight
setblock 221 169 592 minecraft:ochre_froglight
setblock 221 169 594 minecraft:ochre_froglight
setblock 221 169 596 minecraft:ochre_froglight
setblock 221 169 598 minecraft:ochre_froglight
setblock 222 169 589 minecraft:ochre_froglight
setblock 222 169 591 minecraft:ochre_froglight
setblock 222 169 593 minecraft:ochre_froglight
setblock 222 169 595 minecraft:ochre_froglight
setblock 222 169 597 minecraft:ochre_froglight
setblock 223 169 590 minecraft:ochre_froglight
setblock 223 169 592 minecraft:ochre_froglight
setblock 223 169 594 minecraft:ochre_froglight
setblock 223 169 596 minecraft:ochre_froglight
setblock 223 169 598 minecraft:ochre_froglight
setblock 224 169 589 minecraft:ochre_froglight
setblock 224 169 591 minecraft:ochre_froglight
setblock 224 169 593 minecraft:ochre_froglight
setblock 224 169 595 minecraft:ochre_froglight
setblock 224 169 597 minecraft:ochre_froglight
setblock 225 169 590 minecraft:ochre_froglight
setblock 225 169 592 minecraft:ochre_froglight
setblock 225 169 594 minecraft:ochre_froglight
setblock 225 169 596 minecraft:ochre_froglight
setblock 225 169 598 minecraft:ochre_froglight
setblock 226 169 589 minecraft:ochre_froglight
setblock 226 169 591 minecraft:ochre_froglight
setblock 226 169 593 minecraft:ochre_froglight
setblock 226 169 595 minecraft:ochre_froglight
setblock 226 169 597 minecraft:ochre_froglight
setblock 227 169 590 minecraft:ochre_froglight
setblock 227 169 592 minecraft:ochre_froglight
setblock 227 169 594 minecraft:ochre_froglight
setblock 227 169 596 minecraft:ochre_froglight
setblock 227 169 598 minecraft:ochre_froglight
setblock 228 169 589 minecraft:ochre_froglight
setblock 228 169 591 minecraft:ochre_froglight
setblock 228 169 593 minecraft:ochre_froglight
setblock 228 169 595 minecraft:ochre_froglight
setblock 228 169 597 minecraft:ochre_froglight
setblock 229 169 590 minecraft:ochre_froglight
setblock 229 169 592 minecraft:ochre_froglight
setblock 229 169 594 minecraft:ochre_froglight
setblock 229 169 596 minecraft:ochre_froglight
setblock 229 169 598 minecraft:ochre_froglight
fill 193 170 558 193 171 558 minecraft:quartz_block
fill 193 170 560 193 171 560 minecraft:quartz_block
fill 193 170 562 193 171 562 minecraft:quartz_block
fill 193 170 564 193 171 564 minecraft:quartz_block
fill 194 170 559 194 171 559 minecraft:quartz_block
fill 194 170 561 194 171 561 minecraft:quartz_block
fill 194 170 563 194 171 563 minecraft:quartz_block
fill 195 170 558 195 171 558 minecraft:quartz_block
fill 195 170 560 195 171 560 minecraft:quartz_block
fill 195 170 562 195 171 562 minecraft:quartz_block
fill 195 170 564 195 171 564 minecraft:quartz_block
fill 196 170 559 196 171 559 minecraft:quartz_block
fill 196 170 561 196 171 561 minecraft:quartz_block
fill 196 170 563 196 171 563 minecraft:quartz_block
fill 197 170 558 197 171 558 minecraft:quartz_block
fill 197 170 560 197 171 560 minecraft:quartz_block
fill 197 170 562 197 171 562 minecraft:quartz_block
fill 197 170 564 197 171 564 minecraft:quartz_block
fill 198 170 559 198 171 559 minecraft:quartz_block
fill 198 170 561 198 171 561 minecraft:quartz_block
fill 198 170 563 198 171 563 minecraft:quartz_block
fill 199 170 558 199 171 558 minecraft:quartz_block
fill 199 170 560 199 171 560 minecraft:quartz_block
fill 199 170 562 199 171 562 minecraft:quartz_block
fill 199 170 564 199 171 564 minecraft:quartz_block
fill 200 170 559 200 171 559 minecraft:quartz_block
fill 200 170 561 200 171 561 minecraft:quartz_block
fill 200 170 563 200 171 563 minecraft:quartz_block
fill 201 170 558 201 171 558 minecraft:quartz_block
fill 201 170 560 201 171 560 minecraft:quartz_block
fill 201 170 562 201 171 562 minecraft:quartz_block
fill 201 170 564 201 171 564 minecraft:quartz_block
fill 201 170 576 201 179 584 minecraft:white_wool
fill 219 170 590 219 171 590 minecraft:quartz_block
fill 219 170 592 219 171 592 minecraft:quartz_block
fill 219 170 594 219 171 594 minecraft:quartz_block
fill 219 170 596 219 171 596 minecraft:quartz_block
fill 219 170 598 219 171 598 minecraft:quartz_block
fill 220 170 589 220 171 589 minecraft:quartz_block
fill 220 170 591 220 171 591 minecraft:quartz_block
fill 220 170 593 220 171 593 minecraft:quartz_block
fill 220 170 595 220 171 595 minecraft:quartz_block
fill 220 170 597 220 171 597 minecraft:quartz_block
fill 221 170 590 221 171 590 minecraft:quartz_block
fill 221 170 592 221 171 592 minecraft:quartz_block
fill 221 170 594 221 171 594 minecraft:quartz_block
fill 221 170 596 221 171 596 minecraft:quartz_block
fill 221 170 598 221 171 598 minecraft:quartz_block
fill 222 170 589 222 171 589 minecraft:quartz_block
fill 222 170 591 222 171 591 minecraft:quartz_block
fill 222 170 593 222 171 593 minecraft:quartz_block
fill 222 170 595 222 171 595 minecraft:quartz_block
fill 222 170 597 222 171 597 minecraft:quartz_block
fill 223 170 590 223 171 590 minecraft:quartz_block
fill 223 170 592 223 171 592 minecraft:quartz_block
fill 223 170 594 223 171 594 minecraft:quartz_block
fill 223 170 596 223 171 596 minecraft:quartz_block
fill 223 170 598 223 171 598 minecraft:quartz_block
fill 224 170 589 224 171 589 minecraft:quartz_block
fill 224 170 591 224 171 591 minecraft:quartz_block
fill 224 170 593 224 171 593 minecraft:quartz_block
fill 224 170 595 224 171 595 minecraft:quartz_block
fill 224 170 597 224 171 597 minecraft:quartz_block
fill 225 170 590 225 171 590 minecraft:quartz_block
fill 225 170 592 225 171 592 minecraft:quartz_block
fill 225 170 594 225 171 594 minecraft:quartz_block
fill 225 170 596 225 171 596 minecraft:quartz_block
fill 225 170 598 225 171 598 minecraft:quartz_block
fill 226 170 589 226 171 589 minecraft:quartz_block
fill 226 170 591 226 171 591 minecraft:quartz_block
fill 226 170 593 226 171 593 minecraft:quartz_block
fill 226 170 595 226 171 595 minecraft:quartz_block
fill 226 170 597 226 171 597 minecraft:quartz_block
fill 227 170 590 227 171 590 minecraft:quartz_block
fill 227 170 592 227 171 592 minecraft:quartz_block
fill 227 170 594 227 171 594 minecraft:quartz_block
fill 227 170 596 227 171 596 minecraft:quartz_block
fill 227 170 598 227 171 598 minecraft:quartz_block
fill 228 170 589 228 171 589 minecraft:quartz_block
fill 228 170 591 228 171 591 minecraft:quartz_block
fill 228 170 593 228 171 593 minecraft:quartz_block
fill 228 170 595 228 171 595 minecraft:quartz_block
fill 228 170 597 228 171 597 minecraft:quartz_block
fill 229 170 590 229 171 590 minecraft:quartz_block
fill 229 170 592 229 171 592 minecraft:quartz_block
fill 229 170 594 229 171 594 minecraft:quartz_block
fill 229 170 596 229 171 596 minecraft:quartz_block
fill 229 170 598 229 171 598 minecraft:quartz_block
setblock 191 171 560 minecraft:light[level=14]
setblock 191 171 568 minecraft:light[level=14]
setblock 191 171 576 minecraft:light[level=14]
setblock 191 171 584 minecraft:light[level=14]
setblock 191 171 592 minecraft:light[level=14]
setblock 199 171 568 minecraft:light[level=14]
setblock 199 171 576 minecraft:light[level=14]
setblock 199 171 584 minecraft:light[level=14]
setblock 199 171 592 minecraft:light[level=14]
setblock 207 171 560 minecraft:light[level=14]
setblock 207 171 568 minecraft:light[level=14]
setblock 207 171 576 minecraft:light[level=14]
setblock 207 171 584 minecraft:light[level=14]
setblock 207 171 592 minecraft:light[level=14]
setblock 215 171 560 minecraft:light[level=14]
setblock 215 171 568 minecraft:light[level=14]
setblock 215 171 576 minecraft:light[level=14]
setblock 215 171 584 minecraft:light[level=14]
setblock 215 171 592 minecraft:light[level=14]
setblock 223 171 560 minecraft:light[level=14]
setblock 223 171 568 minecraft:light[level=14]
setblock 223 171 576 minecraft:light[level=14]
setblock 223 171 584 minecraft:light[level=14]
fill 188 172 563 188 185 563 minecraft:yellow_terracotta
fill 188 172 564 188 172 565 minecraft:ochre_froglight
fill 188 172 566 188 185 566 minecraft:yellow_terracotta
fill 188 172 575 188 185 575 minecraft:yellow_terracotta
fill 188 172 576 188 172 577 minecraft:ochre_froglight
fill 188 172 578 188 185 578 minecraft:yellow_terracotta
fill 188 172 587 188 185 587 minecraft:yellow_terracotta
fill 188 172 588 188 172 589 minecraft:ochre_froglight
fill 188 172 590 188 185 590 minecraft:yellow_terracotta
fill 188 172 599 188 185 599 minecraft:yellow_terracotta
fill 189 172 599 190 172 599 minecraft:ochre_froglight
fill 191 172 599 191 185 599 minecraft:yellow_terracotta
setblock 193 172 558 minecraft:ochre_froglight
setblock 193 172 560 minecraft:ochre_froglight
setblock 193 172 562 minecraft:ochre_froglight
setblock 193 172 564 minecraft:ochre_froglight
setblock 194 172 559 minecraft:ochre_froglight
setblock 194 172 561 minecraft:ochre_froglight
setblock 194 172 563 minecraft:ochre_froglight
fill 195 172 557 195 185 557 minecraft:yellow_terracotta
setblock 195 172 558 minecraft:ochre_froglight
setblock 195 172 560 minecraft:ochre_froglight
setblock 195 172 562 minecraft:ochre_froglight
setblock 195 172 564 minecraft:ochre_froglight
fill 196 172 557 197 172 557 minecraft:ochre_froglight
setblock 196 172 559 minecraft:ochre_froglight
setblock 196 172 561 minecraft:ochre_froglight
setblock 196 172 563 minecraft:ochre_froglight
setblock 197 172 558 minecraft:ochre_froglight
setblock 197 172 560 minecraft:ochre_froglight
setblock 197 172 562 minecraft:ochre_froglight
setblock 197 172 564 minecraft:ochre_froglight
fill 198 172 557 198 185 557 minecraft:yellow_terracotta
setblock 198 172 559 minecraft:ochre_froglight
setblock 198 172 561 minecraft:ochre_froglight
setblock 198 172 563 minecraft:ochre_froglight
setblock 199 172 558 minecraft:ochre_froglight
setblock 199 172 560 minecraft:ochre_froglight
setblock 199 172 562 minecraft:ochre_froglight
setblock 199 172 564 minecraft:ochre_froglight
setblock 200 172 559 minecraft:ochre_froglight
setblock 200 172 561 minecraft:ochre_froglight
setblock 200 172 563 minecraft:ochre_froglight
fill 200 172 599 200 185 599 minecraft:yellow_terracotta
setblock 201 172 558 minecraft:ochre_froglight
setblock 201 172 560 minecraft:ochre_froglight
setblock 201 172 562 minecraft:ochre_froglight
setblock 201 172 564 minecraft:ochre_froglight
fill 201 172 599 202 172 599 minecraft:ochre_froglight
fill 203 172 599 203 185 599 minecraft:yellow_terracotta
fill 207 172 557 207 185 557 minecraft:yellow_terracotta
fill 208 172 557 209 172 557 minecraft:ochre_froglight
fill 210 172 557 210 185 557 minecraft:yellow_terracotta
fill 212 172 599 212 185 599 minecraft:yellow_terracotta
fill 213 172 599 214 172 599 minecraft:ochre_froglight
fill 215 172 599 215 185 599 minecraft:yellow_terracotta
fill 219 172 557 219 185 557 minecraft:yellow_terracotta
setblock 219 172 590 minecraft:ochre_froglight
setblock 219 172 592 minecraft:ochre_froglight
setblock 219 172 594 minecraft:ochre_froglight
setblock 219 172 596 minecraft:ochre_froglight
setblock 219 172 598 minecraft:ochre_froglight
fill 220 172 557 221 172 557 minecraft:ochre_froglight
setblock 220 172 589 minecraft:ochre_froglight
setblock 220 172 591 minecraft:ochre_froglight
setblock 220 172 593 minecraft:ochre_froglight
setblock 220 172 595 minecraft:ochre_froglight
setblock 220 172 597 minecraft:ochre_froglight
setblock 221 172 590 minecraft:ochre_froglight
setblock 221 172 592 minecraft:ochre_froglight
setblock 221 172 594 minecraft:ochre_froglight
setblock 221 172 596 minecraft:ochre_froglight
setblock 221 172 598 minecraft:ochre_froglight
fill 222 172 557 222 185 557 minecraft:yellow_terracotta
setblock 222 172 589 minecraft:ochre_froglight
setblock 222 172 591 minecraft:ochre_froglight
setblock 222 172 593 minecraft:ochre_froglight
setblock 222 172 595 minecraft:ochre_froglight
setblock 222 172 597 minecraft:ochre_froglight
setblock 223 172 590 minecraft:ochre_froglight
setblock 223 172 592 minecraft:ochre_froglight
setblock 223 172 594 minecraft:ochre_froglight
setblock 223 172 596 minecraft:ochre_froglight
setblock 223 172 598 minecraft:ochre_froglight
setblock 224 172 589 minecraft:ochre_froglight
setblock 224 172 591 minecraft:ochre_froglight
setblock 224 172 593 minecraft:ochre_froglight
setblock 224 172 595 minecraft:ochre_froglight
setblock 224 172 597 minecraft:ochre_froglight
fill 224 172 599 224 185 599 minecraft:yellow_terracotta
setblock 225 172 590 minecraft:ochre_froglight
setblock 225 172 592 minecraft:ochre_froglight
setblock 225 172 594 minecraft:ochre_froglight
setblock 225 172 596 minecraft:ochre_froglight
fill 225 172 598 225 172 599 minecraft:ochre_froglight
setblock 226 172 589 minecraft:ochre_froglight
setblock 226 172 591 minecraft:ochre_froglight
setblock 226 172 593 minecraft:ochre_froglight
setblock 226 172 595 minecraft:ochre_froglight
setblock 226 172 597 minecraft:ochre_froglight
setblock 226 172 599 minecraft:ochre_froglight
setblock 227 172 590 minecraft:ochre_froglight
setblock 227 172 592 minecraft:ochre_froglight
setblock 227 172 594 minecraft:ochre_froglight
setblock 227 172 596 minecraft:ochre_froglight
setblock 227 172 598 minecraft:ochre_froglight
fill 227 172 599 227 185 599 minecraft:yellow_terracotta
setblock 228 172 589 minecraft:ochre_froglight
setblock 228 172 591 minecraft:ochre_froglight
setblock 228 172 593 minecraft:ochre_froglight
setblock 228 172 595 minecraft:ochre_froglight
setblock 228 172 597 minecraft:ochre_froglight
setblock 229 172 590 minecraft:ochre_froglight
setblock 229 172 592 minecraft:ochre_froglight
setblock 229 172 594 minecraft:ochre_froglight
setblock 229 172 596 minecraft:ochre_froglight
setblock 229 172 598 minecraft:ochre_froglight
fill 230 172 558 230 185 558 minecraft:yellow_terracotta
fill 230 172 559 230 172 560 minecraft:ochre_froglight
fill 230 172 561 230 185 561 minecraft:yellow_terracotta
fill 230 172 570 230 185 570 minecraft:yellow_terracotta
fill 230 172 571 230 172 572 minecraft:ochre_froglight
fill 230 172 573 230 185 573 minecraft:yellow_terracotta
fill 230 172 582 230 185 582 minecraft:yellow_terracotta
fill 230 172 583 230 172 584 minecraft:ochre_froglight
fill 230 172 585 230 185 585 minecraft:yellow_terracotta
fill 230 172 594 230 185 594 minecraft:yellow_terracotta
fill 230 172 597 230 185 597 minecraft:yellow_terracotta
fill 188 173 564 188 185 565 minecraft:yellow_terracotta
fill 188 173 576 188 185 577 minecraft:yellow_terracotta
fill 188 173 588 188 185 589 minecraft:yellow_terracotta
fill 189 173 599 190 185 599 minecraft:yellow_terracotta
fill 193 173 558 193 174 558 minecraft:quartz_block
fill 193 173 560 193 174 560 minecraft:quartz_block
fill 193 173 562 193 174 562 minecraft:quartz_block
fill 193 173 564 193 174 564 minecraft:quartz_block
fill 194 173 559 194 174 559 minecraft:quartz_block
fill 194 173 561 194 174 561 minecraft:quartz_block
fill 194 173 563 194 174 563 minecraft:quartz_block
fill 195 173 558 195 174 558 minecraft:quartz_block
fill 195 173 560 195 174 560 minecraft:quartz_block
fill 195 173 562 195 174 562 minecraft:quartz_block
fill 195 173 564 195 174 564 minecraft:quartz_block
fill 196 173 557 197 185 557 minecraft:yellow_terracotta
fill 196 173 559 196 174 559 minecraft:quartz_block
fill 196 173 561 196 174 561 minecraft:quartz_block
fill 196 173 563 196 174 563 minecraft:quartz_block
fill 197 173 558 197 174 558 minecraft:quartz_block
fill 197 173 560 197 174 560 minecraft:quartz_block
fill 197 173 562 197 174 562 minecraft:quartz_block
fill 197 173 564 197 174 564 minecraft:quartz_block
fill 198 173 559 198 174 559 minecraft:quartz_block
fill 198 173 561 198 174 561 minecraft:quartz_block
fill 198 173 563 198 174 563 minecraft:quartz_block
fill 198 173 573 198 174 573 minecraft:raw_gold_block
fill 199 173 558 199 174 558 minecraft:quartz_block
fill 199 173 560 199 174 560 minecraft:quartz_block
fill 199 173 562 199 174 562 minecraft:quartz_block
fill 199 173 564 199 174 564 minecraft:quartz_block
fill 200 173 559 200 174 559 minecraft:quartz_block
fill 200 173 561 200 174 561 minecraft:quartz_block
fill 200 173 563 200 174 563 minecraft:quartz_block
fill 201 173 558 201 174 558 minecraft:quartz_block
fill 201 173 560 201 174 560 minecraft:quartz_block
fill 201 173 562 201 174 562 minecraft:quartz_block
fill 201 173 564 201 174 564 minecraft:quartz_block
fill 201 173 599 202 185 599 minecraft:yellow_terracotta
fill 208 173 557 209 185 557 minecraft:yellow_terracotta
fill 213 173 599 214 185 599 minecraft:yellow_terracotta
fill 219 173 590 219 174 590 minecraft:quartz_block
fill 219 173 592 219 174 592 minecraft:quartz_block
fill 219 173 594 219 174 594 minecraft:quartz_block
fill 219 173 596 219 174 596 minecraft:quartz_block
fill 219 173 598 219 174 598 minecraft:quartz_block
fill 220 173 557 221 185 557 minecraft:yellow_terracotta
fill 220 173 589 220 174 589 minecraft:quartz_block
fill 220 173 591 220 174 591 minecraft:quartz_block
fill 220 173 593 220 174 593 minecraft:quartz_block
fill 220 173 595 220 174 595 minecraft:quartz_block
fill 220 173 597 220 174 597 minecraft:quartz_block
fill 221 173 590 221 174 590 minecraft:quartz_block
fill 221 173 592 221 174 592 minecraft:quartz_block
fill 221 173 594 221 174 594 minecraft:quartz_block
fill 221 173 596 221 174 596 minecraft:quartz_block
fill 221 173 598 221 174 598 minecraft:quartz_block
fill 222 173 589 222 174 589 minecraft:quartz_block
fill 222 173 591 222 174 591 minecraft:quartz_block
fill 222 173 593 222 174 593 minecraft:quartz_block
fill 222 173 595 222 174 595 minecraft:quartz_block
fill 222 173 597 222 174 597 minecraft:quartz_block
fill 223 173 590 223 174 590 minecraft:quartz_block
fill 223 173 592 223 174 592 minecraft:quartz_block
fill 223 173 594 223 174 594 minecraft:quartz_block
fill 223 173 596 223 174 596 minecraft:quartz_block
fill 223 173 598 223 174 598 minecraft:quartz_block
fill 224 173 589 224 174 589 minecraft:quartz_block
fill 224 173 591 224 174 591 minecraft:quartz_block
fill 224 173 593 224 174 593 minecraft:quartz_block
fill 224 173 595 224 174 595 minecraft:quartz_block
fill 224 173 597 224 174 597 minecraft:quartz_block
fill 225 173 590 225 174 590 minecraft:quartz_block
fill 225 173 592 225 174 592 minecraft:quartz_block
fill 225 173 594 225 174 594 minecraft:quartz_block
fill 225 173 596 225 174 596 minecraft:quartz_block
fill 225 173 598 225 174 598 minecraft:quartz_block
fill 225 173 599 226 185 599 minecraft:yellow_terracotta
fill 226 173 589 226 174 589 minecraft:quartz_block
fill 226 173 591 226 174 591 minecraft:quartz_block
fill 226 173 593 226 174 593 minecraft:quartz_block
fill 226 173 595 226 174 595 minecraft:quartz_block
fill 226 173 597 226 174 597 minecraft:quartz_block
fill 227 173 590 227 174 590 minecraft:quartz_block
fill 227 173 592 227 174 592 minecraft:quartz_block
fill 227 173 594 227 174 594 minecraft:quartz_block
fill 227 173 596 227 174 596 minecraft:quartz_block
fill 227 173 598 227 174 598 minecraft:quartz_block
fill 228 173 589 228 174 589 minecraft:quartz_block
fill 228 173 591 228 174 591 minecraft:quartz_block
fill 228 173 593 228 174 593 minecraft:quartz_block
fill 228 173 595 228 174 595 minecraft:quartz_block
fill 228 173 597 228 174 597 minecraft:quartz_block
fill 229 173 590 229 174 590 minecraft:quartz_block
fill 229 173 592 229 174 592 minecraft:quartz_block
fill 229 173 594 229 174 594 minecraft:quartz_block
fill 229 173 596 229 174 596 minecraft:quartz_block
fill 229 173 598 229 174 598 minecraft:quartz_block
fill 230 173 559 230 185 560 minecraft:yellow_terracotta
fill 230 173 571 230 185 572 minecraft:yellow_terracotta
fill 230 173 583 230 185 584 minecraft:yellow_terracotta
fill 230 173 595 230 185 596 minecraft:yellow_terracotta
setblock 193 175 558 minecraft:ochre_froglight
setblock 193 175 560 minecraft:ochre_froglight
setblock 193 175 562 minecraft:ochre_froglight
setblock 193 175 564 minecraft:ochre_froglight
setblock 194 175 559 minecraft:ochre_froglight
setblock 194 175 561 minecraft:ochre_froglight
setblock 194 175 563 minecraft:ochre_froglight
setblock 195 175 558 minecraft:ochre_froglight
setblock 195 175 560 minecraft:ochre_froglight
setblock 195 175 562 minecraft:ochre_froglight
setblock 195 175 564 minecraft:ochre_froglight
setblock 196 175 559 minecraft:ochre_froglight
setblock 196 175 561 minecraft:ochre_froglight
setblock 196 175 563 minecraft:ochre_froglight
setblock 197 175 558 minecraft:ochre_froglight
setblock 197 175 560 minecraft:ochre_froglight
setblock 197 175 562 minecraft:ochre_froglight
setblock 197 175 564 minecraft:ochre_froglight
setblock 198 175 559 minecraft:ochre_froglight
setblock 198 175 561 minecraft:ochre_froglight
setblock 198 175 563 minecraft:ochre_froglight
setblock 199 175 558 minecraft:ochre_froglight
setblock 199 175 560 minecraft:ochre_froglight
setblock 199 175 562 minecraft:ochre_froglight
setblock 199 175 564 minecraft:ochre_froglight
setblock 200 175 559 minecraft:ochre_froglight
setblock 200 175 561 minecraft:ochre_froglight
setblock 200 175 563 minecraft:ochre_froglight
setblock 201 175 558 minecraft:ochre_froglight
setblock 201 175 560 minecraft:ochre_froglight
setblock 201 175 562 minecraft:ochre_froglight
setblock 201 175 564 minecraft:ochre_froglight
setblock 219 175 590 minecraft:ochre_froglight
setblock 219 175 592 minecraft:ochre_froglight
setblock 219 175 594 minecraft:ochre_froglight
setblock 219 175 596 minecraft:ochre_froglight
setblock 219 175 598 minecraft:ochre_froglight
setblock 220 175 589 minecraft:ochre_froglight
setblock 220 175 591 minecraft:ochre_froglight
setblock 220 175 593 minecraft:ochre_froglight
setblock 220 175 595 minecraft:ochre_froglight
setblock 220 175 597 minecraft:ochre_froglight
setblock 221 175 590 minecraft:ochre_froglight
setblock 221 175 592 minecraft:ochre_froglight
setblock 221 175 594 minecraft:ochre_froglight
setblock 221 175 596 minecraft:ochre_froglight
setblock 221 175 598 minecraft:ochre_froglight
setblock 222 175 589 minecraft:ochre_froglight
setblock 222 175 591 minecraft:ochre_froglight
setblock 222 175 593 minecraft:ochre_froglight
setblock 222 175 595 minecraft:ochre_froglight
setblock 222 175 597 minecraft:ochre_froglight
setblock 223 175 590 minecraft:ochre_froglight
setblock 223 175 592 minecraft:ochre_froglight
setblock 223 175 594 minecraft:ochre_froglight
setblock 223 175 596 minecraft:ochre_froglight
setblock 223 175 598 minecraft:ochre_froglight
setblock 224 175 589 minecraft:ochre_froglight
setblock 224 175 591 minecraft:ochre_froglight
setblock 224 175 593 minecraft:ochre_froglight
setblock 224 175 595 minecraft:ochre_froglight
setblock 224 175 597 minecraft:ochre_froglight
setblock 225 175 590 minecraft:ochre_froglight
setblock 225 175 592 minecraft:ochre_froglight
setblock 225 175 594 minecraft:ochre_froglight
setblock 225 175 596 minecraft:ochre_froglight
setblock 225 175 598 minecraft:ochre_froglight
setblock 226 175 589 minecraft:ochre_froglight
setblock 226 175 591 minecraft:ochre_froglight
setblock 226 175 593 minecraft:ochre_froglight
setblock 226 175 595 minecraft:ochre_froglight
setblock 226 175 597 minecraft:ochre_froglight
setblock 227 175 590 minecraft:ochre_froglight
setblock 227 175 592 minecraft:ochre_froglight
setblock 227 175 594 minecraft:ochre_froglight
setblock 227 175 596 minecraft:ochre_froglight
setblock 227 175 598 minecraft:ochre_froglight
setblock 228 175 589 minecraft:ochre_froglight
setblock 228 175 591 minecraft:ochre_froglight
setblock 228 175 593 minecraft:ochre_froglight
setblock 228 175 595 minecraft:ochre_froglight
setblock 228 175 597 minecraft:ochre_froglight
setblock 229 175 590 minecraft:ochre_froglight
setblock 229 175 592 minecraft:ochre_froglight
setblock 229 175 594 minecraft:ochre_froglight
setblock 229 175 596 minecraft:ochre_froglight
setblock 229 175 598 minecraft:ochre_froglight
fill 193 176 558 193 177 558 minecraft:quartz_block
fill 193 176 560 193 177 560 minecraft:quartz_block
fill 193 176 562 193 177 562 minecraft:quartz_block
fill 193 176 564 193 177 564 minecraft:quartz_block
fill 194 176 559 194 177 559 minecraft:quartz_block
fill 194 176 561 194 177 561 minecraft:quartz_block
fill 194 176 563 194 177 563 minecraft:quartz_block
fill 195 176 558 195 177 558 minecraft:quartz_block
fill 195 176 560 195 177 560 minecraft:quartz_block
fill 195 176 562 195 177 562 minecraft:quartz_block
fill 195 176 564 195 177 564 minecraft:quartz_block
fill 196 176 559 196 177 559 minecraft:quartz_block
fill 196 176 561 196 177 561 minecraft:quartz_block
fill 196 176 563 196 177 563 minecraft:quartz_block
fill 197 176 558 197 177 558 minecraft:quartz_block
fill 197 176 560 197 177 560 minecraft:quartz_block
fill 197 176 562 197 177 562 minecraft:quartz_block
fill 197 176 564 197 177 564 minecraft:quartz_block
fill 198 176 559 198 177 559 minecraft:quartz_block
fill 198 176 561 198 177 561 minecraft:quartz_block
fill 198 176 563 198 177 563 minecraft:quartz_block
fill 199 176 558 199 177 558 minecraft:quartz_block
fill 199 176 560 199 177 560 minecraft:quartz_block
fill 199 176 562 199 177 562 minecraft:quartz_block
fill 199 176 564 199 177 564 minecraft:quartz_block
fill 200 176 559 200 177 559 minecraft:quartz_block
fill 200 176 561 200 177 561 minecraft:quartz_block
fill 200 176 563 200 177 563 minecraft:quartz_block
fill 201 176 558 201 220 558 minecraft:quartz_block
fill 201 176 560 201 177 560 minecraft:quartz_block
fill 201 176 562 201 177 562 minecraft:quartz_block
fill 201 176 564 201 177 564 minecraft:quartz_block
fill 205 176 596 205 177 596 minecraft:gold_block
fill 219 176 590 219 177 590 minecraft:quartz_block
fill 219 176 592 219 177 592 minecraft:quartz_block
fill 219 176 594 219 177 594 minecraft:quartz_block
fill 219 176 596 219 177 596 minecraft:quartz_block
fill 219 176 598 219 177 598 minecraft:quartz_block
fill 220 176 589 220 177 589 minecraft:quartz_block
fill 220 176 591 220 177 591 minecraft:quartz_block
fill 220 176 593 220 177 593 minecraft:quartz_block
fill 220 176 595 220 177 595 minecraft:quartz_block
fill 220 176 597 220 177 597 minecraft:quartz_block
fill 221 176 590 221 177 590 minecraft:quartz_block
fill 221 176 592 221 177 592 minecraft:quartz_block
fill 221 176 594 221 177 594 minecraft:quartz_block
fill 221 176 596 221 177 596 minecraft:quartz_block
fill 221 176 598 221 177 598 minecraft:quartz_block
fill 222 176 589 222 177 589 minecraft:quartz_block
fill 222 176 591 222 177 591 minecraft:quartz_block
fill 222 176 593 222 177 593 minecraft:quartz_block
fill 222 176 595 222 177 595 minecraft:quartz_block
fill 222 176 597 222 177 597 minecraft:quartz_block
fill 223 176 590 223 177 590 minecraft:quartz_block
fill 223 176 592 223 177 592 minecraft:quartz_block
fill 223 176 594 223 177 594 minecraft:quartz_block
fill 223 176 596 223 177 596 minecraft:quartz_block
fill 223 176 598 223 177 598 minecraft:quartz_block
fill 224 176 589 224 177 589 minecraft:quartz_block
fill 224 176 591 224 177 591 minecraft:quartz_block
fill 224 176 593 224 177 593 minecraft:quartz_block
fill 224 176 595 224 177 595 minecraft:quartz_block
fill 224 176 597 224 177 597 minecraft:quartz_block
fill 225 176 590 225 177 590 minecraft:quartz_block
fill 225 176 592 225 177 592 minecraft:quartz_block
fill 225 176 594 225 177 594 minecraft:quartz_block
fill 225 176 596 225 177 596 minecraft:quartz_block
fill 225 176 598 225 177 598 minecraft:quartz_block
fill 226 176 589 226 177 589 minecraft:quartz_block
fill 226 176 591 226 177 591 minecraft:quartz_block
fill 226 176 593 226 177 593 minecraft:quartz_block
fill 226 176 595 226 177 595 minecraft:quartz_block
fill 226 176 597 226 177 597 minecraft:quartz_block
schedule function dropper:buildpart/136_2 1t
