fill 104 287 356 104 287 357 minecraft:andesite
setblock 105 287 323 minecraft:stripped_spruce_log
setblock 105 287 329 minecraft:andesite
fill 105 287 330 125 287 330 minecraft:stone
fill 105 287 338 105 287 339 minecraft:cobbled_deepslate
fill 105 287 347 105 287 348 minecraft:cobbled_deepslate
fill 105 287 356 125 287 356 minecraft:stone
setblock 105 287 357 minecraft:andesite
fill 106 287 323 106 287 324 minecraft:stone
fill 106 287 328 107 287 328 minecraft:andesite
fill 106 287 329 108 287 329 minecraft:stone
setblock 106 287 336 minecraft:stone
setblock 106 287 337 minecraft:cobbled_deepslate
fill 106 287 349 106 287 350 minecraft:cobbled_deepslate
fill 106 287 357 108 287 357 minecraft:stone
fill 106 287 358 107 287 358 minecraft:andesite
fill 107 287 324 108 287 324 minecraft:stone
fill 107 287 327 109 287 327 minecraft:andesite
setblock 107 287 336 minecraft:cobbled_deepslate
setblock 107 287 351 minecraft:cobbled_deepslate
fill 107 287 352 108 287 352 minecraft:stone
fill 107 287 359 109 287 359 minecraft:andesite
setblock 108 287 328 minecraft:stone
setblock 108 287 334 minecraft:stone
setblock 108 287 335 minecraft:cobbled_deepslate
setblock 108 287 358 minecraft:stone
setblock 109 287 323 minecraft:stone
fill 109 287 334 110 287 334 minecraft:cobbled_deepslate
setblock 109 287 352 minecraft:cobbled_deepslate
setblock 110 287 323 minecraft:stripped_spruce_log
fill 110 287 326 120 287 326 minecraft:andesite
fill 110 287 327 120 287 327 minecraft:stone
fill 110 287 353 112 287 353 minecraft:cobbled_deepslate
fill 110 287 359 120 287 359 minecraft:stone
fill 110 287 360 120 287 360 minecraft:andesite
fill 111 287 323 112 287 323 minecraft:stone
fill 111 287 333 118 287 333 minecraft:cobbled_deepslate
fill 112 287 328 122 287 329 minecraft:stone
fill 112 287 357 122 287 358 minecraft:stone
fill 113 287 354 116 287 354 minecraft:cobbled_deepslate
setblock 115 287 324 minecraft:glowstone
setblock 115 287 362 minecraft:glowstone
fill 117 287 353 119 287 353 minecraft:cobbled_deepslate
fill 117 287 354 127 287 354 minecraft:stone
setblock 119 287 323 minecraft:stone
fill 119 287 333 128 287 333 minecraft:stone
fill 119 287 334 120 287 334 minecraft:cobbled_deepslate
setblock 120 287 323 minecraft:stripped_spruce_log
fill 120 287 324 123 287 324 minecraft:stone
setblock 120 287 352 minecraft:cobbled_deepslate
fill 120 287 353 128 287 353 minecraft:stone
fill 121 287 323 124 287 323 minecraft:stone
fill 121 287 327 123 287 327 minecraft:andesite
fill 121 287 334 129 287 334 minecraft:stone
setblock 121 287 335 minecraft:cobbled_deepslate
setblock 121 287 351 minecraft:cobbled_deepslate
fill 121 287 352 129 287 352 minecraft:stone
fill 121 287 359 123 287 359 minecraft:andesite
setblock 122 287 325 minecraft:stone
fill 122 287 335 129 287 335 minecraft:stone
setblock 122 287 336 minecraft:cobbled_deepslate
fill 122 287 348 122 300 349 minecraft:stripped_spruce_log
setblock 122 287 350 minecraft:cobbled_deepslate
fill 122 287 351 129 287 351 minecraft:stone
fill 122 287 363 124 287 363 minecraft:stone
setblock 123 287 325 minecraft:stripped_spruce_log
fill 123 287 328 124 287 328 minecraft:andesite
fill 123 287 329 124 287 329 minecraft:stone
fill 123 287 336 130 287 336 minecraft:stone
fill 123 287 337 123 287 338 minecraft:cobbled_deepslate
fill 123 287 348 123 300 348 minecraft:stripped_spruce_log
setblock 123 287 349 minecraft:cobbled_deepslate
fill 123 287 350 130 287 350 minecraft:stone
fill 123 287 357 124 287 357 minecraft:stone
fill 123 287 358 124 287 358 minecraft:andesite
setblock 124 287 324 minecraft:stripped_spruce_log
fill 124 287 325 127 287 325 minecraft:stone
fill 124 287 337 130 287 337 minecraft:stone
fill 124 287 338 124 287 340 minecraft:cobbled_deepslate
fill 124 287 346 124 287 348 minecraft:cobbled_deepslate
fill 124 287 349 130 287 349 minecraft:stone
fill 124 287 362 125 287 362 minecraft:stone
setblock 125 287 323 minecraft:stripped_spruce_log
fill 125 287 324 128 287 324 minecraft:stone
setblock 125 287 326 minecraft:stone
fill 125 287 329 126 287 329 minecraft:andesite
fill 125 287 338 131 287 340 minecraft:stone
fill 125 287 341 125 287 346 minecraft:cobbled_deepslate
fill 125 287 347 131 287 348 minecraft:stone
fill 125 287 357 126 287 357 minecraft:andesite
setblock 125 287 363 minecraft:stripped_spruce_log
fill 126 287 323 129 287 323 minecraft:stone
fill 126 287 330 127 287 330 minecraft:andesite
fill 126 287 341 131 287 346 minecraft:stone
fill 126 287 356 127 287 356 minecraft:andesite
setblock 126 287 362 minecraft:stripped_spruce_log
fill 126 287 363 129 287 363 minecraft:stone
fill 127 287 331 128 287 331 minecraft:andesite
fill 127 287 355 128 287 355 minecraft:andesite
fill 127 287 362 127 288 362 minecraft:stone
setblock 128 287 325 minecraft:stripped_spruce_log
fill 128 287 332 129 287 332 minecraft:andesite
fill 128 287 354 129 287 354 minecraft:andesite
setblock 129 287 324 minecraft:stripped_spruce_log
setblock 129 287 325 minecraft:stone
setblock 129 287 333 minecraft:andesite
setblock 129 287 353 minecraft:andesite
setblock 130 287 323 minecraft:stripped_spruce_log
setblock 130 287 324 minecraft:stone
fill 130 287 334 130 287 335 minecraft:andesite
fill 130 287 351 130 287 352 minecraft:andesite
setblock 130 287 363 minecraft:stripped_spruce_log
fill 131 287 323 131 288 323 minecraft:stone
fill 131 287 335 131 287 337 minecraft:andesite
fill 131 287 349 131 287 351 minecraft:andesite
fill 131 287 363 131 288 363 minecraft:stone
fill 132 287 338 132 287 348 minecraft:andesite
setblock 134 287 324 minecraft:glowstone
setblock 134 287 343 minecraft:glowstone
fill 134 287 350 134 287 353 minecraft:stone
setblock 134 287 354 minecraft:stripped_spruce_log
fill 134 287 355 134 288 355 minecraft:stone
setblock 134 287 362 minecraft:glowstone
setblock 135 287 348 minecraft:stripped_spruce_log
fill 135 287 349 135 288 349 minecraft:stone
setblock 135 287 353 minecraft:stripped_spruce_log
fill 135 287 354 135 288 354 minecraft:stone
setblock 135 287 357 minecraft:stone
setblock 135 287 358 minecraft:stripped_spruce_log
fill 135 287 359 135 288 359 minecraft:stone
fill 135 287 364 135 306 364 minecraft:stone
fill 94 288 344 94 304 345 minecraft:stone
fill 94 288 350 94 289 352 minecraft:stone
setblock 95 288 346 minecraft:stone
setblock 95 288 347 minecraft:stripped_spruce_log
setblock 95 288 348 minecraft:stone
fill 95 288 350 95 288 351 minecraft:stone
setblock 95 288 352 minecraft:stripped_spruce_log
setblock 95 288 353 minecraft:stone
setblock 95 288 356 minecraft:stone
setblock 95 288 357 minecraft:stripped_spruce_log
fill 96 288 324 96 289 324 minecraft:spruce_log
fill 96 288 343 96 289 343 minecraft:spruce_log
setblock 96 288 350 minecraft:stone
setblock 96 288 351 minecraft:stripped_spruce_log
setblock 96 288 352 minecraft:stone
fill 96 288 362 96 289 362 minecraft:spruce_log
fill 97 288 325 97 290 325 minecraft:cobbled_deepslate
fill 97 288 327 97 290 327 minecraft:cobbled_deepslate
setblock 97 288 332 minecraft:light[level=12]
setblock 97 288 339 minecraft:light[level=12]
setblock 97 288 346 minecraft:light[level=12]
setblock 97 288 353 minecraft:light[level=12]
setblock 97 288 360 minecraft:light[level=12]
fill 99 288 325 99 290 325 minecraft:cobbled_deepslate
fill 99 288 327 99 290 327 minecraft:cobbled_deepslate
fill 99 288 338 99 288 348 minecraft:andesite
fill 100 288 336 100 288 340 minecraft:andesite
fill 100 288 341 102 288 345 minecraft:stone
fill 100 288 346 100 288 350 minecraft:andesite
fill 101 288 334 101 288 337 minecraft:andesite
fill 101 288 338 103 288 340 minecraft:stone
fill 101 288 346 103 288 348 minecraft:stone
fill 101 288 349 101 288 352 minecraft:andesite
fill 102 288 333 102 288 335 minecraft:andesite
fill 102 288 336 104 288 337 minecraft:stone
fill 102 288 349 104 288 350 minecraft:stone
fill 102 288 351 102 288 353 minecraft:andesite
fill 103 288 332 103 288 333 minecraft:andesite
fill 103 288 334 106 288 335 minecraft:stone
setblock 103 288 341 minecraft:stone
fill 103 288 342 103 288 345 minecraft:spruce_planks
fill 103 288 351 106 288 352 minecraft:stone
fill 103 288 353 103 288 354 minecraft:andesite
fill 104 288 322 104 308 322 minecraft:stone
setblock 104 288 323 minecraft:stripped_spruce_log
setblock 104 288 325 minecraft:light[level=12]
fill 104 288 331 104 288 332 minecraft:andesite
fill 104 288 333 108 288 333 minecraft:stone
setblock 104 288 338 minecraft:stone
fill 104 288 339 104 288 341 minecraft:spruce_planks
fill 104 288 346 104 288 348 minecraft:spruce_planks
fill 104 288 353 108 288 353 minecraft:stone
fill 104 288 354 104 288 355 minecraft:andesite
setblock 104 288 360 minecraft:light[level=12]
fill 105 288 323 106 288 323 minecraft:stone
fill 105 288 330 105 288 331 minecraft:andesite
fill 105 288 332 110 288 332 minecraft:stone
setblock 105 288 336 minecraft:stone
fill 105 288 337 105 288 338 minecraft:spruce_planks
setblock 105 288 349 minecraft:spruce_planks
setblock 105 288 350 minecraft:stone
fill 105 288 354 110 288 354 minecraft:stone
fill 105 288 355 105 288 356 minecraft:andesite
fill 106 288 329 107 288 330 minecraft:andesite
fill 106 288 331 124 288 331 minecraft:stone
setblock 106 288 336 minecraft:spruce_planks
setblock 106 288 350 minecraft:spruce_planks
fill 106 288 355 124 288 355 minecraft:stone
fill 106 288 356 107 288 357 minecraft:andesite
setblock 107 288 334 minecraft:stone
setblock 107 288 335 minecraft:spruce_planks
setblock 107 288 351 minecraft:spruce_planks
setblock 107 288 352 minecraft:stone
fill 108 288 328 109 288 329 minecraft:andesite
fill 108 288 330 122 288 330 minecraft:stone
setblock 108 288 334 minecraft:spruce_planks
setblock 108 288 352 minecraft:spruce_planks
fill 108 288 356 122 288 356 minecraft:stone
fill 108 288 357 109 288 358 minecraft:andesite
setblock 109 288 323 minecraft:stripped_spruce_log
fill 109 288 333 110 288 333 minecraft:spruce_planks
fill 109 288 353 110 288 353 minecraft:spruce_planks
fill 110 288 327 112 288 328 minecraft:andesite
fill 110 288 329 120 288 329 minecraft:stone
fill 110 288 357 120 288 357 minecraft:stone
fill 110 288 358 112 288 359 minecraft:andesite
setblock 111 288 325 minecraft:light[level=12]
fill 111 288 332 118 288 332 minecraft:spruce_planks
setblock 111 288 339 minecraft:light[level=12]
setblock 111 288 346 minecraft:light[level=12]
setblock 111 288 353 minecraft:light[level=12]
fill 111 288 354 118 288 354 minecraft:spruce_planks
setblock 111 288 360 minecraft:light[level=12]
fill 113 288 327 120 288 327 minecraft:andesite
fill 113 288 328 117 288 328 minecraft:stone
fill 113 288 358 117 288 358 minecraft:stone
fill 113 288 359 120 288 359 minecraft:andesite
fill 115 288 324 115 289 324 minecraft:spruce_log
fill 115 288 362 115 289 362 minecraft:spruce_log
setblock 118 288 325 minecraft:light[level=12]
fill 118 288 328 122 288 328 minecraft:andesite
setblock 118 288 339 minecraft:light[level=12]
setblock 118 288 346 minecraft:light[level=12]
setblock 118 288 353 minecraft:light[level=12]
fill 118 288 358 122 288 358 minecraft:andesite
setblock 118 288 360 minecraft:light[level=12]
setblock 119 288 323 minecraft:stripped_spruce_log
fill 119 288 332 125 288 332 minecraft:stone
fill 119 288 333 120 288 333 minecraft:spruce_planks
fill 119 288 353 120 288 353 minecraft:spruce_planks
fill 119 288 354 125 288 354 minecraft:stone
fill 120 288 323 122 288 324 minecraft:stone
fill 121 288 329 124 288 329 minecraft:andesite
fill 121 288 333 126 288 333 minecraft:stone
fill 121 288 334 122 288 334 minecraft:spruce_planks
fill 121 288 352 122 288 352 minecraft:spruce_planks
fill 121 288 353 126 288 353 minecraft:stone
fill 121 288 357 124 288 357 minecraft:andesite
fill 121 288 363 123 288 363 minecraft:stone
fill 122 288 335 123 288 335 minecraft:spruce_planks
fill 122 288 351 123 288 351 minecraft:spruce_planks
setblock 123 288 323 minecraft:stone
setblock 123 288 324 minecraft:stripped_spruce_log
fill 123 288 325 126 288 325 minecraft:stone
fill 123 288 330 125 288 330 minecraft:andesite
fill 123 288 334 127 288 334 minecraft:stone
fill 123 288 336 124 288 336 minecraft:spruce_planks
fill 123 288 349 123 300 349 minecraft:stripped_spruce_log
fill 123 288 350 124 288 350 minecraft:spruce_planks
fill 123 288 352 127 288 352 minecraft:stone
fill 123 288 356 125 288 356 minecraft:andesite
setblock 124 288 322 minecraft:diamond_block
setblock 124 288 323 minecraft:stripped_spruce_log
fill 124 288 324 127 288 324 minecraft:stone
fill 124 288 335 127 288 335 minecraft:stone
setblock 124 288 337 minecraft:spruce_planks
setblock 124 288 349 minecraft:spruce_planks
fill 124 288 351 127 288 351 minecraft:stone
setblock 124 288 362 minecraft:stone
setblock 124 288 363 minecraft:stripped_spruce_log
fill 125 288 323 128 288 323 minecraft:stone
fill 125 288 331 126 288 331 minecraft:andesite
fill 125 288 336 128 288 337 minecraft:stone
fill 125 288 338 125 288 340 minecraft:spruce_planks
setblock 125 288 346 minecraft:light[level=12]
fill 125 288 347 125 288 348 minecraft:spruce_planks
fill 125 288 349 128 288 350 minecraft:stone
fill 125 288 355 126 288 355 minecraft:andesite
setblock 125 288 360 minecraft:light[level=12]
setblock 125 288 362 minecraft:stripped_spruce_log
fill 125 288 363 128 288 363 minecraft:stone
setblock 125 288 364 minecraft:raw_gold_block
fill 126 288 332 127 288 332 minecraft:andesite
fill 126 288 338 129 288 339 minecraft:stone
fill 126 288 340 126 288 346 minecraft:spruce_planks
fill 126 288 347 129 288 348 minecraft:stone
fill 126 288 354 127 288 354 minecraft:andesite
setblock 126 288 362 minecraft:stone
setblock 127 288 325 minecraft:stripped_spruce_log
fill 127 288 333 128 288 333 minecraft:andesite
fill 127 288 340 129 288 346 minecraft:stone
fill 127 288 353 128 288 353 minecraft:andesite
setblock 128 288 324 minecraft:stripped_spruce_log
fill 128 288 334 129 288 335 minecraft:andesite
fill 128 288 351 129 288 352 minecraft:andesite
setblock 129 288 323 minecraft:stripped_spruce_log
setblock 129 288 324 minecraft:stone
fill 129 288 336 130 288 337 minecraft:andesite
fill 129 288 349 130 288 350 minecraft:andesite
setblock 129 288 363 minecraft:stripped_spruce_log
setblock 130 288 323 minecraft:stone
fill 130 288 338 131 288 340 minecraft:andesite
fill 130 288 341 130 288 345 minecraft:stone
fill 130 288 346 131 288 348 minecraft:andesite
setblock 130 288 363 minecraft:stone
fill 131 288 341 131 288 345 minecraft:andesite
setblock 132 288 325 minecraft:light[level=12]
setblock 132 288 332 minecraft:light[level=12]
setblock 132 288 339 minecraft:light[level=12]
setblock 132 288 346 minecraft:light[level=12]
setblock 132 288 353 minecraft:light[level=12]
setblock 132 288 360 minecraft:light[level=12]
fill 134 288 324 134 289 324 minecraft:spruce_log
fill 134 288 343 134 289 343 minecraft:spruce_log
fill 134 288 351 134 288 352 minecraft:stone
setblock 134 288 353 minecraft:stripped_spruce_log
setblock 134 288 354 minecraft:stone
fill 134 288 362 134 289 362 minecraft:spruce_log
setblock 135 288 352 minecraft:stripped_spruce_log
setblock 135 288 353 minecraft:stone
setblock 135 288 357 minecraft:stripped_spruce_log
setblock 135 288 358 minecraft:stone
setblock 94 289 361 minecraft:raw_gold_block
fill 95 289 323 95 289 363 minecraft:spruce_planks
fill 96 289 323 135 289 323 minecraft:spruce_planks
fill 96 289 325 96 289 342 minecraft:spruce_planks
fill 96 289 344 96 289 361 minecraft:spruce_planks
fill 96 289 363 135 289 363 minecraft:spruce_planks
fill 97 289 324 114 289 324 minecraft:spruce_planks
fill 97 289 362 114 289 362 minecraft:spruce_planks
fill 100 289 341 102 289 345 minecraft:andesite
fill 101 289 338 102 289 340 minecraft:andesite
fill 101 289 346 102 289 348 minecraft:andesite
fill 102 289 336 103 289 337 minecraft:andesite
fill 102 289 349 103 289 350 minecraft:andesite
fill 103 289 334 105 289 335 minecraft:andesite
setblock 103 289 338 minecraft:andesite
fill 103 289 339 103 289 347 minecraft:cobbled_deepslate
setblock 103 289 348 minecraft:andesite
fill 103 289 351 105 289 352 minecraft:andesite
fill 104 289 333 107 289 333 minecraft:andesite
setblock 104 289 336 minecraft:andesite
fill 104 289 337 104 289 338 minecraft:cobbled_deepslate
fill 104 289 348 104 289 349 minecraft:cobbled_deepslate
setblock 104 289 350 minecraft:andesite
fill 104 289 353 107 289 353 minecraft:andesite
fill 105 289 332 109 289 332 minecraft:andesite
setblock 105 289 336 minecraft:cobbled_deepslate
setblock 105 289 350 minecraft:cobbled_deepslate
fill 105 289 354 108 289 354 minecraft:andesite
fill 106 289 331 111 289 331 minecraft:andesite
setblock 106 289 334 minecraft:andesite
setblock 106 289 335 minecraft:cobbled_deepslate
setblock 106 289 351 minecraft:cobbled_deepslate
setblock 106 289 352 minecraft:andesite
fill 106 289 355 111 289 355 minecraft:andesite
setblock 107 289 334 minecraft:cobbled_deepslate
setblock 107 289 352 minecraft:cobbled_deepslate
fill 108 289 330 122 289 330 minecraft:andesite
fill 108 289 333 109 289 333 minecraft:cobbled_deepslate
setblock 108 289 353 minecraft:cobbled_deepslate
fill 108 289 356 122 289 356 minecraft:andesite
fill 109 289 354 111 289 354 minecraft:cobbled_deepslate
fill 110 289 329 120 289 329 minecraft:andesite
fill 110 289 332 111 289 332 minecraft:cobbled_deepslate
fill 110 289 357 120 289 357 minecraft:andesite
fill 112 289 331 118 289 331 minecraft:cobbled_deepslate
fill 112 289 355 118 289 355 minecraft:cobbled_deepslate
fill 113 289 328 117 289 328 minecraft:andesite
fill 113 289 358 117 289 358 minecraft:andesite
setblock 115 289 322 minecraft:gold_block
fill 116 289 324 133 289 324 minecraft:spruce_planks
fill 116 289 362 133 289 362 minecraft:spruce_planks
fill 118 289 322 118 308 322 minecraft:stone
fill 119 289 331 124 289 331 minecraft:andesite
fill 119 289 332 120 289 332 minecraft:cobbled_deepslate
fill 119 289 354 120 289 354 minecraft:cobbled_deepslate
fill 119 289 355 124 289 355 minecraft:andesite
fill 121 289 332 125 289 332 minecraft:andesite
fill 121 289 333 122 289 333 minecraft:cobbled_deepslate
fill 121 289 353 122 289 353 minecraft:cobbled_deepslate
fill 121 289 354 125 289 354 minecraft:andesite
fill 123 289 333 126 289 333 minecraft:andesite
setblock 123 289 334 minecraft:cobbled_deepslate
setblock 123 289 352 minecraft:cobbled_deepslate
fill 123 289 353 126 289 353 minecraft:andesite
fill 124 289 322 124 299 322 minecraft:stone
fill 124 289 334 127 289 334 minecraft:andesite
setblock 124 289 335 minecraft:cobbled_deepslate
setblock 124 289 351 minecraft:cobbled_deepslate
fill 124 289 352 127 289 352 minecraft:andesite
fill 125 289 335 127 289 335 minecraft:andesite
fill 125 289 336 125 289 337 minecraft:cobbled_deepslate
fill 125 289 349 125 289 350 minecraft:cobbled_deepslate
fill 125 289 351 127 289 351 minecraft:andesite
fill 125 289 364 125 308 364 minecraft:stone
fill 126 289 336 128 289 337 minecraft:andesite
fill 126 289 338 126 289 339 minecraft:cobbled_deepslate
fill 126 289 347 126 289 348 minecraft:cobbled_deepslate
fill 126 289 349 128 289 350 minecraft:andesite
fill 127 289 338 129 289 339 minecraft:andesite
fill 127 289 340 127 289 346 minecraft:cobbled_deepslate
fill 127 289 347 129 289 348 minecraft:andesite
fill 128 289 340 129 289 346 minecraft:andesite
fill 130 289 341 130 289 345 minecraft:andesite
fill 131 289 327 131 290 327 minecraft:cobbled_deepslate
fill 132 289 326 132 290 326 minecraft:cobbled_deepslate
fill 132 289 328 132 290 328 minecraft:cobbled_deepslate
fill 133 289 327 133 290 327 minecraft:cobbled_deepslate
fill 134 289 325 135 289 342 minecraft:spruce_planks
fill 134 289 344 135 289 361 minecraft:spruce_planks
setblock 135 289 324 minecraft:spruce_planks
setblock 135 289 343 minecraft:spruce_planks
setblock 135 289 362 minecraft:spruce_planks
setblock 136 289 326 minecraft:diamond_block
setblock 94 290 327 minecraft:gold_block
setblock 94 290 350 minecraft:diamond_block
fill 94 290 351 95 292 352 minecraft:stone
fill 94 290 361 94 308 361 minecraft:stone
setblock 95 290 349 minecraft:stone
setblock 95 290 350 minecraft:stripped_spruce_log
fill 95 290 353 95 290 354 minecraft:stone
setblock 95 290 355 minecraft:stripped_spruce_log
fill 95 290 356 95 292 357 minecraft:stone
setblock 96 290 326 minecraft:cobbled_deepslate
fill 96 290 352 96 290 353 minecraft:stone
setblock 96 290 354 minecraft:stripped_spruce_log
setblock 97 290 333 minecraft:light[level=15]
setblock 97 290 341 minecraft:light[level=15]
setblock 97 290 349 minecraft:light[level=15]
setblock 97 290 357 minecraft:light[level=15]
setblock 98 290 324 minecraft:cobbled_deepslate
setblock 98 290 328 minecraft:cobbled_deepslate
setblock 100 290 326 minecraft:cobbled_deepslate
setblock 105 290 325 minecraft:light[level=15]
setblock 105 290 333 minecraft:light[level=15]
setblock 105 290 341 minecraft:light[level=15]
setblock 105 290 349 minecraft:light[level=15]
setblock 105 290 357 minecraft:light[level=15]
setblock 105 290 364 minecraft:diamond_block
setblock 113 290 325 minecraft:light[level=15]
setblock 113 290 333 minecraft:light[level=15]
setblock 113 290 341 minecraft:light[level=15]
setblock 113 290 349 minecraft:light[level=15]
setblock 113 290 357 minecraft:light[level=15]
fill 115 290 322 115 308 322 minecraft:stone
fill 119 290 323 121 290 323 minecraft:stone
setblock 121 290 325 minecraft:light[level=15]
setblock 121 290 333 minecraft:light[level=15]
setblock 121 290 341 minecraft:light[level=15]
setblock 121 290 357 minecraft:light[level=15]
setblock 121 290 363 minecraft:stone
setblock 122 290 323 minecraft:stripped_spruce_log
fill 122 290 324 125 290 324 minecraft:stone
setblock 122 290 363 minecraft:stripped_spruce_log
fill 123 290 323 126 290 323 minecraft:stone
setblock 123 290 362 minecraft:stripped_spruce_log
fill 123 290 363 126 290 363 minecraft:stone
fill 124 290 362 127 290 362 minecraft:stone
setblock 126 290 324 minecraft:stripped_spruce_log
setblock 127 290 323 minecraft:stripped_spruce_log
setblock 127 290 363 minecraft:stripped_spruce_log
setblock 128 290 323 minecraft:stone
fill 128 290 363 130 290 363 minecraft:stone
setblock 129 290 325 minecraft:light[level=15]
setblock 129 290 333 minecraft:light[level=15]
setblock 129 290 341 minecraft:light[level=15]
setblock 129 290 349 minecraft:light[level=15]
setblock 129 290 357 minecraft:light[level=15]
fill 134 290 354 134 290 355 minecraft:stone
setblock 134 290 356 minecraft:stripped_spruce_log
setblock 135 290 350 minecraft:stripped_spruce_log
fill 135 290 351 135 290 354 minecraft:stone
setblock 135 290 355 minecraft:stripped_spruce_log
fill 135 290 356 135 290 359 minecraft:stone
fill 136 290 326 136 296 326 minecraft:stone
setblock 136 290 339 minecraft:raw_gold_block
fill 94 291 327 94 308 327 minecraft:stone
setblock 94 291 332 minecraft:raw_gold_block
fill 94 291 350 95 294 350 minecraft:stone
setblock 95 291 349 minecraft:stripped_spruce_log
setblock 95 291 353 minecraft:stone
setblock 95 291 354 minecraft:stripped_spruce_log
fill 95 291 355 95 294 355 minecraft:stone
setblock 95 291 358 minecraft:stone
setblock 96 291 353 minecraft:stripped_spruce_log
fill 96 291 354 96 294 354 minecraft:stone
fill 97 291 360 99 291 362 minecraft:raw_gold_block
fill 98 291 322 98 297 322 minecraft:stone
fill 98 291 358 98 292 359 minecraft:raw_gold_block
fill 98 291 363 98 292 363 minecraft:raw_gold_block
setblock 99 291 322 minecraft:diamond_block
fill 100 291 322 100 292 322 minecraft:stone
fill 105 291 364 105 308 364 minecraft:stone
fill 119 291 323 120 291 323 minecraft:stone
setblock 120 291 363 minecraft:stone
setblock 121 291 323 minecraft:stripped_spruce_log
setblock 121 291 363 minecraft:stripped_spruce_log
fill 122 291 323 124 291 324 minecraft:stone
fill 122 291 325 122 292 325 minecraft:iron_bars
setblock 122 291 362 minecraft:stripped_spruce_log
fill 122 291 363 125 291 363 minecraft:stone
fill 123 291 362 126 291 362 minecraft:stone
setblock 123 291 364 minecraft:gold_block
setblock 125 291 323 minecraft:stone
setblock 126 291 323 minecraft:stripped_spruce_log
setblock 126 291 363 minecraft:stripped_spruce_log
setblock 127 291 323 minecraft:stone
setblock 127 291 362 minecraft:stripped_spruce_log
fill 127 291 363 129 292 363 minecraft:stone
setblock 130 291 364 minecraft:diamond_block
setblock 134 291 354 minecraft:stone
setblock 134 291 355 minecraft:stripped_spruce_log
fill 134 291 356 135 293 356 minecraft:stone
fill 135 291 351 135 291 353 minecraft:stone
setblock 135 291 354 minecraft:stripped_spruce_log
fill 135 291 355 135 294 355 minecraft:stone
fill 135 291 357 135 291 358 minecraft:stone
setblock 135 291 359 minecraft:stripped_spruce_log
fill 135 291 360 135 294 360 minecraft:stone
fill 136 291 339 136 308 339 minecraft:stone
setblock 136 291 349 minecraft:diamond_block
fill 94 292 332 94 300 332 minecraft:stone
fill 95 292 334 95 292 337 minecraft:stone
setblock 95 292 353 minecraft:stripped_spruce_log
fill 95 292 354 95 295 354 minecraft:stone
setblock 95 292 358 minecraft:stripped_spruce_log
fill 96 292 355 96 293 355 minecraft:stone
fill 97 292 361 99 292 362 minecraft:raw_gold_block
setblock 98 292 360 minecraft:raw_gold_block
fill 99 292 322 99 308 322 minecraft:stone
fill 111 292 364 111 296 364 minecraft:stone
setblock 112 292 364 minecraft:raw_iron_block
setblock 119 292 323 minecraft:stone
setblock 119 292 363 minecraft:stone
setblock 120 292 323 minecraft:stripped_spruce_log
setblock 120 292 363 minecraft:stripped_spruce_log
fill 121 292 323 124 292 323 minecraft:stone
setblock 121 292 362 minecraft:stripped_spruce_log
fill 121 292 363 124 292 363 minecraft:stone
fill 122 292 324 123 292 324 minecraft:stone
fill 122 292 362 125 292 362 minecraft:stone
fill 123 292 364 123 308 364 minecraft:stone
setblock 125 292 323 minecraft:stripped_spruce_log
setblock 125 292 363 minecraft:stripped_spruce_log
fill 126 292 323 126 295 323 minecraft:stone
setblock 126 292 362 minecraft:stripped_spruce_log
fill 126 292 363 126 295 363 minecraft:stone
fill 127 292 362 127 295 362 minecraft:stone
fill 130 292 364 130 294 364 minecraft:stone
setblock 134 292 354 minecraft:stripped_spruce_log
fill 134 292 355 134 295 355 minecraft:stone
fill 134 292 357 135 292 357 minecraft:stone
fill 135 292 351 135 292 352 minecraft:stone
setblock 135 292 353 minecraft:stripped_spruce_log
fill 135 292 354 135 295 354 minecraft:stone
setblock 135 292 358 minecraft:stripped_spruce_log
fill 135 292 359 135 295 359 minecraft:stone
setblock 136 292 343 minecraft:raw_gold_block
fill 136 292 349 136 308 349 minecraft:stone
fill 94 293 351 94 306 352 minecraft:stone
fill 95 293 333 95 293 336 minecraft:stone
setblock 95 293 337 minecraft:stripped_spruce_log
fill 95 293 338 95 294 340 minecraft:stone
setblock 95 293 351 minecraft:stone
setblock 95 293 352 minecraft:stripped_spruce_log
fill 95 293 353 96 295 353 minecraft:stone
setblock 95 293 356 minecraft:stone
setblock 95 293 357 minecraft:stripped_spruce_log
fill 95 293 358 95 295 359 minecraft:stone
setblock 96 293 335 minecraft:stone
setblock 96 293 336 minecraft:stripped_spruce_log
fill 96 293 337 96 296 337 minecraft:stone
setblock 96 293 356 minecraft:stripped_spruce_log
setblock 100 293 322 minecraft:diamond_block
fill 112 293 364 112 308 364 minecraft:stone
setblock 114 293 364 minecraft:raw_gold_block
setblock 115 293 364 minecraft:gold_block
setblock 117 293 364 minecraft:raw_gold_block
setblock 118 293 323 minecraft:stone
setblock 118 293 363 minecraft:stone
setblock 119 293 323 minecraft:stripped_spruce_log
setblock 119 293 363 minecraft:stripped_spruce_log
fill 120 293 323 123 293 323 minecraft:stone
setblock 120 293 362 minecraft:stripped_spruce_log
fill 120 293 363 123 293 363 minecraft:stone
fill 121 293 324 122 293 324 minecraft:stone
fill 121 293 362 124 293 362 minecraft:stone
fill 122 293 361 125 293 361 minecraft:stone
setblock 123 293 324 minecraft:stripped_spruce_log
setblock 124 293 323 minecraft:stripped_spruce_log
setblock 124 293 363 minecraft:stripped_spruce_log
fill 125 293 323 125 296 323 minecraft:stone
setblock 125 293 362 minecraft:stripped_spruce_log
fill 125 293 363 125 296 363 minecraft:stone
fill 126 293 362 126 296 362 minecraft:stone
fill 127 293 363 128 293 363 minecraft:stone
fill 128 293 362 128 294 362 minecraft:stone
setblock 129 293 363 minecraft:stripped_spruce_log
fill 130 293 363 130 296 363 minecraft:stone
fill 134 293 354 134 296 354 minecraft:stone
setblock 134 293 357 minecraft:stone
setblock 134 293 358 minecraft:stripped_spruce_log
setblock 134 293 364 minecraft:gold_block
setblock 135 293 351 minecraft:stone
setblock 135 293 352 minecraft:stripped_spruce_log
fill 135 293 353 135 296 353 minecraft:stone
setblock 135 293 357 minecraft:stripped_spruce_log
fill 135 293 358 135 296 358 minecraft:stone
setblock 135 293 361 minecraft:stone
fill 136 293 343 136 308 343 minecraft:stone
setblock 136 293 358 minecraft:gold_block
setblock 94 294 329 minecraft:raw_gold_block
fill 94 294 341 94 308 341 minecraft:stone
setblock 94 294 342 minecraft:raw_gold_block
fill 95 294 332 95 294 335 minecraft:stone
setblock 95 294 336 minecraft:stripped_spruce_log
fill 95 294 337 95 297 337 minecraft:stone
setblock 95 294 341 minecraft:stripped_spruce_log
fill 95 294 342 95 296 343 minecraft:stone
fill 95 294 349 95 295 349 minecraft:stone
setblock 95 294 351 minecraft:stripped_spruce_log
fill 95 294 352 95 297 352 minecraft:stone
setblock 95 294 356 minecraft:stripped_spruce_log
fill 95 294 357 96 296 357 minecraft:stone
setblock 95 294 360 minecraft:stone
fill 96 294 333 96 294 334 minecraft:stone
setblock 96 294 335 minecraft:stripped_spruce_log
fill 96 294 336 97 296 336 minecraft:stone
fill 96 294 338 96 294 339 minecraft:stone
setblock 96 294 340 minecraft:stripped_spruce_log
setblock 96 294 355 minecraft:stripped_spruce_log
fill 96 294 356 96 297 356 minecraft:stone
fill 96 294 358 96 295 358 minecraft:stone
setblock 97 294 325 minecraft:light[level=12]
setblock 97 294 332 minecraft:light[level=12]
fill 97 294 337 97 294 338 minecraft:stone
setblock 97 294 339 minecraft:light[level=12]
setblock 97 294 346 minecraft:light[level=12]
setblock 97 294 353 minecraft:light[level=12]
setblock 97 294 360 minecraft:light[level=12]
fill 100 294 322 100 308 322 minecraft:stone
fill 100 294 363 102 294 363 minecraft:stone
setblock 103 294 323 minecraft:stripped_spruce_log
setblock 103 294 363 minecraft:stripped_spruce_log
setblock 104 294 325 minecraft:light[level=12]
setblock 104 294 332 minecraft:light[level=12]
setblock 104 294 339 minecraft:light[level=12]
setblock 104 294 346 minecraft:light[level=12]
setblock 104 294 353 minecraft:light[level=12]
setblock 104 294 360 minecraft:light[level=12]
setblock 111 294 325 minecraft:light[level=12]
setblock 111 294 332 minecraft:light[level=12]
setblock 111 294 339 minecraft:light[level=12]
setblock 111 294 346 minecraft:light[level=12]
setblock 111 294 353 minecraft:light[level=12]
setblock 111 294 360 minecraft:light[level=12]
fill 114 294 364 115 308 364 minecraft:stone
setblock 116 294 322 minecraft:diamond_block
fill 116 294 323 117 294 323 minecraft:stone
fill 116 294 363 117 294 363 minecraft:stone
fill 117 294 364 117 308 364 minecraft:stone
setblock 118 294 323 minecraft:stripped_spruce_log
setblock 118 294 325 minecraft:light[level=12]
setblock 118 294 332 minecraft:light[level=12]
setblock 118 294 339 minecraft:light[level=12]
setblock 118 294 346 minecraft:light[level=12]
setblock 118 294 353 minecraft:light[level=12]
setblock 118 294 360 minecraft:light[level=12]
setblock 118 294 362 minecraft:stone
setblock 118 294 363 minecraft:stripped_spruce_log
fill 119 294 323 122 294 323 minecraft:stone
setblock 119 294 362 minecraft:stripped_spruce_log
fill 119 294 363 122 294 363 minecraft:stone
fill 120 294 324 121 294 324 minecraft:stone
setblock 120 294 361 minecraft:stripped_spruce_log
fill 120 294 362 123 294 362 minecraft:stone
fill 121 294 361 124 294 361 minecraft:stone
setblock 122 294 324 minecraft:stripped_spruce_log
setblock 123 294 323 minecraft:stripped_spruce_log
fill 123 294 324 123 297 324 minecraft:stone
setblock 123 294 363 minecraft:stripped_spruce_log
fill 124 294 323 124 297 323 minecraft:stone
setblock 124 294 362 minecraft:stripped_spruce_log
fill 124 294 363 124 297 363 minecraft:stone
setblock 125 294 325 minecraft:light[level=12]
setblock 125 294 332 minecraft:light[level=12]
setblock 125 294 339 minecraft:light[level=12]
setblock 125 294 346 minecraft:light[level=12]
setblock 125 294 353 minecraft:light[level=12]
setblock 125 294 360 minecraft:light[level=12]
setblock 125 294 361 minecraft:stripped_spruce_log
fill 125 294 362 125 297 362 minecraft:stone
fill 126 294 361 126 297 361 minecraft:stone
setblock 127 294 363 minecraft:stone
setblock 128 294 363 minecraft:stripped_spruce_log
fill 129 294 363 129 297 363 minecraft:stone
setblock 130 294 322 minecraft:raw_iron_block
fill 131 294 363 131 295 363 minecraft:stone
setblock 132 294 325 minecraft:light[level=12]
setblock 132 294 332 minecraft:light[level=12]
setblock 132 294 339 minecraft:light[level=12]
setblock 132 294 346 minecraft:light[level=12]
setblock 132 294 353 minecraft:light[level=12]
setblock 132 294 360 minecraft:light[level=12]
setblock 134 294 356 minecraft:stone
setblock 134 294 357 minecraft:stripped_spruce_log
fill 134 294 358 134 295 360 minecraft:stone
fill 134 294 364 134 299 364 minecraft:stone
setblock 135 294 350 minecraft:stone
setblock 135 294 351 minecraft:stripped_spruce_log
fill 135 294 352 135 297 352 minecraft:stone
setblock 135 294 356 minecraft:stripped_spruce_log
fill 135 294 357 135 297 357 minecraft:stone
setblock 135 294 361 minecraft:stripped_spruce_log
fill 135 294 362 135 297 362 minecraft:stone
setblock 136 294 356 minecraft:gold_block
fill 136 294 358 136 308 358 minecraft:stone
fill 94 295 329 94 296 329 minecraft:stone
fill 94 295 342 94 308 342 minecraft:stone
fill 94 295 350 94 308 350 minecraft:stone
fill 95 295 331 95 295 334 minecraft:stone
setblock 95 295 335 minecraft:stripped_spruce_log
fill 95 295 336 95 298 336 minecraft:stone
fill 95 295 338 95 295 339 minecraft:stone
setblock 95 295 340 minecraft:stripped_spruce_log
fill 95 295 341 97 296 341 minecraft:stone
setblock 95 295 344 minecraft:stone
setblock 95 295 345 minecraft:stripped_spruce_log
fill 95 295 346 95 296 348 minecraft:stone
setblock 95 295 350 minecraft:stripped_spruce_log
fill 95 295 351 95 298 351 minecraft:stone
setblock 95 295 355 minecraft:stripped_spruce_log
fill 95 295 356 95 298 356 minecraft:stone
setblock 95 295 360 minecraft:stripped_spruce_log
fill 95 295 361 95 298 361 minecraft:stone
setblock 96 295 333 minecraft:stone
setblock 96 295 334 minecraft:stripped_spruce_log
fill 96 295 335 97 297 335 minecraft:stone
setblock 96 295 338 minecraft:stone
setblock 96 295 339 minecraft:stripped_spruce_log
fill 96 295 340 97 297 340 minecraft:stone
fill 96 295 342 96 295 343 minecraft:stone
fill 96 295 352 96 296 352 minecraft:stone
setblock 96 295 354 minecraft:stripped_spruce_log
fill 96 295 355 96 298 355 minecraft:stone
setblock 96 295 359 minecraft:stripped_spruce_log
fill 97 295 334 97 298 334 minecraft:stone
setblock 97 295 337 minecraft:stone
setblock 97 295 338 minecraft:stripped_spruce_log
fill 97 295 339 97 298 339 minecraft:stone
setblock 98 295 336 minecraft:stone
setblock 98 295 337 minecraft:stripped_spruce_log
fill 98 295 338 98 298 338 minecraft:stone
fill 98 295 363 101 295 363 minecraft:stone
fill 100 295 323 101 295 323 minecraft:stone
setblock 102 295 323 minecraft:stripped_spruce_log
setblock 102 295 363 minecraft:stripped_spruce_log
fill 103 295 323 105 296 323 minecraft:stone
fill 103 295 363 105 296 363 minecraft:stone
fill 115 295 323 116 295 323 minecraft:stone
fill 115 295 363 116 295 363 minecraft:stone
fill 116 295 322 116 306 322 minecraft:stone
setblock 117 295 323 minecraft:stripped_spruce_log
setblock 117 295 362 minecraft:stone
setblock 117 295 363 minecraft:stripped_spruce_log
fill 118 295 323 120 295 324 minecraft:stone
setblock 118 295 361 minecraft:stone
setblock 118 295 362 minecraft:stripped_spruce_log
fill 118 295 363 121 295 363 minecraft:stone
setblock 119 295 361 minecraft:stripped_spruce_log
fill 119 295 362 122 295 362 minecraft:stone
fill 120 295 361 123 295 361 minecraft:stone
setblock 121 295 322 minecraft:gold_block
setblock 121 295 323 minecraft:stone
setblock 121 295 324 minecraft:stripped_spruce_log
fill 121 295 360 124 295 360 minecraft:stone
fill 122 295 322 123 308 322 minecraft:stone
setblock 122 295 323 minecraft:stripped_spruce_log
fill 122 295 324 122 298 324 minecraft:stone
setblock 122 295 363 minecraft:stripped_spruce_log
fill 123 295 323 123 298 323 minecraft:stone
setblock 123 295 362 minecraft:stripped_spruce_log
fill 123 295 363 123 298 363 minecraft:stone
setblock 124 295 361 minecraft:stripped_spruce_log
fill 124 295 362 124 298 362 minecraft:stone
fill 125 295 361 125 298 361 minecraft:stone
fill 127 295 361 127 296 361 minecraft:stone
setblock 127 295 363 minecraft:stripped_spruce_log
setblock 128 295 362 minecraft:stripped_spruce_log
fill 128 295 363 128 298 363 minecraft:stone
fill 129 295 362 129 298 362 minecraft:stone
fill 130 295 322 130 308 322 minecraft:stone
setblock 130 295 364 minecraft:raw_iron_block
setblock 132 295 363 minecraft:stripped_spruce_log
fill 133 295 363 135 296 363 minecraft:stone
fill 134 295 353 134 297 353 minecraft:stone
setblock 134 295 356 minecraft:stripped_spruce_log
fill 134 295 357 134 298 357 minecraft:stone
setblock 134 295 361 minecraft:stripped_spruce_log
setblock 135 295 334 minecraft:stone
setblock 135 295 335 minecraft:stripped_spruce_log
fill 135 295 336 135 295 339 minecraft:stone
setblock 135 295 340 minecraft:stripped_spruce_log
fill 135 295 341 135 298 341 minecraft:stone
setblock 135 295 349 minecraft:stone
setblock 135 295 350 minecraft:stripped_spruce_log
fill 135 295 351 135 298 351 minecraft:stone
setblock 135 295 355 minecraft:stripped_spruce_log
fill 135 295 356 136 298 356 minecraft:stone
setblock 135 295 360 minecraft:stripped_spruce_log
fill 135 295 361 135 298 361 minecraft:stone
fill 95 296 331 95 296 333 minecraft:stone
setblock 95 296 334 minecraft:stripped_spruce_log
fill 95 296 335 95 299 335 minecraft:stone
setblock 95 296 338 minecraft:stone
setblock 95 296 339 minecraft:stripped_spruce_log
fill 95 296 340 95 299 340 minecraft:stone
setblock 95 296 344 minecraft:stripped_spruce_log
fill 95 296 345 96 298 345 minecraft:stone
setblock 95 296 349 minecraft:stripped_spruce_log
fill 95 296 350 95 299 350 minecraft:stone
setblock 95 296 353 minecraft:stone
setblock 95 296 354 minecraft:stripped_spruce_log
fill 95 296 355 95 299 355 minecraft:stone
setblock 95 296 358 minecraft:stone
setblock 95 296 359 minecraft:stripped_spruce_log
fill 95 296 360 96 298 360 minecraft:stone
fill 95 296 362 95 296 363 minecraft:stone
setblock 96 296 332 minecraft:stone
setblock 96 296 333 minecraft:stripped_spruce_log
fill 96 296 334 96 299 334 minecraft:stone
setblock 96 296 338 minecraft:stripped_spruce_log
fill 96 296 339 96 299 339 minecraft:stone
setblock 96 296 342 minecraft:stone
setblock 96 296 343 minecraft:stripped_spruce_log
fill 96 296 344 96 299 344 minecraft:stone
setblock 96 296 353 minecraft:stripped_spruce_log
fill 96 296 354 96 299 354 minecraft:stone
setblock 96 296 358 minecraft:stripped_spruce_log
fill 96 296 359 96 299 359 minecraft:stone
fill 96 296 361 96 297 361 minecraft:stone
setblock 96 296 363 minecraft:stripped_spruce_log
fill 97 296 333 97 299 333 minecraft:stone
setblock 97 296 337 minecraft:stripped_spruce_log
fill 97 296 338 97 299 338 minecraft:stone
setblock 97 296 342 minecraft:stripped_spruce_log
fill 97 296 343 97 299 343 minecraft:stone
fill 97 296 363 100 296 363 minecraft:stone
setblock 98 296 335 minecraft:stone
setblock 98 296 336 minecraft:stripped_spruce_log
fill 98 296 337 98 299 337 minecraft:stone
fill 98 296 339 98 296 340 minecraft:stone
setblock 98 296 341 minecraft:stripped_spruce_log
fill 98 296 362 101 296 362 minecraft:stone
fill 99 296 323 100 296 323 minecraft:stone
setblock 101 296 323 minecraft:stripped_spruce_log
setblock 101 296 363 minecraft:stripped_spruce_log
fill 102 296 323 102 299 323 minecraft:stone
setblock 102 296 362 minecraft:stripped_spruce_log
fill 102 296 363 102 299 363 minecraft:stone
fill 103 296 362 103 299 362 minecraft:stone
setblock 106 296 323 minecraft:stripped_spruce_log
setblock 106 296 363 minecraft:stripped_spruce_log
fill 107 296 323 107 299 323 minecraft:stone
fill 113 296 323 115 296 323 minecraft:stone
fill 113 296 363 115 296 363 minecraft:stone
fill 115 296 362 116 296 362 minecraft:stone
setblock 116 296 323 minecraft:stripped_spruce_log
setblock 116 296 363 minecraft:stripped_spruce_log
fill 117 296 323 119 296 324 minecraft:stone
setblock 117 296 361 minecraft:stone
setblock 117 296 362 minecraft:stripped_spruce_log
fill 117 296 363 120 296 363 minecraft:stone
setblock 118 296 361 minecraft:stripped_spruce_log
fill 118 296 362 121 296 362 minecraft:stone
setblock 119 296 360 minecraft:stripped_spruce_log
fill 119 296 361 122 296 361 minecraft:stone
setblock 120 296 323 minecraft:stone
setblock 120 296 324 minecraft:stripped_spruce_log
fill 120 296 360 123 296 360 minecraft:stone
fill 121 296 322 121 308 322 minecraft:stone
setblock 121 296 323 minecraft:stripped_spruce_log
fill 121 296 324 121 299 324 minecraft:stone
setblock 121 296 363 minecraft:stripped_spruce_log
fill 122 296 323 122 299 323 minecraft:stone
setblock 122 296 362 minecraft:stripped_spruce_log
fill 122 296 363 122 299 363 minecraft:stone
setblock 123 296 361 minecraft:stripped_spruce_log
fill 123 296 362 123 299 362 minecraft:stone
setblock 124 296 324 minecraft:stone
setblock 124 296 360 minecraft:stripped_spruce_log
fill 124 296 361 124 299 361 minecraft:stone
fill 125 296 360 125 299 360 minecraft:stone
setblock 126 296 323 minecraft:stripped_spruce_log
setblock 126 296 363 minecraft:stripped_spruce_log
fill 127 296 323 127 299 323 minecraft:stone
setblock 127 296 362 minecraft:stripped_spruce_log
fill 127 296 363 127 299 363 minecraft:stone
setblock 128 296 361 minecraft:stripped_spruce_log
fill 128 296 362 128 299 362 minecraft:stone
fill 130 296 362 131 296 362 minecraft:stone
fill 130 296 364 130 308 364 minecraft:stone
setblock 131 296 363 minecraft:stripped_spruce_log
setblock 132 296 362 minecraft:stripped_spruce_log
fill 132 296 363 132 299 363 minecraft:stone
fill 133 296 358 134 297 358 minecraft:stone
fill 133 296 362 134 298 362 minecraft:stone
setblock 134 296 355 minecraft:stripped_spruce_log
fill 134 296 356 134 299 356 minecraft:stone
setblock 134 296 359 minecraft:stone
setblock 134 296 360 minecraft:stripped_spruce_log
fill 134 296 361 134 299 361 minecraft:stone
setblock 135 296 333 minecraft:stone
setblock 135 296 334 minecraft:stripped_spruce_log
fill 135 296 335 135 296 338 minecraft:stone
setblock 135 296 339 minecraft:stripped_spruce_log
fill 135 296 340 135 299 340 minecraft:stone
fill 135 296 342 135 296 343 minecraft:stone
setblock 135 296 344 minecraft:stripped_spruce_log
fill 135 296 345 135 296 348 minecraft:stone
setblock 135 296 349 minecraft:stripped_spruce_log
fill 135 296 350 135 299 350 minecraft:stone
setblock 135 296 354 minecraft:stripped_spruce_log
fill 135 296 355 135 299 355 minecraft:stone
setblock 135 296 359 minecraft:stripped_spruce_log
fill 135 296 360 135 299 360 minecraft:stone
setblock 136 296 324 minecraft:diamond_block
setblock 136 296 340 minecraft:raw_iron_block
setblock 94 297 323 minecraft:raw_gold_block
fill 94 297 324 94 308 324 minecraft:stone
setblock 94 297 329 minecraft:diamond_block
fill 94 297 359 95 300 359 minecraft:stone
setblock 94 297 360 minecraft:raw_iron_block
fill 95 297 330 95 297 332 minecraft:stone
setblock 95 297 333 minecraft:stripped_spruce_log
fill 95 297 334 95 300 334 minecraft:stone
setblock 95 297 338 minecraft:stripped_spruce_log
fill 95 297 339 95 300 339 minecraft:stone
fill 95 297 341 95 297 342 minecraft:stone
setblock 95 297 343 minecraft:stripped_spruce_log
fill 95 297 344 95 300 344 minecraft:stone
fill 95 297 346 95 297 347 minecraft:stone
setblock 95 297 348 minecraft:stripped_spruce_log
fill 95 297 349 95 300 349 minecraft:stone
setblock 95 297 353 minecraft:stripped_spruce_log
fill 95 297 354 95 300 354 minecraft:stone
setblock 95 297 357 minecraft:stone
setblock 95 297 358 minecraft:stripped_spruce_log
setblock 95 297 362 minecraft:stone
setblock 95 297 363 minecraft:stripped_spruce_log
setblock 96 297 331 minecraft:stone
setblock 96 297 332 minecraft:stripped_spruce_log
fill 96 297 333 96 300 333 minecraft:stone
setblock 96 297 336 minecraft:stone
setblock 96 297 337 minecraft:stripped_spruce_log
fill 96 297 338 96 300 338 minecraft:stone
setblock 96 297 341 minecraft:stone
setblock 96 297 342 minecraft:stripped_spruce_log
fill 96 297 343 96 300 343 minecraft:stone
setblock 96 297 346 minecraft:stone
setblock 96 297 347 minecraft:stripped_spruce_log
fill 96 297 348 96 300 348 minecraft:stone
setblock 96 297 351 minecraft:stone
setblock 96 297 352 minecraft:stripped_spruce_log
fill 96 297 353 96 299 353 minecraft:stone
setblock 96 297 357 minecraft:stripped_spruce_log
fill 96 297 358 97 299 358 minecraft:stone
setblock 96 297 362 minecraft:stripped_spruce_log
fill 96 297 363 99 297 363 minecraft:stone
fill 97 297 323 99 297 323 minecraft:stone
setblock 97 297 336 minecraft:stripped_spruce_log
fill 97 297 337 97 300 337 minecraft:stone
setblock 97 297 341 minecraft:stripped_spruce_log
fill 97 297 342 98 299 342 minecraft:stone
fill 97 297 344 97 298 344 minecraft:stone
setblock 97 297 356 minecraft:stripped_spruce_log
fill 97 297 357 97 298 357 minecraft:stone
fill 97 297 359 97 298 359 minecraft:stone
fill 97 297 362 100 297 362 minecraft:stone
setblock 98 297 334 minecraft:stone
setblock 98 297 335 minecraft:stripped_spruce_log
fill 98 297 336 99 299 336 minecraft:stone
setblock 98 297 339 minecraft:stone
setblock 98 297 340 minecraft:stripped_spruce_log
fill 98 297 341 98 300 341 minecraft:stone
fill 99 297 337 99 297 338 minecraft:stone
setblock 99 297 339 minecraft:stripped_spruce_log
setblock 100 297 323 minecraft:stripped_spruce_log
setblock 100 297 363 minecraft:stripped_spruce_log
fill 101 297 323 101 299 324 minecraft:stone
setblock 101 297 362 minecraft:stripped_spruce_log
fill 101 297 363 101 300 363 minecraft:stone
fill 102 297 324 102 298 324 minecraft:stone
fill 102 297 362 102 300 362 minecraft:stone
fill 103 297 323 104 297 323 minecraft:stone
fill 103 297 363 104 297 363 minecraft:stone
fill 104 297 362 104 298 362 minecraft:stone
setblock 105 297 323 minecraft:stripped_spruce_log
setblock 105 297 363 minecraft:stripped_spruce_log
fill 106 297 323 106 300 323 minecraft:stone
fill 106 297 363 109 297 363 minecraft:stone
fill 108 297 323 109 297 323 minecraft:stone
setblock 110 297 323 minecraft:stripped_spruce_log
setblock 110 297 363 minecraft:stripped_spruce_log
fill 111 297 323 114 297 323 minecraft:stone
fill 111 297 363 114 297 363 minecraft:stone
setblock 111 297 364 minecraft:diamond_block
fill 114 297 362 115 297 362 minecraft:stone
setblock 115 297 323 minecraft:stripped_spruce_log
fill 115 297 324 118 297 324 minecraft:stone
setblock 115 297 363 minecraft:stripped_spruce_log
fill 116 297 323 119 297 323 minecraft:stone
setblock 116 297 361 minecraft:stone
setblock 116 297 362 minecraft:stripped_spruce_log
fill 116 297 363 119 297 363 minecraft:stone
setblock 117 297 361 minecraft:stripped_spruce_log
fill 117 297 362 120 297 362 minecraft:stone
setblock 118 297 360 minecraft:stripped_spruce_log
fill 118 297 361 121 297 361 minecraft:stone
setblock 119 297 324 minecraft:stripped_spruce_log
fill 119 297 360 122 297 360 minecraft:stone
setblock 120 297 323 minecraft:stripped_spruce_log
fill 120 297 324 120 300 324 minecraft:stone
fill 120 297 348 120 297 349 minecraft:stripped_dark_oak_log
setblock 120 297 363 minecraft:stripped_spruce_log
fill 121 297 323 121 300 323 minecraft:stone
fill 121 297 347 123 298 347 minecraft:stripped_dark_oak_log
fill 121 297 350 123 298 350 minecraft:stripped_dark_oak_log
setblock 121 297 362 minecraft:stripped_spruce_log
fill 121 297 363 121 300 363 minecraft:stone
setblock 122 297 361 minecraft:stripped_spruce_log
fill 122 297 362 122 300 362 minecraft:stone
setblock 123 297 360 minecraft:stripped_spruce_log
fill 123 297 361 123 300 361 minecraft:stone
setblock 124 297 324 minecraft:stripped_spruce_log
fill 124 297 348 124 297 349 minecraft:stripped_dark_oak_log
fill 124 297 360 124 300 360 minecraft:stone
setblock 125 297 323 minecraft:stripped_spruce_log
setblock 125 297 363 minecraft:stripped_spruce_log
fill 126 297 323 126 300 323 minecraft:stone
fill 126 297 360 126 298 360 minecraft:stone
setblock 126 297 362 minecraft:stripped_spruce_log
fill 126 297 363 126 300 363 minecraft:stone
setblock 127 297 361 minecraft:stripped_spruce_log
fill 127 297 362 127 300 362 minecraft:stone
fill 128 297 361 129 299 361 minecraft:stone
setblock 130 297 362 minecraft:stone
setblock 130 297 363 minecraft:stripped_spruce_log
setblock 131 297 362 minecraft:stripped_spruce_log
fill 131 297 363 131 300 363 minecraft:stone
fill 132 297 362 132 300 362 minecraft:stone
fill 133 297 357 133 299 357 minecraft:stone
setblock 133 297 359 minecraft:stone
setblock 133 297 360 minecraft:stripped_spruce_log
fill 133 297 363 134 297 363 minecraft:stone
fill 134 297 337 134 297 338 minecraft:stone
setblock 134 297 339 minecraft:stripped_spruce_log
fill 134 297 340 134 299 341 minecraft:stone
fill 134 297 352 134 298 352 minecraft:stone
setblock 134 297 354 minecraft:stripped_spruce_log
fill 134 297 355 134 300 355 minecraft:stone
setblock 134 297 359 minecraft:stripped_spruce_log
fill 134 297 360 134 300 360 minecraft:stone
setblock 135 297 333 minecraft:stripped_spruce_log
fill 135 297 334 135 297 337 minecraft:stone
setblock 135 297 338 minecraft:stripped_spruce_log
fill 135 297 339 135 300 339 minecraft:stone
setblock 135 297 342 minecraft:stone
setblock 135 297 343 minecraft:stripped_spruce_log
fill 135 297 344 135 297 347 minecraft:stone
setblock 135 297 348 minecraft:stripped_spruce_log
fill 135 297 349 135 300 349 minecraft:stone
setblock 135 297 353 minecraft:stripped_spruce_log
fill 135 297 354 135 300 354 minecraft:stone
setblock 135 297 358 minecraft:stripped_spruce_log
fill 135 297 359 135 300 359 minecraft:stone
setblock 135 297 363 minecraft:stripped_spruce_log
fill 136 297 324 136 308 324 minecraft:stone
setblock 136 297 326 minecraft:gold_block
fill 136 297 340 136 308 340 minecraft:stone
setblock 136 297 363 minecraft:raw_iron_block
fill 94 298 322 94 308 323 minecraft:stone
setblock 94 298 329 minecraft:raw_gold_block
fill 94 298 360 94 308 360 minecraft:stone
setblock 95 298 322 minecraft:diamond_block
fill 95 298 329 95 298 331 minecraft:stone
setblock 95 298 332 minecraft:stripped_spruce_log
fill 95 298 333 95 300 333 minecraft:stone
setblock 95 298 337 minecraft:stripped_spruce_log
fill 95 298 338 95 300 338 minecraft:stone
setblock 95 298 341 minecraft:stone
setblock 95 298 342 minecraft:stripped_spruce_log
fill 95 298 343 95 300 343 minecraft:stone
setblock 95 298 346 minecraft:stone
setblock 95 298 347 minecraft:stripped_spruce_log
fill 95 298 348 95 300 348 minecraft:stone
setblock 95 298 352 minecraft:stripped_spruce_log
fill 95 298 353 95 300 353 minecraft:stone
setblock 95 298 357 minecraft:stripped_spruce_log
fill 95 298 358 95 300 358 minecraft:stone
setblock 95 298 362 minecraft:stripped_spruce_log
fill 95 298 363 98 298 363 minecraft:stone
fill 96 298 323 98 298 323 minecraft:stone
setblock 96 298 331 minecraft:stripped_spruce_log
fill 96 298 332 97 299 332 minecraft:stone
setblock 96 298 335 minecraft:stone
setblock 96 298 336 minecraft:stripped_spruce_log
fill 96 298 337 96 300 337 minecraft:stone
setblock 96 298 340 minecraft:stone
setblock 96 298 341 minecraft:stripped_spruce_log
fill 96 298 342 96 300 342 minecraft:stone
setblock 96 298 346 minecraft:stripped_spruce_log
fill 96 298 347 96 300 347 minecraft:stone
fill 96 298 349 96 298 350 minecraft:stone
setblock 96 298 351 minecraft:stripped_spruce_log
fill 96 298 352 96 299 352 minecraft:stone
setblock 96 298 356 minecraft:stripped_spruce_log
fill 96 298 357 96 300 357 minecraft:stone
setblock 96 298 361 minecraft:stripped_spruce_log
fill 96 298 362 99 298 362 minecraft:stone
setblock 97 298 325 minecraft:light[level=15]
setblock 97 298 335 minecraft:stripped_spruce_log
fill 97 298 336 97 300 336 minecraft:stone
setblock 97 298 340 minecraft:stripped_spruce_log
fill 97 298 341 97 300 341 minecraft:stone
setblock 97 298 345 minecraft:stripped_spruce_log
fill 97 298 346 97 300 346 minecraft:stone
setblock 97 298 349 minecraft:light[level=15]
setblock 97 298 360 minecraft:stripped_spruce_log
setblock 98 298 322 minecraft:diamond_block
setblock 98 298 334 minecraft:stripped_spruce_log
fill 98 298 335 98 300 335 minecraft:stone
setblock 98 298 339 minecraft:stripped_spruce_log
fill 98 298 340 99 300 340 minecraft:stone
setblock 98 298 343 minecraft:stone
fill 98 298 361 100 298 361 minecraft:stone
setblock 99 298 323 minecraft:stripped_spruce_log
fill 99 298 324 100 300 324 minecraft:stone
setblock 99 298 337 minecraft:stone
setblock 99 298 338 minecraft:stripped_spruce_log
fill 99 298 339 99 300 339 minecraft:stone
fill 99 298 341 99 299 341 minecraft:stone
setblock 99 298 363 minecraft:stripped_spruce_log
fill 100 298 323 100 300 323 minecraft:stone
fill 100 298 360 100 299 360 minecraft:iron_bars
setblock 100 298 362 minecraft:stripped_spruce_log
fill 100 298 363 100 300 363 minecraft:stone
setblock 101 298 361 minecraft:stripped_spruce_log
fill 101 298 362 101 300 362 minecraft:stone
setblock 103 298 323 minecraft:stone
setblock 103 298 324 minecraft:stripped_spruce_log
setblock 103 298 363 minecraft:stone
setblock 104 298 323 minecraft:stripped_spruce_log
fill 104 298 324 104 300 324 minecraft:stone
setblock 104 298 363 minecraft:stripped_spruce_log
fill 105 298 323 105 300 323 minecraft:stone
setblock 105 298 325 minecraft:light[level=15]
setblock 105 298 333 minecraft:light[level=15]
setblock 105 298 341 minecraft:light[level=15]
setblock 105 298 349 minecraft:light[level=15]
setblock 105 298 357 minecraft:light[level=15]
setblock 105 298 362 minecraft:stripped_spruce_log
fill 105 298 363 108 298 363 minecraft:stone
setblock 108 298 323 minecraft:stone
setblock 109 298 323 minecraft:stripped_spruce_log
setblock 109 298 363 minecraft:stripped_spruce_log
fill 110 298 323 113 298 323 minecraft:stone
fill 110 298 363 113 298 363 minecraft:stone
fill 111 298 364 111 308 364 minecraft:stone
fill 112 298 362 114 298 362 minecraft:stone
setblock 113 298 325 minecraft:light[level=15]
setblock 113 298 333 minecraft:light[level=15]
setblock 113 298 341 minecraft:light[level=15]
setblock 113 298 349 minecraft:light[level=15]
setblock 113 298 357 minecraft:light[level=15]
setblock 114 298 323 minecraft:stripped_spruce_log
fill 114 298 324 117 298 324 minecraft:stone
setblock 114 298 363 minecraft:stripped_spruce_log
fill 115 298 323 118 298 323 minecraft:stone
setblock 115 298 361 minecraft:stone
setblock 115 298 362 minecraft:stripped_spruce_log
fill 115 298 363 118 298 363 minecraft:stone
setblock 116 298 361 minecraft:stripped_spruce_log
fill 116 298 362 119 298 362 minecraft:stone
setblock 117 298 360 minecraft:stripped_spruce_log
fill 117 298 361 120 298 361 minecraft:stone
setblock 118 298 324 minecraft:stripped_spruce_log
fill 118 298 325 120 299 325 minecraft:stone
fill 118 298 360 121 298 360 minecraft:stone
setblock 119 298 323 minecraft:stripped_spruce_log
fill 119 298 324 119 300 324 minecraft:stone
setblock 119 298 363 minecraft:stripped_spruce_log
fill 120 298 323 120 300 323 minecraft:stone
setblock 120 298 362 minecraft:stripped_spruce_log
fill 120 298 363 120 300 363 minecraft:stone
setblock 121 298 325 minecraft:light[level=15]
setblock 121 298 333 minecraft:light[level=15]
setblock 121 298 341 minecraft:light[level=15]
setblock 121 298 357 minecraft:light[level=15]
setblock 121 298 361 minecraft:stripped_spruce_log
fill 121 298 362 121 300 362 minecraft:stone
setblock 122 298 360 minecraft:stripped_spruce_log
fill 122 298 361 122 300 361 minecraft:stone
setblock 123 298 324 minecraft:stripped_spruce_log
fill 123 298 360 123 300 360 minecraft:stone
setblock 124 298 323 minecraft:stripped_spruce_log
fill 124 298 324 124 299 324 minecraft:stone
setblock 124 298 363 minecraft:stripped_spruce_log
fill 125 298 322 125 300 323 minecraft:stone
setblock 125 298 362 minecraft:stripped_spruce_log
fill 125 298 363 125 300 363 minecraft:stone
setblock 126 298 322 minecraft:gold_block
setblock 126 298 361 minecraft:stripped_spruce_log
fill 126 298 362 126 300 362 minecraft:stone
fill 127 298 361 127 300 361 minecraft:stone
setblock 129 298 325 minecraft:light[level=15]
setblock 129 298 333 minecraft:light[level=15]
setblock 129 298 341 minecraft:light[level=15]
setblock 129 298 349 minecraft:light[level=15]
setblock 129 298 357 minecraft:light[level=15]
setblock 129 298 363 minecraft:stripped_spruce_log
setblock 130 298 362 minecraft:stripped_spruce_log
fill 130 298 363 130 300 363 minecraft:stone
fill 131 298 362 131 300 362 minecraft:stone
setblock 133 298 358 minecraft:stone
setblock 133 298 359 minecraft:stripped_spruce_log
fill 133 298 360 133 300 361 minecraft:stone
setblock 133 298 363 minecraft:stone
fill 134 298 336 134 298 337 minecraft:stone
setblock 134 298 338 minecraft:stripped_spruce_log
fill 134 298 339 134 300 339 minecraft:stone
setblock 134 298 342 minecraft:stone
setblock 134 298 343 minecraft:stripped_spruce_log
fill 134 298 344 135 300 344 minecraft:stone
setblock 134 298 353 minecraft:stripped_spruce_log
fill 134 298 354 134 300 354 minecraft:stone
setblock 134 298 358 minecraft:stripped_spruce_log
fill 134 298 359 134 300 359 minecraft:stone
setblock 134 298 363 minecraft:stripped_spruce_log
fill 135 298 333 135 298 336 minecraft:stone
setblock 135 298 337 minecraft:stripped_spruce_log
fill 135 298 338 135 300 338 minecraft:stone
setblock 135 298 342 minecraft:stripped_spruce_log
fill 135 298 343 135 300 343 minecraft:stone
fill 135 298 345 135 298 346 minecraft:stone
setblock 135 298 347 minecraft:stripped_spruce_log
fill 135 298 348 135 300 348 minecraft:stone
setblock 135 298 352 minecraft:stripped_spruce_log
fill 135 298 353 135 300 353 minecraft:stone
setblock 135 298 357 minecraft:stripped_spruce_log
fill 135 298 358 135 300 358 minecraft:stone
setblock 135 298 362 minecraft:stripped_spruce_log
fill 135 298 363 136 300 363 minecraft:stone
fill 136 298 326 136 308 326 minecraft:stone
fill 136 298 329 136 308 329 minecraft:stone
fill 136 298 330 136 298 331 minecraft:diamond_block
fill 136 298 332 136 308 332 minecraft:stone
setblock 136 298 344 minecraft:gold_block
fill 94 299 329 95 300 329 minecraft:stone
fill 95 299 322 95 299 325 minecraft:stone
fill 95 299 328 95 300 328 minecraft:stone
setblock 95 299 330 minecraft:stone
setblock 95 299 331 minecraft:stripped_spruce_log
fill 95 299 332 95 300 332 minecraft:stone
setblock 95 299 336 minecraft:stripped_spruce_log
fill 95 299 337 95 300 337 minecraft:stone
setblock 95 299 341 minecraft:stripped_spruce_log
fill 95 299 342 95 300 342 minecraft:stone
setblock 95 299 345 minecraft:stone
setblock 95 299 346 minecraft:stripped_spruce_log
fill 95 299 347 95 300 347 minecraft:stone
setblock 95 299 351 minecraft:stripped_spruce_log
fill 95 299 352 95 300 352 minecraft:stone
setblock 95 299 356 minecraft:stripped_spruce_log
fill 95 299 357 95 300 357 minecraft:stone
setblock 95 299 360 minecraft:stone
setblock 95 299 361 minecraft:stripped_spruce_log
fill 95 299 362 97 299 363 minecraft:stone
fill 96 299 323 97 299 323 minecraft:stone
fill 96 299 331 96 300 331 minecraft:stone
setblock 96 299 335 minecraft:stripped_spruce_log
fill 96 299 336 96 300 336 minecraft:stone
setblock 96 299 340 minecraft:stripped_spruce_log
fill 96 299 341 96 300 341 minecraft:stone
setblock 96 299 345 minecraft:stripped_spruce_log
fill 96 299 346 96 300 346 minecraft:stone
setblock 96 299 349 minecraft:stone
setblock 96 299 350 minecraft:stripped_spruce_log
setblock 96 299 351 minecraft:stone
setblock 96 299 355 minecraft:stripped_spruce_log
fill 96 299 356 96 300 356 minecraft:stone
setblock 96 299 360 minecraft:stripped_spruce_log
fill 96 299 361 99 299 361 minecraft:stone
setblock 97 299 334 minecraft:stripped_spruce_log
fill 97 299 335 97 300 335 minecraft:stone
setblock 97 299 339 minecraft:stripped_spruce_log
fill 97 299 340 97 300 340 minecraft:stone
setblock 97 299 344 minecraft:stripped_spruce_log
fill 97 299 345 97 300 345 minecraft:stone
setblock 97 299 359 minecraft:stripped_spruce_log
fill 97 299 360 97 300 360 minecraft:stone
fill 98 299 322 98 308 322 minecraft:stone
setblock 98 299 323 minecraft:stripped_spruce_log
fill 98 299 324 98 300 324 minecraft:stone
setblock 98 299 334 minecraft:stone
setblock 98 299 338 minecraft:stripped_spruce_log
fill 98 299 339 98 300 339 minecraft:stone
setblock 98 299 343 minecraft:stripped_spruce_log
fill 98 299 344 98 300 344 minecraft:stone
setblock 98 299 362 minecraft:stone
setblock 98 299 363 minecraft:stripped_spruce_log
setblock 98 299 364 minecraft:raw_iron_block
fill 99 299 323 99 300 323 minecraft:stone
setblock 99 299 337 minecraft:stripped_spruce_log
fill 99 299 338 99 300 338 minecraft:stone
setblock 99 299 362 minecraft:stripped_spruce_log
fill 99 299 363 99 300 363 minecraft:stone
setblock 100 299 361 minecraft:stripped_spruce_log
fill 100 299 362 100 300 362 minecraft:stone
setblock 101 299 361 minecraft:stone
setblock 102 299 324 minecraft:stripped_spruce_log
setblock 103 299 323 minecraft:stripped_spruce_log
fill 103 299 324 103 300 324 minecraft:stone
setblock 103 299 363 minecraft:stripped_spruce_log
fill 104 299 323 104 300 323 minecraft:stone
setblock 104 299 362 minecraft:stripped_spruce_log
fill 104 299 363 107 299 363 minecraft:stone
setblock 105 299 362 minecraft:stone
setblock 107 299 322 minecraft:raw_gold_block
setblock 108 299 323 minecraft:stripped_spruce_log
setblock 108 299 363 minecraft:stripped_spruce_log
fill 109 299 323 112 299 323 minecraft:stone
fill 109 299 363 112 299 363 minecraft:stone
fill 111 299 362 113 299 362 minecraft:stone
setblock 112 299 324 minecraft:stripped_spruce_log
setblock 113 299 323 minecraft:stripped_spruce_log
fill 113 299 324 116 299 324 minecraft:stone
setblock 113 299 363 minecraft:stripped_spruce_log
fill 114 299 323 117 299 323 minecraft:stone
setblock 114 299 361 minecraft:stone
setblock 114 299 362 minecraft:stripped_spruce_log
fill 114 299 363 117 299 363 minecraft:stone
setblock 115 299 361 minecraft:stripped_spruce_log
fill 115 299 362 118 299 362 minecraft:stone
setblock 116 299 360 minecraft:stripped_spruce_log
fill 116 299 361 119 299 361 minecraft:stone
setblock 117 299 324 minecraft:stripped_spruce_log
fill 117 299 325 117 300 325 minecraft:stone
fill 117 299 360 120 299 360 minecraft:stone
setblock 118 299 323 minecraft:stripped_spruce_log
fill 118 299 324 118 300 324 minecraft:stone
setblock 118 299 363 minecraft:stripped_spruce_log
fill 119 299 323 119 300 323 minecraft:stone
setblock 119 299 362 minecraft:stripped_spruce_log
fill 119 299 363 119 300 363 minecraft:stone
setblock 120 299 361 minecraft:stripped_spruce_log
fill 120 299 362 120 300 362 minecraft:stone
setblock 121 299 360 minecraft:stripped_spruce_log
fill 121 299 361 121 300 361 minecraft:stone
setblock 122 299 324 minecraft:stripped_spruce_log
setblock 122 299 347 minecraft:stripped_dark_oak_log
setblock 122 299 350 minecraft:stripped_dark_oak_log
fill 122 299 360 122 300 360 minecraft:stone
setblock 123 299 323 minecraft:stripped_spruce_log
fill 123 299 324 123 300 324 minecraft:stone
setblock 123 299 363 minecraft:stripped_spruce_log
fill 124 299 323 124 300 323 minecraft:stone
setblock 124 299 362 minecraft:stripped_spruce_log
fill 124 299 363 124 300 363 minecraft:stone
setblock 125 299 361 minecraft:stripped_spruce_log
fill 125 299 362 125 300 362 minecraft:stone
fill 126 299 322 126 308 322 minecraft:stone
fill 126 299 361 126 300 361 minecraft:stone
setblock 128 299 363 minecraft:stripped_spruce_log
setblock 129 299 362 minecraft:stripped_spruce_log
fill 129 299 363 129 300 363 minecraft:stone
fill 130 299 362 130 300 362 minecraft:stone
fill 132 299 361 132 300 361 minecraft:stone
setblock 133 299 358 minecraft:stripped_spruce_log
fill 133 299 359 133 300 359 minecraft:stone
setblock 133 299 362 minecraft:stone
setblock 133 299 363 minecraft:stripped_spruce_log
setblock 134 299 336 minecraft:stone
setblock 134 299 337 minecraft:stripped_spruce_log
fill 134 299 338 134 300 338 minecraft:stone
setblock 134 299 342 minecraft:stripped_spruce_log
fill 134 299 343 134 300 343 minecraft:stone
fill 134 299 345 134 299 346 minecraft:stone
setblock 134 299 347 minecraft:stripped_spruce_log
setblock 134 299 351 minecraft:stone
setblock 134 299 352 minecraft:stripped_spruce_log
fill 134 299 353 134 300 353 minecraft:stone
setblock 134 299 357 minecraft:stripped_spruce_log
fill 134 299 358 134 300 358 minecraft:stone
setblock 134 299 362 minecraft:stripped_spruce_log
fill 134 299 363 134 300 363 minecraft:stone
fill 135 299 323 135 300 323 minecraft:stone
fill 135 299 333 135 299 335 minecraft:stone
setblock 135 299 336 minecraft:stripped_spruce_log
fill 135 299 337 135 300 337 minecraft:stone
setblock 135 299 341 minecraft:stripped_spruce_log
fill 135 299 342 135 300 342 minecraft:stone
setblock 135 299 345 minecraft:stone
setblock 135 299 346 minecraft:stripped_spruce_log
fill 135 299 347 135 300 347 minecraft:stone
setblock 135 299 351 minecraft:stripped_spruce_log
fill 135 299 352 135 300 352 minecraft:stone
setblock 135 299 356 minecraft:stripped_spruce_log
fill 135 299 357 135 300 357 minecraft:stone
setblock 135 299 361 minecraft:stripped_spruce_log
fill 135 299 362 135 300 362 minecraft:stone
fill 136 299 330 136 299 331 minecraft:stone
fill 136 299 344 136 308 344 minecraft:stone
fill 136 299 356 136 308 356 minecraft:stone
fill 94 300 347 94 308 347 minecraft:stone
setblock 94 300 348 minecraft:raw_iron_block
setblock 94 300 363 minecraft:raw_iron_block
fill 94 300 364 94 308 364 minecraft:stone
fill 95 300 322 95 300 324 minecraft:stone
setblock 95 300 325 minecraft:stripped_spruce_log
fill 95 300 326 95 300 327 minecraft:stone
setblock 95 300 330 minecraft:stripped_spruce_log
setblock 95 300 331 minecraft:stone
setblock 95 300 335 minecraft:stripped_spruce_log
setblock 95 300 336 minecraft:stone
setblock 95 300 340 minecraft:stripped_spruce_log
setblock 95 300 341 minecraft:stone
setblock 95 300 345 minecraft:stripped_spruce_log
setblock 95 300 346 minecraft:stone
setblock 95 300 350 minecraft:stripped_spruce_log
setblock 95 300 351 minecraft:stone
setblock 95 300 355 minecraft:stripped_spruce_log
setblock 95 300 356 minecraft:stone
setblock 95 300 360 minecraft:stripped_spruce_log
fill 95 300 361 96 300 363 minecraft:stone
setblock 95 300 364 minecraft:diamond_block
setblock 96 300 323 minecraft:stone
setblock 96 300 332 minecraft:stone
setblock 96 300 334 minecraft:stripped_spruce_log
setblock 96 300 335 minecraft:stone
setblock 96 300 339 minecraft:stripped_spruce_log
setblock 96 300 340 minecraft:stone
setblock 96 300 344 minecraft:stripped_spruce_log
setblock 96 300 345 minecraft:stone
setblock 96 300 349 minecraft:stripped_spruce_log
setblock 96 300 350 minecraft:stone
setblock 96 300 354 minecraft:stripped_spruce_log
setblock 96 300 355 minecraft:stone
setblock 96 300 358 minecraft:stone
setblock 96 300 359 minecraft:stripped_spruce_log
setblock 96 300 360 minecraft:stone
setblock 97 300 323 minecraft:stripped_spruce_log
setblock 97 300 324 minecraft:stone
setblock 97 300 325 minecraft:light[level=12]
setblock 97 300 332 minecraft:light[level=12]
setblock 97 300 333 minecraft:stripped_spruce_log
setblock 97 300 334 minecraft:stone
setblock 97 300 338 minecraft:stripped_spruce_log
setblock 97 300 339 minecraft:stone
setblock 97 300 342 minecraft:stone
setblock 97 300 343 minecraft:stripped_spruce_log
setblock 97 300 344 minecraft:stone
setblock 97 300 347 minecraft:stone
setblock 97 300 353 minecraft:light[level=12]
setblock 97 300 359 minecraft:stone
fill 97 300 361 97 300 362 minecraft:stone
setblock 97 300 363 minecraft:stripped_spruce_log
setblock 98 300 323 minecraft:stone
setblock 98 300 336 minecraft:stone
setblock 98 300 337 minecraft:stripped_spruce_log
setblock 98 300 338 minecraft:stone
setblock 98 300 342 minecraft:stripped_spruce_log
setblock 98 300 343 minecraft:stone
setblock 98 300 361 minecraft:stone
setblock 98 300 362 minecraft:stripped_spruce_log
fill 98 300 363 98 300 364 minecraft:stone
setblock 99 300 337 minecraft:stone
setblock 99 300 341 minecraft:stripped_spruce_log
setblock 99 300 361 minecraft:stripped_spruce_log
setblock 99 300 362 minecraft:stone
setblock 100 300 361 minecraft:stone
setblock 101 300 323 minecraft:stone
setblock 101 300 324 minecraft:stripped_spruce_log
setblock 102 300 323 minecraft:stripped_spruce_log
setblock 102 300 324 minecraft:stone
setblock 102 300 363 minecraft:stripped_spruce_log
setblock 103 300 323 minecraft:stone
setblock 103 300 362 minecraft:stripped_spruce_log
fill 103 300 363 106 300 363 minecraft:stone
setblock 104 300 325 minecraft:light[level=12]
setblock 104 300 332 minecraft:light[level=12]
setblock 104 300 339 minecraft:light[level=12]
setblock 104 300 346 minecraft:light[level=12]
setblock 104 300 353 minecraft:light[level=12]
setblock 104 300 360 minecraft:light[level=12]
setblock 104 300 362 minecraft:stone
fill 107 300 322 107 308 322 minecraft:stone
setblock 107 300 323 minecraft:stripped_spruce_log
setblock 107 300 363 minecraft:stripped_spruce_log
fill 108 300 323 111 300 323 minecraft:stone
fill 108 300 363 111 300 363 minecraft:stone
setblock 111 300 324 minecraft:stripped_spruce_log
setblock 111 300 325 minecraft:light[level=12]
setblock 111 300 332 minecraft:light[level=12]
setblock 111 300 339 minecraft:light[level=12]
setblock 111 300 346 minecraft:light[level=12]
setblock 111 300 353 minecraft:light[level=12]
setblock 111 300 360 minecraft:light[level=12]
fill 111 300 362 112 300 362 minecraft:stone
setblock 112 300 323 minecraft:stripped_spruce_log
fill 112 300 324 115 300 324 minecraft:stone
setblock 112 300 363 minecraft:stripped_spruce_log
fill 113 300 323 116 300 323 minecraft:stone
setblock 113 300 361 minecraft:stone
setblock 113 300 362 minecraft:stripped_spruce_log
fill 113 300 363 116 300 363 minecraft:stone
setblock 114 300 361 minecraft:stripped_spruce_log
fill 114 300 362 117 300 362 minecraft:stone
fill 115 300 361 118 300 361 minecraft:stone
setblock 116 300 324 minecraft:stripped_spruce_log
setblock 116 300 325 minecraft:stone
fill 116 300 360 119 300 360 minecraft:stone
setblock 117 300 322 minecraft:raw_gold_block
setblock 117 300 323 minecraft:stripped_spruce_log
setblock 117 300 324 minecraft:stone
setblock 117 300 363 minecraft:stripped_spruce_log
setblock 118 300 323 minecraft:stone
fill 118 300 325 119 300 325 minecraft:stone
setblock 118 300 332 minecraft:light[level=12]
setblock 118 300 339 minecraft:light[level=12]
setblock 118 300 346 minecraft:light[level=12]
setblock 118 300 353 minecraft:light[level=12]
setblock 118 300 362 minecraft:stripped_spruce_log
setblock 118 300 363 minecraft:stone
setblock 119 300 361 minecraft:stripped_spruce_log
setblock 119 300 362 minecraft:stone
setblock 120 300 325 minecraft:stripped_spruce_log
setblock 120 300 360 minecraft:stripped_spruce_log
setblock 120 300 361 minecraft:stone
setblock 121 300 324 minecraft:stripped_spruce_log
setblock 121 300 360 minecraft:stone
setblock 122 300 323 minecraft:stripped_spruce_log
setblock 122 300 324 minecraft:stone
setblock 122 300 363 minecraft:stripped_spruce_log
setblock 123 300 323 minecraft:stone
setblock 123 300 362 minecraft:stripped_spruce_log
setblock 123 300 363 minecraft:stone
setblock 124 300 322 minecraft:raw_gold_block
setblock 124 300 361 minecraft:stripped_spruce_log
setblock 124 300 362 minecraft:stone
setblock 125 300 325 minecraft:light[level=12]
setblock 125 300 332 minecraft:light[level=12]
setblock 125 300 339 minecraft:light[level=12]
setblock 125 300 346 minecraft:light[level=12]
setblock 125 300 353 minecraft:light[level=12]
setblock 125 300 360 minecraft:light[level=12]
setblock 125 300 361 minecraft:stone
setblock 127 300 323 minecraft:stripped_spruce_log
setblock 127 300 363 minecraft:stripped_spruce_log
setblock 128 300 361 minecraft:stone
setblock 128 300 362 minecraft:stripped_spruce_log
setblock 128 300 363 minecraft:stone
setblock 129 300 362 minecraft:stone
setblock 132 300 325 minecraft:light[level=12]
setblock 132 300 332 minecraft:light[level=12]
setblock 132 300 339 minecraft:light[level=12]
setblock 132 300 346 minecraft:light[level=12]
setblock 132 300 353 minecraft:light[level=12]
setblock 132 300 360 minecraft:light[level=12]
setblock 132 300 363 minecraft:stripped_spruce_log
setblock 132 300 364 minecraft:gold_block
setblock 133 300 358 minecraft:stone
setblock 133 300 362 minecraft:stripped_spruce_log
setblock 133 300 363 minecraft:stone
setblock 134 300 323 minecraft:stone
setblock 134 300 336 minecraft:stripped_spruce_log
setblock 134 300 337 minecraft:stone
setblock 134 300 340 minecraft:stone
setblock 134 300 341 minecraft:stripped_spruce_log
setblock 134 300 342 minecraft:stone
setblock 134 300 345 minecraft:stone
setblock 134 300 346 minecraft:stripped_spruce_log
fill 134 300 347 134 300 350 minecraft:stone
setblock 134 300 351 minecraft:stripped_spruce_log
setblock 134 300 352 minecraft:stone
setblock 134 300 356 minecraft:stripped_spruce_log
setblock 134 300 357 minecraft:stone
setblock 134 300 361 minecraft:stripped_spruce_log
setblock 134 300 362 minecraft:stone
setblock 134 300 364 minecraft:gold_block
setblock 135 300 324 minecraft:stone
fill 135 300 333 135 300 334 minecraft:stone
setblock 135 300 335 minecraft:stripped_spruce_log
setblock 135 300 336 minecraft:stone
setblock 135 300 340 minecraft:stripped_spruce_log
setblock 135 300 341 minecraft:stone
setblock 135 300 345 minecraft:stripped_spruce_log
setblock 135 300 346 minecraft:stone
setblock 135 300 350 minecraft:stripped_spruce_log
setblock 135 300 351 minecraft:stone
setblock 135 300 355 minecraft:stripped_spruce_log
setblock 135 300 356 minecraft:stone
setblock 135 300 360 minecraft:stripped_spruce_log
setblock 135 300 361 minecraft:stone
fill 136 300 330 136 308 330 minecraft:stone
setblock 136 300 331 minecraft:raw_gold_block
setblock 94 301 325 minecraft:raw_iron_block
fill 94 301 329 94 308 329 minecraft:stone
setblock 94 301 330 minecraft:raw_gold_block
setblock 94 301 332 minecraft:diamond_block
fill 94 301 348 94 308 348 minecraft:stone
fill 94 301 359 94 308 359 minecraft:stone
fill 94 301 363 94 308 363 minecraft:stone
fill 95 301 322 95 308 322 minecraft:stone
fill 95 301 364 95 308 364 minecraft:stone
fill 98 301 364 98 308 364 minecraft:stone
fill 117 301 322 117 302 322 minecraft:stone
fill 124 301 322 125 303 322 minecraft:stone
setblock 129 301 364 minecraft:raw_gold_block
fill 132 301 364 132 308 364 minecraft:stone
fill 134 301 364 134 308 364 minecraft:stone
fill 136 301 331 136 308 331 minecraft:stone
fill 136 301 363 136 308 363 minecraft:stone
fill 94 302 325 94 308 325 minecraft:stone
fill 94 302 330 94 308 330 minecraft:stone
fill 94 302 332 94 304 332 minecraft:stone
setblock 128 302 322 minecraft:diamond_block
fill 129 302 364 129 308 364 minecraft:stone
setblock 117 303 322 minecraft:raw_iron_block
fill 128 303 322 128 307 322 minecraft:stone
fill 117 304 322 117 308 322 minecraft:stone
setblock 124 304 322 minecraft:raw_iron_block
fill 125 304 322 125 308 322 minecraft:stone
setblock 126 304 364 minecraft:raw_gold_block
setblock 94 305 332 minecraft:raw_iron_block
fill 94 305 344 94 308 344 minecraft:stone
setblock 94 305 345 minecraft:raw_iron_block
setblock 113 305 364 minecraft:raw_iron_block
fill 124 305 322 124 308 322 minecraft:stone
fill 126 305 364 126 308 364 minecraft:stone
setblock 136 305 355 minecraft:raw_iron_block
fill 94 306 332 94 308 332 minecraft:stone
fill 94 306 345 94 308 345 minecraft:stone
fill 102 306 322 102 308 322 minecraft:stone
setblock 103 306 322 minecraft:diamond_block
fill 113 306 364 113 308 364 minecraft:stone
setblock 136 306 345 minecraft:diamond_block
setblock 136 306 348 minecraft:raw_iron_block
fill 136 306 355 136 308 355 minecraft:stone
setblock 94 307 351 minecraft:raw_gold_block
fill 94 307 352 94 308 352 minecraft:stone
fill 103 307 322 103 308 322 minecraft:stone
setblock 116 307 322 minecraft:diamond_block
setblock 135 307 364 minecraft:raw_gold_block
fill 136 307 345 136 308 345 minecraft:stone
fill 136 307 348 136 308 348 minecraft:stone
setblock 94 308 351 minecraft:stone
setblock 116 308 322 minecraft:stone
setblock 128 308 322 minecraft:gold_block
setblock 135 308 364 minecraft:stone
