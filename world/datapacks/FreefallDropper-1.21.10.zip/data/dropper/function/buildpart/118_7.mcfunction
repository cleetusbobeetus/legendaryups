fill 478 191 464 478 194 464 minecraft:red_terracotta
fill 478 191 504 481 191 504 minecraft:red_terracotta
fill 479 191 465 479 192 465 minecraft:red_terracotta
fill 480 191 503 482 191 503 minecraft:red_terracotta
setblock 481 191 465 minecraft:terracotta
setblock 482 191 464 minecraft:terracotta
fill 482 191 465 482 194 465 minecraft:red_terracotta
fill 482 191 502 483 191 502 minecraft:red_terracotta
setblock 482 191 504 minecraft:terracotta
fill 483 191 464 483 194 464 minecraft:red_terracotta
setblock 483 191 503 minecraft:terracotta
fill 483 191 504 486 191 504 minecraft:red_terracotta
setblock 484 191 502 minecraft:terracotta
fill 484 191 503 484 194 503 minecraft:red_terracotta
fill 485 191 502 485 194 502 minecraft:red_terracotta
setblock 487 191 464 minecraft:terracotta
setblock 487 191 504 minecraft:terracotta
fill 488 191 504 488 194 504 minecraft:red_terracotta
fill 503 191 464 503 194 464 minecraft:red_terracotta
setblock 507 191 464 minecraft:terracotta
fill 508 191 464 508 192 464 minecraft:red_terracotta
setblock 508 191 472 minecraft:red_terracotta
setblock 508 191 473 minecraft:terracotta
fill 508 191 474 508 194 474 minecraft:red_terracotta
setblock 509 191 472 minecraft:terracotta
fill 509 191 473 509 194 473 minecraft:red_terracotta
setblock 509 191 477 minecraft:terracotta
setblock 510 191 471 minecraft:terracotta
fill 510 191 472 510 194 472 minecraft:red_terracotta
setblock 510 191 476 minecraft:terracotta
fill 510 191 477 510 194 477 minecraft:red_terracotta
fill 510 191 479 510 192 479 minecraft:red_terracotta
fill 511 191 466 511 193 466 minecraft:red_terracotta
setblock 511 191 470 minecraft:terracotta
fill 511 191 471 511 194 471 minecraft:red_terracotta
setblock 511 191 475 minecraft:terracotta
fill 511 191 476 511 194 476 minecraft:red_terracotta
setblock 511 191 480 minecraft:terracotta
fill 511 191 481 511 194 481 minecraft:red_terracotta
setblock 511 191 490 minecraft:terracotta
fill 511 191 491 511 192 491 minecraft:red_terracotta
setblock 511 191 495 minecraft:terracotta
fill 511 191 496 511 194 496 minecraft:red_terracotta
setblock 471 192 464 minecraft:terracotta
fill 471 192 465 471 194 465 minecraft:red_terracotta
setblock 471 192 469 minecraft:terracotta
fill 471 192 470 471 195 470 minecraft:red_terracotta
setblock 471 192 474 minecraft:terracotta
fill 471 192 475 472 194 475 minecraft:red_terracotta
setblock 471 192 493 minecraft:red_terracotta
setblock 471 192 494 minecraft:terracotta
fill 471 192 495 471 195 495 minecraft:red_terracotta
fill 471 192 497 471 192 498 minecraft:red_terracotta
setblock 471 192 499 minecraft:terracotta
fill 472 192 464 475 192 464 minecraft:red_terracotta
setblock 472 192 468 minecraft:terracotta
fill 472 192 469 472 193 469 minecraft:red_terracotta
setblock 472 192 473 minecraft:terracotta
fill 472 192 474 472 195 474 minecraft:red_terracotta
setblock 476 192 464 minecraft:terracotta
setblock 476 192 504 minecraft:terracotta
fill 477 192 464 477 195 464 minecraft:red_terracotta
fill 477 192 504 480 192 504 minecraft:red_terracotta
fill 478 192 503 481 192 503 minecraft:red_terracotta
setblock 480 192 464 minecraft:red_terracotta
setblock 480 192 465 minecraft:terracotta
fill 480 192 502 482 192 502 minecraft:red_terracotta
setblock 481 192 464 minecraft:terracotta
fill 481 192 465 481 195 465 minecraft:red_terracotta
setblock 481 192 504 minecraft:terracotta
fill 482 192 464 482 195 464 minecraft:red_terracotta
setblock 482 192 503 minecraft:terracotta
fill 482 192 504 485 192 504 minecraft:red_terracotta
setblock 483 192 502 minecraft:terracotta
fill 483 192 503 483 195 503 minecraft:red_terracotta
fill 484 192 502 484 195 502 minecraft:red_terracotta
setblock 486 192 464 minecraft:terracotta
fill 486 192 502 486 193 502 minecraft:red_terracotta
setblock 486 192 504 minecraft:terracotta
setblock 487 192 464 minecraft:red_terracotta
setblock 487 192 503 minecraft:terracotta
fill 487 192 504 487 195 504 minecraft:red_terracotta
fill 488 192 503 488 194 503 minecraft:red_terracotta
fill 502 192 464 502 195 464 minecraft:red_terracotta
fill 503 192 504 503 194 504 minecraft:red_terracotta
setblock 506 192 464 minecraft:terracotta
fill 507 192 464 507 194 464 minecraft:red_terracotta
setblock 508 192 472 minecraft:terracotta
fill 508 192 473 508 193 473 minecraft:red_terracotta
fill 508 192 475 508 193 475 minecraft:red_terracotta
setblock 509 192 471 minecraft:terracotta
fill 509 192 472 509 195 472 minecraft:red_terracotta
setblock 509 192 476 minecraft:terracotta
fill 509 192 477 509 194 478 minecraft:red_terracotta
setblock 510 192 470 minecraft:terracotta
fill 510 192 471 510 195 471 minecraft:red_terracotta
setblock 510 192 475 minecraft:terracotta
fill 510 192 476 510 195 476 minecraft:red_terracotta
setblock 511 192 469 minecraft:terracotta
fill 511 192 470 511 195 470 minecraft:red_terracotta
setblock 511 192 474 minecraft:terracotta
fill 511 192 475 511 195 475 minecraft:red_terracotta
setblock 511 192 479 minecraft:terracotta
fill 511 192 480 511 195 480 minecraft:red_terracotta
setblock 511 192 494 minecraft:terracotta
fill 511 192 495 511 194 495 minecraft:red_terracotta
fill 471 193 464 474 193 464 minecraft:red_terracotta
setblock 471 193 468 minecraft:terracotta
fill 471 193 469 471 196 469 minecraft:red_terracotta
setblock 471 193 473 minecraft:terracotta
fill 471 193 474 471 196 474 minecraft:red_terracotta
setblock 471 193 478 minecraft:terracotta
fill 471 193 494 471 194 494 minecraft:red_terracotta
setblock 471 193 497 minecraft:red_terracotta
setblock 471 193 498 minecraft:terracotta
fill 471 193 499 471 194 501 minecraft:red_terracotta
setblock 472 193 472 minecraft:terracotta
fill 472 193 473 472 195 473 minecraft:red_terracotta
setblock 474 193 504 minecraft:red_terracotta
setblock 475 193 464 minecraft:terracotta
setblock 475 193 504 minecraft:terracotta
fill 476 193 464 476 196 464 minecraft:red_terracotta
fill 476 193 504 479 193 504 minecraft:red_terracotta
fill 477 193 503 480 193 503 minecraft:red_terracotta
setblock 478 193 465 minecraft:red_terracotta
setblock 479 193 465 minecraft:terracotta
fill 479 193 502 481 193 502 minecraft:red_terracotta
setblock 480 193 464 minecraft:terracotta
fill 480 193 465 480 196 465 minecraft:red_terracotta
setblock 480 193 504 minecraft:terracotta
fill 481 193 464 481 196 464 minecraft:red_terracotta
fill 481 193 501 482 193 501 minecraft:red_terracotta
setblock 481 193 503 minecraft:terracotta
fill 481 193 504 484 193 504 minecraft:red_terracotta
setblock 482 193 502 minecraft:terracotta
fill 482 193 503 482 196 503 minecraft:red_terracotta
setblock 483 193 501 minecraft:terracotta
fill 483 193 502 483 196 502 minecraft:red_terracotta
setblock 484 193 465 minecraft:terracotta
fill 484 193 501 484 196 501 minecraft:red_terracotta
setblock 485 193 464 minecraft:terracotta
setblock 485 193 504 minecraft:terracotta
fill 486 193 464 486 194 464 minecraft:red_terracotta
setblock 486 193 503 minecraft:terracotta
fill 486 193 504 486 196 504 minecraft:red_terracotta
fill 487 193 503 487 196 503 minecraft:red_terracotta
setblock 500 193 504 minecraft:terracotta
fill 501 193 464 501 196 464 minecraft:red_terracotta
fill 501 193 504 502 195 504 minecraft:red_terracotta
setblock 504 193 504 minecraft:red_terracotta
setblock 505 193 464 minecraft:terracotta
setblock 505 193 504 minecraft:terracotta
fill 506 193 464 506 195 464 minecraft:red_terracotta
setblock 508 193 476 minecraft:terracotta
setblock 509 193 470 minecraft:terracotta
fill 509 193 471 509 194 471 minecraft:red_terracotta
setblock 509 193 475 minecraft:terracotta
fill 509 193 476 509 196 476 minecraft:red_terracotta
setblock 510 193 469 minecraft:terracotta
fill 510 193 470 510 195 470 minecraft:red_terracotta
setblock 510 193 474 minecraft:terracotta
fill 510 193 475 510 196 475 minecraft:red_terracotta
setblock 510 193 479 minecraft:terracotta
fill 510 193 480 510 195 480 minecraft:red_terracotta
setblock 511 193 468 minecraft:terracotta
fill 511 193 469 511 196 469 minecraft:red_terracotta
setblock 511 193 473 minecraft:terracotta
fill 511 193 474 511 196 474 minecraft:red_terracotta
setblock 511 193 478 minecraft:terracotta
fill 511 193 479 511 196 479 minecraft:red_terracotta
setblock 511 193 493 minecraft:terracotta
fill 511 193 494 511 194 494 minecraft:red_terracotta
setblock 511 193 497 minecraft:red_terracotta
fill 471 194 464 473 194 464 minecraft:red_terracotta
setblock 471 194 467 minecraft:terracotta
fill 471 194 468 471 195 468 minecraft:red_terracotta
setblock 471 194 472 minecraft:terracotta
fill 471 194 473 471 197 473 minecraft:red_terracotta
setblock 471 194 477 minecraft:terracotta
fill 471 194 478 471 196 479 minecraft:red_terracotta
setblock 471 194 497 minecraft:terracotta
fill 471 194 498 471 197 498 minecraft:red_terracotta
setblock 471 194 502 minecraft:terracotta
fill 471 194 503 471 197 503 minecraft:red_terracotta
setblock 472 194 471 minecraft:terracotta
fill 472 194 472 472 195 472 minecraft:red_terracotta
setblock 473 194 504 minecraft:red_terracotta
setblock 474 194 464 minecraft:terracotta
setblock 474 194 504 minecraft:terracotta
fill 475 194 464 475 197 464 minecraft:red_terracotta
fill 475 194 504 478 194 504 minecraft:red_terracotta
fill 476 194 503 479 194 503 minecraft:red_terracotta
setblock 478 194 465 minecraft:terracotta
fill 478 194 502 480 194 502 minecraft:red_terracotta
setblock 479 194 464 minecraft:terracotta
fill 479 194 465 479 196 465 minecraft:red_terracotta
setblock 479 194 504 minecraft:terracotta
fill 480 194 464 480 197 464 minecraft:red_terracotta
fill 480 194 501 481 194 501 minecraft:red_terracotta
setblock 480 194 503 minecraft:terracotta
fill 480 194 504 483 194 504 minecraft:red_terracotta
setblock 481 194 502 minecraft:terracotta
fill 481 194 503 481 197 503 minecraft:red_terracotta
setblock 482 194 501 minecraft:terracotta
fill 482 194 502 482 197 502 minecraft:red_terracotta
setblock 483 194 465 minecraft:terracotta
fill 483 194 501 483 197 501 minecraft:red_terracotta
setblock 484 194 464 minecraft:terracotta
setblock 484 194 504 minecraft:terracotta
fill 485 194 464 485 195 464 minecraft:red_terracotta
fill 485 194 501 485 195 501 minecraft:red_terracotta
setblock 485 194 503 minecraft:terracotta
fill 485 194 504 485 197 504 minecraft:red_terracotta
setblock 486 194 502 minecraft:terracotta
fill 486 194 503 486 197 503 minecraft:red_terracotta
setblock 489 194 504 minecraft:terracotta
setblock 499 194 504 minecraft:terracotta
fill 500 194 504 500 197 504 minecraft:red_terracotta
setblock 504 194 464 minecraft:terracotta
setblock 504 194 504 minecraft:terracotta
fill 505 194 464 505 196 464 minecraft:red_terracotta
fill 505 194 504 505 196 504 minecraft:red_terracotta
setblock 508 194 475 minecraft:terracotta
setblock 508 194 476 minecraft:red_terracotta
setblock 509 194 474 minecraft:terracotta
fill 509 194 475 509 196 475 minecraft:red_terracotta
setblock 510 194 469 minecraft:red_terracotta
setblock 510 194 473 minecraft:terracotta
fill 510 194 474 510 197 474 minecraft:red_terracotta
setblock 510 194 478 minecraft:terracotta
fill 510 194 479 510 197 479 minecraft:red_terracotta
setblock 511 194 467 minecraft:terracotta
fill 511 194 468 511 196 468 minecraft:red_terracotta
setblock 511 194 472 minecraft:terracotta
fill 511 194 473 511 197 473 minecraft:red_terracotta
setblock 511 194 477 minecraft:terracotta
fill 511 194 478 511 197 478 minecraft:red_terracotta
setblock 511 194 497 minecraft:terracotta
fill 511 194 498 511 195 498 minecraft:red_terracotta
fill 471 195 464 472 195 464 minecraft:red_terracotta
setblock 471 195 466 minecraft:terracotta
setblock 471 195 467 minecraft:red_terracotta
setblock 471 195 471 minecraft:terracotta
fill 471 195 472 471 197 472 minecraft:red_terracotta
setblock 471 195 475 minecraft:red_terracotta
setblock 471 195 476 minecraft:terracotta
fill 471 195 477 471 198 477 minecraft:red_terracotta
setblock 471 195 496 minecraft:terracotta
fill 471 195 497 471 198 497 minecraft:red_terracotta
fill 471 195 499 471 195 500 minecraft:red_terracotta
setblock 471 195 501 minecraft:terracotta
fill 471 195 502 471 198 502 minecraft:red_terracotta
fill 471 195 504 472 195 504 minecraft:red_terracotta
setblock 472 195 475 minecraft:terracotta
setblock 473 195 464 minecraft:terracotta
setblock 473 195 504 minecraft:terracotta
fill 474 195 464 474 198 464 minecraft:red_terracotta
fill 474 195 504 477 195 504 minecraft:red_terracotta
fill 475 195 503 478 195 503 minecraft:red_terracotta
fill 477 195 502 479 195 502 minecraft:red_terracotta
setblock 478 195 464 minecraft:terracotta
setblock 478 195 465 minecraft:red_terracotta
setblock 478 195 504 minecraft:terracotta
fill 479 195 464 479 198 464 minecraft:red_terracotta
fill 479 195 501 480 195 501 minecraft:red_terracotta
setblock 479 195 503 minecraft:terracotta
fill 479 195 504 482 195 504 minecraft:red_terracotta
setblock 480 195 502 minecraft:terracotta
fill 480 195 503 480 198 503 minecraft:red_terracotta
setblock 481 195 501 minecraft:terracotta
fill 481 195 502 481 198 502 minecraft:red_terracotta
setblock 482 195 465 minecraft:terracotta
fill 482 195 501 482 198 501 minecraft:red_terracotta
setblock 483 195 464 minecraft:terracotta
setblock 483 195 504 minecraft:terracotta
fill 484 195 464 484 196 464 minecraft:red_terracotta
setblock 484 195 503 minecraft:terracotta
fill 484 195 504 484 198 504 minecraft:red_terracotta
setblock 485 195 502 minecraft:terracotta
fill 485 195 503 485 198 503 minecraft:red_terracotta
fill 486 195 502 486 196 502 minecraft:red_terracotta
setblock 488 195 504 minecraft:terracotta
setblock 489 195 504 minecraft:red_terracotta
setblock 498 195 504 minecraft:terracotta
fill 499 195 504 499 198 504 minecraft:red_terracotta
fill 500 195 464 500 197 464 minecraft:red_terracotta
setblock 503 195 464 minecraft:terracotta
setblock 503 195 504 minecraft:terracotta
fill 504 195 464 504 197 464 minecraft:red_terracotta
fill 504 195 504 504 198 504 minecraft:red_terracotta
setblock 509 195 473 minecraft:terracotta
fill 509 195 474 509 196 474 minecraft:red_terracotta
setblock 509 195 477 minecraft:red_terracotta
setblock 509 195 478 minecraft:terracotta
setblock 510 195 472 minecraft:terracotta
fill 510 195 473 510 197 473 minecraft:red_terracotta
setblock 510 195 477 minecraft:terracotta
fill 510 195 478 510 198 478 minecraft:red_terracotta
setblock 511 195 467 minecraft:red_terracotta
setblock 511 195 471 minecraft:terracotta
fill 511 195 472 511 198 472 minecraft:red_terracotta
setblock 511 195 476 minecraft:terracotta
fill 511 195 477 511 198 477 minecraft:red_terracotta
setblock 511 195 481 minecraft:terracotta
setblock 511 195 497 minecraft:red_terracotta
setblock 471 196 470 minecraft:terracotta
fill 471 196 471 471 197 471 minecraft:red_terracotta
setblock 471 196 475 minecraft:terracotta
fill 471 196 476 471 198 476 minecraft:red_terracotta
setblock 471 196 495 minecraft:terracotta
fill 471 196 496 471 197 496 minecraft:red_terracotta
setblock 471 196 499 minecraft:red_terracotta
setblock 471 196 500 minecraft:terracotta
fill 471 196 501 471 199 501 minecraft:red_terracotta
setblock 471 196 504 minecraft:red_terracotta
setblock 472 196 499 minecraft:terracotta
fill 472 196 500 472 199 500 minecraft:red_terracotta
setblock 472 196 504 minecraft:terracotta
fill 473 196 464 473 199 464 minecraft:red_terracotta
fill 473 196 504 476 196 504 minecraft:red_terracotta
fill 474 196 503 477 196 503 minecraft:red_terracotta
fill 476 196 502 478 196 502 minecraft:red_terracotta
setblock 477 196 464 minecraft:terracotta
setblock 477 196 504 minecraft:terracotta
fill 478 196 464 478 199 464 minecraft:red_terracotta
fill 478 196 501 479 196 501 minecraft:red_terracotta
setblock 478 196 503 minecraft:terracotta
fill 478 196 504 481 196 504 minecraft:red_terracotta
setblock 479 196 502 minecraft:terracotta
fill 479 196 503 479 199 503 minecraft:red_terracotta
setblock 480 196 501 minecraft:terracotta
fill 480 196 502 480 199 502 minecraft:red_terracotta
fill 481 196 501 481 199 501 minecraft:red_terracotta
setblock 482 196 464 minecraft:terracotta
setblock 482 196 504 minecraft:terracotta
fill 483 196 464 483 197 464 minecraft:red_terracotta
setblock 483 196 503 minecraft:terracotta
fill 483 196 504 483 199 504 minecraft:red_terracotta
setblock 484 196 502 minecraft:terracotta
fill 484 196 503 484 199 503 minecraft:red_terracotta
fill 485 196 502 485 197 502 minecraft:red_terracotta
setblock 487 196 504 minecraft:terracotta
fill 488 196 504 488 197 504 minecraft:red_terracotta
setblock 497 196 504 minecraft:terracotta
fill 498 196 504 498 199 504 minecraft:red_terracotta
fill 500 196 503 501 197 503 minecraft:red_terracotta
setblock 501 196 504 minecraft:red_terracotta
setblock 502 196 464 minecraft:terracotta
setblock 502 196 504 minecraft:terracotta
fill 503 196 464 503 199 464 minecraft:red_terracotta
fill 503 196 504 503 199 504 minecraft:red_terracotta
setblock 509 196 477 minecraft:terracotta
setblock 510 196 471 minecraft:terracotta
setblock 510 196 472 minecraft:red_terracotta
setblock 510 196 476 minecraft:terracotta
fill 510 196 477 510 198 477 minecraft:red_terracotta
setblock 511 196 470 minecraft:terracotta
fill 511 196 471 511 198 471 minecraft:red_terracotta
setblock 511 196 475 minecraft:terracotta
fill 511 196 476 511 199 476 minecraft:red_terracotta
setblock 511 196 480 minecraft:terracotta
fill 511 196 481 511 199 481 minecraft:red_terracotta
setblock 471 197 474 minecraft:terracotta
fill 471 197 475 471 198 475 minecraft:red_terracotta
setblock 471 197 478 minecraft:red_terracotta
setblock 471 197 499 minecraft:terracotta
fill 471 197 500 471 200 500 minecraft:red_terracotta
setblock 471 197 504 minecraft:terracotta
fill 472 197 499 472 200 499 minecraft:red_terracotta
fill 472 197 501 472 198 501 minecraft:red_terracotta
fill 472 197 504 475 197 504 minecraft:red_terracotta
fill 473 197 503 476 197 503 minecraft:red_terracotta
fill 475 197 502 477 197 502 minecraft:red_terracotta
setblock 476 197 464 minecraft:terracotta
setblock 476 197 504 minecraft:terracotta
fill 477 197 464 477 200 464 minecraft:red_terracotta
fill 477 197 501 478 197 501 minecraft:red_terracotta
setblock 477 197 503 minecraft:terracotta
fill 477 197 504 480 197 504 minecraft:red_terracotta
setblock 478 197 502 minecraft:terracotta
fill 478 197 503 478 200 503 minecraft:red_terracotta
setblock 479 197 501 minecraft:terracotta
fill 479 197 502 479 200 502 minecraft:red_terracotta
fill 480 197 501 480 200 501 minecraft:red_terracotta
setblock 481 197 464 minecraft:terracotta
setblock 481 197 504 minecraft:terracotta
fill 482 197 464 482 199 464 minecraft:red_terracotta
setblock 482 197 503 minecraft:terracotta
fill 482 197 504 482 200 504 minecraft:red_terracotta
setblock 483 197 502 minecraft:terracotta
fill 483 197 503 483 200 503 minecraft:red_terracotta
setblock 484 197 501 minecraft:terracotta
fill 484 197 502 484 199 502 minecraft:red_terracotta
setblock 486 197 504 minecraft:terracotta
fill 487 197 504 487 199 504 minecraft:red_terracotta
setblock 496 197 504 minecraft:terracotta
fill 497 197 504 497 200 504 minecraft:red_terracotta
setblock 501 197 464 minecraft:terracotta
setblock 501 197 504 minecraft:terracotta
fill 502 197 464 502 200 464 minecraft:red_terracotta
fill 502 197 504 502 200 504 minecraft:red_terracotta
setblock 510 197 475 minecraft:terracotta
fill 510 197 476 510 198 476 minecraft:red_terracotta
setblock 511 197 469 minecraft:terracotta
setblock 511 197 470 minecraft:red_terracotta
setblock 511 197 474 minecraft:terracotta
fill 511 197 475 511 200 475 minecraft:red_terracotta
setblock 511 197 479 minecraft:terracotta
fill 511 197 480 511 200 480 minecraft:red_terracotta
setblock 471 198 474 minecraft:red_terracotta
setblock 471 198 498 minecraft:terracotta
fill 471 198 499 471 201 499 minecraft:red_terracotta
setblock 471 198 503 minecraft:terracotta
fill 471 198 504 474 198 504 minecraft:red_terracotta
setblock 472 198 502 minecraft:terracotta
setblock 473 198 466 minecraft:light[level=14]
setblock 473 198 474 minecraft:light[level=14]
setblock 473 198 482 minecraft:light[level=14]
setblock 473 198 490 minecraft:light[level=14]
setblock 473 198 498 minecraft:light[level=14]
fill 473 198 503 475 198 503 minecraft:red_terracotta
setblock 475 198 464 minecraft:terracotta
fill 475 198 502 476 198 502 minecraft:red_terracotta
setblock 475 198 504 minecraft:terracotta
fill 476 198 464 476 201 464 minecraft:red_terracotta
setblock 476 198 503 minecraft:terracotta
fill 476 198 504 479 198 504 minecraft:red_terracotta
setblock 477 198 501 minecraft:red_terracotta
setblock 477 198 502 minecraft:terracotta
fill 477 198 503 477 201 503 minecraft:red_terracotta
setblock 478 198 501 minecraft:terracotta
fill 478 198 502 478 201 502 minecraft:red_terracotta
fill 479 198 501 479 201 501 minecraft:red_terracotta
setblock 480 198 464 minecraft:terracotta
setblock 480 198 504 minecraft:terracotta
fill 481 198 464 481 201 464 minecraft:red_terracotta
setblock 481 198 466 minecraft:light[level=14]
setblock 481 198 474 minecraft:light[level=14]
setblock 481 198 482 minecraft:light[level=14]
setblock 481 198 490 minecraft:light[level=14]
setblock 481 198 498 minecraft:light[level=14]
setblock 481 198 503 minecraft:terracotta
fill 481 198 504 481 201 504 minecraft:red_terracotta
setblock 482 198 502 minecraft:terracotta
fill 482 198 503 482 201 503 minecraft:red_terracotta
setblock 483 198 501 minecraft:terracotta
fill 483 198 502 483 200 502 minecraft:red_terracotta
setblock 485 198 504 minecraft:terracotta
setblock 486 198 503 minecraft:terracotta
fill 486 198 504 486 201 504 minecraft:red_terracotta
setblock 489 198 466 minecraft:light[level=14]
setblock 489 198 474 minecraft:light[level=14]
setblock 489 198 482 minecraft:light[level=14]
setblock 489 198 490 minecraft:light[level=14]
setblock 489 198 498 minecraft:light[level=14]
fill 496 198 504 496 201 504 minecraft:red_terracotta
setblock 497 198 466 minecraft:light[level=14]
setblock 497 198 474 minecraft:light[level=14]
setblock 497 198 482 minecraft:light[level=14]
setblock 497 198 490 minecraft:light[level=14]
setblock 497 198 498 minecraft:light[level=14]
setblock 500 198 464 minecraft:terracotta
setblock 500 198 503 minecraft:red_terracotta
setblock 500 198 504 minecraft:terracotta
fill 501 198 464 501 201 464 minecraft:red_terracotta
fill 501 198 504 501 201 504 minecraft:red_terracotta
setblock 505 198 466 minecraft:light[level=14]
setblock 505 198 474 minecraft:light[level=14]
setblock 505 198 482 minecraft:light[level=14]
setblock 505 198 490 minecraft:light[level=14]
setblock 510 198 474 minecraft:terracotta
setblock 510 198 475 minecraft:red_terracotta
setblock 511 198 473 minecraft:terracotta
fill 511 198 474 511 200 474 minecraft:red_terracotta
setblock 511 198 478 minecraft:terracotta
fill 511 198 479 511 201 479 minecraft:red_terracotta
setblock 471 199 497 minecraft:terracotta
fill 471 199 498 471 202 498 minecraft:red_terracotta
setblock 471 199 502 minecraft:terracotta
fill 471 199 503 473 199 504 minecraft:red_terracotta
setblock 472 199 501 minecraft:terracotta
fill 472 199 502 472 202 502 minecraft:red_terracotta
setblock 474 199 464 minecraft:terracotta
fill 474 199 502 474 199 503 minecraft:red_terracotta
setblock 474 199 504 minecraft:terracotta
fill 475 199 464 475 202 464 minecraft:red_terracotta
setblock 475 199 502 minecraft:red_terracotta
setblock 475 199 503 minecraft:terracotta
fill 475 199 504 478 199 504 minecraft:red_terracotta
setblock 476 199 502 minecraft:terracotta
fill 476 199 503 476 202 503 minecraft:red_terracotta
setblock 477 199 501 minecraft:terracotta
fill 477 199 502 477 202 502 minecraft:red_terracotta
fill 478 199 501 478 202 501 minecraft:red_terracotta
setblock 479 199 464 minecraft:terracotta
setblock 479 199 504 minecraft:terracotta
fill 480 199 464 480 202 464 minecraft:red_terracotta
setblock 480 199 503 minecraft:terracotta
fill 480 199 504 480 202 504 minecraft:red_terracotta
setblock 481 199 502 minecraft:terracotta
fill 481 199 503 481 202 503 minecraft:red_terracotta
setblock 482 199 501 minecraft:terracotta
fill 482 199 502 482 202 502 minecraft:red_terracotta
setblock 484 199 504 minecraft:terracotta
setblock 485 199 503 minecraft:terracotta
fill 485 199 504 485 202 504 minecraft:red_terracotta
fill 495 199 504 495 202 504 minecraft:red_terracotta
setblock 499 199 464 minecraft:terracotta
setblock 499 199 504 minecraft:terracotta
fill 500 199 464 500 202 464 minecraft:red_terracotta
fill 500 199 504 500 202 504 minecraft:red_terracotta
setblock 511 199 472 minecraft:terracotta
setblock 511 199 473 minecraft:red_terracotta
setblock 511 199 477 minecraft:terracotta
fill 511 199 478 511 202 478 minecraft:red_terracotta
setblock 471 200 501 minecraft:terracotta
fill 471 200 502 471 201 504 minecraft:red_terracotta
setblock 472 200 464 minecraft:red_terracotta
setblock 472 200 500 minecraft:terracotta
fill 472 200 501 472 203 501 minecraft:red_terracotta
fill 472 200 503 472 200 504 minecraft:red_terracotta
setblock 473 200 464 minecraft:terracotta
setblock 473 200 503 minecraft:red_terracotta
setblock 473 200 504 minecraft:terracotta
fill 474 200 464 474 203 464 minecraft:red_terracotta
setblock 474 200 502 minecraft:red_terracotta
setblock 474 200 503 minecraft:terracotta
fill 474 200 504 477 200 504 minecraft:red_terracotta
setblock 475 200 502 minecraft:terracotta
fill 475 200 503 475 203 503 minecraft:red_terracotta
fill 476 200 502 476 203 502 minecraft:red_terracotta
fill 477 200 501 477 203 501 minecraft:red_terracotta
setblock 478 200 464 minecraft:terracotta
setblock 478 200 504 minecraft:terracotta
fill 479 200 464 479 203 464 minecraft:red_terracotta
setblock 479 200 503 minecraft:terracotta
fill 479 200 504 479 203 504 minecraft:red_terracotta
setblock 480 200 502 minecraft:terracotta
fill 480 200 503 480 203 503 minecraft:red_terracotta
setblock 481 200 501 minecraft:terracotta
fill 481 200 502 481 203 502 minecraft:red_terracotta
setblock 483 200 504 minecraft:terracotta
setblock 484 200 503 minecraft:terracotta
fill 484 200 504 484 203 504 minecraft:red_terracotta
setblock 485 200 503 minecraft:red_terracotta
setblock 498 200 464 minecraft:terracotta
setblock 498 200 504 minecraft:terracotta
fill 499 200 464 499 203 464 minecraft:red_terracotta
fill 499 200 504 499 203 504 minecraft:red_terracotta
setblock 503 200 504 minecraft:terracotta
setblock 511 200 476 minecraft:terracotta
fill 511 200 477 511 203 477 minecraft:red_terracotta
setblock 511 200 481 minecraft:terracotta
setblock 471 201 464 minecraft:red_terracotta
setblock 471 201 500 minecraft:terracotta
fill 471 201 501 471 204 501 minecraft:red_terracotta
setblock 472 201 464 minecraft:terracotta
setblock 472 201 499 minecraft:terracotta
fill 472 201 500 472 204 500 minecraft:red_terracotta
setblock 472 201 503 minecraft:red_terracotta
setblock 472 201 504 minecraft:terracotta
fill 473 201 464 473 204 464 minecraft:red_terracotta
setblock 473 201 502 minecraft:red_terracotta
setblock 473 201 503 minecraft:terracotta
fill 473 201 504 476 201 504 minecraft:red_terracotta
setblock 474 201 502 minecraft:terracotta
fill 474 201 503 474 204 503 minecraft:red_terracotta
fill 475 201 502 475 204 502 minecraft:red_terracotta
fill 476 201 501 476 204 501 minecraft:red_terracotta
setblock 477 201 464 minecraft:terracotta
setblock 477 201 504 minecraft:terracotta
fill 478 201 464 478 204 464 minecraft:red_terracotta
setblock 478 201 503 minecraft:terracotta
fill 478 201 504 478 204 504 minecraft:red_terracotta
setblock 479 201 502 minecraft:terracotta
fill 479 201 503 479 204 503 minecraft:red_terracotta
setblock 480 201 501 minecraft:terracotta
fill 480 201 502 480 204 502 minecraft:red_terracotta
setblock 482 201 504 minecraft:terracotta
setblock 483 201 503 minecraft:terracotta
fill 483 201 504 483 204 504 minecraft:red_terracotta
fill 484 201 503 484 204 503 minecraft:red_terracotta
fill 494 201 504 494 203 504 minecraft:red_terracotta
setblock 497 201 464 minecraft:terracotta
setblock 497 201 504 minecraft:terracotta
fill 498 201 464 498 204 464 minecraft:red_terracotta
setblock 498 201 503 minecraft:terracotta
fill 498 201 504 498 204 504 minecraft:red_terracotta
fill 499 201 503 499 204 503 minecraft:red_terracotta
setblock 502 201 464 minecraft:terracotta
setblock 502 201 504 minecraft:terracotta
fill 503 201 464 503 204 464 minecraft:red_terracotta
fill 503 201 504 503 204 504 minecraft:red_terracotta
setblock 511 201 464 minecraft:red_terracotta
setblock 511 201 475 minecraft:terracotta
fill 511 201 476 511 204 476 minecraft:red_terracotta
setblock 511 201 480 minecraft:terracotta
fill 511 201 481 511 204 481 minecraft:red_terracotta
fill 511 201 502 511 202 503 minecraft:red_terracotta
setblock 471 202 464 minecraft:terracotta
fill 471 202 465 471 205 465 minecraft:red_terracotta
setblock 471 202 499 minecraft:terracotta
fill 471 202 500 471 205 500 minecraft:red_terracotta
fill 471 202 502 471 202 503 minecraft:red_terracotta
setblock 471 202 504 minecraft:terracotta
fill 472 202 464 472 205 464 minecraft:red_terracotta
fill 472 202 499 472 205 499 minecraft:red_terracotta
setblock 472 202 503 minecraft:terracotta
fill 472 202 504 475 202 504 minecraft:red_terracotta
setblock 473 202 501 minecraft:red_terracotta
setblock 473 202 502 minecraft:terracotta
fill 473 202 503 473 205 503 minecraft:red_terracotta
fill 474 202 502 474 205 502 minecraft:red_terracotta
setblock 476 202 464 minecraft:terracotta
setblock 476 202 504 minecraft:terracotta
fill 477 202 464 477 205 464 minecraft:red_terracotta
setblock 477 202 503 minecraft:terracotta
fill 477 202 504 477 205 504 minecraft:red_terracotta
setblock 478 202 502 minecraft:terracotta
fill 478 202 503 478 205 503 minecraft:red_terracotta
setblock 479 202 501 minecraft:terracotta
fill 479 202 502 479 205 502 minecraft:red_terracotta
setblock 481 202 464 minecraft:terracotta
setblock 481 202 504 minecraft:terracotta
setblock 482 202 503 minecraft:terracotta
fill 482 202 504 482 205 504 minecraft:red_terracotta
fill 483 202 503 483 205 503 minecraft:red_terracotta
setblock 486 202 504 minecraft:terracotta
fill 493 202 504 493 204 504 minecraft:red_terracotta
setblock 496 202 464 minecraft:terracotta
setblock 496 202 503 minecraft:red_terracotta
setblock 496 202 504 minecraft:terracotta
fill 497 202 464 497 205 464 minecraft:red_terracotta
setblock 497 202 503 minecraft:terracotta
fill 497 202 504 497 205 504 minecraft:red_terracotta
fill 498 202 503 498 205 503 minecraft:red_terracotta
setblock 501 202 464 minecraft:terracotta
setblock 501 202 504 minecraft:terracotta
fill 502 202 464 502 205 464 minecraft:red_terracotta
fill 502 202 504 502 205 504 minecraft:red_terracotta
fill 504 202 464 504 203 464 minecraft:red_terracotta
setblock 510 202 464 minecraft:red_terracotta
setblock 510 202 504 minecraft:red_terracotta
setblock 511 202 464 minecraft:terracotta
fill 511 202 465 511 205 465 minecraft:red_terracotta
setblock 511 202 475 minecraft:red_terracotta
setblock 511 202 479 minecraft:terracotta
fill 511 202 480 511 205 480 minecraft:red_terracotta
fill 511 202 501 511 204 501 minecraft:red_terracotta
setblock 511 202 504 minecraft:terracotta
fill 471 203 464 471 206 464 minecraft:red_terracotta
fill 471 203 466 471 204 466 minecraft:red_terracotta
setblock 471 203 497 minecraft:red_terracotta
setblock 471 203 498 minecraft:terracotta
fill 471 203 499 471 206 499 minecraft:red_terracotta
setblock 471 203 502 minecraft:red_terracotta
setblock 471 203 503 minecraft:terracotta
fill 471 203 504 474 203 504 minecraft:red_terracotta
fill 472 203 498 472 206 498 minecraft:red_terracotta
setblock 472 203 502 minecraft:terracotta
fill 472 203 503 472 206 503 minecraft:red_terracotta
setblock 473 203 500 minecraft:red_terracotta
setblock 473 203 501 minecraft:terracotta
fill 473 203 502 473 206 502 minecraft:red_terracotta
setblock 474 203 465 minecraft:terracotta
setblock 475 203 464 minecraft:terracotta
fill 475 203 465 477 204 465 minecraft:red_terracotta
fill 475 203 501 475 205 501 minecraft:red_terracotta
setblock 475 203 504 minecraft:terracotta
fill 476 203 464 476 206 464 minecraft:red_terracotta
setblock 476 203 503 minecraft:terracotta
fill 476 203 504 476 206 504 minecraft:red_terracotta
setblock 477 203 502 minecraft:terracotta
fill 477 203 503 477 206 503 minecraft:red_terracotta
setblock 478 203 501 minecraft:terracotta
fill 478 203 502 478 206 502 minecraft:red_terracotta
fill 479 203 501 479 204 501 minecraft:red_terracotta
setblock 480 203 464 minecraft:terracotta
setblock 480 203 504 minecraft:terracotta
fill 481 203 464 481 206 464 minecraft:red_terracotta
setblock 481 203 503 minecraft:terracotta
fill 481 203 504 481 206 504 minecraft:red_terracotta
setblock 482 203 502 minecraft:terracotta
fill 482 203 503 482 206 503 minecraft:red_terracotta
setblock 485 203 504 minecraft:terracotta
fill 486 203 504 486 206 504 minecraft:red_terracotta
fill 491 203 504 492 205 504 minecraft:red_terracotta
setblock 494 203 464 minecraft:red_terracotta
setblock 495 203 464 minecraft:terracotta
setblock 495 203 503 minecraft:red_terracotta
setblock 495 203 504 minecraft:terracotta
fill 496 203 464 496 206 464 minecraft:red_terracotta
setblock 496 203 503 minecraft:terracotta
fill 496 203 504 496 206 504 minecraft:red_terracotta
fill 497 203 503 497 206 503 minecraft:red_terracotta
setblock 500 203 464 minecraft:terracotta
setblock 500 203 504 minecraft:terracotta
fill 501 203 464 501 206 464 minecraft:red_terracotta
fill 501 203 504 501 206 504 minecraft:red_terracotta
setblock 505 203 464 minecraft:terracotta
fill 506 203 464 509 203 464 minecraft:red_terracotta
setblock 509 203 504 minecraft:red_terracotta
setblock 510 203 464 minecraft:terracotta
setblock 510 203 504 minecraft:terracotta
fill 511 203 464 511 206 464 minecraft:red_terracotta
fill 511 203 466 511 203 467 minecraft:red_terracotta
setblock 511 203 478 minecraft:terracotta
fill 511 203 479 511 206 479 minecraft:red_terracotta
setblock 511 203 482 minecraft:red_terracotta
setblock 511 203 483 minecraft:terracotta
fill 511 203 500 511 205 500 minecraft:red_terracotta
setblock 511 203 502 minecraft:red_terracotta
setblock 511 203 503 minecraft:terracotta
fill 511 203 504 511 206 504 minecraft:red_terracotta
setblock 471 204 467 minecraft:terracotta
fill 471 204 480 471 204 481 minecraft:red_terracotta
setblock 471 204 482 minecraft:terracotta
fill 471 204 483 471 206 484 minecraft:red_terracotta
setblock 471 204 497 minecraft:terracotta
fill 471 204 498 471 207 498 minecraft:red_terracotta
setblock 471 204 502 minecraft:terracotta
fill 471 204 503 471 206 504 minecraft:red_terracotta
setblock 472 204 465 minecraft:red_terracotta
setblock 472 204 501 minecraft:terracotta
fill 472 204 502 472 207 502 minecraft:red_terracotta
fill 472 204 504 473 204 504 minecraft:red_terracotta
setblock 473 204 465 minecraft:terracotta
setblock 473 204 499 minecraft:red_terracotta
setblock 473 204 500 minecraft:terracotta
fill 473 204 501 474 206 501 minecraft:red_terracotta
setblock 474 204 464 minecraft:terracotta
fill 474 204 465 474 207 465 minecraft:red_terracotta
setblock 474 204 504 minecraft:terracotta
fill 475 204 464 475 207 464 minecraft:red_terracotta
setblock 475 204 503 minecraft:terracotta
fill 475 204 504 475 207 504 minecraft:red_terracotta
setblock 476 204 502 minecraft:terracotta
fill 476 204 503 476 207 503 minecraft:red_terracotta
setblock 477 204 501 minecraft:terracotta
fill 477 204 502 477 207 502 minecraft:red_terracotta
setblock 478 204 465 minecraft:terracotta
fill 478 204 501 478 206 501 minecraft:red_terracotta
setblock 479 204 464 minecraft:terracotta
setblock 479 204 504 minecraft:terracotta
fill 480 204 464 480 207 464 minecraft:red_terracotta
setblock 480 204 503 minecraft:terracotta
fill 480 204 504 480 207 504 minecraft:red_terracotta
setblock 481 204 502 minecraft:terracotta
fill 481 204 503 481 207 503 minecraft:red_terracotta
fill 482 204 464 482 205 464 minecraft:red_terracotta
setblock 484 204 504 minecraft:terracotta
fill 485 204 504 485 207 504 minecraft:red_terracotta
fill 487 204 504 488 204 504 minecraft:red_terracotta
setblock 489 204 504 minecraft:terracotta
fill 490 204 504 490 207 504 minecraft:red_terracotta
setblock 493 204 464 minecraft:red_terracotta
fill 493 204 503 494 204 503 minecraft:red_terracotta
setblock 494 204 464 minecraft:terracotta
setblock 494 204 504 minecraft:terracotta
fill 495 204 464 495 207 464 minecraft:red_terracotta
setblock 495 204 503 minecraft:terracotta
fill 495 204 504 495 207 504 minecraft:red_terracotta
fill 496 204 465 497 204 465 minecraft:red_terracotta
fill 496 204 503 496 207 503 minecraft:red_terracotta
setblock 498 204 465 minecraft:terracotta
setblock 499 204 464 minecraft:terracotta
fill 499 204 465 501 205 465 minecraft:red_terracotta
setblock 499 204 504 minecraft:terracotta
fill 500 204 464 500 207 464 minecraft:red_terracotta
setblock 500 204 503 minecraft:terracotta
fill 500 204 504 500 207 504 minecraft:red_terracotta
setblock 504 204 464 minecraft:terracotta
setblock 504 204 504 minecraft:terracotta
fill 505 204 464 508 204 464 minecraft:red_terracotta
fill 505 204 504 508 204 504 minecraft:red_terracotta
setblock 509 204 464 minecraft:terracotta
setblock 509 204 504 minecraft:terracotta
fill 510 204 464 510 207 464 minecraft:red_terracotta
fill 510 204 504 510 207 504 minecraft:red_terracotta
setblock 511 204 466 minecraft:red_terracotta
setblock 511 204 467 minecraft:terracotta
fill 511 204 468 511 206 469 minecraft:red_terracotta
fill 511 204 475 511 205 475 minecraft:red_terracotta
setblock 511 204 477 minecraft:terracotta
fill 511 204 478 511 207 478 minecraft:red_terracotta
setblock 511 204 482 minecraft:terracotta
fill 511 204 483 511 206 484 minecraft:red_terracotta
setblock 511 204 502 minecraft:terracotta
fill 511 204 503 511 207 503 minecraft:red_terracotta
setblock 471 205 466 minecraft:terracotta
fill 471 205 467 471 207 468 minecraft:red_terracotta
fill 471 205 479 471 205 480 minecraft:red_terracotta
setblock 471 205 481 minecraft:terracotta
fill 471 205 482 472 207 482 minecraft:red_terracotta
setblock 471 205 485 minecraft:red_terracotta
setblock 471 205 486 minecraft:terracotta
fill 471 205 487 471 208 487 minecraft:red_terracotta
setblock 471 205 496 minecraft:terracotta
fill 471 205 497 472 207 497 minecraft:red_terracotta
setblock 471 205 501 minecraft:terracotta
fill 471 205 502 471 208 502 minecraft:red_terracotta
setblock 472 205 465 minecraft:terracotta
fill 472 205 466 472 208 466 minecraft:red_terracotta
fill 472 205 483 472 205 484 minecraft:red_terracotta
setblock 472 205 500 minecraft:terracotta
fill 472 205 501 472 208 501 minecraft:red_terracotta
setblock 472 205 504 minecraft:red_terracotta
setblock 473 205 464 minecraft:terracotta
fill 473 205 465 473 208 465 minecraft:red_terracotta
setblock 473 205 499 minecraft:terracotta
fill 473 205 500 473 208 500 minecraft:red_terracotta
setblock 473 205 504 minecraft:terracotta
fill 474 205 464 474 208 464 minecraft:red_terracotta
setblock 474 205 503 minecraft:terracotta
fill 474 205 504 474 208 504 minecraft:red_terracotta
fill 475 205 465 476 205 465 minecraft:red_terracotta
setblock 475 205 502 minecraft:terracotta
fill 475 205 503 475 208 503 minecraft:red_terracotta
setblock 476 205 501 minecraft:terracotta
fill 476 205 502 476 208 502 minecraft:red_terracotta
setblock 477 205 465 minecraft:terracotta
fill 477 205 501 477 207 501 minecraft:red_terracotta
setblock 478 205 464 minecraft:terracotta
fill 478 205 465 479 207 465 minecraft:red_terracotta
setblock 478 205 504 minecraft:terracotta
fill 479 205 464 479 208 464 minecraft:red_terracotta
setblock 479 205 503 minecraft:terracotta
fill 479 205 504 479 208 504 minecraft:red_terracotta
setblock 480 205 502 minecraft:terracotta
fill 480 205 503 480 208 503 minecraft:red_terracotta
fill 481 205 502 481 206 502 minecraft:red_terracotta
setblock 483 205 504 minecraft:terracotta
fill 484 205 504 484 208 504 minecraft:red_terracotta
setblock 487 205 504 minecraft:red_terracotta
setblock 488 205 504 minecraft:terracotta
fill 489 205 504 489 208 504 minecraft:red_terracotta
fill 491 205 464 492 205 464 minecraft:red_terracotta
fill 492 205 503 493 205 503 minecraft:red_terracotta
setblock 493 205 464 minecraft:terracotta
setblock 493 205 504 minecraft:terracotta
fill 494 205 464 494 207 465 minecraft:red_terracotta
setblock 494 205 503 minecraft:terracotta
fill 494 205 504 494 208 504 minecraft:red_terracotta
fill 495 205 465 496 205 465 minecraft:red_terracotta
fill 495 205 503 495 208 503 minecraft:red_terracotta
setblock 497 205 465 minecraft:terracotta
setblock 498 205 464 minecraft:terracotta
fill 498 205 465 498 208 465 minecraft:red_terracotta
setblock 498 205 504 minecraft:terracotta
fill 499 205 464 499 208 464 minecraft:red_terracotta
setblock 499 205 503 minecraft:terracotta
fill 499 205 504 499 208 504 minecraft:red_terracotta
fill 500 205 503 500 206 503 minecraft:red_terracotta
setblock 502 205 465 minecraft:terracotta
setblock 503 205 464 minecraft:terracotta
fill 503 205 465 503 208 465 minecraft:red_terracotta
setblock 503 205 504 minecraft:terracotta
fill 504 205 464 507 205 464 minecraft:red_terracotta
fill 504 205 504 507 205 504 minecraft:red_terracotta
setblock 508 205 464 minecraft:terracotta
fill 508 205 465 510 206 465 minecraft:red_terracotta
setblock 508 205 504 minecraft:terracotta
fill 509 205 464 509 208 464 minecraft:red_terracotta
fill 509 205 504 509 208 504 minecraft:red_terracotta
setblock 510 205 466 minecraft:red_terracotta
setblock 510 205 467 minecraft:terracotta
fill 510 205 503 510 208 503 minecraft:red_terracotta
setblock 511 205 466 minecraft:terracotta
fill 511 205 467 511 208 467 minecraft:red_terracotta
setblock 511 205 470 minecraft:red_terracotta
setblock 511 205 471 minecraft:terracotta
fill 511 205 472 511 206 474 minecraft:red_terracotta
setblock 511 205 476 minecraft:terracotta
fill 511 205 477 511 208 477 minecraft:red_terracotta
setblock 511 205 481 minecraft:terracotta
fill 511 205 482 511 208 482 minecraft:red_terracotta
setblock 511 205 485 minecraft:red_terracotta
setblock 511 205 486 minecraft:terracotta
fill 511 205 499 511 206 499 minecraft:red_terracotta
setblock 511 205 501 minecraft:terracotta
fill 511 205 502 511 208 502 minecraft:red_terracotta
setblock 471 206 465 minecraft:terracotta
fill 471 206 466 471 209 466 minecraft:red_terracotta
setblock 471 206 469 minecraft:red_terracotta
fill 471 206 478 471 206 479 minecraft:red_terracotta
setblock 471 206 480 minecraft:terracotta
fill 471 206 481 472 208 481 minecraft:red_terracotta
setblock 471 206 485 minecraft:terracotta
fill 471 206 486 472 208 486 minecraft:red_terracotta
fill 471 206 488 471 206 489 minecraft:red_terracotta
setblock 471 206 490 minecraft:terracotta
fill 471 206 491 471 206 494 minecraft:red_terracotta
setblock 471 206 495 minecraft:terracotta
fill 471 206 496 472 208 496 minecraft:red_terracotta
setblock 471 206 500 minecraft:terracotta
fill 471 206 501 471 209 501 minecraft:red_terracotta
setblock 472 206 464 minecraft:terracotta
fill 472 206 465 472 209 465 minecraft:red_terracotta
fill 472 206 467 472 207 467 minecraft:red_terracotta
setblock 472 206 483 minecraft:red_terracotta
setblock 472 206 484 minecraft:terracotta
fill 472 206 485 472 209 485 minecraft:red_terracotta
fill 472 206 487 472 206 488 minecraft:red_terracotta
setblock 472 206 499 minecraft:terracotta
fill 472 206 500 472 209 500 minecraft:red_terracotta
setblock 472 206 504 minecraft:terracotta
fill 473 206 464 473 209 464 minecraft:red_terracotta
setblock 473 206 466 minecraft:light[level=14]
setblock 473 206 474 minecraft:light[level=14]
setblock 473 206 482 minecraft:light[level=14]
setblock 473 206 490 minecraft:light[level=14]
setblock 473 206 498 minecraft:terracotta
fill 473 206 499 473 209 499 minecraft:red_terracotta
setblock 473 206 503 minecraft:terracotta
fill 473 206 504 473 209 504 minecraft:red_terracotta
setblock 474 206 466 minecraft:red_terracotta
fill 474 206 500 474 207 500 minecraft:red_terracotta
setblock 474 206 502 minecraft:terracotta
fill 474 206 503 474 209 503 minecraft:red_terracotta
setblock 475 206 465 minecraft:red_terracotta
setblock 475 206 501 minecraft:terracotta
fill 475 206 502 475 209 502 minecraft:red_terracotta
setblock 476 206 465 minecraft:terracotta
fill 476 206 501 476 208 501 minecraft:red_terracotta
setblock 477 206 464 minecraft:terracotta
fill 477 206 465 477 209 465 minecraft:red_terracotta
setblock 477 206 504 minecraft:terracotta
fill 478 206 464 478 209 464 minecraft:red_terracotta
setblock 478 206 503 minecraft:terracotta
fill 478 206 504 478 209 504 minecraft:red_terracotta
setblock 479 206 502 minecraft:terracotta
fill 479 206 503 479 209 503 minecraft:red_terracotta
fill 480 206 502 480 207 502 minecraft:red_terracotta
setblock 481 206 466 minecraft:light[level=14]
setblock 481 206 474 minecraft:light[level=14]
setblock 481 206 482 minecraft:light[level=14]
setblock 481 206 490 minecraft:light[level=14]
setblock 481 206 498 minecraft:light[level=14]
setblock 482 206 464 minecraft:terracotta
setblock 482 206 504 minecraft:terracotta
setblock 483 206 503 minecraft:terracotta
fill 483 206 504 483 209 504 minecraft:red_terracotta
setblock 487 206 504 minecraft:terracotta
fill 488 206 504 488 209 504 minecraft:red_terracotta
fill 489 206 464 491 206 464 minecraft:red_terracotta
setblock 489 206 466 minecraft:light[level=14]
setblock 489 206 474 minecraft:light[level=14]
setblock 489 206 482 minecraft:light[level=14]
setblock 489 206 490 minecraft:light[level=14]
setblock 489 206 498 minecraft:light[level=14]
fill 491 206 503 491 206 504 minecraft:red_terracotta
setblock 492 206 464 minecraft:terracotta
fill 492 206 465 493 208 465 minecraft:red_terracotta
setblock 492 206 503 minecraft:red_terracotta
setblock 492 206 504 minecraft:terracotta
fill 493 206 464 493 209 464 minecraft:red_terracotta
setblock 493 206 503 minecraft:terracotta
fill 493 206 504 493 209 504 minecraft:red_terracotta
fill 494 206 503 494 209 503 minecraft:red_terracotta
setblock 495 206 465 minecraft:red_terracotta
setblock 496 206 465 minecraft:terracotta
fill 496 206 466 498 207 466 minecraft:red_terracotta
setblock 497 206 464 minecraft:terracotta
fill 497 206 465 497 209 465 minecraft:red_terracotta
setblock 497 206 474 minecraft:light[level=14]
setblock 497 206 482 minecraft:light[level=14]
setblock 497 206 490 minecraft:light[level=14]
setblock 497 206 498 minecraft:light[level=14]
setblock 497 206 504 minecraft:terracotta
fill 498 206 464 498 209 464 minecraft:red_terracotta
setblock 498 206 503 minecraft:terracotta
fill 498 206 504 498 209 504 minecraft:red_terracotta
fill 499 206 465 500 206 465 minecraft:red_terracotta
fill 499 206 503 499 208 503 minecraft:red_terracotta
setblock 501 206 465 minecraft:terracotta
setblock 502 206 464 minecraft:terracotta
fill 502 206 465 502 209 465 minecraft:red_terracotta
setblock 502 206 504 minecraft:terracotta
fill 503 206 464 506 206 464 minecraft:red_terracotta
fill 503 206 504 506 206 504 minecraft:red_terracotta
fill 504 206 465 505 206 465 minecraft:red_terracotta
setblock 505 206 466 minecraft:light[level=14]
setblock 505 206 474 minecraft:light[level=14]
setblock 505 206 482 minecraft:light[level=14]
setblock 505 206 490 minecraft:light[level=14]
setblock 506 206 465 minecraft:terracotta
setblock 507 206 464 minecraft:terracotta
fill 507 206 465 507 209 465 minecraft:red_terracotta
setblock 507 206 504 minecraft:terracotta
fill 508 206 464 508 209 464 minecraft:red_terracotta
fill 508 206 504 508 209 504 minecraft:red_terracotta
fill 509 206 503 509 209 503 minecraft:red_terracotta
setblock 510 206 466 minecraft:terracotta
fill 510 206 467 510 208 468 minecraft:red_terracotta
fill 510 206 502 510 209 502 minecraft:red_terracotta
setblock 511 206 465 minecraft:terracotta
fill 511 206 466 511 209 466 minecraft:red_terracotta
setblock 511 206 470 minecraft:terracotta
fill 511 206 471 511 209 471 minecraft:red_terracotta
setblock 511 206 475 minecraft:terracotta
fill 511 206 476 511 209 476 minecraft:red_terracotta
setblock 511 206 480 minecraft:terracotta
fill 511 206 481 511 209 481 minecraft:red_terracotta
setblock 511 206 485 minecraft:terracotta
fill 511 206 486 511 208 487 minecraft:red_terracotta
fill 511 206 498 511 207 498 minecraft:red_terracotta
setblock 511 206 500 minecraft:terracotta
fill 511 206 501 511 209 501 minecraft:red_terracotta
setblock 471 207 464 minecraft:terracotta
fill 471 207 465 471 210 465 minecraft:red_terracotta
setblock 471 207 469 minecraft:terracotta
fill 471 207 470 471 209 471 minecraft:red_terracotta
setblock 471 207 478 minecraft:red_terracotta
setblock 471 207 479 minecraft:terracotta
fill 471 207 480 472 209 480 minecraft:red_terracotta
setblock 471 207 483 minecraft:red_terracotta
setblock 471 207 484 minecraft:terracotta
fill 471 207 485 471 210 485 minecraft:red_terracotta
setblock 471 207 488 minecraft:red_terracotta
setblock 471 207 489 minecraft:terracotta
fill 471 207 490 471 207 493 minecraft:red_terracotta
setblock 471 207 494 minecraft:terracotta
fill 471 207 495 472 209 495 minecraft:red_terracotta
setblock 471 207 499 minecraft:terracotta
fill 471 207 500 471 210 500 minecraft:red_terracotta
setblock 471 207 503 minecraft:red_terracotta
setblock 471 207 504 minecraft:terracotta
fill 472 207 464 472 210 464 minecraft:red_terracotta
setblock 472 207 468 minecraft:terracotta
setblock 472 207 483 minecraft:terracotta
fill 472 207 484 473 209 484 minecraft:red_terracotta
setblock 472 207 487 minecraft:red_terracotta
setblock 472 207 488 minecraft:terracotta
fill 472 207 489 472 207 492 minecraft:red_terracotta
setblock 472 207 493 minecraft:terracotta
fill 472 207 494 472 210 494 minecraft:red_terracotta
setblock 472 207 498 minecraft:terracotta
fill 472 207 499 472 210 499 minecraft:red_terracotta
setblock 472 207 503 minecraft:terracotta
fill 472 207 504 472 210 504 minecraft:red_terracotta
setblock 473 207 466 minecraft:red_terracotta
fill 473 207 483 473 210 483 minecraft:red_terracotta
fill 473 207 485 473 207 486 minecraft:red_terracotta
setblock 473 207 487 minecraft:terracotta
fill 473 207 488 473 210 488 minecraft:red_terracotta
fill 473 207 498 473 210 498 minecraft:red_terracotta
setblock 473 207 501 minecraft:red_terracotta
setblock 473 207 502 minecraft:terracotta
fill 473 207 503 473 210 503 minecraft:red_terracotta
setblock 474 207 466 minecraft:terracotta
setblock 474 207 501 minecraft:terracotta
fill 474 207 502 474 210 502 minecraft:red_terracotta
setblock 475 207 465 minecraft:terracotta
fill 475 207 466 476 209 466 minecraft:red_terracotta
fill 475 207 501 475 208 501 minecraft:red_terracotta
setblock 476 207 464 minecraft:terracotta
fill 476 207 465 476 210 465 minecraft:red_terracotta
setblock 476 207 504 minecraft:terracotta
fill 477 207 464 477 210 464 minecraft:red_terracotta
setblock 477 207 503 minecraft:terracotta
fill 477 207 504 477 210 504 minecraft:red_terracotta
setblock 478 207 502 minecraft:terracotta
fill 478 207 503 478 210 503 minecraft:red_terracotta
fill 479 207 502 479 208 502 minecraft:red_terracotta
setblock 481 207 464 minecraft:terracotta
setblock 481 207 504 minecraft:terracotta
fill 482 207 464 483 209 464 minecraft:red_terracotta
setblock 482 207 503 minecraft:terracotta
fill 482 207 504 482 210 504 minecraft:red_terracotta
setblock 483 207 503 minecraft:red_terracotta
setblock 486 207 504 minecraft:terracotta
fill 487 207 464 490 207 464 minecraft:red_terracotta
fill 487 207 504 487 210 504 minecraft:red_terracotta
setblock 491 207 464 minecraft:terracotta
fill 491 207 465 491 210 465 minecraft:red_terracotta
setblock 491 207 503 minecraft:red_terracotta
setblock 491 207 504 minecraft:terracotta
fill 492 207 464 492 210 464 minecraft:red_terracotta
setblock 492 207 503 minecraft:terracotta
fill 492 207 504 492 210 504 minecraft:red_terracotta
fill 493 207 503 493 210 503 minecraft:red_terracotta
setblock 494 207 466 minecraft:terracotta
setblock 495 207 465 minecraft:terracotta
fill 495 207 466 495 210 466 minecraft:red_terracotta
setblock 496 207 464 minecraft:terracotta
fill 496 207 465 496 210 465 minecraft:red_terracotta
setblock 496 207 504 minecraft:terracotta
fill 497 207 464 497 210 464 minecraft:red_terracotta
setblock 497 207 503 minecraft:terracotta
fill 497 207 504 497 210 504 minecraft:red_terracotta
fill 498 207 503 498 208 503 minecraft:red_terracotta
setblock 499 207 465 minecraft:red_terracotta
setblock 499 207 466 minecraft:terracotta
setblock 500 207 465 minecraft:terracotta
fill 500 207 466 500 210 466 minecraft:red_terracotta
setblock 501 207 464 minecraft:terracotta
fill 501 207 465 501 210 465 minecraft:red_terracotta
setblock 501 207 504 minecraft:terracotta
fill 502 207 464 505 207 464 minecraft:red_terracotta
fill 502 207 504 505 207 504 minecraft:red_terracotta
setblock 504 207 465 minecraft:red_terracotta
setblock 505 207 465 minecraft:terracotta
setblock 506 207 464 minecraft:terracotta
fill 506 207 465 506 210 465 minecraft:red_terracotta
setblock 506 207 504 minecraft:terracotta
fill 507 207 464 507 210 464 minecraft:red_terracotta
fill 507 207 504 507 210 504 minecraft:red_terracotta
fill 508 207 465 509 207 465 minecraft:red_terracotta
fill 508 207 503 508 210 503 minecraft:red_terracotta
setblock 509 207 466 minecraft:terracotta
setblock 510 207 465 minecraft:terracotta
fill 510 207 466 510 210 466 minecraft:red_terracotta
setblock 510 207 469 minecraft:red_terracotta
setblock 510 207 470 minecraft:terracotta
fill 510 207 481 510 207 484 minecraft:red_terracotta
fill 510 207 501 510 210 501 minecraft:red_terracotta
setblock 511 207 464 minecraft:terracotta
fill 511 207 465 511 210 465 minecraft:red_terracotta
setblock 511 207 468 minecraft:red_terracotta
setblock 511 207 469 minecraft:terracotta
fill 511 207 470 511 210 470 minecraft:red_terracotta
fill 511 207 472 511 207 473 minecraft:red_terracotta
setblock 511 207 474 minecraft:terracotta
fill 511 207 475 511 210 475 minecraft:red_terracotta
setblock 511 207 479 minecraft:terracotta
fill 511 207 480 511 210 480 minecraft:red_terracotta
setblock 511 207 483 minecraft:red_terracotta
setblock 511 207 484 minecraft:terracotta
fill 511 207 485 511 210 485 minecraft:red_terracotta
setblock 511 207 488 minecraft:red_terracotta
setblock 511 207 489 minecraft:terracotta
setblock 511 207 499 minecraft:terracotta
fill 511 207 500 511 210 500 minecraft:red_terracotta
setblock 511 207 504 minecraft:terracotta
fill 471 208 464 471 211 464 minecraft:red_terracotta
setblock 471 208 467 minecraft:red_terracotta
setblock 471 208 468 minecraft:terracotta
fill 471 208 469 472 210 469 minecraft:red_terracotta
setblock 471 208 472 minecraft:red_terracotta
setblock 471 208 478 minecraft:terracotta
fill 471 208 479 471 211 479 minecraft:red_terracotta
setblock 471 208 482 minecraft:red_terracotta
setblock 471 208 483 minecraft:terracotta
fill 471 208 484 471 211 484 minecraft:red_terracotta
setblock 471 208 488 minecraft:terracotta
fill 471 208 489 471 208 492 minecraft:red_terracotta
setblock 471 208 493 minecraft:terracotta
fill 471 208 494 471 211 494 minecraft:red_terracotta
setblock 471 208 497 minecraft:red_terracotta
setblock 471 208 498 minecraft:terracotta
fill 471 208 499 471 211 499 minecraft:red_terracotta
setblock 471 208 503 minecraft:terracotta
fill 471 208 504 471 211 504 minecraft:red_terracotta
setblock 472 208 467 minecraft:terracotta
fill 472 208 468 472 211 468 minecraft:red_terracotta
setblock 472 208 482 minecraft:terracotta
fill 472 208 483 472 211 483 minecraft:red_terracotta
setblock 472 208 487 minecraft:terracotta
fill 472 208 488 472 208 491 minecraft:red_terracotta
setblock 472 208 492 minecraft:terracotta
fill 472 208 493 472 211 493 minecraft:red_terracotta
setblock 472 208 497 minecraft:terracotta
fill 472 208 498 472 211 498 minecraft:red_terracotta
setblock 472 208 502 minecraft:terracotta
fill 472 208 503 472 211 503 minecraft:red_terracotta
setblock 473 208 466 minecraft:terracotta
fill 473 208 467 473 211 467 minecraft:red_terracotta
fill 473 208 482 473 209 482 minecraft:red_terracotta
setblock 473 208 485 minecraft:red_terracotta
setblock 473 208 486 minecraft:terracotta
fill 473 208 487 473 211 487 minecraft:red_terracotta
fill 473 208 489 473 208 490 minecraft:red_terracotta
setblock 473 208 491 minecraft:terracotta
fill 473 208 497 473 210 497 minecraft:red_terracotta
setblock 473 208 501 minecraft:terracotta
fill 473 208 502 473 211 502 minecraft:red_terracotta
setblock 474 208 465 minecraft:terracotta
fill 474 208 466 474 211 466 minecraft:red_terracotta
setblock 474 208 500 minecraft:terracotta
fill 474 208 501 474 209 501 minecraft:red_terracotta
setblock 475 208 464 minecraft:terracotta
fill 475 208 465 475 211 465 minecraft:red_terracotta
setblock 475 208 504 minecraft:terracotta
fill 476 208 464 476 211 464 minecraft:red_terracotta
setblock 476 208 503 minecraft:terracotta
fill 476 208 504 476 211 504 minecraft:red_terracotta
setblock 477 208 502 minecraft:terracotta
fill 477 208 503 477 211 503 minecraft:red_terracotta
setblock 478 208 465 minecraft:red_terracotta
fill 478 208 502 478 209 502 minecraft:red_terracotta
setblock 479 208 465 minecraft:terracotta
fill 479 208 485 479 209 487 minecraft:orange_concrete
setblock 480 208 464 minecraft:terracotta
fill 480 208 486 480 209 486 minecraft:orange_concrete
setblock 480 208 504 minecraft:terracotta
fill 481 208 464 481 210 464 minecraft:red_terracotta
setblock 481 208 503 minecraft:terracotta
fill 481 208 504 481 211 504 minecraft:red_terracotta
setblock 482 208 503 minecraft:red_terracotta
setblock 484 208 464 minecraft:red_terracotta
setblock 485 208 464 minecraft:terracotta
setblock 485 208 504 minecraft:terracotta
fill 486 208 464 489 208 464 minecraft:red_terracotta
fill 486 208 504 486 210 504 minecraft:red_terracotta
setblock 490 208 464 minecraft:terracotta
fill 490 208 465 490 211 465 minecraft:red_terracotta
setblock 490 208 503 minecraft:red_terracotta
setblock 490 208 504 minecraft:terracotta
fill 491 208 464 491 211 464 minecraft:red_terracotta
setblock 491 208 503 minecraft:terracotta
fill 491 208 504 491 211 504 minecraft:red_terracotta
setblock 492 208 466 minecraft:red_terracotta
fill 492 208 503 492 210 503 minecraft:red_terracotta
setblock 493 208 466 minecraft:terracotta
setblock 494 208 464 minecraft:red_terracotta
setblock 494 208 465 minecraft:terracotta
fill 494 208 466 494 211 466 minecraft:red_terracotta
setblock 495 208 464 minecraft:terracotta
fill 495 208 465 495 211 465 minecraft:red_terracotta
setblock 495 208 504 minecraft:terracotta
fill 496 208 464 496 211 464 minecraft:red_terracotta
fill 496 208 466 497 208 466 minecraft:red_terracotta
setblock 496 208 503 minecraft:terracotta
fill 496 208 504 496 211 504 minecraft:red_terracotta
fill 497 208 503 497 209 503 minecraft:red_terracotta
setblock 498 208 466 minecraft:terracotta
setblock 499 208 465 minecraft:terracotta
fill 499 208 466 499 211 466 minecraft:red_terracotta
setblock 500 208 464 minecraft:terracotta
fill 500 208 465 500 211 465 minecraft:red_terracotta
setblock 500 208 504 minecraft:terracotta
fill 501 208 464 504 208 464 minecraft:red_terracotta
fill 501 208 466 501 209 466 minecraft:red_terracotta
fill 501 208 504 504 208 504 minecraft:red_terracotta
setblock 504 208 465 minecraft:terracotta
setblock 505 208 464 minecraft:terracotta
fill 505 208 465 505 211 465 minecraft:red_terracotta
setblock 505 208 504 minecraft:terracotta
fill 506 208 464 506 211 464 minecraft:red_terracotta
fill 506 208 504 506 211 504 minecraft:red_terracotta
setblock 507 208 466 minecraft:red_terracotta
setblock 508 208 465 minecraft:red_terracotta
setblock 508 208 466 minecraft:terracotta
setblock 509 208 465 minecraft:terracotta
fill 509 208 466 509 209 468 minecraft:red_terracotta
setblock 510 208 464 minecraft:terracotta
fill 510 208 465 510 211 465 minecraft:red_terracotta
setblock 510 208 469 minecraft:terracotta
fill 510 208 470 510 210 471 minecraft:red_terracotta
fill 510 208 481 510 208 483 minecraft:red_terracotta
setblock 510 208 484 minecraft:terracotta
fill 510 208 485 510 210 486 minecraft:red_terracotta
setblock 510 208 504 minecraft:terracotta
fill 511 208 464 511 211 464 minecraft:red_terracotta
setblock 511 208 468 minecraft:terracotta
fill 511 208 469 511 211 469 minecraft:red_terracotta
setblock 511 208 472 minecraft:red_terracotta
setblock 511 208 473 minecraft:terracotta
fill 511 208 474 511 211 474 minecraft:red_terracotta
setblock 511 208 478 minecraft:terracotta
fill 511 208 479 511 211 479 minecraft:red_terracotta
setblock 511 208 483 minecraft:terracotta
fill 511 208 484 511 211 484 minecraft:red_terracotta
setblock 511 208 488 minecraft:terracotta
fill 511 208 489 511 208 492 minecraft:red_terracotta
setblock 511 208 497 minecraft:red_terracotta
setblock 511 208 498 minecraft:terracotta
fill 511 208 499 511 211 499 minecraft:red_terracotta
setblock 511 208 503 minecraft:terracotta
fill 511 208 504 511 211 504 minecraft:red_terracotta
setblock 471 209 467 minecraft:terracotta
fill 471 209 468 471 212 468 minecraft:red_terracotta
setblock 471 209 472 minecraft:terracotta
fill 471 209 478 471 210 478 minecraft:red_terracotta
setblock 471 209 481 minecraft:red_terracotta
setblock 471 209 482 minecraft:terracotta
fill 471 209 483 471 212 483 minecraft:red_terracotta
setblock 471 209 486 minecraft:red_terracotta
setblock 471 209 487 minecraft:terracotta
fill 471 209 488 471 209 491 minecraft:red_terracotta
setblock 471 209 492 minecraft:terracotta
fill 471 209 493 471 212 493 minecraft:red_terracotta
setblock 471 209 496 minecraft:red_terracotta
setblock 471 209 497 minecraft:terracotta
fill 471 209 498 471 212 498 minecraft:red_terracotta
setblock 471 209 502 minecraft:terracotta
fill 471 209 503 471 212 503 minecraft:red_terracotta
setblock 472 209 466 minecraft:terracotta
fill 472 209 467 472 212 467 minecraft:red_terracotta
setblock 472 209 470 minecraft:red_terracotta
setblock 472 209 481 minecraft:terracotta
fill 472 209 482 472 212 482 minecraft:red_terracotta
setblock 472 209 486 minecraft:terracotta
fill 472 209 487 472 209 490 minecraft:red_terracotta
setblock 472 209 491 minecraft:terracotta
fill 472 209 492 473 211 492 minecraft:red_terracotta
setblock 472 209 496 minecraft:terracotta
fill 472 209 497 472 212 497 minecraft:red_terracotta
setblock 472 209 501 minecraft:terracotta
fill 472 209 502 472 212 502 minecraft:red_terracotta
setblock 473 209 465 minecraft:terracotta
fill 473 209 466 473 212 466 minecraft:red_terracotta
fill 473 209 468 473 210 468 minecraft:red_terracotta
setblock 473 209 485 minecraft:terracotta
fill 473 209 486 474 210 486 minecraft:red_terracotta
setblock 473 209 489 minecraft:red_terracotta
setblock 473 209 490 minecraft:terracotta
fill 473 209 491 473 212 491 minecraft:red_terracotta
fill 473 209 493 473 209 494 minecraft:red_terracotta
setblock 473 209 495 minecraft:terracotta
fill 473 209 496 473 211 496 minecraft:red_terracotta
setblock 473 209 500 minecraft:terracotta
fill 473 209 501 473 211 501 minecraft:red_terracotta
setblock 474 209 464 minecraft:terracotta
fill 474 209 465 474 212 465 minecraft:red_terracotta
setblock 474 209 485 minecraft:red_terracotta
fill 474 209 487 474 209 488 minecraft:red_terracotta
setblock 474 209 489 minecraft:terracotta
setblock 474 209 504 minecraft:terracotta
fill 475 209 464 475 212 464 minecraft:red_terracotta
setblock 475 209 503 minecraft:terracotta
fill 475 209 504 475 212 504 minecraft:red_terracotta
setblock 476 209 502 minecraft:terracotta
fill 476 209 503 476 212 503 minecraft:red_terracotta
fill 477 209 474 477 210 474 minecraft:orange_concrete
fill 477 209 502 477 210 502 minecraft:red_terracotta
setblock 478 209 465 minecraft:terracotta
setblock 479 209 464 minecraft:terracotta
setblock 479 209 465 minecraft:red_terracotta
setblock 479 209 504 minecraft:terracotta
fill 480 209 464 480 211 464 minecraft:red_terracotta
setblock 480 209 503 minecraft:terracotta
fill 480 209 504 480 211 504 minecraft:red_terracotta
setblock 481 209 503 minecraft:red_terracotta
setblock 484 209 464 minecraft:terracotta
setblock 484 209 504 minecraft:terracotta
fill 485 209 464 488 209 464 minecraft:red_terracotta
setblock 485 209 504 minecraft:red_terracotta
setblock 489 209 464 minecraft:terracotta
fill 489 209 465 489 212 465 minecraft:red_terracotta
setblock 489 209 504 minecraft:terracotta
fill 490 209 464 490 212 464 minecraft:red_terracotta
fill 490 209 504 490 212 504 minecraft:red_terracotta
setblock 491 209 466 minecraft:red_terracotta
setblock 491 209 503 minecraft:red_terracotta
setblock 492 209 465 minecraft:red_terracotta
setblock 492 209 466 minecraft:terracotta
setblock 493 209 465 minecraft:terracotta
fill 493 209 466 493 212 466 minecraft:red_terracotta
setblock 494 209 464 minecraft:terracotta
fill 494 209 465 494 212 465 minecraft:red_terracotta
setblock 494 209 504 minecraft:terracotta
fill 495 209 464 495 212 464 minecraft:red_terracotta
setblock 495 209 503 minecraft:terracotta
fill 495 209 504 495 212 504 minecraft:red_terracotta
setblock 496 209 466 minecraft:red_terracotta
setblock 496 209 503 minecraft:red_terracotta
setblock 497 209 466 minecraft:terracotta
setblock 498 209 465 minecraft:terracotta
fill 498 209 466 498 212 466 minecraft:red_terracotta
setblock 499 209 464 minecraft:terracotta
fill 499 209 465 499 212 465 minecraft:red_terracotta
setblock 499 209 504 minecraft:terracotta
fill 500 209 464 503 209 464 minecraft:red_terracotta
fill 500 209 504 503 209 504 minecraft:red_terracotta
setblock 502 209 466 minecraft:terracotta
setblock 503 209 465 minecraft:terracotta
setblock 504 209 464 minecraft:terracotta
fill 504 209 465 504 212 465 minecraft:red_terracotta
setblock 504 209 504 minecraft:terracotta
fill 505 209 464 505 212 464 minecraft:red_terracotta
fill 505 209 504 505 212 504 minecraft:red_terracotta
setblock 506 209 466 minecraft:red_terracotta
setblock 507 209 466 minecraft:terracotta
setblock 508 209 465 minecraft:terracotta
fill 508 209 466 508 212 466 minecraft:red_terracotta
setblock 509 209 464 minecraft:terracotta
fill 509 209 465 509 212 465 minecraft:red_terracotta
setblock 509 209 504 minecraft:terracotta
fill 510 209 464 510 212 464 minecraft:red_terracotta
setblock 510 209 467 minecraft:red_terracotta
setblock 510 209 468 minecraft:terracotta
fill 510 209 469 510 212 469 minecraft:red_terracotta
setblock 510 209 472 minecraft:red_terracotta
setblock 510 209 482 minecraft:red_terracotta
setblock 510 209 483 minecraft:terracotta
fill 510 209 484 510 211 484 minecraft:red_terracotta
setblock 510 209 487 minecraft:red_terracotta
setblock 510 209 488 minecraft:terracotta
setblock 510 209 503 minecraft:terracotta
fill 510 209 504 510 212 504 minecraft:red_terracotta
setblock 511 209 467 minecraft:terracotta
fill 511 209 468 511 212 468 minecraft:red_terracotta
setblock 511 209 472 minecraft:terracotta
fill 511 209 473 511 212 473 minecraft:red_terracotta
setblock 511 209 477 minecraft:terracotta
fill 511 209 478 511 211 478 minecraft:red_terracotta
setblock 511 209 482 minecraft:terracotta
fill 511 209 483 511 212 483 minecraft:red_terracotta
setblock 511 209 486 minecraft:red_terracotta
setblock 511 209 487 minecraft:terracotta
fill 511 209 488 511 209 491 minecraft:red_terracotta
setblock 511 209 492 minecraft:terracotta
fill 511 209 493 511 209 496 minecraft:red_terracotta
setblock 511 209 497 minecraft:terracotta
fill 511 209 498 511 212 498 minecraft:red_terracotta
setblock 511 209 502 minecraft:terracotta
fill 511 209 503 511 212 503 minecraft:red_terracotta
setblock 471 210 466 minecraft:terracotta
fill 471 210 467 471 213 467 minecraft:red_terracotta
setblock 471 210 470 minecraft:red_terracotta
setblock 471 210 471 minecraft:terracotta
fill 471 210 472 471 212 473 minecraft:red_terracotta
setblock 471 210 480 minecraft:red_terracotta
setblock 471 210 481 minecraft:terracotta
fill 471 210 482 471 213 482 minecraft:red_terracotta
setblock 471 210 486 minecraft:terracotta
fill 471 210 487 471 210 490 minecraft:red_terracotta
setblock 471 210 491 minecraft:terracotta
fill 471 210 492 471 213 492 minecraft:red_terracotta
setblock 471 210 495 minecraft:red_terracotta
setblock 471 210 496 minecraft:terracotta
fill 471 210 497 471 213 497 minecraft:red_terracotta
setblock 471 210 501 minecraft:terracotta
fill 471 210 502 471 213 502 minecraft:red_terracotta
setblock 472 210 465 minecraft:terracotta
fill 472 210 466 472 213 466 minecraft:red_terracotta
setblock 472 210 470 minecraft:terracotta
setblock 472 210 481 minecraft:red_terracotta
setblock 472 210 484 minecraft:red_terracotta
setblock 472 210 485 minecraft:terracotta
fill 472 210 486 472 210 489 minecraft:red_terracotta
setblock 472 210 490 minecraft:terracotta
fill 472 210 491 472 213 491 minecraft:red_terracotta
setblock 472 210 495 minecraft:terracotta
fill 472 210 496 472 213 496 minecraft:red_terracotta
setblock 472 210 500 minecraft:terracotta
fill 472 210 501 472 213 501 minecraft:red_terracotta
setblock 473 210 464 minecraft:terracotta
fill 473 210 465 473 213 465 minecraft:red_terracotta
setblock 473 210 484 minecraft:terracotta
fill 473 210 485 473 212 485 minecraft:red_terracotta
setblock 473 210 489 minecraft:terracotta
fill 473 210 490 474 212 490 minecraft:red_terracotta
setblock 473 210 493 minecraft:red_terracotta
setblock 473 210 494 minecraft:terracotta
fill 473 210 495 473 213 495 minecraft:red_terracotta
setblock 473 210 499 minecraft:terracotta
fill 473 210 500 473 211 500 minecraft:red_terracotta
setblock 473 210 504 minecraft:terracotta
fill 474 210 464 474 213 464 minecraft:red_terracotta
setblock 474 210 487 minecraft:red_terracotta
setblock 474 210 488 minecraft:terracotta
fill 474 210 489 474 212 489 minecraft:red_terracotta
setblock 474 210 503 minecraft:terracotta
fill 474 210 504 474 213 504 minecraft:red_terracotta
setblock 475 210 466 minecraft:red_terracotta
setblock 475 210 502 minecraft:terracotta
fill 475 210 503 475 213 503 minecraft:red_terracotta
setblock 476 210 466 minecraft:terracotta
setblock 476 210 502 minecraft:red_terracotta
setblock 477 210 465 minecraft:terracotta
setblock 478 210 464 minecraft:terracotta
fill 478 210 465 478 211 465 minecraft:red_terracotta
setblock 478 210 504 minecraft:terracotta
fill 479 210 464 479 212 464 minecraft:red_terracotta
setblock 479 210 503 minecraft:terracotta
fill 479 210 504 479 212 504 minecraft:red_terracotta
setblock 482 210 464 minecraft:red_terracotta
setblock 483 210 504 minecraft:terracotta
setblock 484 210 504 minecraft:red_terracotta
fill 485 210 464 487 210 464 minecraft:red_terracotta
setblock 488 210 464 minecraft:terracotta
fill 488 210 465 488 213 465 minecraft:red_terracotta
setblock 488 210 504 minecraft:terracotta
fill 489 210 464 489 213 464 minecraft:red_terracotta
fill 489 210 504 489 212 504 minecraft:red_terracotta
setblock 491 210 466 minecraft:terracotta
setblock 492 210 465 minecraft:terracotta
fill 492 210 466 492 213 466 minecraft:red_terracotta
setblock 493 210 464 minecraft:terracotta
fill 493 210 465 493 213 465 minecraft:red_terracotta
setblock 493 210 504 minecraft:terracotta
fill 494 210 464 494 213 464 minecraft:red_terracotta
setblock 494 210 467 minecraft:red_terracotta
setblock 494 210 503 minecraft:terracotta
fill 494 210 504 494 213 504 minecraft:red_terracotta
setblock 495 210 467 minecraft:terracotta
setblock 495 210 503 minecraft:red_terracotta
setblock 496 210 466 minecraft:terracotta
setblock 497 210 465 minecraft:terracotta
fill 497 210 466 497 213 466 minecraft:red_terracotta
setblock 498 210 464 minecraft:terracotta
fill 498 210 465 498 213 465 minecraft:red_terracotta
setblock 498 210 504 minecraft:terracotta
fill 499 210 464 502 210 464 minecraft:red_terracotta
fill 499 210 504 502 210 504 minecraft:red_terracotta
setblock 501 210 466 minecraft:terracotta
setblock 502 210 465 minecraft:terracotta
setblock 503 210 464 minecraft:terracotta
fill 503 210 465 503 213 465 minecraft:red_terracotta
setblock 503 210 504 minecraft:terracotta
fill 504 210 464 504 213 464 minecraft:red_terracotta
fill 504 210 504 504 211 504 minecraft:red_terracotta
setblock 505 210 466 minecraft:red_terracotta
setblock 506 210 466 minecraft:terracotta
setblock 507 210 465 minecraft:terracotta
fill 507 210 466 507 213 466 minecraft:red_terracotta
setblock 508 210 464 minecraft:terracotta
fill 508 210 465 508 213 465 minecraft:red_terracotta
setblock 508 210 504 minecraft:terracotta
fill 509 210 464 509 213 464 minecraft:red_terracotta
fill 509 210 466 509 210 467 minecraft:red_terracotta
setblock 509 210 468 minecraft:terracotta
fill 509 210 469 509 213 469 minecraft:red_terracotta
setblock 509 210 503 minecraft:terracotta
fill 509 210 504 509 213 504 minecraft:red_terracotta
setblock 510 210 467 minecraft:terracotta
fill 510 210 468 510 213 468 minecraft:red_terracotta
setblock 510 210 472 minecraft:terracotta
setblock 510 210 483 minecraft:red_terracotta
setblock 510 210 487 minecraft:terracotta
fill 510 210 488 511 211 489 minecraft:red_terracotta
setblock 510 210 502 minecraft:terracotta
fill 510 210 503 510 213 503 minecraft:red_terracotta
setblock 511 210 466 minecraft:terracotta
fill 511 210 467 511 213 467 minecraft:red_terracotta
setblock 511 210 471 minecraft:terracotta
fill 511 210 472 511 213 472 minecraft:red_terracotta
setblock 511 210 476 minecraft:terracotta
fill 511 210 477 511 211 477 minecraft:red_terracotta
setblock 511 210 481 minecraft:terracotta
fill 511 210 482 511 213 482 minecraft:red_terracotta
setblock 511 210 486 minecraft:terracotta
fill 511 210 487 511 213 487 minecraft:red_terracotta
setblock 511 210 490 minecraft:red_terracotta
setblock 511 210 491 minecraft:terracotta
fill 511 210 492 511 210 495 minecraft:red_terracotta
setblock 511 210 496 minecraft:terracotta
fill 511 210 497 511 213 497 minecraft:red_terracotta
setblock 511 210 501 minecraft:terracotta
fill 511 210 502 511 213 502 minecraft:red_terracotta
setblock 471 211 465 minecraft:terracotta
fill 471 211 466 471 214 466 minecraft:red_terracotta
setblock 471 211 469 minecraft:red_terracotta
setblock 471 211 470 minecraft:terracotta
fill 471 211 471 471 214 471 minecraft:red_terracotta
setblock 471 211 480 minecraft:terracotta
fill 471 211 481 471 213 481 minecraft:red_terracotta
setblock 471 211 485 minecraft:terracotta
fill 471 211 486 471 211 489 minecraft:red_terracotta
setblock 471 211 490 minecraft:terracotta
fill 471 211 491 471 214 491 minecraft:red_terracotta
setblock 471 211 495 minecraft:terracotta
fill 471 211 496 471 214 496 minecraft:red_terracotta
setblock 471 211 500 minecraft:terracotta
fill 471 211 501 471 214 501 minecraft:red_terracotta
setblock 472 211 464 minecraft:terracotta
fill 472 211 465 472 214 465 minecraft:red_terracotta
setblock 472 211 469 minecraft:terracotta
fill 472 211 470 472 214 470 minecraft:red_terracotta
setblock 472 211 484 minecraft:terracotta
fill 472 211 485 472 211 488 minecraft:red_terracotta
setblock 472 211 489 minecraft:terracotta
fill 472 211 490 472 214 490 minecraft:red_terracotta
setblock 472 211 494 minecraft:terracotta
fill 472 211 495 472 214 495 minecraft:red_terracotta
setblock 472 211 499 minecraft:terracotta
fill 472 211 500 472 214 500 minecraft:red_terracotta
setblock 472 211 504 minecraft:terracotta
fill 473 211 464 473 214 464 minecraft:red_terracotta
setblock 473 211 468 minecraft:terracotta
setblock 473 211 484 minecraft:red_terracotta
fill 473 211 486 473 212 486 minecraft:red_terracotta
setblock 473 211 488 minecraft:terracotta
fill 473 211 489 473 214 489 minecraft:red_terracotta
setblock 473 211 493 minecraft:terracotta
fill 473 211 494 473 214 494 minecraft:red_terracotta
setblock 473 211 499 minecraft:red_terracotta
setblock 473 211 503 minecraft:terracotta
fill 473 211 504 473 214 504 minecraft:red_terracotta
setblock 474 211 487 minecraft:terracotta
fill 474 211 488 474 212 488 minecraft:red_terracotta
setblock 474 211 502 minecraft:terracotta
fill 474 211 503 474 213 503 minecraft:red_terracotta
setblock 475 211 466 minecraft:terracotta
setblock 475 211 502 minecraft:red_terracotta
setblock 476 211 465 minecraft:terracotta
setblock 477 211 464 minecraft:terracotta
setblock 477 211 465 minecraft:red_terracotta
setblock 477 211 504 minecraft:terracotta
fill 478 211 464 478 212 464 minecraft:red_terracotta
setblock 478 211 503 minecraft:terracotta
fill 478 211 504 478 212 504 minecraft:red_terracotta
setblock 486 211 464 minecraft:red_terracotta
setblock 487 211 464 minecraft:terracotta
fill 488 211 464 488 214 464 minecraft:red_terracotta
setblock 488 211 504 minecraft:red_terracotta
setblock 490 211 466 minecraft:terracotta
setblock 491 211 465 minecraft:terracotta
fill 491 211 466 491 214 466 minecraft:red_terracotta
setblock 492 211 464 minecraft:terracotta
fill 492 211 465 492 214 465 minecraft:red_terracotta
setblock 492 211 504 minecraft:terracotta
fill 493 211 464 493 214 464 minecraft:red_terracotta
fill 493 211 504 493 213 504 minecraft:red_terracotta
setblock 494 211 467 minecraft:terracotta
setblock 495 211 466 minecraft:terracotta
setblock 495 211 467 minecraft:red_terracotta
setblock 496 211 465 minecraft:terracotta
fill 496 211 466 496 213 466 minecraft:red_terracotta
setblock 497 211 464 minecraft:terracotta
fill 497 211 465 497 214 465 minecraft:red_terracotta
setblock 497 211 504 minecraft:terracotta
fill 498 211 464 501 211 464 minecraft:red_terracotta
fill 498 211 504 499 211 504 minecraft:red_terracotta
setblock 500 211 466 minecraft:terracotta
setblock 501 211 465 minecraft:terracotta
setblock 502 211 464 minecraft:terracotta
fill 502 211 465 502 214 465 minecraft:red_terracotta
fill 503 211 464 503 214 464 minecraft:red_terracotta
setblock 505 211 466 minecraft:terracotta
setblock 506 211 465 minecraft:terracotta
fill 506 211 466 506 214 466 minecraft:red_terracotta
setblock 507 211 464 minecraft:terracotta
fill 507 211 465 507 214 465 minecraft:red_terracotta
setblock 507 211 504 minecraft:terracotta
fill 508 211 464 508 214 464 minecraft:red_terracotta
setblock 508 211 503 minecraft:terracotta
fill 508 211 504 508 214 504 minecraft:red_terracotta
setblock 509 211 466 minecraft:red_terracotta
setblock 509 211 467 minecraft:terracotta
fill 509 211 468 509 214 468 minecraft:red_terracotta
fill 509 211 470 510 211 470 minecraft:red_terracotta
fill 509 211 503 509 214 503 minecraft:red_terracotta
setblock 510 211 466 minecraft:terracotta
fill 510 211 467 510 214 467 minecraft:red_terracotta
setblock 510 211 471 minecraft:terracotta
fill 510 211 472 510 214 472 minecraft:red_terracotta
setblock 510 211 485 minecraft:red_terracotta
setblock 510 211 486 minecraft:terracotta
fill 510 211 487 510 214 487 minecraft:red_terracotta
setblock 510 211 490 minecraft:red_terracotta
setblock 510 211 501 minecraft:terracotta
fill 510 211 502 510 214 502 minecraft:red_terracotta
setblock 511 211 465 minecraft:terracotta
fill 511 211 466 511 214 466 minecraft:red_terracotta
setblock 511 211 470 minecraft:terracotta
fill 511 211 471 511 214 471 minecraft:red_terracotta
setblock 511 211 475 minecraft:terracotta
fill 511 211 476 511 212 476 minecraft:red_terracotta
setblock 511 211 480 minecraft:terracotta
fill 511 211 481 511 212 481 minecraft:red_terracotta
setblock 511 211 485 minecraft:terracotta
fill 511 211 486 511 214 486 minecraft:red_terracotta
setblock 511 211 490 minecraft:terracotta
fill 511 211 491 511 211 494 minecraft:red_terracotta
setblock 511 211 495 minecraft:terracotta
fill 511 211 496 511 214 496 minecraft:red_terracotta
setblock 511 211 500 minecraft:terracotta
fill 511 211 501 511 214 501 minecraft:red_terracotta
setblock 471 212 464 minecraft:terracotta
fill 471 212 465 471 215 465 minecraft:red_terracotta
setblock 471 212 469 minecraft:terracotta
fill 471 212 470 471 215 470 minecraft:red_terracotta
setblock 471 212 480 minecraft:red_terracotta
setblock 471 212 484 minecraft:terracotta
fill 471 212 485 471 212 488 minecraft:red_terracotta
setblock 471 212 489 minecraft:terracotta
fill 471 212 490 471 215 490 minecraft:red_terracotta
setblock 471 212 494 minecraft:terracotta
fill 471 212 495 471 215 495 minecraft:red_terracotta
setblock 471 212 499 minecraft:terracotta
fill 471 212 500 471 215 500 minecraft:red_terracotta
setblock 471 212 504 minecraft:terracotta
fill 472 212 464 472 215 464 minecraft:red_terracotta
setblock 472 212 468 minecraft:terracotta
fill 472 212 469 472 215 469 minecraft:red_terracotta
setblock 472 212 483 minecraft:terracotta
fill 472 212 484 472 212 487 minecraft:red_terracotta
setblock 472 212 488 minecraft:terracotta
fill 472 212 489 472 215 489 minecraft:red_terracotta
setblock 472 212 492 minecraft:red_terracotta
setblock 472 212 493 minecraft:terracotta
fill 472 212 494 472 215 494 minecraft:red_terracotta
setblock 472 212 498 minecraft:terracotta
fill 472 212 499 472 215 499 minecraft:red_terracotta
setblock 472 212 503 minecraft:terracotta
fill 472 212 504 472 215 504 minecraft:red_terracotta
setblock 473 212 467 minecraft:terracotta
setblock 473 212 487 minecraft:terracotta
fill 473 212 488 473 215 488 minecraft:red_terracotta
setblock 473 212 492 minecraft:terracotta
fill 473 212 493 473 215 493 minecraft:red_terracotta
setblock 473 212 502 minecraft:terracotta
fill 473 212 503 473 214 503 minecraft:red_terracotta
setblock 474 212 466 minecraft:terracotta
setblock 475 212 465 minecraft:terracotta
setblock 476 212 464 minecraft:terracotta
setblock 476 212 465 minecraft:red_terracotta
setblock 476 212 504 minecraft:terracotta
fill 477 212 464 477 213 464 minecraft:red_terracotta
fill 477 212 504 477 213 504 minecraft:red_terracotta
setblock 486 212 464 minecraft:terracotta
fill 487 212 464 487 215 464 minecraft:red_terracotta
setblock 490 212 465 minecraft:terracotta
fill 490 212 466 490 213 466 minecraft:red_terracotta
setblock 491 212 464 minecraft:terracotta
fill 491 212 465 491 215 465 minecraft:red_terracotta
setblock 491 212 504 minecraft:terracotta
fill 492 212 464 492 215 464 minecraft:red_terracotta
fill 492 212 504 492 213 504 minecraft:red_terracotta
setblock 494 212 466 minecraft:terracotta
setblock 495 212 465 minecraft:terracotta
fill 495 212 466 495 214 466 minecraft:red_terracotta
setblock 496 212 464 minecraft:terracotta
fill 496 212 465 496 215 465 minecraft:red_terracotta
setblock 496 212 504 minecraft:terracotta
fill 497 212 464 500 212 464 minecraft:red_terracotta
setblock 497 212 504 minecraft:red_terracotta
setblock 499 212 466 minecraft:terracotta
setblock 500 212 465 minecraft:terracotta
setblock 501 212 464 minecraft:terracotta
fill 501 212 465 501 213 465 minecraft:red_terracotta
fill 502 212 464 502 215 464 minecraft:red_terracotta
setblock 505 212 465 minecraft:terracotta
setblock 505 212 466 minecraft:red_terracotta
setblock 506 212 464 minecraft:terracotta
fill 506 212 465 506 215 465 minecraft:red_terracotta
fill 506 212 483 506 213 484 minecraft:magma_block
setblock 506 212 504 minecraft:terracotta
fill 507 212 464 507 215 464 minecraft:red_terracotta
fill 507 212 504 507 215 504 minecraft:red_terracotta
setblock 509 212 466 minecraft:terracotta
fill 509 212 467 509 215 467 minecraft:red_terracotta
setblock 509 212 470 minecraft:red_terracotta
setblock 510 212 465 minecraft:terracotta
fill 510 212 466 510 215 466 minecraft:red_terracotta
setblock 510 212 470 minecraft:terracotta
fill 510 212 471 510 215 471 minecraft:red_terracotta
setblock 510 212 485 minecraft:terracotta
fill 510 212 486 510 213 486 minecraft:red_terracotta
fill 510 212 488 510 212 489 minecraft:red_terracotta
setblock 510 212 490 minecraft:terracotta
fill 510 212 491 511 214 491 minecraft:red_terracotta
setblock 510 212 501 minecraft:red_terracotta
setblock 511 212 464 minecraft:terracotta
fill 511 212 465 511 215 465 minecraft:red_terracotta
setblock 511 212 469 minecraft:terracotta
fill 511 212 470 511 215 470 minecraft:red_terracotta
setblock 511 212 474 minecraft:terracotta
fill 511 212 475 511 215 475 minecraft:red_terracotta
setblock 511 212 480 minecraft:red_terracotta
setblock 511 212 484 minecraft:terracotta
fill 511 212 485 511 215 485 minecraft:red_terracotta
setblock 511 212 488 minecraft:red_terracotta
setblock 511 212 489 minecraft:terracotta
fill 511 212 490 511 215 490 minecraft:red_terracotta
fill 511 212 492 511 212 493 minecraft:red_terracotta
setblock 511 212 494 minecraft:terracotta
fill 511 212 495 511 215 495 minecraft:red_terracotta
setblock 511 212 499 minecraft:terracotta
fill 511 212 500 511 215 500 minecraft:red_terracotta
setblock 511 212 504 minecraft:terracotta
fill 471 213 464 471 216 464 minecraft:red_terracotta
setblock 471 213 468 minecraft:terracotta
fill 471 213 469 471 216 469 minecraft:red_terracotta
setblock 471 213 472 minecraft:red_terracotta
setblock 471 213 473 minecraft:terracotta
setblock 471 213 483 minecraft:terracotta
fill 471 213 484 471 213 487 minecraft:red_terracotta
setblock 471 213 488 minecraft:terracotta
fill 471 213 489 471 216 489 minecraft:red_terracotta
setblock 471 213 493 minecraft:terracotta
fill 471 213 494 471 216 494 minecraft:red_terracotta
setblock 471 213 498 minecraft:terracotta
fill 471 213 499 471 216 499 minecraft:red_terracotta
setblock 471 213 503 minecraft:terracotta
fill 471 213 504 471 216 504 minecraft:red_terracotta
setblock 472 213 467 minecraft:terracotta
fill 472 213 468 472 216 468 minecraft:red_terracotta
fill 472 213 483 472 213 486 minecraft:red_terracotta
setblock 472 213 487 minecraft:terracotta
fill 472 213 488 472 216 488 minecraft:red_terracotta
setblock 472 213 492 minecraft:terracotta
fill 472 213 493 472 216 493 minecraft:red_terracotta
setblock 472 213 497 minecraft:terracotta
fill 472 213 498 472 216 498 minecraft:red_terracotta
setblock 472 213 502 minecraft:terracotta
fill 472 213 503 472 215 503 minecraft:red_terracotta
setblock 473 213 486 minecraft:terracotta
fill 473 213 487 473 215 487 minecraft:red_terracotta
setblock 473 213 490 minecraft:red_terracotta
setblock 473 213 491 minecraft:terracotta
fill 473 213 492 473 216 492 minecraft:red_terracotta
setblock 474 213 465 minecraft:terracotta
setblock 475 213 464 minecraft:terracotta
setblock 475 213 465 minecraft:red_terracotta
setblock 475 213 504 minecraft:terracotta
fill 476 213 464 476 214 464 minecraft:red_terracotta
fill 476 213 504 476 214 504 minecraft:red_terracotta
setblock 489 213 465 minecraft:terracotta
setblock 490 213 464 minecraft:terracotta
fill 490 213 465 490 216 465 minecraft:red_terracotta
setblock 490 213 504 minecraft:terracotta
fill 491 213 464 491 216 464 minecraft:red_terracotta
setblock 491 213 504 minecraft:red_terracotta
setblock 493 213 466 minecraft:terracotta
setblock 494 213 465 minecraft:terracotta
fill 494 213 466 494 214 466 minecraft:red_terracotta
setblock 495 213 464 minecraft:terracotta
fill 495 213 465 495 216 465 minecraft:red_terracotta
fill 496 213 464 499 213 464 minecraft:red_terracotta
setblock 499 213 465 minecraft:terracotta
setblock 500 213 464 minecraft:terracotta
setblock 500 213 465 minecraft:red_terracotta
fill 501 213 464 501 216 464 minecraft:red_terracotta
setblock 504 213 465 minecraft:terracotta
setblock 505 213 464 minecraft:terracotta
fill 505 213 465 505 216 465 minecraft:red_terracotta
fill 506 213 464 506 216 464 minecraft:red_terracotta
fill 506 213 504 506 216 504 minecraft:red_terracotta
setblock 508 213 466 minecraft:terracotta
setblock 509 213 465 minecraft:terracotta
fill 509 213 466 509 216 466 minecraft:red_terracotta
setblock 509 213 470 minecraft:terracotta
setblock 510 213 464 minecraft:terracotta
fill 510 213 465 510 216 465 minecraft:red_terracotta
setblock 510 213 469 minecraft:terracotta
fill 510 213 470 510 216 470 minecraft:red_terracotta
setblock 510 213 488 minecraft:red_terracotta
setblock 510 213 489 minecraft:terracotta
fill 510 213 490 510 216 490 minecraft:red_terracotta
fill 510 213 492 511 213 492 minecraft:red_terracotta
setblock 510 213 504 minecraft:terracotta
fill 511 213 464 511 216 464 minecraft:red_terracotta
setblock 511 213 468 minecraft:terracotta
fill 511 213 469 511 216 469 minecraft:red_terracotta
setblock 511 213 473 minecraft:terracotta
fill 511 213 474 511 216 474 minecraft:red_terracotta
setblock 511 213 483 minecraft:terracotta
fill 511 213 484 511 215 484 minecraft:red_terracotta
setblock 511 213 488 minecraft:terracotta
fill 511 213 489 511 216 489 minecraft:red_terracotta
setblock 511 213 493 minecraft:terracotta
fill 511 213 494 511 216 494 minecraft:red_terracotta
setblock 511 213 498 minecraft:terracotta
fill 511 213 499 511 216 499 minecraft:red_terracotta
setblock 511 213 503 minecraft:terracotta
fill 511 213 504 511 216 504 minecraft:red_terracotta
setblock 471 214 467 minecraft:terracotta
fill 471 214 468 471 217 468 minecraft:red_terracotta
setblock 471 214 472 minecraft:terracotta
fill 471 214 473 471 217 473 minecraft:red_terracotta
setblock 471 214 482 minecraft:terracotta
fill 471 214 483 471 214 486 minecraft:red_terracotta
setblock 471 214 487 minecraft:terracotta
fill 471 214 488 471 217 488 minecraft:red_terracotta
setblock 471 214 492 minecraft:terracotta
fill 471 214 493 471 217 493 minecraft:red_terracotta
setblock 471 214 497 minecraft:terracotta
fill 471 214 498 471 217 498 minecraft:red_terracotta
setblock 471 214 502 minecraft:terracotta
fill 471 214 503 471 217 503 minecraft:red_terracotta
setblock 472 214 466 minecraft:terracotta
fill 472 214 467 472 216 467 minecraft:red_terracotta
fill 472 214 484 472 214 485 minecraft:red_terracotta
setblock 472 214 486 minecraft:terracotta
fill 472 214 487 472 217 487 minecraft:red_terracotta
setblock 472 214 491 minecraft:terracotta
fill 472 214 492 472 217 492 minecraft:red_terracotta
setblock 472 214 496 minecraft:terracotta
fill 472 214 497 472 217 497 minecraft:red_terracotta
setblock 472 214 501 minecraft:terracotta
setblock 472 214 502 minecraft:red_terracotta
setblock 473 214 465 minecraft:terracotta
setblock 473 214 466 minecraft:light[level=14]
setblock 473 214 474 minecraft:light[level=14]
setblock 473 214 482 minecraft:light[level=14]
setblock 473 214 490 minecraft:terracotta
fill 473 214 491 473 217 491 minecraft:red_terracotta
setblock 473 214 495 minecraft:terracotta
setblock 473 214 498 minecraft:light[level=14]
setblock 474 214 464 minecraft:terracotta
setblock 474 214 465 minecraft:red_terracotta
setblock 474 214 504 minecraft:terracotta
setblock 475 214 464 minecraft:red_terracotta
fill 475 214 504 475 215 504 minecraft:red_terracotta
setblock 481 214 466 minecraft:light[level=14]
setblock 481 214 474 minecraft:light[level=14]
setblock 481 214 482 minecraft:light[level=14]
setblock 481 214 490 minecraft:light[level=14]
setblock 481 214 498 minecraft:light[level=14]
setblock 489 214 464 minecraft:terracotta
fill 489 214 465 489 217 465 minecraft:red_terracotta
setblock 489 214 466 minecraft:light[level=14]
setblock 489 214 474 minecraft:light[level=14]
setblock 489 214 482 minecraft:light[level=14]
setblock 489 214 490 minecraft:light[level=14]
setblock 489 214 498 minecraft:light[level=14]
fill 490 214 464 490 217 464 minecraft:red_terracotta
setblock 492 214 466 minecraft:terracotta
setblock 493 214 465 minecraft:terracotta
fill 493 214 466 493 215 466 minecraft:red_terracotta
setblock 494 214 464 minecraft:terracotta
fill 494 214 465 494 217 465 minecraft:red_terracotta
fill 495 214 464 498 214 464 minecraft:red_terracotta
setblock 497 214 466 minecraft:light[level=14]
setblock 497 214 474 minecraft:light[level=14]
setblock 497 214 482 minecraft:light[level=14]
setblock 497 214 490 minecraft:light[level=14]
setblock 497 214 498 minecraft:light[level=14]
setblock 498 214 465 minecraft:terracotta
setblock 499 214 464 minecraft:terracotta
setblock 499 214 465 minecraft:red_terracotta
fill 500 214 464 500 216 464 minecraft:red_terracotta
setblock 503 214 465 minecraft:terracotta
setblock 504 214 464 minecraft:terracotta
fill 504 214 465 504 217 465 minecraft:red_terracotta
fill 505 214 464 505 217 464 minecraft:red_terracotta
setblock 505 214 466 minecraft:light[level=14]
setblock 505 214 474 minecraft:light[level=14]
setblock 505 214 482 minecraft:light[level=14]
setblock 505 214 490 minecraft:light[level=14]
setblock 507 214 466 minecraft:terracotta
setblock 508 214 465 minecraft:terracotta
fill 508 214 466 508 217 466 minecraft:red_terracotta
setblock 509 214 464 minecraft:terracotta
fill 509 214 465 509 217 465 minecraft:red_terracotta
setblock 509 214 469 minecraft:terracotta
fill 509 214 470 509 217 470 minecraft:red_terracotta
setblock 509 214 504 minecraft:terracotta
fill 510 214 464 510 217 464 minecraft:red_terracotta
setblock 510 214 468 minecraft:terracotta
fill 510 214 469 510 217 469 minecraft:red_terracotta
setblock 510 214 488 minecraft:terracotta
fill 510 214 489 510 217 489 minecraft:red_terracotta
setblock 510 214 492 minecraft:red_terracotta
setblock 510 214 493 minecraft:terracotta
fill 510 214 494 510 217 494 minecraft:red_terracotta
setblock 510 214 503 minecraft:terracotta
fill 510 214 504 510 217 504 minecraft:red_terracotta
setblock 511 214 467 minecraft:terracotta
fill 511 214 468 511 217 468 minecraft:red_terracotta
setblock 511 214 472 minecraft:terracotta
fill 511 214 473 511 217 473 minecraft:red_terracotta
setblock 511 214 487 minecraft:terracotta
fill 511 214 488 511 217 488 minecraft:red_terracotta
setblock 511 214 492 minecraft:terracotta
fill 511 214 493 511 217 493 minecraft:red_terracotta
setblock 511 214 497 minecraft:terracotta
fill 511 214 498 511 217 498 minecraft:red_terracotta
setblock 511 214 502 minecraft:terracotta
fill 511 214 503 511 217 503 minecraft:red_terracotta
setblock 471 215 466 minecraft:terracotta
fill 471 215 467 471 218 467 minecraft:red_terracotta
setblock 471 215 471 minecraft:terracotta
fill 471 215 472 471 218 472 minecraft:red_terracotta
fill 471 215 483 471 215 485 minecraft:red_terracotta
setblock 471 215 486 minecraft:terracotta
fill 471 215 487 471 218 487 minecraft:red_terracotta
setblock 471 215 491 minecraft:terracotta
fill 471 215 492 471 218 492 minecraft:red_terracotta
setblock 471 215 496 minecraft:terracotta
fill 471 215 497 471 218 497 minecraft:red_terracotta
setblock 471 215 501 minecraft:terracotta
fill 471 215 502 471 218 502 minecraft:red_terracotta
setblock 472 215 465 minecraft:terracotta
setblock 472 215 466 minecraft:red_terracotta
setblock 472 215 485 minecraft:terracotta
fill 472 215 486 472 218 486 minecraft:red_terracotta
setblock 472 215 490 minecraft:terracotta
fill 472 215 491 472 218 491 minecraft:red_terracotta
setblock 472 215 495 minecraft:terracotta
fill 472 215 496 472 218 496 minecraft:red_terracotta
setblock 472 215 500 minecraft:terracotta
setblock 473 215 464 minecraft:terracotta
setblock 473 215 489 minecraft:terracotta
fill 473 215 490 473 218 490 minecraft:red_terracotta
setblock 473 215 494 minecraft:terracotta
fill 473 215 495 473 218 495 minecraft:red_terracotta
setblock 473 215 504 minecraft:terracotta
setblock 474 215 464 minecraft:red_terracotta
setblock 474 215 504 minecraft:red_terracotta
setblock 488 215 464 minecraft:terracotta
fill 489 215 464 489 218 464 minecraft:red_terracotta
setblock 491 215 466 minecraft:terracotta
setblock 492 215 465 minecraft:terracotta
setblock 492 215 466 minecraft:red_terracotta
setblock 493 215 464 minecraft:terracotta
fill 493 215 465 493 218 465 minecraft:red_terracotta
fill 494 215 464 497 215 464 minecraft:red_terracotta
setblock 497 215 465 minecraft:terracotta
setblock 498 215 464 minecraft:terracotta
fill 499 215 464 499 216 464 minecraft:red_terracotta
setblock 503 215 464 minecraft:terracotta
fill 504 215 464 504 218 464 minecraft:red_terracotta
setblock 506 215 466 minecraft:terracotta
setblock 507 215 465 minecraft:terracotta
fill 507 215 466 507 218 466 minecraft:red_terracotta
setblock 508 215 464 minecraft:terracotta
fill 508 215 465 508 218 465 minecraft:red_terracotta
setblock 508 215 504 minecraft:terracotta
fill 509 215 464 509 218 464 minecraft:red_terracotta
setblock 509 215 468 minecraft:terracotta
fill 509 215 469 509 218 469 minecraft:red_terracotta
fill 509 215 504 509 218 504 minecraft:red_terracotta
setblock 510 215 467 minecraft:terracotta
fill 510 215 468 510 218 468 minecraft:red_terracotta
setblock 510 215 472 minecraft:terracotta
fill 510 215 473 510 218 473 minecraft:red_terracotta
fill 510 215 488 510 218 488 minecraft:red_terracotta
setblock 510 215 491 minecraft:red_terracotta
setblock 510 215 492 minecraft:terracotta
fill 510 215 493 510 218 493 minecraft:red_terracotta
fill 510 215 495 510 216 495 minecraft:red_terracotta
fill 510 215 503 510 218 503 minecraft:red_terracotta
setblock 511 215 466 minecraft:terracotta
fill 511 215 467 511 218 467 minecraft:red_terracotta
setblock 511 215 471 minecraft:terracotta
fill 511 215 472 511 218 472 minecraft:red_terracotta
setblock 511 215 486 minecraft:terracotta
fill 511 215 487 511 218 487 minecraft:red_terracotta
setblock 511 215 491 minecraft:terracotta
fill 511 215 492 511 218 492 minecraft:red_terracotta
setblock 511 215 496 minecraft:terracotta
fill 511 215 497 511 218 497 minecraft:red_terracotta
setblock 511 215 501 minecraft:terracotta
fill 511 215 502 511 218 502 minecraft:red_terracotta
setblock 471 216 465 minecraft:terracotta
fill 471 216 466 471 219 466 minecraft:red_terracotta
setblock 471 216 470 minecraft:terracotta
fill 471 216 471 471 219 471 minecraft:red_terracotta
setblock 471 216 474 minecraft:red_terracotta
fill 471 216 483 471 216 484 minecraft:red_terracotta
setblock 471 216 485 minecraft:terracotta
fill 471 216 486 471 219 486 minecraft:red_terracotta
setblock 471 216 490 minecraft:terracotta
fill 471 216 491 471 219 491 minecraft:red_terracotta
setblock 471 216 495 minecraft:terracotta
fill 471 216 496 471 219 496 minecraft:red_terracotta
setblock 471 216 500 minecraft:terracotta
fill 471 216 501 471 219 501 minecraft:red_terracotta
setblock 472 216 464 minecraft:terracotta
setblock 472 216 469 minecraft:terracotta
setblock 472 216 485 minecraft:red_terracotta
setblock 472 216 489 minecraft:terracotta
fill 472 216 490 472 219 490 minecraft:red_terracotta
setblock 472 216 494 minecraft:terracotta
fill 472 216 495 472 219 495 minecraft:red_terracotta
setblock 472 216 499 minecraft:terracotta
setblock 472 216 504 minecraft:terracotta
setblock 473 216 464 minecraft:red_terracotta
setblock 473 216 488 minecraft:terracotta
fill 473 216 489 473 219 489 minecraft:red_terracotta
setblock 473 216 493 minecraft:terracotta
fill 473 216 494 473 219 494 minecraft:red_terracotta
fill 473 216 504 473 217 504 minecraft:red_terracotta
setblock 487 216 464 minecraft:terracotta
fill 488 216 464 488 219 464 minecraft:red_terracotta
setblock 491 216 465 minecraft:terracotta
setblock 492 216 464 minecraft:terracotta
fill 492 216 465 492 219 465 minecraft:red_terracotta
fill 493 216 464 496 216 464 minecraft:red_terracotta
setblock 497 216 464 minecraft:terracotta
setblock 498 216 464 minecraft:red_terracotta
setblock 502 216 464 minecraft:terracotta
fill 503 216 464 503 219 464 minecraft:red_terracotta
setblock 506 216 465 minecraft:terracotta
setblock 507 216 464 minecraft:terracotta
fill 507 216 465 507 219 465 minecraft:red_terracotta
setblock 507 216 504 minecraft:terracotta
fill 508 216 464 508 219 464 minecraft:red_terracotta
fill 508 216 504 508 219 504 minecraft:red_terracotta
setblock 509 216 467 minecraft:terracotta
fill 509 216 468 509 219 468 minecraft:red_terracotta
setblock 509 216 471 minecraft:red_terracotta
setblock 510 216 466 minecraft:terracotta
fill 510 216 467 510 219 467 minecraft:red_terracotta
setblock 510 216 471 minecraft:terracotta
fill 510 216 472 510 219 472 minecraft:red_terracotta
setblock 510 216 491 minecraft:terracotta
fill 510 216 492 510 219 492 minecraft:red_terracotta
setblock 510 216 496 minecraft:terracotta
fill 510 216 497 510 219 497 minecraft:red_terracotta
setblock 511 216 465 minecraft:terracotta
fill 511 216 466 511 219 466 minecraft:red_terracotta
setblock 511 216 470 minecraft:terracotta
fill 511 216 471 511 219 471 minecraft:red_terracotta
setblock 511 216 475 minecraft:terracotta
setblock 511 216 485 minecraft:terracotta
fill 511 216 486 511 219 486 minecraft:red_terracotta
setblock 511 216 490 minecraft:terracotta
fill 511 216 491 511 219 491 minecraft:red_terracotta
setblock 511 216 495 minecraft:terracotta
fill 511 216 496 511 219 496 minecraft:red_terracotta
setblock 511 216 500 minecraft:terracotta
fill 511 216 501 511 219 501 minecraft:red_terracotta
setblock 471 217 464 minecraft:terracotta
fill 471 217 465 471 220 465 minecraft:red_terracotta
setblock 471 217 469 minecraft:terracotta
fill 471 217 470 471 220 470 minecraft:red_terracotta
setblock 471 217 474 minecraft:terracotta
fill 471 217 475 471 220 475 minecraft:red_terracotta
setblock 471 217 483 minecraft:red_terracotta
setblock 471 217 484 minecraft:terracotta
fill 471 217 485 471 220 485 minecraft:red_terracotta
setblock 471 217 489 minecraft:terracotta
fill 471 217 490 471 220 490 minecraft:red_terracotta
setblock 471 217 494 minecraft:terracotta
fill 471 217 495 471 220 495 minecraft:red_terracotta
setblock 471 217 499 minecraft:terracotta
fill 471 217 500 471 220 500 minecraft:red_terracotta
setblock 471 217 504 minecraft:terracotta
setblock 472 217 464 minecraft:red_terracotta
setblock 472 217 488 minecraft:terracotta
fill 472 217 489 472 220 489 minecraft:red_terracotta
setblock 472 217 493 minecraft:terracotta
fill 472 217 494 472 220 494 minecraft:red_terracotta
setblock 472 217 498 minecraft:terracotta
fill 472 217 499 472 220 499 minecraft:red_terracotta
fill 472 217 504 472 220 504 minecraft:red_terracotta
setblock 473 217 492 minecraft:terracotta
fill 473 217 493 473 220 493 minecraft:red_terracotta
fill 487 217 464 487 220 464 minecraft:red_terracotta
setblock 490 217 465 minecraft:terracotta
setblock 491 217 464 minecraft:terracotta
fill 491 217 465 491 220 465 minecraft:red_terracotta
fill 492 217 464 495 217 464 minecraft:red_terracotta
setblock 496 217 464 minecraft:terracotta
setblock 497 217 464 minecraft:red_terracotta
setblock 501 217 464 minecraft:terracotta
fill 502 217 464 502 220 464 minecraft:red_terracotta
setblock 505 217 465 minecraft:terracotta
setblock 506 217 464 minecraft:terracotta
fill 506 217 465 506 220 465 minecraft:red_terracotta
setblock 506 217 504 minecraft:terracotta
fill 507 217 464 507 220 464 minecraft:red_terracotta
fill 507 217 504 507 220 504 minecraft:red_terracotta
setblock 509 217 466 minecraft:terracotta
fill 509 217 467 509 220 467 minecraft:red_terracotta
setblock 509 217 471 minecraft:terracotta
fill 509 217 503 509 219 503 minecraft:red_terracotta
setblock 510 217 465 minecraft:terracotta
fill 510 217 466 510 220 466 minecraft:red_terracotta
setblock 510 217 470 minecraft:terracotta
fill 510 217 471 510 220 471 minecraft:red_terracotta
setblock 510 217 490 minecraft:terracotta
fill 510 217 491 510 220 491 minecraft:red_terracotta
setblock 510 217 495 minecraft:terracotta
fill 510 217 496 510 220 496 minecraft:red_terracotta
fill 510 217 498 510 217 499 minecraft:red_terracotta
setblock 510 217 500 minecraft:terracotta
fill 510 217 501 510 219 502 minecraft:red_terracotta
setblock 511 217 464 minecraft:terracotta
fill 511 217 465 511 220 465 minecraft:red_terracotta
setblock 511 217 469 minecraft:terracotta
fill 511 217 470 511 220 470 minecraft:red_terracotta
setblock 511 217 474 minecraft:terracotta
fill 511 217 475 511 220 475 minecraft:red_terracotta
setblock 511 217 489 minecraft:terracotta
fill 511 217 490 511 220 490 minecraft:red_terracotta
setblock 511 217 494 minecraft:terracotta
fill 511 217 495 511 220 495 minecraft:red_terracotta
setblock 511 217 499 minecraft:terracotta
fill 511 217 500 511 220 500 minecraft:red_terracotta
setblock 511 217 504 minecraft:terracotta
fill 471 218 464 471 219 464 minecraft:red_terracotta
setblock 471 218 468 minecraft:terracotta
fill 471 218 469 471 221 469 minecraft:red_terracotta
setblock 471 218 473 minecraft:terracotta
fill 471 218 474 471 221 474 minecraft:red_terracotta
fill 471 218 476 471 219 476 minecraft:red_terracotta
setblock 471 218 483 minecraft:terracotta
fill 471 218 484 471 221 484 minecraft:red_terracotta
setblock 471 218 488 minecraft:terracotta
fill 471 218 489 471 221 489 minecraft:red_terracotta
setblock 471 218 493 minecraft:terracotta
fill 471 218 494 471 221 494 minecraft:red_terracotta
setblock 471 218 498 minecraft:terracotta
fill 471 218 499 471 221 499 minecraft:red_terracotta
setblock 471 218 503 minecraft:terracotta
fill 471 218 504 471 221 504 minecraft:red_terracotta
setblock 472 218 487 minecraft:terracotta
fill 472 218 488 472 221 488 minecraft:red_terracotta
setblock 472 218 492 minecraft:terracotta
fill 472 218 493 472 221 493 minecraft:red_terracotta
setblock 472 218 497 minecraft:terracotta
fill 472 218 498 472 221 498 minecraft:red_terracotta
fill 472 218 500 472 219 500 minecraft:red_terracotta
setblock 473 218 491 minecraft:terracotta
fill 473 218 492 473 221 492 minecraft:red_terracotta
setblock 473 218 496 minecraft:terracotta
setblock 488 218 465 minecraft:red_terracotta
setblock 489 218 465 minecraft:terracotta
setblock 490 218 464 minecraft:terracotta
fill 490 218 465 490 221 465 minecraft:red_terracotta
fill 491 218 464 494 218 464 minecraft:red_terracotta
setblock 495 218 464 minecraft:terracotta
fill 496 218 464 496 219 464 minecraft:red_terracotta
fill 501 218 464 501 221 464 minecraft:red_terracotta
setblock 504 218 465 minecraft:terracotta
setblock 505 218 464 minecraft:terracotta
fill 505 218 465 505 221 465 minecraft:red_terracotta
setblock 505 218 504 minecraft:terracotta
fill 506 218 464 506 221 464 minecraft:red_terracotta
fill 506 218 466 506 219 466 minecraft:red_terracotta
fill 506 218 504 506 221 504 minecraft:red_terracotta
setblock 508 218 466 minecraft:terracotta
fill 508 218 503 508 220 503 minecraft:red_terracotta
setblock 509 218 465 minecraft:terracotta
fill 509 218 466 509 220 466 minecraft:red_terracotta
setblock 509 218 470 minecraft:terracotta
fill 509 218 471 509 220 472 minecraft:red_terracotta
fill 509 218 492 509 218 494 minecraft:red_terracotta
setblock 509 218 495 minecraft:terracotta
fill 509 218 496 509 221 496 minecraft:red_terracotta
setblock 510 218 464 minecraft:terracotta
fill 510 218 465 510 221 465 minecraft:red_terracotta
setblock 510 218 469 minecraft:terracotta
fill 510 218 470 510 221 470 minecraft:red_terracotta
setblock 510 218 474 minecraft:terracotta
setblock 510 218 489 minecraft:terracotta
fill 510 218 490 510 221 490 minecraft:red_terracotta
setblock 510 218 494 minecraft:terracotta
fill 510 218 495 510 221 495 minecraft:red_terracotta
setblock 510 218 498 minecraft:red_terracotta
setblock 510 218 499 minecraft:terracotta
fill 510 218 500 510 221 500 minecraft:red_terracotta
setblock 510 218 504 minecraft:terracotta
fill 511 218 464 511 221 464 minecraft:red_terracotta
setblock 511 218 468 minecraft:terracotta
fill 511 218 469 511 221 469 minecraft:red_terracotta
setblock 511 218 473 minecraft:terracotta
fill 511 218 474 511 221 474 minecraft:red_terracotta
fill 511 218 476 511 219 476 minecraft:red_terracotta
setblock 511 218 488 minecraft:terracotta
fill 511 218 489 511 221 489 minecraft:red_terracotta
setblock 511 218 493 minecraft:terracotta
fill 511 218 494 511 221 494 minecraft:red_terracotta
setblock 511 218 498 minecraft:terracotta
fill 511 218 499 511 221 499 minecraft:red_terracotta
setblock 511 218 503 minecraft:terracotta
fill 511 218 504 511 221 504 minecraft:red_terracotta
setblock 471 219 467 minecraft:terracotta
fill 471 219 468 471 222 468 minecraft:red_terracotta
setblock 471 219 472 minecraft:terracotta
fill 471 219 473 471 222 473 minecraft:red_terracotta
setblock 471 219 477 minecraft:terracotta
fill 471 219 478 471 222 478 minecraft:red_terracotta
fill 471 219 483 471 222 483 minecraft:red_terracotta
setblock 471 219 487 minecraft:terracotta
fill 471 219 488 471 222 488 minecraft:red_terracotta
setblock 471 219 492 minecraft:terracotta
fill 471 219 493 471 222 493 minecraft:red_terracotta
setblock 471 219 497 minecraft:terracotta
fill 471 219 498 471 222 498 minecraft:red_terracotta
setblock 471 219 502 minecraft:terracotta
fill 471 219 503 471 222 503 minecraft:red_terracotta
setblock 472 219 486 minecraft:terracotta
fill 472 219 487 472 222 487 minecraft:red_terracotta
setblock 472 219 491 minecraft:terracotta
fill 472 219 492 472 222 492 minecraft:red_terracotta
setblock 472 219 496 minecraft:terracotta
fill 472 219 497 472 222 497 minecraft:red_terracotta
setblock 473 219 490 minecraft:terracotta
fill 473 219 491 473 222 491 minecraft:red_terracotta
setblock 473 219 495 minecraft:terracotta
fill 473 219 496 473 222 496 minecraft:red_terracotta
fill 486 219 464 486 221 464 minecraft:red_terracotta
setblock 488 219 465 minecraft:terracotta
setblock 489 219 464 minecraft:terracotta
fill 489 219 465 489 222 465 minecraft:red_terracotta
fill 490 219 464 493 219 464 minecraft:red_terracotta
setblock 493 219 465 minecraft:terracotta
setblock 494 219 464 minecraft:terracotta
fill 495 219 464 495 222 464 minecraft:red_terracotta
fill 500 219 464 500 222 464 minecraft:red_terracotta
fill 501 219 497 502 219 499 minecraft:orange_concrete
fill 502 219 496 504 219 496 minecraft:orange_concrete
fill 502 219 500 503 219 501 minecraft:orange_concrete
setblock 503 219 465 minecraft:terracotta
fill 503 219 495 508 219 495 minecraft:orange_concrete
fill 503 219 497 503 221 497 minecraft:orange_concrete
fill 503 219 499 503 221 499 minecraft:orange_concrete
fill 503 219 502 507 219 502 minecraft:orange_concrete
setblock 504 219 464 minecraft:terracotta
fill 504 219 465 504 222 465 minecraft:red_terracotta
fill 504 219 494 506 219 494 minecraft:orange_concrete
fill 504 219 501 508 219 501 minecraft:orange_concrete
setblock 504 219 504 minecraft:terracotta
fill 505 219 464 505 222 464 minecraft:red_terracotta
fill 505 219 504 505 222 504 minecraft:red_terracotta
fill 506 219 496 508 220 496 minecraft:orange_concrete
setblock 507 219 466 minecraft:terracotta
fill 507 219 500 509 219 500 minecraft:orange_concrete
fill 507 219 503 507 221 503 minecraft:red_terracotta
setblock 508 219 465 minecraft:terracotta
fill 508 219 466 508 221 466 minecraft:red_terracotta
fill 508 219 497 508 220 499 minecraft:orange_concrete
setblock 509 219 464 minecraft:terracotta
fill 509 219 465 509 222 465 minecraft:red_terracotta
setblock 509 219 469 minecraft:terracotta
fill 509 219 470 509 222 470 minecraft:red_terracotta
setblock 509 219 473 minecraft:red_terracotta
fill 509 219 491 509 219 493 minecraft:red_terracotta
setblock 509 219 494 minecraft:terracotta
fill 509 219 495 509 222 495 minecraft:red_terracotta
fill 509 219 497 509 219 498 minecraft:red_terracotta
setblock 509 219 499 minecraft:orange_concrete
setblock 509 219 504 minecraft:terracotta
fill 510 219 464 510 222 464 minecraft:red_terracotta
setblock 510 219 468 minecraft:terracotta
fill 510 219 469 510 222 469 minecraft:red_terracotta
setblock 510 219 473 minecraft:terracotta
fill 510 219 474 510 221 475 minecraft:red_terracotta
setblock 510 219 488 minecraft:terracotta
fill 510 219 489 510 222 489 minecraft:red_terracotta
setblock 510 219 493 minecraft:terracotta
fill 510 219 494 510 222 494 minecraft:red_terracotta
setblock 510 219 498 minecraft:terracotta
fill 510 219 499 510 222 499 minecraft:red_terracotta
setblock 510 219 503 minecraft:terracotta
fill 510 219 504 510 222 504 minecraft:red_terracotta
setblock 511 219 467 minecraft:terracotta
fill 511 219 468 511 222 468 minecraft:red_terracotta
setblock 511 219 472 minecraft:terracotta
fill 511 219 473 511 222 473 minecraft:red_terracotta
setblock 511 219 477 minecraft:terracotta
setblock 511 219 487 minecraft:terracotta
fill 511 219 488 511 222 488 minecraft:red_terracotta
setblock 511 219 492 minecraft:terracotta
fill 511 219 493 511 222 493 minecraft:red_terracotta
setblock 511 219 497 minecraft:terracotta
fill 511 219 498 511 222 498 minecraft:red_terracotta
setblock 511 219 502 minecraft:terracotta
fill 511 219 503 511 222 503 minecraft:red_terracotta
setblock 471 220 466 minecraft:terracotta
fill 471 220 467 471 222 467 minecraft:red_terracotta
setblock 471 220 471 minecraft:terracotta
fill 471 220 472 472 222 472 minecraft:red_terracotta
setblock 471 220 476 minecraft:terracotta
fill 471 220 477 471 222 477 minecraft:red_terracotta
fill 471 220 479 471 220 480 minecraft:red_terracotta
setblock 471 220 481 minecraft:terracotta
fill 471 220 482 471 222 482 minecraft:red_terracotta
setblock 471 220 486 minecraft:terracotta
fill 471 220 487 471 222 487 minecraft:red_terracotta
setblock 471 220 491 minecraft:terracotta
fill 471 220 492 471 222 492 minecraft:red_terracotta
setblock 471 220 496 minecraft:terracotta
fill 471 220 497 471 222 497 minecraft:red_terracotta
setblock 471 220 501 minecraft:terracotta
fill 471 220 502 471 222 502 minecraft:red_terracotta
setblock 472 220 471 minecraft:red_terracotta
fill 472 220 473 472 221 473 minecraft:red_terracotta
setblock 472 220 486 minecraft:red_terracotta
setblock 472 220 490 minecraft:terracotta
fill 472 220 491 472 222 491 minecraft:red_terracotta
setblock 472 220 495 minecraft:terracotta
fill 472 220 496 472 222 496 minecraft:red_terracotta
setblock 472 220 500 minecraft:terracotta
fill 473 220 490 473 221 490 minecraft:red_terracotta
setblock 473 220 494 minecraft:terracotta
fill 473 220 495 473 222 495 minecraft:red_terracotta
fill 473 220 497 473 221 497 minecraft:red_terracotta
fill 476 220 483 476 221 485 minecraft:magma_block
fill 477 220 484 477 221 484 minecraft:magma_block
fill 485 220 464 485 222 464 minecraft:red_terracotta
setblock 487 220 465 minecraft:terracotta
setblock 488 220 464 minecraft:terracotta
fill 488 220 465 488 222 465 minecraft:red_terracotta
fill 489 220 464 492 220 464 minecraft:red_terracotta
setblock 492 220 465 minecraft:terracotta
setblock 493 220 464 minecraft:terracotta
fill 494 220 464 494 222 464 minecraft:red_terracotta
fill 499 220 464 499 222 464 minecraft:red_terracotta
fill 502 220 497 502 220 500 minecraft:orange_concrete
setblock 503 220 464 minecraft:terracotta
fill 503 220 465 503 222 465 minecraft:red_terracotta
fill 503 220 496 504 220 496 minecraft:orange_concrete
fill 503 220 500 503 220 501 minecraft:orange_concrete
setblock 503 220 504 minecraft:terracotta
fill 504 220 464 504 222 464 minecraft:red_terracotta
fill 504 220 495 507 220 495 minecraft:orange_concrete
fill 504 220 501 507 220 501 minecraft:orange_concrete
fill 504 220 504 504 222 504 minecraft:red_terracotta
setblock 505 220 466 minecraft:red_terracotta
fill 505 220 503 506 222 503 minecraft:red_terracotta
setblock 506 220 466 minecraft:terracotta
setblock 507 220 465 minecraft:terracotta
fill 507 220 466 507 222 466 minecraft:red_terracotta
fill 507 220 500 508 220 500 minecraft:orange_concrete
setblock 508 220 464 minecraft:terracotta
fill 508 220 465 508 222 465 minecraft:red_terracotta
setblock 508 220 504 minecraft:terracotta
fill 509 220 464 509 222 464 minecraft:red_terracotta
setblock 509 220 468 minecraft:terracotta
fill 509 220 469 509 222 469 minecraft:red_terracotta
setblock 509 220 473 minecraft:terracotta
fill 509 220 491 509 220 492 minecraft:red_terracotta
setblock 509 220 493 minecraft:terracotta
fill 509 220 494 509 222 494 minecraft:red_terracotta
setblock 509 220 497 minecraft:red_terracotta
setblock 509 220 498 minecraft:terracotta
fill 509 220 499 509 221 501 minecraft:red_terracotta
setblock 509 220 503 minecraft:terracotta
fill 509 220 504 509 222 504 minecraft:red_terracotta
setblock 510 220 467 minecraft:terracotta
fill 510 220 468 510 222 468 minecraft:red_terracotta
setblock 510 220 472 minecraft:terracotta
fill 510 220 473 510 222 473 minecraft:red_terracotta
setblock 510 220 476 minecraft:red_terracotta
fill 510 220 488 510 222 488 minecraft:red_terracotta
setblock 510 220 492 minecraft:terracotta
fill 510 220 493 510 222 493 minecraft:red_terracotta
setblock 510 220 497 minecraft:terracotta
fill 510 220 498 510 222 498 minecraft:red_terracotta
setblock 510 220 501 minecraft:red_terracotta
setblock 510 220 502 minecraft:terracotta
fill 510 220 503 510 222 503 minecraft:red_terracotta
setblock 511 220 466 minecraft:terracotta
fill 511 220 467 511 222 467 minecraft:red_terracotta
setblock 511 220 471 minecraft:terracotta
fill 511 220 472 511 222 472 minecraft:red_terracotta
setblock 511 220 476 minecraft:terracotta
fill 511 220 477 511 222 478 minecraft:red_terracotta
setblock 511 220 486 minecraft:terracotta
fill 511 220 487 511 222 487 minecraft:red_terracotta
setblock 511 220 491 minecraft:terracotta
fill 511 220 492 511 222 492 minecraft:red_terracotta
setblock 511 220 496 minecraft:terracotta
fill 511 220 497 511 222 497 minecraft:red_terracotta
setblock 511 220 501 minecraft:terracotta
fill 511 220 502 511 222 502 minecraft:red_terracotta
setblock 471 221 466 minecraft:red_terracotta
setblock 471 221 470 minecraft:terracotta
fill 471 221 471 471 222 471 minecraft:red_terracotta
setblock 471 221 475 minecraft:terracotta
fill 471 221 476 471 222 476 minecraft:red_terracotta
setblock 471 221 479 minecraft:red_terracotta
setblock 471 221 480 minecraft:terracotta
fill 471 221 481 471 222 481 minecraft:red_terracotta
setblock 471 221 485 minecraft:terracotta
fill 471 221 486 471 222 486 minecraft:red_terracotta
setblock 471 221 490 minecraft:terracotta
fill 471 221 491 471 222 491 minecraft:red_terracotta
setblock 471 221 495 minecraft:terracotta
fill 471 221 496 471 222 496 minecraft:red_terracotta
setblock 471 221 500 minecraft:terracotta
fill 471 221 501 472 222 501 minecraft:red_terracotta
setblock 472 221 474 minecraft:terracotta
fill 472 221 475 472 222 475 minecraft:red_terracotta
setblock 472 221 489 minecraft:terracotta
fill 472 221 490 472 222 490 minecraft:red_terracotta
setblock 472 221 494 minecraft:terracotta
fill 472 221 495 472 222 495 minecraft:red_terracotta
setblock 472 221 499 minecraft:terracotta
fill 472 221 500 472 222 500 minecraft:red_terracotta
setblock 472 221 504 minecraft:terracotta
setblock 473 221 493 minecraft:terracotta
fill 473 221 494 473 222 494 minecraft:red_terracotta
setblock 486 221 465 minecraft:terracotta
setblock 487 221 464 minecraft:terracotta
fill 487 221 465 487 222 465 minecraft:red_terracotta
fill 488 221 464 491 221 464 minecraft:red_terracotta
setblock 491 221 465 minecraft:terracotta
setblock 492 221 464 minecraft:terracotta
setblock 492 221 465 minecraft:red_terracotta
fill 493 221 464 493 222 464 minecraft:red_terracotta
setblock 496 221 464 minecraft:red_terracotta
fill 498 221 464 498 222 464 minecraft:red_terracotta
setblock 502 221 464 minecraft:terracotta
fill 502 221 465 502 222 465 minecraft:red_terracotta
setblock 502 221 504 minecraft:terracotta
fill 503 221 464 503 222 464 minecraft:red_terracotta
setblock 503 221 500 minecraft:orange_concrete
fill 503 221 504 503 222 504 minecraft:red_terracotta
setblock 504 221 496 minecraft:orange_concrete
fill 504 221 503 504 222 503 minecraft:red_terracotta
setblock 505 221 466 minecraft:terracotta
fill 505 221 501 506 221 501 minecraft:orange_concrete
setblock 506 221 465 minecraft:terracotta
fill 506 221 466 506 222 466 minecraft:red_terracotta
fill 506 221 496 507 221 496 minecraft:orange_concrete
setblock 507 221 464 minecraft:terracotta
fill 507 221 465 507 222 465 minecraft:red_terracotta
setblock 507 221 500 minecraft:orange_concrete
fill 507 221 502 508 221 502 minecraft:red_terracotta
setblock 507 221 504 minecraft:terracotta
fill 508 221 464 508 222 464 minecraft:red_terracotta
setblock 508 221 493 minecraft:terracotta
fill 508 221 494 508 221 497 minecraft:red_terracotta
setblock 508 221 498 minecraft:terracotta
setblock 508 221 499 minecraft:orange_concrete
setblock 508 221 503 minecraft:terracotta
fill 508 221 504 508 222 504 minecraft:red_terracotta
setblock 509 221 467 minecraft:terracotta
fill 509 221 468 509 222 468 minecraft:red_terracotta
setblock 509 221 471 minecraft:red_terracotta
schedule function dropper:buildpart/118_8 1t
