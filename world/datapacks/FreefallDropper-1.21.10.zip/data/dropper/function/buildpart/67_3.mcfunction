setblock 339 293 285 minecraft:light[level=12]
setblock 339 293 292 minecraft:light[level=12]
setblock 339 293 306 minecraft:light[level=12]
setblock 339 293 313 minecraft:light[level=12]
fill 339 293 317 339 308 317 minecraft:light_blue_concrete
setblock 340 293 299 minecraft:dirt
setblock 340 293 304 minecraft:dirt
setblock 340 293 317 minecraft:white_wool
fill 341 293 301 341 293 303 minecraft:dirt
setblock 346 293 278 minecraft:light[level=12]
setblock 346 293 285 minecraft:light[level=12]
setblock 346 293 292 minecraft:light[level=12]
setblock 346 293 299 minecraft:light[level=12]
setblock 346 293 306 minecraft:light[level=12]
setblock 346 293 313 minecraft:light[level=12]
setblock 353 293 278 minecraft:light[level=12]
setblock 353 293 285 minecraft:light[level=12]
setblock 353 293 292 minecraft:light[level=12]
setblock 353 293 299 minecraft:light[level=12]
setblock 353 293 306 minecraft:light[level=12]
setblock 353 293 313 minecraft:light[level=12]
fill 356 293 306 359 295 306 minecraft:packed_mud
fill 357 293 305 358 296 305 minecraft:packed_mud
fill 357 293 307 357 296 307 minecraft:packed_mud
fill 358 293 304 358 295 304 minecraft:packed_mud
fill 359 293 307 359 295 307 minecraft:packed_mud
setblock 360 293 278 minecraft:light[level=12]
setblock 360 293 285 minecraft:light[level=12]
setblock 360 293 292 minecraft:light[level=12]
setblock 360 293 299 minecraft:light[level=12]
setblock 360 293 306 minecraft:light[level=12]
setblock 360 293 313 minecraft:light[level=12]
setblock 367 293 278 minecraft:light[level=12]
setblock 367 293 285 minecraft:light[level=12]
setblock 367 293 292 minecraft:light[level=12]
setblock 367 293 299 minecraft:light[level=12]
setblock 367 293 306 minecraft:light[level=12]
setblock 367 293 313 minecraft:light[level=12]
fill 371 293 302 371 308 302 minecraft:light_blue_concrete
setblock 371 293 303 minecraft:white_wool
fill 371 293 312 371 308 312 minecraft:light_blue_concrete
setblock 371 293 313 minecraft:white_wool
fill 371 293 314 371 308 314 minecraft:light_blue_concrete
fill 329 294 294 329 308 294 minecraft:light_blue_concrete
fill 338 294 302 338 296 302 minecraft:white_concrete
fill 340 294 317 340 308 317 minecraft:light_blue_concrete
fill 356 294 305 356 295 305 minecraft:packed_mud
fill 357 294 304 357 295 304 minecraft:packed_mud
fill 358 294 307 358 296 307 minecraft:packed_mud
fill 359 294 304 359 295 305 minecraft:packed_mud
setblock 371 294 276 minecraft:white_wool
fill 371 294 303 371 308 303 minecraft:light_blue_concrete
fill 371 294 313 371 299 313 minecraft:light_blue_concrete
fill 353 295 306 354 297 308 minecraft:packed_mud
fill 355 295 306 355 298 307 minecraft:packed_mud
setblock 358 295 308 minecraft:packed_mud
setblock 360 295 305 minecraft:packed_mud
fill 371 295 276 371 303 276 minecraft:light_blue_concrete
fill 335 296 292 335 297 293 minecraft:white_concrete
setblock 341 296 275 minecraft:white_wool
fill 352 296 306 352 297 308 minecraft:packed_mud
fill 354 296 305 355 296 305 minecraft:packed_mud
fill 355 296 308 355 298 308 minecraft:packed_mud
fill 356 296 305 356 297 307 minecraft:moss_block
fill 357 296 304 359 297 304 minecraft:moss_block
fill 357 296 306 359 296 306 minecraft:packed_mud
fill 358 296 308 358 297 308 minecraft:moss_block
setblock 359 296 305 minecraft:packed_mud
fill 359 296 307 359 297 307 minecraft:moss_block
fill 360 296 305 360 296 306 minecraft:moss_block
setblock 367 296 317 minecraft:white_wool
setblock 371 296 293 minecraft:white_wool
setblock 329 297 300 minecraft:white_wool
setblock 332 297 278 minecraft:light[level=15]
setblock 332 297 286 minecraft:light[level=15]
setblock 332 297 294 minecraft:light[level=15]
setblock 332 297 302 minecraft:light[level=15]
setblock 332 297 310 minecraft:light[level=15]
fill 336 297 301 339 299 302 minecraft:oak_leaves[persistent=true]
fill 337 297 300 338 299 300 minecraft:oak_leaves[persistent=true]
fill 337 297 303 339 299 303 minecraft:oak_leaves[persistent=true]
setblock 340 297 278 minecraft:light[level=15]
setblock 340 297 286 minecraft:light[level=15]
setblock 340 297 294 minecraft:light[level=15]
setblock 340 297 302 minecraft:light[level=15]
setblock 340 297 310 minecraft:light[level=15]
fill 341 297 275 341 308 275 minecraft:light_blue_concrete
setblock 348 297 278 minecraft:light[level=15]
setblock 348 297 286 minecraft:light[level=15]
setblock 348 297 294 minecraft:light[level=15]
setblock 348 297 302 minecraft:light[level=15]
setblock 348 297 310 minecraft:light[level=15]
setblock 348 297 317 minecraft:white_wool
fill 349 297 317 350 308 317 minecraft:light_blue_concrete
setblock 354 297 305 minecraft:packed_mud
setblock 356 297 278 minecraft:light[level=15]
setblock 356 297 286 minecraft:light[level=15]
setblock 356 297 294 minecraft:light[level=15]
setblock 356 297 302 minecraft:light[level=15]
setblock 356 297 310 minecraft:light[level=15]
fill 357 297 305 357 297 308 minecraft:moss_block
fill 358 297 305 358 297 307 minecraft:moss_block
fill 359 297 305 359 297 306 minecraft:moss_block
setblock 364 297 278 minecraft:light[level=15]
setblock 364 297 286 minecraft:light[level=15]
setblock 364 297 294 minecraft:light[level=15]
setblock 364 297 302 minecraft:light[level=15]
setblock 364 297 310 minecraft:light[level=15]
fill 367 297 317 367 308 317 minecraft:light_blue_concrete
fill 371 297 293 371 308 293 minecraft:light_blue_concrete
fill 329 298 300 329 308 300 minecraft:light_blue_concrete
setblock 336 298 300 minecraft:oak_leaves[persistent=true]
setblock 336 298 303 minecraft:oak_leaves[persistent=true]
setblock 338 298 304 minecraft:oak_leaves[persistent=true]
setblock 339 298 300 minecraft:oak_leaves[persistent=true]
fill 340 298 301 340 298 302 minecraft:oak_leaves[persistent=true]
fill 344 298 287 346 299 287 minecraft:white_wool
fill 345 298 286 345 299 286 minecraft:white_wool
fill 345 298 288 345 299 288 minecraft:white_wool
fill 348 298 317 348 308 317 minecraft:light_blue_concrete
fill 352 298 306 352 299 306 minecraft:moss_block
fill 352 298 307 354 298 307 minecraft:packed_mud
fill 352 298 308 353 299 308 minecraft:moss_block
fill 353 298 305 355 299 305 minecraft:moss_block
fill 353 298 306 354 298 306 minecraft:packed_mud
fill 353 298 309 354 299 309 minecraft:moss_block
setblock 354 298 308 minecraft:packed_mud
fill 356 298 306 356 298 307 minecraft:moss_block
fill 364 298 275 365 308 275 minecraft:light_blue_concrete
setblock 366 298 275 minecraft:white_wool
setblock 371 298 292 minecraft:white_wool
setblock 332 299 278 minecraft:light[level=12]
setblock 332 299 285 minecraft:light[level=12]
fill 332 299 291 336 299 293 minecraft:white_wool
setblock 332 299 299 minecraft:light[level=12]
setblock 332 299 306 minecraft:light[level=12]
setblock 332 299 313 minecraft:light[level=12]
fill 333 299 290 335 299 290 minecraft:white_wool
fill 333 299 294 335 299 294 minecraft:white_wool
setblock 339 299 278 minecraft:light[level=12]
setblock 339 299 285 minecraft:light[level=12]
setblock 339 299 292 minecraft:light[level=12]
setblock 339 299 299 minecraft:light[level=12]
setblock 339 299 306 minecraft:light[level=12]
setblock 339 299 313 minecraft:light[level=12]
setblock 346 299 278 minecraft:light[level=12]
setblock 346 299 285 minecraft:light[level=12]
setblock 346 299 292 minecraft:light[level=12]
setblock 346 299 299 minecraft:light[level=12]
setblock 346 299 306 minecraft:light[level=12]
setblock 346 299 313 minecraft:light[level=12]
fill 352 299 307 356 299 307 minecraft:moss_block
setblock 353 299 278 minecraft:light[level=12]
setblock 353 299 285 minecraft:light[level=12]
setblock 353 299 292 minecraft:light[level=12]
setblock 353 299 299 minecraft:light[level=12]
fill 353 299 306 355 299 306 minecraft:moss_block
setblock 353 299 313 minecraft:light[level=12]
fill 354 299 308 356 299 308 minecraft:moss_block
setblock 355 299 309 minecraft:moss_block
setblock 360 299 278 minecraft:light[level=12]
setblock 360 299 285 minecraft:light[level=12]
setblock 360 299 292 minecraft:light[level=12]
setblock 360 299 299 minecraft:light[level=12]
setblock 360 299 306 minecraft:light[level=12]
setblock 360 299 313 minecraft:light[level=12]
fill 366 299 275 366 308 275 minecraft:light_blue_concrete
setblock 367 299 278 minecraft:light[level=12]
setblock 367 299 285 minecraft:light[level=12]
setblock 367 299 292 minecraft:light[level=12]
setblock 367 299 299 minecraft:light[level=12]
setblock 367 299 306 minecraft:light[level=12]
setblock 367 299 313 minecraft:light[level=12]
fill 371 299 292 371 308 292 minecraft:light_blue_concrete
fill 332 300 292 336 300 292 minecraft:white_wool
fill 333 300 291 336 300 291 minecraft:white_wool
fill 333 300 293 336 300 293 minecraft:white_wool
fill 334 300 290 335 300 290 minecraft:white_wool
fill 334 300 294 336 300 294 minecraft:white_wool
setblock 335 300 295 minecraft:white_wool
setblock 342 300 275 minecraft:white_wool
fill 343 300 275 343 308 275 minecraft:light_blue_concrete
setblock 370 300 275 minecraft:white_wool
setblock 371 300 313 minecraft:white_wool
fill 334 301 292 335 301 292 minecraft:white_wool
fill 342 301 275 342 308 275 minecraft:light_blue_concrete
fill 370 301 275 370 308 275 minecraft:light_blue_concrete
fill 371 301 313 371 308 313 minecraft:light_blue_concrete
setblock 329 303 295 minecraft:white_wool
fill 329 303 296 329 308 296 minecraft:light_blue_concrete
setblock 329 303 314 minecraft:white_wool
setblock 354 303 275 minecraft:white_wool
setblock 371 303 291 minecraft:white_wool
fill 329 304 295 329 308 295 minecraft:light_blue_concrete
setblock 329 304 311 minecraft:white_wool
fill 329 304 314 329 308 314 minecraft:light_blue_concrete
fill 354 304 275 354 308 275 minecraft:light_blue_concrete
setblock 371 304 276 minecraft:white_wool
fill 371 304 291 371 308 291 minecraft:light_blue_concrete
fill 329 305 311 329 308 311 minecraft:light_blue_concrete
fill 371 305 276 371 308 276 minecraft:light_blue_concrete
setblock 345 306 317 minecraft:white_wool
fill 345 307 317 345 308 317 minecraft:light_blue_concrete
