fill 160 140 276 163 140 276 minecraft:packed_ice
setblock 160 140 315 minecraft:snow_block
fill 160 140 316 163 140 316 minecraft:packed_ice
setblock 164 140 276 minecraft:snow_block
setblock 164 140 316 minecraft:snow_block
fill 165 140 276 165 143 276 minecraft:packed_ice
fill 165 140 316 165 143 316 minecraft:packed_ice
fill 167 140 315 167 142 315 minecraft:packed_ice
setblock 169 140 276 minecraft:snow_block
setblock 169 140 316 minecraft:snow_block
fill 170 140 276 170 143 276 minecraft:packed_ice
setblock 170 140 315 minecraft:snow_block
fill 170 140 316 170 143 316 minecraft:packed_ice
fill 171 140 277 172 140 277 minecraft:packed_ice
setblock 171 140 314 minecraft:snow_block
fill 171 140 315 171 143 315 minecraft:packed_ice
fill 172 140 314 172 143 314 minecraft:packed_ice
setblock 173 140 277 minecraft:snow_block
setblock 174 140 276 minecraft:snow_block
fill 174 140 277 174 143 277 minecraft:packed_ice
setblock 174 140 316 minecraft:snow_block
fill 175 140 276 175 143 276 minecraft:packed_ice
setblock 175 140 315 minecraft:snow_block
fill 175 140 316 175 143 316 minecraft:packed_ice
fill 176 140 313 176 140 314 minecraft:snow_block
fill 176 140 315 176 143 315 minecraft:packed_ice
fill 177 140 313 177 200 313 minecraft:snow_block
fill 177 140 314 177 143 314 minecraft:packed_ice
setblock 179 140 276 minecraft:snow_block
setblock 179 140 316 minecraft:snow_block
fill 180 140 276 180 143 276 minecraft:packed_ice
setblock 180 140 315 minecraft:snow_block
fill 180 140 316 180 143 316 minecraft:packed_ice
setblock 181 140 294 minecraft:snow_block
fill 181 140 295 181 143 295 minecraft:packed_ice
setblock 181 140 298 minecraft:packed_ice
setblock 181 140 314 minecraft:snow_block
setblock 181 140 315 minecraft:packed_ice
setblock 182 140 293 minecraft:snow_block
fill 182 140 294 182 143 294 minecraft:packed_ice
setblock 182 140 298 minecraft:snow_block
fill 182 140 299 182 143 299 minecraft:packed_ice
setblock 182 140 313 minecraft:snow_block
fill 182 140 314 182 143 314 minecraft:packed_ice
fill 142 141 290 142 141 291 minecraft:packed_ice
setblock 142 141 292 minecraft:snow_block
fill 142 141 293 142 144 293 minecraft:packed_ice
setblock 142 141 297 minecraft:snow_block
fill 142 141 298 142 144 298 minecraft:packed_ice
setblock 142 141 301 minecraft:packed_ice
setblock 143 141 296 minecraft:snow_block
fill 143 141 297 143 144 297 minecraft:packed_ice
setblock 148 141 276 minecraft:snow_block
fill 149 141 276 149 144 276 minecraft:packed_ice
fill 149 141 316 149 144 316 minecraft:packed_ice
fill 150 141 277 150 142 277 minecraft:packed_ice
setblock 152 141 277 minecraft:snow_block
fill 152 141 315 152 142 315 minecraft:packed_ice
setblock 153 141 276 minecraft:snow_block
fill 153 141 277 153 143 278 minecraft:packed_ice
setblock 153 141 316 minecraft:snow_block
fill 154 141 276 154 144 276 minecraft:packed_ice
setblock 154 141 315 minecraft:snow_block
fill 154 141 316 154 144 316 minecraft:packed_ice
setblock 155 141 278 minecraft:packed_ice
setblock 155 141 280 minecraft:packed_ice
fill 155 141 315 155 144 315 minecraft:packed_ice
setblock 156 141 278 minecraft:snow_block
setblock 157 141 277 minecraft:snow_block
fill 157 141 278 158 143 278 minecraft:packed_ice
setblock 157 141 282 minecraft:packed_ice
setblock 158 141 276 minecraft:snow_block
fill 158 141 277 158 144 277 minecraft:packed_ice
setblock 158 141 316 minecraft:snow_block
fill 159 141 276 162 141 276 minecraft:packed_ice
setblock 159 141 280 minecraft:packed_ice
setblock 159 141 315 minecraft:snow_block
fill 159 141 316 162 141 316 minecraft:packed_ice
fill 160 141 315 160 144 315 minecraft:packed_ice
setblock 162 141 277 minecraft:snow_block
setblock 163 141 276 minecraft:snow_block
setblock 163 141 316 minecraft:snow_block
fill 164 141 276 164 144 276 minecraft:packed_ice
fill 164 141 316 164 144 316 minecraft:packed_ice
fill 166 141 315 166 143 315 minecraft:packed_ice
setblock 168 141 276 minecraft:snow_block
setblock 168 141 316 minecraft:snow_block
fill 169 141 276 169 143 277 minecraft:packed_ice
setblock 169 141 315 minecraft:snow_block
fill 169 141 316 169 144 316 minecraft:packed_ice
fill 170 141 277 171 141 277 minecraft:packed_ice
setblock 170 141 314 minecraft:snow_block
fill 170 141 315 170 144 315 minecraft:packed_ice
fill 171 141 314 171 144 314 minecraft:packed_ice
setblock 172 141 277 minecraft:snow_block
setblock 173 141 276 minecraft:snow_block
fill 173 141 277 173 144 277 minecraft:packed_ice
setblock 173 141 316 minecraft:snow_block
fill 174 141 276 174 144 276 minecraft:packed_ice
setblock 174 141 315 minecraft:snow_block
fill 174 141 316 174 144 316 minecraft:packed_ice
setblock 175 141 314 minecraft:snow_block
fill 175 141 315 175 144 315 minecraft:packed_ice
fill 176 141 313 176 200 313 minecraft:snow_block
fill 176 141 314 176 144 314 minecraft:packed_ice
setblock 177 141 277 minecraft:snow_block
fill 177 141 278 177 142 278 minecraft:packed_ice
fill 177 141 303 177 142 303 minecraft:packed_ice
setblock 178 141 276 minecraft:snow_block
fill 178 141 280 178 142 280 minecraft:packed_ice
setblock 178 141 316 minecraft:snow_block
fill 179 141 276 179 144 276 minecraft:packed_ice
fill 179 141 311 179 142 311 minecraft:packed_ice
setblock 179 141 315 minecraft:snow_block
fill 179 141 316 179 144 316 minecraft:packed_ice
fill 180 141 315 180 142 315 minecraft:packed_ice
setblock 181 141 298 minecraft:snow_block
fill 181 141 299 181 144 299 minecraft:packed_ice
setblock 182 141 292 minecraft:snow_block
fill 182 141 293 182 144 293 minecraft:packed_ice
setblock 182 141 297 minecraft:snow_block
fill 182 141 298 182 144 298 minecraft:packed_ice
setblock 182 141 302 minecraft:snow_block
setblock 182 141 312 minecraft:snow_block
fill 182 141 313 182 142 313 minecraft:packed_ice
setblock 183 141 314 minecraft:white_concrete
setblock 142 142 290 minecraft:packed_ice
setblock 142 142 291 minecraft:snow_block
fill 142 142 292 142 145 292 minecraft:packed_ice
setblock 142 142 296 minecraft:snow_block
fill 142 142 297 142 145 297 minecraft:packed_ice
setblock 142 142 301 minecraft:snow_block
setblock 143 142 295 minecraft:snow_block
fill 143 142 296 143 145 296 minecraft:packed_ice
fill 143 142 298 143 143 298 minecraft:packed_ice
setblock 146 142 276 minecraft:packed_ice
setblock 147 142 276 minecraft:snow_block
fill 148 142 276 148 145 276 minecraft:packed_ice
fill 148 142 316 148 145 316 minecraft:packed_ice
fill 149 142 277 149 143 277 minecraft:packed_ice
setblock 151 142 277 minecraft:snow_block
fill 151 142 278 152 144 278 minecraft:packed_ice
setblock 152 142 276 minecraft:snow_block
fill 152 142 277 152 145 277 minecraft:packed_ice
setblock 152 142 316 minecraft:snow_block
fill 153 142 276 153 145 276 minecraft:packed_ice
setblock 153 142 315 minecraft:snow_block
fill 153 142 316 153 145 316 minecraft:packed_ice
fill 154 142 315 154 145 315 minecraft:packed_ice
setblock 155 142 278 minecraft:snow_block
setblock 156 142 277 minecraft:snow_block
fill 156 142 278 156 145 278 minecraft:packed_ice
setblock 157 142 276 minecraft:snow_block
fill 157 142 277 157 145 277 minecraft:packed_ice
setblock 157 142 316 minecraft:snow_block
fill 158 142 276 161 142 276 minecraft:packed_ice
setblock 158 142 315 minecraft:snow_block
fill 158 142 316 161 142 316 minecraft:packed_ice
setblock 159 142 278 minecraft:packed_ice
fill 159 142 315 159 145 315 minecraft:packed_ice
setblock 161 142 277 minecraft:snow_block
setblock 162 142 276 minecraft:snow_block
fill 162 142 277 165 142 277 minecraft:packed_ice
setblock 162 142 316 minecraft:snow_block
fill 163 142 276 163 145 276 minecraft:packed_ice
fill 163 142 316 163 145 316 minecraft:packed_ice
setblock 166 142 277 minecraft:snow_block
setblock 167 142 276 minecraft:snow_block
fill 167 142 277 168 144 277 minecraft:packed_ice
setblock 167 142 316 minecraft:snow_block
fill 168 142 276 168 145 276 minecraft:packed_ice
setblock 168 142 315 minecraft:snow_block
fill 168 142 316 168 145 316 minecraft:packed_ice
fill 169 142 315 169 145 315 minecraft:packed_ice
setblock 170 142 277 minecraft:packed_ice
fill 170 142 314 170 145 314 minecraft:packed_ice
setblock 171 142 277 minecraft:snow_block
setblock 172 142 276 minecraft:snow_block
fill 172 142 277 172 145 277 minecraft:packed_ice
setblock 172 142 316 minecraft:snow_block
fill 173 142 276 173 145 276 minecraft:packed_ice
setblock 173 142 315 minecraft:snow_block
fill 173 142 316 173 145 316 minecraft:packed_ice
setblock 174 142 314 minecraft:snow_block
fill 174 142 315 174 145 315 minecraft:packed_ice
fill 175 142 314 175 145 314 minecraft:packed_ice
setblock 176 142 277 minecraft:snow_block
setblock 177 142 276 minecraft:snow_block
fill 177 142 277 177 145 277 minecraft:packed_ice
setblock 177 142 316 minecraft:snow_block
fill 178 142 276 178 145 276 minecraft:packed_ice
fill 178 142 278 178 143 279 minecraft:packed_ice
fill 178 142 303 178 143 303 minecraft:packed_ice
setblock 178 142 315 minecraft:snow_block
fill 178 142 316 178 145 316 minecraft:packed_ice
fill 179 142 312 179 143 312 minecraft:packed_ice
fill 179 142 315 179 146 315 minecraft:packed_ice
setblock 181 142 297 minecraft:snow_block
fill 181 142 298 181 145 298 minecraft:packed_ice
fill 181 142 300 181 143 300 minecraft:packed_ice
fill 182 142 292 182 145 292 minecraft:packed_ice
setblock 182 142 296 minecraft:snow_block
fill 182 142 297 182 145 297 minecraft:packed_ice
setblock 182 142 301 minecraft:snow_block
fill 182 142 302 182 144 303 minecraft:packed_ice
setblock 182 142 316 minecraft:snow_block
fill 183 142 314 183 165 314 minecraft:blue_ice
setblock 141 143 276 minecraft:light_blue_concrete
fill 141 143 277 141 165 277 minecraft:blue_ice
fill 141 143 307 141 143 310 minecraft:blue_ice
setblock 141 143 311 minecraft:light_blue_concrete
fill 141 143 312 141 165 313 minecraft:blue_ice
setblock 142 143 290 minecraft:snow_block
fill 142 143 291 142 146 291 minecraft:packed_ice
setblock 142 143 295 minecraft:snow_block
fill 142 143 296 142 146 296 minecraft:packed_ice
setblock 142 143 300 minecraft:snow_block
fill 142 143 301 142 145 302 minecraft:packed_ice
setblock 143 143 294 minecraft:snow_block
fill 143 143 295 143 146 295 minecraft:packed_ice
setblock 143 143 299 minecraft:snow_block
fill 144 143 276 145 143 276 minecraft:packed_ice
setblock 146 143 276 minecraft:snow_block
fill 147 143 276 147 145 277 minecraft:packed_ice
fill 147 143 316 147 146 316 minecraft:packed_ice
fill 148 143 277 148 144 277 minecraft:packed_ice
setblock 149 143 278 minecraft:snow_block
setblock 150 143 277 minecraft:snow_block
fill 150 143 278 150 146 278 minecraft:packed_ice
setblock 150 143 317 minecraft:white_concrete
setblock 151 143 276 minecraft:snow_block
fill 151 143 277 151 146 277 minecraft:packed_ice
setblock 151 143 315 minecraft:packed_ice
setblock 151 143 316 minecraft:snow_block
fill 152 143 276 152 146 276 minecraft:packed_ice
setblock 152 143 315 minecraft:snow_block
fill 152 143 316 152 146 316 minecraft:packed_ice
setblock 153 143 279 minecraft:snow_block
fill 153 143 315 153 146 315 minecraft:packed_ice
setblock 154 143 277 minecraft:packed_ice
setblock 154 143 278 minecraft:snow_block
fill 154 143 279 155 145 279 minecraft:packed_ice
setblock 155 143 277 minecraft:snow_block
fill 155 143 278 155 146 278 minecraft:packed_ice
setblock 156 143 276 minecraft:snow_block
fill 156 143 277 156 146 277 minecraft:packed_ice
setblock 156 143 316 minecraft:snow_block
fill 157 143 276 160 143 276 minecraft:packed_ice
setblock 157 143 315 minecraft:snow_block
fill 157 143 316 160 143 316 minecraft:packed_ice
fill 158 143 315 158 146 315 minecraft:packed_ice
setblock 159 143 278 minecraft:snow_block
setblock 160 143 277 minecraft:snow_block
setblock 161 143 276 minecraft:snow_block
fill 161 143 277 164 143 277 minecraft:packed_ice
setblock 161 143 316 minecraft:snow_block
fill 162 143 276 162 146 276 minecraft:packed_ice
fill 162 143 316 162 146 316 minecraft:packed_ice
setblock 165 143 277 minecraft:snow_block
fill 165 143 315 165 144 315 minecraft:packed_ice
setblock 166 143 276 minecraft:snow_block
fill 166 143 277 166 146 277 minecraft:packed_ice
setblock 166 143 316 minecraft:snow_block
fill 167 143 276 167 146 276 minecraft:packed_ice
setblock 167 143 315 minecraft:snow_block
fill 167 143 316 167 146 316 minecraft:packed_ice
fill 168 143 315 168 146 315 minecraft:packed_ice
fill 169 143 314 169 146 314 minecraft:packed_ice
setblock 170 143 277 minecraft:snow_block
setblock 171 143 276 minecraft:snow_block
fill 171 143 277 171 145 278 minecraft:packed_ice
setblock 171 143 316 minecraft:snow_block
fill 172 143 276 172 146 276 minecraft:packed_ice
fill 172 143 278 173 143 278 minecraft:packed_ice
setblock 172 143 315 minecraft:snow_block
fill 172 143 316 172 146 316 minecraft:packed_ice
setblock 173 143 314 minecraft:snow_block
fill 173 143 315 173 146 315 minecraft:packed_ice
fill 174 143 314 174 146 314 minecraft:packed_ice
setblock 175 143 277 minecraft:snow_block
setblock 176 143 276 minecraft:snow_block
fill 176 143 277 176 146 277 minecraft:packed_ice
setblock 176 143 316 minecraft:snow_block
fill 177 143 276 177 146 276 minecraft:packed_ice
setblock 177 143 315 minecraft:snow_block
fill 177 143 316 177 146 316 minecraft:packed_ice
fill 178 143 315 178 145 315 minecraft:packed_ice
fill 179 143 278 179 144 278 minecraft:packed_ice
fill 179 143 303 179 144 303 minecraft:packed_ice
fill 179 143 313 179 144 313 minecraft:packed_ice
fill 181 143 294 181 144 294 minecraft:packed_ice
setblock 181 143 296 minecraft:snow_block
fill 181 143 297 181 146 297 minecraft:packed_ice
setblock 181 143 301 minecraft:snow_block
fill 181 143 302 181 146 302 minecraft:packed_ice
setblock 181 143 316 minecraft:snow_block
setblock 182 143 295 minecraft:snow_block
fill 182 143 296 182 146 296 minecraft:packed_ice
setblock 182 143 300 minecraft:snow_block
fill 182 143 301 182 146 301 minecraft:packed_ice
setblock 182 143 304 minecraft:packed_ice
setblock 182 143 315 minecraft:snow_block
fill 182 143 316 182 145 316 minecraft:packed_ice
setblock 182 143 317 minecraft:white_concrete
setblock 183 143 298 minecraft:white_concrete
fill 141 144 276 141 165 276 minecraft:blue_ice
fill 141 144 307 141 165 307 minecraft:blue_ice
setblock 141 144 308 minecraft:light_blue_concrete
fill 141 144 309 141 150 311 minecraft:blue_ice
fill 142 144 276 142 144 278 minecraft:packed_ice
setblock 142 144 279 minecraft:snow_block
fill 142 144 290 142 147 290 minecraft:packed_ice
setblock 142 144 294 minecraft:snow_block
fill 142 144 295 142 147 295 minecraft:packed_ice
setblock 142 144 299 minecraft:snow_block
fill 142 144 300 143 146 300 minecraft:packed_ice
setblock 142 144 303 minecraft:packed_ice
fill 143 144 276 144 144 276 minecraft:packed_ice
setblock 143 144 293 minecraft:snow_block
fill 143 144 294 143 147 294 minecraft:packed_ice
setblock 143 144 298 minecraft:snow_block
fill 143 144 299 143 147 299 minecraft:packed_ice
setblock 144 144 278 minecraft:light[level=15]
fill 144 144 280 144 146 280 minecraft:packed_ice
setblock 144 144 285 minecraft:light[level=12]
setblock 144 144 286 minecraft:light[level=15]
setblock 144 144 292 minecraft:light[level=12]
setblock 144 144 294 minecraft:light[level=15]
setblock 144 144 299 minecraft:light[level=12]
setblock 144 144 302 minecraft:light[level=15]
setblock 144 144 306 minecraft:light[level=12]
setblock 144 144 310 minecraft:light[level=15]
setblock 144 144 313 minecraft:light[level=12]
setblock 145 144 276 minecraft:snow_block
fill 145 144 279 145 146 279 minecraft:packed_ice
fill 145 144 281 145 146 281 minecraft:packed_ice
fill 146 144 276 146 146 277 minecraft:packed_ice
fill 146 144 280 146 146 280 minecraft:packed_ice
setblock 148 144 278 minecraft:snow_block
setblock 149 144 277 minecraft:snow_block
fill 149 144 278 149 147 278 minecraft:packed_ice
setblock 150 144 276 minecraft:snow_block
fill 150 144 277 150 147 277 minecraft:packed_ice
setblock 150 144 315 minecraft:packed_ice
setblock 150 144 316 minecraft:snow_block
fill 150 144 317 150 165 317 minecraft:blue_ice
fill 151 144 276 151 147 276 minecraft:packed_ice
setblock 151 144 279 minecraft:packed_ice
setblock 151 144 285 minecraft:light[level=12]
setblock 151 144 292 minecraft:light[level=12]
setblock 151 144 299 minecraft:light[level=12]
setblock 151 144 306 minecraft:light[level=12]
setblock 151 144 313 minecraft:light[level=12]
setblock 151 144 315 minecraft:snow_block
fill 151 144 316 151 147 316 minecraft:packed_ice
setblock 152 144 279 minecraft:snow_block
setblock 152 144 286 minecraft:light[level=15]
setblock 152 144 294 minecraft:light[level=15]
setblock 152 144 310 minecraft:light[level=15]
fill 152 144 315 152 147 315 minecraft:packed_ice
setblock 153 144 277 minecraft:packed_ice
setblock 153 144 278 minecraft:snow_block
fill 153 144 279 153 147 279 minecraft:packed_ice
setblock 154 144 277 minecraft:snow_block
fill 154 144 278 154 147 278 minecraft:packed_ice
setblock 155 144 276 minecraft:snow_block
fill 155 144 277 155 147 277 minecraft:packed_ice
setblock 155 144 316 minecraft:snow_block
fill 156 144 276 159 144 276 minecraft:packed_ice
setblock 156 144 279 minecraft:packed_ice
setblock 156 144 315 minecraft:snow_block
fill 156 144 316 159 144 316 minecraft:packed_ice
setblock 157 144 278 minecraft:packed_ice
fill 157 144 315 157 146 315 minecraft:packed_ice
setblock 158 144 278 minecraft:snow_block
setblock 158 144 285 minecraft:light[level=12]
setblock 158 144 299 minecraft:light[level=12]
setblock 158 144 306 minecraft:light[level=12]
setblock 158 144 313 minecraft:light[level=12]
setblock 159 144 277 minecraft:snow_block
fill 159 144 278 160 146 278 minecraft:packed_ice
setblock 160 144 276 minecraft:snow_block
fill 160 144 277 163 144 277 minecraft:packed_ice
setblock 160 144 286 minecraft:light[level=15]
setblock 160 144 294 minecraft:light[level=15]
setblock 160 144 302 minecraft:light[level=15]
setblock 160 144 310 minecraft:light[level=15]
setblock 160 144 316 minecraft:snow_block
fill 161 144 276 161 147 276 minecraft:packed_ice
fill 161 144 316 161 147 316 minecraft:packed_ice
setblock 164 144 277 minecraft:snow_block
fill 164 144 315 164 145 315 minecraft:packed_ice
setblock 165 144 276 minecraft:snow_block
fill 165 144 277 165 147 277 minecraft:packed_ice
setblock 165 144 278 minecraft:light[level=12]
setblock 165 144 285 minecraft:light[level=12]
setblock 165 144 292 minecraft:light[level=12]
setblock 165 144 299 minecraft:light[level=12]
setblock 165 144 306 minecraft:light[level=12]
setblock 165 144 313 minecraft:light[level=12]
setblock 165 144 316 minecraft:snow_block
fill 166 144 276 166 147 276 minecraft:packed_ice
setblock 166 144 315 minecraft:snow_block
fill 166 144 316 166 147 316 minecraft:packed_ice
fill 167 144 315 167 147 315 minecraft:packed_ice
setblock 168 144 278 minecraft:light[level=15]
setblock 168 144 286 minecraft:light[level=15]
setblock 168 144 294 minecraft:light[level=15]
setblock 168 144 302 minecraft:light[level=15]
setblock 168 144 310 minecraft:light[level=15]
fill 168 144 314 168 147 314 minecraft:packed_ice
setblock 169 144 276 minecraft:packed_ice
setblock 169 144 277 minecraft:snow_block
fill 169 144 278 170 146 278 minecraft:packed_ice
setblock 170 144 276 minecraft:snow_block
fill 170 144 277 170 147 277 minecraft:packed_ice
setblock 170 144 316 minecraft:snow_block
fill 171 144 276 171 147 276 minecraft:packed_ice
setblock 171 144 315 minecraft:snow_block
fill 171 144 316 171 147 316 minecraft:packed_ice
setblock 172 144 278 minecraft:packed_ice
setblock 172 144 285 minecraft:light[level=12]
setblock 172 144 292 minecraft:light[level=12]
setblock 172 144 299 minecraft:light[level=12]
setblock 172 144 306 minecraft:light[level=12]
setblock 172 144 313 minecraft:light[level=12]
setblock 172 144 314 minecraft:snow_block
fill 172 144 315 172 147 315 minecraft:packed_ice
setblock 173 144 278 minecraft:snow_block
fill 173 144 314 173 147 314 minecraft:packed_ice
setblock 174 144 277 minecraft:snow_block
fill 174 144 278 174 147 278 minecraft:packed_ice
setblock 175 144 276 minecraft:snow_block
fill 175 144 277 175 147 277 minecraft:packed_ice
setblock 175 144 316 minecraft:snow_block
fill 176 144 276 176 147 276 minecraft:packed_ice
setblock 176 144 278 minecraft:light[level=15]
setblock 176 144 286 minecraft:light[level=15]
setblock 176 144 294 minecraft:light[level=15]
setblock 176 144 302 minecraft:light[level=15]
setblock 176 144 315 minecraft:snow_block
fill 176 144 316 176 147 316 minecraft:packed_ice
fill 177 144 315 177 146 315 minecraft:packed_ice
fill 178 144 277 178 144 278 minecraft:packed_ice
setblock 179 144 285 minecraft:light[level=12]
setblock 179 144 292 minecraft:light[level=12]
setblock 179 144 299 minecraft:light[level=12]
setblock 179 144 306 minecraft:light[level=12]
fill 179 144 314 179 145 314 minecraft:packed_ice
setblock 180 144 276 minecraft:snow_block
fill 180 144 278 180 145 278 minecraft:packed_ice
fill 180 144 297 180 144 300 minecraft:packed_ice
fill 180 144 303 181 145 303 minecraft:packed_ice
setblock 180 144 316 minecraft:snow_block
fill 181 144 276 181 146 276 minecraft:packed_ice
setblock 181 144 295 minecraft:snow_block
fill 181 144 296 181 147 296 minecraft:packed_ice
setblock 181 144 300 minecraft:snow_block
fill 181 144 301 181 147 301 minecraft:packed_ice
fill 181 144 316 181 145 316 minecraft:packed_ice
setblock 182 144 294 minecraft:snow_block
fill 182 144 295 182 147 295 minecraft:packed_ice
setblock 182 144 299 minecraft:snow_block
fill 182 144 300 182 147 300 minecraft:packed_ice
setblock 182 144 304 minecraft:snow_block
fill 182 144 305 182 147 305 minecraft:packed_ice
setblock 182 144 315 minecraft:packed_ice
fill 182 144 317 182 149 317 minecraft:blue_ice
fill 183 144 298 183 165 298 minecraft:blue_ice
fill 141 145 308 141 165 308 minecraft:blue_ice
fill 142 145 276 142 145 277 minecraft:packed_ice
setblock 142 145 278 minecraft:snow_block
fill 142 145 279 142 145 282 minecraft:packed_ice
setblock 142 145 293 minecraft:snow_block
fill 142 145 294 142 148 294 minecraft:packed_ice
setblock 142 145 298 minecraft:snow_block
fill 142 145 299 142 148 299 minecraft:packed_ice
setblock 142 145 303 minecraft:snow_block
setblock 143 145 276 minecraft:packed_ice
fill 143 145 293 143 146 293 minecraft:packed_ice
setblock 143 145 297 minecraft:snow_block
fill 143 145 298 143 148 298 minecraft:packed_ice
setblock 143 145 301 minecraft:packed_ice
setblock 144 145 276 minecraft:snow_block
fill 144 145 279 144 146 279 minecraft:packed_ice
fill 144 145 281 144 146 281 minecraft:packed_ice
fill 145 145 276 145 147 277 minecraft:packed_ice
fill 146 145 279 146 146 279 minecraft:packed_ice
fill 146 145 281 146 146 281 minecraft:packed_ice
fill 146 145 316 146 147 316 minecraft:packed_ice
setblock 147 145 278 minecraft:snow_block
setblock 148 145 277 minecraft:snow_block
fill 148 145 278 148 148 278 minecraft:packed_ice
setblock 149 145 276 minecraft:snow_block
fill 149 145 277 149 148 277 minecraft:packed_ice
fill 149 145 279 150 145 279 minecraft:packed_ice
setblock 149 145 316 minecraft:snow_block
fill 150 145 276 150 148 276 minecraft:packed_ice
setblock 150 145 315 minecraft:snow_block
fill 150 145 316 150 148 316 minecraft:packed_ice
setblock 151 145 278 minecraft:packed_ice
setblock 151 145 279 minecraft:snow_block
fill 151 145 315 151 148 315 minecraft:packed_ice
setblock 152 145 278 minecraft:snow_block
fill 152 145 279 152 148 279 minecraft:packed_ice
setblock 153 145 277 minecraft:snow_block
fill 153 145 278 153 148 278 minecraft:packed_ice
setblock 154 145 276 minecraft:snow_block
fill 154 145 277 154 148 277 minecraft:packed_ice
setblock 154 145 316 minecraft:snow_block
fill 155 145 276 158 145 276 minecraft:packed_ice
setblock 155 145 315 minecraft:snow_block
fill 155 145 316 158 145 316 minecraft:packed_ice
setblock 156 145 279 minecraft:snow_block
fill 156 145 315 156 147 315 minecraft:packed_ice
setblock 157 145 278 minecraft:snow_block
fill 157 145 279 157 146 279 minecraft:packed_ice
setblock 158 145 277 minecraft:snow_block
fill 158 145 278 158 148 278 minecraft:packed_ice
setblock 159 145 276 minecraft:snow_block
fill 159 145 277 162 145 277 minecraft:packed_ice
setblock 159 145 316 minecraft:snow_block
fill 160 145 276 160 148 276 minecraft:packed_ice
fill 160 145 316 160 148 316 minecraft:packed_ice
setblock 163 145 277 minecraft:snow_block
setblock 164 145 276 minecraft:snow_block
fill 164 145 277 164 148 277 minecraft:packed_ice
setblock 164 145 316 minecraft:snow_block
fill 165 145 276 165 148 276 minecraft:packed_ice
setblock 165 145 315 minecraft:snow_block
fill 165 145 316 165 148 316 minecraft:packed_ice
fill 166 145 315 166 148 315 minecraft:packed_ice
setblock 167 145 277 minecraft:packed_ice
setblock 167 145 278 minecraft:snow_block
setblock 168 145 277 minecraft:snow_block
fill 168 145 278 168 148 278 minecraft:packed_ice
setblock 169 145 276 minecraft:snow_block
fill 169 145 277 169 148 277 minecraft:packed_ice
setblock 169 145 316 minecraft:snow_block
fill 170 145 276 170 148 276 minecraft:packed_ice
setblock 170 145 315 minecraft:snow_block
fill 170 145 316 170 148 316 minecraft:packed_ice
setblock 171 145 314 minecraft:snow_block
fill 171 145 315 171 148 315 minecraft:packed_ice
setblock 172 145 278 minecraft:snow_block
fill 172 145 314 172 148 314 minecraft:packed_ice
setblock 173 145 277 minecraft:snow_block
fill 173 145 278 173 148 278 minecraft:packed_ice
setblock 174 145 276 minecraft:snow_block
fill 174 145 277 174 148 277 minecraft:packed_ice
setblock 174 145 316 minecraft:snow_block
fill 175 145 276 175 148 276 minecraft:packed_ice
setblock 175 145 278 minecraft:packed_ice
setblock 175 145 315 minecraft:snow_block
fill 175 145 316 175 148 316 minecraft:packed_ice
setblock 176 145 314 minecraft:snow_block
fill 176 145 315 176 147 315 minecraft:packed_ice
setblock 178 145 277 minecraft:snow_block
setblock 179 145 276 minecraft:snow_block
setblock 179 145 316 minecraft:snow_block
fill 180 145 276 180 146 276 minecraft:packed_ice
fill 180 145 297 180 145 299 minecraft:packed_ice
setblock 180 145 300 minecraft:snow_block
fill 180 145 301 180 148 301 minecraft:packed_ice
fill 180 145 316 180 146 316 minecraft:packed_ice
fill 181 145 278 181 146 278 minecraft:packed_ice
fill 181 145 295 181 147 295 minecraft:packed_ice
setblock 181 145 299 minecraft:snow_block
fill 181 145 300 181 148 300 minecraft:packed_ice
setblock 181 145 304 minecraft:snow_block
setblock 182 145 293 minecraft:snow_block
fill 182 145 294 182 148 294 minecraft:packed_ice
setblock 182 145 298 minecraft:snow_block
fill 182 145 299 182 148 299 minecraft:packed_ice
setblock 182 145 302 minecraft:packed_ice
setblock 182 145 303 minecraft:snow_block
fill 182 145 304 182 148 304 minecraft:packed_ice
fill 182 145 306 182 146 306 minecraft:packed_ice
setblock 142 146 276 minecraft:packed_ice
setblock 142 146 277 minecraft:snow_block
fill 142 146 278 142 146 281 minecraft:packed_ice
setblock 142 146 282 minecraft:snow_block
fill 142 146 283 142 147 285 minecraft:packed_ice
setblock 142 146 292 minecraft:snow_block
fill 142 146 293 142 149 293 minecraft:packed_ice
setblock 142 146 297 minecraft:snow_block
fill 142 146 298 142 149 298 minecraft:packed_ice
setblock 142 146 301 minecraft:packed_ice
setblock 142 146 302 minecraft:snow_block
fill 142 146 303 142 148 304 minecraft:packed_ice
setblock 143 146 276 minecraft:snow_block
fill 143 146 278 143 146 280 minecraft:packed_ice
setblock 143 146 296 minecraft:snow_block
fill 143 146 297 143 149 297 minecraft:packed_ice
setblock 143 146 301 minecraft:snow_block
fill 143 146 302 143 149 302 minecraft:packed_ice
fill 144 146 276 144 148 277 minecraft:packed_ice
setblock 146 146 278 minecraft:snow_block
setblock 146 146 282 minecraft:sea_lantern
setblock 146 146 288 minecraft:sea_lantern
setblock 146 146 294 minecraft:sea_lantern
setblock 146 146 300 minecraft:sea_lantern
setblock 146 146 306 minecraft:sea_lantern
setblock 146 146 312 minecraft:sea_lantern
setblock 147 146 276 minecraft:packed_ice
setblock 147 146 277 minecraft:snow_block
fill 147 146 278 147 149 278 minecraft:packed_ice
setblock 148 146 276 minecraft:snow_block
fill 148 146 277 148 149 277 minecraft:packed_ice
fill 148 146 279 149 146 279 minecraft:packed_ice
setblock 148 146 280 minecraft:sea_lantern
setblock 148 146 316 minecraft:snow_block
fill 149 146 276 149 149 276 minecraft:packed_ice
fill 149 146 315 149 147 315 minecraft:snow_block
fill 149 146 316 149 149 316 minecraft:packed_ice
setblock 150 146 279 minecraft:snow_block
fill 150 146 315 150 148 315 minecraft:packed_ice
setblock 151 146 278 minecraft:snow_block
fill 151 146 279 151 148 280 minecraft:packed_ice
setblock 152 146 277 minecraft:snow_block
fill 152 146 278 152 149 278 minecraft:packed_ice
fill 152 146 280 153 146 280 minecraft:packed_ice
setblock 152 146 312 minecraft:sea_lantern
setblock 153 146 276 minecraft:snow_block
fill 153 146 277 153 149 277 minecraft:packed_ice
setblock 153 146 316 minecraft:snow_block
fill 154 146 276 157 146 276 minecraft:packed_ice
setblock 154 146 279 minecraft:packed_ice
setblock 154 146 280 minecraft:sea_lantern
setblock 154 146 315 minecraft:snow_block
fill 154 146 316 157 146 316 minecraft:packed_ice
setblock 154 146 317 minecraft:white_concrete
setblock 155 146 279 minecraft:snow_block
fill 155 146 315 155 147 315 minecraft:packed_ice
setblock 156 146 278 minecraft:snow_block
fill 156 146 279 156 148 279 minecraft:packed_ice
setblock 157 146 277 minecraft:snow_block
fill 157 146 278 157 149 278 minecraft:packed_ice
setblock 158 146 276 minecraft:snow_block
fill 158 146 277 161 146 277 minecraft:packed_ice
setblock 158 146 312 minecraft:sea_lantern
setblock 158 146 316 minecraft:snow_block
fill 159 146 276 159 149 276 minecraft:packed_ice
fill 159 146 316 159 149 316 minecraft:packed_ice
setblock 160 146 280 minecraft:sea_lantern
fill 161 146 278 161 147 278 minecraft:snow_block
setblock 162 146 277 minecraft:snow_block
setblock 163 146 276 minecraft:snow_block
fill 163 146 277 163 149 277 minecraft:packed_ice
setblock 163 146 316 minecraft:snow_block
fill 164 146 276 164 149 276 minecraft:packed_ice
setblock 164 146 312 minecraft:sea_lantern
setblock 164 146 315 minecraft:snow_block
fill 164 146 316 164 149 316 minecraft:packed_ice
setblock 165 146 278 minecraft:packed_ice
fill 165 146 315 165 149 315 minecraft:packed_ice
setblock 166 146 278 minecraft:snow_block
setblock 166 146 280 minecraft:sea_lantern
setblock 167 146 277 minecraft:snow_block
fill 167 146 278 167 149 278 minecraft:packed_ice
setblock 168 146 276 minecraft:snow_block
fill 168 146 277 168 149 277 minecraft:packed_ice
setblock 168 146 316 minecraft:snow_block
fill 169 146 276 169 149 276 minecraft:packed_ice
setblock 169 146 315 minecraft:snow_block
fill 169 146 316 169 149 316 minecraft:packed_ice
setblock 170 146 314 minecraft:snow_block
fill 170 146 315 170 149 315 minecraft:packed_ice
setblock 171 146 277 minecraft:packed_ice
setblock 171 146 278 minecraft:snow_block
fill 171 146 314 171 148 314 minecraft:packed_ice
setblock 172 146 277 minecraft:snow_block
fill 172 146 278 172 149 278 minecraft:packed_ice
setblock 172 146 280 minecraft:sea_lantern
setblock 173 146 276 minecraft:snow_block
fill 173 146 277 173 149 277 minecraft:packed_ice
setblock 173 146 316 minecraft:snow_block
fill 174 146 276 174 149 276 minecraft:packed_ice
setblock 174 146 315 minecraft:snow_block
fill 174 146 316 174 149 316 minecraft:packed_ice
fill 175 146 314 175 147 314 minecraft:snow_block
fill 175 146 315 175 148 315 minecraft:packed_ice
setblock 177 146 277 minecraft:snow_block
setblock 178 146 276 minecraft:snow_block
setblock 178 146 280 minecraft:sea_lantern
setblock 178 146 286 minecraft:sea_lantern
setblock 178 146 292 minecraft:sea_lantern
setblock 178 146 298 minecraft:sea_lantern
setblock 178 146 304 minecraft:sea_lantern
setblock 178 146 310 minecraft:sea_lantern
setblock 178 146 316 minecraft:snow_block
fill 179 146 276 179 147 276 minecraft:packed_ice
fill 179 146 316 179 147 316 minecraft:packed_ice
fill 180 146 297 180 146 298 minecraft:packed_ice
setblock 180 146 299 minecraft:snow_block
fill 180 146 300 180 148 300 minecraft:packed_ice
fill 180 146 302 180 147 302 minecraft:packed_ice
fill 180 146 317 180 165 317 minecraft:blue_ice
setblock 181 146 298 minecraft:snow_block
fill 181 146 299 181 149 299 minecraft:packed_ice
setblock 181 146 303 minecraft:snow_block
fill 181 146 304 181 149 304 minecraft:packed_ice
setblock 181 146 317 minecraft:white_concrete
setblock 182 146 277 minecraft:snow_block
fill 182 146 278 182 148 278 minecraft:packed_ice
fill 182 146 292 182 147 292 minecraft:snow_block
fill 182 146 293 182 148 293 minecraft:packed_ice
setblock 182 146 297 minecraft:snow_block
fill 182 146 298 182 149 298 minecraft:packed_ice
setblock 182 146 302 minecraft:snow_block
fill 182 146 303 182 149 303 minecraft:packed_ice
setblock 183 146 276 minecraft:light_blue_concrete
fill 183 146 277 183 165 277 minecraft:blue_ice
setblock 141 147 305 minecraft:white_concrete
setblock 142 147 276 minecraft:snow_block
fill 142 147 277 142 147 280 minecraft:packed_ice
setblock 142 147 281 minecraft:snow_block
fill 142 147 282 143 149 282 minecraft:packed_ice
fill 142 147 286 146 147 286 minecraft:snow_block
fill 142 147 287 142 148 289 minecraft:packed_ice
fill 142 147 291 146 147 291 minecraft:snow_block
fill 142 147 292 142 149 292 minecraft:packed_ice
setblock 142 147 296 minecraft:snow_block
fill 142 147 297 142 150 297 minecraft:packed_ice
setblock 142 147 300 minecraft:packed_ice
setblock 142 147 301 minecraft:snow_block
fill 142 147 302 142 150 302 minecraft:packed_ice
fill 142 147 305 145 147 316 minecraft:snow_block
fill 143 147 276 143 147 279 minecraft:packed_ice
fill 143 147 280 149 147 280 minecraft:snow_block
fill 143 147 281 143 150 281 minecraft:packed_ice
fill 143 147 283 143 148 283 minecraft:packed_ice
fill 143 147 284 146 147 285 minecraft:snow_block
fill 143 147 287 146 147 290 minecraft:snow_block
fill 143 147 292 146 147 293 minecraft:snow_block
fill 143 147 295 146 147 295 minecraft:snow_block
fill 143 147 296 143 149 296 minecraft:packed_ice
fill 143 147 300 146 147 300 minecraft:snow_block
fill 143 147 301 143 150 301 minecraft:packed_ice
fill 143 147 303 146 147 304 minecraft:snow_block
fill 144 147 278 145 147 279 minecraft:snow_block
fill 144 147 281 146 147 283 minecraft:snow_block
fill 144 147 294 146 147 294 minecraft:snow_block
fill 144 147 296 146 147 299 minecraft:snow_block
fill 144 147 301 146 147 302 minecraft:snow_block
setblock 146 147 276 minecraft:packed_ice
setblock 146 147 277 minecraft:snow_block
fill 146 147 278 146 150 278 minecraft:packed_ice
setblock 146 147 279 minecraft:snow_block
fill 146 147 305 146 147 315 minecraft:snow_block
setblock 147 147 276 minecraft:snow_block
fill 147 147 277 147 150 277 minecraft:packed_ice
fill 147 147 279 148 147 279 minecraft:packed_ice
fill 147 147 312 147 147 316 minecraft:snow_block
fill 148 147 276 148 150 276 minecraft:packed_ice
fill 148 147 312 148 147 315 minecraft:snow_block
fill 148 147 316 148 150 316 minecraft:packed_ice
setblock 149 147 279 minecraft:snow_block
fill 149 147 312 160 147 314 minecraft:snow_block
setblock 150 147 278 minecraft:snow_block
fill 150 147 279 150 149 280 minecraft:packed_ice
setblock 151 147 277 minecraft:snow_block
fill 151 147 278 151 150 278 minecraft:packed_ice
setblock 152 147 276 minecraft:snow_block
fill 152 147 277 152 150 277 minecraft:packed_ice
setblock 152 147 280 minecraft:packed_ice
setblock 152 147 316 minecraft:snow_block
fill 153 147 276 156 147 276 minecraft:packed_ice
fill 153 147 280 181 147 280 minecraft:snow_block
setblock 153 147 315 minecraft:snow_block
fill 153 147 316 156 147 316 minecraft:packed_ice
setblock 154 147 279 minecraft:snow_block
fill 154 147 315 154 148 315 minecraft:packed_ice
fill 154 147 317 154 165 317 minecraft:blue_ice
setblock 155 147 278 minecraft:snow_block
fill 155 147 279 155 149 279 minecraft:packed_ice
setblock 156 147 277 minecraft:snow_block
fill 156 147 278 156 150 278 minecraft:packed_ice
setblock 157 147 276 minecraft:snow_block
fill 157 147 277 160 147 277 minecraft:packed_ice
fill 157 147 279 181 147 279 minecraft:snow_block
fill 157 147 315 157 147 316 minecraft:snow_block
fill 158 147 276 158 150 276 minecraft:packed_ice
fill 158 147 315 163 147 315 minecraft:snow_block
fill 158 147 316 158 149 316 minecraft:packed_ice
setblock 159 147 278 minecraft:packed_ice
setblock 160 147 278 minecraft:snow_block
setblock 161 147 277 minecraft:snow_block
fill 161 147 313 167 147 314 minecraft:snow_block
setblock 162 147 276 minecraft:snow_block
fill 162 147 277 162 150 277 minecraft:packed_ice
fill 162 147 278 165 147 278 minecraft:snow_block
setblock 162 147 316 minecraft:snow_block
fill 163 147 276 163 150 276 minecraft:packed_ice
fill 163 147 316 163 150 316 minecraft:packed_ice
fill 164 147 312 167 147 312 minecraft:snow_block
fill 164 147 315 164 148 315 minecraft:packed_ice
setblock 166 147 277 minecraft:snow_block
fill 166 147 278 166 149 278 minecraft:packed_ice
setblock 167 147 276 minecraft:snow_block
fill 167 147 277 167 150 277 minecraft:packed_ice
setblock 167 147 316 minecraft:snow_block
fill 168 147 276 168 150 276 minecraft:packed_ice
setblock 168 147 313 minecraft:snow_block
setblock 168 147 315 minecraft:snow_block
fill 168 147 316 168 150 316 minecraft:packed_ice
setblock 169 147 278 minecraft:packed_ice
setblock 169 147 314 minecraft:snow_block
fill 169 147 315 169 150 315 minecraft:packed_ice
setblock 170 147 278 minecraft:snow_block
fill 170 147 313 175 147 313 minecraft:snow_block
fill 170 147 314 170 149 314 minecraft:packed_ice
setblock 171 147 277 minecraft:snow_block
fill 171 147 278 171 149 278 minecraft:packed_ice
fill 171 147 312 174 147 312 minecraft:snow_block
setblock 172 147 276 minecraft:snow_block
fill 172 147 277 172 150 277 minecraft:packed_ice
setblock 172 147 316 minecraft:snow_block
fill 173 147 276 173 150 276 minecraft:packed_ice
setblock 173 147 315 minecraft:snow_block
fill 173 147 316 173 150 316 minecraft:packed_ice
setblock 174 147 314 minecraft:snow_block
fill 174 147 315 174 149 315 minecraft:packed_ice
fill 175 147 278 181 147 278 minecraft:snow_block
setblock 176 147 277 minecraft:snow_block
fill 176 147 314 182 147 314 minecraft:snow_block
setblock 177 147 276 minecraft:snow_block
setblock 177 147 277 minecraft:packed_ice
fill 177 147 315 177 147 316 minecraft:snow_block
fill 178 147 276 178 148 276 minecraft:packed_ice
fill 178 147 277 181 147 277 minecraft:snow_block
fill 178 147 281 179 147 310 minecraft:snow_block
fill 178 147 313 182 147 313 minecraft:snow_block
fill 178 147 315 182 147 315 minecraft:snow_block
fill 178 147 316 178 148 316 minecraft:packed_ice
fill 179 147 311 182 147 312 minecraft:snow_block
fill 180 147 276 182 147 276 minecraft:snow_block
fill 180 147 281 180 147 298 minecraft:snow_block
fill 180 147 299 180 148 299 minecraft:packed_ice
fill 180 147 303 180 147 310 minecraft:snow_block
fill 180 147 316 182 147 316 minecraft:snow_block
fill 181 147 281 181 147 294 minecraft:snow_block
setblock 181 147 297 minecraft:snow_block
fill 181 147 298 181 150 298 minecraft:packed_ice
setblock 181 147 302 minecraft:snow_block
fill 181 147 303 181 150 303 minecraft:packed_ice
fill 181 147 305 181 148 305 minecraft:packed_ice
fill 181 147 306 181 147 310 minecraft:snow_block
fill 181 147 317 181 162 317 minecraft:blue_ice
setblock 182 147 277 minecraft:packed_ice
fill 182 147 279 182 147 280 minecraft:packed_ice
fill 182 147 281 182 147 291 minecraft:snow_block
setblock 182 147 296 minecraft:snow_block
fill 182 147 297 182 150 297 minecraft:packed_ice
setblock 182 147 301 minecraft:snow_block
fill 182 147 302 182 150 302 minecraft:packed_ice
setblock 182 147 306 minecraft:snow_block
fill 182 147 307 182 150 307 minecraft:packed_ice
fill 182 147 308 182 147 310 minecraft:snow_block
fill 183 147 276 183 165 276 minecraft:blue_ice
fill 183 147 307 183 153 309 minecraft:blue_ice
setblock 183 147 310 minecraft:white_concrete
fill 183 147 311 183 165 311 minecraft:blue_ice
fill 141 148 305 141 165 305 minecraft:blue_ice
fill 142 148 276 142 148 279 minecraft:packed_ice
setblock 142 148 280 minecraft:snow_block
fill 142 148 281 142 151 281 minecraft:packed_ice
fill 142 148 283 142 148 284 minecraft:packed_ice
setblock 142 148 285 minecraft:snow_block
fill 142 148 286 142 151 286 minecraft:packed_ice
setblock 142 148 290 minecraft:snow_block
fill 142 148 291 142 149 291 minecraft:packed_ice
setblock 142 148 295 minecraft:snow_block
fill 142 148 296 142 151 296 minecraft:packed_ice
setblock 142 148 300 minecraft:snow_block
fill 142 148 301 142 151 301 minecraft:packed_ice
setblock 142 148 305 minecraft:snow_block
fill 143 148 276 143 148 278 minecraft:packed_ice
setblock 143 148 279 minecraft:snow_block
fill 143 148 280 144 150 280 minecraft:packed_ice
setblock 143 148 284 minecraft:snow_block
setblock 143 148 295 minecraft:packed_ice
setblock 143 148 299 minecraft:snow_block
fill 143 148 300 143 150 300 minecraft:packed_ice
fill 144 148 281 144 149 281 minecraft:packed_ice
setblock 145 148 276 minecraft:packed_ice
setblock 145 148 277 minecraft:snow_block
fill 145 148 278 145 151 278 minecraft:packed_ice
setblock 146 148 276 minecraft:snow_block
fill 146 148 277 146 151 277 minecraft:packed_ice
fill 146 148 280 146 148 312 minecraft:blue_ice
setblock 146 148 316 minecraft:snow_block
fill 147 148 276 147 151 276 minecraft:packed_ice
setblock 147 148 279 minecraft:packed_ice
fill 147 148 280 148 148 280 minecraft:blue_ice
fill 147 148 312 160 148 312 minecraft:blue_ice
fill 147 148 316 147 150 316 minecraft:packed_ice
setblock 148 148 279 minecraft:snow_block
setblock 149 148 278 minecraft:snow_block
fill 149 148 279 149 149 280 minecraft:packed_ice
setblock 150 148 277 minecraft:snow_block
fill 150 148 278 150 151 278 minecraft:packed_ice
setblock 151 148 276 minecraft:snow_block
fill 151 148 277 151 151 277 minecraft:packed_ice
setblock 151 148 316 minecraft:snow_block
fill 152 148 276 155 148 276 minecraft:packed_ice
setblock 152 148 280 minecraft:snow_block
setblock 152 148 315 minecraft:snow_block
fill 152 148 316 155 148 316 minecraft:packed_ice
setblock 153 148 279 minecraft:snow_block
fill 153 148 280 178 148 280 minecraft:blue_ice
setblock 153 148 315 minecraft:packed_ice
setblock 154 148 278 minecraft:snow_block
fill 154 148 279 154 149 279 minecraft:packed_ice
setblock 155 148 277 minecraft:snow_block
fill 155 148 278 155 150 278 minecraft:packed_ice
setblock 156 148 276 minecraft:snow_block
fill 156 148 277 159 148 277 minecraft:packed_ice
setblock 156 148 316 minecraft:snow_block
fill 157 148 276 157 151 276 minecraft:packed_ice
fill 157 148 316 157 149 316 minecraft:packed_ice
setblock 159 148 278 minecraft:snow_block
setblock 160 148 277 minecraft:snow_block
setblock 161 148 276 minecraft:snow_block
fill 161 148 277 161 150 277 minecraft:packed_ice
setblock 161 148 316 minecraft:snow_block
fill 162 148 276 162 151 276 minecraft:packed_ice
fill 162 148 316 162 151 316 minecraft:packed_ice
fill 164 148 312 167 148 312 minecraft:blue_ice
setblock 165 148 277 minecraft:snow_block
setblock 165 148 278 minecraft:packed_ice
setblock 166 148 276 minecraft:snow_block
fill 166 148 277 166 151 277 minecraft:packed_ice
setblock 166 148 316 minecraft:snow_block
fill 167 148 276 167 151 276 minecraft:packed_ice
fill 167 148 287 168 149 287 minecraft:white_concrete
setblock 167 148 315 minecraft:snow_block
fill 167 148 316 167 151 316 minecraft:packed_ice
setblock 168 148 314 minecraft:snow_block
fill 168 148 315 168 151 315 minecraft:packed_ice
setblock 169 148 278 minecraft:snow_block
fill 169 148 314 169 149 314 minecraft:packed_ice
setblock 170 148 277 minecraft:snow_block
fill 170 148 278 170 150 278 minecraft:packed_ice
setblock 171 148 276 minecraft:snow_block
fill 171 148 277 171 151 277 minecraft:packed_ice
fill 171 148 312 174 148 312 minecraft:blue_ice
setblock 171 148 316 minecraft:snow_block
fill 172 148 276 172 151 276 minecraft:packed_ice
setblock 172 148 315 minecraft:snow_block
fill 172 148 316 172 151 316 minecraft:packed_ice
fill 173 148 315 173 149 315 minecraft:packed_ice
fill 174 148 301 178 167 303 minecraft:snow_block
setblock 175 148 277 minecraft:snow_block
fill 175 148 300 177 167 300 minecraft:snow_block
fill 175 148 304 177 167 304 minecraft:snow_block
setblock 176 148 276 minecraft:snow_block
setblock 176 148 277 minecraft:packed_ice
setblock 176 148 316 minecraft:snow_block
setblock 177 148 276 minecraft:packed_ice
setblock 177 148 316 minecraft:packed_ice
fill 178 148 281 178 148 300 minecraft:blue_ice
fill 178 148 304 178 148 310 minecraft:blue_ice
fill 180 148 302 180 166 302 minecraft:snow_block
setblock 181 148 296 minecraft:snow_block
fill 181 148 297 181 149 297 minecraft:packed_ice
setblock 181 148 301 minecraft:snow_block
fill 181 148 302 181 151 302 minecraft:packed_ice
setblock 182 148 279 minecraft:packed_ice
setblock 182 148 280 minecraft:snow_block
fill 182 148 281 182 151 281 minecraft:packed_ice
setblock 182 148 295 minecraft:snow_block
fill 182 148 296 182 151 296 minecraft:packed_ice
setblock 182 148 300 minecraft:snow_block
fill 182 148 301 182 151 301 minecraft:packed_ice
setblock 182 148 305 minecraft:snow_block
fill 182 148 306 182 151 306 minecraft:packed_ice
setblock 183 148 289 minecraft:light_blue_concrete
fill 183 148 310 183 164 310 minecraft:blue_ice
fill 142 149 276 142 149 278 minecraft:packed_ice
setblock 142 149 279 minecraft:snow_block
fill 142 149 280 142 152 280 minecraft:packed_ice
setblock 142 149 283 minecraft:packed_ice
setblock 142 149 284 minecraft:snow_block
fill 142 149 285 143 151 285 minecraft:packed_ice
fill 142 149 287 142 149 288 minecraft:packed_ice
setblock 142 149 289 minecraft:snow_block
setblock 142 149 290 minecraft:packed_ice
setblock 142 149 294 minecraft:snow_block
fill 142 149 295 142 150 295 minecraft:packed_ice
setblock 142 149 299 minecraft:snow_block
fill 142 149 300 142 152 300 minecraft:packed_ice
setblock 142 149 303 minecraft:packed_ice
setblock 142 149 304 minecraft:snow_block
fill 142 149 305 142 152 305 minecraft:packed_ice
fill 143 149 276 143 149 277 minecraft:packed_ice
setblock 143 149 278 minecraft:snow_block
fill 143 149 279 144 151 279 minecraft:packed_ice
setblock 143 149 283 minecraft:snow_block
fill 143 149 284 143 152 284 minecraft:packed_ice
fill 143 149 293 143 153 295 minecraft:blue_ice
setblock 143 149 298 minecraft:snow_block
fill 143 149 299 143 150 299 minecraft:packed_ice
setblock 144 149 276 minecraft:packed_ice
setblock 144 149 277 minecraft:snow_block
setblock 144 149 282 minecraft:snow_block
fill 144 149 283 144 152 283 minecraft:packed_ice
fill 144 149 294 144 153 294 minecraft:blue_ice
fill 144 149 314 144 158 314 minecraft:snow_block
setblock 145 149 276 minecraft:snow_block
fill 145 149 277 145 152 277 minecraft:packed_ice
fill 146 149 276 146 152 276 minecraft:packed_ice
setblock 147 149 279 minecraft:snow_block
setblock 148 149 278 minecraft:snow_block
fill 148 149 279 148 152 279 minecraft:packed_ice
setblock 149 149 277 minecraft:snow_block
fill 149 149 278 149 152 278 minecraft:packed_ice
setblock 150 149 276 minecraft:snow_block
fill 150 149 277 150 152 277 minecraft:packed_ice
setblock 150 149 316 minecraft:snow_block
fill 151 149 276 154 149 276 minecraft:packed_ice
setblock 151 149 279 minecraft:packed_ice
setblock 151 149 280 minecraft:snow_block
fill 151 149 316 154 149 316 minecraft:packed_ice
setblock 152 149 279 minecraft:snow_block
setblock 153 149 278 minecraft:snow_block
fill 153 149 279 153 150 279 minecraft:packed_ice
setblock 154 149 277 minecraft:snow_block
fill 154 149 278 154 151 278 minecraft:packed_ice
setblock 155 149 276 minecraft:snow_block
fill 155 149 277 158 149 277 minecraft:packed_ice
setblock 155 149 316 minecraft:snow_block
fill 156 149 276 156 152 276 minecraft:packed_ice
fill 156 149 316 156 150 316 minecraft:packed_ice
setblock 159 149 277 minecraft:snow_block
setblock 160 149 276 minecraft:snow_block
fill 160 149 277 160 150 277 minecraft:packed_ice
setblock 160 149 316 minecraft:snow_block
fill 161 149 276 161 152 276 minecraft:packed_ice
fill 161 149 316 161 150 316 minecraft:packed_ice
setblock 164 149 277 minecraft:snow_block
setblock 165 149 276 minecraft:snow_block
fill 165 149 277 165 151 277 minecraft:packed_ice
setblock 165 149 316 minecraft:snow_block
fill 166 149 276 166 152 276 minecraft:packed_ice
fill 166 149 281 166 155 281 minecraft:packed_ice
setblock 166 149 315 minecraft:snow_block
fill 166 149 316 166 152 316 minecraft:packed_ice
fill 167 149 315 167 152 315 minecraft:packed_ice
setblock 168 149 275 minecraft:white_concrete
setblock 168 149 278 minecraft:snow_block
fill 169 149 275 170 165 275 minecraft:blue_ice
setblock 169 149 277 minecraft:snow_block
fill 169 149 278 169 150 278 minecraft:packed_ice
setblock 170 149 276 minecraft:snow_block
fill 170 149 277 170 151 277 minecraft:packed_ice
setblock 170 149 316 minecraft:snow_block
fill 171 149 276 171 152 276 minecraft:packed_ice
setblock 171 149 315 minecraft:snow_block
fill 171 149 316 171 152 316 minecraft:packed_ice
fill 172 149 300 173 166 304 minecraft:snow_block
fill 172 149 307 173 164 307 minecraft:snow_block
fill 172 149 315 172 150 315 minecraft:packed_ice
fill 173 149 299 179 166 299 minecraft:snow_block
fill 173 149 305 179 166 305 minecraft:snow_block
setblock 174 149 277 minecraft:snow_block
fill 174 149 298 178 166 298 minecraft:snow_block
fill 174 149 300 174 166 300 minecraft:snow_block
fill 174 149 304 174 166 304 minecraft:snow_block
fill 174 149 306 178 166 306 minecraft:snow_block
setblock 175 149 276 minecraft:snow_block
setblock 175 149 316 minecraft:snow_block
setblock 176 149 276 minecraft:packed_ice
setblock 176 149 316 minecraft:packed_ice
fill 178 149 300 181 149 300 minecraft:snow_block
fill 178 149 304 180 166 304 minecraft:snow_block
fill 179 149 301 179 166 303 minecraft:snow_block
fill 180 149 301 180 166 301 minecraft:snow_block
fill 180 149 303 180 166 303 minecraft:snow_block
fill 181 149 301 181 152 301 minecraft:packed_ice
setblock 181 149 305 minecraft:snow_block
setblock 182 149 279 minecraft:snow_block
fill 182 149 280 182 152 280 minecraft:packed_ice
fill 182 149 282 182 149 283 minecraft:packed_ice
setblock 182 149 294 minecraft:snow_block
fill 182 149 295 182 151 295 minecraft:packed_ice
setblock 182 149 299 minecraft:snow_block
fill 182 149 300 182 152 300 minecraft:packed_ice
setblock 182 149 304 minecraft:snow_block
fill 182 149 305 182 152 305 minecraft:packed_ice
fill 183 149 289 183 165 289 minecraft:blue_ice
fill 142 150 276 142 150 277 minecraft:packed_ice
setblock 142 150 278 minecraft:snow_block
fill 142 150 279 142 153 279 minecraft:packed_ice
setblock 142 150 282 minecraft:packed_ice
setblock 142 150 283 minecraft:snow_block
fill 142 150 284 142 153 284 minecraft:packed_ice
setblock 142 150 287 minecraft:packed_ice
setblock 142 150 288 minecraft:snow_block
fill 142 150 289 142 153 289 minecraft:packed_ice
fill 142 150 292 142 152 293 minecraft:blue_ice
setblock 142 150 294 minecraft:packed_ice
setblock 142 150 298 minecraft:snow_block
fill 142 150 299 142 152 299 minecraft:packed_ice
setblock 142 150 303 minecraft:snow_block
fill 142 150 304 142 153 304 minecraft:packed_ice
setblock 143 150 276 minecraft:packed_ice
fill 143 150 278 143 153 278 minecraft:packed_ice
setblock 143 150 282 minecraft:snow_block
fill 143 150 283 143 153 283 minecraft:packed_ice
setblock 143 150 286 minecraft:packed_ice
fill 143 150 292 143 151 292 minecraft:blue_ice
fill 143 150 296 143 151 296 minecraft:blue_ice
fill 143 150 298 143 152 298 minecraft:blue_ice
setblock 143 150 302 minecraft:snow_block
setblock 144 150 276 minecraft:snow_block
fill 144 150 277 144 153 277 minecraft:packed_ice
setblock 144 150 278 minecraft:light[level=12]
setblock 144 150 281 minecraft:snow_block
fill 144 150 282 144 153 282 minecraft:packed_ice
fill 144 150 284 144 151 284 minecraft:packed_ice
setblock 144 150 285 minecraft:light[level=12]
setblock 144 150 292 minecraft:light[level=12]
fill 144 150 293 144 153 293 minecraft:blue_ice
fill 144 150 295 144 153 295 minecraft:blue_ice
setblock 144 150 299 minecraft:light[level=12]
setblock 144 150 306 minecraft:light[level=12]
setblock 144 150 313 minecraft:light[level=12]
fill 145 150 276 145 153 276 minecraft:packed_ice
setblock 147 150 278 minecraft:snow_block
fill 147 150 279 147 151 279 minecraft:packed_ice
setblock 148 150 277 minecraft:snow_block
fill 148 150 278 148 153 278 minecraft:packed_ice
setblock 149 150 276 minecraft:snow_block
fill 149 150 277 149 153 277 minecraft:packed_ice
fill 149 150 279 150 150 279 minecraft:packed_ice
setblock 149 150 316 minecraft:snow_block
fill 150 150 276 153 150 276 minecraft:packed_ice
fill 150 150 316 153 150 316 minecraft:packed_ice
setblock 151 150 279 minecraft:snow_block
setblock 151 150 285 minecraft:light[level=12]
setblock 151 150 292 minecraft:light[level=12]
setblock 151 150 299 minecraft:light[level=12]
setblock 151 150 306 minecraft:light[level=12]
setblock 151 150 313 minecraft:light[level=12]
setblock 152 150 278 minecraft:snow_block
fill 152 150 279 152 151 279 minecraft:packed_ice
setblock 153 150 277 minecraft:snow_block
fill 153 150 278 153 151 278 minecraft:packed_ice
setblock 154 150 276 minecraft:snow_block
fill 154 150 277 157 150 277 minecraft:packed_ice
setblock 154 150 316 minecraft:snow_block
fill 155 150 276 155 153 276 minecraft:packed_ice
setblock 155 150 316 minecraft:packed_ice
setblock 158 150 277 minecraft:snow_block
setblock 158 150 278 minecraft:light[level=12]
setblock 158 150 285 minecraft:light[level=12]
setblock 158 150 299 minecraft:light[level=12]
setblock 158 150 306 minecraft:light[level=12]
setblock 158 150 313 minecraft:light[level=12]
setblock 159 150 276 minecraft:snow_block
setblock 159 150 277 minecraft:packed_ice
fill 160 150 276 160 151 276 minecraft:packed_ice
setblock 163 150 277 minecraft:snow_block
setblock 164 150 276 minecraft:snow_block
fill 164 150 277 164 151 277 minecraft:packed_ice
setblock 164 150 316 minecraft:snow_block
fill 165 150 276 165 153 276 minecraft:packed_ice
setblock 165 150 278 minecraft:light[level=12]
setblock 165 150 285 minecraft:light[level=12]
setblock 165 150 292 minecraft:light[level=12]
setblock 165 150 299 minecraft:light[level=12]
setblock 165 150 306 minecraft:light[level=12]
setblock 165 150 313 minecraft:light[level=12]
fill 165 150 316 165 153 316 minecraft:packed_ice
fill 166 150 315 166 151 315 minecraft:packed_ice
setblock 167 150 278 minecraft:snow_block
fill 168 150 275 168 163 275 minecraft:blue_ice
setblock 168 150 277 minecraft:snow_block
setblock 168 150 278 minecraft:packed_ice
setblock 169 150 276 minecraft:snow_block
fill 169 150 277 169 152 277 minecraft:packed_ice
setblock 169 150 316 minecraft:snow_block
fill 170 150 276 170 153 276 minecraft:packed_ice
setblock 170 150 315 minecraft:snow_block
fill 170 150 316 170 153 316 minecraft:packed_ice
fill 171 150 299 171 165 305 minecraft:snow_block
fill 171 150 315 171 151 315 minecraft:packed_ice
setblock 172 150 278 minecraft:light[level=12]
setblock 172 150 285 minecraft:light[level=12]
setblock 172 150 292 minecraft:light[level=12]
fill 172 150 298 172 165 299 minecraft:snow_block
fill 172 150 305 172 165 306 minecraft:snow_block
setblock 172 150 313 minecraft:light[level=12]
setblock 173 150 275 minecraft:white_concrete
setblock 173 150 277 minecraft:snow_block
fill 173 150 297 173 165 298 minecraft:snow_block
fill 173 150 306 173 165 306 minecraft:snow_block
fill 174 150 275 175 165 275 minecraft:blue_ice
setblock 174 150 276 minecraft:snow_block
fill 174 150 297 179 165 297 minecraft:snow_block
fill 174 150 307 179 165 307 minecraft:snow_block
setblock 174 150 316 minecraft:snow_block
setblock 175 150 276 minecraft:packed_ice
setblock 175 150 316 minecraft:packed_ice
fill 178 150 300 180 166 300 minecraft:snow_block
setblock 179 150 278 minecraft:light[level=12]
setblock 179 150 285 minecraft:light[level=12]
setblock 179 150 292 minecraft:light[level=12]
fill 179 150 298 180 165 298 minecraft:snow_block
fill 179 150 306 180 165 306 minecraft:snow_block
setblock 179 150 313 minecraft:light[level=12]
fill 180 150 299 181 150 299 minecraft:snow_block
fill 180 150 305 180 165 305 minecraft:snow_block
fill 181 150 300 181 152 300 minecraft:packed_ice
setblock 181 150 304 minecraft:snow_block
setblock 181 150 305 minecraft:packed_ice
setblock 182 150 282 minecraft:packed_ice
setblock 182 150 283 minecraft:snow_block
fill 182 150 284 182 153 284 minecraft:packed_ice
setblock 182 150 294 minecraft:packed_ice
setblock 182 150 298 minecraft:snow_block
fill 182 150 299 182 153 299 minecraft:packed_ice
setblock 182 150 303 minecraft:snow_block
fill 182 150 304 182 153 304 minecraft:packed_ice
setblock 182 150 317 minecraft:white_concrete
setblock 141 151 303 minecraft:light_blue_concrete
setblock 141 151 309 minecraft:white_concrete
fill 141 151 310 141 165 311 minecraft:blue_ice
setblock 141 151 316 minecraft:white_concrete
fill 141 151 317 141 165 317 minecraft:blue_ice
setblock 142 151 277 minecraft:snow_block
fill 142 151 278 142 154 278 minecraft:packed_ice
setblock 142 151 282 minecraft:snow_block
fill 142 151 283 142 154 283 minecraft:packed_ice
setblock 142 151 287 minecraft:snow_block
fill 142 151 288 142 154 288 minecraft:packed_ice
fill 142 151 294 142 152 295 minecraft:blue_ice
setblock 142 151 297 minecraft:snow_block
fill 142 151 298 142 152 298 minecraft:packed_ice
setblock 142 151 302 minecraft:snow_block
fill 142 151 303 142 154 303 minecraft:packed_ice
setblock 143 151 276 minecraft:snow_block
setblock 143 151 280 minecraft:packed_ice
setblock 143 151 281 minecraft:snow_block
fill 143 151 282 143 154 282 minecraft:packed_ice
setblock 143 151 286 minecraft:snow_block
fill 143 151 287 143 154 287 minecraft:packed_ice
fill 143 151 297 144 151 297 minecraft:blue_ice
fill 143 151 299 144 151 299 minecraft:blue_ice
fill 144 151 276 144 154 276 minecraft:packed_ice
setblock 144 151 280 minecraft:snow_block
fill 144 151 281 144 154 281 minecraft:packed_ice
fill 144 151 298 146 151 298 minecraft:blue_ice
fill 145 151 294 145 153 294 minecraft:blue_ice
setblock 146 151 278 minecraft:snow_block
setblock 147 151 277 minecraft:snow_block
fill 147 151 278 147 154 278 minecraft:packed_ice
setblock 148 151 276 minecraft:snow_block
fill 148 151 277 148 154 277 minecraft:packed_ice
setblock 148 151 316 minecraft:snow_block
fill 149 151 276 152 151 276 minecraft:packed_ice
setblock 149 151 279 minecraft:packed_ice
fill 149 151 316 152 151 316 minecraft:packed_ice
setblock 150 151 279 minecraft:snow_block
setblock 151 151 278 minecraft:snow_block
setblock 151 151 279 minecraft:packed_ice
setblock 152 151 277 minecraft:snow_block
fill 152 151 278 152 152 278 minecraft:packed_ice
setblock 153 151 276 minecraft:snow_block
fill 153 151 277 156 151 277 minecraft:packed_ice
setblock 153 151 316 minecraft:snow_block
fill 154 151 276 154 154 276 minecraft:packed_ice
setblock 154 151 316 minecraft:packed_ice
setblock 158 151 276 minecraft:snow_block
setblock 159 151 276 minecraft:packed_ice
setblock 163 151 276 minecraft:snow_block
setblock 163 151 316 minecraft:snow_block
fill 164 151 276 164 154 276 minecraft:packed_ice
fill 164 151 316 164 154 316 minecraft:packed_ice
setblock 167 151 277 minecraft:snow_block
setblock 168 151 276 minecraft:snow_block
fill 168 151 277 168 152 277 minecraft:packed_ice
setblock 168 151 316 minecraft:snow_block
fill 169 151 276 169 153 276 minecraft:packed_ice
setblock 169 151 315 minecraft:snow_block
fill 169 151 316 169 154 316 minecraft:packed_ice
fill 170 151 299 170 164 305 minecraft:snow_block
setblock 170 151 315 minecraft:packed_ice
fill 171 151 298 171 164 298 minecraft:snow_block
fill 171 151 306 171 164 306 minecraft:snow_block
fill 172 151 297 172 164 297 minecraft:snow_block
fill 173 151 275 173 166 275 minecraft:blue_ice
setblock 173 151 276 minecraft:snow_block
fill 173 151 296 179 164 296 minecraft:snow_block
fill 173 151 308 179 164 308 minecraft:snow_block
setblock 173 151 316 minecraft:snow_block
fill 180 151 297 180 164 297 minecraft:snow_block
fill 180 151 299 180 165 299 minecraft:snow_block
fill 180 151 307 180 164 307 minecraft:snow_block
fill 181 151 298 181 159 298 minecraft:snow_block
setblock 181 151 299 minecraft:packed_ice
setblock 181 151 303 minecraft:snow_block
fill 181 151 304 181 154 304 minecraft:packed_ice
fill 181 151 305 181 154 306 minecraft:snow_block
setblock 182 151 282 minecraft:snow_block
fill 182 151 283 182 154 283 minecraft:packed_ice
fill 182 151 285 182 152 285 minecraft:packed_ice
setblock 182 151 297 minecraft:snow_block
fill 182 151 298 182 154 298 minecraft:packed_ice
setblock 182 151 302 minecraft:snow_block
fill 182 151 303 182 154 303 minecraft:packed_ice
setblock 182 151 307 minecraft:snow_block
fill 182 151 317 182 156 317 minecraft:blue_ice
fill 183 151 282 183 163 283 minecraft:blue_ice
setblock 183 151 284 minecraft:light_blue_concrete
fill 141 152 303 141 163 303 minecraft:blue_ice
fill 141 152 309 141 162 309 minecraft:blue_ice
setblock 141 152 315 minecraft:white_concrete
fill 141 152 316 141 167 316 minecraft:blue_ice
fill 142 152 277 142 155 277 minecraft:packed_ice
setblock 142 152 281 minecraft:snow_block
fill 142 152 282 142 155 282 minecraft:packed_ice
setblock 142 152 285 minecraft:packed_ice
setblock 142 152 286 minecraft:snow_block
fill 142 152 287 142 155 287 minecraft:packed_ice
setblock 142 152 290 minecraft:packed_ice
fill 142 152 296 142 152 297 minecraft:blue_ice
setblock 142 152 301 minecraft:snow_block
fill 142 152 302 142 155 302 minecraft:packed_ice
fill 143 152 276 143 155 276 minecraft:packed_ice
setblock 143 152 279 minecraft:packed_ice
setblock 143 152 280 minecraft:snow_block
fill 143 152 281 143 155 281 minecraft:packed_ice
setblock 143 152 285 minecraft:snow_block
fill 143 152 286 143 155 286 minecraft:packed_ice
setblock 143 152 297 minecraft:blue_ice
setblock 143 152 299 minecraft:blue_ice
setblock 144 152 278 minecraft:light[level=15]
fill 144 152 280 144 155 280 minecraft:packed_ice
setblock 144 152 284 minecraft:snow_block
fill 144 152 285 144 155 285 minecraft:packed_ice
setblock 144 152 286 minecraft:light[level=15]
fill 144 152 298 145 152 298 minecraft:blue_ice
setblock 144 152 302 minecraft:light[level=15]
setblock 144 152 310 minecraft:light[level=15]
fill 145 152 293 145 153 293 minecraft:blue_ice
fill 145 152 295 145 153 295 minecraft:blue_ice
setblock 146 152 277 minecraft:snow_block
fill 146 152 278 146 155 278 minecraft:packed_ice
setblock 147 152 276 minecraft:snow_block
fill 147 152 277 147 155 277 minecraft:packed_ice
fill 148 152 276 151 152 276 minecraft:packed_ice
fill 148 152 316 151 152 316 minecraft:packed_ice
setblock 149 152 279 minecraft:snow_block
setblock 150 152 278 minecraft:snow_block
setblock 150 152 279 minecraft:packed_ice
setblock 151 152 277 minecraft:snow_block
fill 151 152 278 151 153 278 minecraft:packed_ice
setblock 152 152 276 minecraft:snow_block
fill 152 152 277 155 152 277 minecraft:packed_ice
setblock 152 152 286 minecraft:light[level=15]
setblock 152 152 294 minecraft:light[level=15]
setblock 152 152 310 minecraft:light[level=15]
setblock 152 152 316 minecraft:snow_block
fill 153 152 276 153 155 276 minecraft:packed_ice
setblock 157 152 276 minecraft:snow_block
setblock 158 152 276 minecraft:packed_ice
setblock 160 152 278 minecraft:light[level=15]
setblock 160 152 286 minecraft:light[level=15]
setblock 160 152 294 minecraft:light[level=15]
setblock 160 152 302 minecraft:light[level=15]
setblock 160 152 310 minecraft:light[level=15]
setblock 162 152 276 minecraft:snow_block
fill 163 152 276 163 153 276 minecraft:packed_ice
fill 163 152 316 163 155 316 minecraft:packed_ice
setblock 166 152 277 minecraft:snow_block
setblock 167 152 276 minecraft:snow_block
setblock 167 152 277 minecraft:packed_ice
setblock 167 152 316 minecraft:snow_block
fill 168 152 276 168 154 276 minecraft:packed_ice
setblock 168 152 278 minecraft:light[level=15]
setblock 168 152 286 minecraft:light[level=15]
setblock 168 152 294 minecraft:light[level=15]
setblock 168 152 302 minecraft:light[level=15]
setblock 168 152 310 minecraft:light[level=15]
setblock 168 152 315 minecraft:snow_block
fill 168 152 316 168 155 316 minecraft:packed_ice
fill 169 152 300 169 163 304 minecraft:snow_block
setblock 169 152 315 minecraft:packed_ice
fill 170 152 298 170 163 298 minecraft:snow_block
fill 170 152 306 170 163 306 minecraft:snow_block
fill 171 152 297 171 163 297 minecraft:snow_block
fill 171 152 307 171 163 307 minecraft:snow_block
fill 172 152 296 172 163 296 minecraft:snow_block
fill 172 152 308 172 163 308 minecraft:snow_block
setblock 172 152 316 minecraft:snow_block
fill 174 152 295 178 163 295 minecraft:snow_block
fill 174 152 309 178 163 309 minecraft:snow_block
setblock 176 152 278 minecraft:light[level=15]
setblock 176 152 286 minecraft:light[level=15]
setblock 176 152 294 minecraft:light[level=15]
fill 180 152 296 180 161 296 minecraft:snow_block
fill 180 152 308 180 163 308 minecraft:snow_block
fill 181 152 297 181 158 297 minecraft:snow_block
fill 181 152 299 181 160 299 minecraft:snow_block
setblock 181 152 302 minecraft:snow_block
fill 181 152 303 181 155 303 minecraft:packed_ice
fill 181 152 307 181 155 307 minecraft:snow_block
setblock 182 152 281 minecraft:snow_block
fill 182 152 282 182 155 282 minecraft:packed_ice
setblock 182 152 286 minecraft:snow_block
fill 182 152 287 182 155 287 minecraft:packed_ice
setblock 182 152 296 minecraft:snow_block
fill 182 152 297 182 155 297 minecraft:packed_ice
setblock 182 152 301 minecraft:snow_block
fill 182 152 302 182 155 302 minecraft:packed_ice
setblock 182 152 306 minecraft:snow_block
fill 182 152 307 182 155 307 minecraft:packed_ice
fill 183 152 284 183 165 284 minecraft:blue_ice
fill 141 153 315 141 165 315 minecraft:blue_ice
setblock 142 153 280 minecraft:snow_block
fill 142 153 281 142 156 281 minecraft:packed_ice
setblock 142 153 285 minecraft:snow_block
fill 142 153 286 142 156 286 minecraft:packed_ice
setblock 142 153 290 minecraft:snow_block
setblock 142 153 294 minecraft:blue_ice
setblock 142 153 298 minecraft:blue_ice
setblock 142 153 300 minecraft:snow_block
fill 142 153 301 142 156 301 minecraft:packed_ice
setblock 142 153 305 minecraft:snow_block
setblock 143 153 279 minecraft:snow_block
fill 143 153 280 143 156 280 minecraft:packed_ice
setblock 143 153 284 minecraft:snow_block
fill 143 153 285 143 156 285 minecraft:packed_ice
setblock 143 153 288 minecraft:packed_ice
setblock 144 153 283 minecraft:snow_block
fill 144 153 284 144 156 284 minecraft:packed_ice
fill 144 153 286 144 154 286 minecraft:packed_ice
setblock 145 153 277 minecraft:snow_block
setblock 146 153 276 minecraft:snow_block
fill 146 153 277 146 156 277 minecraft:packed_ice
fill 146 153 294 146 154 294 minecraft:blue_ice
fill 147 153 276 150 153 276 minecraft:packed_ice
setblock 149 153 278 minecraft:snow_block
setblock 149 153 316 minecraft:packed_ice
setblock 150 153 277 minecraft:snow_block
setblock 150 153 278 minecraft:packed_ice
setblock 151 153 276 minecraft:snow_block
fill 151 153 277 153 153 277 minecraft:packed_ice
fill 152 153 276 152 156 276 minecraft:packed_ice
setblock 166 153 276 minecraft:snow_block
setblock 166 153 316 minecraft:snow_block
fill 167 153 276 167 155 276 minecraft:packed_ice
fill 167 153 316 167 156 316 minecraft:packed_ice
fill 168 153 299 168 153 301 minecraft:packed_ice
fill 168 153 302 168 162 302 minecraft:snow_block
fill 168 153 303 168 153 305 minecraft:packed_ice
fill 169 153 299 169 162 299 minecraft:snow_block
fill 169 153 305 169 162 305 minecraft:snow_block
fill 170 153 297 170 162 297 minecraft:snow_block
fill 170 153 307 170 162 307 minecraft:snow_block
fill 171 153 296 171 162 296 minecraft:snow_block
fill 171 153 308 171 162 308 minecraft:snow_block
setblock 171 153 316 minecraft:snow_block
fill 173 153 295 173 162 295 minecraft:snow_block
fill 173 153 309 173 162 309 minecraft:snow_block
fill 176 153 294 176 162 294 minecraft:snow_block
fill 179 153 295 179 162 295 minecraft:snow_block
fill 179 153 309 179 162 309 minecraft:snow_block
fill 181 153 296 181 158 296 minecraft:snow_block
fill 181 153 300 181 158 301 minecraft:snow_block
fill 181 153 302 181 154 302 minecraft:packed_ice
fill 181 153 308 181 156 308 minecraft:snow_block
setblock 182 153 280 minecraft:snow_block
fill 182 153 281 182 156 281 minecraft:packed_ice
setblock 182 153 285 minecraft:snow_block
fill 182 153 286 182 156 286 minecraft:packed_ice
fill 182 153 288 182 153 289 minecraft:packed_ice
setblock 182 153 300 minecraft:snow_block
fill 182 153 301 182 156 301 minecraft:packed_ice
setblock 182 153 305 minecraft:snow_block
fill 182 153 306 182 156 306 minecraft:packed_ice
fill 182 153 308 182 154 308 minecraft:packed_ice
setblock 141 154 299 minecraft:light_blue_concrete
setblock 142 154 279 minecraft:snow_block
fill 142 154 280 142 157 280 minecraft:packed_ice
setblock 142 154 284 minecraft:snow_block
fill 142 154 285 142 157 285 minecraft:packed_ice
setblock 142 154 289 minecraft:snow_block
fill 142 154 290 142 156 291 minecraft:packed_ice
setblock 142 154 304 minecraft:snow_block
fill 142 154 305 142 156 306 minecraft:packed_ice
setblock 143 154 278 minecraft:snow_block
fill 143 154 279 143 157 279 minecraft:packed_ice
setblock 143 154 283 minecraft:snow_block
fill 143 154 284 143 157 284 minecraft:packed_ice
setblock 143 154 288 minecraft:snow_block
fill 143 154 289 143 157 289 minecraft:packed_ice
setblock 144 154 277 minecraft:snow_block
setblock 144 154 282 minecraft:snow_block
fill 144 154 283 145 156 283 minecraft:packed_ice
setblock 144 154 287 minecraft:snow_block
setblock 145 154 276 minecraft:snow_block
fill 145 154 277 145 157 277 minecraft:packed_ice
fill 145 154 282 145 157 282 minecraft:packed_ice
fill 145 154 284 145 155 284 minecraft:packed_ice
fill 146 154 276 149 154 276 minecraft:packed_ice
setblock 148 154 278 minecraft:snow_block
setblock 149 154 277 minecraft:snow_block
setblock 149 154 278 minecraft:packed_ice
setblock 150 154 276 minecraft:snow_block
fill 150 154 277 152 154 277 minecraft:packed_ice
fill 151 154 276 151 157 276 minecraft:packed_ice
setblock 165 154 276 minecraft:snow_block
fill 165 154 281 165 155 281 minecraft:packed_ice
setblock 165 154 316 minecraft:snow_block
fill 166 154 276 166 157 276 minecraft:packed_ice
fill 166 154 280 166 155 280 minecraft:packed_ice
fill 166 154 282 166 155 282 minecraft:packed_ice
fill 166 154 316 166 157 316 minecraft:packed_ice
fill 167 154 281 167 155 281 minecraft:packed_ice
setblock 168 154 299 minecraft:packed_ice
fill 168 154 300 168 161 301 minecraft:snow_block
fill 168 154 303 168 161 304 minecraft:snow_block
setblock 168 154 305 minecraft:packed_ice
fill 169 154 298 169 161 298 minecraft:snow_block
fill 169 154 306 169 161 306 minecraft:snow_block
setblock 170 154 316 minecraft:snow_block
fill 172 154 295 172 161 295 minecraft:snow_block
fill 172 154 309 172 161 309 minecraft:snow_block
fill 174 154 294 175 161 294 minecraft:snow_block
fill 174 154 310 175 161 310 minecraft:snow_block
fill 177 154 294 178 161 294 minecraft:snow_block
fill 178 154 310 178 161 310 minecraft:snow_block
fill 180 154 295 180 160 295 minecraft:snow_block
fill 180 154 309 180 161 309 minecraft:snow_block
fill 182 154 280 182 157 280 minecraft:packed_ice
setblock 182 154 284 minecraft:snow_block
fill 182 154 285 182 157 285 minecraft:packed_ice
setblock 182 154 288 minecraft:packed_ice
setblock 182 154 289 minecraft:snow_block
fill 182 154 290 182 156 291 minecraft:packed_ice
setblock 182 154 299 minecraft:snow_block
fill 182 154 300 182 157 300 minecraft:packed_ice
setblock 182 154 304 minecraft:snow_block
fill 182 154 305 182 157 305 minecraft:packed_ice
setblock 183 154 290 minecraft:white_concrete
fill 183 154 307 183 162 308 minecraft:blue_ice
setblock 183 154 309 minecraft:light_blue_concrete
setblock 141 155 287 minecraft:light_blue_concrete
fill 141 155 299 141 166 299 minecraft:blue_ice
setblock 142 155 278 minecraft:snow_block
fill 142 155 279 142 158 279 minecraft:packed_ice
setblock 142 155 283 minecraft:snow_block
fill 142 155 284 142 158 284 minecraft:packed_ice
setblock 142 155 288 minecraft:snow_block
fill 142 155 289 142 158 289 minecraft:packed_ice
setblock 142 155 292 minecraft:packed_ice
setblock 142 155 303 minecraft:snow_block
fill 142 155 304 142 158 304 minecraft:packed_ice
setblock 142 155 307 minecraft:packed_ice
fill 143 155 278 143 158 278 minecraft:packed_ice
setblock 143 155 282 minecraft:snow_block
fill 143 155 283 143 158 283 minecraft:packed_ice
setblock 143 155 287 minecraft:snow_block
fill 143 155 288 144 157 288 minecraft:packed_ice
fill 143 155 290 143 156 290 minecraft:packed_ice
setblock 144 155 276 minecraft:snow_block
fill 144 155 277 144 158 277 minecraft:packed_ice
setblock 144 155 281 minecraft:snow_block
fill 144 155 282 144 158 282 minecraft:packed_ice
setblock 144 155 286 minecraft:snow_block
fill 144 155 287 144 158 287 minecraft:packed_ice
fill 145 155 276 148 155 276 minecraft:packed_ice
setblock 145 155 285 minecraft:snow_block
setblock 147 155 278 minecraft:snow_block
setblock 148 155 277 minecraft:snow_block
setblock 148 155 278 minecraft:packed_ice
setblock 148 155 316 minecraft:packed_ice
setblock 149 155 276 minecraft:snow_block
fill 149 155 277 151 155 277 minecraft:packed_ice
fill 150 155 276 150 158 276 minecraft:packed_ice
fill 162 155 316 162 156 316 minecraft:packed_ice
setblock 164 155 276 minecraft:snow_block
setblock 164 155 316 minecraft:snow_block
fill 165 155 276 165 158 276 minecraft:packed_ice
fill 165 155 316 165 158 316 minecraft:packed_ice
fill 166 155 315 166 158 315 minecraft:packed_ice
fill 168 155 299 168 160 299 minecraft:snow_block
fill 168 155 305 168 160 305 minecraft:snow_block
fill 169 155 297 169 160 297 minecraft:snow_block
fill 169 155 307 169 160 307 minecraft:snow_block
setblock 169 155 316 minecraft:snow_block
fill 170 155 296 170 160 296 minecraft:snow_block
fill 170 155 308 170 160 308 minecraft:snow_block
fill 171 155 295 171 160 295 minecraft:snow_block
fill 171 155 309 171 160 309 minecraft:snow_block
fill 173 155 294 173 160 294 minecraft:snow_block
fill 173 155 310 173 160 310 minecraft:snow_block
fill 179 155 294 179 160 294 minecraft:snow_block
fill 179 155 310 179 160 310 minecraft:snow_block
fill 181 155 285 181 157 286 minecraft:packed_ice
fill 181 155 295 181 159 295 minecraft:snow_block
setblock 181 155 302 minecraft:snow_block
setblock 181 155 304 minecraft:snow_block
fill 181 155 305 181 158 305 minecraft:packed_ice
setblock 181 155 306 minecraft:snow_block
fill 181 155 309 181 157 309 minecraft:snow_block
setblock 182 155 283 minecraft:snow_block
fill 182 155 284 182 158 284 minecraft:packed_ice
setblock 182 155 288 minecraft:snow_block
fill 182 155 289 182 158 289 minecraft:packed_ice
setblock 182 155 292 minecraft:packed_ice
setblock 182 155 293 minecraft:snow_block
fill 182 155 294 182 156 296 minecraft:packed_ice
setblock 182 155 298 minecraft:snow_block
fill 182 155 299 182 158 299 minecraft:packed_ice
setblock 182 155 303 minecraft:snow_block
fill 182 155 304 182 158 304 minecraft:packed_ice
setblock 182 155 308 minecraft:snow_block
fill 182 155 309 182 158 309 minecraft:packed_ice
fill 183 155 290 183 165 290 minecraft:blue_ice
fill 183 155 309 183 165 309 minecraft:blue_ice
fill 141 156 287 141 161 287 minecraft:blue_ice
setblock 142 156 276 minecraft:packed_ice
setblock 142 156 277 minecraft:snow_block
fill 142 156 278 142 159 278 minecraft:packed_ice
setblock 142 156 282 minecraft:snow_block
fill 142 156 283 142 159 283 minecraft:packed_ice
setblock 142 156 287 minecraft:snow_block
fill 142 156 288 142 159 288 minecraft:packed_ice
setblock 142 156 292 minecraft:snow_block
fill 142 156 293 142 159 293 minecraft:packed_ice
setblock 142 156 302 minecraft:snow_block
fill 142 156 303 142 159 303 minecraft:packed_ice
setblock 142 156 307 minecraft:snow_block
fill 142 156 308 142 158 309 minecraft:packed_ice
setblock 143 156 276 minecraft:snow_block
setblock 143 156 281 minecraft:snow_block
fill 143 156 282 143 159 282 minecraft:packed_ice
setblock 143 156 286 minecraft:snow_block
fill 143 156 287 143 159 287 minecraft:packed_ice
setblock 143 156 291 minecraft:snow_block
fill 143 156 314 143 158 314 minecraft:snow_block
fill 144 156 276 147 156 276 minecraft:packed_ice
setblock 144 156 278 minecraft:light[level=12]
setblock 144 156 279 minecraft:packed_ice
setblock 144 156 280 minecraft:snow_block
fill 144 156 281 144 159 281 minecraft:packed_ice
setblock 144 156 285 minecraft:snow_block
fill 144 156 286 145 158 286 minecraft:packed_ice
setblock 144 156 289 minecraft:packed_ice
setblock 144 156 292 minecraft:light[level=12]
setblock 144 156 299 minecraft:light[level=12]
setblock 144 156 306 minecraft:light[level=12]
fill 144 156 313 144 158 313 minecraft:snow_block
fill 144 156 315 144 158 315 minecraft:snow_block
setblock 145 156 284 minecraft:snow_block
fill 145 156 285 145 159 285 minecraft:packed_ice
fill 145 156 287 145 157 287 minecraft:packed_ice
fill 145 156 314 145 158 314 minecraft:snow_block
setblock 146 156 278 minecraft:snow_block
fill 146 156 316 147 156 316 minecraft:packed_ice
setblock 147 156 277 minecraft:snow_block
setblock 147 156 278 minecraft:packed_ice
setblock 148 156 276 minecraft:snow_block
fill 148 156 277 150 157 277 minecraft:packed_ice
setblock 148 156 316 minecraft:snow_block
fill 149 156 276 149 159 276 minecraft:packed_ice
fill 149 156 316 150 158 316 minecraft:packed_ice
setblock 151 156 278 minecraft:light[level=12]
setblock 151 156 285 minecraft:light[level=12]
setblock 151 156 292 minecraft:light[level=12]
setblock 151 156 299 minecraft:light[level=12]
setblock 151 156 306 minecraft:light[level=12]
setblock 151 156 313 minecraft:light[level=12]
fill 157 156 311 157 162 311 minecraft:packed_ice
setblock 158 156 278 minecraft:light[level=12]
setblock 158 156 285 minecraft:light[level=12]
setblock 158 156 299 minecraft:light[level=12]
setblock 158 156 306 minecraft:light[level=12]
setblock 158 156 313 minecraft:light[level=12]
fill 161 156 316 161 157 316 minecraft:packed_ice
setblock 163 156 316 minecraft:snow_block
fill 164 156 276 164 159 276 minecraft:packed_ice
setblock 164 156 315 minecraft:snow_block
fill 164 156 316 164 159 316 minecraft:packed_ice
setblock 165 156 278 minecraft:light[level=12]
setblock 165 156 285 minecraft:light[level=12]
setblock 165 156 292 minecraft:light[level=12]
setblock 165 156 299 minecraft:light[level=12]
setblock 165 156 306 minecraft:light[level=12]
setblock 165 156 313 minecraft:light[level=12]
fill 165 156 315 165 159 315 minecraft:packed_ice
fill 167 156 315 167 157 315 minecraft:packed_ice
setblock 168 156 316 minecraft:snow_block
fill 169 156 316 169 159 316 minecraft:packed_ice
setblock 172 156 278 minecraft:light[level=12]
setblock 172 156 285 minecraft:light[level=12]
setblock 172 156 292 minecraft:light[level=12]
setblock 172 156 313 minecraft:light[level=12]
setblock 179 156 278 minecraft:light[level=12]
setblock 179 156 285 minecraft:light[level=12]
setblock 179 156 292 minecraft:light[level=12]
setblock 179 156 313 minecraft:light[level=12]
setblock 181 156 283 minecraft:snow_block
fill 181 156 284 181 159 284 minecraft:packed_ice
setblock 181 156 287 minecraft:packed_ice
setblock 181 156 288 minecraft:snow_block
fill 181 156 289 181 159 289 minecraft:packed_ice
setblock 181 156 302 minecraft:packed_ice
setblock 181 156 303 minecraft:snow_block
fill 181 156 304 181 159 304 minecraft:packed_ice
fill 181 156 306 181 156 307 minecraft:packed_ice
fill 182 156 279 182 158 279 minecraft:packed_ice
setblock 182 156 282 minecraft:snow_block
fill 182 156 283 182 159 283 minecraft:packed_ice
setblock 182 156 287 minecraft:snow_block
fill 182 156 288 182 159 288 minecraft:packed_ice
setblock 182 156 292 minecraft:snow_block
fill 182 156 293 182 159 293 minecraft:packed_ice
setblock 182 156 297 minecraft:snow_block
fill 182 156 298 182 159 298 minecraft:packed_ice
setblock 182 156 302 minecraft:snow_block
fill 182 156 303 182 159 303 minecraft:packed_ice
setblock 182 156 307 minecraft:snow_block
fill 182 156 308 182 159 308 minecraft:packed_ice
fill 182 156 310 182 157 310 minecraft:packed_ice
setblock 141 157 304 minecraft:light_blue_concrete
setblock 142 157 276 minecraft:snow_block
fill 142 157 277 143 159 277 minecraft:packed_ice
setblock 142 157 281 minecraft:snow_block
fill 142 157 282 142 160 282 minecraft:packed_ice
setblock 142 157 286 minecraft:snow_block
fill 142 157 287 142 160 287 minecraft:packed_ice
setblock 142 157 290 minecraft:packed_ice
setblock 142 157 291 minecraft:snow_block
fill 142 157 292 143 159 292 minecraft:packed_ice
fill 142 157 294 142 157 295 minecraft:packed_ice
setblock 142 157 301 minecraft:snow_block
fill 142 157 302 142 160 302 minecraft:packed_ice
setblock 142 157 305 minecraft:packed_ice
setblock 142 157 306 minecraft:snow_block
fill 142 157 307 143 159 307 minecraft:packed_ice
setblock 142 157 310 minecraft:packed_ice
setblock 142 157 311 minecraft:snow_block
fill 142 157 312 142 160 312 minecraft:packed_ice
fill 143 157 276 146 157 276 minecraft:packed_ice
setblock 143 157 280 minecraft:snow_block
fill 143 157 281 143 160 281 minecraft:packed_ice
setblock 143 157 285 minecraft:snow_block
fill 143 157 286 143 160 286 minecraft:packed_ice
setblock 143 157 290 minecraft:snow_block
fill 143 157 291 143 160 291 minecraft:packed_ice
setblock 143 157 305 minecraft:snow_block
fill 143 157 306 143 160 306 minecraft:packed_ice
fill 143 157 308 143 157 309 minecraft:packed_ice
setblock 144 157 279 minecraft:snow_block
fill 144 157 280 144 160 280 minecraft:packed_ice
setblock 144 157 283 minecraft:packed_ice
setblock 144 157 284 minecraft:snow_block
fill 144 157 285 144 160 285 minecraft:packed_ice
setblock 144 157 289 minecraft:snow_block
fill 144 157 290 144 160 290 minecraft:packed_ice
fill 144 157 316 146 157 316 minecraft:packed_ice
fill 145 157 281 145 158 281 minecraft:packed_ice
setblock 145 157 283 minecraft:snow_block
fill 145 157 284 145 160 284 minecraft:packed_ice
setblock 145 157 288 minecraft:snow_block
setblock 146 157 277 minecraft:snow_block
fill 146 157 278 146 160 278 minecraft:packed_ice
setblock 147 157 276 minecraft:snow_block
fill 147 157 277 147 160 277 minecraft:packed_ice
setblock 147 157 316 minecraft:snow_block
fill 148 157 276 148 160 276 minecraft:packed_ice
fill 148 157 316 148 160 316 minecraft:packed_ice
setblock 151 157 316 minecraft:packed_ice
setblock 152 157 276 minecraft:snow_block
fill 159 157 316 160 158 316 minecraft:packed_ice
setblock 162 157 315 minecraft:packed_ice
setblock 162 157 316 minecraft:snow_block
fill 163 157 276 163 160 276 minecraft:packed_ice
setblock 163 157 315 minecraft:snow_block
fill 163 157 316 163 160 316 minecraft:packed_ice
fill 164 157 315 164 160 315 minecraft:packed_ice
setblock 167 157 316 minecraft:snow_block
fill 168 157 298 168 158 298 minecraft:snow_block
fill 168 157 306 168 158 306 minecraft:snow_block
setblock 168 157 315 minecraft:snow_block
fill 168 157 316 168 160 316 minecraft:packed_ice
fill 172 157 294 172 158 294 minecraft:snow_block
fill 172 157 310 172 158 310 minecraft:snow_block
fill 180 157 294 180 158 294 minecraft:snow_block
fill 180 157 310 180 158 310 minecraft:snow_block
setblock 181 157 282 minecraft:snow_block
fill 181 157 283 181 160 283 minecraft:packed_ice
setblock 181 157 287 minecraft:snow_block
fill 181 157 288 181 160 288 minecraft:packed_ice
fill 181 157 290 181 157 291 minecraft:packed_ice
setblock 181 157 292 minecraft:snow_block
setblock 181 157 302 minecraft:snow_block
fill 181 157 303 181 160 303 minecraft:packed_ice
setblock 181 157 306 minecraft:packed_ice
setblock 181 157 307 minecraft:snow_block
fill 181 157 308 181 160 308 minecraft:packed_ice
setblock 182 157 281 minecraft:snow_block
fill 182 157 282 182 160 282 minecraft:packed_ice
setblock 182 157 286 minecraft:snow_block
fill 182 157 287 182 160 287 minecraft:packed_ice
setblock 182 157 290 minecraft:packed_ice
setblock 182 157 291 minecraft:snow_block
fill 182 157 292 182 160 292 minecraft:packed_ice
fill 182 157 294 182 157 295 minecraft:packed_ice
setblock 182 157 296 minecraft:snow_block
fill 182 157 297 182 160 297 minecraft:packed_ice
setblock 182 157 301 minecraft:snow_block
fill 182 157 302 182 160 302 minecraft:packed_ice
setblock 182 157 306 minecraft:snow_block
fill 182 157 307 182 160 307 minecraft:packed_ice
setblock 182 157 311 minecraft:snow_block
fill 182 157 312 182 160 312 minecraft:packed_ice
setblock 182 157 317 minecraft:white_concrete
fill 141 158 304 141 165 304 minecraft:blue_ice
fill 142 158 276 145 158 276 minecraft:packed_ice
setblock 142 158 280 minecraft:snow_block
fill 142 158 281 142 161 281 minecraft:packed_ice
setblock 142 158 285 minecraft:snow_block
fill 142 158 286 142 161 286 minecraft:packed_ice
setblock 142 158 290 minecraft:snow_block
fill 142 158 291 142 161 291 minecraft:packed_ice
setblock 142 158 294 minecraft:packed_ice
setblock 142 158 295 minecraft:snow_block
fill 142 158 296 142 160 297 minecraft:packed_ice
setblock 142 158 299 minecraft:packed_ice
setblock 142 158 300 minecraft:snow_block
fill 142 158 301 142 161 301 minecraft:packed_ice
setblock 142 158 305 minecraft:snow_block
fill 142 158 306 142 161 306 minecraft:packed_ice
setblock 142 158 310 minecraft:snow_block
fill 142 158 311 143 160 311 minecraft:packed_ice
fill 142 158 313 142 158 314 minecraft:packed_ice
setblock 142 158 315 minecraft:snow_block
setblock 143 158 279 minecraft:snow_block
fill 143 158 280 143 161 280 minecraft:packed_ice
setblock 143 158 284 minecraft:snow_block
fill 143 158 285 143 161 285 minecraft:packed_ice
setblock 143 158 288 minecraft:packed_ice
setblock 143 158 289 minecraft:snow_block
fill 143 158 290 143 161 290 minecraft:packed_ice
setblock 143 158 293 minecraft:packed_ice
setblock 143 158 304 minecraft:snow_block
fill 143 158 305 143 161 305 minecraft:packed_ice
setblock 143 158 308 minecraft:packed_ice
setblock 143 158 309 minecraft:snow_block
fill 143 158 310 143 161 310 minecraft:packed_ice
fill 143 158 312 143 159 312 minecraft:packed_ice
fill 143 158 316 145 158 316 minecraft:packed_ice
fill 144 158 279 144 161 279 minecraft:packed_ice
setblock 144 158 283 minecraft:snow_block
fill 144 158 284 144 161 284 minecraft:packed_ice
setblock 144 158 288 minecraft:snow_block
fill 144 158 289 145 160 289 minecraft:packed_ice
fill 144 158 291 144 159 291 minecraft:packed_ice
setblock 145 158 277 minecraft:snow_block
fill 145 158 278 145 161 278 minecraft:packed_ice
setblock 145 158 282 minecraft:snow_block
fill 145 158 283 145 161 283 minecraft:packed_ice
setblock 145 158 287 minecraft:snow_block
fill 145 158 288 145 161 288 minecraft:packed_ice
setblock 146 158 276 minecraft:snow_block
fill 146 158 277 146 161 277 minecraft:packed_ice
setblock 146 158 315 minecraft:packed_ice
setblock 146 158 316 minecraft:snow_block
fill 147 158 276 147 161 276 minecraft:packed_ice
setblock 147 158 315 minecraft:snow_block
fill 147 158 316 147 161 316 minecraft:packed_ice
fill 148 158 277 149 158 277 minecraft:packed_ice
setblock 151 158 276 minecraft:snow_block
setblock 151 158 316 minecraft:snow_block
fill 152 158 276 152 161 276 minecraft:packed_ice
fill 152 158 316 152 161 316 minecraft:packed_ice
fill 157 158 316 158 160 316 minecraft:packed_ice
fill 160 158 315 161 158 315 minecraft:packed_ice
setblock 161 158 276 minecraft:snow_block
setblock 161 158 316 minecraft:snow_block
fill 162 158 276 162 161 276 minecraft:packed_ice
setblock 162 158 314 minecraft:packed_ice
setblock 162 158 315 minecraft:snow_block
fill 162 158 316 162 161 316 minecraft:packed_ice
setblock 163 158 314 minecraft:snow_block
fill 163 158 315 163 161 315 minecraft:packed_ice
fill 164 158 314 167 158 314 minecraft:packed_ice
setblock 166 158 276 minecraft:snow_block
setblock 166 158 316 minecraft:snow_block
setblock 167 158 315 minecraft:snow_block
fill 167 158 316 167 161 316 minecraft:packed_ice
fill 168 158 315 168 161 315 minecraft:packed_ice
setblock 170 158 316 minecraft:packed_ice
setblock 180 158 286 minecraft:packed_ice
setblock 180 158 287 minecraft:snow_block
fill 180 158 288 180 160 289 minecraft:packed_ice
setblock 181 158 281 minecraft:snow_block
fill 181 158 282 181 161 282 minecraft:packed_ice
setblock 181 158 285 minecraft:packed_ice
setblock 181 158 286 minecraft:snow_block
fill 181 158 287 181 161 287 minecraft:packed_ice
setblock 181 158 290 minecraft:packed_ice
setblock 181 158 291 minecraft:snow_block
fill 181 158 292 181 159 294 minecraft:packed_ice
fill 181 158 302 181 161 302 minecraft:packed_ice
setblock 181 158 306 minecraft:snow_block
fill 181 158 307 181 161 307 minecraft:packed_ice
fill 181 158 309 181 158 310 minecraft:packed_ice
fill 182 158 278 182 159 278 minecraft:packed_ice
setblock 182 158 280 minecraft:snow_block
fill 182 158 281 182 161 281 minecraft:packed_ice
setblock 182 158 285 minecraft:snow_block
fill 182 158 286 182 161 286 minecraft:packed_ice
setblock 182 158 290 minecraft:snow_block
fill 182 158 291 182 161 291 minecraft:packed_ice
setblock 182 158 294 minecraft:packed_ice
setblock 182 158 295 minecraft:snow_block
fill 182 158 296 182 161 296 minecraft:packed_ice
setblock 182 158 300 minecraft:snow_block
fill 182 158 301 182 161 301 minecraft:packed_ice
setblock 182 158 305 minecraft:snow_block
fill 182 158 306 182 161 306 minecraft:packed_ice
setblock 182 158 310 minecraft:snow_block
fill 182 158 311 182 161 311 minecraft:packed_ice
fill 182 158 313 182 159 313 minecraft:packed_ice
fill 182 158 317 182 165 317 minecraft:blue_ice
fill 142 159 276 144 159 276 minecraft:packed_ice
setblock 142 159 279 minecraft:snow_block
fill 142 159 280 142 162 280 minecraft:packed_ice
setblock 142 159 284 minecraft:snow_block
fill 142 159 285 142 162 285 minecraft:packed_ice
setblock 142 159 289 minecraft:snow_block
fill 142 159 290 142 162 290 minecraft:packed_ice
setblock 142 159 294 minecraft:snow_block
fill 142 159 295 142 162 295 minecraft:packed_ice
setblock 142 159 298 minecraft:packed_ice
setblock 142 159 299 minecraft:snow_block
fill 142 159 300 142 162 300 minecraft:packed_ice
setblock 142 159 304 minecraft:snow_block
fill 142 159 305 142 162 305 minecraft:packed_ice
setblock 142 159 308 minecraft:packed_ice
setblock 142 159 309 minecraft:snow_block
fill 142 159 310 142 162 310 minecraft:packed_ice
setblock 142 159 313 minecraft:packed_ice
setblock 142 159 314 minecraft:snow_block
fill 142 159 315 144 159 316 minecraft:packed_ice
setblock 143 159 278 minecraft:snow_block
fill 143 159 279 143 162 279 minecraft:packed_ice
setblock 143 159 283 minecraft:snow_block
fill 143 159 284 143 162 284 minecraft:packed_ice
setblock 143 159 288 minecraft:snow_block
fill 143 159 289 143 162 289 minecraft:packed_ice
setblock 143 159 293 minecraft:snow_block
fill 143 159 294 143 162 294 minecraft:packed_ice
fill 143 159 304 143 161 304 minecraft:packed_ice
setblock 143 159 308 minecraft:snow_block
fill 143 159 309 144 161 309 minecraft:packed_ice
setblock 143 159 313 minecraft:snow_block
fill 143 159 314 143 162 314 minecraft:packed_ice
setblock 144 159 277 minecraft:snow_block
fill 144 159 278 144 162 278 minecraft:packed_ice
setblock 144 159 282 minecraft:snow_block
fill 144 159 283 144 162 283 minecraft:packed_ice
setblock 144 159 286 minecraft:packed_ice
setblock 144 159 287 minecraft:snow_block
fill 144 159 288 144 162 288 minecraft:packed_ice
setblock 144 159 292 minecraft:snow_block
fill 144 159 308 144 162 308 minecraft:packed_ice
fill 144 159 310 144 159 311 minecraft:packed_ice
setblock 145 159 276 minecraft:snow_block
fill 145 159 277 145 162 277 minecraft:packed_ice
setblock 145 159 281 minecraft:snow_block
fill 145 159 282 145 160 282 minecraft:packed_ice
setblock 145 159 286 minecraft:snow_block
fill 145 159 287 145 162 287 minecraft:packed_ice
setblock 145 159 315 minecraft:packed_ice
setblock 145 159 316 minecraft:snow_block
fill 146 159 276 146 162 276 minecraft:packed_ice
setblock 146 159 315 minecraft:snow_block
fill 146 159 316 146 162 316 minecraft:packed_ice
fill 147 159 315 149 160 315 minecraft:packed_ice
setblock 148 159 277 minecraft:packed_ice
setblock 149 159 277 minecraft:snow_block
setblock 149 159 316 minecraft:packed_ice
setblock 150 159 276 minecraft:snow_block
setblock 150 159 316 minecraft:snow_block
fill 151 159 276 151 162 276 minecraft:packed_ice
fill 151 159 316 151 162 316 minecraft:packed_ice
fill 153 159 316 154 159 316 minecraft:packed_ice
setblock 155 159 316 minecraft:snow_block
fill 156 159 316 156 162 316 minecraft:packed_ice
fill 158 159 315 160 159 315 minecraft:packed_ice
setblock 159 159 316 minecraft:packed_ice
setblock 160 159 276 minecraft:snow_block
fill 160 159 314 161 159 314 minecraft:packed_ice
setblock 160 159 316 minecraft:snow_block
fill 161 159 276 161 162 276 minecraft:packed_ice
setblock 161 159 315 minecraft:snow_block
fill 161 159 316 161 162 316 minecraft:packed_ice
setblock 162 159 314 minecraft:snow_block
fill 162 159 315 162 162 315 minecraft:packed_ice
setblock 163 159 313 minecraft:snow_block
fill 163 159 314 166 159 314 minecraft:packed_ice
fill 164 159 313 166 160 313 minecraft:packed_ice
setblock 165 159 276 minecraft:snow_block
setblock 165 159 316 minecraft:snow_block
fill 166 159 276 166 162 276 minecraft:packed_ice
setblock 166 159 315 minecraft:snow_block
fill 166 159 316 166 162 316 minecraft:packed_ice
fill 167 159 298 167 159 299 minecraft:sea_lantern
fill 167 159 305 167 159 306 minecraft:sea_lantern
setblock 167 159 314 minecraft:snow_block
fill 167 159 315 167 162 315 minecraft:packed_ice
fill 168 159 297 168 160 298 minecraft:sea_lantern
fill 168 159 306 168 160 307 minecraft:sea_lantern
fill 169 159 315 169 160 315 minecraft:packed_ice
setblock 170 159 316 minecraft:snow_block
fill 175 159 314 177 162 316 minecraft:blue_ice
fill 180 159 284 180 159 285 minecraft:packed_ice
setblock 180 159 286 minecraft:snow_block
fill 180 159 287 180 162 287 minecraft:packed_ice
setblock 180 159 290 minecraft:packed_ice
setblock 180 159 291 minecraft:snow_block
fill 180 159 292 180 162 292 minecraft:packed_ice
fill 181 159 281 181 162 281 minecraft:packed_ice
setblock 181 159 285 minecraft:snow_block
fill 181 159 286 181 162 286 minecraft:packed_ice
setblock 181 159 290 minecraft:snow_block
fill 181 159 291 181 162 291 minecraft:packed_ice
fill 181 159 296 181 161 297 minecraft:packed_ice
setblock 181 159 300 minecraft:snow_block
fill 181 159 301 181 162 301 minecraft:packed_ice
setblock 181 159 305 minecraft:snow_block
fill 181 159 306 181 162 306 minecraft:packed_ice
setblock 181 159 309 minecraft:packed_ice
setblock 181 159 310 minecraft:snow_block
fill 181 159 311 181 162 311 minecraft:packed_ice
fill 182 159 276 182 160 277 minecraft:packed_ice
setblock 182 159 279 minecraft:snow_block
fill 182 159 280 182 162 280 minecraft:packed_ice
setblock 182 159 284 minecraft:snow_block
fill 182 159 285 182 162 285 minecraft:packed_ice
setblock 182 159 289 minecraft:snow_block
fill 182 159 290 182 162 290 minecraft:packed_ice
setblock 182 159 294 minecraft:snow_block
fill 182 159 295 182 162 295 minecraft:packed_ice
setblock 182 159 299 minecraft:snow_block
fill 182 159 300 182 162 300 minecraft:packed_ice
setblock 182 159 304 minecraft:snow_block
fill 182 159 305 182 162 305 minecraft:packed_ice
setblock 182 159 309 minecraft:snow_block
fill 182 159 310 182 162 310 minecraft:packed_ice
setblock 182 159 314 minecraft:snow_block
fill 182 159 315 182 162 315 minecraft:packed_ice
fill 141 160 278 141 165 281 minecraft:blue_ice
setblock 141 160 282 minecraft:white_concrete
fill 141 160 283 141 165 286 minecraft:blue_ice
fill 142 160 276 142 160 277 minecraft:packed_ice
setblock 142 160 278 minecraft:snow_block
fill 142 160 279 142 163 279 minecraft:packed_ice
setblock 142 160 283 minecraft:snow_block
fill 142 160 284 142 163 284 minecraft:packed_ice
setblock 142 160 288 minecraft:snow_block
fill 142 160 289 142 163 289 minecraft:packed_ice
setblock 142 160 292 minecraft:packed_ice
setblock 142 160 293 minecraft:snow_block
fill 142 160 294 142 163 294 minecraft:packed_ice
setblock 142 160 298 minecraft:snow_block
fill 142 160 299 142 163 299 minecraft:packed_ice
setblock 142 160 303 minecraft:snow_block
fill 142 160 304 142 163 304 minecraft:packed_ice
setblock 142 160 307 minecraft:packed_ice
setblock 142 160 308 minecraft:snow_block
fill 142 160 309 142 163 309 minecraft:packed_ice
setblock 142 160 313 minecraft:snow_block
fill 142 160 314 142 161 316 minecraft:packed_ice
setblock 143 160 276 minecraft:packed_ice
setblock 143 160 277 minecraft:snow_block
fill 143 160 278 143 163 278 minecraft:packed_ice
setblock 143 160 282 minecraft:snow_block
fill 143 160 283 143 163 283 minecraft:packed_ice
setblock 143 160 287 minecraft:snow_block
fill 143 160 288 143 163 288 minecraft:packed_ice
setblock 143 160 292 minecraft:snow_block
fill 143 160 293 144 162 293 minecraft:packed_ice
fill 143 160 295 143 161 295 minecraft:packed_ice
setblock 143 160 307 minecraft:snow_block
fill 143 160 308 143 163 308 minecraft:packed_ice
setblock 143 160 312 minecraft:snow_block
fill 143 160 313 144 162 313 minecraft:packed_ice
fill 143 160 315 143 160 316 minecraft:packed_ice
setblock 144 160 276 minecraft:snow_block
fill 144 160 277 144 163 277 minecraft:packed_ice
setblock 144 160 281 minecraft:snow_block
fill 144 160 282 144 163 282 minecraft:packed_ice
setblock 144 160 286 minecraft:snow_block
fill 144 160 287 144 163 287 minecraft:packed_ice
setblock 144 160 291 minecraft:snow_block
fill 144 160 292 144 163 292 minecraft:packed_ice
setblock 144 160 294 minecraft:light[level=15]
setblock 144 160 302 minecraft:light[level=15]
setblock 144 160 307 minecraft:packed_ice
setblock 144 160 310 minecraft:packed_ice
setblock 144 160 311 minecraft:snow_block
fill 144 160 312 144 163 312 minecraft:packed_ice
setblock 144 160 315 minecraft:packed_ice
setblock 144 160 316 minecraft:snow_block
fill 145 160 276 145 163 276 minecraft:packed_ice
setblock 145 160 285 minecraft:snow_block
fill 145 160 286 145 162 286 minecraft:packed_ice
setblock 145 160 290 minecraft:snow_block
setblock 145 160 314 minecraft:packed_ice
setblock 145 160 315 minecraft:snow_block
fill 145 160 316 145 163 316 minecraft:packed_ice
setblock 146 160 314 minecraft:snow_block
fill 146 160 315 146 163 315 minecraft:packed_ice
setblock 147 160 275 minecraft:white_concrete
setblock 148 160 277 minecraft:snow_block
setblock 149 160 276 minecraft:snow_block
setblock 149 160 277 minecraft:packed_ice
setblock 149 160 316 minecraft:snow_block
fill 150 160 276 150 163 276 minecraft:packed_ice
setblock 150 160 315 minecraft:snow_block
fill 150 160 316 150 163 316 minecraft:packed_ice
fill 151 160 315 151 163 315 minecraft:packed_ice
setblock 152 160 278 minecraft:light[level=15]
setblock 152 160 286 minecraft:light[level=15]
setblock 152 160 294 minecraft:light[level=15]
setblock 152 160 310 minecraft:light[level=15]
setblock 153 160 316 minecraft:packed_ice
setblock 154 160 316 minecraft:snow_block
fill 155 160 316 155 163 316 minecraft:packed_ice
fill 156 160 315 159 160 315 minecraft:packed_ice
setblock 159 160 276 minecraft:snow_block
fill 159 160 314 160 160 314 minecraft:packed_ice
setblock 159 160 316 minecraft:snow_block
fill 160 160 276 160 163 276 minecraft:packed_ice
setblock 160 160 278 minecraft:light[level=15]
setblock 160 160 286 minecraft:light[level=15]
setblock 160 160 294 minecraft:light[level=15]
setblock 160 160 302 minecraft:light[level=15]
setblock 160 160 310 minecraft:light[level=15]
setblock 160 160 315 minecraft:snow_block
fill 160 160 316 160 163 316 minecraft:packed_ice
setblock 161 160 313 minecraft:packed_ice
setblock 161 160 314 minecraft:snow_block
fill 161 160 315 161 163 315 minecraft:packed_ice
setblock 162 160 313 minecraft:snow_block
fill 162 160 314 165 160 314 minecraft:packed_ice
fill 163 160 313 163 163 313 minecraft:packed_ice
setblock 164 160 276 minecraft:snow_block
setblock 164 160 316 minecraft:snow_block
fill 165 160 276 165 163 276 minecraft:packed_ice
setblock 165 160 315 minecraft:snow_block
fill 165 160 316 165 163 316 minecraft:packed_ice
setblock 166 160 314 minecraft:snow_block
fill 166 160 315 166 163 315 minecraft:packed_ice
setblock 167 160 299 minecraft:sea_lantern
setblock 167 160 305 minecraft:sea_lantern
fill 167 160 314 168 161 314 minecraft:packed_ice
setblock 168 160 278 minecraft:light[level=15]
setblock 168 160 286 minecraft:light[level=15]
setblock 168 160 294 minecraft:light[level=15]
setblock 168 160 310 minecraft:light[level=15]
setblock 169 160 316 minecraft:snow_block
fill 170 160 316 170 163 316 minecraft:packed_ice
fill 174 160 315 174 161 315 minecraft:blue_ice
fill 175 160 313 175 161 313 minecraft:blue_ice
setblock 176 160 278 minecraft:light[level=15]
setblock 176 160 286 minecraft:light[level=15]
fill 178 160 315 178 161 315 minecraft:blue_ice
setblock 180 160 284 minecraft:packed_ice
setblock 180 160 285 minecraft:snow_block
fill 180 160 286 180 163 286 minecraft:packed_ice
setblock 180 160 290 minecraft:snow_block
fill 180 160 291 180 163 291 minecraft:packed_ice
fill 180 160 293 181 160 293 minecraft:packed_ice
fill 181 160 276 181 162 276 minecraft:packed_ice
fill 181 160 280 181 163 280 minecraft:packed_ice
setblock 181 160 284 minecraft:snow_block
fill 181 160 285 181 163 285 minecraft:packed_ice
setblock 181 160 289 minecraft:snow_block
fill 181 160 290 181 163 290 minecraft:packed_ice
fill 181 160 292 181 161 292 minecraft:packed_ice
setblock 181 160 294 minecraft:snow_block
fill 181 160 295 181 163 295 minecraft:packed_ice
setblock 181 160 298 minecraft:packed_ice
fill 181 160 300 181 163 300 minecraft:packed_ice
setblock 181 160 304 minecraft:snow_block
fill 181 160 305 181 163 305 minecraft:packed_ice
setblock 181 160 309 minecraft:snow_block
fill 181 160 310 181 163 310 minecraft:packed_ice
fill 181 160 312 181 160 313 minecraft:packed_ice
fill 181 160 316 182 161 316 minecraft:packed_ice
setblock 182 160 278 minecraft:snow_block
fill 182 160 279 182 163 279 minecraft:packed_ice
setblock 182 160 283 minecraft:snow_block
fill 182 160 284 182 163 284 minecraft:packed_ice
setblock 182 160 288 minecraft:snow_block
fill 182 160 289 182 163 289 minecraft:packed_ice
setblock 182 160 293 minecraft:snow_block
fill 182 160 294 182 163 294 minecraft:packed_ice
setblock 182 160 298 minecraft:snow_block
fill 182 160 299 182 163 299 minecraft:packed_ice
setblock 182 160 303 minecraft:snow_block
fill 182 160 304 182 163 304 minecraft:packed_ice
setblock 182 160 308 minecraft:snow_block
fill 182 160 309 182 163 309 minecraft:packed_ice
setblock 182 160 313 minecraft:snow_block
fill 182 160 314 182 163 314 minecraft:packed_ice
fill 141 161 282 141 165 282 minecraft:blue_ice
setblock 142 161 276 minecraft:packed_ice
setblock 142 161 277 minecraft:snow_block
fill 142 161 278 142 164 278 minecraft:packed_ice
setblock 142 161 282 minecraft:snow_block
fill 142 161 283 142 164 283 minecraft:packed_ice
setblock 142 161 287 minecraft:snow_block
fill 142 161 288 142 164 288 minecraft:packed_ice
setblock 142 161 292 minecraft:snow_block
fill 142 161 293 142 164 293 minecraft:packed_ice
setblock 142 161 296 minecraft:packed_ice
setblock 142 161 297 minecraft:snow_block
fill 142 161 298 142 164 298 minecraft:packed_ice
setblock 142 161 302 minecraft:snow_block
fill 142 161 303 142 163 303 minecraft:packed_ice
setblock 142 161 307 minecraft:snow_block
fill 142 161 308 142 164 308 minecraft:packed_ice
setblock 142 161 311 minecraft:packed_ice
setblock 142 161 312 minecraft:snow_block
fill 142 161 313 142 164 313 minecraft:packed_ice
setblock 143 161 276 minecraft:snow_block
fill 143 161 277 143 164 277 minecraft:packed_ice
setblock 143 161 281 minecraft:snow_block
fill 143 161 282 143 164 282 minecraft:packed_ice
setblock 143 161 286 minecraft:snow_block
fill 143 161 287 143 164 287 minecraft:packed_ice
setblock 143 161 291 minecraft:snow_block
fill 143 161 292 143 164 292 minecraft:packed_ice
setblock 143 161 296 minecraft:snow_block
setblock 143 161 306 minecraft:snow_block
fill 143 161 307 143 164 307 minecraft:packed_ice
setblock 143 161 311 minecraft:snow_block
fill 143 161 312 143 164 312 minecraft:packed_ice
setblock 143 161 315 minecraft:packed_ice
setblock 143 161 316 minecraft:snow_block
fill 144 161 276 144 164 276 minecraft:packed_ice
setblock 144 161 280 minecraft:snow_block
fill 144 161 281 144 163 281 minecraft:packed_ice
setblock 144 161 285 minecraft:snow_block
fill 144 161 286 144 164 286 minecraft:packed_ice
setblock 144 161 289 minecraft:packed_ice
setblock 144 161 290 minecraft:snow_block
fill 144 161 291 144 164 291 minecraft:packed_ice
setblock 144 161 310 minecraft:snow_block
fill 144 161 311 144 164 311 minecraft:packed_ice
setblock 144 161 314 minecraft:packed_ice
setblock 144 161 315 minecraft:snow_block
fill 144 161 316 144 164 316 minecraft:packed_ice
setblock 145 161 284 minecraft:snow_block
fill 145 161 285 145 162 285 minecraft:packed_ice
setblock 145 161 289 minecraft:snow_block
fill 145 161 290 145 162 290 minecraft:packed_ice
setblock 145 161 314 minecraft:snow_block
fill 145 161 315 145 164 315 minecraft:packed_ice
fill 146 161 314 148 162 314 minecraft:packed_ice
fill 147 161 275 147 165 275 minecraft:blue_ice
setblock 147 161 277 minecraft:snow_block
fill 147 161 315 148 161 315 minecraft:packed_ice
setblock 148 161 276 minecraft:snow_block
fill 148 161 277 148 162 277 minecraft:packed_ice
setblock 148 161 316 minecraft:snow_block
fill 149 161 276 149 164 276 minecraft:packed_ice
setblock 149 161 315 minecraft:snow_block
fill 149 161 316 149 164 316 minecraft:packed_ice
fill 150 161 315 150 164 315 minecraft:packed_ice
fill 152 161 315 153 161 315 minecraft:packed_ice
setblock 153 161 316 minecraft:snow_block
setblock 154 161 315 minecraft:snow_block
fill 154 161 316 154 164 316 minecraft:packed_ice
fill 155 161 315 158 161 315 minecraft:packed_ice
fill 156 161 311 156 162 311 minecraft:packed_ice
fill 157 161 310 157 162 310 minecraft:packed_ice
fill 157 161 312 157 162 312 minecraft:packed_ice
fill 157 161 314 159 161 314 minecraft:packed_ice
setblock 157 161 316 minecraft:packed_ice
setblock 158 161 276 minecraft:snow_block
fill 158 161 311 158 162 311 minecraft:packed_ice
setblock 158 161 316 minecraft:snow_block
fill 159 161 276 159 164 276 minecraft:packed_ice
fill 159 161 313 160 161 313 minecraft:packed_ice
setblock 159 161 315 minecraft:snow_block
fill 159 161 316 159 164 316 minecraft:packed_ice
setblock 160 161 314 minecraft:snow_block
fill 160 161 315 160 164 315 minecraft:packed_ice
fill 161 161 310 161 161 313 minecraft:snow_block
fill 161 161 314 164 161 314 minecraft:packed_ice
fill 162 161 310 162 161 312 minecraft:snow_block
fill 162 161 313 162 164 313 minecraft:packed_ice
setblock 163 161 276 minecraft:snow_block
fill 163 161 310 163 200 311 minecraft:snow_block
fill 163 161 312 164 162 312 minecraft:packed_ice
setblock 163 161 316 minecraft:snow_block
fill 164 161 276 164 164 276 minecraft:packed_ice
fill 164 161 313 165 161 313 minecraft:packed_ice
setblock 164 161 315 minecraft:snow_block
fill 164 161 316 164 164 316 minecraft:packed_ice
setblock 165 161 314 minecraft:snow_block
fill 165 161 315 165 164 315 minecraft:packed_ice
setblock 166 161 313 minecraft:snow_block
fill 166 161 314 166 164 314 minecraft:packed_ice
fill 168 161 298 168 161 299 minecraft:sea_lantern
fill 168 161 305 168 161 306 minecraft:sea_lantern
setblock 168 161 316 minecraft:snow_block
setblock 169 161 315 minecraft:snow_block
fill 169 161 316 169 164 316 minecraft:packed_ice
fill 178 161 281 178 167 281 minecraft:packed_ice
fill 179 161 288 179 161 289 minecraft:packed_ice
setblock 179 161 290 minecraft:snow_block
setblock 180 161 283 minecraft:packed_ice
setblock 180 161 284 minecraft:snow_block
fill 180 161 285 180 164 285 minecraft:packed_ice
setblock 180 161 288 minecraft:packed_ice
setblock 180 161 289 minecraft:snow_block
fill 180 161 290 180 164 290 minecraft:packed_ice
setblock 180 161 293 minecraft:packed_ice
setblock 180 161 294 minecraft:snow_block
fill 180 161 295 180 164 295 minecraft:packed_ice
fill 180 161 316 180 163 316 minecraft:packed_ice
setblock 181 161 283 minecraft:snow_block
fill 181 161 284 181 164 284 minecraft:packed_ice
setblock 181 161 288 minecraft:snow_block
fill 181 161 289 181 164 289 minecraft:packed_ice
setblock 181 161 293 minecraft:snow_block
fill 181 161 294 181 164 294 minecraft:packed_ice
setblock 181 161 298 minecraft:snow_block
fill 181 161 299 181 164 299 minecraft:packed_ice
setblock 181 161 303 minecraft:snow_block
fill 181 161 304 181 163 304 minecraft:packed_ice
setblock 181 161 308 minecraft:snow_block
fill 181 161 309 181 164 309 minecraft:packed_ice
setblock 181 161 312 minecraft:packed_ice
setblock 181 161 313 minecraft:snow_block
fill 181 161 314 181 164 314 minecraft:packed_ice
setblock 182 161 276 minecraft:packed_ice
setblock 182 161 277 minecraft:snow_block
fill 182 161 278 182 164 278 minecraft:packed_ice
setblock 182 161 282 minecraft:snow_block
fill 182 161 283 182 164 283 minecraft:packed_ice
setblock 182 161 287 minecraft:snow_block
fill 182 161 288 182 164 288 minecraft:packed_ice
setblock 182 161 292 minecraft:snow_block
fill 182 161 293 182 164 293 minecraft:packed_ice
setblock 182 161 297 minecraft:snow_block
fill 182 161 298 182 164 298 minecraft:packed_ice
setblock 182 161 302 minecraft:snow_block
fill 182 161 303 182 164 303 minecraft:packed_ice
setblock 182 161 307 minecraft:snow_block
fill 182 161 308 182 164 308 minecraft:packed_ice
setblock 182 161 312 minecraft:snow_block
fill 182 161 313 182 164 313 minecraft:packed_ice
fill 183 161 300 183 166 300 minecraft:blue_ice
setblock 183 161 301 minecraft:white_concrete
fill 141 162 275 141 168 275 minecraft:blue_ice
fill 141 162 287 142 162 287 minecraft:packed_ice
fill 141 162 291 141 165 291 minecraft:blue_ice
fill 141 162 292 142 162 292 minecraft:packed_ice
fill 141 162 293 141 165 293 minecraft:blue_ice
fill 142 162 275 144 162 275 minecraft:packed_ice
setblock 142 162 276 minecraft:snow_block
fill 142 162 277 142 165 277 minecraft:packed_ice
setblock 142 162 281 minecraft:snow_block
fill 142 162 282 142 165 282 minecraft:packed_ice
setblock 142 162 286 minecraft:snow_block
setblock 142 162 291 minecraft:snow_block
setblock 142 162 296 minecraft:snow_block
fill 142 162 297 142 165 297 minecraft:packed_ice
setblock 142 162 301 minecraft:snow_block
fill 142 162 302 142 163 302 minecraft:packed_ice
setblock 142 162 306 minecraft:snow_block
fill 142 162 307 142 165 307 minecraft:packed_ice
setblock 142 162 311 minecraft:snow_block
fill 142 162 312 142 165 312 minecraft:packed_ice
fill 142 162 314 142 162 315 minecraft:packed_ice
setblock 142 162 316 minecraft:snow_block
fill 143 162 276 143 165 276 minecraft:packed_ice
setblock 143 162 280 minecraft:snow_block
fill 143 162 281 143 165 281 minecraft:packed_ice
setblock 143 162 285 minecraft:snow_block
fill 143 162 286 143 165 286 minecraft:packed_ice
setblock 143 162 290 minecraft:snow_block
fill 143 162 291 143 165 291 minecraft:packed_ice
setblock 143 162 295 minecraft:snow_block
fill 143 162 296 143 164 296 minecraft:packed_ice
setblock 143 162 305 minecraft:snow_block
fill 143 162 306 143 163 306 minecraft:packed_ice
setblock 143 162 309 minecraft:packed_ice
setblock 143 162 310 minecraft:snow_block
fill 143 162 311 143 165 311 minecraft:packed_ice
setblock 143 162 315 minecraft:snow_block
fill 143 162 316 143 165 316 minecraft:packed_ice
setblock 144 162 279 minecraft:snow_block
setblock 144 162 280 minecraft:packed_ice
setblock 144 162 284 minecraft:snow_block
fill 144 162 285 144 164 285 minecraft:packed_ice
setblock 144 162 289 minecraft:snow_block
fill 144 162 290 144 165 290 minecraft:packed_ice
setblock 144 162 299 minecraft:light[level=12]
setblock 144 162 306 minecraft:light[level=12]
setblock 144 162 309 minecraft:snow_block
fill 144 162 310 144 164 310 minecraft:packed_ice
setblock 144 162 314 minecraft:snow_block
fill 144 162 315 144 165 315 minecraft:packed_ice
setblock 145 162 288 minecraft:snow_block
setblock 145 162 289 minecraft:packed_ice
fill 145 162 314 145 165 314 minecraft:packed_ice
setblock 146 162 275 minecraft:white_concrete
setblock 146 162 277 minecraft:snow_block
setblock 147 162 276 minecraft:snow_block
fill 147 162 277 147 163 277 minecraft:packed_ice
setblock 147 162 315 minecraft:packed_ice
setblock 147 162 316 minecraft:snow_block
fill 148 162 276 148 165 276 minecraft:packed_ice
setblock 148 162 315 minecraft:snow_block
fill 148 162 316 148 165 316 minecraft:packed_ice
fill 149 162 315 149 165 315 minecraft:packed_ice
setblock 151 162 278 minecraft:light[level=12]
setblock 151 162 285 minecraft:light[level=12]
setblock 151 162 292 minecraft:light[level=12]
setblock 151 162 299 minecraft:light[level=12]
setblock 151 162 306 minecraft:light[level=12]
setblock 151 162 313 minecraft:light[level=12]
setblock 152 162 276 minecraft:snow_block
fill 152 162 309 152 163 309 minecraft:blue_ice
setblock 152 162 315 minecraft:packed_ice
setblock 152 162 316 minecraft:snow_block
setblock 153 162 315 minecraft:snow_block
fill 153 162 316 153 165 316 minecraft:packed_ice
setblock 154 162 275 minecraft:packed_ice
fill 154 162 315 157 162 315 minecraft:packed_ice
fill 155 162 275 155 165 275 minecraft:blue_ice
fill 156 162 314 158 162 314 minecraft:packed_ice
setblock 157 162 276 minecraft:snow_block
setblock 157 162 316 minecraft:snow_block
fill 158 162 275 158 162 276 minecraft:packed_ice
setblock 158 162 278 minecraft:light[level=12]
setblock 158 162 285 minecraft:light[level=12]
setblock 158 162 299 minecraft:light[level=12]
setblock 158 162 306 minecraft:light[level=12]
fill 158 162 313 159 162 313 minecraft:packed_ice
setblock 158 162 315 minecraft:snow_block
fill 158 162 316 158 165 316 minecraft:packed_ice
setblock 159 162 314 minecraft:snow_block
fill 159 162 315 159 165 315 minecraft:packed_ice
setblock 160 162 313 minecraft:snow_block
fill 160 162 314 163 162 314 minecraft:packed_ice
fill 161 162 310 161 162 312 minecraft:snow_block
fill 161 162 313 161 165 313 minecraft:packed_ice
setblock 162 162 276 minecraft:snow_block
fill 162 162 310 162 200 311 minecraft:snow_block
fill 162 162 312 162 163 312 minecraft:packed_ice
setblock 162 162 316 minecraft:snow_block
fill 163 162 276 163 165 276 minecraft:packed_ice
setblock 163 162 315 minecraft:snow_block
fill 163 162 316 163 165 316 minecraft:packed_ice
setblock 164 162 275 minecraft:packed_ice
setblock 164 162 313 minecraft:packed_ice
setblock 164 162 314 minecraft:snow_block
fill 164 162 315 164 165 315 minecraft:packed_ice
setblock 165 162 278 minecraft:light[level=12]
setblock 165 162 285 minecraft:light[level=12]
setblock 165 162 292 minecraft:light[level=12]
setblock 165 162 299 minecraft:light[level=12]
setblock 165 162 306 minecraft:light[level=12]
setblock 165 162 313 minecraft:snow_block
fill 165 162 314 165 165 314 minecraft:packed_ice
fill 166 162 313 166 163 313 minecraft:packed_ice
fill 167 162 314 167 163 314 minecraft:packed_ice
setblock 167 162 316 minecraft:snow_block
setblock 168 162 315 minecraft:snow_block
fill 168 162 316 168 165 316 minecraft:packed_ice
setblock 169 162 315 minecraft:packed_ice
fill 170 162 317 173 165 317 minecraft:blue_ice
setblock 172 162 278 minecraft:light[level=12]
setblock 172 162 285 minecraft:light[level=12]
setblock 172 162 292 minecraft:light[level=12]
setblock 172 162 313 minecraft:light[level=12]
setblock 174 162 317 minecraft:packed_ice
fill 175 162 317 178 163 317 minecraft:blue_ice
fill 179 162 275 180 165 275 minecraft:blue_ice
setblock 179 162 278 minecraft:light[level=12]
setblock 179 162 285 minecraft:light[level=12]
fill 179 162 287 179 162 288 minecraft:packed_ice
setblock 179 162 289 minecraft:snow_block
fill 179 162 290 179 163 292 minecraft:packed_ice
schedule function dropper:buildpart/63_6 1t
