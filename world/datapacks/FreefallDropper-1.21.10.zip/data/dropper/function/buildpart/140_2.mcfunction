fill 376 122 557 376 127 557 minecraft:purple_terracotta
fill 376 122 563 376 123 564 minecraft:purple_concrete
fill 376 122 565 376 127 566 minecraft:purple_terracotta
fill 376 122 575 376 122 576 minecraft:purple_concrete
fill 376 122 577 376 127 578 minecraft:purple_terracotta
fill 376 122 584 376 123 584 minecraft:purple_concrete
fill 376 122 585 376 127 586 minecraft:purple_terracotta
setblock 376 122 587 minecraft:purple_concrete
fill 376 122 589 376 124 589 minecraft:purple_terracotta
fill 376 122 595 376 123 596 minecraft:purple_concrete
fill 376 122 597 376 127 598 minecraft:purple_terracotta
fill 380 122 557 380 127 557 minecraft:purple_terracotta
setblock 380 122 599 minecraft:purple_terracotta
fill 381 122 599 381 123 599 minecraft:purple_concrete
setblock 382 122 557 minecraft:purple_concrete
fill 383 122 557 384 127 557 minecraft:purple_terracotta
fill 383 122 599 383 127 599 minecraft:purple_terracotta
fill 384 122 599 385 122 599 minecraft:purple_concrete
fill 385 122 557 385 123 557 minecraft:purple_concrete
fill 386 122 599 387 124 599 minecraft:purple_terracotta
fill 391 122 557 392 127 557 minecraft:purple_terracotta
fill 392 122 599 393 123 599 minecraft:purple_concrete
fill 393 122 557 394 122 557 minecraft:purple_concrete
fill 394 122 599 395 127 599 minecraft:purple_terracotta
fill 395 122 562 395 123 564 minecraft:black_concrete
fill 396 122 561 396 125 561 minecraft:black_concrete
setblock 396 122 599 minecraft:purple_concrete
fill 397 122 565 397 125 565 minecraft:black_concrete
fill 397 122 599 397 125 599 minecraft:purple_terracotta
setblock 400 122 565 minecraft:black_concrete
setblock 401 122 561 minecraft:purple_concrete
setblock 401 122 564 minecraft:black_concrete
setblock 402 122 564 minecraft:purple_concrete
fill 402 122 599 403 123 599 minecraft:purple_terracotta
fill 403 122 557 404 127 557 minecraft:purple_terracotta
fill 404 122 599 405 122 599 minecraft:purple_concrete
fill 405 122 557 406 123 557 minecraft:purple_concrete
fill 406 122 599 407 127 599 minecraft:purple_terracotta
fill 412 122 557 412 127 557 minecraft:purple_terracotta
setblock 412 122 599 minecraft:purple_terracotta
fill 413 122 557 414 122 557 minecraft:purple_concrete
fill 413 122 599 413 123 599 minecraft:purple_concrete
fill 414 122 599 415 127 599 minecraft:purple_terracotta
fill 415 122 557 416 123 557 minecraft:purple_terracotta
setblock 416 122 599 minecraft:purple_concrete
fill 417 122 557 417 123 557 minecraft:purple_concrete
fill 418 122 562 418 127 563 minecraft:purple_terracotta
fill 418 122 564 418 123 565 minecraft:purple_concrete
fill 418 122 572 418 125 572 minecraft:purple_terracotta
setblock 418 122 573 minecraft:purple_concrete
fill 418 122 574 418 127 575 minecraft:purple_terracotta
fill 418 122 576 418 123 577 minecraft:purple_concrete
fill 418 122 582 418 127 583 minecraft:purple_terracotta
fill 418 122 584 418 122 585 minecraft:purple_concrete
fill 418 122 586 418 127 586 minecraft:purple_terracotta
fill 418 122 594 418 127 595 minecraft:purple_terracotta
fill 418 122 596 418 123 597 minecraft:purple_concrete
fill 418 122 599 418 127 599 minecraft:purple_terracotta
setblock 376 123 572 minecraft:purple_concrete
setblock 376 123 575 minecraft:purple_concrete
fill 376 123 576 376 126 576 minecraft:purple_terracotta
setblock 376 123 583 minecraft:purple_concrete
fill 376 123 587 376 126 587 minecraft:purple_terracotta
fill 376 123 591 376 125 591 minecraft:purple_terracotta
setblock 376 123 592 minecraft:purple_concrete
setblock 380 123 599 minecraft:purple_concrete
fill 382 123 557 382 126 557 minecraft:purple_terracotta
setblock 384 123 599 minecraft:purple_concrete
fill 385 123 599 385 126 599 minecraft:purple_terracotta
setblock 386 123 557 minecraft:purple_concrete
fill 393 123 557 393 126 557 minecraft:purple_terracotta
setblock 394 123 557 minecraft:purple_concrete
fill 394 123 562 394 123 564 minecraft:black_concrete
fill 395 123 557 396 123 557 minecraft:purple_terracotta
fill 395 123 561 395 124 561 minecraft:black_concrete
fill 395 123 565 396 124 565 minecraft:black_concrete
fill 396 123 592 396 131 592 minecraft:obsidian
fill 396 123 599 396 125 599 minecraft:purple_terracotta
setblock 397 123 557 minecraft:purple_concrete
fill 397 123 560 398 123 560 minecraft:black_concrete
setblock 401 123 564 minecraft:purple_concrete
setblock 401 123 599 minecraft:purple_concrete
setblock 404 123 599 minecraft:purple_concrete
fill 405 123 599 405 126 599 minecraft:purple_terracotta
setblock 412 123 599 minecraft:purple_concrete
fill 413 123 557 414 126 557 minecraft:purple_terracotta
fill 416 123 599 416 126 599 minecraft:purple_terracotta
setblock 418 123 557 minecraft:purple_concrete
setblock 418 123 567 minecraft:purple_terracotta
setblock 418 123 568 minecraft:purple_concrete
fill 418 123 573 418 126 573 minecraft:purple_terracotta
fill 418 123 584 418 126 584 minecraft:purple_terracotta
setblock 418 123 585 minecraft:purple_concrete
fill 418 123 588 418 123 589 minecraft:purple_concrete
fill 376 124 561 376 125 562 minecraft:purple_concrete
fill 376 124 563 376 129 564 minecraft:purple_terracotta
fill 376 124 570 376 125 570 minecraft:purple_concrete
fill 376 124 571 376 125 572 minecraft:purple_terracotta
fill 376 124 573 376 124 574 minecraft:purple_concrete
fill 376 124 575 376 129 575 minecraft:purple_terracotta
fill 376 124 581 376 125 582 minecraft:purple_concrete
fill 376 124 583 376 129 584 minecraft:purple_terracotta
fill 376 124 592 376 125 592 minecraft:purple_terracotta
fill 376 124 593 376 124 594 minecraft:purple_concrete
fill 376 124 595 376 129 596 minecraft:purple_terracotta
fill 378 124 599 379 125 599 minecraft:purple_concrete
fill 380 124 599 381 129 599 minecraft:purple_terracotta
setblock 382 124 599 minecraft:purple_concrete
fill 384 124 599 384 126 599 minecraft:purple_terracotta
fill 385 124 557 386 129 557 minecraft:purple_terracotta
fill 387 124 557 388 125 557 minecraft:purple_concrete
fill 388 124 573 388 125 573 minecraft:obsidian
fill 390 124 599 391 125 599 minecraft:purple_concrete
fill 392 124 599 393 129 599 minecraft:purple_terracotta
setblock 393 124 561 minecraft:black_concrete
fill 393 124 562 395 128 564 minecraft:purple_concrete
fill 394 124 557 394 129 557 minecraft:purple_terracotta
fill 394 124 561 394 128 561 minecraft:purple_concrete
setblock 394 124 565 minecraft:black_concrete
fill 395 124 557 396 124 557 minecraft:purple_concrete
fill 396 124 560 397 124 560 minecraft:black_concrete
fill 396 124 593 396 131 593 minecraft:obsidian
fill 397 124 557 397 129 557 minecraft:purple_terracotta
fill 397 124 592 397 131 592 minecraft:obsidian
fill 398 124 564 398 124 565 minecraft:black_concrete
setblock 398 124 599 minecraft:purple_terracotta
fill 399 124 557 399 125 557 minecraft:purple_concrete
setblock 399 124 564 minecraft:black_concrete
fill 399 124 599 399 125 599 minecraft:purple_concrete
fill 401 124 599 401 129 599 minecraft:purple_terracotta
fill 402 124 599 403 124 599 minecraft:purple_concrete
fill 404 124 599 404 129 599 minecraft:purple_terracotta
fill 405 124 557 406 129 557 minecraft:purple_terracotta
fill 407 124 557 408 125 557 minecraft:purple_concrete
fill 410 124 599 411 125 599 minecraft:purple_concrete
fill 412 124 599 413 129 599 minecraft:purple_terracotta
fill 415 124 557 415 127 557 minecraft:purple_terracotta
setblock 416 124 557 minecraft:purple_concrete
fill 417 124 557 418 129 557 minecraft:purple_terracotta
fill 418 124 558 418 125 559 minecraft:purple_concrete
fill 418 124 564 418 129 565 minecraft:purple_terracotta
fill 418 124 566 418 124 567 minecraft:purple_concrete
fill 418 124 568 418 129 568 minecraft:purple_terracotta
fill 418 124 576 418 129 577 minecraft:purple_terracotta
fill 418 124 578 418 125 579 minecraft:purple_concrete
fill 418 124 585 418 129 585 minecraft:purple_terracotta
setblock 418 124 587 minecraft:purple_concrete
fill 418 124 588 418 129 589 minecraft:purple_terracotta
fill 418 124 590 418 125 590 minecraft:purple_concrete
fill 418 124 596 418 129 597 minecraft:purple_terracotta
setblock 418 124 598 minecraft:purple_concrete
setblock 376 125 558 minecraft:purple_concrete
setblock 376 125 569 minecraft:purple_concrete
fill 376 125 573 376 128 574 minecraft:purple_terracotta
fill 376 125 589 376 125 590 minecraft:purple_concrete
setblock 376 125 593 minecraft:purple_concrete
fill 376 125 594 376 128 594 minecraft:purple_terracotta
setblock 379 125 557 minecraft:purple_concrete
setblock 379 125 560 minecraft:light[level=12]
setblock 379 125 568 minecraft:light[level=12]
setblock 379 125 576 minecraft:light[level=12]
setblock 379 125 584 minecraft:light[level=12]
setblock 379 125 592 minecraft:light[level=12]
fill 382 125 599 382 128 599 minecraft:purple_terracotta
fill 386 125 599 386 127 599 minecraft:purple_terracotta
setblock 387 125 560 minecraft:light[level=12]
setblock 387 125 568 minecraft:light[level=12]
setblock 387 125 576 minecraft:light[level=12]
setblock 387 125 584 minecraft:light[level=12]
setblock 387 125 592 minecraft:light[level=12]
setblock 387 125 599 minecraft:purple_concrete
fill 391 125 563 392 131 563 minecraft:purple_concrete
fill 392 125 562 392 130 562 minecraft:purple_concrete
fill 392 125 564 392 131 564 minecraft:purple_concrete
fill 393 125 561 393 128 561 minecraft:purple_concrete
fill 393 125 565 395 127 565 minecraft:purple_concrete
fill 395 125 557 396 128 557 minecraft:purple_terracotta
fill 395 125 560 396 125 560 minecraft:black_concrete
fill 395 125 561 395 127 561 minecraft:purple_concrete
setblock 395 125 568 minecraft:light[level=12]
setblock 395 125 576 minecraft:light[level=12]
setblock 395 125 584 minecraft:light[level=12]
fill 395 125 592 395 131 593 minecraft:obsidian
fill 396 125 562 396 127 564 minecraft:purple_concrete
fill 396 125 565 396 126 565 minecraft:black_concrete
fill 396 125 591 396 131 591 minecraft:obsidian
fill 397 125 562 399 125 563 minecraft:black_concrete
fill 397 125 593 397 131 593 minecraft:obsidian
setblock 398 125 561 minecraft:black_concrete
setblock 398 125 564 minecraft:black_concrete
setblock 398 125 599 minecraft:purple_concrete
setblock 400 125 557 minecraft:purple_concrete
fill 402 125 599 403 128 599 minecraft:purple_terracotta
setblock 403 125 560 minecraft:light[level=12]
setblock 403 125 568 minecraft:light[level=12]
setblock 403 125 576 minecraft:light[level=12]
setblock 403 125 584 minecraft:light[level=12]
setblock 403 125 592 minecraft:light[level=12]
setblock 411 125 557 minecraft:purple_concrete
setblock 411 125 560 minecraft:light[level=12]
setblock 411 125 568 minecraft:light[level=12]
setblock 411 125 576 minecraft:light[level=12]
setblock 411 125 584 minecraft:light[level=12]
setblock 411 125 592 minecraft:light[level=12]
fill 416 125 557 416 128 557 minecraft:purple_terracotta
fill 418 125 566 418 128 566 minecraft:purple_terracotta
setblock 418 125 567 minecraft:purple_concrete
fill 418 125 570 418 125 571 minecraft:purple_concrete
fill 418 125 587 418 128 587 minecraft:purple_terracotta
setblock 418 125 591 minecraft:purple_concrete
fill 418 125 598 418 128 598 minecraft:purple_terracotta
fill 376 126 558 376 131 558 minecraft:purple_terracotta
fill 376 126 559 376 126 560 minecraft:purple_concrete
fill 376 126 561 376 131 562 minecraft:purple_terracotta
fill 376 126 567 376 127 568 minecraft:purple_concrete
fill 376 126 569 376 131 570 minecraft:purple_terracotta
setblock 376 126 571 minecraft:purple_concrete
fill 376 126 572 376 129 572 minecraft:purple_terracotta
fill 376 126 579 376 127 580 minecraft:purple_concrete
fill 376 126 581 376 131 582 minecraft:purple_terracotta
fill 376 126 588 376 127 588 minecraft:purple_concrete
fill 376 126 589 376 127 590 minecraft:purple_terracotta
fill 376 126 591 376 126 592 minecraft:purple_concrete
fill 376 126 593 376 131 593 minecraft:purple_terracotta
fill 376 126 599 377 127 599 minecraft:purple_concrete
fill 377 126 557 378 126 557 minecraft:purple_concrete
fill 377 126 558 379 126 558 minecraft:obsidian
fill 377 126 560 377 126 562 minecraft:obsidian
fill 377 126 564 377 126 566 minecraft:obsidian
fill 377 126 568 377 126 570 minecraft:obsidian
fill 377 126 572 377 126 574 minecraft:obsidian
fill 377 126 576 377 126 578 minecraft:obsidian
fill 377 126 580 377 126 582 minecraft:obsidian
fill 377 126 584 377 126 586 minecraft:obsidian
fill 377 126 588 377 126 590 minecraft:obsidian
fill 377 126 592 377 126 594 minecraft:obsidian
fill 377 126 596 377 126 598 minecraft:obsidian
fill 378 126 599 379 131 599 minecraft:purple_terracotta
fill 379 126 557 379 131 557 minecraft:purple_terracotta
fill 379 126 598 381 126 598 minecraft:obsidian
fill 381 126 557 381 127 557 minecraft:purple_concrete
fill 381 126 558 383 126 558 minecraft:obsidian
fill 383 126 598 385 126 598 minecraft:obsidian
fill 385 126 558 387 126 558 minecraft:obsidian
fill 387 126 557 388 131 557 minecraft:purple_terracotta
fill 387 126 598 389 126 598 minecraft:obsidian
fill 387 126 599 387 127 599 minecraft:purple_terracotta
fill 388 126 599 389 126 599 minecraft:purple_concrete
fill 389 126 557 390 127 557 minecraft:purple_concrete
fill 389 126 558 391 126 558 minecraft:obsidian
fill 390 126 563 390 132 564 minecraft:purple_concrete
fill 390 126 599 391 131 599 minecraft:purple_terracotta
fill 391 126 562 391 131 562 minecraft:purple_concrete
fill 391 126 564 391 132 565 minecraft:purple_concrete
fill 391 126 598 393 126 598 minecraft:obsidian
fill 392 126 561 392 129 561 minecraft:purple_concrete
fill 392 126 565 392 131 565 minecraft:purple_concrete
fill 393 126 558 395 126 558 minecraft:obsidian
setblock 394 126 560 minecraft:purple_concrete
fill 395 126 591 395 131 591 minecraft:obsidian
fill 395 126 598 397 126 598 minecraft:obsidian
setblock 396 126 561 minecraft:purple_concrete
fill 396 126 594 397 131 594 minecraft:obsidian
fill 396 126 599 397 127 599 minecraft:purple_concrete
fill 397 126 558 399 126 558 minecraft:obsidian
fill 397 126 562 398 126 563 minecraft:black_concrete
fill 397 126 591 397 131 591 minecraft:obsidian
setblock 398 126 557 minecraft:purple_concrete
fill 398 126 592 398 131 592 minecraft:obsidian
fill 398 126 599 399 131 599 minecraft:purple_terracotta
fill 399 126 557 400 131 557 minecraft:purple_terracotta
fill 399 126 598 401 126 598 minecraft:obsidian
setblock 400 126 599 minecraft:purple_concrete
fill 401 126 557 402 127 557 minecraft:purple_concrete
fill 401 126 558 403 126 558 minecraft:obsidian
fill 403 126 598 405 126 598 minecraft:obsidian
fill 405 126 558 407 126 558 minecraft:obsidian
fill 407 126 557 408 131 557 minecraft:purple_terracotta
fill 407 126 598 409 126 598 minecraft:obsidian
fill 408 126 599 409 127 599 minecraft:purple_concrete
fill 409 126 557 410 126 557 minecraft:purple_concrete
fill 409 126 558 411 126 558 minecraft:obsidian
fill 410 126 599 411 131 599 minecraft:purple_terracotta
fill 411 126 557 411 131 557 minecraft:purple_terracotta
fill 411 126 598 413 126 598 minecraft:obsidian
fill 413 126 558 415 126 558 minecraft:obsidian
fill 415 126 598 417 126 598 minecraft:obsidian
fill 417 126 558 417 126 560 minecraft:obsidian
fill 417 126 562 417 126 564 minecraft:obsidian
fill 417 126 566 417 126 568 minecraft:obsidian
fill 417 126 570 417 126 572 minecraft:obsidian
fill 417 126 574 417 126 576 minecraft:obsidian
fill 417 126 578 417 126 580 minecraft:obsidian
fill 417 126 582 417 126 584 minecraft:obsidian
fill 417 126 586 417 126 588 minecraft:obsidian
fill 417 126 590 417 126 592 minecraft:obsidian
fill 417 126 594 417 126 596 minecraft:obsidian
fill 417 126 599 417 127 599 minecraft:purple_concrete
fill 418 126 558 418 131 559 minecraft:purple_terracotta
fill 418 126 560 418 127 561 minecraft:purple_concrete
fill 418 126 567 418 131 567 minecraft:purple_terracotta
setblock 418 126 569 minecraft:purple_concrete
fill 418 126 570 418 131 571 minecraft:purple_terracotta
fill 418 126 572 418 127 572 minecraft:purple_concrete
fill 418 126 578 418 131 579 minecraft:purple_terracotta
fill 418 126 580 418 126 581 minecraft:purple_concrete
fill 418 126 590 418 131 591 minecraft:purple_terracotta
fill 418 126 592 418 127 593 minecraft:purple_concrete
setblock 376 127 559 minecraft:purple_concrete
fill 376 127 560 376 130 560 minecraft:purple_terracotta
fill 376 127 571 376 130 571 minecraft:purple_terracotta
setblock 376 127 576 minecraft:purple_concrete
setblock 376 127 587 minecraft:purple_concrete
fill 376 127 591 376 129 592 minecraft:purple_terracotta
fill 377 127 557 378 130 557 minecraft:purple_terracotta
setblock 382 127 557 minecraft:purple_concrete
fill 384 127 599 385 127 599 minecraft:purple_concrete
setblock 388 127 599 minecraft:purple_concrete
fill 389 127 564 389 134 564 minecraft:purple_concrete
fill 389 127 599 389 130 599 minecraft:purple_terracotta
fill 390 127 562 390 131 562 minecraft:purple_concrete
fill 390 127 565 390 133 565 minecraft:purple_concrete
fill 391 127 561 391 128 561 minecraft:purple_concrete
fill 391 127 566 393 128 566 minecraft:purple_concrete
setblock 393 127 557 minecraft:purple_concrete
fill 394 127 592 394 131 593 minecraft:obsidian
fill 395 127 594 395 131 594 minecraft:obsidian
setblock 396 127 561 minecraft:black_concrete
fill 396 127 590 396 131 590 minecraft:obsidian
setblock 397 127 563 minecraft:black_concrete
fill 398 127 557 398 130 557 minecraft:purple_terracotta
fill 398 127 591 398 131 591 minecraft:obsidian
fill 398 127 593 398 131 593 minecraft:obsidian
fill 400 127 599 400 130 599 minecraft:purple_terracotta
setblock 405 127 599 minecraft:purple_concrete
fill 409 127 557 409 130 557 minecraft:purple_terracotta
setblock 410 127 557 minecraft:purple_concrete
fill 413 127 557 414 127 557 minecraft:purple_concrete
setblock 416 127 599 minecraft:purple_concrete
fill 418 127 569 418 130 569 minecraft:purple_terracotta
setblock 418 127 573 minecraft:purple_concrete
fill 418 127 580 418 130 580 minecraft:purple_terracotta
setblock 418 127 581 minecraft:purple_concrete
setblock 418 127 584 minecraft:purple_concrete
setblock 376 128 557 minecraft:purple_concrete
fill 376 128 559 376 133 559 minecraft:purple_terracotta
fill 376 128 565 376 129 566 minecraft:purple_concrete
fill 376 128 567 376 133 568 minecraft:purple_terracotta
fill 376 128 576 376 133 576 minecraft:purple_terracotta
fill 376 128 577 376 128 578 minecraft:purple_concrete
fill 376 128 579 376 130 580 minecraft:purple_terracotta
fill 376 128 585 376 129 586 minecraft:purple_concrete
fill 376 128 587 376 133 588 minecraft:purple_terracotta
setblock 376 128 589 minecraft:purple_concrete
fill 376 128 590 376 131 590 minecraft:purple_terracotta
fill 376 128 597 376 129 598 minecraft:purple_concrete
fill 376 128 599 377 133 599 minecraft:purple_terracotta
setblock 380 128 557 minecraft:purple_concrete
fill 381 128 557 382 133 557 minecraft:purple_terracotta
fill 383 128 557 384 129 557 minecraft:purple_concrete
fill 383 128 599 383 129 599 minecraft:purple_concrete
fill 384 128 599 385 129 599 minecraft:purple_terracotta
fill 386 128 599 387 128 599 minecraft:purple_concrete
fill 388 128 564 388 134 565 minecraft:purple_concrete
fill 388 128 599 388 133 599 minecraft:purple_terracotta
fill 389 128 557 390 133 557 minecraft:purple_terracotta
fill 389 128 563 389 133 563 minecraft:purple_concrete
fill 389 128 565 389 134 566 minecraft:purple_concrete
fill 390 128 566 390 133 566 minecraft:purple_concrete
fill 391 128 557 392 128 557 minecraft:purple_concrete
fill 393 128 557 393 133 557 minecraft:purple_terracotta
fill 393 128 565 394 129 565 minecraft:purple_concrete
fill 394 128 591 394 131 591 minecraft:obsidian
fill 394 128 594 394 131 594 minecraft:obsidian
fill 394 128 599 395 129 599 minecraft:purple_concrete
fill 395 128 590 395 131 590 minecraft:obsidian
fill 396 128 595 397 131 595 minecraft:obsidian
fill 396 128 599 397 133 599 minecraft:purple_terracotta
fill 397 128 590 397 131 590 minecraft:obsidian
fill 398 128 594 398 131 594 minecraft:obsidian
fill 399 128 592 399 131 592 minecraft:obsidian
fill 401 128 557 402 133 557 minecraft:purple_terracotta
fill 403 128 557 404 129 557 minecraft:purple_concrete
fill 405 128 599 405 133 599 minecraft:purple_terracotta
fill 406 128 599 407 128 599 minecraft:purple_concrete
fill 408 128 599 409 133 599 minecraft:purple_terracotta
fill 410 128 557 410 133 557 minecraft:purple_terracotta
setblock 412 128 557 minecraft:purple_concrete
fill 413 128 557 414 133 557 minecraft:purple_terracotta
fill 414 128 599 415 129 599 minecraft:purple_concrete
fill 415 128 557 415 129 557 minecraft:purple_concrete
fill 416 128 599 417 133 599 minecraft:purple_terracotta
fill 418 128 560 418 133 561 minecraft:purple_terracotta
fill 418 128 562 418 128 563 minecraft:purple_concrete
fill 418 128 572 418 133 573 minecraft:purple_terracotta
fill 418 128 574 418 129 575 minecraft:purple_concrete
fill 418 128 581 418 133 581 minecraft:purple_terracotta
fill 418 128 582 418 128 583 minecraft:purple_concrete
fill 418 128 584 418 133 584 minecraft:purple_terracotta
fill 418 128 586 418 129 586 minecraft:purple_concrete
fill 418 128 592 418 133 593 minecraft:purple_terracotta
fill 418 128 594 418 129 595 minecraft:purple_concrete
setblock 418 128 599 minecraft:purple_concrete
fill 376 129 557 376 132 557 minecraft:purple_terracotta
fill 376 129 573 376 129 574 minecraft:purple_concrete
setblock 376 129 577 minecraft:purple_concrete
fill 376 129 578 376 132 578 minecraft:purple_terracotta
fill 376 129 589 376 131 589 minecraft:purple_terracotta
setblock 376 129 594 minecraft:purple_concrete
fill 380 129 557 380 132 557 minecraft:purple_terracotta
setblock 382 129 599 minecraft:purple_concrete
fill 386 129 599 387 131 599 minecraft:purple_terracotta
fill 387 129 565 387 132 565 minecraft:purple_concrete
fill 388 129 563 388 133 563 minecraft:purple_concrete
fill 388 129 566 388 132 566 minecraft:purple_concrete
fill 389 129 562 389 131 562 minecraft:purple_concrete
fill 391 129 557 391 132 557 minecraft:purple_terracotta
fill 391 129 566 392 130 566 minecraft:purple_concrete
setblock 392 129 557 minecraft:purple_concrete
fill 393 129 562 394 129 564 minecraft:purple_concrete
fill 393 129 592 393 131 593 minecraft:obsidian
fill 394 129 590 394 131 590 minecraft:obsidian
fill 395 129 557 396 129 557 minecraft:purple_concrete
fill 395 129 595 395 131 595 minecraft:obsidian
fill 396 129 589 396 131 589 minecraft:obsidian
fill 398 129 590 398 131 590 minecraft:obsidian
fill 398 129 595 398 131 595 minecraft:obsidian
fill 399 129 591 399 131 591 minecraft:obsidian
fill 399 129 593 399 131 594 minecraft:obsidian
fill 402 129 599 403 129 599 minecraft:purple_concrete
setblock 406 129 599 minecraft:purple_concrete
fill 407 129 599 407 132 599 minecraft:purple_terracotta
fill 412 129 557 412 132 557 minecraft:purple_terracotta
setblock 416 129 557 minecraft:purple_concrete
fill 418 129 562 418 132 562 minecraft:purple_terracotta
setblock 418 129 563 minecraft:purple_concrete
setblock 418 129 566 minecraft:purple_concrete
fill 418 129 582 418 132 583 minecraft:purple_terracotta
setblock 418 129 587 minecraft:purple_concrete
setblock 418 129 598 minecraft:purple_concrete
fill 418 129 599 418 132 599 minecraft:purple_terracotta
fill 376 130 563 376 130 564 minecraft:purple_concrete
fill 376 130 565 376 135 566 minecraft:purple_terracotta
fill 376 130 572 376 131 572 minecraft:purple_concrete
fill 376 130 573 376 135 574 minecraft:purple_terracotta
setblock 376 130 575 minecraft:purple_concrete
fill 376 130 577 376 132 577 minecraft:purple_terracotta
fill 376 130 583 376 131 584 minecraft:purple_concrete
fill 376 130 585 376 135 586 minecraft:purple_terracotta
setblock 376 130 591 minecraft:purple_terracotta
fill 376 130 592 376 131 592 minecraft:purple_concrete
fill 376 130 594 376 135 594 minecraft:purple_terracotta
fill 376 130 595 376 130 596 minecraft:purple_concrete
fill 376 130 597 376 132 598 minecraft:purple_terracotta
fill 380 130 599 381 131 599 minecraft:purple_concrete
fill 382 130 599 383 135 599 minecraft:purple_terracotta
fill 383 130 557 384 135 557 minecraft:purple_terracotta
setblock 384 130 599 minecraft:purple_concrete
fill 385 130 557 386 131 557 minecraft:purple_concrete
fill 385 130 599 385 133 599 minecraft:purple_terracotta
fill 387 130 564 387 134 564 minecraft:purple_concrete
fill 387 130 566 387 131 567 minecraft:purple_concrete
fill 388 130 567 390 132 567 minecraft:purple_concrete
fill 392 130 557 392 135 557 minecraft:purple_terracotta
fill 392 130 599 393 130 599 minecraft:purple_concrete
fill 393 130 562 393 130 565 minecraft:purple_concrete
fill 393 130 591 393 131 591 minecraft:obsidian
fill 393 130 594 393 131 594 minecraft:obsidian
setblock 394 130 557 minecraft:purple_concrete
fill 394 130 562 394 132 563 minecraft:amethyst_block
fill 394 130 595 394 131 595 minecraft:obsidian
fill 394 130 599 395 135 599 minecraft:purple_terracotta
fill 395 130 557 396 135 557 minecraft:purple_terracotta
fill 395 130 589 395 131 589 minecraft:obsidian
fill 396 130 596 397 131 596 minecraft:obsidian
fill 397 130 557 397 131 557 minecraft:purple_concrete
fill 397 130 589 398 131 589 minecraft:obsidian
fill 399 130 590 399 131 590 minecraft:obsidian
fill 401 130 599 401 131 599 minecraft:purple_concrete
fill 402 130 599 403 135 599 minecraft:purple_terracotta
fill 403 130 557 404 135 557 minecraft:purple_terracotta
setblock 404 130 599 minecraft:purple_concrete
fill 405 130 557 406 130 557 minecraft:purple_concrete
fill 406 130 599 406 135 599 minecraft:purple_terracotta
fill 412 130 599 413 131 599 minecraft:purple_concrete
fill 414 130 599 415 135 599 minecraft:purple_terracotta
fill 415 130 557 416 135 557 minecraft:purple_terracotta
fill 417 130 557 418 131 557 minecraft:purple_concrete
fill 418 130 563 418 135 563 minecraft:purple_terracotta
fill 418 130 564 418 130 565 minecraft:purple_concrete
fill 418 130 566 418 135 566 minecraft:purple_terracotta
fill 418 130 568 418 131 568 minecraft:purple_concrete
fill 418 130 574 418 135 575 minecraft:purple_terracotta
fill 418 130 576 418 131 577 minecraft:purple_concrete
setblock 418 130 585 minecraft:purple_concrete
fill 418 130 586 418 135 587 minecraft:purple_terracotta
fill 418 130 588 418 131 589 minecraft:purple_concrete
fill 418 130 594 418 135 595 minecraft:purple_terracotta
fill 418 130 596 418 130 597 minecraft:purple_concrete
fill 418 130 598 418 135 598 minecraft:purple_terracotta
setblock 376 131 560 minecraft:purple_concrete
setblock 376 131 563 minecraft:purple_concrete
fill 376 131 564 376 134 564 minecraft:purple_terracotta
setblock 376 131 571 minecraft:purple_concrete
fill 376 131 575 376 134 575 minecraft:purple_terracotta
fill 376 131 579 376 133 579 minecraft:purple_terracotta
setblock 376 131 580 minecraft:purple_concrete
setblock 376 131 591 minecraft:purple_concrete
setblock 376 131 595 minecraft:purple_concrete
fill 376 131 596 376 134 596 minecraft:purple_terracotta
fill 377 131 557 378 131 557 minecraft:purple_concrete
fill 384 131 599 384 133 599 minecraft:purple_terracotta
fill 386 131 564 386 131 567 minecraft:purple_concrete
fill 387 131 563 387 132 563 minecraft:purple_concrete
fill 387 131 568 389 131 568 minecraft:purple_concrete
setblock 389 131 599 minecraft:purple_concrete
fill 391 131 566 391 132 566 minecraft:purple_concrete
fill 392 131 592 392 131 593 minecraft:obsidian
setblock 392 131 599 minecraft:purple_concrete
setblock 393 131 590 minecraft:obsidian
setblock 393 131 595 minecraft:obsidian
fill 393 131 599 393 134 599 minecraft:purple_terracotta
fill 394 131 557 394 134 557 minecraft:purple_terracotta
setblock 394 131 589 minecraft:obsidian
fill 394 131 596 395 131 596 minecraft:obsidian
setblock 398 131 557 minecraft:purple_concrete
setblock 398 131 596 minecraft:obsidian
setblock 399 131 595 minecraft:obsidian
fill 400 131 591 400 131 594 minecraft:obsidian
setblock 400 131 599 minecraft:purple_concrete
fill 404 131 599 404 134 599 minecraft:purple_terracotta
fill 405 131 557 405 134 557 minecraft:purple_terracotta
setblock 406 131 557 minecraft:purple_concrete
setblock 409 131 557 minecraft:purple_concrete
fill 418 131 564 418 134 565 minecraft:purple_terracotta
setblock 418 131 569 minecraft:purple_concrete
setblock 418 131 580 minecraft:purple_concrete
fill 418 131 585 418 134 585 minecraft:purple_terracotta
fill 418 131 596 418 134 596 minecraft:purple_terracotta
setblock 418 131 597 minecraft:purple_concrete
fill 376 132 558 376 133 558 minecraft:purple_concrete
fill 376 132 560 376 137 560 minecraft:purple_terracotta
fill 376 132 561 376 132 562 minecraft:purple_concrete
fill 376 132 563 376 137 563 minecraft:purple_terracotta
fill 376 132 569 376 133 570 minecraft:purple_concrete
fill 376 132 571 376 137 572 minecraft:purple_terracotta
fill 376 132 580 376 133 580 minecraft:purple_terracotta
fill 376 132 581 376 132 582 minecraft:purple_concrete
fill 376 132 583 376 137 584 minecraft:purple_terracotta
fill 376 132 589 376 133 590 minecraft:purple_concrete
fill 376 132 591 376 137 592 minecraft:purple_terracotta
setblock 376 132 593 minecraft:purple_concrete
fill 376 132 595 376 134 595 minecraft:purple_terracotta
fill 377 132 557 378 137 557 minecraft:purple_terracotta
fill 377 132 558 379 132 558 minecraft:obsidian
fill 377 132 560 377 132 562 minecraft:obsidian
fill 377 132 564 377 132 566 minecraft:obsidian
fill 377 132 568 377 132 570 minecraft:obsidian
fill 377 132 572 377 132 574 minecraft:obsidian
fill 377 132 576 377 132 578 minecraft:obsidian
fill 377 132 580 377 132 582 minecraft:obsidian
fill 377 132 584 377 132 586 minecraft:obsidian
fill 377 132 588 377 132 590 minecraft:obsidian
fill 377 132 592 377 132 594 minecraft:obsidian
fill 377 132 596 377 132 598 minecraft:obsidian
fill 378 132 599 379 133 599 minecraft:purple_concrete
fill 379 132 557 379 133 557 minecraft:purple_concrete
fill 379 132 598 381 132 598 minecraft:obsidian
fill 380 132 599 381 137 599 minecraft:purple_terracotta
fill 381 132 558 383 132 558 minecraft:obsidian
fill 383 132 598 385 132 598 minecraft:obsidian
fill 385 132 557 386 137 557 minecraft:purple_terracotta
fill 385 132 558 387 132 558 minecraft:obsidian
fill 385 132 565 386 132 565 minecraft:purple_concrete
fill 385 132 566 387 136 568 minecraft:black_concrete
fill 386 132 564 386 134 564 minecraft:purple_concrete
setblock 386 132 599 minecraft:purple_terracotta
fill 387 132 557 388 132 557 minecraft:purple_concrete
fill 387 132 598 389 132 598 minecraft:obsidian
fill 387 132 599 387 133 599 minecraft:purple_concrete
fill 388 132 568 389 132 568 minecraft:purple_concrete
fill 389 132 558 391 132 558 minecraft:obsidian
fill 389 132 599 389 137 599 minecraft:purple_terracotta
fill 390 132 599 391 132 599 minecraft:purple_concrete
setblock 391 132 563 minecraft:purple_concrete
fill 391 132 598 393 132 598 minecraft:obsidian
fill 392 132 599 392 137 599 minecraft:purple_terracotta
fill 393 132 558 395 132 558 minecraft:obsidian
fill 395 132 592 397 132 592 minecraft:amethyst_block
fill 395 132 598 397 132 598 minecraft:obsidian
fill 396 132 593 397 132 593 minecraft:amethyst_block
fill 397 132 557 398 137 557 minecraft:purple_terracotta
fill 397 132 558 399 132 558 minecraft:obsidian
fill 398 132 599 399 133 599 minecraft:purple_concrete
fill 399 132 557 400 133 557 minecraft:purple_concrete
fill 399 132 598 401 132 598 minecraft:obsidian
fill 400 132 599 401 137 599 minecraft:purple_terracotta
fill 401 132 558 403 132 558 minecraft:obsidian
fill 403 132 598 405 132 598 minecraft:obsidian
fill 405 132 558 407 132 558 minecraft:obsidian
fill 406 132 557 406 137 557 minecraft:purple_terracotta
fill 407 132 557 408 132 557 minecraft:purple_concrete
fill 407 132 598 409 132 598 minecraft:obsidian
fill 409 132 557 409 137 557 minecraft:purple_terracotta
fill 409 132 558 411 132 558 minecraft:obsidian
fill 410 132 599 411 132 599 minecraft:purple_concrete
fill 411 132 557 411 133 557 minecraft:purple_concrete
fill 411 132 598 413 132 598 minecraft:obsidian
fill 412 132 599 413 137 599 minecraft:purple_terracotta
fill 413 132 558 415 132 558 minecraft:obsidian
fill 415 132 598 417 132 598 minecraft:obsidian
fill 417 132 557 418 137 557 minecraft:purple_terracotta
fill 417 132 558 417 132 560 minecraft:obsidian
fill 417 132 562 417 132 564 minecraft:obsidian
fill 417 132 566 417 132 568 minecraft:obsidian
fill 417 132 570 417 132 572 minecraft:obsidian
fill 417 132 574 417 132 576 minecraft:obsidian
fill 417 132 578 417 132 580 minecraft:obsidian
fill 417 132 582 417 132 584 minecraft:obsidian
fill 417 132 586 417 132 588 minecraft:obsidian
fill 417 132 590 417 132 592 minecraft:obsidian
fill 417 132 594 417 132 596 minecraft:obsidian
fill 418 132 558 418 133 559 minecraft:purple_concrete
setblock 418 132 567 minecraft:purple_concrete
fill 418 132 568 418 137 569 minecraft:purple_terracotta
fill 418 132 570 418 133 571 minecraft:purple_concrete
fill 418 132 576 418 137 577 minecraft:purple_terracotta
fill 418 132 578 418 132 579 minecraft:purple_concrete
fill 418 132 580 418 137 580 minecraft:purple_terracotta
fill 418 132 588 418 137 589 minecraft:purple_terracotta
fill 418 132 590 418 133 591 minecraft:purple_concrete
fill 418 132 597 418 137 597 minecraft:purple_terracotta
setblock 376 133 557 minecraft:purple_concrete
fill 376 133 561 376 136 562 minecraft:purple_terracotta
fill 376 133 577 376 133 578 minecraft:purple_concrete
setblock 376 133 581 minecraft:purple_concrete
fill 376 133 582 376 136 582 minecraft:purple_terracotta
fill 376 133 593 376 136 593 minecraft:purple_terracotta
fill 376 133 597 376 135 597 minecraft:purple_terracotta
setblock 376 133 598 minecraft:purple_concrete
setblock 379 133 560 minecraft:light[level=12]
setblock 379 133 568 minecraft:light[level=12]
setblock 379 133 576 minecraft:light[level=12]
setblock 379 133 584 minecraft:light[level=12]
setblock 379 133 592 minecraft:light[level=12]
setblock 380 133 557 minecraft:purple_concrete
fill 384 133 566 384 136 569 minecraft:black_concrete
fill 385 133 565 387 135 565 minecraft:black_concrete
fill 385 133 569 387 137 569 minecraft:black_concrete
setblock 386 133 599 minecraft:purple_concrete
fill 387 133 557 387 136 557 minecraft:purple_terracotta
setblock 387 133 560 minecraft:light[level=12]
setblock 387 133 576 minecraft:light[level=12]
setblock 387 133 584 minecraft:light[level=12]
setblock 387 133 592 minecraft:light[level=12]
setblock 388 133 557 minecraft:purple_concrete
fill 388 133 566 388 135 568 minecraft:black_concrete
setblock 388 133 569 minecraft:purple_concrete
fill 389 133 567 389 134 568 minecraft:purple_concrete
setblock 390 133 564 minecraft:purple_concrete
setblock 390 133 567 minecraft:purple_concrete
fill 390 133 599 391 136 599 minecraft:purple_terracotta
setblock 391 133 557 minecraft:purple_concrete
setblock 395 133 560 minecraft:light[level=12]
setblock 395 133 568 minecraft:light[level=12]
setblock 395 133 576 minecraft:light[level=12]
setblock 395 133 584 minecraft:light[level=12]
setblock 395 133 592 minecraft:light[level=12]
fill 396 133 592 396 134 593 minecraft:amethyst_block
setblock 397 133 592 minecraft:amethyst_block
setblock 403 133 560 minecraft:light[level=12]
setblock 403 133 568 minecraft:light[level=12]
setblock 403 133 576 minecraft:light[level=12]
setblock 403 133 584 minecraft:light[level=12]
setblock 403 133 592 minecraft:light[level=12]
fill 407 133 557 408 136 557 minecraft:purple_terracotta
setblock 407 133 599 minecraft:purple_concrete
setblock 410 133 599 minecraft:purple_concrete
setblock 411 133 560 minecraft:light[level=12]
setblock 411 133 568 minecraft:light[level=12]
setblock 411 133 576 minecraft:light[level=12]
setblock 411 133 584 minecraft:light[level=12]
setblock 411 133 592 minecraft:light[level=12]
fill 411 133 599 411 136 599 minecraft:purple_terracotta
setblock 412 133 557 minecraft:purple_concrete
setblock 418 133 562 minecraft:purple_concrete
fill 418 133 567 418 136 567 minecraft:purple_terracotta
fill 418 133 578 418 136 578 minecraft:purple_terracotta
setblock 418 133 579 minecraft:purple_concrete
fill 418 133 582 418 133 583 minecraft:purple_concrete
setblock 418 133 599 minecraft:purple_concrete
fill 376 134 557 376 139 558 minecraft:purple_terracotta
setblock 376 134 559 minecraft:purple_concrete
fill 376 134 567 376 135 568 minecraft:purple_concrete
fill 376 134 569 376 139 570 minecraft:purple_terracotta
fill 376 134 576 376 135 576 minecraft:purple_concrete
fill 376 134 577 376 135 578 minecraft:purple_terracotta
fill 376 134 579 376 134 580 minecraft:purple_concrete
fill 376 134 581 376 139 581 minecraft:purple_terracotta
fill 376 134 587 376 135 588 minecraft:purple_concrete
fill 376 134 589 376 139 590 minecraft:purple_terracotta
fill 376 134 598 376 135 598 minecraft:purple_terracotta
fill 376 134 599 377 134 599 minecraft:purple_concrete
fill 378 134 599 379 139 599 minecraft:purple_terracotta
fill 379 134 557 380 139 557 minecraft:purple_terracotta
fill 381 134 557 382 135 557 minecraft:purple_concrete
fill 383 134 567 383 136 569 minecraft:black_concrete
fill 384 134 570 386 135 570 minecraft:black_concrete
fill 384 134 599 385 135 599 minecraft:purple_concrete
fill 386 134 599 387 139 599 minecraft:purple_terracotta
fill 388 134 557 388 139 557 minecraft:purple_terracotta
fill 388 134 569 388 135 569 minecraft:black_concrete
setblock 388 134 599 minecraft:purple_concrete
fill 389 134 557 390 134 557 minecraft:purple_concrete
fill 391 134 557 391 139 557 minecraft:purple_terracotta
fill 393 134 557 393 135 557 minecraft:purple_concrete
fill 396 134 599 397 135 599 minecraft:purple_concrete
fill 398 134 599 399 139 599 minecraft:purple_terracotta
fill 399 134 557 400 139 557 minecraft:purple_terracotta
fill 401 134 557 402 135 557 minecraft:purple_concrete
fill 405 134 599 405 135 599 minecraft:purple_concrete
fill 407 134 599 407 139 599 minecraft:purple_terracotta
fill 408 134 599 409 134 599 minecraft:purple_concrete
setblock 410 134 557 minecraft:purple_concrete
fill 410 134 599 410 139 599 minecraft:purple_terracotta
fill 411 134 557 412 139 557 minecraft:purple_terracotta
fill 413 134 557 414 135 557 minecraft:purple_concrete
fill 416 134 599 417 135 599 minecraft:purple_concrete
fill 418 134 558 418 139 559 minecraft:purple_terracotta
fill 418 134 560 418 134 561 minecraft:purple_concrete
fill 418 134 562 418 139 562 minecraft:purple_terracotta
fill 418 134 570 418 139 571 minecraft:purple_terracotta
fill 418 134 572 418 135 573 minecraft:purple_concrete
fill 418 134 579 418 139 579 minecraft:purple_terracotta
setblock 418 134 581 minecraft:purple_concrete
fill 418 134 582 418 139 583 minecraft:purple_terracotta
fill 418 134 584 418 135 584 minecraft:purple_concrete
fill 418 134 590 418 139 591 minecraft:purple_terracotta
fill 418 134 592 418 134 593 minecraft:purple_concrete
fill 418 134 599 418 139 599 minecraft:purple_terracotta
fill 376 135 559 376 138 559 minecraft:purple_terracotta
setblock 376 135 564 minecraft:purple_concrete
setblock 376 135 575 minecraft:purple_concrete
fill 376 135 579 376 137 580 minecraft:purple_terracotta
fill 376 135 595 376 135 596 minecraft:purple_concrete
setblock 376 135 599 minecraft:purple_concrete
fill 377 135 599 377 138 599 minecraft:purple_terracotta
fill 383 135 570 383 135 571 minecraft:black_concrete
fill 384 135 571 386 135 571 minecraft:black_concrete
fill 387 135 570 387 137 570 minecraft:black_concrete
setblock 388 135 565 minecraft:purple_concrete
fill 388 135 599 388 138 599 minecraft:purple_terracotta
fill 389 135 557 390 138 557 minecraft:purple_terracotta
setblock 393 135 599 minecraft:purple_concrete
setblock 394 135 557 minecraft:purple_concrete
setblock 396 135 592 minecraft:amethyst_block
setblock 404 135 599 minecraft:purple_concrete
setblock 405 135 557 minecraft:purple_concrete
fill 408 135 599 409 138 599 minecraft:purple_terracotta
fill 410 135 557 410 138 557 minecraft:purple_terracotta
fill 418 135 560 418 138 560 minecraft:purple_terracotta
setblock 418 135 561 minecraft:purple_concrete
fill 418 135 564 418 135 565 minecraft:purple_concrete
fill 418 135 581 418 138 581 minecraft:purple_terracotta
setblock 418 135 585 minecraft:purple_concrete
fill 418 135 592 418 138 592 minecraft:purple_terracotta
setblock 418 135 593 minecraft:purple_concrete
setblock 418 135 596 minecraft:purple_concrete
fill 376 136 564 376 141 564 minecraft:purple_terracotta
fill 376 136 565 376 136 566 minecraft:purple_concrete
fill 376 136 567 376 138 568 minecraft:purple_terracotta
fill 376 136 573 376 137 574 minecraft:purple_concrete
fill 376 136 575 376 141 576 minecraft:purple_terracotta
setblock 376 136 577 minecraft:purple_concrete
fill 376 136 578 376 139 578 minecraft:purple_terracotta
fill 376 136 585 376 137 586 minecraft:purple_concrete
fill 376 136 587 376 141 588 minecraft:purple_terracotta
fill 376 136 594 376 137 594 minecraft:purple_concrete
fill 376 136 595 376 137 596 minecraft:purple_terracotta
fill 376 136 597 376 136 598 minecraft:purple_concrete
fill 376 136 599 376 141 599 minecraft:purple_terracotta
fill 381 136 557 382 141 557 minecraft:purple_terracotta
fill 382 136 568 382 136 570 minecraft:black_concrete
fill 382 136 571 384 141 571 minecraft:purple_concrete
fill 382 136 599 383 137 599 minecraft:purple_concrete
fill 383 136 557 384 137 557 minecraft:purple_concrete
fill 383 136 570 384 141 570 minecraft:purple_concrete
fill 383 136 572 384 142 572 minecraft:purple_concrete
fill 384 136 599 385 141 599 minecraft:purple_terracotta
fill 385 136 570 385 136 572 minecraft:black_concrete
setblock 386 136 565 minecraft:black_concrete
fill 386 136 570 386 139 571 minecraft:black_concrete
fill 388 136 567 388 136 568 minecraft:black_concrete
setblock 392 136 557 minecraft:purple_concrete
fill 393 136 557 394 141 557 minecraft:purple_terracotta
fill 393 136 599 393 141 599 minecraft:purple_terracotta
fill 394 136 599 395 136 599 minecraft:purple_concrete
fill 395 136 557 396 137 557 minecraft:purple_concrete
fill 396 136 599 397 141 599 minecraft:purple_terracotta
fill 401 136 557 402 141 557 minecraft:purple_terracotta
fill 402 136 599 403 137 599 minecraft:purple_concrete
fill 403 136 557 404 136 557 minecraft:purple_concrete
fill 404 136 599 405 141 599 minecraft:purple_terracotta
fill 405 136 557 405 141 557 minecraft:purple_terracotta
setblock 406 136 599 minecraft:purple_concrete
fill 413 136 557 414 141 557 minecraft:purple_terracotta
fill 414 136 599 415 137 599 minecraft:purple_concrete
fill 415 136 557 416 137 557 minecraft:purple_concrete
fill 416 136 599 417 141 599 minecraft:purple_terracotta
fill 418 136 561 418 141 561 minecraft:purple_terracotta
setblock 418 136 563 minecraft:purple_concrete
fill 418 136 564 418 141 565 minecraft:purple_terracotta
fill 418 136 566 418 137 566 minecraft:purple_concrete
fill 418 136 572 418 141 573 minecraft:purple_terracotta
fill 418 136 574 418 136 575 minecraft:purple_concrete
fill 418 136 584 418 141 585 minecraft:purple_terracotta
fill 418 136 586 418 137 587 minecraft:purple_concrete
fill 418 136 593 418 141 593 minecraft:purple_terracotta
fill 418 136 594 418 136 595 minecraft:purple_concrete
fill 418 136 596 418 141 596 minecraft:purple_terracotta
fill 418 136 598 418 137 598 minecraft:purple_concrete
fill 376 137 561 376 137 562 minecraft:purple_concrete
setblock 376 137 565 minecraft:purple_concrete
fill 376 137 566 376 140 566 minecraft:purple_terracotta
fill 376 137 577 376 139 577 minecraft:purple_terracotta
setblock 376 137 582 minecraft:purple_concrete
setblock 376 137 593 minecraft:purple_concrete
fill 376 137 597 376 139 598 minecraft:purple_terracotta
fill 381 137 570 381 140 571 minecraft:purple_concrete
fill 382 137 568 387 137 568 minecraft:black_concrete
fill 382 137 569 382 140 570 minecraft:purple_concrete
fill 382 137 572 382 143 573 minecraft:purple_concrete
fill 383 137 567 387 137 567 minecraft:black_concrete
fill 383 137 569 384 140 569 minecraft:purple_concrete
fill 383 137 573 384 143 573 minecraft:purple_concrete
fill 385 137 566 386 137 566 minecraft:black_concrete
fill 385 137 570 385 140 572 minecraft:purple_concrete
setblock 387 137 557 minecraft:purple_concrete
fill 390 137 599 391 137 599 minecraft:purple_concrete
fill 392 137 557 392 140 557 minecraft:purple_terracotta
setblock 394 137 599 minecraft:purple_concrete
fill 395 137 599 395 140 599 minecraft:purple_terracotta
fill 403 137 557 403 140 557 minecraft:purple_terracotta
setblock 404 137 557 minecraft:purple_concrete
fill 406 137 599 406 140 599 minecraft:purple_terracotta
fill 407 137 557 408 137 557 minecraft:purple_concrete
setblock 411 137 599 minecraft:purple_concrete
fill 418 137 563 418 140 563 minecraft:purple_terracotta
setblock 418 137 567 minecraft:purple_concrete
fill 418 137 574 418 140 574 minecraft:purple_terracotta
setblock 418 137 575 minecraft:purple_concrete
setblock 418 137 578 minecraft:purple_concrete
fill 418 137 594 418 140 595 minecraft:purple_terracotta
fill 376 138 560 376 139 560 minecraft:purple_concrete
fill 376 138 561 376 143 562 minecraft:purple_terracotta
setblock 376 138 563 minecraft:purple_concrete
fill 376 138 565 376 140 565 minecraft:purple_terracotta
fill 376 138 571 376 139 572 minecraft:purple_concrete
fill 376 138 573 376 143 574 minecraft:purple_terracotta
setblock 376 138 579 minecraft:purple_terracotta
fill 376 138 580 376 139 580 minecraft:purple_concrete
fill 376 138 582 376 143 582 minecraft:purple_terracotta
fill 376 138 583 376 138 584 minecraft:purple_concrete
fill 376 138 585 376 140 586 minecraft:purple_terracotta
fill 376 138 591 376 139 592 minecraft:purple_concrete
fill 376 138 593 376 143 594 minecraft:purple_terracotta
setblock 376 138 595 minecraft:purple_concrete
fill 376 138 596 376 141 596 minecraft:purple_terracotta
fill 377 138 557 378 139 557 minecraft:purple_concrete
fill 377 138 558 379 138 558 minecraft:obsidian
fill 377 138 560 377 138 562 minecraft:obsidian
fill 377 138 564 377 138 566 minecraft:obsidian
fill 377 138 568 377 138 570 minecraft:obsidian
fill 377 138 572 377 138 574 minecraft:obsidian
fill 377 138 576 377 138 578 minecraft:obsidian
fill 377 138 580 377 138 582 minecraft:obsidian
fill 377 138 584 377 138 586 minecraft:obsidian
fill 377 138 588 377 138 590 minecraft:obsidian
fill 377 138 592 377 138 594 minecraft:obsidian
fill 377 138 596 377 138 598 minecraft:obsidian
fill 379 138 598 381 138 598 minecraft:obsidian
fill 380 138 599 381 138 599 minecraft:purple_concrete
fill 381 138 558 383 138 558 minecraft:obsidian
fill 381 138 572 381 142 573 minecraft:purple_concrete
fill 382 138 574 384 143 574 minecraft:purple_concrete
fill 382 138 599 383 143 599 minecraft:purple_terracotta
fill 383 138 557 384 143 557 minecraft:purple_terracotta
fill 383 138 568 386 138 568 minecraft:black_concrete
fill 383 138 598 385 138 598 minecraft:obsidian
fill 384 138 567 385 138 567 minecraft:black_concrete
fill 385 138 557 386 138 557 minecraft:purple_concrete
fill 385 138 558 387 138 558 minecraft:obsidian
fill 385 138 569 385 139 569 minecraft:purple_concrete
fill 385 138 573 385 141 573 minecraft:purple_concrete
setblock 386 138 569 minecraft:black_concrete
fill 387 138 557 387 143 557 minecraft:purple_terracotta
fill 387 138 598 389 138 598 minecraft:obsidian
fill 389 138 558 391 138 558 minecraft:obsidian
fill 389 138 599 389 139 599 minecraft:purple_concrete
fill 390 138 599 391 143 599 minecraft:purple_terracotta
fill 391 138 598 393 138 598 minecraft:obsidian
setblock 392 138 599 minecraft:purple_concrete
fill 393 138 558 395 138 558 minecraft:obsidian
fill 394 138 599 394 143 599 minecraft:purple_terracotta
fill 395 138 557 396 143 557 minecraft:purple_terracotta
fill 395 138 598 397 138 598 minecraft:obsidian
fill 397 138 557 398 139 557 minecraft:purple_concrete
fill 397 138 558 399 138 558 minecraft:obsidian
fill 399 138 598 401 138 598 minecraft:obsidian
fill 400 138 599 401 139 599 minecraft:purple_concrete
fill 401 138 558 403 138 558 minecraft:obsidian
fill 402 138 599 403 143 599 minecraft:purple_terracotta
fill 403 138 598 405 138 598 minecraft:obsidian
fill 404 138 557 404 143 557 minecraft:purple_terracotta
fill 405 138 558 407 138 558 minecraft:obsidian
setblock 406 138 557 minecraft:purple_concrete
fill 407 138 557 408 143 557 minecraft:purple_terracotta
fill 407 138 598 409 138 598 minecraft:obsidian
fill 409 138 557 409 139 557 minecraft:purple_concrete
fill 409 138 558 411 138 558 minecraft:obsidian
fill 411 138 598 413 138 598 minecraft:obsidian
fill 411 138 599 411 143 599 minecraft:purple_terracotta
fill 412 138 599 413 138 599 minecraft:purple_concrete
fill 413 138 558 415 138 558 minecraft:obsidian
fill 414 138 599 415 143 599 minecraft:purple_terracotta
fill 415 138 557 416 143 557 minecraft:purple_terracotta
fill 415 138 598 417 138 598 minecraft:obsidian
fill 417 138 557 418 138 557 minecraft:purple_concrete
fill 417 138 558 417 138 560 minecraft:obsidian
fill 417 138 562 417 138 564 minecraft:obsidian
fill 417 138 566 417 138 568 minecraft:obsidian
fill 417 138 570 417 138 572 minecraft:obsidian
fill 417 138 574 417 138 576 minecraft:obsidian
fill 417 138 578 417 138 580 minecraft:obsidian
fill 417 138 582 417 138 584 minecraft:obsidian
fill 417 138 586 417 138 588 minecraft:obsidian
fill 417 138 590 417 138 592 minecraft:obsidian
fill 417 138 594 417 138 596 minecraft:obsidian
fill 418 138 566 418 143 567 minecraft:purple_terracotta
fill 418 138 568 418 139 569 minecraft:purple_concrete
fill 418 138 575 418 143 575 minecraft:purple_terracotta
fill 418 138 576 418 138 577 minecraft:purple_concrete
fill 418 138 578 418 143 578 minecraft:purple_terracotta
fill 418 138 580 418 139 580 minecraft:purple_concrete
fill 418 138 586 418 143 587 minecraft:purple_terracotta
fill 418 138 588 418 139 589 minecraft:purple_concrete
setblock 418 138 597 minecraft:purple_concrete
fill 418 138 598 418 143 598 minecraft:purple_terracotta
setblock 376 139 559 minecraft:purple_concrete
fill 376 139 563 376 142 563 minecraft:purple_terracotta
fill 376 139 567 376 141 567 minecraft:purple_terracotta
setblock 376 139 568 minecraft:purple_concrete
setblock 376 139 579 minecraft:purple_concrete
setblock 376 139 583 minecraft:purple_concrete
fill 376 139 584 376 142 584 minecraft:purple_terracotta
fill 376 139 595 376 141 595 minecraft:purple_terracotta
setblock 377 139 599 minecraft:purple_concrete
setblock 380 139 599 minecraft:purple_concrete
fill 381 139 574 381 144 575 minecraft:purple_concrete
fill 381 139 599 381 142 599 minecraft:purple_terracotta
fill 382 139 575 383 145 575 minecraft:purple_concrete
fill 383 139 568 385 139 568 minecraft:black_concrete
fill 385 139 557 385 142 557 minecraft:purple_terracotta
setblock 386 139 557 minecraft:purple_concrete
setblock 388 139 599 minecraft:purple_concrete
fill 389 139 557 390 139 557 minecraft:purple_concrete
fill 392 139 599 392 142 599 minecraft:purple_terracotta
fill 406 139 557 406 142 557 minecraft:purple_terracotta
fill 408 139 599 409 139 599 minecraft:purple_concrete
setblock 410 139 557 minecraft:purple_concrete
setblock 412 139 599 minecraft:purple_concrete
fill 413 139 599 413 142 599 minecraft:purple_terracotta
fill 417 139 557 417 142 557 minecraft:purple_terracotta
setblock 418 139 557 minecraft:purple_concrete
setblock 418 139 560 minecraft:purple_concrete
fill 418 139 576 418 142 577 minecraft:purple_terracotta
setblock 418 139 581 minecraft:purple_concrete
setblock 418 139 592 minecraft:purple_concrete
fill 418 139 597 418 142 597 minecraft:purple_terracotta
fill 376 140 557 376 141 558 minecraft:purple_concrete
fill 376 140 559 376 145 560 minecraft:purple_terracotta
fill 376 140 568 376 141 568 minecraft:purple_terracotta
fill 376 140 569 376 140 570 minecraft:purple_concrete
fill 376 140 571 376 145 572 minecraft:purple_terracotta
fill 376 140 577 376 141 578 minecraft:purple_concrete
fill 376 140 579 376 145 580 minecraft:purple_terracotta
setblock 376 140 581 minecraft:purple_concrete
fill 376 140 583 376 142 583 minecraft:purple_terracotta
fill 376 140 589 376 141 590 minecraft:purple_concrete
fill 376 140 591 376 145 592 minecraft:purple_terracotta
setblock 376 140 597 minecraft:purple_terracotta
fill 376 140 598 376 141 598 minecraft:purple_concrete
fill 377 140 557 378 145 557 minecraft:purple_terracotta
fill 377 140 599 377 145 599 minecraft:purple_terracotta
fill 378 140 599 379 140 599 minecraft:purple_concrete
fill 379 140 557 380 141 557 minecraft:purple_concrete
fill 380 140 572 380 141 575 minecraft:purple_concrete
fill 380 140 599 380 145 599 minecraft:purple_terracotta
fill 381 140 576 383 146 576 minecraft:purple_concrete
fill 384 140 575 384 144 575 minecraft:purple_concrete
fill 385 140 574 385 141 574 minecraft:purple_concrete
fill 386 140 557 386 145 557 minecraft:purple_terracotta
fill 386 140 599 387 141 599 minecraft:purple_concrete
setblock 388 140 557 minecraft:purple_concrete
fill 388 140 599 389 145 599 minecraft:purple_terracotta
fill 389 140 557 390 145 557 minecraft:purple_terracotta
fill 391 140 557 391 141 557 minecraft:purple_concrete
fill 397 140 557 398 145 557 minecraft:purple_terracotta
fill 398 140 599 399 140 599 minecraft:purple_concrete
fill 399 140 557 400 140 557 minecraft:purple_concrete
fill 400 140 599 401 145 599 minecraft:purple_terracotta
fill 407 140 599 407 141 599 minecraft:purple_concrete
fill 408 140 599 409 145 599 minecraft:purple_terracotta
fill 409 140 557 410 145 557 minecraft:purple_terracotta
setblock 410 140 599 minecraft:purple_concrete
fill 411 140 557 412 141 557 minecraft:purple_concrete
fill 412 140 599 412 145 599 minecraft:purple_terracotta
fill 418 140 557 418 145 557 minecraft:purple_terracotta
fill 418 140 558 418 140 559 minecraft:purple_concrete
fill 418 140 560 418 145 560 minecraft:purple_terracotta
fill 418 140 562 418 141 562 minecraft:purple_concrete
fill 418 140 568 418 145 569 minecraft:purple_terracotta
fill 418 140 570 418 141 571 minecraft:purple_concrete
setblock 418 140 579 minecraft:purple_concrete
fill 418 140 580 418 145 581 minecraft:purple_terracotta
fill 418 140 582 418 141 583 minecraft:purple_concrete
fill 418 140 588 418 145 589 minecraft:purple_terracotta
fill 418 140 590 418 140 591 minecraft:purple_concrete
fill 418 140 592 418 145 592 minecraft:purple_terracotta
fill 418 140 599 418 141 599 minecraft:purple_concrete
fill 376 141 565 376 141 566 minecraft:purple_concrete
setblock 376 141 569 minecraft:purple_concrete
fill 376 141 570 376 144 570 minecraft:purple_terracotta
fill 376 141 581 376 144 581 minecraft:purple_terracotta
fill 376 141 585 376 143 585 minecraft:purple_terracotta
setblock 376 141 586 minecraft:purple_concrete
setblock 376 141 597 minecraft:purple_concrete
fill 378 141 599 379 144 599 minecraft:purple_terracotta
setblock 379 141 560 minecraft:light[level=12]
setblock 379 141 568 minecraft:light[level=12]
setblock 379 141 576 minecraft:light[level=12]
setblock 379 141 584 minecraft:light[level=12]
setblock 379 141 592 minecraft:light[level=12]
fill 380 141 576 380 146 576 minecraft:purple_concrete
setblock 381 141 571 minecraft:purple_concrete
fill 381 141 577 383 147 577 minecraft:purple_concrete
setblock 382 141 570 minecraft:purple_concrete
fill 384 141 576 384 145 576 minecraft:purple_concrete
setblock 385 141 572 minecraft:purple_concrete
setblock 387 141 560 minecraft:light[level=12]
setblock 387 141 568 minecraft:light[level=12]
setblock 387 141 576 minecraft:light[level=12]
setblock 387 141 584 minecraft:light[level=12]
setblock 387 141 592 minecraft:light[level=12]
fill 388 141 557 388 144 557 minecraft:purple_terracotta
setblock 392 141 557 minecraft:purple_concrete
setblock 395 141 560 minecraft:light[level=12]
setblock 395 141 568 minecraft:light[level=12]
setblock 395 141 576 minecraft:light[level=12]
setblock 395 141 584 minecraft:light[level=12]
setblock 395 141 592 minecraft:light[level=12]
setblock 395 141 599 minecraft:purple_concrete
setblock 398 141 599 minecraft:purple_concrete
fill 399 141 557 399 144 557 minecraft:purple_terracotta
fill 399 141 599 399 144 599 minecraft:purple_terracotta
setblock 400 141 557 minecraft:purple_concrete
setblock 403 141 557 minecraft:purple_concrete
setblock 403 141 560 minecraft:light[level=12]
setblock 403 141 568 minecraft:light[level=12]
setblock 403 141 576 minecraft:light[level=12]
setblock 403 141 584 minecraft:light[level=12]
setblock 403 141 592 minecraft:light[level=12]
setblock 406 141 599 minecraft:purple_concrete
fill 410 141 599 410 144 599 minecraft:purple_terracotta
setblock 411 141 560 minecraft:light[level=12]
setblock 411 141 568 minecraft:light[level=12]
setblock 411 141 576 minecraft:light[level=12]
setblock 411 141 584 minecraft:light[level=12]
setblock 411 141 592 minecraft:light[level=12]
fill 418 141 558 418 144 559 minecraft:purple_terracotta
setblock 418 141 563 minecraft:purple_concrete
setblock 418 141 574 minecraft:purple_concrete
fill 418 141 579 418 144 579 minecraft:purple_terracotta
fill 418 141 590 418 144 590 minecraft:purple_terracotta
setblock 418 141 591 minecraft:purple_concrete
fill 418 141 594 418 141 595 minecraft:purple_concrete
fill 376 142 557 376 147 558 minecraft:purple_terracotta
fill 376 142 564 376 143 564 minecraft:purple_concrete
fill 376 142 565 376 143 566 minecraft:purple_terracotta
fill 376 142 567 376 142 568 minecraft:purple_concrete
fill 376 142 569 376 147 569 minecraft:purple_terracotta
fill 376 142 575 376 143 576 minecraft:purple_concrete
fill 376 142 577 376 147 578 minecraft:purple_terracotta
fill 376 142 586 376 143 586 minecraft:purple_terracotta
fill 376 142 587 376 142 588 minecraft:purple_concrete
fill 376 142 589 376 147 590 minecraft:purple_terracotta
fill 376 142 595 376 143 596 minecraft:purple_concrete
fill 376 142 597 376 147 598 minecraft:purple_terracotta
setblock 376 142 599 minecraft:purple_concrete
fill 379 142 557 380 147 557 minecraft:purple_terracotta
fill 379 142 575 380 143 575 minecraft:purple_concrete
fill 380 142 573 380 143 574 minecraft:purple_concrete
fill 380 142 577 380 145 578 minecraft:purple_concrete
fill 381 142 557 382 142 557 minecraft:purple_concrete
fill 381 142 578 383 144 578 minecraft:purple_concrete
fill 382 142 571 383 142 571 minecraft:purple_concrete
fill 384 142 571 384 144 571 minecraft:amethyst_block
fill 384 142 577 384 146 577 minecraft:purple_concrete
fill 384 142 599 385 143 599 minecraft:purple_concrete
fill 386 142 599 387 147 599 minecraft:purple_terracotta
fill 391 142 557 392 147 557 minecraft:purple_terracotta
fill 393 142 557 394 143 557 minecraft:purple_concrete
fill 393 142 599 393 143 599 minecraft:purple_concrete
fill 395 142 599 395 147 599 minecraft:purple_terracotta
fill 396 142 599 397 142 599 minecraft:purple_concrete
fill 398 142 599 398 147 599 minecraft:purple_terracotta
fill 400 142 557 400 147 557 minecraft:purple_terracotta
fill 401 142 557 402 142 557 minecraft:purple_concrete
fill 403 142 557 403 147 557 minecraft:purple_terracotta
fill 404 142 599 405 143 599 minecraft:purple_concrete
fill 405 142 557 405 143 557 minecraft:purple_concrete
fill 406 142 599 407 147 599 minecraft:purple_terracotta
fill 411 142 557 412 147 557 minecraft:purple_terracotta
fill 413 142 557 414 143 557 minecraft:purple_concrete
fill 416 142 599 417 142 599 minecraft:purple_concrete
setblock 418 142 561 minecraft:purple_concrete
fill 418 142 562 418 147 563 minecraft:purple_terracotta
fill 418 142 564 418 143 565 minecraft:purple_concrete
fill 418 142 570 418 147 571 minecraft:purple_terracotta
fill 418 142 572 418 142 573 minecraft:purple_concrete
fill 418 142 574 418 147 574 minecraft:purple_terracotta
fill 418 142 582 418 147 583 minecraft:purple_terracotta
fill 418 142 584 418 143 585 minecraft:purple_concrete
fill 418 142 591 418 147 591 minecraft:purple_terracotta
setblock 418 142 593 minecraft:purple_concrete
fill 418 142 594 418 147 595 minecraft:purple_terracotta
fill 418 142 596 418 143 596 minecraft:purple_concrete
fill 418 142 599 418 147 599 minecraft:purple_terracotta
setblock 376 143 563 minecraft:purple_concrete
fill 376 143 567 376 145 568 minecraft:purple_terracotta
fill 376 143 583 376 143 584 minecraft:purple_concrete
setblock 376 143 587 minecraft:purple_concrete
fill 376 143 588 376 146 588 minecraft:purple_terracotta
fill 376 143 599 376 146 599 minecraft:purple_terracotta
fill 379 143 576 379 144 576 minecraft:purple_concrete
fill 380 143 579 383 144 579 minecraft:purple_concrete
fill 381 143 557 381 146 557 minecraft:purple_terracotta
setblock 381 143 573 minecraft:purple_concrete
setblock 381 143 599 minecraft:purple_concrete
setblock 382 143 557 minecraft:purple_concrete
setblock 382 143 580 minecraft:purple_concrete
fill 383 143 571 383 145 571 minecraft:amethyst_block
setblock 383 143 572 minecraft:purple_concrete
fill 384 143 578 384 146 578 minecraft:purple_concrete
setblock 385 143 557 minecraft:purple_concrete
setblock 392 143 599 minecraft:purple_concrete
fill 396 143 599 397 146 599 minecraft:purple_terracotta
fill 401 143 557 402 146 557 minecraft:purple_terracotta
setblock 406 143 557 minecraft:purple_concrete
setblock 413 143 599 minecraft:purple_concrete
setblock 416 143 599 minecraft:purple_concrete
setblock 417 143 557 minecraft:purple_concrete
fill 417 143 599 417 146 599 minecraft:purple_terracotta
fill 418 143 561 418 146 561 minecraft:purple_terracotta
fill 418 143 572 418 146 572 minecraft:purple_terracotta
setblock 418 143 573 minecraft:purple_concrete
fill 418 143 576 418 143 577 minecraft:purple_concrete
fill 418 143 593 418 146 593 minecraft:purple_terracotta
setblock 418 143 597 minecraft:purple_concrete
fill 376 144 561 376 145 562 minecraft:purple_concrete
fill 376 144 563 376 149 564 minecraft:purple_terracotta
setblock 376 144 565 minecraft:purple_concrete
fill 376 144 566 376 147 566 minecraft:purple_terracotta
fill 376 144 573 376 145 574 minecraft:purple_concrete
fill 376 144 575 376 149 576 minecraft:purple_terracotta
fill 376 144 582 376 145 582 minecraft:purple_concrete
fill 376 144 583 376 145 584 minecraft:purple_terracotta
fill 376 144 585 376 144 586 minecraft:purple_concrete
fill 376 144 587 376 149 587 minecraft:purple_terracotta
fill 376 144 593 376 145 594 minecraft:purple_concrete
fill 376 144 595 376 149 596 minecraft:purple_terracotta
fill 377 144 558 379 144 558 minecraft:obsidian
fill 377 144 560 377 144 562 minecraft:obsidian
fill 377 144 564 377 144 566 minecraft:obsidian
fill 377 144 568 377 144 570 minecraft:obsidian
fill 377 144 572 377 144 574 minecraft:obsidian
fill 377 144 576 377 144 578 minecraft:obsidian
fill 377 144 580 377 144 582 minecraft:obsidian
fill 377 144 584 377 144 586 minecraft:obsidian
fill 377 144 588 377 144 590 minecraft:obsidian
fill 377 144 592 377 144 594 minecraft:obsidian
fill 377 144 596 377 144 598 minecraft:obsidian
fill 379 144 577 379 145 578 minecraft:purple_concrete
fill 379 144 598 381 144 598 minecraft:obsidian
fill 380 144 574 380 144 575 minecraft:purple_concrete
setblock 380 144 580 minecraft:purple_concrete
fill 381 144 558 383 144 558 minecraft:obsidian
fill 381 144 580 382 150 580 minecraft:black_concrete
fill 381 144 581 382 144 581 minecraft:purple_concrete
fill 381 144 599 381 149 599 minecraft:purple_terracotta
fill 382 144 557 382 149 557 minecraft:purple_terracotta
fill 382 144 573 382 144 574 minecraft:purple_concrete
fill 382 144 599 383 144 599 minecraft:purple_concrete
fill 383 144 557 384 144 557 minecraft:purple_concrete
setblock 383 144 574 minecraft:purple_concrete
setblock 383 144 580 minecraft:purple_concrete
fill 383 144 598 385 144 598 minecraft:obsidian
fill 384 144 579 384 145 579 minecraft:purple_concrete
fill 384 144 599 385 149 599 minecraft:purple_terracotta
fill 385 144 557 385 149 557 minecraft:purple_terracotta
fill 385 144 558 387 144 558 minecraft:obsidian
fill 387 144 557 387 145 557 minecraft:purple_concrete
fill 387 144 598 389 144 598 minecraft:obsidian
fill 389 144 558 391 144 558 minecraft:obsidian
fill 390 144 599 391 145 599 minecraft:purple_concrete
fill 391 144 598 393 144 598 minecraft:obsidian
fill 392 144 599 393 149 599 minecraft:purple_terracotta
fill 393 144 557 394 149 557 minecraft:purple_terracotta
fill 393 144 558 395 144 558 minecraft:obsidian
setblock 394 144 599 minecraft:purple_concrete
fill 395 144 557 396 145 557 minecraft:purple_concrete
fill 395 144 598 397 144 598 minecraft:obsidian
fill 397 144 558 399 144 558 minecraft:obsidian
fill 399 144 598 401 144 598 minecraft:obsidian
fill 401 144 558 403 144 558 minecraft:obsidian
fill 402 144 599 403 145 599 minecraft:purple_concrete
fill 403 144 598 405 144 598 minecraft:obsidian
setblock 404 144 557 minecraft:purple_concrete
fill 404 144 599 405 149 599 minecraft:purple_terracotta
fill 405 144 557 406 149 557 minecraft:purple_terracotta
fill 405 144 558 407 144 558 minecraft:obsidian
fill 407 144 557 408 145 557 minecraft:purple_concrete
fill 407 144 598 409 144 598 minecraft:obsidian
fill 409 144 558 411 144 558 minecraft:obsidian
fill 411 144 598 413 144 598 minecraft:obsidian
fill 411 144 599 411 145 599 minecraft:purple_concrete
fill 413 144 557 414 149 557 minecraft:purple_terracotta
fill 413 144 558 415 144 558 minecraft:obsidian
fill 413 144 599 413 149 599 minecraft:purple_terracotta
fill 414 144 599 415 144 599 minecraft:purple_concrete
fill 415 144 557 416 144 557 minecraft:purple_concrete
fill 415 144 598 417 144 598 minecraft:obsidian
fill 416 144 599 416 149 599 minecraft:purple_terracotta
fill 417 144 557 417 149 557 minecraft:purple_terracotta
fill 417 144 558 417 144 560 minecraft:obsidian
fill 417 144 562 417 144 564 minecraft:obsidian
fill 417 144 566 417 144 568 minecraft:obsidian
fill 417 144 570 417 144 572 minecraft:obsidian
fill 417 144 574 417 144 576 minecraft:obsidian
fill 417 144 578 417 144 580 minecraft:obsidian
fill 417 144 582 417 144 584 minecraft:obsidian
fill 417 144 586 417 144 588 minecraft:obsidian
fill 417 144 590 417 144 592 minecraft:obsidian
fill 417 144 594 417 144 596 minecraft:obsidian
fill 418 144 564 418 149 565 minecraft:purple_terracotta
fill 418 144 566 418 145 567 minecraft:purple_concrete
fill 418 144 573 418 149 573 minecraft:purple_terracotta
setblock 418 144 575 minecraft:purple_concrete
fill 418 144 576 418 149 577 minecraft:purple_terracotta
fill 418 144 578 418 145 578 minecraft:purple_concrete
fill 418 144 584 418 149 585 minecraft:purple_terracotta
fill 418 144 586 418 144 587 minecraft:purple_concrete
fill 418 144 596 418 149 597 minecraft:purple_terracotta
fill 418 144 598 418 145 598 minecraft:purple_concrete
fill 376 145 565 376 147 565 minecraft:purple_terracotta
setblock 376 145 570 minecraft:purple_concrete
setblock 376 145 581 minecraft:purple_concrete
fill 376 145 585 376 147 586 minecraft:purple_terracotta
fill 378 145 599 379 145 599 minecraft:purple_concrete
fill 379 145 579 379 147 579 minecraft:purple_concrete
fill 380 145 575 381 145 575 minecraft:purple_concrete
fill 380 145 579 380 148 581 minecraft:black_concrete
fill 381 145 578 382 148 579 minecraft:black_concrete
fill 381 145 581 382 149 582 minecraft:black_concrete
setblock 382 145 574 minecraft:purple_concrete
setblock 382 145 599 minecraft:purple_concrete
fill 383 145 557 384 148 557 minecraft:purple_terracotta
setblock 383 145 578 minecraft:purple_concrete
fill 383 145 579 383 149 581 minecraft:black_concrete
fill 383 145 599 383 148 599 minecraft:purple_terracotta
setblock 384 145 580 minecraft:purple_concrete
setblock 388 145 557 minecraft:purple_concrete
fill 394 145 599 394 148 599 minecraft:purple_terracotta
setblock 399 145 557 minecraft:purple_concrete
setblock 399 145 599 minecraft:purple_concrete
fill 404 145 557 404 148 557 minecraft:purple_terracotta
setblock 410 145 599 minecraft:purple_concrete
fill 414 145 599 415 148 599 minecraft:purple_terracotta
fill 415 145 557 415 148 557 minecraft:purple_terracotta
setblock 416 145 557 minecraft:purple_concrete
fill 418 145 558 418 145 559 minecraft:purple_concrete
fill 418 145 575 418 148 575 minecraft:purple_terracotta
setblock 418 145 579 minecraft:purple_concrete
fill 418 145 586 418 148 586 minecraft:purple_terracotta
setblock 418 145 587 minecraft:purple_concrete
setblock 418 145 590 minecraft:purple_concrete
fill 376 146 559 376 147 560 minecraft:purple_concrete
fill 376 146 561 376 151 562 minecraft:purple_terracotta
setblock 376 146 567 minecraft:purple_terracotta
fill 376 146 568 376 147 568 minecraft:purple_concrete
fill 376 146 570 376 151 570 minecraft:purple_terracotta
fill 376 146 571 376 146 572 minecraft:purple_concrete
fill 376 146 573 376 148 574 minecraft:purple_terracotta
fill 376 146 579 376 147 580 minecraft:purple_concrete
fill 376 146 581 376 151 582 minecraft:purple_terracotta
setblock 376 146 583 minecraft:purple_concrete
fill 376 146 584 376 149 584 minecraft:purple_terracotta
fill 376 146 591 376 146 592 minecraft:purple_concrete
fill 376 146 593 376 151 594 minecraft:purple_terracotta
fill 377 146 557 378 147 557 minecraft:purple_concrete
fill 377 146 599 377 147 599 minecraft:purple_concrete
fill 378 146 599 379 151 599 minecraft:purple_terracotta
setblock 379 146 578 minecraft:purple_concrete
fill 379 146 580 379 147 580 minecraft:black_concrete
fill 380 146 577 380 147 577 minecraft:purple_concrete
fill 380 146 578 380 147 578 minecraft:black_concrete
fill 380 146 582 380 150 582 minecraft:black_concrete
setblock 380 146 599 minecraft:purple_concrete
fill 381 146 583 383 148 583 minecraft:black_concrete
fill 382 146 599 382 151 599 minecraft:purple_terracotta
fill 383 146 578 383 148 578 minecraft:black_concrete
fill 383 146 582 383 149 582 minecraft:black_concrete
fill 384 146 579 384 147 581 minecraft:black_concrete
setblock 386 146 557 minecraft:purple_concrete
fill 387 146 557 388 151 557 minecraft:purple_terracotta
fill 388 146 599 389 147 599 minecraft:purple_concrete
fill 389 146 557 390 147 557 minecraft:purple_concrete
fill 390 146 599 391 151 599 minecraft:purple_terracotta
fill 395 146 557 396 151 557 minecraft:purple_terracotta
fill 397 146 557 398 146 557 minecraft:purple_concrete
fill 399 146 557 399 151 557 minecraft:purple_terracotta
fill 399 146 599 399 151 599 minecraft:purple_terracotta
fill 400 146 599 401 146 599 minecraft:purple_concrete
fill 402 146 599 403 151 599 minecraft:purple_terracotta
fill 407 146 557 408 151 557 minecraft:purple_terracotta
fill 408 146 599 409 147 599 minecraft:purple_concrete
fill 409 146 557 410 147 557 minecraft:purple_concrete
fill 410 146 599 411 151 599 minecraft:purple_terracotta
setblock 412 146 599 minecraft:purple_concrete
fill 413 146 574 415 147 574 minecraft:amethyst_block
fill 414 146 573 414 147 573 minecraft:amethyst_block
fill 414 146 575 414 147 575 minecraft:amethyst_block
fill 416 146 557 416 151 557 minecraft:purple_terracotta
setblock 418 146 557 minecraft:purple_concrete
fill 418 146 558 418 151 559 minecraft:purple_terracotta
fill 418 146 560 418 147 560 minecraft:purple_concrete
fill 418 146 566 418 151 567 minecraft:purple_terracotta
fill 418 146 568 418 146 569 minecraft:purple_concrete
fill 418 146 578 418 151 579 minecraft:purple_terracotta
fill 418 146 580 418 147 581 minecraft:purple_concrete
fill 418 146 587 418 151 587 minecraft:purple_terracotta
fill 418 146 588 418 146 589 minecraft:purple_concrete
fill 418 146 590 418 151 590 minecraft:purple_terracotta
fill 418 146 592 418 147 592 minecraft:purple_concrete
fill 418 146 598 418 151 598 minecraft:purple_terracotta
setblock 376 147 567 minecraft:purple_concrete
setblock 376 147 571 minecraft:purple_concrete
fill 376 147 572 376 150 572 minecraft:purple_terracotta
fill 376 147 583 376 149 583 minecraft:purple_terracotta
setblock 376 147 588 minecraft:purple_concrete
setblock 376 147 591 minecraft:purple_concrete
fill 376 147 592 376 150 592 minecraft:purple_terracotta
setblock 376 147 599 minecraft:purple_concrete
fill 380 147 583 380 150 583 minecraft:black_concrete
fill 380 147 599 380 150 599 minecraft:purple_terracotta
setblock 381 147 557 minecraft:purple_concrete
fill 381 147 584 383 147 584 minecraft:black_concrete
fill 384 147 582 384 148 583 minecraft:black_concrete
fill 386 147 557 386 150 557 minecraft:purple_terracotta
fill 396 147 599 397 147 599 minecraft:purple_concrete
fill 397 147 557 397 150 557 minecraft:purple_terracotta
setblock 398 147 557 minecraft:purple_concrete
setblock 400 147 599 minecraft:purple_concrete
fill 401 147 557 402 147 557 minecraft:purple_concrete
fill 401 147 599 401 150 599 minecraft:purple_terracotta
fill 412 147 599 412 150 599 minecraft:purple_terracotta
setblock 417 147 599 minecraft:purple_concrete
fill 418 147 557 418 150 557 minecraft:purple_terracotta
setblock 418 147 561 minecraft:purple_concrete
fill 418 147 568 418 150 568 minecraft:purple_terracotta
setblock 418 147 569 minecraft:purple_concrete
setblock 418 147 572 minecraft:purple_concrete
fill 418 147 588 418 150 589 minecraft:purple_terracotta
setblock 418 147 593 minecraft:purple_concrete
fill 376 148 557 376 148 558 minecraft:purple_concrete
fill 376 148 559 376 153 560 minecraft:purple_terracotta
fill 376 148 565 376 149 566 minecraft:purple_concrete
fill 376 148 567 376 153 568 minecraft:purple_terracotta
setblock 376 148 569 minecraft:purple_concrete
fill 376 148 571 376 150 571 minecraft:purple_terracotta
fill 376 148 577 376 149 578 minecraft:purple_concrete
fill 376 148 579 376 153 580 minecraft:purple_terracotta
setblock 376 148 585 minecraft:purple_terracotta
fill 376 148 586 376 149 586 minecraft:purple_concrete
fill 376 148 588 376 153 588 minecraft:purple_terracotta
fill 376 148 589 376 148 590 minecraft:purple_concrete
fill 376 148 591 376 153 591 minecraft:purple_terracotta
fill 376 148 597 376 149 598 minecraft:purple_concrete
fill 376 148 599 377 153 599 minecraft:purple_terracotta
fill 377 148 557 378 153 557 minecraft:purple_terracotta
fill 379 148 557 380 148 557 minecraft:purple_concrete
fill 381 148 557 381 153 557 minecraft:purple_terracotta
fill 381 148 584 382 148 584 minecraft:black_concrete
fill 382 148 585 383 148 585 minecraft:black_concrete
fill 383 148 584 383 154 584 minecraft:purple_concrete
fill 384 148 580 384 149 581 minecraft:black_concrete
setblock 384 148 584 minecraft:black_concrete
fill 386 148 599 387 148 599 minecraft:purple_concrete
fill 388 148 599 389 153 599 minecraft:purple_terracotta
fill 389 148 557 390 153 557 minecraft:purple_terracotta
fill 391 148 557 392 149 557 minecraft:purple_concrete
fill 395 148 599 395 149 599 minecraft:purple_concrete
fill 396 148 599 397 153 599 minecraft:purple_terracotta
fill 398 148 557 398 153 557 minecraft:purple_terracotta
setblock 398 148 599 minecraft:purple_concrete
setblock 400 148 557 minecraft:purple_concrete
fill 400 148 599 400 153 599 minecraft:purple_terracotta
fill 401 148 557 402 153 557 minecraft:purple_terracotta
fill 403 148 557 403 149 557 minecraft:purple_concrete
fill 406 148 599 407 149 599 minecraft:purple_concrete
fill 408 148 599 409 153 599 minecraft:purple_terracotta
fill 409 148 557 410 153 557 minecraft:purple_terracotta
fill 411 148 557 412 148 557 minecraft:purple_concrete
fill 417 148 599 417 153 599 minecraft:purple_terracotta
fill 418 148 560 418 153 561 minecraft:purple_terracotta
fill 418 148 562 418 149 563 minecraft:purple_concrete
fill 418 148 569 418 153 569 minecraft:purple_terracotta
fill 418 148 570 418 148 571 minecraft:purple_concrete
fill 418 148 572 418 153 572 minecraft:purple_terracotta
fill 418 148 574 418 149 574 minecraft:purple_concrete
fill 418 148 580 418 153 581 minecraft:purple_terracotta
fill 418 148 582 418 149 583 minecraft:purple_concrete
setblock 418 148 591 minecraft:purple_concrete
fill 418 148 592 418 153 593 minecraft:purple_terracotta
fill 418 148 594 418 149 595 minecraft:purple_concrete
fill 418 148 599 418 149 599 minecraft:purple_concrete
setblock 376 149 557 minecraft:purple_concrete
fill 376 149 558 376 152 558 minecraft:purple_terracotta
fill 376 149 569 376 152 569 minecraft:purple_terracotta
fill 376 149 573 376 151 573 minecraft:purple_terracotta
setblock 376 149 574 minecraft:purple_concrete
setblock 376 149 585 minecraft:purple_concrete
fill 376 149 589 376 152 590 minecraft:purple_terracotta
fill 379 149 557 379 152 557 minecraft:purple_terracotta
setblock 379 149 560 minecraft:light[level=12]
setblock 379 149 568 minecraft:light[level=12]
setblock 379 149 576 minecraft:light[level=12]
setblock 379 149 584 minecraft:light[level=12]
setblock 379 149 592 minecraft:light[level=12]
setblock 380 149 557 minecraft:purple_concrete
fill 380 149 580 380 149 581 minecraft:black_concrete
fill 380 149 584 380 150 584 minecraft:black_concrete
fill 381 149 579 382 149 579 minecraft:black_concrete
setblock 381 149 583 minecraft:black_concrete
fill 381 149 584 382 152 585 minecraft:purple_concrete
fill 382 149 583 384 153 583 minecraft:purple_concrete
fill 382 149 586 384 154 586 minecraft:purple_concrete
fill 383 149 557 384 149 557 minecraft:purple_concrete
fill 383 149 585 384 155 585 minecraft:purple_concrete
setblock 383 149 599 minecraft:purple_concrete
fill 384 149 582 385 149 582 minecraft:black_concrete
fill 384 149 584 385 154 584 minecraft:purple_concrete
setblock 385 149 583 minecraft:black_concrete
setblock 386 149 599 minecraft:purple_concrete
setblock 387 149 560 minecraft:light[level=12]
setblock 387 149 568 minecraft:light[level=12]
setblock 387 149 576 minecraft:light[level=12]
setblock 387 149 584 minecraft:light[level=12]
setblock 387 149 592 minecraft:light[level=12]
fill 387 149 599 387 152 599 minecraft:purple_terracotta
setblock 394 149 599 minecraft:purple_concrete
setblock 395 149 560 minecraft:light[level=12]
setblock 395 149 568 minecraft:light[level=12]
setblock 395 149 576 minecraft:light[level=12]
setblock 395 149 584 minecraft:light[level=12]
setblock 395 149 592 minecraft:light[level=12]
fill 398 149 599 398 152 599 minecraft:purple_terracotta
fill 400 149 557 400 152 557 minecraft:purple_terracotta
setblock 403 149 560 minecraft:light[level=12]
setblock 403 149 568 minecraft:light[level=12]
setblock 403 149 576 minecraft:light[level=12]
setblock 403 149 584 minecraft:light[level=12]
setblock 403 149 592 minecraft:light[level=12]
setblock 404 149 557 minecraft:purple_concrete
fill 411 149 557 411 152 557 minecraft:purple_terracotta
setblock 411 149 560 minecraft:light[level=12]
setblock 411 149 568 minecraft:light[level=12]
setblock 411 149 576 minecraft:light[level=12]
setblock 411 149 584 minecraft:light[level=12]
setblock 411 149 592 minecraft:light[level=12]
setblock 412 149 557 minecraft:purple_concrete
fill 414 149 599 415 149 599 minecraft:purple_concrete
setblock 415 149 557 minecraft:purple_concrete
fill 418 149 570 418 152 571 minecraft:purple_terracotta
setblock 418 149 575 minecraft:purple_concrete
setblock 418 149 586 minecraft:purple_concrete
fill 418 149 591 418 152 591 minecraft:purple_terracotta
fill 376 150 557 376 155 557 minecraft:purple_terracotta
fill 376 150 563 376 151 564 minecraft:purple_concrete
fill 376 150 565 376 155 566 minecraft:purple_terracotta
fill 376 150 574 376 151 574 minecraft:purple_terracotta
fill 376 150 575 376 150 576 minecraft:purple_concrete
fill 376 150 577 376 155 578 minecraft:purple_terracotta
fill 376 150 583 376 151 584 minecraft:purple_concrete
fill 376 150 585 376 155 586 minecraft:purple_terracotta
setblock 376 150 587 minecraft:purple_concrete
fill 376 150 595 376 151 596 minecraft:purple_concrete
fill 376 150 597 376 155 598 minecraft:purple_terracotta
fill 377 150 558 379 150 558 minecraft:obsidian
fill 377 150 560 377 150 562 minecraft:obsidian
fill 377 150 564 377 150 566 minecraft:obsidian
fill 377 150 568 377 150 570 minecraft:obsidian
fill 377 150 572 377 150 574 minecraft:obsidian
fill 377 150 576 377 150 578 minecraft:obsidian
fill 377 150 580 377 150 582 minecraft:obsidian
fill 377 150 584 377 150 586 minecraft:obsidian
fill 377 150 588 377 150 590 minecraft:obsidian
fill 377 150 592 377 150 594 minecraft:obsidian
fill 377 150 596 377 150 598 minecraft:obsidian
fill 379 150 598 381 150 598 minecraft:obsidian
fill 380 150 557 380 155 557 minecraft:purple_terracotta
fill 381 150 558 383 150 558 minecraft:obsidian
fill 381 150 581 381 150 582 minecraft:black_concrete
fill 381 150 583 381 152 583 minecraft:purple_concrete
fill 381 150 586 381 152 586 minecraft:purple_concrete
fill 381 150 599 381 151 599 minecraft:purple_concrete
setblock 382 150 557 minecraft:purple_concrete
fill 382 150 581 384 150 581 minecraft:black_concrete
fill 382 150 582 384 151 582 minecraft:purple_concrete
fill 382 150 587 384 154 587 minecraft:purple_concrete
fill 383 150 557 384 155 557 minecraft:purple_terracotta
setblock 383 150 580 minecraft:black_concrete
fill 383 150 598 385 150 598 minecraft:obsidian
fill 383 150 599 383 155 599 minecraft:purple_terracotta
fill 384 150 599 385 150 599 minecraft:purple_concrete
fill 385 150 557 385 151 557 minecraft:purple_concrete
fill 385 150 558 387 150 558 minecraft:obsidian
setblock 385 150 582 minecraft:black_concrete
fill 385 150 583 385 152 583 minecraft:purple_concrete
fill 385 150 585 385 155 586 minecraft:purple_concrete
fill 386 150 599 386 155 599 minecraft:purple_terracotta
fill 387 150 598 389 150 598 minecraft:obsidian
fill 389 150 558 391 150 558 minecraft:obsidian
fill 391 150 557 392 155 557 minecraft:purple_terracotta
fill 391 150 598 393 150 598 minecraft:obsidian
fill 392 150 599 393 151 599 minecraft:purple_concrete
fill 393 150 557 394 150 557 minecraft:purple_concrete
fill 393 150 558 395 150 558 minecraft:obsidian
fill 394 150 599 395 155 599 minecraft:purple_terracotta
fill 395 150 598 397 150 598 minecraft:obsidian
fill 397 150 558 399 150 558 minecraft:obsidian
fill 399 150 598 401 150 598 minecraft:obsidian
fill 401 150 558 403 150 558 minecraft:obsidian
fill 403 150 557 404 155 557 minecraft:purple_terracotta
fill 403 150 598 405 150 598 minecraft:obsidian
fill 404 150 599 405 150 599 minecraft:purple_concrete
fill 405 150 557 406 151 557 minecraft:purple_concrete
fill 405 150 558 407 150 558 minecraft:obsidian
fill 406 150 599 407 155 599 minecraft:purple_terracotta
fill 407 150 598 409 150 598 minecraft:obsidian
fill 409 150 558 411 150 558 minecraft:obsidian
fill 411 150 598 413 150 598 minecraft:obsidian
fill 412 150 557 412 155 557 minecraft:purple_terracotta
fill 413 150 557 414 150 557 minecraft:purple_concrete
fill 413 150 558 415 150 558 minecraft:obsidian
fill 413 150 599 413 151 599 minecraft:purple_concrete
fill 414 150 599 415 155 599 minecraft:purple_terracotta
fill 415 150 557 415 155 557 minecraft:purple_terracotta
fill 415 150 598 417 150 598 minecraft:obsidian
setblock 416 150 599 minecraft:purple_concrete
fill 417 150 557 417 151 557 minecraft:purple_concrete
fill 417 150 558 417 150 560 minecraft:obsidian
fill 417 150 562 417 150 564 minecraft:obsidian
fill 417 150 566 417 150 568 minecraft:obsidian
fill 417 150 570 417 150 572 minecraft:obsidian
fill 417 150 574 417 150 576 minecraft:obsidian
fill 417 150 578 417 150 580 minecraft:obsidian
fill 417 150 582 417 150 584 minecraft:obsidian
fill 417 150 586 417 150 588 minecraft:obsidian
fill 417 150 590 417 150 592 minecraft:obsidian
fill 417 150 594 417 150 596 minecraft:obsidian
fill 418 150 562 418 155 563 minecraft:purple_terracotta
fill 418 150 564 418 151 565 minecraft:purple_concrete
setblock 418 150 573 minecraft:purple_concrete
fill 418 150 574 418 155 575 minecraft:purple_terracotta
fill 418 150 576 418 151 577 minecraft:purple_concrete
fill 418 150 582 418 155 583 minecraft:purple_terracotta
fill 418 150 584 418 150 585 minecraft:purple_concrete
fill 418 150 586 418 155 586 minecraft:purple_terracotta
fill 418 150 594 418 155 595 minecraft:purple_terracotta
fill 418 150 596 418 151 597 minecraft:purple_concrete
fill 418 150 599 418 155 599 minecraft:purple_terracotta
fill 376 151 571 376 151 572 minecraft:purple_concrete
setblock 376 151 575 minecraft:purple_concrete
fill 376 151 576 376 154 576 minecraft:purple_terracotta
fill 376 151 587 376 154 587 minecraft:purple_terracotta
setblock 376 151 592 minecraft:purple_concrete
setblock 380 151 599 minecraft:purple_concrete
setblock 381 151 582 minecraft:black_concrete
fill 382 151 557 382 154 557 minecraft:purple_terracotta
fill 382 151 581 383 151 581 minecraft:black_concrete
fill 383 151 588 385 156 588 minecraft:purple_concrete
fill 384 151 599 385 154 599 minecraft:purple_terracotta
fill 385 151 587 386 157 587 minecraft:purple_concrete
setblock 386 151 557 minecraft:purple_concrete
fill 386 151 585 386 154 586 minecraft:purple_concrete
fill 393 151 557 393 154 557 minecraft:purple_terracotta
setblock 394 151 557 minecraft:purple_concrete
setblock 397 151 557 minecraft:purple_concrete
setblock 401 151 599 minecraft:purple_concrete
fill 403 151 564 403 152 565 minecraft:amethyst_block
fill 404 151 564 404 152 564 minecraft:amethyst_block
setblock 404 151 599 minecraft:purple_concrete
fill 405 151 599 405 154 599 minecraft:purple_terracotta
setblock 412 151 599 minecraft:purple_concrete
fill 413 151 557 414 154 557 minecraft:purple_terracotta
fill 416 151 599 416 154 599 minecraft:purple_terracotta
setblock 418 151 557 minecraft:purple_concrete
setblock 418 151 568 minecraft:purple_concrete
fill 418 151 573 418 154 573 minecraft:purple_terracotta
fill 418 151 584 418 154 584 minecraft:purple_terracotta
setblock 418 151 585 minecraft:purple_concrete
fill 418 151 588 418 151 589 minecraft:purple_concrete
fill 376 152 561 376 153 562 minecraft:purple_concrete
fill 376 152 563 376 157 564 minecraft:purple_terracotta
fill 376 152 570 376 153 570 minecraft:purple_concrete
fill 376 152 571 376 153 572 minecraft:purple_terracotta
fill 376 152 573 376 152 574 minecraft:purple_concrete
fill 376 152 575 376 157 575 minecraft:purple_terracotta
fill 376 152 581 376 153 582 minecraft:purple_concrete
fill 376 152 583 376 157 584 minecraft:purple_terracotta
fill 376 152 592 376 157 592 minecraft:purple_terracotta
fill 376 152 593 376 152 594 minecraft:purple_concrete
fill 376 152 595 376 157 596 minecraft:purple_terracotta
fill 378 152 599 379 153 599 minecraft:purple_concrete
fill 380 152 599 381 157 599 minecraft:purple_terracotta
setblock 382 152 582 minecraft:black_concrete
setblock 382 152 599 minecraft:purple_concrete
fill 383 152 568 385 153 568 minecraft:obsidian
setblock 383 152 582 minecraft:purple_concrete
fill 384 152 567 384 153 567 minecraft:obsidian
fill 384 152 569 384 153 569 minecraft:obsidian
fill 384 152 589 386 157 589 minecraft:purple_concrete
fill 385 152 557 386 157 557 minecraft:purple_terracotta
fill 386 152 588 386 158 588 minecraft:purple_concrete
fill 387 152 557 388 153 557 minecraft:purple_concrete
fill 389 152 586 391 153 586 minecraft:obsidian
fill 390 152 585 390 153 585 minecraft:obsidian
fill 390 152 587 390 153 587 minecraft:obsidian
fill 390 152 599 391 153 599 minecraft:purple_concrete
fill 392 152 599 393 157 599 minecraft:purple_terracotta
fill 394 152 557 394 157 557 minecraft:purple_terracotta
fill 395 152 557 396 152 557 minecraft:purple_concrete
fill 397 152 557 397 157 557 minecraft:purple_terracotta
fill 399 152 557 399 153 557 minecraft:purple_concrete
fill 399 152 599 399 153 599 minecraft:purple_concrete
fill 401 152 599 401 157 599 minecraft:purple_terracotta
fill 402 152 599 403 152 599 minecraft:purple_concrete
fill 404 152 599 404 157 599 minecraft:purple_terracotta
fill 405 152 557 406 157 557 minecraft:purple_terracotta
fill 407 152 557 408 153 557 minecraft:purple_concrete
fill 410 152 599 411 153 599 minecraft:purple_concrete
fill 412 152 599 413 157 599 minecraft:purple_terracotta
setblock 416 152 557 minecraft:purple_concrete
fill 417 152 557 418 157 557 minecraft:purple_terracotta
fill 418 152 558 418 153 559 minecraft:purple_concrete
fill 418 152 564 418 157 565 minecraft:purple_terracotta
fill 418 152 566 418 152 567 minecraft:purple_concrete
fill 418 152 568 418 157 568 minecraft:purple_terracotta
fill 418 152 576 418 157 577 minecraft:purple_terracotta
fill 418 152 578 418 153 579 minecraft:purple_concrete
fill 418 152 585 418 157 585 minecraft:purple_terracotta
setblock 418 152 587 minecraft:purple_concrete
fill 418 152 588 418 157 589 minecraft:purple_terracotta
fill 418 152 590 418 153 590 minecraft:purple_concrete
fill 418 152 596 418 157 597 minecraft:purple_terracotta
setblock 418 152 598 minecraft:purple_concrete
setblock 376 153 558 minecraft:purple_concrete
setblock 376 153 569 minecraft:purple_concrete
fill 376 153 573 376 155 574 minecraft:purple_terracotta
fill 376 153 589 376 153 590 minecraft:purple_concrete
setblock 376 153 593 minecraft:purple_concrete
fill 376 153 594 376 156 594 minecraft:purple_terracotta
setblock 379 153 557 minecraft:purple_concrete
fill 381 153 585 382 153 585 minecraft:purple_concrete
setblock 382 153 584 minecraft:purple_concrete
fill 382 153 588 382 154 588 minecraft:purple_concrete
fill 382 153 599 382 156 599 minecraft:purple_terracotta
fill 383 153 589 383 156 589 minecraft:purple_concrete
fill 385 153 590 386 158 590 minecraft:purple_concrete
fill 387 153 586 387 155 589 minecraft:purple_concrete
setblock 387 153 599 minecraft:purple_concrete
fill 395 153 557 396 156 557 minecraft:purple_terracotta
setblock 398 153 599 minecraft:purple_concrete
setblock 400 153 557 minecraft:purple_concrete
fill 402 153 599 403 156 599 minecraft:purple_terracotta
setblock 411 153 557 minecraft:purple_concrete
fill 416 153 557 416 156 557 minecraft:purple_terracotta
fill 418 153 566 418 156 566 minecraft:purple_terracotta
setblock 418 153 567 minecraft:purple_concrete
fill 418 153 570 418 153 571 minecraft:purple_concrete
fill 418 153 587 418 156 587 minecraft:purple_terracotta
setblock 418 153 591 minecraft:purple_concrete
fill 418 153 598 418 156 598 minecraft:purple_terracotta
fill 376 154 558 376 159 558 minecraft:purple_terracotta
fill 376 154 559 376 154 560 minecraft:purple_concrete
fill 376 154 561 376 156 562 minecraft:purple_terracotta
fill 376 154 567 376 155 568 minecraft:purple_concrete
fill 376 154 569 376 159 570 minecraft:purple_terracotta
setblock 376 154 571 minecraft:purple_concrete
fill 376 154 572 376 157 572 minecraft:purple_terracotta
fill 376 154 579 376 154 580 minecraft:purple_concrete
fill 376 154 581 376 159 582 minecraft:purple_terracotta
fill 376 154 588 376 155 588 minecraft:purple_concrete
fill 376 154 589 376 159 590 minecraft:purple_terracotta
setblock 376 154 591 minecraft:purple_concrete
fill 376 154 593 376 159 593 minecraft:purple_terracotta
fill 376 154 599 377 155 599 minecraft:purple_concrete
fill 377 154 557 378 154 557 minecraft:purple_concrete
fill 378 154 599 379 159 599 minecraft:purple_terracotta
fill 379 154 557 379 159 557 minecraft:purple_terracotta
fill 381 154 557 381 155 557 minecraft:purple_concrete
setblock 382 154 585 minecraft:purple_concrete
fill 384 154 590 384 157 590 minecraft:purple_concrete
fill 386 154 591 386 159 591 minecraft:purple_concrete
fill 387 154 557 388 159 557 minecraft:purple_terracotta
fill 387 154 590 388 156 590 minecraft:purple_concrete
fill 387 154 599 387 159 599 minecraft:purple_terracotta
fill 388 154 588 388 157 589 minecraft:purple_concrete
fill 388 154 599 389 154 599 minecraft:purple_concrete
fill 389 154 557 390 155 557 minecraft:purple_concrete
fill 390 154 599 391 159 599 minecraft:purple_terracotta
fill 396 154 599 397 155 599 minecraft:purple_concrete
setblock 398 154 557 minecraft:purple_concrete
fill 398 154 599 399 159 599 minecraft:purple_terracotta
fill 399 154 557 400 159 557 minecraft:purple_terracotta
setblock 400 154 599 minecraft:purple_concrete
fill 401 154 557 402 155 557 minecraft:purple_concrete
fill 407 154 557 408 159 557 minecraft:purple_terracotta
fill 408 154 599 409 155 599 minecraft:purple_concrete
fill 409 154 557 410 154 557 minecraft:purple_concrete
fill 410 154 599 411 159 599 minecraft:purple_terracotta
fill 411 154 557 411 159 557 minecraft:purple_terracotta
fill 417 154 599 417 155 599 minecraft:purple_concrete
fill 418 154 558 418 159 559 minecraft:purple_terracotta
fill 418 154 560 418 155 561 minecraft:purple_concrete
fill 418 154 567 418 159 567 minecraft:purple_terracotta
setblock 418 154 569 minecraft:purple_concrete
fill 418 154 570 418 159 571 minecraft:purple_terracotta
fill 418 154 572 418 155 572 minecraft:purple_concrete
fill 418 154 578 418 159 579 minecraft:purple_terracotta
fill 418 154 580 418 154 581 minecraft:purple_concrete
fill 418 154 590 418 159 591 minecraft:purple_terracotta
fill 418 154 592 418 155 593 minecraft:purple_concrete
setblock 376 155 559 minecraft:purple_concrete
fill 376 155 560 376 158 560 minecraft:purple_terracotta
fill 376 155 571 376 157 571 minecraft:purple_terracotta
setblock 376 155 576 minecraft:purple_concrete
setblock 376 155 579 minecraft:purple_concrete
fill 376 155 580 376 158 580 minecraft:purple_terracotta
setblock 376 155 587 minecraft:purple_concrete
fill 376 155 591 376 158 591 minecraft:purple_terracotta
fill 377 155 557 378 157 557 minecraft:purple_terracotta
setblock 382 155 557 minecraft:purple_concrete
fill 383 155 584 383 157 584 minecraft:amethyst_block
fill 383 155 586 384 155 587 minecraft:purple_concrete
fill 384 155 599 385 155 599 minecraft:purple_concrete
fill 385 155 591 385 158 591 minecraft:purple_concrete
fill 386 155 586 386 156 586 minecraft:purple_concrete
fill 387 155 591 388 156 591 minecraft:purple_concrete
fill 388 155 587 388 157 587 minecraft:purple_concrete
setblock 388 155 599 minecraft:purple_concrete
fill 389 155 589 389 156 590 minecraft:purple_concrete
fill 389 155 599 389 158 599 minecraft:purple_terracotta
setblock 393 155 557 minecraft:purple_concrete
fill 398 155 557 398 158 557 minecraft:purple_terracotta
fill 400 155 599 400 158 599 minecraft:purple_terracotta
setblock 405 155 599 minecraft:purple_concrete
fill 409 155 557 409 158 557 minecraft:purple_terracotta
setblock 410 155 557 minecraft:purple_concrete
fill 413 155 557 414 155 557 minecraft:purple_concrete
setblock 416 155 599 minecraft:purple_concrete
fill 418 155 569 418 158 569 minecraft:purple_terracotta
setblock 418 155 573 minecraft:purple_concrete
fill 418 155 580 418 158 580 minecraft:purple_terracotta
setblock 418 155 581 minecraft:purple_concrete
setblock 418 155 584 minecraft:purple_concrete
setblock 376 156 557 minecraft:purple_concrete
fill 376 156 559 376 158 559 minecraft:purple_terracotta
fill 376 156 565 376 157 566 minecraft:purple_concrete
fill 376 156 567 376 161 568 minecraft:purple_terracotta
setblock 376 156 573 minecraft:purple_terracotta
fill 376 156 574 376 157 574 minecraft:purple_concrete
fill 376 156 576 376 161 576 minecraft:purple_terracotta
fill 376 156 577 376 156 578 minecraft:purple_concrete
fill 376 156 579 376 161 579 minecraft:purple_terracotta
fill 376 156 585 376 157 586 minecraft:purple_concrete
fill 376 156 587 376 161 588 minecraft:purple_terracotta
fill 376 156 597 376 156 598 minecraft:purple_concrete
fill 376 156 599 377 161 599 minecraft:purple_terracotta
fill 377 156 558 379 156 558 minecraft:obsidian
fill 377 156 560 377 156 562 minecraft:obsidian
fill 377 156 564 377 156 566 minecraft:obsidian
fill 377 156 568 377 156 570 minecraft:obsidian
fill 377 156 572 377 156 574 minecraft:obsidian
fill 377 156 576 377 156 578 minecraft:obsidian
fill 377 156 580 377 156 582 minecraft:obsidian
fill 377 156 584 377 156 586 minecraft:obsidian
fill 377 156 588 377 156 590 minecraft:obsidian
fill 377 156 592 377 156 594 minecraft:obsidian
fill 377 156 596 377 156 598 minecraft:obsidian
fill 379 156 598 381 156 598 minecraft:obsidian
setblock 380 156 557 minecraft:purple_concrete
fill 381 156 557 382 161 557 minecraft:purple_terracotta
fill 381 156 558 383 156 558 minecraft:obsidian
fill 383 156 557 384 157 557 minecraft:purple_concrete
fill 383 156 585 383 157 585 minecraft:amethyst_block
fill 383 156 587 384 156 587 minecraft:purple_concrete
fill 383 156 598 385 156 598 minecraft:obsidian
fill 383 156 599 383 157 599 minecraft:purple_concrete
fill 384 156 586 385 156 586 minecraft:purple_concrete
fill 384 156 599 385 161 599 minecraft:purple_terracotta
fill 385 156 558 387 156 558 minecraft:obsidian
fill 386 156 592 389 156 592 minecraft:purple_concrete
setblock 386 156 599 minecraft:purple_concrete
fill 387 156 587 387 157 589 minecraft:purple_concrete
fill 387 156 598 389 156 598 minecraft:obsidian
fill 388 156 599 388 161 599 minecraft:purple_terracotta
fill 389 156 557 390 161 557 minecraft:purple_terracotta
fill 389 156 558 391 156 558 minecraft:obsidian
fill 389 156 588 389 158 588 minecraft:purple_concrete
setblock 389 156 591 minecraft:purple_concrete
setblock 390 156 590 minecraft:purple_concrete
fill 391 156 557 392 156 557 minecraft:purple_concrete
fill 391 156 598 393 156 598 minecraft:obsidian
fill 393 156 557 393 161 557 minecraft:purple_terracotta
fill 393 156 558 395 156 558 minecraft:obsidian
fill 394 156 599 395 157 599 minecraft:purple_concrete
fill 395 156 598 397 156 598 minecraft:obsidian
fill 396 156 599 397 161 599 minecraft:purple_terracotta
fill 397 156 558 399 156 558 minecraft:obsidian
fill 399 156 598 401 156 598 minecraft:obsidian
fill 401 156 557 402 161 557 minecraft:purple_terracotta
fill 401 156 558 403 156 558 minecraft:obsidian
fill 403 156 557 404 157 557 minecraft:purple_concrete
fill 403 156 598 405 156 598 minecraft:obsidian
fill 405 156 558 407 156 558 minecraft:obsidian
fill 405 156 599 405 161 599 minecraft:purple_terracotta
fill 406 156 599 407 156 599 minecraft:purple_concrete
fill 407 156 598 409 156 598 minecraft:obsidian
fill 408 156 599 409 161 599 minecraft:purple_terracotta
fill 409 156 558 411 156 558 minecraft:obsidian
fill 410 156 557 410 161 557 minecraft:purple_terracotta
fill 411 156 598 413 156 598 minecraft:obsidian
setblock 412 156 557 minecraft:purple_concrete
fill 413 156 557 414 161 557 minecraft:purple_terracotta
fill 413 156 558 415 156 558 minecraft:obsidian
fill 414 156 599 415 157 599 minecraft:purple_concrete
fill 415 156 557 415 157 557 minecraft:purple_concrete
fill 415 156 598 417 156 598 minecraft:obsidian
fill 416 156 599 417 161 599 minecraft:purple_terracotta
fill 417 156 558 417 156 560 minecraft:obsidian
fill 417 156 562 417 156 564 minecraft:obsidian
fill 417 156 566 417 156 568 minecraft:obsidian
fill 417 156 570 417 156 572 minecraft:obsidian
fill 417 156 574 417 156 576 minecraft:obsidian
fill 417 156 578 417 156 580 minecraft:obsidian
fill 417 156 582 417 156 584 minecraft:obsidian
fill 417 156 586 417 156 588 minecraft:obsidian
fill 417 156 590 417 156 592 minecraft:obsidian
fill 417 156 594 417 156 596 minecraft:obsidian
fill 418 156 560 418 161 561 minecraft:purple_terracotta
fill 418 156 562 418 156 563 minecraft:purple_concrete
fill 418 156 572 418 161 573 minecraft:purple_terracotta
fill 418 156 574 418 157 575 minecraft:purple_concrete
fill 418 156 581 418 161 581 minecraft:purple_terracotta
fill 418 156 582 418 156 583 minecraft:purple_concrete
fill 418 156 584 418 161 584 minecraft:purple_terracotta
fill 418 156 586 418 157 586 minecraft:purple_concrete
fill 418 156 592 418 161 593 minecraft:purple_terracotta
fill 418 156 594 418 157 595 minecraft:purple_concrete
setblock 418 156 599 minecraft:purple_concrete
fill 376 157 557 376 160 557 minecraft:purple_terracotta
fill 376 157 561 376 159 561 minecraft:purple_terracotta
setblock 376 157 562 minecraft:purple_concrete
setblock 376 157 573 minecraft:purple_concrete
fill 376 157 577 376 160 578 minecraft:purple_terracotta
setblock 376 157 594 minecraft:purple_concrete
setblock 376 157 597 minecraft:purple_concrete
fill 376 157 598 376 160 598 minecraft:purple_terracotta
setblock 379 157 560 minecraft:light[level=12]
setblock 379 157 568 minecraft:light[level=12]
setblock 379 157 576 minecraft:light[level=12]
setblock 379 157 584 minecraft:light[level=12]
setblock 379 157 592 minecraft:light[level=12]
fill 380 157 557 380 159 557 minecraft:purple_terracotta
setblock 382 157 599 minecraft:purple_concrete
fill 384 157 588 385 157 588 minecraft:purple_concrete
fill 386 157 592 387 157 592 minecraft:purple_concrete
fill 386 157 599 386 160 599 minecraft:purple_terracotta
setblock 387 157 560 minecraft:light[level=12]
setblock 387 157 568 minecraft:light[level=12]
setblock 387 157 576 minecraft:light[level=12]
setblock 387 157 584 minecraft:light[level=12]
fill 387 157 590 387 157 591 minecraft:purple_concrete
fill 388 157 590 390 161 592 minecraft:black_concrete
setblock 388 157 593 minecraft:purple_concrete
fill 389 157 589 390 157 589 minecraft:purple_concrete
fill 389 157 593 389 162 593 minecraft:black_concrete
fill 391 157 557 391 160 557 minecraft:purple_terracotta
setblock 392 157 557 minecraft:purple_concrete
fill 395 157 557 396 157 557 minecraft:purple_concrete
setblock 395 157 560 minecraft:light[level=12]
setblock 395 157 568 minecraft:light[level=12]
setblock 395 157 576 minecraft:light[level=12]
setblock 395 157 584 minecraft:light[level=12]
setblock 395 157 592 minecraft:light[level=12]
fill 402 157 599 403 157 599 minecraft:purple_concrete
setblock 403 157 560 minecraft:light[level=12]
setblock 403 157 568 minecraft:light[level=12]
setblock 403 157 576 minecraft:light[level=12]
setblock 403 157 584 minecraft:light[level=12]
setblock 403 157 592 minecraft:light[level=12]
setblock 406 157 599 minecraft:purple_concrete
fill 407 157 599 407 160 599 minecraft:purple_terracotta
setblock 411 157 560 minecraft:light[level=12]
setblock 411 157 568 minecraft:light[level=12]
setblock 411 157 576 minecraft:light[level=12]
setblock 411 157 584 minecraft:light[level=12]
setblock 411 157 592 minecraft:light[level=12]
fill 412 157 557 412 160 557 minecraft:purple_terracotta
setblock 416 157 557 minecraft:purple_concrete
fill 418 157 562 418 160 562 minecraft:purple_terracotta
setblock 418 157 563 minecraft:purple_concrete
setblock 418 157 566 minecraft:purple_concrete
fill 418 157 582 418 160 583 minecraft:purple_terracotta
setblock 418 157 587 minecraft:purple_concrete
setblock 418 157 598 minecraft:purple_concrete
fill 418 157 599 418 160 599 minecraft:purple_terracotta
fill 376 158 562 376 159 562 minecraft:purple_terracotta
fill 376 158 563 376 158 564 minecraft:purple_concrete
fill 376 158 565 376 175 566 minecraft:purple_terracotta
fill 376 158 571 376 159 572 minecraft:purple_concrete
fill 376 158 573 376 176 574 minecraft:purple_terracotta
setblock 376 158 575 minecraft:purple_concrete
fill 376 158 583 376 159 584 minecraft:purple_concrete
fill 376 158 585 376 175 586 minecraft:purple_terracotta
fill 376 158 592 376 159 592 minecraft:purple_concrete
fill 376 158 594 376 179 594 minecraft:purple_terracotta
fill 376 158 595 376 158 596 minecraft:purple_concrete
fill 376 158 597 376 175 597 minecraft:purple_terracotta
fill 377 158 557 377 159 557 minecraft:purple_concrete
setblock 378 158 557 minecraft:purple_terracotta
fill 380 158 599 381 159 599 minecraft:purple_concrete
fill 382 158 599 383 176 599 minecraft:purple_terracotta
fill 383 158 557 384 175 557 minecraft:purple_terracotta
fill 385 158 557 386 159 557 minecraft:purple_concrete
fill 385 158 588 385 158 589 minecraft:purple_concrete
fill 386 158 589 387 159 589 minecraft:purple_concrete
fill 386 158 592 386 159 592 minecraft:purple_concrete
fill 387 158 588 388 159 588 minecraft:purple_concrete
fill 387 158 590 387 160 592 minecraft:black_concrete
setblock 387 158 593 minecraft:purple_concrete
fill 388 158 589 390 160 589 minecraft:black_concrete
fill 388 158 593 388 161 593 minecraft:black_concrete
fill 390 158 593 391 161 593 minecraft:black_concrete
fill 391 158 590 391 161 592 minecraft:black_concrete
fill 392 158 557 392 175 557 minecraft:purple_terracotta
fill 392 158 599 393 158 599 minecraft:purple_concrete
setblock 394 158 557 minecraft:purple_concrete
fill 394 158 599 395 175 599 minecraft:purple_terracotta
fill 395 158 557 396 176 557 minecraft:purple_terracotta
fill 397 158 557 397 159 557 minecraft:purple_concrete
fill 401 158 599 401 159 599 minecraft:purple_concrete
fill 402 158 599 403 179 599 minecraft:purple_terracotta
fill 403 158 557 404 175 557 minecraft:purple_terracotta
setblock 404 158 599 minecraft:purple_concrete
fill 405 158 557 406 158 557 minecraft:purple_concrete
fill 406 158 599 406 175 599 minecraft:purple_terracotta
fill 412 158 599 413 159 599 minecraft:purple_concrete
fill 414 158 599 415 176 599 minecraft:purple_terracotta
fill 415 158 557 416 176 557 minecraft:purple_terracotta
fill 417 158 557 418 159 557 minecraft:purple_concrete
fill 418 158 563 418 175 563 minecraft:purple_terracotta
fill 418 158 564 418 158 565 minecraft:purple_concrete
fill 418 158 566 418 179 566 minecraft:purple_terracotta
fill 418 158 568 418 159 568 minecraft:purple_concrete
fill 418 158 574 418 175 575 minecraft:purple_terracotta
fill 418 158 576 418 159 577 minecraft:purple_concrete
setblock 418 158 585 minecraft:purple_concrete
fill 418 158 586 418 176 587 minecraft:purple_terracotta
fill 418 158 588 418 159 589 minecraft:purple_concrete
fill 418 158 594 418 175 595 minecraft:purple_terracotta
fill 418 158 596 418 158 597 minecraft:purple_concrete
fill 418 158 598 418 179 598 minecraft:purple_terracotta
fill 376 159 559 376 159 560 minecraft:purple_concrete
setblock 376 159 563 minecraft:purple_concrete
fill 376 159 564 376 162 564 minecraft:purple_terracotta
fill 376 159 575 376 162 575 minecraft:purple_terracotta
setblock 376 159 580 minecraft:purple_concrete
setblock 376 159 591 minecraft:purple_concrete
fill 376 159 595 376 162 596 minecraft:purple_terracotta
setblock 378 159 557 minecraft:purple_concrete
setblock 386 159 590 minecraft:purple_concrete
setblock 387 159 593 minecraft:black_concrete
fill 389 159 594 391 161 594 minecraft:black_concrete
setblock 389 159 599 minecraft:purple_concrete
fill 392 159 590 392 160 593 minecraft:black_concrete
setblock 392 159 599 minecraft:purple_concrete
fill 393 159 599 393 162 599 minecraft:purple_terracotta
fill 394 159 557 394 162 557 minecraft:purple_terracotta
setblock 398 159 557 minecraft:purple_concrete
setblock 400 159 599 minecraft:purple_concrete
fill 404 159 599 404 162 599 minecraft:purple_terracotta
fill 405 159 557 405 162 557 minecraft:purple_terracotta
setblock 406 159 557 minecraft:purple_concrete
setblock 409 159 557 minecraft:purple_concrete
fill 418 159 564 418 162 565 minecraft:purple_terracotta
setblock 418 159 569 minecraft:purple_concrete
setblock 418 159 580 minecraft:purple_concrete
fill 418 159 585 418 162 585 minecraft:purple_terracotta
fill 418 159 596 418 162 596 minecraft:purple_terracotta
setblock 418 159 597 minecraft:purple_concrete
fill 376 160 558 376 161 558 minecraft:purple_concrete
fill 376 160 559 376 161 560 minecraft:purple_terracotta
fill 376 160 561 376 160 562 minecraft:purple_concrete
fill 376 160 563 376 177 563 minecraft:purple_terracotta
fill 376 160 569 376 161 570 minecraft:purple_concrete
fill 376 160 571 376 173 572 minecraft:purple_terracotta
fill 376 160 580 376 173 580 minecraft:purple_terracotta
fill 376 160 581 376 160 582 minecraft:purple_concrete
fill 376 160 583 376 177 584 minecraft:purple_terracotta
fill 376 160 589 376 161 590 minecraft:purple_concrete
fill 376 160 591 376 173 592 minecraft:purple_terracotta
setblock 376 160 593 minecraft:purple_concrete
fill 377 160 557 378 173 557 minecraft:purple_terracotta
fill 378 160 599 379 161 599 minecraft:purple_concrete
fill 379 160 557 380 161 557 minecraft:purple_concrete
fill 380 160 599 381 173 599 minecraft:purple_terracotta
fill 385 160 557 386 173 557 minecraft:purple_terracotta
fill 387 160 557 388 160 557 minecraft:purple_concrete
setblock 387 160 589 minecraft:purple_concrete
fill 387 160 599 387 161 599 minecraft:purple_concrete
fill 389 160 599 389 173 599 minecraft:purple_terracotta
fill 390 160 599 391 160 599 minecraft:purple_concrete
fill 392 160 594 393 160 594 minecraft:black_concrete
fill 392 160 599 392 177 599 minecraft:purple_terracotta
fill 393 160 591 393 160 593 minecraft:black_concrete
fill 397 160 557 398 173 557 minecraft:purple_terracotta
fill 398 160 599 399 161 599 minecraft:purple_concrete
fill 399 160 557 400 161 557 minecraft:purple_concrete
fill 400 160 599 401 173 599 minecraft:purple_terracotta
fill 406 160 557 406 177 557 minecraft:purple_terracotta
fill 407 160 557 408 160 557 minecraft:purple_concrete
fill 409 160 557 409 173 557 minecraft:purple_terracotta
fill 410 160 599 411 160 599 minecraft:purple_concrete
fill 411 160 557 411 161 557 minecraft:purple_concrete
fill 412 160 599 413 173 599 minecraft:purple_terracotta
fill 417 160 557 418 173 557 minecraft:purple_terracotta
fill 418 160 558 418 161 559 minecraft:purple_concrete
setblock 418 160 567 minecraft:purple_concrete
fill 418 160 568 418 173 569 minecraft:purple_terracotta
fill 418 160 570 418 161 571 minecraft:purple_concrete
fill 418 160 576 418 177 577 minecraft:purple_terracotta
fill 418 160 578 418 160 579 minecraft:purple_concrete
fill 418 160 580 418 173 580 minecraft:purple_terracotta
fill 418 160 588 418 173 589 minecraft:purple_terracotta
fill 418 160 590 418 161 591 minecraft:purple_concrete
fill 418 160 597 418 177 597 minecraft:purple_terracotta
setblock 376 161 557 minecraft:purple_concrete
fill 376 161 561 376 179 562 minecraft:purple_terracotta
fill 376 161 577 376 161 578 minecraft:purple_concrete
setblock 376 161 581 minecraft:purple_concrete
fill 376 161 582 376 179 582 minecraft:purple_terracotta
fill 376 161 593 376 179 593 minecraft:purple_terracotta
setblock 376 161 598 minecraft:purple_concrete
setblock 386 161 599 minecraft:purple_concrete
fill 387 161 557 387 179 557 minecraft:purple_terracotta
setblock 388 161 557 minecraft:purple_concrete
fill 390 161 599 391 179 599 minecraft:purple_terracotta
setblock 391 161 557 minecraft:purple_concrete
fill 391 161 595 393 161 595 minecraft:black_concrete
fill 392 161 590 393 161 591 minecraft:black_concrete
fill 392 161 592 394 163 594 minecraft:purple_concrete
setblock 394 161 591 minecraft:black_concrete
fill 395 161 593 395 163 593 minecraft:purple_concrete
fill 407 161 557 408 179 557 minecraft:purple_terracotta
setblock 407 161 599 minecraft:purple_concrete
setblock 410 161 599 minecraft:purple_concrete
fill 411 161 599 411 179 599 minecraft:purple_terracotta
setblock 412 161 557 minecraft:purple_concrete
setblock 418 161 562 minecraft:purple_concrete
fill 418 161 567 418 179 567 minecraft:purple_terracotta
fill 418 161 578 418 179 578 minecraft:purple_terracotta
setblock 418 161 579 minecraft:purple_concrete
fill 418 161 582 418 161 583 minecraft:purple_concrete
setblock 418 161 599 minecraft:purple_concrete
fill 376 162 557 376 175 558 minecraft:purple_terracotta
setblock 376 162 559 minecraft:purple_concrete
fill 376 162 560 376 173 560 minecraft:purple_terracotta
fill 376 162 567 376 162 568 minecraft:purple_concrete
fill 376 162 569 376 175 570 minecraft:purple_terracotta
fill 376 162 576 376 163 576 minecraft:purple_concrete
fill 376 162 577 376 175 578 minecraft:purple_terracotta
setblock 376 162 579 minecraft:purple_concrete
fill 376 162 581 376 179 581 minecraft:purple_terracotta
fill 376 162 587 376 163 588 minecraft:purple_concrete
fill 376 162 589 376 175 590 minecraft:purple_terracotta
fill 376 162 598 376 175 598 minecraft:purple_terracotta
fill 376 162 599 377 162 599 minecraft:purple_concrete
fill 377 162 558 379 162 558 minecraft:obsidian
fill 377 162 560 377 162 562 minecraft:obsidian
fill 377 162 564 377 162 566 minecraft:obsidian
fill 377 162 568 377 162 570 minecraft:obsidian
fill 377 162 572 377 162 574 minecraft:obsidian
fill 377 162 576 377 162 578 minecraft:obsidian
fill 377 162 580 377 162 582 minecraft:obsidian
fill 377 162 584 377 162 586 minecraft:obsidian
fill 377 162 588 377 162 590 minecraft:obsidian
fill 377 162 592 377 162 594 minecraft:obsidian
fill 377 162 596 377 162 598 minecraft:obsidian
fill 378 162 599 379 179 599 minecraft:purple_terracotta
fill 379 162 557 380 175 557 minecraft:purple_terracotta
fill 379 162 598 381 162 598 minecraft:obsidian
fill 381 162 557 382 163 557 minecraft:purple_concrete
fill 381 162 558 383 162 558 minecraft:obsidian
fill 383 162 598 385 162 598 minecraft:obsidian
fill 384 162 599 385 163 599 minecraft:purple_concrete
fill 385 162 558 387 162 558 minecraft:obsidian
fill 386 162 599 387 175 599 minecraft:purple_terracotta
fill 387 162 598 389 162 598 minecraft:obsidian
fill 388 162 557 388 179 557 minecraft:purple_terracotta
setblock 388 162 599 minecraft:purple_concrete
fill 389 162 557 390 162 557 minecraft:purple_concrete
fill 389 162 558 391 162 558 minecraft:obsidian
fill 389 162 590 390 162 592 minecraft:black_concrete
fill 390 162 593 390 163 594 minecraft:black_concrete
fill 391 162 557 391 175 557 minecraft:purple_terracotta
fill 391 162 590 391 162 591 minecraft:black_concrete
fill 391 162 592 391 163 594 minecraft:purple_concrete
fill 391 162 595 391 163 595 minecraft:black_concrete
fill 391 162 598 393 162 598 minecraft:obsidian
fill 392 162 590 393 162 590 minecraft:black_concrete
fill 392 162 591 394 163 591 minecraft:purple_concrete
fill 392 162 595 395 163 595 minecraft:purple_concrete
fill 393 162 557 393 163 557 minecraft:purple_concrete
fill 393 162 558 395 162 558 minecraft:obsidian
fill 395 162 592 395 163 592 minecraft:purple_concrete
fill 395 162 594 395 163 594 minecraft:purple_concrete
fill 395 162 598 397 162 598 minecraft:obsidian
fill 396 162 593 396 163 593 minecraft:purple_concrete
fill 396 162 599 397 163 599 minecraft:purple_concrete
fill 397 162 558 399 162 558 minecraft:obsidian
fill 398 162 599 399 175 599 minecraft:purple_terracotta
fill 399 162 557 400 175 557 minecraft:purple_terracotta
fill 399 162 598 401 162 598 minecraft:obsidian
fill 401 162 557 402 163 557 minecraft:purple_concrete
fill 401 162 558 403 162 558 minecraft:obsidian
fill 403 162 598 405 162 598 minecraft:obsidian
fill 405 162 558 407 162 558 minecraft:obsidian
fill 405 162 599 405 163 599 minecraft:purple_concrete
fill 407 162 598 409 162 598 minecraft:obsidian
fill 407 162 599 407 175 599 minecraft:purple_terracotta
fill 408 162 599 409 162 599 minecraft:purple_concrete
fill 409 162 558 411 162 558 minecraft:obsidian
setblock 410 162 557 minecraft:purple_concrete
fill 410 162 599 410 179 599 minecraft:purple_terracotta
fill 411 162 557 412 175 557 minecraft:purple_terracotta
fill 411 162 598 413 162 598 minecraft:obsidian
fill 413 162 557 414 163 557 minecraft:purple_concrete
fill 413 162 558 415 162 558 minecraft:obsidian
fill 415 162 598 417 162 598 minecraft:obsidian
fill 416 162 577 416 163 577 minecraft:obsidian
fill 416 162 599 417 163 599 minecraft:purple_concrete
fill 417 162 558 417 162 560 minecraft:obsidian
fill 417 162 562 417 162 564 minecraft:obsidian
fill 417 162 566 417 162 568 minecraft:obsidian
fill 417 162 570 417 162 572 minecraft:obsidian
fill 417 162 574 417 162 576 minecraft:obsidian
fill 417 162 578 417 162 580 minecraft:obsidian
fill 417 162 582 417 162 584 minecraft:obsidian
fill 417 162 586 417 162 588 minecraft:obsidian
fill 417 162 590 417 162 592 minecraft:obsidian
fill 417 162 594 417 162 596 minecraft:obsidian
fill 418 162 558 418 179 559 minecraft:purple_terracotta
fill 418 162 560 418 162 561 minecraft:purple_concrete
fill 418 162 562 418 175 562 minecraft:purple_terracotta
fill 418 162 570 418 175 571 minecraft:purple_terracotta
fill 418 162 572 418 163 573 minecraft:purple_concrete
fill 418 162 579 418 179 579 minecraft:purple_terracotta
setblock 418 162 581 minecraft:purple_concrete
fill 418 162 582 418 175 583 minecraft:purple_terracotta
fill 418 162 584 418 163 584 minecraft:purple_concrete
fill 418 162 590 418 175 591 minecraft:purple_terracotta
fill 418 162 592 418 162 593 minecraft:purple_concrete
fill 418 162 599 418 175 599 minecraft:purple_terracotta
fill 376 163 559 376 173 559 minecraft:purple_terracotta
setblock 376 163 564 minecraft:purple_concrete
setblock 376 163 567 minecraft:purple_concrete
fill 376 163 568 376 173 568 minecraft:purple_terracotta
setblock 376 163 575 minecraft:purple_concrete
fill 376 163 579 376 173 579 minecraft:purple_terracotta
fill 376 163 595 376 163 596 minecraft:purple_concrete
setblock 376 163 599 minecraft:purple_concrete
fill 377 163 599 377 173 599 minecraft:purple_terracotta
fill 388 163 599 388 173 599 minecraft:purple_terracotta
fill 389 163 557 390 173 557 minecraft:purple_terracotta
fill 390 163 591 390 163 592 minecraft:black_concrete
setblock 391 163 591 minecraft:black_concrete
setblock 392 163 590 minecraft:black_concrete
setblock 393 163 599 minecraft:purple_concrete
setblock 394 163 557 minecraft:purple_concrete
setblock 395 163 591 minecraft:purple_concrete
setblock 396 163 592 minecraft:purple_concrete
fill 396 163 594 396 163 595 minecraft:purple_concrete
fill 397 163 593 397 163 594 minecraft:purple_concrete
setblock 404 163 599 minecraft:purple_concrete
setblock 405 163 557 minecraft:purple_concrete
fill 408 163 599 409 173 599 minecraft:purple_terracotta
fill 410 163 557 410 173 557 minecraft:purple_terracotta
fill 418 163 560 418 173 560 minecraft:purple_terracotta
setblock 418 163 561 minecraft:purple_concrete
fill 418 163 564 418 163 565 minecraft:purple_concrete
fill 418 163 581 418 173 581 minecraft:purple_terracotta
setblock 418 163 585 minecraft:purple_concrete
fill 418 163 592 418 173 592 minecraft:purple_terracotta
setblock 418 163 593 minecraft:purple_concrete
setblock 418 163 596 minecraft:purple_concrete
fill 376 164 564 376 177 564 minecraft:purple_terracotta
fill 376 164 567 376 174 567 minecraft:purple_terracotta
fill 376 164 575 376 177 576 minecraft:purple_terracotta
fill 376 164 587 376 174 588 minecraft:purple_terracotta
fill 376 164 595 376 177 596 minecraft:purple_terracotta
fill 376 164 599 376 174 599 minecraft:purple_terracotta
fill 381 164 557 382 174 557 minecraft:purple_terracotta
fill 384 164 599 385 177 599 minecraft:purple_terracotta
fill 393 164 557 394 177 557 minecraft:purple_terracotta
fill 393 164 599 393 177 599 minecraft:purple_terracotta
fill 396 164 599 397 174 599 minecraft:purple_terracotta
fill 401 164 557 402 173 557 minecraft:purple_terracotta
fill 404 164 599 405 177 599 minecraft:purple_terracotta
fill 405 164 557 405 177 557 minecraft:purple_terracotta
fill 413 164 557 414 177 557 minecraft:purple_terracotta
fill 416 164 599 417 174 599 minecraft:purple_terracotta
fill 418 164 561 418 174 561 minecraft:purple_terracotta
fill 418 164 564 418 177 565 minecraft:purple_terracotta
fill 418 164 572 418 174 573 minecraft:purple_terracotta
fill 418 164 584 418 177 585 minecraft:purple_terracotta
fill 418 164 593 418 174 593 minecraft:purple_terracotta
fill 418 164 596 418 177 596 minecraft:purple_terracotta
setblock 379 165 560 minecraft:light[level=12]
setblock 379 165 568 minecraft:light[level=12]
setblock 379 165 576 minecraft:light[level=12]
setblock 379 165 584 minecraft:light[level=12]
setblock 379 165 592 minecraft:light[level=12]
setblock 387 165 560 minecraft:light[level=12]
setblock 387 165 568 minecraft:light[level=12]
setblock 387 165 576 minecraft:light[level=12]
setblock 387 165 584 minecraft:light[level=12]
setblock 387 165 592 minecraft:light[level=12]
setblock 395 165 560 minecraft:light[level=12]
setblock 395 165 568 minecraft:light[level=12]
setblock 395 165 576 minecraft:light[level=12]
setblock 395 165 584 minecraft:light[level=12]
setblock 395 165 592 minecraft:light[level=12]
setblock 403 165 560 minecraft:light[level=12]
setblock 403 165 568 minecraft:light[level=12]
setblock 403 165 576 minecraft:light[level=12]
setblock 403 165 584 minecraft:light[level=12]
setblock 403 165 592 minecraft:light[level=12]
setblock 411 165 560 minecraft:light[level=12]
setblock 411 165 568 minecraft:light[level=12]
setblock 411 165 576 minecraft:light[level=12]
setblock 411 165 584 minecraft:light[level=12]
setblock 411 165 592 minecraft:light[level=12]
fill 377 169 558 377 170 568 minecraft:purple_terracotta
fill 377 169 569 377 170 570 minecraft:black_concrete
fill 377 169 571 377 170 584 minecraft:purple_terracotta
fill 377 169 585 377 170 586 minecraft:black_concrete
fill 377 169 587 378 170 598 minecraft:purple_terracotta
fill 378 169 558 378 170 567 minecraft:purple_terracotta
fill 378 169 568 378 170 568 minecraft:black_concrete
fill 378 169 569 378 170 582 minecraft:purple_terracotta
fill 378 169 583 378 170 584 minecraft:black_concrete
fill 378 169 585 385 170 586 minecraft:purple_terracotta
fill 379 169 558 379 170 565 minecraft:purple_terracotta
fill 379 169 566 379 170 566 minecraft:black_concrete
fill 379 169 567 379 170 581 minecraft:purple_terracotta
fill 379 169 582 379 170 582 minecraft:black_concrete
fill 379 169 583 386 170 584 minecraft:purple_terracotta
fill 379 169 587 379 170 596 minecraft:purple_terracotta
fill 379 169 597 379 170 598 minecraft:black_concrete
fill 380 169 558 380 170 563 minecraft:purple_terracotta
fill 380 169 564 380 170 565 minecraft:black_concrete
fill 380 169 566 380 170 579 minecraft:purple_terracotta
fill 380 169 580 380 170 580 minecraft:black_concrete
fill 380 169 581 387 170 582 minecraft:purple_terracotta
fill 380 169 587 380 170 594 minecraft:purple_terracotta
fill 380 169 595 380 170 596 minecraft:black_concrete
fill 380 169 597 387 170 598 minecraft:purple_terracotta
fill 381 169 558 381 170 561 minecraft:purple_terracotta
fill 381 169 562 381 170 563 minecraft:black_concrete
fill 381 169 564 381 170 577 minecraft:purple_terracotta
fill 381 169 578 381 170 579 minecraft:black_concrete
fill 381 169 580 388 170 580 minecraft:purple_terracotta
fill 381 169 587 381 170 593 minecraft:purple_terracotta
fill 381 169 594 381 170 594 minecraft:black_concrete
fill 381 169 595 388 170 596 minecraft:purple_terracotta
fill 382 169 558 382 170 560 minecraft:purple_terracotta
fill 382 169 561 382 170 561 minecraft:black_concrete
fill 382 169 562 382 170 575 minecraft:purple_terracotta
fill 382 169 576 382 170 577 minecraft:black_concrete
fill 382 169 578 389 170 579 minecraft:purple_terracotta
fill 382 169 587 382 170 591 minecraft:purple_terracotta
fill 382 169 592 382 170 593 minecraft:black_concrete
fill 382 169 594 389 170 594 minecraft:purple_terracotta
fill 383 169 558 383 170 558 minecraft:purple_terracotta
fill 383 169 559 383 170 559 minecraft:black_concrete
fill 383 169 560 383 170 574 minecraft:purple_terracotta
fill 383 169 575 383 170 575 minecraft:black_concrete
fill 383 169 576 390 170 577 minecraft:purple_terracotta
fill 383 169 587 383 170 589 minecraft:purple_terracotta
fill 383 169 590 383 170 591 minecraft:black_concrete
fill 383 169 592 390 170 593 minecraft:purple_terracotta
fill 384 169 558 384 170 558 minecraft:black_concrete
fill 384 169 559 384 170 572 minecraft:purple_terracotta
fill 384 169 573 384 170 573 minecraft:black_concrete
fill 384 169 574 391 170 575 minecraft:purple_terracotta
fill 384 169 587 384 170 587 minecraft:purple_terracotta
fill 384 169 588 384 170 589 minecraft:black_concrete
fill 384 169 590 391 170 591 minecraft:purple_terracotta
fill 385 169 558 385 170 570 minecraft:purple_terracotta
fill 385 169 571 385 170 572 minecraft:black_concrete
fill 385 169 573 392 170 573 minecraft:purple_terracotta
fill 385 169 587 385 170 587 minecraft:black_concrete
fill 385 169 588 392 170 589 minecraft:purple_terracotta
fill 386 169 558 386 170 568 minecraft:purple_terracotta
fill 386 169 569 386 170 570 minecraft:black_concrete
fill 386 169 571 393 170 572 minecraft:purple_terracotta
fill 386 169 585 386 170 586 minecraft:black_concrete
fill 386 169 587 393 170 587 minecraft:purple_terracotta
fill 387 169 558 387 170 567 minecraft:purple_terracotta
fill 387 169 568 387 170 568 minecraft:black_concrete
fill 387 169 569 394 170 570 minecraft:purple_terracotta
fill 387 169 583 387 170 584 minecraft:black_concrete
fill 387 169 585 394 170 586 minecraft:purple_terracotta
fill 388 169 558 388 170 565 minecraft:purple_terracotta
fill 388 169 566 388 170 566 minecraft:black_concrete
fill 388 169 567 395 170 568 minecraft:purple_terracotta
fill 388 169 581 388 170 582 minecraft:black_concrete
fill 388 169 583 395 170 584 minecraft:purple_terracotta
fill 388 169 597 388 170 598 minecraft:black_concrete
fill 389 169 558 389 170 563 minecraft:purple_terracotta
fill 389 169 564 389 170 565 minecraft:black_concrete
fill 389 169 566 396 170 566 minecraft:purple_terracotta
fill 389 169 580 389 170 580 minecraft:black_concrete
fill 389 169 581 396 170 582 minecraft:purple_terracotta
fill 389 169 595 389 170 596 minecraft:black_concrete
fill 389 169 597 396 170 598 minecraft:purple_terracotta
fill 390 169 558 390 170 561 minecraft:purple_terracotta
fill 390 169 562 390 170 563 minecraft:black_concrete
fill 390 169 564 397 170 565 minecraft:purple_terracotta
fill 390 169 578 390 170 579 minecraft:black_concrete
fill 390 169 580 397 169 580 minecraft:purple_terracotta
fill 390 169 594 390 170 594 minecraft:black_concrete
fill 390 169 595 397 170 596 minecraft:purple_terracotta
fill 391 169 558 391 170 560 minecraft:purple_terracotta
fill 391 169 561 391 170 561 minecraft:black_concrete
fill 391 169 562 398 170 563 minecraft:purple_terracotta
fill 391 169 576 391 170 577 minecraft:black_concrete
fill 391 169 578 398 169 579 minecraft:purple_terracotta
fill 391 169 592 391 170 592 minecraft:black_concrete
fill 391 169 593 398 170 594 minecraft:purple_terracotta
fill 392 169 558 392 170 558 minecraft:purple_terracotta
fill 392 169 559 392 170 559 minecraft:black_concrete
fill 392 169 560 399 170 561 minecraft:purple_terracotta
fill 392 169 574 392 170 575 minecraft:black_concrete
fill 392 169 576 398 169 577 minecraft:purple_terracotta
fill 392 169 590 392 170 591 minecraft:black_concrete
fill 392 169 592 399 170 592 minecraft:purple_terracotta
fill 393 169 558 393 170 558 minecraft:black_concrete
fill 393 169 559 400 170 559 minecraft:purple_terracotta
fill 393 169 573 393 170 573 minecraft:black_concrete
fill 393 169 574 397 169 575 minecraft:purple_terracotta
fill 393 169 588 393 170 589 minecraft:black_concrete
fill 393 169 590 400 170 591 minecraft:purple_terracotta
fill 394 169 558 401 170 558 minecraft:purple_terracotta
fill 394 169 571 394 170 572 minecraft:black_concrete
fill 394 169 573 399 169 573 minecraft:purple_terracotta
fill 394 169 587 394 170 587 minecraft:black_concrete
fill 394 169 588 401 170 589 minecraft:purple_terracotta
fill 395 169 569 395 170 570 minecraft:black_concrete
fill 395 169 571 402 169 572 minecraft:purple_terracotta
fill 395 169 585 395 170 585 minecraft:black_concrete
fill 395 169 586 402 170 587 minecraft:purple_terracotta
fill 396 169 567 396 170 568 minecraft:black_concrete
fill 396 169 569 403 169 570 minecraft:purple_terracotta
fill 396 169 583 396 170 584 minecraft:black_concrete
fill 396 169 585 403 170 585 minecraft:purple_terracotta
fill 397 169 566 397 170 566 minecraft:black_concrete
fill 397 169 567 404 170 568 minecraft:purple_terracotta
fill 397 169 581 397 170 582 minecraft:black_concrete
fill 397 169 583 404 170 584 minecraft:purple_terracotta
fill 397 169 597 397 170 598 minecraft:black_concrete
fill 398 169 564 398 170 565 minecraft:black_concrete
fill 398 169 566 405 170 566 minecraft:purple_terracotta
setblock 398 169 574 minecraft:purple_terracotta
setblock 398 169 580 minecraft:black_concrete
fill 398 169 581 405 169 582 minecraft:purple_terracotta
fill 398 169 595 398 170 596 minecraft:black_concrete
fill 398 169 597 405 170 598 minecraft:purple_terracotta
fill 399 169 562 399 170 563 minecraft:black_concrete
fill 399 169 564 406 170 565 minecraft:purple_terracotta
setblock 399 169 577 minecraft:purple_terracotta
setblock 399 169 578 minecraft:black_concrete
fill 399 169 579 406 169 580 minecraft:purple_terracotta
fill 399 169 593 417 170 593 minecraft:purple_terracotta
fill 399 169 594 399 170 594 minecraft:black_concrete
fill 399 169 595 406 170 596 minecraft:purple_terracotta
fill 400 169 560 400 170 561 minecraft:black_concrete
fill 400 169 562 407 170 563 minecraft:purple_terracotta
fill 400 169 578 407 169 578 minecraft:purple_terracotta
fill 400 169 592 400 170 592 minecraft:black_concrete
fill 400 169 594 407 170 594 minecraft:purple_terracotta
fill 401 169 559 401 170 559 minecraft:black_concrete
fill 401 169 560 408 170 561 minecraft:purple_terracotta
setblock 401 169 573 minecraft:purple_terracotta
fill 401 169 577 408 169 577 minecraft:purple_terracotta
fill 401 169 590 401 170 591 minecraft:black_concrete
fill 401 169 592 408 170 592 minecraft:purple_terracotta
fill 402 169 558 402 170 558 minecraft:black_concrete
fill 402 169 559 409 170 559 minecraft:purple_terracotta
setblock 402 169 573 minecraft:black_concrete
fill 402 169 574 409 169 574 minecraft:purple_terracotta
fill 402 169 576 408 169 576 minecraft:purple_terracotta
fill 402 169 588 402 170 589 minecraft:black_concrete
fill 402 169 590 409 170 591 minecraft:purple_terracotta
fill 403 169 558 417 170 558 minecraft:purple_terracotta
setblock 403 169 571 minecraft:black_concrete
fill 403 169 572 410 169 573 minecraft:purple_terracotta
fill 403 169 575 409 169 575 minecraft:purple_terracotta
fill 403 169 586 417 170 586 minecraft:purple_terracotta
fill 403 169 587 403 170 587 minecraft:black_concrete
fill 403 169 588 410 170 589 minecraft:purple_terracotta
fill 404 169 569 404 169 570 minecraft:black_concrete
fill 404 169 571 411 169 571 minecraft:purple_terracotta
fill 404 169 585 404 170 585 minecraft:black_concrete
fill 404 169 587 411 170 587 minecraft:purple_terracotta
fill 405 169 567 405 170 568 minecraft:black_concrete
fill 405 169 569 412 170 570 minecraft:purple_terracotta
fill 405 169 583 405 170 584 minecraft:black_concrete
fill 405 169 585 412 170 585 minecraft:purple_terracotta
fill 406 169 566 406 170 566 minecraft:black_concrete
fill 406 169 567 413 170 568 minecraft:purple_terracotta
fill 406 169 581 406 170 582 minecraft:black_concrete
fill 406 169 583 413 170 584 minecraft:purple_terracotta
fill 406 169 597 406 170 598 minecraft:black_concrete
fill 407 169 564 407 170 564 minecraft:black_concrete
fill 407 169 565 414 170 566 minecraft:purple_terracotta
fill 407 169 579 417 170 579 minecraft:purple_terracotta
fill 407 169 580 407 170 580 minecraft:black_concrete
fill 407 169 581 414 170 582 minecraft:purple_terracotta
fill 407 169 595 407 170 596 minecraft:black_concrete
fill 407 169 597 414 170 598 minecraft:purple_terracotta
fill 408 169 562 408 170 563 minecraft:black_concrete
fill 408 169 564 415 170 564 minecraft:purple_terracotta
fill 408 169 578 408 170 578 minecraft:black_concrete
fill 408 169 580 415 170 580 minecraft:purple_terracotta
fill 408 169 594 408 170 594 minecraft:black_concrete
fill 408 169 595 415 170 596 minecraft:purple_terracotta
fill 409 169 560 409 170 561 minecraft:black_concrete
fill 409 169 562 416 170 563 minecraft:purple_terracotta
fill 409 169 576 409 170 577 minecraft:black_concrete
fill 409 169 578 416 170 578 minecraft:purple_terracotta
fill 409 169 592 409 170 592 minecraft:black_concrete
fill 409 169 594 416 170 594 minecraft:purple_terracotta
fill 410 169 559 410 170 559 minecraft:black_concrete
fill 410 169 560 417 170 561 minecraft:purple_terracotta
fill 410 169 574 410 170 575 minecraft:black_concrete
fill 410 169 576 417 170 577 minecraft:purple_terracotta
fill 410 169 590 410 170 591 minecraft:black_concrete
fill 410 169 592 417 170 592 minecraft:purple_terracotta
fill 411 169 559 417 170 559 minecraft:purple_terracotta
fill 411 169 572 417 170 572 minecraft:purple_terracotta
fill 411 169 573 411 170 573 minecraft:black_concrete
fill 411 169 574 417 170 575 minecraft:purple_terracotta
fill 411 169 588 411 170 589 minecraft:black_concrete
fill 411 169 590 417 170 591 minecraft:purple_terracotta
fill 412 169 571 412 170 571 minecraft:black_concrete
fill 412 169 573 417 170 573 minecraft:purple_terracotta
fill 412 169 587 412 170 587 minecraft:black_concrete
fill 412 169 588 417 170 589 minecraft:purple_terracotta
fill 413 169 569 413 170 570 minecraft:black_concrete
fill 413 169 571 417 170 571 minecraft:purple_terracotta
fill 413 169 585 413 170 585 minecraft:black_concrete
fill 413 169 587 417 170 587 minecraft:purple_terracotta
fill 414 169 567 414 170 568 minecraft:black_concrete
fill 414 169 569 417 170 570 minecraft:purple_terracotta
fill 414 169 583 414 170 584 minecraft:black_concrete
fill 414 169 585 417 170 585 minecraft:purple_terracotta
schedule function dropper:buildpart/140_3 1t
