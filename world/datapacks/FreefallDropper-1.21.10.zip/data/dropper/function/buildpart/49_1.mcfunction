setblock 50 181 247 minecraft:light[level=12]
setblock 50 181 255 minecraft:light[level=12]
setblock 50 181 263 minecraft:light[level=12]
setblock 58 181 231 minecraft:light[level=12]
setblock 58 181 239 minecraft:light[level=12]
setblock 58 181 247 minecraft:light[level=12]
setblock 58 181 255 minecraft:light[level=12]
setblock 58 181 263 minecraft:light[level=12]
fill 59 181 231 59 182 231 minecraft:deepslate_bricks
setblock 66 181 231 minecraft:light[level=12]
setblock 66 181 239 minecraft:light[level=12]
setblock 66 181 247 minecraft:light[level=12]
setblock 66 181 255 minecraft:light[level=12]
setblock 66 181 263 minecraft:light[level=12]
fill 66 181 266 66 182 266 minecraft:deepslate_bricks
fill 72 181 231 72 182 231 minecraft:deepslate_bricks
setblock 74 181 231 minecraft:light[level=12]
setblock 74 181 239 minecraft:light[level=12]
setblock 74 181 247 minecraft:light[level=12]
setblock 74 181 255 minecraft:light[level=12]
setblock 74 181 263 minecraft:light[level=12]
fill 79 181 266 79 182 266 minecraft:deepslate_bricks
fill 80 181 231 80 182 231 minecraft:deepslate_bricks
setblock 82 181 231 minecraft:light[level=12]
setblock 82 181 239 minecraft:light[level=12]
setblock 82 181 247 minecraft:light[level=12]
setblock 82 181 255 minecraft:light[level=12]
setblock 82 181 263 minecraft:light[level=12]
fill 85 181 266 85 182 266 minecraft:deepslate_bricks
fill 66 182 267 66 183 267 minecraft:deepslate_bricks
fill 69 182 267 69 200 267 minecraft:moss_block
fill 79 182 267 79 183 267 minecraft:deepslate_bricks
fill 80 182 230 80 183 230 minecraft:deepslate_bricks
fill 84 182 266 84 182 267 minecraft:deepslate_bricks
fill 86 182 266 86 183 266 minecraft:deepslate_bricks
fill 59 183 229 59 184 229 minecraft:deepslate_bricks
fill 66 183 268 66 184 268 minecraft:deepslate_bricks
fill 80 183 229 80 185 229 minecraft:deepslate_bricks
fill 84 183 267 84 183 268 minecraft:deepslate_bricks
fill 87 183 266 87 184 266 minecraft:deepslate_bricks
setblock 52 184 235 minecraft:lantern
setblock 52 184 241 minecraft:lantern
setblock 52 184 247 minecraft:lantern
setblock 52 184 253 minecraft:lantern
setblock 52 184 259 minecraft:lantern
setblock 52 184 265 minecraft:lantern
setblock 54 184 233 minecraft:lantern
setblock 58 184 265 minecraft:lantern
setblock 60 184 233 minecraft:lantern
setblock 64 184 265 minecraft:lantern
setblock 66 184 233 minecraft:lantern
setblock 70 184 265 minecraft:lantern
setblock 72 184 233 minecraft:lantern
setblock 76 184 265 minecraft:lantern
setblock 78 184 233 minecraft:lantern
setblock 82 184 265 minecraft:lantern
setblock 84 184 233 minecraft:lantern
setblock 84 184 239 minecraft:lantern
setblock 84 184 245 minecraft:lantern
setblock 84 184 251 minecraft:lantern
setblock 84 184 257 minecraft:lantern
setblock 84 184 263 minecraft:lantern
setblock 84 184 268 minecraft:deepslate_bricks
fill 48 185 230 58 185 231 minecraft:polished_andesite
fill 48 185 232 48 185 237 minecraft:deepslate_bricks
setblock 48 185 238 minecraft:polished_andesite
fill 48 185 242 52 185 243 minecraft:polished_andesite
fill 48 185 244 48 185 249 minecraft:deepslate_bricks
setblock 48 185 250 minecraft:polished_andesite
fill 48 185 254 52 185 255 minecraft:polished_andesite
fill 48 185 256 48 185 261 minecraft:deepslate_bricks
setblock 48 185 262 minecraft:polished_andesite
fill 48 185 266 68 185 267 minecraft:polished_andesite
fill 48 185 268 48 185 269 minecraft:deepslate_bricks
fill 49 185 232 52 185 237 minecraft:polished_andesite
fill 49 185 241 52 185 241 minecraft:polished_andesite
fill 49 185 244 52 185 249 minecraft:polished_andesite
fill 49 185 253 52 185 253 minecraft:polished_andesite
fill 49 185 256 52 185 261 minecraft:polished_andesite
fill 49 185 265 87 185 265 minecraft:polished_andesite
fill 49 185 268 54 185 268 minecraft:polished_andesite
fill 49 185 269 52 185 269 minecraft:deepslate_bricks
fill 50 185 238 52 185 240 minecraft:polished_andesite
fill 50 185 250 52 185 252 minecraft:polished_andesite
fill 50 185 262 52 185 264 minecraft:polished_andesite
setblock 51 185 229 minecraft:polished_andesite
fill 52 185 229 57 185 229 minecraft:deepslate_bricks
fill 53 185 232 87 185 233 minecraft:polished_andesite
setblock 53 185 269 minecraft:polished_andesite
fill 57 185 269 58 185 269 minecraft:polished_andesite
fill 58 185 229 59 185 229 minecraft:polished_andesite
fill 58 185 268 66 185 268 minecraft:polished_andesite
fill 59 185 231 87 185 231 minecraft:polished_andesite
fill 59 185 269 64 185 269 minecraft:deepslate_bricks
fill 62 185 230 70 185 230 minecraft:polished_andesite
setblock 63 185 229 minecraft:polished_andesite
fill 64 185 229 69 185 229 minecraft:deepslate_bricks
setblock 65 185 269 minecraft:polished_andesite
fill 69 185 266 87 185 266 minecraft:polished_andesite
fill 69 185 269 70 185 269 minecraft:polished_andesite
fill 70 185 229 71 185 229 minecraft:polished_andesite
fill 70 185 267 78 185 268 minecraft:polished_andesite
fill 71 185 269 76 185 269 minecraft:deepslate_bricks
fill 74 185 230 82 185 230 minecraft:polished_andesite
setblock 75 185 229 minecraft:polished_andesite
fill 76 185 229 79 185 229 minecraft:deepslate_bricks
setblock 77 185 269 minecraft:polished_andesite
fill 79 185 267 87 185 267 minecraft:polished_andesite
setblock 81 185 229 minecraft:deepslate_bricks
fill 81 185 269 82 185 269 minecraft:polished_andesite
fill 82 185 229 83 185 229 minecraft:polished_andesite
fill 82 185 268 87 185 268 minecraft:polished_andesite
fill 83 185 269 88 185 269 minecraft:deepslate_bricks
fill 84 185 234 86 185 264 minecraft:polished_andesite
fill 86 185 230 87 185 230 minecraft:polished_andesite
setblock 87 185 229 minecraft:polished_andesite
fill 87 185 234 87 185 237 minecraft:polished_andesite
fill 87 185 241 87 185 249 minecraft:polished_andesite
fill 87 185 253 87 185 261 minecraft:polished_andesite
fill 88 185 229 88 185 234 minecraft:deepslate_bricks
fill 88 185 235 88 185 236 minecraft:polished_andesite
setblock 88 185 240 minecraft:polished_andesite
fill 88 185 241 88 185 246 minecraft:deepslate_bricks
fill 88 185 247 88 185 248 minecraft:polished_andesite
setblock 88 185 252 minecraft:polished_andesite
fill 88 185 253 88 185 258 minecraft:deepslate_bricks
fill 88 185 259 88 185 260 minecraft:polished_andesite
setblock 88 185 264 minecraft:polished_andesite
fill 88 185 265 88 185 268 minecraft:deepslate_bricks
fill 47 186 234 47 191 237 minecraft:lantern
fill 47 186 246 47 191 249 minecraft:lantern
fill 47 186 258 47 191 261 minecraft:lantern
fill 47 186 270 50 191 270 minecraft:lantern
fill 52 186 233 52 186 265 minecraft:iron_block
fill 53 186 233 84 186 233 minecraft:iron_block
fill 53 186 265 84 186 265 minecraft:iron_block
fill 54 186 228 57 191 228 minecraft:lantern
fill 59 186 270 62 191 270 minecraft:lantern
fill 66 186 228 69 191 228 minecraft:lantern
fill 71 186 270 74 191 270 minecraft:lantern
fill 78 186 228 81 191 228 minecraft:lantern
fill 83 186 270 86 191 270 minecraft:lantern
fill 84 186 234 84 186 264 minecraft:iron_block
fill 89 186 229 89 191 232 minecraft:lantern
fill 89 186 241 89 191 244 minecraft:lantern
fill 89 186 253 89 191 256 minecraft:lantern
fill 89 186 265 89 191 268 minecraft:lantern
setblock 47 189 228 minecraft:cracked_stone_bricks
fill 47 189 229 47 189 230 minecraft:stone_bricks
setblock 47 189 231 minecraft:cracked_stone_bricks
fill 47 189 251 47 192 253 minecraft:cracked_stone_bricks
fill 47 189 254 47 189 255 minecraft:stone_bricks
fill 50 189 228 51 192 228 minecraft:cracked_stone_bricks
setblock 50 189 231 minecraft:light[level=12]
setblock 50 189 239 minecraft:light[level=12]
setblock 50 189 247 minecraft:light[level=12]
setblock 50 189 255 minecraft:light[level=12]
setblock 50 189 263 minecraft:light[level=12]
setblock 52 189 228 minecraft:stone_bricks
fill 52 189 270 54 192 270 minecraft:cracked_stone_bricks
setblock 55 189 270 minecraft:stone_bricks
fill 56 189 270 56 192 270 minecraft:cracked_stone_bricks
fill 58 189 228 59 189 228 minecraft:cracked_stone_bricks
setblock 58 189 231 minecraft:light[level=12]
setblock 58 189 239 minecraft:light[level=12]
setblock 58 189 247 minecraft:light[level=12]
setblock 58 189 255 minecraft:light[level=12]
setblock 58 189 263 minecraft:light[level=12]
setblock 60 189 228 minecraft:stone_bricks
fill 63 189 270 67 190 270 minecraft:cracked_stone_bricks
setblock 66 189 231 minecraft:light[level=12]
setblock 66 189 239 minecraft:light[level=12]
setblock 66 189 247 minecraft:light[level=12]
setblock 66 189 255 minecraft:light[level=12]
setblock 66 189 263 minecraft:light[level=12]
setblock 68 189 270 minecraft:stone_bricks
fill 69 189 270 69 190 270 minecraft:cracked_stone_bricks
setblock 70 189 270 minecraft:stone_bricks
fill 73 189 228 73 192 228 minecraft:cracked_stone_bricks
fill 74 189 228 75 189 228 minecraft:stone_bricks
setblock 74 189 231 minecraft:light[level=12]
setblock 74 189 239 minecraft:light[level=12]
setblock 74 189 247 minecraft:light[level=12]
setblock 74 189 255 minecraft:light[level=12]
setblock 74 189 263 minecraft:light[level=12]
setblock 79 189 270 minecraft:stone_bricks
fill 80 189 270 81 192 270 minecraft:cracked_stone_bricks
setblock 82 189 231 minecraft:light[level=12]
setblock 82 189 239 minecraft:light[level=12]
setblock 82 189 247 minecraft:light[level=12]
setblock 82 189 255 minecraft:light[level=12]
setblock 82 189 263 minecraft:light[level=12]
setblock 82 189 270 minecraft:stone_bricks
fill 88 189 228 88 192 228 minecraft:cracked_stone_bricks
fill 88 189 270 88 192 270 minecraft:cracked_stone_bricks
setblock 89 189 228 minecraft:stone_bricks
setblock 89 189 245 minecraft:stone_bricks
fill 89 189 246 89 192 247 minecraft:cracked_stone_bricks
setblock 89 189 248 minecraft:stone_bricks
fill 89 189 249 89 190 250 minecraft:cracked_stone_bricks
setblock 89 189 259 minecraft:stone_bricks
fill 89 189 260 89 190 262 minecraft:cracked_stone_bricks
fill 89 189 263 89 189 264 minecraft:stone_bricks
setblock 89 189 270 minecraft:stone_bricks
setblock 47 190 228 minecraft:stone_bricks
fill 47 190 229 47 192 230 minecraft:cracked_stone_bricks
setblock 47 190 231 minecraft:stone_bricks
fill 47 190 238 47 192 243 minecraft:cracked_stone_bricks
setblock 47 190 244 minecraft:stone_bricks
fill 47 190 245 47 192 245 minecraft:cracked_stone_bricks
setblock 47 190 250 minecraft:stone_bricks
fill 47 190 254 47 192 255 minecraft:cracked_stone_bricks
fill 47 190 264 47 190 267 minecraft:cracked_stone_bricks
setblock 47 190 268 minecraft:stone_bricks
fill 47 190 269 47 192 269 minecraft:cracked_stone_bricks
fill 52 190 228 52 193 228 minecraft:cracked_stone_bricks
fill 55 190 270 55 193 270 minecraft:cracked_stone_bricks
fill 58 190 228 58 192 228 minecraft:cracked_stone_bricks
setblock 59 190 228 minecraft:stone_bricks
fill 60 190 228 60 192 228 minecraft:cracked_stone_bricks
fill 68 190 270 68 192 270 minecraft:cracked_stone_bricks
fill 70 190 270 70 192 270 minecraft:cracked_stone_bricks
fill 74 190 228 75 190 228 minecraft:cracked_stone_bricks
fill 79 190 270 79 192 270 minecraft:cracked_stone_bricks
fill 82 190 228 85 190 228 minecraft:cracked_stone_bricks
fill 82 190 270 82 192 270 minecraft:cracked_stone_bricks
setblock 86 190 228 minecraft:stone_bricks
fill 89 190 228 89 193 228 minecraft:cracked_stone_bricks
fill 89 190 245 89 192 245 minecraft:cracked_stone_bricks
setblock 89 190 248 minecraft:cracked_stone_bricks
fill 89 190 257 89 192 257 minecraft:cracked_stone_bricks
setblock 89 190 258 minecraft:stone_bricks
fill 89 190 259 89 193 259 minecraft:cracked_stone_bricks
fill 89 190 263 89 192 264 minecraft:cracked_stone_bricks
fill 89 190 270 89 192 270 minecraft:cracked_stone_bricks
fill 47 191 228 47 193 228 minecraft:cracked_stone_bricks
fill 47 191 231 47 193 231 minecraft:cracked_stone_bricks
fill 47 191 244 47 192 244 minecraft:cracked_stone_bricks
fill 47 191 250 47 192 250 minecraft:cracked_stone_bricks
fill 47 191 264 47 192 266 minecraft:cracked_stone_bricks
setblock 47 191 267 minecraft:stone_bricks
fill 47 191 268 47 192 268 minecraft:cracked_stone_bricks
fill 59 191 228 59 192 228 minecraft:cracked_stone_bricks
fill 62 191 228 63 192 228 minecraft:cracked_stone_bricks
fill 63 191 270 66 192 270 minecraft:cracked_stone_bricks
setblock 64 191 228 minecraft:stone_bricks
fill 65 191 228 65 192 228 minecraft:cracked_stone_bricks
setblock 67 191 270 minecraft:stone_bricks
setblock 69 191 270 minecraft:stone_bricks
setblock 74 191 228 minecraft:stone_bricks
fill 75 191 228 75 192 228 minecraft:cracked_stone_bricks
fill 82 191 228 82 192 228 minecraft:cracked_stone_bricks
setblock 83 191 228 minecraft:stone_bricks
fill 84 191 228 86 192 228 minecraft:cracked_stone_bricks
setblock 89 191 238 minecraft:stone_bricks
fill 89 191 239 89 192 239 minecraft:cracked_stone_bricks
setblock 89 191 240 minecraft:stone_bricks
fill 89 191 248 89 191 249 minecraft:stone_bricks
fill 89 191 250 89 193 250 minecraft:cracked_stone_bricks
fill 89 191 258 89 192 258 minecraft:cracked_stone_bricks
fill 89 191 260 89 192 261 minecraft:cracked_stone_bricks
setblock 89 191 262 minecraft:stone_bricks
setblock 89 191 269 minecraft:stone_bricks
setblock 47 192 234 minecraft:cracked_stone_bricks
fill 47 192 235 47 192 236 minecraft:lantern
setblock 47 192 237 minecraft:cracked_stone_bricks
setblock 47 192 246 minecraft:cracked_stone_bricks
fill 47 192 247 47 192 248 minecraft:lantern
setblock 47 192 249 minecraft:cracked_stone_bricks
setblock 47 192 258 minecraft:cracked_stone_bricks
fill 47 192 259 47 192 260 minecraft:lantern
setblock 47 192 261 minecraft:cracked_stone_bricks
setblock 47 192 267 minecraft:cracked_stone_bricks
fill 47 192 270 47 193 270 minecraft:cracked_stone_bricks
fill 48 192 270 49 192 270 minecraft:lantern
setblock 50 192 270 minecraft:cracked_stone_bricks
fill 54 192 228 54 193 228 minecraft:cracked_stone_bricks
fill 55 192 228 56 192 228 minecraft:lantern
setblock 57 192 228 minecraft:cracked_stone_bricks
setblock 59 192 270 minecraft:cracked_stone_bricks
fill 60 192 270 61 192 270 minecraft:lantern
setblock 62 192 270 minecraft:cracked_stone_bricks
setblock 64 192 228 minecraft:cracked_stone_bricks
setblock 66 192 228 minecraft:cracked_stone_bricks
fill 67 192 228 68 192 228 minecraft:lantern
setblock 67 192 270 minecraft:cracked_stone_bricks
setblock 69 192 228 minecraft:cracked_stone_bricks
setblock 69 192 270 minecraft:cracked_stone_bricks
setblock 71 192 270 minecraft:cracked_stone_bricks
fill 72 192 270 73 192 270 minecraft:lantern
setblock 74 192 228 minecraft:cracked_stone_bricks
setblock 74 192 270 minecraft:cracked_stone_bricks
setblock 78 192 228 minecraft:cracked_stone_bricks
fill 79 192 228 80 192 228 minecraft:lantern
setblock 81 192 228 minecraft:cracked_stone_bricks
setblock 83 192 228 minecraft:cracked_stone_bricks
setblock 83 192 270 minecraft:cracked_stone_bricks
fill 84 192 270 85 192 270 minecraft:lantern
setblock 86 192 270 minecraft:cracked_stone_bricks
setblock 89 192 229 minecraft:cracked_stone_bricks
fill 89 192 230 89 192 231 minecraft:lantern
setblock 89 192 232 minecraft:cracked_stone_bricks
setblock 89 192 238 minecraft:cracked_stone_bricks
fill 89 192 240 89 192 241 minecraft:cracked_stone_bricks
fill 89 192 242 89 192 243 minecraft:lantern
setblock 89 192 244 minecraft:cracked_stone_bricks
fill 89 192 248 89 192 249 minecraft:cracked_stone_bricks
fill 89 192 253 89 193 253 minecraft:cracked_stone_bricks
fill 89 192 254 89 192 255 minecraft:lantern
setblock 89 192 256 minecraft:cracked_stone_bricks
fill 89 192 262 89 193 262 minecraft:cracked_stone_bricks
setblock 89 192 265 minecraft:cracked_stone_bricks
fill 89 192 266 89 192 267 minecraft:lantern
fill 89 192 268 89 192 269 minecraft:cracked_stone_bricks
setblock 47 193 229 minecraft:cracked_stone_bricks
fill 47 193 230 47 307 230 minecraft:stone_bricks
fill 47 193 232 47 193 239 minecraft:stone_bricks
setblock 47 193 240 minecraft:cracked_stone_bricks
fill 47 193 241 47 307 242 minecraft:stone_bricks
setblock 47 193 243 minecraft:cracked_stone_bricks
fill 47 193 244 47 193 263 minecraft:stone_bricks
setblock 47 193 264 minecraft:cracked_stone_bricks
fill 47 193 265 47 307 269 minecraft:stone_bricks
fill 48 193 228 51 193 228 minecraft:stone_bricks
fill 48 193 270 48 205 270 minecraft:stone_bricks
setblock 49 193 270 minecraft:cracked_stone_bricks
fill 50 193 270 54 193 270 minecraft:stone_bricks
fill 53 193 228 53 307 228 minecraft:stone_bricks
fill 55 193 228 88 193 228 minecraft:stone_bricks
fill 56 193 270 63 193 270 minecraft:stone_bricks
setblock 64 193 270 minecraft:cracked_stone_bricks
fill 65 193 270 76 193 270 minecraft:stone_bricks
setblock 77 193 270 minecraft:cracked_stone_bricks
fill 78 193 270 89 193 270 minecraft:stone_bricks
fill 89 193 229 89 193 240 minecraft:stone_bricks
setblock 89 193 241 minecraft:cracked_stone_bricks
fill 89 193 242 89 205 245 minecraft:stone_bricks
setblock 89 193 246 minecraft:cracked_stone_bricks
fill 89 193 247 89 194 248 minecraft:stone_bricks
setblock 89 193 249 minecraft:cracked_stone_bricks
fill 89 193 251 89 193 252 minecraft:stone_bricks
fill 89 193 254 89 193 258 minecraft:stone_bricks
fill 89 193 260 89 193 261 minecraft:stone_bricks
fill 89 193 263 89 193 269 minecraft:stone_bricks
fill 47 194 228 47 307 229 minecraft:stone_bricks
fill 47 194 231 47 307 231 minecraft:stone_bricks
setblock 47 194 232 minecraft:cracked_stone_bricks
fill 47 194 233 47 205 236 minecraft:stone_bricks
setblock 47 194 237 minecraft:cracked_stone_bricks
fill 47 194 238 47 307 240 minecraft:stone_bricks
fill 47 194 243 47 205 247 minecraft:stone_bricks
setblock 47 194 248 minecraft:cracked_stone_bricks
fill 47 194 249 47 194 264 minecraft:stone_bricks
setblock 47 194 270 minecraft:stone_bricks
fill 48 194 228 50 194 228 minecraft:stone_bricks
fill 49 194 270 51 205 270 minecraft:stone_bricks
setblock 51 194 228 minecraft:cracked_stone_bricks
setblock 52 194 228 minecraft:stone_bricks
setblock 52 194 270 minecraft:cracked_stone_bricks
fill 53 194 270 59 194 270 minecraft:stone_bricks
fill 54 194 228 55 205 228 minecraft:stone_bricks
setblock 56 194 228 minecraft:cracked_stone_bricks
fill 57 194 228 64 194 228 minecraft:stone_bricks
setblock 60 194 270 minecraft:cracked_stone_bricks
fill 61 194 270 70 194 270 minecraft:stone_bricks
setblock 65 194 228 minecraft:cracked_stone_bricks
fill 66 194 228 85 194 228 minecraft:stone_bricks
fill 71 194 270 72 194 270 minecraft:cracked_stone_bricks
fill 73 194 270 77 205 270 minecraft:stone_bricks
setblock 78 194 270 minecraft:cracked_stone_bricks
fill 79 194 270 81 194 270 minecraft:stone_bricks
setblock 82 194 270 minecraft:cracked_stone_bricks
fill 83 194 270 86 194 270 minecraft:stone_bricks
fill 86 194 228 87 194 228 minecraft:cracked_stone_bricks
setblock 87 194 270 minecraft:cracked_stone_bricks
fill 88 194 228 89 307 228 minecraft:stone_bricks
fill 88 194 270 89 194 270 minecraft:stone_bricks
fill 89 194 229 89 194 235 minecraft:stone_bricks
setblock 89 194 236 minecraft:cracked_stone_bricks
fill 89 194 237 89 307 238 minecraft:stone_bricks
setblock 89 194 239 minecraft:cracked_stone_bricks
fill 89 194 240 89 205 241 minecraft:stone_bricks
fill 89 194 246 89 307 246 minecraft:stone_bricks
fill 89 194 249 89 307 251 minecraft:stone_bricks
setblock 89 194 252 minecraft:cracked_stone_bricks
fill 89 194 253 89 205 257 minecraft:stone_bricks
setblock 89 194 258 minecraft:cracked_stone_bricks
fill 89 194 259 89 307 260 minecraft:stone_bricks
setblock 89 194 261 minecraft:cracked_stone_bricks
fill 89 194 262 89 194 263 minecraft:stone_bricks
setblock 89 194 264 minecraft:cracked_stone_bricks
fill 89 194 265 89 194 269 minecraft:stone_bricks
fill 47 195 232 47 307 232 minecraft:stone_bricks
fill 47 195 237 47 205 237 minecraft:stone_bricks
fill 47 195 248 47 205 249 minecraft:stone_bricks
setblock 47 195 250 minecraft:cracked_stone_bricks
fill 47 195 251 47 307 252 minecraft:stone_bricks
setblock 47 195 253 minecraft:cracked_stone_bricks
fill 47 195 254 47 205 261 minecraft:stone_bricks
setblock 47 195 262 minecraft:cracked_stone_bricks
fill 47 195 263 47 307 264 minecraft:stone_bricks
setblock 47 195 270 minecraft:cracked_stone_bricks
setblock 48 195 228 minecraft:cracked_stone_bricks
fill 49 195 228 51 307 228 minecraft:stone_bricks
setblock 52 195 228 minecraft:cracked_stone_bricks
fill 52 195 270 56 307 270 minecraft:stone_bricks
fill 56 195 228 58 205 228 minecraft:stone_bricks
setblock 57 195 270 minecraft:cracked_stone_bricks
fill 58 195 270 63 205 270 minecraft:stone_bricks
setblock 59 195 228 minecraft:cracked_stone_bricks
fill 60 195 228 73 205 228 minecraft:stone_bricks
setblock 64 195 270 minecraft:cracked_stone_bricks
fill 65 195 270 66 307 270 minecraft:stone_bricks
setblock 67 195 270 minecraft:cracked_stone_bricks
fill 68 195 270 68 307 270 minecraft:stone_bricks
setblock 69 195 270 minecraft:cracked_stone_bricks
fill 70 195 270 72 205 270 minecraft:stone_bricks
setblock 74 195 228 minecraft:cracked_stone_bricks
fill 75 195 228 81 205 228 minecraft:stone_bricks
fill 78 195 270 79 307 270 minecraft:stone_bricks
setblock 80 195 270 minecraft:cracked_stone_bricks
fill 81 195 270 82 307 270 minecraft:stone_bricks
setblock 82 195 228 minecraft:cracked_stone_bricks
fill 83 195 228 85 307 228 minecraft:stone_bricks
setblock 83 195 270 minecraft:cracked_stone_bricks
fill 84 195 270 88 205 270 minecraft:stone_bricks
setblock 86 195 228 minecraft:cracked_stone_bricks
fill 87 195 228 87 307 228 minecraft:stone_bricks
setblock 89 195 229 minecraft:cracked_stone_bricks
fill 89 195 230 89 205 236 minecraft:stone_bricks
fill 89 195 239 89 307 239 minecraft:stone_bricks
fill 89 195 247 89 307 247 minecraft:stone_bricks
setblock 89 195 248 minecraft:cracked_stone_bricks
fill 89 195 252 89 307 252 minecraft:stone_bricks
fill 89 195 258 89 307 258 minecraft:stone_bricks
fill 89 195 261 89 307 261 minecraft:stone_bricks
setblock 89 195 262 minecraft:cracked_stone_bricks
fill 89 195 263 89 205 265 minecraft:stone_bricks
setblock 89 195 266 minecraft:cracked_stone_bricks
fill 89 195 267 89 205 269 minecraft:stone_bricks
setblock 89 195 270 minecraft:cracked_stone_bricks
fill 47 196 250 47 307 250 minecraft:stone_bricks
fill 47 196 253 47 307 253 minecraft:stone_bricks
fill 47 196 262 47 307 262 minecraft:stone_bricks
fill 47 196 270 47 205 270 minecraft:stone_bricks
fill 48 196 228 48 307 228 minecraft:stone_bricks
fill 52 196 228 52 307 228 minecraft:stone_bricks
fill 57 196 270 57 307 270 minecraft:stone_bricks
fill 59 196 228 59 307 228 minecraft:stone_bricks
fill 64 196 270 64 307 270 minecraft:stone_bricks
fill 67 196 270 67 307 270 minecraft:stone_bricks
fill 69 196 270 69 307 270 minecraft:stone_bricks
fill 74 196 228 74 307 228 minecraft:stone_bricks
fill 80 196 270 80 307 270 minecraft:stone_bricks
fill 82 196 228 82 307 228 minecraft:stone_bricks
fill 83 196 270 83 205 270 minecraft:stone_bricks
fill 86 196 228 86 307 228 minecraft:stone_bricks
fill 89 196 229 89 205 229 minecraft:stone_bricks
fill 89 196 248 89 307 248 minecraft:stone_bricks
fill 89 196 262 89 307 262 minecraft:stone_bricks
fill 89 196 266 89 205 266 minecraft:stone_bricks
fill 89 196 270 89 307 270 minecraft:stone_bricks
setblock 50 197 231 minecraft:light[level=12]
setblock 50 197 239 minecraft:light[level=12]
setblock 50 197 247 minecraft:light[level=12]
setblock 50 197 255 minecraft:light[level=12]
setblock 50 197 263 minecraft:light[level=12]
setblock 58 197 231 minecraft:light[level=12]
setblock 58 197 239 minecraft:light[level=12]
setblock 58 197 247 minecraft:light[level=12]
setblock 58 197 255 minecraft:light[level=12]
setblock 58 197 263 minecraft:light[level=12]
setblock 66 197 231 minecraft:light[level=12]
setblock 66 197 239 minecraft:light[level=12]
setblock 66 197 247 minecraft:light[level=12]
setblock 66 197 255 minecraft:light[level=12]
setblock 66 197 263 minecraft:light[level=12]
setblock 74 197 231 minecraft:light[level=12]
setblock 74 197 239 minecraft:light[level=12]
setblock 74 197 247 minecraft:light[level=12]
setblock 74 197 255 minecraft:light[level=12]
setblock 74 197 263 minecraft:light[level=12]
setblock 82 197 231 minecraft:light[level=12]
setblock 82 197 239 minecraft:light[level=12]
setblock 82 197 247 minecraft:light[level=12]
setblock 82 197 255 minecraft:light[level=12]
setblock 82 197 263 minecraft:light[level=12]
fill 49 200 238 49 205 240 minecraft:polished_andesite
fill 49 200 250 49 205 252 minecraft:polished_andesite
fill 49 200 262 49 205 264 minecraft:polished_andesite
fill 55 200 268 57 205 268 minecraft:polished_andesite
fill 59 200 230 61 205 230 minecraft:polished_andesite
fill 67 200 268 69 205 268 minecraft:polished_andesite
fill 71 200 230 73 205 230 minecraft:polished_andesite
fill 79 200 268 81 205 268 minecraft:polished_andesite
fill 83 200 230 85 205 230 minecraft:polished_andesite
fill 87 200 238 87 205 240 minecraft:polished_andesite
fill 87 200 250 87 205 252 minecraft:polished_andesite
fill 87 200 262 87 205 264 minecraft:polished_andesite
fill 48 205 232 48 205 237 minecraft:deepslate_bricks
fill 48 205 244 48 205 249 minecraft:deepslate_bricks
fill 48 205 256 48 205 261 minecraft:deepslate_bricks
fill 48 205 268 48 205 269 minecraft:deepslate_bricks
fill 49 205 269 52 205 269 minecraft:deepslate_bricks
setblock 50 205 231 minecraft:light[level=12]
setblock 50 205 239 minecraft:light[level=12]
setblock 50 205 247 minecraft:light[level=12]
setblock 50 205 255 minecraft:light[level=12]
setblock 50 205 263 minecraft:light[level=12]
fill 52 205 229 57 205 229 minecraft:deepslate_bricks
setblock 58 205 231 minecraft:light[level=12]
setblock 58 205 239 minecraft:light[level=12]
setblock 58 205 247 minecraft:light[level=12]
setblock 58 205 255 minecraft:light[level=12]
setblock 58 205 263 minecraft:light[level=12]
fill 59 205 269 64 205 269 minecraft:deepslate_bricks
fill 64 205 229 69 205 229 minecraft:deepslate_bricks
setblock 66 205 231 minecraft:light[level=12]
setblock 66 205 239 minecraft:light[level=12]
setblock 66 205 247 minecraft:light[level=12]
setblock 66 205 255 minecraft:light[level=12]
setblock 66 205 263 minecraft:light[level=12]
fill 71 205 269 76 205 269 minecraft:deepslate_bricks
setblock 74 205 231 minecraft:light[level=12]
setblock 74 205 239 minecraft:light[level=12]
setblock 74 205 247 minecraft:light[level=12]
setblock 74 205 255 minecraft:light[level=12]
setblock 74 205 263 minecraft:light[level=12]
fill 76 205 229 81 205 229 minecraft:deepslate_bricks
setblock 82 205 231 minecraft:light[level=12]
setblock 82 205 239 minecraft:light[level=12]
setblock 82 205 247 minecraft:light[level=12]
setblock 82 205 255 minecraft:light[level=12]
setblock 82 205 263 minecraft:light[level=12]
fill 83 205 269 88 205 269 minecraft:deepslate_bricks
fill 88 205 229 88 205 234 minecraft:deepslate_bricks
fill 88 205 241 88 205 246 minecraft:deepslate_bricks
fill 88 205 253 88 205 258 minecraft:deepslate_bricks
fill 88 205 265 88 205 268 minecraft:deepslate_bricks
fill 47 206 233 47 307 233 minecraft:stone_bricks
fill 47 206 234 47 210 237 minecraft:lantern
fill 47 206 243 47 307 245 minecraft:stone_bricks
fill 47 206 246 47 210 249 minecraft:lantern
fill 47 206 254 47 307 257 minecraft:stone_bricks
fill 47 206 258 47 210 261 minecraft:lantern
fill 47 206 270 50 210 270 minecraft:lantern
fill 51 206 270 51 307 270 minecraft:stone_bricks
fill 54 206 228 57 210 228 minecraft:lantern
fill 58 206 228 58 307 228 minecraft:stone_bricks
fill 58 206 270 58 307 270 minecraft:stone_bricks
fill 59 206 270 62 210 270 minecraft:lantern
fill 60 206 228 65 307 228 minecraft:stone_bricks
fill 63 206 270 63 307 270 minecraft:stone_bricks
fill 66 206 228 69 210 228 minecraft:lantern
fill 70 206 228 73 307 228 minecraft:stone_bricks
fill 70 206 270 70 307 270 minecraft:stone_bricks
fill 71 206 270 74 210 270 minecraft:lantern
fill 75 206 228 77 307 228 minecraft:stone_bricks
fill 75 206 270 77 307 270 minecraft:stone_bricks
fill 78 206 228 81 210 228 minecraft:lantern
fill 83 206 270 86 210 270 minecraft:lantern
fill 87 206 270 88 307 270 minecraft:stone_bricks
fill 89 206 229 89 210 232 minecraft:lantern
fill 89 206 233 89 307 236 minecraft:stone_bricks
fill 89 206 240 89 307 240 minecraft:stone_bricks
fill 89 206 241 89 210 244 minecraft:lantern
fill 89 206 245 89 307 245 minecraft:stone_bricks
fill 89 206 253 89 210 256 minecraft:lantern
fill 89 206 257 89 307 257 minecraft:stone_bricks
fill 89 206 263 89 307 264 minecraft:stone_bricks
fill 89 206 265 89 210 268 minecraft:lantern
fill 89 206 269 89 307 269 minecraft:stone_bricks
fill 47 211 234 47 225 237 minecraft:stone_bricks
fill 47 211 246 47 225 249 minecraft:stone_bricks
fill 47 211 258 47 225 261 minecraft:stone_bricks
fill 47 211 270 50 225 270 minecraft:stone_bricks
fill 54 211 228 57 225 228 minecraft:stone_bricks
fill 59 211 270 62 225 270 minecraft:stone_bricks
fill 66 211 228 69 225 228 minecraft:stone_bricks
fill 71 211 270 74 225 270 minecraft:stone_bricks
fill 78 211 228 81 225 228 minecraft:stone_bricks
fill 83 211 270 86 225 270 minecraft:stone_bricks
fill 89 211 229 89 225 232 minecraft:stone_bricks
fill 89 211 241 89 225 244 minecraft:stone_bricks
fill 89 211 253 89 225 256 minecraft:stone_bricks
fill 89 211 265 89 225 268 minecraft:stone_bricks
setblock 50 213 231 minecraft:light[level=12]
setblock 50 213 239 minecraft:light[level=12]
setblock 50 213 247 minecraft:light[level=12]
setblock 50 213 255 minecraft:light[level=12]
setblock 50 213 263 minecraft:light[level=12]
setblock 58 213 231 minecraft:light[level=12]
setblock 58 213 239 minecraft:light[level=12]
setblock 58 213 247 minecraft:light[level=12]
setblock 58 213 255 minecraft:light[level=12]
setblock 58 213 263 minecraft:light[level=12]
setblock 66 213 231 minecraft:light[level=12]
setblock 66 213 239 minecraft:light[level=12]
setblock 66 213 247 minecraft:light[level=12]
setblock 66 213 255 minecraft:light[level=12]
setblock 66 213 263 minecraft:light[level=12]
setblock 74 213 231 minecraft:light[level=12]
setblock 74 213 239 minecraft:light[level=12]
setblock 74 213 247 minecraft:light[level=12]
setblock 74 213 255 minecraft:light[level=12]
setblock 74 213 263 minecraft:light[level=12]
setblock 82 213 231 minecraft:light[level=12]
setblock 82 213 239 minecraft:light[level=12]
setblock 82 213 247 minecraft:light[level=12]
setblock 82 213 255 minecraft:light[level=12]
setblock 82 213 263 minecraft:light[level=12]
fill 48 216 229 48 219 232 minecraft:stone_bricks
fill 48 216 233 48 218 237 minecraft:polished_andesite
fill 48 216 238 48 218 242 minecraft:stone_bricks
fill 48 216 243 48 218 247 minecraft:polished_andesite
fill 48 216 248 48 218 252 minecraft:stone_bricks
fill 48 216 253 48 218 257 minecraft:polished_andesite
fill 48 216 258 48 218 262 minecraft:stone_bricks
fill 48 216 263 48 218 267 minecraft:polished_andesite
fill 48 216 268 48 218 269 minecraft:stone_bricks
fill 49 216 229 53 218 232 minecraft:polished_andesite
fill 49 216 233 53 218 237 minecraft:stone_bricks
fill 49 216 238 53 218 242 minecraft:polished_andesite
fill 49 216 243 53 218 247 minecraft:stone_bricks
fill 49 216 248 53 218 252 minecraft:polished_andesite
fill 49 216 253 53 218 257 minecraft:stone_bricks
fill 49 216 258 53 218 262 minecraft:polished_andesite
fill 49 216 263 53 218 267 minecraft:stone_bricks
fill 49 216 268 53 218 269 minecraft:polished_andesite
fill 54 216 229 58 218 232 minecraft:stone_bricks
fill 54 216 233 58 218 237 minecraft:polished_andesite
fill 54 216 238 58 218 242 minecraft:stone_bricks
fill 54 216 243 58 218 247 minecraft:polished_andesite
fill 54 216 248 58 218 252 minecraft:stone_bricks
fill 54 216 253 58 218 257 minecraft:polished_andesite
fill 54 216 258 58 218 262 minecraft:stone_bricks
fill 54 216 263 58 218 267 minecraft:polished_andesite
fill 54 216 268 58 218 269 minecraft:stone_bricks
fill 59 216 229 63 218 232 minecraft:polished_andesite
fill 59 216 233 63 218 237 minecraft:stone_bricks
fill 59 216 238 63 218 242 minecraft:polished_andesite
fill 59 216 243 63 218 247 minecraft:stone_bricks
fill 59 216 248 63 218 252 minecraft:polished_andesite
fill 59 216 253 63 218 257 minecraft:stone_bricks
fill 59 216 258 63 218 262 minecraft:polished_andesite
fill 59 216 263 63 218 267 minecraft:stone_bricks
fill 59 216 268 63 218 269 minecraft:polished_andesite
fill 64 216 229 68 218 232 minecraft:stone_bricks
fill 64 216 233 68 218 237 minecraft:polished_andesite
fill 64 216 238 68 218 242 minecraft:stone_bricks
fill 64 216 243 66 218 247 minecraft:polished_andesite
fill 64 216 248 65 218 252 minecraft:stone_bricks
fill 64 216 253 68 218 257 minecraft:polished_andesite
fill 64 216 258 68 218 262 minecraft:stone_bricks
fill 64 216 263 68 218 267 minecraft:polished_andesite
fill 64 216 268 68 218 269 minecraft:stone_bricks
fill 66 216 249 66 218 252 minecraft:stone_bricks
fill 67 216 243 68 218 245 minecraft:polished_andesite
fill 67 216 251 68 218 252 minecraft:stone_bricks
fill 69 216 229 73 218 232 minecraft:polished_andesite
fill 69 216 233 73 218 237 minecraft:stone_bricks
fill 69 216 238 73 218 242 minecraft:polished_andesite
fill 69 216 243 73 218 244 minecraft:stone_bricks
fill 69 216 252 73 218 252 minecraft:polished_andesite
fill 69 216 253 73 218 257 minecraft:stone_bricks
fill 69 216 258 73 218 262 minecraft:polished_andesite
fill 69 216 263 73 218 267 minecraft:stone_bricks
fill 69 216 268 73 218 269 minecraft:polished_andesite
fill 70 216 245 73 218 245 minecraft:stone_bricks
fill 70 216 251 73 218 251 minecraft:polished_andesite
fill 72 216 246 73 218 247 minecraft:stone_bricks
fill 72 216 249 73 218 250 minecraft:polished_andesite
fill 73 216 248 73 218 248 minecraft:polished_andesite
fill 74 216 229 78 218 232 minecraft:stone_bricks
fill 74 216 233 78 218 237 minecraft:polished_andesite
fill 74 216 238 78 218 242 minecraft:stone_bricks
fill 74 216 243 78 218 247 minecraft:polished_andesite
fill 74 216 248 78 218 252 minecraft:stone_bricks
fill 74 216 253 78 218 257 minecraft:polished_andesite
fill 74 216 258 78 218 262 minecraft:stone_bricks
fill 74 216 263 78 218 267 minecraft:polished_andesite
fill 74 216 268 78 218 269 minecraft:stone_bricks
fill 79 216 229 83 218 232 minecraft:polished_andesite
fill 79 216 233 83 218 237 minecraft:stone_bricks
fill 79 216 238 83 218 242 minecraft:polished_andesite
fill 79 216 243 83 218 247 minecraft:stone_bricks
fill 79 216 248 83 218 252 minecraft:polished_andesite
fill 79 216 253 83 218 257 minecraft:stone_bricks
fill 79 216 258 83 218 262 minecraft:polished_andesite
fill 79 216 263 83 218 267 minecraft:stone_bricks
fill 79 216 268 83 218 269 minecraft:polished_andesite
fill 84 216 229 88 218 232 minecraft:stone_bricks
fill 84 216 233 88 218 237 minecraft:polished_andesite
fill 84 216 238 88 218 242 minecraft:stone_bricks
fill 84 216 243 88 218 247 minecraft:polished_andesite
fill 84 216 248 88 218 252 minecraft:stone_bricks
fill 84 216 253 88 218 257 minecraft:polished_andesite
fill 84 216 258 88 218 262 minecraft:stone_bricks
fill 84 216 263 88 218 267 minecraft:polished_andesite
fill 84 216 268 88 218 269 minecraft:stone_bricks
fill 48 219 233 88 219 233 minecraft:iron_block
fill 48 219 234 48 219 237 minecraft:polished_andesite
fill 48 219 238 88 219 238 minecraft:iron_block
fill 48 219 239 48 219 242 minecraft:stone_bricks
fill 48 219 243 88 219 243 minecraft:iron_block
fill 48 219 244 48 219 247 minecraft:polished_andesite
fill 48 219 248 64 219 248 minecraft:iron_block
fill 48 219 249 48 219 252 minecraft:stone_bricks
fill 48 219 253 88 219 253 minecraft:iron_block
fill 48 219 254 48 219 257 minecraft:polished_andesite
fill 48 219 258 88 219 258 minecraft:iron_block
fill 48 219 259 48 219 262 minecraft:stone_bricks
fill 48 219 263 88 219 263 minecraft:iron_block
fill 48 219 264 48 219 267 minecraft:polished_andesite
fill 48 219 268 88 219 268 minecraft:iron_block
setblock 48 219 269 minecraft:stone_bricks
fill 49 219 229 49 219 232 minecraft:iron_block
fill 49 219 234 49 219 237 minecraft:iron_block
fill 49 219 239 49 219 242 minecraft:iron_block
fill 49 219 244 49 219 247 minecraft:iron_block
fill 49 219 249 49 219 252 minecraft:iron_block
fill 49 219 254 49 219 257 minecraft:iron_block
fill 49 219 259 49 219 262 minecraft:iron_block
fill 49 219 264 49 219 267 minecraft:iron_block
setblock 49 219 269 minecraft:iron_block
fill 50 219 229 53 219 232 minecraft:polished_andesite
fill 50 219 234 53 219 237 minecraft:stone_bricks
fill 50 219 239 53 219 242 minecraft:polished_andesite
fill 50 219 244 53 219 247 minecraft:stone_bricks
fill 50 219 249 53 219 252 minecraft:polished_andesite
fill 50 219 254 53 219 257 minecraft:stone_bricks
fill 50 219 259 53 219 262 minecraft:polished_andesite
fill 50 219 264 53 219 267 minecraft:stone_bricks
fill 50 219 269 53 219 269 minecraft:polished_andesite
fill 54 219 229 54 219 232 minecraft:iron_block
fill 54 219 234 54 219 237 minecraft:iron_block
fill 54 219 239 54 219 242 minecraft:iron_block
fill 54 219 244 54 219 247 minecraft:iron_block
fill 54 219 249 54 219 252 minecraft:iron_block
fill 54 219 254 54 219 257 minecraft:iron_block
fill 54 219 259 54 219 262 minecraft:iron_block
fill 54 219 264 54 219 267 minecraft:iron_block
setblock 54 219 269 minecraft:iron_block
fill 55 219 229 58 219 232 minecraft:stone_bricks
fill 55 219 234 58 219 237 minecraft:polished_andesite
fill 55 219 239 58 219 242 minecraft:stone_bricks
fill 55 219 244 58 219 247 minecraft:polished_andesite
fill 55 219 249 58 219 252 minecraft:stone_bricks
fill 55 219 254 58 219 257 minecraft:polished_andesite
fill 55 219 259 58 219 262 minecraft:stone_bricks
fill 55 219 264 58 219 267 minecraft:polished_andesite
fill 55 219 269 58 219 269 minecraft:stone_bricks
fill 59 219 229 59 219 232 minecraft:iron_block
fill 59 219 234 59 219 237 minecraft:iron_block
fill 59 219 239 59 219 242 minecraft:iron_block
fill 59 219 244 59 219 247 minecraft:iron_block
fill 59 219 249 59 219 252 minecraft:iron_block
fill 59 219 254 59 219 257 minecraft:iron_block
fill 59 219 259 59 219 262 minecraft:iron_block
fill 59 219 264 59 219 267 minecraft:iron_block
setblock 59 219 269 minecraft:iron_block
fill 60 219 229 63 219 232 minecraft:polished_andesite
fill 60 219 234 63 219 237 minecraft:stone_bricks
fill 60 219 239 63 219 242 minecraft:polished_andesite
fill 60 219 244 63 219 247 minecraft:stone_bricks
fill 60 219 249 63 219 252 minecraft:polished_andesite
fill 60 219 254 63 219 257 minecraft:stone_bricks
fill 60 219 259 63 219 262 minecraft:polished_andesite
fill 60 219 264 63 219 267 minecraft:stone_bricks
fill 60 219 269 63 219 269 minecraft:polished_andesite
fill 64 219 229 64 219 232 minecraft:iron_block
fill 64 219 234 64 219 237 minecraft:iron_block
fill 64 219 239 64 219 242 minecraft:iron_block
fill 64 219 244 64 219 247 minecraft:iron_block
fill 64 219 249 64 219 252 minecraft:iron_block
fill 64 219 254 64 219 257 minecraft:iron_block
fill 64 219 259 64 219 262 minecraft:iron_block
fill 64 219 264 64 219 267 minecraft:iron_block
setblock 64 219 269 minecraft:iron_block
fill 65 219 229 68 219 232 minecraft:stone_bricks
fill 65 219 234 68 219 237 minecraft:polished_andesite
fill 65 219 239 68 219 242 minecraft:stone_bricks
fill 65 219 244 65 219 246 minecraft:polished_andesite
fill 65 219 247 65 219 249 minecraft:lantern
fill 65 219 250 65 219 252 minecraft:stone_bricks
fill 65 219 254 68 219 257 minecraft:polished_andesite
fill 65 219 259 68 219 262 minecraft:stone_bricks
fill 65 219 264 68 219 267 minecraft:polished_andesite
fill 65 219 269 68 219 269 minecraft:stone_bricks
fill 66 219 244 67 219 244 minecraft:polished_andesite
fill 66 219 245 66 219 247 minecraft:lantern
fill 66 219 249 66 219 251 minecraft:lantern
fill 66 219 252 67 219 252 minecraft:stone_bricks
fill 67 219 245 68 219 245 minecraft:lantern
fill 67 219 251 68 219 251 minecraft:lantern
fill 68 219 244 70 219 244 minecraft:lantern
fill 68 219 252 70 219 252 minecraft:lantern
fill 69 219 229 69 219 232 minecraft:iron_block
fill 69 219 234 69 219 237 minecraft:iron_block
fill 69 219 239 69 219 242 minecraft:iron_block
fill 69 219 254 69 219 257 minecraft:iron_block
fill 69 219 259 69 219 262 minecraft:iron_block
fill 69 219 264 69 219 267 minecraft:iron_block
setblock 69 219 269 minecraft:iron_block
fill 70 219 229 73 219 232 minecraft:polished_andesite
fill 70 219 234 73 219 237 minecraft:stone_bricks
fill 70 219 239 73 219 242 minecraft:polished_andesite
fill 70 219 245 72 219 245 minecraft:lantern
fill 70 219 251 72 219 251 minecraft:lantern
fill 70 219 254 73 219 257 minecraft:stone_bricks
fill 70 219 259 73 219 262 minecraft:polished_andesite
fill 70 219 264 73 219 267 minecraft:stone_bricks
fill 70 219 269 73 219 269 minecraft:polished_andesite
fill 71 219 244 73 219 244 minecraft:stone_bricks
fill 71 219 252 73 219 252 minecraft:polished_andesite
fill 72 219 246 72 219 247 minecraft:lantern
fill 72 219 249 72 219 250 minecraft:lantern
fill 73 219 245 73 219 246 minecraft:stone_bricks
fill 73 219 247 73 219 249 minecraft:lantern
fill 73 219 250 73 219 251 minecraft:polished_andesite
fill 74 219 229 74 219 232 minecraft:iron_block
fill 74 219 234 74 219 237 minecraft:iron_block
fill 74 219 239 74 219 242 minecraft:iron_block
fill 74 219 244 74 219 252 minecraft:iron_block
fill 74 219 254 74 219 257 minecraft:iron_block
fill 74 219 259 74 219 262 minecraft:iron_block
fill 74 219 264 74 219 267 minecraft:iron_block
setblock 74 219 269 minecraft:iron_block
fill 75 219 229 78 219 232 minecraft:stone_bricks
fill 75 219 234 78 219 237 minecraft:polished_andesite
fill 75 219 239 78 219 242 minecraft:stone_bricks
fill 75 219 244 78 219 247 minecraft:polished_andesite
fill 75 219 248 88 219 248 minecraft:iron_block
fill 75 219 249 78 219 252 minecraft:stone_bricks
fill 75 219 254 78 219 257 minecraft:polished_andesite
fill 75 219 259 78 219 262 minecraft:stone_bricks
fill 75 219 264 78 219 267 minecraft:polished_andesite
fill 75 219 269 78 219 269 minecraft:stone_bricks
fill 79 219 229 79 219 232 minecraft:iron_block
fill 79 219 234 79 219 237 minecraft:iron_block
fill 79 219 239 79 219 242 minecraft:iron_block
fill 79 219 244 79 219 247 minecraft:iron_block
fill 79 219 249 79 219 252 minecraft:iron_block
fill 79 219 254 79 219 257 minecraft:iron_block
fill 79 219 259 79 219 262 minecraft:iron_block
fill 79 219 264 79 219 267 minecraft:iron_block
setblock 79 219 269 minecraft:iron_block
fill 80 219 229 83 219 232 minecraft:polished_andesite
fill 80 219 234 83 219 237 minecraft:stone_bricks
fill 80 219 239 83 219 242 minecraft:polished_andesite
fill 80 219 244 83 219 247 minecraft:stone_bricks
fill 80 219 249 83 219 252 minecraft:polished_andesite
fill 80 219 254 83 219 257 minecraft:stone_bricks
fill 80 219 259 83 219 262 minecraft:polished_andesite
fill 80 219 264 83 219 267 minecraft:stone_bricks
fill 80 219 269 83 219 269 minecraft:polished_andesite
fill 84 219 229 84 219 232 minecraft:iron_block
fill 84 219 234 84 219 237 minecraft:iron_block
fill 84 219 239 84 219 242 minecraft:iron_block
fill 84 219 244 84 219 247 minecraft:iron_block
fill 84 219 249 84 219 252 minecraft:iron_block
fill 84 219 254 84 219 257 minecraft:iron_block
fill 84 219 259 84 219 262 minecraft:iron_block
fill 84 219 264 84 219 267 minecraft:iron_block
setblock 84 219 269 minecraft:iron_block
fill 85 219 229 88 219 232 minecraft:stone_bricks
fill 85 219 234 88 219 237 minecraft:polished_andesite
fill 85 219 239 88 219 242 minecraft:stone_bricks
fill 85 219 244 88 219 247 minecraft:polished_andesite
fill 85 219 249 88 219 252 minecraft:stone_bricks
fill 85 219 254 88 219 257 minecraft:polished_andesite
fill 85 219 259 88 219 262 minecraft:stone_bricks
fill 85 219 264 88 219 267 minecraft:polished_andesite
fill 85 219 269 88 219 269 minecraft:stone_bricks
setblock 50 221 231 minecraft:light[level=12]
setblock 50 221 239 minecraft:light[level=12]
setblock 50 221 247 minecraft:light[level=12]
setblock 50 221 255 minecraft:light[level=12]
setblock 50 221 263 minecraft:light[level=12]
setblock 58 221 231 minecraft:light[level=12]
setblock 58 221 239 minecraft:light[level=12]
setblock 58 221 247 minecraft:light[level=12]
setblock 58 221 255 minecraft:light[level=12]
setblock 58 221 263 minecraft:light[level=12]
setblock 66 221 231 minecraft:light[level=12]
setblock 66 221 239 minecraft:light[level=12]
setblock 66 221 247 minecraft:light[level=12]
setblock 66 221 255 minecraft:light[level=12]
setblock 66 221 263 minecraft:light[level=12]
setblock 74 221 231 minecraft:light[level=12]
setblock 74 221 239 minecraft:light[level=12]
setblock 74 221 247 minecraft:light[level=12]
setblock 74 221 255 minecraft:light[level=12]
setblock 74 221 263 minecraft:light[level=12]
setblock 82 221 231 minecraft:light[level=12]
setblock 82 221 239 minecraft:light[level=12]
setblock 82 221 247 minecraft:light[level=12]
setblock 82 221 255 minecraft:light[level=12]
setblock 82 221 263 minecraft:light[level=12]
fill 48 223 229 50 272 229 minecraft:polished_andesite
fill 48 223 235 50 223 235 minecraft:iron_block
fill 48 223 239 48 272 241 minecraft:polished_andesite
fill 48 223 251 48 272 253 minecraft:polished_andesite
fill 48 223 263 48 272 265 minecraft:polished_andesite
fill 49 223 238 49 225 240 minecraft:polished_andesite
fill 49 223 250 49 225 252 minecraft:polished_andesite
fill 49 223 262 49 225 264 minecraft:polished_andesite
fill 54 223 269 56 272 269 minecraft:polished_andesite
fill 55 223 268 57 225 268 minecraft:polished_andesite
fill 59 223 230 61 225 230 minecraft:polished_andesite
fill 60 223 229 62 272 229 minecraft:polished_andesite
fill 66 223 269 68 272 269 minecraft:polished_andesite
fill 67 223 268 69 225 268 minecraft:polished_andesite
fill 71 223 230 73 225 230 minecraft:polished_andesite
fill 72 223 229 74 272 229 minecraft:polished_andesite
fill 78 223 269 80 272 269 minecraft:polished_andesite
fill 79 223 268 81 225 268 minecraft:polished_andesite
fill 83 223 230 85 225 230 minecraft:polished_andesite
fill 83 223 233 83 233 233 minecraft:moss_block
fill 84 223 229 86 272 229 minecraft:polished_andesite
fill 87 223 238 87 225 240 minecraft:polished_andesite
fill 87 223 250 87 225 252 minecraft:polished_andesite
fill 87 223 262 87 225 264 minecraft:polished_andesite
fill 88 223 237 88 272 239 minecraft:polished_andesite
fill 88 223 249 88 272 251 minecraft:polished_andesite
fill 88 223 261 88 272 263 minecraft:polished_andesite
fill 48 225 232 48 225 237 minecraft:deepslate_bricks
fill 48 225 244 48 225 249 minecraft:deepslate_bricks
fill 48 225 256 48 225 261 minecraft:deepslate_bricks
fill 48 225 268 48 225 269 minecraft:deepslate_bricks
fill 49 225 269 52 225 269 minecraft:deepslate_bricks
fill 52 225 229 57 225 229 minecraft:deepslate_bricks
fill 59 225 269 64 225 269 minecraft:deepslate_bricks
fill 64 225 229 69 225 229 minecraft:deepslate_bricks
fill 71 225 269 76 225 269 minecraft:deepslate_bricks
fill 76 225 229 81 225 229 minecraft:deepslate_bricks
fill 82 225 266 82 226 268 minecraft:iron_block
fill 83 225 269 88 225 269 minecraft:deepslate_bricks
fill 88 225 229 88 225 234 minecraft:deepslate_bricks
fill 88 225 241 88 225 246 minecraft:deepslate_bricks
fill 88 225 253 88 225 258 minecraft:deepslate_bricks
fill 88 225 265 88 225 268 minecraft:deepslate_bricks
fill 47 226 234 47 231 237 minecraft:lantern
fill 47 226 246 47 231 249 minecraft:lantern
fill 47 226 258 47 231 261 minecraft:lantern
fill 47 226 270 50 231 270 minecraft:lantern
fill 54 226 228 57 231 228 minecraft:lantern
fill 59 226 270 62 231 270 minecraft:lantern
fill 66 226 228 69 231 228 minecraft:lantern
fill 71 226 270 74 231 270 minecraft:lantern
fill 78 226 228 81 231 228 minecraft:lantern
fill 83 226 270 86 231 270 minecraft:lantern
fill 89 226 229 89 231 232 minecraft:lantern
fill 89 226 241 89 231 244 minecraft:lantern
fill 89 226 253 89 231 256 minecraft:lantern
fill 89 226 265 89 231 268 minecraft:lantern
setblock 50 229 231 minecraft:light[level=12]
setblock 50 229 239 minecraft:light[level=12]
setblock 50 229 247 minecraft:light[level=12]
setblock 50 229 255 minecraft:light[level=12]
setblock 50 229 263 minecraft:light[level=12]
setblock 58 229 231 minecraft:light[level=12]
setblock 58 229 239 minecraft:light[level=12]
setblock 58 229 247 minecraft:light[level=12]
setblock 58 229 255 minecraft:light[level=12]
setblock 58 229 263 minecraft:light[level=12]
setblock 66 229 231 minecraft:light[level=12]
setblock 66 229 239 minecraft:light[level=12]
setblock 66 229 247 minecraft:light[level=12]
setblock 66 229 255 minecraft:light[level=12]
setblock 66 229 263 minecraft:light[level=12]
setblock 74 229 231 minecraft:light[level=12]
setblock 74 229 239 minecraft:light[level=12]
setblock 74 229 247 minecraft:light[level=12]
setblock 74 229 255 minecraft:light[level=12]
setblock 74 229 263 minecraft:light[level=12]
setblock 82 229 231 minecraft:light[level=12]
setblock 82 229 239 minecraft:light[level=12]
setblock 82 229 247 minecraft:light[level=12]
setblock 82 229 255 minecraft:light[level=12]
setblock 82 229 263 minecraft:light[level=12]
fill 47 232 234 47 245 234 minecraft:stone_bricks
fill 47 232 235 47 232 236 minecraft:lantern
fill 47 232 237 47 245 237 minecraft:stone_bricks
fill 47 232 246 47 245 246 minecraft:stone_bricks
fill 47 232 247 47 232 248 minecraft:lantern
fill 47 232 249 47 245 249 minecraft:stone_bricks
fill 47 232 258 47 245 258 minecraft:stone_bricks
fill 47 232 259 47 232 260 minecraft:lantern
fill 47 232 261 47 245 261 minecraft:stone_bricks
fill 47 232 270 47 245 270 minecraft:stone_bricks
fill 48 232 270 49 232 270 minecraft:lantern
fill 50 232 270 50 245 270 minecraft:stone_bricks
fill 54 232 228 54 245 228 minecraft:stone_bricks
fill 55 232 228 56 232 228 minecraft:lantern
fill 57 232 228 57 245 228 minecraft:stone_bricks
fill 59 232 270 59 245 270 minecraft:stone_bricks
fill 60 232 270 61 232 270 minecraft:lantern
fill 62 232 270 62 245 270 minecraft:stone_bricks
fill 66 232 228 66 245 228 minecraft:stone_bricks
fill 67 232 228 68 232 228 minecraft:lantern
fill 69 232 228 69 245 228 minecraft:stone_bricks
fill 71 232 270 71 245 270 minecraft:stone_bricks
fill 72 232 270 73 232 270 minecraft:lantern
fill 74 232 270 74 245 270 minecraft:stone_bricks
fill 78 232 228 78 245 228 minecraft:stone_bricks
fill 79 232 228 80 232 228 minecraft:lantern
fill 81 232 228 81 245 228 minecraft:stone_bricks
fill 83 232 270 83 245 270 minecraft:stone_bricks
fill 84 232 270 85 232 270 minecraft:lantern
fill 86 232 270 86 245 270 minecraft:stone_bricks
fill 89 232 229 89 245 229 minecraft:stone_bricks
fill 89 232 230 89 232 231 minecraft:lantern
fill 89 232 232 89 245 232 minecraft:stone_bricks
fill 89 232 241 89 245 241 minecraft:stone_bricks
fill 89 232 242 89 232 243 minecraft:lantern
fill 89 232 244 89 245 244 minecraft:stone_bricks
fill 89 232 253 89 245 253 minecraft:stone_bricks
fill 89 232 254 89 232 255 minecraft:lantern
fill 89 232 256 89 245 256 minecraft:stone_bricks
fill 89 232 265 89 245 265 minecraft:stone_bricks
fill 89 232 266 89 232 267 minecraft:lantern
fill 89 232 268 89 245 268 minecraft:stone_bricks
fill 47 233 235 47 245 236 minecraft:stone_bricks
fill 47 233 247 47 245 248 minecraft:stone_bricks
fill 47 233 259 47 245 260 minecraft:stone_bricks
fill 48 233 270 49 245 270 minecraft:stone_bricks
fill 55 233 228 56 245 228 minecraft:stone_bricks
fill 60 233 270 61 245 270 minecraft:stone_bricks
fill 67 233 228 68 245 228 minecraft:stone_bricks
fill 72 233 270 73 245 270 minecraft:stone_bricks
fill 79 233 228 80 245 228 minecraft:stone_bricks
fill 84 233 270 85 245 270 minecraft:stone_bricks
fill 89 233 230 89 245 231 minecraft:stone_bricks
fill 89 233 242 89 245 243 minecraft:stone_bricks
fill 89 233 254 89 245 255 minecraft:stone_bricks
fill 89 233 266 89 245 267 minecraft:stone_bricks
setblock 50 237 231 minecraft:light[level=12]
setblock 50 237 239 minecraft:light[level=12]
setblock 50 237 247 minecraft:light[level=12]
setblock 50 237 255 minecraft:light[level=12]
setblock 50 237 263 minecraft:light[level=12]
setblock 58 237 231 minecraft:light[level=12]
setblock 58 237 239 minecraft:light[level=12]
setblock 58 237 247 minecraft:light[level=12]
setblock 58 237 255 minecraft:light[level=12]
setblock 58 237 263 minecraft:light[level=12]
setblock 66 237 231 minecraft:light[level=12]
setblock 66 237 239 minecraft:light[level=12]
setblock 66 237 247 minecraft:light[level=12]
setblock 66 237 255 minecraft:light[level=12]
setblock 66 237 263 minecraft:light[level=12]
setblock 74 237 231 minecraft:light[level=12]
setblock 74 237 239 minecraft:light[level=12]
setblock 74 237 247 minecraft:light[level=12]
setblock 74 237 255 minecraft:light[level=12]
setblock 74 237 263 minecraft:light[level=12]
setblock 82 237 231 minecraft:light[level=12]
setblock 82 237 239 minecraft:light[level=12]
setblock 82 237 247 minecraft:light[level=12]
setblock 82 237 255 minecraft:light[level=12]
setblock 82 237 263 minecraft:light[level=12]
fill 49 240 238 49 245 240 minecraft:polished_andesite
fill 49 240 250 49 245 252 minecraft:polished_andesite
fill 49 240 262 49 245 264 minecraft:polished_andesite
fill 50 240 235 50 241 235 minecraft:deepslate_bricks
fill 54 240 241 54 241 241 minecraft:deepslate_bricks
fill 55 240 268 57 245 268 minecraft:polished_andesite
fill 59 240 230 61 245 230 minecraft:polished_andesite
fill 67 240 268 69 245 268 minecraft:polished_andesite
fill 70 240 235 70 241 235 minecraft:deepslate_bricks
fill 71 240 230 73 245 230 minecraft:polished_andesite
fill 71 240 262 71 241 262 minecraft:deepslate_bricks
fill 79 240 235 79 241 235 minecraft:deepslate_bricks
fill 79 240 268 81 245 268 minecraft:polished_andesite
fill 81 240 242 81 241 242 minecraft:deepslate_bricks
fill 83 240 230 85 245 230 minecraft:polished_andesite
fill 87 240 238 87 245 240 minecraft:polished_andesite
fill 87 240 250 87 245 252 minecraft:polished_andesite
fill 87 240 262 87 245 264 minecraft:polished_andesite
fill 50 241 234 50 242 234 minecraft:deepslate_bricks
fill 53 241 241 53 242 241 minecraft:deepslate_bricks
fill 70 241 234 70 242 234 minecraft:deepslate_bricks
fill 71 241 263 71 242 263 minecraft:deepslate_bricks
fill 79 241 234 79 242 234 minecraft:deepslate_bricks
fill 82 241 242 82 242 242 minecraft:deepslate_bricks
fill 50 242 233 50 243 233 minecraft:deepslate_bricks
fill 52 242 241 52 243 241 minecraft:deepslate_bricks
fill 70 242 233 70 243 233 minecraft:deepslate_bricks
fill 71 242 264 71 243 264 minecraft:deepslate_bricks
fill 79 242 233 79 243 233 minecraft:deepslate_bricks
fill 83 242 242 83 243 242 minecraft:deepslate_bricks
fill 50 243 232 50 244 232 minecraft:deepslate_bricks
fill 51 243 241 51 244 241 minecraft:deepslate_bricks
fill 70 243 232 70 244 232 minecraft:deepslate_bricks
fill 71 243 265 71 244 265 minecraft:deepslate_bricks
fill 79 243 232 79 244 232 minecraft:deepslate_bricks
fill 84 243 242 84 244 242 minecraft:deepslate_bricks
fill 50 244 231 50 245 231 minecraft:deepslate_bricks
fill 50 244 241 50 245 241 minecraft:deepslate_bricks
fill 70 244 231 70 245 231 minecraft:deepslate_bricks
fill 71 244 266 71 245 266 minecraft:deepslate_bricks
fill 79 244 231 79 245 231 minecraft:deepslate_bricks
fill 85 244 242 85 245 242 minecraft:deepslate_bricks
fill 48 245 232 48 245 237 minecraft:deepslate_bricks
fill 48 245 244 48 245 249 minecraft:deepslate_bricks
fill 48 245 256 48 245 261 minecraft:deepslate_bricks
fill 48 245 268 48 245 269 minecraft:deepslate_bricks
fill 49 245 241 49 246 241 minecraft:deepslate_bricks
fill 49 245 269 52 245 269 minecraft:deepslate_bricks
fill 50 245 230 50 246 230 minecraft:deepslate_bricks
setblock 50 245 239 minecraft:light[level=12]
setblock 50 245 247 minecraft:light[level=12]
setblock 50 245 255 minecraft:light[level=12]
setblock 50 245 263 minecraft:light[level=12]
fill 52 245 229 57 245 229 minecraft:deepslate_bricks
setblock 58 245 231 minecraft:light[level=12]
setblock 58 245 239 minecraft:light[level=12]
setblock 58 245 247 minecraft:light[level=12]
setblock 58 245 255 minecraft:light[level=12]
setblock 58 245 263 minecraft:light[level=12]
fill 59 245 269 64 245 269 minecraft:deepslate_bricks
fill 64 245 229 69 245 229 minecraft:deepslate_bricks
setblock 66 245 231 minecraft:light[level=12]
setblock 66 245 239 minecraft:light[level=12]
setblock 66 245 247 minecraft:light[level=12]
setblock 66 245 255 minecraft:light[level=12]
setblock 66 245 263 minecraft:light[level=12]
fill 70 245 230 70 246 230 minecraft:deepslate_bricks
fill 71 245 267 71 246 267 minecraft:deepslate_bricks
fill 71 245 269 76 245 269 minecraft:deepslate_bricks
setblock 74 245 231 minecraft:light[level=12]
setblock 74 245 239 minecraft:light[level=12]
setblock 74 245 247 minecraft:light[level=12]
setblock 74 245 255 minecraft:light[level=12]
setblock 74 245 263 minecraft:light[level=12]
fill 76 245 229 81 245 229 minecraft:deepslate_bricks
fill 79 245 230 79 246 230 minecraft:deepslate_bricks
setblock 82 245 231 minecraft:light[level=12]
setblock 82 245 239 minecraft:light[level=12]
setblock 82 245 247 minecraft:light[level=12]
setblock 82 245 255 minecraft:light[level=12]
setblock 82 245 263 minecraft:light[level=12]
fill 83 245 269 88 245 269 minecraft:deepslate_bricks
fill 86 245 242 86 246 242 minecraft:deepslate_bricks
fill 88 245 229 88 245 234 minecraft:deepslate_bricks
fill 88 245 241 88 245 246 minecraft:deepslate_bricks
fill 88 245 253 88 245 258 minecraft:deepslate_bricks
fill 88 245 265 88 245 268 minecraft:deepslate_bricks
fill 47 246 234 47 251 237 minecraft:lantern
fill 47 246 246 47 251 249 minecraft:lantern
fill 47 246 258 47 251 261 minecraft:lantern
fill 47 246 270 50 251 270 minecraft:lantern
fill 54 246 228 57 251 228 minecraft:lantern
fill 59 246 270 62 251 270 minecraft:lantern
fill 66 246 228 69 251 228 minecraft:lantern
fill 70 246 229 70 247 229 minecraft:deepslate_bricks
fill 71 246 268 71 247 268 minecraft:deepslate_bricks
fill 71 246 270 74 251 270 minecraft:lantern
fill 78 246 228 81 251 228 minecraft:lantern
fill 79 246 229 79 247 229 minecraft:deepslate_bricks
fill 83 246 270 86 251 270 minecraft:lantern
fill 87 246 242 87 247 242 minecraft:deepslate_bricks
fill 89 246 229 89 251 232 minecraft:lantern
fill 89 246 241 89 251 244 minecraft:lantern
fill 89 246 253 89 251 256 minecraft:lantern
fill 89 246 265 89 251 268 minecraft:lantern
setblock 54 247 239 minecraft:lantern
setblock 54 247 245 minecraft:lantern
setblock 54 247 251 minecraft:lantern
setblock 54 247 257 minecraft:lantern
setblock 54 247 263 minecraft:lantern
setblock 58 247 235 minecraft:lantern
setblock 60 247 263 minecraft:lantern
setblock 64 247 235 minecraft:lantern
setblock 66 247 263 minecraft:lantern
setblock 70 247 235 minecraft:lantern
setblock 72 247 263 minecraft:lantern
setblock 76 247 235 minecraft:lantern
setblock 78 247 263 minecraft:lantern
setblock 82 247 235 minecraft:lantern
setblock 82 247 241 minecraft:lantern
setblock 82 247 247 minecraft:lantern
setblock 82 247 253 minecraft:lantern
setblock 82 247 259 minecraft:lantern
fill 85 247 263 87 248 263 minecraft:iron_block
fill 48 248 230 54 248 238 minecraft:polished_andesite
fill 48 248 242 54 248 250 minecraft:polished_andesite
fill 48 248 254 54 248 262 minecraft:polished_andesite
fill 48 248 266 53 248 269 minecraft:polished_andesite
fill 49 248 239 54 248 241 minecraft:polished_andesite
fill 49 248 251 54 248 253 minecraft:polished_andesite
fill 49 248 263 84 248 265 minecraft:polished_andesite
fill 51 248 229 59 248 229 minecraft:polished_andesite
fill 54 248 266 88 248 268 minecraft:polished_andesite
fill 55 248 230 88 248 235 minecraft:polished_andesite
fill 57 248 269 65 248 269 minecraft:polished_andesite
fill 63 248 229 71 248 229 minecraft:polished_andesite
fill 69 248 269 77 248 269 minecraft:polished_andesite
fill 75 248 229 83 248 229 minecraft:polished_andesite
fill 81 248 269 88 248 269 minecraft:polished_andesite
fill 82 248 236 87 248 262 minecraft:polished_andesite
fill 85 248 264 88 248 265 minecraft:polished_andesite
fill 87 248 229 88 248 229 minecraft:polished_andesite
setblock 88 248 236 minecraft:polished_andesite
fill 88 248 240 88 248 248 minecraft:polished_andesite
fill 88 248 252 88 248 260 minecraft:polished_andesite
fill 54 249 235 54 249 263 minecraft:iron_block
fill 55 249 235 82 249 235 minecraft:iron_block
fill 55 249 263 82 249 263 minecraft:iron_block
fill 82 249 236 82 249 262 minecraft:iron_block
fill 47 252 234 47 265 234 minecraft:stone_bricks
fill 47 252 235 47 252 236 minecraft:lantern
fill 47 252 237 47 265 237 minecraft:stone_bricks
fill 47 252 246 47 265 246 minecraft:stone_bricks
fill 47 252 247 47 252 248 minecraft:lantern
fill 47 252 249 47 265 249 minecraft:stone_bricks
fill 47 252 258 47 265 258 minecraft:stone_bricks
fill 47 252 259 47 252 260 minecraft:lantern
fill 47 252 261 47 265 261 minecraft:stone_bricks
fill 47 252 270 47 265 270 minecraft:stone_bricks
fill 48 252 270 49 252 270 minecraft:lantern
fill 50 252 270 50 265 270 minecraft:stone_bricks
fill 54 252 228 54 265 228 minecraft:stone_bricks
fill 55 252 228 56 252 228 minecraft:lantern
fill 57 252 228 57 265 228 minecraft:stone_bricks
fill 59 252 270 59 265 270 minecraft:stone_bricks
fill 60 252 270 61 252 270 minecraft:lantern
fill 62 252 270 62 265 270 minecraft:stone_bricks
fill 66 252 228 66 265 228 minecraft:stone_bricks
fill 67 252 228 68 252 228 minecraft:lantern
fill 69 252 228 69 265 228 minecraft:stone_bricks
fill 71 252 270 71 265 270 minecraft:stone_bricks
fill 72 252 270 73 252 270 minecraft:lantern
fill 74 252 270 74 265 270 minecraft:stone_bricks
fill 78 252 228 78 265 228 minecraft:stone_bricks
fill 79 252 228 80 252 228 minecraft:lantern
fill 81 252 228 81 265 228 minecraft:stone_bricks
fill 83 252 270 83 265 270 minecraft:stone_bricks
fill 84 252 270 85 252 270 minecraft:lantern
fill 86 252 270 86 265 270 minecraft:stone_bricks
fill 89 252 229 89 265 229 minecraft:stone_bricks
fill 89 252 230 89 252 231 minecraft:lantern
fill 89 252 232 89 265 232 minecraft:stone_bricks
fill 89 252 241 89 265 241 minecraft:stone_bricks
fill 89 252 242 89 252 243 minecraft:lantern
fill 89 252 244 89 265 244 minecraft:stone_bricks
fill 89 252 253 89 265 253 minecraft:stone_bricks
fill 89 252 254 89 252 255 minecraft:lantern
fill 89 252 256 89 265 256 minecraft:stone_bricks
fill 89 252 265 89 265 265 minecraft:stone_bricks
fill 89 252 266 89 252 267 minecraft:lantern
fill 89 252 268 89 265 268 minecraft:stone_bricks
fill 47 253 235 47 265 236 minecraft:stone_bricks
fill 47 253 247 47 265 248 minecraft:stone_bricks
fill 47 253 259 47 265 260 minecraft:stone_bricks
fill 48 253 270 49 265 270 minecraft:stone_bricks
setblock 50 253 231 minecraft:light[level=12]
setblock 50 253 239 minecraft:light[level=12]
setblock 50 253 247 minecraft:light[level=12]
setblock 50 253 255 minecraft:light[level=12]
setblock 50 253 263 minecraft:light[level=12]
fill 55 253 228 56 265 228 minecraft:stone_bricks
setblock 58 253 231 minecraft:light[level=12]
setblock 58 253 239 minecraft:light[level=12]
setblock 58 253 247 minecraft:light[level=12]
setblock 58 253 255 minecraft:light[level=12]
setblock 58 253 263 minecraft:light[level=12]
fill 60 253 270 61 265 270 minecraft:stone_bricks
setblock 66 253 231 minecraft:light[level=12]
setblock 66 253 239 minecraft:light[level=12]
setblock 66 253 247 minecraft:light[level=12]
setblock 66 253 255 minecraft:light[level=12]
setblock 66 253 263 minecraft:light[level=12]
fill 67 253 228 68 265 228 minecraft:stone_bricks
fill 72 253 270 73 265 270 minecraft:stone_bricks
setblock 74 253 231 minecraft:light[level=12]
setblock 74 253 239 minecraft:light[level=12]
setblock 74 253 247 minecraft:light[level=12]
setblock 74 253 255 minecraft:light[level=12]
setblock 74 253 263 minecraft:light[level=12]
fill 79 253 228 80 265 228 minecraft:stone_bricks
setblock 82 253 231 minecraft:light[level=12]
setblock 82 253 239 minecraft:light[level=12]
setblock 82 253 247 minecraft:light[level=12]
setblock 82 253 255 minecraft:light[level=12]
setblock 82 253 263 minecraft:light[level=12]
fill 84 253 270 85 265 270 minecraft:stone_bricks
fill 89 253 230 89 265 231 minecraft:stone_bricks
fill 89 253 242 89 265 243 minecraft:stone_bricks
fill 89 253 254 89 265 255 minecraft:stone_bricks
fill 89 253 266 89 265 267 minecraft:stone_bricks
fill 49 260 238 49 265 240 minecraft:polished_andesite
fill 49 260 250 49 265 252 minecraft:polished_andesite
fill 49 260 262 49 265 264 minecraft:polished_andesite
fill 55 260 268 57 265 268 minecraft:polished_andesite
fill 59 260 230 61 265 230 minecraft:polished_andesite
fill 67 260 268 69 265 268 minecraft:polished_andesite
fill 71 260 230 73 265 230 minecraft:polished_andesite
fill 79 260 268 81 265 268 minecraft:polished_andesite
fill 83 260 230 85 265 230 minecraft:polished_andesite
fill 87 260 238 87 265 240 minecraft:polished_andesite
fill 87 260 250 87 265 252 minecraft:polished_andesite
fill 87 260 262 87 265 264 minecraft:polished_andesite
setblock 50 261 231 minecraft:light[level=12]
setblock 50 261 239 minecraft:light[level=12]
setblock 50 261 247 minecraft:light[level=12]
setblock 50 261 255 minecraft:light[level=12]
setblock 50 261 263 minecraft:light[level=12]
setblock 58 261 231 minecraft:light[level=12]
setblock 58 261 239 minecraft:light[level=12]
setblock 58 261 247 minecraft:light[level=12]
setblock 58 261 255 minecraft:light[level=12]
setblock 58 261 263 minecraft:light[level=12]
setblock 66 261 231 minecraft:light[level=12]
setblock 66 261 239 minecraft:light[level=12]
setblock 66 261 247 minecraft:light[level=12]
setblock 66 261 255 minecraft:light[level=12]
setblock 66 261 263 minecraft:light[level=12]
setblock 74 261 231 minecraft:light[level=12]
setblock 74 261 239 minecraft:light[level=12]
setblock 74 261 247 minecraft:light[level=12]
setblock 74 261 255 minecraft:light[level=12]
setblock 74 261 263 minecraft:light[level=12]
setblock 82 261 231 minecraft:light[level=12]
setblock 82 261 239 minecraft:light[level=12]
setblock 82 261 247 minecraft:light[level=12]
setblock 82 261 255 minecraft:light[level=12]
setblock 82 261 263 minecraft:light[level=12]
fill 48 265 232 48 265 237 minecraft:deepslate_bricks
fill 48 265 244 48 265 249 minecraft:deepslate_bricks
fill 48 265 256 48 265 261 minecraft:deepslate_bricks
fill 48 265 268 48 265 269 minecraft:deepslate_bricks
fill 49 265 269 52 265 269 minecraft:deepslate_bricks
fill 52 265 229 57 265 229 minecraft:deepslate_bricks
fill 59 265 269 64 265 269 minecraft:deepslate_bricks
fill 64 265 229 69 265 229 minecraft:deepslate_bricks
fill 71 265 269 76 265 269 minecraft:deepslate_bricks
fill 76 265 229 81 265 229 minecraft:deepslate_bricks
fill 83 265 269 88 265 269 minecraft:deepslate_bricks
fill 88 265 229 88 265 234 minecraft:deepslate_bricks
fill 88 265 241 88 265 246 minecraft:deepslate_bricks
fill 88 265 253 88 265 258 minecraft:deepslate_bricks
fill 88 265 265 88 265 268 minecraft:deepslate_bricks
fill 47 266 234 47 271 237 minecraft:lantern
fill 47 266 246 47 271 249 minecraft:lantern
fill 47 266 258 47 271 261 minecraft:lantern
fill 47 266 270 50 271 270 minecraft:lantern
fill 54 266 228 57 271 228 minecraft:lantern
fill 59 266 270 62 271 270 minecraft:lantern
fill 66 266 228 69 271 228 minecraft:lantern
fill 71 266 270 74 271 270 minecraft:lantern
fill 78 266 228 81 271 228 minecraft:lantern
fill 83 266 270 86 271 270 minecraft:lantern
fill 89 266 229 89 271 232 minecraft:lantern
fill 89 266 241 89 271 244 minecraft:lantern
fill 89 266 253 89 271 256 minecraft:lantern
fill 89 266 265 89 271 268 minecraft:lantern
setblock 50 269 231 minecraft:light[level=12]
setblock 50 269 239 minecraft:light[level=12]
setblock 50 269 247 minecraft:light[level=12]
setblock 50 269 255 minecraft:light[level=12]
setblock 50 269 263 minecraft:light[level=12]
setblock 58 269 231 minecraft:light[level=12]
setblock 58 269 239 minecraft:light[level=12]
setblock 58 269 247 minecraft:light[level=12]
setblock 58 269 255 minecraft:light[level=12]
setblock 58 269 263 minecraft:light[level=12]
setblock 66 269 231 minecraft:light[level=12]
setblock 66 269 239 minecraft:light[level=12]
setblock 66 269 247 minecraft:light[level=12]
setblock 66 269 255 minecraft:light[level=12]
setblock 66 269 263 minecraft:light[level=12]
setblock 74 269 231 minecraft:light[level=12]
setblock 74 269 239 minecraft:light[level=12]
setblock 74 269 247 minecraft:light[level=12]
setblock 74 269 255 minecraft:light[level=12]
setblock 74 269 263 minecraft:light[level=12]
setblock 82 269 231 minecraft:light[level=12]
setblock 82 269 239 minecraft:light[level=12]
setblock 82 269 247 minecraft:light[level=12]
setblock 82 269 255 minecraft:light[level=12]
setblock 82 269 263 minecraft:light[level=12]
fill 47 272 234 47 285 234 minecraft:stone_bricks
fill 47 272 235 47 272 236 minecraft:lantern
fill 47 272 237 47 285 237 minecraft:stone_bricks
fill 47 272 246 47 285 246 minecraft:stone_bricks
fill 47 272 247 47 272 248 minecraft:lantern
fill 47 272 249 47 285 249 minecraft:stone_bricks
fill 47 272 258 47 285 258 minecraft:stone_bricks
fill 47 272 259 47 272 260 minecraft:lantern
fill 47 272 261 47 285 261 minecraft:stone_bricks
fill 47 272 270 47 285 270 minecraft:stone_bricks
fill 48 272 270 49 272 270 minecraft:lantern
fill 50 272 270 50 285 270 minecraft:stone_bricks
fill 54 272 228 54 285 228 minecraft:stone_bricks
fill 55 272 228 56 272 228 minecraft:lantern
fill 57 272 228 57 285 228 minecraft:stone_bricks
fill 59 272 270 59 285 270 minecraft:stone_bricks
fill 60 272 270 61 272 270 minecraft:lantern
fill 62 272 270 62 285 270 minecraft:stone_bricks
fill 66 272 228 66 285 228 minecraft:stone_bricks
fill 67 272 228 68 272 228 minecraft:lantern
fill 69 272 228 69 285 228 minecraft:stone_bricks
fill 71 272 270 71 285 270 minecraft:stone_bricks
fill 72 272 270 73 272 270 minecraft:lantern
fill 74 272 270 74 285 270 minecraft:stone_bricks
fill 78 272 228 78 285 228 minecraft:stone_bricks
fill 79 272 228 80 272 228 minecraft:lantern
fill 81 272 228 81 285 228 minecraft:stone_bricks
fill 83 272 270 83 285 270 minecraft:stone_bricks
fill 84 272 270 85 272 270 minecraft:lantern
fill 86 272 270 86 285 270 minecraft:stone_bricks
fill 89 272 229 89 285 229 minecraft:stone_bricks
fill 89 272 230 89 272 231 minecraft:lantern
fill 89 272 232 89 285 232 minecraft:stone_bricks
fill 89 272 241 89 285 241 minecraft:stone_bricks
fill 89 272 242 89 272 243 minecraft:lantern
fill 89 272 244 89 285 244 minecraft:stone_bricks
fill 89 272 253 89 285 253 minecraft:stone_bricks
fill 89 272 254 89 272 255 minecraft:lantern
fill 89 272 256 89 285 256 minecraft:stone_bricks
fill 89 272 265 89 285 265 minecraft:stone_bricks
fill 89 272 266 89 272 267 minecraft:lantern
fill 89 272 268 89 285 268 minecraft:stone_bricks
fill 47 273 235 47 285 236 minecraft:stone_bricks
fill 47 273 247 47 285 248 minecraft:stone_bricks
fill 47 273 259 47 285 260 minecraft:stone_bricks
fill 48 273 270 49 285 270 minecraft:stone_bricks
fill 55 273 228 56 285 228 minecraft:stone_bricks
fill 60 273 270 61 285 270 minecraft:stone_bricks
fill 67 273 228 68 285 228 minecraft:stone_bricks
fill 72 273 270 73 285 270 minecraft:stone_bricks
fill 79 273 228 80 285 228 minecraft:stone_bricks
fill 84 273 270 85 285 270 minecraft:stone_bricks
fill 89 273 230 89 285 231 minecraft:stone_bricks
fill 89 273 242 89 285 243 minecraft:stone_bricks
fill 89 273 254 89 285 255 minecraft:stone_bricks
fill 89 273 266 89 285 267 minecraft:stone_bricks
setblock 50 277 231 minecraft:light[level=12]
setblock 50 277 239 minecraft:light[level=12]
setblock 50 277 247 minecraft:light[level=12]
setblock 50 277 255 minecraft:light[level=12]
setblock 50 277 263 minecraft:light[level=12]
setblock 58 277 231 minecraft:light[level=12]
setblock 58 277 239 minecraft:light[level=12]
setblock 58 277 247 minecraft:light[level=12]
setblock 58 277 255 minecraft:light[level=12]
setblock 58 277 263 minecraft:light[level=12]
setblock 66 277 231 minecraft:light[level=12]
setblock 66 277 239 minecraft:light[level=12]
setblock 66 277 247 minecraft:light[level=12]
setblock 66 277 255 minecraft:light[level=12]
setblock 66 277 263 minecraft:light[level=12]
setblock 74 277 231 minecraft:light[level=12]
setblock 74 277 239 minecraft:light[level=12]
setblock 74 277 247 minecraft:light[level=12]
setblock 74 277 255 minecraft:light[level=12]
setblock 74 277 263 minecraft:light[level=12]
setblock 82 277 231 minecraft:light[level=12]
setblock 82 277 239 minecraft:light[level=12]
setblock 82 277 247 minecraft:light[level=12]
setblock 82 277 255 minecraft:light[level=12]
setblock 82 277 263 minecraft:light[level=12]
fill 48 278 229 49 279 269 minecraft:deepslate_tiles
fill 50 278 229 50 279 269 minecraft:iron_block
fill 51 278 229 52 279 269 minecraft:deepslate_tiles
fill 53 278 229 53 279 269 minecraft:iron_block
fill 54 278 229 55 279 269 minecraft:deepslate_tiles
fill 56 278 229 56 279 269 minecraft:iron_block
fill 57 278 229 58 279 269 minecraft:deepslate_tiles
fill 59 278 229 59 279 269 minecraft:iron_block
fill 60 278 229 61 279 269 minecraft:deepslate_tiles
fill 62 278 229 62 279 269 minecraft:iron_block
fill 63 278 229 63 278 269 minecraft:deepslate_tiles
fill 64 278 229 64 278 250 minecraft:deepslate_tiles
fill 64 278 252 64 278 269 minecraft:deepslate_tiles
fill 65 278 229 65 278 248 minecraft:iron_block
fill 65 278 254 65 278 269 minecraft:iron_block
fill 66 278 229 66 278 248 minecraft:deepslate_tiles
fill 66 278 254 66 278 269 minecraft:deepslate_tiles
fill 67 278 229 67 278 247 minecraft:deepslate_tiles
fill 67 278 255 67 278 269 minecraft:deepslate_tiles
fill 68 278 229 68 278 248 minecraft:iron_block
fill 68 278 254 68 278 269 minecraft:iron_block
fill 69 278 229 70 278 248 minecraft:deepslate_tiles
fill 69 278 254 70 278 269 minecraft:deepslate_tiles
fill 70 278 249 70 278 250 minecraft:deepslate_tiles
fill 70 278 252 70 278 253 minecraft:deepslate_tiles
fill 71 278 229 71 278 269 minecraft:iron_block
fill 72 278 229 73 279 269 minecraft:deepslate_tiles
fill 74 278 229 74 279 269 minecraft:iron_block
fill 75 278 229 76 279 269 minecraft:deepslate_tiles
fill 77 278 229 77 279 269 minecraft:iron_block
fill 78 278 229 79 279 269 minecraft:deepslate_tiles
fill 80 278 229 80 279 269 minecraft:iron_block
fill 81 278 229 82 279 269 minecraft:deepslate_tiles
fill 83 278 229 83 279 269 minecraft:iron_block
fill 84 278 229 85 279 269 minecraft:deepslate_tiles
fill 86 278 229 86 279 269 minecraft:iron_block
fill 87 278 229 88 279 269 minecraft:deepslate_tiles
fill 63 279 229 63 279 249 minecraft:deepslate_tiles
fill 63 279 250 63 279 252 minecraft:lantern
fill 63 279 253 63 279 269 minecraft:deepslate_tiles
fill 64 279 229 64 279 247 minecraft:deepslate_tiles
fill 64 279 248 64 279 250 minecraft:lantern
fill 64 279 252 64 279 254 minecraft:lantern
fill 64 279 255 64 279 269 minecraft:deepslate_tiles
fill 65 279 229 65 279 247 minecraft:iron_block
fill 65 279 248 66 279 248 minecraft:lantern
fill 65 279 254 66 279 254 minecraft:lantern
fill 65 279 255 65 279 269 minecraft:iron_block
fill 66 279 229 67 279 246 minecraft:deepslate_tiles
fill 66 279 247 68 279 247 minecraft:lantern
fill 66 279 255 68 279 255 minecraft:lantern
fill 66 279 256 67 279 269 minecraft:deepslate_tiles
fill 68 279 229 68 279 246 minecraft:iron_block
fill 68 279 248 70 279 248 minecraft:lantern
fill 68 279 254 70 279 254 minecraft:lantern
fill 68 279 256 68 279 269 minecraft:iron_block
fill 69 279 229 70 279 247 minecraft:deepslate_tiles
fill 69 279 255 70 279 269 minecraft:deepslate_tiles
fill 70 279 249 70 279 250 minecraft:lantern
fill 70 279 252 70 279 253 minecraft:lantern
fill 71 279 229 71 279 249 minecraft:iron_block
fill 71 279 250 71 279 252 minecraft:lantern
fill 71 279 253 71 279 269 minecraft:iron_block
fill 48 283 229 50 300 229 minecraft:polished_andesite
fill 48 283 239 48 300 241 minecraft:polished_andesite
fill 48 283 251 48 300 253 minecraft:polished_andesite
fill 48 283 263 48 300 265 minecraft:polished_andesite
fill 49 283 238 49 285 240 minecraft:polished_andesite
fill 49 283 250 49 285 252 minecraft:polished_andesite
fill 49 283 262 49 285 264 minecraft:polished_andesite
setblock 50 283 240 minecraft:iron_block
fill 54 283 269 56 300 269 minecraft:polished_andesite
fill 55 283 268 57 285 268 minecraft:polished_andesite
fill 59 283 230 61 285 230 minecraft:polished_andesite
fill 60 283 229 62 300 229 minecraft:polished_andesite
fill 66 283 269 68 300 269 minecraft:polished_andesite
fill 67 283 268 69 285 268 minecraft:polished_andesite
fill 71 283 230 73 285 230 minecraft:polished_andesite
fill 72 283 229 74 300 229 minecraft:polished_andesite
fill 78 283 269 80 300 269 minecraft:polished_andesite
fill 79 283 268 81 285 268 minecraft:polished_andesite
fill 83 283 230 85 285 230 minecraft:polished_andesite
fill 84 283 229 86 300 229 minecraft:polished_andesite
fill 87 283 238 87 285 240 minecraft:polished_andesite
fill 87 283 250 87 285 252 minecraft:polished_andesite
fill 87 283 262 87 285 264 minecraft:polished_andesite
fill 88 283 237 88 300 239 minecraft:polished_andesite
fill 88 283 249 88 300 251 minecraft:polished_andesite
fill 88 283 261 88 300 263 minecraft:polished_andesite
fill 48 285 232 48 285 237 minecraft:deepslate_bricks
fill 48 285 244 48 285 249 minecraft:deepslate_bricks
fill 48 285 256 48 285 261 minecraft:deepslate_bricks
fill 48 285 268 48 285 269 minecraft:deepslate_bricks
fill 49 285 269 52 285 269 minecraft:deepslate_bricks
setblock 50 285 231 minecraft:light[level=12]
setblock 50 285 239 minecraft:light[level=12]
setblock 50 285 247 minecraft:light[level=12]
setblock 50 285 255 minecraft:light[level=12]
setblock 50 285 263 minecraft:light[level=12]
fill 52 285 229 57 285 229 minecraft:deepslate_bricks
setblock 58 285 231 minecraft:light[level=12]
setblock 58 285 239 minecraft:light[level=12]
setblock 58 285 247 minecraft:light[level=12]
setblock 58 285 255 minecraft:light[level=12]
setblock 58 285 263 minecraft:light[level=12]
fill 59 285 269 64 285 269 minecraft:deepslate_bricks
fill 64 285 229 69 285 229 minecraft:deepslate_bricks
setblock 66 285 231 minecraft:light[level=12]
setblock 66 285 239 minecraft:light[level=12]
setblock 66 285 247 minecraft:light[level=12]
setblock 66 285 255 minecraft:light[level=12]
setblock 66 285 263 minecraft:light[level=12]
fill 71 285 269 76 285 269 minecraft:deepslate_bricks
setblock 74 285 231 minecraft:light[level=12]
setblock 74 285 239 minecraft:light[level=12]
setblock 74 285 247 minecraft:light[level=12]
setblock 74 285 255 minecraft:light[level=12]
setblock 74 285 263 minecraft:light[level=12]
fill 76 285 229 81 285 229 minecraft:deepslate_bricks
setblock 82 285 231 minecraft:light[level=12]
setblock 82 285 239 minecraft:light[level=12]
setblock 82 285 247 minecraft:light[level=12]
setblock 82 285 255 minecraft:light[level=12]
setblock 82 285 263 minecraft:light[level=12]
fill 83 285 269 88 285 269 minecraft:deepslate_bricks
fill 88 285 229 88 285 234 minecraft:deepslate_bricks
fill 88 285 241 88 285 246 minecraft:deepslate_bricks
fill 88 285 253 88 285 258 minecraft:deepslate_bricks
fill 88 285 265 88 285 268 minecraft:deepslate_bricks
fill 47 286 234 47 291 237 minecraft:lantern
fill 47 286 246 47 291 249 minecraft:lantern
fill 47 286 258 47 291 261 minecraft:lantern
fill 47 286 270 50 291 270 minecraft:lantern
fill 54 286 228 57 291 228 minecraft:lantern
fill 59 286 270 62 291 270 minecraft:lantern
fill 66 286 228 69 291 228 minecraft:lantern
fill 71 286 270 74 291 270 minecraft:lantern
fill 78 286 228 81 291 228 minecraft:lantern
fill 83 286 270 86 291 270 minecraft:lantern
fill 89 286 229 89 291 232 minecraft:lantern
fill 89 286 241 89 291 244 minecraft:lantern
fill 89 286 253 89 291 256 minecraft:lantern
fill 89 286 265 89 291 268 minecraft:lantern
fill 47 292 234 47 307 234 minecraft:stone_bricks
fill 47 292 235 47 292 236 minecraft:lantern
fill 47 292 237 47 307 237 minecraft:stone_bricks
fill 47 292 246 47 307 246 minecraft:stone_bricks
fill 47 292 247 47 292 248 minecraft:lantern
fill 47 292 249 47 307 249 minecraft:stone_bricks
fill 47 292 258 47 307 258 minecraft:stone_bricks
fill 47 292 259 47 292 260 minecraft:lantern
fill 47 292 261 47 307 261 minecraft:stone_bricks
fill 47 292 270 47 307 270 minecraft:stone_bricks
fill 48 292 270 49 292 270 minecraft:lantern
fill 50 292 270 50 307 270 minecraft:stone_bricks
fill 54 292 228 54 307 228 minecraft:stone_bricks
fill 55 292 228 56 292 228 minecraft:lantern
fill 57 292 228 57 307 228 minecraft:stone_bricks
fill 59 292 270 59 307 270 minecraft:stone_bricks
fill 60 292 270 61 292 270 minecraft:lantern
fill 62 292 270 62 307 270 minecraft:stone_bricks
fill 66 292 228 66 307 228 minecraft:stone_bricks
fill 67 292 228 68 292 228 minecraft:lantern
fill 69 292 228 69 307 228 minecraft:stone_bricks
fill 71 292 270 71 307 270 minecraft:stone_bricks
fill 72 292 270 73 292 270 minecraft:lantern
fill 74 292 270 74 307 270 minecraft:stone_bricks
fill 78 292 228 78 307 228 minecraft:stone_bricks
fill 79 292 228 80 292 228 minecraft:lantern
fill 81 292 228 81 307 228 minecraft:stone_bricks
fill 83 292 270 83 307 270 minecraft:stone_bricks
fill 84 292 270 85 292 270 minecraft:lantern
fill 86 292 270 86 307 270 minecraft:stone_bricks
fill 89 292 229 89 307 229 minecraft:stone_bricks
fill 89 292 230 89 292 231 minecraft:lantern
fill 89 292 232 89 307 232 minecraft:stone_bricks
fill 89 292 241 89 307 241 minecraft:stone_bricks
fill 89 292 242 89 292 243 minecraft:lantern
fill 89 292 244 89 307 244 minecraft:stone_bricks
fill 89 292 253 89 307 253 minecraft:stone_bricks
fill 89 292 254 89 292 255 minecraft:lantern
fill 89 292 256 89 307 256 minecraft:stone_bricks
fill 89 292 265 89 307 265 minecraft:stone_bricks
fill 89 292 266 89 292 267 minecraft:lantern
fill 89 292 268 89 307 268 minecraft:stone_bricks
fill 47 293 235 47 307 236 minecraft:stone_bricks
fill 47 293 247 47 307 248 minecraft:stone_bricks
fill 47 293 259 47 307 260 minecraft:stone_bricks
fill 48 293 270 49 307 270 minecraft:stone_bricks
setblock 50 293 231 minecraft:light[level=12]
setblock 50 293 239 minecraft:light[level=12]
setblock 50 293 247 minecraft:light[level=12]
setblock 50 293 255 minecraft:light[level=12]
setblock 50 293 263 minecraft:light[level=12]
fill 55 293 228 56 307 228 minecraft:stone_bricks
setblock 58 293 231 minecraft:light[level=12]
setblock 58 293 239 minecraft:light[level=12]
setblock 58 293 247 minecraft:light[level=12]
setblock 58 293 255 minecraft:light[level=12]
setblock 58 293 263 minecraft:light[level=12]
fill 60 293 270 61 307 270 minecraft:stone_bricks
setblock 66 293 231 minecraft:light[level=12]
setblock 66 293 239 minecraft:light[level=12]
setblock 66 293 247 minecraft:light[level=12]
setblock 66 293 255 minecraft:light[level=12]
setblock 66 293 263 minecraft:light[level=12]
fill 67 293 228 68 307 228 minecraft:stone_bricks
fill 72 293 270 73 307 270 minecraft:stone_bricks
setblock 74 293 231 minecraft:light[level=12]
setblock 74 293 239 minecraft:light[level=12]
setblock 74 293 247 minecraft:light[level=12]
setblock 74 293 255 minecraft:light[level=12]
setblock 74 293 263 minecraft:light[level=12]
fill 79 293 228 80 307 228 minecraft:stone_bricks
setblock 82 293 231 minecraft:light[level=12]
setblock 82 293 239 minecraft:light[level=12]
setblock 82 293 247 minecraft:light[level=12]
setblock 82 293 255 minecraft:light[level=12]
setblock 82 293 263 minecraft:light[level=12]
fill 84 293 270 85 307 270 minecraft:stone_bricks
fill 89 293 230 89 307 231 minecraft:stone_bricks
fill 89 293 242 89 307 243 minecraft:stone_bricks
fill 89 293 254 89 307 255 minecraft:stone_bricks
fill 89 293 266 89 307 267 minecraft:stone_bricks
fill 49 300 238 49 300 240 minecraft:polished_andesite
fill 49 300 250 49 300 252 minecraft:polished_andesite
fill 49 300 262 49 300 264 minecraft:polished_andesite
fill 55 300 268 57 300 268 minecraft:polished_andesite
fill 59 300 230 61 300 230 minecraft:polished_andesite
fill 67 300 268 69 300 268 minecraft:polished_andesite
fill 71 300 230 73 300 230 minecraft:polished_andesite
fill 79 300 268 81 300 268 minecraft:polished_andesite
fill 83 300 230 85 300 230 minecraft:polished_andesite
fill 87 300 238 87 300 240 minecraft:polished_andesite
fill 87 300 250 87 300 252 minecraft:polished_andesite
fill 87 300 262 87 300 264 minecraft:polished_andesite
setblock 50 301 231 minecraft:light[level=12]
setblock 50 301 239 minecraft:light[level=12]
setblock 50 301 247 minecraft:light[level=12]
setblock 50 301 255 minecraft:light[level=12]
setblock 50 301 263 minecraft:light[level=12]
setblock 58 301 231 minecraft:light[level=12]
setblock 58 301 239 minecraft:light[level=12]
setblock 58 301 247 minecraft:light[level=12]
setblock 58 301 255 minecraft:light[level=12]
setblock 58 301 263 minecraft:light[level=12]
setblock 66 301 231 minecraft:light[level=12]
setblock 66 301 239 minecraft:light[level=12]
setblock 66 301 247 minecraft:light[level=12]
setblock 66 301 255 minecraft:light[level=12]
setblock 66 301 263 minecraft:light[level=12]
setblock 74 301 231 minecraft:light[level=12]
setblock 74 301 239 minecraft:light[level=12]
setblock 74 301 247 minecraft:light[level=12]
setblock 74 301 255 minecraft:light[level=12]
setblock 74 301 263 minecraft:light[level=12]
setblock 82 301 231 minecraft:light[level=12]
setblock 82 301 239 minecraft:light[level=12]
setblock 82 301 247 minecraft:light[level=12]
setblock 82 301 255 minecraft:light[level=12]
setblock 82 301 263 minecraft:light[level=12]
