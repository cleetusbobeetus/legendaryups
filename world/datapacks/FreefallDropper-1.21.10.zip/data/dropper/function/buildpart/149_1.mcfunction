setblock 254 139 607 minecraft:light[level=14]
setblock 254 139 615 minecraft:light[level=14]
setblock 254 139 623 minecraft:light[level=14]
setblock 254 139 631 minecraft:light[level=14]
setblock 254 139 639 minecraft:light[level=14]
setblock 262 139 607 minecraft:light[level=14]
fill 262 139 611 263 140 612 minecraft:gold_block
setblock 262 139 615 minecraft:light[level=14]
setblock 262 139 623 minecraft:light[level=14]
setblock 262 139 631 minecraft:light[level=14]
setblock 262 139 639 minecraft:light[level=14]
setblock 270 139 607 minecraft:light[level=14]
setblock 270 139 615 minecraft:light[level=14]
setblock 270 139 623 minecraft:light[level=14]
setblock 270 139 631 minecraft:light[level=14]
setblock 270 139 639 minecraft:light[level=14]
fill 236 140 605 236 141 610 minecraft:gray_concrete
fill 236 140 613 237 140 618 minecraft:gray_concrete
fill 236 140 621 237 140 626 minecraft:gray_concrete
fill 236 140 629 237 140 634 minecraft:gray_concrete
fill 236 140 637 237 140 642 minecraft:gray_concrete
fill 236 140 645 241 141 645 minecraft:gray_concrete
fill 237 140 606 237 140 612 minecraft:gray_concrete
fill 237 140 619 237 140 620 minecraft:gray_concrete
fill 237 140 627 237 140 628 minecraft:gray_concrete
fill 237 140 635 237 140 636 minecraft:gray_concrete
fill 237 140 643 237 140 644 minecraft:gray_concrete
fill 238 140 606 275 140 606 minecraft:gray_concrete
fill 238 140 644 276 140 644 minecraft:gray_concrete
fill 239 140 605 244 141 605 minecraft:gray_concrete
fill 244 140 645 249 141 645 minecraft:gray_concrete
fill 247 140 605 252 141 605 minecraft:gray_concrete
fill 252 140 645 257 141 645 minecraft:gray_concrete
fill 255 140 605 260 141 605 minecraft:gray_concrete
fill 260 140 645 265 141 645 minecraft:gray_concrete
fill 263 140 605 268 141 605 minecraft:gray_concrete
fill 268 140 645 273 141 645 minecraft:gray_concrete
fill 271 140 605 276 141 605 minecraft:gray_concrete
fill 275 140 607 275 140 643 minecraft:gray_concrete
fill 276 140 608 276 141 613 minecraft:gray_concrete
fill 276 140 616 276 141 621 minecraft:gray_concrete
fill 276 140 624 276 141 629 minecraft:gray_concrete
fill 276 140 632 276 141 637 minecraft:gray_concrete
fill 276 140 640 276 141 643 minecraft:gray_concrete
fill 276 140 645 276 141 645 minecraft:gray_concrete
fill 236 141 613 236 141 618 minecraft:gray_concrete
fill 236 141 621 236 141 626 minecraft:gray_concrete
fill 236 141 629 236 141 634 minecraft:gray_concrete
fill 236 141 637 236 141 642 minecraft:gray_concrete
setblock 276 141 644 minecraft:gray_concrete
fill 235 144 609 235 149 609 minecraft:sea_lantern
fill 235 144 617 235 149 617 minecraft:sea_lantern
fill 235 144 625 235 149 625 minecraft:sea_lantern
fill 235 144 633 235 149 633 minecraft:sea_lantern
fill 235 144 641 235 149 641 minecraft:sea_lantern
fill 238 144 646 238 149 646 minecraft:sea_lantern
fill 242 144 604 242 149 604 minecraft:sea_lantern
fill 246 144 646 246 149 646 minecraft:sea_lantern
fill 250 144 604 250 149 604 minecraft:sea_lantern
fill 254 144 646 254 149 646 minecraft:sea_lantern
fill 258 144 604 258 149 604 minecraft:sea_lantern
fill 262 144 646 262 149 646 minecraft:sea_lantern
fill 264 144 614 266 145 614 minecraft:white_concrete
fill 265 144 613 265 145 613 minecraft:white_concrete
fill 265 144 615 265 145 615 minecraft:white_concrete
fill 266 144 604 266 149 604 minecraft:sea_lantern
setblock 270 144 639 minecraft:black_concrete
fill 270 144 641 270 144 642 minecraft:black_concrete
fill 270 144 646 270 149 646 minecraft:sea_lantern
fill 271 144 638 272 144 638 minecraft:black_concrete
setblock 273 144 639 minecraft:black_concrete
setblock 273 144 642 minecraft:black_concrete
fill 274 144 604 274 149 604 minecraft:sea_lantern
fill 274 144 640 274 144 641 minecraft:black_concrete
fill 277 144 609 277 149 609 minecraft:sea_lantern
fill 277 144 617 277 149 617 minecraft:sea_lantern
fill 277 144 625 277 149 625 minecraft:sea_lantern
fill 277 144 633 277 149 633 minecraft:sea_lantern
fill 277 144 641 277 149 641 minecraft:sea_lantern
setblock 235 147 618 minecraft:light_gray_concrete
setblock 238 147 607 minecraft:light[level=14]
setblock 238 147 615 minecraft:light[level=14]
setblock 238 147 623 minecraft:light[level=14]
setblock 238 147 631 minecraft:light[level=14]
setblock 238 147 639 minecraft:light[level=14]
fill 243 147 604 244 150 604 minecraft:gray_concrete
fill 245 147 604 246 147 604 minecraft:light_gray_concrete
setblock 246 147 607 minecraft:light[level=14]
setblock 246 147 615 minecraft:light[level=14]
setblock 246 147 623 minecraft:light[level=14]
setblock 246 147 631 minecraft:light[level=14]
setblock 246 147 639 minecraft:light[level=14]
setblock 253 147 646 minecraft:light_gray_concrete
setblock 254 147 607 minecraft:light[level=14]
setblock 254 147 615 minecraft:light[level=14]
setblock 254 147 623 minecraft:light[level=14]
setblock 254 147 631 minecraft:light[level=14]
setblock 254 147 639 minecraft:light[level=14]
setblock 256 147 646 minecraft:light_gray_concrete
fill 257 147 646 259 150 646 minecraft:gray_concrete
fill 259 147 604 260 150 604 minecraft:gray_concrete
setblock 261 147 604 minecraft:light_gray_concrete
fill 262 147 604 265 150 604 minecraft:gray_concrete
setblock 262 147 607 minecraft:light[level=14]
setblock 262 147 615 minecraft:light[level=14]
setblock 262 147 623 minecraft:light[level=14]
setblock 262 147 631 minecraft:light[level=14]
setblock 262 147 639 minecraft:light[level=14]
fill 264 147 646 265 150 646 minecraft:gray_concrete
setblock 266 147 646 minecraft:light_gray_concrete
fill 267 147 604 268 148 604 minecraft:gray_concrete
fill 267 147 646 267 150 646 minecraft:gray_concrete
fill 268 147 619 269 148 619 minecraft:gold_block
setblock 269 147 604 minecraft:light_gray_concrete
fill 270 147 604 272 150 604 minecraft:gray_concrete
setblock 270 147 607 minecraft:light[level=14]
setblock 270 147 615 minecraft:light[level=14]
setblock 270 147 623 minecraft:light[level=14]
setblock 270 147 631 minecraft:light[level=14]
setblock 270 147 639 minecraft:light[level=14]
fill 276 147 604 276 151 604 minecraft:gray_concrete
setblock 277 147 604 minecraft:light_gray_concrete
setblock 277 147 610 minecraft:light_gray_concrete
fill 277 147 611 277 150 612 minecraft:gray_concrete
fill 277 147 618 277 147 619 minecraft:gray_concrete
setblock 277 147 620 minecraft:light_gray_concrete
fill 277 147 621 277 148 621 minecraft:gray_concrete
fill 277 147 622 277 147 623 minecraft:light_gray_concrete
fill 277 147 624 277 151 624 minecraft:gray_concrete
fill 277 147 626 277 147 628 minecraft:gray_concrete
setblock 277 147 629 minecraft:light_gray_concrete
fill 277 147 630 277 150 632 minecraft:gray_concrete
fill 235 148 618 235 150 618 minecraft:gray_concrete
setblock 235 148 626 minecraft:gray_concrete
setblock 235 148 627 minecraft:light_gray_concrete
fill 235 148 628 235 150 628 minecraft:gray_concrete
setblock 235 148 629 minecraft:light_gray_concrete
fill 235 148 630 235 148 632 minecraft:gray_concrete
fill 235 148 642 235 148 645 minecraft:gray_concrete
setblock 235 148 646 minecraft:light_gray_concrete
fill 237 148 604 237 150 604 minecraft:gray_concrete
setblock 238 148 604 minecraft:light_gray_concrete
fill 239 148 604 240 150 604 minecraft:gray_concrete
setblock 241 148 646 minecraft:light_gray_concrete
fill 242 148 646 242 150 646 minecraft:gray_concrete
setblock 243 148 646 minecraft:light_gray_concrete
setblock 245 148 604 minecraft:gray_concrete
setblock 245 148 646 minecraft:light_gray_concrete
setblock 246 148 604 minecraft:light_gray_concrete
fill 252 148 604 254 150 604 minecraft:gray_concrete
fill 253 148 646 253 151 646 minecraft:gray_concrete
setblock 255 148 604 minecraft:light_gray_concrete
fill 256 148 604 257 148 604 minecraft:gray_concrete
fill 256 148 646 256 150 646 minecraft:gray_concrete
fill 261 148 604 261 150 604 minecraft:gray_concrete
setblock 261 148 646 minecraft:light_gray_concrete
setblock 266 148 646 minecraft:gray_concrete
fill 269 148 604 269 152 604 minecraft:gray_concrete
fill 270 148 626 271 149 627 minecraft:gold_block
fill 277 148 604 277 150 604 minecraft:gray_concrete
fill 277 148 610 277 150 610 minecraft:gray_concrete
fill 277 148 618 277 150 618 minecraft:gray_concrete
setblock 277 148 619 minecraft:light_gray_concrete
fill 277 148 620 277 150 620 minecraft:gray_concrete
fill 277 148 622 277 150 623 minecraft:gray_concrete
fill 277 148 626 277 149 626 minecraft:light_gray_concrete
fill 277 148 627 277 150 629 minecraft:gray_concrete
fill 235 149 611 235 150 611 minecraft:gray_concrete
setblock 235 149 612 minecraft:light_gray_concrete
fill 235 149 613 235 150 613 minecraft:gray_concrete
setblock 235 149 615 minecraft:light_gray_concrete
setblock 235 149 626 minecraft:light_gray_concrete
fill 235 149 627 235 150 627 minecraft:gray_concrete
fill 235 149 629 235 150 630 minecraft:gray_concrete
setblock 235 149 631 minecraft:light_gray_concrete
fill 235 149 632 235 150 632 minecraft:gray_concrete
fill 235 149 642 235 149 643 minecraft:light_gray_concrete
fill 235 149 644 235 150 646 minecraft:gray_concrete
setblock 236 149 646 minecraft:light_gray_concrete
fill 238 149 604 238 150 604 minecraft:gray_concrete
fill 241 149 646 241 150 646 minecraft:gray_concrete
fill 243 149 646 243 151 646 minecraft:gray_concrete
setblock 244 149 646 minecraft:light_gray_concrete
setblock 245 149 604 minecraft:light_gray_concrete
fill 245 149 646 245 150 646 minecraft:gray_concrete
fill 246 149 604 246 150 604 minecraft:gray_concrete
fill 248 149 646 248 150 646 minecraft:gray_concrete
setblock 249 149 646 minecraft:light_gray_concrete
fill 251 149 646 251 151 646 minecraft:gray_concrete
setblock 252 149 646 minecraft:light_gray_concrete
fill 255 149 604 255 150 604 minecraft:gray_concrete
setblock 256 149 604 minecraft:light_gray_concrete
fill 257 149 604 257 150 604 minecraft:gray_concrete
fill 261 149 608 261 150 608 minecraft:black_concrete
fill 261 149 646 261 150 646 minecraft:gray_concrete
setblock 266 149 646 minecraft:light_gray_concrete
setblock 267 149 604 minecraft:light_gray_concrete
fill 268 149 604 268 150 604 minecraft:gray_concrete
fill 271 149 641 271 154 642 minecraft:gray_concrete
setblock 271 149 646 minecraft:light_gray_concrete
fill 272 149 607 272 150 607 minecraft:black_concrete
fill 272 149 641 272 150 641 minecraft:black_concrete
setblock 272 149 642 minecraft:gray_concrete
fill 272 149 646 276 150 646 minecraft:gray_concrete
fill 273 149 608 273 150 608 minecraft:black_concrete
fill 277 149 619 277 150 619 minecraft:gray_concrete
setblock 277 149 621 minecraft:light_gray_concrete
setblock 277 149 642 minecraft:light_gray_concrete
fill 277 149 643 277 150 643 minecraft:gray_concrete
setblock 277 149 644 minecraft:light_gray_concrete
fill 277 149 645 277 150 645 minecraft:gray_concrete
setblock 235 150 609 minecraft:gray_concrete
setblock 235 150 612 minecraft:gray_concrete
setblock 235 150 615 minecraft:gray_concrete
setblock 235 150 617 minecraft:gray_concrete
fill 235 150 625 235 150 626 minecraft:gray_concrete
setblock 235 150 631 minecraft:gray_concrete
setblock 235 150 633 minecraft:gray_concrete
fill 235 150 641 235 150 643 minecraft:gray_concrete
setblock 236 150 646 minecraft:gray_concrete
setblock 238 150 646 minecraft:gray_concrete
fill 242 150 604 242 151 604 minecraft:gray_concrete
setblock 244 150 646 minecraft:gray_concrete
setblock 245 150 604 minecraft:gray_concrete
setblock 246 150 646 minecraft:gray_concrete
setblock 249 150 646 minecraft:gray_concrete
setblock 250 150 604 minecraft:gray_concrete
fill 252 150 646 252 151 646 minecraft:gray_concrete
setblock 254 150 646 minecraft:gray_concrete
setblock 256 150 604 minecraft:gray_concrete
setblock 258 150 604 minecraft:gray_concrete
fill 261 150 607 261 151 607 minecraft:black_concrete
setblock 262 150 646 minecraft:gray_concrete
fill 266 150 604 267 150 604 minecraft:gray_concrete
setblock 266 150 646 minecraft:gray_concrete
fill 270 150 646 271 150 646 minecraft:gray_concrete
fill 272 150 642 272 151 642 minecraft:black_concrete
fill 273 150 607 273 151 607 minecraft:black_concrete
fill 274 150 604 274 152 604 minecraft:gray_concrete
setblock 277 150 609 minecraft:gray_concrete
setblock 277 150 617 minecraft:gray_concrete
setblock 277 150 621 minecraft:gray_concrete
fill 277 150 625 277 150 626 minecraft:gray_concrete
setblock 277 150 633 minecraft:gray_concrete
fill 277 150 641 277 150 642 minecraft:gray_concrete
setblock 277 150 644 minecraft:gray_concrete
fill 235 151 604 235 151 607 minecraft:light_gray_concrete
fill 235 151 609 235 151 637 minecraft:light_gray_concrete
setblock 235 151 638 minecraft:gray_concrete
fill 235 151 639 235 152 646 minecraft:light_gray_concrete
fill 236 151 604 241 151 604 minecraft:light_gray_concrete
fill 236 151 646 242 157 646 minecraft:light_gray_concrete
fill 243 151 604 268 151 604 minecraft:light_gray_concrete
fill 244 151 646 246 157 646 minecraft:light_gray_concrete
fill 248 151 646 249 226 646 minecraft:light_gray_concrete
fill 254 151 646 264 151 646 minecraft:light_gray_concrete
fill 261 151 606 261 152 606 minecraft:black_concrete
setblock 265 151 646 minecraft:gray_concrete
fill 266 151 646 275 151 646 minecraft:light_gray_concrete
fill 270 151 604 273 225 604 minecraft:light_gray_concrete
fill 272 151 641 272 158 641 minecraft:gray_concrete
fill 272 151 643 272 152 643 minecraft:black_concrete
fill 273 151 606 273 152 606 minecraft:black_concrete
fill 274 151 607 274 152 607 minecraft:black_concrete
fill 275 151 604 275 229 604 minecraft:light_gray_concrete
fill 276 151 646 276 152 646 minecraft:gray_concrete
fill 277 151 604 277 151 614 minecraft:light_gray_concrete
fill 277 151 615 277 151 616 minecraft:gray_concrete
fill 277 151 617 277 151 623 minecraft:light_gray_concrete
fill 277 151 625 277 157 627 minecraft:light_gray_concrete
setblock 277 151 628 minecraft:gray_concrete
fill 277 151 629 277 151 638 minecraft:light_gray_concrete
setblock 277 151 639 minecraft:gray_concrete
fill 277 151 640 277 151 646 minecraft:light_gray_concrete
fill 235 152 604 235 226 604 minecraft:light_gray_concrete
setblock 235 152 605 minecraft:gray_concrete
fill 235 152 606 235 157 612 minecraft:light_gray_concrete
setblock 235 152 613 minecraft:gray_concrete
fill 235 152 614 235 229 614 minecraft:light_gray_concrete
setblock 235 152 615 minecraft:gray_concrete
fill 235 152 616 235 152 638 minecraft:light_gray_concrete
fill 236 152 604 238 152 604 minecraft:gray_concrete
fill 239 152 604 242 157 604 minecraft:light_gray_concrete
setblock 243 152 604 minecraft:gray_concrete
setblock 243 152 646 minecraft:light_gray_concrete
fill 244 152 604 247 229 604 minecraft:light_gray_concrete
fill 247 152 646 247 229 646 minecraft:light_gray_concrete
setblock 248 152 604 minecraft:gray_concrete
fill 249 152 604 268 152 604 minecraft:light_gray_concrete
fill 251 152 646 262 152 646 minecraft:light_gray_concrete
setblock 263 152 646 minecraft:gray_concrete
fill 264 152 646 266 229 646 minecraft:light_gray_concrete
setblock 267 152 646 minecraft:gray_concrete
fill 268 152 646 269 226 646 minecraft:light_gray_concrete
setblock 270 152 639 minecraft:black_concrete
fill 270 152 641 270 152 642 minecraft:black_concrete
fill 270 152 646 270 153 646 minecraft:gray_concrete
fill 271 152 638 272 152 638 minecraft:black_concrete
fill 271 152 646 272 229 646 minecraft:light_gray_concrete
fill 272 152 642 272 154 642 minecraft:gray_concrete
fill 272 152 644 272 153 644 minecraft:black_concrete
fill 273 152 605 273 153 605 minecraft:black_concrete
setblock 273 152 639 minecraft:black_concrete
setblock 273 152 642 minecraft:black_concrete
setblock 273 152 646 minecraft:gray_concrete
fill 274 152 640 274 152 641 minecraft:black_concrete
fill 274 152 646 274 227 646 minecraft:light_gray_concrete
fill 275 152 607 275 153 607 minecraft:black_concrete
setblock 275 152 646 minecraft:gray_concrete
fill 276 152 604 276 229 604 minecraft:light_gray_concrete
setblock 277 152 604 minecraft:gray_concrete
setblock 277 152 605 minecraft:light_gray_concrete
setblock 277 152 606 minecraft:gray_concrete
fill 277 152 607 277 229 607 minecraft:light_gray_concrete
setblock 277 152 608 minecraft:gray_concrete
fill 277 152 609 277 157 609 minecraft:light_gray_concrete
fill 277 152 610 277 152 611 minecraft:gray_concrete
fill 277 152 612 277 229 612 minecraft:light_gray_concrete
setblock 277 152 613 minecraft:gray_concrete
fill 277 152 614 277 157 618 minecraft:light_gray_concrete
setblock 277 152 619 minecraft:gray_concrete
fill 277 152 620 277 152 624 minecraft:light_gray_concrete
fill 277 152 628 277 225 628 minecraft:light_gray_concrete
fill 277 152 629 277 153 629 minecraft:gray_concrete
fill 277 152 630 277 152 635 minecraft:light_gray_concrete
setblock 277 152 636 minecraft:gray_concrete
fill 277 152 637 277 157 642 minecraft:light_gray_concrete
setblock 277 152 643 minecraft:gray_concrete
fill 277 152 644 277 152 646 minecraft:light_gray_concrete
fill 235 153 605 235 225 605 minecraft:light_gray_concrete
fill 235 153 613 235 229 613 minecraft:light_gray_concrete
fill 235 153 615 235 157 620 minecraft:light_gray_concrete
setblock 235 153 621 minecraft:gray_concrete
fill 235 153 622 235 157 638 minecraft:light_gray_concrete
setblock 235 153 639 minecraft:gray_concrete
fill 235 153 640 235 157 646 minecraft:light_gray_concrete
fill 236 153 604 238 226 604 minecraft:light_gray_concrete
setblock 239 153 612 minecraft:sea_lantern
setblock 239 153 618 minecraft:sea_lantern
setblock 239 153 624 minecraft:sea_lantern
setblock 239 153 630 minecraft:sea_lantern
setblock 239 153 636 minecraft:sea_lantern
setblock 239 153 642 minecraft:sea_lantern
fill 243 153 604 243 230 604 minecraft:light_gray_concrete
setblock 243 153 608 minecraft:sea_lantern
setblock 243 153 646 minecraft:gray_concrete
setblock 245 153 642 minecraft:sea_lantern
fill 248 153 604 258 157 604 minecraft:light_gray_concrete
setblock 249 153 608 minecraft:sea_lantern
fill 250 153 646 255 157 646 minecraft:light_gray_concrete
setblock 251 153 642 minecraft:sea_lantern
setblock 255 153 608 minecraft:sea_lantern
setblock 256 153 646 minecraft:gray_concrete
setblock 257 153 642 minecraft:sea_lantern
fill 257 153 646 258 229 646 minecraft:light_gray_concrete
setblock 259 153 604 minecraft:gray_concrete
setblock 259 153 646 minecraft:gray_concrete
fill 260 153 604 265 226 604 minecraft:light_gray_concrete
fill 260 153 646 263 157 646 minecraft:light_gray_concrete
setblock 261 153 608 minecraft:sea_lantern
setblock 263 153 642 minecraft:sea_lantern
setblock 266 153 604 minecraft:gray_concrete
fill 267 153 604 269 225 604 minecraft:light_gray_concrete
setblock 267 153 608 minecraft:sea_lantern
fill 267 153 646 267 229 646 minecraft:light_gray_concrete
setblock 269 153 642 minecraft:sea_lantern
setblock 273 153 608 minecraft:sea_lantern
setblock 273 153 614 minecraft:sea_lantern
setblock 273 153 620 minecraft:sea_lantern
setblock 273 153 626 minecraft:sea_lantern
setblock 273 153 632 minecraft:sea_lantern
setblock 273 153 638 minecraft:sea_lantern
fill 273 153 646 273 229 646 minecraft:light_gray_concrete
fill 274 153 604 274 157 604 minecraft:light_gray_concrete
fill 275 153 646 277 229 646 minecraft:light_gray_concrete
fill 277 153 604 277 229 604 minecraft:light_gray_concrete
setblock 277 153 605 minecraft:gray_concrete
fill 277 153 606 277 229 606 minecraft:light_gray_concrete
fill 277 153 608 277 225 608 minecraft:light_gray_concrete
fill 277 153 610 277 225 611 minecraft:light_gray_concrete
fill 277 153 613 277 227 613 minecraft:light_gray_concrete
fill 277 153 619 277 226 623 minecraft:light_gray_concrete
setblock 277 153 624 minecraft:gray_concrete
fill 277 153 630 277 229 631 minecraft:light_gray_concrete
setblock 277 153 632 minecraft:gray_concrete
fill 277 153 633 277 157 634 minecraft:light_gray_concrete
setblock 277 153 635 minecraft:gray_concrete
fill 277 153 636 277 230 636 minecraft:light_gray_concrete
fill 277 153 643 277 230 643 minecraft:light_gray_concrete
setblock 277 153 644 minecraft:gray_concrete
fill 277 153 645 277 229 645 minecraft:light_gray_concrete
fill 235 154 621 235 229 621 minecraft:light_gray_concrete
fill 235 154 639 235 229 639 minecraft:light_gray_concrete
fill 236 154 605 236 155 610 minecraft:gray_concrete
fill 236 154 613 239 154 618 minecraft:gray_concrete
fill 236 154 621 239 154 626 minecraft:gray_concrete
fill 236 154 629 239 154 634 minecraft:gray_concrete
fill 236 154 637 239 154 642 minecraft:gray_concrete
fill 236 154 645 241 155 645 minecraft:gray_concrete
fill 237 154 606 239 154 612 minecraft:gray_concrete
fill 237 154 619 239 154 620 minecraft:gray_concrete
fill 237 154 627 239 154 628 minecraft:gray_concrete
fill 237 154 635 239 154 636 minecraft:gray_concrete
fill 237 154 643 276 154 644 minecraft:gray_concrete
fill 239 154 605 244 155 605 minecraft:gray_concrete
fill 240 154 606 275 154 608 minecraft:gray_concrete
fill 240 154 642 270 154 642 minecraft:gray_concrete
fill 243 154 646 243 229 646 minecraft:light_gray_concrete
fill 244 154 645 249 155 645 minecraft:gray_concrete
fill 247 154 605 252 155 605 minecraft:gray_concrete
fill 252 154 645 257 155 645 minecraft:gray_concrete
fill 255 154 605 260 155 605 minecraft:gray_concrete
fill 256 154 646 256 229 646 minecraft:light_gray_concrete
fill 259 154 604 259 229 604 minecraft:light_gray_concrete
fill 259 154 646 259 229 646 minecraft:light_gray_concrete
fill 260 154 645 265 155 645 minecraft:gray_concrete
fill 263 154 605 268 155 605 minecraft:gray_concrete
fill 266 154 604 266 157 604 minecraft:light_gray_concrete
fill 268 154 645 273 155 645 minecraft:gray_concrete
fill 270 154 646 270 157 646 minecraft:light_gray_concrete
fill 271 154 605 276 155 605 minecraft:gray_concrete
fill 273 154 609 275 154 639 minecraft:gray_concrete
fill 273 154 642 276 154 642 minecraft:gray_concrete
fill 274 154 640 276 154 641 minecraft:gray_concrete
fill 276 154 608 276 155 613 minecraft:gray_concrete
fill 276 154 616 276 155 621 minecraft:gray_concrete
fill 276 154 624 276 155 629 minecraft:gray_concrete
fill 276 154 632 276 155 637 minecraft:gray_concrete
fill 276 154 645 276 155 645 minecraft:gray_concrete
fill 277 154 605 277 225 605 minecraft:light_gray_concrete
fill 277 154 624 277 229 624 minecraft:light_gray_concrete
fill 277 154 629 277 225 629 minecraft:light_gray_concrete
fill 277 154 632 277 225 632 minecraft:light_gray_concrete
fill 277 154 635 277 225 635 minecraft:light_gray_concrete
fill 277 154 644 277 226 644 minecraft:light_gray_concrete
fill 236 155 613 236 155 618 minecraft:gray_concrete
fill 236 155 621 236 155 626 minecraft:gray_concrete
fill 236 155 629 236 155 634 minecraft:gray_concrete
fill 236 155 637 236 155 642 minecraft:gray_concrete
setblock 238 155 607 minecraft:light[level=14]
setblock 238 155 615 minecraft:light[level=14]
setblock 238 155 623 minecraft:light[level=14]
setblock 238 155 631 minecraft:light[level=14]
setblock 238 155 639 minecraft:light[level=14]
fill 239 155 608 239 155 642 minecraft:gold_block
fill 240 155 608 273 155 608 minecraft:gold_block
fill 240 155 642 273 155 642 minecraft:gold_block
setblock 246 155 607 minecraft:light[level=14]
setblock 246 155 615 minecraft:light[level=14]
setblock 246 155 623 minecraft:light[level=14]
setblock 246 155 631 minecraft:light[level=14]
setblock 246 155 639 minecraft:light[level=14]
setblock 254 155 607 minecraft:light[level=14]
setblock 254 155 615 minecraft:light[level=14]
setblock 254 155 623 minecraft:light[level=14]
setblock 254 155 631 minecraft:light[level=14]
setblock 254 155 639 minecraft:light[level=14]
fill 258 155 641 259 156 641 minecraft:gold_block
setblock 262 155 607 minecraft:light[level=14]
setblock 262 155 615 minecraft:light[level=14]
setblock 262 155 623 minecraft:light[level=14]
setblock 262 155 631 minecraft:light[level=14]
setblock 262 155 639 minecraft:light[level=14]
setblock 270 155 607 minecraft:light[level=14]
setblock 270 155 615 minecraft:light[level=14]
setblock 270 155 623 minecraft:light[level=14]
setblock 270 155 631 minecraft:light[level=14]
setblock 270 155 639 minecraft:light[level=14]
fill 270 155 640 272 158 640 minecraft:gray_concrete
fill 271 155 641 271 158 641 minecraft:gray_concrete
fill 273 155 609 273 155 641 minecraft:gold_block
fill 276 155 640 276 155 644 minecraft:gray_concrete
fill 258 156 642 259 156 642 minecraft:gold_block
fill 271 156 642 272 158 642 minecraft:gray_concrete
fill 273 156 640 273 158 641 minecraft:gray_concrete
fill 270 157 639 270 158 639 minecraft:gold_block
fill 270 157 641 270 158 642 minecraft:gold_block
fill 273 157 639 273 158 639 minecraft:gold_block
fill 273 157 642 273 158 642 minecraft:gold_block
fill 274 157 640 274 158 641 minecraft:gold_block
fill 235 158 606 235 226 608 minecraft:light_gray_concrete
setblock 235 158 609 minecraft:sea_lantern
fill 235 158 610 235 227 612 minecraft:light_gray_concrete
fill 235 158 615 235 225 616 minecraft:light_gray_concrete
setblock 235 158 617 minecraft:sea_lantern
fill 235 158 618 235 229 620 minecraft:light_gray_concrete
fill 235 158 622 235 229 624 minecraft:light_gray_concrete
setblock 235 158 625 minecraft:sea_lantern
fill 235 158 626 235 226 632 minecraft:light_gray_concrete
setblock 235 158 633 minecraft:sea_lantern
fill 235 158 634 235 225 638 minecraft:light_gray_concrete
fill 235 158 640 235 229 640 minecraft:light_gray_concrete
setblock 235 158 641 minecraft:sea_lantern
fill 235 158 642 235 225 646 minecraft:light_gray_concrete
fill 236 158 646 237 229 646 minecraft:light_gray_concrete
setblock 238 158 646 minecraft:sea_lantern
fill 239 158 604 241 225 604 minecraft:light_gray_concrete
fill 239 158 646 242 225 646 minecraft:light_gray_concrete
setblock 242 158 604 minecraft:sea_lantern
fill 244 158 646 245 229 646 minecraft:light_gray_concrete
setblock 246 158 646 minecraft:sea_lantern
fill 248 158 604 249 229 604 minecraft:light_gray_concrete
setblock 250 158 604 minecraft:sea_lantern
fill 250 158 646 253 229 646 minecraft:light_gray_concrete
fill 251 158 604 257 225 604 minecraft:light_gray_concrete
setblock 254 158 646 minecraft:sea_lantern
fill 255 158 646 255 229 646 minecraft:light_gray_concrete
setblock 258 158 604 minecraft:sea_lantern
fill 260 158 646 261 229 646 minecraft:light_gray_concrete
setblock 262 158 646 minecraft:sea_lantern
fill 263 158 646 263 229 646 minecraft:light_gray_concrete
setblock 266 158 604 minecraft:sea_lantern
setblock 270 158 646 minecraft:sea_lantern
setblock 274 158 604 minecraft:sea_lantern
setblock 277 158 609 minecraft:sea_lantern
fill 277 158 614 277 227 616 minecraft:light_gray_concrete
setblock 277 158 617 minecraft:sea_lantern
fill 277 158 618 277 225 618 minecraft:light_gray_concrete
setblock 277 158 625 minecraft:sea_lantern
fill 277 158 626 277 229 627 minecraft:light_gray_concrete
setblock 277 158 633 minecraft:sea_lantern
fill 277 158 634 277 225 634 minecraft:light_gray_concrete
fill 277 158 637 277 229 640 minecraft:light_gray_concrete
setblock 277 158 641 minecraft:sea_lantern
fill 277 158 642 277 229 642 minecraft:light_gray_concrete
fill 235 159 609 235 171 609 minecraft:light_gray_concrete
fill 235 159 617 235 171 617 minecraft:light_gray_concrete
fill 235 159 625 235 171 625 minecraft:light_gray_concrete
fill 235 159 633 235 171 633 minecraft:light_gray_concrete
fill 235 159 641 235 171 641 minecraft:light_gray_concrete
fill 238 159 646 238 171 646 minecraft:light_gray_concrete
fill 242 159 604 242 171 604 minecraft:light_gray_concrete
fill 246 159 646 246 171 646 minecraft:light_gray_concrete
fill 250 159 604 250 171 604 minecraft:light_gray_concrete
fill 254 159 646 254 171 646 minecraft:light_gray_concrete
fill 258 159 604 258 171 604 minecraft:light_gray_concrete
fill 262 159 646 262 171 646 minecraft:light_gray_concrete
fill 266 159 604 266 171 604 minecraft:light_gray_concrete
fill 270 159 646 270 171 646 minecraft:light_gray_concrete
fill 274 159 604 274 171 604 minecraft:light_gray_concrete
fill 277 159 609 277 171 609 minecraft:light_gray_concrete
fill 277 159 617 277 171 617 minecraft:light_gray_concrete
fill 277 159 625 277 171 625 minecraft:light_gray_concrete
fill 277 159 633 277 171 633 minecraft:light_gray_concrete
fill 277 159 641 277 171 641 minecraft:light_gray_concrete
setblock 238 163 607 minecraft:light[level=14]
setblock 238 163 615 minecraft:light[level=14]
setblock 238 163 623 minecraft:light[level=14]
setblock 238 163 631 minecraft:light[level=14]
setblock 238 163 639 minecraft:light[level=14]
setblock 246 163 607 minecraft:light[level=14]
setblock 246 163 615 minecraft:light[level=14]
setblock 246 163 623 minecraft:light[level=14]
setblock 246 163 631 minecraft:light[level=14]
setblock 246 163 639 minecraft:light[level=14]
fill 251 163 628 253 163 630 minecraft:redstone_block
fill 252 163 621 254 163 623 minecraft:redstone_block
setblock 254 163 607 minecraft:light[level=14]
setblock 254 163 615 minecraft:light[level=14]
setblock 254 163 631 minecraft:light[level=14]
setblock 254 163 639 minecraft:light[level=14]
fill 258 163 621 260 163 623 minecraft:redstone_block
setblock 262 163 607 minecraft:light[level=14]
setblock 262 163 615 minecraft:light[level=14]
setblock 262 163 623 minecraft:light[level=14]
setblock 262 163 631 minecraft:light[level=14]
setblock 262 163 639 minecraft:light[level=14]
setblock 270 163 607 minecraft:light[level=14]
setblock 270 163 615 minecraft:light[level=14]
setblock 270 163 623 minecraft:light[level=14]
setblock 270 163 631 minecraft:light[level=14]
setblock 270 163 639 minecraft:light[level=14]
fill 237 164 620 250 164 630 minecraft:gray_concrete
fill 238 164 618 274 164 619 minecraft:gray_concrete
fill 238 164 631 274 164 632 minecraft:gray_concrete
fill 239 164 616 273 164 617 minecraft:gray_concrete
fill 239 164 633 273 164 634 minecraft:gray_concrete
fill 240 164 614 272 164 615 minecraft:gray_concrete
fill 240 164 635 272 164 636 minecraft:gray_concrete
fill 241 164 613 271 165 613 minecraft:gray_concrete
fill 241 164 637 271 164 637 minecraft:gray_concrete
fill 242 164 612 270 165 612 minecraft:gray_concrete
fill 242 164 638 270 164 638 minecraft:gray_concrete
fill 243 164 611 269 165 611 minecraft:gray_concrete
fill 243 164 639 269 165 639 minecraft:gray_concrete
fill 244 164 610 268 165 610 minecraft:gray_concrete
fill 244 164 640 268 165 640 minecraft:gray_concrete
fill 245 164 609 267 165 609 minecraft:gray_concrete
fill 245 164 641 267 165 641 minecraft:gray_concrete
fill 247 164 608 265 165 608 minecraft:gray_concrete
fill 247 164 642 265 165 642 minecraft:gray_concrete
fill 249 164 607 263 165 607 minecraft:gray_concrete
fill 249 164 643 263 165 643 minecraft:gray_concrete
fill 251 164 606 261 165 606 minecraft:gray_concrete
fill 251 164 620 251 164 627 minecraft:gray_concrete
fill 251 164 644 261 165 644 minecraft:gray_concrete
fill 252 164 620 275 164 620 minecraft:gray_concrete
fill 252 164 624 253 164 627 minecraft:gray_concrete
fill 254 164 624 254 164 625 minecraft:gray_concrete
setblock 254 164 626 minecraft:black_concrete
fill 254 164 627 254 164 630 minecraft:gray_concrete
fill 255 164 621 255 164 624 minecraft:gray_concrete
fill 255 164 628 255 164 630 minecraft:gray_concrete
fill 256 164 621 257 164 623 minecraft:gray_concrete
setblock 256 164 624 minecraft:black_concrete
setblock 256 164 628 minecraft:black_concrete
fill 256 164 629 275 164 630 minecraft:gray_concrete
fill 257 164 624 275 164 624 minecraft:gray_concrete
fill 257 164 628 275 164 628 minecraft:gray_concrete
fill 258 164 625 275 164 625 minecraft:gray_concrete
setblock 258 164 626 minecraft:black_concrete
fill 258 164 627 275 164 627 minecraft:gray_concrete
fill 259 164 626 275 164 626 minecraft:gray_concrete
fill 261 164 621 275 164 623 minecraft:gray_concrete
fill 236 165 605 240 165 645 minecraft:gray_concrete
fill 241 165 605 241 165 612 minecraft:gray_concrete
fill 241 165 614 242 165 645 minecraft:gray_concrete
fill 242 165 605 242 165 611 minecraft:gray_concrete
fill 243 165 605 243 165 610 minecraft:gray_concrete
fill 243 165 614 243 168 625 minecraft:gray_concrete
fill 243 165 626 252 166 626 minecraft:iron_block
fill 243 165 627 243 166 638 minecraft:gray_concrete
fill 243 165 640 243 165 645 minecraft:gray_concrete
fill 244 165 605 244 165 609 minecraft:gray_concrete
fill 244 165 614 244 169 620 minecraft:gray_concrete
fill 244 165 621 268 166 621 minecraft:iron_block
fill 244 165 622 244 172 624 minecraft:gray_concrete
fill 244 165 625 244 166 625 minecraft:iron_block
fill 244 165 627 244 166 627 minecraft:iron_block
fill 244 165 628 244 172 630 minecraft:gray_concrete
fill 244 165 631 268 166 631 minecraft:iron_block
fill 244 165 632 244 167 638 minecraft:gray_concrete
fill 244 165 641 244 165 645 minecraft:gray_concrete
fill 245 165 605 246 165 608 minecraft:gray_concrete
fill 245 165 614 247 170 619 minecraft:gray_concrete
fill 245 165 620 267 166 620 minecraft:iron_block
fill 245 165 622 267 166 622 minecraft:iron_block
fill 245 165 623 245 173 625 minecraft:gray_concrete
fill 245 165 627 245 173 629 minecraft:gray_concrete
fill 245 165 630 267 166 630 minecraft:iron_block
fill 245 165 632 267 166 632 minecraft:iron_block
fill 245 165 633 247 168 638 minecraft:gray_concrete
fill 245 165 642 246 165 645 minecraft:gray_concrete
fill 246 165 623 253 166 625 minecraft:iron_block
fill 246 165 627 253 166 629 minecraft:iron_block
fill 247 165 605 248 165 607 minecraft:gray_concrete
fill 247 165 643 248 165 645 minecraft:gray_concrete
fill 248 165 614 252 172 615 minecraft:gray_concrete
fill 248 165 616 249 166 617 minecraft:iron_block
fill 248 165 618 248 173 618 minecraft:gray_concrete
fill 248 165 619 264 166 619 minecraft:iron_block
fill 248 165 633 264 166 633 minecraft:iron_block
fill 248 165 634 248 173 634 minecraft:gray_concrete
fill 248 165 635 249 166 636 minecraft:iron_block
fill 248 165 637 252 170 638 minecraft:gray_concrete
fill 249 165 605 250 165 606 minecraft:gray_concrete
fill 249 165 618 263 166 618 minecraft:iron_block
fill 249 165 634 263 166 634 minecraft:iron_block
fill 249 165 644 250 165 645 minecraft:gray_concrete
fill 250 165 616 251 173 616 minecraft:gray_concrete
fill 250 165 617 264 166 617 minecraft:iron_block
fill 250 165 635 264 166 635 minecraft:iron_block
fill 250 165 636 251 172 636 minecraft:gray_concrete
fill 251 165 605 276 165 605 minecraft:gray_concrete
fill 251 165 645 276 165 645 minecraft:gray_concrete
fill 252 165 616 260 166 616 minecraft:iron_block
fill 252 165 636 260 166 636 minecraft:iron_block
fill 253 165 614 254 166 615 minecraft:iron_block
fill 253 165 626 254 165 626 minecraft:waxed_copper_block
fill 253 165 637 254 166 638 minecraft:iron_block
fill 254 165 623 255 166 623 minecraft:iron_block
fill 254 165 624 254 166 625 minecraft:waxed_copper_block
fill 254 165 627 254 166 628 minecraft:waxed_copper_block
fill 254 165 629 255 166 629 minecraft:iron_block
fill 255 165 614 255 173 615 minecraft:gray_concrete
fill 255 165 624 258 165 624 minecraft:waxed_copper_block
fill 255 165 628 258 165 628 minecraft:waxed_copper_block
fill 255 165 637 255 172 638 minecraft:gray_concrete
fill 256 165 614 257 173 614 minecraft:gray_concrete
fill 256 165 615 256 166 615 minecraft:iron_block
fill 256 165 623 256 167 623 minecraft:waxed_copper_block
fill 256 165 629 256 167 629 minecraft:waxed_copper_block
fill 256 165 637 256 166 637 minecraft:iron_block
fill 256 165 638 257 172 638 minecraft:gray_concrete
fill 257 165 615 257 173 615 minecraft:gray_concrete
fill 257 165 623 266 166 623 minecraft:iron_block
fill 257 165 629 266 166 629 minecraft:iron_block
fill 257 165 637 257 173 637 minecraft:gray_concrete
fill 258 165 614 259 166 615 minecraft:iron_block
fill 258 165 625 258 165 627 minecraft:waxed_copper_block
fill 258 165 637 259 166 638 minecraft:iron_block
fill 259 165 624 266 166 625 minecraft:iron_block
fill 259 165 626 259 167 626 minecraft:waxed_copper_block
fill 259 165 627 266 166 628 minecraft:iron_block
fill 260 165 614 276 165 615 minecraft:gray_concrete
fill 260 165 626 269 166 626 minecraft:iron_block
fill 260 165 637 276 165 638 minecraft:gray_concrete
fill 261 165 616 262 173 616 minecraft:gray_concrete
fill 261 165 636 262 172 636 minecraft:gray_concrete
fill 262 165 606 276 165 606 minecraft:gray_concrete
fill 262 165 644 276 165 644 minecraft:gray_concrete
fill 263 165 616 264 166 616 minecraft:iron_block
fill 263 165 636 264 166 636 minecraft:iron_block
fill 264 165 607 276 165 607 minecraft:gray_concrete
fill 264 165 618 276 165 618 minecraft:gray_concrete
fill 264 165 634 276 165 634 minecraft:gray_concrete
fill 264 165 643 276 165 643 minecraft:gray_concrete
fill 265 165 616 276 165 617 minecraft:gray_concrete
fill 265 165 619 276 165 619 minecraft:gray_concrete
fill 265 165 633 276 165 633 minecraft:gray_concrete
fill 265 165 635 276 165 636 minecraft:gray_concrete
fill 266 165 608 276 165 608 minecraft:gray_concrete
fill 266 165 642 276 165 642 minecraft:gray_concrete
fill 267 165 623 267 170 625 minecraft:gray_concrete
fill 267 165 627 267 170 629 minecraft:gray_concrete
fill 268 165 609 276 165 609 minecraft:gray_concrete
fill 268 165 620 276 165 620 minecraft:gray_concrete
fill 268 165 622 276 165 624 minecraft:gray_concrete
fill 268 165 625 268 166 625 minecraft:iron_block
fill 268 165 627 268 166 627 minecraft:iron_block
fill 268 165 628 276 165 630 minecraft:gray_concrete
fill 268 165 632 276 165 632 minecraft:gray_concrete
fill 268 165 641 276 165 641 minecraft:gray_concrete
fill 269 165 610 276 165 610 minecraft:gray_concrete
fill 269 165 621 276 165 621 minecraft:gray_concrete
fill 269 165 625 276 165 625 minecraft:gray_concrete
fill 269 165 627 276 165 627 minecraft:gray_concrete
fill 269 165 631 276 165 631 minecraft:gray_concrete
fill 269 165 640 276 165 640 minecraft:gray_concrete
fill 270 165 611 276 165 611 minecraft:gray_concrete
fill 270 165 626 276 165 626 minecraft:gray_concrete
fill 270 165 639 276 165 639 minecraft:gray_concrete
fill 271 165 612 276 165 612 minecraft:gray_concrete
fill 272 165 613 276 165 613 minecraft:gray_concrete
fill 238 166 621 242 166 629 minecraft:gray_concrete
fill 239 166 618 242 166 620 minecraft:gray_concrete
fill 239 166 630 242 166 632 minecraft:gray_concrete
fill 240 166 616 242 166 617 minecraft:gray_concrete
fill 240 166 633 242 166 634 minecraft:gray_concrete
fill 241 166 615 242 166 615 minecraft:gray_concrete
fill 241 166 635 242 166 635 minecraft:gray_concrete
fill 242 166 613 242 166 614 minecraft:gray_concrete
fill 242 166 636 242 166 637 minecraft:gray_concrete
fill 243 166 612 269 166 613 minecraft:gray_concrete
fill 244 166 611 268 166 611 minecraft:gray_concrete
fill 244 166 639 268 166 639 minecraft:gray_concrete
fill 246 166 610 266 166 610 minecraft:gray_concrete
fill 246 166 640 266 166 640 minecraft:gray_concrete
fill 247 166 609 265 166 609 minecraft:gray_concrete
fill 247 166 641 265 166 641 minecraft:gray_concrete
fill 249 166 608 263 166 608 minecraft:gray_concrete
fill 249 166 642 263 166 642 minecraft:gray_concrete
fill 252 166 607 260 166 607 minecraft:gray_concrete
fill 252 166 643 260 166 643 minecraft:gray_concrete
fill 253 166 626 253 167 626 minecraft:waxed_copper_block
setblock 255 166 624 minecraft:waxed_copper_block
setblock 255 166 628 minecraft:waxed_copper_block
fill 257 166 624 258 166 624 minecraft:waxed_copper_block
fill 257 166 628 258 166 628 minecraft:waxed_copper_block
setblock 258 166 625 minecraft:waxed_copper_block
setblock 258 166 627 minecraft:waxed_copper_block
fill 260 166 614 270 167 615 minecraft:gray_concrete
fill 260 166 637 269 166 638 minecraft:gray_concrete
fill 264 166 618 273 166 618 minecraft:gray_concrete
fill 264 166 634 272 166 634 minecraft:gray_concrete
fill 265 166 616 272 166 617 minecraft:gray_concrete
fill 265 166 619 273 166 619 minecraft:gray_concrete
fill 265 166 633 272 167 633 minecraft:gray_concrete
fill 265 166 635 270 167 636 minecraft:gray_concrete
fill 268 166 620 273 167 620 minecraft:gray_concrete
fill 268 166 622 274 166 624 minecraft:gray_concrete
fill 268 166 628 273 167 630 minecraft:gray_concrete
fill 268 166 632 273 166 632 minecraft:gray_concrete
fill 269 166 621 274 166 621 minecraft:gray_concrete
fill 269 166 625 274 166 625 minecraft:gray_concrete
fill 269 166 627 274 166 627 minecraft:gray_concrete
fill 269 166 631 273 166 631 minecraft:gray_concrete
setblock 270 166 613 minecraft:gray_concrete
fill 270 166 626 274 166 626 minecraft:gray_concrete
setblock 270 166 637 minecraft:gray_concrete
setblock 271 166 615 minecraft:gray_concrete
setblock 271 166 635 minecraft:gray_concrete
fill 274 166 628 274 166 629 minecraft:gray_concrete
fill 239 167 620 242 167 630 minecraft:gray_concrete
fill 240 167 617 242 167 619 minecraft:gray_concrete
fill 240 167 631 243 167 633 minecraft:gray_concrete
fill 241 167 616 242 167 616 minecraft:gray_concrete
fill 241 167 634 243 167 634 minecraft:gray_concrete
fill 242 167 614 242 167 615 minecraft:gray_concrete
fill 242 167 635 243 167 636 minecraft:gray_concrete
fill 243 167 613 269 167 613 minecraft:gray_concrete
fill 243 167 626 243 171 630 minecraft:gray_concrete
setblock 243 167 637 minecraft:gray_concrete
fill 244 167 612 268 167 612 minecraft:gray_concrete
fill 244 167 621 250 170 621 minecraft:gray_concrete
fill 244 167 625 244 173 627 minecraft:gray_concrete
fill 244 167 631 250 171 631 minecraft:gray_concrete
fill 245 167 611 267 167 611 minecraft:gray_concrete
fill 245 167 620 251 170 620 minecraft:gray_concrete
fill 245 167 622 249 170 622 minecraft:gray_concrete
fill 245 167 626 248 171 626 minecraft:gray_concrete
fill 245 167 630 249 171 630 minecraft:gray_concrete
fill 245 167 632 251 171 632 minecraft:gray_concrete
fill 245 167 639 267 167 639 minecraft:gray_concrete
fill 246 167 623 248 171 625 minecraft:gray_concrete
fill 246 167 627 248 171 629 minecraft:gray_concrete
fill 247 167 610 265 167 610 minecraft:gray_concrete
fill 247 167 640 265 167 640 minecraft:gray_concrete
fill 248 167 609 264 167 609 minecraft:gray_concrete
fill 248 167 616 249 173 617 minecraft:gray_concrete
fill 248 167 619 253 169 619 minecraft:gray_concrete
fill 248 167 633 253 171 633 minecraft:gray_concrete
fill 248 167 635 249 172 636 minecraft:gray_concrete
fill 248 167 641 264 167 641 minecraft:gray_concrete
fill 249 167 618 272 167 618 minecraft:gray_concrete
fill 249 167 623 249 170 623 minecraft:gray_concrete
fill 249 167 624 249 167 628 minecraft:waxed_oxidized_copper
fill 249 167 629 249 171 629 minecraft:gray_concrete
fill 249 167 634 271 167 634 minecraft:gray_concrete
fill 250 167 617 272 167 617 minecraft:gray_concrete
fill 250 167 622 250 167 623 minecraft:waxed_oxidized_copper
fill 250 167 624 251 167 628 minecraft:gray_concrete
fill 250 167 629 250 167 630 minecraft:waxed_oxidized_copper
fill 250 167 635 264 172 635 minecraft:gray_concrete
fill 251 167 608 261 167 608 minecraft:gray_concrete
setblock 251 167 621 minecraft:waxed_oxidized_copper
fill 251 167 622 252 167 623 minecraft:gray_concrete
fill 251 167 629 252 167 630 minecraft:gray_concrete
setblock 251 167 631 minecraft:waxed_oxidized_copper
fill 251 167 642 261 167 642 minecraft:gray_concrete
fill 252 167 616 260 172 616 minecraft:gray_concrete
fill 252 167 620 253 167 620 minecraft:waxed_oxidized_copper
fill 252 167 621 255 167 621 minecraft:gray_concrete
fill 252 167 624 252 167 627 minecraft:black_concrete
setblock 252 167 628 minecraft:gray_concrete
fill 252 167 631 260 167 631 minecraft:gray_concrete
fill 252 167 632 253 167 632 minecraft:waxed_oxidized_copper
fill 252 167 636 260 173 636 minecraft:gray_concrete
fill 253 167 614 254 173 615 minecraft:gray_concrete
setblock 253 167 622 minecraft:gray_concrete
setblock 253 167 623 minecraft:black_concrete
fill 253 167 628 253 167 629 minecraft:black_concrete
fill 253 167 630 254 167 630 minecraft:gray_concrete
fill 253 167 637 254 172 638 minecraft:gray_concrete
fill 254 167 619 258 167 619 minecraft:waxed_oxidized_copper
fill 254 167 620 258 168 620 minecraft:gray_concrete
fill 254 167 622 255 167 622 minecraft:black_concrete
setblock 254 167 624 minecraft:waxed_copper_block
setblock 254 167 628 minecraft:waxed_copper_block
setblock 254 167 629 minecraft:black_concrete
fill 254 167 632 258 169 632 minecraft:gray_concrete
fill 254 167 633 258 167 633 minecraft:waxed_oxidized_copper
fill 255 167 630 257 167 630 minecraft:black_concrete
fill 256 167 615 256 173 615 minecraft:gray_concrete
setblock 256 167 621 minecraft:black_concrete
fill 256 167 637 256 173 637 minecraft:gray_concrete
fill 257 167 621 260 167 621 minecraft:gray_concrete
fill 257 167 622 258 167 622 minecraft:black_concrete
fill 258 167 614 259 173 615 minecraft:gray_concrete
setblock 258 167 624 minecraft:waxed_copper_block
setblock 258 167 628 minecraft:waxed_copper_block
fill 258 167 629 259 167 629 minecraft:black_concrete
fill 258 167 630 261 167 630 minecraft:gray_concrete
fill 258 167 637 268 167 638 minecraft:gray_concrete
fill 259 167 619 272 168 619 minecraft:gray_concrete
fill 259 167 620 260 167 620 minecraft:waxed_oxidized_copper
fill 259 167 622 261 167 622 minecraft:gray_concrete
setblock 259 167 623 minecraft:black_concrete
setblock 259 167 628 minecraft:black_concrete
fill 259 167 632 260 167 632 minecraft:waxed_oxidized_copper
fill 259 167 633 264 171 633 minecraft:gray_concrete
fill 260 167 623 261 167 623 minecraft:gray_concrete
fill 260 167 624 260 167 627 minecraft:black_concrete
fill 260 167 628 261 167 629 minecraft:gray_concrete
fill 261 167 620 267 170 620 minecraft:gray_concrete
setblock 261 167 621 minecraft:waxed_oxidized_copper
fill 261 167 624 262 167 627 minecraft:gray_concrete
setblock 261 167 631 minecraft:waxed_oxidized_copper
fill 261 167 632 272 167 632 minecraft:gray_concrete
fill 262 167 621 273 167 621 minecraft:gray_concrete
fill 262 167 622 262 167 623 minecraft:waxed_oxidized_copper
fill 262 167 628 262 169 628 minecraft:gray_concrete
fill 262 167 629 262 167 630 minecraft:waxed_oxidized_copper
fill 262 167 631 272 168 631 minecraft:gray_concrete
fill 263 167 616 271 167 616 minecraft:gray_concrete
fill 263 167 622 266 170 623 minecraft:gray_concrete
fill 263 167 624 263 167 628 minecraft:waxed_oxidized_copper
fill 263 167 629 266 170 630 minecraft:gray_concrete
fill 263 167 636 264 172 636 minecraft:gray_concrete
fill 264 167 624 266 171 628 minecraft:gray_concrete
fill 267 167 622 273 168 622 minecraft:gray_concrete
fill 267 167 626 273 168 626 minecraft:gray_concrete
fill 267 167 630 267 170 630 minecraft:gray_concrete
fill 268 167 623 273 168 625 minecraft:gray_concrete
fill 268 167 627 273 168 627 minecraft:gray_concrete
setblock 269 167 637 minecraft:gray_concrete
fill 239 168 622 242 168 628 minecraft:gray_concrete
fill 240 168 619 242 168 621 minecraft:gray_concrete
fill 240 168 629 242 168 631 minecraft:gray_concrete
fill 241 168 617 242 168 618 minecraft:gray_concrete
fill 241 168 632 244 168 633 minecraft:gray_concrete
fill 242 168 615 242 168 616 minecraft:gray_concrete
fill 242 168 634 244 168 635 minecraft:gray_concrete
fill 243 168 631 243 171 631 minecraft:gray_concrete
fill 243 168 636 244 168 636 minecraft:gray_concrete
fill 244 168 613 268 168 613 minecraft:gray_concrete
setblock 244 168 637 minecraft:gray_concrete
fill 245 168 612 267 168 612 minecraft:gray_concrete
fill 246 168 611 266 168 611 minecraft:gray_concrete
fill 246 168 639 266 168 639 minecraft:gray_concrete
fill 248 168 610 264 168 610 minecraft:gray_concrete
fill 248 168 640 264 168 640 minecraft:gray_concrete
fill 249 168 618 271 169 618 minecraft:gray_concrete
fill 249 168 624 250 168 628 minecraft:gray_concrete
fill 249 168 634 270 168 634 minecraft:gray_concrete
fill 250 168 609 262 168 609 minecraft:gray_concrete
fill 250 168 617 271 168 617 minecraft:gray_concrete
fill 250 168 622 251 168 623 minecraft:gray_concrete
fill 250 168 629 251 168 630 minecraft:gray_concrete
fill 250 168 641 262 168 641 minecraft:gray_concrete
fill 251 168 621 253 168 621 minecraft:gray_concrete
fill 251 168 624 251 168 627 minecraft:gold_block
setblock 251 168 628 minecraft:gray_concrete
fill 251 168 631 254 168 631 minecraft:gray_concrete
fill 252 168 620 253 169 620 minecraft:gray_concrete
fill 252 168 622 252 168 623 minecraft:gold_block
fill 252 168 628 252 168 629 minecraft:gold_block
setblock 252 168 630 minecraft:gray_concrete
fill 252 168 632 253 170 632 minecraft:gray_concrete
fill 253 168 608 259 168 608 minecraft:gray_concrete
setblock 253 168 622 minecraft:gold_block
fill 253 168 630 254 168 630 minecraft:gold_block
fill 253 168 642 259 168 642 minecraft:gray_concrete
fill 254 168 619 258 169 619 minecraft:gray_concrete
fill 254 168 621 258 168 621 minecraft:gold_block
fill 254 168 633 258 170 633 minecraft:gray_concrete
fill 255 168 631 257 168 631 minecraft:gold_block
fill 258 168 630 259 168 630 minecraft:gold_block
fill 258 168 631 261 168 631 minecraft:gray_concrete
fill 258 168 637 267 168 638 minecraft:gray_concrete
fill 259 168 620 260 168 621 minecraft:gray_concrete
fill 259 168 622 260 168 622 minecraft:gold_block
fill 259 168 632 271 169 632 minecraft:gray_concrete
fill 260 168 614 269 168 615 minecraft:gray_concrete
setblock 260 168 623 minecraft:gold_block
fill 260 168 628 260 168 629 minecraft:gold_block
fill 260 168 630 262 168 630 minecraft:gray_concrete
fill 261 168 621 262 168 623 minecraft:gray_concrete
fill 261 168 624 261 168 627 minecraft:gold_block
fill 261 168 628 261 168 629 minecraft:gray_concrete
fill 262 168 624 263 168 627 minecraft:gray_concrete
fill 262 168 629 262 170 629 minecraft:gray_concrete
fill 263 168 616 270 168 616 minecraft:gray_concrete
fill 263 168 621 272 169 621 minecraft:gray_concrete
fill 263 168 628 263 170 628 minecraft:gray_concrete
fill 265 168 633 271 168 633 minecraft:gray_concrete
fill 265 168 635 269 168 636 minecraft:gray_concrete
fill 268 168 620 272 168 620 minecraft:gray_concrete
fill 268 168 628 272 168 630 minecraft:gray_concrete
setblock 268 168 637 minecraft:gray_concrete
setblock 270 168 615 minecraft:gray_concrete
setblock 270 168 635 minecraft:gray_concrete
setblock 273 168 628 minecraft:gray_concrete
fill 236 169 605 236 169 645 minecraft:gray_concrete
fill 237 169 605 276 169 605 minecraft:gray_concrete
setblock 237 169 612 minecraft:black_concrete
setblock 237 169 614 minecraft:black_concrete
setblock 237 169 631 minecraft:black_concrete
fill 237 169 645 276 169 645 minecraft:gray_concrete
fill 240 169 621 242 169 629 minecraft:gray_concrete
fill 241 169 618 243 169 620 minecraft:gray_concrete
fill 241 169 630 242 169 632 minecraft:gray_concrete
fill 242 169 617 243 169 617 minecraft:gray_concrete
fill 242 169 633 247 169 633 minecraft:gray_concrete
fill 243 169 615 243 169 616 minecraft:gray_concrete
fill 243 169 621 243 172 625 minecraft:gray_concrete
fill 243 169 632 244 171 632 minecraft:gray_concrete
fill 243 169 634 247 169 635 minecraft:gray_concrete
fill 244 169 636 247 169 636 minecraft:gray_concrete
fill 245 169 613 267 169 613 minecraft:gray_concrete
fill 245 169 637 247 169 637 minecraft:gray_concrete
fill 246 169 612 266 169 612 minecraft:gray_concrete
fill 246 169 638 247 169 638 minecraft:gray_concrete
fill 248 169 611 264 169 611 minecraft:gray_concrete
fill 248 169 639 264 169 639 minecraft:gray_concrete
fill 249 169 610 263 169 610 minecraft:gray_concrete
fill 249 169 624 249 169 628 minecraft:gray_concrete
fill 249 169 634 269 170 634 minecraft:gray_concrete
fill 249 169 640 263 169 640 minecraft:gray_concrete
fill 250 169 617 270 169 617 minecraft:gray_concrete
fill 250 169 622 250 169 623 minecraft:gray_concrete
fill 250 169 624 250 169 627 minecraft:black_concrete
fill 250 169 628 250 169 630 minecraft:gray_concrete
setblock 251 169 621 minecraft:gray_concrete
fill 251 169 622 251 169 623 minecraft:black_concrete
fill 251 169 628 251 169 629 minecraft:black_concrete
fill 251 169 630 251 169 631 minecraft:gray_concrete
fill 252 169 609 260 169 609 minecraft:gray_concrete
fill 252 169 621 253 169 621 minecraft:black_concrete
fill 252 169 630 253 169 630 minecraft:black_concrete
fill 252 169 631 253 169 631 minecraft:gray_concrete
fill 252 169 641 260 169 641 minecraft:gray_concrete
fill 254 169 620 258 169 620 minecraft:black_concrete
fill 254 169 631 258 169 631 minecraft:black_concrete
fill 258 169 637 266 169 638 minecraft:gray_concrete
fill 259 169 619 260 169 620 minecraft:gray_concrete
fill 259 169 621 260 169 621 minecraft:black_concrete
fill 259 169 630 260 169 630 minecraft:black_concrete
fill 259 169 631 271 169 631 minecraft:gray_concrete
fill 260 169 614 268 169 615 minecraft:gray_concrete
fill 261 169 619 271 169 619 minecraft:gray_concrete
fill 261 169 621 262 169 621 minecraft:gray_concrete
fill 261 169 622 261 169 623 minecraft:black_concrete
fill 261 169 628 261 169 629 minecraft:black_concrete
fill 261 169 630 262 169 630 minecraft:gray_concrete
fill 262 169 622 262 169 623 minecraft:gray_concrete
fill 262 169 624 262 169 627 minecraft:black_concrete
fill 263 169 616 269 170 616 minecraft:gray_concrete
fill 263 169 624 263 169 627 minecraft:gray_concrete
fill 265 169 633 270 169 633 minecraft:gray_concrete
fill 265 169 635 268 169 636 minecraft:gray_concrete
fill 267 169 622 272 169 622 minecraft:gray_concrete
fill 267 169 626 272 169 626 minecraft:gray_concrete
setblock 267 169 637 minecraft:gray_concrete
fill 267 169 643 267 169 644 minecraft:black_concrete
fill 268 169 620 271 171 620 minecraft:gray_concrete
fill 268 169 623 272 169 625 minecraft:gray_concrete
fill 268 169 627 271 170 630 minecraft:gray_concrete
setblock 269 169 615 minecraft:gray_concrete
setblock 269 169 635 minecraft:gray_concrete
fill 271 169 643 271 169 644 minecraft:black_concrete
fill 272 169 627 272 169 629 minecraft:gray_concrete
fill 274 169 626 275 169 626 minecraft:black_concrete
fill 274 169 633 275 169 633 minecraft:black_concrete
fill 276 169 606 276 169 644 minecraft:gray_concrete
fill 236 170 611 236 224 612 minecraft:gray_concrete
setblock 236 170 614 minecraft:black_concrete
fill 236 170 619 236 224 620 minecraft:gray_concrete
fill 236 170 627 236 224 628 minecraft:gray_concrete
setblock 236 170 631 minecraft:black_concrete
fill 236 170 635 236 224 636 minecraft:gray_concrete
fill 236 170 643 236 224 644 minecraft:gray_concrete
fill 237 170 605 238 224 605 minecraft:gray_concrete
fill 241 170 620 242 171 630 minecraft:gray_concrete
setblock 242 170 615 minecraft:sea_lantern
fill 242 170 618 244 171 619 minecraft:gray_concrete
fill 242 170 631 242 171 632 minecraft:gray_concrete
setblock 242 170 633 minecraft:sea_lantern
setblock 242 170 639 minecraft:sea_lantern
fill 242 170 645 243 224 645 minecraft:gray_concrete
fill 243 170 616 244 170 617 minecraft:gray_concrete
fill 243 170 620 244 171 620 minecraft:gray_concrete
fill 243 170 633 247 170 634 minecraft:gray_concrete
setblock 244 170 615 minecraft:gray_concrete
fill 244 170 635 247 170 635 minecraft:gray_concrete
fill 245 170 605 246 224 605 minecraft:gray_concrete
fill 245 170 636 247 170 636 minecraft:gray_concrete
setblock 246 170 611 minecraft:sea_lantern
fill 246 170 613 266 170 613 minecraft:gray_concrete
fill 246 170 637 247 170 637 minecraft:gray_concrete
fill 247 170 612 265 170 612 minecraft:gray_concrete
setblock 247 170 638 minecraft:gray_concrete
fill 248 170 619 252 170 619 minecraft:gray_concrete
setblock 248 170 639 minecraft:sea_lantern
fill 249 170 611 263 171 611 minecraft:gray_concrete
fill 249 170 618 270 170 618 minecraft:gray_concrete
fill 249 170 624 249 170 626 minecraft:black_concrete
fill 249 170 627 249 170 628 minecraft:gray_concrete
fill 249 170 639 263 171 639 minecraft:gray_concrete
fill 250 170 617 269 170 617 minecraft:gray_concrete
fill 250 170 622 250 170 623 minecraft:black_concrete
fill 250 170 627 250 170 628 minecraft:black_concrete
fill 250 170 629 250 170 630 minecraft:gray_concrete
fill 250 170 645 251 224 645 minecraft:gray_concrete
fill 251 170 610 261 171 610 minecraft:gray_concrete
setblock 251 170 621 minecraft:black_concrete
fill 251 170 629 251 170 630 minecraft:black_concrete
setblock 251 170 631 minecraft:gray_concrete
fill 251 170 640 261 171 640 minecraft:gray_concrete
fill 252 170 620 253 170 620 minecraft:black_concrete
fill 252 170 631 253 170 631 minecraft:black_concrete
fill 253 170 605 254 224 605 minecraft:gray_concrete
fill 253 170 619 259 170 619 minecraft:black_concrete
fill 254 170 632 258 170 632 minecraft:black_concrete
fill 258 170 637 265 170 638 minecraft:gray_concrete
fill 258 170 645 259 224 645 minecraft:gray_concrete
fill 259 170 620 260 170 620 minecraft:black_concrete
fill 259 170 631 260 170 631 minecraft:black_concrete
fill 259 170 632 270 170 632 minecraft:gray_concrete
fill 260 170 614 267 170 615 minecraft:gray_concrete
fill 260 170 619 270 170 619 minecraft:gray_concrete
fill 261 170 605 262 224 605 minecraft:gray_concrete
setblock 261 170 621 minecraft:black_concrete
fill 261 170 629 261 170 630 minecraft:black_concrete
fill 261 170 631 270 170 631 minecraft:gray_concrete
fill 262 170 621 271 170 621 minecraft:gray_concrete
fill 262 170 622 262 170 623 minecraft:black_concrete
fill 262 170 627 262 170 628 minecraft:black_concrete
setblock 262 170 630 minecraft:gray_concrete
fill 263 170 624 263 170 626 minecraft:black_concrete
setblock 263 170 627 minecraft:gray_concrete
setblock 264 170 611 minecraft:sea_lantern
fill 265 170 633 269 170 633 minecraft:gray_concrete
fill 265 170 635 267 170 636 minecraft:gray_concrete
setblock 266 170 637 minecraft:gray_concrete
setblock 266 170 639 minecraft:sea_lantern
fill 266 170 645 267 224 645 minecraft:gray_concrete
fill 267 170 622 271 170 622 minecraft:gray_concrete
fill 267 170 626 271 170 626 minecraft:gray_concrete
setblock 267 170 644 minecraft:black_concrete
setblock 268 170 615 minecraft:gray_concrete
fill 268 170 623 271 170 625 minecraft:gray_concrete
setblock 268 170 635 minecraft:gray_concrete
fill 269 170 605 270 224 605 minecraft:gray_concrete
setblock 270 170 611 minecraft:sea_lantern
setblock 270 170 617 minecraft:sea_lantern
setblock 270 170 635 minecraft:sea_lantern
setblock 271 170 644 minecraft:black_concrete
fill 274 170 645 275 224 645 minecraft:gray_concrete
setblock 275 170 626 minecraft:black_concrete
setblock 275 170 633 minecraft:black_concrete
fill 276 170 606 276 224 607 minecraft:gray_concrete
fill 276 170 614 276 224 615 minecraft:gray_concrete
fill 276 170 622 276 224 623 minecraft:gray_concrete
fill 276 170 630 276 224 631 minecraft:gray_concrete
fill 276 170 638 276 224 639 minecraft:gray_concrete
fill 236 171 605 236 171 610 minecraft:gray_concrete
fill 236 171 613 241 171 618 minecraft:gray_concrete
fill 236 171 621 240 171 626 minecraft:gray_concrete
fill 236 171 629 240 171 634 minecraft:gray_concrete
fill 236 171 637 242 171 642 minecraft:gray_concrete
fill 236 171 645 241 171 645 minecraft:gray_concrete
fill 237 171 606 242 171 612 minecraft:gray_concrete
fill 237 171 619 240 171 620 minecraft:gray_concrete
fill 237 171 627 240 171 628 minecraft:gray_concrete
fill 237 171 635 242 171 636 minecraft:gray_concrete
fill 237 171 643 276 171 644 minecraft:gray_concrete
fill 239 171 605 244 171 605 minecraft:gray_concrete
setblock 241 171 619 minecraft:gray_concrete
fill 241 171 631 241 171 634 minecraft:gray_concrete
fill 242 171 613 242 171 617 minecraft:gray_concrete
fill 242 171 633 242 171 634 minecraft:gray_concrete
fill 243 171 606 248 171 611 minecraft:gray_concrete
fill 243 171 639 248 171 642 minecraft:gray_concrete
fill 244 171 617 247 171 617 minecraft:gray_concrete
fill 244 171 621 249 171 621 minecraft:gray_concrete
fill 244 171 633 247 171 633 minecraft:gray_concrete
fill 244 171 645 249 171 645 minecraft:gray_concrete
fill 245 171 615 247 171 616 minecraft:gray_concrete
fill 245 171 618 247 172 620 minecraft:gray_concrete
fill 245 171 622 248 171 622 minecraft:gray_concrete
fill 245 171 634 247 171 635 minecraft:gray_concrete
fill 246 171 614 247 171 614 minecraft:gray_concrete
fill 246 171 636 247 171 636 minecraft:gray_concrete
fill 247 171 605 252 171 605 minecraft:gray_concrete
fill 248 171 613 264 171 613 minecraft:gray_concrete
fill 248 171 619 250 171 620 minecraft:gray_concrete
fill 248 171 637 252 171 637 minecraft:gray_concrete
fill 249 171 606 250 171 610 minecraft:gray_concrete
fill 249 171 612 263 171 612 minecraft:gray_concrete
fill 249 171 618 252 171 618 minecraft:gray_concrete
fill 249 171 622 249 171 628 minecraft:gold_block
fill 249 171 634 267 171 634 minecraft:gray_concrete
fill 249 171 638 252 171 638 minecraft:gray_concrete
fill 249 171 640 250 171 642 minecraft:gray_concrete
fill 250 171 617 268 171 617 minecraft:gray_concrete
setblock 250 171 621 minecraft:gold_block
fill 250 171 629 250 171 630 minecraft:gold_block
fill 251 171 606 275 171 609 minecraft:gray_concrete
setblock 251 171 619 minecraft:gray_concrete
setblock 251 171 620 minecraft:gold_block
fill 251 171 631 252 171 631 minecraft:gold_block
fill 251 171 641 276 171 642 minecraft:gray_concrete
setblock 252 171 619 minecraft:gold_block
setblock 252 171 632 minecraft:gray_concrete
fill 252 171 645 257 171 645 minecraft:gray_concrete
fill 253 171 618 259 171 618 minecraft:gold_block
fill 253 171 632 254 171 632 minecraft:gold_block
setblock 254 171 623 minecraft:light[level=14]
setblock 254 171 631 minecraft:light[level=14]
setblock 254 171 633 minecraft:gray_concrete
fill 255 171 605 260 171 605 minecraft:gray_concrete
fill 255 171 633 257 171 633 minecraft:gold_block
fill 258 171 632 259 171 632 minecraft:gold_block
setblock 258 171 633 minecraft:gray_concrete
fill 258 171 637 263 171 638 minecraft:gray_concrete
fill 260 171 614 266 171 615 minecraft:gray_concrete
fill 260 171 618 276 171 618 minecraft:gray_concrete
setblock 260 171 619 minecraft:gold_block
fill 260 171 623 261 172 629 minecraft:waxed_copper_block
fill 260 171 631 261 171 631 minecraft:gold_block
fill 260 171 632 264 171 632 minecraft:gray_concrete
fill 260 171 645 265 171 645 minecraft:gray_concrete
fill 261 171 619 276 171 619 minecraft:gray_concrete
setblock 261 171 620 minecraft:gold_block
fill 261 171 622 269 172 622 minecraft:waxed_copper_block
fill 261 171 630 269 172 630 minecraft:waxed_copper_block
fill 262 171 610 276 171 610 minecraft:gray_concrete
fill 262 171 620 264 171 620 minecraft:gray_concrete
fill 262 171 621 268 172 621 minecraft:waxed_copper_block
fill 262 171 623 262 172 625 minecraft:waxed_copper_block
fill 262 171 627 262 172 629 minecraft:waxed_copper_block
fill 262 171 631 268 172 631 minecraft:waxed_copper_block
fill 262 171 640 276 171 640 minecraft:gray_concrete
fill 263 171 605 268 171 605 minecraft:gray_concrete
fill 263 171 616 267 171 616 minecraft:gray_concrete
fill 263 171 623 264 172 623 minecraft:waxed_copper_block
fill 263 171 624 263 171 628 minecraft:gold_block
fill 263 171 629 264 172 629 minecraft:waxed_copper_block
fill 264 171 611 276 171 611 minecraft:gray_concrete
setblock 264 171 637 minecraft:gray_concrete
fill 264 171 639 275 171 639 minecraft:gray_concrete
fill 265 171 620 265 172 620 minecraft:waxed_copper_block
fill 265 171 623 265 172 623 minecraft:gray_concrete
fill 265 171 629 265 173 629 minecraft:gray_concrete
fill 265 171 632 265 172 632 minecraft:waxed_copper_block
fill 265 171 633 268 171 633 minecraft:gray_concrete
fill 265 171 635 266 171 636 minecraft:gray_concrete
fill 266 171 620 267 173 620 minecraft:gray_concrete
fill 266 171 623 270 172 623 minecraft:waxed_copper_block
fill 266 171 629 270 172 629 minecraft:waxed_copper_block
fill 266 171 632 276 171 632 minecraft:gray_concrete
setblock 267 171 615 minecraft:gray_concrete
fill 267 171 624 267 173 628 minecraft:gray_concrete
setblock 267 171 635 minecraft:gray_concrete
fill 268 171 624 270 172 625 minecraft:waxed_copper_block
fill 268 171 626 268 173 626 minecraft:gray_concrete
fill 268 171 627 270 172 628 minecraft:waxed_copper_block
fill 268 171 645 273 171 645 minecraft:gray_concrete
fill 269 171 621 276 171 621 minecraft:gray_concrete
fill 269 171 626 271 172 626 minecraft:waxed_copper_block
fill 269 171 631 275 171 631 minecraft:gray_concrete
fill 270 171 612 275 171 617 minecraft:gray_concrete
fill 270 171 622 275 171 622 minecraft:gray_concrete
fill 270 171 630 275 171 630 minecraft:gray_concrete
fill 270 171 633 275 171 638 minecraft:gray_concrete
fill 271 171 605 276 171 605 minecraft:gray_concrete
fill 271 171 623 275 171 625 minecraft:gray_concrete
fill 271 171 627 276 171 629 minecraft:gray_concrete
fill 272 171 620 276 171 620 minecraft:gray_concrete
fill 272 171 626 276 171 626 minecraft:gray_concrete
fill 276 171 608 276 171 609 minecraft:gray_concrete
fill 276 171 612 276 171 613 minecraft:gray_concrete
fill 276 171 616 276 171 617 minecraft:gray_concrete
fill 276 171 624 276 171 625 minecraft:gray_concrete
fill 276 171 633 276 171 637 minecraft:gray_concrete
setblock 276 171 645 minecraft:gray_concrete
fill 235 172 609 235 177 609 minecraft:sea_lantern
fill 235 172 617 235 177 617 minecraft:sea_lantern
fill 235 172 625 235 177 625 minecraft:sea_lantern
fill 235 172 633 235 177 633 minecraft:sea_lantern
fill 235 172 641 235 177 641 minecraft:sea_lantern
fill 236 172 642 238 172 642 minecraft:iron_block
fill 238 172 646 238 177 646 minecraft:sea_lantern
fill 242 172 604 242 177 604 minecraft:sea_lantern
fill 242 172 611 242 172 639 minecraft:gold_block
fill 243 172 611 270 172 611 minecraft:gold_block
fill 243 172 626 243 172 629 minecraft:gray_concrete
fill 243 172 639 270 172 639 minecraft:gold_block
fill 244 172 619 244 172 621 minecraft:gray_concrete
fill 244 172 631 249 172 631 minecraft:gray_concrete
fill 245 172 617 247 172 617 minecraft:gray_concrete
fill 245 172 621 247 172 622 minecraft:gray_concrete
fill 245 172 626 247 172 626 minecraft:gray_concrete
fill 245 172 630 248 172 630 minecraft:gray_concrete
fill 245 172 632 250 172 633 minecraft:gray_concrete
fill 246 172 616 247 172 616 minecraft:gray_concrete
fill 246 172 623 247 172 625 minecraft:gray_concrete
fill 246 172 627 247 172 629 minecraft:gray_concrete
fill 246 172 634 247 172 634 minecraft:gray_concrete
fill 246 172 646 246 177 646 minecraft:sea_lantern
setblock 247 172 615 minecraft:gray_concrete
setblock 247 172 635 minecraft:gray_concrete
fill 248 172 619 248 172 621 minecraft:gray_concrete
fill 248 172 622 248 172 628 minecraft:black_concrete
setblock 248 172 629 minecraft:gray_concrete
fill 249 172 618 249 172 620 minecraft:gray_concrete
setblock 249 172 621 minecraft:black_concrete
fill 249 172 629 249 172 630 minecraft:black_concrete
fill 249 172 634 266 172 634 minecraft:gray_concrete
fill 250 172 604 250 177 604 minecraft:sea_lantern
fill 250 172 613 262 172 613 minecraft:gray_concrete
fill 250 172 617 251 172 618 minecraft:gray_concrete
fill 250 172 619 250 172 620 minecraft:black_concrete
setblock 250 172 631 minecraft:black_concrete
fill 250 172 637 252 172 637 minecraft:gray_concrete
fill 250 172 642 250 173 644 minecraft:iron_block
setblock 251 172 619 minecraft:black_concrete
fill 251 172 632 252 172 632 minecraft:black_concrete
fill 251 172 633 252 172 633 minecraft:gray_concrete
fill 252 172 612 260 172 612 minecraft:gray_concrete
setblock 252 172 617 minecraft:gray_concrete
setblock 252 172 618 minecraft:black_concrete
setblock 252 172 638 minecraft:gray_concrete
fill 253 172 617 259 172 617 minecraft:black_concrete
fill 253 172 633 259 172 633 minecraft:black_concrete
fill 254 172 646 254 177 646 minecraft:sea_lantern
fill 258 172 604 258 177 604 minecraft:sea_lantern
fill 258 172 637 260 172 638 minecraft:gray_concrete
fill 260 172 614 264 172 615 minecraft:gray_concrete
fill 260 172 617 267 172 617 minecraft:gray_concrete
setblock 260 172 618 minecraft:black_concrete
fill 260 172 632 261 172 632 minecraft:black_concrete
fill 260 172 633 267 172 633 minecraft:gray_concrete
fill 261 172 618 267 172 618 minecraft:gray_concrete
fill 261 172 619 262 172 619 minecraft:black_concrete
fill 261 172 637 262 172 637 minecraft:gray_concrete
setblock 262 172 620 minecraft:black_concrete
fill 262 172 632 264 172 632 minecraft:gray_concrete
fill 262 172 646 262 177 646 minecraft:sea_lantern
fill 263 172 616 266 172 616 minecraft:gray_concrete
fill 263 172 619 264 172 620 minecraft:gray_concrete
fill 264 172 624 264 172 628 minecraft:black_concrete
setblock 265 172 615 minecraft:gray_concrete
fill 265 172 619 268 172 619 minecraft:gray_concrete
fill 265 172 624 266 172 628 minecraft:gray_concrete
setblock 265 172 635 minecraft:gray_concrete
fill 266 172 604 266 177 604 minecraft:sea_lantern
fill 266 172 632 267 172 632 minecraft:gray_concrete
setblock 268 172 620 minecraft:gray_concrete
setblock 269 172 621 minecraft:gray_concrete
fill 270 172 612 270 172 622 minecraft:gold_block
fill 270 172 630 270 172 638 minecraft:gold_block
fill 270 172 646 270 177 646 minecraft:sea_lantern
fill 274 172 604 274 177 604 minecraft:sea_lantern
fill 277 172 609 277 177 609 minecraft:sea_lantern
fill 277 172 617 277 177 617 minecraft:sea_lantern
fill 277 172 625 277 177 625 minecraft:sea_lantern
fill 277 172 633 277 177 633 minecraft:sea_lantern
fill 277 172 641 277 177 641 minecraft:sea_lantern
fill 244 173 623 244 173 624 minecraft:gray_concrete
fill 245 173 620 246 173 622 minecraft:gray_concrete
fill 245 173 626 246 173 626 minecraft:gray_concrete
fill 245 173 630 247 173 630 minecraft:gray_concrete
fill 246 173 618 247 173 619 minecraft:gray_concrete
fill 246 173 623 246 173 625 minecraft:gray_concrete
fill 246 173 627 246 173 629 minecraft:gray_concrete
fill 246 173 631 248 173 632 minecraft:gray_concrete
setblock 247 173 617 minecraft:gray_concrete
fill 247 173 620 247 173 621 minecraft:gray_concrete
fill 247 173 622 247 173 628 minecraft:black_concrete
setblock 247 173 629 minecraft:gray_concrete
fill 247 173 633 250 173 633 minecraft:gray_concrete
fill 248 173 619 248 173 620 minecraft:gray_concrete
setblock 248 173 621 minecraft:black_concrete
fill 248 173 629 248 173 630 minecraft:black_concrete
fill 249 173 615 252 173 615 minecraft:gray_concrete
setblock 249 173 618 minecraft:gray_concrete
fill 249 173 619 249 173 620 minecraft:black_concrete
setblock 249 173 631 minecraft:black_concrete
setblock 249 173 632 minecraft:gray_concrete
fill 249 173 634 252 173 635 minecraft:gray_concrete
fill 250 173 617 251 173 617 minecraft:gray_concrete
fill 250 173 618 251 173 618 minecraft:black_concrete
setblock 250 173 632 minecraft:black_concrete
fill 251 173 614 252 173 614 minecraft:gray_concrete
fill 251 173 633 252 173 633 minecraft:black_concrete
setblock 251 173 636 minecraft:gray_concrete
fill 252 173 616 253 173 616 minecraft:gray_concrete
fill 252 173 617 253 173 617 minecraft:black_concrete
fill 253 173 634 259 173 634 minecraft:black_concrete
fill 253 173 635 263 173 635 minecraft:gray_concrete
fill 254 173 613 258 173 613 minecraft:gray_concrete
fill 254 173 616 258 173 616 minecraft:black_concrete
fill 254 173 637 255 173 637 minecraft:gray_concrete
setblock 258 173 637 minecraft:gray_concrete
fill 259 173 616 260 173 616 minecraft:gray_concrete
fill 259 173 617 260 173 617 minecraft:black_concrete
fill 260 173 614 261 173 615 minecraft:gray_concrete
fill 260 173 633 261 173 633 minecraft:black_concrete
fill 260 173 634 264 173 634 minecraft:gray_concrete
fill 261 173 617 265 173 617 minecraft:gray_concrete
fill 261 173 618 262 173 618 minecraft:black_concrete
setblock 261 173 636 minecraft:gray_concrete
fill 262 173 615 263 173 615 minecraft:gray_concrete
setblock 262 173 632 minecraft:black_concrete
fill 262 173 633 265 173 633 minecraft:gray_concrete
fill 263 173 616 264 173 616 minecraft:gray_concrete
fill 263 173 618 266 173 618 minecraft:gray_concrete
fill 263 173 619 263 173 620 minecraft:black_concrete
setblock 263 173 631 minecraft:black_concrete
fill 263 173 632 266 173 632 minecraft:gray_concrete
fill 264 173 619 265 173 620 minecraft:gray_concrete
setblock 264 173 621 minecraft:black_concrete
fill 264 173 629 264 173 630 minecraft:black_concrete
fill 264 173 631 266 173 631 minecraft:gray_concrete
fill 265 173 621 267 173 621 minecraft:gray_concrete
fill 265 173 622 265 173 628 minecraft:black_concrete
fill 265 173 630 267 173 630 minecraft:gray_concrete
setblock 266 173 619 minecraft:gray_concrete
fill 266 173 622 266 173 629 minecraft:gray_concrete
fill 267 173 622 267 173 623 minecraft:gray_concrete
setblock 267 173 629 minecraft:gray_concrete
fill 268 173 623 268 173 625 minecraft:gray_concrete
setblock 268 173 627 minecraft:gray_concrete
fill 235 178 609 235 185 609 minecraft:light_gray_concrete
fill 235 178 617 235 185 617 minecraft:light_gray_concrete
fill 235 178 625 235 185 625 minecraft:light_gray_concrete
fill 235 178 633 235 185 633 minecraft:light_gray_concrete
fill 235 178 641 235 185 641 minecraft:light_gray_concrete
fill 238 178 646 238 185 646 minecraft:light_gray_concrete
fill 242 178 604 242 185 604 minecraft:light_gray_concrete
fill 246 178 646 246 185 646 minecraft:light_gray_concrete
fill 250 178 604 250 185 604 minecraft:light_gray_concrete
fill 254 178 646 254 185 646 minecraft:light_gray_concrete
fill 258 178 604 258 185 604 minecraft:light_gray_concrete
fill 262 178 646 262 185 646 minecraft:light_gray_concrete
fill 266 178 604 266 185 604 minecraft:light_gray_concrete
fill 270 178 646 270 185 646 minecraft:light_gray_concrete
fill 274 178 604 274 185 604 minecraft:light_gray_concrete
fill 277 178 609 277 185 609 minecraft:light_gray_concrete
fill 277 178 617 277 185 617 minecraft:light_gray_concrete
fill 277 178 625 277 185 625 minecraft:light_gray_concrete
fill 277 178 633 277 185 633 minecraft:light_gray_concrete
fill 277 178 641 277 185 641 minecraft:light_gray_concrete
setblock 238 179 607 minecraft:light[level=14]
setblock 238 179 615 minecraft:light[level=14]
setblock 238 179 623 minecraft:light[level=14]
setblock 238 179 631 minecraft:light[level=14]
setblock 238 179 639 minecraft:light[level=14]
setblock 246 179 607 minecraft:light[level=14]
setblock 246 179 615 minecraft:light[level=14]
setblock 246 179 623 minecraft:light[level=14]
setblock 246 179 631 minecraft:light[level=14]
setblock 246 179 639 minecraft:light[level=14]
setblock 254 179 607 minecraft:light[level=14]
setblock 254 179 615 minecraft:light[level=14]
setblock 254 179 623 minecraft:light[level=14]
setblock 254 179 631 minecraft:light[level=14]
setblock 254 179 639 minecraft:light[level=14]
setblock 262 179 607 minecraft:light[level=14]
setblock 262 179 615 minecraft:light[level=14]
setblock 262 179 623 minecraft:light[level=14]
setblock 262 179 631 minecraft:light[level=14]
setblock 262 179 639 minecraft:light[level=14]
setblock 270 179 607 minecraft:light[level=14]
setblock 270 179 615 minecraft:light[level=14]
setblock 270 179 623 minecraft:light[level=14]
setblock 270 179 631 minecraft:light[level=14]
setblock 270 179 639 minecraft:light[level=14]
fill 236 182 605 236 183 610 minecraft:gray_concrete
fill 236 182 613 237 182 618 minecraft:gray_concrete
fill 236 182 621 237 182 626 minecraft:gray_concrete
fill 236 182 629 237 182 634 minecraft:gray_concrete
fill 236 182 637 237 182 642 minecraft:gray_concrete
fill 236 182 645 241 183 645 minecraft:gray_concrete
fill 237 182 606 237 182 612 minecraft:gray_concrete
fill 237 182 619 237 182 620 minecraft:gray_concrete
fill 237 182 627 237 182 628 minecraft:gray_concrete
fill 237 182 635 237 182 636 minecraft:gray_concrete
fill 237 182 643 237 182 644 minecraft:gray_concrete
fill 238 182 606 275 182 606 minecraft:gray_concrete
fill 238 182 644 276 182 644 minecraft:gray_concrete
fill 239 182 605 244 183 605 minecraft:gray_concrete
fill 244 182 645 249 183 645 minecraft:gray_concrete
fill 247 182 605 252 183 605 minecraft:gray_concrete
fill 252 182 645 257 183 645 minecraft:gray_concrete
fill 255 182 605 260 183 605 minecraft:gray_concrete
fill 260 182 645 265 183 645 minecraft:gray_concrete
fill 263 182 605 268 183 605 minecraft:gray_concrete
fill 268 182 645 273 183 645 minecraft:gray_concrete
fill 271 182 605 276 183 605 minecraft:gray_concrete
fill 275 182 607 275 182 643 minecraft:gray_concrete
fill 276 182 608 276 183 613 minecraft:gray_concrete
fill 276 182 616 276 183 621 minecraft:gray_concrete
fill 276 182 624 276 183 629 minecraft:gray_concrete
fill 276 182 632 276 183 637 minecraft:gray_concrete
fill 276 182 640 276 183 643 minecraft:gray_concrete
fill 276 182 645 276 183 645 minecraft:gray_concrete
fill 236 183 613 236 183 618 minecraft:gray_concrete
fill 236 183 621 236 183 626 minecraft:gray_concrete
fill 236 183 629 236 183 634 minecraft:gray_concrete
fill 236 183 637 236 183 642 minecraft:gray_concrete
setblock 276 183 644 minecraft:gray_concrete
fill 235 186 609 235 191 609 minecraft:sea_lantern
fill 235 186 617 235 191 617 minecraft:sea_lantern
fill 235 186 625 235 191 625 minecraft:sea_lantern
fill 235 186 633 235 191 633 minecraft:sea_lantern
fill 235 186 641 235 191 641 minecraft:sea_lantern
fill 238 186 646 238 191 646 minecraft:sea_lantern
fill 242 186 604 242 191 604 minecraft:sea_lantern
fill 246 186 646 246 191 646 minecraft:sea_lantern
fill 250 186 604 250 191 604 minecraft:sea_lantern
fill 254 186 646 254 191 646 minecraft:sea_lantern
fill 258 186 604 258 191 604 minecraft:sea_lantern
fill 262 186 646 262 191 646 minecraft:sea_lantern
fill 266 186 604 266 191 604 minecraft:sea_lantern
fill 270 186 646 270 191 646 minecraft:sea_lantern
fill 274 186 604 274 191 604 minecraft:sea_lantern
fill 277 186 609 277 191 609 minecraft:sea_lantern
fill 277 186 617 277 191 617 minecraft:sea_lantern
fill 277 186 625 277 191 625 minecraft:sea_lantern
fill 277 186 633 277 191 633 minecraft:sea_lantern
fill 277 186 641 277 191 641 minecraft:sea_lantern
setblock 238 187 607 minecraft:light[level=14]
setblock 238 187 615 minecraft:light[level=14]
setblock 238 187 623 minecraft:light[level=14]
setblock 238 187 631 minecraft:light[level=14]
setblock 238 187 639 minecraft:light[level=14]
setblock 246 187 607 minecraft:light[level=14]
setblock 246 187 615 minecraft:light[level=14]
setblock 246 187 623 minecraft:light[level=14]
setblock 246 187 631 minecraft:light[level=14]
setblock 246 187 639 minecraft:light[level=14]
setblock 254 187 607 minecraft:light[level=14]
setblock 254 187 615 minecraft:light[level=14]
setblock 254 187 623 minecraft:light[level=14]
setblock 254 187 631 minecraft:light[level=14]
setblock 254 187 639 minecraft:light[level=14]
setblock 262 187 607 minecraft:light[level=14]
setblock 262 187 615 minecraft:light[level=14]
setblock 262 187 623 minecraft:light[level=14]
setblock 262 187 631 minecraft:light[level=14]
setblock 262 187 639 minecraft:light[level=14]
setblock 270 187 607 minecraft:light[level=14]
setblock 270 187 615 minecraft:light[level=14]
setblock 270 187 623 minecraft:light[level=14]
setblock 270 187 631 minecraft:light[level=14]
setblock 270 187 639 minecraft:light[level=14]
fill 236 190 634 238 191 634 minecraft:iron_block
fill 235 192 609 235 199 609 minecraft:light_gray_concrete
fill 235 192 617 235 199 617 minecraft:light_gray_concrete
fill 235 192 625 235 199 625 minecraft:light_gray_concrete
fill 235 192 633 235 199 633 minecraft:light_gray_concrete
fill 235 192 641 235 199 641 minecraft:light_gray_concrete
fill 238 192 646 238 199 646 minecraft:light_gray_concrete
fill 242 192 604 242 199 604 minecraft:light_gray_concrete
fill 246 192 646 246 199 646 minecraft:light_gray_concrete
fill 250 192 604 250 199 604 minecraft:light_gray_concrete
fill 254 192 646 254 199 646 minecraft:light_gray_concrete
fill 258 192 604 258 199 604 minecraft:light_gray_concrete
fill 262 192 646 262 199 646 minecraft:light_gray_concrete
fill 266 192 604 266 199 604 minecraft:light_gray_concrete
fill 270 192 646 270 199 646 minecraft:light_gray_concrete
fill 274 192 604 274 199 604 minecraft:light_gray_concrete
fill 277 192 609 277 199 609 minecraft:light_gray_concrete
fill 277 192 617 277 199 617 minecraft:light_gray_concrete
fill 277 192 625 277 199 625 minecraft:light_gray_concrete
fill 277 192 633 277 199 633 minecraft:light_gray_concrete
fill 277 192 641 277 199 641 minecraft:light_gray_concrete
setblock 238 195 607 minecraft:light[level=14]
setblock 238 195 615 minecraft:light[level=14]
setblock 238 195 623 minecraft:light[level=14]
setblock 238 195 631 minecraft:light[level=14]
setblock 238 195 639 minecraft:light[level=14]
setblock 246 195 607 minecraft:light[level=14]
setblock 246 195 615 minecraft:light[level=14]
setblock 246 195 623 minecraft:light[level=14]
setblock 246 195 631 minecraft:light[level=14]
setblock 246 195 639 minecraft:light[level=14]
setblock 254 195 607 minecraft:light[level=14]
setblock 254 195 615 minecraft:light[level=14]
setblock 254 195 623 minecraft:light[level=14]
setblock 254 195 631 minecraft:light[level=14]
setblock 254 195 639 minecraft:light[level=14]
setblock 262 195 607 minecraft:light[level=14]
setblock 262 195 615 minecraft:light[level=14]
setblock 262 195 623 minecraft:light[level=14]
setblock 262 195 631 minecraft:light[level=14]
setblock 262 195 639 minecraft:light[level=14]
setblock 270 195 607 minecraft:light[level=14]
setblock 270 195 615 minecraft:light[level=14]
setblock 270 195 623 minecraft:light[level=14]
setblock 270 195 631 minecraft:light[level=14]
setblock 270 195 639 minecraft:light[level=14]
fill 236 196 605 236 197 610 minecraft:gray_concrete
fill 236 196 613 237 196 618 minecraft:gray_concrete
fill 236 196 621 237 196 626 minecraft:gray_concrete
fill 236 196 629 237 196 634 minecraft:gray_concrete
fill 236 196 637 237 196 642 minecraft:gray_concrete
fill 236 196 645 241 197 645 minecraft:gray_concrete
fill 237 196 606 237 196 612 minecraft:gray_concrete
fill 237 196 619 237 196 620 minecraft:gray_concrete
fill 237 196 627 237 196 628 minecraft:gray_concrete
fill 237 196 635 237 196 636 minecraft:gray_concrete
fill 237 196 643 237 196 644 minecraft:gray_concrete
fill 238 196 606 275 196 606 minecraft:gray_concrete
fill 238 196 644 276 196 644 minecraft:gray_concrete
fill 239 196 605 244 197 605 minecraft:gray_concrete
fill 244 196 645 249 197 645 minecraft:gray_concrete
fill 247 196 605 252 197 605 minecraft:gray_concrete
fill 252 196 645 257 197 645 minecraft:gray_concrete
fill 255 196 605 260 197 605 minecraft:gray_concrete
fill 260 196 645 265 197 645 minecraft:gray_concrete
fill 263 196 605 268 197 605 minecraft:gray_concrete
fill 268 196 645 273 197 645 minecraft:gray_concrete
fill 271 196 605 276 197 605 minecraft:gray_concrete
fill 275 196 607 275 196 643 minecraft:gray_concrete
fill 276 196 608 276 197 613 minecraft:gray_concrete
fill 276 196 616 276 197 621 minecraft:gray_concrete
fill 276 196 624 276 197 629 minecraft:gray_concrete
fill 276 196 632 276 197 637 minecraft:gray_concrete
fill 276 196 640 276 197 643 minecraft:gray_concrete
fill 276 196 645 276 197 645 minecraft:gray_concrete
fill 236 197 613 236 197 618 minecraft:gray_concrete
fill 236 197 621 236 197 626 minecraft:gray_concrete
fill 236 197 629 236 197 634 minecraft:gray_concrete
fill 236 197 637 236 197 642 minecraft:gray_concrete
setblock 276 197 644 minecraft:gray_concrete
fill 235 200 609 235 205 609 minecraft:sea_lantern
fill 235 200 617 235 205 617 minecraft:sea_lantern
fill 235 200 625 235 205 625 minecraft:sea_lantern
fill 235 200 633 235 205 633 minecraft:sea_lantern
fill 235 200 641 235 205 641 minecraft:sea_lantern
fill 238 200 646 238 205 646 minecraft:sea_lantern
fill 242 200 604 242 205 604 minecraft:sea_lantern
fill 246 200 646 246 205 646 minecraft:sea_lantern
fill 250 200 604 250 205 604 minecraft:sea_lantern
fill 254 200 646 254 205 646 minecraft:sea_lantern
fill 258 200 604 258 205 604 minecraft:sea_lantern
fill 262 200 646 262 205 646 minecraft:sea_lantern
fill 266 200 604 266 205 604 minecraft:sea_lantern
fill 270 200 646 270 205 646 minecraft:sea_lantern
fill 274 200 604 274 205 604 minecraft:sea_lantern
fill 277 200 609 277 205 609 minecraft:sea_lantern
fill 277 200 617 277 205 617 minecraft:sea_lantern
fill 277 200 625 277 205 625 minecraft:sea_lantern
fill 277 200 633 277 205 633 minecraft:sea_lantern
fill 277 200 641 277 205 641 minecraft:sea_lantern
setblock 238 203 607 minecraft:light[level=14]
setblock 238 203 615 minecraft:light[level=14]
setblock 238 203 623 minecraft:light[level=14]
setblock 238 203 631 minecraft:light[level=14]
setblock 238 203 639 minecraft:light[level=14]
setblock 246 203 607 minecraft:light[level=14]
setblock 246 203 615 minecraft:light[level=14]
setblock 246 203 623 minecraft:light[level=14]
setblock 246 203 631 minecraft:light[level=14]
setblock 246 203 639 minecraft:light[level=14]
setblock 254 203 607 minecraft:light[level=14]
setblock 254 203 615 minecraft:light[level=14]
setblock 254 203 623 minecraft:light[level=14]
setblock 254 203 631 minecraft:light[level=14]
setblock 254 203 639 minecraft:light[level=14]
setblock 262 203 607 minecraft:light[level=14]
setblock 262 203 615 minecraft:light[level=14]
setblock 262 203 623 minecraft:light[level=14]
setblock 262 203 631 minecraft:light[level=14]
setblock 262 203 639 minecraft:light[level=14]
setblock 270 203 607 minecraft:light[level=14]
setblock 270 203 615 minecraft:light[level=14]
setblock 270 203 623 minecraft:light[level=14]
setblock 270 203 631 minecraft:light[level=14]
setblock 270 203 639 minecraft:light[level=14]
fill 235 206 609 235 213 609 minecraft:light_gray_concrete
fill 235 206 617 235 213 617 minecraft:light_gray_concrete
fill 235 206 625 235 213 625 minecraft:light_gray_concrete
fill 235 206 633 235 213 633 minecraft:light_gray_concrete
fill 235 206 641 235 213 641 minecraft:light_gray_concrete
fill 238 206 646 238 213 646 minecraft:light_gray_concrete
fill 242 206 604 242 213 604 minecraft:light_gray_concrete
fill 246 206 646 246 213 646 minecraft:light_gray_concrete
fill 250 206 604 250 213 604 minecraft:light_gray_concrete
fill 254 206 646 254 213 646 minecraft:light_gray_concrete
fill 258 206 604 258 213 604 minecraft:light_gray_concrete
fill 262 206 646 262 213 646 minecraft:light_gray_concrete
fill 266 206 604 266 213 604 minecraft:light_gray_concrete
fill 270 206 646 270 213 646 minecraft:light_gray_concrete
fill 274 206 604 274 213 604 minecraft:light_gray_concrete
fill 277 206 609 277 213 609 minecraft:light_gray_concrete
fill 277 206 617 277 213 617 minecraft:light_gray_concrete
fill 277 206 625 277 213 625 minecraft:light_gray_concrete
fill 277 206 633 277 213 633 minecraft:light_gray_concrete
fill 277 206 641 277 213 641 minecraft:light_gray_concrete
fill 254 207 609 254 208 609 minecraft:white_concrete
fill 236 210 605 236 211 610 minecraft:gray_concrete
fill 236 210 613 237 210 618 minecraft:gray_concrete
fill 236 210 621 237 210 626 minecraft:gray_concrete
fill 236 210 629 237 210 634 minecraft:gray_concrete
fill 236 210 637 237 210 642 minecraft:gray_concrete
fill 236 210 645 241 211 645 minecraft:gray_concrete
fill 237 210 606 237 210 612 minecraft:gray_concrete
fill 237 210 619 237 210 620 minecraft:gray_concrete
fill 237 210 627 237 210 628 minecraft:gray_concrete
fill 237 210 635 237 210 636 minecraft:gray_concrete
fill 237 210 643 237 210 644 minecraft:gray_concrete
fill 238 210 606 275 210 606 minecraft:gray_concrete
fill 238 210 644 276 210 644 minecraft:gray_concrete
fill 239 210 605 244 211 605 minecraft:gray_concrete
fill 244 210 645 249 211 645 minecraft:gray_concrete
fill 247 210 605 252 211 605 minecraft:gray_concrete
fill 252 210 645 257 211 645 minecraft:gray_concrete
fill 255 210 605 260 211 605 minecraft:gray_concrete
fill 260 210 645 265 211 645 minecraft:gray_concrete
fill 263 210 605 268 211 605 minecraft:gray_concrete
fill 268 210 631 268 211 631 minecraft:white_concrete
fill 268 210 645 273 211 645 minecraft:gray_concrete
fill 271 210 605 276 211 605 minecraft:gray_concrete
fill 275 210 607 275 210 643 minecraft:gray_concrete
fill 276 210 608 276 211 613 minecraft:gray_concrete
fill 276 210 616 276 211 621 minecraft:gray_concrete
fill 276 210 624 276 211 629 minecraft:gray_concrete
fill 276 210 632 276 211 637 minecraft:gray_concrete
fill 276 210 640 276 211 643 minecraft:gray_concrete
fill 276 210 645 276 211 645 minecraft:gray_concrete
fill 236 211 613 236 211 618 minecraft:gray_concrete
fill 236 211 621 236 211 626 minecraft:gray_concrete
fill 236 211 629 236 211 634 minecraft:gray_concrete
fill 236 211 637 236 211 642 minecraft:gray_concrete
setblock 238 211 607 minecraft:light[level=14]
setblock 238 211 615 minecraft:light[level=14]
setblock 238 211 623 minecraft:light[level=14]
setblock 238 211 631 minecraft:light[level=14]
setblock 238 211 639 minecraft:light[level=14]
setblock 246 211 607 minecraft:light[level=14]
setblock 246 211 615 minecraft:light[level=14]
setblock 246 211 623 minecraft:light[level=14]
setblock 246 211 631 minecraft:light[level=14]
setblock 246 211 639 minecraft:light[level=14]
setblock 254 211 607 minecraft:light[level=14]
setblock 254 211 615 minecraft:light[level=14]
setblock 254 211 623 minecraft:light[level=14]
setblock 254 211 631 minecraft:light[level=14]
setblock 254 211 639 minecraft:light[level=14]
setblock 262 211 607 minecraft:light[level=14]
setblock 262 211 615 minecraft:light[level=14]
setblock 262 211 623 minecraft:light[level=14]
setblock 262 211 631 minecraft:light[level=14]
setblock 262 211 639 minecraft:light[level=14]
setblock 270 211 607 minecraft:light[level=14]
setblock 270 211 615 minecraft:light[level=14]
setblock 270 211 623 minecraft:light[level=14]
setblock 270 211 631 minecraft:light[level=14]
setblock 270 211 639 minecraft:light[level=14]
setblock 276 211 644 minecraft:gray_concrete
fill 235 214 609 235 219 609 minecraft:sea_lantern
fill 235 214 617 235 219 617 minecraft:sea_lantern
fill 235 214 625 235 219 625 minecraft:sea_lantern
fill 235 214 633 235 219 633 minecraft:sea_lantern
fill 235 214 641 235 219 641 minecraft:sea_lantern
fill 238 214 646 238 219 646 minecraft:sea_lantern
fill 242 214 604 242 219 604 minecraft:sea_lantern
fill 246 214 646 246 219 646 minecraft:sea_lantern
fill 250 214 604 250 219 604 minecraft:sea_lantern
fill 254 214 646 254 219 646 minecraft:sea_lantern
fill 258 214 604 258 219 604 minecraft:sea_lantern
fill 262 214 646 262 219 646 minecraft:sea_lantern
fill 266 214 604 266 219 604 minecraft:sea_lantern
fill 270 214 646 270 219 646 minecraft:sea_lantern
fill 274 214 604 274 219 604 minecraft:sea_lantern
fill 277 214 609 277 219 609 minecraft:sea_lantern
fill 277 214 617 277 219 617 minecraft:sea_lantern
fill 277 214 625 277 219 625 minecraft:sea_lantern
fill 277 214 633 277 219 633 minecraft:sea_lantern
fill 277 214 641 277 219 641 minecraft:sea_lantern
fill 273 217 623 275 218 623 minecraft:iron_block
setblock 238 219 607 minecraft:light[level=14]
setblock 238 219 615 minecraft:light[level=14]
setblock 238 219 623 minecraft:light[level=14]
setblock 238 219 631 minecraft:light[level=14]
setblock 238 219 639 minecraft:light[level=14]
setblock 246 219 607 minecraft:light[level=14]
setblock 246 219 615 minecraft:light[level=14]
setblock 246 219 623 minecraft:light[level=14]
setblock 246 219 631 minecraft:light[level=14]
setblock 246 219 639 minecraft:light[level=14]
setblock 254 219 607 minecraft:light[level=14]
setblock 254 219 615 minecraft:light[level=14]
setblock 254 219 623 minecraft:light[level=14]
setblock 254 219 631 minecraft:light[level=14]
setblock 254 219 639 minecraft:light[level=14]
setblock 262 219 607 minecraft:light[level=14]
setblock 262 219 615 minecraft:light[level=14]
setblock 262 219 623 minecraft:light[level=14]
setblock 262 219 631 minecraft:light[level=14]
setblock 262 219 639 minecraft:light[level=14]
setblock 270 219 607 minecraft:light[level=14]
setblock 270 219 615 minecraft:light[level=14]
setblock 270 219 623 minecraft:light[level=14]
setblock 270 219 631 minecraft:light[level=14]
setblock 270 219 639 minecraft:light[level=14]
fill 235 220 609 235 229 609 minecraft:light_gray_concrete
fill 235 220 617 235 229 617 minecraft:light_gray_concrete
fill 235 220 625 235 226 625 minecraft:light_gray_concrete
fill 235 220 633 235 226 633 minecraft:light_gray_concrete
fill 235 220 641 235 226 641 minecraft:light_gray_concrete
fill 238 220 646 238 229 646 minecraft:light_gray_concrete
fill 242 220 604 242 229 604 minecraft:light_gray_concrete
fill 246 220 646 246 229 646 minecraft:light_gray_concrete
fill 250 220 604 250 229 604 minecraft:light_gray_concrete
fill 254 220 646 254 229 646 minecraft:light_gray_concrete
fill 258 220 604 258 229 604 minecraft:light_gray_concrete
fill 262 220 646 262 229 646 minecraft:light_gray_concrete
fill 266 220 604 266 227 604 minecraft:light_gray_concrete
fill 270 220 646 270 229 646 minecraft:light_gray_concrete
fill 274 220 604 274 229 604 minecraft:light_gray_concrete
fill 277 220 609 277 226 609 minecraft:light_gray_concrete
fill 277 220 617 277 225 617 minecraft:light_gray_concrete
fill 277 220 625 277 225 625 minecraft:light_gray_concrete
fill 277 220 633 277 230 633 minecraft:light_gray_concrete
fill 277 220 641 277 227 641 minecraft:light_gray_concrete
fill 236 224 605 236 224 610 minecraft:gray_concrete
fill 236 224 613 237 224 618 minecraft:gray_concrete
fill 236 224 621 237 224 626 minecraft:gray_concrete
fill 236 224 629 237 224 634 minecraft:gray_concrete
fill 236 224 637 237 224 642 minecraft:gray_concrete
fill 236 224 645 241 224 645 minecraft:gray_concrete
fill 237 224 606 237 224 612 minecraft:gray_concrete
fill 237 224 619 237 224 620 minecraft:gray_concrete
fill 237 224 627 237 224 628 minecraft:gray_concrete
fill 237 224 635 237 224 636 minecraft:gray_concrete
fill 237 224 643 237 224 644 minecraft:gray_concrete
fill 238 224 606 275 224 606 minecraft:gray_concrete
fill 238 224 644 276 224 644 minecraft:gray_concrete
fill 239 224 605 244 224 605 minecraft:gray_concrete
fill 244 224 645 249 224 645 minecraft:gray_concrete
fill 247 224 605 252 224 605 minecraft:gray_concrete
fill 252 224 645 257 224 645 minecraft:gray_concrete
fill 255 224 605 260 224 605 minecraft:gray_concrete
fill 260 224 645 265 224 645 minecraft:gray_concrete
fill 263 224 605 268 224 605 minecraft:gray_concrete
fill 268 224 645 273 224 645 minecraft:gray_concrete
fill 271 224 605 276 224 605 minecraft:gray_concrete
fill 275 224 607 275 224 643 minecraft:gray_concrete
fill 276 224 608 276 224 613 minecraft:gray_concrete
fill 276 224 616 276 224 621 minecraft:gray_concrete
fill 276 224 624 276 224 629 minecraft:gray_concrete
fill 276 224 632 276 224 637 minecraft:gray_concrete
fill 276 224 640 276 224 643 minecraft:gray_concrete
setblock 276 224 645 minecraft:gray_concrete
setblock 235 226 605 minecraft:white_concrete
fill 235 226 615 235 229 615 minecraft:light_gray_concrete
setblock 235 226 616 minecraft:white_concrete
fill 235 226 634 235 229 636 minecraft:light_gray_concrete
setblock 235 226 637 minecraft:white_concrete
setblock 235 226 638 minecraft:light_gray_concrete
fill 235 226 642 235 227 643 minecraft:light_gray_concrete
fill 235 226 644 235 227 644 minecraft:white_concrete
fill 235 226 645 235 229 646 minecraft:light_gray_concrete
setblock 239 226 604 minecraft:light_gray_concrete
setblock 239 226 646 minecraft:white_concrete
setblock 240 226 604 minecraft:white_concrete
fill 240 226 646 242 229 646 minecraft:light_gray_concrete
fill 241 226 604 241 227 604 minecraft:light_gray_concrete
fill 251 226 604 251 229 604 minecraft:light_gray_concrete
setblock 252 226 604 minecraft:white_concrete
fill 253 226 604 254 229 604 minecraft:light_gray_concrete
setblock 255 226 604 minecraft:white_concrete
fill 256 226 604 257 229 604 minecraft:light_gray_concrete
fill 267 226 604 267 227 604 minecraft:light_gray_concrete
setblock 268 226 604 minecraft:white_concrete
fill 269 226 604 270 227 604 minecraft:light_gray_concrete
setblock 271 226 604 minecraft:white_concrete
fill 272 226 604 273 226 604 minecraft:light_gray_concrete
setblock 277 226 605 minecraft:white_concrete
fill 277 226 608 277 227 608 minecraft:white_concrete
setblock 277 226 610 minecraft:white_concrete
setblock 277 226 611 minecraft:light_gray_concrete
fill 277 226 617 277 226 618 minecraft:white_concrete
setblock 277 226 625 minecraft:white_concrete
fill 277 226 628 277 226 629 minecraft:white_concrete
setblock 277 226 632 minecraft:white_concrete
fill 277 226 634 277 226 635 minecraft:white_concrete
setblock 235 227 604 minecraft:white_concrete
fill 235 227 605 235 229 605 minecraft:light_gray_concrete
setblock 235 227 606 minecraft:white_concrete
fill 235 227 607 235 229 607 minecraft:light_gray_concrete
fill 235 227 608 235 228 608 minecraft:white_concrete
fill 235 227 616 235 230 616 minecraft:light_gray_concrete
setblock 235 227 625 minecraft:white_concrete
fill 235 227 626 235 227 628 minecraft:light_gray_concrete
setblock 235 227 629 minecraft:white_concrete
fill 235 227 630 235 229 632 minecraft:light_gray_concrete
setblock 235 227 633 minecraft:white_concrete
fill 235 227 637 235 229 637 minecraft:light_gray_concrete
setblock 235 227 638 minecraft:white_concrete
setblock 235 227 641 minecraft:white_concrete
fill 236 227 604 237 229 604 minecraft:light_gray_concrete
fill 238 227 604 239 227 604 minecraft:white_concrete
setblock 238 227 607 minecraft:light[level=14]
setblock 238 227 615 minecraft:light[level=14]
setblock 238 227 623 minecraft:light[level=14]
setblock 238 227 631 minecraft:light[level=14]
setblock 238 227 639 minecraft:light[level=14]
fill 239 227 646 239 229 646 minecraft:light_gray_concrete
fill 240 227 604 240 229 604 minecraft:light_gray_concrete
setblock 246 227 607 minecraft:light[level=14]
setblock 246 227 615 minecraft:light[level=14]
setblock 246 227 623 minecraft:light[level=14]
setblock 246 227 631 minecraft:light[level=14]
setblock 246 227 639 minecraft:light[level=14]
fill 248 227 646 248 229 646 minecraft:light_gray_concrete
fill 249 227 646 249 228 646 minecraft:white_concrete
fill 252 227 604 252 229 604 minecraft:light_gray_concrete
setblock 254 227 607 minecraft:light[level=14]
setblock 254 227 615 minecraft:light[level=14]
setblock 254 227 623 minecraft:light[level=14]
setblock 254 227 631 minecraft:light[level=14]
setblock 254 227 639 minecraft:light[level=14]
fill 255 227 604 255 229 604 minecraft:light_gray_concrete
setblock 260 227 604 minecraft:light_gray_concrete
fill 261 227 604 262 227 604 minecraft:white_concrete
setblock 262 227 607 minecraft:light[level=14]
setblock 262 227 615 minecraft:light[level=14]
setblock 262 227 623 minecraft:light[level=14]
setblock 262 227 631 minecraft:light[level=14]
setblock 262 227 639 minecraft:light[level=14]
fill 263 227 604 265 229 604 minecraft:light_gray_concrete
fill 268 227 604 268 229 604 minecraft:light_gray_concrete
fill 268 227 646 268 228 646 minecraft:white_concrete
fill 269 227 646 269 229 646 minecraft:light_gray_concrete
setblock 270 227 607 minecraft:light[level=14]
setblock 270 227 615 minecraft:light[level=14]
setblock 270 227 623 minecraft:light[level=14]
setblock 270 227 631 minecraft:light[level=14]
setblock 270 227 639 minecraft:light[level=14]
fill 271 227 604 271 229 604 minecraft:light_gray_concrete
setblock 272 227 604 minecraft:white_concrete
fill 273 227 604 273 229 604 minecraft:light_gray_concrete
fill 277 227 605 277 229 605 minecraft:light_gray_concrete
setblock 277 227 609 minecraft:white_concrete
fill 277 227 610 277 229 610 minecraft:light_gray_concrete
setblock 277 227 611 minecraft:white_concrete
fill 277 227 617 277 227 622 minecraft:light_gray_concrete
setblock 277 227 623 minecraft:white_concrete
fill 277 227 625 277 229 625 minecraft:light_gray_concrete
fill 277 227 628 277 229 629 minecraft:light_gray_concrete
fill 277 227 632 277 229 632 minecraft:light_gray_concrete
fill 277 227 634 277 229 635 minecraft:light_gray_concrete
setblock 277 227 644 minecraft:white_concrete
fill 235 228 604 235 230 604 minecraft:light_gray_concrete
fill 235 228 606 235 229 606 minecraft:light_gray_concrete
fill 235 228 610 235 228 611 minecraft:white_concrete
fill 235 228 612 235 229 612 minecraft:light_gray_concrete
fill 235 228 625 235 230 626 minecraft:light_gray_concrete
setblock 235 228 627 minecraft:white_concrete
fill 235 228 628 235 229 629 minecraft:light_gray_concrete
fill 235 228 633 235 229 633 minecraft:light_gray_concrete
fill 235 228 638 235 229 638 minecraft:light_gray_concrete
fill 235 228 641 235 229 641 minecraft:light_gray_concrete
setblock 235 228 642 minecraft:white_concrete
fill 235 228 643 235 229 644 minecraft:light_gray_concrete
fill 238 228 604 239 229 604 minecraft:light_gray_concrete
setblock 241 228 604 minecraft:white_concrete
setblock 260 228 604 minecraft:white_concrete
fill 261 228 604 262 229 604 minecraft:light_gray_concrete
fill 266 228 604 267 228 604 minecraft:white_concrete
setblock 269 228 604 minecraft:white_concrete
fill 270 228 604 270 229 604 minecraft:light_gray_concrete
fill 272 228 604 272 229 604 minecraft:light_gray_concrete
setblock 274 228 646 minecraft:white_concrete
fill 277 228 608 277 229 609 minecraft:light_gray_concrete
fill 277 228 611 277 229 611 minecraft:light_gray_concrete
fill 277 228 613 277 228 614 minecraft:white_concrete
fill 277 228 615 277 229 618 minecraft:light_gray_concrete
setblock 277 228 619 minecraft:white_concrete
fill 277 228 620 277 229 623 minecraft:light_gray_concrete
setblock 277 228 641 minecraft:white_concrete
fill 277 228 644 277 229 644 minecraft:light_gray_concrete
setblock 235 229 608 minecraft:light_gray_concrete
fill 235 229 610 235 229 611 minecraft:light_gray_concrete
setblock 235 229 627 minecraft:light_gray_concrete
setblock 235 229 642 minecraft:light_gray_concrete
fill 241 229 604 241 230 604 minecraft:light_gray_concrete
setblock 249 229 646 minecraft:light_gray_concrete
fill 253 229 620 255 229 622 minecraft:redstone_block
fill 254 229 627 256 229 629 minecraft:redstone_block
setblock 260 229 604 minecraft:light_gray_concrete
fill 261 229 620 263 229 622 minecraft:redstone_block
fill 261 229 626 263 229 628 minecraft:redstone_block
fill 266 229 604 267 229 604 minecraft:light_gray_concrete
setblock 268 229 646 minecraft:light_gray_concrete
setblock 269 229 604 minecraft:light_gray_concrete
setblock 274 229 646 minecraft:light_gray_concrete
fill 277 229 613 277 229 614 minecraft:light_gray_concrete
setblock 277 229 619 minecraft:light_gray_concrete
setblock 277 229 641 minecraft:light_gray_concrete
fill 235 230 605 235 230 615 minecraft:white_concrete
setblock 235 230 617 minecraft:white_concrete
fill 235 230 618 276 230 618 minecraft:light_gray_concrete
fill 235 230 619 235 231 624 minecraft:white_concrete
fill 235 230 627 235 231 630 minecraft:white_concrete
fill 235 230 631 276 230 632 minecraft:light_gray_concrete
fill 235 230 633 235 230 644 minecraft:white_concrete
setblock 235 230 645 minecraft:light_gray_concrete
fill 235 230 646 236 231 646 minecraft:white_concrete
fill 236 230 604 240 231 604 minecraft:white_concrete
fill 236 230 615 276 231 617 minecraft:light_gray_concrete
fill 236 230 619 252 230 630 minecraft:light_gray_concrete
fill 236 230 633 276 231 635 minecraft:light_gray_concrete
fill 237 230 613 275 231 614 minecraft:light_gray_concrete
fill 237 230 636 275 231 637 minecraft:light_gray_concrete
fill 237 230 646 237 231 646 minecraft:light_gray_concrete
fill 238 230 612 274 231 612 minecraft:light_gray_concrete
fill 238 230 638 274 231 638 minecraft:light_gray_concrete
fill 238 230 646 241 241 646 minecraft:white_concrete
fill 239 230 611 273 231 611 minecraft:light_gray_concrete
fill 239 230 639 273 231 639 minecraft:light_gray_concrete
fill 240 230 609 272 231 610 minecraft:light_gray_concrete
fill 240 230 640 272 231 641 minecraft:light_gray_concrete
fill 242 230 604 242 241 604 minecraft:white_concrete
fill 242 230 608 270 231 608 minecraft:light_gray_concrete
fill 242 230 642 270 231 642 minecraft:light_gray_concrete
setblock 242 230 646 minecraft:light_gray_concrete
fill 243 230 607 269 231 607 minecraft:light_gray_concrete
fill 243 230 643 269 231 643 minecraft:light_gray_concrete
fill 243 230 646 277 230 646 minecraft:white_concrete
fill 244 230 604 277 231 604 minecraft:white_concrete
fill 244 230 606 268 231 606 minecraft:light_gray_concrete
fill 244 230 644 268 231 644 minecraft:light_gray_concrete
fill 246 230 605 266 231 605 minecraft:light_gray_concrete
fill 246 230 645 266 231 645 minecraft:light_gray_concrete
fill 253 230 619 276 230 619 minecraft:light_gray_concrete
fill 253 230 623 253 230 630 minecraft:light_gray_concrete
fill 254 230 623 255 230 626 minecraft:light_gray_concrete
fill 254 230 630 276 230 630 minecraft:light_gray_concrete
fill 256 230 620 256 230 622 minecraft:light_gray_concrete
fill 256 230 623 256 230 625 minecraft:gray_concrete
setblock 256 230 626 minecraft:light_gray_concrete
fill 257 230 620 260 230 621 minecraft:light_gray_concrete
fill 257 230 622 258 230 622 minecraft:gray_concrete
fill 257 230 626 259 230 626 minecraft:gray_concrete
fill 257 230 627 260 230 629 minecraft:light_gray_concrete
fill 259 230 622 260 230 622 minecraft:light_gray_concrete
fill 260 230 623 276 230 623 minecraft:light_gray_concrete
setblock 260 230 624 minecraft:gray_concrete
fill 260 230 625 260 230 626 minecraft:light_gray_concrete
fill 261 230 624 276 230 625 minecraft:light_gray_concrete
fill 261 230 629 277 230 629 minecraft:light_gray_concrete
fill 264 230 620 276 230 622 minecraft:light_gray_concrete
fill 264 230 626 276 230 628 minecraft:light_gray_concrete
fill 277 230 605 277 230 613 minecraft:white_concrete
fill 277 230 614 277 230 615 minecraft:light_gray_concrete
fill 277 230 616 277 230 628 minecraft:white_concrete
fill 277 230 630 277 307 632 minecraft:white_concrete
fill 277 230 634 277 307 635 minecraft:white_concrete
fill 277 230 637 277 230 642 minecraft:white_concrete
fill 277 230 644 277 230 645 minecraft:white_concrete
fill 235 231 604 235 231 606 minecraft:white_concrete
fill 235 231 607 242 231 607 minecraft:light_gray_concrete
fill 235 231 608 235 241 616 minecraft:white_concrete
setblock 235 231 617 minecraft:light_gray_concrete
fill 235 231 618 235 307 618 minecraft:white_concrete
fill 235 231 625 235 231 626 minecraft:white_concrete
fill 235 231 631 235 307 631 minecraft:white_concrete
fill 235 231 632 276 231 632 minecraft:light_gray_concrete
fill 235 231 633 235 241 633 minecraft:white_concrete
setblock 235 231 634 minecraft:light_gray_concrete
fill 235 231 635 235 307 636 minecraft:white_concrete
fill 235 231 637 236 231 637 minecraft:light_gray_concrete
fill 235 231 638 235 231 645 minecraft:white_concrete
fill 236 231 605 243 231 606 minecraft:light_gray_concrete
fill 236 231 608 236 231 614 minecraft:light_gray_concrete
fill 236 231 618 251 231 631 minecraft:light_gray_concrete
setblock 236 231 636 minecraft:light_gray_concrete
fill 236 231 638 237 231 645 minecraft:light_gray_concrete
fill 237 231 608 237 231 612 minecraft:light_gray_concrete
fill 238 231 608 238 231 611 minecraft:light_gray_concrete
fill 238 231 639 238 231 645 minecraft:light_gray_concrete
fill 239 231 608 239 231 610 minecraft:light_gray_concrete
fill 239 231 640 239 231 645 minecraft:light_gray_concrete
fill 240 231 608 241 231 608 minecraft:light_gray_concrete
fill 240 231 642 241 231 645 minecraft:light_gray_concrete
fill 241 231 604 241 307 604 minecraft:white_concrete
fill 242 231 643 242 231 645 minecraft:light_gray_concrete
fill 242 231 646 244 231 646 minecraft:white_concrete
setblock 243 231 604 minecraft:white_concrete
fill 243 231 644 243 231 645 minecraft:light_gray_concrete
fill 244 231 605 245 231 605 minecraft:light_gray_concrete
fill 244 231 645 245 231 645 minecraft:light_gray_concrete
setblock 245 231 646 minecraft:light_gray_concrete
fill 246 231 646 257 241 646 minecraft:white_concrete
fill 252 231 618 276 232 618 minecraft:light_gray_concrete
fill 252 231 619 252 231 623 minecraft:sea_lantern
fill 252 231 624 252 232 631 minecraft:light_gray_concrete
fill 253 231 619 256 231 619 minecraft:sea_lantern
fill 253 231 620 255 231 622 minecraft:light_gray_concrete
fill 253 231 623 256 231 623 minecraft:sea_lantern
fill 253 231 624 254 231 625 minecraft:light_gray_concrete
fill 253 231 626 253 231 630 minecraft:sea_lantern
fill 253 231 631 276 233 631 minecraft:light_gray_concrete
fill 254 231 626 260 231 626 minecraft:sea_lantern
fill 254 231 627 256 231 629 minecraft:light_gray_concrete
fill 254 231 630 257 231 630 minecraft:sea_lantern
fill 255 231 624 255 231 625 minecraft:gold_block
fill 256 231 620 256 231 622 minecraft:sea_lantern
fill 256 231 624 256 231 625 minecraft:sea_lantern
fill 257 231 619 259 231 620 minecraft:light_gray_concrete
fill 257 231 621 258 231 621 minecraft:gold_block
fill 257 231 622 260 231 622 minecraft:sea_lantern
fill 257 231 627 257 231 629 minecraft:sea_lantern
fill 258 231 627 259 231 627 minecraft:gold_block
fill 258 231 628 259 231 630 minecraft:light_gray_concrete
fill 258 231 646 260 231 646 minecraft:light_gray_concrete
setblock 259 231 621 minecraft:light_gray_concrete
fill 260 231 619 260 231 621 minecraft:sea_lantern
fill 260 231 623 260 231 625 minecraft:sea_lantern
fill 260 231 627 260 231 629 minecraft:sea_lantern
fill 260 231 630 276 233 630 minecraft:light_gray_concrete
fill 261 231 619 264 231 619 minecraft:sea_lantern
fill 261 231 620 263 231 622 minecraft:light_gray_concrete
fill 261 231 623 264 231 623 minecraft:sea_lantern
setblock 261 231 624 minecraft:gold_block
fill 261 231 625 264 231 625 minecraft:sea_lantern
fill 261 231 626 263 231 628 minecraft:light_gray_concrete
fill 261 231 629 264 231 629 minecraft:sea_lantern
fill 261 231 646 264 241 646 minecraft:white_concrete
fill 262 231 624 276 231 624 minecraft:light_gray_concrete
fill 264 231 620 264 231 622 minecraft:sea_lantern
fill 264 231 626 264 231 628 minecraft:sea_lantern
fill 265 231 619 276 231 623 minecraft:light_gray_concrete
fill 265 231 625 276 231 629 minecraft:light_gray_concrete
fill 265 231 646 265 232 646 minecraft:light_gray_concrete
fill 266 231 646 271 241 646 minecraft:white_concrete
fill 267 231 605 276 231 605 minecraft:light_gray_concrete
fill 267 231 645 276 231 645 minecraft:light_gray_concrete
fill 269 231 606 276 231 606 minecraft:light_gray_concrete
fill 269 231 644 277 231 644 minecraft:light_gray_concrete
fill 270 231 607 276 231 607 minecraft:light_gray_concrete
fill 270 231 643 276 231 643 minecraft:light_gray_concrete
fill 271 231 608 276 231 608 minecraft:light_gray_concrete
fill 271 231 642 276 231 642 minecraft:light_gray_concrete
setblock 272 231 646 minecraft:light_gray_concrete
fill 273 231 609 276 231 610 minecraft:light_gray_concrete
fill 273 231 640 276 231 641 minecraft:light_gray_concrete
fill 273 231 646 273 307 646 minecraft:white_concrete
fill 274 231 611 276 231 611 minecraft:light_gray_concrete
fill 274 231 639 276 231 639 minecraft:light_gray_concrete
setblock 274 231 646 minecraft:light_gray_concrete
fill 275 231 612 276 231 612 minecraft:light_gray_concrete
fill 275 231 638 277 231 638 minecraft:light_gray_concrete
fill 275 231 646 277 307 646 minecraft:white_concrete
fill 276 231 613 276 231 614 minecraft:light_gray_concrete
fill 276 231 636 276 231 637 minecraft:light_gray_concrete
fill 277 231 605 277 231 609 minecraft:white_concrete
setblock 277 231 610 minecraft:light_gray_concrete
fill 277 231 611 277 231 621 minecraft:white_concrete
setblock 277 231 622 minecraft:light_gray_concrete
fill 277 231 623 277 241 629 minecraft:white_concrete
fill 277 231 633 277 241 633 minecraft:white_concrete
fill 277 231 636 277 307 637 minecraft:white_concrete
fill 277 231 639 277 231 643 minecraft:white_concrete
fill 277 231 645 277 307 645 minecraft:white_concrete
setblock 235 232 604 minecraft:light_gray_concrete
fill 235 232 605 235 307 605 minecraft:white_concrete
setblock 235 232 606 minecraft:light_gray_concrete
fill 235 232 607 235 307 607 minecraft:white_concrete
fill 235 232 617 235 241 617 minecraft:white_concrete
fill 235 232 619 235 307 619 minecraft:white_concrete
fill 235 232 620 255 232 620 minecraft:light_gray_concrete
fill 235 232 621 235 307 622 minecraft:white_concrete
fill 235 232 623 243 232 625 minecraft:light_gray_concrete
fill 235 232 626 235 307 628 minecraft:white_concrete
fill 235 232 629 251 232 629 minecraft:light_gray_concrete
fill 235 232 630 235 307 630 minecraft:white_concrete
fill 235 232 632 235 307 632 minecraft:white_concrete
fill 235 232 634 235 307 634 minecraft:white_concrete
fill 235 232 637 235 307 639 minecraft:white_concrete
fill 235 232 640 235 232 641 minecraft:light_gray_concrete
fill 235 232 642 235 307 646 minecraft:white_concrete
fill 236 232 604 237 307 604 minecraft:white_concrete
fill 236 232 617 251 232 619 minecraft:light_gray_concrete
fill 236 232 621 253 232 622 minecraft:light_gray_concrete
fill 236 232 626 251 233 628 minecraft:light_gray_concrete
fill 236 232 630 247 232 633 minecraft:light_gray_concrete
setblock 236 232 646 minecraft:light_gray_concrete
fill 237 232 615 247 232 616 minecraft:light_gray_concrete
fill 237 232 634 247 232 635 minecraft:light_gray_concrete
fill 237 232 646 237 307 646 minecraft:white_concrete
setblock 238 232 604 minecraft:light_gray_concrete
fill 238 232 614 247 232 614 minecraft:light_gray_concrete
fill 238 232 636 257 232 636 minecraft:light_gray_concrete
fill 239 232 604 240 307 604 minecraft:white_concrete
fill 239 232 612 257 232 613 minecraft:light_gray_concrete
fill 239 232 637 256 232 638 minecraft:light_gray_concrete
fill 240 232 611 256 232 611 minecraft:light_gray_concrete
fill 240 232 639 272 232 639 minecraft:light_gray_concrete
fill 241 232 610 257 232 610 minecraft:light_gray_concrete
fill 241 232 640 271 232 640 minecraft:light_gray_concrete
fill 242 232 609 270 232 609 minecraft:light_gray_concrete
fill 242 232 641 270 232 641 minecraft:light_gray_concrete
fill 242 232 646 242 307 646 minecraft:white_concrete
setblock 243 232 604 minecraft:light_gray_concrete
fill 243 232 608 269 232 608 minecraft:light_gray_concrete
fill 243 232 642 269 232 642 minecraft:light_gray_concrete
setblock 243 232 646 minecraft:light_gray_concrete
fill 244 232 604 254 241 604 minecraft:white_concrete
fill 244 232 623 244 238 623 minecraft:light_gray_concrete
fill 244 232 624 246 246 624 minecraft:pink_concrete
fill 244 232 625 244 238 625 minecraft:light_gray_concrete
fill 244 232 646 245 307 646 minecraft:white_concrete
fill 245 232 607 267 232 607 minecraft:light_gray_concrete
fill 245 232 623 245 246 623 minecraft:pink_concrete
fill 245 232 625 245 246 625 minecraft:pink_concrete
fill 245 232 643 267 232 643 minecraft:light_gray_concrete
fill 246 232 606 266 232 606 minecraft:light_gray_concrete
fill 246 232 623 253 232 623 minecraft:light_gray_concrete
fill 246 232 625 251 233 625 minecraft:light_gray_concrete
fill 246 232 644 266 232 644 minecraft:light_gray_concrete
fill 247 232 624 251 233 624 minecraft:light_gray_concrete
fill 248 232 605 264 232 605 minecraft:light_gray_concrete
fill 248 232 614 249 246 615 minecraft:light_blue_concrete
fill 248 232 616 275 232 616 minecraft:light_gray_concrete
fill 248 232 630 251 234 632 minecraft:light_gray_concrete
fill 248 232 633 249 246 634 minecraft:light_blue_concrete
fill 248 232 635 275 232 635 minecraft:light_gray_concrete
fill 248 232 645 264 232 645 minecraft:light_gray_concrete
fill 250 232 614 266 236 615 minecraft:light_gray_concrete
fill 250 232 633 266 235 634 minecraft:light_gray_concrete
fill 252 232 617 276 232 617 minecraft:light_gray_concrete
fill 252 232 619 276 232 619 minecraft:light_gray_concrete
fill 252 232 632 276 232 632 minecraft:light_gray_concrete
fill 253 232 624 254 232 625 minecraft:gray_concrete
fill 253 232 626 253 232 630 minecraft:light_gray_concrete
setblock 254 232 621 minecraft:light_gray_concrete
fill 254 232 622 254 232 623 minecraft:gray_concrete
fill 254 232 626 254 232 627 minecraft:gray_concrete
fill 254 232 628 254 232 630 minecraft:light_gray_concrete
setblock 255 232 604 minecraft:light_gray_concrete
fill 255 232 621 255 232 622 minecraft:gray_concrete
fill 255 232 627 255 232 628 minecraft:gray_concrete
fill 255 232 629 259 232 630 minecraft:light_gray_concrete
fill 256 232 604 261 241 604 minecraft:white_concrete
fill 256 232 620 256 232 621 minecraft:gray_concrete
fill 256 232 628 260 232 628 minecraft:gray_concrete
fill 257 232 611 259 246 611 minecraft:pink_concrete
fill 257 232 620 259 232 620 minecraft:gray_concrete
fill 257 232 637 259 246 637 minecraft:pink_concrete
fill 257 232 638 257 239 638 minecraft:light_gray_concrete
fill 258 232 610 258 246 610 minecraft:pink_concrete
fill 258 232 612 258 246 612 minecraft:pink_concrete
fill 258 232 613 273 233 613 minecraft:light_gray_concrete
fill 258 232 636 258 246 636 minecraft:pink_concrete
fill 258 232 638 258 246 638 minecraft:pink_concrete
fill 258 232 646 258 307 646 minecraft:white_concrete
fill 259 232 610 271 232 610 minecraft:light_gray_concrete
fill 259 232 612 273 232 612 minecraft:light_gray_concrete
fill 259 232 621 260 232 621 minecraft:gray_concrete
fill 259 232 636 274 232 636 minecraft:light_gray_concrete
fill 259 232 638 273 232 638 minecraft:light_gray_concrete
setblock 259 232 646 minecraft:light_gray_concrete
fill 260 232 611 272 232 611 minecraft:light_gray_concrete
fill 260 232 620 276 232 620 minecraft:light_gray_concrete
fill 260 232 627 261 232 627 minecraft:gray_concrete
fill 260 232 629 276 232 629 minecraft:light_gray_concrete
fill 260 232 637 273 233 637 minecraft:light_gray_concrete
fill 260 232 646 260 307 646 minecraft:white_concrete
fill 261 232 621 276 232 621 minecraft:light_gray_concrete
fill 261 232 622 261 232 623 minecraft:gray_concrete
fill 261 232 625 261 232 626 minecraft:gray_concrete
fill 261 232 628 276 232 628 minecraft:light_gray_concrete
setblock 262 232 604 minecraft:light_gray_concrete
fill 262 232 622 270 232 623 minecraft:light_gray_concrete
fill 262 232 624 262 233 624 minecraft:gray_concrete
fill 262 232 625 270 232 627 minecraft:light_gray_concrete
fill 263 232 604 265 307 604 minecraft:white_concrete
fill 263 232 624 269 232 624 minecraft:light_gray_concrete
setblock 266 232 604 minecraft:light_gray_concrete
fill 267 232 604 277 241 604 minecraft:white_concrete
fill 267 232 614 268 246 615 minecraft:light_blue_concrete
fill 267 232 633 268 246 634 minecraft:light_blue_concrete
fill 269 232 614 274 232 615 minecraft:light_gray_concrete
fill 269 232 633 275 232 634 minecraft:light_gray_concrete
fill 270 232 624 272 246 624 minecraft:pink_concrete
fill 271 232 622 276 234 622 minecraft:light_gray_concrete
fill 271 232 623 271 246 623 minecraft:pink_concrete
fill 271 232 625 271 246 625 minecraft:pink_concrete
fill 271 232 626 276 234 627 minecraft:light_gray_concrete
fill 272 232 623 276 234 623 minecraft:light_gray_concrete
fill 272 232 625 276 234 625 minecraft:light_gray_concrete
fill 272 232 646 272 307 646 minecraft:white_concrete
fill 273 232 624 276 234 624 minecraft:light_gray_concrete
fill 274 232 646 274 307 646 minecraft:white_concrete
setblock 275 232 615 minecraft:light_gray_concrete
setblock 276 232 633 minecraft:light_gray_concrete
fill 277 232 605 277 307 606 minecraft:white_concrete
setblock 277 232 607 minecraft:light_gray_concrete
fill 277 232 608 277 241 612 minecraft:white_concrete
setblock 277 232 613 minecraft:light_gray_concrete
fill 277 232 614 277 241 622 minecraft:white_concrete
fill 277 232 638 277 307 639 minecraft:white_concrete
setblock 277 232 640 minecraft:light_gray_concrete
fill 277 232 641 277 241 644 minecraft:white_concrete
fill 235 233 604 235 307 604 minecraft:white_concrete
fill 235 233 606 235 307 606 minecraft:white_concrete
fill 235 233 620 235 307 620 minecraft:white_concrete
fill 235 233 623 235 241 625 minecraft:white_concrete
fill 235 233 629 235 307 629 minecraft:white_concrete
fill 235 233 640 235 241 641 minecraft:white_concrete
fill 236 233 619 243 233 625 minecraft:light_gray_concrete
fill 236 233 629 247 233 631 minecraft:light_gray_concrete
fill 236 233 646 236 307 646 minecraft:white_concrete
fill 237 233 617 256 233 618 minecraft:light_gray_concrete
fill 237 233 632 247 233 633 minecraft:light_gray_concrete
fill 238 233 604 238 307 604 minecraft:white_concrete
fill 238 233 615 247 233 616 minecraft:light_gray_concrete
fill 238 233 634 247 233 635 minecraft:light_gray_concrete
fill 239 233 613 247 233 614 minecraft:light_gray_concrete
fill 239 233 636 256 233 637 minecraft:light_gray_concrete
fill 240 233 612 257 233 612 minecraft:light_gray_concrete
fill 240 233 638 256 233 638 minecraft:light_gray_concrete
fill 241 233 611 256 233 611 minecraft:light_gray_concrete
fill 241 233 639 271 233 639 minecraft:light_gray_concrete
fill 242 233 610 257 233 610 minecraft:light_gray_concrete
fill 242 233 640 270 233 640 minecraft:light_gray_concrete
fill 243 233 604 243 307 604 minecraft:white_concrete
fill 243 233 609 269 233 609 minecraft:light_gray_concrete
fill 243 233 641 269 233 641 minecraft:light_gray_concrete
fill 243 233 646 243 307 646 minecraft:white_concrete
fill 244 233 608 268 233 608 minecraft:light_gray_concrete
fill 244 233 619 252 233 622 minecraft:light_gray_concrete
fill 244 233 642 268 233 642 minecraft:light_gray_concrete
fill 246 233 607 266 233 607 minecraft:light_gray_concrete
fill 246 233 623 251 233 623 minecraft:light_gray_concrete
fill 246 233 643 266 233 643 minecraft:light_gray_concrete
fill 248 233 606 264 233 606 minecraft:light_gray_concrete
fill 248 233 613 257 238 613 minecraft:light_gray_concrete
fill 248 233 616 274 234 616 minecraft:light_gray_concrete
fill 248 233 629 253 233 629 minecraft:light_gray_concrete
fill 248 233 635 274 233 635 minecraft:light_gray_concrete
fill 248 233 644 264 233 644 minecraft:light_gray_concrete
fill 250 233 605 262 233 605 minecraft:light_gray_concrete
fill 250 233 645 262 233 645 minecraft:light_gray_concrete
fill 252 233 623 253 234 625 minecraft:magenta_concrete
setblock 252 233 626 minecraft:gray_concrete
fill 252 233 627 252 233 628 minecraft:light_gray_concrete
fill 252 233 630 252 234 632 minecraft:light_gray_concrete
fill 253 233 619 253 233 620 minecraft:light_gray_concrete
fill 253 233 621 253 234 622 minecraft:magenta_concrete
fill 253 233 626 253 234 627 minecraft:magenta_concrete
setblock 253 233 628 minecraft:gray_concrete
fill 253 233 630 256 233 630 minecraft:light_gray_concrete
fill 253 233 632 275 234 632 minecraft:light_gray_concrete
setblock 254 233 619 minecraft:light_gray_concrete
fill 254 233 620 254 234 621 minecraft:magenta_concrete
fill 254 233 627 254 234 628 minecraft:magenta_concrete
setblock 254 233 629 minecraft:gray_concrete
fill 255 233 604 255 307 604 minecraft:white_concrete
fill 255 233 619 255 234 620 minecraft:magenta_concrete
fill 255 233 628 255 234 629 minecraft:magenta_concrete
fill 256 233 619 261 234 619 minecraft:magenta_concrete
fill 256 233 629 261 234 629 minecraft:magenta_concrete
fill 257 233 617 275 233 617 minecraft:light_gray_concrete
fill 257 233 618 259 234 618 minecraft:magenta_concrete
fill 257 233 630 259 234 630 minecraft:magenta_concrete
fill 257 233 636 257 237 636 minecraft:light_gray_concrete
fill 259 233 610 270 233 610 minecraft:light_gray_concrete
fill 259 233 612 272 233 612 minecraft:light_gray_concrete
fill 259 233 636 273 234 636 minecraft:light_gray_concrete
fill 259 233 638 272 233 638 minecraft:light_gray_concrete
fill 259 233 646 259 307 646 minecraft:white_concrete
fill 260 233 611 271 233 611 minecraft:light_gray_concrete
fill 260 233 618 275 234 618 minecraft:light_gray_concrete
setblock 260 233 620 minecraft:gray_concrete
fill 261 233 620 262 234 620 minecraft:magenta_concrete
setblock 261 233 621 minecraft:gray_concrete
fill 261 233 628 262 234 628 minecraft:magenta_concrete
fill 262 233 604 262 307 604 minecraft:white_concrete
fill 262 233 619 276 233 619 minecraft:light_gray_concrete
fill 262 233 621 263 234 621 minecraft:magenta_concrete
fill 262 233 622 262 233 623 minecraft:gray_concrete
fill 262 233 625 262 233 626 minecraft:gray_concrete
fill 262 233 627 263 234 627 minecraft:magenta_concrete
fill 262 233 629 276 233 629 minecraft:light_gray_concrete
fill 263 233 620 276 233 620 minecraft:light_gray_concrete
fill 263 233 622 263 234 626 minecraft:magenta_concrete
fill 263 233 628 276 234 628 minecraft:light_gray_concrete
fill 264 233 621 270 234 622 minecraft:light_gray_concrete
fill 264 233 623 264 234 625 minecraft:magenta_concrete
fill 264 233 626 270 234 627 minecraft:light_gray_concrete
fill 265 233 623 269 235 625 minecraft:light_gray_concrete
fill 265 233 646 265 307 646 minecraft:white_concrete
fill 266 233 604 266 241 604 minecraft:white_concrete
fill 269 233 614 273 234 615 minecraft:light_gray_concrete
fill 269 233 633 274 234 634 minecraft:light_gray_concrete
fill 270 233 623 270 239 623 minecraft:light_gray_concrete
fill 270 233 625 270 239 625 minecraft:light_gray_concrete
fill 271 233 621 276 233 621 minecraft:light_gray_concrete
setblock 274 233 615 minecraft:light_gray_concrete
setblock 275 233 633 minecraft:light_gray_concrete
fill 277 233 607 277 307 607 minecraft:white_concrete
fill 277 233 613 277 307 613 minecraft:white_concrete
fill 277 233 640 277 307 640 minecraft:white_concrete
fill 236 234 622 243 234 628 minecraft:light_gray_concrete
fill 237 234 618 251 234 621 minecraft:light_gray_concrete
fill 237 234 629 247 234 632 minecraft:light_gray_concrete
fill 238 234 616 247 234 617 minecraft:light_gray_concrete
fill 238 234 633 247 234 634 minecraft:light_gray_concrete
fill 239 234 614 247 234 615 minecraft:light_gray_concrete
fill 239 234 635 256 234 636 minecraft:light_gray_concrete
fill 240 234 613 247 234 613 minecraft:light_gray_concrete
fill 240 234 637 256 234 637 minecraft:light_gray_concrete
fill 241 234 612 257 234 612 minecraft:light_gray_concrete
fill 241 234 638 256 234 638 minecraft:light_gray_concrete
fill 242 234 611 256 234 611 minecraft:light_gray_concrete
fill 242 234 639 270 234 639 minecraft:light_gray_concrete
fill 243 234 610 257 234 610 minecraft:light_gray_concrete
fill 243 234 640 269 234 640 minecraft:light_gray_concrete
fill 244 234 609 268 234 609 minecraft:light_gray_concrete
fill 244 234 622 250 234 622 minecraft:light_gray_concrete
fill 244 234 626 250 234 628 minecraft:light_gray_concrete
fill 244 234 641 268 234 641 minecraft:light_gray_concrete
fill 245 234 608 267 234 608 minecraft:light_gray_concrete
fill 245 234 642 267 234 642 minecraft:light_gray_concrete
fill 246 234 623 250 234 623 minecraft:light_gray_concrete
fill 246 234 625 250 234 625 minecraft:light_gray_concrete
fill 247 234 607 265 234 607 minecraft:light_gray_concrete
fill 247 234 624 250 234 624 minecraft:light_gray_concrete
fill 247 234 643 265 234 643 minecraft:light_gray_concrete
fill 248 234 617 274 234 617 minecraft:light_gray_concrete
fill 248 234 629 251 234 629 minecraft:light_gray_concrete
fill 249 234 606 263 234 606 minecraft:light_gray_concrete
fill 249 234 644 263 234 644 minecraft:light_gray_concrete
fill 251 234 622 251 234 627 minecraft:gold_block
setblock 251 234 628 minecraft:light_gray_concrete
fill 252 234 618 252 234 619 minecraft:light_gray_concrete
fill 252 234 620 252 234 622 minecraft:gold_block
fill 252 234 627 252 234 629 minecraft:gold_block
fill 253 234 605 259 234 605 minecraft:light_gray_concrete
fill 253 234 618 254 234 618 minecraft:light_gray_concrete
fill 253 234 619 253 234 620 minecraft:gold_block
fill 253 234 629 253 234 630 minecraft:gold_block
fill 253 234 631 254 234 631 minecraft:light_gray_concrete
fill 253 234 645 259 234 645 minecraft:light_gray_concrete
setblock 254 234 619 minecraft:gold_block
fill 254 234 630 256 234 630 minecraft:gold_block
fill 255 234 618 256 234 618 minecraft:gold_block
fill 255 234 631 259 234 631 minecraft:gold_block
fill 257 234 635 273 234 635 minecraft:light_gray_concrete
fill 258 234 613 272 234 613 minecraft:light_gray_concrete
fill 259 234 610 269 234 610 minecraft:light_gray_concrete
fill 259 234 612 271 234 612 minecraft:light_gray_concrete
fill 259 234 638 271 234 638 minecraft:light_gray_concrete
fill 260 234 611 270 234 611 minecraft:light_gray_concrete
fill 260 234 630 261 234 630 minecraft:gold_block
fill 260 234 631 275 234 631 minecraft:light_gray_concrete
fill 260 234 637 272 234 637 minecraft:light_gray_concrete
fill 262 234 619 275 234 619 minecraft:light_gray_concrete
setblock 262 234 629 minecraft:gold_block
fill 262 234 630 275 234 630 minecraft:light_gray_concrete
fill 263 234 620 275 234 620 minecraft:light_gray_concrete
fill 263 234 629 275 234 629 minecraft:light_gray_concrete
fill 271 234 621 275 235 621 minecraft:light_gray_concrete
fill 236 235 611 236 273 612 minecraft:gray_concrete
fill 236 235 619 236 273 620 minecraft:gray_concrete
fill 236 235 627 236 273 628 minecraft:gray_concrete
fill 236 235 635 236 273 636 minecraft:gray_concrete
fill 236 235 643 236 273 644 minecraft:gray_concrete
fill 237 235 605 238 273 605 minecraft:gray_concrete
fill 237 235 621 243 235 629 minecraft:light_gray_concrete
setblock 238 235 607 minecraft:light[level=14]
setblock 238 235 615 minecraft:light[level=14]
fill 238 235 618 250 235 620 minecraft:light_gray_concrete
fill 238 235 630 250 235 632 minecraft:light_gray_concrete
setblock 238 235 639 minecraft:light[level=14]
fill 239 235 616 254 235 617 minecraft:light_gray_concrete
fill 239 235 633 247 235 634 minecraft:light_gray_concrete
fill 240 235 614 247 235 615 minecraft:light_gray_concrete
fill 240 235 635 256 235 636 minecraft:light_gray_concrete
fill 241 235 613 247 235 613 minecraft:light_gray_concrete
fill 241 235 637 256 235 637 minecraft:light_gray_concrete
fill 242 235 612 257 235 612 minecraft:light_gray_concrete
fill 242 235 638 256 235 638 minecraft:light_gray_concrete
fill 242 235 645 243 273 645 minecraft:gray_concrete
fill 243 235 611 256 235 611 minecraft:light_gray_concrete
fill 243 235 639 269 235 639 minecraft:light_gray_concrete
fill 244 235 610 257 235 610 minecraft:light_gray_concrete
fill 244 235 621 249 235 622 minecraft:light_gray_concrete
fill 244 235 626 248 235 629 minecraft:light_gray_concrete
fill 244 235 640 268 235 640 minecraft:light_gray_concrete
fill 245 235 605 246 273 605 minecraft:gray_concrete
fill 245 235 609 267 235 609 minecraft:light_gray_concrete
fill 245 235 641 267 235 641 minecraft:light_gray_concrete
setblock 246 235 607 minecraft:light[level=14]
fill 246 235 623 248 235 623 minecraft:light_gray_concrete
fill 246 235 625 248 235 625 minecraft:light_gray_concrete
fill 247 235 608 265 235 608 minecraft:light_gray_concrete
fill 247 235 624 248 235 624 minecraft:light_gray_concrete
fill 247 235 642 265 235 642 minecraft:light_gray_concrete
fill 249 235 607 263 235 607 minecraft:light_gray_concrete
fill 249 235 623 250 235 626 minecraft:gray_concrete
fill 249 235 627 249 235 629 minecraft:light_gray_concrete
fill 249 235 643 263 235 643 minecraft:light_gray_concrete
fill 250 235 621 250 235 622 minecraft:gray_concrete
fill 250 235 627 250 235 628 minecraft:gray_concrete
setblock 250 235 629 minecraft:light_gray_concrete
fill 250 235 645 251 273 645 minecraft:gray_concrete
fill 251 235 618 251 235 619 minecraft:light_gray_concrete
fill 251 235 620 251 235 621 minecraft:gray_concrete
fill 251 235 628 251 235 630 minecraft:gray_concrete
fill 251 235 631 251 235 632 minecraft:light_gray_concrete
fill 252 235 606 260 235 606 minecraft:light_gray_concrete
setblock 252 235 618 minecraft:light_gray_concrete
setblock 252 235 619 minecraft:gray_concrete
fill 252 235 630 252 235 631 minecraft:gray_concrete
fill 252 235 632 253 235 632 minecraft:light_gray_concrete
fill 252 235 644 260 235 644 minecraft:light_gray_concrete
fill 253 235 605 254 273 605 minecraft:gray_concrete
fill 253 235 618 254 235 618 minecraft:gray_concrete
fill 253 235 631 254 235 631 minecraft:gray_concrete
setblock 254 235 623 minecraft:light[level=14]
fill 254 235 632 259 235 632 minecraft:gray_concrete
fill 255 235 616 273 235 616 minecraft:light_gray_concrete
fill 255 235 617 259 235 617 minecraft:gray_concrete
fill 257 235 635 272 235 635 minecraft:light_gray_concrete
fill 258 235 613 271 235 613 minecraft:light_gray_concrete
fill 258 235 645 259 273 645 minecraft:gray_concrete
fill 259 235 610 268 235 610 minecraft:light_gray_concrete
fill 259 235 612 270 235 612 minecraft:light_gray_concrete
fill 259 235 636 272 235 636 minecraft:light_gray_concrete
schedule function dropper:buildpart/149_2 1t
