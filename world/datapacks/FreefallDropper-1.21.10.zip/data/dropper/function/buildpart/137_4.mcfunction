fill 258 246 557 259 251 557 minecraft:red_concrete
fill 258 246 598 260 246 598 minecraft:orange_concrete
fill 260 246 557 261 246 557 minecraft:yellow_concrete
fill 260 246 558 262 246 558 minecraft:orange_concrete
setblock 261 246 578 minecraft:yellow_concrete
fill 261 246 580 262 246 580 minecraft:orange_concrete
setblock 262 246 577 minecraft:red_concrete
fill 262 246 598 264 246 598 minecraft:orange_concrete
fill 263 246 574 263 246 575 minecraft:shroomlight
fill 263 246 576 265 246 576 minecraft:yellow_concrete
setblock 263 246 578 minecraft:red_concrete
fill 263 246 579 263 248 579 minecraft:yellow_concrete
fill 264 246 558 266 246 558 minecraft:orange_concrete
fill 264 246 574 264 246 575 minecraft:orange_concrete
setblock 264 246 577 minecraft:yellow_concrete
fill 264 246 599 264 247 599 minecraft:yellow_concrete
fill 265 246 573 266 246 574 minecraft:orange_concrete
fill 265 246 599 266 251 599 minecraft:red_concrete
setblock 266 246 572 minecraft:red_concrete
fill 266 246 598 268 246 598 minecraft:orange_concrete
setblock 267 246 571 minecraft:red_concrete
fill 267 246 572 267 247 573 minecraft:orange_concrete
setblock 267 246 599 minecraft:yellow_concrete
fill 268 246 558 270 246 558 minecraft:orange_concrete
fill 269 246 568 271 246 568 minecraft:red_concrete
setblock 269 246 570 minecraft:red_concrete
fill 269 246 599 269 251 599 minecraft:red_concrete
fill 270 246 557 271 251 557 minecraft:red_concrete
fill 270 246 567 271 247 567 minecraft:red_concrete
setblock 270 246 569 minecraft:red_concrete
fill 270 246 598 272 246 598 minecraft:orange_concrete
fill 271 246 566 272 247 566 minecraft:red_concrete
fill 272 246 557 273 247 557 minecraft:yellow_concrete
fill 272 246 558 274 246 558 minecraft:orange_concrete
fill 272 246 565 273 247 565 minecraft:red_concrete
fill 274 246 598 276 246 598 minecraft:orange_concrete
fill 275 246 599 276 247 599 minecraft:yellow_concrete
fill 276 246 558 276 246 560 minecraft:orange_concrete
fill 276 246 562 276 246 564 minecraft:orange_concrete
fill 276 246 566 276 246 568 minecraft:orange_concrete
fill 276 246 570 276 246 572 minecraft:orange_concrete
fill 276 246 574 276 246 576 minecraft:orange_concrete
fill 276 246 578 276 246 580 minecraft:orange_concrete
fill 276 246 582 276 246 584 minecraft:orange_concrete
fill 276 246 586 276 246 588 minecraft:orange_concrete
fill 276 246 590 276 246 592 minecraft:orange_concrete
fill 276 246 594 276 246 596 minecraft:orange_concrete
fill 277 246 559 277 251 559 minecraft:red_concrete
fill 277 246 560 277 246 561 minecraft:yellow_concrete
fill 277 246 562 277 251 562 minecraft:red_concrete
fill 277 246 564 277 247 564 minecraft:yellow_concrete
fill 277 246 570 277 251 571 minecraft:red_concrete
fill 277 246 572 277 247 573 minecraft:yellow_concrete
setblock 277 246 581 minecraft:yellow_concrete
fill 277 246 582 277 251 583 minecraft:red_concrete
fill 277 246 584 277 247 585 minecraft:yellow_concrete
fill 277 246 590 277 251 591 minecraft:red_concrete
fill 277 246 592 277 246 593 minecraft:yellow_concrete
fill 277 246 594 277 251 594 minecraft:red_concrete
fill 277 246 599 277 251 599 minecraft:red_concrete
setblock 235 247 564 minecraft:yellow_concrete
setblock 235 247 567 minecraft:yellow_concrete
fill 235 247 568 235 250 568 minecraft:red_concrete
setblock 235 247 575 minecraft:yellow_concrete
fill 235 247 579 235 250 579 minecraft:red_concrete
setblock 235 247 595 minecraft:yellow_concrete
setblock 235 247 599 minecraft:yellow_concrete
fill 236 247 562 237 248 562 minecraft:red_concrete
fill 236 247 599 236 250 599 minecraft:red_concrete
fill 237 247 563 238 248 563 minecraft:red_concrete
fill 238 247 564 239 247 564 minecraft:red_concrete
fill 241 247 567 242 247 567 minecraft:red_concrete
setblock 242 247 568 minecraft:red_concrete
fill 242 247 571 244 248 571 minecraft:orange_concrete
fill 243 247 572 244 248 572 minecraft:orange_concrete
setblock 244 247 573 minecraft:orange_concrete
fill 245 247 575 247 247 575 minecraft:yellow_concrete
setblock 246 247 573 minecraft:orange_concrete
fill 246 247 574 246 248 574 minecraft:yellow_concrete
fill 246 247 576 248 247 576 minecraft:yellow_concrete
fill 247 247 577 249 247 577 minecraft:red_concrete
fill 247 247 599 247 249 599 minecraft:red_concrete
fill 248 247 578 250 247 578 minecraft:orange_concrete
fill 248 247 579 248 249 579 minecraft:yellow_concrete
fill 249 247 557 249 250 557 minecraft:red_concrete
fill 249 247 580 250 247 580 minecraft:red_concrete
setblock 250 247 579 minecraft:yellow_concrete
setblock 252 247 599 minecraft:yellow_concrete
setblock 253 247 557 minecraft:yellow_concrete
fill 260 247 557 260 250 557 minecraft:red_concrete
setblock 261 247 557 minecraft:yellow_concrete
fill 262 247 578 264 247 578 minecraft:orange_concrete
setblock 262 247 579 minecraft:yellow_concrete
fill 262 247 580 263 247 580 minecraft:red_concrete
fill 263 247 577 265 247 577 minecraft:red_concrete
setblock 263 247 599 minecraft:yellow_concrete
setblock 264 247 557 minecraft:yellow_concrete
fill 264 247 576 266 247 576 minecraft:yellow_concrete
fill 264 247 579 264 249 579 minecraft:yellow_concrete
fill 265 247 575 267 247 575 minecraft:yellow_concrete
setblock 266 247 573 minecraft:orange_concrete
fill 266 247 574 266 248 574 minecraft:yellow_concrete
fill 267 247 599 267 250 599 minecraft:red_concrete
fill 268 247 571 268 247 573 minecraft:orange_concrete
fill 269 247 571 269 248 572 minecraft:orange_concrete
setblock 270 247 568 minecraft:red_concrete
fill 270 247 571 270 248 571 minecraft:orange_concrete
fill 273 247 564 274 247 564 minecraft:red_concrete
fill 274 247 563 275 248 563 minecraft:red_concrete
fill 275 247 562 276 248 562 minecraft:red_concrete
fill 277 247 560 277 250 561 minecraft:red_concrete
setblock 277 247 565 minecraft:yellow_concrete
setblock 277 247 576 minecraft:yellow_concrete
fill 277 247 581 277 250 581 minecraft:red_concrete
fill 277 247 592 277 250 592 minecraft:red_concrete
setblock 277 247 593 minecraft:yellow_concrete
fill 277 247 596 277 247 597 minecraft:yellow_concrete
fill 235 248 562 235 249 562 minecraft:yellow_concrete
fill 235 248 563 235 249 564 minecraft:red_concrete
fill 235 248 565 235 248 566 minecraft:yellow_concrete
fill 235 248 567 235 253 567 minecraft:red_concrete
fill 235 248 573 235 249 574 minecraft:yellow_concrete
fill 235 248 575 235 253 576 minecraft:red_concrete
fill 235 248 585 235 248 586 minecraft:yellow_concrete
fill 235 248 587 235 253 588 minecraft:red_concrete
fill 235 248 593 235 249 594 minecraft:yellow_concrete
fill 235 248 595 235 253 596 minecraft:red_concrete
setblock 235 248 597 minecraft:yellow_concrete
fill 235 248 599 235 250 599 minecraft:red_concrete
setblock 238 248 564 minecraft:red_concrete
fill 240 248 557 241 253 557 minecraft:red_concrete
fill 240 248 569 241 249 569 minecraft:orange_concrete
fill 241 248 570 243 248 570 minecraft:orange_concrete
fill 241 248 599 242 249 599 minecraft:yellow_concrete
fill 242 248 557 243 248 557 minecraft:yellow_concrete
fill 243 248 599 244 253 599 minecraft:red_concrete
fill 244 248 574 245 249 574 minecraft:yellow_concrete
fill 245 248 575 246 248 575 minecraft:yellow_concrete
fill 246 248 576 247 248 577 minecraft:red_concrete
fill 247 248 578 249 248 578 minecraft:orange_concrete
setblock 248 248 577 minecraft:red_concrete
fill 248 248 580 249 248 580 minecraft:red_concrete
fill 249 248 581 249 250 581 minecraft:orange_concrete
setblock 249 248 599 minecraft:red_concrete
setblock 250 248 580 minecraft:orange_concrete
fill 250 248 599 250 249 599 minecraft:yellow_concrete
fill 252 248 557 253 253 557 minecraft:red_concrete
fill 252 248 599 252 253 599 minecraft:red_concrete
fill 253 248 599 254 248 599 minecraft:yellow_concrete
fill 254 248 557 255 249 557 minecraft:yellow_concrete
fill 255 248 599 256 250 599 minecraft:red_concrete
fill 256 248 586 256 249 587 minecraft:yellow_concrete
fill 261 248 557 261 253 557 minecraft:red_concrete
fill 261 248 599 262 249 599 minecraft:yellow_concrete
fill 262 248 557 263 248 557 minecraft:yellow_concrete
setblock 262 248 580 minecraft:orange_concrete
fill 263 248 578 265 248 578 minecraft:orange_concrete
fill 263 248 580 264 248 580 minecraft:red_concrete
fill 263 248 581 263 250 581 minecraft:orange_concrete
fill 263 248 599 264 253 599 minecraft:red_concrete
fill 264 248 557 265 249 557 minecraft:red_concrete
fill 264 248 577 266 248 577 minecraft:red_concrete
fill 265 248 576 266 248 576 minecraft:red_concrete
fill 266 248 557 266 249 557 minecraft:yellow_concrete
fill 266 248 575 267 248 575 minecraft:yellow_concrete
fill 267 248 574 268 249 574 minecraft:yellow_concrete
fill 268 248 571 268 248 572 minecraft:orange_concrete
fill 269 248 570 271 248 570 minecraft:orange_concrete
fill 271 248 569 272 249 569 minecraft:orange_concrete
fill 272 248 557 273 253 557 minecraft:red_concrete
fill 273 248 599 274 248 599 minecraft:yellow_concrete
fill 274 248 557 275 249 557 minecraft:yellow_concrete
setblock 274 248 564 minecraft:red_concrete
fill 275 248 599 276 253 599 minecraft:red_concrete
setblock 277 248 563 minecraft:yellow_concrete
fill 277 248 564 277 253 565 minecraft:red_concrete
fill 277 248 566 277 249 567 minecraft:yellow_concrete
fill 277 248 572 277 253 573 minecraft:red_concrete
fill 277 248 574 277 248 575 minecraft:yellow_concrete
fill 277 248 576 277 253 576 minecraft:red_concrete
fill 277 248 584 277 253 585 minecraft:red_concrete
fill 277 248 586 277 249 587 minecraft:yellow_concrete
fill 277 248 593 277 253 593 minecraft:red_concrete
setblock 277 248 595 minecraft:yellow_concrete
fill 277 248 596 277 253 597 minecraft:red_concrete
fill 277 248 598 277 249 598 minecraft:yellow_concrete
setblock 235 249 561 minecraft:yellow_concrete
fill 235 249 565 235 252 566 minecraft:red_concrete
setblock 235 249 582 minecraft:yellow_concrete
setblock 235 249 585 minecraft:yellow_concrete
fill 235 249 586 235 252 586 minecraft:red_concrete
fill 235 249 597 235 252 597 minecraft:red_concrete
fill 237 249 599 237 251 599 minecraft:red_concrete
fill 238 249 567 239 250 568 minecraft:orange_concrete
setblock 238 249 599 minecraft:yellow_concrete
setblock 239 249 569 minecraft:orange_concrete
setblock 240 249 568 minecraft:orange_concrete
fill 241 249 570 242 249 570 minecraft:orange_concrete
fill 242 249 557 242 252 557 minecraft:red_concrete
fill 242 249 573 244 249 573 minecraft:yellow_concrete
setblock 243 249 557 minecraft:yellow_concrete
fill 243 249 574 243 250 574 minecraft:yellow_concrete
fill 244 249 576 246 249 576 minecraft:red_concrete
fill 245 249 577 246 249 577 minecraft:red_concrete
setblock 246 249 557 minecraft:yellow_concrete
fill 246 249 578 248 249 578 minecraft:orange_concrete
fill 247 249 579 247 250 580 minecraft:yellow_concrete
setblock 248 249 580 minecraft:yellow_concrete
fill 248 249 581 248 250 581 minecraft:red_concrete
setblock 249 249 580 minecraft:red_concrete
setblock 249 249 599 minecraft:yellow_concrete
setblock 253 249 599 minecraft:yellow_concrete
fill 254 249 599 254 252 599 minecraft:red_concrete
fill 262 249 557 263 252 557 minecraft:red_concrete
setblock 263 249 580 minecraft:red_concrete
fill 264 249 578 266 249 578 minecraft:orange_concrete
fill 264 249 580 265 249 580 minecraft:yellow_concrete
fill 264 249 581 264 250 581 minecraft:red_concrete
fill 265 249 579 265 251 579 minecraft:yellow_concrete
fill 266 249 576 267 249 577 minecraft:red_concrete
setblock 267 249 557 minecraft:yellow_concrete
fill 268 249 573 270 249 573 minecraft:yellow_concrete
fill 268 249 576 268 251 576 minecraft:red_concrete
fill 269 249 574 269 250 574 minecraft:yellow_concrete
fill 270 249 570 271 249 570 minecraft:orange_concrete
setblock 270 249 599 minecraft:yellow_concrete
fill 272 249 568 274 249 568 minecraft:orange_concrete
fill 273 249 567 274 250 567 minecraft:orange_concrete
setblock 273 249 569 minecraft:orange_concrete
setblock 273 249 599 minecraft:yellow_concrete
fill 274 249 599 274 252 599 minecraft:red_concrete
setblock 277 249 558 minecraft:yellow_concrete
fill 277 249 563 277 252 563 minecraft:red_concrete
fill 277 249 574 277 252 574 minecraft:red_concrete
setblock 277 249 575 minecraft:yellow_concrete
fill 277 249 578 277 249 579 minecraft:yellow_concrete
fill 277 249 595 277 252 595 minecraft:red_concrete
fill 235 250 559 235 251 560 minecraft:yellow_concrete
fill 235 250 561 235 255 562 minecraft:red_concrete
setblock 235 250 563 minecraft:yellow_concrete
fill 235 250 564 235 253 564 minecraft:red_concrete
fill 235 250 571 235 251 572 minecraft:yellow_concrete
fill 235 250 573 235 255 574 minecraft:red_concrete
fill 235 250 580 235 251 580 minecraft:yellow_concrete
fill 235 250 582 235 255 582 minecraft:red_concrete
fill 235 250 583 235 250 584 minecraft:yellow_concrete
fill 235 250 585 235 255 585 minecraft:red_concrete
fill 235 250 591 235 251 592 minecraft:yellow_concrete
fill 235 250 593 235 255 594 minecraft:red_concrete
fill 236 250 557 237 251 557 minecraft:yellow_concrete
fill 236 250 566 238 250 566 minecraft:orange_concrete
fill 237 250 567 237 251 567 minecraft:orange_concrete
setblock 238 250 560 minecraft:light[level=14]
setblock 238 250 576 minecraft:light[level=14]
setblock 238 250 584 minecraft:light[level=14]
setblock 238 250 592 minecraft:light[level=14]
fill 238 250 599 238 251 599 minecraft:red_concrete
fill 239 250 599 240 250 599 minecraft:yellow_concrete
fill 241 250 572 242 250 573 minecraft:yellow_concrete
fill 241 250 599 242 255 599 minecraft:red_concrete
fill 243 250 557 243 255 557 minecraft:red_concrete
setblock 243 250 573 minecraft:yellow_concrete
fill 243 250 576 245 250 576 minecraft:red_concrete
fill 244 250 557 245 250 557 minecraft:yellow_concrete
setblock 244 250 575 minecraft:red_concrete
setblock 245 250 577 minecraft:red_concrete
fill 245 250 578 247 250 578 minecraft:orange_concrete
fill 246 250 557 246 255 557 minecraft:red_concrete
setblock 246 250 560 minecraft:light[level=14]
setblock 246 250 568 minecraft:light[level=14]
setblock 246 250 576 minecraft:light[level=14]
fill 246 250 579 246 252 580 minecraft:yellow_concrete
setblock 246 250 584 minecraft:light[level=14]
setblock 246 250 592 minecraft:light[level=14]
fill 247 250 581 247 252 581 minecraft:red_concrete
fill 247 250 599 248 251 599 minecraft:yellow_concrete
fill 248 250 557 248 251 557 minecraft:yellow_concrete
setblock 248 250 580 minecraft:red_concrete
fill 248 250 582 248 251 582 minecraft:orange_concrete
fill 249 250 599 250 255 599 minecraft:red_concrete
setblock 251 250 599 minecraft:yellow_concrete
fill 253 250 599 253 252 599 minecraft:red_concrete
fill 254 250 557 255 255 557 minecraft:red_concrete
setblock 254 250 560 minecraft:light[level=14]
setblock 254 250 568 minecraft:light[level=14]
setblock 254 250 576 minecraft:light[level=14]
setblock 254 250 584 minecraft:light[level=14]
setblock 254 250 592 minecraft:light[level=14]
fill 256 250 557 257 251 557 minecraft:yellow_concrete
fill 259 250 599 260 251 599 minecraft:yellow_concrete
fill 261 250 599 262 255 599 minecraft:red_concrete
setblock 262 250 560 minecraft:light[level=14]
setblock 262 250 568 minecraft:light[level=14]
setblock 262 250 576 minecraft:light[level=14]
setblock 262 250 584 minecraft:light[level=14]
setblock 262 250 592 minecraft:light[level=14]
fill 264 250 557 264 253 557 minecraft:red_concrete
setblock 264 250 580 minecraft:red_concrete
fill 264 250 582 264 251 582 minecraft:orange_concrete
setblock 265 250 557 minecraft:yellow_concrete
fill 265 250 578 267 250 578 minecraft:orange_concrete
fill 265 250 580 266 250 580 minecraft:yellow_concrete
fill 265 250 581 265 252 581 minecraft:red_concrete
fill 266 250 557 267 255 557 minecraft:red_concrete
fill 266 250 579 266 252 579 minecraft:yellow_concrete
fill 267 250 576 267 250 577 minecraft:red_concrete
fill 268 250 557 269 251 557 minecraft:yellow_concrete
setblock 268 250 575 minecraft:red_concrete
fill 268 250 599 268 251 599 minecraft:yellow_concrete
fill 269 250 573 271 250 573 minecraft:yellow_concrete
fill 269 250 576 269 252 576 minecraft:red_concrete
setblock 270 250 560 minecraft:light[level=14]
setblock 270 250 568 minecraft:light[level=14]
fill 270 250 572 271 250 572 minecraft:yellow_concrete
setblock 270 250 576 minecraft:light[level=14]
setblock 270 250 584 minecraft:light[level=14]
setblock 270 250 592 minecraft:light[level=14]
fill 270 250 599 270 255 599 minecraft:red_concrete
fill 271 250 599 272 250 599 minecraft:yellow_concrete
fill 273 250 568 274 250 568 minecraft:orange_concrete
fill 273 250 599 273 255 599 minecraft:red_concrete
fill 274 250 557 275 255 557 minecraft:red_concrete
fill 274 250 566 276 250 566 minecraft:orange_concrete
fill 275 250 567 275 251 567 minecraft:orange_concrete
fill 276 250 557 277 250 557 minecraft:yellow_concrete
fill 277 250 558 277 255 558 minecraft:red_concrete
fill 277 250 566 277 255 567 minecraft:red_concrete
fill 277 250 568 277 251 569 minecraft:yellow_concrete
fill 277 250 575 277 255 575 minecraft:red_concrete
setblock 277 250 577 minecraft:yellow_concrete
fill 277 250 578 277 255 579 minecraft:red_concrete
fill 277 250 580 277 251 580 minecraft:yellow_concrete
fill 277 250 586 277 255 587 minecraft:red_concrete
fill 277 250 588 277 250 589 minecraft:yellow_concrete
fill 277 250 598 277 255 598 minecraft:red_concrete
fill 235 251 563 235 254 563 minecraft:red_concrete
setblock 235 251 568 minecraft:yellow_concrete
setblock 235 251 579 minecraft:yellow_concrete
fill 235 251 583 235 253 584 minecraft:red_concrete
fill 235 251 599 236 251 599 minecraft:yellow_concrete
fill 236 251 566 237 251 566 minecraft:orange_concrete
fill 239 251 571 240 252 572 minecraft:yellow_concrete
setblock 239 251 599 minecraft:yellow_concrete
fill 240 251 599 240 254 599 minecraft:red_concrete
fill 241 251 572 241 251 573 minecraft:yellow_concrete
setblock 242 251 573 minecraft:yellow_concrete
fill 242 251 575 243 252 576 minecraft:red_concrete
fill 244 251 557 245 254 557 minecraft:red_concrete
setblock 244 251 576 minecraft:red_concrete
fill 244 251 578 246 251 578 minecraft:orange_concrete
fill 245 251 579 245 252 580 minecraft:yellow_concrete
fill 246 251 581 246 253 581 minecraft:red_concrete
setblock 247 251 579 minecraft:yellow_concrete
setblock 247 251 580 minecraft:red_concrete
fill 247 251 582 247 253 582 minecraft:orange_concrete
setblock 248 251 581 minecraft:orange_concrete
setblock 249 251 557 minecraft:yellow_concrete
fill 251 251 599 251 254 599 minecraft:red_concrete
fill 255 251 599 255 253 599 minecraft:red_concrete
setblock 256 251 599 minecraft:yellow_concrete
setblock 260 251 557 minecraft:yellow_concrete
setblock 264 251 581 minecraft:orange_concrete
fill 265 251 557 265 254 557 minecraft:red_concrete
setblock 265 251 580 minecraft:red_concrete
fill 265 251 582 265 253 582 minecraft:orange_concrete
fill 266 251 578 268 251 578 minecraft:orange_concrete
fill 266 251 580 267 252 580 minecraft:yellow_concrete
fill 266 251 581 266 253 581 minecraft:red_concrete
fill 267 251 579 267 252 579 minecraft:yellow_concrete
setblock 267 251 599 minecraft:yellow_concrete
fill 269 251 575 270 252 575 minecraft:red_concrete
fill 270 251 573 271 251 573 minecraft:yellow_concrete
fill 270 251 576 270 252 576 minecraft:red_concrete
fill 271 251 572 273 251 572 minecraft:yellow_concrete
fill 271 251 599 272 254 599 minecraft:red_concrete
fill 272 251 571 273 252 571 minecraft:yellow_concrete
fill 275 251 566 276 251 566 minecraft:orange_concrete
fill 276 251 557 276 254 557 minecraft:red_concrete
setblock 277 251 557 minecraft:yellow_concrete
fill 277 251 560 277 251 561 minecraft:yellow_concrete
fill 277 251 577 277 254 577 minecraft:red_concrete
setblock 277 251 581 minecraft:yellow_concrete
fill 277 251 588 277 254 588 minecraft:red_concrete
setblock 277 251 589 minecraft:yellow_concrete
setblock 277 251 592 minecraft:yellow_concrete
fill 235 252 557 235 253 558 minecraft:yellow_concrete
fill 235 252 559 235 257 560 minecraft:red_concrete
fill 235 252 568 235 257 568 minecraft:red_concrete
fill 235 252 569 235 252 570 minecraft:yellow_concrete
fill 235 252 571 235 257 572 minecraft:red_concrete
fill 235 252 577 235 253 578 minecraft:yellow_concrete
fill 235 252 579 235 257 580 minecraft:red_concrete
setblock 235 252 581 minecraft:yellow_concrete
fill 235 252 589 235 253 590 minecraft:yellow_concrete
fill 235 252 591 235 257 592 minecraft:red_concrete
fill 235 252 598 235 253 598 minecraft:yellow_concrete
fill 235 252 599 236 253 599 minecraft:red_concrete
fill 236 252 557 237 257 557 minecraft:red_concrete
fill 236 252 558 238 252 558 minecraft:orange_concrete
fill 236 252 560 236 252 562 minecraft:orange_concrete
fill 236 252 564 236 252 566 minecraft:orange_concrete
fill 236 252 568 236 252 570 minecraft:orange_concrete
fill 236 252 572 236 252 574 minecraft:orange_concrete
fill 236 252 576 236 252 578 minecraft:orange_concrete
fill 236 252 580 236 252 582 minecraft:orange_concrete
fill 236 252 584 236 252 586 minecraft:orange_concrete
fill 236 252 588 236 252 590 minecraft:orange_concrete
fill 236 252 592 236 252 594 minecraft:orange_concrete
fill 236 252 596 236 252 598 minecraft:orange_concrete
fill 237 252 599 238 252 599 minecraft:yellow_concrete
fill 238 252 557 239 253 557 minecraft:yellow_concrete
fill 238 252 570 238 253 571 minecraft:yellow_concrete
fill 238 252 598 240 252 598 minecraft:orange_concrete
fill 239 252 599 239 257 599 minecraft:red_concrete
fill 240 252 558 242 252 558 minecraft:orange_concrete
fill 241 252 575 241 253 576 minecraft:red_concrete
fill 242 252 598 244 252 598 minecraft:orange_concrete
fill 243 252 578 245 252 578 minecraft:orange_concrete
fill 244 252 558 246 252 558 minecraft:orange_concrete
fill 244 252 580 244 254 580 minecraft:yellow_concrete
fill 245 252 581 245 254 581 minecraft:red_concrete
fill 245 252 599 246 253 599 minecraft:yellow_concrete
fill 246 252 582 246 253 582 minecraft:red_concrete
fill 246 252 583 247 253 583 minecraft:orange_concrete
fill 246 252 598 248 252 598 minecraft:orange_concrete
setblock 247 252 557 minecraft:yellow_concrete
fill 247 252 599 248 257 599 minecraft:red_concrete
fill 248 252 557 249 257 557 minecraft:red_concrete
fill 248 252 558 250 252 558 minecraft:orange_concrete
fill 250 252 557 251 253 557 minecraft:yellow_concrete
fill 250 252 598 252 252 598 minecraft:orange_concrete
fill 252 252 558 254 252 558 minecraft:orange_concrete
fill 254 252 598 256 252 598 minecraft:orange_concrete
fill 256 252 557 257 257 557 minecraft:red_concrete
fill 256 252 558 258 252 558 minecraft:orange_concrete
fill 256 252 599 256 257 599 minecraft:red_concrete
fill 257 252 599 258 252 599 minecraft:yellow_concrete
fill 258 252 557 259 252 557 minecraft:yellow_concrete
fill 258 252 598 260 252 598 minecraft:orange_concrete
fill 259 252 599 260 257 599 minecraft:red_concrete
fill 260 252 557 260 257 557 minecraft:red_concrete
fill 260 252 558 262 252 558 minecraft:orange_concrete
fill 262 252 598 264 252 598 minecraft:orange_concrete
fill 264 252 558 266 252 558 minecraft:orange_concrete
fill 265 252 583 266 253 583 minecraft:orange_concrete
fill 265 252 599 266 253 599 minecraft:yellow_concrete
fill 266 252 582 266 253 582 minecraft:red_concrete
fill 266 252 598 268 252 598 minecraft:orange_concrete
fill 267 252 578 269 252 578 minecraft:orange_concrete
fill 267 252 581 267 254 581 minecraft:red_concrete
fill 267 252 599 268 257 599 minecraft:red_concrete
fill 268 252 557 269 257 557 minecraft:red_concrete
fill 268 252 558 270 252 558 minecraft:orange_concrete
fill 268 252 580 268 254 580 minecraft:yellow_concrete
setblock 269 252 599 minecraft:yellow_concrete
fill 270 252 557 271 253 557 minecraft:yellow_concrete
fill 270 252 598 272 252 598 minecraft:orange_concrete
fill 271 252 575 271 253 576 minecraft:red_concrete
fill 272 252 558 274 252 558 minecraft:orange_concrete
fill 272 252 572 273 252 572 minecraft:yellow_concrete
fill 274 252 570 274 253 571 minecraft:yellow_concrete
fill 274 252 598 276 252 598 minecraft:orange_concrete
fill 276 252 558 276 252 560 minecraft:orange_concrete
fill 276 252 562 276 252 564 minecraft:orange_concrete
fill 276 252 566 276 252 568 minecraft:orange_concrete
fill 276 252 570 276 252 572 minecraft:orange_concrete
fill 276 252 574 276 252 576 minecraft:orange_concrete
fill 276 252 578 276 252 580 minecraft:orange_concrete
fill 276 252 582 276 252 584 minecraft:orange_concrete
fill 276 252 586 276 252 588 minecraft:orange_concrete
fill 276 252 590 276 252 592 minecraft:orange_concrete
fill 276 252 594 276 252 596 minecraft:orange_concrete
fill 277 252 557 277 257 557 minecraft:red_concrete
setblock 277 252 559 minecraft:yellow_concrete
fill 277 252 560 277 257 561 minecraft:red_concrete
fill 277 252 562 277 253 562 minecraft:yellow_concrete
fill 277 252 568 277 257 569 minecraft:red_concrete
fill 277 252 570 277 252 571 minecraft:yellow_concrete
fill 277 252 580 277 257 581 minecraft:red_concrete
fill 277 252 582 277 253 583 minecraft:yellow_concrete
fill 277 252 589 277 257 589 minecraft:red_concrete
fill 277 252 590 277 252 591 minecraft:yellow_concrete
fill 277 252 592 277 257 592 minecraft:red_concrete
fill 277 252 594 277 253 594 minecraft:yellow_concrete
fill 277 252 599 277 253 599 minecraft:yellow_concrete
fill 235 253 565 235 253 566 minecraft:yellow_concrete
setblock 235 253 569 minecraft:yellow_concrete
fill 235 253 570 235 256 570 minecraft:red_concrete
fill 235 253 581 235 255 581 minecraft:red_concrete
setblock 235 253 586 minecraft:yellow_concrete
setblock 235 253 597 minecraft:yellow_concrete
fill 236 253 570 237 254 570 minecraft:yellow_concrete
setblock 237 253 571 minecraft:yellow_concrete
fill 237 253 599 238 255 599 minecraft:red_concrete
setblock 239 253 571 minecraft:yellow_concrete
fill 240 253 575 240 254 575 minecraft:red_concrete
setblock 242 253 557 minecraft:yellow_concrete
setblock 242 253 575 minecraft:red_concrete
fill 242 253 578 244 253 578 minecraft:orange_concrete
fill 243 253 580 243 255 580 minecraft:yellow_concrete
fill 244 253 581 244 254 581 minecraft:yellow_concrete
setblock 245 253 580 minecraft:yellow_concrete
fill 245 253 582 245 255 582 minecraft:red_concrete
fill 245 253 583 245 255 583 minecraft:orange_concrete
fill 247 253 557 247 256 557 minecraft:red_concrete
fill 253 253 599 254 253 599 minecraft:yellow_concrete
fill 255 253 569 256 254 570 minecraft:red_concrete
fill 257 253 570 257 254 570 minecraft:red_concrete
setblock 257 253 599 minecraft:yellow_concrete
fill 258 253 557 258 256 557 minecraft:red_concrete
fill 258 253 599 258 256 599 minecraft:red_concrete
setblock 259 253 557 minecraft:yellow_concrete
fill 262 253 557 263 253 557 minecraft:yellow_concrete
setblock 267 253 580 minecraft:yellow_concrete
fill 267 253 582 267 255 582 minecraft:red_concrete
fill 267 253 583 267 255 583 minecraft:orange_concrete
fill 268 253 578 270 253 578 minecraft:orange_concrete
fill 268 253 581 268 254 581 minecraft:yellow_concrete
fill 269 253 580 269 255 580 minecraft:yellow_concrete
fill 269 253 599 269 256 599 minecraft:red_concrete
setblock 270 253 575 minecraft:red_concrete
fill 272 253 575 272 254 575 minecraft:red_concrete
setblock 273 253 571 minecraft:yellow_concrete
setblock 274 253 599 minecraft:yellow_concrete
fill 275 253 570 275 253 571 minecraft:yellow_concrete
fill 276 253 570 276 254 570 minecraft:yellow_concrete
fill 277 253 559 277 256 559 minecraft:red_concrete
setblock 277 253 563 minecraft:yellow_concrete
fill 277 253 570 277 256 570 minecraft:red_concrete
setblock 277 253 571 minecraft:yellow_concrete
setblock 277 253 574 minecraft:yellow_concrete
fill 277 253 590 277 256 591 minecraft:red_concrete
setblock 277 253 595 minecraft:yellow_concrete
fill 235 254 557 235 259 558 minecraft:red_concrete
fill 235 254 564 235 255 564 minecraft:yellow_concrete
fill 235 254 565 235 259 566 minecraft:red_concrete
setblock 235 254 567 minecraft:yellow_concrete
fill 235 254 569 235 259 569 minecraft:red_concrete
fill 235 254 575 235 255 576 minecraft:yellow_concrete
fill 235 254 577 235 259 578 minecraft:red_concrete
setblock 235 254 583 minecraft:red_concrete
fill 235 254 584 235 255 584 minecraft:yellow_concrete
fill 235 254 586 235 259 586 minecraft:red_concrete
fill 235 254 587 235 254 588 minecraft:yellow_concrete
fill 235 254 589 235 256 590 minecraft:red_concrete
fill 235 254 595 235 255 596 minecraft:yellow_concrete
fill 235 254 597 235 259 598 minecraft:red_concrete
setblock 235 254 599 minecraft:yellow_concrete
fill 236 254 599 236 257 599 minecraft:red_concrete
fill 238 254 557 239 259 557 minecraft:red_concrete
fill 239 254 574 239 255 575 minecraft:red_concrete
fill 240 254 557 241 254 557 minecraft:yellow_concrete
setblock 240 254 574 minecraft:red_concrete
setblock 241 254 575 minecraft:red_concrete
fill 241 254 578 243 254 578 minecraft:orange_concrete
fill 242 254 557 242 259 557 minecraft:red_concrete
fill 243 254 581 243 255 581 minecraft:yellow_concrete
fill 243 254 599 244 255 599 minecraft:yellow_concrete
fill 244 254 582 244 256 582 minecraft:red_concrete
fill 245 254 584 245 256 584 minecraft:orange_concrete
fill 245 254 599 246 259 599 minecraft:red_concrete
fill 246 254 582 246 254 583 minecraft:orange_concrete
fill 250 254 557 251 259 557 minecraft:red_concrete
fill 252 254 557 253 255 557 minecraft:yellow_concrete
fill 252 254 599 252 255 599 minecraft:yellow_concrete
fill 253 254 599 254 259 599 minecraft:red_concrete
setblock 255 254 599 minecraft:yellow_concrete
fill 257 254 599 257 259 599 minecraft:red_concrete
fill 259 254 557 259 259 557 minecraft:red_concrete
setblock 261 254 557 minecraft:yellow_concrete
fill 262 254 557 263 259 557 minecraft:red_concrete
fill 263 254 599 264 255 599 minecraft:yellow_concrete
fill 264 254 557 264 255 557 minecraft:yellow_concrete
fill 265 254 599 266 259 599 minecraft:red_concrete
fill 266 254 582 266 254 583 minecraft:orange_concrete
fill 267 254 584 267 256 584 minecraft:orange_concrete
fill 268 254 582 268 256 582 minecraft:red_concrete
fill 269 254 578 271 254 578 minecraft:orange_concrete
fill 269 254 581 269 255 581 minecraft:yellow_concrete
fill 270 254 557 271 259 557 minecraft:red_concrete
setblock 271 254 575 minecraft:red_concrete
fill 272 254 557 273 254 557 minecraft:yellow_concrete
fill 272 254 574 273 254 574 minecraft:red_concrete
fill 273 254 575 273 255 575 minecraft:red_concrete
fill 274 254 599 274 259 599 minecraft:red_concrete
setblock 275 254 570 minecraft:yellow_concrete
fill 275 254 599 276 254 599 minecraft:yellow_concrete
fill 277 254 562 277 259 563 minecraft:red_concrete
fill 277 254 564 277 255 565 minecraft:yellow_concrete
fill 277 254 571 277 259 571 minecraft:red_concrete
fill 277 254 572 277 254 573 minecraft:yellow_concrete
fill 277 254 574 277 259 574 minecraft:red_concrete
fill 277 254 576 277 255 576 minecraft:yellow_concrete
fill 277 254 582 277 259 583 minecraft:red_concrete
fill 277 254 584 277 255 585 minecraft:yellow_concrete
setblock 277 254 593 minecraft:yellow_concrete
fill 277 254 594 277 259 595 minecraft:red_concrete
fill 277 254 596 277 255 597 minecraft:yellow_concrete
fill 277 254 599 277 259 599 minecraft:red_concrete
setblock 235 255 563 minecraft:yellow_concrete
fill 235 255 567 235 258 567 minecraft:red_concrete
setblock 235 255 583 minecraft:yellow_concrete
setblock 235 255 587 minecraft:yellow_concrete
fill 235 255 588 235 258 588 minecraft:red_concrete
fill 235 255 599 235 257 599 minecraft:red_concrete
fill 237 255 574 238 256 574 minecraft:red_concrete
fill 238 255 575 238 256 575 minecraft:red_concrete
fill 240 255 557 240 258 557 minecraft:red_concrete
fill 240 255 578 242 255 578 minecraft:orange_concrete
setblock 240 255 599 minecraft:yellow_concrete
setblock 241 255 557 minecraft:yellow_concrete
fill 242 255 580 242 256 581 minecraft:yellow_concrete
fill 243 255 582 243 257 583 minecraft:red_concrete
fill 244 255 557 245 255 557 minecraft:yellow_concrete
fill 244 255 583 244 256 583 minecraft:red_concrete
fill 244 255 584 244 257 584 minecraft:orange_concrete
setblock 246 255 583 minecraft:orange_concrete
setblock 251 255 599 minecraft:yellow_concrete
fill 255 255 587 256 256 588 minecraft:orange_concrete
fill 255 255 599 255 258 599 minecraft:red_concrete
fill 261 255 557 261 258 557 minecraft:red_concrete
setblock 265 255 557 minecraft:yellow_concrete
setblock 266 255 583 minecraft:orange_concrete
fill 268 255 583 269 256 583 minecraft:red_concrete
fill 268 255 584 268 257 584 minecraft:orange_concrete
fill 269 255 582 269 257 582 minecraft:red_concrete
fill 270 255 578 272 255 578 minecraft:orange_concrete
fill 270 255 580 270 256 581 minecraft:yellow_concrete
fill 271 255 599 272 255 599 minecraft:yellow_concrete
fill 272 255 557 272 258 557 minecraft:red_concrete
setblock 273 255 557 minecraft:yellow_concrete
fill 273 255 574 275 255 574 minecraft:red_concrete
fill 274 255 575 274 256 575 minecraft:red_concrete
setblock 275 255 599 minecraft:yellow_concrete
setblock 276 255 557 minecraft:yellow_concrete
fill 276 255 599 276 258 599 minecraft:red_concrete
fill 277 255 572 277 258 573 minecraft:red_concrete
setblock 277 255 577 minecraft:yellow_concrete
setblock 277 255 588 minecraft:yellow_concrete
fill 277 255 593 277 258 593 minecraft:red_concrete
fill 235 256 561 235 257 562 minecraft:yellow_concrete
fill 235 256 563 235 261 564 minecraft:red_concrete
fill 235 256 573 235 256 574 minecraft:yellow_concrete
fill 235 256 575 235 261 576 minecraft:red_concrete
fill 235 256 581 235 257 582 minecraft:yellow_concrete
fill 235 256 583 235 261 584 minecraft:red_concrete
setblock 235 256 585 minecraft:yellow_concrete
fill 235 256 587 235 258 587 minecraft:red_concrete
fill 235 256 593 235 257 594 minecraft:yellow_concrete
fill 235 256 595 235 261 596 minecraft:red_concrete
fill 236 256 574 236 257 574 minecraft:red_concrete
setblock 237 256 575 minecraft:red_concrete
setblock 237 256 599 minecraft:red_concrete
fill 238 256 599 238 257 599 minecraft:yellow_concrete
fill 239 256 578 241 256 578 minecraft:orange_concrete
fill 240 256 599 240 261 599 minecraft:red_concrete
fill 241 256 557 241 261 557 minecraft:red_concrete
fill 241 256 580 241 257 581 minecraft:yellow_concrete
fill 241 256 599 242 256 599 minecraft:yellow_concrete
setblock 243 256 557 minecraft:yellow_concrete
fill 243 256 599 244 258 599 minecraft:red_concrete
fill 244 256 557 245 261 557 minecraft:red_concrete
fill 244 256 585 244 258 585 minecraft:orange_concrete
fill 246 256 557 246 257 557 minecraft:yellow_concrete
fill 249 256 599 250 257 599 minecraft:yellow_concrete
fill 251 256 599 252 261 599 minecraft:red_concrete
fill 252 256 557 253 261 557 minecraft:red_concrete
fill 254 256 557 255 256 557 minecraft:yellow_concrete
fill 258 256 589 258 257 589 minecraft:yellow_concrete
fill 261 256 599 262 256 599 minecraft:yellow_concrete
fill 263 256 599 264 261 599 minecraft:red_concrete
fill 264 256 557 265 261 557 minecraft:red_concrete
fill 266 256 557 267 257 557 minecraft:yellow_concrete
fill 267 256 565 268 257 566 minecraft:yellow_concrete
fill 268 256 585 268 258 585 minecraft:orange_concrete
fill 270 256 599 270 257 599 minecraft:yellow_concrete
fill 271 256 578 273 256 578 minecraft:orange_concrete
fill 271 256 580 271 257 581 minecraft:yellow_concrete
fill 271 256 599 272 261 599 minecraft:red_concrete
fill 273 256 557 273 261 557 minecraft:red_concrete
setblock 273 256 599 minecraft:yellow_concrete
fill 274 256 557 275 256 557 minecraft:yellow_concrete
fill 274 256 574 276 256 574 minecraft:red_concrete
setblock 275 256 575 minecraft:red_concrete
fill 275 256 599 275 261 599 minecraft:red_concrete
fill 276 256 557 276 261 557 minecraft:red_concrete
fill 277 256 558 277 257 558 minecraft:yellow_concrete
fill 277 256 564 277 261 565 minecraft:red_concrete
fill 277 256 566 277 257 567 minecraft:yellow_concrete
setblock 277 256 575 minecraft:yellow_concrete
fill 277 256 576 277 261 577 minecraft:red_concrete
fill 277 256 578 277 257 579 minecraft:yellow_concrete
fill 277 256 584 277 261 585 minecraft:red_concrete
fill 277 256 586 277 256 587 minecraft:yellow_concrete
fill 277 256 588 277 261 588 minecraft:red_concrete
fill 277 256 596 277 261 597 minecraft:red_concrete
fill 277 256 598 277 257 598 minecraft:yellow_concrete
setblock 235 257 570 minecraft:yellow_concrete
setblock 235 257 573 minecraft:yellow_concrete
fill 235 257 574 235 260 574 minecraft:red_concrete
fill 235 257 585 235 260 585 minecraft:red_concrete
fill 235 257 589 235 259 589 minecraft:red_concrete
setblock 235 257 590 minecraft:yellow_concrete
setblock 237 257 574 minecraft:red_concrete
setblock 237 257 599 minecraft:yellow_concrete
fill 238 257 578 240 257 578 minecraft:orange_concrete
fill 240 257 581 240 259 581 minecraft:yellow_concrete
setblock 241 257 599 minecraft:yellow_concrete
setblock 242 257 581 minecraft:yellow_concrete
fill 242 257 583 242 259 583 minecraft:red_concrete
fill 242 257 599 242 260 599 minecraft:red_concrete
fill 243 257 557 243 260 557 minecraft:red_concrete
fill 243 257 584 243 258 585 minecraft:orange_concrete
setblock 247 257 557 minecraft:yellow_concrete
fill 254 257 557 254 260 557 minecraft:red_concrete
setblock 255 257 557 minecraft:yellow_concrete
setblock 258 257 557 minecraft:yellow_concrete
setblock 258 257 599 minecraft:yellow_concrete
setblock 261 257 599 minecraft:yellow_concrete
fill 262 257 599 262 260 599 minecraft:red_concrete
fill 269 257 583 270 258 583 minecraft:red_concrete
fill 269 257 584 269 258 585 minecraft:orange_concrete
setblock 269 257 599 minecraft:yellow_concrete
setblock 270 257 581 minecraft:yellow_concrete
fill 272 257 578 274 257 578 minecraft:orange_concrete
fill 272 257 581 272 259 581 minecraft:yellow_concrete
fill 273 257 599 273 260 599 minecraft:red_concrete
fill 274 257 557 275 260 557 minecraft:red_concrete
fill 275 257 574 276 257 574 minecraft:red_concrete
setblock 277 257 559 minecraft:yellow_concrete
setblock 277 257 570 minecraft:yellow_concrete
fill 277 257 575 277 260 575 minecraft:red_concrete
fill 277 257 586 277 260 586 minecraft:red_concrete
setblock 277 257 587 minecraft:yellow_concrete
fill 277 257 590 277 257 591 minecraft:yellow_concrete
fill 235 258 559 235 259 560 minecraft:yellow_concrete
fill 235 258 561 235 263 562 minecraft:red_concrete
fill 235 258 568 235 259 568 minecraft:yellow_concrete
fill 235 258 570 235 263 570 minecraft:red_concrete
fill 235 258 571 235 258 572 minecraft:yellow_concrete
fill 235 258 573 235 263 573 minecraft:red_concrete
fill 235 258 579 235 259 580 minecraft:yellow_concrete
fill 235 258 581 235 263 582 minecraft:red_concrete
fill 235 258 590 235 259 590 minecraft:red_concrete
fill 235 258 591 235 258 592 minecraft:yellow_concrete
fill 235 258 593 235 263 594 minecraft:red_concrete
fill 235 258 599 236 259 599 minecraft:yellow_concrete
fill 236 258 557 237 258 557 minecraft:yellow_concrete
fill 236 258 558 238 258 558 minecraft:orange_concrete
fill 236 258 560 236 258 562 minecraft:orange_concrete
fill 236 258 564 236 258 566 minecraft:orange_concrete
fill 236 258 568 236 258 570 minecraft:orange_concrete
fill 236 258 572 236 258 574 minecraft:orange_concrete
fill 236 258 576 236 258 578 minecraft:orange_concrete
fill 236 258 580 236 258 582 minecraft:orange_concrete
fill 236 258 584 236 258 586 minecraft:orange_concrete
fill 236 258 588 236 258 590 minecraft:orange_concrete
fill 236 258 592 236 258 594 minecraft:orange_concrete
fill 236 258 596 236 258 598 minecraft:orange_concrete
fill 237 258 578 239 258 578 minecraft:orange_concrete
fill 237 258 599 238 263 599 minecraft:red_concrete
setblock 238 258 560 minecraft:light[level=14]
setblock 238 258 568 minecraft:light[level=14]
setblock 238 258 576 minecraft:light[level=14]
setblock 238 258 584 minecraft:light[level=14]
setblock 238 258 592 minecraft:light[level=14]
fill 238 258 598 240 258 598 minecraft:orange_concrete
fill 239 258 581 239 260 581 minecraft:yellow_concrete
setblock 239 258 599 minecraft:yellow_concrete
fill 240 258 558 242 258 558 minecraft:orange_concrete
fill 240 258 582 240 259 582 minecraft:yellow_concrete
setblock 241 258 581 minecraft:yellow_concrete
fill 241 258 583 241 260 584 minecraft:red_concrete
fill 241 258 599 241 260 599 minecraft:red_concrete
fill 242 258 584 242 259 584 minecraft:red_concrete
fill 242 258 585 242 260 585 minecraft:orange_concrete
fill 242 258 598 244 258 598 minecraft:orange_concrete
setblock 243 258 583 minecraft:red_concrete
fill 243 258 586 243 259 586 minecraft:orange_concrete
fill 244 258 558 246 258 558 minecraft:orange_concrete
fill 244 258 586 244 259 586 minecraft:yellow_concrete
fill 246 258 557 247 263 557 minecraft:red_concrete
setblock 246 258 560 minecraft:light[level=14]
setblock 246 258 568 minecraft:light[level=14]
setblock 246 258 576 minecraft:light[level=14]
setblock 246 258 584 minecraft:light[level=14]
setblock 246 258 592 minecraft:light[level=14]
fill 246 258 598 248 258 598 minecraft:orange_concrete
fill 247 258 599 248 259 599 minecraft:yellow_concrete
fill 248 258 557 249 259 557 minecraft:yellow_concrete
fill 248 258 558 250 258 558 minecraft:orange_concrete
fill 249 258 599 250 263 599 minecraft:red_concrete
fill 250 258 598 252 258 598 minecraft:orange_concrete
fill 252 258 558 254 258 558 minecraft:orange_concrete
setblock 254 258 560 minecraft:light[level=14]
setblock 254 258 568 minecraft:light[level=14]
setblock 254 258 576 minecraft:light[level=14]
setblock 254 258 584 minecraft:light[level=14]
setblock 254 258 592 minecraft:light[level=14]
fill 254 258 598 256 258 598 minecraft:orange_concrete
fill 255 258 557 255 263 557 minecraft:red_concrete
fill 256 258 557 257 258 557 minecraft:yellow_concrete
fill 256 258 558 258 258 558 minecraft:orange_concrete
fill 256 258 599 256 259 599 minecraft:yellow_concrete
fill 258 258 557 258 263 557 minecraft:red_concrete
fill 258 258 598 260 258 598 minecraft:orange_concrete
fill 258 258 599 258 263 599 minecraft:red_concrete
fill 259 258 599 260 258 599 minecraft:yellow_concrete
fill 260 258 557 260 259 557 minecraft:yellow_concrete
fill 260 258 558 262 258 558 minecraft:orange_concrete
fill 261 258 599 261 263 599 minecraft:red_concrete
setblock 262 258 560 minecraft:light[level=14]
setblock 262 258 568 minecraft:light[level=14]
setblock 262 258 576 minecraft:light[level=14]
setblock 262 258 584 minecraft:light[level=14]
setblock 262 258 592 minecraft:light[level=14]
fill 262 258 598 264 258 598 minecraft:orange_concrete
fill 264 258 558 266 258 558 minecraft:orange_concrete
fill 266 258 557 267 263 557 minecraft:red_concrete
fill 266 258 598 268 258 598 minecraft:orange_concrete
fill 267 258 599 268 259 599 minecraft:yellow_concrete
fill 268 258 557 269 259 557 minecraft:yellow_concrete
fill 268 258 558 270 258 558 minecraft:orange_concrete
fill 269 258 586 269 259 586 minecraft:orange_concrete
fill 269 258 599 270 263 599 minecraft:red_concrete
setblock 270 258 560 minecraft:light[level=14]
setblock 270 258 568 minecraft:light[level=14]
setblock 270 258 576 minecraft:light[level=14]
fill 270 258 584 271 259 584 minecraft:red_concrete
fill 270 258 585 270 260 585 minecraft:orange_concrete
setblock 270 258 592 minecraft:light[level=14]
fill 270 258 598 272 258 598 minecraft:orange_concrete
setblock 271 258 581 minecraft:yellow_concrete
fill 271 258 583 271 260 583 minecraft:red_concrete
fill 272 258 558 274 258 558 minecraft:orange_concrete
fill 272 258 582 272 259 582 minecraft:yellow_concrete
fill 273 258 578 276 258 578 minecraft:orange_concrete
fill 273 258 581 273 260 581 minecraft:yellow_concrete
fill 274 258 598 276 258 598 minecraft:orange_concrete
fill 276 258 558 276 258 560 minecraft:orange_concrete
fill 276 258 562 276 258 564 minecraft:orange_concrete
fill 276 258 566 276 258 568 minecraft:orange_concrete
fill 276 258 570 276 258 572 minecraft:orange_concrete
fill 276 258 574 276 258 576 minecraft:orange_concrete
fill 276 258 579 276 258 580 minecraft:orange_concrete
fill 276 258 582 276 258 584 minecraft:orange_concrete
fill 276 258 586 276 258 588 minecraft:orange_concrete
fill 276 258 590 276 258 592 minecraft:orange_concrete
fill 276 258 594 276 258 596 minecraft:orange_concrete
setblock 277 258 557 minecraft:yellow_concrete
fill 277 258 558 277 263 559 minecraft:red_concrete
fill 277 258 560 277 259 561 minecraft:yellow_concrete
fill 277 258 566 277 263 567 minecraft:red_concrete
fill 277 258 568 277 258 569 minecraft:yellow_concrete
fill 277 258 570 277 263 570 minecraft:red_concrete
fill 277 258 578 277 263 579 minecraft:red_concrete
fill 277 258 580 277 259 581 minecraft:yellow_concrete
fill 277 258 587 277 263 587 minecraft:red_concrete
setblock 277 258 589 minecraft:yellow_concrete
fill 277 258 590 277 263 591 minecraft:red_concrete
fill 277 258 592 277 259 592 minecraft:yellow_concrete
fill 277 258 598 277 263 598 minecraft:red_concrete
setblock 235 259 567 minecraft:yellow_concrete
fill 235 259 571 235 261 572 minecraft:red_concrete
fill 235 259 587 235 259 588 minecraft:yellow_concrete
setblock 235 259 591 minecraft:yellow_concrete
fill 235 259 592 235 262 592 minecraft:red_concrete
fill 236 259 557 236 262 557 minecraft:red_concrete
fill 236 259 578 238 259 578 minecraft:orange_concrete
setblock 237 259 557 minecraft:yellow_concrete
fill 239 259 582 239 260 582 minecraft:yellow_concrete
fill 239 259 599 239 262 599 minecraft:red_concrete
setblock 240 259 557 minecraft:yellow_concrete
fill 240 259 584 240 262 584 minecraft:red_concrete
fill 242 259 586 242 261 586 minecraft:orange_concrete
setblock 243 259 585 minecraft:orange_concrete
fill 243 259 599 243 261 599 minecraft:red_concrete
setblock 244 259 599 minecraft:yellow_concrete
setblock 255 259 599 minecraft:yellow_concrete
fill 256 259 557 257 262 557 minecraft:red_concrete
fill 259 259 599 260 262 599 minecraft:red_concrete
setblock 261 259 557 minecraft:yellow_concrete
setblock 269 259 585 minecraft:orange_concrete
setblock 270 259 583 minecraft:red_concrete
fill 270 259 586 270 261 586 minecraft:orange_concrete
setblock 272 259 557 minecraft:yellow_concrete
fill 272 259 584 272 262 584 minecraft:red_concrete
fill 273 259 582 273 260 582 minecraft:yellow_concrete
fill 274 259 578 276 259 578 minecraft:orange_concrete
setblock 276 259 599 minecraft:yellow_concrete
fill 277 259 557 277 262 557 minecraft:red_concrete
fill 277 259 568 277 262 568 minecraft:red_concrete
setblock 277 259 569 minecraft:yellow_concrete
fill 277 259 572 277 259 573 minecraft:yellow_concrete
fill 277 259 589 277 262 589 minecraft:red_concrete
setblock 277 259 593 minecraft:yellow_concrete
fill 235 260 557 235 260 558 minecraft:yellow_concrete
fill 235 260 559 235 265 560 minecraft:red_concrete
fill 235 260 565 235 261 566 minecraft:yellow_concrete
fill 235 260 567 235 265 568 minecraft:red_concrete
setblock 235 260 569 minecraft:yellow_concrete
fill 235 260 577 235 261 578 minecraft:yellow_concrete
fill 235 260 579 235 265 580 minecraft:red_concrete
fill 235 260 586 235 261 586 minecraft:yellow_concrete
fill 235 260 587 235 261 588 minecraft:red_concrete
fill 235 260 589 235 260 590 minecraft:yellow_concrete
fill 235 260 591 235 265 591 minecraft:red_concrete
fill 235 260 597 235 261 598 minecraft:yellow_concrete
fill 235 260 599 236 265 599 minecraft:red_concrete
fill 236 260 578 237 260 578 minecraft:orange_concrete
fill 237 260 557 237 265 557 minecraft:red_concrete
fill 238 260 557 239 260 557 minecraft:yellow_concrete
fill 238 260 581 238 261 582 minecraft:yellow_concrete
fill 240 260 557 240 265 557 minecraft:red_concrete
fill 240 260 585 240 262 585 minecraft:red_concrete
fill 241 260 586 241 262 586 minecraft:orange_concrete
fill 242 260 557 242 261 557 minecraft:yellow_concrete
fill 244 260 572 245 261 572 minecraft:shroomlight
fill 244 260 599 244 265 599 minecraft:red_concrete
fill 245 260 599 246 260 599 minecraft:yellow_concrete
fill 247 260 599 248 265 599 minecraft:red_concrete
fill 248 260 557 249 265 557 minecraft:red_concrete
fill 250 260 557 251 261 557 minecraft:yellow_concrete
fill 253 260 599 254 261 599 minecraft:yellow_concrete
fill 255 260 599 256 265 599 minecraft:red_concrete
setblock 257 260 599 minecraft:yellow_concrete
setblock 259 260 557 minecraft:yellow_concrete
fill 260 260 557 261 265 557 minecraft:red_concrete
fill 262 260 557 263 261 557 minecraft:yellow_concrete
fill 265 260 599 266 261 599 minecraft:yellow_concrete
fill 267 260 599 268 265 599 minecraft:red_concrete
fill 268 260 557 269 265 557 minecraft:red_concrete
fill 270 260 557 271 260 557 minecraft:yellow_concrete
setblock 271 260 584 minecraft:red_concrete
fill 271 260 586 271 262 586 minecraft:orange_concrete
fill 272 260 557 272 265 557 minecraft:red_concrete
fill 272 260 585 272 262 585 minecraft:red_concrete
fill 274 260 581 274 261 582 minecraft:yellow_concrete
fill 274 260 599 274 261 599 minecraft:yellow_concrete
fill 275 260 578 276 260 578 minecraft:orange_concrete
fill 276 260 599 276 265 599 minecraft:red_concrete
fill 277 260 560 277 265 561 minecraft:red_concrete
fill 277 260 562 277 261 563 minecraft:yellow_concrete
fill 277 260 569 277 265 569 minecraft:red_concrete
setblock 277 260 571 minecraft:yellow_concrete
fill 277 260 572 277 265 573 minecraft:red_concrete
fill 277 260 574 277 261 574 minecraft:yellow_concrete
fill 277 260 580 277 265 581 minecraft:red_concrete
fill 277 260 582 277 260 583 minecraft:yellow_concrete
fill 277 260 592 277 265 593 minecraft:red_concrete
fill 277 260 594 277 261 595 minecraft:yellow_concrete
setblock 277 260 599 minecraft:yellow_concrete
setblock 235 261 557 minecraft:yellow_concrete
fill 235 261 558 235 264 558 minecraft:red_concrete
fill 235 261 569 235 263 569 minecraft:red_concrete
setblock 235 261 574 minecraft:yellow_concrete
setblock 235 261 585 minecraft:yellow_concrete
fill 235 261 589 235 263 590 minecraft:red_concrete
fill 237 261 581 237 262 582 minecraft:yellow_concrete
fill 238 261 557 239 264 557 minecraft:red_concrete
fill 239 261 584 239 262 585 minecraft:red_concrete
fill 241 261 587 241 263 587 minecraft:orange_concrete
fill 241 261 599 242 261 599 minecraft:yellow_concrete
setblock 243 261 557 minecraft:yellow_concrete
setblock 245 261 599 minecraft:yellow_concrete
fill 246 261 599 246 264 599 minecraft:red_concrete
setblock 254 261 557 minecraft:yellow_concrete
fill 257 261 599 257 264 599 minecraft:red_concrete
fill 259 261 557 259 264 557 minecraft:red_concrete
setblock 262 261 599 minecraft:yellow_concrete
fill 270 261 557 270 264 557 minecraft:red_concrete
setblock 271 261 557 minecraft:yellow_concrete
fill 271 261 587 271 263 587 minecraft:orange_concrete
fill 273 261 584 273 262 585 minecraft:red_concrete
setblock 273 261 599 minecraft:yellow_concrete
fill 274 261 557 275 261 557 minecraft:yellow_concrete
fill 275 261 581 275 262 582 minecraft:yellow_concrete
fill 277 261 571 277 264 571 minecraft:red_concrete
setblock 277 261 575 minecraft:yellow_concrete
fill 277 261 582 277 264 582 minecraft:red_concrete
setblock 277 261 583 minecraft:yellow_concrete
setblock 277 261 586 minecraft:yellow_concrete
fill 277 261 599 277 264 599 minecraft:red_concrete
fill 235 262 557 235 267 557 minecraft:red_concrete
fill 235 262 563 235 263 564 minecraft:yellow_concrete
fill 235 262 565 235 267 566 minecraft:red_concrete
setblock 235 262 571 minecraft:red_concrete
fill 235 262 572 235 263 572 minecraft:yellow_concrete
fill 235 262 574 235 267 574 minecraft:red_concrete
fill 235 262 575 235 262 576 minecraft:yellow_concrete
fill 235 262 577 235 264 578 minecraft:red_concrete
fill 235 262 583 235 263 584 minecraft:yellow_concrete
fill 235 262 585 235 267 586 minecraft:red_concrete
setblock 235 262 587 minecraft:yellow_concrete
fill 235 262 588 235 265 588 minecraft:red_concrete
fill 235 262 595 235 263 596 minecraft:yellow_concrete
fill 235 262 597 235 267 598 minecraft:red_concrete
fill 236 262 582 236 263 582 minecraft:yellow_concrete
setblock 238 262 582 minecraft:yellow_concrete
fill 238 262 585 238 264 585 minecraft:red_concrete
fill 240 262 587 240 264 587 minecraft:orange_concrete
fill 240 262 599 240 263 599 minecraft:yellow_concrete
setblock 241 262 557 minecraft:yellow_concrete
fill 241 262 599 242 267 599 minecraft:red_concrete
fill 242 262 557 243 267 557 minecraft:red_concrete
setblock 243 262 599 minecraft:yellow_concrete
fill 244 262 557 245 263 557 minecraft:yellow_concrete
fill 245 262 599 245 267 599 minecraft:red_concrete
fill 250 262 557 251 267 557 minecraft:red_concrete
fill 251 262 599 252 263 599 minecraft:yellow_concrete
fill 252 262 557 253 262 557 minecraft:yellow_concrete
fill 253 262 599 254 267 599 minecraft:red_concrete
fill 254 262 557 254 267 557 minecraft:red_concrete
fill 262 262 557 263 267 557 minecraft:red_concrete
fill 262 262 599 262 267 599 minecraft:red_concrete
fill 263 262 599 264 262 599 minecraft:yellow_concrete
fill 264 262 557 265 263 557 minecraft:yellow_concrete
fill 265 262 599 266 267 599 minecraft:red_concrete
fill 271 262 557 271 267 557 minecraft:red_concrete
fill 271 262 599 272 263 599 minecraft:yellow_concrete
fill 272 262 587 272 264 587 minecraft:orange_concrete
setblock 273 262 557 minecraft:yellow_concrete
fill 273 262 599 274 267 599 minecraft:red_concrete
fill 274 262 557 275 267 557 minecraft:red_concrete
setblock 274 262 582 minecraft:yellow_concrete
fill 274 262 585 274 264 585 minecraft:red_concrete
setblock 275 262 599 minecraft:yellow_concrete
fill 276 262 557 276 263 557 minecraft:yellow_concrete
fill 276 262 582 276 263 582 minecraft:yellow_concrete
fill 277 262 562 277 267 563 minecraft:red_concrete
fill 277 262 564 277 262 565 minecraft:yellow_concrete
fill 277 262 574 277 267 575 minecraft:red_concrete
fill 277 262 576 277 263 577 minecraft:yellow_concrete
fill 277 262 583 277 267 583 minecraft:red_concrete
fill 277 262 584 277 262 585 minecraft:yellow_concrete
fill 277 262 586 277 267 586 minecraft:red_concrete
fill 277 262 588 277 263 588 minecraft:yellow_concrete
fill 277 262 594 277 267 595 minecraft:red_concrete
fill 277 262 596 277 263 597 minecraft:yellow_concrete
setblock 235 263 571 minecraft:yellow_concrete
setblock 235 263 575 minecraft:yellow_concrete
fill 235 263 576 235 266 576 minecraft:red_concrete
fill 235 263 587 235 265 587 minecraft:red_concrete
setblock 235 263 592 minecraft:yellow_concrete
setblock 236 263 557 minecraft:yellow_concrete
setblock 237 263 582 minecraft:yellow_concrete
fill 238 263 586 238 264 586 minecraft:red_concrete
setblock 239 263 585 minecraft:red_concrete
fill 239 263 587 239 264 588 minecraft:orange_concrete
setblock 239 263 599 minecraft:yellow_concrete
fill 240 263 588 240 264 588 minecraft:orange_concrete
fill 241 263 557 241 266 557 minecraft:red_concrete
fill 243 263 599 243 266 599 minecraft:red_concrete
fill 252 263 557 252 266 557 minecraft:red_concrete
setblock 253 263 557 minecraft:yellow_concrete
fill 256 263 557 257 263 557 minecraft:yellow_concrete
fill 259 263 599 260 263 599 minecraft:yellow_concrete
setblock 263 263 599 minecraft:yellow_concrete
fill 264 263 599 264 266 599 minecraft:red_concrete
fill 269 263 587 269 264 587 minecraft:yellow_concrete
fill 272 263 588 273 264 588 minecraft:orange_concrete
fill 273 263 557 273 266 557 minecraft:red_concrete
setblock 273 263 585 minecraft:red_concrete
fill 273 263 587 273 264 587 minecraft:orange_concrete
fill 274 263 586 274 264 586 minecraft:red_concrete
setblock 275 263 582 minecraft:yellow_concrete
fill 275 263 599 275 266 599 minecraft:red_concrete
setblock 277 263 557 minecraft:yellow_concrete
fill 277 263 564 277 266 564 minecraft:red_concrete
setblock 277 263 565 minecraft:yellow_concrete
setblock 277 263 568 minecraft:yellow_concrete
fill 277 263 584 277 266 585 minecraft:red_concrete
setblock 277 263 589 minecraft:yellow_concrete
fill 235 264 561 235 264 562 minecraft:yellow_concrete
fill 235 264 563 235 269 564 minecraft:red_concrete
fill 235 264 569 235 265 570 minecraft:yellow_concrete
fill 235 264 571 235 269 572 minecraft:red_concrete
setblock 235 264 573 minecraft:yellow_concrete
fill 235 264 575 235 266 575 minecraft:red_concrete
fill 235 264 581 235 265 582 minecraft:yellow_concrete
fill 235 264 583 235 269 584 minecraft:red_concrete
setblock 235 264 589 minecraft:red_concrete
fill 235 264 590 235 265 590 minecraft:yellow_concrete
fill 235 264 592 235 269 592 minecraft:red_concrete
fill 235 264 593 235 264 594 minecraft:yellow_concrete
fill 235 264 595 235 266 596 minecraft:red_concrete
fill 236 264 557 236 269 557 minecraft:red_concrete
fill 236 264 558 238 264 558 minecraft:orange_concrete
fill 236 264 560 236 264 562 minecraft:orange_concrete
fill 236 264 564 236 264 566 minecraft:orange_concrete
fill 236 264 568 236 264 570 minecraft:orange_concrete
fill 236 264 572 236 264 574 minecraft:orange_concrete
fill 236 264 576 236 264 578 minecraft:orange_concrete
fill 236 264 580 236 264 582 minecraft:orange_concrete
fill 236 264 584 236 264 586 minecraft:orange_concrete
fill 236 264 588 236 264 590 minecraft:orange_concrete
fill 236 264 592 236 264 594 minecraft:orange_concrete
fill 236 264 596 236 264 598 minecraft:orange_concrete
fill 237 264 585 237 265 586 minecraft:red_concrete
fill 237 264 599 238 265 599 minecraft:yellow_concrete
fill 238 264 598 240 264 598 minecraft:orange_concrete
fill 239 264 599 240 269 599 minecraft:red_concrete
fill 240 264 558 242 264 558 minecraft:orange_concrete
fill 242 264 598 244 264 598 minecraft:orange_concrete
fill 244 264 557 245 269 557 minecraft:red_concrete
fill 244 264 558 246 264 558 minecraft:orange_concrete
fill 246 264 557 247 265 557 minecraft:yellow_concrete
fill 246 264 598 248 264 598 minecraft:orange_concrete
fill 248 264 558 250 264 558 minecraft:orange_concrete
fill 249 264 599 250 264 599 minecraft:yellow_concrete
fill 250 264 598 252 264 598 minecraft:orange_concrete
fill 251 264 599 252 269 599 minecraft:red_concrete
fill 252 264 558 254 264 558 minecraft:orange_concrete
fill 253 264 557 253 269 557 minecraft:red_concrete
fill 254 264 598 256 264 598 minecraft:orange_concrete
setblock 255 264 557 minecraft:yellow_concrete
fill 256 264 557 257 269 557 minecraft:red_concrete
fill 256 264 558 258 264 558 minecraft:orange_concrete
fill 258 264 557 258 265 557 minecraft:yellow_concrete
fill 258 264 598 260 264 598 minecraft:orange_concrete
fill 258 264 599 258 265 599 minecraft:yellow_concrete
fill 259 264 599 260 269 599 minecraft:red_concrete
fill 260 264 558 262 264 558 minecraft:orange_concrete
setblock 261 264 599 minecraft:yellow_concrete
fill 262 264 598 264 264 598 minecraft:orange_concrete
fill 263 264 599 263 269 599 minecraft:red_concrete
fill 264 264 557 265 269 557 minecraft:red_concrete
fill 264 264 558 266 264 558 minecraft:orange_concrete
fill 266 264 557 267 264 557 minecraft:yellow_concrete
fill 266 264 598 268 264 598 minecraft:orange_concrete
fill 268 264 558 270 264 558 minecraft:orange_concrete
fill 269 264 599 270 265 599 minecraft:yellow_concrete
fill 270 264 598 272 264 598 minecraft:orange_concrete
fill 271 264 599 272 269 599 minecraft:red_concrete
fill 272 264 558 274 264 558 minecraft:orange_concrete
fill 274 264 598 276 264 598 minecraft:orange_concrete
fill 275 264 585 275 265 586 minecraft:red_concrete
fill 276 264 557 277 269 557 minecraft:red_concrete
fill 276 264 558 276 264 560 minecraft:orange_concrete
fill 276 264 562 276 264 564 minecraft:orange_concrete
fill 276 264 566 276 264 568 minecraft:orange_concrete
fill 276 264 570 276 264 572 minecraft:orange_concrete
fill 276 264 574 276 264 576 minecraft:orange_concrete
fill 276 264 578 276 264 580 minecraft:orange_concrete
fill 276 264 582 276 264 584 minecraft:orange_concrete
fill 276 264 586 276 264 588 minecraft:orange_concrete
fill 276 264 590 276 264 592 minecraft:orange_concrete
fill 276 264 594 276 264 596 minecraft:orange_concrete
fill 277 264 558 277 265 559 minecraft:yellow_concrete
fill 277 264 565 277 269 565 minecraft:red_concrete
fill 277 264 566 277 264 567 minecraft:yellow_concrete
fill 277 264 568 277 269 568 minecraft:red_concrete
fill 277 264 570 277 265 570 minecraft:yellow_concrete
fill 277 264 576 277 269 577 minecraft:red_concrete
fill 277 264 578 277 265 579 minecraft:yellow_concrete
setblock 277 264 587 minecraft:yellow_concrete
fill 277 264 588 277 269 589 minecraft:red_concrete
fill 277 264 590 277 265 591 minecraft:yellow_concrete
fill 277 264 596 277 269 597 minecraft:red_concrete
setblock 277 264 598 minecraft:yellow_concrete
setblock 235 265 558 minecraft:yellow_concrete
setblock 235 265 561 minecraft:yellow_concrete
fill 235 265 562 235 268 562 minecraft:red_concrete
fill 235 265 573 235 268 573 minecraft:red_concrete
fill 235 265 577 235 267 577 minecraft:red_concrete
setblock 235 265 578 minecraft:yellow_concrete
setblock 235 265 589 minecraft:yellow_concrete
setblock 235 265 593 minecraft:yellow_concrete
fill 235 265 594 235 268 594 minecraft:red_concrete
fill 236 265 586 236 266 586 minecraft:red_concrete
fill 238 265 557 239 265 557 minecraft:yellow_concrete
fill 238 265 588 239 266 589 minecraft:orange_concrete
setblock 246 265 599 minecraft:yellow_concrete
setblock 249 265 599 minecraft:yellow_concrete
fill 250 265 599 250 268 599 minecraft:red_concrete
fill 255 265 557 255 268 557 minecraft:red_concrete
setblock 257 265 599 minecraft:yellow_concrete
setblock 259 265 557 minecraft:yellow_concrete
fill 261 265 599 261 268 599 minecraft:red_concrete
fill 266 265 557 266 268 557 minecraft:red_concrete
setblock 267 265 557 minecraft:yellow_concrete
setblock 270 265 557 minecraft:yellow_concrete
fill 273 265 588 274 266 589 minecraft:orange_concrete
fill 276 265 586 276 266 586 minecraft:red_concrete
fill 277 265 566 277 268 567 minecraft:red_concrete
setblock 277 265 571 minecraft:yellow_concrete
setblock 277 265 582 minecraft:yellow_concrete
fill 277 265 587 277 268 587 minecraft:red_concrete
fill 277 265 598 277 268 598 minecraft:red_concrete
setblock 277 265 599 minecraft:yellow_concrete
fill 235 266 558 235 271 558 minecraft:red_concrete
fill 235 266 559 235 266 560 minecraft:yellow_concrete
fill 235 266 561 235 271 561 minecraft:red_concrete
fill 235 266 567 235 267 568 minecraft:yellow_concrete
fill 235 266 569 235 271 570 minecraft:red_concrete
fill 235 266 578 235 267 578 minecraft:red_concrete
fill 235 266 579 235 266 580 minecraft:yellow_concrete
fill 235 266 581 235 271 582 minecraft:red_concrete
fill 235 266 587 235 267 588 minecraft:yellow_concrete
fill 235 266 589 235 271 590 minecraft:red_concrete
setblock 235 266 591 minecraft:yellow_concrete
fill 235 266 593 235 268 593 minecraft:red_concrete
fill 235 266 599 236 267 599 minecraft:yellow_concrete
setblock 237 266 557 minecraft:yellow_concrete
setblock 237 266 586 minecraft:red_concrete
fill 237 266 589 237 268 589 minecraft:orange_concrete
fill 237 266 599 238 271 599 minecraft:red_concrete
fill 238 266 557 239 271 557 minecraft:red_concrete
setblock 238 266 560 minecraft:light[level=14]
setblock 238 266 568 minecraft:light[level=14]
setblock 238 266 576 minecraft:light[level=14]
setblock 238 266 584 minecraft:light[level=14]
setblock 238 266 592 minecraft:light[level=14]
fill 240 266 557 240 267 557 minecraft:yellow_concrete
fill 244 266 599 244 267 599 minecraft:yellow_concrete
fill 246 266 557 247 271 557 minecraft:red_concrete
setblock 246 266 560 minecraft:light[level=14]
setblock 246 266 568 minecraft:light[level=14]
setblock 246 266 576 minecraft:light[level=14]
setblock 246 266 584 minecraft:light[level=14]
setblock 246 266 592 minecraft:light[level=14]
fill 246 266 599 246 271 599 minecraft:red_concrete
fill 247 266 599 248 266 599 minecraft:yellow_concrete
fill 248 266 557 249 266 557 minecraft:yellow_concrete
fill 249 266 599 249 271 599 minecraft:red_concrete
setblock 254 266 560 minecraft:light[level=14]
setblock 254 266 568 minecraft:light[level=14]
setblock 254 266 576 minecraft:light[level=14]
setblock 254 266 584 minecraft:light[level=14]
setblock 254 266 592 minecraft:light[level=14]
fill 255 266 599 256 267 599 minecraft:yellow_concrete
fill 257 266 599 258 271 599 minecraft:red_concrete
fill 258 266 557 259 271 557 minecraft:red_concrete
fill 260 266 557 261 267 557 minecraft:yellow_concrete
setblock 262 266 560 minecraft:light[level=14]
setblock 262 266 568 minecraft:light[level=14]
setblock 262 266 576 minecraft:light[level=14]
setblock 262 266 584 minecraft:light[level=14]
setblock 262 266 592 minecraft:light[level=14]
fill 267 266 557 267 271 557 minecraft:red_concrete
fill 267 266 599 268 266 599 minecraft:yellow_concrete
fill 268 266 557 269 266 557 minecraft:yellow_concrete
fill 269 266 599 270 271 599 minecraft:red_concrete
fill 270 266 557 270 271 557 minecraft:red_concrete
setblock 270 266 560 minecraft:light[level=14]
setblock 270 266 568 minecraft:light[level=14]
setblock 270 266 576 minecraft:light[level=14]
setblock 270 266 584 minecraft:light[level=14]
setblock 270 266 592 minecraft:light[level=14]
fill 272 266 557 272 267 557 minecraft:yellow_concrete
setblock 275 266 586 minecraft:red_concrete
fill 275 266 589 275 268 589 minecraft:orange_concrete
fill 276 266 599 276 267 599 minecraft:yellow_concrete
fill 277 266 558 277 271 559 minecraft:red_concrete
fill 277 266 560 277 267 561 minecraft:yellow_concrete
setblock 277 266 569 minecraft:yellow_concrete
fill 277 266 570 277 271 571 minecraft:red_concrete
fill 277 266 572 277 267 573 minecraft:yellow_concrete
fill 277 266 578 277 271 579 minecraft:red_concrete
fill 277 266 580 277 266 581 minecraft:yellow_concrete
fill 277 266 582 277 271 582 minecraft:red_concrete
fill 277 266 590 277 271 591 minecraft:red_concrete
fill 277 266 592 277 267 593 minecraft:yellow_concrete
fill 277 266 599 277 271 599 minecraft:red_concrete
fill 235 267 559 235 269 560 minecraft:red_concrete
fill 235 267 575 235 267 576 minecraft:yellow_concrete
setblock 235 267 579 minecraft:yellow_concrete
fill 235 267 580 235 270 580 minecraft:red_concrete
fill 235 267 591 235 270 591 minecraft:red_concrete
fill 235 267 595 235 269 595 minecraft:red_concrete
setblock 235 267 596 minecraft:yellow_concrete
fill 237 267 557 237 270 557 minecraft:red_concrete
fill 237 267 590 238 267 590 minecraft:orange_concrete
setblock 238 267 589 minecraft:orange_concrete
setblock 241 267 557 minecraft:yellow_concrete
setblock 243 267 599 minecraft:yellow_concrete
fill 247 267 599 248 270 599 minecraft:red_concrete
fill 248 267 557 248 270 557 minecraft:red_concrete
setblock 249 267 557 minecraft:yellow_concrete
setblock 252 267 557 minecraft:yellow_concrete
setblock 264 267 599 minecraft:yellow_concrete
setblock 267 267 599 minecraft:yellow_concrete
fill 268 267 557 269 270 557 minecraft:red_concrete
fill 268 267 599 268 270 599 minecraft:red_concrete
setblock 273 267 557 minecraft:yellow_concrete
fill 274 267 589 274 267 590 minecraft:orange_concrete
fill 275 267 590 275 269 590 minecraft:orange_concrete
setblock 275 267 599 minecraft:yellow_concrete
setblock 277 267 564 minecraft:yellow_concrete
fill 277 267 569 277 270 569 minecraft:red_concrete
fill 277 267 580 277 270 580 minecraft:red_concrete
setblock 277 267 581 minecraft:yellow_concrete
fill 277 267 584 277 267 585 minecraft:yellow_concrete
setblock 235 268 557 minecraft:yellow_concrete
fill 235 268 565 235 269 566 minecraft:yellow_concrete
fill 235 268 567 235 285 568 minecraft:red_concrete
fill 235 268 574 235 269 574 minecraft:yellow_concrete
fill 235 268 575 235 269 576 minecraft:red_concrete
fill 235 268 577 235 268 578 minecraft:yellow_concrete
fill 235 268 579 235 285 579 minecraft:red_concrete
fill 235 268 585 235 269 586 minecraft:yellow_concrete
fill 235 268 587 235 286 588 minecraft:red_concrete
fill 235 268 596 235 289 596 minecraft:red_concrete
fill 235 268 597 235 268 598 minecraft:yellow_concrete
fill 235 268 599 236 285 599 minecraft:red_concrete
fill 236 268 590 237 269 590 minecraft:orange_concrete
fill 240 268 557 241 286 557 minecraft:red_concrete
fill 241 268 599 242 269 599 minecraft:yellow_concrete
fill 242 268 557 243 269 557 minecraft:yellow_concrete
fill 243 268 599 244 286 599 minecraft:red_concrete
setblock 245 268 599 minecraft:yellow_concrete
fill 249 268 557 249 285 557 minecraft:red_concrete
fill 250 268 557 251 268 557 minecraft:yellow_concrete
fill 252 268 557 252 289 557 minecraft:red_concrete
fill 253 268 599 254 269 599 minecraft:yellow_concrete
fill 254 268 557 254 269 557 minecraft:yellow_concrete
fill 255 268 599 256 285 599 minecraft:red_concrete
fill 260 268 557 261 285 557 minecraft:red_concrete
fill 262 268 557 263 269 557 minecraft:yellow_concrete
fill 262 268 599 262 269 599 minecraft:yellow_concrete
fill 264 268 599 264 289 599 minecraft:red_concrete
fill 265 268 599 266 268 599 minecraft:yellow_concrete
fill 267 268 599 267 285 599 minecraft:red_concrete
setblock 271 268 557 minecraft:yellow_concrete
fill 272 268 557 273 286 557 minecraft:red_concrete
fill 273 268 599 274 269 599 minecraft:yellow_concrete
fill 274 268 557 275 269 557 minecraft:yellow_concrete
fill 275 268 599 276 286 599 minecraft:red_concrete
fill 276 268 590 276 270 590 minecraft:orange_concrete
fill 277 268 560 277 285 561 minecraft:red_concrete
fill 277 268 562 277 268 563 minecraft:yellow_concrete
fill 277 268 564 277 289 564 minecraft:red_concrete
fill 277 268 572 277 286 573 minecraft:red_concrete
fill 277 268 574 277 269 575 minecraft:yellow_concrete
fill 277 268 581 277 285 581 minecraft:red_concrete
setblock 277 268 583 minecraft:yellow_concrete
fill 277 268 584 277 289 585 minecraft:red_concrete
fill 277 268 586 277 269 586 minecraft:yellow_concrete
fill 277 268 592 277 285 593 minecraft:red_concrete
fill 277 268 594 277 268 595 minecraft:yellow_concrete
fill 235 269 557 235 271 557 minecraft:red_concrete
setblock 235 269 562 minecraft:yellow_concrete
setblock 235 269 573 minecraft:yellow_concrete
fill 235 269 577 235 271 578 minecraft:red_concrete
fill 235 269 593 235 269 594 minecraft:yellow_concrete
setblock 235 269 597 minecraft:yellow_concrete
fill 235 269 598 235 272 598 minecraft:red_concrete
fill 245 269 599 245 272 599 minecraft:red_concrete
fill 250 269 557 251 272 557 minecraft:red_concrete
setblock 250 269 599 minecraft:yellow_concrete
setblock 255 269 557 minecraft:yellow_concrete
setblock 261 269 599 minecraft:yellow_concrete
fill 265 269 599 266 272 599 minecraft:red_concrete
setblock 266 269 557 minecraft:yellow_concrete
fill 271 269 557 271 272 557 minecraft:red_concrete
fill 277 269 562 277 272 562 minecraft:red_concrete
setblock 277 269 563 minecraft:yellow_concrete
fill 277 269 566 277 269 567 minecraft:yellow_concrete
fill 277 269 583 277 272 583 minecraft:red_concrete
setblock 277 269 587 minecraft:yellow_concrete
fill 277 269 594 277 272 594 minecraft:red_concrete
setblock 277 269 595 minecraft:yellow_concrete
setblock 277 269 598 minecraft:yellow_concrete
setblock 235 270 559 minecraft:red_concrete
fill 235 270 560 235 271 560 minecraft:yellow_concrete
fill 235 270 562 235 283 562 minecraft:red_concrete
fill 235 270 563 235 270 564 minecraft:yellow_concrete
fill 235 270 565 235 272 566 minecraft:red_concrete
fill 235 270 571 235 271 572 minecraft:yellow_concrete
fill 235 270 573 235 283 574 minecraft:red_concrete
setblock 235 270 575 minecraft:yellow_concrete
fill 235 270 576 235 289 576 minecraft:red_concrete
fill 235 270 583 235 271 584 minecraft:yellow_concrete
fill 235 270 585 235 283 586 minecraft:red_concrete
fill 235 270 592 235 271 592 minecraft:yellow_concrete
fill 235 270 593 235 283 594 minecraft:red_concrete
setblock 235 270 595 minecraft:yellow_concrete
fill 235 270 597 235 287 597 minecraft:red_concrete
fill 236 270 557 236 271 557 minecraft:yellow_concrete
fill 236 270 558 238 270 558 minecraft:orange_concrete
fill 236 270 560 236 270 562 minecraft:orange_concrete
fill 236 270 564 236 270 566 minecraft:orange_concrete
fill 236 270 568 236 270 570 minecraft:orange_concrete
fill 236 270 572 236 270 574 minecraft:orange_concrete
fill 236 270 576 236 270 578 minecraft:orange_concrete
fill 236 270 580 236 270 582 minecraft:orange_concrete
fill 236 270 584 236 270 586 minecraft:orange_concrete
fill 236 270 588 236 270 590 minecraft:orange_concrete
fill 236 270 592 236 270 594 minecraft:orange_concrete
fill 236 270 596 236 270 598 minecraft:orange_concrete
fill 238 270 598 240 270 598 minecraft:orange_concrete
fill 239 270 599 240 271 599 minecraft:yellow_concrete
fill 240 270 558 242 270 558 minecraft:orange_concrete
fill 241 270 599 242 283 599 minecraft:red_concrete
fill 242 270 557 243 283 557 minecraft:red_concrete
fill 242 270 598 244 270 598 minecraft:orange_concrete
fill 244 270 557 245 271 557 minecraft:yellow_concrete
fill 244 270 558 246 270 558 minecraft:orange_concrete
fill 246 270 598 248 270 598 minecraft:orange_concrete
fill 248 270 558 250 270 558 minecraft:orange_concrete
fill 250 270 598 252 270 598 minecraft:orange_concrete
fill 250 270 599 250 283 599 minecraft:red_concrete
fill 251 270 599 252 270 599 minecraft:yellow_concrete
fill 252 270 558 254 270 558 minecraft:orange_concrete
setblock 253 270 557 minecraft:yellow_concrete
fill 253 270 599 254 287 599 minecraft:red_concrete
fill 254 270 557 255 283 557 minecraft:red_concrete
fill 254 270 598 256 270 598 minecraft:orange_concrete
fill 256 270 557 257 271 557 minecraft:yellow_concrete
fill 256 270 558 258 270 558 minecraft:orange_concrete
fill 258 270 598 260 270 598 minecraft:orange_concrete
fill 259 270 599 260 271 599 minecraft:yellow_concrete
fill 260 270 558 262 270 558 minecraft:orange_concrete
fill 261 270 599 262 283 599 minecraft:red_concrete
fill 262 270 557 263 287 557 minecraft:red_concrete
fill 262 270 598 264 270 598 minecraft:orange_concrete
setblock 263 270 599 minecraft:yellow_concrete
fill 264 270 557 265 270 557 minecraft:yellow_concrete
fill 264 270 558 266 270 558 minecraft:orange_concrete
fill 266 270 557 266 283 557 minecraft:red_concrete
fill 266 270 598 268 270 598 minecraft:orange_concrete
fill 268 270 558 270 270 558 minecraft:orange_concrete
fill 270 270 598 272 270 598 minecraft:orange_concrete
fill 271 270 599 272 271 599 minecraft:yellow_concrete
fill 272 270 558 274 270 558 minecraft:orange_concrete
fill 273 270 599 274 283 599 minecraft:red_concrete
fill 274 270 557 275 283 557 minecraft:red_concrete
fill 274 270 598 276 270 598 minecraft:orange_concrete
fill 276 270 557 277 271 557 minecraft:yellow_concrete
fill 276 270 558 276 270 560 minecraft:orange_concrete
fill 276 270 562 276 270 564 minecraft:orange_concrete
fill 276 270 566 276 270 568 minecraft:orange_concrete
fill 276 270 570 276 270 572 minecraft:orange_concrete
fill 276 270 574 276 270 576 minecraft:orange_concrete
fill 276 270 578 276 270 580 minecraft:orange_concrete
fill 276 270 582 276 270 584 minecraft:orange_concrete
fill 276 270 586 276 270 588 minecraft:orange_concrete
fill 276 270 591 276 270 592 minecraft:orange_concrete
fill 276 270 594 276 270 596 minecraft:orange_concrete
fill 277 270 563 277 287 563 minecraft:red_concrete
setblock 277 270 565 minecraft:yellow_concrete
fill 277 270 566 277 283 567 minecraft:red_concrete
fill 277 270 568 277 271 568 minecraft:yellow_concrete
fill 277 270 574 277 283 575 minecraft:red_concrete
fill 277 270 576 277 270 577 minecraft:yellow_concrete
fill 277 270 586 277 283 587 minecraft:red_concrete
fill 277 270 588 277 271 589 minecraft:yellow_concrete
fill 277 270 595 277 287 595 minecraft:red_concrete
fill 277 270 596 277 270 597 minecraft:yellow_concrete
fill 277 270 598 277 283 598 minecraft:red_concrete
setblock 235 271 559 minecraft:yellow_concrete
setblock 235 271 563 minecraft:yellow_concrete
fill 235 271 564 235 289 564 minecraft:red_concrete
fill 235 271 575 235 289 575 minecraft:red_concrete
setblock 235 271 580 minecraft:yellow_concrete
setblock 235 271 591 minecraft:yellow_concrete
fill 235 271 595 235 289 595 minecraft:red_concrete
setblock 237 271 557 minecraft:yellow_concrete
fill 247 271 599 248 271 599 minecraft:yellow_concrete
setblock 248 271 557 minecraft:yellow_concrete
setblock 251 271 599 minecraft:yellow_concrete
fill 252 271 599 252 289 599 minecraft:red_concrete
fill 253 271 557 253 289 557 minecraft:red_concrete
fill 263 271 599 263 289 599 minecraft:red_concrete
fill 264 271 557 264 289 557 minecraft:red_concrete
setblock 265 271 557 minecraft:yellow_concrete
fill 268 271 557 269 271 557 minecraft:yellow_concrete
setblock 268 271 599 minecraft:yellow_concrete
fill 277 271 565 277 289 565 minecraft:red_concrete
setblock 277 271 569 minecraft:yellow_concrete
fill 277 271 576 277 289 576 minecraft:red_concrete
setblock 277 271 577 minecraft:yellow_concrete
setblock 277 271 580 minecraft:yellow_concrete
fill 277 271 596 277 289 597 minecraft:red_concrete
fill 235 272 557 235 273 558 minecraft:yellow_concrete
fill 235 272 559 235 285 560 minecraft:red_concrete
setblock 235 272 561 minecraft:yellow_concrete
fill 235 272 563 235 289 563 minecraft:red_concrete
fill 235 272 569 235 273 570 minecraft:yellow_concrete
fill 235 272 571 235 285 572 minecraft:red_concrete
setblock 235 272 577 minecraft:red_concrete
fill 235 272 578 235 273 578 minecraft:yellow_concrete
fill 235 272 580 235 285 580 minecraft:red_concrete
fill 235 272 581 235 272 582 minecraft:yellow_concrete
fill 235 272 583 235 289 584 minecraft:red_concrete
fill 235 272 589 235 273 590 minecraft:yellow_concrete
fill 235 272 591 235 285 592 minecraft:red_concrete
fill 236 272 557 237 285 557 minecraft:red_concrete
fill 237 272 599 238 272 599 minecraft:yellow_concrete
fill 238 272 557 239 273 557 minecraft:yellow_concrete
fill 239 272 599 240 285 599 minecraft:red_concrete
fill 244 272 557 245 289 557 minecraft:red_concrete
fill 246 272 557 247 272 557 minecraft:yellow_concrete
fill 246 272 599 246 273 599 minecraft:yellow_concrete
fill 247 272 599 248 285 599 minecraft:red_concrete
fill 248 272 557 248 285 557 minecraft:red_concrete
setblock 249 272 599 minecraft:yellow_concrete
fill 251 272 599 251 289 599 minecraft:red_concrete
fill 256 272 557 257 285 557 minecraft:red_concrete
fill 257 272 599 258 273 599 minecraft:yellow_concrete
fill 258 272 557 259 273 557 minecraft:yellow_concrete
fill 259 272 599 260 285 599 minecraft:red_concrete
fill 265 272 557 265 289 557 minecraft:red_concrete
setblock 267 272 557 minecraft:yellow_concrete
fill 268 272 557 269 285 557 minecraft:red_concrete
fill 268 272 599 268 285 599 minecraft:red_concrete
fill 269 272 599 270 272 599 minecraft:yellow_concrete
fill 270 272 557 270 273 557 minecraft:yellow_concrete
fill 271 272 599 272 289 599 minecraft:red_concrete
fill 276 272 557 277 285 557 minecraft:red_concrete
fill 277 272 558 277 272 559 minecraft:yellow_concrete
fill 277 272 568 277 285 569 minecraft:red_concrete
fill 277 272 570 277 273 571 minecraft:yellow_concrete
fill 277 272 577 277 289 577 minecraft:red_concrete
fill 277 272 578 277 272 579 minecraft:yellow_concrete
fill 277 272 580 277 285 580 minecraft:red_concrete
fill 277 272 582 277 273 582 minecraft:yellow_concrete
fill 277 272 588 277 285 589 minecraft:red_concrete
fill 277 272 590 277 273 591 minecraft:yellow_concrete
fill 277 272 599 277 273 599 minecraft:yellow_concrete
fill 235 273 561 235 283 561 minecraft:red_concrete
fill 235 273 565 235 287 565 minecraft:red_concrete
setblock 235 273 566 minecraft:yellow_concrete
setblock 235 273 577 minecraft:yellow_concrete
setblock 235 273 581 minecraft:yellow_concrete
fill 235 273 582 235 283 582 minecraft:red_concrete
setblock 235 273 598 minecraft:yellow_concrete
setblock 237 273 599 minecraft:yellow_concrete
fill 238 273 599 238 283 599 minecraft:red_concrete
setblock 245 273 599 minecraft:yellow_concrete
fill 246 273 557 246 283 557 minecraft:red_concrete
setblock 247 273 557 minecraft:yellow_concrete
fill 249 273 599 249 283 599 minecraft:red_concrete
fill 250 273 557 251 273 557 minecraft:yellow_concrete
fill 265 273 599 266 273 599 minecraft:yellow_concrete
fill 267 273 557 267 283 557 minecraft:red_concrete
setblock 269 273 599 minecraft:yellow_concrete
fill 270 273 599 270 283 599 minecraft:red_concrete
setblock 271 273 557 minecraft:yellow_concrete
fill 277 273 558 277 283 558 minecraft:red_concrete
setblock 277 273 559 minecraft:yellow_concrete
setblock 277 273 562 minecraft:yellow_concrete
fill 277 273 578 277 283 579 minecraft:red_concrete
setblock 277 273 583 minecraft:yellow_concrete
setblock 277 273 594 minecraft:yellow_concrete
fill 235 274 557 235 287 558 minecraft:red_concrete
fill 235 274 566 235 287 566 minecraft:red_concrete
fill 235 274 569 235 284 570 minecraft:red_concrete
fill 235 274 577 235 287 578 minecraft:red_concrete
fill 235 274 581 235 283 581 minecraft:red_concrete
fill 235 274 589 235 284 590 minecraft:red_concrete
fill 235 274 598 235 287 598 minecraft:red_concrete
fill 237 274 599 237 284 599 minecraft:red_concrete
fill 238 274 557 239 284 557 minecraft:red_concrete
setblock 238 274 560 minecraft:light[level=14]
setblock 238 274 568 minecraft:light[level=14]
setblock 238 274 576 minecraft:light[level=14]
setblock 238 274 584 minecraft:light[level=14]
setblock 238 274 592 minecraft:light[level=14]
fill 245 274 599 246 287 599 minecraft:red_concrete
setblock 246 274 560 minecraft:light[level=14]
setblock 246 274 568 minecraft:light[level=14]
setblock 246 274 576 minecraft:light[level=14]
setblock 246 274 584 minecraft:light[level=14]
setblock 246 274 592 minecraft:light[level=14]
fill 247 274 557 247 284 557 minecraft:red_concrete
fill 250 274 557 251 287 557 minecraft:red_concrete
setblock 254 274 560 minecraft:light[level=14]
setblock 254 274 568 minecraft:light[level=14]
setblock 254 274 576 minecraft:light[level=14]
setblock 254 274 584 minecraft:light[level=14]
setblock 254 274 592 minecraft:light[level=14]
fill 257 274 599 258 284 599 minecraft:red_concrete
fill 258 274 557 259 284 557 minecraft:red_concrete
setblock 262 274 560 minecraft:light[level=14]
setblock 262 274 568 minecraft:light[level=14]
setblock 262 274 576 minecraft:light[level=14]
setblock 262 274 584 minecraft:light[level=14]
setblock 262 274 592 minecraft:light[level=14]
fill 265 274 599 266 287 599 minecraft:red_concrete
fill 269 274 599 269 284 599 minecraft:red_concrete
fill 270 274 557 271 287 557 minecraft:red_concrete
setblock 270 274 560 minecraft:light[level=14]
setblock 270 274 568 minecraft:light[level=14]
setblock 270 274 576 minecraft:light[level=14]
setblock 270 274 584 minecraft:light[level=14]
setblock 270 274 592 minecraft:light[level=14]
fill 277 274 559 277 284 559 minecraft:red_concrete
fill 277 274 562 277 287 562 minecraft:red_concrete
fill 277 274 570 277 284 571 minecraft:red_concrete
fill 277 274 582 277 287 583 minecraft:red_concrete
fill 277 274 590 277 284 591 minecraft:red_concrete
fill 277 274 594 277 287 594 minecraft:red_concrete
fill 277 274 599 277 287 599 minecraft:red_concrete
fill 243 279 575 250 280 575 minecraft:orange_concrete
fill 243 279 587 250 280 587 minecraft:orange_concrete
fill 244 279 576 262 279 577 minecraft:orange_concrete
fill 244 279 585 262 279 586 minecraft:orange_concrete
fill 245 279 578 262 279 578 minecraft:orange_concrete
fill 245 279 584 262 279 584 minecraft:orange_concrete
fill 246 279 579 255 279 579 minecraft:orange_concrete
fill 246 279 583 255 279 583 minecraft:orange_concrete
fill 248 279 580 254 279 580 minecraft:orange_concrete
fill 248 279 582 254 279 582 minecraft:orange_concrete
fill 250 279 581 253 279 581 minecraft:orange_concrete
fill 252 279 568 254 279 575 minecraft:orange_concrete
fill 252 279 587 254 279 594 minecraft:orange_concrete
fill 253 279 567 253 280 567 minecraft:orange_concrete
fill 253 279 595 253 280 595 minecraft:orange_concrete
fill 255 279 569 255 279 575 minecraft:orange_concrete
fill 255 279 587 255 279 593 minecraft:orange_concrete
fill 256 279 571 256 279 575 minecraft:orange_concrete
fill 256 279 587 256 279 591 minecraft:orange_concrete
fill 257 279 573 257 280 575 minecraft:orange_concrete
fill 257 279 579 267 279 579 minecraft:orange_concrete
fill 257 279 583 267 279 583 minecraft:orange_concrete
fill 257 279 587 257 280 589 minecraft:orange_concrete
fill 258 279 574 264 279 575 minecraft:orange_concrete
fill 258 279 580 269 279 580 minecraft:orange_concrete
fill 258 279 582 269 279 582 minecraft:orange_concrete
fill 258 279 587 264 279 588 minecraft:orange_concrete
fill 259 279 573 264 279 573 minecraft:orange_concrete
fill 259 279 581 271 279 581 minecraft:orange_concrete
fill 259 279 589 264 279 589 minecraft:orange_concrete
fill 260 279 572 265 280 572 minecraft:orange_concrete
fill 260 279 590 265 280 590 minecraft:orange_concrete
fill 262 279 571 265 280 571 minecraft:orange_concrete
fill 262 279 591 265 280 591 minecraft:orange_concrete
fill 263 279 570 265 280 570 minecraft:orange_concrete
fill 263 279 576 263 280 576 minecraft:orange_concrete
fill 263 279 586 263 280 586 minecraft:orange_concrete
fill 263 279 592 265 280 592 minecraft:orange_concrete
fill 236 280 558 242 280 598 minecraft:red_concrete
fill 243 280 558 251 280 574 minecraft:red_concrete
fill 243 280 576 243 280 586 minecraft:red_concrete
fill 243 280 588 251 280 598 minecraft:red_concrete
fill 244 280 576 246 280 577 minecraft:orange_concrete
fill 244 280 578 244 280 584 minecraft:red_concrete
fill 244 280 585 246 280 586 minecraft:orange_concrete
fill 245 280 578 247 280 578 minecraft:orange_concrete
fill 245 280 579 245 280 583 minecraft:red_concrete
fill 245 280 584 247 280 584 minecraft:orange_concrete
fill 246 280 579 248 280 579 minecraft:orange_concrete
fill 246 280 580 247 280 582 minecraft:red_concrete
fill 246 280 583 248 280 583 minecraft:orange_concrete
fill 247 280 576 252 280 576 minecraft:orange_concrete
fill 247 280 577 255 280 577 minecraft:yellow_concrete
fill 247 280 585 255 280 585 minecraft:yellow_concrete
fill 247 280 586 252 280 586 minecraft:orange_concrete
fill 248 280 578 253 280 578 minecraft:yellow_concrete
fill 248 280 580 249 280 580 minecraft:orange_concrete
fill 248 280 581 249 280 581 minecraft:red_concrete
fill 248 280 582 249 280 582 minecraft:orange_concrete
fill 248 280 584 253 280 584 minecraft:yellow_concrete
fill 249 280 579 252 280 579 minecraft:yellow_concrete
fill 249 280 583 252 280 583 minecraft:yellow_concrete
fill 250 280 580 252 280 580 minecraft:yellow_concrete
fill 250 280 581 251 280 581 minecraft:orange_concrete
fill 250 280 582 252 280 582 minecraft:yellow_concrete
setblock 251 280 575 minecraft:red_concrete
setblock 251 280 587 minecraft:red_concrete
fill 252 280 558 252 280 567 minecraft:red_concrete
fill 252 280 568 252 280 575 minecraft:orange_concrete
setblock 252 280 581 minecraft:red_concrete
fill 252 280 587 252 280 594 minecraft:orange_concrete
fill 252 280 595 252 280 598 minecraft:red_concrete
fill 253 280 558 276 280 566 minecraft:red_concrete
fill 253 280 568 253 280 572 minecraft:orange_concrete
fill 253 280 573 255 280 576 minecraft:yellow_concrete
setblock 253 280 579 minecraft:red_concrete
fill 253 280 580 253 280 582 minecraft:shroomlight
setblock 253 280 583 minecraft:red_concrete
fill 253 280 586 255 280 589 minecraft:yellow_concrete
fill 253 280 590 253 280 594 minecraft:orange_concrete
fill 253 280 596 276 280 598 minecraft:red_concrete
fill 254 280 567 276 280 567 minecraft:red_concrete
fill 254 280 568 254 280 571 minecraft:orange_concrete
setblock 254 280 572 minecraft:yellow_concrete
setblock 254 280 578 minecraft:red_concrete
fill 254 280 579 254 280 580 minecraft:shroomlight
fill 254 280 582 254 280 583 minecraft:shroomlight
setblock 254 280 584 minecraft:red_concrete
setblock 254 280 590 minecraft:yellow_concrete
fill 254 280 591 254 280 594 minecraft:orange_concrete
fill 254 280 595 276 280 595 minecraft:red_concrete
fill 255 280 568 276 280 568 minecraft:red_concrete
fill 255 280 569 255 280 572 minecraft:orange_concrete
fill 255 280 578 255 280 579 minecraft:shroomlight
fill 255 280 583 255 280 584 minecraft:shroomlight
fill 255 280 590 255 280 593 minecraft:orange_concrete
fill 255 280 594 276 280 594 minecraft:red_concrete
fill 256 280 569 262 280 570 minecraft:red_concrete
fill 256 280 571 256 280 573 minecraft:orange_concrete
fill 256 280 574 256 280 576 minecraft:yellow_concrete
setblock 256 280 577 minecraft:red_concrete
fill 256 280 578 257 280 578 minecraft:shroomlight
fill 256 280 584 257 280 584 minecraft:shroomlight
setblock 256 280 585 minecraft:red_concrete
fill 256 280 586 256 280 588 minecraft:yellow_concrete
fill 256 280 589 256 280 591 minecraft:orange_concrete
fill 256 280 592 262 280 593 minecraft:red_concrete
fill 257 280 571 259 280 572 minecraft:red_concrete
setblock 257 280 576 minecraft:orange_concrete
fill 257 280 577 261 280 577 minecraft:yellow_concrete
fill 257 280 579 258 280 579 minecraft:shroomlight
fill 257 280 583 258 280 583 minecraft:shroomlight
fill 257 280 585 261 280 585 minecraft:yellow_concrete
setblock 257 280 586 minecraft:orange_concrete
fill 257 280 590 259 280 591 minecraft:red_concrete
setblock 258 280 573 minecraft:red_concrete
fill 258 280 574 258 280 575 minecraft:orange_concrete
fill 258 280 576 262 280 576 minecraft:yellow_concrete
setblock 258 280 578 minecraft:red_concrete
fill 258 280 580 259 280 580 minecraft:shroomlight
fill 258 280 582 259 280 582 minecraft:shroomlight
setblock 258 280 584 minecraft:red_concrete
fill 258 280 586 262 280 586 minecraft:yellow_concrete
fill 258 280 587 258 280 588 minecraft:orange_concrete
setblock 258 280 589 minecraft:red_concrete
fill 259 280 573 259 280 574 minecraft:orange_concrete
fill 259 280 575 262 280 575 minecraft:yellow_concrete
fill 259 280 578 261 280 578 minecraft:yellow_concrete
setblock 259 280 579 minecraft:red_concrete
setblock 259 280 581 minecraft:shroomlight
setblock 259 280 583 minecraft:red_concrete
fill 259 280 584 261 280 584 minecraft:yellow_concrete
fill 259 280 587 262 280 587 minecraft:yellow_concrete
fill 259 280 588 259 280 589 minecraft:orange_concrete
fill 260 280 571 261 280 571 minecraft:red_concrete
fill 260 280 573 261 280 573 minecraft:orange_concrete
fill 260 280 574 262 280 574 minecraft:yellow_concrete
fill 260 280 579 262 280 580 minecraft:yellow_concrete
setblock 260 280 581 minecraft:red_concrete
fill 260 280 582 262 280 583 minecraft:yellow_concrete
fill 260 280 588 262 280 588 minecraft:yellow_concrete
fill 260 280 589 261 280 589 minecraft:orange_concrete
fill 260 280 591 261 280 591 minecraft:red_concrete
fill 261 280 581 266 280 581 minecraft:yellow_concrete
setblock 262 280 573 minecraft:yellow_concrete
fill 262 280 577 262 280 578 minecraft:orange_concrete
fill 262 280 584 262 280 585 minecraft:orange_concrete
setblock 262 280 589 minecraft:yellow_concrete
fill 263 280 569 276 280 569 minecraft:red_concrete
fill 263 280 573 264 280 575 minecraft:orange_concrete
fill 263 280 577 276 280 578 minecraft:red_concrete
fill 263 280 579 267 280 579 minecraft:orange_concrete
fill 263 280 580 265 280 580 minecraft:yellow_concrete
fill 263 280 582 265 280 582 minecraft:yellow_concrete
fill 263 280 583 267 280 583 minecraft:orange_concrete
fill 263 280 584 276 280 585 minecraft:red_concrete
fill 263 280 587 264 280 589 minecraft:orange_concrete
fill 263 280 593 276 280 593 minecraft:red_concrete
fill 264 280 576 276 280 576 minecraft:red_concrete
fill 264 280 586 276 280 586 minecraft:red_concrete
fill 265 280 573 276 280 575 minecraft:red_concrete
fill 265 280 587 276 280 589 minecraft:red_concrete
fill 266 280 570 276 280 572 minecraft:red_concrete
fill 266 280 580 269 280 580 minecraft:orange_concrete
fill 266 280 582 269 280 582 minecraft:orange_concrete
fill 266 280 590 276 280 592 minecraft:red_concrete
fill 267 280 581 271 280 581 minecraft:orange_concrete
fill 268 280 579 276 280 579 minecraft:red_concrete
fill 268 280 583 276 280 583 minecraft:red_concrete
fill 270 280 580 276 280 580 minecraft:red_concrete
fill 270 280 582 276 280 582 minecraft:red_concrete
fill 272 280 581 276 280 581 minecraft:red_concrete
setblock 238 282 560 minecraft:light[level=14]
setblock 238 282 568 minecraft:light[level=14]
setblock 238 282 576 minecraft:light[level=14]
setblock 238 282 584 minecraft:light[level=14]
setblock 238 282 592 minecraft:light[level=14]
setblock 246 282 560 minecraft:light[level=14]
setblock 246 282 568 minecraft:light[level=14]
setblock 246 282 576 minecraft:light[level=14]
setblock 246 282 584 minecraft:light[level=14]
setblock 246 282 592 minecraft:light[level=14]
setblock 254 282 560 minecraft:light[level=14]
setblock 254 282 568 minecraft:light[level=14]
setblock 254 282 576 minecraft:light[level=14]
setblock 254 282 584 minecraft:light[level=14]
setblock 254 282 592 minecraft:light[level=14]
setblock 262 282 560 minecraft:light[level=14]
setblock 262 282 568 minecraft:light[level=14]
setblock 262 282 576 minecraft:light[level=14]
setblock 262 282 584 minecraft:light[level=14]
setblock 262 282 592 minecraft:light[level=14]
setblock 270 282 560 minecraft:light[level=14]
setblock 270 282 568 minecraft:light[level=14]
setblock 270 282 576 minecraft:light[level=14]
setblock 270 282 584 minecraft:light[level=14]
setblock 270 282 592 minecraft:light[level=14]
fill 235 284 561 235 285 562 minecraft:yellow_concrete
fill 235 284 573 235 284 574 minecraft:yellow_concrete
fill 235 284 581 235 285 582 minecraft:yellow_concrete
setblock 235 284 585 minecraft:yellow_concrete
fill 235 284 586 235 287 586 minecraft:red_concrete
fill 235 284 593 235 285 594 minecraft:yellow_concrete
fill 236 284 572 238 285 574 minecraft:magma_block
fill 238 284 599 238 285 599 minecraft:yellow_concrete
fill 239 284 573 239 285 573 minecraft:magma_block
fill 241 284 599 242 284 599 minecraft:yellow_concrete
fill 242 284 557 242 287 557 minecraft:red_concrete
setblock 243 284 557 minecraft:yellow_concrete
fill 246 284 557 246 285 557 minecraft:yellow_concrete
fill 249 284 599 250 285 599 minecraft:yellow_concrete
fill 254 284 557 255 284 557 minecraft:yellow_concrete
fill 261 284 599 262 284 599 minecraft:yellow_concrete
fill 266 284 557 267 285 557 minecraft:yellow_concrete
fill 270 284 599 270 285 599 minecraft:yellow_concrete
setblock 273 284 599 minecraft:yellow_concrete
fill 274 284 557 275 284 557 minecraft:yellow_concrete
fill 274 284 599 274 287 599 minecraft:red_concrete
fill 277 284 558 277 285 558 minecraft:yellow_concrete
fill 277 284 566 277 285 567 minecraft:yellow_concrete
fill 277 284 574 277 287 574 minecraft:red_concrete
setblock 277 284 575 minecraft:yellow_concrete
fill 277 284 578 277 285 579 minecraft:yellow_concrete
fill 277 284 586 277 284 587 minecraft:yellow_concrete
fill 277 284 598 277 285 598 minecraft:yellow_concrete
fill 235 285 569 235 285 570 minecraft:yellow_concrete
setblock 235 285 573 minecraft:yellow_concrete
fill 235 285 574 235 288 574 minecraft:red_concrete
fill 235 285 585 235 288 585 minecraft:red_concrete
fill 235 285 589 235 287 589 minecraft:red_concrete
setblock 235 285 590 minecraft:yellow_concrete
setblock 237 285 599 minecraft:yellow_concrete
setblock 238 285 557 minecraft:yellow_concrete
fill 239 285 557 239 287 557 minecraft:red_concrete
fill 241 285 599 242 288 599 minecraft:red_concrete
fill 243 285 557 243 288 557 minecraft:red_concrete
fill 245 285 581 245 286 581 minecraft:orange_concrete
setblock 247 285 557 minecraft:yellow_concrete
fill 254 285 557 254 288 557 minecraft:red_concrete
setblock 255 285 557 minecraft:yellow_concrete
fill 257 285 599 257 287 599 minecraft:red_concrete
setblock 258 285 557 minecraft:yellow_concrete
setblock 258 285 599 minecraft:yellow_concrete
fill 259 285 557 259 287 557 minecraft:red_concrete
setblock 261 285 599 minecraft:yellow_concrete
fill 262 285 599 262 288 599 minecraft:red_concrete
setblock 269 285 599 minecraft:yellow_concrete
fill 273 285 599 273 288 599 minecraft:red_concrete
fill 274 285 557 275 288 557 minecraft:red_concrete
setblock 277 285 559 minecraft:yellow_concrete
setblock 277 285 570 minecraft:yellow_concrete
fill 277 285 571 277 287 571 minecraft:red_concrete
fill 277 285 575 277 288 575 minecraft:red_concrete
fill 277 285 586 277 288 586 minecraft:red_concrete
setblock 277 285 587 minecraft:yellow_concrete
fill 277 285 590 277 285 591 minecraft:yellow_concrete
fill 235 286 559 235 287 560 minecraft:yellow_concrete
fill 235 286 561 235 291 562 minecraft:red_concrete
setblock 235 286 567 minecraft:red_concrete
fill 235 286 568 235 287 568 minecraft:yellow_concrete
fill 235 286 569 235 291 570 minecraft:red_concrete
setblock 235 286 571 minecraft:yellow_concrete
fill 235 286 572 235 289 573 minecraft:red_concrete
fill 235 286 579 235 287 580 minecraft:yellow_concrete
fill 235 286 581 235 291 582 minecraft:red_concrete
fill 235 286 590 235 291 590 minecraft:red_concrete
fill 235 286 591 235 286 592 minecraft:yellow_concrete
fill 235 286 593 235 291 594 minecraft:red_concrete
fill 235 286 599 236 287 599 minecraft:yellow_concrete
fill 236 286 557 237 286 557 minecraft:yellow_concrete
fill 237 286 599 238 291 599 minecraft:red_concrete
fill 238 286 557 238 287 557 minecraft:red_concrete
setblock 239 286 599 minecraft:yellow_concrete
fill 240 286 599 240 289 599 minecraft:red_concrete
fill 246 286 557 247 291 557 minecraft:red_concrete
fill 247 286 599 248 287 599 minecraft:yellow_concrete
fill 248 286 557 249 287 557 minecraft:yellow_concrete
fill 249 286 599 250 291 599 minecraft:red_concrete
fill 255 286 557 255 291 557 minecraft:red_concrete
setblock 255 286 599 minecraft:red_concrete
fill 256 286 557 257 286 557 minecraft:yellow_concrete
fill 256 286 599 256 287 599 minecraft:yellow_concrete
fill 258 286 557 258 291 557 minecraft:red_concrete
fill 258 286 599 258 291 599 minecraft:red_concrete
fill 259 286 599 260 286 599 minecraft:yellow_concrete
fill 260 286 557 260 287 557 minecraft:yellow_concrete
setblock 261 286 557 minecraft:red_concrete
fill 261 286 599 261 291 599 minecraft:red_concrete
fill 266 286 557 267 291 557 minecraft:red_concrete
fill 267 286 599 268 287 599 minecraft:yellow_concrete
fill 268 286 557 269 287 557 minecraft:yellow_concrete
fill 269 286 599 270 291 599 minecraft:red_concrete
fill 276 286 557 276 289 557 minecraft:red_concrete
setblock 277 286 557 minecraft:yellow_concrete
fill 277 286 558 277 291 559 minecraft:red_concrete
fill 277 286 560 277 287 561 minecraft:yellow_concrete
fill 277 286 566 277 291 567 minecraft:red_concrete
fill 277 286 568 277 286 569 minecraft:yellow_concrete
fill 277 286 570 277 291 570 minecraft:red_concrete
fill 277 286 578 277 291 579 minecraft:red_concrete
fill 277 286 580 277 287 581 minecraft:yellow_concrete
fill 277 286 587 277 289 588 minecraft:red_concrete
setblock 277 286 589 minecraft:yellow_concrete
fill 277 286 590 277 291 591 minecraft:red_concrete
fill 277 286 592 277 287 592 minecraft:yellow_concrete
setblock 277 286 593 minecraft:red_concrete
fill 277 286 598 277 291 598 minecraft:red_concrete
setblock 235 287 567 minecraft:yellow_concrete
fill 235 287 571 235 290 571 minecraft:red_concrete
fill 235 287 587 235 287 588 minecraft:yellow_concrete
setblock 235 287 591 minecraft:yellow_concrete
fill 235 287 592 235 290 592 minecraft:red_concrete
fill 236 287 557 236 290 557 minecraft:red_concrete
setblock 237 287 557 minecraft:yellow_concrete
fill 239 287 599 239 290 599 minecraft:red_concrete
fill 240 287 557 241 287 557 minecraft:yellow_concrete
fill 243 287 599 243 289 599 minecraft:red_concrete
setblock 244 287 599 minecraft:yellow_concrete
setblock 255 287 599 minecraft:yellow_concrete
fill 256 287 557 257 290 557 minecraft:red_concrete
fill 259 287 599 260 290 599 minecraft:red_concrete
setblock 261 287 557 minecraft:yellow_concrete
setblock 272 287 557 minecraft:yellow_concrete
fill 273 287 557 273 289 557 minecraft:red_concrete
fill 275 287 599 275 289 599 minecraft:red_concrete
setblock 276 287 599 minecraft:yellow_concrete
fill 277 287 557 277 290 557 minecraft:red_concrete
fill 277 287 568 277 290 568 minecraft:red_concrete
setblock 277 287 569 minecraft:yellow_concrete
fill 277 287 572 277 287 573 minecraft:yellow_concrete
fill 277 287 589 277 290 589 minecraft:red_concrete
setblock 277 287 593 minecraft:yellow_concrete
fill 235 288 557 235 288 558 minecraft:yellow_concrete
fill 235 288 559 235 290 560 minecraft:red_concrete
fill 235 288 565 235 289 566 minecraft:yellow_concrete
fill 235 288 567 235 293 568 minecraft:red_concrete
fill 235 288 577 235 288 578 minecraft:yellow_concrete
fill 235 288 579 235 293 580 minecraft:red_concrete
fill 235 288 586 235 289 586 minecraft:yellow_concrete
fill 235 288 587 235 293 588 minecraft:red_concrete
setblock 235 288 589 minecraft:yellow_concrete
fill 235 288 591 235 293 591 minecraft:red_concrete
fill 235 288 597 235 289 598 minecraft:yellow_concrete
fill 235 288 599 236 293 599 minecraft:red_concrete
fill 236 288 558 238 288 558 minecraft:orange_concrete
fill 236 288 560 236 288 562 minecraft:orange_concrete
fill 236 288 564 236 288 566 minecraft:orange_concrete
fill 236 288 568 236 288 570 minecraft:orange_concrete
fill 236 288 572 236 288 574 minecraft:orange_concrete
fill 236 288 576 236 288 578 minecraft:orange_concrete
fill 236 288 580 236 288 582 minecraft:orange_concrete
fill 236 288 584 236 288 586 minecraft:orange_concrete
fill 236 288 588 236 288 590 minecraft:orange_concrete
fill 236 288 592 236 288 594 minecraft:orange_concrete
fill 236 288 596 236 288 598 minecraft:orange_concrete
fill 237 288 557 237 293 557 minecraft:red_concrete
fill 238 288 557 239 288 557 minecraft:yellow_concrete
fill 238 288 598 240 288 598 minecraft:orange_concrete
fill 240 288 557 241 289 557 minecraft:red_concrete
fill 240 288 558 242 288 558 minecraft:orange_concrete
fill 242 288 557 242 289 557 minecraft:yellow_concrete
fill 242 288 598 244 288 598 minecraft:orange_concrete
fill 244 288 558 246 288 558 minecraft:orange_concrete
fill 244 288 599 244 293 599 minecraft:red_concrete
fill 245 288 599 246 288 599 minecraft:yellow_concrete
fill 246 288 598 248 288 598 minecraft:orange_concrete
fill 247 288 599 248 293 599 minecraft:red_concrete
fill 248 288 557 249 293 557 minecraft:red_concrete
fill 248 288 558 250 288 558 minecraft:orange_concrete
fill 250 288 557 251 289 557 minecraft:yellow_concrete
fill 250 288 598 252 288 598 minecraft:orange_concrete
fill 252 288 558 254 288 558 minecraft:orange_concrete
fill 253 288 599 254 289 599 minecraft:yellow_concrete
fill 254 288 598 256 288 598 minecraft:orange_concrete
fill 255 288 599 256 293 599 minecraft:red_concrete
fill 256 288 558 258 288 558 minecraft:orange_concrete
setblock 257 288 599 minecraft:yellow_concrete
fill 258 288 598 260 288 598 minecraft:orange_concrete
setblock 259 288 557 minecraft:yellow_concrete
fill 260 288 557 261 293 557 minecraft:red_concrete
fill 260 288 558 262 288 558 minecraft:orange_concrete
fill 262 288 557 263 289 557 minecraft:yellow_concrete
fill 262 288 598 264 288 598 minecraft:orange_concrete
fill 264 288 558 266 288 558 minecraft:orange_concrete
fill 265 288 599 266 289 599 minecraft:yellow_concrete
fill 266 288 598 268 288 598 minecraft:orange_concrete
fill 267 288 599 268 293 599 minecraft:red_concrete
fill 268 288 557 269 293 557 minecraft:red_concrete
fill 268 288 558 270 288 558 minecraft:orange_concrete
fill 270 288 557 271 288 557 minecraft:yellow_concrete
fill 270 288 598 272 288 598 minecraft:orange_concrete
fill 272 288 557 272 293 557 minecraft:red_concrete
fill 272 288 558 274 288 558 minecraft:orange_concrete
fill 274 288 598 276 288 598 minecraft:orange_concrete
fill 274 288 599 274 289 599 minecraft:yellow_concrete
fill 276 288 558 276 288 560 minecraft:orange_concrete
fill 276 288 562 276 288 564 minecraft:orange_concrete
fill 276 288 566 276 288 568 minecraft:orange_concrete
fill 276 288 570 276 288 572 minecraft:orange_concrete
fill 276 288 574 276 288 576 minecraft:orange_concrete
fill 276 288 578 276 288 580 minecraft:orange_concrete
fill 276 288 582 276 288 584 minecraft:orange_concrete
fill 276 288 586 276 288 588 minecraft:orange_concrete
fill 276 288 590 276 288 592 minecraft:orange_concrete
fill 276 288 594 276 288 596 minecraft:orange_concrete
fill 276 288 599 276 293 599 minecraft:red_concrete
fill 277 288 560 277 293 561 minecraft:red_concrete
fill 277 288 562 277 289 563 minecraft:yellow_concrete
fill 277 288 569 277 293 569 minecraft:red_concrete
setblock 277 288 571 minecraft:yellow_concrete
fill 277 288 572 277 293 573 minecraft:red_concrete
fill 277 288 574 277 289 574 minecraft:yellow_concrete
fill 277 288 580 277 293 581 minecraft:red_concrete
fill 277 288 582 277 288 583 minecraft:yellow_concrete
fill 277 288 592 277 293 593 minecraft:red_concrete
fill 277 288 594 277 289 595 minecraft:yellow_concrete
setblock 277 288 599 minecraft:yellow_concrete
setblock 235 289 557 minecraft:yellow_concrete
fill 235 289 558 235 292 558 minecraft:red_concrete
setblock 235 289 574 minecraft:yellow_concrete
setblock 235 289 577 minecraft:yellow_concrete
fill 235 289 578 235 292 578 minecraft:red_concrete
setblock 235 289 585 minecraft:yellow_concrete
fill 235 289 589 235 292 589 minecraft:red_concrete
fill 238 289 557 239 291 557 minecraft:red_concrete
fill 241 289 599 242 289 599 minecraft:yellow_concrete
setblock 243 289 557 minecraft:yellow_concrete
setblock 245 289 599 minecraft:yellow_concrete
fill 246 289 599 246 292 599 minecraft:red_concrete
setblock 254 289 557 minecraft:yellow_concrete
fill 257 289 599 257 292 599 minecraft:red_concrete
fill 259 289 557 259 292 557 minecraft:red_concrete
setblock 262 289 599 minecraft:yellow_concrete
fill 270 289 557 270 292 557 minecraft:red_concrete
setblock 271 289 557 minecraft:yellow_concrete
setblock 273 289 599 minecraft:yellow_concrete
fill 274 289 557 275 289 557 minecraft:yellow_concrete
fill 277 289 571 277 292 571 minecraft:red_concrete
setblock 277 289 575 minecraft:yellow_concrete
fill 277 289 582 277 292 582 minecraft:red_concrete
setblock 277 289 583 minecraft:yellow_concrete
setblock 277 289 586 minecraft:yellow_concrete
fill 277 289 599 277 292 599 minecraft:red_concrete
fill 235 290 557 235 292 557 minecraft:red_concrete
fill 235 290 563 235 291 564 minecraft:yellow_concrete
fill 235 290 565 235 295 566 minecraft:red_concrete
fill 235 290 572 235 291 572 minecraft:yellow_concrete
fill 235 290 573 235 291 574 minecraft:red_concrete
fill 235 290 575 235 290 576 minecraft:yellow_concrete
fill 235 290 577 235 295 577 minecraft:red_concrete
fill 235 290 583 235 291 584 minecraft:yellow_concrete
fill 235 290 585 235 295 586 minecraft:red_concrete
fill 235 290 595 235 290 596 minecraft:yellow_concrete
fill 235 290 597 235 295 598 minecraft:red_concrete
setblock 238 290 560 minecraft:light[level=14]
setblock 238 290 568 minecraft:light[level=14]
setblock 238 290 576 minecraft:light[level=14]
setblock 238 290 584 minecraft:light[level=14]
setblock 238 290 592 minecraft:light[level=14]
fill 240 290 557 240 293 557 minecraft:red_concrete
fill 240 290 599 240 291 599 minecraft:yellow_concrete
setblock 241 290 557 minecraft:yellow_concrete
fill 241 290 599 242 295 599 minecraft:red_concrete
fill 242 290 557 243 295 557 minecraft:red_concrete
setblock 243 290 599 minecraft:yellow_concrete
fill 244 290 557 245 291 557 minecraft:yellow_concrete
fill 245 290 599 245 295 599 minecraft:red_concrete
setblock 246 290 560 minecraft:light[level=14]
setblock 246 290 568 minecraft:light[level=14]
setblock 246 290 576 minecraft:light[level=14]
setblock 246 290 584 minecraft:light[level=14]
setblock 246 290 592 minecraft:light[level=14]
fill 250 290 557 251 292 557 minecraft:red_concrete
fill 251 290 599 252 291 599 minecraft:yellow_concrete
fill 252 290 557 253 290 557 minecraft:yellow_concrete
fill 253 290 599 254 295 599 minecraft:red_concrete
fill 254 290 557 254 295 557 minecraft:red_concrete
setblock 254 290 560 minecraft:light[level=14]
setblock 254 290 568 minecraft:light[level=14]
setblock 254 290 576 minecraft:light[level=14]
setblock 254 290 584 minecraft:light[level=14]
setblock 254 290 592 minecraft:light[level=14]
fill 262 290 557 263 295 557 minecraft:red_concrete
setblock 262 290 560 minecraft:light[level=14]
setblock 262 290 568 minecraft:light[level=14]
setblock 262 290 576 minecraft:light[level=14]
setblock 262 290 584 minecraft:light[level=14]
setblock 262 290 592 minecraft:light[level=14]
fill 262 290 599 262 295 599 minecraft:red_concrete
fill 263 290 599 264 290 599 minecraft:yellow_concrete
fill 264 290 557 265 291 557 minecraft:yellow_concrete
fill 265 290 599 266 295 599 minecraft:red_concrete
setblock 270 290 560 minecraft:light[level=14]
setblock 270 290 568 minecraft:light[level=14]
setblock 270 290 576 minecraft:light[level=14]
setblock 270 290 584 minecraft:light[level=14]
setblock 270 290 592 minecraft:light[level=14]
fill 271 290 557 271 295 557 minecraft:red_concrete
fill 271 290 599 272 291 599 minecraft:yellow_concrete
setblock 273 290 557 minecraft:yellow_concrete
fill 273 290 599 274 295 599 minecraft:red_concrete
fill 274 290 557 275 295 557 minecraft:red_concrete
setblock 275 290 599 minecraft:yellow_concrete
fill 276 290 557 276 291 557 minecraft:yellow_concrete
fill 277 290 562 277 295 563 minecraft:red_concrete
fill 277 290 564 277 290 565 minecraft:yellow_concrete
fill 277 290 574 277 295 575 minecraft:red_concrete
fill 277 290 576 277 291 577 minecraft:yellow_concrete
fill 277 290 583 277 295 583 minecraft:red_concrete
fill 277 290 584 277 290 585 minecraft:yellow_concrete
fill 277 290 586 277 291 587 minecraft:red_concrete
fill 277 290 588 277 291 588 minecraft:yellow_concrete
fill 277 290 594 277 295 595 minecraft:red_concrete
fill 277 290 596 277 291 597 minecraft:yellow_concrete
fill 235 291 559 235 293 559 minecraft:red_concrete
setblock 235 291 560 minecraft:yellow_concrete
setblock 235 291 571 minecraft:yellow_concrete
fill 235 291 575 235 294 576 minecraft:red_concrete
setblock 235 291 592 minecraft:yellow_concrete
setblock 235 291 595 minecraft:yellow_concrete
fill 235 291 596 235 294 596 minecraft:red_concrete
setblock 236 291 557 minecraft:yellow_concrete
setblock 239 291 599 minecraft:yellow_concrete
fill 241 291 557 241 293 557 minecraft:red_concrete
fill 243 291 599 243 294 599 minecraft:red_concrete
fill 252 291 557 252 294 557 minecraft:red_concrete
setblock 253 291 557 minecraft:yellow_concrete
fill 256 291 557 257 291 557 minecraft:yellow_concrete
fill 259 291 599 260 291 599 minecraft:yellow_concrete
setblock 263 291 599 minecraft:yellow_concrete
fill 264 291 599 264 294 599 minecraft:red_concrete
fill 273 291 557 273 294 557 minecraft:red_concrete
fill 275 291 599 275 294 599 minecraft:red_concrete
setblock 277 291 557 minecraft:yellow_concrete
fill 277 291 564 277 294 564 minecraft:red_concrete
setblock 277 291 565 minecraft:yellow_concrete
setblock 277 291 568 minecraft:yellow_concrete
fill 277 291 584 277 294 585 minecraft:red_concrete
setblock 277 291 589 minecraft:yellow_concrete
fill 235 292 560 235 297 560 minecraft:red_concrete
fill 235 292 561 235 292 562 minecraft:yellow_concrete
fill 235 292 563 235 297 564 minecraft:red_concrete
fill 235 292 569 235 293 570 minecraft:yellow_concrete
fill 235 292 571 235 297 572 minecraft:red_concrete
setblock 235 292 573 minecraft:yellow_concrete
fill 235 292 574 235 295 574 minecraft:red_concrete
fill 235 292 581 235 293 582 minecraft:yellow_concrete
fill 235 292 583 235 297 584 minecraft:red_concrete
fill 235 292 590 235 293 590 minecraft:yellow_concrete
fill 235 292 592 235 297 592 minecraft:red_concrete
fill 235 292 593 235 292 594 minecraft:yellow_concrete
fill 235 292 595 235 297 595 minecraft:red_concrete
fill 236 292 557 236 297 557 minecraft:red_concrete
fill 237 292 599 238 293 599 minecraft:yellow_concrete
fill 238 292 557 238 293 557 minecraft:yellow_concrete
setblock 239 292 557 minecraft:red_concrete
fill 239 292 599 240 297 599 minecraft:red_concrete
fill 244 292 557 245 297 557 minecraft:red_concrete
fill 246 292 557 247 293 557 minecraft:yellow_concrete
fill 249 292 599 250 292 599 minecraft:yellow_concrete
fill 251 292 599 252 297 599 minecraft:red_concrete
fill 253 292 557 253 294 557 minecraft:red_concrete
setblock 255 292 557 minecraft:yellow_concrete
fill 256 292 557 257 297 557 minecraft:red_concrete
fill 258 292 557 258 293 557 minecraft:yellow_concrete
fill 258 292 599 258 293 599 minecraft:yellow_concrete
fill 259 292 599 260 297 599 minecraft:red_concrete
setblock 261 292 599 minecraft:yellow_concrete
fill 263 292 599 263 297 599 minecraft:red_concrete
fill 264 292 557 265 297 557 minecraft:red_concrete
fill 266 292 557 267 292 557 minecraft:yellow_concrete
fill 269 292 599 270 293 599 minecraft:yellow_concrete
fill 271 292 599 272 297 599 minecraft:red_concrete
fill 276 292 557 277 297 557 minecraft:red_concrete
fill 277 292 558 277 293 559 minecraft:yellow_concrete
fill 277 292 565 277 297 565 minecraft:red_concrete
fill 277 292 566 277 292 567 minecraft:yellow_concrete
fill 277 292 568 277 297 568 minecraft:red_concrete
fill 277 292 570 277 293 570 minecraft:yellow_concrete
fill 277 292 576 277 297 577 minecraft:red_concrete
fill 277 292 578 277 293 579 minecraft:yellow_concrete
fill 277 292 586 277 295 586 minecraft:red_concrete
setblock 277 292 587 minecraft:yellow_concrete
fill 277 292 588 277 297 589 minecraft:red_concrete
fill 277 292 590 277 293 591 minecraft:yellow_concrete
fill 277 292 596 277 297 597 minecraft:red_concrete
setblock 277 292 598 minecraft:yellow_concrete
fill 235 293 557 235 293 558 minecraft:yellow_concrete
setblock 235 293 561 minecraft:yellow_concrete
fill 235 293 562 235 296 562 minecraft:red_concrete
fill 235 293 573 235 296 573 minecraft:red_concrete
setblock 235 293 578 minecraft:yellow_concrete
setblock 235 293 589 minecraft:yellow_concrete
fill 235 293 593 235 296 594 minecraft:red_concrete
setblock 239 293 557 minecraft:yellow_concrete
setblock 246 293 599 minecraft:yellow_concrete
fill 247 293 575 247 294 575 minecraft:orange_concrete
setblock 249 293 599 minecraft:yellow_concrete
setblock 250 293 557 minecraft:yellow_concrete
fill 250 293 599 250 296 599 minecraft:red_concrete
fill 251 293 557 251 295 557 minecraft:red_concrete
fill 255 293 557 255 296 557 minecraft:red_concrete
setblock 257 293 599 minecraft:yellow_concrete
setblock 259 293 557 minecraft:yellow_concrete
fill 261 293 599 261 296 599 minecraft:red_concrete
fill 266 293 557 266 296 557 minecraft:red_concrete
setblock 267 293 557 minecraft:yellow_concrete
setblock 270 293 557 minecraft:yellow_concrete
fill 277 293 566 277 296 567 minecraft:red_concrete
setblock 277 293 571 minecraft:yellow_concrete
setblock 277 293 582 minecraft:yellow_concrete
fill 277 293 587 277 296 587 minecraft:red_concrete
fill 277 293 598 277 296 598 minecraft:red_concrete
setblock 277 293 599 minecraft:yellow_concrete
fill 235 294 557 235 299 558 minecraft:red_concrete
setblock 235 294 559 minecraft:yellow_concrete
fill 235 294 561 235 299 561 minecraft:red_concrete
fill 235 294 567 235 295 568 minecraft:yellow_concrete
fill 235 294 569 235 299 570 minecraft:red_concrete
fill 235 294 578 235 299 578 minecraft:red_concrete
fill 235 294 579 235 294 580 minecraft:yellow_concrete
fill 235 294 581 235 299 582 minecraft:red_concrete
fill 235 294 587 235 295 588 minecraft:yellow_concrete
fill 235 294 589 235 299 590 minecraft:red_concrete
setblock 235 294 591 minecraft:yellow_concrete
fill 235 294 599 236 295 599 minecraft:yellow_concrete
fill 236 294 558 238 294 558 minecraft:orange_concrete
fill 236 294 560 236 294 562 minecraft:orange_concrete
fill 236 294 564 236 294 566 minecraft:orange_concrete
fill 236 294 568 236 294 570 minecraft:orange_concrete
fill 236 294 572 236 294 574 minecraft:orange_concrete
fill 236 294 576 236 294 578 minecraft:orange_concrete
fill 236 294 580 236 294 582 minecraft:orange_concrete
fill 236 294 584 236 294 586 minecraft:orange_concrete
fill 236 294 588 236 294 590 minecraft:orange_concrete
fill 236 294 592 236 294 594 minecraft:orange_concrete
fill 236 294 596 236 294 598 minecraft:orange_concrete
setblock 237 294 557 minecraft:yellow_concrete
fill 237 294 599 238 299 599 minecraft:red_concrete
fill 238 294 557 239 299 557 minecraft:red_concrete
fill 238 294 598 240 294 598 minecraft:orange_concrete
fill 240 294 557 241 295 557 minecraft:yellow_concrete
fill 240 294 558 242 294 558 minecraft:orange_concrete
fill 242 294 598 244 294 598 minecraft:orange_concrete
fill 244 294 558 246 294 558 minecraft:orange_concrete
fill 244 294 599 244 295 599 minecraft:yellow_concrete
fill 246 294 557 247 299 557 minecraft:red_concrete
fill 246 294 598 248 294 598 minecraft:orange_concrete
fill 246 294 599 246 299 599 minecraft:red_concrete
fill 247 294 599 248 294 599 minecraft:yellow_concrete
fill 248 294 557 249 294 557 minecraft:yellow_concrete
fill 248 294 558 250 294 558 minecraft:orange_concrete
fill 249 294 599 249 299 599 minecraft:red_concrete
fill 250 294 557 250 295 557 minecraft:red_concrete
fill 250 294 598 252 294 598 minecraft:orange_concrete
fill 252 294 558 254 294 558 minecraft:orange_concrete
fill 254 294 598 256 294 598 minecraft:orange_concrete
fill 255 294 599 256 295 599 minecraft:yellow_concrete
fill 256 294 558 258 294 558 minecraft:orange_concrete
fill 257 294 599 258 299 599 minecraft:red_concrete
fill 258 294 557 259 299 557 minecraft:red_concrete
fill 258 294 598 260 294 598 minecraft:orange_concrete
fill 260 294 557 261 295 557 minecraft:yellow_concrete
fill 260 294 558 262 294 558 minecraft:orange_concrete
fill 262 294 598 264 294 598 minecraft:orange_concrete
fill 264 294 558 266 294 558 minecraft:orange_concrete
fill 266 294 598 268 294 598 minecraft:orange_concrete
fill 267 294 557 267 299 557 minecraft:red_concrete
fill 267 294 599 268 294 599 minecraft:yellow_concrete
fill 268 294 557 269 294 557 minecraft:yellow_concrete
fill 268 294 558 270 294 558 minecraft:orange_concrete
fill 269 294 599 270 299 599 minecraft:red_concrete
fill 270 294 557 270 299 557 minecraft:red_concrete
fill 270 294 598 272 294 598 minecraft:orange_concrete
fill 272 294 557 272 295 557 minecraft:yellow_concrete
fill 272 294 558 274 294 558 minecraft:orange_concrete
fill 274 294 598 276 294 598 minecraft:orange_concrete
fill 276 294 558 276 294 560 minecraft:orange_concrete
fill 276 294 562 276 294 564 minecraft:orange_concrete
fill 276 294 566 276 294 568 minecraft:orange_concrete
fill 276 294 570 276 294 572 minecraft:orange_concrete
fill 276 294 574 276 294 576 minecraft:orange_concrete
fill 276 294 578 276 294 580 minecraft:orange_concrete
fill 276 294 582 276 294 584 minecraft:orange_concrete
fill 276 294 586 276 294 588 minecraft:orange_concrete
fill 276 294 590 276 294 592 minecraft:orange_concrete
fill 276 294 594 276 294 596 minecraft:orange_concrete
fill 276 294 599 276 295 599 minecraft:yellow_concrete
fill 277 294 558 277 299 559 minecraft:red_concrete
fill 277 294 560 277 295 561 minecraft:yellow_concrete
setblock 277 294 569 minecraft:yellow_concrete
fill 277 294 570 277 299 571 minecraft:red_concrete
fill 277 294 572 277 295 573 minecraft:yellow_concrete
fill 277 294 578 277 299 579 minecraft:red_concrete
fill 277 294 580 277 294 581 minecraft:yellow_concrete
fill 277 294 582 277 299 582 minecraft:red_concrete
fill 277 294 590 277 299 591 minecraft:red_concrete
fill 277 294 592 277 295 593 minecraft:yellow_concrete
fill 277 294 599 277 299 599 minecraft:red_concrete
fill 235 295 559 235 298 559 minecraft:red_concrete
fill 235 295 575 235 295 576 minecraft:yellow_concrete
setblock 235 295 579 minecraft:yellow_concrete
fill 235 295 580 235 298 580 minecraft:red_concrete
fill 235 295 591 235 298 591 minecraft:red_concrete
setblock 235 295 596 minecraft:yellow_concrete
fill 237 295 557 237 298 557 minecraft:red_concrete
setblock 243 295 599 minecraft:yellow_concrete
fill 247 295 599 248 298 599 minecraft:red_concrete
fill 248 295 557 248 298 557 minecraft:red_concrete
setblock 249 295 557 minecraft:yellow_concrete
fill 252 295 557 253 295 557 minecraft:yellow_concrete
setblock 264 295 599 minecraft:yellow_concrete
setblock 267 295 599 minecraft:yellow_concrete
fill 268 295 557 269 298 557 minecraft:red_concrete
fill 268 295 599 268 298 599 minecraft:red_concrete
setblock 273 295 557 minecraft:yellow_concrete
setblock 275 295 599 minecraft:yellow_concrete
setblock 277 295 564 minecraft:yellow_concrete
fill 277 295 569 277 298 569 minecraft:red_concrete
fill 277 295 580 277 298 580 minecraft:red_concrete
setblock 277 295 581 minecraft:yellow_concrete
fill 277 295 584 277 295 585 minecraft:yellow_concrete
fill 235 296 565 235 296 566 minecraft:yellow_concrete
fill 235 296 567 235 307 568 minecraft:red_concrete
fill 235 296 574 235 297 574 minecraft:yellow_concrete
fill 235 296 575 235 307 576 minecraft:red_concrete
setblock 235 296 577 minecraft:yellow_concrete
fill 235 296 579 235 307 579 minecraft:red_concrete
fill 235 296 585 235 297 586 minecraft:yellow_concrete
fill 235 296 587 235 307 588 minecraft:red_concrete
fill 235 296 596 235 307 596 minecraft:red_concrete
fill 235 296 597 235 296 598 minecraft:yellow_concrete
fill 235 296 599 236 307 599 minecraft:red_concrete
fill 240 296 557 241 307 557 minecraft:red_concrete
fill 241 296 599 242 297 599 minecraft:yellow_concrete
fill 242 296 557 243 297 557 minecraft:yellow_concrete
fill 243 296 599 244 307 599 minecraft:red_concrete
setblock 245 296 599 minecraft:yellow_concrete
fill 249 296 557 249 307 557 minecraft:red_concrete
fill 250 296 557 251 296 557 minecraft:yellow_concrete
fill 252 296 557 253 297 557 minecraft:red_concrete
fill 253 296 599 254 297 599 minecraft:yellow_concrete
fill 254 296 557 254 297 557 minecraft:yellow_concrete
fill 255 296 599 256 307 599 minecraft:red_concrete
fill 260 296 557 261 307 557 minecraft:red_concrete
fill 262 296 557 263 297 557 minecraft:yellow_concrete
fill 262 296 599 262 297 599 minecraft:yellow_concrete
fill 264 296 599 264 307 599 minecraft:red_concrete
fill 265 296 599 266 296 599 minecraft:yellow_concrete
fill 267 296 599 267 307 599 minecraft:red_concrete
setblock 271 296 557 minecraft:yellow_concrete
fill 272 296 557 273 307 557 minecraft:red_concrete
fill 273 296 599 274 297 599 minecraft:yellow_concrete
fill 274 296 557 275 297 557 minecraft:yellow_concrete
fill 275 296 599 276 307 599 minecraft:red_concrete
fill 277 296 560 277 307 561 minecraft:red_concrete
fill 277 296 562 277 296 563 minecraft:yellow_concrete
fill 277 296 564 277 307 564 minecraft:red_concrete
fill 277 296 572 277 307 573 minecraft:red_concrete
fill 277 296 574 277 297 575 minecraft:yellow_concrete
fill 277 296 581 277 307 581 minecraft:red_concrete
setblock 277 296 583 minecraft:yellow_concrete
fill 277 296 584 277 307 585 minecraft:red_concrete
fill 277 296 586 277 297 586 minecraft:yellow_concrete
fill 277 296 592 277 307 593 minecraft:red_concrete
fill 277 296 594 277 296 595 minecraft:yellow_concrete
setblock 235 297 562 minecraft:yellow_concrete
setblock 235 297 565 minecraft:yellow_concrete
fill 235 297 566 235 307 566 minecraft:red_concrete
setblock 235 297 573 minecraft:yellow_concrete
fill 235 297 577 235 307 577 minecraft:red_concrete
fill 235 297 593 235 297 594 minecraft:yellow_concrete
setblock 235 297 597 minecraft:yellow_concrete
fill 235 297 598 235 307 598 minecraft:red_concrete
fill 245 297 599 245 307 599 minecraft:red_concrete
fill 250 297 557 251 299 557 minecraft:red_concrete
setblock 250 297 599 minecraft:yellow_concrete
setblock 255 297 557 minecraft:yellow_concrete
setblock 261 297 599 minecraft:yellow_concrete
fill 265 297 599 266 307 599 minecraft:red_concrete
setblock 266 297 557 minecraft:yellow_concrete
fill 271 297 557 271 307 557 minecraft:red_concrete
fill 277 297 562 277 307 562 minecraft:red_concrete
setblock 277 297 563 minecraft:yellow_concrete
fill 277 297 566 277 297 567 minecraft:yellow_concrete
fill 277 297 583 277 307 583 minecraft:red_concrete
setblock 277 297 587 minecraft:yellow_concrete
fill 277 297 594 277 307 594 minecraft:red_concrete
setblock 277 297 595 minecraft:yellow_concrete
setblock 277 297 598 minecraft:yellow_concrete
fill 235 298 560 235 299 560 minecraft:yellow_concrete
fill 235 298 562 235 307 562 minecraft:red_concrete
fill 235 298 563 235 298 564 minecraft:yellow_concrete
fill 235 298 565 235 307 565 minecraft:red_concrete
fill 235 298 571 235 299 572 minecraft:yellow_concrete
fill 235 298 573 235 307 574 minecraft:red_concrete
fill 235 298 583 235 298 584 minecraft:yellow_concrete
fill 235 298 585 235 307 586 minecraft:red_concrete
fill 235 298 592 235 299 592 minecraft:yellow_concrete
fill 235 298 593 235 307 594 minecraft:red_concrete
setblock 235 298 595 minecraft:yellow_concrete
fill 235 298 597 235 307 597 minecraft:red_concrete
fill 236 298 557 236 299 557 minecraft:yellow_concrete
setblock 238 298 560 minecraft:light[level=14]
setblock 238 298 568 minecraft:light[level=14]
setblock 238 298 576 minecraft:light[level=14]
setblock 238 298 584 minecraft:light[level=14]
setblock 238 298 592 minecraft:light[level=14]
fill 239 298 599 240 299 599 minecraft:yellow_concrete
fill 241 298 599 242 307 599 minecraft:red_concrete
fill 242 298 557 243 307 557 minecraft:red_concrete
fill 244 298 557 245 299 557 minecraft:yellow_concrete
setblock 246 298 560 minecraft:light[level=14]
setblock 246 298 568 minecraft:light[level=14]
setblock 246 298 576 minecraft:light[level=14]
setblock 246 298 584 minecraft:light[level=14]
setblock 246 298 592 minecraft:light[level=14]
fill 250 298 599 250 307 599 minecraft:red_concrete
fill 251 298 599 252 298 599 minecraft:yellow_concrete
fill 252 298 557 252 307 557 minecraft:red_concrete
setblock 253 298 557 minecraft:yellow_concrete
fill 253 298 599 254 307 599 minecraft:red_concrete
fill 254 298 557 255 307 557 minecraft:red_concrete
setblock 254 298 560 minecraft:light[level=14]
setblock 254 298 568 minecraft:light[level=14]
setblock 254 298 576 minecraft:light[level=14]
setblock 254 298 584 minecraft:light[level=14]
setblock 254 298 592 minecraft:light[level=14]
fill 256 298 557 257 299 557 minecraft:yellow_concrete
fill 259 298 599 260 299 599 minecraft:yellow_concrete
fill 261 298 599 262 307 599 minecraft:red_concrete
fill 262 298 557 263 307 557 minecraft:red_concrete
setblock 262 298 560 minecraft:light[level=14]
setblock 262 298 568 minecraft:light[level=14]
setblock 262 298 576 minecraft:light[level=14]
setblock 262 298 584 minecraft:light[level=14]
setblock 262 298 592 minecraft:light[level=14]
setblock 263 298 599 minecraft:yellow_concrete
fill 264 298 557 265 298 557 minecraft:yellow_concrete
fill 266 298 557 266 307 557 minecraft:red_concrete
setblock 270 298 560 minecraft:light[level=14]
setblock 270 298 568 minecraft:light[level=14]
setblock 270 298 576 minecraft:light[level=14]
setblock 270 298 584 minecraft:light[level=14]
setblock 270 298 592 minecraft:light[level=14]
fill 271 298 599 272 299 599 minecraft:yellow_concrete
fill 273 298 599 274 307 599 minecraft:red_concrete
fill 274 298 557 275 307 557 minecraft:red_concrete
fill 276 298 557 277 299 557 minecraft:yellow_concrete
fill 277 298 563 277 307 563 minecraft:red_concrete
setblock 277 298 565 minecraft:yellow_concrete
fill 277 298 566 277 307 567 minecraft:red_concrete
fill 277 298 568 277 299 568 minecraft:yellow_concrete
fill 277 298 574 277 307 575 minecraft:red_concrete
fill 277 298 576 277 298 577 minecraft:yellow_concrete
fill 277 298 586 277 307 587 minecraft:red_concrete
fill 277 298 588 277 299 589 minecraft:yellow_concrete
fill 277 298 595 277 307 595 minecraft:red_concrete
fill 277 298 596 277 298 597 minecraft:yellow_concrete
fill 277 298 598 277 307 598 minecraft:red_concrete
setblock 235 299 559 minecraft:yellow_concrete
fill 235 299 563 235 307 564 minecraft:red_concrete
setblock 235 299 580 minecraft:yellow_concrete
setblock 235 299 583 minecraft:yellow_concrete
fill 235 299 584 235 307 584 minecraft:red_concrete
setblock 235 299 591 minecraft:yellow_concrete
fill 235 299 595 235 307 595 minecraft:red_concrete
setblock 237 299 557 minecraft:yellow_concrete
fill 247 299 599 248 299 599 minecraft:yellow_concrete
setblock 248 299 557 minecraft:yellow_concrete
setblock 251 299 599 minecraft:yellow_concrete
fill 252 299 599 252 307 599 minecraft:red_concrete
fill 253 299 557 253 307 557 minecraft:red_concrete
fill 263 299 599 263 307 599 minecraft:red_concrete
fill 264 299 557 264 307 557 minecraft:red_concrete
setblock 265 299 557 minecraft:yellow_concrete
fill 268 299 557 269 299 557 minecraft:yellow_concrete
setblock 268 299 599 minecraft:yellow_concrete
fill 277 299 565 277 307 565 minecraft:red_concrete
setblock 277 299 569 minecraft:yellow_concrete
fill 277 299 576 277 307 576 minecraft:red_concrete
setblock 277 299 577 minecraft:yellow_concrete
setblock 277 299 580 minecraft:yellow_concrete
fill 277 299 596 277 307 597 minecraft:red_concrete
fill 235 300 557 235 300 558 minecraft:yellow_concrete
fill 235 300 559 235 307 560 minecraft:red_concrete
setblock 235 300 561 minecraft:yellow_concrete
fill 235 300 569 235 300 570 minecraft:yellow_concrete
fill 235 300 571 235 307 572 minecraft:red_concrete
setblock 235 300 578 minecraft:yellow_concrete
fill 235 300 580 235 307 580 minecraft:red_concrete
fill 235 300 581 235 300 582 minecraft:yellow_concrete
fill 235 300 583 235 307 583 minecraft:red_concrete
fill 235 300 589 235 300 590 minecraft:yellow_concrete
fill 235 300 591 235 307 592 minecraft:red_concrete
fill 236 300 557 237 307 557 minecraft:red_concrete
fill 236 300 558 238 300 558 minecraft:orange_concrete
fill 236 300 560 236 300 562 minecraft:orange_concrete
fill 236 300 564 236 300 566 minecraft:orange_concrete
fill 236 300 568 236 300 570 minecraft:orange_concrete
fill 236 300 572 236 300 574 minecraft:orange_concrete
fill 236 300 576 236 300 578 minecraft:orange_concrete
fill 236 300 580 236 300 582 minecraft:orange_concrete
fill 236 300 584 236 300 586 minecraft:orange_concrete
fill 236 300 588 236 300 590 minecraft:orange_concrete
fill 236 300 592 236 300 594 minecraft:orange_concrete
schedule function dropper:buildpart/137_5 1t
