fill 557 267 189 557 270 189 minecraft:packed_mud
setblock 557 267 192 minecraft:packed_mud
setblock 557 267 193 minecraft:bone_block
fill 557 267 194 557 270 194 minecraft:packed_mud
fill 557 267 206 557 268 206 minecraft:packed_mud
setblock 557 267 208 minecraft:bone_block
fill 557 267 209 557 270 209 minecraft:packed_mud
setblock 557 267 213 minecraft:bone_block
fill 557 267 214 557 270 214 minecraft:packed_mud
setblock 557 267 218 minecraft:bone_block
fill 557 267 219 557 270 219 minecraft:packed_mud
setblock 558 267 187 minecraft:bone_block
fill 558 267 188 558 270 188 minecraft:packed_mud
setblock 558 267 192 minecraft:bone_block
fill 558 267 193 558 270 193 minecraft:packed_mud
setblock 558 267 196 minecraft:packed_mud
setblock 558 267 197 minecraft:bone_block
fill 558 267 198 558 267 201 minecraft:packed_mud
setblock 558 267 202 minecraft:bone_block
fill 558 267 203 558 270 203 minecraft:packed_mud
setblock 558 267 207 minecraft:bone_block
fill 558 267 208 558 270 208 minecraft:packed_mud
setblock 558 267 212 minecraft:bone_block
fill 558 267 213 558 270 213 minecraft:packed_mud
setblock 558 267 217 minecraft:bone_block
fill 558 267 218 558 270 218 minecraft:packed_mud
setblock 558 267 222 minecraft:bone_block
setblock 518 268 185 minecraft:packed_mud
setblock 518 268 186 minecraft:bone_block
fill 518 268 187 518 271 187 minecraft:packed_mud
setblock 518 268 191 minecraft:bone_block
fill 518 268 192 518 268 195 minecraft:packed_mud
setblock 518 268 196 minecraft:bone_block
fill 518 268 197 518 268 200 minecraft:packed_mud
setblock 518 268 201 minecraft:bone_block
fill 518 268 202 518 271 202 minecraft:packed_mud
setblock 518 268 206 minecraft:bone_block
fill 518 268 207 518 271 207 minecraft:packed_mud
setblock 518 268 211 minecraft:bone_block
fill 518 268 212 518 271 212 minecraft:packed_mud
setblock 518 268 216 minecraft:bone_block
fill 518 268 217 518 271 217 minecraft:packed_mud
setblock 518 268 221 minecraft:bone_block
fill 518 268 222 519 270 222 minecraft:packed_mud
setblock 519 268 190 minecraft:bone_block
fill 519 268 191 519 271 191 minecraft:packed_mud
setblock 519 268 195 minecraft:bone_block
fill 519 268 196 519 268 199 minecraft:packed_mud
setblock 519 268 200 minecraft:bone_block
fill 519 268 201 519 271 201 minecraft:packed_mud
setblock 519 268 205 minecraft:bone_block
fill 519 268 206 519 271 206 minecraft:packed_mud
setblock 519 268 210 minecraft:bone_block
fill 519 268 211 519 271 211 minecraft:packed_mud
setblock 519 268 215 minecraft:bone_block
fill 519 268 216 519 271 216 minecraft:packed_mud
setblock 520 268 194 minecraft:bone_block
fill 520 268 195 520 271 195 minecraft:packed_mud
fill 520 268 197 520 268 198 minecraft:packed_mud
setblock 520 268 209 minecraft:bone_block
fill 520 268 210 520 270 210 minecraft:packed_mud
setblock 520 268 214 minecraft:bone_block
fill 520 268 215 520 271 215 minecraft:packed_mud
fill 533 268 182 533 271 182 minecraft:packed_mud
setblock 535 268 183 minecraft:packed_mud
fill 535 268 222 536 268 222 minecraft:packed_mud
setblock 536 268 183 minecraft:bone_block
setblock 537 268 182 minecraft:bone_block
fill 537 268 183 537 271 183 minecraft:packed_mud
setblock 537 268 222 minecraft:bone_block
fill 538 268 182 538 271 182 minecraft:packed_mud
setblock 538 268 221 minecraft:bone_block
fill 538 268 222 538 271 222 minecraft:packed_mud
fill 539 268 221 541 269 221 minecraft:packed_mud
setblock 541 268 183 minecraft:bone_block
setblock 542 268 182 minecraft:bone_block
setblock 542 268 222 minecraft:bone_block
fill 543 268 182 543 271 182 minecraft:packed_mud
fill 543 268 222 545 269 222 minecraft:packed_mud
fill 550 268 222 551 268 222 minecraft:packed_mud
setblock 552 268 222 minecraft:bone_block
setblock 553 268 221 minecraft:bone_block
fill 553 268 222 553 271 222 minecraft:packed_mud
fill 554 268 221 554 271 221 minecraft:packed_mud
setblock 555 268 213 minecraft:packed_mud
setblock 555 268 214 minecraft:bone_block
fill 555 268 215 555 269 217 minecraft:packed_mud
fill 555 268 220 556 270 220 minecraft:packed_mud
setblock 556 268 182 minecraft:packed_mud
fill 556 268 209 556 271 209 minecraft:packed_mud
setblock 556 268 213 minecraft:bone_block
fill 556 268 214 556 271 214 minecraft:packed_mud
setblock 556 268 218 minecraft:bone_block
fill 556 268 219 556 271 219 minecraft:packed_mud
setblock 557 268 182 minecraft:bone_block
setblock 557 268 192 minecraft:bone_block
fill 557 268 193 557 271 193 minecraft:packed_mud
fill 557 268 195 557 268 196 minecraft:packed_mud
setblock 557 268 197 minecraft:bone_block
setblock 557 268 207 minecraft:bone_block
fill 557 268 208 557 271 208 minecraft:packed_mud
setblock 557 268 212 minecraft:bone_block
fill 557 268 213 557 271 213 minecraft:packed_mud
setblock 557 268 217 minecraft:bone_block
fill 557 268 218 557 271 218 minecraft:packed_mud
setblock 557 268 222 minecraft:bone_block
fill 558 268 184 558 269 184 minecraft:packed_mud
setblock 558 268 186 minecraft:bone_block
fill 558 268 187 558 271 187 minecraft:packed_mud
setblock 558 268 191 minecraft:bone_block
fill 558 268 192 558 271 192 minecraft:packed_mud
setblock 558 268 196 minecraft:bone_block
fill 558 268 197 558 268 200 minecraft:packed_mud
setblock 558 268 201 minecraft:bone_block
fill 558 268 202 558 271 202 minecraft:packed_mud
setblock 558 268 206 minecraft:bone_block
fill 558 268 207 558 271 207 minecraft:packed_mud
setblock 558 268 211 minecraft:bone_block
fill 558 268 212 558 271 212 minecraft:packed_mud
setblock 558 268 216 minecraft:bone_block
fill 558 268 217 558 271 217 minecraft:packed_mud
setblock 558 268 221 minecraft:bone_block
fill 558 268 222 558 271 222 minecraft:packed_mud
setblock 518 269 185 minecraft:bone_block
fill 518 269 186 518 272 186 minecraft:packed_mud
setblock 518 269 190 minecraft:bone_block
fill 518 269 191 518 269 194 minecraft:packed_mud
setblock 518 269 195 minecraft:bone_block
fill 518 269 196 518 269 199 minecraft:packed_mud
setblock 518 269 200 minecraft:bone_block
fill 518 269 201 518 272 201 minecraft:packed_mud
setblock 518 269 205 minecraft:bone_block
fill 518 269 206 518 272 206 minecraft:packed_mud
setblock 518 269 210 minecraft:bone_block
fill 518 269 211 518 272 211 minecraft:packed_mud
setblock 518 269 215 minecraft:bone_block
fill 518 269 216 518 272 216 minecraft:packed_mud
setblock 518 269 220 minecraft:bone_block
fill 518 269 221 518 272 221 minecraft:packed_mud
setblock 519 269 189 minecraft:bone_block
fill 519 269 190 519 272 190 minecraft:packed_mud
setblock 519 269 193 minecraft:packed_mud
setblock 519 269 194 minecraft:bone_block
fill 519 269 195 519 269 198 minecraft:packed_mud
setblock 519 269 199 minecraft:bone_block
fill 519 269 200 520 271 200 minecraft:packed_mud
setblock 519 269 204 minecraft:bone_block
fill 519 269 205 519 272 205 minecraft:packed_mud
setblock 519 269 209 minecraft:bone_block
fill 519 269 210 519 272 210 minecraft:packed_mud
setblock 519 269 214 minecraft:bone_block
fill 519 269 215 519 272 215 minecraft:packed_mud
setblock 519 269 219 minecraft:bone_block
fill 519 269 220 519 272 220 minecraft:packed_mud
setblock 520 269 193 minecraft:bone_block
fill 520 269 194 520 272 194 minecraft:packed_mud
setblock 520 269 197 minecraft:packed_mud
setblock 520 269 198 minecraft:bone_block
fill 520 269 199 520 272 199 minecraft:packed_mud
setblock 520 269 209 minecraft:packed_mud
setblock 520 269 213 minecraft:bone_block
fill 520 269 214 520 271 214 minecraft:packed_mud
setblock 520 269 217 minecraft:packed_mud
setblock 520 269 222 minecraft:packed_mud
fill 532 269 182 532 272 182 minecraft:packed_mud
setblock 534 269 183 minecraft:packed_mud
fill 534 269 222 535 269 222 minecraft:packed_mud
setblock 535 269 183 minecraft:bone_block
setblock 536 269 182 minecraft:bone_block
fill 536 269 183 536 272 183 minecraft:packed_mud
setblock 536 269 221 minecraft:packed_mud
setblock 536 269 222 minecraft:bone_block
fill 537 269 182 537 272 182 minecraft:packed_mud
setblock 537 269 221 minecraft:bone_block
fill 537 269 222 537 272 222 minecraft:packed_mud
fill 538 269 221 538 272 221 minecraft:packed_mud
setblock 540 269 183 minecraft:bone_block
setblock 541 269 182 minecraft:bone_block
fill 541 269 183 541 272 183 minecraft:packed_mud
setblock 541 269 222 minecraft:bone_block
fill 542 269 182 542 272 182 minecraft:packed_mud
setblock 542 269 221 minecraft:bone_block
fill 542 269 222 542 272 222 minecraft:packed_mud
fill 543 269 221 543 272 221 minecraft:packed_mud
setblock 546 269 222 minecraft:bone_block
fill 547 269 222 550 269 222 minecraft:packed_mud
setblock 551 269 221 minecraft:packed_mud
setblock 551 269 222 minecraft:bone_block
setblock 552 269 221 minecraft:bone_block
fill 552 269 222 552 272 222 minecraft:packed_mud
setblock 553 269 220 minecraft:bone_block
fill 553 269 221 553 272 221 minecraft:packed_mud
fill 554 269 182 555 269 182 minecraft:packed_mud
fill 554 269 220 554 272 220 minecraft:packed_mud
setblock 555 269 212 minecraft:packed_mud
setblock 555 269 213 minecraft:bone_block
fill 555 269 214 555 272 214 minecraft:packed_mud
setblock 555 269 218 minecraft:bone_block
fill 555 269 219 555 272 219 minecraft:packed_mud
setblock 556 269 182 minecraft:bone_block
setblock 556 269 212 minecraft:bone_block
fill 556 269 213 556 272 213 minecraft:packed_mud
setblock 556 269 216 minecraft:packed_mud
setblock 556 269 217 minecraft:bone_block
fill 556 269 218 556 272 218 minecraft:packed_mud
setblock 556 269 222 minecraft:bone_block
fill 557 269 182 558 271 182 minecraft:packed_mud
setblock 557 269 190 minecraft:packed_mud
setblock 557 269 191 minecraft:bone_block
fill 557 269 192 557 272 192 minecraft:packed_mud
setblock 557 269 195 minecraft:packed_mud
setblock 557 269 196 minecraft:bone_block
fill 557 269 197 557 269 200 minecraft:packed_mud
setblock 557 269 201 minecraft:bone_block
fill 557 269 204 557 269 205 minecraft:packed_mud
setblock 557 269 206 minecraft:bone_block
fill 557 269 207 557 272 207 minecraft:packed_mud
setblock 557 269 211 minecraft:bone_block
fill 557 269 212 557 272 212 minecraft:packed_mud
setblock 557 269 216 minecraft:bone_block
fill 557 269 217 557 272 217 minecraft:packed_mud
setblock 557 269 220 minecraft:packed_mud
setblock 557 269 221 minecraft:bone_block
fill 557 269 222 557 272 222 minecraft:packed_mud
fill 558 269 183 558 270 183 minecraft:packed_mud
setblock 558 269 185 minecraft:bone_block
fill 558 269 186 558 271 186 minecraft:packed_mud
setblock 558 269 190 minecraft:bone_block
fill 558 269 191 558 272 191 minecraft:packed_mud
setblock 558 269 195 minecraft:bone_block
fill 558 269 196 558 269 199 minecraft:packed_mud
setblock 558 269 200 minecraft:bone_block
fill 558 269 201 558 272 201 minecraft:packed_mud
setblock 558 269 205 minecraft:bone_block
fill 558 269 206 558 272 206 minecraft:packed_mud
setblock 558 269 210 minecraft:bone_block
fill 558 269 211 558 272 211 minecraft:packed_mud
setblock 558 269 215 minecraft:bone_block
fill 558 269 216 558 272 216 minecraft:packed_mud
setblock 558 269 220 minecraft:bone_block
fill 558 269 221 558 272 221 minecraft:packed_mud
fill 518 270 185 518 272 185 minecraft:packed_mud
setblock 518 270 189 minecraft:bone_block
fill 518 270 190 518 270 193 minecraft:packed_mud
setblock 518 270 194 minecraft:bone_block
fill 518 270 195 518 270 198 minecraft:packed_mud
setblock 518 270 199 minecraft:bone_block
fill 518 270 200 518 272 200 minecraft:packed_mud
setblock 518 270 204 minecraft:bone_block
fill 518 270 205 518 272 205 minecraft:packed_mud
setblock 518 270 209 minecraft:bone_block
fill 518 270 210 518 272 210 minecraft:packed_mud
setblock 518 270 214 minecraft:bone_block
fill 518 270 215 518 272 215 minecraft:packed_mud
setblock 518 270 219 minecraft:bone_block
fill 518 270 220 518 272 220 minecraft:packed_mud
setblock 519 270 188 minecraft:bone_block
fill 519 270 189 519 272 189 minecraft:packed_mud
setblock 519 270 193 minecraft:bone_block
fill 519 270 194 519 270 197 minecraft:packed_mud
setblock 519 270 198 minecraft:bone_block
fill 519 270 199 519 272 199 minecraft:packed_mud
setblock 519 270 203 minecraft:bone_block
fill 519 270 204 519 272 204 minecraft:packed_mud
setblock 519 270 208 minecraft:bone_block
fill 519 270 209 519 272 209 minecraft:packed_mud
setblock 519 270 213 minecraft:bone_block
fill 519 270 214 519 272 214 minecraft:packed_mud
setblock 519 270 218 minecraft:bone_block
fill 519 270 219 519 272 219 minecraft:packed_mud
fill 519 270 221 519 271 221 minecraft:packed_mud
setblock 520 270 192 minecraft:bone_block
fill 520 270 193 520 272 193 minecraft:packed_mud
setblock 520 270 197 minecraft:bone_block
fill 520 270 198 520 272 198 minecraft:packed_mud
setblock 520 270 201 minecraft:packed_mud
setblock 520 270 212 minecraft:bone_block
fill 520 270 213 520 271 213 minecraft:packed_mud
setblock 520 270 217 minecraft:bone_block
setblock 520 270 222 minecraft:bone_block
fill 531 270 182 531 272 182 minecraft:packed_mud
fill 532 270 222 534 270 222 minecraft:packed_mud
setblock 533 270 183 minecraft:packed_mud
setblock 534 270 183 minecraft:bone_block
fill 534 270 221 535 270 221 minecraft:packed_mud
setblock 535 270 182 minecraft:bone_block
fill 535 270 183 535 272 183 minecraft:packed_mud
setblock 535 270 222 minecraft:bone_block
fill 536 270 182 536 272 182 minecraft:packed_mud
fill 536 270 184 537 270 184 minecraft:packed_mud
setblock 536 270 220 minecraft:packed_mud
setblock 536 270 221 minecraft:bone_block
fill 536 270 222 536 272 222 minecraft:packed_mud
setblock 537 270 220 minecraft:bone_block
fill 537 270 221 537 272 221 minecraft:packed_mud
setblock 538 270 184 minecraft:bone_block
fill 538 270 220 540 271 220 minecraft:packed_mud
setblock 539 270 183 minecraft:bone_block
fill 539 270 221 540 270 221 minecraft:packed_mud
setblock 540 270 182 minecraft:bone_block
fill 540 270 183 540 272 183 minecraft:packed_mud
setblock 540 270 222 minecraft:bone_block
fill 541 270 182 541 272 182 minecraft:packed_mud
setblock 541 270 221 minecraft:bone_block
fill 541 270 222 541 272 222 minecraft:packed_mud
fill 542 270 221 542 272 221 minecraft:packed_mud
fill 543 270 222 544 270 222 minecraft:packed_mud
fill 544 270 221 544 271 221 minecraft:packed_mud
setblock 545 270 222 minecraft:bone_block
fill 546 270 222 549 270 222 minecraft:packed_mud
fill 548 270 221 550 270 221 minecraft:packed_mud
setblock 550 270 222 minecraft:bone_block
setblock 551 270 220 minecraft:packed_mud
setblock 551 270 221 minecraft:bone_block
fill 551 270 222 551 272 222 minecraft:packed_mud
fill 552 270 182 554 270 182 minecraft:packed_mud
setblock 552 270 220 minecraft:bone_block
fill 552 270 221 552 272 221 minecraft:packed_mud
setblock 553 270 219 minecraft:bone_block
fill 553 270 220 553 272 220 minecraft:packed_mud
fill 554 270 219 554 272 219 minecraft:packed_mud
setblock 555 270 182 minecraft:bone_block
setblock 555 270 211 minecraft:packed_mud
setblock 555 270 212 minecraft:bone_block
fill 555 270 213 555 272 213 minecraft:packed_mud
fill 555 270 215 555 270 216 minecraft:packed_mud
setblock 555 270 217 minecraft:bone_block
fill 555 270 218 555 272 218 minecraft:packed_mud
setblock 555 270 221 minecraft:packed_mud
setblock 555 270 222 minecraft:bone_block
fill 556 270 182 556 272 182 minecraft:packed_mud
fill 556 270 193 556 270 195 minecraft:packed_mud
setblock 556 270 196 minecraft:bone_block
fill 556 270 197 558 271 197 minecraft:packed_mud
fill 556 270 208 556 272 208 minecraft:packed_mud
setblock 556 270 211 minecraft:bone_block
fill 556 270 212 556 272 212 minecraft:packed_mud
setblock 556 270 216 minecraft:bone_block
fill 556 270 217 556 272 217 minecraft:packed_mud
setblock 556 270 221 minecraft:bone_block
fill 556 270 222 556 272 222 minecraft:packed_mud
setblock 557 270 190 minecraft:bone_block
fill 557 270 191 557 272 191 minecraft:packed_mud
setblock 557 270 195 minecraft:bone_block
fill 557 270 196 558 272 196 minecraft:packed_mud
fill 557 270 198 557 270 199 minecraft:packed_mud
setblock 557 270 200 minecraft:bone_block
fill 557 270 201 557 270 204 minecraft:packed_mud
setblock 557 270 205 minecraft:bone_block
fill 557 270 206 557 272 206 minecraft:packed_mud
setblock 557 270 210 minecraft:bone_block
fill 557 270 211 557 272 211 minecraft:packed_mud
setblock 557 270 215 minecraft:bone_block
fill 557 270 216 557 272 216 minecraft:packed_mud
setblock 557 270 220 minecraft:bone_block
fill 557 270 221 557 272 221 minecraft:packed_mud
setblock 558 270 184 minecraft:bone_block
fill 558 270 185 558 271 185 minecraft:packed_mud
setblock 558 270 189 minecraft:bone_block
fill 558 270 190 558 272 190 minecraft:packed_mud
setblock 558 270 194 minecraft:bone_block
fill 558 270 195 558 272 195 minecraft:packed_mud
setblock 558 270 198 minecraft:packed_mud
setblock 558 270 199 minecraft:bone_block
fill 558 270 200 558 272 200 minecraft:packed_mud
setblock 558 270 204 minecraft:bone_block
fill 558 270 205 558 272 205 minecraft:packed_mud
setblock 558 270 209 minecraft:bone_block
fill 558 270 210 558 272 210 minecraft:packed_mud
setblock 558 270 214 minecraft:bone_block
fill 558 270 215 558 272 215 minecraft:packed_mud
setblock 558 270 219 minecraft:bone_block
fill 558 270 220 558 272 220 minecraft:packed_mud
setblock 518 271 182 minecraft:packed_mud
setblock 518 271 188 minecraft:bone_block
fill 518 271 189 518 271 192 minecraft:packed_mud
setblock 518 271 193 minecraft:bone_block
fill 518 271 194 518 271 197 minecraft:packed_mud
setblock 518 271 198 minecraft:bone_block
fill 518 271 199 518 272 199 minecraft:packed_mud
setblock 518 271 203 minecraft:bone_block
fill 518 271 204 518 272 204 minecraft:packed_mud
setblock 518 271 208 minecraft:bone_block
fill 518 271 209 518 272 209 minecraft:packed_mud
setblock 518 271 213 minecraft:bone_block
fill 518 271 214 518 272 214 minecraft:packed_mud
setblock 518 271 218 minecraft:bone_block
fill 518 271 219 518 272 219 minecraft:packed_mud
setblock 518 271 222 minecraft:packed_mud
setblock 519 271 192 minecraft:bone_block
fill 519 271 193 519 271 196 minecraft:packed_mud
setblock 519 271 197 minecraft:bone_block
fill 519 271 198 519 272 198 minecraft:packed_mud
setblock 519 271 202 minecraft:bone_block
fill 519 271 203 519 272 203 minecraft:packed_mud
setblock 519 271 207 minecraft:bone_block
fill 519 271 208 519 272 208 minecraft:packed_mud
setblock 519 271 212 minecraft:bone_block
fill 519 271 213 519 272 213 minecraft:packed_mud
setblock 519 271 217 minecraft:bone_block
fill 519 271 218 519 272 218 minecraft:packed_mud
setblock 519 271 222 minecraft:bone_block
setblock 520 271 184 minecraft:light[level=11]
setblock 520 271 191 minecraft:bone_block
fill 520 271 192 520 272 192 minecraft:packed_mud
setblock 520 271 196 minecraft:bone_block
fill 520 271 197 520 272 197 minecraft:packed_mud
setblock 520 271 201 minecraft:bone_block
setblock 520 271 208 minecraft:light[level=11]
setblock 520 271 212 minecraft:packed_mud
setblock 520 271 216 minecraft:bone_block
setblock 520 271 217 minecraft:packed_mud
fill 520 271 222 521 272 222 minecraft:packed_mud
setblock 521 271 195 minecraft:bone_block
setblock 521 271 196 minecraft:packed_mud
setblock 528 271 184 minecraft:light[level=11]
setblock 528 271 192 minecraft:light[level=11]
setblock 528 271 200 minecraft:light[level=11]
setblock 528 271 208 minecraft:light[level=11]
setblock 528 271 216 minecraft:light[level=11]
fill 530 271 182 530 272 182 minecraft:packed_mud
fill 531 271 222 533 271 222 minecraft:packed_mud
setblock 532 271 183 minecraft:packed_mud
fill 532 271 221 534 271 221 minecraft:packed_mud
setblock 533 271 183 minecraft:bone_block
setblock 534 271 182 minecraft:bone_block
fill 534 271 183 534 272 183 minecraft:packed_mud
setblock 534 271 222 minecraft:bone_block
fill 535 271 182 535 272 182 minecraft:packed_mud
fill 535 271 184 536 271 184 minecraft:packed_mud
setblock 535 271 220 minecraft:packed_mud
setblock 535 271 221 minecraft:bone_block
fill 535 271 222 535 272 222 minecraft:packed_mud
setblock 536 271 192 minecraft:light[level=11]
setblock 536 271 200 minecraft:light[level=11]
setblock 536 271 208 minecraft:light[level=11]
setblock 536 271 216 minecraft:light[level=11]
setblock 536 271 220 minecraft:bone_block
fill 536 271 221 536 272 221 minecraft:packed_mud
setblock 537 271 184 minecraft:bone_block
fill 537 271 220 537 272 220 minecraft:packed_mud
setblock 538 271 183 minecraft:bone_block
setblock 538 271 184 minecraft:packed_mud
setblock 539 271 182 minecraft:bone_block
fill 539 271 183 539 272 183 minecraft:packed_mud
setblock 539 271 221 minecraft:packed_mud
setblock 539 271 222 minecraft:bone_block
fill 540 271 182 540 272 182 minecraft:packed_mud
setblock 540 271 221 minecraft:bone_block
fill 540 271 222 540 272 222 minecraft:packed_mud
setblock 541 271 220 minecraft:bone_block
fill 541 271 221 541 272 221 minecraft:packed_mud
setblock 543 271 222 minecraft:packed_mud
setblock 544 271 182 minecraft:bone_block
setblock 544 271 184 minecraft:light[level=11]
setblock 544 271 192 minecraft:light[level=11]
setblock 544 271 200 minecraft:light[level=11]
setblock 544 271 208 minecraft:light[level=11]
setblock 544 271 216 minecraft:light[level=11]
setblock 544 271 222 minecraft:bone_block
fill 545 271 182 545 272 182 minecraft:packed_mud
setblock 545 271 221 minecraft:bone_block
fill 545 271 222 548 271 222 minecraft:packed_mud
fill 546 271 221 549 271 221 minecraft:packed_mud
fill 549 271 220 550 271 220 minecraft:packed_mud
setblock 549 271 222 minecraft:bone_block
setblock 550 271 221 minecraft:bone_block
fill 550 271 222 550 272 222 minecraft:packed_mud
fill 551 271 182 553 271 182 minecraft:packed_mud
setblock 551 271 220 minecraft:bone_block
fill 551 271 221 551 272 221 minecraft:packed_mud
setblock 552 271 184 minecraft:light[level=11]
setblock 552 271 192 minecraft:light[level=11]
setblock 552 271 200 minecraft:light[level=11]
setblock 552 271 208 minecraft:light[level=11]
setblock 552 271 216 minecraft:light[level=11]
setblock 552 271 219 minecraft:bone_block
fill 552 271 220 552 272 220 minecraft:packed_mud
fill 553 271 219 553 272 219 minecraft:packed_mud
setblock 554 271 182 minecraft:bone_block
fill 554 271 215 554 271 216 minecraft:packed_mud
setblock 554 271 217 minecraft:bone_block
setblock 554 271 222 minecraft:bone_block
fill 555 271 182 555 272 182 minecraft:packed_mud
setblock 555 271 211 minecraft:bone_block
fill 555 271 212 555 272 212 minecraft:packed_mud
setblock 555 271 215 minecraft:packed_mud
setblock 555 271 216 minecraft:bone_block
fill 555 271 217 555 272 217 minecraft:packed_mud
setblock 555 271 220 minecraft:packed_mud
setblock 555 271 221 minecraft:bone_block
fill 555 271 222 555 272 222 minecraft:packed_mud
fill 556 271 193 556 271 194 minecraft:packed_mud
setblock 556 271 195 minecraft:bone_block
fill 556 271 196 556 272 196 minecraft:packed_mud
fill 556 271 198 556 271 199 minecraft:packed_mud
setblock 556 271 210 minecraft:bone_block
fill 556 271 211 556 272 211 minecraft:packed_mud
setblock 556 271 215 minecraft:bone_block
fill 556 271 216 556 272 216 minecraft:packed_mud
setblock 556 271 220 minecraft:bone_block
fill 556 271 221 556 272 221 minecraft:packed_mud
setblock 557 271 189 minecraft:bone_block
fill 557 271 190 557 272 190 minecraft:packed_mud
setblock 557 271 194 minecraft:bone_block
fill 557 271 195 557 272 195 minecraft:packed_mud
setblock 557 271 198 minecraft:packed_mud
setblock 557 271 199 minecraft:bone_block
fill 557 271 200 557 271 203 minecraft:packed_mud
setblock 557 271 204 minecraft:bone_block
fill 557 271 205 557 272 205 minecraft:packed_mud
setblock 557 271 209 minecraft:bone_block
fill 557 271 210 557 272 210 minecraft:packed_mud
setblock 557 271 214 minecraft:bone_block
fill 557 271 215 557 272 215 minecraft:packed_mud
setblock 557 271 219 minecraft:bone_block
fill 557 271 220 557 272 220 minecraft:packed_mud
setblock 558 271 183 minecraft:bone_block
setblock 558 271 184 minecraft:packed_mud
setblock 558 271 188 minecraft:bone_block
fill 558 271 189 558 272 189 minecraft:packed_mud
setblock 558 271 193 minecraft:bone_block
fill 558 271 194 558 272 194 minecraft:packed_mud
setblock 558 271 198 minecraft:bone_block
fill 558 271 199 558 272 199 minecraft:packed_mud
setblock 558 271 203 minecraft:bone_block
fill 558 271 204 558 272 204 minecraft:packed_mud
setblock 558 271 208 minecraft:bone_block
fill 558 271 209 558 272 209 minecraft:packed_mud
setblock 558 271 213 minecraft:bone_block
fill 558 271 214 558 272 214 minecraft:packed_mud
setblock 558 271 218 minecraft:bone_block
fill 558 271 219 558 272 219 minecraft:packed_mud
setblock 518 272 182 minecraft:bone_block
setblock 518 272 187 minecraft:bone_block
fill 518 272 188 518 272 191 minecraft:packed_mud
setblock 518 272 192 minecraft:bone_block
fill 518 272 193 518 272 196 minecraft:packed_mud
setblock 518 272 197 minecraft:bone_block
setblock 518 272 198 minecraft:packed_mud
setblock 518 272 202 minecraft:bone_block
setblock 518 272 203 minecraft:packed_mud
setblock 518 272 207 minecraft:bone_block
setblock 518 272 208 minecraft:packed_mud
setblock 518 272 212 minecraft:bone_block
setblock 518 272 213 minecraft:packed_mud
setblock 518 272 217 minecraft:bone_block
setblock 518 272 218 minecraft:packed_mud
setblock 518 272 222 minecraft:bone_block
setblock 519 272 191 minecraft:bone_block
fill 519 272 192 519 272 195 minecraft:packed_mud
setblock 519 272 196 minecraft:bone_block
setblock 519 272 197 minecraft:packed_mud
setblock 519 272 200 minecraft:packed_mud
setblock 519 272 201 minecraft:bone_block
fill 519 272 202 520 272 202 minecraft:packed_mud
setblock 519 272 206 minecraft:bone_block
setblock 519 272 207 minecraft:packed_mud
setblock 519 272 211 minecraft:bone_block
setblock 519 272 212 minecraft:packed_mud
setblock 519 272 216 minecraft:bone_block
setblock 519 272 217 minecraft:packed_mud
setblock 519 272 221 minecraft:bone_block
setblock 519 272 222 minecraft:packed_mud
setblock 520 272 195 minecraft:bone_block
setblock 520 272 196 minecraft:packed_mud
setblock 520 272 200 minecraft:bone_block
setblock 520 272 201 minecraft:packed_mud
setblock 529 272 182 minecraft:packed_mud
fill 529 272 222 532 272 222 minecraft:packed_mud
setblock 531 272 183 minecraft:packed_mud
fill 531 272 221 533 272 221 minecraft:packed_mud
setblock 532 272 183 minecraft:bone_block
setblock 533 272 182 minecraft:bone_block
setblock 533 272 183 minecraft:packed_mud
fill 533 272 220 534 272 220 minecraft:packed_mud
setblock 533 272 222 minecraft:bone_block
setblock 534 272 182 minecraft:packed_mud
fill 534 272 184 535 272 184 minecraft:packed_mud
setblock 534 272 221 minecraft:bone_block
setblock 534 272 222 minecraft:packed_mud
setblock 535 272 220 minecraft:bone_block
setblock 535 272 221 minecraft:packed_mud
setblock 536 272 184 minecraft:bone_block
setblock 536 272 220 minecraft:packed_mud
setblock 537 272 183 minecraft:bone_block
setblock 537 272 184 minecraft:packed_mud
setblock 538 272 182 minecraft:bone_block
setblock 538 272 183 minecraft:packed_mud
fill 538 272 220 539 272 220 minecraft:packed_mud
setblock 538 272 222 minecraft:bone_block
setblock 539 272 182 minecraft:packed_mud
setblock 539 272 221 minecraft:bone_block
setblock 539 272 222 minecraft:packed_mud
setblock 540 272 220 minecraft:bone_block
setblock 540 272 221 minecraft:packed_mud
fill 541 272 220 542 272 220 minecraft:packed_mud
setblock 543 272 182 minecraft:bone_block
setblock 543 272 222 minecraft:bone_block
setblock 544 272 182 minecraft:packed_mud
setblock 544 272 221 minecraft:bone_block
fill 544 272 222 547 272 222 minecraft:packed_mud
fill 545 272 221 548 272 221 minecraft:packed_mud
fill 548 272 220 549 272 220 minecraft:packed_mud
setblock 548 272 222 minecraft:bone_block
fill 549 272 182 552 272 182 minecraft:packed_mud
setblock 549 272 221 minecraft:bone_block
setblock 549 272 222 minecraft:packed_mud
setblock 550 272 220 minecraft:bone_block
setblock 550 272 221 minecraft:packed_mud
setblock 551 272 219 minecraft:bone_block
setblock 551 272 220 minecraft:packed_mud
setblock 552 272 219 minecraft:packed_mud
setblock 553 272 182 minecraft:bone_block
setblock 553 272 222 minecraft:bone_block
setblock 554 272 182 minecraft:packed_mud
setblock 554 272 215 minecraft:packed_mud
setblock 554 272 216 minecraft:bone_block
fill 554 272 217 554 272 218 minecraft:packed_mud
setblock 554 272 221 minecraft:bone_block
setblock 554 272 222 minecraft:packed_mud
setblock 555 272 215 minecraft:bone_block
setblock 555 272 216 minecraft:packed_mud
setblock 555 272 220 minecraft:bone_block
setblock 555 272 221 minecraft:packed_mud
setblock 556 272 193 minecraft:packed_mud
setblock 556 272 194 minecraft:bone_block
setblock 556 272 195 minecraft:packed_mud
fill 556 272 197 556 272 198 minecraft:packed_mud
setblock 556 272 199 minecraft:bone_block
fill 556 272 200 557 272 202 minecraft:packed_mud
setblock 556 272 209 minecraft:bone_block
setblock 556 272 210 minecraft:packed_mud
setblock 556 272 214 minecraft:bone_block
setblock 556 272 215 minecraft:packed_mud
setblock 556 272 219 minecraft:bone_block
setblock 556 272 220 minecraft:packed_mud
setblock 557 272 182 minecraft:packed_mud
setblock 557 272 193 minecraft:bone_block
setblock 557 272 194 minecraft:packed_mud
setblock 557 272 197 minecraft:packed_mud
setblock 557 272 198 minecraft:bone_block
setblock 557 272 199 minecraft:packed_mud
setblock 557 272 203 minecraft:bone_block
setblock 557 272 204 minecraft:packed_mud
setblock 557 272 208 minecraft:bone_block
setblock 557 272 209 minecraft:packed_mud
setblock 557 272 213 minecraft:bone_block
setblock 557 272 214 minecraft:packed_mud
setblock 557 272 218 minecraft:bone_block
setblock 557 272 219 minecraft:packed_mud
setblock 558 272 182 minecraft:bone_block
setblock 558 272 183 minecraft:packed_mud
setblock 558 272 187 minecraft:bone_block
setblock 558 272 188 minecraft:packed_mud
setblock 558 272 192 minecraft:bone_block
setblock 558 272 193 minecraft:packed_mud
setblock 558 272 197 minecraft:bone_block
setblock 558 272 198 minecraft:packed_mud
setblock 558 272 202 minecraft:bone_block
setblock 558 272 203 minecraft:packed_mud
setblock 558 272 207 minecraft:bone_block
setblock 558 272 208 minecraft:packed_mud
setblock 558 272 212 minecraft:bone_block
setblock 558 272 213 minecraft:packed_mud
setblock 558 272 217 minecraft:bone_block
setblock 558 272 218 minecraft:packed_mud
setblock 558 272 222 minecraft:bone_block
fill 518 278 182 519 279 222 minecraft:black_concrete
fill 520 278 182 520 279 222 minecraft:bone_block
fill 521 278 182 522 279 222 minecraft:black_concrete
fill 523 278 182 523 279 222 minecraft:bone_block
fill 524 278 182 525 279 222 minecraft:black_concrete
fill 526 278 182 526 279 222 minecraft:bone_block
fill 527 278 182 528 279 222 minecraft:black_concrete
fill 529 278 182 529 279 222 minecraft:bone_block
fill 530 278 182 531 278 222 minecraft:black_concrete
fill 532 278 182 532 278 200 minecraft:bone_block
fill 532 278 202 532 278 222 minecraft:bone_block
fill 533 278 182 534 278 198 minecraft:black_concrete
fill 533 278 204 534 278 222 minecraft:black_concrete
fill 535 278 182 535 278 197 minecraft:bone_block
fill 535 278 205 535 278 222 minecraft:bone_block
fill 536 278 182 537 278 198 minecraft:black_concrete
fill 536 278 204 537 278 222 minecraft:black_concrete
fill 538 278 182 538 278 200 minecraft:bone_block
fill 538 278 202 538 278 222 minecraft:bone_block
fill 539 278 182 540 278 222 minecraft:black_concrete
fill 541 278 182 541 279 222 minecraft:bone_block
fill 542 278 182 543 279 222 minecraft:black_concrete
fill 544 278 182 544 279 222 minecraft:bone_block
fill 545 278 182 546 279 222 minecraft:black_concrete
fill 547 278 182 547 279 222 minecraft:bone_block
fill 548 278 182 549 279 222 minecraft:black_concrete
fill 550 278 182 550 279 222 minecraft:bone_block
fill 551 278 182 552 279 222 minecraft:black_concrete
fill 553 278 182 553 279 222 minecraft:bone_block
fill 554 278 182 555 279 222 minecraft:black_concrete
fill 556 278 182 556 279 222 minecraft:bone_block
fill 557 278 182 558 279 222 minecraft:black_concrete
fill 530 279 182 530 279 222 minecraft:black_concrete
fill 531 279 182 531 279 199 minecraft:black_concrete
fill 531 279 200 531 279 202 minecraft:soul_lantern
fill 531 279 203 531 279 222 minecraft:black_concrete
fill 532 279 182 532 279 197 minecraft:bone_block
fill 532 279 198 532 279 200 minecraft:soul_lantern
fill 532 279 202 532 279 204 minecraft:soul_lantern
fill 532 279 205 532 279 222 minecraft:bone_block
fill 533 279 182 533 279 197 minecraft:black_concrete
fill 533 279 198 534 279 198 minecraft:soul_lantern
fill 533 279 204 534 279 204 minecraft:soul_lantern
fill 533 279 205 533 279 222 minecraft:black_concrete
fill 534 279 182 534 279 196 minecraft:black_concrete
fill 534 279 197 536 279 197 minecraft:soul_lantern
fill 534 279 205 536 279 205 minecraft:soul_lantern
fill 534 279 206 534 279 222 minecraft:black_concrete
fill 535 279 182 535 279 196 minecraft:bone_block
fill 535 279 206 535 279 222 minecraft:bone_block
fill 536 279 182 537 279 196 minecraft:black_concrete
fill 536 279 198 538 279 198 minecraft:soul_lantern
fill 536 279 204 538 279 204 minecraft:soul_lantern
fill 536 279 206 537 279 222 minecraft:black_concrete
setblock 537 279 197 minecraft:black_concrete
setblock 537 279 205 minecraft:black_concrete
fill 538 279 182 538 279 197 minecraft:bone_block
fill 538 279 199 538 279 200 minecraft:soul_lantern
fill 538 279 202 538 279 203 minecraft:soul_lantern
fill 538 279 205 538 279 222 minecraft:bone_block
fill 539 279 182 540 279 199 minecraft:black_concrete
fill 539 279 200 539 279 202 minecraft:soul_lantern
fill 539 279 203 540 279 222 minecraft:black_concrete
fill 540 279 200 540 279 202 minecraft:black_concrete
fill 518 283 182 518 283 185 minecraft:packed_mud
setblock 518 283 186 minecraft:bone_block
fill 518 283 187 518 285 188 minecraft:packed_mud
setblock 518 283 196 minecraft:bone_block
fill 518 283 197 518 283 200 minecraft:packed_mud
setblock 518 283 201 minecraft:bone_block
fill 518 283 202 518 283 205 minecraft:packed_mud
setblock 518 283 206 minecraft:bone_block
fill 518 283 207 518 286 207 minecraft:packed_mud
fill 519 283 182 521 283 182 minecraft:packed_mud
fill 519 283 201 519 284 203 minecraft:packed_mud
setblock 521 283 183 minecraft:bone_block
setblock 522 283 182 minecraft:bone_block
fill 522 283 183 525 283 183 minecraft:packed_mud
fill 523 283 182 526 283 182 minecraft:packed_mud
fill 523 283 222 526 283 222 minecraft:packed_mud
setblock 524 283 184 minecraft:packed_mud
setblock 525 283 184 minecraft:bone_block
setblock 526 283 183 minecraft:bone_block
fill 526 283 184 529 283 184 minecraft:packed_mud
fill 526 283 221 527 283 221 minecraft:packed_mud
setblock 527 283 182 minecraft:bone_block
fill 527 283 183 530 283 183 minecraft:packed_mud
fill 527 283 185 528 283 185 minecraft:packed_mud
setblock 527 283 222 minecraft:bone_block
fill 528 283 182 531 283 182 minecraft:packed_mud
setblock 528 283 221 minecraft:bone_block
fill 528 283 222 531 283 222 minecraft:packed_mud
setblock 529 283 185 minecraft:bone_block
fill 529 283 221 532 283 221 minecraft:packed_mud
setblock 530 283 184 minecraft:bone_block
fill 530 283 185 532 284 185 minecraft:packed_mud
setblock 531 283 183 minecraft:bone_block
fill 531 283 184 534 283 184 minecraft:packed_mud
setblock 532 283 182 minecraft:bone_block
fill 532 283 183 535 283 183 minecraft:packed_mud
setblock 532 283 222 minecraft:bone_block
fill 533 283 182 536 283 182 minecraft:packed_mud
setblock 533 283 221 minecraft:bone_block
fill 533 283 222 536 283 222 minecraft:packed_mud
fill 534 283 221 537 283 221 minecraft:packed_mud
setblock 535 283 184 minecraft:bone_block
setblock 536 283 183 minecraft:bone_block
setblock 537 283 182 minecraft:bone_block
fill 537 283 183 539 284 183 minecraft:packed_mud
setblock 537 283 222 minecraft:bone_block
fill 538 283 182 541 283 182 minecraft:packed_mud
setblock 538 283 221 minecraft:bone_block
fill 538 283 222 541 283 222 minecraft:packed_mud
fill 539 283 221 542 283 221 minecraft:packed_mud
setblock 542 283 182 minecraft:bone_block
setblock 542 283 222 minecraft:bone_block
fill 543 283 182 545 283 183 minecraft:packed_mud
setblock 543 283 221 minecraft:bone_block
fill 543 283 222 546 283 222 minecraft:packed_mud
fill 544 283 221 547 283 221 minecraft:packed_mud
setblock 546 283 182 minecraft:packed_mud
setblock 546 283 183 minecraft:bone_block
fill 546 283 220 548 283 220 minecraft:packed_mud
setblock 547 283 182 minecraft:bone_block
fill 547 283 183 550 283 183 minecraft:packed_mud
setblock 547 283 222 minecraft:bone_block
fill 548 283 182 551 283 182 minecraft:packed_mud
setblock 548 283 221 minecraft:bone_block
fill 548 283 222 551 283 222 minecraft:packed_mud
setblock 549 283 220 minecraft:bone_block
fill 549 283 221 552 283 221 minecraft:packed_mud
fill 550 283 220 551 283 220 minecraft:packed_mud
setblock 551 283 183 minecraft:bone_block
setblock 552 283 182 minecraft:bone_block
fill 552 283 183 553 285 183 minecraft:packed_mud
setblock 552 283 222 minecraft:bone_block
fill 553 283 182 556 283 182 minecraft:packed_mud
setblock 553 283 221 minecraft:bone_block
fill 553 283 222 556 283 222 minecraft:packed_mud
setblock 554 283 221 minecraft:packed_mud
fill 556 283 201 556 283 202 minecraft:packed_mud
setblock 556 283 203 minecraft:bone_block
fill 556 283 204 557 283 206 minecraft:packed_mud
setblock 557 283 182 minecraft:bone_block
fill 557 283 199 557 283 201 minecraft:packed_mud
setblock 557 283 202 minecraft:bone_block
fill 557 283 203 558 285 203 minecraft:packed_mud
setblock 557 283 207 minecraft:bone_block
fill 557 283 208 558 285 208 minecraft:packed_mud
fill 558 283 197 558 283 200 minecraft:packed_mud
setblock 558 283 201 minecraft:bone_block
fill 558 283 202 558 286 202 minecraft:packed_mud
fill 558 283 204 558 283 205 minecraft:packed_mud
setblock 558 283 206 minecraft:bone_block
fill 558 283 207 558 286 207 minecraft:packed_mud
fill 558 283 209 558 283 210 minecraft:packed_mud
fill 518 284 182 518 284 184 minecraft:packed_mud
setblock 518 284 185 minecraft:bone_block
fill 518 284 186 518 287 186 minecraft:packed_mud
setblock 518 284 189 minecraft:packed_mud
setblock 518 284 190 minecraft:bone_block
fill 518 284 196 518 284 199 minecraft:packed_mud
setblock 518 284 200 minecraft:bone_block
fill 518 284 201 518 284 204 minecraft:packed_mud
setblock 518 284 205 minecraft:bone_block
fill 518 284 206 518 287 206 minecraft:packed_mud
fill 518 284 208 518 285 208 minecraft:packed_mud
fill 519 284 182 519 284 183 minecraft:packed_mud
setblock 519 284 184 minecraft:bone_block
fill 519 284 185 519 287 185 minecraft:packed_mud
setblock 519 284 204 minecraft:bone_block
setblock 520 284 182 minecraft:packed_mud
setblock 520 284 183 minecraft:bone_block
setblock 521 284 182 minecraft:bone_block
fill 521 284 183 524 284 183 minecraft:packed_mud
fill 522 284 182 525 284 182 minecraft:packed_mud
fill 522 284 222 525 284 222 minecraft:packed_mud
setblock 523 284 184 minecraft:packed_mud
setblock 524 284 184 minecraft:bone_block
setblock 525 284 183 minecraft:bone_block
fill 525 284 184 527 284 185 minecraft:packed_mud
fill 525 284 221 526 284 221 minecraft:packed_mud
setblock 526 284 182 minecraft:bone_block
fill 526 284 183 529 284 183 minecraft:packed_mud
setblock 526 284 222 minecraft:bone_block
fill 527 284 182 530 284 182 minecraft:packed_mud
setblock 527 284 221 minecraft:bone_block
fill 527 284 222 530 284 222 minecraft:packed_mud
setblock 528 284 184 minecraft:packed_mud
setblock 528 284 185 minecraft:bone_block
fill 528 284 221 531 284 221 minecraft:packed_mud
setblock 529 284 184 minecraft:bone_block
fill 529 284 185 529 287 185 minecraft:packed_mud
setblock 530 284 183 minecraft:bone_block
fill 530 284 184 533 284 184 minecraft:packed_mud
setblock 531 284 182 minecraft:bone_block
fill 531 284 183 534 284 183 minecraft:packed_mud
setblock 531 284 222 minecraft:bone_block
fill 532 284 182 535 284 182 minecraft:packed_mud
setblock 532 284 221 minecraft:bone_block
fill 532 284 222 535 284 222 minecraft:packed_mud
fill 533 284 221 536 284 221 minecraft:packed_mud
setblock 534 284 184 minecraft:bone_block
setblock 535 284 183 minecraft:bone_block
fill 535 284 184 535 286 184 minecraft:packed_mud
setblock 536 284 182 minecraft:bone_block
fill 536 284 183 536 287 183 minecraft:packed_mud
setblock 536 284 222 minecraft:bone_block
fill 537 284 182 540 284 182 minecraft:packed_mud
setblock 537 284 221 minecraft:bone_block
fill 537 284 222 540 284 222 minecraft:packed_mud
fill 538 284 221 541 284 221 minecraft:packed_mud
setblock 540 284 183 minecraft:bone_block
setblock 541 284 182 minecraft:bone_block
fill 541 284 183 544 284 183 minecraft:packed_mud
setblock 541 284 222 minecraft:bone_block
fill 542 284 182 545 284 182 minecraft:packed_mud
setblock 542 284 221 minecraft:bone_block
fill 542 284 222 545 284 222 minecraft:packed_mud
fill 543 284 221 546 284 221 minecraft:packed_mud
setblock 545 284 183 minecraft:bone_block
setblock 546 284 182 minecraft:bone_block
fill 546 284 183 549 284 183 minecraft:packed_mud
fill 546 284 220 547 284 220 minecraft:packed_mud
setblock 546 284 222 minecraft:bone_block
fill 547 284 182 550 284 182 minecraft:packed_mud
setblock 547 284 221 minecraft:bone_block
fill 547 284 222 550 284 222 minecraft:packed_mud
setblock 548 284 220 minecraft:bone_block
fill 548 284 221 551 284 221 minecraft:packed_mud
setblock 549 284 184 minecraft:bone_block
fill 549 284 220 550 285 220 minecraft:packed_mud
setblock 550 284 183 minecraft:bone_block
setblock 551 284 182 minecraft:bone_block
fill 551 284 183 551 287 183 minecraft:packed_mud
setblock 551 284 222 minecraft:bone_block
fill 552 284 182 555 284 182 minecraft:packed_mud
setblock 552 284 221 minecraft:bone_block
fill 552 284 222 555 284 222 minecraft:packed_mud
fill 553 284 221 553 285 221 minecraft:packed_mud
setblock 556 284 182 minecraft:bone_block
setblock 556 284 202 minecraft:bone_block
fill 556 284 203 556 284 206 minecraft:packed_mud
setblock 556 284 207 minecraft:bone_block
setblock 556 284 222 minecraft:bone_block
fill 557 284 182 557 286 182 minecraft:packed_mud
fill 557 284 199 557 284 200 minecraft:packed_mud
setblock 557 284 201 minecraft:bone_block
fill 557 284 202 557 287 202 minecraft:packed_mud
fill 557 284 204 557 284 205 minecraft:packed_mud
setblock 557 284 206 minecraft:bone_block
fill 557 284 207 557 287 207 minecraft:packed_mud
fill 557 284 209 558 284 209 minecraft:packed_mud
fill 558 284 183 558 284 184 minecraft:packed_mud
fill 558 284 197 558 284 199 minecraft:packed_mud
setblock 558 284 200 minecraft:bone_block
fill 558 284 201 558 287 201 minecraft:packed_mud
setblock 558 284 204 minecraft:packed_mud
setblock 558 284 205 minecraft:bone_block
fill 558 284 206 558 287 206 minecraft:packed_mud
setblock 558 284 210 minecraft:bone_block
fill 518 285 182 518 285 183 minecraft:packed_mud
setblock 518 285 184 minecraft:bone_block
fill 518 285 185 518 288 185 minecraft:packed_mud
setblock 518 285 189 minecraft:bone_block
fill 518 285 190 518 286 192 minecraft:packed_mud
fill 518 285 196 518 285 198 minecraft:packed_mud
setblock 518 285 199 minecraft:bone_block
fill 518 285 200 518 285 203 minecraft:packed_mud
setblock 518 285 204 minecraft:bone_block
fill 518 285 205 519 287 205 minecraft:packed_mud
setblock 519 285 182 minecraft:packed_mud
setblock 519 285 183 minecraft:bone_block
fill 519 285 184 519 288 184 minecraft:packed_mud
fill 519 285 186 519 285 187 minecraft:packed_mud
setblock 519 285 188 minecraft:bone_block
fill 519 285 201 519 285 202 minecraft:packed_mud
setblock 519 285 203 minecraft:bone_block
fill 519 285 204 519 286 204 minecraft:packed_mud
setblock 520 285 182 minecraft:bone_block
fill 520 285 183 523 285 183 minecraft:packed_mud
fill 521 285 182 524 285 182 minecraft:packed_mud
fill 521 285 184 522 285 184 minecraft:packed_mud
fill 522 285 222 524 285 222 minecraft:packed_mud
setblock 523 285 184 minecraft:bone_block
fill 523 285 204 523 286 204 minecraft:bone_block
setblock 524 285 183 minecraft:bone_block
fill 524 285 184 526 285 185 minecraft:packed_mud
setblock 525 285 182 minecraft:bone_block
fill 525 285 183 528 285 183 minecraft:packed_mud
setblock 525 285 221 minecraft:packed_mud
setblock 525 285 222 minecraft:bone_block
fill 526 285 182 529 285 182 minecraft:packed_mud
setblock 526 285 221 minecraft:bone_block
fill 526 285 222 529 285 222 minecraft:packed_mud
setblock 527 285 184 minecraft:packed_mud
setblock 527 285 185 minecraft:bone_block
fill 527 285 221 530 285 221 minecraft:packed_mud
setblock 528 285 184 minecraft:bone_block
fill 528 285 185 528 288 185 minecraft:packed_mud
setblock 529 285 183 minecraft:bone_block
fill 529 285 184 532 285 184 minecraft:packed_mud
setblock 530 285 182 minecraft:bone_block
fill 530 285 183 533 285 183 minecraft:packed_mud
fill 530 285 185 531 285 185 minecraft:packed_mud
setblock 530 285 222 minecraft:bone_block
fill 531 285 182 534 285 182 minecraft:packed_mud
setblock 531 285 221 minecraft:bone_block
fill 531 285 222 534 285 222 minecraft:packed_mud
setblock 532 285 185 minecraft:bone_block
fill 532 285 221 535 285 221 minecraft:packed_mud
setblock 533 285 184 minecraft:bone_block
setblock 534 285 183 minecraft:bone_block
fill 534 285 184 534 287 184 minecraft:packed_mud
setblock 535 285 182 minecraft:bone_block
fill 535 285 183 535 288 183 minecraft:packed_mud
setblock 535 285 222 minecraft:bone_block
fill 536 285 182 539 285 182 minecraft:packed_mud
setblock 536 285 221 minecraft:bone_block
fill 536 285 222 539 285 222 minecraft:packed_mud
fill 537 285 183 538 285 183 minecraft:packed_mud
fill 537 285 221 540 285 221 minecraft:packed_mud
setblock 539 285 183 minecraft:bone_block
setblock 540 285 182 minecraft:bone_block
fill 540 285 183 543 285 183 minecraft:packed_mud
setblock 540 285 222 minecraft:bone_block
fill 541 285 182 544 285 182 minecraft:packed_mud
setblock 541 285 221 minecraft:bone_block
fill 541 285 222 544 285 222 minecraft:packed_mud
fill 542 285 221 545 285 221 minecraft:packed_mud
setblock 544 285 183 minecraft:bone_block
setblock 545 285 182 minecraft:bone_block
fill 545 285 183 548 285 183 minecraft:packed_mud
fill 545 285 220 546 285 220 minecraft:packed_mud
setblock 545 285 222 minecraft:bone_block
fill 546 285 182 549 285 182 minecraft:packed_mud
fill 546 285 184 547 285 184 minecraft:packed_mud
setblock 546 285 221 minecraft:bone_block
fill 546 285 222 549 285 222 minecraft:packed_mud
setblock 547 285 220 minecraft:bone_block
fill 547 285 221 550 285 221 minecraft:packed_mud
setblock 548 285 184 minecraft:bone_block
fill 548 285 220 548 286 220 minecraft:packed_mud
setblock 549 285 183 minecraft:bone_block
fill 549 285 184 550 286 184 minecraft:packed_mud
setblock 550 285 182 minecraft:bone_block
fill 550 285 183 550 288 183 minecraft:packed_mud
setblock 550 285 222 minecraft:bone_block
fill 551 285 182 554 285 182 minecraft:packed_mud
setblock 551 285 221 minecraft:bone_block
fill 551 285 222 554 285 222 minecraft:packed_mud
fill 552 285 221 552 286 221 minecraft:packed_mud
setblock 555 285 182 minecraft:bone_block
setblock 555 285 222 minecraft:bone_block
fill 556 285 182 556 286 182 minecraft:packed_mud
fill 556 285 202 556 285 205 minecraft:packed_mud
setblock 556 285 206 minecraft:bone_block
fill 556 285 207 556 287 208 minecraft:packed_mud
setblock 557 285 200 minecraft:bone_block
fill 557 285 201 557 287 201 minecraft:packed_mud
setblock 557 285 204 minecraft:packed_mud
setblock 557 285 205 minecraft:bone_block
fill 557 285 206 557 288 206 minecraft:packed_mud
setblock 557 285 209 minecraft:packed_mud
fill 558 285 182 558 285 183 minecraft:packed_mud
setblock 558 285 184 minecraft:bone_block
fill 558 285 185 558 286 187 minecraft:packed_mud
fill 558 285 197 558 285 198 minecraft:packed_mud
setblock 558 285 199 minecraft:bone_block
fill 558 285 200 558 288 200 minecraft:packed_mud
setblock 558 285 204 minecraft:bone_block
fill 558 285 205 558 288 205 minecraft:packed_mud
setblock 558 285 209 minecraft:bone_block
fill 558 285 210 558 287 211 minecraft:packed_mud
setblock 518 286 182 minecraft:packed_mud
setblock 518 286 183 minecraft:bone_block
fill 518 286 184 518 289 184 minecraft:packed_mud
setblock 518 286 187 minecraft:packed_mud
setblock 518 286 188 minecraft:bone_block
fill 518 286 189 519 288 189 minecraft:packed_mud
setblock 518 286 193 minecraft:bone_block
fill 518 286 194 518 286 197 minecraft:packed_mud
setblock 518 286 198 minecraft:bone_block
fill 518 286 199 518 286 202 minecraft:packed_mud
setblock 518 286 203 minecraft:bone_block
fill 518 286 204 518 289 204 minecraft:packed_mud
setblock 518 286 208 minecraft:bone_block
fill 518 286 209 518 289 209 minecraft:packed_mud
setblock 519 286 182 minecraft:bone_block
fill 519 286 183 522 286 183 minecraft:packed_mud
setblock 519 286 186 minecraft:packed_mud
setblock 519 286 187 minecraft:bone_block
fill 519 286 188 519 289 188 minecraft:packed_mud
setblock 519 286 202 minecraft:bone_block
setblock 519 286 203 minecraft:packed_mud
fill 520 286 182 523 286 182 minecraft:packed_mud
fill 520 286 184 520 286 185 minecraft:packed_mud
setblock 520 286 186 minecraft:bone_block
setblock 521 286 184 minecraft:packed_mud
setblock 522 286 184 minecraft:bone_block
fill 522 286 222 523 286 222 minecraft:packed_mud
setblock 523 286 183 minecraft:bone_block
fill 523 286 184 525 286 185 minecraft:packed_mud
setblock 524 286 182 minecraft:bone_block
fill 524 286 183 527 286 183 minecraft:packed_mud
setblock 524 286 222 minecraft:bone_block
fill 525 286 182 528 286 182 minecraft:packed_mud
setblock 525 286 221 minecraft:bone_block
fill 525 286 222 528 286 222 minecraft:packed_mud
setblock 526 286 184 minecraft:packed_mud
setblock 526 286 185 minecraft:bone_block
fill 526 286 186 529 286 186 minecraft:packed_mud
fill 526 286 221 529 286 221 minecraft:packed_mud
setblock 527 286 184 minecraft:bone_block
fill 527 286 185 527 289 185 minecraft:packed_mud
setblock 528 286 183 minecraft:bone_block
fill 528 286 184 531 286 184 minecraft:packed_mud
setblock 529 286 182 minecraft:bone_block
fill 529 286 183 532 286 183 minecraft:packed_mud
setblock 529 286 222 minecraft:bone_block
fill 530 286 182 533 286 182 minecraft:packed_mud
setblock 530 286 185 minecraft:packed_mud
setblock 530 286 221 minecraft:bone_block
fill 530 286 222 533 286 222 minecraft:packed_mud
setblock 531 286 185 minecraft:bone_block
fill 531 286 221 534 286 221 minecraft:packed_mud
setblock 532 286 184 minecraft:bone_block
fill 532 286 185 532 287 185 minecraft:packed_mud
setblock 533 286 183 minecraft:bone_block
fill 533 286 184 533 288 184 minecraft:packed_mud
setblock 534 286 182 minecraft:bone_block
fill 534 286 183 534 289 183 minecraft:packed_mud
setblock 534 286 222 minecraft:bone_block
fill 535 286 182 538 286 182 minecraft:packed_mud
setblock 535 286 221 minecraft:bone_block
fill 535 286 222 538 286 222 minecraft:packed_mud
setblock 536 286 221 minecraft:packed_mud
setblock 537 286 183 minecraft:packed_mud
setblock 538 286 183 minecraft:bone_block
setblock 539 286 182 minecraft:bone_block
fill 539 286 183 542 286 183 minecraft:packed_mud
setblock 539 286 222 minecraft:bone_block
fill 540 286 182 543 286 182 minecraft:packed_mud
setblock 540 286 221 minecraft:bone_block
fill 540 286 222 543 286 222 minecraft:packed_mud
fill 541 286 221 544 286 221 minecraft:packed_mud
setblock 543 286 183 minecraft:bone_block
setblock 544 286 182 minecraft:bone_block
fill 544 286 183 547 286 183 minecraft:packed_mud
setblock 544 286 222 minecraft:bone_block
fill 545 286 182 548 286 182 minecraft:packed_mud
fill 545 286 184 546 286 184 minecraft:packed_mud
setblock 545 286 220 minecraft:packed_mud
setblock 545 286 221 minecraft:bone_block
fill 545 286 222 548 286 222 minecraft:packed_mud
setblock 546 286 220 minecraft:bone_block
fill 546 286 221 549 286 221 minecraft:packed_mud
setblock 547 286 184 minecraft:bone_block
fill 547 286 220 547 287 220 minecraft:packed_mud
setblock 548 286 183 minecraft:bone_block
fill 548 286 184 548 288 184 minecraft:packed_mud
setblock 549 286 182 minecraft:bone_block
fill 549 286 183 549 289 183 minecraft:packed_mud
setblock 549 286 220 minecraft:packed_mud
setblock 549 286 222 minecraft:bone_block
fill 550 286 182 553 286 182 minecraft:packed_mud
setblock 550 286 221 minecraft:bone_block
fill 550 286 222 553 286 222 minecraft:packed_mud
fill 551 286 221 551 287 221 minecraft:packed_mud
setblock 552 286 183 minecraft:packed_mud
setblock 553 286 183 minecraft:bone_block
setblock 554 286 182 minecraft:bone_block
setblock 554 286 222 minecraft:bone_block
fill 555 286 182 555 287 182 minecraft:packed_mud
fill 556 286 203 556 286 204 minecraft:packed_mud
setblock 556 286 205 minecraft:bone_block
fill 556 286 206 556 288 206 minecraft:packed_mud
setblock 557 286 200 minecraft:packed_mud
setblock 557 286 203 minecraft:packed_mud
setblock 557 286 204 minecraft:bone_block
fill 557 286 205 557 289 205 minecraft:packed_mud
setblock 557 286 208 minecraft:packed_mud
setblock 557 286 209 minecraft:bone_block
fill 557 286 210 557 288 210 minecraft:packed_mud
setblock 558 286 182 minecraft:packed_mud
setblock 558 286 183 minecraft:bone_block
fill 558 286 184 558 289 184 minecraft:packed_mud
setblock 558 286 188 minecraft:bone_block
fill 558 286 189 558 289 189 minecraft:packed_mud
setblock 558 286 197 minecraft:packed_mud
setblock 558 286 198 minecraft:bone_block
fill 558 286 199 558 289 199 minecraft:packed_mud
setblock 558 286 203 minecraft:bone_block
fill 558 286 204 558 289 204 minecraft:packed_mud
setblock 558 286 208 minecraft:bone_block
fill 558 286 209 558 289 209 minecraft:packed_mud
setblock 518 287 182 minecraft:bone_block
fill 518 287 183 521 287 183 minecraft:packed_mud
setblock 518 287 187 minecraft:bone_block
fill 518 287 188 518 290 188 minecraft:packed_mud
fill 518 287 190 518 287 191 minecraft:packed_mud
setblock 518 287 192 minecraft:bone_block
fill 518 287 193 518 287 195 minecraft:packed_mud
fill 518 287 198 518 287 201 minecraft:packed_mud
setblock 518 287 202 minecraft:bone_block
fill 518 287 203 518 289 203 minecraft:packed_mud
setblock 518 287 207 minecraft:bone_block
fill 518 287 208 518 290 208 minecraft:packed_mud
fill 519 287 182 522 287 182 minecraft:packed_mud
setblock 519 287 186 minecraft:bone_block
fill 519 287 187 520 289 187 minecraft:packed_mud
setblock 519 287 190 minecraft:packed_mud
setblock 520 287 184 minecraft:packed_mud
setblock 520 287 185 minecraft:bone_block
fill 520 287 186 520 290 186 minecraft:packed_mud
fill 520 287 188 520 288 188 minecraft:packed_mud
setblock 520 287 192 minecraft:light[level=11]
setblock 520 287 200 minecraft:light[level=11]
setblock 520 287 208 minecraft:light[level=11]
setblock 520 287 216 minecraft:light[level=11]
setblock 521 287 184 minecraft:bone_block
setblock 522 287 183 minecraft:bone_block
fill 522 287 184 524 287 185 minecraft:packed_mud
setblock 522 287 222 minecraft:packed_mud
setblock 523 287 182 minecraft:bone_block
fill 523 287 183 526 287 183 minecraft:packed_mud
setblock 523 287 222 minecraft:bone_block
fill 524 287 182 527 287 182 minecraft:packed_mud
fill 524 287 222 527 287 222 minecraft:packed_mud
setblock 525 287 184 minecraft:packed_mud
setblock 525 287 185 minecraft:bone_block
fill 525 287 186 528 287 186 minecraft:packed_mud
fill 525 287 221 528 287 221 minecraft:packed_mud
setblock 526 287 184 minecraft:bone_block
fill 526 287 185 526 290 185 minecraft:packed_mud
setblock 527 287 183 minecraft:bone_block
fill 527 287 184 530 287 184 minecraft:packed_mud
setblock 528 287 182 minecraft:bone_block
fill 528 287 183 531 287 183 minecraft:packed_mud
setblock 528 287 192 minecraft:light[level=11]
setblock 528 287 200 minecraft:light[level=11]
setblock 528 287 208 minecraft:light[level=11]
setblock 528 287 216 minecraft:light[level=11]
setblock 528 287 222 minecraft:bone_block
fill 529 287 182 532 287 182 minecraft:packed_mud
setblock 529 287 186 minecraft:bone_block
setblock 529 287 221 minecraft:bone_block
fill 529 287 222 532 287 222 minecraft:packed_mud
setblock 530 287 185 minecraft:bone_block
fill 530 287 221 533 287 221 minecraft:packed_mud
setblock 531 287 184 minecraft:bone_block
fill 531 287 185 531 288 185 minecraft:packed_mud
setblock 532 287 183 minecraft:bone_block
fill 532 287 184 532 289 184 minecraft:packed_mud
setblock 533 287 182 minecraft:bone_block
fill 533 287 183 533 290 183 minecraft:packed_mud
setblock 533 287 222 minecraft:bone_block
fill 534 287 182 537 287 182 minecraft:packed_mud
setblock 534 287 221 minecraft:bone_block
fill 534 287 222 537 287 222 minecraft:packed_mud
setblock 536 287 184 minecraft:light[level=11]
setblock 536 287 192 minecraft:light[level=11]
setblock 536 287 200 minecraft:light[level=11]
setblock 536 287 208 minecraft:light[level=11]
setblock 536 287 216 minecraft:light[level=11]
setblock 537 287 183 minecraft:bone_block
setblock 538 287 182 minecraft:bone_block
fill 538 287 183 541 287 183 minecraft:packed_mud
setblock 538 287 222 minecraft:bone_block
fill 539 287 182 542 287 182 minecraft:packed_mud
fill 539 287 222 542 287 222 minecraft:packed_mud
fill 541 287 221 543 287 221 minecraft:packed_mud
setblock 542 287 183 minecraft:bone_block
setblock 543 287 182 minecraft:bone_block
fill 543 287 183 546 287 183 minecraft:packed_mud
setblock 543 287 222 minecraft:bone_block
fill 544 287 182 547 287 182 minecraft:packed_mud
setblock 544 287 184 minecraft:light[level=11]
setblock 544 287 192 minecraft:light[level=11]
setblock 544 287 200 minecraft:light[level=11]
setblock 544 287 208 minecraft:light[level=11]
setblock 544 287 216 minecraft:light[level=11]
setblock 544 287 221 minecraft:bone_block
fill 544 287 222 547 287 222 minecraft:packed_mud
setblock 545 287 184 minecraft:packed_mud
fill 545 287 221 548 287 221 minecraft:packed_mud
setblock 546 287 184 minecraft:bone_block
setblock 546 287 220 minecraft:packed_mud
setblock 547 287 183 minecraft:bone_block
fill 547 287 184 547 288 184 minecraft:packed_mud
setblock 548 287 182 minecraft:bone_block
fill 548 287 183 548 289 183 minecraft:packed_mud
setblock 548 287 222 minecraft:bone_block
fill 549 287 182 552 287 182 minecraft:packed_mud
setblock 549 287 184 minecraft:packed_mud
setblock 549 287 221 minecraft:bone_block
fill 549 287 222 552 287 222 minecraft:packed_mud
setblock 550 287 221 minecraft:packed_mud
setblock 552 287 183 minecraft:bone_block
setblock 552 287 184 minecraft:light[level=11]
setblock 552 287 192 minecraft:light[level=11]
setblock 552 287 200 minecraft:light[level=11]
setblock 552 287 208 minecraft:light[level=11]
setblock 552 287 216 minecraft:light[level=11]
setblock 553 287 182 minecraft:bone_block
setblock 553 287 222 minecraft:bone_block
setblock 554 287 182 minecraft:packed_mud
setblock 556 287 204 minecraft:bone_block
setblock 556 287 205 minecraft:packed_mud
setblock 557 287 203 minecraft:bone_block
fill 557 287 204 557 289 204 minecraft:packed_mud
setblock 557 287 208 minecraft:bone_block
fill 557 287 209 557 290 209 minecraft:packed_mud
fill 558 287 183 558 288 183 minecraft:packed_mud
fill 558 287 185 558 287 186 minecraft:packed_mud
setblock 558 287 187 minecraft:bone_block
fill 558 287 188 558 290 188 minecraft:packed_mud
fill 558 287 190 558 287 191 minecraft:packed_mud
setblock 558 287 197 minecraft:bone_block
fill 558 287 198 558 288 198 minecraft:packed_mud
setblock 558 287 202 minecraft:bone_block
fill 558 287 203 558 290 203 minecraft:packed_mud
setblock 558 287 207 minecraft:bone_block
fill 558 287 208 558 290 208 minecraft:packed_mud
setblock 558 287 212 minecraft:bone_block
fill 518 288 182 520 288 183 minecraft:packed_mud
setblock 518 288 186 minecraft:bone_block
fill 518 288 187 518 291 187 minecraft:packed_mud
setblock 518 288 190 minecraft:packed_mud
setblock 518 288 191 minecraft:bone_block
fill 518 288 192 518 289 194 minecraft:packed_mud
setblock 518 288 200 minecraft:packed_mud
setblock 518 288 201 minecraft:bone_block
setblock 518 288 202 minecraft:packed_mud
setblock 518 288 205 minecraft:packed_mud
setblock 518 288 206 minecraft:bone_block
fill 518 288 207 518 290 207 minecraft:packed_mud
setblock 519 288 185 minecraft:bone_block
fill 519 288 186 519 291 186 minecraft:packed_mud
setblock 519 288 190 minecraft:bone_block
fill 519 288 191 519 291 191 minecraft:packed_mud
setblock 520 288 184 minecraft:bone_block
fill 520 288 185 520 291 185 minecraft:packed_mud
setblock 520 288 189 minecraft:bone_block
setblock 521 288 182 minecraft:packed_mud
setblock 521 288 183 minecraft:bone_block
fill 521 288 184 524 288 184 minecraft:packed_mud
setblock 522 288 182 minecraft:bone_block
fill 522 288 183 525 288 183 minecraft:packed_mud
fill 522 288 185 523 288 185 minecraft:packed_mud
setblock 522 288 222 minecraft:bone_block
fill 523 288 182 526 288 182 minecraft:packed_mud
fill 523 288 222 526 288 222 minecraft:packed_mud
setblock 524 288 185 minecraft:bone_block
setblock 525 288 184 minecraft:bone_block
fill 525 288 185 525 289 186 minecraft:packed_mud
fill 525 288 221 527 288 221 minecraft:packed_mud
setblock 526 288 183 minecraft:bone_block
fill 526 288 184 529 288 184 minecraft:packed_mud
fill 526 288 186 527 288 186 minecraft:packed_mud
setblock 527 288 182 minecraft:bone_block
fill 527 288 183 530 288 183 minecraft:packed_mud
setblock 527 288 222 minecraft:bone_block
fill 528 288 182 531 288 182 minecraft:packed_mud
setblock 528 288 186 minecraft:bone_block
setblock 528 288 221 minecraft:bone_block
fill 528 288 222 531 288 222 minecraft:packed_mud
setblock 529 288 185 minecraft:bone_block
fill 529 288 221 532 288 221 minecraft:packed_mud
setblock 530 288 184 minecraft:bone_block
fill 530 288 185 530 289 185 minecraft:packed_mud
setblock 531 288 183 minecraft:bone_block
fill 531 288 184 531 290 184 minecraft:packed_mud
setblock 532 288 182 minecraft:bone_block
fill 532 288 183 532 290 183 minecraft:packed_mud
setblock 532 288 222 minecraft:bone_block
fill 533 288 182 536 288 182 minecraft:packed_mud
fill 533 288 222 536 288 222 minecraft:packed_mud
setblock 536 288 183 minecraft:bone_block
setblock 537 288 182 minecraft:bone_block
setblock 537 288 183 minecraft:packed_mud
setblock 537 288 222 minecraft:bone_block
fill 538 288 182 541 288 182 minecraft:packed_mud
fill 538 288 222 541 288 222 minecraft:packed_mud
setblock 540 288 183 minecraft:packed_mud
setblock 541 288 183 minecraft:bone_block
setblock 542 288 182 minecraft:bone_block
fill 542 288 183 545 288 183 minecraft:packed_mud
setblock 542 288 221 minecraft:packed_mud
setblock 542 288 222 minecraft:bone_block
fill 543 288 182 546 288 182 minecraft:packed_mud
setblock 543 288 221 minecraft:bone_block
fill 543 288 222 546 288 222 minecraft:packed_mud
fill 544 288 221 547 288 221 minecraft:packed_mud
setblock 545 288 184 minecraft:bone_block
setblock 546 288 183 minecraft:bone_block
setblock 546 288 184 minecraft:packed_mud
setblock 547 288 182 minecraft:bone_block
fill 547 288 183 547 290 183 minecraft:packed_mud
setblock 547 288 222 minecraft:bone_block
fill 548 288 182 551 288 182 minecraft:packed_mud
setblock 548 288 221 minecraft:bone_block
fill 548 288 222 551 288 222 minecraft:packed_mud
setblock 549 288 221 minecraft:packed_mud
setblock 551 288 183 minecraft:bone_block
setblock 552 288 182 minecraft:bone_block
setblock 552 288 222 minecraft:bone_block
setblock 553 288 182 minecraft:packed_mud
setblock 557 288 202 minecraft:bone_block
setblock 557 288 203 minecraft:packed_mud
setblock 557 288 207 minecraft:bone_block
fill 557 288 208 557 290 208 minecraft:packed_mud
setblock 558 288 185 minecraft:packed_mud
setblock 558 288 186 minecraft:bone_block
fill 558 288 187 558 291 187 minecraft:packed_mud
setblock 558 288 190 minecraft:packed_mud
setblock 558 288 191 minecraft:bone_block
fill 558 288 192 558 291 192 minecraft:packed_mud
setblock 558 288 201 minecraft:bone_block
fill 558 288 202 558 290 202 minecraft:packed_mud
setblock 558 288 206 minecraft:bone_block
fill 558 288 207 558 291 207 minecraft:packed_mud
setblock 558 288 210 minecraft:packed_mud
setblock 558 288 211 minecraft:bone_block
fill 558 288 212 558 291 212 minecraft:packed_mud
fill 518 289 182 519 289 183 minecraft:packed_mud
setblock 518 289 185 minecraft:bone_block
fill 518 289 186 518 292 186 minecraft:packed_mud
setblock 518 289 189 minecraft:packed_mud
setblock 518 289 190 minecraft:bone_block
fill 518 289 191 518 292 191 minecraft:packed_mud
setblock 518 289 205 minecraft:bone_block
fill 518 289 206 518 290 206 minecraft:packed_mud
setblock 519 289 184 minecraft:bone_block
fill 519 289 185 519 292 185 minecraft:packed_mud
setblock 519 289 189 minecraft:bone_block
fill 519 289 190 519 292 190 minecraft:packed_mud
fill 519 289 192 519 290 192 minecraft:packed_mud
setblock 520 289 182 minecraft:packed_mud
setblock 520 289 183 minecraft:bone_block
fill 520 289 184 523 289 184 minecraft:packed_mud
setblock 520 289 188 minecraft:bone_block
fill 520 289 189 520 292 189 minecraft:packed_mud
setblock 521 289 182 minecraft:bone_block
fill 521 289 183 524 289 183 minecraft:packed_mud
fill 522 289 182 525 289 182 minecraft:packed_mud
setblock 522 289 185 minecraft:packed_mud
fill 522 289 222 525 289 222 minecraft:packed_mud
setblock 523 289 185 minecraft:bone_block
setblock 524 289 184 minecraft:bone_block
fill 524 289 185 524 291 185 minecraft:packed_mud
setblock 525 289 183 minecraft:bone_block
fill 525 289 184 528 289 184 minecraft:packed_mud
fill 525 289 221 526 289 221 minecraft:packed_mud
setblock 526 289 182 minecraft:bone_block
fill 526 289 183 529 289 183 minecraft:packed_mud
setblock 526 289 186 minecraft:packed_mud
setblock 526 289 222 minecraft:bone_block
fill 527 289 182 530 289 182 minecraft:packed_mud
setblock 527 289 221 minecraft:bone_block
fill 527 289 222 530 289 222 minecraft:packed_mud
setblock 528 289 185 minecraft:bone_block
fill 528 289 221 530 289 221 minecraft:packed_mud
setblock 529 289 184 minecraft:bone_block
setblock 529 289 185 minecraft:packed_mud
setblock 530 289 183 minecraft:bone_block
fill 530 289 184 530 290 184 minecraft:packed_mud
setblock 531 289 182 minecraft:bone_block
fill 531 289 183 531 291 183 minecraft:packed_mud
setblock 531 289 222 minecraft:bone_block
fill 532 289 182 535 289 182 minecraft:packed_mud
fill 532 289 222 535 289 222 minecraft:packed_mud
setblock 536 289 182 minecraft:bone_block
setblock 536 289 222 minecraft:bone_block
fill 537 289 182 540 289 182 minecraft:packed_mud
fill 537 289 222 540 289 222 minecraft:packed_mud
setblock 541 289 182 minecraft:bone_block
setblock 541 289 222 minecraft:bone_block
fill 542 289 182 544 289 183 minecraft:packed_mud
setblock 542 289 221 minecraft:bone_block
fill 542 289 222 545 289 222 minecraft:packed_mud
fill 543 289 221 546 289 221 minecraft:packed_mud
setblock 545 289 182 minecraft:packed_mud
setblock 545 289 183 minecraft:bone_block
setblock 546 289 182 minecraft:bone_block
fill 546 289 183 546 290 183 minecraft:packed_mud
setblock 546 289 222 minecraft:bone_block
fill 547 289 182 550 289 182 minecraft:packed_mud
setblock 547 289 221 minecraft:bone_block
fill 547 289 222 550 289 222 minecraft:packed_mud
setblock 548 289 221 minecraft:packed_mud
setblock 551 289 182 minecraft:bone_block
setblock 552 289 182 minecraft:packed_mud
setblock 557 289 206 minecraft:bone_block
fill 557 289 207 557 290 207 minecraft:packed_mud
setblock 558 289 185 minecraft:bone_block
fill 558 289 186 558 292 186 minecraft:packed_mud
setblock 558 289 190 minecraft:bone_block
fill 558 289 191 558 292 191 minecraft:packed_mud
fill 558 289 193 558 290 193 minecraft:packed_mud
setblock 558 289 200 minecraft:bone_block
fill 558 289 201 558 290 201 minecraft:packed_mud
setblock 558 289 205 minecraft:bone_block
fill 558 289 206 558 292 206 minecraft:packed_mud
setblock 558 289 210 minecraft:bone_block
fill 558 289 211 558 292 211 minecraft:packed_mud
fill 518 290 182 518 290 183 minecraft:packed_mud
setblock 518 290 184 minecraft:bone_block
fill 518 290 185 518 293 185 minecraft:packed_mud
setblock 518 290 189 minecraft:bone_block
fill 518 290 190 518 293 190 minecraft:packed_mud
fill 518 290 192 518 290 193 minecraft:packed_mud
setblock 518 290 194 minecraft:bone_block
setblock 518 290 205 minecraft:packed_mud
setblock 518 290 209 minecraft:bone_block
setblock 519 290 182 minecraft:packed_mud
setblock 519 290 183 minecraft:bone_block
fill 519 290 184 522 290 184 minecraft:packed_mud
setblock 519 290 187 minecraft:packed_mud
setblock 519 290 188 minecraft:bone_block
fill 519 290 189 519 293 189 minecraft:packed_mud
setblock 520 290 182 minecraft:bone_block
fill 520 290 183 523 290 183 minecraft:packed_mud
setblock 520 290 187 minecraft:bone_block
fill 520 290 188 520 293 188 minecraft:packed_mud
fill 520 290 190 520 291 190 minecraft:packed_mud
fill 521 290 182 524 290 182 minecraft:packed_mud
setblock 522 290 185 minecraft:bone_block
fill 522 290 222 524 290 222 minecraft:packed_mud
setblock 523 290 184 minecraft:bone_block
fill 523 290 185 523 291 185 minecraft:packed_mud
setblock 524 290 183 minecraft:bone_block
fill 524 290 184 527 290 184 minecraft:packed_mud
setblock 525 290 182 minecraft:bone_block
fill 525 290 183 528 290 183 minecraft:packed_mud
fill 525 290 185 525 291 185 minecraft:packed_mud
setblock 525 290 222 minecraft:bone_block
fill 526 290 182 529 290 182 minecraft:packed_mud
setblock 526 290 221 minecraft:bone_block
fill 526 290 222 529 290 222 minecraft:packed_mud
setblock 527 290 185 minecraft:bone_block
fill 527 290 221 528 290 221 minecraft:packed_mud
setblock 528 290 184 minecraft:bone_block
setblock 528 290 185 minecraft:packed_mud
setblock 529 290 183 minecraft:bone_block
fill 529 290 184 529 291 184 minecraft:packed_mud
setblock 530 290 182 minecraft:bone_block
fill 530 290 183 530 291 183 minecraft:packed_mud
setblock 530 290 222 minecraft:bone_block
fill 531 290 182 534 290 182 minecraft:packed_mud
fill 531 290 222 534 290 222 minecraft:packed_mud
setblock 535 290 182 minecraft:bone_block
setblock 536 290 182 minecraft:packed_mud
fill 538 290 182 539 290 182 minecraft:packed_mud
setblock 539 290 222 minecraft:packed_mud
setblock 540 290 182 minecraft:bone_block
setblock 540 290 222 minecraft:bone_block
fill 541 290 182 544 290 182 minecraft:packed_mud
fill 541 290 222 544 290 222 minecraft:packed_mud
setblock 543 290 183 minecraft:packed_mud
setblock 544 290 183 minecraft:bone_block
fill 544 290 221 545 290 221 minecraft:packed_mud
setblock 545 290 182 minecraft:bone_block
setblock 545 290 183 minecraft:packed_mud
setblock 545 290 222 minecraft:bone_block
fill 546 290 182 549 290 182 minecraft:packed_mud
setblock 546 290 221 minecraft:bone_block
fill 546 290 222 549 290 222 minecraft:packed_mud
setblock 550 290 182 minecraft:bone_block
setblock 557 290 206 minecraft:packed_mud
setblock 558 290 184 minecraft:bone_block
fill 558 290 185 558 293 185 minecraft:packed_mud
setblock 558 290 189 minecraft:bone_block
fill 558 290 190 558 293 190 minecraft:packed_mud
setblock 558 290 194 minecraft:bone_block
setblock 558 290 204 minecraft:bone_block
fill 558 290 205 558 293 205 minecraft:packed_mud
setblock 558 290 209 minecraft:bone_block
fill 558 290 210 558 293 210 minecraft:packed_mud
setblock 518 291 182 minecraft:packed_mud
setblock 518 291 183 minecraft:bone_block
fill 518 291 184 519 293 184 minecraft:packed_mud
setblock 518 291 188 minecraft:bone_block
fill 518 291 189 518 294 189 minecraft:packed_mud
setblock 518 291 192 minecraft:packed_mud
setblock 518 291 193 minecraft:bone_block
fill 518 291 194 518 294 194 minecraft:packed_mud
setblock 519 291 182 minecraft:bone_block
fill 519 291 183 522 291 183 minecraft:packed_mud
setblock 519 291 187 minecraft:bone_block
fill 519 291 188 519 294 188 minecraft:packed_mud
setblock 519 291 192 minecraft:bone_block
fill 520 291 182 523 291 182 minecraft:packed_mud
setblock 520 291 186 minecraft:bone_block
fill 520 291 187 520 294 187 minecraft:packed_mud
setblock 521 291 184 minecraft:packed_mud
setblock 522 291 184 minecraft:bone_block
fill 522 291 222 523 291 222 minecraft:packed_mud
setblock 523 291 183 minecraft:bone_block
fill 523 291 184 526 291 184 minecraft:packed_mud
setblock 524 291 182 minecraft:bone_block
fill 524 291 183 527 291 183 minecraft:packed_mud
setblock 524 291 222 minecraft:bone_block
fill 525 291 182 528 291 182 minecraft:packed_mud
fill 525 291 222 528 291 222 minecraft:packed_mud
setblock 526 291 185 minecraft:bone_block
setblock 527 291 184 minecraft:bone_block
setblock 527 291 185 minecraft:packed_mud
setblock 528 291 183 minecraft:bone_block
setblock 528 291 184 minecraft:packed_mud
setblock 529 291 182 minecraft:bone_block
fill 529 291 183 529 292 183 minecraft:packed_mud
setblock 529 291 222 minecraft:bone_block
fill 530 291 182 533 291 182 minecraft:packed_mud
fill 530 291 222 531 291 222 minecraft:packed_mud
fill 536 291 190 536 292 191 minecraft:mud_bricks
fill 537 291 190 537 292 190 minecraft:mud_bricks
fill 540 291 222 543 291 222 minecraft:packed_mud
fill 541 291 182 543 291 182 minecraft:packed_mud
setblock 544 291 182 minecraft:bone_block
setblock 544 291 222 minecraft:bone_block
fill 545 291 182 548 291 182 minecraft:packed_mud
fill 545 291 222 547 291 222 minecraft:packed_mud
setblock 558 291 188 minecraft:bone_block
fill 558 291 189 558 294 189 minecraft:packed_mud
setblock 558 291 193 minecraft:bone_block
fill 558 291 194 558 294 194 minecraft:packed_mud
setblock 558 291 203 minecraft:bone_block
fill 558 291 204 558 292 204 minecraft:packed_mud
setblock 558 291 208 minecraft:bone_block
fill 558 291 209 558 294 209 minecraft:packed_mud
setblock 518 292 182 minecraft:bone_block
fill 518 292 183 518 295 183 minecraft:packed_mud
setblock 518 292 187 minecraft:bone_block
fill 518 292 188 518 295 188 minecraft:packed_mud
setblock 518 292 192 minecraft:bone_block
fill 518 292 193 519 294 193 minecraft:packed_mud
fill 518 292 195 518 293 195 minecraft:packed_mud
fill 519 292 182 522 292 182 minecraft:packed_mud
setblock 519 292 186 minecraft:bone_block
fill 519 292 187 519 295 187 minecraft:packed_mud
setblock 519 292 191 minecraft:bone_block
fill 519 292 192 519 295 192 minecraft:packed_mud
fill 520 292 183 521 292 183 minecraft:packed_mud
setblock 520 292 185 minecraft:bone_block
fill 520 292 186 520 295 186 minecraft:packed_mud
setblock 520 292 190 minecraft:bone_block
fill 520 292 191 520 295 191 minecraft:packed_mud
setblock 521 292 184 minecraft:bone_block
setblock 522 292 183 minecraft:bone_block
fill 522 292 184 525 292 184 minecraft:packed_mud
setblock 522 292 222 minecraft:packed_mud
setblock 523 292 182 minecraft:bone_block
fill 523 292 183 526 292 183 minecraft:packed_mud
setblock 523 292 222 minecraft:bone_block
fill 524 292 182 527 292 182 minecraft:packed_mud
fill 524 292 222 527 292 222 minecraft:packed_mud
setblock 526 292 184 minecraft:bone_block
setblock 527 292 183 minecraft:bone_block
setblock 527 292 184 minecraft:packed_mud
setblock 528 292 182 minecraft:bone_block
fill 528 292 183 528 293 183 minecraft:packed_mud
setblock 528 292 222 minecraft:bone_block
fill 529 292 182 531 292 182 minecraft:packed_mud
fill 529 292 222 530 292 222 minecraft:packed_mud
fill 541 292 222 542 292 222 minecraft:packed_mud
setblock 543 292 182 minecraft:bone_block
setblock 543 292 222 minecraft:bone_block
fill 544 292 182 545 292 182 minecraft:packed_mud
fill 544 292 222 546 292 222 minecraft:packed_mud
setblock 558 292 187 minecraft:bone_block
fill 558 292 188 558 295 188 minecraft:packed_mud
setblock 558 292 192 minecraft:bone_block
fill 558 292 193 558 295 193 minecraft:packed_mud
fill 558 292 195 558 293 195 minecraft:packed_mud
setblock 558 292 207 minecraft:bone_block
fill 558 292 208 558 295 208 minecraft:packed_mud
setblock 558 292 212 minecraft:bone_block
setblock 518 293 186 minecraft:bone_block
fill 518 293 187 518 296 187 minecraft:packed_mud
setblock 518 293 191 minecraft:bone_block
fill 518 293 192 518 296 192 minecraft:packed_mud
fill 519 293 182 521 293 182 minecraft:packed_mud
setblock 519 293 185 minecraft:bone_block
fill 519 293 186 519 296 186 minecraft:packed_mud
setblock 519 293 190 minecraft:bone_block
fill 519 293 191 519 296 191 minecraft:packed_mud
setblock 520 293 183 minecraft:packed_mud
setblock 520 293 189 minecraft:bone_block
fill 520 293 190 520 296 190 minecraft:packed_mud
setblock 521 293 183 minecraft:bone_block
setblock 522 293 182 minecraft:bone_block
fill 522 293 183 524 293 184 minecraft:packed_mud
setblock 522 293 222 minecraft:bone_block
fill 523 293 182 526 293 182 minecraft:packed_mud
fill 523 293 222 526 293 222 minecraft:packed_mud
setblock 525 293 183 minecraft:packed_mud
setblock 525 293 184 minecraft:bone_block
setblock 526 293 183 minecraft:bone_block
setblock 526 293 184 minecraft:packed_mud
setblock 527 293 182 minecraft:bone_block
fill 527 293 183 527 294 183 minecraft:packed_mud
setblock 527 293 222 minecraft:bone_block
fill 528 293 182 530 293 182 minecraft:packed_mud
fill 528 293 222 529 293 222 minecraft:packed_mud
setblock 541 293 222 minecraft:packed_mud
setblock 542 293 222 minecraft:bone_block
fill 543 293 222 545 293 222 minecraft:packed_mud
setblock 558 293 186 minecraft:bone_block
fill 558 293 187 558 296 187 minecraft:packed_mud
setblock 558 293 191 minecraft:bone_block
fill 558 293 192 558 296 192 minecraft:packed_mud
setblock 558 293 196 minecraft:bone_block
setblock 558 293 206 minecraft:bone_block
fill 558 293 207 558 296 207 minecraft:packed_mud
setblock 558 293 211 minecraft:bone_block
fill 558 293 212 558 296 212 minecraft:packed_mud
fill 518 294 182 520 294 182 minecraft:packed_mud
setblock 518 294 184 minecraft:packed_mud
setblock 518 294 185 minecraft:bone_block
fill 518 294 186 518 297 186 minecraft:packed_mud
setblock 518 294 190 minecraft:bone_block
fill 518 294 191 518 297 191 minecraft:packed_mud
setblock 518 294 195 minecraft:bone_block
fill 518 294 196 518 297 196 minecraft:packed_mud
setblock 519 294 184 minecraft:bone_block
fill 519 294 185 519 297 185 minecraft:packed_mud
setblock 519 294 189 minecraft:bone_block
fill 519 294 190 519 297 190 minecraft:packed_mud
setblock 519 294 194 minecraft:bone_block
setblock 520 294 183 minecraft:bone_block
setblock 520 294 188 minecraft:bone_block
fill 520 294 189 520 297 189 minecraft:packed_mud
setblock 520 294 192 minecraft:packed_mud
setblock 521 294 182 minecraft:bone_block
fill 521 294 183 524 294 183 minecraft:packed_mud
fill 522 294 182 525 294 182 minecraft:packed_mud
fill 522 294 184 523 294 184 minecraft:packed_mud
fill 522 294 222 525 294 222 minecraft:packed_mud
setblock 524 294 184 minecraft:bone_block
setblock 525 294 183 minecraft:bone_block
setblock 526 294 182 minecraft:bone_block
fill 526 294 183 526 295 183 minecraft:packed_mud
setblock 526 294 222 minecraft:bone_block
fill 527 294 182 529 294 182 minecraft:packed_mud
fill 527 294 222 528 296 222 minecraft:packed_mud
setblock 541 294 222 minecraft:bone_block
fill 542 294 222 544 295 222 minecraft:packed_mud
fill 557 294 189 557 294 190 minecraft:packed_mud
setblock 557 294 191 minecraft:bone_block
fill 557 294 192 557 297 192 minecraft:packed_mud
setblock 558 294 185 minecraft:bone_block
fill 558 294 186 558 297 186 minecraft:packed_mud
setblock 558 294 190 minecraft:bone_block
fill 558 294 191 558 297 191 minecraft:packed_mud
setblock 558 294 195 minecraft:bone_block
fill 558 294 196 558 296 197 minecraft:packed_mud
setblock 558 294 206 minecraft:packed_mud
setblock 558 294 210 minecraft:bone_block
fill 558 294 211 558 297 211 minecraft:packed_mud
fill 558 294 213 558 295 213 minecraft:packed_mud
fill 518 295 182 519 295 182 minecraft:packed_mud
setblock 518 295 184 minecraft:bone_block
fill 518 295 185 518 298 185 minecraft:packed_mud
setblock 518 295 189 minecraft:bone_block
fill 518 295 190 518 298 190 minecraft:packed_mud
setblock 518 295 193 minecraft:packed_mud
setblock 518 295 194 minecraft:bone_block
fill 518 295 195 519 297 195 minecraft:packed_mud
fill 518 295 197 518 296 197 minecraft:packed_mud
fill 518 295 211 518 295 213 minecraft:packed_mud
setblock 518 295 214 minecraft:bone_block
fill 519 295 184 519 298 184 minecraft:packed_mud
setblock 519 295 188 minecraft:bone_block
fill 519 295 189 519 298 189 minecraft:packed_mud
setblock 519 295 193 minecraft:bone_block
fill 519 295 194 519 298 194 minecraft:packed_mud
setblock 520 295 182 minecraft:bone_block
fill 520 295 183 523 295 183 minecraft:packed_mud
setblock 520 295 184 minecraft:light[level=11]
setblock 520 295 187 minecraft:bone_block
fill 520 295 188 520 298 188 minecraft:packed_mud
setblock 520 295 192 minecraft:bone_block
fill 520 295 193 520 298 193 minecraft:packed_mud
setblock 520 295 200 minecraft:light[level=11]
setblock 520 295 208 minecraft:light[level=11]
setblock 520 295 216 minecraft:light[level=11]
fill 521 295 182 524 295 182 minecraft:packed_mud
fill 521 295 222 524 295 222 minecraft:packed_mud
setblock 524 295 183 minecraft:bone_block
setblock 525 295 182 minecraft:bone_block
fill 525 295 183 525 298 183 minecraft:packed_mud
setblock 525 295 222 minecraft:bone_block
fill 526 295 182 528 295 182 minecraft:packed_mud
fill 526 295 222 526 298 222 minecraft:packed_mud
setblock 528 295 184 minecraft:light[level=11]
setblock 528 295 192 minecraft:light[level=11]
setblock 528 295 200 minecraft:light[level=11]
setblock 528 295 208 minecraft:light[level=11]
setblock 528 295 216 minecraft:light[level=11]
setblock 536 295 184 minecraft:light[level=11]
setblock 536 295 192 minecraft:light[level=11]
setblock 536 295 200 minecraft:light[level=11]
setblock 536 295 208 minecraft:light[level=11]
setblock 536 295 216 minecraft:light[level=11]
setblock 540 295 222 minecraft:bone_block
fill 541 295 222 541 298 222 minecraft:packed_mud
setblock 544 295 184 minecraft:light[level=11]
setblock 544 295 192 minecraft:light[level=11]
setblock 544 295 200 minecraft:light[level=11]
setblock 544 295 208 minecraft:light[level=11]
setblock 544 295 216 minecraft:light[level=11]
setblock 552 295 184 minecraft:light[level=11]
setblock 552 295 192 minecraft:light[level=11]
setblock 552 295 200 minecraft:light[level=11]
setblock 552 295 208 minecraft:light[level=11]
setblock 552 295 216 minecraft:light[level=11]
fill 557 295 188 557 295 189 minecraft:packed_mud
setblock 557 295 190 minecraft:bone_block
fill 557 295 191 557 298 191 minecraft:packed_mud
fill 557 295 193 557 295 194 minecraft:packed_mud
setblock 557 295 195 minecraft:bone_block
fill 558 295 185 558 298 185 minecraft:packed_mud
setblock 558 295 189 minecraft:bone_block
fill 558 295 190 558 298 190 minecraft:packed_mud
setblock 558 295 194 minecraft:bone_block
fill 558 295 195 558 298 195 minecraft:packed_mud
setblock 558 295 198 minecraft:packed_mud
setblock 558 295 199 minecraft:bone_block
setblock 558 295 209 minecraft:bone_block
fill 558 295 210 558 298 210 minecraft:packed_mud
setblock 558 295 214 minecraft:bone_block
setblock 518 296 182 minecraft:packed_mud
setblock 518 296 183 minecraft:bone_block
fill 518 296 184 518 299 184 minecraft:packed_mud
setblock 518 296 188 minecraft:bone_block
fill 518 296 189 518 299 189 minecraft:packed_mud
setblock 518 296 193 minecraft:bone_block
fill 518 296 194 518 299 194 minecraft:packed_mud
setblock 518 296 198 minecraft:bone_block
fill 518 296 210 518 296 212 minecraft:packed_mud
setblock 518 296 213 minecraft:bone_block
fill 518 296 214 518 296 217 minecraft:packed_mud
setblock 519 296 182 minecraft:bone_block
fill 519 296 183 522 296 183 minecraft:packed_mud
setblock 519 296 187 minecraft:bone_block
fill 519 296 188 519 299 188 minecraft:packed_mud
setblock 519 296 192 minecraft:bone_block
fill 519 296 193 519 299 193 minecraft:packed_mud
setblock 519 296 196 minecraft:packed_mud
fill 520 296 182 523 296 182 minecraft:packed_mud
setblock 520 296 186 minecraft:bone_block
fill 520 296 187 520 299 187 minecraft:packed_mud
setblock 520 296 191 minecraft:bone_block
fill 520 296 192 520 299 192 minecraft:packed_mud
fill 520 296 194 520 297 194 minecraft:packed_mud
fill 520 296 222 523 296 222 minecraft:packed_mud
setblock 521 296 190 minecraft:bone_block
setblock 523 296 183 minecraft:bone_block
fill 523 296 221 524 296 221 minecraft:packed_mud
setblock 524 296 182 minecraft:bone_block
fill 524 296 183 524 299 183 minecraft:packed_mud
setblock 524 296 222 minecraft:bone_block
fill 525 296 182 527 297 182 minecraft:packed_mud
fill 525 296 222 525 299 222 minecraft:packed_mud
setblock 538 296 222 minecraft:packed_mud
setblock 539 296 222 minecraft:bone_block
fill 540 296 222 540 299 222 minecraft:packed_mud
fill 542 296 222 543 296 222 minecraft:packed_mud
setblock 544 296 222 minecraft:bone_block
setblock 557 296 188 minecraft:packed_mud
setblock 557 296 189 minecraft:bone_block
fill 557 296 190 557 299 190 minecraft:packed_mud
setblock 557 296 193 minecraft:packed_mud
setblock 557 296 194 minecraft:bone_block
fill 557 296 195 557 298 196 minecraft:packed_mud
setblock 558 296 188 minecraft:bone_block
fill 558 296 189 558 299 189 minecraft:packed_mud
setblock 558 296 193 minecraft:bone_block
fill 558 296 194 558 299 194 minecraft:packed_mud
setblock 558 296 198 minecraft:bone_block
fill 558 296 199 558 297 201 minecraft:packed_mud
setblock 558 296 208 minecraft:bone_block
fill 558 296 209 558 299 209 minecraft:packed_mud
setblock 558 296 213 minecraft:bone_block
fill 558 296 214 558 298 215 minecraft:packed_mud
setblock 518 297 182 minecraft:bone_block
fill 518 297 183 521 297 183 minecraft:packed_mud
setblock 518 297 187 minecraft:bone_block
fill 518 297 188 518 300 188 minecraft:packed_mud
setblock 518 297 192 minecraft:bone_block
fill 518 297 193 518 300 193 minecraft:packed_mud
setblock 518 297 197 minecraft:bone_block
fill 518 297 198 518 299 199 minecraft:packed_mud
fill 518 297 209 518 297 211 minecraft:packed_mud
setblock 518 297 212 minecraft:bone_block
fill 518 297 213 518 297 216 minecraft:packed_mud
setblock 518 297 217 minecraft:bone_block
fill 518 297 218 518 297 221 minecraft:packed_mud
setblock 518 297 222 minecraft:bone_block
fill 519 297 182 522 297 182 minecraft:packed_mud
setblock 519 297 186 minecraft:bone_block
fill 519 297 187 519 300 187 minecraft:packed_mud
setblock 519 297 191 minecraft:bone_block
fill 519 297 192 519 300 192 minecraft:packed_mud
setblock 519 297 196 minecraft:bone_block
fill 519 297 197 519 300 197 minecraft:packed_mud
fill 519 297 212 519 297 215 minecraft:packed_mud
setblock 519 297 216 minecraft:bone_block
fill 519 297 217 519 299 218 minecraft:packed_mud
fill 519 297 222 522 297 222 minecraft:packed_mud
setblock 520 297 185 minecraft:bone_block
fill 520 297 186 520 300 186 minecraft:packed_mud
setblock 520 297 190 minecraft:bone_block
fill 520 297 191 521 299 191 minecraft:packed_mud
setblock 520 297 195 minecraft:bone_block
setblock 521 297 189 minecraft:bone_block
fill 521 297 190 521 299 190 minecraft:packed_mud
fill 521 297 192 521 298 192 minecraft:packed_mud
fill 521 297 221 523 297 221 minecraft:packed_mud
setblock 522 297 183 minecraft:bone_block
setblock 523 297 182 minecraft:bone_block
fill 523 297 183 523 300 183 minecraft:packed_mud
setblock 523 297 222 minecraft:bone_block
fill 524 297 182 524 300 182 minecraft:packed_mud
setblock 524 297 221 minecraft:bone_block
fill 524 297 222 524 300 222 minecraft:packed_mud
fill 525 297 221 526 299 221 minecraft:packed_mud
setblock 527 297 222 minecraft:packed_mud
setblock 528 297 222 minecraft:bone_block
fill 529 297 222 529 300 222 minecraft:packed_mud
fill 536 297 222 537 297 222 minecraft:packed_mud
setblock 538 297 222 minecraft:bone_block
setblock 539 297 221 minecraft:bone_block
fill 539 297 222 539 300 222 minecraft:packed_mud
fill 540 297 221 542 298 221 minecraft:packed_mud
setblock 542 297 222 minecraft:packed_mud
setblock 543 297 222 minecraft:bone_block
fill 544 297 222 544 300 222 minecraft:packed_mud
fill 556 297 191 556 297 193 minecraft:packed_mud
setblock 556 297 194 minecraft:bone_block
setblock 557 297 187 minecraft:packed_mud
setblock 557 297 188 minecraft:bone_block
fill 557 297 189 557 300 189 minecraft:packed_mud
setblock 557 297 193 minecraft:bone_block
fill 557 297 194 557 300 194 minecraft:packed_mud
setblock 557 297 197 minecraft:packed_mud
setblock 557 297 198 minecraft:bone_block
fill 558 297 184 558 299 184 minecraft:packed_mud
setblock 558 297 187 minecraft:bone_block
fill 558 297 188 558 300 188 minecraft:packed_mud
setblock 558 297 192 minecraft:bone_block
fill 558 297 193 558 300 193 minecraft:packed_mud
setblock 558 297 196 minecraft:packed_mud
setblock 558 297 197 minecraft:bone_block
fill 558 297 198 558 300 198 minecraft:packed_mud
setblock 558 297 202 minecraft:bone_block
fill 558 297 203 558 300 203 minecraft:packed_mud
fill 558 297 205 558 297 206 minecraft:packed_mud
setblock 558 297 207 minecraft:bone_block
fill 558 297 208 558 300 208 minecraft:packed_mud
setblock 558 297 212 minecraft:bone_block
fill 558 297 213 558 300 213 minecraft:packed_mud
setblock 558 297 216 minecraft:packed_mud
setblock 558 297 217 minecraft:bone_block
fill 518 298 182 520 298 183 minecraft:packed_mud
setblock 518 298 186 minecraft:bone_block
fill 518 298 187 518 300 187 minecraft:packed_mud
setblock 518 298 191 minecraft:bone_block
fill 518 298 192 518 300 192 minecraft:packed_mud
setblock 518 298 195 minecraft:packed_mud
setblock 518 298 196 minecraft:bone_block
fill 518 298 197 518 300 197 minecraft:packed_mud
setblock 518 298 200 minecraft:packed_mud
fill 518 298 209 518 298 210 minecraft:packed_mud
setblock 518 298 211 minecraft:bone_block
fill 518 298 212 518 298 215 minecraft:packed_mud
setblock 518 298 216 minecraft:bone_block
fill 518 298 217 518 298 220 minecraft:packed_mud
setblock 518 298 221 minecraft:bone_block
fill 518 298 222 521 298 222 minecraft:packed_mud
setblock 519 298 185 minecraft:bone_block
fill 519 298 186 519 300 186 minecraft:packed_mud
setblock 519 298 190 minecraft:bone_block
fill 519 298 191 519 300 191 minecraft:packed_mud
setblock 519 298 195 minecraft:bone_block
fill 519 298 196 520 300 196 minecraft:packed_mud
fill 519 298 198 519 299 198 minecraft:packed_mud
fill 519 298 211 519 298 214 minecraft:packed_mud
setblock 519 298 215 minecraft:bone_block
fill 519 298 216 520 300 216 minecraft:packed_mud
setblock 519 298 219 minecraft:packed_mud
setblock 519 298 220 minecraft:bone_block
fill 519 298 221 522 298 221 minecraft:packed_mud
fill 520 298 185 520 300 185 minecraft:packed_mud
setblock 520 298 189 minecraft:bone_block
fill 520 298 190 520 300 190 minecraft:packed_mud
setblock 520 298 194 minecraft:bone_block
fill 520 298 195 520 300 195 minecraft:packed_mud
setblock 520 298 214 minecraft:bone_block
fill 520 298 215 520 300 215 minecraft:packed_mud
fill 520 298 217 520 298 218 minecraft:packed_mud
setblock 521 298 182 minecraft:packed_mud
setblock 521 298 183 minecraft:bone_block
fill 521 298 184 521 300 184 minecraft:packed_mud
setblock 521 298 189 minecraft:packed_mud
setblock 521 298 193 minecraft:bone_block
fill 521 298 220 523 298 220 minecraft:packed_mud
setblock 522 298 182 minecraft:bone_block
fill 522 298 183 522 300 183 minecraft:packed_mud
setblock 522 298 222 minecraft:bone_block
fill 523 298 182 523 300 182 minecraft:packed_mud
setblock 523 298 221 minecraft:bone_block
fill 523 298 222 523 300 222 minecraft:packed_mud
setblock 524 298 220 minecraft:bone_block
fill 524 298 221 524 300 221 minecraft:packed_mud
fill 525 298 182 526 298 182 minecraft:packed_mud
setblock 527 298 182 minecraft:bone_block
setblock 527 298 221 minecraft:packed_mud
setblock 527 298 222 minecraft:bone_block
fill 528 298 222 528 300 222 minecraft:packed_mud
fill 530 298 222 531 298 222 minecraft:packed_mud
setblock 532 298 222 minecraft:bone_block
fill 533 298 222 536 298 222 minecraft:packed_mud
setblock 537 298 221 minecraft:packed_mud
setblock 537 298 222 minecraft:bone_block
setblock 538 298 221 minecraft:bone_block
fill 538 298 222 538 300 222 minecraft:packed_mud
fill 539 298 221 539 300 221 minecraft:packed_mud
fill 540 298 220 541 300 220 minecraft:packed_mud
setblock 542 298 222 minecraft:bone_block
setblock 543 298 221 minecraft:bone_block
fill 543 298 222 543 300 222 minecraft:packed_mud
fill 545 298 222 545 299 222 minecraft:packed_mud
fill 556 298 190 556 298 192 minecraft:packed_mud
setblock 556 298 193 minecraft:bone_block
fill 556 298 194 556 299 196 minecraft:packed_mud
setblock 557 298 187 minecraft:bone_block
fill 557 298 188 557 300 188 minecraft:packed_mud
setblock 557 298 192 minecraft:bone_block
fill 557 298 193 557 300 193 minecraft:packed_mud
setblock 557 298 197 minecraft:bone_block
fill 557 298 198 557 299 200 minecraft:packed_mud
fill 558 298 182 558 300 183 minecraft:packed_mud
setblock 558 298 186 minecraft:bone_block
fill 558 298 187 558 300 187 minecraft:packed_mud
setblock 558 298 191 minecraft:bone_block
fill 558 298 192 558 300 192 minecraft:packed_mud
setblock 558 298 196 minecraft:bone_block
fill 558 298 197 558 300 197 minecraft:packed_mud
fill 558 298 199 558 298 200 minecraft:packed_mud
setblock 558 298 201 minecraft:bone_block
fill 558 298 202 558 300 202 minecraft:packed_mud
fill 558 298 204 558 298 205 minecraft:packed_mud
setblock 558 298 206 minecraft:bone_block
fill 558 298 207 558 300 207 minecraft:packed_mud
setblock 558 298 211 minecraft:bone_block
fill 558 298 212 558 300 212 minecraft:packed_mud
setblock 558 298 216 minecraft:bone_block
fill 558 298 217 558 298 220 minecraft:packed_mud
fill 518 299 182 519 299 183 minecraft:packed_mud
setblock 518 299 185 minecraft:bone_block
fill 518 299 186 518 300 186 minecraft:packed_mud
setblock 518 299 190 minecraft:bone_block
fill 518 299 191 518 300 191 minecraft:packed_mud
setblock 518 299 195 minecraft:bone_block
fill 518 299 196 518 300 196 minecraft:packed_mud
setblock 518 299 200 minecraft:bone_block
fill 518 299 201 518 300 202 minecraft:packed_mud
fill 518 299 208 518 299 209 minecraft:packed_mud
setblock 518 299 210 minecraft:bone_block
fill 518 299 211 518 299 214 minecraft:packed_mud
setblock 518 299 215 minecraft:bone_block
fill 518 299 216 518 299 219 minecraft:packed_mud
setblock 518 299 220 minecraft:bone_block
fill 518 299 221 520 299 222 minecraft:packed_mud
setblock 519 299 184 minecraft:bone_block
fill 519 299 185 519 300 185 minecraft:packed_mud
setblock 519 299 189 minecraft:bone_block
fill 519 299 190 519 300 190 minecraft:packed_mud
setblock 519 299 194 minecraft:bone_block
fill 519 299 195 519 300 195 minecraft:packed_mud
setblock 519 299 199 minecraft:bone_block
fill 519 299 211 519 299 213 minecraft:packed_mud
setblock 519 299 214 minecraft:bone_block
fill 519 299 215 519 300 215 minecraft:packed_mud
setblock 519 299 219 minecraft:bone_block
fill 519 299 220 522 299 220 minecraft:packed_mud
setblock 520 299 182 minecraft:packed_mud
setblock 520 299 183 minecraft:bone_block
fill 520 299 184 520 300 184 minecraft:packed_mud
setblock 520 299 188 minecraft:bone_block
fill 520 299 189 520 300 189 minecraft:packed_mud
setblock 520 299 193 minecraft:bone_block
fill 520 299 194 521 300 194 minecraft:packed_mud
setblock 520 299 197 minecraft:packed_mud
setblock 520 299 213 minecraft:bone_block
fill 520 299 214 520 300 214 minecraft:packed_mud
setblock 520 299 217 minecraft:packed_mud
setblock 520 299 218 minecraft:bone_block
fill 520 299 219 520 300 219 minecraft:packed_mud
setblock 521 299 182 minecraft:bone_block
fill 521 299 183 521 300 183 minecraft:packed_mud
setblock 521 299 192 minecraft:bone_block
fill 521 299 193 521 300 193 minecraft:packed_mud
setblock 521 299 221 minecraft:packed_mud
setblock 521 299 222 minecraft:bone_block
fill 522 299 182 522 300 182 minecraft:packed_mud
setblock 522 299 221 minecraft:bone_block
fill 522 299 222 522 300 222 minecraft:packed_mud
setblock 523 299 220 minecraft:bone_block
fill 523 299 221 523 300 221 minecraft:packed_mud
fill 524 299 220 525 300 220 minecraft:packed_mud
setblock 525 299 182 minecraft:packed_mud
setblock 526 299 182 minecraft:bone_block
setblock 526 299 222 minecraft:bone_block
fill 527 299 182 527 300 182 minecraft:packed_mud
setblock 527 299 221 minecraft:bone_block
fill 527 299 222 527 300 222 minecraft:packed_mud
fill 528 299 221 528 300 221 minecraft:packed_mud
setblock 530 299 222 minecraft:packed_mud
setblock 531 299 222 minecraft:bone_block
fill 532 299 222 535 299 222 minecraft:packed_mud
fill 534 299 221 536 299 221 minecraft:packed_mud
setblock 536 299 222 minecraft:bone_block
setblock 537 299 220 minecraft:packed_mud
setblock 537 299 221 minecraft:bone_block
fill 537 299 222 537 300 222 minecraft:packed_mud
setblock 538 299 220 minecraft:bone_block
fill 538 299 221 538 300 221 minecraft:packed_mud
fill 539 299 220 539 300 220 minecraft:packed_mud
fill 540 299 221 541 299 221 minecraft:packed_mud
setblock 541 299 222 minecraft:bone_block
setblock 542 299 220 minecraft:packed_mud
setblock 542 299 221 minecraft:bone_block
fill 542 299 222 542 300 222 minecraft:packed_mud
fill 543 299 221 544 300 221 minecraft:packed_mud
fill 556 299 189 556 299 191 minecraft:packed_mud
setblock 556 299 192 minecraft:bone_block
fill 556 299 193 556 300 193 minecraft:packed_mud
setblock 556 299 197 minecraft:bone_block
fill 556 299 198 556 300 198 minecraft:packed_mud
fill 557 299 182 557 300 182 minecraft:packed_mud
setblock 557 299 186 minecraft:bone_block
fill 557 299 187 557 300 187 minecraft:packed_mud
setblock 557 299 191 minecraft:bone_block
fill 557 299 192 557 300 192 minecraft:packed_mud
setblock 557 299 195 minecraft:packed_mud
setblock 557 299 196 minecraft:bone_block
fill 557 299 197 557 300 197 minecraft:packed_mud
setblock 557 299 201 minecraft:bone_block
fill 557 299 212 557 299 215 minecraft:packed_mud
setblock 557 299 216 minecraft:bone_block
fill 557 299 217 558 300 217 minecraft:packed_mud
setblock 558 299 185 minecraft:bone_block
fill 558 299 186 558 300 186 minecraft:packed_mud
setblock 558 299 190 minecraft:bone_block
fill 558 299 191 558 300 191 minecraft:packed_mud
setblock 558 299 195 minecraft:bone_block
fill 558 299 196 558 300 196 minecraft:packed_mud
setblock 558 299 199 minecraft:packed_mud
setblock 558 299 200 minecraft:bone_block
fill 558 299 201 558 300 201 minecraft:packed_mud
setblock 558 299 204 minecraft:packed_mud
setblock 558 299 205 minecraft:bone_block
fill 558 299 206 558 300 206 minecraft:packed_mud
setblock 558 299 210 minecraft:bone_block
fill 558 299 211 558 300 211 minecraft:packed_mud
setblock 558 299 214 minecraft:packed_mud
setblock 558 299 215 minecraft:bone_block
fill 558 299 216 558 300 216 minecraft:packed_mud
fill 558 299 218 558 299 219 minecraft:packed_mud
setblock 558 299 220 minecraft:bone_block
fill 558 299 221 558 300 222 minecraft:packed_mud
fill 518 300 182 518 300 183 minecraft:packed_mud
setblock 518 300 184 minecraft:bone_block
setblock 518 300 185 minecraft:packed_mud
setblock 518 300 189 minecraft:bone_block
setblock 518 300 190 minecraft:packed_mud
setblock 518 300 194 minecraft:bone_block
setblock 518 300 195 minecraft:packed_mud
setblock 518 300 198 minecraft:packed_mud
setblock 518 300 199 minecraft:bone_block
fill 518 300 200 519 300 200 minecraft:packed_mud
setblock 518 300 203 minecraft:packed_mud
setblock 518 300 208 minecraft:packed_mud
setblock 518 300 209 minecraft:bone_block
fill 518 300 210 518 300 213 minecraft:packed_mud
setblock 518 300 214 minecraft:bone_block
fill 518 300 215 518 300 218 minecraft:packed_mud
setblock 518 300 219 minecraft:bone_block
fill 518 300 220 519 300 222 minecraft:packed_mud
setblock 519 300 182 minecraft:packed_mud
setblock 519 300 183 minecraft:bone_block
setblock 519 300 184 minecraft:packed_mud
setblock 519 300 188 minecraft:bone_block
setblock 519 300 189 minecraft:packed_mud
setblock 519 300 193 minecraft:bone_block
setblock 519 300 194 minecraft:packed_mud
setblock 519 300 198 minecraft:bone_block
setblock 519 300 199 minecraft:packed_mud
fill 519 300 210 519 300 212 minecraft:packed_mud
setblock 519 300 213 minecraft:bone_block
setblock 519 300 214 minecraft:packed_mud
setblock 519 300 217 minecraft:packed_mud
setblock 519 300 218 minecraft:bone_block
setblock 519 300 219 minecraft:packed_mud
setblock 520 300 182 minecraft:bone_block
setblock 520 300 183 minecraft:packed_mud
setblock 520 300 187 minecraft:bone_block
setblock 520 300 188 minecraft:packed_mud
setblock 520 300 191 minecraft:packed_mud
setblock 520 300 192 minecraft:bone_block
setblock 520 300 193 minecraft:packed_mud
setblock 520 300 197 minecraft:bone_block
setblock 520 300 198 minecraft:packed_mud
setblock 520 300 213 minecraft:packed_mud
setblock 520 300 217 minecraft:bone_block
fill 520 300 218 521 300 218 minecraft:packed_mud
fill 520 300 220 520 300 221 minecraft:packed_mud
setblock 520 300 222 minecraft:bone_block
setblock 521 300 182 minecraft:packed_mud
setblock 521 300 191 minecraft:bone_block
setblock 521 300 192 minecraft:packed_mud
setblock 521 300 216 minecraft:bone_block
setblock 521 300 217 minecraft:packed_mud
fill 521 300 219 521 300 220 minecraft:packed_mud
setblock 521 300 221 minecraft:bone_block
setblock 521 300 222 minecraft:packed_mud
setblock 522 300 219 minecraft:packed_mud
setblock 522 300 220 minecraft:bone_block
setblock 522 300 221 minecraft:packed_mud
setblock 523 300 219 minecraft:bone_block
setblock 523 300 220 minecraft:packed_mud
setblock 524 300 183 minecraft:bone_block
setblock 525 300 182 minecraft:bone_block
setblock 525 300 221 minecraft:packed_mud
setblock 525 300 222 minecraft:bone_block
setblock 526 300 182 minecraft:packed_mud
setblock 526 300 220 minecraft:packed_mud
setblock 526 300 221 minecraft:bone_block
setblock 526 300 222 minecraft:packed_mud
setblock 527 300 221 minecraft:packed_mud
fill 529 300 221 530 300 221 minecraft:packed_mud
setblock 530 300 222 minecraft:bone_block
setblock 531 300 221 minecraft:bone_block
fill 531 300 222 534 300 222 minecraft:packed_mud
fill 532 300 221 535 300 221 minecraft:packed_mud
fill 535 300 220 536 300 220 minecraft:packed_mud
setblock 535 300 222 minecraft:bone_block
setblock 536 300 221 minecraft:bone_block
setblock 536 300 222 minecraft:packed_mud
setblock 537 300 219 minecraft:packed_mud
setblock 537 300 220 minecraft:bone_block
setblock 537 300 221 minecraft:packed_mud
fill 538 300 182 539 300 182 minecraft:packed_mud
setblock 538 300 219 minecraft:bone_block
setblock 538 300 220 minecraft:packed_mud
fill 539 300 219 541 300 219 minecraft:packed_mud
setblock 540 300 182 minecraft:bone_block
setblock 540 300 221 minecraft:packed_mud
setblock 540 300 222 minecraft:bone_block
setblock 541 300 182 minecraft:packed_mud
setblock 541 300 221 minecraft:bone_block
setblock 541 300 222 minecraft:packed_mud
setblock 542 300 220 minecraft:bone_block
setblock 542 300 221 minecraft:packed_mud
setblock 543 300 220 minecraft:packed_mud
setblock 545 300 222 minecraft:bone_block
fill 555 300 194 556 300 195 minecraft:packed_mud
setblock 556 300 182 minecraft:packed_mud
fill 556 300 189 556 300 190 minecraft:packed_mud
setblock 556 300 191 minecraft:bone_block
setblock 556 300 192 minecraft:packed_mud
setblock 556 300 196 minecraft:bone_block
setblock 556 300 197 minecraft:packed_mud
fill 556 300 199 557 300 199 minecraft:packed_mud
setblock 557 300 185 minecraft:bone_block
setblock 557 300 186 minecraft:packed_mud
setblock 557 300 190 minecraft:bone_block
setblock 557 300 191 minecraft:packed_mud
setblock 557 300 195 minecraft:bone_block
setblock 557 300 196 minecraft:packed_mud
setblock 557 300 198 minecraft:packed_mud
setblock 557 300 200 minecraft:bone_block
fill 557 300 201 557 300 202 minecraft:packed_mud
fill 557 300 212 557 300 214 minecraft:packed_mud
setblock 557 300 215 minecraft:bone_block
setblock 557 300 216 minecraft:packed_mud
fill 557 300 218 557 300 219 minecraft:packed_mud
setblock 557 300 222 minecraft:packed_mud
setblock 558 300 184 minecraft:bone_block
setblock 558 300 185 minecraft:packed_mud
setblock 558 300 189 minecraft:bone_block
setblock 558 300 190 minecraft:packed_mud
setblock 558 300 194 minecraft:bone_block
setblock 558 300 195 minecraft:packed_mud
setblock 558 300 199 minecraft:bone_block
setblock 558 300 200 minecraft:packed_mud
setblock 558 300 204 minecraft:bone_block
setblock 558 300 205 minecraft:packed_mud
setblock 558 300 209 minecraft:bone_block
setblock 558 300 210 minecraft:packed_mud
setblock 558 300 214 minecraft:bone_block
setblock 558 300 215 minecraft:packed_mud
setblock 558 300 218 minecraft:packed_mud
setblock 558 300 219 minecraft:bone_block
setblock 558 300 220 minecraft:packed_mud
setblock 520 303 184 minecraft:light[level=11]
setblock 520 303 192 minecraft:light[level=11]
setblock 520 303 200 minecraft:light[level=11]
setblock 520 303 208 minecraft:light[level=11]
setblock 520 303 216 minecraft:light[level=11]
setblock 528 303 184 minecraft:light[level=11]
setblock 528 303 192 minecraft:light[level=11]
setblock 528 303 200 minecraft:light[level=11]
setblock 528 303 208 minecraft:light[level=11]
setblock 528 303 216 minecraft:light[level=11]
setblock 536 303 184 minecraft:light[level=11]
setblock 536 303 192 minecraft:light[level=11]
setblock 536 303 200 minecraft:light[level=11]
setblock 536 303 208 minecraft:light[level=11]
setblock 536 303 216 minecraft:light[level=11]
setblock 544 303 184 minecraft:light[level=11]
setblock 544 303 192 minecraft:light[level=11]
setblock 544 303 200 minecraft:light[level=11]
setblock 544 303 208 minecraft:light[level=11]
setblock 544 303 216 minecraft:light[level=11]
setblock 552 303 184 minecraft:light[level=11]
setblock 552 303 192 minecraft:light[level=11]
setblock 552 303 200 minecraft:light[level=11]
setblock 552 303 208 minecraft:light[level=11]
setblock 552 303 216 minecraft:light[level=11]
