fill 507 151 424 507 209 425 minecraft:red_nether_bricks
fill 510 151 458 510 154 458 minecraft:red_nether_bricks
setblock 512 151 416 minecraft:orange_concrete
setblock 512 151 427 minecraft:orange_concrete
fill 512 151 432 512 154 432 minecraft:red_nether_bricks
fill 512 151 443 512 154 443 minecraft:red_nether_bricks
setblock 512 151 444 minecraft:orange_concrete
fill 512 151 447 512 151 448 minecraft:orange_concrete
fill 470 152 420 470 153 421 minecraft:orange_concrete
fill 470 152 422 470 157 423 minecraft:red_nether_bricks
fill 470 152 429 470 153 429 minecraft:orange_concrete
fill 470 152 430 470 153 431 minecraft:red_nether_bricks
fill 470 152 432 470 152 433 minecraft:orange_concrete
fill 470 152 434 470 157 434 minecraft:red_nether_bricks
fill 470 152 440 470 153 441 minecraft:orange_concrete
fill 470 152 442 470 157 443 minecraft:red_nether_bricks
fill 470 152 451 470 157 451 minecraft:red_nether_bricks
fill 470 152 452 470 152 453 minecraft:orange_concrete
fill 470 152 454 470 157 455 minecraft:red_nether_bricks
fill 472 152 458 473 153 458 minecraft:orange_concrete
setblock 473 152 419 minecraft:light[level=14]
setblock 473 152 427 minecraft:light[level=14]
setblock 473 152 435 minecraft:light[level=14]
setblock 473 152 443 minecraft:light[level=14]
setblock 473 152 451 minecraft:light[level=14]
fill 474 152 458 475 157 458 minecraft:red_nether_bricks
setblock 476 152 458 minecraft:orange_concrete
fill 479 152 416 480 157 416 minecraft:red_nether_bricks
fill 481 152 416 482 153 416 minecraft:orange_concrete
setblock 481 152 419 minecraft:light[level=14]
setblock 481 152 427 minecraft:light[level=14]
setblock 481 152 435 minecraft:light[level=14]
setblock 481 152 443 minecraft:light[level=14]
setblock 481 152 451 minecraft:light[level=14]
setblock 483 152 434 minecraft:blackstone
setblock 483 152 448 minecraft:blackstone
fill 484 152 458 485 153 458 minecraft:orange_concrete
fill 486 152 458 487 157 458 minecraft:red_nether_bricks
fill 488 152 416 488 157 416 minecraft:red_nether_bricks
fill 489 152 416 490 152 416 minecraft:orange_concrete
setblock 489 152 419 minecraft:light[level=14]
setblock 489 152 427 minecraft:light[level=14]
setblock 489 152 435 minecraft:light[level=14]
setblock 489 152 443 minecraft:light[level=14]
setblock 489 152 451 minecraft:light[level=14]
fill 491 152 416 491 157 416 minecraft:red_nether_bricks
fill 493 152 416 493 153 416 minecraft:orange_concrete
fill 493 152 458 493 153 458 minecraft:orange_concrete
fill 495 152 458 495 157 458 minecraft:red_nether_bricks
fill 496 152 458 497 152 458 minecraft:orange_concrete
setblock 497 152 419 minecraft:light[level=14]
setblock 497 152 427 minecraft:light[level=14]
setblock 497 152 435 minecraft:light[level=14]
setblock 497 152 443 minecraft:light[level=14]
fill 497 152 449 497 158 449 minecraft:red_nether_bricks
fill 497 152 453 497 154 453 minecraft:red_nether_bricks
fill 498 152 450 498 157 452 minecraft:red_nether_bricks
fill 498 152 458 498 157 458 minecraft:red_nether_bricks
fill 499 152 416 500 157 416 minecraft:red_nether_bricks
fill 501 152 416 502 153 416 minecraft:orange_concrete
fill 502 152 423 502 153 427 minecraft:blackstone
fill 503 152 422 507 153 422 minecraft:blackstone
fill 503 152 427 503 153 427 minecraft:blackstone
fill 504 152 428 506 153 428 minecraft:blackstone
fill 504 152 458 505 153 458 minecraft:orange_concrete
setblock 505 152 419 minecraft:light[level=14]
setblock 505 152 435 minecraft:light[level=14]
setblock 505 152 443 minecraft:light[level=14]
setblock 505 152 451 minecraft:light[level=14]
fill 506 152 427 507 153 427 minecraft:blackstone
fill 506 152 458 507 157 458 minecraft:red_nether_bricks
fill 507 152 423 507 153 423 minecraft:blackstone
fill 507 152 426 508 153 426 minecraft:blackstone
fill 508 152 424 508 153 425 minecraft:blackstone
setblock 510 152 416 minecraft:orange_concrete
fill 511 152 416 512 157 416 minecraft:red_nether_bricks
fill 512 152 417 512 153 418 minecraft:orange_concrete
fill 512 152 423 512 157 424 minecraft:red_nether_bricks
fill 512 152 425 512 152 426 minecraft:orange_concrete
fill 512 152 427 512 157 427 minecraft:red_nether_bricks
fill 512 152 435 512 157 436 minecraft:red_nether_bricks
fill 512 152 437 512 153 438 minecraft:orange_concrete
fill 512 152 444 512 157 444 minecraft:red_nether_bricks
setblock 512 152 446 minecraft:orange_concrete
fill 512 152 447 512 157 448 minecraft:red_nether_bricks
fill 512 152 449 512 153 449 minecraft:orange_concrete
fill 512 152 455 512 157 456 minecraft:red_nether_bricks
setblock 512 152 457 minecraft:orange_concrete
setblock 470 153 417 minecraft:orange_concrete
setblock 470 153 428 minecraft:orange_concrete
fill 470 153 432 470 155 433 minecraft:red_nether_bricks
fill 470 153 448 470 153 449 minecraft:orange_concrete
setblock 470 153 452 minecraft:orange_concrete
fill 470 153 453 470 156 453 minecraft:red_nether_bricks
setblock 473 153 416 minecraft:orange_concrete
fill 476 153 458 476 156 458 minecraft:red_nether_bricks
setblock 481 153 458 minecraft:orange_concrete
setblock 482 153 433 minecraft:blackstone
setblock 482 153 449 minecraft:blackstone
fill 488 153 448 489 154 449 minecraft:shroomlight
fill 489 153 416 490 156 416 minecraft:red_nether_bricks
setblock 492 153 458 minecraft:orange_concrete
setblock 494 153 416 minecraft:orange_concrete
fill 495 153 449 496 154 449 minecraft:red_nether_bricks
fill 496 153 458 497 156 458 minecraft:red_nether_bricks
fill 498 153 449 498 159 449 minecraft:red_nether_bricks
fill 499 153 450 499 158 451 minecraft:red_nether_bricks
fill 501 153 422 501 153 427 minecraft:blackstone
fill 502 153 421 502 153 422 minecraft:blackstone
fill 502 153 428 503 153 428 minecraft:blackstone
fill 503 153 421 507 153 421 minecraft:blackstone
fill 504 153 429 506 153 429 minecraft:blackstone
setblock 505 153 416 minecraft:orange_concrete
setblock 505 153 420 minecraft:blackstone
setblock 507 153 428 minecraft:blackstone
fill 508 153 422 508 153 423 minecraft:blackstone
setblock 508 153 427 minecraft:blackstone
fill 509 153 423 509 153 426 minecraft:blackstone
fill 510 153 416 510 156 416 minecraft:red_nether_bricks
fill 512 153 425 512 156 425 minecraft:red_nether_bricks
setblock 512 153 426 minecraft:orange_concrete
fill 512 153 429 512 153 430 minecraft:orange_concrete
fill 512 153 446 512 156 446 minecraft:red_nether_bricks
setblock 512 153 450 minecraft:orange_concrete
fill 512 153 457 512 156 457 minecraft:red_nether_bricks
fill 470 154 417 470 159 417 minecraft:red_nether_bricks
fill 470 154 418 470 154 419 minecraft:orange_concrete
fill 470 154 420 470 156 421 minecraft:red_nether_bricks
fill 470 154 426 470 155 427 minecraft:orange_concrete
fill 470 154 428 470 159 429 minecraft:red_nether_bricks
setblock 470 154 430 minecraft:orange_concrete
fill 470 154 431 470 157 431 minecraft:red_nether_bricks
fill 470 154 438 470 154 439 minecraft:orange_concrete
fill 470 154 440 470 159 441 minecraft:red_nether_bricks
fill 470 154 447 470 155 447 minecraft:orange_concrete
fill 470 154 448 470 159 449 minecraft:red_nether_bricks
setblock 470 154 450 minecraft:orange_concrete
fill 470 154 452 470 159 452 minecraft:red_nether_bricks
fill 470 154 458 471 155 458 minecraft:orange_concrete
fill 471 154 416 472 154 416 minecraft:orange_concrete
fill 472 154 458 473 159 458 minecraft:red_nether_bricks
fill 473 154 416 473 159 416 minecraft:red_nether_bricks
fill 475 154 416 475 155 416 minecraft:orange_concrete
fill 481 154 416 482 159 416 minecraft:red_nether_bricks
fill 481 154 458 481 159 458 minecraft:red_nether_bricks
fill 482 154 458 483 154 458 minecraft:orange_concrete
fill 483 154 416 484 155 416 minecraft:orange_concrete
fill 484 154 458 485 159 458 minecraft:red_nether_bricks
fill 490 154 458 491 155 458 minecraft:orange_concrete
setblock 492 154 416 minecraft:orange_concrete
fill 492 154 458 493 159 458 minecraft:red_nether_bricks
fill 493 154 416 494 159 416 minecraft:red_nether_bricks
fill 493 154 451 493 155 452 minecraft:magma_block
setblock 494 154 458 minecraft:orange_concrete
fill 495 154 416 496 155 416 minecraft:orange_concrete
fill 497 154 448 498 157 448 minecraft:red_nether_bricks
fill 499 154 449 500 160 449 minecraft:red_nether_bricks
fill 499 154 452 499 157 452 minecraft:red_nether_bricks
fill 500 154 450 500 159 451 minecraft:red_nether_bricks
fill 501 154 416 502 159 416 minecraft:red_nether_bricks
fill 502 154 458 503 155 458 minecraft:orange_concrete
fill 503 154 416 504 154 416 minecraft:orange_concrete
fill 504 154 458 505 159 458 minecraft:red_nether_bricks
fill 505 154 416 505 159 416 minecraft:red_nether_bricks
fill 511 154 458 511 155 458 minecraft:orange_concrete
fill 512 154 417 512 159 418 minecraft:red_nether_bricks
fill 512 154 419 512 155 420 minecraft:orange_concrete
fill 512 154 426 512 159 426 minecraft:red_nether_bricks
setblock 512 154 428 minecraft:orange_concrete
fill 512 154 429 512 159 430 minecraft:red_nether_bricks
fill 512 154 431 512 155 431 minecraft:orange_concrete
fill 512 154 437 512 159 438 minecraft:red_nether_bricks
fill 512 154 439 512 154 440 minecraft:orange_concrete
fill 512 154 449 512 159 450 minecraft:red_nether_bricks
fill 512 154 451 512 155 452 minecraft:orange_concrete
setblock 470 155 418 minecraft:orange_concrete
fill 470 155 419 470 158 419 minecraft:red_nether_bricks
fill 470 155 430 470 157 430 minecraft:red_nether_bricks
setblock 470 155 435 minecraft:orange_concrete
fill 470 155 436 470 155 437 minecraft:red_nether_bricks
setblock 470 155 438 minecraft:orange_concrete
fill 470 155 439 470 158 439 minecraft:red_nether_bricks
fill 470 155 444 470 155 445 minecraft:red_nether_bricks
setblock 470 155 446 minecraft:orange_concrete
fill 470 155 450 470 158 450 minecraft:red_nether_bricks
fill 471 155 416 472 157 416 minecraft:red_nether_bricks
setblock 476 155 416 minecraft:orange_concrete
setblock 477 155 458 minecraft:red_nether_bricks
fill 478 155 458 479 155 458 minecraft:orange_concrete
setblock 482 155 458 minecraft:orange_concrete
fill 483 155 458 483 158 458 minecraft:red_nether_bricks
setblock 487 155 416 minecraft:orange_concrete
fill 492 155 416 492 158 416 minecraft:red_nether_bricks
setblock 494 155 452 minecraft:magma_block
fill 494 155 458 494 158 458 minecraft:red_nether_bricks
fill 496 155 449 496 156 452 minecraft:red_nether_bricks
fill 499 155 448 500 161 448 minecraft:red_nether_bricks
setblock 499 155 458 minecraft:orange_concrete
fill 501 155 449 501 160 450 minecraft:red_nether_bricks
fill 503 155 416 503 158 416 minecraft:red_nether_bricks
setblock 504 155 416 minecraft:orange_concrete
fill 507 155 416 508 155 416 minecraft:orange_concrete
setblock 510 155 458 minecraft:orange_concrete
fill 512 155 428 512 158 428 minecraft:red_nether_bricks
setblock 512 155 432 minecraft:orange_concrete
fill 512 155 439 512 158 439 minecraft:red_nether_bricks
setblock 512 155 440 minecraft:orange_concrete
setblock 512 155 443 minecraft:orange_concrete
setblock 470 156 416 minecraft:orange_concrete
fill 470 156 418 470 158 418 minecraft:red_nether_bricks
fill 470 156 424 470 157 425 minecraft:orange_concrete
fill 470 156 426 470 161 427 minecraft:red_nether_bricks
fill 470 156 432 471 156 432 minecraft:red_nether_bricks
fill 470 156 433 470 157 433 minecraft:orange_concrete
fill 470 156 435 471 156 435 minecraft:red_nether_bricks
fill 470 156 436 470 156 437 minecraft:orange_concrete
fill 470 156 438 470 161 438 minecraft:red_nether_bricks
fill 470 156 444 470 157 445 minecraft:orange_concrete
fill 470 156 446 470 161 447 minecraft:red_nether_bricks
fill 470 156 456 470 156 457 minecraft:orange_concrete
fill 470 156 458 471 161 458 minecraft:red_nether_bricks
fill 471 156 417 473 156 417 minecraft:red_nether_bricks
fill 471 156 419 471 156 421 minecraft:red_nether_bricks
fill 471 156 423 471 156 425 minecraft:red_nether_bricks
fill 471 156 427 471 156 429 minecraft:red_nether_bricks
setblock 471 156 431 minecraft:red_nether_bricks
setblock 471 156 433 minecraft:red_nether_bricks
fill 471 156 436 471 156 437 minecraft:red_nether_bricks
fill 471 156 439 471 156 441 minecraft:red_nether_bricks
fill 471 156 443 471 156 445 minecraft:red_nether_bricks
fill 471 156 447 471 156 449 minecraft:red_nether_bricks
fill 471 156 451 471 156 453 minecraft:red_nether_bricks
fill 471 156 455 471 156 457 minecraft:red_nether_bricks
fill 473 156 457 475 156 457 minecraft:red_nether_bricks
setblock 474 156 416 minecraft:orange_concrete
fill 475 156 416 476 156 417 minecraft:red_nether_bricks
fill 477 156 416 478 157 416 minecraft:orange_concrete
setblock 477 156 417 minecraft:red_nether_bricks
fill 477 156 457 479 156 457 minecraft:red_nether_bricks
fill 477 156 458 477 157 458 minecraft:orange_concrete
fill 478 156 458 479 161 458 minecraft:red_nether_bricks
fill 479 156 417 481 156 417 minecraft:red_nether_bricks
setblock 480 156 458 minecraft:orange_concrete
fill 481 156 457 483 156 457 minecraft:red_nether_bricks
fill 482 156 458 482 161 458 minecraft:red_nether_bricks
fill 483 156 416 484 156 417 minecraft:red_nether_bricks
fill 485 156 416 486 156 416 minecraft:orange_concrete
setblock 485 156 417 minecraft:red_nether_bricks
fill 485 156 457 487 156 457 minecraft:red_nether_bricks
fill 487 156 416 487 156 417 minecraft:red_nether_bricks
fill 488 156 417 489 156 417 minecraft:red_nether_bricks
fill 488 156 458 489 157 458 minecraft:orange_concrete
fill 489 156 457 491 156 457 minecraft:red_nether_bricks
fill 490 156 458 491 161 458 minecraft:red_nether_bricks
fill 491 156 417 493 156 417 minecraft:red_nether_bricks
setblock 493 156 452 minecraft:magma_block
fill 493 156 457 495 156 457 minecraft:red_nether_bricks
fill 495 156 416 496 156 417 minecraft:red_nether_bricks
fill 497 156 416 498 157 416 minecraft:orange_concrete
setblock 497 156 417 minecraft:red_nether_bricks
fill 497 156 457 499 156 457 minecraft:red_nether_bricks
fill 499 156 417 501 156 417 minecraft:red_nether_bricks
fill 499 156 447 500 160 447 minecraft:red_nether_bricks
fill 499 156 458 499 161 458 minecraft:red_nether_bricks
setblock 500 156 452 minecraft:red_nether_bricks
fill 500 156 458 501 156 458 minecraft:orange_concrete
fill 501 156 448 501 163 448 minecraft:red_nether_bricks
fill 501 156 451 501 158 451 minecraft:red_nether_bricks
fill 501 156 457 503 156 457 minecraft:red_nether_bricks
fill 502 156 458 503 161 458 minecraft:red_nether_bricks
fill 503 156 417 505 156 417 minecraft:red_nether_bricks
fill 504 156 416 504 161 416 minecraft:red_nether_bricks
fill 505 156 457 507 156 457 minecraft:red_nether_bricks
setblock 506 156 416 minecraft:orange_concrete
fill 507 156 416 508 156 417 minecraft:red_nether_bricks
fill 508 156 458 509 157 458 minecraft:orange_concrete
fill 509 156 416 509 157 416 minecraft:orange_concrete
setblock 509 156 417 minecraft:red_nether_bricks
fill 509 156 457 511 156 457 minecraft:red_nether_bricks
fill 510 156 458 511 161 458 minecraft:red_nether_bricks
fill 511 156 417 511 156 419 minecraft:red_nether_bricks
fill 511 156 421 511 156 423 minecraft:red_nether_bricks
fill 511 156 425 511 156 427 minecraft:red_nether_bricks
fill 511 156 429 511 156 431 minecraft:red_nether_bricks
fill 511 156 433 511 156 435 minecraft:red_nether_bricks
fill 511 156 437 511 156 439 minecraft:red_nether_bricks
fill 511 156 441 511 156 443 minecraft:red_nether_bricks
fill 511 156 445 511 156 447 minecraft:red_nether_bricks
fill 511 156 449 511 156 451 minecraft:red_nether_bricks
fill 511 156 453 511 156 455 minecraft:red_nether_bricks
fill 512 156 419 512 161 420 minecraft:red_nether_bricks
fill 512 156 421 512 156 422 minecraft:orange_concrete
fill 512 156 431 512 161 432 minecraft:red_nether_bricks
fill 512 156 433 512 157 434 minecraft:orange_concrete
fill 512 156 440 512 161 440 minecraft:red_nether_bricks
fill 512 156 441 512 156 442 minecraft:orange_concrete
fill 512 156 443 512 161 443 minecraft:red_nether_bricks
fill 512 156 445 512 157 445 minecraft:orange_concrete
fill 512 156 451 512 161 452 minecraft:red_nether_bricks
fill 512 156 453 512 157 454 minecraft:orange_concrete
setblock 512 156 458 minecraft:orange_concrete
fill 470 157 416 470 160 416 minecraft:red_nether_bricks
fill 470 157 420 470 159 420 minecraft:red_nether_bricks
setblock 470 157 421 minecraft:orange_concrete
setblock 470 157 432 minecraft:orange_concrete
fill 470 157 435 470 160 437 minecraft:red_nether_bricks
setblock 470 157 453 minecraft:orange_concrete
setblock 470 157 456 minecraft:orange_concrete
fill 470 157 457 470 160 457 minecraft:red_nether_bricks
fill 471 157 447 471 161 447 minecraft:magma_block
fill 474 157 416 476 159 416 minecraft:red_nether_bricks
setblock 476 157 458 minecraft:orange_concrete
fill 480 157 458 480 160 458 minecraft:red_nether_bricks
fill 483 157 416 485 160 416 minecraft:red_nether_bricks
setblock 486 157 416 minecraft:orange_concrete
fill 487 157 416 487 161 416 minecraft:red_nether_bricks
fill 489 157 416 490 157 416 minecraft:orange_concrete
fill 489 157 444 491 209 445 minecraft:red_nether_bricks
fill 495 157 416 496 161 416 minecraft:red_nether_bricks
fill 496 157 458 497 157 458 minecraft:orange_concrete
fill 497 157 450 497 157 451 minecraft:red_nether_bricks
setblock 500 157 458 minecraft:orange_concrete
fill 501 157 447 502 163 447 minecraft:red_nether_bricks
fill 501 157 458 501 160 458 minecraft:red_nether_bricks
fill 502 157 448 502 160 450 minecraft:red_nether_bricks
fill 506 157 416 508 160 416 minecraft:red_nether_bricks
setblock 510 157 416 minecraft:orange_concrete
fill 512 157 421 512 160 421 minecraft:red_nether_bricks
setblock 512 157 422 minecraft:orange_concrete
setblock 512 157 425 minecraft:orange_concrete
fill 512 157 441 512 160 442 minecraft:red_nether_bricks
setblock 512 157 446 minecraft:orange_concrete
setblock 512 157 457 minecraft:orange_concrete
fill 512 157 458 512 160 458 minecraft:red_nether_bricks
fill 470 158 421 470 159 421 minecraft:red_nether_bricks
fill 470 158 422 470 158 423 minecraft:orange_concrete
fill 470 158 424 470 163 425 minecraft:red_nether_bricks
fill 470 158 430 470 159 431 minecraft:orange_concrete
fill 470 158 432 470 163 433 minecraft:red_nether_bricks
setblock 470 158 434 minecraft:orange_concrete
fill 470 158 442 470 159 443 minecraft:orange_concrete
fill 470 158 444 470 163 445 minecraft:red_nether_bricks
fill 470 158 451 470 159 451 minecraft:orange_concrete
fill 470 158 453 470 163 453 minecraft:red_nether_bricks
fill 470 158 454 470 158 455 minecraft:orange_concrete
fill 470 158 456 470 163 456 minecraft:red_nether_bricks
fill 471 158 416 471 159 416 minecraft:orange_concrete
fill 471 158 445 471 161 446 minecraft:magma_block
fill 471 158 448 471 161 449 minecraft:magma_block
setblock 472 158 416 minecraft:red_nether_bricks
fill 472 158 446 472 161 448 minecraft:magma_block
fill 473 158 447 473 162 447 minecraft:magma_block
fill 474 158 458 475 159 458 minecraft:orange_concrete
fill 476 158 458 477 163 458 minecraft:red_nether_bricks
fill 477 158 416 478 163 416 minecraft:red_nether_bricks
fill 479 158 416 480 159 416 minecraft:orange_concrete
fill 486 158 416 486 163 416 minecraft:red_nether_bricks
fill 486 158 458 487 158 458 minecraft:orange_concrete
setblock 488 158 416 minecraft:orange_concrete
fill 488 158 458 489 163 458 minecraft:red_nether_bricks
fill 489 158 416 490 163 416 minecraft:red_nether_bricks
fill 490 158 446 490 159 446 minecraft:blackstone
fill 491 158 416 491 159 416 minecraft:orange_concrete
fill 495 158 458 495 159 458 minecraft:orange_concrete
fill 496 158 458 497 163 458 minecraft:red_nether_bricks
fill 497 158 416 498 163 416 minecraft:red_nether_bricks
fill 497 158 450 498 158 450 minecraft:red_nether_bricks
fill 498 158 448 498 159 448 minecraft:red_nether_bricks
setblock 498 158 451 minecraft:red_nether_bricks
setblock 498 158 458 minecraft:orange_concrete
fill 499 158 416 500 158 416 minecraft:orange_concrete
fill 500 158 446 502 162 446 minecraft:red_nether_bricks
fill 500 158 458 500 163 458 minecraft:red_nether_bricks
fill 503 158 447 503 163 448 minecraft:red_nether_bricks
fill 506 158 458 507 159 458 minecraft:orange_concrete
fill 508 158 458 509 163 458 minecraft:red_nether_bricks
fill 509 158 416 510 163 416 minecraft:red_nether_bricks
fill 511 158 416 512 159 416 minecraft:orange_concrete
fill 512 158 422 512 163 422 minecraft:red_nether_bricks
fill 512 158 423 512 158 424 minecraft:orange_concrete
fill 512 158 425 512 163 425 minecraft:red_nether_bricks
fill 512 158 427 512 159 427 minecraft:orange_concrete
fill 512 158 433 512 163 434 minecraft:red_nether_bricks
fill 512 158 435 512 159 436 minecraft:orange_concrete
setblock 512 158 444 minecraft:orange_concrete
fill 512 158 445 512 163 446 minecraft:red_nether_bricks
fill 512 158 447 512 159 448 minecraft:orange_concrete
fill 512 158 453 512 163 454 minecraft:red_nether_bricks
fill 512 158 455 512 158 456 minecraft:orange_concrete
fill 512 158 457 512 163 457 minecraft:red_nether_bricks
fill 470 159 418 470 159 419 minecraft:orange_concrete
setblock 470 159 422 minecraft:orange_concrete
fill 470 159 423 470 162 423 minecraft:red_nether_bricks
fill 470 159 434 470 162 434 minecraft:red_nether_bricks
setblock 470 159 439 minecraft:orange_concrete
setblock 470 159 450 minecraft:orange_concrete
fill 470 159 454 470 162 455 minecraft:red_nether_bricks
setblock 472 159 416 minecraft:orange_concrete
fill 472 159 445 472 160 445 minecraft:magma_block
fill 472 159 449 472 160 449 minecraft:magma_block
fill 473 159 446 474 161 446 minecraft:magma_block
fill 473 159 448 474 161 448 minecraft:magma_block
fill 474 159 447 474 162 447 minecraft:magma_block
setblock 483 159 458 minecraft:orange_concrete
setblock 486 159 458 minecraft:orange_concrete
fill 487 159 458 487 162 458 minecraft:red_nether_bricks
fill 488 159 416 488 162 416 minecraft:red_nether_bricks
fill 488 159 443 488 159 445 minecraft:blackstone
setblock 489 159 446 minecraft:blackstone
setblock 491 159 446 minecraft:blackstone
setblock 492 159 416 minecraft:orange_concrete
fill 492 159 444 492 159 445 minecraft:blackstone
setblock 494 159 458 minecraft:orange_concrete
fill 498 159 450 499 159 450 minecraft:red_nether_bricks
fill 498 159 458 498 162 458 minecraft:red_nether_bricks
fill 499 159 416 499 162 416 minecraft:red_nether_bricks
setblock 500 159 416 minecraft:orange_concrete
setblock 503 159 416 minecraft:orange_concrete
fill 503 159 446 503 166 446 minecraft:red_nether_bricks
fill 503 159 449 503 162 449 minecraft:red_nether_bricks
fill 512 159 423 512 162 424 minecraft:red_nether_bricks
setblock 512 159 428 minecraft:orange_concrete
setblock 512 159 439 minecraft:orange_concrete
fill 512 159 444 512 162 444 minecraft:red_nether_bricks
fill 512 159 455 512 162 455 minecraft:red_nether_bricks
setblock 512 159 456 minecraft:orange_concrete
fill 470 160 417 470 161 417 minecraft:orange_concrete
fill 470 160 418 470 161 419 minecraft:red_nether_bricks
fill 470 160 420 470 160 421 minecraft:orange_concrete
fill 470 160 422 470 165 422 minecraft:red_nether_bricks
fill 470 160 428 470 161 429 minecraft:orange_concrete
fill 470 160 430 470 165 431 minecraft:red_nether_bricks
fill 470 160 439 470 165 439 minecraft:red_nether_bricks
fill 470 160 440 470 160 441 minecraft:orange_concrete
fill 470 160 442 470 165 443 minecraft:red_nether_bricks
fill 470 160 448 470 161 449 minecraft:orange_concrete
fill 470 160 450 470 165 451 minecraft:red_nether_bricks
setblock 470 160 452 minecraft:orange_concrete
fill 471 160 416 472 165 416 minecraft:red_nether_bricks
fill 472 160 458 473 161 458 minecraft:orange_concrete
fill 473 160 416 474 161 416 minecraft:orange_concrete
setblock 473 160 419 minecraft:light[level=14]
setblock 473 160 427 minecraft:light[level=14]
setblock 473 160 435 minecraft:light[level=14]
setblock 473 160 443 minecraft:light[level=14]
setblock 473 160 445 minecraft:magma_block
setblock 473 160 449 minecraft:magma_block
setblock 473 160 451 minecraft:light[level=14]
fill 474 160 458 475 165 458 minecraft:red_nether_bricks
fill 475 160 416 476 161 416 minecraft:red_nether_bricks
fill 475 160 446 475 162 448 minecraft:magma_block
fill 476 160 447 476 162 447 minecraft:magma_block
fill 479 160 416 480 165 416 minecraft:red_nether_bricks
fill 481 160 416 482 160 416 minecraft:orange_concrete
setblock 481 160 419 minecraft:light[level=14]
setblock 481 160 427 minecraft:light[level=14]
setblock 481 160 435 minecraft:light[level=14]
setblock 481 160 443 minecraft:light[level=14]
setblock 481 160 451 minecraft:light[level=14]
fill 481 160 458 481 161 458 minecraft:orange_concrete
fill 483 160 458 483 165 458 minecraft:red_nether_bricks
fill 484 160 458 485 160 458 minecraft:orange_concrete
fill 486 160 458 486 165 458 minecraft:red_nether_bricks
setblock 489 160 419 minecraft:light[level=14]
setblock 489 160 427 minecraft:light[level=14]
setblock 489 160 435 minecraft:light[level=14]
setblock 489 160 443 minecraft:light[level=14]
setblock 489 160 451 minecraft:light[level=14]
fill 491 160 416 492 165 416 minecraft:red_nether_bricks
fill 492 160 458 493 161 458 minecraft:orange_concrete
fill 493 160 416 494 161 416 minecraft:orange_concrete
fill 494 160 458 495 165 458 minecraft:red_nether_bricks
setblock 497 160 419 minecraft:light[level=14]
setblock 497 160 427 minecraft:light[level=14]
setblock 497 160 435 minecraft:light[level=14]
setblock 497 160 443 minecraft:light[level=14]
setblock 497 160 451 minecraft:light[level=14]
fill 499 160 450 500 160 450 minecraft:red_nether_bricks
fill 500 160 416 500 165 416 minecraft:red_nether_bricks
fill 501 160 416 502 160 416 minecraft:orange_concrete
fill 501 160 445 503 164 445 minecraft:red_nether_bricks
fill 503 160 416 503 165 416 minecraft:red_nether_bricks
fill 504 160 446 504 163 448 minecraft:red_nether_bricks
fill 504 160 458 505 160 458 minecraft:orange_concrete
fill 505 160 416 505 161 416 minecraft:orange_concrete
setblock 505 160 419 minecraft:light[level=14]
setblock 505 160 435 minecraft:light[level=14]
setblock 505 160 443 minecraft:light[level=14]
setblock 505 160 451 minecraft:light[level=14]
fill 506 160 458 507 165 458 minecraft:red_nether_bricks
fill 511 160 416 512 165 416 minecraft:red_nether_bricks
fill 512 160 417 512 161 418 minecraft:orange_concrete
setblock 512 160 426 minecraft:orange_concrete
fill 512 160 427 512 165 428 minecraft:red_nether_bricks
fill 512 160 429 512 161 430 minecraft:orange_concrete
fill 512 160 435 512 165 436 minecraft:red_nether_bricks
fill 512 160 437 512 160 438 minecraft:orange_concrete
fill 512 160 439 512 165 439 minecraft:red_nether_bricks
fill 512 160 447 512 165 448 minecraft:red_nether_bricks
fill 512 160 449 512 161 450 minecraft:orange_concrete
fill 512 160 456 512 165 456 minecraft:red_nether_bricks
setblock 470 161 416 minecraft:orange_concrete
fill 470 161 420 470 163 421 minecraft:red_nether_bricks
setblock 470 161 435 minecraft:red_nether_bricks
fill 470 161 436 470 161 437 minecraft:orange_concrete
setblock 470 161 440 minecraft:orange_concrete
fill 470 161 441 470 164 441 minecraft:red_nether_bricks
fill 470 161 452 470 164 452 minecraft:red_nether_bricks
setblock 470 161 457 minecraft:orange_concrete
setblock 476 161 446 minecraft:magma_block
setblock 476 161 448 minecraft:magma_block
fill 477 161 447 477 162 447 minecraft:magma_block
setblock 480 161 458 minecraft:orange_concrete
fill 481 161 416 481 164 416 minecraft:red_nether_bricks
setblock 482 161 416 minecraft:orange_concrete
fill 483 161 416 484 161 416 minecraft:red_nether_bricks
fill 484 161 458 485 164 458 minecraft:red_nether_bricks
setblock 485 161 416 minecraft:orange_concrete
fill 500 161 447 500 162 447 minecraft:red_nether_bricks
fill 500 161 449 502 161 449 minecraft:red_nether_bricks
fill 501 161 416 502 164 416 minecraft:red_nether_bricks
setblock 501 161 458 minecraft:orange_concrete
fill 502 161 444 504 166 444 minecraft:red_nether_bricks
fill 502 161 448 502 163 448 minecraft:red_nether_bricks
fill 504 161 445 504 167 445 minecraft:red_nether_bricks
setblock 504 161 458 minecraft:orange_concrete
fill 505 161 446 505 164 447 minecraft:red_nether_bricks
fill 505 161 458 505 164 458 minecraft:red_nether_bricks
setblock 506 161 416 minecraft:orange_concrete
fill 507 161 416 508 161 416 minecraft:red_nether_bricks
setblock 512 161 421 minecraft:orange_concrete
fill 512 161 426 512 164 426 minecraft:red_nether_bricks
fill 512 161 437 512 164 437 minecraft:red_nether_bricks
setblock 512 161 438 minecraft:orange_concrete
fill 512 161 441 512 161 442 minecraft:orange_concrete
setblock 512 161 458 minecraft:orange_concrete
fill 470 162 416 470 167 417 minecraft:red_nether_bricks
setblock 470 162 418 minecraft:orange_concrete
fill 470 162 419 471 162 419 minecraft:red_nether_bricks
fill 470 162 426 470 162 427 minecraft:orange_concrete
fill 470 162 428 471 162 429 minecraft:red_nether_bricks
fill 470 162 435 470 163 435 minecraft:orange_concrete
fill 470 162 436 471 162 437 minecraft:red_nether_bricks
setblock 470 162 438 minecraft:orange_concrete
fill 470 162 440 471 162 440 minecraft:red_nether_bricks
fill 470 162 446 470 163 447 minecraft:orange_concrete
fill 470 162 448 471 162 449 minecraft:red_nether_bricks
fill 470 162 457 471 162 457 minecraft:red_nether_bricks
fill 470 162 458 471 162 458 minecraft:orange_concrete
fill 471 162 417 473 162 417 minecraft:red_nether_bricks
fill 471 162 420 471 162 421 minecraft:red_nether_bricks
fill 471 162 423 471 162 425 minecraft:red_nether_bricks
setblock 471 162 427 minecraft:red_nether_bricks
fill 471 162 431 471 162 433 minecraft:red_nether_bricks
setblock 471 162 435 minecraft:red_nether_bricks
setblock 471 162 439 minecraft:red_nether_bricks
setblock 471 162 441 minecraft:red_nether_bricks
fill 471 162 443 471 162 445 minecraft:red_nether_bricks
setblock 471 162 447 minecraft:red_nether_bricks
fill 471 162 451 471 162 453 minecraft:red_nether_bricks
fill 471 162 455 471 162 456 minecraft:red_nether_bricks
setblock 472 162 447 minecraft:magma_block
fill 472 162 458 473 167 458 minecraft:red_nether_bricks
fill 473 162 416 474 167 416 minecraft:red_nether_bricks
fill 473 162 457 475 162 457 minecraft:red_nether_bricks
setblock 474 162 446 minecraft:magma_block
setblock 474 162 448 minecraft:magma_block
fill 475 162 416 476 163 416 minecraft:orange_concrete
fill 475 162 417 477 162 417 minecraft:red_nether_bricks
setblock 477 162 446 minecraft:magma_block
setblock 477 162 448 minecraft:magma_block
fill 477 162 457 479 162 457 minecraft:red_nether_bricks
fill 478 162 447 478 163 447 minecraft:magma_block
fill 478 162 458 479 163 458 minecraft:orange_concrete
fill 479 162 417 481 162 417 minecraft:red_nether_bricks
fill 480 162 458 481 167 458 minecraft:red_nether_bricks
fill 481 162 457 483 162 457 minecraft:red_nether_bricks
fill 482 162 416 482 167 416 minecraft:red_nether_bricks
setblock 482 162 458 minecraft:orange_concrete
fill 483 162 416 484 162 416 minecraft:orange_concrete
fill 483 162 417 485 162 417 minecraft:red_nether_bricks
fill 485 162 416 485 167 416 minecraft:red_nether_bricks
fill 485 162 457 487 162 457 minecraft:red_nether_bricks
fill 487 162 416 487 163 416 minecraft:orange_concrete
fill 487 162 417 489 162 417 minecraft:red_nether_bricks
fill 489 162 457 491 162 457 minecraft:red_nether_bricks
fill 490 162 458 491 163 458 minecraft:orange_concrete
fill 491 162 417 493 162 417 minecraft:red_nether_bricks
fill 492 162 458 493 167 458 minecraft:red_nether_bricks
fill 493 162 416 494 167 416 minecraft:red_nether_bricks
fill 493 162 457 495 162 457 minecraft:red_nether_bricks
fill 495 162 416 496 163 416 minecraft:orange_concrete
fill 495 162 417 497 162 417 minecraft:red_nether_bricks
fill 497 162 457 499 162 457 minecraft:red_nether_bricks
fill 499 162 417 501 162 417 minecraft:red_nether_bricks
fill 499 162 458 499 163 458 minecraft:orange_concrete
setblock 500 162 448 minecraft:red_nether_bricks
fill 501 162 449 502 162 449 minecraft:red_nether_bricks
fill 501 162 457 501 162 458 minecraft:red_nether_bricks
fill 502 162 457 503 162 457 minecraft:red_nether_bricks
fill 502 162 458 503 162 458 minecraft:orange_concrete
fill 503 162 417 505 162 417 minecraft:red_nether_bricks
fill 503 162 443 504 168 443 minecraft:red_nether_bricks
setblock 504 162 416 minecraft:orange_concrete
fill 504 162 458 504 167 458 minecraft:red_nether_bricks
fill 505 162 416 506 167 416 minecraft:red_nether_bricks
fill 505 162 444 505 167 445 minecraft:red_nether_bricks
fill 505 162 457 507 162 457 minecraft:red_nether_bricks
fill 507 162 416 508 163 416 minecraft:orange_concrete
fill 507 162 417 509 162 417 minecraft:red_nether_bricks
fill 509 162 457 511 162 457 minecraft:red_nether_bricks
fill 510 162 458 511 163 458 minecraft:orange_concrete
fill 511 162 417 511 162 419 minecraft:red_nether_bricks
fill 511 162 421 511 162 423 minecraft:red_nether_bricks
fill 511 162 425 511 162 427 minecraft:red_nether_bricks
fill 511 162 429 511 162 431 minecraft:red_nether_bricks
fill 511 162 433 511 162 435 minecraft:red_nether_bricks
fill 511 162 437 511 162 439 minecraft:red_nether_bricks
fill 511 162 441 511 162 443 minecraft:red_nether_bricks
fill 511 162 445 511 162 447 minecraft:red_nether_bricks
fill 511 162 449 511 162 451 minecraft:red_nether_bricks
fill 511 162 453 511 162 455 minecraft:red_nether_bricks
fill 512 162 417 512 167 418 minecraft:red_nether_bricks
fill 512 162 419 512 162 420 minecraft:orange_concrete
fill 512 162 421 512 167 421 minecraft:red_nether_bricks
fill 512 162 429 512 167 430 minecraft:red_nether_bricks
fill 512 162 431 512 163 432 minecraft:orange_concrete
fill 512 162 438 512 167 438 minecraft:red_nether_bricks
setblock 512 162 440 minecraft:orange_concrete
fill 512 162 441 512 167 442 minecraft:red_nether_bricks
fill 512 162 443 512 163 443 minecraft:orange_concrete
fill 512 162 449 512 167 450 minecraft:red_nether_bricks
fill 512 162 451 512 162 452 minecraft:orange_concrete
fill 512 162 458 512 167 458 minecraft:red_nether_bricks
fill 470 163 418 470 165 419 minecraft:red_nether_bricks
setblock 470 163 423 minecraft:orange_concrete
setblock 470 163 426 minecraft:orange_concrete
fill 470 163 427 470 166 429 minecraft:red_nether_bricks
setblock 470 163 434 minecraft:orange_concrete
fill 470 163 436 470 166 438 minecraft:red_nether_bricks
fill 470 163 440 470 167 440 minecraft:red_nether_bricks
fill 470 163 448 470 167 449 minecraft:red_nether_bricks
fill 470 163 454 470 163 455 minecraft:orange_concrete
fill 470 163 457 470 167 457 minecraft:red_nether_bricks
setblock 470 163 458 minecraft:orange_concrete
fill 471 163 458 471 166 458 minecraft:red_nether_bricks
fill 482 163 458 482 166 458 minecraft:red_nether_bricks
fill 483 163 416 484 165 416 minecraft:red_nether_bricks
setblock 487 163 458 minecraft:orange_concrete
setblock 488 163 416 minecraft:orange_concrete
setblock 498 163 458 minecraft:orange_concrete
setblock 499 163 416 minecraft:orange_concrete
setblock 501 163 444 minecraft:red_nether_bricks
fill 501 163 446 502 164 446 minecraft:red_nether_bricks
fill 501 163 458 503 166 458 minecraft:red_nether_bricks
fill 502 163 443 502 166 443 minecraft:red_nether_bricks
fill 504 163 416 504 166 416 minecraft:red_nether_bricks
fill 505 163 443 505 170 443 minecraft:red_nether_bricks
fill 506 163 444 506 166 445 minecraft:red_nether_bricks
fill 512 163 419 512 166 419 minecraft:red_nether_bricks
setblock 512 163 420 minecraft:orange_concrete
fill 512 163 423 512 163 424 minecraft:orange_concrete
fill 512 163 440 512 166 440 minecraft:red_nether_bricks
setblock 512 163 444 minecraft:orange_concrete
fill 512 163 451 512 166 451 minecraft:red_nether_bricks
setblock 512 163 452 minecraft:orange_concrete
setblock 512 163 455 minecraft:orange_concrete
setblock 470 164 420 minecraft:red_nether_bricks
fill 470 164 421 470 165 421 minecraft:orange_concrete
fill 470 164 423 470 169 423 minecraft:red_nether_bricks
fill 470 164 424 470 164 425 minecraft:orange_concrete
fill 470 164 426 470 169 426 minecraft:red_nether_bricks
fill 470 164 432 470 165 433 minecraft:orange_concrete
fill 470 164 434 470 169 435 minecraft:red_nether_bricks
fill 470 164 444 470 164 445 minecraft:orange_concrete
fill 470 164 446 470 169 447 minecraft:red_nether_bricks
fill 470 164 453 470 165 453 minecraft:orange_concrete
fill 470 164 454 470 169 455 minecraft:red_nether_bricks
setblock 470 164 456 minecraft:orange_concrete
fill 470 164 458 470 169 458 minecraft:red_nether_bricks
fill 475 164 416 476 169 416 minecraft:red_nether_bricks
fill 476 164 458 477 165 458 minecraft:orange_concrete
fill 477 164 416 478 165 416 minecraft:orange_concrete
fill 478 164 458 479 169 458 minecraft:red_nether_bricks
fill 481 164 447 482 165 448 minecraft:magma_block
fill 482 164 446 482 165 446 minecraft:magma_block
setblock 486 164 416 minecraft:orange_concrete
fill 487 164 416 488 169 416 minecraft:red_nether_bricks
fill 487 164 458 487 169 458 minecraft:red_nether_bricks
fill 488 164 458 489 164 458 minecraft:orange_concrete
fill 489 164 416 490 165 416 minecraft:orange_concrete
fill 490 164 458 491 169 458 minecraft:red_nether_bricks
fill 495 164 416 496 169 416 minecraft:red_nether_bricks
fill 496 164 458 497 165 458 minecraft:orange_concrete
fill 497 164 416 498 164 416 minecraft:orange_concrete
fill 498 164 458 499 169 458 minecraft:red_nether_bricks
fill 499 164 416 499 169 416 minecraft:red_nether_bricks
setblock 500 164 458 minecraft:orange_concrete
fill 502 164 447 504 164 447 minecraft:red_nether_bricks
fill 503 164 442 505 169 442 minecraft:red_nether_bricks
fill 504 164 446 504 166 446 minecraft:red_nether_bricks
fill 506 164 443 506 169 443 minecraft:red_nether_bricks
fill 507 164 416 508 169 416 minecraft:red_nether_bricks
fill 508 164 458 509 165 458 minecraft:orange_concrete
fill 509 164 416 510 165 416 minecraft:orange_concrete
fill 510 164 458 511 169 458 minecraft:red_nether_bricks
fill 512 164 420 512 169 420 minecraft:red_nether_bricks
setblock 512 164 422 minecraft:orange_concrete
fill 512 164 423 512 169 424 minecraft:red_nether_bricks
fill 512 164 425 512 165 425 minecraft:orange_concrete
fill 512 164 431 512 169 432 minecraft:red_nether_bricks
fill 512 164 433 512 164 434 minecraft:orange_concrete
fill 512 164 443 512 169 444 minecraft:red_nether_bricks
fill 512 164 445 512 165 446 minecraft:orange_concrete
fill 512 164 452 512 169 452 minecraft:red_nether_bricks
fill 512 164 453 512 164 454 minecraft:orange_concrete
fill 512 164 455 512 169 455 minecraft:red_nether_bricks
fill 512 164 457 512 165 457 minecraft:orange_concrete
setblock 470 165 420 minecraft:orange_concrete
fill 470 165 424 470 168 425 minecraft:red_nether_bricks
setblock 470 165 441 minecraft:orange_concrete
setblock 470 165 444 minecraft:orange_concrete
fill 470 165 445 470 168 445 minecraft:red_nether_bricks
setblock 470 165 452 minecraft:orange_concrete
fill 470 165 456 470 168 456 minecraft:red_nether_bricks
setblock 481 165 416 minecraft:orange_concrete
fill 484 165 458 485 165 458 minecraft:orange_concrete
fill 486 165 416 486 167 416 minecraft:red_nether_bricks
setblock 488 165 458 minecraft:orange_concrete
fill 489 165 458 489 168 458 minecraft:red_nether_bricks
fill 497 165 416 497 168 416 minecraft:red_nether_bricks
setblock 498 165 416 minecraft:orange_concrete
fill 499 165 447 501 166 447 minecraft:shroomlight
fill 500 165 446 501 166 446 minecraft:shroomlight
fill 500 165 458 500 168 458 minecraft:red_nether_bricks
fill 501 165 416 502 165 416 minecraft:orange_concrete
fill 502 165 445 502 165 446 minecraft:red_nether_bricks
fill 502 165 447 502 167 447 minecraft:magma_block
fill 503 165 445 503 167 445 minecraft:red_nether_bricks
fill 503 165 447 504 165 447 minecraft:red_nether_bricks
fill 504 165 441 506 171 441 minecraft:red_nether_bricks
fill 505 165 446 505 166 446 minecraft:red_nether_bricks
setblock 505 165 458 minecraft:orange_concrete
fill 506 165 442 506 171 442 minecraft:red_nether_bricks
fill 507 165 443 507 168 443 minecraft:red_nether_bricks
fill 512 165 422 512 168 422 minecraft:red_nether_bricks
setblock 512 165 426 minecraft:orange_concrete
fill 512 165 433 512 168 433 minecraft:red_nether_bricks
setblock 512 165 434 minecraft:orange_concrete
setblock 512 165 437 minecraft:orange_concrete
fill 512 165 453 512 168 454 minecraft:red_nether_bricks
fill 470 166 418 470 167 419 minecraft:orange_concrete
fill 470 166 420 470 171 421 minecraft:red_nether_bricks
setblock 470 166 422 minecraft:orange_concrete
fill 470 166 430 470 167 431 minecraft:orange_concrete
fill 470 166 432 470 171 433 minecraft:red_nether_bricks
fill 470 166 439 470 167 439 minecraft:orange_concrete
fill 470 166 441 470 171 441 minecraft:red_nether_bricks
fill 470 166 442 470 166 443 minecraft:orange_concrete
fill 470 166 444 470 171 444 minecraft:red_nether_bricks
fill 470 166 450 470 167 451 minecraft:orange_concrete
fill 470 166 452 470 171 453 minecraft:red_nether_bricks
fill 471 166 416 472 167 416 minecraft:orange_concrete
fill 474 166 458 475 166 458 minecraft:orange_concrete
fill 476 166 458 477 171 458 minecraft:red_nether_bricks
fill 477 166 416 478 168 416 minecraft:red_nether_bricks
fill 479 166 416 480 166 416 minecraft:orange_concrete
fill 481 166 416 481 171 416 minecraft:red_nether_bricks
fill 483 166 416 483 167 416 minecraft:orange_concrete
fill 483 166 458 483 167 458 minecraft:orange_concrete
setblock 484 166 416 minecraft:red_nether_bricks
fill 484 166 458 485 171 458 minecraft:red_nether_bricks
setblock 486 166 458 minecraft:orange_concrete
fill 488 166 458 488 171 458 minecraft:red_nether_bricks
fill 489 166 416 490 171 416 minecraft:red_nether_bricks
fill 491 166 416 492 167 416 minecraft:orange_concrete
fill 494 166 458 495 167 458 minecraft:orange_concrete
fill 496 166 458 497 171 458 minecraft:red_nether_bricks
fill 498 166 416 498 171 416 minecraft:red_nether_bricks
fill 499 166 436 501 167 436 minecraft:netherrack
setblock 500 166 416 minecraft:orange_concrete
fill 500 166 435 500 167 435 minecraft:netherrack
fill 500 166 437 500 167 437 minecraft:netherrack
fill 501 166 416 502 171 416 minecraft:red_nether_bricks
setblock 502 166 445 minecraft:red_nether_bricks
fill 503 166 416 503 167 416 minecraft:orange_concrete
fill 503 166 441 503 169 441 minecraft:red_nether_bricks
fill 503 166 447 503 167 447 minecraft:magma_block
fill 504 166 440 506 172 440 minecraft:red_nether_bricks
fill 505 166 458 505 171 458 minecraft:red_nether_bricks
fill 506 166 458 507 166 458 minecraft:orange_concrete
fill 507 166 441 507 170 442 minecraft:red_nether_bricks
fill 507 166 444 507 167 444 minecraft:red_nether_bricks
fill 508 166 458 509 171 458 minecraft:red_nether_bricks
fill 509 166 416 510 171 416 minecraft:red_nether_bricks
fill 511 166 416 512 166 416 minecraft:orange_concrete
fill 512 166 425 512 171 426 minecraft:red_nether_bricks
fill 512 166 427 512 167 428 minecraft:orange_concrete
fill 512 166 434 512 171 434 minecraft:red_nether_bricks
fill 512 166 435 512 166 436 minecraft:orange_concrete
fill 512 166 437 512 171 437 minecraft:red_nether_bricks
fill 512 166 439 512 167 439 minecraft:orange_concrete
fill 512 166 445 512 171 446 minecraft:red_nether_bricks
fill 512 166 447 512 167 448 minecraft:orange_concrete
setblock 512 166 456 minecraft:orange_concrete
fill 512 166 457 512 171 457 minecraft:red_nether_bricks
fill 470 167 422 470 170 422 minecraft:red_nether_bricks
setblock 470 167 427 minecraft:orange_concrete
fill 470 167 428 470 167 429 minecraft:red_nether_bricks
fill 470 167 436 470 167 437 minecraft:red_nether_bricks
setblock 470 167 438 minecraft:orange_concrete
fill 470 167 442 470 170 443 minecraft:red_nether_bricks
setblock 471 167 458 minecraft:orange_concrete
setblock 474 167 458 minecraft:orange_concrete
fill 475 167 458 475 170 458 minecraft:red_nether_bricks
fill 479 167 416 479 170 416 minecraft:red_nether_bricks
setblock 480 167 416 minecraft:orange_concrete
setblock 482 167 458 minecraft:orange_concrete
setblock 484 167 416 minecraft:orange_concrete
fill 486 167 458 486 170 458 minecraft:red_nether_bricks
fill 500 167 416 500 170 416 minecraft:red_nether_bricks
setblock 501 167 458 minecraft:red_nether_bricks
fill 502 167 458 503 167 458 minecraft:orange_concrete
fill 503 167 444 504 167 444 minecraft:red_nether_bricks
setblock 504 167 416 minecraft:orange_concrete
fill 505 167 439 506 174 439 minecraft:red_nether_bricks
fill 506 167 444 506 168 444 minecraft:red_nether_bricks
setblock 506 167 458 minecraft:orange_concrete
fill 507 167 440 507 172 440 minecraft:red_nether_bricks
fill 507 167 458 507 170 458 minecraft:red_nether_bricks
fill 511 167 416 511 170 416 minecraft:red_nether_bricks
setblock 512 167 416 minecraft:orange_concrete
setblock 512 167 419 minecraft:orange_concrete
fill 512 167 435 512 170 436 minecraft:red_nether_bricks
setblock 512 167 440 minecraft:orange_concrete
setblock 512 167 451 minecraft:orange_concrete
fill 512 167 456 512 170 456 minecraft:red_nether_bricks
fill 470 168 416 470 169 417 minecraft:orange_concrete
fill 470 168 418 470 173 419 minecraft:red_nether_bricks
fill 470 168 427 471 168 427 minecraft:red_nether_bricks
fill 470 168 428 470 168 429 minecraft:orange_concrete
fill 470 168 430 470 173 431 minecraft:red_nether_bricks
fill 470 168 436 470 169 437 minecraft:orange_concrete
fill 470 168 438 470 173 439 minecraft:red_nether_bricks
setblock 470 168 440 minecraft:orange_concrete
fill 470 168 448 470 169 449 minecraft:orange_concrete
fill 470 168 450 470 173 451 minecraft:red_nether_bricks
fill 470 168 457 470 169 457 minecraft:orange_concrete
fill 471 168 416 472 168 417 minecraft:red_nether_bricks
fill 471 168 419 471 168 421 minecraft:red_nether_bricks
fill 471 168 423 471 168 425 minecraft:red_nether_bricks
fill 471 168 428 471 168 429 minecraft:red_nether_bricks
fill 471 168 431 471 168 433 minecraft:red_nether_bricks
fill 471 168 435 471 168 437 minecraft:red_nether_bricks
fill 471 168 439 471 168 441 minecraft:red_nether_bricks
fill 471 168 443 471 168 445 minecraft:red_nether_bricks
fill 471 168 447 471 168 449 minecraft:red_nether_bricks
fill 471 168 451 471 168 453 minecraft:red_nether_bricks
fill 471 168 455 471 168 458 minecraft:red_nether_bricks
fill 472 168 458 473 168 458 minecraft:orange_concrete
fill 473 168 416 474 169 416 minecraft:orange_concrete
setblock 473 168 417 minecraft:red_nether_bricks
setblock 473 168 419 minecraft:light[level=14]
setblock 473 168 427 minecraft:light[level=14]
setblock 473 168 435 minecraft:light[level=14]
setblock 473 168 443 minecraft:light[level=14]
setblock 473 168 451 minecraft:light[level=14]
fill 473 168 457 475 168 457 minecraft:red_nether_bricks
fill 474 168 458 474 173 458 minecraft:red_nether_bricks
fill 475 168 417 477 168 417 minecraft:red_nether_bricks
fill 477 168 457 479 168 457 minecraft:red_nether_bricks
fill 479 168 417 481 168 417 minecraft:red_nether_bricks
fill 480 168 416 480 170 416 minecraft:red_nether_bricks
fill 480 168 458 481 169 458 minecraft:orange_concrete
setblock 481 168 419 minecraft:light[level=14]
setblock 481 168 427 minecraft:light[level=14]
setblock 481 168 435 minecraft:light[level=14]
setblock 481 168 443 minecraft:light[level=14]
setblock 481 168 451 minecraft:light[level=14]
fill 481 168 457 483 168 457 minecraft:red_nether_bricks
setblock 482 168 416 minecraft:orange_concrete
fill 482 168 458 483 173 458 minecraft:red_nether_bricks
fill 483 168 416 484 168 417 minecraft:red_nether_bricks
fill 485 168 416 486 169 416 minecraft:orange_concrete
setblock 485 168 417 minecraft:red_nether_bricks
fill 485 168 457 487 168 457 minecraft:red_nether_bricks
fill 487 168 417 489 168 417 minecraft:red_nether_bricks
setblock 489 168 419 minecraft:light[level=14]
setblock 489 168 427 minecraft:light[level=14]
setblock 489 168 435 minecraft:light[level=14]
setblock 489 168 443 minecraft:light[level=14]
setblock 489 168 451 minecraft:light[level=14]
fill 489 168 457 491 168 457 minecraft:red_nether_bricks
fill 491 168 416 492 168 417 minecraft:red_nether_bricks
fill 492 168 458 493 168 458 minecraft:orange_concrete
fill 493 168 416 494 168 416 minecraft:orange_concrete
setblock 493 168 417 minecraft:red_nether_bricks
fill 493 168 457 495 168 457 minecraft:red_nether_bricks
fill 494 168 458 495 173 458 minecraft:red_nether_bricks
fill 495 168 417 497 168 417 minecraft:red_nether_bricks
setblock 497 168 419 minecraft:light[level=14]
setblock 497 168 427 minecraft:light[level=14]
setblock 497 168 435 minecraft:light[level=14]
setblock 497 168 443 minecraft:light[level=14]
setblock 497 168 451 minecraft:light[level=14]
fill 497 168 457 499 168 457 minecraft:red_nether_bricks
fill 499 168 417 501 168 417 minecraft:red_nether_bricks
fill 501 168 457 503 168 457 minecraft:red_nether_bricks
fill 501 168 458 501 169 458 minecraft:orange_concrete
fill 502 168 458 503 173 458 minecraft:red_nether_bricks
fill 503 168 416 504 168 417 minecraft:red_nether_bricks
fill 503 168 440 503 170 440 minecraft:red_nether_bricks
fill 504 168 439 504 173 439 minecraft:red_nether_bricks
fill 504 168 444 505 168 444 minecraft:red_nether_bricks
setblock 504 168 458 minecraft:orange_concrete
fill 505 168 416 506 169 416 minecraft:orange_concrete
setblock 505 168 417 minecraft:red_nether_bricks
setblock 505 168 419 minecraft:light[level=14]
setblock 505 168 435 minecraft:light[level=14]
fill 505 168 438 506 175 438 minecraft:red_nether_bricks
setblock 505 168 451 minecraft:light[level=14]
fill 505 168 457 507 168 457 minecraft:red_nether_bricks
fill 506 168 458 506 173 458 minecraft:red_nether_bricks
fill 507 168 417 509 168 417 minecraft:red_nether_bricks
fill 507 168 439 507 174 439 minecraft:red_nether_bricks
fill 509 168 457 511 168 457 minecraft:red_nether_bricks
fill 511 168 417 511 168 419 minecraft:red_nether_bricks
fill 511 168 421 511 168 423 minecraft:red_nether_bricks
fill 511 168 425 511 168 427 minecraft:red_nether_bricks
fill 511 168 429 511 168 431 minecraft:red_nether_bricks
fill 511 168 433 511 168 435 minecraft:red_nether_bricks
fill 511 168 437 511 168 439 minecraft:red_nether_bricks
fill 511 168 441 511 168 443 minecraft:red_nether_bricks
fill 511 168 445 511 168 447 minecraft:red_nether_bricks
fill 511 168 449 511 168 451 minecraft:red_nether_bricks
fill 511 168 453 511 168 455 minecraft:red_nether_bricks
fill 512 168 416 512 173 416 minecraft:red_nether_bricks
fill 512 168 417 512 168 418 minecraft:orange_concrete
fill 512 168 419 512 173 419 minecraft:red_nether_bricks
fill 512 168 421 512 169 421 minecraft:orange_concrete
fill 512 168 427 512 173 428 minecraft:red_nether_bricks
fill 512 168 429 512 169 430 minecraft:orange_concrete
setblock 512 168 438 minecraft:orange_concrete
fill 512 168 439 512 173 440 minecraft:red_nether_bricks
fill 512 168 441 512 169 442 minecraft:orange_concrete
fill 512 168 447 512 173 448 minecraft:red_nether_bricks
fill 512 168 449 512 168 450 minecraft:orange_concrete
fill 512 168 451 512 173 451 minecraft:red_nether_bricks
fill 512 168 458 512 169 458 minecraft:orange_concrete
fill 470 169 424 470 169 425 minecraft:orange_concrete
fill 470 169 427 470 173 427 minecraft:red_nether_bricks
setblock 470 169 428 minecraft:orange_concrete
fill 470 169 429 470 172 429 minecraft:red_nether_bricks
fill 470 169 440 470 172 440 minecraft:red_nether_bricks
setblock 470 169 445 minecraft:orange_concrete
setblock 470 169 456 minecraft:orange_concrete
fill 471 169 416 472 173 416 minecraft:red_nether_bricks
fill 471 169 458 473 172 458 minecraft:red_nether_bricks
setblock 477 169 416 minecraft:orange_concrete
fill 478 169 416 478 171 416 minecraft:red_nether_bricks
fill 482 169 416 484 172 416 minecraft:red_nether_bricks
setblock 489 169 458 minecraft:orange_concrete
fill 491 169 416 493 172 416 minecraft:red_nether_bricks
setblock 492 169 458 minecraft:orange_concrete
fill 493 169 458 493 172 458 minecraft:red_nether_bricks
setblock 494 169 416 minecraft:orange_concrete
setblock 497 169 416 minecraft:orange_concrete
setblock 500 169 458 minecraft:orange_concrete
fill 503 169 416 504 173 416 minecraft:red_nether_bricks
fill 504 169 438 504 174 438 minecraft:red_nether_bricks
setblock 504 169 443 minecraft:red_nether_bricks
fill 504 169 458 504 172 458 minecraft:red_nether_bricks
fill 506 169 437 506 176 437 minecraft:red_nether_bricks
fill 507 169 438 507 175 438 minecraft:red_nether_bricks
fill 508 169 440 508 171 440 minecraft:red_nether_bricks
fill 512 169 417 512 172 418 minecraft:red_nether_bricks
setblock 512 169 422 minecraft:orange_concrete
setblock 512 169 433 minecraft:orange_concrete
fill 512 169 438 512 172 438 minecraft:red_nether_bricks
fill 512 169 449 512 172 449 minecraft:red_nether_bricks
setblock 512 169 450 minecraft:orange_concrete
fill 512 169 453 512 169 454 minecraft:orange_concrete
fill 470 170 416 470 175 417 minecraft:red_nether_bricks
fill 470 170 423 470 171 423 minecraft:orange_concrete
fill 470 170 424 470 175 425 minecraft:red_nether_bricks
setblock 470 170 426 minecraft:orange_concrete
fill 470 170 428 470 175 428 minecraft:red_nether_bricks
fill 470 170 434 470 171 435 minecraft:orange_concrete
fill 470 170 436 470 175 437 minecraft:red_nether_bricks
fill 470 170 445 470 175 445 minecraft:red_nether_bricks
fill 470 170 446 470 170 447 minecraft:orange_concrete
fill 470 170 448 470 175 449 minecraft:red_nether_bricks
fill 470 170 454 470 171 455 minecraft:orange_concrete
fill 470 170 456 470 175 457 minecraft:red_nether_bricks
setblock 470 170 458 minecraft:orange_concrete
fill 473 170 416 474 175 416 minecraft:red_nether_bricks
fill 475 170 416 476 170 416 minecraft:orange_concrete
fill 477 170 416 477 171 416 minecraft:red_nether_bricks
fill 478 170 458 479 171 458 minecraft:orange_concrete
fill 480 170 458 481 175 458 minecraft:red_nether_bricks
fill 485 170 416 486 175 416 minecraft:red_nether_bricks
fill 487 170 416 488 171 416 minecraft:orange_concrete
fill 487 170 458 487 171 458 minecraft:orange_concrete
fill 489 170 458 489 175 458 minecraft:red_nether_bricks
fill 490 170 458 491 170 458 minecraft:orange_concrete
fill 492 170 458 492 175 458 minecraft:red_nether_bricks
fill 494 170 416 494 175 416 minecraft:red_nether_bricks
fill 495 170 416 496 170 416 minecraft:orange_concrete
fill 497 170 416 497 175 416 minecraft:red_nether_bricks
fill 498 170 458 499 171 458 minecraft:orange_concrete
fill 499 170 416 499 171 416 minecraft:orange_concrete
fill 500 170 458 501 175 458 minecraft:red_nether_bricks
fill 504 170 437 505 175 437 minecraft:red_nether_bricks
fill 504 170 442 505 170 442 minecraft:red_nether_bricks
fill 505 170 416 506 175 416 minecraft:red_nether_bricks
fill 507 170 416 508 171 416 minecraft:orange_concrete
fill 507 170 437 507 176 437 minecraft:red_nether_bricks
fill 508 170 438 508 172 439 minecraft:red_nether_bricks
fill 510 170 458 511 170 458 minecraft:orange_concrete
setblock 512 170 420 minecraft:orange_concrete
fill 512 170 421 512 175 422 minecraft:red_nether_bricks
fill 512 170 423 512 171 424 minecraft:orange_concrete
fill 512 170 429 512 175 430 minecraft:red_nether_bricks
fill 512 170 431 512 170 432 minecraft:orange_concrete
fill 512 170 433 512 175 433 minecraft:red_nether_bricks
fill 512 170 441 512 175 442 minecraft:red_nether_bricks
fill 512 170 443 512 171 444 minecraft:orange_concrete
fill 512 170 450 512 175 450 minecraft:red_nether_bricks
setblock 512 170 452 minecraft:orange_concrete
fill 512 170 453 512 175 454 minecraft:red_nether_bricks
fill 512 170 455 512 171 455 minecraft:orange_concrete
fill 512 170 458 512 175 458 minecraft:red_nether_bricks
setblock 470 171 422 minecraft:orange_concrete
fill 470 171 426 470 174 426 minecraft:red_nether_bricks
fill 470 171 442 470 171 443 minecraft:orange_concrete
setblock 470 171 446 minecraft:orange_concrete
fill 470 171 447 470 174 447 minecraft:red_nether_bricks
fill 470 171 458 470 174 458 minecraft:red_nether_bricks
fill 475 171 416 475 174 416 minecraft:red_nether_bricks
setblock 475 171 458 minecraft:orange_concrete
setblock 476 171 416 minecraft:orange_concrete
fill 479 171 416 480 171 416 minecraft:orange_concrete
setblock 486 171 458 minecraft:orange_concrete
fill 490 171 458 491 174 458 minecraft:red_nether_bricks
fill 495 171 416 496 173 416 minecraft:red_nether_bricks
fill 498 171 452 498 172 453 minecraft:netherrack
setblock 500 171 416 minecraft:orange_concrete
fill 505 171 436 507 177 436 minecraft:red_nether_bricks
setblock 505 171 442 minecraft:red_nether_bricks
setblock 507 171 441 minecraft:red_nether_bricks
setblock 507 171 458 minecraft:orange_concrete
fill 508 171 437 508 174 437 minecraft:red_nether_bricks
setblock 510 171 458 minecraft:orange_concrete
setblock 511 171 416 minecraft:orange_concrete
fill 511 171 458 511 174 458 minecraft:red_nether_bricks
fill 512 171 420 512 174 420 minecraft:red_nether_bricks
fill 512 171 431 512 174 431 minecraft:red_nether_bricks
setblock 512 171 432 minecraft:orange_concrete
fill 512 171 435 512 171 436 minecraft:orange_concrete
fill 512 171 452 512 174 452 minecraft:red_nether_bricks
setblock 512 171 456 minecraft:orange_concrete
fill 470 172 420 470 173 421 minecraft:orange_concrete
fill 470 172 422 470 177 423 minecraft:red_nether_bricks
fill 470 172 432 470 172 433 minecraft:orange_concrete
fill 470 172 434 470 177 435 minecraft:red_nether_bricks
fill 470 172 441 470 173 441 minecraft:orange_concrete
fill 470 172 442 470 177 443 minecraft:red_nether_bricks
setblock 470 172 444 minecraft:orange_concrete
fill 470 172 446 470 177 446 minecraft:red_nether_bricks
fill 470 172 452 470 173 453 minecraft:orange_concrete
fill 470 172 454 470 177 455 minecraft:red_nether_bricks
fill 475 172 458 475 177 458 minecraft:red_nether_bricks
fill 476 172 416 476 177 416 minecraft:red_nether_bricks
fill 476 172 458 477 172 458 minecraft:orange_concrete
fill 477 172 416 478 172 416 minecraft:orange_concrete
fill 478 172 458 479 177 458 minecraft:red_nether_bricks
fill 479 172 416 480 173 416 minecraft:red_nether_bricks
fill 481 172 416 481 173 416 minecraft:orange_concrete
fill 484 172 458 485 173 458 minecraft:orange_concrete
fill 486 172 458 487 177 458 minecraft:red_nether_bricks
fill 487 172 416 488 177 416 minecraft:red_nether_bricks
setblock 488 172 458 minecraft:orange_concrete
fill 489 172 416 490 173 416 minecraft:orange_concrete
fill 496 172 458 497 173 458 minecraft:orange_concrete
setblock 498 172 416 minecraft:orange_concrete
fill 498 172 458 499 177 458 minecraft:red_nether_bricks
fill 499 172 416 500 177 416 minecraft:red_nether_bricks
fill 501 172 416 502 173 416 minecraft:orange_concrete
fill 504 172 436 504 176 436 minecraft:red_nether_bricks
fill 505 172 435 507 178 435 minecraft:red_nether_bricks
fill 505 172 441 506 172 441 minecraft:red_nether_bricks
fill 505 172 458 505 173 458 minecraft:orange_concrete
fill 507 172 416 508 177 416 minecraft:red_nether_bricks
fill 507 172 458 507 177 458 minecraft:red_nether_bricks
fill 508 172 436 508 175 436 minecraft:red_nether_bricks
fill 508 172 458 509 172 458 minecraft:orange_concrete
fill 509 172 416 510 172 416 minecraft:orange_concrete
fill 510 172 458 510 177 458 minecraft:red_nether_bricks
fill 511 172 416 511 177 416 minecraft:red_nether_bricks
fill 512 172 423 512 177 424 minecraft:red_nether_bricks
fill 512 172 425 512 173 426 minecraft:orange_concrete
fill 512 172 432 512 177 432 minecraft:red_nether_bricks
setblock 512 172 434 minecraft:orange_concrete
fill 512 172 435 512 177 436 minecraft:red_nether_bricks
fill 512 172 437 512 173 437 minecraft:orange_concrete
fill 512 172 443 512 177 444 minecraft:red_nether_bricks
fill 512 172 445 512 172 446 minecraft:orange_concrete
fill 512 172 455 512 177 456 minecraft:red_nether_bricks
fill 512 172 457 512 173 457 minecraft:orange_concrete
setblock 470 173 429 minecraft:orange_concrete
setblock 470 173 432 minecraft:orange_concrete
fill 470 173 433 470 176 433 minecraft:red_nether_bricks
setblock 470 173 440 minecraft:orange_concrete
fill 470 173 444 470 176 444 minecraft:red_nether_bricks
setblock 471 173 458 minecraft:red_nether_bricks
fill 472 173 458 473 173 458 minecraft:orange_concrete
setblock 476 173 458 minecraft:orange_concrete
fill 477 173 416 478 175 416 minecraft:red_nether_bricks
fill 477 173 458 477 176 458 minecraft:red_nether_bricks
setblock 482 173 416 minecraft:orange_concrete
fill 483 173 416 484 173 416 minecraft:red_nether_bricks
fill 488 173 458 488 176 458 minecraft:red_nether_bricks
fill 491 173 416 492 173 416 minecraft:red_nether_bricks
setblock 493 173 416 minecraft:orange_concrete
setblock 493 173 458 minecraft:orange_concrete
fill 498 173 416 498 175 416 minecraft:red_nether_bricks
fill 504 173 435 504 178 435 minecraft:red_nether_bricks
setblock 504 173 458 minecraft:orange_concrete
fill 505 173 434 507 178 434 minecraft:red_nether_bricks
fill 505 173 440 506 173 440 minecraft:red_nether_bricks
fill 508 173 435 508 176 435 minecraft:red_nether_bricks
fill 508 173 438 508 174 438 minecraft:red_nether_bricks
fill 508 173 458 509 176 458 minecraft:red_nether_bricks
fill 509 173 416 509 176 416 minecraft:red_nether_bricks
setblock 510 173 416 minecraft:orange_concrete
fill 512 173 417 512 173 418 minecraft:orange_concrete
fill 512 173 434 512 176 434 minecraft:red_nether_bricks
setblock 512 173 438 minecraft:orange_concrete
fill 512 173 445 512 176 445 minecraft:red_nether_bricks
setblock 512 173 446 minecraft:orange_concrete
setblock 512 173 449 minecraft:orange_concrete
fill 470 174 418 470 175 419 minecraft:orange_concrete
fill 470 174 420 471 174 421 minecraft:red_nether_bricks
fill 470 174 427 470 175 427 minecraft:orange_concrete
fill 470 174 429 471 174 429 minecraft:red_nether_bricks
fill 470 174 430 470 174 431 minecraft:orange_concrete
fill 470 174 432 471 174 432 minecraft:red_nether_bricks
fill 470 174 438 470 175 439 minecraft:orange_concrete
fill 470 174 440 471 174 441 minecraft:red_nether_bricks
fill 470 174 450 470 174 451 minecraft:orange_concrete
fill 470 174 452 471 174 453 minecraft:red_nether_bricks
fill 471 174 416 472 175 416 minecraft:orange_concrete
fill 471 174 417 473 174 417 minecraft:red_nether_bricks
setblock 471 174 419 minecraft:red_nether_bricks
fill 471 174 423 471 174 425 minecraft:red_nether_bricks
fill 471 174 427 471 174 428 minecraft:red_nether_bricks
setblock 471 174 431 minecraft:red_nether_bricks
setblock 471 174 433 minecraft:red_nether_bricks
fill 471 174 435 471 174 437 minecraft:red_nether_bricks
setblock 471 174 439 minecraft:red_nether_bricks
fill 471 174 443 471 174 445 minecraft:red_nether_bricks
fill 471 174 447 471 174 449 minecraft:red_nether_bricks
setblock 471 174 451 minecraft:red_nether_bricks
fill 471 174 455 471 174 457 minecraft:red_nether_bricks
fill 471 174 458 471 175 458 minecraft:orange_concrete
fill 472 174 458 473 179 458 minecraft:red_nether_bricks
fill 473 174 457 475 174 457 minecraft:red_nether_bricks
setblock 474 174 458 minecraft:orange_concrete
fill 475 174 417 477 174 417 minecraft:red_nether_bricks
fill 476 174 458 476 179 458 minecraft:red_nether_bricks
fill 477 174 457 479 174 457 minecraft:red_nether_bricks
fill 479 174 416 479 174 417 minecraft:red_nether_bricks
setblock 480 174 416 minecraft:orange_concrete
fill 480 174 417 481 174 417 minecraft:red_nether_bricks
fill 481 174 416 482 179 416 minecraft:red_nether_bricks
fill 481 174 457 483 174 457 minecraft:red_nether_bricks
fill 482 174 458 483 175 458 minecraft:orange_concrete
fill 483 174 416 484 175 416 minecraft:orange_concrete
fill 483 174 417 485 174 417 minecraft:red_nether_bricks
fill 484 174 458 485 179 458 minecraft:red_nether_bricks
fill 485 174 457 487 174 457 minecraft:red_nether_bricks
fill 487 174 417 489 174 417 minecraft:red_nether_bricks
fill 489 174 416 490 176 416 minecraft:red_nether_bricks
fill 489 174 457 491 174 457 minecraft:red_nether_bricks
fill 491 174 416 492 174 416 minecraft:orange_concrete
fill 491 174 417 493 174 417 minecraft:red_nether_bricks
fill 493 174 416 493 179 416 minecraft:red_nether_bricks
fill 493 174 457 493 174 458 minecraft:red_nether_bricks
fill 494 174 457 495 174 457 minecraft:red_nether_bricks
fill 494 174 458 495 174 458 minecraft:orange_concrete
fill 495 174 416 495 175 416 minecraft:orange_concrete
fill 495 174 417 497 174 417 minecraft:red_nether_bricks
setblock 496 174 416 minecraft:red_nether_bricks
fill 496 174 458 497 179 458 minecraft:red_nether_bricks
fill 497 174 457 499 174 457 minecraft:red_nether_bricks
fill 499 174 417 501 174 417 minecraft:red_nether_bricks
fill 501 174 416 502 179 416 minecraft:red_nether_bricks
fill 501 174 457 503 174 457 minecraft:red_nether_bricks
fill 502 174 458 503 175 458 minecraft:orange_concrete
fill 503 174 416 504 175 416 minecraft:orange_concrete
fill 503 174 417 505 174 417 minecraft:red_nether_bricks
fill 504 174 434 504 179 434 minecraft:red_nether_bricks
fill 504 174 458 505 179 458 minecraft:red_nether_bricks
fill 505 174 433 507 179 433 minecraft:red_nether_bricks
fill 505 174 457 507 174 457 minecraft:red_nether_bricks
setblock 506 174 458 minecraft:orange_concrete
fill 507 174 417 509 174 417 minecraft:red_nether_bricks
fill 509 174 457 512 174 457 minecraft:red_nether_bricks
fill 510 174 416 510 179 416 minecraft:red_nether_bricks
fill 511 174 417 511 174 419 minecraft:red_nether_bricks
fill 511 174 421 511 174 423 minecraft:red_nether_bricks
fill 511 174 425 511 174 427 minecraft:red_nether_bricks
fill 511 174 429 511 174 431 minecraft:red_nether_bricks
fill 511 174 433 511 174 435 minecraft:red_nether_bricks
fill 511 174 437 511 174 439 minecraft:red_nether_bricks
fill 511 174 441 511 174 443 minecraft:red_nether_bricks
fill 511 174 445 511 174 447 minecraft:red_nether_bricks
fill 511 174 449 511 174 451 minecraft:red_nether_bricks
fill 511 174 453 511 174 455 minecraft:red_nether_bricks
setblock 512 174 416 minecraft:orange_concrete
fill 512 174 417 512 179 418 minecraft:red_nether_bricks
fill 512 174 419 512 175 419 minecraft:orange_concrete
fill 512 174 425 512 179 426 minecraft:red_nether_bricks
fill 512 174 427 512 174 428 minecraft:orange_concrete
fill 512 174 437 512 179 438 minecraft:red_nether_bricks
fill 512 174 439 512 175 440 minecraft:orange_concrete
fill 512 174 446 512 179 446 minecraft:red_nether_bricks
fill 512 174 447 512 174 448 minecraft:orange_concrete
fill 512 174 449 512 179 449 minecraft:red_nether_bricks
fill 512 174 451 512 175 451 minecraft:orange_concrete
fill 470 175 420 470 179 421 minecraft:red_nether_bricks
setblock 470 175 426 minecraft:orange_concrete
fill 470 175 429 470 178 432 minecraft:red_nether_bricks
fill 470 175 440 470 179 441 minecraft:red_nether_bricks
setblock 470 175 447 minecraft:orange_concrete
setblock 470 175 450 minecraft:orange_concrete
fill 470 175 451 470 178 453 minecraft:red_nether_bricks
setblock 470 175 458 minecraft:orange_concrete
fill 474 175 458 474 178 458 minecraft:red_nether_bricks
setblock 475 175 416 minecraft:orange_concrete
fill 479 175 416 480 177 416 minecraft:red_nether_bricks
fill 490 175 458 491 175 458 minecraft:orange_concrete
fill 491 175 416 491 178 416 minecraft:red_nether_bricks
setblock 492 175 416 minecraft:orange_concrete
fill 493 175 458 493 179 458 minecraft:red_nether_bricks
setblock 494 175 458 minecraft:orange_concrete
fill 495 175 458 495 178 458 minecraft:red_nether_bricks
setblock 496 175 416 minecraft:orange_concrete
fill 504 175 433 504 181 433 minecraft:red_nether_bricks
fill 505 175 432 506 181 432 minecraft:red_nether_bricks
fill 506 175 458 506 178 458 minecraft:red_nether_bricks
fill 508 175 434 508 176 434 minecraft:red_nether_bricks
setblock 511 175 458 minecraft:orange_concrete
fill 512 175 416 512 178 416 minecraft:red_nether_bricks
setblock 512 175 420 minecraft:orange_concrete
fill 512 175 427 512 178 427 minecraft:red_nether_bricks
setblock 512 175 428 minecraft:orange_concrete
setblock 512 175 431 minecraft:orange_concrete
fill 512 175 447 512 178 448 minecraft:red_nether_bricks
setblock 512 175 452 minecraft:orange_concrete
fill 512 175 457 512 179 457 minecraft:red_nether_bricks
fill 470 176 416 470 176 417 minecraft:orange_concrete
fill 470 176 418 470 181 419 minecraft:red_nether_bricks
fill 470 176 424 470 177 425 minecraft:orange_concrete
fill 470 176 426 470 181 427 minecraft:red_nether_bricks
setblock 470 176 428 minecraft:orange_concrete
fill 470 176 436 470 177 437 minecraft:orange_concrete
fill 470 176 438 470 181 439 minecraft:red_nether_bricks
fill 470 176 445 470 177 445 minecraft:orange_concrete
fill 470 176 447 470 181 447 minecraft:red_nether_bricks
fill 470 176 448 470 176 449 minecraft:orange_concrete
fill 470 176 450 470 181 450 minecraft:red_nether_bricks
fill 470 176 456 470 177 457 minecraft:orange_concrete
fill 470 176 458 471 181 458 minecraft:red_nether_bricks
fill 471 176 416 472 178 416 minecraft:red_nether_bricks
fill 473 176 416 474 176 416 minecraft:orange_concrete
setblock 473 176 419 minecraft:light[level=14]
setblock 473 176 427 minecraft:light[level=14]
setblock 473 176 435 minecraft:light[level=14]
setblock 473 176 443 minecraft:light[level=14]
setblock 473 176 451 minecraft:light[level=14]
fill 475 176 416 475 181 416 minecraft:red_nether_bricks
fill 477 176 416 477 177 416 minecraft:orange_concrete
setblock 478 176 416 minecraft:red_nether_bricks
fill 480 176 458 481 176 458 minecraft:orange_concrete
setblock 481 176 419 minecraft:light[level=14]
setblock 481 176 427 minecraft:light[level=14]
setblock 481 176 435 minecraft:light[level=14]
setblock 481 176 443 minecraft:light[level=14]
setblock 481 176 451 minecraft:light[level=14]
fill 482 176 458 483 181 458 minecraft:red_nether_bricks
fill 483 176 416 484 181 416 minecraft:red_nether_bricks
fill 485 176 416 486 177 416 minecraft:orange_concrete
setblock 489 176 419 minecraft:light[level=14]
setblock 489 176 427 minecraft:light[level=14]
setblock 489 176 435 minecraft:light[level=14]
setblock 489 176 443 minecraft:light[level=14]
setblock 489 176 451 minecraft:light[level=14]
fill 489 176 458 489 177 458 minecraft:orange_concrete
fill 490 176 443 490 209 443 minecraft:red_nether_bricks
fill 490 176 458 491 181 458 minecraft:red_nether_bricks
fill 492 176 416 492 178 416 minecraft:red_nether_bricks
setblock 492 176 458 minecraft:orange_concrete
setblock 494 176 416 minecraft:orange_concrete
fill 494 176 458 494 181 458 minecraft:red_nether_bricks
fill 495 176 416 496 181 416 minecraft:red_nether_bricks
fill 497 176 416 498 177 416 minecraft:orange_concrete
setblock 497 176 419 minecraft:light[level=14]
setblock 497 176 427 minecraft:light[level=14]
setblock 497 176 435 minecraft:light[level=14]
setblock 497 176 443 minecraft:light[level=14]
setblock 497 176 451 minecraft:light[level=14]
fill 500 176 458 501 177 458 minecraft:orange_concrete
fill 502 176 458 503 181 458 minecraft:red_nether_bricks
fill 503 176 416 504 181 416 minecraft:red_nether_bricks
fill 503 176 433 503 177 434 minecraft:red_nether_bricks
fill 504 176 431 504 182 432 minecraft:red_nether_bricks
fill 505 176 416 506 176 416 minecraft:orange_concrete
setblock 505 176 419 minecraft:light[level=14]
fill 505 176 431 506 182 431 minecraft:red_nether_bricks
setblock 505 176 437 minecraft:red_nether_bricks
setblock 505 176 443 minecraft:light[level=14]
setblock 505 176 451 minecraft:light[level=14]
fill 506 176 438 506 178 438 minecraft:magma_block
fill 507 176 432 507 180 432 minecraft:red_nether_bricks
fill 511 176 458 511 181 458 minecraft:red_nether_bricks
fill 512 176 419 512 181 420 minecraft:red_nether_bricks
fill 512 176 421 512 177 422 minecraft:orange_concrete
fill 512 176 428 512 181 428 minecraft:red_nether_bricks
fill 512 176 429 512 176 430 minecraft:orange_concrete
fill 512 176 431 512 181 431 minecraft:red_nether_bricks
fill 512 176 433 512 177 433 minecraft:orange_concrete
fill 512 176 439 512 181 440 minecraft:red_nether_bricks
fill 512 176 441 512 177 442 minecraft:orange_concrete
setblock 512 176 450 minecraft:orange_concrete
fill 512 176 451 512 181 452 minecraft:red_nether_bricks
fill 512 176 453 512 177 454 minecraft:orange_concrete
fill 512 176 458 512 177 458 minecraft:orange_concrete
setblock 470 177 416 minecraft:orange_concrete
fill 470 177 417 470 180 417 minecraft:red_nether_bricks
fill 470 177 428 470 180 428 minecraft:red_nether_bricks
setblock 470 177 433 minecraft:orange_concrete
setblock 470 177 444 minecraft:orange_concrete
fill 470 177 448 470 180 449 minecraft:red_nether_bricks
fill 473 177 416 473 180 416 minecraft:red_nether_bricks
setblock 474 177 416 minecraft:orange_concrete
setblock 477 177 458 minecraft:orange_concrete
setblock 478 177 416 minecraft:orange_concrete
setblock 480 177 458 minecraft:orange_concrete
fill 481 177 458 481 180 458 minecraft:red_nether_bricks
setblock 488 177 458 minecraft:orange_concrete
setblock 489 177 416 minecraft:orange_concrete
fill 490 177 416 490 179 416 minecraft:red_nether_bricks
fill 492 177 458 492 180 458 minecraft:red_nether_bricks
fill 494 177 416 494 180 416 minecraft:red_nether_bricks
fill 503 177 432 503 182 432 minecraft:red_nether_bricks
fill 504 177 430 506 182 430 minecraft:red_nether_bricks
fill 505 177 416 505 180 416 minecraft:red_nether_bricks
setblock 506 177 416 minecraft:orange_concrete
fill 506 177 437 506 178 437 minecraft:magma_block
fill 507 177 431 507 180 431 minecraft:red_nether_bricks
fill 508 177 458 509 177 458 minecraft:orange_concrete
setblock 509 177 416 minecraft:orange_concrete
fill 512 177 429 512 180 430 minecraft:red_nether_bricks
setblock 512 177 434 minecraft:orange_concrete
setblock 512 177 445 minecraft:orange_concrete
fill 512 177 450 512 180 450 minecraft:red_nether_bricks
fill 470 178 416 470 183 416 minecraft:red_nether_bricks
fill 470 178 422 470 179 423 minecraft:orange_concrete
fill 470 178 424 470 183 425 minecraft:red_nether_bricks
fill 470 178 433 470 183 433 minecraft:red_nether_bricks
fill 470 178 434 470 178 435 minecraft:orange_concrete
fill 470 178 436 470 182 437 minecraft:red_nether_bricks
fill 470 178 442 470 179 443 minecraft:orange_concrete
fill 470 178 444 470 183 445 minecraft:red_nether_bricks
setblock 470 178 446 minecraft:orange_concrete
fill 470 178 454 470 179 455 minecraft:orange_concrete
fill 470 178 456 470 182 457 minecraft:red_nether_bricks
fill 474 178 416 474 180 416 minecraft:red_nether_bricks
fill 475 178 458 475 179 458 minecraft:orange_concrete
setblock 476 178 416 minecraft:orange_concrete
fill 477 178 416 478 183 416 minecraft:red_nether_bricks
fill 477 178 458 477 183 458 minecraft:red_nether_bricks
fill 478 178 458 479 178 458 minecraft:orange_concrete
fill 479 178 416 480 179 416 minecraft:orange_concrete
fill 480 178 458 480 183 458 minecraft:red_nether_bricks
fill 485 178 416 486 182 416 minecraft:red_nether_bricks
fill 486 178 458 487 179 458 minecraft:orange_concrete
fill 487 178 416 488 178 416 minecraft:orange_concrete
fill 488 178 458 489 183 458 minecraft:red_nether_bricks
fill 489 178 416 489 179 416 minecraft:red_nether_bricks
fill 497 178 416 498 183 416 minecraft:red_nether_bricks
fill 498 178 458 499 178 458 minecraft:orange_concrete
fill 499 178 416 500 179 416 minecraft:orange_concrete
fill 500 178 458 501 183 458 minecraft:red_nether_bricks
fill 503 178 430 503 183 431 minecraft:red_nether_bricks
fill 503 178 433 503 180 433 minecraft:red_nether_bricks
fill 504 178 429 505 184 429 minecraft:red_nether_bricks
fill 506 178 416 506 183 416 minecraft:red_nether_bricks
fill 507 178 416 508 178 416 minecraft:orange_concrete
fill 507 178 458 507 179 458 minecraft:orange_concrete
fill 508 178 458 509 182 458 minecraft:red_nether_bricks
fill 509 178 416 509 183 416 minecraft:red_nether_bricks
setblock 510 178 458 minecraft:orange_concrete
fill 511 178 416 511 179 416 minecraft:orange_concrete
fill 512 178 421 512 183 422 minecraft:red_nether_bricks
fill 512 178 423 512 179 424 minecraft:orange_concrete
setblock 512 178 432 minecraft:orange_concrete
fill 512 178 433 512 182 434 minecraft:red_nether_bricks
fill 512 178 435 512 179 436 minecraft:orange_concrete
fill 512 178 441 512 183 442 minecraft:red_nether_bricks
fill 512 178 443 512 178 444 minecraft:orange_concrete
fill 512 178 445 512 183 445 minecraft:red_nether_bricks
fill 512 178 453 512 181 454 minecraft:red_nether_bricks
fill 512 178 455 512 179 456 minecraft:orange_concrete
fill 512 178 458 512 181 458 minecraft:red_nether_bricks
setblock 470 179 429 minecraft:red_nether_bricks
fill 470 179 430 470 179 431 minecraft:orange_concrete
setblock 470 179 432 minecraft:red_nether_bricks
setblock 470 179 434 minecraft:orange_concrete
fill 470 179 435 470 182 435 minecraft:red_nether_bricks
fill 470 179 446 470 182 446 minecraft:red_nether_bricks
setblock 470 179 451 minecraft:orange_concrete
fill 470 179 452 470 179 453 minecraft:red_nether_bricks
setblock 471 179 416 minecraft:orange_concrete
fill 472 179 416 472 181 416 minecraft:red_nether_bricks
setblock 474 179 458 minecraft:orange_concrete
fill 476 179 416 476 182 416 minecraft:red_nether_bricks
fill 478 179 458 479 182 458 minecraft:red_nether_bricks
fill 487 179 416 487 182 416 minecraft:red_nether_bricks
setblock 488 179 416 minecraft:orange_concrete
fill 491 179 416 492 179 416 minecraft:orange_concrete
setblock 495 179 458 minecraft:orange_concrete
setblock 498 179 458 minecraft:orange_concrete
fill 499 179 458 499 182 458 minecraft:red_nether_bricks
fill 502 179 430 502 182 431 minecraft:red_nether_bricks
fill 503 179 429 503 186 429 minecraft:red_nether_bricks
fill 505 179 434 506 179 434 minecraft:red_nether_bricks
fill 506 179 429 506 182 429 minecraft:red_nether_bricks
setblock 506 179 458 minecraft:orange_concrete
fill 507 179 416 508 181 416 minecraft:red_nether_bricks
fill 510 179 458 510 181 458 minecraft:red_nether_bricks
setblock 512 179 416 minecraft:orange_concrete
setblock 512 179 427 minecraft:orange_concrete
fill 512 179 432 512 182 432 minecraft:red_nether_bricks
fill 512 179 443 512 182 443 minecraft:red_nether_bricks
setblock 512 179 444 minecraft:orange_concrete
fill 512 179 447 512 179 448 minecraft:orange_concrete
fill 470 180 420 470 180 421 minecraft:orange_concrete
fill 470 180 422 470 182 423 minecraft:red_nether_bricks
fill 470 180 429 470 181 429 minecraft:orange_concrete
fill 470 180 430 470 181 431 minecraft:red_nether_bricks
setblock 470 180 432 minecraft:orange_concrete
fill 470 180 434 470 185 434 minecraft:red_nether_bricks
fill 470 180 440 470 181 441 minecraft:orange_concrete
fill 470 180 442 470 183 443 minecraft:red_nether_bricks
fill 470 180 451 471 180 451 minecraft:red_nether_bricks
fill 470 180 452 470 180 453 minecraft:orange_concrete
fill 470 180 454 470 185 455 minecraft:red_nether_bricks
fill 471 180 416 471 180 417 minecraft:red_nether_bricks
fill 471 180 419 471 180 421 minecraft:red_nether_bricks
fill 471 180 423 471 180 425 minecraft:red_nether_bricks
fill 471 180 427 471 180 429 minecraft:red_nether_bricks
fill 471 180 431 471 180 433 minecraft:red_nether_bricks
fill 471 180 435 471 180 437 minecraft:red_nether_bricks
fill 471 180 439 471 180 441 minecraft:red_nether_bricks
fill 471 180 443 471 180 445 minecraft:red_nether_bricks
fill 471 180 447 471 180 449 minecraft:red_nether_bricks
fill 471 180 452 471 180 453 minecraft:red_nether_bricks
fill 471 180 455 471 180 457 minecraft:red_nether_bricks
fill 472 180 417 473 180 417 minecraft:red_nether_bricks
fill 472 180 458 473 181 458 minecraft:orange_concrete
fill 473 180 457 475 180 457 minecraft:red_nether_bricks
fill 474 180 458 475 185 458 minecraft:red_nether_bricks
fill 475 180 417 477 180 417 minecraft:red_nether_bricks
setblock 476 180 458 minecraft:orange_concrete
fill 477 180 457 479 180 457 minecraft:red_nether_bricks
fill 479 180 416 480 180 417 minecraft:red_nether_bricks
fill 481 180 416 482 181 416 minecraft:orange_concrete
setblock 481 180 417 minecraft:red_nether_bricks
fill 481 180 457 483 180 457 minecraft:red_nether_bricks
fill 483 180 417 485 180 417 minecraft:red_nether_bricks
fill 484 180 458 485 181 458 minecraft:orange_concrete
fill 485 180 457 487 180 457 minecraft:red_nether_bricks
fill 486 180 458 487 181 458 minecraft:red_nether_bricks
fill 487 180 417 489 180 417 minecraft:red_nether_bricks
fill 488 180 416 488 185 416 minecraft:red_nether_bricks
fill 489 180 416 490 180 416 minecraft:orange_concrete
fill 489 180 457 491 180 457 minecraft:red_nether_bricks
fill 491 180 416 492 180 417 minecraft:red_nether_bricks
fill 493 180 416 493 181 416 minecraft:orange_concrete
setblock 493 180 417 minecraft:red_nether_bricks
fill 493 180 457 495 180 457 minecraft:red_nether_bricks
fill 493 180 458 493 181 458 minecraft:orange_concrete
fill 495 180 417 497 180 417 minecraft:red_nether_bricks
fill 495 180 458 495 185 458 minecraft:red_nether_bricks
fill 496 180 458 497 180 458 minecraft:orange_concrete
fill 497 180 457 499 180 457 minecraft:red_nether_bricks
fill 498 180 458 498 181 458 minecraft:red_nether_bricks
fill 499 180 416 500 180 417 minecraft:red_nether_bricks
fill 501 180 416 502 181 416 minecraft:orange_concrete
setblock 501 180 417 minecraft:red_nether_bricks
fill 501 180 457 503 180 457 minecraft:red_nether_bricks
fill 502 180 429 502 186 429 minecraft:red_nether_bricks
fill 503 180 417 505 180 417 minecraft:red_nether_bricks
fill 503 180 428 505 184 428 minecraft:red_nether_bricks
fill 504 180 458 505 181 458 minecraft:orange_concrete
fill 505 180 433 506 180 433 minecraft:red_nether_bricks
fill 505 180 457 507 180 457 minecraft:red_nether_bricks
fill 506 180 458 507 182 458 minecraft:red_nether_bricks
fill 507 180 417 509 180 417 minecraft:red_nether_bricks
fill 509 180 457 511 180 457 minecraft:red_nether_bricks
setblock 510 180 416 minecraft:orange_concrete
fill 511 180 416 511 180 419 minecraft:red_nether_bricks
fill 511 180 421 511 180 423 minecraft:red_nether_bricks
fill 511 180 425 511 180 427 minecraft:red_nether_bricks
fill 511 180 429 511 180 431 minecraft:red_nether_bricks
fill 511 180 433 511 180 435 minecraft:red_nether_bricks
fill 511 180 437 511 180 439 minecraft:red_nether_bricks
fill 511 180 441 511 180 443 minecraft:red_nether_bricks
fill 511 180 445 511 180 447 minecraft:red_nether_bricks
fill 511 180 449 511 180 451 minecraft:red_nether_bricks
fill 511 180 453 511 180 455 minecraft:red_nether_bricks
fill 512 180 416 512 185 416 minecraft:red_nether_bricks
fill 512 180 417 512 181 418 minecraft:orange_concrete
fill 512 180 423 512 185 424 minecraft:red_nether_bricks
fill 512 180 425 512 180 426 minecraft:orange_concrete
fill 512 180 427 512 185 427 minecraft:red_nether_bricks
fill 512 180 435 512 183 436 minecraft:red_nether_bricks
fill 512 180 437 512 181 438 minecraft:orange_concrete
fill 512 180 444 512 182 444 minecraft:red_nether_bricks
setblock 512 180 446 minecraft:orange_concrete
fill 512 180 447 512 185 448 minecraft:red_nether_bricks
fill 512 180 449 512 181 449 minecraft:orange_concrete
fill 512 180 455 512 185 456 minecraft:red_nether_bricks
setblock 512 180 457 minecraft:orange_concrete
setblock 470 181 417 minecraft:orange_concrete
setblock 470 181 420 minecraft:orange_concrete
fill 470 181 421 470 182 421 minecraft:red_nether_bricks
setblock 470 181 428 minecraft:orange_concrete
fill 470 181 432 470 184 432 minecraft:red_nether_bricks
fill 470 181 448 470 181 449 minecraft:orange_concrete
fill 470 181 451 470 182 451 minecraft:red_nether_bricks
setblock 470 181 452 minecraft:orange_concrete
fill 470 181 453 470 184 453 minecraft:red_nether_bricks
fill 471 181 416 471 185 416 minecraft:red_nether_bricks
fill 473 181 416 474 181 416 minecraft:orange_concrete
fill 476 181 458 476 184 458 minecraft:red_nether_bricks
fill 479 181 416 480 183 416 minecraft:red_nether_bricks
setblock 481 181 458 minecraft:orange_concrete
fill 489 181 416 492 181 416 minecraft:red_nether_bricks
setblock 492 181 458 minecraft:orange_concrete
setblock 494 181 416 minecraft:orange_concrete
fill 496 181 458 497 184 458 minecraft:red_nether_bricks
fill 499 181 416 500 181 416 minecraft:red_nether_bricks
fill 502 181 427 502 187 428 minecraft:red_nether_bricks
fill 503 181 427 503 187 427 minecraft:red_nether_bricks
setblock 505 181 416 minecraft:orange_concrete
setblock 505 181 433 minecraft:red_nether_bricks
fill 510 181 416 511 183 416 minecraft:red_nether_bricks
fill 512 181 425 512 184 425 minecraft:red_nether_bricks
setblock 512 181 426 minecraft:orange_concrete
fill 512 181 429 512 181 430 minecraft:orange_concrete
fill 512 181 446 512 184 446 minecraft:red_nether_bricks
setblock 512 181 450 minecraft:orange_concrete
fill 512 181 457 512 184 457 minecraft:red_nether_bricks
fill 470 182 417 470 185 417 minecraft:red_nether_bricks
fill 470 182 418 470 182 419 minecraft:orange_concrete
fill 470 182 420 470 183 420 minecraft:red_nether_bricks
fill 470 182 426 470 183 427 minecraft:orange_concrete
fill 470 182 428 470 182 429 minecraft:red_nether_bricks
setblock 470 182 430 minecraft:netherrack
fill 470 182 431 470 185 431 minecraft:red_nether_bricks
fill 470 182 438 470 182 439 minecraft:orange_concrete
fill 470 182 440 470 182 441 minecraft:red_nether_bricks
fill 470 182 447 470 183 447 minecraft:orange_concrete
fill 470 182 448 470 182 449 minecraft:red_nether_bricks
setblock 470 182 450 minecraft:orange_concrete
setblock 470 182 452 minecraft:netherrack
fill 470 182 458 471 183 458 minecraft:orange_concrete
setblock 472 182 416 minecraft:orange_concrete
fill 472 182 458 472 185 458 minecraft:red_nether_bricks
fill 473 182 416 473 185 416 minecraft:red_nether_bricks
fill 473 182 458 473 183 458 minecraft:netherrack
setblock 474 182 416 minecraft:netherrack
fill 475 182 416 475 183 416 minecraft:orange_concrete
fill 481 182 416 481 185 416 minecraft:red_nether_bricks
fill 481 182 458 481 185 458 minecraft:red_nether_bricks
setblock 482 182 416 minecraft:netherrack
fill 482 182 458 483 182 458 minecraft:orange_concrete
fill 483 182 416 484 183 416 minecraft:orange_concrete
fill 484 182 458 485 185 458 minecraft:red_nether_bricks
setblock 486 182 458 minecraft:netherrack
fill 487 182 458 487 185 458 minecraft:red_nether_bricks
fill 489 182 416 491 182 416 minecraft:red_nether_bricks
fill 490 182 458 491 183 458 minecraft:orange_concrete
setblock 492 182 416 minecraft:orange_concrete
fill 492 182 458 492 185 458 minecraft:red_nether_bricks
fill 493 182 416 493 185 416 minecraft:red_nether_bricks
setblock 493 182 458 minecraft:netherrack
setblock 494 182 416 minecraft:netherrack
setblock 494 182 458 minecraft:orange_concrete
fill 495 182 416 496 183 416 minecraft:orange_concrete
setblock 498 182 458 minecraft:netherrack
fill 499 182 416 499 185 416 minecraft:red_nether_bricks
setblock 500 182 416 minecraft:netherrack
fill 501 182 416 502 183 416 minecraft:red_nether_bricks
fill 501 182 427 501 186 429 minecraft:red_nether_bricks
fill 502 182 426 502 189 426 minecraft:red_nether_bricks
fill 502 182 458 503 183 458 minecraft:orange_concrete
fill 503 182 416 504 182 416 minecraft:orange_concrete
setblock 504 182 458 minecraft:netherrack
fill 505 182 416 505 185 416 minecraft:red_nether_bricks
setblock 505 182 432 minecraft:red_nether_bricks
fill 505 182 458 505 185 458 minecraft:red_nether_bricks
fill 507 182 416 507 183 416 minecraft:orange_concrete
setblock 508 182 416 minecraft:red_nether_bricks
setblock 510 182 458 minecraft:netherrack
fill 511 182 458 511 183 458 minecraft:orange_concrete
fill 512 182 417 512 182 418 minecraft:red_nether_bricks
fill 512 182 419 512 183 420 minecraft:orange_concrete
fill 512 182 426 512 185 426 minecraft:red_nether_bricks
setblock 512 182 428 minecraft:orange_concrete
fill 512 182 429 512 185 429 minecraft:red_nether_bricks
setblock 512 182 430 minecraft:netherrack
fill 512 182 431 512 183 431 minecraft:orange_concrete
fill 512 182 437 512 185 438 minecraft:red_nether_bricks
fill 512 182 439 512 182 440 minecraft:orange_concrete
fill 512 182 449 512 185 450 minecraft:red_nether_bricks
fill 512 182 451 512 183 452 minecraft:orange_concrete
fill 512 182 453 512 183 453 minecraft:red_nether_bricks
setblock 512 182 454 minecraft:netherrack
setblock 512 182 458 minecraft:netherrack
fill 470 183 418 470 183 419 minecraft:red_nether_bricks
fill 470 183 421 470 184 421 minecraft:netherrack
fill 470 183 422 470 185 422 minecraft:red_nether_bricks
setblock 470 183 423 minecraft:netherrack
fill 470 183 428 470 185 428 minecraft:red_nether_bricks
setblock 470 183 429 minecraft:netherrack
fill 470 183 430 470 185 430 minecraft:red_nether_bricks
setblock 470 183 435 minecraft:orange_concrete
fill 470 183 436 470 183 437 minecraft:netherrack
setblock 470 183 438 minecraft:orange_concrete
fill 470 183 439 470 185 439 minecraft:red_nether_bricks
fill 470 183 440 470 184 440 minecraft:netherrack
fill 470 183 441 470 185 441 minecraft:red_nether_bricks
setblock 470 183 446 minecraft:orange_concrete
fill 470 183 448 470 184 448 minecraft:netherrack
fill 470 183 449 470 185 450 minecraft:red_nether_bricks
setblock 470 183 451 minecraft:netherrack
fill 470 183 452 470 185 452 minecraft:red_nether_bricks
setblock 470 183 456 minecraft:netherrack
setblock 470 183 457 minecraft:red_nether_bricks
fill 472 183 416 472 185 416 minecraft:red_nether_bricks
fill 474 183 416 474 185 416 minecraft:red_nether_bricks
setblock 476 183 416 minecraft:orange_concrete
fill 478 183 458 479 183 458 minecraft:orange_concrete
setblock 482 183 416 minecraft:red_nether_bricks
setblock 482 183 458 minecraft:orange_concrete
fill 483 183 458 483 186 458 minecraft:red_nether_bricks
setblock 485 183 416 minecraft:netherrack
setblock 486 183 416 minecraft:red_nether_bricks
fill 486 183 458 486 185 458 minecraft:red_nether_bricks
setblock 487 183 416 minecraft:orange_concrete
setblock 489 183 416 minecraft:red_nether_bricks
setblock 490 183 416 minecraft:netherrack
fill 491 183 416 491 185 416 minecraft:red_nether_bricks
setblock 492 183 416 minecraft:netherrack
fill 493 183 458 494 185 458 minecraft:red_nether_bricks
fill 494 183 416 494 185 416 minecraft:red_nether_bricks
setblock 498 183 458 minecraft:red_nether_bricks
setblock 499 183 458 minecraft:orange_concrete
fill 500 183 416 500 185 416 minecraft:red_nether_bricks
fill 501 183 426 501 190 426 minecraft:red_nether_bricks
fill 502 183 430 502 184 430 minecraft:red_nether_bricks
setblock 503 183 416 minecraft:netherrack
setblock 504 183 416 minecraft:orange_concrete
fill 504 183 430 505 183 431 minecraft:red_nether_bricks
fill 504 183 458 504 185 458 minecraft:red_nether_bricks
setblock 506 183 458 minecraft:netherrack
setblock 507 183 458 minecraft:red_nether_bricks
setblock 508 183 416 minecraft:orange_concrete
setblock 508 183 458 minecraft:netherrack
setblock 509 183 458 minecraft:red_nether_bricks
setblock 510 183 458 minecraft:orange_concrete
fill 512 183 417 512 185 417 minecraft:red_nether_bricks
setblock 512 183 418 minecraft:netherrack
fill 512 183 428 512 185 428 minecraft:red_nether_bricks
setblock 512 183 430 minecraft:red_nether_bricks
setblock 512 183 432 minecraft:orange_concrete
setblock 512 183 433 minecraft:netherrack
setblock 512 183 434 minecraft:red_nether_bricks
setblock 512 183 439 minecraft:netherrack
setblock 512 183 440 minecraft:orange_concrete
setblock 512 183 443 minecraft:orange_concrete
setblock 512 183 444 minecraft:netherrack
setblock 512 183 454 minecraft:red_nether_bricks
setblock 512 183 458 minecraft:red_nether_bricks
setblock 470 184 416 minecraft:orange_concrete
setblock 470 184 418 minecraft:netherrack
fill 470 184 419 470 185 419 minecraft:red_nether_bricks
setblock 470 184 420 minecraft:netherrack
fill 470 184 423 470 185 423 minecraft:red_nether_bricks
fill 470 184 424 470 185 425 minecraft:orange_concrete
fill 470 184 426 470 185 427 minecraft:red_nether_bricks
fill 470 184 429 470 186 429 minecraft:red_nether_bricks
fill 470 184 433 470 185 433 minecraft:orange_concrete
fill 470 184 435 470 185 435 minecraft:red_nether_bricks
fill 470 184 436 470 184 437 minecraft:orange_concrete
fill 470 184 438 470 185 438 minecraft:red_nether_bricks
setblock 470 184 442 minecraft:netherrack
fill 470 184 443 470 185 443 minecraft:red_nether_bricks
fill 470 184 444 470 185 445 minecraft:orange_concrete
fill 470 184 446 470 185 447 minecraft:red_nether_bricks
fill 470 184 451 470 185 451 minecraft:red_nether_bricks
fill 470 184 456 470 184 457 minecraft:orange_concrete
fill 470 184 458 471 185 458 minecraft:red_nether_bricks
setblock 473 184 419 minecraft:light[level=14]
setblock 473 184 427 minecraft:light[level=14]
setblock 473 184 435 minecraft:light[level=14]
setblock 473 184 443 minecraft:light[level=14]
setblock 473 184 451 minecraft:light[level=14]
fill 473 184 458 473 185 458 minecraft:red_nether_bricks
fill 475 184 416 476 185 416 minecraft:red_nether_bricks
fill 477 184 416 478 185 416 minecraft:orange_concrete
fill 477 184 458 477 185 458 minecraft:orange_concrete
fill 478 184 458 479 185 458 minecraft:red_nether_bricks
setblock 479 184 416 minecraft:netherrack
fill 480 184 416 480 185 416 minecraft:red_nether_bricks
setblock 480 184 458 minecraft:orange_concrete
setblock 481 184 419 minecraft:light[level=14]
setblock 481 184 427 minecraft:light[level=14]
setblock 481 184 435 minecraft:light[level=14]
setblock 481 184 443 minecraft:light[level=14]
setblock 481 184 451 minecraft:light[level=14]
setblock 482 184 416 minecraft:netherrack
fill 482 184 458 482 185 458 minecraft:red_nether_bricks
fill 483 184 416 484 185 416 minecraft:red_nether_bricks
fill 484 184 420 485 185 421 minecraft:magma_block
fill 485 184 416 486 184 416 minecraft:orange_concrete
fill 487 184 416 487 185 416 minecraft:red_nether_bricks
fill 488 184 458 489 185 458 minecraft:orange_concrete
fill 489 184 416 489 185 416 minecraft:orange_concrete
setblock 489 184 419 minecraft:light[level=14]
setblock 489 184 427 minecraft:light[level=14]
setblock 489 184 435 minecraft:light[level=14]
setblock 489 184 443 minecraft:light[level=14]
setblock 489 184 451 minecraft:light[level=14]
setblock 490 184 416 minecraft:red_nether_bricks
setblock 490 184 458 minecraft:netherrack
fill 491 184 458 491 185 458 minecraft:red_nether_bricks
fill 492 184 416 492 185 416 minecraft:red_nether_bricks
fill 495 184 416 496 185 416 minecraft:red_nether_bricks
fill 497 184 416 498 185 416 minecraft:orange_concrete
setblock 497 184 419 minecraft:light[level=14]
setblock 497 184 427 minecraft:light[level=14]
setblock 497 184 435 minecraft:light[level=14]
setblock 497 184 443 minecraft:light[level=14]
setblock 497 184 451 minecraft:light[level=14]
setblock 498 184 458 minecraft:netherrack
fill 499 184 458 499 185 458 minecraft:red_nether_bricks
fill 500 184 425 500 187 428 minecraft:red_nether_bricks
fill 500 184 458 501 184 458 minecraft:orange_concrete
fill 501 184 416 502 184 416 minecraft:netherrack
fill 501 184 425 502 189 425 minecraft:red_nether_bricks
fill 502 184 458 502 185 458 minecraft:red_nether_bricks
fill 503 184 416 504 185 416 minecraft:red_nether_bricks
fill 503 184 430 504 184 430 minecraft:red_nether_bricks
setblock 503 184 458 minecraft:netherrack
setblock 505 184 419 minecraft:light[level=14]
setblock 505 184 435 minecraft:light[level=14]
setblock 505 184 443 minecraft:light[level=14]
setblock 505 184 451 minecraft:light[level=14]
setblock 506 184 416 minecraft:orange_concrete
fill 506 184 458 506 185 458 minecraft:red_nether_bricks
fill 507 184 416 508 185 416 minecraft:red_nether_bricks
setblock 507 184 458 minecraft:netherrack
fill 508 184 458 509 185 458 minecraft:orange_concrete
fill 509 184 416 510 185 416 minecraft:orange_concrete
fill 510 184 458 510 185 458 minecraft:red_nether_bricks
fill 511 184 416 511 185 416 minecraft:red_nether_bricks
setblock 511 184 458 minecraft:netherrack
fill 512 184 418 512 185 420 minecraft:red_nether_bricks
fill 512 184 421 512 184 422 minecraft:orange_concrete
setblock 512 184 430 minecraft:netherrack
fill 512 184 431 512 185 432 minecraft:red_nether_bricks
fill 512 184 433 512 185 434 minecraft:orange_concrete
setblock 512 184 435 minecraft:netherrack
fill 512 184 436 512 185 436 minecraft:red_nether_bricks
fill 512 184 439 512 185 440 minecraft:red_nether_bricks
fill 512 184 441 512 184 442 minecraft:orange_concrete
fill 512 184 443 512 185 444 minecraft:red_nether_bricks
fill 512 184 445 512 185 445 minecraft:orange_concrete
fill 512 184 451 512 185 452 minecraft:red_nether_bricks
fill 512 184 453 512 185 454 minecraft:orange_concrete
setblock 512 184 458 minecraft:orange_concrete
setblock 470 185 416 minecraft:red_nether_bricks
setblock 470 185 418 minecraft:red_nether_bricks
setblock 470 185 420 minecraft:red_nether_bricks
setblock 470 185 421 minecraft:orange_concrete
setblock 470 185 432 minecraft:orange_concrete
fill 470 185 436 470 185 437 minecraft:red_nether_bricks
fill 470 185 440 470 186 440 minecraft:red_nether_bricks
setblock 470 185 442 minecraft:red_nether_bricks
setblock 470 185 448 minecraft:red_nether_bricks
setblock 470 185 453 minecraft:orange_concrete
setblock 470 185 456 minecraft:orange_concrete
setblock 470 185 457 minecraft:red_nether_bricks
setblock 476 185 458 minecraft:orange_concrete
setblock 479 185 416 minecraft:red_nether_bricks
setblock 480 185 458 minecraft:red_nether_bricks
setblock 482 185 416 minecraft:red_nether_bricks
setblock 485 185 416 minecraft:red_nether_bricks
setblock 486 185 416 minecraft:orange_concrete
setblock 490 185 416 minecraft:orange_concrete
setblock 490 185 458 minecraft:red_nether_bricks
fill 496 185 458 497 185 458 minecraft:orange_concrete
setblock 498 185 458 minecraft:red_nether_bricks
fill 499 185 425 499 189 427 minecraft:red_nether_bricks
fill 500 185 424 502 188 424 minecraft:red_nether_bricks
setblock 500 185 458 minecraft:orange_concrete
setblock 501 185 416 minecraft:orange_concrete
setblock 501 185 458 minecraft:red_nether_bricks
fill 502 185 416 502 186 416 minecraft:red_nether_bricks
fill 503 185 428 504 186 428 minecraft:red_nether_bricks
setblock 503 185 458 minecraft:red_nether_bricks
setblock 504 185 429 minecraft:red_nether_bricks
fill 506 185 416 506 186 416 minecraft:red_nether_bricks
setblock 507 185 458 minecraft:red_nether_bricks
fill 511 185 458 512 185 458 minecraft:red_nether_bricks
setblock 512 185 421 minecraft:red_nether_bricks
setblock 512 185 422 minecraft:orange_concrete
setblock 512 185 425 minecraft:orange_concrete
setblock 512 185 430 minecraft:red_nether_bricks
setblock 512 185 435 minecraft:red_nether_bricks
fill 512 185 441 512 185 442 minecraft:red_nether_bricks
setblock 512 185 446 minecraft:orange_concrete
setblock 512 185 457 minecraft:orange_concrete
fill 470 186 416 470 186 421 minecraft:netherrack
fill 470 186 422 470 186 423 minecraft:orange_concrete
fill 470 186 424 471 186 424 minecraft:red_nether_bricks
fill 470 186 425 470 187 428 minecraft:netherrack
fill 470 186 430 470 187 431 minecraft:orange_concrete
fill 470 186 432 470 186 433 minecraft:netherrack
setblock 470 186 434 minecraft:orange_concrete
fill 470 186 435 470 186 439 minecraft:netherrack
fill 470 186 441 470 187 441 minecraft:netherrack
fill 470 186 442 470 187 443 minecraft:orange_concrete
fill 470 186 444 471 186 445 minecraft:red_nether_bricks
fill 470 186 446 470 186 450 minecraft:netherrack
fill 470 186 451 470 187 451 minecraft:orange_concrete
fill 470 186 452 470 187 453 minecraft:netherrack
fill 470 186 454 470 186 455 minecraft:orange_concrete
fill 470 186 456 470 188 458 minecraft:netherrack
fill 471 186 416 471 187 416 minecraft:orange_concrete
fill 471 186 417 473 186 417 minecraft:red_nether_bricks
fill 471 186 419 471 186 421 minecraft:red_nether_bricks
setblock 471 186 423 minecraft:red_nether_bricks
setblock 471 186 425 minecraft:red_nether_bricks
fill 471 186 427 471 186 429 minecraft:red_nether_bricks
fill 471 186 431 471 186 433 minecraft:red_nether_bricks
fill 471 186 435 471 186 437 minecraft:red_nether_bricks
fill 471 186 439 471 186 441 minecraft:red_nether_bricks
setblock 471 186 443 minecraft:red_nether_bricks
fill 471 186 447 471 186 449 minecraft:red_nether_bricks
fill 471 186 451 471 186 453 minecraft:red_nether_bricks
fill 471 186 455 471 186 457 minecraft:red_nether_bricks
fill 471 186 458 473 187 458 minecraft:netherrack
fill 472 186 416 478 186 416 minecraft:netherrack
fill 473 186 457 475 186 457 minecraft:red_nether_bricks
fill 474 186 458 475 187 458 minecraft:orange_concrete
fill 475 186 417 477 186 417 minecraft:red_nether_bricks
fill 476 186 458 478 186 458 minecraft:netherrack
fill 477 186 457 479 186 457 minecraft:red_nether_bricks
fill 479 186 416 480 187 416 minecraft:orange_concrete
fill 479 186 417 481 186 417 minecraft:red_nether_bricks
setblock 479 186 458 minecraft:red_nether_bricks
fill 480 186 458 482 187 458 minecraft:netherrack
fill 481 186 416 487 186 416 minecraft:netherrack
fill 481 186 457 483 186 457 minecraft:red_nether_bricks
fill 483 186 417 485 186 417 minecraft:red_nether_bricks
fill 484 186 458 485 187 458 minecraft:netherrack
fill 485 186 457 487 186 457 minecraft:red_nether_bricks
fill 486 186 458 487 186 458 minecraft:orange_concrete
fill 487 186 417 489 186 417 minecraft:red_nether_bricks
setblock 488 186 416 minecraft:orange_concrete
fill 488 186 458 492 187 458 minecraft:netherrack
fill 489 186 416 490 191 416 minecraft:netherrack
fill 489 186 457 491 186 457 minecraft:red_nether_bricks
fill 491 186 416 492 187 416 minecraft:orange_concrete
fill 491 186 417 493 186 417 minecraft:red_nether_bricks
fill 493 186 416 498 187 416 minecraft:netherrack
fill 493 186 457 493 186 458 minecraft:red_nether_bricks
fill 494 186 457 495 186 457 minecraft:red_nether_bricks
setblock 494 186 458 minecraft:netherrack
fill 495 186 417 497 186 417 minecraft:red_nether_bricks
fill 495 186 458 495 187 458 minecraft:orange_concrete
fill 496 186 458 497 187 458 minecraft:netherrack
fill 497 186 457 499 186 457 minecraft:red_nether_bricks
fill 498 186 425 498 193 425 minecraft:red_nether_bricks
setblock 498 186 458 minecraft:orange_concrete
fill 499 186 416 500 186 416 minecraft:orange_concrete
fill 499 186 417 501 186 417 minecraft:red_nether_bricks
fill 499 186 424 499 193 424 minecraft:red_nether_bricks
fill 499 186 458 505 186 458 minecraft:netherrack
fill 501 186 416 501 187 416 minecraft:netherrack
fill 501 186 457 503 186 457 minecraft:red_nether_bricks
setblock 503 186 416 minecraft:netherrack
fill 503 186 417 505 186 417 minecraft:red_nether_bricks
setblock 504 186 416 minecraft:red_nether_bricks
fill 505 186 416 505 187 416 minecraft:netherrack
fill 505 186 457 507 186 457 minecraft:red_nether_bricks
fill 506 186 458 507 187 458 minecraft:orange_concrete
fill 507 186 416 510 187 416 minecraft:netherrack
fill 507 186 417 509 186 417 minecraft:red_nether_bricks
fill 508 186 458 511 189 458 minecraft:netherrack
fill 509 186 457 511 186 457 minecraft:red_nether_bricks
fill 511 186 416 512 187 416 minecraft:orange_concrete
fill 511 186 417 511 186 419 minecraft:red_nether_bricks
fill 511 186 421 511 186 423 minecraft:red_nether_bricks
fill 511 186 425 511 186 427 minecraft:red_nether_bricks
fill 511 186 429 511 186 431 minecraft:red_nether_bricks
fill 511 186 433 511 186 435 minecraft:red_nether_bricks
fill 511 186 437 511 186 439 minecraft:red_nether_bricks
fill 511 186 441 511 186 443 minecraft:red_nether_bricks
fill 511 186 445 511 186 447 minecraft:red_nether_bricks
fill 511 186 449 511 186 451 minecraft:red_nether_bricks
fill 511 186 453 511 186 455 minecraft:red_nether_bricks
setblock 512 186 417 minecraft:netherrack
setblock 512 186 418 minecraft:red_nether_bricks
fill 512 186 419 512 188 421 minecraft:netherrack
setblock 512 186 422 minecraft:red_nether_bricks
fill 512 186 423 512 186 424 minecraft:orange_concrete
fill 512 186 425 512 187 426 minecraft:netherrack
fill 512 186 427 512 187 427 minecraft:orange_concrete
fill 512 186 428 512 186 434 minecraft:netherrack
fill 512 186 435 512 187 436 minecraft:orange_concrete
fill 512 186 437 512 186 443 minecraft:netherrack
setblock 512 186 444 minecraft:orange_concrete
fill 512 186 445 512 191 446 minecraft:netherrack
fill 512 186 447 512 187 448 minecraft:orange_concrete
fill 512 186 449 512 187 453 minecraft:netherrack
setblock 512 186 454 minecraft:red_nether_bricks
fill 512 186 455 512 186 456 minecraft:orange_concrete
fill 512 186 457 512 191 457 minecraft:netherrack
setblock 512 186 458 minecraft:red_nether_bricks
fill 470 187 416 470 187 417 minecraft:netherrack
fill 470 187 418 470 187 419 minecraft:orange_concrete
fill 470 187 420 470 187 421 minecraft:netherrack
setblock 470 187 422 minecraft:orange_concrete
fill 470 187 423 470 187 424 minecraft:netherrack
setblock 470 187 429 minecraft:netherrack
setblock 470 187 432 minecraft:red_nether_bricks
fill 470 187 433 470 189 435 minecraft:netherrack
setblock 470 187 436 minecraft:red_nether_bricks
fill 470 187 437 470 188 438 minecraft:netherrack
setblock 470 187 439 minecraft:orange_concrete
setblock 470 187 440 minecraft:netherrack
fill 470 187 444 470 187 449 minecraft:netherrack
setblock 470 187 450 minecraft:orange_concrete
fill 470 187 454 470 190 454 minecraft:netherrack
fill 470 187 455 470 188 455 minecraft:red_nether_bricks
setblock 472 187 416 minecraft:orange_concrete
setblock 473 187 416 minecraft:red_nether_bricks
fill 474 187 416 477 187 416 minecraft:netherrack
fill 476 187 458 476 191 458 minecraft:netherrack
setblock 477 187 458 minecraft:red_nether_bricks
fill 478 187 416 478 188 416 minecraft:red_nether_bricks
fill 478 187 458 479 187 458 minecraft:netherrack
fill 481 187 416 482 187 416 minecraft:netherrack
setblock 483 187 416 minecraft:orange_concrete
setblock 483 187 458 minecraft:orange_concrete
fill 484 187 416 488 188 416 minecraft:netherrack
setblock 486 187 458 minecraft:orange_concrete
fill 487 187 458 487 190 458 minecraft:netherrack
setblock 493 187 458 minecraft:red_nether_bricks
setblock 494 187 458 minecraft:orange_concrete
fill 498 187 424 498 194 424 minecraft:red_nether_bricks
fill 498 187 426 498 191 426 minecraft:red_nether_bricks
fill 498 187 458 502 188 458 minecraft:netherrack
fill 499 187 416 499 190 416 minecraft:netherrack
fill 499 187 423 501 189 423 minecraft:red_nether_bricks
setblock 500 187 416 minecraft:orange_concrete
fill 501 187 427 501 188 428 minecraft:red_nether_bricks
setblock 502 187 416 minecraft:netherrack
fill 503 187 416 504 187 416 minecraft:orange_concrete
setblock 503 187 428 minecraft:red_nether_bricks
setblock 503 187 458 minecraft:red_nether_bricks
fill 504 187 458 505 187 458 minecraft:netherrack
fill 506 187 416 506 188 416 minecraft:netherrack
setblock 512 187 417 minecraft:red_nether_bricks
setblock 512 187 418 minecraft:netherrack
fill 512 187 422 512 187 424 minecraft:netherrack
setblock 512 187 428 minecraft:orange_concrete
fill 512 187 429 512 187 434 minecraft:netherrack
fill 512 187 437 512 187 438 minecraft:netherrack
setblock 512 187 439 minecraft:orange_concrete
fill 512 187 440 512 187 444 minecraft:netherrack
fill 512 187 454 512 187 455 minecraft:netherrack
setblock 512 187 456 minecraft:orange_concrete
fill 512 187 458 512 188 458 minecraft:netherrack
setblock 470 188 416 minecraft:netherrack
fill 470 188 417 470 189 417 minecraft:orange_concrete
fill 470 188 418 470 193 419 minecraft:netherrack
setblock 470 188 420 minecraft:orange_concrete
fill 470 188 421 470 191 422 minecraft:netherrack
setblock 470 188 423 minecraft:red_nether_bricks
fill 470 188 424 470 189 427 minecraft:netherrack
fill 470 188 428 470 189 429 minecraft:orange_concrete
setblock 470 188 430 minecraft:red_nether_bricks
fill 470 188 431 470 191 432 minecraft:netherrack
setblock 470 188 436 minecraft:netherrack
setblock 470 188 439 minecraft:red_nether_bricks
fill 470 188 440 470 188 441 minecraft:orange_concrete
fill 470 188 442 470 191 444 minecraft:netherrack
setblock 470 188 445 minecraft:red_nether_bricks
fill 470 188 446 470 189 447 minecraft:netherrack
fill 470 188 448 470 189 449 minecraft:orange_concrete
fill 470 188 450 470 193 451 minecraft:netherrack
setblock 470 188 452 minecraft:orange_concrete
setblock 470 188 453 minecraft:red_nether_bricks
setblock 471 188 416 minecraft:red_nether_bricks
fill 471 188 458 471 189 458 minecraft:netherrack
fill 472 188 416 472 193 416 minecraft:netherrack
fill 472 188 458 473 189 458 minecraft:orange_concrete
fill 473 188 416 474 189 416 minecraft:orange_concrete
fill 474 188 458 475 193 458 minecraft:netherrack
fill 475 188 416 477 189 416 minecraft:netherrack
fill 477 188 458 478 189 458 minecraft:netherrack
fill 479 188 416 480 193 416 minecraft:netherrack
setblock 479 188 458 minecraft:red_nether_bricks
setblock 480 188 458 minecraft:netherrack
fill 481 188 416 482 188 416 minecraft:orange_concrete
fill 481 188 458 481 189 458 minecraft:orange_concrete
fill 482 188 458 483 189 458 minecraft:netherrack
fill 483 188 416 483 193 416 minecraft:netherrack
fill 484 188 458 485 188 458 minecraft:orange_concrete
fill 486 188 458 486 193 458 minecraft:netherrack
fill 488 188 458 489 191 458 minecraft:netherrack
setblock 490 188 458 minecraft:red_nether_bricks
fill 491 188 416 492 193 416 minecraft:netherrack
fill 491 188 458 491 189 458 minecraft:netherrack
fill 492 188 458 493 189 458 minecraft:orange_concrete
fill 493 188 416 494 189 416 minecraft:orange_concrete
fill 494 188 458 494 193 458 minecraft:netherrack
fill 495 188 416 498 189 416 minecraft:netherrack
fill 495 188 458 496 188 458 minecraft:red_nether_bricks
fill 497 188 423 497 194 425 minecraft:red_nether_bricks
fill 497 188 458 497 191 458 minecraft:netherrack
fill 498 188 423 498 194 423 minecraft:red_nether_bricks
fill 499 188 422 499 192 422 minecraft:red_nether_bricks
fill 500 188 416 500 193 416 minecraft:netherrack
fill 500 188 425 500 189 427 minecraft:red_nether_bricks
fill 501 188 416 502 188 416 minecraft:orange_concrete
setblock 502 188 427 minecraft:red_nether_bricks
fill 502 188 428 503 189 428 minecraft:magma_block
fill 503 188 416 504 189 416 minecraft:netherrack
fill 503 188 427 503 189 427 minecraft:magma_block
fill 503 188 458 503 189 458 minecraft:netherrack
fill 504 188 458 505 188 458 minecraft:orange_concrete
fill 505 188 416 505 189 416 minecraft:orange_concrete
setblock 506 188 458 minecraft:red_nether_bricks
fill 507 188 416 507 189 416 minecraft:netherrack
fill 507 188 458 507 193 458 minecraft:netherrack
fill 508 188 416 509 188 416 minecraft:red_nether_bricks
fill 510 188 416 512 191 416 minecraft:netherrack
fill 512 188 417 512 189 418 minecraft:orange_concrete
fill 512 188 422 512 191 422 minecraft:netherrack
setblock 512 188 423 minecraft:red_nether_bricks
fill 512 188 424 512 190 425 minecraft:netherrack
setblock 512 188 426 minecraft:orange_concrete
fill 512 188 427 512 193 428 minecraft:netherrack
fill 512 188 429 512 189 430 minecraft:orange_concrete
fill 512 188 431 512 189 436 minecraft:netherrack
fill 512 188 437 512 188 438 minecraft:orange_concrete
fill 512 188 439 512 188 443 minecraft:netherrack
setblock 512 188 444 minecraft:red_nether_bricks
fill 512 188 447 512 193 448 minecraft:netherrack
fill 512 188 449 512 189 450 minecraft:orange_concrete
fill 512 188 451 512 189 454 minecraft:netherrack
setblock 512 188 455 minecraft:red_nether_bricks
fill 512 188 456 512 193 456 minecraft:netherrack
setblock 470 189 416 minecraft:orange_concrete
fill 470 189 420 470 192 420 minecraft:netherrack
fill 470 189 423 470 190 423 minecraft:netherrack
fill 470 189 430 470 193 430 minecraft:netherrack
fill 470 189 436 470 189 437 minecraft:orange_concrete
fill 470 189 438 470 189 439 minecraft:netherrack
setblock 470 189 440 minecraft:orange_concrete
fill 470 189 441 470 192 441 minecraft:netherrack
fill 470 189 445 470 191 445 minecraft:netherrack
fill 470 189 452 470 191 453 minecraft:netherrack
fill 470 189 455 470 190 456 minecraft:netherrack
setblock 470 189 457 minecraft:orange_concrete
setblock 470 189 458 minecraft:netherrack
fill 471 189 416 471 193 416 minecraft:netherrack
fill 478 189 416 478 191 416 minecraft:netherrack
setblock 479 189 458 minecraft:netherrack
setblock 480 189 458 minecraft:orange_concrete
fill 481 189 416 481 192 416 minecraft:netherrack
setblock 482 189 416 minecraft:orange_concrete
setblock 484 189 416 minecraft:netherrack
fill 484 189 458 485 192 458 minecraft:netherrack
fill 485 189 416 486 189 416 minecraft:orange_concrete
fill 487 189 416 488 189 416 minecraft:netherrack
setblock 490 189 458 minecraft:netherrack
fill 495 189 458 496 191 458 minecraft:netherrack
fill 496 189 423 496 195 424 minecraft:red_nether_bricks
fill 497 189 422 498 193 422 minecraft:red_nether_bricks
fill 497 189 426 497 192 426 minecraft:red_nether_bricks
fill 498 189 458 500 189 458 minecraft:netherrack
fill 500 189 422 500 190 422 minecraft:red_nether_bricks
fill 500 189 424 501 190 424 minecraft:red_nether_bricks
fill 501 189 416 502 191 416 minecraft:netherrack
setblock 501 189 427 minecraft:red_nether_bricks
setblock 501 189 458 minecraft:orange_concrete
setblock 502 189 427 minecraft:magma_block
setblock 502 189 458 minecraft:netherrack
setblock 504 189 458 minecraft:orange_concrete
fill 505 189 458 506 192 458 minecraft:netherrack
setblock 506 189 416 minecraft:orange_concrete
fill 508 189 416 509 189 416 minecraft:netherrack
fill 512 189 419 512 189 420 minecraft:netherrack
setblock 512 189 421 minecraft:orange_concrete
setblock 512 189 423 minecraft:netherrack
fill 512 189 426 512 191 426 minecraft:netherrack
fill 512 189 437 512 192 437 minecraft:netherrack
setblock 512 189 438 minecraft:orange_concrete
fill 512 189 439 512 189 440 minecraft:netherrack
fill 512 189 441 512 189 442 minecraft:orange_concrete
fill 512 189 443 512 189 444 minecraft:netherrack
fill 512 189 455 512 190 455 minecraft:netherrack
setblock 512 189 458 minecraft:orange_concrete
fill 470 190 416 470 195 417 minecraft:netherrack
fill 470 190 424 470 191 425 minecraft:netherrack
fill 470 190 426 470 190 427 minecraft:orange_concrete
fill 470 190 428 470 195 429 minecraft:netherrack
fill 470 190 433 470 190 434 minecraft:netherrack
fill 470 190 435 470 191 435 minecraft:orange_concrete
fill 470 190 436 470 195 437 minecraft:netherrack
setblock 470 190 438 minecraft:orange_concrete
fill 470 190 439 470 193 440 minecraft:netherrack
fill 470 190 446 470 191 447 minecraft:orange_concrete
fill 470 190 448 470 195 449 minecraft:netherrack
fill 470 190 457 470 195 457 minecraft:netherrack
fill 470 190 458 471 190 458 minecraft:orange_concrete
fill 472 190 458 473 195 458 minecraft:netherrack
fill 473 190 416 474 195 416 minecraft:netherrack
fill 475 190 416 476 191 416 minecraft:orange_concrete
fill 477 190 416 477 191 416 minecraft:netherrack
fill 477 190 458 477 191 458 minecraft:netherrack
fill 478 190 458 479 191 458 minecraft:orange_concrete
fill 480 190 458 481 195 458 minecraft:netherrack
fill 482 190 416 482 195 416 minecraft:netherrack
setblock 482 190 458 minecraft:orange_concrete
fill 483 190 458 483 193 458 minecraft:netherrack
setblock 484 190 416 minecraft:orange_concrete
fill 485 190 416 486 195 416 minecraft:netherrack
fill 487 190 416 487 191 416 minecraft:orange_concrete
setblock 488 190 416 minecraft:netherrack
fill 490 190 458 491 191 458 minecraft:orange_concrete
fill 492 190 458 493 195 458 minecraft:netherrack
fill 493 190 416 494 195 416 minecraft:netherrack
fill 495 190 416 496 191 416 minecraft:orange_concrete
fill 495 190 423 495 196 424 minecraft:red_nether_bricks
fill 496 190 422 496 196 422 minecraft:red_nether_bricks
fill 496 190 425 496 194 425 minecraft:red_nether_bricks
fill 497 190 416 498 191 416 minecraft:netherrack
setblock 498 190 458 minecraft:netherrack
fill 499 190 423 500 191 423 minecraft:red_nether_bricks
fill 499 190 425 500 190 426 minecraft:red_nether_bricks
fill 499 190 458 499 191 458 minecraft:orange_concrete
fill 500 190 458 501 191 458 minecraft:netherrack
setblock 501 190 425 minecraft:red_nether_bricks
fill 502 190 458 503 190 458 minecraft:orange_concrete
fill 503 190 416 503 193 416 minecraft:netherrack
setblock 503 190 428 minecraft:magma_block
setblock 504 190 416 minecraft:orange_concrete
fill 504 190 458 504 195 458 minecraft:netherrack
fill 505 190 416 506 195 416 minecraft:netherrack
fill 507 190 416 508 191 416 minecraft:orange_concrete
fill 508 190 458 509 191 458 minecraft:netherrack
fill 509 190 416 509 191 416 minecraft:netherrack
fill 510 190 458 511 191 458 minecraft:orange_concrete
fill 512 190 417 512 192 418 minecraft:netherrack
fill 512 190 419 512 190 420 minecraft:orange_concrete
fill 512 190 421 512 195 421 minecraft:netherrack
fill 512 190 423 512 191 423 minecraft:orange_concrete
fill 512 190 429 512 195 430 minecraft:netherrack
fill 512 190 431 512 191 432 minecraft:orange_concrete
fill 512 190 433 512 191 436 minecraft:netherrack
fill 512 190 438 512 193 439 minecraft:netherrack
setblock 512 190 440 minecraft:orange_concrete
fill 512 190 441 512 195 442 minecraft:netherrack
fill 512 190 443 512 191 443 minecraft:orange_concrete
setblock 512 190 444 minecraft:netherrack
fill 512 190 449 512 195 450 minecraft:netherrack
fill 512 190 451 512 190 452 minecraft:orange_concrete
fill 512 190 453 512 191 454 minecraft:netherrack
fill 512 190 458 512 195 458 minecraft:netherrack
setblock 470 191 423 minecraft:orange_concrete
setblock 470 191 426 minecraft:orange_concrete
fill 470 191 427 470 194 427 minecraft:netherrack
setblock 470 191 433 minecraft:netherrack
setblock 470 191 434 minecraft:orange_concrete
fill 470 191 438 470 194 438 minecraft:netherrack
fill 470 191 454 470 191 455 minecraft:orange_concrete
setblock 470 191 456 minecraft:netherrack
setblock 470 191 458 minecraft:orange_concrete
fill 471 191 458 471 194 458 minecraft:netherrack
fill 482 191 458 482 194 458 minecraft:netherrack
fill 484 191 416 484 194 416 minecraft:netherrack
setblock 487 191 458 minecraft:orange_concrete
setblock 488 191 416 minecraft:orange_concrete
fill 494 191 423 494 198 423 minecraft:red_nether_bricks
fill 495 191 422 495 197 422 minecraft:red_nether_bricks
fill 495 191 425 495 195 425 minecraft:red_nether_bricks
fill 496 191 421 497 194 421 minecraft:red_nether_bricks
setblock 498 191 458 minecraft:orange_concrete
setblock 499 191 416 minecraft:orange_concrete
fill 499 191 425 499 191 426 minecraft:red_nether_bricks
fill 500 191 424 500 191 425 minecraft:red_nether_bricks
fill 502 191 458 503 194 458 minecraft:netherrack
fill 504 191 416 504 193 416 minecraft:netherrack
fill 512 191 419 512 194 419 minecraft:netherrack
setblock 512 191 420 minecraft:orange_concrete
setblock 512 191 424 minecraft:orange_concrete
setblock 512 191 425 minecraft:netherrack
fill 512 191 440 512 194 440 minecraft:netherrack
setblock 512 191 444 minecraft:orange_concrete
fill 512 191 451 512 194 451 minecraft:netherrack
setblock 512 191 452 minecraft:orange_concrete
setblock 512 191 455 minecraft:orange_concrete
fill 470 192 421 470 193 421 minecraft:orange_concrete
fill 470 192 422 470 193 423 minecraft:netherrack
fill 470 192 424 470 192 425 minecraft:orange_concrete
fill 470 192 426 470 197 426 minecraft:netherrack
fill 470 192 431 470 193 431 minecraft:netherrack
fill 470 192 432 470 193 433 minecraft:orange_concrete
fill 470 192 434 470 197 435 minecraft:netherrack
fill 470 192 442 470 193 443 minecraft:netherrack
fill 470 192 444 470 192 445 minecraft:orange_concrete
fill 470 192 446 470 197 447 minecraft:netherrack
setblock 470 192 452 minecraft:netherrack
fill 470 192 453 470 193 453 minecraft:orange_concrete
fill 470 192 454 470 197 455 minecraft:netherrack
setblock 470 192 456 minecraft:orange_concrete
fill 470 192 458 470 197 458 minecraft:netherrack
fill 471 192 417 473 192 417 minecraft:red_nether_bricks
fill 471 192 419 471 192 421 minecraft:red_nether_bricks
fill 471 192 423 471 192 425 minecraft:red_nether_bricks
fill 471 192 427 471 192 429 minecraft:red_nether_bricks
fill 471 192 431 471 192 433 minecraft:red_nether_bricks
fill 471 192 435 471 192 437 minecraft:red_nether_bricks
fill 471 192 439 471 192 441 minecraft:red_nether_bricks
fill 471 192 443 471 192 445 minecraft:red_nether_bricks
fill 471 192 447 471 192 449 minecraft:red_nether_bricks
fill 471 192 451 471 192 453 minecraft:red_nether_bricks
fill 471 192 455 471 192 457 minecraft:red_nether_bricks
setblock 473 192 419 minecraft:light[level=14]
setblock 473 192 427 minecraft:light[level=14]
setblock 473 192 435 minecraft:light[level=14]
setblock 473 192 443 minecraft:light[level=14]
setblock 473 192 451 minecraft:light[level=14]
fill 473 192 457 475 192 457 minecraft:red_nether_bricks
fill 475 192 416 476 197 416 minecraft:netherrack
fill 475 192 417 477 192 417 minecraft:red_nether_bricks
fill 476 192 458 477 193 458 minecraft:orange_concrete
fill 477 192 416 478 192 416 minecraft:orange_concrete
fill 477 192 457 479 192 457 minecraft:red_nether_bricks
fill 478 192 458 479 197 458 minecraft:netherrack
fill 479 192 417 481 192 417 minecraft:red_nether_bricks
setblock 481 192 419 minecraft:light[level=14]
setblock 481 192 427 minecraft:light[level=14]
setblock 481 192 435 minecraft:light[level=14]
setblock 481 192 443 minecraft:light[level=14]
setblock 481 192 451 minecraft:light[level=14]
fill 481 192 457 483 192 457 minecraft:red_nether_bricks
fill 483 192 417 485 192 417 minecraft:red_nether_bricks
fill 485 192 457 487 192 457 minecraft:red_nether_bricks
fill 487 192 416 488 197 416 minecraft:netherrack
fill 487 192 417 489 192 417 minecraft:red_nether_bricks
fill 487 192 458 487 197 458 minecraft:netherrack
fill 488 192 458 489 192 458 minecraft:orange_concrete
fill 489 192 416 490 193 416 minecraft:orange_concrete
setblock 489 192 419 minecraft:light[level=14]
setblock 489 192 427 minecraft:light[level=14]
setblock 489 192 435 minecraft:light[level=14]
setblock 489 192 443 minecraft:light[level=14]
setblock 489 192 451 minecraft:light[level=14]
fill 489 192 457 491 192 457 minecraft:red_nether_bricks
fill 490 192 458 491 197 458 minecraft:netherrack
fill 491 192 417 493 192 417 minecraft:red_nether_bricks
fill 493 192 457 495 192 457 minecraft:red_nether_bricks
fill 494 192 422 494 198 422 minecraft:red_nether_bricks
fill 494 192 424 494 197 424 minecraft:red_nether_bricks
fill 495 192 416 496 194 416 minecraft:netherrack
fill 495 192 417 497 192 417 minecraft:red_nether_bricks
fill 495 192 421 495 197 421 minecraft:red_nether_bricks
fill 495 192 458 495 193 458 minecraft:netherrack
fill 496 192 458 497 193 458 minecraft:orange_concrete
fill 497 192 416 498 192 416 minecraft:orange_concrete
setblock 497 192 419 minecraft:light[level=14]
setblock 497 192 427 minecraft:light[level=14]
setblock 497 192 435 minecraft:light[level=14]
setblock 497 192 443 minecraft:light[level=14]
setblock 497 192 451 minecraft:light[level=14]
fill 497 192 457 499 192 457 minecraft:red_nether_bricks
fill 498 192 458 499 197 458 minecraft:netherrack
fill 499 192 416 499 197 416 minecraft:netherrack
fill 499 192 417 501 192 417 minecraft:red_nether_bricks
fill 499 192 423 499 193 423 minecraft:red_nether_bricks
setblock 499 192 425 minecraft:red_nether_bricks
setblock 500 192 458 minecraft:orange_concrete
fill 501 192 416 501 193 416 minecraft:orange_concrete
fill 501 192 457 503 192 457 minecraft:red_nether_bricks
fill 501 192 458 501 195 458 minecraft:netherrack
setblock 502 192 416 minecraft:netherrack
fill 503 192 417 505 192 417 minecraft:red_nether_bricks
setblock 505 192 419 minecraft:light[level=14]
setblock 505 192 435 minecraft:light[level=14]
setblock 505 192 443 minecraft:light[level=14]
setblock 505 192 451 minecraft:light[level=14]
fill 505 192 457 507 192 457 minecraft:red_nether_bricks
fill 507 192 416 508 197 416 minecraft:netherrack
fill 507 192 417 509 192 417 minecraft:red_nether_bricks
fill 508 192 458 509 193 458 minecraft:orange_concrete
fill 509 192 416 510 193 416 minecraft:orange_concrete
fill 509 192 457 511 192 457 minecraft:red_nether_bricks
fill 510 192 458 511 197 458 minecraft:netherrack
fill 511 192 416 512 193 416 minecraft:netherrack
fill 511 192 417 511 192 419 minecraft:red_nether_bricks
fill 511 192 421 511 192 423 minecraft:red_nether_bricks
fill 511 192 425 511 192 427 minecraft:red_nether_bricks
fill 511 192 429 511 192 431 minecraft:red_nether_bricks
fill 511 192 433 511 192 435 minecraft:red_nether_bricks
fill 511 192 437 511 192 439 minecraft:red_nether_bricks
fill 511 192 441 511 192 443 minecraft:red_nether_bricks
fill 511 192 445 511 192 447 minecraft:red_nether_bricks
fill 511 192 449 511 192 451 minecraft:red_nether_bricks
fill 511 192 453 511 192 455 minecraft:red_nether_bricks
fill 512 192 420 512 194 420 minecraft:netherrack
setblock 512 192 422 minecraft:orange_concrete
fill 512 192 423 512 197 424 minecraft:netherrack
fill 512 192 425 512 193 426 minecraft:orange_concrete
fill 512 192 431 512 197 432 minecraft:netherrack
fill 512 192 433 512 192 434 minecraft:orange_concrete
fill 512 192 435 512 193 436 minecraft:netherrack
fill 512 192 443 512 197 444 minecraft:netherrack
fill 512 192 445 512 193 446 minecraft:orange_concrete
fill 512 192 452 512 197 452 minecraft:netherrack
fill 512 192 453 512 192 454 minecraft:orange_concrete
fill 512 192 455 512 197 455 minecraft:netherrack
fill 512 192 457 512 193 457 minecraft:orange_concrete
setblock 470 193 420 minecraft:orange_concrete
fill 470 193 424 470 196 425 minecraft:netherrack
setblock 470 193 441 minecraft:orange_concrete
setblock 470 193 444 minecraft:orange_concrete
fill 470 193 445 470 196 445 minecraft:netherrack
setblock 470 193 452 minecraft:orange_concrete
fill 470 193 456 470 196 456 minecraft:netherrack
fill 477 193 416 477 196 416 minecraft:netherrack
setblock 478 193 416 minecraft:orange_concrete
setblock 481 193 416 minecraft:orange_concrete
fill 484 193 458 485 193 458 minecraft:orange_concrete
setblock 488 193 458 minecraft:orange_concrete
fill 489 193 458 489 196 458 minecraft:netherrack
fill 493 193 421 493 198 424 minecraft:red_nether_bricks
fill 494 193 421 494 198 421 minecraft:red_nether_bricks
fill 494 193 425 494 195 425 minecraft:red_nether_bricks
fill 497 193 416 497 196 416 minecraft:netherrack
setblock 498 193 416 minecraft:orange_concrete
fill 500 193 458 500 196 458 minecraft:netherrack
setblock 502 193 416 minecraft:orange_concrete
setblock 505 193 458 minecraft:orange_concrete
setblock 506 193 458 minecraft:netherrack
setblock 512 193 417 minecraft:orange_concrete
fill 512 193 418 512 195 418 minecraft:netherrack
fill 512 193 422 512 196 422 minecraft:netherrack
fill 512 193 433 512 196 433 minecraft:netherrack
setblock 512 193 434 minecraft:orange_concrete
setblock 512 193 437 minecraft:orange_concrete
fill 512 193 453 512 196 454 minecraft:netherrack
fill 470 194 418 470 195 419 minecraft:orange_concrete
fill 470 194 420 470 199 421 minecraft:netherrack
setblock 470 194 422 minecraft:orange_concrete
fill 470 194 423 470 197 423 minecraft:netherrack
fill 470 194 430 470 195 431 minecraft:orange_concrete
fill 470 194 432 470 199 433 minecraft:netherrack
fill 470 194 439 470 195 439 minecraft:orange_concrete
fill 470 194 440 470 195 441 minecraft:netherrack
fill 470 194 442 470 194 443 minecraft:orange_concrete
fill 470 194 444 470 199 444 minecraft:netherrack
fill 470 194 450 470 195 451 minecraft:orange_concrete
fill 470 194 452 470 199 453 minecraft:netherrack
fill 471 194 416 472 195 416 minecraft:orange_concrete
fill 474 194 458 475 194 458 minecraft:orange_concrete
fill 476 194 458 477 199 458 minecraft:netherrack
fill 478 194 416 478 199 416 minecraft:netherrack
fill 479 194 416 480 194 416 minecraft:orange_concrete
fill 481 194 416 481 199 416 minecraft:netherrack
fill 483 194 416 483 195 416 minecraft:orange_concrete
fill 483 194 458 483 195 458 minecraft:orange_concrete
fill 484 194 458 485 199 458 minecraft:netherrack
setblock 486 194 458 minecraft:orange_concrete
fill 488 194 458 488 199 458 minecraft:netherrack
fill 489 194 416 490 199 416 minecraft:netherrack
fill 491 194 416 492 195 416 minecraft:orange_concrete
fill 492 194 421 492 200 423 minecraft:red_nether_bricks
fill 494 194 420 494 196 420 minecraft:red_nether_bricks
fill 494 194 458 495 195 458 minecraft:orange_concrete
fill 496 194 458 497 199 458 minecraft:netherrack
fill 497 194 422 497 195 422 minecraft:red_nether_bricks
fill 498 194 416 498 196 416 minecraft:netherrack
setblock 500 194 416 minecraft:orange_concrete
fill 501 194 416 502 199 416 minecraft:netherrack
fill 503 194 416 504 195 416 minecraft:orange_concrete
fill 505 194 458 505 199 458 minecraft:netherrack
fill 506 194 458 507 194 458 minecraft:orange_concrete
fill 508 194 458 509 199 458 minecraft:netherrack
fill 509 194 416 510 199 416 minecraft:netherrack
fill 511 194 416 512 194 416 minecraft:orange_concrete
fill 512 194 417 512 195 417 minecraft:netherrack
fill 512 194 425 512 199 426 minecraft:netherrack
fill 512 194 427 512 195 428 minecraft:orange_concrete
fill 512 194 434 512 199 434 minecraft:netherrack
fill 512 194 435 512 194 436 minecraft:orange_concrete
fill 512 194 437 512 195 438 minecraft:netherrack
fill 512 194 439 512 195 439 minecraft:orange_concrete
fill 512 194 445 512 199 446 minecraft:netherrack
fill 512 194 447 512 195 448 minecraft:orange_concrete
setblock 512 194 456 minecraft:orange_concrete
fill 512 194 457 512 199 457 minecraft:netherrack
fill 470 195 422 470 198 422 minecraft:netherrack
setblock 470 195 427 minecraft:orange_concrete
setblock 470 195 438 minecraft:orange_concrete
fill 470 195 442 470 198 443 minecraft:netherrack
setblock 471 195 458 minecraft:orange_concrete
setblock 474 195 458 minecraft:orange_concrete
fill 475 195 458 475 198 458 minecraft:netherrack
fill 479 195 416 480 198 416 minecraft:netherrack
setblock 482 195 458 minecraft:orange_concrete
setblock 484 195 416 minecraft:orange_concrete
fill 486 195 458 486 198 458 minecraft:netherrack
fill 491 195 421 491 201 423 minecraft:red_nether_bricks
fill 492 195 424 492 199 424 minecraft:red_nether_bricks
fill 493 195 420 493 197 420 minecraft:red_nether_bricks
setblock 495 195 416 minecraft:orange_concrete
setblock 495 195 420 minecraft:red_nether_bricks
fill 496 195 416 496 197 416 minecraft:netherrack
setblock 496 195 421 minecraft:red_nether_bricks
fill 497 195 423 497 195 424 minecraft:red_nether_bricks
fill 500 195 416 500 198 416 minecraft:netherrack
fill 502 195 458 503 195 458 minecraft:orange_concrete
setblock 506 195 458 minecraft:orange_concrete
fill 507 195 458 507 198 458 minecraft:netherrack
fill 511 195 416 511 198 416 minecraft:netherrack
setblock 512 195 416 minecraft:orange_concrete
fill 512 195 419 512 195 420 minecraft:orange_concrete
fill 512 195 435 512 197 436 minecraft:netherrack
setblock 512 195 440 minecraft:orange_concrete
setblock 512 195 451 minecraft:orange_concrete
fill 512 195 456 512 198 456 minecraft:netherrack
fill 470 196 416 470 197 417 minecraft:orange_concrete
fill 470 196 418 470 201 419 minecraft:netherrack
fill 470 196 427 470 201 427 minecraft:netherrack
fill 470 196 428 470 196 429 minecraft:orange_concrete
fill 470 196 430 470 201 431 minecraft:netherrack
fill 470 196 436 470 197 437 minecraft:orange_concrete
fill 470 196 438 470 201 439 minecraft:netherrack
setblock 470 196 440 minecraft:orange_concrete
fill 470 196 441 470 199 441 minecraft:netherrack
fill 470 196 448 470 197 449 minecraft:orange_concrete
fill 470 196 450 470 201 451 minecraft:netherrack
fill 470 196 457 470 197 457 minecraft:orange_concrete
fill 471 196 416 472 201 416 minecraft:netherrack
fill 471 196 458 471 201 458 minecraft:netherrack
fill 472 196 458 473 196 458 minecraft:orange_concrete
fill 473 196 416 474 197 416 minecraft:orange_concrete
fill 474 196 458 474 201 458 minecraft:netherrack
fill 480 196 458 481 197 458 minecraft:orange_concrete
setblock 482 196 416 minecraft:orange_concrete
fill 482 196 458 483 201 458 minecraft:netherrack
fill 483 196 416 484 201 416 minecraft:netherrack
fill 485 196 416 486 197 416 minecraft:orange_concrete
fill 490 196 421 490 202 423 minecraft:red_nether_bricks
fill 491 196 416 492 201 416 minecraft:netherrack
fill 491 196 424 491 200 424 minecraft:red_nether_bricks
fill 492 196 420 492 199 420 minecraft:red_nether_bricks
fill 492 196 458 493 196 458 minecraft:orange_concrete
fill 493 196 416 494 196 416 minecraft:orange_concrete
fill 494 196 458 495 201 458 minecraft:netherrack
fill 495 196 416 495 201 416 minecraft:netherrack
setblock 496 196 423 minecraft:red_nether_bricks
fill 501 196 458 501 197 458 minecraft:orange_concrete
fill 502 196 458 503 201 458 minecraft:netherrack
fill 503 196 416 504 201 416 minecraft:netherrack
setblock 504 196 458 minecraft:orange_concrete
fill 505 196 416 506 197 416 minecraft:orange_concrete
fill 506 196 458 506 201 458 minecraft:netherrack
schedule function dropper:buildpart/106_5 1t
