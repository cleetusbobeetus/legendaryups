setblock 360 169 238 minecraft:light[level=12]
setblock 360 169 245 minecraft:light[level=12]
setblock 360 169 252 minecraft:light[level=12]
setblock 360 169 259 minecraft:light[level=12]
setblock 360 169 266 minecraft:light[level=12]
fill 364 169 261 369 170 261 minecraft:waxed_oxidized_copper
fill 364 169 265 369 170 265 minecraft:waxed_oxidized_copper
fill 365 169 240 365 169 242 minecraft:light_gray_concrete
fill 366 169 239 368 169 239 minecraft:light_gray_concrete
fill 366 169 243 368 169 243 minecraft:light_gray_concrete
setblock 367 169 231 minecraft:light[level=12]
setblock 367 169 238 minecraft:light[level=12]
setblock 367 169 245 minecraft:light[level=12]
setblock 367 169 252 minecraft:light[level=12]
setblock 367 169 259 minecraft:light[level=12]
setblock 367 169 266 minecraft:light[level=12]
fill 369 169 240 369 169 242 minecraft:light_gray_concrete
fill 371 169 262 371 170 264 minecraft:waxed_oxidized_copper
fill 329 170 229 329 233 229 minecraft:stone_bricks
setblock 330 170 242 minecraft:green_concrete
fill 340 171 249 341 172 250 minecraft:white_stained_glass
fill 342 171 249 342 172 249 minecraft:white_stained_glass
fill 366 171 265 368 176 265 minecraft:iron_block
setblock 371 171 249 minecraft:mossy_cobblestone
setblock 371 171 250 minecraft:cobblestone
fill 371 171 262 371 188 264 minecraft:stone_bricks
fill 329 172 262 329 190 264 minecraft:stone_bricks
setblock 330 172 257 minecraft:lime_terracotta
setblock 363 172 228 minecraft:mossy_cobblestone
fill 366 172 263 368 187 264 minecraft:iron_block
setblock 371 172 234 minecraft:mossy_stone_bricks
fill 371 172 249 371 174 250 minecraft:stone_bricks
setblock 329 173 235 minecraft:mossy_cobblestone
setblock 329 173 240 minecraft:cobblestone
fill 363 173 228 363 242 228 minecraft:stone_bricks
fill 365 173 263 365 173 265 minecraft:light_gray_concrete
fill 366 173 262 368 173 262 minecraft:light_gray_concrete
fill 366 173 266 368 173 266 minecraft:light_gray_concrete
fill 369 173 240 370 174 242 minecraft:iron_block
fill 369 173 263 369 173 265 minecraft:light_gray_concrete
fill 371 173 234 371 190 234 minecraft:stone_bricks
setblock 371 173 258 minecraft:mossy_cobblestone
fill 329 174 235 329 202 235 minecraft:stone_bricks
fill 329 174 240 329 222 240 minecraft:stone_bricks
setblock 329 174 265 minecraft:mossy_cobblestone
fill 329 174 266 329 175 266 minecraft:stone_bricks
setblock 329 174 267 minecraft:mossy_stone_bricks
setblock 329 174 268 minecraft:mossy_cobblestone
setblock 332 174 231 minecraft:light[level=15]
setblock 332 174 239 minecraft:light[level=15]
setblock 332 174 247 minecraft:light[level=15]
setblock 332 174 255 minecraft:light[level=15]
setblock 332 174 263 minecraft:light[level=15]
setblock 340 174 231 minecraft:light[level=15]
setblock 340 174 239 minecraft:light[level=15]
setblock 340 174 247 minecraft:light[level=15]
setblock 340 174 255 minecraft:light[level=15]
setblock 340 174 263 minecraft:light[level=15]
setblock 346 174 228 minecraft:mossy_cobblestone
setblock 348 174 231 minecraft:light[level=15]
setblock 348 174 239 minecraft:light[level=15]
setblock 348 174 247 minecraft:light[level=15]
setblock 348 174 255 minecraft:light[level=15]
setblock 348 174 263 minecraft:light[level=15]
setblock 356 174 231 minecraft:light[level=15]
setblock 356 174 239 minecraft:light[level=15]
setblock 356 174 247 minecraft:light[level=15]
setblock 356 174 255 minecraft:light[level=15]
setblock 356 174 263 minecraft:light[level=15]
setblock 364 174 231 minecraft:light[level=15]
setblock 364 174 239 minecraft:light[level=15]
setblock 364 174 247 minecraft:light[level=15]
setblock 364 174 255 minecraft:light[level=15]
setblock 364 174 263 minecraft:light[level=15]
setblock 365 174 241 minecraft:sea_lantern
fill 371 174 258 371 280 258 minecraft:stone_bricks
fill 329 175 265 329 176 265 minecraft:stone_bricks
fill 329 175 267 329 176 268 minecraft:stone_bricks
setblock 332 175 231 minecraft:light[level=12]
setblock 332 175 238 minecraft:light[level=12]
setblock 332 175 245 minecraft:light[level=12]
setblock 332 175 252 minecraft:light[level=12]
setblock 332 175 259 minecraft:light[level=12]
setblock 332 175 266 minecraft:light[level=12]
setblock 339 175 231 minecraft:light[level=12]
setblock 339 175 238 minecraft:light[level=12]
setblock 339 175 245 minecraft:light[level=12]
setblock 339 175 252 minecraft:light[level=12]
setblock 339 175 259 minecraft:light[level=12]
setblock 339 175 266 minecraft:light[level=12]
setblock 345 175 228 minecraft:cobblestone
fill 346 175 228 346 205 228 minecraft:stone_bricks
setblock 346 175 231 minecraft:light[level=12]
setblock 346 175 238 minecraft:light[level=12]
setblock 346 175 245 minecraft:light[level=12]
setblock 346 175 252 minecraft:light[level=12]
setblock 346 175 259 minecraft:light[level=12]
setblock 346 175 266 minecraft:light[level=12]
setblock 353 175 231 minecraft:light[level=12]
setblock 353 175 238 minecraft:light[level=12]
setblock 353 175 245 minecraft:light[level=12]
setblock 353 175 252 minecraft:light[level=12]
setblock 353 175 259 minecraft:light[level=12]
setblock 353 175 266 minecraft:light[level=12]
setblock 360 175 231 minecraft:light[level=12]
setblock 360 175 238 minecraft:light[level=12]
setblock 360 175 245 minecraft:light[level=12]
setblock 360 175 252 minecraft:light[level=12]
setblock 360 175 259 minecraft:light[level=12]
setblock 360 175 266 minecraft:light[level=12]
setblock 367 175 231 minecraft:light[level=12]
setblock 367 175 238 minecraft:light[level=12]
setblock 367 175 245 minecraft:light[level=12]
setblock 367 175 252 minecraft:light[level=12]
setblock 367 175 259 minecraft:light[level=12]
setblock 367 175 266 minecraft:light[level=12]
fill 371 175 249 371 199 249 minecraft:stone_bricks
setblock 371 175 250 minecraft:mossy_cobblestone
fill 329 176 266 331 176 266 minecraft:waxed_oxidized_copper
setblock 330 176 269 minecraft:green_concrete
fill 332 176 265 335 179 267 minecraft:gray_concrete
setblock 332 176 269 minecraft:lime_concrete
fill 336 176 266 338 176 266 minecraft:waxed_oxidized_copper
fill 339 176 265 342 179 267 minecraft:gray_concrete
fill 343 176 266 345 176 266 minecraft:waxed_oxidized_copper
fill 345 176 228 345 185 228 minecraft:stone_bricks
fill 346 176 265 349 179 267 minecraft:gray_concrete
fill 350 176 266 352 176 266 minecraft:waxed_oxidized_copper
fill 353 176 265 356 179 267 minecraft:gray_concrete
fill 357 176 266 359 176 266 minecraft:waxed_oxidized_copper
fill 360 176 265 363 179 267 minecraft:gray_concrete
setblock 360 176 270 minecraft:mossy_cobblestone
fill 364 176 266 370 176 266 minecraft:waxed_oxidized_copper
setblock 370 176 237 minecraft:lime_terracotta
fill 371 176 250 371 206 250 minecraft:stone_bricks
fill 329 177 265 330 178 267 minecraft:waxed_oxidized_copper
fill 329 177 268 329 205 268 minecraft:stone_bricks
fill 331 177 265 331 178 267 minecraft:gray_concrete
fill 332 177 264 335 178 264 minecraft:gray_concrete
fill 332 177 268 335 178 268 minecraft:gray_concrete
fill 336 177 265 336 178 267 minecraft:gray_concrete
fill 337 177 265 337 178 267 minecraft:waxed_oxidized_copper
fill 338 177 265 338 178 267 minecraft:gray_concrete
fill 339 177 264 342 178 264 minecraft:gray_concrete
fill 339 177 268 342 178 268 minecraft:gray_concrete
fill 343 177 265 343 178 267 minecraft:gray_concrete
fill 344 177 265 344 178 267 minecraft:waxed_oxidized_copper
fill 345 177 265 345 178 267 minecraft:gray_concrete
fill 346 177 264 349 178 264 minecraft:gray_concrete
fill 346 177 268 349 178 268 minecraft:gray_concrete
fill 350 177 265 350 178 267 minecraft:gray_concrete
fill 351 177 265 351 178 267 minecraft:waxed_oxidized_copper
fill 352 177 265 352 178 267 minecraft:gray_concrete
fill 353 177 264 356 178 264 minecraft:gray_concrete
fill 353 177 268 356 178 268 minecraft:gray_concrete
fill 357 177 265 357 178 267 minecraft:gray_concrete
fill 358 177 265 358 178 267 minecraft:waxed_oxidized_copper
fill 359 177 265 359 178 267 minecraft:gray_concrete
setblock 360 177 228 minecraft:mossy_cobblestone
fill 360 177 264 363 178 264 minecraft:gray_concrete
fill 360 177 268 363 178 268 minecraft:gray_concrete
fill 360 177 270 360 249 270 minecraft:stone_bricks
fill 364 177 265 364 178 267 minecraft:gray_concrete
fill 365 177 240 365 177 242 minecraft:light_gray_concrete
fill 365 177 265 370 178 267 minecraft:waxed_oxidized_copper
fill 366 177 239 368 177 239 minecraft:light_gray_concrete
fill 366 177 243 368 177 243 minecraft:light_gray_concrete
fill 369 177 240 369 177 242 minecraft:light_gray_concrete
fill 371 177 266 371 178 266 minecraft:waxed_oxidized_copper
setblock 339 178 270 minecraft:mossy_cobblestone
fill 340 178 270 340 224 270 minecraft:stone_bricks
setblock 349 178 270 minecraft:mossy_cobblestone
fill 360 178 228 360 197 228 minecraft:stone_bricks
fill 365 178 263 365 178 264 minecraft:light_gray_concrete
fill 366 178 228 367 187 228 minecraft:stone_bricks
fill 366 178 262 368 178 262 minecraft:light_gray_concrete
setblock 368 178 228 minecraft:cobblestone
fill 369 178 263 369 178 264 minecraft:light_gray_concrete
setblock 371 178 260 minecraft:mossy_stone_bricks
setblock 329 179 250 minecraft:mossy_stone_bricks
fill 329 179 265 329 221 265 minecraft:stone_bricks
fill 329 179 266 331 179 266 minecraft:waxed_oxidized_copper
fill 329 179 267 329 208 267 minecraft:stone_bricks
fill 336 179 266 338 179 266 minecraft:waxed_oxidized_copper
fill 339 179 270 339 280 270 minecraft:stone_bricks
fill 343 179 266 345 179 266 minecraft:waxed_oxidized_copper
fill 349 179 270 349 184 270 minecraft:stone_bricks
fill 350 179 266 352 179 266 minecraft:waxed_oxidized_copper
setblock 355 179 270 minecraft:cobblestone
fill 357 179 266 359 179 266 minecraft:waxed_oxidized_copper
fill 364 179 266 370 179 266 minecraft:waxed_oxidized_copper
fill 366 179 265 368 189 265 minecraft:iron_block
fill 368 179 228 368 186 228 minecraft:stone_bricks
fill 371 179 260 371 280 260 minecraft:stone_bricks
fill 371 179 266 371 222 266 minecraft:stone_bricks
fill 329 180 250 329 239 250 minecraft:stone_bricks
fill 329 180 266 329 197 266 minecraft:stone_bricks
setblock 330 180 258 minecraft:green_concrete
fill 347 180 266 347 189 266 minecraft:iron_block
fill 355 180 270 355 198 270 minecraft:stone_bricks
setblock 329 181 230 minecraft:cobblestone
setblock 332 181 231 minecraft:light[level=15]
setblock 332 181 238 minecraft:light[level=12]
setblock 332 181 239 minecraft:light[level=15]
setblock 332 181 245 minecraft:light[level=12]
setblock 332 181 247 minecraft:light[level=15]
setblock 332 181 252 minecraft:light[level=12]
setblock 332 181 255 minecraft:light[level=15]
setblock 332 181 259 minecraft:light[level=12]
setblock 332 181 263 minecraft:light[level=15]
setblock 332 181 266 minecraft:light[level=12]
setblock 339 181 231 minecraft:light[level=12]
setblock 339 181 238 minecraft:light[level=12]
setblock 339 181 245 minecraft:light[level=12]
setblock 339 181 252 minecraft:light[level=12]
setblock 339 181 259 minecraft:light[level=12]
setblock 339 181 266 minecraft:light[level=12]
setblock 340 181 231 minecraft:light[level=15]
setblock 340 181 239 minecraft:light[level=15]
setblock 340 181 247 minecraft:light[level=15]
setblock 340 181 255 minecraft:light[level=15]
setblock 340 181 263 minecraft:light[level=15]
setblock 346 181 231 minecraft:light[level=12]
setblock 346 181 238 minecraft:light[level=12]
setblock 346 181 245 minecraft:light[level=12]
setblock 346 181 252 minecraft:light[level=12]
setblock 346 181 259 minecraft:light[level=12]
setblock 346 181 266 minecraft:light[level=12]
setblock 348 181 231 minecraft:light[level=15]
setblock 348 181 239 minecraft:light[level=15]
setblock 348 181 247 minecraft:light[level=15]
setblock 348 181 255 minecraft:light[level=15]
setblock 348 181 263 minecraft:light[level=15]
setblock 353 181 231 minecraft:light[level=12]
setblock 353 181 238 minecraft:light[level=12]
setblock 353 181 245 minecraft:light[level=12]
setblock 353 181 252 minecraft:light[level=12]
setblock 353 181 259 minecraft:light[level=12]
setblock 353 181 266 minecraft:light[level=12]
setblock 356 181 231 minecraft:light[level=15]
setblock 356 181 239 minecraft:light[level=15]
setblock 356 181 247 minecraft:light[level=15]
setblock 356 181 255 minecraft:light[level=15]
setblock 356 181 263 minecraft:light[level=15]
setblock 360 181 231 minecraft:light[level=12]
setblock 360 181 238 minecraft:light[level=12]
setblock 360 181 245 minecraft:light[level=12]
setblock 360 181 252 minecraft:light[level=12]
setblock 360 181 259 minecraft:light[level=12]
setblock 360 181 266 minecraft:light[level=12]
setblock 364 181 231 minecraft:light[level=15]
setblock 364 181 239 minecraft:light[level=15]
setblock 364 181 247 minecraft:light[level=15]
setblock 364 181 255 minecraft:light[level=15]
setblock 364 181 263 minecraft:light[level=15]
setblock 367 181 231 minecraft:light[level=12]
setblock 367 181 238 minecraft:light[level=12]
setblock 367 181 245 minecraft:light[level=12]
setblock 367 181 252 minecraft:light[level=12]
setblock 367 181 259 minecraft:light[level=12]
setblock 367 181 266 minecraft:light[level=12]
fill 329 182 230 329 196 230 minecraft:stone_bricks
setblock 362 182 270 minecraft:mossy_stone_bricks
fill 346 183 265 346 183 267 minecraft:light_gray_concrete
fill 347 183 265 348 183 265 minecraft:light_gray_concrete
fill 347 183 267 348 183 267 minecraft:light_gray_concrete
setblock 348 183 266 minecraft:light_gray_concrete
fill 362 183 270 362 280 270 minecraft:stone_bricks
fill 365 183 263 365 183 265 minecraft:light_gray_concrete
fill 366 183 262 368 183 262 minecraft:light_gray_concrete
fill 366 183 266 368 183 266 minecraft:light_gray_concrete
fill 369 183 263 369 183 265 minecraft:light_gray_concrete
setblock 371 183 233 minecraft:mossy_stone_bricks
setblock 348 184 270 minecraft:mossy_stone_bricks
fill 371 184 233 371 202 233 minecraft:stone_bricks
setblock 371 184 256 minecraft:cobblestone
setblock 329 185 239 minecraft:mossy_cobblestone
setblock 341 185 269 minecraft:green_concrete
setblock 348 185 228 minecraft:mossy_cobblestone
fill 348 185 270 348 280 270 minecraft:stone_bricks
setblock 349 185 270 minecraft:mossy_stone_bricks
fill 365 185 240 365 185 242 minecraft:light_gray_concrete
fill 366 185 239 368 185 239 minecraft:light_gray_concrete
fill 366 185 243 368 185 243 minecraft:light_gray_concrete
fill 369 185 240 369 185 242 minecraft:light_gray_concrete
setblock 371 185 242 minecraft:mossy_stone_bricks
setblock 371 185 243 minecraft:cobblestone
fill 371 185 256 371 280 256 minecraft:stone_bricks
fill 329 186 239 329 246 239 minecraft:stone_bricks
setblock 345 186 228 minecraft:mossy_stone_bricks
fill 348 186 228 348 260 228 minecraft:stone_bricks
fill 349 186 270 349 266 270 minecraft:stone_bricks
setblock 357 186 270 minecraft:cobblestone
fill 371 186 242 371 191 243 minecraft:stone_bricks
setblock 329 187 259 minecraft:mossy_stone_bricks
setblock 332 187 231 minecraft:light[level=12]
setblock 332 187 238 minecraft:light[level=12]
setblock 332 187 245 minecraft:light[level=12]
setblock 332 187 252 minecraft:light[level=12]
setblock 332 187 259 minecraft:light[level=12]
setblock 332 187 266 minecraft:light[level=12]
setblock 334 187 270 minecraft:mossy_cobblestone
setblock 339 187 231 minecraft:light[level=12]
setblock 339 187 238 minecraft:light[level=12]
setblock 339 187 245 minecraft:light[level=12]
setblock 339 187 252 minecraft:light[level=12]
setblock 339 187 259 minecraft:light[level=12]
setblock 339 187 266 minecraft:light[level=12]
fill 345 187 228 345 210 228 minecraft:stone_bricks
setblock 346 187 231 minecraft:light[level=12]
setblock 346 187 238 minecraft:light[level=12]
setblock 346 187 245 minecraft:light[level=12]
setblock 346 187 252 minecraft:light[level=12]
setblock 346 187 259 minecraft:light[level=12]
setblock 346 187 266 minecraft:light[level=12]
setblock 353 187 231 minecraft:light[level=12]
setblock 353 187 238 minecraft:light[level=12]
setblock 353 187 245 minecraft:light[level=12]
setblock 353 187 252 minecraft:light[level=12]
setblock 353 187 259 minecraft:light[level=12]
setblock 353 187 266 minecraft:light[level=12]
fill 357 187 270 357 195 270 minecraft:stone_bricks
setblock 360 187 231 minecraft:light[level=12]
setblock 360 187 238 minecraft:light[level=12]
setblock 360 187 245 minecraft:light[level=12]
setblock 360 187 252 minecraft:light[level=12]
setblock 360 187 259 minecraft:light[level=12]
setblock 360 187 266 minecraft:light[level=12]
setblock 366 187 240 minecraft:iron_block
fill 367 187 231 369 190 234 minecraft:gray_concrete
fill 367 187 238 369 190 241 minecraft:gray_concrete
fill 367 187 245 369 190 248 minecraft:gray_concrete
fill 367 187 252 369 190 255 minecraft:gray_concrete
fill 367 187 259 369 190 262 minecraft:gray_concrete
setblock 367 187 266 minecraft:light[level=12]
fill 368 187 228 368 187 230 minecraft:iron_block
fill 368 187 235 368 187 237 minecraft:iron_block
fill 368 187 243 368 187 244 minecraft:iron_block
fill 368 187 249 368 187 251 minecraft:iron_block
fill 368 187 256 368 187 258 minecraft:iron_block
fill 368 187 266 368 190 269 minecraft:iron_block
setblock 370 187 262 minecraft:green_concrete
setblock 371 187 236 minecraft:mossy_cobblestone
fill 329 188 259 329 280 259 minecraft:stone_bricks
setblock 332 188 231 minecraft:light[level=15]
setblock 332 188 239 minecraft:light[level=15]
setblock 332 188 247 minecraft:light[level=15]
setblock 332 188 255 minecraft:light[level=15]
setblock 332 188 263 minecraft:light[level=15]
fill 334 188 270 334 217 270 minecraft:stone_bricks
setblock 340 188 231 minecraft:light[level=15]
setblock 340 188 239 minecraft:light[level=15]
setblock 340 188 247 minecraft:light[level=15]
setblock 340 188 255 minecraft:light[level=15]
setblock 340 188 263 minecraft:light[level=15]
setblock 348 188 231 minecraft:light[level=15]
setblock 348 188 239 minecraft:light[level=15]
setblock 348 188 247 minecraft:light[level=15]
setblock 348 188 255 minecraft:light[level=15]
setblock 348 188 263 minecraft:light[level=15]
setblock 352 188 228 minecraft:cobblestone
setblock 356 188 231 minecraft:light[level=15]
setblock 356 188 239 minecraft:light[level=15]
setblock 356 188 247 minecraft:light[level=15]
setblock 356 188 255 minecraft:light[level=15]
setblock 356 188 263 minecraft:light[level=15]
setblock 364 188 231 minecraft:light[level=15]
setblock 364 188 239 minecraft:light[level=15]
setblock 364 188 247 minecraft:light[level=15]
setblock 364 188 255 minecraft:light[level=15]
setblock 364 188 263 minecraft:light[level=15]
fill 365 188 263 365 188 265 minecraft:light_gray_concrete
fill 366 188 228 366 209 228 minecraft:stone_bricks
fill 366 188 231 366 189 234 minecraft:gray_concrete
fill 366 188 238 366 189 241 minecraft:gray_concrete
fill 366 188 242 366 189 242 minecraft:iron_block
fill 366 188 245 366 189 248 minecraft:gray_concrete
fill 366 188 252 366 189 255 minecraft:gray_concrete
fill 366 188 259 366 189 262 minecraft:gray_concrete
fill 366 188 263 366 189 264 minecraft:iron_block
setblock 366 188 266 minecraft:light_gray_concrete
fill 367 188 228 369 188 229 minecraft:iron_block
fill 367 188 230 369 189 230 minecraft:gray_concrete
fill 367 188 235 369 189 235 minecraft:gray_concrete
fill 367 188 236 369 189 236 minecraft:iron_block
fill 367 188 237 369 189 237 minecraft:gray_concrete
fill 367 188 242 369 189 242 minecraft:gray_concrete
fill 367 188 243 369 189 243 minecraft:iron_block
fill 367 188 244 369 189 244 minecraft:gray_concrete
fill 367 188 249 369 189 249 minecraft:gray_concrete
fill 367 188 250 369 189 250 minecraft:iron_block
fill 367 188 251 369 189 251 minecraft:gray_concrete
fill 367 188 256 369 189 256 minecraft:gray_concrete
fill 367 188 257 369 189 257 minecraft:iron_block
fill 367 188 258 369 189 258 minecraft:gray_concrete
fill 367 188 263 369 189 263 minecraft:gray_concrete
fill 367 188 264 369 189 264 minecraft:iron_block
fill 367 188 266 367 189 269 minecraft:iron_block
fill 368 188 270 368 189 270 minecraft:iron_block
fill 369 188 265 369 189 269 minecraft:iron_block
fill 370 188 231 370 189 234 minecraft:gray_concrete
fill 370 188 238 370 189 241 minecraft:gray_concrete
fill 370 188 245 370 189 248 minecraft:gray_concrete
fill 370 188 252 370 189 255 minecraft:gray_concrete
fill 370 188 259 370 189 262 minecraft:gray_concrete
fill 371 188 236 371 193 236 minecraft:stone_bricks
fill 352 189 228 352 280 228 minecraft:stone_bricks
setblock 362 189 269 minecraft:lime_concrete
fill 367 189 228 369 189 228 minecraft:iron_block
setblock 367 189 229 minecraft:green_concrete
fill 368 189 229 369 189 229 minecraft:iron_block
setblock 370 189 249 minecraft:green_concrete
setblock 371 189 251 minecraft:mossy_stone_bricks
setblock 371 189 262 minecraft:mossy_stone_bricks
fill 371 189 263 371 221 264 minecraft:stone_bricks
setblock 349 190 228 minecraft:cobblestone
fill 367 190 228 367 206 228 minecraft:stone_bricks
fill 368 190 228 368 190 230 minecraft:iron_block
fill 368 190 235 368 190 237 minecraft:iron_block
fill 368 190 242 368 190 244 minecraft:iron_block
fill 368 190 249 368 190 251 minecraft:iron_block
fill 368 190 256 368 190 258 minecraft:iron_block
fill 368 190 263 368 190 265 minecraft:iron_block
fill 368 190 270 368 269 270 minecraft:stone_bricks
fill 369 190 228 369 280 228 minecraft:stone_bricks
setblock 371 190 245 minecraft:mossy_stone_bricks
fill 371 190 251 371 280 251 minecraft:stone_bricks
fill 371 190 262 371 210 262 minecraft:stone_bricks
setblock 329 191 262 minecraft:mossy_stone_bricks
fill 329 191 263 329 220 264 minecraft:stone_bricks
setblock 330 191 270 minecraft:cobblestone
fill 349 191 228 349 223 228 minecraft:stone_bricks
fill 368 191 228 368 280 228 minecraft:stone_bricks
setblock 371 191 234 minecraft:mossy_stone_bricks
fill 371 191 245 371 213 245 minecraft:stone_bricks
fill 329 192 262 329 221 262 minecraft:stone_bricks
setblock 330 192 259 minecraft:lime_terracotta
fill 330 192 270 330 222 270 minecraft:stone_bricks
fill 371 192 234 371 202 234 minecraft:stone_bricks
fill 371 192 242 371 212 242 minecraft:stone_bricks
setblock 371 192 243 minecraft:mossy_cobblestone
setblock 332 193 231 minecraft:light[level=12]
setblock 332 193 238 minecraft:light[level=12]
setblock 332 193 245 minecraft:light[level=12]
setblock 332 193 252 minecraft:light[level=12]
setblock 332 193 259 minecraft:light[level=12]
setblock 332 193 266 minecraft:light[level=12]
setblock 339 193 231 minecraft:light[level=12]
setblock 339 193 238 minecraft:light[level=12]
setblock 339 193 245 minecraft:light[level=12]
setblock 339 193 252 minecraft:light[level=12]
setblock 339 193 259 minecraft:light[level=12]
setblock 339 193 266 minecraft:light[level=12]
setblock 346 193 231 minecraft:light[level=12]
setblock 346 193 238 minecraft:light[level=12]
setblock 346 193 245 minecraft:light[level=12]
setblock 346 193 252 minecraft:light[level=12]
setblock 346 193 259 minecraft:light[level=12]
setblock 346 193 266 minecraft:light[level=12]
setblock 353 193 231 minecraft:light[level=12]
setblock 353 193 238 minecraft:light[level=12]
setblock 353 193 245 minecraft:light[level=12]
setblock 353 193 252 minecraft:light[level=12]
setblock 353 193 259 minecraft:light[level=12]
setblock 353 193 266 minecraft:light[level=12]
setblock 360 193 231 minecraft:light[level=12]
setblock 360 193 238 minecraft:light[level=12]
setblock 360 193 245 minecraft:light[level=12]
setblock 360 193 252 minecraft:light[level=12]
setblock 360 193 259 minecraft:light[level=12]
setblock 360 193 266 minecraft:light[level=12]
setblock 367 193 231 minecraft:light[level=12]
setblock 367 193 238 minecraft:light[level=12]
setblock 367 193 245 minecraft:light[level=12]
setblock 367 193 252 minecraft:light[level=12]
setblock 367 193 259 minecraft:light[level=12]
setblock 367 193 266 minecraft:light[level=12]
fill 371 193 243 371 202 243 minecraft:stone_bricks
setblock 333 194 228 minecraft:mossy_stone_bricks
setblock 371 194 236 minecraft:cobblestone
setblock 332 195 231 minecraft:light[level=15]
setblock 332 195 239 minecraft:light[level=15]
setblock 332 195 247 minecraft:light[level=15]
setblock 332 195 255 minecraft:light[level=15]
setblock 332 195 263 minecraft:light[level=15]
fill 333 195 228 333 208 228 minecraft:stone_bricks
setblock 340 195 231 minecraft:light[level=15]
setblock 340 195 239 minecraft:light[level=15]
setblock 340 195 247 minecraft:light[level=15]
setblock 340 195 255 minecraft:light[level=15]
setblock 340 195 263 minecraft:light[level=15]
setblock 341 195 228 minecraft:mossy_cobblestone
fill 342 195 248 348 195 254 minecraft:gray_concrete
fill 343 195 246 361 195 247 minecraft:gray_concrete
fill 343 195 255 361 195 256 minecraft:gray_concrete
fill 344 195 245 360 195 245 minecraft:gray_concrete
fill 344 195 257 360 195 257 minecraft:gray_concrete
fill 345 195 244 359 195 244 minecraft:gray_concrete
fill 345 195 258 359 195 258 minecraft:gray_concrete
fill 346 195 243 358 195 243 minecraft:gray_concrete
fill 346 195 259 358 195 259 minecraft:gray_concrete
fill 347 195 242 357 195 242 minecraft:gray_concrete
fill 347 195 260 357 195 260 minecraft:gray_concrete
setblock 348 195 231 minecraft:light[level=15]
setblock 348 195 239 minecraft:light[level=15]
setblock 348 195 263 minecraft:light[level=15]
fill 349 195 241 355 195 241 minecraft:gray_concrete
fill 349 195 248 349 196 249 minecraft:gray_concrete
fill 349 195 253 349 196 254 minecraft:gray_concrete
fill 349 195 261 355 195 261 minecraft:gray_concrete
fill 350 195 248 350 196 248 minecraft:gray_concrete
fill 350 195 254 350 196 254 minecraft:gray_concrete
fill 354 195 248 362 195 248 minecraft:gray_concrete
fill 354 195 254 362 195 254 minecraft:gray_concrete
fill 355 195 249 362 195 249 minecraft:gray_concrete
fill 355 195 253 362 195 253 minecraft:gray_concrete
setblock 356 195 231 minecraft:light[level=15]
setblock 356 195 239 minecraft:light[level=15]
fill 356 195 250 362 195 252 minecraft:gray_concrete
setblock 356 195 263 minecraft:light[level=15]
setblock 364 195 231 minecraft:light[level=15]
setblock 364 195 239 minecraft:light[level=15]
setblock 364 195 247 minecraft:light[level=15]
setblock 364 195 255 minecraft:light[level=15]
setblock 364 195 263 minecraft:light[level=15]
fill 371 195 236 371 280 236 minecraft:stone_bricks
setblock 337 196 228 minecraft:mossy_stone_bricks
fill 341 196 228 341 263 228 minecraft:stone_bricks
fill 342 196 248 342 197 254 minecraft:iron_block
fill 343 196 246 343 197 247 minecraft:iron_block
fill 343 196 248 348 196 254 minecraft:gray_concrete
fill 343 196 255 343 197 256 minecraft:iron_block
fill 344 196 245 344 197 245 minecraft:iron_block
fill 344 196 246 360 196 247 minecraft:gray_concrete
fill 344 196 255 360 196 256 minecraft:gray_concrete
fill 344 196 257 344 197 257 minecraft:iron_block
fill 345 196 244 345 197 244 minecraft:iron_block
fill 345 196 245 359 196 245 minecraft:gray_concrete
fill 345 196 257 359 196 257 minecraft:gray_concrete
fill 345 196 258 345 197 258 minecraft:iron_block
fill 346 196 243 346 197 243 minecraft:iron_block
fill 346 196 244 358 196 244 minecraft:gray_concrete
fill 346 196 258 358 196 258 minecraft:gray_concrete
fill 346 196 259 346 197 259 minecraft:iron_block
fill 347 196 242 348 197 242 minecraft:iron_block
fill 347 196 243 357 196 243 minecraft:gray_concrete
fill 347 196 259 357 196 259 minecraft:gray_concrete
fill 347 196 260 348 197 260 minecraft:iron_block
fill 349 196 241 355 197 241 minecraft:iron_block
fill 349 196 242 355 196 242 minecraft:gray_concrete
fill 349 196 260 355 196 260 minecraft:gray_concrete
fill 349 196 261 355 197 261 minecraft:iron_block
setblock 354 196 228 minecraft:cobblestone
fill 354 196 248 361 196 248 minecraft:gray_concrete
fill 354 196 254 361 196 254 minecraft:gray_concrete
fill 355 196 249 361 196 249 minecraft:gray_concrete
fill 355 196 253 361 196 253 minecraft:gray_concrete
fill 356 196 242 357 197 242 minecraft:iron_block
fill 356 196 250 361 196 252 minecraft:gray_concrete
fill 356 196 260 357 197 260 minecraft:iron_block
setblock 357 196 270 minecraft:cobblestone
fill 358 196 243 358 197 243 minecraft:iron_block
fill 358 196 259 358 197 259 minecraft:iron_block
fill 359 196 244 359 197 244 minecraft:iron_block
fill 359 196 258 359 197 258 minecraft:iron_block
fill 360 196 245 360 197 245 minecraft:iron_block
fill 360 196 257 360 197 257 minecraft:iron_block
fill 361 196 246 361 197 247 minecraft:iron_block
fill 361 196 255 361 197 256 minecraft:iron_block
fill 362 196 248 362 197 254 minecraft:iron_block
setblock 371 196 229 minecraft:mossy_cobblestone
setblock 329 197 230 minecraft:mossy_cobblestone
fill 330 197 229 370 197 230 minecraft:stone_bricks
fill 330 197 231 370 197 231 minecraft:mossy_stone_bricks
fill 330 197 232 370 197 233 minecraft:stone_bricks
fill 330 197 234 370 197 234 minecraft:mossy_stone_bricks
fill 330 197 235 370 197 236 minecraft:stone_bricks
fill 330 197 237 370 197 237 minecraft:mossy_stone_bricks
fill 330 197 238 370 197 239 minecraft:stone_bricks
fill 330 197 240 370 197 240 minecraft:mossy_stone_bricks
fill 330 197 241 346 197 242 minecraft:stone_bricks
fill 330 197 243 345 197 243 minecraft:mossy_stone_bricks
fill 330 197 244 343 197 245 minecraft:stone_bricks
fill 330 197 246 342 197 246 minecraft:mossy_stone_bricks
fill 330 197 247 341 197 248 minecraft:stone_bricks
fill 330 197 249 341 197 249 minecraft:mossy_stone_bricks
fill 330 197 250 341 197 251 minecraft:stone_bricks
fill 330 197 252 341 197 252 minecraft:mossy_stone_bricks
fill 330 197 253 341 197 254 minecraft:stone_bricks
fill 330 197 255 342 197 255 minecraft:mossy_stone_bricks
fill 330 197 256 342 197 257 minecraft:stone_bricks
fill 330 197 258 344 197 258 minecraft:mossy_stone_bricks
fill 330 197 259 345 197 260 minecraft:stone_bricks
fill 330 197 261 348 197 261 minecraft:mossy_stone_bricks
fill 330 197 262 370 197 263 minecraft:stone_bricks
fill 330 197 264 370 197 264 minecraft:mossy_stone_bricks
fill 330 197 265 370 197 266 minecraft:stone_bricks
fill 330 197 267 370 197 267 minecraft:mossy_stone_bricks
fill 330 197 268 370 197 269 minecraft:stone_bricks
fill 337 197 228 337 230 228 minecraft:stone_bricks
setblock 342 197 247 minecraft:stone_bricks
setblock 343 197 248 minecraft:light_gray_concrete
setblock 343 197 249 minecraft:gray_concrete
setblock 343 197 250 minecraft:light_gray_concrete
fill 343 197 251 344 197 251 minecraft:iron_block
setblock 343 197 252 minecraft:light_gray_concrete
setblock 343 197 253 minecraft:gray_concrete
setblock 343 197 254 minecraft:light_gray_concrete
setblock 343 197 257 minecraft:stone_bricks
setblock 344 197 244 minecraft:stone_bricks
setblock 344 197 246 minecraft:gray_concrete
setblock 344 197 247 minecraft:light_gray_concrete
setblock 344 197 248 minecraft:gray_concrete
setblock 344 197 249 minecraft:light_gray_concrete
setblock 344 197 250 minecraft:gray_concrete
setblock 344 197 252 minecraft:gray_concrete
setblock 344 197 253 minecraft:light_gray_concrete
setblock 344 197 254 minecraft:gray_concrete
setblock 344 197 255 minecraft:light_gray_concrete
setblock 344 197 256 minecraft:gray_concrete
setblock 345 197 245 minecraft:gray_concrete
setblock 345 197 246 minecraft:light_gray_concrete
setblock 345 197 247 minecraft:gray_concrete
setblock 345 197 248 minecraft:light_gray_concrete
setblock 345 197 249 minecraft:gray_concrete
setblock 345 197 250 minecraft:light_gray_concrete
setblock 345 197 251 minecraft:gray_concrete
setblock 345 197 252 minecraft:light_gray_concrete
setblock 345 197 253 minecraft:gray_concrete
setblock 345 197 254 minecraft:light_gray_concrete
setblock 345 197 255 minecraft:gray_concrete
setblock 345 197 256 minecraft:light_gray_concrete
setblock 345 197 257 minecraft:gray_concrete
setblock 346 197 244 minecraft:gray_concrete
setblock 346 197 245 minecraft:iron_block
setblock 346 197 246 minecraft:gray_concrete
setblock 346 197 247 minecraft:light_gray_concrete
setblock 346 197 248 minecraft:gray_concrete
setblock 346 197 249 minecraft:light_gray_concrete
setblock 346 197 250 minecraft:gray_concrete
setblock 346 197 251 minecraft:light_gray_concrete
setblock 346 197 252 minecraft:gray_concrete
setblock 346 197 253 minecraft:light_gray_concrete
setblock 346 197 254 minecraft:gray_concrete
setblock 346 197 255 minecraft:light_gray_concrete
setblock 346 197 256 minecraft:gray_concrete
setblock 346 197 257 minecraft:iron_block
setblock 346 197 258 minecraft:gray_concrete
setblock 346 197 260 minecraft:stone_bricks
fill 347 197 241 348 197 241 minecraft:stone_bricks
setblock 347 197 243 minecraft:gray_concrete
setblock 347 197 244 minecraft:light_gray_concrete
setblock 347 197 245 minecraft:gray_concrete
setblock 347 197 246 minecraft:light_gray_concrete
setblock 347 197 247 minecraft:gray_concrete
setblock 347 197 248 minecraft:light_gray_concrete
setblock 347 197 249 minecraft:gray_concrete
setblock 347 197 250 minecraft:light_gray_concrete
setblock 347 197 251 minecraft:gray_concrete
setblock 347 197 252 minecraft:light_gray_concrete
setblock 347 197 253 minecraft:gray_concrete
setblock 347 197 254 minecraft:light_gray_concrete
setblock 347 197 255 minecraft:gray_concrete
setblock 347 197 256 minecraft:light_gray_concrete
setblock 347 197 257 minecraft:gray_concrete
setblock 347 197 258 minecraft:light_gray_concrete
setblock 347 197 259 minecraft:gray_concrete
setblock 348 197 243 minecraft:light_gray_concrete
setblock 348 197 244 minecraft:gray_concrete
setblock 348 197 245 minecraft:light_gray_concrete
setblock 348 197 246 minecraft:gray_concrete
setblock 348 197 247 minecraft:light_gray_concrete
setblock 348 197 248 minecraft:gray_concrete
fill 348 197 249 349 197 249 minecraft:yellow_concrete
fill 348 197 250 348 197 252 minecraft:ochre_froglight
fill 348 197 253 349 197 253 minecraft:yellow_concrete
setblock 348 197 254 minecraft:gray_concrete
setblock 348 197 255 minecraft:light_gray_concrete
setblock 348 197 256 minecraft:gray_concrete
setblock 348 197 257 minecraft:light_gray_concrete
setblock 348 197 258 minecraft:gray_concrete
setblock 348 197 259 minecraft:light_gray_concrete
setblock 349 197 242 minecraft:light_gray_concrete
setblock 349 197 243 minecraft:gray_concrete
setblock 349 197 244 minecraft:light_gray_concrete
setblock 349 197 245 minecraft:gray_concrete
setblock 349 197 246 minecraft:light_gray_concrete
setblock 349 197 247 minecraft:gray_concrete
setblock 349 197 248 minecraft:ochre_froglight
setblock 349 197 254 minecraft:ochre_froglight
setblock 349 197 255 minecraft:gray_concrete
setblock 349 197 256 minecraft:light_gray_concrete
setblock 349 197 257 minecraft:gray_concrete
setblock 349 197 258 minecraft:light_gray_concrete
setblock 349 197 259 minecraft:gray_concrete
setblock 349 197 260 minecraft:light_gray_concrete
setblock 350 197 242 minecraft:gray_concrete
setblock 350 197 243 minecraft:light_gray_concrete
setblock 350 197 244 minecraft:gray_concrete
setblock 350 197 245 minecraft:light_gray_concrete
setblock 350 197 246 minecraft:gray_concrete
fill 350 197 247 350 197 248 minecraft:yellow_concrete
fill 350 197 254 350 197 255 minecraft:yellow_concrete
setblock 350 197 256 minecraft:gray_concrete
setblock 350 197 257 minecraft:light_gray_concrete
setblock 350 197 258 minecraft:gray_concrete
setblock 350 197 259 minecraft:light_gray_concrete
setblock 350 197 260 minecraft:gray_concrete
setblock 351 197 242 minecraft:light_gray_concrete
setblock 351 197 243 minecraft:gray_concrete
setblock 351 197 244 minecraft:light_gray_concrete
setblock 351 197 245 minecraft:gray_concrete
setblock 351 197 246 minecraft:light_gray_concrete
fill 351 197 247 353 197 247 minecraft:ochre_froglight
fill 351 197 255 353 197 255 minecraft:ochre_froglight
setblock 351 197 256 minecraft:light_gray_concrete
setblock 351 197 257 minecraft:gray_concrete
setblock 351 197 258 minecraft:light_gray_concrete
setblock 351 197 259 minecraft:gray_concrete
setblock 351 197 260 minecraft:light_gray_concrete
fill 352 197 242 352 198 243 minecraft:iron_block
setblock 352 197 244 minecraft:gray_concrete
setblock 352 197 245 minecraft:light_gray_concrete
setblock 352 197 246 minecraft:gray_concrete
setblock 352 197 256 minecraft:gray_concrete
setblock 352 197 257 minecraft:light_gray_concrete
setblock 352 197 258 minecraft:gray_concrete
fill 352 197 259 352 198 260 minecraft:iron_block
setblock 353 197 242 minecraft:light_gray_concrete
setblock 353 197 243 minecraft:gray_concrete
setblock 353 197 244 minecraft:light_gray_concrete
setblock 353 197 245 minecraft:gray_concrete
setblock 353 197 246 minecraft:light_gray_concrete
setblock 353 197 256 minecraft:light_gray_concrete
setblock 353 197 257 minecraft:gray_concrete
setblock 353 197 258 minecraft:light_gray_concrete
setblock 353 197 259 minecraft:gray_concrete
setblock 353 197 260 minecraft:light_gray_concrete
fill 354 197 228 354 230 228 minecraft:stone_bricks
setblock 354 197 242 minecraft:gray_concrete
setblock 354 197 243 minecraft:light_gray_concrete
setblock 354 197 244 minecraft:gray_concrete
setblock 354 197 245 minecraft:light_gray_concrete
setblock 354 197 246 minecraft:gray_concrete
fill 354 197 247 354 197 248 minecraft:yellow_concrete
fill 354 197 254 354 197 255 minecraft:yellow_concrete
setblock 354 197 256 minecraft:gray_concrete
setblock 354 197 257 minecraft:light_gray_concrete
setblock 354 197 258 minecraft:gray_concrete
setblock 354 197 259 minecraft:light_gray_concrete
setblock 354 197 260 minecraft:gray_concrete
setblock 355 197 242 minecraft:light_gray_concrete
setblock 355 197 243 minecraft:gray_concrete
setblock 355 197 244 minecraft:light_gray_concrete
setblock 355 197 245 minecraft:gray_concrete
setblock 355 197 246 minecraft:light_gray_concrete
setblock 355 197 247 minecraft:gray_concrete
setblock 355 197 248 minecraft:ochre_froglight
fill 355 197 249 356 197 249 minecraft:yellow_concrete
fill 355 197 253 356 197 253 minecraft:yellow_concrete
setblock 355 197 254 minecraft:ochre_froglight
setblock 355 197 255 minecraft:gray_concrete
setblock 355 197 256 minecraft:light_gray_concrete
setblock 355 197 257 minecraft:gray_concrete
setblock 355 197 258 minecraft:light_gray_concrete
setblock 355 197 259 minecraft:gray_concrete
setblock 355 197 260 minecraft:light_gray_concrete
fill 356 197 241 370 197 241 minecraft:stone_bricks
setblock 356 197 243 minecraft:light_gray_concrete
setblock 356 197 244 minecraft:gray_concrete
setblock 356 197 245 minecraft:light_gray_concrete
setblock 356 197 246 minecraft:gray_concrete
setblock 356 197 247 minecraft:light_gray_concrete
setblock 356 197 248 minecraft:gray_concrete
fill 356 197 250 356 197 252 minecraft:ochre_froglight
setblock 356 197 254 minecraft:gray_concrete
setblock 356 197 255 minecraft:light_gray_concrete
setblock 356 197 256 minecraft:gray_concrete
setblock 356 197 257 minecraft:light_gray_concrete
setblock 356 197 258 minecraft:gray_concrete
setblock 356 197 259 minecraft:light_gray_concrete
fill 356 197 261 370 197 261 minecraft:mossy_stone_bricks
setblock 357 197 243 minecraft:gray_concrete
setblock 357 197 244 minecraft:light_gray_concrete
setblock 357 197 245 minecraft:gray_concrete
setblock 357 197 246 minecraft:light_gray_concrete
setblock 357 197 247 minecraft:gray_concrete
setblock 357 197 248 minecraft:light_gray_concrete
setblock 357 197 249 minecraft:gray_concrete
setblock 357 197 250 minecraft:light_gray_concrete
setblock 357 197 251 minecraft:gray_concrete
setblock 357 197 252 minecraft:light_gray_concrete
setblock 357 197 253 minecraft:gray_concrete
setblock 357 197 254 minecraft:light_gray_concrete
setblock 357 197 255 minecraft:gray_concrete
setblock 357 197 256 minecraft:light_gray_concrete
setblock 357 197 257 minecraft:gray_concrete
setblock 357 197 258 minecraft:light_gray_concrete
setblock 357 197 259 minecraft:gray_concrete
fill 357 197 270 357 241 270 minecraft:stone_bricks
fill 358 197 242 370 197 242 minecraft:stone_bricks
setblock 358 197 244 minecraft:gray_concrete
setblock 358 197 245 minecraft:iron_block
setblock 358 197 246 minecraft:gray_concrete
setblock 358 197 247 minecraft:light_gray_concrete
setblock 358 197 248 minecraft:gray_concrete
setblock 358 197 249 minecraft:light_gray_concrete
setblock 358 197 250 minecraft:gray_concrete
setblock 358 197 251 minecraft:light_gray_concrete
setblock 358 197 252 minecraft:gray_concrete
setblock 358 197 253 minecraft:light_gray_concrete
setblock 358 197 254 minecraft:gray_concrete
setblock 358 197 255 minecraft:light_gray_concrete
setblock 358 197 256 minecraft:gray_concrete
setblock 358 197 257 minecraft:iron_block
setblock 358 197 258 minecraft:gray_concrete
fill 358 197 260 370 197 260 minecraft:stone_bricks
fill 359 197 243 370 197 243 minecraft:mossy_stone_bricks
setblock 359 197 245 minecraft:gray_concrete
setblock 359 197 246 minecraft:light_gray_concrete
setblock 359 197 247 minecraft:gray_concrete
setblock 359 197 248 minecraft:light_gray_concrete
setblock 359 197 249 minecraft:gray_concrete
setblock 359 197 250 minecraft:light_gray_concrete
setblock 359 197 251 minecraft:gray_concrete
setblock 359 197 252 minecraft:light_gray_concrete
setblock 359 197 253 minecraft:gray_concrete
setblock 359 197 254 minecraft:light_gray_concrete
setblock 359 197 255 minecraft:gray_concrete
setblock 359 197 256 minecraft:light_gray_concrete
setblock 359 197 257 minecraft:gray_concrete
fill 359 197 259 370 197 259 minecraft:stone_bricks
fill 360 197 244 370 197 244 minecraft:stone_bricks
setblock 360 197 246 minecraft:gray_concrete
setblock 360 197 247 minecraft:light_gray_concrete
setblock 360 197 248 minecraft:gray_concrete
setblock 360 197 249 minecraft:light_gray_concrete
setblock 360 197 250 minecraft:gray_concrete
fill 360 197 251 361 197 251 minecraft:iron_block
setblock 360 197 252 minecraft:gray_concrete
setblock 360 197 253 minecraft:light_gray_concrete
setblock 360 197 254 minecraft:gray_concrete
setblock 360 197 255 minecraft:light_gray_concrete
setblock 360 197 256 minecraft:gray_concrete
fill 360 197 258 370 197 258 minecraft:mossy_stone_bricks
fill 361 197 245 370 197 245 minecraft:stone_bricks
setblock 361 197 248 minecraft:light_gray_concrete
setblock 361 197 249 minecraft:gray_concrete
setblock 361 197 250 minecraft:light_gray_concrete
setblock 361 197 252 minecraft:light_gray_concrete
setblock 361 197 253 minecraft:gray_concrete
setblock 361 197 254 minecraft:light_gray_concrete
fill 361 197 257 370 197 257 minecraft:stone_bricks
fill 362 197 246 370 197 246 minecraft:mossy_stone_bricks
fill 362 197 247 370 197 247 minecraft:stone_bricks
fill 362 197 255 370 197 255 minecraft:mossy_stone_bricks
fill 362 197 256 370 197 256 minecraft:stone_bricks
fill 363 197 248 370 197 248 minecraft:stone_bricks
fill 363 197 249 370 197 249 minecraft:mossy_stone_bricks
fill 363 197 250 370 197 251 minecraft:stone_bricks
fill 363 197 252 370 197 252 minecraft:mossy_stone_bricks
fill 363 197 253 370 197 254 minecraft:stone_bricks
fill 371 197 229 371 259 229 minecraft:stone_bricks
fill 329 198 230 329 223 230 minecraft:stone_bricks
setblock 329 198 257 minecraft:mossy_cobblestone
setblock 329 198 266 minecraft:mossy_stone_bricks
fill 339 198 242 346 206 260 minecraft:smooth_stone
fill 347 198 242 347 206 260 minecraft:oak_planks
fill 348 198 248 348 199 249 minecraft:red_concrete
fill 348 198 253 348 199 254 minecraft:red_concrete
fill 349 198 247 350 199 247 minecraft:red_concrete
fill 349 198 255 350 199 255 minecraft:red_concrete
fill 350 198 246 354 199 246 minecraft:red_concrete
fill 350 198 256 354 199 256 minecraft:red_concrete
setblock 350 198 270 minecraft:mossy_stone_bricks
fill 354 198 247 355 199 247 minecraft:red_concrete
fill 354 198 255 355 199 255 minecraft:red_concrete
fill 356 198 248 356 199 249 minecraft:red_concrete
fill 356 198 253 356 199 254 minecraft:red_concrete
fill 357 198 249 357 199 253 minecraft:red_concrete
fill 358 198 242 358 206 260 minecraft:oak_planks
fill 359 198 242 365 206 260 minecraft:smooth_stone
setblock 360 198 228 minecraft:cobblestone
setblock 329 199 234 minecraft:mossy_stone_bricks
fill 329 199 257 329 265 257 minecraft:stone_bricks
fill 329 199 266 329 200 266 minecraft:stone_bricks
setblock 332 199 231 minecraft:light[level=12]
setblock 332 199 238 minecraft:light[level=12]
setblock 332 199 245 minecraft:light[level=12]
setblock 332 199 252 minecraft:light[level=12]
setblock 332 199 259 minecraft:light[level=12]
setblock 332 199 266 minecraft:light[level=12]
setblock 339 199 231 minecraft:light[level=12]
setblock 339 199 238 minecraft:light[level=12]
setblock 339 199 266 minecraft:light[level=12]
setblock 346 199 231 minecraft:light[level=12]
setblock 346 199 238 minecraft:light[level=12]
setblock 346 199 266 minecraft:light[level=12]
setblock 348 199 247 minecraft:red_concrete
setblock 348 199 251 minecraft:red_concrete
setblock 348 199 255 minecraft:red_concrete
setblock 349 199 246 minecraft:red_concrete
setblock 349 199 248 minecraft:red_concrete
setblock 349 199 254 minecraft:red_concrete
setblock 349 199 256 minecraft:red_concrete
fill 350 199 270 350 227 270 minecraft:stone_bricks
setblock 352 199 247 minecraft:red_concrete
setblock 352 199 255 minecraft:red_concrete
setblock 353 199 231 minecraft:light[level=12]
setblock 353 199 238 minecraft:light[level=12]
setblock 353 199 245 minecraft:light[level=12]
setblock 353 199 259 minecraft:light[level=12]
setblock 353 199 266 minecraft:light[level=12]
setblock 355 199 246 minecraft:red_concrete
setblock 355 199 248 minecraft:red_concrete
setblock 355 199 254 minecraft:red_concrete
setblock 355 199 256 minecraft:red_concrete
setblock 355 199 270 minecraft:mossy_cobblestone
setblock 356 199 247 minecraft:red_concrete
setblock 356 199 251 minecraft:red_concrete
setblock 356 199 255 minecraft:red_concrete
setblock 357 199 248 minecraft:red_concrete
setblock 357 199 254 minecraft:red_concrete
fill 360 199 228 360 280 228 minecraft:stone_bricks
setblock 360 199 231 minecraft:light[level=12]
setblock 360 199 238 minecraft:light[level=12]
setblock 360 199 266 minecraft:light[level=12]
setblock 367 199 231 minecraft:light[level=12]
setblock 367 199 238 minecraft:light[level=12]
setblock 367 199 245 minecraft:light[level=12]
setblock 367 199 252 minecraft:light[level=12]
setblock 367 199 259 minecraft:light[level=12]
setblock 367 199 266 minecraft:light[level=12]
setblock 370 199 249 minecraft:green_concrete
fill 329 200 234 329 202 234 minecraft:stone_bricks
setblock 338 200 229 minecraft:lime_terracotta
setblock 342 200 270 minecraft:mossy_stone_bricks
fill 355 200 270 355 203 270 minecraft:stone_bricks
setblock 371 200 249 minecraft:mossy_stone_bricks
setblock 329 201 266 minecraft:mossy_stone_bricks
fill 332 201 245 334 259 245 minecraft:iron_block
fill 333 201 244 333 259 244 minecraft:iron_block
fill 333 201 246 333 259 246 minecraft:iron_block
setblock 336 201 270 minecraft:cobblestone
fill 340 201 232 340 202 232 minecraft:iron_block
fill 341 201 265 343 220 265 minecraft:iron_block
fill 342 201 264 342 220 264 minecraft:iron_block
fill 342 201 266 342 221 266 minecraft:iron_block
fill 342 201 270 342 216 270 minecraft:stone_bricks
fill 371 201 249 371 280 249 minecraft:stone_bricks
fill 329 202 266 329 221 266 minecraft:stone_bricks
setblock 332 202 231 minecraft:light[level=15]
fill 332 202 233 335 207 235 minecraft:gray_concrete
setblock 332 202 239 minecraft:light[level=15]
setblock 332 202 247 minecraft:light[level=15]
setblock 332 202 255 minecraft:light[level=15]
setblock 332 202 263 minecraft:light[level=15]
fill 336 202 270 336 205 270 minecraft:stone_bricks
fill 339 202 233 342 207 235 minecraft:gray_concrete
setblock 340 202 231 minecraft:light[level=15]
setblock 340 202 239 minecraft:light[level=15]
setblock 340 202 263 minecraft:light[level=15]
fill 346 202 233 349 207 235 minecraft:gray_concrete
setblock 348 202 231 minecraft:light[level=15]
setblock 348 202 239 minecraft:light[level=15]
setblock 348 202 247 minecraft:light[level=15]
setblock 348 202 255 minecraft:light[level=15]
setblock 348 202 263 minecraft:light[level=15]
fill 353 202 233 356 207 235 minecraft:gray_concrete
setblock 356 202 231 minecraft:light[level=15]
setblock 356 202 239 minecraft:light[level=15]
setblock 356 202 247 minecraft:light[level=15]
setblock 356 202 255 minecraft:light[level=15]
setblock 356 202 263 minecraft:light[level=15]
fill 360 202 233 363 207 235 minecraft:gray_concrete
setblock 364 202 231 minecraft:light[level=15]
setblock 364 202 239 minecraft:light[level=15]
setblock 364 202 263 minecraft:light[level=15]
fill 329 203 233 330 203 235 minecraft:iron_block
fill 331 203 233 331 206 235 minecraft:gray_concrete
fill 332 203 232 335 206 232 minecraft:gray_concrete
fill 332 203 236 335 206 236 minecraft:gray_concrete
setblock 332 203 244 minecraft:light_gray_concrete
setblock 332 203 246 minecraft:light_gray_concrete
setblock 334 203 244 minecraft:light_gray_concrete
setblock 334 203 246 minecraft:light_gray_concrete
fill 336 203 233 336 206 235 minecraft:gray_concrete
fill 337 203 233 337 203 235 minecraft:iron_block
fill 338 203 233 338 206 235 minecraft:gray_concrete
fill 339 203 231 341 203 231 minecraft:light_gray_concrete
fill 339 203 232 342 206 232 minecraft:gray_concrete
fill 339 203 236 342 206 236 minecraft:gray_concrete
setblock 341 203 264 minecraft:light_gray_concrete
setblock 341 203 266 minecraft:light_gray_concrete
fill 343 203 233 343 206 235 minecraft:gray_concrete
setblock 343 203 264 minecraft:light_gray_concrete
setblock 343 203 266 minecraft:light_gray_concrete
fill 344 203 233 344 203 235 minecraft:iron_block
fill 345 203 233 345 206 235 minecraft:gray_concrete
fill 346 203 232 349 206 232 minecraft:gray_concrete
fill 346 203 236 349 206 236 minecraft:gray_concrete
fill 350 203 233 350 206 235 minecraft:gray_concrete
fill 351 203 233 351 203 235 minecraft:iron_block
fill 352 203 233 352 206 235 minecraft:gray_concrete
fill 353 203 232 356 206 232 minecraft:gray_concrete
fill 353 203 236 356 206 236 minecraft:gray_concrete
fill 357 203 233 357 206 235 minecraft:gray_concrete
fill 358 203 233 358 203 235 minecraft:iron_block
fill 359 203 233 359 206 235 minecraft:gray_concrete
fill 360 203 232 363 206 232 minecraft:gray_concrete
fill 360 203 236 363 206 236 minecraft:gray_concrete
fill 364 203 233 364 206 235 minecraft:gray_concrete
fill 365 203 233 371 203 235 minecraft:iron_block
setblock 371 203 243 minecraft:mossy_stone_bricks
fill 329 204 232 329 205 236 minecraft:iron_block
fill 330 204 232 330 205 233 minecraft:iron_block
fill 330 204 234 330 205 234 minecraft:gray_concrete
fill 330 204 235 330 205 236 minecraft:iron_block
fill 331 204 232 331 205 232 minecraft:gray_concrete
fill 331 204 236 331 205 236 minecraft:gray_concrete
fill 333 204 231 334 205 231 minecraft:gray_concrete
fill 333 204 237 334 205 237 minecraft:gray_concrete
fill 336 204 232 336 205 232 minecraft:gray_concrete
fill 336 204 236 336 205 236 minecraft:gray_concrete
fill 337 204 232 337 205 233 minecraft:iron_block
fill 337 204 234 337 205 234 minecraft:gray_concrete
fill 337 204 235 337 205 236 minecraft:iron_block
fill 338 204 232 338 205 232 minecraft:gray_concrete
fill 338 204 236 338 205 236 minecraft:gray_concrete
fill 340 204 231 341 205 231 minecraft:gray_concrete
fill 340 204 237 341 205 237 minecraft:gray_concrete
fill 341 204 241 341 205 241 minecraft:light_blue_stained_glass
fill 343 204 232 343 205 232 minecraft:gray_concrete
fill 343 204 236 343 205 236 minecraft:gray_concrete
fill 344 204 232 344 205 233 minecraft:iron_block
fill 344 204 234 344 205 234 minecraft:gray_concrete
fill 344 204 235 344 205 236 minecraft:iron_block
fill 345 204 232 345 205 232 minecraft:gray_concrete
fill 345 204 236 345 205 236 minecraft:gray_concrete
fill 347 204 231 348 205 231 minecraft:gray_concrete
fill 347 204 237 348 205 237 minecraft:gray_concrete
fill 350 204 232 350 205 232 minecraft:gray_concrete
fill 350 204 236 350 205 236 minecraft:gray_concrete
setblock 350 204 269 minecraft:lime_terracotta
fill 351 204 232 351 205 233 minecraft:iron_block
fill 351 204 234 351 205 234 minecraft:gray_concrete
fill 351 204 235 351 205 236 minecraft:iron_block
fill 352 204 232 352 205 232 minecraft:gray_concrete
fill 352 204 236 352 205 236 minecraft:gray_concrete
fill 354 204 231 355 205 231 minecraft:gray_concrete
fill 354 204 237 355 205 237 minecraft:gray_concrete
setblock 355 204 270 minecraft:mossy_stone_bricks
fill 357 204 232 357 205 232 minecraft:gray_concrete
fill 357 204 236 357 205 236 minecraft:gray_concrete
fill 358 204 232 358 205 233 minecraft:iron_block
fill 358 204 234 358 205 234 minecraft:gray_concrete
fill 358 204 235 358 205 236 minecraft:iron_block
fill 359 204 232 359 205 232 minecraft:gray_concrete
fill 359 204 236 359 205 236 minecraft:gray_concrete
fill 361 204 231 362 205 231 minecraft:gray_concrete
fill 361 204 237 362 205 237 minecraft:gray_concrete
fill 364 204 232 364 205 232 minecraft:gray_concrete
fill 364 204 236 364 205 236 minecraft:gray_concrete
fill 365 204 232 370 205 233 minecraft:iron_block
fill 365 204 234 365 205 234 minecraft:gray_concrete
fill 365 204 235 370 205 236 minecraft:iron_block
fill 366 204 234 371 206 234 minecraft:iron_block
setblock 370 204 270 minecraft:mossy_stone_bricks
fill 371 204 233 371 206 233 minecraft:iron_block
fill 371 204 235 371 206 235 minecraft:iron_block
fill 371 204 243 371 280 243 minecraft:stone_bricks
fill 371 204 270 371 280 270 minecraft:stone_bricks
setblock 330 205 238 minecraft:lime_concrete
setblock 332 205 231 minecraft:light[level=12]
setblock 332 205 238 minecraft:light[level=12]
setblock 332 205 252 minecraft:light[level=12]
setblock 332 205 259 minecraft:light[level=12]
setblock 332 205 266 minecraft:light[level=12]
setblock 339 205 231 minecraft:light[level=12]
setblock 339 205 238 minecraft:light[level=12]
setblock 339 205 266 minecraft:light[level=12]
setblock 346 205 231 minecraft:light[level=12]
setblock 346 205 238 minecraft:light[level=12]
setblock 346 205 266 minecraft:light[level=12]
setblock 347 205 229 minecraft:green_concrete
setblock 353 205 231 minecraft:light[level=12]
setblock 353 205 238 minecraft:light[level=12]
setblock 353 205 245 minecraft:light[level=12]
setblock 353 205 252 minecraft:light[level=12]
setblock 353 205 259 minecraft:light[level=12]
setblock 353 205 266 minecraft:light[level=12]
fill 355 205 270 355 232 270 minecraft:stone_bricks
setblock 360 205 231 minecraft:light[level=12]
setblock 360 205 238 minecraft:light[level=12]
setblock 360 205 266 minecraft:light[level=12]
setblock 367 205 231 minecraft:light[level=12]
setblock 367 205 238 minecraft:light[level=12]
setblock 367 205 245 minecraft:light[level=12]
setblock 367 205 252 minecraft:light[level=12]
setblock 367 205 259 minecraft:light[level=12]
setblock 367 205 266 minecraft:light[level=12]
fill 370 205 270 370 280 270 minecraft:stone_bricks
setblock 371 205 268 minecraft:mossy_cobblestone
fill 329 206 232 329 220 232 minecraft:stone_bricks
fill 329 206 233 330 206 235 minecraft:iron_block
fill 329 206 236 329 280 236 minecraft:stone_bricks
setblock 329 206 268 minecraft:mossy_cobblestone
setblock 336 206 270 minecraft:cobblestone
fill 337 206 233 337 206 235 minecraft:iron_block
fill 344 206 233 344 206 235 minecraft:iron_block
setblock 346 206 228 minecraft:mossy_cobblestone
fill 351 206 233 351 206 235 minecraft:iron_block
fill 358 206 233 358 206 235 minecraft:iron_block
setblock 363 206 270 minecraft:cobblestone
fill 365 206 233 365 206 235 minecraft:iron_block
fill 366 206 233 370 206 233 minecraft:iron_block
fill 366 206 235 370 206 235 minecraft:iron_block
setblock 370 206 248 minecraft:lime_concrete
fill 371 206 268 371 265 268 minecraft:stone_bricks
fill 329 207 233 329 274 235 minecraft:stone_bricks
fill 329 207 268 329 224 268 minecraft:stone_bricks
fill 336 207 270 336 252 270 minecraft:stone_bricks
fill 340 207 232 340 259 232 minecraft:iron_block
fill 346 207 228 346 269 228 minecraft:stone_bricks
setblock 356 207 228 minecraft:mossy_cobblestone
fill 363 207 270 363 280 270 minecraft:stone_bricks
setblock 366 207 270 minecraft:mossy_stone_bricks
setblock 367 207 228 minecraft:cobblestone
setblock 370 207 228 minecraft:mossy_stone_bricks
fill 371 207 233 371 214 235 minecraft:stone_bricks
setblock 371 207 250 minecraft:mossy_cobblestone
setblock 336 208 228 minecraft:mossy_cobblestone
fill 339 208 231 339 208 233 minecraft:light_gray_concrete
fill 340 208 231 341 208 231 minecraft:light_gray_concrete
fill 340 208 233 341 208 233 minecraft:light_gray_concrete
setblock 341 208 232 minecraft:light_gray_concrete
fill 356 208 228 356 280 228 minecraft:stone_bricks
fill 366 208 270 366 262 270 minecraft:stone_bricks
fill 367 208 228 367 249 228 minecraft:stone_bricks
fill 370 208 228 370 236 228 minecraft:stone_bricks
fill 371 208 250 371 276 250 minecraft:stone_bricks
setblock 329 209 267 minecraft:cobblestone
setblock 332 209 231 minecraft:light[level=15]
setblock 332 209 239 minecraft:light[level=15]
setblock 332 209 247 minecraft:light[level=15]
setblock 332 209 255 minecraft:light[level=15]
setblock 332 209 263 minecraft:light[level=15]
setblock 333 209 228 minecraft:cobblestone
fill 336 209 228 336 280 228 minecraft:stone_bricks
fill 339 209 249 350 210 250 minecraft:iron_block
setblock 340 209 231 minecraft:light[level=15]
setblock 340 209 239 minecraft:light[level=15]
setblock 340 209 247 minecraft:light[level=15]
setblock 340 209 255 minecraft:light[level=15]
setblock 340 209 263 minecraft:light[level=15]
setblock 341 209 264 minecraft:light_gray_concrete
setblock 341 209 266 minecraft:light_gray_concrete
setblock 343 209 264 minecraft:light_gray_concrete
setblock 343 209 266 minecraft:light_gray_concrete
setblock 348 209 231 minecraft:light[level=15]
setblock 348 209 239 minecraft:light[level=15]
setblock 348 209 247 minecraft:light[level=15]
setblock 348 209 255 minecraft:light[level=15]
setblock 348 209 263 minecraft:light[level=15]
fill 353 209 249 365 210 250 minecraft:iron_block
setblock 356 209 231 minecraft:light[level=15]
setblock 356 209 239 minecraft:light[level=15]
setblock 356 209 247 minecraft:light[level=15]
setblock 356 209 255 minecraft:light[level=15]
setblock 356 209 263 minecraft:light[level=15]
setblock 361 209 270 minecraft:mossy_stone_bricks
setblock 364 209 231 minecraft:light[level=15]
setblock 364 209 239 minecraft:light[level=15]
setblock 364 209 247 minecraft:light[level=15]
setblock 364 209 255 minecraft:light[level=15]
setblock 364 209 263 minecraft:light[level=15]
setblock 370 209 232 minecraft:green_concrete
fill 329 210 267 329 267 267 minecraft:stone_bricks
setblock 332 210 244 minecraft:light_gray_concrete
setblock 332 210 246 minecraft:light_gray_concrete
fill 333 210 228 333 228 228 minecraft:stone_bricks
setblock 334 210 244 minecraft:light_gray_concrete
setblock 334 210 246 minecraft:light_gray_concrete
setblock 352 210 250 minecraft:iron_block
fill 361 210 270 361 263 270 minecraft:stone_bricks
setblock 366 210 228 minecraft:mossy_cobblestone
setblock 332 211 231 minecraft:light[level=12]
setblock 332 211 238 minecraft:light[level=12]
setblock 332 211 252 minecraft:light[level=12]
setblock 332 211 259 minecraft:light[level=12]
setblock 332 211 266 minecraft:light[level=12]
setblock 339 211 231 minecraft:light[level=12]
setblock 339 211 238 minecraft:light[level=12]
setblock 339 211 245 minecraft:light[level=12]
setblock 339 211 252 minecraft:light[level=12]
setblock 339 211 259 minecraft:light[level=12]
setblock 339 211 266 minecraft:light[level=12]
setblock 345 211 228 minecraft:mossy_cobblestone
setblock 346 211 231 minecraft:light[level=12]
setblock 346 211 238 minecraft:light[level=12]
setblock 346 211 245 minecraft:light[level=12]
setblock 346 211 252 minecraft:light[level=12]
setblock 346 211 259 minecraft:light[level=12]
setblock 346 211 266 minecraft:light[level=12]
setblock 353 211 231 minecraft:light[level=12]
setblock 353 211 238 minecraft:light[level=12]
setblock 353 211 245 minecraft:light[level=12]
setblock 353 211 252 minecraft:light[level=12]
setblock 353 211 259 minecraft:light[level=12]
setblock 353 211 266 minecraft:light[level=12]
setblock 360 211 231 minecraft:light[level=12]
setblock 360 211 238 minecraft:light[level=12]
setblock 360 211 245 minecraft:light[level=12]
setblock 360 211 252 minecraft:light[level=12]
setblock 360 211 259 minecraft:light[level=12]
setblock 360 211 266 minecraft:light[level=12]
fill 366 211 228 366 215 228 minecraft:stone_bricks
setblock 367 211 231 minecraft:light[level=12]
setblock 367 211 238 minecraft:light[level=12]
setblock 367 211 245 minecraft:light[level=12]
setblock 367 211 252 minecraft:light[level=12]
setblock 367 211 259 minecraft:light[level=12]
setblock 367 211 266 minecraft:light[level=12]
setblock 370 211 247 minecraft:green_concrete
setblock 371 211 262 minecraft:mossy_stone_bricks
fill 345 212 228 345 280 228 minecraft:stone_bricks
fill 346 212 258 347 213 258 minecraft:white_stained_glass
fill 371 212 262 371 222 262 minecraft:stone_bricks
setblock 331 213 228 minecraft:cobblestone
fill 339 213 231 339 213 233 minecraft:light_gray_concrete
fill 340 213 231 341 213 231 minecraft:light_gray_concrete
fill 340 213 233 341 213 233 minecraft:light_gray_concrete
setblock 341 213 232 minecraft:light_gray_concrete
setblock 355 213 229 minecraft:lime_concrete
setblock 371 213 242 minecraft:mossy_cobblestone
setblock 371 213 267 minecraft:mossy_cobblestone
setblock 330 214 252 minecraft:green_concrete
fill 331 214 228 331 280 228 minecraft:stone_bricks
setblock 336 214 229 minecraft:lime_concrete
setblock 348 214 229 minecraft:lime_concrete
setblock 371 214 231 minecraft:mossy_stone_bricks
fill 371 214 242 371 251 242 minecraft:stone_bricks
setblock 371 214 245 minecraft:mossy_cobblestone
fill 371 214 267 371 280 267 minecraft:stone_bricks
setblock 341 215 264 minecraft:light_gray_concrete
setblock 341 215 266 minecraft:light_gray_concrete
setblock 343 215 264 minecraft:light_gray_concrete
setblock 343 215 266 minecraft:light_gray_concrete
fill 371 215 231 371 218 231 minecraft:stone_bricks
fill 371 215 233 371 280 233 minecraft:stone_bricks
setblock 371 215 234 minecraft:mossy_cobblestone
fill 371 215 235 371 280 235 minecraft:stone_bricks
fill 371 215 245 371 232 245 minecraft:stone_bricks
setblock 332 216 231 minecraft:light[level=15]
setblock 332 216 239 minecraft:light[level=15]
setblock 332 216 247 minecraft:light[level=15]
setblock 332 216 255 minecraft:light[level=15]
setblock 332 216 263 minecraft:light[level=15]
setblock 340 216 231 minecraft:light[level=15]
setblock 340 216 239 minecraft:light[level=15]
setblock 340 216 247 minecraft:light[level=15]
setblock 340 216 255 minecraft:light[level=15]
setblock 340 216 263 minecraft:light[level=15]
setblock 348 216 231 minecraft:light[level=15]
setblock 348 216 239 minecraft:light[level=15]
setblock 348 216 247 minecraft:light[level=15]
setblock 348 216 255 minecraft:light[level=15]
setblock 348 216 263 minecraft:light[level=15]
setblock 356 216 231 minecraft:light[level=15]
setblock 356 216 239 minecraft:light[level=15]
setblock 356 216 247 minecraft:light[level=15]
setblock 356 216 255 minecraft:light[level=15]
setblock 356 216 263 minecraft:light[level=15]
setblock 364 216 231 minecraft:light[level=15]
setblock 364 216 239 minecraft:light[level=15]
setblock 364 216 247 minecraft:light[level=15]
setblock 364 216 255 minecraft:light[level=15]
setblock 364 216 263 minecraft:light[level=15]
setblock 366 216 228 minecraft:mossy_stone_bricks
fill 371 216 234 371 280 234 minecraft:stone_bricks
setblock 332 217 231 minecraft:light[level=12]
setblock 332 217 238 minecraft:light[level=12]
setblock 332 217 244 minecraft:light_gray_concrete
setblock 332 217 246 minecraft:light_gray_concrete
setblock 332 217 252 minecraft:light[level=12]
setblock 332 217 259 minecraft:light[level=12]
setblock 332 217 266 minecraft:light[level=12]
setblock 334 217 244 minecraft:light_gray_concrete
setblock 334 217 246 minecraft:light_gray_concrete
setblock 339 217 231 minecraft:light[level=12]
setblock 339 217 238 minecraft:light[level=12]
setblock 339 217 245 minecraft:light[level=12]
setblock 339 217 252 minecraft:light[level=12]
setblock 339 217 259 minecraft:light[level=12]
setblock 339 217 266 minecraft:light[level=12]
setblock 342 217 270 minecraft:cobblestone
setblock 346 217 231 minecraft:light[level=12]
setblock 346 217 238 minecraft:light[level=12]
setblock 346 217 245 minecraft:light[level=12]
setblock 346 217 252 minecraft:light[level=12]
setblock 346 217 259 minecraft:light[level=12]
setblock 346 217 266 minecraft:light[level=12]
setblock 353 217 231 minecraft:light[level=12]
setblock 353 217 238 minecraft:light[level=12]
setblock 353 217 245 minecraft:light[level=12]
setblock 353 217 252 minecraft:light[level=12]
setblock 353 217 259 minecraft:light[level=12]
setblock 353 217 266 minecraft:light[level=12]
setblock 360 217 231 minecraft:light[level=12]
setblock 360 217 238 minecraft:light[level=12]
setblock 360 217 245 minecraft:light[level=12]
setblock 360 217 252 minecraft:light[level=12]
setblock 360 217 259 minecraft:light[level=12]
setblock 360 217 266 minecraft:light[level=12]
fill 366 217 228 366 280 228 minecraft:stone_bricks
setblock 367 217 231 minecraft:light[level=12]
setblock 367 217 238 minecraft:light[level=12]
setblock 367 217 245 minecraft:light[level=12]
setblock 367 217 252 minecraft:light[level=12]
setblock 367 217 259 minecraft:light[level=12]
setblock 367 217 266 minecraft:light[level=12]
setblock 334 218 270 minecraft:mossy_cobblestone
fill 339 218 231 339 218 233 minecraft:light_gray_concrete
fill 340 218 231 341 218 231 minecraft:light_gray_concrete
fill 340 218 233 341 218 233 minecraft:light_gray_concrete
setblock 341 218 232 minecraft:light_gray_concrete
fill 342 218 270 342 237 270 minecraft:stone_bricks
setblock 347 218 270 minecraft:mossy_stone_bricks
setblock 329 219 255 minecraft:mossy_cobblestone
setblock 330 219 267 minecraft:green_concrete
fill 334 219 270 334 280 270 minecraft:stone_bricks
fill 347 219 270 347 280 270 minecraft:stone_bricks
setblock 370 219 237 minecraft:green_concrete
setblock 371 219 231 minecraft:cobblestone
fill 329 220 251 329 220 252 minecraft:mossy_cobblestone
fill 329 220 255 329 280 255 minecraft:stone_bricks
setblock 370 220 229 minecraft:lime_terracotta
fill 371 220 231 371 268 231 minecraft:stone_bricks
setblock 329 221 232 minecraft:mossy_stone_bricks
fill 329 221 251 329 231 252 minecraft:stone_bricks
setblock 329 221 263 minecraft:stone_bricks
fill 329 221 264 331 221 264 minecraft:iron_block
fill 332 221 263 335 226 265 minecraft:gray_concrete
fill 336 221 264 338 221 264 minecraft:iron_block
fill 339 221 263 342 226 265 minecraft:gray_concrete
setblock 341 221 266 minecraft:light_gray_concrete
fill 343 221 264 343 221 265 minecraft:iron_block
setblock 343 221 266 minecraft:light_gray_concrete
fill 344 221 264 345 221 264 minecraft:iron_block
fill 346 221 263 349 226 265 minecraft:gray_concrete
fill 350 221 264 352 221 264 minecraft:iron_block
fill 353 221 263 356 226 265 minecraft:gray_concrete
fill 357 221 264 359 221 264 minecraft:iron_block
fill 360 221 263 363 226 265 minecraft:gray_concrete
fill 364 221 264 370 221 264 minecraft:iron_block
setblock 364 221 270 minecraft:mossy_cobblestone
setblock 365 221 229 minecraft:lime_concrete
fill 329 222 232 329 258 232 minecraft:stone_bricks
fill 329 222 262 330 222 266 minecraft:iron_block
setblock 331 222 262 minecraft:iron_block
fill 331 222 263 331 225 265 minecraft:gray_concrete
setblock 331 222 266 minecraft:iron_block
fill 332 222 262 335 225 262 minecraft:gray_concrete
fill 332 222 266 335 225 266 minecraft:gray_concrete
fill 336 222 262 338 222 262 minecraft:iron_block
fill 336 222 263 336 225 265 minecraft:gray_concrete
fill 336 222 266 338 222 266 minecraft:iron_block
fill 337 222 263 337 222 265 minecraft:iron_block
fill 338 222 263 338 225 265 minecraft:gray_concrete
fill 339 222 262 342 225 262 minecraft:gray_concrete
fill 339 222 266 342 225 266 minecraft:gray_concrete
fill 343 222 262 345 222 262 minecraft:iron_block
fill 343 222 263 343 225 265 minecraft:gray_concrete
fill 343 222 266 345 222 266 minecraft:iron_block
fill 344 222 263 344 222 265 minecraft:iron_block
fill 345 222 263 345 225 265 minecraft:gray_concrete
fill 346 222 262 349 225 262 minecraft:gray_concrete
fill 346 222 266 349 225 266 minecraft:gray_concrete
fill 350 222 262 352 222 262 minecraft:iron_block
fill 350 222 263 350 225 265 minecraft:gray_concrete
fill 350 222 266 352 222 266 minecraft:iron_block
fill 351 222 263 351 222 265 minecraft:iron_block
fill 352 222 263 352 225 265 minecraft:gray_concrete
fill 353 222 262 356 225 262 minecraft:gray_concrete
fill 353 222 266 356 225 266 minecraft:gray_concrete
setblock 357 222 229 minecraft:green_concrete
fill 357 222 262 359 222 262 minecraft:iron_block
fill 357 222 263 357 225 265 minecraft:gray_concrete
fill 357 222 266 359 222 266 minecraft:iron_block
fill 358 222 263 358 222 265 minecraft:iron_block
fill 359 222 263 359 225 265 minecraft:gray_concrete
fill 360 222 262 363 225 262 minecraft:gray_concrete
fill 360 222 266 363 225 266 minecraft:gray_concrete
fill 364 222 262 370 222 262 minecraft:iron_block
fill 364 222 263 364 225 265 minecraft:gray_concrete
fill 364 222 266 370 222 266 minecraft:iron_block
fill 364 222 270 364 230 270 minecraft:stone_bricks
fill 365 222 263 371 222 265 minecraft:iron_block
setblock 370 222 235 minecraft:lime_concrete
setblock 329 223 240 minecraft:mossy_stone_bricks
fill 329 223 262 329 225 266 minecraft:iron_block
fill 330 223 262 330 225 263 minecraft:iron_block
setblock 330 223 264 minecraft:green_concrete
fill 330 223 265 330 225 266 minecraft:iron_block
setblock 330 223 270 minecraft:mossy_stone_bricks
fill 331 223 262 331 224 262 minecraft:gray_concrete
fill 331 223 266 331 224 266 minecraft:gray_concrete
setblock 332 223 231 minecraft:light[level=15]
setblock 332 223 238 minecraft:light[level=12]
setblock 332 223 239 minecraft:light[level=15]
setblock 332 223 247 minecraft:light[level=15]
setblock 332 223 252 minecraft:light[level=12]
setblock 332 223 255 minecraft:light[level=15]
setblock 332 223 259 minecraft:light[level=12]
fill 333 223 261 334 224 261 minecraft:gray_concrete
fill 333 223 267 334 224 267 minecraft:gray_concrete
fill 336 223 262 336 224 262 minecraft:gray_concrete
fill 336 223 266 336 224 266 minecraft:gray_concrete
fill 337 223 262 337 225 263 minecraft:iron_block
fill 337 223 264 337 224 264 minecraft:gray_concrete
fill 337 223 265 337 225 266 minecraft:iron_block
fill 338 223 262 338 224 262 minecraft:gray_concrete
fill 338 223 266 338 224 266 minecraft:gray_concrete
fill 339 223 231 339 223 233 minecraft:light_gray_concrete
setblock 339 223 238 minecraft:light[level=12]
setblock 339 223 245 minecraft:light[level=12]
setblock 339 223 252 minecraft:light[level=12]
setblock 339 223 259 minecraft:light[level=12]
fill 340 223 231 341 223 231 minecraft:light_gray_concrete
fill 340 223 233 341 223 233 minecraft:light_gray_concrete
setblock 340 223 239 minecraft:light[level=15]
setblock 340 223 247 minecraft:light[level=15]
setblock 340 223 255 minecraft:light[level=15]
fill 340 223 261 341 224 261 minecraft:gray_concrete
fill 340 223 267 341 224 267 minecraft:gray_concrete
setblock 341 223 232 minecraft:light_gray_concrete
fill 343 223 262 343 224 262 minecraft:gray_concrete
fill 343 223 266 343 224 266 minecraft:gray_concrete
fill 344 223 262 344 225 263 minecraft:iron_block
fill 344 223 264 344 224 264 minecraft:gray_concrete
fill 344 223 265 344 225 266 minecraft:iron_block
fill 345 223 262 345 224 262 minecraft:gray_concrete
fill 345 223 266 345 224 266 minecraft:gray_concrete
setblock 346 223 231 minecraft:light[level=12]
setblock 346 223 238 minecraft:light[level=12]
setblock 346 223 245 minecraft:light[level=12]
setblock 346 223 252 minecraft:light[level=12]
setblock 346 223 259 minecraft:light[level=12]
fill 347 223 261 348 224 261 minecraft:gray_concrete
fill 347 223 267 348 224 267 minecraft:gray_concrete
setblock 348 223 231 minecraft:light[level=15]
setblock 348 223 239 minecraft:light[level=15]
setblock 348 223 247 minecraft:light[level=15]
setblock 348 223 255 minecraft:light[level=15]
fill 350 223 262 350 224 262 minecraft:gray_concrete
fill 350 223 266 350 224 266 minecraft:gray_concrete
fill 351 223 262 351 225 263 minecraft:iron_block
fill 351 223 264 351 224 264 minecraft:gray_concrete
fill 351 223 265 351 225 266 minecraft:iron_block
fill 352 223 262 352 224 262 minecraft:gray_concrete
fill 352 223 266 352 224 266 minecraft:gray_concrete
setblock 353 223 231 minecraft:light[level=12]
setblock 353 223 238 minecraft:light[level=12]
setblock 353 223 245 minecraft:light[level=12]
setblock 353 223 252 minecraft:light[level=12]
setblock 353 223 259 minecraft:light[level=12]
fill 354 223 261 355 224 261 minecraft:gray_concrete
fill 354 223 267 355 224 267 minecraft:gray_concrete
setblock 356 223 231 minecraft:light[level=15]
setblock 356 223 239 minecraft:light[level=15]
setblock 356 223 247 minecraft:light[level=15]
setblock 356 223 255 minecraft:light[level=15]
setblock 356 223 270 minecraft:mossy_stone_bricks
fill 357 223 262 357 224 262 minecraft:gray_concrete
fill 357 223 266 357 224 266 minecraft:gray_concrete
fill 358 223 262 358 225 263 minecraft:iron_block
fill 358 223 264 358 224 264 minecraft:gray_concrete
fill 358 223 265 358 225 266 minecraft:iron_block
fill 359 223 262 359 224 262 minecraft:gray_concrete
fill 359 223 266 359 224 266 minecraft:gray_concrete
setblock 360 223 231 minecraft:light[level=12]
setblock 360 223 238 minecraft:light[level=12]
setblock 360 223 245 minecraft:light[level=12]
setblock 360 223 252 minecraft:light[level=12]
setblock 360 223 259 minecraft:light[level=12]
fill 361 223 261 362 224 261 minecraft:gray_concrete
fill 361 223 267 362 224 267 minecraft:gray_concrete
setblock 364 223 231 minecraft:light[level=15]
setblock 364 223 239 minecraft:light[level=15]
setblock 364 223 247 minecraft:light[level=15]
setblock 364 223 255 minecraft:light[level=15]
fill 364 223 262 364 224 262 minecraft:gray_concrete
fill 364 223 266 364 224 266 minecraft:gray_concrete
fill 365 223 262 371 224 263 minecraft:iron_block
fill 365 223 264 365 224 264 minecraft:gray_concrete
fill 365 223 265 371 224 266 minecraft:iron_block
fill 366 223 264 371 225 264 minecraft:iron_block
setblock 367 223 231 minecraft:light[level=12]
setblock 367 223 238 minecraft:light[level=12]
setblock 367 223 245 minecraft:light[level=12]
setblock 367 223 252 minecraft:light[level=12]
setblock 367 223 259 minecraft:light[level=12]
setblock 329 224 230 minecraft:cobblestone
fill 329 224 240 329 255 240 minecraft:stone_bricks
setblock 329 224 269 minecraft:mossy_cobblestone
setblock 330 224 264 minecraft:gray_concrete
fill 330 224 270 330 235 270 minecraft:stone_bricks
setblock 332 224 244 minecraft:light_gray_concrete
setblock 332 224 246 minecraft:light_gray_concrete
setblock 334 224 244 minecraft:light_gray_concrete
setblock 334 224 246 minecraft:light_gray_concrete
setblock 349 224 228 minecraft:mossy_cobblestone
fill 356 224 270 356 280 270 minecraft:stone_bricks
setblock 361 224 228 minecraft:mossy_cobblestone
fill 329 225 230 329 280 230 minecraft:stone_bricks
setblock 329 225 268 minecraft:mossy_stone_bricks
fill 329 225 269 329 280 269 minecraft:stone_bricks
fill 330 225 264 330 226 264 minecraft:iron_block
setblock 331 225 262 minecraft:iron_block
setblock 331 225 266 minecraft:iron_block
setblock 336 225 262 minecraft:iron_block
setblock 336 225 266 minecraft:iron_block
fill 337 225 264 337 226 264 minecraft:iron_block
setblock 338 225 262 minecraft:iron_block
setblock 338 225 266 minecraft:iron_block
setblock 340 225 270 minecraft:cobblestone
setblock 343 225 262 minecraft:iron_block
setblock 343 225 266 minecraft:iron_block
fill 344 225 264 344 226 264 minecraft:iron_block
setblock 345 225 262 minecraft:iron_block
setblock 345 225 266 minecraft:iron_block
setblock 346 225 270 minecraft:mossy_cobblestone
fill 349 225 228 349 228 228 minecraft:stone_bricks
setblock 350 225 262 minecraft:iron_block
setblock 350 225 266 minecraft:iron_block
fill 351 225 264 351 226 264 minecraft:iron_block
setblock 352 225 262 minecraft:iron_block
setblock 352 225 266 minecraft:iron_block
setblock 357 225 262 minecraft:iron_block
setblock 357 225 266 minecraft:iron_block
fill 358 225 264 358 226 264 minecraft:iron_block
setblock 359 225 262 minecraft:iron_block
setblock 359 225 266 minecraft:iron_block
fill 361 225 228 361 280 228 minecraft:stone_bricks
fill 364 225 262 370 225 262 minecraft:iron_block
fill 364 225 266 370 225 266 minecraft:iron_block
fill 365 225 263 365 225 265 minecraft:iron_block
fill 366 225 263 371 225 263 minecraft:iron_block
fill 366 225 265 371 225 265 minecraft:iron_block
fill 371 225 262 371 280 262 minecraft:stone_bricks
fill 371 225 266 371 240 266 minecraft:stone_bricks
fill 329 226 262 329 229 263 minecraft:stone_bricks
setblock 329 226 264 minecraft:iron_block
fill 329 226 265 329 231 266 minecraft:stone_bricks
fill 329 226 268 329 272 268 minecraft:stone_bricks
setblock 331 226 264 minecraft:iron_block
setblock 336 226 264 minecraft:iron_block
setblock 338 226 264 minecraft:iron_block
fill 340 226 270 340 280 270 minecraft:stone_bricks
fill 342 226 266 342 259 266 minecraft:iron_block
fill 343 226 264 343 226 265 minecraft:iron_block
setblock 345 226 264 minecraft:iron_block
fill 346 226 270 346 280 270 minecraft:stone_bricks
setblock 350 226 264 minecraft:iron_block
setblock 352 226 264 minecraft:iron_block
fill 356 226 242 357 227 242 minecraft:light_blue_stained_glass
setblock 357 226 264 minecraft:iron_block
setblock 359 226 264 minecraft:iron_block
fill 364 226 264 370 226 264 minecraft:iron_block
fill 371 226 263 371 280 265 minecraft:stone_bricks
setblock 329 227 243 minecraft:mossy_stone_bricks
fill 329 227 264 329 280 264 minecraft:stone_bricks
setblock 341 227 264 minecraft:light_gray_concrete
fill 341 227 265 343 259 265 minecraft:iron_block
setblock 341 227 266 minecraft:light_gray_concrete
fill 342 227 264 342 259 264 minecraft:iron_block
setblock 343 227 264 minecraft:light_gray_concrete
setblock 343 227 266 minecraft:light_gray_concrete
setblock 355 227 228 minecraft:mossy_cobblestone
fill 329 228 243 329 280 243 minecraft:stone_bricks
setblock 338 228 228 minecraft:mossy_cobblestone
fill 339 228 231 339 228 233 minecraft:light_gray_concrete
fill 340 228 231 341 228 231 minecraft:light_gray_concrete
fill 340 228 233 341 228 233 minecraft:light_gray_concrete
setblock 341 228 232 minecraft:light_gray_concrete
setblock 350 228 270 minecraft:mossy_cobblestone
fill 355 228 228 355 280 228 minecraft:stone_bricks
setblock 332 229 231 minecraft:light[level=12]
setblock 332 229 238 minecraft:light[level=12]
setblock 332 229 252 minecraft:light[level=12]
setblock 332 229 259 minecraft:light[level=12]
setblock 332 229 266 minecraft:light[level=12]
setblock 333 229 228 minecraft:cobblestone
fill 338 229 228 338 232 228 minecraft:stone_bricks
setblock 339 229 231 minecraft:light[level=12]
setblock 339 229 238 minecraft:light[level=12]
setblock 339 229 245 minecraft:light[level=12]
setblock 339 229 252 minecraft:light[level=12]
setblock 339 229 259 minecraft:light[level=12]
setblock 339 229 266 minecraft:light[level=12]
setblock 346 229 231 minecraft:light[level=12]
setblock 346 229 238 minecraft:light[level=12]
setblock 346 229 245 minecraft:light[level=12]
setblock 346 229 252 minecraft:light[level=12]
setblock 346 229 259 minecraft:light[level=12]
setblock 346 229 266 minecraft:light[level=12]
setblock 349 229 228 minecraft:mossy_cobblestone
fill 350 229 270 350 280 270 minecraft:stone_bricks
setblock 353 229 231 minecraft:light[level=12]
setblock 353 229 238 minecraft:light[level=12]
setblock 353 229 245 minecraft:light[level=12]
setblock 353 229 252 minecraft:light[level=12]
setblock 353 229 259 minecraft:light[level=12]
setblock 353 229 266 minecraft:light[level=12]
setblock 360 229 231 minecraft:light[level=12]
setblock 360 229 238 minecraft:light[level=12]
setblock 360 229 245 minecraft:light[level=12]
setblock 360 229 252 minecraft:light[level=12]
setblock 360 229 259 minecraft:light[level=12]
setblock 360 229 266 minecraft:light[level=12]
setblock 363 229 269 minecraft:lime_concrete
setblock 367 229 231 minecraft:light[level=12]
setblock 367 229 238 minecraft:light[level=12]
setblock 367 229 245 minecraft:light[level=12]
setblock 367 229 252 minecraft:light[level=12]
setblock 367 229 259 minecraft:light[level=12]
setblock 367 229 266 minecraft:light[level=12]
fill 329 230 262 329 280 262 minecraft:stone_bricks
setblock 329 230 263 minecraft:cobblestone
setblock 330 230 234 minecraft:green_concrete
setblock 332 230 231 minecraft:light[level=15]
setblock 332 230 239 minecraft:light[level=15]
setblock 332 230 247 minecraft:light[level=15]
setblock 332 230 255 minecraft:light[level=15]
setblock 332 230 263 minecraft:light[level=15]
fill 333 230 228 333 280 228 minecraft:stone_bricks
setblock 340 230 231 minecraft:light[level=15]
setblock 340 230 239 minecraft:light[level=15]
setblock 340 230 247 minecraft:light[level=15]
setblock 340 230 255 minecraft:light[level=15]
setblock 340 230 263 minecraft:light[level=15]
setblock 348 230 231 minecraft:light[level=15]
setblock 348 230 239 minecraft:light[level=15]
setblock 348 230 247 minecraft:light[level=15]
setblock 348 230 255 minecraft:light[level=15]
setblock 348 230 263 minecraft:light[level=15]
fill 349 230 228 349 280 228 minecraft:stone_bricks
setblock 356 230 231 minecraft:light[level=15]
setblock 356 230 239 minecraft:light[level=15]
setblock 356 230 247 minecraft:light[level=15]
setblock 356 230 255 minecraft:light[level=15]
setblock 356 230 263 minecraft:light[level=15]
setblock 364 230 231 minecraft:light[level=15]
setblock 364 230 239 minecraft:light[level=15]
setblock 364 230 247 minecraft:light[level=15]
setblock 364 230 255 minecraft:light[level=15]
setblock 364 230 263 minecraft:light[level=15]
setblock 370 230 230 minecraft:lime_concrete
setblock 371 230 261 minecraft:mossy_stone_bricks
fill 329 231 263 329 280 263 minecraft:stone_bricks
setblock 332 231 244 minecraft:light_gray_concrete
setblock 332 231 246 minecraft:light_gray_concrete
setblock 334 231 244 minecraft:light_gray_concrete
setblock 334 231 246 minecraft:light_gray_concrete
setblock 337 231 228 minecraft:mossy_cobblestone
setblock 354 231 228 minecraft:mossy_cobblestone
setblock 364 231 270 minecraft:cobblestone
setblock 370 231 234 minecraft:green_concrete
fill 371 231 261 371 280 261 minecraft:stone_bricks
setblock 329 232 251 minecraft:mossy_stone_bricks
fill 329 232 252 329 280 252 minecraft:stone_bricks
fill 329 232 265 329 256 265 minecraft:stone_bricks
setblock 329 232 266 minecraft:mossy_cobblestone
fill 337 232 228 337 280 228 minecraft:stone_bricks
setblock 337 232 229 minecraft:green_concrete
fill 354 232 228 354 242 228 minecraft:stone_bricks
fill 364 232 270 364 270 270 minecraft:stone_bricks
fill 329 233 251 329 265 251 minecraft:stone_bricks
fill 329 233 266 329 280 266 minecraft:stone_bricks
setblock 332 233 228 minecraft:cobblestone
setblock 338 233 228 minecraft:cobblestone
fill 339 233 231 339 233 233 minecraft:light_gray_concrete
fill 340 233 231 341 233 231 minecraft:light_gray_concrete
fill 340 233 233 341 233 233 minecraft:light_gray_concrete
setblock 341 233 232 minecraft:light_gray_concrete
setblock 341 233 264 minecraft:light_gray_concrete
setblock 341 233 266 minecraft:light_gray_concrete
setblock 343 233 264 minecraft:light_gray_concrete
setblock 343 233 266 minecraft:light_gray_concrete
setblock 355 233 270 minecraft:mossy_stone_bricks
setblock 371 233 245 minecraft:mossy_cobblestone
setblock 329 234 229 minecraft:mossy_stone_bricks
fill 332 234 228 332 280 228 minecraft:stone_bricks
fill 338 234 228 338 280 228 minecraft:stone_bricks
setblock 350 234 228 minecraft:mossy_stone_bricks
setblock 355 234 269 minecraft:lime_terracotta
fill 355 234 270 355 253 270 minecraft:stone_bricks
fill 371 234 245 371 280 245 minecraft:stone_bricks
fill 329 235 229 329 250 229 minecraft:stone_bricks
setblock 332 235 231 minecraft:light[level=12]
setblock 332 235 238 minecraft:light[level=12]
setblock 332 235 252 minecraft:light[level=12]
setblock 332 235 259 minecraft:light[level=12]
setblock 332 235 266 minecraft:light[level=12]
setblock 339 235 231 minecraft:light[level=12]
setblock 339 235 238 minecraft:light[level=12]
setblock 339 235 245 minecraft:light[level=12]
setblock 339 235 252 minecraft:light[level=12]
setblock 339 235 259 minecraft:light[level=12]
setblock 339 235 266 minecraft:light[level=12]
fill 340 235 229 340 236 231 minecraft:iron_block
setblock 346 235 231 minecraft:light[level=12]
setblock 346 235 238 minecraft:light[level=12]
setblock 346 235 245 minecraft:light[level=12]
setblock 346 235 252 minecraft:light[level=12]
setblock 346 235 259 minecraft:light[level=12]
setblock 346 235 266 minecraft:light[level=12]
fill 350 235 228 350 280 228 minecraft:stone_bricks
setblock 353 235 231 minecraft:light[level=12]
setblock 353 235 238 minecraft:light[level=12]
setblock 353 235 245 minecraft:light[level=12]
setblock 353 235 252 minecraft:light[level=12]
setblock 353 235 259 minecraft:light[level=12]
setblock 353 235 266 minecraft:light[level=12]
setblock 360 235 231 minecraft:light[level=12]
setblock 360 235 238 minecraft:light[level=12]
setblock 360 235 245 minecraft:light[level=12]
setblock 360 235 252 minecraft:light[level=12]
setblock 360 235 259 minecraft:light[level=12]
setblock 360 235 266 minecraft:light[level=12]
setblock 367 235 231 minecraft:light[level=12]
setblock 367 235 238 minecraft:light[level=12]
setblock 367 235 245 minecraft:light[level=12]
setblock 367 235 252 minecraft:light[level=12]
setblock 367 235 259 minecraft:light[level=12]
setblock 367 235 266 minecraft:light[level=12]
setblock 330 236 229 minecraft:lime_terracotta
setblock 330 236 270 minecraft:mossy_stone_bricks
setblock 340 236 233 minecraft:sea_lantern
setblock 361 236 229 minecraft:lime_concrete
fill 330 237 270 330 249 270 minecraft:stone_bricks
setblock 332 237 231 minecraft:light[level=15]
setblock 332 237 239 minecraft:light[level=15]
setblock 332 237 247 minecraft:light[level=15]
setblock 332 237 255 minecraft:light[level=15]
setblock 332 237 263 minecraft:light[level=15]
fill 338 237 244 339 238 244 minecraft:light_blue_stained_glass
setblock 340 237 231 minecraft:light[level=15]
setblock 340 237 239 minecraft:light[level=15]
setblock 340 237 247 minecraft:light[level=15]
setblock 340 237 255 minecraft:light[level=15]
setblock 340 237 263 minecraft:light[level=15]
setblock 348 237 231 minecraft:light[level=15]
setblock 348 237 239 minecraft:light[level=15]
setblock 348 237 247 minecraft:light[level=15]
setblock 348 237 255 minecraft:light[level=15]
setblock 348 237 263 minecraft:light[level=15]
setblock 356 237 231 minecraft:light[level=15]
setblock 356 237 239 minecraft:light[level=15]
setblock 356 237 247 minecraft:light[level=15]
setblock 356 237 255 minecraft:light[level=15]
setblock 356 237 263 minecraft:light[level=15]
setblock 364 237 231 minecraft:light[level=15]
setblock 364 237 239 minecraft:light[level=15]
setblock 364 237 247 minecraft:light[level=15]
setblock 364 237 255 minecraft:light[level=15]
setblock 364 237 263 minecraft:light[level=15]
setblock 370 237 228 minecraft:mossy_cobblestone
setblock 332 238 244 minecraft:light_gray_concrete
setblock 332 238 246 minecraft:light_gray_concrete
setblock 334 238 244 minecraft:light_gray_concrete
setblock 334 238 246 minecraft:light_gray_concrete
fill 339 238 231 339 238 233 minecraft:light_gray_concrete
fill 340 238 231 341 238 231 minecraft:light_gray_concrete
fill 340 238 233 341 238 233 minecraft:light_gray_concrete
setblock 341 238 232 minecraft:light_gray_concrete
setblock 342 238 270 minecraft:cobblestone
fill 370 238 228 370 280 228 minecraft:stone_bricks
setblock 339 239 228 minecraft:mossy_cobblestone
setblock 341 239 264 minecraft:light_gray_concrete
setblock 341 239 266 minecraft:light_gray_concrete
setblock 342 239 270 minecraft:stone_bricks
setblock 343 239 264 minecraft:light_gray_concrete
setblock 343 239 266 minecraft:light_gray_concrete
setblock 329 240 250 minecraft:cobblestone
fill 330 240 245 331 241 245 minecraft:iron_block
fill 339 240 228 339 276 228 minecraft:stone_bricks
setblock 342 240 270 minecraft:mossy_cobblestone
setblock 346 240 269 minecraft:green_concrete
setblock 370 240 258 minecraft:lime_concrete
fill 329 241 250 329 280 250 minecraft:stone_bricks
setblock 332 241 231 minecraft:light[level=12]
setblock 332 241 238 minecraft:light[level=12]
setblock 332 241 252 minecraft:light[level=12]
setblock 332 241 259 minecraft:light[level=12]
setblock 332 241 266 minecraft:light[level=12]
setblock 335 241 245 minecraft:sea_lantern
setblock 339 241 231 minecraft:light[level=12]
setblock 339 241 238 minecraft:light[level=12]
setblock 339 241 245 minecraft:light[level=12]
setblock 339 241 252 minecraft:light[level=12]
setblock 339 241 259 minecraft:light[level=12]
setblock 339 241 266 minecraft:light[level=12]
fill 342 241 270 342 280 270 minecraft:stone_bricks
setblock 346 241 231 minecraft:light[level=12]
setblock 346 241 238 minecraft:light[level=12]
setblock 346 241 245 minecraft:light[level=12]
setblock 346 241 252 minecraft:light[level=12]
setblock 346 241 259 minecraft:light[level=12]
setblock 346 241 266 minecraft:light[level=12]
setblock 353 241 231 minecraft:light[level=12]
setblock 353 241 238 minecraft:light[level=12]
setblock 353 241 245 minecraft:light[level=12]
setblock 353 241 252 minecraft:light[level=12]
setblock 353 241 259 minecraft:light[level=12]
setblock 353 241 266 minecraft:light[level=12]
setblock 360 241 231 minecraft:light[level=12]
setblock 360 241 238 minecraft:light[level=12]
setblock 360 241 245 minecraft:light[level=12]
setblock 360 241 252 minecraft:light[level=12]
setblock 360 241 259 minecraft:light[level=12]
setblock 360 241 266 minecraft:light[level=12]
setblock 367 241 231 minecraft:light[level=12]
setblock 367 241 238 minecraft:light[level=12]
setblock 367 241 245 minecraft:light[level=12]
setblock 367 241 252 minecraft:light[level=12]
setblock 367 241 259 minecraft:light[level=12]
setblock 367 241 266 minecraft:light[level=12]
setblock 371 241 266 minecraft:mossy_stone_bricks
setblock 330 242 250 minecraft:lime_concrete
setblock 341 242 270 minecraft:cobblestone
setblock 357 242 270 minecraft:mossy_stone_bricks
fill 371 242 266 371 280 266 minecraft:stone_bricks
fill 339 243 231 339 243 233 minecraft:light_gray_concrete
fill 340 243 231 341 243 231 minecraft:light_gray_concrete
fill 340 243 233 341 243 233 minecraft:light_gray_concrete
setblock 341 243 232 minecraft:light_gray_concrete
fill 341 243 270 341 250 270 minecraft:stone_bricks
setblock 354 243 228 minecraft:mossy_cobblestone
fill 357 243 270 357 280 270 minecraft:stone_bricks
setblock 363 243 228 minecraft:cobblestone
setblock 332 244 231 minecraft:light[level=15]
setblock 332 244 239 minecraft:light[level=15]
setblock 332 244 247 minecraft:light[level=15]
setblock 332 244 255 minecraft:light[level=15]
setblock 332 244 263 minecraft:light[level=15]
setblock 340 244 231 minecraft:light[level=15]
setblock 340 244 239 minecraft:light[level=15]
setblock 340 244 247 minecraft:light[level=15]
setblock 340 244 255 minecraft:light[level=15]
setblock 340 244 263 minecraft:light[level=15]
setblock 348 244 231 minecraft:light[level=15]
setblock 348 244 239 minecraft:light[level=15]
setblock 348 244 247 minecraft:light[level=15]
setblock 348 244 255 minecraft:light[level=15]
setblock 348 244 263 minecraft:light[level=15]
fill 354 244 228 354 257 228 minecraft:stone_bricks
setblock 356 244 231 minecraft:light[level=15]
setblock 356 244 239 minecraft:light[level=15]
setblock 356 244 247 minecraft:light[level=15]
setblock 356 244 255 minecraft:light[level=15]
setblock 356 244 263 minecraft:light[level=15]
fill 363 244 228 363 280 228 minecraft:stone_bricks
setblock 364 244 231 minecraft:light[level=15]
setblock 364 244 239 minecraft:light[level=15]
setblock 364 244 247 minecraft:light[level=15]
setblock 364 244 255 minecraft:light[level=15]
setblock 364 244 263 minecraft:light[level=15]
fill 329 245 247 329 275 247 minecraft:stone_bricks
setblock 329 245 248 minecraft:mossy_cobblestone
setblock 332 245 244 minecraft:light_gray_concrete
setblock 332 245 246 minecraft:light_gray_concrete
setblock 334 245 228 minecraft:cobblestone
setblock 334 245 244 minecraft:light_gray_concrete
setblock 334 245 246 minecraft:light_gray_concrete
setblock 341 245 264 minecraft:light_gray_concrete
setblock 341 245 266 minecraft:light_gray_concrete
setblock 343 245 264 minecraft:light_gray_concrete
setblock 343 245 266 minecraft:light_gray_concrete
setblock 354 245 270 minecraft:cobblestone
fill 329 246 248 329 280 248 minecraft:stone_bricks
fill 334 246 228 334 280 228 minecraft:stone_bricks
fill 354 246 270 354 280 270 minecraft:stone_bricks
setblock 371 246 237 minecraft:mossy_stone_bricks
setblock 371 246 252 minecraft:mossy_stone_bricks
setblock 329 247 239 minecraft:mossy_cobblestone
setblock 330 247 254 minecraft:green_concrete
setblock 332 247 231 minecraft:light[level=12]
setblock 332 247 238 minecraft:light[level=12]
setblock 332 247 252 minecraft:light[level=12]
setblock 332 247 259 minecraft:light[level=12]
setblock 332 247 266 minecraft:light[level=12]
setblock 339 247 231 minecraft:light[level=12]
setblock 339 247 238 minecraft:light[level=12]
setblock 339 247 245 minecraft:light[level=12]
setblock 339 247 252 minecraft:light[level=12]
setblock 339 247 259 minecraft:light[level=12]
setblock 339 247 266 minecraft:light[level=12]
setblock 344 247 228 minecraft:mossy_stone_bricks
setblock 346 247 231 minecraft:light[level=12]
setblock 346 247 238 minecraft:light[level=12]
setblock 346 247 245 minecraft:light[level=12]
setblock 346 247 252 minecraft:light[level=12]
setblock 346 247 259 minecraft:light[level=12]
setblock 346 247 266 minecraft:light[level=12]
setblock 353 247 231 minecraft:light[level=12]
setblock 353 247 238 minecraft:light[level=12]
setblock 353 247 245 minecraft:light[level=12]
setblock 353 247 252 minecraft:light[level=12]
setblock 353 247 259 minecraft:light[level=12]
setblock 353 247 266 minecraft:light[level=12]
setblock 360 247 231 minecraft:light[level=12]
setblock 360 247 238 minecraft:light[level=12]
setblock 360 247 245 minecraft:light[level=12]
setblock 360 247 252 minecraft:light[level=12]
setblock 360 247 259 minecraft:light[level=12]
setblock 360 247 266 minecraft:light[level=12]
setblock 367 247 231 minecraft:light[level=12]
setblock 367 247 238 minecraft:light[level=12]
setblock 367 247 245 minecraft:light[level=12]
setblock 367 247 252 minecraft:light[level=12]
setblock 367 247 259 minecraft:light[level=12]
setblock 367 247 266 minecraft:light[level=12]
fill 371 247 237 371 261 237 minecraft:stone_bricks
fill 371 247 252 371 280 252 minecraft:stone_bricks
setblock 371 247 253 minecraft:mossy_stone_bricks
fill 329 248 239 329 262 239 minecraft:stone_bricks
fill 339 248 231 339 248 233 minecraft:light_gray_concrete
fill 340 248 231 341 248 231 minecraft:light_gray_concrete
fill 340 248 233 341 248 233 minecraft:light_gray_concrete
setblock 341 248 232 minecraft:light_gray_concrete
fill 344 248 228 344 280 228 minecraft:stone_bricks
fill 371 248 253 371 280 253 minecraft:stone_bricks
setblock 332 249 270 minecraft:mossy_stone_bricks
setblock 330 250 270 minecraft:mossy_stone_bricks
fill 332 250 270 332 280 270 minecraft:stone_bricks
setblock 360 250 270 minecraft:mossy_stone_bricks
setblock 367 250 228 minecraft:cobblestone
setblock 371 250 240 minecraft:mossy_cobblestone
setblock 329 251 229 minecraft:cobblestone
setblock 330 251 229 minecraft:lime_concrete
fill 330 251 270 330 279 270 minecraft:stone_bricks
setblock 332 251 231 minecraft:light[level=15]
setblock 332 251 239 minecraft:light[level=15]
setblock 332 251 247 minecraft:light[level=15]
setblock 332 251 255 minecraft:light[level=15]
setblock 332 251 263 minecraft:light[level=15]
setblock 340 251 231 minecraft:light[level=15]
setblock 340 251 239 minecraft:light[level=15]
setblock 340 251 247 minecraft:light[level=15]
setblock 340 251 255 minecraft:light[level=15]
setblock 340 251 263 minecraft:light[level=15]
setblock 341 251 264 minecraft:light_gray_concrete
setblock 341 251 266 minecraft:light_gray_concrete
setblock 341 251 270 minecraft:mossy_cobblestone
setblock 343 251 264 minecraft:light_gray_concrete
setblock 343 251 266 minecraft:light_gray_concrete
setblock 348 251 231 minecraft:light[level=15]
setblock 348 251 239 minecraft:light[level=15]
setblock 348 251 247 minecraft:light[level=15]
setblock 348 251 255 minecraft:light[level=15]
setblock 348 251 263 minecraft:light[level=15]
setblock 356 251 231 minecraft:light[level=15]
setblock 356 251 239 minecraft:light[level=15]
setblock 356 251 247 minecraft:light[level=15]
setblock 356 251 255 minecraft:light[level=15]
setblock 356 251 263 minecraft:light[level=15]
setblock 358 251 270 minecraft:cobblestone
fill 360 251 270 360 280 270 minecraft:stone_bricks
setblock 364 251 231 minecraft:light[level=15]
setblock 364 251 239 minecraft:light[level=15]
setblock 364 251 247 minecraft:light[level=15]
setblock 364 251 255 minecraft:light[level=15]
setblock 364 251 263 minecraft:light[level=15]
fill 367 251 228 367 280 228 minecraft:stone_bricks
fill 371 251 240 371 280 240 minecraft:stone_bricks
fill 329 252 229 329 280 229 minecraft:stone_bricks
setblock 332 252 244 minecraft:light_gray_concrete
setblock 332 252 246 minecraft:light_gray_concrete
setblock 334 252 244 minecraft:light_gray_concrete
setblock 334 252 246 minecraft:light_gray_concrete
fill 341 252 270 341 280 270 minecraft:stone_bricks
fill 358 252 270 358 273 270 minecraft:stone_bricks
setblock 371 252 242 minecraft:mossy_stone_bricks
setblock 329 253 245 minecraft:cobblestone
setblock 332 253 231 minecraft:light[level=12]
setblock 332 253 238 minecraft:light[level=12]
setblock 332 253 252 minecraft:light[level=12]
setblock 332 253 259 minecraft:light[level=12]
setblock 332 253 266 minecraft:light[level=12]
setblock 336 253 270 minecraft:mossy_stone_bricks
fill 339 253 231 339 253 233 minecraft:light_gray_concrete
setblock 339 253 238 minecraft:light[level=12]
setblock 339 253 245 minecraft:light[level=12]
setblock 339 253 252 minecraft:light[level=12]
setblock 339 253 259 minecraft:light[level=12]
setblock 339 253 266 minecraft:light[level=12]
fill 340 253 231 341 253 231 minecraft:light_gray_concrete
fill 340 253 233 341 253 233 minecraft:light_gray_concrete
setblock 341 253 232 minecraft:light_gray_concrete
setblock 346 253 231 minecraft:light[level=12]
setblock 346 253 238 minecraft:light[level=12]
setblock 346 253 245 minecraft:light[level=12]
setblock 346 253 252 minecraft:light[level=12]
setblock 346 253 259 minecraft:light[level=12]
setblock 346 253 266 minecraft:light[level=12]
setblock 353 253 231 minecraft:light[level=12]
setblock 353 253 238 minecraft:light[level=12]
setblock 353 253 245 minecraft:light[level=12]
setblock 353 253 252 minecraft:light[level=12]
setblock 353 253 259 minecraft:light[level=12]
setblock 353 253 266 minecraft:light[level=12]
setblock 360 253 231 minecraft:light[level=12]
setblock 360 253 238 minecraft:light[level=12]
setblock 360 253 245 minecraft:light[level=12]
setblock 360 253 252 minecraft:light[level=12]
setblock 360 253 259 minecraft:light[level=12]
setblock 360 253 266 minecraft:light[level=12]
setblock 367 253 231 minecraft:light[level=12]
setblock 367 253 238 minecraft:light[level=12]
setblock 367 253 245 minecraft:light[level=12]
setblock 367 253 252 minecraft:light[level=12]
setblock 367 253 259 minecraft:light[level=12]
setblock 367 253 266 minecraft:light[level=12]
setblock 371 253 232 minecraft:cobblestone
fill 371 253 242 371 280 242 minecraft:stone_bricks
fill 329 254 245 329 280 245 minecraft:stone_bricks
setblock 336 254 270 minecraft:cobblestone
setblock 355 254 270 minecraft:mossy_cobblestone
fill 371 254 232 371 280 232 minecraft:stone_bricks
fill 336 255 270 336 280 270 minecraft:stone_bricks
fill 342 255 267 342 256 268 minecraft:iron_block
setblock 343 255 228 minecraft:mossy_cobblestone
setblock 351 255 228 minecraft:mossy_cobblestone
fill 355 255 270 355 260 270 minecraft:stone_bricks
setblock 329 256 240 minecraft:mossy_stone_bricks
setblock 342 256 263 minecraft:sea_lantern
fill 343 256 228 343 280 228 minecraft:stone_bricks
fill 351 256 228 351 280 228 minecraft:stone_bricks
setblock 356 256 269 minecraft:lime_concrete
fill 329 257 240 329 280 240 minecraft:stone_bricks
setblock 329 257 265 minecraft:cobblestone
setblock 341 257 264 minecraft:light_gray_concrete
setblock 341 257 266 minecraft:light_gray_concrete
setblock 343 257 264 minecraft:light_gray_concrete
setblock 343 257 266 minecraft:light_gray_concrete
fill 329 258 265 329 280 265 minecraft:stone_bricks
setblock 332 258 231 minecraft:light[level=15]
setblock 332 258 239 minecraft:light[level=15]
setblock 332 258 247 minecraft:light[level=15]
setblock 332 258 255 minecraft:light[level=15]
setblock 332 258 263 minecraft:light[level=15]
fill 339 258 231 339 258 233 minecraft:light_gray_concrete
fill 340 258 231 341 258 231 minecraft:light_gray_concrete
fill 340 258 233 341 258 233 minecraft:light_gray_concrete
setblock 340 258 239 minecraft:light[level=15]
setblock 340 258 247 minecraft:light[level=15]
setblock 340 258 255 minecraft:light[level=15]
setblock 340 258 263 minecraft:light[level=15]
setblock 341 258 232 minecraft:light_gray_concrete
setblock 348 258 231 minecraft:light[level=15]
setblock 348 258 239 minecraft:light[level=15]
setblock 348 258 247 minecraft:light[level=15]
setblock 348 258 255 minecraft:light[level=15]
setblock 348 258 263 minecraft:light[level=15]
setblock 354 258 228 minecraft:mossy_stone_bricks
setblock 356 258 231 minecraft:light[level=15]
setblock 356 258 239 minecraft:light[level=15]
setblock 356 258 247 minecraft:light[level=15]
setblock 356 258 255 minecraft:light[level=15]
setblock 356 258 263 minecraft:light[level=15]
setblock 362 258 228 minecraft:mossy_cobblestone
setblock 364 258 231 minecraft:light[level=15]
setblock 364 258 239 minecraft:light[level=15]
setblock 364 258 247 minecraft:light[level=15]
setblock 364 258 255 minecraft:light[level=15]
setblock 364 258 263 minecraft:light[level=15]
setblock 329 259 232 minecraft:mossy_stone_bricks
setblock 332 259 231 minecraft:light[level=12]
setblock 332 259 238 minecraft:light[level=12]
setblock 332 259 252 minecraft:light[level=12]
setblock 332 259 259 minecraft:light[level=12]
setblock 332 259 266 minecraft:light[level=12]
setblock 334 259 269 minecraft:lime_concrete
setblock 339 259 231 minecraft:light[level=12]
setblock 339 259 238 minecraft:light[level=12]
setblock 339 259 245 minecraft:light[level=12]
setblock 339 259 252 minecraft:light[level=12]
setblock 339 259 259 minecraft:light[level=12]
setblock 339 259 266 minecraft:light[level=12]
setblock 346 259 231 minecraft:light[level=12]
setblock 346 259 238 minecraft:light[level=12]
setblock 346 259 245 minecraft:light[level=12]
setblock 346 259 252 minecraft:light[level=12]
setblock 346 259 259 minecraft:light[level=12]
setblock 346 259 266 minecraft:light[level=12]
setblock 353 259 231 minecraft:light[level=12]
setblock 353 259 238 minecraft:light[level=12]
setblock 353 259 245 minecraft:light[level=12]
setblock 353 259 252 minecraft:light[level=12]
setblock 353 259 259 minecraft:light[level=12]
setblock 353 259 266 minecraft:light[level=12]
fill 354 259 228 354 280 228 minecraft:stone_bricks
setblock 358 259 229 minecraft:lime_terracotta
setblock 360 259 231 minecraft:light[level=12]
setblock 360 259 238 minecraft:light[level=12]
setblock 360 259 245 minecraft:light[level=12]
setblock 360 259 252 minecraft:light[level=12]
setblock 360 259 259 minecraft:light[level=12]
setblock 360 259 266 minecraft:light[level=12]
fill 362 259 228 362 280 228 minecraft:stone_bricks
setblock 367 259 231 minecraft:light[level=12]
setblock 367 259 238 minecraft:light[level=12]
setblock 367 259 245 minecraft:light[level=12]
setblock 367 259 252 minecraft:light[level=12]
setblock 367 259 259 minecraft:light[level=12]
setblock 367 259 266 minecraft:light[level=12]
fill 329 260 232 329 261 232 minecraft:stone_bricks
setblock 371 260 229 minecraft:mossy_stone_bricks
setblock 329 261 261 minecraft:cobblestone
setblock 348 261 228 minecraft:mossy_stone_bricks
setblock 354 261 269 minecraft:lime_concrete
setblock 355 261 270 minecraft:mossy_stone_bricks
fill 371 261 229 371 280 229 minecraft:stone_bricks
setblock 329 262 232 minecraft:cobblestone
fill 329 262 261 329 280 261 minecraft:stone_bricks
fill 348 262 228 348 280 228 minecraft:stone_bricks
fill 355 262 270 355 280 270 minecraft:stone_bricks
setblock 371 262 237 minecraft:mossy_stone_bricks
fill 329 263 232 329 280 232 minecraft:stone_bricks
setblock 329 263 239 minecraft:mossy_cobblestone
setblock 366 263 270 minecraft:cobblestone
fill 371 263 237 371 280 237 minecraft:stone_bricks
fill 329 264 239 329 280 239 minecraft:stone_bricks
setblock 335 264 270 minecraft:mossy_stone_bricks
setblock 341 264 228 minecraft:cobblestone
setblock 361 264 270 minecraft:mossy_cobblestone
fill 366 264 270 366 273 270 minecraft:stone_bricks
fill 330 265 229 370 266 237 minecraft:white_concrete
setblock 330 265 238 minecraft:green_concrete
fill 330 265 239 347 266 269 minecraft:white_concrete
fill 331 265 238 370 266 238 minecraft:white_concrete
fill 335 265 270 335 280 270 minecraft:stone_bricks
fill 341 265 228 341 280 228 minecraft:stone_bricks
fill 348 265 239 348 266 244 minecraft:white_concrete
fill 348 265 248 348 266 269 minecraft:white_concrete
fill 349 265 239 349 266 243 minecraft:white_concrete
fill 349 265 249 349 266 269 minecraft:white_concrete
fill 350 265 239 370 266 242 minecraft:white_concrete
fill 350 265 250 367 266 269 minecraft:white_concrete
fill 353 265 243 370 266 243 minecraft:white_concrete
fill 353 265 249 370 266 249 minecraft:white_concrete
fill 354 265 244 370 266 244 minecraft:white_concrete
fill 354 265 248 370 266 248 minecraft:white_concrete
fill 355 265 245 370 266 247 minecraft:white_concrete
fill 361 265 270 361 280 270 minecraft:stone_bricks
fill 368 265 250 370 266 268 minecraft:white_concrete
setblock 368 265 269 minecraft:green_concrete
fill 369 265 269 370 266 269 minecraft:white_concrete
setblock 329 266 251 minecraft:mossy_cobblestone
setblock 329 266 257 minecraft:mossy_cobblestone
setblock 330 266 238 minecraft:white_concrete
setblock 368 266 269 minecraft:white_concrete
setblock 371 266 268 minecraft:cobblestone
fill 329 267 251 329 280 251 minecraft:stone_bricks
fill 329 267 257 329 280 257 minecraft:stone_bricks
fill 330 267 229 343 267 269 minecraft:smooth_quartz
fill 344 267 229 370 267 241 minecraft:smooth_quartz
fill 344 267 242 344 268 242 minecraft:white_stained_glass
fill 344 267 243 344 267 246 minecraft:smooth_quartz
fill 344 267 247 345 267 253 minecraft:light_blue_stained_glass
fill 344 267 254 344 267 269 minecraft:smooth_quartz
fill 345 267 242 345 267 244 minecraft:smooth_quartz
fill 345 267 245 345 267 246 minecraft:light_blue_stained_glass
fill 345 267 254 347 267 255 minecraft:light_blue_stained_glass
fill 345 267 256 345 267 269 minecraft:smooth_quartz
fill 346 267 242 347 267 243 minecraft:smooth_quartz
fill 346 267 244 346 267 245 minecraft:light_blue_stained_glass
fill 346 267 246 346 267 251 minecraft:blue_stained_glass
fill 346 267 252 346 267 253 minecraft:light_blue_stained_glass
fill 346 267 256 351 267 256 minecraft:light_blue_stained_glass
fill 346 267 257 347 267 269 minecraft:smooth_quartz
fill 347 267 244 347 267 248 minecraft:white_concrete
setblock 347 267 249 minecraft:white_stained_glass
fill 347 267 250 347 267 253 minecraft:blue_stained_glass
setblock 348 267 242 minecraft:smooth_quartz
fill 348 267 243 348 267 244 minecraft:white_concrete
fill 348 267 248 348 267 249 minecraft:white_concrete
fill 348 267 250 348 267 251 minecraft:white_stained_glass
fill 348 267 252 348 267 254 minecraft:blue_stained_glass
setblock 348 267 255 minecraft:light_blue_stained_glass
fill 348 267 257 352 267 257 minecraft:light_blue_stained_glass
fill 348 267 258 370 267 269 minecraft:smooth_quartz
fill 349 267 242 349 267 243 minecraft:white_concrete
fill 349 267 249 349 267 250 minecraft:white_concrete
fill 349 267 251 356 267 251 minecraft:light_blue_stained_glass
fill 349 267 252 350 267 252 minecraft:white_stained_glass
fill 349 267 253 349 267 255 minecraft:blue_stained_glass
setblock 349 267 270 minecraft:cobblestone
fill 350 267 242 353 267 242 minecraft:white_concrete
fill 350 267 250 353 267 250 minecraft:white_concrete
fill 350 267 253 352 267 253 minecraft:white_stained_glass
fill 350 267 254 351 267 255 minecraft:blue_stained_glass
fill 351 267 252 356 267 252 minecraft:light_blue_stained_glass
fill 352 267 254 355 267 254 minecraft:white_stained_glass
fill 352 267 255 354 267 256 minecraft:blue_stained_glass
setblock 353 267 243 minecraft:white_concrete
fill 353 267 249 354 267 249 minecraft:white_concrete
fill 353 267 253 355 267 253 minecraft:light_blue_stained_glass
fill 353 267 257 370 267 257 minecraft:smooth_quartz
fill 354 267 242 355 267 242 minecraft:smooth_quartz
fill 354 267 243 354 268 244 minecraft:white_stained_glass
fill 354 267 248 355 267 248 minecraft:white_concrete
fill 354 267 250 354 268 250 minecraft:white_stained_glass
fill 355 267 243 370 267 243 minecraft:smooth_quartz
fill 355 267 244 355 268 244 minecraft:white_stained_glass
fill 355 267 245 355 267 247 minecraft:white_concrete
fill 355 267 249 355 267 250 minecraft:blue_stained_glass
setblock 355 267 255 minecraft:blue_stained_glass
fill 355 267 256 370 267 256 minecraft:smooth_quartz
fill 356 267 242 356 268 242 minecraft:white_stained_glass
fill 356 267 244 370 267 246 minecraft:smooth_quartz
fill 356 267 247 357 268 247 minecraft:white_stained_glass
fill 356 267 248 356 267 249 minecraft:blue_stained_glass
setblock 356 267 250 minecraft:light_blue_stained_glass
setblock 356 267 253 minecraft:white_stained_glass
fill 356 267 254 370 267 255 minecraft:smooth_quartz
fill 357 267 242 370 267 242 minecraft:smooth_quartz
fill 357 267 248 370 267 253 minecraft:smooth_quartz
fill 358 267 247 370 267 247 minecraft:smooth_quartz
fill 371 267 268 371 280 268 minecraft:stone_bricks
setblock 329 268 267 minecraft:cobblestone
fill 330 268 229 342 269 269 minecraft:white_concrete
fill 343 268 229 355 269 241 minecraft:white_concrete
setblock 343 268 242 minecraft:white_stained_glass
fill 343 268 243 343 268 248 minecraft:white_concrete
fill 343 268 252 343 268 269 minecraft:white_concrete
setblock 344 268 243 minecraft:white_stained_glass
fill 344 268 244 344 268 245 minecraft:white_concrete
fill 344 268 255 344 268 269 minecraft:white_concrete
fill 345 268 242 345 268 244 minecraft:white_concrete
fill 345 268 256 345 268 269 minecraft:white_concrete
fill 346 268 242 346 268 243 minecraft:white_concrete
fill 346 268 257 346 268 269 minecraft:white_concrete
fill 347 268 242 348 268 242 minecraft:white_concrete
fill 347 268 258 348 268 269 minecraft:white_concrete
fill 349 268 259 370 269 269 minecraft:white_concrete
fill 349 268 270 349 271 270 minecraft:stone_bricks
fill 352 268 242 355 268 242 minecraft:white_concrete
fill 352 268 258 370 268 258 minecraft:white_concrete
setblock 354 268 251 minecraft:white_stained_glass
fill 354 268 257 370 268 257 minecraft:white_concrete
setblock 355 268 243 minecraft:white_stained_glass
fill 355 268 256 370 268 256 minecraft:white_concrete
fill 356 268 229 370 269 240 minecraft:white_concrete
setblock 356 268 241 minecraft:white_stained_glass
fill 356 268 243 370 268 245 minecraft:white_concrete
fill 356 268 255 370 268 255 minecraft:white_concrete
fill 357 268 241 370 269 242 minecraft:white_concrete
fill 357 268 246 370 269 246 minecraft:white_concrete
fill 357 268 248 370 268 248 minecraft:white_concrete
fill 357 268 252 370 268 254 minecraft:white_concrete
fill 358 268 247 370 269 247 minecraft:white_concrete
fill 358 268 249 370 269 251 minecraft:white_concrete
fill 329 269 267 329 280 267 minecraft:stone_bricks
fill 343 269 242 343 269 246 minecraft:white_concrete
fill 343 269 254 343 269 269 minecraft:white_concrete
fill 344 269 242 344 269 244 minecraft:white_concrete
fill 344 269 256 344 269 269 minecraft:white_concrete
fill 345 269 242 345 269 243 minecraft:white_concrete
fill 345 269 257 345 269 269 minecraft:white_concrete
fill 346 269 242 347 269 242 minecraft:white_concrete
fill 346 269 258 347 269 269 minecraft:white_concrete
fill 348 269 259 348 269 269 minecraft:white_concrete
fill 353 269 242 356 269 242 minecraft:white_concrete
fill 353 269 258 370 269 258 minecraft:white_concrete
fill 355 269 243 370 269 243 minecraft:white_concrete
fill 355 269 257 370 269 257 minecraft:white_concrete
setblock 356 269 241 minecraft:white_concrete
fill 356 269 244 370 269 244 minecraft:white_concrete
fill 356 269 256 370 269 256 minecraft:white_concrete
fill 357 269 245 370 269 245 minecraft:white_concrete
fill 357 269 254 370 269 255 minecraft:white_concrete
fill 358 269 248 370 269 248 minecraft:white_concrete
fill 358 269 252 370 269 253 minecraft:white_concrete
setblock 371 269 231 minecraft:mossy_stone_bricks
fill 330 270 229 342 270 269 minecraft:smooth_quartz
fill 343 270 229 343 270 245 minecraft:smooth_quartz
fill 343 270 255 343 270 269 minecraft:smooth_quartz
fill 344 270 229 344 270 243 minecraft:smooth_quartz
fill 344 270 257 344 270 269 minecraft:smooth_quartz
fill 345 270 229 346 270 242 minecraft:smooth_quartz
fill 345 270 258 346 270 269 minecraft:smooth_quartz
setblock 346 270 228 minecraft:cobblestone
fill 347 270 229 348 270 241 minecraft:smooth_quartz
fill 347 270 259 348 270 269 minecraft:smooth_quartz
fill 349 270 229 370 270 240 minecraft:smooth_quartz
fill 349 270 260 370 270 269 minecraft:smooth_quartz
fill 352 270 241 370 270 241 minecraft:smooth_quartz
fill 352 270 259 370 270 259 minecraft:smooth_quartz
fill 354 270 242 370 270 242 minecraft:smooth_quartz
fill 354 270 258 370 270 258 minecraft:smooth_quartz
fill 356 270 243 370 270 243 minecraft:smooth_quartz
fill 356 270 257 370 270 257 minecraft:smooth_quartz
fill 357 270 244 370 270 245 minecraft:smooth_quartz
fill 357 270 255 370 270 256 minecraft:smooth_quartz
fill 358 270 246 370 270 254 minecraft:smooth_quartz
setblock 368 270 270 minecraft:mossy_cobblestone
fill 371 270 231 371 280 231 minecraft:stone_bricks
setblock 371 270 248 minecraft:cobblestone
setblock 371 270 254 minecraft:cobblestone
setblock 371 270 259 minecraft:mossy_stone_bricks
fill 330 271 229 341 272 269 minecraft:white_concrete
fill 342 271 229 342 271 247 minecraft:white_concrete
fill 342 271 253 342 271 269 minecraft:white_concrete
fill 343 271 229 343 271 244 minecraft:white_concrete
fill 343 271 256 343 271 269 minecraft:white_concrete
fill 344 271 229 344 271 243 minecraft:white_concrete
fill 344 271 257 344 271 269 minecraft:white_concrete
fill 345 271 229 345 271 242 minecraft:white_concrete
fill 345 271 258 345 271 269 minecraft:white_concrete
fill 346 271 228 346 280 228 minecraft:stone_bricks
fill 346 271 229 347 271 241 minecraft:white_concrete
setblock 346 271 245 minecraft:light[level=12]
setblock 346 271 252 minecraft:light[level=12]
fill 346 271 259 347 271 269 minecraft:white_concrete
fill 348 271 229 370 271 240 minecraft:white_concrete
fill 348 271 260 370 271 269 minecraft:white_concrete
fill 353 271 241 370 271 241 minecraft:white_concrete
setblock 353 271 245 minecraft:light[level=12]
setblock 353 271 252 minecraft:light[level=12]
fill 353 271 259 370 271 259 minecraft:white_concrete
fill 355 271 242 370 271 242 minecraft:white_concrete
fill 355 271 258 370 271 258 minecraft:white_concrete
fill 356 271 243 370 271 243 minecraft:white_concrete
fill 356 271 257 370 271 257 minecraft:white_concrete
fill 357 271 244 370 271 244 minecraft:white_concrete
fill 357 271 256 370 271 256 minecraft:white_concrete
fill 358 271 245 370 271 247 minecraft:white_concrete
fill 358 271 253 370 271 255 minecraft:white_concrete
fill 359 271 248 370 272 252 minecraft:white_concrete
setblock 364 271 270 minecraft:mossy_cobblestone
fill 368 271 270 368 280 270 minecraft:stone_bricks
fill 371 271 248 371 280 248 minecraft:stone_bricks
fill 371 271 254 371 280 254 minecraft:stone_bricks
fill 371 271 259 371 280 259 minecraft:stone_bricks
fill 342 272 229 342 272 245 minecraft:white_concrete
fill 342 272 255 342 272 269 minecraft:white_concrete
fill 343 272 229 343 272 243 minecraft:white_concrete
fill 343 272 257 343 272 269 minecraft:white_concrete
fill 344 272 229 344 272 242 minecraft:white_concrete
fill 344 272 258 344 272 269 minecraft:white_concrete
fill 345 272 229 346 272 241 minecraft:white_concrete
fill 345 272 259 346 272 269 minecraft:white_concrete
fill 347 272 229 348 272 240 minecraft:white_concrete
fill 347 272 260 348 272 269 minecraft:white_concrete
setblock 348 272 247 minecraft:light[level=15]
setblock 348 272 255 minecraft:light[level=15]
fill 349 272 229 370 272 239 minecraft:white_concrete
fill 349 272 261 370 272 269 minecraft:white_concrete
setblock 349 272 270 minecraft:mossy_cobblestone
fill 352 272 240 370 272 240 minecraft:white_concrete
fill 352 272 260 370 272 260 minecraft:white_concrete
fill 354 272 241 370 272 241 minecraft:white_concrete
fill 354 272 259 370 272 259 minecraft:white_concrete
fill 356 272 242 370 272 242 minecraft:white_concrete
setblock 356 272 247 minecraft:light[level=15]
setblock 356 272 255 minecraft:light[level=15]
fill 356 272 258 370 272 258 minecraft:white_concrete
fill 357 272 243 370 272 243 minecraft:white_concrete
fill 357 272 257 370 272 257 minecraft:white_concrete
fill 358 272 244 370 272 245 minecraft:white_concrete
fill 358 272 255 370 272 256 minecraft:white_concrete
fill 359 272 246 370 272 247 minecraft:white_concrete
fill 359 272 253 370 272 254 minecraft:white_concrete
fill 364 272 270 364 280 270 minecraft:stone_bricks
setblock 329 273 268 minecraft:mossy_cobblestone
fill 330 273 229 340 273 269 minecraft:smooth_quartz
fill 341 273 229 341 273 247 minecraft:smooth_quartz
fill 341 273 253 341 273 269 minecraft:smooth_quartz
fill 342 273 229 342 273 244 minecraft:smooth_quartz
fill 342 273 256 342 273 269 minecraft:smooth_quartz
fill 343 273 229 343 273 243 minecraft:smooth_quartz
fill 343 273 257 343 273 269 minecraft:smooth_quartz
fill 344 273 229 345 273 241 minecraft:smooth_quartz
fill 344 273 259 345 273 269 minecraft:smooth_quartz
fill 346 273 229 347 273 240 minecraft:smooth_quartz
fill 346 273 260 347 273 269 minecraft:smooth_quartz
fill 348 273 229 370 273 239 minecraft:smooth_quartz
fill 348 273 261 370 273 269 minecraft:smooth_quartz
fill 349 273 270 349 280 270 minecraft:stone_bricks
fill 353 273 240 370 273 240 minecraft:smooth_quartz
fill 353 273 260 370 273 260 minecraft:smooth_quartz
fill 355 273 241 370 273 241 minecraft:smooth_quartz
fill 355 273 259 370 273 259 minecraft:smooth_quartz
fill 357 273 242 370 273 243 minecraft:smooth_quartz
fill 357 273 257 370 273 258 minecraft:smooth_quartz
fill 358 273 244 370 273 244 minecraft:smooth_quartz
fill 358 273 256 370 273 256 minecraft:smooth_quartz
fill 359 273 245 370 273 247 minecraft:smooth_quartz
fill 359 273 253 370 273 255 minecraft:smooth_quartz
fill 360 273 248 370 273 252 minecraft:smooth_quartz
setblock 329 274 254 minecraft:mossy_cobblestone
fill 329 274 268 329 280 268 minecraft:stone_bricks
fill 330 274 229 340 274 269 minecraft:white_concrete
fill 341 274 229 341 274 246 minecraft:white_concrete
fill 341 274 254 341 274 269 minecraft:white_concrete
fill 342 274 229 342 275 243 minecraft:white_concrete
fill 342 274 257 342 275 269 minecraft:white_concrete
fill 343 274 229 343 274 242 minecraft:white_concrete
fill 343 274 258 343 274 269 minecraft:white_concrete
fill 344 274 229 344 274 241 minecraft:white_concrete
fill 344 274 259 344 274 269 minecraft:white_concrete
fill 345 274 229 345 275 240 minecraft:white_concrete
fill 345 274 260 345 275 269 minecraft:white_concrete
fill 346 274 229 349 274 239 minecraft:white_concrete
fill 346 274 261 349 274 269 minecraft:white_concrete
fill 350 274 229 370 275 238 minecraft:white_concrete
fill 350 274 262 370 275 269 minecraft:white_concrete
fill 351 274 239 370 274 239 minecraft:white_concrete
fill 351 274 261 370 274 261 minecraft:white_concrete
fill 355 274 240 370 275 240 minecraft:white_concrete
fill 355 274 260 370 275 260 minecraft:white_concrete
fill 356 274 241 370 274 241 minecraft:white_concrete
fill 356 274 259 370 274 259 minecraft:white_concrete
fill 357 274 242 370 274 242 minecraft:white_concrete
fill 357 274 258 370 274 258 minecraft:white_concrete
fill 358 274 243 370 275 243 minecraft:white_concrete
fill 358 274 257 370 275 257 minecraft:white_concrete
setblock 358 274 270 minecraft:mossy_cobblestone
fill 359 274 244 370 274 246 minecraft:white_concrete
fill 359 274 254 370 274 256 minecraft:white_concrete
fill 360 274 247 370 274 253 minecraft:white_concrete
setblock 366 274 270 minecraft:cobblestone
fill 329 275 233 329 280 233 minecraft:stone_bricks
setblock 329 275 234 minecraft:mossy_cobblestone
fill 329 275 235 329 280 235 minecraft:stone_bricks
fill 329 275 254 329 280 254 minecraft:stone_bricks
fill 330 275 229 339 275 269 minecraft:white_concrete
fill 340 275 229 340 275 248 minecraft:white_concrete
fill 340 275 252 340 275 269 minecraft:white_concrete
fill 341 275 229 341 275 244 minecraft:white_concrete
fill 341 275 256 341 275 269 minecraft:white_concrete
fill 343 275 229 343 275 241 minecraft:white_concrete
fill 343 275 259 343 275 269 minecraft:white_concrete
fill 344 275 229 344 275 240 minecraft:white_concrete
fill 344 275 260 344 275 269 minecraft:white_concrete
fill 346 275 229 347 275 239 minecraft:white_concrete
fill 346 275 261 347 275 269 minecraft:white_concrete
fill 348 275 229 349 275 238 minecraft:white_concrete
fill 348 275 262 349 275 269 minecraft:white_concrete
fill 353 275 239 370 275 239 minecraft:white_concrete
fill 353 275 261 370 275 261 minecraft:white_concrete
fill 357 275 241 370 275 241 minecraft:white_concrete
fill 357 275 259 370 275 259 minecraft:white_concrete
fill 358 275 242 370 275 242 minecraft:white_concrete
fill 358 275 258 370 275 258 minecraft:white_concrete
fill 358 275 270 358 280 270 minecraft:stone_bricks
fill 359 275 244 370 275 244 minecraft:white_concrete
fill 359 275 256 370 275 256 minecraft:white_concrete
fill 360 275 245 370 275 248 minecraft:white_concrete
fill 360 275 252 370 275 255 minecraft:white_concrete
fill 361 275 249 370 275 251 minecraft:white_concrete
fill 366 275 270 366 280 270 minecraft:stone_bricks
fill 329 276 234 329 280 234 minecraft:stone_bricks
setblock 329 276 247 minecraft:mossy_stone_bricks
fill 330 276 229 339 276 269 minecraft:smooth_quartz
fill 340 276 229 340 276 246 minecraft:smooth_quartz
fill 340 276 254 340 276 269 minecraft:smooth_quartz
fill 341 276 229 341 276 243 minecraft:smooth_quartz
fill 341 276 257 341 276 269 minecraft:smooth_quartz
fill 342 276 229 342 276 242 minecraft:smooth_quartz
fill 342 276 258 342 276 269 minecraft:smooth_quartz
fill 343 276 229 343 276 241 minecraft:smooth_quartz
fill 343 276 259 343 276 269 minecraft:smooth_quartz
fill 344 276 229 344 276 240 minecraft:smooth_quartz
fill 344 276 260 344 276 269 minecraft:smooth_quartz
fill 345 276 229 345 276 239 minecraft:smooth_quartz
fill 345 276 261 345 276 269 minecraft:smooth_quartz
fill 346 276 229 370 276 238 minecraft:smooth_quartz
fill 346 276 262 370 276 269 minecraft:smooth_quartz
fill 355 276 239 370 276 239 minecraft:smooth_quartz
fill 355 276 261 370 276 261 minecraft:smooth_quartz
fill 356 276 240 370 276 240 minecraft:smooth_quartz
fill 356 276 260 370 276 260 minecraft:smooth_quartz
fill 357 276 241 370 276 241 minecraft:smooth_quartz
fill 357 276 259 370 276 259 minecraft:smooth_quartz
fill 358 276 242 370 276 242 minecraft:smooth_quartz
fill 358 276 258 370 276 258 minecraft:smooth_quartz
fill 359 276 243 370 276 243 minecraft:smooth_quartz
fill 359 276 257 370 276 257 minecraft:smooth_quartz
fill 360 276 244 370 276 246 minecraft:smooth_quartz
fill 360 276 254 370 276 256 minecraft:smooth_quartz
fill 361 276 247 370 276 253 minecraft:smooth_quartz
setblock 329 277 247 minecraft:cobblestone
fill 330 277 229 339 277 269 minecraft:white_concrete
setblock 339 277 228 minecraft:mossy_cobblestone
fill 340 277 229 340 277 245 minecraft:white_concrete
fill 340 277 251 340 278 251 minecraft:white_stained_glass
fill 340 277 255 340 277 269 minecraft:white_concrete
schedule function dropper:buildpart/55_3 1t
