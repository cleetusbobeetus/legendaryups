fill 450 209 416 453 307 416 minecraft:stone_bricks
fill 458 209 416 460 307 416 minecraft:stone_bricks
setblock 461 209 416 minecraft:cracked_stone_bricks
fill 462 209 416 464 209 416 minecraft:stone_bricks
fill 463 209 458 464 307 458 minecraft:stone_bricks
setblock 465 209 416 minecraft:cracked_stone_bricks
fill 465 209 421 465 307 421 minecraft:stone_bricks
fill 465 209 423 465 307 423 minecraft:stone_bricks
fill 465 209 427 465 307 428 minecraft:stone_bricks
fill 465 209 437 465 307 437 minecraft:stone_bricks
fill 465 209 445 465 209 446 minecraft:stone_bricks
setblock 465 209 447 minecraft:cracked_stone_bricks
fill 465 209 448 465 209 452 minecraft:stone_bricks
fill 465 209 457 465 209 458 minecraft:cracked_stone_bricks
fill 423 210 416 423 307 416 minecraft:stone_bricks
setblock 423 210 417 minecraft:cracked_stone_bricks
fill 423 210 418 423 307 420 minecraft:stone_bricks
fill 423 210 427 423 307 427 minecraft:stone_bricks
fill 423 210 429 423 307 429 minecraft:stone_bricks
setblock 423 210 430 minecraft:cracked_stone_bricks
setblock 423 210 438 minecraft:cracked_stone_bricks
fill 423 210 439 423 307 442 minecraft:stone_bricks
fill 423 210 450 423 307 452 minecraft:stone_bricks
setblock 423 210 453 minecraft:cracked_stone_bricks
fill 423 210 456 423 307 456 minecraft:stone_bricks
fill 426 210 416 426 307 416 minecraft:stone_bricks
setblock 426 210 419 minecraft:light[level=12]
setblock 426 210 427 minecraft:light[level=12]
setblock 426 210 435 minecraft:light[level=12]
setblock 426 210 443 minecraft:light[level=12]
setblock 426 210 451 minecraft:light[level=12]
fill 432 210 458 433 307 458 minecraft:stone_bricks
setblock 434 210 419 minecraft:light[level=12]
setblock 434 210 427 minecraft:light[level=12]
setblock 434 210 435 minecraft:light[level=12]
setblock 434 210 443 minecraft:light[level=12]
setblock 434 210 451 minecraft:light[level=12]
fill 435 210 416 435 307 416 minecraft:stone_bricks
setblock 436 210 416 minecraft:cracked_stone_bricks
fill 437 210 416 441 307 416 minecraft:stone_bricks
setblock 442 210 419 minecraft:light[level=12]
setblock 442 210 427 minecraft:light[level=12]
setblock 442 210 435 minecraft:light[level=12]
setblock 442 210 443 minecraft:light[level=12]
setblock 442 210 451 minecraft:light[level=12]
fill 449 210 416 449 307 416 minecraft:stone_bricks
setblock 450 210 419 minecraft:light[level=12]
setblock 450 210 427 minecraft:light[level=12]
setblock 450 210 435 minecraft:light[level=12]
setblock 450 210 443 minecraft:light[level=12]
setblock 450 210 451 minecraft:light[level=12]
setblock 451 210 458 minecraft:cracked_stone_bricks
fill 452 210 458 456 307 458 minecraft:stone_bricks
setblock 457 210 458 minecraft:cracked_stone_bricks
setblock 458 210 419 minecraft:light[level=12]
setblock 458 210 427 minecraft:light[level=12]
setblock 458 210 435 minecraft:light[level=12]
setblock 458 210 443 minecraft:light[level=12]
setblock 458 210 451 minecraft:light[level=12]
fill 458 210 458 458 307 458 minecraft:stone_bricks
fill 461 210 416 461 307 416 minecraft:stone_bricks
setblock 462 210 416 minecraft:cracked_stone_bricks
fill 463 210 416 465 307 416 minecraft:stone_bricks
setblock 465 210 422 minecraft:cracked_stone_bricks
setblock 465 210 424 minecraft:cracked_stone_bricks
fill 465 210 425 465 307 426 minecraft:stone_bricks
fill 465 210 433 465 307 433 minecraft:stone_bricks
setblock 465 210 434 minecraft:cracked_stone_bricks
fill 465 210 435 465 307 436 minecraft:stone_bricks
fill 465 210 438 465 307 439 minecraft:stone_bricks
setblock 465 210 440 minecraft:cracked_stone_bricks
setblock 465 210 445 minecraft:cracked_stone_bricks
fill 465 210 446 465 307 448 minecraft:stone_bricks
setblock 465 210 449 minecraft:cracked_stone_bricks
fill 465 210 450 465 307 452 minecraft:stone_bricks
fill 465 210 457 465 307 458 minecraft:stone_bricks
fill 423 211 417 423 307 417 minecraft:stone_bricks
fill 423 211 430 423 307 430 minecraft:stone_bricks
fill 423 211 438 423 307 438 minecraft:stone_bricks
fill 423 211 453 423 307 453 minecraft:stone_bricks
fill 436 211 416 436 307 416 minecraft:stone_bricks
fill 451 211 458 451 307 458 minecraft:stone_bricks
fill 457 211 458 457 307 458 minecraft:stone_bricks
fill 462 211 416 462 307 416 minecraft:stone_bricks
fill 465 211 422 465 307 422 minecraft:stone_bricks
fill 465 211 424 465 307 424 minecraft:stone_bricks
fill 465 211 434 465 307 434 minecraft:stone_bricks
fill 465 211 440 465 307 440 minecraft:stone_bricks
fill 465 211 445 465 307 445 minecraft:stone_bricks
fill 465 211 449 465 307 449 minecraft:stone_bricks
fill 423 212 422 423 245 422 minecraft:stone_bricks
fill 423 212 423 423 212 424 minecraft:glowstone
fill 423 212 425 423 245 425 minecraft:stone_bricks
fill 423 212 434 423 245 434 minecraft:stone_bricks
fill 423 212 435 423 212 436 minecraft:glowstone
fill 423 212 437 423 245 437 minecraft:stone_bricks
fill 423 212 446 423 245 446 minecraft:stone_bricks
fill 423 212 447 423 212 448 minecraft:glowstone
fill 423 212 449 423 245 449 minecraft:stone_bricks
fill 423 212 458 423 245 458 minecraft:stone_bricks
fill 424 212 458 425 212 458 minecraft:glowstone
fill 426 212 458 426 245 458 minecraft:stone_bricks
fill 430 212 416 430 245 416 minecraft:stone_bricks
fill 431 212 416 432 212 416 minecraft:glowstone
fill 433 212 416 433 245 416 minecraft:stone_bricks
fill 435 212 458 435 245 458 minecraft:stone_bricks
fill 436 212 458 437 212 458 minecraft:glowstone
fill 438 212 458 438 245 458 minecraft:stone_bricks
fill 442 212 416 442 245 416 minecraft:stone_bricks
fill 443 212 416 444 212 416 minecraft:glowstone
fill 445 212 416 445 245 416 minecraft:stone_bricks
fill 447 212 458 447 245 458 minecraft:stone_bricks
fill 448 212 458 449 212 458 minecraft:glowstone
fill 450 212 458 450 245 458 minecraft:stone_bricks
fill 454 212 416 454 245 416 minecraft:stone_bricks
fill 455 212 416 456 212 416 minecraft:glowstone
fill 457 212 416 457 245 416 minecraft:stone_bricks
fill 459 212 458 459 245 458 minecraft:stone_bricks
fill 460 212 458 461 212 458 minecraft:glowstone
fill 462 212 458 462 245 458 minecraft:stone_bricks
fill 465 212 417 465 245 417 minecraft:stone_bricks
fill 465 212 418 465 212 419 minecraft:glowstone
fill 465 212 420 465 245 420 minecraft:stone_bricks
fill 465 212 429 465 245 429 minecraft:stone_bricks
fill 465 212 430 465 212 431 minecraft:glowstone
fill 465 212 432 465 245 432 minecraft:stone_bricks
fill 465 212 441 465 245 441 minecraft:stone_bricks
fill 465 212 442 465 212 443 minecraft:glowstone
fill 465 212 444 465 245 444 minecraft:stone_bricks
fill 465 212 453 465 245 453 minecraft:stone_bricks
fill 465 212 454 465 212 455 minecraft:glowstone
fill 465 212 456 465 245 456 minecraft:stone_bricks
fill 423 213 423 423 245 424 minecraft:stone_bricks
fill 423 213 435 423 245 436 minecraft:stone_bricks
fill 423 213 447 423 245 448 minecraft:stone_bricks
fill 424 213 458 425 245 458 minecraft:stone_bricks
fill 431 213 416 432 245 416 minecraft:stone_bricks
fill 436 213 458 437 245 458 minecraft:stone_bricks
fill 443 213 416 444 245 416 minecraft:stone_bricks
fill 448 213 458 449 245 458 minecraft:stone_bricks
fill 455 213 416 456 245 416 minecraft:stone_bricks
fill 460 213 458 461 245 458 minecraft:stone_bricks
fill 465 213 418 465 245 419 minecraft:stone_bricks
fill 465 213 430 465 245 431 minecraft:stone_bricks
fill 465 213 442 465 245 443 minecraft:stone_bricks
fill 465 213 454 465 245 455 minecraft:stone_bricks
setblock 426 218 419 minecraft:light[level=12]
setblock 426 218 427 minecraft:light[level=12]
setblock 426 218 435 minecraft:light[level=12]
setblock 426 218 443 minecraft:light[level=12]
setblock 426 218 451 minecraft:light[level=12]
setblock 434 218 419 minecraft:light[level=12]
setblock 434 218 427 minecraft:light[level=12]
setblock 434 218 435 minecraft:light[level=12]
setblock 434 218 443 minecraft:light[level=12]
setblock 434 218 451 minecraft:light[level=12]
setblock 442 218 419 minecraft:light[level=12]
setblock 442 218 427 minecraft:light[level=12]
setblock 442 218 435 minecraft:light[level=12]
setblock 442 218 443 minecraft:light[level=12]
setblock 442 218 451 minecraft:light[level=12]
setblock 450 218 419 minecraft:light[level=12]
setblock 450 218 427 minecraft:light[level=12]
setblock 450 218 435 minecraft:light[level=12]
setblock 450 218 443 minecraft:light[level=12]
setblock 450 218 451 minecraft:light[level=12]
setblock 458 218 419 minecraft:light[level=12]
setblock 458 218 427 minecraft:light[level=12]
setblock 458 218 435 minecraft:light[level=12]
setblock 458 218 443 minecraft:light[level=12]
setblock 458 218 451 minecraft:light[level=12]
fill 425 220 426 425 225 428 minecraft:iron_block
fill 425 220 438 425 225 440 minecraft:iron_block
fill 425 220 450 425 225 452 minecraft:iron_block
fill 431 220 456 433 225 456 minecraft:iron_block
fill 435 220 418 437 225 418 minecraft:iron_block
fill 443 220 456 445 225 456 minecraft:iron_block
fill 447 220 418 449 225 418 minecraft:iron_block
fill 455 220 456 457 225 456 minecraft:iron_block
fill 459 220 418 461 225 418 minecraft:iron_block
fill 463 220 426 463 225 428 minecraft:iron_block
fill 463 220 438 463 225 440 minecraft:iron_block
fill 463 220 450 463 225 452 minecraft:iron_block
fill 424 225 420 424 225 425 minecraft:cobblestone
fill 424 225 432 424 225 437 minecraft:cobblestone
fill 424 225 444 424 225 449 minecraft:cobblestone
fill 424 225 456 424 225 457 minecraft:cobblestone
fill 425 225 457 428 225 457 minecraft:cobblestone
fill 428 225 417 433 225 417 minecraft:cobblestone
fill 435 225 457 440 225 457 minecraft:cobblestone
fill 440 225 417 445 225 417 minecraft:cobblestone
fill 447 225 457 452 225 457 minecraft:cobblestone
fill 452 225 417 457 225 417 minecraft:cobblestone
fill 459 225 457 464 225 457 minecraft:cobblestone
fill 464 225 417 464 225 422 minecraft:cobblestone
fill 464 225 429 464 225 434 minecraft:cobblestone
fill 464 225 441 464 225 446 minecraft:cobblestone
fill 464 225 453 464 225 456 minecraft:cobblestone
setblock 426 226 419 minecraft:light[level=12]
setblock 426 226 427 minecraft:light[level=12]
setblock 426 226 435 minecraft:light[level=12]
setblock 426 226 443 minecraft:light[level=12]
setblock 426 226 451 minecraft:light[level=12]
setblock 434 226 419 minecraft:light[level=12]
setblock 434 226 427 minecraft:light[level=12]
setblock 434 226 435 minecraft:light[level=12]
setblock 434 226 443 minecraft:light[level=12]
setblock 434 226 451 minecraft:light[level=12]
setblock 442 226 419 minecraft:light[level=12]
setblock 442 226 427 minecraft:light[level=12]
setblock 442 226 435 minecraft:light[level=12]
setblock 442 226 443 minecraft:light[level=12]
setblock 442 226 451 minecraft:light[level=12]
setblock 450 226 419 minecraft:light[level=12]
setblock 450 226 427 minecraft:light[level=12]
setblock 450 226 435 minecraft:light[level=12]
setblock 450 226 443 minecraft:light[level=12]
setblock 450 226 451 minecraft:light[level=12]
setblock 458 226 419 minecraft:light[level=12]
setblock 458 226 427 minecraft:light[level=12]
setblock 458 226 435 minecraft:light[level=12]
setblock 458 226 443 minecraft:light[level=12]
setblock 458 226 451 minecraft:light[level=12]
fill 424 231 417 424 232 427 minecraft:black_concrete
fill 424 231 428 464 232 428 minecraft:stone_bricks
fill 424 231 429 424 232 439 minecraft:black_concrete
fill 424 231 440 441 231 440 minecraft:stone_bricks
fill 424 231 441 424 232 451 minecraft:black_concrete
fill 424 231 452 464 232 452 minecraft:stone_bricks
fill 424 231 453 424 232 457 minecraft:black_concrete
fill 425 231 417 425 232 427 minecraft:iron_block
fill 425 231 429 425 232 439 minecraft:iron_block
fill 425 231 441 425 232 451 minecraft:iron_block
fill 425 231 453 425 232 457 minecraft:iron_block
fill 426 231 417 426 232 427 minecraft:black_concrete
fill 426 231 429 426 232 439 minecraft:black_concrete
fill 426 231 441 426 232 451 minecraft:black_concrete
fill 426 231 453 426 232 457 minecraft:black_concrete
fill 427 231 417 427 232 427 minecraft:iron_block
fill 427 231 429 427 232 439 minecraft:iron_block
fill 427 231 441 427 232 451 minecraft:iron_block
fill 427 231 453 427 232 457 minecraft:iron_block
fill 428 231 417 428 232 427 minecraft:black_concrete
fill 428 231 429 428 232 439 minecraft:black_concrete
fill 428 231 441 428 232 451 minecraft:black_concrete
fill 428 231 453 428 232 457 minecraft:black_concrete
fill 429 231 417 429 232 427 minecraft:iron_block
fill 429 231 429 429 232 439 minecraft:iron_block
fill 429 231 441 429 232 451 minecraft:iron_block
fill 429 231 453 429 232 457 minecraft:iron_block
fill 430 231 417 430 232 427 minecraft:black_concrete
fill 430 231 429 430 232 439 minecraft:black_concrete
fill 430 231 441 430 232 451 minecraft:black_concrete
fill 430 231 453 430 232 457 minecraft:black_concrete
fill 431 231 417 431 232 427 minecraft:iron_block
fill 431 231 429 431 232 439 minecraft:iron_block
fill 431 231 441 431 232 451 minecraft:iron_block
fill 431 231 453 431 232 457 minecraft:iron_block
fill 432 231 417 432 232 427 minecraft:black_concrete
fill 432 231 429 432 232 439 minecraft:black_concrete
fill 432 231 441 432 232 451 minecraft:black_concrete
fill 432 231 453 432 232 457 minecraft:black_concrete
fill 433 231 417 433 232 427 minecraft:iron_block
fill 433 231 429 433 232 439 minecraft:iron_block
fill 433 231 441 433 232 451 minecraft:iron_block
fill 433 231 453 433 232 457 minecraft:iron_block
fill 434 231 417 434 232 427 minecraft:black_concrete
fill 434 231 429 434 232 439 minecraft:black_concrete
fill 434 231 441 434 232 451 minecraft:black_concrete
fill 434 231 453 434 232 457 minecraft:black_concrete
fill 435 231 417 435 232 427 minecraft:iron_block
fill 435 231 429 435 232 439 minecraft:iron_block
fill 435 231 441 435 232 451 minecraft:iron_block
fill 435 231 453 435 232 457 minecraft:iron_block
fill 436 231 417 436 232 427 minecraft:black_concrete
fill 436 231 429 436 232 439 minecraft:black_concrete
fill 436 231 441 436 232 451 minecraft:black_concrete
fill 436 231 453 436 232 457 minecraft:black_concrete
fill 437 231 417 437 232 427 minecraft:iron_block
fill 437 231 429 437 232 439 minecraft:iron_block
fill 437 231 441 437 232 451 minecraft:iron_block
fill 437 231 453 437 232 457 minecraft:iron_block
fill 438 231 417 438 232 427 minecraft:black_concrete
fill 438 231 429 438 232 439 minecraft:black_concrete
fill 438 231 441 438 232 451 minecraft:black_concrete
fill 438 231 453 438 232 457 minecraft:black_concrete
fill 439 231 417 439 232 427 minecraft:iron_block
fill 439 231 429 439 232 439 minecraft:iron_block
fill 439 231 441 439 232 451 minecraft:iron_block
fill 439 231 453 439 232 457 minecraft:iron_block
fill 440 231 417 440 232 427 minecraft:black_concrete
fill 440 231 429 440 231 439 minecraft:black_concrete
fill 440 231 441 440 232 451 minecraft:black_concrete
fill 440 231 453 440 232 457 minecraft:black_concrete
fill 441 231 417 441 232 427 minecraft:iron_block
fill 441 231 429 441 231 438 minecraft:iron_block
fill 441 231 441 441 231 451 minecraft:iron_block
fill 441 231 453 441 232 457 minecraft:iron_block
fill 442 231 417 442 232 427 minecraft:black_concrete
fill 442 231 429 442 231 437 minecraft:black_concrete
fill 442 231 441 442 231 451 minecraft:black_concrete
fill 442 231 453 442 232 457 minecraft:black_concrete
fill 443 231 417 443 232 427 minecraft:iron_block
fill 443 231 429 443 231 436 minecraft:iron_block
fill 443 231 442 443 231 451 minecraft:iron_block
fill 443 231 453 443 232 457 minecraft:iron_block
fill 444 231 417 444 232 427 minecraft:black_concrete
fill 444 231 429 444 231 437 minecraft:black_concrete
fill 444 231 441 444 231 451 minecraft:black_concrete
fill 444 231 453 444 232 457 minecraft:black_concrete
fill 445 231 417 445 232 427 minecraft:iron_block
fill 445 231 429 445 231 438 minecraft:iron_block
fill 445 231 440 464 231 440 minecraft:stone_bricks
fill 445 231 441 445 231 451 minecraft:iron_block
fill 445 231 453 445 232 457 minecraft:iron_block
fill 446 231 417 446 232 427 minecraft:black_concrete
fill 446 231 429 446 231 439 minecraft:black_concrete
fill 446 231 441 446 232 451 minecraft:black_concrete
fill 446 231 453 446 232 457 minecraft:black_concrete
fill 447 231 417 447 232 427 minecraft:iron_block
fill 447 231 429 447 232 439 minecraft:iron_block
fill 447 231 441 447 232 451 minecraft:iron_block
fill 447 231 453 447 232 457 minecraft:iron_block
fill 448 231 417 448 232 427 minecraft:black_concrete
fill 448 231 429 448 232 439 minecraft:black_concrete
fill 448 231 441 448 232 451 minecraft:black_concrete
fill 448 231 453 448 232 457 minecraft:black_concrete
fill 449 231 417 449 232 427 minecraft:iron_block
fill 449 231 429 449 232 439 minecraft:iron_block
fill 449 231 441 449 232 451 minecraft:iron_block
fill 449 231 453 449 232 457 minecraft:iron_block
fill 450 231 417 450 232 427 minecraft:black_concrete
fill 450 231 429 450 232 439 minecraft:black_concrete
fill 450 231 441 450 232 451 minecraft:black_concrete
fill 450 231 453 450 232 457 minecraft:black_concrete
fill 451 231 417 451 232 427 minecraft:iron_block
fill 451 231 429 451 232 439 minecraft:iron_block
fill 451 231 441 451 232 451 minecraft:iron_block
fill 451 231 453 451 232 457 minecraft:iron_block
fill 452 231 417 452 232 427 minecraft:black_concrete
fill 452 231 429 452 232 439 minecraft:black_concrete
fill 452 231 441 452 232 451 minecraft:black_concrete
fill 452 231 453 452 232 457 minecraft:black_concrete
fill 453 231 417 453 232 427 minecraft:iron_block
fill 453 231 429 453 232 439 minecraft:iron_block
fill 453 231 441 453 232 451 minecraft:iron_block
fill 453 231 453 453 232 457 minecraft:iron_block
fill 454 231 417 454 232 427 minecraft:black_concrete
fill 454 231 429 454 232 439 minecraft:black_concrete
fill 454 231 441 454 232 451 minecraft:black_concrete
fill 454 231 453 454 232 457 minecraft:black_concrete
fill 455 231 417 455 232 427 minecraft:iron_block
fill 455 231 429 455 232 439 minecraft:iron_block
fill 455 231 441 455 232 451 minecraft:iron_block
fill 455 231 453 455 232 457 minecraft:iron_block
fill 456 231 417 456 232 427 minecraft:black_concrete
fill 456 231 429 456 232 439 minecraft:black_concrete
fill 456 231 441 456 232 451 minecraft:black_concrete
fill 456 231 453 456 232 457 minecraft:black_concrete
fill 457 231 417 457 232 427 minecraft:iron_block
fill 457 231 429 457 232 439 minecraft:iron_block
fill 457 231 441 457 232 451 minecraft:iron_block
fill 457 231 453 457 232 457 minecraft:iron_block
fill 458 231 417 458 232 427 minecraft:black_concrete
fill 458 231 429 458 232 439 minecraft:black_concrete
fill 458 231 441 458 232 451 minecraft:black_concrete
fill 458 231 453 458 232 457 minecraft:black_concrete
fill 459 231 417 459 232 427 minecraft:iron_block
fill 459 231 429 459 232 439 minecraft:iron_block
fill 459 231 441 459 232 451 minecraft:iron_block
fill 459 231 453 459 232 457 minecraft:iron_block
fill 460 231 417 460 232 427 minecraft:black_concrete
fill 460 231 429 460 232 439 minecraft:black_concrete
fill 460 231 441 460 232 451 minecraft:black_concrete
fill 460 231 453 460 232 457 minecraft:black_concrete
fill 461 231 417 461 232 427 minecraft:iron_block
fill 461 231 429 461 232 439 minecraft:iron_block
fill 461 231 441 461 232 451 minecraft:iron_block
fill 461 231 453 461 232 457 minecraft:iron_block
fill 462 231 417 462 232 427 minecraft:black_concrete
fill 462 231 429 462 232 439 minecraft:black_concrete
fill 462 231 441 462 232 451 minecraft:black_concrete
fill 462 231 453 462 232 457 minecraft:black_concrete
fill 463 231 417 463 232 427 minecraft:iron_block
fill 463 231 429 463 232 439 minecraft:iron_block
fill 463 231 441 463 232 451 minecraft:iron_block
fill 463 231 453 463 232 457 minecraft:iron_block
fill 464 231 417 464 232 427 minecraft:black_concrete
fill 464 231 429 464 232 439 minecraft:black_concrete
fill 464 231 441 464 232 451 minecraft:black_concrete
fill 464 231 453 464 232 457 minecraft:black_concrete
fill 424 232 440 439 232 440 minecraft:stone_bricks
fill 440 232 429 440 232 437 minecraft:black_concrete
fill 440 232 438 440 232 440 minecraft:glowstone
fill 441 232 429 441 232 436 minecraft:iron_block
fill 441 232 437 441 232 438 minecraft:glowstone
fill 441 232 440 441 232 441 minecraft:glowstone
fill 441 232 442 441 232 451 minecraft:iron_block
fill 442 232 429 442 232 435 minecraft:black_concrete
fill 442 232 436 442 232 437 minecraft:glowstone
fill 442 232 441 442 232 442 minecraft:glowstone
fill 442 232 443 442 232 451 minecraft:black_concrete
fill 443 232 429 443 232 435 minecraft:iron_block
fill 443 232 436 444 232 436 minecraft:glowstone
fill 443 232 442 444 232 442 minecraft:glowstone
fill 443 232 443 443 232 451 minecraft:iron_block
fill 444 232 429 444 232 435 minecraft:black_concrete
fill 444 232 437 445 232 437 minecraft:glowstone
fill 444 232 441 445 232 441 minecraft:glowstone
fill 444 232 443 444 232 451 minecraft:black_concrete
fill 445 232 429 445 232 436 minecraft:iron_block
fill 445 232 438 446 232 438 minecraft:glowstone
fill 445 232 440 446 232 440 minecraft:glowstone
fill 445 232 442 445 232 451 minecraft:iron_block
fill 446 232 429 446 232 437 minecraft:black_concrete
setblock 446 232 439 minecraft:glowstone
fill 447 232 440 464 232 440 minecraft:stone_bricks
setblock 426 234 419 minecraft:light[level=12]
setblock 426 234 427 minecraft:light[level=12]
setblock 426 234 435 minecraft:light[level=12]
setblock 426 234 443 minecraft:light[level=12]
setblock 426 234 451 minecraft:light[level=12]
setblock 434 234 419 minecraft:light[level=12]
setblock 434 234 427 minecraft:light[level=12]
setblock 434 234 435 minecraft:light[level=12]
setblock 434 234 443 minecraft:light[level=12]
setblock 434 234 451 minecraft:light[level=12]
setblock 442 234 419 minecraft:light[level=12]
setblock 442 234 427 minecraft:light[level=12]
setblock 442 234 435 minecraft:light[level=12]
setblock 442 234 443 minecraft:light[level=12]
setblock 442 234 451 minecraft:light[level=12]
setblock 450 234 419 minecraft:light[level=12]
setblock 450 234 427 minecraft:light[level=12]
setblock 450 234 435 minecraft:light[level=12]
setblock 450 234 443 minecraft:light[level=12]
setblock 450 234 451 minecraft:light[level=12]
setblock 458 234 419 minecraft:light[level=12]
setblock 458 234 427 minecraft:light[level=12]
setblock 458 234 435 minecraft:light[level=12]
setblock 458 234 443 minecraft:light[level=12]
setblock 458 234 451 minecraft:light[level=12]
fill 424 236 417 426 244 430 minecraft:iron_block
fill 424 236 439 424 273 441 minecraft:iron_block
fill 424 236 451 424 273 453 minecraft:iron_block
fill 427 236 418 427 257 430 minecraft:iron_block
fill 430 236 457 432 273 457 minecraft:iron_block
fill 433 236 417 443 237 426 minecraft:iron_block
fill 442 236 457 444 273 457 minecraft:iron_block
fill 448 236 417 450 273 417 minecraft:iron_block
fill 454 236 457 456 273 457 minecraft:iron_block
fill 456 236 441 464 237 453 minecraft:iron_block
fill 460 236 417 462 273 417 minecraft:iron_block
fill 464 236 425 464 273 427 minecraft:iron_block
fill 464 236 437 464 273 439 minecraft:iron_block
fill 433 238 417 433 244 417 minecraft:iron_block
setblock 433 238 418 minecraft:glowstone
fill 433 238 419 433 260 419 minecraft:iron_block
setblock 433 238 420 minecraft:glowstone
fill 433 238 421 433 260 421 minecraft:iron_block
setblock 433 238 422 minecraft:glowstone
fill 433 238 423 433 260 423 minecraft:iron_block
setblock 433 238 424 minecraft:glowstone
fill 433 238 425 433 260 425 minecraft:iron_block
setblock 433 238 426 minecraft:glowstone
setblock 434 238 417 minecraft:glowstone
fill 434 238 418 434 260 418 minecraft:iron_block
setblock 434 238 419 minecraft:glowstone
fill 434 238 420 434 260 420 minecraft:iron_block
setblock 434 238 421 minecraft:glowstone
fill 434 238 422 434 260 422 minecraft:iron_block
setblock 434 238 423 minecraft:glowstone
fill 434 238 424 434 260 424 minecraft:iron_block
setblock 434 238 425 minecraft:glowstone
fill 434 238 426 434 260 426 minecraft:iron_block
fill 435 238 417 435 260 417 minecraft:iron_block
setblock 435 238 418 minecraft:glowstone
fill 435 238 419 435 260 419 minecraft:iron_block
setblock 435 238 420 minecraft:glowstone
fill 435 238 421 435 260 421 minecraft:iron_block
setblock 435 238 422 minecraft:glowstone
fill 435 238 423 435 260 423 minecraft:iron_block
setblock 435 238 424 minecraft:glowstone
fill 435 238 425 435 260 425 minecraft:iron_block
setblock 435 238 426 minecraft:glowstone
setblock 436 238 417 minecraft:glowstone
fill 436 238 418 436 265 418 minecraft:iron_block
setblock 436 238 419 minecraft:glowstone
fill 436 238 420 436 260 420 minecraft:iron_block
setblock 436 238 421 minecraft:glowstone
fill 436 238 422 436 260 422 minecraft:iron_block
setblock 436 238 423 minecraft:glowstone
fill 436 238 424 436 260 424 minecraft:iron_block
setblock 436 238 425 minecraft:glowstone
fill 436 238 426 436 260 426 minecraft:iron_block
fill 437 238 417 437 273 417 minecraft:iron_block
setblock 437 238 418 minecraft:glowstone
fill 437 238 419 437 260 419 minecraft:iron_block
setblock 437 238 420 minecraft:glowstone
fill 437 238 421 437 260 421 minecraft:iron_block
setblock 437 238 422 minecraft:glowstone
fill 437 238 423 437 260 423 minecraft:iron_block
setblock 437 238 424 minecraft:glowstone
fill 437 238 425 437 260 425 minecraft:iron_block
setblock 437 238 426 minecraft:glowstone
setblock 438 238 417 minecraft:glowstone
fill 438 238 418 438 260 418 minecraft:iron_block
setblock 438 238 419 minecraft:glowstone
fill 438 238 420 438 260 420 minecraft:iron_block
setblock 438 238 421 minecraft:glowstone
fill 438 238 422 438 260 422 minecraft:iron_block
setblock 438 238 423 minecraft:glowstone
fill 438 238 424 438 260 424 minecraft:iron_block
setblock 438 238 425 minecraft:glowstone
fill 438 238 426 438 260 426 minecraft:iron_block
fill 439 238 417 439 260 417 minecraft:iron_block
setblock 439 238 418 minecraft:glowstone
fill 439 238 419 439 260 419 minecraft:iron_block
setblock 439 238 420 minecraft:glowstone
fill 439 238 421 439 260 421 minecraft:iron_block
setblock 439 238 422 minecraft:glowstone
fill 439 238 423 439 260 423 minecraft:iron_block
setblock 439 238 424 minecraft:glowstone
fill 439 238 425 439 260 425 minecraft:iron_block
setblock 439 238 426 minecraft:glowstone
setblock 440 238 417 minecraft:glowstone
fill 440 238 418 440 260 418 minecraft:iron_block
setblock 440 238 419 minecraft:glowstone
fill 440 238 420 440 260 420 minecraft:iron_block
setblock 440 238 421 minecraft:glowstone
fill 440 238 422 440 260 422 minecraft:iron_block
setblock 440 238 423 minecraft:glowstone
fill 440 238 424 440 260 424 minecraft:iron_block
setblock 440 238 425 minecraft:glowstone
fill 440 238 426 440 260 426 minecraft:iron_block
fill 441 238 417 441 244 417 minecraft:iron_block
setblock 441 238 418 minecraft:glowstone
fill 441 238 419 441 260 419 minecraft:iron_block
setblock 441 238 420 minecraft:glowstone
fill 441 238 421 441 260 421 minecraft:iron_block
setblock 441 238 422 minecraft:glowstone
fill 441 238 423 441 260 423 minecraft:iron_block
setblock 441 238 424 minecraft:glowstone
fill 441 238 425 441 260 425 minecraft:iron_block
setblock 441 238 426 minecraft:glowstone
setblock 442 238 417 minecraft:glowstone
fill 442 238 418 442 260 418 minecraft:iron_block
setblock 442 238 419 minecraft:glowstone
fill 442 238 420 442 260 420 minecraft:iron_block
setblock 442 238 421 minecraft:glowstone
fill 442 238 422 442 260 422 minecraft:iron_block
setblock 442 238 423 minecraft:glowstone
fill 442 238 424 442 260 424 minecraft:iron_block
setblock 442 238 425 minecraft:glowstone
fill 442 238 426 442 260 426 minecraft:iron_block
fill 443 238 417 443 244 417 minecraft:iron_block
setblock 443 238 418 minecraft:glowstone
fill 443 238 419 443 260 419 minecraft:iron_block
setblock 443 238 420 minecraft:glowstone
fill 443 238 421 443 260 421 minecraft:iron_block
setblock 443 238 422 minecraft:glowstone
fill 443 238 423 443 260 423 minecraft:iron_block
setblock 443 238 424 minecraft:glowstone
fill 443 238 425 443 260 425 minecraft:iron_block
setblock 443 238 426 minecraft:glowstone
setblock 456 238 441 minecraft:glowstone
fill 456 238 442 456 255 442 minecraft:iron_block
setblock 456 238 443 minecraft:glowstone
fill 456 238 444 456 255 444 minecraft:iron_block
setblock 456 238 445 minecraft:glowstone
fill 456 238 446 456 255 446 minecraft:iron_block
setblock 456 238 447 minecraft:glowstone
fill 456 238 448 456 255 448 minecraft:iron_block
setblock 456 238 449 minecraft:glowstone
fill 456 238 450 456 255 450 minecraft:iron_block
setblock 456 238 451 minecraft:glowstone
fill 456 238 452 456 255 452 minecraft:iron_block
setblock 456 238 453 minecraft:glowstone
fill 457 238 441 457 255 441 minecraft:iron_block
setblock 457 238 442 minecraft:glowstone
fill 457 238 443 457 255 443 minecraft:iron_block
setblock 457 238 444 minecraft:glowstone
fill 457 238 445 457 255 445 minecraft:iron_block
setblock 457 238 446 minecraft:glowstone
fill 457 238 447 457 255 447 minecraft:iron_block
setblock 457 238 448 minecraft:glowstone
fill 457 238 449 457 255 449 minecraft:iron_block
setblock 457 238 450 minecraft:glowstone
fill 457 238 451 457 255 451 minecraft:iron_block
setblock 457 238 452 minecraft:glowstone
fill 457 238 453 457 255 453 minecraft:iron_block
setblock 458 238 441 minecraft:glowstone
fill 458 238 442 458 255 442 minecraft:iron_block
setblock 458 238 443 minecraft:glowstone
fill 458 238 444 458 255 444 minecraft:iron_block
setblock 458 238 445 minecraft:glowstone
fill 458 238 446 458 255 446 minecraft:iron_block
setblock 458 238 447 minecraft:glowstone
fill 458 238 448 458 255 448 minecraft:iron_block
setblock 458 238 449 minecraft:glowstone
fill 458 238 450 458 255 450 minecraft:iron_block
setblock 458 238 451 minecraft:glowstone
fill 458 238 452 458 255 452 minecraft:iron_block
setblock 458 238 453 minecraft:glowstone
fill 459 238 441 459 255 441 minecraft:iron_block
setblock 459 238 442 minecraft:glowstone
fill 459 238 443 459 255 443 minecraft:iron_block
setblock 459 238 444 minecraft:glowstone
fill 459 238 445 459 255 445 minecraft:iron_block
setblock 459 238 446 minecraft:glowstone
fill 459 238 447 459 255 447 minecraft:iron_block
setblock 459 238 448 minecraft:glowstone
fill 459 238 449 459 255 449 minecraft:iron_block
setblock 459 238 450 minecraft:glowstone
fill 459 238 451 459 255 451 minecraft:iron_block
setblock 459 238 452 minecraft:glowstone
fill 459 238 453 459 255 453 minecraft:iron_block
setblock 460 238 441 minecraft:glowstone
fill 460 238 442 460 255 442 minecraft:iron_block
setblock 460 238 443 minecraft:glowstone
fill 460 238 444 460 255 444 minecraft:iron_block
setblock 460 238 445 minecraft:glowstone
fill 460 238 446 460 255 446 minecraft:iron_block
setblock 460 238 447 minecraft:glowstone
fill 460 238 448 460 255 448 minecraft:iron_block
setblock 460 238 449 minecraft:glowstone
fill 460 238 450 460 255 450 minecraft:iron_block
setblock 460 238 451 minecraft:glowstone
fill 460 238 452 460 255 452 minecraft:iron_block
setblock 460 238 453 minecraft:glowstone
fill 461 238 441 461 255 441 minecraft:iron_block
setblock 461 238 442 minecraft:glowstone
fill 461 238 443 461 255 443 minecraft:iron_block
setblock 461 238 444 minecraft:glowstone
fill 461 238 445 461 255 445 minecraft:iron_block
setblock 461 238 446 minecraft:glowstone
fill 461 238 447 461 255 447 minecraft:iron_block
setblock 461 238 448 minecraft:glowstone
fill 461 238 449 461 255 449 minecraft:iron_block
setblock 461 238 450 minecraft:glowstone
fill 461 238 451 461 255 451 minecraft:iron_block
setblock 461 238 452 minecraft:glowstone
fill 461 238 453 461 255 453 minecraft:iron_block
setblock 462 238 441 minecraft:glowstone
fill 462 238 442 462 255 442 minecraft:iron_block
setblock 462 238 443 minecraft:glowstone
fill 462 238 444 462 255 444 minecraft:iron_block
setblock 462 238 445 minecraft:glowstone
fill 462 238 446 462 255 446 minecraft:iron_block
setblock 462 238 447 minecraft:glowstone
fill 462 238 448 462 255 448 minecraft:iron_block
setblock 462 238 449 minecraft:glowstone
fill 462 238 450 462 255 450 minecraft:iron_block
setblock 462 238 451 minecraft:glowstone
fill 462 238 452 462 255 452 minecraft:iron_block
setblock 462 238 453 minecraft:glowstone
fill 463 238 441 463 255 441 minecraft:iron_block
setblock 463 238 442 minecraft:glowstone
fill 463 238 443 463 255 443 minecraft:iron_block
setblock 463 238 444 minecraft:glowstone
fill 463 238 445 463 255 445 minecraft:iron_block
setblock 463 238 446 minecraft:glowstone
fill 463 238 447 463 255 447 minecraft:iron_block
setblock 463 238 448 minecraft:glowstone
fill 463 238 449 463 255 449 minecraft:iron_block
setblock 463 238 450 minecraft:glowstone
fill 463 238 451 463 255 451 minecraft:iron_block
setblock 463 238 452 minecraft:glowstone
fill 463 238 453 463 255 453 minecraft:iron_block
setblock 464 238 441 minecraft:glowstone
fill 464 238 442 464 244 442 minecraft:iron_block
setblock 464 238 443 minecraft:glowstone
fill 464 238 444 464 244 444 minecraft:iron_block
setblock 464 238 445 minecraft:glowstone
fill 464 238 446 464 244 446 minecraft:iron_block
setblock 464 238 447 minecraft:glowstone
fill 464 238 448 464 255 448 minecraft:iron_block
setblock 464 238 449 minecraft:glowstone
fill 464 238 450 464 273 450 minecraft:iron_block
setblock 464 238 451 minecraft:glowstone
fill 464 238 452 464 255 452 minecraft:iron_block
setblock 464 238 453 minecraft:glowstone
fill 433 239 418 433 240 418 minecraft:iron_block
fill 433 239 420 433 240 420 minecraft:iron_block
fill 433 239 422 433 240 422 minecraft:iron_block
fill 433 239 424 433 240 424 minecraft:iron_block
fill 433 239 426 433 240 426 minecraft:iron_block
fill 434 239 417 434 240 417 minecraft:iron_block
fill 434 239 419 434 240 419 minecraft:iron_block
fill 434 239 421 434 240 421 minecraft:iron_block
fill 434 239 423 434 240 423 minecraft:iron_block
fill 434 239 425 434 240 425 minecraft:iron_block
fill 435 239 418 435 240 418 minecraft:iron_block
fill 435 239 420 435 240 420 minecraft:iron_block
fill 435 239 422 435 240 422 minecraft:iron_block
fill 435 239 424 435 240 424 minecraft:iron_block
fill 435 239 426 435 240 426 minecraft:iron_block
fill 436 239 417 436 240 417 minecraft:iron_block
fill 436 239 419 436 240 419 minecraft:iron_block
fill 436 239 421 436 240 421 minecraft:iron_block
fill 436 239 423 436 240 423 minecraft:iron_block
fill 436 239 425 436 240 425 minecraft:iron_block
fill 437 239 418 437 240 418 minecraft:iron_block
fill 437 239 420 437 240 420 minecraft:iron_block
fill 437 239 422 437 240 422 minecraft:iron_block
fill 437 239 424 437 240 424 minecraft:iron_block
fill 437 239 426 437 240 426 minecraft:iron_block
fill 438 239 417 438 240 417 minecraft:iron_block
fill 438 239 419 438 240 419 minecraft:iron_block
fill 438 239 421 438 240 421 minecraft:iron_block
fill 438 239 423 438 240 423 minecraft:iron_block
fill 438 239 425 438 240 425 minecraft:iron_block
fill 439 239 418 439 240 418 minecraft:iron_block
fill 439 239 420 439 240 420 minecraft:iron_block
fill 439 239 422 439 240 422 minecraft:iron_block
fill 439 239 424 439 240 424 minecraft:iron_block
fill 439 239 426 439 240 426 minecraft:iron_block
fill 440 239 417 440 240 417 minecraft:iron_block
fill 440 239 419 440 240 419 minecraft:iron_block
fill 440 239 421 440 240 421 minecraft:iron_block
fill 440 239 423 440 240 423 minecraft:iron_block
fill 440 239 425 440 240 425 minecraft:iron_block
fill 441 239 418 441 240 418 minecraft:iron_block
fill 441 239 420 441 240 420 minecraft:iron_block
fill 441 239 422 441 240 422 minecraft:iron_block
fill 441 239 424 441 240 424 minecraft:iron_block
fill 441 239 426 441 240 426 minecraft:iron_block
fill 442 239 417 442 240 417 minecraft:iron_block
fill 442 239 419 442 240 419 minecraft:iron_block
fill 442 239 421 442 240 421 minecraft:iron_block
fill 442 239 423 442 240 423 minecraft:iron_block
fill 442 239 425 442 240 425 minecraft:iron_block
fill 443 239 418 443 240 418 minecraft:iron_block
fill 443 239 420 443 240 420 minecraft:iron_block
fill 443 239 422 443 240 422 minecraft:iron_block
fill 443 239 424 443 240 424 minecraft:iron_block
fill 443 239 426 443 240 426 minecraft:iron_block
fill 456 239 441 456 240 441 minecraft:iron_block
fill 456 239 443 456 240 443 minecraft:iron_block
fill 456 239 445 456 240 445 minecraft:iron_block
fill 456 239 447 456 240 447 minecraft:iron_block
fill 456 239 449 456 240 449 minecraft:iron_block
fill 456 239 451 456 240 451 minecraft:iron_block
fill 456 239 453 456 240 453 minecraft:iron_block
fill 457 239 442 457 240 442 minecraft:iron_block
fill 457 239 444 457 240 444 minecraft:iron_block
fill 457 239 446 457 240 446 minecraft:iron_block
fill 457 239 448 457 240 448 minecraft:iron_block
fill 457 239 450 457 240 450 minecraft:iron_block
fill 457 239 452 457 240 452 minecraft:iron_block
fill 458 239 441 458 240 441 minecraft:iron_block
fill 458 239 443 458 240 443 minecraft:iron_block
fill 458 239 445 458 240 445 minecraft:iron_block
fill 458 239 447 458 240 447 minecraft:iron_block
fill 458 239 449 458 240 449 minecraft:iron_block
fill 458 239 451 458 240 451 minecraft:iron_block
fill 458 239 453 458 240 453 minecraft:iron_block
fill 459 239 442 459 240 442 minecraft:iron_block
fill 459 239 444 459 240 444 minecraft:iron_block
fill 459 239 446 459 240 446 minecraft:iron_block
fill 459 239 448 459 240 448 minecraft:iron_block
fill 459 239 450 459 240 450 minecraft:iron_block
fill 459 239 452 459 240 452 minecraft:iron_block
fill 460 239 441 460 240 441 minecraft:iron_block
fill 460 239 443 460 240 443 minecraft:iron_block
fill 460 239 445 460 240 445 minecraft:iron_block
fill 460 239 447 460 240 447 minecraft:iron_block
fill 460 239 449 460 240 449 minecraft:iron_block
fill 460 239 451 460 240 451 minecraft:iron_block
fill 460 239 453 460 240 453 minecraft:iron_block
fill 461 239 442 461 240 442 minecraft:iron_block
fill 461 239 444 461 240 444 minecraft:iron_block
fill 461 239 446 461 240 446 minecraft:iron_block
fill 461 239 448 461 240 448 minecraft:iron_block
fill 461 239 450 461 240 450 minecraft:iron_block
fill 461 239 452 461 240 452 minecraft:iron_block
fill 462 239 441 462 240 441 minecraft:iron_block
fill 462 239 443 462 240 443 minecraft:iron_block
fill 462 239 445 462 240 445 minecraft:iron_block
fill 462 239 447 462 240 447 minecraft:iron_block
fill 462 239 449 462 240 449 minecraft:iron_block
fill 462 239 451 462 240 451 minecraft:iron_block
fill 462 239 453 462 240 453 minecraft:iron_block
fill 463 239 442 463 240 442 minecraft:iron_block
fill 463 239 444 463 240 444 minecraft:iron_block
fill 463 239 446 463 240 446 minecraft:iron_block
fill 463 239 448 463 240 448 minecraft:iron_block
fill 463 239 450 463 240 450 minecraft:iron_block
fill 463 239 452 463 240 452 minecraft:iron_block
fill 464 239 441 464 240 441 minecraft:iron_block
fill 464 239 443 464 240 443 minecraft:iron_block
fill 464 239 445 464 240 445 minecraft:iron_block
fill 464 239 447 464 240 447 minecraft:iron_block
fill 464 239 449 464 240 449 minecraft:iron_block
fill 464 239 451 464 240 451 minecraft:iron_block
fill 464 239 453 464 240 453 minecraft:iron_block
fill 425 240 438 425 245 440 minecraft:iron_block
fill 425 240 450 425 245 452 minecraft:iron_block
fill 431 240 456 433 245 456 minecraft:iron_block
fill 443 240 456 445 245 456 minecraft:iron_block
fill 447 240 418 449 245 418 minecraft:iron_block
fill 455 240 456 457 245 456 minecraft:iron_block
fill 459 240 418 461 245 418 minecraft:iron_block
fill 463 240 426 463 245 428 minecraft:iron_block
fill 463 240 438 463 245 440 minecraft:iron_block
setblock 433 241 418 minecraft:glowstone
setblock 433 241 420 minecraft:glowstone
setblock 433 241 422 minecraft:glowstone
setblock 433 241 424 minecraft:glowstone
setblock 433 241 426 minecraft:glowstone
setblock 434 241 417 minecraft:glowstone
setblock 434 241 419 minecraft:glowstone
setblock 434 241 421 minecraft:glowstone
setblock 434 241 423 minecraft:glowstone
setblock 434 241 425 minecraft:glowstone
setblock 435 241 418 minecraft:glowstone
setblock 435 241 420 minecraft:glowstone
setblock 435 241 422 minecraft:glowstone
setblock 435 241 424 minecraft:glowstone
setblock 435 241 426 minecraft:glowstone
setblock 436 241 417 minecraft:glowstone
setblock 436 241 419 minecraft:glowstone
setblock 436 241 421 minecraft:glowstone
setblock 436 241 423 minecraft:glowstone
setblock 436 241 425 minecraft:glowstone
setblock 437 241 418 minecraft:glowstone
setblock 437 241 420 minecraft:glowstone
setblock 437 241 422 minecraft:glowstone
setblock 437 241 424 minecraft:glowstone
setblock 437 241 426 minecraft:glowstone
setblock 438 241 417 minecraft:glowstone
setblock 438 241 419 minecraft:glowstone
setblock 438 241 421 minecraft:glowstone
setblock 438 241 423 minecraft:glowstone
setblock 438 241 425 minecraft:glowstone
setblock 439 241 418 minecraft:glowstone
setblock 439 241 420 minecraft:glowstone
setblock 439 241 422 minecraft:glowstone
setblock 439 241 424 minecraft:glowstone
setblock 439 241 426 minecraft:glowstone
setblock 440 241 417 minecraft:glowstone
setblock 440 241 419 minecraft:glowstone
setblock 440 241 421 minecraft:glowstone
setblock 440 241 423 minecraft:glowstone
setblock 440 241 425 minecraft:glowstone
setblock 441 241 418 minecraft:glowstone
setblock 441 241 420 minecraft:glowstone
setblock 441 241 422 minecraft:glowstone
setblock 441 241 424 minecraft:glowstone
setblock 441 241 426 minecraft:glowstone
setblock 442 241 417 minecraft:glowstone
setblock 442 241 419 minecraft:glowstone
setblock 442 241 421 minecraft:glowstone
setblock 442 241 423 minecraft:glowstone
setblock 442 241 425 minecraft:glowstone
setblock 443 241 418 minecraft:glowstone
setblock 443 241 420 minecraft:glowstone
setblock 443 241 422 minecraft:glowstone
setblock 443 241 424 minecraft:glowstone
setblock 443 241 426 minecraft:glowstone
setblock 456 241 441 minecraft:glowstone
setblock 456 241 443 minecraft:glowstone
setblock 456 241 445 minecraft:glowstone
setblock 456 241 447 minecraft:glowstone
setblock 456 241 449 minecraft:glowstone
setblock 456 241 451 minecraft:glowstone
setblock 456 241 453 minecraft:glowstone
setblock 457 241 442 minecraft:glowstone
setblock 457 241 444 minecraft:glowstone
setblock 457 241 446 minecraft:glowstone
setblock 457 241 448 minecraft:glowstone
setblock 457 241 450 minecraft:glowstone
setblock 457 241 452 minecraft:glowstone
setblock 458 241 441 minecraft:glowstone
setblock 458 241 443 minecraft:glowstone
setblock 458 241 445 minecraft:glowstone
setblock 458 241 447 minecraft:glowstone
setblock 458 241 449 minecraft:glowstone
setblock 458 241 451 minecraft:glowstone
setblock 458 241 453 minecraft:glowstone
setblock 459 241 442 minecraft:glowstone
setblock 459 241 444 minecraft:glowstone
setblock 459 241 446 minecraft:glowstone
setblock 459 241 448 minecraft:glowstone
setblock 459 241 450 minecraft:glowstone
setblock 459 241 452 minecraft:glowstone
setblock 460 241 441 minecraft:glowstone
setblock 460 241 443 minecraft:glowstone
setblock 460 241 445 minecraft:glowstone
setblock 460 241 447 minecraft:glowstone
setblock 460 241 449 minecraft:glowstone
setblock 460 241 451 minecraft:glowstone
setblock 460 241 453 minecraft:glowstone
setblock 461 241 442 minecraft:glowstone
setblock 461 241 444 minecraft:glowstone
setblock 461 241 446 minecraft:glowstone
setblock 461 241 448 minecraft:glowstone
setblock 461 241 450 minecraft:glowstone
setblock 461 241 452 minecraft:glowstone
setblock 462 241 441 minecraft:glowstone
setblock 462 241 443 minecraft:glowstone
setblock 462 241 445 minecraft:glowstone
setblock 462 241 447 minecraft:glowstone
setblock 462 241 449 minecraft:glowstone
setblock 462 241 451 minecraft:glowstone
setblock 462 241 453 minecraft:glowstone
setblock 463 241 442 minecraft:glowstone
setblock 463 241 444 minecraft:glowstone
setblock 463 241 446 minecraft:glowstone
setblock 463 241 448 minecraft:glowstone
setblock 463 241 450 minecraft:glowstone
setblock 463 241 452 minecraft:glowstone
setblock 464 241 441 minecraft:glowstone
setblock 464 241 443 minecraft:glowstone
setblock 464 241 445 minecraft:glowstone
setblock 464 241 447 minecraft:glowstone
setblock 464 241 449 minecraft:glowstone
setblock 464 241 451 minecraft:glowstone
setblock 464 241 453 minecraft:glowstone
setblock 426 242 435 minecraft:light[level=12]
setblock 426 242 443 minecraft:light[level=12]
setblock 426 242 451 minecraft:light[level=12]
fill 433 242 418 433 243 418 minecraft:iron_block
fill 433 242 420 433 243 420 minecraft:iron_block
fill 433 242 422 433 243 422 minecraft:iron_block
fill 433 242 424 433 243 424 minecraft:iron_block
fill 433 242 426 433 243 426 minecraft:iron_block
fill 434 242 417 434 243 417 minecraft:iron_block
fill 434 242 419 434 243 419 minecraft:iron_block
fill 434 242 421 434 243 421 minecraft:iron_block
fill 434 242 423 434 243 423 minecraft:iron_block
fill 434 242 425 434 243 425 minecraft:iron_block
setblock 434 242 427 minecraft:light[level=12]
setblock 434 242 435 minecraft:light[level=12]
setblock 434 242 443 minecraft:light[level=12]
setblock 434 242 451 minecraft:light[level=12]
fill 435 242 418 435 243 418 minecraft:iron_block
fill 435 242 420 435 243 420 minecraft:iron_block
fill 435 242 422 435 243 422 minecraft:iron_block
fill 435 242 424 435 243 424 minecraft:iron_block
fill 435 242 426 435 243 426 minecraft:iron_block
fill 436 242 417 436 243 417 minecraft:iron_block
fill 436 242 419 436 243 419 minecraft:iron_block
fill 436 242 421 436 243 421 minecraft:iron_block
fill 436 242 423 436 243 423 minecraft:iron_block
fill 436 242 425 436 243 425 minecraft:iron_block
fill 437 242 418 437 243 418 minecraft:iron_block
fill 437 242 420 437 243 420 minecraft:iron_block
fill 437 242 422 437 243 422 minecraft:iron_block
fill 437 242 424 437 243 424 minecraft:iron_block
fill 437 242 426 437 243 426 minecraft:iron_block
fill 438 242 417 438 243 417 minecraft:iron_block
fill 438 242 419 438 243 419 minecraft:iron_block
fill 438 242 421 438 243 421 minecraft:iron_block
fill 438 242 423 438 243 423 minecraft:iron_block
fill 438 242 425 438 243 425 minecraft:iron_block
fill 439 242 418 439 243 418 minecraft:iron_block
fill 439 242 420 439 243 420 minecraft:iron_block
fill 439 242 422 439 243 422 minecraft:iron_block
fill 439 242 424 439 243 424 minecraft:iron_block
fill 439 242 426 439 243 426 minecraft:iron_block
fill 440 242 417 440 243 417 minecraft:iron_block
fill 440 242 419 440 243 419 minecraft:iron_block
fill 440 242 421 440 243 421 minecraft:iron_block
fill 440 242 423 440 243 423 minecraft:iron_block
fill 440 242 425 440 243 425 minecraft:iron_block
fill 441 242 418 441 243 418 minecraft:iron_block
fill 441 242 420 441 243 420 minecraft:iron_block
fill 441 242 422 441 243 422 minecraft:iron_block
fill 441 242 424 441 243 424 minecraft:iron_block
fill 441 242 426 441 243 426 minecraft:iron_block
fill 442 242 417 442 243 417 minecraft:iron_block
fill 442 242 419 442 243 419 minecraft:iron_block
fill 442 242 421 442 243 421 minecraft:iron_block
fill 442 242 423 442 243 423 minecraft:iron_block
fill 442 242 425 442 243 425 minecraft:iron_block
setblock 442 242 427 minecraft:light[level=12]
setblock 442 242 435 minecraft:light[level=12]
setblock 442 242 443 minecraft:light[level=12]
setblock 442 242 451 minecraft:light[level=12]
fill 443 242 418 443 243 418 minecraft:iron_block
fill 443 242 420 443 243 420 minecraft:iron_block
fill 443 242 422 443 243 422 minecraft:iron_block
fill 443 242 424 443 243 424 minecraft:iron_block
fill 443 242 426 443 243 426 minecraft:iron_block
setblock 450 242 419 minecraft:light[level=12]
setblock 450 242 427 minecraft:light[level=12]
setblock 450 242 435 minecraft:light[level=12]
setblock 450 242 443 minecraft:light[level=12]
setblock 450 242 451 minecraft:light[level=12]
fill 456 242 441 456 243 441 minecraft:iron_block
fill 456 242 443 456 243 443 minecraft:iron_block
fill 456 242 445 456 243 445 minecraft:iron_block
fill 456 242 447 456 243 447 minecraft:iron_block
fill 456 242 449 456 243 449 minecraft:iron_block
fill 456 242 451 456 243 451 minecraft:iron_block
fill 456 242 453 456 243 453 minecraft:iron_block
fill 457 242 442 457 243 442 minecraft:iron_block
fill 457 242 444 457 243 444 minecraft:iron_block
fill 457 242 446 457 243 446 minecraft:iron_block
fill 457 242 448 457 243 448 minecraft:iron_block
fill 457 242 450 457 243 450 minecraft:iron_block
fill 457 242 452 457 243 452 minecraft:iron_block
setblock 458 242 419 minecraft:light[level=12]
setblock 458 242 427 minecraft:light[level=12]
setblock 458 242 435 minecraft:light[level=12]
fill 458 242 441 458 243 441 minecraft:iron_block
fill 458 242 443 458 243 443 minecraft:iron_block
fill 458 242 445 458 243 445 minecraft:iron_block
fill 458 242 447 458 243 447 minecraft:iron_block
fill 458 242 449 458 243 449 minecraft:iron_block
fill 458 242 451 458 243 451 minecraft:iron_block
fill 458 242 453 458 243 453 minecraft:iron_block
fill 459 242 442 459 243 442 minecraft:iron_block
fill 459 242 444 459 243 444 minecraft:iron_block
fill 459 242 446 459 243 446 minecraft:iron_block
fill 459 242 448 459 243 448 minecraft:iron_block
fill 459 242 450 459 243 450 minecraft:iron_block
fill 459 242 452 459 243 452 minecraft:iron_block
fill 460 242 441 460 243 441 minecraft:iron_block
fill 460 242 443 460 243 443 minecraft:iron_block
fill 460 242 445 460 243 445 minecraft:iron_block
fill 460 242 447 460 243 447 minecraft:iron_block
fill 460 242 449 460 243 449 minecraft:iron_block
fill 460 242 451 460 243 451 minecraft:iron_block
fill 460 242 453 460 243 453 minecraft:iron_block
fill 461 242 442 461 243 442 minecraft:iron_block
fill 461 242 444 461 243 444 minecraft:iron_block
fill 461 242 446 461 243 446 minecraft:iron_block
fill 461 242 448 461 243 448 minecraft:iron_block
fill 461 242 450 461 243 450 minecraft:iron_block
fill 461 242 452 461 243 452 minecraft:iron_block
fill 462 242 441 462 243 441 minecraft:iron_block
fill 462 242 443 462 243 443 minecraft:iron_block
fill 462 242 445 462 243 445 minecraft:iron_block
fill 462 242 447 462 243 447 minecraft:iron_block
fill 462 242 449 462 243 449 minecraft:iron_block
fill 462 242 451 462 243 451 minecraft:iron_block
fill 462 242 453 462 243 453 minecraft:iron_block
fill 463 242 442 463 243 442 minecraft:iron_block
fill 463 242 444 463 243 444 minecraft:iron_block
fill 463 242 446 463 243 446 minecraft:iron_block
fill 463 242 448 463 243 448 minecraft:iron_block
fill 463 242 450 463 243 450 minecraft:iron_block
fill 463 242 452 463 243 452 minecraft:iron_block
fill 464 242 441 464 243 441 minecraft:iron_block
fill 464 242 443 464 243 443 minecraft:iron_block
fill 464 242 445 464 243 445 minecraft:iron_block
fill 464 242 447 464 243 447 minecraft:iron_block
fill 464 242 449 464 243 449 minecraft:iron_block
fill 464 242 451 464 243 451 minecraft:iron_block
fill 464 242 453 464 243 453 minecraft:iron_block
setblock 433 244 418 minecraft:glowstone
setblock 433 244 420 minecraft:glowstone
setblock 433 244 422 minecraft:glowstone
setblock 433 244 424 minecraft:glowstone
setblock 433 244 426 minecraft:glowstone
setblock 434 244 417 minecraft:glowstone
setblock 434 244 419 minecraft:glowstone
setblock 434 244 421 minecraft:glowstone
setblock 434 244 423 minecraft:glowstone
setblock 434 244 425 minecraft:glowstone
setblock 435 244 418 minecraft:glowstone
setblock 435 244 420 minecraft:glowstone
setblock 435 244 422 minecraft:glowstone
setblock 435 244 424 minecraft:glowstone
setblock 435 244 426 minecraft:glowstone
setblock 436 244 417 minecraft:glowstone
setblock 436 244 419 minecraft:glowstone
setblock 436 244 421 minecraft:glowstone
setblock 436 244 423 minecraft:glowstone
setblock 436 244 425 minecraft:glowstone
setblock 437 244 418 minecraft:glowstone
setblock 437 244 420 minecraft:glowstone
setblock 437 244 422 minecraft:glowstone
setblock 437 244 424 minecraft:glowstone
setblock 437 244 426 minecraft:glowstone
setblock 438 244 417 minecraft:glowstone
setblock 438 244 419 minecraft:glowstone
setblock 438 244 421 minecraft:glowstone
setblock 438 244 423 minecraft:glowstone
setblock 438 244 425 minecraft:glowstone
setblock 439 244 418 minecraft:glowstone
setblock 439 244 420 minecraft:glowstone
setblock 439 244 422 minecraft:glowstone
setblock 439 244 424 minecraft:glowstone
setblock 439 244 426 minecraft:glowstone
setblock 440 244 417 minecraft:glowstone
setblock 440 244 419 minecraft:glowstone
setblock 440 244 421 minecraft:glowstone
setblock 440 244 423 minecraft:glowstone
setblock 440 244 425 minecraft:glowstone
setblock 441 244 418 minecraft:glowstone
setblock 441 244 420 minecraft:glowstone
setblock 441 244 422 minecraft:glowstone
setblock 441 244 424 minecraft:glowstone
setblock 441 244 426 minecraft:glowstone
setblock 442 244 417 minecraft:glowstone
setblock 442 244 419 minecraft:glowstone
setblock 442 244 421 minecraft:glowstone
setblock 442 244 423 minecraft:glowstone
setblock 442 244 425 minecraft:glowstone
setblock 443 244 418 minecraft:glowstone
setblock 443 244 420 minecraft:glowstone
setblock 443 244 422 minecraft:glowstone
setblock 443 244 424 minecraft:glowstone
setblock 443 244 426 minecraft:glowstone
setblock 456 244 441 minecraft:glowstone
setblock 456 244 443 minecraft:glowstone
setblock 456 244 445 minecraft:glowstone
setblock 456 244 447 minecraft:glowstone
setblock 456 244 449 minecraft:glowstone
setblock 456 244 451 minecraft:glowstone
setblock 456 244 453 minecraft:glowstone
setblock 457 244 442 minecraft:glowstone
setblock 457 244 444 minecraft:glowstone
setblock 457 244 446 minecraft:glowstone
setblock 457 244 448 minecraft:glowstone
setblock 457 244 450 minecraft:glowstone
setblock 457 244 452 minecraft:glowstone
setblock 458 244 441 minecraft:glowstone
setblock 458 244 443 minecraft:glowstone
setblock 458 244 445 minecraft:glowstone
setblock 458 244 447 minecraft:glowstone
setblock 458 244 449 minecraft:glowstone
setblock 458 244 451 minecraft:glowstone
setblock 458 244 453 minecraft:glowstone
setblock 459 244 442 minecraft:glowstone
setblock 459 244 444 minecraft:glowstone
setblock 459 244 446 minecraft:glowstone
setblock 459 244 448 minecraft:glowstone
setblock 459 244 450 minecraft:glowstone
setblock 459 244 452 minecraft:glowstone
setblock 460 244 441 minecraft:glowstone
setblock 460 244 443 minecraft:glowstone
setblock 460 244 445 minecraft:glowstone
setblock 460 244 447 minecraft:glowstone
setblock 460 244 449 minecraft:glowstone
setblock 460 244 451 minecraft:glowstone
setblock 460 244 453 minecraft:glowstone
setblock 461 244 442 minecraft:glowstone
setblock 461 244 444 minecraft:glowstone
setblock 461 244 446 minecraft:glowstone
setblock 461 244 448 minecraft:glowstone
setblock 461 244 450 minecraft:glowstone
setblock 461 244 452 minecraft:glowstone
setblock 462 244 441 minecraft:glowstone
setblock 462 244 443 minecraft:glowstone
setblock 462 244 445 minecraft:glowstone
setblock 462 244 447 minecraft:glowstone
setblock 462 244 449 minecraft:glowstone
setblock 462 244 451 minecraft:glowstone
setblock 462 244 453 minecraft:glowstone
setblock 463 244 442 minecraft:glowstone
setblock 463 244 444 minecraft:glowstone
setblock 463 244 446 minecraft:glowstone
setblock 463 244 448 minecraft:glowstone
setblock 463 244 450 minecraft:glowstone
setblock 463 244 452 minecraft:glowstone
setblock 464 244 441 minecraft:glowstone
setblock 464 244 443 minecraft:glowstone
setblock 464 244 445 minecraft:glowstone
setblock 464 244 447 minecraft:glowstone
setblock 464 244 449 minecraft:glowstone
setblock 464 244 451 minecraft:glowstone
setblock 464 244 453 minecraft:glowstone
fill 424 245 417 426 257 419 minecraft:iron_block
fill 424 245 420 424 245 425 minecraft:cobblestone
fill 424 245 426 426 257 430 minecraft:iron_block
fill 424 245 432 424 245 437 minecraft:cobblestone
fill 424 245 444 424 245 449 minecraft:cobblestone
fill 424 245 456 424 245 457 minecraft:cobblestone
fill 425 245 420 426 257 425 minecraft:iron_block
fill 425 245 457 428 245 457 minecraft:cobblestone
fill 428 245 417 433 245 417 minecraft:cobblestone
fill 433 245 418 433 246 418 minecraft:iron_block
fill 433 245 420 433 246 420 minecraft:iron_block
fill 433 245 422 433 246 422 minecraft:iron_block
fill 433 245 424 433 246 424 minecraft:iron_block
fill 433 245 426 433 246 426 minecraft:iron_block
fill 434 245 417 434 246 417 minecraft:iron_block
fill 434 245 419 434 246 419 minecraft:iron_block
fill 434 245 421 434 246 421 minecraft:iron_block
fill 434 245 423 434 246 423 minecraft:iron_block
fill 434 245 425 434 246 425 minecraft:iron_block
fill 435 245 418 435 246 418 minecraft:iron_block
fill 435 245 420 435 246 420 minecraft:iron_block
fill 435 245 422 435 246 422 minecraft:iron_block
fill 435 245 424 435 246 424 minecraft:iron_block
fill 435 245 426 435 246 426 minecraft:iron_block
fill 435 245 457 440 245 457 minecraft:cobblestone
fill 436 245 417 436 246 417 minecraft:iron_block
fill 436 245 419 436 246 419 minecraft:iron_block
fill 436 245 421 436 246 421 minecraft:iron_block
fill 436 245 423 436 246 423 minecraft:iron_block
fill 436 245 425 436 246 425 minecraft:iron_block
fill 437 245 418 437 246 418 minecraft:iron_block
fill 437 245 420 437 246 420 minecraft:iron_block
fill 437 245 422 437 246 422 minecraft:iron_block
fill 437 245 424 437 246 424 minecraft:iron_block
fill 437 245 426 437 246 426 minecraft:iron_block
fill 438 245 417 438 246 417 minecraft:iron_block
fill 438 245 419 438 246 419 minecraft:iron_block
fill 438 245 421 438 246 421 minecraft:iron_block
fill 438 245 423 438 246 423 minecraft:iron_block
fill 438 245 425 438 246 425 minecraft:iron_block
fill 439 245 418 439 246 418 minecraft:iron_block
fill 439 245 420 439 246 420 minecraft:iron_block
fill 439 245 422 439 246 422 minecraft:iron_block
fill 439 245 424 439 246 424 minecraft:iron_block
fill 439 245 426 439 246 426 minecraft:iron_block
fill 440 245 417 445 245 417 minecraft:cobblestone
fill 440 245 419 440 246 419 minecraft:iron_block
fill 440 245 421 440 246 421 minecraft:iron_block
fill 440 245 423 440 246 423 minecraft:iron_block
fill 440 245 425 440 246 425 minecraft:iron_block
fill 441 245 418 441 246 418 minecraft:iron_block
fill 441 245 420 441 246 420 minecraft:iron_block
fill 441 245 422 441 246 422 minecraft:iron_block
fill 441 245 424 441 246 424 minecraft:iron_block
fill 441 245 426 441 246 426 minecraft:iron_block
fill 442 245 419 442 246 419 minecraft:iron_block
fill 442 245 421 442 246 421 minecraft:iron_block
fill 442 245 423 442 246 423 minecraft:iron_block
fill 442 245 425 442 246 425 minecraft:iron_block
fill 443 245 418 443 246 418 minecraft:iron_block
fill 443 245 420 443 246 420 minecraft:iron_block
fill 443 245 422 443 246 422 minecraft:iron_block
fill 443 245 424 443 246 424 minecraft:iron_block
fill 443 245 426 443 246 426 minecraft:iron_block
fill 447 245 457 452 245 457 minecraft:cobblestone
fill 452 245 417 457 245 417 minecraft:cobblestone
fill 456 245 441 456 246 441 minecraft:iron_block
fill 456 245 443 456 246 443 minecraft:iron_block
fill 456 245 445 456 246 445 minecraft:iron_block
fill 456 245 447 456 246 447 minecraft:iron_block
fill 456 245 449 456 246 449 minecraft:iron_block
fill 456 245 451 456 246 451 minecraft:iron_block
fill 456 245 453 456 246 453 minecraft:iron_block
fill 457 245 442 457 246 442 minecraft:iron_block
fill 457 245 444 457 246 444 minecraft:iron_block
fill 457 245 446 457 246 446 minecraft:iron_block
fill 457 245 448 457 246 448 minecraft:iron_block
fill 457 245 450 457 246 450 minecraft:iron_block
fill 457 245 452 457 246 452 minecraft:iron_block
fill 458 245 441 458 246 441 minecraft:iron_block
fill 458 245 443 458 246 443 minecraft:iron_block
fill 458 245 445 458 246 445 minecraft:iron_block
fill 458 245 447 458 246 447 minecraft:iron_block
fill 458 245 449 458 246 449 minecraft:iron_block
fill 458 245 451 458 246 451 minecraft:iron_block
fill 458 245 453 458 246 453 minecraft:iron_block
fill 459 245 442 459 246 442 minecraft:iron_block
fill 459 245 444 459 246 444 minecraft:iron_block
fill 459 245 446 459 246 446 minecraft:iron_block
fill 459 245 448 459 246 448 minecraft:iron_block
fill 459 245 450 459 246 450 minecraft:iron_block
fill 459 245 452 459 246 452 minecraft:iron_block
fill 459 245 457 464 245 457 minecraft:cobblestone
fill 460 245 441 460 246 441 minecraft:iron_block
fill 460 245 443 460 246 443 minecraft:iron_block
fill 460 245 445 460 246 445 minecraft:iron_block
fill 460 245 447 460 246 447 minecraft:iron_block
fill 460 245 449 460 246 449 minecraft:iron_block
fill 460 245 451 460 246 451 minecraft:iron_block
fill 460 245 453 460 246 453 minecraft:iron_block
fill 461 245 442 461 246 442 minecraft:iron_block
fill 461 245 444 461 246 444 minecraft:iron_block
fill 461 245 446 461 246 446 minecraft:iron_block
fill 461 245 448 461 246 448 minecraft:iron_block
fill 461 245 450 461 246 450 minecraft:iron_block
fill 461 245 452 461 246 452 minecraft:iron_block
fill 462 245 441 462 246 441 minecraft:iron_block
fill 462 245 443 462 246 443 minecraft:iron_block
fill 462 245 445 462 246 445 minecraft:iron_block
fill 462 245 447 462 246 447 minecraft:iron_block
fill 462 245 449 462 246 449 minecraft:iron_block
fill 462 245 451 462 246 451 minecraft:iron_block
fill 462 245 453 462 246 453 minecraft:iron_block
fill 463 245 442 463 246 442 minecraft:iron_block
fill 463 245 444 463 246 444 minecraft:iron_block
fill 463 245 446 463 246 446 minecraft:iron_block
fill 463 245 448 463 246 448 minecraft:iron_block
fill 463 245 450 463 246 450 minecraft:iron_block
fill 463 245 452 463 246 452 minecraft:iron_block
fill 464 245 417 464 245 422 minecraft:cobblestone
fill 464 245 429 464 245 434 minecraft:cobblestone
fill 464 245 441 464 245 446 minecraft:cobblestone
fill 464 245 447 464 246 447 minecraft:iron_block
fill 464 245 449 464 246 449 minecraft:iron_block
fill 464 245 451 464 246 451 minecraft:iron_block
fill 464 245 453 464 245 456 minecraft:cobblestone
fill 423 246 422 423 251 425 minecraft:glowstone
fill 423 246 434 423 251 437 minecraft:glowstone
fill 423 246 446 423 251 449 minecraft:glowstone
fill 423 246 458 426 251 458 minecraft:glowstone
fill 424 246 420 424 257 425 minecraft:iron_block
fill 430 246 416 433 251 416 minecraft:glowstone
fill 433 246 417 433 260 417 minecraft:iron_block
fill 435 246 458 438 251 458 minecraft:glowstone
fill 440 246 417 443 246 417 minecraft:iron_block
fill 442 246 416 445 251 416 minecraft:glowstone
fill 447 246 458 450 251 458 minecraft:glowstone
fill 454 246 416 457 251 416 minecraft:glowstone
fill 459 246 458 462 251 458 minecraft:glowstone
fill 464 246 441 464 246 446 minecraft:iron_block
setblock 464 246 453 minecraft:iron_block
fill 465 246 417 465 251 420 minecraft:glowstone
fill 465 246 429 465 251 432 minecraft:glowstone
fill 465 246 441 465 251 444 minecraft:glowstone
fill 465 246 453 465 251 456 minecraft:glowstone
setblock 433 247 418 minecraft:glowstone
setblock 433 247 420 minecraft:glowstone
setblock 433 247 422 minecraft:glowstone
setblock 433 247 424 minecraft:glowstone
setblock 433 247 426 minecraft:glowstone
setblock 434 247 417 minecraft:glowstone
setblock 434 247 419 minecraft:glowstone
setblock 434 247 421 minecraft:glowstone
setblock 434 247 423 minecraft:glowstone
setblock 434 247 425 minecraft:glowstone
setblock 435 247 418 minecraft:glowstone
setblock 435 247 420 minecraft:glowstone
setblock 435 247 422 minecraft:glowstone
setblock 435 247 424 minecraft:glowstone
setblock 435 247 426 minecraft:glowstone
setblock 436 247 417 minecraft:glowstone
setblock 436 247 419 minecraft:glowstone
setblock 436 247 421 minecraft:glowstone
setblock 436 247 423 minecraft:glowstone
setblock 436 247 425 minecraft:glowstone
setblock 437 247 418 minecraft:glowstone
setblock 437 247 420 minecraft:glowstone
setblock 437 247 422 minecraft:glowstone
setblock 437 247 424 minecraft:glowstone
setblock 437 247 426 minecraft:glowstone
setblock 438 247 417 minecraft:glowstone
setblock 438 247 419 minecraft:glowstone
setblock 438 247 421 minecraft:glowstone
setblock 438 247 423 minecraft:glowstone
setblock 438 247 425 minecraft:glowstone
setblock 439 247 418 minecraft:glowstone
setblock 439 247 420 minecraft:glowstone
setblock 439 247 422 minecraft:glowstone
setblock 439 247 424 minecraft:glowstone
setblock 439 247 426 minecraft:glowstone
setblock 440 247 417 minecraft:glowstone
setblock 440 247 419 minecraft:glowstone
setblock 440 247 421 minecraft:glowstone
setblock 440 247 423 minecraft:glowstone
setblock 440 247 425 minecraft:glowstone
fill 441 247 417 441 260 417 minecraft:iron_block
setblock 441 247 418 minecraft:glowstone
setblock 441 247 420 minecraft:glowstone
setblock 441 247 422 minecraft:glowstone
setblock 441 247 424 minecraft:glowstone
setblock 441 247 426 minecraft:glowstone
setblock 442 247 417 minecraft:glowstone
setblock 442 247 419 minecraft:glowstone
setblock 442 247 421 minecraft:glowstone
setblock 442 247 423 minecraft:glowstone
setblock 442 247 425 minecraft:glowstone
fill 443 247 417 443 260 417 minecraft:iron_block
setblock 443 247 418 minecraft:glowstone
setblock 443 247 420 minecraft:glowstone
setblock 443 247 422 minecraft:glowstone
setblock 443 247 424 minecraft:glowstone
setblock 443 247 426 minecraft:glowstone
setblock 456 247 441 minecraft:glowstone
setblock 456 247 443 minecraft:glowstone
setblock 456 247 445 minecraft:glowstone
setblock 456 247 447 minecraft:glowstone
setblock 456 247 449 minecraft:glowstone
setblock 456 247 451 minecraft:glowstone
setblock 456 247 453 minecraft:glowstone
setblock 457 247 442 minecraft:glowstone
setblock 457 247 444 minecraft:glowstone
setblock 457 247 446 minecraft:glowstone
setblock 457 247 448 minecraft:glowstone
setblock 457 247 450 minecraft:glowstone
setblock 457 247 452 minecraft:glowstone
setblock 458 247 441 minecraft:glowstone
setblock 458 247 443 minecraft:glowstone
setblock 458 247 445 minecraft:glowstone
setblock 458 247 447 minecraft:glowstone
setblock 458 247 449 minecraft:glowstone
setblock 458 247 451 minecraft:glowstone
setblock 458 247 453 minecraft:glowstone
setblock 459 247 442 minecraft:glowstone
setblock 459 247 444 minecraft:glowstone
setblock 459 247 446 minecraft:glowstone
setblock 459 247 448 minecraft:glowstone
setblock 459 247 450 minecraft:glowstone
setblock 459 247 452 minecraft:glowstone
setblock 460 247 441 minecraft:glowstone
setblock 460 247 443 minecraft:glowstone
setblock 460 247 445 minecraft:glowstone
setblock 460 247 447 minecraft:glowstone
setblock 460 247 449 minecraft:glowstone
setblock 460 247 451 minecraft:glowstone
setblock 460 247 453 minecraft:glowstone
fill 461 247 420 461 256 420 minecraft:iron_bars
setblock 461 247 442 minecraft:glowstone
setblock 461 247 444 minecraft:glowstone
setblock 461 247 446 minecraft:glowstone
setblock 461 247 448 minecraft:glowstone
setblock 461 247 450 minecraft:glowstone
setblock 461 247 452 minecraft:glowstone
setblock 462 247 441 minecraft:glowstone
setblock 462 247 443 minecraft:glowstone
setblock 462 247 445 minecraft:glowstone
setblock 462 247 447 minecraft:glowstone
setblock 462 247 449 minecraft:glowstone
setblock 462 247 451 minecraft:glowstone
setblock 462 247 453 minecraft:glowstone
setblock 463 247 442 minecraft:glowstone
setblock 463 247 444 minecraft:glowstone
setblock 463 247 446 minecraft:glowstone
setblock 463 247 448 minecraft:glowstone
setblock 463 247 450 minecraft:glowstone
setblock 463 247 452 minecraft:glowstone
setblock 464 247 441 minecraft:glowstone
fill 464 247 442 464 255 442 minecraft:iron_block
setblock 464 247 443 minecraft:glowstone
fill 464 247 444 464 255 444 minecraft:iron_block
setblock 464 247 445 minecraft:glowstone
fill 464 247 446 464 255 446 minecraft:iron_block
setblock 464 247 447 minecraft:glowstone
setblock 464 247 449 minecraft:glowstone
setblock 464 247 451 minecraft:glowstone
setblock 464 247 453 minecraft:glowstone
fill 433 248 418 433 249 418 minecraft:iron_block
fill 433 248 420 433 249 420 minecraft:iron_block
fill 433 248 422 433 249 422 minecraft:iron_block
fill 433 248 424 433 249 424 minecraft:iron_block
fill 433 248 426 433 249 426 minecraft:iron_block
fill 434 248 417 434 249 417 minecraft:iron_block
fill 434 248 419 434 249 419 minecraft:iron_block
fill 434 248 421 434 249 421 minecraft:iron_block
fill 434 248 423 434 249 423 minecraft:iron_block
fill 434 248 425 434 249 425 minecraft:iron_block
fill 435 248 418 435 249 418 minecraft:iron_block
fill 435 248 420 435 249 420 minecraft:iron_block
fill 435 248 422 435 249 422 minecraft:iron_block
fill 435 248 424 435 249 424 minecraft:iron_block
fill 435 248 426 435 249 426 minecraft:iron_block
fill 436 248 417 436 249 417 minecraft:iron_block
fill 436 248 419 436 249 419 minecraft:iron_block
fill 436 248 421 436 249 421 minecraft:iron_block
fill 436 248 423 436 249 423 minecraft:iron_block
fill 436 248 425 436 249 425 minecraft:iron_block
fill 437 248 418 437 249 418 minecraft:iron_block
fill 437 248 420 437 249 420 minecraft:iron_block
fill 437 248 422 437 249 422 minecraft:iron_block
fill 437 248 424 437 249 424 minecraft:iron_block
fill 437 248 426 437 249 426 minecraft:iron_block
fill 438 248 417 438 249 417 minecraft:iron_block
fill 438 248 419 438 249 419 minecraft:iron_block
fill 438 248 421 438 249 421 minecraft:iron_block
fill 438 248 423 438 249 423 minecraft:iron_block
fill 438 248 425 438 249 425 minecraft:iron_block
fill 439 248 418 439 249 418 minecraft:iron_block
fill 439 248 420 439 249 420 minecraft:iron_block
fill 439 248 422 439 249 422 minecraft:iron_block
fill 439 248 424 439 249 424 minecraft:iron_block
fill 439 248 426 439 249 426 minecraft:iron_block
fill 440 248 417 440 249 417 minecraft:iron_block
fill 440 248 419 440 249 419 minecraft:iron_block
fill 440 248 421 440 249 421 minecraft:iron_block
fill 440 248 423 440 249 423 minecraft:iron_block
fill 440 248 425 440 249 425 minecraft:iron_block
fill 441 248 418 441 249 418 minecraft:iron_block
fill 441 248 420 441 249 420 minecraft:iron_block
fill 441 248 422 441 249 422 minecraft:iron_block
fill 441 248 424 441 249 424 minecraft:iron_block
fill 441 248 426 441 249 426 minecraft:iron_block
fill 442 248 417 442 249 417 minecraft:iron_block
fill 442 248 419 442 249 419 minecraft:iron_block
fill 442 248 421 442 249 421 minecraft:iron_block
fill 442 248 423 442 249 423 minecraft:iron_block
fill 442 248 425 442 249 425 minecraft:iron_block
fill 443 248 418 443 249 418 minecraft:iron_block
fill 443 248 420 443 249 420 minecraft:iron_block
fill 443 248 422 443 249 422 minecraft:iron_block
fill 443 248 424 443 249 424 minecraft:iron_block
fill 443 248 426 443 249 426 minecraft:iron_block
fill 456 248 441 456 249 441 minecraft:iron_block
fill 456 248 443 456 249 443 minecraft:iron_block
fill 456 248 445 456 249 445 minecraft:iron_block
fill 456 248 447 456 249 447 minecraft:iron_block
fill 456 248 449 456 249 449 minecraft:iron_block
fill 456 248 451 456 249 451 minecraft:iron_block
fill 456 248 453 456 249 453 minecraft:iron_block
fill 457 248 442 457 249 442 minecraft:iron_block
fill 457 248 444 457 249 444 minecraft:iron_block
fill 457 248 446 457 249 446 minecraft:iron_block
fill 457 248 448 457 249 448 minecraft:iron_block
fill 457 248 450 457 249 450 minecraft:iron_block
fill 457 248 452 457 249 452 minecraft:iron_block
fill 458 248 441 458 249 441 minecraft:iron_block
fill 458 248 443 458 249 443 minecraft:iron_block
fill 458 248 445 458 249 445 minecraft:iron_block
fill 458 248 447 458 249 447 minecraft:iron_block
fill 458 248 449 458 249 449 minecraft:iron_block
fill 458 248 451 458 249 451 minecraft:iron_block
fill 458 248 453 458 249 453 minecraft:iron_block
fill 459 248 442 459 249 442 minecraft:iron_block
fill 459 248 444 459 249 444 minecraft:iron_block
fill 459 248 446 459 249 446 minecraft:iron_block
fill 459 248 448 459 249 448 minecraft:iron_block
fill 459 248 450 459 249 450 minecraft:iron_block
fill 459 248 452 459 249 452 minecraft:iron_block
fill 460 248 441 460 249 441 minecraft:iron_block
fill 460 248 443 460 249 443 minecraft:iron_block
fill 460 248 445 460 249 445 minecraft:iron_block
fill 460 248 447 460 249 447 minecraft:iron_block
fill 460 248 449 460 249 449 minecraft:iron_block
fill 460 248 451 460 249 451 minecraft:iron_block
fill 460 248 453 460 249 453 minecraft:iron_block
fill 461 248 442 461 249 442 minecraft:iron_block
fill 461 248 444 461 249 444 minecraft:iron_block
fill 461 248 446 461 249 446 minecraft:iron_block
fill 461 248 448 461 249 448 minecraft:iron_block
fill 461 248 450 461 249 450 minecraft:iron_block
fill 461 248 452 461 249 452 minecraft:iron_block
fill 462 248 441 462 249 441 minecraft:iron_block
fill 462 248 443 462 249 443 minecraft:iron_block
fill 462 248 445 462 249 445 minecraft:iron_block
fill 462 248 447 462 249 447 minecraft:iron_block
fill 462 248 449 462 249 449 minecraft:iron_block
fill 462 248 451 462 249 451 minecraft:iron_block
fill 462 248 453 462 249 453 minecraft:iron_block
fill 463 248 442 463 249 442 minecraft:iron_block
fill 463 248 444 463 249 444 minecraft:iron_block
fill 463 248 446 463 249 446 minecraft:iron_block
fill 463 248 448 463 249 448 minecraft:iron_block
fill 463 248 450 463 249 450 minecraft:iron_block
fill 463 248 452 463 249 452 minecraft:iron_block
fill 464 248 441 464 249 441 minecraft:iron_block
fill 464 248 443 464 249 443 minecraft:iron_block
fill 464 248 445 464 249 445 minecraft:iron_block
fill 464 248 447 464 249 447 minecraft:iron_block
fill 464 248 449 464 249 449 minecraft:iron_block
fill 464 248 451 464 249 451 minecraft:iron_block
fill 464 248 453 464 249 453 minecraft:iron_block
setblock 426 250 435 minecraft:light[level=12]
setblock 426 250 443 minecraft:light[level=12]
setblock 426 250 451 minecraft:light[level=12]
setblock 433 250 418 minecraft:glowstone
setblock 433 250 420 minecraft:glowstone
setblock 433 250 422 minecraft:glowstone
setblock 433 250 424 minecraft:glowstone
setblock 433 250 426 minecraft:glowstone
setblock 434 250 417 minecraft:glowstone
setblock 434 250 419 minecraft:glowstone
setblock 434 250 421 minecraft:glowstone
setblock 434 250 423 minecraft:glowstone
setblock 434 250 425 minecraft:glowstone
setblock 434 250 427 minecraft:light[level=12]
setblock 434 250 435 minecraft:light[level=12]
setblock 434 250 443 minecraft:light[level=12]
setblock 434 250 451 minecraft:light[level=12]
setblock 435 250 418 minecraft:glowstone
setblock 435 250 420 minecraft:glowstone
setblock 435 250 422 minecraft:glowstone
setblock 435 250 424 minecraft:glowstone
setblock 435 250 426 minecraft:glowstone
setblock 436 250 417 minecraft:glowstone
setblock 436 250 419 minecraft:glowstone
setblock 436 250 421 minecraft:glowstone
setblock 436 250 423 minecraft:glowstone
setblock 436 250 425 minecraft:glowstone
setblock 437 250 418 minecraft:glowstone
setblock 437 250 420 minecraft:glowstone
setblock 437 250 422 minecraft:glowstone
setblock 437 250 424 minecraft:glowstone
setblock 437 250 426 minecraft:glowstone
setblock 438 250 417 minecraft:glowstone
setblock 438 250 419 minecraft:glowstone
setblock 438 250 421 minecraft:glowstone
setblock 438 250 423 minecraft:glowstone
setblock 438 250 425 minecraft:glowstone
setblock 439 250 418 minecraft:glowstone
setblock 439 250 420 minecraft:glowstone
setblock 439 250 422 minecraft:glowstone
setblock 439 250 424 minecraft:glowstone
setblock 439 250 426 minecraft:glowstone
setblock 440 250 417 minecraft:glowstone
setblock 440 250 419 minecraft:glowstone
setblock 440 250 421 minecraft:glowstone
setblock 440 250 423 minecraft:glowstone
setblock 440 250 425 minecraft:glowstone
setblock 441 250 418 minecraft:glowstone
setblock 441 250 420 minecraft:glowstone
setblock 441 250 422 minecraft:glowstone
setblock 441 250 424 minecraft:glowstone
setblock 441 250 426 minecraft:glowstone
setblock 442 250 417 minecraft:glowstone
setblock 442 250 419 minecraft:glowstone
setblock 442 250 421 minecraft:glowstone
setblock 442 250 423 minecraft:glowstone
setblock 442 250 425 minecraft:glowstone
setblock 442 250 427 minecraft:light[level=12]
setblock 442 250 435 minecraft:light[level=12]
setblock 442 250 443 minecraft:light[level=12]
setblock 442 250 451 minecraft:light[level=12]
setblock 443 250 418 minecraft:glowstone
setblock 443 250 420 minecraft:glowstone
setblock 443 250 422 minecraft:glowstone
setblock 443 250 424 minecraft:glowstone
setblock 443 250 426 minecraft:glowstone
setblock 450 250 419 minecraft:light[level=12]
setblock 450 250 427 minecraft:light[level=12]
setblock 450 250 435 minecraft:light[level=12]
setblock 450 250 443 minecraft:light[level=12]
setblock 450 250 451 minecraft:light[level=12]
setblock 456 250 441 minecraft:glowstone
setblock 456 250 443 minecraft:glowstone
setblock 456 250 445 minecraft:glowstone
setblock 456 250 447 minecraft:glowstone
setblock 456 250 449 minecraft:glowstone
setblock 456 250 451 minecraft:glowstone
setblock 456 250 453 minecraft:glowstone
setblock 457 250 442 minecraft:glowstone
setblock 457 250 444 minecraft:glowstone
setblock 457 250 446 minecraft:glowstone
setblock 457 250 448 minecraft:glowstone
setblock 457 250 450 minecraft:glowstone
setblock 457 250 452 minecraft:glowstone
setblock 458 250 419 minecraft:light[level=12]
setblock 458 250 427 minecraft:light[level=12]
setblock 458 250 435 minecraft:light[level=12]
setblock 458 250 441 minecraft:glowstone
setblock 458 250 443 minecraft:glowstone
setblock 458 250 445 minecraft:glowstone
setblock 458 250 447 minecraft:glowstone
setblock 458 250 449 minecraft:glowstone
setblock 458 250 451 minecraft:glowstone
setblock 458 250 453 minecraft:glowstone
setblock 459 250 442 minecraft:glowstone
setblock 459 250 444 minecraft:glowstone
setblock 459 250 446 minecraft:glowstone
setblock 459 250 448 minecraft:glowstone
setblock 459 250 450 minecraft:glowstone
setblock 459 250 452 minecraft:glowstone
setblock 460 250 441 minecraft:glowstone
setblock 460 250 443 minecraft:glowstone
setblock 460 250 445 minecraft:glowstone
setblock 460 250 447 minecraft:glowstone
setblock 460 250 449 minecraft:glowstone
setblock 460 250 451 minecraft:glowstone
setblock 460 250 453 minecraft:glowstone
setblock 461 250 442 minecraft:glowstone
setblock 461 250 444 minecraft:glowstone
setblock 461 250 446 minecraft:glowstone
setblock 461 250 448 minecraft:glowstone
setblock 461 250 450 minecraft:glowstone
setblock 461 250 452 minecraft:glowstone
setblock 462 250 441 minecraft:glowstone
setblock 462 250 443 minecraft:glowstone
setblock 462 250 445 minecraft:glowstone
setblock 462 250 447 minecraft:glowstone
setblock 462 250 449 minecraft:glowstone
setblock 462 250 451 minecraft:glowstone
setblock 462 250 453 minecraft:glowstone
setblock 463 250 442 minecraft:glowstone
setblock 463 250 444 minecraft:glowstone
setblock 463 250 446 minecraft:glowstone
setblock 463 250 448 minecraft:glowstone
setblock 463 250 450 minecraft:glowstone
setblock 463 250 452 minecraft:glowstone
setblock 464 250 441 minecraft:glowstone
setblock 464 250 443 minecraft:glowstone
setblock 464 250 445 minecraft:glowstone
setblock 464 250 447 minecraft:glowstone
setblock 464 250 449 minecraft:glowstone
setblock 464 250 451 minecraft:glowstone
setblock 464 250 453 minecraft:glowstone
fill 433 251 418 433 252 418 minecraft:iron_block
fill 433 251 420 433 252 420 minecraft:iron_block
fill 433 251 422 433 252 422 minecraft:iron_block
fill 433 251 424 433 252 424 minecraft:iron_block
fill 433 251 426 433 252 426 minecraft:iron_block
fill 434 251 417 434 252 417 minecraft:iron_block
fill 434 251 419 434 252 419 minecraft:iron_block
fill 434 251 421 434 252 421 minecraft:iron_block
fill 434 251 423 434 252 423 minecraft:iron_block
fill 434 251 425 434 252 425 minecraft:iron_block
fill 435 251 418 435 252 418 minecraft:iron_block
fill 435 251 420 435 252 420 minecraft:iron_block
fill 435 251 422 435 252 422 minecraft:iron_block
fill 435 251 424 435 252 424 minecraft:iron_block
fill 435 251 426 435 252 426 minecraft:iron_block
fill 436 251 417 436 252 417 minecraft:iron_block
fill 436 251 419 436 252 419 minecraft:iron_block
fill 436 251 421 436 252 421 minecraft:iron_block
fill 436 251 423 436 252 423 minecraft:iron_block
fill 436 251 425 436 252 425 minecraft:iron_block
fill 437 251 418 437 252 418 minecraft:iron_block
fill 437 251 420 437 252 420 minecraft:iron_block
fill 437 251 422 437 252 422 minecraft:iron_block
fill 437 251 424 437 252 424 minecraft:iron_block
fill 437 251 426 437 252 426 minecraft:iron_block
fill 438 251 417 438 252 417 minecraft:iron_block
fill 438 251 419 438 252 419 minecraft:iron_block
fill 438 251 421 438 252 421 minecraft:iron_block
fill 438 251 423 438 252 423 minecraft:iron_block
fill 438 251 425 438 252 425 minecraft:iron_block
fill 439 251 418 439 252 418 minecraft:iron_block
fill 439 251 420 439 252 420 minecraft:iron_block
fill 439 251 422 439 252 422 minecraft:iron_block
fill 439 251 424 439 252 424 minecraft:iron_block
fill 439 251 426 439 252 426 minecraft:iron_block
fill 440 251 417 440 252 417 minecraft:iron_block
fill 440 251 419 440 252 419 minecraft:iron_block
fill 440 251 421 440 252 421 minecraft:iron_block
fill 440 251 423 440 252 423 minecraft:iron_block
fill 440 251 425 440 252 425 minecraft:iron_block
fill 441 251 418 441 252 418 minecraft:iron_block
fill 441 251 420 441 252 420 minecraft:iron_block
fill 441 251 422 441 252 422 minecraft:iron_block
fill 441 251 424 441 252 424 minecraft:iron_block
fill 441 251 426 441 252 426 minecraft:iron_block
fill 442 251 417 442 252 417 minecraft:iron_block
fill 442 251 419 442 252 419 minecraft:iron_block
fill 442 251 421 442 252 421 minecraft:iron_block
fill 442 251 423 442 252 423 minecraft:iron_block
fill 442 251 425 442 252 425 minecraft:iron_block
fill 443 251 418 443 252 418 minecraft:iron_block
fill 443 251 420 443 252 420 minecraft:iron_block
fill 443 251 422 443 252 422 minecraft:iron_block
fill 443 251 424 443 252 424 minecraft:iron_block
fill 443 251 426 443 252 426 minecraft:iron_block
fill 456 251 441 456 252 441 minecraft:iron_block
fill 456 251 443 456 252 443 minecraft:iron_block
fill 456 251 445 456 252 445 minecraft:iron_block
fill 456 251 447 456 252 447 minecraft:iron_block
fill 456 251 449 456 252 449 minecraft:iron_block
fill 456 251 451 456 252 451 minecraft:iron_block
fill 456 251 453 456 252 453 minecraft:iron_block
fill 457 251 442 457 252 442 minecraft:iron_block
fill 457 251 444 457 252 444 minecraft:iron_block
fill 457 251 446 457 252 446 minecraft:iron_block
fill 457 251 448 457 252 448 minecraft:iron_block
fill 457 251 450 457 252 450 minecraft:iron_block
fill 457 251 452 457 252 452 minecraft:iron_block
fill 458 251 441 458 252 441 minecraft:iron_block
fill 458 251 443 458 252 443 minecraft:iron_block
fill 458 251 445 458 252 445 minecraft:iron_block
fill 458 251 447 458 252 447 minecraft:iron_block
fill 458 251 449 458 252 449 minecraft:iron_block
fill 458 251 451 458 252 451 minecraft:iron_block
fill 458 251 453 458 252 453 minecraft:iron_block
fill 459 251 442 459 252 442 minecraft:iron_block
fill 459 251 444 459 252 444 minecraft:iron_block
fill 459 251 446 459 252 446 minecraft:iron_block
fill 459 251 448 459 252 448 minecraft:iron_block
fill 459 251 450 459 252 450 minecraft:iron_block
fill 459 251 452 459 252 452 minecraft:iron_block
fill 460 251 441 460 252 441 minecraft:iron_block
fill 460 251 443 460 252 443 minecraft:iron_block
fill 460 251 445 460 252 445 minecraft:iron_block
fill 460 251 447 460 252 447 minecraft:iron_block
fill 460 251 449 460 252 449 minecraft:iron_block
fill 460 251 451 460 252 451 minecraft:iron_block
fill 460 251 453 460 252 453 minecraft:iron_block
fill 461 251 442 461 252 442 minecraft:iron_block
fill 461 251 444 461 252 444 minecraft:iron_block
fill 461 251 446 461 252 446 minecraft:iron_block
fill 461 251 448 461 252 448 minecraft:iron_block
fill 461 251 450 461 252 450 minecraft:iron_block
fill 461 251 452 461 252 452 minecraft:iron_block
fill 462 251 441 462 252 441 minecraft:iron_block
fill 462 251 443 462 252 443 minecraft:iron_block
fill 462 251 445 462 252 445 minecraft:iron_block
fill 462 251 447 462 252 447 minecraft:iron_block
fill 462 251 449 462 252 449 minecraft:iron_block
fill 462 251 451 462 252 451 minecraft:iron_block
fill 462 251 453 462 252 453 minecraft:iron_block
fill 463 251 442 463 252 442 minecraft:iron_block
fill 463 251 444 463 252 444 minecraft:iron_block
fill 463 251 446 463 252 446 minecraft:iron_block
fill 463 251 448 463 252 448 minecraft:iron_block
fill 463 251 450 463 252 450 minecraft:iron_block
fill 463 251 452 463 252 452 minecraft:iron_block
fill 464 251 441 464 252 441 minecraft:iron_block
fill 464 251 443 464 252 443 minecraft:iron_block
fill 464 251 445 464 252 445 minecraft:iron_block
fill 464 251 447 464 252 447 minecraft:iron_block
fill 464 251 449 464 252 449 minecraft:iron_block
fill 464 251 451 464 252 451 minecraft:iron_block
fill 464 251 453 464 252 453 minecraft:iron_block
fill 423 252 422 423 265 422 minecraft:stone_bricks
fill 423 252 423 423 252 424 minecraft:glowstone
fill 423 252 425 423 265 425 minecraft:stone_bricks
fill 423 252 434 423 265 434 minecraft:stone_bricks
fill 423 252 435 423 252 436 minecraft:glowstone
fill 423 252 437 423 265 437 minecraft:stone_bricks
fill 423 252 446 423 265 446 minecraft:stone_bricks
fill 423 252 447 423 252 448 minecraft:glowstone
fill 423 252 449 423 265 449 minecraft:stone_bricks
fill 423 252 458 423 265 458 minecraft:stone_bricks
fill 424 252 458 425 252 458 minecraft:glowstone
fill 426 252 458 426 265 458 minecraft:stone_bricks
fill 430 252 416 430 265 416 minecraft:stone_bricks
fill 431 252 416 432 252 416 minecraft:glowstone
fill 433 252 416 433 265 416 minecraft:stone_bricks
fill 435 252 458 435 265 458 minecraft:stone_bricks
fill 436 252 458 437 252 458 minecraft:glowstone
fill 438 252 458 438 265 458 minecraft:stone_bricks
fill 442 252 416 442 265 416 minecraft:stone_bricks
fill 443 252 416 444 252 416 minecraft:glowstone
fill 445 252 416 445 265 416 minecraft:stone_bricks
fill 447 252 458 447 265 458 minecraft:stone_bricks
fill 448 252 458 449 252 458 minecraft:glowstone
fill 450 252 458 450 265 458 minecraft:stone_bricks
fill 454 252 416 454 265 416 minecraft:stone_bricks
fill 455 252 416 456 252 416 minecraft:glowstone
fill 457 252 416 457 265 416 minecraft:stone_bricks
fill 459 252 458 459 265 458 minecraft:stone_bricks
fill 460 252 458 461 252 458 minecraft:glowstone
fill 462 252 458 462 265 458 minecraft:stone_bricks
fill 465 252 417 465 265 417 minecraft:stone_bricks
fill 465 252 418 465 252 419 minecraft:glowstone
fill 465 252 420 465 265 420 minecraft:stone_bricks
fill 465 252 429 465 265 429 minecraft:stone_bricks
fill 465 252 430 465 252 431 minecraft:glowstone
fill 465 252 432 465 265 432 minecraft:stone_bricks
fill 465 252 441 465 265 441 minecraft:stone_bricks
fill 465 252 442 465 252 443 minecraft:glowstone
fill 465 252 444 465 265 444 minecraft:stone_bricks
fill 465 252 453 465 265 453 minecraft:stone_bricks
fill 465 252 454 465 252 455 minecraft:glowstone
fill 465 252 456 465 265 456 minecraft:stone_bricks
fill 423 253 423 423 265 424 minecraft:stone_bricks
fill 423 253 435 423 265 436 minecraft:stone_bricks
fill 423 253 447 423 265 448 minecraft:stone_bricks
fill 424 253 458 425 265 458 minecraft:stone_bricks
fill 431 253 416 432 265 416 minecraft:stone_bricks
setblock 433 253 418 minecraft:glowstone
setblock 433 253 420 minecraft:glowstone
setblock 433 253 422 minecraft:glowstone
setblock 433 253 424 minecraft:glowstone
setblock 433 253 426 minecraft:glowstone
setblock 434 253 417 minecraft:glowstone
setblock 434 253 419 minecraft:glowstone
setblock 434 253 421 minecraft:glowstone
setblock 434 253 423 minecraft:glowstone
setblock 434 253 425 minecraft:glowstone
setblock 435 253 418 minecraft:glowstone
setblock 435 253 420 minecraft:glowstone
setblock 435 253 422 minecraft:glowstone
setblock 435 253 424 minecraft:glowstone
setblock 435 253 426 minecraft:glowstone
setblock 436 253 417 minecraft:glowstone
setblock 436 253 419 minecraft:glowstone
setblock 436 253 421 minecraft:glowstone
setblock 436 253 423 minecraft:glowstone
setblock 436 253 425 minecraft:glowstone
fill 436 253 458 437 265 458 minecraft:stone_bricks
setblock 437 253 418 minecraft:glowstone
setblock 437 253 420 minecraft:glowstone
setblock 437 253 422 minecraft:glowstone
setblock 437 253 424 minecraft:glowstone
setblock 437 253 426 minecraft:glowstone
setblock 438 253 417 minecraft:glowstone
setblock 438 253 419 minecraft:glowstone
setblock 438 253 421 minecraft:glowstone
setblock 438 253 423 minecraft:glowstone
setblock 438 253 425 minecraft:glowstone
setblock 439 253 418 minecraft:glowstone
setblock 439 253 420 minecraft:glowstone
setblock 439 253 422 minecraft:glowstone
setblock 439 253 424 minecraft:glowstone
setblock 439 253 426 minecraft:glowstone
setblock 440 253 417 minecraft:glowstone
setblock 440 253 419 minecraft:glowstone
setblock 440 253 421 minecraft:glowstone
setblock 440 253 423 minecraft:glowstone
setblock 440 253 425 minecraft:glowstone
setblock 441 253 418 minecraft:glowstone
setblock 441 253 420 minecraft:glowstone
setblock 441 253 422 minecraft:glowstone
setblock 441 253 424 minecraft:glowstone
setblock 441 253 426 minecraft:glowstone
setblock 442 253 417 minecraft:glowstone
setblock 442 253 419 minecraft:glowstone
setblock 442 253 421 minecraft:glowstone
setblock 442 253 423 minecraft:glowstone
setblock 442 253 425 minecraft:glowstone
fill 443 253 416 444 265 416 minecraft:stone_bricks
setblock 443 253 418 minecraft:glowstone
setblock 443 253 420 minecraft:glowstone
setblock 443 253 422 minecraft:glowstone
setblock 443 253 424 minecraft:glowstone
setblock 443 253 426 minecraft:glowstone
fill 448 253 458 449 265 458 minecraft:stone_bricks
fill 455 253 416 456 265 416 minecraft:stone_bricks
setblock 456 253 441 minecraft:glowstone
setblock 456 253 443 minecraft:glowstone
setblock 456 253 445 minecraft:glowstone
setblock 456 253 447 minecraft:glowstone
setblock 456 253 449 minecraft:glowstone
setblock 456 253 451 minecraft:glowstone
setblock 456 253 453 minecraft:glowstone
setblock 457 253 442 minecraft:glowstone
setblock 457 253 444 minecraft:glowstone
setblock 457 253 446 minecraft:glowstone
setblock 457 253 448 minecraft:glowstone
setblock 457 253 450 minecraft:glowstone
setblock 457 253 452 minecraft:glowstone
setblock 458 253 441 minecraft:glowstone
setblock 458 253 443 minecraft:glowstone
setblock 458 253 445 minecraft:glowstone
setblock 458 253 447 minecraft:glowstone
setblock 458 253 449 minecraft:glowstone
setblock 458 253 451 minecraft:glowstone
setblock 458 253 453 minecraft:glowstone
setblock 459 253 442 minecraft:glowstone
setblock 459 253 444 minecraft:glowstone
setblock 459 253 446 minecraft:glowstone
setblock 459 253 448 minecraft:glowstone
setblock 459 253 450 minecraft:glowstone
setblock 459 253 452 minecraft:glowstone
setblock 460 253 441 minecraft:glowstone
setblock 460 253 443 minecraft:glowstone
setblock 460 253 445 minecraft:glowstone
setblock 460 253 447 minecraft:glowstone
setblock 460 253 449 minecraft:glowstone
setblock 460 253 451 minecraft:glowstone
setblock 460 253 453 minecraft:glowstone
fill 460 253 458 461 265 458 minecraft:stone_bricks
setblock 461 253 442 minecraft:glowstone
setblock 461 253 444 minecraft:glowstone
setblock 461 253 446 minecraft:glowstone
setblock 461 253 448 minecraft:glowstone
setblock 461 253 450 minecraft:glowstone
setblock 461 253 452 minecraft:glowstone
setblock 462 253 441 minecraft:glowstone
setblock 462 253 443 minecraft:glowstone
setblock 462 253 445 minecraft:glowstone
setblock 462 253 447 minecraft:glowstone
setblock 462 253 449 minecraft:glowstone
setblock 462 253 451 minecraft:glowstone
setblock 462 253 453 minecraft:glowstone
setblock 463 253 442 minecraft:glowstone
setblock 463 253 444 minecraft:glowstone
setblock 463 253 446 minecraft:glowstone
setblock 463 253 448 minecraft:glowstone
setblock 463 253 450 minecraft:glowstone
setblock 463 253 452 minecraft:glowstone
setblock 464 253 441 minecraft:glowstone
setblock 464 253 443 minecraft:glowstone
setblock 464 253 445 minecraft:glowstone
setblock 464 253 447 minecraft:glowstone
setblock 464 253 449 minecraft:glowstone
setblock 464 253 451 minecraft:glowstone
setblock 464 253 453 minecraft:glowstone
fill 465 253 418 465 265 419 minecraft:stone_bricks
fill 465 253 430 465 265 431 minecraft:stone_bricks
fill 465 253 442 465 265 443 minecraft:stone_bricks
fill 465 253 454 465 265 455 minecraft:stone_bricks
fill 433 254 418 433 255 418 minecraft:iron_block
fill 433 254 420 433 255 420 minecraft:iron_block
fill 433 254 422 433 255 422 minecraft:iron_block
fill 433 254 424 433 255 424 minecraft:iron_block
fill 433 254 426 433 255 426 minecraft:iron_block
fill 434 254 417 434 255 417 minecraft:iron_block
fill 434 254 419 434 255 419 minecraft:iron_block
fill 434 254 421 434 255 421 minecraft:iron_block
fill 434 254 423 434 255 423 minecraft:iron_block
fill 434 254 425 434 255 425 minecraft:iron_block
fill 435 254 418 435 255 418 minecraft:iron_block
fill 435 254 420 435 255 420 minecraft:iron_block
fill 435 254 422 435 255 422 minecraft:iron_block
fill 435 254 424 435 255 424 minecraft:iron_block
fill 435 254 426 435 255 426 minecraft:iron_block
fill 436 254 417 436 255 417 minecraft:iron_block
fill 436 254 419 436 255 419 minecraft:iron_block
fill 436 254 421 436 255 421 minecraft:iron_block
fill 436 254 423 436 255 423 minecraft:iron_block
fill 436 254 425 436 255 425 minecraft:iron_block
fill 437 254 418 437 255 418 minecraft:iron_block
fill 437 254 420 437 255 420 minecraft:iron_block
fill 437 254 422 437 255 422 minecraft:iron_block
fill 437 254 424 437 255 424 minecraft:iron_block
fill 437 254 426 437 255 426 minecraft:iron_block
fill 438 254 417 438 255 417 minecraft:iron_block
fill 438 254 419 438 255 419 minecraft:iron_block
fill 438 254 421 438 255 421 minecraft:iron_block
fill 438 254 423 438 255 423 minecraft:iron_block
fill 438 254 425 438 255 425 minecraft:iron_block
fill 439 254 418 439 255 418 minecraft:iron_block
fill 439 254 420 439 255 420 minecraft:iron_block
fill 439 254 422 439 255 422 minecraft:iron_block
fill 439 254 424 439 255 424 minecraft:iron_block
fill 439 254 426 439 255 426 minecraft:iron_block
fill 440 254 417 440 255 417 minecraft:iron_block
fill 440 254 419 440 255 419 minecraft:iron_block
fill 440 254 421 440 255 421 minecraft:iron_block
fill 440 254 423 440 255 423 minecraft:iron_block
fill 440 254 425 440 255 425 minecraft:iron_block
fill 441 254 418 441 255 418 minecraft:iron_block
fill 441 254 420 441 255 420 minecraft:iron_block
fill 441 254 422 441 255 422 minecraft:iron_block
fill 441 254 424 441 255 424 minecraft:iron_block
fill 441 254 426 441 255 426 minecraft:iron_block
fill 442 254 417 442 255 417 minecraft:iron_block
fill 442 254 419 442 255 419 minecraft:iron_block
fill 442 254 421 442 255 421 minecraft:iron_block
fill 442 254 423 442 255 423 minecraft:iron_block
fill 442 254 425 442 255 425 minecraft:iron_block
fill 443 254 418 443 255 418 minecraft:iron_block
fill 443 254 420 443 255 420 minecraft:iron_block
fill 443 254 422 443 255 422 minecraft:iron_block
fill 443 254 424 443 255 424 minecraft:iron_block
fill 443 254 426 443 255 426 minecraft:iron_block
fill 456 254 441 456 255 441 minecraft:iron_block
fill 456 254 443 456 255 443 minecraft:iron_block
fill 456 254 445 456 255 445 minecraft:iron_block
fill 456 254 447 456 255 447 minecraft:iron_block
fill 456 254 449 456 255 449 minecraft:iron_block
fill 456 254 451 456 255 451 minecraft:iron_block
fill 456 254 453 456 255 453 minecraft:iron_block
fill 457 254 442 457 255 442 minecraft:iron_block
fill 457 254 444 457 255 444 minecraft:iron_block
fill 457 254 446 457 255 446 minecraft:iron_block
fill 457 254 448 457 255 448 minecraft:iron_block
fill 457 254 450 457 255 450 minecraft:iron_block
fill 457 254 452 457 255 452 minecraft:iron_block
fill 458 254 441 458 255 441 minecraft:iron_block
fill 458 254 443 458 255 443 minecraft:iron_block
fill 458 254 445 458 255 445 minecraft:iron_block
fill 458 254 447 458 255 447 minecraft:iron_block
fill 458 254 449 458 255 449 minecraft:iron_block
fill 458 254 451 458 255 451 minecraft:iron_block
fill 458 254 453 458 255 453 minecraft:iron_block
fill 459 254 442 459 255 442 minecraft:iron_block
fill 459 254 444 459 255 444 minecraft:iron_block
fill 459 254 446 459 255 446 minecraft:iron_block
fill 459 254 448 459 255 448 minecraft:iron_block
fill 459 254 450 459 255 450 minecraft:iron_block
fill 459 254 452 459 255 452 minecraft:iron_block
fill 460 254 441 460 255 441 minecraft:iron_block
fill 460 254 443 460 255 443 minecraft:iron_block
fill 460 254 445 460 255 445 minecraft:iron_block
fill 460 254 447 460 255 447 minecraft:iron_block
fill 460 254 449 460 255 449 minecraft:iron_block
fill 460 254 451 460 255 451 minecraft:iron_block
fill 460 254 453 460 255 453 minecraft:iron_block
fill 461 254 442 461 255 442 minecraft:iron_block
fill 461 254 444 461 255 444 minecraft:iron_block
fill 461 254 446 461 255 446 minecraft:iron_block
fill 461 254 448 461 255 448 minecraft:iron_block
fill 461 254 450 461 255 450 minecraft:iron_block
fill 461 254 452 461 255 452 minecraft:iron_block
fill 462 254 441 462 255 441 minecraft:iron_block
fill 462 254 443 462 255 443 minecraft:iron_block
fill 462 254 445 462 255 445 minecraft:iron_block
fill 462 254 447 462 255 447 minecraft:iron_block
fill 462 254 449 462 255 449 minecraft:iron_block
fill 462 254 451 462 255 451 minecraft:iron_block
fill 462 254 453 462 255 453 minecraft:iron_block
fill 463 254 442 463 255 442 minecraft:iron_block
fill 463 254 444 463 255 444 minecraft:iron_block
fill 463 254 446 463 255 446 minecraft:iron_block
fill 463 254 448 463 255 448 minecraft:iron_block
fill 463 254 450 463 255 450 minecraft:iron_block
fill 463 254 452 463 255 452 minecraft:iron_block
fill 464 254 441 464 255 441 minecraft:iron_block
fill 464 254 443 464 255 443 minecraft:iron_block
fill 464 254 445 464 255 445 minecraft:iron_block
fill 464 254 447 464 255 447 minecraft:iron_block
fill 464 254 449 464 273 449 minecraft:iron_block
fill 464 254 451 464 273 451 minecraft:iron_block
fill 464 254 453 464 255 453 minecraft:iron_block
setblock 433 256 418 minecraft:glowstone
setblock 433 256 420 minecraft:glowstone
setblock 433 256 422 minecraft:glowstone
setblock 433 256 424 minecraft:glowstone
setblock 433 256 426 minecraft:glowstone
setblock 434 256 417 minecraft:glowstone
setblock 434 256 419 minecraft:glowstone
setblock 434 256 421 minecraft:glowstone
setblock 434 256 423 minecraft:glowstone
setblock 434 256 425 minecraft:glowstone
setblock 435 256 418 minecraft:glowstone
setblock 435 256 420 minecraft:glowstone
setblock 435 256 422 minecraft:glowstone
setblock 435 256 424 minecraft:glowstone
setblock 435 256 426 minecraft:glowstone
setblock 436 256 417 minecraft:glowstone
setblock 436 256 419 minecraft:glowstone
setblock 436 256 421 minecraft:glowstone
setblock 436 256 423 minecraft:glowstone
setblock 436 256 425 minecraft:glowstone
setblock 437 256 418 minecraft:glowstone
setblock 437 256 420 minecraft:glowstone
setblock 437 256 422 minecraft:glowstone
setblock 437 256 424 minecraft:glowstone
setblock 437 256 426 minecraft:glowstone
setblock 438 256 417 minecraft:glowstone
setblock 438 256 419 minecraft:glowstone
setblock 438 256 421 minecraft:glowstone
setblock 438 256 423 minecraft:glowstone
setblock 438 256 425 minecraft:glowstone
setblock 439 256 418 minecraft:glowstone
setblock 439 256 420 minecraft:glowstone
setblock 439 256 422 minecraft:glowstone
setblock 439 256 424 minecraft:glowstone
setblock 439 256 426 minecraft:glowstone
setblock 440 256 417 minecraft:glowstone
setblock 440 256 419 minecraft:glowstone
setblock 440 256 421 minecraft:glowstone
setblock 440 256 423 minecraft:glowstone
setblock 440 256 425 minecraft:glowstone
setblock 441 256 418 minecraft:glowstone
setblock 441 256 420 minecraft:glowstone
setblock 441 256 422 minecraft:glowstone
setblock 441 256 424 minecraft:glowstone
setblock 441 256 426 minecraft:glowstone
setblock 442 256 417 minecraft:glowstone
setblock 442 256 419 minecraft:glowstone
setblock 442 256 421 minecraft:glowstone
setblock 442 256 423 minecraft:glowstone
setblock 442 256 425 minecraft:glowstone
setblock 443 256 418 minecraft:glowstone
setblock 443 256 420 minecraft:glowstone
setblock 443 256 422 minecraft:glowstone
setblock 443 256 424 minecraft:glowstone
setblock 443 256 426 minecraft:glowstone
fill 433 257 418 433 258 418 minecraft:iron_block
fill 433 257 420 433 258 420 minecraft:iron_block
fill 433 257 422 433 258 422 minecraft:iron_block
fill 433 257 424 433 258 424 minecraft:iron_block
fill 433 257 426 433 258 426 minecraft:iron_block
fill 434 257 417 434 258 417 minecraft:iron_block
fill 434 257 419 434 258 419 minecraft:iron_block
fill 434 257 421 434 258 421 minecraft:iron_block
fill 434 257 423 434 258 423 minecraft:iron_block
fill 434 257 425 434 258 425 minecraft:iron_block
fill 435 257 418 435 258 418 minecraft:iron_block
fill 435 257 420 435 258 420 minecraft:iron_block
fill 435 257 422 435 258 422 minecraft:iron_block
fill 435 257 424 435 258 424 minecraft:iron_block
fill 435 257 426 435 258 426 minecraft:iron_block
fill 436 257 417 436 258 417 minecraft:iron_block
fill 436 257 419 436 258 419 minecraft:iron_block
fill 436 257 421 436 258 421 minecraft:iron_block
fill 436 257 423 436 258 423 minecraft:iron_block
fill 436 257 425 436 258 425 minecraft:iron_block
fill 437 257 418 437 258 418 minecraft:iron_block
fill 437 257 420 437 258 420 minecraft:iron_block
fill 437 257 422 437 258 422 minecraft:iron_block
fill 437 257 424 437 258 424 minecraft:iron_block
fill 437 257 426 437 258 426 minecraft:iron_block
fill 438 257 417 438 258 417 minecraft:iron_block
fill 438 257 419 438 258 419 minecraft:iron_block
fill 438 257 421 438 258 421 minecraft:iron_block
fill 438 257 423 438 258 423 minecraft:iron_block
fill 438 257 425 438 258 425 minecraft:iron_block
fill 439 257 418 439 258 418 minecraft:iron_block
fill 439 257 420 439 258 420 minecraft:iron_block
fill 439 257 422 439 258 422 minecraft:iron_block
fill 439 257 424 439 258 424 minecraft:iron_block
fill 439 257 426 439 258 426 minecraft:iron_block
fill 440 257 417 440 258 417 minecraft:iron_block
fill 440 257 419 440 258 419 minecraft:iron_block
fill 440 257 421 440 258 421 minecraft:iron_block
fill 440 257 423 440 258 423 minecraft:iron_block
fill 440 257 425 440 258 425 minecraft:iron_block
fill 441 257 418 441 258 418 minecraft:iron_block
fill 441 257 420 441 258 420 minecraft:iron_block
fill 441 257 422 441 258 422 minecraft:iron_block
fill 441 257 424 441 258 424 minecraft:iron_block
fill 441 257 426 441 258 426 minecraft:iron_block
fill 442 257 417 442 258 417 minecraft:iron_block
fill 442 257 419 442 258 419 minecraft:iron_block
fill 442 257 421 442 258 421 minecraft:iron_block
fill 442 257 423 442 258 423 minecraft:iron_block
fill 442 257 425 442 258 425 minecraft:iron_block
fill 443 257 418 443 258 418 minecraft:iron_block
fill 443 257 420 443 258 420 minecraft:iron_block
fill 443 257 422 443 258 422 minecraft:iron_block
fill 443 257 424 443 258 424 minecraft:iron_block
fill 443 257 426 443 258 426 minecraft:iron_block
fill 424 258 417 426 273 417 minecraft:iron_block
fill 424 258 427 424 273 429 minecraft:iron_block
setblock 426 258 419 minecraft:light[level=12]
setblock 426 258 427 minecraft:light[level=12]
setblock 426 258 435 minecraft:light[level=12]
setblock 426 258 443 minecraft:light[level=12]
setblock 426 258 451 minecraft:light[level=12]
setblock 434 258 427 minecraft:light[level=12]
setblock 434 258 435 minecraft:light[level=12]
setblock 434 258 443 minecraft:light[level=12]
setblock 434 258 451 minecraft:light[level=12]
setblock 442 258 427 minecraft:light[level=12]
setblock 442 258 435 minecraft:light[level=12]
setblock 442 258 443 minecraft:light[level=12]
setblock 442 258 451 minecraft:light[level=12]
setblock 450 258 419 minecraft:light[level=12]
setblock 450 258 427 minecraft:light[level=12]
setblock 450 258 435 minecraft:light[level=12]
setblock 450 258 443 minecraft:light[level=12]
setblock 450 258 451 minecraft:light[level=12]
setblock 458 258 419 minecraft:light[level=12]
setblock 458 258 427 minecraft:light[level=12]
setblock 458 258 435 minecraft:light[level=12]
setblock 458 258 443 minecraft:light[level=12]
setblock 458 258 451 minecraft:light[level=12]
setblock 433 259 418 minecraft:glowstone
setblock 433 259 420 minecraft:glowstone
setblock 433 259 422 minecraft:glowstone
setblock 433 259 424 minecraft:glowstone
setblock 433 259 426 minecraft:glowstone
setblock 434 259 417 minecraft:glowstone
setblock 434 259 419 minecraft:glowstone
setblock 434 259 421 minecraft:glowstone
setblock 434 259 423 minecraft:glowstone
setblock 434 259 425 minecraft:glowstone
setblock 435 259 418 minecraft:glowstone
setblock 435 259 420 minecraft:glowstone
setblock 435 259 422 minecraft:glowstone
setblock 435 259 424 minecraft:glowstone
setblock 435 259 426 minecraft:glowstone
setblock 436 259 417 minecraft:glowstone
setblock 436 259 419 minecraft:glowstone
setblock 436 259 421 minecraft:glowstone
setblock 436 259 423 minecraft:glowstone
setblock 436 259 425 minecraft:glowstone
setblock 437 259 418 minecraft:glowstone
setblock 437 259 420 minecraft:glowstone
setblock 437 259 422 minecraft:glowstone
setblock 437 259 424 minecraft:glowstone
setblock 437 259 426 minecraft:glowstone
setblock 438 259 417 minecraft:glowstone
setblock 438 259 419 minecraft:glowstone
setblock 438 259 421 minecraft:glowstone
setblock 438 259 423 minecraft:glowstone
setblock 438 259 425 minecraft:glowstone
setblock 439 259 418 minecraft:glowstone
setblock 439 259 420 minecraft:glowstone
setblock 439 259 422 minecraft:glowstone
setblock 439 259 424 minecraft:glowstone
setblock 439 259 426 minecraft:glowstone
setblock 440 259 417 minecraft:glowstone
setblock 440 259 419 minecraft:glowstone
setblock 440 259 421 minecraft:glowstone
setblock 440 259 423 minecraft:glowstone
setblock 440 259 425 minecraft:glowstone
setblock 441 259 418 minecraft:glowstone
setblock 441 259 420 minecraft:glowstone
setblock 441 259 422 minecraft:glowstone
setblock 441 259 424 minecraft:glowstone
setblock 441 259 426 minecraft:glowstone
setblock 442 259 417 minecraft:glowstone
setblock 442 259 419 minecraft:glowstone
setblock 442 259 421 minecraft:glowstone
setblock 442 259 423 minecraft:glowstone
setblock 442 259 425 minecraft:glowstone
setblock 443 259 418 minecraft:glowstone
setblock 443 259 420 minecraft:glowstone
setblock 443 259 422 minecraft:glowstone
setblock 443 259 424 minecraft:glowstone
setblock 443 259 426 minecraft:glowstone
fill 425 260 426 425 265 428 minecraft:iron_block
fill 425 260 438 425 265 440 minecraft:iron_block
fill 425 260 450 425 265 452 minecraft:iron_block
fill 431 260 456 433 265 456 minecraft:iron_block
setblock 433 260 418 minecraft:iron_block
setblock 433 260 420 minecraft:iron_block
setblock 433 260 422 minecraft:iron_block
setblock 433 260 424 minecraft:iron_block
setblock 433 260 426 minecraft:iron_block
setblock 434 260 417 minecraft:iron_block
setblock 434 260 419 minecraft:iron_block
setblock 434 260 421 minecraft:iron_block
setblock 434 260 423 minecraft:iron_block
setblock 434 260 425 minecraft:iron_block
fill 435 260 418 435 265 418 minecraft:iron_block
setblock 435 260 420 minecraft:iron_block
setblock 435 260 422 minecraft:iron_block
setblock 435 260 424 minecraft:iron_block
setblock 435 260 426 minecraft:iron_block
fill 436 260 417 436 273 417 minecraft:iron_block
setblock 436 260 419 minecraft:iron_block
setblock 436 260 421 minecraft:iron_block
setblock 436 260 423 minecraft:iron_block
setblock 436 260 425 minecraft:iron_block
fill 437 260 418 437 265 418 minecraft:iron_block
setblock 437 260 420 minecraft:iron_block
setblock 437 260 422 minecraft:iron_block
setblock 437 260 424 minecraft:iron_block
setblock 437 260 426 minecraft:iron_block
fill 438 260 417 438 273 417 minecraft:iron_block
setblock 438 260 419 minecraft:iron_block
setblock 438 260 421 minecraft:iron_block
setblock 438 260 423 minecraft:iron_block
setblock 438 260 425 minecraft:iron_block
setblock 439 260 418 minecraft:iron_block
setblock 439 260 420 minecraft:iron_block
setblock 439 260 422 minecraft:iron_block
setblock 439 260 424 minecraft:iron_block
setblock 439 260 426 minecraft:iron_block
setblock 440 260 417 minecraft:iron_block
setblock 440 260 419 minecraft:iron_block
setblock 440 260 421 minecraft:iron_block
setblock 440 260 423 minecraft:iron_block
setblock 440 260 425 minecraft:iron_block
setblock 441 260 418 minecraft:iron_block
setblock 441 260 420 minecraft:iron_block
setblock 441 260 422 minecraft:iron_block
setblock 441 260 424 minecraft:iron_block
setblock 441 260 426 minecraft:iron_block
setblock 442 260 417 minecraft:iron_block
setblock 442 260 419 minecraft:iron_block
setblock 442 260 421 minecraft:iron_block
setblock 442 260 423 minecraft:iron_block
setblock 442 260 425 minecraft:iron_block
setblock 443 260 418 minecraft:iron_block
setblock 443 260 420 minecraft:iron_block
setblock 443 260 422 minecraft:iron_block
setblock 443 260 424 minecraft:iron_block
setblock 443 260 426 minecraft:iron_block
fill 443 260 456 445 265 456 minecraft:iron_block
fill 447 260 418 449 265 418 minecraft:iron_block
fill 455 260 456 457 265 456 minecraft:iron_block
fill 459 260 418 461 265 418 minecraft:iron_block
fill 463 260 426 463 265 428 minecraft:iron_block
fill 463 260 438 463 265 440 minecraft:iron_block
fill 463 260 450 463 265 452 minecraft:iron_block
fill 424 265 420 424 265 425 minecraft:cobblestone
fill 424 265 432 424 265 437 minecraft:cobblestone
fill 424 265 444 424 265 449 minecraft:cobblestone
fill 424 265 456 424 265 457 minecraft:cobblestone
fill 425 265 457 428 265 457 minecraft:cobblestone
fill 428 265 417 433 265 417 minecraft:cobblestone
fill 435 265 457 440 265 457 minecraft:cobblestone
fill 440 265 417 445 265 417 minecraft:cobblestone
fill 447 265 457 452 265 457 minecraft:cobblestone
fill 452 265 417 457 265 417 minecraft:cobblestone
fill 459 265 457 464 265 457 minecraft:cobblestone
fill 464 265 417 464 265 422 minecraft:cobblestone
fill 464 265 429 464 265 434 minecraft:cobblestone
fill 464 265 441 464 265 446 minecraft:cobblestone
fill 464 265 453 464 265 456 minecraft:cobblestone
fill 423 266 422 423 271 425 minecraft:glowstone
fill 423 266 434 423 271 437 minecraft:glowstone
fill 423 266 446 423 271 449 minecraft:glowstone
fill 423 266 458 426 271 458 minecraft:glowstone
setblock 426 266 419 minecraft:light[level=12]
setblock 426 266 427 minecraft:light[level=12]
setblock 426 266 435 minecraft:light[level=12]
setblock 426 266 443 minecraft:light[level=12]
setblock 426 266 451 minecraft:light[level=12]
fill 430 266 416 433 271 416 minecraft:glowstone
setblock 434 266 419 minecraft:light[level=12]
setblock 434 266 427 minecraft:light[level=12]
setblock 434 266 435 minecraft:light[level=12]
setblock 434 266 443 minecraft:light[level=12]
setblock 434 266 451 minecraft:light[level=12]
fill 435 266 458 438 271 458 minecraft:glowstone
fill 442 266 416 445 271 416 minecraft:glowstone
setblock 442 266 419 minecraft:light[level=12]
setblock 442 266 427 minecraft:light[level=12]
setblock 442 266 435 minecraft:light[level=12]
setblock 442 266 443 minecraft:light[level=12]
setblock 442 266 451 minecraft:light[level=12]
fill 447 266 458 450 271 458 minecraft:glowstone
setblock 450 266 419 minecraft:light[level=12]
setblock 450 266 427 minecraft:light[level=12]
setblock 450 266 435 minecraft:light[level=12]
setblock 450 266 443 minecraft:light[level=12]
setblock 450 266 451 minecraft:light[level=12]
fill 454 266 416 457 271 416 minecraft:glowstone
setblock 458 266 419 minecraft:light[level=12]
setblock 458 266 427 minecraft:light[level=12]
setblock 458 266 435 minecraft:light[level=12]
setblock 458 266 443 minecraft:light[level=12]
setblock 458 266 451 minecraft:light[level=12]
fill 459 266 458 462 271 458 minecraft:glowstone
fill 465 266 417 465 271 420 minecraft:glowstone
fill 465 266 429 465 271 432 minecraft:glowstone
fill 465 266 441 465 271 444 minecraft:glowstone
fill 465 266 453 465 271 456 minecraft:glowstone
fill 451 268 421 464 268 421 minecraft:iron_block
fill 455 268 436 463 268 436 minecraft:iron_block
fill 424 269 421 453 269 421 minecraft:iron_block
fill 424 269 426 463 269 426 minecraft:iron_block
fill 424 269 431 464 269 431 minecraft:iron_block
fill 424 269 436 457 269 436 minecraft:iron_block
fill 424 269 446 464 269 446 minecraft:iron_block
fill 424 269 456 429 270 456 minecraft:iron_block
fill 425 269 441 428 270 441 minecraft:iron_block
fill 425 269 451 426 270 451 minecraft:iron_block
setblock 424 270 421 minecraft:iron_block
fill 424 270 426 426 270 426 minecraft:iron_block
fill 424 270 431 426 270 431 minecraft:iron_block
fill 424 270 436 425 270 436 minecraft:iron_block
fill 424 270 446 426 270 446 minecraft:iron_block
fill 427 270 451 463 270 451 minecraft:iron_block
fill 429 270 441 443 270 441 minecraft:iron_block
fill 430 270 456 464 270 456 minecraft:iron_block
fill 449 270 441 464 270 441 minecraft:iron_block
fill 428 271 417 428 272 418 minecraft:iron_bars
fill 433 271 417 433 272 421 minecraft:iron_bars
fill 438 271 418 438 271 456 minecraft:iron_bars
fill 443 271 417 443 272 422 minecraft:iron_bars
fill 448 271 418 448 272 418 minecraft:iron_bars
fill 453 271 417 453 272 419 minecraft:iron_bars
fill 458 271 417 458 272 417 minecraft:iron_bars
fill 463 271 417 463 272 419 minecraft:iron_bars
fill 423 272 422 423 285 422 minecraft:stone_bricks
fill 423 272 423 423 272 424 minecraft:glowstone
fill 423 272 425 423 285 425 minecraft:stone_bricks
fill 423 272 434 423 285 434 minecraft:stone_bricks
fill 423 272 435 423 272 436 minecraft:glowstone
fill 423 272 437 423 285 437 minecraft:stone_bricks
fill 423 272 446 423 285 446 minecraft:stone_bricks
fill 423 272 447 423 272 448 minecraft:glowstone
fill 423 272 449 423 285 449 minecraft:stone_bricks
fill 423 272 458 423 285 458 minecraft:stone_bricks
fill 424 272 458 425 272 458 minecraft:glowstone
fill 426 272 458 426 285 458 minecraft:stone_bricks
fill 428 272 419 428 272 453 minecraft:iron_bars
fill 430 272 416 430 285 416 minecraft:stone_bricks
fill 431 272 416 432 272 416 minecraft:glowstone
fill 433 272 416 433 285 416 minecraft:stone_bricks
fill 433 272 422 433 272 457 minecraft:iron_bars
fill 435 272 458 435 285 458 minecraft:stone_bricks
fill 436 272 458 437 272 458 minecraft:glowstone
setblock 438 272 418 minecraft:iron_bars
fill 438 272 458 438 285 458 minecraft:stone_bricks
fill 442 272 416 442 285 416 minecraft:stone_bricks
fill 443 272 416 444 272 416 minecraft:glowstone
fill 443 272 423 443 272 456 minecraft:iron_bars
fill 445 272 416 445 285 416 minecraft:stone_bricks
fill 447 272 458 447 285 458 minecraft:stone_bricks
fill 448 272 419 448 272 436 minecraft:iron_bars
fill 448 272 442 448 272 448 minecraft:iron_bars
fill 448 272 458 449 272 458 minecraft:glowstone
fill 450 272 458 450 285 458 minecraft:stone_bricks
fill 453 272 420 453 272 457 minecraft:iron_bars
fill 454 272 416 454 285 416 minecraft:stone_bricks
fill 455 272 416 456 272 416 minecraft:glowstone
fill 457 272 416 457 285 416 minecraft:stone_bricks
fill 458 272 418 458 272 446 minecraft:iron_bars
fill 459 272 458 459 285 458 minecraft:stone_bricks
fill 460 272 458 461 272 458 minecraft:glowstone
fill 462 272 458 462 285 458 minecraft:stone_bricks
fill 463 272 420 463 272 457 minecraft:iron_bars
fill 465 272 417 465 285 417 minecraft:stone_bricks
fill 465 272 418 465 272 419 minecraft:glowstone
fill 465 272 420 465 285 420 minecraft:stone_bricks
fill 465 272 429 465 285 429 minecraft:stone_bricks
fill 465 272 430 465 272 431 minecraft:glowstone
fill 465 272 432 465 285 432 minecraft:stone_bricks
fill 465 272 441 465 285 441 minecraft:stone_bricks
fill 465 272 442 465 272 443 minecraft:glowstone
fill 465 272 444 465 285 444 minecraft:stone_bricks
fill 465 272 453 465 285 453 minecraft:stone_bricks
fill 465 272 454 465 272 455 minecraft:glowstone
fill 465 272 456 465 285 456 minecraft:stone_bricks
fill 423 273 423 423 285 424 minecraft:stone_bricks
fill 423 273 435 423 285 436 minecraft:stone_bricks
fill 423 273 447 423 285 448 minecraft:stone_bricks
fill 424 273 458 425 285 458 minecraft:stone_bricks
fill 428 273 451 428 273 456 minecraft:iron_bars
fill 431 273 416 432 285 416 minecraft:stone_bricks
fill 436 273 458 437 285 458 minecraft:stone_bricks
fill 443 273 416 444 285 416 minecraft:stone_bricks
fill 448 273 446 448 273 457 minecraft:iron_bars
fill 448 273 458 449 285 458 minecraft:stone_bricks
fill 455 273 416 456 285 416 minecraft:stone_bricks
fill 458 273 444 458 273 457 minecraft:iron_bars
fill 460 273 458 461 285 458 minecraft:stone_bricks
fill 465 273 418 465 285 419 minecraft:stone_bricks
fill 465 273 430 465 285 431 minecraft:stone_bricks
fill 465 273 442 465 285 443 minecraft:stone_bricks
fill 465 273 454 465 285 455 minecraft:stone_bricks
setblock 426 274 419 minecraft:light[level=12]
setblock 426 274 427 minecraft:light[level=12]
setblock 426 274 435 minecraft:light[level=12]
setblock 426 274 443 minecraft:light[level=12]
setblock 426 274 451 minecraft:light[level=12]
setblock 434 274 419 minecraft:light[level=12]
setblock 434 274 427 minecraft:light[level=12]
setblock 434 274 435 minecraft:light[level=12]
setblock 434 274 443 minecraft:light[level=12]
setblock 434 274 451 minecraft:light[level=12]
setblock 442 274 419 minecraft:light[level=12]
setblock 442 274 427 minecraft:light[level=12]
setblock 442 274 435 minecraft:light[level=12]
setblock 442 274 443 minecraft:light[level=12]
setblock 442 274 451 minecraft:light[level=12]
setblock 450 274 419 minecraft:light[level=12]
setblock 450 274 427 minecraft:light[level=12]
setblock 450 274 435 minecraft:light[level=12]
setblock 450 274 443 minecraft:light[level=12]
schedule function dropper:buildpart/105_3 1t
