fill 332 61 479 332 64 479 minecraft:pink_terracotta
setblock 332 61 483 minecraft:red_nether_bricks
fill 332 61 484 332 64 484 minecraft:pink_terracotta
setblock 332 61 503 minecraft:red_nether_bricks
fill 332 61 504 335 61 504 minecraft:pink_terracotta
setblock 333 61 466 minecraft:pink_terracotta
setblock 333 61 477 minecraft:red_nether_bricks
fill 333 61 478 333 63 478 minecraft:pink_terracotta
setblock 333 61 482 minecraft:red_nether_bricks
fill 333 61 483 333 63 483 minecraft:pink_terracotta
setblock 333 61 502 minecraft:red_nether_bricks
fill 333 61 503 336 61 503 minecraft:pink_terracotta
setblock 334 61 466 minecraft:red_nether_bricks
fill 334 61 502 337 61 502 minecraft:pink_terracotta
setblock 335 61 465 minecraft:red_nether_bricks
fill 335 61 466 335 64 466 minecraft:pink_terracotta
setblock 336 61 464 minecraft:red_nether_bricks
fill 336 61 465 336 64 465 minecraft:pink_terracotta
setblock 336 61 504 minecraft:red_nether_bricks
fill 337 61 464 337 64 464 minecraft:pink_terracotta
setblock 337 61 503 minecraft:red_nether_bricks
fill 337 61 504 337 64 504 minecraft:pink_terracotta
setblock 338 61 502 minecraft:red_nether_bricks
fill 338 61 503 338 64 503 minecraft:pink_terracotta
setblock 339 61 466 minecraft:red_nether_bricks
fill 339 61 502 339 62 502 minecraft:pink_terracotta
setblock 340 61 465 minecraft:red_nether_bricks
setblock 341 61 464 minecraft:red_nether_bricks
fill 341 61 465 341 64 465 minecraft:pink_terracotta
setblock 341 61 504 minecraft:red_nether_bricks
fill 342 61 464 342 64 464 minecraft:pink_terracotta
setblock 342 61 503 minecraft:red_nether_bricks
fill 342 61 504 345 61 504 minecraft:pink_terracotta
fill 343 61 503 346 61 503 minecraft:pink_terracotta
setblock 344 61 465 minecraft:pink_terracotta
setblock 346 61 464 minecraft:red_nether_bricks
setblock 346 61 504 minecraft:red_nether_bricks
fill 347 61 464 347 64 464 minecraft:pink_terracotta
setblock 347 61 503 minecraft:red_nether_bricks
fill 347 61 504 347 64 504 minecraft:pink_terracotta
fill 348 61 465 349 61 465 minecraft:pink_terracotta
setblock 348 61 502 minecraft:red_nether_bricks
fill 348 61 503 348 64 503 minecraft:pink_terracotta
fill 349 61 502 349 64 502 minecraft:pink_terracotta
setblock 350 61 465 minecraft:red_nether_bricks
setblock 351 61 464 minecraft:red_nether_bricks
fill 351 61 465 354 61 465 minecraft:pink_terracotta
fill 351 61 501 353 61 501 minecraft:pink_terracotta
setblock 351 61 504 minecraft:red_nether_bricks
fill 352 61 464 352 64 464 minecraft:pink_terracotta
setblock 352 61 503 minecraft:red_nether_bricks
fill 352 61 504 352 64 504 minecraft:pink_terracotta
setblock 353 61 502 minecraft:red_nether_bricks
fill 353 61 503 353 64 503 minecraft:pink_terracotta
setblock 354 61 500 minecraft:pink_terracotta
setblock 354 61 501 minecraft:red_nether_bricks
fill 354 61 502 354 64 502 minecraft:pink_terracotta
setblock 355 61 465 minecraft:red_nether_bricks
setblock 355 61 500 minecraft:red_nether_bricks
fill 355 61 501 355 64 501 minecraft:pink_terracotta
setblock 356 61 464 minecraft:red_nether_bricks
fill 356 61 465 356 64 465 minecraft:pink_terracotta
setblock 356 61 500 minecraft:pink_terracotta
setblock 356 61 504 minecraft:red_nether_bricks
fill 357 61 464 357 64 464 minecraft:pink_terracotta
setblock 357 61 503 minecraft:red_nether_bricks
fill 357 61 504 357 64 504 minecraft:pink_terracotta
setblock 358 61 502 minecraft:red_nether_bricks
fill 358 61 503 358 64 503 minecraft:pink_terracotta
setblock 359 61 501 minecraft:red_nether_bricks
fill 359 61 502 359 63 502 minecraft:pink_terracotta
setblock 360 61 501 minecraft:pink_terracotta
setblock 361 61 464 minecraft:red_nether_bricks
setblock 361 61 504 minecraft:red_nether_bricks
setblock 362 61 503 minecraft:red_nether_bricks
fill 362 61 504 362 64 504 minecraft:pink_terracotta
fill 363 61 503 363 62 503 minecraft:pink_terracotta
fill 366 61 503 366 66 503 minecraft:white_concrete
setblock 366 61 504 minecraft:red_nether_bricks
fill 367 61 504 367 64 504 minecraft:pink_terracotta
setblock 368 61 481 minecraft:pink_terracotta
setblock 368 61 482 minecraft:red_nether_bricks
fill 368 61 483 368 64 483 minecraft:pink_terracotta
fill 369 61 477 369 61 480 minecraft:pink_terracotta
setblock 369 61 481 minecraft:red_nether_bricks
fill 369 61 482 369 64 482 minecraft:pink_terracotta
setblock 369 61 486 minecraft:red_nether_bricks
fill 369 61 487 369 63 488 minecraft:pink_terracotta
setblock 369 61 501 minecraft:red_nether_bricks
fill 369 61 502 369 62 503 minecraft:pink_terracotta
setblock 370 61 464 minecraft:pink_terracotta
setblock 370 61 468 minecraft:white_concrete
fill 370 61 473 370 61 474 minecraft:pink_terracotta
setblock 370 61 475 minecraft:red_nether_bricks
fill 370 61 476 370 64 476 minecraft:pink_terracotta
setblock 370 61 480 minecraft:red_nether_bricks
fill 370 61 481 370 64 481 minecraft:pink_terracotta
setblock 370 61 485 minecraft:red_nether_bricks
fill 370 61 486 370 64 486 minecraft:pink_terracotta
setblock 370 61 489 minecraft:pink_terracotta
setblock 370 61 490 minecraft:red_nether_bricks
fill 370 61 491 370 64 491 minecraft:pink_terracotta
setblock 370 61 495 minecraft:red_nether_bricks
fill 370 61 496 370 63 496 minecraft:pink_terracotta
setblock 370 61 500 minecraft:red_nether_bricks
fill 370 61 501 370 64 501 minecraft:pink_terracotta
setblock 330 62 464 minecraft:red_nether_bricks
fill 330 62 465 333 62 465 minecraft:pink_terracotta
fill 330 62 467 330 62 468 minecraft:pink_terracotta
setblock 330 62 469 minecraft:red_nether_bricks
fill 330 62 470 330 65 470 minecraft:pink_terracotta
setblock 330 62 474 minecraft:red_nether_bricks
fill 330 62 475 330 65 475 minecraft:pink_terracotta
setblock 330 62 479 minecraft:red_nether_bricks
fill 330 62 480 330 65 480 minecraft:pink_terracotta
setblock 330 62 484 minecraft:red_nether_bricks
fill 330 62 485 330 65 485 minecraft:pink_terracotta
setblock 330 62 489 minecraft:red_nether_bricks
fill 330 62 490 330 65 490 minecraft:pink_terracotta
setblock 330 62 499 minecraft:red_nether_bricks
fill 330 62 500 330 64 500 minecraft:pink_terracotta
setblock 330 62 503 minecraft:pink_terracotta
setblock 330 62 504 minecraft:red_nether_bricks
fill 331 62 464 334 62 464 minecraft:pink_terracotta
setblock 331 62 467 minecraft:pink_terracotta
setblock 331 62 468 minecraft:red_nether_bricks
fill 331 62 469 331 65 469 minecraft:pink_terracotta
setblock 331 62 473 minecraft:red_nether_bricks
fill 331 62 474 331 65 474 minecraft:pink_terracotta
setblock 331 62 478 minecraft:red_nether_bricks
fill 331 62 479 331 65 479 minecraft:pink_terracotta
setblock 331 62 483 minecraft:red_nether_bricks
fill 331 62 484 331 65 484 minecraft:pink_terracotta
setblock 331 62 488 minecraft:red_nether_bricks
setblock 331 62 503 minecraft:red_nether_bricks
fill 331 62 504 334 62 504 minecraft:pink_terracotta
setblock 332 62 466 minecraft:pink_terracotta
setblock 332 62 477 minecraft:red_nether_bricks
fill 332 62 478 332 65 478 minecraft:pink_terracotta
setblock 332 62 482 minecraft:red_nether_bricks
fill 332 62 483 332 65 483 minecraft:pink_terracotta
setblock 332 62 486 minecraft:pink_terracotta
fill 332 62 503 335 62 503 minecraft:pink_terracotta
setblock 333 62 466 minecraft:red_nether_bricks
setblock 333 62 477 minecraft:pink_terracotta
setblock 333 62 481 minecraft:red_nether_bricks
fill 333 62 482 333 64 482 minecraft:pink_terracotta
setblock 333 62 484 minecraft:pink_terracotta
fill 333 62 502 336 62 502 minecraft:pink_terracotta
setblock 334 62 465 minecraft:red_nether_bricks
fill 334 62 466 334 65 466 minecraft:pink_terracotta
setblock 335 62 464 minecraft:red_nether_bricks
fill 335 62 465 335 65 465 minecraft:pink_terracotta
setblock 335 62 504 minecraft:red_nether_bricks
fill 336 62 464 336 65 464 minecraft:pink_terracotta
setblock 336 62 503 minecraft:red_nether_bricks
fill 336 62 504 336 65 504 minecraft:pink_terracotta
setblock 337 62 466 minecraft:pink_terracotta
setblock 337 62 502 minecraft:red_nether_bricks
fill 337 62 503 337 65 503 minecraft:pink_terracotta
setblock 338 62 466 minecraft:red_nether_bricks
setblock 338 62 502 minecraft:pink_terracotta
setblock 339 62 465 minecraft:red_nether_bricks
setblock 339 62 466 minecraft:pink_terracotta
setblock 340 62 464 minecraft:red_nether_bricks
fill 340 62 465 340 65 465 minecraft:pink_terracotta
setblock 340 62 504 minecraft:red_nether_bricks
fill 341 62 464 341 65 464 minecraft:pink_terracotta
setblock 341 62 503 minecraft:red_nether_bricks
fill 341 62 504 344 62 504 minecraft:pink_terracotta
fill 342 62 503 345 62 503 minecraft:pink_terracotta
setblock 344 62 465 minecraft:red_nether_bricks
setblock 345 62 464 minecraft:red_nether_bricks
fill 345 62 465 348 62 465 minecraft:pink_terracotta
setblock 345 62 504 minecraft:red_nether_bricks
fill 346 62 464 346 65 464 minecraft:pink_terracotta
setblock 346 62 503 minecraft:red_nether_bricks
fill 346 62 504 346 65 504 minecraft:pink_terracotta
fill 347 62 503 347 65 503 minecraft:pink_terracotta
fill 348 62 502 348 64 502 minecraft:pink_terracotta
setblock 349 62 465 minecraft:red_nether_bricks
setblock 350 62 464 minecraft:red_nether_bricks
fill 350 62 465 353 62 465 minecraft:pink_terracotta
setblock 350 62 504 minecraft:red_nether_bricks
fill 351 62 464 351 65 464 minecraft:pink_terracotta
fill 351 62 501 352 62 501 minecraft:pink_terracotta
setblock 351 62 503 minecraft:red_nether_bricks
fill 351 62 504 351 65 504 minecraft:pink_terracotta
setblock 352 62 502 minecraft:red_nether_bricks
fill 352 62 503 352 65 503 minecraft:pink_terracotta
setblock 353 62 501 minecraft:red_nether_bricks
fill 353 62 502 353 65 502 minecraft:pink_terracotta
setblock 354 62 465 minecraft:red_nether_bricks
fill 354 62 501 354 64 501 minecraft:pink_terracotta
setblock 355 62 464 minecraft:red_nether_bricks
fill 355 62 465 355 65 465 minecraft:pink_terracotta
setblock 355 62 504 minecraft:red_nether_bricks
fill 356 62 464 356 65 464 minecraft:pink_terracotta
setblock 356 62 503 minecraft:red_nether_bricks
fill 356 62 504 356 65 504 minecraft:pink_terracotta
setblock 357 62 502 minecraft:red_nether_bricks
fill 357 62 503 357 65 503 minecraft:pink_terracotta
setblock 358 62 501 minecraft:red_nether_bricks
fill 358 62 502 358 64 502 minecraft:pink_terracotta
setblock 359 62 501 minecraft:pink_terracotta
setblock 360 62 464 minecraft:red_nether_bricks
setblock 360 62 504 minecraft:red_nether_bricks
fill 361 62 464 361 63 464 minecraft:pink_terracotta
setblock 361 62 503 minecraft:red_nether_bricks
fill 361 62 504 361 65 504 minecraft:pink_terracotta
fill 362 62 503 362 63 503 minecraft:pink_terracotta
fill 365 62 502 365 65 503 minecraft:white_concrete
setblock 365 62 504 minecraft:red_nether_bricks
fill 366 62 501 366 65 502 minecraft:white_concrete
fill 366 62 504 366 64 504 minecraft:pink_terracotta
fill 367 62 502 367 65 503 minecraft:white_concrete
setblock 368 62 464 minecraft:white_concrete
setblock 368 62 480 minecraft:pink_terracotta
setblock 368 62 481 minecraft:red_nether_bricks
fill 368 62 482 368 65 482 minecraft:pink_terracotta
fill 368 62 484 368 62 485 minecraft:pink_terracotta
fill 368 62 503 368 65 503 minecraft:white_concrete
fill 369 62 477 369 62 479 minecraft:pink_terracotta
setblock 369 62 480 minecraft:red_nether_bricks
fill 369 62 481 369 65 481 minecraft:pink_terracotta
setblock 369 62 484 minecraft:pink_terracotta
setblock 369 62 485 minecraft:red_nether_bricks
fill 369 62 486 369 65 486 minecraft:pink_terracotta
setblock 369 62 489 minecraft:pink_terracotta
setblock 369 62 501 minecraft:pink_terracotta
setblock 370 62 464 minecraft:red_nether_bricks
fill 370 62 465 370 65 465 minecraft:pink_terracotta
setblock 370 62 473 minecraft:pink_terracotta
setblock 370 62 474 minecraft:red_nether_bricks
fill 370 62 475 370 65 475 minecraft:pink_terracotta
setblock 370 62 479 minecraft:red_nether_bricks
fill 370 62 480 370 65 480 minecraft:pink_terracotta
setblock 370 62 484 minecraft:red_nether_bricks
fill 370 62 485 370 65 485 minecraft:pink_terracotta
setblock 370 62 489 minecraft:red_nether_bricks
fill 370 62 490 370 65 490 minecraft:pink_terracotta
setblock 370 62 494 minecraft:red_nether_bricks
fill 370 62 495 370 63 495 minecraft:pink_terracotta
setblock 370 62 499 minecraft:red_nether_bricks
fill 370 62 500 370 65 500 minecraft:pink_terracotta
setblock 370 62 504 minecraft:red_nether_bricks
fill 330 63 464 332 63 465 minecraft:pink_terracotta
setblock 330 63 467 minecraft:pink_terracotta
setblock 330 63 468 minecraft:red_nether_bricks
fill 330 63 469 330 66 469 minecraft:pink_terracotta
setblock 330 63 473 minecraft:red_nether_bricks
fill 330 63 474 330 66 474 minecraft:pink_terracotta
setblock 330 63 478 minecraft:red_nether_bricks
fill 330 63 479 330 66 479 minecraft:pink_terracotta
setblock 330 63 483 minecraft:red_nether_bricks
fill 330 63 484 330 66 484 minecraft:pink_terracotta
setblock 330 63 487 minecraft:pink_terracotta
setblock 330 63 488 minecraft:red_nether_bricks
fill 330 63 489 330 66 489 minecraft:pink_terracotta
setblock 330 63 499 minecraft:pink_terracotta
setblock 330 63 502 minecraft:pink_terracotta
setblock 330 63 503 minecraft:red_nether_bricks
fill 330 63 504 333 63 504 minecraft:pink_terracotta
setblock 331 63 467 minecraft:red_nether_bricks
fill 331 63 468 331 66 468 minecraft:pink_terracotta
setblock 331 63 472 minecraft:red_nether_bricks
fill 331 63 473 331 66 473 minecraft:pink_terracotta
setblock 331 63 477 minecraft:red_nether_bricks
fill 331 63 478 331 66 478 minecraft:pink_terracotta
setblock 331 63 482 minecraft:red_nether_bricks
fill 331 63 483 331 66 483 minecraft:pink_terracotta
setblock 331 63 487 minecraft:red_nether_bricks
fill 331 63 488 331 66 488 minecraft:pink_terracotta
setblock 331 63 502 minecraft:red_nether_bricks
fill 331 63 503 334 63 503 minecraft:pink_terracotta
setblock 332 63 466 minecraft:red_nether_bricks
fill 332 63 467 332 66 467 minecraft:pink_terracotta
setblock 332 63 476 minecraft:red_nether_bricks
fill 332 63 477 332 64 477 minecraft:pink_terracotta
setblock 332 63 481 minecraft:red_nether_bricks
fill 332 63 482 332 66 482 minecraft:pink_terracotta
setblock 332 63 486 minecraft:red_nether_bricks
setblock 333 63 464 minecraft:pink_terracotta
setblock 333 63 465 minecraft:red_nether_bricks
fill 333 63 466 333 66 466 minecraft:pink_terracotta
setblock 333 63 480 minecraft:red_nether_bricks
fill 333 63 481 333 64 481 minecraft:pink_terracotta
setblock 334 63 464 minecraft:red_nether_bricks
fill 334 63 465 334 66 465 minecraft:pink_terracotta
fill 334 63 502 335 63 502 minecraft:pink_terracotta
setblock 334 63 504 minecraft:red_nether_bricks
fill 335 63 464 335 66 464 minecraft:pink_terracotta
setblock 335 63 503 minecraft:red_nether_bricks
fill 335 63 504 335 66 504 minecraft:pink_terracotta
setblock 336 63 502 minecraft:red_nether_bricks
fill 336 63 503 336 66 503 minecraft:pink_terracotta
setblock 337 63 466 minecraft:red_nether_bricks
setblock 337 63 502 minecraft:pink_terracotta
setblock 338 63 465 minecraft:red_nether_bricks
fill 338 63 466 338 64 466 minecraft:pink_terracotta
setblock 339 63 464 minecraft:red_nether_bricks
fill 339 63 465 339 66 465 minecraft:pink_terracotta
setblock 339 63 504 minecraft:red_nether_bricks
fill 340 63 464 340 66 464 minecraft:pink_terracotta
setblock 340 63 503 minecraft:red_nether_bricks
fill 340 63 504 343 63 504 minecraft:pink_terracotta
fill 341 63 503 344 63 503 minecraft:pink_terracotta
setblock 343 63 465 minecraft:red_nether_bricks
setblock 344 63 464 minecraft:red_nether_bricks
fill 344 63 465 347 63 465 minecraft:pink_terracotta
setblock 344 63 504 minecraft:red_nether_bricks
fill 345 63 464 345 66 464 minecraft:pink_terracotta
setblock 345 63 503 minecraft:red_nether_bricks
fill 345 63 504 345 66 504 minecraft:pink_terracotta
fill 346 63 503 346 66 503 minecraft:pink_terracotta
setblock 348 63 465 minecraft:red_nether_bricks
setblock 349 63 464 minecraft:red_nether_bricks
fill 349 63 465 352 63 465 minecraft:pink_terracotta
setblock 349 63 504 minecraft:red_nether_bricks
fill 350 63 464 350 66 464 minecraft:pink_terracotta
setblock 350 63 503 minecraft:red_nether_bricks
fill 350 63 504 350 66 504 minecraft:pink_terracotta
setblock 351 63 501 minecraft:pink_terracotta
setblock 351 63 502 minecraft:red_nether_bricks
fill 351 63 503 351 66 503 minecraft:pink_terracotta
setblock 352 63 501 minecraft:red_nether_bricks
fill 352 63 502 352 66 502 minecraft:pink_terracotta
setblock 353 63 465 minecraft:red_nether_bricks
fill 353 63 501 353 64 501 minecraft:pink_terracotta
setblock 354 63 464 minecraft:red_nether_bricks
fill 354 63 465 354 66 465 minecraft:pink_terracotta
setblock 354 63 504 minecraft:red_nether_bricks
fill 355 63 464 355 66 464 minecraft:pink_terracotta
setblock 355 63 503 minecraft:red_nether_bricks
fill 355 63 504 355 66 504 minecraft:pink_terracotta
setblock 356 63 502 minecraft:red_nether_bricks
fill 356 63 503 356 66 503 minecraft:pink_terracotta
setblock 357 63 501 minecraft:red_nether_bricks
fill 357 63 502 357 65 502 minecraft:pink_terracotta
setblock 359 63 464 minecraft:red_nether_bricks
setblock 359 63 504 minecraft:red_nether_bricks
fill 360 63 464 360 64 464 minecraft:pink_terracotta
setblock 360 63 503 minecraft:red_nether_bricks
fill 360 63 504 360 66 504 minecraft:pink_terracotta
fill 361 63 503 361 64 503 minecraft:pink_terracotta
setblock 362 63 464 minecraft:white_concrete
fill 364 63 502 364 64 503 minecraft:white_concrete
setblock 364 63 504 minecraft:red_nether_bricks
fill 365 63 501 365 64 501 minecraft:white_concrete
fill 365 63 504 365 64 504 minecraft:pink_terracotta
fill 367 63 501 367 64 501 minecraft:white_concrete
fill 368 63 481 368 64 481 minecraft:pink_terracotta
setblock 368 63 484 minecraft:pink_terracotta
setblock 368 63 485 minecraft:red_nether_bricks
fill 368 63 502 368 64 502 minecraft:white_concrete
setblock 369 63 464 minecraft:red_nether_bricks
fill 369 63 477 369 63 478 minecraft:pink_terracotta
setblock 369 63 479 minecraft:red_nether_bricks
fill 369 63 480 369 66 480 minecraft:pink_terracotta
setblock 369 63 484 minecraft:red_nether_bricks
fill 369 63 485 369 66 485 minecraft:pink_terracotta
setblock 369 63 489 minecraft:red_nether_bricks
setblock 369 63 504 minecraft:red_nether_bricks
fill 370 63 464 370 66 464 minecraft:pink_terracotta
fill 370 63 466 370 64 466 minecraft:pink_terracotta
setblock 370 63 473 minecraft:red_nether_bricks
fill 370 63 474 370 66 474 minecraft:pink_terracotta
setblock 370 63 478 minecraft:red_nether_bricks
fill 370 63 479 370 66 479 minecraft:pink_terracotta
setblock 370 63 483 minecraft:red_nether_bricks
fill 370 63 484 370 66 484 minecraft:pink_terracotta
setblock 370 63 488 minecraft:red_nether_bricks
fill 370 63 489 370 66 489 minecraft:pink_terracotta
setblock 370 63 493 minecraft:red_nether_bricks
fill 370 63 494 370 64 494 minecraft:pink_terracotta
setblock 370 63 498 minecraft:red_nether_bricks
fill 370 63 499 370 64 499 minecraft:pink_terracotta
setblock 370 63 503 minecraft:red_nether_bricks
fill 370 63 504 370 66 504 minecraft:pink_terracotta
fill 330 64 464 330 64 466 minecraft:pink_terracotta
setblock 330 64 467 minecraft:red_nether_bricks
fill 330 64 468 330 67 468 minecraft:pink_terracotta
setblock 330 64 472 minecraft:red_nether_bricks
fill 330 64 473 330 67 473 minecraft:pink_terracotta
setblock 330 64 477 minecraft:red_nether_bricks
fill 330 64 478 330 67 478 minecraft:pink_terracotta
setblock 330 64 482 minecraft:red_nether_bricks
fill 330 64 483 330 67 483 minecraft:pink_terracotta
setblock 330 64 487 minecraft:red_nether_bricks
fill 330 64 488 330 67 488 minecraft:pink_terracotta
setblock 330 64 493 minecraft:white_concrete
setblock 330 64 502 minecraft:red_nether_bricks
fill 330 64 503 332 64 504 minecraft:pink_terracotta
fill 331 64 464 331 64 465 minecraft:pink_terracotta
setblock 331 64 466 minecraft:red_nether_bricks
fill 331 64 467 331 67 467 minecraft:pink_terracotta
setblock 331 64 471 minecraft:red_nether_bricks
fill 331 64 472 331 67 472 minecraft:pink_terracotta
setblock 331 64 476 minecraft:red_nether_bricks
fill 331 64 477 331 67 477 minecraft:pink_terracotta
setblock 331 64 481 minecraft:red_nether_bricks
fill 331 64 482 331 67 482 minecraft:pink_terracotta
setblock 331 64 486 minecraft:red_nether_bricks
fill 331 64 487 331 67 487 minecraft:pink_terracotta
setblock 331 64 502 minecraft:pink_terracotta
setblock 332 64 464 minecraft:pink_terracotta
setblock 332 64 465 minecraft:red_nether_bricks
fill 332 64 466 332 67 466 minecraft:pink_terracotta
fill 332 64 468 332 65 468 minecraft:pink_terracotta
setblock 332 64 476 minecraft:pink_terracotta
setblock 332 64 480 minecraft:red_nether_bricks
fill 332 64 481 332 66 481 minecraft:pink_terracotta
setblock 332 64 485 minecraft:red_nether_bricks
fill 332 64 486 332 65 486 minecraft:pink_terracotta
setblock 333 64 464 minecraft:red_nether_bricks
fill 333 64 465 333 67 465 minecraft:pink_terracotta
setblock 333 64 503 minecraft:pink_terracotta
setblock 333 64 504 minecraft:red_nether_bricks
fill 334 64 464 334 67 464 minecraft:pink_terracotta
setblock 334 64 503 minecraft:red_nether_bricks
fill 334 64 504 334 67 504 minecraft:pink_terracotta
fill 335 64 503 335 67 503 minecraft:pink_terracotta
setblock 336 64 466 minecraft:red_nether_bricks
setblock 337 64 465 minecraft:red_nether_bricks
fill 337 64 466 337 66 466 minecraft:pink_terracotta
setblock 338 64 464 minecraft:red_nether_bricks
fill 338 64 465 338 67 465 minecraft:pink_terracotta
setblock 338 64 504 minecraft:red_nether_bricks
fill 339 64 464 339 67 464 minecraft:pink_terracotta
setblock 339 64 503 minecraft:red_nether_bricks
fill 339 64 504 342 64 504 minecraft:pink_terracotta
fill 340 64 503 343 64 503 minecraft:pink_terracotta
setblock 342 64 465 minecraft:red_nether_bricks
setblock 343 64 464 minecraft:red_nether_bricks
setblock 343 64 465 minecraft:pink_terracotta
setblock 343 64 504 minecraft:red_nether_bricks
fill 344 64 464 344 67 464 minecraft:pink_terracotta
setblock 344 64 503 minecraft:red_nether_bricks
fill 344 64 504 344 67 504 minecraft:pink_terracotta
fill 345 64 503 345 65 503 minecraft:pink_terracotta
setblock 346 64 465 minecraft:pink_terracotta
setblock 347 64 465 minecraft:red_nether_bricks
setblock 348 64 464 minecraft:red_nether_bricks
fill 348 64 465 351 64 465 minecraft:pink_terracotta
setblock 348 64 504 minecraft:red_nether_bricks
fill 349 64 464 349 67 464 minecraft:pink_terracotta
setblock 349 64 503 minecraft:red_nether_bricks
fill 349 64 504 349 67 504 minecraft:pink_terracotta
setblock 350 64 502 minecraft:red_nether_bricks
fill 350 64 503 350 67 503 minecraft:pink_terracotta
fill 351 64 502 351 67 502 minecraft:pink_terracotta
setblock 352 64 465 minecraft:red_nether_bricks
setblock 352 64 501 minecraft:pink_terracotta
setblock 353 64 464 minecraft:red_nether_bricks
fill 353 64 465 353 67 465 minecraft:pink_terracotta
setblock 353 64 504 minecraft:red_nether_bricks
fill 354 64 464 354 67 464 minecraft:pink_terracotta
setblock 354 64 503 minecraft:red_nether_bricks
fill 354 64 504 354 67 504 minecraft:pink_terracotta
setblock 355 64 502 minecraft:red_nether_bricks
fill 355 64 503 355 67 503 minecraft:pink_terracotta
fill 356 64 502 356 65 502 minecraft:pink_terracotta
setblock 357 64 465 minecraft:red_nether_bricks
setblock 358 64 464 minecraft:red_nether_bricks
setblock 358 64 504 minecraft:red_nether_bricks
fill 359 64 464 359 65 464 minecraft:pink_terracotta
setblock 359 64 503 minecraft:red_nether_bricks
fill 359 64 504 359 67 504 minecraft:pink_terracotta
setblock 360 64 503 minecraft:pink_terracotta
setblock 363 64 504 minecraft:red_nether_bricks
setblock 364 64 504 minecraft:pink_terracotta
setblock 366 64 500 minecraft:black_concrete
setblock 368 64 484 minecraft:red_nether_bricks
fill 368 64 485 368 66 486 minecraft:pink_terracotta
setblock 368 64 504 minecraft:red_nether_bricks
fill 369 64 464 369 67 464 minecraft:pink_terracotta
setblock 369 64 477 minecraft:pink_terracotta
setblock 369 64 478 minecraft:red_nether_bricks
fill 369 64 479 369 67 479 minecraft:pink_terracotta
setblock 369 64 483 minecraft:red_nether_bricks
fill 369 64 484 369 67 484 minecraft:pink_terracotta
setblock 369 64 487 minecraft:pink_terracotta
setblock 369 64 488 minecraft:red_nether_bricks
fill 369 64 489 369 67 489 minecraft:pink_terracotta
fill 369 64 504 369 67 504 minecraft:pink_terracotta
setblock 370 64 467 minecraft:red_nether_bricks
fill 370 64 468 370 67 468 minecraft:pink_terracotta
fill 370 64 473 370 67 473 minecraft:pink_terracotta
setblock 370 64 477 minecraft:red_nether_bricks
fill 370 64 478 370 67 478 minecraft:pink_terracotta
setblock 370 64 482 minecraft:red_nether_bricks
fill 370 64 483 370 67 483 minecraft:pink_terracotta
setblock 370 64 487 minecraft:red_nether_bricks
fill 370 64 488 370 67 488 minecraft:pink_terracotta
setblock 370 64 492 minecraft:red_nether_bricks
fill 370 64 493 370 67 493 minecraft:pink_terracotta
setblock 370 64 497 minecraft:red_nether_bricks
setblock 370 64 498 minecraft:pink_terracotta
setblock 370 64 502 minecraft:red_nether_bricks
fill 370 64 503 370 67 503 minecraft:pink_terracotta
fill 330 65 464 330 65 465 minecraft:pink_terracotta
setblock 330 65 466 minecraft:red_nether_bricks
fill 330 65 467 330 68 467 minecraft:pink_terracotta
setblock 330 65 471 minecraft:red_nether_bricks
fill 330 65 472 330 68 472 minecraft:pink_terracotta
setblock 330 65 476 minecraft:red_nether_bricks
fill 330 65 477 330 68 477 minecraft:pink_terracotta
setblock 330 65 481 minecraft:red_nether_bricks
fill 330 65 482 330 68 482 minecraft:pink_terracotta
setblock 330 65 486 minecraft:red_nether_bricks
fill 330 65 487 330 68 487 minecraft:pink_terracotta
setblock 330 65 499 minecraft:white_concrete
setblock 330 65 501 minecraft:red_nether_bricks
fill 330 65 502 330 66 504 minecraft:pink_terracotta
setblock 331 65 464 minecraft:pink_terracotta
setblock 331 65 465 minecraft:red_nether_bricks
fill 331 65 466 331 68 466 minecraft:pink_terracotta
setblock 331 65 470 minecraft:red_nether_bricks
fill 331 65 471 331 68 471 minecraft:pink_terracotta
setblock 331 65 475 minecraft:red_nether_bricks
fill 331 65 476 331 67 476 minecraft:pink_terracotta
setblock 331 65 480 minecraft:red_nether_bricks
fill 331 65 481 331 68 481 minecraft:pink_terracotta
setblock 331 65 485 minecraft:red_nether_bricks
fill 331 65 486 331 68 486 minecraft:pink_terracotta
fill 331 65 503 331 65 504 minecraft:pink_terracotta
setblock 332 65 464 minecraft:red_nether_bricks
fill 332 65 465 332 68 465 minecraft:pink_terracotta
setblock 332 65 474 minecraft:light[level=12]
setblock 332 65 479 minecraft:red_nether_bricks
fill 332 65 480 332 66 480 minecraft:pink_terracotta
setblock 332 65 484 minecraft:red_nether_bricks
fill 332 65 485 332 66 485 minecraft:pink_terracotta
setblock 332 65 490 minecraft:light[level=12]
setblock 332 65 498 minecraft:light[level=12]
setblock 332 65 503 minecraft:pink_terracotta
setblock 332 65 504 minecraft:red_nether_bricks
fill 333 65 464 333 68 464 minecraft:pink_terracotta
setblock 333 65 503 minecraft:red_nether_bricks
fill 333 65 504 333 68 504 minecraft:pink_terracotta
fill 334 65 503 334 67 503 minecraft:pink_terracotta
setblock 335 65 466 minecraft:red_nether_bricks
setblock 336 65 465 minecraft:red_nether_bricks
fill 336 65 466 336 68 466 minecraft:pink_terracotta
setblock 337 65 464 minecraft:red_nether_bricks
fill 337 65 465 337 68 465 minecraft:pink_terracotta
setblock 337 65 504 minecraft:red_nether_bricks
fill 338 65 464 338 68 464 minecraft:pink_terracotta
setblock 338 65 503 minecraft:red_nether_bricks
fill 338 65 504 341 65 504 minecraft:pink_terracotta
setblock 339 65 503 minecraft:pink_terracotta
setblock 340 65 466 minecraft:light[level=12]
setblock 340 65 474 minecraft:light[level=12]
setblock 340 65 482 minecraft:light[level=12]
setblock 340 65 490 minecraft:light[level=12]
setblock 340 65 498 minecraft:light[level=12]
setblock 341 65 465 minecraft:red_nether_bricks
setblock 342 65 464 minecraft:red_nether_bricks
setblock 342 65 465 minecraft:pink_terracotta
setblock 342 65 504 minecraft:red_nether_bricks
fill 343 65 464 343 68 464 minecraft:pink_terracotta
fill 343 65 504 343 68 504 minecraft:pink_terracotta
setblock 346 65 465 minecraft:red_nether_bricks
setblock 347 65 464 minecraft:red_nether_bricks
fill 347 65 465 350 65 465 minecraft:pink_terracotta
setblock 347 65 504 minecraft:red_nether_bricks
fill 348 65 464 348 68 464 minecraft:pink_terracotta
setblock 348 65 466 minecraft:light[level=12]
setblock 348 65 474 minecraft:light[level=12]
setblock 348 65 482 minecraft:light[level=12]
setblock 348 65 490 minecraft:light[level=12]
setblock 348 65 498 minecraft:light[level=12]
setblock 348 65 503 minecraft:red_nether_bricks
fill 348 65 504 348 68 504 minecraft:pink_terracotta
setblock 349 65 502 minecraft:red_nether_bricks
fill 349 65 503 349 68 503 minecraft:pink_terracotta
fill 350 65 502 350 68 502 minecraft:pink_terracotta
setblock 351 65 465 minecraft:red_nether_bricks
setblock 352 65 464 minecraft:red_nether_bricks
fill 352 65 465 352 68 465 minecraft:pink_terracotta
setblock 352 65 504 minecraft:red_nether_bricks
fill 353 65 464 353 68 464 minecraft:pink_terracotta
setblock 353 65 503 minecraft:red_nether_bricks
fill 353 65 504 353 68 504 minecraft:pink_terracotta
setblock 354 65 502 minecraft:red_nether_bricks
fill 354 65 503 354 68 503 minecraft:pink_terracotta
fill 355 65 502 355 66 502 minecraft:pink_terracotta
setblock 356 65 465 minecraft:red_nether_bricks
setblock 356 65 466 minecraft:light[level=12]
setblock 356 65 474 minecraft:light[level=12]
setblock 356 65 482 minecraft:light[level=12]
setblock 356 65 490 minecraft:light[level=12]
setblock 356 65 498 minecraft:light[level=12]
setblock 357 65 464 minecraft:red_nether_bricks
setblock 357 65 504 minecraft:red_nether_bricks
fill 358 65 464 358 67 464 minecraft:pink_terracotta
setblock 358 65 503 minecraft:red_nether_bricks
fill 358 65 504 358 68 504 minecraft:pink_terracotta
setblock 359 65 503 minecraft:pink_terracotta
setblock 362 65 504 minecraft:red_nether_bricks
setblock 364 65 466 minecraft:light[level=12]
setblock 364 65 474 minecraft:light[level=12]
setblock 364 65 482 minecraft:light[level=12]
setblock 364 65 490 minecraft:light[level=12]
setblock 364 65 498 minecraft:light[level=12]
setblock 364 65 503 minecraft:white_concrete
fill 365 65 504 366 65 504 minecraft:white_concrete
setblock 367 65 504 minecraft:red_nether_bricks
fill 368 65 464 368 68 464 minecraft:pink_terracotta
setblock 368 65 483 minecraft:red_nether_bricks
fill 368 65 484 368 68 484 minecraft:pink_terracotta
fill 368 65 504 368 67 504 minecraft:pink_terracotta
fill 369 65 478 369 66 478 minecraft:pink_terracotta
setblock 369 65 482 minecraft:red_nether_bricks
fill 369 65 483 369 68 483 minecraft:pink_terracotta
setblock 369 65 487 minecraft:red_nether_bricks
fill 369 65 488 369 68 488 minecraft:pink_terracotta
fill 369 65 490 369 66 490 minecraft:pink_terracotta
setblock 370 65 466 minecraft:red_nether_bricks
fill 370 65 467 370 68 467 minecraft:pink_terracotta
fill 370 65 469 370 65 470 minecraft:pink_terracotta
setblock 370 65 476 minecraft:red_nether_bricks
fill 370 65 477 370 68 477 minecraft:pink_terracotta
setblock 370 65 481 minecraft:red_nether_bricks
fill 370 65 482 370 68 482 minecraft:pink_terracotta
setblock 370 65 486 minecraft:red_nether_bricks
fill 370 65 487 370 68 487 minecraft:pink_terracotta
setblock 370 65 491 minecraft:red_nether_bricks
fill 370 65 492 370 68 492 minecraft:pink_terracotta
setblock 370 65 501 minecraft:red_nether_bricks
fill 370 65 502 370 67 502 minecraft:pink_terracotta
setblock 330 66 464 minecraft:pink_terracotta
setblock 330 66 465 minecraft:red_nether_bricks
fill 330 66 466 330 69 466 minecraft:pink_terracotta
setblock 330 66 470 minecraft:red_nether_bricks
fill 330 66 471 330 69 471 minecraft:pink_terracotta
setblock 330 66 475 minecraft:red_nether_bricks
fill 330 66 476 330 69 476 minecraft:pink_terracotta
setblock 330 66 480 minecraft:red_nether_bricks
fill 330 66 481 330 69 481 minecraft:pink_terracotta
setblock 330 66 485 minecraft:red_nether_bricks
fill 330 66 486 330 69 486 minecraft:pink_terracotta
setblock 330 66 490 minecraft:red_nether_bricks
setblock 330 66 501 minecraft:pink_terracotta
setblock 331 66 464 minecraft:red_nether_bricks
fill 331 66 465 331 69 465 minecraft:pink_terracotta
setblock 331 66 469 minecraft:red_nether_bricks
fill 331 66 470 331 69 470 minecraft:pink_terracotta
setblock 331 66 474 minecraft:red_nether_bricks
fill 331 66 475 331 69 475 minecraft:pink_terracotta
setblock 331 66 479 minecraft:red_nether_bricks
fill 331 66 480 331 69 480 minecraft:pink_terracotta
setblock 331 66 484 minecraft:red_nether_bricks
fill 331 66 485 331 69 485 minecraft:pink_terracotta
setblock 331 66 503 minecraft:pink_terracotta
setblock 331 66 504 minecraft:red_nether_bricks
fill 332 66 464 332 69 464 minecraft:pink_terracotta
setblock 332 66 468 minecraft:red_nether_bricks
fill 332 66 469 332 69 469 minecraft:pink_terracotta
setblock 332 66 483 minecraft:red_nether_bricks
fill 332 66 484 332 67 484 minecraft:pink_terracotta
setblock 332 66 503 minecraft:red_nether_bricks
fill 332 66 504 332 69 504 minecraft:pink_terracotta
fill 333 66 503 333 67 503 minecraft:pink_terracotta
setblock 334 66 466 minecraft:red_nether_bricks
setblock 335 66 465 minecraft:red_nether_bricks
fill 335 66 466 335 69 466 minecraft:pink_terracotta
setblock 336 66 464 minecraft:red_nether_bricks
fill 336 66 465 336 69 465 minecraft:pink_terracotta
setblock 336 66 504 minecraft:red_nether_bricks
fill 337 66 464 337 69 464 minecraft:pink_terracotta
setblock 337 66 503 minecraft:red_nether_bricks
fill 337 66 504 340 66 504 minecraft:pink_terracotta
setblock 340 66 465 minecraft:red_nether_bricks
setblock 341 66 464 minecraft:red_nether_bricks
fill 341 66 465 341 69 465 minecraft:pink_terracotta
setblock 341 66 504 minecraft:red_nether_bricks
fill 342 66 464 342 69 464 minecraft:pink_terracotta
fill 342 66 504 342 69 504 minecraft:pink_terracotta
setblock 346 66 464 minecraft:red_nether_bricks
fill 346 66 465 349 66 465 minecraft:pink_terracotta
setblock 346 66 504 minecraft:red_nether_bricks
fill 347 66 464 347 69 464 minecraft:pink_terracotta
setblock 347 66 503 minecraft:red_nether_bricks
fill 347 66 504 347 69 504 minecraft:pink_terracotta
fill 348 66 503 348 69 503 minecraft:pink_terracotta
setblock 349 66 502 minecraft:pink_terracotta
setblock 350 66 465 minecraft:red_nether_bricks
setblock 351 66 464 minecraft:red_nether_bricks
fill 351 66 465 351 69 465 minecraft:pink_terracotta
setblock 351 66 504 minecraft:red_nether_bricks
fill 352 66 464 352 69 464 minecraft:pink_terracotta
setblock 352 66 503 minecraft:red_nether_bricks
fill 352 66 504 352 69 504 minecraft:pink_terracotta
setblock 353 66 502 minecraft:red_nether_bricks
fill 353 66 503 353 69 503 minecraft:pink_terracotta
fill 354 66 502 354 67 502 minecraft:pink_terracotta
setblock 355 66 465 minecraft:red_nether_bricks
setblock 356 66 464 minecraft:red_nether_bricks
setblock 356 66 504 minecraft:red_nether_bricks
fill 357 66 464 357 69 464 minecraft:pink_terracotta
setblock 357 66 503 minecraft:red_nether_bricks
fill 357 66 504 357 69 504 minecraft:pink_terracotta
setblock 358 66 503 minecraft:pink_terracotta
setblock 361 66 504 minecraft:red_nether_bricks
setblock 363 66 464 minecraft:white_concrete
setblock 368 66 482 minecraft:red_nether_bricks
fill 368 66 483 368 69 483 minecraft:pink_terracotta
setblock 368 66 487 minecraft:red_nether_bricks
setblock 369 66 481 minecraft:red_nether_bricks
fill 369 66 482 369 69 482 minecraft:pink_terracotta
setblock 369 66 486 minecraft:red_nether_bricks
fill 369 66 487 369 69 487 minecraft:pink_terracotta
setblock 370 66 465 minecraft:red_nether_bricks
fill 370 66 466 370 69 466 minecraft:pink_terracotta
setblock 370 66 469 minecraft:pink_terracotta
setblock 370 66 470 minecraft:red_nether_bricks
fill 370 66 471 370 68 472 minecraft:pink_terracotta
setblock 370 66 475 minecraft:red_nether_bricks
fill 370 66 476 370 69 476 minecraft:pink_terracotta
setblock 370 66 480 minecraft:red_nether_bricks
fill 370 66 481 370 69 481 minecraft:pink_terracotta
setblock 370 66 485 minecraft:red_nether_bricks
fill 370 66 486 370 69 486 minecraft:pink_terracotta
setblock 370 66 490 minecraft:red_nether_bricks
fill 370 66 491 370 69 491 minecraft:pink_terracotta
setblock 370 66 501 minecraft:pink_terracotta
setblock 330 67 464 minecraft:red_nether_bricks
fill 330 67 465 330 70 465 minecraft:pink_terracotta
setblock 330 67 469 minecraft:red_nether_bricks
fill 330 67 470 330 70 470 minecraft:pink_terracotta
setblock 330 67 474 minecraft:red_nether_bricks
fill 330 67 475 330 70 475 minecraft:pink_terracotta
setblock 330 67 479 minecraft:red_nether_bricks
fill 330 67 480 330 70 480 minecraft:pink_terracotta
setblock 330 67 484 minecraft:red_nether_bricks
fill 330 67 485 330 70 485 minecraft:pink_terracotta
setblock 330 67 489 minecraft:red_nether_bricks
fill 330 67 490 330 69 491 minecraft:pink_terracotta
setblock 330 67 492 minecraft:white_concrete
fill 330 67 502 330 67 503 minecraft:pink_terracotta
setblock 330 67 504 minecraft:red_nether_bricks
fill 331 67 464 331 70 464 minecraft:pink_terracotta
setblock 331 67 468 minecraft:red_nether_bricks
fill 331 67 469 331 70 469 minecraft:pink_terracotta
setblock 331 67 473 minecraft:red_nether_bricks
fill 331 67 474 331 70 474 minecraft:pink_terracotta
setblock 331 67 478 minecraft:red_nether_bricks
fill 331 67 479 331 69 479 minecraft:pink_terracotta
setblock 331 67 483 minecraft:red_nether_bricks
fill 331 67 484 331 70 484 minecraft:pink_terracotta
setblock 331 67 488 minecraft:red_nether_bricks
fill 331 67 504 331 70 504 minecraft:pink_terracotta
setblock 332 67 467 minecraft:red_nether_bricks
fill 332 67 468 332 70 468 minecraft:pink_terracotta
setblock 332 67 483 minecraft:pink_terracotta
setblock 332 67 503 minecraft:pink_terracotta
setblock 333 67 466 minecraft:red_nether_bricks
setblock 334 67 465 minecraft:red_nether_bricks
fill 334 67 466 334 70 466 minecraft:pink_terracotta
setblock 335 67 464 minecraft:red_nether_bricks
fill 335 67 465 335 70 465 minecraft:pink_terracotta
setblock 335 67 504 minecraft:red_nether_bricks
fill 336 67 464 336 70 464 minecraft:pink_terracotta
fill 336 67 504 339 67 504 minecraft:pink_terracotta
setblock 339 67 465 minecraft:red_nether_bricks
setblock 340 67 464 minecraft:red_nether_bricks
fill 340 67 465 340 70 465 minecraft:pink_terracotta
setblock 340 67 504 minecraft:red_nether_bricks
fill 341 67 464 341 70 464 minecraft:pink_terracotta
fill 341 67 504 341 70 504 minecraft:pink_terracotta
setblock 345 67 464 minecraft:red_nether_bricks
fill 345 67 465 348 67 465 minecraft:pink_terracotta
setblock 345 67 504 minecraft:red_nether_bricks
fill 346 67 464 346 70 464 minecraft:pink_terracotta
setblock 346 67 503 minecraft:red_nether_bricks
fill 346 67 504 346 70 504 minecraft:pink_terracotta
fill 347 67 503 347 70 503 minecraft:pink_terracotta
setblock 349 67 465 minecraft:red_nether_bricks
setblock 350 67 464 minecraft:red_nether_bricks
fill 350 67 465 350 70 465 minecraft:pink_terracotta
setblock 350 67 504 minecraft:red_nether_bricks
fill 351 67 464 351 70 464 minecraft:pink_terracotta
setblock 351 67 503 minecraft:red_nether_bricks
fill 351 67 504 351 70 504 minecraft:pink_terracotta
setblock 352 67 502 minecraft:red_nether_bricks
fill 352 67 503 352 70 503 minecraft:pink_terracotta
setblock 353 67 502 minecraft:pink_terracotta
setblock 354 67 465 minecraft:red_nether_bricks
setblock 355 67 464 minecraft:red_nether_bricks
setblock 355 67 465 minecraft:pink_terracotta
setblock 355 67 504 minecraft:red_nether_bricks
fill 356 67 464 356 70 464 minecraft:pink_terracotta
setblock 356 67 503 minecraft:red_nether_bricks
fill 356 67 504 356 70 504 minecraft:pink_terracotta
setblock 357 67 503 minecraft:pink_terracotta
setblock 362 67 504 minecraft:white_concrete
fill 367 67 464 367 69 464 minecraft:pink_terracotta
setblock 368 67 482 minecraft:pink_terracotta
setblock 368 67 485 minecraft:pink_terracotta
setblock 368 67 486 minecraft:red_nether_bricks
fill 368 67 487 368 70 487 minecraft:pink_terracotta
setblock 369 67 480 minecraft:red_nether_bricks
fill 369 67 481 369 70 481 minecraft:pink_terracotta
setblock 369 67 485 minecraft:red_nether_bricks
fill 369 67 486 369 70 486 minecraft:pink_terracotta
setblock 369 67 490 minecraft:red_nether_bricks
setblock 370 67 464 minecraft:red_nether_bricks
fill 370 67 465 370 70 465 minecraft:pink_terracotta
setblock 370 67 469 minecraft:red_nether_bricks
fill 370 67 470 370 70 470 minecraft:pink_terracotta
setblock 370 67 474 minecraft:red_nether_bricks
fill 370 67 475 370 70 475 minecraft:pink_terracotta
setblock 370 67 479 minecraft:red_nether_bricks
fill 370 67 480 370 70 480 minecraft:pink_terracotta
setblock 370 67 484 minecraft:red_nether_bricks
fill 370 67 485 370 70 485 minecraft:pink_terracotta
setblock 370 67 489 minecraft:red_nether_bricks
fill 370 67 490 370 70 490 minecraft:pink_terracotta
setblock 370 67 495 minecraft:white_concrete
setblock 370 67 501 minecraft:white_concrete
setblock 370 67 504 minecraft:red_nether_bricks
fill 330 68 464 330 71 464 minecraft:pink_terracotta
setblock 330 68 468 minecraft:red_nether_bricks
fill 330 68 469 330 71 469 minecraft:pink_terracotta
setblock 330 68 473 minecraft:red_nether_bricks
fill 330 68 474 330 71 474 minecraft:pink_terracotta
setblock 330 68 478 minecraft:red_nether_bricks
fill 330 68 479 330 71 479 minecraft:pink_terracotta
setblock 330 68 483 minecraft:red_nether_bricks
fill 330 68 484 330 71 484 minecraft:pink_terracotta
setblock 330 68 488 minecraft:red_nether_bricks
fill 330 68 489 331 70 489 minecraft:pink_terracotta
setblock 330 68 498 minecraft:white_concrete
setblock 330 68 502 minecraft:pink_terracotta
setblock 330 68 503 minecraft:red_nether_bricks
fill 330 68 504 330 71 504 minecraft:pink_terracotta
setblock 331 68 467 minecraft:red_nether_bricks
fill 331 68 468 331 71 468 minecraft:pink_terracotta
setblock 331 68 472 minecraft:red_nether_bricks
fill 331 68 473 331 71 473 minecraft:pink_terracotta
setblock 331 68 477 minecraft:red_nether_bricks
setblock 331 68 478 minecraft:pink_terracotta
setblock 331 68 482 minecraft:red_nether_bricks
fill 331 68 483 331 71 483 minecraft:pink_terracotta
setblock 331 68 487 minecraft:red_nether_bricks
fill 331 68 488 331 71 488 minecraft:pink_terracotta
setblock 332 68 466 minecraft:red_nether_bricks
fill 332 68 467 332 71 467 minecraft:pink_terracotta
setblock 332 68 470 minecraft:pink_terracotta
setblock 333 68 465 minecraft:red_nether_bricks
fill 333 68 466 333 71 466 minecraft:pink_terracotta
setblock 334 68 464 minecraft:red_nether_bricks
fill 334 68 465 334 71 465 minecraft:pink_terracotta
setblock 334 68 504 minecraft:red_nether_bricks
fill 335 68 464 335 71 464 minecraft:pink_terracotta
fill 335 68 504 338 68 504 minecraft:pink_terracotta
setblock 338 68 465 minecraft:red_nether_bricks
setblock 339 68 464 minecraft:red_nether_bricks
fill 339 68 465 339 71 465 minecraft:pink_terracotta
setblock 339 68 504 minecraft:red_nether_bricks
fill 340 68 464 340 71 464 minecraft:pink_terracotta
fill 340 68 504 340 71 504 minecraft:pink_terracotta
setblock 344 68 464 minecraft:red_nether_bricks
fill 344 68 465 347 68 465 minecraft:pink_terracotta
setblock 344 68 504 minecraft:red_nether_bricks
fill 345 68 464 345 71 464 minecraft:pink_terracotta
fill 345 68 504 345 71 504 minecraft:pink_terracotta
fill 346 68 503 346 71 503 minecraft:pink_terracotta
setblock 348 68 465 minecraft:red_nether_bricks
setblock 349 68 464 minecraft:red_nether_bricks
fill 349 68 465 349 71 465 minecraft:pink_terracotta
setblock 349 68 504 minecraft:red_nether_bricks
fill 350 68 464 350 71 464 minecraft:pink_terracotta
setblock 350 68 503 minecraft:red_nether_bricks
fill 350 68 504 350 71 504 minecraft:pink_terracotta
setblock 351 68 502 minecraft:red_nether_bricks
fill 351 68 503 351 71 503 minecraft:pink_terracotta
setblock 352 68 502 minecraft:pink_terracotta
setblock 353 68 465 minecraft:red_nether_bricks
setblock 354 68 464 minecraft:red_nether_bricks
fill 354 68 465 354 71 465 minecraft:pink_terracotta
setblock 354 68 504 minecraft:red_nether_bricks
fill 355 68 464 355 71 464 minecraft:pink_terracotta
setblock 355 68 503 minecraft:red_nether_bricks
fill 355 68 504 355 71 504 minecraft:pink_terracotta
setblock 356 68 503 minecraft:pink_terracotta
setblock 368 68 485 minecraft:red_nether_bricks
fill 368 68 486 368 71 486 minecraft:pink_terracotta
fill 368 68 488 368 69 488 minecraft:pink_terracotta
setblock 368 68 504 minecraft:white_concrete
setblock 369 68 464 minecraft:red_nether_bricks
fill 369 68 465 369 68 468 minecraft:pink_terracotta
setblock 369 68 479 minecraft:red_nether_bricks
fill 369 68 480 369 71 480 minecraft:pink_terracotta
setblock 369 68 484 minecraft:red_nether_bricks
fill 369 68 485 369 71 485 minecraft:pink_terracotta
setblock 369 68 489 minecraft:red_nether_bricks
fill 369 68 490 369 70 491 minecraft:pink_terracotta
setblock 369 68 504 minecraft:red_nether_bricks
fill 370 68 464 370 71 464 minecraft:pink_terracotta
setblock 370 68 468 minecraft:red_nether_bricks
fill 370 68 469 370 71 469 minecraft:pink_terracotta
setblock 370 68 473 minecraft:red_nether_bricks
fill 370 68 474 370 71 474 minecraft:pink_terracotta
setblock 370 68 478 minecraft:red_nether_bricks
fill 370 68 479 370 71 479 minecraft:pink_terracotta
setblock 370 68 483 minecraft:red_nether_bricks
fill 370 68 484 370 71 484 minecraft:pink_terracotta
setblock 370 68 488 minecraft:red_nether_bricks
fill 370 68 489 370 71 489 minecraft:pink_terracotta
setblock 370 68 493 minecraft:red_nether_bricks
fill 370 68 494 370 71 494 minecraft:pink_terracotta
setblock 370 68 503 minecraft:red_nether_bricks
fill 370 68 504 370 71 504 minecraft:pink_terracotta
setblock 330 69 467 minecraft:red_nether_bricks
fill 330 69 468 330 72 468 minecraft:pink_terracotta
setblock 330 69 472 minecraft:red_nether_bricks
fill 330 69 473 330 72 473 minecraft:pink_terracotta
setblock 330 69 477 minecraft:red_nether_bricks
fill 330 69 478 330 72 478 minecraft:pink_terracotta
setblock 330 69 482 minecraft:red_nether_bricks
fill 330 69 483 330 72 483 minecraft:pink_terracotta
setblock 330 69 487 minecraft:red_nether_bricks
fill 330 69 488 330 72 488 minecraft:pink_terracotta
setblock 330 69 492 minecraft:red_nether_bricks
setblock 330 69 502 minecraft:red_nether_bricks
fill 330 69 503 330 72 503 minecraft:pink_terracotta
setblock 331 69 466 minecraft:red_nether_bricks
fill 331 69 467 331 72 467 minecraft:pink_terracotta
setblock 331 69 471 minecraft:red_nether_bricks
fill 331 69 472 331 72 472 minecraft:pink_terracotta
setblock 331 69 481 minecraft:red_nether_bricks
fill 331 69 482 331 72 482 minecraft:pink_terracotta
setblock 331 69 486 minecraft:red_nether_bricks
fill 331 69 487 331 72 487 minecraft:pink_terracotta
setblock 332 69 465 minecraft:red_nether_bricks
fill 332 69 466 332 72 466 minecraft:pink_terracotta
setblock 332 69 470 minecraft:red_nether_bricks
fill 332 69 471 332 72 471 minecraft:pink_terracotta
setblock 333 69 464 minecraft:red_nether_bricks
fill 333 69 465 333 72 465 minecraft:pink_terracotta
fill 333 69 467 333 70 467 minecraft:pink_terracotta
setblock 333 69 504 minecraft:red_nether_bricks
fill 334 69 464 334 72 464 minecraft:pink_terracotta
fill 334 69 504 337 69 504 minecraft:pink_terracotta
setblock 336 69 466 minecraft:red_nether_bricks
setblock 337 69 465 minecraft:red_nether_bricks
setblock 338 69 464 minecraft:red_nether_bricks
fill 338 69 465 338 72 465 minecraft:pink_terracotta
setblock 338 69 504 minecraft:red_nether_bricks
fill 339 69 464 339 72 464 minecraft:pink_terracotta
fill 339 69 504 339 72 504 minecraft:pink_terracotta
setblock 342 69 465 minecraft:red_nether_bricks
setblock 343 69 464 minecraft:red_nether_bricks
fill 343 69 465 346 69 465 minecraft:pink_terracotta
setblock 343 69 504 minecraft:red_nether_bricks
fill 344 69 464 344 72 464 minecraft:pink_terracotta
fill 344 69 504 344 72 504 minecraft:pink_terracotta
setblock 347 69 465 minecraft:red_nether_bricks
setblock 348 69 464 minecraft:red_nether_bricks
fill 348 69 465 348 72 465 minecraft:pink_terracotta
setblock 348 69 504 minecraft:red_nether_bricks
fill 349 69 464 349 72 464 minecraft:pink_terracotta
setblock 349 69 503 minecraft:red_nether_bricks
fill 349 69 504 349 72 504 minecraft:pink_terracotta
fill 350 69 503 350 72 503 minecraft:pink_terracotta
setblock 352 69 465 minecraft:red_nether_bricks
setblock 353 69 464 minecraft:red_nether_bricks
fill 353 69 465 353 72 465 minecraft:pink_terracotta
setblock 353 69 504 minecraft:red_nether_bricks
fill 354 69 464 354 72 464 minecraft:pink_terracotta
setblock 354 69 503 minecraft:red_nether_bricks
fill 354 69 504 354 72 504 minecraft:pink_terracotta
setblock 355 69 503 minecraft:pink_terracotta
fill 366 69 464 366 70 464 minecraft:pink_terracotta
setblock 368 69 464 minecraft:red_nether_bricks
fill 368 69 465 369 71 465 minecraft:pink_terracotta
fill 368 69 482 368 70 482 minecraft:pink_terracotta
setblock 368 69 484 minecraft:red_nether_bricks
fill 368 69 485 368 72 485 minecraft:pink_terracotta
setblock 368 69 489 minecraft:red_nether_bricks
fill 369 69 464 369 72 464 minecraft:pink_terracotta
fill 369 69 466 369 69 467 minecraft:pink_terracotta
setblock 369 69 468 minecraft:red_nether_bricks
fill 369 69 469 369 70 471 minecraft:pink_terracotta
setblock 369 69 478 minecraft:red_nether_bricks
fill 369 69 479 369 72 479 minecraft:pink_terracotta
setblock 369 69 483 minecraft:red_nether_bricks
fill 369 69 484 369 72 484 minecraft:pink_terracotta
setblock 369 69 488 minecraft:red_nether_bricks
fill 369 69 489 369 72 489 minecraft:pink_terracotta
setblock 369 69 492 minecraft:pink_terracotta
fill 369 69 504 369 72 504 minecraft:pink_terracotta
setblock 370 69 467 minecraft:red_nether_bricks
fill 370 69 468 370 72 468 minecraft:pink_terracotta
setblock 370 69 471 minecraft:pink_terracotta
setblock 370 69 472 minecraft:red_nether_bricks
fill 370 69 473 370 72 473 minecraft:pink_terracotta
setblock 370 69 477 minecraft:red_nether_bricks
fill 370 69 478 370 72 478 minecraft:pink_terracotta
setblock 370 69 482 minecraft:red_nether_bricks
fill 370 69 483 370 72 483 minecraft:pink_terracotta
setblock 370 69 487 minecraft:red_nether_bricks
fill 370 69 488 370 72 488 minecraft:pink_terracotta
setblock 370 69 492 minecraft:red_nether_bricks
fill 370 69 493 370 72 493 minecraft:pink_terracotta
fill 370 69 503 370 72 503 minecraft:pink_terracotta
setblock 330 70 466 minecraft:red_nether_bricks
fill 330 70 467 330 73 467 minecraft:pink_terracotta
setblock 330 70 471 minecraft:red_nether_bricks
fill 330 70 472 330 73 472 minecraft:pink_terracotta
setblock 330 70 476 minecraft:red_nether_bricks
fill 330 70 477 330 73 477 minecraft:pink_terracotta
setblock 330 70 481 minecraft:red_nether_bricks
fill 330 70 482 330 73 482 minecraft:pink_terracotta
setblock 330 70 486 minecraft:red_nether_bricks
fill 330 70 487 330 73 487 minecraft:pink_terracotta
setblock 330 70 490 minecraft:pink_terracotta
setblock 330 70 491 minecraft:red_nether_bricks
fill 330 70 492 330 72 493 minecraft:pink_terracotta
fill 330 70 502 330 73 502 minecraft:pink_terracotta
setblock 331 70 465 minecraft:red_nether_bricks
fill 331 70 466 331 73 466 minecraft:pink_terracotta
setblock 331 70 470 minecraft:red_nether_bricks
fill 331 70 471 331 73 471 minecraft:pink_terracotta
setblock 331 70 475 minecraft:red_nether_bricks
fill 331 70 476 331 73 476 minecraft:pink_terracotta
setblock 331 70 480 minecraft:red_nether_bricks
fill 331 70 481 331 71 481 minecraft:pink_terracotta
setblock 331 70 485 minecraft:red_nether_bricks
fill 331 70 486 331 73 486 minecraft:pink_terracotta
setblock 331 70 490 minecraft:red_nether_bricks
setblock 332 70 464 minecraft:red_nether_bricks
fill 332 70 465 332 73 465 minecraft:pink_terracotta
setblock 332 70 469 minecraft:red_nether_bricks
fill 332 70 470 332 73 470 minecraft:pink_terracotta
fill 332 70 472 332 71 472 minecraft:pink_terracotta
setblock 332 70 504 minecraft:red_nether_bricks
fill 333 70 464 333 73 464 minecraft:pink_terracotta
setblock 333 70 468 minecraft:red_nether_bricks
fill 333 70 504 336 70 504 minecraft:pink_terracotta
setblock 335 70 466 minecraft:red_nether_bricks
setblock 336 70 465 minecraft:red_nether_bricks
fill 336 70 466 336 73 466 minecraft:pink_terracotta
setblock 337 70 464 minecraft:red_nether_bricks
fill 337 70 465 337 73 465 minecraft:pink_terracotta
setblock 337 70 504 minecraft:red_nether_bricks
fill 338 70 464 338 73 464 minecraft:pink_terracotta
fill 338 70 504 338 73 504 minecraft:pink_terracotta
setblock 341 70 465 minecraft:red_nether_bricks
setblock 342 70 464 minecraft:red_nether_bricks
fill 342 70 465 345 70 465 minecraft:pink_terracotta
setblock 342 70 504 minecraft:red_nether_bricks
fill 343 70 464 343 73 464 minecraft:pink_terracotta
fill 343 70 504 343 73 504 minecraft:pink_terracotta
fill 345 70 503 345 72 503 minecraft:pink_terracotta
setblock 346 70 465 minecraft:red_nether_bricks
setblock 347 70 464 minecraft:red_nether_bricks
fill 347 70 465 347 73 465 minecraft:pink_terracotta
setblock 347 70 504 minecraft:red_nether_bricks
fill 348 70 464 348 73 464 minecraft:pink_terracotta
fill 348 70 466 349 70 466 minecraft:pink_terracotta
setblock 348 70 503 minecraft:red_nether_bricks
fill 348 70 504 348 73 504 minecraft:pink_terracotta
fill 349 70 503 349 73 503 minecraft:pink_terracotta
setblock 350 70 466 minecraft:red_nether_bricks
setblock 351 70 465 minecraft:red_nether_bricks
setblock 352 70 464 minecraft:red_nether_bricks
fill 352 70 465 352 73 465 minecraft:pink_terracotta
setblock 352 70 504 minecraft:red_nether_bricks
fill 353 70 464 353 73 464 minecraft:pink_terracotta
setblock 353 70 503 minecraft:red_nether_bricks
fill 353 70 504 353 73 504 minecraft:pink_terracotta
setblock 354 70 503 minecraft:pink_terracotta
setblock 357 70 504 minecraft:red_nether_bricks
setblock 361 70 504 minecraft:white_concrete
setblock 364 70 464 minecraft:white_concrete
fill 365 70 464 365 71 464 minecraft:pink_terracotta
setblock 367 70 464 minecraft:red_nether_bricks
fill 367 70 465 367 73 465 minecraft:pink_terracotta
fill 368 70 464 368 73 464 minecraft:pink_terracotta
setblock 368 70 483 minecraft:red_nether_bricks
fill 368 70 484 368 73 484 minecraft:pink_terracotta
setblock 368 70 488 minecraft:red_nether_bricks
fill 368 70 489 368 72 490 minecraft:pink_terracotta
fill 368 70 504 368 73 504 minecraft:pink_terracotta
setblock 369 70 466 minecraft:pink_terracotta
setblock 369 70 467 minecraft:red_nether_bricks
fill 369 70 468 369 73 468 minecraft:pink_terracotta
setblock 369 70 472 minecraft:red_nether_bricks
fill 369 70 473 369 70 476 minecraft:pink_terracotta
setblock 369 70 477 minecraft:red_nether_bricks
fill 369 70 478 369 73 478 minecraft:pink_terracotta
setblock 369 70 482 minecraft:red_nether_bricks
fill 369 70 483 369 73 483 minecraft:pink_terracotta
setblock 369 70 487 minecraft:red_nether_bricks
fill 369 70 488 369 73 488 minecraft:pink_terracotta
setblock 369 70 492 minecraft:red_nether_bricks
fill 369 70 493 369 73 493 minecraft:pink_terracotta
setblock 370 70 466 minecraft:red_nether_bricks
fill 370 70 467 370 73 467 minecraft:pink_terracotta
setblock 370 70 471 minecraft:red_nether_bricks
fill 370 70 472 370 73 472 minecraft:pink_terracotta
setblock 370 70 476 minecraft:red_nether_bricks
fill 370 70 477 370 73 477 minecraft:pink_terracotta
setblock 370 70 481 minecraft:red_nether_bricks
fill 370 70 482 370 73 482 minecraft:pink_terracotta
setblock 370 70 486 minecraft:red_nether_bricks
fill 370 70 487 370 73 487 minecraft:pink_terracotta
setblock 370 70 491 minecraft:red_nether_bricks
fill 370 70 492 370 73 492 minecraft:pink_terracotta
setblock 370 70 495 minecraft:pink_terracotta
setblock 370 70 502 minecraft:white_concrete
setblock 330 71 465 minecraft:red_nether_bricks
fill 330 71 466 330 74 466 minecraft:pink_terracotta
setblock 330 71 470 minecraft:red_nether_bricks
fill 330 71 471 330 74 471 minecraft:pink_terracotta
setblock 330 71 475 minecraft:red_nether_bricks
fill 330 71 476 330 74 476 minecraft:pink_terracotta
setblock 330 71 480 minecraft:red_nether_bricks
fill 330 71 481 330 74 481 minecraft:pink_terracotta
setblock 330 71 485 minecraft:red_nether_bricks
fill 330 71 486 330 74 486 minecraft:pink_terracotta
setblock 330 71 489 minecraft:pink_terracotta
setblock 330 71 490 minecraft:red_nether_bricks
fill 330 71 491 331 73 491 minecraft:pink_terracotta
setblock 330 71 494 minecraft:pink_terracotta
setblock 330 71 495 minecraft:red_nether_bricks
setblock 330 71 497 minecraft:white_concrete
fill 330 71 501 330 74 501 minecraft:pink_terracotta
setblock 331 71 464 minecraft:red_nether_bricks
fill 331 71 465 331 74 465 minecraft:pink_terracotta
setblock 331 71 469 minecraft:red_nether_bricks
fill 331 71 470 331 74 470 minecraft:pink_terracotta
setblock 331 71 474 minecraft:red_nether_bricks
fill 331 71 475 331 74 475 minecraft:pink_terracotta
fill 331 71 477 331 72 477 minecraft:pink_terracotta
setblock 331 71 484 minecraft:red_nether_bricks
fill 331 71 485 331 74 485 minecraft:pink_terracotta
setblock 331 71 489 minecraft:red_nether_bricks
fill 331 71 490 331 74 490 minecraft:pink_terracotta
setblock 331 71 504 minecraft:red_nether_bricks
fill 332 71 464 332 74 464 minecraft:pink_terracotta
setblock 332 71 468 minecraft:red_nether_bricks
fill 332 71 469 333 73 469 minecraft:pink_terracotta
fill 332 71 504 335 71 504 minecraft:pink_terracotta
setblock 333 71 467 minecraft:red_nether_bricks
fill 333 71 468 333 74 468 minecraft:pink_terracotta
setblock 334 71 466 minecraft:red_nether_bricks
setblock 335 71 465 minecraft:red_nether_bricks
fill 335 71 466 335 74 466 minecraft:pink_terracotta
setblock 336 71 464 minecraft:red_nether_bricks
fill 336 71 465 336 74 465 minecraft:pink_terracotta
setblock 336 71 504 minecraft:red_nether_bricks
fill 337 71 464 337 74 464 minecraft:pink_terracotta
fill 337 71 504 337 74 504 minecraft:pink_terracotta
setblock 340 71 465 minecraft:red_nether_bricks
setblock 341 71 464 minecraft:red_nether_bricks
fill 341 71 465 344 71 465 minecraft:pink_terracotta
setblock 341 71 504 minecraft:red_nether_bricks
fill 342 71 464 342 74 464 minecraft:pink_terracotta
fill 342 71 504 342 74 504 minecraft:pink_terracotta
setblock 345 71 465 minecraft:red_nether_bricks
setblock 346 71 464 minecraft:red_nether_bricks
fill 346 71 465 346 73 466 minecraft:pink_terracotta
setblock 346 71 504 minecraft:red_nether_bricks
fill 347 71 464 347 74 464 minecraft:pink_terracotta
fill 347 71 466 348 71 466 minecraft:pink_terracotta
setblock 347 71 503 minecraft:red_nether_bricks
fill 347 71 504 347 74 504 minecraft:pink_terracotta
fill 348 71 503 348 74 503 minecraft:pink_terracotta
setblock 349 71 466 minecraft:red_nether_bricks
setblock 350 71 465 minecraft:red_nether_bricks
fill 350 71 466 351 73 466 minecraft:pink_terracotta
setblock 351 71 464 minecraft:red_nether_bricks
fill 351 71 465 351 74 465 minecraft:pink_terracotta
setblock 351 71 504 minecraft:red_nether_bricks
fill 352 71 464 352 74 464 minecraft:pink_terracotta
setblock 352 71 503 minecraft:red_nether_bricks
fill 352 71 504 352 74 504 minecraft:pink_terracotta
fill 353 71 503 353 72 503 minecraft:pink_terracotta
setblock 356 71 464 minecraft:red_nether_bricks
setblock 356 71 504 minecraft:red_nether_bricks
setblock 358 71 464 minecraft:white_concrete
setblock 366 71 464 minecraft:red_nether_bricks
fill 366 71 465 366 74 465 minecraft:pink_terracotta
fill 367 71 464 367 74 464 minecraft:pink_terracotta
setblock 367 71 487 minecraft:pink_terracotta
setblock 367 71 504 minecraft:white_concrete
setblock 368 71 466 minecraft:pink_terracotta
setblock 368 71 467 minecraft:red_nether_bricks
fill 368 71 468 368 71 471 minecraft:pink_terracotta
setblock 368 71 482 minecraft:red_nether_bricks
fill 368 71 483 368 74 483 minecraft:pink_terracotta
setblock 368 71 487 minecraft:red_nether_bricks
fill 368 71 488 368 74 488 minecraft:pink_terracotta
setblock 368 71 491 minecraft:pink_terracotta
setblock 369 71 466 minecraft:red_nether_bricks
fill 369 71 467 369 74 467 minecraft:pink_terracotta
fill 369 71 469 369 71 470 minecraft:pink_terracotta
setblock 369 71 471 minecraft:red_nether_bricks
fill 369 71 472 369 71 475 minecraft:pink_terracotta
setblock 369 71 476 minecraft:red_nether_bricks
fill 369 71 477 369 74 477 minecraft:pink_terracotta
setblock 369 71 481 minecraft:red_nether_bricks
fill 369 71 482 369 74 482 minecraft:pink_terracotta
setblock 369 71 486 minecraft:red_nether_bricks
fill 369 71 487 369 74 487 minecraft:pink_terracotta
setblock 369 71 490 minecraft:pink_terracotta
setblock 369 71 491 minecraft:red_nether_bricks
fill 369 71 492 369 74 492 minecraft:pink_terracotta
fill 369 71 494 369 72 494 minecraft:pink_terracotta
setblock 370 71 465 minecraft:red_nether_bricks
fill 370 71 466 370 74 466 minecraft:pink_terracotta
setblock 370 71 470 minecraft:red_nether_bricks
fill 370 71 471 370 74 471 minecraft:pink_terracotta
setblock 370 71 475 minecraft:red_nether_bricks
fill 370 71 476 370 74 476 minecraft:pink_terracotta
setblock 370 71 480 minecraft:red_nether_bricks
fill 370 71 481 370 74 481 minecraft:pink_terracotta
setblock 370 71 485 minecraft:red_nether_bricks
fill 370 71 486 370 74 486 minecraft:pink_terracotta
setblock 370 71 490 minecraft:red_nether_bricks
fill 370 71 491 370 74 491 minecraft:pink_terracotta
setblock 370 71 495 minecraft:red_nether_bricks
fill 370 71 496 370 74 496 minecraft:pink_terracotta
setblock 330 72 464 minecraft:red_nether_bricks
fill 330 72 465 330 75 465 minecraft:pink_terracotta
setblock 330 72 469 minecraft:red_nether_bricks
fill 330 72 470 330 75 470 minecraft:pink_terracotta
setblock 330 72 474 minecraft:red_nether_bricks
fill 330 72 475 330 75 475 minecraft:pink_terracotta
setblock 330 72 479 minecraft:red_nether_bricks
fill 330 72 480 330 75 480 minecraft:pink_terracotta
setblock 330 72 484 minecraft:red_nether_bricks
fill 330 72 485 330 75 485 minecraft:pink_terracotta
setblock 330 72 489 minecraft:red_nether_bricks
fill 330 72 490 330 75 490 minecraft:pink_terracotta
setblock 330 72 494 minecraft:red_nether_bricks
fill 330 72 495 330 73 497 minecraft:pink_terracotta
setblock 330 72 504 minecraft:red_nether_bricks
fill 331 72 464 331 75 464 minecraft:pink_terracotta
setblock 331 72 468 minecraft:red_nether_bricks
fill 331 72 469 331 75 469 minecraft:pink_terracotta
setblock 331 72 473 minecraft:red_nether_bricks
fill 331 72 474 331 75 474 minecraft:pink_terracotta
setblock 331 72 483 minecraft:red_nether_bricks
fill 331 72 484 331 73 484 minecraft:pink_terracotta
setblock 331 72 488 minecraft:red_nether_bricks
fill 331 72 489 331 75 489 minecraft:pink_terracotta
setblock 331 72 492 minecraft:pink_terracotta
fill 331 72 504 334 72 504 minecraft:pink_terracotta
setblock 332 72 467 minecraft:red_nether_bricks
fill 332 72 468 332 75 468 minecraft:pink_terracotta
setblock 332 72 472 minecraft:red_nether_bricks
fill 332 72 473 332 75 473 minecraft:pink_terracotta
setblock 333 72 466 minecraft:red_nether_bricks
fill 333 72 467 334 72 467 minecraft:pink_terracotta
setblock 334 72 465 minecraft:red_nether_bricks
fill 334 72 466 334 75 466 minecraft:pink_terracotta
setblock 335 72 464 minecraft:red_nether_bricks
fill 335 72 465 335 75 465 minecraft:pink_terracotta
setblock 335 72 504 minecraft:red_nether_bricks
fill 336 72 464 336 75 464 minecraft:pink_terracotta
fill 336 72 504 336 75 504 minecraft:pink_terracotta
setblock 339 72 465 minecraft:red_nether_bricks
setblock 340 72 464 minecraft:red_nether_bricks
fill 340 72 465 343 72 465 minecraft:pink_terracotta
setblock 340 72 504 minecraft:red_nether_bricks
fill 341 72 464 341 75 464 minecraft:pink_terracotta
fill 341 72 504 341 75 504 minecraft:pink_terracotta
setblock 344 72 465 minecraft:red_nether_bricks
fill 344 72 503 344 73 503 minecraft:pink_terracotta
setblock 345 72 464 minecraft:red_nether_bricks
fill 345 72 465 345 74 466 minecraft:pink_terracotta
setblock 345 72 504 minecraft:red_nether_bricks
fill 346 72 464 346 75 464 minecraft:pink_terracotta
setblock 346 72 503 minecraft:red_nether_bricks
fill 346 72 504 346 75 504 minecraft:pink_terracotta
setblock 347 72 466 minecraft:pink_terracotta
fill 347 72 503 347 75 503 minecraft:pink_terracotta
setblock 348 72 466 minecraft:red_nether_bricks
setblock 349 72 465 minecraft:red_nether_bricks
fill 349 72 466 349 75 466 minecraft:pink_terracotta
fill 349 72 502 349 74 502 minecraft:pink_terracotta
setblock 350 72 464 minecraft:red_nether_bricks
fill 350 72 465 350 75 465 minecraft:pink_terracotta
setblock 350 72 504 minecraft:red_nether_bricks
fill 351 72 464 351 75 464 minecraft:pink_terracotta
setblock 351 72 503 minecraft:red_nether_bricks
fill 351 72 504 351 75 504 minecraft:pink_terracotta
fill 352 72 503 352 74 503 minecraft:pink_terracotta
setblock 355 72 464 minecraft:red_nether_bricks
setblock 355 72 504 minecraft:red_nether_bricks
setblock 364 72 464 minecraft:pink_terracotta
setblock 365 72 464 minecraft:red_nether_bricks
fill 365 72 465 365 75 465 minecraft:pink_terracotta
fill 366 72 464 366 75 464 minecraft:pink_terracotta
setblock 367 72 466 minecraft:pink_terracotta
setblock 367 72 486 minecraft:pink_terracotta
setblock 367 72 487 minecraft:red_nether_bricks
fill 367 72 488 367 74 489 minecraft:pink_terracotta
fill 367 72 504 367 74 504 minecraft:pink_terracotta
setblock 368 72 465 minecraft:pink_terracotta
setblock 368 72 466 minecraft:red_nether_bricks
fill 368 72 467 368 72 470 minecraft:pink_terracotta
setblock 368 72 471 minecraft:red_nether_bricks
fill 368 72 472 369 72 474 minecraft:pink_terracotta
setblock 368 72 481 minecraft:red_nether_bricks
fill 368 72 482 368 75 482 minecraft:pink_terracotta
setblock 368 72 486 minecraft:red_nether_bricks
fill 368 72 487 368 75 487 minecraft:pink_terracotta
setblock 368 72 491 minecraft:red_nether_bricks
fill 368 72 492 368 75 492 minecraft:pink_terracotta
setblock 369 72 465 minecraft:red_nether_bricks
fill 369 72 466 369 75 466 minecraft:pink_terracotta
setblock 369 72 469 minecraft:pink_terracotta
setblock 369 72 470 minecraft:red_nether_bricks
fill 369 72 471 369 75 471 minecraft:pink_terracotta
setblock 369 72 475 minecraft:red_nether_bricks
fill 369 72 476 369 75 476 minecraft:pink_terracotta
setblock 369 72 480 minecraft:red_nether_bricks
fill 369 72 481 369 75 481 minecraft:pink_terracotta
setblock 369 72 485 minecraft:red_nether_bricks
fill 369 72 486 369 75 486 minecraft:pink_terracotta
setblock 369 72 490 minecraft:red_nether_bricks
fill 369 72 491 369 75 491 minecraft:pink_terracotta
setblock 369 72 495 minecraft:red_nether_bricks
setblock 370 72 464 minecraft:red_nether_bricks
fill 370 72 465 370 75 465 minecraft:pink_terracotta
setblock 370 72 469 minecraft:red_nether_bricks
fill 370 72 470 370 75 470 minecraft:pink_terracotta
setblock 370 72 474 minecraft:red_nether_bricks
fill 370 72 475 370 75 475 minecraft:pink_terracotta
setblock 370 72 479 minecraft:red_nether_bricks
fill 370 72 480 370 75 480 minecraft:pink_terracotta
setblock 370 72 484 minecraft:red_nether_bricks
fill 370 72 485 370 75 485 minecraft:pink_terracotta
setblock 370 72 489 minecraft:red_nether_bricks
fill 370 72 490 370 75 490 minecraft:pink_terracotta
setblock 370 72 494 minecraft:red_nether_bricks
fill 370 72 495 370 75 495 minecraft:pink_terracotta
fill 370 72 497 370 73 497 minecraft:pink_terracotta
setblock 370 72 504 minecraft:red_nether_bricks
fill 330 73 464 330 76 464 minecraft:pink_terracotta
setblock 330 73 468 minecraft:red_nether_bricks
fill 330 73 469 330 76 469 minecraft:pink_terracotta
setblock 330 73 473 minecraft:red_nether_bricks
fill 330 73 474 330 76 474 minecraft:pink_terracotta
setblock 330 73 478 minecraft:red_nether_bricks
fill 330 73 479 330 76 479 minecraft:pink_terracotta
setblock 330 73 483 minecraft:red_nether_bricks
fill 330 73 484 330 76 484 minecraft:pink_terracotta
setblock 330 73 488 minecraft:red_nether_bricks
fill 330 73 489 330 76 489 minecraft:pink_terracotta
setblock 330 73 492 minecraft:pink_terracotta
setblock 330 73 493 minecraft:red_nether_bricks
fill 330 73 494 331 75 494 minecraft:pink_terracotta
setblock 330 73 498 minecraft:red_nether_bricks
fill 330 73 499 330 75 500 minecraft:pink_terracotta
setblock 330 73 503 minecraft:red_nether_bricks
fill 330 73 504 333 73 504 minecraft:pink_terracotta
setblock 331 73 467 minecraft:red_nether_bricks
fill 331 73 468 331 76 468 minecraft:pink_terracotta
setblock 331 73 472 minecraft:red_nether_bricks
fill 331 73 473 331 76 473 minecraft:pink_terracotta
setblock 331 73 477 minecraft:red_nether_bricks
setblock 331 73 483 minecraft:pink_terracotta
setblock 331 73 487 minecraft:red_nether_bricks
fill 331 73 488 331 75 488 minecraft:pink_terracotta
setblock 331 73 492 minecraft:red_nether_bricks
fill 331 73 493 331 76 493 minecraft:pink_terracotta
setblock 332 73 466 minecraft:red_nether_bricks
fill 332 73 467 333 74 467 minecraft:pink_terracotta
setblock 332 73 471 minecraft:red_nether_bricks
fill 332 73 472 332 76 472 minecraft:pink_terracotta
setblock 332 73 474 minecraft:light[level=12]
setblock 332 73 482 minecraft:light[level=12]
setblock 332 73 490 minecraft:light[level=12]
setblock 332 73 498 minecraft:light[level=12]
setblock 333 73 465 minecraft:red_nether_bricks
fill 333 73 466 333 76 466 minecraft:pink_terracotta
setblock 333 73 470 minecraft:red_nether_bricks
setblock 334 73 464 minecraft:red_nether_bricks
fill 334 73 465 334 76 465 minecraft:pink_terracotta
setblock 334 73 504 minecraft:red_nether_bricks
fill 335 73 464 335 76 464 minecraft:pink_terracotta
fill 335 73 504 335 75 504 minecraft:pink_terracotta
setblock 338 73 465 minecraft:red_nether_bricks
setblock 339 73 464 minecraft:red_nether_bricks
fill 339 73 465 342 73 465 minecraft:pink_terracotta
fill 339 73 466 339 76 466 minecraft:white_concrete
setblock 339 73 504 minecraft:red_nether_bricks
fill 340 73 464 340 76 464 minecraft:pink_terracotta
setblock 340 73 466 minecraft:light[level=12]
setblock 340 73 474 minecraft:light[level=12]
setblock 340 73 482 minecraft:light[level=12]
setblock 340 73 490 minecraft:light[level=12]
setblock 340 73 498 minecraft:light[level=12]
fill 340 73 504 340 76 504 minecraft:pink_terracotta
setblock 343 73 465 minecraft:red_nether_bricks
setblock 344 73 464 minecraft:red_nether_bricks
fill 344 73 465 344 75 466 minecraft:pink_terracotta
setblock 344 73 504 minecraft:red_nether_bricks
fill 345 73 464 345 76 464 minecraft:pink_terracotta
setblock 345 73 503 minecraft:red_nether_bricks
fill 345 73 504 345 76 504 minecraft:pink_terracotta
fill 346 73 503 346 76 503 minecraft:pink_terracotta
setblock 347 73 466 minecraft:red_nether_bricks
setblock 348 73 465 minecraft:red_nether_bricks
fill 348 73 466 348 75 466 minecraft:pink_terracotta
setblock 348 73 474 minecraft:light[level=12]
setblock 348 73 482 minecraft:light[level=12]
setblock 348 73 490 minecraft:light[level=12]
setblock 348 73 498 minecraft:light[level=12]
fill 348 73 502 348 75 502 minecraft:pink_terracotta
setblock 349 73 464 minecraft:red_nether_bricks
fill 349 73 465 349 76 465 minecraft:pink_terracotta
setblock 349 73 504 minecraft:red_nether_bricks
fill 350 73 464 350 76 464 minecraft:pink_terracotta
setblock 350 73 503 minecraft:red_nether_bricks
fill 350 73 504 350 76 504 minecraft:pink_terracotta
fill 351 73 503 351 75 503 minecraft:pink_terracotta
setblock 353 73 465 minecraft:red_nether_bricks
setblock 354 73 464 minecraft:red_nether_bricks
setblock 354 73 504 minecraft:red_nether_bricks
setblock 355 73 464 minecraft:pink_terracotta
setblock 355 73 504 minecraft:pink_terracotta
setblock 356 73 466 minecraft:light[level=12]
setblock 356 73 474 minecraft:light[level=12]
setblock 356 73 482 minecraft:light[level=12]
setblock 356 73 490 minecraft:light[level=12]
setblock 356 73 498 minecraft:light[level=12]
setblock 363 73 464 minecraft:pink_terracotta
setblock 364 73 464 minecraft:red_nether_bricks
setblock 364 73 466 minecraft:light[level=12]
setblock 364 73 474 minecraft:light[level=12]
setblock 364 73 482 minecraft:light[level=12]
setblock 364 73 490 minecraft:light[level=12]
setblock 364 73 498 minecraft:light[level=12]
fill 365 73 464 365 76 464 minecraft:pink_terracotta
setblock 366 73 466 minecraft:pink_terracotta
setblock 367 73 466 minecraft:red_nether_bricks
fill 367 73 469 367 73 470 minecraft:pink_terracotta
setblock 367 73 485 minecraft:pink_terracotta
setblock 367 73 486 minecraft:red_nether_bricks
fill 367 73 487 367 75 487 minecraft:pink_terracotta
setblock 367 73 490 minecraft:pink_terracotta
setblock 367 73 491 minecraft:red_nether_bricks
setblock 368 73 465 minecraft:red_nether_bricks
fill 368 73 466 368 73 469 minecraft:pink_terracotta
setblock 368 73 470 minecraft:red_nether_bricks
fill 368 73 471 368 73 474 minecraft:pink_terracotta
setblock 368 73 475 minecraft:red_nether_bricks
fill 368 73 476 368 73 479 minecraft:pink_terracotta
setblock 368 73 480 minecraft:red_nether_bricks
fill 368 73 481 368 76 481 minecraft:pink_terracotta
setblock 368 73 485 minecraft:red_nether_bricks
fill 368 73 486 368 76 486 minecraft:pink_terracotta
setblock 368 73 489 minecraft:pink_terracotta
setblock 368 73 490 minecraft:red_nether_bricks
fill 368 73 491 368 76 491 minecraft:pink_terracotta
fill 368 73 493 368 74 493 minecraft:pink_terracotta
setblock 369 73 464 minecraft:red_nether_bricks
fill 369 73 465 369 76 465 minecraft:pink_terracotta
setblock 369 73 469 minecraft:red_nether_bricks
fill 369 73 470 369 76 470 minecraft:pink_terracotta
fill 369 73 472 369 73 473 minecraft:pink_terracotta
setblock 369 73 474 minecraft:red_nether_bricks
fill 369 73 475 369 76 475 minecraft:pink_terracotta
setblock 369 73 479 minecraft:red_nether_bricks
fill 369 73 480 369 76 480 minecraft:pink_terracotta
setblock 369 73 484 minecraft:red_nether_bricks
fill 369 73 485 369 76 485 minecraft:pink_terracotta
setblock 369 73 489 minecraft:red_nether_bricks
fill 369 73 490 369 76 490 minecraft:pink_terracotta
setblock 369 73 494 minecraft:red_nether_bricks
fill 369 73 495 369 75 496 minecraft:pink_terracotta
setblock 369 73 504 minecraft:red_nether_bricks
fill 370 73 464 370 76 464 minecraft:pink_terracotta
setblock 370 73 468 minecraft:red_nether_bricks
fill 370 73 469 370 76 469 minecraft:pink_terracotta
setblock 370 73 473 minecraft:red_nether_bricks
fill 370 73 474 370 76 474 minecraft:pink_terracotta
setblock 370 73 478 minecraft:red_nether_bricks
fill 370 73 479 370 76 479 minecraft:pink_terracotta
setblock 370 73 483 minecraft:red_nether_bricks
fill 370 73 484 370 76 484 minecraft:pink_terracotta
setblock 370 73 488 minecraft:red_nether_bricks
fill 370 73 489 370 76 489 minecraft:pink_terracotta
setblock 370 73 493 minecraft:red_nether_bricks
fill 370 73 494 370 76 494 minecraft:pink_terracotta
setblock 370 73 498 minecraft:red_nether_bricks
setblock 370 73 503 minecraft:red_nether_bricks
fill 370 73 504 370 75 504 minecraft:pink_terracotta
setblock 330 74 467 minecraft:red_nether_bricks
fill 330 74 468 330 77 468 minecraft:pink_terracotta
setblock 330 74 472 minecraft:red_nether_bricks
fill 330 74 473 330 77 473 minecraft:pink_terracotta
setblock 330 74 477 minecraft:red_nether_bricks
fill 330 74 478 330 77 478 minecraft:pink_terracotta
setblock 330 74 482 minecraft:red_nether_bricks
fill 330 74 483 330 76 483 minecraft:pink_terracotta
setblock 330 74 487 minecraft:red_nether_bricks
fill 330 74 488 330 77 488 minecraft:pink_terracotta
setblock 330 74 491 minecraft:pink_terracotta
setblock 330 74 492 minecraft:red_nether_bricks
fill 330 74 493 330 77 493 minecraft:pink_terracotta
fill 330 74 495 330 74 496 minecraft:pink_terracotta
setblock 330 74 497 minecraft:red_nether_bricks
fill 330 74 498 330 77 498 minecraft:pink_terracotta
setblock 330 74 502 minecraft:red_nether_bricks
fill 330 74 503 330 76 504 minecraft:pink_terracotta
setblock 331 74 466 minecraft:red_nether_bricks
fill 331 74 467 331 77 467 minecraft:pink_terracotta
setblock 331 74 471 minecraft:red_nether_bricks
fill 331 74 472 331 77 472 minecraft:pink_terracotta
setblock 331 74 476 minecraft:red_nether_bricks
fill 331 74 477 331 76 477 minecraft:pink_terracotta
setblock 331 74 486 minecraft:red_nether_bricks
fill 331 74 487 331 75 487 minecraft:pink_terracotta
setblock 331 74 491 minecraft:red_nether_bricks
fill 331 74 492 331 77 492 minecraft:pink_terracotta
setblock 331 74 495 minecraft:pink_terracotta
fill 331 74 504 332 74 504 minecraft:pink_terracotta
setblock 332 74 465 minecraft:red_nether_bricks
fill 332 74 466 332 77 466 minecraft:pink_terracotta
setblock 332 74 469 minecraft:pink_terracotta
setblock 332 74 470 minecraft:red_nether_bricks
fill 332 74 471 332 77 471 minecraft:pink_terracotta
setblock 332 74 474 minecraft:pink_terracotta
setblock 333 74 464 minecraft:red_nether_bricks
fill 333 74 465 333 77 465 minecraft:pink_terracotta
setblock 333 74 469 minecraft:red_nether_bricks
setblock 333 74 470 minecraft:pink_terracotta
setblock 333 74 504 minecraft:red_nether_bricks
fill 334 74 464 334 77 464 minecraft:pink_terracotta
fill 334 74 504 334 76 504 minecraft:pink_terracotta
setblock 336 74 466 minecraft:red_nether_bricks
setblock 337 74 465 minecraft:red_nether_bricks
setblock 338 74 464 minecraft:red_nether_bricks
fill 338 74 465 341 74 465 minecraft:pink_terracotta
fill 338 74 466 338 75 466 minecraft:white_concrete
setblock 338 74 504 minecraft:red_nether_bricks
fill 339 74 464 339 77 464 minecraft:pink_terracotta
fill 339 74 467 339 75 467 minecraft:red_concrete
fill 339 74 504 339 77 504 minecraft:pink_terracotta
fill 340 74 466 340 75 466 minecraft:white_concrete
setblock 342 74 465 minecraft:red_nether_bricks
setblock 343 74 464 minecraft:red_nether_bricks
fill 343 74 465 343 77 465 minecraft:pink_terracotta
setblock 343 74 503 minecraft:pink_terracotta
setblock 343 74 504 minecraft:red_nether_bricks
fill 344 74 464 344 77 464 minecraft:pink_terracotta
setblock 344 74 503 minecraft:red_nether_bricks
fill 344 74 504 344 77 504 minecraft:pink_terracotta
fill 345 74 503 345 77 503 minecraft:pink_terracotta
setblock 346 74 465 minecraft:pink_terracotta
setblock 346 74 466 minecraft:red_nether_bricks
setblock 347 74 465 minecraft:red_nether_bricks
fill 347 74 466 347 76 466 minecraft:pink_terracotta
fill 347 74 502 347 76 502 minecraft:pink_terracotta
setblock 348 74 464 minecraft:red_nether_bricks
fill 348 74 465 348 77 465 minecraft:pink_terracotta
setblock 348 74 504 minecraft:red_nether_bricks
fill 349 74 464 349 77 464 minecraft:pink_terracotta
setblock 349 74 503 minecraft:red_nether_bricks
fill 349 74 504 349 77 504 minecraft:pink_terracotta
setblock 350 74 466 minecraft:pink_terracotta
fill 350 74 503 350 76 503 minecraft:pink_terracotta
setblock 352 74 465 minecraft:red_nether_bricks
setblock 353 74 464 minecraft:red_nether_bricks
setblock 353 74 504 minecraft:red_nether_bricks
setblock 354 74 464 minecraft:pink_terracotta
setblock 354 74 504 minecraft:pink_terracotta
setblock 359 74 464 minecraft:white_concrete
setblock 360 74 504 minecraft:white_concrete
setblock 363 74 464 minecraft:red_nether_bricks
fill 364 74 464 364 76 465 minecraft:pink_terracotta
setblock 366 74 466 minecraft:red_nether_bricks
fill 366 74 504 366 75 504 minecraft:pink_terracotta
setblock 367 74 465 minecraft:red_nether_bricks
fill 367 74 466 368 76 466 minecraft:pink_terracotta
fill 367 74 468 367 74 469 minecraft:pink_terracotta
setblock 367 74 470 minecraft:red_nether_bricks
fill 367 74 471 368 74 473 minecraft:pink_terracotta
setblock 367 74 486 minecraft:pink_terracotta
setblock 367 74 490 minecraft:red_nether_bricks
fill 367 74 491 367 76 491 minecraft:pink_terracotta
setblock 368 74 464 minecraft:red_nether_bricks
fill 368 74 465 368 77 465 minecraft:pink_terracotta
fill 368 74 467 368 74 468 minecraft:pink_terracotta
setblock 368 74 469 minecraft:red_nether_bricks
fill 368 74 470 368 77 470 minecraft:pink_terracotta
setblock 368 74 474 minecraft:red_nether_bricks
fill 368 74 475 368 74 478 minecraft:pink_terracotta
setblock 368 74 479 minecraft:red_nether_bricks
fill 368 74 480 368 76 480 minecraft:pink_terracotta
setblock 368 74 484 minecraft:red_nether_bricks
fill 368 74 485 368 76 485 minecraft:pink_terracotta
setblock 368 74 489 minecraft:red_nether_bricks
fill 368 74 490 368 77 490 minecraft:pink_terracotta
setblock 368 74 494 minecraft:red_nether_bricks
setblock 368 74 504 minecraft:red_nether_bricks
fill 369 74 464 369 77 464 minecraft:pink_terracotta
setblock 369 74 468 minecraft:red_nether_bricks
fill 369 74 469 369 77 469 minecraft:pink_terracotta
setblock 369 74 472 minecraft:pink_terracotta
setblock 369 74 473 minecraft:red_nether_bricks
fill 369 74 474 369 77 474 minecraft:pink_terracotta
setblock 369 74 478 minecraft:red_nether_bricks
fill 369 74 479 369 77 479 minecraft:pink_terracotta
setblock 369 74 483 minecraft:red_nether_bricks
fill 369 74 484 369 77 484 minecraft:pink_terracotta
setblock 369 74 488 minecraft:red_nether_bricks
fill 369 74 489 369 77 489 minecraft:pink_terracotta
setblock 369 74 493 minecraft:red_nether_bricks
fill 369 74 494 369 77 494 minecraft:pink_terracotta
fill 369 74 504 369 76 504 minecraft:pink_terracotta
setblock 370 74 467 minecraft:red_nether_bricks
fill 370 74 468 370 77 468 minecraft:pink_terracotta
setblock 370 74 472 minecraft:red_nether_bricks
fill 370 74 473 370 77 473 minecraft:pink_terracotta
setblock 370 74 477 minecraft:red_nether_bricks
fill 370 74 478 370 77 478 minecraft:pink_terracotta
setblock 370 74 482 minecraft:red_nether_bricks
fill 370 74 483 370 77 483 minecraft:pink_terracotta
setblock 370 74 487 minecraft:red_nether_bricks
fill 370 74 488 370 77 488 minecraft:pink_terracotta
setblock 370 74 492 minecraft:red_nether_bricks
fill 370 74 493 370 77 493 minecraft:pink_terracotta
setblock 370 74 497 minecraft:red_nether_bricks
fill 370 74 498 370 76 499 minecraft:pink_terracotta
fill 370 74 503 370 75 503 minecraft:pink_terracotta
setblock 330 75 466 minecraft:red_nether_bricks
fill 330 75 467 330 78 467 minecraft:pink_terracotta
setblock 330 75 471 minecraft:red_nether_bricks
fill 330 75 472 330 78 472 minecraft:pink_terracotta
setblock 330 75 476 minecraft:red_nether_bricks
fill 330 75 477 330 78 477 minecraft:pink_terracotta
setblock 330 75 481 minecraft:red_nether_bricks
fill 330 75 482 330 76 482 minecraft:pink_terracotta
setblock 330 75 486 minecraft:red_nether_bricks
fill 330 75 487 330 77 487 minecraft:pink_terracotta
setblock 330 75 491 minecraft:red_nether_bricks
fill 330 75 492 330 78 492 minecraft:pink_terracotta
setblock 330 75 495 minecraft:pink_terracotta
setblock 330 75 496 minecraft:red_nether_bricks
fill 330 75 497 330 78 497 minecraft:pink_terracotta
setblock 330 75 501 minecraft:red_nether_bricks
fill 330 75 502 330 78 502 minecraft:pink_terracotta
setblock 331 75 465 minecraft:red_nether_bricks
fill 331 75 466 331 78 466 minecraft:pink_terracotta
setblock 331 75 470 minecraft:red_nether_bricks
fill 331 75 471 331 78 471 minecraft:pink_terracotta
setblock 331 75 475 minecraft:red_nether_bricks
fill 331 75 476 331 78 476 minecraft:pink_terracotta
setblock 331 75 490 minecraft:red_nether_bricks
fill 331 75 491 331 77 491 minecraft:pink_terracotta
setblock 331 75 495 minecraft:red_nether_bricks
setblock 331 75 504 minecraft:pink_terracotta
setblock 332 75 464 minecraft:red_nether_bricks
fill 332 75 465 332 78 465 minecraft:pink_terracotta
fill 332 75 467 332 76 467 minecraft:pink_terracotta
setblock 332 75 469 minecraft:red_nether_bricks
fill 332 75 470 332 78 470 minecraft:pink_terracotta
setblock 332 75 474 minecraft:red_nether_bricks
setblock 332 75 504 minecraft:red_nether_bricks
fill 333 75 464 333 78 464 minecraft:pink_terracotta
setblock 333 75 468 minecraft:red_nether_bricks
setblock 333 75 469 minecraft:pink_terracotta
fill 333 75 504 333 77 504 minecraft:pink_terracotta
setblock 335 75 466 minecraft:red_nether_bricks
setblock 336 75 465 minecraft:red_nether_bricks
setblock 337 75 464 minecraft:red_nether_bricks
fill 337 75 465 340 75 465 minecraft:pink_terracotta
setblock 337 75 504 minecraft:red_nether_bricks
fill 338 75 464 338 77 464 minecraft:pink_terracotta
fill 338 75 504 338 76 504 minecraft:pink_terracotta
setblock 341 75 465 minecraft:red_nether_bricks
setblock 342 75 464 minecraft:red_nether_bricks
fill 342 75 465 342 77 465 minecraft:pink_terracotta
setblock 342 75 504 minecraft:red_nether_bricks
fill 343 75 464 343 78 464 minecraft:pink_terracotta
setblock 343 75 503 minecraft:red_nether_bricks
fill 343 75 504 343 78 504 minecraft:pink_terracotta
fill 344 75 503 344 78 503 minecraft:pink_terracotta
setblock 345 75 465 minecraft:pink_terracotta
setblock 345 75 466 minecraft:red_nether_bricks
setblock 346 75 465 minecraft:red_nether_bricks
fill 346 75 466 346 76 466 minecraft:pink_terracotta
fill 346 75 502 346 76 502 minecraft:pink_terracotta
setblock 347 75 464 minecraft:red_nether_bricks
fill 347 75 465 347 77 465 minecraft:pink_terracotta
setblock 347 75 504 minecraft:red_nether_bricks
fill 348 75 464 348 78 464 minecraft:pink_terracotta
setblock 348 75 503 minecraft:red_nether_bricks
fill 348 75 504 348 78 504 minecraft:pink_terracotta
fill 349 75 503 349 77 503 minecraft:pink_terracotta
setblock 351 75 465 minecraft:red_nether_bricks
setblock 352 75 464 minecraft:red_nether_bricks
setblock 352 75 504 minecraft:red_nether_bricks
setblock 353 75 464 minecraft:pink_terracotta
setblock 353 75 504 minecraft:pink_terracotta
fill 363 75 464 363 78 464 minecraft:pink_terracotta
setblock 365 75 466 minecraft:red_nether_bricks
setblock 366 75 465 minecraft:red_nether_bricks
fill 366 75 466 366 77 466 minecraft:pink_terracotta
setblock 367 75 464 minecraft:red_nether_bricks
fill 367 75 465 367 78 465 minecraft:pink_terracotta
fill 367 75 467 367 75 468 minecraft:pink_terracotta
setblock 367 75 469 minecraft:red_nether_bricks
fill 367 75 470 367 75 473 minecraft:pink_terracotta
setblock 367 75 474 minecraft:red_nether_bricks
fill 367 75 475 368 77 475 minecraft:pink_terracotta
setblock 367 75 488 minecraft:pink_terracotta
setblock 367 75 489 minecraft:red_nether_bricks
fill 367 75 490 367 76 490 minecraft:pink_terracotta
fill 367 75 492 367 76 492 minecraft:pink_terracotta
setblock 367 75 504 minecraft:red_nether_bricks
fill 368 75 464 368 78 464 minecraft:pink_terracotta
setblock 368 75 467 minecraft:pink_terracotta
setblock 368 75 468 minecraft:red_nether_bricks
fill 368 75 469 368 78 469 minecraft:pink_terracotta
fill 368 75 471 368 75 472 minecraft:pink_terracotta
setblock 368 75 473 minecraft:red_nether_bricks
fill 368 75 474 368 78 474 minecraft:pink_terracotta
fill 368 75 476 368 75 477 minecraft:pink_terracotta
setblock 368 75 478 minecraft:red_nether_bricks
fill 368 75 479 368 78 479 minecraft:pink_terracotta
setblock 368 75 483 minecraft:red_nether_bricks
fill 368 75 484 368 76 484 minecraft:pink_terracotta
setblock 368 75 488 minecraft:red_nether_bricks
fill 368 75 489 368 77 489 minecraft:pink_terracotta
setblock 368 75 493 minecraft:red_nether_bricks
fill 368 75 494 368 76 495 minecraft:pink_terracotta
fill 368 75 504 368 76 504 minecraft:pink_terracotta
setblock 369 75 467 minecraft:red_nether_bricks
fill 369 75 468 369 78 468 minecraft:pink_terracotta
setblock 369 75 472 minecraft:red_nether_bricks
fill 369 75 473 369 78 473 minecraft:pink_terracotta
setblock 369 75 477 minecraft:red_nether_bricks
fill 369 75 478 369 78 478 minecraft:pink_terracotta
setblock 369 75 482 minecraft:red_nether_bricks
fill 369 75 483 369 77 483 minecraft:pink_terracotta
setblock 369 75 487 minecraft:red_nether_bricks
fill 369 75 488 369 78 488 minecraft:pink_terracotta
setblock 369 75 492 minecraft:red_nether_bricks
fill 369 75 493 369 78 493 minecraft:pink_terracotta
setblock 369 75 497 minecraft:red_nether_bricks
setblock 370 75 466 minecraft:red_nether_bricks
fill 370 75 467 370 78 467 minecraft:pink_terracotta
setblock 370 75 471 minecraft:red_nether_bricks
fill 370 75 472 370 78 472 minecraft:pink_terracotta
setblock 370 75 476 minecraft:red_nether_bricks
fill 370 75 477 370 78 477 minecraft:pink_terracotta
setblock 370 75 481 minecraft:red_nether_bricks
fill 370 75 482 370 78 482 minecraft:pink_terracotta
setblock 370 75 486 minecraft:red_nether_bricks
fill 370 75 487 370 78 487 minecraft:pink_terracotta
setblock 370 75 491 minecraft:red_nether_bricks
fill 370 75 492 370 78 492 minecraft:pink_terracotta
setblock 370 75 496 minecraft:red_nether_bricks
fill 370 75 497 370 78 497 minecraft:pink_terracotta
setblock 370 75 500 minecraft:pink_terracotta
setblock 330 76 465 minecraft:red_nether_bricks
fill 330 76 466 330 79 466 minecraft:pink_terracotta
setblock 330 76 470 minecraft:red_nether_bricks
fill 330 76 471 330 79 471 minecraft:pink_terracotta
setblock 330 76 475 minecraft:red_nether_bricks
fill 330 76 476 330 79 476 minecraft:pink_terracotta
setblock 330 76 480 minecraft:red_nether_bricks
setblock 330 76 481 minecraft:pink_terracotta
setblock 330 76 485 minecraft:red_nether_bricks
fill 330 76 486 330 77 486 minecraft:pink_terracotta
setblock 330 76 490 minecraft:red_nether_bricks
fill 330 76 491 330 79 491 minecraft:pink_terracotta
setblock 330 76 494 minecraft:pink_terracotta
setblock 330 76 495 minecraft:red_nether_bricks
fill 330 76 496 331 76 496 minecraft:pink_terracotta
setblock 330 76 499 minecraft:pink_terracotta
setblock 330 76 500 minecraft:red_nether_bricks
fill 330 76 501 330 79 501 minecraft:pink_terracotta
setblock 331 76 464 minecraft:red_nether_bricks
fill 331 76 465 331 78 465 minecraft:pink_terracotta
setblock 331 76 469 minecraft:red_nether_bricks
fill 331 76 470 331 79 470 minecraft:pink_terracotta
setblock 331 76 474 minecraft:red_nether_bricks
fill 331 76 475 331 79 475 minecraft:pink_terracotta
setblock 331 76 489 minecraft:red_nether_bricks
setblock 331 76 490 minecraft:pink_terracotta
setblock 331 76 494 minecraft:red_nether_bricks
fill 331 76 495 331 77 495 minecraft:pink_terracotta
setblock 331 76 504 minecraft:red_nether_bricks
fill 332 76 464 332 79 464 minecraft:pink_terracotta
setblock 332 76 468 minecraft:red_nether_bricks
fill 332 76 469 332 78 469 minecraft:pink_terracotta
setblock 332 76 473 minecraft:red_nether_bricks
fill 332 76 504 332 77 504 minecraft:pink_terracotta
setblock 335 76 465 minecraft:red_nether_bricks
setblock 336 76 464 minecraft:red_nether_bricks
setblock 336 76 465 minecraft:pink_terracotta
fill 337 76 464 337 77 464 minecraft:pink_terracotta
fill 338 76 465 339 76 465 minecraft:white_concrete
setblock 340 76 465 minecraft:red_nether_bricks
setblock 341 76 464 minecraft:red_nether_bricks
setblock 341 76 465 minecraft:pink_terracotta
setblock 341 76 504 minecraft:red_nether_bricks
fill 342 76 464 342 79 464 minecraft:pink_terracotta
setblock 342 76 503 minecraft:red_nether_bricks
fill 342 76 504 342 79 504 minecraft:pink_terracotta
fill 343 76 503 343 79 503 minecraft:pink_terracotta
setblock 344 76 465 minecraft:pink_terracotta
setblock 345 76 465 minecraft:red_nether_bricks
setblock 345 76 466 minecraft:pink_terracotta
setblock 346 76 464 minecraft:red_nether_bricks
fill 346 76 465 346 77 465 minecraft:pink_terracotta
setblock 346 76 504 minecraft:red_nether_bricks
fill 347 76 464 347 79 464 minecraft:pink_terracotta
setblock 347 76 503 minecraft:red_nether_bricks
fill 347 76 504 347 79 504 minecraft:pink_terracotta
fill 348 76 503 348 78 503 minecraft:pink_terracotta
setblock 350 76 465 minecraft:red_nether_bricks
setblock 351 76 464 minecraft:red_nether_bricks
setblock 351 76 504 minecraft:red_nether_bricks
setblock 352 76 464 minecraft:pink_terracotta
setblock 352 76 504 minecraft:pink_terracotta
setblock 353 76 504 minecraft:white_concrete
setblock 365 76 465 minecraft:red_nether_bricks
setblock 365 76 466 minecraft:pink_terracotta
setblock 366 76 464 minecraft:red_nether_bricks
fill 366 76 465 366 79 465 minecraft:pink_terracotta
fill 367 76 464 367 79 464 minecraft:pink_terracotta
setblock 367 76 467 minecraft:pink_terracotta
setblock 367 76 468 minecraft:red_nether_bricks
fill 367 76 469 367 76 472 minecraft:pink_terracotta
setblock 367 76 473 minecraft:red_nether_bricks
fill 367 76 474 367 79 474 minecraft:pink_terracotta
fill 367 76 476 368 76 476 minecraft:pink_terracotta
setblock 367 76 488 minecraft:red_nether_bricks
setblock 367 76 489 minecraft:pink_terracotta
setblock 367 76 504 minecraft:pink_terracotta
setblock 368 76 467 minecraft:red_nether_bricks
fill 368 76 468 368 79 468 minecraft:pink_terracotta
setblock 368 76 471 minecraft:pink_terracotta
setblock 368 76 472 minecraft:red_nether_bricks
fill 368 76 473 368 79 473 minecraft:pink_terracotta
setblock 368 76 477 minecraft:red_nether_bricks
fill 368 76 478 368 79 478 minecraft:pink_terracotta
setblock 368 76 482 minecraft:red_nether_bricks
setblock 368 76 483 minecraft:pink_terracotta
setblock 368 76 487 minecraft:red_nether_bricks
fill 368 76 488 368 77 488 minecraft:pink_terracotta
setblock 368 76 492 minecraft:red_nether_bricks
fill 368 76 493 368 78 493 minecraft:pink_terracotta
setblock 369 76 466 minecraft:red_nether_bricks
fill 369 76 467 369 79 467 minecraft:pink_terracotta
setblock 369 76 471 minecraft:red_nether_bricks
fill 369 76 472 369 79 472 minecraft:pink_terracotta
setblock 369 76 476 minecraft:red_nether_bricks
fill 369 76 477 369 79 477 minecraft:pink_terracotta
setblock 369 76 481 minecraft:red_nether_bricks
fill 369 76 482 369 78 482 minecraft:pink_terracotta
setblock 369 76 486 minecraft:red_nether_bricks
fill 369 76 487 369 78 487 minecraft:pink_terracotta
setblock 369 76 491 minecraft:red_nether_bricks
fill 369 76 492 369 79 492 minecraft:pink_terracotta
setblock 369 76 495 minecraft:pink_terracotta
setblock 369 76 496 minecraft:red_nether_bricks
fill 369 76 497 369 77 497 minecraft:pink_terracotta
setblock 370 76 465 minecraft:red_nether_bricks
fill 370 76 466 370 79 466 minecraft:pink_terracotta
setblock 370 76 470 minecraft:red_nether_bricks
fill 370 76 471 370 79 471 minecraft:pink_terracotta
setblock 370 76 475 minecraft:red_nether_bricks
fill 370 76 476 370 79 476 minecraft:pink_terracotta
setblock 370 76 480 minecraft:red_nether_bricks
fill 370 76 481 370 79 481 minecraft:pink_terracotta
setblock 370 76 485 minecraft:red_nether_bricks
fill 370 76 486 370 78 486 minecraft:pink_terracotta
setblock 370 76 490 minecraft:red_nether_bricks
fill 370 76 491 370 79 491 minecraft:pink_terracotta
setblock 370 76 495 minecraft:red_nether_bricks
fill 370 76 496 370 79 496 minecraft:pink_terracotta
setblock 330 77 464 minecraft:red_nether_bricks
fill 330 77 465 330 80 465 minecraft:pink_terracotta
setblock 330 77 469 minecraft:red_nether_bricks
fill 330 77 470 330 80 470 minecraft:pink_terracotta
setblock 330 77 474 minecraft:red_nether_bricks
fill 330 77 475 330 80 475 minecraft:pink_terracotta
setblock 330 77 479 minecraft:red_nether_bricks
setblock 330 77 480 minecraft:pink_terracotta
setblock 330 77 489 minecraft:red_nether_bricks
fill 330 77 490 330 79 490 minecraft:pink_terracotta
setblock 330 77 494 minecraft:red_nether_bricks
fill 330 77 495 330 79 496 minecraft:pink_terracotta
setblock 330 77 499 minecraft:red_nether_bricks
fill 330 77 500 330 80 500 minecraft:pink_terracotta
setblock 330 77 503 minecraft:pink_terracotta
setblock 330 77 504 minecraft:red_nether_bricks
fill 331 77 464 331 80 464 minecraft:pink_terracotta
setblock 331 77 468 minecraft:red_nether_bricks
fill 331 77 469 331 80 469 minecraft:pink_terracotta
setblock 331 77 473 minecraft:red_nether_bricks
fill 331 77 474 331 80 474 minecraft:pink_terracotta
setblock 331 77 493 minecraft:red_nether_bricks
setblock 331 77 494 minecraft:pink_terracotta
fill 331 77 504 331 78 504 minecraft:pink_terracotta
setblock 332 77 467 minecraft:red_nether_bricks
setblock 332 77 468 minecraft:pink_terracotta
setblock 332 77 472 minecraft:red_nether_bricks
setblock 332 77 473 minecraft:pink_terracotta
setblock 334 77 465 minecraft:red_nether_bricks
setblock 334 77 504 minecraft:white_concrete
setblock 335 77 464 minecraft:red_nether_bricks
setblock 336 77 464 minecraft:pink_terracotta
setblock 340 77 464 minecraft:red_nether_bricks
setblock 340 77 504 minecraft:red_nether_bricks
fill 341 77 464 341 79 464 minecraft:pink_terracotta
fill 341 77 504 341 80 504 minecraft:pink_terracotta
fill 342 77 503 342 80 503 minecraft:pink_terracotta
setblock 344 77 465 minecraft:red_nether_bricks
setblock 345 77 464 minecraft:red_nether_bricks
fill 345 77 465 345 78 465 minecraft:pink_terracotta
setblock 345 77 504 minecraft:red_nether_bricks
fill 346 77 464 346 79 464 minecraft:pink_terracotta
setblock 346 77 503 minecraft:red_nether_bricks
fill 346 77 504 346 80 504 minecraft:pink_terracotta
fill 347 77 503 347 79 503 minecraft:pink_terracotta
setblock 350 77 464 minecraft:red_nether_bricks
setblock 350 77 504 minecraft:red_nether_bricks
setblock 351 77 504 minecraft:pink_terracotta
setblock 359 77 504 minecraft:white_concrete
setblock 360 77 464 minecraft:white_concrete
setblock 364 77 464 minecraft:pink_terracotta
setblock 364 77 465 minecraft:red_nether_bricks
setblock 365 77 464 minecraft:red_nether_bricks
fill 365 77 465 365 78 465 minecraft:pink_terracotta
fill 366 77 464 366 80 464 minecraft:pink_terracotta
setblock 367 77 466 minecraft:pink_terracotta
fill 367 77 468 367 77 471 minecraft:pink_terracotta
setblock 367 77 472 minecraft:red_nether_bricks
fill 367 77 473 367 80 473 minecraft:pink_terracotta
setblock 367 77 476 minecraft:pink_terracotta
setblock 368 77 466 minecraft:red_nether_bricks
fill 368 77 467 368 78 467 minecraft:pink_terracotta
setblock 368 77 471 minecraft:red_nether_bricks
fill 368 77 472 368 80 472 minecraft:pink_terracotta
setblock 368 77 476 minecraft:red_nether_bricks
fill 368 77 477 368 80 477 minecraft:pink_terracotta
setblock 368 77 486 minecraft:red_nether_bricks
setblock 368 77 487 minecraft:pink_terracotta
setblock 368 77 491 minecraft:red_nether_bricks
fill 368 77 492 368 78 492 minecraft:pink_terracotta
setblock 368 77 494 minecraft:pink_terracotta
setblock 369 77 465 minecraft:red_nether_bricks
fill 369 77 466 369 79 466 minecraft:pink_terracotta
setblock 369 77 470 minecraft:red_nether_bricks
fill 369 77 471 369 80 471 minecraft:pink_terracotta
setblock 369 77 475 minecraft:red_nether_bricks
fill 369 77 476 369 80 476 minecraft:pink_terracotta
setblock 369 77 480 minecraft:red_nether_bricks
fill 369 77 481 369 78 481 minecraft:pink_terracotta
setblock 369 77 485 minecraft:red_nether_bricks
fill 369 77 486 369 78 486 minecraft:pink_terracotta
setblock 369 77 490 minecraft:red_nether_bricks
fill 369 77 491 369 79 491 minecraft:pink_terracotta
setblock 369 77 495 minecraft:red_nether_bricks
fill 369 77 496 369 78 496 minecraft:pink_terracotta
setblock 370 77 464 minecraft:red_nether_bricks
fill 370 77 465 370 80 465 minecraft:pink_terracotta
setblock 370 77 469 minecraft:red_nether_bricks
fill 370 77 470 370 80 470 minecraft:pink_terracotta
setblock 370 77 474 minecraft:red_nether_bricks
fill 370 77 475 370 80 475 minecraft:pink_terracotta
setblock 370 77 479 minecraft:red_nether_bricks
fill 370 77 480 370 80 480 minecraft:pink_terracotta
setblock 370 77 484 minecraft:red_nether_bricks
fill 370 77 485 370 78 485 minecraft:pink_terracotta
setblock 370 77 489 minecraft:red_nether_bricks
fill 370 77 490 370 79 490 minecraft:pink_terracotta
setblock 370 77 494 minecraft:red_nether_bricks
fill 370 77 495 370 80 495 minecraft:pink_terracotta
setblock 370 77 498 minecraft:pink_terracotta
setblock 370 77 499 minecraft:red_nether_bricks
fill 330 78 464 330 80 464 minecraft:pink_terracotta
setblock 330 78 468 minecraft:red_nether_bricks
fill 330 78 469 330 81 469 minecraft:pink_terracotta
setblock 330 78 473 minecraft:red_nether_bricks
fill 330 78 474 330 81 474 minecraft:pink_terracotta
setblock 330 78 478 minecraft:red_nether_bricks
setblock 330 78 479 minecraft:pink_terracotta
setblock 330 78 488 minecraft:red_nether_bricks
setblock 330 78 489 minecraft:pink_terracotta
setblock 330 78 493 minecraft:red_nether_bricks
fill 330 78 494 330 81 494 minecraft:pink_terracotta
setblock 330 78 498 minecraft:red_nether_bricks
fill 330 78 499 330 81 499 minecraft:pink_terracotta
setblock 330 78 503 minecraft:red_nether_bricks
setblock 330 78 504 minecraft:pink_terracotta
setblock 331 78 467 minecraft:red_nether_bricks
fill 331 78 468 331 79 468 minecraft:pink_terracotta
setblock 331 78 472 minecraft:red_nether_bricks
fill 331 78 473 331 80 473 minecraft:pink_terracotta
setblock 332 78 471 minecraft:red_nether_bricks
fill 333 78 465 335 81 465 minecraft:white_concrete
setblock 334 78 464 minecraft:red_nether_bricks
fill 334 78 466 334 81 466 minecraft:white_concrete
setblock 335 78 464 minecraft:pink_terracotta
fill 336 78 464 336 81 464 minecraft:white_concrete
setblock 339 78 464 minecraft:red_nether_bricks
setblock 339 78 504 minecraft:red_nether_bricks
setblock 340 78 464 minecraft:pink_terracotta
fill 340 78 504 340 81 504 minecraft:pink_terracotta
setblock 344 78 464 minecraft:red_nether_bricks
setblock 344 78 465 minecraft:pink_terracotta
fill 344 78 470 345 79 471 minecraft:red_concrete
setblock 344 78 504 minecraft:red_nether_bricks
fill 345 78 464 345 80 464 minecraft:pink_terracotta
setblock 345 78 503 minecraft:red_nether_bricks
fill 345 78 504 345 81 504 minecraft:pink_terracotta
fill 346 78 503 346 81 503 minecraft:pink_terracotta
setblock 349 78 464 minecraft:red_nether_bricks
setblock 349 78 504 minecraft:red_nether_bricks
setblock 350 78 504 minecraft:pink_terracotta
setblock 354 78 464 minecraft:white_concrete
setblock 364 78 464 minecraft:red_nether_bricks
fill 365 78 464 365 81 464 minecraft:pink_terracotta
setblock 365 78 504 minecraft:white_concrete
fill 367 78 469 367 78 470 minecraft:pink_terracotta
setblock 367 78 471 minecraft:red_nether_bricks
fill 367 78 472 367 80 472 minecraft:pink_terracotta
setblock 367 78 475 minecraft:pink_terracotta
setblock 367 78 476 minecraft:red_nether_bricks
setblock 368 78 465 minecraft:red_nether_bricks
setblock 368 78 466 minecraft:pink_terracotta
setblock 368 78 470 minecraft:red_nether_bricks
fill 368 78 471 368 81 471 minecraft:pink_terracotta
setblock 368 78 475 minecraft:red_nether_bricks
fill 368 78 476 368 81 476 minecraft:pink_terracotta
setblock 368 78 490 minecraft:red_nether_bricks
setblock 368 78 491 minecraft:pink_terracotta
setblock 369 78 464 minecraft:red_nether_bricks
setblock 369 78 465 minecraft:pink_terracotta
setblock 369 78 469 minecraft:red_nether_bricks
fill 369 78 470 369 81 470 minecraft:pink_terracotta
setblock 369 78 474 minecraft:red_nether_bricks
fill 369 78 475 369 81 475 minecraft:pink_terracotta
setblock 369 78 479 minecraft:red_nether_bricks
fill 369 78 480 369 79 480 minecraft:pink_terracotta
setblock 369 78 489 minecraft:red_nether_bricks
fill 369 78 490 369 79 490 minecraft:pink_terracotta
setblock 369 78 494 minecraft:red_nether_bricks
fill 369 78 495 369 79 495 minecraft:pink_terracotta
fill 370 78 464 370 79 464 minecraft:pink_terracotta
setblock 370 78 468 minecraft:red_nether_bricks
fill 370 78 469 370 81 469 minecraft:pink_terracotta
setblock 370 78 473 minecraft:red_nether_bricks
fill 370 78 474 370 81 474 minecraft:pink_terracotta
setblock 370 78 478 minecraft:red_nether_bricks
fill 370 78 479 370 81 479 minecraft:pink_terracotta
setblock 370 78 483 minecraft:red_nether_bricks
setblock 370 78 484 minecraft:pink_terracotta
setblock 370 78 488 minecraft:red_nether_bricks
fill 370 78 489 370 79 489 minecraft:pink_terracotta
setblock 370 78 493 minecraft:red_nether_bricks
fill 370 78 494 370 81 494 minecraft:pink_terracotta
setblock 370 78 498 minecraft:red_nether_bricks
setblock 330 79 467 minecraft:red_nether_bricks
fill 330 79 468 330 82 468 minecraft:pink_terracotta
setblock 330 79 472 minecraft:red_nether_bricks
fill 330 79 473 330 82 473 minecraft:pink_terracotta
setblock 330 79 477 minecraft:red_nether_bricks
fill 330 79 478 330 80 478 minecraft:pink_terracotta
setblock 330 79 482 minecraft:white_concrete
setblock 330 79 492 minecraft:red_nether_bricks
fill 330 79 493 330 80 493 minecraft:pink_terracotta
setblock 330 79 497 minecraft:red_nether_bricks
fill 330 79 498 330 82 498 minecraft:pink_terracotta
setblock 330 79 502 minecraft:red_nether_bricks
setblock 331 79 466 minecraft:red_nether_bricks
setblock 331 79 467 minecraft:pink_terracotta
setblock 331 79 471 minecraft:red_nether_bricks
fill 331 79 472 331 80 472 minecraft:pink_terracotta
fill 332 79 465 332 80 465 minecraft:white_concrete
fill 333 79 464 335 81 464 minecraft:white_concrete
fill 333 79 466 333 80 466 minecraft:white_concrete
fill 334 79 467 334 80 467 minecraft:red_concrete
fill 335 79 466 335 80 466 minecraft:white_concrete
fill 336 79 465 336 80 465 minecraft:white_concrete
fill 339 79 504 339 82 504 minecraft:pink_terracotta
setblock 343 79 464 minecraft:red_nether_bricks
setblock 343 79 504 minecraft:red_nether_bricks
fill 344 79 464 344 80 464 minecraft:pink_terracotta
setblock 344 79 503 minecraft:red_nether_bricks
fill 344 79 504 344 82 504 minecraft:pink_terracotta
fill 345 79 503 345 82 503 minecraft:pink_terracotta
setblock 348 79 464 minecraft:white_concrete
setblock 348 79 504 minecraft:red_nether_bricks
setblock 349 79 504 minecraft:pink_terracotta
setblock 352 79 504 minecraft:white_concrete
fill 364 79 464 364 80 464 minecraft:pink_terracotta
setblock 367 79 465 minecraft:red_nether_bricks
setblock 367 79 470 minecraft:red_nether_bricks
fill 367 79 471 367 80 471 minecraft:pink_terracotta
setblock 367 79 475 minecraft:red_nether_bricks
fill 367 79 476 367 80 476 minecraft:pink_terracotta
setblock 368 79 464 minecraft:red_nether_bricks
setblock 368 79 465 minecraft:pink_terracotta
setblock 368 79 469 minecraft:red_nether_bricks
fill 368 79 470 368 81 470 minecraft:pink_terracotta
setblock 368 79 474 minecraft:red_nether_bricks
fill 368 79 475 368 82 475 minecraft:pink_terracotta
fill 369 79 464 369 80 464 minecraft:pink_terracotta
setblock 369 79 468 minecraft:red_nether_bricks
fill 369 79 469 369 82 469 minecraft:pink_terracotta
setblock 369 79 473 minecraft:red_nether_bricks
fill 369 79 474 369 82 474 minecraft:pink_terracotta
setblock 369 79 478 minecraft:red_nether_bricks
fill 369 79 479 369 82 479 minecraft:pink_terracotta
setblock 369 79 493 minecraft:red_nether_bricks
setblock 369 79 494 minecraft:pink_terracotta
setblock 370 79 467 minecraft:red_nether_bricks
fill 370 79 468 370 82 468 minecraft:pink_terracotta
setblock 370 79 472 minecraft:red_nether_bricks
fill 370 79 473 370 82 473 minecraft:pink_terracotta
setblock 370 79 477 minecraft:red_nether_bricks
fill 370 79 478 370 82 478 minecraft:pink_terracotta
setblock 370 79 482 minecraft:red_nether_bricks
setblock 370 79 483 minecraft:pink_terracotta
setblock 370 79 486 minecraft:white_concrete
setblock 370 79 487 minecraft:red_nether_bricks
setblock 370 79 488 minecraft:pink_terracotta
setblock 370 79 492 minecraft:red_nether_bricks
fill 370 79 493 370 80 493 minecraft:pink_terracotta
setblock 370 79 497 minecraft:red_nether_bricks
setblock 370 79 498 minecraft:pink_terracotta
setblock 330 80 466 minecraft:red_nether_bricks
fill 330 80 467 330 81 467 minecraft:pink_terracotta
setblock 330 80 471 minecraft:red_nether_bricks
fill 330 80 472 330 83 472 minecraft:pink_terracotta
setblock 330 80 476 minecraft:red_nether_bricks
fill 330 80 477 330 83 477 minecraft:pink_terracotta
setblock 330 80 488 minecraft:white_concrete
setblock 330 80 492 minecraft:pink_terracotta
setblock 330 80 495 minecraft:pink_terracotta
setblock 330 80 496 minecraft:red_nether_bricks
fill 330 80 497 330 83 497 minecraft:pink_terracotta
setblock 330 80 501 minecraft:red_nether_bricks
setblock 331 80 470 minecraft:red_nether_bricks
setblock 331 80 471 minecraft:pink_terracotta
fill 332 80 464 332 81 464 minecraft:white_concrete
setblock 333 80 504 minecraft:white_concrete
setblock 342 80 464 minecraft:white_concrete
setblock 342 80 504 minecraft:red_nether_bricks
setblock 343 80 464 minecraft:pink_terracotta
setblock 343 80 503 minecraft:red_nether_bricks
fill 343 80 504 343 83 504 minecraft:pink_terracotta
fill 344 80 503 344 83 503 minecraft:pink_terracotta
setblock 347 80 504 minecraft:red_nether_bricks
setblock 348 80 504 minecraft:pink_terracotta
setblock 358 80 504 minecraft:white_concrete
setblock 367 80 464 minecraft:red_nether_bricks
setblock 367 80 474 minecraft:red_nether_bricks
fill 367 80 475 367 81 475 minecraft:pink_terracotta
fill 368 80 464 368 81 464 minecraft:pink_terracotta
setblock 368 80 469 minecraft:pink_terracotta
setblock 368 80 473 minecraft:red_nether_bricks
fill 368 80 474 368 83 474 minecraft:pink_terracotta
setblock 368 80 478 minecraft:red_nether_bricks
setblock 369 80 467 minecraft:red_nether_bricks
fill 369 80 468 369 81 468 minecraft:pink_terracotta
setblock 369 80 472 minecraft:red_nether_bricks
fill 369 80 473 369 83 473 minecraft:pink_terracotta
setblock 369 80 477 minecraft:red_nether_bricks
fill 369 80 478 369 83 478 minecraft:pink_terracotta
setblock 370 80 466 minecraft:red_nether_bricks
fill 370 80 467 370 82 467 minecraft:pink_terracotta
setblock 370 80 471 minecraft:red_nether_bricks
fill 370 80 472 370 83 472 minecraft:pink_terracotta
setblock 370 80 476 minecraft:red_nether_bricks
fill 370 80 477 370 83 477 minecraft:pink_terracotta
setblock 370 80 481 minecraft:red_nether_bricks
setblock 370 80 491 minecraft:red_nether_bricks
setblock 370 80 492 minecraft:pink_terracotta
setblock 370 80 496 minecraft:red_nether_bricks
setblock 370 80 497 minecraft:pink_terracotta
setblock 330 81 465 minecraft:red_nether_bricks
setblock 330 81 466 minecraft:pink_terracotta
setblock 330 81 470 minecraft:red_nether_bricks
fill 330 81 471 330 83 471 minecraft:pink_terracotta
setblock 330 81 475 minecraft:red_nether_bricks
fill 330 81 476 330 84 476 minecraft:pink_terracotta
setblock 330 81 495 minecraft:red_nether_bricks
fill 330 81 496 330 84 496 minecraft:pink_terracotta
setblock 330 81 500 minecraft:red_nether_bricks
fill 330 81 501 330 84 501 minecraft:pink_terracotta
setblock 332 81 466 minecraft:light[level=12]
setblock 332 81 474 minecraft:light[level=12]
setblock 332 81 482 minecraft:light[level=12]
setblock 332 81 490 minecraft:light[level=12]
setblock 332 81 498 minecraft:light[level=12]
setblock 340 81 466 minecraft:light[level=12]
setblock 340 81 474 minecraft:light[level=12]
setblock 340 81 482 minecraft:light[level=12]
setblock 340 81 490 minecraft:light[level=12]
setblock 340 81 498 minecraft:light[level=12]
setblock 341 81 503 minecraft:pink_terracotta
setblock 341 81 504 minecraft:red_nether_bricks
setblock 342 81 503 minecraft:red_nether_bricks
fill 342 81 504 342 84 504 minecraft:pink_terracotta
fill 343 81 503 343 84 503 minecraft:pink_terracotta
setblock 346 81 504 minecraft:red_nether_bricks
fill 347 81 504 347 84 504 minecraft:pink_terracotta
setblock 348 81 466 minecraft:light[level=12]
setblock 348 81 474 minecraft:light[level=12]
setblock 348 81 482 minecraft:light[level=12]
setblock 348 81 490 minecraft:light[level=12]
setblock 348 81 498 minecraft:light[level=12]
setblock 356 81 466 minecraft:light[level=12]
setblock 356 81 474 minecraft:light[level=12]
setblock 356 81 482 minecraft:light[level=12]
setblock 356 81 490 minecraft:light[level=12]
setblock 356 81 498 minecraft:light[level=12]
setblock 361 81 464 minecraft:white_concrete
setblock 364 81 466 minecraft:light[level=12]
setblock 364 81 474 minecraft:light[level=12]
setblock 364 81 482 minecraft:light[level=12]
setblock 364 81 490 minecraft:light[level=12]
setblock 364 81 498 minecraft:light[level=12]
setblock 364 81 504 minecraft:white_concrete
setblock 366 81 464 minecraft:red_nether_bricks
setblock 367 81 464 minecraft:pink_terracotta
setblock 367 81 473 minecraft:red_nether_bricks
setblock 367 81 474 minecraft:pink_terracotta
setblock 368 81 472 minecraft:red_nether_bricks
fill 368 81 473 368 84 473 minecraft:pink_terracotta
setblock 368 81 477 minecraft:red_nether_bricks
setblock 369 81 471 minecraft:red_nether_bricks
fill 369 81 472 369 84 472 minecraft:pink_terracotta
setblock 369 81 476 minecraft:red_nether_bricks
fill 369 81 477 369 84 477 minecraft:pink_terracotta
setblock 370 81 466 minecraft:pink_terracotta
setblock 370 81 470 minecraft:red_nether_bricks
fill 370 81 471 370 84 471 minecraft:pink_terracotta
setblock 370 81 475 minecraft:red_nether_bricks
fill 370 81 476 370 84 476 minecraft:pink_terracotta
setblock 370 81 480 minecraft:red_nether_bricks
setblock 370 81 495 minecraft:red_nether_bricks
setblock 370 81 496 minecraft:pink_terracotta
setblock 370 81 499 minecraft:white_concrete
setblock 330 82 469 minecraft:red_nether_bricks
fill 330 82 470 330 83 470 minecraft:pink_terracotta
setblock 330 82 474 minecraft:red_nether_bricks
fill 330 82 475 330 85 475 minecraft:pink_terracotta
fill 330 82 495 330 83 495 minecraft:pink_terracotta
setblock 330 82 499 minecraft:red_nether_bricks
fill 330 82 500 330 85 500 minecraft:pink_terracotta
setblock 334 82 464 minecraft:white_concrete
fill 338 82 504 338 83 504 minecraft:pink_terracotta
setblock 340 82 503 minecraft:pink_terracotta
setblock 340 82 504 minecraft:red_nether_bricks
setblock 341 82 503 minecraft:red_nether_bricks
fill 341 82 504 341 85 504 minecraft:pink_terracotta
fill 342 82 503 342 85 503 minecraft:pink_terracotta
setblock 345 82 504 minecraft:red_nether_bricks
setblock 346 82 503 minecraft:red_nether_bricks
fill 346 82 504 346 85 504 minecraft:pink_terracotta
setblock 355 82 464 minecraft:white_concrete
setblock 365 82 464 minecraft:red_nether_bricks
fill 366 82 464 366 85 464 minecraft:pink_terracotta
setblock 368 82 471 minecraft:red_nether_bricks
fill 368 82 472 368 83 472 minecraft:pink_terracotta
setblock 368 82 476 minecraft:red_nether_bricks
fill 368 82 477 368 85 477 minecraft:pink_terracotta
setblock 369 82 470 minecraft:red_nether_bricks
fill 369 82 471 369 84 471 minecraft:pink_terracotta
setblock 369 82 475 minecraft:red_nether_bricks
fill 369 82 476 369 85 476 minecraft:pink_terracotta
setblock 370 82 469 minecraft:red_nether_bricks
fill 370 82 470 370 85 470 minecraft:pink_terracotta
setblock 370 82 474 minecraft:red_nether_bricks
fill 370 82 475 370 85 475 minecraft:pink_terracotta
setblock 370 82 479 minecraft:red_nether_bricks
fill 370 82 480 370 85 480 minecraft:pink_terracotta
setblock 370 82 493 minecraft:white_concrete
setblock 370 82 504 minecraft:white_concrete
setblock 330 83 473 minecraft:red_nether_bricks
fill 330 83 474 330 86 474 minecraft:pink_terracotta
setblock 330 83 481 minecraft:white_concrete
setblock 330 83 498 minecraft:red_nether_bricks
fill 330 83 499 330 86 499 minecraft:pink_terracotta
setblock 330 83 502 minecraft:pink_terracotta
setblock 332 83 504 minecraft:white_concrete
fill 337 83 504 337 84 504 minecraft:pink_terracotta
setblock 339 83 503 minecraft:pink_terracotta
setblock 339 83 504 minecraft:red_nether_bricks
setblock 340 83 503 minecraft:red_nether_bricks
fill 340 83 504 340 86 504 minecraft:pink_terracotta
fill 341 83 503 341 86 503 minecraft:pink_terracotta
fill 342 83 502 344 84 502 minecraft:pink_terracotta
setblock 344 83 504 minecraft:red_nether_bricks
setblock 345 83 503 minecraft:red_nether_bricks
fill 345 83 504 345 86 504 minecraft:pink_terracotta
fill 346 83 503 346 86 503 minecraft:pink_terracotta
setblock 349 83 464 minecraft:white_concrete
setblock 351 83 504 minecraft:white_concrete
setblock 364 83 464 minecraft:red_nether_bricks
fill 365 83 464 365 86 464 minecraft:pink_terracotta
setblock 368 83 464 minecraft:white_concrete
setblock 368 83 475 minecraft:red_nether_bricks
fill 368 83 476 368 86 476 minecraft:pink_terracotta
setblock 369 83 470 minecraft:pink_terracotta
setblock 369 83 474 minecraft:red_nether_bricks
fill 369 83 475 369 86 475 minecraft:pink_terracotta
setblock 369 83 479 minecraft:red_nether_bricks
setblock 370 83 468 minecraft:red_nether_bricks
fill 370 83 469 370 86 469 minecraft:pink_terracotta
setblock 370 83 473 minecraft:red_nether_bricks
fill 370 83 474 370 86 474 minecraft:pink_terracotta
setblock 370 83 478 minecraft:red_nether_bricks
fill 370 83 479 370 86 479 minecraft:pink_terracotta
setblock 370 83 487 minecraft:white_concrete
setblock 330 84 468 minecraft:white_concrete
setblock 330 84 472 minecraft:red_nether_bricks
fill 330 84 473 330 85 473 minecraft:pink_terracotta
setblock 330 84 477 minecraft:red_nether_bricks
setblock 330 84 487 minecraft:white_concrete
setblock 330 84 497 minecraft:red_nether_bricks
fill 330 84 498 330 87 498 minecraft:pink_terracotta
setblock 330 84 502 minecraft:red_nether_bricks
fill 330 84 503 330 87 503 minecraft:pink_terracotta
fill 335 84 504 336 85 504 minecraft:pink_terracotta
fill 337 84 464 337 85 464 minecraft:white_concrete
fill 337 84 503 338 84 503 minecraft:pink_terracotta
setblock 338 84 504 minecraft:red_nether_bricks
setblock 339 84 503 minecraft:red_nether_bricks
fill 339 84 504 339 87 504 minecraft:pink_terracotta
setblock 340 84 502 minecraft:red_nether_bricks
fill 340 84 503 340 87 503 minecraft:pink_terracotta
fill 341 84 502 341 87 502 minecraft:pink_terracotta
setblock 343 84 464 minecraft:white_concrete
setblock 343 84 504 minecraft:red_nether_bricks
setblock 344 84 503 minecraft:red_nether_bricks
fill 344 84 504 344 87 504 minecraft:pink_terracotta
fill 345 84 503 345 87 503 minecraft:pink_terracotta
setblock 357 84 504 minecraft:white_concrete
setblock 362 84 464 minecraft:white_concrete
setblock 363 84 464 minecraft:red_nether_bricks
fill 364 84 464 364 87 464 minecraft:pink_terracotta
setblock 367 84 464 minecraft:pink_terracotta
setblock 368 84 474 minecraft:red_nether_bricks
fill 368 84 475 368 86 475 minecraft:pink_terracotta
setblock 369 84 473 minecraft:red_nether_bricks
fill 369 84 474 369 87 474 minecraft:pink_terracotta
setblock 369 84 478 minecraft:red_nether_bricks
fill 369 84 479 369 87 479 minecraft:pink_terracotta
setblock 370 84 472 minecraft:red_nether_bricks
fill 370 84 473 370 87 473 minecraft:pink_terracotta
setblock 370 84 477 minecraft:red_nether_bricks
fill 370 84 478 370 87 478 minecraft:pink_terracotta
setblock 370 84 481 minecraft:white_concrete
setblock 370 84 500 minecraft:white_concrete
setblock 330 85 476 minecraft:red_nether_bricks
fill 330 85 477 330 88 477 minecraft:pink_terracotta
setblock 330 85 493 minecraft:white_concrete
setblock 330 85 496 minecraft:red_nether_bricks
fill 330 85 497 330 88 497 minecraft:pink_terracotta
setblock 330 85 501 minecraft:red_nether_bricks
fill 330 85 502 330 88 502 minecraft:pink_terracotta
fill 330 85 504 331 85 504 minecraft:pink_terracotta
setblock 331 85 464 minecraft:white_concrete
setblock 332 85 504 minecraft:red_nether_bricks
fill 333 85 504 334 87 504 minecraft:pink_terracotta
fill 336 85 503 337 85 503 minecraft:pink_terracotta
setblock 337 85 504 minecraft:red_nether_bricks
setblock 338 85 502 minecraft:pink_terracotta
setblock 338 85 503 minecraft:red_nether_bricks
fill 338 85 504 338 88 504 minecraft:pink_terracotta
setblock 339 85 502 minecraft:red_nether_bricks
fill 339 85 503 339 88 503 minecraft:pink_terracotta
fill 340 85 464 341 85 464 minecraft:pink_terracotta
setblock 340 85 501 minecraft:red_nether_bricks
fill 340 85 502 340 88 502 minecraft:pink_terracotta
fill 341 85 501 343 86 501 minecraft:pink_terracotta
setblock 342 85 464 minecraft:red_nether_bricks
fill 342 85 502 343 85 502 minecraft:pink_terracotta
setblock 342 85 504 minecraft:red_nether_bricks
setblock 343 85 503 minecraft:red_nether_bricks
fill 343 85 504 343 88 504 minecraft:pink_terracotta
setblock 344 85 502 minecraft:red_nether_bricks
fill 344 85 503 344 88 503 minecraft:pink_terracotta
fill 345 85 502 345 88 502 minecraft:pink_terracotta
setblock 347 85 504 minecraft:red_nether_bricks
setblock 356 85 464 minecraft:white_concrete
fill 359 85 488 359 86 488 minecraft:pink_concrete
setblock 361 85 464 minecraft:pink_terracotta
setblock 361 85 504 minecraft:pink_terracotta
setblock 362 85 464 minecraft:red_nether_bricks
setblock 362 85 504 minecraft:red_nether_bricks
fill 363 85 464 363 88 464 minecraft:pink_terracotta
fill 363 85 504 366 85 504 minecraft:pink_terracotta
setblock 367 85 464 minecraft:red_nether_bricks
fill 368 85 464 368 88 464 minecraft:pink_terracotta
setblock 368 85 474 minecraft:pink_terracotta
setblock 369 85 472 minecraft:red_nether_bricks
fill 369 85 473 369 87 473 minecraft:pink_terracotta
setblock 369 85 477 minecraft:red_nether_bricks
fill 369 85 478 369 88 478 minecraft:pink_terracotta
setblock 370 85 471 minecraft:red_nether_bricks
fill 370 85 472 370 88 472 minecraft:pink_terracotta
setblock 370 85 476 minecraft:red_nether_bricks
fill 370 85 477 370 88 477 minecraft:pink_terracotta
setblock 370 85 494 minecraft:white_concrete
setblock 330 86 475 minecraft:red_nether_bricks
fill 330 86 476 330 88 476 minecraft:pink_terracotta
setblock 330 86 480 minecraft:white_concrete
fill 330 86 496 330 89 496 minecraft:pink_terracotta
setblock 330 86 500 minecraft:red_nether_bricks
fill 330 86 501 331 88 501 minecraft:pink_terracotta
setblock 330 86 504 minecraft:pink_terracotta
setblock 331 86 498 minecraft:pink_terracotta
setblock 331 86 499 minecraft:red_nether_bricks
fill 331 86 500 331 89 500 minecraft:pink_terracotta
fill 331 86 502 331 87 502 minecraft:pink_terracotta
setblock 331 86 504 minecraft:red_nether_bricks
fill 332 86 504 332 89 504 minecraft:pink_terracotta
fill 333 86 503 336 86 503 minecraft:pink_terracotta
setblock 335 86 504 minecraft:pink_terracotta
fill 336 86 502 337 86 502 minecraft:pink_terracotta
setblock 336 86 504 minecraft:red_nether_bricks
fill 337 86 464 340 86 464 minecraft:pink_terracotta
fill 337 86 500 337 86 501 minecraft:red_nether_bricks
setblock 337 86 503 minecraft:red_nether_bricks
fill 337 86 504 337 89 504 minecraft:pink_terracotta
fill 338 86 500 338 88 500 minecraft:red_nether_bricks
setblock 338 86 501 minecraft:pink_terracotta
setblock 338 86 502 minecraft:red_nether_bricks
fill 338 86 503 338 89 503 minecraft:pink_terracotta
setblock 339 86 501 minecraft:red_nether_bricks
fill 339 86 502 339 89 502 minecraft:pink_terracotta
fill 340 86 501 340 89 501 minecraft:pink_terracotta
setblock 341 86 464 minecraft:red_nether_bricks
setblock 341 86 504 minecraft:red_nether_bricks
fill 342 86 464 343 88 464 minecraft:pink_terracotta
setblock 342 86 502 minecraft:pink_terracotta
setblock 342 86 503 minecraft:red_nether_bricks
fill 342 86 504 342 89 504 minecraft:pink_terracotta
setblock 343 86 502 minecraft:red_nether_bricks
fill 343 86 503 343 89 503 minecraft:pink_terracotta
setblock 344 86 501 minecraft:red_nether_bricks
fill 344 86 502 344 89 502 minecraft:pink_terracotta
setblock 346 86 504 minecraft:red_nether_bricks
setblock 347 86 503 minecraft:red_nether_bricks
fill 347 86 504 348 88 504 minecraft:pink_terracotta
setblock 350 86 464 minecraft:white_concrete
setblock 350 86 504 minecraft:white_concrete
fill 359 86 464 360 86 464 minecraft:pink_terracotta
fill 359 86 504 360 86 504 minecraft:pink_terracotta
setblock 361 86 464 minecraft:red_nether_bricks
setblock 361 86 503 minecraft:pink_terracotta
setblock 361 86 504 minecraft:red_nether_bricks
fill 362 86 464 362 89 464 minecraft:pink_terracotta
setblock 362 86 503 minecraft:red_nether_bricks
fill 362 86 504 365 86 504 minecraft:pink_terracotta
fill 363 86 503 364 88 503 minecraft:pink_terracotta
setblock 366 86 464 minecraft:red_nether_bricks
setblock 366 86 504 minecraft:red_nether_bricks
fill 367 86 464 367 89 464 minecraft:pink_terracotta
fill 367 86 504 368 88 504 minecraft:pink_terracotta
setblock 368 86 477 minecraft:red_nether_bricks
fill 369 86 464 369 87 464 minecraft:pink_terracotta
setblock 369 86 472 minecraft:pink_terracotta
setblock 369 86 476 minecraft:red_nether_bricks
fill 369 86 477 369 89 477 minecraft:pink_terracotta
setblock 369 86 504 minecraft:white_concrete
setblock 370 86 470 minecraft:red_nether_bricks
fill 370 86 471 370 89 471 minecraft:pink_terracotta
setblock 370 86 475 minecraft:red_nether_bricks
fill 370 86 476 370 89 476 minecraft:pink_terracotta
setblock 370 86 480 minecraft:red_nether_bricks
fill 370 86 481 370 89 481 minecraft:pink_terracotta
setblock 370 86 488 minecraft:white_concrete
fill 370 86 498 370 86 499 minecraft:pink_terracotta
setblock 370 86 500 minecraft:red_nether_bricks
fill 370 86 501 370 87 503 minecraft:pink_terracotta
setblock 330 87 464 minecraft:red_nether_bricks
setblock 330 87 475 minecraft:pink_terracotta
setblock 330 87 478 minecraft:pink_terracotta
setblock 330 87 486 minecraft:white_concrete
setblock 330 87 499 minecraft:red_nether_bricks
fill 330 87 500 330 90 500 minecraft:pink_terracotta
setblock 330 87 504 minecraft:red_nether_bricks
setblock 331 87 498 minecraft:red_nether_bricks
fill 331 87 499 331 90 499 minecraft:pink_terracotta
setblock 331 87 503 minecraft:red_nether_bricks
fill 331 87 504 331 90 504 minecraft:pink_terracotta
fill 332 87 503 335 87 503 minecraft:pink_terracotta
fill 334 87 502 336 87 502 minecraft:pink_terracotta
schedule function dropper:buildpart/115_2 1t
