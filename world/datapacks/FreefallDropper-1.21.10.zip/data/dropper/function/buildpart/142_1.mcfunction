fill 511 193 578 511 233 580 minecraft:quartz_pillar
fill 511 193 590 511 233 592 minecraft:quartz_pillar
fill 484 194 571 489 195 587 minecraft:prismarine_bricks
fill 490 194 571 490 195 577 minecraft:prismarine_bricks
fill 490 194 581 490 195 587 minecraft:prismarine_bricks
fill 491 194 571 500 195 576 minecraft:prismarine_bricks
fill 491 194 582 500 195 587 minecraft:prismarine_bricks
fill 494 194 577 500 195 577 minecraft:prismarine_bricks
fill 494 194 581 500 194 581 minecraft:prismarine_bricks
fill 495 194 578 500 195 580 minecraft:prismarine_bricks
fill 495 195 581 500 195 581 minecraft:prismarine_bricks
setblock 473 196 560 minecraft:light[level=14]
setblock 473 196 568 minecraft:light[level=14]
setblock 473 196 576 minecraft:light[level=14]
setblock 473 196 584 minecraft:light[level=14]
setblock 473 196 592 minecraft:light[level=14]
setblock 481 196 560 minecraft:light[level=14]
setblock 481 196 568 minecraft:light[level=14]
setblock 481 196 576 minecraft:light[level=14]
setblock 481 196 584 minecraft:light[level=14]
setblock 481 196 592 minecraft:light[level=14]
fill 486 196 573 489 196 585 minecraft:dark_prismarine
setblock 489 196 560 minecraft:light[level=14]
setblock 489 196 568 minecraft:light[level=14]
setblock 489 196 592 minecraft:light[level=14]
fill 490 196 573 498 196 576 minecraft:dark_prismarine
fill 490 196 582 498 196 585 minecraft:dark_prismarine
fill 495 196 577 498 196 581 minecraft:dark_prismarine
setblock 497 196 560 minecraft:light[level=14]
setblock 497 196 568 minecraft:light[level=14]
setblock 497 196 592 minecraft:light[level=14]
setblock 505 196 560 minecraft:light[level=14]
setblock 505 196 568 minecraft:light[level=14]
setblock 505 196 576 minecraft:light[level=14]
setblock 505 196 584 minecraft:light[level=14]
setblock 505 196 592 minecraft:light[level=14]
fill 486 197 573 488 197 585 minecraft:dark_prismarine
fill 489 197 573 489 197 578 minecraft:dark_prismarine
fill 489 197 580 489 197 585 minecraft:dark_prismarine
fill 490 197 573 491 197 576 minecraft:dark_prismarine
fill 490 197 582 491 197 585 minecraft:dark_prismarine
fill 492 197 573 498 197 575 minecraft:dark_prismarine
fill 492 197 583 498 197 585 minecraft:dark_prismarine
fill 493 197 576 498 197 576 minecraft:dark_prismarine
fill 493 197 582 498 197 582 minecraft:dark_prismarine
fill 495 197 577 498 197 578 minecraft:dark_prismarine
fill 495 197 580 498 197 581 minecraft:dark_prismarine
fill 496 197 579 498 197 579 minecraft:dark_prismarine
fill 488 198 575 488 199 583 minecraft:prismarine_bricks
fill 489 198 575 489 199 577 minecraft:prismarine_bricks
fill 489 198 581 489 199 583 minecraft:prismarine_bricks
fill 490 198 575 490 199 576 minecraft:prismarine_bricks
fill 490 198 582 490 199 583 minecraft:prismarine_bricks
fill 491 198 575 496 199 575 minecraft:prismarine_bricks
fill 491 198 583 496 199 583 minecraft:prismarine_bricks
fill 494 198 576 496 199 576 minecraft:prismarine_bricks
fill 494 198 582 496 199 582 minecraft:prismarine_bricks
fill 495 198 577 496 199 577 minecraft:prismarine_bricks
fill 495 198 581 496 199 581 minecraft:prismarine_bricks
fill 496 198 578 496 199 580 minecraft:prismarine_bricks
fill 472 200 567 472 205 569 minecraft:quartz_pillar
fill 472 200 579 472 205 581 minecraft:quartz_pillar
fill 472 200 591 472 205 593 minecraft:quartz_pillar
fill 478 200 597 480 205 597 minecraft:quartz_pillar
fill 482 200 559 484 205 559 minecraft:quartz_pillar
fill 490 200 597 492 205 597 minecraft:quartz_pillar
fill 494 200 559 496 205 559 minecraft:quartz_pillar
fill 502 200 597 504 205 597 minecraft:quartz_pillar
fill 506 200 559 508 205 559 minecraft:quartz_pillar
fill 510 200 567 510 205 569 minecraft:quartz_pillar
fill 510 200 579 510 205 581 minecraft:quartz_pillar
fill 510 200 591 510 205 593 minecraft:quartz_pillar
setblock 504 201 562 minecraft:smooth_quartz
setblock 505 201 561 minecraft:smooth_quartz
fill 505 201 564 508 201 564 minecraft:smooth_quartz
fill 506 201 560 507 201 560 minecraft:smooth_quartz
setblock 508 201 561 minecraft:smooth_quartz
fill 509 201 562 509 201 563 minecraft:smooth_quartz
setblock 473 204 560 minecraft:light[level=14]
setblock 473 204 568 minecraft:light[level=14]
setblock 473 204 576 minecraft:light[level=14]
setblock 473 204 584 minecraft:light[level=14]
setblock 473 204 592 minecraft:light[level=14]
setblock 481 204 560 minecraft:light[level=14]
setblock 481 204 568 minecraft:light[level=14]
setblock 481 204 576 minecraft:light[level=14]
setblock 481 204 584 minecraft:light[level=14]
setblock 481 204 592 minecraft:light[level=14]
setblock 489 204 560 minecraft:light[level=14]
setblock 489 204 568 minecraft:light[level=14]
setblock 489 204 576 minecraft:light[level=14]
setblock 489 204 584 minecraft:light[level=14]
setblock 489 204 592 minecraft:light[level=14]
setblock 497 204 560 minecraft:light[level=14]
setblock 497 204 568 minecraft:light[level=14]
setblock 497 204 576 minecraft:light[level=14]
setblock 497 204 584 minecraft:light[level=14]
setblock 497 204 592 minecraft:light[level=14]
setblock 505 204 560 minecraft:light[level=14]
setblock 505 204 568 minecraft:light[level=14]
setblock 505 204 576 minecraft:light[level=14]
setblock 505 204 584 minecraft:light[level=14]
setblock 505 204 592 minecraft:light[level=14]
fill 509 204 591 509 216 591 minecraft:blue_wool
fill 471 205 561 471 205 566 minecraft:smooth_quartz
fill 471 205 573 471 205 578 minecraft:smooth_quartz
fill 471 205 585 471 205 590 minecraft:smooth_quartz
fill 471 205 597 471 205 598 minecraft:smooth_quartz
fill 472 205 598 475 205 598 minecraft:smooth_quartz
fill 475 205 558 480 205 558 minecraft:smooth_quartz
fill 482 205 598 487 205 598 minecraft:smooth_quartz
fill 487 205 558 492 205 558 minecraft:smooth_quartz
fill 494 205 598 499 205 598 minecraft:smooth_quartz
fill 499 205 558 504 205 558 minecraft:smooth_quartz
fill 506 205 598 511 205 598 minecraft:smooth_quartz
fill 509 205 589 509 216 590 minecraft:blue_wool
fill 509 205 592 509 216 593 minecraft:blue_wool
fill 511 205 558 511 205 563 minecraft:smooth_quartz
fill 511 205 570 511 205 575 minecraft:smooth_quartz
fill 511 205 582 511 205 587 minecraft:smooth_quartz
fill 511 205 594 511 205 597 minecraft:smooth_quartz
fill 470 206 563 470 211 566 minecraft:pearlescent_froglight
fill 470 206 575 470 211 578 minecraft:pearlescent_froglight
fill 470 206 587 470 211 590 minecraft:pearlescent_froglight
fill 470 206 599 473 211 599 minecraft:pearlescent_froglight
fill 477 206 557 480 211 557 minecraft:pearlescent_froglight
fill 482 206 599 485 211 599 minecraft:pearlescent_froglight
fill 489 206 557 492 211 557 minecraft:pearlescent_froglight
fill 494 206 599 497 211 599 minecraft:pearlescent_froglight
fill 501 206 557 504 211 557 minecraft:pearlescent_froglight
fill 506 206 599 509 211 599 minecraft:pearlescent_froglight
fill 512 206 558 512 211 561 minecraft:pearlescent_froglight
fill 512 206 570 512 211 573 minecraft:pearlescent_froglight
fill 512 206 582 512 211 585 minecraft:pearlescent_froglight
fill 512 206 594 512 211 597 minecraft:pearlescent_froglight
setblock 504 209 562 minecraft:smooth_quartz
setblock 505 209 561 minecraft:smooth_quartz
fill 505 209 564 508 209 564 minecraft:smooth_quartz
fill 506 209 560 507 209 560 minecraft:smooth_quartz
setblock 508 209 561 minecraft:smooth_quartz
fill 509 209 562 509 209 563 minecraft:smooth_quartz
fill 470 212 563 470 216 563 minecraft:smooth_quartz
fill 470 212 564 470 212 565 minecraft:pearlescent_froglight
fill 470 212 566 470 216 566 minecraft:smooth_quartz
fill 470 212 575 470 216 575 minecraft:smooth_quartz
fill 470 212 576 470 212 577 minecraft:pearlescent_froglight
fill 470 212 578 470 216 578 minecraft:smooth_quartz
fill 470 212 587 470 216 587 minecraft:smooth_quartz
fill 470 212 588 470 212 589 minecraft:pearlescent_froglight
fill 470 212 590 470 214 590 minecraft:smooth_quartz
setblock 470 212 599 minecraft:smooth_quartz
fill 471 212 599 472 212 599 minecraft:pearlescent_froglight
setblock 473 212 560 minecraft:light[level=14]
setblock 473 212 568 minecraft:light[level=14]
setblock 473 212 576 minecraft:light[level=14]
setblock 473 212 584 minecraft:light[level=14]
setblock 473 212 592 minecraft:light[level=14]
fill 473 212 599 473 214 599 minecraft:smooth_quartz
fill 477 212 557 477 213 557 minecraft:smooth_quartz
fill 478 212 557 479 212 557 minecraft:pearlescent_froglight
fill 480 212 557 480 213 557 minecraft:smooth_quartz
setblock 481 212 560 minecraft:light[level=14]
setblock 481 212 568 minecraft:light[level=14]
setblock 481 212 576 minecraft:light[level=14]
setblock 481 212 584 minecraft:light[level=14]
setblock 481 212 592 minecraft:light[level=14]
fill 482 212 599 482 216 599 minecraft:smooth_quartz
fill 483 212 599 484 212 599 minecraft:pearlescent_froglight
fill 485 212 599 485 216 599 minecraft:smooth_quartz
fill 489 212 557 489 216 557 minecraft:smooth_quartz
setblock 489 212 560 minecraft:light[level=14]
setblock 489 212 568 minecraft:light[level=14]
setblock 489 212 576 minecraft:light[level=14]
setblock 489 212 584 minecraft:light[level=14]
setblock 489 212 592 minecraft:light[level=14]
fill 490 212 557 491 212 557 minecraft:pearlescent_froglight
setblock 492 212 557 minecraft:smooth_quartz
fill 494 212 599 494 216 599 minecraft:smooth_quartz
fill 495 212 599 496 212 599 minecraft:pearlescent_froglight
setblock 497 212 560 minecraft:light[level=14]
setblock 497 212 568 minecraft:light[level=14]
setblock 497 212 576 minecraft:light[level=14]
setblock 497 212 584 minecraft:light[level=14]
setblock 497 212 592 minecraft:light[level=14]
fill 497 212 599 497 216 599 minecraft:smooth_quartz
fill 501 212 557 501 216 557 minecraft:smooth_quartz
fill 502 212 557 503 212 557 minecraft:pearlescent_froglight
fill 504 212 557 504 216 557 minecraft:smooth_quartz
setblock 505 212 560 minecraft:light[level=14]
setblock 505 212 568 minecraft:light[level=14]
setblock 505 212 576 minecraft:light[level=14]
setblock 505 212 584 minecraft:light[level=14]
setblock 505 212 592 minecraft:light[level=14]
fill 506 212 599 506 216 599 minecraft:smooth_quartz
fill 507 212 599 508 212 599 minecraft:pearlescent_froglight
fill 509 212 599 509 216 599 minecraft:smooth_quartz
fill 512 212 558 512 216 558 minecraft:smooth_quartz
fill 512 212 559 512 212 560 minecraft:pearlescent_froglight
fill 512 212 561 512 217 561 minecraft:smooth_quartz
fill 512 212 570 512 213 570 minecraft:smooth_quartz
fill 512 212 571 512 212 572 minecraft:pearlescent_froglight
fill 512 212 573 512 214 573 minecraft:smooth_quartz
fill 512 212 582 512 216 582 minecraft:smooth_quartz
fill 512 212 583 512 212 584 minecraft:pearlescent_froglight
fill 512 212 585 512 216 585 minecraft:smooth_quartz
fill 512 212 594 512 218 594 minecraft:smooth_quartz
fill 512 212 595 512 212 596 minecraft:pearlescent_froglight
fill 512 212 597 512 213 597 minecraft:smooth_quartz
fill 470 213 558 470 214 558 minecraft:quartz_block
fill 470 213 564 470 216 565 minecraft:smooth_quartz
setblock 470 213 571 minecraft:quartz_block
fill 470 213 576 470 216 577 minecraft:smooth_quartz
fill 470 213 588 470 216 589 minecraft:smooth_quartz
setblock 470 213 599 minecraft:quartz_block
fill 471 213 557 471 216 557 minecraft:smooth_quartz
fill 471 213 599 471 216 599 minecraft:smooth_quartz
setblock 472 213 557 minecraft:quartz_block
setblock 472 213 599 minecraft:quartz_block
fill 473 213 557 473 216 557 minecraft:smooth_quartz
setblock 474 213 557 minecraft:quartz_block
fill 475 213 557 475 216 557 minecraft:smooth_quartz
setblock 476 213 557 minecraft:quartz_block
fill 478 213 557 479 216 557 minecraft:smooth_quartz
fill 481 213 557 481 214 557 minecraft:smooth_quartz
setblock 482 213 557 minecraft:quartz_block
fill 483 213 599 484 216 599 minecraft:smooth_quartz
fill 490 213 557 491 216 557 minecraft:smooth_quartz
setblock 492 213 557 minecraft:quartz_block
setblock 495 213 557 minecraft:quartz_block
setblock 495 213 599 minecraft:quartz_block
fill 496 213 599 496 217 599 minecraft:smooth_quartz
fill 502 213 557 502 216 557 minecraft:smooth_quartz
fill 502 213 599 502 216 599 minecraft:smooth_quartz
setblock 503 213 557 minecraft:quartz_block
fill 503 213 599 504 213 599 minecraft:quartz_block
fill 505 213 557 507 216 557 minecraft:smooth_quartz
fill 507 213 599 508 216 599 minecraft:smooth_quartz
setblock 508 213 557 minecraft:quartz_block
fill 509 213 557 511 216 557 minecraft:smooth_quartz
fill 512 213 559 512 216 560 minecraft:smooth_quartz
fill 512 213 571 512 213 572 minecraft:smooth_quartz
setblock 512 213 579 minecraft:quartz_block
fill 512 213 583 512 216 584 minecraft:smooth_quartz
fill 512 213 595 512 213 596 minecraft:smooth_quartz
setblock 470 214 557 minecraft:quartz_block
setblock 470 214 567 minecraft:quartz_block
fill 470 214 568 470 216 571 minecraft:smooth_quartz
setblock 470 214 572 minecraft:quartz_block
fill 470 214 573 470 216 574 minecraft:smooth_quartz
fill 470 214 581 470 214 582 minecraft:quartz_block
setblock 470 214 598 minecraft:quartz_block
setblock 470 214 599 minecraft:smooth_quartz
fill 472 214 557 472 216 557 minecraft:smooth_quartz
fill 472 214 599 472 216 599 minecraft:smooth_quartz
fill 474 214 557 474 216 557 minecraft:smooth_quartz
setblock 474 214 599 minecraft:quartz_block
fill 476 214 557 476 216 557 minecraft:smooth_quartz
setblock 477 214 557 minecraft:quartz_block
setblock 480 214 557 minecraft:quartz_block
setblock 482 214 557 minecraft:smooth_quartz
setblock 486 214 599 minecraft:quartz_block
fill 487 214 599 487 216 599 minecraft:smooth_quartz
fill 492 214 557 492 216 557 minecraft:smooth_quartz
setblock 495 214 557 minecraft:smooth_quartz
fill 495 214 599 495 216 599 minecraft:smooth_quartz
fill 498 214 557 498 216 557 minecraft:smooth_quartz
setblock 499 214 557 minecraft:quartz_block
fill 500 214 557 500 216 557 minecraft:smooth_quartz
setblock 501 214 599 minecraft:quartz_block
setblock 503 214 557 minecraft:smooth_quartz
fill 503 214 599 503 216 599 minecraft:smooth_quartz
setblock 504 214 599 minecraft:quartz_block
fill 508 214 557 508 216 557 minecraft:smooth_quartz
fill 510 214 599 510 216 599 minecraft:smooth_quartz
setblock 511 214 599 minecraft:quartz_block
fill 512 214 563 512 216 563 minecraft:smooth_quartz
setblock 512 214 564 minecraft:quartz_block
fill 512 214 565 512 217 565 minecraft:smooth_quartz
fill 512 214 570 512 214 571 minecraft:quartz_block
fill 512 214 572 512 216 572 minecraft:smooth_quartz
fill 512 214 579 512 216 579 minecraft:smooth_quartz
fill 512 214 595 512 216 595 minecraft:smooth_quartz
fill 512 214 596 512 214 597 minecraft:quartz_block
fill 512 214 599 512 216 599 minecraft:smooth_quartz
fill 470 215 557 470 216 559 minecraft:smooth_quartz
setblock 470 215 560 minecraft:quartz_block
fill 470 215 561 470 216 562 minecraft:smooth_quartz
fill 470 215 567 470 217 567 minecraft:smooth_quartz
fill 470 215 572 470 216 572 minecraft:smooth_quartz
setblock 470 215 581 minecraft:quartz_block
fill 470 215 582 470 216 582 minecraft:smooth_quartz
setblock 470 215 583 minecraft:quartz_block
fill 470 215 584 470 216 584 minecraft:smooth_quartz
setblock 470 215 585 minecraft:quartz_block
fill 470 215 586 470 216 586 minecraft:smooth_quartz
setblock 470 215 590 minecraft:quartz_block
setblock 470 215 592 minecraft:quartz_block
fill 470 215 593 470 216 593 minecraft:smooth_quartz
fill 470 215 598 470 216 598 minecraft:smooth_quartz
setblock 470 215 599 minecraft:quartz_block
setblock 473 215 599 minecraft:quartz_block
fill 474 215 599 474 216 599 minecraft:smooth_quartz
fill 477 215 557 477 216 557 minecraft:smooth_quartz
fill 478 215 599 479 216 599 minecraft:smooth_quartz
fill 480 215 557 480 216 557 minecraft:smooth_quartz
setblock 480 215 599 minecraft:quartz_block
fill 481 215 557 482 215 557 minecraft:quartz_block
fill 481 215 599 481 216 599 minecraft:smooth_quartz
fill 483 215 557 483 216 557 minecraft:smooth_quartz
setblock 484 215 557 minecraft:quartz_block
fill 486 215 599 486 216 599 minecraft:smooth_quartz
setblock 495 215 557 minecraft:quartz_block
setblock 497 215 557 minecraft:quartz_block
fill 499 215 557 499 216 557 minecraft:smooth_quartz
fill 501 215 599 501 216 599 minecraft:smooth_quartz
setblock 503 215 557 minecraft:quartz_block
fill 504 215 599 504 216 599 minecraft:smooth_quartz
fill 511 215 599 511 216 599 minecraft:smooth_quartz
fill 512 215 564 512 217 564 minecraft:smooth_quartz
fill 512 215 570 512 216 571 minecraft:smooth_quartz
setblock 512 215 573 minecraft:quartz_block
fill 512 215 574 512 217 576 minecraft:smooth_quartz
setblock 512 215 577 minecraft:quartz_block
fill 512 215 588 512 216 590 minecraft:smooth_quartz
setblock 512 215 591 minecraft:quartz_block
fill 512 215 592 512 216 593 minecraft:smooth_quartz
fill 512 215 596 512 216 597 minecraft:smooth_quartz
setblock 470 216 560 minecraft:smooth_quartz
setblock 470 216 581 minecraft:smooth_quartz
setblock 470 216 583 minecraft:smooth_quartz
setblock 470 216 585 minecraft:smooth_quartz
setblock 470 216 590 minecraft:smooth_quartz
setblock 470 216 592 minecraft:smooth_quartz
setblock 470 216 599 minecraft:smooth_quartz
setblock 473 216 599 minecraft:smooth_quartz
setblock 480 216 599 minecraft:smooth_quartz
fill 481 216 557 482 216 557 minecraft:smooth_quartz
setblock 484 216 557 minecraft:smooth_quartz
setblock 495 216 557 minecraft:smooth_quartz
setblock 497 216 557 minecraft:smooth_quartz
setblock 503 216 557 minecraft:smooth_quartz
setblock 512 216 573 minecraft:smooth_quartz
setblock 512 216 577 minecraft:smooth_quartz
setblock 512 216 591 minecraft:smooth_quartz
fill 470 217 557 470 217 566 minecraft:quartz_block
setblock 470 217 568 minecraft:smooth_quartz
fill 470 217 569 470 218 569 minecraft:quartz_block
setblock 470 217 570 minecraft:smooth_quartz
fill 470 217 571 470 217 587 minecraft:quartz_block
setblock 470 217 588 minecraft:smooth_quartz
fill 470 217 589 470 225 593 minecraft:quartz_block
fill 470 217 596 470 217 599 minecraft:quartz_block
fill 471 217 557 484 217 557 minecraft:quartz_block
fill 471 217 599 488 217 599 minecraft:quartz_block
fill 485 217 557 485 218 557 minecraft:smooth_quartz
fill 486 217 557 508 217 557 minecraft:quartz_block
setblock 489 217 599 minecraft:smooth_quartz
fill 490 217 599 495 217 599 minecraft:quartz_block
fill 497 217 599 512 217 599 minecraft:quartz_block
setblock 504 217 562 minecraft:smooth_quartz
setblock 505 217 561 minecraft:smooth_quartz
fill 505 217 564 508 217 564 minecraft:smooth_quartz
fill 506 217 560 507 217 560 minecraft:smooth_quartz
setblock 508 217 561 minecraft:smooth_quartz
setblock 509 217 557 minecraft:smooth_quartz
fill 509 217 562 509 217 563 minecraft:smooth_quartz
fill 509 217 588 509 218 594 minecraft:iron_block
fill 510 217 557 512 217 557 minecraft:quartz_block
fill 512 217 558 512 225 558 minecraft:quartz_block
setblock 512 217 559 minecraft:smooth_quartz
fill 512 217 560 512 225 560 minecraft:quartz_block
fill 512 217 562 512 307 563 minecraft:quartz_block
fill 512 217 566 512 217 570 minecraft:quartz_block
setblock 512 217 571 minecraft:smooth_quartz
fill 512 217 572 512 225 573 minecraft:quartz_block
fill 512 217 577 512 218 586 minecraft:quartz_block
fill 512 217 588 512 217 593 minecraft:quartz_block
fill 512 217 595 512 225 596 minecraft:quartz_block
fill 512 217 597 512 218 597 minecraft:smooth_quartz
fill 512 217 598 512 307 598 minecraft:quartz_block
fill 470 218 557 470 219 557 minecraft:smooth_quartz
fill 470 218 558 470 225 563 minecraft:quartz_block
setblock 470 218 564 minecraft:smooth_quartz
fill 470 218 565 470 225 568 minecraft:quartz_block
fill 470 218 570 470 218 585 minecraft:quartz_block
setblock 470 218 586 minecraft:smooth_quartz
fill 470 218 587 470 218 588 minecraft:quartz_block
fill 470 218 594 470 218 597 minecraft:quartz_block
fill 470 218 598 470 218 599 minecraft:smooth_quartz
fill 471 218 557 481 218 557 minecraft:quartz_block
fill 471 218 599 471 225 599 minecraft:quartz_block
setblock 472 218 599 minecraft:smooth_quartz
fill 473 218 599 489 218 599 minecraft:quartz_block
setblock 482 218 557 minecraft:smooth_quartz
fill 483 218 557 483 307 557 minecraft:quartz_block
setblock 484 218 557 minecraft:smooth_quartz
fill 486 218 557 487 307 557 minecraft:quartz_block
setblock 488 218 557 minecraft:smooth_quartz
fill 489 218 557 499 225 557 minecraft:quartz_block
setblock 490 218 599 minecraft:smooth_quartz
fill 491 218 599 502 218 599 minecraft:quartz_block
setblock 500 218 557 minecraft:smooth_quartz
fill 501 218 557 509 218 557 minecraft:quartz_block
setblock 503 218 599 minecraft:smooth_quartz
fill 504 218 599 505 307 599 minecraft:quartz_block
setblock 506 218 599 minecraft:smooth_quartz
fill 507 218 599 512 225 599 minecraft:quartz_block
setblock 510 218 557 minecraft:smooth_quartz
fill 511 218 557 511 307 557 minecraft:quartz_block
setblock 512 218 557 minecraft:smooth_quartz
fill 512 218 559 512 225 559 minecraft:quartz_block
fill 512 218 561 512 225 561 minecraft:quartz_block
fill 512 218 564 512 307 567 minecraft:quartz_block
setblock 512 218 568 minecraft:smooth_quartz
fill 512 218 569 512 218 571 minecraft:quartz_block
fill 512 218 574 512 307 576 minecraft:quartz_block
fill 512 218 587 512 307 590 minecraft:quartz_block
setblock 512 218 591 minecraft:smooth_quartz
fill 512 218 592 512 307 593 minecraft:quartz_block
fill 470 219 564 470 225 564 minecraft:quartz_block
setblock 470 219 569 minecraft:smooth_quartz
fill 470 219 570 470 307 572 minecraft:quartz_block
setblock 470 219 573 minecraft:smooth_quartz
fill 470 219 574 470 307 574 minecraft:quartz_block
setblock 470 219 575 minecraft:smooth_quartz
fill 470 219 576 470 225 586 minecraft:quartz_block
setblock 470 219 587 minecraft:smooth_quartz
fill 470 219 588 470 225 588 minecraft:quartz_block
fill 470 219 594 470 307 595 minecraft:quartz_block
setblock 470 219 596 minecraft:smooth_quartz
fill 470 219 597 470 225 599 minecraft:quartz_block
fill 471 219 557 471 307 557 minecraft:quartz_block
setblock 472 219 557 minecraft:smooth_quartz
fill 472 219 599 474 225 599 minecraft:quartz_block
fill 473 219 557 475 307 557 minecraft:quartz_block
setblock 475 219 599 minecraft:smooth_quartz
setblock 476 219 557 minecraft:smooth_quartz
fill 476 219 599 479 307 599 minecraft:quartz_block
fill 477 219 557 482 225 557 minecraft:quartz_block
setblock 480 219 599 minecraft:smooth_quartz
fill 481 219 599 483 225 599 minecraft:quartz_block
fill 484 219 557 485 307 557 minecraft:quartz_block
setblock 484 219 599 minecraft:smooth_quartz
fill 485 219 599 490 225 599 minecraft:quartz_block
fill 488 219 557 488 307 557 minecraft:quartz_block
setblock 491 219 599 minecraft:smooth_quartz
fill 492 219 599 495 225 599 minecraft:quartz_block
setblock 496 219 599 minecraft:smooth_quartz
fill 497 219 599 503 225 599 minecraft:quartz_block
fill 500 219 557 504 225 557 minecraft:quartz_block
setblock 505 219 557 minecraft:smooth_quartz
fill 506 219 557 510 307 557 minecraft:quartz_block
fill 506 219 599 506 225 599 minecraft:quartz_block
fill 512 219 557 512 307 557 minecraft:quartz_block
fill 512 219 568 512 307 568 minecraft:quartz_block
setblock 512 219 569 minecraft:smooth_quartz
fill 512 219 570 512 225 571 minecraft:quartz_block
fill 512 219 577 512 238 579 minecraft:quartz_block
setblock 512 219 580 minecraft:smooth_quartz
fill 512 219 581 512 225 586 minecraft:quartz_block
fill 512 219 591 512 307 591 minecraft:quartz_block
fill 512 219 594 512 225 594 minecraft:quartz_block
fill 512 219 597 512 225 597 minecraft:quartz_block
fill 470 220 557 470 307 557 minecraft:quartz_block
fill 470 220 569 470 307 569 minecraft:quartz_block
fill 470 220 573 470 307 573 minecraft:quartz_block
fill 470 220 575 470 225 575 minecraft:quartz_block
fill 470 220 587 470 225 587 minecraft:quartz_block
fill 470 220 596 470 307 596 minecraft:quartz_block
fill 472 220 557 472 307 557 minecraft:quartz_block
fill 472 220 567 472 225 569 minecraft:quartz_pillar
fill 472 220 579 472 225 581 minecraft:quartz_pillar
fill 472 220 591 472 225 593 minecraft:quartz_pillar
setblock 473 220 560 minecraft:light[level=14]
setblock 473 220 568 minecraft:light[level=14]
setblock 473 220 576 minecraft:light[level=14]
setblock 473 220 584 minecraft:light[level=14]
setblock 473 220 592 minecraft:light[level=14]
fill 475 220 599 475 307 599 minecraft:quartz_block
fill 476 220 557 476 307 557 minecraft:quartz_block
fill 478 220 597 480 225 597 minecraft:quartz_pillar
fill 480 220 599 480 307 599 minecraft:quartz_block
setblock 481 220 560 minecraft:light[level=14]
setblock 481 220 568 minecraft:light[level=14]
setblock 481 220 576 minecraft:light[level=14]
setblock 481 220 584 minecraft:light[level=14]
setblock 481 220 592 minecraft:light[level=14]
fill 482 220 559 484 225 559 minecraft:quartz_pillar
fill 484 220 599 484 225 599 minecraft:quartz_block
setblock 489 220 560 minecraft:light[level=14]
setblock 489 220 568 minecraft:light[level=14]
setblock 489 220 576 minecraft:light[level=14]
setblock 489 220 584 minecraft:light[level=14]
setblock 489 220 592 minecraft:light[level=14]
fill 490 220 597 492 225 597 minecraft:quartz_pillar
fill 491 220 599 491 307 599 minecraft:quartz_block
fill 494 220 559 496 225 559 minecraft:quartz_pillar
fill 496 220 599 496 225 599 minecraft:quartz_block
setblock 497 220 560 minecraft:light[level=14]
setblock 497 220 568 minecraft:light[level=14]
setblock 497 220 576 minecraft:light[level=14]
setblock 497 220 584 minecraft:light[level=14]
setblock 497 220 592 minecraft:light[level=14]
fill 502 220 597 504 225 597 minecraft:quartz_pillar
fill 505 220 557 505 307 557 minecraft:quartz_block
setblock 505 220 560 minecraft:light[level=14]
setblock 505 220 568 minecraft:light[level=14]
setblock 505 220 576 minecraft:light[level=14]
setblock 505 220 584 minecraft:light[level=14]
setblock 505 220 592 minecraft:light[level=14]
fill 506 220 559 508 225 559 minecraft:quartz_pillar
fill 510 220 567 510 225 569 minecraft:quartz_pillar
fill 510 220 579 510 225 581 minecraft:quartz_pillar
fill 510 220 591 510 225 593 minecraft:quartz_pillar
fill 512 220 569 512 307 569 minecraft:quartz_block
fill 512 220 580 512 238 580 minecraft:quartz_block
fill 504 224 565 508 225 569 minecraft:smooth_quartz
setblock 509 224 567 minecraft:smooth_quartz
fill 471 225 561 471 225 566 minecraft:smooth_quartz
fill 471 225 573 471 225 578 minecraft:smooth_quartz
fill 471 225 585 471 225 590 minecraft:smooth_quartz
fill 471 225 597 471 225 598 minecraft:smooth_quartz
fill 472 225 598 475 225 598 minecraft:smooth_quartz
fill 475 225 558 480 225 558 minecraft:smooth_quartz
fill 482 225 598 487 225 598 minecraft:smooth_quartz
fill 487 225 558 492 225 558 minecraft:smooth_quartz
fill 494 225 598 499 225 598 minecraft:smooth_quartz
fill 499 225 558 504 225 558 minecraft:smooth_quartz
setblock 504 225 562 minecraft:smooth_quartz
setblock 505 225 561 minecraft:smooth_quartz
fill 505 225 564 508 225 564 minecraft:smooth_quartz
fill 506 225 560 507 225 560 minecraft:smooth_quartz
fill 506 225 598 511 225 598 minecraft:smooth_quartz
setblock 508 225 561 minecraft:smooth_quartz
fill 509 225 562 509 225 563 minecraft:smooth_quartz
fill 511 225 558 511 225 563 minecraft:smooth_quartz
fill 511 225 570 511 225 575 minecraft:smooth_quartz
fill 511 225 582 511 225 587 minecraft:smooth_quartz
fill 511 225 594 511 225 597 minecraft:smooth_quartz
fill 470 226 558 470 307 562 minecraft:quartz_block
fill 470 226 563 470 231 566 minecraft:pearlescent_froglight
fill 470 226 567 470 307 568 minecraft:quartz_block
fill 470 226 575 470 231 578 minecraft:pearlescent_froglight
fill 470 226 579 470 307 586 minecraft:quartz_block
fill 470 226 587 470 231 590 minecraft:pearlescent_froglight
fill 470 226 591 470 307 593 minecraft:quartz_block
fill 470 226 597 470 307 598 minecraft:quartz_block
fill 470 226 599 473 231 599 minecraft:pearlescent_froglight
fill 474 226 599 474 307 599 minecraft:quartz_block
fill 477 226 557 480 231 557 minecraft:pearlescent_froglight
fill 481 226 557 482 307 557 minecraft:quartz_block
fill 481 226 599 481 307 599 minecraft:quartz_block
fill 482 226 599 485 231 599 minecraft:pearlescent_froglight
fill 486 226 599 490 307 599 minecraft:quartz_block
fill 489 226 557 492 231 557 minecraft:pearlescent_froglight
fill 492 226 599 493 307 599 minecraft:quartz_block
fill 493 226 557 500 307 557 minecraft:quartz_block
fill 494 226 599 497 231 599 minecraft:pearlescent_froglight
fill 498 226 599 503 307 599 minecraft:quartz_block
fill 501 226 557 504 231 557 minecraft:pearlescent_froglight
fill 505 226 566 507 227 568 minecraft:quartz_pillar
fill 506 226 599 509 231 599 minecraft:pearlescent_froglight
fill 510 226 599 512 307 599 minecraft:quartz_block
fill 512 226 558 512 231 561 minecraft:pearlescent_froglight
fill 512 226 570 512 231 573 minecraft:pearlescent_froglight
fill 512 226 581 512 238 581 minecraft:quartz_block
fill 512 226 582 512 231 585 minecraft:pearlescent_froglight
fill 512 226 586 512 307 586 minecraft:quartz_block
fill 512 226 594 512 231 597 minecraft:pearlescent_froglight
setblock 473 228 560 minecraft:light[level=14]
setblock 473 228 568 minecraft:light[level=14]
setblock 473 228 576 minecraft:light[level=14]
setblock 473 228 584 minecraft:light[level=14]
setblock 473 228 592 minecraft:light[level=14]
setblock 481 228 560 minecraft:light[level=14]
setblock 481 228 568 minecraft:light[level=14]
setblock 481 228 576 minecraft:light[level=14]
setblock 481 228 584 minecraft:light[level=14]
setblock 481 228 592 minecraft:light[level=14]
setblock 489 228 560 minecraft:light[level=14]
setblock 489 228 568 minecraft:light[level=14]
setblock 489 228 576 minecraft:light[level=14]
setblock 489 228 584 minecraft:light[level=14]
setblock 489 228 592 minecraft:light[level=14]
setblock 497 228 560 minecraft:light[level=14]
setblock 497 228 568 minecraft:light[level=14]
setblock 497 228 576 minecraft:light[level=14]
setblock 497 228 584 minecraft:light[level=14]
setblock 497 228 592 minecraft:light[level=14]
setblock 505 228 560 minecraft:light[level=14]
fill 505 228 567 507 230 567 minecraft:quartz_pillar
setblock 505 228 568 minecraft:light[level=14]
setblock 505 228 576 minecraft:light[level=14]
setblock 505 228 584 minecraft:light[level=14]
setblock 505 228 592 minecraft:light[level=14]
fill 506 228 566 506 230 566 minecraft:quartz_pillar
fill 506 228 568 506 230 568 minecraft:quartz_pillar
fill 506 231 567 506 233 567 minecraft:quartz_pillar
fill 470 232 563 470 245 563 minecraft:quartz_block
fill 470 232 564 470 232 565 minecraft:pearlescent_froglight
fill 470 232 566 470 245 566 minecraft:quartz_block
fill 470 232 575 470 245 575 minecraft:quartz_block
fill 470 232 576 470 232 577 minecraft:pearlescent_froglight
fill 470 232 578 470 245 578 minecraft:quartz_block
fill 470 232 587 470 245 587 minecraft:quartz_block
fill 470 232 588 470 232 589 minecraft:pearlescent_froglight
fill 470 232 590 470 245 590 minecraft:quartz_block
fill 470 232 599 470 245 599 minecraft:quartz_block
fill 471 232 599 472 232 599 minecraft:pearlescent_froglight
fill 473 232 599 473 245 599 minecraft:quartz_block
fill 477 232 557 477 245 557 minecraft:quartz_block
fill 478 232 557 479 232 557 minecraft:pearlescent_froglight
fill 480 232 557 480 245 557 minecraft:quartz_block
fill 482 232 599 482 245 599 minecraft:quartz_block
fill 483 232 599 484 232 599 minecraft:pearlescent_froglight
fill 485 232 599 485 245 599 minecraft:quartz_block
fill 489 232 557 489 245 557 minecraft:quartz_block
fill 490 232 557 491 232 557 minecraft:pearlescent_froglight
fill 492 232 557 492 245 557 minecraft:quartz_block
fill 494 232 599 494 245 599 minecraft:quartz_block
fill 495 232 599 496 232 599 minecraft:pearlescent_froglight
fill 497 232 599 497 245 599 minecraft:quartz_block
fill 501 232 557 501 245 557 minecraft:quartz_block
fill 502 232 557 503 232 557 minecraft:pearlescent_froglight
fill 504 232 557 504 245 557 minecraft:quartz_block
fill 505 232 561 505 233 561 minecraft:gold_block
fill 505 232 564 508 233 564 minecraft:gold_block
fill 506 232 560 507 233 560 minecraft:gold_block
fill 506 232 599 506 245 599 minecraft:quartz_block
fill 507 232 599 508 232 599 minecraft:pearlescent_froglight
fill 508 232 561 508 233 561 minecraft:gold_block
fill 509 232 599 509 245 599 minecraft:quartz_block
fill 512 232 558 512 245 558 minecraft:quartz_block
fill 512 232 559 512 232 560 minecraft:pearlescent_froglight
fill 512 232 561 512 245 561 minecraft:quartz_block
fill 512 232 570 512 245 570 minecraft:quartz_block
fill 512 232 571 512 232 572 minecraft:pearlescent_froglight
fill 512 232 573 512 245 573 minecraft:quartz_block
fill 512 232 582 512 238 582 minecraft:quartz_block
fill 512 232 583 512 232 584 minecraft:pearlescent_froglight
fill 512 232 585 512 245 585 minecraft:quartz_block
fill 512 232 594 512 245 594 minecraft:quartz_block
fill 512 232 595 512 232 596 minecraft:pearlescent_froglight
fill 512 232 597 512 245 597 minecraft:quartz_block
fill 470 233 564 470 245 565 minecraft:quartz_block
fill 470 233 576 470 245 577 minecraft:quartz_block
fill 470 233 588 470 245 589 minecraft:quartz_block
fill 471 233 599 472 245 599 minecraft:quartz_block
fill 478 233 557 479 245 557 minecraft:quartz_block
fill 483 233 599 484 245 599 minecraft:quartz_block
fill 490 233 557 491 245 557 minecraft:quartz_block
fill 495 233 599 496 245 599 minecraft:quartz_block
fill 502 233 557 503 245 557 minecraft:quartz_block
fill 507 233 599 508 245 599 minecraft:quartz_block
fill 512 233 559 512 245 560 minecraft:quartz_block
fill 512 233 571 512 245 572 minecraft:quartz_block
fill 512 233 583 512 245 584 minecraft:quartz_block
fill 512 233 595 512 245 596 minecraft:quartz_block
setblock 473 236 560 minecraft:light[level=14]
setblock 473 236 568 minecraft:light[level=14]
setblock 473 236 576 minecraft:light[level=14]
setblock 473 236 584 minecraft:light[level=14]
setblock 473 236 592 minecraft:light[level=14]
setblock 481 236 560 minecraft:light[level=14]
setblock 481 236 568 minecraft:light[level=14]
setblock 481 236 576 minecraft:light[level=14]
setblock 481 236 584 minecraft:light[level=14]
setblock 481 236 592 minecraft:light[level=14]
setblock 489 236 560 minecraft:light[level=14]
setblock 489 236 568 minecraft:light[level=14]
setblock 489 236 576 minecraft:light[level=14]
setblock 489 236 584 minecraft:light[level=14]
setblock 489 236 592 minecraft:light[level=14]
setblock 497 236 560 minecraft:light[level=14]
setblock 497 236 568 minecraft:light[level=14]
setblock 497 236 576 minecraft:light[level=14]
setblock 497 236 584 minecraft:light[level=14]
setblock 497 236 592 minecraft:light[level=14]
setblock 505 236 560 minecraft:light[level=14]
setblock 505 236 568 minecraft:light[level=14]
setblock 505 236 576 minecraft:light[level=14]
setblock 505 236 584 minecraft:light[level=14]
setblock 505 236 592 minecraft:light[level=14]
fill 489 238 576 491 238 578 minecraft:redstone_block
fill 490 238 583 492 238 585 minecraft:redstone_block
fill 494 238 574 496 238 576 minecraft:redstone_block
fill 497 238 582 499 238 584 minecraft:redstone_block
fill 476 239 578 488 239 582 minecraft:gold_block
fill 489 239 579 492 239 582 minecraft:gold_block
fill 492 239 562 493 239 578 minecraft:gold_block
fill 492 239 586 496 239 598 minecraft:gold_block
fill 493 239 582 496 239 585 minecraft:gold_block
fill 494 239 562 496 239 573 minecraft:gold_block
fill 494 239 577 496 239 578 minecraft:gold_block
fill 496 239 579 512 239 581 minecraft:gold_block
fill 497 239 578 512 239 578 minecraft:gold_block
fill 500 239 582 512 239 582 minecraft:gold_block
fill 512 239 577 512 307 577 minecraft:quartz_block
fill 471 240 558 475 240 598 minecraft:smooth_quartz
fill 476 240 558 487 240 577 minecraft:smooth_quartz
fill 476 240 578 487 240 578 minecraft:lapis_block
fill 476 240 579 487 240 581 minecraft:gold_block
fill 476 240 582 488 240 582 minecraft:lapis_block
fill 476 240 583 488 240 598 minecraft:smooth_quartz
fill 488 240 558 491 240 574 minecraft:smooth_quartz
fill 488 240 575 488 240 579 minecraft:pearlescent_froglight
fill 488 240 580 491 240 581 minecraft:gold_block
fill 489 240 575 493 240 575 minecraft:pearlescent_froglight
fill 489 240 576 491 240 578 minecraft:smooth_quartz
fill 489 240 579 492 240 579 minecraft:pearlescent_froglight
fill 489 240 582 489 240 586 minecraft:pearlescent_froglight
fill 489 240 587 491 240 598 minecraft:smooth_quartz
fill 490 240 582 496 240 582 minecraft:pearlescent_froglight
fill 490 240 583 492 240 585 minecraft:smooth_quartz
fill 490 240 586 493 240 586 minecraft:pearlescent_froglight
fill 492 240 558 511 240 561 minecraft:smooth_quartz
fill 492 240 562 492 240 574 minecraft:lapis_block
fill 492 240 576 493 240 578 minecraft:pearlescent_froglight
fill 492 240 580 492 240 581 minecraft:pearlescent_froglight
fill 492 240 587 492 240 598 minecraft:lapis_block
fill 493 240 562 495 240 572 minecraft:gold_block
fill 493 240 573 493 240 574 minecraft:pearlescent_froglight
fill 493 240 583 493 240 585 minecraft:pearlescent_froglight
fill 493 240 587 495 240 598 minecraft:gold_block
fill 494 240 573 497 240 573 minecraft:pearlescent_froglight
fill 494 240 574 496 240 576 minecraft:smooth_quartz
fill 494 240 577 496 240 578 minecraft:pearlescent_froglight
fill 494 240 583 495 240 586 minecraft:gold_block
fill 496 240 562 496 240 572 minecraft:lapis_block
fill 496 240 579 496 240 581 minecraft:pearlescent_froglight
fill 496 240 583 496 240 585 minecraft:pearlescent_froglight
fill 496 240 586 496 240 598 minecraft:lapis_block
fill 497 240 562 511 240 572 minecraft:smooth_quartz
fill 497 240 574 497 240 577 minecraft:pearlescent_froglight
fill 497 240 578 512 240 578 minecraft:lapis_block
fill 497 240 579 512 240 580 minecraft:gold_block
fill 497 240 581 500 240 581 minecraft:pearlescent_froglight
fill 497 240 582 499 240 584 minecraft:smooth_quartz
fill 497 240 585 500 240 585 minecraft:pearlescent_froglight
fill 497 240 586 511 240 598 minecraft:smooth_quartz
fill 498 240 573 511 240 577 minecraft:smooth_quartz
fill 500 240 582 500 240 584 minecraft:pearlescent_froglight
fill 501 240 581 512 240 581 minecraft:gold_block
fill 501 240 582 512 240 582 minecraft:lapis_block
fill 501 240 583 511 240 585 minecraft:smooth_quartz
fill 512 241 578 512 245 582 minecraft:quartz_block
fill 471 244 558 476 244 598 minecraft:quartz_pillar
fill 477 244 558 511 244 563 minecraft:quartz_pillar
fill 477 244 593 505 244 598 minecraft:quartz_pillar
setblock 481 244 568 minecraft:light[level=14]
setblock 481 244 576 minecraft:light[level=14]
setblock 481 244 584 minecraft:light[level=14]
setblock 481 244 592 minecraft:light[level=14]
setblock 489 244 568 minecraft:light[level=14]
setblock 489 244 576 minecraft:light[level=14]
setblock 489 244 584 minecraft:light[level=14]
setblock 489 244 592 minecraft:light[level=14]
setblock 497 244 568 minecraft:light[level=14]
setblock 497 244 576 minecraft:light[level=14]
setblock 497 244 584 minecraft:light[level=14]
setblock 497 244 592 minecraft:light[level=14]
setblock 505 244 568 minecraft:light[level=14]
setblock 505 244 576 minecraft:light[level=14]
setblock 505 244 584 minecraft:light[level=14]
setblock 505 244 592 minecraft:light[level=14]
fill 506 244 564 506 244 591 minecraft:quartz_pillar
fill 506 244 592 506 244 594 minecraft:smooth_quartz
fill 506 244 595 506 244 598 minecraft:quartz_pillar
fill 507 244 564 511 244 590 minecraft:quartz_pillar
fill 507 244 591 509 244 591 minecraft:smooth_quartz
fill 507 244 592 509 273 594 minecraft:quartz_pillar
fill 507 244 595 509 244 595 minecraft:smooth_quartz
fill 507 244 596 511 244 598 minecraft:quartz_pillar
fill 510 244 591 511 244 593 minecraft:quartz_pillar
setblock 510 244 594 minecraft:smooth_quartz
fill 510 244 595 511 244 595 minecraft:quartz_pillar
setblock 511 244 594 minecraft:quartz_pillar
fill 471 245 558 473 273 558 minecraft:quartz_pillar
fill 471 245 561 471 245 566 minecraft:smooth_quartz
fill 471 245 568 471 273 570 minecraft:quartz_pillar
fill 471 245 573 471 245 578 minecraft:smooth_quartz
fill 471 245 580 471 273 582 minecraft:quartz_pillar
fill 471 245 585 471 245 590 minecraft:smooth_quartz
fill 471 245 592 471 273 594 minecraft:quartz_pillar
fill 471 245 597 471 245 598 minecraft:smooth_quartz
fill 472 245 567 472 245 569 minecraft:quartz_pillar
fill 472 245 579 472 245 581 minecraft:quartz_pillar
fill 472 245 591 472 245 593 minecraft:quartz_pillar
fill 472 245 598 475 245 598 minecraft:smooth_quartz
fill 475 245 558 480 245 558 minecraft:smooth_quartz
fill 476 245 563 476 245 593 minecraft:gold_block
fill 477 245 563 506 245 563 minecraft:gold_block
fill 477 245 593 506 245 593 minecraft:gold_block
fill 477 245 598 479 273 598 minecraft:quartz_pillar
fill 478 245 597 480 245 597 minecraft:quartz_pillar
fill 482 245 559 484 245 559 minecraft:quartz_pillar
fill 482 245 598 487 245 598 minecraft:smooth_quartz
fill 483 245 558 485 273 558 minecraft:quartz_pillar
fill 487 245 558 492 245 558 minecraft:smooth_quartz
fill 489 245 598 491 273 598 minecraft:quartz_pillar
fill 490 245 597 492 245 597 minecraft:quartz_pillar
fill 494 245 559 496 245 559 minecraft:quartz_pillar
fill 494 245 598 499 245 598 minecraft:smooth_quartz
fill 495 245 558 497 273 558 minecraft:quartz_pillar
fill 499 245 558 504 245 558 minecraft:smooth_quartz
fill 501 245 598 503 273 598 minecraft:quartz_pillar
fill 502 245 597 504 245 597 minecraft:quartz_pillar
fill 506 245 559 508 245 559 minecraft:quartz_pillar
fill 506 245 564 506 245 592 minecraft:gold_block
fill 506 245 598 511 245 598 minecraft:smooth_quartz
fill 507 245 558 509 273 558 minecraft:quartz_pillar
fill 510 245 567 510 245 569 minecraft:quartz_pillar
fill 510 245 579 510 245 581 minecraft:quartz_pillar
fill 510 245 591 510 245 593 minecraft:quartz_pillar
fill 511 245 558 511 245 563 minecraft:smooth_quartz
fill 511 245 566 511 273 568 minecraft:quartz_pillar
fill 511 245 570 511 245 575 minecraft:smooth_quartz
fill 511 245 578 511 273 580 minecraft:quartz_pillar
fill 511 245 582 511 245 587 minecraft:smooth_quartz
fill 511 245 590 511 273 592 minecraft:quartz_pillar
fill 511 245 594 511 245 597 minecraft:smooth_quartz
fill 470 246 563 470 251 566 minecraft:pearlescent_froglight
fill 470 246 575 470 251 578 minecraft:pearlescent_froglight
fill 470 246 587 470 251 590 minecraft:pearlescent_froglight
fill 470 246 599 473 251 599 minecraft:pearlescent_froglight
fill 471 246 577 477 246 577 minecraft:smooth_quartz
fill 473 246 575 477 247 576 minecraft:smooth_quartz
fill 473 246 578 477 247 579 minecraft:smooth_quartz
fill 477 246 557 480 251 557 minecraft:pearlescent_froglight
fill 482 246 599 485 251 599 minecraft:pearlescent_froglight
fill 489 246 557 492 251 557 minecraft:pearlescent_froglight
fill 494 246 599 497 251 599 minecraft:pearlescent_froglight
fill 501 246 557 504 251 557 minecraft:pearlescent_froglight
fill 506 246 599 509 251 599 minecraft:pearlescent_froglight
fill 509 246 580 509 256 580 minecraft:blue_wool
fill 512 246 558 512 251 561 minecraft:pearlescent_froglight
fill 512 246 570 512 251 573 minecraft:pearlescent_froglight
fill 512 246 578 512 307 581 minecraft:quartz_block
fill 512 246 582 512 251 585 minecraft:pearlescent_froglight
fill 512 246 594 512 251 597 minecraft:pearlescent_froglight
fill 473 247 577 477 247 577 minecraft:smooth_quartz
fill 509 247 578 509 256 579 minecraft:blue_wool
fill 509 247 581 509 256 582 minecraft:blue_wool
fill 474 248 576 476 249 578 minecraft:quartz_pillar
fill 474 250 577 476 252 577 minecraft:quartz_pillar
fill 475 250 576 475 252 576 minecraft:quartz_pillar
fill 475 250 578 475 252 578 minecraft:quartz_pillar
fill 470 252 563 470 265 563 minecraft:quartz_block
fill 470 252 564 470 252 565 minecraft:pearlescent_froglight
fill 470 252 566 470 265 566 minecraft:quartz_block
fill 470 252 575 470 265 575 minecraft:quartz_block
fill 470 252 576 470 252 577 minecraft:pearlescent_froglight
fill 470 252 578 470 265 578 minecraft:quartz_block
fill 470 252 587 470 265 587 minecraft:quartz_block
fill 470 252 588 470 252 589 minecraft:pearlescent_froglight
fill 470 252 590 470 265 590 minecraft:quartz_block
fill 470 252 599 470 265 599 minecraft:quartz_block
fill 471 252 599 472 252 599 minecraft:pearlescent_froglight
setblock 473 252 560 minecraft:light[level=14]
setblock 473 252 568 minecraft:light[level=14]
setblock 473 252 576 minecraft:light[level=14]
setblock 473 252 584 minecraft:light[level=14]
setblock 473 252 592 minecraft:light[level=14]
fill 473 252 599 473 265 599 minecraft:quartz_block
fill 477 252 557 477 265 557 minecraft:quartz_block
fill 478 252 557 479 252 557 minecraft:pearlescent_froglight
fill 480 252 557 480 265 557 minecraft:quartz_block
setblock 481 252 560 minecraft:light[level=14]
setblock 481 252 568 minecraft:light[level=14]
setblock 481 252 576 minecraft:light[level=14]
setblock 481 252 584 minecraft:light[level=14]
setblock 481 252 592 minecraft:light[level=14]
fill 482 252 599 482 265 599 minecraft:quartz_block
fill 483 252 599 484 252 599 minecraft:pearlescent_froglight
fill 485 252 599 485 265 599 minecraft:quartz_block
fill 489 252 557 489 265 557 minecraft:quartz_block
setblock 489 252 560 minecraft:light[level=14]
setblock 489 252 568 minecraft:light[level=14]
setblock 489 252 576 minecraft:light[level=14]
setblock 489 252 584 minecraft:light[level=14]
setblock 489 252 592 minecraft:light[level=14]
fill 490 252 557 491 252 557 minecraft:pearlescent_froglight
fill 492 252 557 492 265 557 minecraft:quartz_block
fill 494 252 599 494 265 599 minecraft:quartz_block
fill 495 252 599 496 252 599 minecraft:pearlescent_froglight
setblock 497 252 560 minecraft:light[level=14]
setblock 497 252 568 minecraft:light[level=14]
setblock 497 252 576 minecraft:light[level=14]
setblock 497 252 584 minecraft:light[level=14]
setblock 497 252 592 minecraft:light[level=14]
fill 497 252 599 497 265 599 minecraft:quartz_block
fill 501 252 557 501 265 557 minecraft:quartz_block
fill 502 252 557 503 252 557 minecraft:pearlescent_froglight
fill 504 252 557 504 265 557 minecraft:quartz_block
setblock 505 252 560 minecraft:light[level=14]
setblock 505 252 568 minecraft:light[level=14]
setblock 505 252 576 minecraft:light[level=14]
setblock 505 252 584 minecraft:light[level=14]
setblock 505 252 592 minecraft:light[level=14]
fill 506 252 592 506 252 594 minecraft:smooth_quartz
fill 506 252 599 506 265 599 minecraft:quartz_block
fill 507 252 591 509 252 591 minecraft:smooth_quartz
fill 507 252 595 509 252 595 minecraft:smooth_quartz
fill 507 252 599 508 252 599 minecraft:pearlescent_froglight
fill 509 252 599 509 265 599 minecraft:quartz_block
fill 510 252 592 510 252 594 minecraft:smooth_quartz
fill 512 252 558 512 265 558 minecraft:quartz_block
fill 512 252 559 512 252 560 minecraft:pearlescent_froglight
fill 512 252 561 512 265 561 minecraft:quartz_block
fill 512 252 570 512 265 570 minecraft:quartz_block
fill 512 252 571 512 252 572 minecraft:pearlescent_froglight
fill 512 252 573 512 265 573 minecraft:quartz_block
fill 512 252 582 512 265 582 minecraft:quartz_block
fill 512 252 583 512 252 584 minecraft:pearlescent_froglight
fill 512 252 585 512 265 585 minecraft:quartz_block
fill 512 252 594 512 265 594 minecraft:quartz_block
fill 512 252 595 512 252 596 minecraft:pearlescent_froglight
fill 512 252 597 512 265 597 minecraft:quartz_block
fill 470 253 564 470 265 565 minecraft:quartz_block
fill 470 253 576 470 265 577 minecraft:quartz_block
fill 470 253 588 470 265 589 minecraft:quartz_block
fill 471 253 599 472 265 599 minecraft:quartz_block
fill 475 253 577 475 257 577 minecraft:quartz_pillar
fill 478 253 557 479 265 557 minecraft:quartz_block
fill 483 253 599 484 265 599 minecraft:quartz_block
fill 490 253 557 491 265 557 minecraft:quartz_block
fill 495 253 599 496 265 599 minecraft:quartz_block
fill 502 253 557 503 265 557 minecraft:quartz_block
fill 507 253 599 508 265 599 minecraft:quartz_block
fill 512 253 559 512 265 560 minecraft:quartz_block
fill 512 253 571 512 265 572 minecraft:quartz_block
fill 512 253 583 512 265 584 minecraft:quartz_block
fill 512 253 595 512 265 596 minecraft:quartz_block
fill 509 257 577 509 258 583 minecraft:iron_block
setblock 475 258 577 minecraft:pearlescent_froglight
fill 472 260 567 472 265 569 minecraft:quartz_pillar
fill 472 260 579 472 265 581 minecraft:quartz_pillar
fill 472 260 591 472 265 593 minecraft:quartz_pillar
setblock 473 260 560 minecraft:light[level=14]
setblock 473 260 568 minecraft:light[level=14]
setblock 473 260 576 minecraft:light[level=14]
setblock 473 260 584 minecraft:light[level=14]
setblock 473 260 592 minecraft:light[level=14]
fill 478 260 597 480 265 597 minecraft:quartz_pillar
setblock 481 260 560 minecraft:light[level=14]
setblock 481 260 568 minecraft:light[level=14]
setblock 481 260 576 minecraft:light[level=14]
setblock 481 260 584 minecraft:light[level=14]
setblock 481 260 592 minecraft:light[level=14]
fill 482 260 559 484 265 559 minecraft:quartz_pillar
setblock 489 260 560 minecraft:light[level=14]
setblock 489 260 568 minecraft:light[level=14]
setblock 489 260 576 minecraft:light[level=14]
setblock 489 260 584 minecraft:light[level=14]
setblock 489 260 592 minecraft:light[level=14]
fill 490 260 597 492 265 597 minecraft:quartz_pillar
fill 494 260 559 496 265 559 minecraft:quartz_pillar
setblock 497 260 560 minecraft:light[level=14]
setblock 497 260 568 minecraft:light[level=14]
setblock 497 260 576 minecraft:light[level=14]
setblock 497 260 584 minecraft:light[level=14]
setblock 497 260 592 minecraft:light[level=14]
fill 502 260 597 504 265 597 minecraft:quartz_pillar
setblock 505 260 560 minecraft:light[level=14]
setblock 505 260 568 minecraft:light[level=14]
setblock 505 260 576 minecraft:light[level=14]
setblock 505 260 584 minecraft:light[level=14]
setblock 505 260 592 minecraft:light[level=14]
fill 506 260 559 508 265 559 minecraft:quartz_pillar
fill 506 260 592 506 260 594 minecraft:smooth_quartz
fill 507 260 591 509 260 591 minecraft:smooth_quartz
fill 507 260 595 509 260 595 minecraft:smooth_quartz
fill 510 260 567 510 265 569 minecraft:quartz_pillar
fill 510 260 579 510 265 581 minecraft:quartz_pillar
fill 510 260 591 510 265 593 minecraft:quartz_pillar
setblock 510 260 594 minecraft:smooth_quartz
fill 472 263 566 472 272 566 minecraft:blue_wool
fill 472 264 564 472 272 565 minecraft:blue_wool
fill 471 265 561 471 265 566 minecraft:smooth_quartz
fill 471 265 573 471 265 578 minecraft:smooth_quartz
fill 471 265 585 471 265 590 minecraft:smooth_quartz
fill 471 265 597 471 265 598 minecraft:smooth_quartz
fill 472 265 598 475 265 598 minecraft:smooth_quartz
fill 475 265 558 480 265 558 minecraft:smooth_quartz
fill 482 265 598 487 265 598 minecraft:smooth_quartz
fill 487 265 558 492 265 558 minecraft:smooth_quartz
fill 494 265 598 499 265 598 minecraft:smooth_quartz
fill 499 265 558 504 265 558 minecraft:smooth_quartz
fill 506 265 598 511 265 598 minecraft:smooth_quartz
fill 511 265 558 511 265 563 minecraft:smooth_quartz
fill 511 265 570 511 265 575 minecraft:smooth_quartz
fill 511 265 582 511 265 587 minecraft:smooth_quartz
fill 511 265 594 511 265 597 minecraft:smooth_quartz
fill 470 266 563 470 271 566 minecraft:pearlescent_froglight
fill 470 266 575 470 271 578 minecraft:pearlescent_froglight
fill 470 266 587 470 271 590 minecraft:pearlescent_froglight
fill 470 266 599 473 271 599 minecraft:pearlescent_froglight
fill 472 266 567 472 272 568 minecraft:blue_wool
fill 477 266 557 480 271 557 minecraft:pearlescent_froglight
fill 482 266 599 485 271 599 minecraft:pearlescent_froglight
fill 489 266 557 492 271 557 minecraft:pearlescent_froglight
fill 494 266 599 497 271 599 minecraft:pearlescent_froglight
fill 501 266 557 504 271 557 minecraft:pearlescent_froglight
fill 506 266 599 509 271 599 minecraft:pearlescent_froglight
fill 512 266 558 512 271 561 minecraft:pearlescent_froglight
fill 512 266 570 512 271 573 minecraft:pearlescent_froglight
fill 512 266 582 512 271 585 minecraft:pearlescent_froglight
fill 512 266 594 512 271 597 minecraft:pearlescent_froglight
setblock 473 268 560 minecraft:light[level=14]
setblock 473 268 568 minecraft:light[level=14]
setblock 473 268 576 minecraft:light[level=14]
setblock 473 268 584 minecraft:light[level=14]
setblock 473 268 592 minecraft:light[level=14]
setblock 481 268 560 minecraft:light[level=14]
setblock 481 268 568 minecraft:light[level=14]
setblock 481 268 576 minecraft:light[level=14]
setblock 481 268 584 minecraft:light[level=14]
setblock 481 268 592 minecraft:light[level=14]
setblock 489 268 560 minecraft:light[level=14]
setblock 489 268 568 minecraft:light[level=14]
setblock 489 268 576 minecraft:light[level=14]
setblock 489 268 584 minecraft:light[level=14]
setblock 489 268 592 minecraft:light[level=14]
setblock 497 268 560 minecraft:light[level=14]
setblock 497 268 568 minecraft:light[level=14]
setblock 497 268 576 minecraft:light[level=14]
setblock 497 268 584 minecraft:light[level=14]
setblock 497 268 592 minecraft:light[level=14]
setblock 505 268 560 minecraft:light[level=14]
setblock 505 268 568 minecraft:light[level=14]
setblock 505 268 576 minecraft:light[level=14]
setblock 505 268 584 minecraft:light[level=14]
setblock 505 268 592 minecraft:light[level=14]
fill 506 268 592 506 268 594 minecraft:smooth_quartz
fill 507 268 591 509 268 591 minecraft:smooth_quartz
fill 507 268 595 509 268 595 minecraft:smooth_quartz
fill 510 268 592 510 268 594 minecraft:smooth_quartz
fill 470 272 563 470 285 563 minecraft:quartz_block
fill 470 272 564 470 272 565 minecraft:pearlescent_froglight
fill 470 272 566 470 285 566 minecraft:quartz_block
fill 470 272 575 470 285 575 minecraft:quartz_block
fill 470 272 576 470 272 577 minecraft:pearlescent_froglight
fill 470 272 578 470 285 578 minecraft:quartz_block
fill 470 272 587 470 285 587 minecraft:quartz_block
fill 470 272 588 470 272 589 minecraft:pearlescent_froglight
fill 470 272 590 470 285 590 minecraft:quartz_block
fill 470 272 599 470 285 599 minecraft:quartz_block
fill 471 272 599 472 272 599 minecraft:pearlescent_froglight
fill 473 272 599 473 285 599 minecraft:quartz_block
fill 477 272 557 477 285 557 minecraft:quartz_block
fill 478 272 557 479 272 557 minecraft:pearlescent_froglight
fill 480 272 557 480 285 557 minecraft:quartz_block
fill 482 272 599 482 285 599 minecraft:quartz_block
fill 483 272 599 484 272 599 minecraft:pearlescent_froglight
fill 485 272 599 485 285 599 minecraft:quartz_block
fill 489 272 557 489 285 557 minecraft:quartz_block
fill 490 272 557 491 272 557 minecraft:pearlescent_froglight
fill 492 272 557 492 285 557 minecraft:quartz_block
fill 494 272 599 494 285 599 minecraft:quartz_block
fill 495 272 599 496 272 599 minecraft:pearlescent_froglight
fill 497 272 599 497 285 599 minecraft:quartz_block
fill 501 272 557 501 285 557 minecraft:quartz_block
fill 502 272 557 503 272 557 minecraft:pearlescent_froglight
fill 504 272 557 504 285 557 minecraft:quartz_block
fill 506 272 592 506 273 594 minecraft:gold_block
fill 506 272 599 506 285 599 minecraft:quartz_block
fill 507 272 591 509 273 591 minecraft:gold_block
fill 507 272 595 509 273 595 minecraft:gold_block
fill 507 272 599 508 272 599 minecraft:pearlescent_froglight
fill 509 272 599 509 285 599 minecraft:quartz_block
fill 510 272 592 510 273 594 minecraft:gold_block
fill 512 272 558 512 285 558 minecraft:quartz_block
fill 512 272 559 512 272 560 minecraft:pearlescent_froglight
fill 512 272 561 512 285 561 minecraft:quartz_block
fill 512 272 570 512 285 570 minecraft:quartz_block
fill 512 272 571 512 272 572 minecraft:pearlescent_froglight
fill 512 272 573 512 285 573 minecraft:quartz_block
fill 512 272 582 512 285 582 minecraft:quartz_block
fill 512 272 583 512 272 584 minecraft:pearlescent_froglight
fill 512 272 585 512 285 585 minecraft:quartz_block
fill 512 272 594 512 285 594 minecraft:quartz_block
fill 512 272 595 512 272 596 minecraft:pearlescent_froglight
fill 512 272 597 512 285 597 minecraft:quartz_block
fill 470 273 564 470 285 565 minecraft:quartz_block
fill 470 273 576 470 285 577 minecraft:quartz_block
fill 470 273 588 470 285 589 minecraft:quartz_block
fill 471 273 599 472 285 599 minecraft:quartz_block
fill 472 273 563 472 273 569 minecraft:iron_block
fill 478 273 557 479 285 557 minecraft:quartz_block
fill 483 273 599 484 285 599 minecraft:quartz_block
fill 490 273 557 491 285 557 minecraft:quartz_block
fill 495 273 599 496 285 599 minecraft:quartz_block
fill 502 273 557 503 285 557 minecraft:quartz_block
fill 507 273 599 508 285 599 minecraft:quartz_block
fill 512 273 559 512 285 560 minecraft:quartz_block
fill 512 273 571 512 285 572 minecraft:quartz_block
fill 512 273 583 512 285 584 minecraft:quartz_block
fill 512 273 595 512 285 596 minecraft:quartz_block
setblock 473 276 560 minecraft:light[level=14]
setblock 473 276 568 minecraft:light[level=14]
setblock 473 276 576 minecraft:light[level=14]
setblock 473 276 584 minecraft:light[level=14]
setblock 473 276 592 minecraft:light[level=14]
setblock 481 276 560 minecraft:light[level=14]
setblock 481 276 568 minecraft:light[level=14]
setblock 481 276 576 minecraft:light[level=14]
setblock 481 276 584 minecraft:light[level=14]
setblock 481 276 592 minecraft:light[level=14]
setblock 489 276 560 minecraft:light[level=14]
setblock 489 276 568 minecraft:light[level=14]
setblock 489 276 576 minecraft:light[level=14]
setblock 489 276 584 minecraft:light[level=14]
setblock 489 276 592 minecraft:light[level=14]
setblock 497 276 560 minecraft:light[level=14]
setblock 497 276 568 minecraft:light[level=14]
setblock 497 276 576 minecraft:light[level=14]
setblock 497 276 584 minecraft:light[level=14]
setblock 497 276 592 minecraft:light[level=14]
setblock 505 276 560 minecraft:light[level=14]
setblock 505 276 568 minecraft:light[level=14]
setblock 505 276 576 minecraft:light[level=14]
setblock 505 276 584 minecraft:light[level=14]
setblock 505 276 592 minecraft:light[level=14]
fill 487 278 578 489 278 580 minecraft:redstone_block
fill 492 278 582 494 278 584 minecraft:redstone_block
fill 496 278 574 498 278 576 minecraft:redstone_block
fill 471 279 568 486 279 588 minecraft:smooth_quartz
fill 472 279 566 510 279 567 minecraft:smooth_quartz
fill 472 279 589 510 279 590 minecraft:smooth_quartz
fill 473 279 565 509 279 565 minecraft:smooth_quartz
fill 473 279 591 509 279 591 minecraft:smooth_quartz
fill 474 279 564 508 279 564 minecraft:smooth_quartz
fill 474 279 592 508 279 592 minecraft:smooth_quartz
fill 475 279 563 507 279 563 minecraft:smooth_quartz
fill 475 279 593 507 279 593 minecraft:smooth_quartz
fill 476 279 562 506 279 562 minecraft:smooth_quartz
fill 476 279 594 506 279 594 minecraft:smooth_quartz
fill 477 279 561 505 279 561 minecraft:smooth_quartz
fill 477 279 595 505 279 595 minecraft:smooth_quartz
fill 478 279 560 504 279 560 minecraft:smooth_quartz
fill 478 279 596 504 279 596 minecraft:smooth_quartz
fill 479 279 559 503 279 559 minecraft:smooth_quartz
fill 479 279 597 503 279 597 minecraft:smooth_quartz
fill 481 279 558 501 279 558 minecraft:smooth_quartz
fill 481 279 598 501 279 598 minecraft:smooth_quartz
fill 487 279 568 490 279 577 minecraft:smooth_quartz
fill 487 279 581 491 279 588 minecraft:smooth_quartz
fill 490 279 578 490 279 580 minecraft:smooth_quartz
fill 491 279 568 491 279 576 minecraft:smooth_quartz
fill 491 279 577 491 279 579 minecraft:gold_block
setblock 491 279 580 minecraft:smooth_quartz
fill 492 279 568 495 279 575 minecraft:smooth_quartz
fill 492 279 576 494 279 576 minecraft:gold_block
fill 492 279 580 494 279 580 minecraft:gold_block
fill 492 279 581 511 279 581 minecraft:smooth_quartz
fill 492 279 585 511 279 588 minecraft:smooth_quartz
setblock 495 279 576 minecraft:smooth_quartz
fill 495 279 577 495 279 579 minecraft:gold_block
fill 495 279 580 511 279 580 minecraft:smooth_quartz
fill 495 279 582 511 279 584 minecraft:smooth_quartz
fill 496 279 568 511 279 573 minecraft:smooth_quartz
fill 496 279 577 511 279 579 minecraft:smooth_quartz
fill 499 279 574 511 279 576 minecraft:smooth_quartz
fill 471 280 558 471 280 568 minecraft:quartz_block
fill 471 280 569 471 280 587 minecraft:smooth_quartz
fill 471 280 588 471 280 598 minecraft:quartz_block
fill 472 280 558 472 280 566 minecraft:quartz_block
fill 472 280 567 472 280 568 minecraft:smooth_quartz
fill 472 280 569 485 280 587 minecraft:quartz_block
fill 472 280 588 472 280 589 minecraft:smooth_quartz
fill 472 280 590 472 280 598 minecraft:quartz_block
fill 473 280 558 473 280 565 minecraft:quartz_block
setblock 473 280 566 minecraft:smooth_quartz
fill 473 280 567 509 280 568 minecraft:quartz_block
fill 473 280 588 509 280 589 minecraft:quartz_block
setblock 473 280 590 minecraft:smooth_quartz
fill 473 280 591 473 280 598 minecraft:quartz_block
fill 474 280 558 474 280 564 minecraft:quartz_block
setblock 474 280 565 minecraft:smooth_quartz
fill 474 280 566 508 280 566 minecraft:quartz_block
fill 474 280 590 508 280 590 minecraft:quartz_block
setblock 474 280 591 minecraft:smooth_quartz
fill 474 280 592 474 280 598 minecraft:quartz_block
fill 475 280 558 475 280 562 minecraft:quartz_block
fill 475 280 563 475 280 564 minecraft:smooth_quartz
fill 475 280 565 507 280 565 minecraft:quartz_block
fill 475 280 591 507 280 591 minecraft:quartz_block
fill 475 280 592 475 280 593 minecraft:smooth_quartz
fill 475 280 594 475 280 598 minecraft:quartz_block
fill 476 280 558 477 280 561 minecraft:quartz_block
fill 476 280 562 477 280 562 minecraft:smooth_quartz
fill 476 280 563 506 280 564 minecraft:quartz_block
fill 476 280 592 506 280 593 minecraft:quartz_block
fill 476 280 594 477 280 594 minecraft:smooth_quartz
fill 476 280 595 477 280 598 minecraft:quartz_block
fill 478 280 558 478 280 560 minecraft:quartz_block
setblock 478 280 561 minecraft:smooth_quartz
fill 478 280 562 504 280 562 minecraft:quartz_block
fill 478 280 594 504 280 594 minecraft:quartz_block
setblock 478 280 595 minecraft:smooth_quartz
fill 478 280 596 478 280 598 minecraft:quartz_block
fill 479 280 558 479 280 559 minecraft:quartz_block
setblock 479 280 560 minecraft:smooth_quartz
fill 479 280 561 503 280 561 minecraft:quartz_block
fill 479 280 595 503 280 595 minecraft:quartz_block
setblock 479 280 596 minecraft:smooth_quartz
fill 479 280 597 479 280 598 minecraft:quartz_block
fill 480 280 558 481 280 558 minecraft:quartz_block
fill 480 280 559 481 280 559 minecraft:smooth_quartz
fill 480 280 560 502 280 560 minecraft:quartz_block
fill 480 280 596 502 280 596 minecraft:quartz_block
fill 480 280 597 481 280 597 minecraft:smooth_quartz
fill 480 280 598 481 280 598 minecraft:quartz_block
fill 482 280 558 500 280 558 minecraft:smooth_quartz
fill 482 280 559 500 280 559 minecraft:quartz_block
fill 482 280 597 500 280 597 minecraft:quartz_block
fill 482 280 598 500 280 598 minecraft:smooth_quartz
fill 486 280 569 488 280 576 minecraft:quartz_block
fill 486 280 577 486 280 581 minecraft:pearlescent_froglight
fill 486 280 582 490 280 587 minecraft:quartz_block
fill 487 280 577 491 280 577 minecraft:pearlescent_froglight
fill 487 280 578 489 280 580 minecraft:quartz_block
fill 487 280 581 495 280 581 minecraft:pearlescent_froglight
fill 489 280 569 489 280 575 minecraft:quartz_block
fill 489 280 576 490 280 576 minecraft:gold_block
fill 490 280 569 491 280 574 minecraft:quartz_block
fill 490 280 575 494 280 575 minecraft:gold_block
fill 490 280 578 491 280 580 minecraft:pearlescent_froglight
fill 491 280 576 495 280 576 minecraft:pearlescent_froglight
fill 491 280 582 491 280 585 minecraft:pearlescent_froglight
fill 491 280 586 510 280 587 minecraft:quartz_block
fill 492 280 569 494 280 573 minecraft:quartz_block
fill 492 280 574 493 280 574 minecraft:gold_block
fill 492 280 580 495 280 580 minecraft:pearlescent_froglight
fill 492 280 582 494 280 584 minecraft:quartz_block
fill 492 280 585 495 280 585 minecraft:pearlescent_froglight
setblock 494 280 574 minecraft:quartz_block
fill 495 280 569 510 280 572 minecraft:quartz_block
fill 495 280 573 495 280 575 minecraft:pearlescent_froglight
fill 495 280 577 495 280 579 minecraft:pearlescent_froglight
fill 495 280 582 495 280 584 minecraft:pearlescent_froglight
fill 496 280 573 499 280 573 minecraft:pearlescent_froglight
fill 496 280 574 498 280 576 minecraft:quartz_block
fill 496 280 577 499 280 577 minecraft:pearlescent_froglight
fill 496 280 578 496 280 580 minecraft:gold_block
fill 496 280 581 510 280 585 minecraft:quartz_block
fill 497 280 578 510 280 580 minecraft:quartz_block
fill 499 280 574 499 280 576 minecraft:pearlescent_froglight
fill 500 280 573 510 282 577 minecraft:quartz_block
fill 501 280 558 511 280 558 minecraft:quartz_block
fill 501 280 559 502 280 559 minecraft:smooth_quartz
fill 501 280 597 502 280 597 minecraft:smooth_quartz
fill 501 280 598 511 280 598 minecraft:quartz_block
fill 503 280 559 511 280 559 minecraft:quartz_block
setblock 503 280 560 minecraft:smooth_quartz
setblock 503 280 596 minecraft:smooth_quartz
fill 503 280 597 511 280 597 minecraft:quartz_block
fill 504 280 560 511 280 560 minecraft:quartz_block
setblock 504 280 561 minecraft:smooth_quartz
setblock 504 280 595 minecraft:smooth_quartz
fill 504 280 596 511 280 596 minecraft:quartz_block
fill 505 280 561 511 280 561 minecraft:quartz_block
fill 505 280 562 506 280 562 minecraft:smooth_quartz
fill 505 280 594 506 280 594 minecraft:smooth_quartz
fill 505 280 595 511 280 595 minecraft:quartz_block
fill 507 280 562 511 280 562 minecraft:quartz_block
fill 507 280 563 507 280 564 minecraft:smooth_quartz
fill 507 280 592 507 280 593 minecraft:smooth_quartz
fill 507 280 594 511 280 594 minecraft:quartz_block
fill 508 280 563 511 280 564 minecraft:quartz_block
setblock 508 280 565 minecraft:smooth_quartz
setblock 508 280 591 minecraft:smooth_quartz
fill 508 280 592 511 280 593 minecraft:quartz_block
fill 509 280 565 511 280 565 minecraft:quartz_block
setblock 509 280 566 minecraft:smooth_quartz
setblock 509 280 590 minecraft:smooth_quartz
fill 509 280 591 511 280 591 minecraft:quartz_block
fill 510 280 566 511 280 566 minecraft:quartz_block
fill 510 280 567 510 280 568 minecraft:smooth_quartz
fill 510 280 588 510 280 589 minecraft:smooth_quartz
fill 510 280 590 511 280 590 minecraft:quartz_block
fill 511 280 567 511 280 568 minecraft:quartz_block
fill 511 280 569 511 280 587 minecraft:smooth_quartz
fill 511 280 588 511 280 589 minecraft:quartz_block
fill 471 281 571 471 281 585 minecraft:smooth_quartz
fill 472 281 569 472 281 570 minecraft:smooth_quartz
fill 472 281 571 486 281 585 minecraft:quartz_block
fill 472 281 586 472 281 587 minecraft:smooth_quartz
fill 473 281 567 473 281 568 minecraft:smooth_quartz
fill 473 281 569 509 281 570 minecraft:quartz_block
fill 473 281 586 509 281 587 minecraft:quartz_block
fill 473 281 588 473 281 589 minecraft:smooth_quartz
setblock 474 281 566 minecraft:smooth_quartz
fill 474 281 567 508 281 568 minecraft:quartz_block
fill 474 281 588 508 281 589 minecraft:quartz_block
setblock 474 281 590 minecraft:smooth_quartz
fill 475 281 564 475 281 565 minecraft:smooth_quartz
fill 475 281 566 507 281 566 minecraft:quartz_block
fill 475 281 590 507 281 590 minecraft:quartz_block
fill 475 281 591 475 281 592 minecraft:smooth_quartz
setblock 476 281 563 minecraft:smooth_quartz
fill 476 281 564 506 281 565 minecraft:quartz_block
fill 476 281 591 506 281 592 minecraft:quartz_block
setblock 476 281 593 minecraft:smooth_quartz
fill 477 281 562 478 281 562 minecraft:smooth_quartz
fill 477 281 563 505 281 563 minecraft:quartz_block
fill 477 281 593 505 281 593 minecraft:quartz_block
fill 477 281 594 478 281 594 minecraft:smooth_quartz
setblock 479 281 561 minecraft:smooth_quartz
fill 479 281 562 503 281 562 minecraft:quartz_block
fill 479 281 594 503 281 594 minecraft:quartz_block
setblock 479 281 595 minecraft:smooth_quartz
fill 480 281 560 481 281 560 minecraft:smooth_quartz
fill 480 281 561 502 281 561 minecraft:quartz_block
fill 480 281 595 502 281 595 minecraft:quartz_block
fill 480 281 596 481 281 596 minecraft:smooth_quartz
fill 482 281 559 483 281 559 minecraft:smooth_quartz
fill 482 281 560 500 281 560 minecraft:quartz_block
fill 482 281 596 500 281 596 minecraft:quartz_block
fill 482 281 597 483 281 597 minecraft:smooth_quartz
fill 484 281 558 498 281 558 minecraft:smooth_quartz
fill 484 281 559 498 281 559 minecraft:quartz_block
fill 484 281 597 498 281 597 minecraft:quartz_block
fill 484 281 598 498 281 598 minecraft:smooth_quartz
fill 487 281 571 487 281 575 minecraft:quartz_block
fill 487 281 576 488 281 580 minecraft:gold_block
fill 487 281 581 487 281 585 minecraft:quartz_block
fill 488 281 571 488 281 574 minecraft:quartz_block
fill 488 281 575 489 281 575 minecraft:gold_block
fill 488 281 581 489 281 581 minecraft:gold_block
fill 488 281 582 488 281 585 minecraft:quartz_block
fill 489 281 571 489 281 573 minecraft:quartz_block
fill 489 281 574 491 281 574 minecraft:gold_block
fill 489 281 582 491 281 582 minecraft:gold_block
fill 489 281 583 489 281 585 minecraft:quartz_block
fill 490 281 571 510 281 572 minecraft:quartz_block
fill 490 281 573 495 281 573 minecraft:gold_block
fill 490 281 583 495 281 583 minecraft:gold_block
fill 490 281 584 510 281 585 minecraft:quartz_block
fill 494 281 574 496 281 574 minecraft:gold_block
fill 494 281 582 496 281 582 minecraft:gold_block
fill 496 281 573 499 281 573 minecraft:quartz_block
fill 496 281 575 497 281 575 minecraft:gold_block
fill 496 281 581 497 281 581 minecraft:gold_block
fill 496 281 583 510 281 583 minecraft:quartz_block
fill 497 281 574 499 281 574 minecraft:quartz_block
fill 497 281 576 497 281 580 minecraft:gold_block
fill 497 281 582 510 281 582 minecraft:quartz_block
fill 498 281 575 499 281 577 minecraft:quartz_block
setblock 498 281 578 minecraft:gold_block
fill 498 281 579 510 281 581 minecraft:quartz_block
fill 499 281 559 500 281 559 minecraft:smooth_quartz
fill 499 281 578 510 281 578 minecraft:quartz_block
fill 499 281 597 500 281 597 minecraft:smooth_quartz
fill 501 281 560 502 281 560 minecraft:smooth_quartz
fill 501 281 596 502 281 596 minecraft:smooth_quartz
setblock 503 281 561 minecraft:smooth_quartz
setblock 503 281 595 minecraft:smooth_quartz
fill 504 281 562 505 281 562 minecraft:smooth_quartz
fill 504 281 594 505 281 594 minecraft:smooth_quartz
setblock 506 281 563 minecraft:smooth_quartz
setblock 506 281 593 minecraft:smooth_quartz
fill 507 281 564 507 281 565 minecraft:smooth_quartz
fill 507 281 591 507 281 592 minecraft:smooth_quartz
setblock 508 281 566 minecraft:smooth_quartz
setblock 508 281 590 minecraft:smooth_quartz
fill 509 281 567 509 281 568 minecraft:smooth_quartz
fill 509 281 588 509 281 589 minecraft:smooth_quartz
fill 510 281 569 510 281 570 minecraft:smooth_quartz
fill 510 281 586 510 281 587 minecraft:smooth_quartz
fill 511 281 571 511 281 585 minecraft:smooth_quartz
fill 471 282 573 471 282 583 minecraft:smooth_quartz
fill 472 282 570 472 282 572 minecraft:smooth_quartz
fill 472 282 573 484 282 583 minecraft:quartz_block
fill 472 282 584 472 282 586 minecraft:smooth_quartz
fill 473 282 568 473 282 569 minecraft:smooth_quartz
fill 473 282 570 487 282 572 minecraft:quartz_block
fill 473 282 584 487 282 586 minecraft:quartz_block
fill 473 282 587 473 282 588 minecraft:smooth_quartz
setblock 474 282 567 minecraft:smooth_quartz
fill 474 282 568 508 282 569 minecraft:quartz_block
fill 474 282 587 508 282 588 minecraft:quartz_block
setblock 474 282 589 minecraft:smooth_quartz
fill 475 282 565 475 282 566 minecraft:smooth_quartz
fill 475 282 567 507 282 567 minecraft:quartz_block
fill 475 282 589 507 282 589 minecraft:quartz_block
fill 475 282 590 475 282 591 minecraft:smooth_quartz
setblock 476 282 564 minecraft:smooth_quartz
fill 476 282 565 506 282 566 minecraft:quartz_block
fill 476 282 590 506 282 591 minecraft:quartz_block
setblock 476 282 592 minecraft:smooth_quartz
setblock 477 282 563 minecraft:smooth_quartz
fill 477 282 564 505 282 564 minecraft:quartz_block
fill 477 282 592 505 282 592 minecraft:quartz_block
setblock 477 282 593 minecraft:smooth_quartz
fill 478 282 562 479 282 562 minecraft:smooth_quartz
fill 478 282 563 504 282 563 minecraft:quartz_block
fill 478 282 593 504 282 593 minecraft:quartz_block
fill 478 282 594 479 282 594 minecraft:smooth_quartz
setblock 480 282 561 minecraft:smooth_quartz
fill 480 282 562 502 282 562 minecraft:quartz_block
fill 480 282 594 502 282 594 minecraft:quartz_block
setblock 480 282 595 minecraft:smooth_quartz
fill 481 282 560 482 282 560 minecraft:smooth_quartz
fill 481 282 561 501 282 561 minecraft:quartz_block
fill 481 282 595 501 282 595 minecraft:quartz_block
fill 481 282 596 482 282 596 minecraft:smooth_quartz
fill 483 282 559 485 282 559 minecraft:smooth_quartz
fill 483 282 560 499 282 560 minecraft:quartz_block
fill 483 282 596 499 282 596 minecraft:quartz_block
fill 483 282 597 485 282 597 minecraft:smooth_quartz
fill 485 282 573 485 282 575 minecraft:quartz_block
fill 485 282 576 486 282 580 minecraft:gold_block
fill 485 282 581 485 282 583 minecraft:quartz_block
fill 486 282 558 496 282 558 minecraft:smooth_quartz
fill 486 282 559 496 282 559 minecraft:quartz_block
setblock 486 282 573 minecraft:quartz_block
fill 486 282 574 487 282 575 minecraft:gold_block
fill 486 282 581 487 282 582 minecraft:gold_block
setblock 486 282 583 minecraft:quartz_block
fill 486 282 597 496 282 597 minecraft:quartz_block
fill 486 282 598 496 282 598 minecraft:smooth_quartz
fill 487 282 573 489 282 573 minecraft:gold_block
fill 487 282 583 489 282 583 minecraft:gold_block
fill 488 282 570 489 282 571 minecraft:quartz_block
fill 488 282 572 496 282 572 minecraft:gold_block
setblock 488 282 574 minecraft:gold_block
setblock 488 282 582 minecraft:gold_block
fill 488 282 584 496 282 584 minecraft:gold_block
fill 488 282 585 489 282 586 minecraft:quartz_block
fill 490 282 570 509 282 570 minecraft:quartz_block
fill 490 282 571 494 282 571 minecraft:gold_block
fill 490 282 585 494 282 585 minecraft:gold_block
fill 490 282 586 509 282 586 minecraft:quartz_block
fill 495 282 571 509 282 571 minecraft:quartz_block
fill 495 282 585 509 282 585 minecraft:quartz_block
fill 496 282 573 497 282 573 minecraft:gold_block
fill 496 282 583 497 282 583 minecraft:gold_block
fill 497 282 559 499 282 559 minecraft:smooth_quartz
fill 497 282 572 509 282 572 minecraft:quartz_block
fill 497 282 574 498 282 574 minecraft:gold_block
fill 497 282 582 498 282 582 minecraft:gold_block
fill 497 282 584 509 282 584 minecraft:quartz_block
fill 497 282 597 499 282 597 minecraft:smooth_quartz
fill 498 282 573 499 282 573 minecraft:quartz_block
fill 498 282 575 498 282 577 minecraft:gold_block
fill 498 282 579 498 282 581 minecraft:gold_block
fill 498 282 583 510 282 583 minecraft:quartz_block
fill 499 282 574 499 282 575 minecraft:quartz_block
fill 499 282 576 499 282 580 minecraft:gold_block
fill 499 282 581 510 282 582 minecraft:quartz_block
fill 500 282 560 501 282 560 minecraft:smooth_quartz
fill 500 282 578 510 282 580 minecraft:quartz_block
fill 500 282 596 501 282 596 minecraft:smooth_quartz
setblock 502 282 561 minecraft:smooth_quartz
setblock 502 282 595 minecraft:smooth_quartz
fill 503 282 562 504 282 562 minecraft:smooth_quartz
fill 503 282 594 504 282 594 minecraft:smooth_quartz
setblock 505 282 563 minecraft:smooth_quartz
setblock 505 282 593 minecraft:smooth_quartz
setblock 506 282 564 minecraft:smooth_quartz
setblock 506 282 592 minecraft:smooth_quartz
fill 507 282 565 507 282 566 minecraft:smooth_quartz
fill 507 282 590 507 282 591 minecraft:smooth_quartz
setblock 508 282 567 minecraft:smooth_quartz
setblock 508 282 589 minecraft:smooth_quartz
fill 509 282 568 509 282 569 minecraft:smooth_quartz
fill 509 282 587 509 282 588 minecraft:smooth_quartz
fill 510 282 570 510 282 572 minecraft:smooth_quartz
fill 510 282 584 510 282 586 minecraft:smooth_quartz
fill 511 282 573 511 282 583 minecraft:smooth_quartz
fill 472 283 573 472 283 583 minecraft:smooth_quartz
fill 473 283 570 473 283 572 minecraft:smooth_quartz
fill 473 283 573 482 283 583 minecraft:quartz_block
fill 473 283 584 473 283 586 minecraft:smooth_quartz
fill 474 283 568 474 283 569 minecraft:smooth_quartz
fill 474 283 570 485 283 572 minecraft:quartz_block
fill 474 283 584 485 283 586 minecraft:quartz_block
fill 474 283 587 474 283 588 minecraft:smooth_quartz
setblock 475 283 567 minecraft:smooth_quartz
fill 475 283 568 507 283 569 minecraft:quartz_block
fill 475 283 587 507 283 588 minecraft:quartz_block
setblock 475 283 589 minecraft:smooth_quartz
fill 476 283 565 476 283 566 minecraft:smooth_quartz
fill 476 283 567 506 283 567 minecraft:quartz_block
fill 476 283 589 506 283 589 minecraft:quartz_block
fill 476 283 590 476 283 591 minecraft:smooth_quartz
fill 477 283 564 477 283 565 minecraft:smooth_quartz
fill 477 283 566 505 283 566 minecraft:quartz_block
fill 477 283 590 505 283 590 minecraft:quartz_block
fill 477 283 591 477 283 592 minecraft:smooth_quartz
fill 478 283 563 478 283 564 minecraft:smooth_quartz
fill 478 283 565 504 283 565 minecraft:quartz_block
fill 478 283 591 504 283 591 minecraft:quartz_block
fill 478 283 592 478 283 593 minecraft:smooth_quartz
setblock 479 283 563 minecraft:smooth_quartz
fill 479 283 564 503 283 564 minecraft:quartz_block
fill 479 283 592 503 283 592 minecraft:quartz_block
setblock 479 283 593 minecraft:smooth_quartz
setblock 480 283 562 minecraft:smooth_quartz
fill 480 283 563 502 283 563 minecraft:quartz_block
fill 480 283 593 502 283 593 minecraft:quartz_block
setblock 480 283 594 minecraft:smooth_quartz
fill 481 283 561 482 283 561 minecraft:smooth_quartz
fill 481 283 562 501 283 562 minecraft:quartz_block
fill 481 283 594 501 283 594 minecraft:quartz_block
fill 481 283 595 482 283 595 minecraft:smooth_quartz
fill 483 283 560 485 283 560 minecraft:smooth_quartz
fill 483 283 561 499 283 561 minecraft:quartz_block
fill 483 283 573 483 283 575 minecraft:quartz_block
fill 483 283 576 484 283 580 minecraft:gold_block
fill 483 283 581 483 283 583 minecraft:quartz_block
fill 483 283 595 499 283 595 minecraft:quartz_block
fill 483 283 596 485 283 596 minecraft:smooth_quartz
setblock 484 283 573 minecraft:quartz_block
fill 484 283 574 485 283 575 minecraft:gold_block
fill 484 283 581 485 283 582 minecraft:gold_block
setblock 484 283 583 minecraft:quartz_block
fill 485 283 573 486 283 573 minecraft:gold_block
fill 485 283 583 486 283 583 minecraft:gold_block
fill 486 283 559 496 283 559 minecraft:smooth_quartz
fill 486 283 560 496 283 560 minecraft:quartz_block
fill 486 283 570 486 283 571 minecraft:quartz_block
fill 486 283 572 487 283 572 minecraft:gold_block
fill 486 283 584 487 283 584 minecraft:gold_block
fill 486 283 585 486 283 586 minecraft:quartz_block
fill 486 283 596 496 283 596 minecraft:quartz_block
fill 486 283 597 496 283 597 minecraft:smooth_quartz
setblock 487 283 570 minecraft:quartz_block
fill 487 283 571 489 283 571 minecraft:gold_block
fill 487 283 585 489 283 585 minecraft:gold_block
setblock 487 283 586 minecraft:quartz_block
fill 488 283 570 495 283 570 minecraft:gold_block
fill 488 283 586 495 283 586 minecraft:gold_block
fill 495 283 571 497 283 571 minecraft:gold_block
fill 495 283 585 497 283 585 minecraft:gold_block
fill 496 283 570 508 283 570 minecraft:quartz_block
fill 496 283 586 508 283 586 minecraft:quartz_block
fill 497 283 560 499 283 560 minecraft:smooth_quartz
fill 497 283 572 498 283 572 minecraft:gold_block
fill 497 283 584 498 283 584 minecraft:gold_block
fill 497 283 596 499 283 596 minecraft:smooth_quartz
fill 498 283 571 508 283 571 minecraft:quartz_block
fill 498 283 573 499 283 573 minecraft:gold_block
fill 498 283 583 499 283 583 minecraft:gold_block
fill 498 283 585 508 283 585 minecraft:quartz_block
fill 499 283 572 508 283 572 minecraft:quartz_block
fill 499 283 574 499 283 575 minecraft:gold_block
fill 499 283 581 499 283 582 minecraft:gold_block
fill 499 283 584 508 283 584 minecraft:quartz_block
fill 500 283 561 501 283 561 minecraft:smooth_quartz
fill 500 283 573 509 283 574 minecraft:quartz_block
fill 500 283 575 500 283 581 minecraft:gold_block
fill 500 283 582 509 283 583 minecraft:quartz_block
fill 500 283 595 501 283 595 minecraft:smooth_quartz
fill 501 283 575 509 283 581 minecraft:quartz_block
setblock 502 283 562 minecraft:smooth_quartz
setblock 502 283 594 minecraft:smooth_quartz
fill 503 283 563 504 283 563 minecraft:smooth_quartz
fill 503 283 593 504 283 593 minecraft:smooth_quartz
fill 504 283 564 505 283 564 minecraft:smooth_quartz
fill 504 283 592 505 283 592 minecraft:smooth_quartz
fill 505 283 565 506 283 565 minecraft:smooth_quartz
fill 505 283 591 506 283 591 minecraft:smooth_quartz
setblock 506 283 566 minecraft:smooth_quartz
setblock 506 283 590 minecraft:smooth_quartz
setblock 507 283 567 minecraft:smooth_quartz
setblock 507 283 589 minecraft:smooth_quartz
fill 508 283 568 508 283 569 minecraft:smooth_quartz
fill 508 283 587 508 283 588 minecraft:smooth_quartz
fill 509 283 570 509 283 572 minecraft:smooth_quartz
fill 509 283 584 509 283 586 minecraft:smooth_quartz
fill 510 283 573 510 283 583 minecraft:smooth_quartz
fill 471 284 558 473 300 558 minecraft:quartz_pillar
fill 471 284 568 471 300 570 minecraft:quartz_pillar
fill 471 284 580 471 300 582 minecraft:quartz_pillar
fill 471 284 592 471 300 594 minecraft:quartz_pillar
fill 472 284 567 472 285 569 minecraft:quartz_pillar
fill 472 284 579 472 285 581 minecraft:quartz_pillar
fill 472 284 591 472 285 593 minecraft:quartz_pillar
fill 472 284 594 472 284 595 minecraft:smooth_quartz
setblock 473 284 560 minecraft:light[level=14]
setblock 473 284 568 minecraft:light[level=14]
fill 473 284 573 473 284 583 minecraft:smooth_quartz
setblock 473 284 584 minecraft:light[level=14]
fill 473 284 592 476 284 592 minecraft:smooth_quartz
fill 473 284 593 475 300 595 minecraft:quartz_pillar
fill 473 284 596 476 284 596 minecraft:smooth_quartz
fill 474 284 570 474 284 572 minecraft:smooth_quartz
fill 474 284 573 480 284 583 minecraft:quartz_block
fill 474 284 584 474 284 586 minecraft:smooth_quartz
fill 475 284 568 475 284 570 minecraft:smooth_quartz
fill 475 284 571 482 284 572 minecraft:quartz_block
fill 475 284 584 482 284 585 minecraft:quartz_block
fill 475 284 586 475 284 588 minecraft:smooth_quartz
fill 476 284 567 476 284 568 minecraft:smooth_quartz
fill 476 284 569 484 284 570 minecraft:quartz_block
fill 476 284 586 484 284 587 minecraft:quartz_block
fill 476 284 588 476 284 589 minecraft:smooth_quartz
setblock 476 284 593 minecraft:smooth_quartz
fill 476 284 594 476 300 594 minecraft:quartz_pillar
setblock 476 284 595 minecraft:smooth_quartz
setblock 477 284 566 minecraft:smooth_quartz
fill 477 284 567 487 284 568 minecraft:quartz_block
fill 477 284 588 487 284 589 minecraft:quartz_block
setblock 477 284 590 minecraft:smooth_quartz
fill 477 284 598 479 300 598 minecraft:quartz_pillar
setblock 478 284 565 minecraft:smooth_quartz
fill 478 284 566 504 284 566 minecraft:quartz_block
fill 478 284 590 504 284 590 minecraft:quartz_block
setblock 478 284 591 minecraft:smooth_quartz
fill 478 284 597 480 285 597 minecraft:quartz_pillar
setblock 479 284 564 minecraft:smooth_quartz
fill 479 284 565 503 284 565 minecraft:quartz_block
fill 479 284 591 503 284 591 minecraft:quartz_block
setblock 479 284 592 minecraft:smooth_quartz
fill 480 284 563 481 284 563 minecraft:smooth_quartz
fill 480 284 564 502 284 564 minecraft:quartz_block
fill 480 284 592 502 284 592 minecraft:quartz_block
fill 480 284 593 481 284 593 minecraft:smooth_quartz
setblock 481 284 560 minecraft:light[level=14]
fill 481 284 562 483 284 562 minecraft:smooth_quartz
fill 481 284 573 481 284 576 minecraft:quartz_block
fill 481 284 577 482 284 579 minecraft:gold_block
fill 481 284 580 481 284 583 minecraft:quartz_block
fill 481 284 594 483 284 594 minecraft:smooth_quartz
fill 482 284 559 484 285 559 minecraft:quartz_pillar
fill 482 284 563 500 284 563 minecraft:quartz_block
setblock 482 284 573 minecraft:quartz_block
fill 482 284 574 482 284 576 minecraft:gold_block
fill 482 284 580 482 284 582 minecraft:gold_block
setblock 482 284 583 minecraft:quartz_block
fill 482 284 593 500 284 593 minecraft:quartz_block
fill 483 284 558 485 300 558 minecraft:quartz_pillar
fill 483 284 561 485 284 561 minecraft:smooth_quartz
setblock 483 284 571 minecraft:quartz_block
fill 483 284 572 483 284 575 minecraft:gold_block
fill 483 284 581 483 284 584 minecraft:gold_block
setblock 483 284 585 minecraft:quartz_block
fill 483 284 595 485 284 595 minecraft:smooth_quartz
fill 484 284 562 498 284 562 minecraft:quartz_block
fill 484 284 571 484 284 573 minecraft:gold_block
fill 484 284 583 484 284 585 minecraft:gold_block
fill 484 284 594 498 284 594 minecraft:quartz_block
setblock 485 284 569 minecraft:quartz_block
fill 485 284 570 485 284 572 minecraft:gold_block
fill 485 284 584 485 284 586 minecraft:gold_block
setblock 485 284 587 minecraft:quartz_block
fill 486 284 560 496 284 560 minecraft:smooth_quartz
fill 486 284 561 496 284 561 minecraft:quartz_block
fill 486 284 569 486 284 571 minecraft:gold_block
fill 486 284 585 486 284 587 minecraft:gold_block
fill 486 284 595 496 284 595 minecraft:quartz_block
fill 486 284 596 496 284 596 minecraft:smooth_quartz
fill 487 284 569 487 284 570 minecraft:gold_block
fill 487 284 586 487 284 587 minecraft:gold_block
fill 488 284 567 505 284 567 minecraft:quartz_block
fill 488 284 568 494 284 569 minecraft:gold_block
fill 488 284 587 494 284 588 minecraft:gold_block
fill 488 284 589 505 284 589 minecraft:quartz_block
setblock 489 284 576 minecraft:light[level=14]
setblock 489 284 584 minecraft:light[level=14]
fill 489 284 598 491 300 598 minecraft:quartz_pillar
fill 490 284 597 492 285 597 minecraft:quartz_pillar
fill 494 284 559 496 285 559 minecraft:quartz_pillar
fill 495 284 558 497 300 558 minecraft:quartz_pillar
fill 495 284 568 505 284 568 minecraft:quartz_block
fill 495 284 569 496 284 569 minecraft:gold_block
fill 495 284 587 496 284 587 minecraft:gold_block
fill 495 284 588 505 284 588 minecraft:quartz_block
fill 496 284 570 498 284 570 minecraft:gold_block
fill 496 284 586 498 284 586 minecraft:gold_block
setblock 497 284 560 minecraft:light[level=14]
fill 497 284 561 499 284 561 minecraft:smooth_quartz
fill 497 284 569 506 284 569 minecraft:quartz_block
setblock 497 284 576 minecraft:light[level=14]
setblock 497 284 584 minecraft:light[level=14]
fill 497 284 587 506 284 587 minecraft:quartz_block
fill 497 284 595 499 284 595 minecraft:smooth_quartz
fill 498 284 571 499 284 571 minecraft:gold_block
fill 498 284 585 499 284 585 minecraft:gold_block
fill 499 284 562 501 284 562 minecraft:smooth_quartz
fill 499 284 570 506 284 570 minecraft:quartz_block
fill 499 284 572 500 284 572 minecraft:gold_block
fill 499 284 584 500 284 584 minecraft:gold_block
fill 499 284 586 506 284 586 minecraft:quartz_block
fill 499 284 594 501 284 594 minecraft:smooth_quartz
fill 500 284 571 507 284 571 minecraft:quartz_block
fill 500 284 573 500 284 574 minecraft:gold_block
fill 500 284 582 500 284 583 minecraft:gold_block
fill 500 284 585 507 284 585 minecraft:quartz_block
fill 501 284 563 502 284 563 minecraft:smooth_quartz
fill 501 284 572 507 284 573 minecraft:quartz_block
fill 501 284 574 501 284 582 minecraft:gold_block
fill 501 284 583 507 284 584 minecraft:quartz_block
fill 501 284 593 502 284 593 minecraft:smooth_quartz
fill 501 284 598 503 300 598 minecraft:quartz_pillar
fill 502 284 574 508 284 577 minecraft:quartz_block
setblock 502 284 578 minecraft:gold_block
fill 502 284 579 508 284 582 minecraft:quartz_block
fill 502 284 597 504 285 597 minecraft:quartz_pillar
setblock 503 284 564 minecraft:smooth_quartz
fill 503 284 578 508 284 578 minecraft:quartz_block
setblock 503 284 592 minecraft:smooth_quartz
setblock 504 284 565 minecraft:smooth_quartz
setblock 504 284 591 minecraft:smooth_quartz
setblock 505 284 560 minecraft:light[level=14]
setblock 505 284 566 minecraft:smooth_quartz
setblock 505 284 590 minecraft:smooth_quartz
setblock 505 284 592 minecraft:light[level=14]
fill 505 284 594 505 284 596 minecraft:smooth_quartz
fill 506 284 559 508 285 559 minecraft:quartz_pillar
fill 506 284 567 506 284 568 minecraft:smooth_quartz
fill 506 284 588 506 284 589 minecraft:smooth_quartz
setblock 506 284 593 minecraft:smooth_quartz
fill 506 284 594 508 300 596 minecraft:quartz_pillar
fill 506 284 597 508 284 597 minecraft:smooth_quartz
fill 507 284 558 509 300 558 minecraft:quartz_pillar
fill 507 284 568 507 284 570 minecraft:smooth_quartz
fill 507 284 586 507 284 588 minecraft:smooth_quartz
fill 507 284 593 507 300 593 minecraft:quartz_pillar
fill 508 284 570 508 284 572 minecraft:smooth_quartz
setblock 508 284 573 minecraft:quartz_block
setblock 508 284 583 minecraft:quartz_block
fill 508 284 584 508 284 586 minecraft:smooth_quartz
fill 508 284 593 509 284 593 minecraft:smooth_quartz
fill 509 284 563 509 287 567 minecraft:blue_wool
fill 509 284 573 509 284 583 minecraft:smooth_quartz
fill 509 284 594 509 284 596 minecraft:smooth_quartz
fill 510 284 567 510 285 569 minecraft:quartz_pillar
fill 510 284 579 510 285 581 minecraft:quartz_pillar
fill 510 284 591 510 285 593 minecraft:quartz_pillar
fill 511 284 566 511 300 568 minecraft:quartz_pillar
fill 511 284 578 511 300 580 minecraft:quartz_pillar
fill 511 284 590 511 300 592 minecraft:quartz_pillar
fill 471 285 561 471 285 566 minecraft:smooth_quartz
fill 471 285 573 471 285 578 minecraft:smooth_quartz
fill 471 285 585 471 285 590 minecraft:smooth_quartz
fill 471 285 597 471 285 598 minecraft:smooth_quartz
fill 472 285 598 475 285 598 minecraft:smooth_quartz
fill 474 285 573 474 285 583 minecraft:smooth_quartz
fill 475 285 558 480 285 558 minecraft:smooth_quartz
fill 475 285 571 475 285 575 minecraft:smooth_quartz
fill 475 285 576 478 285 580 minecraft:quartz_block
fill 475 285 581 475 285 585 minecraft:smooth_quartz
fill 476 285 569 476 285 571 minecraft:smooth_quartz
fill 476 285 572 479 285 575 minecraft:quartz_block
fill 476 285 581 479 285 584 minecraft:quartz_block
fill 476 285 585 476 285 587 minecraft:smooth_quartz
fill 477 285 567 477 285 569 minecraft:smooth_quartz
fill 477 285 570 481 285 571 minecraft:quartz_block
fill 477 285 585 481 285 586 minecraft:quartz_block
fill 477 285 587 477 285 589 minecraft:smooth_quartz
fill 478 285 566 478 285 568 minecraft:smooth_quartz
fill 478 285 569 482 285 569 minecraft:quartz_block
fill 478 285 587 482 285 587 minecraft:quartz_block
fill 478 285 588 478 285 590 minecraft:smooth_quartz
fill 479 285 565 479 285 567 minecraft:smooth_quartz
fill 479 285 568 484 285 568 minecraft:quartz_block
setblock 479 285 576 minecraft:quartz_block
fill 479 285 577 480 285 579 minecraft:gold_block
setblock 479 285 580 minecraft:quartz_block
fill 479 285 588 484 285 588 minecraft:quartz_block
fill 479 285 589 479 285 591 minecraft:smooth_quartz
fill 480 285 564 480 285 566 minecraft:smooth_quartz
fill 480 285 567 485 285 567 minecraft:quartz_block
fill 480 285 572 480 285 573 minecraft:quartz_block
fill 480 285 574 481 285 576 minecraft:gold_block
fill 480 285 580 481 285 582 minecraft:gold_block
fill 480 285 583 480 285 584 minecraft:quartz_block
fill 480 285 589 485 285 589 minecraft:quartz_block
fill 480 285 590 480 285 592 minecraft:smooth_quartz
fill 481 285 564 481 285 565 minecraft:smooth_quartz
fill 481 285 566 488 285 566 minecraft:quartz_block
fill 481 285 572 482 285 573 minecraft:gold_block
fill 481 285 583 482 285 584 minecraft:gold_block
fill 481 285 590 488 285 590 minecraft:quartz_block
fill 481 285 591 481 285 592 minecraft:smooth_quartz
fill 482 285 563 482 285 564 minecraft:smooth_quartz
fill 482 285 565 500 285 565 minecraft:quartz_block
fill 482 285 570 483 285 571 minecraft:gold_block
fill 482 285 585 483 285 586 minecraft:gold_block
fill 482 285 591 500 285 591 minecraft:quartz_block
fill 482 285 592 482 285 593 minecraft:smooth_quartz
fill 482 285 598 487 285 598 minecraft:smooth_quartz
fill 483 285 563 484 285 563 minecraft:smooth_quartz
fill 483 285 564 499 285 564 minecraft:quartz_block
fill 483 285 569 485 285 569 minecraft:gold_block
fill 483 285 587 485 285 587 minecraft:gold_block
fill 483 285 592 499 285 592 minecraft:quartz_block
fill 483 285 593 484 285 593 minecraft:smooth_quartz
fill 484 285 562 488 285 562 minecraft:smooth_quartz
setblock 484 285 570 minecraft:gold_block
setblock 484 285 586 minecraft:gold_block
fill 484 285 594 488 285 594 minecraft:smooth_quartz
fill 485 285 563 497 285 563 minecraft:quartz_block
fill 485 285 568 487 285 568 minecraft:gold_block
fill 485 285 588 487 285 588 minecraft:gold_block
fill 485 285 593 497 285 593 minecraft:quartz_block
fill 486 285 561 496 285 561 minecraft:smooth_quartz
fill 486 285 567 496 285 567 minecraft:gold_block
fill 486 285 589 496 285 589 minecraft:gold_block
fill 486 285 595 496 285 595 minecraft:smooth_quartz
fill 487 285 558 492 285 558 minecraft:smooth_quartz
fill 489 285 562 493 285 562 minecraft:quartz_block
fill 489 285 566 493 285 566 minecraft:gold_block
fill 489 285 590 493 285 590 minecraft:gold_block
fill 489 285 594 493 285 594 minecraft:quartz_block
fill 494 285 562 498 285 562 minecraft:smooth_quartz
fill 494 285 566 501 285 566 minecraft:quartz_block
fill 494 285 590 501 285 590 minecraft:quartz_block
fill 494 285 594 498 285 594 minecraft:smooth_quartz
fill 494 285 598 499 285 598 minecraft:smooth_quartz
fill 495 285 568 498 285 568 minecraft:gold_block
fill 495 285 588 498 285 588 minecraft:gold_block
fill 497 285 567 502 285 567 minecraft:quartz_block
fill 497 285 569 499 285 569 minecraft:gold_block
fill 497 285 587 499 285 587 minecraft:gold_block
fill 497 285 589 502 285 589 minecraft:quartz_block
fill 498 285 563 500 285 563 minecraft:smooth_quartz
fill 498 285 593 500 285 593 minecraft:smooth_quartz
fill 499 285 558 504 285 558 minecraft:smooth_quartz
fill 499 285 568 503 285 568 minecraft:quartz_block
fill 499 285 570 500 285 570 minecraft:gold_block
fill 499 285 586 500 285 586 minecraft:gold_block
fill 499 285 588 503 285 588 minecraft:quartz_block
fill 500 285 564 502 285 564 minecraft:smooth_quartz
fill 500 285 569 504 285 569 minecraft:quartz_block
fill 500 285 571 501 285 571 minecraft:gold_block
fill 500 285 585 501 285 585 minecraft:gold_block
fill 500 285 587 504 285 587 minecraft:quartz_block
fill 500 285 592 502 285 592 minecraft:smooth_quartz
fill 501 285 565 503 285 565 minecraft:smooth_quartz
fill 501 285 570 505 285 570 minecraft:quartz_block
fill 501 285 572 501 285 573 minecraft:gold_block
fill 501 285 583 501 285 584 minecraft:gold_block
fill 501 285 586 505 285 586 minecraft:quartz_block
fill 501 285 591 503 285 591 minecraft:smooth_quartz
fill 502 285 566 504 285 566 minecraft:smooth_quartz
fill 502 285 571 505 285 572 minecraft:quartz_block
fill 502 285 573 502 285 577 minecraft:gold_block
fill 502 285 579 502 285 583 minecraft:gold_block
fill 502 285 584 505 285 585 minecraft:quartz_block
fill 502 285 590 504 285 590 minecraft:smooth_quartz
fill 503 285 567 505 285 567 minecraft:smooth_quartz
fill 503 285 573 506 285 575 minecraft:quartz_block
fill 503 285 576 503 285 580 minecraft:gold_block
fill 503 285 581 506 285 583 minecraft:quartz_block
fill 503 285 589 505 285 589 minecraft:smooth_quartz
fill 504 285 568 505 285 568 minecraft:smooth_quartz
fill 504 285 576 507 285 580 minecraft:quartz_block
fill 504 285 588 505 285 588 minecraft:smooth_quartz
fill 505 285 569 506 285 569 minecraft:smooth_quartz
fill 505 285 587 506 285 587 minecraft:smooth_quartz
fill 506 285 570 506 285 571 minecraft:smooth_quartz
setblock 506 285 572 minecraft:quartz_block
setblock 506 285 584 minecraft:quartz_block
fill 506 285 585 506 285 586 minecraft:smooth_quartz
fill 506 285 598 511 285 598 minecraft:smooth_quartz
fill 507 285 571 507 285 575 minecraft:smooth_quartz
fill 507 285 581 507 285 585 minecraft:smooth_quartz
fill 508 285 573 508 285 583 minecraft:smooth_quartz
fill 511 285 558 511 285 563 minecraft:smooth_quartz
fill 511 285 570 511 285 575 minecraft:smooth_quartz
fill 511 285 582 511 285 587 minecraft:smooth_quartz
fill 511 285 594 511 285 597 minecraft:smooth_quartz
fill 470 286 563 470 291 566 minecraft:pearlescent_froglight
fill 470 286 575 470 291 578 minecraft:pearlescent_froglight
fill 470 286 587 470 291 590 minecraft:pearlescent_froglight
fill 470 286 599 473 291 599 minecraft:pearlescent_froglight
fill 475 286 576 477 286 580 minecraft:smooth_quartz
fill 476 286 572 478 286 575 minecraft:smooth_quartz
fill 476 286 581 478 286 584 minecraft:smooth_quartz
fill 477 286 557 480 291 557 minecraft:pearlescent_froglight
fill 477 286 570 480 286 571 minecraft:smooth_quartz
fill 477 286 585 480 286 586 minecraft:smooth_quartz
fill 478 286 569 481 286 569 minecraft:smooth_quartz
setblock 478 286 576 minecraft:smooth_quartz
fill 478 286 577 478 286 579 minecraft:gold_block
setblock 478 286 580 minecraft:smooth_quartz
fill 478 286 587 481 286 587 minecraft:smooth_quartz
fill 479 286 568 482 286 568 minecraft:smooth_quartz
setblock 479 286 572 minecraft:smooth_quartz
fill 479 286 573 479 286 576 minecraft:gold_block
fill 479 286 580 479 286 583 minecraft:gold_block
setblock 479 286 584 minecraft:smooth_quartz
fill 479 286 588 482 286 588 minecraft:smooth_quartz
fill 480 286 567 484 286 567 minecraft:smooth_quartz
fill 480 286 572 480 286 573 minecraft:gold_block
fill 480 286 583 480 286 584 minecraft:gold_block
fill 480 286 589 484 286 589 minecraft:smooth_quartz
fill 481 286 566 485 286 566 minecraft:smooth_quartz
fill 481 286 570 481 286 571 minecraft:gold_block
fill 481 286 585 481 286 586 minecraft:gold_block
fill 481 286 590 485 286 590 minecraft:smooth_quartz
fill 482 286 565 488 286 565 minecraft:smooth_quartz
setblock 482 286 569 minecraft:gold_block
setblock 482 286 587 minecraft:gold_block
fill 482 286 591 488 286 591 minecraft:smooth_quartz
fill 482 286 599 485 291 599 minecraft:pearlescent_froglight
fill 483 286 564 499 286 564 minecraft:smooth_quartz
fill 483 286 568 484 286 568 minecraft:gold_block
fill 483 286 588 484 286 588 minecraft:gold_block
fill 483 286 592 499 286 592 minecraft:smooth_quartz
fill 485 286 563 497 286 563 minecraft:smooth_quartz
setblock 485 286 567 minecraft:gold_block
setblock 485 286 589 minecraft:gold_block
fill 485 286 593 497 286 593 minecraft:smooth_quartz
fill 486 286 566 488 286 566 minecraft:gold_block
fill 486 286 590 488 286 590 minecraft:gold_block
fill 489 286 557 492 291 557 minecraft:pearlescent_froglight
fill 489 286 562 493 286 562 minecraft:smooth_quartz
fill 489 286 565 493 286 565 minecraft:gold_block
fill 489 286 591 493 286 591 minecraft:gold_block
fill 489 286 594 493 286 594 minecraft:smooth_quartz
fill 494 286 565 500 286 565 minecraft:smooth_quartz
fill 494 286 566 496 286 566 minecraft:gold_block
fill 494 286 590 496 286 590 minecraft:gold_block
fill 494 286 591 500 286 591 minecraft:smooth_quartz
fill 494 286 599 497 291 599 minecraft:pearlescent_froglight
fill 497 286 566 501 286 566 minecraft:smooth_quartz
fill 497 286 567 498 286 567 minecraft:gold_block
fill 497 286 589 498 286 589 minecraft:gold_block
fill 497 286 590 501 286 590 minecraft:smooth_quartz
fill 499 286 567 502 286 567 minecraft:smooth_quartz
setblock 499 286 568 minecraft:gold_block
setblock 499 286 588 minecraft:gold_block
fill 499 286 589 502 286 589 minecraft:smooth_quartz
fill 500 286 568 503 286 568 minecraft:smooth_quartz
setblock 500 286 569 minecraft:gold_block
setblock 500 286 587 minecraft:gold_block
fill 500 286 588 503 286 588 minecraft:smooth_quartz
fill 501 286 557 504 291 557 minecraft:pearlescent_froglight
fill 501 286 569 504 286 569 minecraft:smooth_quartz
setblock 501 286 570 minecraft:gold_block
setblock 501 286 586 minecraft:gold_block
fill 501 286 587 504 286 587 minecraft:smooth_quartz
fill 502 286 570 505 286 570 minecraft:smooth_quartz
fill 502 286 571 502 286 572 minecraft:gold_block
fill 502 286 584 502 286 585 minecraft:gold_block
fill 502 286 586 505 286 586 minecraft:smooth_quartz
fill 503 286 571 505 286 572 minecraft:smooth_quartz
fill 503 286 573 503 286 575 minecraft:gold_block
fill 503 286 581 503 286 583 minecraft:gold_block
fill 503 286 584 505 286 585 minecraft:smooth_quartz
fill 504 286 573 506 286 575 minecraft:smooth_quartz
fill 504 286 576 504 286 580 minecraft:gold_block
fill 504 286 581 506 286 583 minecraft:smooth_quartz
fill 505 286 576 507 286 580 minecraft:smooth_quartz
setblock 506 286 572 minecraft:smooth_quartz
setblock 506 286 584 minecraft:smooth_quartz
fill 506 286 599 509 291 599 minecraft:pearlescent_froglight
fill 512 286 558 512 291 561 minecraft:pearlescent_froglight
fill 512 286 570 512 291 573 minecraft:pearlescent_froglight
fill 512 286 582 512 291 585 minecraft:pearlescent_froglight
fill 512 286 594 512 291 597 minecraft:pearlescent_froglight
fill 472 287 592 472 298 592 minecraft:blue_wool
fill 472 288 590 472 298 591 minecraft:blue_wool
fill 472 288 593 472 291 594 minecraft:blue_wool
fill 509 288 562 509 289 568 minecraft:iron_block
fill 470 292 563 470 307 563 minecraft:quartz_block
fill 470 292 564 470 292 565 minecraft:pearlescent_froglight
fill 470 292 566 470 307 566 minecraft:quartz_block
fill 470 292 575 470 307 575 minecraft:quartz_block
fill 470 292 576 470 292 577 minecraft:pearlescent_froglight
fill 470 292 578 470 307 578 minecraft:quartz_block
fill 470 292 587 470 307 587 minecraft:quartz_block
fill 470 292 588 470 292 589 minecraft:pearlescent_froglight
fill 470 292 590 470 307 590 minecraft:quartz_block
fill 470 292 599 470 307 599 minecraft:quartz_block
fill 471 292 599 472 292 599 minecraft:pearlescent_froglight
fill 472 292 593 472 292 595 minecraft:smooth_quartz
setblock 473 292 560 minecraft:light[level=14]
setblock 473 292 568 minecraft:light[level=14]
setblock 473 292 576 minecraft:light[level=14]
setblock 473 292 584 minecraft:light[level=14]
fill 473 292 592 476 292 592 minecraft:smooth_quartz
fill 473 292 596 476 292 596 minecraft:smooth_quartz
fill 473 292 599 473 307 599 minecraft:quartz_block
setblock 476 292 593 minecraft:smooth_quartz
setblock 476 292 595 minecraft:smooth_quartz
fill 477 292 557 477 307 557 minecraft:quartz_block
fill 478 292 557 479 292 557 minecraft:pearlescent_froglight
fill 480 292 557 480 307 557 minecraft:quartz_block
setblock 481 292 560 minecraft:light[level=14]
setblock 481 292 568 minecraft:light[level=14]
setblock 481 292 576 minecraft:light[level=14]
setblock 481 292 584 minecraft:light[level=14]
setblock 481 292 592 minecraft:light[level=14]
fill 482 292 599 482 307 599 minecraft:quartz_block
fill 483 292 599 484 292 599 minecraft:pearlescent_froglight
fill 485 292 599 485 307 599 minecraft:quartz_block
fill 489 292 557 489 307 557 minecraft:quartz_block
setblock 489 292 560 minecraft:light[level=14]
setblock 489 292 568 minecraft:light[level=14]
setblock 489 292 576 minecraft:light[level=14]
setblock 489 292 584 minecraft:light[level=14]
setblock 489 292 592 minecraft:light[level=14]
fill 490 292 557 491 292 557 minecraft:pearlescent_froglight
fill 492 292 557 492 307 557 minecraft:quartz_block
fill 494 292 599 494 307 599 minecraft:quartz_block
fill 495 292 599 496 292 599 minecraft:pearlescent_froglight
setblock 497 292 560 minecraft:light[level=14]
setblock 497 292 568 minecraft:light[level=14]
setblock 497 292 576 minecraft:light[level=14]
setblock 497 292 584 minecraft:light[level=14]
setblock 497 292 592 minecraft:light[level=14]
fill 497 292 599 497 307 599 minecraft:quartz_block
fill 501 292 557 501 307 557 minecraft:quartz_block
fill 502 292 557 503 292 557 minecraft:pearlescent_froglight
fill 504 292 557 504 307 557 minecraft:quartz_block
setblock 505 292 560 minecraft:light[level=14]
setblock 505 292 568 minecraft:light[level=14]
setblock 505 292 576 minecraft:light[level=14]
setblock 505 292 584 minecraft:light[level=14]
setblock 505 292 592 minecraft:light[level=14]
fill 505 292 594 505 292 596 minecraft:smooth_quartz
setblock 506 292 593 minecraft:smooth_quartz
fill 506 292 597 508 292 597 minecraft:smooth_quartz
fill 506 292 599 506 307 599 minecraft:quartz_block
fill 507 292 599 508 292 599 minecraft:pearlescent_froglight
fill 508 292 593 509 292 593 minecraft:smooth_quartz
fill 509 292 594 509 292 596 minecraft:smooth_quartz
fill 509 292 599 509 307 599 minecraft:quartz_block
fill 512 292 558 512 307 558 minecraft:quartz_block
fill 512 292 559 512 292 560 minecraft:pearlescent_froglight
fill 512 292 561 512 307 561 minecraft:quartz_block
fill 512 292 570 512 307 570 minecraft:quartz_block
fill 512 292 571 512 292 572 minecraft:pearlescent_froglight
fill 512 292 573 512 307 573 minecraft:quartz_block
fill 512 292 582 512 307 582 minecraft:quartz_block
fill 512 292 583 512 292 584 minecraft:pearlescent_froglight
fill 512 292 585 512 307 585 minecraft:quartz_block
fill 512 292 594 512 307 594 minecraft:quartz_block
fill 512 292 595 512 292 596 minecraft:pearlescent_froglight
fill 512 292 597 512 307 597 minecraft:quartz_block
fill 470 293 564 470 307 565 minecraft:quartz_block
fill 470 293 576 470 307 577 minecraft:quartz_block
fill 470 293 588 470 307 589 minecraft:quartz_block
fill 471 293 599 472 307 599 minecraft:quartz_block
fill 472 293 593 472 298 594 minecraft:blue_wool
fill 478 293 557 479 307 557 minecraft:quartz_block
fill 483 293 599 484 307 599 minecraft:quartz_block
fill 490 293 557 491 307 557 minecraft:quartz_block
fill 495 293 599 496 307 599 minecraft:quartz_block
fill 502 293 557 503 307 557 minecraft:quartz_block
fill 507 293 599 508 307 599 minecraft:quartz_block
fill 512 293 559 512 307 560 minecraft:quartz_block
fill 512 293 571 512 307 572 minecraft:quartz_block
fill 512 293 583 512 307 584 minecraft:quartz_block
fill 512 293 595 512 307 596 minecraft:quartz_block
fill 504 297 586 508 298 590 minecraft:smooth_quartz
fill 509 297 588 510 297 588 minecraft:smooth_quartz
fill 472 299 589 472 299 593 minecraft:iron_block
fill 472 299 594 472 300 594 minecraft:gold_block
fill 472 299 595 472 300 595 minecraft:iron_block
fill 474 299 592 475 300 592 minecraft:gold_block
fill 474 299 596 475 300 596 minecraft:gold_block
fill 476 299 593 476 300 593 minecraft:gold_block
fill 476 299 595 476 300 595 minecraft:gold_block
fill 505 299 587 507 300 589 minecraft:quartz_pillar
fill 505 299 594 505 300 595 minecraft:gold_block
fill 506 299 593 506 300 593 minecraft:gold_block
fill 507 299 597 507 300 597 minecraft:gold_block
fill 508 299 593 508 300 593 minecraft:gold_block
fill 509 299 594 509 300 596 minecraft:gold_block
fill 472 300 567 472 300 569 minecraft:quartz_pillar
fill 472 300 579 472 300 581 minecraft:quartz_pillar
fill 472 300 589 472 300 590 minecraft:iron_block
fill 472 300 591 472 300 593 minecraft:quartz_pillar
setblock 473 300 560 minecraft:light[level=14]
setblock 473 300 568 minecraft:light[level=14]
setblock 473 300 576 minecraft:light[level=14]
setblock 473 300 584 minecraft:light[level=14]
setblock 473 300 592 minecraft:light[level=14]
fill 478 300 597 480 300 597 minecraft:quartz_pillar
setblock 481 300 560 minecraft:light[level=14]
setblock 481 300 568 minecraft:light[level=14]
setblock 481 300 576 minecraft:light[level=14]
setblock 481 300 584 minecraft:light[level=14]
setblock 481 300 592 minecraft:light[level=14]
fill 482 300 559 484 300 559 minecraft:quartz_pillar
setblock 489 300 560 minecraft:light[level=14]
setblock 489 300 568 minecraft:light[level=14]
setblock 489 300 576 minecraft:light[level=14]
setblock 489 300 584 minecraft:light[level=14]
setblock 489 300 592 minecraft:light[level=14]
fill 490 300 597 492 300 597 minecraft:quartz_pillar
fill 494 300 559 496 300 559 minecraft:quartz_pillar
setblock 497 300 560 minecraft:light[level=14]
setblock 497 300 568 minecraft:light[level=14]
setblock 497 300 576 minecraft:light[level=14]
setblock 497 300 584 minecraft:light[level=14]
setblock 497 300 592 minecraft:light[level=14]
fill 502 300 597 504 300 597 minecraft:quartz_pillar
setblock 505 300 560 minecraft:light[level=14]
setblock 505 300 568 minecraft:light[level=14]
setblock 505 300 576 minecraft:light[level=14]
setblock 505 300 584 minecraft:light[level=14]
setblock 505 300 592 minecraft:light[level=14]
fill 506 300 559 508 300 559 minecraft:quartz_pillar
fill 510 300 567 510 300 569 minecraft:quartz_pillar
fill 510 300 579 510 300 581 minecraft:quartz_pillar
fill 510 300 591 510 300 593 minecraft:quartz_pillar
