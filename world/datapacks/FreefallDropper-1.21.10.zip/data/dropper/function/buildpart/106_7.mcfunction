fill 486 289 454 496 289 454 minecraft:nether_bricks
fill 487 289 427 488 290 427 minecraft:bone_block
fill 487 289 447 488 290 447 minecraft:bone_block
fill 488 289 425 494 289 425 minecraft:magma_block
fill 488 289 428 488 290 428 minecraft:bone_block
fill 488 289 446 488 290 446 minecraft:bone_block
fill 488 289 449 494 289 449 minecraft:magma_block
setblock 489 289 416 minecraft:orange_concrete
fill 489 289 421 493 289 421 minecraft:red_nether_bricks
fill 489 289 453 493 289 453 minecraft:red_nether_bricks
fill 491 289 426 491 290 427 minecraft:bone_block
fill 491 289 447 491 290 448 minecraft:bone_block
fill 492 289 458 492 292 458 minecraft:netherrack
setblock 493 289 429 minecraft:bone_block
setblock 493 289 445 minecraft:bone_block
fill 494 289 416 494 292 416 minecraft:netherrack
fill 494 289 421 498 289 421 minecraft:nether_bricks
fill 494 289 427 494 290 428 minecraft:bone_block
fill 494 289 446 494 290 447 minecraft:bone_block
fill 494 289 453 498 289 453 minecraft:nether_bricks
fill 495 289 425 501 289 425 minecraft:red_nether_bricks
fill 495 289 426 497 289 426 minecraft:magma_block
fill 495 289 427 495 291 427 minecraft:bone_block
fill 495 289 447 495 291 447 minecraft:bone_block
fill 495 289 448 497 289 448 minecraft:magma_block
fill 495 289 449 501 289 449 minecraft:red_nether_bricks
fill 496 289 429 497 289 430 minecraft:bone_block
fill 496 289 444 497 289 445 minecraft:bone_block
fill 497 289 428 497 291 428 minecraft:bone_block
fill 497 289 441 497 300 442 minecraft:red_nether_bricks
fill 497 289 446 497 291 446 minecraft:bone_block
setblock 497 289 458 minecraft:orange_concrete
fill 498 289 422 500 289 422 minecraft:nether_bricks
fill 498 289 426 502 289 426 minecraft:red_nether_bricks
setblock 498 289 427 minecraft:magma_block
fill 498 289 431 499 289 432 minecraft:bone_block
fill 498 289 441 498 300 441 minecraft:red_nether_bricks
fill 498 289 442 499 289 443 minecraft:bone_block
setblock 498 289 447 minecraft:magma_block
fill 498 289 448 502 289 448 minecraft:red_nether_bricks
fill 498 289 452 500 289 452 minecraft:nether_bricks
fill 499 289 427 503 289 427 minecraft:red_nether_bricks
setblock 499 289 428 minecraft:magma_block
setblock 499 289 435 minecraft:bone_block
setblock 499 289 439 minecraft:bone_block
setblock 499 289 446 minecraft:magma_block
fill 499 289 447 503 289 447 minecraft:red_nether_bricks
fill 500 289 423 502 289 423 minecraft:nether_bricks
fill 500 289 428 504 289 428 minecraft:red_nether_bricks
setblock 500 289 429 minecraft:magma_block
fill 500 289 431 500 291 431 minecraft:bone_block
fill 500 289 434 501 290 434 minecraft:bone_block
fill 500 289 440 501 290 440 minecraft:bone_block
fill 500 289 443 500 291 443 minecraft:bone_block
setblock 500 289 445 minecraft:magma_block
fill 500 289 446 504 289 446 minecraft:red_nether_bricks
fill 500 289 451 502 289 451 minecraft:nether_bricks
fill 501 289 424 503 289 424 minecraft:nether_bricks
fill 501 289 429 505 289 429 minecraft:red_nether_bricks
setblock 501 289 430 minecraft:magma_block
fill 501 289 433 501 291 433 minecraft:bone_block
fill 501 289 437 502 290 437 minecraft:bone_block
fill 501 289 441 501 291 441 minecraft:bone_block
setblock 501 289 444 minecraft:magma_block
fill 501 289 445 505 289 445 minecraft:red_nether_bricks
fill 501 289 450 503 289 450 minecraft:nether_bricks
fill 502 289 425 504 289 425 minecraft:nether_bricks
fill 502 289 430 505 289 430 minecraft:red_nether_bricks
fill 502 289 431 502 289 432 minecraft:magma_block
fill 502 289 442 502 289 443 minecraft:magma_block
fill 502 289 444 505 289 444 minecraft:red_nether_bricks
fill 502 289 449 504 289 449 minecraft:nether_bricks
fill 503 289 426 505 289 426 minecraft:nether_bricks
fill 503 289 431 506 289 432 minecraft:red_nether_bricks
fill 503 289 433 503 289 435 minecraft:magma_block
fill 503 289 439 503 289 441 minecraft:magma_block
fill 503 289 442 506 289 443 minecraft:red_nether_bricks
fill 503 289 448 505 289 448 minecraft:nether_bricks
fill 504 289 427 505 289 427 minecraft:nether_bricks
fill 504 289 433 506 289 441 minecraft:red_nether_bricks
fill 504 289 447 505 289 447 minecraft:nether_bricks
fill 505 289 416 505 292 416 minecraft:netherrack
fill 505 289 428 506 289 428 minecraft:nether_bricks
fill 505 289 446 506 289 446 minecraft:nether_bricks
setblock 506 289 416 minecraft:orange_concrete
fill 506 289 429 506 289 430 minecraft:nether_bricks
fill 506 289 444 506 289 445 minecraft:nether_bricks
fill 507 289 430 507 289 434 minecraft:nether_bricks
fill 507 289 435 507 289 439 minecraft:red_nether_bricks
fill 507 289 440 507 289 444 minecraft:nether_bricks
fill 508 289 432 508 289 442 minecraft:nether_bricks
setblock 508 289 458 minecraft:orange_concrete
fill 509 289 416 510 289 416 minecraft:orange_concrete
fill 512 289 430 512 292 430 minecraft:netherrack
setblock 512 289 434 minecraft:orange_concrete
fill 512 289 441 512 292 441 minecraft:netherrack
setblock 512 289 442 minecraft:orange_concrete
setblock 512 289 445 minecraft:orange_concrete
fill 512 289 458 512 292 458 minecraft:netherrack
fill 470 290 416 470 292 416 minecraft:netherrack
fill 470 290 422 470 291 423 minecraft:orange_concrete
fill 470 290 424 470 295 425 minecraft:netherrack
fill 470 290 431 470 291 431 minecraft:orange_concrete
fill 470 290 432 470 291 433 minecraft:netherrack
fill 470 290 434 470 290 435 minecraft:orange_concrete
fill 470 290 436 470 295 436 minecraft:netherrack
fill 470 290 442 470 291 443 minecraft:orange_concrete
fill 470 290 444 470 295 445 minecraft:netherrack
fill 470 290 454 470 290 455 minecraft:orange_concrete
fill 470 290 456 470 295 457 minecraft:netherrack
fill 475 290 416 475 293 416 minecraft:netherrack
fill 475 290 435 477 290 439 minecraft:nether_bricks
fill 475 290 458 475 291 458 minecraft:orange_concrete
setblock 476 290 416 minecraft:orange_concrete
fill 476 290 431 477 290 434 minecraft:nether_bricks
fill 476 290 440 477 290 443 minecraft:nether_bricks
fill 476 290 458 477 295 458 minecraft:netherrack
fill 477 290 416 478 295 416 minecraft:netherrack
fill 477 290 429 479 290 430 minecraft:nether_bricks
fill 477 290 444 479 290 445 minecraft:nether_bricks
fill 478 290 428 481 290 428 minecraft:nether_bricks
fill 478 290 431 478 290 433 minecraft:nether_bricks
fill 478 290 434 478 290 435 minecraft:magma_block
fill 478 290 436 479 291 438 minecraft:bone_block
fill 478 290 439 478 290 440 minecraft:magma_block
fill 478 290 441 478 290 443 minecraft:nether_bricks
fill 478 290 446 481 290 446 minecraft:nether_bricks
setblock 478 290 458 minecraft:orange_concrete
fill 479 290 416 480 291 416 minecraft:orange_concrete
fill 479 290 427 482 290 427 minecraft:nether_bricks
setblock 479 290 431 minecraft:nether_bricks
fill 479 290 432 479 291 434 minecraft:bone_block
fill 479 290 440 479 291 442 minecraft:bone_block
setblock 479 290 443 minecraft:nether_bricks
fill 479 290 447 482 290 447 minecraft:nether_bricks
fill 480 290 426 483 290 426 minecraft:nether_bricks
setblock 480 290 429 minecraft:nether_bricks
fill 480 290 430 483 290 430 minecraft:bone_block
setblock 480 290 431 minecraft:magma_block
fill 480 290 433 480 291 434 minecraft:bone_block
fill 480 290 436 480 291 436 minecraft:bone_block
fill 480 290 438 480 291 438 minecraft:bone_block
fill 480 290 440 480 291 441 minecraft:bone_block
setblock 480 290 443 minecraft:magma_block
fill 480 290 444 483 290 444 minecraft:bone_block
setblock 480 290 445 minecraft:nether_bricks
fill 480 290 448 483 290 448 minecraft:nether_bricks
fill 480 290 458 480 295 458 minecraft:netherrack
fill 481 290 425 485 290 425 minecraft:nether_bricks
fill 481 290 429 482 291 429 minecraft:bone_block
fill 481 290 431 483 290 431 minecraft:bone_block
fill 481 290 443 483 290 443 minecraft:bone_block
fill 481 290 445 482 291 445 minecraft:bone_block
fill 481 290 449 485 290 449 minecraft:nether_bricks
fill 482 290 424 487 290 424 minecraft:nether_bricks
setblock 482 290 428 minecraft:magma_block
setblock 482 290 446 minecraft:magma_block
fill 482 290 450 487 290 450 minecraft:nether_bricks
fill 483 290 423 499 290 423 minecraft:nether_bricks
fill 483 290 427 485 291 428 minecraft:bone_block
fill 483 290 446 485 291 447 minecraft:bone_block
fill 483 290 451 499 290 451 minecraft:nether_bricks
fill 484 290 426 484 291 426 minecraft:bone_block
fill 484 290 429 485 290 429 minecraft:bone_block
fill 484 290 445 485 290 445 minecraft:bone_block
fill 484 290 448 484 291 448 minecraft:bone_block
fill 485 290 416 486 292 416 minecraft:netherrack
fill 485 290 422 497 290 422 minecraft:nether_bricks
setblock 485 290 426 minecraft:magma_block
setblock 485 290 448 minecraft:magma_block
fill 485 290 452 497 290 452 minecraft:nether_bricks
fill 486 290 425 488 291 425 minecraft:bone_block
fill 486 290 449 488 291 449 minecraft:bone_block
fill 486 290 458 487 291 458 minecraft:orange_concrete
fill 487 290 416 488 290 416 minecraft:orange_concrete
fill 487 290 426 488 291 426 minecraft:bone_block
fill 487 290 448 488 291 448 minecraft:bone_block
fill 488 290 424 489 290 424 minecraft:magma_block
fill 488 290 450 489 290 450 minecraft:magma_block
fill 488 290 458 489 295 458 minecraft:netherrack
fill 489 290 416 489 295 416 minecraft:netherrack
fill 489 290 421 493 290 421 minecraft:nether_bricks
fill 489 290 453 493 290 453 minecraft:nether_bricks
fill 490 290 424 490 291 426 minecraft:bone_block
fill 490 290 448 490 291 450 minecraft:bone_block
fill 491 290 424 492 291 425 minecraft:bone_block
fill 491 290 449 492 291 450 minecraft:bone_block
fill 492 290 426 492 291 426 minecraft:bone_block
fill 492 290 448 492 291 448 minecraft:bone_block
fill 493 290 424 494 290 424 minecraft:magma_block
fill 493 290 450 494 290 450 minecraft:magma_block
fill 494 290 425 495 291 426 minecraft:bone_block
fill 494 290 448 495 291 449 minecraft:bone_block
fill 495 290 424 500 290 424 minecraft:nether_bricks
fill 495 290 450 500 290 450 minecraft:nether_bricks
fill 496 290 425 496 291 425 minecraft:bone_block
fill 496 290 441 496 291 442 minecraft:blackstone
fill 496 290 449 496 291 449 minecraft:bone_block
fill 497 290 416 498 295 416 minecraft:netherrack
setblock 497 290 425 minecraft:magma_block
fill 497 290 427 499 291 427 minecraft:bone_block
fill 497 290 429 498 290 429 minecraft:bone_block
fill 497 290 440 498 291 440 minecraft:blackstone
fill 497 290 443 498 291 443 minecraft:blackstone
fill 497 290 445 498 290 445 minecraft:bone_block
fill 497 290 447 499 291 447 minecraft:bone_block
setblock 497 290 449 minecraft:magma_block
fill 497 290 458 497 295 458 minecraft:netherrack
fill 498 290 425 501 290 425 minecraft:nether_bricks
fill 498 290 426 498 291 426 minecraft:bone_block
fill 498 290 428 499 291 428 minecraft:bone_block
fill 498 290 442 498 300 442 minecraft:red_nether_bricks
fill 498 290 446 499 291 446 minecraft:bone_block
fill 498 290 448 498 291 448 minecraft:bone_block
fill 498 290 449 501 290 449 minecraft:nether_bricks
fill 498 290 458 499 290 458 minecraft:orange_concrete
fill 499 290 416 500 291 416 minecraft:orange_concrete
fill 499 290 426 502 290 426 minecraft:nether_bricks
fill 499 290 430 499 290 431 minecraft:bone_block
fill 499 290 441 499 291 442 minecraft:blackstone
fill 499 290 443 499 290 444 minecraft:bone_block
fill 499 290 448 502 290 448 minecraft:nether_bricks
fill 500 290 427 503 290 427 minecraft:nether_bricks
setblock 500 290 428 minecraft:magma_block
fill 500 290 429 501 291 430 minecraft:bone_block
fill 500 290 444 501 291 445 minecraft:bone_block
setblock 500 290 446 minecraft:magma_block
fill 500 290 447 503 290 447 minecraft:nether_bricks
fill 500 290 458 501 295 458 minecraft:netherrack
fill 501 290 428 504 290 428 minecraft:nether_bricks
fill 501 290 431 501 291 431 minecraft:bone_block
fill 501 290 443 501 291 443 minecraft:bone_block
fill 501 290 446 504 290 446 minecraft:nether_bricks
fill 502 290 429 505 290 429 minecraft:nether_bricks
fill 502 290 430 502 291 430 minecraft:bone_block
fill 502 290 433 503 291 434 minecraft:bone_block
fill 502 290 436 504 291 436 minecraft:bone_block
fill 502 290 438 504 291 438 minecraft:bone_block
fill 502 290 440 503 291 441 minecraft:bone_block
fill 502 290 444 502 291 444 minecraft:bone_block
fill 502 290 445 505 290 445 minecraft:nether_bricks
fill 503 290 430 505 290 430 minecraft:nether_bricks
setblock 503 290 431 minecraft:magma_block
fill 503 290 432 503 291 432 minecraft:bone_block
fill 503 290 437 504 291 437 minecraft:bone_block
fill 503 290 442 503 291 442 minecraft:bone_block
setblock 503 290 443 minecraft:magma_block
fill 503 290 444 505 290 444 minecraft:nether_bricks
fill 504 290 431 506 290 433 minecraft:nether_bricks
fill 504 290 434 504 290 435 minecraft:magma_block
fill 504 290 439 504 290 440 minecraft:magma_block
fill 504 290 441 506 290 443 minecraft:nether_bricks
fill 505 290 434 506 290 440 minecraft:nether_bricks
fill 506 290 416 506 295 416 minecraft:netherrack
fill 506 290 458 507 291 458 minecraft:orange_concrete
fill 507 290 435 507 290 439 minecraft:nether_bricks
setblock 508 290 416 minecraft:orange_concrete
fill 508 290 458 509 295 458 minecraft:netherrack
fill 509 290 416 510 295 416 minecraft:netherrack
setblock 510 290 458 minecraft:orange_concrete
fill 511 290 416 511 291 416 minecraft:orange_concrete
fill 512 290 421 512 295 422 minecraft:netherrack
fill 512 290 423 512 290 424 minecraft:orange_concrete
fill 512 290 433 512 295 434 minecraft:netherrack
fill 512 290 435 512 291 436 minecraft:orange_concrete
fill 512 290 442 512 295 442 minecraft:netherrack
fill 512 290 443 512 290 444 minecraft:orange_concrete
fill 512 290 445 512 291 446 minecraft:netherrack
fill 512 290 447 512 291 447 minecraft:orange_concrete
fill 512 290 453 512 295 454 minecraft:netherrack
fill 512 290 455 512 291 456 minecraft:orange_concrete
fill 470 291 418 470 293 418 minecraft:netherrack
setblock 470 291 419 minecraft:orange_concrete
setblock 470 291 430 minecraft:orange_concrete
fill 470 291 434 470 294 435 minecraft:netherrack
setblock 470 291 451 minecraft:orange_concrete
setblock 470 291 454 minecraft:orange_concrete
fill 470 291 455 470 294 455 minecraft:netherrack
setblock 471 291 416 minecraft:orange_concrete
setblock 474 291 458 minecraft:orange_concrete
fill 476 291 416 476 293 416 minecraft:netherrack
setblock 477 291 437 minecraft:bone_block
fill 478 291 432 478 291 434 minecraft:bone_block
fill 478 291 440 478 291 442 minecraft:bone_block
fill 478 291 458 478 294 458 minecraft:netherrack
fill 480 291 429 480 291 430 minecraft:bone_block
setblock 480 291 437 minecraft:bone_block
fill 480 291 444 480 291 445 minecraft:bone_block
fill 481 291 430 482 291 431 minecraft:bone_block
setblock 481 291 433 minecraft:bone_block
setblock 481 291 441 minecraft:bone_block
fill 481 291 443 482 291 444 minecraft:bone_block
setblock 483 291 426 minecraft:bone_block
setblock 483 291 448 minecraft:bone_block
fill 486 291 424 488 291 424 minecraft:bone_block
fill 486 291 450 488 291 450 minecraft:bone_block
fill 487 291 416 487 294 416 minecraft:netherrack
setblock 487 291 427 minecraft:bone_block
setblock 487 291 447 minecraft:bone_block
setblock 488 291 416 minecraft:orange_concrete
fill 491 291 416 492 291 416 minecraft:orange_concrete
setblock 491 291 423 minecraft:bone_block
setblock 491 291 426 minecraft:bone_block
setblock 491 291 448 minecraft:bone_block
setblock 491 291 451 minecraft:bone_block
fill 494 291 424 496 291 424 minecraft:bone_block
fill 494 291 450 496 291 450 minecraft:bone_block
fill 494 291 458 495 291 458 minecraft:orange_concrete
setblock 496 291 443 minecraft:blackstone
setblock 498 291 458 minecraft:orange_concrete
setblock 499 291 426 minecraft:bone_block
setblock 499 291 440 minecraft:blackstone
setblock 499 291 443 minecraft:blackstone
setblock 499 291 448 minecraft:bone_block
fill 499 291 458 499 294 458 minecraft:netherrack
setblock 502 291 429 minecraft:bone_block
setblock 502 291 437 minecraft:bone_block
setblock 502 291 445 minecraft:bone_block
fill 504 291 432 504 291 434 minecraft:bone_block
fill 504 291 440 504 291 442 minecraft:bone_block
setblock 505 291 437 minecraft:bone_block
fill 508 291 416 508 294 416 minecraft:netherrack
fill 510 291 458 510 294 458 minecraft:netherrack
setblock 512 291 416 minecraft:orange_concrete
fill 512 291 423 512 294 423 minecraft:netherrack
setblock 512 291 424 minecraft:orange_concrete
setblock 512 291 427 minecraft:orange_concrete
fill 512 291 443 512 294 444 minecraft:netherrack
setblock 512 291 448 minecraft:orange_concrete
fill 470 292 419 470 297 419 minecraft:netherrack
fill 470 292 420 470 292 421 minecraft:orange_concrete
fill 470 292 422 470 297 423 minecraft:netherrack
fill 470 292 428 470 293 429 minecraft:orange_concrete
fill 470 292 430 470 297 431 minecraft:netherrack
setblock 470 292 432 minecraft:orange_concrete
fill 470 292 433 470 295 433 minecraft:netherrack
fill 470 292 440 470 293 441 minecraft:orange_concrete
fill 470 292 442 470 297 443 minecraft:netherrack
fill 470 292 449 470 293 449 minecraft:orange_concrete
fill 470 292 451 470 297 451 minecraft:netherrack
fill 470 292 452 470 292 453 minecraft:orange_concrete
fill 470 292 454 470 297 454 minecraft:netherrack
fill 471 292 416 471 297 416 minecraft:netherrack
fill 472 292 458 473 293 458 minecraft:orange_concrete
fill 473 292 416 473 293 416 minecraft:orange_concrete
setblock 474 292 416 minecraft:netherrack
fill 474 292 458 475 297 458 minecraft:netherrack
fill 479 292 416 480 297 416 minecraft:netherrack
fill 481 292 416 482 293 416 minecraft:orange_concrete
fill 484 292 458 485 292 458 minecraft:orange_concrete
fill 486 292 458 487 297 458 minecraft:netherrack
fill 488 292 416 488 294 416 minecraft:netherrack
setblock 490 292 416 minecraft:orange_concrete
fill 491 292 416 492 297 416 minecraft:netherrack
fill 493 292 416 493 293 416 minecraft:orange_concrete
fill 493 292 458 493 293 458 minecraft:orange_concrete
fill 494 292 458 495 297 458 minecraft:netherrack
setblock 496 292 458 minecraft:orange_concrete
fill 498 292 458 498 297 458 minecraft:netherrack
fill 499 292 416 500 297 416 minecraft:netherrack
fill 501 292 416 502 292 416 minecraft:orange_concrete
fill 504 292 458 505 293 458 minecraft:orange_concrete
fill 506 292 458 507 297 458 minecraft:netherrack
fill 511 292 416 512 297 416 minecraft:netherrack
fill 512 292 417 512 293 418 minecraft:orange_concrete
fill 512 292 424 512 297 424 minecraft:netherrack
fill 512 292 425 512 292 426 minecraft:orange_concrete
fill 512 292 427 512 297 427 minecraft:netherrack
fill 512 292 429 512 293 429 minecraft:orange_concrete
fill 512 292 435 512 297 436 minecraft:netherrack
fill 512 292 437 512 293 438 minecraft:orange_concrete
fill 512 292 445 512 295 445 minecraft:netherrack
setblock 512 292 446 minecraft:orange_concrete
fill 512 292 447 512 297 448 minecraft:netherrack
fill 512 292 449 512 293 450 minecraft:orange_concrete
fill 512 292 455 512 297 456 minecraft:netherrack
setblock 512 292 457 minecraft:orange_concrete
fill 470 293 416 470 293 417 minecraft:orange_concrete
setblock 470 293 420 minecraft:orange_concrete
fill 470 293 421 470 296 421 minecraft:netherrack
fill 470 293 432 470 296 432 minecraft:netherrack
setblock 470 293 437 minecraft:orange_concrete
setblock 470 293 448 minecraft:orange_concrete
fill 470 293 452 470 296 453 minecraft:netherrack
setblock 474 293 416 minecraft:orange_concrete
setblock 481 293 458 minecraft:orange_concrete
setblock 484 293 458 minecraft:orange_concrete
setblock 485 293 416 minecraft:orange_concrete
fill 485 293 458 485 296 458 minecraft:netherrack
fill 486 293 416 486 295 416 minecraft:netherrack
fill 490 293 416 490 296 416 minecraft:netherrack
setblock 492 293 458 minecraft:orange_concrete
setblock 494 293 416 minecraft:orange_concrete
fill 496 293 458 496 296 458 minecraft:netherrack
fill 501 293 416 501 296 416 minecraft:netherrack
setblock 502 293 416 minecraft:orange_concrete
setblock 505 293 416 minecraft:orange_concrete
fill 506 293 442 511 293 442 minecraft:magma_block
fill 507 293 441 511 293 441 minecraft:magma_block
fill 507 293 443 511 293 443 minecraft:magma_block
fill 512 293 425 512 296 426 minecraft:netherrack
setblock 512 293 430 minecraft:orange_concrete
setblock 512 293 441 minecraft:orange_concrete
fill 512 293 446 512 296 446 minecraft:netherrack
fill 512 293 457 512 296 457 minecraft:netherrack
setblock 512 293 458 minecraft:orange_concrete
fill 470 294 416 470 299 417 minecraft:netherrack
setblock 470 294 418 minecraft:orange_concrete
fill 470 294 420 470 299 420 minecraft:netherrack
fill 470 294 426 470 295 427 minecraft:orange_concrete
fill 470 294 428 470 299 429 minecraft:netherrack
fill 470 294 437 470 299 437 minecraft:netherrack
fill 470 294 438 470 294 439 minecraft:orange_concrete
fill 470 294 440 470 299 441 minecraft:netherrack
fill 470 294 446 470 295 447 minecraft:orange_concrete
fill 470 294 448 470 299 449 minecraft:netherrack
setblock 470 294 450 minecraft:orange_concrete
fill 470 294 458 471 295 458 minecraft:orange_concrete
fill 471 294 417 473 294 417 minecraft:red_nether_bricks
fill 471 294 419 471 294 421 minecraft:red_nether_bricks
fill 471 294 423 471 294 425 minecraft:red_nether_bricks
fill 471 294 427 471 294 429 minecraft:red_nether_bricks
fill 471 294 431 471 294 433 minecraft:red_nether_bricks
fill 471 294 435 471 294 437 minecraft:red_nether_bricks
fill 471 294 439 471 294 441 minecraft:red_nether_bricks
fill 471 294 443 471 294 445 minecraft:red_nether_bricks
fill 471 294 447 471 294 449 minecraft:red_nether_bricks
fill 471 294 451 471 294 453 minecraft:red_nether_bricks
fill 471 294 455 471 294 457 minecraft:red_nether_bricks
setblock 472 294 416 minecraft:orange_concrete
fill 472 294 458 473 299 458 minecraft:netherrack
fill 473 294 416 474 299 416 minecraft:netherrack
fill 473 294 457 475 294 457 minecraft:red_nether_bricks
fill 475 294 416 476 295 416 minecraft:orange_concrete
fill 475 294 417 477 294 417 minecraft:red_nether_bricks
fill 477 294 457 479 294 457 minecraft:red_nether_bricks
fill 479 294 417 481 294 417 minecraft:red_nether_bricks
fill 479 294 458 479 295 458 minecraft:orange_concrete
fill 481 294 416 482 299 416 minecraft:netherrack
fill 481 294 457 483 294 457 minecraft:red_nether_bricks
fill 481 294 458 481 299 458 minecraft:netherrack
fill 482 294 458 483 294 458 minecraft:orange_concrete
fill 483 294 416 484 294 416 minecraft:orange_concrete
fill 483 294 417 485 294 417 minecraft:red_nether_bricks
fill 484 294 458 484 299 458 minecraft:netherrack
fill 485 294 416 485 295 416 minecraft:netherrack
fill 485 294 457 487 294 457 minecraft:red_nether_bricks
fill 487 294 417 489 294 417 minecraft:red_nether_bricks
fill 489 294 457 491 294 457 minecraft:red_nether_bricks
fill 490 294 458 491 295 458 minecraft:orange_concrete
fill 491 294 417 493 294 417 minecraft:red_nether_bricks
fill 492 294 458 493 299 458 minecraft:netherrack
fill 493 294 416 494 299 416 minecraft:netherrack
fill 493 294 457 495 294 457 minecraft:red_nether_bricks
fill 495 294 416 496 295 416 minecraft:orange_concrete
fill 495 294 417 497 294 417 minecraft:red_nether_bricks
fill 497 294 457 499 294 457 minecraft:red_nether_bricks
fill 499 294 417 501 294 417 minecraft:red_nether_bricks
fill 501 294 457 503 294 457 minecraft:red_nether_bricks
fill 502 294 416 502 299 416 minecraft:netherrack
fill 502 294 458 503 294 458 minecraft:orange_concrete
fill 503 294 416 504 294 416 minecraft:orange_concrete
fill 503 294 417 505 294 417 minecraft:red_nether_bricks
fill 503 294 442 510 294 442 minecraft:magma_block
fill 504 294 458 505 299 458 minecraft:netherrack
fill 505 294 416 505 299 416 minecraft:netherrack
fill 505 294 441 510 294 441 minecraft:magma_block
fill 505 294 443 510 294 443 minecraft:magma_block
fill 505 294 457 507 294 457 minecraft:red_nether_bricks
fill 507 294 416 507 295 416 minecraft:orange_concrete
fill 507 294 417 509 294 417 minecraft:red_nether_bricks
fill 509 294 440 511 295 440 minecraft:magma_block
fill 509 294 444 511 295 444 minecraft:magma_block
fill 509 294 457 511 294 457 minecraft:red_nether_bricks
fill 511 294 417 511 294 419 minecraft:red_nether_bricks
fill 511 294 421 511 294 423 minecraft:red_nether_bricks
fill 511 294 425 511 294 427 minecraft:red_nether_bricks
fill 511 294 429 511 294 431 minecraft:red_nether_bricks
fill 511 294 433 511 294 435 minecraft:red_nether_bricks
fill 511 294 437 511 294 439 minecraft:red_nether_bricks
fill 511 294 441 511 294 443 minecraft:red_nether_bricks
fill 511 294 445 511 294 447 minecraft:red_nether_bricks
fill 511 294 449 511 294 451 minecraft:red_nether_bricks
fill 511 294 453 511 294 455 minecraft:red_nether_bricks
fill 511 294 458 511 295 458 minecraft:orange_concrete
fill 512 294 417 512 299 418 minecraft:netherrack
fill 512 294 419 512 295 420 minecraft:orange_concrete
setblock 512 294 428 minecraft:orange_concrete
fill 512 294 429 512 299 430 minecraft:netherrack
fill 512 294 431 512 295 432 minecraft:orange_concrete
fill 512 294 437 512 299 438 minecraft:netherrack
fill 512 294 439 512 294 440 minecraft:orange_concrete
fill 512 294 441 512 299 441 minecraft:netherrack
fill 512 294 449 512 299 450 minecraft:netherrack
fill 512 294 451 512 295 452 minecraft:orange_concrete
fill 512 294 458 512 299 458 minecraft:netherrack
fill 470 295 418 470 298 418 minecraft:netherrack
fill 470 295 434 470 295 435 minecraft:orange_concrete
setblock 470 295 438 minecraft:orange_concrete
fill 470 295 439 470 298 439 minecraft:netherrack
fill 470 295 450 470 298 450 minecraft:netherrack
setblock 470 295 455 minecraft:orange_concrete
fill 472 295 416 472 298 416 minecraft:netherrack
setblock 478 295 458 minecraft:orange_concrete
fill 482 295 458 483 298 458 minecraft:netherrack
fill 483 295 416 483 298 416 minecraft:netherrack
setblock 484 295 416 minecraft:orange_concrete
fill 487 295 416 488 295 416 minecraft:orange_concrete
setblock 499 295 458 minecraft:orange_concrete
fill 502 295 439 502 296 440 minecraft:netherrack
setblock 502 295 458 minecraft:orange_concrete
fill 503 295 416 504 298 416 minecraft:netherrack
fill 503 295 458 503 298 458 minecraft:netherrack
fill 505 295 442 511 295 442 minecraft:magma_block
fill 506 295 441 511 295 441 minecraft:magma_block
fill 506 295 443 511 295 443 minecraft:magma_block
setblock 508 295 416 minecraft:orange_concrete
setblock 510 295 458 minecraft:orange_concrete
setblock 512 295 423 minecraft:orange_concrete
fill 512 295 428 512 298 428 minecraft:netherrack
fill 512 295 439 512 298 439 minecraft:netherrack
setblock 512 295 440 minecraft:orange_concrete
fill 512 295 443 512 295 444 minecraft:orange_concrete
fill 470 296 424 470 296 425 minecraft:orange_concrete
fill 470 296 426 470 307 427 minecraft:netherrack
fill 470 296 433 470 297 433 minecraft:orange_concrete
fill 470 296 434 470 307 435 minecraft:netherrack
setblock 470 296 436 minecraft:orange_concrete
fill 470 296 438 470 307 438 minecraft:netherrack
fill 470 296 444 470 297 445 minecraft:orange_concrete
fill 470 296 446 470 307 447 minecraft:netherrack
fill 470 296 455 470 307 455 minecraft:netherrack
fill 470 296 456 470 296 457 minecraft:orange_concrete
fill 470 296 458 471 307 458 minecraft:netherrack
setblock 473 296 419 minecraft:light[level=14]
setblock 473 296 427 minecraft:light[level=14]
setblock 473 296 435 minecraft:light[level=14]
setblock 473 296 443 minecraft:light[level=14]
setblock 473 296 451 minecraft:light[level=14]
fill 475 296 416 476 307 416 minecraft:netherrack
fill 476 296 458 477 297 458 minecraft:orange_concrete
fill 477 296 416 478 297 416 minecraft:orange_concrete
fill 478 296 458 479 307 458 minecraft:netherrack
setblock 480 296 458 minecraft:orange_concrete
setblock 481 296 419 minecraft:light[level=14]
setblock 481 296 427 minecraft:light[level=14]
setblock 481 296 435 minecraft:light[level=14]
setblock 481 296 443 minecraft:light[level=14]
setblock 481 296 451 minecraft:light[level=14]
fill 484 296 416 484 307 416 minecraft:netherrack
fill 485 296 416 486 296 416 minecraft:orange_concrete
fill 487 296 416 488 297 416 minecraft:netherrack
fill 488 296 458 489 297 458 minecraft:orange_concrete
fill 489 296 416 489 297 416 minecraft:orange_concrete
setblock 489 296 419 minecraft:light[level=14]
setblock 489 296 427 minecraft:light[level=14]
setblock 489 296 435 minecraft:light[level=14]
setblock 489 296 443 minecraft:light[level=14]
setblock 489 296 451 minecraft:light[level=14]
fill 490 296 458 491 307 458 minecraft:netherrack
fill 495 296 416 496 307 416 minecraft:netherrack
fill 497 296 416 498 297 416 minecraft:orange_concrete
setblock 497 296 419 minecraft:light[level=14]
setblock 497 296 427 minecraft:light[level=14]
setblock 497 296 435 minecraft:light[level=14]
setblock 497 296 443 minecraft:light[level=14]
setblock 497 296 451 minecraft:light[level=14]
fill 497 296 458 497 297 458 minecraft:orange_concrete
fill 499 296 458 499 307 458 minecraft:netherrack
fill 500 296 458 501 296 458 minecraft:orange_concrete
fill 502 296 458 502 307 458 minecraft:netherrack
setblock 505 296 419 minecraft:light[level=14]
setblock 505 296 427 minecraft:light[level=14]
setblock 505 296 435 minecraft:light[level=14]
setblock 505 296 443 minecraft:light[level=14]
setblock 505 296 451 minecraft:light[level=14]
setblock 506 296 416 minecraft:orange_concrete
fill 507 296 416 508 307 416 minecraft:netherrack
fill 508 296 441 511 296 443 minecraft:magma_block
fill 508 296 458 509 297 458 minecraft:orange_concrete
fill 509 296 416 510 297 416 minecraft:orange_concrete
fill 510 296 458 511 307 458 minecraft:netherrack
fill 512 296 419 512 307 420 minecraft:netherrack
fill 512 296 421 512 296 422 minecraft:orange_concrete
fill 512 296 423 512 307 423 minecraft:netherrack
fill 512 296 431 512 307 432 minecraft:netherrack
fill 512 296 433 512 297 434 minecraft:orange_concrete
fill 512 296 440 512 307 440 minecraft:netherrack
setblock 512 296 442 minecraft:orange_concrete
fill 512 296 443 512 307 444 minecraft:netherrack
fill 512 296 445 512 297 445 minecraft:orange_concrete
fill 512 296 451 512 307 452 minecraft:netherrack
fill 512 296 453 512 296 454 minecraft:orange_concrete
setblock 470 297 421 minecraft:orange_concrete
setblock 470 297 424 minecraft:orange_concrete
fill 470 297 425 470 307 425 minecraft:netherrack
setblock 470 297 432 minecraft:orange_concrete
fill 470 297 436 470 307 436 minecraft:netherrack
fill 470 297 452 470 297 453 minecraft:orange_concrete
setblock 470 297 456 minecraft:orange_concrete
fill 470 297 457 470 307 457 minecraft:netherrack
fill 480 297 458 480 307 458 minecraft:netherrack
fill 485 297 416 486 299 416 minecraft:netherrack
setblock 485 297 458 minecraft:orange_concrete
setblock 490 297 416 minecraft:orange_concrete
fill 496 297 440 496 297 443 minecraft:orange_concrete
setblock 496 297 458 minecraft:orange_concrete
fill 497 297 440 499 297 440 minecraft:orange_concrete
fill 497 297 443 499 297 443 minecraft:orange_concrete
fill 499 297 441 499 299 442 minecraft:orange_concrete
fill 500 297 458 501 307 458 minecraft:netherrack
setblock 501 297 416 minecraft:orange_concrete
fill 506 297 416 506 307 416 minecraft:netherrack
fill 512 297 421 512 307 421 minecraft:netherrack
setblock 512 297 422 minecraft:orange_concrete
fill 512 297 425 512 297 426 minecraft:orange_concrete
fill 512 297 442 512 307 442 minecraft:netherrack
setblock 512 297 446 minecraft:orange_concrete
fill 512 297 453 512 307 453 minecraft:netherrack
setblock 512 297 454 minecraft:orange_concrete
setblock 512 297 457 minecraft:orange_concrete
fill 470 298 419 470 299 419 minecraft:orange_concrete
fill 470 298 421 470 307 421 minecraft:netherrack
fill 470 298 422 470 298 423 minecraft:orange_concrete
fill 470 298 424 470 307 424 minecraft:netherrack
fill 470 298 430 470 299 431 minecraft:orange_concrete
fill 470 298 432 470 307 433 minecraft:netherrack
fill 470 298 442 470 298 443 minecraft:orange_concrete
fill 470 298 444 470 307 445 minecraft:netherrack
fill 470 298 451 470 299 451 minecraft:orange_concrete
fill 470 298 452 470 307 453 minecraft:netherrack
setblock 470 298 454 minecraft:orange_concrete
fill 470 298 456 470 307 456 minecraft:netherrack
fill 471 298 416 471 299 416 minecraft:orange_concrete
fill 474 298 458 475 299 458 minecraft:orange_concrete
fill 476 298 458 477 307 458 minecraft:netherrack
fill 477 298 416 478 307 416 minecraft:netherrack
fill 479 298 416 480 299 416 minecraft:orange_concrete
fill 485 298 458 485 307 458 minecraft:netherrack
fill 486 298 458 487 298 458 minecraft:orange_concrete
fill 487 298 416 487 307 416 minecraft:netherrack
setblock 488 298 416 minecraft:orange_concrete
fill 488 298 458 489 307 458 minecraft:netherrack
fill 489 298 416 490 307 416 minecraft:netherrack
fill 491 298 416 492 299 416 minecraft:orange_concrete
fill 494 298 458 495 299 458 minecraft:orange_concrete
fill 496 298 441 496 298 442 minecraft:orange_concrete
fill 496 298 458 497 307 458 minecraft:netherrack
fill 497 298 416 498 307 416 minecraft:netherrack
fill 497 298 440 498 298 440 minecraft:orange_concrete
fill 497 298 443 498 299 443 minecraft:orange_concrete
setblock 498 298 458 minecraft:orange_concrete
fill 499 298 416 500 298 416 minecraft:orange_concrete
fill 501 298 416 501 307 416 minecraft:netherrack
fill 506 298 458 507 299 458 minecraft:orange_concrete
fill 508 298 458 509 307 458 minecraft:netherrack
fill 509 298 416 510 307 416 minecraft:netherrack
fill 510 298 449 510 300 449 minecraft:magma_block
fill 511 298 416 512 299 416 minecraft:orange_concrete
fill 512 298 422 512 307 422 minecraft:netherrack
setblock 512 298 424 minecraft:orange_concrete
fill 512 298 425 512 307 426 minecraft:netherrack
fill 512 298 427 512 299 427 minecraft:orange_concrete
fill 512 298 433 512 307 434 minecraft:netherrack
fill 512 298 435 512 298 436 minecraft:orange_concrete
fill 512 298 445 512 307 446 minecraft:netherrack
fill 512 298 447 512 299 448 minecraft:orange_concrete
fill 512 298 454 512 307 454 minecraft:netherrack
fill 512 298 455 512 298 456 minecraft:orange_concrete
fill 512 298 457 512 307 457 minecraft:netherrack
setblock 470 299 418 minecraft:orange_concrete
fill 470 299 422 470 307 423 minecraft:netherrack
setblock 470 299 439 minecraft:orange_concrete
setblock 470 299 442 minecraft:orange_concrete
fill 470 299 443 470 307 443 minecraft:netherrack
setblock 470 299 450 minecraft:orange_concrete
fill 470 299 454 470 307 454 minecraft:netherrack
setblock 472 299 416 minecraft:orange_concrete
fill 482 299 458 483 299 458 minecraft:orange_concrete
setblock 483 299 416 minecraft:orange_concrete
setblock 486 299 458 minecraft:orange_concrete
fill 487 299 458 487 307 458 minecraft:netherrack
fill 488 299 416 488 307 416 minecraft:netherrack
fill 494 299 444 494 300 445 minecraft:netherrack
fill 498 299 458 498 307 458 minecraft:netherrack
fill 499 299 416 499 307 416 minecraft:netherrack
setblock 500 299 416 minecraft:orange_concrete
fill 503 299 416 504 299 416 minecraft:orange_concrete
fill 503 299 435 504 300 436 minecraft:shroomlight
setblock 503 299 458 minecraft:orange_concrete
fill 508 299 449 509 300 449 minecraft:magma_block
fill 509 299 448 511 300 448 minecraft:magma_block
fill 509 299 450 511 299 450 minecraft:magma_block
setblock 511 299 449 minecraft:magma_block
fill 512 299 424 512 307 424 minecraft:netherrack
setblock 512 299 428 minecraft:orange_concrete
fill 512 299 435 512 307 435 minecraft:netherrack
setblock 512 299 436 minecraft:orange_concrete
setblock 512 299 439 minecraft:orange_concrete
fill 512 299 455 512 307 456 minecraft:netherrack
fill 470 300 416 470 300 417 minecraft:orange_concrete
fill 470 300 418 470 307 419 minecraft:netherrack
setblock 470 300 420 minecraft:orange_concrete
fill 470 300 428 470 300 429 minecraft:orange_concrete
fill 470 300 430 470 307 431 minecraft:netherrack
setblock 470 300 437 minecraft:orange_concrete
fill 470 300 439 470 307 439 minecraft:netherrack
fill 470 300 440 470 300 441 minecraft:orange_concrete
fill 470 300 442 470 307 442 minecraft:netherrack
fill 470 300 448 470 300 449 minecraft:orange_concrete
fill 470 300 450 470 307 451 minecraft:netherrack
fill 471 300 416 472 307 416 minecraft:netherrack
fill 471 300 417 473 300 417 minecraft:red_nether_bricks
fill 471 300 419 471 300 421 minecraft:red_nether_bricks
fill 471 300 423 471 300 425 minecraft:red_nether_bricks
fill 471 300 427 471 300 429 minecraft:red_nether_bricks
fill 471 300 431 471 300 433 minecraft:red_nether_bricks
fill 471 300 435 471 300 437 minecraft:red_nether_bricks
fill 471 300 439 471 300 441 minecraft:red_nether_bricks
fill 471 300 443 471 300 445 minecraft:red_nether_bricks
fill 471 300 447 471 300 449 minecraft:red_nether_bricks
fill 471 300 451 471 300 453 minecraft:red_nether_bricks
fill 471 300 455 471 300 457 minecraft:red_nether_bricks
fill 472 300 458 473 300 458 minecraft:orange_concrete
fill 473 300 416 474 300 416 minecraft:orange_concrete
fill 473 300 457 475 300 457 minecraft:red_nether_bricks
fill 474 300 458 475 307 458 minecraft:netherrack
fill 475 300 417 477 300 417 minecraft:red_nether_bricks
fill 477 300 457 479 300 457 minecraft:red_nether_bricks
fill 479 300 416 480 307 416 minecraft:netherrack
fill 479 300 417 481 300 417 minecraft:red_nether_bricks
fill 481 300 416 482 300 416 minecraft:orange_concrete
fill 481 300 457 483 300 457 minecraft:red_nether_bricks
setblock 481 300 458 minecraft:orange_concrete
fill 482 300 458 483 307 458 minecraft:netherrack
fill 483 300 416 483 307 416 minecraft:netherrack
fill 483 300 417 485 300 417 minecraft:red_nether_bricks
setblock 484 300 458 minecraft:orange_concrete
setblock 485 300 416 minecraft:orange_concrete
fill 485 300 457 487 300 457 minecraft:red_nether_bricks
fill 486 300 416 486 307 416 minecraft:netherrack
fill 486 300 458 486 307 458 minecraft:netherrack
fill 487 300 417 489 300 417 minecraft:red_nether_bricks
fill 489 300 457 491 300 457 minecraft:red_nether_bricks
fill 491 300 416 492 307 416 minecraft:netherrack
fill 491 300 417 493 300 417 minecraft:red_nether_bricks
fill 492 300 458 493 300 458 minecraft:orange_concrete
fill 493 300 416 494 300 416 minecraft:orange_concrete
fill 493 300 457 495 300 457 minecraft:red_nether_bricks
fill 494 300 458 495 307 458 minecraft:netherrack
fill 495 300 417 497 300 417 minecraft:red_nether_bricks
fill 497 300 457 499 300 457 minecraft:red_nether_bricks
fill 499 300 417 501 300 417 minecraft:red_nether_bricks
fill 500 300 416 500 307 416 minecraft:netherrack
fill 501 300 457 503 300 457 minecraft:red_nether_bricks
setblock 502 300 416 minecraft:orange_concrete
fill 503 300 416 504 307 416 minecraft:netherrack
fill 503 300 417 505 300 417 minecraft:red_nether_bricks
fill 503 300 458 503 307 458 minecraft:netherrack
fill 504 300 458 505 300 458 minecraft:orange_concrete
setblock 505 300 416 minecraft:orange_concrete
fill 505 300 457 507 300 457 minecraft:red_nether_bricks
fill 506 300 449 507 300 449 minecraft:magma_block
fill 506 300 458 507 307 458 minecraft:netherrack
fill 507 300 417 509 300 417 minecraft:red_nether_bricks
fill 507 300 448 508 300 448 minecraft:magma_block
fill 507 300 450 510 300 450 minecraft:magma_block
fill 509 300 457 511 300 457 minecraft:red_nether_bricks
fill 511 300 416 512 307 416 minecraft:netherrack
fill 511 300 417 511 300 419 minecraft:red_nether_bricks
fill 511 300 421 511 300 423 minecraft:red_nether_bricks
fill 511 300 425 511 300 427 minecraft:red_nether_bricks
fill 511 300 429 511 300 431 minecraft:red_nether_bricks
fill 511 300 433 511 300 435 minecraft:red_nether_bricks
fill 511 300 437 511 300 439 minecraft:red_nether_bricks
fill 511 300 441 511 300 443 minecraft:red_nether_bricks
fill 511 300 445 511 300 447 minecraft:red_nether_bricks
fill 511 300 449 511 300 451 minecraft:red_nether_bricks
fill 511 300 453 511 300 455 minecraft:red_nether_bricks
fill 512 300 417 512 300 418 minecraft:orange_concrete
fill 512 300 427 512 307 428 minecraft:netherrack
fill 512 300 429 512 300 430 minecraft:orange_concrete
fill 512 300 436 512 307 436 minecraft:netherrack
fill 512 300 437 512 300 438 minecraft:orange_concrete
fill 512 300 439 512 307 439 minecraft:netherrack
setblock 512 300 441 minecraft:orange_concrete
fill 512 300 447 512 307 448 minecraft:netherrack
fill 512 300 449 512 300 450 minecraft:orange_concrete
setblock 512 300 458 minecraft:orange_concrete
fill 470 301 416 470 307 417 minecraft:netherrack
fill 470 301 420 470 307 420 minecraft:netherrack
fill 470 301 428 470 307 429 minecraft:netherrack
fill 470 301 437 470 307 437 minecraft:netherrack
fill 470 301 440 470 307 441 minecraft:netherrack
fill 470 301 448 470 307 449 minecraft:netherrack
fill 472 301 458 473 307 458 minecraft:netherrack
fill 473 301 416 474 307 416 minecraft:netherrack
fill 481 301 416 482 307 416 minecraft:netherrack
fill 481 301 458 481 307 458 minecraft:netherrack
fill 484 301 458 484 307 458 minecraft:netherrack
fill 485 301 416 485 307 416 minecraft:netherrack
fill 492 301 458 493 307 458 minecraft:netherrack
fill 493 301 416 494 307 416 minecraft:netherrack
fill 502 301 416 502 307 416 minecraft:netherrack
fill 504 301 458 505 307 458 minecraft:netherrack
fill 505 301 416 505 307 416 minecraft:netherrack
fill 512 301 417 512 307 418 minecraft:netherrack
fill 512 301 429 512 307 430 minecraft:netherrack
fill 512 301 437 512 307 438 minecraft:netherrack
fill 512 301 441 512 307 441 minecraft:netherrack
fill 512 301 449 512 307 450 minecraft:netherrack
fill 512 301 458 512 307 458 minecraft:netherrack
