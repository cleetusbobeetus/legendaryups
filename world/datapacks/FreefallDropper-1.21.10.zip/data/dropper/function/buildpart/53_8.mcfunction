setblock 238 277 231 minecraft:light[level=12]
setblock 238 277 238 minecraft:light[level=12]
setblock 238 277 245 minecraft:light[level=12]
setblock 238 277 252 minecraft:light[level=12]
setblock 238 277 259 minecraft:light[level=12]
setblock 238 277 266 minecraft:light[level=12]
setblock 245 277 231 minecraft:light[level=12]
setblock 245 277 238 minecraft:light[level=12]
setblock 245 277 245 minecraft:light[level=12]
setblock 245 277 252 minecraft:light[level=12]
setblock 245 277 259 minecraft:light[level=12]
setblock 245 277 266 minecraft:light[level=12]
fill 248 277 261 250 277 261 minecraft:light_blue_stained_glass
setblock 252 277 231 minecraft:light[level=12]
setblock 252 277 238 minecraft:light[level=12]
setblock 252 277 245 minecraft:light[level=12]
setblock 252 277 252 minecraft:light[level=12]
setblock 252 277 259 minecraft:light[level=12]
setblock 252 277 266 minecraft:light[level=12]
setblock 259 277 231 minecraft:light[level=12]
setblock 259 277 238 minecraft:light[level=12]
setblock 259 277 245 minecraft:light[level=12]
setblock 259 277 259 minecraft:light[level=12]
setblock 259 277 266 minecraft:light[level=12]
fill 260 277 270 260 308 270 minecraft:black_concrete
setblock 266 277 231 minecraft:light[level=12]
setblock 266 277 238 minecraft:light[level=12]
setblock 266 277 245 minecraft:light[level=12]
setblock 266 277 252 minecraft:light[level=12]
setblock 266 277 259 minecraft:light[level=12]
setblock 266 277 266 minecraft:light[level=12]
setblock 272 277 270 minecraft:purple_concrete
setblock 273 277 231 minecraft:light[level=12]
setblock 273 277 238 minecraft:light[level=12]
setblock 273 277 245 minecraft:light[level=12]
setblock 273 277 252 minecraft:light[level=12]
setblock 273 277 259 minecraft:light[level=12]
setblock 273 277 266 minecraft:light[level=12]
setblock 277 277 246 minecraft:purple_concrete
setblock 277 277 248 minecraft:sea_lantern
setblock 277 277 251 minecraft:verdant_froglight
setblock 241 278 228 minecraft:blue_concrete
fill 246 278 246 246 278 252 minecraft:sea_lantern
fill 247 278 244 247 278 246 minecraft:sea_lantern
fill 247 278 247 255 278 251 minecraft:black_concrete
fill 247 278 252 247 278 254 minecraft:sea_lantern
fill 248 278 243 248 278 244 minecraft:sea_lantern
fill 248 278 245 264 278 246 minecraft:black_concrete
fill 248 278 252 256 278 253 minecraft:black_concrete
fill 248 278 254 248 278 255 minecraft:sea_lantern
setblock 249 278 242 minecraft:sea_lantern
fill 249 278 243 263 278 244 minecraft:black_concrete
fill 249 278 254 263 278 255 minecraft:black_concrete
setblock 249 278 256 minecraft:sea_lantern
fill 250 278 241 251 278 241 minecraft:sea_lantern
fill 250 278 242 262 278 242 minecraft:black_concrete
fill 250 278 256 262 278 256 minecraft:black_concrete
fill 250 278 257 251 278 257 minecraft:sea_lantern
fill 251 278 240 253 278 240 minecraft:sea_lantern
fill 251 278 258 253 278 258 minecraft:sea_lantern
fill 252 278 241 260 278 241 minecraft:black_concrete
fill 252 278 257 260 278 257 minecraft:black_concrete
fill 253 278 239 259 278 239 minecraft:sea_lantern
fill 253 278 259 259 278 259 minecraft:sea_lantern
fill 254 278 240 258 278 240 minecraft:black_concrete
fill 254 278 258 258 278 258 minecraft:black_concrete
fill 256 278 247 256 278 248 minecraft:black_concrete
setblock 257 278 247 minecraft:black_concrete
setblock 257 278 253 minecraft:black_concrete
fill 259 278 240 261 278 240 minecraft:sea_lantern
fill 259 278 258 261 278 258 minecraft:sea_lantern
setblock 259 278 270 minecraft:cyan_concrete
fill 261 278 241 262 278 241 minecraft:sea_lantern
fill 261 278 247 265 278 247 minecraft:black_concrete
fill 261 278 253 264 278 253 minecraft:black_concrete
fill 261 278 257 262 278 257 minecraft:sea_lantern
fill 262 278 248 265 278 248 minecraft:black_concrete
fill 262 278 252 264 278 252 minecraft:black_concrete
setblock 263 278 242 minecraft:sea_lantern
fill 263 278 249 265 278 251 minecraft:black_concrete
setblock 263 278 256 minecraft:sea_lantern
fill 264 278 243 264 278 244 minecraft:sea_lantern
fill 264 278 254 264 278 255 minecraft:sea_lantern
fill 265 278 244 265 278 246 minecraft:sea_lantern
fill 265 278 252 265 278 254 minecraft:sea_lantern
fill 266 278 246 266 278 252 minecraft:sea_lantern
fill 272 278 270 272 308 270 minecraft:black_concrete
fill 277 278 246 277 286 246 minecraft:black_concrete
fill 277 278 248 277 293 248 minecraft:black_concrete
fill 277 278 251 277 285 251 minecraft:black_concrete
setblock 277 278 264 minecraft:purple_concrete
setblock 235 279 240 minecraft:verdant_froglight
fill 241 279 228 241 308 228 minecraft:black_concrete
fill 246 279 246 246 279 252 minecraft:pearlescent_froglight
fill 247 279 244 247 279 245 minecraft:pearlescent_froglight
setblock 247 279 246 minecraft:gray_stained_glass
fill 247 279 247 247 279 250 minecraft:black_stained_glass
setblock 247 279 251 minecraft:gray_stained_glass
fill 247 279 252 247 279 254 minecraft:pearlescent_froglight
fill 248 279 243 248 279 244 minecraft:pearlescent_froglight
fill 248 279 245 248 279 246 minecraft:black_stained_glass
fill 248 279 247 249 279 249 minecraft:gray_stained_glass
fill 248 279 250 248 279 253 minecraft:black_stained_glass
fill 248 279 254 249 279 254 minecraft:gray_stained_glass
setblock 248 279 255 minecraft:pearlescent_froglight
setblock 249 279 242 minecraft:pearlescent_froglight
fill 249 279 243 249 279 245 minecraft:black_stained_glass
setblock 249 279 246 minecraft:magenta_concrete
fill 249 279 250 249 279 252 minecraft:magenta_concrete
setblock 249 279 253 minecraft:black_stained_glass
fill 249 279 255 250 279 255 minecraft:black_stained_glass
setblock 249 279 256 minecraft:pearlescent_froglight
fill 250 279 241 251 279 241 minecraft:pearlescent_froglight
fill 250 279 242 250 279 243 minecraft:black_stained_glass
fill 250 279 244 251 279 244 minecraft:gray_stained_glass
setblock 250 279 245 minecraft:magenta_concrete
fill 250 279 246 251 279 246 minecraft:gray_stained_glass
fill 250 279 247 250 279 250 minecraft:black_stained_glass
fill 250 279 251 251 279 251 minecraft:gray_stained_glass
fill 250 279 252 251 279 252 minecraft:black_stained_glass
fill 250 279 253 251 279 253 minecraft:gray_stained_glass
fill 250 279 254 251 279 254 minecraft:magenta_concrete
fill 250 279 256 251 279 256 minecraft:black_stained_glass
fill 250 279 257 251 279 257 minecraft:pearlescent_froglight
fill 251 279 240 252 279 240 minecraft:pearlescent_froglight
setblock 251 279 242 minecraft:black_stained_glass
fill 251 279 243 252 279 243 minecraft:magenta_concrete
fill 251 279 245 252 279 245 minecraft:black_stained_glass
fill 251 279 247 251 279 250 minecraft:cyan_concrete
fill 251 279 255 252 279 255 minecraft:magenta_concrete
fill 251 279 258 253 279 258 minecraft:pearlescent_froglight
fill 252 279 241 253 279 242 minecraft:gray_stained_glass
fill 252 279 244 253 279 244 minecraft:black_stained_glass
setblock 252 279 246 minecraft:cyan_concrete
fill 252 279 247 253 279 249 minecraft:gray_stained_glass
fill 252 279 250 253 279 251 minecraft:black_stained_glass
setblock 252 279 252 minecraft:cyan_concrete
setblock 252 279 253 minecraft:black_stained_glass
fill 252 279 254 253 279 254 minecraft:gray_stained_glass
fill 252 279 256 253 279 256 minecraft:gray_stained_glass
fill 252 279 257 260 279 257 minecraft:black_stained_glass
fill 253 279 239 259 279 239 minecraft:pearlescent_froglight
setblock 253 279 240 minecraft:gray_stained_glass
fill 253 279 243 259 279 243 minecraft:black_stained_glass
setblock 253 279 245 minecraft:cyan_concrete
setblock 253 279 246 minecraft:black_stained_glass
setblock 253 279 252 minecraft:black_stained_glass
setblock 253 279 253 minecraft:cyan_concrete
fill 253 279 255 255 279 255 minecraft:black_stained_glass
fill 253 279 259 259 279 259 minecraft:pearlescent_froglight
fill 254 279 240 255 279 241 minecraft:black_stained_glass
fill 254 279 242 255 279 242 minecraft:magenta_concrete
fill 254 279 244 255 279 244 minecraft:gray_stained_glass
fill 254 279 245 255 279 245 minecraft:black_stained_glass
setblock 254 279 246 minecraft:gray_stained_glass
fill 254 279 247 254 279 253 minecraft:magenta_concrete
setblock 254 279 254 minecraft:cyan_concrete
fill 254 279 256 255 279 256 minecraft:magenta_concrete
fill 254 279 258 255 279 258 minecraft:gray_stained_glass
fill 255 279 246 255 279 247 minecraft:magenta_concrete
fill 255 279 248 255 279 252 minecraft:sea_lantern
fill 255 279 253 255 279 254 minecraft:magenta_concrete
fill 256 279 240 257 279 242 minecraft:gray_stained_glass
fill 256 279 244 257 279 244 minecraft:cyan_concrete
fill 256 279 245 256 279 246 minecraft:magenta_concrete
fill 256 279 247 256 279 248 minecraft:sea_lantern
fill 256 279 252 256 279 253 minecraft:sea_lantern
fill 256 279 254 256 279 255 minecraft:magenta_concrete
fill 256 279 256 257 279 256 minecraft:gray_stained_glass
fill 256 279 258 257 279 258 minecraft:black_stained_glass
fill 257 279 245 262 279 245 minecraft:magenta_concrete
fill 257 279 246 257 279 247 minecraft:sea_lantern
fill 257 279 253 257 279 254 minecraft:sea_lantern
fill 257 279 255 262 279 255 minecraft:magenta_concrete
fill 258 279 240 258 279 241 minecraft:black_stained_glass
fill 258 279 242 259 279 242 minecraft:magenta_concrete
fill 258 279 244 259 279 244 minecraft:gray_stained_glass
fill 258 279 246 261 279 246 minecraft:sea_lantern
fill 258 279 254 261 279 254 minecraft:sea_lantern
fill 258 279 256 259 279 256 minecraft:magenta_concrete
fill 258 279 258 259 279 258 minecraft:gray_stained_glass
fill 259 279 240 261 279 240 minecraft:pearlescent_froglight
setblock 259 279 241 minecraft:black_stained_glass
fill 259 279 270 259 303 270 minecraft:black_concrete
fill 260 279 241 261 279 242 minecraft:gray_stained_glass
fill 260 279 243 261 279 243 minecraft:magenta_concrete
setblock 260 279 244 minecraft:black_stained_glass
fill 260 279 256 261 279 256 minecraft:gray_stained_glass
fill 260 279 258 261 279 258 minecraft:pearlescent_froglight
setblock 261 279 244 minecraft:magenta_concrete
fill 261 279 247 262 279 247 minecraft:sea_lantern
fill 261 279 253 262 279 253 minecraft:sea_lantern
fill 261 279 257 262 279 257 minecraft:pearlescent_froglight
setblock 262 279 241 minecraft:pearlescent_froglight
fill 262 279 242 262 279 243 minecraft:black_stained_glass
fill 262 279 244 263 279 244 minecraft:gray_stained_glass
fill 262 279 246 263 279 246 minecraft:magenta_concrete
fill 262 279 248 263 279 248 minecraft:sea_lantern
fill 262 279 252 263 279 252 minecraft:sea_lantern
fill 262 279 254 263 279 254 minecraft:magenta_concrete
setblock 262 279 256 minecraft:black_stained_glass
setblock 263 279 242 minecraft:pearlescent_froglight
setblock 263 279 243 minecraft:black_stained_glass
fill 263 279 245 264 279 245 minecraft:black_stained_glass
fill 263 279 247 264 279 247 minecraft:magenta_concrete
fill 263 279 249 263 279 251 minecraft:sea_lantern
fill 263 279 253 264 279 253 minecraft:magenta_concrete
setblock 263 279 255 minecraft:black_stained_glass
setblock 263 279 256 minecraft:pearlescent_froglight
fill 264 279 243 264 279 244 minecraft:pearlescent_froglight
setblock 264 279 246 minecraft:black_stained_glass
fill 264 279 248 264 279 252 minecraft:magenta_concrete
setblock 264 279 254 minecraft:gray_stained_glass
setblock 264 279 255 minecraft:pearlescent_froglight
fill 265 279 244 265 279 246 minecraft:pearlescent_froglight
fill 265 279 247 265 279 249 minecraft:gray_stained_glass
fill 265 279 250 265 279 251 minecraft:black_stained_glass
fill 265 279 252 265 279 254 minecraft:pearlescent_froglight
fill 266 279 246 266 279 252 minecraft:pearlescent_froglight
setblock 275 279 228 minecraft:verdant_froglight
fill 277 279 264 277 285 264 minecraft:black_concrete
fill 235 280 240 235 308 240 minecraft:black_concrete
setblock 235 280 243 minecraft:verdant_froglight
fill 275 280 228 275 308 228 minecraft:black_concrete
fill 235 281 243 235 308 243 minecraft:black_concrete
setblock 235 281 261 minecraft:purple_concrete
setblock 256 281 228 minecraft:cyan_concrete
setblock 269 281 270 minecraft:pearlescent_froglight
fill 235 282 261 235 308 261 minecraft:black_concrete
fill 256 282 228 256 308 228 minecraft:black_concrete
setblock 258 282 270 minecraft:cyan_concrete
fill 269 282 270 269 308 270 minecraft:black_concrete
setblock 277 282 230 minecraft:blue_concrete
setblock 235 283 266 minecraft:verdant_froglight
fill 236 283 260 244 285 266 minecraft:gray_concrete
setblock 238 283 231 minecraft:light[level=15]
setblock 238 283 238 minecraft:light[level=12]
setblock 238 283 239 minecraft:light[level=15]
setblock 238 283 245 minecraft:light[level=12]
setblock 238 283 247 minecraft:light[level=15]
setblock 238 283 252 minecraft:light[level=12]
setblock 238 283 255 minecraft:light[level=15]
setblock 238 283 259 minecraft:light[level=12]
setblock 245 283 231 minecraft:light[level=12]
setblock 245 283 238 minecraft:light[level=12]
setblock 245 283 245 minecraft:light[level=12]
setblock 245 283 252 minecraft:light[level=12]
setblock 245 283 259 minecraft:light[level=12]
setblock 245 283 266 minecraft:light[level=12]
setblock 246 283 231 minecraft:light[level=15]
setblock 246 283 239 minecraft:light[level=15]
setblock 246 283 247 minecraft:light[level=15]
setblock 246 283 255 minecraft:light[level=15]
setblock 246 283 263 minecraft:light[level=15]
fill 248 283 229 258 299 233 minecraft:gray_concrete
setblock 252 283 238 minecraft:light[level=12]
setblock 252 283 245 minecraft:light[level=12]
setblock 252 283 252 minecraft:light[level=12]
setblock 252 283 259 minecraft:light[level=12]
setblock 252 283 266 minecraft:light[level=12]
setblock 254 283 239 minecraft:light[level=15]
setblock 254 283 247 minecraft:light[level=15]
setblock 254 283 255 minecraft:light[level=15]
setblock 254 283 263 minecraft:light[level=15]
fill 258 283 270 258 298 270 minecraft:black_concrete
setblock 259 283 231 minecraft:light[level=12]
setblock 259 283 238 minecraft:light[level=12]
setblock 259 283 245 minecraft:light[level=12]
setblock 259 283 252 minecraft:light[level=12]
setblock 259 283 259 minecraft:light[level=12]
setblock 259 283 266 minecraft:light[level=12]
setblock 262 283 231 minecraft:light[level=15]
setblock 262 283 239 minecraft:light[level=15]
setblock 262 283 247 minecraft:light[level=15]
setblock 262 283 255 minecraft:light[level=15]
setblock 262 283 263 minecraft:light[level=15]
setblock 266 283 231 minecraft:light[level=12]
setblock 266 283 238 minecraft:light[level=12]
setblock 266 283 245 minecraft:light[level=12]
setblock 266 283 252 minecraft:light[level=12]
setblock 266 283 259 minecraft:light[level=12]
setblock 266 283 266 minecraft:light[level=12]
setblock 270 283 231 minecraft:light[level=15]
setblock 270 283 239 minecraft:light[level=15]
setblock 270 283 247 minecraft:light[level=15]
setblock 270 283 255 minecraft:light[level=15]
setblock 270 283 263 minecraft:light[level=15]
setblock 273 283 231 minecraft:light[level=12]
setblock 273 283 238 minecraft:light[level=12]
setblock 273 283 245 minecraft:light[level=12]
setblock 273 283 252 minecraft:light[level=12]
setblock 273 283 259 minecraft:light[level=12]
setblock 273 283 266 minecraft:light[level=12]
fill 277 283 230 277 308 230 minecraft:black_concrete
fill 235 284 266 235 308 266 minecraft:black_concrete
setblock 250 284 270 minecraft:cyan_concrete
setblock 260 284 228 minecraft:purple_concrete
setblock 277 284 244 minecraft:verdant_froglight
setblock 277 284 255 minecraft:cyan_concrete
fill 250 285 270 250 308 270 minecraft:black_concrete
setblock 256 285 270 minecraft:magenta_concrete
fill 260 285 228 260 308 228 minecraft:black_concrete
setblock 262 285 228 minecraft:cyan_concrete
fill 277 285 244 277 287 244 minecraft:black_concrete
fill 277 285 255 277 303 255 minecraft:black_concrete
fill 236 286 260 236 299 260 minecraft:gray_concrete
setblock 236 286 261 minecraft:sea_lantern
fill 236 286 262 236 299 262 minecraft:gray_concrete
setblock 236 286 263 minecraft:sea_lantern
fill 236 286 264 236 299 264 minecraft:gray_concrete
setblock 236 286 265 minecraft:sea_lantern
fill 236 286 266 236 299 266 minecraft:gray_concrete
setblock 237 286 260 minecraft:sea_lantern
fill 237 286 261 237 299 261 minecraft:gray_concrete
setblock 237 286 262 minecraft:sea_lantern
fill 237 286 263 237 299 263 minecraft:gray_concrete
setblock 237 286 264 minecraft:sea_lantern
fill 237 286 265 237 299 265 minecraft:gray_concrete
setblock 237 286 266 minecraft:sea_lantern
fill 238 286 260 238 299 260 minecraft:gray_concrete
setblock 238 286 261 minecraft:sea_lantern
fill 238 286 262 238 299 262 minecraft:gray_concrete
setblock 238 286 263 minecraft:sea_lantern
fill 238 286 264 238 299 264 minecraft:gray_concrete
setblock 238 286 265 minecraft:sea_lantern
fill 238 286 266 238 299 266 minecraft:gray_concrete
setblock 239 286 260 minecraft:sea_lantern
fill 239 286 261 239 299 261 minecraft:gray_concrete
setblock 239 286 262 minecraft:sea_lantern
fill 239 286 263 239 299 263 minecraft:gray_concrete
setblock 239 286 264 minecraft:sea_lantern
fill 239 286 265 239 299 265 minecraft:gray_concrete
setblock 239 286 266 minecraft:sea_lantern
fill 240 286 260 240 299 260 minecraft:gray_concrete
setblock 240 286 261 minecraft:sea_lantern
fill 240 286 262 240 299 262 minecraft:gray_concrete
setblock 240 286 263 minecraft:sea_lantern
fill 240 286 264 240 299 264 minecraft:gray_concrete
setblock 240 286 265 minecraft:sea_lantern
fill 240 286 266 240 299 266 minecraft:gray_concrete
setblock 241 286 260 minecraft:sea_lantern
fill 241 286 261 241 299 261 minecraft:gray_concrete
setblock 241 286 262 minecraft:sea_lantern
fill 241 286 263 241 299 263 minecraft:gray_concrete
setblock 241 286 264 minecraft:sea_lantern
fill 241 286 265 241 299 265 minecraft:gray_concrete
setblock 241 286 266 minecraft:sea_lantern
fill 242 286 260 242 299 260 minecraft:gray_concrete
setblock 242 286 261 minecraft:sea_lantern
fill 242 286 262 242 299 262 minecraft:gray_concrete
setblock 242 286 263 minecraft:sea_lantern
fill 242 286 264 242 299 264 minecraft:gray_concrete
setblock 242 286 265 minecraft:sea_lantern
fill 242 286 266 242 299 266 minecraft:gray_concrete
setblock 243 286 260 minecraft:sea_lantern
fill 243 286 261 243 299 261 minecraft:gray_concrete
setblock 243 286 262 minecraft:sea_lantern
fill 243 286 263 243 299 263 minecraft:gray_concrete
setblock 243 286 264 minecraft:sea_lantern
fill 243 286 265 243 299 265 minecraft:gray_concrete
setblock 243 286 266 minecraft:sea_lantern
fill 244 286 260 244 299 260 minecraft:gray_concrete
setblock 244 286 261 minecraft:sea_lantern
fill 244 286 262 244 299 262 minecraft:gray_concrete
setblock 244 286 263 minecraft:sea_lantern
fill 244 286 264 244 299 264 minecraft:gray_concrete
setblock 244 286 265 minecraft:sea_lantern
fill 244 286 266 244 299 266 minecraft:gray_concrete
fill 256 286 270 256 296 270 minecraft:black_concrete
fill 262 286 228 262 308 228 minecraft:black_concrete
setblock 277 286 251 minecraft:pearlescent_froglight
setblock 277 286 264 minecraft:pearlescent_froglight
setblock 235 287 238 minecraft:cyan_concrete
setblock 235 287 249 minecraft:verdant_froglight
setblock 235 287 265 minecraft:pearlescent_froglight
fill 236 287 261 236 288 261 minecraft:gray_concrete
fill 236 287 263 236 288 263 minecraft:gray_concrete
fill 236 287 265 236 288 265 minecraft:gray_concrete
fill 237 287 260 237 288 260 minecraft:gray_concrete
fill 237 287 262 237 288 262 minecraft:gray_concrete
fill 237 287 264 237 288 264 minecraft:gray_concrete
fill 237 287 266 237 288 266 minecraft:gray_concrete
fill 238 287 261 238 288 261 minecraft:gray_concrete
fill 238 287 263 238 288 263 minecraft:gray_concrete
fill 238 287 265 238 288 265 minecraft:gray_concrete
fill 239 287 260 239 288 260 minecraft:gray_concrete
fill 239 287 262 239 288 262 minecraft:gray_concrete
fill 239 287 264 239 288 264 minecraft:gray_concrete
fill 239 287 266 239 288 266 minecraft:gray_concrete
fill 240 287 261 240 288 261 minecraft:gray_concrete
fill 240 287 263 240 288 263 minecraft:gray_concrete
fill 240 287 265 240 288 265 minecraft:gray_concrete
fill 241 287 260 241 288 260 minecraft:gray_concrete
fill 241 287 262 241 288 262 minecraft:gray_concrete
fill 241 287 264 241 288 264 minecraft:gray_concrete
fill 241 287 266 241 288 266 minecraft:gray_concrete
fill 242 287 261 242 288 261 minecraft:gray_concrete
fill 242 287 263 242 288 263 minecraft:gray_concrete
fill 242 287 265 242 288 265 minecraft:gray_concrete
fill 243 287 260 243 288 260 minecraft:gray_concrete
fill 243 287 262 243 288 262 minecraft:gray_concrete
fill 243 287 264 243 288 264 minecraft:gray_concrete
fill 243 287 266 243 288 266 minecraft:gray_concrete
fill 244 287 261 244 288 261 minecraft:gray_concrete
fill 244 287 263 244 288 263 minecraft:gray_concrete
fill 244 287 265 244 288 265 minecraft:gray_concrete
setblock 277 287 246 minecraft:pearlescent_froglight
fill 277 287 251 277 308 251 minecraft:black_concrete
setblock 277 287 261 minecraft:purple_concrete
fill 277 287 264 277 299 264 minecraft:black_concrete
fill 235 288 238 235 308 238 minecraft:black_concrete
fill 235 288 249 235 308 249 minecraft:black_concrete
setblock 235 288 255 minecraft:cyan_concrete
fill 235 288 265 235 308 265 minecraft:black_concrete
setblock 277 288 240 minecraft:purple_concrete
setblock 277 288 244 minecraft:cyan_concrete
fill 277 288 246 277 308 246 minecraft:black_concrete
fill 277 288 261 277 308 261 minecraft:black_concrete
setblock 235 289 229 minecraft:ochre_froglight
fill 235 289 255 235 308 255 minecraft:black_concrete
setblock 236 289 261 minecraft:sea_lantern
setblock 236 289 263 minecraft:sea_lantern
setblock 236 289 265 minecraft:sea_lantern
setblock 237 289 260 minecraft:sea_lantern
setblock 237 289 262 minecraft:sea_lantern
setblock 237 289 264 minecraft:sea_lantern
setblock 237 289 266 minecraft:sea_lantern
setblock 238 289 231 minecraft:light[level=12]
setblock 238 289 238 minecraft:light[level=12]
setblock 238 289 245 minecraft:light[level=12]
setblock 238 289 252 minecraft:light[level=12]
setblock 238 289 259 minecraft:light[level=12]
setblock 238 289 261 minecraft:sea_lantern
setblock 238 289 263 minecraft:sea_lantern
setblock 238 289 265 minecraft:sea_lantern
setblock 239 289 260 minecraft:sea_lantern
setblock 239 289 262 minecraft:sea_lantern
setblock 239 289 264 minecraft:sea_lantern
setblock 239 289 266 minecraft:sea_lantern
setblock 240 289 261 minecraft:sea_lantern
setblock 240 289 263 minecraft:sea_lantern
setblock 240 289 265 minecraft:sea_lantern
setblock 241 289 260 minecraft:sea_lantern
setblock 241 289 262 minecraft:sea_lantern
setblock 241 289 264 minecraft:sea_lantern
setblock 241 289 266 minecraft:sea_lantern
setblock 242 289 261 minecraft:sea_lantern
setblock 242 289 263 minecraft:sea_lantern
setblock 242 289 265 minecraft:sea_lantern
setblock 243 289 260 minecraft:sea_lantern
setblock 243 289 262 minecraft:sea_lantern
setblock 243 289 264 minecraft:sea_lantern
setblock 243 289 266 minecraft:sea_lantern
setblock 244 289 261 minecraft:sea_lantern
setblock 244 289 263 minecraft:sea_lantern
setblock 244 289 265 minecraft:sea_lantern
setblock 245 289 228 minecraft:pearlescent_froglight
setblock 245 289 231 minecraft:light[level=12]
setblock 245 289 238 minecraft:light[level=12]
setblock 245 289 245 minecraft:light[level=12]
setblock 245 289 252 minecraft:light[level=12]
setblock 245 289 259 minecraft:light[level=12]
setblock 245 289 266 minecraft:light[level=12]
setblock 251 289 228 minecraft:blue_concrete
setblock 252 289 238 minecraft:light[level=12]
setblock 252 289 245 minecraft:light[level=12]
setblock 252 289 252 minecraft:light[level=12]
setblock 252 289 259 minecraft:light[level=12]
setblock 252 289 266 minecraft:light[level=12]
setblock 259 289 231 minecraft:light[level=12]
setblock 259 289 238 minecraft:light[level=12]
setblock 259 289 245 minecraft:light[level=12]
setblock 259 289 252 minecraft:light[level=12]
setblock 259 289 259 minecraft:light[level=12]
setblock 259 289 266 minecraft:light[level=12]
fill 262 289 229 262 290 231 minecraft:iron_block
setblock 266 289 231 minecraft:light[level=12]
setblock 266 289 238 minecraft:light[level=12]
setblock 266 289 245 minecraft:light[level=12]
setblock 266 289 252 minecraft:light[level=12]
setblock 266 289 259 minecraft:light[level=12]
setblock 266 289 266 minecraft:light[level=12]
setblock 273 289 231 minecraft:light[level=12]
setblock 273 289 238 minecraft:light[level=12]
setblock 273 289 245 minecraft:light[level=12]
setblock 273 289 252 minecraft:light[level=12]
setblock 273 289 259 minecraft:light[level=12]
setblock 273 289 266 minecraft:light[level=12]
fill 277 289 240 277 308 240 minecraft:black_concrete
fill 277 289 244 277 308 244 minecraft:black_concrete
setblock 277 289 260 minecraft:ochre_froglight
fill 235 290 229 235 300 229 minecraft:black_concrete
setblock 235 290 244 minecraft:verdant_froglight
fill 236 290 261 236 291 261 minecraft:gray_concrete
fill 236 290 263 236 291 263 minecraft:gray_concrete
fill 236 290 265 236 291 265 minecraft:gray_concrete
fill 237 290 260 237 291 260 minecraft:gray_concrete
fill 237 290 262 237 291 262 minecraft:gray_concrete
fill 237 290 264 237 291 264 minecraft:gray_concrete
fill 237 290 266 237 291 266 minecraft:gray_concrete
setblock 238 290 231 minecraft:light[level=15]
setblock 238 290 239 minecraft:light[level=15]
setblock 238 290 247 minecraft:light[level=15]
setblock 238 290 255 minecraft:light[level=15]
fill 238 290 261 238 291 261 minecraft:gray_concrete
fill 238 290 263 238 291 263 minecraft:gray_concrete
fill 238 290 265 238 291 265 minecraft:gray_concrete
fill 239 290 260 239 291 260 minecraft:gray_concrete
fill 239 290 262 239 291 262 minecraft:gray_concrete
fill 239 290 264 239 291 264 minecraft:gray_concrete
fill 239 290 266 239 291 266 minecraft:gray_concrete
fill 240 290 261 240 291 261 minecraft:gray_concrete
fill 240 290 263 240 291 263 minecraft:gray_concrete
fill 240 290 265 240 291 265 minecraft:gray_concrete
fill 241 290 260 241 291 260 minecraft:gray_concrete
fill 241 290 262 241 291 262 minecraft:gray_concrete
fill 241 290 264 241 291 264 minecraft:gray_concrete
fill 241 290 266 241 291 266 minecraft:gray_concrete
fill 242 290 261 242 291 261 minecraft:gray_concrete
fill 242 290 263 242 291 263 minecraft:gray_concrete
fill 242 290 265 242 291 265 minecraft:gray_concrete
fill 243 290 260 243 291 260 minecraft:gray_concrete
fill 243 290 262 243 291 262 minecraft:gray_concrete
fill 243 290 264 243 291 264 minecraft:gray_concrete
fill 243 290 266 243 291 266 minecraft:gray_concrete
fill 244 290 261 244 291 261 minecraft:gray_concrete
fill 244 290 263 244 291 263 minecraft:gray_concrete
fill 244 290 265 244 291 265 minecraft:gray_concrete
fill 245 290 228 245 308 228 minecraft:black_concrete
setblock 246 290 231 minecraft:light[level=15]
setblock 246 290 239 minecraft:light[level=15]
setblock 246 290 247 minecraft:light[level=15]
setblock 246 290 255 minecraft:light[level=15]
setblock 246 290 263 minecraft:light[level=15]
fill 251 290 228 251 308 228 minecraft:black_concrete
setblock 253 290 270 minecraft:magenta_concrete
setblock 254 290 239 minecraft:light[level=15]
setblock 254 290 247 minecraft:light[level=15]
setblock 254 290 255 minecraft:light[level=15]
setblock 254 290 263 minecraft:light[level=15]
setblock 262 290 239 minecraft:light[level=15]
setblock 262 290 247 minecraft:light[level=15]
setblock 262 290 255 minecraft:light[level=15]
setblock 262 290 263 minecraft:light[level=15]
setblock 270 290 231 minecraft:light[level=15]
setblock 270 290 239 minecraft:light[level=15]
setblock 270 290 247 minecraft:light[level=15]
setblock 270 290 255 minecraft:light[level=15]
setblock 270 290 263 minecraft:light[level=15]
fill 277 290 260 277 308 260 minecraft:black_concrete
fill 235 291 244 235 308 244 minecraft:black_concrete
setblock 235 291 253 minecraft:cyan_concrete
fill 236 291 251 239 292 252 minecraft:gray_concrete
fill 240 291 252 246 292 252 minecraft:gray_concrete
fill 244 291 253 253 292 253 minecraft:gray_concrete
setblock 253 291 270 minecraft:verdant_froglight
fill 235 292 253 235 308 253 minecraft:black_concrete
setblock 236 292 261 minecraft:sea_lantern
setblock 236 292 263 minecraft:sea_lantern
setblock 236 292 265 minecraft:sea_lantern
setblock 237 292 228 minecraft:ochre_froglight
setblock 237 292 260 minecraft:sea_lantern
setblock 237 292 262 minecraft:sea_lantern
setblock 237 292 264 minecraft:sea_lantern
setblock 237 292 266 minecraft:sea_lantern
setblock 238 292 261 minecraft:sea_lantern
setblock 238 292 263 minecraft:sea_lantern
setblock 238 292 265 minecraft:sea_lantern
setblock 239 292 260 minecraft:sea_lantern
setblock 239 292 262 minecraft:sea_lantern
setblock 239 292 264 minecraft:sea_lantern
setblock 239 292 266 minecraft:sea_lantern
setblock 240 292 251 minecraft:gray_concrete
setblock 240 292 261 minecraft:sea_lantern
setblock 240 292 263 minecraft:sea_lantern
setblock 240 292 265 minecraft:sea_lantern
setblock 241 292 260 minecraft:sea_lantern
setblock 241 292 262 minecraft:sea_lantern
setblock 241 292 264 minecraft:sea_lantern
setblock 241 292 266 minecraft:sea_lantern
fill 242 292 253 243 292 253 minecraft:gray_concrete
setblock 242 292 261 minecraft:sea_lantern
setblock 242 292 263 minecraft:sea_lantern
setblock 242 292 265 minecraft:sea_lantern
setblock 243 292 260 minecraft:sea_lantern
setblock 243 292 262 minecraft:sea_lantern
setblock 243 292 264 minecraft:sea_lantern
setblock 243 292 266 minecraft:sea_lantern
setblock 244 292 261 minecraft:sea_lantern
setblock 244 292 263 minecraft:sea_lantern
setblock 244 292 265 minecraft:sea_lantern
fill 247 292 252 249 292 252 minecraft:gray_concrete
fill 251 292 254 267 292 254 minecraft:gray_concrete
setblock 253 292 270 minecraft:black_concrete
fill 254 292 253 256 292 253 minecraft:gray_concrete
fill 259 292 255 275 292 255 minecraft:gray_concrete
fill 268 292 256 276 292 256 minecraft:gray_concrete
setblock 277 292 247 minecraft:pearlescent_froglight
fill 236 293 251 237 293 251 minecraft:magenta_concrete
fill 236 293 261 236 294 261 minecraft:gray_concrete
fill 236 293 263 236 294 263 minecraft:gray_concrete
fill 236 293 265 236 294 265 minecraft:gray_concrete
fill 237 293 228 237 308 228 minecraft:black_concrete
fill 237 293 252 245 293 252 minecraft:magenta_concrete
fill 237 293 260 237 294 260 minecraft:gray_concrete
fill 237 293 262 237 294 262 minecraft:gray_concrete
fill 237 293 264 237 294 264 minecraft:gray_concrete
fill 237 293 266 237 294 266 minecraft:gray_concrete
fill 238 293 261 238 294 261 minecraft:gray_concrete
fill 238 293 263 238 294 263 minecraft:gray_concrete
fill 238 293 265 238 294 265 minecraft:gray_concrete
fill 239 293 260 239 294 260 minecraft:gray_concrete
fill 239 293 262 239 294 262 minecraft:gray_concrete
fill 239 293 264 239 294 264 minecraft:gray_concrete
fill 239 293 266 239 294 266 minecraft:gray_concrete
fill 240 293 261 240 294 261 minecraft:gray_concrete
fill 240 293 263 240 294 263 minecraft:gray_concrete
fill 240 293 265 240 294 265 minecraft:gray_concrete
fill 241 293 260 241 294 260 minecraft:gray_concrete
fill 241 293 262 241 294 262 minecraft:gray_concrete
fill 241 293 264 241 294 264 minecraft:gray_concrete
fill 241 293 266 241 294 266 minecraft:gray_concrete
fill 242 293 261 242 294 261 minecraft:gray_concrete
fill 242 293 263 242 294 263 minecraft:gray_concrete
fill 242 293 265 242 294 265 minecraft:gray_concrete
fill 243 293 260 243 294 260 minecraft:gray_concrete
fill 243 293 262 243 294 262 minecraft:gray_concrete
fill 243 293 264 243 294 264 minecraft:gray_concrete
fill 243 293 266 243 294 266 minecraft:gray_concrete
fill 244 293 261 244 294 261 minecraft:gray_concrete
fill 244 293 263 244 294 263 minecraft:gray_concrete
fill 244 293 265 244 294 265 minecraft:gray_concrete
fill 246 293 253 253 293 253 minecraft:magenta_concrete
setblock 253 293 270 minecraft:ochre_froglight
setblock 256 293 254 minecraft:magenta_concrete
fill 257 293 254 264 293 254 minecraft:gray_concrete
setblock 261 293 270 minecraft:magenta_concrete
fill 263 293 255 274 293 255 minecraft:gray_concrete
setblock 265 293 228 minecraft:ochre_froglight
fill 270 293 256 276 293 256 minecraft:gray_concrete
fill 277 293 247 277 308 247 minecraft:black_concrete
setblock 277 293 253 minecraft:cyan_concrete
setblock 235 294 241 minecraft:cyan_concrete
setblock 235 294 269 minecraft:pearlescent_froglight
setblock 248 294 228 minecraft:cyan_concrete
fill 253 294 270 253 308 270 minecraft:black_concrete
fill 258 294 254 261 294 254 minecraft:magenta_concrete
fill 261 294 270 261 308 270 minecraft:black_concrete
fill 265 294 228 265 308 228 minecraft:black_concrete
fill 265 294 255 271 294 255 minecraft:magenta_concrete
fill 272 294 256 276 294 256 minecraft:magenta_concrete
setblock 277 294 248 minecraft:purple_concrete
fill 277 294 253 277 308 253 minecraft:black_concrete
fill 235 295 241 235 304 241 minecraft:black_concrete
fill 235 295 269 235 308 269 minecraft:black_concrete
setblock 236 295 261 minecraft:sea_lantern
setblock 236 295 263 minecraft:sea_lantern
setblock 236 295 265 minecraft:sea_lantern
setblock 237 295 260 minecraft:sea_lantern
setblock 237 295 262 minecraft:sea_lantern
setblock 237 295 264 minecraft:sea_lantern
setblock 237 295 266 minecraft:sea_lantern
setblock 238 295 231 minecraft:light[level=12]
setblock 238 295 238 minecraft:light[level=12]
setblock 238 295 245 minecraft:light[level=12]
setblock 238 295 252 minecraft:light[level=12]
setblock 238 295 259 minecraft:light[level=12]
setblock 238 295 261 minecraft:sea_lantern
setblock 238 295 263 minecraft:sea_lantern
setblock 238 295 265 minecraft:sea_lantern
setblock 239 295 260 minecraft:sea_lantern
setblock 239 295 262 minecraft:sea_lantern
setblock 239 295 264 minecraft:sea_lantern
setblock 239 295 266 minecraft:sea_lantern
setblock 240 295 261 minecraft:sea_lantern
setblock 240 295 263 minecraft:sea_lantern
setblock 240 295 265 minecraft:sea_lantern
setblock 241 295 260 minecraft:sea_lantern
setblock 241 295 262 minecraft:sea_lantern
setblock 241 295 264 minecraft:sea_lantern
setblock 241 295 266 minecraft:sea_lantern
setblock 242 295 261 minecraft:sea_lantern
setblock 242 295 263 minecraft:sea_lantern
setblock 242 295 265 minecraft:sea_lantern
setblock 243 295 260 minecraft:sea_lantern
setblock 243 295 262 minecraft:sea_lantern
setblock 243 295 264 minecraft:sea_lantern
setblock 243 295 266 minecraft:sea_lantern
setblock 244 295 261 minecraft:sea_lantern
setblock 244 295 263 minecraft:sea_lantern
setblock 244 295 265 minecraft:sea_lantern
setblock 245 295 231 minecraft:light[level=12]
setblock 245 295 238 minecraft:light[level=12]
setblock 245 295 245 minecraft:light[level=12]
setblock 245 295 252 minecraft:light[level=12]
setblock 245 295 259 minecraft:light[level=12]
setblock 245 295 266 minecraft:light[level=12]
fill 248 295 228 248 308 228 minecraft:black_concrete
setblock 252 295 238 minecraft:light[level=12]
setblock 252 295 245 minecraft:light[level=12]
setblock 252 295 252 minecraft:light[level=12]
setblock 252 295 259 minecraft:light[level=12]
setblock 252 295 266 minecraft:light[level=12]
setblock 259 295 231 minecraft:light[level=12]
setblock 259 295 238 minecraft:light[level=12]
setblock 259 295 245 minecraft:light[level=12]
setblock 259 295 252 minecraft:light[level=12]
setblock 259 295 259 minecraft:light[level=12]
setblock 259 295 266 minecraft:light[level=12]
setblock 266 295 231 minecraft:light[level=12]
setblock 266 295 238 minecraft:light[level=12]
setblock 266 295 245 minecraft:light[level=12]
setblock 266 295 252 minecraft:light[level=12]
setblock 266 295 259 minecraft:light[level=12]
setblock 266 295 266 minecraft:light[level=12]
setblock 273 295 231 minecraft:light[level=12]
setblock 273 295 238 minecraft:light[level=12]
setblock 273 295 245 minecraft:light[level=12]
setblock 273 295 252 minecraft:light[level=12]
setblock 273 295 259 minecraft:light[level=12]
setblock 273 295 266 minecraft:light[level=12]
fill 277 295 248 277 308 248 minecraft:black_concrete
fill 236 296 261 236 297 261 minecraft:gray_concrete
fill 236 296 263 236 297 263 minecraft:gray_concrete
fill 236 296 265 236 297 265 minecraft:gray_concrete
setblock 236 296 270 minecraft:verdant_froglight
fill 237 296 260 237 297 260 minecraft:gray_concrete
fill 237 296 262 237 297 262 minecraft:gray_concrete
fill 237 296 264 237 297 264 minecraft:gray_concrete
fill 237 296 266 237 297 266 minecraft:gray_concrete
fill 238 296 261 238 297 261 minecraft:gray_concrete
fill 238 296 263 238 297 263 minecraft:gray_concrete
fill 238 296 265 238 297 265 minecraft:gray_concrete
fill 239 296 260 239 297 260 minecraft:gray_concrete
fill 239 296 262 239 297 262 minecraft:gray_concrete
fill 239 296 264 239 297 264 minecraft:gray_concrete
fill 239 296 266 239 297 266 minecraft:gray_concrete
fill 240 296 261 240 297 261 minecraft:gray_concrete
fill 240 296 263 240 297 263 minecraft:gray_concrete
fill 240 296 265 240 297 265 minecraft:gray_concrete
fill 241 296 260 241 297 260 minecraft:gray_concrete
fill 241 296 262 241 297 262 minecraft:gray_concrete
fill 241 296 264 241 297 264 minecraft:gray_concrete
fill 241 296 266 241 297 266 minecraft:gray_concrete
fill 242 296 261 242 297 261 minecraft:gray_concrete
fill 242 296 263 242 297 263 minecraft:gray_concrete
fill 242 296 265 242 297 265 minecraft:gray_concrete
fill 243 296 260 243 297 260 minecraft:gray_concrete
fill 243 296 262 243 297 262 minecraft:gray_concrete
fill 243 296 264 243 297 264 minecraft:gray_concrete
fill 243 296 266 243 297 266 minecraft:gray_concrete
fill 244 296 261 244 297 261 minecraft:gray_concrete
fill 244 296 263 244 297 263 minecraft:gray_concrete
fill 244 296 265 244 297 265 minecraft:gray_concrete
fill 236 297 270 236 308 270 minecraft:black_concrete
setblock 238 297 231 minecraft:light[level=15]
setblock 238 297 239 minecraft:light[level=15]
setblock 238 297 247 minecraft:light[level=15]
setblock 238 297 255 minecraft:light[level=15]
setblock 246 297 231 minecraft:light[level=15]
setblock 246 297 239 minecraft:light[level=15]
setblock 246 297 247 minecraft:light[level=15]
setblock 246 297 255 minecraft:light[level=15]
setblock 246 297 263 minecraft:light[level=15]
setblock 254 297 228 minecraft:ochre_froglight
setblock 254 297 239 minecraft:light[level=15]
setblock 254 297 247 minecraft:light[level=15]
setblock 254 297 255 minecraft:light[level=15]
setblock 254 297 263 minecraft:light[level=15]
setblock 256 297 270 minecraft:pearlescent_froglight
setblock 262 297 231 minecraft:light[level=15]
setblock 262 297 239 minecraft:light[level=15]
setblock 262 297 247 minecraft:light[level=15]
setblock 262 297 255 minecraft:light[level=15]
setblock 262 297 263 minecraft:light[level=15]
setblock 270 297 231 minecraft:light[level=15]
setblock 270 297 239 minecraft:light[level=15]
setblock 270 297 247 minecraft:light[level=15]
setblock 270 297 255 minecraft:light[level=15]
setblock 270 297 263 minecraft:light[level=15]
setblock 236 298 261 minecraft:sea_lantern
setblock 236 298 263 minecraft:sea_lantern
setblock 236 298 265 minecraft:sea_lantern
setblock 237 298 260 minecraft:sea_lantern
setblock 237 298 262 minecraft:sea_lantern
setblock 237 298 264 minecraft:sea_lantern
setblock 237 298 266 minecraft:sea_lantern
setblock 238 298 261 minecraft:sea_lantern
setblock 238 298 263 minecraft:sea_lantern
setblock 238 298 265 minecraft:sea_lantern
setblock 239 298 260 minecraft:sea_lantern
setblock 239 298 262 minecraft:sea_lantern
setblock 239 298 264 minecraft:sea_lantern
setblock 239 298 266 minecraft:sea_lantern
setblock 240 298 261 minecraft:sea_lantern
setblock 240 298 263 minecraft:sea_lantern
setblock 240 298 265 minecraft:sea_lantern
setblock 241 298 260 minecraft:sea_lantern
setblock 241 298 262 minecraft:sea_lantern
setblock 241 298 264 minecraft:sea_lantern
setblock 241 298 266 minecraft:sea_lantern
setblock 242 298 261 minecraft:sea_lantern
setblock 242 298 263 minecraft:sea_lantern
setblock 242 298 265 minecraft:sea_lantern
setblock 243 298 260 minecraft:sea_lantern
setblock 243 298 262 minecraft:sea_lantern
setblock 243 298 264 minecraft:sea_lantern
setblock 243 298 266 minecraft:sea_lantern
setblock 244 298 261 minecraft:sea_lantern
setblock 244 298 263 minecraft:sea_lantern
setblock 244 298 265 minecraft:sea_lantern
setblock 245 298 270 minecraft:ochre_froglight
fill 254 298 228 254 308 228 minecraft:black_concrete
fill 256 298 270 256 308 270 minecraft:black_concrete
setblock 277 298 234 minecraft:magenta_concrete
setblock 236 299 261 minecraft:gray_concrete
setblock 236 299 263 minecraft:gray_concrete
setblock 236 299 265 minecraft:gray_concrete
setblock 237 299 260 minecraft:gray_concrete
setblock 237 299 262 minecraft:gray_concrete
setblock 237 299 264 minecraft:gray_concrete
setblock 237 299 266 minecraft:gray_concrete
setblock 238 299 261 minecraft:gray_concrete
setblock 238 299 263 minecraft:gray_concrete
setblock 238 299 265 minecraft:gray_concrete
setblock 239 299 260 minecraft:gray_concrete
setblock 239 299 262 minecraft:gray_concrete
setblock 239 299 264 minecraft:gray_concrete
setblock 239 299 266 minecraft:gray_concrete
setblock 240 299 261 minecraft:gray_concrete
setblock 240 299 263 minecraft:gray_concrete
setblock 240 299 265 minecraft:gray_concrete
setblock 241 299 260 minecraft:gray_concrete
setblock 241 299 262 minecraft:gray_concrete
setblock 241 299 264 minecraft:gray_concrete
setblock 241 299 266 minecraft:gray_concrete
setblock 242 299 261 minecraft:gray_concrete
setblock 242 299 263 minecraft:gray_concrete
setblock 242 299 265 minecraft:gray_concrete
setblock 243 299 260 minecraft:gray_concrete
setblock 243 299 262 minecraft:gray_concrete
setblock 243 299 264 minecraft:gray_concrete
setblock 243 299 266 minecraft:gray_concrete
setblock 244 299 261 minecraft:gray_concrete
setblock 244 299 263 minecraft:gray_concrete
setblock 244 299 265 minecraft:gray_concrete
fill 245 299 270 245 308 270 minecraft:black_concrete
setblock 258 299 270 minecraft:ochre_froglight
setblock 266 299 270 minecraft:ochre_froglight
fill 277 299 234 277 308 234 minecraft:black_concrete
setblock 277 299 239 minecraft:purple_concrete
setblock 235 300 231 minecraft:ochre_froglight
setblock 246 300 228 minecraft:sea_lantern
fill 258 300 270 258 308 270 minecraft:black_concrete
fill 266 300 270 266 308 270 minecraft:black_concrete
setblock 277 300 237 minecraft:verdant_froglight
fill 277 300 239 277 308 239 minecraft:black_concrete
setblock 277 300 264 minecraft:cyan_concrete
setblock 235 301 229 minecraft:ochre_froglight
fill 235 301 231 235 308 231 minecraft:black_concrete
setblock 238 301 231 minecraft:light[level=12]
setblock 238 301 238 minecraft:light[level=12]
setblock 238 301 245 minecraft:light[level=12]
setblock 238 301 252 minecraft:light[level=12]
setblock 238 301 259 minecraft:light[level=12]
setblock 238 301 266 minecraft:light[level=12]
setblock 245 301 231 minecraft:light[level=12]
setblock 245 301 238 minecraft:light[level=12]
setblock 245 301 245 minecraft:light[level=12]
setblock 245 301 252 minecraft:light[level=12]
setblock 245 301 259 minecraft:light[level=12]
setblock 245 301 266 minecraft:light[level=12]
fill 246 301 228 246 308 228 minecraft:black_concrete
setblock 252 301 231 minecraft:light[level=12]
setblock 252 301 238 minecraft:light[level=12]
setblock 252 301 245 minecraft:light[level=12]
setblock 252 301 252 minecraft:light[level=12]
setblock 252 301 259 minecraft:light[level=12]
setblock 252 301 266 minecraft:light[level=12]
setblock 259 301 231 minecraft:light[level=12]
setblock 259 301 238 minecraft:light[level=12]
setblock 259 301 245 minecraft:light[level=12]
setblock 259 301 252 minecraft:light[level=12]
setblock 259 301 259 minecraft:light[level=12]
setblock 259 301 266 minecraft:light[level=12]
setblock 266 301 231 minecraft:light[level=12]
setblock 266 301 238 minecraft:light[level=12]
setblock 266 301 245 minecraft:light[level=12]
setblock 266 301 252 minecraft:light[level=12]
setblock 266 301 259 minecraft:light[level=12]
setblock 266 301 266 minecraft:light[level=12]
setblock 273 301 231 minecraft:light[level=12]
setblock 273 301 238 minecraft:light[level=12]
setblock 273 301 245 minecraft:light[level=12]
setblock 273 301 252 minecraft:light[level=12]
setblock 273 301 259 minecraft:light[level=12]
setblock 273 301 266 minecraft:light[level=12]
fill 277 301 237 277 308 237 minecraft:black_concrete
fill 277 301 264 277 308 264 minecraft:black_concrete
fill 235 302 229 235 303 229 minecraft:black_concrete
setblock 236 302 228 minecraft:verdant_froglight
setblock 255 302 228 minecraft:sea_lantern
setblock 235 303 232 minecraft:magenta_concrete
fill 236 303 228 236 308 228 minecraft:black_concrete
fill 255 303 228 255 308 228 minecraft:black_concrete
setblock 235 304 229 minecraft:ochre_froglight
fill 235 304 232 235 308 232 minecraft:black_concrete
setblock 235 304 234 minecraft:sea_lantern
setblock 238 304 270 minecraft:blue_concrete
setblock 259 304 270 minecraft:blue_concrete
setblock 277 304 232 minecraft:pearlescent_froglight
setblock 277 304 255 minecraft:magenta_concrete
fill 235 305 229 235 308 229 minecraft:black_concrete
setblock 235 305 234 minecraft:verdant_froglight
setblock 235 305 241 minecraft:cyan_concrete
setblock 235 305 252 minecraft:magenta_concrete
fill 238 305 270 238 308 270 minecraft:black_concrete
fill 259 305 270 259 308 270 minecraft:black_concrete
fill 277 305 232 277 308 232 minecraft:black_concrete
fill 277 305 255 277 308 255 minecraft:black_concrete
fill 235 306 234 235 308 234 minecraft:black_concrete
fill 235 306 241 235 308 241 minecraft:black_concrete
fill 235 306 252 235 308 252 minecraft:black_concrete
setblock 257 306 228 minecraft:verdant_froglight
setblock 250 307 228 minecraft:magenta_concrete
fill 257 307 228 257 308 228 minecraft:black_concrete
setblock 271 307 270 minecraft:magenta_concrete
setblock 250 308 228 minecraft:black_concrete
setblock 267 308 228 minecraft:pearlescent_froglight
setblock 271 308 270 minecraft:black_concrete
