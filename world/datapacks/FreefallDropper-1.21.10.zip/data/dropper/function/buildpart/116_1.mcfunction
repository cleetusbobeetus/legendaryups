fill 394 134 501 394 135 501 minecraft:gold_block
fill 394 134 503 394 135 503 minecraft:gold_block
fill 395 134 498 395 135 498 minecraft:white_concrete
fill 395 134 500 395 135 500 minecraft:gold_block
fill 395 134 502 395 135 502 minecraft:gold_block
fill 395 134 504 395 135 504 minecraft:black_concrete
fill 396 134 499 396 135 499 minecraft:white_concrete
fill 396 134 501 396 135 501 minecraft:black_concrete
fill 396 134 503 396 135 503 minecraft:black_concrete
fill 376 136 468 376 143 468 minecraft:magenta_concrete
fill 376 136 476 376 143 476 minecraft:magenta_concrete
fill 376 136 484 376 143 484 minecraft:magenta_concrete
fill 376 136 492 376 143 492 minecraft:magenta_concrete
fill 376 136 500 376 143 500 minecraft:magenta_concrete
setblock 379 136 466 minecraft:light[level=14]
setblock 379 136 474 minecraft:light[level=14]
setblock 379 136 482 minecraft:light[level=14]
setblock 379 136 490 minecraft:light[level=14]
setblock 379 136 498 minecraft:light[level=14]
fill 379 136 505 379 143 505 minecraft:magenta_concrete
fill 383 136 463 383 143 463 minecraft:magenta_concrete
setblock 386 136 499 minecraft:sea_lantern
setblock 386 136 501 minecraft:sea_lantern
setblock 386 136 503 minecraft:sea_lantern
setblock 387 136 466 minecraft:light[level=14]
setblock 387 136 474 minecraft:light[level=14]
setblock 387 136 482 minecraft:light[level=14]
setblock 387 136 490 minecraft:light[level=14]
setblock 387 136 498 minecraft:sea_lantern
setblock 387 136 500 minecraft:sea_lantern
setblock 387 136 502 minecraft:sea_lantern
setblock 387 136 504 minecraft:sea_lantern
fill 387 136 505 387 143 505 minecraft:magenta_concrete
setblock 388 136 499 minecraft:sea_lantern
setblock 388 136 501 minecraft:sea_lantern
setblock 388 136 503 minecraft:sea_lantern
setblock 389 136 498 minecraft:sea_lantern
setblock 389 136 500 minecraft:sea_lantern
setblock 389 136 502 minecraft:sea_lantern
setblock 389 136 504 minecraft:sea_lantern
setblock 390 136 499 minecraft:sea_lantern
setblock 390 136 501 minecraft:sea_lantern
setblock 390 136 503 minecraft:sea_lantern
fill 391 136 463 391 143 463 minecraft:magenta_concrete
setblock 391 136 498 minecraft:sea_lantern
setblock 391 136 500 minecraft:sea_lantern
setblock 391 136 502 minecraft:sea_lantern
setblock 391 136 504 minecraft:sea_lantern
setblock 392 136 499 minecraft:sea_lantern
setblock 392 136 501 minecraft:sea_lantern
setblock 392 136 503 minecraft:sea_lantern
setblock 393 136 498 minecraft:sea_lantern
setblock 393 136 500 minecraft:sea_lantern
setblock 393 136 502 minecraft:sea_lantern
setblock 393 136 504 minecraft:sea_lantern
setblock 394 136 499 minecraft:sea_lantern
setblock 394 136 501 minecraft:sea_lantern
setblock 394 136 503 minecraft:sea_lantern
setblock 395 136 466 minecraft:light[level=14]
setblock 395 136 474 minecraft:light[level=14]
setblock 395 136 482 minecraft:light[level=14]
setblock 395 136 490 minecraft:light[level=14]
setblock 395 136 498 minecraft:sea_lantern
setblock 395 136 500 minecraft:sea_lantern
setblock 395 136 502 minecraft:sea_lantern
setblock 395 136 504 minecraft:sea_lantern
fill 395 136 505 395 143 505 minecraft:magenta_concrete
setblock 396 136 499 minecraft:sea_lantern
setblock 396 136 501 minecraft:sea_lantern
setblock 396 136 503 minecraft:sea_lantern
fill 399 136 463 399 143 463 minecraft:magenta_concrete
setblock 403 136 466 minecraft:light[level=14]
setblock 403 136 474 minecraft:light[level=14]
setblock 403 136 482 minecraft:light[level=14]
setblock 403 136 490 minecraft:light[level=14]
setblock 403 136 498 minecraft:light[level=14]
fill 403 136 505 403 143 505 minecraft:magenta_concrete
fill 407 136 463 407 143 463 minecraft:magenta_concrete
setblock 411 136 466 minecraft:light[level=14]
setblock 411 136 474 minecraft:light[level=14]
setblock 411 136 482 minecraft:light[level=14]
setblock 411 136 490 minecraft:light[level=14]
setblock 411 136 498 minecraft:light[level=14]
fill 411 136 505 411 143 505 minecraft:magenta_concrete
fill 415 136 463 415 143 463 minecraft:magenta_concrete
fill 418 136 468 418 143 468 minecraft:magenta_concrete
fill 418 136 476 418 143 476 minecraft:magenta_concrete
fill 418 136 484 418 143 484 minecraft:magenta_concrete
fill 418 136 492 418 143 492 minecraft:magenta_concrete
fill 418 136 500 418 143 500 minecraft:magenta_concrete
setblock 386 137 499 minecraft:black_concrete
setblock 386 137 501 minecraft:black_concrete
setblock 386 137 503 minecraft:black_concrete
setblock 387 137 498 minecraft:black_concrete
setblock 387 137 500 minecraft:black_concrete
setblock 387 137 502 minecraft:black_concrete
setblock 387 137 504 minecraft:black_concrete
setblock 388 137 499 minecraft:black_concrete
setblock 388 137 501 minecraft:black_concrete
setblock 388 137 503 minecraft:black_concrete
setblock 389 137 498 minecraft:black_concrete
setblock 389 137 500 minecraft:black_concrete
setblock 389 137 502 minecraft:black_concrete
setblock 389 137 504 minecraft:black_concrete
setblock 390 137 499 minecraft:black_concrete
setblock 390 137 501 minecraft:black_concrete
setblock 390 137 503 minecraft:black_concrete
setblock 391 137 498 minecraft:black_concrete
fill 391 137 500 396 137 500 minecraft:black_concrete
fill 391 137 502 395 137 502 minecraft:black_concrete
fill 391 137 504 391 176 504 minecraft:black_concrete
setblock 392 137 499 minecraft:black_concrete
fill 392 137 501 396 137 501 minecraft:black_concrete
fill 392 137 503 396 137 503 minecraft:black_concrete
fill 393 137 498 396 137 498 minecraft:black_concrete
setblock 393 137 504 minecraft:black_concrete
fill 394 137 499 396 137 499 minecraft:black_concrete
setblock 395 137 504 minecraft:black_concrete
fill 377 140 464 377 141 469 minecraft:black_concrete
fill 377 140 472 378 140 477 minecraft:black_concrete
fill 377 140 480 378 140 485 minecraft:black_concrete
fill 377 140 488 378 140 493 minecraft:black_concrete
fill 377 140 496 378 140 501 minecraft:black_concrete
fill 377 140 504 382 141 504 minecraft:black_concrete
fill 378 140 465 378 140 471 minecraft:black_concrete
fill 378 140 478 378 140 479 minecraft:black_concrete
fill 378 140 486 378 140 487 minecraft:black_concrete
fill 378 140 494 378 140 495 minecraft:black_concrete
fill 378 140 502 378 140 503 minecraft:black_concrete
fill 379 140 465 416 140 465 minecraft:black_concrete
fill 379 140 503 417 140 503 minecraft:black_concrete
fill 380 140 464 385 141 464 minecraft:black_concrete
fill 385 140 504 390 141 504 minecraft:black_concrete
fill 388 140 464 393 141 464 minecraft:black_concrete
fill 393 140 504 398 141 504 minecraft:black_concrete
fill 396 140 464 401 141 464 minecraft:black_concrete
fill 401 140 504 406 141 504 minecraft:black_concrete
fill 404 140 464 409 141 464 minecraft:black_concrete
fill 409 140 504 414 141 504 minecraft:black_concrete
fill 412 140 464 417 141 464 minecraft:black_concrete
fill 416 140 466 416 140 502 minecraft:black_concrete
fill 417 140 467 417 141 472 minecraft:black_concrete
fill 417 140 475 417 141 480 minecraft:black_concrete
fill 417 140 483 417 141 488 minecraft:black_concrete
fill 417 140 491 417 141 496 minecraft:black_concrete
fill 417 140 499 417 141 502 minecraft:black_concrete
fill 417 140 504 417 141 504 minecraft:black_concrete
fill 377 141 472 377 141 477 minecraft:black_concrete
fill 377 141 480 377 141 485 minecraft:black_concrete
fill 377 141 488 377 141 493 minecraft:black_concrete
fill 377 141 496 377 141 501 minecraft:black_concrete
setblock 417 141 503 minecraft:black_concrete
fill 376 144 468 376 149 468 minecraft:sea_lantern
fill 376 144 476 376 149 476 minecraft:sea_lantern
fill 376 144 484 376 149 484 minecraft:sea_lantern
fill 376 144 492 376 149 492 minecraft:sea_lantern
fill 376 144 500 376 149 500 minecraft:sea_lantern
setblock 379 144 466 minecraft:light[level=14]
setblock 379 144 474 minecraft:light[level=14]
setblock 379 144 482 minecraft:light[level=14]
setblock 379 144 490 minecraft:light[level=14]
setblock 379 144 498 minecraft:light[level=14]
fill 379 144 505 379 149 505 minecraft:sea_lantern
fill 383 144 463 383 149 463 minecraft:sea_lantern
setblock 387 144 466 minecraft:light[level=14]
setblock 387 144 474 minecraft:light[level=14]
setblock 387 144 482 minecraft:light[level=14]
setblock 387 144 490 minecraft:light[level=14]
setblock 387 144 498 minecraft:light[level=14]
fill 387 144 505 387 149 505 minecraft:sea_lantern
fill 391 144 463 391 149 463 minecraft:sea_lantern
setblock 395 144 466 minecraft:light[level=14]
setblock 395 144 474 minecraft:light[level=14]
setblock 395 144 482 minecraft:light[level=14]
setblock 395 144 490 minecraft:light[level=14]
setblock 395 144 498 minecraft:light[level=14]
fill 395 144 505 395 149 505 minecraft:sea_lantern
fill 399 144 463 399 149 463 minecraft:sea_lantern
setblock 403 144 466 minecraft:light[level=14]
setblock 403 144 474 minecraft:light[level=14]
setblock 403 144 482 minecraft:light[level=14]
setblock 403 144 490 minecraft:light[level=14]
setblock 403 144 498 minecraft:light[level=14]
fill 403 144 505 403 149 505 minecraft:sea_lantern
fill 407 144 463 407 149 463 minecraft:sea_lantern
setblock 411 144 466 minecraft:light[level=14]
setblock 411 144 474 minecraft:light[level=14]
setblock 411 144 482 minecraft:light[level=14]
setblock 411 144 490 minecraft:light[level=14]
setblock 411 144 498 minecraft:light[level=14]
fill 411 144 505 411 149 505 minecraft:sea_lantern
fill 415 144 463 415 149 463 minecraft:sea_lantern
fill 418 144 468 418 149 468 minecraft:sea_lantern
fill 418 144 476 418 149 476 minecraft:sea_lantern
fill 418 144 484 418 149 484 minecraft:sea_lantern
fill 418 144 492 418 149 492 minecraft:sea_lantern
fill 418 144 500 418 149 500 minecraft:sea_lantern
fill 387 149 499 388 150 500 minecraft:moss_block
fill 376 150 468 376 157 468 minecraft:magenta_concrete
fill 376 150 476 376 157 476 minecraft:magenta_concrete
fill 376 150 484 376 157 484 minecraft:magenta_concrete
fill 376 150 492 376 157 492 minecraft:magenta_concrete
fill 376 150 500 376 157 500 minecraft:magenta_concrete
fill 379 150 505 379 157 505 minecraft:magenta_concrete
fill 383 150 463 383 157 463 minecraft:magenta_concrete
fill 387 150 505 387 157 505 minecraft:magenta_concrete
fill 391 150 463 391 157 463 minecraft:magenta_concrete
fill 395 150 505 395 157 505 minecraft:magenta_concrete
fill 399 150 463 399 157 463 minecraft:magenta_concrete
fill 403 150 505 403 157 505 minecraft:magenta_concrete
fill 407 150 463 407 157 463 minecraft:magenta_concrete
fill 411 150 505 411 157 505 minecraft:magenta_concrete
fill 415 150 463 415 157 463 minecraft:magenta_concrete
fill 418 150 468 418 157 468 minecraft:magenta_concrete
fill 418 150 476 418 157 476 minecraft:magenta_concrete
fill 418 150 484 418 157 484 minecraft:magenta_concrete
fill 418 150 492 418 157 492 minecraft:magenta_concrete
fill 418 150 500 418 157 500 minecraft:magenta_concrete
setblock 379 152 466 minecraft:light[level=14]
setblock 379 152 474 minecraft:light[level=14]
setblock 379 152 482 minecraft:light[level=14]
setblock 379 152 490 minecraft:light[level=14]
setblock 379 152 498 minecraft:light[level=14]
setblock 387 152 466 minecraft:light[level=14]
setblock 387 152 474 minecraft:light[level=14]
setblock 387 152 482 minecraft:light[level=14]
setblock 387 152 490 minecraft:light[level=14]
setblock 387 152 498 minecraft:light[level=14]
setblock 395 152 466 minecraft:light[level=14]
setblock 395 152 474 minecraft:light[level=14]
setblock 395 152 482 minecraft:light[level=14]
setblock 395 152 490 minecraft:light[level=14]
setblock 395 152 498 minecraft:light[level=14]
setblock 403 152 466 minecraft:light[level=14]
setblock 403 152 474 minecraft:light[level=14]
setblock 403 152 482 minecraft:light[level=14]
setblock 403 152 490 minecraft:light[level=14]
setblock 403 152 498 minecraft:light[level=14]
setblock 411 152 466 minecraft:light[level=14]
setblock 411 152 474 minecraft:light[level=14]
setblock 411 152 482 minecraft:light[level=14]
setblock 411 152 490 minecraft:light[level=14]
setblock 411 152 498 minecraft:light[level=14]
fill 377 154 464 377 155 469 minecraft:black_concrete
fill 377 154 472 378 154 477 minecraft:black_concrete
fill 377 154 480 378 154 485 minecraft:black_concrete
fill 377 154 488 378 154 493 minecraft:black_concrete
fill 377 154 496 378 154 501 minecraft:black_concrete
fill 377 154 504 382 155 504 minecraft:black_concrete
fill 378 154 465 378 154 471 minecraft:black_concrete
fill 378 154 478 378 154 479 minecraft:black_concrete
fill 378 154 486 378 154 487 minecraft:black_concrete
fill 378 154 494 378 154 495 minecraft:black_concrete
fill 378 154 502 378 154 503 minecraft:black_concrete
fill 379 154 465 416 154 465 minecraft:black_concrete
fill 379 154 503 417 154 503 minecraft:black_concrete
fill 380 154 464 385 155 464 minecraft:black_concrete
fill 385 154 504 390 155 504 minecraft:black_concrete
fill 386 154 471 389 157 474 minecraft:white_concrete
fill 388 154 464 393 155 464 minecraft:black_concrete
fill 393 154 504 398 155 504 minecraft:black_concrete
fill 396 154 464 401 155 464 minecraft:black_concrete
fill 401 154 504 406 155 504 minecraft:black_concrete
fill 404 154 464 409 155 464 minecraft:black_concrete
fill 409 154 504 414 155 504 minecraft:black_concrete
fill 412 154 464 417 155 464 minecraft:black_concrete
fill 416 154 466 416 154 502 minecraft:black_concrete
fill 417 154 467 417 155 472 minecraft:black_concrete
fill 417 154 475 417 155 480 minecraft:black_concrete
fill 417 154 483 417 155 488 minecraft:black_concrete
fill 417 154 491 417 155 496 minecraft:black_concrete
fill 417 154 499 417 155 502 minecraft:black_concrete
fill 417 154 504 417 155 504 minecraft:black_concrete
fill 377 155 472 377 155 477 minecraft:black_concrete
fill 377 155 480 377 155 485 minecraft:black_concrete
fill 377 155 488 377 155 493 minecraft:black_concrete
fill 377 155 496 377 155 501 minecraft:black_concrete
setblock 417 155 503 minecraft:black_concrete
fill 376 158 468 376 163 468 minecraft:sea_lantern
fill 376 158 476 376 163 476 minecraft:sea_lantern
fill 376 158 484 376 163 484 minecraft:sea_lantern
fill 376 158 492 376 163 492 minecraft:sea_lantern
fill 376 158 500 376 163 500 minecraft:sea_lantern
fill 379 158 505 379 163 505 minecraft:sea_lantern
fill 383 158 463 383 163 463 minecraft:sea_lantern
fill 387 158 505 387 163 505 minecraft:sea_lantern
fill 391 158 463 391 163 463 minecraft:sea_lantern
fill 395 158 505 395 163 505 minecraft:sea_lantern
fill 399 158 463 399 163 463 minecraft:sea_lantern
fill 403 158 505 403 163 505 minecraft:sea_lantern
fill 407 158 463 407 163 463 minecraft:sea_lantern
fill 411 158 505 411 163 505 minecraft:sea_lantern
fill 415 158 463 415 163 463 minecraft:sea_lantern
fill 418 158 468 418 163 468 minecraft:sea_lantern
fill 418 158 476 418 163 476 minecraft:sea_lantern
fill 418 158 484 418 163 484 minecraft:sea_lantern
fill 418 158 492 418 163 492 minecraft:sea_lantern
fill 418 158 500 418 163 500 minecraft:sea_lantern
fill 408 159 466 408 164 466 minecraft:magenta_concrete
setblock 379 160 466 minecraft:light[level=14]
setblock 379 160 474 minecraft:light[level=14]
setblock 379 160 482 minecraft:light[level=14]
setblock 379 160 490 minecraft:light[level=14]
setblock 379 160 498 minecraft:light[level=14]
setblock 387 160 466 minecraft:light[level=14]
setblock 387 160 474 minecraft:light[level=14]
setblock 387 160 482 minecraft:light[level=14]
setblock 387 160 490 minecraft:light[level=14]
setblock 387 160 498 minecraft:light[level=14]
setblock 395 160 466 minecraft:light[level=14]
setblock 395 160 474 minecraft:light[level=14]
setblock 395 160 482 minecraft:light[level=14]
setblock 395 160 490 minecraft:light[level=14]
setblock 395 160 498 minecraft:light[level=14]
setblock 403 160 466 minecraft:light[level=14]
setblock 403 160 474 minecraft:light[level=14]
setblock 403 160 482 minecraft:light[level=14]
setblock 403 160 490 minecraft:light[level=14]
setblock 403 160 498 minecraft:light[level=14]
setblock 411 160 466 minecraft:light[level=14]
setblock 411 160 474 minecraft:light[level=14]
setblock 411 160 482 minecraft:light[level=14]
setblock 411 160 490 minecraft:light[level=14]
setblock 411 160 498 minecraft:light[level=14]
fill 408 161 465 408 164 465 minecraft:magenta_concrete
fill 407 162 465 407 164 466 minecraft:magenta_concrete
fill 408 162 467 408 164 467 minecraft:magenta_concrete
fill 409 162 465 409 164 466 minecraft:magenta_concrete
fill 399 163 500 410 164 500 minecraft:black_concrete
fill 406 163 501 417 164 501 minecraft:black_concrete
fill 415 163 502 416 164 502 minecraft:black_concrete
fill 376 164 468 376 166 468 minecraft:magenta_concrete
fill 376 164 476 376 170 476 minecraft:magenta_concrete
fill 376 164 484 376 168 484 minecraft:magenta_concrete
fill 376 164 492 376 168 492 minecraft:magenta_concrete
fill 376 164 500 376 168 500 minecraft:magenta_concrete
fill 377 164 497 377 165 498 minecraft:black_concrete
fill 378 164 498 390 164 498 minecraft:black_concrete
fill 379 164 505 379 168 505 minecraft:magenta_concrete
fill 380 164 499 401 164 499 minecraft:black_concrete
fill 383 164 463 383 168 463 minecraft:magenta_concrete
fill 387 164 505 387 168 505 minecraft:magenta_concrete
fill 391 164 463 391 168 463 minecraft:magenta_concrete
fill 391 164 500 398 164 500 minecraft:black_concrete
fill 395 164 505 395 165 505 minecraft:magenta_concrete
fill 399 164 463 399 168 463 minecraft:magenta_concrete
fill 402 164 501 405 164 501 minecraft:black_concrete
fill 403 164 505 403 168 505 minecraft:magenta_concrete
fill 407 164 463 407 168 463 minecraft:magenta_concrete
setblock 407 164 467 minecraft:magenta_concrete
setblock 408 164 464 minecraft:magenta_concrete
setblock 409 164 467 minecraft:magenta_concrete
fill 411 164 500 412 164 500 minecraft:black_concrete
fill 411 164 505 411 168 505 minecraft:magenta_concrete
fill 415 164 463 415 168 463 minecraft:magenta_concrete
fill 418 164 468 418 168 468 minecraft:magenta_concrete
fill 418 164 476 418 169 476 minecraft:magenta_concrete
fill 418 164 484 418 165 484 minecraft:magenta_concrete
fill 418 164 492 418 169 492 minecraft:magenta_concrete
fill 418 164 500 418 168 500 minecraft:magenta_concrete
fill 376 165 463 376 168 464 minecraft:magenta_concrete
setblock 376 165 465 minecraft:black_concrete
fill 376 165 466 376 165 467 minecraft:magenta_concrete
fill 376 165 478 376 169 478 minecraft:magenta_concrete
setblock 376 165 479 minecraft:black_concrete
fill 376 165 480 376 166 482 minecraft:magenta_concrete
fill 376 165 485 376 165 488 minecraft:magenta_concrete
setblock 376 165 489 minecraft:black_concrete
fill 376 165 490 376 165 491 minecraft:magenta_concrete
fill 378 165 498 386 165 498 minecraft:black_concrete
setblock 380 165 463 minecraft:black_concrete
fill 382 165 499 394 165 499 minecraft:black_concrete
fill 384 165 463 385 165 463 minecraft:black_concrete
setblock 385 165 505 minecraft:black_concrete
fill 386 165 463 389 165 463 minecraft:magenta_concrete
setblock 386 165 505 minecraft:magenta_concrete
fill 392 165 505 393 168 505 minecraft:magenta_concrete
fill 394 165 463 395 168 463 minecraft:magenta_concrete
setblock 394 165 505 minecraft:black_concrete
setblock 396 165 463 minecraft:black_concrete
fill 396 165 505 397 168 505 minecraft:magenta_concrete
fill 397 165 463 397 170 463 minecraft:magenta_concrete
fill 398 165 500 407 165 500 minecraft:magenta_concrete
setblock 398 165 505 minecraft:black_concrete
fill 399 165 505 402 165 505 minecraft:magenta_concrete
fill 404 165 464 409 176 468 minecraft:black_concrete
fill 408 165 501 416 165 501 minecraft:magenta_concrete
fill 410 165 463 411 166 463 minecraft:magenta_concrete
fill 410 165 465 412 176 468 minecraft:black_concrete
fill 412 165 463 412 165 464 minecraft:black_concrete
fill 413 165 463 414 168 463 minecraft:magenta_concrete
setblock 414 165 505 minecraft:black_concrete
setblock 418 165 463 minecraft:black_concrete
fill 418 165 464 418 168 467 minecraft:magenta_concrete
fill 418 165 469 418 168 469 minecraft:magenta_concrete
setblock 418 165 470 minecraft:black_concrete
fill 418 165 471 418 168 471 minecraft:magenta_concrete
setblock 418 165 493 minecraft:magenta_concrete
setblock 418 165 494 minecraft:black_concrete
fill 418 165 495 418 168 495 minecraft:magenta_concrete
fill 418 165 501 418 165 503 minecraft:magenta_concrete
setblock 418 165 504 minecraft:black_concrete
fill 376 166 465 376 168 466 minecraft:magenta_concrete
setblock 376 166 467 minecraft:black_concrete
fill 376 166 469 376 169 469 minecraft:magenta_concrete
setblock 376 166 470 minecraft:black_concrete
fill 376 166 471 376 168 475 minecraft:magenta_concrete
fill 376 166 479 376 168 479 minecraft:magenta_concrete
fill 376 166 485 376 168 485 minecraft:magenta_concrete
fill 376 166 486 376 166 487 minecraft:black_concrete
fill 376 166 488 376 168 490 minecraft:magenta_concrete
setblock 376 166 491 minecraft:black_concrete
fill 376 166 501 376 168 501 minecraft:magenta_concrete
fill 376 166 502 376 167 502 minecraft:black_concrete
fill 376 166 503 376 168 504 minecraft:magenta_concrete
fill 377 166 498 384 166 498 minecraft:magenta_concrete
fill 380 166 463 380 168 463 minecraft:magenta_concrete
fill 384 166 463 384 168 463 minecraft:magenta_concrete
fill 385 166 463 385 167 463 minecraft:black_concrete
fill 385 166 505 385 168 505 minecraft:magenta_concrete
fill 386 166 463 387 168 463 minecraft:magenta_concrete
fill 386 166 499 392 166 499 minecraft:magenta_concrete
setblock 386 166 505 minecraft:black_concrete
setblock 388 166 463 minecraft:black_concrete
fill 389 166 463 389 168 463 minecraft:magenta_concrete
fill 394 166 505 394 168 505 minecraft:magenta_concrete
setblock 395 166 505 minecraft:black_concrete
fill 396 166 463 396 168 463 minecraft:magenta_concrete
fill 398 166 505 399 168 505 minecraft:magenta_concrete
setblock 400 166 463 minecraft:black_concrete
setblock 400 166 505 minecraft:black_concrete
fill 401 166 463 401 168 463 minecraft:magenta_concrete
fill 401 166 505 402 168 505 minecraft:magenta_concrete
setblock 402 166 463 minecraft:black_concrete
fill 403 166 463 403 168 463 minecraft:magenta_concrete
setblock 404 166 463 minecraft:black_concrete
fill 405 166 463 406 168 463 minecraft:magenta_concrete
fill 406 166 505 406 168 505 minecraft:magenta_concrete
setblock 407 166 505 minecraft:black_concrete
fill 408 166 505 410 166 505 minecraft:magenta_concrete
fill 412 166 463 412 168 463 minecraft:magenta_concrete
fill 412 166 464 412 176 464 minecraft:black_concrete
fill 412 166 505 413 166 505 minecraft:black_concrete
fill 414 166 505 414 168 505 minecraft:magenta_concrete
fill 418 166 463 418 169 463 minecraft:magenta_concrete
fill 418 166 470 418 168 470 minecraft:magenta_concrete
fill 418 166 473 418 169 473 minecraft:magenta_concrete
setblock 418 166 474 minecraft:black_concrete
fill 418 166 475 418 168 475 minecraft:magenta_concrete
fill 418 166 477 418 169 477 minecraft:magenta_concrete
setblock 418 166 478 minecraft:black_concrete
fill 418 166 479 418 168 483 minecraft:magenta_concrete
setblock 418 166 484 minecraft:black_concrete
setblock 418 166 493 minecraft:black_concrete
fill 418 166 494 418 168 494 minecraft:magenta_concrete
fill 418 166 501 418 168 501 minecraft:magenta_concrete
setblock 418 166 502 minecraft:black_concrete
fill 418 166 503 418 168 504 minecraft:magenta_concrete
fill 376 167 467 376 168 467 minecraft:magenta_concrete
setblock 376 167 468 minecraft:black_concrete
fill 376 167 470 376 168 470 minecraft:magenta_concrete
fill 376 167 480 376 168 480 minecraft:magenta_concrete
setblock 376 167 481 minecraft:black_concrete
fill 376 167 482 376 168 482 minecraft:magenta_concrete
fill 376 167 486 376 168 487 minecraft:magenta_concrete
fill 376 167 491 376 168 491 minecraft:magenta_concrete
setblock 376 167 505 minecraft:black_concrete
fill 386 167 505 386 168 505 minecraft:magenta_concrete
fill 388 167 463 388 168 463 minecraft:magenta_concrete
setblock 390 167 463 minecraft:black_concrete
setblock 393 167 463 minecraft:black_concrete
fill 395 167 505 395 168 505 minecraft:magenta_concrete
fill 400 167 463 400 168 463 minecraft:magenta_concrete
fill 400 167 505 400 168 505 minecraft:magenta_concrete
fill 402 167 463 402 168 463 minecraft:magenta_concrete
fill 404 167 463 404 168 463 minecraft:magenta_concrete
setblock 404 167 505 minecraft:black_concrete
fill 407 167 505 409 168 505 minecraft:magenta_concrete
setblock 410 167 463 minecraft:black_concrete
setblock 410 167 505 minecraft:black_concrete
fill 411 167 463 411 169 463 minecraft:magenta_concrete
fill 412 167 505 413 168 505 minecraft:magenta_concrete
fill 418 167 474 418 168 474 minecraft:magenta_concrete
fill 418 167 478 418 168 478 minecraft:magenta_concrete
fill 418 167 484 418 168 484 minecraft:magenta_concrete
fill 418 167 493 418 168 493 minecraft:magenta_concrete
fill 418 167 502 418 168 502 minecraft:magenta_concrete
setblock 418 167 505 minecraft:black_concrete
setblock 376 168 468 minecraft:magenta_concrete
setblock 376 168 481 minecraft:magenta_concrete
setblock 376 168 502 minecraft:magenta_concrete
setblock 376 168 505 minecraft:magenta_concrete
fill 377 168 464 377 169 469 minecraft:black_concrete
fill 377 168 472 378 168 477 minecraft:black_concrete
fill 377 168 480 378 168 485 minecraft:black_concrete
fill 377 168 488 378 168 493 minecraft:black_concrete
fill 377 168 496 378 168 501 minecraft:black_concrete
fill 377 168 504 382 169 504 minecraft:black_concrete
fill 378 168 465 378 168 471 minecraft:black_concrete
fill 378 168 478 378 168 479 minecraft:black_concrete
fill 378 168 486 378 168 487 minecraft:black_concrete
fill 378 168 494 378 168 495 minecraft:black_concrete
fill 378 168 502 378 168 503 minecraft:black_concrete
fill 379 168 465 403 168 465 minecraft:black_concrete
setblock 379 168 466 minecraft:light[level=14]
setblock 379 168 474 minecraft:light[level=14]
setblock 379 168 482 minecraft:light[level=14]
setblock 379 168 490 minecraft:light[level=14]
setblock 379 168 498 minecraft:light[level=14]
fill 379 168 503 417 168 503 minecraft:black_concrete
fill 380 168 464 385 169 464 minecraft:black_concrete
setblock 385 168 463 minecraft:magenta_concrete
fill 385 168 504 390 169 504 minecraft:black_concrete
setblock 387 168 466 minecraft:light[level=14]
setblock 387 168 474 minecraft:light[level=14]
setblock 387 168 482 minecraft:light[level=14]
setblock 387 168 490 minecraft:light[level=14]
setblock 387 168 498 minecraft:light[level=14]
fill 388 168 464 393 169 464 minecraft:black_concrete
setblock 390 168 463 minecraft:magenta_concrete
setblock 393 168 463 minecraft:magenta_concrete
fill 393 168 504 398 169 504 minecraft:black_concrete
setblock 395 168 466 minecraft:light[level=14]
setblock 395 168 474 minecraft:light[level=14]
setblock 395 168 482 minecraft:light[level=14]
setblock 395 168 490 minecraft:light[level=14]
setblock 395 168 498 minecraft:light[level=14]
fill 396 168 464 401 169 464 minecraft:black_concrete
fill 401 168 504 406 169 504 minecraft:black_concrete
setblock 403 168 466 minecraft:light[level=14]
setblock 403 168 474 minecraft:light[level=14]
setblock 403 168 482 minecraft:light[level=14]
setblock 403 168 490 minecraft:light[level=14]
setblock 403 168 498 minecraft:light[level=14]
setblock 404 168 505 minecraft:magenta_concrete
fill 409 168 504 414 169 504 minecraft:black_concrete
setblock 410 168 463 minecraft:magenta_concrete
setblock 410 168 505 minecraft:magenta_concrete
setblock 411 168 474 minecraft:light[level=14]
setblock 411 168 482 minecraft:light[level=14]
setblock 411 168 490 minecraft:light[level=14]
setblock 411 168 498 minecraft:light[level=14]
fill 413 168 464 416 168 465 minecraft:black_concrete
fill 416 168 466 416 168 502 minecraft:black_concrete
fill 417 168 464 417 169 464 minecraft:black_concrete
fill 417 168 467 417 169 472 minecraft:black_concrete
fill 417 168 475 417 169 480 minecraft:black_concrete
fill 417 168 483 417 169 488 minecraft:black_concrete
fill 417 168 491 417 169 496 minecraft:black_concrete
fill 417 168 499 417 169 502 minecraft:black_concrete
fill 417 168 504 417 169 504 minecraft:black_concrete
fill 418 168 505 418 170 505 minecraft:magenta_concrete
fill 376 169 463 376 169 468 minecraft:black_concrete
fill 376 169 470 376 236 472 minecraft:black_concrete
setblock 376 169 473 minecraft:magenta_concrete
fill 376 169 474 377 169 475 minecraft:black_concrete
fill 376 169 477 377 169 477 minecraft:black_concrete
fill 376 169 479 376 169 497 minecraft:black_concrete
fill 376 169 499 376 169 505 minecraft:black_concrete
fill 377 169 463 396 169 463 minecraft:black_concrete
fill 377 169 472 377 169 473 minecraft:black_concrete
setblock 377 169 476 minecraft:black_concrete
fill 377 169 480 377 169 485 minecraft:black_concrete
fill 377 169 488 377 169 493 minecraft:black_concrete
fill 377 169 496 377 169 501 minecraft:black_concrete
fill 379 169 505 415 169 505 minecraft:black_concrete
fill 398 169 463 404 170 463 minecraft:black_concrete
setblock 405 169 463 minecraft:magenta_concrete
fill 406 169 463 410 169 463 minecraft:black_concrete
fill 412 169 463 417 170 463 minecraft:black_concrete
fill 413 169 464 416 169 464 minecraft:black_concrete
fill 416 169 505 416 170 505 minecraft:magenta_concrete
fill 417 169 503 418 169 503 minecraft:black_concrete
fill 417 169 505 417 239 505 minecraft:black_concrete
setblock 418 169 464 minecraft:magenta_concrete
fill 418 169 465 418 170 472 minecraft:black_concrete
fill 418 169 474 418 238 475 minecraft:black_concrete
fill 418 169 478 418 238 480 minecraft:black_concrete
setblock 418 169 481 minecraft:magenta_concrete
fill 418 169 482 418 169 491 minecraft:black_concrete
fill 418 169 493 418 169 502 minecraft:black_concrete
fill 418 169 504 418 238 504 minecraft:black_concrete
setblock 376 170 463 minecraft:magenta_concrete
fill 376 170 464 376 234 467 minecraft:black_concrete
setblock 376 170 468 minecraft:magenta_concrete
fill 376 170 469 376 238 469 minecraft:black_concrete
fill 376 170 473 376 238 473 minecraft:black_concrete
setblock 376 170 474 minecraft:magenta_concrete
fill 376 170 475 376 238 475 minecraft:black_concrete
fill 376 170 477 376 235 480 minecraft:black_concrete
setblock 376 170 481 minecraft:magenta_concrete
fill 376 170 482 376 170 489 minecraft:black_concrete
fill 376 170 490 376 171 490 minecraft:magenta_concrete
fill 376 170 491 376 170 504 minecraft:black_concrete
setblock 376 170 505 minecraft:magenta_concrete
fill 377 170 463 378 238 463 minecraft:black_concrete
fill 377 170 505 380 171 505 minecraft:black_concrete
fill 379 170 463 380 170 463 minecraft:magenta_concrete
fill 381 170 463 382 170 463 minecraft:black_concrete
setblock 381 170 505 minecraft:magenta_concrete
fill 382 170 505 388 170 505 minecraft:black_concrete
setblock 383 170 463 minecraft:magenta_concrete
fill 384 170 463 390 170 463 minecraft:black_concrete
setblock 389 170 505 minecraft:magenta_concrete
fill 390 170 505 409 170 505 minecraft:black_concrete
setblock 391 170 463 minecraft:magenta_concrete
fill 392 170 463 396 234 463 minecraft:black_concrete
fill 405 170 463 409 171 463 minecraft:black_concrete
setblock 410 170 463 minecraft:magenta_concrete
setblock 410 170 505 minecraft:magenta_concrete
setblock 411 170 463 minecraft:black_concrete
fill 411 170 505 415 170 505 minecraft:black_concrete
fill 418 170 463 418 170 464 minecraft:black_concrete
fill 418 170 473 418 238 473 minecraft:black_concrete
fill 418 170 476 418 171 477 minecraft:black_concrete
fill 418 170 481 418 170 487 minecraft:black_concrete
setblock 418 170 488 minecraft:magenta_concrete
fill 418 170 489 418 170 496 minecraft:black_concrete
setblock 418 170 497 minecraft:magenta_concrete
fill 418 170 498 418 171 500 minecraft:black_concrete
fill 418 170 501 418 171 501 minecraft:magenta_concrete
fill 418 170 502 418 170 503 minecraft:black_concrete
fill 376 171 463 376 238 463 minecraft:black_concrete
setblock 376 171 468 minecraft:black_concrete
fill 376 171 474 376 240 474 minecraft:black_concrete
setblock 376 171 476 minecraft:black_concrete
fill 376 171 481 376 171 484 minecraft:black_concrete
setblock 376 171 485 minecraft:magenta_concrete
fill 376 171 486 376 234 489 minecraft:black_concrete
fill 376 171 491 376 171 492 minecraft:black_concrete
setblock 376 171 493 minecraft:magenta_concrete
fill 376 171 494 376 234 496 minecraft:black_concrete
setblock 376 171 497 minecraft:magenta_concrete
fill 376 171 498 376 171 505 minecraft:black_concrete
fill 379 171 463 380 234 463 minecraft:black_concrete
setblock 381 171 463 minecraft:magenta_concrete
fill 381 171 505 383 238 505 minecraft:black_concrete
fill 382 171 463 383 171 463 minecraft:black_concrete
setblock 384 171 463 minecraft:magenta_concrete
setblock 384 171 505 minecraft:magenta_concrete
fill 385 171 463 389 238 463 minecraft:black_concrete
fill 385 171 505 387 171 505 minecraft:black_concrete
setblock 388 171 505 minecraft:magenta_concrete
fill 389 171 505 391 235 505 minecraft:black_concrete
setblock 390 171 463 minecraft:magenta_concrete
setblock 391 171 463 minecraft:black_concrete
setblock 392 171 505 minecraft:magenta_concrete
fill 393 171 505 393 238 505 minecraft:black_concrete
setblock 394 171 505 minecraft:magenta_concrete
fill 395 171 505 399 171 505 minecraft:black_concrete
fill 397 171 463 398 235 463 minecraft:black_concrete
setblock 399 171 463 minecraft:magenta_concrete
fill 400 171 463 404 234 463 minecraft:black_concrete
setblock 400 171 505 minecraft:magenta_concrete
fill 401 171 505 401 235 505 minecraft:black_concrete
setblock 402 171 505 minecraft:magenta_concrete
fill 403 171 505 410 171 505 minecraft:black_concrete
fill 410 171 463 410 238 463 minecraft:black_concrete
setblock 411 171 463 minecraft:magenta_concrete
setblock 411 171 505 minecraft:magenta_concrete
fill 412 171 463 412 240 463 minecraft:black_concrete
fill 412 171 505 413 239 505 minecraft:black_concrete
setblock 413 171 463 minecraft:magenta_concrete
fill 414 171 463 414 238 463 minecraft:black_concrete
fill 414 171 505 415 171 505 minecraft:magenta_concrete
setblock 415 171 463 minecraft:magenta_concrete
fill 416 171 463 416 238 463 minecraft:black_concrete
fill 416 171 505 416 239 505 minecraft:black_concrete
setblock 417 171 463 minecraft:magenta_concrete
fill 418 171 463 418 236 463 minecraft:black_concrete
setblock 418 171 464 minecraft:magenta_concrete
fill 418 171 465 418 238 465 minecraft:black_concrete
setblock 418 171 466 minecraft:magenta_concrete
fill 418 171 467 418 171 472 minecraft:black_concrete
fill 418 171 481 418 171 485 minecraft:black_concrete
setblock 418 171 486 minecraft:magenta_concrete
fill 418 171 487 418 236 490 minecraft:black_concrete
setblock 418 171 491 minecraft:magenta_concrete
setblock 418 171 492 minecraft:black_concrete
setblock 418 171 493 minecraft:magenta_concrete
fill 418 171 494 418 234 497 minecraft:black_concrete
setblock 418 171 502 minecraft:magenta_concrete
fill 418 171 503 418 240 503 minecraft:black_concrete
fill 418 171 505 418 238 505 minecraft:black_concrete
fill 376 172 468 376 176 468 minecraft:sea_lantern
fill 376 172 476 376 176 476 minecraft:sea_lantern
fill 376 172 481 376 235 483 minecraft:black_concrete
fill 376 172 484 376 176 484 minecraft:sea_lantern
fill 376 172 485 376 235 485 minecraft:black_concrete
fill 376 172 490 376 238 491 minecraft:black_concrete
fill 376 172 492 376 176 492 minecraft:sea_lantern
fill 376 172 493 376 238 493 minecraft:black_concrete
fill 376 172 497 376 238 499 minecraft:black_concrete
fill 376 172 500 376 176 500 minecraft:sea_lantern
fill 376 172 501 376 234 505 minecraft:black_concrete
fill 377 172 505 378 236 505 minecraft:black_concrete
fill 379 172 505 379 176 505 minecraft:sea_lantern
fill 380 172 505 380 235 505 minecraft:black_concrete
fill 381 172 463 382 238 463 minecraft:black_concrete
fill 383 172 463 383 176 463 minecraft:sea_lantern
fill 384 172 463 384 238 463 minecraft:black_concrete
fill 384 172 505 386 238 505 minecraft:black_concrete
fill 387 172 505 387 176 505 minecraft:sea_lantern
fill 388 172 505 388 235 505 minecraft:black_concrete
fill 390 172 463 390 236 463 minecraft:black_concrete
fill 391 172 463 391 176 463 minecraft:sea_lantern
fill 392 172 505 392 241 505 minecraft:black_concrete
fill 394 172 505 394 238 505 minecraft:black_concrete
fill 395 172 505 395 176 505 minecraft:sea_lantern
fill 396 172 505 400 235 505 minecraft:black_concrete
fill 399 172 463 399 176 463 minecraft:sea_lantern
fill 402 172 505 402 239 505 minecraft:black_concrete
fill 403 172 505 403 176 505 minecraft:sea_lantern
fill 404 172 505 410 236 505 minecraft:black_concrete
fill 405 172 463 406 236 463 minecraft:black_concrete
fill 407 172 463 407 176 463 minecraft:sea_lantern
fill 408 172 463 409 234 463 minecraft:black_concrete
fill 411 172 463 411 238 463 minecraft:black_concrete
fill 411 172 505 411 176 505 minecraft:sea_lantern
fill 413 172 463 413 235 463 minecraft:black_concrete
fill 414 172 505 415 236 505 minecraft:black_concrete
fill 415 172 463 415 176 463 minecraft:sea_lantern
fill 417 172 463 417 238 463 minecraft:black_concrete
fill 418 172 464 418 236 464 minecraft:black_concrete
fill 418 172 466 418 234 467 minecraft:black_concrete
fill 418 172 468 418 176 468 minecraft:sea_lantern
fill 418 172 469 418 236 472 minecraft:black_concrete
fill 418 172 476 418 176 476 minecraft:sea_lantern
fill 418 172 477 418 238 477 minecraft:black_concrete
fill 418 172 481 418 234 483 minecraft:black_concrete
fill 418 172 484 418 176 484 minecraft:sea_lantern
fill 418 172 485 418 238 486 minecraft:black_concrete
fill 418 172 491 418 238 491 minecraft:black_concrete
fill 418 172 492 418 176 492 minecraft:sea_lantern
fill 418 172 493 418 238 493 minecraft:black_concrete
fill 418 172 498 418 236 499 minecraft:black_concrete
fill 418 172 500 418 176 500 minecraft:sea_lantern
fill 418 172 501 418 238 502 minecraft:black_concrete
setblock 379 176 466 minecraft:light[level=14]
setblock 379 176 474 minecraft:light[level=14]
setblock 379 176 482 minecraft:light[level=14]
setblock 379 176 490 minecraft:light[level=14]
setblock 379 176 498 minecraft:light[level=14]
setblock 387 176 466 minecraft:light[level=14]
setblock 387 176 474 minecraft:light[level=14]
setblock 387 176 482 minecraft:light[level=14]
setblock 387 176 490 minecraft:light[level=14]
setblock 387 176 498 minecraft:light[level=14]
fill 391 176 477 393 176 479 minecraft:black_concrete
setblock 395 176 466 minecraft:light[level=14]
setblock 395 176 474 minecraft:light[level=14]
setblock 395 176 482 minecraft:light[level=14]
setblock 395 176 490 minecraft:light[level=14]
setblock 395 176 498 minecraft:light[level=14]
setblock 403 176 466 minecraft:light[level=14]
setblock 403 176 474 minecraft:light[level=14]
setblock 403 176 482 minecraft:light[level=14]
setblock 403 176 490 minecraft:light[level=14]
setblock 403 176 498 minecraft:light[level=14]
setblock 411 176 474 minecraft:light[level=14]
setblock 411 176 482 minecraft:light[level=14]
setblock 411 176 490 minecraft:light[level=14]
setblock 411 176 498 minecraft:light[level=14]
fill 376 177 468 376 186 468 minecraft:black_concrete
fill 376 177 476 376 186 476 minecraft:black_concrete
fill 376 177 484 376 186 484 minecraft:black_concrete
fill 376 177 492 376 186 492 minecraft:black_concrete
fill 376 177 500 376 186 500 minecraft:black_concrete
fill 379 177 505 379 186 505 minecraft:black_concrete
fill 383 177 463 383 186 463 minecraft:black_concrete
fill 387 177 505 387 186 505 minecraft:black_concrete
fill 391 177 463 391 186 463 minecraft:black_concrete
fill 395 177 505 395 186 505 minecraft:black_concrete
fill 399 177 463 399 186 463 minecraft:black_concrete
fill 403 177 505 403 186 505 minecraft:black_concrete
fill 407 177 463 407 186 463 minecraft:black_concrete
fill 411 177 505 411 186 505 minecraft:black_concrete
fill 415 177 463 415 186 463 minecraft:black_concrete
fill 418 177 468 418 186 468 minecraft:black_concrete
fill 418 177 476 418 186 476 minecraft:black_concrete
fill 418 177 484 418 186 484 minecraft:black_concrete
fill 418 177 492 418 186 492 minecraft:black_concrete
fill 418 177 500 418 186 500 minecraft:black_concrete
fill 394 181 483 396 181 485 minecraft:redstone_block
fill 395 181 490 397 181 492 minecraft:redstone_block
fill 401 181 482 403 181 484 minecraft:redstone_block
fill 401 181 490 403 181 492 minecraft:redstone_block
fill 377 182 464 378 182 464 minecraft:white_concrete
fill 377 182 465 378 182 466 minecraft:black_concrete
fill 377 182 467 378 182 468 minecraft:white_concrete
fill 377 182 469 378 182 470 minecraft:black_concrete
fill 377 182 471 378 182 472 minecraft:white_concrete
fill 377 182 473 378 182 474 minecraft:black_concrete
fill 377 182 475 378 182 476 minecraft:white_concrete
fill 377 182 477 378 182 478 minecraft:black_concrete
fill 377 182 479 378 182 480 minecraft:white_concrete
fill 377 182 481 378 182 482 minecraft:black_concrete
fill 377 182 483 378 182 484 minecraft:white_concrete
fill 377 182 485 378 182 486 minecraft:black_concrete
fill 377 182 487 378 182 488 minecraft:white_concrete
fill 377 182 489 378 182 490 minecraft:black_concrete
fill 377 182 491 378 182 492 minecraft:white_concrete
fill 377 182 493 378 182 494 minecraft:black_concrete
fill 377 182 495 378 182 496 minecraft:white_concrete
fill 377 182 497 378 182 498 minecraft:black_concrete
fill 377 182 499 378 182 500 minecraft:white_concrete
fill 377 182 501 378 182 502 minecraft:black_concrete
fill 377 182 503 378 182 504 minecraft:white_concrete
fill 379 182 464 380 182 464 minecraft:black_concrete
fill 379 182 465 380 182 466 minecraft:white_concrete
fill 379 182 467 380 182 468 minecraft:black_concrete
fill 379 182 469 380 182 470 minecraft:white_concrete
fill 379 182 471 380 182 472 minecraft:black_concrete
fill 379 182 473 380 182 474 minecraft:white_concrete
fill 379 182 475 380 182 476 minecraft:black_concrete
fill 379 182 477 380 182 478 minecraft:white_concrete
fill 379 182 479 380 182 480 minecraft:black_concrete
fill 379 182 481 380 182 482 minecraft:white_concrete
fill 379 182 483 380 182 484 minecraft:black_concrete
fill 379 182 485 380 182 486 minecraft:white_concrete
fill 379 182 487 380 182 488 minecraft:black_concrete
fill 379 182 489 380 182 490 minecraft:white_concrete
fill 379 182 491 380 182 492 minecraft:black_concrete
fill 379 182 493 380 182 494 minecraft:white_concrete
fill 379 182 495 380 182 496 minecraft:black_concrete
fill 379 182 497 380 182 498 minecraft:white_concrete
fill 379 182 499 380 182 500 minecraft:black_concrete
fill 379 182 501 380 182 502 minecraft:white_concrete
fill 379 182 503 380 182 504 minecraft:black_concrete
fill 381 182 464 382 182 464 minecraft:white_concrete
fill 381 182 465 382 182 466 minecraft:black_concrete
fill 381 182 467 382 182 468 minecraft:white_concrete
fill 381 182 469 382 182 470 minecraft:black_concrete
fill 381 182 471 382 182 472 minecraft:white_concrete
fill 381 182 473 382 182 474 minecraft:black_concrete
fill 381 182 475 382 182 476 minecraft:white_concrete
fill 381 182 477 382 182 478 minecraft:black_concrete
fill 381 182 479 382 182 480 minecraft:white_concrete
fill 381 182 481 382 182 482 minecraft:black_concrete
fill 381 182 483 382 182 484 minecraft:white_concrete
fill 381 182 485 382 182 486 minecraft:black_concrete
fill 381 182 487 382 182 488 minecraft:white_concrete
fill 381 182 489 382 182 490 minecraft:black_concrete
fill 381 182 491 382 182 492 minecraft:white_concrete
fill 381 182 493 382 182 494 minecraft:black_concrete
fill 381 182 495 382 182 496 minecraft:white_concrete
fill 381 182 497 382 182 498 minecraft:black_concrete
fill 381 182 499 382 182 500 minecraft:white_concrete
fill 381 182 501 382 182 502 minecraft:black_concrete
fill 381 182 503 382 182 504 minecraft:white_concrete
fill 383 182 464 384 182 464 minecraft:black_concrete
fill 383 182 465 384 182 466 minecraft:white_concrete
fill 383 182 467 384 182 468 minecraft:black_concrete
fill 383 182 469 384 182 470 minecraft:white_concrete
fill 383 182 471 384 182 472 minecraft:black_concrete
fill 383 182 473 384 182 474 minecraft:white_concrete
fill 383 182 475 384 182 476 minecraft:black_concrete
fill 383 182 477 384 182 478 minecraft:white_concrete
fill 383 182 479 384 182 480 minecraft:black_concrete
fill 383 182 481 384 182 482 minecraft:white_concrete
fill 383 182 483 384 182 484 minecraft:black_concrete
fill 383 182 485 384 182 486 minecraft:white_concrete
fill 383 182 487 384 182 488 minecraft:black_concrete
fill 383 182 489 384 182 490 minecraft:white_concrete
fill 383 182 491 384 182 492 minecraft:black_concrete
fill 383 182 493 384 182 494 minecraft:white_concrete
fill 383 182 495 384 182 496 minecraft:black_concrete
fill 383 182 497 384 182 498 minecraft:white_concrete
fill 383 182 499 384 182 500 minecraft:black_concrete
fill 383 182 501 384 182 502 minecraft:white_concrete
fill 383 182 503 384 182 504 minecraft:black_concrete
fill 385 182 464 386 182 464 minecraft:white_concrete
fill 385 182 465 386 182 466 minecraft:black_concrete
fill 385 182 467 386 182 468 minecraft:white_concrete
fill 385 182 469 386 182 470 minecraft:black_concrete
fill 385 182 471 386 182 472 minecraft:white_concrete
fill 385 182 473 386 182 474 minecraft:black_concrete
fill 385 182 475 386 182 476 minecraft:white_concrete
fill 385 182 477 386 182 478 minecraft:black_concrete
fill 385 182 479 386 182 480 minecraft:white_concrete
fill 385 182 481 386 182 482 minecraft:black_concrete
fill 385 182 483 386 182 484 minecraft:white_concrete
fill 385 182 485 386 182 486 minecraft:black_concrete
fill 385 182 487 386 182 488 minecraft:white_concrete
fill 385 182 489 386 182 490 minecraft:black_concrete
fill 385 182 491 386 182 492 minecraft:white_concrete
fill 385 182 493 386 182 494 minecraft:black_concrete
fill 385 182 495 386 182 496 minecraft:white_concrete
fill 385 182 497 386 182 498 minecraft:black_concrete
fill 385 182 499 386 182 500 minecraft:white_concrete
fill 385 182 501 386 182 502 minecraft:black_concrete
fill 385 182 503 386 182 504 minecraft:white_concrete
fill 387 182 464 388 182 464 minecraft:black_concrete
fill 387 182 465 388 182 466 minecraft:white_concrete
fill 387 182 467 388 182 468 minecraft:black_concrete
fill 387 182 469 388 182 470 minecraft:white_concrete
fill 387 182 471 388 182 472 minecraft:black_concrete
fill 387 182 473 388 182 474 minecraft:white_concrete
fill 387 182 475 388 182 476 minecraft:black_concrete
fill 387 182 477 388 182 478 minecraft:white_concrete
fill 387 182 479 388 182 480 minecraft:black_concrete
fill 387 182 481 388 182 482 minecraft:white_concrete
fill 387 182 483 388 182 484 minecraft:black_concrete
fill 387 182 485 388 182 486 minecraft:white_concrete
fill 387 182 487 388 182 488 minecraft:black_concrete
fill 387 182 489 388 182 490 minecraft:white_concrete
fill 387 182 491 388 182 492 minecraft:black_concrete
fill 387 182 493 388 182 494 minecraft:white_concrete
fill 387 182 495 388 182 496 minecraft:black_concrete
fill 387 182 497 388 182 498 minecraft:white_concrete
fill 387 182 499 388 182 500 minecraft:black_concrete
fill 387 182 501 388 182 502 minecraft:white_concrete
fill 387 182 503 388 182 504 minecraft:black_concrete
fill 389 182 464 390 182 464 minecraft:white_concrete
fill 389 182 465 390 182 466 minecraft:black_concrete
fill 389 182 467 390 182 468 minecraft:white_concrete
fill 389 182 469 390 182 470 minecraft:black_concrete
fill 389 182 471 390 182 472 minecraft:white_concrete
fill 389 182 473 390 182 474 minecraft:black_concrete
fill 389 182 475 390 182 476 minecraft:white_concrete
fill 389 182 477 390 182 478 minecraft:black_concrete
fill 389 182 479 390 182 480 minecraft:white_concrete
fill 389 182 481 390 182 482 minecraft:black_concrete
fill 389 182 483 390 182 484 minecraft:white_concrete
fill 389 182 485 390 182 486 minecraft:black_concrete
fill 389 182 487 390 182 488 minecraft:white_concrete
fill 389 182 489 390 182 490 minecraft:black_concrete
fill 389 182 491 390 182 492 minecraft:white_concrete
fill 389 182 493 390 182 494 minecraft:black_concrete
fill 389 182 495 390 182 496 minecraft:white_concrete
fill 389 182 497 390 182 498 minecraft:black_concrete
fill 389 182 499 390 182 500 minecraft:white_concrete
fill 389 182 501 390 182 502 minecraft:black_concrete
fill 389 182 503 390 182 504 minecraft:white_concrete
fill 391 182 464 392 182 464 minecraft:black_concrete
fill 391 182 465 392 182 466 minecraft:white_concrete
fill 391 182 467 392 182 468 minecraft:black_concrete
fill 391 182 469 392 182 470 minecraft:white_concrete
fill 391 182 471 392 182 472 minecraft:black_concrete
fill 391 182 473 392 182 474 minecraft:white_concrete
fill 391 182 475 392 182 476 minecraft:black_concrete
fill 391 182 477 392 182 478 minecraft:white_concrete
fill 391 182 479 392 182 480 minecraft:black_concrete
fill 391 182 481 392 182 482 minecraft:white_concrete
fill 391 182 483 392 182 484 minecraft:black_concrete
fill 391 182 485 392 182 486 minecraft:white_concrete
fill 391 182 487 392 182 488 minecraft:black_concrete
fill 391 182 489 392 182 490 minecraft:white_concrete
fill 391 182 491 392 182 492 minecraft:black_concrete
fill 391 182 493 392 182 494 minecraft:white_concrete
fill 391 182 495 392 182 496 minecraft:black_concrete
fill 391 182 497 392 182 498 minecraft:white_concrete
fill 391 182 499 392 182 500 minecraft:black_concrete
fill 391 182 501 392 182 502 minecraft:white_concrete
fill 391 182 503 392 182 504 minecraft:black_concrete
fill 393 182 464 394 182 464 minecraft:white_concrete
fill 393 182 465 394 182 466 minecraft:black_concrete
fill 393 182 467 394 182 468 minecraft:white_concrete
fill 393 182 469 394 182 470 minecraft:black_concrete
fill 393 182 471 394 182 472 minecraft:white_concrete
fill 393 182 473 394 182 474 minecraft:black_concrete
fill 393 182 475 394 182 476 minecraft:white_concrete
fill 393 182 477 394 182 478 minecraft:black_concrete
fill 393 182 479 394 182 480 minecraft:white_concrete
fill 393 182 481 394 182 482 minecraft:black_concrete
fill 393 182 483 393 182 484 minecraft:white_concrete
fill 393 182 485 393 182 486 minecraft:black_concrete
fill 393 182 487 394 182 488 minecraft:white_concrete
fill 393 182 489 394 182 490 minecraft:black_concrete
fill 393 182 491 394 182 492 minecraft:white_concrete
fill 393 182 493 394 182 494 minecraft:black_concrete
fill 393 182 495 394 182 496 minecraft:white_concrete
fill 393 182 497 394 182 498 minecraft:black_concrete
fill 393 182 499 394 182 500 minecraft:white_concrete
fill 393 182 501 394 182 502 minecraft:black_concrete
fill 393 182 503 394 182 504 minecraft:white_concrete
setblock 394 182 486 minecraft:black_concrete
fill 395 182 464 396 182 464 minecraft:black_concrete
fill 395 182 465 396 182 466 minecraft:white_concrete
fill 395 182 467 396 182 468 minecraft:black_concrete
fill 395 182 469 396 182 470 minecraft:white_concrete
fill 395 182 471 396 182 472 minecraft:black_concrete
fill 395 182 473 396 182 474 minecraft:white_concrete
fill 395 182 475 396 182 476 minecraft:black_concrete
fill 395 182 477 396 182 478 minecraft:white_concrete
fill 395 182 479 396 182 480 minecraft:black_concrete
fill 395 182 481 396 182 482 minecraft:white_concrete
fill 395 182 486 396 182 486 minecraft:white_concrete
fill 395 182 487 396 182 488 minecraft:black_concrete
fill 395 182 489 396 182 489 minecraft:white_concrete
fill 395 182 493 396 182 494 minecraft:white_concrete
fill 395 182 495 396 182 496 minecraft:black_concrete
fill 395 182 497 396 182 498 minecraft:white_concrete
fill 395 182 499 396 182 500 minecraft:black_concrete
fill 395 182 501 396 182 502 minecraft:white_concrete
fill 395 182 503 396 182 504 minecraft:black_concrete
fill 397 182 464 398 182 464 minecraft:white_concrete
fill 397 182 465 398 182 466 minecraft:black_concrete
fill 397 182 467 398 182 468 minecraft:white_concrete
fill 397 182 469 398 182 470 minecraft:black_concrete
fill 397 182 471 398 182 472 minecraft:white_concrete
fill 397 182 473 398 182 474 minecraft:black_concrete
fill 397 182 475 398 182 476 minecraft:white_concrete
fill 397 182 477 398 182 478 minecraft:black_concrete
fill 397 182 479 398 182 480 minecraft:white_concrete
fill 397 182 481 398 182 482 minecraft:black_concrete
fill 397 182 483 398 182 484 minecraft:white_concrete
fill 397 182 485 397 182 486 minecraft:black_concrete
fill 397 182 487 397 182 488 minecraft:white_concrete
fill 397 182 489 398 182 489 minecraft:black_concrete
fill 397 182 493 398 182 494 minecraft:black_concrete
fill 397 182 495 398 182 496 minecraft:white_concrete
fill 397 182 497 398 182 498 minecraft:black_concrete
fill 397 182 499 398 182 500 minecraft:white_concrete
fill 397 182 501 398 182 502 minecraft:black_concrete
fill 397 182 503 398 182 504 minecraft:white_concrete
setblock 398 182 485 minecraft:black_concrete
setblock 398 182 490 minecraft:black_concrete
fill 398 182 491 398 182 492 minecraft:white_concrete
fill 399 182 464 400 182 464 minecraft:black_concrete
fill 399 182 465 400 182 466 minecraft:white_concrete
fill 399 182 467 400 182 468 minecraft:black_concrete
fill 399 182 469 400 182 470 minecraft:white_concrete
fill 399 182 471 400 182 472 minecraft:black_concrete
fill 399 182 473 400 182 474 minecraft:white_concrete
fill 399 182 475 400 182 476 minecraft:black_concrete
fill 399 182 477 400 182 478 minecraft:white_concrete
fill 399 182 479 400 182 480 minecraft:black_concrete
fill 399 182 481 400 182 482 minecraft:white_concrete
fill 399 182 483 400 182 484 minecraft:black_concrete
fill 399 182 485 400 182 485 minecraft:white_concrete
fill 399 182 489 400 182 490 minecraft:white_concrete
fill 399 182 491 400 182 492 minecraft:black_concrete
fill 399 182 493 400 182 494 minecraft:white_concrete
fill 399 182 495 400 182 496 minecraft:black_concrete
fill 399 182 497 400 182 498 minecraft:white_concrete
fill 399 182 499 400 182 500 minecraft:black_concrete
fill 399 182 501 400 182 502 minecraft:white_concrete
fill 399 182 503 400 182 504 minecraft:black_concrete
fill 401 182 464 402 182 464 minecraft:white_concrete
fill 401 182 465 402 182 466 minecraft:black_concrete
fill 401 182 467 402 182 468 minecraft:white_concrete
fill 401 182 469 402 182 470 minecraft:black_concrete
fill 401 182 471 402 182 472 minecraft:white_concrete
fill 401 182 473 402 182 474 minecraft:black_concrete
fill 401 182 475 402 182 476 minecraft:white_concrete
fill 401 182 477 402 182 478 minecraft:black_concrete
fill 401 182 479 402 182 480 minecraft:white_concrete
fill 401 182 481 402 182 481 minecraft:black_concrete
fill 401 182 485 402 182 486 minecraft:black_concrete
fill 401 182 487 402 182 488 minecraft:white_concrete
fill 401 182 489 402 182 489 minecraft:black_concrete
fill 401 182 493 402 182 494 minecraft:black_concrete
fill 401 182 495 402 182 496 minecraft:white_concrete
fill 401 182 497 402 182 498 minecraft:black_concrete
fill 401 182 499 402 182 500 minecraft:white_concrete
fill 401 182 501 402 182 502 minecraft:black_concrete
fill 401 182 503 402 182 504 minecraft:white_concrete
fill 403 182 464 404 182 464 minecraft:black_concrete
fill 403 182 465 404 182 466 minecraft:white_concrete
fill 403 182 467 404 182 468 minecraft:black_concrete
fill 403 182 469 404 182 470 minecraft:white_concrete
fill 403 182 471 404 182 472 minecraft:black_concrete
fill 403 182 473 404 182 474 minecraft:white_concrete
fill 403 182 475 404 182 476 minecraft:black_concrete
fill 403 182 477 404 182 478 minecraft:white_concrete
fill 403 182 479 404 182 480 minecraft:black_concrete
fill 403 182 481 404 182 481 minecraft:white_concrete
fill 403 182 485 404 182 486 minecraft:white_concrete
fill 403 182 487 404 182 488 minecraft:black_concrete
fill 403 182 489 404 182 489 minecraft:white_concrete
fill 403 182 493 404 182 494 minecraft:white_concrete
fill 403 182 495 404 182 496 minecraft:black_concrete
fill 403 182 497 404 182 498 minecraft:white_concrete
fill 403 182 499 404 182 500 minecraft:black_concrete
fill 403 182 501 404 182 502 minecraft:white_concrete
fill 403 182 503 404 182 504 minecraft:black_concrete
setblock 404 182 482 minecraft:white_concrete
fill 404 182 483 404 182 484 minecraft:black_concrete
setblock 404 182 490 minecraft:white_concrete
fill 404 182 491 404 182 492 minecraft:black_concrete
fill 405 182 464 406 182 464 minecraft:white_concrete
fill 405 182 465 406 182 466 minecraft:black_concrete
fill 405 182 467 406 182 468 minecraft:white_concrete
fill 405 182 469 406 182 470 minecraft:black_concrete
fill 405 182 471 406 182 472 minecraft:white_concrete
fill 405 182 473 406 182 474 minecraft:black_concrete
fill 405 182 475 406 182 476 minecraft:white_concrete
fill 405 182 477 406 182 478 minecraft:black_concrete
fill 405 182 479 406 182 480 minecraft:white_concrete
fill 405 182 481 406 182 482 minecraft:black_concrete
fill 405 182 483 406 182 484 minecraft:white_concrete
fill 405 182 485 406 182 486 minecraft:black_concrete
fill 405 182 487 406 182 488 minecraft:white_concrete
fill 405 182 489 406 182 490 minecraft:black_concrete
fill 405 182 491 406 182 492 minecraft:white_concrete
fill 405 182 493 406 182 494 minecraft:black_concrete
fill 405 182 495 406 182 496 minecraft:white_concrete
fill 405 182 497 406 182 498 minecraft:black_concrete
fill 405 182 499 406 182 500 minecraft:white_concrete
fill 405 182 501 406 182 502 minecraft:black_concrete
fill 405 182 503 406 182 504 minecraft:white_concrete
fill 407 182 464 408 182 464 minecraft:black_concrete
fill 407 182 465 408 182 466 minecraft:white_concrete
fill 407 182 467 408 182 468 minecraft:black_concrete
fill 407 182 469 408 182 470 minecraft:white_concrete
fill 407 182 471 408 182 472 minecraft:black_concrete
fill 407 182 473 408 182 474 minecraft:white_concrete
fill 407 182 475 408 182 476 minecraft:black_concrete
fill 407 182 477 408 182 478 minecraft:white_concrete
fill 407 182 479 408 182 480 minecraft:black_concrete
fill 407 182 481 408 182 482 minecraft:white_concrete
fill 407 182 483 408 182 484 minecraft:black_concrete
fill 407 182 485 408 182 486 minecraft:white_concrete
fill 407 182 487 408 182 488 minecraft:black_concrete
fill 407 182 489 408 182 490 minecraft:white_concrete
fill 407 182 491 408 182 492 minecraft:black_concrete
fill 407 182 493 408 182 494 minecraft:white_concrete
fill 407 182 495 408 182 496 minecraft:black_concrete
fill 407 182 497 408 182 498 minecraft:white_concrete
fill 407 182 499 408 182 500 minecraft:black_concrete
fill 407 182 501 408 182 502 minecraft:white_concrete
fill 407 182 503 408 182 504 minecraft:black_concrete
fill 409 182 464 410 182 464 minecraft:white_concrete
fill 409 182 465 410 182 466 minecraft:black_concrete
fill 409 182 467 410 182 468 minecraft:white_concrete
fill 409 182 469 410 182 470 minecraft:black_concrete
fill 409 182 471 410 182 472 minecraft:white_concrete
fill 409 182 473 410 182 474 minecraft:black_concrete
fill 409 182 475 410 182 476 minecraft:white_concrete
fill 409 182 477 410 182 478 minecraft:black_concrete
fill 409 182 479 410 182 480 minecraft:white_concrete
fill 409 182 481 410 182 482 minecraft:black_concrete
fill 409 182 483 410 182 484 minecraft:white_concrete
fill 409 182 485 410 182 486 minecraft:black_concrete
fill 409 182 487 410 182 488 minecraft:white_concrete
fill 409 182 489 410 182 490 minecraft:black_concrete
fill 409 182 491 410 182 492 minecraft:white_concrete
fill 409 182 493 410 182 494 minecraft:black_concrete
fill 409 182 495 410 182 496 minecraft:white_concrete
fill 409 182 497 410 182 498 minecraft:black_concrete
fill 409 182 499 410 182 500 minecraft:white_concrete
fill 409 182 501 410 182 502 minecraft:black_concrete
fill 409 182 503 410 182 504 minecraft:white_concrete
fill 411 182 464 412 182 464 minecraft:black_concrete
fill 411 182 465 412 182 466 minecraft:white_concrete
fill 411 182 467 412 182 468 minecraft:black_concrete
fill 411 182 469 412 182 470 minecraft:white_concrete
fill 411 182 471 412 182 472 minecraft:black_concrete
fill 411 182 473 412 182 474 minecraft:white_concrete
fill 411 182 475 412 182 476 minecraft:black_concrete
fill 411 182 477 412 182 478 minecraft:white_concrete
fill 411 182 479 412 182 480 minecraft:black_concrete
fill 411 182 481 412 182 482 minecraft:white_concrete
fill 411 182 483 412 182 484 minecraft:black_concrete
fill 411 182 485 412 182 486 minecraft:white_concrete
fill 411 182 487 412 182 488 minecraft:black_concrete
fill 411 182 489 412 182 490 minecraft:white_concrete
fill 411 182 491 412 182 492 minecraft:black_concrete
fill 411 182 493 412 182 494 minecraft:white_concrete
fill 411 182 495 412 182 496 minecraft:black_concrete
fill 411 182 497 412 182 498 minecraft:white_concrete
fill 411 182 499 412 182 500 minecraft:black_concrete
fill 411 182 501 412 182 502 minecraft:white_concrete
fill 411 182 503 412 182 504 minecraft:black_concrete
fill 413 182 464 414 182 464 minecraft:white_concrete
fill 413 182 465 414 182 466 minecraft:black_concrete
fill 413 182 467 414 182 468 minecraft:white_concrete
fill 413 182 469 414 182 470 minecraft:black_concrete
fill 413 182 471 414 182 472 minecraft:white_concrete
fill 413 182 473 414 182 474 minecraft:black_concrete
fill 413 182 475 414 182 476 minecraft:white_concrete
fill 413 182 477 414 182 478 minecraft:black_concrete
fill 413 182 479 414 182 480 minecraft:white_concrete
fill 413 182 481 414 182 482 minecraft:black_concrete
fill 413 182 483 414 182 484 minecraft:white_concrete
fill 413 182 485 414 182 486 minecraft:black_concrete
fill 413 182 487 414 182 488 minecraft:white_concrete
fill 413 182 489 414 182 490 minecraft:black_concrete
fill 413 182 491 414 182 492 minecraft:white_concrete
fill 413 182 493 414 182 494 minecraft:black_concrete
fill 413 182 495 414 182 496 minecraft:white_concrete
fill 413 182 497 414 182 498 minecraft:black_concrete
fill 413 182 499 414 182 500 minecraft:white_concrete
fill 413 182 501 414 182 502 minecraft:black_concrete
fill 413 182 503 414 182 504 minecraft:white_concrete
fill 415 182 464 416 182 464 minecraft:black_concrete
fill 415 182 465 416 182 466 minecraft:white_concrete
fill 415 182 467 416 182 468 minecraft:black_concrete
fill 415 182 469 416 182 470 minecraft:white_concrete
fill 415 182 471 416 182 472 minecraft:black_concrete
fill 415 182 473 416 182 474 minecraft:white_concrete
fill 415 182 475 416 182 476 minecraft:black_concrete
fill 415 182 477 416 182 478 minecraft:white_concrete
fill 415 182 479 416 182 480 minecraft:black_concrete
fill 415 182 481 416 182 482 minecraft:white_concrete
fill 415 182 483 416 182 484 minecraft:black_concrete
fill 415 182 485 416 182 486 minecraft:white_concrete
fill 415 182 487 416 182 488 minecraft:black_concrete
fill 415 182 489 416 182 490 minecraft:white_concrete
fill 415 182 491 416 182 492 minecraft:black_concrete
fill 415 182 493 416 182 494 minecraft:white_concrete
fill 415 182 495 416 182 496 minecraft:black_concrete
fill 415 182 497 416 182 498 minecraft:white_concrete
fill 415 182 499 416 182 500 minecraft:black_concrete
fill 415 182 501 416 182 502 minecraft:white_concrete
fill 415 182 503 416 182 504 minecraft:black_concrete
setblock 417 182 464 minecraft:white_concrete
fill 417 182 465 417 182 466 minecraft:black_concrete
fill 417 182 467 417 182 468 minecraft:white_concrete
fill 417 182 469 417 182 470 minecraft:black_concrete
fill 417 182 471 417 182 472 minecraft:white_concrete
fill 417 182 473 417 182 474 minecraft:black_concrete
fill 417 182 475 417 182 476 minecraft:white_concrete
fill 417 182 477 417 182 478 minecraft:black_concrete
fill 417 182 479 417 182 480 minecraft:white_concrete
fill 417 182 481 417 182 482 minecraft:black_concrete
fill 417 182 483 417 182 484 minecraft:white_concrete
fill 417 182 485 417 182 486 minecraft:black_concrete
fill 417 182 487 417 182 488 minecraft:white_concrete
fill 417 182 489 417 182 490 minecraft:black_concrete
fill 417 182 491 417 182 492 minecraft:white_concrete
fill 417 182 493 417 182 494 minecraft:black_concrete
fill 417 182 495 417 182 496 minecraft:white_concrete
fill 417 182 497 417 182 498 minecraft:black_concrete
fill 417 182 499 417 182 500 minecraft:white_concrete
fill 417 182 501 417 182 502 minecraft:black_concrete
fill 417 182 503 417 182 504 minecraft:white_concrete
fill 377 183 464 377 183 504 minecraft:magenta_concrete
setblock 378 183 464 minecraft:white_concrete
fill 378 183 465 417 183 465 minecraft:magenta_concrete
setblock 378 183 466 minecraft:black_concrete
fill 378 183 467 417 183 467 minecraft:magenta_concrete
setblock 378 183 468 minecraft:white_concrete
fill 378 183 469 417 183 469 minecraft:magenta_concrete
setblock 378 183 470 minecraft:black_concrete
fill 378 183 471 417 183 471 minecraft:magenta_concrete
setblock 378 183 472 minecraft:white_concrete
fill 378 183 473 417 183 473 minecraft:magenta_concrete
setblock 378 183 474 minecraft:black_concrete
fill 378 183 475 417 183 475 minecraft:magenta_concrete
setblock 378 183 476 minecraft:white_concrete
fill 378 183 477 417 183 477 minecraft:magenta_concrete
setblock 378 183 478 minecraft:black_concrete
fill 378 183 479 417 183 479 minecraft:magenta_concrete
setblock 378 183 480 minecraft:white_concrete
fill 378 183 481 399 183 481 minecraft:magenta_concrete
setblock 378 183 482 minecraft:black_concrete
fill 378 183 483 392 183 483 minecraft:magenta_concrete
setblock 378 183 484 minecraft:white_concrete
fill 378 183 485 392 183 485 minecraft:magenta_concrete
setblock 378 183 486 minecraft:black_concrete
fill 378 183 487 396 183 487 minecraft:magenta_concrete
setblock 378 183 488 minecraft:white_concrete
fill 378 183 489 393 183 489 minecraft:magenta_concrete
setblock 378 183 490 minecraft:black_concrete
fill 378 183 491 393 183 491 minecraft:magenta_concrete
setblock 378 183 492 minecraft:white_concrete
fill 378 183 493 393 183 493 minecraft:magenta_concrete
setblock 378 183 494 minecraft:black_concrete
fill 378 183 495 417 183 495 minecraft:magenta_concrete
setblock 378 183 496 minecraft:white_concrete
fill 378 183 497 417 183 497 minecraft:magenta_concrete
setblock 378 183 498 minecraft:black_concrete
fill 378 183 499 417 183 499 minecraft:magenta_concrete
setblock 378 183 500 minecraft:white_concrete
fill 378 183 501 417 183 501 minecraft:magenta_concrete
setblock 378 183 502 minecraft:black_concrete
fill 378 183 503 417 183 503 minecraft:magenta_concrete
setblock 378 183 504 minecraft:white_concrete
setblock 379 183 464 minecraft:magenta_concrete
setblock 379 183 466 minecraft:magenta_concrete
setblock 379 183 468 minecraft:magenta_concrete
setblock 379 183 470 minecraft:magenta_concrete
setblock 379 183 472 minecraft:magenta_concrete
setblock 379 183 474 minecraft:magenta_concrete
setblock 379 183 476 minecraft:magenta_concrete
setblock 379 183 478 minecraft:magenta_concrete
setblock 379 183 480 minecraft:magenta_concrete
setblock 379 183 482 minecraft:magenta_concrete
setblock 379 183 484 minecraft:magenta_concrete
setblock 379 183 486 minecraft:magenta_concrete
setblock 379 183 488 minecraft:magenta_concrete
setblock 379 183 490 minecraft:magenta_concrete
setblock 379 183 492 minecraft:magenta_concrete
setblock 379 183 494 minecraft:magenta_concrete
setblock 379 183 496 minecraft:magenta_concrete
setblock 379 183 498 minecraft:magenta_concrete
setblock 379 183 500 minecraft:magenta_concrete
setblock 379 183 502 minecraft:magenta_concrete
setblock 379 183 504 minecraft:magenta_concrete
setblock 380 183 464 minecraft:black_concrete
setblock 380 183 466 minecraft:white_concrete
setblock 380 183 468 minecraft:black_concrete
setblock 380 183 470 minecraft:white_concrete
setblock 380 183 472 minecraft:black_concrete
setblock 380 183 474 minecraft:white_concrete
setblock 380 183 476 minecraft:black_concrete
setblock 380 183 478 minecraft:white_concrete
setblock 380 183 480 minecraft:black_concrete
setblock 380 183 482 minecraft:white_concrete
setblock 380 183 484 minecraft:black_concrete
setblock 380 183 486 minecraft:white_concrete
setblock 380 183 488 minecraft:black_concrete
setblock 380 183 490 minecraft:white_concrete
setblock 380 183 492 minecraft:black_concrete
setblock 380 183 494 minecraft:white_concrete
setblock 380 183 496 minecraft:black_concrete
setblock 380 183 498 minecraft:white_concrete
setblock 380 183 500 minecraft:black_concrete
setblock 380 183 502 minecraft:white_concrete
setblock 380 183 504 minecraft:black_concrete
setblock 381 183 464 minecraft:magenta_concrete
setblock 381 183 466 minecraft:magenta_concrete
setblock 381 183 468 minecraft:magenta_concrete
setblock 381 183 470 minecraft:magenta_concrete
setblock 381 183 472 minecraft:magenta_concrete
setblock 381 183 474 minecraft:magenta_concrete
setblock 381 183 476 minecraft:magenta_concrete
setblock 381 183 478 minecraft:magenta_concrete
setblock 381 183 480 minecraft:magenta_concrete
setblock 381 183 482 minecraft:magenta_concrete
setblock 381 183 484 minecraft:magenta_concrete
setblock 381 183 486 minecraft:magenta_concrete
setblock 381 183 488 minecraft:magenta_concrete
setblock 381 183 490 minecraft:magenta_concrete
setblock 381 183 492 minecraft:magenta_concrete
setblock 381 183 494 minecraft:magenta_concrete
setblock 381 183 496 minecraft:magenta_concrete
setblock 381 183 498 minecraft:magenta_concrete
setblock 381 183 500 minecraft:magenta_concrete
setblock 381 183 502 minecraft:magenta_concrete
setblock 381 183 504 minecraft:magenta_concrete
setblock 382 183 464 minecraft:white_concrete
setblock 382 183 466 minecraft:black_concrete
setblock 382 183 468 minecraft:white_concrete
setblock 382 183 470 minecraft:black_concrete
setblock 382 183 472 minecraft:white_concrete
setblock 382 183 474 minecraft:black_concrete
setblock 382 183 476 minecraft:white_concrete
setblock 382 183 478 minecraft:black_concrete
setblock 382 183 480 minecraft:white_concrete
setblock 382 183 482 minecraft:black_concrete
setblock 382 183 484 minecraft:white_concrete
setblock 382 183 486 minecraft:black_concrete
setblock 382 183 488 minecraft:white_concrete
setblock 382 183 490 minecraft:black_concrete
setblock 382 183 492 minecraft:white_concrete
setblock 382 183 494 minecraft:black_concrete
setblock 382 183 496 minecraft:white_concrete
setblock 382 183 498 minecraft:black_concrete
setblock 382 183 500 minecraft:white_concrete
setblock 382 183 502 minecraft:black_concrete
setblock 382 183 504 minecraft:white_concrete
setblock 383 183 464 minecraft:magenta_concrete
setblock 383 183 466 minecraft:magenta_concrete
setblock 383 183 468 minecraft:magenta_concrete
setblock 383 183 470 minecraft:magenta_concrete
setblock 383 183 472 minecraft:magenta_concrete
setblock 383 183 474 minecraft:magenta_concrete
setblock 383 183 476 minecraft:magenta_concrete
setblock 383 183 478 minecraft:magenta_concrete
setblock 383 183 480 minecraft:magenta_concrete
setblock 383 183 482 minecraft:magenta_concrete
setblock 383 183 484 minecraft:magenta_concrete
setblock 383 183 486 minecraft:magenta_concrete
setblock 383 183 488 minecraft:magenta_concrete
setblock 383 183 490 minecraft:magenta_concrete
setblock 383 183 492 minecraft:magenta_concrete
setblock 383 183 494 minecraft:magenta_concrete
setblock 383 183 496 minecraft:magenta_concrete
setblock 383 183 498 minecraft:magenta_concrete
setblock 383 183 500 minecraft:magenta_concrete
setblock 383 183 502 minecraft:magenta_concrete
setblock 383 183 504 minecraft:magenta_concrete
setblock 384 183 464 minecraft:black_concrete
setblock 384 183 466 minecraft:white_concrete
setblock 384 183 468 minecraft:black_concrete
setblock 384 183 470 minecraft:white_concrete
setblock 384 183 472 minecraft:black_concrete
setblock 384 183 474 minecraft:white_concrete
setblock 384 183 476 minecraft:black_concrete
setblock 384 183 478 minecraft:white_concrete
setblock 384 183 480 minecraft:black_concrete
setblock 384 183 482 minecraft:white_concrete
setblock 384 183 484 minecraft:black_concrete
setblock 384 183 486 minecraft:white_concrete
setblock 384 183 488 minecraft:black_concrete
setblock 384 183 490 minecraft:white_concrete
setblock 384 183 492 minecraft:black_concrete
setblock 384 183 494 minecraft:white_concrete
setblock 384 183 496 minecraft:black_concrete
setblock 384 183 498 minecraft:white_concrete
setblock 384 183 500 minecraft:black_concrete
setblock 384 183 502 minecraft:white_concrete
setblock 384 183 504 minecraft:black_concrete
setblock 385 183 464 minecraft:magenta_concrete
setblock 385 183 466 minecraft:magenta_concrete
setblock 385 183 468 minecraft:magenta_concrete
setblock 385 183 470 minecraft:magenta_concrete
setblock 385 183 472 minecraft:magenta_concrete
setblock 385 183 474 minecraft:magenta_concrete
setblock 385 183 476 minecraft:magenta_concrete
setblock 385 183 478 minecraft:magenta_concrete
setblock 385 183 480 minecraft:magenta_concrete
setblock 385 183 482 minecraft:magenta_concrete
setblock 385 183 484 minecraft:magenta_concrete
setblock 385 183 486 minecraft:magenta_concrete
setblock 385 183 488 minecraft:magenta_concrete
setblock 385 183 490 minecraft:magenta_concrete
setblock 385 183 492 minecraft:magenta_concrete
setblock 385 183 494 minecraft:magenta_concrete
setblock 385 183 496 minecraft:magenta_concrete
setblock 385 183 498 minecraft:magenta_concrete
setblock 385 183 500 minecraft:magenta_concrete
setblock 385 183 502 minecraft:magenta_concrete
setblock 385 183 504 minecraft:magenta_concrete
setblock 386 183 464 minecraft:white_concrete
setblock 386 183 466 minecraft:black_concrete
setblock 386 183 468 minecraft:white_concrete
setblock 386 183 470 minecraft:black_concrete
setblock 386 183 472 minecraft:white_concrete
setblock 386 183 474 minecraft:black_concrete
setblock 386 183 476 minecraft:white_concrete
setblock 386 183 478 minecraft:black_concrete
setblock 386 183 480 minecraft:white_concrete
setblock 386 183 482 minecraft:black_concrete
setblock 386 183 484 minecraft:white_concrete
setblock 386 183 486 minecraft:black_concrete
setblock 386 183 488 minecraft:white_concrete
setblock 386 183 490 minecraft:black_concrete
setblock 386 183 492 minecraft:white_concrete
setblock 386 183 494 minecraft:black_concrete
setblock 386 183 496 minecraft:white_concrete
setblock 386 183 498 minecraft:black_concrete
setblock 386 183 500 minecraft:white_concrete
setblock 386 183 502 minecraft:black_concrete
setblock 386 183 504 minecraft:white_concrete
setblock 387 183 464 minecraft:magenta_concrete
setblock 387 183 466 minecraft:magenta_concrete
setblock 387 183 468 minecraft:magenta_concrete
setblock 387 183 470 minecraft:magenta_concrete
setblock 387 183 472 minecraft:magenta_concrete
setblock 387 183 474 minecraft:magenta_concrete
setblock 387 183 476 minecraft:magenta_concrete
setblock 387 183 478 minecraft:magenta_concrete
setblock 387 183 480 minecraft:magenta_concrete
setblock 387 183 482 minecraft:magenta_concrete
setblock 387 183 484 minecraft:magenta_concrete
setblock 387 183 486 minecraft:magenta_concrete
setblock 387 183 488 minecraft:magenta_concrete
setblock 387 183 490 minecraft:magenta_concrete
setblock 387 183 492 minecraft:magenta_concrete
setblock 387 183 494 minecraft:magenta_concrete
setblock 387 183 496 minecraft:magenta_concrete
setblock 387 183 498 minecraft:magenta_concrete
setblock 387 183 500 minecraft:magenta_concrete
setblock 387 183 502 minecraft:magenta_concrete
setblock 387 183 504 minecraft:magenta_concrete
setblock 388 183 464 minecraft:black_concrete
setblock 388 183 466 minecraft:white_concrete
setblock 388 183 468 minecraft:black_concrete
setblock 388 183 470 minecraft:white_concrete
setblock 388 183 472 minecraft:black_concrete
setblock 388 183 474 minecraft:white_concrete
setblock 388 183 476 minecraft:black_concrete
setblock 388 183 478 minecraft:white_concrete
setblock 388 183 480 minecraft:black_concrete
setblock 388 183 482 minecraft:white_concrete
setblock 388 183 484 minecraft:black_concrete
setblock 388 183 486 minecraft:white_concrete
setblock 388 183 488 minecraft:black_concrete
setblock 388 183 490 minecraft:white_concrete
setblock 388 183 492 minecraft:black_concrete
setblock 388 183 494 minecraft:white_concrete
setblock 388 183 496 minecraft:black_concrete
setblock 388 183 498 minecraft:white_concrete
setblock 388 183 500 minecraft:black_concrete
setblock 388 183 502 minecraft:white_concrete
setblock 388 183 504 minecraft:black_concrete
setblock 389 183 464 minecraft:magenta_concrete
setblock 389 183 466 minecraft:magenta_concrete
setblock 389 183 468 minecraft:magenta_concrete
setblock 389 183 470 minecraft:magenta_concrete
setblock 389 183 472 minecraft:magenta_concrete
setblock 389 183 474 minecraft:magenta_concrete
setblock 389 183 476 minecraft:magenta_concrete
setblock 389 183 478 minecraft:magenta_concrete
setblock 389 183 480 minecraft:magenta_concrete
setblock 389 183 482 minecraft:magenta_concrete
setblock 389 183 484 minecraft:magenta_concrete
setblock 389 183 486 minecraft:magenta_concrete
setblock 389 183 488 minecraft:magenta_concrete
setblock 389 183 490 minecraft:magenta_concrete
setblock 389 183 492 minecraft:magenta_concrete
setblock 389 183 494 minecraft:magenta_concrete
setblock 389 183 496 minecraft:magenta_concrete
setblock 389 183 498 minecraft:magenta_concrete
setblock 389 183 500 minecraft:magenta_concrete
setblock 389 183 502 minecraft:magenta_concrete
setblock 389 183 504 minecraft:magenta_concrete
setblock 390 183 464 minecraft:white_concrete
setblock 390 183 466 minecraft:black_concrete
setblock 390 183 468 minecraft:white_concrete
setblock 390 183 470 minecraft:black_concrete
setblock 390 183 472 minecraft:white_concrete
setblock 390 183 474 minecraft:black_concrete
setblock 390 183 476 minecraft:white_concrete
setblock 390 183 478 minecraft:black_concrete
setblock 390 183 480 minecraft:white_concrete
setblock 390 183 482 minecraft:black_concrete
setblock 390 183 484 minecraft:white_concrete
setblock 390 183 486 minecraft:black_concrete
setblock 390 183 488 minecraft:white_concrete
setblock 390 183 490 minecraft:black_concrete
setblock 390 183 492 minecraft:white_concrete
setblock 390 183 494 minecraft:black_concrete
setblock 390 183 496 minecraft:white_concrete
setblock 390 183 498 minecraft:black_concrete
setblock 390 183 500 minecraft:white_concrete
setblock 390 183 502 minecraft:black_concrete
setblock 390 183 504 minecraft:white_concrete
setblock 391 183 464 minecraft:magenta_concrete
setblock 391 183 466 minecraft:magenta_concrete
setblock 391 183 468 minecraft:magenta_concrete
setblock 391 183 470 minecraft:magenta_concrete
setblock 391 183 472 minecraft:magenta_concrete
setblock 391 183 474 minecraft:magenta_concrete
setblock 391 183 476 minecraft:magenta_concrete
setblock 391 183 478 minecraft:magenta_concrete
setblock 391 183 480 minecraft:magenta_concrete
setblock 391 183 482 minecraft:magenta_concrete
setblock 391 183 484 minecraft:magenta_concrete
setblock 391 183 486 minecraft:magenta_concrete
setblock 391 183 488 minecraft:magenta_concrete
setblock 391 183 490 minecraft:magenta_concrete
setblock 391 183 492 minecraft:magenta_concrete
setblock 391 183 494 minecraft:magenta_concrete
setblock 391 183 496 minecraft:magenta_concrete
setblock 391 183 498 minecraft:magenta_concrete
setblock 391 183 500 minecraft:magenta_concrete
setblock 391 183 502 minecraft:magenta_concrete
setblock 391 183 504 minecraft:magenta_concrete
setblock 392 183 464 minecraft:black_concrete
setblock 392 183 466 minecraft:white_concrete
setblock 392 183 468 minecraft:black_concrete
setblock 392 183 470 minecraft:white_concrete
setblock 392 183 472 minecraft:black_concrete
setblock 392 183 474 minecraft:white_concrete
setblock 392 183 476 minecraft:black_concrete
setblock 392 183 478 minecraft:white_concrete
setblock 392 183 480 minecraft:black_concrete
setblock 392 183 482 minecraft:white_concrete
setblock 392 183 484 minecraft:black_concrete
setblock 392 183 486 minecraft:white_concrete
setblock 392 183 488 minecraft:black_concrete
setblock 392 183 490 minecraft:white_concrete
setblock 392 183 492 minecraft:black_concrete
setblock 392 183 494 minecraft:white_concrete
setblock 392 183 496 minecraft:black_concrete
setblock 392 183 498 minecraft:white_concrete
setblock 392 183 500 minecraft:black_concrete
setblock 392 183 502 minecraft:white_concrete
setblock 392 183 504 minecraft:black_concrete
setblock 393 183 464 minecraft:magenta_concrete
setblock 393 183 466 minecraft:magenta_concrete
setblock 393 183 468 minecraft:magenta_concrete
setblock 393 183 470 minecraft:magenta_concrete
setblock 393 183 472 minecraft:magenta_concrete
setblock 393 183 474 minecraft:magenta_concrete
setblock 393 183 476 minecraft:magenta_concrete
setblock 393 183 478 minecraft:magenta_concrete
setblock 393 183 480 minecraft:magenta_concrete
fill 393 183 482 393 183 486 minecraft:sea_lantern
setblock 393 183 488 minecraft:magenta_concrete
setblock 393 183 490 minecraft:magenta_concrete
setblock 393 183 492 minecraft:magenta_concrete
setblock 393 183 494 minecraft:magenta_concrete
setblock 393 183 496 minecraft:magenta_concrete
setblock 393 183 498 minecraft:magenta_concrete
setblock 393 183 500 minecraft:magenta_concrete
setblock 393 183 502 minecraft:magenta_concrete
setblock 393 183 504 minecraft:magenta_concrete
setblock 394 183 464 minecraft:white_concrete
setblock 394 183 466 minecraft:black_concrete
setblock 394 183 468 minecraft:white_concrete
setblock 394 183 470 minecraft:black_concrete
setblock 394 183 472 minecraft:white_concrete
setblock 394 183 474 minecraft:black_concrete
setblock 394 183 476 minecraft:white_concrete
setblock 394 183 478 minecraft:black_concrete
setblock 394 183 480 minecraft:white_concrete
fill 394 183 482 397 183 482 minecraft:sea_lantern
fill 394 183 483 396 183 485 minecraft:white_concrete
fill 394 183 486 397 183 486 minecraft:sea_lantern
setblock 394 183 488 minecraft:white_concrete
fill 394 183 489 394 183 493 minecraft:sea_lantern
setblock 394 183 494 minecraft:black_concrete
setblock 394 183 496 minecraft:white_concrete
setblock 394 183 498 minecraft:black_concrete
setblock 394 183 500 minecraft:white_concrete
setblock 394 183 502 minecraft:black_concrete
setblock 394 183 504 minecraft:white_concrete
setblock 395 183 464 minecraft:magenta_concrete
setblock 395 183 466 minecraft:magenta_concrete
setblock 395 183 468 minecraft:magenta_concrete
setblock 395 183 470 minecraft:magenta_concrete
setblock 395 183 472 minecraft:magenta_concrete
setblock 395 183 474 minecraft:magenta_concrete
setblock 395 183 476 minecraft:magenta_concrete
setblock 395 183 478 minecraft:magenta_concrete
setblock 395 183 480 minecraft:magenta_concrete
setblock 395 183 488 minecraft:magenta_concrete
fill 395 183 489 404 183 489 minecraft:sea_lantern
fill 395 183 490 397 183 492 minecraft:white_concrete
fill 395 183 493 398 183 493 minecraft:sea_lantern
setblock 395 183 494 minecraft:magenta_concrete
setblock 395 183 496 minecraft:magenta_concrete
setblock 395 183 498 minecraft:magenta_concrete
setblock 395 183 500 minecraft:magenta_concrete
setblock 395 183 502 minecraft:magenta_concrete
setblock 395 183 504 minecraft:magenta_concrete
setblock 396 183 464 minecraft:black_concrete
setblock 396 183 466 minecraft:white_concrete
setblock 396 183 468 minecraft:black_concrete
setblock 396 183 470 minecraft:white_concrete
setblock 396 183 472 minecraft:black_concrete
setblock 396 183 474 minecraft:white_concrete
setblock 396 183 476 minecraft:black_concrete
setblock 396 183 478 minecraft:white_concrete
setblock 396 183 480 minecraft:black_concrete
setblock 396 183 488 minecraft:black_concrete
setblock 396 183 494 minecraft:white_concrete
setblock 396 183 496 minecraft:black_concrete
setblock 396 183 498 minecraft:white_concrete
setblock 396 183 500 minecraft:black_concrete
setblock 396 183 502 minecraft:white_concrete
setblock 396 183 504 minecraft:black_concrete
setblock 397 183 464 minecraft:magenta_concrete
setblock 397 183 466 minecraft:magenta_concrete
setblock 397 183 468 minecraft:magenta_concrete
setblock 397 183 470 minecraft:magenta_concrete
setblock 397 183 472 minecraft:magenta_concrete
setblock 397 183 474 minecraft:magenta_concrete
setblock 397 183 476 minecraft:magenta_concrete
setblock 397 183 478 minecraft:magenta_concrete
setblock 397 183 480 minecraft:magenta_concrete
fill 397 183 483 397 183 485 minecraft:sea_lantern
fill 397 183 487 397 183 488 minecraft:sea_lantern
setblock 397 183 494 minecraft:magenta_concrete
setblock 397 183 496 minecraft:magenta_concrete
setblock 397 183 498 minecraft:magenta_concrete
setblock 397 183 500 minecraft:magenta_concrete
setblock 397 183 502 minecraft:magenta_concrete
setblock 397 183 504 minecraft:magenta_concrete
setblock 398 183 464 minecraft:white_concrete
setblock 398 183 466 minecraft:black_concrete
setblock 398 183 468 minecraft:white_concrete
setblock 398 183 470 minecraft:black_concrete
setblock 398 183 472 minecraft:white_concrete
setblock 398 183 474 minecraft:black_concrete
setblock 398 183 476 minecraft:white_concrete
setblock 398 183 478 minecraft:black_concrete
setblock 398 183 480 minecraft:white_concrete
setblock 398 183 482 minecraft:black_concrete
fill 398 183 483 399 183 483 minecraft:magenta_concrete
setblock 398 183 484 minecraft:white_concrete
fill 398 183 485 404 183 485 minecraft:sea_lantern
fill 398 183 490 398 183 492 minecraft:sea_lantern
setblock 398 183 494 minecraft:black_concrete
setblock 398 183 496 minecraft:white_concrete
setblock 398 183 498 minecraft:black_concrete
setblock 398 183 500 minecraft:white_concrete
setblock 398 183 502 minecraft:black_concrete
setblock 398 183 504 minecraft:white_concrete
setblock 399 183 464 minecraft:magenta_concrete
setblock 399 183 466 minecraft:magenta_concrete
setblock 399 183 468 minecraft:magenta_concrete
setblock 399 183 470 minecraft:magenta_concrete
setblock 399 183 472 minecraft:magenta_concrete
setblock 399 183 474 minecraft:magenta_concrete
setblock 399 183 476 minecraft:magenta_concrete
setblock 399 183 478 minecraft:magenta_concrete
setblock 399 183 480 minecraft:magenta_concrete
setblock 399 183 482 minecraft:magenta_concrete
setblock 399 183 484 minecraft:magenta_concrete
fill 399 183 490 399 183 494 minecraft:magenta_concrete
setblock 399 183 496 minecraft:magenta_concrete
setblock 399 183 498 minecraft:magenta_concrete
setblock 399 183 500 minecraft:magenta_concrete
setblock 399 183 502 minecraft:magenta_concrete
setblock 399 183 504 minecraft:magenta_concrete
setblock 400 183 464 minecraft:black_concrete
setblock 400 183 466 minecraft:white_concrete
setblock 400 183 468 minecraft:black_concrete
setblock 400 183 470 minecraft:white_concrete
setblock 400 183 472 minecraft:black_concrete
setblock 400 183 474 minecraft:white_concrete
setblock 400 183 476 minecraft:black_concrete
setblock 400 183 478 minecraft:white_concrete
setblock 400 183 480 minecraft:black_concrete
fill 400 183 481 400 183 484 minecraft:sea_lantern
fill 400 183 490 400 183 493 minecraft:sea_lantern
setblock 400 183 494 minecraft:white_concrete
setblock 400 183 496 minecraft:black_concrete
setblock 400 183 498 minecraft:white_concrete
setblock 400 183 500 minecraft:black_concrete
setblock 400 183 502 minecraft:white_concrete
setblock 400 183 504 minecraft:black_concrete
setblock 401 183 464 minecraft:magenta_concrete
setblock 401 183 466 minecraft:magenta_concrete
setblock 401 183 468 minecraft:magenta_concrete
setblock 401 183 470 minecraft:magenta_concrete
setblock 401 183 472 minecraft:magenta_concrete
setblock 401 183 474 minecraft:magenta_concrete
setblock 401 183 476 minecraft:magenta_concrete
setblock 401 183 478 minecraft:magenta_concrete
setblock 401 183 480 minecraft:magenta_concrete
fill 401 183 481 404 183 481 minecraft:sea_lantern
fill 401 183 482 403 183 484 minecraft:white_concrete
fill 401 183 486 401 183 488 minecraft:sea_lantern
fill 401 183 490 403 183 492 minecraft:white_concrete
fill 401 183 493 404 183 493 minecraft:sea_lantern
setblock 401 183 494 minecraft:magenta_concrete
setblock 401 183 496 minecraft:magenta_concrete
setblock 401 183 498 minecraft:magenta_concrete
setblock 401 183 500 minecraft:magenta_concrete
setblock 401 183 502 minecraft:magenta_concrete
setblock 401 183 504 minecraft:magenta_concrete
setblock 402 183 464 minecraft:white_concrete
setblock 402 183 466 minecraft:black_concrete
setblock 402 183 468 minecraft:white_concrete
setblock 402 183 470 minecraft:black_concrete
setblock 402 183 472 minecraft:white_concrete
setblock 402 183 474 minecraft:black_concrete
setblock 402 183 476 minecraft:white_concrete
setblock 402 183 478 minecraft:black_concrete
setblock 402 183 480 minecraft:white_concrete
setblock 402 183 486 minecraft:black_concrete
fill 402 183 487 417 183 487 minecraft:magenta_concrete
setblock 402 183 488 minecraft:white_concrete
setblock 402 183 494 minecraft:black_concrete
setblock 402 183 496 minecraft:white_concrete
setblock 402 183 498 minecraft:black_concrete
setblock 402 183 500 minecraft:white_concrete
setblock 402 183 502 minecraft:black_concrete
setblock 402 183 504 minecraft:white_concrete
setblock 403 183 464 minecraft:magenta_concrete
setblock 403 183 466 minecraft:magenta_concrete
setblock 403 183 468 minecraft:magenta_concrete
setblock 403 183 470 minecraft:magenta_concrete
setblock 403 183 472 minecraft:magenta_concrete
setblock 403 183 474 minecraft:magenta_concrete
setblock 403 183 476 minecraft:magenta_concrete
setblock 403 183 478 minecraft:magenta_concrete
setblock 403 183 480 minecraft:magenta_concrete
setblock 403 183 486 minecraft:magenta_concrete
setblock 403 183 488 minecraft:magenta_concrete
setblock 403 183 494 minecraft:magenta_concrete
setblock 403 183 496 minecraft:magenta_concrete
setblock 403 183 498 minecraft:magenta_concrete
setblock 403 183 500 minecraft:magenta_concrete
setblock 403 183 502 minecraft:magenta_concrete
setblock 403 183 504 minecraft:magenta_concrete
setblock 404 183 464 minecraft:black_concrete
setblock 404 183 466 minecraft:white_concrete
setblock 404 183 468 minecraft:black_concrete
setblock 404 183 470 minecraft:white_concrete
setblock 404 183 472 minecraft:black_concrete
setblock 404 183 474 minecraft:white_concrete
setblock 404 183 476 minecraft:black_concrete
setblock 404 183 478 minecraft:white_concrete
setblock 404 183 480 minecraft:black_concrete
fill 404 183 482 404 183 484 minecraft:sea_lantern
setblock 404 183 486 minecraft:white_concrete
setblock 404 183 488 minecraft:black_concrete
fill 404 183 490 404 183 492 minecraft:sea_lantern
setblock 404 183 494 minecraft:white_concrete
setblock 404 183 496 minecraft:black_concrete
setblock 404 183 498 minecraft:white_concrete
setblock 404 183 500 minecraft:black_concrete
setblock 404 183 502 minecraft:white_concrete
setblock 404 183 504 minecraft:black_concrete
setblock 405 183 464 minecraft:magenta_concrete
setblock 405 183 466 minecraft:magenta_concrete
setblock 405 183 468 minecraft:magenta_concrete
setblock 405 183 470 minecraft:magenta_concrete
setblock 405 183 472 minecraft:magenta_concrete
setblock 405 183 474 minecraft:magenta_concrete
setblock 405 183 476 minecraft:magenta_concrete
setblock 405 183 478 minecraft:magenta_concrete
fill 405 183 480 405 183 486 minecraft:magenta_concrete
fill 405 183 488 405 183 494 minecraft:magenta_concrete
setblock 405 183 496 minecraft:magenta_concrete
setblock 405 183 498 minecraft:magenta_concrete
setblock 405 183 500 minecraft:magenta_concrete
setblock 405 183 502 minecraft:magenta_concrete
setblock 405 183 504 minecraft:magenta_concrete
setblock 406 183 464 minecraft:white_concrete
setblock 406 183 466 minecraft:black_concrete
setblock 406 183 468 minecraft:white_concrete
setblock 406 183 470 minecraft:black_concrete
setblock 406 183 472 minecraft:white_concrete
setblock 406 183 474 minecraft:black_concrete
setblock 406 183 476 minecraft:white_concrete
setblock 406 183 478 minecraft:black_concrete
setblock 406 183 480 minecraft:white_concrete
fill 406 183 481 417 183 481 minecraft:magenta_concrete
setblock 406 183 482 minecraft:black_concrete
fill 406 183 483 417 183 483 minecraft:magenta_concrete
setblock 406 183 484 minecraft:white_concrete
fill 406 183 485 417 183 485 minecraft:magenta_concrete
setblock 406 183 486 minecraft:black_concrete
setblock 406 183 488 minecraft:white_concrete
fill 406 183 489 417 183 489 minecraft:magenta_concrete
setblock 406 183 490 minecraft:black_concrete
fill 406 183 491 417 183 491 minecraft:magenta_concrete
setblock 406 183 492 minecraft:white_concrete
fill 406 183 493 417 183 493 minecraft:magenta_concrete
setblock 406 183 494 minecraft:black_concrete
setblock 406 183 496 minecraft:white_concrete
setblock 406 183 498 minecraft:black_concrete
setblock 406 183 500 minecraft:white_concrete
setblock 406 183 502 minecraft:black_concrete
setblock 406 183 504 minecraft:white_concrete
setblock 407 183 464 minecraft:magenta_concrete
setblock 407 183 466 minecraft:magenta_concrete
setblock 407 183 468 minecraft:magenta_concrete
setblock 407 183 470 minecraft:magenta_concrete
setblock 407 183 472 minecraft:magenta_concrete
setblock 407 183 474 minecraft:magenta_concrete
setblock 407 183 476 minecraft:magenta_concrete
setblock 407 183 478 minecraft:magenta_concrete
setblock 407 183 480 minecraft:magenta_concrete
setblock 407 183 482 minecraft:magenta_concrete
setblock 407 183 484 minecraft:magenta_concrete
setblock 407 183 486 minecraft:magenta_concrete
setblock 407 183 488 minecraft:magenta_concrete
setblock 407 183 490 minecraft:magenta_concrete
setblock 407 183 492 minecraft:magenta_concrete
setblock 407 183 494 minecraft:magenta_concrete
setblock 407 183 496 minecraft:magenta_concrete
setblock 407 183 498 minecraft:magenta_concrete
setblock 407 183 500 minecraft:magenta_concrete
setblock 407 183 502 minecraft:magenta_concrete
setblock 407 183 504 minecraft:magenta_concrete
setblock 408 183 464 minecraft:black_concrete
setblock 408 183 466 minecraft:white_concrete
setblock 408 183 468 minecraft:black_concrete
setblock 408 183 470 minecraft:white_concrete
setblock 408 183 472 minecraft:black_concrete
setblock 408 183 474 minecraft:white_concrete
setblock 408 183 476 minecraft:black_concrete
setblock 408 183 478 minecraft:white_concrete
setblock 408 183 480 minecraft:black_concrete
setblock 408 183 482 minecraft:white_concrete
setblock 408 183 484 minecraft:black_concrete
setblock 408 183 486 minecraft:white_concrete
setblock 408 183 488 minecraft:black_concrete
setblock 408 183 490 minecraft:white_concrete
setblock 408 183 492 minecraft:black_concrete
setblock 408 183 494 minecraft:white_concrete
setblock 408 183 496 minecraft:black_concrete
setblock 408 183 498 minecraft:white_concrete
setblock 408 183 500 minecraft:black_concrete
setblock 408 183 502 minecraft:white_concrete
setblock 408 183 504 minecraft:black_concrete
setblock 409 183 464 minecraft:magenta_concrete
setblock 409 183 466 minecraft:magenta_concrete
setblock 409 183 468 minecraft:magenta_concrete
setblock 409 183 470 minecraft:magenta_concrete
setblock 409 183 472 minecraft:magenta_concrete
setblock 409 183 474 minecraft:magenta_concrete
setblock 409 183 476 minecraft:magenta_concrete
setblock 409 183 478 minecraft:magenta_concrete
setblock 409 183 480 minecraft:magenta_concrete
setblock 409 183 482 minecraft:magenta_concrete
setblock 409 183 484 minecraft:magenta_concrete
setblock 409 183 486 minecraft:magenta_concrete
setblock 409 183 488 minecraft:magenta_concrete
setblock 409 183 490 minecraft:magenta_concrete
setblock 409 183 492 minecraft:magenta_concrete
setblock 409 183 494 minecraft:magenta_concrete
setblock 409 183 496 minecraft:magenta_concrete
setblock 409 183 498 minecraft:magenta_concrete
setblock 409 183 500 minecraft:magenta_concrete
setblock 409 183 502 minecraft:magenta_concrete
setblock 409 183 504 minecraft:magenta_concrete
setblock 410 183 464 minecraft:white_concrete
setblock 410 183 466 minecraft:black_concrete
setblock 410 183 468 minecraft:white_concrete
setblock 410 183 470 minecraft:black_concrete
setblock 410 183 472 minecraft:white_concrete
setblock 410 183 474 minecraft:black_concrete
setblock 410 183 476 minecraft:white_concrete
setblock 410 183 478 minecraft:black_concrete
setblock 410 183 480 minecraft:white_concrete
setblock 410 183 482 minecraft:black_concrete
setblock 410 183 484 minecraft:white_concrete
setblock 410 183 486 minecraft:black_concrete
setblock 410 183 488 minecraft:white_concrete
setblock 410 183 490 minecraft:black_concrete
setblock 410 183 492 minecraft:white_concrete
setblock 410 183 494 minecraft:black_concrete
setblock 410 183 496 minecraft:white_concrete
setblock 410 183 498 minecraft:black_concrete
setblock 410 183 500 minecraft:white_concrete
setblock 410 183 502 minecraft:black_concrete
setblock 410 183 504 minecraft:white_concrete
setblock 411 183 464 minecraft:magenta_concrete
setblock 411 183 466 minecraft:magenta_concrete
setblock 411 183 468 minecraft:magenta_concrete
setblock 411 183 470 minecraft:magenta_concrete
setblock 411 183 472 minecraft:magenta_concrete
setblock 411 183 474 minecraft:magenta_concrete
setblock 411 183 476 minecraft:magenta_concrete
setblock 411 183 478 minecraft:magenta_concrete
setblock 411 183 480 minecraft:magenta_concrete
setblock 411 183 482 minecraft:magenta_concrete
setblock 411 183 484 minecraft:magenta_concrete
setblock 411 183 486 minecraft:magenta_concrete
setblock 411 183 488 minecraft:magenta_concrete
setblock 411 183 490 minecraft:magenta_concrete
setblock 411 183 492 minecraft:magenta_concrete
setblock 411 183 494 minecraft:magenta_concrete
setblock 411 183 496 minecraft:magenta_concrete
setblock 411 183 498 minecraft:magenta_concrete
setblock 411 183 500 minecraft:magenta_concrete
setblock 411 183 502 minecraft:magenta_concrete
setblock 411 183 504 minecraft:magenta_concrete
setblock 412 183 464 minecraft:black_concrete
setblock 412 183 466 minecraft:white_concrete
setblock 412 183 468 minecraft:black_concrete
setblock 412 183 470 minecraft:white_concrete
setblock 412 183 472 minecraft:black_concrete
setblock 412 183 474 minecraft:white_concrete
setblock 412 183 476 minecraft:black_concrete
setblock 412 183 478 minecraft:white_concrete
setblock 412 183 480 minecraft:black_concrete
setblock 412 183 482 minecraft:white_concrete
setblock 412 183 484 minecraft:black_concrete
setblock 412 183 486 minecraft:white_concrete
setblock 412 183 488 minecraft:black_concrete
setblock 412 183 490 minecraft:white_concrete
setblock 412 183 492 minecraft:black_concrete
setblock 412 183 494 minecraft:white_concrete
setblock 412 183 496 minecraft:black_concrete
setblock 412 183 498 minecraft:white_concrete
setblock 412 183 500 minecraft:black_concrete
setblock 412 183 502 minecraft:white_concrete
setblock 412 183 504 minecraft:black_concrete
setblock 413 183 464 minecraft:magenta_concrete
setblock 413 183 466 minecraft:magenta_concrete
setblock 413 183 468 minecraft:magenta_concrete
setblock 413 183 470 minecraft:magenta_concrete
setblock 413 183 472 minecraft:magenta_concrete
setblock 413 183 474 minecraft:magenta_concrete
setblock 413 183 476 minecraft:magenta_concrete
setblock 413 183 478 minecraft:magenta_concrete
setblock 413 183 480 minecraft:magenta_concrete
setblock 413 183 482 minecraft:magenta_concrete
setblock 413 183 484 minecraft:magenta_concrete
setblock 413 183 486 minecraft:magenta_concrete
setblock 413 183 488 minecraft:magenta_concrete
setblock 413 183 490 minecraft:magenta_concrete
setblock 413 183 492 minecraft:magenta_concrete
setblock 413 183 494 minecraft:magenta_concrete
setblock 413 183 496 minecraft:magenta_concrete
setblock 413 183 498 minecraft:magenta_concrete
setblock 413 183 500 minecraft:magenta_concrete
setblock 413 183 502 minecraft:magenta_concrete
setblock 413 183 504 minecraft:magenta_concrete
setblock 414 183 464 minecraft:white_concrete
setblock 414 183 466 minecraft:black_concrete
setblock 414 183 468 minecraft:white_concrete
setblock 414 183 470 minecraft:black_concrete
setblock 414 183 472 minecraft:white_concrete
setblock 414 183 474 minecraft:black_concrete
setblock 414 183 476 minecraft:white_concrete
setblock 414 183 478 minecraft:black_concrete
setblock 414 183 480 minecraft:white_concrete
setblock 414 183 482 minecraft:black_concrete
setblock 414 183 484 minecraft:white_concrete
setblock 414 183 486 minecraft:black_concrete
setblock 414 183 488 minecraft:white_concrete
setblock 414 183 490 minecraft:black_concrete
setblock 414 183 492 minecraft:white_concrete
setblock 414 183 494 minecraft:black_concrete
setblock 414 183 496 minecraft:white_concrete
setblock 414 183 498 minecraft:black_concrete
setblock 414 183 500 minecraft:white_concrete
setblock 414 183 502 minecraft:black_concrete
setblock 414 183 504 minecraft:white_concrete
setblock 415 183 464 minecraft:magenta_concrete
setblock 415 183 466 minecraft:magenta_concrete
setblock 415 183 468 minecraft:magenta_concrete
setblock 415 183 470 minecraft:magenta_concrete
setblock 415 183 472 minecraft:magenta_concrete
setblock 415 183 474 minecraft:magenta_concrete
setblock 415 183 476 minecraft:magenta_concrete
setblock 415 183 478 minecraft:magenta_concrete
setblock 415 183 480 minecraft:magenta_concrete
setblock 415 183 482 minecraft:magenta_concrete
setblock 415 183 484 minecraft:magenta_concrete
setblock 415 183 486 minecraft:magenta_concrete
setblock 415 183 488 minecraft:magenta_concrete
setblock 415 183 490 minecraft:magenta_concrete
setblock 415 183 492 minecraft:magenta_concrete
setblock 415 183 494 minecraft:magenta_concrete
setblock 415 183 496 minecraft:magenta_concrete
setblock 415 183 498 minecraft:magenta_concrete
setblock 415 183 500 minecraft:magenta_concrete
setblock 415 183 502 minecraft:magenta_concrete
setblock 415 183 504 minecraft:magenta_concrete
setblock 416 183 464 minecraft:black_concrete
setblock 416 183 466 minecraft:white_concrete
setblock 416 183 468 minecraft:black_concrete
setblock 416 183 470 minecraft:white_concrete
setblock 416 183 472 minecraft:black_concrete
setblock 416 183 474 minecraft:white_concrete
setblock 416 183 476 minecraft:black_concrete
setblock 416 183 478 minecraft:white_concrete
setblock 416 183 480 minecraft:black_concrete
setblock 416 183 482 minecraft:white_concrete
setblock 416 183 484 minecraft:black_concrete
setblock 416 183 486 minecraft:white_concrete
setblock 416 183 488 minecraft:black_concrete
setblock 416 183 490 minecraft:white_concrete
setblock 416 183 492 minecraft:black_concrete
setblock 416 183 494 minecraft:white_concrete
setblock 416 183 496 minecraft:black_concrete
setblock 416 183 498 minecraft:white_concrete
setblock 416 183 500 minecraft:black_concrete
setblock 416 183 502 minecraft:white_concrete
setblock 416 183 504 minecraft:black_concrete
setblock 417 183 464 minecraft:magenta_concrete
setblock 417 183 466 minecraft:magenta_concrete
setblock 417 183 468 minecraft:magenta_concrete
setblock 417 183 470 minecraft:magenta_concrete
setblock 417 183 472 minecraft:magenta_concrete
setblock 417 183 474 minecraft:magenta_concrete
setblock 417 183 476 minecraft:magenta_concrete
setblock 417 183 478 minecraft:magenta_concrete
setblock 417 183 480 minecraft:magenta_concrete
setblock 417 183 482 minecraft:magenta_concrete
setblock 417 183 484 minecraft:magenta_concrete
setblock 417 183 486 minecraft:magenta_concrete
setblock 417 183 488 minecraft:magenta_concrete
setblock 417 183 490 minecraft:magenta_concrete
setblock 417 183 492 minecraft:magenta_concrete
setblock 417 183 494 minecraft:magenta_concrete
setblock 417 183 496 minecraft:magenta_concrete
setblock 417 183 498 minecraft:magenta_concrete
setblock 417 183 500 minecraft:magenta_concrete
setblock 417 183 502 minecraft:magenta_concrete
setblock 417 183 504 minecraft:magenta_concrete
setblock 379 184 466 minecraft:light[level=14]
setblock 379 184 474 minecraft:light[level=14]
setblock 379 184 482 minecraft:light[level=14]
setblock 379 184 490 minecraft:light[level=14]
setblock 379 184 498 minecraft:light[level=14]
fill 385 184 487 387 198 487 minecraft:pink_concrete
fill 386 184 486 386 198 486 minecraft:pink_concrete
fill 386 184 488 386 198 488 minecraft:pink_concrete
setblock 387 184 466 minecraft:light[level=14]
setblock 387 184 474 minecraft:light[level=14]
setblock 387 184 482 minecraft:light[level=14]
setblock 387 184 490 minecraft:light[level=14]
setblock 387 184 498 minecraft:light[level=14]
fill 389 184 477 390 198 478 minecraft:light_blue_concrete
fill 389 184 496 390 198 497 minecraft:light_blue_concrete
setblock 395 184 466 minecraft:light[level=14]
setblock 395 184 474 minecraft:light[level=14]
setblock 395 184 482 minecraft:light[level=14]
setblock 395 184 490 minecraft:light[level=14]
setblock 395 184 498 minecraft:light[level=14]
fill 398 184 474 400 198 474 minecraft:pink_concrete
fill 398 184 500 400 198 500 minecraft:pink_concrete
fill 399 184 473 399 198 473 minecraft:pink_concrete
fill 399 184 475 399 198 475 minecraft:pink_concrete
fill 399 184 499 399 198 499 minecraft:pink_concrete
fill 399 184 501 399 198 501 minecraft:pink_concrete
setblock 403 184 466 minecraft:light[level=14]
setblock 403 184 474 minecraft:light[level=14]
setblock 403 184 482 minecraft:light[level=14]
setblock 403 184 490 minecraft:light[level=14]
setblock 403 184 498 minecraft:light[level=14]
fill 408 184 477 409 198 478 minecraft:light_blue_concrete
fill 408 184 496 409 198 497 minecraft:light_blue_concrete
setblock 411 184 466 minecraft:light[level=14]
setblock 411 184 474 minecraft:light[level=14]
setblock 411 184 482 minecraft:light[level=14]
fill 411 184 487 413 198 487 minecraft:pink_concrete
setblock 411 184 490 minecraft:light[level=14]
setblock 411 184 498 minecraft:light[level=14]
fill 412 184 486 412 198 486 minecraft:pink_concrete
fill 412 184 488 412 198 488 minecraft:pink_concrete
fill 393 185 486 394 186 488 minecraft:magenta_concrete
fill 394 185 484 394 186 485 minecraft:magenta_concrete
fill 394 185 489 394 186 490 minecraft:magenta_concrete
fill 395 185 483 395 186 484 minecraft:magenta_concrete
fill 395 185 490 395 186 491 minecraft:magenta_concrete
fill 396 185 482 396 186 483 minecraft:magenta_concrete
fill 396 185 491 396 186 492 minecraft:magenta_concrete
fill 397 185 482 402 186 482 minecraft:magenta_concrete
fill 397 185 492 402 186 492 minecraft:magenta_concrete
fill 398 185 481 400 186 481 minecraft:magenta_concrete
fill 398 185 493 400 186 493 minecraft:magenta_concrete
fill 402 185 483 403 186 483 minecraft:magenta_concrete
fill 402 185 491 403 186 491 minecraft:magenta_concrete
fill 403 185 484 404 186 484 minecraft:magenta_concrete
fill 403 185 490 404 186 490 minecraft:magenta_concrete
fill 404 185 485 404 186 489 minecraft:magenta_concrete
fill 405 185 486 405 186 488 minecraft:magenta_concrete
fill 376 187 468 376 191 468 minecraft:sea_lantern
fill 376 187 476 376 191 476 minecraft:sea_lantern
fill 376 187 484 376 191 484 minecraft:sea_lantern
fill 376 187 492 376 191 492 minecraft:sea_lantern
fill 376 187 500 376 191 500 minecraft:sea_lantern
fill 377 187 470 377 230 471 minecraft:black_concrete
fill 377 187 478 377 189 487 minecraft:black_concrete
fill 377 187 494 377 216 495 minecraft:black_concrete
fill 377 187 502 377 230 503 minecraft:black_concrete
fill 378 187 464 379 230 464 minecraft:black_concrete
fill 378 187 479 382 189 485 minecraft:black_concrete
fill 379 187 505 379 191 505 minecraft:sea_lantern
fill 383 187 463 383 191 463 minecraft:sea_lantern
fill 383 187 504 384 230 504 minecraft:black_concrete
fill 386 187 464 387 230 464 minecraft:black_concrete
fill 387 187 505 387 191 505 minecraft:sea_lantern
fill 391 187 463 391 191 463 minecraft:sea_lantern
fill 391 187 504 392 230 504 minecraft:black_concrete
fill 394 187 464 395 230 464 minecraft:black_concrete
fill 395 187 505 395 191 505 minecraft:sea_lantern
fill 399 187 463 399 191 463 minecraft:sea_lantern
fill 399 187 504 400 230 504 minecraft:black_concrete
fill 402 187 464 403 230 464 minecraft:black_concrete
fill 403 187 505 403 191 505 minecraft:sea_lantern
fill 407 187 463 407 191 463 minecraft:sea_lantern
fill 407 187 504 408 230 504 minecraft:black_concrete
fill 410 187 464 411 230 464 minecraft:black_concrete
fill 411 187 505 411 191 505 minecraft:sea_lantern
fill 415 187 463 415 191 463 minecraft:sea_lantern
fill 415 187 504 416 230 504 minecraft:black_concrete
fill 417 187 465 417 230 466 minecraft:black_concrete
fill 417 187 473 417 230 474 minecraft:black_concrete
fill 417 187 481 417 230 482 minecraft:black_concrete
fill 417 187 489 417 230 490 minecraft:black_concrete
fill 417 187 497 417 230 498 minecraft:black_concrete
fill 418 187 468 418 191 468 minecraft:sea_lantern
fill 418 187 476 418 191 476 minecraft:sea_lantern
fill 418 187 484 418 191 484 minecraft:sea_lantern
fill 418 187 492 418 191 492 minecraft:sea_lantern
fill 418 187 500 418 191 500 minecraft:sea_lantern
fill 390 188 471 392 190 473 minecraft:moss_block
fill 391 189 486 392 190 488 minecraft:cyan_concrete
fill 392 189 483 392 190 485 minecraft:cyan_concrete
fill 392 189 489 392 190 491 minecraft:cyan_concrete
fill 393 189 482 393 190 483 minecraft:cyan_concrete
fill 393 189 491 393 190 492 minecraft:cyan_concrete
fill 394 189 481 394 190 482 minecraft:cyan_concrete
fill 394 189 492 394 190 493 minecraft:cyan_concrete
fill 395 189 480 395 190 481 minecraft:cyan_concrete
fill 395 189 493 395 190 494 minecraft:cyan_concrete
fill 396 189 480 403 190 480 minecraft:cyan_concrete
fill 396 189 494 403 190 494 minecraft:cyan_concrete
fill 398 189 479 400 190 479 minecraft:cyan_concrete
fill 398 189 495 400 190 495 minecraft:cyan_concrete
fill 403 189 481 404 190 481 minecraft:cyan_concrete
fill 403 189 493 404 190 493 minecraft:cyan_concrete
fill 404 189 482 405 190 482 minecraft:cyan_concrete
fill 404 189 492 405 190 492 minecraft:cyan_concrete
fill 405 189 483 406 190 483 minecraft:cyan_concrete
fill 405 189 491 406 190 491 minecraft:cyan_concrete
fill 406 189 484 406 190 490 minecraft:cyan_concrete
fill 407 189 486 407 190 488 minecraft:cyan_concrete
fill 377 190 478 377 230 479 minecraft:black_concrete
setblock 377 190 480 minecraft:sea_lantern
fill 377 190 481 377 211 481 minecraft:black_concrete
setblock 377 190 482 minecraft:sea_lantern
fill 377 190 483 377 211 483 minecraft:black_concrete
setblock 377 190 484 minecraft:sea_lantern
fill 377 190 485 377 211 487 minecraft:black_concrete
setblock 378 190 479 minecraft:sea_lantern
fill 378 190 480 378 210 480 minecraft:black_concrete
setblock 378 190 481 minecraft:sea_lantern
fill 378 190 482 378 210 482 minecraft:black_concrete
setblock 378 190 483 minecraft:sea_lantern
fill 378 190 484 378 210 484 minecraft:black_concrete
setblock 378 190 485 minecraft:sea_lantern
fill 379 190 479 379 210 479 minecraft:black_concrete
setblock 379 190 480 minecraft:sea_lantern
fill 379 190 481 379 210 481 minecraft:black_concrete
setblock 379 190 482 minecraft:sea_lantern
fill 379 190 483 379 210 483 minecraft:black_concrete
setblock 379 190 484 minecraft:sea_lantern
fill 379 190 485 379 210 485 minecraft:black_concrete
setblock 380 190 479 minecraft:sea_lantern
fill 380 190 480 380 210 480 minecraft:black_concrete
setblock 380 190 481 minecraft:sea_lantern
fill 380 190 482 380 210 482 minecraft:black_concrete
setblock 380 190 483 minecraft:sea_lantern
fill 380 190 484 380 210 484 minecraft:black_concrete
setblock 380 190 485 minecraft:sea_lantern
fill 381 190 479 381 210 479 minecraft:black_concrete
setblock 381 190 480 minecraft:sea_lantern
fill 381 190 481 381 210 481 minecraft:black_concrete
setblock 381 190 482 minecraft:sea_lantern
fill 381 190 483 381 210 483 minecraft:black_concrete
setblock 381 190 484 minecraft:sea_lantern
fill 381 190 485 381 210 485 minecraft:black_concrete
setblock 382 190 479 minecraft:sea_lantern
fill 382 190 480 382 210 480 minecraft:black_concrete
setblock 382 190 481 minecraft:sea_lantern
fill 382 190 482 382 210 482 minecraft:black_concrete
setblock 382 190 483 minecraft:sea_lantern
fill 382 190 484 382 210 484 minecraft:black_concrete
setblock 382 190 485 minecraft:sea_lantern
fill 398 190 473 398 193 473 minecraft:black_concrete
fill 398 190 475 398 193 476 minecraft:black_concrete
fill 399 190 476 401 193 476 minecraft:black_concrete
fill 400 190 473 401 193 473 minecraft:black_concrete
fill 400 190 475 401 193 475 minecraft:black_concrete
fill 401 190 474 401 193 474 minecraft:black_concrete
fill 377 191 480 377 192 480 minecraft:black_concrete
fill 377 191 482 377 192 482 minecraft:black_concrete
fill 377 191 484 377 192 484 minecraft:black_concrete
fill 378 191 479 378 192 479 minecraft:black_concrete
fill 378 191 481 378 192 481 minecraft:black_concrete
fill 378 191 483 378 192 483 minecraft:black_concrete
fill 378 191 485 378 192 485 minecraft:black_concrete
fill 379 191 480 379 192 480 minecraft:black_concrete
fill 379 191 482 379 192 482 minecraft:black_concrete
fill 379 191 484 379 192 484 minecraft:black_concrete
fill 380 191 479 380 192 479 minecraft:black_concrete
fill 380 191 481 380 192 481 minecraft:black_concrete
fill 380 191 483 380 192 483 minecraft:black_concrete
fill 380 191 485 380 192 485 minecraft:black_concrete
fill 381 191 480 381 192 480 minecraft:black_concrete
fill 381 191 482 381 192 482 minecraft:black_concrete
fill 381 191 484 381 192 484 minecraft:black_concrete
fill 382 191 479 382 192 479 minecraft:black_concrete
fill 382 191 481 382 192 481 minecraft:black_concrete
fill 382 191 483 382 192 483 minecraft:black_concrete
fill 382 191 485 382 192 485 minecraft:black_concrete
fill 376 192 468 376 199 468 minecraft:black_concrete
fill 376 192 476 376 199 476 minecraft:black_concrete
fill 376 192 484 376 199 484 minecraft:black_concrete
fill 376 192 492 376 199 492 minecraft:black_concrete
fill 376 192 500 376 199 500 minecraft:black_concrete
setblock 379 192 466 minecraft:light[level=14]
setblock 379 192 474 minecraft:light[level=14]
setblock 379 192 490 minecraft:light[level=14]
setblock 379 192 498 minecraft:light[level=14]
fill 379 192 505 379 199 505 minecraft:black_concrete
fill 383 192 463 383 199 463 minecraft:black_concrete
setblock 387 192 466 minecraft:light[level=14]
setblock 387 192 474 minecraft:light[level=14]
setblock 387 192 482 minecraft:light[level=14]
setblock 387 192 490 minecraft:light[level=14]
setblock 387 192 498 minecraft:light[level=14]
fill 387 192 505 387 199 505 minecraft:black_concrete
fill 391 192 463 391 199 463 minecraft:black_concrete
setblock 395 192 466 minecraft:light[level=14]
setblock 395 192 474 minecraft:light[level=14]
setblock 395 192 482 minecraft:light[level=14]
setblock 395 192 490 minecraft:light[level=14]
setblock 395 192 498 minecraft:light[level=14]
fill 395 192 505 395 199 505 minecraft:black_concrete
fill 398 192 468 401 195 471 minecraft:cyan_concrete
fill 399 192 463 399 199 463 minecraft:black_concrete
setblock 403 192 466 minecraft:light[level=14]
setblock 403 192 474 minecraft:light[level=14]
setblock 403 192 482 minecraft:light[level=14]
setblock 403 192 490 minecraft:light[level=14]
setblock 403 192 498 minecraft:light[level=14]
fill 403 192 505 403 199 505 minecraft:black_concrete
fill 407 192 463 407 199 463 minecraft:black_concrete
setblock 411 192 466 minecraft:light[level=14]
setblock 411 192 474 minecraft:light[level=14]
setblock 411 192 482 minecraft:light[level=14]
setblock 411 192 490 minecraft:light[level=14]
setblock 411 192 498 minecraft:light[level=14]
fill 411 192 505 411 199 505 minecraft:black_concrete
fill 415 192 463 415 199 463 minecraft:black_concrete
fill 418 192 468 418 199 468 minecraft:black_concrete
fill 418 192 476 418 199 476 minecraft:black_concrete
fill 418 192 484 418 199 484 minecraft:black_concrete
fill 418 192 492 418 199 492 minecraft:black_concrete
fill 418 192 500 418 199 500 minecraft:black_concrete
setblock 377 193 480 minecraft:sea_lantern
setblock 377 193 482 minecraft:sea_lantern
setblock 377 193 484 minecraft:sea_lantern
setblock 378 193 479 minecraft:sea_lantern
setblock 378 193 481 minecraft:sea_lantern
setblock 378 193 483 minecraft:sea_lantern
setblock 378 193 485 minecraft:sea_lantern
setblock 379 193 480 minecraft:sea_lantern
setblock 379 193 482 minecraft:sea_lantern
setblock 379 193 484 minecraft:sea_lantern
setblock 380 193 479 minecraft:sea_lantern
setblock 380 193 481 minecraft:sea_lantern
setblock 380 193 483 minecraft:sea_lantern
setblock 380 193 485 minecraft:sea_lantern
setblock 381 193 480 minecraft:sea_lantern
setblock 381 193 482 minecraft:sea_lantern
setblock 381 193 484 minecraft:sea_lantern
setblock 382 193 479 minecraft:sea_lantern
setblock 382 193 481 minecraft:sea_lantern
setblock 382 193 483 minecraft:sea_lantern
setblock 382 193 485 minecraft:sea_lantern
fill 389 193 486 390 194 488 minecraft:lime_concrete
fill 390 193 483 390 194 485 minecraft:lime_concrete
fill 390 193 489 390 194 491 minecraft:lime_concrete
fill 391 193 481 391 194 483 minecraft:lime_concrete
fill 391 193 491 391 194 493 minecraft:lime_concrete
fill 392 193 480 392 194 481 minecraft:lime_concrete
fill 392 193 493 392 194 494 minecraft:lime_concrete
fill 393 193 479 393 194 480 minecraft:lime_concrete
fill 393 193 494 393 194 495 minecraft:lime_concrete
fill 394 193 479 395 194 479 minecraft:lime_concrete
fill 394 193 495 395 194 495 minecraft:lime_concrete
fill 395 193 478 403 194 478 minecraft:lime_concrete
fill 395 193 496 403 194 496 minecraft:lime_concrete
fill 398 193 477 400 194 477 minecraft:lime_concrete
fill 398 193 497 400 194 497 minecraft:lime_concrete
fill 403 193 479 405 194 479 minecraft:lime_concrete
fill 403 193 495 405 194 495 minecraft:lime_concrete
fill 405 193 480 406 194 480 minecraft:lime_concrete
fill 405 193 494 406 194 494 minecraft:lime_concrete
fill 406 193 481 407 194 481 minecraft:lime_concrete
fill 406 193 493 407 194 493 minecraft:lime_concrete
fill 407 193 482 407 194 483 minecraft:lime_concrete
fill 407 193 491 407 194 492 minecraft:lime_concrete
fill 408 193 483 408 194 491 minecraft:lime_concrete
fill 409 193 486 409 194 488 minecraft:lime_concrete
fill 377 194 480 377 195 480 minecraft:black_concrete
fill 377 194 482 377 195 482 minecraft:black_concrete
fill 377 194 484 377 195 484 minecraft:black_concrete
fill 378 194 479 378 195 479 minecraft:black_concrete
fill 378 194 481 378 195 481 minecraft:black_concrete
fill 378 194 483 378 195 483 minecraft:black_concrete
fill 378 194 485 378 195 485 minecraft:black_concrete
fill 379 194 480 379 195 480 minecraft:black_concrete
fill 379 194 482 379 195 482 minecraft:black_concrete
fill 379 194 484 379 195 484 minecraft:black_concrete
fill 380 194 479 380 195 479 minecraft:black_concrete
fill 380 194 481 380 195 481 minecraft:black_concrete
fill 380 194 483 380 195 483 minecraft:black_concrete
fill 380 194 485 380 195 485 minecraft:black_concrete
fill 381 194 480 381 195 480 minecraft:black_concrete
fill 381 194 482 381 195 482 minecraft:black_concrete
fill 381 194 484 381 195 484 minecraft:black_concrete
fill 382 194 479 382 195 479 minecraft:black_concrete
fill 382 194 481 382 195 481 minecraft:black_concrete
fill 382 194 483 382 195 483 minecraft:black_concrete
fill 382 194 485 382 195 485 minecraft:black_concrete
fill 397 194 466 398 195 467 minecraft:gold_block
fill 377 196 464 377 197 469 minecraft:black_concrete
fill 377 196 472 378 196 477 minecraft:black_concrete
setblock 377 196 480 minecraft:sea_lantern
setblock 377 196 482 minecraft:sea_lantern
setblock 377 196 484 minecraft:sea_lantern
fill 377 196 488 378 196 493 minecraft:black_concrete
fill 377 196 496 378 196 501 minecraft:black_concrete
fill 377 196 504 382 197 504 minecraft:black_concrete
fill 378 196 465 378 196 471 minecraft:black_concrete
setblock 378 196 478 minecraft:black_concrete
setblock 378 196 479 minecraft:sea_lantern
setblock 378 196 481 minecraft:sea_lantern
setblock 378 196 483 minecraft:sea_lantern
setblock 378 196 485 minecraft:sea_lantern
fill 378 196 486 378 196 487 minecraft:black_concrete
fill 378 196 494 378 196 495 minecraft:black_concrete
fill 378 196 502 378 196 503 minecraft:black_concrete
fill 379 196 465 416 196 465 minecraft:black_concrete
setblock 379 196 480 minecraft:sea_lantern
setblock 379 196 482 minecraft:sea_lantern
setblock 379 196 484 minecraft:sea_lantern
fill 379 196 503 417 196 503 minecraft:black_concrete
fill 380 196 464 385 197 464 minecraft:black_concrete
setblock 380 196 479 minecraft:sea_lantern
setblock 380 196 481 minecraft:sea_lantern
setblock 380 196 483 minecraft:sea_lantern
setblock 380 196 485 minecraft:sea_lantern
setblock 381 196 480 minecraft:sea_lantern
setblock 381 196 482 minecraft:sea_lantern
setblock 381 196 484 minecraft:sea_lantern
setblock 382 196 479 minecraft:sea_lantern
setblock 382 196 481 minecraft:sea_lantern
setblock 382 196 483 minecraft:sea_lantern
setblock 382 196 485 minecraft:sea_lantern
fill 385 196 504 390 197 504 minecraft:black_concrete
fill 388 196 464 393 197 464 minecraft:black_concrete
fill 393 196 504 398 197 504 minecraft:black_concrete
fill 396 196 464 401 197 464 minecraft:black_concrete
fill 401 196 504 406 197 504 minecraft:black_concrete
fill 404 196 464 409 197 464 minecraft:black_concrete
fill 409 196 504 414 197 504 minecraft:black_concrete
fill 412 196 464 417 197 464 minecraft:black_concrete
fill 416 196 466 416 196 502 minecraft:black_concrete
fill 417 196 467 417 197 472 minecraft:black_concrete
fill 417 196 475 417 197 480 minecraft:black_concrete
fill 417 196 483 417 197 488 minecraft:black_concrete
fill 417 196 491 417 197 496 minecraft:black_concrete
fill 417 196 499 417 197 502 minecraft:black_concrete
fill 417 196 504 417 197 504 minecraft:black_concrete
fill 377 197 472 377 197 477 minecraft:black_concrete
fill 377 197 480 377 198 480 minecraft:black_concrete
fill 377 197 482 377 198 482 minecraft:black_concrete
fill 377 197 484 377 198 484 minecraft:black_concrete
fill 377 197 488 377 197 493 minecraft:black_concrete
fill 377 197 496 377 197 501 minecraft:black_concrete
fill 378 197 479 378 198 479 minecraft:black_concrete
fill 378 197 481 378 198 481 minecraft:black_concrete
fill 378 197 483 378 198 483 minecraft:black_concrete
fill 378 197 485 378 198 485 minecraft:black_concrete
fill 379 197 480 379 198 480 minecraft:black_concrete
fill 379 197 482 379 198 482 minecraft:black_concrete
fill 379 197 484 379 198 484 minecraft:black_concrete
fill 380 197 479 380 198 479 minecraft:black_concrete
fill 380 197 481 380 198 481 minecraft:black_concrete
fill 380 197 483 380 198 483 minecraft:black_concrete
fill 380 197 485 380 198 485 minecraft:black_concrete
fill 381 197 480 381 198 480 minecraft:black_concrete
fill 381 197 482 381 198 482 minecraft:black_concrete
fill 381 197 484 381 198 484 minecraft:black_concrete
fill 382 197 479 382 198 479 minecraft:black_concrete
fill 382 197 481 382 198 481 minecraft:black_concrete
fill 382 197 483 382 198 483 minecraft:black_concrete
fill 382 197 485 382 198 485 minecraft:black_concrete
setblock 417 197 503 minecraft:black_concrete
setblock 377 199 480 minecraft:sea_lantern
setblock 377 199 482 minecraft:sea_lantern
setblock 377 199 484 minecraft:sea_lantern
setblock 378 199 479 minecraft:sea_lantern
setblock 378 199 481 minecraft:sea_lantern
setblock 378 199 483 minecraft:sea_lantern
setblock 378 199 485 minecraft:sea_lantern
setblock 379 199 480 minecraft:sea_lantern
setblock 379 199 482 minecraft:sea_lantern
setblock 379 199 484 minecraft:sea_lantern
setblock 380 199 479 minecraft:sea_lantern
setblock 380 199 481 minecraft:sea_lantern
setblock 380 199 483 minecraft:sea_lantern
setblock 380 199 485 minecraft:sea_lantern
setblock 381 199 480 minecraft:sea_lantern
setblock 381 199 482 minecraft:sea_lantern
setblock 381 199 484 minecraft:sea_lantern
setblock 382 199 479 minecraft:sea_lantern
setblock 382 199 481 minecraft:sea_lantern
setblock 382 199 483 minecraft:sea_lantern
setblock 382 199 485 minecraft:sea_lantern
fill 385 199 487 387 199 487 minecraft:glowstone
setblock 386 199 486 minecraft:glowstone
setblock 386 199 488 minecraft:glowstone
fill 389 199 477 390 199 478 minecraft:glowstone
fill 389 199 496 390 199 497 minecraft:glowstone
setblock 390 199 479 minecraft:glowstone
setblock 390 199 495 minecraft:glowstone
setblock 391 199 478 minecraft:glowstone
setblock 391 199 496 minecraft:glowstone
fill 398 199 474 400 199 474 minecraft:glowstone
fill 398 199 500 400 199 500 minecraft:glowstone
setblock 399 199 473 minecraft:glowstone
setblock 399 199 475 minecraft:glowstone
setblock 399 199 499 minecraft:glowstone
setblock 399 199 501 minecraft:glowstone
fill 407 199 478 409 199 478 minecraft:glowstone
fill 407 199 496 409 199 496 minecraft:glowstone
fill 408 199 477 409 199 477 minecraft:glowstone
setblock 408 199 479 minecraft:glowstone
setblock 408 199 495 minecraft:glowstone
fill 408 199 497 409 199 497 minecraft:glowstone
fill 411 199 487 413 199 487 minecraft:glowstone
setblock 412 199 486 minecraft:glowstone
setblock 412 199 488 minecraft:glowstone
fill 376 200 468 376 205 468 minecraft:sea_lantern
fill 376 200 476 376 205 476 minecraft:sea_lantern
fill 376 200 484 376 205 484 minecraft:sea_lantern
fill 376 200 492 376 205 492 minecraft:sea_lantern
fill 376 200 500 376 205 500 minecraft:sea_lantern
fill 377 200 480 377 201 480 minecraft:black_concrete
fill 377 200 482 377 201 482 minecraft:black_concrete
fill 377 200 484 377 201 484 minecraft:black_concrete
fill 378 200 479 378 201 479 minecraft:black_concrete
fill 378 200 481 378 201 481 minecraft:black_concrete
fill 378 200 483 378 201 483 minecraft:black_concrete
fill 378 200 485 378 201 485 minecraft:black_concrete
setblock 379 200 466 minecraft:light[level=14]
setblock 379 200 474 minecraft:light[level=14]
fill 379 200 480 379 201 480 minecraft:black_concrete
fill 379 200 482 379 201 482 minecraft:black_concrete
fill 379 200 484 379 201 484 minecraft:black_concrete
setblock 379 200 490 minecraft:light[level=14]
setblock 379 200 498 minecraft:light[level=14]
fill 379 200 505 379 205 505 minecraft:sea_lantern
fill 380 200 479 380 201 479 minecraft:black_concrete
fill 380 200 481 380 201 481 minecraft:black_concrete
fill 380 200 483 380 201 483 minecraft:black_concrete
schedule function dropper:buildpart/116_2 1t
