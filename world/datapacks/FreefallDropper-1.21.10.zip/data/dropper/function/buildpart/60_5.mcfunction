fill 18 245 298 18 246 299 minecraft:red_nether_bricks
setblock 19 245 281 minecraft:nether_wart_block
fill 19 245 289 19 246 289 minecraft:red_nether_bricks
fill 19 245 299 19 246 299 minecraft:red_nether_bricks
fill 20 245 287 24 245 287 minecraft:red_nether_bricks
fill 20 245 301 24 245 301 minecraft:red_nether_bricks
setblock 25 245 287 minecraft:black_concrete
setblock 25 245 301 minecraft:black_concrete
setblock 26 245 287 minecraft:red_nether_bricks
setblock 26 245 301 minecraft:red_nether_bricks
fill 27 245 289 27 246 289 minecraft:red_nether_bricks
fill 27 245 299 27 246 299 minecraft:red_nether_bricks
fill 28 245 290 28 246 290 minecraft:red_nether_bricks
fill 28 245 298 28 246 298 minecraft:red_nether_bricks
fill 29 245 291 29 247 291 minecraft:red_nether_bricks
fill 29 245 297 29 247 297 minecraft:red_nether_bricks
setblock 3 246 278 minecraft:light[level=12]
fill 3 246 285 3 246 286 minecraft:light[level=12]
setblock 3 246 292 minecraft:light[level=12]
setblock 3 246 294 minecraft:light[level=12]
setblock 3 246 299 minecraft:light[level=12]
setblock 3 246 302 minecraft:light[level=12]
setblock 3 246 306 minecraft:light[level=12]
setblock 3 246 310 minecraft:light[level=12]
setblock 3 246 313 minecraft:light[level=12]
setblock 8 246 285 minecraft:nether_wart_block
fill 8 246 286 9 247 288 minecraft:orange_terracotta
fill 9 246 284 9 247 284 minecraft:red_nether_bricks
fill 10 246 278 11 246 278 minecraft:light[level=12]
setblock 10 246 283 minecraft:nether_wart_block
fill 10 246 287 10 247 287 minecraft:orange_terracotta
setblock 10 246 292 minecraft:light[level=12]
setblock 10 246 299 minecraft:light[level=12]
setblock 10 246 306 minecraft:light[level=12]
setblock 10 246 313 minecraft:light[level=12]
setblock 11 246 283 minecraft:red_nether_bricks
fill 11 246 284 11 246 285 minecraft:orange_terracotta
setblock 11 246 287 minecraft:red_nether_bricks
setblock 11 246 294 minecraft:light[level=12]
setblock 11 246 302 minecraft:light[level=12]
setblock 11 246 310 minecraft:light[level=12]
setblock 12 246 281 minecraft:nether_wart_block
fill 12 246 282 12 247 282 minecraft:red_nether_bricks
setblock 12 246 284 minecraft:orange_terracotta
setblock 12 246 285 minecraft:nether_wart_block
fill 12 246 286 12 248 286 minecraft:red_nether_bricks
setblock 13 246 282 minecraft:nether_wart_block
fill 13 246 283 13 249 283 minecraft:bone_block
setblock 13 246 286 minecraft:nether_wart_block
fill 14 246 282 16 246 282 minecraft:red_nether_bricks
setblock 14 246 283 minecraft:nether_wart_block
fill 14 246 284 14 247 284 minecraft:red_nether_bricks
setblock 15 246 281 minecraft:red_nether_bricks
fill 15 246 283 16 246 283 minecraft:red_nether_bricks
setblock 15 246 284 minecraft:nether_wart_block
fill 15 246 292 16 246 296 minecraft:red_nether_bricks
setblock 16 246 281 minecraft:nether_wart_block
fill 16 246 290 17 246 290 minecraft:red_nether_bricks
fill 16 246 298 17 246 298 minecraft:red_nether_bricks
setblock 17 246 278 minecraft:light[level=12]
setblock 17 246 281 minecraft:red_nether_bricks
setblock 17 246 282 minecraft:nether_wart_block
setblock 17 246 285 minecraft:light[level=12]
setblock 17 246 292 minecraft:red_nether_bricks
setblock 17 246 296 minecraft:red_nether_bricks
setblock 17 246 306 minecraft:light[level=12]
setblock 17 246 313 minecraft:light[level=12]
setblock 19 246 278 minecraft:light[level=12]
setblock 19 246 286 minecraft:light[level=12]
setblock 19 246 302 minecraft:light[level=12]
setblock 19 246 310 minecraft:light[level=12]
fill 22 246 287 24 246 287 minecraft:red_nether_bricks
fill 22 246 301 24 246 301 minecraft:red_nether_bricks
setblock 24 246 278 minecraft:light[level=12]
setblock 24 246 285 minecraft:light[level=12]
setblock 24 246 306 minecraft:light[level=12]
setblock 24 246 313 minecraft:light[level=12]
fill 25 246 286 28 246 286 minecraft:black_concrete
fill 25 246 302 28 246 302 minecraft:black_concrete
setblock 27 246 278 minecraft:light[level=12]
setblock 27 246 310 minecraft:light[level=12]
fill 29 246 292 30 246 292 minecraft:red_nether_bricks
fill 29 246 296 30 246 296 minecraft:red_nether_bricks
fill 30 246 293 30 247 295 minecraft:red_nether_bricks
setblock 31 246 278 minecraft:light[level=12]
setblock 31 246 285 minecraft:light[level=12]
setblock 31 246 299 minecraft:light[level=12]
setblock 31 246 306 minecraft:light[level=12]
setblock 31 246 313 minecraft:light[level=12]
setblock 35 246 278 minecraft:light[level=12]
setblock 35 246 286 minecraft:light[level=12]
setblock 35 246 294 minecraft:light[level=12]
setblock 35 246 302 minecraft:light[level=12]
setblock 35 246 310 minecraft:light[level=12]
setblock 38 246 278 minecraft:light[level=12]
setblock 38 246 285 minecraft:light[level=12]
setblock 38 246 292 minecraft:light[level=12]
setblock 38 246 299 minecraft:light[level=12]
setblock 38 246 306 minecraft:light[level=12]
setblock 38 246 313 minecraft:light[level=12]
setblock 0 247 304 minecraft:purple_concrete
setblock 7 247 286 minecraft:red_nether_bricks
setblock 7 247 287 minecraft:nether_wart_block
setblock 7 247 288 minecraft:orange_terracotta
setblock 7 247 289 minecraft:red_nether_bricks
setblock 8 247 284 minecraft:nether_wart_block
fill 8 247 285 8 249 285 minecraft:red_nether_bricks
fill 8 247 289 8 249 289 minecraft:orange_terracotta
fill 9 247 275 10 308 275 minecraft:deepslate_tiles
fill 9 247 283 10 247 283 minecraft:red_nether_bricks
setblock 9 247 285 minecraft:nether_wart_block
setblock 9 247 289 minecraft:nether_wart_block
fill 10 247 284 11 247 285 minecraft:red_nether_bricks
setblock 10 247 286 minecraft:nether_wart_block
fill 10 247 288 11 248 288 minecraft:red_nether_bricks
setblock 11 247 275 minecraft:magma_block
setblock 11 247 283 minecraft:nether_wart_block
setblock 11 247 286 minecraft:red_nether_bricks
setblock 11 247 287 minecraft:nether_wart_block
fill 12 247 275 16 276 275 minecraft:deepslate_tiles
setblock 12 247 284 minecraft:nether_wart_block
fill 12 247 285 12 249 285 minecraft:red_nether_bricks
setblock 12 247 287 minecraft:red_nether_bricks
setblock 13 247 281 minecraft:nether_wart_block
setblock 13 247 282 minecraft:red_nether_bricks
setblock 13 247 285 minecraft:nether_wart_block
setblock 13 247 286 minecraft:red_nether_bricks
setblock 14 247 282 minecraft:nether_wart_block
setblock 14 247 283 minecraft:red_nether_bricks
setblock 15 247 282 minecraft:red_nether_bricks
setblock 15 247 283 minecraft:nether_wart_block
fill 15 247 294 16 247 294 minecraft:red_nether_bricks
fill 16 247 291 16 247 293 minecraft:red_nether_bricks
fill 16 247 295 16 247 297 minecraft:red_nether_bricks
fill 17 247 290 17 247 291 minecraft:red_nether_bricks
fill 17 247 297 17 247 298 minecraft:red_nether_bricks
setblock 18 247 299 minecraft:red_nether_bricks
setblock 21 247 317 minecraft:purple_concrete
setblock 25 247 286 minecraft:black_concrete
setblock 25 247 302 minecraft:black_concrete
fill 26 247 285 30 247 285 minecraft:black_concrete
fill 26 247 303 30 247 303 minecraft:black_concrete
fill 29 247 284 31 247 284 minecraft:black_concrete
fill 29 247 304 31 247 304 minecraft:black_concrete
setblock 30 247 292 minecraft:red_nether_bricks
setblock 30 247 296 minecraft:red_nether_bricks
setblock 31 247 294 minecraft:red_nether_bricks
setblock 33 247 317 minecraft:purple_concrete
fill 34 247 317 35 267 317 minecraft:deepslate_tiles
fill 0 248 304 0 272 304 minecraft:deepslate_tiles
fill 6 248 287 7 248 288 minecraft:red_nether_bricks
setblock 6 248 289 minecraft:nether_wart_block
fill 6 248 290 7 249 291 minecraft:orange_terracotta
setblock 7 248 286 minecraft:nether_wart_block
fill 7 248 289 7 249 289 minecraft:orange_terracotta
setblock 8 248 284 minecraft:red_nether_bricks
fill 8 248 286 10 248 286 minecraft:red_nether_bricks
fill 8 248 287 9 248 288 minecraft:orange_terracotta
fill 8 248 290 8 249 290 minecraft:orange_terracotta
setblock 8 248 291 minecraft:nether_wart_block
setblock 9 248 284 minecraft:nether_wart_block
fill 9 248 285 9 250 285 minecraft:red_nether_bricks
fill 9 248 289 9 249 290 minecraft:red_nether_bricks
fill 10 248 283 11 248 284 minecraft:red_nether_bricks
setblock 10 248 285 minecraft:nether_wart_block
fill 10 248 287 11 249 287 minecraft:red_nether_bricks
setblock 10 248 289 minecraft:nether_wart_block
fill 11 248 275 11 282 275 minecraft:deepslate_tiles
setblock 11 248 285 minecraft:red_nether_bricks
setblock 11 248 286 minecraft:nether_wart_block
setblock 12 248 282 minecraft:gold_block
setblock 12 248 283 minecraft:nether_wart_block
fill 12 248 284 12 249 284 minecraft:red_nether_bricks
setblock 12 248 287 minecraft:nether_wart_block
setblock 13 248 284 minecraft:nether_wart_block
setblock 13 248 285 minecraft:red_nether_bricks
fill 21 248 317 21 308 317 minecraft:deepslate_tiles
setblock 25 248 285 minecraft:black_concrete
setblock 25 248 303 minecraft:black_concrete
setblock 26 248 284 minecraft:black_concrete
setblock 26 248 304 minecraft:black_concrete
fill 28 248 284 29 248 284 minecraft:black_concrete
fill 28 248 304 29 248 304 minecraft:black_concrete
setblock 30 248 283 minecraft:black_concrete
setblock 30 248 305 minecraft:black_concrete
setblock 33 248 283 minecraft:black_concrete
setblock 33 248 305 minecraft:black_concrete
fill 33 248 317 33 308 317 minecraft:deepslate_tiles
fill 2 249 298 3 250 298 minecraft:raw_gold_block
fill 5 249 289 5 249 290 minecraft:red_nether_bricks
setblock 5 249 291 minecraft:nether_wart_block
fill 5 249 292 5 251 292 minecraft:red_nether_bricks
fill 6 249 287 8 249 287 minecraft:red_nether_bricks
setblock 6 249 288 minecraft:nether_wart_block
fill 6 249 289 6 251 289 minecraft:red_nether_bricks
fill 6 249 292 6 250 293 minecraft:orange_terracotta
fill 7 249 286 7 250 286 minecraft:red_nether_bricks
setblock 7 249 288 minecraft:red_nether_bricks
setblock 7 249 292 minecraft:orange_terracotta
setblock 7 249 293 minecraft:nether_wart_block
setblock 8 249 286 minecraft:nether_wart_block
fill 8 249 288 8 252 288 minecraft:bone_block
setblock 8 249 291 minecraft:orange_terracotta
fill 8 249 292 8 250 292 minecraft:red_nether_bricks
setblock 9 249 284 minecraft:red_nether_bricks
fill 9 249 286 11 249 286 minecraft:red_nether_bricks
setblock 9 249 287 minecraft:nether_wart_block
fill 9 249 288 9 251 288 minecraft:red_nether_bricks
setblock 9 249 291 minecraft:nether_wart_block
setblock 10 249 284 minecraft:nether_wart_block
fill 10 249 285 10 250 285 minecraft:red_nether_bricks
setblock 10 249 288 minecraft:nether_wart_block
fill 10 249 289 10 250 289 minecraft:red_nether_bricks
setblock 11 249 284 minecraft:red_nether_bricks
setblock 11 249 285 minecraft:nether_wart_block
setblock 11 249 288 minecraft:red_nether_bricks
setblock 12 249 286 minecraft:nether_wart_block
fill 22 249 317 23 271 317 minecraft:deepslate_tiles
setblock 24 249 317 minecraft:purple_concrete
fill 25 249 284 25 250 284 minecraft:black_concrete
fill 25 249 304 25 250 304 minecraft:black_concrete
fill 25 249 317 25 308 317 minecraft:deepslate_tiles
fill 27 249 283 27 250 283 minecraft:black_concrete
fill 27 249 305 27 250 305 minecraft:black_concrete
setblock 29 249 283 minecraft:black_concrete
setblock 29 249 305 minecraft:black_concrete
fill 31 249 282 32 249 282 minecraft:black_concrete
fill 31 249 306 32 249 306 minecraft:black_concrete
fill 35 249 282 36 249 282 minecraft:black_concrete
fill 35 249 306 36 249 306 minecraft:black_concrete
fill 36 249 281 37 249 281 minecraft:black_concrete
fill 36 249 307 37 249 307 minecraft:black_concrete
setblock 5 250 289 minecraft:red_nether_bricks
setblock 5 250 290 minecraft:nether_wart_block
fill 5 250 291 5 252 291 minecraft:red_nether_bricks
fill 5 250 293 5 251 295 minecraft:orange_terracotta
setblock 6 250 287 minecraft:nether_wart_block
fill 6 250 288 6 251 288 minecraft:red_nether_bricks
setblock 6 250 290 minecraft:red_nether_bricks
fill 6 250 291 7 250 291 minecraft:orange_terracotta
fill 6 250 294 6 252 295 minecraft:orange_terracotta
fill 7 250 287 9 250 287 minecraft:red_nether_bricks
setblock 7 250 288 minecraft:nether_wart_block
fill 7 250 289 7 252 289 minecraft:red_nether_bricks
setblock 7 250 290 minecraft:orange_terracotta
setblock 7 250 292 minecraft:nether_wart_block
fill 7 250 293 7 251 294 minecraft:orange_terracotta
setblock 8 250 286 minecraft:red_nether_bricks
setblock 8 250 289 minecraft:nether_wart_block
fill 8 250 290 8 251 291 minecraft:red_nether_bricks
setblock 8 250 293 minecraft:nether_wart_block
setblock 9 250 286 minecraft:nether_wart_block
setblock 9 250 289 minecraft:red_nether_bricks
setblock 9 250 290 minecraft:nether_wart_block
fill 9 250 291 9 251 291 minecraft:red_nether_bricks
setblock 10 250 286 minecraft:red_nether_bricks
setblock 10 250 287 minecraft:nether_wart_block
setblock 10 250 288 minecraft:red_nether_bricks
fill 24 250 317 24 308 317 minecraft:deepslate_tiles
fill 25 250 283 25 251 283 minecraft:black_concrete
fill 25 250 305 25 251 305 minecraft:black_concrete
fill 27 250 282 27 251 282 minecraft:black_concrete
fill 27 250 306 27 251 306 minecraft:black_concrete
fill 28 250 288 28 251 288 minecraft:blackstone
fill 28 250 300 28 251 300 minecraft:blackstone
fill 30 250 282 30 251 282 minecraft:black_concrete
fill 30 250 306 30 251 306 minecraft:black_concrete
setblock 33 250 281 minecraft:black_concrete
setblock 33 250 307 minecraft:black_concrete
fill 34 250 280 34 251 280 minecraft:black_concrete
fill 34 250 308 34 251 308 minecraft:black_concrete
setblock 37 250 281 minecraft:black_concrete
setblock 37 250 307 minecraft:black_concrete
setblock 4 251 291 minecraft:red_nether_bricks
setblock 4 251 292 minecraft:nether_wart_block
fill 4 251 293 4 251 295 minecraft:red_nether_bricks
setblock 5 251 289 minecraft:nether_wart_block
fill 5 251 290 5 252 290 minecraft:red_nether_bricks
setblock 5 251 296 minecraft:red_nether_bricks
fill 5 251 297 6 253 297 minecraft:orange_terracotta
setblock 6 251 290 minecraft:nether_wart_block
fill 6 251 291 6 252 292 minecraft:red_nether_bricks
setblock 6 251 293 minecraft:orange_terracotta
fill 6 251 296 6 253 296 minecraft:orange_terracotta
setblock 7 251 287 minecraft:nether_wart_block
setblock 7 251 288 minecraft:red_nether_bricks
setblock 7 251 290 minecraft:red_nether_bricks
setblock 7 251 291 minecraft:nether_wart_block
fill 7 251 292 7 253 292 minecraft:red_nether_bricks
setblock 7 251 295 minecraft:orange_terracotta
setblock 7 251 296 minecraft:red_nether_bricks
fill 8 251 287 9 251 287 minecraft:red_nether_bricks
fill 8 251 289 8 252 289 minecraft:red_nether_bricks
setblock 8 251 292 minecraft:nether_wart_block
fill 8 251 293 8 252 294 minecraft:red_nether_bricks
setblock 9 251 289 minecraft:nether_wart_block
setblock 9 251 290 minecraft:red_nether_bricks
setblock 9 251 292 minecraft:red_nether_bricks
fill 29 251 288 29 253 288 minecraft:blackstone
fill 29 251 300 29 253 300 minecraft:blackstone
fill 31 251 281 31 252 281 minecraft:black_concrete
fill 31 251 307 31 252 307 minecraft:black_concrete
setblock 42 251 280 minecraft:magma_block
setblock 0 252 277 minecraft:magma_block
fill 3 252 278 3 253 278 minecraft:light[level=12]
setblock 3 252 285 minecraft:light[level=12]
setblock 3 252 292 minecraft:light[level=12]
setblock 3 252 299 minecraft:light[level=12]
setblock 3 252 306 minecraft:light[level=12]
setblock 3 252 313 minecraft:light[level=12]
fill 4 252 292 4 252 294 minecraft:red_nether_bricks
setblock 4 252 295 minecraft:nether_wart_block
fill 4 252 296 4 253 297 minecraft:red_nether_bricks
setblock 5 252 292 minecraft:nether_wart_block
fill 5 252 293 5 252 295 minecraft:red_nether_bricks
setblock 5 252 296 minecraft:orange_terracotta
fill 5 252 298 7 253 298 minecraft:orange_terracotta
setblock 6 252 289 minecraft:nether_wart_block
fill 6 252 290 6 253 290 minecraft:red_nether_bricks
setblock 6 252 293 minecraft:nether_wart_block
fill 6 252 299 6 254 299 minecraft:orange_terracotta
setblock 7 252 290 minecraft:nether_wart_block
fill 7 252 291 7 253 291 minecraft:red_nether_bricks
setblock 7 252 293 minecraft:red_nether_bricks
setblock 7 252 294 minecraft:nether_wart_block
fill 7 252 295 7 254 295 minecraft:red_nether_bricks
fill 7 252 296 7 252 297 minecraft:orange_terracotta
setblock 8 252 290 minecraft:red_nether_bricks
setblock 8 252 291 minecraft:nether_wart_block
fill 8 252 292 8 253 292 minecraft:red_nether_bricks
setblock 8 252 295 minecraft:nether_wart_block
fill 8 252 296 8 254 296 minecraft:red_nether_bricks
setblock 10 252 278 minecraft:light[level=12]
setblock 10 252 285 minecraft:light[level=12]
setblock 10 252 292 minecraft:light[level=12]
setblock 10 252 299 minecraft:light[level=12]
setblock 10 252 306 minecraft:light[level=12]
setblock 10 252 313 minecraft:light[level=12]
setblock 17 252 278 minecraft:light[level=12]
setblock 17 252 285 minecraft:light[level=12]
setblock 17 252 306 minecraft:light[level=12]
setblock 17 252 313 minecraft:light[level=12]
fill 17 252 317 17 308 317 minecraft:deepslate_tiles
setblock 18 252 317 minecraft:crying_obsidian
setblock 24 252 278 minecraft:light[level=12]
setblock 24 252 285 minecraft:light[level=12]
setblock 24 252 306 minecraft:light[level=12]
setblock 24 252 313 minecraft:light[level=12]
setblock 25 252 282 minecraft:black_concrete
setblock 25 252 306 minecraft:black_concrete
fill 28 252 280 28 252 281 minecraft:black_concrete
fill 28 252 287 29 252 287 minecraft:blackstone
fill 28 252 301 29 252 301 minecraft:blackstone
fill 28 252 307 28 252 308 minecraft:black_concrete
setblock 31 252 278 minecraft:light[level=12]
setblock 31 252 285 minecraft:light[level=12]
setblock 31 252 292 minecraft:light[level=12]
setblock 31 252 299 minecraft:light[level=12]
setblock 31 252 306 minecraft:light[level=12]
setblock 31 252 313 minecraft:light[level=12]
setblock 38 252 278 minecraft:light[level=12]
setblock 38 252 285 minecraft:light[level=12]
setblock 38 252 292 minecraft:light[level=12]
setblock 38 252 299 minecraft:light[level=12]
setblock 38 252 306 minecraft:light[level=12]
setblock 38 252 313 minecraft:light[level=12]
fill 42 252 280 42 308 280 minecraft:deepslate_tiles
fill 42 252 290 42 299 292 minecraft:deepslate_tiles
setblock 42 252 293 minecraft:crying_obsidian
fill 42 252 294 42 308 294 minecraft:deepslate_tiles
setblock 42 252 299 minecraft:purple_concrete
fill 0 253 277 0 308 277 minecraft:deepslate_tiles
setblock 3 253 286 minecraft:light[level=12]
setblock 3 253 294 minecraft:light[level=12]
setblock 3 253 302 minecraft:light[level=12]
setblock 3 253 310 minecraft:light[level=12]
fill 4 253 293 6 253 293 minecraft:red_nether_bricks
setblock 4 253 294 minecraft:nether_wart_block
fill 4 253 295 4 254 295 minecraft:red_nether_bricks
setblock 4 253 298 minecraft:nether_wart_block
fill 4 253 299 4 255 299 minecraft:red_nether_bricks
setblock 5 253 291 minecraft:nether_wart_block
setblock 5 253 292 minecraft:red_nether_bricks
setblock 5 253 294 minecraft:red_nether_bricks
setblock 5 253 295 minecraft:nether_wart_block
fill 5 253 296 5 255 296 minecraft:red_nether_bricks
setblock 5 253 299 minecraft:nether_wart_block
fill 5 253 300 5 255 300 minecraft:red_nether_bricks
setblock 6 253 291 minecraft:red_nether_bricks
setblock 6 253 292 minecraft:nether_wart_block
fill 6 253 294 6 255 295 minecraft:bone_block
fill 6 253 300 7 255 301 minecraft:orange_terracotta
setblock 7 253 290 minecraft:red_nether_bricks
setblock 7 253 293 minecraft:nether_wart_block
fill 7 253 294 7 254 294 minecraft:red_nether_bricks
setblock 7 253 296 minecraft:red_nether_bricks
setblock 7 253 297 minecraft:orange_terracotta
fill 7 253 299 8 253 299 minecraft:red_nether_bricks
setblock 8 253 291 minecraft:red_nether_bricks
setblock 8 253 293 minecraft:red_nether_bricks
setblock 8 253 294 minecraft:nether_wart_block
fill 8 253 295 8 254 295 minecraft:red_nether_bricks
setblock 8 253 297 minecraft:red_nether_bricks
setblock 8 253 298 minecraft:nether_wart_block
setblock 11 253 278 minecraft:light[level=12]
setblock 11 253 286 minecraft:light[level=12]
setblock 11 253 294 minecraft:light[level=12]
setblock 11 253 302 minecraft:light[level=12]
setblock 11 253 310 minecraft:light[level=12]
fill 18 253 317 18 308 317 minecraft:deepslate_tiles
setblock 19 253 278 minecraft:light[level=12]
setblock 19 253 286 minecraft:light[level=12]
setblock 19 253 302 minecraft:light[level=12]
setblock 19 253 310 minecraft:light[level=12]
fill 25 253 281 25 254 281 minecraft:black_concrete
fill 25 253 307 25 254 307 minecraft:black_concrete
setblock 27 253 278 minecraft:light[level=12]
setblock 27 253 286 minecraft:light[level=12]
setblock 27 253 302 minecraft:light[level=12]
setblock 27 253 310 minecraft:light[level=12]
setblock 28 253 280 minecraft:black_concrete
setblock 28 253 308 minecraft:black_concrete
fill 29 253 287 30 254 287 minecraft:blackstone
fill 29 253 301 30 254 301 minecraft:blackstone
fill 30 253 288 30 254 288 minecraft:blackstone
fill 30 253 300 30 254 300 minecraft:blackstone
setblock 35 253 278 minecraft:light[level=12]
setblock 35 253 286 minecraft:light[level=12]
setblock 35 253 294 minecraft:light[level=12]
setblock 35 253 302 minecraft:light[level=12]
setblock 35 253 310 minecraft:light[level=12]
fill 42 253 293 42 308 293 minecraft:deepslate_tiles
fill 42 253 295 42 308 295 minecraft:deepslate_tiles
setblock 42 253 296 minecraft:crying_obsidian
fill 42 253 297 42 254 299 minecraft:deepslate_tiles
setblock 4 254 294 minecraft:red_nether_bricks
setblock 4 254 296 minecraft:red_nether_bricks
setblock 4 254 297 minecraft:nether_wart_block
fill 4 254 298 4 256 298 minecraft:red_nether_bricks
setblock 4 254 300 minecraft:red_nether_bricks
fill 5 254 293 7 254 293 minecraft:red_nether_bricks
setblock 5 254 294 minecraft:nether_wart_block
fill 5 254 295 5 255 295 minecraft:red_nether_bricks
fill 5 254 297 7 254 297 minecraft:red_nether_bricks
setblock 5 254 298 minecraft:nether_wart_block
fill 5 254 299 5 256 299 minecraft:red_nether_bricks
setblock 5 254 301 minecraft:red_nether_bricks
setblock 6 254 292 minecraft:red_nether_bricks
fill 6 254 296 6 256 296 minecraft:red_nether_bricks
setblock 6 254 298 minecraft:orange_terracotta
fill 6 254 302 7 255 302 minecraft:orange_terracotta
setblock 7 254 296 minecraft:nether_wart_block
fill 7 254 298 8 255 298 minecraft:red_nether_bricks
setblock 7 254 299 minecraft:orange_terracotta
setblock 7 254 303 minecraft:red_nether_bricks
setblock 8 254 297 minecraft:nether_wart_block
fill 8 254 299 8 254 300 minecraft:red_nether_bricks
fill 8 254 301 8 255 301 minecraft:orange_terracotta
fill 8 254 302 8 256 302 minecraft:red_nether_bricks
fill 30 254 286 31 255 286 minecraft:blackstone
fill 30 254 302 31 255 302 minecraft:blackstone
fill 31 254 287 31 255 287 minecraft:blackstone
fill 31 254 301 31 255 301 minecraft:blackstone
fill 42 254 296 42 308 296 minecraft:deepslate_tiles
fill 42 254 312 42 308 312 minecraft:deepslate_tiles
setblock 42 254 313 minecraft:crying_obsidian
setblock 0 255 299 minecraft:crying_obsidian
setblock 4 255 296 minecraft:nether_wart_block
setblock 4 255 297 minecraft:red_nether_bricks
setblock 4 255 300 minecraft:nether_wart_block
fill 4 255 301 4 256 301 minecraft:red_nether_bricks
setblock 5 255 294 minecraft:red_nether_bricks
setblock 5 255 297 minecraft:nether_wart_block
fill 5 255 298 5 256 298 minecraft:red_nether_bricks
setblock 5 255 301 minecraft:nether_wart_block
fill 5 255 302 5 257 302 minecraft:red_nether_bricks
fill 6 255 297 8 255 297 minecraft:red_nether_bricks
setblock 6 255 298 minecraft:nether_wart_block
fill 6 255 299 6 257 299 minecraft:red_nether_bricks
fill 6 255 303 6 256 304 minecraft:red_nether_bricks
setblock 7 255 295 minecraft:nether_wart_block
setblock 7 255 296 minecraft:red_nether_bricks
setblock 7 255 299 minecraft:nether_wart_block
fill 7 255 303 8 256 304 minecraft:orange_terracotta
setblock 8 255 299 minecraft:red_nether_bricks
setblock 8 255 300 minecraft:nether_wart_block
fill 8 255 305 8 257 305 minecraft:orange_terracotta
setblock 9 255 301 minecraft:nether_wart_block
fill 9 255 302 9 255 303 minecraft:red_nether_bricks
fill 9 255 304 9 257 304 minecraft:orange_terracotta
setblock 30 255 287 minecraft:blackstone
setblock 30 255 301 minecraft:blackstone
setblock 42 255 297 minecraft:crying_obsidian
fill 42 255 298 42 276 299 minecraft:deepslate_tiles
fill 42 255 313 42 308 313 minecraft:deepslate_tiles
setblock 0 256 289 minecraft:amethyst_block
fill 0 256 299 0 304 299 minecraft:deepslate_tiles
setblock 4 256 299 minecraft:nether_wart_block
setblock 4 256 300 minecraft:red_nether_bricks
setblock 5 256 296 minecraft:nether_wart_block
setblock 5 256 297 minecraft:red_nether_bricks
setblock 5 256 300 minecraft:nether_wart_block
fill 5 256 301 5 257 301 minecraft:red_nether_bricks
setblock 5 256 303 minecraft:red_nether_bricks
setblock 6 256 275 minecraft:magma_block
setblock 6 256 294 minecraft:bone_block
setblock 6 256 297 minecraft:nether_wart_block
fill 6 256 298 6 257 298 minecraft:red_nether_bricks
fill 6 256 300 8 256 300 minecraft:red_nether_bricks
setblock 6 256 301 minecraft:nether_wart_block
fill 6 256 302 6 258 302 minecraft:red_nether_bricks
setblock 7 256 297 minecraft:red_nether_bricks
setblock 7 256 298 minecraft:nether_wart_block
fill 7 256 299 7 257 299 minecraft:red_nether_bricks
fill 7 256 301 7 259 301 minecraft:bone_block
setblock 7 256 302 minecraft:nether_wart_block
setblock 7 256 305 minecraft:red_nether_bricks
setblock 8 256 298 minecraft:red_nether_bricks
setblock 8 256 299 minecraft:nether_wart_block
fill 8 256 301 9 257 301 minecraft:red_nether_bricks
fill 8 256 306 9 256 306 minecraft:red_nether_bricks
setblock 9 256 300 minecraft:nether_wart_block
fill 9 256 302 9 257 302 minecraft:red_nether_bricks
setblock 9 256 303 minecraft:orange_terracotta
fill 9 256 305 9 257 305 minecraft:orange_terracotta
fill 10 256 303 10 256 304 minecraft:red_nether_bricks
setblock 10 256 305 minecraft:nether_wart_block
setblock 31 256 286 minecraft:blackstone
setblock 31 256 302 minecraft:blackstone
fill 42 256 297 42 275 297 minecraft:deepslate_tiles
fill 0 257 289 0 308 289 minecraft:deepslate_tiles
setblock 5 257 299 minecraft:nether_wart_block
setblock 5 257 300 minecraft:red_nether_bricks
setblock 5 257 303 minecraft:nether_wart_block
fill 6 257 275 6 308 275 minecraft:deepslate_tiles
setblock 6 257 300 minecraft:nether_wart_block
fill 6 257 301 6 258 301 minecraft:red_nether_bricks
fill 6 257 303 8 257 303 minecraft:red_nether_bricks
setblock 6 257 304 minecraft:nether_wart_block
fill 6 257 305 6 258 305 minecraft:red_nether_bricks
setblock 7 257 298 minecraft:red_nether_bricks
fill 7 257 300 8 257 300 minecraft:red_nether_bricks
fill 7 257 302 7 259 302 minecraft:red_nether_bricks
setblock 7 257 304 minecraft:red_nether_bricks
setblock 7 257 305 minecraft:nether_wart_block
fill 7 257 306 7 259 306 minecraft:red_nether_bricks
setblock 8 257 299 minecraft:red_nether_bricks
setblock 8 257 302 minecraft:nether_wart_block
setblock 8 257 304 minecraft:orange_terracotta
setblock 8 257 306 minecraft:nether_wart_block
fill 8 257 307 8 259 307 minecraft:red_nether_bricks
setblock 9 257 303 minecraft:nether_wart_block
fill 9 257 306 11 258 307 minecraft:orange_terracotta
setblock 10 257 303 minecraft:red_nether_bricks
setblock 10 257 304 minecraft:nether_wart_block
setblock 10 257 305 minecraft:orange_terracotta
setblock 11 257 305 minecraft:nether_wart_block
fill 11 257 308 11 259 308 minecraft:orange_terracotta
setblock 22 257 275 minecraft:magma_block
fill 23 257 275 23 267 275 minecraft:deepslate_tiles
setblock 42 257 285 minecraft:crying_obsidian
setblock 3 258 278 minecraft:light[level=12]
setblock 3 258 285 minecraft:light[level=12]
setblock 3 258 292 minecraft:light[level=12]
setblock 3 258 299 minecraft:light[level=12]
setblock 3 258 306 minecraft:light[level=12]
setblock 3 258 313 minecraft:light[level=12]
setblock 5 258 302 minecraft:nether_wart_block
setblock 6 258 300 minecraft:red_nether_bricks
setblock 6 258 303 minecraft:nether_wart_block
fill 6 258 304 6 259 304 minecraft:red_nether_bricks
setblock 7 258 300 minecraft:nether_wart_block
fill 7 258 303 9 258 303 minecraft:red_nether_bricks
setblock 7 258 304 minecraft:nether_wart_block
fill 7 258 305 7 260 305 minecraft:red_nether_bricks
setblock 8 258 301 minecraft:nether_wart_block
fill 8 258 302 8 259 302 minecraft:red_nether_bricks
fill 8 258 304 10 258 304 minecraft:red_nether_bricks
setblock 8 258 305 minecraft:nether_wart_block
fill 8 258 306 8 260 306 minecraft:red_nether_bricks
setblock 9 258 302 minecraft:nether_wart_block
fill 9 258 305 11 258 305 minecraft:red_nether_bricks
fill 9 258 308 9 259 308 minecraft:red_nether_bricks
setblock 10 258 278 minecraft:light[level=12]
setblock 10 258 285 minecraft:light[level=12]
setblock 10 258 292 minecraft:light[level=12]
setblock 10 258 299 minecraft:light[level=12]
setblock 10 258 303 minecraft:nether_wart_block
setblock 10 258 308 minecraft:orange_terracotta
fill 10 258 309 11 259 309 minecraft:red_nether_bricks
setblock 10 258 313 minecraft:light[level=12]
setblock 11 258 304 minecraft:nether_wart_block
fill 12 258 306 12 260 306 minecraft:red_nether_bricks
setblock 12 258 307 minecraft:orange_terracotta
setblock 12 258 308 minecraft:red_nether_bricks
fill 12 258 309 13 260 309 minecraft:orange_terracotta
setblock 17 258 278 minecraft:light[level=12]
setblock 17 258 285 minecraft:light[level=12]
setblock 17 258 292 minecraft:light[level=12]
setblock 17 258 299 minecraft:light[level=12]
setblock 17 258 306 minecraft:light[level=12]
setblock 17 258 313 minecraft:light[level=12]
fill 22 258 275 22 299 275 minecraft:deepslate_tiles
setblock 24 258 278 minecraft:light[level=12]
setblock 24 258 285 minecraft:light[level=12]
setblock 24 258 292 minecraft:light[level=12]
setblock 24 258 299 minecraft:light[level=12]
setblock 24 258 306 minecraft:light[level=12]
setblock 24 258 313 minecraft:light[level=12]
setblock 31 258 278 minecraft:light[level=12]
setblock 31 258 285 minecraft:light[level=12]
setblock 31 258 292 minecraft:light[level=12]
setblock 31 258 299 minecraft:light[level=12]
setblock 31 258 306 minecraft:light[level=12]
setblock 31 258 313 minecraft:light[level=12]
setblock 38 258 278 minecraft:light[level=12]
setblock 38 258 285 minecraft:light[level=12]
setblock 38 258 292 minecraft:light[level=12]
setblock 38 258 299 minecraft:light[level=12]
setblock 38 258 306 minecraft:light[level=12]
setblock 38 258 313 minecraft:light[level=12]
fill 42 258 285 42 308 285 minecraft:deepslate_tiles
setblock 0 259 281 minecraft:amethyst_block
setblock 6 259 303 minecraft:red_nether_bricks
setblock 7 259 303 minecraft:nether_wart_block
setblock 7 259 304 minecraft:red_nether_bricks
fill 8 259 303 10 259 303 minecraft:red_nether_bricks
setblock 8 259 304 minecraft:nether_wart_block
fill 8 259 305 8 260 305 minecraft:red_nether_bricks
setblock 8 259 308 minecraft:nether_wart_block
setblock 9 259 302 minecraft:red_nether_bricks
fill 9 259 304 11 259 304 minecraft:red_nether_bricks
setblock 9 259 305 minecraft:nether_wart_block
fill 9 259 306 9 260 307 minecraft:red_nether_bricks
setblock 9 259 309 minecraft:nether_wart_block
fill 10 259 305 12 259 305 minecraft:red_nether_bricks
setblock 10 259 306 minecraft:nether_wart_block
fill 10 259 307 11 259 307 minecraft:orange_terracotta
fill 10 259 308 10 260 308 minecraft:red_nether_bricks
setblock 11 259 306 minecraft:red_nether_bricks
fill 11 259 310 12 259 310 minecraft:red_nether_bricks
fill 12 259 307 13 259 307 minecraft:red_nether_bricks
fill 12 259 308 13 260 308 minecraft:orange_terracotta
fill 13 259 306 13 261 306 minecraft:red_nether_bricks
fill 13 259 310 14 260 310 minecraft:orange_terracotta
setblock 14 259 308 minecraft:red_nether_bricks
fill 14 259 309 14 261 309 minecraft:orange_terracotta
fill 0 260 281 0 308 281 minecraft:deepslate_tiles
setblock 3 260 278 minecraft:light[level=12]
setblock 3 260 286 minecraft:light[level=12]
setblock 3 260 294 minecraft:light[level=12]
setblock 3 260 302 minecraft:light[level=12]
setblock 3 260 310 minecraft:light[level=12]
setblock 8 260 304 minecraft:red_nether_bricks
setblock 8 260 307 minecraft:nether_wart_block
setblock 9 260 304 minecraft:nether_wart_block
fill 9 260 305 9 261 305 minecraft:red_nether_bricks
setblock 9 260 308 minecraft:nether_wart_block
setblock 9 260 309 minecraft:red_nether_bricks
setblock 10 260 304 minecraft:red_nether_bricks
setblock 10 260 305 minecraft:nether_wart_block
fill 10 260 306 10 261 306 minecraft:red_nether_bricks
fill 10 260 307 11 263 307 minecraft:bone_block
setblock 10 260 309 minecraft:nether_wart_block
setblock 11 260 278 minecraft:light[level=12]
setblock 11 260 286 minecraft:light[level=12]
setblock 11 260 294 minecraft:light[level=12]
setblock 11 260 302 minecraft:light[level=12]
fill 11 260 305 12 260 305 minecraft:red_nether_bricks
setblock 11 260 306 minecraft:nether_wart_block
fill 11 260 308 11 260 309 minecraft:red_nether_bricks
setblock 11 260 310 minecraft:nether_wart_block
setblock 12 260 307 minecraft:nether_wart_block
setblock 12 260 310 minecraft:red_nether_bricks
setblock 12 260 311 minecraft:nether_wart_block
fill 13 260 307 14 260 307 minecraft:red_nether_bricks
fill 13 260 311 15 260 311 minecraft:red_nether_bricks
setblock 14 260 308 minecraft:orange_terracotta
fill 15 260 308 15 260 309 minecraft:red_nether_bricks
fill 15 260 310 16 262 310 minecraft:orange_terracotta
setblock 16 260 309 minecraft:red_nether_bricks
fill 16 260 311 16 262 311 minecraft:orange_terracotta
setblock 19 260 278 minecraft:light[level=12]
setblock 19 260 286 minecraft:light[level=12]
setblock 19 260 294 minecraft:light[level=12]
setblock 19 260 302 minecraft:light[level=12]
setblock 19 260 310 minecraft:light[level=12]
setblock 27 260 278 minecraft:light[level=12]
setblock 27 260 286 minecraft:light[level=12]
setblock 27 260 294 minecraft:light[level=12]
setblock 27 260 302 minecraft:light[level=12]
setblock 27 260 310 minecraft:light[level=12]
setblock 35 260 278 minecraft:light[level=12]
setblock 35 260 286 minecraft:light[level=12]
setblock 35 260 294 minecraft:light[level=12]
setblock 35 260 302 minecraft:light[level=12]
setblock 35 260 310 minecraft:light[level=12]
setblock 9 261 306 minecraft:red_nether_bricks
setblock 9 261 307 minecraft:nether_wart_block
setblock 9 261 308 minecraft:red_nether_bricks
setblock 10 261 305 minecraft:red_nether_bricks
setblock 10 261 308 minecraft:nether_wart_block
fill 10 261 309 10 262 309 minecraft:red_nether_bricks
setblock 11 261 305 minecraft:nether_wart_block
fill 11 261 306 11 262 306 minecraft:red_nether_bricks
fill 11 261 308 13 261 308 minecraft:red_nether_bricks
setblock 11 261 309 minecraft:nether_wart_block
fill 11 261 310 11 262 310 minecraft:red_nether_bricks
setblock 12 261 306 minecraft:nether_wart_block
fill 12 261 307 12 262 307 minecraft:red_nether_bricks
setblock 12 261 309 minecraft:red_nether_bricks
setblock 12 261 310 minecraft:nether_wart_block
fill 12 261 311 12 262 311 minecraft:red_nether_bricks
setblock 13 261 307 minecraft:nether_wart_block
setblock 13 261 309 minecraft:orange_terracotta
fill 13 261 310 14 261 310 minecraft:red_nether_bricks
setblock 13 261 311 minecraft:nether_wart_block
setblock 14 261 307 minecraft:red_nether_bricks
setblock 14 261 308 minecraft:nether_wart_block
setblock 14 261 311 minecraft:red_nether_bricks
setblock 14 261 312 minecraft:nether_wart_block
fill 15 261 308 16 261 308 minecraft:red_nether_bricks
fill 15 261 309 16 261 309 minecraft:orange_terracotta
setblock 15 261 311 minecraft:orange_terracotta
fill 15 261 312 17 261 312 minecraft:red_nether_bricks
fill 17 261 309 17 262 309 minecraft:red_nether_bricks
fill 17 261 310 17 262 311 minecraft:orange_terracotta
setblock 18 261 311 minecraft:red_nether_bricks
setblock 10 262 308 minecraft:red_nether_bricks
setblock 11 262 308 minecraft:nether_wart_block
setblock 11 262 309 minecraft:red_nether_bricks
fill 12 262 308 14 262 308 minecraft:red_nether_bricks
setblock 12 262 309 minecraft:nether_wart_block
fill 12 262 310 12 263 310 minecraft:red_nether_bricks
fill 13 262 306 13 263 306 minecraft:amethyst_block
setblock 13 262 307 minecraft:red_nether_bricks
fill 13 262 309 15 262 309 minecraft:red_nether_bricks
setblock 13 262 310 minecraft:nether_wart_block
fill 13 262 311 13 263 311 minecraft:red_nether_bricks
setblock 14 262 307 minecraft:nether_wart_block
setblock 14 262 310 minecraft:red_nether_bricks
setblock 14 262 311 minecraft:nether_wart_block
fill 14 262 312 14 263 312 minecraft:red_nether_bricks
setblock 15 262 308 minecraft:nether_wart_block
setblock 15 262 311 minecraft:red_nether_bricks
setblock 15 262 312 minecraft:nether_wart_block
setblock 16 262 308 minecraft:red_nether_bricks
setblock 16 262 309 minecraft:nether_wart_block
fill 16 262 312 18 262 312 minecraft:red_nether_bricks
fill 18 262 309 18 262 310 minecraft:red_nether_bricks
fill 18 262 311 20 263 311 minecraft:orange_terracotta
fill 19 262 310 19 263 310 minecraft:orange_terracotta
fill 19 262 312 19 263 312 minecraft:orange_terracotta
setblock 0 263 300 minecraft:crying_obsidian
fill 0 263 305 0 290 305 minecraft:deepslate_tiles
setblock 0 263 306 minecraft:purple_concrete
setblock 12 263 308 minecraft:nether_wart_block
setblock 12 263 309 minecraft:red_nether_bricks
fill 13 263 308 15 263 308 minecraft:red_nether_bricks
setblock 13 263 309 minecraft:nether_wart_block
fill 13 263 310 13 264 310 minecraft:red_nether_bricks
fill 14 263 309 16 263 309 minecraft:red_nether_bricks
setblock 14 263 310 minecraft:nether_wart_block
fill 14 263 311 14 264 311 minecraft:red_nether_bricks
fill 15 263 310 16 263 310 minecraft:red_nether_bricks
setblock 15 263 311 minecraft:nether_wart_block
fill 15 263 312 15 264 312 minecraft:red_nether_bricks
setblock 16 263 308 minecraft:nether_wart_block
setblock 16 263 311 minecraft:red_nether_bricks
setblock 16 263 312 minecraft:nether_wart_block
setblock 16 263 313 minecraft:red_nether_bricks
setblock 17 263 308 minecraft:red_nether_bricks
setblock 17 263 309 minecraft:nether_wart_block
fill 17 263 310 17 266 311 minecraft:bone_block
setblock 17 263 312 minecraft:red_nether_bricks
setblock 17 263 313 minecraft:nether_wart_block
fill 18 263 309 19 263 309 minecraft:red_nether_bricks
setblock 18 263 310 minecraft:nether_wart_block
setblock 18 263 312 minecraft:orange_terracotta
fill 18 263 313 20 263 313 minecraft:red_nether_bricks
fill 20 263 310 20 264 310 minecraft:orange_terracotta
fill 20 263 312 21 264 312 minecraft:orange_terracotta
fill 21 263 310 21 265 310 minecraft:red_nether_bricks
fill 21 263 311 21 264 311 minecraft:orange_terracotta
setblock 22 263 311 minecraft:red_nether_bricks
fill 42 263 305 42 303 309 minecraft:deepslate_tiles
setblock 42 263 310 minecraft:amethyst_block
fill 0 264 286 0 270 287 minecraft:deepslate_tiles
setblock 0 264 288 minecraft:magma_block
fill 0 264 300 0 308 300 minecraft:deepslate_tiles
fill 0 264 306 0 308 306 minecraft:deepslate_tiles
fill 1 264 275 3 282 275 minecraft:deepslate_tiles
setblock 3 264 278 minecraft:light[level=12]
setblock 3 264 285 minecraft:light[level=12]
setblock 3 264 292 minecraft:light[level=12]
setblock 3 264 299 minecraft:light[level=12]
setblock 3 264 306 minecraft:light[level=12]
setblock 3 264 313 minecraft:light[level=12]
setblock 4 264 275 minecraft:magma_block
fill 5 264 275 5 292 275 minecraft:deepslate_tiles
setblock 10 264 278 minecraft:light[level=12]
setblock 10 264 285 minecraft:light[level=12]
setblock 10 264 292 minecraft:light[level=12]
setblock 10 264 299 minecraft:light[level=12]
setblock 10 264 306 minecraft:light[level=12]
setblock 10 264 313 minecraft:light[level=12]
fill 13 264 306 13 274 306 minecraft:blackstone
setblock 13 264 309 minecraft:red_nether_bricks
setblock 14 264 309 minecraft:nether_wart_block
setblock 14 264 310 minecraft:red_nether_bricks
fill 15 264 309 17 264 309 minecraft:red_nether_bricks
setblock 15 264 310 minecraft:nether_wart_block
fill 15 264 311 15 265 311 minecraft:red_nether_bricks
setblock 16 264 310 minecraft:red_nether_bricks
setblock 16 264 311 minecraft:nether_wart_block
fill 16 264 312 16 265 312 minecraft:red_nether_bricks
setblock 17 264 278 minecraft:light[level=12]
setblock 17 264 285 minecraft:light[level=12]
setblock 17 264 292 minecraft:light[level=12]
setblock 17 264 299 minecraft:light[level=12]
setblock 17 264 306 minecraft:light[level=12]
setblock 17 264 312 minecraft:nether_wart_block
fill 17 264 313 17 265 313 minecraft:red_nether_bricks
setblock 18 264 309 minecraft:nether_wart_block
fill 18 264 310 18 264 312 minecraft:red_nether_bricks
setblock 18 264 313 minecraft:nether_wart_block
fill 19 264 309 21 264 309 minecraft:red_nether_bricks
setblock 19 264 310 minecraft:nether_wart_block
fill 19 264 311 20 264 311 minecraft:orange_terracotta
fill 19 264 312 19 264 313 minecraft:red_nether_bricks
fill 20 264 313 21 265 313 minecraft:red_nether_bricks
fill 22 264 310 23 265 312 minecraft:orange_terracotta
setblock 22 264 313 minecraft:nether_wart_block
setblock 24 264 278 minecraft:light[level=12]
setblock 24 264 285 minecraft:light[level=12]
setblock 24 264 292 minecraft:light[level=12]
setblock 24 264 299 minecraft:light[level=12]
setblock 24 264 306 minecraft:light[level=12]
fill 24 264 311 24 266 311 minecraft:orange_terracotta
setblock 24 264 313 minecraft:light[level=12]
setblock 31 264 278 minecraft:light[level=12]
setblock 31 264 285 minecraft:light[level=12]
setblock 31 264 292 minecraft:light[level=12]
setblock 31 264 299 minecraft:light[level=12]
setblock 31 264 306 minecraft:light[level=12]
setblock 31 264 313 minecraft:light[level=12]
setblock 38 264 278 minecraft:light[level=12]
setblock 38 264 285 minecraft:light[level=12]
setblock 38 264 292 minecraft:light[level=12]
setblock 38 264 299 minecraft:light[level=12]
setblock 38 264 306 minecraft:light[level=12]
setblock 38 264 313 minecraft:light[level=12]
fill 42 264 310 42 265 310 minecraft:deepslate_tiles
fill 0 265 288 0 301 288 minecraft:deepslate_tiles
fill 4 265 275 4 270 275 minecraft:deepslate_tiles
fill 14 265 306 14 274 306 minecraft:blackstone
setblock 15 265 310 minecraft:red_nether_bricks
fill 16 265 309 18 265 309 minecraft:red_nether_bricks
setblock 16 265 310 minecraft:nether_wart_block
setblock 16 265 311 minecraft:red_nether_bricks
fill 17 265 312 17 266 312 minecraft:red_nether_bricks
fill 18 265 310 19 265 311 minecraft:red_nether_bricks
setblock 18 265 312 minecraft:nether_wart_block
setblock 18 265 313 minecraft:red_nether_bricks
setblock 19 265 309 minecraft:nether_wart_block
fill 19 265 312 21 265 312 minecraft:red_nether_bricks
setblock 19 265 313 minecraft:nether_wart_block
fill 20 265 309 22 265 309 minecraft:red_nether_bricks
setblock 20 265 310 minecraft:nether_wart_block
fill 20 265 311 20 267 311 minecraft:red_nether_bricks
setblock 21 265 311 minecraft:nether_wart_block
fill 22 265 313 22 267 313 minecraft:red_nether_bricks
setblock 23 265 309 minecraft:nether_wart_block
setblock 23 265 313 minecraft:nether_wart_block
fill 24 265 310 24 266 310 minecraft:orange_terracotta
fill 24 265 312 24 266 312 minecraft:orange_terracotta
setblock 25 265 310 minecraft:red_nether_bricks
fill 25 265 311 25 267 311 minecraft:orange_terracotta
fill 25 265 312 25 267 312 minecraft:red_nether_bricks
fill 13 266 307 14 274 307 minecraft:blackstone
fill 18 266 310 20 266 310 minecraft:red_nether_bricks
setblock 18 266 311 minecraft:nether_wart_block
setblock 18 266 312 minecraft:red_nether_bricks
setblock 19 266 309 minecraft:red_nether_bricks
setblock 19 266 311 minecraft:red_nether_bricks
setblock 19 266 312 minecraft:nether_wart_block
setblock 19 266 313 minecraft:red_nether_bricks
setblock 20 266 309 minecraft:nether_wart_block
fill 20 266 312 22 266 312 minecraft:red_nether_bricks
setblock 20 266 313 minecraft:nether_wart_block
fill 21 266 309 23 266 309 minecraft:red_nether_bricks
setblock 21 266 310 minecraft:nether_wart_block
fill 21 266 311 21 268 311 minecraft:red_nether_bricks
setblock 21 266 313 minecraft:red_nether_bricks
fill 22 266 310 23 266 310 minecraft:red_nether_bricks
setblock 22 266 311 minecraft:nether_wart_block
setblock 23 266 311 minecraft:orange_terracotta
setblock 23 266 312 minecraft:nether_wart_block
fill 23 266 313 23 268 313 minecraft:red_nether_bricks
setblock 24 266 309 minecraft:nether_wart_block
setblock 24 266 313 minecraft:nether_wart_block
setblock 25 266 309 minecraft:red_nether_bricks
fill 25 266 310 28 267 310 minecraft:orange_terracotta
setblock 25 266 313 minecraft:red_nether_bricks
fill 26 266 309 27 267 309 minecraft:orange_terracotta
fill 26 266 311 27 267 311 minecraft:orange_terracotta
fill 26 266 312 26 268 312 minecraft:red_nether_bricks
setblock 42 266 310 minecraft:magma_block
setblock 3 267 278 minecraft:light[level=12]
setblock 3 267 286 minecraft:light[level=12]
setblock 3 267 294 minecraft:light[level=12]
setblock 3 267 302 minecraft:light[level=12]
setblock 3 267 310 minecraft:light[level=12]
setblock 10 267 317 minecraft:amethyst_block
setblock 11 267 278 minecraft:light[level=12]
setblock 11 267 286 minecraft:light[level=12]
setblock 11 267 294 minecraft:light[level=12]
setblock 11 267 302 minecraft:light[level=12]
setblock 11 267 310 minecraft:light[level=12]
fill 12 267 306 12 274 307 minecraft:blackstone
fill 13 267 305 14 273 305 minecraft:blackstone
fill 13 267 308 14 274 308 minecraft:blackstone
fill 15 267 306 15 274 307 minecraft:blackstone
setblock 19 267 278 minecraft:light[level=12]
setblock 19 267 286 minecraft:light[level=12]
setblock 19 267 294 minecraft:light[level=12]
setblock 19 267 302 minecraft:light[level=12]
setblock 19 267 310 minecraft:light[level=12]
setblock 19 267 311 minecraft:nether_wart_block
setblock 19 267 312 minecraft:red_nether_bricks
fill 20 267 310 21 267 310 minecraft:red_nether_bricks
setblock 20 267 312 minecraft:nether_wart_block
fill 21 267 312 23 267 312 minecraft:red_nether_bricks
setblock 21 267 313 minecraft:nether_wart_block
fill 22 267 309 24 267 309 minecraft:red_nether_bricks
setblock 22 267 310 minecraft:nether_wart_block
fill 22 267 311 22 268 311 minecraft:red_nether_bricks
fill 23 267 310 24 267 310 minecraft:red_nether_bricks
setblock 23 267 311 minecraft:nether_wart_block
fill 24 267 311 24 270 311 minecraft:bone_block
setblock 24 267 312 minecraft:nether_wart_block
fill 24 267 313 24 268 313 minecraft:red_nether_bricks
setblock 25 267 309 minecraft:nether_wart_block
setblock 25 267 313 minecraft:nether_wart_block
fill 26 267 308 27 268 308 minecraft:red_nether_bricks
setblock 26 267 313 minecraft:red_nether_bricks
setblock 27 267 278 minecraft:light[level=12]
setblock 27 267 286 minecraft:light[level=12]
setblock 27 267 294 minecraft:light[level=12]
setblock 27 267 302 minecraft:light[level=12]
fill 27 267 312 27 269 312 minecraft:red_nether_bricks
setblock 28 267 308 minecraft:nether_wart_block
fill 28 267 309 29 268 309 minecraft:orange_terracotta
setblock 28 267 311 minecraft:red_nether_bricks
setblock 29 267 310 minecraft:red_nether_bricks
setblock 35 267 278 minecraft:light[level=12]
setblock 35 267 286 minecraft:light[level=12]
setblock 35 267 294 minecraft:light[level=12]
setblock 35 267 302 minecraft:light[level=12]
setblock 35 267 310 minecraft:light[level=12]
fill 42 267 310 42 308 310 minecraft:deepslate_tiles
fill 10 268 317 10 308 317 minecraft:deepslate_tiles
fill 12 268 305 12 274 305 minecraft:blackstone
fill 12 268 308 12 274 308 minecraft:blackstone
fill 15 268 305 15 274 305 minecraft:blackstone
fill 21 268 310 22 268 310 minecraft:red_nether_bricks
setblock 21 268 312 minecraft:nether_wart_block
fill 22 268 312 24 268 312 minecraft:red_nether_bricks
setblock 23 268 275 minecraft:purple_concrete
fill 23 268 309 25 268 309 minecraft:red_nether_bricks
setblock 23 268 310 minecraft:nether_wart_block
fill 23 268 311 23 269 311 minecraft:red_nether_bricks
fill 24 268 310 26 268 310 minecraft:red_nether_bricks
setblock 25 268 308 minecraft:nether_wart_block
fill 25 268 311 27 268 311 minecraft:red_nether_bricks
setblock 25 268 312 minecraft:nether_wart_block
setblock 25 268 313 minecraft:red_nether_bricks
setblock 26 268 309 minecraft:nether_wart_block
setblock 26 268 313 minecraft:nether_wart_block
setblock 27 268 309 minecraft:red_nether_bricks
fill 27 268 310 29 268 310 minecraft:orange_terracotta
fill 28 268 308 28 270 308 minecraft:red_nether_bricks
setblock 28 268 311 minecraft:nether_wart_block
fill 28 268 312 28 269 312 minecraft:red_nether_bricks
setblock 29 268 307 minecraft:red_nether_bricks
fill 29 268 308 31 269 308 minecraft:orange_terracotta
setblock 29 268 311 minecraft:red_nether_bricks
fill 30 268 307 30 269 307 minecraft:orange_terracotta
fill 30 268 309 30 269 309 minecraft:orange_terracotta
fill 30 268 310 30 270 310 minecraft:red_nether_bricks
setblock 31 268 309 minecraft:red_nether_bricks
fill 34 268 317 34 308 317 minecraft:deepslate_tiles
setblock 35 268 317 minecraft:magma_block
setblock 0 269 315 minecraft:amethyst_block
fill 11 269 306 11 274 307 minecraft:blackstone
fill 12 269 304 14 272 304 minecraft:blackstone
fill 13 269 309 14 274 309 minecraft:blackstone
fill 15 269 308 15 274 308 minecraft:blackstone
fill 16 269 306 16 274 307 minecraft:blackstone
fill 23 269 275 23 308 275 minecraft:deepslate_tiles
setblock 23 269 310 minecraft:red_nether_bricks
fill 23 269 312 25 269 312 minecraft:red_nether_bricks
fill 24 269 309 26 269 309 minecraft:red_nether_bricks
setblock 24 269 310 minecraft:nether_wart_block
fill 25 269 310 27 269 310 minecraft:red_nether_bricks
setblock 25 269 311 minecraft:nether_wart_block
setblock 26 269 308 minecraft:nether_wart_block
fill 26 269 311 28 269 311 minecraft:red_nether_bricks
setblock 26 269 312 minecraft:nether_wart_block
setblock 27 269 308 minecraft:red_nether_bricks
setblock 27 269 309 minecraft:nether_wart_block
fill 28 269 307 28 271 307 minecraft:red_nether_bricks
setblock 28 269 309 minecraft:red_nether_bricks
setblock 28 269 310 minecraft:nether_wart_block
setblock 29 269 307 minecraft:nether_wart_block
setblock 29 269 309 minecraft:orange_terracotta
setblock 29 269 310 minecraft:red_nether_bricks
setblock 29 269 311 minecraft:nether_wart_block
fill 30 269 306 31 269 306 minecraft:red_nether_bricks
setblock 30 269 311 minecraft:red_nether_bricks
fill 31 269 307 32 270 307 minecraft:orange_terracotta
setblock 31 269 309 minecraft:orange_terracotta
fill 31 269 310 31 271 310 minecraft:red_nether_bricks
fill 32 269 306 32 271 306 minecraft:orange_terracotta
fill 32 269 308 32 269 309 minecraft:red_nether_bricks
fill 35 269 301 41 270 301 minecraft:amethyst_block
fill 35 269 317 35 308 317 minecraft:deepslate_tiles
fill 38 269 300 41 271 300 minecraft:amethyst_block
fill 38 269 302 41 271 302 minecraft:amethyst_block
fill 39 269 290 39 273 290 minecraft:polished_blackstone
fill 0 270 315 0 308 315 minecraft:deepslate_tiles
setblock 3 270 278 minecraft:light[level=12]
setblock 3 270 285 minecraft:light[level=12]
setblock 3 270 292 minecraft:light[level=12]
setblock 3 270 299 minecraft:light[level=12]
setblock 3 270 306 minecraft:light[level=12]
setblock 3 270 313 minecraft:light[level=12]
setblock 10 270 278 minecraft:light[level=12]
setblock 10 270 285 minecraft:light[level=12]
setblock 10 270 292 minecraft:light[level=12]
setblock 10 270 299 minecraft:light[level=12]
setblock 10 270 306 minecraft:light[level=12]
setblock 10 270 313 minecraft:light[level=12]
fill 11 270 305 11 274 305 minecraft:blackstone
fill 11 270 308 11 274 308 minecraft:blackstone
fill 12 270 309 12 274 309 minecraft:blackstone
fill 15 270 304 15 273 304 minecraft:blackstone
fill 15 270 309 15 274 309 minecraft:blackstone
fill 16 270 305 16 274 305 minecraft:blackstone
fill 16 270 308 16 274 308 minecraft:blackstone
setblock 17 270 278 minecraft:light[level=12]
setblock 17 270 285 minecraft:light[level=12]
setblock 17 270 292 minecraft:light[level=12]
setblock 17 270 299 minecraft:light[level=12]
setblock 17 270 306 minecraft:light[level=12]
setblock 17 270 313 minecraft:light[level=12]
setblock 24 270 278 minecraft:light[level=12]
setblock 24 270 285 minecraft:light[level=12]
setblock 24 270 292 minecraft:light[level=12]
setblock 24 270 299 minecraft:light[level=12]
setblock 24 270 306 minecraft:light[level=12]
setblock 24 270 313 minecraft:light[level=12]
fill 25 270 309 27 270 309 minecraft:red_nether_bricks
setblock 25 270 310 minecraft:nether_wart_block
setblock 25 270 311 minecraft:red_nether_bricks
setblock 26 270 308 minecraft:red_nether_bricks
fill 26 270 310 28 270 310 minecraft:red_nether_bricks
setblock 26 270 311 minecraft:nether_wart_block
setblock 26 270 312 minecraft:red_nether_bricks
setblock 27 270 308 minecraft:nether_wart_block
fill 27 270 311 29 270 311 minecraft:red_nether_bricks
setblock 27 270 312 minecraft:nether_wart_block
setblock 28 270 309 minecraft:nether_wart_block
setblock 29 270 306 minecraft:nether_wart_block
fill 29 270 307 29 270 309 minecraft:red_nether_bricks
setblock 29 270 310 minecraft:nether_wart_block
setblock 30 270 306 minecraft:red_nether_bricks
setblock 30 270 307 minecraft:nether_wart_block
setblock 30 270 308 minecraft:orange_terracotta
fill 30 270 309 31 271 309 minecraft:red_nether_bricks
setblock 30 270 311 minecraft:nether_wart_block
setblock 31 270 278 minecraft:light[level=12]
setblock 31 270 285 minecraft:light[level=12]
setblock 31 270 292 minecraft:light[level=12]
setblock 31 270 299 minecraft:light[level=12]
fill 31 270 305 31 272 305 minecraft:red_nether_bricks
setblock 31 270 306 minecraft:orange_terracotta
setblock 31 270 308 minecraft:nether_wart_block
setblock 31 270 313 minecraft:light[level=12]
fill 32 270 305 33 271 305 minecraft:orange_terracotta
setblock 32 270 308 minecraft:orange_terracotta
setblock 32 270 309 minecraft:nether_wart_block
fill 33 270 306 33 271 307 minecraft:orange_terracotta
fill 33 270 308 33 271 308 minecraft:red_nether_bricks
setblock 34 270 306 minecraft:red_nether_bricks
setblock 37 270 300 minecraft:amethyst_block
setblock 37 270 302 minecraft:amethyst_block
setblock 38 270 278 minecraft:light[level=12]
setblock 38 270 285 minecraft:light[level=12]
setblock 38 270 292 minecraft:light[level=12]
setblock 38 270 299 minecraft:light[level=12]
setblock 38 270 306 minecraft:light[level=12]
setblock 38 270 313 minecraft:light[level=12]
fill 40 270 299 40 271 299 minecraft:amethyst_block
fill 40 270 303 40 271 303 minecraft:amethyst_block
setblock 0 271 286 minecraft:magma_block
fill 0 271 287 0 308 287 minecraft:deepslate_tiles
setblock 4 271 275 minecraft:purple_concrete
fill 8 271 287 8 279 287 minecraft:dripstone_block
fill 10 271 305 10 274 307 minecraft:blackstone
fill 11 271 304 11 273 304 minecraft:blackstone
fill 11 271 309 11 274 309 minecraft:blackstone
fill 12 271 303 15 274 303 minecraft:blackstone
fill 13 271 310 14 274 310 minecraft:blackstone
fill 16 271 301 16 279 301 minecraft:dripstone_block
fill 16 271 303 16 279 303 minecraft:dripstone_block
fill 16 271 304 16 274 304 minecraft:blackstone
fill 16 271 309 16 274 309 minecraft:blackstone
fill 17 271 306 17 274 307 minecraft:blackstone
fill 18 271 294 18 278 294 minecraft:dripstone_block
fill 26 271 309 26 279 309 minecraft:dripstone_block
fill 27 271 308 27 271 310 minecraft:red_nether_bricks
setblock 27 271 311 minecraft:nether_wart_block
setblock 28 271 308 minecraft:nether_wart_block
fill 28 271 309 28 271 311 minecraft:red_nether_bricks
fill 29 271 306 29 271 308 minecraft:red_nether_bricks
setblock 29 271 309 minecraft:nether_wart_block
fill 29 271 310 29 271 311 minecraft:red_nether_bricks
fill 29 271 315 29 279 315 minecraft:dripstone_block
setblock 30 271 305 minecraft:red_nether_bricks
setblock 30 271 306 minecraft:nether_wart_block
fill 30 271 307 30 273 307 minecraft:red_nether_bricks
fill 30 271 308 30 274 308 minecraft:bone_block
setblock 30 271 310 minecraft:nether_wart_block
setblock 31 271 306 minecraft:red_nether_bricks
setblock 31 271 307 minecraft:nether_wart_block
fill 31 271 308 31 273 308 minecraft:red_nether_bricks
fill 32 271 299 32 279 299 minecraft:dripstone_block
setblock 32 271 304 minecraft:nether_wart_block
setblock 32 271 307 minecraft:orange_terracotta
setblock 32 271 308 minecraft:nether_wart_block
fill 32 271 309 32 272 309 minecraft:red_nether_bricks
setblock 33 271 303 minecraft:red_nether_bricks
fill 33 271 304 35 272 304 minecraft:orange_terracotta
setblock 33 271 309 minecraft:nether_wart_block
fill 34 271 303 35 273 303 minecraft:orange_terracotta
fill 34 271 305 34 272 305 minecraft:orange_terracotta
setblock 34 271 306 minecraft:nether_wart_block
fill 34 271 307 34 272 308 minecraft:red_nether_bricks
fill 35 271 305 35 271 306 minecraft:red_nether_bricks
fill 37 271 301 41 271 301 minecraft:amethyst_block
fill 0 272 286 0 308 286 minecraft:deepslate_tiles
fill 4 272 275 4 306 275 minecraft:deepslate_tiles
fill 5 272 295 5 279 295 minecraft:dripstone_block
fill 10 272 304 10 274 304 minecraft:blackstone
fill 10 272 308 10 274 308 minecraft:blackstone
fill 11 272 303 11 274 303 minecraft:blackstone
fill 12 272 310 12 274 310 minecraft:blackstone
fill 15 272 310 15 274 310 minecraft:blackstone
fill 17 272 283 17 279 283 minecraft:dripstone_block
fill 17 272 305 17 274 305 minecraft:blackstone
fill 17 272 308 17 274 308 minecraft:blackstone
fill 20 272 289 20 279 289 minecraft:dripstone_block
fill 22 272 317 22 308 317 minecraft:deepslate_tiles
setblock 23 272 317 minecraft:amethyst_block
fill 28 272 288 28 279 288 minecraft:dripstone_block
fill 28 272 308 28 272 309 minecraft:red_nether_bricks
fill 29 272 305 29 279 305 minecraft:dripstone_block
setblock 29 272 307 minecraft:red_nether_bricks
setblock 29 272 308 minecraft:nether_wart_block
fill 29 272 309 29 272 310 minecraft:red_nether_bricks
setblock 30 272 305 minecraft:nether_wart_block
fill 30 272 306 30 273 306 minecraft:red_nether_bricks
setblock 30 272 309 minecraft:nether_wart_block
setblock 30 272 310 minecraft:red_nether_bricks
fill 31 272 304 32 273 304 minecraft:red_nether_bricks
setblock 31 272 306 minecraft:nether_wart_block
fill 31 272 307 31 273 307 minecraft:red_nether_bricks
setblock 31 272 309 minecraft:red_nether_bricks
setblock 32 272 303 minecraft:nether_wart_block
fill 32 272 305 33 272 306 minecraft:red_nether_bricks
setblock 32 272 307 minecraft:nether_wart_block
fill 32 272 308 32 273 308 minecraft:red_nether_bricks
fill 33 272 302 33 273 302 minecraft:red_nether_bricks
setblock 33 272 303 minecraft:orange_terracotta
setblock 33 272 307 minecraft:red_nether_bricks
setblock 33 272 308 minecraft:nether_wart_block
fill 34 272 302 35 273 302 minecraft:orange_terracotta
fill 34 272 306 34 274 306 minecraft:red_nether_bricks
fill 35 272 298 35 279 298 minecraft:dripstone_block
setblock 35 272 301 minecraft:red_nether_bricks
setblock 35 272 305 minecraft:red_nether_bricks
setblock 35 272 306 minecraft:nether_wart_block
setblock 36 272 302 minecraft:red_nether_bricks
setblock 36 272 303 minecraft:nether_wart_block
fill 36 272 304 36 274 304 minecraft:red_nether_bricks
fill 39 272 300 41 272 302 minecraft:amethyst_block
setblock 42 272 314 minecraft:purple_concrete
setblock 0 273 304 minecraft:purple_concrete
fill 9 273 305 9 274 307 minecraft:blackstone
fill 10 273 309 10 274 309 minecraft:blackstone
fill 11 273 310 11 274 310 minecraft:blackstone
fill 12 273 302 15 274 302 minecraft:blackstone
fill 12 273 304 13 273 304 minecraft:blackstone
fill 13 273 311 14 274 311 minecraft:blackstone
fill 14 273 304 14 279 304 minecraft:dripstone_block
fill 16 273 310 16 274 310 minecraft:blackstone
fill 17 273 304 17 274 304 minecraft:blackstone
fill 17 273 309 17 274 309 minecraft:blackstone
fill 18 273 306 18 274 307 minecraft:blackstone
fill 23 273 317 23 308 317 minecraft:deepslate_tiles
fill 30 273 315 30 279 315 minecraft:dripstone_block
setblock 31 273 305 minecraft:nether_wart_block
fill 31 273 306 31 274 306 minecraft:red_nether_bricks
setblock 31 273 309 minecraft:nether_wart_block
fill 32 273 303 32 274 303 minecraft:red_nether_bricks
fill 32 273 305 34 273 305 minecraft:red_nether_bricks
setblock 32 273 306 minecraft:nether_wart_block
fill 32 273 307 32 274 307 minecraft:red_nether_bricks
fill 33 273 301 34 274 301 minecraft:red_nether_bricks
setblock 33 273 303 minecraft:nether_wart_block
fill 33 273 304 33 275 304 minecraft:red_nether_bricks
setblock 33 273 306 minecraft:red_nether_bricks
setblock 33 273 307 minecraft:nether_wart_block
setblock 33 273 308 minecraft:red_nether_bricks
setblock 34 273 300 minecraft:nether_wart_block
fill 34 273 304 35 273 304 minecraft:orange_terracotta
setblock 34 273 307 minecraft:red_nether_bricks
fill 35 273 288 35 279 288 minecraft:dripstone_block
fill 35 273 300 36 274 301 minecraft:orange_terracotta
setblock 35 273 305 minecraft:nether_wart_block
fill 35 273 306 35 274 306 minecraft:red_nether_bricks
fill 36 273 299 36 275 299 minecraft:orange_terracotta
setblock 36 273 302 minecraft:nether_wart_block
fill 36 273 303 36 275 303 minecraft:red_nether_bricks
setblock 36 273 305 minecraft:red_nether_bricks
fill 37 273 301 37 273 302 minecraft:red_nether_bricks
setblock 37 273 303 minecraft:nether_wart_block
setblock 38 273 290 minecraft:polished_blackstone
fill 39 273 283 39 279 283 minecraft:dripstone_block
setblock 39 273 289 minecraft:polished_blackstone
setblock 39 273 291 minecraft:polished_blackstone
setblock 40 273 290 minecraft:polished_blackstone
setblock 42 273 286 minecraft:crying_obsidian
fill 42 273 314 42 308 314 minecraft:deepslate_tiles
fill 0 274 304 0 308 304 minecraft:deepslate_tiles
setblock 3 274 278 minecraft:light[level=12]
setblock 3 274 286 minecraft:light[level=12]
setblock 3 274 294 minecraft:light[level=12]
fill 3 274 298 3 279 298 minecraft:dripstone_block
setblock 3 274 302 minecraft:light[level=12]
setblock 3 274 310 minecraft:light[level=12]
setblock 9 274 304 minecraft:blackstone
fill 9 274 308 9 274 309 minecraft:blackstone
setblock 10 274 303 minecraft:blackstone
setblock 10 274 310 minecraft:blackstone
setblock 11 274 278 minecraft:light[level=12]
setblock 11 274 286 minecraft:light[level=12]
setblock 11 274 294 minecraft:light[level=12]
setblock 11 274 302 minecraft:blackstone
fill 11 274 304 12 279 304 minecraft:dripstone_block
setblock 12 274 311 minecraft:blackstone
fill 13 274 304 13 274 305 minecraft:blackstone
fill 14 274 305 14 279 305 minecraft:dripstone_block
fill 15 274 304 15 279 304 minecraft:dripstone_block
setblock 15 274 311 minecraft:blackstone
setblock 16 274 302 minecraft:blackstone
fill 17 274 294 17 279 294 minecraft:dripstone_block
fill 17 274 297 17 279 297 minecraft:dripstone_block
setblock 17 274 303 minecraft:blackstone
setblock 17 274 310 minecraft:blackstone
fill 18 274 304 18 274 305 minecraft:blackstone
setblock 18 274 308 minecraft:blackstone
setblock 19 274 278 minecraft:light[level=12]
setblock 19 274 286 minecraft:light[level=12]
setblock 19 274 294 minecraft:light[level=12]
setblock 19 274 302 minecraft:light[level=12]
setblock 19 274 310 minecraft:light[level=12]
fill 25 274 309 25 279 309 minecraft:dripstone_block
setblock 27 274 278 minecraft:light[level=12]
setblock 27 274 286 minecraft:light[level=12]
setblock 27 274 294 minecraft:light[level=12]
setblock 27 274 302 minecraft:light[level=12]
setblock 27 274 310 minecraft:light[level=12]
setblock 31 274 305 minecraft:red_nether_bricks
setblock 32 274 304 minecraft:red_nether_bricks
setblock 32 274 305 minecraft:nether_wart_block
setblock 32 274 306 minecraft:red_nether_bricks
fill 33 274 299 33 279 299 minecraft:dripstone_block
setblock 33 274 302 minecraft:nether_wart_block
fill 33 274 303 33 275 303 minecraft:red_nether_bricks
fill 33 274 305 35 274 305 minecraft:red_nether_bricks
setblock 33 274 306 minecraft:nether_wart_block
setblock 33 274 307 minecraft:red_nether_bricks
setblock 34 274 299 minecraft:nether_wart_block
fill 34 274 300 34 276 300 minecraft:red_nether_bricks
fill 34 274 302 36 274 302 minecraft:red_nether_bricks
fill 34 274 303 35 277 303 minecraft:bone_block
fill 34 274 304 34 276 304 minecraft:red_nether_bricks
setblock 34 274 307 minecraft:nether_wart_block
setblock 35 274 278 minecraft:light[level=12]
setblock 35 274 286 minecraft:light[level=12]
setblock 35 274 294 minecraft:light[level=12]
setblock 35 274 299 minecraft:orange_terracotta
setblock 35 274 304 minecraft:nether_wart_block
setblock 35 274 310 minecraft:light[level=12]
fill 36 274 297 36 276 297 minecraft:orange_terracotta
setblock 36 274 298 minecraft:red_nether_bricks
setblock 36 274 305 minecraft:nether_wart_block
setblock 37 274 298 minecraft:nether_wart_block
fill 37 274 299 37 274 300 minecraft:orange_terracotta
setblock 37 274 301 minecraft:red_nether_bricks
setblock 37 274 302 minecraft:nether_wart_block
fill 37 274 303 37 275 303 minecraft:red_nether_bricks
setblock 41 274 317 minecraft:magma_block
fill 42 274 286 42 308 286 minecraft:deepslate_tiles
fill 4 275 295 4 279 295 minecraft:dripstone_block
fill 5 275 294 5 279 294 minecraft:dripstone_block
fill 7 275 287 7 279 287 minecraft:dripstone_block
fill 8 275 283 8 279 284 minecraft:dripstone_block
fill 8 275 286 8 279 286 minecraft:dripstone_block
fill 11 275 303 12 279 303 minecraft:dripstone_block
fill 15 275 305 15 279 305 minecraft:dripstone_block
fill 16 275 302 16 279 302 minecraft:dripstone_block
fill 16 275 304 16 279 304 minecraft:dripstone_block
fill 17 275 284 17 279 284 minecraft:dripstone_block
fill 17 275 301 17 279 301 minecraft:dripstone_block
fill 17 275 303 17 279 303 minecraft:dripstone_block
fill 18 275 283 18 279 283 minecraft:dripstone_block
fill 19 275 289 19 279 289 minecraft:dripstone_block
setblock 19 275 317 minecraft:purple_concrete
fill 20 275 290 20 279 290 minecraft:dripstone_block
fill 20 275 317 20 308 317 minecraft:deepslate_tiles
fill 22 275 296 22 278 296 minecraft:dripstone_block
fill 23 275 286 24 279 286 minecraft:dripstone_block
fill 25 275 284 25 279 284 minecraft:dripstone_block
fill 27 275 285 27 279 285 minecraft:dripstone_block
fill 28 275 287 28 279 287 minecraft:dripstone_block
fill 29 275 288 29 279 288 minecraft:dripstone_block
fill 30 275 308 30 279 308 minecraft:dripstone_block
setblock 33 275 300 minecraft:red_nether_bricks
setblock 33 275 301 minecraft:nether_wart_block
fill 33 275 302 33 276 302 minecraft:red_nether_bricks
setblock 33 275 305 minecraft:nether_wart_block
setblock 33 275 306 minecraft:red_nether_bricks
setblock 34 275 298 minecraft:nether_wart_block
fill 34 275 299 34 277 299 minecraft:red_nether_bricks
fill 34 275 301 36 275 301 minecraft:red_nether_bricks
setblock 34 275 302 minecraft:nether_wart_block
fill 34 275 305 35 275 305 minecraft:red_nether_bricks
setblock 34 275 306 minecraft:nether_wart_block
setblock 35 275 296 minecraft:red_nether_bricks
fill 35 275 297 35 276 297 minecraft:orange_terracotta
fill 35 275 299 35 279 299 minecraft:dripstone_block
fill 35 275 300 36 275 300 minecraft:orange_terracotta
fill 35 275 302 37 275 302 minecraft:red_nether_bricks
fill 35 275 304 35 276 304 minecraft:red_nether_bricks
fill 36 275 295 36 276 296 minecraft:orange_terracotta
fill 36 275 298 37 275 298 minecraft:orange_terracotta
setblock 36 275 304 minecraft:nether_wart_block
fill 37 275 296 37 276 297 minecraft:orange_terracotta
fill 37 275 299 38 275 300 minecraft:red_nether_bricks
setblock 37 275 301 minecraft:nether_wart_block
fill 37 275 314 37 279 314 minecraft:dripstone_block
setblock 38 275 298 minecraft:nether_wart_block
setblock 38 275 301 minecraft:red_nether_bricks
fill 40 275 283 40 279 283 minecraft:dripstone_block
fill 41 275 317 41 308 317 minecraft:deepslate_tiles
setblock 3 276 278 minecraft:light[level=12]
setblock 3 276 285 minecraft:light[level=12]
setblock 3 276 292 minecraft:light[level=12]
setblock 3 276 299 minecraft:light[level=12]
setblock 3 276 306 minecraft:light[level=12]
setblock 3 276 313 minecraft:light[level=12]
fill 3 276 317 6 308 317 minecraft:deepslate_tiles
fill 4 276 294 4 279 294 minecraft:dripstone_block
fill 7 276 283 7 279 284 minecraft:dripstone_block
setblock 7 276 317 minecraft:magma_block
fill 8 276 290 9 279 291 minecraft:dripstone_block
fill 8 276 317 9 307 317 minecraft:deepslate_tiles
setblock 10 276 278 minecraft:light[level=12]
setblock 10 276 285 minecraft:light[level=12]
setblock 10 276 292 minecraft:light[level=12]
setblock 10 276 299 minecraft:light[level=12]
setblock 10 276 306 minecraft:light[level=12]
setblock 10 276 313 minecraft:light[level=12]
fill 11 276 313 11 279 313 minecraft:dripstone_block
fill 15 276 301 15 279 301 minecraft:dripstone_block
fill 16 276 300 16 279 300 minecraft:dripstone_block
setblock 17 276 278 minecraft:light[level=12]
setblock 17 276 285 minecraft:light[level=12]
setblock 17 276 292 minecraft:light[level=12]
fill 17 276 293 18 278 293 minecraft:dripstone_block
setblock 17 276 299 minecraft:light[level=12]
fill 17 276 304 17 279 304 minecraft:dripstone_block
setblock 17 276 306 minecraft:light[level=12]
setblock 17 276 313 minecraft:light[level=12]
fill 18 276 284 18 279 284 minecraft:dripstone_block
fill 18 276 295 18 278 295 minecraft:dripstone_block
fill 18 276 297 18 278 297 minecraft:dripstone_block
fill 19 276 290 19 279 290 minecraft:dripstone_block
fill 19 276 317 19 308 317 minecraft:deepslate_tiles
fill 23 276 287 24 279 287 minecraft:dripstone_block
fill 23 276 296 23 279 296 minecraft:dripstone_block
setblock 24 276 278 minecraft:light[level=12]
setblock 24 276 285 minecraft:light[level=12]
setblock 24 276 292 minecraft:light[level=12]
setblock 24 276 299 minecraft:light[level=12]
setblock 24 276 306 minecraft:light[level=12]
setblock 24 276 313 minecraft:light[level=12]
fill 25 276 285 25 279 285 minecraft:dripstone_block
fill 25 276 306 26 279 306 minecraft:dripstone_block
fill 25 276 308 26 279 308 minecraft:dripstone_block
fill 26 276 300 26 279 300 minecraft:dripstone_block
fill 27 276 312 27 279 313 minecraft:dripstone_block
fill 29 276 306 29 279 306 minecraft:dripstone_block
fill 29 276 316 30 279 316 minecraft:dripstone_block
fill 30 276 305 30 279 305 minecraft:dripstone_block
setblock 31 276 278 minecraft:light[level=12]
setblock 31 276 285 minecraft:light[level=12]
setblock 31 276 292 minecraft:light[level=12]
setblock 31 276 299 minecraft:light[level=12]
setblock 31 276 306 minecraft:light[level=12]
fill 31 276 308 31 279 308 minecraft:dripstone_block
setblock 31 276 313 minecraft:light[level=12]
fill 32 276 298 32 279 298 minecraft:dripstone_block
fill 32 276 300 32 279 300 minecraft:dripstone_block
setblock 33 276 301 minecraft:red_nether_bricks
fill 34 276 288 34 279 288 minecraft:dripstone_block
setblock 34 276 296 minecraft:red_nether_bricks
setblock 34 276 297 minecraft:nether_wart_block
setblock 34 276 298 minecraft:red_nether_bricks
setblock 34 276 301 minecraft:nether_wart_block
setblock 34 276 302 minecraft:red_nether_bricks
fill 35 276 295 35 278 295 minecraft:red_nether_bricks
setblock 35 276 296 minecraft:orange_terracotta
fill 35 276 300 36 276 301 minecraft:red_nether_bricks
setblock 35 276 302 minecraft:nether_wart_block
setblock 36 276 294 minecraft:red_nether_bricks
fill 36 276 298 36 279 298 minecraft:dripstone_block
setblock 36 276 299 minecraft:nether_wart_block
fill 36 276 302 37 276 302 minecraft:red_nether_bricks
setblock 36 276 303 minecraft:nether_wart_block
setblock 37 276 295 minecraft:orange_terracotta
setblock 37 276 298 minecraft:orange_terracotta
fill 37 276 299 38 276 299 minecraft:red_nether_bricks
setblock 37 276 300 minecraft:nether_wart_block
fill 37 276 301 37 277 301 minecraft:red_nether_bricks
setblock 38 276 278 minecraft:light[level=12]
setblock 38 276 285 minecraft:light[level=12]
setblock 38 276 292 minecraft:light[level=12]
fill 38 276 295 38 276 296 minecraft:red_nether_bricks
setblock 38 276 297 minecraft:nether_wart_block
fill 38 276 298 38 278 298 minecraft:red_nether_bricks
setblock 38 276 300 minecraft:red_nether_bricks
setblock 38 276 306 minecraft:light[level=12]
setblock 38 276 313 minecraft:light[level=12]
fill 39 276 282 40 279 282 minecraft:dripstone_block
setblock 42 276 297 minecraft:crying_obsidian
fill 2 277 298 2 279 298 minecraft:dripstone_block
fill 3 277 297 3 279 297 minecraft:dripstone_block
fill 3 277 299 3 279 299 minecraft:dripstone_block
fill 3 277 309 4 279 309 minecraft:dripstone_block
fill 4 277 298 4 279 298 minecraft:dripstone_block
fill 6 277 295 6 279 295 minecraft:dripstone_block
fill 7 277 286 7 279 286 minecraft:dripstone_block
fill 7 277 317 7 308 317 minecraft:deepslate_tiles
fill 8 277 282 8 279 282 minecraft:dripstone_block
fill 8 277 288 8 279 288 minecraft:dripstone_block
fill 9 277 283 9 279 283 minecraft:dripstone_block
fill 9 277 287 9 279 287 minecraft:dripstone_block
fill 10 277 313 10 279 313 minecraft:dripstone_block
setblock 12 277 275 minecraft:magma_block
fill 13 277 275 16 308 275 minecraft:deepslate_tiles
fill 15 277 303 15 279 303 minecraft:dripstone_block
fill 16 277 293 16 279 293 minecraft:dripstone_block
fill 17 277 295 17 278 296 minecraft:dripstone_block
fill 17 277 302 17 279 302 minecraft:dripstone_block
fill 20 277 298 20 278 298 minecraft:dripstone_block
fill 22 277 281 22 279 281 minecraft:dripstone_block
fill 22 277 297 23 278 297 minecraft:dripstone_block
fill 25 277 305 26 279 305 minecraft:dripstone_block
fill 25 277 310 26 279 310 minecraft:dripstone_block
fill 26 277 284 26 279 285 minecraft:dripstone_block
fill 26 277 299 26 279 299 minecraft:dripstone_block
fill 26 277 303 26 279 303 minecraft:dripstone_block
fill 27 277 286 27 279 286 minecraft:dripstone_block
fill 28 277 289 28 279 289 minecraft:dripstone_block
fill 28 277 305 28 279 305 minecraft:dripstone_block
fill 28 277 312 28 279 313 minecraft:dripstone_block
fill 29 277 287 29 279 287 minecraft:dripstone_block
fill 29 277 304 29 279 304 minecraft:dripstone_block
fill 29 277 314 30 279 314 minecraft:dripstone_block
fill 30 277 306 30 279 307 minecraft:dripstone_block
fill 31 277 299 31 279 299 minecraft:dripstone_block
fill 31 277 307 31 279 307 minecraft:dripstone_block
fill 33 277 291 33 279 292 minecraft:dripstone_block
fill 33 277 298 34 279 298 minecraft:dripstone_block
fill 33 277 300 33 279 300 minecraft:dripstone_block
setblock 34 277 295 minecraft:red_nether_bricks
setblock 34 277 296 minecraft:nether_wart_block
fill 34 277 297 34 278 297 minecraft:red_nether_bricks
setblock 34 277 300 minecraft:nether_wart_block
setblock 34 277 301 minecraft:red_nether_bricks
fill 35 277 287 35 279 287 minecraft:dripstone_block
fill 35 277 289 35 279 289 minecraft:dripstone_block
fill 35 277 294 35 278 294 minecraft:red_nether_bricks
setblock 35 277 296 minecraft:red_nether_bricks
setblock 35 277 297 minecraft:nether_wart_block
fill 35 277 300 37 277 300 minecraft:red_nether_bricks
setblock 35 277 301 minecraft:nether_wart_block
setblock 35 277 302 minecraft:red_nether_bricks
fill 36 277 288 36 279 288 minecraft:dripstone_block
setblock 36 277 294 minecraft:nether_wart_block
fill 36 277 295 36 279 295 minecraft:red_nether_bricks
fill 36 277 296 37 277 296 minecraft:orange_terracotta
fill 36 277 297 38 277 297 minecraft:red_nether_bricks
fill 36 277 299 36 279 299 minecraft:dripstone_block
setblock 36 277 301 minecraft:red_nether_bricks
setblock 36 277 302 minecraft:nether_wart_block
fill 36 277 315 36 279 315 minecraft:dripstone_block
setblock 37 277 294 minecraft:red_nether_bricks
setblock 37 277 295 minecraft:nether_wart_block
setblock 37 277 298 minecraft:red_nether_bricks
setblock 37 277 299 minecraft:nether_wart_block
fill 37 277 313 37 279 313 minecraft:dripstone_block
setblock 38 277 295 minecraft:red_nether_bricks
setblock 38 277 296 minecraft:nether_wart_block
setblock 38 277 299 minecraft:red_nether_bricks
setblock 38 277 300 minecraft:nether_wart_block
fill 38 277 314 38 279 314 minecraft:dripstone_block
fill 42 277 297 42 308 297 minecraft:deepslate_tiles
setblock 42 277 298 minecraft:magma_block
fill 42 277 299 42 308 299 minecraft:deepslate_tiles
fill 2 278 299 2 279 299 minecraft:dripstone_block
fill 3 278 310 4 279 310 minecraft:dripstone_block
fill 4 278 299 4 279 299 minecraft:dripstone_block
fill 5 278 296 5 279 296 minecraft:dripstone_block
fill 6 278 285 6 279 286 minecraft:dripstone_block
fill 6 278 294 6 279 294 minecraft:dripstone_block
fill 7 278 285 7 279 285 minecraft:dripstone_block
fill 7 278 288 7 279 288 minecraft:dripstone_block
fill 9 278 282 9 279 282 minecraft:dripstone_block
fill 9 278 284 9 279 284 minecraft:dripstone_block
fill 9 278 286 9 279 286 minecraft:dripstone_block
fill 10 278 291 10 279 291 minecraft:dripstone_block
fill 10 278 304 10 279 304 minecraft:dripstone_block
fill 10 278 312 11 279 312 minecraft:dripstone_block
fill 10 278 314 11 279 314 minecraft:dripstone_block
fill 11 278 305 12 279 305 minecraft:dripstone_block
fill 12 278 275 12 308 275 minecraft:deepslate_tiles
fill 13 278 304 13 279 304 minecraft:dripstone_block
fill 14 278 303 14 279 303 minecraft:dripstone_block
fill 15 278 302 15 279 302 minecraft:dripstone_block
fill 16 278 283 16 279 283 minecraft:dripstone_block
fill 16 278 292 17 279 292 minecraft:dripstone_block
fill 16 278 297 16 279 297 minecraft:dripstone_block
fill 17 278 282 18 279 282 minecraft:dripstone_block
fill 17 278 298 19 279 298 minecraft:dripstone_block
fill 17 278 300 17 279 300 minecraft:dripstone_block
setblock 18 278 296 minecraft:dripstone_block
fill 19 278 288 20 279 288 minecraft:dripstone_block
setblock 19 278 294 minecraft:dripstone_block
setblock 20 278 297 minecraft:dripstone_block
fill 21 278 281 21 279 281 minecraft:dripstone_block
fill 21 278 289 21 279 289 minecraft:dripstone_block
fill 21 278 298 21 279 298 minecraft:dripstone_block
fill 22 278 280 22 279 280 minecraft:dripstone_block
fill 22 278 295 23 278 295 minecraft:dripstone_block
fill 23 278 281 23 279 281 minecraft:dripstone_block
fill 24 278 284 24 279 285 minecraft:dripstone_block
fill 25 278 300 25 279 300 minecraft:dripstone_block
fill 25 278 303 25 279 304 minecraft:dripstone_block
fill 26 278 286 26 279 286 minecraft:dripstone_block
fill 26 278 301 26 279 301 minecraft:dripstone_block
fill 26 278 304 26 279 304 minecraft:dripstone_block
fill 26 278 312 26 279 313 minecraft:dripstone_block
fill 27 278 284 27 279 284 minecraft:dripstone_block
fill 27 278 288 27 279 288 minecraft:dripstone_block
fill 27 278 299 27 279 300 minecraft:dripstone_block
fill 27 278 309 27 279 309 minecraft:dripstone_block
fill 28 278 285 28 279 286 minecraft:dripstone_block
fill 28 278 306 28 279 306 minecraft:dripstone_block
fill 28 278 315 28 279 315 minecraft:dripstone_block
fill 29 278 289 29 279 289 minecraft:dripstone_block
fill 30 278 304 30 279 304 minecraft:dripstone_block
fill 30 278 309 31 279 309 minecraft:dripstone_block
fill 32 278 291 32 279 292 minecraft:dripstone_block
fill 34 278 287 34 279 287 minecraft:dripstone_block
fill 34 278 289 34 279 289 minecraft:dripstone_block
setblock 34 278 295 minecraft:nether_wart_block
setblock 34 278 296 minecraft:red_nether_bricks
fill 34 278 299 34 279 299 minecraft:dripstone_block
setblock 35 278 296 minecraft:nether_wart_block
fill 35 278 297 35 279 297 minecraft:dripstone_block
setblock 35 278 300 minecraft:nether_wart_block
fill 35 278 315 35 279 315 minecraft:dripstone_block
fill 36 278 294 36 279 294 minecraft:red_nether_bricks
fill 36 278 296 36 279 296 minecraft:bone_block
setblock 36 278 297 minecraft:nether_wart_block
fill 36 278 300 37 278 300 minecraft:red_nether_bricks
fill 36 278 314 36 279 314 minecraft:dripstone_block
setblock 37 278 294 minecraft:nether_wart_block
fill 37 278 295 37 278 297 minecraft:red_nether_bricks
setblock 37 278 298 minecraft:nether_wart_block
setblock 37 278 299 minecraft:red_nether_bricks
fill 37 278 315 38 279 315 minecraft:dripstone_block
fill 38 278 283 38 279 283 minecraft:dripstone_block
setblock 38 278 295 minecraft:nether_wart_block
fill 38 278 296 38 279 297 minecraft:red_nether_bricks
fill 38 278 313 38 279 313 minecraft:dripstone_block
fill 39 278 284 39 279 284 minecraft:dripstone_block
fill 42 278 298 42 308 298 minecraft:deepslate_tiles
setblock 2 279 297 minecraft:dripstone_block
setblock 2 279 309 minecraft:dripstone_block
fill 3 279 308 4 279 308 minecraft:dripstone_block
fill 4 279 296 4 279 297 minecraft:dripstone_block
fill 5 279 285 5 279 286 minecraft:dripstone_block
setblock 5 279 309 minecraft:dripstone_block
setblock 6 279 284 minecraft:dripstone_block
setblock 6 279 287 minecraft:dripstone_block
setblock 7 279 282 minecraft:dripstone_block
setblock 8 279 285 minecraft:dripstone_block
fill 8 279 289 9 279 289 minecraft:dripstone_block
fill 8 279 292 9 279 292 minecraft:dripstone_block
setblock 9 279 288 minecraft:dripstone_block
setblock 9 279 313 minecraft:dripstone_block
setblock 10 279 290 minecraft:dripstone_block
setblock 10 279 303 minecraft:dripstone_block
setblock 11 279 302 minecraft:dripstone_block
setblock 12 279 313 minecraft:dripstone_block
setblock 13 279 303 minecraft:dripstone_block
setblock 13 279 305 minecraft:dripstone_block
setblock 14 279 306 minecraft:dripstone_block
fill 15 279 292 15 279 293 minecraft:dripstone_block
setblock 15 279 300 minecraft:dripstone_block
setblock 16 279 284 minecraft:dripstone_block
setblock 16 279 291 minecraft:dripstone_block
setblock 16 279 294 minecraft:dripstone_block
fill 16 279 296 17 279 296 minecraft:dripstone_block
setblock 16 279 298 minecraft:dripstone_block
setblock 17 279 293 minecraft:dripstone_block
setblock 18 279 289 minecraft:dripstone_block
fill 19 279 299 20 279 299 minecraft:dripstone_block
setblock 21 279 280 minecraft:dripstone_block
fill 21 279 282 23 279 282 minecraft:dripstone_block
setblock 21 279 290 minecraft:dripstone_block
fill 22 279 286 22 279 287 minecraft:dripstone_block
setblock 23 279 280 minecraft:dripstone_block
setblock 23 279 285 minecraft:dripstone_block
fill 23 279 297 24 279 297 minecraft:dripstone_block
setblock 24 279 288 minecraft:dripstone_block
setblock 24 279 296 minecraft:dripstone_block
setblock 24 279 303 minecraft:dripstone_block
fill 24 279 305 24 279 306 minecraft:dripstone_block
setblock 24 279 309 minecraft:dripstone_block
fill 25 279 283 26 279 283 minecraft:dripstone_block
fill 25 279 286 25 279 287 minecraft:dripstone_block
setblock 25 279 299 minecraft:dripstone_block
fill 25 279 301 25 279 302 minecraft:dripstone_block
fill 25 279 307 26 279 307 minecraft:dripstone_block
setblock 26 279 302 minecraft:dripstone_block
setblock 27 279 287 minecraft:dripstone_block
setblock 27 279 301 minecraft:dripstone_block
fill 27 279 303 27 279 306 minecraft:dripstone_block
setblock 27 279 308 minecraft:dripstone_block
fill 27 279 311 28 279 311 minecraft:dripstone_block
setblock 27 279 314 minecraft:dripstone_block
setblock 28 279 284 minecraft:dripstone_block
setblock 28 279 304 minecraft:dripstone_block
fill 29 279 307 29 279 308 minecraft:dripstone_block
setblock 31 279 298 minecraft:dripstone_block
setblock 31 279 300 minecraft:dripstone_block
setblock 31 279 315 minecraft:dripstone_block
setblock 32 279 308 minecraft:dripstone_block
setblock 33 279 290 minecraft:dripstone_block
setblock 33 279 293 minecraft:dripstone_block
fill 34 279 291 34 279 292 minecraft:dripstone_block
setblock 35 279 295 minecraft:nether_wart_block
setblock 35 279 296 minecraft:red_nether_bricks
setblock 35 279 300 minecraft:dripstone_block
setblock 35 279 314 minecraft:dripstone_block
fill 35 279 316 37 279 316 minecraft:dripstone_block
setblock 36 279 287 minecraft:dripstone_block
setblock 36 279 289 minecraft:dripstone_block
setblock 36 279 297 minecraft:dripstone_block
setblock 36 279 313 minecraft:dripstone_block
fill 37 279 295 37 279 296 minecraft:red_nether_bricks
setblock 37 279 297 minecraft:nether_wart_block
setblock 37 279 298 minecraft:red_nether_bricks
setblock 38 279 282 minecraft:dripstone_block
setblock 38 279 295 minecraft:red_nether_bricks
setblock 40 279 284 minecraft:dripstone_block
setblock 41 279 283 minecraft:dripstone_block
fill 0 280 294 0 308 295 minecraft:deepslate_tiles
setblock 0 280 296 minecraft:purple_concrete
setblock 1 280 276 minecraft:cobbled_deepslate
fill 1 280 277 1 280 279 minecraft:blackstone
setblock 1 280 280 minecraft:cobbled_deepslate
fill 1 280 281 1 280 283 minecraft:blackstone
setblock 1 280 284 minecraft:cobbled_deepslate
fill 1 280 285 1 280 287 minecraft:blackstone
setblock 1 280 288 minecraft:cobbled_deepslate
fill 1 280 289 1 280 291 minecraft:blackstone
setblock 1 280 292 minecraft:cobbled_deepslate
fill 1 280 293 1 280 295 minecraft:blackstone
setblock 1 280 296 minecraft:cobbled_deepslate
fill 1 280 297 1 280 299 minecraft:blackstone
setblock 1 280 300 minecraft:cobbled_deepslate
fill 1 280 301 1 280 303 minecraft:blackstone
setblock 1 280 304 minecraft:cobbled_deepslate
fill 1 280 305 1 280 307 minecraft:blackstone
setblock 1 280 308 minecraft:cobbled_deepslate
fill 1 280 309 1 280 311 minecraft:blackstone
setblock 1 280 312 minecraft:cobbled_deepslate
fill 1 280 313 1 280 315 minecraft:blackstone
setblock 1 280 316 minecraft:cobbled_deepslate
fill 2 280 276 4 280 276 minecraft:blackstone
setblock 2 280 277 minecraft:cobbled_deepslate
fill 2 280 278 2 280 280 minecraft:blackstone
setblock 2 280 281 minecraft:cobbled_deepslate
fill 2 280 282 2 280 284 minecraft:blackstone
setblock 2 280 285 minecraft:cobbled_deepslate
fill 2 280 286 2 280 288 minecraft:blackstone
setblock 2 280 289 minecraft:cobbled_deepslate
fill 2 280 290 2 280 292 minecraft:blackstone
setblock 2 280 293 minecraft:cobbled_deepslate
fill 2 280 294 2 280 296 minecraft:blackstone
setblock 2 280 297 minecraft:cobbled_deepslate
fill 2 280 298 2 280 300 minecraft:blackstone
setblock 2 280 301 minecraft:cobbled_deepslate
fill 2 280 302 2 280 304 minecraft:blackstone
setblock 2 280 305 minecraft:cobbled_deepslate
fill 2 280 306 2 280 308 minecraft:blackstone
setblock 2 280 309 minecraft:cobbled_deepslate
fill 2 280 310 2 280 312 minecraft:blackstone
setblock 2 280 313 minecraft:cobbled_deepslate
fill 2 280 314 2 280 316 minecraft:blackstone
fill 3 280 277 5 280 277 minecraft:blackstone
setblock 3 280 278 minecraft:cobbled_deepslate
fill 3 280 279 3 280 281 minecraft:blackstone
setblock 3 280 282 minecraft:cobbled_deepslate
fill 3 280 283 3 280 285 minecraft:blackstone
setblock 3 280 286 minecraft:cobbled_deepslate
fill 3 280 287 3 280 289 minecraft:blackstone
setblock 3 280 290 minecraft:cobbled_deepslate
fill 3 280 291 3 280 293 minecraft:blackstone
setblock 3 280 294 minecraft:cobbled_deepslate
fill 3 280 295 3 280 297 minecraft:blackstone
setblock 3 280 298 minecraft:cobbled_deepslate
fill 3 280 299 3 280 301 minecraft:blackstone
setblock 3 280 302 minecraft:cobbled_deepslate
fill 3 280 303 3 280 305 minecraft:blackstone
setblock 3 280 306 minecraft:cobbled_deepslate
fill 3 280 307 3 280 309 minecraft:blackstone
setblock 3 280 310 minecraft:cobbled_deepslate
fill 3 280 311 3 280 313 minecraft:blackstone
setblock 3 280 314 minecraft:cobbled_deepslate
fill 3 280 315 3 280 316 minecraft:blackstone
fill 4 280 278 6 280 278 minecraft:blackstone
setblock 4 280 279 minecraft:cobbled_deepslate
fill 4 280 280 4 280 282 minecraft:blackstone
setblock 4 280 283 minecraft:cobbled_deepslate
fill 4 280 284 4 280 286 minecraft:blackstone
setblock 4 280 287 minecraft:cobbled_deepslate
fill 4 280 288 4 280 290 minecraft:blackstone
setblock 4 280 291 minecraft:cobbled_deepslate
fill 4 280 292 4 280 294 minecraft:blackstone
setblock 4 280 295 minecraft:cobbled_deepslate
fill 4 280 296 4 280 298 minecraft:blackstone
setblock 4 280 299 minecraft:cobbled_deepslate
fill 4 280 300 4 280 302 minecraft:blackstone
setblock 4 280 303 minecraft:cobbled_deepslate
fill 4 280 304 4 280 306 minecraft:blackstone
setblock 4 280 307 minecraft:cobbled_deepslate
fill 4 280 308 4 280 310 minecraft:blackstone
setblock 4 280 311 minecraft:cobbled_deepslate
fill 4 280 312 4 280 314 minecraft:blackstone
setblock 4 280 315 minecraft:cobbled_deepslate
setblock 4 280 316 minecraft:blackstone
setblock 5 280 276 minecraft:cobbled_deepslate
fill 5 280 279 7 280 279 minecraft:blackstone
setblock 5 280 280 minecraft:cobbled_deepslate
fill 5 280 281 5 280 283 minecraft:blackstone
setblock 5 280 284 minecraft:cobbled_deepslate
fill 5 280 285 5 280 287 minecraft:blackstone
setblock 5 280 288 minecraft:cobbled_deepslate
fill 5 280 289 5 280 291 minecraft:blackstone
setblock 5 280 292 minecraft:cobbled_deepslate
fill 5 280 293 5 280 295 minecraft:blackstone
setblock 5 280 296 minecraft:cobbled_deepslate
fill 5 280 297 5 280 299 minecraft:blackstone
setblock 5 280 300 minecraft:cobbled_deepslate
fill 5 280 301 5 280 303 minecraft:blackstone
setblock 5 280 304 minecraft:cobbled_deepslate
fill 5 280 305 5 280 307 minecraft:blackstone
setblock 5 280 308 minecraft:cobbled_deepslate
fill 5 280 309 5 280 311 minecraft:blackstone
setblock 5 280 312 minecraft:cobbled_deepslate
fill 5 280 313 5 280 315 minecraft:blackstone
setblock 5 280 316 minecraft:cobbled_deepslate
fill 6 280 276 8 280 276 minecraft:blackstone
setblock 6 280 277 minecraft:cobbled_deepslate
fill 6 280 280 8 280 280 minecraft:blackstone
setblock 6 280 281 minecraft:cobbled_deepslate
fill 6 280 282 6 280 284 minecraft:blackstone
setblock 6 280 285 minecraft:cobbled_deepslate
fill 6 280 286 6 280 288 minecraft:blackstone
setblock 6 280 289 minecraft:cobbled_deepslate
fill 6 280 290 6 280 292 minecraft:blackstone
setblock 6 280 293 minecraft:cobbled_deepslate
fill 6 280 294 6 280 296 minecraft:blackstone
setblock 6 280 297 minecraft:cobbled_deepslate
fill 6 280 298 6 280 300 minecraft:blackstone
setblock 6 280 301 minecraft:cobbled_deepslate
fill 6 280 302 6 280 304 minecraft:blackstone
setblock 6 280 305 minecraft:cobbled_deepslate
fill 6 280 306 6 280 308 minecraft:blackstone
setblock 6 280 309 minecraft:cobbled_deepslate
fill 6 280 310 6 280 312 minecraft:blackstone
setblock 6 280 313 minecraft:cobbled_deepslate
fill 6 280 314 6 280 316 minecraft:blackstone
fill 7 280 277 9 280 277 minecraft:blackstone
setblock 7 280 278 minecraft:cobbled_deepslate
fill 7 280 281 9 280 281 minecraft:blackstone
setblock 7 280 282 minecraft:cobbled_deepslate
fill 7 280 283 7 280 285 minecraft:blackstone
setblock 7 280 286 minecraft:cobbled_deepslate
fill 7 280 287 7 280 289 minecraft:blackstone
setblock 7 280 290 minecraft:cobbled_deepslate
fill 7 280 291 7 280 293 minecraft:blackstone
setblock 7 280 294 minecraft:cobbled_deepslate
fill 7 280 295 7 280 297 minecraft:blackstone
setblock 7 280 298 minecraft:cobbled_deepslate
fill 7 280 299 7 280 301 minecraft:blackstone
setblock 7 280 302 minecraft:cobbled_deepslate
fill 7 280 303 7 280 305 minecraft:blackstone
setblock 7 280 306 minecraft:cobbled_deepslate
fill 7 280 307 7 280 309 minecraft:blackstone
setblock 7 280 310 minecraft:cobbled_deepslate
fill 7 280 311 7 280 313 minecraft:blackstone
setblock 7 280 314 minecraft:cobbled_deepslate
fill 7 280 315 7 280 316 minecraft:blackstone
fill 8 280 278 10 280 278 minecraft:blackstone
setblock 8 280 279 minecraft:cobbled_deepslate
fill 8 280 282 10 280 282 minecraft:blackstone
setblock 8 280 283 minecraft:cobbled_deepslate
fill 8 280 284 8 280 286 minecraft:blackstone
setblock 8 280 287 minecraft:cobbled_deepslate
fill 8 280 288 8 280 290 minecraft:blackstone
setblock 8 280 291 minecraft:cobbled_deepslate
fill 8 280 292 8 280 294 minecraft:blackstone
setblock 8 280 295 minecraft:cobbled_deepslate
fill 8 280 296 8 280 298 minecraft:blackstone
setblock 8 280 299 minecraft:cobbled_deepslate
fill 8 280 300 8 280 302 minecraft:blackstone
setblock 8 280 303 minecraft:cobbled_deepslate
fill 8 280 304 8 280 306 minecraft:blackstone
setblock 8 280 307 minecraft:cobbled_deepslate
fill 8 280 308 8 280 310 minecraft:blackstone
setblock 8 280 311 minecraft:cobbled_deepslate
fill 8 280 312 8 280 314 minecraft:blackstone
setblock 8 280 315 minecraft:cobbled_deepslate
setblock 8 280 316 minecraft:blackstone
setblock 9 280 276 minecraft:cobbled_deepslate
fill 9 280 279 11 280 279 minecraft:blackstone
setblock 9 280 280 minecraft:cobbled_deepslate
fill 9 280 283 11 280 283 minecraft:blackstone
setblock 9 280 284 minecraft:cobbled_deepslate
fill 9 280 285 9 280 287 minecraft:blackstone
setblock 9 280 288 minecraft:cobbled_deepslate
fill 9 280 289 9 280 291 minecraft:blackstone
setblock 9 280 292 minecraft:cobbled_deepslate
fill 9 280 293 9 280 295 minecraft:blackstone
setblock 9 280 296 minecraft:cobbled_deepslate
fill 9 280 297 9 280 299 minecraft:blackstone
setblock 9 280 300 minecraft:cobbled_deepslate
fill 9 280 301 9 280 303 minecraft:blackstone
setblock 9 280 304 minecraft:cobbled_deepslate
fill 9 280 305 9 280 307 minecraft:blackstone
setblock 9 280 308 minecraft:cobbled_deepslate
fill 9 280 309 9 280 311 minecraft:blackstone
setblock 9 280 312 minecraft:cobbled_deepslate
fill 9 280 313 9 280 315 minecraft:blackstone
setblock 9 280 316 minecraft:cobbled_deepslate
fill 10 280 276 12 280 276 minecraft:blackstone
setblock 10 280 277 minecraft:cobbled_deepslate
fill 10 280 280 12 280 280 minecraft:blackstone
setblock 10 280 281 minecraft:cobbled_deepslate
fill 10 280 284 12 280 284 minecraft:blackstone
setblock 10 280 285 minecraft:cobbled_deepslate
fill 10 280 286 10 280 288 minecraft:blackstone
setblock 10 280 289 minecraft:cobbled_deepslate
fill 10 280 290 10 280 292 minecraft:blackstone
setblock 10 280 293 minecraft:cobbled_deepslate
fill 10 280 294 10 280 296 minecraft:blackstone
setblock 10 280 297 minecraft:cobbled_deepslate
fill 10 280 298 10 280 300 minecraft:blackstone
setblock 10 280 301 minecraft:cobbled_deepslate
fill 10 280 302 10 280 304 minecraft:blackstone
setblock 10 280 305 minecraft:cobbled_deepslate
fill 10 280 306 10 280 308 minecraft:blackstone
setblock 10 280 309 minecraft:cobbled_deepslate
fill 10 280 310 10 280 312 minecraft:blackstone
setblock 10 280 313 minecraft:cobbled_deepslate
fill 10 280 314 10 280 316 minecraft:blackstone
fill 11 280 277 13 280 277 minecraft:blackstone
setblock 11 280 278 minecraft:cobbled_deepslate
fill 11 280 281 13 280 281 minecraft:blackstone
setblock 11 280 282 minecraft:cobbled_deepslate
fill 11 280 285 13 280 285 minecraft:blackstone
setblock 11 280 286 minecraft:cobbled_deepslate
fill 11 280 287 11 280 289 minecraft:blackstone
setblock 11 280 290 minecraft:cobbled_deepslate
fill 11 280 291 11 280 293 minecraft:blackstone
setblock 11 280 294 minecraft:cobbled_deepslate
fill 11 280 295 11 280 297 minecraft:blackstone
setblock 11 280 298 minecraft:cobbled_deepslate
fill 11 280 299 11 280 301 minecraft:blackstone
setblock 11 280 302 minecraft:cobbled_deepslate
fill 11 280 303 11 280 305 minecraft:blackstone
setblock 11 280 306 minecraft:cobbled_deepslate
fill 11 280 307 11 280 309 minecraft:blackstone
setblock 11 280 310 minecraft:cobbled_deepslate
fill 11 280 311 11 280 313 minecraft:blackstone
setblock 11 280 314 minecraft:cobbled_deepslate
fill 11 280 315 11 280 316 minecraft:blackstone
fill 12 280 278 14 280 278 minecraft:blackstone
setblock 12 280 279 minecraft:cobbled_deepslate
fill 12 280 282 14 280 282 minecraft:blackstone
setblock 12 280 283 minecraft:cobbled_deepslate
fill 12 280 286 14 280 286 minecraft:blackstone
setblock 12 280 287 minecraft:cobbled_deepslate
fill 12 280 288 12 280 290 minecraft:blackstone
setblock 12 280 291 minecraft:cobbled_deepslate
fill 12 280 292 12 280 294 minecraft:blackstone
setblock 12 280 295 minecraft:cobbled_deepslate
fill 12 280 296 12 280 298 minecraft:blackstone
setblock 12 280 299 minecraft:cobbled_deepslate
fill 12 280 300 12 280 302 minecraft:blackstone
setblock 12 280 303 minecraft:cobbled_deepslate
fill 12 280 304 12 280 306 minecraft:blackstone
setblock 12 280 307 minecraft:cobbled_deepslate
fill 12 280 308 12 280 310 minecraft:blackstone
setblock 12 280 311 minecraft:cobbled_deepslate
fill 12 280 312 12 280 314 minecraft:blackstone
setblock 12 280 315 minecraft:cobbled_deepslate
setblock 12 280 316 minecraft:blackstone
setblock 13 280 276 minecraft:cobbled_deepslate
fill 13 280 279 15 280 279 minecraft:blackstone
setblock 13 280 280 minecraft:cobbled_deepslate
fill 13 280 283 15 280 283 minecraft:blackstone
setblock 13 280 284 minecraft:cobbled_deepslate
fill 13 280 287 15 280 287 minecraft:blackstone
setblock 13 280 288 minecraft:cobbled_deepslate
fill 13 280 289 13 280 291 minecraft:blackstone
setblock 13 280 292 minecraft:cobbled_deepslate
fill 13 280 293 13 280 295 minecraft:blackstone
setblock 13 280 296 minecraft:cobbled_deepslate
fill 13 280 297 13 280 299 minecraft:blackstone
setblock 13 280 300 minecraft:cobbled_deepslate
fill 13 280 301 13 280 303 minecraft:blackstone
setblock 13 280 304 minecraft:cobbled_deepslate
fill 13 280 305 13 280 307 minecraft:blackstone
setblock 13 280 308 minecraft:cobbled_deepslate
fill 13 280 309 13 280 311 minecraft:blackstone
setblock 13 280 312 minecraft:cobbled_deepslate
fill 13 280 313 13 280 315 minecraft:blackstone
setblock 13 280 316 minecraft:cobbled_deepslate
fill 14 280 276 16 280 276 minecraft:blackstone
setblock 14 280 277 minecraft:cobbled_deepslate
fill 14 280 280 16 280 280 minecraft:blackstone
setblock 14 280 281 minecraft:cobbled_deepslate
fill 14 280 284 16 280 284 minecraft:blackstone
setblock 14 280 285 minecraft:cobbled_deepslate
fill 14 280 288 16 280 288 minecraft:blackstone
setblock 14 280 289 minecraft:cobbled_deepslate
fill 14 280 290 14 280 292 minecraft:blackstone
setblock 14 280 293 minecraft:cobbled_deepslate
fill 14 280 294 14 280 296 minecraft:blackstone
setblock 14 280 297 minecraft:cobbled_deepslate
fill 14 280 298 14 280 300 minecraft:blackstone
setblock 14 280 301 minecraft:cobbled_deepslate
fill 14 280 302 14 280 304 minecraft:blackstone
setblock 14 280 305 minecraft:cobbled_deepslate
fill 14 280 306 14 280 308 minecraft:blackstone
setblock 14 280 309 minecraft:cobbled_deepslate
fill 14 280 310 14 280 312 minecraft:blackstone
setblock 14 280 313 minecraft:cobbled_deepslate
fill 14 280 314 14 280 316 minecraft:blackstone
fill 15 280 277 17 280 277 minecraft:blackstone
setblock 15 280 278 minecraft:cobbled_deepslate
fill 15 280 281 17 280 281 minecraft:blackstone
setblock 15 280 282 minecraft:cobbled_deepslate
fill 15 280 285 17 280 285 minecraft:blackstone
setblock 15 280 286 minecraft:cobbled_deepslate
fill 15 280 289 17 280 289 minecraft:blackstone
setblock 15 280 290 minecraft:cobbled_deepslate
fill 15 280 291 15 280 293 minecraft:blackstone
setblock 15 280 294 minecraft:cobbled_deepslate
fill 15 280 295 15 280 297 minecraft:blackstone
setblock 15 280 298 minecraft:cobbled_deepslate
fill 15 280 299 15 280 301 minecraft:blackstone
setblock 15 280 302 minecraft:cobbled_deepslate
fill 15 280 303 15 280 305 minecraft:blackstone
setblock 15 280 306 minecraft:cobbled_deepslate
fill 15 280 307 15 280 309 minecraft:blackstone
setblock 15 280 310 minecraft:cobbled_deepslate
fill 15 280 311 15 280 313 minecraft:blackstone
setblock 15 280 314 minecraft:cobbled_deepslate
fill 15 280 315 15 280 316 minecraft:blackstone
fill 16 280 278 18 280 278 minecraft:blackstone
setblock 16 280 279 minecraft:cobbled_deepslate
fill 16 280 282 18 280 282 minecraft:blackstone
setblock 16 280 283 minecraft:cobbled_deepslate
fill 16 280 286 18 280 286 minecraft:blackstone
setblock 16 280 287 minecraft:cobbled_deepslate
fill 16 280 290 18 280 290 minecraft:blackstone
setblock 16 280 291 minecraft:cobbled_deepslate
fill 16 280 292 16 280 294 minecraft:blackstone
setblock 16 280 295 minecraft:cobbled_deepslate
fill 16 280 296 16 280 298 minecraft:blackstone
setblock 16 280 299 minecraft:cobbled_deepslate
fill 16 280 300 16 280 302 minecraft:blackstone
setblock 16 280 303 minecraft:cobbled_deepslate
fill 16 280 304 16 280 306 minecraft:blackstone
setblock 16 280 307 minecraft:cobbled_deepslate
fill 16 280 308 16 280 310 minecraft:blackstone
setblock 16 280 311 minecraft:cobbled_deepslate
fill 16 280 312 16 280 314 minecraft:blackstone
setblock 16 280 315 minecraft:cobbled_deepslate
setblock 16 280 316 minecraft:blackstone
setblock 17 280 276 minecraft:cobbled_deepslate
fill 17 280 279 19 280 279 minecraft:blackstone
setblock 17 280 280 minecraft:cobbled_deepslate
fill 17 280 283 19 280 283 minecraft:blackstone
setblock 17 280 284 minecraft:cobbled_deepslate
fill 17 280 287 19 280 287 minecraft:blackstone
setblock 17 280 288 minecraft:cobbled_deepslate
fill 17 280 291 19 280 291 minecraft:blackstone
setblock 17 280 292 minecraft:cobbled_deepslate
fill 17 280 293 17 280 294 minecraft:blackstone
setblock 17 280 296 minecraft:cobbled_deepslate
fill 17 280 297 17 280 299 minecraft:blackstone
setblock 17 280 300 minecraft:cobbled_deepslate
fill 17 280 301 17 280 303 minecraft:blackstone
setblock 17 280 304 minecraft:cobbled_deepslate
fill 17 280 305 17 280 307 minecraft:blackstone
setblock 17 280 308 minecraft:cobbled_deepslate
fill 17 280 309 17 280 311 minecraft:blackstone
setblock 17 280 312 minecraft:cobbled_deepslate
fill 17 280 313 17 280 315 minecraft:blackstone
setblock 17 280 316 minecraft:cobbled_deepslate
fill 18 280 276 20 280 276 minecraft:blackstone
setblock 18 280 277 minecraft:cobbled_deepslate
fill 18 280 280 20 280 280 minecraft:blackstone
setblock 18 280 281 minecraft:cobbled_deepslate
fill 18 280 284 20 280 284 minecraft:blackstone
setblock 18 280 285 minecraft:cobbled_deepslate
fill 18 280 288 20 280 288 minecraft:blackstone
setblock 18 280 289 minecraft:cobbled_deepslate
fill 18 280 292 19 281 292 minecraft:blackstone
fill 18 280 298 18 280 300 minecraft:blackstone
setblock 18 280 301 minecraft:cobbled_deepslate
fill 18 280 302 18 280 304 minecraft:blackstone
setblock 18 280 305 minecraft:cobbled_deepslate
fill 18 280 306 18 280 308 minecraft:blackstone
setblock 18 280 309 minecraft:cobbled_deepslate
fill 18 280 310 18 280 312 minecraft:blackstone
setblock 18 280 313 minecraft:cobbled_deepslate
fill 18 280 314 18 280 316 minecraft:blackstone
fill 19 280 277 21 280 277 minecraft:blackstone
setblock 19 280 278 minecraft:cobbled_deepslate
fill 19 280 281 21 280 281 minecraft:blackstone
setblock 19 280 282 minecraft:cobbled_deepslate
fill 19 280 285 21 280 285 minecraft:blackstone
setblock 19 280 286 minecraft:cobbled_deepslate
fill 19 280 289 21 280 289 minecraft:blackstone
setblock 19 280 290 minecraft:cobbled_deepslate
setblock 19 280 298 minecraft:cobbled_deepslate
fill 19 280 299 19 280 301 minecraft:blackstone
setblock 19 280 302 minecraft:cobbled_deepslate
fill 19 280 303 19 280 305 minecraft:blackstone
setblock 19 280 306 minecraft:cobbled_deepslate
fill 19 280 307 19 280 309 minecraft:blackstone
setblock 19 280 310 minecraft:cobbled_deepslate
fill 19 280 311 19 280 313 minecraft:blackstone
setblock 19 280 314 minecraft:cobbled_deepslate
fill 19 280 315 19 280 316 minecraft:blackstone
fill 20 280 278 22 280 278 minecraft:blackstone
setblock 20 280 279 minecraft:cobbled_deepslate
fill 20 280 282 22 280 282 minecraft:blackstone
setblock 20 280 283 minecraft:cobbled_deepslate
fill 20 280 286 22 280 286 minecraft:blackstone
setblock 20 280 287 minecraft:cobbled_deepslate
fill 20 280 290 22 280 290 minecraft:blackstone
setblock 20 280 291 minecraft:cobbled_deepslate
setblock 20 280 299 minecraft:cobbled_deepslate
fill 20 280 300 20 280 302 minecraft:blackstone
setblock 20 280 303 minecraft:cobbled_deepslate
fill 20 280 304 20 280 306 minecraft:blackstone
setblock 20 280 307 minecraft:cobbled_deepslate
fill 20 280 308 20 280 310 minecraft:blackstone
setblock 20 280 311 minecraft:cobbled_deepslate
fill 20 280 312 20 280 314 minecraft:blackstone
setblock 20 280 315 minecraft:cobbled_deepslate
setblock 20 280 316 minecraft:blackstone
setblock 21 280 276 minecraft:cobbled_deepslate
fill 21 280 279 23 280 279 minecraft:blackstone
setblock 21 280 280 minecraft:cobbled_deepslate
fill 21 280 283 23 280 283 minecraft:blackstone
setblock 21 280 284 minecraft:cobbled_deepslate
fill 21 280 287 23 280 287 minecraft:blackstone
setblock 21 280 288 minecraft:cobbled_deepslate
fill 21 280 291 23 280 291 minecraft:blackstone
setblock 21 280 292 minecraft:cobbled_deepslate
fill 21 280 298 22 280 299 minecraft:blackstone
setblock 21 280 300 minecraft:cobbled_deepslate
fill 21 280 301 21 280 303 minecraft:blackstone
setblock 21 280 304 minecraft:cobbled_deepslate
fill 21 280 305 21 280 307 minecraft:blackstone
setblock 21 280 308 minecraft:cobbled_deepslate
fill 21 280 309 21 280 311 minecraft:blackstone
setblock 21 280 312 minecraft:cobbled_deepslate
fill 21 280 313 21 280 315 minecraft:blackstone
setblock 21 280 316 minecraft:cobbled_deepslate
fill 22 280 276 24 280 276 minecraft:blackstone
setblock 22 280 277 minecraft:cobbled_deepslate
fill 22 280 280 24 280 280 minecraft:blackstone
setblock 22 280 281 minecraft:cobbled_deepslate
fill 22 280 284 24 280 284 minecraft:blackstone
setblock 22 280 285 minecraft:cobbled_deepslate
fill 22 280 288 24 280 288 minecraft:blackstone
setblock 22 280 289 minecraft:cobbled_deepslate
fill 22 280 292 24 280 292 minecraft:blackstone
fill 22 280 300 24 280 300 minecraft:blackstone
setblock 22 280 301 minecraft:cobbled_deepslate
fill 22 280 302 22 280 304 minecraft:blackstone
setblock 22 280 305 minecraft:cobbled_deepslate
fill 22 280 306 22 280 308 minecraft:blackstone
setblock 22 280 309 minecraft:cobbled_deepslate
fill 22 280 310 22 280 312 minecraft:blackstone
setblock 22 280 313 minecraft:cobbled_deepslate
fill 22 280 314 22 280 316 minecraft:blackstone
fill 23 280 277 25 280 277 minecraft:blackstone
setblock 23 280 278 minecraft:cobbled_deepslate
fill 23 280 281 25 280 281 minecraft:blackstone
setblock 23 280 282 minecraft:cobbled_deepslate
fill 23 280 285 25 280 285 minecraft:blackstone
setblock 23 280 286 minecraft:cobbled_deepslate
fill 23 280 289 25 280 289 minecraft:blackstone
setblock 23 280 290 minecraft:cobbled_deepslate
fill 23 280 293 25 280 293 minecraft:blackstone
setblock 23 280 294 minecraft:cobbled_deepslate
fill 23 280 296 24 280 297 minecraft:blackstone
setblock 23 280 298 minecraft:cobbled_deepslate
setblock 23 280 299 minecraft:blackstone
fill 23 280 301 25 280 301 minecraft:blackstone
setblock 23 280 302 minecraft:cobbled_deepslate
fill 23 280 303 23 280 305 minecraft:blackstone
setblock 23 280 306 minecraft:cobbled_deepslate
fill 23 280 307 23 280 309 minecraft:blackstone
setblock 23 280 310 minecraft:cobbled_deepslate
fill 23 280 311 23 280 313 minecraft:blackstone
setblock 23 280 314 minecraft:cobbled_deepslate
fill 23 280 315 23 280 316 minecraft:blackstone
fill 24 280 278 26 280 278 minecraft:blackstone
setblock 24 280 279 minecraft:cobbled_deepslate
fill 24 280 282 26 280 282 minecraft:blackstone
setblock 24 280 283 minecraft:cobbled_deepslate
fill 24 280 286 26 280 286 minecraft:blackstone
setblock 24 280 287 minecraft:cobbled_deepslate
fill 24 280 290 26 280 290 minecraft:blackstone
setblock 24 280 291 minecraft:cobbled_deepslate
fill 24 280 294 26 280 294 minecraft:blackstone
setblock 24 280 295 minecraft:cobbled_deepslate
fill 24 280 298 26 280 298 minecraft:blackstone
setblock 24 280 299 minecraft:cobbled_deepslate
fill 24 280 302 26 280 302 minecraft:blackstone
setblock 24 280 303 minecraft:cobbled_deepslate
fill 24 280 304 24 280 306 minecraft:blackstone
setblock 24 280 307 minecraft:cobbled_deepslate
fill 24 280 308 24 280 310 minecraft:blackstone
setblock 24 280 311 minecraft:cobbled_deepslate
fill 24 280 312 24 280 314 minecraft:blackstone
setblock 24 280 315 minecraft:cobbled_deepslate
setblock 24 280 316 minecraft:blackstone
setblock 25 280 276 minecraft:cobbled_deepslate
fill 25 280 279 27 280 279 minecraft:blackstone
setblock 25 280 280 minecraft:cobbled_deepslate
fill 25 280 283 27 280 283 minecraft:blackstone
setblock 25 280 284 minecraft:cobbled_deepslate
fill 25 280 287 27 280 287 minecraft:blackstone
setblock 25 280 288 minecraft:cobbled_deepslate
fill 25 280 291 27 280 291 minecraft:blackstone
setblock 25 280 292 minecraft:cobbled_deepslate
fill 25 280 295 27 280 295 minecraft:blackstone
setblock 25 280 296 minecraft:cobbled_deepslate
setblock 25 280 297 minecraft:blackstone
fill 25 280 299 27 280 299 minecraft:blackstone
setblock 25 280 300 minecraft:cobbled_deepslate
fill 25 280 303 27 280 303 minecraft:blackstone
setblock 25 280 304 minecraft:cobbled_deepslate
fill 25 280 305 25 280 307 minecraft:blackstone
setblock 25 280 308 minecraft:cobbled_deepslate
fill 25 280 309 25 280 311 minecraft:blackstone
setblock 25 280 312 minecraft:cobbled_deepslate
fill 25 280 313 25 280 315 minecraft:blackstone
setblock 25 280 316 minecraft:cobbled_deepslate
fill 26 280 276 28 280 276 minecraft:blackstone
setblock 26 280 277 minecraft:cobbled_deepslate
fill 26 280 280 28 280 280 minecraft:blackstone
setblock 26 280 281 minecraft:cobbled_deepslate
fill 26 280 284 28 280 284 minecraft:blackstone
setblock 26 280 285 minecraft:cobbled_deepslate
fill 26 280 288 28 280 288 minecraft:blackstone
setblock 26 280 289 minecraft:cobbled_deepslate
fill 26 280 292 28 280 292 minecraft:blackstone
setblock 26 280 293 minecraft:cobbled_deepslate
fill 26 280 296 28 280 296 minecraft:blackstone
setblock 26 280 297 minecraft:cobbled_deepslate
fill 26 280 300 28 280 300 minecraft:blackstone
setblock 26 280 301 minecraft:cobbled_deepslate
fill 26 280 304 28 280 304 minecraft:blackstone
setblock 26 280 305 minecraft:cobbled_deepslate
fill 26 280 306 26 280 308 minecraft:blackstone
setblock 26 280 309 minecraft:cobbled_deepslate
fill 26 280 310 26 280 312 minecraft:blackstone
setblock 26 280 313 minecraft:cobbled_deepslate
fill 26 280 314 26 280 316 minecraft:blackstone
fill 27 280 277 29 280 277 minecraft:blackstone
setblock 27 280 278 minecraft:cobbled_deepslate
fill 27 280 281 29 280 281 minecraft:blackstone
setblock 27 280 282 minecraft:cobbled_deepslate
fill 27 280 285 29 280 285 minecraft:blackstone
setblock 27 280 286 minecraft:cobbled_deepslate
fill 27 280 289 29 280 289 minecraft:blackstone
setblock 27 280 290 minecraft:cobbled_deepslate
fill 27 280 293 29 280 293 minecraft:blackstone
setblock 27 280 294 minecraft:cobbled_deepslate
fill 27 280 297 29 280 297 minecraft:blackstone
setblock 27 280 298 minecraft:cobbled_deepslate
fill 27 280 301 29 280 301 minecraft:blackstone
setblock 27 280 302 minecraft:cobbled_deepslate
fill 27 280 305 29 280 305 minecraft:blackstone
setblock 27 280 306 minecraft:cobbled_deepslate
fill 27 280 307 27 280 309 minecraft:blackstone
setblock 27 280 310 minecraft:cobbled_deepslate
fill 27 280 311 27 280 313 minecraft:blackstone
setblock 27 280 314 minecraft:cobbled_deepslate
fill 27 280 315 27 280 316 minecraft:blackstone
fill 28 280 278 30 280 278 minecraft:blackstone
setblock 28 280 279 minecraft:cobbled_deepslate
fill 28 280 282 30 280 282 minecraft:blackstone
setblock 28 280 283 minecraft:cobbled_deepslate
fill 28 280 286 30 280 286 minecraft:blackstone
setblock 28 280 287 minecraft:cobbled_deepslate
fill 28 280 290 30 280 290 minecraft:blackstone
setblock 28 280 291 minecraft:cobbled_deepslate
fill 28 280 294 30 280 294 minecraft:blackstone
setblock 28 280 295 minecraft:cobbled_deepslate
fill 28 280 298 30 280 298 minecraft:blackstone
setblock 28 280 299 minecraft:cobbled_deepslate
fill 28 280 302 30 280 302 minecraft:blackstone
setblock 28 280 303 minecraft:cobbled_deepslate
fill 28 280 306 30 280 306 minecraft:blackstone
setblock 28 280 307 minecraft:cobbled_deepslate
fill 28 280 308 28 280 310 minecraft:blackstone
setblock 28 280 311 minecraft:cobbled_deepslate
fill 28 280 312 28 280 314 minecraft:blackstone
setblock 28 280 315 minecraft:cobbled_deepslate
setblock 28 280 316 minecraft:blackstone
setblock 29 280 276 minecraft:cobbled_deepslate
fill 29 280 279 31 280 279 minecraft:blackstone
setblock 29 280 280 minecraft:cobbled_deepslate
fill 29 280 283 31 280 283 minecraft:blackstone
setblock 29 280 284 minecraft:cobbled_deepslate
fill 29 280 287 31 280 287 minecraft:blackstone
setblock 29 280 288 minecraft:cobbled_deepslate
fill 29 280 291 31 280 291 minecraft:blackstone
setblock 29 280 292 minecraft:cobbled_deepslate
fill 29 280 295 31 280 295 minecraft:blackstone
setblock 29 280 296 minecraft:cobbled_deepslate
fill 29 280 299 31 280 299 minecraft:blackstone
setblock 29 280 300 minecraft:cobbled_deepslate
fill 29 280 303 31 280 303 minecraft:blackstone
setblock 29 280 304 minecraft:cobbled_deepslate
fill 29 280 307 31 280 307 minecraft:blackstone
setblock 29 280 308 minecraft:cobbled_deepslate
fill 29 280 309 29 280 311 minecraft:blackstone
setblock 29 280 312 minecraft:cobbled_deepslate
fill 29 280 313 29 280 315 minecraft:blackstone
setblock 29 280 316 minecraft:cobbled_deepslate
fill 30 280 276 32 280 276 minecraft:blackstone
setblock 30 280 277 minecraft:cobbled_deepslate
fill 30 280 280 32 280 280 minecraft:blackstone
setblock 30 280 281 minecraft:cobbled_deepslate
fill 30 280 284 32 280 284 minecraft:blackstone
setblock 30 280 285 minecraft:cobbled_deepslate
fill 30 280 288 32 280 288 minecraft:blackstone
setblock 30 280 289 minecraft:cobbled_deepslate
fill 30 280 292 32 280 292 minecraft:blackstone
setblock 30 280 293 minecraft:cobbled_deepslate
fill 30 280 296 32 280 296 minecraft:blackstone
setblock 30 280 297 minecraft:cobbled_deepslate
fill 30 280 300 32 280 300 minecraft:blackstone
setblock 30 280 301 minecraft:cobbled_deepslate
fill 30 280 304 32 280 304 minecraft:blackstone
setblock 30 280 305 minecraft:cobbled_deepslate
fill 30 280 308 32 280 308 minecraft:blackstone
setblock 30 280 309 minecraft:cobbled_deepslate
fill 30 280 310 30 280 312 minecraft:blackstone
setblock 30 280 313 minecraft:cobbled_deepslate
fill 30 280 314 30 280 316 minecraft:blackstone
fill 31 280 277 33 280 277 minecraft:blackstone
setblock 31 280 278 minecraft:cobbled_deepslate
fill 31 280 281 33 280 281 minecraft:blackstone
setblock 31 280 282 minecraft:cobbled_deepslate
fill 31 280 285 33 280 285 minecraft:blackstone
setblock 31 280 286 minecraft:cobbled_deepslate
fill 31 280 289 33 280 289 minecraft:blackstone
setblock 31 280 290 minecraft:cobbled_deepslate
fill 31 280 293 33 280 293 minecraft:blackstone
setblock 31 280 294 minecraft:cobbled_deepslate
fill 31 280 297 33 280 297 minecraft:blackstone
setblock 31 280 298 minecraft:cobbled_deepslate
fill 31 280 301 33 280 301 minecraft:blackstone
setblock 31 280 302 minecraft:cobbled_deepslate
fill 31 280 305 33 280 305 minecraft:blackstone
setblock 31 280 306 minecraft:cobbled_deepslate
fill 31 280 309 33 280 309 minecraft:blackstone
setblock 31 280 310 minecraft:cobbled_deepslate
fill 31 280 311 31 280 313 minecraft:blackstone
setblock 31 280 314 minecraft:cobbled_deepslate
fill 31 280 315 31 280 316 minecraft:blackstone
fill 32 280 278 34 280 278 minecraft:blackstone
setblock 32 280 279 minecraft:cobbled_deepslate
fill 32 280 282 34 280 282 minecraft:blackstone
setblock 32 280 283 minecraft:cobbled_deepslate
fill 32 280 286 34 280 286 minecraft:blackstone
setblock 32 280 287 minecraft:cobbled_deepslate
fill 32 280 290 34 280 290 minecraft:blackstone
setblock 32 280 291 minecraft:cobbled_deepslate
fill 32 280 294 34 280 294 minecraft:blackstone
setblock 32 280 295 minecraft:cobbled_deepslate
fill 32 280 298 34 280 298 minecraft:blackstone
setblock 32 280 299 minecraft:cobbled_deepslate
fill 32 280 302 34 280 302 minecraft:blackstone
setblock 32 280 303 minecraft:cobbled_deepslate
fill 32 280 306 34 280 306 minecraft:blackstone
setblock 32 280 307 minecraft:cobbled_deepslate
fill 32 280 310 34 280 310 minecraft:blackstone
setblock 32 280 311 minecraft:cobbled_deepslate
fill 32 280 312 32 280 314 minecraft:blackstone
setblock 32 280 315 minecraft:cobbled_deepslate
setblock 32 280 316 minecraft:blackstone
setblock 33 280 276 minecraft:cobbled_deepslate
fill 33 280 279 35 280 279 minecraft:blackstone
setblock 33 280 280 minecraft:cobbled_deepslate
fill 33 280 283 35 280 283 minecraft:blackstone
setblock 33 280 284 minecraft:cobbled_deepslate
fill 33 280 287 35 280 287 minecraft:blackstone
setblock 33 280 288 minecraft:cobbled_deepslate
fill 33 280 291 35 280 291 minecraft:blackstone
setblock 33 280 292 minecraft:cobbled_deepslate
fill 33 280 295 35 280 295 minecraft:blackstone
setblock 33 280 296 minecraft:cobbled_deepslate
fill 33 280 299 35 280 299 minecraft:blackstone
setblock 33 280 300 minecraft:cobbled_deepslate
fill 33 280 303 35 280 303 minecraft:blackstone
setblock 33 280 304 minecraft:cobbled_deepslate
fill 33 280 307 35 280 307 minecraft:blackstone
setblock 33 280 308 minecraft:cobbled_deepslate
fill 33 280 311 35 280 311 minecraft:blackstone
setblock 33 280 312 minecraft:cobbled_deepslate
fill 33 280 313 33 280 315 minecraft:blackstone
setblock 33 280 316 minecraft:cobbled_deepslate
fill 34 280 276 36 280 276 minecraft:blackstone
setblock 34 280 277 minecraft:cobbled_deepslate
fill 34 280 280 36 280 280 minecraft:blackstone
setblock 34 280 281 minecraft:cobbled_deepslate
fill 34 280 284 36 280 284 minecraft:blackstone
setblock 34 280 285 minecraft:cobbled_deepslate
fill 34 280 288 36 280 288 minecraft:blackstone
setblock 34 280 289 minecraft:cobbled_deepslate
fill 34 280 292 36 280 292 minecraft:blackstone
setblock 34 280 293 minecraft:cobbled_deepslate
fill 34 280 296 36 280 296 minecraft:blackstone
setblock 34 280 297 minecraft:cobbled_deepslate
fill 34 280 300 36 280 300 minecraft:blackstone
setblock 34 280 301 minecraft:cobbled_deepslate
fill 34 280 304 36 280 304 minecraft:blackstone
setblock 34 280 305 minecraft:cobbled_deepslate
fill 34 280 308 36 280 308 minecraft:blackstone
setblock 34 280 309 minecraft:cobbled_deepslate
fill 34 280 312 36 280 312 minecraft:blackstone
setblock 34 280 313 minecraft:cobbled_deepslate
fill 34 280 314 34 280 316 minecraft:blackstone
fill 35 280 277 37 280 277 minecraft:blackstone
setblock 35 280 278 minecraft:cobbled_deepslate
fill 35 280 281 37 280 281 minecraft:blackstone
setblock 35 280 282 minecraft:cobbled_deepslate
fill 35 280 285 37 280 285 minecraft:blackstone
setblock 35 280 286 minecraft:cobbled_deepslate
fill 35 280 289 37 280 289 minecraft:blackstone
setblock 35 280 290 minecraft:cobbled_deepslate
fill 35 280 293 37 280 293 minecraft:blackstone
setblock 35 280 294 minecraft:cobbled_deepslate
fill 35 280 297 37 280 297 minecraft:blackstone
setblock 35 280 298 minecraft:cobbled_deepslate
fill 35 280 301 37 280 301 minecraft:blackstone
setblock 35 280 302 minecraft:cobbled_deepslate
fill 35 280 305 37 280 305 minecraft:blackstone
setblock 35 280 306 minecraft:cobbled_deepslate
fill 35 280 309 37 280 309 minecraft:blackstone
setblock 35 280 310 minecraft:cobbled_deepslate
fill 35 280 313 37 280 313 minecraft:blackstone
setblock 35 280 314 minecraft:cobbled_deepslate
fill 35 280 315 35 280 316 minecraft:blackstone
fill 36 280 278 38 280 278 minecraft:blackstone
setblock 36 280 279 minecraft:cobbled_deepslate
fill 36 280 282 38 280 282 minecraft:blackstone
setblock 36 280 283 minecraft:cobbled_deepslate
fill 36 280 286 38 280 286 minecraft:blackstone
setblock 36 280 287 minecraft:cobbled_deepslate
fill 36 280 290 38 280 290 minecraft:blackstone
setblock 36 280 291 minecraft:cobbled_deepslate
fill 36 280 294 38 280 294 minecraft:blackstone
setblock 36 280 295 minecraft:cobbled_deepslate
fill 36 280 298 38 280 298 minecraft:blackstone
setblock 36 280 299 minecraft:cobbled_deepslate
fill 36 280 302 38 280 302 minecraft:blackstone
setblock 36 280 303 minecraft:cobbled_deepslate
fill 36 280 306 38 280 306 minecraft:blackstone
setblock 36 280 307 minecraft:cobbled_deepslate
fill 36 280 310 38 280 310 minecraft:blackstone
setblock 36 280 311 minecraft:cobbled_deepslate
fill 36 280 314 38 280 314 minecraft:blackstone
setblock 36 280 315 minecraft:cobbled_deepslate
setblock 36 280 316 minecraft:blackstone
setblock 37 280 276 minecraft:cobbled_deepslate
fill 37 280 279 39 280 279 minecraft:blackstone
setblock 37 280 280 minecraft:cobbled_deepslate
fill 37 280 283 39 280 283 minecraft:blackstone
setblock 37 280 284 minecraft:cobbled_deepslate
fill 37 280 287 39 280 287 minecraft:blackstone
setblock 37 280 288 minecraft:cobbled_deepslate
fill 37 280 291 39 280 291 minecraft:blackstone
setblock 37 280 292 minecraft:cobbled_deepslate
fill 37 280 295 39 280 295 minecraft:blackstone
setblock 37 280 296 minecraft:cobbled_deepslate
fill 37 280 299 39 280 299 minecraft:blackstone
setblock 37 280 300 minecraft:cobbled_deepslate
fill 37 280 303 39 280 303 minecraft:blackstone
setblock 37 280 304 minecraft:cobbled_deepslate
fill 37 280 307 39 280 307 minecraft:blackstone
setblock 37 280 308 minecraft:cobbled_deepslate
fill 37 280 311 39 280 311 minecraft:blackstone
setblock 37 280 312 minecraft:cobbled_deepslate
fill 37 280 315 39 280 315 minecraft:blackstone
setblock 37 280 316 minecraft:cobbled_deepslate
fill 38 280 276 40 280 276 minecraft:blackstone
setblock 38 280 277 minecraft:cobbled_deepslate
fill 38 280 280 40 280 280 minecraft:blackstone
setblock 38 280 281 minecraft:cobbled_deepslate
fill 38 280 284 40 280 284 minecraft:blackstone
setblock 38 280 285 minecraft:cobbled_deepslate
fill 38 280 288 40 280 288 minecraft:blackstone
setblock 38 280 289 minecraft:cobbled_deepslate
fill 38 280 292 40 280 292 minecraft:blackstone
setblock 38 280 293 minecraft:cobbled_deepslate
fill 38 280 296 40 280 296 minecraft:blackstone
setblock 38 280 297 minecraft:cobbled_deepslate
fill 38 280 300 40 280 300 minecraft:blackstone
setblock 38 280 301 minecraft:cobbled_deepslate
fill 38 280 304 40 280 304 minecraft:blackstone
setblock 38 280 305 minecraft:cobbled_deepslate
fill 38 280 308 40 280 308 minecraft:blackstone
setblock 38 280 309 minecraft:cobbled_deepslate
fill 38 280 312 40 280 312 minecraft:blackstone
setblock 38 280 313 minecraft:cobbled_deepslate
fill 38 280 316 40 280 316 minecraft:blackstone
fill 39 280 277 41 280 277 minecraft:blackstone
setblock 39 280 278 minecraft:cobbled_deepslate
fill 39 280 281 41 280 281 minecraft:blackstone
setblock 39 280 282 minecraft:cobbled_deepslate
fill 39 280 285 41 280 285 minecraft:blackstone
setblock 39 280 286 minecraft:cobbled_deepslate
fill 39 280 289 41 280 289 minecraft:blackstone
setblock 39 280 290 minecraft:cobbled_deepslate
fill 39 280 293 41 280 293 minecraft:blackstone
setblock 39 280 294 minecraft:cobbled_deepslate
fill 39 280 297 41 280 297 minecraft:blackstone
setblock 39 280 298 minecraft:cobbled_deepslate
fill 39 280 301 41 280 301 minecraft:blackstone
setblock 39 280 302 minecraft:cobbled_deepslate
fill 39 280 305 41 280 305 minecraft:blackstone
setblock 39 280 306 minecraft:cobbled_deepslate
fill 39 280 309 41 280 309 minecraft:blackstone
setblock 39 280 310 minecraft:cobbled_deepslate
schedule function dropper:buildpart/60_6 1t
