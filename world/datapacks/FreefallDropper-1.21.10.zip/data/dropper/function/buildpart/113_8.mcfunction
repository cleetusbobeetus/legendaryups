fill 258 208 502 259 210 502 minecraft:brown_terracotta
setblock 259 208 504 minecraft:brown_terracotta
setblock 260 208 464 minecraft:bone_block
setblock 260 208 503 minecraft:brown_terracotta
setblock 260 208 504 minecraft:bone_block
fill 261 208 464 261 211 464 minecraft:brown_terracotta
setblock 261 208 503 minecraft:bone_block
fill 261 208 504 261 211 504 minecraft:brown_terracotta
setblock 262 208 466 minecraft:light[level=12]
setblock 262 208 474 minecraft:light[level=12]
setblock 262 208 482 minecraft:light[level=12]
setblock 262 208 490 minecraft:light[level=12]
setblock 262 208 498 minecraft:light[level=12]
fill 262 208 503 262 210 503 minecraft:brown_terracotta
setblock 264 208 464 minecraft:brown_terracotta
setblock 264 208 504 minecraft:brown_terracotta
setblock 265 208 464 minecraft:bone_block
setblock 269 208 464 minecraft:brown_terracotta
setblock 270 208 464 minecraft:bone_block
setblock 270 208 466 minecraft:light[level=12]
setblock 270 208 474 minecraft:light[level=12]
setblock 270 208 482 minecraft:light[level=12]
setblock 270 208 490 minecraft:light[level=12]
setblock 270 208 498 minecraft:light[level=12]
setblock 270 208 504 minecraft:bone_block
fill 271 208 464 271 211 464 minecraft:brown_terracotta
fill 271 208 504 271 211 504 minecraft:brown_terracotta
fill 272 208 503 273 210 503 minecraft:brown_terracotta
setblock 273 208 465 minecraft:brown_terracotta
setblock 274 208 465 minecraft:bone_block
setblock 274 208 474 minecraft:brown_terracotta
setblock 274 208 475 minecraft:bone_block
fill 274 208 476 274 211 476 minecraft:brown_terracotta
setblock 274 208 479 minecraft:brown_terracotta
setblock 274 208 500 minecraft:bone_block
fill 274 208 501 274 210 502 minecraft:brown_terracotta
setblock 275 208 464 minecraft:bone_block
fill 275 208 465 275 211 465 minecraft:brown_terracotta
setblock 275 208 469 minecraft:bone_block
fill 275 208 470 275 211 470 minecraft:brown_terracotta
setblock 275 208 474 minecraft:bone_block
fill 275 208 475 275 211 475 minecraft:brown_terracotta
setblock 275 208 478 minecraft:brown_terracotta
setblock 275 208 479 minecraft:bone_block
fill 275 208 480 275 211 480 minecraft:brown_terracotta
fill 275 208 482 275 208 483 minecraft:brown_terracotta
fill 275 208 496 275 208 498 minecraft:brown_terracotta
setblock 275 208 499 minecraft:bone_block
fill 275 208 500 275 211 500 minecraft:brown_terracotta
setblock 275 208 504 minecraft:bone_block
fill 276 208 464 276 211 464 minecraft:brown_terracotta
setblock 276 208 468 minecraft:bone_block
fill 276 208 469 276 211 469 minecraft:brown_terracotta
setblock 276 208 473 minecraft:bone_block
fill 276 208 474 276 211 474 minecraft:brown_terracotta
setblock 276 208 478 minecraft:bone_block
fill 276 208 479 276 211 479 minecraft:brown_terracotta
setblock 276 208 483 minecraft:bone_block
fill 276 208 484 276 209 486 minecraft:brown_terracotta
setblock 276 208 492 minecraft:brown_terracotta
setblock 276 208 493 minecraft:bone_block
fill 276 208 494 276 211 494 minecraft:brown_terracotta
setblock 276 208 498 minecraft:bone_block
fill 276 208 499 276 211 499 minecraft:brown_terracotta
setblock 276 208 503 minecraft:bone_block
fill 276 208 504 276 211 504 minecraft:brown_terracotta
setblock 236 209 467 minecraft:bone_block
fill 236 209 468 236 212 468 minecraft:brown_terracotta
setblock 236 209 472 minecraft:bone_block
fill 236 209 473 236 212 473 minecraft:brown_terracotta
setblock 236 209 477 minecraft:bone_block
fill 236 209 478 236 212 478 minecraft:brown_terracotta
setblock 236 209 481 minecraft:brown_terracotta
setblock 236 209 482 minecraft:bone_block
fill 236 209 483 236 212 483 minecraft:brown_terracotta
setblock 236 209 486 minecraft:brown_terracotta
setblock 236 209 487 minecraft:bone_block
fill 236 209 488 236 212 488 minecraft:brown_terracotta
setblock 236 209 492 minecraft:bone_block
fill 236 209 493 236 212 493 minecraft:brown_terracotta
setblock 236 209 497 minecraft:bone_block
fill 236 209 498 236 212 498 minecraft:brown_terracotta
setblock 236 209 501 minecraft:brown_terracotta
setblock 236 209 502 minecraft:bone_block
fill 236 209 503 236 212 503 minecraft:brown_terracotta
setblock 237 209 465 minecraft:brown_terracotta
setblock 237 209 466 minecraft:bone_block
fill 237 209 467 237 211 467 minecraft:brown_terracotta
setblock 237 209 476 minecraft:bone_block
fill 237 209 477 237 212 477 minecraft:brown_terracotta
setblock 237 209 481 minecraft:bone_block
fill 237 209 482 238 211 482 minecraft:brown_terracotta
setblock 237 209 485 minecraft:brown_terracotta
setblock 237 209 486 minecraft:bone_block
fill 237 209 487 237 212 487 minecraft:brown_terracotta
setblock 237 209 490 minecraft:brown_terracotta
setblock 237 209 491 minecraft:bone_block
fill 237 209 492 237 212 492 minecraft:brown_terracotta
setblock 237 209 496 minecraft:bone_block
fill 237 209 497 237 212 497 minecraft:brown_terracotta
setblock 237 209 501 minecraft:bone_block
fill 237 209 502 237 212 502 minecraft:brown_terracotta
setblock 238 209 465 minecraft:bone_block
setblock 238 209 479 minecraft:brown_terracotta
setblock 238 209 480 minecraft:bone_block
fill 238 209 481 238 212 481 minecraft:brown_terracotta
setblock 238 209 495 minecraft:bone_block
fill 238 209 496 238 212 496 minecraft:brown_terracotta
setblock 238 209 500 minecraft:bone_block
fill 238 209 501 238 212 501 minecraft:brown_terracotta
setblock 239 209 464 minecraft:bone_block
fill 239 209 465 239 212 465 minecraft:brown_terracotta
setblock 239 209 499 minecraft:bone_block
fill 239 209 500 239 212 500 minecraft:brown_terracotta
setblock 239 209 504 minecraft:bone_block
fill 240 209 464 240 212 464 minecraft:brown_terracotta
setblock 240 209 503 minecraft:bone_block
fill 240 209 504 240 212 504 minecraft:brown_terracotta
setblock 241 209 501 minecraft:brown_terracotta
setblock 241 209 502 minecraft:bone_block
fill 241 209 503 241 212 503 minecraft:brown_terracotta
setblock 242 209 501 minecraft:bone_block
fill 242 209 502 242 212 502 minecraft:brown_terracotta
setblock 243 209 464 minecraft:brown_terracotta
setblock 244 209 504 minecraft:bone_block
setblock 245 209 503 minecraft:bone_block
fill 245 209 504 245 212 504 minecraft:brown_terracotta
fill 246 209 503 247 211 503 minecraft:brown_terracotta
setblock 249 209 504 minecraft:bone_block
setblock 250 209 503 minecraft:bone_block
fill 250 209 504 253 209 504 minecraft:brown_terracotta
fill 251 209 503 254 209 503 minecraft:brown_terracotta
setblock 254 209 464 minecraft:bone_block
fill 254 209 502 255 209 502 minecraft:brown_terracotta
setblock 254 209 504 minecraft:bone_block
fill 255 209 464 258 209 464 minecraft:brown_terracotta
setblock 255 209 503 minecraft:bone_block
fill 255 209 504 255 212 504 minecraft:brown_terracotta
setblock 256 209 502 minecraft:bone_block
fill 256 209 503 256 212 503 minecraft:brown_terracotta
fill 257 209 502 257 211 502 minecraft:brown_terracotta
setblock 259 209 464 minecraft:bone_block
fill 259 209 465 259 212 465 minecraft:brown_terracotta
setblock 259 209 504 minecraft:bone_block
fill 260 209 464 260 212 464 minecraft:brown_terracotta
setblock 260 209 503 minecraft:bone_block
fill 260 209 504 260 212 504 minecraft:brown_terracotta
fill 261 209 503 261 211 503 minecraft:brown_terracotta
setblock 264 209 464 minecraft:bone_block
setblock 264 209 504 minecraft:bone_block
fill 265 209 464 268 209 464 minecraft:brown_terracotta
fill 265 209 504 268 209 504 minecraft:brown_terracotta
setblock 269 209 464 minecraft:bone_block
setblock 269 209 504 minecraft:bone_block
fill 270 209 464 270 212 464 minecraft:brown_terracotta
fill 270 209 504 270 212 504 minecraft:brown_terracotta
fill 271 209 503 271 212 503 minecraft:brown_terracotta
setblock 272 209 465 minecraft:brown_terracotta
setblock 273 209 464 minecraft:brown_terracotta
setblock 273 209 465 minecraft:bone_block
fill 273 209 502 273 211 502 minecraft:brown_terracotta
setblock 273 209 504 minecraft:brown_terracotta
setblock 274 209 464 minecraft:bone_block
fill 274 209 465 274 212 465 minecraft:brown_terracotta
setblock 274 209 474 minecraft:bone_block
fill 274 209 475 274 210 475 minecraft:brown_terracotta
setblock 274 209 479 minecraft:bone_block
fill 274 209 480 274 212 480 minecraft:brown_terracotta
setblock 274 209 499 minecraft:bone_block
fill 274 209 500 274 212 500 minecraft:brown_terracotta
setblock 274 209 504 minecraft:bone_block
fill 275 209 464 275 212 464 minecraft:brown_terracotta
fill 275 209 466 275 209 467 minecraft:brown_terracotta
setblock 275 209 468 minecraft:bone_block
fill 275 209 469 275 212 469 minecraft:brown_terracotta
setblock 275 209 473 minecraft:bone_block
fill 275 209 474 275 212 474 minecraft:brown_terracotta
setblock 275 209 478 minecraft:bone_block
fill 275 209 479 275 212 479 minecraft:brown_terracotta
setblock 275 209 482 minecraft:brown_terracotta
setblock 275 209 483 minecraft:bone_block
fill 275 209 484 275 212 484 minecraft:brown_terracotta
fill 275 209 496 275 209 497 minecraft:brown_terracotta
setblock 275 209 498 minecraft:bone_block
fill 275 209 499 275 212 499 minecraft:brown_terracotta
setblock 275 209 502 minecraft:brown_terracotta
setblock 275 209 503 minecraft:bone_block
fill 275 209 504 275 212 504 minecraft:brown_terracotta
setblock 276 209 467 minecraft:bone_block
fill 276 209 468 276 212 468 minecraft:brown_terracotta
setblock 276 209 472 minecraft:bone_block
fill 276 209 473 276 212 473 minecraft:brown_terracotta
setblock 276 209 477 minecraft:bone_block
fill 276 209 478 276 212 478 minecraft:brown_terracotta
setblock 276 209 482 minecraft:bone_block
fill 276 209 483 276 212 483 minecraft:brown_terracotta
setblock 276 209 487 minecraft:bone_block
fill 276 209 488 276 212 488 minecraft:brown_terracotta
setblock 276 209 491 minecraft:brown_terracotta
setblock 276 209 492 minecraft:bone_block
fill 276 209 493 276 212 493 minecraft:brown_terracotta
setblock 276 209 497 minecraft:bone_block
fill 276 209 498 276 212 498 minecraft:brown_terracotta
setblock 276 209 502 minecraft:bone_block
fill 276 209 503 276 212 503 minecraft:brown_terracotta
setblock 236 210 466 minecraft:bone_block
fill 236 210 467 236 213 467 minecraft:brown_terracotta
setblock 236 210 471 minecraft:bone_block
fill 236 210 472 236 212 472 minecraft:brown_terracotta
setblock 236 210 476 minecraft:bone_block
fill 236 210 477 236 213 477 minecraft:brown_terracotta
setblock 236 210 481 minecraft:bone_block
fill 236 210 482 236 213 482 minecraft:brown_terracotta
setblock 236 210 486 minecraft:bone_block
fill 236 210 487 236 213 487 minecraft:brown_terracotta
setblock 236 210 491 minecraft:bone_block
fill 236 210 492 236 213 492 minecraft:brown_terracotta
setblock 236 210 496 minecraft:bone_block
fill 236 210 497 236 213 497 minecraft:brown_terracotta
setblock 236 210 501 minecraft:bone_block
fill 236 210 502 236 213 502 minecraft:brown_terracotta
setblock 237 210 465 minecraft:bone_block
fill 237 210 466 237 213 466 minecraft:brown_terracotta
setblock 237 210 475 minecraft:bone_block
fill 237 210 476 237 211 476 minecraft:brown_terracotta
setblock 237 210 480 minecraft:bone_block
fill 237 210 481 237 213 481 minecraft:brown_terracotta
setblock 237 210 485 minecraft:bone_block
fill 237 210 486 237 213 486 minecraft:brown_terracotta
fill 237 210 488 237 210 489 minecraft:brown_terracotta
setblock 237 210 490 minecraft:bone_block
fill 237 210 491 237 213 491 minecraft:brown_terracotta
fill 237 210 493 237 211 493 minecraft:brown_terracotta
setblock 237 210 495 minecraft:bone_block
fill 237 210 496 237 213 496 minecraft:brown_terracotta
setblock 237 210 500 minecraft:bone_block
fill 237 210 501 237 213 501 minecraft:brown_terracotta
setblock 238 210 464 minecraft:bone_block
fill 238 210 465 238 213 465 minecraft:brown_terracotta
setblock 238 210 479 minecraft:bone_block
fill 238 210 480 238 211 480 minecraft:brown_terracotta
setblock 238 210 483 minecraft:brown_terracotta
setblock 238 210 494 minecraft:bone_block
fill 238 210 495 238 211 495 minecraft:brown_terracotta
setblock 238 210 499 minecraft:bone_block
fill 238 210 500 238 213 500 minecraft:brown_terracotta
setblock 238 210 504 minecraft:bone_block
fill 239 210 464 239 213 464 minecraft:brown_terracotta
setblock 239 210 498 minecraft:bone_block
fill 239 210 499 239 212 499 minecraft:brown_terracotta
setblock 239 210 503 minecraft:bone_block
fill 239 210 504 239 213 504 minecraft:brown_terracotta
setblock 240 210 502 minecraft:bone_block
fill 240 210 503 240 213 503 minecraft:brown_terracotta
setblock 241 210 501 minecraft:bone_block
fill 241 210 502 241 213 502 minecraft:brown_terracotta
setblock 242 210 501 minecraft:brown_terracotta
setblock 243 210 464 minecraft:bone_block
setblock 243 210 504 minecraft:bone_block
setblock 244 210 503 minecraft:bone_block
fill 244 210 504 244 213 504 minecraft:brown_terracotta
fill 245 210 503 245 212 503 minecraft:brown_terracotta
setblock 247 210 504 minecraft:brown_terracotta
setblock 248 210 503 minecraft:brown_terracotta
setblock 248 210 504 minecraft:bone_block
setblock 249 210 503 minecraft:bone_block
fill 249 210 504 252 210 504 minecraft:brown_terracotta
fill 250 210 503 253 210 503 minecraft:brown_terracotta
setblock 253 210 464 minecraft:bone_block
setblock 253 210 504 minecraft:bone_block
fill 254 210 464 257 210 464 minecraft:brown_terracotta
setblock 254 210 502 minecraft:brown_terracotta
setblock 254 210 503 minecraft:bone_block
fill 254 210 504 254 213 504 minecraft:brown_terracotta
setblock 255 210 502 minecraft:bone_block
fill 255 210 503 255 213 503 minecraft:brown_terracotta
fill 256 210 502 256 212 502 minecraft:brown_terracotta
setblock 257 210 465 minecraft:bone_block
setblock 258 210 464 minecraft:bone_block
fill 258 210 465 258 213 465 minecraft:brown_terracotta
setblock 258 210 504 minecraft:bone_block
fill 259 210 464 259 213 464 minecraft:brown_terracotta
setblock 259 210 503 minecraft:bone_block
fill 259 210 504 259 213 504 minecraft:brown_terracotta
fill 260 210 465 260 211 465 minecraft:brown_terracotta
fill 260 210 503 260 212 503 minecraft:brown_terracotta
setblock 262 210 464 minecraft:brown_terracotta
setblock 262 210 504 minecraft:brown_terracotta
setblock 263 210 464 minecraft:bone_block
setblock 263 210 504 minecraft:bone_block
fill 264 210 464 267 210 464 minecraft:brown_terracotta
fill 264 210 504 267 210 504 minecraft:brown_terracotta
setblock 268 210 464 minecraft:bone_block
setblock 268 210 504 minecraft:bone_block
fill 269 210 464 269 213 464 minecraft:brown_terracotta
fill 269 210 504 269 213 504 minecraft:brown_terracotta
fill 270 210 503 270 213 503 minecraft:brown_terracotta
setblock 271 210 465 minecraft:brown_terracotta
setblock 272 210 465 minecraft:bone_block
setblock 273 210 464 minecraft:bone_block
fill 273 210 465 273 213 465 minecraft:brown_terracotta
setblock 273 210 504 minecraft:bone_block
fill 274 210 464 274 213 464 minecraft:brown_terracotta
fill 274 210 466 275 210 466 minecraft:brown_terracotta
setblock 274 210 477 minecraft:brown_terracotta
setblock 274 210 478 minecraft:bone_block
fill 274 210 479 274 212 479 minecraft:brown_terracotta
fill 274 210 481 274 211 481 minecraft:brown_terracotta
fill 274 210 499 274 212 499 minecraft:brown_terracotta
setblock 274 210 503 minecraft:bone_block
fill 274 210 504 274 213 504 minecraft:brown_terracotta
setblock 275 210 467 minecraft:bone_block
fill 275 210 468 275 213 468 minecraft:brown_terracotta
setblock 275 210 472 minecraft:bone_block
fill 275 210 473 275 212 473 minecraft:brown_terracotta
setblock 275 210 477 minecraft:bone_block
fill 275 210 478 275 213 478 minecraft:brown_terracotta
setblock 275 210 482 minecraft:bone_block
fill 275 210 483 275 213 483 minecraft:brown_terracotta
fill 275 210 485 276 210 485 minecraft:brown_terracotta
setblock 275 210 496 minecraft:brown_terracotta
setblock 275 210 497 minecraft:bone_block
fill 275 210 498 275 213 498 minecraft:brown_terracotta
setblock 275 210 502 minecraft:bone_block
fill 275 210 503 275 213 503 minecraft:brown_terracotta
setblock 276 210 466 minecraft:bone_block
fill 276 210 467 276 213 467 minecraft:brown_terracotta
setblock 276 210 471 minecraft:bone_block
fill 276 210 472 276 213 472 minecraft:brown_terracotta
setblock 276 210 476 minecraft:bone_block
fill 276 210 477 276 213 477 minecraft:brown_terracotta
setblock 276 210 481 minecraft:bone_block
fill 276 210 482 276 213 482 minecraft:brown_terracotta
fill 276 210 484 276 211 484 minecraft:brown_terracotta
setblock 276 210 486 minecraft:bone_block
fill 276 210 487 276 213 487 minecraft:brown_terracotta
fill 276 210 489 276 210 490 minecraft:brown_terracotta
setblock 276 210 491 minecraft:bone_block
fill 276 210 492 276 213 492 minecraft:brown_terracotta
setblock 276 210 496 minecraft:bone_block
fill 276 210 497 276 213 497 minecraft:brown_terracotta
setblock 276 210 501 minecraft:bone_block
fill 276 210 502 276 213 502 minecraft:brown_terracotta
setblock 236 211 464 minecraft:brown_terracotta
setblock 236 211 465 minecraft:bone_block
fill 236 211 466 236 214 466 minecraft:brown_terracotta
setblock 236 211 470 minecraft:bone_block
fill 236 211 471 236 212 471 minecraft:brown_terracotta
setblock 236 211 475 minecraft:bone_block
fill 236 211 476 236 213 476 minecraft:brown_terracotta
setblock 236 211 480 minecraft:bone_block
fill 236 211 481 236 214 481 minecraft:brown_terracotta
setblock 236 211 484 minecraft:brown_terracotta
setblock 236 211 485 minecraft:bone_block
fill 236 211 486 236 214 486 minecraft:brown_terracotta
setblock 236 211 490 minecraft:bone_block
fill 236 211 491 236 214 491 minecraft:brown_terracotta
setblock 236 211 495 minecraft:bone_block
fill 236 211 496 236 214 496 minecraft:brown_terracotta
setblock 236 211 500 minecraft:bone_block
fill 236 211 501 236 214 501 minecraft:brown_terracotta
setblock 237 211 464 minecraft:bone_block
fill 237 211 465 237 214 465 minecraft:brown_terracotta
setblock 237 211 475 minecraft:brown_terracotta
setblock 237 211 478 minecraft:brown_terracotta
setblock 237 211 479 minecraft:bone_block
fill 237 211 480 237 214 480 minecraft:brown_terracotta
setblock 237 211 484 minecraft:bone_block
fill 237 211 485 237 214 485 minecraft:brown_terracotta
setblock 237 211 488 minecraft:brown_terracotta
setblock 237 211 489 minecraft:bone_block
fill 237 211 490 237 214 490 minecraft:brown_terracotta
setblock 237 211 494 minecraft:bone_block
fill 237 211 495 237 214 495 minecraft:brown_terracotta
setblock 237 211 499 minecraft:bone_block
fill 237 211 500 237 214 500 minecraft:brown_terracotta
setblock 237 211 504 minecraft:bone_block
fill 238 211 464 238 214 464 minecraft:brown_terracotta
setblock 238 211 483 minecraft:bone_block
fill 238 211 484 238 212 484 minecraft:brown_terracotta
setblock 238 211 498 minecraft:bone_block
fill 238 211 499 238 214 499 minecraft:brown_terracotta
setblock 238 211 503 minecraft:bone_block
fill 238 211 504 238 214 504 minecraft:brown_terracotta
setblock 239 211 498 minecraft:brown_terracotta
setblock 239 211 502 minecraft:bone_block
fill 239 211 503 239 214 503 minecraft:brown_terracotta
setblock 240 211 501 minecraft:bone_block
fill 240 211 502 240 213 502 minecraft:brown_terracotta
setblock 241 211 501 minecraft:brown_terracotta
setblock 242 211 464 minecraft:bone_block
setblock 242 211 504 minecraft:bone_block
setblock 243 211 503 minecraft:bone_block
fill 243 211 504 243 214 504 minecraft:brown_terracotta
fill 244 211 503 244 212 503 minecraft:brown_terracotta
setblock 247 211 504 minecraft:bone_block
setblock 248 211 503 minecraft:bone_block
fill 248 211 504 251 211 504 minecraft:brown_terracotta
fill 249 211 503 252 211 503 minecraft:brown_terracotta
setblock 252 211 464 minecraft:bone_block
setblock 252 211 504 minecraft:bone_block
fill 253 211 464 256 211 464 minecraft:brown_terracotta
setblock 253 211 502 minecraft:brown_terracotta
setblock 253 211 503 minecraft:bone_block
fill 253 211 504 253 214 504 minecraft:brown_terracotta
setblock 254 211 502 minecraft:bone_block
fill 254 211 503 254 214 503 minecraft:brown_terracotta
setblock 255 211 465 minecraft:brown_terracotta
fill 255 211 502 255 212 502 minecraft:brown_terracotta
setblock 256 211 465 minecraft:bone_block
setblock 257 211 464 minecraft:bone_block
fill 257 211 465 257 214 465 minecraft:brown_terracotta
setblock 257 211 504 minecraft:bone_block
fill 258 211 464 258 214 464 minecraft:brown_terracotta
setblock 258 211 502 minecraft:brown_terracotta
setblock 258 211 503 minecraft:bone_block
fill 258 211 504 258 214 504 minecraft:brown_terracotta
fill 259 211 503 259 213 503 minecraft:brown_terracotta
setblock 261 211 465 minecraft:bone_block
setblock 262 211 464 minecraft:bone_block
setblock 262 211 504 minecraft:bone_block
fill 263 211 464 266 211 464 minecraft:brown_terracotta
fill 263 211 504 266 211 504 minecraft:brown_terracotta
setblock 267 211 464 minecraft:bone_block
setblock 267 211 504 minecraft:bone_block
fill 268 211 464 268 214 464 minecraft:brown_terracotta
fill 268 211 504 268 214 504 minecraft:brown_terracotta
setblock 270 211 465 minecraft:brown_terracotta
setblock 271 211 465 minecraft:bone_block
setblock 272 211 464 minecraft:bone_block
fill 272 211 465 272 214 465 minecraft:brown_terracotta
fill 272 211 502 272 211 503 minecraft:brown_terracotta
setblock 272 211 504 minecraft:bone_block
fill 273 211 464 273 214 464 minecraft:brown_terracotta
fill 273 211 466 274 211 466 minecraft:brown_terracotta
setblock 273 211 503 minecraft:bone_block
fill 273 211 504 273 214 504 minecraft:brown_terracotta
setblock 274 211 467 minecraft:bone_block
setblock 274 211 477 minecraft:bone_block
fill 274 211 478 274 212 478 minecraft:brown_terracotta
setblock 274 211 482 minecraft:bone_block
setblock 274 211 501 minecraft:brown_terracotta
setblock 274 211 502 minecraft:bone_block
fill 274 211 503 274 214 503 minecraft:brown_terracotta
setblock 275 211 466 minecraft:bone_block
fill 275 211 467 275 214 467 minecraft:brown_terracotta
setblock 275 211 471 minecraft:bone_block
fill 275 211 472 275 212 472 minecraft:brown_terracotta
setblock 275 211 476 minecraft:bone_block
fill 275 211 477 275 213 477 minecraft:brown_terracotta
setblock 275 211 481 minecraft:bone_block
fill 275 211 482 275 214 482 minecraft:brown_terracotta
setblock 275 211 485 minecraft:brown_terracotta
setblock 275 211 496 minecraft:bone_block
fill 275 211 497 275 213 497 minecraft:brown_terracotta
setblock 275 211 501 minecraft:bone_block
fill 275 211 502 275 214 502 minecraft:brown_terracotta
setblock 276 211 465 minecraft:bone_block
fill 276 211 466 276 214 466 minecraft:brown_terracotta
setblock 276 211 470 minecraft:bone_block
fill 276 211 471 276 214 471 minecraft:brown_terracotta
setblock 276 211 475 minecraft:bone_block
fill 276 211 476 276 214 476 minecraft:brown_terracotta
setblock 276 211 480 minecraft:bone_block
fill 276 211 481 276 214 481 minecraft:brown_terracotta
setblock 276 211 485 minecraft:bone_block
fill 276 211 486 276 214 486 minecraft:brown_terracotta
setblock 276 211 489 minecraft:brown_terracotta
setblock 276 211 490 minecraft:bone_block
fill 276 211 491 276 213 491 minecraft:brown_terracotta
setblock 276 211 495 minecraft:bone_block
fill 276 211 496 276 214 496 minecraft:brown_terracotta
setblock 276 211 500 minecraft:bone_block
fill 276 211 501 276 214 501 minecraft:brown_terracotta
setblock 236 212 464 minecraft:bone_block
fill 236 212 465 236 215 465 minecraft:brown_terracotta
setblock 236 212 469 minecraft:bone_block
setblock 236 212 470 minecraft:brown_terracotta
setblock 236 212 474 minecraft:bone_block
fill 236 212 475 236 213 475 minecraft:brown_terracotta
setblock 236 212 479 minecraft:bone_block
fill 236 212 480 236 215 480 minecraft:brown_terracotta
setblock 236 212 484 minecraft:bone_block
fill 236 212 485 236 215 485 minecraft:brown_terracotta
setblock 236 212 489 minecraft:bone_block
fill 236 212 490 236 215 490 minecraft:brown_terracotta
setblock 236 212 494 minecraft:bone_block
fill 236 212 495 236 215 495 minecraft:brown_terracotta
setblock 236 212 499 minecraft:bone_block
fill 236 212 500 236 215 500 minecraft:brown_terracotta
setblock 236 212 504 minecraft:bone_block
fill 237 212 464 237 215 464 minecraft:brown_terracotta
setblock 237 212 478 minecraft:bone_block
fill 237 212 479 237 213 479 minecraft:brown_terracotta
setblock 237 212 482 minecraft:brown_terracotta
setblock 237 212 483 minecraft:bone_block
fill 237 212 484 237 215 484 minecraft:brown_terracotta
setblock 237 212 488 minecraft:bone_block
fill 237 212 489 237 215 489 minecraft:brown_terracotta
setblock 237 212 493 minecraft:bone_block
fill 237 212 494 237 214 494 minecraft:brown_terracotta
setblock 237 212 498 minecraft:bone_block
fill 237 212 499 237 215 499 minecraft:brown_terracotta
setblock 237 212 503 minecraft:bone_block
fill 237 212 504 237 215 504 minecraft:brown_terracotta
setblock 238 212 482 minecraft:bone_block
setblock 238 212 483 minecraft:brown_terracotta
setblock 238 212 497 minecraft:bone_block
fill 238 212 498 238 213 498 minecraft:brown_terracotta
setblock 238 212 502 minecraft:bone_block
fill 238 212 503 238 215 503 minecraft:brown_terracotta
setblock 239 212 501 minecraft:bone_block
fill 239 212 502 239 214 502 minecraft:brown_terracotta
setblock 240 212 501 minecraft:brown_terracotta
setblock 241 212 464 minecraft:bone_block
setblock 241 212 504 minecraft:bone_block
setblock 242 212 464 minecraft:brown_terracotta
setblock 242 212 503 minecraft:bone_block
fill 242 212 504 242 215 504 minecraft:brown_terracotta
fill 243 212 503 243 213 503 minecraft:brown_terracotta
setblock 246 212 504 minecraft:bone_block
fill 247 212 504 250 212 504 minecraft:brown_terracotta
fill 249 212 503 251 212 503 minecraft:brown_terracotta
setblock 251 212 464 minecraft:bone_block
setblock 251 212 504 minecraft:bone_block
fill 252 212 464 255 212 464 minecraft:brown_terracotta
setblock 252 212 503 minecraft:bone_block
fill 252 212 504 252 215 504 minecraft:brown_terracotta
fill 253 212 503 253 215 503 minecraft:brown_terracotta
setblock 254 212 502 minecraft:brown_terracotta
setblock 255 212 465 minecraft:bone_block
setblock 256 212 464 minecraft:bone_block
fill 256 212 465 256 215 465 minecraft:brown_terracotta
setblock 256 212 504 minecraft:bone_block
fill 257 212 464 257 215 464 minecraft:brown_terracotta
setblock 257 212 503 minecraft:bone_block
fill 257 212 504 257 215 504 minecraft:brown_terracotta
fill 258 212 503 258 213 503 minecraft:brown_terracotta
setblock 260 212 465 minecraft:bone_block
setblock 261 212 464 minecraft:bone_block
setblock 261 212 504 minecraft:bone_block
fill 262 212 464 265 212 464 minecraft:brown_terracotta
fill 262 212 504 265 212 504 minecraft:brown_terracotta
setblock 266 212 464 minecraft:bone_block
setblock 266 212 504 minecraft:bone_block
fill 267 212 464 267 215 464 minecraft:brown_terracotta
fill 267 212 504 267 215 504 minecraft:brown_terracotta
setblock 269 212 465 minecraft:brown_terracotta
fill 269 212 503 269 214 503 minecraft:brown_terracotta
setblock 270 212 465 minecraft:bone_block
setblock 271 212 464 minecraft:bone_block
fill 271 212 465 271 215 465 minecraft:brown_terracotta
setblock 271 212 504 minecraft:bone_block
fill 272 212 464 272 215 464 minecraft:brown_terracotta
setblock 272 212 502 minecraft:brown_terracotta
setblock 272 212 503 minecraft:bone_block
fill 272 212 504 272 215 504 minecraft:brown_terracotta
setblock 273 212 466 minecraft:brown_terracotta
setblock 273 212 502 minecraft:bone_block
fill 273 212 503 273 215 503 minecraft:brown_terracotta
setblock 274 212 466 minecraft:bone_block
fill 274 212 467 274 215 467 minecraft:brown_terracotta
setblock 274 212 481 minecraft:bone_block
setblock 274 212 501 minecraft:bone_block
fill 274 212 502 274 215 502 minecraft:brown_terracotta
setblock 275 212 465 minecraft:bone_block
fill 275 212 466 275 215 466 minecraft:brown_terracotta
setblock 275 212 470 minecraft:bone_block
fill 275 212 471 275 213 471 minecraft:brown_terracotta
setblock 275 212 475 minecraft:bone_block
fill 275 212 476 275 213 476 minecraft:brown_terracotta
setblock 275 212 480 minecraft:bone_block
fill 275 212 481 275 215 481 minecraft:brown_terracotta
setblock 275 212 485 minecraft:bone_block
fill 275 212 486 275 215 486 minecraft:brown_terracotta
setblock 275 212 496 minecraft:brown_terracotta
setblock 275 212 500 minecraft:bone_block
fill 275 212 501 275 215 501 minecraft:brown_terracotta
setblock 276 212 464 minecraft:bone_block
fill 276 212 465 276 215 465 minecraft:brown_terracotta
setblock 276 212 469 minecraft:bone_block
fill 276 212 470 276 215 470 minecraft:brown_terracotta
setblock 276 212 474 minecraft:bone_block
fill 276 212 475 276 214 475 minecraft:brown_terracotta
setblock 276 212 479 minecraft:bone_block
fill 276 212 480 276 215 480 minecraft:brown_terracotta
setblock 276 212 484 minecraft:bone_block
fill 276 212 485 276 215 485 minecraft:brown_terracotta
setblock 276 212 489 minecraft:bone_block
fill 276 212 490 276 215 490 minecraft:brown_terracotta
setblock 276 212 494 minecraft:bone_block
fill 276 212 495 276 215 495 minecraft:brown_terracotta
setblock 276 212 499 minecraft:bone_block
fill 276 212 500 276 215 500 minecraft:brown_terracotta
setblock 276 212 504 minecraft:bone_block
fill 236 213 464 236 216 464 minecraft:brown_terracotta
setblock 236 213 468 minecraft:bone_block
setblock 236 213 469 minecraft:brown_terracotta
setblock 236 213 478 minecraft:bone_block
fill 236 213 479 236 216 479 minecraft:brown_terracotta
setblock 236 213 483 minecraft:bone_block
fill 236 213 484 236 216 484 minecraft:brown_terracotta
setblock 236 213 488 minecraft:bone_block
fill 236 213 489 236 216 489 minecraft:brown_terracotta
setblock 236 213 493 minecraft:bone_block
fill 236 213 494 236 216 494 minecraft:brown_terracotta
setblock 236 213 498 minecraft:bone_block
fill 236 213 499 236 216 499 minecraft:brown_terracotta
setblock 236 213 503 minecraft:bone_block
fill 236 213 504 236 216 504 minecraft:brown_terracotta
setblock 237 213 482 minecraft:bone_block
fill 237 213 483 237 216 483 minecraft:brown_terracotta
setblock 237 213 487 minecraft:bone_block
fill 237 213 488 237 216 488 minecraft:brown_terracotta
setblock 237 213 492 minecraft:bone_block
setblock 237 213 493 minecraft:brown_terracotta
setblock 237 213 497 minecraft:bone_block
fill 237 213 498 237 216 498 minecraft:brown_terracotta
setblock 237 213 502 minecraft:bone_block
fill 237 213 503 237 216 503 minecraft:brown_terracotta
setblock 238 213 497 minecraft:brown_terracotta
setblock 238 213 501 minecraft:bone_block
fill 238 213 502 238 215 502 minecraft:brown_terracotta
setblock 240 213 464 minecraft:bone_block
setblock 240 213 504 minecraft:bone_block
setblock 241 213 464 minecraft:brown_terracotta
setblock 241 213 503 minecraft:bone_block
fill 241 213 504 241 216 504 minecraft:brown_terracotta
fill 242 213 503 242 214 503 minecraft:brown_terracotta
setblock 245 213 504 minecraft:bone_block
fill 246 213 504 249 213 504 minecraft:brown_terracotta
setblock 250 213 503 minecraft:brown_terracotta
setblock 250 213 504 minecraft:bone_block
fill 251 213 464 254 213 464 minecraft:brown_terracotta
setblock 251 213 503 minecraft:bone_block
fill 251 213 504 251 216 504 minecraft:brown_terracotta
fill 252 213 503 252 215 503 minecraft:brown_terracotta
setblock 254 213 465 minecraft:bone_block
setblock 255 213 464 minecraft:bone_block
fill 255 213 465 255 216 465 minecraft:brown_terracotta
setblock 255 213 504 minecraft:bone_block
fill 256 213 464 256 216 464 minecraft:brown_terracotta
setblock 256 213 503 minecraft:bone_block
fill 256 213 504 256 216 504 minecraft:brown_terracotta
fill 257 213 503 257 214 503 minecraft:brown_terracotta
setblock 259 213 465 minecraft:bone_block
setblock 260 213 464 minecraft:bone_block
fill 260 213 465 260 214 465 minecraft:brown_terracotta
setblock 260 213 504 minecraft:bone_block
fill 261 213 464 264 213 464 minecraft:brown_terracotta
fill 261 213 497 265 214 501 minecraft:soul_soil
fill 261 213 504 264 213 504 minecraft:brown_terracotta
fill 263 213 502 263 213 503 minecraft:soul_soil
setblock 265 213 464 minecraft:bone_block
setblock 265 213 504 minecraft:bone_block
fill 266 213 464 266 216 464 minecraft:brown_terracotta
fill 266 213 504 266 216 504 minecraft:brown_terracotta
setblock 268 213 465 minecraft:brown_terracotta
setblock 269 213 465 minecraft:bone_block
setblock 270 213 464 minecraft:bone_block
fill 270 213 465 270 216 465 minecraft:brown_terracotta
setblock 270 213 504 minecraft:bone_block
fill 271 213 464 271 216 464 minecraft:brown_terracotta
setblock 271 213 503 minecraft:bone_block
fill 271 213 504 271 216 504 minecraft:brown_terracotta
setblock 272 213 466 minecraft:brown_terracotta
setblock 272 213 502 minecraft:bone_block
fill 272 213 503 272 216 503 minecraft:brown_terracotta
setblock 273 213 466 minecraft:bone_block
fill 273 213 502 273 216 502 minecraft:brown_terracotta
setblock 274 213 465 minecraft:bone_block
fill 274 213 466 274 216 466 minecraft:brown_terracotta
setblock 274 213 500 minecraft:bone_block
fill 274 213 501 274 215 501 minecraft:brown_terracotta
setblock 275 213 464 minecraft:bone_block
fill 275 213 465 275 216 465 minecraft:brown_terracotta
setblock 275 213 469 minecraft:bone_block
fill 275 213 470 275 214 470 minecraft:brown_terracotta
setblock 275 213 475 minecraft:brown_terracotta
setblock 275 213 479 minecraft:bone_block
fill 275 213 480 275 215 480 minecraft:brown_terracotta
setblock 275 213 484 minecraft:bone_block
fill 275 213 485 275 216 485 minecraft:brown_terracotta
setblock 275 213 499 minecraft:bone_block
fill 275 213 500 275 216 500 minecraft:brown_terracotta
setblock 275 213 504 minecraft:bone_block
fill 276 213 464 276 216 464 minecraft:brown_terracotta
setblock 276 213 468 minecraft:bone_block
fill 276 213 469 276 216 469 minecraft:brown_terracotta
setblock 276 213 473 minecraft:bone_block
fill 276 213 474 276 214 474 minecraft:brown_terracotta
setblock 276 213 478 minecraft:bone_block
fill 276 213 479 276 216 479 minecraft:brown_terracotta
setblock 276 213 483 minecraft:bone_block
fill 276 213 484 276 216 484 minecraft:brown_terracotta
setblock 276 213 488 minecraft:bone_block
fill 276 213 489 276 216 489 minecraft:brown_terracotta
setblock 276 213 493 minecraft:bone_block
fill 276 213 494 276 214 494 minecraft:brown_terracotta
setblock 276 213 498 minecraft:bone_block
fill 276 213 499 276 216 499 minecraft:brown_terracotta
setblock 276 213 503 minecraft:bone_block
fill 276 213 504 276 216 504 minecraft:brown_terracotta
setblock 236 214 467 minecraft:bone_block
fill 236 214 468 236 217 468 minecraft:brown_terracotta
setblock 236 214 477 minecraft:bone_block
fill 236 214 478 236 215 478 minecraft:brown_terracotta
setblock 236 214 482 minecraft:bone_block
fill 236 214 483 236 217 483 minecraft:brown_terracotta
setblock 236 214 487 minecraft:bone_block
fill 236 214 488 236 217 488 minecraft:brown_terracotta
setblock 236 214 492 minecraft:bone_block
fill 236 214 493 236 217 493 minecraft:brown_terracotta
setblock 236 214 497 minecraft:bone_block
fill 236 214 498 236 217 498 minecraft:brown_terracotta
setblock 236 214 502 minecraft:bone_block
fill 236 214 503 236 217 503 minecraft:brown_terracotta
setblock 237 214 481 minecraft:bone_block
fill 237 214 482 237 216 482 minecraft:brown_terracotta
setblock 237 214 486 minecraft:bone_block
fill 237 214 487 237 217 487 minecraft:brown_terracotta
setblock 237 214 496 minecraft:bone_block
fill 237 214 497 237 215 497 minecraft:brown_terracotta
setblock 237 214 501 minecraft:bone_block
fill 237 214 502 237 217 502 minecraft:brown_terracotta
setblock 238 214 500 minecraft:bone_block
setblock 238 214 501 minecraft:brown_terracotta
setblock 239 214 464 minecraft:bone_block
setblock 239 214 504 minecraft:bone_block
fill 240 214 464 240 215 464 minecraft:brown_terracotta
setblock 240 214 503 minecraft:bone_block
fill 240 214 504 240 217 504 minecraft:brown_terracotta
setblock 241 214 503 minecraft:brown_terracotta
setblock 244 214 504 minecraft:bone_block
fill 245 214 504 248 214 504 minecraft:brown_terracotta
setblock 249 214 504 minecraft:bone_block
fill 250 214 464 253 214 464 minecraft:brown_terracotta
fill 250 214 504 250 217 504 minecraft:brown_terracotta
setblock 251 214 503 minecraft:brown_terracotta
setblock 253 214 465 minecraft:bone_block
setblock 254 214 464 minecraft:bone_block
fill 254 214 465 254 217 465 minecraft:brown_terracotta
setblock 254 214 504 minecraft:bone_block
fill 255 214 464 255 217 464 minecraft:brown_terracotta
setblock 255 214 503 minecraft:bone_block
fill 255 214 504 255 217 504 minecraft:brown_terracotta
setblock 256 214 503 minecraft:brown_terracotta
setblock 258 214 465 minecraft:bone_block
setblock 259 214 464 minecraft:bone_block
fill 259 214 465 259 217 465 minecraft:brown_terracotta
setblock 259 214 504 minecraft:bone_block
fill 260 214 464 263 214 464 minecraft:brown_terracotta
fill 260 214 504 262 214 504 minecraft:brown_terracotta
setblock 264 214 464 minecraft:bone_block
fill 265 214 464 265 217 464 minecraft:brown_terracotta
setblock 268 214 465 minecraft:bone_block
setblock 269 214 464 minecraft:bone_block
fill 269 214 465 269 217 465 minecraft:brown_terracotta
setblock 269 214 504 minecraft:bone_block
fill 270 214 464 270 217 464 minecraft:brown_terracotta
setblock 270 214 503 minecraft:bone_block
fill 270 214 504 270 217 504 minecraft:brown_terracotta
fill 271 214 503 271 217 503 minecraft:brown_terracotta
setblock 272 214 466 minecraft:bone_block
fill 272 214 502 272 215 502 minecraft:brown_terracotta
setblock 273 214 465 minecraft:bone_block
fill 273 214 466 273 217 466 minecraft:brown_terracotta
setblock 274 214 464 minecraft:bone_block
fill 274 214 465 274 217 465 minecraft:brown_terracotta
setblock 274 214 500 minecraft:brown_terracotta
setblock 274 214 504 minecraft:bone_block
fill 275 214 464 275 217 464 minecraft:brown_terracotta
setblock 275 214 468 minecraft:bone_block
fill 275 214 469 275 217 469 minecraft:brown_terracotta
setblock 275 214 478 minecraft:bone_block
setblock 275 214 479 minecraft:brown_terracotta
setblock 275 214 483 minecraft:bone_block
fill 275 214 484 275 217 484 minecraft:brown_terracotta
setblock 275 214 498 minecraft:bone_block
fill 275 214 499 275 216 499 minecraft:brown_terracotta
setblock 275 214 503 minecraft:bone_block
fill 275 214 504 275 217 504 minecraft:brown_terracotta
setblock 276 214 467 minecraft:bone_block
fill 276 214 468 276 217 468 minecraft:brown_terracotta
setblock 276 214 472 minecraft:bone_block
setblock 276 214 473 minecraft:brown_terracotta
setblock 276 214 477 minecraft:bone_block
fill 276 214 478 276 215 478 minecraft:brown_terracotta
setblock 276 214 482 minecraft:bone_block
fill 276 214 483 276 217 483 minecraft:brown_terracotta
setblock 276 214 487 minecraft:bone_block
fill 276 214 488 276 217 488 minecraft:brown_terracotta
setblock 276 214 497 minecraft:bone_block
fill 276 214 498 276 217 498 minecraft:brown_terracotta
setblock 276 214 502 minecraft:bone_block
fill 276 214 503 276 217 503 minecraft:brown_terracotta
setblock 236 215 466 minecraft:bone_block
fill 236 215 467 236 217 467 minecraft:brown_terracotta
setblock 236 215 481 minecraft:bone_block
fill 236 215 482 236 217 482 minecraft:brown_terracotta
setblock 236 215 486 minecraft:bone_block
fill 236 215 487 236 217 487 minecraft:brown_terracotta
setblock 236 215 491 minecraft:bone_block
fill 236 215 492 236 217 492 minecraft:brown_terracotta
setblock 236 215 496 minecraft:bone_block
fill 236 215 497 236 217 497 minecraft:brown_terracotta
setblock 236 215 501 minecraft:bone_block
fill 236 215 502 236 217 502 minecraft:brown_terracotta
setblock 237 215 465 minecraft:bone_block
setblock 237 215 481 minecraft:brown_terracotta
setblock 237 215 485 minecraft:bone_block
fill 237 215 486 237 217 486 minecraft:brown_terracotta
setblock 237 215 490 minecraft:bone_block
setblock 237 215 500 minecraft:bone_block
fill 237 215 501 237 217 501 minecraft:brown_terracotta
setblock 238 215 464 minecraft:bone_block
setblock 238 215 504 minecraft:bone_block
fill 239 215 464 239 217 464 minecraft:brown_terracotta
setblock 239 215 503 minecraft:bone_block
fill 239 215 504 239 217 504 minecraft:brown_terracotta
setblock 240 215 503 minecraft:brown_terracotta
setblock 243 215 504 minecraft:bone_block
setblock 244 215 504 minecraft:brown_terracotta
setblock 247 215 504 minecraft:brown_terracotta
setblock 248 215 504 minecraft:bone_block
fill 249 215 504 249 217 504 minecraft:brown_terracotta
fill 250 215 464 252 215 464 minecraft:brown_terracotta
setblock 253 215 464 minecraft:bone_block
fill 253 215 465 253 217 465 minecraft:brown_terracotta
setblock 253 215 504 minecraft:bone_block
fill 254 215 464 254 217 464 minecraft:brown_terracotta
setblock 254 215 503 minecraft:bone_block
fill 254 215 504 254 217 504 minecraft:brown_terracotta
setblock 255 215 503 minecraft:brown_terracotta
setblock 257 215 465 minecraft:bone_block
setblock 258 215 464 minecraft:bone_block
fill 258 215 465 258 217 465 minecraft:brown_terracotta
setblock 258 215 504 minecraft:bone_block
fill 259 215 464 262 215 464 minecraft:brown_terracotta
fill 259 215 498 261 216 498 minecraft:bone_block
fill 259 215 500 261 216 500 minecraft:bone_block
fill 259 215 504 260 215 504 minecraft:brown_terracotta
fill 260 215 499 260 216 499 minecraft:bone_block
setblock 263 215 464 minecraft:bone_block
fill 264 215 464 264 217 464 minecraft:brown_terracotta
setblock 267 215 465 minecraft:bone_block
fill 267 215 493 267 216 493 minecraft:bone_block
setblock 268 215 464 minecraft:bone_block
fill 268 215 465 268 217 465 minecraft:brown_terracotta
setblock 268 215 504 minecraft:bone_block
fill 269 215 464 269 217 464 minecraft:brown_terracotta
setblock 269 215 503 minecraft:bone_block
fill 269 215 504 269 217 504 minecraft:brown_terracotta
fill 270 215 503 270 217 503 minecraft:brown_terracotta
setblock 271 215 466 minecraft:bone_block
setblock 272 215 465 minecraft:bone_block
fill 272 215 466 272 217 466 minecraft:brown_terracotta
setblock 273 215 464 minecraft:bone_block
fill 273 215 465 273 217 465 minecraft:brown_terracotta
setblock 273 215 504 minecraft:bone_block
fill 274 215 464 274 217 464 minecraft:brown_terracotta
setblock 274 215 503 minecraft:bone_block
fill 274 215 504 274 217 504 minecraft:brown_terracotta
setblock 275 215 467 minecraft:bone_block
fill 275 215 468 275 217 468 minecraft:brown_terracotta
setblock 275 215 482 minecraft:bone_block
fill 275 215 483 275 216 483 minecraft:brown_terracotta
setblock 275 215 498 minecraft:brown_terracotta
setblock 275 215 502 minecraft:bone_block
fill 275 215 503 275 217 503 minecraft:brown_terracotta
setblock 276 215 466 minecraft:bone_block
fill 276 215 467 276 217 467 minecraft:brown_terracotta
setblock 276 215 471 minecraft:bone_block
setblock 276 215 472 minecraft:brown_terracotta
setblock 276 215 477 minecraft:brown_terracotta
setblock 276 215 481 minecraft:bone_block
fill 276 215 482 276 217 482 minecraft:brown_terracotta
setblock 276 215 486 minecraft:bone_block
fill 276 215 487 276 217 487 minecraft:brown_terracotta
setblock 276 215 496 minecraft:bone_block
fill 276 215 497 276 217 497 minecraft:brown_terracotta
setblock 276 215 501 minecraft:bone_block
fill 276 215 502 276 217 502 minecraft:brown_terracotta
setblock 236 216 465 minecraft:bone_block
fill 236 216 466 236 217 466 minecraft:brown_terracotta
setblock 236 216 480 minecraft:bone_block
fill 236 216 481 236 217 481 minecraft:brown_terracotta
setblock 236 216 485 minecraft:bone_block
fill 236 216 486 236 217 486 minecraft:brown_terracotta
setblock 236 216 490 minecraft:bone_block
fill 236 216 491 236 217 491 minecraft:brown_terracotta
setblock 236 216 495 minecraft:bone_block
fill 236 216 496 236 217 496 minecraft:brown_terracotta
setblock 236 216 500 minecraft:bone_block
fill 236 216 501 236 217 501 minecraft:brown_terracotta
setblock 237 216 464 minecraft:bone_block
setblock 237 216 484 minecraft:bone_block
fill 237 216 485 237 217 485 minecraft:brown_terracotta
setblock 237 216 489 minecraft:bone_block
fill 237 216 490 237 217 490 minecraft:brown_terracotta
setblock 237 216 499 minecraft:bone_block
fill 237 216 500 237 217 500 minecraft:brown_terracotta
setblock 237 216 504 minecraft:bone_block
fill 238 216 464 238 217 464 minecraft:brown_terracotta
setblock 238 216 466 minecraft:light[level=12]
setblock 238 216 474 minecraft:light[level=12]
setblock 238 216 482 minecraft:light[level=12]
setblock 238 216 490 minecraft:light[level=12]
setblock 238 216 498 minecraft:light[level=12]
setblock 238 216 503 minecraft:bone_block
fill 238 216 504 238 217 504 minecraft:brown_terracotta
setblock 239 216 503 minecraft:brown_terracotta
setblock 242 216 504 minecraft:bone_block
setblock 246 216 466 minecraft:light[level=12]
setblock 246 216 474 minecraft:light[level=12]
setblock 246 216 482 minecraft:light[level=12]
setblock 246 216 490 minecraft:light[level=12]
setblock 246 216 498 minecraft:light[level=12]
fill 248 216 504 248 217 504 minecraft:brown_terracotta
fill 249 216 464 251 216 464 minecraft:brown_terracotta
setblock 252 216 464 minecraft:bone_block
fill 252 216 465 252 217 465 minecraft:brown_terracotta
setblock 252 216 504 minecraft:bone_block
fill 253 216 464 253 217 464 minecraft:brown_terracotta
fill 253 216 504 253 217 504 minecraft:brown_terracotta
setblock 254 216 466 minecraft:light[level=12]
setblock 254 216 474 minecraft:light[level=12]
setblock 254 216 482 minecraft:light[level=12]
setblock 254 216 490 minecraft:light[level=12]
setblock 254 216 498 minecraft:light[level=12]
setblock 256 216 465 minecraft:bone_block
setblock 257 216 464 minecraft:bone_block
fill 257 216 465 257 217 465 minecraft:brown_terracotta
setblock 257 216 504 minecraft:bone_block
fill 258 216 464 261 216 464 minecraft:brown_terracotta
fill 258 216 504 259 216 504 minecraft:brown_terracotta
fill 261 216 499 262 217 499 minecraft:bone_block
setblock 262 216 464 minecraft:bone_block
setblock 262 216 466 minecraft:light[level=12]
setblock 262 216 474 minecraft:light[level=12]
setblock 262 216 482 minecraft:light[level=12]
setblock 262 216 490 minecraft:light[level=12]
setblock 262 216 498 minecraft:light[level=12]
fill 263 216 464 263 217 464 minecraft:brown_terracotta
setblock 266 216 465 minecraft:bone_block
setblock 267 216 464 minecraft:bone_block
fill 267 216 465 267 217 465 minecraft:brown_terracotta
setblock 267 216 504 minecraft:bone_block
fill 268 216 464 268 217 464 minecraft:brown_terracotta
fill 268 216 504 268 217 504 minecraft:brown_terracotta
fill 269 216 503 269 217 503 minecraft:brown_terracotta
setblock 270 216 466 minecraft:bone_block
setblock 270 216 474 minecraft:light[level=12]
setblock 270 216 482 minecraft:light[level=12]
setblock 270 216 490 minecraft:light[level=12]
setblock 270 216 498 minecraft:light[level=12]
setblock 271 216 465 minecraft:bone_block
fill 271 216 466 271 217 466 minecraft:brown_terracotta
setblock 272 216 464 minecraft:bone_block
fill 272 216 465 272 217 465 minecraft:brown_terracotta
setblock 272 216 504 minecraft:bone_block
fill 273 216 464 273 217 464 minecraft:brown_terracotta
setblock 273 216 503 minecraft:bone_block
fill 273 216 504 273 217 504 minecraft:brown_terracotta
setblock 274 216 467 minecraft:bone_block
setblock 274 216 502 minecraft:bone_block
fill 274 216 503 274 217 503 minecraft:brown_terracotta
setblock 275 216 466 minecraft:bone_block
fill 275 216 467 275 217 467 minecraft:brown_terracotta
setblock 275 216 486 minecraft:bone_block
setblock 275 216 501 minecraft:bone_block
fill 275 216 502 275 217 502 minecraft:brown_terracotta
setblock 276 216 465 minecraft:bone_block
fill 276 216 466 276 217 466 minecraft:brown_terracotta
setblock 276 216 470 minecraft:bone_block
setblock 276 216 471 minecraft:brown_terracotta
setblock 276 216 480 minecraft:bone_block
fill 276 216 481 276 217 481 minecraft:brown_terracotta
setblock 276 216 485 minecraft:bone_block
fill 276 216 486 276 217 486 minecraft:brown_terracotta
setblock 276 216 490 minecraft:bone_block
fill 276 216 491 276 217 491 minecraft:brown_terracotta
fill 276 216 496 276 217 496 minecraft:brown_terracotta
setblock 276 216 500 minecraft:bone_block
fill 276 216 501 276 217 501 minecraft:brown_terracotta
setblock 236 217 464 minecraft:bone_block
setblock 236 217 465 minecraft:brown_terracotta
setblock 236 217 480 minecraft:brown_terracotta
setblock 236 217 484 minecraft:bone_block
setblock 236 217 485 minecraft:brown_terracotta
setblock 236 217 489 minecraft:bone_block
setblock 236 217 490 minecraft:brown_terracotta
setblock 236 217 494 minecraft:bone_block
setblock 236 217 495 minecraft:brown_terracotta
setblock 236 217 499 minecraft:bone_block
setblock 236 217 500 minecraft:brown_terracotta
setblock 236 217 504 minecraft:bone_block
setblock 237 217 464 minecraft:brown_terracotta
setblock 237 217 483 minecraft:bone_block
setblock 237 217 484 minecraft:brown_terracotta
setblock 237 217 488 minecraft:bone_block
setblock 237 217 489 minecraft:brown_terracotta
setblock 237 217 503 minecraft:bone_block
setblock 237 217 504 minecraft:brown_terracotta
setblock 238 217 503 minecraft:brown_terracotta
setblock 241 217 504 minecraft:bone_block
fill 248 217 464 250 217 464 minecraft:brown_terracotta
setblock 251 217 464 minecraft:bone_block
setblock 251 217 465 minecraft:brown_terracotta
setblock 251 217 504 minecraft:bone_block
setblock 252 217 464 minecraft:brown_terracotta
setblock 252 217 504 minecraft:brown_terracotta
setblock 255 217 465 minecraft:bone_block
setblock 256 217 464 minecraft:bone_block
setblock 256 217 465 minecraft:brown_terracotta
setblock 256 217 504 minecraft:bone_block
fill 257 217 464 260 217 464 minecraft:brown_terracotta
fill 257 217 504 258 217 504 minecraft:brown_terracotta
setblock 261 217 464 minecraft:bone_block
setblock 262 217 464 minecraft:brown_terracotta
setblock 263 217 499 minecraft:bone_block
setblock 265 217 465 minecraft:bone_block
setblock 266 217 464 minecraft:bone_block
setblock 266 217 465 minecraft:brown_terracotta
setblock 266 217 504 minecraft:bone_block
setblock 267 217 464 minecraft:brown_terracotta
setblock 267 217 504 minecraft:brown_terracotta
setblock 269 217 466 minecraft:bone_block
setblock 270 217 465 minecraft:bone_block
setblock 270 217 466 minecraft:brown_terracotta
setblock 271 217 464 minecraft:bone_block
setblock 271 217 465 minecraft:brown_terracotta
setblock 271 217 504 minecraft:bone_block
setblock 272 217 464 minecraft:brown_terracotta
setblock 272 217 503 minecraft:bone_block
setblock 272 217 504 minecraft:brown_terracotta
setblock 273 217 502 minecraft:bone_block
setblock 273 217 503 minecraft:brown_terracotta
setblock 274 217 466 minecraft:bone_block
setblock 274 217 467 minecraft:brown_terracotta
setblock 274 217 502 minecraft:brown_terracotta
setblock 275 217 465 minecraft:bone_block
setblock 275 217 466 minecraft:brown_terracotta
setblock 275 217 485 minecraft:bone_block
setblock 275 217 486 minecraft:brown_terracotta
setblock 275 217 500 minecraft:bone_block
setblock 275 217 501 minecraft:brown_terracotta
setblock 276 217 464 minecraft:bone_block
setblock 276 217 465 minecraft:brown_terracotta
setblock 276 217 469 minecraft:bone_block
setblock 276 217 470 minecraft:brown_terracotta
setblock 276 217 484 minecraft:bone_block
setblock 276 217 485 minecraft:brown_terracotta
setblock 276 217 489 minecraft:bone_block
setblock 276 217 490 minecraft:brown_terracotta
setblock 276 217 499 minecraft:bone_block
setblock 276 217 500 minecraft:brown_terracotta
setblock 276 217 504 minecraft:bone_block
fill 241 223 487 249 223 495 minecraft:bone_block
fill 242 223 485 262 223 486 minecraft:bone_block
fill 242 223 496 262 224 497 minecraft:bone_block
fill 243 223 484 261 224 484 minecraft:bone_block
fill 243 223 498 261 224 498 minecraft:bone_block
fill 244 223 483 260 224 483 minecraft:bone_block
fill 244 223 499 260 224 499 minecraft:bone_block
fill 245 223 482 259 223 482 minecraft:bone_block
fill 245 223 500 259 224 500 minecraft:bone_block
fill 246 223 476 258 223 481 minecraft:bone_block
fill 247 223 501 257 224 501 minecraft:bone_block
fill 250 223 487 250 223 488 minecraft:bone_block
fill 250 223 490 250 223 495 minecraft:bone_block
fill 250 223 502 254 224 502 minecraft:bone_block
setblock 251 223 487 minecraft:bone_block
fill 251 223 491 251 223 495 minecraft:bone_block
fill 252 223 492 263 223 495 minecraft:bone_block
fill 253 223 487 263 223 487 minecraft:bone_block
fill 253 223 491 263 223 491 minecraft:bone_block
fill 254 223 488 263 223 488 minecraft:bone_block
fill 254 223 490 263 223 490 minecraft:bone_block
fill 255 223 489 263 223 489 minecraft:bone_block
fill 236 224 464 240 224 504 minecraft:brown_terracotta
fill 241 224 464 241 224 486 minecraft:brown_terracotta
fill 241 224 487 244 224 495 minecraft:bone_block
fill 241 224 496 241 224 504 minecraft:brown_terracotta
fill 242 224 464 242 224 484 minecraft:brown_terracotta
fill 242 224 485 250 224 486 minecraft:bone_block
fill 242 224 498 242 224 504 minecraft:brown_terracotta
fill 243 224 464 243 224 483 minecraft:brown_terracotta
fill 243 224 499 243 224 504 minecraft:brown_terracotta
fill 244 224 464 244 224 482 minecraft:brown_terracotta
fill 244 224 500 244 224 504 minecraft:brown_terracotta
fill 245 224 464 245 224 481 minecraft:brown_terracotta
fill 245 224 482 246 224 482 minecraft:bone_block
fill 245 224 487 246 224 489 minecraft:bone_block
fill 245 224 490 249 224 492 minecraft:shroomlight
fill 245 224 493 245 224 495 minecraft:bone_block
fill 245 224 501 246 224 504 minecraft:brown_terracotta
fill 246 224 464 276 224 475 minecraft:brown_terracotta
fill 246 224 476 246 224 481 minecraft:bone_block
fill 246 224 493 249 224 493 minecraft:shroomlight
fill 246 224 494 246 224 495 minecraft:bone_block
fill 247 224 476 258 224 480 minecraft:bone_block
fill 247 224 481 247 224 482 minecraft:black_concrete
fill 247 224 487 248 224 488 minecraft:bone_block
fill 247 224 489 248 224 489 minecraft:shroomlight
setblock 247 224 494 minecraft:shroomlight
fill 247 224 495 263 224 495 minecraft:bone_block
fill 247 224 502 249 224 504 minecraft:brown_terracotta
fill 248 224 481 248 224 482 minecraft:bone_block
fill 248 224 494 256 224 494 minecraft:bone_block
fill 249 224 481 249 224 482 minecraft:black_concrete
setblock 249 224 487 minecraft:bone_block
setblock 249 224 488 minecraft:shroomlight
setblock 249 224 489 minecraft:smooth_sandstone
fill 250 224 481 250 224 482 minecraft:bone_block
fill 250 224 487 250 224 488 minecraft:ochre_froglight
fill 250 224 490 250 224 491 minecraft:ochre_froglight
fill 250 224 492 250 224 493 minecraft:bone_block
fill 250 224 503 276 224 504 minecraft:brown_terracotta
fill 251 224 481 251 224 482 minecraft:black_concrete
fill 251 224 485 262 224 485 minecraft:bone_block
setblock 251 224 486 minecraft:shroomlight
setblock 251 224 487 minecraft:ochre_froglight
setblock 251 224 491 minecraft:ochre_froglight
setblock 251 224 492 minecraft:shroomlight
fill 251 224 493 254 224 493 minecraft:bone_block
fill 252 224 481 252 224 482 minecraft:bone_block
setblock 252 224 486 minecraft:smooth_sandstone
setblock 252 224 492 minecraft:smooth_sandstone
fill 253 224 481 253 224 482 minecraft:black_concrete
setblock 253 224 486 minecraft:shroomlight
fill 253 224 487 254 224 487 minecraft:ochre_froglight
fill 253 224 491 254 224 491 minecraft:ochre_froglight
setblock 253 224 492 minecraft:shroomlight
fill 254 224 481 254 224 482 minecraft:bone_block
fill 254 224 486 262 224 486 minecraft:bone_block
setblock 254 224 488 minecraft:ochre_froglight
setblock 254 224 490 minecraft:ochre_froglight
setblock 254 224 492 minecraft:bone_block
fill 255 224 481 255 224 482 minecraft:black_concrete
fill 255 224 487 263 224 487 minecraft:bone_block
setblock 255 224 488 minecraft:shroomlight
setblock 255 224 489 minecraft:smooth_sandstone
fill 255 224 490 258 224 493 minecraft:shroomlight
fill 255 224 502 276 224 502 minecraft:brown_terracotta
fill 256 224 481 256 224 482 minecraft:bone_block
fill 256 224 488 263 224 488 minecraft:bone_block
fill 256 224 489 257 224 489 minecraft:shroomlight
fill 257 224 481 257 224 482 minecraft:black_concrete
setblock 257 224 494 minecraft:shroomlight
fill 258 224 481 258 224 482 minecraft:bone_block
fill 258 224 489 263 224 489 minecraft:bone_block
fill 258 224 494 263 224 494 minecraft:bone_block
fill 258 224 501 276 224 501 minecraft:brown_terracotta
fill 259 224 476 276 224 481 minecraft:brown_terracotta
setblock 259 224 482 minecraft:bone_block
fill 259 224 490 259 224 492 minecraft:shroomlight
fill 259 224 493 263 224 493 minecraft:bone_block
fill 260 224 482 276 224 482 minecraft:brown_terracotta
fill 260 224 490 263 224 492 minecraft:bone_block
fill 260 224 500 276 224 500 minecraft:brown_terracotta
fill 261 224 483 276 224 483 minecraft:brown_terracotta
fill 261 224 499 276 224 499 minecraft:brown_terracotta
fill 262 224 484 276 224 484 minecraft:brown_terracotta
fill 262 224 498 276 224 498 minecraft:brown_terracotta
fill 263 224 485 276 224 486 minecraft:brown_terracotta
fill 263 224 496 276 224 497 minecraft:brown_terracotta
fill 264 224 487 276 224 495 minecraft:brown_terracotta
fill 243 225 480 243 226 480 minecraft:bone_block
fill 243 225 489 243 231 489 minecraft:bone_block
fill 243 225 498 243 226 498 minecraft:bone_block
fill 246 225 480 246 226 480 minecraft:bone_block
fill 246 225 489 246 231 489 minecraft:bone_block
fill 246 225 498 246 226 498 minecraft:bone_block
fill 249 225 480 249 226 480 minecraft:bone_block
fill 249 225 489 249 231 489 minecraft:bone_block
fill 249 225 498 249 226 498 minecraft:bone_block
fill 252 225 480 252 226 480 minecraft:bone_block
fill 252 225 498 252 226 498 minecraft:bone_block
fill 255 225 480 255 226 480 minecraft:bone_block
fill 255 225 489 255 231 489 minecraft:bone_block
fill 255 225 498 255 226 498 minecraft:bone_block
fill 258 225 480 258 226 480 minecraft:bone_block
fill 258 225 489 258 231 489 minecraft:bone_block
fill 258 225 498 258 226 498 minecraft:bone_block
fill 261 225 480 261 226 480 minecraft:bone_block
fill 261 225 489 261 235 489 minecraft:bone_block
fill 261 225 498 261 226 498 minecraft:bone_block
fill 243 227 481 243 228 481 minecraft:bone_block
fill 243 227 497 243 228 497 minecraft:bone_block
fill 246 227 481 246 228 481 minecraft:bone_block
fill 246 227 497 246 228 497 minecraft:bone_block
fill 249 227 481 249 228 481 minecraft:bone_block
fill 249 227 497 249 228 497 minecraft:bone_block
fill 252 227 481 252 228 481 minecraft:bone_block
fill 252 227 497 252 228 497 minecraft:bone_block
fill 255 227 481 255 228 481 minecraft:bone_block
fill 255 227 497 255 228 497 minecraft:bone_block
fill 258 227 481 258 228 481 minecraft:bone_block
fill 258 227 497 258 228 497 minecraft:bone_block
fill 261 227 481 261 228 481 minecraft:bone_block
fill 261 227 497 261 228 497 minecraft:bone_block
fill 236 228 486 236 228 487 minecraft:brown_terracotta
setblock 236 228 488 minecraft:bone_block
fill 236 228 489 236 228 492 minecraft:brown_terracotta
setblock 236 228 493 minecraft:bone_block
fill 236 228 494 236 228 497 minecraft:brown_terracotta
setblock 236 228 498 minecraft:bone_block
fill 237 228 489 237 228 491 minecraft:brown_terracotta
setblock 237 228 492 minecraft:bone_block
fill 237 228 493 237 228 495 minecraft:brown_terracotta
fill 242 228 466 246 228 470 minecraft:soul_soil
setblock 245 228 464 minecraft:bone_block
fill 246 228 464 249 228 464 minecraft:brown_terracotta
fill 247 228 465 248 228 465 minecraft:brown_terracotta
setblock 249 228 465 minecraft:bone_block
setblock 250 228 464 minecraft:bone_block
fill 250 228 465 251 228 465 minecraft:brown_terracotta
fill 251 228 464 253 228 464 minecraft:brown_terracotta
setblock 259 228 464 minecraft:brown_terracotta
setblock 260 228 464 minecraft:bone_block
fill 261 228 464 264 228 464 minecraft:brown_terracotta
fill 262 228 465 263 228 465 minecraft:brown_terracotta
fill 263 228 504 264 228 504 minecraft:brown_terracotta
setblock 264 228 465 minecraft:bone_block
fill 264 228 466 267 228 466 minecraft:brown_terracotta
setblock 265 228 464 minecraft:bone_block
fill 265 228 465 268 228 465 minecraft:brown_terracotta
setblock 265 228 503 minecraft:brown_terracotta
setblock 265 228 504 minecraft:bone_block
fill 266 228 464 269 228 464 minecraft:brown_terracotta
setblock 266 228 503 minecraft:bone_block
fill 266 228 504 269 228 504 minecraft:brown_terracotta
fill 267 228 503 270 228 503 minecraft:brown_terracotta
setblock 268 228 466 minecraft:bone_block
setblock 269 228 465 minecraft:bone_block
setblock 269 228 466 minecraft:brown_terracotta
setblock 270 228 464 minecraft:bone_block
fill 270 228 465 271 228 465 minecraft:brown_terracotta
setblock 270 228 504 minecraft:bone_block
fill 271 228 464 273 228 464 minecraft:brown_terracotta
setblock 271 228 503 minecraft:bone_block
fill 271 228 504 273 228 504 minecraft:brown_terracotta
fill 275 228 491 275 228 493 minecraft:brown_terracotta
setblock 275 228 494 minecraft:bone_block
fill 275 228 495 276 228 497 minecraft:brown_terracotta
setblock 276 228 488 minecraft:bone_block
fill 276 228 489 276 228 492 minecraft:brown_terracotta
setblock 276 228 493 minecraft:bone_block
fill 276 228 494 276 231 494 minecraft:brown_terracotta
setblock 276 228 498 minecraft:bone_block
fill 276 228 499 276 230 500 minecraft:brown_terracotta
fill 236 229 488 236 229 491 minecraft:brown_terracotta
setblock 236 229 492 minecraft:bone_block
fill 236 229 493 236 229 496 minecraft:brown_terracotta
setblock 236 229 497 minecraft:bone_block
setblock 236 229 498 minecraft:brown_terracotta
setblock 237 229 491 minecraft:bone_block
fill 237 229 492 237 229 494 minecraft:brown_terracotta
fill 240 229 467 242 230 467 minecraft:bone_block
fill 240 229 469 242 230 469 minecraft:bone_block
fill 241 229 468 241 230 468 minecraft:bone_block
fill 243 229 482 243 230 482 minecraft:bone_block
fill 243 229 496 243 230 496 minecraft:bone_block
fill 246 229 464 248 229 464 minecraft:brown_terracotta
fill 246 229 482 246 230 482 minecraft:bone_block
fill 246 229 496 246 230 496 minecraft:bone_block
setblock 249 229 464 minecraft:bone_block
fill 249 229 482 249 230 482 minecraft:bone_block
fill 249 229 496 249 230 496 minecraft:bone_block
fill 250 229 464 251 229 464 minecraft:brown_terracotta
fill 252 229 482 252 230 482 minecraft:bone_block
fill 252 229 496 252 230 496 minecraft:bone_block
fill 255 229 482 255 230 482 minecraft:bone_block
fill 255 229 496 255 230 496 minecraft:bone_block
fill 258 229 482 258 230 482 minecraft:bone_block
fill 258 229 496 258 230 496 minecraft:bone_block
fill 260 229 464 263 229 464 minecraft:brown_terracotta
fill 261 229 482 261 230 482 minecraft:bone_block
fill 261 229 496 261 230 496 minecraft:bone_block
setblock 262 229 465 minecraft:brown_terracotta
setblock 263 229 465 minecraft:bone_block
setblock 263 229 504 minecraft:brown_terracotta
setblock 264 229 464 minecraft:bone_block
fill 264 229 465 267 229 465 minecraft:brown_terracotta
fill 264 229 488 266 235 490 minecraft:bone_block
setblock 264 229 504 minecraft:bone_block
fill 265 229 464 268 229 464 minecraft:brown_terracotta
setblock 265 229 503 minecraft:bone_block
fill 265 229 504 268 229 504 minecraft:brown_terracotta
fill 266 229 503 269 229 503 minecraft:brown_terracotta
fill 267 229 488 267 236 489 minecraft:bone_block
setblock 268 229 465 minecraft:bone_block
setblock 269 229 464 minecraft:bone_block
setblock 269 229 465 minecraft:brown_terracotta
setblock 269 229 504 minecraft:bone_block
fill 270 229 464 271 229 464 minecraft:brown_terracotta
setblock 270 229 503 minecraft:bone_block
fill 270 229 504 272 229 504 minecraft:brown_terracotta
setblock 275 229 492 minecraft:brown_terracotta
setblock 275 229 493 minecraft:bone_block
fill 275 229 494 275 229 497 minecraft:brown_terracotta
fill 276 229 489 276 229 491 minecraft:brown_terracotta
setblock 276 229 492 minecraft:bone_block
fill 276 229 493 276 232 493 minecraft:brown_terracotta
fill 276 229 495 276 229 496 minecraft:brown_terracotta
setblock 276 229 497 minecraft:bone_block
fill 276 229 498 276 232 498 minecraft:brown_terracotta
fill 236 230 489 236 230 490 minecraft:brown_terracotta
setblock 236 230 491 minecraft:bone_block
fill 236 230 492 236 230 495 minecraft:brown_terracotta
setblock 236 230 496 minecraft:bone_block
fill 236 230 497 236 233 497 minecraft:brown_terracotta
setblock 237 230 493 minecraft:brown_terracotta
fill 238 230 493 238 236 493 minecraft:bone_block
fill 242 230 468 243 231 468 minecraft:bone_block
fill 243 230 483 243 232 483 minecraft:bone_block
fill 243 230 495 243 232 495 minecraft:bone_block
fill 246 230 483 246 232 483 minecraft:bone_block
fill 246 230 495 246 232 495 minecraft:bone_block
setblock 247 230 464 minecraft:brown_terracotta
setblock 248 230 464 minecraft:bone_block
fill 249 230 483 249 232 483 minecraft:bone_block
fill 249 230 495 249 232 495 minecraft:bone_block
fill 252 230 483 252 232 483 minecraft:bone_block
fill 252 230 495 252 232 495 minecraft:bone_block
fill 255 230 483 255 232 483 minecraft:bone_block
fill 255 230 495 255 232 495 minecraft:bone_block
fill 258 230 483 258 232 483 minecraft:bone_block
fill 258 230 495 258 232 495 minecraft:bone_block
fill 261 230 464 262 230 464 minecraft:brown_terracotta
fill 261 230 483 261 232 483 minecraft:bone_block
fill 261 230 495 261 232 495 minecraft:bone_block
setblock 262 230 504 minecraft:brown_terracotta
setblock 263 230 464 minecraft:bone_block
fill 263 230 465 266 230 465 minecraft:brown_terracotta
fill 263 230 487 263 235 490 minecraft:bone_block
setblock 263 230 504 minecraft:bone_block
fill 264 230 464 267 230 464 minecraft:brown_terracotta
fill 264 230 487 267 235 487 minecraft:bone_block
fill 264 230 491 267 234 491 minecraft:bone_block
fill 264 230 504 267 230 504 minecraft:brown_terracotta
fill 265 230 486 266 234 486 minecraft:bone_block
fill 265 230 492 266 234 492 minecraft:bone_block
fill 265 230 503 268 230 503 minecraft:brown_terracotta
setblock 267 230 465 minecraft:bone_block
fill 267 230 490 268 235 490 minecraft:bone_block
setblock 268 230 464 minecraft:bone_block
setblock 268 230 465 minecraft:brown_terracotta
fill 268 230 488 268 235 489 minecraft:bone_block
setblock 268 230 504 minecraft:bone_block
fill 269 230 464 270 230 464 minecraft:brown_terracotta
setblock 269 230 503 minecraft:bone_block
fill 269 230 504 271 231 504 minecraft:brown_terracotta
fill 275 230 493 275 230 496 minecraft:brown_terracotta
setblock 275 230 497 minecraft:bone_block
setblock 276 230 490 minecraft:brown_terracotta
setblock 276 230 491 minecraft:bone_block
fill 276 230 492 276 233 492 minecraft:brown_terracotta
setblock 276 230 495 minecraft:brown_terracotta
setblock 276 230 496 minecraft:bone_block
fill 276 230 497 276 233 497 minecraft:brown_terracotta
setblock 236 231 490 minecraft:bone_block
fill 236 231 491 236 231 494 minecraft:brown_terracotta
setblock 236 231 495 minecraft:bone_block
fill 236 231 496 236 234 496 minecraft:brown_terracotta
fill 236 231 498 236 232 498 minecraft:brown_terracotta
fill 243 231 488 243 234 488 minecraft:bone_block
fill 243 231 490 243 234 490 minecraft:bone_block
fill 244 231 468 244 232 468 minecraft:bone_block
fill 246 231 488 246 234 488 minecraft:bone_block
fill 246 231 490 246 234 490 minecraft:bone_block
fill 249 231 488 249 234 488 minecraft:bone_block
fill 249 231 490 249 234 490 minecraft:bone_block
fill 255 231 488 255 234 488 minecraft:bone_block
fill 255 231 490 255 234 490 minecraft:bone_block
fill 258 231 488 258 234 488 minecraft:bone_block
fill 258 231 490 258 234 490 minecraft:bone_block
setblock 261 231 464 minecraft:brown_terracotta
fill 261 231 488 262 234 488 minecraft:bone_block
fill 261 231 490 262 234 490 minecraft:bone_block
setblock 262 231 464 minecraft:bone_block
fill 262 231 489 262 235 489 minecraft:bone_block
setblock 262 231 504 minecraft:bone_block
fill 263 231 464 266 231 464 minecraft:brown_terracotta
fill 263 231 491 263 235 491 minecraft:bone_block
fill 263 231 504 266 231 504 minecraft:brown_terracotta
fill 264 231 465 265 231 465 minecraft:brown_terracotta
fill 264 231 486 264 234 486 minecraft:bone_block
fill 264 231 492 264 234 492 minecraft:bone_block
fill 264 231 503 267 231 503 minecraft:brown_terracotta
setblock 266 231 465 minecraft:bone_block
setblock 267 231 464 minecraft:bone_block
fill 267 231 486 267 234 486 minecraft:bone_block
fill 267 231 492 267 234 492 minecraft:bone_block
setblock 267 231 504 minecraft:bone_block
fill 268 231 464 269 231 464 minecraft:brown_terracotta
fill 268 231 487 268 234 487 minecraft:bone_block
fill 268 231 491 268 234 491 minecraft:bone_block
setblock 268 231 503 minecraft:bone_block
fill 268 231 504 268 234 504 minecraft:brown_terracotta
fill 269 231 503 269 234 503 minecraft:brown_terracotta
fill 275 231 494 275 231 495 minecraft:brown_terracotta
setblock 275 231 496 minecraft:bone_block
fill 275 231 497 275 234 497 minecraft:brown_terracotta
fill 276 231 491 276 234 491 minecraft:brown_terracotta
setblock 276 231 495 minecraft:bone_block
fill 276 231 496 276 234 496 minecraft:brown_terracotta
setblock 276 231 499 minecraft:brown_terracotta
setblock 276 231 500 minecraft:bone_block
fill 236 232 475 236 234 476 minecraft:brown_terracotta
fill 236 232 491 236 232 493 minecraft:brown_terracotta
setblock 236 232 494 minecraft:bone_block
fill 236 232 495 236 235 495 minecraft:brown_terracotta
setblock 238 232 466 minecraft:light[level=12]
setblock 238 232 474 minecraft:light[level=12]
setblock 238 232 482 minecraft:light[level=12]
setblock 238 232 490 minecraft:light[level=12]
setblock 238 232 498 minecraft:light[level=12]
fill 243 232 484 243 233 484 minecraft:bone_block
fill 243 232 494 243 233 494 minecraft:bone_block
fill 245 232 468 246 233 468 minecraft:bone_block
setblock 246 232 466 minecraft:light[level=12]
setblock 246 232 474 minecraft:light[level=12]
setblock 246 232 482 minecraft:light[level=12]
fill 246 232 484 246 233 484 minecraft:bone_block
fill 246 232 494 246 233 494 minecraft:bone_block
setblock 246 232 498 minecraft:light[level=12]
fill 249 232 484 249 233 484 minecraft:bone_block
fill 249 232 494 249 233 494 minecraft:bone_block
fill 252 232 484 252 233 484 minecraft:bone_block
fill 252 232 494 252 233 494 minecraft:bone_block
setblock 254 232 466 minecraft:light[level=12]
setblock 254 232 474 minecraft:light[level=12]
setblock 254 232 482 minecraft:light[level=12]
setblock 254 232 490 minecraft:light[level=12]
setblock 254 232 498 minecraft:light[level=12]
fill 255 232 484 255 233 484 minecraft:bone_block
fill 255 232 494 255 233 494 minecraft:bone_block
fill 258 232 484 258 233 484 minecraft:bone_block
setblock 258 232 493 minecraft:soul_soil
fill 258 232 494 258 233 494 minecraft:bone_block
setblock 260 232 464 minecraft:brown_terracotta
setblock 261 232 464 minecraft:bone_block
fill 261 232 484 261 233 484 minecraft:bone_block
fill 261 232 494 261 233 494 minecraft:bone_block
setblock 261 232 504 minecraft:bone_block
fill 262 232 464 265 232 464 minecraft:brown_terracotta
setblock 262 232 466 minecraft:light[level=12]
setblock 262 232 474 minecraft:light[level=12]
setblock 262 232 482 minecraft:light[level=12]
setblock 262 232 498 minecraft:light[level=12]
fill 262 232 504 265 232 504 minecraft:brown_terracotta
fill 263 232 486 263 233 486 minecraft:bone_block
fill 263 232 503 266 232 503 minecraft:brown_terracotta
fill 265 232 485 266 233 485 minecraft:bone_block
setblock 266 232 464 minecraft:bone_block
setblock 266 232 493 minecraft:bone_block
setblock 266 232 504 minecraft:bone_block
fill 267 232 464 268 233 464 minecraft:brown_terracotta
setblock 267 232 503 minecraft:bone_block
fill 267 232 504 267 235 504 minecraft:brown_terracotta
setblock 268 232 492 minecraft:bone_block
fill 268 232 503 268 235 503 minecraft:brown_terracotta
fill 269 232 504 270 232 504 minecraft:brown_terracotta
setblock 270 232 466 minecraft:light[level=12]
setblock 270 232 474 minecraft:light[level=12]
setblock 270 232 482 minecraft:light[level=12]
setblock 270 232 490 minecraft:light[level=12]
setblock 270 232 498 minecraft:light[level=12]
setblock 271 232 504 minecraft:bone_block
setblock 275 232 495 minecraft:bone_block
fill 275 232 496 275 235 496 minecraft:brown_terracotta
setblock 276 232 494 minecraft:bone_block
fill 276 232 495 276 235 495 minecraft:brown_terracotta
setblock 276 232 499 minecraft:bone_block
fill 276 232 500 276 235 500 minecraft:brown_terracotta
fill 236 233 474 236 236 474 minecraft:brown_terracotta
setblock 236 233 477 minecraft:brown_terracotta
setblock 236 233 478 minecraft:bone_block
fill 236 233 479 236 236 479 minecraft:brown_terracotta
fill 236 233 491 236 233 492 minecraft:brown_terracotta
fill 236 233 493 237 233 493 minecraft:bone_block
fill 236 233 494 236 236 494 minecraft:brown_terracotta
setblock 236 233 498 minecraft:bone_block
fill 236 233 499 236 236 499 minecraft:brown_terracotta
fill 238 233 492 238 236 492 minecraft:bone_block
fill 238 233 494 238 236 494 minecraft:bone_block
fill 239 233 493 239 236 493 minecraft:bone_block
fill 243 233 485 243 234 485 minecraft:bone_block
fill 243 233 493 243 234 493 minecraft:bone_block
fill 246 233 467 248 234 467 minecraft:bone_block
fill 246 233 469 248 234 469 minecraft:bone_block
fill 246 233 485 246 234 485 minecraft:bone_block
fill 246 233 493 246 234 493 minecraft:bone_block
fill 247 233 468 247 234 468 minecraft:bone_block
fill 249 233 485 249 234 485 minecraft:bone_block
fill 249 233 493 249 234 493 minecraft:bone_block
fill 252 233 485 252 234 485 minecraft:bone_block
fill 252 233 493 252 234 493 minecraft:bone_block
fill 255 233 485 255 234 485 minecraft:bone_block
fill 255 233 493 255 234 493 minecraft:bone_block
fill 258 233 485 258 234 485 minecraft:bone_block
fill 258 233 493 258 234 493 minecraft:bone_block
setblock 260 233 464 minecraft:bone_block
setblock 260 233 504 minecraft:bone_block
fill 261 233 464 264 233 464 minecraft:brown_terracotta
fill 261 233 485 261 234 485 minecraft:bone_block
fill 261 233 493 261 234 493 minecraft:bone_block
fill 261 233 504 264 233 504 minecraft:brown_terracotta
fill 262 233 491 262 234 491 minecraft:bone_block
fill 262 233 503 265 233 503 minecraft:brown_terracotta
fill 264 233 502 266 233 502 minecraft:brown_terracotta
setblock 265 233 464 minecraft:bone_block
setblock 265 233 504 minecraft:bone_block
fill 266 233 464 266 236 464 minecraft:brown_terracotta
setblock 266 233 503 minecraft:bone_block
fill 266 233 504 266 236 504 minecraft:brown_terracotta
setblock 267 233 502 minecraft:bone_block
fill 267 233 503 267 236 503 minecraft:brown_terracotta
setblock 269 233 504 minecraft:brown_terracotta
setblock 270 233 504 minecraft:bone_block
fill 271 233 504 271 236 504 minecraft:brown_terracotta
fill 275 233 495 275 236 495 minecraft:brown_terracotta
setblock 275 233 498 minecraft:brown_terracotta
setblock 276 233 493 minecraft:bone_block
fill 276 233 494 276 236 494 minecraft:brown_terracotta
setblock 276 233 498 minecraft:bone_block
fill 276 233 499 276 236 499 minecraft:brown_terracotta
fill 276 233 501 276 234 501 minecraft:brown_terracotta
fill 236 234 473 236 237 473 minecraft:brown_terracotta
setblock 236 234 477 minecraft:bone_block
fill 236 234 478 237 236 478 minecraft:brown_terracotta
fill 236 234 480 236 234 481 minecraft:brown_terracotta
setblock 236 234 482 minecraft:bone_block
setblock 236 234 491 minecraft:brown_terracotta
setblock 236 234 492 minecraft:bone_block
fill 236 234 493 236 237 493 minecraft:brown_terracotta
setblock 236 234 497 minecraft:bone_block
fill 236 234 498 236 237 498 minecraft:brown_terracotta
setblock 237 234 475 minecraft:brown_terracotta
setblock 237 234 476 minecraft:bone_block
fill 237 234 477 237 237 477 minecraft:brown_terracotta
fill 237 234 479 237 235 479 minecraft:brown_terracotta
fill 237 234 493 237 236 493 minecraft:bone_block
fill 241 234 489 251 235 489 minecraft:bone_block
fill 243 234 486 243 234 487 minecraft:bone_block
fill 243 234 491 243 234 492 minecraft:bone_block
setblock 244 234 464 minecraft:bone_block
fill 245 234 464 247 235 464 minecraft:brown_terracotta
fill 246 234 486 246 234 487 minecraft:bone_block
fill 246 234 491 246 234 492 minecraft:bone_block
fill 249 234 486 249 234 487 minecraft:bone_block
fill 249 234 491 249 234 492 minecraft:bone_block
fill 252 234 486 252 234 487 minecraft:bone_block
fill 252 234 490 252 234 492 minecraft:bone_block
fill 254 234 489 260 235 489 minecraft:bone_block
fill 255 234 486 255 234 487 minecraft:bone_block
fill 255 234 491 255 234 492 minecraft:bone_block
fill 258 234 486 258 234 487 minecraft:bone_block
fill 258 234 491 258 234 492 minecraft:bone_block
setblock 258 234 504 minecraft:brown_terracotta
setblock 259 234 464 minecraft:bone_block
setblock 259 234 504 minecraft:bone_block
fill 260 234 464 263 234 464 minecraft:brown_terracotta
setblock 260 234 503 minecraft:bone_block
fill 260 234 504 263 234 504 minecraft:brown_terracotta
fill 261 234 486 261 234 487 minecraft:bone_block
fill 261 234 491 261 234 492 minecraft:bone_block
fill 261 234 503 264 234 503 minecraft:brown_terracotta
fill 262 234 502 265 234 502 minecraft:brown_terracotta
setblock 263 234 465 minecraft:bone_block
setblock 264 234 464 minecraft:bone_block
fill 264 234 465 264 237 465 minecraft:brown_terracotta
setblock 264 234 504 minecraft:bone_block
fill 265 234 464 265 237 464 minecraft:brown_terracotta
setblock 265 234 503 minecraft:bone_block
fill 265 234 504 265 237 504 minecraft:brown_terracotta
setblock 266 234 502 minecraft:bone_block
fill 266 234 503 266 237 503 minecraft:brown_terracotta
fill 267 234 464 267 235 464 minecraft:brown_terracotta
fill 267 234 502 268 236 502 minecraft:brown_terracotta
setblock 269 234 504 minecraft:bone_block
fill 270 234 504 270 237 504 minecraft:brown_terracotta
fill 275 234 494 275 237 494 minecraft:brown_terracotta
setblock 275 234 498 minecraft:bone_block
fill 275 234 499 275 237 499 minecraft:brown_terracotta
setblock 276 234 492 minecraft:bone_block
fill 276 234 493 276 237 493 minecraft:brown_terracotta
setblock 276 234 497 minecraft:bone_block
fill 276 234 498 276 237 498 minecraft:brown_terracotta
setblock 276 234 502 minecraft:bone_block
fill 236 235 472 236 238 472 minecraft:brown_terracotta
setblock 236 235 475 minecraft:brown_terracotta
setblock 236 235 476 minecraft:bone_block
fill 236 235 477 236 238 477 minecraft:brown_terracotta
setblock 236 235 480 minecraft:brown_terracotta
setblock 236 235 481 minecraft:bone_block
fill 236 235 482 236 235 485 minecraft:brown_terracotta
setblock 236 235 490 minecraft:brown_terracotta
setblock 236 235 491 minecraft:bone_block
fill 236 235 492 236 238 492 minecraft:brown_terracotta
setblock 236 235 496 minecraft:bone_block
fill 236 235 497 237 237 497 minecraft:brown_terracotta
setblock 236 235 500 minecraft:brown_terracotta
setblock 236 235 501 minecraft:bone_block
setblock 237 235 474 minecraft:brown_terracotta
setblock 237 235 475 minecraft:bone_block
fill 237 235 476 238 237 476 minecraft:brown_terracotta
setblock 237 235 480 minecraft:bone_block
fill 237 235 481 237 237 482 minecraft:brown_terracotta
fill 237 235 492 237 236 492 minecraft:bone_block
fill 237 235 494 237 235 495 minecraft:bone_block
fill 237 235 496 237 238 496 minecraft:brown_terracotta
fill 237 235 498 237 236 498 minecraft:brown_terracotta
fill 238 235 477 238 235 478 minecraft:brown_terracotta
setblock 238 235 479 minecraft:bone_block
fill 239 235 492 239 236 492 minecraft:bone_block
fill 239 235 494 239 236 494 minecraft:bone_block
fill 241 235 504 242 235 504 minecraft:brown_terracotta
setblock 242 235 464 minecraft:brown_terracotta
setblock 243 235 464 minecraft:bone_block
setblock 243 235 504 minecraft:bone_block
fill 244 235 464 244 238 464 minecraft:brown_terracotta
fill 244 235 504 246 236 504 minecraft:brown_terracotta
setblock 248 235 464 minecraft:bone_block
setblock 257 235 464 minecraft:brown_terracotta
setblock 257 235 504 minecraft:brown_terracotta
setblock 258 235 464 minecraft:bone_block
setblock 258 235 504 minecraft:bone_block
fill 259 235 464 262 235 464 minecraft:brown_terracotta
setblock 259 235 503 minecraft:bone_block
fill 259 235 504 262 235 504 minecraft:brown_terracotta
setblock 260 235 502 minecraft:bone_block
fill 260 235 503 263 235 503 minecraft:brown_terracotta
setblock 261 235 465 minecraft:brown_terracotta
fill 261 235 502 264 235 502 minecraft:brown_terracotta
setblock 262 235 465 minecraft:bone_block
setblock 262 235 490 minecraft:bone_block
setblock 263 235 464 minecraft:bone_block
fill 263 235 465 263 238 465 minecraft:brown_terracotta
fill 263 235 501 265 235 501 minecraft:brown_terracotta
setblock 263 235 504 minecraft:bone_block
fill 264 235 464 264 238 464 minecraft:brown_terracotta
fill 264 235 491 266 235 491 minecraft:bone_block
setblock 264 235 503 minecraft:bone_block
fill 264 235 504 264 238 504 minecraft:brown_terracotta
setblock 265 235 502 minecraft:bone_block
fill 265 235 503 265 238 503 minecraft:brown_terracotta
setblock 266 235 501 minecraft:bone_block
fill 266 235 502 266 238 502 minecraft:brown_terracotta
setblock 268 235 504 minecraft:bone_block
setblock 269 235 503 minecraft:bone_block
fill 269 235 504 269 238 504 minecraft:brown_terracotta
fill 270 235 503 270 238 503 minecraft:brown_terracotta
setblock 272 235 504 minecraft:brown_terracotta
setblock 275 235 497 minecraft:bone_block
fill 275 235 498 275 238 498 minecraft:brown_terracotta
fill 275 235 500 275 236 500 minecraft:brown_terracotta
setblock 276 235 476 minecraft:bone_block
fill 276 235 477 276 236 479 minecraft:brown_terracotta
setblock 276 235 491 minecraft:bone_block
fill 276 235 492 276 238 492 minecraft:brown_terracotta
setblock 276 235 496 minecraft:bone_block
fill 276 235 497 276 238 497 minecraft:brown_terracotta
setblock 276 235 501 minecraft:bone_block
fill 276 235 502 276 237 503 minecraft:brown_terracotta
setblock 236 236 475 minecraft:bone_block
fill 236 236 476 236 239 476 minecraft:brown_terracotta
setblock 236 236 480 minecraft:bone_block
fill 236 236 481 236 236 484 minecraft:brown_terracotta
setblock 236 236 485 minecraft:bone_block
fill 236 236 486 236 236 489 minecraft:brown_terracotta
setblock 236 236 490 minecraft:bone_block
fill 236 236 491 236 239 491 minecraft:brown_terracotta
setblock 236 236 495 minecraft:bone_block
fill 236 236 496 236 239 496 minecraft:brown_terracotta
setblock 236 236 500 minecraft:bone_block
fill 236 236 501 236 238 502 minecraft:brown_terracotta
setblock 237 236 473 minecraft:brown_terracotta
setblock 237 236 474 minecraft:bone_block
fill 237 236 475 238 238 475 minecraft:brown_terracotta
setblock 237 236 479 minecraft:bone_block
fill 237 236 480 238 238 480 minecraft:brown_terracotta
setblock 237 236 483 minecraft:brown_terracotta
setblock 237 236 484 minecraft:bone_block
setblock 237 236 494 minecraft:bone_block
fill 237 236 495 237 239 495 minecraft:brown_terracotta
setblock 237 236 499 minecraft:bone_block
fill 238 236 474 238 239 474 minecraft:brown_terracotta
setblock 238 236 477 minecraft:brown_terracotta
setblock 238 236 478 minecraft:bone_block
fill 238 236 479 239 238 479 minecraft:brown_terracotta
fill 238 236 481 238 236 482 minecraft:brown_terracotta
setblock 239 236 476 minecraft:brown_terracotta
setblock 239 236 477 minecraft:bone_block
fill 239 236 478 239 239 478 minecraft:brown_terracotta
fill 239 236 504 241 236 504 minecraft:brown_terracotta
setblock 241 236 464 minecraft:brown_terracotta
setblock 242 236 464 minecraft:bone_block
setblock 242 236 503 minecraft:brown_terracotta
setblock 242 236 504 minecraft:bone_block
fill 243 236 464 243 239 464 minecraft:brown_terracotta
setblock 243 236 503 minecraft:bone_block
fill 243 236 504 243 239 504 minecraft:brown_terracotta
fill 244 236 503 244 239 503 minecraft:brown_terracotta
fill 245 236 464 246 236 464 minecraft:brown_terracotta
setblock 247 236 464 minecraft:bone_block
setblock 247 236 504 minecraft:bone_block
fill 248 236 464 249 238 464 minecraft:brown_terracotta
fill 248 236 504 248 239 504 minecraft:brown_terracotta
fill 255 236 464 256 236 464 minecraft:brown_terracotta
fill 255 236 504 256 236 504 minecraft:brown_terracotta
setblock 257 236 464 minecraft:bone_block
setblock 257 236 503 minecraft:brown_terracotta
setblock 257 236 504 minecraft:bone_block
fill 258 236 464 261 236 464 minecraft:brown_terracotta
setblock 258 236 503 minecraft:bone_block
fill 258 236 504 261 236 504 minecraft:brown_terracotta
fill 259 236 465 260 236 465 minecraft:brown_terracotta
setblock 259 236 502 minecraft:bone_block
fill 259 236 503 262 236 503 minecraft:brown_terracotta
fill 260 236 502 263 236 502 minecraft:brown_terracotta
setblock 261 236 465 minecraft:bone_block
fill 261 236 501 264 236 501 minecraft:brown_terracotta
setblock 262 236 464 minecraft:bone_block
fill 262 236 465 262 239 465 minecraft:brown_terracotta
setblock 262 236 504 minecraft:bone_block
fill 263 236 464 263 239 464 minecraft:brown_terracotta
fill 263 236 488 265 236 490 minecraft:bone_block
setblock 263 236 503 minecraft:bone_block
fill 263 236 504 263 239 504 minecraft:brown_terracotta
setblock 264 236 491 minecraft:bone_block
setblock 264 236 502 minecraft:bone_block
fill 264 236 503 264 239 503 minecraft:brown_terracotta
setblock 265 236 465 minecraft:brown_terracotta
setblock 265 236 501 minecraft:bone_block
fill 265 236 502 265 239 502 minecraft:brown_terracotta
fill 266 236 488 266 236 489 minecraft:bone_block
fill 266 236 501 267 238 501 minecraft:brown_terracotta
setblock 267 236 464 minecraft:bone_block
setblock 267 236 504 minecraft:bone_block
fill 268 236 464 268 239 464 minecraft:brown_terracotta
setblock 268 236 503 minecraft:bone_block
fill 268 236 504 268 239 504 minecraft:brown_terracotta
setblock 269 236 502 minecraft:bone_block
fill 269 236 503 269 239 503 minecraft:brown_terracotta
fill 271 236 503 271 237 503 minecraft:brown_terracotta
setblock 272 236 504 minecraft:bone_block
fill 273 236 504 276 236 504 minecraft:brown_terracotta
setblock 275 236 496 minecraft:bone_block
fill 275 236 497 275 239 497 minecraft:brown_terracotta
setblock 275 236 501 minecraft:bone_block
fill 275 236 502 275 239 502 minecraft:brown_terracotta
setblock 276 236 475 minecraft:bone_block
fill 276 236 476 276 239 476 minecraft:brown_terracotta
setblock 276 236 480 minecraft:bone_block
fill 276 236 481 276 237 483 minecraft:brown_terracotta
setblock 276 236 490 minecraft:bone_block
fill 276 236 491 276 239 491 minecraft:brown_terracotta
setblock 276 236 495 minecraft:bone_block
fill 276 236 496 276 239 496 minecraft:brown_terracotta
setblock 276 236 500 minecraft:bone_block
fill 276 236 501 276 239 501 minecraft:brown_terracotta
fill 236 237 471 236 239 471 minecraft:brown_terracotta
setblock 236 237 474 minecraft:bone_block
fill 236 237 475 236 240 475 minecraft:brown_terracotta
setblock 236 237 478 minecraft:brown_terracotta
setblock 236 237 479 minecraft:bone_block
fill 236 237 480 236 237 483 minecraft:brown_terracotta
setblock 236 237 484 minecraft:bone_block
fill 236 237 485 236 237 488 minecraft:brown_terracotta
setblock 236 237 489 minecraft:bone_block
fill 236 237 490 236 240 490 minecraft:brown_terracotta
setblock 236 237 494 minecraft:bone_block
fill 236 237 495 236 240 495 minecraft:brown_terracotta
setblock 236 237 499 minecraft:bone_block
fill 236 237 500 237 239 500 minecraft:brown_terracotta
setblock 236 237 503 minecraft:brown_terracotta
setblock 237 237 473 minecraft:bone_block
fill 237 237 474 237 240 474 minecraft:brown_terracotta
setblock 237 237 478 minecraft:bone_block
fill 237 237 479 237 240 479 minecraft:brown_terracotta
setblock 237 237 483 minecraft:bone_block
fill 237 237 484 237 238 486 minecraft:brown_terracotta
fill 237 237 494 237 238 494 minecraft:brown_terracotta
setblock 237 237 498 minecraft:bone_block
fill 237 237 499 237 240 499 minecraft:brown_terracotta
fill 237 237 501 237 238 501 minecraft:brown_terracotta
fill 237 237 504 240 237 504 minecraft:brown_terracotta
setblock 238 237 477 minecraft:bone_block
fill 238 237 478 238 240 478 minecraft:brown_terracotta
setblock 238 237 481 minecraft:brown_terracotta
setblock 238 237 482 minecraft:bone_block
fill 238 237 483 238 239 484 minecraft:brown_terracotta
fill 239 237 464 240 237 464 minecraft:brown_terracotta
setblock 239 237 475 minecraft:brown_terracotta
setblock 239 237 476 minecraft:bone_block
fill 239 237 477 239 240 477 minecraft:brown_terracotta
setblock 239 237 480 minecraft:brown_terracotta
setblock 239 237 481 minecraft:bone_block
fill 239 237 482 239 240 482 minecraft:brown_terracotta
fill 239 237 503 241 237 503 minecraft:brown_terracotta
setblock 241 237 464 minecraft:bone_block
setblock 241 237 504 minecraft:bone_block
fill 242 237 464 242 240 464 minecraft:brown_terracotta
setblock 242 237 503 minecraft:bone_block
fill 242 237 504 242 240 504 minecraft:brown_terracotta
fill 243 237 465 244 237 465 minecraft:brown_terracotta
fill 243 237 503 243 240 503 minecraft:brown_terracotta
fill 244 237 504 245 237 504 minecraft:brown_terracotta
setblock 245 237 464 minecraft:brown_terracotta
setblock 245 237 465 minecraft:bone_block
fill 245 237 503 246 237 503 minecraft:brown_terracotta
setblock 246 237 464 minecraft:bone_block
setblock 246 237 504 minecraft:bone_block
fill 247 237 464 247 240 464 minecraft:brown_terracotta
fill 247 237 504 247 240 504 minecraft:brown_terracotta
fill 249 237 504 250 237 504 minecraft:brown_terracotta
setblock 250 237 464 minecraft:brown_terracotta
setblock 251 237 464 minecraft:bone_block
setblock 251 237 504 minecraft:bone_block
fill 252 237 464 255 237 464 minecraft:brown_terracotta
fill 252 237 504 255 237 504 minecraft:brown_terracotta
fill 255 237 503 256 237 503 minecraft:brown_terracotta
setblock 256 237 464 minecraft:bone_block
setblock 256 237 504 minecraft:bone_block
fill 257 237 464 260 237 464 minecraft:brown_terracotta
setblock 257 237 503 minecraft:bone_block
fill 257 237 504 260 237 504 minecraft:brown_terracotta
fill 258 237 465 259 237 465 minecraft:brown_terracotta
setblock 258 237 502 minecraft:bone_block
fill 258 237 503 261 237 503 minecraft:brown_terracotta
fill 259 237 502 262 237 502 minecraft:brown_terracotta
setblock 260 237 465 minecraft:bone_block
fill 260 237 501 263 237 501 minecraft:brown_terracotta
setblock 261 237 464 minecraft:bone_block
fill 261 237 465 261 240 465 minecraft:brown_terracotta
setblock 261 237 504 minecraft:bone_block
fill 262 237 464 262 240 464 minecraft:brown_terracotta
setblock 262 237 503 minecraft:bone_block
fill 262 237 504 262 240 504 minecraft:brown_terracotta
setblock 263 237 502 minecraft:bone_block
fill 263 237 503 263 240 503 minecraft:brown_terracotta
setblock 264 237 501 minecraft:bone_block
fill 264 237 502 264 240 502 minecraft:brown_terracotta
setblock 265 237 465 minecraft:bone_block
fill 265 237 501 265 240 501 minecraft:brown_terracotta
setblock 266 237 464 minecraft:bone_block
setblock 266 237 504 minecraft:bone_block
fill 267 237 464 267 240 464 minecraft:brown_terracotta
setblock 267 237 502 minecraft:brown_terracotta
setblock 267 237 503 minecraft:bone_block
fill 267 237 504 267 240 504 minecraft:brown_terracotta
setblock 268 237 502 minecraft:bone_block
fill 268 237 503 268 240 503 minecraft:brown_terracotta
fill 269 237 502 270 239 502 minecraft:brown_terracotta
setblock 271 237 504 minecraft:bone_block
setblock 272 237 503 minecraft:bone_block
fill 272 237 504 275 237 504 minecraft:brown_terracotta
fill 273 237 503 273 240 503 minecraft:brown_terracotta
setblock 275 237 495 minecraft:bone_block
fill 275 237 496 275 240 496 minecraft:brown_terracotta
setblock 275 237 500 minecraft:bone_block
fill 275 237 501 275 240 501 minecraft:brown_terracotta
fill 275 237 503 275 238 503 minecraft:brown_terracotta
setblock 276 237 474 minecraft:bone_block
fill 276 237 475 276 240 475 minecraft:brown_terracotta
fill 276 237 477 276 237 478 minecraft:brown_terracotta
setblock 276 237 479 minecraft:bone_block
fill 276 237 480 276 240 480 minecraft:brown_terracotta
setblock 276 237 484 minecraft:bone_block
fill 276 237 485 276 237 488 minecraft:brown_terracotta
setblock 276 237 489 minecraft:bone_block
fill 276 237 490 276 240 490 minecraft:brown_terracotta
setblock 276 237 494 minecraft:bone_block
fill 276 237 495 276 240 495 minecraft:brown_terracotta
setblock 276 237 499 minecraft:bone_block
fill 276 237 500 276 240 500 minecraft:brown_terracotta
setblock 276 237 504 minecraft:bone_block
setblock 236 238 473 minecraft:bone_block
fill 236 238 474 236 241 474 minecraft:brown_terracotta
setblock 236 238 478 minecraft:bone_block
fill 236 238 479 236 238 482 minecraft:brown_terracotta
setblock 236 238 483 minecraft:bone_block
fill 236 238 484 236 238 487 minecraft:brown_terracotta
setblock 236 238 488 minecraft:bone_block
fill 236 238 489 236 241 489 minecraft:brown_terracotta
setblock 236 238 493 minecraft:bone_block
fill 236 238 494 236 241 494 minecraft:brown_terracotta
setblock 236 238 497 minecraft:brown_terracotta
setblock 236 238 498 minecraft:bone_block
fill 236 238 499 236 241 499 minecraft:brown_terracotta
setblock 236 238 503 minecraft:bone_block
fill 236 238 504 239 238 504 minecraft:brown_terracotta
setblock 237 238 472 minecraft:bone_block
fill 237 238 473 238 240 473 minecraft:brown_terracotta
setblock 237 238 476 minecraft:brown_terracotta
setblock 237 238 477 minecraft:bone_block
fill 237 238 478 237 241 478 minecraft:brown_terracotta
setblock 237 238 481 minecraft:brown_terracotta
setblock 237 238 482 minecraft:bone_block
fill 237 238 483 237 241 483 minecraft:brown_terracotta
setblock 237 238 487 minecraft:bone_block
fill 237 238 488 237 241 488 minecraft:brown_terracotta
setblock 237 238 497 minecraft:bone_block
fill 237 238 498 237 241 498 minecraft:brown_terracotta
setblock 237 238 502 minecraft:bone_block
fill 238 238 464 239 238 464 minecraft:brown_terracotta
setblock 238 238 476 minecraft:bone_block
fill 238 238 477 238 241 477 minecraft:brown_terracotta
setblock 238 238 481 minecraft:bone_block
fill 238 238 482 238 241 482 minecraft:brown_terracotta
setblock 238 238 485 minecraft:brown_terracotta
fill 238 238 503 240 238 503 minecraft:brown_terracotta
setblock 239 238 475 minecraft:bone_block
fill 239 238 476 239 241 476 minecraft:brown_terracotta
setblock 239 238 480 minecraft:bone_block
fill 239 238 481 239 241 481 minecraft:brown_terracotta
fill 239 238 483 239 239 483 minecraft:brown_terracotta
setblock 240 238 464 minecraft:bone_block
fill 240 238 477 240 238 478 minecraft:brown_terracotta
setblock 240 238 479 minecraft:bone_block
fill 240 238 480 240 241 480 minecraft:brown_terracotta
setblock 240 238 504 minecraft:bone_block
fill 241 238 464 241 240 465 minecraft:brown_terracotta
setblock 241 238 502 minecraft:brown_terracotta
setblock 241 238 503 minecraft:bone_block
fill 241 238 504 241 241 504 minecraft:brown_terracotta
fill 242 238 465 243 238 465 minecraft:brown_terracotta
setblock 242 238 502 minecraft:bone_block
fill 242 238 503 242 241 503 minecraft:brown_terracotta
setblock 244 238 465 minecraft:bone_block
setblock 244 238 504 minecraft:brown_terracotta
setblock 245 238 464 minecraft:bone_block
fill 245 238 465 246 240 465 minecraft:brown_terracotta
setblock 245 238 503 minecraft:brown_terracotta
setblock 245 238 504 minecraft:bone_block
fill 246 238 464 246 241 464 minecraft:brown_terracotta
setblock 246 238 503 minecraft:bone_block
fill 246 238 504 246 241 504 minecraft:brown_terracotta
fill 247 238 503 247 240 503 minecraft:brown_terracotta
setblock 249 238 504 minecraft:brown_terracotta
setblock 250 238 464 minecraft:bone_block
setblock 250 238 504 minecraft:bone_block
fill 251 238 464 254 238 464 minecraft:brown_terracotta
fill 251 238 504 254 238 504 minecraft:brown_terracotta
fill 254 238 503 255 238 503 minecraft:brown_terracotta
setblock 255 238 464 minecraft:bone_block
setblock 255 238 504 minecraft:bone_block
fill 256 238 464 258 238 465 minecraft:brown_terracotta
setblock 256 238 502 minecraft:brown_terracotta
setblock 256 238 503 minecraft:bone_block
fill 256 238 504 259 238 504 minecraft:brown_terracotta
setblock 257 238 502 minecraft:bone_block
fill 257 238 503 260 238 503 minecraft:brown_terracotta
setblock 258 238 501 minecraft:bone_block
fill 258 238 502 261 238 502 minecraft:brown_terracotta
setblock 259 238 464 minecraft:brown_terracotta
setblock 259 238 465 minecraft:bone_block
fill 259 238 501 262 238 501 minecraft:brown_terracotta
setblock 260 238 464 minecraft:bone_block
fill 260 238 465 260 241 465 minecraft:brown_terracotta
setblock 260 238 504 minecraft:bone_block
fill 261 238 464 261 241 464 minecraft:brown_terracotta
setblock 261 238 503 minecraft:bone_block
fill 261 238 504 261 241 504 minecraft:brown_terracotta
fill 262 238 500 263 238 500 minecraft:brown_terracotta
setblock 262 238 502 minecraft:bone_block
fill 262 238 503 262 241 503 minecraft:brown_terracotta
setblock 263 238 501 minecraft:bone_block
fill 263 238 502 263 241 502 minecraft:brown_terracotta
setblock 264 238 465 minecraft:bone_block
setblock 264 238 500 minecraft:bone_block
fill 264 238 501 264 241 501 minecraft:brown_terracotta
setblock 265 238 464 minecraft:bone_block
fill 265 238 465 265 239 465 minecraft:brown_terracotta
setblock 265 238 504 minecraft:bone_block
fill 266 238 464 266 241 464 minecraft:brown_terracotta
setblock 266 238 503 minecraft:bone_block
fill 266 238 504 266 241 504 minecraft:brown_terracotta
setblock 267 238 502 minecraft:bone_block
fill 267 238 503 267 241 503 minecraft:brown_terracotta
fill 268 238 502 268 241 502 minecraft:brown_terracotta
setblock 270 238 504 minecraft:bone_block
setblock 271 238 503 minecraft:bone_block
fill 271 238 504 274 238 504 minecraft:brown_terracotta
fill 272 238 503 272 241 503 minecraft:brown_terracotta
fill 274 238 498 274 238 499 minecraft:brown_terracotta
setblock 274 238 500 minecraft:bone_block
fill 274 238 503 274 239 503 minecraft:brown_terracotta
setblock 275 238 478 minecraft:brown_terracotta
setblock 275 238 479 minecraft:bone_block
fill 275 238 480 275 238 483 minecraft:brown_terracotta
setblock 275 238 493 minecraft:brown_terracotta
setblock 275 238 494 minecraft:bone_block
fill 275 238 495 275 241 495 minecraft:brown_terracotta
setblock 275 238 499 minecraft:bone_block
fill 275 238 500 275 241 500 minecraft:brown_terracotta
setblock 275 238 504 minecraft:bone_block
fill 276 238 474 276 241 474 minecraft:brown_terracotta
setblock 276 238 477 minecraft:brown_terracotta
setblock 276 238 478 minecraft:bone_block
fill 276 238 479 276 241 479 minecraft:brown_terracotta
fill 276 238 481 276 238 482 minecraft:brown_terracotta
setblock 276 238 483 minecraft:bone_block
fill 276 238 484 276 238 487 minecraft:brown_terracotta
setblock 276 238 488 minecraft:bone_block
fill 276 238 489 276 241 489 minecraft:brown_terracotta
setblock 276 238 493 minecraft:bone_block
fill 276 238 494 276 241 494 minecraft:brown_terracotta
setblock 276 238 498 minecraft:bone_block
fill 276 238 499 276 241 499 minecraft:brown_terracotta
setblock 276 238 502 minecraft:brown_terracotta
setblock 276 238 503 minecraft:bone_block
fill 276 238 504 276 241 504 minecraft:brown_terracotta
fill 236 239 470 236 240 470 minecraft:brown_terracotta
setblock 236 239 472 minecraft:bone_block
fill 236 239 473 236 242 473 minecraft:brown_terracotta
setblock 236 239 477 minecraft:bone_block
fill 236 239 478 236 239 481 minecraft:brown_terracotta
setblock 236 239 482 minecraft:bone_block
fill 236 239 483 236 239 486 minecraft:brown_terracotta
setblock 236 239 487 minecraft:bone_block
fill 236 239 488 236 242 488 minecraft:brown_terracotta
setblock 236 239 492 minecraft:bone_block
fill 236 239 493 236 242 493 minecraft:brown_terracotta
setblock 236 239 497 minecraft:bone_block
fill 236 239 498 236 242 498 minecraft:brown_terracotta
setblock 236 239 501 minecraft:brown_terracotta
setblock 236 239 502 minecraft:bone_block
fill 236 239 503 238 239 504 minecraft:brown_terracotta
fill 237 239 464 238 239 464 minecraft:brown_terracotta
fill 237 239 472 237 242 472 minecraft:brown_terracotta
setblock 237 239 475 minecraft:brown_terracotta
setblock 237 239 476 minecraft:bone_block
fill 237 239 477 237 242 477 minecraft:brown_terracotta
setblock 237 239 480 minecraft:brown_terracotta
setblock 237 239 481 minecraft:bone_block
fill 237 239 482 237 242 482 minecraft:brown_terracotta
fill 237 239 484 237 239 485 minecraft:brown_terracotta
setblock 237 239 486 minecraft:bone_block
fill 237 239 487 237 242 487 minecraft:brown_terracotta
fill 237 239 489 237 240 489 minecraft:brown_terracotta
setblock 237 239 496 minecraft:bone_block
fill 237 239 497 237 241 497 minecraft:brown_terracotta
setblock 237 239 501 minecraft:bone_block
fill 237 239 502 237 242 502 minecraft:brown_terracotta
setblock 238 239 475 minecraft:bone_block
fill 238 239 476 238 242 476 minecraft:brown_terracotta
setblock 238 239 479 minecraft:brown_terracotta
setblock 238 239 480 minecraft:bone_block
fill 238 239 481 238 242 481 minecraft:brown_terracotta
setblock 238 239 485 minecraft:bone_block
fill 238 239 486 238 242 486 minecraft:brown_terracotta
setblock 239 239 464 minecraft:bone_block
fill 239 239 465 240 241 465 minecraft:brown_terracotta
fill 239 239 475 239 240 475 minecraft:brown_terracotta
setblock 239 239 479 minecraft:bone_block
fill 239 239 480 239 242 480 minecraft:brown_terracotta
setblock 239 239 484 minecraft:bone_block
setblock 239 239 503 minecraft:brown_terracotta
setblock 239 239 504 minecraft:bone_block
fill 240 239 464 240 242 464 minecraft:brown_terracotta
setblock 240 239 477 minecraft:brown_terracotta
setblock 240 239 478 minecraft:bone_block
fill 240 239 479 240 241 479 minecraft:brown_terracotta
fill 240 239 481 240 240 481 minecraft:brown_terracotta
setblock 240 239 502 minecraft:brown_terracotta
setblock 240 239 503 minecraft:bone_block
fill 240 239 504 240 242 504 minecraft:brown_terracotta
setblock 241 239 502 minecraft:bone_block
fill 241 239 503 241 242 503 minecraft:brown_terracotta
setblock 242 239 465 minecraft:brown_terracotta
fill 242 239 502 243 239 502 minecraft:brown_terracotta
setblock 243 239 465 minecraft:bone_block
setblock 244 239 464 minecraft:bone_block
fill 244 239 465 244 242 465 minecraft:brown_terracotta
setblock 244 239 504 minecraft:bone_block
fill 245 239 464 245 242 464 minecraft:brown_terracotta
setblock 245 239 503 minecraft:bone_block
fill 245 239 504 245 242 504 minecraft:brown_terracotta
fill 246 239 503 246 241 503 minecraft:brown_terracotta
setblock 248 239 464 minecraft:brown_terracotta
setblock 249 239 464 minecraft:bone_block
setblock 249 239 504 minecraft:bone_block
fill 250 239 464 253 239 464 minecraft:brown_terracotta
fill 250 239 504 253 239 504 minecraft:brown_terracotta
fill 253 239 503 254 239 503 minecraft:brown_terracotta
setblock 254 239 464 minecraft:bone_block
setblock 254 239 504 minecraft:bone_block
fill 255 239 464 257 239 465 minecraft:brown_terracotta
setblock 255 239 502 minecraft:brown_terracotta
setblock 255 239 503 minecraft:bone_block
fill 255 239 504 258 239 504 minecraft:brown_terracotta
setblock 256 239 502 minecraft:bone_block
fill 256 239 503 259 239 503 minecraft:brown_terracotta
fill 257 239 502 260 239 502 minecraft:brown_terracotta
setblock 258 239 464 minecraft:brown_terracotta
setblock 258 239 465 minecraft:bone_block
fill 258 239 501 261 239 501 minecraft:brown_terracotta
setblock 259 239 464 minecraft:bone_block
fill 259 239 465 259 242 465 minecraft:brown_terracotta
setblock 259 239 504 minecraft:bone_block
fill 260 239 464 260 242 464 minecraft:brown_terracotta
setblock 260 239 503 minecraft:bone_block
fill 260 239 504 260 242 504 minecraft:brown_terracotta
fill 261 239 500 262 239 500 minecraft:brown_terracotta
setblock 261 239 502 minecraft:bone_block
fill 261 239 503 261 242 503 minecraft:brown_terracotta
setblock 262 239 501 minecraft:bone_block
fill 262 239 502 262 242 502 minecraft:brown_terracotta
setblock 263 239 465 minecraft:bone_block
setblock 263 239 500 minecraft:bone_block
fill 263 239 501 263 242 501 minecraft:brown_terracotta
setblock 264 239 464 minecraft:bone_block
fill 264 239 465 264 241 465 minecraft:brown_terracotta
setblock 264 239 500 minecraft:brown_terracotta
setblock 264 239 504 minecraft:bone_block
fill 265 239 464 265 242 464 minecraft:brown_terracotta
setblock 265 239 503 minecraft:bone_block
fill 265 239 504 265 242 504 minecraft:brown_terracotta
setblock 266 239 501 minecraft:brown_terracotta
setblock 266 239 502 minecraft:bone_block
fill 266 239 503 266 242 503 minecraft:brown_terracotta
setblock 267 239 501 minecraft:bone_block
fill 267 239 502 267 242 502 minecraft:brown_terracotta
setblock 269 239 504 minecraft:bone_block
setblock 270 239 503 minecraft:bone_block
fill 270 239 504 273 239 504 minecraft:brown_terracotta
fill 271 239 503 271 242 503 minecraft:brown_terracotta
setblock 274 239 499 minecraft:bone_block
fill 274 239 500 274 239 501 minecraft:brown_terracotta
setblock 274 239 504 minecraft:bone_block
setblock 275 239 477 minecraft:brown_terracotta
setblock 275 239 478 minecraft:bone_block
fill 275 239 479 275 239 482 minecraft:brown_terracotta
setblock 275 239 483 minecraft:bone_block
fill 275 239 484 276 240 485 minecraft:brown_terracotta
setblock 275 239 493 minecraft:bone_block
fill 275 239 494 275 240 494 minecraft:brown_terracotta
setblock 275 239 498 minecraft:bone_block
fill 275 239 499 275 242 499 minecraft:brown_terracotta
setblock 275 239 503 minecraft:bone_block
fill 275 239 504 275 242 504 minecraft:brown_terracotta
setblock 276 239 477 minecraft:bone_block
fill 276 239 478 276 242 478 minecraft:brown_terracotta
setblock 276 239 481 minecraft:brown_terracotta
setblock 276 239 482 minecraft:bone_block
fill 276 239 483 276 242 483 minecraft:brown_terracotta
setblock 276 239 486 minecraft:brown_terracotta
setblock 276 239 487 minecraft:bone_block
fill 276 239 488 276 242 488 minecraft:brown_terracotta
setblock 276 239 492 minecraft:bone_block
fill 276 239 493 276 242 493 minecraft:brown_terracotta
setblock 276 239 497 minecraft:bone_block
fill 276 239 498 276 242 498 minecraft:brown_terracotta
setblock 276 239 502 minecraft:bone_block
fill 276 239 503 276 242 503 minecraft:brown_terracotta
fill 236 240 464 236 240 465 minecraft:brown_terracotta
fill 236 240 469 236 241 469 minecraft:brown_terracotta
setblock 236 240 471 minecraft:bone_block
fill 236 240 472 236 243 472 minecraft:brown_terracotta
setblock 236 240 476 minecraft:bone_block
fill 236 240 477 236 240 480 minecraft:brown_terracotta
setblock 236 240 481 minecraft:bone_block
fill 236 240 482 236 240 485 minecraft:brown_terracotta
setblock 236 240 486 minecraft:bone_block
fill 236 240 487 236 243 487 minecraft:brown_terracotta
setblock 236 240 491 minecraft:bone_block
fill 236 240 492 236 243 492 minecraft:brown_terracotta
setblock 236 240 496 minecraft:bone_block
fill 236 240 497 236 243 497 minecraft:brown_terracotta
setblock 236 240 500 minecraft:brown_terracotta
setblock 236 240 501 minecraft:bone_block
fill 236 240 502 236 241 504 minecraft:brown_terracotta
setblock 237 240 464 minecraft:brown_terracotta
setblock 237 240 475 minecraft:bone_block
fill 237 240 476 237 243 476 minecraft:brown_terracotta
setblock 237 240 480 minecraft:bone_block
fill 237 240 481 237 243 481 minecraft:brown_terracotta
setblock 237 240 484 minecraft:brown_terracotta
setblock 237 240 485 minecraft:bone_block
fill 237 240 486 237 243 486 minecraft:brown_terracotta
setblock 237 240 496 minecraft:brown_terracotta
setblock 237 240 500 minecraft:bone_block
fill 237 240 501 237 243 501 minecraft:brown_terracotta
fill 237 240 503 237 240 504 minecraft:brown_terracotta
setblock 238 240 464 minecraft:bone_block
setblock 238 240 466 minecraft:light[level=12]
setblock 238 240 474 minecraft:bone_block
fill 238 240 475 238 243 475 minecraft:brown_terracotta
setblock 238 240 479 minecraft:bone_block
fill 238 240 480 238 243 480 minecraft:brown_terracotta
setblock 238 240 483 minecraft:brown_terracotta
setblock 238 240 484 minecraft:bone_block
fill 238 240 485 238 243 485 minecraft:brown_terracotta
setblock 238 240 490 minecraft:light[level=12]
setblock 238 240 498 minecraft:light[level=12]
setblock 238 240 503 minecraft:brown_terracotta
setblock 238 240 504 minecraft:bone_block
fill 239 240 464 239 243 464 minecraft:brown_terracotta
setblock 239 240 478 minecraft:bone_block
fill 239 240 479 239 243 479 minecraft:brown_terracotta
setblock 239 240 483 minecraft:bone_block
fill 239 240 484 239 243 484 minecraft:brown_terracotta
setblock 239 240 502 minecraft:brown_terracotta
setblock 239 240 503 minecraft:bone_block
fill 239 240 504 239 243 504 minecraft:brown_terracotta
setblock 240 240 477 minecraft:bone_block
setblock 240 240 478 minecraft:brown_terracotta
setblock 240 240 482 minecraft:bone_block
setblock 240 240 502 minecraft:bone_block
fill 240 240 503 240 243 503 minecraft:brown_terracotta
fill 241 240 502 242 240 502 minecraft:brown_terracotta
setblock 242 240 465 minecraft:bone_block
setblock 243 240 464 minecraft:bone_block
fill 243 240 465 243 243 465 minecraft:brown_terracotta
setblock 243 240 504 minecraft:bone_block
fill 244 240 464 244 243 464 minecraft:brown_terracotta
setblock 244 240 503 minecraft:bone_block
fill 244 240 504 244 243 504 minecraft:brown_terracotta
fill 245 240 503 245 242 503 minecraft:brown_terracotta
setblock 246 240 466 minecraft:light[level=12]
setblock 246 240 474 minecraft:light[level=12]
setblock 246 240 482 minecraft:light[level=12]
setblock 246 240 490 minecraft:light[level=12]
setblock 246 240 498 minecraft:light[level=12]
setblock 248 240 464 minecraft:bone_block
setblock 248 240 504 minecraft:bone_block
fill 249 240 464 252 240 464 minecraft:brown_terracotta
fill 249 240 504 252 240 504 minecraft:brown_terracotta
fill 252 240 503 253 240 503 minecraft:brown_terracotta
setblock 253 240 464 minecraft:bone_block
setblock 253 240 504 minecraft:bone_block
fill 254 240 464 256 240 465 minecraft:brown_terracotta
setblock 254 240 466 minecraft:light[level=12]
setblock 254 240 474 minecraft:light[level=12]
setblock 254 240 482 minecraft:light[level=12]
setblock 254 240 490 minecraft:light[level=12]
setblock 254 240 498 minecraft:light[level=12]
setblock 254 240 503 minecraft:bone_block
fill 254 240 504 257 240 504 minecraft:brown_terracotta
setblock 255 240 502 minecraft:bone_block
fill 255 240 503 258 240 503 minecraft:brown_terracotta
fill 256 240 502 259 240 502 minecraft:brown_terracotta
setblock 257 240 464 minecraft:brown_terracotta
setblock 257 240 465 minecraft:bone_block
fill 257 240 501 260 240 501 minecraft:brown_terracotta
setblock 258 240 464 minecraft:bone_block
fill 258 240 465 258 243 465 minecraft:brown_terracotta
setblock 258 240 504 minecraft:bone_block
fill 259 240 464 259 243 464 minecraft:brown_terracotta
setblock 259 240 503 minecraft:bone_block
fill 259 240 504 259 243 504 minecraft:brown_terracotta
setblock 260 240 502 minecraft:bone_block
fill 260 240 503 260 243 503 minecraft:brown_terracotta
setblock 261 240 500 minecraft:brown_terracotta
setblock 261 240 501 minecraft:bone_block
fill 261 240 502 261 243 502 minecraft:brown_terracotta
setblock 262 240 465 minecraft:bone_block
setblock 262 240 466 minecraft:light[level=12]
setblock 262 240 474 minecraft:light[level=12]
setblock 262 240 482 minecraft:light[level=12]
setblock 262 240 490 minecraft:light[level=12]
setblock 262 240 498 minecraft:light[level=12]
setblock 262 240 500 minecraft:bone_block
fill 262 240 501 262 243 501 minecraft:brown_terracotta
setblock 263 240 464 minecraft:bone_block
fill 263 240 465 263 243 465 minecraft:brown_terracotta
setblock 263 240 504 minecraft:bone_block
fill 264 240 464 264 243 464 minecraft:brown_terracotta
setblock 264 240 503 minecraft:bone_block
fill 264 240 504 264 243 504 minecraft:brown_terracotta
setblock 265 240 502 minecraft:bone_block
fill 265 240 503 265 243 503 minecraft:brown_terracotta
setblock 266 240 501 minecraft:bone_block
fill 266 240 502 266 242 502 minecraft:brown_terracotta
setblock 268 240 464 minecraft:bone_block
setblock 268 240 504 minecraft:bone_block
setblock 269 240 502 minecraft:brown_terracotta
setblock 269 240 503 minecraft:bone_block
fill 269 240 504 272 240 504 minecraft:brown_terracotta
setblock 270 240 466 minecraft:light[level=12]
setblock 270 240 474 minecraft:light[level=12]
setblock 270 240 482 minecraft:light[level=12]
setblock 270 240 490 minecraft:light[level=12]
setblock 270 240 498 minecraft:light[level=12]
fill 270 240 503 270 242 503 minecraft:brown_terracotta
setblock 273 240 504 minecraft:bone_block
setblock 274 240 500 minecraft:brown_terracotta
setblock 274 240 503 minecraft:bone_block
fill 274 240 504 274 243 504 minecraft:brown_terracotta
setblock 275 240 477 minecraft:bone_block
fill 275 240 478 275 240 481 minecraft:brown_terracotta
setblock 275 240 482 minecraft:bone_block
fill 275 240 483 275 243 483 minecraft:brown_terracotta
setblock 275 240 486 minecraft:brown_terracotta
setblock 275 240 487 minecraft:bone_block
setblock 275 240 497 minecraft:bone_block
fill 275 240 498 275 243 498 minecraft:brown_terracotta
setblock 275 240 502 minecraft:bone_block
fill 275 240 503 275 243 503 minecraft:brown_terracotta
setblock 276 240 476 minecraft:bone_block
fill 276 240 477 276 243 477 minecraft:brown_terracotta
setblock 276 240 481 minecraft:bone_block
fill 276 240 482 276 243 482 minecraft:brown_terracotta
setblock 276 240 486 minecraft:bone_block
fill 276 240 487 276 243 487 minecraft:brown_terracotta
setblock 276 240 491 minecraft:bone_block
fill 276 240 492 276 243 492 minecraft:brown_terracotta
setblock 276 240 496 minecraft:bone_block
fill 276 240 497 276 243 497 minecraft:brown_terracotta
setblock 276 240 501 minecraft:bone_block
fill 276 240 502 276 243 502 minecraft:brown_terracotta
setblock 236 241 464 minecraft:brown_terracotta
setblock 236 241 465 minecraft:bone_block
fill 236 241 466 236 242 468 minecraft:brown_terracotta
setblock 236 241 470 minecraft:bone_block
fill 236 241 471 236 244 471 minecraft:brown_terracotta
setblock 236 241 475 minecraft:bone_block
fill 236 241 476 236 241 479 minecraft:brown_terracotta
setblock 236 241 480 minecraft:bone_block
fill 236 241 481 236 241 484 minecraft:brown_terracotta
setblock 236 241 485 minecraft:bone_block
fill 236 241 486 236 244 486 minecraft:brown_terracotta
setblock 236 241 490 minecraft:bone_block
fill 236 241 491 236 244 491 minecraft:brown_terracotta
setblock 236 241 495 minecraft:bone_block
fill 236 241 496 236 242 496 minecraft:brown_terracotta
setblock 236 241 500 minecraft:bone_block
fill 236 241 501 236 244 501 minecraft:brown_terracotta
setblock 237 241 464 minecraft:bone_block
setblock 237 241 473 minecraft:brown_terracotta
setblock 237 241 474 minecraft:bone_block
fill 237 241 475 237 244 475 minecraft:brown_terracotta
setblock 237 241 479 minecraft:bone_block
fill 237 241 480 237 244 480 minecraft:brown_terracotta
setblock 237 241 484 minecraft:bone_block
fill 237 241 485 237 244 485 minecraft:brown_terracotta
setblock 237 241 489 minecraft:bone_block
setblock 237 241 499 minecraft:bone_block
fill 237 241 500 237 242 500 minecraft:brown_terracotta
setblock 237 241 503 minecraft:brown_terracotta
setblock 237 241 504 minecraft:bone_block
fill 238 241 464 238 243 465 minecraft:brown_terracotta
fill 238 241 474 238 242 474 minecraft:brown_terracotta
setblock 238 241 478 minecraft:bone_block
fill 238 241 479 238 244 479 minecraft:brown_terracotta
setblock 238 241 483 minecraft:bone_block
fill 238 241 484 238 244 484 minecraft:brown_terracotta
setblock 238 241 487 minecraft:brown_terracotta
fill 238 241 502 238 245 502 minecraft:soul_soil
setblock 238 241 503 minecraft:bone_block
fill 238 241 504 238 244 504 minecraft:brown_terracotta
setblock 239 241 477 minecraft:bone_block
fill 239 241 478 239 243 478 minecraft:brown_terracotta
setblock 239 241 482 minecraft:bone_block
fill 239 241 483 239 244 483 minecraft:brown_terracotta
fill 239 241 503 239 244 503 minecraft:brown_terracotta
setblock 240 241 481 minecraft:bone_block
setblock 240 241 502 minecraft:brown_terracotta
setblock 241 241 464 minecraft:brown_terracotta
setblock 241 241 465 minecraft:bone_block
setblock 242 241 464 minecraft:bone_block
fill 242 241 465 242 244 465 minecraft:brown_terracotta
setblock 242 241 504 minecraft:bone_block
fill 243 241 464 243 244 464 minecraft:brown_terracotta
setblock 243 241 503 minecraft:bone_block
fill 243 241 504 243 244 504 minecraft:brown_terracotta
fill 244 241 503 244 242 503 minecraft:brown_terracotta
setblock 245 241 465 minecraft:brown_terracotta
setblock 246 241 465 minecraft:bone_block
setblock 247 241 464 minecraft:bone_block
setblock 247 241 504 minecraft:bone_block
fill 248 241 464 251 241 464 minecraft:brown_terracotta
fill 248 241 504 251 241 504 minecraft:brown_terracotta
setblock 252 241 464 minecraft:bone_block
setblock 252 241 503 minecraft:brown_terracotta
setblock 252 241 504 minecraft:bone_block
fill 253 241 464 255 241 465 minecraft:brown_terracotta
setblock 253 241 503 minecraft:bone_block
fill 253 241 504 256 241 504 minecraft:brown_terracotta
fill 254 241 503 257 241 503 minecraft:brown_terracotta
fill 255 241 502 258 241 502 minecraft:brown_terracotta
setblock 256 241 464 minecraft:brown_terracotta
setblock 256 241 465 minecraft:bone_block
setblock 257 241 464 minecraft:bone_block
fill 257 241 465 257 244 465 minecraft:brown_terracotta
fill 257 241 501 259 241 501 minecraft:brown_terracotta
setblock 257 241 504 minecraft:bone_block
fill 258 241 464 258 244 464 minecraft:brown_terracotta
setblock 258 241 503 minecraft:bone_block
fill 258 241 504 258 244 504 minecraft:brown_terracotta
setblock 259 241 466 minecraft:brown_terracotta
setblock 259 241 502 minecraft:bone_block
fill 259 241 503 259 244 503 minecraft:brown_terracotta
setblock 260 241 501 minecraft:bone_block
fill 260 241 502 260 244 502 minecraft:brown_terracotta
setblock 261 241 465 minecraft:bone_block
fill 261 241 501 261 243 501 minecraft:brown_terracotta
setblock 262 241 464 minecraft:bone_block
fill 262 241 465 262 244 465 minecraft:brown_terracotta
setblock 262 241 504 minecraft:bone_block
fill 263 241 464 263 244 464 minecraft:brown_terracotta
setblock 263 241 503 minecraft:bone_block
fill 263 241 504 263 244 504 minecraft:brown_terracotta
setblock 264 241 502 minecraft:bone_block
fill 264 241 503 264 244 503 minecraft:brown_terracotta
setblock 265 241 501 minecraft:bone_block
fill 265 241 502 265 243 502 minecraft:brown_terracotta
setblock 267 241 464 minecraft:bone_block
setblock 267 241 504 minecraft:bone_block
setblock 268 241 503 minecraft:bone_block
fill 268 241 504 271 241 504 minecraft:brown_terracotta
fill 269 241 503 269 243 503 minecraft:brown_terracotta
setblock 272 241 504 minecraft:bone_block
setblock 273 241 503 minecraft:bone_block
fill 273 241 504 273 244 504 minecraft:brown_terracotta
fill 274 241 503 274 244 503 minecraft:brown_terracotta
fill 275 241 477 275 241 480 minecraft:brown_terracotta
setblock 275 241 481 minecraft:bone_block
fill 275 241 482 275 244 482 minecraft:brown_terracotta
fill 275 241 484 275 241 485 minecraft:brown_terracotta
setblock 275 241 486 minecraft:bone_block
fill 275 241 487 275 243 488 minecraft:brown_terracotta
setblock 275 241 496 minecraft:bone_block
fill 275 241 497 275 242 497 minecraft:brown_terracotta
setblock 275 241 501 minecraft:bone_block
fill 275 241 502 275 244 502 minecraft:brown_terracotta
setblock 276 241 464 minecraft:brown_terracotta
setblock 276 241 475 minecraft:bone_block
fill 276 241 476 276 244 476 minecraft:brown_terracotta
setblock 276 241 480 minecraft:bone_block
fill 276 241 481 276 244 481 minecraft:brown_terracotta
setblock 276 241 484 minecraft:brown_terracotta
setblock 276 241 485 minecraft:bone_block
fill 276 241 486 276 244 486 minecraft:brown_terracotta
setblock 276 241 490 minecraft:bone_block
fill 276 241 491 276 244 491 minecraft:brown_terracotta
setblock 276 241 495 minecraft:bone_block
fill 276 241 496 276 244 496 minecraft:brown_terracotta
setblock 276 241 500 minecraft:bone_block
fill 276 241 501 276 244 501 minecraft:brown_terracotta
setblock 236 242 464 minecraft:bone_block
fill 236 242 465 237 244 465 minecraft:brown_terracotta
setblock 236 242 469 minecraft:bone_block
fill 236 242 470 236 245 470 minecraft:brown_terracotta
setblock 236 242 474 minecraft:bone_block
fill 236 242 475 236 242 478 minecraft:brown_terracotta
setblock 236 242 479 minecraft:bone_block
fill 236 242 480 236 242 483 minecraft:brown_terracotta
setblock 236 242 484 minecraft:bone_block
fill 236 242 485 236 245 485 minecraft:brown_terracotta
setblock 236 242 489 minecraft:bone_block
fill 236 242 490 236 245 490 minecraft:brown_terracotta
setblock 236 242 494 minecraft:bone_block
setblock 236 242 495 minecraft:brown_terracotta
setblock 236 242 499 minecraft:bone_block
fill 236 242 500 236 245 500 minecraft:brown_terracotta
fill 236 242 502 236 242 503 minecraft:brown_terracotta
setblock 236 242 504 minecraft:bone_block
fill 237 242 464 237 245 464 minecraft:brown_terracotta
setblock 237 242 473 minecraft:bone_block
fill 237 242 474 237 245 474 minecraft:brown_terracotta
setblock 237 242 478 minecraft:bone_block
fill 237 242 479 237 245 479 minecraft:brown_terracotta
setblock 237 242 483 minecraft:bone_block
fill 237 242 484 237 245 484 minecraft:brown_terracotta
setblock 237 242 488 minecraft:bone_block
fill 237 242 489 237 245 489 minecraft:brown_terracotta
setblock 237 242 499 minecraft:brown_terracotta
setblock 237 242 503 minecraft:bone_block
fill 237 242 504 237 245 504 minecraft:brown_terracotta
setblock 238 242 477 minecraft:bone_block
fill 238 242 478 238 245 478 minecraft:brown_terracotta
setblock 238 242 482 minecraft:bone_block
fill 238 242 483 238 245 483 minecraft:brown_terracotta
setblock 238 242 487 minecraft:bone_block
fill 238 242 503 238 245 503 minecraft:brown_terracotta
setblock 239 242 465 minecraft:brown_terracotta
setblock 239 242 477 minecraft:brown_terracotta
setblock 239 242 481 minecraft:bone_block
fill 239 242 482 239 244 482 minecraft:brown_terracotta
setblock 240 242 465 minecraft:bone_block
setblock 241 242 464 minecraft:bone_block
fill 241 242 465 241 245 465 minecraft:brown_terracotta
setblock 241 242 504 minecraft:bone_block
fill 242 242 464 242 245 464 minecraft:brown_terracotta
setblock 242 242 503 minecraft:bone_block
fill 242 242 504 242 245 504 minecraft:brown_terracotta
fill 243 242 503 243 243 503 minecraft:brown_terracotta
setblock 245 242 465 minecraft:bone_block
setblock 246 242 464 minecraft:bone_block
setblock 246 242 465 minecraft:brown_terracotta
setblock 246 242 504 minecraft:bone_block
fill 247 242 464 250 242 464 minecraft:brown_terracotta
fill 247 242 504 250 242 504 minecraft:brown_terracotta
setblock 251 242 464 minecraft:bone_block
setblock 251 242 504 minecraft:bone_block
schedule function dropper:buildpart/113_9 1t
