setblock 293 100 208 minecraft:light[level=14]
setblock 293 100 216 minecraft:light[level=14]
setblock 294 100 183 minecraft:polished_blackstone
fill 294 100 184 294 103 184 minecraft:red_nether_bricks
setblock 295 100 182 minecraft:polished_blackstone
fill 295 100 183 295 103 183 minecraft:red_nether_bricks
setblock 295 100 222 minecraft:polished_blackstone
fill 296 100 182 299 100 182 minecraft:red_nether_bricks
fill 296 100 222 296 101 222 minecraft:red_nether_bricks
setblock 297 100 185 minecraft:polished_blackstone
setblock 298 100 184 minecraft:polished_blackstone
setblock 298 100 185 minecraft:red_nether_bricks
setblock 299 100 183 minecraft:polished_blackstone
fill 299 100 184 299 101 184 minecraft:red_nether_bricks
setblock 300 100 182 minecraft:polished_blackstone
fill 300 100 183 300 102 183 minecraft:red_nether_bricks
fill 301 100 182 301 103 182 minecraft:red_nether_bricks
setblock 301 100 192 minecraft:light[level=14]
setblock 301 100 200 minecraft:light[level=14]
setblock 301 100 208 minecraft:light[level=14]
setblock 301 100 216 minecraft:light[level=14]
setblock 304 100 183 minecraft:polished_blackstone
setblock 305 100 182 minecraft:polished_blackstone
fill 305 100 183 305 102 183 minecraft:red_nether_bricks
fill 306 100 182 306 103 182 minecraft:red_nether_bricks
fill 307 100 222 307 102 222 minecraft:red_nether_bricks
setblock 308 100 183 minecraft:red_nether_bricks
setblock 308 100 184 minecraft:polished_blackstone
setblock 309 100 183 minecraft:polished_blackstone
fill 309 100 184 309 103 184 minecraft:red_nether_bricks
setblock 309 100 192 minecraft:light[level=14]
setblock 309 100 200 minecraft:light[level=14]
setblock 309 100 208 minecraft:light[level=14]
setblock 309 100 216 minecraft:light[level=14]
setblock 310 100 182 minecraft:polished_blackstone
fill 310 100 183 310 103 183 minecraft:red_nether_bricks
setblock 310 100 221 minecraft:red_nether_bricks
setblock 310 100 222 minecraft:polished_blackstone
fill 311 100 182 311 103 182 minecraft:red_nether_bricks
setblock 311 100 221 minecraft:polished_blackstone
fill 311 100 222 311 103 222 minecraft:red_nether_bricks
setblock 312 100 184 minecraft:red_nether_bricks
setblock 312 100 185 minecraft:polished_blackstone
fill 312 100 221 312 103 221 minecraft:red_nether_bricks
setblock 313 100 184 minecraft:polished_blackstone
fill 313 100 185 313 101 185 minecraft:red_nether_bricks
setblock 314 100 183 minecraft:polished_blackstone
fill 314 100 184 314 103 184 minecraft:red_nether_bricks
setblock 315 100 182 minecraft:polished_blackstone
fill 315 100 183 315 103 183 minecraft:red_nether_bricks
setblock 315 100 222 minecraft:polished_blackstone
fill 316 100 182 316 103 182 minecraft:red_nether_bricks
setblock 316 100 221 minecraft:polished_blackstone
fill 316 100 222 316 103 222 minecraft:red_nether_bricks
setblock 317 100 192 minecraft:light[level=14]
setblock 317 100 200 minecraft:light[level=14]
setblock 317 100 208 minecraft:light[level=14]
setblock 317 100 216 minecraft:light[level=14]
fill 317 100 221 317 102 221 minecraft:red_nether_bricks
setblock 318 100 184 minecraft:polished_blackstone
setblock 319 100 183 minecraft:polished_blackstone
setblock 320 100 182 minecraft:polished_blackstone
setblock 320 100 183 minecraft:red_nether_bricks
setblock 320 100 222 minecraft:polished_blackstone
fill 321 100 182 321 101 182 minecraft:red_nether_bricks
setblock 321 100 211 minecraft:polished_blackstone
fill 321 100 212 321 102 212 minecraft:red_nether_bricks
fill 321 100 222 321 101 222 minecraft:red_nether_bricks
setblock 322 100 205 minecraft:polished_blackstone
fill 322 100 206 322 101 206 minecraft:red_nether_bricks
setblock 322 100 210 minecraft:polished_blackstone
fill 322 100 211 322 103 211 minecraft:red_nether_bricks
setblock 322 100 215 minecraft:polished_blackstone
setblock 323 100 184 minecraft:polished_blackstone
setblock 323 100 185 minecraft:red_nether_bricks
setblock 323 100 189 minecraft:polished_blackstone
setblock 323 100 204 minecraft:polished_blackstone
fill 323 100 205 323 103 205 minecraft:red_nether_bricks
setblock 323 100 209 minecraft:polished_blackstone
fill 323 100 210 323 103 210 minecraft:red_nether_bricks
setblock 323 100 214 minecraft:polished_blackstone
fill 323 100 215 323 103 215 minecraft:red_nether_bricks
setblock 323 100 219 minecraft:polished_blackstone
setblock 283 101 187 minecraft:red_nether_bricks
setblock 283 101 188 minecraft:polished_blackstone
fill 283 101 189 283 104 189 minecraft:red_nether_bricks
setblock 283 101 192 minecraft:red_nether_bricks
setblock 283 101 203 minecraft:polished_blackstone
fill 283 101 204 283 103 204 minecraft:red_nether_bricks
setblock 283 101 208 minecraft:polished_blackstone
fill 283 101 209 283 104 209 minecraft:red_nether_bricks
setblock 283 101 212 minecraft:red_nether_bricks
setblock 283 101 213 minecraft:polished_blackstone
fill 283 101 214 283 104 214 minecraft:red_nether_bricks
setblock 284 101 207 minecraft:polished_blackstone
fill 284 101 208 284 104 208 minecraft:red_nether_bricks
setblock 284 101 212 minecraft:polished_blackstone
fill 284 101 213 284 102 213 minecraft:red_nether_bricks
setblock 289 101 182 minecraft:polished_blackstone
fill 290 101 182 290 104 182 minecraft:red_nether_bricks
setblock 292 101 183 minecraft:red_nether_bricks
setblock 292 101 184 minecraft:polished_blackstone
setblock 293 101 183 minecraft:polished_blackstone
fill 293 101 184 293 101 185 minecraft:red_nether_bricks
setblock 294 101 182 minecraft:polished_blackstone
fill 294 101 183 294 104 183 minecraft:red_nether_bricks
fill 294 101 185 295 101 185 minecraft:red_nether_bricks
setblock 294 101 222 minecraft:polished_blackstone
fill 295 101 182 298 101 182 minecraft:red_nether_bricks
setblock 295 101 222 minecraft:red_nether_bricks
setblock 296 101 185 minecraft:polished_blackstone
setblock 297 101 184 minecraft:polished_blackstone
setblock 297 101 185 minecraft:red_nether_bricks
setblock 298 101 183 minecraft:polished_blackstone
setblock 298 101 184 minecraft:red_nether_bricks
setblock 299 101 182 minecraft:polished_blackstone
fill 299 101 183 299 102 183 minecraft:red_nether_bricks
fill 300 101 182 300 103 182 minecraft:red_nether_bricks
setblock 303 101 183 minecraft:polished_blackstone
setblock 304 101 182 minecraft:polished_blackstone
setblock 304 101 183 minecraft:red_nether_bricks
fill 305 101 182 305 104 182 minecraft:red_nether_bricks
setblock 307 101 184 minecraft:polished_blackstone
setblock 308 101 183 minecraft:polished_blackstone
fill 308 101 184 308 102 184 minecraft:red_nether_bricks
setblock 309 101 182 minecraft:polished_blackstone
fill 309 101 183 309 104 183 minecraft:red_nether_bricks
setblock 309 101 222 minecraft:polished_blackstone
fill 310 101 182 310 104 182 minecraft:red_nether_bricks
setblock 310 101 221 minecraft:polished_blackstone
fill 310 101 222 310 104 222 minecraft:red_nether_bricks
setblock 311 101 184 minecraft:red_nether_bricks
setblock 311 101 185 minecraft:polished_blackstone
fill 311 101 221 311 104 221 minecraft:red_nether_bricks
setblock 312 101 184 minecraft:polished_blackstone
setblock 312 101 185 minecraft:red_nether_bricks
setblock 313 101 183 minecraft:polished_blackstone
fill 313 101 184 313 103 184 minecraft:red_nether_bricks
setblock 314 101 182 minecraft:polished_blackstone
fill 314 101 183 314 104 183 minecraft:red_nether_bricks
setblock 314 101 222 minecraft:polished_blackstone
fill 315 101 182 315 104 182 minecraft:red_nether_bricks
setblock 315 101 221 minecraft:polished_blackstone
fill 315 101 222 315 104 222 minecraft:red_nether_bricks
fill 316 101 221 316 103 221 minecraft:red_nether_bricks
setblock 317 101 184 minecraft:polished_blackstone
setblock 318 101 183 minecraft:polished_blackstone
setblock 319 101 182 minecraft:polished_blackstone
setblock 319 101 183 minecraft:red_nether_bricks
setblock 319 101 222 minecraft:polished_blackstone
setblock 320 101 182 minecraft:red_nether_bricks
fill 320 101 222 320 102 222 minecraft:red_nether_bricks
setblock 321 101 209 minecraft:red_nether_bricks
setblock 321 101 210 minecraft:polished_blackstone
fill 321 101 211 321 102 211 minecraft:red_nether_bricks
setblock 322 101 209 minecraft:polished_blackstone
fill 322 101 210 322 104 210 minecraft:red_nether_bricks
setblock 322 101 213 minecraft:red_nether_bricks
setblock 322 101 214 minecraft:polished_blackstone
fill 322 101 215 322 104 215 minecraft:red_nether_bricks
setblock 323 101 187 minecraft:red_nether_bricks
setblock 323 101 188 minecraft:polished_blackstone
setblock 323 101 204 minecraft:red_nether_bricks
setblock 323 101 208 minecraft:polished_blackstone
fill 323 101 209 323 104 209 minecraft:red_nether_bricks
setblock 323 101 213 minecraft:polished_blackstone
fill 323 101 214 323 104 214 minecraft:red_nether_bricks
setblock 323 101 218 minecraft:polished_blackstone
setblock 283 102 187 minecraft:polished_blackstone
fill 283 102 188 283 103 188 minecraft:red_nether_bricks
setblock 283 102 192 minecraft:polished_blackstone
fill 283 102 193 283 105 193 minecraft:red_nether_bricks
setblock 283 102 202 minecraft:polished_blackstone
setblock 283 102 203 minecraft:red_nether_bricks
setblock 283 102 207 minecraft:polished_blackstone
fill 283 102 208 283 105 208 minecraft:red_nether_bricks
setblock 283 102 212 minecraft:polished_blackstone
fill 283 102 213 283 105 213 minecraft:red_nether_bricks
setblock 284 102 206 minecraft:polished_blackstone
fill 284 102 207 284 103 207 minecraft:red_nether_bricks
setblock 284 102 211 minecraft:polished_blackstone
fill 284 102 212 284 104 212 minecraft:red_nether_bricks
fill 289 102 182 289 103 182 minecraft:red_nether_bricks
setblock 291 102 183 minecraft:red_nether_bricks
setblock 292 102 183 minecraft:polished_blackstone
fill 292 102 184 293 102 184 minecraft:red_nether_bricks
setblock 293 102 182 minecraft:polished_blackstone
fill 293 102 183 293 104 183 minecraft:red_nether_bricks
fill 294 102 182 297 102 182 minecraft:red_nether_bricks
setblock 296 102 184 minecraft:polished_blackstone
setblock 297 102 183 minecraft:polished_blackstone
setblock 297 102 184 minecraft:red_nether_bricks
setblock 298 102 182 minecraft:polished_blackstone
fill 298 102 183 298 103 183 minecraft:red_nether_bricks
fill 299 102 182 299 103 182 minecraft:red_nether_bricks
fill 299 102 217 299 102 219 minecraft:polished_blackstone
fill 300 102 217 301 102 217 minecraft:polished_blackstone
fill 300 102 219 301 102 219 minecraft:polished_blackstone
setblock 301 102 218 minecraft:polished_blackstone
setblock 303 102 182 minecraft:polished_blackstone
fill 304 102 182 304 103 182 minecraft:red_nether_bricks
setblock 307 102 183 minecraft:polished_blackstone
setblock 308 102 182 minecraft:polished_blackstone
fill 308 102 183 308 104 183 minecraft:red_nether_bricks
setblock 308 102 222 minecraft:polished_blackstone
fill 309 102 182 309 105 182 minecraft:red_nether_bricks
fill 309 102 222 309 105 222 minecraft:red_nether_bricks
setblock 310 102 184 minecraft:red_nether_bricks
fill 310 102 221 310 105 221 minecraft:red_nether_bricks
setblock 311 102 184 minecraft:polished_blackstone
setblock 312 102 183 minecraft:polished_blackstone
fill 312 102 184 312 103 184 minecraft:red_nether_bricks
fill 312 102 185 312 136 185 minecraft:gilded_blackstone
setblock 313 102 182 minecraft:polished_blackstone
fill 313 102 183 313 104 183 minecraft:red_nether_bricks
setblock 313 102 222 minecraft:polished_blackstone
fill 314 102 182 314 105 182 minecraft:red_nether_bricks
setblock 314 102 221 minecraft:polished_blackstone
fill 314 102 222 314 105 222 minecraft:red_nether_bricks
fill 315 102 221 315 104 221 minecraft:red_nether_bricks
setblock 317 102 183 minecraft:polished_blackstone
setblock 318 102 182 minecraft:polished_blackstone
setblock 318 102 222 minecraft:polished_blackstone
setblock 319 102 182 minecraft:red_nether_bricks
fill 319 102 222 319 103 222 minecraft:red_nether_bricks
setblock 321 102 210 minecraft:red_nether_bricks
setblock 322 102 208 minecraft:polished_blackstone
fill 322 102 209 322 104 209 minecraft:red_nether_bricks
setblock 322 102 213 minecraft:polished_blackstone
fill 322 102 214 322 105 214 minecraft:red_nether_bricks
setblock 323 102 207 minecraft:polished_blackstone
fill 323 102 208 323 105 208 minecraft:red_nether_bricks
setblock 323 102 212 minecraft:polished_blackstone
fill 323 102 213 323 105 213 minecraft:red_nether_bricks
setblock 323 102 217 minecraft:polished_blackstone
setblock 323 102 218 minecraft:red_nether_bricks
setblock 283 103 190 minecraft:red_nether_bricks
setblock 283 103 191 minecraft:polished_blackstone
fill 283 103 192 283 106 192 minecraft:red_nether_bricks
fill 283 103 194 283 104 194 minecraft:red_nether_bricks
setblock 283 103 206 minecraft:polished_blackstone
fill 283 103 207 283 106 207 minecraft:red_nether_bricks
setblock 283 103 211 minecraft:polished_blackstone
fill 283 103 212 283 106 212 minecraft:red_nether_bricks
setblock 284 103 210 minecraft:polished_blackstone
fill 284 103 211 284 105 211 minecraft:red_nether_bricks
setblock 291 103 183 minecraft:polished_blackstone
setblock 292 103 182 minecraft:polished_blackstone
fill 292 103 183 292 104 183 minecraft:red_nether_bricks
fill 293 103 182 296 103 182 minecraft:red_nether_bricks
setblock 293 103 184 minecraft:red_nether_bricks
setblock 295 103 184 minecraft:polished_blackstone
setblock 296 103 183 minecraft:polished_blackstone
setblock 297 103 182 minecraft:polished_blackstone
setblock 297 103 183 minecraft:red_nether_bricks
fill 298 103 182 298 104 182 minecraft:red_nether_bricks
setblock 302 103 182 minecraft:polished_blackstone
setblock 303 103 182 minecraft:red_nether_bricks
setblock 307 103 182 minecraft:polished_blackstone
setblock 307 103 183 minecraft:red_nether_bricks
setblock 307 103 222 minecraft:polished_blackstone
fill 308 103 182 308 106 182 minecraft:red_nether_bricks
fill 308 103 222 308 106 222 minecraft:red_nether_bricks
setblock 310 103 184 minecraft:polished_blackstone
setblock 311 103 183 minecraft:polished_blackstone
setblock 311 103 184 minecraft:red_nether_bricks
setblock 312 103 182 minecraft:polished_blackstone
fill 312 103 183 312 105 183 minecraft:red_nether_bricks
setblock 312 103 222 minecraft:polished_blackstone
fill 313 103 182 313 106 182 minecraft:red_nether_bricks
setblock 313 103 221 minecraft:polished_blackstone
fill 313 103 222 313 106 222 minecraft:red_nether_bricks
fill 314 103 221 314 106 221 minecraft:red_nether_bricks
setblock 316 103 183 minecraft:polished_blackstone
setblock 317 103 182 minecraft:polished_blackstone
setblock 317 103 222 minecraft:polished_blackstone
setblock 318 103 182 minecraft:red_nether_bricks
setblock 318 103 222 minecraft:red_nether_bricks
setblock 322 103 208 minecraft:red_nether_bricks
setblock 322 103 212 minecraft:polished_blackstone
fill 322 103 213 322 106 213 minecraft:red_nether_bricks
setblock 323 103 206 minecraft:polished_blackstone
fill 323 103 207 323 105 207 minecraft:red_nether_bricks
setblock 323 103 211 minecraft:polished_blackstone
fill 323 103 212 323 106 212 minecraft:red_nether_bricks
setblock 323 103 216 minecraft:polished_blackstone
fill 323 103 217 323 106 217 minecraft:red_nether_bricks
setblock 283 104 190 minecraft:polished_blackstone
fill 283 104 191 283 107 191 minecraft:red_nether_bricks
setblock 283 104 195 minecraft:polished_blackstone
setblock 283 104 205 minecraft:polished_blackstone
fill 283 104 206 283 105 206 minecraft:red_nether_bricks
setblock 283 104 210 minecraft:polished_blackstone
fill 283 104 211 283 107 211 minecraft:red_nether_bricks
setblock 283 104 215 minecraft:polished_blackstone
setblock 284 104 209 minecraft:polished_blackstone
setblock 284 104 210 minecraft:red_nether_bricks
setblock 291 104 182 minecraft:polished_blackstone
fill 292 104 182 295 104 182 minecraft:red_nether_bricks
setblock 295 104 183 minecraft:polished_blackstone
setblock 296 104 182 minecraft:polished_blackstone
fill 296 104 194 297 105 194 minecraft:magma_block
setblock 297 104 182 minecraft:red_nether_bricks
setblock 306 104 182 minecraft:polished_blackstone
fill 307 104 182 307 107 182 minecraft:red_nether_bricks
fill 307 104 222 307 107 222 minecraft:red_nether_bricks
setblock 310 104 183 minecraft:polished_blackstone
setblock 311 104 182 minecraft:polished_blackstone
fill 311 104 183 311 105 183 minecraft:red_nether_bricks
fill 311 104 184 313 136 184 minecraft:gilded_blackstone
setblock 311 104 185 minecraft:polished_blackstone
setblock 311 104 222 minecraft:polished_blackstone
fill 312 104 182 312 107 182 minecraft:red_nether_bricks
setblock 312 104 221 minecraft:polished_blackstone
fill 312 104 222 312 107 222 minecraft:red_nether_bricks
setblock 313 104 185 minecraft:polished_blackstone
fill 313 104 221 313 107 221 minecraft:red_nether_bricks
setblock 316 104 182 minecraft:polished_blackstone
setblock 316 104 222 minecraft:polished_blackstone
fill 317 104 222 317 105 222 minecraft:red_nether_bricks
setblock 322 104 211 minecraft:polished_blackstone
fill 322 104 212 322 107 212 minecraft:red_nether_bricks
setblock 323 104 206 minecraft:red_nether_bricks
setblock 323 104 210 minecraft:polished_blackstone
fill 323 104 211 323 107 211 minecraft:red_nether_bricks
setblock 323 104 215 minecraft:polished_blackstone
fill 323 104 216 323 107 216 minecraft:red_nether_bricks
setblock 283 105 189 minecraft:polished_blackstone
fill 283 105 190 283 108 190 minecraft:red_nether_bricks
setblock 283 105 194 minecraft:polished_blackstone
fill 283 105 195 283 108 195 minecraft:red_nether_bricks
setblock 283 105 209 minecraft:polished_blackstone
fill 283 105 210 283 108 210 minecraft:red_nether_bricks
setblock 283 105 214 minecraft:polished_blackstone
fill 283 105 215 283 108 215 minecraft:red_nether_bricks
setblock 290 105 182 minecraft:polished_blackstone
fill 291 105 182 294 105 182 minecraft:red_nether_bricks
setblock 295 105 182 minecraft:polished_blackstone
setblock 296 105 182 minecraft:red_nether_bricks
fill 306 105 182 306 108 182 minecraft:red_nether_bricks
setblock 309 105 183 minecraft:polished_blackstone
fill 309 105 221 309 106 221 minecraft:red_nether_bricks
setblock 310 105 182 minecraft:polished_blackstone
setblock 310 105 183 minecraft:red_nether_bricks
setblock 310 105 222 minecraft:polished_blackstone
fill 311 105 182 311 108 182 minecraft:red_nether_bricks
setblock 311 105 221 minecraft:polished_blackstone
fill 311 105 222 311 108 222 minecraft:red_nether_bricks
fill 312 105 221 312 108 221 minecraft:red_nether_bricks
setblock 315 105 182 minecraft:polished_blackstone
setblock 315 105 222 minecraft:polished_blackstone
fill 316 105 222 316 106 222 minecraft:red_nether_bricks
setblock 322 105 210 minecraft:polished_blackstone
fill 322 105 211 322 106 211 minecraft:red_nether_bricks
setblock 323 105 209 minecraft:polished_blackstone
fill 323 105 210 323 108 210 minecraft:red_nether_bricks
setblock 323 105 214 minecraft:polished_blackstone
fill 323 105 215 323 108 215 minecraft:red_nether_bricks
setblock 283 106 193 minecraft:polished_blackstone
fill 283 106 194 283 109 194 minecraft:red_nether_bricks
fill 283 106 196 283 106 197 minecraft:red_nether_bricks
setblock 283 106 208 minecraft:polished_blackstone
fill 283 106 209 283 109 209 minecraft:red_nether_bricks
setblock 283 106 213 minecraft:polished_blackstone
fill 283 106 214 283 109 214 minecraft:red_nether_bricks
setblock 284 106 192 minecraft:polished_blackstone
fill 284 106 193 284 109 193 minecraft:red_nether_bricks
fill 291 106 182 293 106 182 minecraft:red_nether_bricks
setblock 294 106 182 minecraft:polished_blackstone
setblock 309 106 182 minecraft:polished_blackstone
setblock 309 106 222 minecraft:polished_blackstone
fill 310 106 182 310 109 182 minecraft:red_nether_bricks
setblock 310 106 221 minecraft:polished_blackstone
fill 310 106 222 310 109 222 minecraft:red_nether_bricks
fill 311 106 221 311 109 221 minecraft:red_nether_bricks
fill 312 106 183 312 136 183 minecraft:gilded_blackstone
setblock 314 106 222 minecraft:polished_blackstone
fill 315 106 222 315 109 222 minecraft:red_nether_bricks
setblock 322 106 214 minecraft:polished_blackstone
setblock 323 106 208 minecraft:polished_blackstone
fill 323 106 209 323 109 209 minecraft:red_nether_bricks
setblock 323 106 213 minecraft:polished_blackstone
fill 323 106 214 323 109 214 minecraft:red_nether_bricks
setblock 283 107 192 minecraft:polished_blackstone
fill 283 107 193 283 110 193 minecraft:red_nether_bricks
setblock 283 107 196 minecraft:red_nether_bricks
setblock 283 107 197 minecraft:polished_blackstone
fill 283 107 198 283 110 198 minecraft:red_nether_bricks
setblock 283 107 208 minecraft:red_nether_bricks
setblock 283 107 212 minecraft:polished_blackstone
fill 283 107 213 283 110 213 minecraft:red_nether_bricks
setblock 284 107 191 minecraft:polished_blackstone
fill 284 107 192 284 110 192 minecraft:red_nether_bricks
fill 284 107 194 284 107 195 minecraft:red_nether_bricks
setblock 284 107 196 minecraft:polished_blackstone
fill 291 107 182 292 107 182 minecraft:red_nether_bricks
setblock 293 107 182 minecraft:polished_blackstone
fill 306 107 222 306 108 222 minecraft:red_nether_bricks
setblock 308 107 182 minecraft:polished_blackstone
setblock 308 107 221 minecraft:red_nether_bricks
setblock 308 107 222 minecraft:polished_blackstone
fill 309 107 182 309 110 182 minecraft:red_nether_bricks
setblock 309 107 221 minecraft:polished_blackstone
fill 309 107 222 309 110 222 minecraft:red_nether_bricks
fill 310 107 221 310 110 221 minecraft:red_nether_bricks
setblock 313 107 182 minecraft:polished_blackstone
setblock 313 107 222 minecraft:polished_blackstone
setblock 314 107 221 minecraft:polished_blackstone
fill 314 107 222 314 110 222 minecraft:red_nether_bricks
setblock 322 107 213 minecraft:polished_blackstone
fill 322 107 214 322 109 215 minecraft:red_nether_bricks
fill 323 107 208 323 110 208 minecraft:red_nether_bricks
setblock 323 107 212 minecraft:polished_blackstone
fill 323 107 213 323 110 213 minecraft:red_nether_bricks
setblock 323 107 217 minecraft:polished_blackstone
fill 323 107 218 323 110 218 minecraft:red_nether_bricks
fill 283 108 189 283 109 189 minecraft:red_nether_bricks
setblock 283 108 191 minecraft:polished_blackstone
fill 283 108 192 283 111 192 minecraft:red_nether_bricks
setblock 283 108 196 minecraft:polished_blackstone
fill 283 108 197 284 110 197 minecraft:red_nether_bricks
fill 283 108 199 283 108 200 minecraft:red_nether_bricks
setblock 283 108 211 minecraft:polished_blackstone
fill 283 108 212 283 111 212 minecraft:red_nether_bricks
setblock 283 108 216 minecraft:polished_blackstone
fill 284 108 191 284 111 191 minecraft:red_nether_bricks
setblock 284 108 194 minecraft:red_nether_bricks
setblock 284 108 195 minecraft:polished_blackstone
fill 284 108 196 284 111 196 minecraft:red_nether_bricks
fill 284 108 198 284 109 198 minecraft:red_nether_bricks
setblock 285 108 184 minecraft:light[level=14]
setblock 285 108 192 minecraft:light[level=14]
setblock 285 108 193 minecraft:red_nether_bricks
setblock 285 108 194 minecraft:polished_blackstone
fill 285 108 195 285 111 195 minecraft:red_nether_bricks
setblock 285 108 200 minecraft:light[level=14]
setblock 285 108 208 minecraft:light[level=14]
setblock 285 108 216 minecraft:light[level=14]
fill 290 108 182 291 108 182 minecraft:red_nether_bricks
fill 290 108 205 290 109 205 minecraft:magma_block
setblock 292 108 182 minecraft:polished_blackstone
setblock 293 108 184 minecraft:light[level=14]
setblock 293 108 192 minecraft:light[level=14]
setblock 293 108 200 minecraft:light[level=14]
setblock 293 108 208 minecraft:light[level=14]
setblock 293 108 216 minecraft:light[level=14]
setblock 301 108 184 minecraft:light[level=14]
setblock 301 108 192 minecraft:light[level=14]
setblock 301 108 200 minecraft:light[level=14]
setblock 301 108 208 minecraft:light[level=14]
setblock 301 108 216 minecraft:light[level=14]
fill 305 108 182 305 109 182 minecraft:red_nether_bricks
fill 305 108 222 305 109 222 minecraft:red_nether_bricks
setblock 307 108 182 minecraft:polished_blackstone
setblock 307 108 221 minecraft:red_nether_bricks
setblock 307 108 222 minecraft:polished_blackstone
fill 308 108 182 308 111 182 minecraft:red_nether_bricks
setblock 308 108 221 minecraft:polished_blackstone
fill 308 108 222 308 111 222 minecraft:red_nether_bricks
setblock 309 108 184 minecraft:light[level=14]
setblock 309 108 192 minecraft:light[level=14]
setblock 309 108 200 minecraft:light[level=14]
setblock 309 108 208 minecraft:light[level=14]
setblock 309 108 216 minecraft:light[level=14]
setblock 309 108 220 minecraft:polished_blackstone
fill 309 108 221 309 111 221 minecraft:red_nether_bricks
fill 310 108 220 312 109 220 minecraft:red_nether_bricks
setblock 312 108 182 minecraft:polished_blackstone
setblock 312 108 222 minecraft:polished_blackstone
setblock 313 108 221 minecraft:polished_blackstone
fill 313 108 222 313 111 222 minecraft:red_nether_bricks
fill 314 108 221 314 111 221 minecraft:red_nether_bricks
setblock 317 108 184 minecraft:light[level=14]
setblock 317 108 192 minecraft:light[level=14]
setblock 317 108 200 minecraft:light[level=14]
setblock 317 108 208 minecraft:light[level=14]
setblock 317 108 216 minecraft:light[level=14]
setblock 322 108 212 minecraft:polished_blackstone
fill 322 108 213 322 111 213 minecraft:red_nether_bricks
setblock 323 108 211 minecraft:polished_blackstone
fill 323 108 212 323 111 212 minecraft:red_nether_bricks
setblock 323 108 216 minecraft:polished_blackstone
fill 323 108 217 323 111 217 minecraft:red_nether_bricks
fill 323 108 219 323 109 219 minecraft:red_nether_bricks
setblock 283 109 190 minecraft:polished_blackstone
fill 283 109 191 283 112 191 minecraft:red_nether_bricks
setblock 283 109 195 minecraft:polished_blackstone
fill 283 109 196 283 112 196 minecraft:red_nether_bricks
setblock 283 109 199 minecraft:red_nether_bricks
setblock 283 109 200 minecraft:polished_blackstone
fill 283 109 201 283 111 202 minecraft:red_nether_bricks
setblock 283 109 210 minecraft:polished_blackstone
fill 283 109 211 283 112 211 minecraft:red_nether_bricks
setblock 283 109 215 minecraft:polished_blackstone
fill 283 109 216 283 111 217 minecraft:red_nether_bricks
fill 284 109 190 284 112 190 minecraft:red_nether_bricks
setblock 284 109 194 minecraft:polished_blackstone
fill 284 109 195 284 112 195 minecraft:red_nether_bricks
setblock 284 109 199 minecraft:polished_blackstone
setblock 285 109 192 minecraft:red_nether_bricks
setblock 285 109 193 minecraft:polished_blackstone
fill 285 109 194 285 112 194 minecraft:red_nether_bricks
fill 285 109 196 285 109 197 minecraft:red_nether_bricks
fill 288 109 182 290 109 182 minecraft:red_nether_bricks
setblock 291 109 182 minecraft:polished_blackstone
fill 292 109 182 293 111 182 minecraft:red_nether_bricks
fill 303 109 222 304 110 222 minecraft:red_nether_bricks
fill 304 109 182 304 110 182 minecraft:red_nether_bricks
fill 305 109 221 306 109 221 minecraft:red_nether_bricks
setblock 306 109 182 minecraft:polished_blackstone
setblock 306 109 222 minecraft:polished_blackstone
fill 307 109 182 307 112 182 minecraft:red_nether_bricks
setblock 307 109 220 minecraft:red_nether_bricks
setblock 307 109 221 minecraft:polished_blackstone
fill 307 109 222 307 112 222 minecraft:red_nether_bricks
setblock 308 109 220 minecraft:polished_blackstone
fill 308 109 221 308 112 221 minecraft:red_nether_bricks
fill 309 109 220 309 112 220 minecraft:red_nether_bricks
setblock 311 109 182 minecraft:polished_blackstone
setblock 311 109 222 minecraft:polished_blackstone
fill 312 109 182 312 112 182 minecraft:red_nether_bricks
setblock 312 109 221 minecraft:polished_blackstone
fill 312 109 222 312 112 222 minecraft:red_nether_bricks
fill 313 109 221 313 112 221 minecraft:red_nether_bricks
setblock 316 109 222 minecraft:polished_blackstone
fill 322 109 212 322 112 212 minecraft:red_nether_bricks
setblock 322 109 216 minecraft:polished_blackstone
fill 322 109 217 322 112 217 minecraft:red_nether_bricks
fill 323 109 192 323 109 194 minecraft:red_nether_bricks
setblock 323 109 195 minecraft:polished_blackstone
fill 323 109 196 323 109 199 minecraft:red_nether_bricks
setblock 323 109 210 minecraft:polished_blackstone
fill 323 109 211 323 112 211 minecraft:red_nether_bricks
setblock 323 109 215 minecraft:polished_blackstone
fill 323 109 216 323 112 216 minecraft:red_nether_bricks
setblock 323 109 220 minecraft:polished_blackstone
setblock 283 110 188 minecraft:red_nether_bricks
setblock 283 110 189 minecraft:polished_blackstone
fill 283 110 190 283 113 190 minecraft:red_nether_bricks
setblock 283 110 194 minecraft:polished_blackstone
fill 283 110 195 283 113 195 minecraft:red_nether_bricks
setblock 283 110 199 minecraft:polished_blackstone
fill 283 110 200 284 112 200 minecraft:red_nether_bricks
setblock 283 110 203 minecraft:red_nether_bricks
setblock 283 110 204 minecraft:polished_blackstone
setblock 283 110 208 minecraft:red_nether_bricks
setblock 283 110 209 minecraft:polished_blackstone
fill 283 110 210 283 113 210 minecraft:red_nether_bricks
setblock 283 110 214 minecraft:polished_blackstone
fill 283 110 215 284 112 215 minecraft:red_nether_bricks
setblock 283 110 218 minecraft:red_nether_bricks
setblock 283 110 219 minecraft:polished_blackstone
setblock 284 110 193 minecraft:polished_blackstone
fill 284 110 194 284 113 194 minecraft:red_nether_bricks
setblock 284 110 198 minecraft:polished_blackstone
fill 284 110 199 285 112 199 minecraft:red_nether_bricks
fill 284 110 201 284 111 201 minecraft:red_nether_bricks
setblock 284 110 213 minecraft:polished_blackstone
fill 284 110 214 284 113 214 minecraft:red_nether_bricks
setblock 285 110 191 minecraft:red_nether_bricks
setblock 285 110 192 minecraft:polished_blackstone
fill 285 110 193 286 112 193 minecraft:red_nether_bricks
setblock 285 110 196 minecraft:red_nether_bricks
setblock 285 110 197 minecraft:polished_blackstone
fill 285 110 198 285 113 198 minecraft:red_nether_bricks
fill 286 110 194 286 110 195 minecraft:red_nether_bricks
setblock 286 110 196 minecraft:polished_blackstone
fill 286 110 197 286 113 197 minecraft:red_nether_bricks
fill 287 110 182 289 110 182 minecraft:red_nether_bricks
fill 287 110 222 289 110 222 minecraft:red_nether_bricks
setblock 290 110 182 minecraft:polished_blackstone
setblock 290 110 222 minecraft:polished_blackstone
fill 291 110 182 291 113 182 minecraft:red_nether_bricks
fill 291 110 222 292 112 222 minecraft:red_nether_bricks
setblock 294 110 182 minecraft:red_nether_bricks
fill 299 110 217 299 110 219 minecraft:polished_blackstone
fill 300 110 217 301 110 217 minecraft:polished_blackstone
fill 300 110 219 301 110 219 minecraft:polished_blackstone
setblock 301 110 218 minecraft:polished_blackstone
fill 302 110 222 302 112 222 minecraft:red_nether_bricks
fill 303 110 182 303 111 182 minecraft:red_nether_bricks
fill 304 110 221 305 110 221 minecraft:red_nether_bricks
setblock 305 110 182 minecraft:polished_blackstone
fill 305 110 220 306 110 220 minecraft:red_nether_bricks
setblock 305 110 222 minecraft:polished_blackstone
fill 306 110 182 306 113 182 minecraft:red_nether_bricks
setblock 306 110 221 minecraft:polished_blackstone
fill 306 110 222 306 113 222 minecraft:red_nether_bricks
setblock 307 110 220 minecraft:polished_blackstone
fill 307 110 221 307 113 221 minecraft:red_nether_bricks
setblock 308 110 219 minecraft:polished_blackstone
fill 308 110 220 308 113 220 minecraft:red_nether_bricks
fill 309 110 219 311 111 219 minecraft:red_nether_bricks
setblock 310 110 182 minecraft:polished_blackstone
fill 310 110 220 311 110 220 minecraft:red_nether_bricks
setblock 310 110 222 minecraft:polished_blackstone
fill 311 110 182 311 113 182 minecraft:red_nether_bricks
setblock 311 110 221 minecraft:polished_blackstone
fill 311 110 222 311 113 222 minecraft:red_nether_bricks
setblock 312 110 220 minecraft:polished_blackstone
fill 312 110 221 312 113 221 minecraft:red_nether_bricks
fill 313 110 220 313 113 220 minecraft:red_nether_bricks
setblock 315 110 221 minecraft:red_nether_bricks
setblock 315 110 222 minecraft:polished_blackstone
fill 316 110 222 316 113 222 minecraft:red_nether_bricks
setblock 322 110 214 minecraft:red_nether_bricks
setblock 322 110 215 minecraft:polished_blackstone
fill 322 110 216 322 113 216 minecraft:red_nether_bricks
fill 322 110 218 322 111 218 minecraft:red_nether_bricks
fill 323 110 191 323 110 193 minecraft:red_nether_bricks
setblock 323 110 194 minecraft:polished_blackstone
fill 323 110 195 323 110 198 minecraft:red_nether_bricks
setblock 323 110 199 minecraft:polished_blackstone
fill 323 110 200 323 110 203 minecraft:red_nether_bricks
fill 323 110 206 323 111 207 minecraft:red_nether_bricks
setblock 323 110 209 minecraft:polished_blackstone
fill 323 110 210 323 113 210 minecraft:red_nether_bricks
setblock 323 110 214 minecraft:polished_blackstone
fill 323 110 215 323 113 215 minecraft:red_nether_bricks
setblock 323 110 219 minecraft:polished_blackstone
fill 323 110 220 323 112 221 minecraft:red_nether_bricks
setblock 283 111 188 minecraft:polished_blackstone
fill 283 111 189 284 113 189 minecraft:red_nether_bricks
setblock 283 111 193 minecraft:polished_blackstone
fill 283 111 194 283 114 194 minecraft:red_nether_bricks
setblock 283 111 197 minecraft:red_nether_bricks
setblock 283 111 198 minecraft:polished_blackstone
fill 283 111 199 283 114 199 minecraft:red_nether_bricks
setblock 283 111 203 minecraft:polished_blackstone
fill 283 111 204 283 111 207 minecraft:red_nether_bricks
setblock 283 111 208 minecraft:polished_blackstone
fill 283 111 209 283 114 209 minecraft:red_nether_bricks
setblock 283 111 213 minecraft:polished_blackstone
fill 283 111 214 283 114 214 minecraft:red_nether_bricks
setblock 283 111 218 minecraft:polished_blackstone
fill 283 111 219 283 113 220 minecraft:red_nether_bricks
setblock 284 111 192 minecraft:polished_blackstone
fill 284 111 193 284 114 193 minecraft:red_nether_bricks
setblock 284 111 197 minecraft:polished_blackstone
fill 284 111 198 284 114 198 minecraft:red_nether_bricks
setblock 284 111 202 minecraft:polished_blackstone
fill 284 111 203 284 114 203 minecraft:red_nether_bricks
fill 284 111 213 284 114 213 minecraft:red_nether_bricks
setblock 284 111 216 minecraft:red_nether_bricks
setblock 284 111 217 minecraft:polished_blackstone
fill 284 111 218 284 114 218 minecraft:red_nether_bricks
fill 285 111 182 288 111 182 minecraft:red_nether_bricks
setblock 285 111 190 minecraft:red_nether_bricks
setblock 285 111 191 minecraft:polished_blackstone
fill 285 111 192 286 113 192 minecraft:red_nether_bricks
setblock 285 111 196 minecraft:polished_blackstone
fill 285 111 197 285 114 197 minecraft:red_nether_bricks
setblock 285 111 200 minecraft:red_nether_bricks
setblock 285 111 201 minecraft:polished_blackstone
fill 285 111 222 288 111 222 minecraft:red_nether_bricks
setblock 286 111 194 minecraft:red_nether_bricks
setblock 286 111 195 minecraft:polished_blackstone
fill 286 111 196 286 114 196 minecraft:red_nether_bricks
fill 286 111 198 286 111 199 minecraft:red_nether_bricks
fill 288 111 221 289 111 221 minecraft:red_nether_bricks
setblock 289 111 182 minecraft:polished_blackstone
setblock 289 111 222 minecraft:polished_blackstone
fill 290 111 182 290 114 182 minecraft:red_nether_bricks
setblock 290 111 221 minecraft:polished_blackstone
fill 290 111 222 290 114 222 minecraft:red_nether_bricks
setblock 293 111 222 minecraft:red_nether_bricks
setblock 294 111 182 minecraft:polished_blackstone
setblock 294 111 222 minecraft:polished_blackstone
fill 295 111 182 295 114 182 minecraft:red_nether_bricks
setblock 299 111 222 minecraft:polished_blackstone
fill 300 111 222 301 113 222 minecraft:red_nether_bricks
fill 301 111 182 302 112 182 minecraft:red_nether_bricks
fill 302 111 221 304 111 221 minecraft:red_nether_bricks
setblock 303 111 222 minecraft:red_nether_bricks
setblock 304 111 182 minecraft:polished_blackstone
fill 304 111 220 305 111 220 minecraft:red_nether_bricks
setblock 304 111 222 minecraft:polished_blackstone
fill 305 111 182 305 114 182 minecraft:red_nether_bricks
setblock 305 111 221 minecraft:polished_blackstone
fill 305 111 222 305 114 222 minecraft:red_nether_bricks
fill 306 111 183 307 111 183 minecraft:red_nether_bricks
setblock 306 111 219 minecraft:red_nether_bricks
setblock 306 111 220 minecraft:polished_blackstone
fill 306 111 221 306 114 221 minecraft:red_nether_bricks
setblock 307 111 219 minecraft:polished_blackstone
fill 307 111 220 307 114 220 minecraft:red_nether_bricks
setblock 308 111 183 minecraft:polished_blackstone
fill 308 111 219 308 114 219 minecraft:red_nether_bricks
setblock 309 111 182 minecraft:polished_blackstone
setblock 309 111 222 minecraft:polished_blackstone
fill 310 111 182 310 114 182 minecraft:red_nether_bricks
setblock 310 111 220 minecraft:red_nether_bricks
setblock 310 111 221 minecraft:polished_blackstone
fill 310 111 222 310 114 222 minecraft:red_nether_bricks
setblock 311 111 183 minecraft:polished_blackstone
setblock 311 111 185 minecraft:polished_blackstone
setblock 311 111 220 minecraft:polished_blackstone
fill 311 111 221 311 114 221 minecraft:red_nether_bricks
setblock 312 111 219 minecraft:polished_blackstone
fill 312 111 220 312 114 220 minecraft:red_nether_bricks
setblock 313 111 183 minecraft:polished_blackstone
setblock 313 111 185 minecraft:polished_blackstone
fill 314 111 220 314 112 220 minecraft:red_nether_bricks
setblock 314 111 222 minecraft:polished_blackstone
setblock 315 111 221 minecraft:polished_blackstone
fill 315 111 222 315 114 222 minecraft:red_nether_bricks
fill 317 111 222 317 112 222 minecraft:red_nether_bricks
fill 322 111 195 322 111 198 minecraft:red_nether_bricks
fill 322 111 211 322 113 211 minecraft:red_nether_bricks
setblock 322 111 214 minecraft:polished_blackstone
fill 322 111 215 322 114 215 minecraft:red_nether_bricks
setblock 322 111 219 minecraft:polished_blackstone
fill 323 111 191 323 111 192 minecraft:red_nether_bricks
setblock 323 111 193 minecraft:polished_blackstone
fill 323 111 194 323 111 197 minecraft:red_nether_bricks
setblock 323 111 198 minecraft:polished_blackstone
fill 323 111 199 323 111 202 minecraft:red_nether_bricks
setblock 323 111 203 minecraft:polished_blackstone
fill 323 111 204 323 113 205 minecraft:red_nether_bricks
setblock 323 111 208 minecraft:polished_blackstone
fill 323 111 209 323 114 209 minecraft:red_nether_bricks
setblock 323 111 213 minecraft:polished_blackstone
fill 323 111 214 323 114 214 minecraft:red_nether_bricks
setblock 323 111 218 minecraft:polished_blackstone
fill 323 111 219 323 114 219 minecraft:red_nether_bricks
setblock 323 111 222 minecraft:red_nether_bricks
setblock 283 112 186 minecraft:red_nether_bricks
setblock 283 112 187 minecraft:polished_blackstone
fill 283 112 188 284 114 188 minecraft:red_nether_bricks
setblock 283 112 192 minecraft:polished_blackstone
fill 283 112 193 283 115 193 minecraft:red_nether_bricks
setblock 283 112 197 minecraft:polished_blackstone
fill 283 112 198 283 115 198 minecraft:red_nether_bricks
setblock 283 112 201 minecraft:red_nether_bricks
setblock 283 112 202 minecraft:polished_blackstone
fill 283 112 203 283 112 206 minecraft:red_nether_bricks
setblock 283 112 207 minecraft:polished_blackstone
fill 283 112 208 283 115 208 minecraft:red_nether_bricks
setblock 283 112 212 minecraft:polished_blackstone
fill 283 112 213 283 115 213 minecraft:red_nether_bricks
setblock 283 112 216 minecraft:red_nether_bricks
setblock 283 112 217 minecraft:polished_blackstone
fill 283 112 218 283 115 218 minecraft:red_nether_bricks
setblock 283 112 221 minecraft:red_nether_bricks
setblock 283 112 222 minecraft:polished_blackstone
fill 284 112 182 287 112 182 minecraft:red_nether_bricks
setblock 284 112 191 minecraft:polished_blackstone
fill 284 112 192 284 115 192 minecraft:red_nether_bricks
setblock 284 112 196 minecraft:polished_blackstone
fill 284 112 197 284 115 197 minecraft:red_nether_bricks
setblock 284 112 201 minecraft:polished_blackstone
fill 284 112 202 285 114 202 minecraft:red_nether_bricks
fill 284 112 204 284 113 204 minecraft:red_nether_bricks
fill 284 112 212 284 113 212 minecraft:red_nether_bricks
setblock 284 112 216 minecraft:polished_blackstone
fill 284 112 217 284 115 217 minecraft:red_nether_bricks
fill 284 112 219 284 112 220 minecraft:red_nether_bricks
fill 284 112 222 287 112 222 minecraft:red_nether_bricks
setblock 285 112 190 minecraft:polished_blackstone
fill 285 112 191 286 114 191 minecraft:red_nether_bricks
setblock 285 112 195 minecraft:polished_blackstone
fill 285 112 196 285 115 196 minecraft:red_nether_bricks
setblock 285 112 200 minecraft:polished_blackstone
fill 285 112 201 285 115 201 minecraft:red_nether_bricks
fill 285 112 221 288 112 221 minecraft:red_nether_bricks
setblock 286 112 194 minecraft:polished_blackstone
fill 286 112 195 287 114 195 minecraft:red_nether_bricks
setblock 286 112 198 minecraft:red_nether_bricks
setblock 286 112 199 minecraft:polished_blackstone
fill 286 112 200 286 115 200 minecraft:red_nether_bricks
setblock 287 112 183 minecraft:polished_blackstone
fill 287 112 194 287 113 194 minecraft:red_nether_bricks
fill 287 112 196 287 112 197 minecraft:red_nether_bricks
setblock 288 112 182 minecraft:polished_blackstone
fill 288 112 183 291 112 183 minecraft:red_nether_bricks
setblock 288 112 222 minecraft:polished_blackstone
fill 289 112 182 289 115 182 minecraft:red_nether_bricks
setblock 289 112 221 minecraft:polished_blackstone
fill 289 112 222 289 115 222 minecraft:red_nether_bricks
fill 290 112 221 292 113 221 minecraft:red_nether_bricks
setblock 292 112 182 minecraft:red_nether_bricks
setblock 293 112 182 minecraft:polished_blackstone
setblock 293 112 222 minecraft:polished_blackstone
fill 294 112 182 294 115 182 minecraft:red_nether_bricks
fill 294 112 222 297 112 222 minecraft:red_nether_bricks
fill 296 112 182 297 112 182 minecraft:red_nether_bricks
setblock 298 112 182 minecraft:polished_blackstone
setblock 298 112 222 minecraft:polished_blackstone
fill 299 112 182 300 114 182 minecraft:red_nether_bricks
fill 299 112 222 299 115 222 minecraft:red_nether_bricks
fill 300 112 221 303 112 221 minecraft:red_nether_bricks
fill 302 112 220 304 112 220 minecraft:red_nether_bricks
setblock 303 112 182 minecraft:polished_blackstone
setblock 303 112 222 minecraft:polished_blackstone
fill 304 112 182 304 114 183 minecraft:red_nether_bricks
fill 304 112 219 305 112 219 minecraft:red_nether_bricks
setblock 304 112 221 minecraft:polished_blackstone
fill 304 112 222 304 115 222 minecraft:red_nether_bricks
fill 305 112 183 306 112 183 minecraft:red_nether_bricks
setblock 305 112 220 minecraft:polished_blackstone
fill 305 112 221 305 115 221 minecraft:red_nether_bricks
setblock 306 112 219 minecraft:polished_blackstone
fill 306 112 220 306 115 220 minecraft:red_nether_bricks
setblock 307 112 183 minecraft:polished_blackstone
fill 307 112 219 307 115 219 minecraft:red_nether_bricks
setblock 308 112 182 minecraft:polished_blackstone
fill 308 112 183 309 114 183 minecraft:red_nether_bricks
fill 308 112 218 309 114 218 minecraft:red_nether_bricks
setblock 308 112 222 minecraft:polished_blackstone
fill 309 112 182 309 115 182 minecraft:red_nether_bricks
fill 309 112 219 310 112 219 minecraft:red_nether_bricks
setblock 309 112 221 minecraft:polished_blackstone
fill 309 112 222 309 115 222 minecraft:red_nether_bricks
setblock 310 112 220 minecraft:polished_blackstone
fill 310 112 221 310 115 221 minecraft:red_nether_bricks
setblock 311 112 219 minecraft:polished_blackstone
fill 311 112 220 311 115 220 minecraft:red_nether_bricks
fill 312 112 219 312 114 219 minecraft:red_nether_bricks
setblock 313 112 222 minecraft:polished_blackstone
setblock 314 112 221 minecraft:polished_blackstone
fill 314 112 222 314 115 222 minecraft:red_nether_bricks
fill 315 112 221 316 114 221 minecraft:red_nether_bricks
setblock 318 112 222 minecraft:polished_blackstone
fill 319 112 222 322 112 222 minecraft:red_nether_bricks
fill 322 112 194 322 112 197 minecraft:red_nether_bricks
setblock 322 112 198 minecraft:polished_blackstone
fill 322 112 199 322 112 202 minecraft:red_nether_bricks
fill 322 112 210 322 114 210 minecraft:red_nether_bricks
setblock 322 112 213 minecraft:polished_blackstone
fill 322 112 214 322 115 214 minecraft:red_nether_bricks
setblock 322 112 218 minecraft:polished_blackstone
fill 322 112 219 322 114 220 minecraft:red_nether_bricks
fill 323 112 190 323 112 191 minecraft:red_nether_bricks
setblock 323 112 192 minecraft:polished_blackstone
fill 323 112 193 323 112 196 minecraft:red_nether_bricks
setblock 323 112 197 minecraft:polished_blackstone
fill 323 112 198 323 112 201 minecraft:red_nether_bricks
setblock 323 112 202 minecraft:polished_blackstone
fill 323 112 203 323 115 203 minecraft:red_nether_bricks
setblock 323 112 206 minecraft:red_nether_bricks
setblock 323 112 207 minecraft:polished_blackstone
fill 323 112 208 323 115 208 minecraft:red_nether_bricks
setblock 323 112 212 minecraft:polished_blackstone
fill 323 112 213 323 115 213 minecraft:red_nether_bricks
setblock 323 112 217 minecraft:polished_blackstone
fill 323 112 218 323 115 218 minecraft:red_nether_bricks
setblock 323 112 222 minecraft:polished_blackstone
fill 283 113 182 283 113 185 minecraft:red_nether_bricks
setblock 283 113 186 minecraft:polished_blackstone
fill 283 113 187 284 115 187 minecraft:red_nether_bricks
setblock 283 113 191 minecraft:polished_blackstone
fill 283 113 192 283 116 192 minecraft:red_nether_bricks
setblock 283 113 196 minecraft:polished_blackstone
fill 283 113 197 283 116 197 minecraft:red_nether_bricks
setblock 283 113 200 minecraft:red_nether_bricks
setblock 283 113 201 minecraft:polished_blackstone
fill 283 113 202 283 113 205 minecraft:red_nether_bricks
setblock 283 113 206 minecraft:polished_blackstone
fill 283 113 207 283 116 207 minecraft:red_nether_bricks
setblock 283 113 211 minecraft:polished_blackstone
fill 283 113 212 283 116 212 minecraft:red_nether_bricks
setblock 283 113 215 minecraft:red_nether_bricks
setblock 283 113 216 minecraft:polished_blackstone
fill 283 113 217 283 116 217 minecraft:red_nether_bricks
setblock 283 113 221 minecraft:polished_blackstone
fill 283 113 222 286 113 222 minecraft:red_nether_bricks
fill 284 113 182 286 113 182 minecraft:red_nether_bricks
setblock 284 113 190 minecraft:polished_blackstone
fill 284 113 191 284 116 191 minecraft:red_nether_bricks
setblock 284 113 195 minecraft:polished_blackstone
fill 284 113 196 284 116 196 minecraft:red_nether_bricks
setblock 284 113 199 minecraft:red_nether_bricks
setblock 284 113 200 minecraft:polished_blackstone
fill 284 113 201 284 116 201 minecraft:red_nether_bricks
setblock 284 113 205 minecraft:polished_blackstone
fill 284 113 206 284 116 206 minecraft:red_nether_bricks
setblock 284 113 215 minecraft:polished_blackstone
fill 284 113 216 284 116 216 minecraft:red_nether_bricks
setblock 284 113 219 minecraft:red_nether_bricks
setblock 284 113 220 minecraft:polished_blackstone
fill 284 113 221 287 113 221 minecraft:red_nether_bricks
setblock 285 113 183 minecraft:red_nether_bricks
setblock 285 113 189 minecraft:polished_blackstone
fill 285 113 190 285 116 190 minecraft:red_nether_bricks
setblock 285 113 193 minecraft:red_nether_bricks
setblock 285 113 194 minecraft:polished_blackstone
fill 285 113 195 285 116 195 minecraft:red_nether_bricks
setblock 285 113 199 minecraft:polished_blackstone
fill 285 113 200 285 116 200 minecraft:red_nether_bricks
setblock 285 113 203 minecraft:red_nether_bricks
setblock 286 113 183 minecraft:polished_blackstone
setblock 286 113 193 minecraft:polished_blackstone
fill 286 113 194 286 116 194 minecraft:red_nether_bricks
setblock 286 113 198 minecraft:polished_blackstone
fill 286 113 199 286 116 199 minecraft:red_nether_bricks
fill 286 113 201 286 114 201 minecraft:red_nether_bricks
setblock 287 113 182 minecraft:polished_blackstone
fill 287 113 183 290 113 183 minecraft:red_nether_bricks
setblock 287 113 196 minecraft:red_nether_bricks
setblock 287 113 197 minecraft:polished_blackstone
fill 287 113 198 287 115 198 minecraft:red_nether_bricks
fill 287 113 220 288 113 220 minecraft:red_nether_bricks
setblock 287 113 222 minecraft:polished_blackstone
fill 288 113 182 288 116 182 minecraft:red_nether_bricks
setblock 288 113 221 minecraft:polished_blackstone
fill 288 113 222 288 116 222 minecraft:red_nether_bricks
fill 289 113 221 289 116 221 minecraft:red_nether_bricks
setblock 291 113 183 minecraft:polished_blackstone
setblock 291 113 222 minecraft:red_nether_bricks
setblock 292 113 182 minecraft:polished_blackstone
fill 292 113 183 292 116 183 minecraft:red_nether_bricks
setblock 292 113 222 minecraft:polished_blackstone
fill 293 113 182 293 116 182 minecraft:red_nether_bricks
setblock 293 113 221 minecraft:polished_blackstone
fill 293 113 222 296 113 222 minecraft:red_nether_bricks
setblock 296 113 182 minecraft:red_nether_bricks
setblock 297 113 182 minecraft:polished_blackstone
setblock 297 113 222 minecraft:polished_blackstone
fill 298 113 182 298 116 182 minecraft:red_nether_bricks
setblock 298 113 221 minecraft:polished_blackstone
fill 298 113 222 298 116 222 minecraft:red_nether_bricks
fill 299 113 221 302 113 221 minecraft:red_nether_bricks
setblock 301 113 182 minecraft:red_nether_bricks
fill 301 113 220 303 113 220 minecraft:red_nether_bricks
setblock 302 113 182 minecraft:polished_blackstone
fill 302 113 183 303 115 183 minecraft:red_nether_bricks
setblock 302 113 222 minecraft:polished_blackstone
fill 303 113 182 303 116 182 minecraft:red_nether_bricks
fill 303 113 219 304 113 219 minecraft:red_nether_bricks
setblock 303 113 221 minecraft:polished_blackstone
fill 303 113 222 303 116 222 minecraft:red_nether_bricks
setblock 304 113 220 minecraft:polished_blackstone
fill 304 113 221 304 116 221 minecraft:red_nether_bricks
setblock 305 113 183 minecraft:red_nether_bricks
setblock 305 113 219 minecraft:polished_blackstone
fill 305 113 220 305 116 220 minecraft:red_nether_bricks
setblock 306 113 183 minecraft:polished_blackstone
setblock 306 113 218 minecraft:polished_blackstone
fill 306 113 219 306 116 219 minecraft:red_nether_bricks
setblock 307 113 182 minecraft:polished_blackstone
fill 307 113 183 307 116 183 minecraft:red_nether_bricks
fill 307 113 218 307 115 218 minecraft:red_nether_bricks
setblock 307 113 222 minecraft:polished_blackstone
fill 308 113 182 308 116 182 minecraft:red_nether_bricks
setblock 308 113 221 minecraft:polished_blackstone
fill 308 113 222 308 116 222 minecraft:red_nether_bricks
setblock 309 113 219 minecraft:red_nether_bricks
setblock 309 113 220 minecraft:polished_blackstone
fill 309 113 221 309 116 221 minecraft:red_nether_bricks
setblock 310 113 219 minecraft:polished_blackstone
fill 310 113 220 310 116 220 minecraft:red_nether_bricks
fill 311 113 219 311 115 219 minecraft:red_nether_bricks
setblock 312 113 182 minecraft:polished_blackstone
setblock 312 113 186 minecraft:shroomlight
setblock 312 113 222 minecraft:polished_blackstone
setblock 313 113 221 minecraft:polished_blackstone
fill 313 113 222 313 116 222 minecraft:red_nether_bricks
setblock 314 113 220 minecraft:polished_blackstone
fill 314 113 221 314 116 221 minecraft:red_nether_bricks
setblock 317 113 221 minecraft:red_nether_bricks
setblock 317 113 222 minecraft:polished_blackstone
fill 318 113 222 321 113 222 minecraft:red_nether_bricks
fill 320 113 221 322 113 221 minecraft:red_nether_bricks
fill 321 113 216 321 113 217 minecraft:red_nether_bricks
fill 322 113 193 322 113 196 minecraft:red_nether_bricks
setblock 322 113 197 minecraft:polished_blackstone
fill 322 113 198 322 113 201 minecraft:red_nether_bricks
setblock 322 113 202 minecraft:polished_blackstone
fill 322 113 203 322 114 205 minecraft:red_nether_bricks
fill 322 113 209 322 115 209 minecraft:red_nether_bricks
setblock 322 113 212 minecraft:polished_blackstone
fill 322 113 213 322 116 213 minecraft:red_nether_bricks
setblock 322 113 217 minecraft:polished_blackstone
fill 322 113 218 322 116 218 minecraft:red_nether_bricks
setblock 322 113 222 minecraft:polished_blackstone
fill 323 113 189 323 113 190 minecraft:red_nether_bricks
setblock 323 113 191 minecraft:polished_blackstone
fill 323 113 192 323 113 195 minecraft:red_nether_bricks
setblock 323 113 196 minecraft:polished_blackstone
fill 323 113 197 323 113 200 minecraft:red_nether_bricks
setblock 323 113 201 minecraft:polished_blackstone
fill 323 113 202 323 116 202 minecraft:red_nether_bricks
setblock 323 113 206 minecraft:polished_blackstone
fill 323 113 207 323 116 207 minecraft:red_nether_bricks
setblock 323 113 211 minecraft:polished_blackstone
fill 323 113 212 323 116 212 minecraft:red_nether_bricks
setblock 323 113 216 minecraft:polished_blackstone
fill 323 113 217 323 116 217 minecraft:red_nether_bricks
setblock 323 113 220 minecraft:red_nether_bricks
setblock 323 113 221 minecraft:polished_blackstone
fill 323 113 222 323 116 222 minecraft:red_nether_bricks
fill 283 114 182 283 114 184 minecraft:red_nether_bricks
setblock 283 114 185 minecraft:polished_blackstone
fill 283 114 186 284 116 186 minecraft:red_nether_bricks
setblock 283 114 189 minecraft:red_nether_bricks
setblock 283 114 190 minecraft:polished_blackstone
fill 283 114 191 283 117 191 minecraft:red_nether_bricks
setblock 283 114 195 minecraft:polished_blackstone
fill 283 114 196 283 117 196 minecraft:red_nether_bricks
setblock 283 114 200 minecraft:polished_blackstone
fill 283 114 201 283 114 204 minecraft:red_nether_bricks
setblock 283 114 205 minecraft:polished_blackstone
fill 283 114 206 283 117 206 minecraft:red_nether_bricks
setblock 283 114 210 minecraft:polished_blackstone
fill 283 114 211 283 117 211 minecraft:red_nether_bricks
setblock 283 114 215 minecraft:polished_blackstone
fill 283 114 216 283 117 216 minecraft:red_nether_bricks
setblock 283 114 219 minecraft:red_nether_bricks
setblock 283 114 220 minecraft:polished_blackstone
fill 283 114 221 285 114 222 minecraft:red_nether_bricks
fill 284 114 182 284 114 183 minecraft:red_nether_bricks
setblock 284 114 184 minecraft:polished_blackstone
fill 284 114 185 284 117 185 minecraft:red_nether_bricks
setblock 284 114 189 minecraft:polished_blackstone
fill 284 114 190 284 117 190 minecraft:red_nether_bricks
setblock 284 114 194 minecraft:polished_blackstone
fill 284 114 195 284 117 195 minecraft:red_nether_bricks
setblock 284 114 199 minecraft:polished_blackstone
fill 284 114 200 284 117 200 minecraft:red_nether_bricks
setblock 284 114 204 minecraft:polished_blackstone
fill 284 114 205 284 117 205 minecraft:red_nether_bricks
fill 284 114 207 284 115 207 minecraft:red_nether_bricks
setblock 284 114 214 minecraft:polished_blackstone
fill 284 114 215 284 116 215 minecraft:red_nether_bricks
setblock 284 114 219 minecraft:polished_blackstone
fill 284 114 220 287 114 220 minecraft:red_nether_bricks
setblock 285 114 182 minecraft:red_nether_bricks
setblock 285 114 183 minecraft:polished_blackstone
fill 285 114 189 285 116 189 minecraft:red_nether_bricks
setblock 285 114 192 minecraft:red_nether_bricks
setblock 285 114 193 minecraft:polished_blackstone
fill 285 114 194 285 117 194 minecraft:red_nether_bricks
setblock 285 114 198 minecraft:polished_blackstone
fill 285 114 199 285 117 199 minecraft:red_nether_bricks
setblock 285 114 203 minecraft:polished_blackstone
fill 285 114 204 285 117 204 minecraft:red_nether_bricks
setblock 285 114 217 minecraft:red_nether_bricks
setblock 285 114 218 minecraft:polished_blackstone
fill 285 114 219 285 116 219 minecraft:red_nether_bricks
setblock 286 114 182 minecraft:polished_blackstone
fill 286 114 183 289 114 183 minecraft:red_nether_bricks
setblock 286 114 192 minecraft:polished_blackstone
fill 286 114 193 286 116 193 minecraft:red_nether_bricks
setblock 286 114 197 minecraft:polished_blackstone
fill 286 114 198 286 117 198 minecraft:red_nether_bricks
setblock 286 114 221 minecraft:red_nether_bricks
setblock 286 114 222 minecraft:polished_blackstone
fill 287 114 182 287 117 182 minecraft:red_nether_bricks
setblock 287 114 196 minecraft:polished_blackstone
fill 287 114 197 287 115 197 minecraft:red_nether_bricks
setblock 287 114 221 minecraft:polished_blackstone
fill 287 114 222 287 117 222 minecraft:red_nether_bricks
setblock 288 114 220 minecraft:polished_blackstone
fill 288 114 221 288 117 221 minecraft:red_nether_bricks
fill 289 114 220 289 115 220 minecraft:red_nether_bricks
setblock 290 114 183 minecraft:polished_blackstone
fill 290 114 221 291 114 221 minecraft:red_nether_bricks
setblock 291 114 182 minecraft:polished_blackstone
fill 291 114 183 291 117 183 minecraft:red_nether_bricks
setblock 291 114 222 minecraft:polished_blackstone
fill 292 114 182 292 117 182 minecraft:red_nether_bricks
setblock 292 114 221 minecraft:polished_blackstone
fill 292 114 222 295 114 222 minecraft:red_nether_bricks
fill 293 114 221 296 114 221 minecraft:red_nether_bricks
setblock 296 114 182 minecraft:polished_blackstone
setblock 296 114 222 minecraft:polished_blackstone
fill 297 114 182 297 117 182 minecraft:red_nether_bricks
setblock 297 114 221 minecraft:polished_blackstone
fill 297 114 222 297 117 222 minecraft:red_nether_bricks
fill 298 114 221 301 114 221 minecraft:red_nether_bricks
setblock 300 114 183 minecraft:polished_blackstone
fill 300 114 220 302 114 220 minecraft:red_nether_bricks
setblock 300 114 222 minecraft:red_nether_bricks
setblock 301 114 182 minecraft:polished_blackstone
fill 301 114 183 301 117 183 minecraft:red_nether_bricks
setblock 301 114 222 minecraft:polished_blackstone
fill 302 114 182 302 117 182 minecraft:red_nether_bricks
fill 302 114 219 303 114 219 minecraft:red_nether_bricks
setblock 302 114 221 minecraft:polished_blackstone
fill 302 114 222 302 117 222 minecraft:red_nether_bricks
setblock 303 114 220 minecraft:polished_blackstone
fill 303 114 221 303 117 221 minecraft:red_nether_bricks
setblock 304 114 219 minecraft:polished_blackstone
fill 304 114 220 304 117 220 minecraft:red_nether_bricks
setblock 305 114 183 minecraft:polished_blackstone
setblock 305 114 218 minecraft:polished_blackstone
fill 305 114 219 305 117 219 minecraft:red_nether_bricks
setblock 306 114 182 minecraft:polished_blackstone
fill 306 114 183 306 117 183 minecraft:red_nether_bricks
fill 306 114 218 306 116 218 minecraft:red_nether_bricks
setblock 306 114 222 minecraft:polished_blackstone
fill 307 114 182 307 117 182 minecraft:red_nether_bricks
setblock 307 114 221 minecraft:polished_blackstone
fill 307 114 222 307 117 222 minecraft:red_nether_bricks
setblock 308 114 220 minecraft:polished_blackstone
fill 308 114 221 308 117 221 minecraft:red_nether_bricks
setblock 309 114 219 minecraft:polished_blackstone
fill 309 114 220 309 117 220 minecraft:red_nether_bricks
fill 310 114 219 310 116 219 minecraft:red_nether_bricks
setblock 311 114 182 minecraft:polished_blackstone
setblock 311 114 222 minecraft:polished_blackstone
fill 312 114 182 312 116 182 minecraft:red_nether_bricks
setblock 312 114 221 minecraft:polished_blackstone
fill 312 114 222 312 117 222 minecraft:red_nether_bricks
setblock 313 114 220 minecraft:polished_blackstone
fill 313 114 221 313 117 221 minecraft:red_nether_bricks
fill 314 114 220 314 115 220 minecraft:red_nether_bricks
setblock 316 114 222 minecraft:polished_blackstone
setblock 317 114 221 minecraft:polished_blackstone
fill 317 114 222 320 114 222 minecraft:red_nether_bricks
fill 318 114 221 321 114 221 minecraft:red_nether_bricks
setblock 321 114 196 minecraft:red_nether_bricks
setblock 321 114 197 minecraft:polished_blackstone
fill 321 114 198 321 114 201 minecraft:red_nether_bricks
setblock 321 114 216 minecraft:red_nether_bricks
setblock 321 114 217 minecraft:polished_blackstone
fill 321 114 218 321 115 218 minecraft:red_nether_bricks
setblock 321 114 222 minecraft:polished_blackstone
fill 322 114 193 322 114 195 minecraft:red_nether_bricks
setblock 322 114 196 minecraft:polished_blackstone
fill 322 114 197 322 114 200 minecraft:red_nether_bricks
setblock 322 114 201 minecraft:polished_blackstone
fill 322 114 202 322 117 202 minecraft:red_nether_bricks
setblock 322 114 206 minecraft:polished_blackstone
fill 322 114 207 322 116 208 minecraft:red_nether_bricks
setblock 322 114 211 minecraft:polished_blackstone
fill 322 114 212 322 117 212 minecraft:red_nether_bricks
setblock 322 114 216 minecraft:polished_blackstone
fill 322 114 217 322 117 217 minecraft:red_nether_bricks
setblock 322 114 221 minecraft:polished_blackstone
fill 322 114 222 322 117 222 minecraft:red_nether_bricks
fill 323 114 182 323 116 182 minecraft:red_nether_bricks
setblock 323 114 189 minecraft:red_nether_bricks
setblock 323 114 190 minecraft:polished_blackstone
fill 323 114 191 323 114 194 minecraft:red_nether_bricks
setblock 323 114 195 minecraft:polished_blackstone
fill 323 114 196 323 114 199 minecraft:red_nether_bricks
setblock 323 114 200 minecraft:polished_blackstone
fill 323 114 201 323 117 201 minecraft:red_nether_bricks
setblock 323 114 204 minecraft:red_nether_bricks
setblock 323 114 205 minecraft:polished_blackstone
fill 323 114 206 323 117 206 minecraft:red_nether_bricks
setblock 323 114 210 minecraft:polished_blackstone
fill 323 114 211 323 117 211 minecraft:red_nether_bricks
setblock 323 114 215 minecraft:polished_blackstone
fill 323 114 216 323 117 216 minecraft:red_nether_bricks
setblock 323 114 220 minecraft:polished_blackstone
fill 323 114 221 323 117 221 minecraft:red_nether_bricks
fill 283 115 182 283 115 183 minecraft:red_nether_bricks
setblock 283 115 184 minecraft:polished_blackstone
fill 283 115 185 283 118 185 minecraft:red_nether_bricks
setblock 283 115 188 minecraft:red_nether_bricks
setblock 283 115 189 minecraft:polished_blackstone
fill 283 115 190 283 118 190 minecraft:red_nether_bricks
setblock 283 115 194 minecraft:polished_blackstone
fill 283 115 195 283 118 195 minecraft:red_nether_bricks
setblock 283 115 199 minecraft:polished_blackstone
fill 283 115 200 283 115 203 minecraft:red_nether_bricks
setblock 283 115 204 minecraft:polished_blackstone
fill 283 115 205 283 118 205 minecraft:red_nether_bricks
setblock 283 115 209 minecraft:polished_blackstone
fill 283 115 210 283 118 210 minecraft:red_nether_bricks
setblock 283 115 214 minecraft:polished_blackstone
fill 283 115 215 283 118 215 minecraft:red_nether_bricks
setblock 283 115 219 minecraft:polished_blackstone
fill 283 115 220 284 115 222 minecraft:red_nether_bricks
setblock 284 115 182 minecraft:red_nether_bricks
setblock 284 115 183 minecraft:polished_blackstone
fill 284 115 184 284 118 184 minecraft:red_nether_bricks
setblock 284 115 188 minecraft:polished_blackstone
fill 284 115 189 284 118 189 minecraft:red_nether_bricks
setblock 284 115 193 minecraft:polished_blackstone
fill 284 115 194 284 118 194 minecraft:red_nether_bricks
setblock 284 115 198 minecraft:polished_blackstone
fill 284 115 199 284 118 199 minecraft:red_nether_bricks
setblock 284 115 202 minecraft:red_nether_bricks
setblock 284 115 203 minecraft:polished_blackstone
fill 284 115 204 284 118 204 minecraft:red_nether_bricks
setblock 284 115 214 minecraft:red_nether_bricks
setblock 284 115 218 minecraft:polished_blackstone
fill 284 115 219 284 118 219 minecraft:red_nether_bricks
setblock 285 115 182 minecraft:polished_blackstone
fill 285 115 183 288 115 183 minecraft:red_nether_bricks
setblock 285 115 191 minecraft:red_nether_bricks
setblock 285 115 192 minecraft:polished_blackstone
fill 285 115 193 285 118 193 minecraft:red_nether_bricks
setblock 285 115 197 minecraft:polished_blackstone
fill 285 115 198 285 118 198 minecraft:red_nether_bricks
setblock 285 115 202 minecraft:polished_blackstone
fill 285 115 203 285 118 203 minecraft:red_nether_bricks
setblock 285 115 218 minecraft:red_nether_bricks
fill 285 115 220 285 115 221 minecraft:red_nether_bricks
setblock 285 115 222 minecraft:polished_blackstone
fill 286 115 182 286 118 182 minecraft:red_nether_bricks
setblock 286 115 192 minecraft:red_nether_bricks
setblock 286 115 195 minecraft:red_nether_bricks
setblock 286 115 196 minecraft:polished_blackstone
fill 286 115 197 286 118 197 minecraft:red_nether_bricks
setblock 286 115 201 minecraft:polished_blackstone
fill 286 115 202 286 116 202 minecraft:red_nether_bricks
setblock 286 115 220 minecraft:red_nether_bricks
setblock 286 115 221 minecraft:polished_blackstone
fill 286 115 222 286 118 222 minecraft:red_nether_bricks
setblock 287 115 196 minecraft:red_nether_bricks
setblock 287 115 220 minecraft:polished_blackstone
fill 287 115 221 287 118 221 minecraft:red_nether_bricks
fill 288 115 220 288 116 220 minecraft:red_nether_bricks
setblock 289 115 183 minecraft:polished_blackstone
setblock 290 115 182 minecraft:polished_blackstone
fill 290 115 183 290 118 183 minecraft:red_nether_bricks
setblock 290 115 221 minecraft:red_nether_bricks
setblock 290 115 222 minecraft:polished_blackstone
fill 291 115 182 291 118 182 minecraft:red_nether_bricks
setblock 291 115 221 minecraft:polished_blackstone
fill 291 115 222 294 115 222 minecraft:red_nether_bricks
fill 292 115 221 295 115 221 minecraft:red_nether_bricks
setblock 293 115 183 minecraft:red_nether_bricks
setblock 295 115 182 minecraft:polished_blackstone
setblock 295 115 222 minecraft:polished_blackstone
fill 296 115 182 296 118 182 minecraft:red_nether_bricks
setblock 296 115 221 minecraft:polished_blackstone
fill 296 115 222 296 118 222 minecraft:red_nether_bricks
fill 297 115 221 300 115 221 minecraft:red_nether_bricks
setblock 299 115 182 minecraft:red_nether_bricks
setblock 299 115 183 minecraft:polished_blackstone
fill 299 115 220 301 115 220 minecraft:red_nether_bricks
setblock 300 115 182 minecraft:polished_blackstone
fill 300 115 183 300 118 183 minecraft:red_nether_bricks
setblock 300 115 222 minecraft:polished_blackstone
fill 301 115 182 301 118 182 minecraft:red_nether_bricks
setblock 301 115 221 minecraft:polished_blackstone
fill 301 115 222 301 118 222 minecraft:red_nether_bricks
setblock 302 115 219 minecraft:red_nether_bricks
setblock 302 115 220 minecraft:polished_blackstone
fill 302 115 221 302 118 221 minecraft:red_nether_bricks
setblock 303 115 219 minecraft:polished_blackstone
fill 303 115 220 303 118 220 minecraft:red_nether_bricks
setblock 304 115 182 minecraft:red_nether_bricks
setblock 304 115 183 minecraft:polished_blackstone
fill 304 115 219 304 118 219 minecraft:red_nether_bricks
setblock 305 115 182 minecraft:polished_blackstone
fill 305 115 183 305 118 183 minecraft:red_nether_bricks
setblock 305 115 218 minecraft:red_nether_bricks
setblock 305 115 222 minecraft:polished_blackstone
fill 306 115 182 306 118 182 minecraft:red_nether_bricks
setblock 306 115 221 minecraft:polished_blackstone
fill 306 115 222 306 118 222 minecraft:red_nether_bricks
setblock 307 115 220 minecraft:polished_blackstone
fill 307 115 221 307 118 221 minecraft:red_nether_bricks
setblock 308 115 183 minecraft:red_nether_bricks
setblock 308 115 218 minecraft:red_nether_bricks
setblock 308 115 219 minecraft:polished_blackstone
fill 308 115 220 308 118 220 minecraft:red_nether_bricks
setblock 309 115 183 minecraft:polished_blackstone
fill 309 115 219 309 117 219 minecraft:red_nether_bricks
setblock 310 115 182 minecraft:polished_blackstone
setblock 310 115 222 minecraft:polished_blackstone
fill 311 115 182 311 118 182 minecraft:red_nether_bricks
setblock 311 115 221 minecraft:polished_blackstone
fill 311 115 222 311 118 222 minecraft:red_nether_bricks
setblock 312 115 220 minecraft:polished_blackstone
fill 312 115 221 312 118 221 minecraft:red_nether_bricks
fill 313 115 220 313 116 220 minecraft:red_nether_bricks
setblock 315 115 221 minecraft:red_nether_bricks
setblock 315 115 222 minecraft:polished_blackstone
setblock 316 115 221 minecraft:polished_blackstone
fill 316 115 222 319 115 222 minecraft:red_nether_bricks
fill 317 115 221 320 115 221 minecraft:red_nether_bricks
setblock 320 115 222 minecraft:polished_blackstone
setblock 321 115 196 minecraft:polished_blackstone
fill 321 115 197 321 115 200 minecraft:red_nether_bricks
setblock 321 115 201 minecraft:polished_blackstone
fill 321 115 202 321 117 203 minecraft:red_nether_bricks
setblock 321 115 217 minecraft:red_nether_bricks
fill 321 115 219 322 115 219 minecraft:red_nether_bricks
setblock 321 115 221 minecraft:polished_blackstone
fill 321 115 222 321 118 222 minecraft:red_nether_bricks
fill 322 115 182 322 117 182 minecraft:red_nether_bricks
fill 322 115 192 322 115 194 minecraft:red_nether_bricks
setblock 322 115 195 minecraft:polished_blackstone
fill 322 115 196 322 115 199 minecraft:red_nether_bricks
setblock 322 115 200 minecraft:polished_blackstone
fill 322 115 201 322 118 201 minecraft:red_nether_bricks
fill 322 115 203 322 115 204 minecraft:red_nether_bricks
setblock 322 115 205 minecraft:polished_blackstone
fill 322 115 206 322 118 206 minecraft:red_nether_bricks
setblock 322 115 210 minecraft:polished_blackstone
fill 322 115 211 322 117 211 minecraft:red_nether_bricks
setblock 322 115 215 minecraft:polished_blackstone
fill 322 115 216 322 118 216 minecraft:red_nether_bricks
setblock 322 115 220 minecraft:polished_blackstone
fill 322 115 221 322 118 221 minecraft:red_nether_bricks
setblock 323 115 183 minecraft:red_nether_bricks
setblock 323 115 184 minecraft:polished_blackstone
setblock 323 115 188 minecraft:red_nether_bricks
setblock 323 115 189 minecraft:polished_blackstone
fill 323 115 190 323 115 193 minecraft:red_nether_bricks
setblock 323 115 194 minecraft:polished_blackstone
fill 323 115 195 323 115 198 minecraft:red_nether_bricks
setblock 323 115 199 minecraft:polished_blackstone
fill 323 115 200 323 118 200 minecraft:red_nether_bricks
setblock 323 115 204 minecraft:polished_blackstone
fill 323 115 205 323 118 205 minecraft:red_nether_bricks
setblock 323 115 209 minecraft:polished_blackstone
fill 323 115 210 323 118 210 minecraft:red_nether_bricks
setblock 323 115 214 minecraft:polished_blackstone
fill 323 115 215 323 118 215 minecraft:red_nether_bricks
setblock 323 115 219 minecraft:polished_blackstone
fill 323 115 220 323 118 220 minecraft:red_nether_bricks
setblock 283 116 182 minecraft:red_nether_bricks
setblock 283 116 183 minecraft:polished_blackstone
fill 283 116 184 283 119 184 minecraft:red_nether_bricks
setblock 283 116 187 minecraft:red_nether_bricks
setblock 283 116 188 minecraft:polished_blackstone
fill 283 116 189 283 119 189 minecraft:red_nether_bricks
setblock 283 116 193 minecraft:polished_blackstone
fill 283 116 194 283 119 194 minecraft:red_nether_bricks
setblock 283 116 198 minecraft:polished_blackstone
fill 283 116 199 283 116 202 minecraft:red_nether_bricks
setblock 283 116 203 minecraft:polished_blackstone
fill 283 116 204 283 119 204 minecraft:red_nether_bricks
setblock 283 116 208 minecraft:polished_blackstone
fill 283 116 209 283 119 209 minecraft:red_nether_bricks
setblock 283 116 213 minecraft:polished_blackstone
fill 283 116 214 283 118 214 minecraft:red_nether_bricks
setblock 283 116 218 minecraft:polished_blackstone
fill 283 116 219 283 116 222 minecraft:red_nether_bricks
setblock 284 116 182 minecraft:polished_blackstone
fill 284 116 183 287 116 183 minecraft:red_nether_bricks
setblock 284 116 187 minecraft:polished_blackstone
fill 284 116 188 284 119 188 minecraft:red_nether_bricks
setblock 284 116 192 minecraft:polished_blackstone
fill 284 116 193 284 119 193 minecraft:red_nether_bricks
setblock 284 116 197 minecraft:polished_blackstone
fill 284 116 198 284 119 198 minecraft:red_nether_bricks
setblock 284 116 202 minecraft:polished_blackstone
fill 284 116 203 284 119 203 minecraft:red_nether_bricks
setblock 284 116 207 minecraft:polished_blackstone
setblock 284 116 217 minecraft:polished_blackstone
fill 284 116 218 284 118 218 minecraft:red_nether_bricks
fill 284 116 220 284 116 221 minecraft:red_nether_bricks
setblock 284 116 222 minecraft:polished_blackstone
fill 285 116 182 285 119 182 minecraft:red_nether_bricks
setblock 285 116 184 minecraft:light[level=14]
setblock 285 116 191 minecraft:polished_blackstone
fill 285 116 192 285 118 192 minecraft:red_nether_bricks
setblock 285 116 196 minecraft:polished_blackstone
fill 285 116 197 285 119 197 minecraft:red_nether_bricks
setblock 285 116 201 minecraft:polished_blackstone
fill 285 116 202 285 119 202 minecraft:red_nether_bricks
setblock 285 116 208 minecraft:light[level=14]
setblock 285 116 216 minecraft:light[level=14]
setblock 285 116 220 minecraft:red_nether_bricks
setblock 285 116 221 minecraft:polished_blackstone
fill 285 116 222 285 119 222 minecraft:red_nether_bricks
setblock 286 116 184 minecraft:red_nether_bricks
setblock 286 116 195 minecraft:polished_blackstone
fill 286 116 196 286 117 196 minecraft:red_nether_bricks
setblock 286 116 200 minecraft:polished_blackstone
fill 286 116 201 286 117 201 minecraft:red_nether_bricks
setblock 286 116 220 minecraft:polished_blackstone
fill 286 116 221 286 119 221 minecraft:red_nether_bricks
setblock 287 116 184 minecraft:polished_blackstone
setblock 287 116 220 minecraft:red_nether_bricks
setblock 288 116 183 minecraft:polished_blackstone
setblock 289 116 182 minecraft:polished_blackstone
fill 289 116 183 289 119 183 minecraft:red_nether_bricks
setblock 289 116 222 minecraft:polished_blackstone
fill 290 116 182 290 119 182 minecraft:red_nether_bricks
setblock 290 116 221 minecraft:polished_blackstone
fill 290 116 222 293 116 222 minecraft:red_nether_bricks
fill 291 116 221 294 116 221 minecraft:red_nether_bricks
setblock 293 116 183 minecraft:polished_blackstone
setblock 293 116 184 minecraft:light[level=14]
setblock 293 116 192 minecraft:light[level=14]
setblock 293 116 200 minecraft:light[level=14]
setblock 293 116 208 minecraft:light[level=14]
setblock 293 116 216 minecraft:light[level=14]
setblock 294 116 182 minecraft:polished_blackstone
setblock 294 116 222 minecraft:polished_blackstone
fill 295 116 182 295 119 182 minecraft:red_nether_bricks
setblock 295 116 221 minecraft:polished_blackstone
fill 295 116 222 295 119 222 minecraft:red_nether_bricks
fill 296 116 221 299 116 221 minecraft:red_nether_bricks
setblock 298 116 183 minecraft:polished_blackstone
setblock 299 116 182 minecraft:polished_blackstone
fill 299 116 183 299 119 183 minecraft:red_nether_bricks
fill 299 116 220 300 116 220 minecraft:red_nether_bricks
setblock 299 116 222 minecraft:polished_blackstone
fill 300 116 182 300 119 182 minecraft:red_nether_bricks
setblock 300 116 221 minecraft:polished_blackstone
fill 300 116 222 300 119 222 minecraft:red_nether_bricks
setblock 301 116 184 minecraft:light[level=14]
setblock 301 116 192 minecraft:light[level=14]
setblock 301 116 200 minecraft:light[level=14]
setblock 301 116 208 minecraft:light[level=14]
setblock 301 116 216 minecraft:light[level=14]
setblock 301 116 220 minecraft:polished_blackstone
fill 301 116 221 301 119 221 minecraft:red_nether_bricks
setblock 302 116 183 minecraft:red_nether_bricks
setblock 302 116 219 minecraft:polished_blackstone
fill 302 116 220 302 119 220 minecraft:red_nether_bricks
setblock 303 116 183 minecraft:polished_blackstone
fill 303 116 219 303 119 219 minecraft:red_nether_bricks
setblock 304 116 182 minecraft:polished_blackstone
fill 304 116 183 304 119 183 minecraft:red_nether_bricks
setblock 304 116 222 minecraft:polished_blackstone
fill 305 116 182 305 119 182 minecraft:red_nether_bricks
setblock 305 116 221 minecraft:polished_blackstone
fill 305 116 222 305 119 222 minecraft:red_nether_bricks
setblock 306 116 220 minecraft:polished_blackstone
fill 306 116 221 306 119 221 minecraft:red_nether_bricks
setblock 307 116 219 minecraft:polished_blackstone
fill 307 116 220 307 119 220 minecraft:red_nether_bricks
setblock 308 116 183 minecraft:polished_blackstone
fill 308 116 219 308 117 219 minecraft:red_nether_bricks
setblock 309 116 182 minecraft:polished_blackstone
setblock 309 116 183 minecraft:red_nether_bricks
setblock 309 116 184 minecraft:light[level=14]
setblock 309 116 192 minecraft:light[level=14]
setblock 309 116 200 minecraft:light[level=14]
setblock 309 116 208 minecraft:light[level=14]
setblock 309 116 216 minecraft:light[level=14]
setblock 309 116 222 minecraft:polished_blackstone
fill 310 116 182 310 119 182 minecraft:red_nether_bricks
setblock 310 116 221 minecraft:polished_blackstone
fill 310 116 222 310 119 222 minecraft:red_nether_bricks
setblock 311 116 220 minecraft:polished_blackstone
fill 311 116 221 311 119 221 minecraft:red_nether_bricks
fill 312 116 220 312 117 220 minecraft:red_nether_bricks
setblock 314 116 222 minecraft:polished_blackstone
setblock 315 116 221 minecraft:polished_blackstone
fill 315 116 222 318 116 222 minecraft:red_nether_bricks
fill 316 116 221 319 116 221 minecraft:red_nether_bricks
setblock 317 116 184 minecraft:light[level=14]
setblock 317 116 192 minecraft:light[level=14]
setblock 317 116 200 minecraft:light[level=14]
setblock 317 116 208 minecraft:light[level=14]
setblock 317 116 216 minecraft:light[level=14]
setblock 319 116 222 minecraft:polished_blackstone
setblock 320 116 221 minecraft:polished_blackstone
fill 320 116 222 320 119 222 minecraft:red_nether_bricks
fill 321 116 182 321 118 182 minecraft:red_nether_bricks
fill 321 116 196 321 116 199 minecraft:red_nether_bricks
setblock 321 116 200 minecraft:polished_blackstone
fill 321 116 201 321 119 201 minecraft:red_nether_bricks
setblock 321 116 204 minecraft:red_nether_bricks
fill 321 116 221 321 119 221 minecraft:red_nether_bricks
setblock 322 116 193 minecraft:red_nether_bricks
setblock 322 116 194 minecraft:polished_blackstone
fill 322 116 195 322 116 198 minecraft:red_nether_bricks
setblock 322 116 199 minecraft:polished_blackstone
fill 322 116 200 322 119 200 minecraft:red_nether_bricks
setblock 322 116 203 minecraft:red_nether_bricks
setblock 322 116 204 minecraft:polished_blackstone
fill 322 116 205 322 119 205 minecraft:red_nether_bricks
setblock 322 116 209 minecraft:polished_blackstone
fill 322 116 210 322 117 210 minecraft:red_nether_bricks
setblock 322 116 214 minecraft:polished_blackstone
fill 322 116 215 322 117 215 minecraft:red_nether_bricks
setblock 322 116 219 minecraft:polished_blackstone
fill 322 116 220 322 119 220 minecraft:red_nether_bricks
setblock 323 116 183 minecraft:polished_blackstone
fill 323 116 184 323 116 187 minecraft:red_nether_bricks
setblock 323 116 188 minecraft:polished_blackstone
fill 323 116 189 323 116 192 minecraft:red_nether_bricks
setblock 323 116 193 minecraft:polished_blackstone
fill 323 116 194 323 116 197 minecraft:red_nether_bricks
setblock 323 116 198 minecraft:polished_blackstone
fill 323 116 199 323 119 199 minecraft:red_nether_bricks
setblock 323 116 203 minecraft:polished_blackstone
fill 323 116 204 323 119 204 minecraft:red_nether_bricks
setblock 323 116 208 minecraft:polished_blackstone
fill 323 116 209 323 119 209 minecraft:red_nether_bricks
setblock 323 116 213 minecraft:polished_blackstone
fill 323 116 214 323 119 214 minecraft:red_nether_bricks
setblock 323 116 218 minecraft:polished_blackstone
fill 323 116 219 323 119 219 minecraft:red_nether_bricks
setblock 283 117 182 minecraft:polished_blackstone
fill 283 117 183 286 117 183 minecraft:red_nether_bricks
setblock 283 117 186 minecraft:red_nether_bricks
setblock 283 117 187 minecraft:polished_blackstone
fill 283 117 188 283 120 188 minecraft:red_nether_bricks
setblock 283 117 192 minecraft:polished_blackstone
fill 283 117 193 283 120 193 minecraft:red_nether_bricks
setblock 283 117 197 minecraft:polished_blackstone
fill 283 117 198 283 117 201 minecraft:red_nether_bricks
setblock 283 117 202 minecraft:polished_blackstone
fill 283 117 203 283 120 203 minecraft:red_nether_bricks
setblock 283 117 207 minecraft:polished_blackstone
fill 283 117 208 283 120 208 minecraft:red_nether_bricks
setblock 283 117 212 minecraft:polished_blackstone
setblock 283 117 213 minecraft:red_nether_bricks
setblock 283 117 217 minecraft:polished_blackstone
fill 283 117 218 283 117 221 minecraft:red_nether_bricks
setblock 283 117 222 minecraft:polished_blackstone
fill 284 117 182 284 120 182 minecraft:red_nether_bricks
setblock 284 117 186 minecraft:polished_blackstone
fill 284 117 187 284 120 187 minecraft:red_nether_bricks
setblock 284 117 191 minecraft:polished_blackstone
fill 284 117 192 284 120 192 minecraft:red_nether_bricks
setblock 284 117 196 minecraft:polished_blackstone
fill 284 117 197 284 120 197 minecraft:red_nether_bricks
setblock 284 117 201 minecraft:polished_blackstone
fill 284 117 202 284 120 202 minecraft:red_nether_bricks
setblock 284 117 206 minecraft:polished_blackstone
setblock 284 117 207 minecraft:red_nether_bricks
setblock 284 117 217 minecraft:red_nether_bricks
setblock 284 117 220 minecraft:red_nether_bricks
setblock 284 117 221 minecraft:polished_blackstone
fill 284 117 222 284 120 222 minecraft:red_nether_bricks
setblock 285 117 184 minecraft:red_nether_bricks
setblock 285 117 191 minecraft:red_nether_bricks
setblock 285 117 195 minecraft:polished_blackstone
fill 285 117 196 285 119 196 minecraft:red_nether_bricks
setblock 285 117 200 minecraft:polished_blackstone
fill 285 117 201 285 120 201 minecraft:red_nether_bricks
fill 285 117 221 285 120 221 minecraft:red_nether_bricks
setblock 286 117 184 minecraft:polished_blackstone
setblock 286 117 195 minecraft:red_nether_bricks
setblock 286 117 199 minecraft:polished_blackstone
fill 286 117 200 286 118 200 minecraft:red_nether_bricks
setblock 287 117 183 minecraft:polished_blackstone
fill 287 117 184 287 118 184 minecraft:red_nether_bricks
setblock 288 117 182 minecraft:polished_blackstone
fill 288 117 183 288 120 183 minecraft:red_nether_bricks
setblock 288 117 222 minecraft:polished_blackstone
fill 289 117 182 289 120 182 minecraft:red_nether_bricks
setblock 289 117 221 minecraft:polished_blackstone
fill 289 117 222 292 117 222 minecraft:red_nether_bricks
fill 290 117 221 293 117 221 minecraft:red_nether_bricks
setblock 292 117 183 minecraft:polished_blackstone
setblock 293 117 182 minecraft:polished_blackstone
setblock 293 117 183 minecraft:red_nether_bricks
setblock 293 117 222 minecraft:polished_blackstone
fill 294 117 182 294 120 182 minecraft:red_nether_bricks
setblock 294 117 221 minecraft:polished_blackstone
fill 294 117 222 294 120 222 minecraft:red_nether_bricks
fill 295 117 221 298 117 221 minecraft:red_nether_bricks
setblock 297 117 183 minecraft:polished_blackstone
setblock 298 117 182 minecraft:polished_blackstone
fill 298 117 183 298 120 183 minecraft:red_nether_bricks
setblock 298 117 222 minecraft:polished_blackstone
fill 299 117 182 299 120 182 minecraft:red_nether_bricks
setblock 299 117 220 minecraft:red_nether_bricks
setblock 299 117 221 minecraft:polished_blackstone
fill 299 117 222 299 120 222 minecraft:red_nether_bricks
setblock 300 117 220 minecraft:polished_blackstone
fill 300 117 221 300 120 221 minecraft:red_nether_bricks
fill 301 117 220 301 120 220 minecraft:red_nether_bricks
setblock 302 117 183 minecraft:polished_blackstone
fill 302 117 219 302 118 219 minecraft:red_nether_bricks
setblock 303 117 182 minecraft:polished_blackstone
fill 303 117 183 303 120 183 minecraft:red_nether_bricks
setblock 303 117 222 minecraft:polished_blackstone
fill 304 117 182 304 120 182 minecraft:red_nether_bricks
setblock 304 117 221 minecraft:polished_blackstone
fill 304 117 222 304 120 222 minecraft:red_nether_bricks
setblock 305 117 220 minecraft:polished_blackstone
fill 305 117 221 305 120 221 minecraft:red_nether_bricks
setblock 306 117 219 minecraft:polished_blackstone
fill 306 117 220 306 120 220 minecraft:red_nether_bricks
setblock 307 117 183 minecraft:polished_blackstone
fill 307 117 219 307 118 219 minecraft:red_nether_bricks
setblock 308 117 182 minecraft:polished_blackstone
fill 308 117 183 308 118 183 minecraft:red_nether_bricks
setblock 308 117 222 minecraft:polished_blackstone
fill 309 117 182 309 120 182 minecraft:red_nether_bricks
setblock 309 117 221 minecraft:polished_blackstone
fill 309 117 222 309 120 222 minecraft:red_nether_bricks
setblock 310 117 220 minecraft:polished_blackstone
fill 310 117 221 310 120 221 minecraft:red_nether_bricks
setblock 311 117 220 minecraft:red_nether_bricks
setblock 313 117 222 minecraft:polished_blackstone
setblock 314 117 221 minecraft:polished_blackstone
fill 314 117 222 317 117 222 minecraft:red_nether_bricks
fill 315 117 221 318 117 221 minecraft:red_nether_bricks
setblock 318 117 222 minecraft:polished_blackstone
setblock 319 117 221 minecraft:polished_blackstone
fill 319 117 222 319 120 222 minecraft:red_nether_bricks
fill 320 117 221 320 119 221 minecraft:red_nether_bricks
fill 321 117 196 321 117 198 minecraft:red_nether_bricks
setblock 321 117 199 minecraft:polished_blackstone
fill 321 117 200 321 120 200 minecraft:red_nether_bricks
setblock 321 117 204 minecraft:polished_blackstone
fill 321 117 205 321 120 205 minecraft:red_nether_bricks
setblock 322 117 193 minecraft:polished_blackstone
fill 322 117 194 322 117 197 minecraft:red_nether_bricks
setblock 322 117 198 minecraft:polished_blackstone
fill 322 117 199 322 120 199 minecraft:red_nether_bricks
setblock 322 117 203 minecraft:polished_blackstone
fill 322 117 204 322 120 204 minecraft:red_nether_bricks
setblock 322 117 207 minecraft:red_nether_bricks
setblock 322 117 208 minecraft:polished_blackstone
fill 322 117 209 322 120 209 minecraft:red_nether_bricks
setblock 322 117 213 minecraft:polished_blackstone
setblock 322 117 214 minecraft:red_nether_bricks
setblock 322 117 218 minecraft:polished_blackstone
fill 322 117 219 322 119 219 minecraft:red_nether_bricks
setblock 323 117 182 minecraft:polished_blackstone
fill 323 117 183 323 117 186 minecraft:red_nether_bricks
setblock 323 117 187 minecraft:polished_blackstone
fill 323 117 188 323 117 191 minecraft:red_nether_bricks
setblock 323 117 192 minecraft:polished_blackstone
fill 323 117 193 323 117 196 minecraft:red_nether_bricks
setblock 323 117 197 minecraft:polished_blackstone
fill 323 117 198 323 120 198 minecraft:red_nether_bricks
setblock 323 117 202 minecraft:polished_blackstone
fill 323 117 203 323 120 203 minecraft:red_nether_bricks
setblock 323 117 207 minecraft:polished_blackstone
fill 323 117 208 323 120 208 minecraft:red_nether_bricks
setblock 323 117 212 minecraft:polished_blackstone
fill 323 117 213 323 120 213 minecraft:red_nether_bricks
setblock 323 117 217 minecraft:polished_blackstone
fill 323 117 218 323 120 218 minecraft:red_nether_bricks
setblock 323 117 222 minecraft:polished_blackstone
fill 283 118 182 283 120 183 minecraft:red_nether_bricks
setblock 283 118 186 minecraft:polished_blackstone
fill 283 118 187 283 121 187 minecraft:red_nether_bricks
setblock 283 118 191 minecraft:polished_blackstone
fill 283 118 192 283 121 192 minecraft:red_nether_bricks
setblock 283 118 196 minecraft:polished_blackstone
fill 283 118 197 283 118 200 minecraft:red_nether_bricks
setblock 283 118 201 minecraft:polished_blackstone
fill 283 118 202 283 121 202 minecraft:red_nether_bricks
setblock 283 118 206 minecraft:polished_blackstone
fill 283 118 207 283 121 207 minecraft:red_nether_bricks
setblock 283 118 216 minecraft:polished_blackstone
fill 283 118 217 283 118 220 minecraft:red_nether_bricks
setblock 283 118 221 minecraft:polished_blackstone
fill 283 118 222 283 121 222 minecraft:red_nether_bricks
fill 284 118 183 285 118 183 minecraft:red_nether_bricks
setblock 284 118 185 minecraft:polished_blackstone
fill 284 118 186 284 121 186 minecraft:red_nether_bricks
setblock 284 118 190 minecraft:polished_blackstone
fill 284 118 191 284 121 191 minecraft:red_nether_bricks
setblock 284 118 195 minecraft:polished_blackstone
fill 284 118 196 284 121 196 minecraft:red_nether_bricks
setblock 284 118 200 minecraft:polished_blackstone
fill 284 118 201 284 121 201 minecraft:red_nether_bricks
setblock 284 118 205 minecraft:polished_blackstone
fill 284 118 206 284 121 206 minecraft:red_nether_bricks
setblock 284 118 220 minecraft:polished_blackstone
fill 284 118 221 284 121 221 minecraft:red_nether_bricks
setblock 285 118 184 minecraft:polished_blackstone
setblock 285 118 194 minecraft:polished_blackstone
fill 285 118 195 285 119 195 minecraft:red_nether_bricks
setblock 285 118 199 minecraft:polished_blackstone
fill 285 118 200 285 121 200 minecraft:red_nether_bricks
setblock 285 118 204 minecraft:polished_blackstone
setblock 286 118 183 minecraft:polished_blackstone
fill 286 118 184 286 121 184 minecraft:red_nether_bricks
setblock 286 118 198 minecraft:polished_blackstone
setblock 286 118 199 minecraft:red_nether_bricks
setblock 287 118 182 minecraft:polished_blackstone
fill 287 118 183 287 121 183 minecraft:red_nether_bricks
setblock 287 118 222 minecraft:polished_blackstone
fill 288 118 182 288 121 182 minecraft:red_nether_bricks
setblock 288 118 221 minecraft:polished_blackstone
fill 288 118 222 291 118 222 minecraft:red_nether_bricks
fill 289 118 221 290 118 221 minecraft:red_nether_bricks
setblock 291 118 183 minecraft:polished_blackstone
setblock 292 118 182 minecraft:polished_blackstone
setblock 292 118 183 minecraft:red_nether_bricks
setblock 292 118 222 minecraft:polished_blackstone
fill 293 118 182 293 121 182 minecraft:red_nether_bricks
fill 293 118 222 293 121 222 minecraft:red_nether_bricks
fill 296 118 221 297 118 221 minecraft:red_nether_bricks
setblock 297 118 182 minecraft:polished_blackstone
fill 297 118 183 297 121 183 minecraft:red_nether_bricks
setblock 297 118 222 minecraft:polished_blackstone
fill 298 118 182 298 121 182 minecraft:red_nether_bricks
setblock 298 118 221 minecraft:polished_blackstone
fill 298 118 222 298 121 222 minecraft:red_nether_bricks
fill 299 118 217 299 118 220 minecraft:polished_blackstone
fill 299 118 221 299 121 221 minecraft:red_nether_bricks
fill 300 118 217 301 118 217 minecraft:polished_blackstone
fill 300 118 219 301 118 219 minecraft:polished_blackstone
fill 300 118 220 300 121 220 minecraft:red_nether_bricks
setblock 301 118 183 minecraft:polished_blackstone
setblock 301 118 218 minecraft:polished_blackstone
setblock 302 118 182 minecraft:polished_blackstone
fill 302 118 183 302 121 183 minecraft:red_nether_bricks
setblock 302 118 222 minecraft:polished_blackstone
fill 303 118 182 303 121 182 minecraft:red_nether_bricks
setblock 303 118 221 minecraft:polished_blackstone
fill 303 118 222 303 121 222 minecraft:red_nether_bricks
setblock 304 118 220 minecraft:polished_blackstone
fill 304 118 221 304 121 221 minecraft:red_nether_bricks
setblock 305 118 219 minecraft:polished_blackstone
fill 305 118 220 305 121 220 minecraft:red_nether_bricks
setblock 306 118 183 minecraft:polished_blackstone
setblock 306 118 219 minecraft:red_nether_bricks
setblock 307 118 182 minecraft:polished_blackstone
fill 307 118 183 307 120 183 minecraft:red_nether_bricks
setblock 307 118 222 minecraft:polished_blackstone
fill 308 118 182 308 121 182 minecraft:red_nether_bricks
setblock 308 118 221 minecraft:polished_blackstone
fill 308 118 222 308 121 222 minecraft:red_nether_bricks
setblock 309 118 220 minecraft:polished_blackstone
fill 309 118 221 309 121 221 minecraft:red_nether_bricks
setblock 310 118 220 minecraft:red_nether_bricks
setblock 311 118 183 minecraft:polished_blackstone
setblock 311 118 185 minecraft:polished_blackstone
setblock 312 118 222 minecraft:polished_blackstone
setblock 313 118 183 minecraft:polished_blackstone
setblock 313 118 185 minecraft:polished_blackstone
setblock 313 118 221 minecraft:polished_blackstone
fill 313 118 222 316 118 222 minecraft:red_nether_bricks
setblock 317 118 222 minecraft:polished_blackstone
fill 318 118 222 318 121 222 minecraft:red_nether_bricks
setblock 319 118 221 minecraft:red_nether_bricks
fill 320 118 182 320 119 182 minecraft:red_nether_bricks
setblock 321 118 197 minecraft:red_nether_bricks
setblock 321 118 198 minecraft:polished_blackstone
fill 321 118 199 321 121 199 minecraft:red_nether_bricks
setblock 321 118 202 minecraft:red_nether_bricks
setblock 321 118 203 minecraft:polished_blackstone
fill 321 118 204 321 121 204 minecraft:red_nether_bricks
setblock 322 118 182 minecraft:polished_blackstone
fill 322 118 193 322 118 196 minecraft:red_nether_bricks
setblock 322 118 197 minecraft:polished_blackstone
fill 322 118 198 322 121 198 minecraft:red_nether_bricks
setblock 322 118 202 minecraft:polished_blackstone
fill 322 118 203 322 121 203 minecraft:red_nether_bricks
setblock 322 118 207 minecraft:polished_blackstone
fill 322 118 208 322 121 208 minecraft:red_nether_bricks
setblock 322 118 217 minecraft:polished_blackstone
fill 322 118 218 322 119 218 minecraft:red_nether_bricks
setblock 322 118 222 minecraft:polished_blackstone
fill 323 118 182 323 118 185 minecraft:red_nether_bricks
setblock 323 118 186 minecraft:polished_blackstone
fill 323 118 187 323 118 190 minecraft:red_nether_bricks
setblock 323 118 191 minecraft:polished_blackstone
fill 323 118 192 323 118 195 minecraft:red_nether_bricks
setblock 323 118 196 minecraft:polished_blackstone
fill 323 118 197 323 121 197 minecraft:red_nether_bricks
setblock 323 118 201 minecraft:polished_blackstone
fill 323 118 202 323 121 202 minecraft:red_nether_bricks
setblock 323 118 206 minecraft:polished_blackstone
fill 323 118 207 323 121 207 minecraft:red_nether_bricks
setblock 323 118 211 minecraft:polished_blackstone
fill 323 118 212 323 121 212 minecraft:red_nether_bricks
setblock 323 118 216 minecraft:polished_blackstone
fill 323 118 217 323 121 217 minecraft:red_nether_bricks
setblock 323 118 221 minecraft:polished_blackstone
fill 323 118 222 323 121 222 minecraft:red_nether_bricks
setblock 283 119 185 minecraft:polished_blackstone
fill 283 119 186 283 122 186 minecraft:red_nether_bricks
setblock 283 119 190 minecraft:polished_blackstone
fill 283 119 191 283 122 191 minecraft:red_nether_bricks
setblock 283 119 195 minecraft:polished_blackstone
fill 283 119 196 283 119 199 minecraft:red_nether_bricks
setblock 283 119 200 minecraft:polished_blackstone
fill 283 119 201 283 122 201 minecraft:red_nether_bricks
setblock 283 119 205 minecraft:polished_blackstone
fill 283 119 206 283 122 206 minecraft:red_nether_bricks
fill 283 119 216 283 119 219 minecraft:red_nether_bricks
setblock 283 119 220 minecraft:polished_blackstone
fill 283 119 221 283 122 221 minecraft:red_nether_bricks
setblock 284 119 183 minecraft:red_nether_bricks
setblock 284 119 184 minecraft:polished_blackstone
fill 284 119 185 284 122 185 minecraft:red_nether_bricks
setblock 284 119 189 minecraft:polished_blackstone
fill 284 119 190 284 122 190 minecraft:red_nether_bricks
setblock 284 119 194 minecraft:polished_blackstone
fill 284 119 195 284 122 195 minecraft:red_nether_bricks
setblock 284 119 199 minecraft:polished_blackstone
fill 284 119 200 284 122 200 minecraft:red_nether_bricks
setblock 284 119 204 minecraft:polished_blackstone
fill 284 119 205 284 122 205 minecraft:red_nether_bricks
setblock 284 119 219 minecraft:polished_blackstone
setblock 284 119 220 minecraft:red_nether_bricks
setblock 285 119 183 minecraft:polished_blackstone
fill 285 119 184 285 122 184 minecraft:red_nether_bricks
setblock 285 119 198 minecraft:polished_blackstone
fill 285 119 199 285 120 199 minecraft:red_nether_bricks
setblock 285 119 203 minecraft:polished_blackstone
setblock 286 119 182 minecraft:polished_blackstone
fill 286 119 183 286 122 183 minecraft:red_nether_bricks
setblock 286 119 222 minecraft:polished_blackstone
fill 287 119 182 287 122 182 minecraft:red_nether_bricks
setblock 287 119 221 minecraft:polished_blackstone
fill 287 119 222 290 119 222 minecraft:red_nether_bricks
setblock 288 119 221 minecraft:red_nether_bricks
setblock 290 119 183 minecraft:polished_blackstone
setblock 291 119 182 minecraft:polished_blackstone
fill 291 119 183 291 122 183 minecraft:red_nether_bricks
setblock 291 119 222 minecraft:polished_blackstone
fill 292 119 182 292 122 182 minecraft:red_nether_bricks
fill 292 119 222 292 122 222 minecraft:red_nether_bricks
setblock 296 119 182 minecraft:polished_blackstone
fill 296 119 183 296 122 183 minecraft:red_nether_bricks
setblock 296 119 221 minecraft:red_nether_bricks
setblock 296 119 222 minecraft:polished_blackstone
fill 297 119 182 297 122 182 minecraft:red_nether_bricks
setblock 297 119 221 minecraft:polished_blackstone
fill 297 119 222 297 122 222 minecraft:red_nether_bricks
fill 298 119 221 298 122 221 minecraft:red_nether_bricks
setblock 299 119 220 minecraft:red_nether_bricks
setblock 300 119 183 minecraft:polished_blackstone
setblock 301 119 182 minecraft:polished_blackstone
fill 301 119 183 301 122 183 minecraft:red_nether_bricks
setblock 301 119 222 minecraft:polished_blackstone
fill 302 119 182 302 122 182 minecraft:red_nether_bricks
setblock 302 119 221 minecraft:polished_blackstone
fill 302 119 222 302 122 222 minecraft:red_nether_bricks
setblock 303 119 220 minecraft:polished_blackstone
fill 303 119 221 303 122 221 minecraft:red_nether_bricks
setblock 304 119 219 minecraft:polished_blackstone
fill 304 119 220 304 122 220 minecraft:red_nether_bricks
setblock 305 119 183 minecraft:polished_blackstone
setblock 305 119 219 minecraft:red_nether_bricks
setblock 306 119 182 minecraft:polished_blackstone
fill 306 119 183 306 122 183 minecraft:red_nether_bricks
setblock 306 119 222 minecraft:polished_blackstone
fill 307 119 182 307 122 182 minecraft:red_nether_bricks
setblock 307 119 221 minecraft:polished_blackstone
fill 307 119 222 307 122 222 minecraft:red_nether_bricks
setblock 308 119 220 minecraft:polished_blackstone
fill 308 119 221 308 122 221 minecraft:red_nether_bricks
setblock 309 119 220 minecraft:red_nether_bricks
setblock 311 119 222 minecraft:polished_blackstone
fill 312 119 199 314 120 199 minecraft:magma_block
setblock 312 119 221 minecraft:polished_blackstone
fill 312 119 222 315 119 222 minecraft:red_nether_bricks
fill 313 119 200 314 120 200 minecraft:magma_block
setblock 316 119 222 minecraft:polished_blackstone
fill 317 119 222 317 122 222 minecraft:red_nether_bricks
setblock 321 119 182 minecraft:polished_blackstone
setblock 321 119 197 minecraft:polished_blackstone
fill 321 119 198 321 122 198 minecraft:red_nether_bricks
setblock 321 119 202 minecraft:polished_blackstone
fill 321 119 203 321 122 203 minecraft:red_nether_bricks
setblock 321 119 206 minecraft:red_nether_bricks
setblock 321 119 222 minecraft:polished_blackstone
fill 322 119 182 323 121 182 minecraft:red_nether_bricks
fill 322 119 194 322 119 195 minecraft:red_nether_bricks
setblock 322 119 196 minecraft:polished_blackstone
fill 322 119 197 322 122 197 minecraft:red_nether_bricks
setblock 322 119 201 minecraft:polished_blackstone
fill 322 119 202 322 122 202 minecraft:red_nether_bricks
setblock 322 119 206 minecraft:polished_blackstone
fill 322 119 207 322 122 207 minecraft:red_nether_bricks
setblock 322 119 221 minecraft:polished_blackstone
fill 322 119 222 322 122 222 minecraft:red_nether_bricks
fill 323 119 183 323 119 184 minecraft:red_nether_bricks
setblock 323 119 185 minecraft:polished_blackstone
fill 323 119 186 323 119 189 minecraft:red_nether_bricks
setblock 323 119 190 minecraft:polished_blackstone
fill 323 119 191 323 119 194 minecraft:red_nether_bricks
setblock 323 119 195 minecraft:polished_blackstone
fill 323 119 196 323 122 196 minecraft:red_nether_bricks
setblock 323 119 200 minecraft:polished_blackstone
fill 323 119 201 323 122 201 minecraft:red_nether_bricks
setblock 323 119 205 minecraft:polished_blackstone
fill 323 119 206 323 122 206 minecraft:red_nether_bricks
setblock 323 119 210 minecraft:polished_blackstone
fill 323 119 211 323 122 211 minecraft:red_nether_bricks
setblock 323 119 215 minecraft:polished_blackstone
fill 323 119 216 323 120 216 minecraft:red_nether_bricks
setblock 323 119 220 minecraft:polished_blackstone
fill 323 119 221 323 122 221 minecraft:red_nether_bricks
setblock 283 120 184 minecraft:polished_blackstone
fill 283 120 185 283 123 185 minecraft:red_nether_bricks
setblock 283 120 189 minecraft:polished_blackstone
fill 283 120 190 283 123 190 minecraft:red_nether_bricks
setblock 283 120 194 minecraft:polished_blackstone
fill 283 120 195 283 120 198 minecraft:red_nether_bricks
setblock 283 120 199 minecraft:polished_blackstone
fill 283 120 200 283 123 200 minecraft:red_nether_bricks
setblock 283 120 204 minecraft:polished_blackstone
fill 283 120 205 283 123 205 minecraft:red_nether_bricks
setblock 283 120 209 minecraft:polished_blackstone
setblock 283 120 218 minecraft:red_nether_bricks
setblock 283 120 219 minecraft:polished_blackstone
fill 283 120 220 283 123 220 minecraft:red_nether_bricks
setblock 284 120 183 minecraft:polished_blackstone
fill 284 120 184 284 123 184 minecraft:red_nether_bricks
setblock 284 120 188 minecraft:polished_blackstone
fill 284 120 189 284 123 189 minecraft:red_nether_bricks
setblock 284 120 193 minecraft:polished_blackstone
fill 284 120 194 284 121 194 minecraft:red_nether_bricks
setblock 284 120 198 minecraft:polished_blackstone
fill 284 120 199 284 123 199 minecraft:red_nether_bricks
setblock 284 120 203 minecraft:polished_blackstone
fill 284 120 204 284 123 204 minecraft:red_nether_bricks
setblock 285 120 182 minecraft:polished_blackstone
fill 285 120 183 285 123 183 minecraft:red_nether_bricks
setblock 285 120 197 minecraft:polished_blackstone
setblock 285 120 198 minecraft:red_nether_bricks
setblock 285 120 202 minecraft:polished_blackstone
setblock 285 120 203 minecraft:red_nether_bricks
setblock 285 120 222 minecraft:polished_blackstone
fill 286 120 182 286 123 182 minecraft:red_nether_bricks
setblock 286 120 221 minecraft:polished_blackstone
fill 286 120 222 289 120 222 minecraft:red_nether_bricks
setblock 289 120 183 minecraft:polished_blackstone
setblock 290 120 182 minecraft:polished_blackstone
fill 290 120 183 290 123 183 minecraft:red_nether_bricks
setblock 290 120 222 minecraft:polished_blackstone
fill 291 120 182 291 123 182 minecraft:red_nether_bricks
fill 291 120 222 291 123 222 minecraft:red_nether_bricks
setblock 295 120 182 minecraft:polished_blackstone
setblock 295 120 222 minecraft:polished_blackstone
fill 296 120 182 296 123 182 minecraft:red_nether_bricks
setblock 296 120 221 minecraft:polished_blackstone
fill 296 120 222 296 123 222 minecraft:red_nether_bricks
fill 297 120 221 297 123 221 minecraft:red_nether_bricks
setblock 299 120 183 minecraft:polished_blackstone
setblock 300 120 182 minecraft:polished_blackstone
fill 300 120 183 300 123 183 minecraft:red_nether_bricks
setblock 300 120 222 minecraft:polished_blackstone
fill 301 120 182 301 123 182 minecraft:red_nether_bricks
setblock 301 120 221 minecraft:polished_blackstone
fill 301 120 222 301 123 222 minecraft:red_nether_bricks
setblock 302 120 220 minecraft:polished_blackstone
fill 302 120 221 302 123 221 minecraft:red_nether_bricks
fill 303 120 220 303 123 220 minecraft:red_nether_bricks
setblock 304 120 183 minecraft:polished_blackstone
setblock 305 120 182 minecraft:polished_blackstone
fill 305 120 183 305 123 183 minecraft:red_nether_bricks
setblock 305 120 222 minecraft:polished_blackstone
fill 306 120 182 306 123 182 minecraft:red_nether_bricks
setblock 306 120 221 minecraft:polished_blackstone
fill 306 120 222 306 123 222 minecraft:red_nether_bricks
setblock 307 120 220 minecraft:polished_blackstone
fill 307 120 221 307 123 221 minecraft:red_nether_bricks
setblock 310 120 222 minecraft:polished_blackstone
fill 311 120 222 314 120 222 minecraft:red_nether_bricks
setblock 315 120 222 minecraft:polished_blackstone
fill 316 120 222 316 121 222 minecraft:red_nether_bricks
setblock 319 120 182 minecraft:red_nether_bricks
setblock 320 120 182 minecraft:polished_blackstone
setblock 320 120 222 minecraft:polished_blackstone
fill 321 120 182 321 123 182 minecraft:red_nether_bricks
setblock 321 120 197 minecraft:red_nether_bricks
setblock 321 120 201 minecraft:polished_blackstone
fill 321 120 202 321 123 202 minecraft:red_nether_bricks
setblock 321 120 206 minecraft:polished_blackstone
setblock 321 120 221 minecraft:polished_blackstone
fill 321 120 222 321 123 222 minecraft:red_nether_bricks
setblock 322 120 194 minecraft:red_nether_bricks
setblock 322 120 195 minecraft:polished_blackstone
fill 322 120 196 322 123 196 minecraft:red_nether_bricks
setblock 322 120 200 minecraft:polished_blackstone
fill 322 120 201 322 123 201 minecraft:red_nether_bricks
setblock 322 120 205 minecraft:polished_blackstone
fill 322 120 206 322 123 206 minecraft:red_nether_bricks
setblock 322 120 220 minecraft:polished_blackstone
setblock 322 120 221 minecraft:red_nether_bricks
setblock 323 120 183 minecraft:red_nether_bricks
setblock 323 120 184 minecraft:polished_blackstone
fill 323 120 185 323 120 188 minecraft:red_nether_bricks
setblock 323 120 189 minecraft:polished_blackstone
fill 323 120 190 323 120 193 minecraft:red_nether_bricks
setblock 323 120 194 minecraft:polished_blackstone
fill 323 120 195 323 123 195 minecraft:red_nether_bricks
setblock 323 120 199 minecraft:polished_blackstone
fill 323 120 200 323 123 200 minecraft:red_nether_bricks
setblock 323 120 204 minecraft:polished_blackstone
fill 323 120 205 323 123 205 minecraft:red_nether_bricks
setblock 323 120 209 minecraft:polished_blackstone
fill 323 120 210 323 123 210 minecraft:red_nether_bricks
setblock 323 120 214 minecraft:polished_blackstone
setblock 323 120 215 minecraft:red_nether_bricks
setblock 323 120 219 minecraft:polished_blackstone
fill 323 120 220 323 123 220 minecraft:red_nether_bricks
setblock 283 121 182 minecraft:red_nether_bricks
setblock 283 121 183 minecraft:polished_blackstone
fill 283 121 184 283 124 184 minecraft:red_nether_bricks
setblock 283 121 188 minecraft:polished_blackstone
fill 283 121 189 283 124 189 minecraft:red_nether_bricks
setblock 283 121 193 minecraft:polished_blackstone
fill 283 121 194 283 121 197 minecraft:red_nether_bricks
setblock 283 121 198 minecraft:polished_blackstone
fill 283 121 199 283 124 199 minecraft:red_nether_bricks
setblock 283 121 203 minecraft:polished_blackstone
fill 283 121 204 283 124 204 minecraft:red_nether_bricks
setblock 283 121 208 minecraft:polished_blackstone
fill 283 121 209 283 124 209 minecraft:red_nether_bricks
fill 283 121 219 283 122 219 minecraft:red_nether_bricks
setblock 284 121 182 minecraft:polished_blackstone
fill 284 121 183 284 124 183 minecraft:red_nether_bricks
setblock 284 121 187 minecraft:polished_blackstone
fill 284 121 188 284 124 188 minecraft:red_nether_bricks
setblock 284 121 192 minecraft:polished_blackstone
setblock 284 121 193 minecraft:red_nether_bricks
setblock 284 121 197 minecraft:polished_blackstone
fill 284 121 198 284 124 198 minecraft:red_nether_bricks
setblock 284 121 202 minecraft:polished_blackstone
fill 284 121 203 284 124 203 minecraft:red_nether_bricks
setblock 284 121 222 minecraft:polished_blackstone
fill 285 121 182 285 124 182 minecraft:red_nether_bricks
setblock 285 121 185 minecraft:red_nether_bricks
setblock 285 121 201 minecraft:polished_blackstone
fill 285 121 222 288 121 222 minecraft:red_nether_bricks
setblock 288 121 183 minecraft:polished_blackstone
setblock 289 121 182 minecraft:polished_blackstone
fill 289 121 183 289 124 183 minecraft:red_nether_bricks
setblock 289 121 222 minecraft:polished_blackstone
fill 290 121 182 290 124 182 minecraft:red_nether_bricks
fill 290 121 222 290 124 222 minecraft:red_nether_bricks
setblock 294 121 182 minecraft:polished_blackstone
setblock 294 121 222 minecraft:polished_blackstone
fill 295 121 182 295 123 183 minecraft:red_nether_bricks
fill 295 121 222 295 124 222 minecraft:red_nether_bricks
setblock 298 121 183 minecraft:polished_blackstone
setblock 299 121 182 minecraft:polished_blackstone
fill 299 121 183 299 124 183 minecraft:red_nether_bricks
setblock 299 121 222 minecraft:polished_blackstone
fill 300 121 182 300 124 182 minecraft:red_nether_bricks
setblock 300 121 221 minecraft:polished_blackstone
fill 300 121 222 300 124 222 minecraft:red_nether_bricks
setblock 301 121 220 minecraft:polished_blackstone
fill 301 121 221 301 124 221 minecraft:red_nether_bricks
fill 302 121 220 302 124 220 minecraft:red_nether_bricks
setblock 303 121 183 minecraft:polished_blackstone
setblock 304 121 182 minecraft:polished_blackstone
fill 304 121 183 304 124 183 minecraft:red_nether_bricks
setblock 304 121 222 minecraft:polished_blackstone
fill 305 121 182 305 124 182 minecraft:red_nether_bricks
setblock 305 121 221 minecraft:polished_blackstone
fill 305 121 222 305 124 222 minecraft:red_nether_bricks
setblock 306 121 220 minecraft:polished_blackstone
fill 306 121 221 306 124 221 minecraft:red_nether_bricks
setblock 309 121 182 minecraft:polished_blackstone
setblock 309 121 222 minecraft:polished_blackstone
fill 310 121 222 312 121 222 minecraft:red_nether_bricks
setblock 319 121 182 minecraft:polished_blackstone
setblock 319 121 222 minecraft:polished_blackstone
fill 320 121 182 320 124 182 minecraft:red_nether_bricks
fill 320 121 222 320 124 222 minecraft:red_nether_bricks
setblock 321 121 200 minecraft:polished_blackstone
fill 321 121 201 321 124 201 minecraft:red_nether_bricks
setblock 321 121 205 minecraft:polished_blackstone
fill 321 121 206 321 123 207 minecraft:red_nether_bricks
setblock 322 121 183 minecraft:red_nether_bricks
setblock 322 121 184 minecraft:polished_blackstone
fill 322 121 195 322 124 195 minecraft:red_nether_bricks
setblock 322 121 199 minecraft:polished_blackstone
fill 322 121 200 322 124 200 minecraft:red_nether_bricks
setblock 322 121 204 minecraft:polished_blackstone
fill 322 121 205 322 124 205 minecraft:red_nether_bricks
setblock 322 121 209 minecraft:polished_blackstone
setblock 323 121 183 minecraft:polished_blackstone
fill 323 121 184 323 121 187 minecraft:red_nether_bricks
setblock 323 121 188 minecraft:polished_blackstone
fill 323 121 189 323 121 192 minecraft:red_nether_bricks
setblock 323 121 193 minecraft:polished_blackstone
fill 323 121 194 323 124 194 minecraft:red_nether_bricks
setblock 323 121 198 minecraft:polished_blackstone
fill 323 121 199 323 124 199 minecraft:red_nether_bricks
setblock 323 121 203 minecraft:polished_blackstone
fill 323 121 204 323 124 204 minecraft:red_nether_bricks
setblock 323 121 208 minecraft:polished_blackstone
fill 323 121 209 323 124 209 minecraft:red_nether_bricks
setblock 323 121 218 minecraft:polished_blackstone
fill 323 121 219 323 122 219 minecraft:red_nether_bricks
setblock 283 122 182 minecraft:polished_blackstone
fill 283 122 183 283 125 183 minecraft:red_nether_bricks
setblock 283 122 187 minecraft:polished_blackstone
fill 283 122 188 283 125 188 minecraft:red_nether_bricks
setblock 283 122 192 minecraft:polished_blackstone
fill 283 122 193 283 122 196 minecraft:red_nether_bricks
setblock 283 122 197 minecraft:polished_blackstone
fill 283 122 198 283 125 198 minecraft:red_nether_bricks
setblock 283 122 202 minecraft:polished_blackstone
fill 283 122 203 283 125 203 minecraft:red_nether_bricks
setblock 283 122 207 minecraft:polished_blackstone
fill 283 122 208 283 125 208 minecraft:red_nether_bricks
setblock 283 122 222 minecraft:polished_blackstone
fill 284 122 182 284 125 182 minecraft:red_nether_bricks
setblock 284 122 186 minecraft:polished_blackstone
fill 284 122 187 284 125 187 minecraft:red_nether_bricks
setblock 284 122 191 minecraft:polished_blackstone
setblock 284 122 196 minecraft:polished_blackstone
fill 284 122 197 284 123 197 minecraft:red_nether_bricks
setblock 284 122 201 minecraft:polished_blackstone
fill 284 122 202 284 125 202 minecraft:red_nether_bricks
setblock 284 122 206 minecraft:polished_blackstone
fill 284 122 222 287 122 222 minecraft:red_nether_bricks
setblock 285 122 185 minecraft:polished_blackstone
setblock 286 122 184 minecraft:polished_blackstone
setblock 287 122 183 minecraft:polished_blackstone
setblock 288 122 182 minecraft:polished_blackstone
fill 288 122 183 288 125 183 minecraft:red_nether_bricks
setblock 288 122 222 minecraft:polished_blackstone
fill 289 122 182 289 125 182 minecraft:red_nether_bricks
fill 289 122 222 289 125 222 minecraft:red_nether_bricks
setblock 292 122 183 minecraft:polished_blackstone
setblock 293 122 182 minecraft:polished_blackstone
fill 293 122 183 294 124 183 minecraft:red_nether_bricks
setblock 293 122 222 minecraft:polished_blackstone
fill 294 122 182 294 125 182 minecraft:red_nether_bricks
fill 294 122 222 294 125 222 minecraft:red_nether_bricks
fill 296 122 221 296 124 221 minecraft:red_nether_bricks
setblock 297 122 183 minecraft:polished_blackstone
setblock 298 122 182 minecraft:polished_blackstone
fill 298 122 183 298 125 183 minecraft:red_nether_bricks
setblock 298 122 222 minecraft:polished_blackstone
fill 299 122 182 299 125 182 minecraft:red_nether_bricks
setblock 299 122 221 minecraft:polished_blackstone
fill 299 122 222 299 125 222 minecraft:red_nether_bricks
setblock 300 122 184 minecraft:red_nether_bricks
setblock 300 122 220 minecraft:polished_blackstone
fill 300 122 221 300 125 221 minecraft:red_nether_bricks
setblock 301 122 184 minecraft:polished_blackstone
fill 301 122 220 301 125 220 minecraft:red_nether_bricks
setblock 302 122 183 minecraft:polished_blackstone
setblock 303 122 182 minecraft:polished_blackstone
fill 303 122 183 303 125 183 minecraft:red_nether_bricks
setblock 303 122 222 minecraft:polished_blackstone
fill 304 122 182 304 125 182 minecraft:red_nether_bricks
setblock 304 122 221 minecraft:polished_blackstone
fill 304 122 222 304 125 222 minecraft:red_nether_bricks
setblock 305 122 220 minecraft:polished_blackstone
fill 305 122 221 305 125 221 minecraft:red_nether_bricks
setblock 308 122 182 minecraft:polished_blackstone
setblock 308 122 222 minecraft:polished_blackstone
fill 309 122 222 311 122 222 minecraft:red_nether_bricks
setblock 318 122 182 minecraft:polished_blackstone
setblock 318 122 222 minecraft:polished_blackstone
fill 319 122 182 319 125 182 minecraft:red_nether_bricks
fill 319 122 222 319 125 222 minecraft:red_nether_bricks
fill 320 122 203 320 123 203 minecraft:red_nether_bricks
setblock 321 122 183 minecraft:red_nether_bricks
setblock 321 122 199 minecraft:polished_blackstone
fill 321 122 200 321 125 200 minecraft:red_nether_bricks
setblock 321 122 204 minecraft:polished_blackstone
fill 321 122 205 321 125 205 minecraft:red_nether_bricks
setblock 322 122 182 minecraft:red_nether_bricks
setblock 322 122 183 minecraft:polished_blackstone
fill 322 122 184 323 123 185 minecraft:red_nether_bricks
setblock 322 122 198 minecraft:polished_blackstone
fill 322 122 199 322 125 199 minecraft:red_nether_bricks
setblock 322 122 203 minecraft:polished_blackstone
fill 322 122 204 322 125 204 minecraft:red_nether_bricks
setblock 322 122 208 minecraft:polished_blackstone
fill 322 122 209 322 124 210 minecraft:red_nether_bricks
setblock 323 122 182 minecraft:polished_blackstone
fill 323 122 183 323 125 183 minecraft:red_nether_bricks
setblock 323 122 186 minecraft:red_nether_bricks
setblock 323 122 187 minecraft:polished_blackstone
fill 323 122 188 323 122 191 minecraft:red_nether_bricks
setblock 323 122 192 minecraft:polished_blackstone
fill 323 122 193 323 125 193 minecraft:red_nether_bricks
setblock 323 122 197 minecraft:polished_blackstone
fill 323 122 198 323 125 198 minecraft:red_nether_bricks
setblock 323 122 202 minecraft:polished_blackstone
fill 323 122 203 323 125 203 minecraft:red_nether_bricks
setblock 323 122 207 minecraft:polished_blackstone
fill 323 122 208 323 125 208 minecraft:red_nether_bricks
setblock 323 122 212 minecraft:polished_blackstone
setblock 323 122 222 minecraft:polished_blackstone
fill 283 123 182 283 126 182 minecraft:red_nether_bricks
setblock 283 123 186 minecraft:polished_blackstone
fill 283 123 187 283 126 187 minecraft:red_nether_bricks
setblock 283 123 191 minecraft:polished_blackstone
fill 283 123 192 283 123 195 minecraft:red_nether_bricks
setblock 283 123 196 minecraft:polished_blackstone
fill 283 123 197 283 126 197 minecraft:red_nether_bricks
setblock 283 123 201 minecraft:polished_blackstone
fill 283 123 202 283 126 202 minecraft:red_nether_bricks
setblock 283 123 206 minecraft:polished_blackstone
fill 283 123 207 283 126 207 minecraft:red_nether_bricks
setblock 283 123 221 minecraft:polished_blackstone
fill 283 123 222 286 123 222 minecraft:red_nether_bricks
setblock 284 123 185 minecraft:polished_blackstone
fill 284 123 186 285 125 186 minecraft:red_nether_bricks
setblock 284 123 190 minecraft:polished_blackstone
fill 284 123 191 284 126 191 minecraft:red_nether_bricks
setblock 284 123 200 minecraft:polished_blackstone
fill 284 123 201 284 126 201 minecraft:red_nether_bricks
setblock 284 123 205 minecraft:polished_blackstone
fill 284 123 206 284 126 206 minecraft:red_nether_bricks
setblock 285 123 184 minecraft:polished_blackstone
fill 285 123 185 285 126 185 minecraft:red_nether_bricks
setblock 286 123 183 minecraft:polished_blackstone
fill 286 123 184 286 126 184 minecraft:red_nether_bricks
setblock 287 123 182 minecraft:polished_blackstone
fill 287 123 183 287 126 183 minecraft:red_nether_bricks
setblock 287 123 222 minecraft:polished_blackstone
fill 288 123 182 288 126 182 minecraft:red_nether_bricks
fill 288 123 222 288 126 222 minecraft:red_nether_bricks
setblock 291 123 183 minecraft:polished_blackstone
setblock 292 123 182 minecraft:polished_blackstone
fill 292 123 183 292 126 183 minecraft:red_nether_bricks
setblock 292 123 222 minecraft:polished_blackstone
fill 293 123 182 293 126 182 minecraft:red_nether_bricks
fill 293 123 222 293 126 222 minecraft:red_nether_bricks
setblock 296 123 183 minecraft:polished_blackstone
setblock 297 123 182 minecraft:polished_blackstone
fill 297 123 183 297 126 183 minecraft:red_nether_bricks
setblock 297 123 222 minecraft:polished_blackstone
fill 298 123 182 298 126 182 minecraft:red_nether_bricks
fill 298 123 184 299 123 184 minecraft:red_nether_bricks
setblock 298 123 221 minecraft:polished_blackstone
fill 298 123 222 298 126 222 minecraft:red_nether_bricks
fill 299 123 221 299 126 221 minecraft:red_nether_bricks
setblock 300 123 184 minecraft:polished_blackstone
fill 300 123 220 300 126 220 minecraft:red_nether_bricks
setblock 301 123 183 minecraft:polished_blackstone
fill 301 123 184 302 125 184 minecraft:red_nether_bricks
setblock 302 123 182 minecraft:polished_blackstone
fill 302 123 183 302 126 183 minecraft:red_nether_bricks
setblock 302 123 222 minecraft:polished_blackstone
fill 303 123 182 303 126 182 minecraft:red_nether_bricks
setblock 303 123 221 minecraft:polished_blackstone
fill 303 123 222 303 126 222 minecraft:red_nether_bricks
setblock 304 123 220 minecraft:polished_blackstone
fill 304 123 221 304 126 221 minecraft:red_nether_bricks
setblock 306 123 183 minecraft:polished_blackstone
setblock 307 123 182 minecraft:polished_blackstone
setblock 307 123 222 minecraft:polished_blackstone
fill 308 123 182 308 125 182 minecraft:red_nether_bricks
fill 308 123 222 310 123 222 minecraft:red_nether_bricks
setblock 317 123 182 minecraft:polished_blackstone
setblock 317 123 222 minecraft:polished_blackstone
fill 318 123 182 318 126 182 minecraft:red_nether_bricks
fill 318 123 222 318 126 222 minecraft:red_nether_bricks
setblock 320 123 183 minecraft:red_nether_bricks
fill 320 123 202 320 124 202 minecraft:red_nether_bricks
setblock 320 123 204 minecraft:polished_blackstone
fill 320 123 205 320 126 205 minecraft:red_nether_bricks
setblock 321 123 183 minecraft:polished_blackstone
setblock 321 123 198 minecraft:polished_blackstone
fill 321 123 199 321 126 199 minecraft:red_nether_bricks
setblock 321 123 203 minecraft:polished_blackstone
fill 321 123 204 321 126 204 minecraft:red_nether_bricks
setblock 321 123 208 minecraft:polished_blackstone
setblock 322 123 182 minecraft:polished_blackstone
fill 322 123 183 322 126 183 minecraft:red_nether_bricks
setblock 322 123 186 minecraft:red_nether_bricks
setblock 322 123 187 minecraft:polished_blackstone
fill 322 123 188 323 125 188 minecraft:red_nether_bricks
setblock 322 123 197 minecraft:polished_blackstone
fill 322 123 198 322 126 198 minecraft:red_nether_bricks
setblock 322 123 202 minecraft:polished_blackstone
fill 322 123 203 322 126 203 minecraft:red_nether_bricks
setblock 322 123 207 minecraft:polished_blackstone
fill 322 123 208 322 126 208 minecraft:red_nether_bricks
setblock 322 123 222 minecraft:polished_blackstone
fill 323 123 182 323 126 182 minecraft:red_nether_bricks
setblock 323 123 186 minecraft:polished_blackstone
fill 323 123 187 323 126 187 minecraft:red_nether_bricks
fill 323 123 189 323 123 190 minecraft:red_nether_bricks
setblock 323 123 191 minecraft:polished_blackstone
fill 323 123 192 323 126 192 minecraft:red_nether_bricks
setblock 323 123 196 minecraft:polished_blackstone
fill 323 123 197 323 126 197 minecraft:red_nether_bricks
setblock 323 123 201 minecraft:polished_blackstone
fill 323 123 202 323 126 202 minecraft:red_nether_bricks
setblock 323 123 206 minecraft:polished_blackstone
fill 323 123 207 323 126 207 minecraft:red_nether_bricks
setblock 323 123 211 minecraft:polished_blackstone
fill 323 123 212 323 126 212 minecraft:red_nether_bricks
setblock 323 123 221 minecraft:polished_blackstone
fill 323 123 222 323 126 222 minecraft:red_nether_bricks
setblock 283 124 185 minecraft:polished_blackstone
fill 283 124 186 283 127 186 minecraft:red_nether_bricks
setblock 283 124 190 minecraft:polished_blackstone
fill 283 124 191 283 124 194 minecraft:red_nether_bricks
setblock 283 124 195 minecraft:polished_blackstone
fill 283 124 196 283 127 196 minecraft:red_nether_bricks
setblock 283 124 200 minecraft:polished_blackstone
fill 283 124 201 283 127 201 minecraft:red_nether_bricks
setblock 283 124 205 minecraft:polished_blackstone
fill 283 124 206 283 127 206 minecraft:red_nether_bricks
setblock 283 124 210 minecraft:polished_blackstone
setblock 283 124 220 minecraft:polished_blackstone
fill 283 124 221 283 126 222 minecraft:red_nether_bricks
setblock 284 124 184 minecraft:polished_blackstone
fill 284 124 185 284 127 185 minecraft:red_nether_bricks
setblock 284 124 189 minecraft:polished_blackstone
fill 284 124 190 284 127 190 minecraft:red_nether_bricks
setblock 284 124 199 minecraft:polished_blackstone
fill 284 124 200 284 125 200 minecraft:red_nether_bricks
setblock 284 124 204 minecraft:polished_blackstone
fill 284 124 205 284 127 205 minecraft:red_nether_bricks
fill 284 124 222 285 124 222 minecraft:red_nether_bricks
setblock 285 124 183 minecraft:polished_blackstone
fill 285 124 184 285 127 184 minecraft:red_nether_bricks
setblock 285 124 187 minecraft:red_nether_bricks
setblock 285 124 192 minecraft:light[level=14]
setblock 285 124 200 minecraft:light[level=14]
setblock 285 124 208 minecraft:light[level=14]
setblock 285 124 216 minecraft:light[level=14]
setblock 286 124 182 minecraft:polished_blackstone
fill 286 124 183 286 127 183 minecraft:red_nether_bricks
setblock 286 124 222 minecraft:polished_blackstone
fill 287 124 182 287 127 182 minecraft:red_nether_bricks
fill 287 124 184 287 125 184 minecraft:red_nether_bricks
fill 287 124 222 287 127 222 minecraft:red_nether_bricks
setblock 290 124 183 minecraft:polished_blackstone
setblock 291 124 182 minecraft:polished_blackstone
fill 291 124 183 291 127 183 minecraft:red_nether_bricks
setblock 291 124 222 minecraft:polished_blackstone
fill 292 124 182 292 127 182 minecraft:red_nether_bricks
fill 292 124 222 292 127 222 minecraft:red_nether_bricks
setblock 293 124 184 minecraft:light[level=14]
setblock 293 124 192 minecraft:light[level=14]
setblock 293 124 200 minecraft:light[level=14]
setblock 293 124 208 minecraft:light[level=14]
setblock 293 124 216 minecraft:light[level=14]
setblock 295 124 182 minecraft:red_nether_bricks
setblock 295 124 183 minecraft:polished_blackstone
setblock 296 124 182 minecraft:polished_blackstone
fill 296 124 183 296 127 183 minecraft:red_nether_bricks
setblock 296 124 222 minecraft:polished_blackstone
fill 297 124 182 297 127 182 minecraft:red_nether_bricks
fill 297 124 184 298 124 184 minecraft:red_nether_bricks
setblock 297 124 221 minecraft:polished_blackstone
fill 297 124 222 297 127 222 minecraft:red_nether_bricks
fill 298 124 221 298 127 221 minecraft:red_nether_bricks
setblock 299 124 184 minecraft:polished_blackstone
fill 299 124 220 299 127 220 minecraft:red_nether_bricks
setblock 300 124 183 minecraft:polished_blackstone
fill 300 124 184 300 127 184 minecraft:red_nether_bricks
setblock 301 124 182 minecraft:polished_blackstone
fill 301 124 183 301 127 183 minecraft:red_nether_bricks
setblock 301 124 192 minecraft:light[level=14]
setblock 301 124 200 minecraft:light[level=14]
setblock 301 124 208 minecraft:light[level=14]
setblock 301 124 216 minecraft:light[level=14]
setblock 301 124 222 minecraft:polished_blackstone
fill 302 124 182 302 127 182 minecraft:red_nether_bricks
setblock 302 124 221 minecraft:polished_blackstone
fill 302 124 222 302 127 222 minecraft:red_nether_bricks
setblock 303 124 220 minecraft:polished_blackstone
fill 303 124 221 303 127 221 minecraft:red_nether_bricks
setblock 305 124 183 minecraft:polished_blackstone
setblock 306 124 182 minecraft:polished_blackstone
setblock 306 124 222 minecraft:polished_blackstone
fill 307 124 182 307 127 182 minecraft:red_nether_bricks
fill 307 124 222 309 125 222 minecraft:red_nether_bricks
setblock 309 124 184 minecraft:light[level=14]
setblock 309 124 192 minecraft:light[level=14]
setblock 309 124 200 minecraft:light[level=14]
setblock 309 124 208 minecraft:light[level=14]
setblock 309 124 216 minecraft:light[level=14]
setblock 316 124 182 minecraft:polished_blackstone
fill 317 124 182 317 127 182 minecraft:red_nether_bricks
setblock 317 124 184 minecraft:light[level=14]
setblock 317 124 192 minecraft:light[level=14]
setblock 317 124 200 minecraft:light[level=14]
setblock 317 124 208 minecraft:light[level=14]
setblock 317 124 216 minecraft:light[level=14]
fill 317 124 222 317 127 222 minecraft:red_nether_bricks
setblock 319 124 183 minecraft:red_nether_bricks
setblock 320 124 183 minecraft:polished_blackstone
fill 320 124 201 320 125 201 minecraft:red_nether_bricks
setblock 320 124 203 minecraft:polished_blackstone
fill 320 124 204 320 127 204 minecraft:red_nether_bricks
fill 320 124 206 321 124 206 minecraft:red_nether_bricks
setblock 321 124 182 minecraft:polished_blackstone
fill 321 124 183 321 127 183 minecraft:red_nether_bricks
fill 321 124 198 321 127 198 minecraft:red_nether_bricks
setblock 321 124 202 minecraft:polished_blackstone
fill 321 124 203 321 127 203 minecraft:red_nether_bricks
setblock 321 124 207 minecraft:polished_blackstone
fill 321 124 208 321 126 209 minecraft:red_nether_bricks
setblock 321 124 222 minecraft:polished_blackstone
fill 322 124 182 322 127 182 minecraft:red_nether_bricks
fill 322 124 184 322 124 185 minecraft:red_nether_bricks
setblock 322 124 186 minecraft:polished_blackstone
fill 322 124 187 322 127 187 minecraft:red_nether_bricks
fill 322 124 189 322 124 190 minecraft:red_nether_bricks
setblock 322 124 191 minecraft:polished_blackstone
fill 322 124 192 322 125 194 minecraft:red_nether_bricks
setblock 322 124 196 minecraft:polished_blackstone
fill 322 124 197 322 127 197 minecraft:red_nether_bricks
setblock 322 124 201 minecraft:polished_blackstone
fill 322 124 202 322 127 202 minecraft:red_nether_bricks
setblock 322 124 206 minecraft:polished_blackstone
fill 322 124 207 322 127 207 minecraft:red_nether_bricks
setblock 322 124 211 minecraft:polished_blackstone
fill 322 124 222 322 127 222 minecraft:red_nether_bricks
setblock 323 124 184 minecraft:red_nether_bricks
setblock 323 124 185 minecraft:polished_blackstone
fill 323 124 186 323 127 186 minecraft:red_nether_bricks
setblock 323 124 189 minecraft:red_nether_bricks
setblock 323 124 190 minecraft:polished_blackstone
fill 323 124 191 323 127 191 minecraft:red_nether_bricks
setblock 323 124 195 minecraft:polished_blackstone
fill 323 124 196 323 127 196 minecraft:red_nether_bricks
setblock 323 124 200 minecraft:polished_blackstone
fill 323 124 201 323 127 201 minecraft:red_nether_bricks
setblock 323 124 205 minecraft:polished_blackstone
fill 323 124 206 323 127 206 minecraft:red_nether_bricks
setblock 323 124 210 minecraft:polished_blackstone
fill 323 124 211 323 127 211 minecraft:red_nether_bricks
fill 323 124 213 323 125 213 minecraft:red_nether_bricks
setblock 323 124 220 minecraft:polished_blackstone
fill 323 124 221 323 126 221 minecraft:red_nether_bricks
setblock 283 125 184 minecraft:polished_blackstone
fill 283 125 185 283 128 185 minecraft:red_nether_bricks
setblock 283 125 189 minecraft:polished_blackstone
fill 283 125 190 283 125 193 minecraft:red_nether_bricks
setblock 283 125 194 minecraft:polished_blackstone
fill 283 125 195 283 128 195 minecraft:red_nether_bricks
setblock 283 125 199 minecraft:polished_blackstone
fill 283 125 200 283 128 200 minecraft:red_nether_bricks
setblock 283 125 204 minecraft:polished_blackstone
fill 283 125 205 283 128 205 minecraft:red_nether_bricks
setblock 283 125 209 minecraft:polished_blackstone
fill 283 125 210 283 127 211 minecraft:red_nether_bricks
fill 283 125 220 283 127 220 minecraft:red_nether_bricks
setblock 284 125 183 minecraft:polished_blackstone
fill 284 125 184 284 128 184 minecraft:red_nether_bricks
setblock 284 125 188 minecraft:polished_blackstone
fill 284 125 189 284 128 189 minecraft:red_nether_bricks
setblock 284 125 192 minecraft:red_nether_bricks
setblock 284 125 203 minecraft:polished_blackstone
fill 284 125 204 284 127 204 minecraft:red_nether_bricks
setblock 284 125 207 minecraft:red_nether_bricks
setblock 284 125 222 minecraft:red_nether_bricks
setblock 285 125 182 minecraft:polished_blackstone
fill 285 125 183 285 128 183 minecraft:red_nether_bricks
setblock 285 125 187 minecraft:polished_blackstone
fill 285 125 188 285 128 188 minecraft:red_nether_bricks
setblock 285 125 222 minecraft:polished_blackstone
fill 286 125 182 286 128 182 minecraft:red_nether_bricks
fill 286 125 222 286 128 222 minecraft:red_nether_bricks
setblock 289 125 183 minecraft:polished_blackstone
setblock 290 125 182 minecraft:polished_blackstone
fill 290 125 183 290 128 183 minecraft:red_nether_bricks
setblock 290 125 222 minecraft:polished_blackstone
fill 291 125 182 291 128 182 minecraft:red_nether_bricks
fill 291 125 222 291 128 222 minecraft:red_nether_bricks
setblock 293 125 183 minecraft:red_nether_bricks
setblock 294 125 183 minecraft:polished_blackstone
setblock 295 125 182 minecraft:polished_blackstone
fill 295 125 183 295 127 184 minecraft:red_nether_bricks
setblock 295 125 221 minecraft:red_nether_bricks
setblock 295 125 222 minecraft:polished_blackstone
fill 296 125 182 296 128 182 minecraft:red_nether_bricks
fill 296 125 184 297 125 184 minecraft:red_nether_bricks
setblock 296 125 221 minecraft:polished_blackstone
fill 296 125 222 296 128 222 minecraft:red_nether_bricks
fill 297 125 221 297 128 221 minecraft:red_nether_bricks
setblock 298 125 184 minecraft:polished_blackstone
setblock 299 125 183 minecraft:polished_blackstone
fill 299 125 184 299 128 184 minecraft:red_nether_bricks
setblock 300 125 182 minecraft:polished_blackstone
fill 300 125 183 300 128 183 minecraft:red_nether_bricks
setblock 300 125 222 minecraft:polished_blackstone
fill 301 125 182 301 128 182 minecraft:red_nether_bricks
setblock 301 125 221 minecraft:polished_blackstone
fill 301 125 222 301 128 222 minecraft:red_nether_bricks
setblock 302 125 220 minecraft:polished_blackstone
fill 302 125 221 302 128 221 minecraft:red_nether_bricks
setblock 303 125 184 minecraft:polished_blackstone
setblock 304 125 183 minecraft:polished_blackstone
setblock 305 125 182 minecraft:polished_blackstone
fill 305 125 183 305 127 183 minecraft:red_nether_bricks
setblock 305 125 222 minecraft:polished_blackstone
fill 306 125 182 306 128 182 minecraft:red_nether_bricks
setblock 306 125 221 minecraft:polished_blackstone
fill 306 125 222 306 128 222 minecraft:red_nether_bricks
setblock 311 125 183 minecraft:polished_blackstone
setblock 311 125 185 minecraft:polished_blackstone
setblock 313 125 183 minecraft:polished_blackstone
setblock 313 125 185 minecraft:polished_blackstone
setblock 315 125 182 minecraft:polished_blackstone
fill 316 125 182 316 128 182 minecraft:red_nether_bricks
fill 316 125 222 316 128 222 minecraft:red_nether_bricks
fill 317 125 183 318 125 183 minecraft:red_nether_bricks
setblock 319 125 183 minecraft:polished_blackstone
setblock 320 125 182 minecraft:polished_blackstone
fill 320 125 183 320 127 184 minecraft:red_nether_bricks
setblock 320 125 202 minecraft:polished_blackstone
fill 320 125 203 320 128 203 minecraft:red_nether_bricks
setblock 320 125 206 minecraft:red_nether_bricks
setblock 320 125 207 minecraft:polished_blackstone
setblock 320 125 222 minecraft:polished_blackstone
fill 321 125 182 321 128 182 minecraft:red_nether_bricks
fill 321 125 184 321 125 185 minecraft:red_nether_bricks
setblock 321 125 186 minecraft:polished_blackstone
fill 321 125 187 321 128 187 minecraft:red_nether_bricks
setblock 321 125 201 minecraft:polished_blackstone
fill 321 125 202 321 128 202 minecraft:red_nether_bricks
setblock 321 125 206 minecraft:polished_blackstone
fill 321 125 207 321 128 207 minecraft:red_nether_bricks
setblock 321 125 210 minecraft:red_nether_bricks
fill 321 125 222 321 128 222 minecraft:red_nether_bricks
setblock 322 125 184 minecraft:red_nether_bricks
setblock 322 125 185 minecraft:polished_blackstone
fill 322 125 186 322 128 186 minecraft:red_nether_bricks
setblock 322 125 189 minecraft:red_nether_bricks
setblock 322 125 190 minecraft:polished_blackstone
fill 322 125 191 322 128 191 minecraft:red_nether_bricks
setblock 322 125 195 minecraft:polished_blackstone
fill 322 125 196 322 128 196 minecraft:red_nether_bricks
setblock 322 125 200 minecraft:polished_blackstone
fill 322 125 201 322 128 201 minecraft:red_nether_bricks
setblock 322 125 205 minecraft:polished_blackstone
fill 322 125 206 322 128 206 minecraft:red_nether_bricks
setblock 322 125 209 minecraft:red_nether_bricks
setblock 322 125 210 minecraft:polished_blackstone
schedule function dropper:buildpart/42_6 1t
