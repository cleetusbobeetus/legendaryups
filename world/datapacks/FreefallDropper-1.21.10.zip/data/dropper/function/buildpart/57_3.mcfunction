setblock 451 184 254 minecraft:cobbled_deepslate
fill 451 184 255 451 186 255 minecraft:tuff
setblock 451 184 256 minecraft:andesite
setblock 451 184 257 minecraft:tuff
setblock 452 184 244 minecraft:tuff
setblock 452 184 245 minecraft:andesite
setblock 452 184 247 minecraft:cobbled_deepslate
fill 452 184 248 452 186 248 minecraft:tuff
setblock 452 184 249 minecraft:andesite
setblock 452 184 250 minecraft:tuff
fill 452 184 252 453 185 252 minecraft:tuff
setblock 452 184 253 minecraft:andesite
setblock 452 184 256 minecraft:cobbled_deepslate
fill 453 184 245 453 185 245 minecraft:tuff
setblock 453 184 246 minecraft:andesite
setblock 453 184 249 minecraft:cobbled_deepslate
setblock 453 184 250 minecraft:andesite
fill 453 184 253 453 186 253 minecraft:tuff
setblock 453 184 254 minecraft:andesite
fill 453 184 256 453 185 256 minecraft:tuff
setblock 454 184 231 minecraft:light[level=12]
setblock 454 184 238 minecraft:light[level=12]
setblock 454 184 245 minecraft:light[level=12]
setblock 454 184 246 minecraft:tuff
setblock 454 184 247 minecraft:andesite
fill 454 184 250 454 186 250 minecraft:tuff
setblock 454 184 251 minecraft:cobbled_deepslate
fill 454 184 254 454 185 254 minecraft:tuff
setblock 454 184 259 minecraft:light[level=12]
setblock 454 184 266 minecraft:light[level=12]
setblock 455 184 248 minecraft:andesite
fill 455 184 251 455 186 251 minecraft:tuff
setblock 455 184 252 minecraft:andesite
setblock 457 184 228 minecraft:white_concrete
fill 459 184 270 459 211 270 minecraft:black_concrete
setblock 461 184 231 minecraft:light[level=12]
setblock 461 184 238 minecraft:light[level=12]
setblock 461 184 245 minecraft:light[level=12]
setblock 461 184 252 minecraft:light[level=12]
setblock 461 184 259 minecraft:light[level=12]
setblock 461 184 266 minecraft:light[level=12]
setblock 465 184 247 minecraft:black_concrete
setblock 423 185 237 minecraft:white_concrete
setblock 423 185 247 minecraft:white_concrete
setblock 426 185 231 minecraft:light[level=15]
setblock 426 185 239 minecraft:light[level=15]
setblock 426 185 247 minecraft:light[level=15]
setblock 426 185 255 minecraft:light[level=15]
setblock 426 185 263 minecraft:light[level=15]
setblock 428 185 228 minecraft:black_concrete
setblock 433 185 248 minecraft:tuff
setblock 434 185 231 minecraft:light[level=15]
setblock 434 185 239 minecraft:light[level=15]
fill 434 185 247 434 186 247 minecraft:tuff
setblock 434 185 248 minecraft:andesite
fill 434 185 251 434 186 251 minecraft:tuff
setblock 434 185 252 minecraft:andesite
setblock 434 185 253 minecraft:cobbled_deepslate
fill 434 185 255 434 186 255 minecraft:tuff
setblock 434 185 256 minecraft:andesite
setblock 434 185 263 minecraft:light[level=15]
setblock 435 185 244 minecraft:tuff
setblock 435 185 245 minecraft:andesite
setblock 435 185 246 minecraft:cobbled_deepslate
fill 435 185 248 435 187 248 minecraft:tuff
setblock 435 185 249 minecraft:andesite
setblock 435 185 252 minecraft:tuff
setblock 435 185 253 minecraft:andesite
setblock 435 185 255 minecraft:cobbled_deepslate
fill 435 185 256 435 187 256 minecraft:tuff
setblock 435 185 257 minecraft:andesite
setblock 436 185 242 minecraft:andesite
setblock 436 185 245 minecraft:tuff
setblock 436 185 246 minecraft:andesite
setblock 436 185 248 minecraft:cobbled_deepslate
fill 436 185 249 436 187 249 minecraft:tuff
setblock 436 185 250 minecraft:andesite
setblock 436 185 251 minecraft:tuff
fill 436 185 253 437 186 253 minecraft:tuff
setblock 436 185 254 minecraft:andesite
setblock 436 185 257 minecraft:cobbled_deepslate
setblock 436 185 258 minecraft:andesite
setblock 437 185 241 minecraft:cobbled_deepslate
fill 437 185 242 439 185 242 minecraft:tuff
setblock 437 185 243 minecraft:andesite
setblock 437 185 244 minecraft:tuff
fill 437 185 246 438 186 246 minecraft:tuff
setblock 437 185 247 minecraft:andesite
setblock 437 185 248 minecraft:tuff
setblock 437 185 250 minecraft:cobbled_deepslate
setblock 437 185 251 minecraft:andesite
setblock 437 185 252 minecraft:tuff
fill 437 185 254 437 187 254 minecraft:tuff
setblock 437 185 255 minecraft:andesite
fill 437 185 258 437 187 258 minecraft:tuff
setblock 437 185 259 minecraft:cobbled_deepslate
setblock 438 185 240 minecraft:andesite
setblock 438 185 241 minecraft:tuff
setblock 438 185 243 minecraft:cobbled_deepslate
setblock 438 185 244 minecraft:andesite
setblock 438 185 245 minecraft:tuff
fill 438 185 247 438 187 247 minecraft:tuff
setblock 438 185 248 minecraft:andesite
fill 438 185 251 438 187 251 minecraft:tuff
setblock 438 185 252 minecraft:cobbled_deepslate
fill 438 185 255 438 186 255 minecraft:tuff
setblock 438 185 256 minecraft:andesite
fill 438 185 259 438 186 259 minecraft:tuff
fill 439 185 239 439 186 240 minecraft:tuff
setblock 439 185 241 minecraft:andesite
fill 439 185 244 439 187 244 minecraft:tuff
setblock 439 185 245 minecraft:cobbled_deepslate
fill 439 185 248 439 186 248 minecraft:tuff
setblock 439 185 249 minecraft:andesite
fill 439 185 252 439 187 252 minecraft:tuff
setblock 439 185 253 minecraft:andesite
setblock 439 185 254 minecraft:cobbled_deepslate
fill 439 185 256 439 187 256 minecraft:tuff
setblock 439 185 257 minecraft:andesite
setblock 440 185 239 minecraft:tuff
fill 440 185 241 440 186 241 minecraft:tuff
setblock 440 185 242 minecraft:andesite
fill 440 185 245 440 187 245 minecraft:tuff
setblock 440 185 246 minecraft:andesite
setblock 440 185 247 minecraft:cobbled_deepslate
fill 440 185 249 440 187 249 minecraft:tuff
setblock 440 185 250 minecraft:andesite
setblock 440 185 256 minecraft:cobbled_deepslate
fill 440 185 257 440 187 257 minecraft:tuff
setblock 440 185 258 minecraft:andesite
fill 440 185 259 440 185 260 minecraft:tuff
fill 441 185 238 441 186 238 minecraft:tuff
setblock 441 185 239 minecraft:andesite
setblock 441 185 240 minecraft:cobbled_deepslate
fill 441 185 242 441 187 242 minecraft:tuff
setblock 441 185 243 minecraft:andesite
setblock 441 185 246 minecraft:tuff
setblock 441 185 247 minecraft:andesite
setblock 441 185 249 minecraft:cobbled_deepslate
fill 441 185 250 441 187 250 minecraft:tuff
setblock 441 185 258 minecraft:cobbled_deepslate
setblock 441 185 259 minecraft:andesite
setblock 441 185 260 minecraft:tuff
setblock 442 185 231 minecraft:light[level=15]
fill 442 185 239 444 185 239 minecraft:tuff
setblock 442 185 240 minecraft:andesite
setblock 442 185 242 minecraft:cobbled_deepslate
fill 442 185 243 442 187 243 minecraft:tuff
setblock 442 185 244 minecraft:andesite
setblock 442 185 245 minecraft:tuff
fill 442 185 247 443 186 247 minecraft:tuff
setblock 442 185 248 minecraft:andesite
setblock 442 185 249 minecraft:tuff
fill 442 185 259 442 187 259 minecraft:tuff
setblock 442 185 260 minecraft:cobbled_deepslate
setblock 442 185 263 minecraft:light[level=15]
setblock 443 185 238 minecraft:tuff
fill 443 185 240 445 185 240 minecraft:tuff
setblock 443 185 241 minecraft:andesite
setblock 443 185 244 minecraft:cobbled_deepslate
setblock 443 185 245 minecraft:andesite
setblock 443 185 246 minecraft:tuff
fill 443 185 248 443 187 248 minecraft:tuff
setblock 443 185 249 minecraft:andesite
setblock 444 185 238 minecraft:andesite
fill 444 185 241 444 187 241 minecraft:tuff
setblock 444 185 242 minecraft:andesite
fill 444 185 245 444 187 245 minecraft:tuff
setblock 444 185 246 minecraft:cobbled_deepslate
fill 444 185 249 444 186 249 minecraft:tuff
fill 445 185 238 445 187 238 minecraft:tuff
setblock 445 185 239 minecraft:cobbled_deepslate
fill 445 185 242 445 186 242 minecraft:tuff
setblock 445 185 243 minecraft:andesite
fill 445 185 246 445 187 246 minecraft:tuff
setblock 445 185 247 minecraft:andesite
setblock 445 185 248 minecraft:cobbled_deepslate
setblock 445 185 259 minecraft:andesite
fill 446 185 239 446 187 239 minecraft:tuff
setblock 446 185 240 minecraft:andesite
setblock 446 185 241 minecraft:cobbled_deepslate
fill 446 185 243 446 187 243 minecraft:tuff
setblock 446 185 244 minecraft:andesite
setblock 446 185 247 minecraft:tuff
setblock 446 185 248 minecraft:andesite
setblock 446 185 250 minecraft:cobbled_deepslate
fill 446 185 258 447 185 258 minecraft:tuff
setblock 446 185 259 minecraft:cobbled_deepslate
setblock 447 185 240 minecraft:tuff
setblock 447 185 241 minecraft:andesite
setblock 447 185 243 minecraft:cobbled_deepslate
fill 447 185 244 449 185 244 minecraft:tuff
setblock 447 185 245 minecraft:andesite
setblock 447 185 246 minecraft:tuff
fill 447 185 248 448 186 248 minecraft:tuff
setblock 447 185 249 minecraft:andesite
setblock 448 185 239 minecraft:tuff
fill 448 185 241 449 186 241 minecraft:tuff
setblock 448 185 242 minecraft:andesite
setblock 448 185 245 minecraft:cobbled_deepslate
setblock 448 185 246 minecraft:andesite
setblock 448 185 247 minecraft:tuff
fill 448 185 249 448 187 249 minecraft:tuff
setblock 448 185 250 minecraft:andesite
fill 448 185 251 448 185 252 minecraft:tuff
fill 448 185 256 448 186 257 minecraft:tuff
setblock 448 185 258 minecraft:andesite
setblock 449 185 240 minecraft:tuff
fill 449 185 242 449 187 242 minecraft:tuff
setblock 449 185 243 minecraft:andesite
fill 449 185 246 449 187 246 minecraft:tuff
setblock 449 185 247 minecraft:cobbled_deepslate
fill 449 185 250 449 186 250 minecraft:tuff
setblock 449 185 251 minecraft:andesite
fill 449 185 254 449 187 254 minecraft:tuff
setblock 449 185 255 minecraft:andesite
setblock 449 185 256 minecraft:cobbled_deepslate
fill 449 185 258 449 186 258 minecraft:tuff
setblock 450 185 231 minecraft:light[level=15]
setblock 450 185 239 minecraft:light[level=15]
fill 450 185 243 450 186 243 minecraft:tuff
setblock 450 185 244 minecraft:andesite
fill 450 185 247 450 187 247 minecraft:tuff
setblock 450 185 248 minecraft:andesite
setblock 450 185 249 minecraft:cobbled_deepslate
fill 450 185 251 450 187 251 minecraft:tuff
setblock 450 185 252 minecraft:andesite
setblock 450 185 255 minecraft:tuff
setblock 450 185 256 minecraft:andesite
setblock 450 185 257 minecraft:tuff
setblock 450 185 258 minecraft:cobbled_deepslate
setblock 450 185 263 minecraft:light[level=15]
setblock 451 185 242 minecraft:cobbled_deepslate
fill 451 185 244 451 187 244 minecraft:tuff
setblock 451 185 245 minecraft:andesite
setblock 451 185 248 minecraft:tuff
setblock 451 185 249 minecraft:andesite
setblock 451 185 251 minecraft:cobbled_deepslate
fill 451 185 252 451 187 252 minecraft:tuff
setblock 451 185 253 minecraft:andesite
setblock 451 185 254 minecraft:tuff
fill 451 185 256 452 186 256 minecraft:tuff
setblock 451 185 257 minecraft:andesite
setblock 452 185 244 minecraft:cobbled_deepslate
fill 452 185 245 452 186 245 minecraft:tuff
setblock 452 185 246 minecraft:andesite
setblock 452 185 247 minecraft:tuff
fill 452 185 249 453 186 249 minecraft:tuff
setblock 452 185 250 minecraft:andesite
setblock 452 185 251 minecraft:tuff
setblock 452 185 253 minecraft:cobbled_deepslate
setblock 452 185 254 minecraft:andesite
setblock 452 185 255 minecraft:tuff
setblock 453 185 246 minecraft:cobbled_deepslate
setblock 453 185 247 minecraft:andesite
setblock 453 185 248 minecraft:tuff
fill 453 185 250 453 187 250 minecraft:tuff
setblock 453 185 251 minecraft:andesite
fill 453 185 254 453 187 254 minecraft:tuff
setblock 453 185 255 minecraft:cobbled_deepslate
setblock 454 185 247 minecraft:tuff
setblock 454 185 248 minecraft:cobbled_deepslate
fill 454 185 251 454 186 251 minecraft:tuff
setblock 454 185 252 minecraft:andesite
setblock 455 185 249 minecraft:andesite
setblock 455 185 250 minecraft:cobbled_deepslate
setblock 455 185 252 minecraft:tuff
fill 457 185 228 457 188 228 minecraft:black_concrete
setblock 458 185 231 minecraft:light[level=15]
setblock 458 185 239 minecraft:light[level=15]
setblock 458 185 247 minecraft:light[level=15]
setblock 458 185 255 minecraft:light[level=15]
setblock 458 185 263 minecraft:light[level=15]
setblock 465 185 247 minecraft:pearlescent_froglight
fill 423 186 237 423 199 237 minecraft:black_concrete
fill 423 186 247 423 209 247 minecraft:black_concrete
setblock 428 186 228 minecraft:blue_concrete
setblock 431 186 270 minecraft:pearlescent_froglight
fill 434 186 248 434 187 248 minecraft:tuff
setblock 434 186 252 minecraft:tuff
setblock 434 186 253 minecraft:andesite
fill 435 186 245 435 187 245 minecraft:tuff
setblock 435 186 246 minecraft:andesite
setblock 435 186 249 minecraft:tuff
setblock 435 186 250 minecraft:andesite
setblock 435 186 252 minecraft:cobbled_deepslate
fill 435 186 253 435 187 253 minecraft:tuff
setblock 435 186 254 minecraft:andesite
setblock 435 186 255 minecraft:tuff
fill 435 186 257 436 186 257 minecraft:tuff
setblock 436 186 243 minecraft:andesite
setblock 436 186 245 minecraft:cobbled_deepslate
fill 436 186 246 436 188 246 minecraft:tuff
setblock 436 186 247 minecraft:andesite
setblock 436 186 248 minecraft:tuff
fill 436 186 250 437 187 250 minecraft:tuff
setblock 436 186 251 minecraft:andesite
setblock 436 186 254 minecraft:cobbled_deepslate
setblock 436 186 255 minecraft:andesite
setblock 436 186 256 minecraft:tuff
setblock 436 186 258 minecraft:tuff
fill 437 186 241 437 186 243 minecraft:tuff
setblock 437 186 244 minecraft:andesite
setblock 437 186 247 minecraft:cobbled_deepslate
setblock 437 186 248 minecraft:andesite
setblock 437 186 249 minecraft:tuff
fill 437 186 251 437 188 251 minecraft:tuff
setblock 437 186 252 minecraft:andesite
fill 437 186 255 437 188 255 minecraft:tuff
setblock 437 186 256 minecraft:cobbled_deepslate
setblock 438 186 240 minecraft:cobbled_deepslate
setblock 438 186 241 minecraft:andesite
fill 438 186 242 438 186 244 minecraft:tuff
setblock 438 186 245 minecraft:andesite
fill 438 186 248 438 188 248 minecraft:tuff
setblock 438 186 249 minecraft:cobbled_deepslate
fill 438 186 252 438 187 252 minecraft:tuff
setblock 438 186 253 minecraft:andesite
fill 438 186 256 438 188 256 minecraft:tuff
setblock 438 186 257 minecraft:andesite
setblock 438 186 258 minecraft:cobbled_deepslate
fill 439 186 241 439 188 241 minecraft:tuff
setblock 439 186 242 minecraft:cobbled_deepslate
fill 439 186 245 439 187 245 minecraft:tuff
setblock 439 186 246 minecraft:andesite
fill 439 186 249 439 188 249 minecraft:tuff
setblock 439 186 250 minecraft:andesite
setblock 439 186 251 minecraft:cobbled_deepslate
fill 439 186 253 439 188 253 minecraft:tuff
setblock 439 186 254 minecraft:andesite
setblock 439 186 257 minecraft:tuff
setblock 439 186 258 minecraft:andesite
setblock 440 186 239 minecraft:andesite
fill 440 186 242 440 188 242 minecraft:tuff
setblock 440 186 243 minecraft:andesite
setblock 440 186 244 minecraft:cobbled_deepslate
fill 440 186 246 440 188 246 minecraft:tuff
setblock 440 186 247 minecraft:andesite
setblock 440 186 250 minecraft:tuff
setblock 440 186 251 minecraft:andesite
setblock 440 186 256 minecraft:tuff
fill 440 186 258 441 187 258 minecraft:tuff
setblock 440 186 259 minecraft:andesite
fill 441 186 239 441 188 239 minecraft:tuff
setblock 441 186 240 minecraft:andesite
setblock 441 186 243 minecraft:tuff
setblock 441 186 244 minecraft:andesite
setblock 441 186 246 minecraft:cobbled_deepslate
fill 441 186 247 441 188 247 minecraft:tuff
setblock 441 186 248 minecraft:andesite
setblock 441 186 249 minecraft:tuff
fill 441 186 259 441 187 259 minecraft:tuff
setblock 442 186 239 minecraft:cobbled_deepslate
fill 442 186 240 444 186 240 minecraft:tuff
setblock 442 186 241 minecraft:andesite
setblock 442 186 242 minecraft:tuff
fill 442 186 244 443 187 244 minecraft:tuff
setblock 442 186 245 minecraft:andesite
setblock 442 186 248 minecraft:cobbled_deepslate
setblock 442 186 249 minecraft:andesite
setblock 443 186 238 minecraft:andesite
setblock 443 186 239 minecraft:tuff
setblock 443 186 241 minecraft:cobbled_deepslate
setblock 443 186 242 minecraft:andesite
setblock 443 186 243 minecraft:tuff
fill 443 186 245 443 188 245 minecraft:tuff
setblock 443 186 246 minecraft:andesite
fill 443 186 249 443 188 249 minecraft:tuff
setblock 443 186 259 minecraft:cobbled_deepslate
fill 444 186 238 444 187 238 minecraft:tuff
setblock 444 186 239 minecraft:andesite
fill 444 186 242 444 188 242 minecraft:tuff
setblock 444 186 243 minecraft:cobbled_deepslate
fill 444 186 246 444 187 246 minecraft:tuff
setblock 444 186 247 minecraft:andesite
setblock 444 186 259 minecraft:andesite
fill 445 186 239 445 187 239 minecraft:tuff
setblock 445 186 240 minecraft:andesite
fill 445 186 243 445 188 243 minecraft:tuff
setblock 445 186 244 minecraft:andesite
setblock 445 186 245 minecraft:cobbled_deepslate
fill 445 186 247 445 188 247 minecraft:tuff
setblock 445 186 248 minecraft:andesite
fill 445 186 259 446 186 259 minecraft:tuff
setblock 446 186 238 minecraft:cobbled_deepslate
fill 446 186 240 446 188 240 minecraft:tuff
setblock 446 186 241 minecraft:andesite
fill 446 186 244 448 186 244 minecraft:tuff
setblock 446 186 245 minecraft:andesite
setblock 446 186 247 minecraft:cobbled_deepslate
fill 446 186 248 446 188 248 minecraft:tuff
setblock 446 186 249 minecraft:andesite
setblock 446 186 250 minecraft:tuff
setblock 446 186 258 minecraft:tuff
setblock 447 186 240 minecraft:cobbled_deepslate
fill 447 186 241 447 188 241 minecraft:tuff
setblock 447 186 242 minecraft:andesite
setblock 447 186 243 minecraft:tuff
fill 447 186 245 448 187 245 minecraft:tuff
setblock 447 186 246 minecraft:andesite
setblock 447 186 249 minecraft:cobbled_deepslate
setblock 447 186 250 minecraft:andesite
setblock 447 186 258 minecraft:cobbled_deepslate
setblock 448 186 239 minecraft:andesite
setblock 448 186 242 minecraft:cobbled_deepslate
setblock 448 186 243 minecraft:andesite
fill 448 186 246 448 188 246 minecraft:tuff
setblock 448 186 247 minecraft:andesite
fill 448 186 250 448 188 250 minecraft:tuff
setblock 448 186 251 minecraft:cobbled_deepslate
setblock 448 186 252 minecraft:tuff
fill 448 186 258 448 187 258 minecraft:tuff
setblock 449 186 240 minecraft:andesite
fill 449 186 243 449 188 243 minecraft:tuff
setblock 449 186 244 minecraft:cobbled_deepslate
fill 449 186 247 449 187 247 minecraft:tuff
setblock 449 186 248 minecraft:andesite
fill 449 186 251 449 188 251 minecraft:tuff
setblock 449 186 252 minecraft:andesite
setblock 449 186 253 minecraft:cobbled_deepslate
fill 449 186 255 449 188 255 minecraft:tuff
setblock 449 186 256 minecraft:andesite
fill 450 186 244 450 188 244 minecraft:tuff
setblock 450 186 245 minecraft:andesite
setblock 450 186 246 minecraft:cobbled_deepslate
fill 450 186 248 450 188 248 minecraft:tuff
setblock 450 186 249 minecraft:andesite
setblock 450 186 252 minecraft:tuff
setblock 450 186 253 minecraft:andesite
setblock 450 186 255 minecraft:cobbled_deepslate
fill 450 186 256 450 188 256 minecraft:tuff
setblock 450 186 257 minecraft:andesite
setblock 451 186 245 minecraft:tuff
setblock 451 186 246 minecraft:andesite
setblock 451 186 248 minecraft:cobbled_deepslate
fill 451 186 249 451 188 249 minecraft:tuff
setblock 451 186 250 minecraft:andesite
setblock 451 186 251 minecraft:tuff
fill 451 186 253 452 187 253 minecraft:tuff
setblock 451 186 254 minecraft:andesite
setblock 451 186 257 minecraft:cobbled_deepslate
fill 452 186 246 453 186 246 minecraft:tuff
setblock 452 186 247 minecraft:andesite
setblock 452 186 250 minecraft:cobbled_deepslate
setblock 452 186 251 minecraft:andesite
setblock 452 186 252 minecraft:tuff
fill 452 186 254 452 188 254 minecraft:tuff
setblock 452 186 255 minecraft:andesite
fill 453 186 247 453 187 247 minecraft:tuff
setblock 453 186 248 minecraft:andesite
fill 453 186 251 453 188 251 minecraft:tuff
setblock 453 186 252 minecraft:cobbled_deepslate
fill 453 186 255 453 187 255 minecraft:tuff
setblock 454 186 248 minecraft:tuff
setblock 454 186 249 minecraft:andesite
fill 454 186 252 454 187 252 minecraft:tuff
setblock 454 186 253 minecraft:andesite
setblock 454 186 254 minecraft:cobbled_deepslate
setblock 458 186 270 minecraft:sea_lantern
setblock 461 186 270 minecraft:ochre_froglight
setblock 465 186 233 minecraft:magenta_terracotta
setblock 465 186 241 minecraft:pearlescent_froglight
fill 465 186 247 465 232 247 minecraft:black_concrete
setblock 423 187 236 minecraft:pearlescent_froglight
setblock 423 187 266 minecraft:ochre_froglight
fill 428 187 228 428 199 228 minecraft:black_concrete
fill 431 187 270 431 218 270 minecraft:black_concrete
setblock 434 187 247 minecraft:cobbled_deepslate
setblock 435 187 246 minecraft:tuff
setblock 435 187 247 minecraft:andesite
setblock 435 187 249 minecraft:cobbled_deepslate
setblock 435 187 250 minecraft:tuff
setblock 435 187 251 minecraft:andesite
setblock 435 187 252 minecraft:tuff
fill 435 187 254 436 187 254 minecraft:tuff
setblock 435 187 255 minecraft:andesite
setblock 436 187 244 minecraft:andesite
setblock 436 187 245 minecraft:tuff
fill 436 187 247 437 188 247 minecraft:tuff
setblock 436 187 248 minecraft:andesite
setblock 436 187 251 minecraft:cobbled_deepslate
setblock 436 187 252 minecraft:andesite
setblock 436 187 253 minecraft:tuff
fill 436 187 255 436 188 255 minecraft:tuff
setblock 436 187 256 minecraft:andesite
setblock 436 187 257 minecraft:tuff
fill 437 187 242 437 187 243 minecraft:tuff
setblock 437 187 244 minecraft:cobbled_deepslate
setblock 437 187 245 minecraft:andesite
setblock 437 187 246 minecraft:tuff
fill 437 187 248 437 189 248 minecraft:tuff
setblock 437 187 249 minecraft:andesite
fill 437 187 252 437 189 252 minecraft:tuff
setblock 437 187 253 minecraft:cobbled_deepslate
fill 437 187 256 437 188 256 minecraft:tuff
setblock 437 187 257 minecraft:andesite
setblock 438 187 241 minecraft:tuff
setblock 438 187 242 minecraft:andesite
fill 438 187 243 438 187 245 minecraft:tuff
setblock 438 187 246 minecraft:cobbled_deepslate
fill 438 187 249 438 188 249 minecraft:tuff
setblock 438 187 250 minecraft:andesite
fill 438 187 253 438 189 253 minecraft:tuff
setblock 438 187 254 minecraft:andesite
setblock 438 187 255 minecraft:cobbled_deepslate
fill 438 187 257 438 188 257 minecraft:tuff
setblock 438 187 258 minecraft:andesite
setblock 438 187 270 minecraft:ochre_froglight
setblock 439 187 240 minecraft:tuff
fill 439 187 242 439 188 242 minecraft:tuff
setblock 439 187 243 minecraft:andesite
fill 439 187 246 439 189 246 minecraft:tuff
setblock 439 187 247 minecraft:andesite
setblock 439 187 248 minecraft:cobbled_deepslate
fill 439 187 250 439 189 250 minecraft:tuff
setblock 439 187 251 minecraft:andesite
setblock 439 187 254 minecraft:tuff
setblock 439 187 255 minecraft:andesite
setblock 439 187 257 minecraft:cobbled_deepslate
fill 439 187 258 439 188 258 minecraft:tuff
setblock 439 187 259 minecraft:andesite
setblock 440 187 239 minecraft:tuff
setblock 440 187 240 minecraft:andesite
setblock 440 187 241 minecraft:cobbled_deepslate
fill 440 187 243 440 189 243 minecraft:tuff
setblock 440 187 244 minecraft:andesite
setblock 440 187 247 minecraft:tuff
setblock 440 187 248 minecraft:andesite
setblock 440 187 250 minecraft:cobbled_deepslate
fill 440 187 251 440 189 251 minecraft:tuff
setblock 440 187 252 minecraft:andesite
setblock 440 187 256 minecraft:andesite
setblock 440 187 259 minecraft:cobbled_deepslate
fill 441 187 240 443 187 240 minecraft:tuff
setblock 441 187 241 minecraft:andesite
setblock 441 187 243 minecraft:cobbled_deepslate
fill 441 187 244 441 189 244 minecraft:tuff
setblock 441 187 245 minecraft:andesite
setblock 441 187 246 minecraft:tuff
fill 441 187 248 442 188 248 minecraft:tuff
setblock 441 187 249 minecraft:andesite
setblock 442 187 238 minecraft:andesite
setblock 442 187 239 minecraft:tuff
fill 442 187 241 443 188 241 minecraft:tuff
setblock 442 187 242 minecraft:andesite
setblock 442 187 245 minecraft:cobbled_deepslate
setblock 442 187 246 minecraft:andesite
setblock 442 187 247 minecraft:tuff
fill 442 187 249 442 189 249 minecraft:tuff
setblock 442 187 250 minecraft:andesite
setblock 442 187 258 minecraft:andesite
setblock 443 187 238 minecraft:cobbled_deepslate
setblock 443 187 239 minecraft:andesite
fill 443 187 242 443 189 242 minecraft:tuff
setblock 443 187 243 minecraft:andesite
fill 443 187 246 443 189 246 minecraft:tuff
setblock 443 187 247 minecraft:cobbled_deepslate
setblock 443 187 259 minecraft:andesite
fill 444 187 239 444 188 239 minecraft:tuff
setblock 444 187 240 minecraft:cobbled_deepslate
fill 444 187 243 444 188 243 minecraft:tuff
setblock 444 187 244 minecraft:andesite
fill 444 187 247 444 189 247 minecraft:tuff
setblock 444 187 248 minecraft:andesite
setblock 444 187 249 minecraft:cobbled_deepslate
setblock 444 187 259 minecraft:tuff
fill 445 187 240 445 189 240 minecraft:tuff
setblock 445 187 241 minecraft:andesite
setblock 445 187 242 minecraft:cobbled_deepslate
fill 445 187 244 445 189 244 minecraft:tuff
setblock 445 187 245 minecraft:andesite
setblock 445 187 248 minecraft:tuff
setblock 445 187 249 minecraft:andesite
setblock 446 187 241 minecraft:tuff
setblock 446 187 242 minecraft:andesite
setblock 446 187 244 minecraft:cobbled_deepslate
fill 446 187 245 446 189 245 minecraft:tuff
setblock 446 187 246 minecraft:andesite
setblock 446 187 247 minecraft:tuff
fill 446 187 249 447 188 249 minecraft:tuff
setblock 446 187 250 minecraft:andesite
setblock 446 187 258 minecraft:andesite
setblock 447 187 239 minecraft:andesite
setblock 447 187 240 minecraft:tuff
fill 447 187 242 448 188 242 minecraft:tuff
setblock 447 187 243 minecraft:andesite
setblock 447 187 244 minecraft:tuff
setblock 447 187 246 minecraft:cobbled_deepslate
setblock 447 187 247 minecraft:andesite
setblock 447 187 248 minecraft:tuff
fill 447 187 250 447 189 250 minecraft:tuff
setblock 447 187 258 minecraft:tuff
setblock 448 187 240 minecraft:andesite
setblock 448 187 241 minecraft:tuff
fill 448 187 243 448 189 243 minecraft:tuff
setblock 448 187 244 minecraft:andesite
fill 448 187 247 448 189 247 minecraft:tuff
setblock 448 187 248 minecraft:cobbled_deepslate
fill 448 187 251 448 188 251 minecraft:tuff
setblock 448 187 252 minecraft:andesite
setblock 448 187 256 minecraft:andesite
setblock 448 187 257 minecraft:cobbled_deepslate
setblock 449 187 241 minecraft:cobbled_deepslate
fill 449 187 244 449 188 244 minecraft:tuff
setblock 449 187 245 minecraft:andesite
fill 449 187 248 449 189 248 minecraft:tuff
setblock 449 187 249 minecraft:andesite
setblock 449 187 250 minecraft:cobbled_deepslate
fill 449 187 252 449 189 252 minecraft:tuff
setblock 449 187 253 minecraft:andesite
setblock 449 187 256 minecraft:tuff
setblock 449 187 257 minecraft:andesite
setblock 450 187 243 minecraft:cobbled_deepslate
fill 450 187 245 450 189 245 minecraft:tuff
setblock 450 187 246 minecraft:andesite
setblock 450 187 249 minecraft:tuff
setblock 450 187 250 minecraft:andesite
setblock 450 187 252 minecraft:cobbled_deepslate
fill 450 187 253 450 189 253 minecraft:tuff
setblock 450 187 254 minecraft:andesite
setblock 450 187 255 minecraft:tuff
setblock 450 187 257 minecraft:tuff
setblock 451 187 245 minecraft:cobbled_deepslate
fill 451 187 246 452 187 246 minecraft:tuff
setblock 451 187 247 minecraft:andesite
setblock 451 187 248 minecraft:tuff
fill 451 187 250 452 188 250 minecraft:tuff
setblock 451 187 251 minecraft:andesite
setblock 451 187 254 minecraft:cobbled_deepslate
setblock 451 187 255 minecraft:andesite
setblock 451 187 256 minecraft:tuff
setblock 452 187 247 minecraft:cobbled_deepslate
setblock 452 187 248 minecraft:andesite
setblock 452 187 249 minecraft:tuff
fill 452 187 251 452 189 251 minecraft:tuff
setblock 452 187 252 minecraft:andesite
fill 452 187 255 452 188 255 minecraft:tuff
setblock 452 187 256 minecraft:cobbled_deepslate
setblock 453 187 248 minecraft:tuff
setblock 453 187 249 minecraft:cobbled_deepslate
fill 453 187 252 453 188 252 minecraft:tuff
setblock 453 187 253 minecraft:andesite
setblock 454 187 249 minecraft:tuff
setblock 454 187 250 minecraft:andesite
setblock 454 187 251 minecraft:cobbled_deepslate
setblock 454 187 253 minecraft:tuff
fill 458 187 270 458 199 270 minecraft:black_concrete
fill 461 187 270 461 200 270 minecraft:black_concrete
fill 465 187 233 465 188 233 minecraft:black_concrete
setblock 465 187 239 minecraft:white_concrete
fill 465 187 241 465 216 241 minecraft:black_concrete
fill 423 188 236 423 236 236 minecraft:black_concrete
setblock 423 188 253 minecraft:sea_lantern
fill 423 188 266 423 216 266 minecraft:black_concrete
setblock 435 188 247 minecraft:tuff
setblock 435 188 248 minecraft:andesite
setblock 436 188 245 minecraft:andesite
setblock 436 188 248 minecraft:cobbled_deepslate
setblock 436 188 249 minecraft:andesite
fill 436 188 250 436 188 252 minecraft:tuff
setblock 436 188 253 minecraft:andesite
setblock 436 188 254 minecraft:tuff
setblock 436 188 256 minecraft:tuff
fill 437 188 243 437 188 245 minecraft:tuff
setblock 437 188 246 minecraft:andesite
fill 437 188 249 437 189 249 minecraft:tuff
setblock 437 188 250 minecraft:cobbled_deepslate
fill 437 188 253 437 189 253 minecraft:tuff
setblock 437 188 254 minecraft:andesite
setblock 437 188 257 minecraft:tuff
setblock 438 188 242 minecraft:tuff
setblock 438 188 243 minecraft:cobbled_deepslate
fill 438 188 244 438 188 246 minecraft:tuff
setblock 438 188 247 minecraft:andesite
fill 438 188 250 438 191 250 minecraft:tuff
setblock 438 188 251 minecraft:andesite
setblock 438 188 252 minecraft:cobbled_deepslate
fill 438 188 254 438 189 254 minecraft:tuff
setblock 438 188 255 minecraft:andesite
fill 438 188 270 438 192 270 minecraft:black_concrete
fill 439 188 243 439 189 243 minecraft:tuff
setblock 439 188 244 minecraft:andesite
setblock 439 188 245 minecraft:cobbled_deepslate
fill 439 188 247 439 191 247 minecraft:tuff
setblock 439 188 248 minecraft:andesite
setblock 439 188 251 minecraft:tuff
setblock 439 188 252 minecraft:andesite
setblock 439 188 254 minecraft:cobbled_deepslate
fill 439 188 255 439 189 255 minecraft:tuff
setblock 439 188 256 minecraft:andesite
setblock 439 188 257 minecraft:tuff
setblock 439 188 270 minecraft:pearlescent_froglight
setblock 440 188 240 minecraft:tuff
setblock 440 188 241 minecraft:andesite
setblock 440 188 244 minecraft:tuff
setblock 440 188 245 minecraft:andesite
setblock 440 188 247 minecraft:cobbled_deepslate
fill 440 188 248 440 191 248 minecraft:tuff
setblock 440 188 249 minecraft:andesite
setblock 440 188 250 minecraft:tuff
fill 440 188 252 440 190 252 minecraft:tuff
setblock 440 188 256 minecraft:cobbled_deepslate
setblock 440 188 257 minecraft:andesite
setblock 440 188 258 minecraft:tuff
setblock 441 188 240 minecraft:cobbled_deepslate
fill 441 188 241 441 189 241 minecraft:tuff
setblock 441 188 242 minecraft:andesite
setblock 441 188 243 minecraft:tuff
fill 441 188 245 442 189 245 minecraft:tuff
setblock 441 188 246 minecraft:andesite
setblock 441 188 249 minecraft:cobbled_deepslate
setblock 441 188 250 minecraft:andesite
setblock 441 188 258 minecraft:cobbled_deepslate
setblock 442 188 239 minecraft:andesite
setblock 442 188 240 minecraft:tuff
setblock 442 188 242 minecraft:cobbled_deepslate
setblock 442 188 243 minecraft:andesite
setblock 442 188 244 minecraft:tuff
fill 442 188 246 442 191 246 minecraft:tuff
setblock 442 188 247 minecraft:andesite
fill 442 188 250 442 191 250 minecraft:tuff
setblock 442 188 258 minecraft:tuff
setblock 443 188 239 minecraft:tuff
setblock 443 188 240 minecraft:andesite
fill 443 188 243 443 190 243 minecraft:tuff
setblock 443 188 244 minecraft:cobbled_deepslate
fill 443 188 247 443 189 247 minecraft:tuff
setblock 443 188 248 minecraft:andesite
fill 444 188 240 444 189 240 minecraft:tuff
setblock 444 188 241 minecraft:andesite
fill 444 188 244 444 191 244 minecraft:tuff
setblock 444 188 245 minecraft:andesite
setblock 444 188 246 minecraft:cobbled_deepslate
fill 444 188 248 444 191 248 minecraft:tuff
setblock 444 188 249 minecraft:andesite
setblock 445 188 239 minecraft:cobbled_deepslate
fill 445 188 241 445 189 241 minecraft:tuff
setblock 445 188 242 minecraft:andesite
setblock 445 188 245 minecraft:tuff
setblock 445 188 246 minecraft:andesite
setblock 445 188 248 minecraft:cobbled_deepslate
fill 445 188 249 445 191 249 minecraft:tuff
setblock 446 188 241 minecraft:cobbled_deepslate
fill 446 188 242 446 189 242 minecraft:tuff
setblock 446 188 243 minecraft:andesite
setblock 446 188 244 minecraft:tuff
fill 446 188 246 447 189 246 minecraft:tuff
setblock 446 188 247 minecraft:andesite
setblock 446 188 250 minecraft:cobbled_deepslate
setblock 447 188 240 minecraft:andesite
setblock 447 188 243 minecraft:cobbled_deepslate
setblock 447 188 244 minecraft:andesite
setblock 447 188 245 minecraft:tuff
fill 447 188 247 447 191 247 minecraft:tuff
setblock 447 188 248 minecraft:andesite
setblock 448 188 241 minecraft:andesite
fill 448 188 244 448 191 244 minecraft:tuff
setblock 448 188 245 minecraft:cobbled_deepslate
fill 448 188 248 448 189 248 minecraft:tuff
setblock 448 188 249 minecraft:andesite
fill 448 188 252 448 190 252 minecraft:tuff
fill 448 188 256 448 189 256 minecraft:tuff
setblock 448 188 257 minecraft:andesite
setblock 449 188 242 minecraft:andesite
fill 449 188 245 449 189 245 minecraft:tuff
setblock 449 188 246 minecraft:andesite
setblock 449 188 247 minecraft:cobbled_deepslate
fill 449 188 249 449 190 249 minecraft:tuff
setblock 449 188 250 minecraft:andesite
setblock 449 188 253 minecraft:tuff
setblock 449 188 254 minecraft:andesite
setblock 449 188 256 minecraft:cobbled_deepslate
setblock 449 188 257 minecraft:tuff
fill 450 188 246 451 188 246 minecraft:tuff
setblock 450 188 247 minecraft:andesite
setblock 450 188 249 minecraft:cobbled_deepslate
fill 450 188 250 450 191 250 minecraft:tuff
setblock 450 188 251 minecraft:andesite
setblock 450 188 252 minecraft:tuff
fill 450 188 254 451 189 254 minecraft:tuff
setblock 450 188 255 minecraft:andesite
setblock 451 188 245 minecraft:tuff
fill 451 188 247 452 188 247 minecraft:tuff
setblock 451 188 248 minecraft:andesite
setblock 451 188 251 minecraft:cobbled_deepslate
setblock 451 188 252 minecraft:andesite
setblock 451 188 253 minecraft:tuff
setblock 451 188 255 minecraft:tuff
setblock 451 188 256 minecraft:andesite
setblock 452 188 248 minecraft:tuff
setblock 452 188 249 minecraft:andesite
fill 452 188 252 452 189 252 minecraft:tuff
setblock 452 188 253 minecraft:cobbled_deepslate
setblock 453 188 249 minecraft:tuff
setblock 453 188 250 minecraft:andesite
setblock 453 188 253 minecraft:tuff
fill 465 188 239 465 202 239 minecraft:black_concrete
setblock 465 188 269 minecraft:white_concrete
fill 423 189 253 423 232 253 minecraft:black_concrete
fill 436 189 247 436 189 248 minecraft:tuff
fill 437 189 245 438 189 246 minecraft:tuff
setblock 437 189 247 minecraft:cobbled_deepslate
setblock 437 189 250 minecraft:tuff
setblock 437 189 251 minecraft:andesite
setblock 437 189 254 minecraft:tuff
setblock 438 189 243 minecraft:tuff
setblock 438 189 244 minecraft:andesite
fill 438 189 247 438 191 247 minecraft:tuff
setblock 438 189 248 minecraft:andesite
setblock 438 189 249 minecraft:cobbled_deepslate
fill 438 189 251 438 191 251 minecraft:tuff
setblock 438 189 252 minecraft:andesite
setblock 438 189 255 minecraft:tuff
setblock 438 189 256 minecraft:andesite
setblock 439 189 242 minecraft:cobbled_deepslate
fill 439 189 244 439 191 244 minecraft:tuff
setblock 439 189 245 minecraft:andesite
setblock 439 189 248 minecraft:tuff
setblock 439 189 249 minecraft:andesite
setblock 439 189 251 minecraft:cobbled_deepslate
fill 439 189 252 439 190 252 minecraft:tuff
setblock 439 189 253 minecraft:andesite
setblock 439 189 254 minecraft:tuff
fill 439 189 256 440 189 256 minecraft:tuff
setblock 439 189 270 minecraft:black_concrete
setblock 440 189 241 minecraft:tuff
setblock 440 189 242 minecraft:andesite
setblock 440 189 244 minecraft:cobbled_deepslate
fill 440 189 245 440 191 245 minecraft:tuff
setblock 440 189 246 minecraft:andesite
setblock 440 189 247 minecraft:tuff
fill 440 189 249 441 191 249 minecraft:tuff
setblock 440 189 250 minecraft:andesite
setblock 440 189 257 minecraft:tuff
setblock 441 189 240 minecraft:tuff
fill 441 189 242 442 191 242 minecraft:tuff
setblock 441 189 243 minecraft:andesite
setblock 441 189 246 minecraft:cobbled_deepslate
setblock 441 189 247 minecraft:andesite
setblock 441 189 248 minecraft:tuff
fill 441 189 250 441 191 250 minecraft:tuff
setblock 442 189 240 minecraft:andesite
setblock 442 189 241 minecraft:tuff
fill 442 189 243 442 190 243 minecraft:tuff
setblock 442 189 244 minecraft:andesite
fill 442 189 247 442 191 247 minecraft:tuff
setblock 442 189 248 minecraft:cobbled_deepslate
setblock 443 189 240 minecraft:tuff
setblock 443 189 241 minecraft:cobbled_deepslate
fill 443 189 244 443 191 244 minecraft:tuff
setblock 443 189 245 minecraft:andesite
fill 443 189 248 443 191 248 minecraft:tuff
setblock 443 189 249 minecraft:andesite
setblock 444 189 241 minecraft:tuff
setblock 444 189 242 minecraft:andesite
setblock 444 189 243 minecraft:cobbled_deepslate
fill 444 189 245 444 191 245 minecraft:tuff
setblock 444 189 246 minecraft:andesite
setblock 444 189 249 minecraft:tuff
setblock 445 189 242 minecraft:tuff
setblock 445 189 243 minecraft:andesite
setblock 445 189 245 minecraft:cobbled_deepslate
fill 445 189 246 445 191 246 minecraft:tuff
setblock 445 189 247 minecraft:andesite
setblock 445 189 248 minecraft:tuff
setblock 446 189 241 minecraft:tuff
fill 446 189 243 447 190 243 minecraft:tuff
setblock 446 189 244 minecraft:andesite
setblock 446 189 247 minecraft:cobbled_deepslate
setblock 446 189 248 minecraft:andesite
fill 446 189 249 446 189 250 minecraft:tuff
setblock 447 189 242 minecraft:tuff
fill 447 189 244 447 191 244 minecraft:tuff
setblock 447 189 245 minecraft:andesite
fill 447 189 248 447 191 248 minecraft:tuff
setblock 447 189 249 minecraft:cobbled_deepslate
fill 448 189 245 448 191 245 minecraft:tuff
setblock 448 189 246 minecraft:andesite
fill 448 189 249 448 191 249 minecraft:tuff
setblock 448 189 250 minecraft:andesite
setblock 448 189 251 minecraft:cobbled_deepslate
setblock 448 189 270 minecraft:purple_terracotta
setblock 449 189 244 minecraft:cobbled_deepslate
fill 449 189 246 449 190 246 minecraft:tuff
setblock 449 189 247 minecraft:andesite
setblock 449 189 250 minecraft:tuff
setblock 449 189 251 minecraft:andesite
setblock 449 189 253 minecraft:cobbled_deepslate
setblock 449 189 254 minecraft:tuff
setblock 449 189 255 minecraft:andesite
setblock 449 189 256 minecraft:tuff
setblock 450 189 246 minecraft:cobbled_deepslate
fill 450 189 247 451 189 247 minecraft:tuff
setblock 450 189 248 minecraft:andesite
setblock 450 189 249 minecraft:tuff
fill 450 189 251 451 189 251 minecraft:tuff
setblock 450 189 252 minecraft:andesite
setblock 450 189 255 minecraft:cobbled_deepslate
setblock 451 189 248 minecraft:cobbled_deepslate
setblock 451 189 249 minecraft:andesite
setblock 451 189 250 minecraft:tuff
setblock 451 189 252 minecraft:tuff
setblock 451 189 253 minecraft:andesite
setblock 452 189 249 minecraft:tuff
setblock 452 189 250 minecraft:cobbled_deepslate
setblock 452 189 253 minecraft:tuff
setblock 457 189 228 minecraft:purple_concrete
setblock 465 189 233 minecraft:blue_concrete
setblock 465 189 257 minecraft:sea_lantern
fill 465 189 269 465 193 269 minecraft:black_concrete
setblock 426 190 231 minecraft:light[level=12]
setblock 426 190 238 minecraft:light[level=12]
setblock 426 190 245 minecraft:light[level=12]
setblock 426 190 252 minecraft:light[level=12]
setblock 426 190 259 minecraft:light[level=12]
setblock 426 190 266 minecraft:light[level=12]
setblock 433 190 231 minecraft:light[level=12]
setblock 433 190 238 minecraft:light[level=12]
setblock 433 190 245 minecraft:light[level=12]
setblock 433 190 252 minecraft:light[level=12]
setblock 433 190 259 minecraft:light[level=12]
setblock 433 190 266 minecraft:light[level=12]
setblock 438 190 245 minecraft:andesite
setblock 438 190 246 minecraft:cobbled_deepslate
fill 438 190 248 438 191 248 minecraft:tuff
fill 438 190 249 438 191 249 minecraft:andesite
fill 439 190 245 439 191 245 minecraft:tuff
fill 439 190 246 439 191 246 minecraft:andesite
setblock 439 190 248 minecraft:cobbled_deepslate
fill 439 190 249 439 191 249 minecraft:tuff
setblock 439 190 250 minecraft:andesite
fill 439 190 251 439 191 251 minecraft:tuff
fill 439 190 253 439 191 253 minecraft:tuff
setblock 439 190 270 minecraft:ochre_froglight
setblock 440 190 231 minecraft:light[level=12]
setblock 440 190 238 minecraft:light[level=12]
fill 440 190 243 440 191 243 minecraft:andesite
fill 440 190 244 440 191 244 minecraft:tuff
fill 440 190 246 441 191 246 minecraft:tuff
setblock 440 190 247 minecraft:andesite
setblock 440 190 250 minecraft:cobbled_deepslate
setblock 440 190 251 minecraft:andesite
setblock 440 190 254 minecraft:obsidian
setblock 440 190 259 minecraft:light[level=12]
setblock 440 190 266 minecraft:light[level=12]
setblock 441 190 243 minecraft:cobbled_deepslate
setblock 441 190 244 minecraft:andesite
fill 441 190 245 441 191 245 minecraft:tuff
fill 441 190 247 441 191 247 minecraft:tuff
setblock 441 190 248 minecraft:andesite
setblock 441 190 255 minecraft:obsidian
fill 442 190 244 442 191 244 minecraft:tuff
setblock 442 190 245 minecraft:cobbled_deepslate
fill 442 190 248 442 191 248 minecraft:tuff
setblock 442 190 249 minecraft:andesite
setblock 442 190 270 minecraft:white_concrete
setblock 443 190 242 minecraft:andesite
fill 443 190 245 443 191 245 minecraft:tuff
setblock 443 190 246 minecraft:andesite
setblock 443 190 247 minecraft:cobbled_deepslate
fill 443 190 249 443 191 249 minecraft:tuff
fill 444 190 242 444 191 242 minecraft:tuff
fill 444 190 243 444 191 243 minecraft:andesite
fill 444 190 246 444 191 246 minecraft:tuff
setblock 444 190 247 minecraft:andesite
setblock 444 190 249 minecraft:cobbled_deepslate
setblock 445 190 242 minecraft:cobbled_deepslate
setblock 445 190 243 minecraft:tuff
setblock 445 190 244 minecraft:andesite
fill 445 190 245 445 191 245 minecraft:tuff
fill 445 190 247 446 191 247 minecraft:tuff
setblock 445 190 248 minecraft:andesite
setblock 446 190 244 minecraft:cobbled_deepslate
setblock 446 190 245 minecraft:andesite
fill 446 190 246 446 191 246 minecraft:tuff
fill 446 190 248 446 191 248 minecraft:tuff
setblock 446 190 249 minecraft:andesite
fill 446 190 250 446 191 250 minecraft:tuff
setblock 447 190 231 minecraft:light[level=12]
setblock 447 190 238 minecraft:light[level=12]
fill 447 190 245 447 191 245 minecraft:tuff
setblock 447 190 246 minecraft:cobbled_deepslate
fill 447 190 249 447 191 249 minecraft:tuff
setblock 447 190 250 minecraft:andesite
setblock 447 190 255 minecraft:obsidian
setblock 447 190 259 minecraft:light[level=12]
setblock 447 190 266 minecraft:light[level=12]
fill 448 190 246 448 191 246 minecraft:tuff
setblock 448 190 247 minecraft:andesite
setblock 448 190 248 minecraft:cobbled_deepslate
fill 448 190 250 448 191 250 minecraft:tuff
setblock 448 190 251 minecraft:andesite
fill 448 190 270 448 221 270 minecraft:black_concrete
fill 449 190 247 450 191 247 minecraft:tuff
setblock 449 190 248 minecraft:andesite
setblock 449 190 250 minecraft:cobbled_deepslate
fill 449 190 251 450 191 251 minecraft:tuff
fill 449 190 252 449 191 252 minecraft:andesite
setblock 450 190 228 minecraft:sea_lantern
fill 450 190 248 450 191 248 minecraft:tuff
fill 450 190 249 450 191 249 minecraft:andesite
setblock 450 190 252 minecraft:cobbled_deepslate
setblock 454 190 231 minecraft:light[level=12]
setblock 454 190 238 minecraft:light[level=12]
setblock 454 190 245 minecraft:light[level=12]
setblock 454 190 252 minecraft:light[level=12]
setblock 454 190 259 minecraft:light[level=12]
setblock 454 190 266 minecraft:light[level=12]
fill 457 190 228 457 210 228 minecraft:black_concrete
setblock 461 190 231 minecraft:light[level=12]
setblock 461 190 238 minecraft:light[level=12]
setblock 461 190 245 minecraft:light[level=12]
setblock 461 190 252 minecraft:light[level=12]
setblock 461 190 259 minecraft:light[level=12]
setblock 461 190 266 minecraft:light[level=12]
fill 465 190 233 465 308 233 minecraft:black_concrete
fill 465 190 257 465 238 257 minecraft:black_concrete
setblock 423 191 231 minecraft:sea_lantern
setblock 423 191 246 minecraft:sea_lantern
fill 424 191 229 464 191 230 minecraft:tuff
fill 424 191 231 464 191 231 minecraft:andesite
fill 424 191 232 464 191 233 minecraft:tuff
fill 424 191 234 464 191 234 minecraft:andesite
fill 424 191 235 464 191 236 minecraft:tuff
fill 424 191 237 464 191 237 minecraft:andesite
fill 424 191 238 464 191 239 minecraft:tuff
fill 424 191 240 464 191 240 minecraft:andesite
fill 424 191 241 440 191 242 minecraft:tuff
fill 424 191 243 439 191 243 minecraft:andesite
fill 424 191 244 438 191 245 minecraft:tuff
fill 424 191 246 438 191 246 minecraft:andesite
fill 424 191 247 437 191 248 minecraft:tuff
fill 424 191 249 437 191 249 minecraft:andesite
fill 424 191 250 437 191 251 minecraft:tuff
fill 424 191 252 440 191 252 minecraft:andesite
fill 424 191 253 438 191 254 minecraft:tuff
fill 424 191 255 439 191 255 minecraft:andesite
fill 424 191 256 440 191 257 minecraft:tuff
fill 424 191 258 442 191 258 minecraft:andesite
fill 424 191 259 464 191 260 minecraft:tuff
fill 424 191 261 464 191 261 minecraft:andesite
fill 424 191 262 464 191 263 minecraft:tuff
fill 424 191 264 464 191 264 minecraft:andesite
fill 424 191 265 464 191 266 minecraft:tuff
fill 424 191 267 464 191 267 minecraft:andesite
fill 424 191 268 464 191 269 minecraft:tuff
setblock 433 191 270 minecraft:pearlescent_froglight
setblock 439 191 248 minecraft:tuff
fill 439 191 250 440 191 250 minecraft:tuff
setblock 439 191 254 minecraft:tuff
setblock 439 191 270 minecraft:black_concrete
setblock 440 191 247 minecraft:tuff
setblock 440 191 251 minecraft:tuff
fill 440 191 253 440 191 255 minecraft:verdant_froglight
setblock 440 191 270 minecraft:ochre_froglight
fill 441 191 241 464 191 241 minecraft:tuff
fill 441 191 243 443 191 243 minecraft:andesite
setblock 441 191 244 minecraft:tuff
setblock 441 191 248 minecraft:tuff
fill 441 191 251 441 191 253 minecraft:verdant_froglight
fill 441 191 255 441 191 257 minecraft:verdant_froglight
setblock 442 191 245 minecraft:tuff
setblock 442 191 249 minecraft:tuff
fill 442 191 251 443 191 251 minecraft:verdant_froglight
fill 442 191 257 443 191 257 minecraft:verdant_froglight
fill 442 191 270 442 212 270 minecraft:black_concrete
setblock 443 191 242 minecraft:tuff
fill 443 191 246 443 191 247 minecraft:tuff
fill 443 191 250 445 191 250 minecraft:verdant_froglight
fill 443 191 258 445 191 258 minecraft:verdant_froglight
setblock 444 191 247 minecraft:tuff
setblock 444 191 249 minecraft:tuff
fill 445 191 242 464 191 242 minecraft:tuff
fill 445 191 243 464 191 243 minecraft:andesite
fill 445 191 244 446 191 244 minecraft:tuff
setblock 445 191 248 minecraft:tuff
fill 445 191 251 447 191 251 minecraft:verdant_froglight
fill 445 191 257 447 191 257 minecraft:verdant_froglight
setblock 446 191 245 minecraft:tuff
setblock 446 191 249 minecraft:tuff
fill 446 191 258 464 191 258 minecraft:andesite
setblock 447 191 246 minecraft:tuff
setblock 447 191 250 minecraft:tuff
fill 447 191 252 447 191 253 minecraft:verdant_froglight
fill 447 191 255 447 191 256 minecraft:verdant_froglight
fill 448 191 247 448 191 248 minecraft:tuff
setblock 448 191 251 minecraft:tuff
setblock 448 191 252 minecraft:andesite
fill 448 191 253 448 191 255 minecraft:verdant_froglight
fill 448 191 256 464 191 257 minecraft:tuff
fill 449 191 244 464 191 245 minecraft:tuff
fill 449 191 246 464 191 246 minecraft:andesite
setblock 449 191 248 minecraft:tuff
setblock 449 191 249 minecraft:andesite
setblock 449 191 250 minecraft:tuff
fill 449 191 253 464 191 254 minecraft:tuff
fill 449 191 255 464 191 255 minecraft:andesite
fill 450 191 228 450 218 228 minecraft:black_concrete
fill 450 191 252 464 191 252 minecraft:andesite
fill 451 191 247 464 191 248 minecraft:tuff
fill 451 191 249 464 191 249 minecraft:andesite
fill 451 191 250 464 191 251 minecraft:tuff
fill 423 192 231 423 247 231 minecraft:black_concrete
fill 423 192 246 423 214 246 minecraft:black_concrete
setblock 426 192 231 minecraft:light[level=15]
setblock 426 192 239 minecraft:light[level=15]
setblock 426 192 247 minecraft:light[level=15]
setblock 426 192 255 minecraft:light[level=15]
setblock 426 192 263 minecraft:light[level=15]
fill 433 192 270 433 308 270 minecraft:black_concrete
setblock 434 192 231 minecraft:light[level=15]
setblock 434 192 239 minecraft:light[level=15]
setblock 434 192 247 minecraft:light[level=15]
setblock 434 192 255 minecraft:light[level=15]
setblock 434 192 263 minecraft:light[level=15]
setblock 439 192 270 minecraft:sea_lantern
fill 440 192 253 440 192 255 minecraft:lime_stained_glass
fill 440 192 270 440 198 270 minecraft:black_concrete
setblock 441 192 252 minecraft:lime_stained_glass
setblock 441 192 256 minecraft:lime_stained_glass
setblock 442 192 231 minecraft:light[level=15]
setblock 442 192 239 minecraft:light[level=15]
setblock 442 192 247 minecraft:light[level=15]
setblock 442 192 251 minecraft:lime_stained_glass
setblock 442 192 257 minecraft:lime_stained_glass
setblock 442 192 263 minecraft:light[level=15]
fill 443 192 250 445 192 250 minecraft:lime_stained_glass
fill 443 192 258 445 192 258 minecraft:lime_stained_glass
setblock 446 192 251 minecraft:lime_stained_glass
setblock 446 192 257 minecraft:lime_stained_glass
setblock 447 192 252 minecraft:lime_stained_glass
setblock 447 192 256 minecraft:lime_stained_glass
fill 448 192 253 448 192 255 minecraft:lime_stained_glass
setblock 449 192 228 minecraft:ochre_froglight
setblock 450 192 231 minecraft:light[level=15]
setblock 450 192 239 minecraft:light[level=15]
setblock 450 192 247 minecraft:light[level=15]
setblock 450 192 255 minecraft:light[level=15]
setblock 450 192 263 minecraft:light[level=15]
setblock 458 192 231 minecraft:light[level=15]
setblock 458 192 239 minecraft:light[level=15]
setblock 458 192 247 minecraft:light[level=15]
setblock 458 192 255 minecraft:light[level=15]
setblock 458 192 263 minecraft:light[level=15]
setblock 465 192 229 minecraft:sea_lantern
setblock 423 193 248 minecraft:pearlescent_froglight
fill 433 193 252 440 194 256 minecraft:light_gray_concrete
fill 434 193 249 441 194 251 minecraft:light_gray_concrete
fill 434 193 257 441 194 259 minecraft:light_gray_concrete
fill 435 193 248 453 196 248 minecraft:light_gray_concrete
fill 435 193 260 453 196 260 minecraft:light_gray_concrete
fill 436 193 247 452 196 247 minecraft:light_gray_concrete
fill 436 193 261 452 196 261 minecraft:light_gray_concrete
fill 437 193 246 451 196 246 minecraft:light_gray_concrete
fill 437 193 262 451 196 262 minecraft:light_gray_concrete
fill 438 193 245 450 196 245 minecraft:light_gray_concrete
fill 438 193 263 450 196 263 minecraft:light_gray_concrete
setblock 438 193 270 minecraft:sea_lantern
fill 439 193 244 449 196 244 minecraft:light_gray_concrete
fill 439 193 264 449 196 264 minecraft:light_gray_concrete
fill 439 193 270 439 245 270 minecraft:black_concrete
fill 442 193 243 446 196 243 minecraft:light_gray_concrete
fill 442 193 249 454 194 250 minecraft:light_gray_concrete
fill 442 193 258 454 194 259 minecraft:light_gray_concrete
fill 442 193 265 446 196 265 minecraft:light_gray_concrete
fill 447 193 251 454 194 251 minecraft:light_gray_concrete
fill 447 193 257 454 194 257 minecraft:light_gray_concrete
fill 448 193 252 455 194 256 minecraft:light_gray_concrete
fill 449 193 228 449 227 228 minecraft:black_concrete
setblock 454 193 228 minecraft:magenta_terracotta
setblock 464 193 228 minecraft:purple_terracotta
fill 465 193 229 465 249 229 minecraft:black_concrete
setblock 423 194 241 minecraft:pearlescent_froglight
fill 423 194 248 423 195 248 minecraft:black_concrete
fill 431 194 250 431 195 258 minecraft:sea_lantern
fill 432 194 248 432 195 251 minecraft:sea_lantern
fill 432 194 252 432 195 256 minecraft:light_gray_concrete
fill 432 194 257 432 195 260 minecraft:sea_lantern
fill 433 194 246 433 195 248 minecraft:sea_lantern
fill 433 194 249 433 195 251 minecraft:light_gray_concrete
fill 433 194 257 433 195 259 minecraft:light_gray_concrete
fill 433 194 260 433 195 262 minecraft:sea_lantern
fill 434 194 245 434 195 246 minecraft:sea_lantern
fill 434 194 247 434 195 248 minecraft:light_gray_concrete
fill 434 194 260 434 195 261 minecraft:light_gray_concrete
fill 434 194 262 434 195 263 minecraft:sea_lantern
setblock 435 194 228 minecraft:ochre_froglight
fill 435 194 244 435 195 245 minecraft:sea_lantern
fill 435 194 246 435 195 247 minecraft:light_gray_concrete
fill 435 194 261 435 195 262 minecraft:light_gray_concrete
fill 435 194 263 435 195 264 minecraft:sea_lantern
fill 436 194 243 436 195 244 minecraft:sea_lantern
fill 436 194 245 436 195 246 minecraft:light_gray_concrete
fill 436 194 262 436 195 263 minecraft:light_gray_concrete
fill 436 194 264 436 195 265 minecraft:sea_lantern
fill 437 194 243 438 195 243 minecraft:sea_lantern
fill 437 194 244 437 195 245 minecraft:light_gray_concrete
fill 437 194 263 437 195 264 minecraft:light_gray_concrete
fill 437 194 265 438 195 265 minecraft:sea_lantern
fill 438 194 242 441 195 242 minecraft:sea_lantern
fill 438 194 244 438 195 244 minecraft:light_gray_concrete
fill 438 194 264 438 195 264 minecraft:light_gray_concrete
fill 438 194 266 441 195 266 minecraft:sea_lantern
fill 438 194 270 438 211 270 minecraft:black_concrete
fill 439 194 243 441 195 243 minecraft:light_gray_concrete
fill 439 194 265 441 195 265 minecraft:light_gray_concrete
fill 440 194 241 448 195 241 minecraft:sea_lantern
fill 440 194 267 448 195 267 minecraft:sea_lantern
fill 442 194 242 446 195 242 minecraft:light_gray_concrete
fill 442 194 266 446 195 266 minecraft:light_gray_concrete
fill 447 194 242 450 195 242 minecraft:sea_lantern
fill 447 194 243 449 195 243 minecraft:light_gray_concrete
fill 447 194 265 449 195 265 minecraft:light_gray_concrete
fill 447 194 266 450 195 266 minecraft:sea_lantern
fill 450 194 243 452 195 243 minecraft:sea_lantern
fill 450 194 244 451 195 244 minecraft:light_gray_concrete
fill 450 194 264 451 195 264 minecraft:light_gray_concrete
fill 450 194 265 452 195 265 minecraft:sea_lantern
fill 451 194 245 452 195 245 minecraft:light_gray_concrete
fill 451 194 263 452 195 263 minecraft:light_gray_concrete
fill 452 194 244 453 195 244 minecraft:sea_lantern
fill 452 194 246 453 195 246 minecraft:light_gray_concrete
fill 452 194 262 453 195 262 minecraft:light_gray_concrete
fill 452 194 264 453 195 264 minecraft:sea_lantern
fill 453 194 245 454 195 245 minecraft:sea_lantern
fill 453 194 247 454 195 247 minecraft:light_gray_concrete
fill 453 194 261 454 195 261 minecraft:light_gray_concrete
fill 453 194 263 454 195 263 minecraft:sea_lantern
fill 454 194 228 454 199 228 minecraft:black_concrete
fill 454 194 246 455 195 246 minecraft:sea_lantern
fill 454 194 248 454 195 248 minecraft:light_gray_concrete
fill 454 194 260 454 195 260 minecraft:light_gray_concrete
fill 454 194 262 455 195 262 minecraft:sea_lantern
fill 455 194 247 455 195 248 minecraft:sea_lantern
fill 455 194 249 455 195 251 minecraft:light_gray_concrete
fill 455 194 257 455 195 259 minecraft:light_gray_concrete
fill 455 194 260 455 195 261 minecraft:sea_lantern
fill 456 194 248 456 195 251 minecraft:sea_lantern
fill 456 194 252 456 195 256 minecraft:light_gray_concrete
fill 456 194 257 456 195 260 minecraft:sea_lantern
fill 457 194 250 457 195 258 minecraft:sea_lantern
fill 464 194 228 464 197 228 minecraft:black_concrete
fill 465 194 231 465 195 231 minecraft:white_concrete
setblock 465 194 269 minecraft:ochre_froglight
fill 423 195 241 423 308 241 minecraft:black_concrete
fill 433 195 252 439 195 256 minecraft:light_gray_concrete
fill 434 195 249 440 195 251 minecraft:light_gray_concrete
fill 434 195 257 440 195 259 minecraft:light_gray_concrete
fill 435 195 228 435 250 228 minecraft:black_concrete
fill 440 195 252 440 195 253 minecraft:light_blue_stained_glass
fill 440 195 255 440 195 256 minecraft:light_blue_stained_glass
fill 441 195 249 441 195 250 minecraft:light_gray_concrete
setblock 441 195 251 minecraft:light_blue_stained_glass
setblock 441 195 257 minecraft:light_blue_stained_glass
fill 441 195 258 441 195 259 minecraft:light_gray_concrete
fill 442 195 249 454 195 249 minecraft:light_gray_concrete
fill 442 195 250 443 195 250 minecraft:light_blue_stained_glass
fill 442 195 258 443 195 258 minecraft:light_blue_stained_glass
fill 442 195 259 454 195 259 minecraft:light_gray_concrete
fill 445 195 250 446 195 250 minecraft:light_blue_stained_glass
fill 445 195 258 446 195 258 minecraft:light_blue_stained_glass
fill 447 195 250 454 195 250 minecraft:light_gray_concrete
setblock 447 195 251 minecraft:light_blue_stained_glass
setblock 447 195 257 minecraft:light_blue_stained_glass
fill 447 195 258 454 195 258 minecraft:light_gray_concrete
fill 448 195 251 454 195 251 minecraft:light_gray_concrete
fill 448 195 252 448 195 253 minecraft:light_blue_stained_glass
fill 448 195 255 448 195 256 minecraft:light_blue_stained_glass
fill 448 195 257 454 195 257 minecraft:light_gray_concrete
fill 449 195 252 455 195 256 minecraft:light_gray_concrete
setblock 456 195 228 minecraft:sea_lantern
setblock 463 195 270 minecraft:white_concrete
setblock 465 195 245 minecraft:purple_concrete
fill 465 195 269 465 222 269 minecraft:black_concrete
setblock 423 196 243 minecraft:sea_lantern
setblock 423 196 248 minecraft:sea_lantern
setblock 423 196 250 minecraft:ochre_froglight
setblock 426 196 231 minecraft:light[level=12]
setblock 426 196 238 minecraft:light[level=12]
setblock 426 196 245 minecraft:light[level=12]
setblock 426 196 252 minecraft:light[level=12]
setblock 426 196 259 minecraft:light[level=12]
setblock 426 196 266 minecraft:light[level=12]
setblock 429 196 270 minecraft:white_concrete
setblock 433 196 231 minecraft:light[level=12]
setblock 433 196 238 minecraft:light[level=12]
setblock 433 196 245 minecraft:light[level=12]
fill 433 196 252 438 196 256 minecraft:light_gray_concrete
setblock 433 196 259 minecraft:light[level=12]
setblock 433 196 266 minecraft:light[level=12]
fill 434 196 249 439 196 251 minecraft:light_gray_concrete
fill 434 196 257 439 196 259 minecraft:light_gray_concrete
fill 439 196 252 439 198 256 minecraft:light_blue_stained_glass
setblock 440 196 231 minecraft:light[level=12]
setblock 440 196 238 minecraft:light[level=12]
fill 440 196 249 441 196 249 minecraft:light_gray_concrete
fill 440 196 250 440 197 252 minecraft:light_blue_stained_glass
fill 440 196 256 440 197 258 minecraft:light_blue_stained_glass
fill 440 196 259 441 196 259 minecraft:light_gray_concrete
setblock 440 196 266 minecraft:light[level=12]
fill 441 196 250 442 197 250 minecraft:light_blue_stained_glass
fill 441 196 258 442 197 258 minecraft:light_blue_stained_glass
fill 442 196 249 446 198 249 minecraft:light_blue_stained_glass
fill 442 196 259 446 198 259 minecraft:light_blue_stained_glass
fill 446 196 250 448 197 250 minecraft:light_blue_stained_glass
fill 446 196 258 448 197 258 minecraft:light_blue_stained_glass
setblock 447 196 231 minecraft:light[level=12]
setblock 447 196 238 minecraft:light[level=12]
fill 447 196 249 454 196 249 minecraft:light_gray_concrete
fill 447 196 259 454 196 259 minecraft:light_gray_concrete
setblock 447 196 266 minecraft:light[level=12]
fill 448 196 251 448 197 252 minecraft:light_blue_stained_glass
fill 448 196 256 448 197 257 minecraft:light_blue_stained_glass
fill 449 196 250 454 196 251 minecraft:light_gray_concrete
fill 449 196 252 449 198 256 minecraft:light_blue_stained_glass
fill 449 196 257 454 196 258 minecraft:light_gray_concrete
fill 450 196 252 455 196 256 minecraft:light_gray_concrete
setblock 454 196 231 minecraft:light[level=12]
setblock 454 196 238 minecraft:light[level=12]
setblock 454 196 245 minecraft:light[level=12]
setblock 454 196 266 minecraft:light[level=12]
fill 456 196 228 456 226 228 minecraft:black_concrete
setblock 458 196 228 minecraft:ochre_froglight
setblock 461 196 231 minecraft:light[level=12]
setblock 461 196 238 minecraft:light[level=12]
setblock 461 196 245 minecraft:light[level=12]
setblock 461 196 252 minecraft:light[level=12]
setblock 461 196 259 minecraft:light[level=12]
setblock 461 196 266 minecraft:light[level=12]
fill 463 196 270 463 201 270 minecraft:black_concrete
fill 465 196 231 465 308 231 minecraft:black_concrete
fill 465 196 245 465 216 245 minecraft:black_concrete
setblock 423 197 232 minecraft:sea_lantern
fill 423 197 243 423 229 243 minecraft:black_concrete
fill 423 197 248 423 308 248 minecraft:black_concrete
fill 423 197 250 423 218 250 minecraft:black_concrete
fill 429 197 270 429 261 270 minecraft:black_concrete
setblock 430 197 228 minecraft:sea_lantern
setblock 438 197 254 minecraft:light_blue_stained_glass
setblock 439 197 251 minecraft:light_blue_stained_glass
setblock 439 197 257 minecraft:light_blue_stained_glass
setblock 441 197 249 minecraft:light_blue_stained_glass
setblock 441 197 259 minecraft:light_blue_stained_glass
setblock 444 197 248 minecraft:light_blue_stained_glass
setblock 444 197 260 minecraft:light_blue_stained_glass
setblock 447 197 249 minecraft:light_blue_stained_glass
setblock 447 197 259 minecraft:light_blue_stained_glass
setblock 449 197 251 minecraft:light_blue_stained_glass
setblock 449 197 257 minecraft:light_blue_stained_glass
setblock 450 197 254 minecraft:light_blue_stained_glass
setblock 451 197 270 minecraft:ochre_froglight
fill 458 197 228 458 207 228 minecraft:black_concrete
setblock 461 197 228 minecraft:sea_lantern
fill 423 198 232 423 270 232 minecraft:black_concrete
setblock 423 198 235 minecraft:sea_lantern
setblock 430 198 228 minecraft:white_concrete
fill 440 198 250 440 198 251 minecraft:light_blue_stained_glass
fill 440 198 257 440 198 258 minecraft:light_blue_stained_glass
setblock 441 198 250 minecraft:light_blue_stained_glass
setblock 441 198 258 minecraft:light_blue_stained_glass
fill 447 198 250 448 198 250 minecraft:light_blue_stained_glass
fill 447 198 258 448 198 258 minecraft:light_blue_stained_glass
setblock 448 198 251 minecraft:light_blue_stained_glass
setblock 448 198 257 minecraft:light_blue_stained_glass
fill 451 198 270 451 212 270 minecraft:black_concrete
fill 461 198 228 461 252 228 minecraft:black_concrete
setblock 464 198 228 minecraft:sea_lantern
setblock 465 198 244 minecraft:purple_terracotta
fill 423 199 235 423 200 235 minecraft:black_concrete
setblock 426 199 231 minecraft:light[level=15]
setblock 426 199 239 minecraft:light[level=15]
setblock 426 199 247 minecraft:light[level=15]
setblock 426 199 255 minecraft:light[level=15]
setblock 426 199 263 minecraft:light[level=15]
fill 430 199 228 430 308 228 minecraft:black_concrete
setblock 434 199 231 minecraft:light[level=15]
setblock 434 199 239 minecraft:light[level=15]
setblock 434 199 247 minecraft:light[level=15]
setblock 434 199 255 minecraft:light[level=15]
setblock 434 199 263 minecraft:light[level=15]
setblock 440 199 270 minecraft:white_concrete
setblock 442 199 231 minecraft:light[level=15]
setblock 442 199 239 minecraft:light[level=15]
setblock 442 199 247 minecraft:light[level=15]
setblock 442 199 263 minecraft:light[level=15]
setblock 450 199 231 minecraft:light[level=15]
setblock 450 199 239 minecraft:light[level=15]
setblock 450 199 247 minecraft:light[level=15]
setblock 450 199 255 minecraft:light[level=15]
setblock 450 199 263 minecraft:light[level=15]
fill 456 199 239 458 200 239 minecraft:gray_concrete
fill 457 199 238 457 200 238 minecraft:gray_concrete
fill 457 199 240 457 200 240 minecraft:gray_concrete
setblock 458 199 231 minecraft:light[level=15]
setblock 458 199 247 minecraft:light[level=15]
setblock 458 199 255 minecraft:light[level=15]
setblock 458 199 263 minecraft:light[level=15]
fill 464 199 228 464 209 228 minecraft:black_concrete
fill 465 199 244 465 212 244 minecraft:black_concrete
setblock 465 199 254 minecraft:white_concrete
setblock 465 199 256 minecraft:sea_lantern
setblock 423 200 237 minecraft:ochre_froglight
setblock 428 200 228 minecraft:white_concrete
fill 440 200 270 440 308 270 minecraft:black_concrete
setblock 454 200 228 minecraft:sea_lantern
setblock 458 200 270 minecraft:ochre_froglight
setblock 465 200 234 minecraft:ochre_froglight
fill 465 200 254 465 282 254 minecraft:black_concrete
fill 465 200 256 465 218 256 minecraft:black_concrete
setblock 423 201 235 minecraft:pearlescent_froglight
fill 423 201 237 423 216 237 minecraft:black_concrete
setblock 425 201 228 minecraft:white_concrete
fill 428 201 228 428 217 228 minecraft:black_concrete
fill 454 201 228 454 225 228 minecraft:black_concrete
fill 458 201 270 458 221 270 minecraft:black_concrete
setblock 461 201 270 minecraft:white_concrete
fill 465 201 234 465 209 234 minecraft:black_concrete
fill 423 202 235 423 232 235 minecraft:black_concrete
setblock 423 202 262 minecraft:blue_concrete
fill 425 202 228 425 229 228 minecraft:black_concrete
setblock 426 202 231 minecraft:light[level=12]
setblock 426 202 238 minecraft:light[level=12]
setblock 426 202 245 minecraft:light[level=12]
setblock 426 202 252 minecraft:light[level=12]
setblock 426 202 259 minecraft:light[level=12]
setblock 426 202 266 minecraft:light[level=12]
setblock 433 202 231 minecraft:light[level=12]
setblock 433 202 238 minecraft:light[level=12]
setblock 433 202 245 minecraft:light[level=12]
setblock 433 202 252 minecraft:light[level=12]
setblock 433 202 259 minecraft:light[level=12]
setblock 433 202 266 minecraft:light[level=12]
setblock 440 202 231 minecraft:light[level=12]
setblock 440 202 238 minecraft:light[level=12]
setblock 440 202 245 minecraft:light[level=12]
setblock 440 202 259 minecraft:light[level=12]
setblock 440 202 266 minecraft:light[level=12]
setblock 447 202 231 minecraft:light[level=12]
setblock 447 202 238 minecraft:light[level=12]
setblock 447 202 245 minecraft:light[level=12]
setblock 447 202 259 minecraft:light[level=12]
setblock 447 202 266 minecraft:light[level=12]
setblock 454 202 231 minecraft:light[level=12]
setblock 454 202 238 minecraft:light[level=12]
setblock 454 202 245 minecraft:light[level=12]
setblock 454 202 252 minecraft:light[level=12]
setblock 454 202 259 minecraft:light[level=12]
setblock 454 202 266 minecraft:light[level=12]
setblock 461 202 231 minecraft:light[level=12]
setblock 461 202 238 minecraft:light[level=12]
setblock 461 202 245 minecraft:light[level=12]
setblock 461 202 252 minecraft:light[level=12]
setblock 461 202 259 minecraft:light[level=12]
setblock 461 202 266 minecraft:light[level=12]
fill 461 202 270 461 258 270 minecraft:black_concrete
setblock 463 202 228 minecraft:ochre_froglight
setblock 463 202 270 minecraft:sea_lantern
setblock 465 202 253 minecraft:pearlescent_froglight
setblock 423 203 252 minecraft:sea_lantern
setblock 423 203 260 minecraft:sea_lantern
fill 423 203 262 423 212 262 minecraft:black_concrete
fill 463 203 228 463 308 228 minecraft:black_concrete
fill 463 203 270 463 212 270 minecraft:black_concrete
setblock 465 203 239 minecraft:white_concrete
fill 465 203 253 465 257 253 minecraft:black_concrete
fill 423 204 252 423 208 252 minecraft:black_concrete
fill 423 204 260 423 240 260 minecraft:black_concrete
setblock 432 204 270 minecraft:ochre_froglight
setblock 437 204 270 minecraft:ochre_froglight
setblock 456 204 270 minecraft:purple_concrete
fill 465 204 239 465 244 239 minecraft:black_concrete
fill 432 205 270 432 308 270 minecraft:black_concrete
fill 437 205 270 437 274 270 minecraft:black_concrete
setblock 441 205 228 minecraft:ochre_froglight
setblock 441 205 270 minecraft:white_concrete
fill 456 205 270 456 289 270 minecraft:black_concrete
setblock 423 206 233 minecraft:pearlescent_froglight
setblock 426 206 231 minecraft:light[level=15]
setblock 426 206 239 minecraft:light[level=15]
setblock 426 206 247 minecraft:light[level=15]
setblock 426 206 255 minecraft:light[level=15]
setblock 426 206 263 minecraft:light[level=15]
setblock 434 206 231 minecraft:light[level=15]
setblock 434 206 239 minecraft:light[level=15]
setblock 434 206 247 minecraft:light[level=15]
setblock 434 206 255 minecraft:light[level=15]
setblock 434 206 263 minecraft:light[level=15]
fill 441 206 228 441 208 228 minecraft:black_concrete
fill 441 206 270 441 273 270 minecraft:black_concrete
setblock 442 206 231 minecraft:light[level=15]
setblock 442 206 239 minecraft:light[level=15]
setblock 442 206 247 minecraft:light[level=15]
setblock 442 206 255 minecraft:light[level=15]
setblock 442 206 263 minecraft:light[level=15]
setblock 450 206 231 minecraft:light[level=15]
setblock 450 206 239 minecraft:light[level=15]
setblock 450 206 247 minecraft:light[level=15]
setblock 450 206 255 minecraft:light[level=15]
setblock 450 206 263 minecraft:light[level=15]
setblock 458 206 231 minecraft:light[level=15]
setblock 458 206 239 minecraft:light[level=15]
setblock 458 206 247 minecraft:light[level=15]
setblock 458 206 255 minecraft:light[level=15]
setblock 458 206 263 minecraft:light[level=15]
setblock 465 206 243 minecraft:sea_lantern
setblock 465 206 250 minecraft:pearlescent_froglight
fill 423 207 233 423 233 233 minecraft:black_concrete
setblock 426 207 228 minecraft:ochre_froglight
setblock 465 207 235 minecraft:purple_terracotta
fill 465 207 243 465 219 243 minecraft:black_concrete
fill 465 207 250 465 211 250 minecraft:black_concrete
setblock 465 207 262 minecraft:white_concrete
setblock 423 208 256 minecraft:sea_lantern
setblock 423 208 261 minecraft:pearlescent_froglight
fill 426 208 228 426 209 228 minecraft:black_concrete
setblock 426 208 231 minecraft:light[level=12]
setblock 426 208 238 minecraft:light[level=12]
setblock 426 208 245 minecraft:light[level=12]
setblock 426 208 252 minecraft:light[level=12]
setblock 426 208 259 minecraft:light[level=12]
setblock 426 208 266 minecraft:light[level=12]
setblock 427 208 228 minecraft:purple_concrete
setblock 432 208 228 minecraft:pearlescent_froglight
setblock 433 208 231 minecraft:light[level=12]
setblock 433 208 238 minecraft:light[level=12]
setblock 433 208 245 minecraft:light[level=12]
setblock 433 208 252 minecraft:light[level=12]
setblock 433 208 259 minecraft:light[level=12]
setblock 433 208 266 minecraft:light[level=12]
fill 435 208 238 435 209 238 minecraft:end_stone
setblock 440 208 231 minecraft:light[level=12]
setblock 440 208 238 minecraft:light[level=12]
setblock 440 208 245 minecraft:light[level=12]
setblock 440 208 252 minecraft:light[level=12]
setblock 440 208 259 minecraft:light[level=12]
setblock 440 208 266 minecraft:light[level=12]
setblock 447 208 231 minecraft:light[level=12]
setblock 447 208 238 minecraft:light[level=12]
setblock 447 208 245 minecraft:light[level=12]
setblock 447 208 252 minecraft:light[level=12]
setblock 447 208 259 minecraft:light[level=12]
setblock 447 208 266 minecraft:light[level=12]
setblock 454 208 231 minecraft:light[level=12]
setblock 454 208 238 minecraft:light[level=12]
setblock 454 208 245 minecraft:light[level=12]
setblock 454 208 252 minecraft:light[level=12]
setblock 454 208 259 minecraft:light[level=12]
setblock 454 208 266 minecraft:light[level=12]
setblock 458 208 228 minecraft:pearlescent_froglight
setblock 461 208 231 minecraft:light[level=12]
setblock 461 208 238 minecraft:light[level=12]
setblock 461 208 245 minecraft:light[level=12]
setblock 461 208 252 minecraft:light[level=12]
setblock 461 208 259 minecraft:light[level=12]
setblock 461 208 266 minecraft:light[level=12]
fill 465 208 235 465 217 235 minecraft:black_concrete
setblock 465 208 252 minecraft:pearlescent_froglight
fill 465 208 262 465 210 262 minecraft:black_concrete
setblock 423 209 252 minecraft:sea_lantern
fill 423 209 256 423 270 256 minecraft:black_concrete
fill 423 209 261 423 291 261 minecraft:black_concrete
fill 427 209 228 427 213 228 minecraft:black_concrete
fill 432 209 228 432 277 228 minecraft:black_concrete
setblock 441 209 228 minecraft:sea_lantern
setblock 448 209 228 minecraft:purple_concrete
setblock 452 209 270 minecraft:ochre_froglight
fill 458 209 228 458 235 228 minecraft:black_concrete
setblock 460 209 270 minecraft:purple_terracotta
fill 465 209 252 465 257 252 minecraft:black_concrete
setblock 465 209 259 minecraft:blue_concrete
setblock 423 210 247 minecraft:blue_concrete
fill 423 210 252 423 231 252 minecraft:black_concrete
setblock 426 210 228 minecraft:sea_lantern
setblock 430 210 270 minecraft:sea_lantern
fill 441 210 228 441 299 228 minecraft:black_concrete
setblock 444 210 270 minecraft:magenta_terracotta
fill 447 210 231 449 212 233 minecraft:gold_block
fill 448 210 228 448 260 228 minecraft:black_concrete
setblock 452 210 270 minecraft:white_concrete
fill 460 210 270 460 251 270 minecraft:black_concrete
setblock 464 210 228 minecraft:ochre_froglight
setblock 465 210 234 minecraft:sea_lantern
fill 465 210 259 465 287 259 minecraft:black_concrete
setblock 465 210 263 minecraft:white_concrete
fill 423 211 247 423 227 247 minecraft:black_concrete
fill 426 211 228 426 299 228 minecraft:black_concrete
fill 430 211 270 430 289 270 minecraft:black_concrete
fill 441 211 233 441 212 235 minecraft:end_stone
fill 442 211 231 446 211 233 minecraft:blue_stained_glass
fill 442 211 234 442 212 234 minecraft:end_stone
fill 444 211 270 444 305 270 minecraft:black_concrete
fill 450 211 231 454 211 233 minecraft:blue_stained_glass
fill 452 211 270 452 212 270 minecraft:black_concrete
setblock 457 211 228 minecraft:sea_lantern
fill 464 211 228 464 223 228 minecraft:black_concrete
fill 465 211 234 465 281 234 minecraft:black_concrete
setblock 465 211 237 minecraft:white_concrete
fill 465 211 238 465 231 238 minecraft:black_concrete
setblock 465 211 262 minecraft:ochre_froglight
fill 465 211 263 465 259 263 minecraft:black_concrete
setblock 465 211 264 minecraft:white_concrete
setblock 465 211 268 minecraft:white_concrete
setblock 438 212 270 minecraft:ochre_froglight
setblock 442 212 233 minecraft:end_stone
setblock 455 212 228 minecraft:white_concrete
fill 457 212 228 457 269 228 minecraft:black_concrete
setblock 459 212 270 minecraft:sea_lantern
fill 465 212 237 465 277 237 minecraft:black_concrete
setblock 465 212 249 minecraft:white_concrete
setblock 465 212 250 minecraft:pearlescent_froglight
fill 465 212 262 465 277 262 minecraft:black_concrete
fill 465 212 264 465 253 264 minecraft:black_concrete
fill 465 212 268 465 274 268 minecraft:black_concrete
setblock 423 213 262 minecraft:white_concrete
setblock 426 213 231 minecraft:light[level=15]
setblock 426 213 239 minecraft:light[level=15]
setblock 426 213 247 minecraft:light[level=15]
setblock 426 213 255 minecraft:light[level=15]
setblock 426 213 263 minecraft:light[level=15]
setblock 434 213 231 minecraft:light[level=15]
setblock 434 213 239 minecraft:light[level=15]
setblock 434 213 247 minecraft:light[level=15]
setblock 434 213 255 minecraft:light[level=15]
setblock 434 213 263 minecraft:light[level=15]
fill 438 213 270 438 250 270 minecraft:black_concrete
setblock 442 213 231 minecraft:light[level=15]
setblock 442 213 239 minecraft:light[level=15]
setblock 442 213 247 minecraft:light[level=15]
setblock 442 213 255 minecraft:light[level=15]
setblock 442 213 263 minecraft:light[level=15]
setblock 442 213 270 minecraft:sea_lantern
fill 447 213 231 447 214 235 minecraft:gray_concrete
fill 448 213 231 451 214 231 minecraft:gray_concrete
fill 448 213 232 448 214 232 minecraft:iron_bars
fill 448 213 233 451 214 235 minecraft:gray_concrete
fill 449 213 229 449 213 230 minecraft:gray_concrete
fill 449 213 232 451 214 232 minecraft:gray_concrete
setblock 450 213 239 minecraft:light[level=15]
setblock 450 213 247 minecraft:light[level=15]
setblock 450 213 255 minecraft:light[level=15]
setblock 450 213 263 minecraft:light[level=15]
setblock 451 213 270 minecraft:ochre_froglight
setblock 452 213 270 minecraft:white_concrete
fill 455 213 228 455 252 228 minecraft:black_concrete
setblock 458 213 231 minecraft:light[level=15]
setblock 458 213 239 minecraft:light[level=15]
setblock 458 213 247 minecraft:light[level=15]
setblock 458 213 255 minecraft:light[level=15]
setblock 458 213 263 minecraft:light[level=15]
fill 459 213 270 459 273 270 minecraft:black_concrete
setblock 463 213 270 minecraft:sea_lantern
setblock 465 213 244 minecraft:purple_terracotta
fill 465 213 249 465 233 250 minecraft:black_concrete
fill 423 214 262 423 235 262 minecraft:black_concrete
setblock 423 214 268 minecraft:white_concrete
setblock 426 214 231 minecraft:light[level=12]
setblock 426 214 238 minecraft:light[level=12]
setblock 426 214 245 minecraft:light[level=12]
setblock 426 214 252 minecraft:light[level=12]
setblock 426 214 259 minecraft:light[level=12]
setblock 426 214 266 minecraft:light[level=12]
setblock 427 214 228 minecraft:pearlescent_froglight
setblock 433 214 231 minecraft:light[level=12]
setblock 433 214 238 minecraft:light[level=12]
setblock 433 214 245 minecraft:light[level=12]
setblock 433 214 252 minecraft:light[level=12]
setblock 433 214 259 minecraft:light[level=12]
setblock 433 214 266 minecraft:light[level=12]
setblock 436 214 270 minecraft:purple_terracotta
setblock 440 214 231 minecraft:light[level=12]
setblock 440 214 238 minecraft:light[level=12]
setblock 440 214 245 minecraft:light[level=12]
setblock 440 214 252 minecraft:light[level=12]
setblock 440 214 259 minecraft:light[level=12]
setblock 440 214 266 minecraft:light[level=12]
fill 442 214 270 442 219 270 minecraft:black_concrete
fill 446 214 233 446 215 233 minecraft:orange_concrete
setblock 447 214 238 minecraft:light[level=12]
setblock 447 214 245 minecraft:light[level=12]
setblock 447 214 252 minecraft:light[level=12]
setblock 447 214 259 minecraft:light[level=12]
setblock 447 214 266 minecraft:light[level=12]
fill 449 214 230 449 215 230 minecraft:orange_concrete
fill 449 214 236 449 215 236 minecraft:orange_concrete
fill 451 214 270 452 246 270 minecraft:black_concrete
setblock 452 214 228 minecraft:magenta_terracotta
fill 452 214 233 452 215 233 minecraft:orange_concrete
setblock 454 214 231 minecraft:light[level=12]
setblock 454 214 238 minecraft:light[level=12]
setblock 454 214 245 minecraft:light[level=12]
setblock 454 214 252 minecraft:light[level=12]
setblock 454 214 259 minecraft:light[level=12]
setblock 454 214 266 minecraft:light[level=12]
setblock 461 214 231 minecraft:light[level=12]
setblock 461 214 238 minecraft:light[level=12]
setblock 461 214 245 minecraft:light[level=12]
setblock 461 214 252 minecraft:light[level=12]
setblock 461 214 259 minecraft:light[level=12]
setblock 461 214 266 minecraft:light[level=12]
fill 463 214 270 463 247 270 minecraft:black_concrete
fill 465 214 244 465 265 244 minecraft:black_concrete
setblock 423 215 246 minecraft:sea_lantern
fill 423 215 268 423 242 268 minecraft:black_concrete
fill 427 215 228 427 217 228 minecraft:black_concrete
fill 436 215 270 436 225 270 minecraft:black_concrete
setblock 444 215 228 minecraft:white_concrete
fill 448 215 232 450 225 234 minecraft:light_gray_concrete
fill 452 215 228 452 234 228 minecraft:black_concrete
setblock 462 215 270 minecraft:magenta_terracotta
setblock 465 215 255 minecraft:purple_concrete
fill 423 216 246 423 219 246 minecraft:black_concrete
setblock 443 216 270 minecraft:magenta_terracotta
fill 444 216 228 444 225 228 minecraft:black_concrete
fill 447 216 233 447 217 233 minecraft:orange_concrete
fill 449 216 231 449 217 231 minecraft:orange_concrete
fill 449 216 235 449 217 235 minecraft:orange_concrete
fill 449 216 254 451 217 255 minecraft:gray_concrete
fill 451 216 233 451 217 233 minecraft:orange_concrete
fill 462 216 270 462 225 270 minecraft:black_concrete
fill 465 216 255 465 220 255 minecraft:black_concrete
fill 423 217 237 423 218 237 minecraft:ochre_froglight
setblock 423 217 266 minecraft:blue_concrete
fill 443 217 270 443 261 270 minecraft:black_concrete
setblock 465 217 241 minecraft:sea_lantern
setblock 465 217 245 minecraft:ochre_froglight
fill 423 218 266 423 243 266 minecraft:black_concrete
setblock 425 218 270 minecraft:white_concrete
setblock 427 218 228 minecraft:sea_lantern
setblock 428 218 228 minecraft:white_concrete
setblock 465 218 235 minecraft:purple_concrete
fill 465 218 241 465 237 241 minecraft:black_concrete
fill 465 218 245 465 245 245 minecraft:black_concrete
fill 423 219 237 423 253 237 minecraft:black_concrete
setblock 423 219 250 minecraft:pearlescent_froglight
fill 425 219 270 425 306 270 minecraft:black_concrete
fill 427 219 228 428 236 228 minecraft:black_concrete
setblock 431 219 270 minecraft:ochre_froglight
setblock 450 219 228 minecraft:ochre_froglight
fill 465 219 235 465 226 235 minecraft:black_concrete
setblock 465 219 236 minecraft:white_concrete
setblock 465 219 256 minecraft:ochre_froglight
setblock 423 220 246 minecraft:sea_lantern
fill 423 220 250 423 230 250 minecraft:black_concrete
setblock 426 220 231 minecraft:light[level=15]
setblock 426 220 238 minecraft:light[level=12]
setblock 426 220 239 minecraft:light[level=15]
setblock 426 220 245 minecraft:light[level=12]
setblock 426 220 247 minecraft:light[level=15]
setblock 426 220 252 minecraft:light[level=12]
setblock 426 220 255 minecraft:light[level=15]
setblock 426 220 259 minecraft:light[level=12]
setblock 426 220 263 minecraft:light[level=15]
setblock 426 220 266 minecraft:light[level=12]
fill 431 220 270 431 226 270 minecraft:black_concrete
setblock 433 220 231 minecraft:light[level=12]
setblock 433 220 238 minecraft:light[level=12]
setblock 433 220 245 minecraft:light[level=12]
setblock 433 220 252 minecraft:light[level=12]
setblock 433 220 259 minecraft:light[level=12]
setblock 433 220 266 minecraft:light[level=12]
setblock 434 220 231 minecraft:light[level=15]
setblock 434 220 239 minecraft:light[level=15]
setblock 434 220 247 minecraft:light[level=15]
setblock 434 220 255 minecraft:light[level=15]
setblock 434 220 263 minecraft:light[level=15]
setblock 440 220 231 minecraft:light[level=12]
setblock 440 220 238 minecraft:light[level=12]
setblock 440 220 245 minecraft:light[level=12]
setblock 440 220 252 minecraft:light[level=12]
setblock 440 220 259 minecraft:light[level=12]
setblock 440 220 266 minecraft:light[level=12]
setblock 442 220 231 minecraft:light[level=15]
setblock 442 220 239 minecraft:light[level=15]
setblock 442 220 247 minecraft:light[level=15]
setblock 442 220 255 minecraft:light[level=15]
setblock 442 220 263 minecraft:light[level=15]
setblock 442 220 270 minecraft:sea_lantern
setblock 447 220 231 minecraft:light[level=12]
setblock 447 220 238 minecraft:light[level=12]
setblock 447 220 245 minecraft:light[level=12]
setblock 447 220 252 minecraft:light[level=12]
setblock 447 220 259 minecraft:light[level=12]
setblock 447 220 266 minecraft:light[level=12]
setblock 447 220 270 minecraft:sea_lantern
fill 450 220 228 450 240 228 minecraft:black_concrete
setblock 450 220 231 minecraft:light[level=15]
setblock 450 220 239 minecraft:light[level=15]
setblock 450 220 247 minecraft:light[level=15]
setblock 450 220 255 minecraft:light[level=15]
setblock 450 220 263 minecraft:light[level=15]
setblock 454 220 231 minecraft:light[level=12]
setblock 454 220 238 minecraft:light[level=12]
setblock 454 220 245 minecraft:light[level=12]
setblock 454 220 252 minecraft:light[level=12]
setblock 454 220 259 minecraft:light[level=12]
setblock 454 220 266 minecraft:light[level=12]
setblock 458 220 231 minecraft:light[level=15]
setblock 458 220 239 minecraft:light[level=15]
setblock 458 220 247 minecraft:light[level=15]
setblock 458 220 255 minecraft:light[level=15]
setblock 458 220 263 minecraft:light[level=15]
setblock 461 220 231 minecraft:light[level=12]
setblock 461 220 238 minecraft:light[level=12]
setblock 461 220 245 minecraft:light[level=12]
setblock 461 220 252 minecraft:light[level=12]
setblock 461 220 259 minecraft:light[level=12]
setblock 461 220 266 minecraft:light[level=12]
fill 465 220 236 465 248 236 minecraft:black_concrete
setblock 465 220 243 minecraft:white_concrete
fill 465 220 256 465 308 256 minecraft:black_concrete
fill 423 221 246 423 241 246 minecraft:black_concrete
setblock 423 221 263 minecraft:white_concrete
fill 442 221 270 442 308 270 minecraft:black_concrete
fill 447 221 270 447 278 270 minecraft:black_concrete
setblock 465 221 243 minecraft:sea_lantern
setblock 465 221 255 minecraft:ochre_froglight
fill 423 222 263 423 298 263 minecraft:black_concrete
fill 425 222 230 425 223 230 minecraft:orange_terracotta
setblock 448 222 270 minecraft:ochre_froglight
setblock 458 222 270 minecraft:ochre_froglight
fill 465 222 243 465 308 243 minecraft:black_concrete
fill 465 222 255 465 258 255 minecraft:black_concrete
fill 424 223 229 424 223 234 minecraft:orange_terracotta
fill 425 223 229 429 223 229 minecraft:orange_terracotta
fill 425 223 231 427 223 234 minecraft:orange_terracotta
fill 426 223 230 429 223 230 minecraft:orange_terracotta
fill 428 223 231 428 223 233 minecraft:orange_terracotta
fill 429 223 231 429 223 232 minecraft:orange_terracotta
setblock 442 223 228 minecraft:white_concrete
fill 445 223 242 448 225 243 minecraft:tuff
fill 446 223 241 447 225 241 minecraft:tuff
fill 446 223 244 448 225 244 minecraft:tuff
fill 448 223 270 448 253 270 minecraft:black_concrete
setblock 458 223 270 minecraft:black_concrete
setblock 465 223 269 minecraft:sea_lantern
setblock 423 224 259 minecraft:white_concrete
fill 424 224 229 426 224 236 minecraft:brown_terracotta
fill 427 224 229 428 224 235 minecraft:brown_terracotta
fill 429 224 229 429 224 234 minecraft:brown_terracotta
fill 430 224 229 430 224 233 minecraft:brown_terracotta
fill 431 224 229 431 224 231 minecraft:brown_terracotta
fill 442 224 228 442 230 228 minecraft:black_concrete
fill 445 224 241 445 225 241 minecraft:tuff
fill 445 224 244 445 226 244 minecraft:tuff
setblock 447 224 245 minecraft:tuff
fill 448 224 241 448 225 241 minecraft:tuff
fill 449 224 243 449 225 243 minecraft:tuff
setblock 450 224 270 minecraft:magenta_terracotta
setblock 458 224 270 minecraft:sea_lantern
setblock 464 224 228 minecraft:ochre_froglight
fill 465 224 269 465 249 269 minecraft:black_concrete
fill 423 225 259 423 227 259 minecraft:black_concrete
fill 424 225 229 427 225 237 minecraft:yellow_terracotta
fill 428 225 229 429 225 236 minecraft:yellow_terracotta
fill 430 225 229 430 225 235 minecraft:yellow_terracotta
fill 431 225 229 431 225 234 minecraft:yellow_terracotta
fill 432 225 229 432 225 232 minecraft:yellow_terracotta
setblock 449 225 242 minecraft:tuff
fill 450 225 270 450 226 270 minecraft:black_concrete
fill 458 225 270 458 261 270 minecraft:black_concrete
fill 464 225 228 464 250 228 minecraft:black_concrete
fill 424 226 229 427 227 238 minecraft:orange_terracotta
setblock 426 226 245 minecraft:light[level=12]
setblock 426 226 252 minecraft:light[level=12]
setblock 426 226 259 minecraft:light[level=12]
setblock 426 226 266 minecraft:light[level=12]
fill 428 226 229 429 227 237 minecraft:orange_terracotta
fill 430 226 229 430 227 236 minecraft:orange_terracotta
fill 431 226 229 431 227 235 minecraft:orange_terracotta
fill 432 226 229 432 227 234 minecraft:orange_terracotta
fill 433 226 229 433 227 232 minecraft:orange_terracotta
setblock 433 226 238 minecraft:light[level=12]
setblock 433 226 245 minecraft:light[level=12]
setblock 433 226 252 minecraft:light[level=12]
setblock 433 226 259 minecraft:light[level=12]
setblock 433 226 266 minecraft:light[level=12]
setblock 436 226 270 minecraft:sea_lantern
setblock 440 226 231 minecraft:light[level=12]
setblock 440 226 238 minecraft:light[level=12]
setblock 440 226 245 minecraft:light[level=12]
setblock 440 226 252 minecraft:light[level=12]
setblock 440 226 259 minecraft:light[level=12]
setblock 440 226 266 minecraft:light[level=12]
setblock 444 226 228 minecraft:pearlescent_froglight
fill 445 226 243 448 226 243 minecraft:tuff
fill 446 226 242 448 226 242 minecraft:tuff
fill 446 226 244 447 226 244 minecraft:tuff
setblock 447 226 231 minecraft:light[level=12]
setblock 447 226 238 minecraft:light[level=12]
setblock 447 226 241 minecraft:tuff
setblock 447 226 245 minecraft:light[level=12]
setblock 447 226 252 minecraft:light[level=12]
setblock 447 226 259 minecraft:light[level=12]
setblock 447 226 266 minecraft:light[level=12]
fill 448 226 232 450 226 234 minecraft:orange_concrete
setblock 454 226 228 minecraft:white_concrete
setblock 454 226 231 minecraft:light[level=12]
setblock 454 226 238 minecraft:light[level=12]
setblock 454 226 245 minecraft:light[level=12]
setblock 454 226 252 minecraft:light[level=12]
setblock 454 226 259 minecraft:light[level=12]
setblock 454 226 266 minecraft:light[level=12]
setblock 461 226 231 minecraft:light[level=12]
setblock 461 226 238 minecraft:light[level=12]
setblock 461 226 245 minecraft:light[level=12]
setblock 461 226 252 minecraft:light[level=12]
setblock 461 226 259 minecraft:light[level=12]
setblock 461 226 266 minecraft:light[level=12]
setblock 462 226 270 minecraft:blue_concrete
setblock 465 226 261 minecraft:magenta_terracotta
setblock 426 227 239 minecraft:light[level=15]
setblock 426 227 247 minecraft:light[level=15]
setblock 426 227 255 minecraft:light[level=15]
setblock 426 227 263 minecraft:light[level=15]
setblock 426 227 270 minecraft:sea_lantern
fill 428 227 238 429 227 238 minecraft:orange_terracotta
setblock 430 227 237 minecraft:orange_terracotta
setblock 431 227 236 minecraft:orange_terracotta
setblock 431 227 270 minecraft:ochre_froglight
setblock 432 227 235 minecraft:orange_terracotta
fill 433 227 233 433 227 234 minecraft:orange_terracotta
setblock 434 227 231 minecraft:light[level=15]
setblock 434 227 239 minecraft:light[level=15]
setblock 434 227 247 minecraft:light[level=15]
setblock 434 227 255 minecraft:light[level=15]
setblock 434 227 263 minecraft:light[level=15]
fill 436 227 270 436 260 270 minecraft:black_concrete
setblock 442 227 231 minecraft:light[level=15]
setblock 442 227 239 minecraft:light[level=15]
setblock 442 227 247 minecraft:light[level=15]
setblock 442 227 255 minecraft:light[level=15]
setblock 442 227 263 minecraft:light[level=15]
fill 444 227 228 444 240 228 minecraft:black_concrete
setblock 447 227 243 minecraft:tuff
fill 448 227 233 450 227 233 minecraft:orange_concrete
setblock 449 227 232 minecraft:orange_concrete
setblock 449 227 234 minecraft:orange_concrete
setblock 450 227 231 minecraft:light[level=15]
setblock 450 227 239 minecraft:light[level=15]
setblock 450 227 247 minecraft:light[level=15]
setblock 450 227 255 minecraft:light[level=15]
setblock 450 227 263 minecraft:light[level=15]
setblock 450 227 270 minecraft:pearlescent_froglight
setblock 453 227 228 minecraft:magenta_terracotta
fill 454 227 228 454 251 228 minecraft:black_concrete
setblock 456 227 228 minecraft:magenta_terracotta
fill 457 227 252 458 228 252 minecraft:end_stone
setblock 458 227 231 minecraft:light[level=15]
setblock 458 227 239 minecraft:light[level=15]
setblock 458 227 247 minecraft:light[level=15]
setblock 458 227 255 minecraft:light[level=15]
setblock 458 227 263 minecraft:light[level=15]
fill 462 227 270 462 237 270 minecraft:black_concrete
setblock 465 227 235 minecraft:pearlescent_froglight
fill 465 227 261 465 240 261 minecraft:black_concrete
setblock 423 228 247 minecraft:ochre_froglight
setblock 423 228 259 minecraft:pearlescent_froglight
fill 424 228 229 428 229 239 minecraft:yellow_terracotta
fill 426 228 270 426 264 270 minecraft:black_concrete
fill 429 228 229 430 229 238 minecraft:yellow_terracotta
fill 431 228 229 431 229 237 minecraft:yellow_terracotta
fill 431 228 270 431 273 270 minecraft:black_concrete
fill 432 228 229 432 229 236 minecraft:yellow_terracotta
fill 433 228 229 433 229 235 minecraft:yellow_terracotta
fill 434 228 229 434 229 233 minecraft:yellow_terracotta
setblock 449 228 228 minecraft:ochre_froglight
fill 449 228 233 449 229 233 minecraft:orange_concrete
fill 450 228 270 450 244 270 minecraft:black_concrete
fill 453 228 228 453 246 228 minecraft:black_concrete
fill 456 228 228 456 229 228 minecraft:black_concrete
fill 465 228 235 465 298 235 minecraft:black_concrete
setblock 465 228 246 minecraft:pearlescent_froglight
setblock 423 229 240 minecraft:pearlescent_froglight
fill 423 229 247 423 235 247 minecraft:black_concrete
fill 423 229 258 423 230 258 minecraft:ochre_froglight
fill 423 229 259 423 288 259 minecraft:black_concrete
setblock 429 229 228 minecraft:purple_concrete
setblock 429 229 239 minecraft:yellow_terracotta
setblock 432 229 237 minecraft:yellow_terracotta
setblock 434 229 234 minecraft:yellow_terracotta
fill 449 229 228 449 264 228 minecraft:black_concrete
fill 465 229 246 465 254 246 minecraft:black_concrete
fill 423 230 240 423 308 240 minecraft:black_concrete
setblock 423 230 243 minecraft:pearlescent_froglight
fill 424 230 229 427 230 240 minecraft:orange_terracotta
setblock 425 230 228 minecraft:sea_lantern
fill 428 230 229 429 230 239 minecraft:orange_terracotta
fill 429 230 228 429 231 228 minecraft:black_concrete
fill 430 230 229 431 230 238 minecraft:orange_terracotta
fill 432 230 229 432 230 237 minecraft:orange_terracotta
fill 433 230 229 433 230 236 minecraft:orange_terracotta
fill 434 230 229 434 230 234 minecraft:orange_terracotta
fill 435 230 229 435 230 232 minecraft:orange_terracotta
fill 438 230 254 439 235 254 minecraft:andesite
setblock 456 230 228 minecraft:pearlescent_froglight
setblock 465 230 258 minecraft:pearlescent_froglight
fill 423 231 243 423 243 243 minecraft:black_concrete
setblock 423 231 250 minecraft:ochre_froglight
fill 423 231 258 423 242 258 minecraft:black_concrete
fill 424 231 229 427 231 240 minecraft:brown_terracotta
fill 425 231 228 425 304 228 minecraft:black_concrete
fill 428 231 229 430 231 239 minecraft:brown_terracotta
fill 431 231 229 431 231 238 minecraft:brown_terracotta
fill 432 231 229 432 231 237 minecraft:brown_terracotta
fill 433 231 229 433 231 236 minecraft:brown_terracotta
fill 434 231 229 434 231 235 minecraft:brown_terracotta
fill 435 231 229 435 231 232 minecraft:brown_terracotta
fill 435 231 238 436 231 241 minecraft:white_terracotta
setblock 436 231 228 minecraft:pearlescent_froglight
fill 436 231 236 438 231 237 minecraft:white_terracotta
fill 437 231 234 439 231 235 minecraft:white_terracotta
fill 437 231 238 437 231 239 minecraft:white_terracotta
fill 437 231 253 440 233 253 minecraft:andesite
fill 438 231 229 440 231 233 minecraft:white_terracotta
setblock 438 231 238 minecraft:white_terracotta
setblock 439 231 236 minecraft:white_terracotta
fill 439 231 255 440 234 255 minecraft:andesite
setblock 440 231 234 minecraft:white_terracotta
fill 440 231 254 440 234 254 minecraft:andesite
setblock 442 231 228 minecraft:sea_lantern
fill 456 231 228 456 288 228 minecraft:black_concrete
fill 465 231 258 465 247 258 minecraft:black_concrete
setblock 423 232 230 minecraft:ochre_froglight
fill 423 232 250 423 308 250 minecraft:black_concrete
setblock 423 232 252 minecraft:ochre_froglight
fill 424 232 229 428 233 240 minecraft:yellow_terracotta
setblock 426 232 245 minecraft:light[level=12]
setblock 426 232 252 minecraft:light[level=12]
setblock 426 232 259 minecraft:light[level=12]
setblock 426 232 266 minecraft:light[level=12]
fill 428 232 243 429 232 245 minecraft:white_terracotta
setblock 429 232 228 minecraft:sea_lantern
fill 429 232 229 430 233 239 minecraft:yellow_terracotta
fill 429 232 242 434 232 242 minecraft:white_terracotta
fill 430 232 243 431 232 244 minecraft:white_terracotta
fill 431 232 229 431 233 238 minecraft:yellow_terracotta
fill 431 232 241 435 232 241 minecraft:white_terracotta
fill 432 232 229 432 233 237 minecraft:yellow_terracotta
fill 432 232 243 433 232 243 minecraft:white_terracotta
fill 433 232 229 433 233 236 minecraft:yellow_terracotta
setblock 433 232 238 minecraft:light[level=12]
fill 433 232 240 435 232 240 minecraft:white_terracotta
setblock 433 232 245 minecraft:light[level=12]
setblock 433 232 252 minecraft:light[level=12]
setblock 433 232 259 minecraft:light[level=12]
setblock 433 232 266 minecraft:light[level=12]
fill 434 232 229 434 233 235 minecraft:yellow_terracotta
fill 434 232 239 435 232 239 minecraft:white_terracotta
fill 435 232 229 435 233 233 minecraft:yellow_terracotta
setblock 435 232 238 minecraft:white_terracotta
fill 436 232 228 436 272 228 minecraft:black_concrete
fill 437 232 255 438 233 256 minecraft:andesite
fill 438 232 252 438 233 252 minecraft:andesite
setblock 439 232 256 minecraft:andesite
setblock 440 232 231 minecraft:light[level=12]
setblock 440 232 238 minecraft:light[level=12]
setblock 440 232 245 minecraft:light[level=12]
setblock 440 232 252 minecraft:light[level=12]
setblock 440 232 259 minecraft:light[level=12]
setblock 440 232 266 minecraft:light[level=12]
fill 441 232 253 441 233 254 minecraft:andesite
fill 442 232 228 442 243 228 minecraft:black_concrete
setblock 447 232 231 minecraft:light[level=12]
setblock 447 232 238 minecraft:light[level=12]
setblock 447 232 245 minecraft:light[level=12]
setblock 447 232 252 minecraft:light[level=12]
setblock 447 232 259 minecraft:light[level=12]
setblock 447 232 266 minecraft:light[level=12]
setblock 454 232 231 minecraft:light[level=12]
setblock 454 232 238 minecraft:light[level=12]
setblock 454 232 245 minecraft:light[level=12]
setblock 454 232 252 minecraft:light[level=12]
setblock 454 232 259 minecraft:light[level=12]
setblock 454 232 266 minecraft:light[level=12]
setblock 461 232 231 minecraft:light[level=12]
setblock 461 232 238 minecraft:light[level=12]
setblock 461 232 245 minecraft:light[level=12]
setblock 461 232 252 minecraft:light[level=12]
setblock 461 232 259 minecraft:light[level=12]
setblock 461 232 266 minecraft:light[level=12]
setblock 465 232 238 minecraft:magenta_terracotta
fill 423 233 230 423 308 230 minecraft:black_concrete
setblock 423 233 234 minecraft:ochre_froglight
setblock 423 233 235 minecraft:sea_lantern
setblock 423 233 252 minecraft:black_concrete
setblock 423 233 253 minecraft:sea_lantern
fill 424 233 243 428 233 245 minecraft:white_terracotta
fill 429 233 228 429 308 228 minecraft:black_concrete
setblock 437 233 228 minecraft:white_concrete
fill 439 233 252 439 234 252 minecraft:andesite
setblock 441 233 255 minecraft:andesite
setblock 453 233 270 minecraft:white_concrete
fill 465 233 238 465 250 238 minecraft:black_concrete
setblock 465 233 247 minecraft:purple_terracotta
setblock 423 234 233 minecraft:ochre_froglight
fill 423 234 234 423 246 235 minecraft:black_concrete
setblock 423 234 252 minecraft:white_concrete
fill 423 234 253 423 247 253 minecraft:black_concrete
fill 424 234 229 427 235 240 minecraft:orange_terracotta
setblock 426 234 247 minecraft:light[level=15]
setblock 426 234 255 minecraft:light[level=15]
setblock 426 234 263 minecraft:light[level=15]
fill 428 234 229 430 234 239 minecraft:orange_terracotta
fill 431 234 229 431 235 238 minecraft:orange_terracotta
fill 432 234 229 432 235 237 minecraft:orange_terracotta
fill 433 234 229 433 235 236 minecraft:orange_terracotta
fill 434 234 229 434 234 235 minecraft:orange_terracotta
setblock 434 234 239 minecraft:light[level=15]
setblock 434 234 247 minecraft:light[level=15]
setblock 434 234 255 minecraft:light[level=15]
setblock 434 234 263 minecraft:light[level=15]
fill 435 234 229 435 235 232 minecraft:orange_terracotta
fill 437 234 228 437 236 228 minecraft:black_concrete
fill 439 234 253 440 234 253 minecraft:andesite
setblock 442 234 231 minecraft:light[level=15]
setblock 442 234 239 minecraft:light[level=15]
setblock 442 234 247 minecraft:light[level=15]
setblock 442 234 255 minecraft:light[level=15]
setblock 442 234 263 minecraft:light[level=15]
setblock 446 234 228 minecraft:sea_lantern
setblock 450 234 231 minecraft:light[level=15]
setblock 450 234 239 minecraft:light[level=15]
setblock 450 234 247 minecraft:light[level=15]
setblock 450 234 255 minecraft:light[level=15]
setblock 450 234 263 minecraft:light[level=15]
fill 453 234 270 453 308 270 minecraft:black_concrete
setblock 458 234 231 minecraft:light[level=15]
setblock 458 234 239 minecraft:light[level=15]
setblock 458 234 247 minecraft:light[level=15]
setblock 458 234 255 minecraft:light[level=15]
setblock 458 234 263 minecraft:light[level=15]
fill 465 234 247 465 236 247 minecraft:black_concrete
fill 465 234 249 465 278 249 minecraft:black_concrete
setblock 465 234 250 minecraft:ochre_froglight
fill 423 235 233 423 308 233 minecraft:black_concrete
fill 423 235 252 423 262 252 minecraft:black_concrete
fill 428 235 229 429 235 239 minecraft:orange_terracotta
fill 430 235 229 430 235 238 minecraft:orange_terracotta
fill 434 235 229 434 235 234 minecraft:orange_terracotta
setblock 439 235 253 minecraft:andesite
fill 446 235 228 446 279 228 minecraft:black_concrete
setblock 446 235 270 minecraft:sea_lantern
setblock 452 235 228 minecraft:sea_lantern
fill 465 235 250 465 254 250 minecraft:black_concrete
setblock 423 236 247 minecraft:purple_concrete
setblock 423 236 262 minecraft:purple_terracotta
fill 424 236 229 429 236 239 minecraft:yellow_terracotta
fill 430 236 229 430 237 238 minecraft:yellow_terracotta
fill 431 236 229 432 236 237 minecraft:yellow_terracotta
fill 433 236 229 433 237 235 minecraft:yellow_terracotta
fill 434 236 229 434 236 234 minecraft:yellow_terracotta
setblock 440 236 228 minecraft:ochre_froglight
setblock 446 236 270 minecraft:ochre_froglight
fill 452 236 228 452 240 228 minecraft:black_concrete
setblock 458 236 228 minecraft:pearlescent_froglight
setblock 465 236 266 minecraft:sea_lantern
setblock 423 237 236 minecraft:white_concrete
setblock 423 237 247 minecraft:magenta_terracotta
fill 423 237 262 423 260 262 minecraft:black_concrete
fill 424 237 229 428 237 239 minecraft:yellow_terracotta
setblock 427 237 228 minecraft:black_concrete
setblock 428 237 228 minecraft:pearlescent_froglight
fill 429 237 229 429 237 238 minecraft:yellow_terracotta
fill 431 237 229 431 237 237 minecraft:yellow_terracotta
fill 432 237 229 432 237 236 minecraft:yellow_terracotta
fill 434 237 229 434 237 233 minecraft:yellow_terracotta
setblock 437 237 228 minecraft:magenta_terracotta
fill 440 237 228 440 243 228 minecraft:black_concrete
fill 446 237 270 446 284 270 minecraft:black_concrete
setblock 455 237 270 minecraft:sea_lantern
fill 458 237 228 458 296 228 minecraft:black_concrete
setblock 465 237 247 minecraft:sea_lantern
fill 465 237 266 465 261 266 minecraft:black_concrete
setblock 423 238 236 minecraft:black_concrete
fill 423 238 247 423 307 247 minecraft:black_concrete
fill 424 238 229 429 238 238 minecraft:brown_terracotta
setblock 426 238 245 minecraft:light[level=12]
setblock 426 238 252 minecraft:light[level=12]
setblock 426 238 259 minecraft:light[level=12]
setblock 426 238 266 minecraft:light[level=12]
setblock 427 238 228 minecraft:purple_concrete
fill 428 238 228 428 249 228 minecraft:black_concrete
fill 430 238 229 430 238 237 minecraft:brown_terracotta
setblock 431 238 228 minecraft:pearlescent_froglight
fill 431 238 229 431 238 236 minecraft:brown_terracotta
fill 432 238 229 432 238 235 minecraft:brown_terracotta
fill 433 238 229 433 238 234 minecraft:brown_terracotta
setblock 433 238 238 minecraft:light[level=12]
setblock 433 238 245 minecraft:light[level=12]
setblock 433 238 252 minecraft:light[level=12]
setblock 433 238 259 minecraft:light[level=12]
setblock 433 238 266 minecraft:light[level=12]
fill 437 238 228 437 241 228 minecraft:black_concrete
setblock 440 238 231 minecraft:light[level=12]
setblock 440 238 238 minecraft:light[level=12]
setblock 440 238 245 minecraft:light[level=12]
setblock 440 238 252 minecraft:light[level=12]
setblock 440 238 259 minecraft:light[level=12]
setblock 440 238 266 minecraft:light[level=12]
setblock 445 238 228 minecraft:ochre_froglight
setblock 447 238 231 minecraft:light[level=12]
setblock 447 238 238 minecraft:light[level=12]
setblock 447 238 245 minecraft:light[level=12]
setblock 447 238 252 minecraft:light[level=12]
setblock 447 238 259 minecraft:light[level=12]
setblock 447 238 266 minecraft:light[level=12]
setblock 454 238 231 minecraft:light[level=12]
setblock 454 238 238 minecraft:light[level=12]
setblock 454 238 245 minecraft:light[level=12]
setblock 454 238 252 minecraft:light[level=12]
setblock 454 238 259 minecraft:light[level=12]
setblock 454 238 266 minecraft:light[level=12]
fill 455 238 270 455 308 270 minecraft:black_concrete
setblock 461 238 231 minecraft:light[level=12]
setblock 461 238 238 minecraft:light[level=12]
setblock 461 238 245 minecraft:light[level=12]
setblock 461 238 252 minecraft:light[level=12]
setblock 461 238 259 minecraft:light[level=12]
setblock 461 238 266 minecraft:light[level=12]
setblock 462 238 270 minecraft:pearlescent_froglight
setblock 465 238 241 minecraft:pearlescent_froglight
fill 465 238 247 465 254 247 minecraft:black_concrete
setblock 423 239 236 minecraft:pearlescent_froglight
fill 424 239 229 427 239 238 minecraft:orange_terracotta
fill 427 239 228 427 308 228 minecraft:black_concrete
fill 428 239 229 429 239 237 minecraft:orange_terracotta
fill 430 239 229 430 239 236 minecraft:orange_terracotta
fill 431 239 228 431 255 228 minecraft:black_concrete
fill 431 239 229 431 239 235 minecraft:orange_terracotta
fill 432 239 229 432 239 234 minecraft:orange_terracotta
fill 433 239 229 433 239 232 minecraft:orange_terracotta
fill 445 239 228 445 271 228 minecraft:black_concrete
fill 462 239 270 462 269 270 minecraft:black_concrete
setblock 465 239 230 minecraft:purple_terracotta
fill 465 239 241 465 270 241 minecraft:black_concrete
setblock 465 239 257 minecraft:ochre_froglight
fill 423 240 236 423 254 236 minecraft:black_concrete
fill 424 240 229 427 240 237 minecraft:yellow_terracotta
fill 428 240 229 429 240 236 minecraft:yellow_terracotta
fill 430 240 229 430 240 235 minecraft:yellow_terracotta
fill 431 240 229 431 240 234 minecraft:yellow_terracotta
fill 432 240 229 432 240 232 minecraft:yellow_terracotta
setblock 433 240 228 minecraft:sea_lantern
setblock 434 240 270 minecraft:pearlescent_froglight
fill 465 240 230 465 308 230 minecraft:black_concrete
setblock 465 240 232 minecraft:blue_concrete
fill 465 240 257 465 298 257 minecraft:black_concrete
setblock 465 240 260 minecraft:pearlescent_froglight
setblock 423 241 260 minecraft:white_concrete
fill 424 241 229 426 241 236 minecraft:yellow_terracotta
setblock 426 241 239 minecraft:light[level=15]
setblock 426 241 247 minecraft:light[level=15]
setblock 426 241 255 minecraft:light[level=15]
setblock 426 241 263 minecraft:light[level=15]
fill 427 241 229 428 241 235 minecraft:yellow_terracotta
fill 429 241 229 429 241 234 minecraft:yellow_terracotta
fill 430 241 229 430 241 233 minecraft:yellow_terracotta
fill 431 241 229 431 241 231 minecraft:yellow_terracotta
fill 433 241 228 433 287 228 minecraft:black_concrete
setblock 434 241 231 minecraft:light[level=15]
setblock 434 241 239 minecraft:light[level=15]
setblock 434 241 247 minecraft:light[level=15]
setblock 434 241 255 minecraft:light[level=15]
setblock 434 241 263 minecraft:light[level=15]
fill 434 241 270 434 308 270 minecraft:black_concrete
setblock 442 241 231 minecraft:light[level=15]
setblock 442 241 239 minecraft:light[level=15]
setblock 442 241 247 minecraft:light[level=15]
setblock 442 241 255 minecraft:light[level=15]
setblock 442 241 263 minecraft:light[level=15]
setblock 444 241 228 minecraft:ochre_froglight
setblock 450 241 228 minecraft:sea_lantern
setblock 450 241 231 minecraft:light[level=15]
setblock 450 241 239 minecraft:light[level=15]
setblock 450 241 247 minecraft:light[level=15]
setblock 450 241 255 minecraft:light[level=15]
setblock 450 241 263 minecraft:light[level=15]
setblock 452 241 228 minecraft:pearlescent_froglight
setblock 458 241 231 minecraft:light[level=15]
setblock 458 241 239 minecraft:light[level=15]
setblock 458 241 247 minecraft:light[level=15]
setblock 458 241 255 minecraft:light[level=15]
setblock 458 241 263 minecraft:light[level=15]
fill 465 241 232 465 265 232 minecraft:black_concrete
fill 465 241 260 465 266 260 minecraft:black_concrete
setblock 465 241 261 minecraft:pearlescent_froglight
setblock 423 242 246 minecraft:sea_lantern
fill 423 242 260 423 308 260 minecraft:black_concrete
fill 424 242 229 427 242 234 minecraft:orange_terracotta
fill 428 242 229 428 242 233 minecraft:orange_terracotta
fill 429 242 229 429 242 232 minecraft:orange_terracotta
setblock 437 242 228 minecraft:white_concrete
fill 444 242 228 444 244 228 minecraft:black_concrete
fill 450 242 228 450 244 228 minecraft:black_concrete
fill 452 242 228 452 278 228 minecraft:black_concrete
setblock 457 242 270 minecraft:sea_lantern
fill 465 242 261 465 270 261 minecraft:black_concrete
fill 423 243 246 423 306 246 minecraft:black_concrete
setblock 423 243 258 minecraft:pearlescent_froglight
setblock 423 243 268 minecraft:pearlescent_froglight
setblock 425 243 230 minecraft:orange_terracotta
fill 437 243 228 437 305 228 minecraft:black_concrete
fill 440 243 241 441 244 242 minecraft:end_stone
fill 457 243 270 457 308 270 minecraft:black_concrete
setblock 423 244 243 minecraft:ochre_froglight
setblock 423 244 251 minecraft:ochre_froglight
fill 423 244 258 423 303 258 minecraft:black_concrete
setblock 423 244 266 minecraft:sea_lantern
fill 423 244 268 423 308 268 minecraft:black_concrete
setblock 426 244 231 minecraft:light[level=12]
setblock 426 244 238 minecraft:light[level=12]
setblock 426 244 245 minecraft:light[level=12]
setblock 426 244 252 minecraft:light[level=12]
setblock 426 244 259 minecraft:light[level=12]
setblock 426 244 266 minecraft:light[level=12]
setblock 433 244 231 minecraft:light[level=12]
setblock 433 244 238 minecraft:light[level=12]
setblock 433 244 245 minecraft:light[level=12]
setblock 433 244 252 minecraft:light[level=12]
setblock 433 244 259 minecraft:light[level=12]
setblock 433 244 266 minecraft:light[level=12]
setblock 440 244 228 minecraft:pearlescent_froglight
setblock 440 244 231 minecraft:light[level=12]
setblock 440 244 238 minecraft:light[level=12]
setblock 440 244 245 minecraft:light[level=12]
setblock 440 244 252 minecraft:light[level=12]
setblock 440 244 259 minecraft:light[level=12]
setblock 440 244 266 minecraft:light[level=12]
setblock 442 244 228 minecraft:white_concrete
setblock 447 244 231 minecraft:light[level=12]
setblock 447 244 238 minecraft:light[level=12]
setblock 447 244 245 minecraft:light[level=12]
setblock 447 244 252 minecraft:light[level=12]
setblock 447 244 259 minecraft:light[level=12]
setblock 447 244 266 minecraft:light[level=12]
setblock 454 244 231 minecraft:light[level=12]
setblock 454 244 238 minecraft:light[level=12]
setblock 454 244 245 minecraft:light[level=12]
setblock 454 244 252 minecraft:light[level=12]
setblock 454 244 259 minecraft:light[level=12]
setblock 454 244 266 minecraft:light[level=12]
setblock 461 244 231 minecraft:light[level=12]
setblock 461 244 238 minecraft:light[level=12]
setblock 461 244 245 minecraft:light[level=12]
setblock 461 244 252 minecraft:light[level=12]
setblock 461 244 259 minecraft:light[level=12]
setblock 461 244 266 minecraft:light[level=12]
setblock 462 244 228 minecraft:ochre_froglight
setblock 423 245 239 minecraft:white_concrete
fill 423 245 243 423 270 243 minecraft:black_concrete
fill 423 245 251 423 284 251 minecraft:black_concrete
fill 423 245 266 423 305 266 minecraft:black_concrete
fill 440 245 228 440 308 228 minecraft:black_concrete
fill 442 245 228 442 308 228 minecraft:black_concrete
setblock 444 245 228 minecraft:sea_lantern
setblock 450 245 228 minecraft:purple_concrete
setblock 450 245 270 minecraft:ochre_froglight
fill 462 245 228 462 308 228 minecraft:black_concrete
setblock 465 245 239 minecraft:sea_lantern
setblock 465 245 248 minecraft:purple_concrete
setblock 465 245 251 minecraft:sea_lantern
fill 423 246 239 423 294 239 minecraft:black_concrete
setblock 439 246 270 minecraft:pearlescent_froglight
fill 444 246 228 444 247 228 minecraft:black_concrete
fill 450 246 228 450 281 228 minecraft:black_concrete
fill 450 246 270 450 308 270 minecraft:black_concrete
setblock 459 246 228 minecraft:white_concrete
fill 465 246 239 465 278 239 minecraft:black_concrete
setblock 465 246 245 minecraft:white_concrete
setblock 465 246 248 minecraft:pearlescent_froglight
fill 465 246 251 465 308 251 minecraft:black_concrete
setblock 423 247 234 minecraft:ochre_froglight
fill 423 247 235 423 308 235 minecraft:black_concrete
fill 439 247 270 439 308 270 minecraft:black_concrete
fill 451 247 270 451 277 270 minecraft:black_concrete
setblock 452 247 270 minecraft:pearlescent_froglight
setblock 453 247 228 minecraft:magenta_terracotta
fill 459 247 228 459 248 228 minecraft:black_concrete
fill 465 247 245 465 308 245 minecraft:black_concrete
fill 465 247 248 465 308 248 minecraft:black_concrete
setblock 423 248 231 minecraft:pearlescent_froglight
fill 423 248 234 423 308 234 minecraft:black_concrete
setblock 423 248 253 minecraft:sea_lantern
setblock 426 248 231 minecraft:light[level=15]
setblock 426 248 239 minecraft:light[level=15]
setblock 426 248 247 minecraft:light[level=15]
fill 426 248 248 428 250 250 minecraft:gold_block
setblock 426 248 255 minecraft:light[level=15]
setblock 426 248 263 minecraft:light[level=15]
setblock 434 248 231 minecraft:light[level=15]
setblock 434 248 239 minecraft:light[level=15]
setblock 434 248 247 minecraft:light[level=15]
setblock 434 248 255 minecraft:light[level=15]
setblock 434 248 263 minecraft:light[level=15]
setblock 442 248 231 minecraft:light[level=15]
setblock 442 248 239 minecraft:light[level=15]
setblock 442 248 247 minecraft:light[level=15]
setblock 442 248 255 minecraft:light[level=15]
setblock 442 248 263 minecraft:light[level=15]
setblock 444 248 228 minecraft:ochre_froglight
setblock 450 248 231 minecraft:light[level=15]
setblock 450 248 239 minecraft:light[level=15]
setblock 450 248 247 minecraft:light[level=15]
setblock 450 248 255 minecraft:light[level=15]
setblock 450 248 263 minecraft:light[level=15]
fill 452 248 270 452 268 270 minecraft:black_concrete
fill 453 248 228 453 266 228 minecraft:black_concrete
setblock 458 248 231 minecraft:light[level=15]
setblock 458 248 239 minecraft:light[level=15]
setblock 458 248 247 minecraft:light[level=15]
setblock 458 248 255 minecraft:light[level=15]
setblock 458 248 263 minecraft:light[level=15]
setblock 463 248 270 minecraft:pearlescent_froglight
setblock 465 248 258 minecraft:white_concrete
fill 423 249 231 423 257 231 minecraft:black_concrete
fill 423 249 253 423 260 253 minecraft:black_concrete
fill 426 249 243 428 249 247 minecraft:blue_stained_glass
fill 426 249 251 428 249 255 minecraft:blue_stained_glass
setblock 428 249 270 minecraft:pearlescent_froglight
setblock 435 249 270 minecraft:pearlescent_froglight
fill 444 249 228 444 254 228 minecraft:black_concrete
setblock 459 249 228 minecraft:white_concrete
fill 463 249 270 463 251 270 minecraft:black_concrete
setblock 465 249 236 minecraft:sea_lantern
fill 465 249 258 465 282 258 minecraft:black_concrete
setblock 426 250 231 minecraft:light[level=12]
setblock 426 250 238 minecraft:light[level=12]
setblock 426 250 245 minecraft:light[level=12]
setblock 426 250 252 minecraft:light[level=12]
setblock 426 250 259 minecraft:light[level=12]
setblock 426 250 266 minecraft:light[level=12]
setblock 428 250 228 minecraft:pearlescent_froglight
fill 428 250 270 428 276 270 minecraft:black_concrete
setblock 433 250 231 minecraft:light[level=12]
setblock 433 250 238 minecraft:light[level=12]
setblock 433 250 245 minecraft:light[level=12]
setblock 433 250 252 minecraft:light[level=12]
setblock 433 250 259 minecraft:light[level=12]
setblock 433 250 266 minecraft:light[level=12]
fill 435 250 270 435 256 270 minecraft:black_concrete
setblock 440 250 231 minecraft:light[level=12]
setblock 440 250 238 minecraft:light[level=12]
setblock 440 250 245 minecraft:light[level=12]
setblock 440 250 252 minecraft:light[level=12]
setblock 440 250 259 minecraft:light[level=12]
setblock 440 250 266 minecraft:light[level=12]
setblock 447 250 231 minecraft:light[level=12]
setblock 447 250 238 minecraft:light[level=12]
setblock 447 250 245 minecraft:light[level=12]
setblock 447 250 252 minecraft:light[level=12]
setblock 447 250 259 minecraft:light[level=12]
setblock 447 250 266 minecraft:light[level=12]
setblock 454 250 231 minecraft:light[level=12]
setblock 454 250 238 minecraft:light[level=12]
setblock 454 250 245 minecraft:light[level=12]
setblock 454 250 252 minecraft:light[level=12]
setblock 454 250 259 minecraft:light[level=12]
setblock 454 250 266 minecraft:light[level=12]
fill 459 250 228 459 308 228 minecraft:black_concrete
setblock 461 250 231 minecraft:light[level=12]
setblock 461 250 238 minecraft:light[level=12]
setblock 461 250 245 minecraft:light[level=12]
setblock 461 250 252 minecraft:light[level=12]
setblock 461 250 259 minecraft:light[level=12]
setblock 461 250 266 minecraft:light[level=12]
setblock 465 250 229 minecraft:white_concrete
setblock 465 250 236 minecraft:black_concrete
setblock 465 250 269 minecraft:ochre_froglight
fill 427 251 249 427 252 249 minecraft:iron_bars
fill 428 251 228 428 303 228 minecraft:black_concrete
setblock 435 251 228 minecraft:white_concrete
setblock 438 251 270 minecraft:blue_concrete
fill 447 251 238 449 252 238 minecraft:gray_concrete
fill 448 251 239 449 252 239 minecraft:gray_concrete
setblock 464 251 228 minecraft:white_concrete
setblock 464 251 270 minecraft:ochre_froglight
fill 465 251 229 465 288 229 minecraft:black_concrete
setblock 465 251 236 minecraft:sea_lantern
setblock 465 251 238 minecraft:white_concrete
fill 465 251 269 465 308 269 minecraft:black_concrete
fill 435 252 228 435 273 228 minecraft:black_concrete
fill 438 252 270 438 308 270 minecraft:black_concrete
setblock 451 252 228 minecraft:purple_concrete
setblock 454 252 228 minecraft:ochre_froglight
setblock 460 252 270 minecraft:blue_concrete
setblock 463 252 270 minecraft:pearlescent_froglight
fill 464 252 228 464 304 228 minecraft:black_concrete
fill 464 252 270 464 269 270 minecraft:black_concrete
fill 465 252 236 465 275 236 minecraft:black_concrete
fill 465 252 238 465 274 238 minecraft:black_concrete
setblock 434 253 228 minecraft:white_concrete
fill 451 253 228 451 274 228 minecraft:black_concrete
fill 454 253 228 454 303 228 minecraft:black_concrete
setblock 455 253 228 minecraft:ochre_froglight
fill 460 253 270 460 291 270 minecraft:black_concrete
setblock 461 253 228 minecraft:pearlescent_froglight
fill 463 253 270 463 282 270 minecraft:black_concrete
setblock 423 254 237 minecraft:pearlescent_froglight
fill 434 254 228 434 256 228 minecraft:black_concrete
setblock 448 254 270 minecraft:sea_lantern
schedule function dropper:buildpart/57_4 1t
