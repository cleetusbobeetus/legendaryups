fill 555 119 419 555 119 421 minecraft:white_wool
setblock 555 119 422 minecraft:light_gray_wool
fill 555 119 423 555 119 425 minecraft:white_wool
setblock 555 119 426 minecraft:light_gray_wool
fill 555 119 427 555 119 429 minecraft:white_wool
setblock 555 119 430 minecraft:light_gray_wool
fill 555 119 431 557 119 431 minecraft:white_wool
setblock 555 119 434 minecraft:light_gray_wool
fill 555 119 435 557 119 435 minecraft:white_wool
setblock 555 119 438 minecraft:light_gray_wool
fill 555 119 439 557 119 439 minecraft:white_wool
setblock 555 119 442 minecraft:light_gray_wool
fill 555 119 443 557 119 443 minecraft:white_wool
setblock 555 119 446 minecraft:light_gray_wool
fill 555 119 447 557 119 447 minecraft:white_wool
setblock 555 119 450 minecraft:light_gray_wool
fill 555 119 451 557 119 451 minecraft:white_wool
setblock 555 119 454 minecraft:light_gray_wool
fill 555 119 455 557 119 455 minecraft:white_wool
setblock 556 119 416 minecraft:black_concrete
setblock 556 119 417 minecraft:light_gray_wool
fill 556 119 418 556 119 420 minecraft:white_wool
setblock 556 119 421 minecraft:light_gray_wool
fill 556 119 422 556 119 424 minecraft:white_wool
setblock 556 119 425 minecraft:light_gray_wool
fill 556 119 426 556 119 428 minecraft:white_wool
setblock 556 119 429 minecraft:light_gray_wool
fill 556 119 430 558 119 430 minecraft:white_wool
setblock 556 119 433 minecraft:light_gray_wool
fill 556 119 434 558 119 434 minecraft:white_wool
setblock 556 119 437 minecraft:light_gray_wool
fill 556 119 438 558 119 438 minecraft:white_wool
setblock 556 119 441 minecraft:light_gray_wool
fill 556 119 442 558 119 442 minecraft:white_wool
setblock 556 119 445 minecraft:light_gray_wool
fill 556 119 446 558 119 446 minecraft:white_wool
setblock 556 119 449 minecraft:light_gray_wool
fill 556 119 450 558 119 450 minecraft:white_wool
setblock 556 119 453 minecraft:light_gray_wool
fill 556 119 454 558 119 454 minecraft:white_wool
setblock 556 119 457 minecraft:light_gray_wool
fill 557 119 416 559 122 416 minecraft:cobbled_deepslate
fill 557 119 417 557 119 419 minecraft:white_wool
setblock 557 119 420 minecraft:light_gray_wool
fill 557 119 421 557 119 423 minecraft:white_wool
setblock 557 119 424 minecraft:light_gray_wool
fill 557 119 425 557 119 427 minecraft:white_wool
setblock 557 119 428 minecraft:light_gray_wool
fill 557 119 429 558 119 429 minecraft:white_wool
setblock 557 119 432 minecraft:light_gray_wool
fill 557 119 433 558 119 433 minecraft:white_wool
setblock 557 119 436 minecraft:light_gray_wool
fill 557 119 437 558 119 437 minecraft:white_wool
setblock 557 119 440 minecraft:light_gray_wool
fill 557 119 441 558 119 441 minecraft:white_wool
setblock 557 119 444 minecraft:light_gray_wool
fill 557 119 445 558 119 445 minecraft:white_wool
setblock 557 119 448 minecraft:light_gray_wool
fill 557 119 449 558 119 449 minecraft:white_wool
setblock 557 119 452 minecraft:light_gray_wool
fill 557 119 453 558 119 453 minecraft:white_wool
setblock 557 119 456 minecraft:light_gray_wool
fill 557 119 457 558 119 457 minecraft:white_wool
fill 558 119 417 558 119 418 minecraft:white_wool
setblock 558 119 419 minecraft:light_gray_wool
fill 558 119 420 558 119 422 minecraft:white_wool
setblock 558 119 423 minecraft:light_gray_wool
fill 558 119 424 558 119 426 minecraft:white_wool
setblock 558 119 427 minecraft:light_gray_wool
setblock 558 119 428 minecraft:white_wool
setblock 558 119 431 minecraft:light_gray_wool
setblock 558 119 432 minecraft:white_wool
setblock 558 119 435 minecraft:light_gray_wool
setblock 558 119 436 minecraft:white_wool
setblock 558 119 439 minecraft:light_gray_wool
setblock 558 119 440 minecraft:white_wool
setblock 558 119 443 minecraft:light_gray_wool
setblock 558 119 444 minecraft:white_wool
setblock 558 119 447 minecraft:light_gray_wool
setblock 558 119 448 minecraft:white_wool
setblock 558 119 451 minecraft:light_gray_wool
setblock 558 119 452 minecraft:white_wool
setblock 558 119 455 minecraft:light_gray_wool
setblock 558 119 456 minecraft:white_wool
fill 559 119 417 559 119 427 minecraft:cobbled_deepslate
fill 559 119 428 559 119 429 minecraft:black_concrete
fill 559 119 430 559 119 447 minecraft:cobbled_deepslate
setblock 559 119 448 minecraft:black_concrete
fill 559 119 449 559 120 456 minecraft:cobbled_deepslate
setblock 559 119 457 minecraft:black_concrete
setblock 517 120 416 minecraft:black_concrete
fill 517 120 417 517 122 420 minecraft:cobbled_deepslate
setblock 517 120 421 minecraft:black_concrete
fill 517 120 422 517 122 432 minecraft:cobbled_deepslate
setblock 517 120 433 minecraft:black_concrete
fill 517 120 434 517 122 436 minecraft:cobbled_deepslate
fill 517 120 437 517 121 437 minecraft:black_concrete
fill 517 120 438 517 122 438 minecraft:cobbled_deepslate
setblock 517 120 439 minecraft:black_concrete
fill 517 120 440 517 122 446 minecraft:cobbled_deepslate
setblock 517 120 447 minecraft:black_concrete
fill 517 120 448 517 122 450 minecraft:cobbled_deepslate
setblock 517 120 451 minecraft:black_concrete
setblock 520 120 419 minecraft:light[level=12]
setblock 520 120 427 minecraft:light[level=12]
setblock 520 120 435 minecraft:light[level=12]
setblock 520 120 443 minecraft:light[level=12]
setblock 520 120 451 minecraft:light[level=12]
fill 524 120 458 524 122 458 minecraft:cobbled_deepslate
setblock 525 120 458 minecraft:black_concrete
fill 526 120 458 526 122 458 minecraft:cobbled_deepslate
setblock 527 120 458 minecraft:black_concrete
fill 528 120 416 534 120 416 minecraft:cobbled_deepslate
setblock 528 120 419 minecraft:light[level=12]
setblock 528 120 427 minecraft:light[level=12]
setblock 528 120 435 minecraft:light[level=12]
setblock 528 120 443 minecraft:light[level=12]
setblock 528 120 451 minecraft:light[level=12]
fill 528 120 458 540 120 458 minecraft:cobbled_deepslate
setblock 535 120 416 minecraft:black_concrete
fill 536 120 416 536 122 416 minecraft:cobbled_deepslate
setblock 536 120 419 minecraft:light[level=12]
setblock 536 120 427 minecraft:light[level=12]
setblock 536 120 443 minecraft:light[level=12]
setblock 536 120 451 minecraft:light[level=12]
fill 537 120 416 537 121 416 minecraft:black_concrete
fill 538 120 416 540 122 416 minecraft:cobbled_deepslate
setblock 541 120 416 minecraft:black_concrete
setblock 541 120 458 minecraft:black_concrete
fill 542 120 416 543 122 416 minecraft:cobbled_deepslate
fill 542 120 458 556 120 458 minecraft:cobbled_deepslate
setblock 544 120 419 minecraft:light[level=12]
setblock 544 120 427 minecraft:light[level=12]
setblock 544 120 435 minecraft:light[level=12]
setblock 544 120 443 minecraft:light[level=12]
setblock 544 120 451 minecraft:light[level=12]
fill 545 120 416 546 122 416 minecraft:cobbled_deepslate
setblock 547 120 416 minecraft:black_concrete
fill 548 120 416 551 122 416 minecraft:cobbled_deepslate
setblock 552 120 419 minecraft:light[level=12]
setblock 552 120 427 minecraft:light[level=12]
setblock 552 120 435 minecraft:light[level=12]
setblock 552 120 443 minecraft:light[level=12]
setblock 552 120 451 minecraft:light[level=12]
setblock 556 120 416 minecraft:cobbled_deepslate
setblock 557 120 458 minecraft:black_concrete
fill 558 120 458 559 122 458 minecraft:cobbled_deepslate
setblock 559 120 417 minecraft:black_concrete
fill 559 120 418 559 120 430 minecraft:cobbled_deepslate
setblock 559 120 431 minecraft:black_concrete
fill 559 120 432 559 122 433 minecraft:cobbled_deepslate
setblock 559 120 434 minecraft:black_concrete
fill 559 120 435 559 122 446 minecraft:cobbled_deepslate
setblock 559 120 447 minecraft:black_concrete
fill 559 120 448 559 122 448 minecraft:cobbled_deepslate
fill 559 120 457 559 122 457 minecraft:cobbled_deepslate
fill 517 121 416 521 122 416 minecraft:cobbled_deepslate
fill 517 121 421 517 122 421 minecraft:cobbled_deepslate
fill 517 121 433 517 122 433 minecraft:cobbled_deepslate
fill 517 121 439 517 122 439 minecraft:cobbled_deepslate
fill 517 121 447 517 122 447 minecraft:cobbled_deepslate
fill 517 121 451 517 122 455 minecraft:cobbled_deepslate
fill 517 121 456 517 121 457 minecraft:black_concrete
fill 517 121 458 522 122 458 minecraft:cobbled_deepslate
setblock 522 121 416 minecraft:black_concrete
fill 523 121 416 524 122 416 minecraft:cobbled_deepslate
setblock 523 121 458 minecraft:black_concrete
setblock 525 121 416 minecraft:black_concrete
fill 525 121 458 525 123 458 minecraft:cobbled_deepslate
fill 526 121 416 532 122 416 minecraft:cobbled_deepslate
fill 527 121 458 530 122 458 minecraft:cobbled_deepslate
setblock 531 121 458 minecraft:black_concrete
fill 532 121 458 532 122 458 minecraft:cobbled_deepslate
setblock 533 121 416 minecraft:black_concrete
setblock 533 121 458 minecraft:black_concrete
fill 534 121 416 535 122 416 minecraft:cobbled_deepslate
fill 534 121 458 549 122 458 minecraft:cobbled_deepslate
fill 541 121 416 541 123 416 minecraft:cobbled_deepslate
fill 547 121 416 547 122 416 minecraft:cobbled_deepslate
fill 550 121 458 551 121 458 minecraft:black_concrete
fill 552 121 458 557 122 458 minecraft:cobbled_deepslate
fill 553 121 416 553 122 416 minecraft:cobbled_deepslate
setblock 556 121 416 minecraft:black_concrete
fill 559 121 417 559 122 421 minecraft:cobbled_deepslate
setblock 559 121 422 minecraft:black_concrete
fill 559 121 423 559 124 423 minecraft:cobbled_deepslate
setblock 559 121 424 minecraft:black_concrete
fill 559 121 425 559 122 431 minecraft:cobbled_deepslate
fill 559 121 434 559 122 434 minecraft:cobbled_deepslate
fill 559 121 447 559 122 447 minecraft:cobbled_deepslate
setblock 559 121 449 minecraft:black_concrete
fill 559 121 450 559 122 451 minecraft:cobbled_deepslate
setblock 559 121 452 minecraft:black_concrete
fill 559 121 453 559 122 453 minecraft:cobbled_deepslate
setblock 559 121 454 minecraft:black_concrete
fill 559 121 455 559 122 455 minecraft:cobbled_deepslate
setblock 559 121 456 minecraft:black_concrete
setblock 517 122 437 minecraft:cobbled_deepslate
fill 517 122 456 517 122 457 minecraft:cobbled_deepslate
setblock 522 122 416 minecraft:cobbled_deepslate
setblock 523 122 458 minecraft:cobbled_deepslate
setblock 525 122 416 minecraft:cobbled_deepslate
setblock 531 122 458 minecraft:cobbled_deepslate
setblock 533 122 416 minecraft:cobbled_deepslate
setblock 533 122 458 minecraft:cobbled_deepslate
setblock 537 122 416 minecraft:cobbled_deepslate
fill 550 122 458 551 122 458 minecraft:cobbled_deepslate
setblock 556 122 416 minecraft:cobbled_deepslate
fill 559 122 422 559 123 422 minecraft:cobbled_deepslate
setblock 559 122 424 minecraft:cobbled_deepslate
setblock 559 122 449 minecraft:cobbled_deepslate
setblock 559 122 452 minecraft:cobbled_deepslate
setblock 559 122 454 minecraft:cobbled_deepslate
setblock 559 122 456 minecraft:cobbled_deepslate
fill 517 123 416 518 123 416 minecraft:cobbled_deepslate
fill 517 123 417 518 124 423 minecraft:black_concrete
fill 517 123 424 517 124 424 minecraft:cobbled_deepslate
fill 517 123 425 518 124 431 minecraft:black_concrete
setblock 517 123 432 minecraft:cobbled_deepslate
fill 517 123 433 517 123 457 minecraft:black_concrete
setblock 517 123 458 minecraft:cobbled_deepslate
fill 518 123 424 519 128 424 minecraft:black_concrete
fill 518 123 432 518 124 449 minecraft:black_concrete
setblock 518 123 458 minecraft:black_concrete
fill 519 123 416 522 123 417 minecraft:black_concrete
fill 519 123 419 519 123 423 minecraft:black_concrete
fill 519 123 425 519 126 428 minecraft:black_concrete
fill 519 123 437 519 123 446 minecraft:black_concrete
setblock 519 123 458 minecraft:cobbled_deepslate
fill 520 123 458 524 123 458 minecraft:black_concrete
setblock 523 123 416 minecraft:cobbled_deepslate
fill 523 123 417 559 123 417 minecraft:black_concrete
fill 524 123 416 540 123 416 minecraft:black_concrete
fill 524 123 418 542 123 418 minecraft:black_concrete
fill 526 123 419 539 123 419 minecraft:black_concrete
fill 526 123 458 539 123 458 minecraft:black_concrete
fill 527 123 420 537 123 420 minecraft:black_concrete
fill 528 123 457 557 123 457 minecraft:black_concrete
fill 530 123 421 534 123 421 minecraft:black_concrete
fill 531 123 456 537 123 456 minecraft:black_concrete
setblock 540 123 458 minecraft:cobbled_deepslate
fill 541 123 458 543 215 458 minecraft:black_concrete
fill 542 123 416 545 124 416 minecraft:black_concrete
setblock 544 123 458 minecraft:cobbled_deepslate
fill 545 123 418 556 123 418 minecraft:black_concrete
fill 545 123 458 559 123 458 minecraft:black_concrete
setblock 546 123 416 minecraft:cobbled_deepslate
fill 547 123 416 554 123 416 minecraft:black_concrete
fill 547 123 456 555 123 456 minecraft:black_concrete
fill 550 123 419 553 123 419 minecraft:black_concrete
fill 554 123 442 558 123 445 minecraft:black_concrete
setblock 555 123 416 minecraft:cobbled_deepslate
fill 555 123 439 559 123 441 minecraft:black_concrete
fill 555 123 446 559 124 448 minecraft:black_concrete
fill 556 123 416 558 215 416 minecraft:black_concrete
fill 556 123 437 559 123 438 minecraft:black_concrete
fill 556 123 449 559 125 449 minecraft:black_concrete
fill 557 123 419 558 123 426 minecraft:black_concrete
fill 557 123 435 559 123 436 minecraft:black_concrete
fill 557 123 450 559 123 451 minecraft:black_concrete
fill 558 123 418 559 124 418 minecraft:black_concrete
fill 558 123 427 558 124 434 minecraft:black_concrete
fill 558 123 452 559 123 453 minecraft:black_concrete
setblock 559 123 416 minecraft:cobbled_deepslate
setblock 559 123 419 minecraft:cobbled_deepslate
fill 559 123 420 559 215 421 minecraft:black_concrete
fill 559 123 424 559 124 427 minecraft:black_concrete
setblock 559 123 428 minecraft:cobbled_deepslate
fill 559 123 429 559 123 434 minecraft:black_concrete
setblock 559 123 442 minecraft:cobbled_deepslate
fill 559 123 443 559 215 443 minecraft:black_concrete
setblock 559 123 444 minecraft:cobbled_deepslate
fill 559 123 445 559 212 445 minecraft:black_concrete
fill 559 123 454 559 215 457 minecraft:black_concrete
setblock 517 124 416 minecraft:cobbled_deepslate
fill 517 124 432 517 211 433 minecraft:black_concrete
setblock 517 124 434 minecraft:cobbled_deepslate
fill 517 124 435 517 124 458 minecraft:black_concrete
fill 518 124 416 518 215 416 minecraft:black_concrete
setblock 518 124 458 minecraft:cobbled_deepslate
setblock 519 124 416 minecraft:cobbled_deepslate
fill 519 124 420 519 124 423 minecraft:black_concrete
fill 519 124 439 519 124 445 minecraft:black_concrete
fill 519 124 458 521 124 458 minecraft:black_concrete
fill 520 124 416 521 124 416 minecraft:black_concrete
setblock 522 124 416 minecraft:cobbled_deepslate
fill 522 124 417 557 124 417 minecraft:black_concrete
setblock 522 124 458 minecraft:cobbled_deepslate
fill 523 124 416 524 215 416 minecraft:black_concrete
fill 523 124 458 527 124 458 minecraft:black_concrete
fill 524 124 418 540 124 418 minecraft:black_concrete
setblock 525 124 416 minecraft:cobbled_deepslate
fill 526 124 416 530 124 416 minecraft:black_concrete
fill 526 124 419 538 124 419 minecraft:black_concrete
fill 527 124 420 536 124 420 minecraft:black_concrete
fill 528 124 457 556 124 457 minecraft:black_concrete
setblock 528 124 458 minecraft:cobbled_deepslate
fill 529 124 458 533 212 458 minecraft:black_concrete
fill 530 124 421 533 124 421 minecraft:black_concrete
setblock 531 124 416 minecraft:cobbled_deepslate
fill 531 124 456 535 124 456 minecraft:black_concrete
fill 532 124 416 539 211 416 minecraft:black_concrete
setblock 534 124 458 minecraft:cobbled_deepslate
setblock 535 124 458 minecraft:black_concrete
fill 536 124 458 537 124 458 minecraft:cobbled_deepslate
fill 538 124 458 540 124 458 minecraft:black_concrete
setblock 540 124 416 minecraft:cobbled_deepslate
fill 541 124 416 541 215 416 minecraft:black_concrete
fill 544 124 458 546 124 458 minecraft:black_concrete
fill 546 124 416 552 124 416 minecraft:black_concrete
fill 547 124 418 554 124 418 minecraft:black_concrete
setblock 547 124 458 minecraft:cobbled_deepslate
fill 548 124 456 554 124 456 minecraft:black_concrete
fill 548 124 458 553 215 458 minecraft:black_concrete
setblock 553 124 416 minecraft:cobbled_deepslate
fill 554 124 416 555 211 416 minecraft:black_concrete
fill 554 124 443 558 124 445 minecraft:black_concrete
setblock 554 124 458 minecraft:cobbled_deepslate
fill 555 124 440 559 124 442 minecraft:black_concrete
fill 555 124 458 559 213 458 minecraft:black_concrete
fill 556 124 438 559 124 439 minecraft:black_concrete
fill 557 124 421 558 124 426 minecraft:black_concrete
fill 557 124 436 559 124 437 minecraft:black_concrete
fill 557 124 450 559 125 450 minecraft:black_concrete
fill 558 124 419 558 124 420 minecraft:black_concrete
fill 558 124 435 559 125 435 minecraft:black_concrete
fill 558 124 451 559 124 452 minecraft:black_concrete
fill 559 124 416 559 124 417 minecraft:black_concrete
fill 559 124 419 559 211 419 minecraft:black_concrete
setblock 559 124 422 minecraft:black_concrete
fill 559 124 428 559 124 433 minecraft:black_concrete
setblock 559 124 434 minecraft:cobbled_deepslate
fill 559 124 444 559 213 444 minecraft:black_concrete
setblock 559 124 453 minecraft:cobbled_deepslate
fill 517 125 416 517 211 430 minecraft:black_concrete
setblock 517 125 431 minecraft:cobbled_deepslate
fill 517 125 434 518 125 437 minecraft:black_concrete
setblock 517 125 438 minecraft:cobbled_deepslate
fill 517 125 439 518 126 439 minecraft:black_concrete
setblock 517 125 440 minecraft:cobbled_deepslate
fill 517 125 441 518 126 441 minecraft:black_concrete
setblock 517 125 442 minecraft:cobbled_deepslate
fill 517 125 443 517 211 453 minecraft:black_concrete
setblock 517 125 454 minecraft:cobbled_deepslate
fill 517 125 455 517 215 455 minecraft:black_concrete
setblock 517 125 456 minecraft:cobbled_deepslate
fill 517 125 457 517 215 458 minecraft:black_concrete
fill 518 125 418 518 125 423 minecraft:black_concrete
fill 518 125 425 518 125 433 minecraft:black_concrete
setblock 518 125 438 minecraft:black_concrete
fill 518 125 440 518 126 440 minecraft:black_concrete
fill 518 125 442 518 125 448 minecraft:black_concrete
fill 518 125 458 519 212 458 minecraft:black_concrete
fill 519 125 416 520 215 416 minecraft:black_concrete
fill 519 125 421 519 125 423 minecraft:black_concrete
setblock 520 125 458 minecraft:cobbled_deepslate
setblock 521 125 416 minecraft:cobbled_deepslate
fill 521 125 458 526 211 458 minecraft:black_concrete
fill 522 125 416 522 215 416 minecraft:black_concrete
fill 523 125 417 555 125 417 minecraft:black_concrete
fill 525 125 416 526 215 416 minecraft:black_concrete
fill 525 125 418 538 125 418 minecraft:black_concrete
fill 526 125 419 536 125 419 minecraft:black_concrete
setblock 527 125 416 minecraft:cobbled_deepslate
setblock 527 125 458 minecraft:cobbled_deepslate
fill 528 125 416 531 212 416 minecraft:black_concrete
fill 528 125 420 534 125 420 minecraft:black_concrete
fill 528 125 457 528 153 458 minecraft:black_concrete
fill 529 125 457 539 125 457 minecraft:black_concrete
fill 531 125 456 534 125 456 minecraft:black_concrete
fill 534 125 458 534 215 458 minecraft:black_concrete
setblock 535 125 458 minecraft:cobbled_deepslate
fill 536 125 458 538 215 458 minecraft:black_concrete
setblock 539 125 458 minecraft:cobbled_deepslate
fill 540 125 416 540 215 416 minecraft:black_concrete
fill 540 125 458 540 212 458 minecraft:black_concrete
fill 542 125 416 544 211 416 minecraft:black_concrete
fill 544 125 457 544 125 458 minecraft:black_concrete
setblock 545 125 416 minecraft:cobbled_deepslate
fill 545 125 457 555 125 457 minecraft:black_concrete
setblock 545 125 458 minecraft:cobbled_deepslate
fill 546 125 416 548 215 416 minecraft:black_concrete
fill 546 125 458 547 212 458 minecraft:black_concrete
fill 548 125 456 552 125 456 minecraft:black_concrete
fill 549 125 416 551 125 416 minecraft:cobbled_deepslate
fill 549 125 418 552 125 418 minecraft:black_concrete
fill 552 125 416 553 212 416 minecraft:black_concrete
fill 554 125 458 554 215 458 minecraft:black_concrete
fill 555 125 442 558 125 447 minecraft:black_concrete
fill 556 125 440 559 125 441 minecraft:black_concrete
fill 556 125 448 559 126 448 minecraft:black_concrete
fill 557 125 423 558 125 425 minecraft:black_concrete
fill 557 125 438 559 125 439 minecraft:black_concrete
fill 558 125 420 558 125 422 minecraft:black_concrete
fill 558 125 426 558 125 431 minecraft:black_concrete
fill 558 125 434 559 125 434 minecraft:black_concrete
fill 558 125 436 559 125 437 minecraft:black_concrete
fill 558 125 451 559 125 451 minecraft:black_concrete
setblock 559 125 416 minecraft:cobbled_deepslate
fill 559 125 417 559 213 418 minecraft:black_concrete
setblock 559 125 422 minecraft:cobbled_deepslate
fill 559 125 423 559 215 424 minecraft:black_concrete
setblock 559 125 425 minecraft:cobbled_deepslate
fill 559 125 426 559 211 430 minecraft:black_concrete
fill 559 125 431 559 125 432 minecraft:cobbled_deepslate
fill 559 125 433 559 215 433 minecraft:black_concrete
fill 559 125 442 559 212 442 minecraft:black_concrete
setblock 559 125 446 minecraft:cobbled_deepslate
fill 559 125 447 559 212 447 minecraft:black_concrete
fill 559 125 452 559 212 453 minecraft:black_concrete
fill 517 126 431 518 153 431 minecraft:black_concrete
fill 517 126 434 517 212 438 minecraft:black_concrete
fill 517 126 440 517 215 440 minecraft:black_concrete
fill 517 126 442 518 126 442 minecraft:black_concrete
fill 517 126 454 517 215 454 minecraft:black_concrete
fill 517 126 456 517 215 456 minecraft:black_concrete
fill 518 126 419 518 126 423 minecraft:black_concrete
fill 518 126 425 518 154 430 minecraft:black_concrete
setblock 518 126 432 minecraft:black_concrete
fill 518 126 443 518 126 447 minecraft:black_concrete
fill 519 126 422 519 126 423 minecraft:black_concrete
fill 520 126 458 520 216 458 minecraft:black_concrete
fill 521 126 416 521 215 416 minecraft:black_concrete
fill 524 126 417 538 126 417 minecraft:black_concrete
fill 525 126 418 536 126 418 minecraft:black_concrete
fill 527 126 416 527 211 416 minecraft:black_concrete
fill 527 126 419 534 126 419 minecraft:black_concrete
fill 527 126 458 527 215 458 minecraft:black_concrete
fill 528 126 420 532 126 420 minecraft:black_concrete
fill 529 126 457 537 126 457 minecraft:black_concrete
fill 535 126 458 535 213 458 minecraft:black_concrete
fill 539 126 458 539 215 458 minecraft:black_concrete
fill 544 126 458 545 212 458 minecraft:black_concrete
fill 545 126 416 545 212 416 minecraft:black_concrete
fill 545 126 457 553 126 457 minecraft:black_concrete
fill 546 126 417 553 126 417 minecraft:black_concrete
fill 549 126 416 551 212 416 minecraft:black_concrete
fill 549 126 456 550 126 456 minecraft:black_concrete
fill 555 126 444 558 126 446 minecraft:black_concrete
fill 556 126 441 558 126 443 minecraft:black_concrete
fill 556 126 447 558 127 447 minecraft:black_concrete
fill 557 126 439 559 126 440 minecraft:black_concrete
fill 557 126 449 559 126 449 minecraft:black_concrete
fill 558 126 422 558 126 430 minecraft:black_concrete
fill 558 126 437 559 126 438 minecraft:black_concrete
fill 558 126 450 559 127 450 minecraft:black_concrete
fill 559 126 416 559 215 416 minecraft:black_concrete
fill 559 126 422 559 211 422 minecraft:black_concrete
fill 559 126 425 559 215 425 minecraft:black_concrete
fill 559 126 431 559 213 432 minecraft:black_concrete
fill 559 126 434 559 215 436 minecraft:black_concrete
fill 559 126 441 559 212 441 minecraft:black_concrete
fill 559 126 446 559 215 446 minecraft:black_concrete
fill 559 126 451 559 211 451 minecraft:black_concrete
fill 517 127 439 517 215 439 minecraft:black_concrete
fill 517 127 441 517 215 442 minecraft:black_concrete
fill 518 127 420 518 127 423 minecraft:black_concrete
fill 518 127 443 518 127 446 minecraft:black_concrete
setblock 519 127 423 minecraft:black_concrete
fill 519 127 425 519 140 427 minecraft:black_concrete
fill 524 127 417 537 127 417 minecraft:black_concrete
fill 526 127 418 535 127 418 minecraft:black_concrete
fill 527 127 419 533 127 419 minecraft:black_concrete
fill 529 127 457 535 127 457 minecraft:black_concrete
fill 545 127 457 552 127 457 minecraft:black_concrete
fill 548 127 417 550 127 417 minecraft:black_concrete
fill 556 127 444 558 127 446 minecraft:black_concrete
fill 557 127 441 558 127 443 minecraft:black_concrete
fill 557 127 448 559 127 448 minecraft:black_concrete
fill 558 127 423 558 127 429 minecraft:black_concrete
fill 558 127 439 559 127 440 minecraft:black_concrete
fill 558 127 449 559 130 449 minecraft:black_concrete
fill 559 127 437 559 215 438 minecraft:black_concrete
fill 518 128 421 518 128 423 minecraft:black_concrete
setblock 520 128 419 minecraft:light[level=12]
setblock 520 128 427 minecraft:light[level=12]
setblock 520 128 435 minecraft:light[level=12]
setblock 520 128 443 minecraft:light[level=12]
setblock 520 128 451 minecraft:light[level=12]
fill 525 128 417 535 128 417 minecraft:black_concrete
fill 526 128 418 533 128 418 minecraft:black_concrete
fill 528 128 419 531 128 419 minecraft:black_concrete
setblock 528 128 427 minecraft:light[level=12]
setblock 528 128 435 minecraft:light[level=12]
setblock 528 128 443 minecraft:light[level=12]
setblock 528 128 451 minecraft:light[level=12]
fill 529 128 457 534 128 457 minecraft:black_concrete
setblock 536 128 419 minecraft:light[level=12]
setblock 536 128 427 minecraft:light[level=12]
setblock 536 128 443 minecraft:light[level=12]
setblock 536 128 451 minecraft:light[level=12]
setblock 544 128 419 minecraft:light[level=12]
setblock 544 128 427 minecraft:light[level=12]
setblock 544 128 435 minecraft:light[level=12]
setblock 544 128 443 minecraft:light[level=12]
setblock 544 128 451 minecraft:light[level=12]
fill 545 128 457 551 128 457 minecraft:black_concrete
setblock 552 128 419 minecraft:light[level=12]
setblock 552 128 427 minecraft:light[level=12]
setblock 552 128 435 minecraft:light[level=12]
setblock 552 128 443 minecraft:light[level=12]
setblock 552 128 451 minecraft:light[level=12]
fill 556 128 423 556 138 423 minecraft:white_wool
fill 557 128 444 558 128 447 minecraft:black_concrete
fill 558 128 424 558 128 430 minecraft:black_concrete
fill 558 128 441 558 128 443 minecraft:black_concrete
fill 558 128 448 559 136 448 minecraft:black_concrete
fill 559 128 439 559 215 440 minecraft:black_concrete
fill 559 128 450 559 215 450 minecraft:black_concrete
fill 518 129 422 518 129 424 minecraft:black_concrete
fill 525 129 417 534 129 417 minecraft:black_concrete
fill 526 129 418 532 129 418 minecraft:black_concrete
fill 527 129 457 527 153 457 minecraft:black_concrete
fill 529 129 457 533 154 457 minecraft:black_concrete
fill 545 129 457 550 140 457 minecraft:black_concrete
fill 553 129 430 553 139 430 minecraft:black_concrete
fill 558 129 425 558 165 430 minecraft:black_concrete
fill 558 129 443 558 129 447 minecraft:black_concrete
fill 518 130 423 518 159 424 minecraft:black_concrete
fill 519 130 428 519 141 428 minecraft:black_concrete
fill 524 130 417 533 130 417 minecraft:black_concrete
fill 526 130 418 530 131 418 minecraft:black_concrete
fill 526 130 457 526 153 457 minecraft:black_concrete
fill 544 130 457 544 148 457 minecraft:black_concrete
fill 558 130 431 558 157 431 minecraft:black_concrete
fill 558 130 444 558 130 447 minecraft:black_concrete
fill 518 131 432 518 152 432 minecraft:black_concrete
fill 519 131 429 519 142 429 minecraft:black_concrete
fill 524 131 417 532 141 417 minecraft:black_concrete
fill 525 131 457 525 153 457 minecraft:black_concrete
fill 528 131 456 530 143 456 minecraft:black_concrete
fill 534 131 457 534 156 457 minecraft:black_concrete
fill 543 131 457 543 149 457 minecraft:black_concrete
fill 546 131 456 548 140 456 minecraft:black_concrete
fill 558 131 432 558 156 432 minecraft:black_concrete
fill 558 131 446 558 131 447 minecraft:black_concrete
fill 559 131 449 559 211 449 minecraft:black_concrete
fill 518 132 433 518 152 433 minecraft:black_concrete
fill 519 132 430 519 142 430 minecraft:black_concrete
fill 523 132 417 523 154 417 minecraft:black_concrete
fill 524 132 457 524 154 457 minecraft:black_concrete
fill 525 132 418 529 139 418 minecraft:black_concrete
fill 526 132 456 527 146 456 minecraft:black_concrete
fill 531 132 456 531 143 456 minecraft:black_concrete
fill 541 132 457 542 151 457 minecraft:black_concrete
fill 544 132 456 545 143 456 minecraft:black_concrete
fill 549 132 456 549 139 456 minecraft:black_concrete
fill 558 132 433 558 154 434 minecraft:black_concrete
fill 558 132 447 558 133 447 minecraft:black_concrete
fill 558 132 449 558 137 449 minecraft:black_concrete
fill 518 133 422 518 159 422 minecraft:black_concrete
fill 518 133 434 518 152 434 minecraft:black_concrete
fill 519 133 431 519 143 432 minecraft:black_concrete
fill 519 133 436 519 136 436 minecraft:white_wool
fill 522 133 417 522 155 417 minecraft:black_concrete
fill 522 133 457 523 154 457 minecraft:black_concrete
fill 524 133 418 524 152 418 minecraft:black_concrete
fill 524 133 456 525 149 456 minecraft:black_concrete
fill 527 133 455 529 141 455 minecraft:black_concrete
fill 532 133 456 533 143 456 minecraft:black_concrete
fill 535 133 457 540 152 457 minecraft:black_concrete
fill 541 133 456 543 145 456 minecraft:black_concrete
fill 544 133 455 548 139 455 minecraft:black_concrete
fill 551 133 457 551 139 457 minecraft:black_concrete
fill 557 133 428 557 140 432 minecraft:black_concrete
fill 558 133 435 558 154 435 minecraft:black_concrete
fill 558 133 450 558 138 450 minecraft:black_concrete
fill 518 134 435 518 153 435 minecraft:black_concrete
fill 519 134 424 519 140 424 minecraft:black_concrete
fill 519 134 433 519 144 433 minecraft:black_concrete
fill 520 134 417 521 155 417 minecraft:black_concrete
fill 520 134 427 520 138 430 minecraft:black_concrete
fill 521 134 457 521 155 457 minecraft:black_concrete
fill 523 134 418 523 153 418 minecraft:black_concrete
fill 523 134 456 523 151 456 minecraft:black_concrete
fill 525 134 455 526 142 455 minecraft:black_concrete
fill 530 134 418 530 137 418 minecraft:black_concrete
fill 530 134 455 531 140 455 minecraft:black_concrete
fill 534 134 456 534 153 456 minecraft:black_concrete
fill 539 134 456 540 150 456 minecraft:black_concrete
fill 541 134 455 543 142 455 minecraft:black_concrete
fill 544 134 454 546 138 454 minecraft:black_concrete
fill 550 134 456 550 138 456 minecraft:black_concrete
fill 557 134 427 557 139 427 minecraft:black_concrete
fill 557 134 433 557 153 434 minecraft:black_concrete
fill 558 134 424 558 164 424 minecraft:black_concrete
fill 558 134 436 558 154 437 minecraft:black_concrete
fill 558 134 451 558 139 452 minecraft:black_concrete
fill 518 135 421 518 158 421 minecraft:black_concrete
fill 518 135 436 518 153 436 minecraft:black_concrete
fill 518 135 450 518 139 455 minecraft:black_concrete
fill 519 135 417 519 157 417 minecraft:black_concrete
fill 519 135 434 519 145 434 minecraft:black_concrete
fill 519 135 457 520 156 457 minecraft:black_concrete
fill 520 135 426 520 138 426 minecraft:black_concrete
fill 520 135 431 520 140 432 minecraft:black_concrete
fill 521 135 418 522 153 418 minecraft:black_concrete
fill 521 135 456 522 152 456 minecraft:black_concrete
fill 523 135 455 524 144 455 minecraft:black_concrete
fill 525 135 419 526 138 419 minecraft:black_concrete
fill 526 135 454 528 138 454 minecraft:black_concrete
fill 532 135 455 532 139 455 minecraft:black_concrete
fill 533 135 417 533 140 417 minecraft:black_concrete
fill 535 135 456 538 152 456 minecraft:black_concrete
fill 539 135 454 539 137 454 minecraft:white_wool
fill 539 135 455 540 144 455 minecraft:black_concrete
fill 542 135 454 543 140 454 minecraft:black_concrete
fill 543 135 417 547 141 417 minecraft:black_concrete
fill 547 135 454 547 137 454 minecraft:black_concrete
fill 549 135 455 549 137 455 minecraft:black_concrete
fill 557 135 435 557 153 435 minecraft:black_concrete
fill 558 135 438 558 155 438 minecraft:black_concrete
fill 558 135 453 558 141 453 minecraft:black_concrete
fill 518 136 417 518 157 420 minecraft:black_concrete
fill 518 136 437 518 154 437 minecraft:black_concrete
fill 518 136 456 518 158 457 minecraft:black_concrete
fill 519 136 423 519 141 423 minecraft:black_concrete
fill 519 136 435 519 147 435 minecraft:black_concrete
fill 519 136 453 519 142 454 minecraft:black_concrete
fill 520 136 418 520 155 418 minecraft:black_concrete
setblock 520 136 419 minecraft:light[level=12]
fill 520 136 433 520 141 433 minecraft:black_concrete
setblock 520 136 435 minecraft:light[level=12]
setblock 520 136 443 minecraft:light[level=12]
setblock 520 136 451 minecraft:light[level=12]
fill 520 136 456 520 154 456 minecraft:black_concrete
fill 522 136 455 522 145 455 minecraft:black_concrete
fill 523 136 419 524 142 419 minecraft:black_concrete
fill 524 136 454 525 140 454 minecraft:black_concrete
setblock 528 136 419 minecraft:light[level=12]
setblock 528 136 427 minecraft:light[level=12]
setblock 528 136 435 minecraft:light[level=12]
setblock 528 136 443 minecraft:light[level=12]
setblock 528 136 451 minecraft:light[level=12]
fill 529 136 454 529 138 454 minecraft:black_concrete
fill 533 136 455 533 139 455 minecraft:black_concrete
setblock 536 136 419 minecraft:light[level=12]
setblock 536 136 427 minecraft:light[level=12]
setblock 536 136 435 minecraft:light[level=12]
setblock 536 136 443 minecraft:light[level=12]
setblock 536 136 451 minecraft:light[level=12]
fill 537 136 455 538 142 455 minecraft:black_concrete
fill 541 136 417 542 153 417 minecraft:black_concrete
fill 541 136 454 541 140 454 minecraft:black_concrete
setblock 544 136 419 minecraft:light[level=12]
setblock 544 136 427 minecraft:light[level=12]
setblock 544 136 435 minecraft:light[level=12]
setblock 544 136 443 minecraft:light[level=12]
setblock 544 136 451 minecraft:light[level=12]
fill 548 136 417 548 139 417 minecraft:black_concrete
setblock 552 136 419 minecraft:light[level=12]
setblock 552 136 427 minecraft:light[level=12]
fill 552 136 430 552 139 430 minecraft:black_concrete
setblock 552 136 435 minecraft:light[level=12]
setblock 552 136 443 minecraft:light[level=12]
setblock 552 136 451 minecraft:light[level=12]
fill 552 136 457 552 138 457 minecraft:black_concrete
fill 553 136 429 553 139 429 minecraft:black_concrete
fill 553 136 431 553 139 431 minecraft:black_concrete
fill 554 136 430 554 139 430 minecraft:black_concrete
fill 556 136 431 556 139 432 minecraft:black_concrete
fill 557 136 436 557 153 436 minecraft:black_concrete
fill 558 136 439 558 155 439 minecraft:black_concrete
fill 558 136 454 558 143 455 minecraft:black_concrete
fill 518 137 438 518 154 438 minecraft:black_concrete
fill 519 137 418 519 155 419 minecraft:black_concrete
fill 519 137 422 519 156 422 minecraft:black_concrete
fill 519 137 436 519 150 436 minecraft:black_concrete
fill 519 137 452 519 140 452 minecraft:black_concrete
fill 519 137 455 519 154 456 minecraft:black_concrete
fill 520 137 434 520 141 434 minecraft:black_concrete
fill 521 137 455 521 145 455 minecraft:black_concrete
fill 522 137 419 522 152 419 minecraft:black_concrete
fill 523 137 454 523 140 454 minecraft:black_concrete
fill 534 137 455 536 139 455 minecraft:black_concrete
fill 539 137 417 540 154 417 minecraft:black_concrete
fill 540 137 454 540 140 454 minecraft:black_concrete
setblock 556 137 430 minecraft:black_concrete
fill 556 137 433 556 141 434 minecraft:black_concrete
fill 557 137 437 557 153 437 minecraft:black_concrete
fill 558 137 423 558 164 423 minecraft:black_concrete
fill 558 137 440 558 156 440 minecraft:black_concrete
fill 558 137 456 558 156 456 minecraft:black_concrete
fill 559 137 448 559 215 448 minecraft:black_concrete
fill 519 138 420 519 156 421 minecraft:black_concrete
fill 520 138 454 520 141 455 minecraft:black_concrete
fill 521 138 419 521 153 419 minecraft:black_concrete
fill 538 138 417 538 155 417 minecraft:black_concrete
fill 539 138 454 539 139 454 minecraft:black_concrete
fill 557 138 438 557 154 438 minecraft:black_concrete
fill 558 138 417 558 160 417 minecraft:black_concrete
fill 558 138 441 558 156 441 minecraft:black_concrete
fill 558 138 457 558 156 457 minecraft:black_concrete
fill 518 139 439 518 155 439 minecraft:black_concrete
fill 519 139 437 519 151 437 minecraft:black_concrete
fill 520 139 428 520 139 430 minecraft:black_concrete
fill 520 139 435 520 140 435 minecraft:black_concrete
fill 525 139 419 525 140 419 minecraft:black_concrete
fill 526 139 454 527 139 454 minecraft:black_concrete
fill 537 139 417 537 155 417 minecraft:black_concrete
fill 544 139 454 545 139 454 minecraft:black_concrete
setblock 552 139 429 minecraft:black_concrete
setblock 552 139 431 minecraft:black_concrete
setblock 554 139 429 minecraft:black_concrete
setblock 554 139 431 minecraft:black_concrete
fill 556 139 435 556 140 435 minecraft:black_concrete
fill 557 139 457 557 157 457 minecraft:black_concrete
fill 558 139 418 558 160 420 minecraft:black_concrete
fill 558 139 422 558 163 422 minecraft:black_concrete
fill 518 140 451 518 141 455 minecraft:black_concrete
fill 520 140 419 520 154 419 minecraft:black_concrete
fill 520 140 429 520 140 430 minecraft:black_concrete
fill 522 140 435 522 154 435 minecraft:white_wool
fill 525 140 418 528 141 418 minecraft:black_concrete
setblock 526 140 454 minecraft:black_concrete
fill 535 140 455 536 140 455 minecraft:black_concrete
fill 536 140 417 536 155 417 minecraft:black_concrete
fill 539 140 454 539 149 454 minecraft:white_wool
fill 544 140 454 544 140 455 minecraft:black_concrete
fill 545 140 455 546 140 455 minecraft:black_concrete
setblock 556 140 432 minecraft:black_concrete
fill 557 140 417 557 174 417 minecraft:black_concrete
fill 558 140 421 558 162 421 minecraft:black_concrete
setblock 558 140 452 minecraft:black_concrete
setblock 519 141 427 minecraft:black_concrete
setblock 520 141 432 minecraft:black_concrete
setblock 536 141 455 minecraft:black_concrete
fill 544 141 455 545 141 455 minecraft:black_concrete
fill 545 141 457 549 141 457 minecraft:black_concrete
fill 546 141 456 547 141 456 minecraft:black_concrete
fill 556 141 417 556 174 417 minecraft:black_concrete
fill 557 141 429 557 142 432 minecraft:black_concrete
fill 518 142 452 518 174 455 minecraft:black_concrete
fill 520 142 455 520 144 455 minecraft:black_concrete
fill 524 142 417 531 143 417 minecraft:black_concrete
fill 525 142 418 527 143 418 minecraft:black_concrete
setblock 527 142 455 minecraft:black_concrete
fill 535 142 417 535 156 417 minecraft:black_concrete
fill 543 142 417 546 143 417 minecraft:black_concrete
setblock 544 142 455 minecraft:black_concrete
fill 545 142 457 548 142 457 minecraft:black_concrete
setblock 546 142 456 minecraft:black_concrete
fill 557 142 439 557 154 439 minecraft:black_concrete
fill 518 143 440 518 156 440 minecraft:black_concrete
fill 519 143 454 519 154 454 minecraft:black_concrete
fill 520 143 420 520 154 420 minecraft:black_concrete
fill 523 143 419 523 151 419 minecraft:black_concrete
setblock 525 143 455 minecraft:black_concrete
fill 535 143 420 535 147 420 minecraft:black_concrete
setblock 538 143 455 minecraft:black_concrete
fill 541 143 455 542 143 455 minecraft:black_concrete
fill 545 143 457 547 143 457 minecraft:black_concrete
fill 555 143 417 555 174 417 minecraft:black_concrete
fill 557 143 430 557 143 432 minecraft:black_concrete
fill 558 143 442 558 156 442 minecraft:black_concrete
fill 518 144 441 518 156 441 minecraft:black_concrete
fill 519 144 423 519 156 423 minecraft:black_concrete
fill 519 144 438 519 152 438 minecraft:black_concrete
setblock 520 144 427 minecraft:light[level=12]
setblock 520 144 435 minecraft:light[level=12]
setblock 520 144 443 minecraft:light[level=12]
setblock 520 144 451 minecraft:light[level=12]
fill 524 144 417 530 153 417 minecraft:black_concrete
fill 525 144 418 526 150 418 minecraft:black_concrete
setblock 528 144 419 minecraft:light[level=12]
setblock 528 144 427 minecraft:light[level=12]
setblock 528 144 435 minecraft:light[level=12]
setblock 528 144 443 minecraft:light[level=12]
setblock 528 144 451 minecraft:light[level=12]
fill 528 144 456 529 144 456 minecraft:black_concrete
fill 534 144 417 534 156 417 minecraft:black_concrete
setblock 536 144 419 minecraft:light[level=12]
setblock 536 144 427 minecraft:light[level=12]
setblock 536 144 435 minecraft:light[level=12]
setblock 536 144 443 minecraft:light[level=12]
setblock 536 144 451 minecraft:light[level=12]
fill 543 144 417 545 151 417 minecraft:black_concrete
setblock 544 144 419 minecraft:light[level=12]
setblock 544 144 427 minecraft:light[level=12]
setblock 544 144 435 minecraft:light[level=12]
setblock 544 144 443 minecraft:light[level=12]
setblock 544 144 451 minecraft:light[level=12]
setblock 544 144 456 minecraft:black_concrete
fill 545 144 457 546 144 457 minecraft:black_concrete
setblock 552 144 419 minecraft:light[level=12]
setblock 552 144 427 minecraft:light[level=12]
setblock 552 144 435 minecraft:light[level=12]
setblock 552 144 443 minecraft:light[level=12]
setblock 552 144 451 minecraft:light[level=12]
fill 554 144 417 554 174 417 minecraft:black_concrete
fill 556 144 457 556 174 457 minecraft:black_concrete
fill 557 144 418 557 158 420 minecraft:black_concrete
fill 557 144 431 557 154 432 minecraft:black_concrete
fill 558 144 455 558 155 455 minecraft:black_concrete
fill 518 145 442 518 157 442 minecraft:black_concrete
fill 519 145 439 519 153 439 minecraft:black_concrete
fill 520 145 421 520 154 421 minecraft:black_concrete
setblock 528 145 456 minecraft:black_concrete
fill 531 145 417 533 155 417 minecraft:black_concrete
fill 545 145 457 545 146 457 minecraft:black_concrete
fill 556 145 418 556 159 418 minecraft:black_concrete
fill 557 145 421 557 160 422 minecraft:black_concrete
fill 557 145 440 557 154 440 minecraft:black_concrete
fill 558 145 443 558 157 443 minecraft:black_concrete
fill 518 146 443 518 158 443 minecraft:black_concrete
fill 519 146 424 519 156 424 minecraft:black_concrete
fill 519 146 440 519 153 440 minecraft:black_concrete
fill 534 146 420 534 147 420 minecraft:black_concrete
fill 535 146 419 535 147 419 minecraft:black_concrete
fill 535 146 421 535 147 421 minecraft:black_concrete
fill 536 146 420 536 147 420 minecraft:black_concrete
fill 538 146 418 541 152 418 minecraft:black_concrete
fill 541 146 456 542 146 456 minecraft:black_concrete
fill 552 146 417 553 174 417 minecraft:black_concrete
fill 555 146 418 555 160 418 minecraft:black_concrete
fill 557 146 423 557 162 424 minecraft:black_concrete
fill 557 146 441 557 155 441 minecraft:black_concrete
fill 558 146 444 558 158 444 minecraft:black_concrete
fill 518 147 444 518 160 446 minecraft:black_concrete
fill 518 147 451 518 172 451 minecraft:black_concrete
fill 519 147 425 519 156 425 minecraft:black_concrete
fill 519 147 441 519 154 442 minecraft:black_concrete
fill 520 147 422 520 154 422 minecraft:black_concrete
setblock 526 147 456 minecraft:black_concrete
setblock 534 147 419 minecraft:black_concrete
setblock 534 147 421 minecraft:black_concrete
fill 536 147 418 536 147 419 minecraft:black_concrete
setblock 536 147 421 minecraft:black_concrete
fill 537 147 418 537 154 418 minecraft:black_concrete
fill 541 147 456 541 148 456 minecraft:black_concrete
fill 542 147 418 542 151 418 minecraft:black_concrete
fill 546 147 417 546 151 417 minecraft:black_concrete
fill 551 147 417 551 174 417 minecraft:black_concrete
fill 554 147 418 554 168 418 minecraft:black_concrete
fill 555 147 457 555 174 457 minecraft:black_concrete
fill 556 147 419 556 157 421 minecraft:black_concrete
fill 556 147 437 556 151 438 minecraft:black_concrete
fill 557 147 425 557 157 430 minecraft:black_concrete
fill 557 147 442 557 155 442 minecraft:black_concrete
fill 558 147 445 558 158 445 minecraft:black_concrete
fill 558 147 454 558 156 454 minecraft:black_concrete
fill 518 148 447 518 169 450 minecraft:black_concrete
fill 519 148 426 519 155 426 minecraft:black_concrete
fill 519 148 443 519 156 444 minecraft:black_concrete
fill 519 148 453 519 154 453 minecraft:black_concrete
fill 520 148 423 520 153 423 minecraft:black_concrete
fill 521 148 425 521 153 425 minecraft:black_concrete
fill 533 148 456 533 153 456 minecraft:black_concrete
fill 535 148 418 536 154 418 minecraft:black_concrete
fill 550 148 417 550 174 417 minecraft:black_concrete
fill 552 148 418 553 170 418 minecraft:black_concrete
fill 554 148 419 555 157 419 minecraft:black_concrete
fill 554 148 457 554 174 457 minecraft:black_concrete
fill 556 148 422 556 159 424 minecraft:black_concrete
fill 556 148 436 556 151 436 minecraft:black_concrete
fill 556 148 439 556 152 440 minecraft:black_concrete
fill 557 148 443 557 156 443 minecraft:black_concrete
fill 558 148 446 558 160 446 minecraft:black_concrete
fill 519 149 445 519 157 446 minecraft:black_concrete
fill 519 149 452 519 155 452 minecraft:black_concrete
fill 521 149 420 521 150 420 minecraft:black_concrete
fill 533 149 418 534 154 418 minecraft:black_concrete
fill 543 149 418 543 150 418 minecraft:black_concrete
fill 547 149 417 549 152 417 minecraft:black_concrete
fill 551 149 418 551 174 418 minecraft:black_concrete
fill 553 149 419 553 157 419 minecraft:black_concrete
fill 555 149 420 555 156 420 minecraft:black_concrete
fill 556 149 425 556 161 426 minecraft:black_concrete
fill 556 149 441 556 153 441 minecraft:black_concrete
fill 557 149 444 557 156 445 minecraft:black_concrete
fill 558 149 447 558 165 448 minecraft:black_concrete
fill 558 149 453 558 174 453 minecraft:black_concrete
fill 519 150 427 519 153 427 minecraft:black_concrete
fill 519 150 447 519 165 451 minecraft:black_concrete
fill 520 150 424 520 152 424 minecraft:black_concrete
setblock 524 150 456 minecraft:black_concrete
fill 532 150 418 532 153 418 minecraft:black_concrete
fill 532 150 456 532 152 456 minecraft:black_concrete
fill 537 150 419 539 151 419 minecraft:black_concrete
fill 550 150 418 550 155 418 minecraft:black_concrete
fill 552 150 419 552 156 419 minecraft:black_concrete
fill 553 150 457 553 155 457 minecraft:black_concrete
fill 554 150 420 554 156 420 minecraft:black_concrete
fill 555 150 421 555 157 423 minecraft:black_concrete
fill 556 150 427 556 159 428 minecraft:black_concrete
fill 556 150 442 556 153 443 minecraft:black_concrete
fill 557 150 446 557 157 446 minecraft:black_concrete
fill 557 150 456 557 152 456 minecraft:black_concrete
fill 558 150 449 558 169 452 minecraft:black_concrete
fill 520 151 442 520 151 444 minecraft:black_concrete
setblock 525 151 418 minecraft:black_concrete
fill 536 151 419 536 152 419 minecraft:black_concrete
setblock 539 151 456 minecraft:black_concrete
fill 553 151 420 553 155 420 minecraft:black_concrete
fill 555 151 424 555 158 425 minecraft:black_concrete
fill 556 151 429 556 156 429 minecraft:black_concrete
fill 556 151 444 556 154 444 minecraft:black_concrete
fill 557 151 447 557 157 447 minecraft:black_concrete
fill 520 152 425 520 153 425 minecraft:black_concrete
setblock 520 152 427 minecraft:light[level=12]
setblock 520 152 435 minecraft:light[level=12]
fill 520 152 443 520 152 445 minecraft:black_concrete
setblock 520 152 451 minecraft:light[level=12]
fill 521 152 424 521 153 424 minecraft:black_concrete
fill 521 152 426 521 153 426 minecraft:black_concrete
fill 522 152 425 522 153 425 minecraft:black_concrete
setblock 528 152 419 minecraft:light[level=12]
setblock 528 152 427 minecraft:light[level=12]
setblock 528 152 435 minecraft:light[level=12]
setblock 528 152 443 minecraft:light[level=12]
setblock 528 152 451 minecraft:light[level=12]
setblock 536 152 427 minecraft:light[level=12]
setblock 536 152 435 minecraft:light[level=12]
setblock 536 152 443 minecraft:light[level=12]
setblock 536 152 451 minecraft:light[level=12]
fill 537 152 419 538 152 419 minecraft:black_concrete
setblock 541 152 457 minecraft:black_concrete
fill 543 152 417 544 152 417 minecraft:black_concrete
setblock 544 152 419 minecraft:light[level=12]
setblock 544 152 427 minecraft:light[level=12]
setblock 544 152 435 minecraft:light[level=12]
setblock 544 152 443 minecraft:light[level=12]
setblock 544 152 451 minecraft:light[level=12]
fill 551 152 419 551 155 419 minecraft:black_concrete
setblock 552 152 427 minecraft:light[level=12]
setblock 552 152 435 minecraft:light[level=12]
setblock 552 152 443 minecraft:light[level=12]
setblock 552 152 451 minecraft:light[level=12]
fill 555 152 426 555 157 426 minecraft:black_concrete
setblock 556 152 438 minecraft:black_concrete
fill 557 152 448 557 156 448 minecraft:black_concrete
fill 520 153 444 520 153 446 minecraft:black_concrete
setblock 521 153 456 minecraft:black_concrete
fill 535 153 456 536 153 457 minecraft:black_concrete
fill 537 153 457 539 153 457 minecraft:black_concrete
fill 538 153 418 540 153 418 minecraft:black_concrete
fill 548 153 417 549 153 417 minecraft:black_concrete
setblock 552 153 420 minecraft:black_concrete
setblock 554 153 422 minecraft:black_concrete
fill 555 153 427 555 156 427 minecraft:black_concrete
setblock 556 153 440 minecraft:black_concrete
setblock 556 153 445 minecraft:black_concrete
fill 557 153 449 557 155 449 minecraft:black_concrete
fill 517 154 431 517 212 431 minecraft:black_concrete
setblock 521 154 418 minecraft:black_concrete
setblock 524 154 417 minecraft:black_concrete
fill 528 154 458 528 212 458 minecraft:black_concrete
setblock 530 154 417 minecraft:black_concrete
fill 535 154 457 538 154 457 minecraft:black_concrete
fill 549 154 417 549 156 417 minecraft:black_concrete
setblock 554 154 423 minecraft:black_concrete
setblock 556 154 443 minecraft:black_concrete
fill 518 155 425 518 156 429 minecraft:black_concrete
setblock 519 155 442 minecraft:black_concrete
setblock 522 155 457 minecraft:black_concrete
fill 530 155 457 533 155 457 minecraft:black_concrete
fill 535 155 457 536 155 457 minecraft:black_concrete
setblock 557 155 431 minecraft:black_concrete
setblock 558 155 433 minecraft:black_concrete
setblock 558 155 437 minecraft:black_concrete
setblock 519 156 419 minecraft:black_concrete
setblock 520 156 417 minecraft:black_concrete
fill 531 156 457 533 156 457 minecraft:black_concrete
setblock 533 156 417 minecraft:black_concrete
setblock 535 156 457 minecraft:black_concrete
fill 518 157 425 518 158 428 minecraft:black_concrete
setblock 519 157 457 minecraft:black_concrete
fill 518 158 418 518 158 420 minecraft:black_concrete
setblock 519 158 446 minecraft:black_concrete
setblock 554 158 419 minecraft:black_concrete
setblock 555 158 423 minecraft:black_concrete
fill 556 158 420 556 158 421 minecraft:black_concrete
fill 557 158 425 557 163 429 minecraft:black_concrete
fill 518 159 425 518 159 427 minecraft:black_concrete
fill 518 159 456 518 174 456 minecraft:black_concrete
fill 553 159 457 553 174 457 minecraft:black_concrete
fill 557 159 419 557 159 420 minecraft:black_concrete
fill 518 160 425 518 160 426 minecraft:black_concrete
fill 519 160 452 519 170 452 minecraft:black_concrete
setblock 520 160 419 minecraft:light[level=12]
setblock 520 160 427 minecraft:light[level=12]
setblock 520 160 435 minecraft:light[level=12]
setblock 520 160 443 minecraft:light[level=12]
setblock 520 160 451 minecraft:light[level=12]
setblock 528 160 419 minecraft:light[level=12]
setblock 528 160 427 minecraft:light[level=12]
setblock 528 160 435 minecraft:light[level=12]
setblock 528 160 443 minecraft:light[level=12]
setblock 528 160 451 minecraft:light[level=12]
setblock 536 160 419 minecraft:light[level=12]
setblock 536 160 427 minecraft:light[level=12]
setblock 536 160 435 minecraft:light[level=12]
setblock 536 160 443 minecraft:light[level=12]
setblock 536 160 451 minecraft:light[level=12]
setblock 544 160 419 minecraft:light[level=12]
setblock 544 160 427 minecraft:light[level=12]
setblock 544 160 435 minecraft:light[level=12]
setblock 544 160 443 minecraft:light[level=12]
setblock 544 160 451 minecraft:light[level=12]
fill 549 160 417 549 174 417 minecraft:black_concrete
setblock 552 160 419 minecraft:light[level=12]
setblock 552 160 427 minecraft:light[level=12]
setblock 552 160 435 minecraft:light[level=12]
setblock 552 160 443 minecraft:light[level=12]
setblock 552 160 451 minecraft:light[level=12]
fill 552 160 457 552 174 457 minecraft:black_concrete
fill 556 160 423 556 160 424 minecraft:black_concrete
fill 556 160 427 556 161 427 minecraft:black_concrete
fill 558 160 454 558 174 454 minecraft:black_concrete
fill 518 161 445 518 166 446 minecraft:black_concrete
fill 518 161 457 518 174 457 minecraft:black_concrete
fill 529 161 457 532 171 457 minecraft:black_concrete
fill 548 161 417 548 174 417 minecraft:black_concrete
fill 550 161 457 551 174 457 minecraft:black_concrete
setblock 557 161 422 minecraft:black_concrete
fill 557 161 457 557 174 457 minecraft:black_concrete
fill 558 161 419 558 161 420 minecraft:black_concrete
fill 558 161 455 558 174 456 minecraft:black_concrete
fill 519 162 453 519 171 454 minecraft:black_concrete
fill 526 162 457 528 174 457 minecraft:black_concrete
fill 530 162 456 530 170 456 minecraft:black_concrete
fill 533 162 457 533 170 457 minecraft:black_concrete
fill 547 162 417 547 174 417 minecraft:black_concrete
fill 549 162 418 550 174 418 minecraft:black_concrete
fill 549 162 457 549 174 457 minecraft:black_concrete
fill 551 162 456 554 173 456 minecraft:black_concrete
fill 557 162 450 557 167 453 minecraft:black_concrete
setblock 558 162 420 minecraft:black_concrete
fill 558 162 431 558 167 431 minecraft:black_concrete
fill 558 162 457 558 174 457 minecraft:black_concrete
fill 519 163 455 519 172 455 minecraft:black_concrete
fill 519 163 457 525 174 457 minecraft:black_concrete
fill 526 163 456 529 171 456 minecraft:black_concrete
fill 531 163 456 532 169 456 minecraft:black_concrete
fill 546 163 417 546 174 417 minecraft:black_concrete
fill 547 163 457 548 174 457 minecraft:black_concrete
fill 548 163 418 548 174 418 minecraft:black_concrete
fill 549 163 456 550 174 456 minecraft:black_concrete
fill 555 163 456 556 173 456 minecraft:black_concrete
fill 557 163 449 557 165 449 minecraft:black_concrete
fill 557 163 454 557 171 455 minecraft:black_concrete
fill 523 164 456 525 174 456 minecraft:black_concrete
fill 526 164 455 531 167 455 minecraft:black_concrete
fill 533 164 456 533 167 456 minecraft:black_concrete
fill 534 164 457 534 169 457 minecraft:black_concrete
fill 545 164 417 545 174 417 minecraft:black_concrete
fill 546 164 457 546 174 457 minecraft:black_concrete
fill 547 164 418 547 174 418 minecraft:black_concrete
fill 547 164 456 548 174 456 minecraft:black_concrete
fill 550 164 455 554 169 455 minecraft:black_concrete
fill 555 164 418 555 166 418 minecraft:black_concrete
fill 557 164 427 557 164 429 minecraft:black_concrete
fill 557 164 456 557 174 456 minecraft:black_concrete
fill 558 164 417 558 174 417 minecraft:black_concrete
fill 558 164 432 558 167 432 minecraft:black_concrete
fill 518 165 430 518 166 432 minecraft:black_concrete
fill 519 165 456 522 172 456 minecraft:black_concrete
fill 520 165 450 520 166 453 minecraft:black_concrete
fill 524 165 455 525 171 455 minecraft:black_concrete
fill 528 165 417 531 171 417 minecraft:black_concrete
fill 528 165 454 528 167 454 minecraft:black_concrete
fill 544 165 417 544 174 417 minecraft:black_concrete
fill 544 165 457 545 174 457 minecraft:black_concrete
fill 546 165 418 546 174 418 minecraft:black_concrete
fill 546 165 456 546 174 456 minecraft:black_concrete
fill 548 165 455 549 172 455 minecraft:black_concrete
fill 549 165 419 551 167 419 minecraft:black_concrete
fill 555 165 455 555 168 455 minecraft:black_concrete
fill 556 165 453 556 167 454 minecraft:black_concrete
fill 518 166 433 518 170 434 minecraft:black_concrete
fill 519 166 448 519 167 451 minecraft:black_concrete
fill 520 166 454 520 168 454 minecraft:black_concrete
fill 522 166 455 523 170 455 minecraft:black_concrete
fill 526 166 417 527 174 417 minecraft:black_concrete
fill 526 166 454 527 168 454 minecraft:black_concrete
fill 529 166 454 529 167 454 minecraft:black_concrete
fill 532 166 417 532 169 417 minecraft:black_concrete
fill 535 166 457 535 167 457 minecraft:black_concrete
fill 543 166 417 543 174 417 minecraft:black_concrete
fill 543 166 457 543 174 457 minecraft:black_concrete
fill 545 166 418 545 174 418 minecraft:black_concrete
fill 545 166 456 545 174 456 minecraft:black_concrete
fill 547 166 455 547 172 455 minecraft:black_concrete
fill 548 166 419 548 174 419 minecraft:black_concrete
fill 556 166 455 556 168 455 minecraft:black_concrete
setblock 558 166 418 minecraft:black_concrete
fill 558 166 427 558 166 430 minecraft:black_concrete
fill 558 166 433 558 167 433 minecraft:black_concrete
fill 558 166 448 558 167 448 minecraft:black_concrete
fill 518 167 431 518 168 432 minecraft:black_concrete
fill 518 167 435 518 174 435 minecraft:black_concrete
fill 518 167 446 518 168 446 minecraft:black_concrete
fill 520 167 451 520 167 453 minecraft:black_concrete
fill 521 167 455 521 169 455 minecraft:black_concrete
fill 523 167 452 523 171 452 minecraft:black_concrete
fill 525 167 417 525 174 417 minecraft:black_concrete
fill 525 167 454 525 168 454 minecraft:black_concrete
fill 542 167 417 542 174 417 minecraft:black_concrete
fill 542 167 457 542 174 457 minecraft:black_concrete
fill 544 167 418 544 174 418 minecraft:black_concrete
fill 544 167 456 544 174 456 minecraft:black_concrete
fill 546 167 455 546 172 455 minecraft:black_concrete
fill 547 167 419 547 174 419 minecraft:black_concrete
setblock 550 167 454 minecraft:black_concrete
fill 558 167 429 558 167 430 minecraft:black_concrete
fill 518 168 436 518 174 436 minecraft:black_concrete
fill 519 168 449 519 168 451 minecraft:black_concrete
setblock 520 168 419 minecraft:light[level=12]
setblock 520 168 427 minecraft:light[level=12]
setblock 520 168 435 minecraft:light[level=12]
setblock 520 168 443 minecraft:light[level=12]
setblock 520 168 451 minecraft:light[level=12]
fill 520 168 452 520 168 453 minecraft:black_concrete
fill 524 168 417 524 174 417 minecraft:black_concrete
fill 526 168 455 530 168 455 minecraft:black_concrete
setblock 528 168 419 minecraft:light[level=12]
setblock 528 168 427 minecraft:light[level=12]
setblock 528 168 435 minecraft:light[level=12]
setblock 528 168 443 minecraft:light[level=12]
setblock 528 168 451 minecraft:light[level=12]
setblock 536 168 419 minecraft:light[level=12]
setblock 536 168 427 minecraft:light[level=12]
setblock 536 168 435 minecraft:light[level=12]
setblock 536 168 443 minecraft:light[level=12]
setblock 536 168 451 minecraft:light[level=12]
fill 541 168 417 541 174 417 minecraft:black_concrete
fill 541 168 457 541 174 457 minecraft:black_concrete
fill 543 168 418 543 174 418 minecraft:black_concrete
fill 543 168 456 543 174 456 minecraft:black_concrete
setblock 544 168 419 minecraft:light[level=12]
setblock 544 168 427 minecraft:light[level=12]
setblock 544 168 435 minecraft:light[level=12]
setblock 544 168 443 minecraft:light[level=12]
setblock 544 168 451 minecraft:light[level=12]
fill 545 168 455 545 171 455 minecraft:black_concrete
fill 546 168 419 546 174 419 minecraft:black_concrete
fill 549 168 419 550 169 419 minecraft:black_concrete
setblock 552 168 419 minecraft:light[level=12]
setblock 552 168 427 minecraft:light[level=12]
setblock 552 168 435 minecraft:light[level=12]
setblock 552 168 443 minecraft:light[level=12]
setblock 552 168 451 minecraft:light[level=12]
fill 557 168 451 557 168 453 minecraft:black_concrete
setblock 518 169 432 minecraft:black_concrete
fill 518 169 437 518 174 437 minecraft:black_concrete
fill 519 169 450 519 169 451 minecraft:black_concrete
fill 522 169 446 522 174 446 minecraft:white_wool
fill 523 169 417 523 174 417 minecraft:black_concrete
fill 526 169 455 529 169 455 minecraft:black_concrete
fill 540 169 417 540 174 417 minecraft:black_concrete
fill 540 169 457 540 174 457 minecraft:black_concrete
fill 557 169 452 557 169 453 minecraft:black_concrete
fill 518 170 438 518 174 438 minecraft:black_concrete
fill 518 170 448 518 170 450 minecraft:black_concrete
setblock 519 170 451 minecraft:black_concrete
fill 522 170 452 522 171 452 minecraft:black_concrete
fill 523 170 451 523 171 451 minecraft:black_concrete
fill 523 170 453 523 171 453 minecraft:black_concrete
fill 524 170 452 524 171 452 minecraft:black_concrete
fill 526 170 455 528 170 455 minecraft:black_concrete
setblock 531 170 456 minecraft:black_concrete
fill 539 170 417 539 174 417 minecraft:black_concrete
fill 542 170 418 542 174 418 minecraft:black_concrete
fill 542 170 456 542 174 456 minecraft:black_concrete
fill 545 170 419 545 174 419 minecraft:black_concrete
fill 549 170 419 549 171 419 minecraft:black_concrete
fill 550 170 455 553 170 455 minecraft:black_concrete
setblock 557 170 453 minecraft:black_concrete
fill 558 170 450 558 170 452 minecraft:black_concrete
fill 518 171 434 518 174 434 minecraft:black_concrete
fill 518 171 439 518 174 439 minecraft:black_concrete
setblock 518 171 450 minecraft:black_concrete
fill 522 171 417 522 174 417 minecraft:black_concrete
setblock 522 171 451 minecraft:black_concrete
setblock 522 171 453 minecraft:black_concrete
setblock 523 171 455 minecraft:black_concrete
setblock 524 171 451 minecraft:black_concrete
setblock 524 171 453 minecraft:black_concrete
setblock 526 171 455 minecraft:black_concrete
fill 550 171 455 551 171 455 minecraft:black_concrete
fill 552 171 418 552 172 418 minecraft:black_concrete
fill 558 171 451 558 171 452 minecraft:black_concrete
fill 518 172 440 518 174 441 minecraft:black_concrete
setblock 519 172 454 minecraft:black_concrete
fill 526 172 456 528 172 456 minecraft:black_concrete
fill 528 172 417 530 174 417 minecraft:black_concrete
fill 529 172 457 531 172 457 minecraft:black_concrete
fill 538 172 417 538 174 417 minecraft:black_concrete
fill 541 172 418 541 174 418 minecraft:black_concrete
fill 544 172 419 544 174 419 minecraft:black_concrete
setblock 557 172 455 minecraft:black_concrete
fill 558 172 452 558 174 452 minecraft:black_concrete
fill 518 173 442 518 174 442 minecraft:black_concrete
fill 519 173 436 519 174 439 minecraft:black_concrete
fill 520 173 456 522 174 456 minecraft:black_concrete
fill 521 173 417 521 174 417 minecraft:black_concrete
fill 526 173 456 527 173 456 minecraft:black_concrete
fill 529 173 457 530 173 457 minecraft:black_concrete
fill 537 173 417 537 174 417 minecraft:black_concrete
fill 539 173 457 539 174 457 minecraft:black_concrete
fill 540 173 418 540 174 418 minecraft:black_concrete
fill 543 173 419 543 174 419 minecraft:black_concrete
fill 518 174 443 518 174 444 minecraft:black_concrete
setblock 519 174 435 minecraft:black_concrete
fill 519 174 440 519 174 441 minecraft:black_concrete
setblock 520 174 417 minecraft:black_concrete
setblock 520 174 438 minecraft:black_concrete
setblock 526 174 456 minecraft:black_concrete
setblock 529 174 457 minecraft:black_concrete
setblock 536 174 417 minecraft:black_concrete
setblock 539 174 418 minecraft:black_concrete
setblock 541 174 453 minecraft:white_wool
setblock 542 174 419 minecraft:black_concrete
fill 551 174 456 552 174 456 minecraft:black_concrete
setblock 558 174 418 minecraft:black_concrete
setblock 520 176 419 minecraft:light[level=12]
setblock 520 176 427 minecraft:light[level=12]
setblock 520 176 435 minecraft:light[level=12]
setblock 520 176 443 minecraft:light[level=12]
setblock 520 176 451 minecraft:light[level=12]
setblock 528 176 419 minecraft:light[level=12]
setblock 528 176 427 minecraft:light[level=12]
setblock 528 176 435 minecraft:light[level=12]
setblock 528 176 443 minecraft:light[level=12]
setblock 528 176 451 minecraft:light[level=12]
setblock 536 176 419 minecraft:light[level=12]
setblock 536 176 427 minecraft:light[level=12]
setblock 536 176 435 minecraft:light[level=12]
setblock 536 176 443 minecraft:light[level=12]
setblock 536 176 451 minecraft:light[level=12]
setblock 544 176 419 minecraft:light[level=12]
setblock 544 176 427 minecraft:light[level=12]
setblock 544 176 435 minecraft:light[level=12]
setblock 544 176 443 minecraft:light[level=12]
setblock 544 176 451 minecraft:light[level=12]
setblock 552 176 419 minecraft:light[level=12]
setblock 552 176 427 minecraft:light[level=12]
setblock 552 176 435 minecraft:light[level=12]
setblock 552 176 443 minecraft:light[level=12]
setblock 552 176 451 minecraft:light[level=12]
fill 519 180 435 535 180 439 minecraft:black_concrete
fill 520 180 431 535 180 434 minecraft:black_concrete
fill 520 180 440 556 180 443 minecraft:black_concrete
fill 521 180 429 555 180 430 minecraft:black_concrete
fill 521 180 444 555 180 445 minecraft:black_concrete
fill 522 180 427 554 180 428 minecraft:black_concrete
fill 522 180 446 554 180 447 minecraft:black_concrete
fill 523 180 426 553 180 426 minecraft:black_concrete
fill 523 180 448 553 180 448 minecraft:black_concrete
fill 524 180 424 552 180 425 minecraft:black_concrete
fill 524 180 449 552 180 450 minecraft:black_concrete
fill 525 180 423 551 180 423 minecraft:black_concrete
fill 525 180 451 551 180 451 minecraft:black_concrete
fill 527 180 422 549 180 422 minecraft:black_concrete
fill 527 180 452 549 180 452 minecraft:black_concrete
fill 528 180 421 548 180 421 minecraft:black_concrete
fill 528 180 453 548 180 453 minecraft:black_concrete
fill 530 180 420 546 180 420 minecraft:black_concrete
fill 530 180 454 546 180 454 minecraft:black_concrete
fill 532 180 419 544 180 419 minecraft:black_concrete
fill 532 180 455 544 180 455 minecraft:black_concrete
fill 536 180 418 540 180 418 minecraft:black_concrete
fill 536 180 431 536 180 432 minecraft:black_concrete
setblock 536 180 433 minecraft:red_concrete
setblock 536 180 435 minecraft:red_concrete
fill 536 180 436 536 180 439 minecraft:black_concrete
fill 536 180 456 540 180 456 minecraft:black_concrete
fill 537 180 431 556 180 431 minecraft:black_concrete
setblock 537 180 432 minecraft:red_concrete
setblock 537 180 436 minecraft:red_concrete
fill 537 180 437 557 180 439 minecraft:black_concrete
setblock 539 180 432 minecraft:red_concrete
setblock 539 180 436 minecraft:red_concrete
fill 540 180 432 556 180 432 minecraft:black_concrete
setblock 540 180 433 minecraft:red_concrete
setblock 540 180 435 minecraft:red_concrete
fill 540 180 436 557 180 436 minecraft:black_concrete
fill 541 180 433 556 180 435 minecraft:black_concrete
setblock 557 180 435 minecraft:black_concrete
fill 518 181 417 519 181 457 minecraft:cobbled_deepslate
fill 520 181 417 520 181 432 minecraft:cobbled_deepslate
fill 520 181 433 533 181 441 minecraft:black_concrete
fill 520 181 442 520 181 457 minecraft:cobbled_deepslate
fill 521 181 417 521 181 429 minecraft:cobbled_deepslate
fill 521 181 430 535 181 432 minecraft:black_concrete
fill 521 181 442 535 181 444 minecraft:black_concrete
fill 521 181 445 521 181 457 minecraft:cobbled_deepslate
fill 522 181 417 522 181 427 minecraft:cobbled_deepslate
fill 522 181 428 533 181 429 minecraft:black_concrete
fill 522 181 445 554 181 446 minecraft:black_concrete
fill 522 181 447 522 181 457 minecraft:cobbled_deepslate
fill 523 181 417 523 181 426 minecraft:cobbled_deepslate
fill 523 181 427 533 181 427 minecraft:black_concrete
fill 523 181 447 553 181 447 minecraft:black_concrete
fill 523 181 448 523 181 457 minecraft:cobbled_deepslate
fill 524 181 417 524 181 424 minecraft:cobbled_deepslate
fill 524 181 425 535 181 426 minecraft:black_concrete
fill 524 181 448 552 181 449 minecraft:black_concrete
fill 524 181 450 524 181 457 minecraft:cobbled_deepslate
fill 525 181 417 525 181 423 minecraft:cobbled_deepslate
fill 525 181 424 551 181 424 minecraft:black_concrete
fill 525 181 450 551 181 450 minecraft:black_concrete
fill 525 181 451 525 181 457 minecraft:cobbled_deepslate
fill 526 181 417 527 181 422 minecraft:cobbled_deepslate
fill 526 181 423 550 181 423 minecraft:black_concrete
fill 526 181 451 550 181 451 minecraft:black_concrete
fill 526 181 452 527 181 457 minecraft:cobbled_deepslate
fill 528 181 417 528 181 421 minecraft:cobbled_deepslate
fill 528 181 422 548 181 422 minecraft:black_concrete
fill 528 181 452 548 181 452 minecraft:black_concrete
fill 528 181 453 528 181 457 minecraft:cobbled_deepslate
fill 529 181 417 530 181 420 minecraft:cobbled_deepslate
fill 529 181 421 547 181 421 minecraft:black_concrete
fill 529 181 453 547 181 453 minecraft:black_concrete
fill 529 181 454 530 181 457 minecraft:cobbled_deepslate
fill 531 181 417 533 181 419 minecraft:cobbled_deepslate
fill 531 181 420 545 181 420 minecraft:black_concrete
fill 531 181 454 545 181 454 minecraft:black_concrete
fill 531 181 455 533 181 457 minecraft:cobbled_deepslate
fill 534 181 417 558 181 418 minecraft:cobbled_deepslate
fill 534 181 419 542 181 419 minecraft:black_concrete
fill 534 181 427 542 192 428 minecraft:green_terracotta
fill 534 181 429 535 181 429 minecraft:black_concrete
fill 534 181 433 534 181 439 minecraft:black_concrete
fill 534 181 440 542 192 441 minecraft:lime_terracotta
fill 534 181 455 542 181 455 minecraft:black_concrete
fill 534 181 456 558 181 457 minecraft:cobbled_deepslate
fill 535 181 433 535 181 435 minecraft:crying_obsidian
setblock 535 181 436 minecraft:red_concrete
fill 535 181 437 535 181 439 minecraft:black_concrete
fill 536 181 425 552 181 425 minecraft:black_concrete
fill 536 181 426 540 192 426 minecraft:green_terracotta
fill 536 181 429 540 191 429 minecraft:green_terracotta
fill 536 181 430 536 181 431 minecraft:black_concrete
fill 536 181 432 536 181 433 minecraft:verdant_froglight
fill 536 181 435 536 181 436 minecraft:verdant_froglight
setblock 536 181 437 minecraft:red_concrete
fill 536 181 438 537 181 438 minecraft:black_concrete
fill 536 181 439 540 191 439 minecraft:lime_terracotta
fill 536 181 442 540 192 442 minecraft:lime_terracotta
fill 536 181 443 555 181 444 minecraft:black_concrete
fill 537 181 430 555 181 430 minecraft:black_concrete
fill 537 181 431 539 181 431 minecraft:crying_obsidian
setblock 537 181 432 minecraft:verdant_froglight
setblock 537 181 436 minecraft:verdant_froglight
fill 537 181 437 539 181 437 minecraft:crying_obsidian
setblock 538 181 438 minecraft:red_concrete
fill 539 181 432 540 181 432 minecraft:verdant_froglight
fill 539 181 436 540 181 436 minecraft:verdant_froglight
fill 539 181 438 556 181 438 minecraft:black_concrete
fill 540 181 431 555 181 431 minecraft:black_concrete
setblock 540 181 433 minecraft:verdant_froglight
setblock 540 181 435 minecraft:verdant_froglight
setblock 540 181 437 minecraft:red_concrete
fill 541 181 426 552 181 426 minecraft:black_concrete
fill 541 181 429 554 181 429 minecraft:black_concrete
fill 541 181 432 555 181 432 minecraft:black_concrete
fill 541 181 433 541 181 435 minecraft:crying_obsidian
setblock 541 181 436 minecraft:red_concrete
fill 541 181 437 556 181 437 minecraft:black_concrete
fill 541 181 439 556 181 439 minecraft:black_concrete
fill 541 181 442 555 181 442 minecraft:black_concrete
fill 542 181 433 556 181 436 minecraft:black_concrete
fill 543 181 419 558 181 419 minecraft:cobbled_deepslate
fill 543 181 427 553 181 428 minecraft:black_concrete
fill 543 181 440 556 181 441 minecraft:black_concrete
fill 543 181 455 558 181 455 minecraft:cobbled_deepslate
fill 546 181 420 558 181 420 minecraft:cobbled_deepslate
fill 546 181 454 558 181 454 minecraft:cobbled_deepslate
fill 548 181 421 558 181 421 minecraft:cobbled_deepslate
fill 548 181 453 558 181 453 minecraft:cobbled_deepslate
fill 549 181 422 558 181 422 minecraft:cobbled_deepslate
fill 549 181 452 558 181 452 minecraft:cobbled_deepslate
fill 551 181 423 558 181 423 minecraft:cobbled_deepslate
fill 551 181 451 558 181 451 minecraft:cobbled_deepslate
fill 552 181 424 558 181 424 minecraft:cobbled_deepslate
fill 552 181 450 558 181 450 minecraft:cobbled_deepslate
fill 553 181 425 558 181 426 minecraft:cobbled_deepslate
fill 553 181 448 558 181 449 minecraft:cobbled_deepslate
fill 554 181 427 558 181 427 minecraft:cobbled_deepslate
setblock 554 181 428 minecraft:black_concrete
fill 554 181 447 558 181 447 minecraft:cobbled_deepslate
fill 555 181 428 558 181 429 minecraft:cobbled_deepslate
fill 555 181 445 558 181 446 minecraft:cobbled_deepslate
fill 556 181 430 558 181 432 minecraft:cobbled_deepslate
fill 556 181 442 558 181 444 minecraft:cobbled_deepslate
fill 557 181 433 558 181 441 minecraft:cobbled_deepslate
fill 521 182 432 531 182 442 minecraft:black_concrete
fill 522 182 429 531 182 431 minecraft:black_concrete
fill 522 182 443 534 182 445 minecraft:black_concrete
fill 523 182 428 531 182 428 minecraft:black_concrete
fill 523 182 446 553 182 446 minecraft:black_concrete
fill 524 182 426 531 182 427 minecraft:black_concrete
fill 524 182 447 552 182 448 minecraft:black_concrete
fill 525 182 425 534 182 425 minecraft:black_concrete
fill 525 182 449 551 182 449 minecraft:black_concrete
fill 526 182 424 550 182 424 minecraft:black_concrete
fill 526 182 450 550 182 450 minecraft:black_concrete
fill 527 182 423 549 182 423 minecraft:black_concrete
fill 527 182 451 549 182 451 minecraft:black_concrete
fill 529 182 422 547 182 422 minecraft:black_concrete
fill 529 182 452 547 182 452 minecraft:black_concrete
fill 530 182 421 546 182 421 minecraft:black_concrete
fill 530 182 453 546 182 453 minecraft:black_concrete
fill 532 182 426 533 191 429 minecraft:green_terracotta
fill 532 182 430 533 182 438 minecraft:black_concrete
fill 532 182 439 533 191 442 minecraft:lime_terracotta
fill 533 182 420 543 182 420 minecraft:black_concrete
fill 533 182 454 543 182 454 minecraft:black_concrete
fill 534 182 426 535 192 426 minecraft:green_terracotta
fill 534 182 429 535 192 429 minecraft:green_terracotta
fill 534 182 430 534 182 432 minecraft:black_concrete
fill 534 182 433 534 182 436 minecraft:red_concrete
fill 534 182 437 534 182 438 minecraft:black_concrete
fill 534 182 439 535 192 439 minecraft:lime_terracotta
fill 534 182 442 535 192 442 minecraft:lime_terracotta
fill 535 182 425 541 191 425 minecraft:green_terracotta
fill 535 182 430 541 186 430 minecraft:green_terracotta
setblock 535 182 431 minecraft:black_concrete
setblock 535 182 432 minecraft:red_concrete
setblock 535 182 437 minecraft:red_concrete
fill 535 182 438 541 186 438 minecraft:lime_terracotta
fill 535 182 443 541 191 443 minecraft:lime_terracotta
fill 535 182 444 554 182 445 minecraft:black_concrete
fill 536 182 431 540 182 431 minecraft:red_concrete
fill 541 182 426 544 191 426 minecraft:green_terracotta
fill 541 182 429 544 191 429 minecraft:green_terracotta
fill 541 182 431 554 182 431 minecraft:black_concrete
setblock 541 182 432 minecraft:red_concrete
setblock 541 182 437 minecraft:red_concrete
fill 541 182 439 544 191 439 minecraft:lime_terracotta
fill 541 182 442 544 191 442 minecraft:lime_terracotta
fill 542 182 425 551 182 425 minecraft:black_concrete
fill 542 182 430 554 182 430 minecraft:black_concrete
fill 542 182 432 555 182 432 minecraft:black_concrete
fill 542 182 433 542 182 436 minecraft:red_concrete
fill 542 182 437 555 182 438 minecraft:black_concrete
fill 542 182 443 554 182 443 minecraft:black_concrete
fill 543 182 427 544 192 428 minecraft:green_terracotta
fill 543 182 433 555 182 436 minecraft:black_concrete
fill 543 182 440 544 192 441 minecraft:lime_terracotta
fill 545 182 426 552 182 429 minecraft:black_concrete
fill 545 182 439 555 182 442 minecraft:black_concrete
fill 553 182 428 553 182 429 minecraft:black_concrete
setblock 554 182 429 minecraft:black_concrete
fill 521 183 434 529 183 440 minecraft:black_concrete
fill 522 183 431 533 183 433 minecraft:black_concrete
fill 522 183 441 529 183 443 minecraft:black_concrete
fill 523 183 429 530 183 430 minecraft:black_concrete
fill 523 183 444 536 183 445 minecraft:black_concrete
fill 524 183 427 529 183 428 minecraft:black_concrete
fill 524 183 446 552 183 447 minecraft:black_concrete
fill 525 183 426 530 183 426 minecraft:black_concrete
fill 525 183 448 551 183 448 minecraft:black_concrete
fill 526 183 425 531 183 425 minecraft:black_concrete
fill 526 183 449 550 183 449 minecraft:black_concrete
fill 527 183 424 536 183 424 minecraft:black_concrete
fill 527 183 450 549 183 450 minecraft:black_concrete
fill 528 183 423 548 183 423 minecraft:black_concrete
fill 528 183 451 548 183 451 minecraft:black_concrete
fill 530 183 422 546 183 422 minecraft:black_concrete
fill 530 183 427 531 191 428 minecraft:green_terracotta
fill 530 183 434 530 183 439 minecraft:black_concrete
fill 530 183 440 531 191 441 minecraft:lime_terracotta
fill 530 183 442 530 183 443 minecraft:black_concrete
fill 530 183 452 546 183 452 minecraft:black_concrete
fill 531 183 426 531 191 426 minecraft:green_terracotta
fill 531 183 429 531 191 429 minecraft:green_terracotta
setblock 531 183 430 minecraft:black_concrete
fill 531 183 434 531 183 438 minecraft:black_concrete
fill 531 183 439 531 191 439 minecraft:lime_terracotta
fill 531 183 442 531 191 442 minecraft:lime_terracotta
setblock 531 183 443 minecraft:black_concrete
fill 532 183 421 544 183 421 minecraft:black_concrete
fill 532 183 425 534 190 425 minecraft:green_terracotta
fill 532 183 430 534 187 430 minecraft:green_terracotta
fill 532 183 434 532 183 437 minecraft:black_concrete
fill 532 183 438 534 187 438 minecraft:lime_terracotta
fill 532 183 443 534 190 443 minecraft:lime_terracotta
fill 532 183 453 544 183 453 minecraft:black_concrete
fill 533 183 434 533 183 436 minecraft:red_concrete
setblock 533 183 437 minecraft:black_concrete
setblock 534 183 431 minecraft:black_concrete
fill 534 183 432 534 183 433 minecraft:red_concrete
setblock 534 183 437 minecraft:red_concrete
fill 535 183 420 541 183 420 minecraft:black_concrete
fill 535 183 431 536 183 431 minecraft:red_concrete
fill 535 183 454 541 183 454 minecraft:black_concrete
fill 537 183 424 539 190 424 minecraft:green_terracotta
fill 537 183 431 539 183 431 minecraft:green_terracotta
fill 537 183 437 539 183 437 minecraft:lime_terracotta
fill 537 183 444 539 190 444 minecraft:lime_terracotta
fill 537 183 445 553 183 445 minecraft:black_concrete
fill 540 183 424 549 183 424 minecraft:black_concrete
fill 540 183 431 541 183 431 minecraft:red_concrete
fill 540 183 444 553 183 444 minecraft:black_concrete
fill 542 183 425 544 190 425 minecraft:green_terracotta
fill 542 183 430 544 186 430 minecraft:green_terracotta
fill 542 183 431 554 183 431 minecraft:black_concrete
fill 542 183 432 542 183 433 minecraft:red_concrete
setblock 542 183 437 minecraft:red_concrete
fill 542 183 438 544 186 438 minecraft:lime_terracotta
fill 542 183 443 544 190 443 minecraft:lime_terracotta
fill 543 183 432 554 183 433 minecraft:black_concrete
fill 543 183 434 543 183 436 minecraft:red_concrete
fill 543 183 437 555 183 437 minecraft:black_concrete
fill 544 183 434 555 183 436 minecraft:black_concrete
fill 545 183 425 550 183 425 minecraft:black_concrete
fill 545 183 426 545 191 429 minecraft:green_terracotta
fill 545 183 430 553 183 430 minecraft:black_concrete
fill 545 183 438 555 183 438 minecraft:black_concrete
fill 545 183 439 545 191 442 minecraft:lime_terracotta
fill 545 183 443 554 183 443 minecraft:black_concrete
fill 546 183 426 551 183 426 minecraft:black_concrete
fill 546 183 427 546 191 428 minecraft:green_terracotta
fill 546 183 429 553 183 429 minecraft:black_concrete
fill 546 183 439 555 183 439 minecraft:black_concrete
fill 546 183 440 546 191 441 minecraft:lime_terracotta
fill 546 183 442 554 183 442 minecraft:black_concrete
fill 547 183 427 552 183 428 minecraft:black_concrete
fill 547 183 440 554 183 441 minecraft:black_concrete
setblock 555 183 440 minecraft:black_concrete
setblock 520 184 419 minecraft:light[level=12]
setblock 520 184 427 minecraft:light[level=12]
setblock 520 184 435 minecraft:light[level=12]
setblock 520 184 443 minecraft:light[level=12]
setblock 520 184 451 minecraft:light[level=12]
fill 522 184 433 528 184 441 minecraft:black_concrete
fill 523 184 430 530 184 432 minecraft:black_concrete
fill 523 184 442 528 184 444 minecraft:black_concrete
fill 524 184 429 528 184 429 minecraft:black_concrete
fill 524 184 445 552 184 445 minecraft:black_concrete
fill 525 184 427 528 184 428 minecraft:black_concrete
fill 525 184 446 551 184 447 minecraft:black_concrete
fill 526 184 426 528 184 426 minecraft:black_concrete
fill 526 184 448 550 184 448 minecraft:black_concrete
fill 527 184 425 530 184 425 minecraft:black_concrete
fill 527 184 449 549 184 449 minecraft:black_concrete
setblock 528 184 419 minecraft:light[level=12]
fill 528 184 424 533 184 424 minecraft:black_concrete
fill 528 184 450 548 184 450 minecraft:black_concrete
setblock 528 184 451 minecraft:light[level=12]
fill 529 184 426 529 189 429 minecraft:green_terracotta
fill 529 184 433 530 184 438 minecraft:black_concrete
fill 529 184 439 529 189 442 minecraft:lime_terracotta
fill 529 184 443 530 184 444 minecraft:black_concrete
fill 530 184 423 546 184 423 minecraft:black_concrete
fill 530 184 426 530 190 426 minecraft:green_terracotta
fill 530 184 429 530 190 429 minecraft:green_terracotta
fill 530 184 439 530 190 439 minecraft:lime_terracotta
fill 530 184 442 530 190 442 minecraft:lime_terracotta
fill 530 184 451 546 184 451 minecraft:black_concrete
fill 531 184 422 545 184 422 minecraft:black_concrete
fill 531 184 425 531 190 425 minecraft:green_terracotta
fill 531 184 430 531 190 430 minecraft:green_terracotta
fill 531 184 431 531 184 437 minecraft:black_concrete
fill 531 184 438 531 190 438 minecraft:lime_terracotta
fill 531 184 443 531 190 443 minecraft:lime_terracotta
fill 531 184 444 533 184 444 minecraft:black_concrete
fill 531 184 452 545 184 452 minecraft:black_concrete
fill 532 184 431 532 184 433 minecraft:black_concrete
fill 532 184 434 532 184 436 minecraft:red_concrete
setblock 532 184 437 minecraft:black_concrete
fill 533 184 431 533 184 432 minecraft:black_concrete
setblock 533 184 433 minecraft:red_concrete
setblock 533 184 437 minecraft:red_concrete
fill 534 184 421 542 184 421 minecraft:black_concrete
fill 534 184 424 536 190 424 minecraft:green_terracotta
fill 534 184 431 537 184 431 minecraft:green_terracotta
setblock 534 184 432 minecraft:red_concrete
fill 534 184 437 537 184 437 minecraft:lime_terracotta
fill 534 184 444 536 190 444 minecraft:lime_terracotta
fill 534 184 453 542 184 453 minecraft:black_concrete
setblock 536 184 419 minecraft:light[level=12]
fill 539 184 431 542 184 431 minecraft:green_terracotta
fill 539 184 437 542 184 437 minecraft:lime_terracotta
fill 540 184 424 542 190 424 minecraft:green_terracotta
fill 540 184 444 542 190 444 minecraft:lime_terracotta
setblock 542 184 432 minecraft:red_concrete
fill 543 184 424 548 184 424 minecraft:black_concrete
fill 543 184 431 553 184 432 minecraft:black_concrete
setblock 543 184 433 minecraft:red_concrete
setblock 543 184 437 minecraft:red_concrete
fill 543 184 444 553 184 444 minecraft:black_concrete
setblock 544 184 419 minecraft:light[level=12]
fill 544 184 433 554 184 433 minecraft:black_concrete
fill 544 184 434 544 184 436 minecraft:red_concrete
fill 544 184 437 554 184 437 minecraft:black_concrete
fill 545 184 425 545 190 425 minecraft:green_terracotta
fill 545 184 430 545 188 430 minecraft:green_terracotta
fill 545 184 434 554 184 436 minecraft:black_concrete
fill 545 184 438 545 188 438 minecraft:lime_terracotta
fill 545 184 443 545 190 443 minecraft:lime_terracotta
fill 546 184 425 549 184 425 minecraft:black_concrete
fill 546 184 426 547 189 426 minecraft:green_terracotta
fill 546 184 429 547 189 429 minecraft:green_terracotta
fill 546 184 430 553 184 430 minecraft:black_concrete
fill 546 184 438 554 184 438 minecraft:black_concrete
fill 546 184 439 547 189 439 minecraft:lime_terracotta
fill 546 184 442 547 189 442 minecraft:lime_terracotta
fill 546 184 443 553 184 443 minecraft:black_concrete
fill 547 184 427 547 190 428 minecraft:green_terracotta
fill 547 184 440 547 190 441 minecraft:lime_terracotta
fill 548 184 426 550 184 429 minecraft:black_concrete
fill 548 184 439 553 184 442 minecraft:black_concrete
fill 551 184 427 551 184 429 minecraft:black_concrete
setblock 552 184 419 minecraft:light[level=12]
setblock 552 184 427 minecraft:light[level=12]
setblock 552 184 429 minecraft:black_concrete
setblock 552 184 451 minecraft:light[level=12]
fill 554 184 439 554 184 441 minecraft:black_concrete
fill 518 185 417 518 185 454 minecraft:black_concrete
fill 519 185 417 522 185 417 minecraft:black_concrete
fill 519 185 419 519 186 451 minecraft:black_concrete
fill 520 185 422 520 185 428 minecraft:black_concrete
fill 520 185 438 520 185 448 minecraft:black_concrete
fill 522 185 446 522 194 446 minecraft:white_wool
fill 523 185 432 527 185 442 minecraft:black_concrete
fill 524 185 430 529 185 431 minecraft:black_concrete
fill 524 185 443 529 185 444 minecraft:black_concrete
fill 525 185 428 527 185 429 minecraft:black_concrete
fill 525 185 445 551 185 446 minecraft:black_concrete
fill 526 185 427 527 185 427 minecraft:black_concrete
fill 526 185 447 550 186 447 minecraft:black_concrete
fill 527 185 426 528 185 426 minecraft:black_concrete
fill 527 185 448 549 185 448 minecraft:black_concrete
fill 528 185 425 529 185 425 minecraft:black_concrete
fill 528 185 427 528 189 428 minecraft:green_terracotta
setblock 528 185 429 minecraft:black_concrete
fill 528 185 432 528 185 439 minecraft:black_concrete
fill 528 185 440 528 189 441 minecraft:lime_terracotta
setblock 528 185 442 minecraft:black_concrete
fill 528 185 449 548 185 449 minecraft:black_concrete
fill 529 185 424 531 185 424 minecraft:black_concrete
fill 529 185 432 529 185 438 minecraft:black_concrete
fill 529 185 450 547 185 450 minecraft:black_concrete
fill 530 185 425 530 189 425 minecraft:green_terracotta
fill 530 185 430 530 189 430 minecraft:green_terracotta
fill 530 185 431 530 186 437 minecraft:black_concrete
fill 530 185 438 530 189 438 minecraft:lime_terracotta
fill 530 185 443 530 189 443 minecraft:lime_terracotta
fill 530 185 444 531 188 444 minecraft:black_concrete
fill 531 185 423 545 185 423 minecraft:black_concrete
fill 531 185 431 531 185 435 minecraft:black_concrete
fill 531 185 436 531 186 436 minecraft:red_concrete
setblock 531 185 437 minecraft:black_concrete
fill 531 185 451 545 186 451 minecraft:black_concrete
fill 532 185 417 547 185 417 minecraft:black_concrete
fill 532 185 424 533 188 424 minecraft:green_terracotta
fill 532 185 431 536 186 431 minecraft:green_terracotta
setblock 532 185 432 minecraft:black_concrete
fill 532 185 433 532 185 435 minecraft:red_concrete
fill 532 185 437 536 186 437 minecraft:lime_terracotta
fill 532 185 444 533 188 444 minecraft:lime_terracotta
fill 533 185 418 544 185 418 minecraft:black_concrete
fill 533 185 422 543 185 422 minecraft:black_concrete
setblock 533 185 432 minecraft:red_concrete
fill 533 185 452 543 185 452 minecraft:black_concrete
fill 534 185 419 543 185 419 minecraft:black_concrete
fill 536 185 420 540 185 420 minecraft:black_concrete
fill 536 185 457 545 185 457 minecraft:black_concrete
fill 540 185 431 544 186 431 minecraft:green_terracotta
fill 540 185 437 544 186 437 minecraft:lime_terracotta
fill 541 185 453 541 194 453 minecraft:white_wool
fill 543 185 424 544 188 424 minecraft:green_terracotta
setblock 543 185 432 minecraft:red_concrete
fill 543 185 444 544 188 444 minecraft:lime_terracotta
fill 544 185 432 553 185 432 minecraft:black_concrete
fill 544 185 433 544 185 435 minecraft:red_concrete
fill 545 185 424 547 185 424 minecraft:black_concrete
fill 545 185 431 552 185 431 minecraft:black_concrete
fill 545 185 433 553 185 435 minecraft:black_concrete
fill 545 185 436 545 186 436 minecraft:red_concrete
fill 545 185 437 553 185 437 minecraft:black_concrete
fill 545 185 444 552 185 444 minecraft:black_concrete
fill 546 185 425 546 189 425 minecraft:green_terracotta
fill 546 185 430 546 189 430 minecraft:green_terracotta
fill 546 185 436 553 185 436 minecraft:black_concrete
fill 546 185 438 546 189 438 minecraft:lime_terracotta
fill 546 185 443 546 189 443 minecraft:lime_terracotta
fill 547 185 425 548 185 425 minecraft:black_concrete
fill 547 185 430 552 185 430 minecraft:black_concrete
fill 547 185 438 553 185 438 minecraft:black_concrete
fill 547 185 443 552 185 443 minecraft:black_concrete
fill 548 185 426 549 185 426 minecraft:black_concrete
fill 548 185 427 548 189 428 minecraft:green_terracotta
fill 548 185 429 551 185 429 minecraft:black_concrete
fill 548 185 439 553 185 439 minecraft:black_concrete
fill 548 185 440 548 189 441 minecraft:lime_terracotta
fill 548 185 442 553 185 442 minecraft:black_concrete
fill 549 185 427 550 185 428 minecraft:black_concrete
fill 549 185 440 553 185 441 minecraft:black_concrete
setblock 551 185 428 minecraft:black_concrete
fill 553 185 457 558 185 457 minecraft:black_concrete
fill 555 185 417 558 185 417 minecraft:black_concrete
fill 556 185 441 558 186 450 minecraft:black_concrete
fill 557 185 420 558 185 426 minecraft:black_concrete
fill 557 185 438 558 186 440 minecraft:black_concrete
fill 557 185 451 558 198 454 minecraft:black_concrete
fill 558 185 418 558 186 419 minecraft:black_concrete
fill 558 185 427 558 199 437 minecraft:black_concrete
fill 558 185 455 558 199 456 minecraft:black_concrete
fill 518 186 418 518 186 453 minecraft:black_concrete
fill 518 186 455 557 186 455 minecraft:black_concrete
fill 520 186 419 521 187 419 minecraft:black_concrete
fill 520 186 423 520 187 428 minecraft:black_concrete
fill 520 186 435 522 187 435 minecraft:black_concrete
fill 520 186 439 520 186 447 minecraft:black_concrete
fill 520 186 451 530 186 451 minecraft:black_concrete
fill 521 186 423 526 187 423 minecraft:black_concrete
fill 521 186 427 521 187 427 minecraft:black_concrete
fill 521 186 439 527 187 439 minecraft:black_concrete
fill 521 186 443 528 186 443 minecraft:black_concrete
fill 521 186 447 525 187 447 minecraft:black_concrete
fill 524 186 432 528 186 438 minecraft:black_concrete
fill 524 186 440 527 186 442 minecraft:black_concrete
fill 525 186 430 528 186 431 minecraft:black_concrete
fill 525 186 444 529 186 444 minecraft:black_concrete
fill 526 186 429 527 186 429 minecraft:black_concrete
fill 526 186 445 550 186 445 minecraft:black_concrete
fill 527 186 427 527 186 428 minecraft:black_concrete
fill 527 186 446 549 186 446 minecraft:black_concrete
fill 528 186 426 528 188 426 minecraft:green_terracotta
fill 528 186 429 528 188 429 minecraft:green_terracotta
fill 528 186 439 528 188 439 minecraft:lime_terracotta
fill 528 186 442 528 188 442 minecraft:lime_terracotta
fill 528 186 448 548 186 448 minecraft:black_concrete
fill 529 186 425 529 187 425 minecraft:green_terracotta
fill 529 186 430 529 187 430 minecraft:green_terracotta
fill 529 186 431 529 187 437 minecraft:black_concrete
fill 529 186 438 529 187 438 minecraft:lime_terracotta
fill 529 186 443 529 187 443 minecraft:lime_terracotta
fill 530 186 449 546 186 449 minecraft:black_concrete
setblock 531 186 424 minecraft:black_concrete
fill 531 186 431 531 186 432 minecraft:black_concrete
fill 531 186 433 531 186 435 minecraft:red_concrete
setblock 531 186 437 minecraft:red_concrete
fill 531 186 450 545 186 450 minecraft:black_concrete
fill 532 186 417 545 186 417 minecraft:black_concrete
setblock 532 186 432 minecraft:red_concrete
fill 533 186 423 543 187 423 minecraft:black_concrete
fill 534 186 418 543 186 418 minecraft:black_concrete
fill 535 186 419 541 187 419 minecraft:black_concrete
fill 536 186 457 543 186 457 minecraft:black_concrete
setblock 544 186 432 minecraft:red_concrete
setblock 545 186 424 minecraft:black_concrete
fill 545 186 431 551 186 432 minecraft:black_concrete
fill 545 186 433 545 186 435 minecraft:red_concrete
setblock 545 186 437 minecraft:red_concrete
fill 545 186 444 551 186 444 minecraft:black_concrete
fill 546 186 433 552 186 437 minecraft:black_concrete
fill 546 186 451 556 186 451 minecraft:black_concrete
fill 547 186 425 547 187 425 minecraft:green_terracotta
fill 547 186 430 547 187 430 minecraft:green_terracotta
fill 547 186 438 547 187 438 minecraft:lime_terracotta
fill 547 186 443 547 187 443 minecraft:lime_terracotta
fill 548 186 426 548 188 426 minecraft:green_terracotta
fill 548 186 429 548 188 429 minecraft:green_terracotta
fill 548 186 430 551 186 430 minecraft:black_concrete
fill 548 186 438 552 186 438 minecraft:black_concrete
fill 548 186 439 548 188 439 minecraft:lime_terracotta
fill 548 186 442 548 188 442 minecraft:lime_terracotta
fill 548 186 443 555 186 443 minecraft:black_concrete
fill 549 186 427 549 186 429 minecraft:black_concrete
fill 549 186 439 552 186 442 minecraft:black_concrete
setblock 550 186 429 minecraft:black_concrete
fill 551 186 447 555 186 447 minecraft:black_concrete
setblock 552 186 432 minecraft:black_concrete
fill 553 186 439 556 186 439 minecraft:black_concrete
fill 554 186 457 558 199 457 minecraft:black_concrete
fill 557 186 417 558 186 417 minecraft:black_concrete
fill 557 186 422 558 186 426 minecraft:black_concrete
fill 558 186 420 558 188 421 minecraft:black_concrete
fill 518 187 419 518 188 453 minecraft:black_concrete
fill 518 187 455 535 187 455 minecraft:black_concrete
setblock 519 187 419 minecraft:black_concrete
fill 519 187 421 519 187 451 minecraft:black_concrete
fill 520 187 431 528 187 431 minecraft:black_concrete
setblock 520 187 439 minecraft:black_concrete
fill 520 187 443 520 187 447 minecraft:black_concrete
fill 520 187 451 524 187 451 minecraft:black_concrete
fill 522 187 419 534 187 419 minecraft:black_concrete
fill 522 187 427 527 187 427 minecraft:black_concrete
fill 523 187 435 528 187 435 minecraft:black_concrete
fill 525 187 433 528 187 434 minecraft:black_concrete
fill 525 187 436 528 187 438 minecraft:black_concrete
fill 525 187 440 527 187 441 minecraft:black_concrete
fill 526 187 432 528 187 432 minecraft:black_concrete
fill 526 187 442 527 187 443 minecraft:black_concrete
fill 526 187 447 547 187 447 minecraft:black_concrete
fill 527 187 423 532 187 423 minecraft:black_concrete
fill 527 187 429 527 187 430 minecraft:black_concrete
fill 527 187 444 529 187 445 minecraft:black_concrete
fill 528 187 430 528 188 430 minecraft:black_concrete
fill 528 187 443 528 188 443 minecraft:black_concrete
fill 528 187 446 548 187 446 minecraft:black_concrete
fill 530 187 431 530 187 433 minecraft:black_concrete
fill 530 187 434 530 187 437 minecraft:red_concrete
fill 530 187 445 535 187 445 minecraft:black_concrete
fill 530 187 448 546 187 448 minecraft:black_concrete
setblock 531 187 431 minecraft:black_concrete
fill 531 187 432 531 187 433 minecraft:red_concrete
fill 531 187 435 533 187 435 minecraft:black_concrete
fill 532 187 417 543 187 417 minecraft:black_concrete
fill 532 187 431 532 189 431 minecraft:white_concrete
fill 532 187 437 532 189 437 minecraft:white_concrete
fill 532 187 449 544 187 449 minecraft:black_concrete
fill 533 187 431 535 188 431 minecraft:green_terracotta
fill 533 187 437 535 188 437 minecraft:lime_terracotta
fill 534 187 418 541 187 418 minecraft:black_concrete
fill 534 187 450 542 187 450 minecraft:black_concrete
fill 535 187 430 535 191 430 minecraft:green_terracotta
fill 535 187 438 535 191 438 minecraft:lime_terracotta
fill 536 187 430 536 189 431 minecraft:white_concrete
fill 536 187 437 536 189 438 minecraft:white_concrete
fill 536 187 445 540 187 445 minecraft:red_concrete
fill 536 187 454 536 188 456 minecraft:white_wool
fill 536 187 457 542 188 457 minecraft:black_concrete
fill 537 187 430 541 187 430 minecraft:green_terracotta
fill 537 187 438 541 187 438 minecraft:lime_terracotta
fill 537 187 455 551 187 455 minecraft:black_concrete
fill 541 187 431 541 188 431 minecraft:green_terracotta
fill 541 187 437 541 188 437 minecraft:lime_terracotta
fill 541 187 445 549 187 445 minecraft:black_concrete
fill 542 187 419 558 187 419 minecraft:black_concrete
fill 542 187 430 542 189 431 minecraft:white_concrete
fill 542 187 435 545 187 435 minecraft:black_concrete
fill 542 187 437 542 189 438 minecraft:white_concrete
fill 543 187 430 544 187 431 minecraft:green_terracotta
fill 543 187 437 544 187 438 minecraft:lime_terracotta
fill 544 187 423 558 187 423 minecraft:black_concrete
fill 545 187 431 545 189 431 minecraft:white_concrete
fill 545 187 432 545 187 433 minecraft:red_concrete
fill 545 187 437 545 189 437 minecraft:white_concrete
fill 545 187 444 549 187 444 minecraft:black_concrete
fill 546 187 431 550 187 433 minecraft:black_concrete
fill 546 187 434 546 187 437 minecraft:red_concrete
fill 547 187 434 551 187 437 minecraft:black_concrete
fill 548 187 430 549 187 430 minecraft:black_concrete
fill 548 187 438 551 187 438 minecraft:black_concrete
fill 548 187 443 550 187 443 minecraft:black_concrete
fill 549 187 427 557 187 427 minecraft:black_concrete
setblock 549 187 429 minecraft:black_concrete
fill 549 187 439 550 187 442 minecraft:black_concrete
setblock 551 187 433 minecraft:black_concrete
fill 551 187 439 551 187 441 minecraft:black_concrete
fill 552 187 435 557 187 435 minecraft:black_concrete
fill 552 187 446 552 187 457 minecraft:white_wool
fill 553 187 455 557 187 455 minecraft:black_concrete
fill 556 187 442 556 189 451 minecraft:black_concrete
fill 557 187 424 558 193 426 minecraft:black_concrete
fill 557 187 439 558 197 450 minecraft:black_concrete
fill 558 187 422 558 193 422 minecraft:black_concrete
fill 558 187 438 558 215 438 minecraft:black_concrete
fill 519 188 422 519 190 434 minecraft:black_concrete
fill 519 188 438 519 188 450 minecraft:black_concrete
fill 520 188 417 520 189 424 minecraft:white_wool
fill 520 188 425 520 189 429 minecraft:black_concrete
fill 524 188 417 524 189 420 minecraft:white_wool
fill 526 188 435 527 188 439 minecraft:black_concrete
fill 527 188 432 528 188 434 minecraft:black_concrete
fill 527 188 440 527 188 442 minecraft:black_concrete
fill 528 188 417 528 189 425 minecraft:white_wool
fill 528 188 431 530 188 431 minecraft:black_concrete
fill 528 188 435 528 188 438 minecraft:black_concrete
fill 528 188 444 529 188 444 minecraft:black_concrete
fill 528 188 445 528 188 456 minecraft:white_wool
setblock 529 188 430 minecraft:black_concrete
fill 529 188 432 529 188 433 minecraft:black_concrete
fill 529 188 434 529 188 438 minecraft:red_concrete
setblock 529 188 443 minecraft:black_concrete
fill 529 188 445 533 188 445 minecraft:black_concrete
fill 530 188 432 530 188 433 minecraft:red_concrete
fill 530 188 436 531 189 437 minecraft:white_concrete
fill 530 188 446 535 188 446 minecraft:black_concrete
fill 531 188 431 531 189 431 minecraft:white_concrete
fill 531 188 447 545 188 447 minecraft:black_concrete
fill 532 188 417 542 188 417 minecraft:black_concrete
fill 532 188 418 532 189 418 minecraft:white_wool
fill 532 188 430 532 189 430 minecraft:white_concrete
setblock 532 188 436 minecraft:white_concrete
fill 532 188 438 532 189 438 minecraft:white_concrete
fill 533 188 430 534 191 430 minecraft:green_terracotta
fill 533 188 438 534 191 438 minecraft:lime_terracotta
fill 533 188 448 543 188 448 minecraft:black_concrete
fill 534 188 418 540 188 418 minecraft:black_concrete
fill 534 188 445 535 188 445 minecraft:red_concrete
fill 535 188 457 535 212 457 minecraft:black_concrete
fill 536 188 419 536 188 423 minecraft:white_wool
setblock 536 188 445 minecraft:white_wool
fill 536 188 446 540 188 446 minecraft:red_concrete
fill 536 188 449 540 188 449 minecraft:black_concrete
fill 536 188 450 536 188 453 minecraft:white_wool
fill 537 188 430 537 189 431 minecraft:white_concrete
fill 537 188 437 537 189 438 minecraft:white_concrete
fill 539 188 430 541 188 430 minecraft:green_terracotta
fill 539 188 438 541 188 438 minecraft:lime_terracotta
fill 540 188 419 540 188 423 minecraft:white_wool
setblock 540 188 445 minecraft:white_wool
fill 540 188 450 540 188 456 minecraft:white_wool
fill 541 188 445 542 188 445 minecraft:red_concrete
fill 541 188 446 546 188 446 minecraft:black_concrete
fill 543 188 430 544 188 430 minecraft:green_terracotta
fill 543 188 431 543 189 431 minecraft:white_concrete
fill 543 188 437 543 189 437 minecraft:white_concrete
fill 543 188 438 544 188 438 minecraft:lime_terracotta
fill 543 188 445 547 188 445 minecraft:black_concrete
fill 544 188 417 544 188 423 minecraft:white_wool
setblock 544 188 431 minecraft:green_terracotta
fill 544 188 432 544 188 435 minecraft:white_wool
fill 544 188 436 546 188 436 minecraft:white_concrete
setblock 544 188 437 minecraft:lime_terracotta
fill 544 188 448 544 188 456 minecraft:white_wool
fill 545 188 444 548 188 444 minecraft:black_concrete
fill 546 188 431 557 188 431 minecraft:black_concrete
fill 546 188 432 546 188 433 minecraft:red_concrete
fill 546 188 437 546 189 437 minecraft:white_concrete
fill 547 188 430 548 188 430 minecraft:black_concrete
fill 547 188 432 549 188 433 minecraft:black_concrete
fill 547 188 434 547 188 438 minecraft:red_concrete
fill 547 188 443 548 188 443 minecraft:black_concrete
fill 548 188 417 548 188 425 minecraft:white_wool
fill 548 188 434 549 188 438 minecraft:black_concrete
fill 548 188 445 548 188 457 minecraft:white_wool
fill 549 188 439 549 188 442 minecraft:black_concrete
fill 550 188 435 550 188 439 minecraft:black_concrete
fill 552 188 417 552 188 430 minecraft:white_wool
fill 552 188 432 552 188 448 minecraft:white_wool
fill 555 188 447 555 195 448 minecraft:black_concrete
fill 556 188 417 556 188 430 minecraft:white_wool
fill 556 188 432 556 188 441 minecraft:white_wool
fill 556 188 452 556 198 452 minecraft:black_concrete
fill 556 188 453 556 188 456 minecraft:white_wool
fill 557 188 427 557 197 429 minecraft:black_concrete
fill 558 188 423 558 195 423 minecraft:black_concrete
fill 518 189 420 518 195 453 minecraft:black_concrete
fill 519 189 440 519 189 450 minecraft:black_concrete
fill 520 189 430 520 189 456 minecraft:white_wool
fill 524 189 421 524 189 457 minecraft:white_wool
setblock 528 189 426 minecraft:white_wool
fill 528 189 437 529 189 437 minecraft:white_concrete
setblock 529 189 436 minecraft:white_concrete
setblock 529 189 438 minecraft:white_concrete
fill 532 189 417 541 190 417 minecraft:black_concrete
fill 532 189 419 532 189 424 minecraft:white_wool
fill 532 189 432 532 189 436 minecraft:white_wool
fill 532 189 444 532 189 455 minecraft:white_wool
setblock 533 189 424 minecraft:green_terracotta
fill 533 189 431 534 189 431 minecraft:green_terracotta
fill 533 189 437 534 189 437 minecraft:lime_terracotta
setblock 533 189 444 minecraft:lime_terracotta
fill 534 189 418 539 189 418 minecraft:black_concrete
setblock 536 189 432 minecraft:white_concrete
setblock 536 189 436 minecraft:white_concrete
fill 536 189 457 541 212 457 minecraft:black_concrete
fill 540 189 418 540 189 419 minecraft:white_wool
fill 540 189 430 541 189 430 minecraft:green_terracotta
fill 540 189 438 541 189 438 minecraft:lime_terracotta
setblock 542 189 432 minecraft:white_concrete
setblock 542 189 436 minecraft:white_concrete
setblock 543 189 424 minecraft:green_terracotta
setblock 543 189 430 minecraft:white_concrete
setblock 543 189 438 minecraft:white_concrete
setblock 543 189 444 minecraft:lime_terracotta
fill 544 189 417 544 189 418 minecraft:white_wool
fill 544 189 430 544 190 430 minecraft:green_terracotta
fill 544 189 438 544 190 438 minecraft:lime_terracotta
setblock 545 189 430 minecraft:white_concrete
fill 545 189 436 547 189 436 minecraft:white_concrete
setblock 545 189 438 minecraft:white_concrete
fill 547 189 437 547 189 438 minecraft:white_concrete
fill 548 189 417 548 189 419 minecraft:white_wool
setblock 548 189 437 minecraft:white_concrete
fill 552 189 417 552 189 418 minecraft:white_wool
fill 553 189 457 553 206 457 minecraft:black_concrete
fill 555 189 446 555 194 446 minecraft:black_concrete
fill 555 189 449 555 196 449 minecraft:black_concrete
fill 556 189 417 556 189 420 minecraft:white_wool
fill 557 189 430 557 200 430 minecraft:black_concrete
fill 558 189 421 558 190 421 minecraft:black_concrete
fill 518 190 454 518 198 454 minecraft:black_concrete
fill 519 190 435 519 200 435 minecraft:black_concrete
fill 519 190 442 519 190 450 minecraft:black_concrete
fill 520 190 426 520 194 430 minecraft:black_concrete
fill 529 190 427 529 190 428 minecraft:green_terracotta
fill 529 190 440 529 190 441 minecraft:lime_terracotta
fill 531 190 417 531 213 417 minecraft:black_concrete
setblock 532 190 430 minecraft:green_terracotta
setblock 532 190 438 minecraft:lime_terracotta
fill 532 190 453 532 190 456 minecraft:white_wool
fill 533 190 418 538 195 418 minecraft:black_concrete
fill 533 190 457 534 212 457 minecraft:black_concrete
setblock 534 190 431 minecraft:green_terracotta
setblock 534 190 437 minecraft:lime_terracotta
fill 537 190 456 538 203 456 minecraft:black_concrete
fill 541 190 430 543 191 430 minecraft:green_terracotta
fill 541 190 438 543 191 438 minecraft:lime_terracotta
setblock 542 190 431 minecraft:green_terracotta
setblock 542 190 437 minecraft:lime_terracotta
fill 542 190 457 542 215 457 minecraft:black_concrete
setblock 545 190 430 minecraft:green_terracotta
setblock 545 190 438 minecraft:lime_terracotta
setblock 546 190 426 minecraft:green_terracotta
setblock 546 190 429 minecraft:green_terracotta
setblock 546 190 439 minecraft:lime_terracotta
setblock 546 190 442 minecraft:lime_terracotta
fill 551 190 430 551 204 430 minecraft:white_wool
fill 552 190 457 552 208 457 minecraft:black_concrete
fill 555 190 450 556 196 450 minecraft:black_concrete
fill 556 190 443 556 195 449 minecraft:black_concrete
fill 556 190 451 556 198 451 minecraft:black_concrete
fill 556 190 453 556 198 453 minecraft:black_concrete
fill 557 190 431 557 201 433 minecraft:black_concrete
fill 557 190 455 557 198 455 minecraft:black_concrete
fill 519 191 423 519 194 434 minecraft:black_concrete
fill 519 191 444 519 191 451 minecraft:black_concrete
fill 520 191 431 520 197 431 minecraft:black_concrete
fill 532 191 417 540 198 417 minecraft:black_concrete
fill 532 191 457 532 213 457 minecraft:black_concrete
fill 533 191 425 534 191 425 minecraft:green_terracotta
fill 533 191 443 534 191 443 minecraft:lime_terracotta
fill 534 191 456 536 206 456 minecraft:black_concrete
fill 539 191 456 540 202 456 minecraft:black_concrete
fill 542 191 425 543 191 425 minecraft:green_terracotta
fill 542 191 443 543 191 443 minecraft:lime_terracotta
fill 543 191 457 543 214 457 minecraft:black_concrete
fill 550 191 457 551 209 457 minecraft:black_concrete
fill 552 191 456 556 199 456 minecraft:black_concrete
fill 555 191 451 555 197 451 minecraft:black_concrete
fill 556 191 442 556 194 442 minecraft:black_concrete
fill 556 191 454 556 198 454 minecraft:black_concrete
fill 557 191 434 557 204 438 minecraft:black_concrete
fill 518 192 455 518 199 455 minecraft:black_concrete
fill 519 192 436 519 199 436 minecraft:black_concrete
fill 519 192 445 519 192 451 minecraft:black_concrete
setblock 520 192 419 minecraft:light[level=12]
fill 520 192 432 520 197 432 minecraft:black_concrete
setblock 520 192 435 minecraft:light[level=12]
setblock 520 192 443 minecraft:light[level=12]
setblock 520 192 451 minecraft:light[level=12]
setblock 528 192 419 minecraft:light[level=12]
setblock 528 192 427 minecraft:light[level=12]
setblock 528 192 435 minecraft:light[level=12]
setblock 528 192 443 minecraft:light[level=12]
setblock 528 192 451 minecraft:light[level=12]
fill 529 192 417 530 214 417 minecraft:black_concrete
fill 531 192 428 533 193 428 minecraft:pearlescent_froglight
fill 531 192 440 533 193 440 minecraft:pearlescent_froglight
fill 531 192 457 531 213 457 minecraft:black_concrete
fill 532 192 418 532 211 418 minecraft:black_concrete
fill 532 192 427 532 193 427 minecraft:pearlescent_froglight
fill 532 192 429 532 193 429 minecraft:pearlescent_froglight
fill 532 192 439 532 193 439 minecraft:pearlescent_froglight
fill 532 192 441 532 193 441 minecraft:pearlescent_froglight
fill 532 192 456 533 209 456 minecraft:black_concrete
fill 533 192 426 533 192 427 minecraft:green_terracotta
setblock 533 192 429 minecraft:green_terracotta
setblock 533 192 439 minecraft:lime_terracotta
fill 533 192 441 533 192 442 minecraft:lime_terracotta
fill 535 192 455 537 200 455 minecraft:black_concrete
setblock 536 192 419 minecraft:light[level=12]
fill 536 192 425 540 192 425 minecraft:green_terracotta
fill 536 192 429 537 192 429 minecraft:green_terracotta
fill 536 192 439 537 192 439 minecraft:lime_terracotta
fill 536 192 443 540 192 443 minecraft:lime_terracotta
setblock 536 192 451 minecraft:light[level=12]
fill 539 192 429 543 192 429 minecraft:green_terracotta
fill 539 192 439 543 192 439 minecraft:lime_terracotta
fill 541 192 426 543 192 426 minecraft:green_terracotta
fill 541 192 442 543 192 442 minecraft:lime_terracotta
fill 541 192 456 541 211 456 minecraft:black_concrete
setblock 544 192 419 minecraft:light[level=12]
setblock 544 192 435 minecraft:light[level=12]
setblock 544 192 443 minecraft:light[level=12]
setblock 544 192 451 minecraft:light[level=12]
fill 544 192 457 549 211 457 minecraft:black_concrete
fill 550 192 456 551 205 456 minecraft:black_concrete
setblock 552 192 419 minecraft:light[level=12]
setblock 552 192 427 minecraft:light[level=12]
setblock 552 192 435 minecraft:light[level=12]
setblock 552 192 443 minecraft:light[level=12]
setblock 552 192 451 minecraft:light[level=12]
fill 553 192 455 555 198 455 minecraft:black_concrete
fill 555 192 445 555 193 445 minecraft:black_concrete
fill 555 192 452 555 197 452 minecraft:black_concrete
fill 556 192 427 556 195 433 minecraft:black_concrete
fill 557 192 456 557 198 456 minecraft:black_concrete
fill 518 193 456 518 199 456 minecraft:black_concrete
fill 519 193 437 519 197 437 minecraft:black_concrete
fill 519 193 447 519 193 451 minecraft:black_concrete
fill 520 193 433 520 197 433 minecraft:black_concrete
fill 528 193 417 528 215 417 minecraft:black_concrete
fill 529 193 457 530 214 457 minecraft:black_concrete
fill 531 193 418 531 212 418 minecraft:black_concrete
fill 531 193 456 531 211 456 minecraft:black_concrete
fill 533 193 455 534 202 455 minecraft:black_concrete
fill 535 193 427 541 193 428 minecraft:green_terracotta
fill 535 193 440 541 193 441 minecraft:lime_terracotta
fill 538 193 455 539 198 455 minecraft:black_concrete
fill 542 193 456 542 212 456 minecraft:black_concrete
fill 547 193 456 549 208 456 minecraft:black_concrete
fill 550 193 455 552 201 455 minecraft:black_concrete
fill 555 193 453 555 197 453 minecraft:black_concrete
fill 556 193 434 556 201 435 minecraft:black_concrete
fill 556 193 455 556 197 455 minecraft:black_concrete
fill 518 194 457 518 198 457 minecraft:black_concrete
fill 519 194 449 519 194 452 minecraft:black_concrete
fill 527 194 417 527 216 417 minecraft:black_concrete
fill 528 194 457 528 215 457 minecraft:black_concrete
fill 529 194 418 530 213 418 minecraft:black_concrete
fill 529 194 456 530 211 456 minecraft:black_concrete
fill 531 194 455 532 204 455 minecraft:black_concrete
fill 533 194 419 534 196 419 minecraft:black_concrete
fill 534 194 454 537 197 454 minecraft:black_concrete
fill 540 194 455 540 198 455 minecraft:black_concrete
fill 541 194 417 541 195 417 minecraft:black_concrete
fill 543 194 456 546 211 456 minecraft:black_concrete
fill 548 194 455 549 203 455 minecraft:black_concrete
fill 551 194 454 555 196 454 minecraft:black_concrete
fill 552 194 417 555 199 417 minecraft:black_concrete
setblock 554 194 450 minecraft:black_concrete
fill 555 194 431 555 197 431 minecraft:black_concrete
fill 556 194 436 556 199 438 minecraft:black_concrete
fill 557 194 425 558 195 426 minecraft:black_concrete
fill 558 194 424 558 196 424 minecraft:black_concrete
fill 519 195 424 519 195 434 minecraft:black_concrete
fill 520 195 427 520 195 430 minecraft:black_concrete
fill 526 195 417 526 217 417 minecraft:black_concrete
fill 526 195 457 527 216 457 minecraft:black_concrete
fill 528 195 418 528 214 418 minecraft:black_concrete
fill 528 195 456 528 213 456 minecraft:black_concrete
fill 530 195 455 530 207 455 minecraft:black_concrete
fill 532 195 419 532 199 419 minecraft:black_concrete
fill 532 195 454 533 199 454 minecraft:black_concrete
fill 541 195 455 541 197 455 minecraft:black_concrete
fill 546 195 455 547 202 455 minecraft:black_concrete
fill 549 195 454 550 199 454 minecraft:black_concrete
fill 550 195 417 551 212 417 minecraft:black_concrete
fill 555 195 430 555 196 430 minecraft:black_concrete
fill 555 195 432 555 198 434 minecraft:black_concrete
fill 556 195 417 556 196 417 minecraft:black_concrete
fill 556 195 439 556 197 439 minecraft:black_concrete
fill 518 196 417 518 198 417 minecraft:black_concrete
fill 518 196 420 518 196 442 minecraft:black_concrete
fill 518 196 445 518 196 453 minecraft:black_concrete
fill 519 196 425 519 196 434 minecraft:black_concrete
fill 520 196 428 520 196 430 minecraft:black_concrete
fill 524 196 417 525 218 417 minecraft:black_concrete
fill 525 196 457 525 230 457 minecraft:black_concrete
fill 527 196 456 527 213 456 minecraft:black_concrete
fill 529 196 455 529 209 455 minecraft:black_concrete
fill 531 196 419 531 200 419 minecraft:black_concrete
fill 531 196 454 531 199 454 minecraft:black_concrete
fill 533 196 418 537 197 418 minecraft:black_concrete
fill 542 196 455 542 197 455 minecraft:black_concrete
fill 544 196 455 545 198 455 minecraft:black_concrete
fill 548 196 454 548 198 454 minecraft:black_concrete
fill 549 196 417 549 213 417 minecraft:black_concrete
fill 555 196 435 555 198 435 minecraft:black_concrete
fill 555 196 448 556 196 448 minecraft:black_concrete
fill 556 196 428 556 196 433 minecraft:black_concrete
fill 556 196 445 556 196 447 minecraft:black_concrete
fill 556 196 449 556 197 449 minecraft:black_concrete
fill 557 196 426 558 196 426 minecraft:black_concrete
fill 558 196 425 558 197 425 minecraft:black_concrete
fill 518 197 421 518 197 440 minecraft:black_concrete
fill 518 197 449 518 197 453 minecraft:black_concrete
fill 519 197 426 519 197 434 minecraft:black_concrete
fill 520 197 429 520 197 430 minecraft:black_concrete
fill 520 197 449 520 210 449 minecraft:white_wool
fill 523 197 417 523 225 417 minecraft:black_concrete
fill 524 197 457 524 230 457 minecraft:black_concrete
fill 526 197 456 526 214 456 minecraft:black_concrete
fill 527 197 418 527 214 418 minecraft:black_concrete
fill 528 197 455 528 210 455 minecraft:black_concrete
fill 530 197 419 530 211 419 minecraft:black_concrete
fill 533 197 419 533 198 419 minecraft:black_concrete
setblock 543 197 455 minecraft:black_concrete
fill 548 197 417 548 213 417 minecraft:black_concrete
fill 551 197 454 554 197 454 minecraft:black_concrete
setblock 555 197 436 minecraft:black_concrete
fill 556 197 429 556 197 433 minecraft:black_concrete
setblock 556 197 448 minecraft:black_concrete
setblock 556 197 450 minecraft:black_concrete
fill 558 197 426 558 198 426 minecraft:black_concrete
fill 518 198 423 518 198 439 minecraft:black_concrete
fill 518 198 451 518 198 453 minecraft:black_concrete
fill 519 198 427 519 198 434 minecraft:black_concrete
fill 522 198 417 522 227 417 minecraft:black_concrete
fill 523 198 457 523 230 457 minecraft:black_concrete
fill 526 198 418 526 215 418 minecraft:black_concrete
fill 533 198 418 536 199 418 minecraft:black_concrete
fill 534 198 454 536 198 454 minecraft:black_concrete
fill 547 198 417 547 213 417 minecraft:black_concrete
fill 551 198 454 553 198 454 minecraft:black_concrete
fill 556 198 430 556 198 433 minecraft:black_concrete
fill 557 198 428 557 198 429 minecraft:black_concrete
fill 557 198 439 558 198 441 minecraft:black_concrete
fill 557 198 448 558 198 450 minecraft:black_concrete
fill 558 198 442 558 198 447 minecraft:black_concrete
fill 518 199 425 518 199 439 minecraft:black_concrete
fill 519 199 429 519 199 434 minecraft:black_concrete
fill 525 199 456 525 214 456 minecraft:black_concrete
fill 530 199 423 530 210 423 minecraft:white_wool
fill 532 199 417 539 199 417 minecraft:black_concrete
setblock 534 199 454 minecraft:black_concrete
setblock 538 199 455 minecraft:black_concrete
fill 545 199 455 545 200 455 minecraft:black_concrete
setblock 551 199 454 minecraft:black_concrete
fill 553 199 455 554 199 455 minecraft:black_concrete
fill 556 199 431 556 199 433 minecraft:black_concrete
setblock 557 199 429 minecraft:black_concrete
fill 557 199 439 558 199 440 minecraft:black_concrete
fill 557 199 453 558 199 454 minecraft:black_concrete
fill 558 199 441 558 199 442 minecraft:black_concrete
fill 558 199 449 558 199 452 minecraft:black_concrete
fill 518 200 427 518 200 438 minecraft:black_concrete
fill 519 200 431 519 200 434 minecraft:black_concrete
setblock 520 200 419 minecraft:light[level=12]
setblock 520 200 427 minecraft:light[level=12]
setblock 520 200 435 minecraft:light[level=12]
setblock 520 200 443 minecraft:light[level=12]
setblock 520 200 451 minecraft:light[level=12]
fill 521 200 417 521 229 417 minecraft:black_concrete
fill 525 200 418 525 216 418 minecraft:black_concrete
setblock 528 200 419 minecraft:light[level=12]
setblock 528 200 427 minecraft:light[level=12]
setblock 528 200 435 minecraft:light[level=12]
setblock 528 200 443 minecraft:light[level=12]
setblock 528 200 451 minecraft:light[level=12]
fill 529 200 419 529 212 419 minecraft:black_concrete
fill 532 200 417 538 202 417 minecraft:black_concrete
fill 533 200 418 535 200 418 minecraft:black_concrete
setblock 536 200 419 minecraft:light[level=12]
setblock 536 200 427 minecraft:light[level=12]
setblock 536 200 443 minecraft:light[level=12]
setblock 536 200 451 minecraft:light[level=12]
setblock 544 200 419 minecraft:light[level=12]
setblock 544 200 427 minecraft:light[level=12]
setblock 544 200 435 minecraft:light[level=12]
setblock 544 200 443 minecraft:light[level=12]
setblock 544 200 451 minecraft:light[level=12]
fill 546 200 417 546 214 417 minecraft:black_concrete
fill 552 200 417 554 201 417 minecraft:black_concrete
setblock 552 200 419 minecraft:light[level=12]
setblock 552 200 427 minecraft:light[level=12]
setblock 552 200 435 minecraft:light[level=12]
setblock 552 200 443 minecraft:light[level=12]
setblock 552 200 451 minecraft:light[level=12]
fill 552 200 456 555 200 456 minecraft:black_concrete
setblock 553 200 455 minecraft:black_concrete
fill 554 200 457 557 200 457 minecraft:black_concrete
fill 556 200 432 556 200 433 minecraft:black_concrete
fill 556 200 436 556 200 437 minecraft:black_concrete
fill 557 200 439 558 201 439 minecraft:black_concrete
fill 558 200 428 558 200 437 minecraft:black_concrete
fill 558 200 440 558 200 441 minecraft:black_concrete
fill 558 200 454 558 200 455 minecraft:black_concrete
fill 518 201 428 518 201 438 minecraft:black_concrete
fill 520 201 417 520 230 417 minecraft:black_concrete
fill 522 201 457 522 230 457 minecraft:black_concrete
fill 524 201 418 524 217 418 minecraft:black_concrete
fill 533 201 418 534 210 418 minecraft:black_concrete
setblock 535 201 455 minecraft:black_concrete
fill 552 201 456 554 201 456 minecraft:black_concrete
fill 554 201 457 556 201 457 minecraft:black_concrete
setblock 556 201 436 minecraft:black_concrete
fill 558 201 429 558 201 437 minecraft:black_concrete
fill 558 201 440 558 216 440 minecraft:black_concrete
fill 518 202 417 519 230 417 minecraft:black_concrete
fill 518 202 430 518 202 438 minecraft:black_concrete
fill 527 202 419 528 213 419 minecraft:black_concrete
fill 545 202 417 545 214 417 minecraft:black_concrete
setblock 550 202 455 minecraft:black_concrete
fill 552 202 417 553 211 417 minecraft:black_concrete
fill 552 202 456 553 202 456 minecraft:black_concrete
fill 554 202 457 555 202 457 minecraft:black_concrete
fill 557 202 433 558 202 433 minecraft:black_concrete
fill 558 202 430 558 202 432 minecraft:black_concrete
fill 558 202 434 558 214 437 minecraft:black_concrete
fill 558 202 439 558 215 439 minecraft:black_concrete
fill 518 203 418 518 230 418 minecraft:black_concrete
fill 518 203 432 518 203 437 minecraft:black_concrete
fill 523 203 418 523 217 418 minecraft:black_concrete
fill 524 203 456 524 215 456 minecraft:black_concrete
fill 526 203 419 526 214 419 minecraft:black_concrete
fill 532 203 417 537 212 417 minecraft:black_concrete
setblock 533 203 455 minecraft:black_concrete
fill 544 203 417 544 215 417 minecraft:black_concrete
fill 544 203 453 544 213 453 minecraft:black_concrete
setblock 547 203 455 minecraft:black_concrete
setblock 552 203 456 minecraft:black_concrete
fill 554 203 457 554 204 457 minecraft:black_concrete
fill 558 203 431 558 203 433 minecraft:black_concrete
fill 518 204 419 518 229 420 minecraft:black_concrete
fill 518 204 433 518 204 437 minecraft:black_concrete
fill 521 204 418 522 219 418 minecraft:black_concrete
fill 521 204 457 521 230 457 minecraft:black_concrete
fill 525 204 419 525 215 419 minecraft:black_concrete
fill 527 204 455 527 210 455 minecraft:black_concrete
fill 531 204 419 531 210 419 minecraft:black_concrete
setblock 537 204 456 minecraft:black_concrete
fill 538 204 417 538 213 417 minecraft:black_concrete
fill 542 204 417 543 215 417 minecraft:black_concrete
fill 548 204 451 548 227 451 minecraft:white_wool
fill 557 204 439 557 212 439 minecraft:black_concrete
fill 558 204 432 558 230 433 minecraft:black_concrete
fill 558 204 441 558 216 441 minecraft:black_concrete
fill 518 205 421 518 228 421 minecraft:black_concrete
fill 518 205 434 518 208 438 minecraft:black_concrete
fill 520 205 418 520 225 418 minecraft:black_concrete
fill 520 205 457 520 230 457 minecraft:black_concrete
fill 523 205 419 524 215 419 minecraft:black_concrete
fill 523 205 456 523 216 456 minecraft:black_concrete
fill 531 205 455 531 206 455 minecraft:black_concrete
fill 539 205 417 541 213 417 minecraft:black_concrete
fill 546 205 418 549 211 418 minecraft:black_concrete
fill 554 205 417 554 211 417 minecraft:black_concrete
fill 557 205 435 557 209 438 minecraft:black_concrete
fill 518 206 422 518 228 423 minecraft:black_concrete
fill 518 206 439 518 213 439 minecraft:black_concrete
fill 519 206 418 519 225 420 minecraft:black_concrete
fill 522 206 419 522 216 419 minecraft:black_concrete
fill 526 206 420 527 212 420 minecraft:black_concrete
fill 526 206 455 526 211 455 minecraft:black_concrete
fill 540 206 456 540 210 456 minecraft:black_concrete
fill 544 206 418 545 213 418 minecraft:black_concrete
fill 550 206 418 550 211 418 minecraft:black_concrete
fill 550 206 456 550 207 456 minecraft:black_concrete
fill 555 206 417 555 212 417 minecraft:black_concrete
fill 557 206 440 557 212 440 minecraft:black_concrete
fill 558 206 417 558 230 419 minecraft:black_concrete
fill 558 206 442 558 225 442 minecraft:black_concrete
fill 518 207 424 518 228 425 minecraft:black_concrete
fill 518 207 440 518 214 440 minecraft:black_concrete
fill 519 207 421 519 225 422 minecraft:black_concrete
fill 519 207 457 519 230 457 minecraft:black_concrete
fill 520 207 419 520 216 420 minecraft:black_concrete
fill 521 207 419 521 216 419 minecraft:black_concrete
fill 522 207 456 522 215 456 minecraft:black_concrete
fill 523 207 420 525 213 420 minecraft:black_concrete
fill 528 207 420 528 211 420 minecraft:black_concrete
fill 534 207 456 535 208 456 minecraft:black_concrete
fill 543 207 418 543 213 418 minecraft:black_concrete
fill 551 207 418 551 210 418 minecraft:black_concrete
fill 556 207 417 557 213 417 minecraft:black_concrete
fill 557 207 441 557 212 441 minecraft:black_concrete
fill 558 207 420 558 230 423 minecraft:black_concrete
fill 558 207 431 558 230 431 minecraft:black_concrete
fill 558 207 443 558 225 443 minecraft:black_concrete
fill 518 208 426 518 228 427 minecraft:black_concrete
fill 518 208 441 518 214 442 minecraft:black_concrete
fill 518 208 457 518 214 457 minecraft:black_concrete
fill 519 208 423 519 225 424 minecraft:black_concrete
fill 520 208 421 520 218 422 minecraft:black_concrete
setblock 520 208 427 minecraft:light[level=12]
setblock 520 208 435 minecraft:light[level=12]
setblock 520 208 443 minecraft:light[level=12]
setblock 520 208 451 minecraft:light[level=12]
fill 522 208 420 522 214 420 minecraft:black_concrete
fill 525 208 455 525 211 455 minecraft:black_concrete
setblock 528 208 427 minecraft:light[level=12]
setblock 528 208 435 minecraft:light[level=12]
setblock 528 208 443 minecraft:light[level=12]
setblock 528 208 451 minecraft:light[level=12]
fill 529 208 420 529 209 420 minecraft:black_concrete
setblock 536 208 419 minecraft:light[level=12]
setblock 536 208 427 minecraft:light[level=12]
setblock 536 208 443 minecraft:light[level=12]
setblock 536 208 451 minecraft:light[level=12]
fill 541 208 418 542 213 418 minecraft:black_concrete
setblock 544 208 419 minecraft:light[level=12]
setblock 544 208 427 minecraft:light[level=12]
setblock 544 208 435 minecraft:light[level=12]
setblock 544 208 443 minecraft:light[level=12]
setblock 544 208 451 minecraft:light[level=12]
fill 552 208 418 552 209 418 minecraft:black_concrete
setblock 552 208 419 minecraft:light[level=12]
setblock 552 208 427 minecraft:light[level=12]
setblock 552 208 435 minecraft:light[level=12]
setblock 552 208 443 minecraft:light[level=12]
setblock 552 208 451 minecraft:light[level=12]
fill 557 208 442 557 213 442 minecraft:black_concrete
fill 558 208 424 558 230 426 minecraft:black_concrete
fill 558 208 444 558 226 444 minecraft:black_concrete
fill 518 209 428 518 229 428 minecraft:black_concrete
fill 518 209 435 518 210 438 minecraft:black_concrete
fill 518 209 443 518 228 443 minecraft:black_concrete
fill 519 209 425 519 226 425 minecraft:black_concrete
fill 520 209 423 520 221 423 minecraft:black_concrete
fill 521 209 420 521 214 421 minecraft:black_concrete
fill 521 209 456 521 214 456 minecraft:black_concrete
setblock 534 209 456 minecraft:black_concrete
fill 540 209 418 540 212 418 minecraft:black_concrete
fill 544 209 419 548 210 419 minecraft:black_concrete
fill 547 209 456 548 209 456 minecraft:black_concrete
fill 557 209 419 557 214 422 minecraft:black_concrete
fill 558 209 427 558 230 430 minecraft:black_concrete
fill 558 209 445 558 226 445 minecraft:black_concrete
fill 518 210 429 518 229 429 minecraft:black_concrete
fill 518 210 444 518 228 444 minecraft:black_concrete
fill 519 210 426 519 226 426 minecraft:black_concrete
fill 520 210 424 520 222 424 minecraft:black_concrete
fill 521 210 422 521 215 422 minecraft:black_concrete
setblock 532 210 456 minecraft:black_concrete
setblock 547 210 456 minecraft:black_concrete
setblock 550 210 457 minecraft:black_concrete
fill 557 210 418 557 212 418 minecraft:black_concrete
fill 557 210 423 557 229 424 minecraft:black_concrete
fill 557 210 436 557 210 438 minecraft:black_concrete
fill 557 210 443 557 212 443 minecraft:black_concrete
fill 518 211 436 518 211 438 minecraft:black_concrete
fill 518 211 445 518 229 445 minecraft:black_concrete
fill 519 211 427 519 226 427 minecraft:black_concrete
fill 520 211 425 520 222 425 minecraft:black_concrete
fill 521 211 423 521 214 423 minecraft:black_concrete
fill 523 211 421 524 211 421 minecraft:black_concrete
fill 543 211 453 543 213 453 minecraft:black_concrete
fill 544 211 419 546 211 419 minecraft:black_concrete
fill 544 211 452 544 213 452 minecraft:black_concrete
fill 544 211 454 544 213 454 minecraft:black_concrete
fill 545 211 453 545 213 453 minecraft:black_concrete
fill 557 211 425 557 229 426 minecraft:black_concrete
fill 557 211 437 557 211 438 minecraft:black_concrete
fill 558 211 446 558 227 446 minecraft:black_concrete
fill 517 212 416 517 213 420 minecraft:black_concrete
setblock 517 212 421 minecraft:deepslate_tiles
fill 517 212 422 517 212 430 minecraft:black_concrete
fill 517 212 432 517 215 432 minecraft:black_concrete
setblock 517 212 433 minecraft:deepslate_tiles
fill 517 212 443 517 213 443 minecraft:deepslate_tiles
fill 517 212 444 517 212 448 minecraft:black_concrete
fill 517 212 449 517 212 450 minecraft:deepslate_tiles
fill 517 212 451 517 215 453 minecraft:black_concrete
fill 518 212 430 518 230 430 minecraft:black_concrete
setblock 518 212 438 minecraft:black_concrete
fill 518 212 446 518 229 446 minecraft:black_concrete
fill 519 212 442 519 212 443 minecraft:black_concrete
fill 520 212 426 520 223 426 minecraft:black_concrete
fill 521 212 424 521 213 424 minecraft:black_concrete
fill 521 212 458 523 213 458 minecraft:black_concrete
setblock 524 212 458 minecraft:deepslate_tiles
fill 525 212 458 526 212 458 minecraft:black_concrete
setblock 527 212 416 minecraft:deepslate_tiles
setblock 529 212 456 minecraft:black_concrete
setblock 532 212 416 minecraft:deepslate_tiles
fill 533 212 416 533 215 416 minecraft:black_concrete
setblock 534 212 416 minecraft:deepslate_tiles
fill 535 212 416 539 212 416 minecraft:black_concrete
fill 542 212 416 543 212 416 minecraft:deepslate_tiles
fill 543 212 456 544 212 456 minecraft:black_concrete
fill 544 212 416 544 215 416 minecraft:black_concrete
fill 544 212 457 548 212 457 minecraft:black_concrete
fill 546 212 418 548 212 418 minecraft:black_concrete
setblock 554 212 416 minecraft:deepslate_tiles
fill 555 212 416 555 215 416 minecraft:black_concrete
fill 557 212 427 557 229 427 minecraft:black_concrete
setblock 559 212 419 minecraft:deepslate_tiles
fill 559 212 422 559 213 422 minecraft:deepslate_tiles
fill 559 212 426 559 215 426 minecraft:black_concrete
setblock 559 212 427 minecraft:deepslate_tiles
fill 559 212 428 559 212 429 minecraft:black_concrete
setblock 559 212 430 minecraft:deepslate_tiles
fill 559 212 449 559 213 449 minecraft:deepslate_tiles
setblock 559 212 451 minecraft:deepslate_tiles
fill 517 213 421 517 213 425 minecraft:black_concrete
setblock 517 213 426 minecraft:deepslate_tiles
fill 517 213 427 517 215 430 minecraft:black_concrete
fill 517 213 431 517 214 431 minecraft:deepslate_tiles
fill 517 213 433 517 213 437 minecraft:black_concrete
setblock 517 213 438 minecraft:deepslate_tiles
fill 517 213 444 517 213 445 minecraft:black_concrete
setblock 517 213 446 minecraft:deepslate_tiles
fill 517 213 447 517 215 449 minecraft:black_concrete
setblock 517 213 450 minecraft:deepslate_tiles
fill 518 213 447 518 230 447 minecraft:black_concrete
setblock 518 213 458 minecraft:deepslate_tiles
fill 519 213 428 519 227 428 minecraft:black_concrete
setblock 519 213 444 minecraft:black_concrete
fill 519 213 458 519 216 458 minecraft:black_concrete
fill 524 213 458 525 215 458 minecraft:black_concrete
fill 526 213 458 526 214 458 minecraft:deepslate_tiles
fill 527 213 416 527 215 416 minecraft:black_concrete
setblock 528 213 416 minecraft:deepslate_tiles
fill 528 213 458 528 214 458 minecraft:deepslate_tiles
fill 529 213 416 532 213 416 minecraft:black_concrete
fill 529 213 458 530 213 458 minecraft:black_concrete
setblock 531 213 458 minecraft:deepslate_tiles
setblock 532 213 417 minecraft:black_concrete
fill 532 213 458 532 215 458 minecraft:black_concrete
setblock 533 213 458 minecraft:deepslate_tiles
fill 534 213 416 536 213 416 minecraft:black_concrete
fill 537 213 416 538 213 416 minecraft:deepslate_tiles
fill 537 213 457 541 213 457 minecraft:black_concrete
fill 539 213 416 539 215 416 minecraft:black_concrete
setblock 540 213 458 minecraft:deepslate_tiles
fill 542 213 416 543 215 416 minecraft:black_concrete
fill 544 213 457 546 213 457 minecraft:black_concrete
setblock 544 213 458 minecraft:deepslate_tiles
fill 545 213 416 545 214 416 minecraft:deepslate_tiles
schedule function dropper:buildpart/107_2 1t
