setblock 370 219 571 minecraft:oak_log
fill 370 219 572 370 220 572 minecraft:green_terracotta
setblock 370 219 576 minecraft:oak_log
fill 370 219 577 370 222 577 minecraft:green_terracotta
setblock 370 219 581 minecraft:oak_log
fill 370 219 582 370 222 582 minecraft:green_terracotta
setblock 370 219 586 minecraft:oak_log
setblock 370 219 587 minecraft:green_terracotta
setblock 370 219 591 minecraft:oak_log
fill 370 219 592 370 221 592 minecraft:green_terracotta
setblock 370 219 596 minecraft:oak_log
fill 370 219 597 370 222 597 minecraft:green_terracotta
setblock 330 220 559 minecraft:oak_leaves[persistent=true]
setblock 330 220 570 minecraft:oak_log
fill 330 220 571 330 221 571 minecraft:green_terracotta
setblock 330 220 575 minecraft:oak_log
fill 330 220 576 330 223 576 minecraft:green_terracotta
setblock 330 220 580 minecraft:oak_log
fill 330 220 581 330 223 581 minecraft:green_terracotta
setblock 330 220 584 minecraft:oak_leaves[persistent=true]
setblock 330 220 595 minecraft:oak_log
setblock 330 220 596 minecraft:green_terracotta
setblock 331 220 574 minecraft:oak_log
fill 331 220 575 331 222 575 minecraft:green_terracotta
setblock 331 220 579 minecraft:oak_log
setblock 335 220 598 minecraft:oak_leaves[persistent=true]
setblock 336 220 558 minecraft:green_terracotta
fill 336 220 596 336 231 596 minecraft:oak_leaves[persistent=true]
setblock 336 220 598 minecraft:green_terracotta
setblock 337 220 558 minecraft:oak_log
setblock 337 220 598 minecraft:oak_log
fill 338 220 558 338 223 558 minecraft:green_terracotta
fill 338 220 598 338 223 598 minecraft:green_terracotta
fill 339 220 597 339 223 597 minecraft:green_terracotta
setblock 341 220 558 minecraft:green_terracotta
setblock 341 220 559 minecraft:oak_log
setblock 342 220 558 minecraft:oak_log
fill 342 220 559 342 223 559 minecraft:green_terracotta
setblock 342 220 598 minecraft:oak_log
fill 343 220 558 343 223 558 minecraft:green_terracotta
setblock 343 220 597 minecraft:oak_log
fill 343 220 598 343 223 598 minecraft:green_terracotta
setblock 344 220 596 minecraft:oak_log
fill 344 220 597 344 223 597 minecraft:green_terracotta
setblock 345 220 560 minecraft:oak_log
setblock 345 220 596 minecraft:green_terracotta
setblock 346 220 559 minecraft:oak_log
setblock 347 220 558 minecraft:oak_log
fill 347 220 559 347 223 559 minecraft:green_terracotta
setblock 347 220 598 minecraft:oak_log
fill 348 220 558 348 223 558 minecraft:green_terracotta
setblock 348 220 597 minecraft:oak_log
fill 348 220 598 351 220 598 minecraft:green_terracotta
fill 349 220 559 349 221 559 minecraft:green_terracotta
fill 349 220 597 352 220 597 minecraft:green_terracotta
setblock 352 220 558 minecraft:oak_log
setblock 352 220 598 minecraft:oak_log
fill 353 220 558 353 223 558 minecraft:green_terracotta
setblock 353 220 597 minecraft:oak_log
fill 353 220 598 353 223 598 minecraft:green_terracotta
fill 354 220 597 354 223 597 minecraft:green_terracotta
fill 356 220 596 358 220 596 minecraft:green_terracotta
setblock 357 220 558 minecraft:oak_log
setblock 357 220 598 minecraft:oak_log
fill 358 220 558 358 223 558 minecraft:green_terracotta
setblock 358 220 597 minecraft:oak_log
fill 358 220 598 358 223 598 minecraft:green_terracotta
setblock 359 220 595 minecraft:green_terracotta
setblock 359 220 596 minecraft:oak_log
fill 359 220 597 359 223 597 minecraft:green_terracotta
setblock 360 220 595 minecraft:oak_log
fill 360 220 596 360 223 596 minecraft:green_terracotta
setblock 361 220 559 minecraft:oak_log
fill 361 220 595 361 222 595 minecraft:green_terracotta
setblock 362 220 558 minecraft:oak_log
fill 362 220 559 362 223 559 minecraft:green_terracotta
setblock 362 220 598 minecraft:oak_log
fill 363 220 558 363 223 558 minecraft:green_terracotta
setblock 363 220 597 minecraft:oak_log
fill 363 220 598 363 223 598 minecraft:green_terracotta
setblock 364 220 596 minecraft:oak_log
fill 364 220 597 364 223 597 minecraft:green_terracotta
setblock 365 220 595 minecraft:oak_log
fill 365 220 596 365 222 596 minecraft:green_terracotta
setblock 366 220 595 minecraft:green_terracotta
setblock 367 220 558 minecraft:oak_log
setblock 367 220 598 minecraft:oak_log
setblock 368 220 558 minecraft:green_terracotta
setblock 368 220 597 minecraft:oak_log
fill 368 220 598 368 223 598 minecraft:green_terracotta
setblock 369 220 576 minecraft:oak_log
fill 369 220 577 369 221 577 minecraft:green_terracotta
setblock 369 220 591 minecraft:oak_log
setblock 369 220 592 minecraft:green_terracotta
setblock 369 220 596 minecraft:oak_log
fill 369 220 597 369 221 597 minecraft:green_terracotta
setblock 370 220 575 minecraft:oak_log
fill 370 220 576 370 223 576 minecraft:green_terracotta
setblock 370 220 580 minecraft:oak_log
fill 370 220 581 370 223 581 minecraft:green_terracotta
setblock 370 220 590 minecraft:oak_log
fill 370 220 591 370 221 591 minecraft:green_terracotta
setblock 370 220 595 minecraft:oak_log
fill 370 220 596 370 222 596 minecraft:green_terracotta
setblock 330 221 565 minecraft:oak_leaves[persistent=true]
setblock 330 221 574 minecraft:oak_log
fill 330 221 575 330 224 575 minecraft:green_terracotta
setblock 330 221 579 minecraft:oak_log
fill 330 221 580 330 224 580 minecraft:green_terracotta
setblock 330 221 590 minecraft:oak_leaves[persistent=true]
setblock 331 221 573 minecraft:oak_log
setblock 331 221 574 minecraft:green_terracotta
setblock 331 221 578 minecraft:oak_log
setblock 331 221 579 minecraft:green_terracotta
setblock 334 221 558 minecraft:oak_leaves[persistent=true]
setblock 336 221 558 minecraft:oak_log
setblock 336 221 598 minecraft:oak_log
fill 337 221 558 337 224 558 minecraft:green_terracotta
fill 337 221 598 337 224 598 minecraft:green_terracotta
fill 338 221 559 338 222 559 minecraft:green_terracotta
setblock 340 221 558 minecraft:green_terracotta
setblock 340 221 559 minecraft:oak_log
setblock 341 221 558 minecraft:oak_log
fill 341 221 559 341 223 560 minecraft:green_terracotta
setblock 341 221 598 minecraft:oak_log
fill 342 221 558 342 224 558 minecraft:green_terracotta
setblock 342 221 597 minecraft:oak_log
fill 342 221 598 342 224 598 minecraft:green_terracotta
fill 343 221 597 343 224 597 minecraft:green_terracotta
setblock 344 221 560 minecraft:oak_log
setblock 345 221 559 minecraft:oak_log
setblock 346 221 558 minecraft:oak_log
fill 346 221 559 346 224 559 minecraft:green_terracotta
setblock 346 221 598 minecraft:oak_log
fill 347 221 558 347 224 558 minecraft:green_terracotta
setblock 347 221 597 minecraft:oak_log
fill 347 221 598 350 221 598 minecraft:green_terracotta
fill 348 221 597 351 221 597 minecraft:green_terracotta
setblock 351 221 558 minecraft:oak_log
setblock 351 221 598 minecraft:oak_log
fill 352 221 558 352 224 558 minecraft:green_terracotta
setblock 352 221 597 minecraft:oak_log
fill 352 221 598 352 224 598 minecraft:green_terracotta
fill 353 221 597 353 224 597 minecraft:green_terracotta
setblock 356 221 558 minecraft:oak_log
setblock 356 221 598 minecraft:oak_log
fill 357 221 558 357 223 559 minecraft:green_terracotta
setblock 357 221 596 minecraft:green_terracotta
setblock 357 221 597 minecraft:oak_log
fill 357 221 598 357 224 598 minecraft:green_terracotta
setblock 358 221 596 minecraft:oak_log
fill 358 221 597 358 224 597 minecraft:green_terracotta
fill 359 221 596 359 224 596 minecraft:green_terracotta
setblock 360 221 559 minecraft:oak_log
setblock 360 221 595 minecraft:green_terracotta
setblock 361 221 558 minecraft:oak_log
fill 361 221 559 361 224 559 minecraft:green_terracotta
setblock 361 221 598 minecraft:oak_log
fill 362 221 558 362 224 558 minecraft:green_terracotta
setblock 362 221 597 minecraft:oak_log
fill 362 221 598 362 224 598 minecraft:green_terracotta
setblock 363 221 596 minecraft:oak_log
fill 363 221 597 363 224 597 minecraft:green_terracotta
setblock 364 221 595 minecraft:oak_log
fill 364 221 596 364 223 596 minecraft:green_terracotta
setblock 366 221 558 minecraft:oak_log
setblock 366 221 598 minecraft:oak_log
fill 367 221 558 367 222 558 minecraft:green_terracotta
setblock 367 221 597 minecraft:oak_log
fill 367 221 598 367 224 598 minecraft:green_terracotta
fill 368 221 597 368 222 597 minecraft:green_terracotta
setblock 369 221 576 minecraft:green_terracotta
setblock 369 221 595 minecraft:oak_log
setblock 369 221 596 minecraft:green_terracotta
setblock 370 221 566 minecraft:oak_leaves[persistent=true]
setblock 370 221 574 minecraft:oak_log
fill 370 221 575 370 224 575 minecraft:green_terracotta
setblock 370 221 579 minecraft:oak_log
fill 370 221 580 370 224 580 minecraft:green_terracotta
setblock 370 221 594 minecraft:oak_log
fill 370 221 595 370 222 595 minecraft:green_terracotta
setblock 330 222 571 minecraft:oak_leaves[persistent=true]
setblock 330 222 573 minecraft:oak_log
fill 330 222 574 330 225 574 minecraft:green_terracotta
setblock 330 222 578 minecraft:oak_log
fill 330 222 579 330 225 579 minecraft:green_terracotta
setblock 330 222 596 minecraft:oak_leaves[persistent=true]
setblock 331 222 577 minecraft:oak_log
fill 331 222 578 331 225 578 minecraft:green_terracotta
setblock 335 222 558 minecraft:oak_log
fill 336 222 558 336 225 558 minecraft:green_terracotta
fill 336 222 598 336 225 598 minecraft:green_terracotta
fill 337 222 559 337 223 559 minecraft:green_terracotta
setblock 339 222 558 minecraft:green_terracotta
setblock 339 222 559 minecraft:oak_log
setblock 340 222 558 minecraft:oak_log
fill 340 222 559 340 224 560 minecraft:green_terracotta
setblock 340 222 598 minecraft:oak_log
fill 341 222 558 341 225 558 minecraft:green_terracotta
setblock 341 222 597 minecraft:oak_log
fill 341 222 598 341 225 598 minecraft:green_terracotta
fill 342 222 597 342 225 597 minecraft:green_terracotta
setblock 343 222 560 minecraft:oak_log
setblock 344 222 559 minecraft:oak_log
fill 344 222 560 344 225 560 minecraft:green_terracotta
setblock 345 222 558 minecraft:oak_log
fill 345 222 559 345 225 559 minecraft:green_terracotta
setblock 345 222 598 minecraft:oak_log
fill 346 222 558 346 225 558 minecraft:green_terracotta
setblock 346 222 597 minecraft:oak_log
fill 346 222 598 349 222 598 minecraft:green_terracotta
setblock 347 222 597 minecraft:green_terracotta
setblock 350 222 558 minecraft:oak_log
setblock 350 222 598 minecraft:oak_log
fill 351 222 558 351 225 558 minecraft:green_terracotta
fill 351 222 598 351 225 598 minecraft:green_terracotta
setblock 355 222 558 minecraft:oak_log
setblock 355 222 598 minecraft:oak_log
fill 356 222 558 356 225 558 minecraft:green_terracotta
setblock 356 222 597 minecraft:oak_log
fill 356 222 598 356 225 598 minecraft:green_terracotta
setblock 357 222 596 minecraft:oak_log
fill 357 222 597 357 225 597 minecraft:green_terracotta
fill 358 222 596 358 225 596 minecraft:green_terracotta
setblock 359 222 559 minecraft:oak_log
setblock 360 222 558 minecraft:oak_log
fill 360 222 559 360 225 559 minecraft:green_terracotta
setblock 360 222 598 minecraft:oak_log
fill 361 222 558 361 225 558 minecraft:green_terracotta
setblock 361 222 597 minecraft:oak_log
fill 361 222 598 361 225 598 minecraft:green_terracotta
setblock 362 222 596 minecraft:oak_log
fill 362 222 597 362 225 597 minecraft:green_terracotta
fill 363 222 596 363 224 596 minecraft:green_terracotta
setblock 365 222 558 minecraft:oak_log
setblock 365 222 598 minecraft:oak_log
fill 366 222 558 366 225 558 minecraft:green_terracotta
setblock 366 222 597 minecraft:oak_log
fill 366 222 598 366 225 598 minecraft:green_terracotta
fill 367 222 597 367 223 597 minecraft:green_terracotta
setblock 369 222 579 minecraft:oak_log
setblock 370 222 560 minecraft:oak_leaves[persistent=true]
setblock 370 222 574 minecraft:green_terracotta
setblock 370 222 578 minecraft:oak_log
fill 370 222 579 370 225 579 minecraft:green_terracotta
setblock 370 222 583 minecraft:oak_log
setblock 370 222 585 minecraft:oak_leaves[persistent=true]
setblock 370 222 594 minecraft:green_terracotta
setblock 370 222 598 minecraft:oak_log
setblock 330 223 558 minecraft:oak_leaves[persistent=true]
fill 330 223 573 330 224 573 minecraft:green_terracotta
setblock 330 223 577 minecraft:oak_log
fill 330 223 578 330 226 578 minecraft:green_terracotta
setblock 330 223 582 minecraft:oak_log
setblock 331 223 576 minecraft:oak_log
fill 331 223 577 331 226 577 minecraft:green_terracotta
setblock 334 223 558 minecraft:oak_log
setblock 334 223 598 minecraft:oak_leaves[persistent=true]
fill 335 223 558 335 226 558 minecraft:green_terracotta
fill 336 223 560 338 223 563 minecraft:oak_log
setblock 338 223 559 minecraft:oak_log
setblock 339 223 558 minecraft:oak_log
fill 339 223 559 339 225 560 minecraft:green_terracotta
fill 339 223 561 339 225 563 minecraft:oak_log
setblock 339 223 598 minecraft:oak_log
fill 340 223 558 340 226 558 minecraft:green_terracotta
setblock 340 223 597 minecraft:oak_log
fill 340 223 598 340 226 598 minecraft:green_terracotta
fill 341 223 597 341 226 597 minecraft:green_terracotta
setblock 342 223 560 minecraft:oak_log
setblock 343 223 559 minecraft:oak_log
fill 343 223 560 343 226 560 minecraft:green_terracotta
setblock 344 223 558 minecraft:oak_log
fill 344 223 559 344 226 559 minecraft:green_terracotta
setblock 344 223 598 minecraft:oak_log
fill 345 223 558 345 226 558 minecraft:green_terracotta
setblock 345 223 597 minecraft:oak_log
fill 345 223 598 348 223 598 minecraft:green_terracotta
setblock 346 223 597 minecraft:green_terracotta
setblock 348 223 559 minecraft:oak_log
setblock 349 223 558 minecraft:oak_log
setblock 349 223 598 minecraft:oak_log
fill 350 223 558 350 226 558 minecraft:green_terracotta
fill 350 223 598 350 226 598 minecraft:green_terracotta
setblock 354 223 558 minecraft:oak_log
setblock 354 223 598 minecraft:oak_log
fill 355 223 558 355 226 558 minecraft:green_terracotta
setblock 355 223 597 minecraft:oak_log
fill 355 223 598 355 226 598 minecraft:green_terracotta
fill 356 223 559 356 224 559 minecraft:green_terracotta
fill 356 223 597 356 226 597 minecraft:green_terracotta
fill 357 223 596 357 226 596 minecraft:green_terracotta
setblock 358 223 559 minecraft:oak_log
setblock 359 223 558 minecraft:oak_log
fill 359 223 559 359 226 559 minecraft:green_terracotta
setblock 359 223 598 minecraft:oak_log
fill 360 223 558 360 226 558 minecraft:green_terracotta
setblock 360 223 597 minecraft:oak_log
fill 360 223 598 360 226 598 minecraft:green_terracotta
setblock 361 223 596 minecraft:oak_log
fill 361 223 597 361 226 597 minecraft:green_terracotta
fill 362 223 596 362 225 596 minecraft:green_terracotta
setblock 363 223 559 minecraft:oak_log
setblock 364 223 558 minecraft:oak_log
setblock 364 223 598 minecraft:oak_log
fill 365 223 558 365 226 558 minecraft:green_terracotta
setblock 365 223 597 minecraft:oak_log
fill 365 223 598 365 226 598 minecraft:green_terracotta
fill 366 223 597 366 224 597 minecraft:green_terracotta
setblock 369 223 598 minecraft:oak_log
setblock 370 223 577 minecraft:oak_log
fill 370 223 578 370 226 578 minecraft:green_terracotta
setblock 370 223 582 minecraft:oak_log
fill 370 223 583 370 226 583 minecraft:green_terracotta
setblock 330 224 564 minecraft:oak_leaves[persistent=true]
setblock 330 224 576 minecraft:oak_log
fill 330 224 577 330 227 577 minecraft:green_terracotta
setblock 330 224 581 minecraft:oak_log
fill 330 224 582 330 227 582 minecraft:green_terracotta
setblock 330 224 583 minecraft:oak_leaves[persistent=true]
fill 334 224 558 334 227 558 minecraft:green_terracotta
setblock 336 224 559 minecraft:green_terracotta
fill 336 224 560 337 224 563 minecraft:oak_log
setblock 337 224 559 minecraft:oak_log
setblock 338 224 558 minecraft:oak_log
fill 338 224 559 338 226 560 minecraft:green_terracotta
fill 338 224 561 338 226 563 minecraft:oak_log
setblock 338 224 598 minecraft:oak_log
fill 339 224 558 339 227 558 minecraft:green_terracotta
setblock 339 224 597 minecraft:oak_log
fill 339 224 598 339 227 598 minecraft:green_terracotta
fill 340 224 597 340 227 597 minecraft:green_terracotta
setblock 341 224 559 minecraft:green_terracotta
setblock 341 224 560 minecraft:oak_log
setblock 342 224 559 minecraft:oak_log
fill 342 224 560 342 227 560 minecraft:green_terracotta
setblock 343 224 558 minecraft:oak_log
fill 343 224 559 343 227 559 minecraft:green_terracotta
setblock 343 224 598 minecraft:oak_log
fill 344 224 558 344 227 558 minecraft:green_terracotta
setblock 344 224 597 minecraft:oak_log
fill 344 224 598 347 224 598 minecraft:green_terracotta
setblock 347 224 559 minecraft:oak_log
setblock 348 224 558 minecraft:oak_log
fill 348 224 559 348 227 559 minecraft:green_terracotta
setblock 348 224 598 minecraft:oak_log
fill 349 224 558 349 227 558 minecraft:green_terracotta
fill 349 224 598 349 227 598 minecraft:green_terracotta
setblock 353 224 558 minecraft:oak_log
setblock 353 224 598 minecraft:oak_log
fill 354 224 558 354 227 558 minecraft:green_terracotta
setblock 354 224 597 minecraft:oak_log
fill 354 224 598 354 227 598 minecraft:green_terracotta
fill 355 224 559 355 225 559 minecraft:green_terracotta
fill 355 224 597 355 227 597 minecraft:green_terracotta
setblock 357 224 558 minecraft:green_terracotta
setblock 357 224 559 minecraft:oak_log
setblock 358 224 558 minecraft:oak_log
fill 358 224 559 358 227 559 minecraft:green_terracotta
setblock 358 224 598 minecraft:oak_log
fill 359 224 558 359 227 558 minecraft:green_terracotta
setblock 359 224 597 minecraft:oak_log
fill 359 224 598 359 227 598 minecraft:green_terracotta
setblock 360 224 596 minecraft:oak_log
fill 360 224 597 360 227 597 minecraft:green_terracotta
fill 361 224 596 361 227 596 minecraft:green_terracotta
setblock 362 224 559 minecraft:oak_log
setblock 363 224 558 minecraft:oak_log
fill 363 224 559 363 227 559 minecraft:green_terracotta
setblock 363 224 598 minecraft:oak_log
fill 364 224 558 364 227 558 minecraft:green_terracotta
setblock 364 224 597 minecraft:oak_log
fill 364 224 598 364 227 598 minecraft:green_terracotta
fill 365 224 597 365 225 597 minecraft:green_terracotta
setblock 368 224 598 minecraft:oak_log
fill 370 224 567 370 225 567 minecraft:oak_leaves[persistent=true]
setblock 370 224 573 minecraft:oak_leaves[persistent=true]
setblock 370 224 576 minecraft:oak_log
fill 370 224 577 370 227 577 minecraft:green_terracotta
setblock 370 224 581 minecraft:oak_log
fill 370 224 582 370 227 582 minecraft:green_terracotta
setblock 370 224 592 minecraft:oak_leaves[persistent=true]
setblock 330 225 570 minecraft:oak_leaves[persistent=true]
setblock 330 225 575 minecraft:oak_log
fill 330 225 576 330 228 576 minecraft:green_terracotta
setblock 330 225 580 minecraft:oak_log
fill 330 225 581 330 228 581 minecraft:green_terracotta
setblock 330 225 589 minecraft:oak_leaves[persistent=true]
setblock 331 225 579 minecraft:oak_log
setblock 332 225 560 minecraft:light[level=14]
setblock 332 225 568 minecraft:light[level=14]
setblock 332 225 576 minecraft:light[level=14]
setblock 332 225 584 minecraft:light[level=14]
setblock 332 225 592 minecraft:light[level=14]
fill 333 225 558 333 228 558 minecraft:green_terracotta
setblock 335 225 559 minecraft:green_terracotta
fill 335 225 598 335 226 598 minecraft:green_terracotta
fill 336 225 559 336 225 563 minecraft:oak_log
setblock 337 225 558 minecraft:oak_log
fill 337 225 559 337 227 560 minecraft:green_terracotta
fill 337 225 561 337 227 563 minecraft:oak_log
setblock 337 225 598 minecraft:oak_log
fill 338 225 558 338 228 558 minecraft:green_terracotta
fill 338 225 598 338 228 598 minecraft:green_terracotta
fill 339 225 597 339 228 597 minecraft:green_terracotta
setblock 340 225 559 minecraft:green_terracotta
setblock 340 225 560 minecraft:oak_log
setblock 340 225 568 minecraft:light[level=14]
setblock 340 225 576 minecraft:light[level=14]
setblock 340 225 584 minecraft:light[level=14]
setblock 340 225 592 minecraft:light[level=14]
setblock 341 225 559 minecraft:oak_log
fill 341 225 560 341 228 560 minecraft:green_terracotta
setblock 342 225 558 minecraft:oak_log
fill 342 225 559 342 228 559 minecraft:green_terracotta
setblock 342 225 598 minecraft:oak_log
fill 343 225 558 343 228 558 minecraft:green_terracotta
setblock 343 225 597 minecraft:oak_log
fill 343 225 598 346 225 598 minecraft:green_terracotta
setblock 346 225 559 minecraft:oak_log
setblock 347 225 558 minecraft:oak_log
fill 347 225 559 347 228 559 minecraft:green_terracotta
setblock 347 225 598 minecraft:oak_log
fill 348 225 558 348 228 558 minecraft:green_terracotta
setblock 348 225 560 minecraft:light[level=14]
setblock 348 225 568 minecraft:light[level=14]
setblock 348 225 576 minecraft:light[level=14]
setblock 348 225 584 minecraft:light[level=14]
setblock 348 225 592 minecraft:light[level=14]
fill 348 225 598 348 228 598 minecraft:green_terracotta
fill 349 225 559 349 226 559 minecraft:green_terracotta
setblock 352 225 558 minecraft:oak_log
setblock 352 225 598 minecraft:oak_log
fill 353 225 558 353 227 559 minecraft:green_terracotta
setblock 353 225 597 minecraft:oak_log
fill 353 225 598 353 228 598 minecraft:green_terracotta
fill 354 225 559 354 226 559 minecraft:green_terracotta
fill 354 225 597 354 228 597 minecraft:green_terracotta
setblock 356 225 559 minecraft:oak_log
setblock 356 225 560 minecraft:light[level=14]
setblock 356 225 568 minecraft:light[level=14]
setblock 356 225 576 minecraft:light[level=14]
setblock 356 225 584 minecraft:light[level=14]
setblock 356 225 592 minecraft:light[level=14]
setblock 357 225 558 minecraft:oak_log
fill 357 225 559 357 228 559 minecraft:green_terracotta
setblock 357 225 598 minecraft:oak_log
fill 358 225 558 358 228 558 minecraft:green_terracotta
setblock 358 225 597 minecraft:oak_log
fill 358 225 598 358 228 598 minecraft:green_terracotta
setblock 359 225 596 minecraft:oak_log
fill 359 225 597 359 228 597 minecraft:green_terracotta
fill 360 225 596 360 228 596 minecraft:green_terracotta
setblock 361 225 559 minecraft:oak_log
setblock 362 225 558 minecraft:oak_log
fill 362 225 559 362 228 559 minecraft:green_terracotta
setblock 362 225 598 minecraft:oak_log
fill 363 225 558 363 228 558 minecraft:green_terracotta
setblock 363 225 597 minecraft:oak_log
fill 363 225 598 363 228 598 minecraft:green_terracotta
setblock 364 225 560 minecraft:light[level=14]
setblock 364 225 568 minecraft:light[level=14]
setblock 364 225 576 minecraft:light[level=14]
setblock 364 225 584 minecraft:light[level=14]
setblock 364 225 592 minecraft:light[level=14]
fill 364 225 597 364 227 597 minecraft:green_terracotta
setblock 367 225 598 minecraft:oak_log
fill 369 225 579 369 225 580 minecraft:green_terracotta
setblock 370 225 561 minecraft:oak_leaves[persistent=true]
setblock 370 225 575 minecraft:oak_log
fill 370 225 576 370 228 576 minecraft:green_terracotta
setblock 370 225 580 minecraft:oak_log
fill 370 225 581 370 228 581 minecraft:green_terracotta
setblock 370 225 584 minecraft:green_terracotta
setblock 370 225 586 minecraft:oak_leaves[persistent=true]
setblock 330 226 574 minecraft:oak_log
fill 330 226 575 330 229 575 minecraft:green_terracotta
setblock 330 226 579 minecraft:oak_log
fill 330 226 580 331 228 580 minecraft:green_terracotta
setblock 330 226 583 minecraft:green_terracotta
setblock 330 226 595 minecraft:oak_leaves[persistent=true]
setblock 331 226 558 minecraft:oak_log
setblock 331 226 578 minecraft:oak_log
fill 331 226 579 331 229 579 minecraft:green_terracotta
fill 332 226 558 332 229 558 minecraft:green_terracotta
fill 333 226 598 333 227 598 minecraft:oak_leaves[persistent=true]
setblock 334 226 559 minecraft:green_terracotta
setblock 335 226 559 minecraft:oak_log
setblock 336 226 558 minecraft:oak_log
fill 336 226 559 336 228 560 minecraft:green_terracotta
fill 336 226 561 336 228 563 minecraft:oak_log
setblock 336 226 598 minecraft:oak_log
fill 337 226 558 337 229 558 minecraft:green_terracotta
fill 337 226 598 337 229 598 minecraft:green_terracotta
setblock 339 226 559 minecraft:green_terracotta
setblock 339 226 560 minecraft:oak_log
fill 339 226 561 340 228 561 minecraft:green_terracotta
fill 339 226 562 339 229 563 minecraft:oak_log
setblock 340 226 559 minecraft:oak_log
fill 340 226 560 340 229 560 minecraft:green_terracotta
fill 340 226 562 340 233 562 minecraft:oak_log
setblock 341 226 558 minecraft:oak_log
fill 341 226 559 341 229 559 minecraft:green_terracotta
setblock 341 226 598 minecraft:oak_log
fill 342 226 558 342 229 558 minecraft:green_terracotta
setblock 342 226 597 minecraft:oak_log
fill 342 226 598 345 226 598 minecraft:green_terracotta
setblock 343 226 597 minecraft:green_terracotta
setblock 344 226 560 minecraft:oak_log
setblock 345 226 559 minecraft:oak_log
fill 345 226 560 345 229 560 minecraft:green_terracotta
setblock 346 226 558 minecraft:oak_log
fill 346 226 559 346 229 559 minecraft:green_terracotta
setblock 346 226 598 minecraft:oak_log
fill 347 226 558 347 229 558 minecraft:green_terracotta
fill 347 226 598 347 229 598 minecraft:green_terracotta
setblock 350 226 559 minecraft:oak_log
setblock 351 226 558 minecraft:oak_log
fill 351 226 559 352 228 559 minecraft:green_terracotta
setblock 351 226 598 minecraft:oak_log
fill 352 226 558 352 229 558 minecraft:green_terracotta
fill 352 226 598 352 229 598 minecraft:green_terracotta
fill 353 226 597 353 229 597 minecraft:green_terracotta
setblock 355 226 559 minecraft:oak_log
setblock 356 226 558 minecraft:oak_log
fill 356 226 559 356 229 559 minecraft:green_terracotta
setblock 356 226 598 minecraft:oak_log
fill 357 226 558 357 229 558 minecraft:green_terracotta
setblock 357 226 597 minecraft:oak_log
fill 357 226 598 357 229 598 minecraft:green_terracotta
setblock 358 226 596 minecraft:oak_log
fill 358 226 597 358 229 597 minecraft:green_terracotta
fill 359 226 596 359 229 596 minecraft:green_terracotta
setblock 360 226 559 minecraft:oak_log
setblock 361 226 558 minecraft:oak_log
fill 361 226 559 361 229 559 minecraft:green_terracotta
setblock 361 226 598 minecraft:oak_log
fill 362 226 558 362 229 558 minecraft:green_terracotta
setblock 362 226 597 minecraft:oak_log
fill 362 226 598 362 229 598 minecraft:green_terracotta
fill 363 226 597 363 228 597 minecraft:green_terracotta
setblock 366 226 598 minecraft:oak_log
setblock 367 226 558 minecraft:oak_leaves[persistent=true]
setblock 367 226 598 minecraft:green_terracotta
fill 369 226 578 369 226 579 minecraft:green_terracotta
setblock 369 226 580 minecraft:oak_log
fill 369 226 581 369 228 582 minecraft:green_terracotta
fill 370 226 575 370 229 575 minecraft:green_terracotta
setblock 370 226 579 minecraft:oak_log
fill 370 226 580 370 229 580 minecraft:green_terracotta
setblock 370 226 584 minecraft:oak_log
fill 370 226 585 370 229 585 minecraft:green_terracotta
setblock 330 227 558 minecraft:oak_log
fill 330 227 559 330 227 562 minecraft:green_terracotta
setblock 330 227 563 minecraft:oak_log
setblock 330 227 573 minecraft:oak_log
fill 330 227 574 330 230 574 minecraft:green_terracotta
setblock 330 227 578 minecraft:oak_log
fill 330 227 579 330 230 579 minecraft:green_terracotta
setblock 330 227 583 minecraft:oak_log
fill 330 227 584 330 230 584 minecraft:green_terracotta
fill 331 227 558 331 230 558 minecraft:green_terracotta
setblock 331 227 576 minecraft:green_terracotta
setblock 331 227 577 minecraft:oak_log
fill 331 227 578 331 230 578 minecraft:green_terracotta
setblock 331 227 581 minecraft:green_terracotta
setblock 331 227 582 minecraft:oak_log
fill 332 227 559 333 227 559 minecraft:green_terracotta
setblock 334 227 559 minecraft:oak_log
fill 334 227 560 335 229 560 minecraft:green_terracotta
setblock 334 227 598 minecraft:green_terracotta
setblock 335 227 558 minecraft:oak_log
fill 335 227 559 335 230 559 minecraft:green_terracotta
setblock 335 227 598 minecraft:oak_log
fill 336 227 558 336 230 558 minecraft:green_terracotta
fill 336 227 598 336 230 598 minecraft:green_terracotta
setblock 338 227 559 minecraft:green_terracotta
setblock 338 227 560 minecraft:oak_log
fill 338 227 561 338 230 561 minecraft:green_terracotta
fill 338 227 562 338 228 563 minecraft:oak_log
fill 338 227 597 338 229 597 minecraft:green_terracotta
setblock 339 227 559 minecraft:oak_log
fill 339 227 560 339 230 560 minecraft:green_terracotta
setblock 340 227 558 minecraft:oak_log
fill 340 227 559 340 230 559 minecraft:green_terracotta
setblock 340 227 598 minecraft:oak_log
fill 341 227 558 341 230 558 minecraft:green_terracotta
setblock 341 227 561 minecraft:green_terracotta
setblock 341 227 597 minecraft:oak_log
fill 341 227 598 344 227 598 minecraft:green_terracotta
fill 342 227 597 342 228 597 minecraft:green_terracotta
setblock 343 227 560 minecraft:oak_log
setblock 344 227 559 minecraft:oak_log
fill 344 227 560 344 230 560 minecraft:green_terracotta
setblock 345 227 558 minecraft:oak_log
fill 345 227 559 345 230 559 minecraft:green_terracotta
setblock 345 227 598 minecraft:oak_log
fill 346 227 558 346 230 558 minecraft:green_terracotta
fill 346 227 598 346 230 598 minecraft:green_terracotta
setblock 349 227 559 minecraft:oak_log
setblock 350 227 558 minecraft:oak_log
fill 350 227 559 350 230 559 minecraft:green_terracotta
setblock 350 227 598 minecraft:oak_log
fill 351 227 558 351 230 558 minecraft:green_terracotta
fill 351 227 598 351 230 598 minecraft:green_terracotta
fill 352 227 597 352 230 597 minecraft:green_terracotta
setblock 354 227 559 minecraft:oak_log
setblock 355 227 558 minecraft:oak_log
fill 355 227 559 355 230 559 minecraft:green_terracotta
setblock 355 227 598 minecraft:oak_log
fill 356 227 558 356 230 558 minecraft:green_terracotta
fill 356 227 560 357 227 560 minecraft:green_terracotta
setblock 356 227 596 minecraft:green_terracotta
setblock 356 227 597 minecraft:oak_log
fill 356 227 598 356 230 598 minecraft:green_terracotta
setblock 357 227 596 minecraft:oak_log
fill 357 227 597 357 230 597 minecraft:green_terracotta
setblock 358 227 560 minecraft:oak_log
fill 358 227 596 358 230 596 minecraft:green_terracotta
setblock 359 227 559 minecraft:oak_log
fill 359 227 560 359 230 560 minecraft:green_terracotta
setblock 360 227 558 minecraft:oak_log
fill 360 227 559 360 230 559 minecraft:green_terracotta
setblock 360 227 598 minecraft:oak_log
fill 361 227 558 361 230 558 minecraft:green_terracotta
setblock 361 227 597 minecraft:oak_log
fill 361 227 598 361 230 598 minecraft:green_terracotta
fill 362 227 597 362 230 597 minecraft:green_terracotta
setblock 365 227 558 minecraft:oak_log
setblock 365 227 598 minecraft:oak_log
fill 366 227 598 366 228 598 minecraft:green_terracotta
setblock 369 227 578 minecraft:green_terracotta
setblock 369 227 579 minecraft:oak_log
fill 369 227 580 369 230 580 minecraft:green_terracotta
setblock 369 227 583 minecraft:green_terracotta
setblock 370 227 574 minecraft:oak_leaves[persistent=true]
setblock 370 227 578 minecraft:oak_log
fill 370 227 579 370 230 579 minecraft:green_terracotta
setblock 370 227 583 minecraft:oak_log
fill 370 227 584 370 230 584 minecraft:green_terracotta
fill 370 227 586 370 228 586 minecraft:green_terracotta
setblock 370 227 593 minecraft:oak_leaves[persistent=true]
fill 330 228 558 330 228 561 minecraft:green_terracotta
setblock 330 228 562 minecraft:oak_log
fill 330 228 563 330 228 566 minecraft:green_terracotta
setblock 330 228 569 minecraft:oak_leaves[persistent=true]
fill 330 228 573 330 231 573 minecraft:green_terracotta
setblock 330 228 577 minecraft:oak_log
fill 330 228 578 330 231 578 minecraft:green_terracotta
setblock 330 228 582 minecraft:oak_log
fill 330 228 583 331 230 583 minecraft:green_terracotta
fill 330 228 585 330 229 585 minecraft:green_terracotta
setblock 330 228 588 minecraft:oak_leaves[persistent=true]
fill 331 228 559 331 228 560 minecraft:green_terracotta
setblock 331 228 561 minecraft:oak_log
fill 331 228 562 331 230 563 minecraft:green_terracotta
setblock 331 228 576 minecraft:oak_log
fill 331 228 577 331 231 577 minecraft:green_terracotta
setblock 331 228 581 minecraft:oak_log
fill 331 228 582 331 231 582 minecraft:green_terracotta
setblock 332 228 559 minecraft:green_terracotta
setblock 333 228 559 minecraft:oak_log
fill 333 228 560 333 231 560 minecraft:green_terracotta
setblock 334 228 558 minecraft:oak_log
fill 334 228 559 334 231 559 minecraft:green_terracotta
setblock 334 228 598 minecraft:oak_log
fill 335 228 558 335 231 558 minecraft:green_terracotta
setblock 335 228 561 minecraft:green_terracotta
fill 335 228 598 335 231 598 minecraft:green_terracotta
setblock 337 228 559 minecraft:green_terracotta
setblock 337 228 560 minecraft:oak_log
fill 337 228 561 337 231 561 minecraft:green_terracotta
fill 337 228 562 337 229 563 minecraft:oak_log
fill 337 228 597 337 230 597 minecraft:green_terracotta
setblock 338 228 559 minecraft:oak_log
fill 338 228 560 338 231 560 minecraft:green_terracotta
setblock 339 228 558 minecraft:oak_log
fill 339 228 559 339 231 559 minecraft:green_terracotta
setblock 339 228 598 minecraft:oak_log
fill 340 228 558 340 231 558 minecraft:green_terracotta
setblock 340 228 597 minecraft:oak_log
fill 340 228 598 343 228 598 minecraft:green_terracotta
setblock 341 228 561 minecraft:oak_log
fill 341 228 597 341 229 597 minecraft:green_terracotta
setblock 342 228 560 minecraft:oak_log
fill 342 228 561 342 231 561 minecraft:green_terracotta
setblock 343 228 559 minecraft:oak_log
fill 343 228 560 343 231 560 minecraft:green_terracotta
setblock 344 228 558 minecraft:oak_log
fill 344 228 559 344 231 559 minecraft:green_terracotta
setblock 344 228 598 minecraft:oak_log
fill 345 228 558 345 231 558 minecraft:green_terracotta
fill 345 228 598 345 231 598 minecraft:green_terracotta
setblock 348 228 559 minecraft:oak_log
setblock 349 228 558 minecraft:oak_log
fill 349 228 559 349 231 559 minecraft:green_terracotta
setblock 349 228 598 minecraft:oak_log
fill 350 228 558 350 231 558 minecraft:green_terracotta
fill 350 228 598 350 231 598 minecraft:green_terracotta
setblock 353 228 558 minecraft:green_terracotta
setblock 353 228 559 minecraft:oak_log
setblock 354 228 558 minecraft:oak_log
fill 354 228 559 354 230 560 minecraft:green_terracotta
setblock 354 228 598 minecraft:oak_log
fill 355 228 558 355 231 558 minecraft:green_terracotta
fill 355 228 560 356 228 560 minecraft:green_terracotta
setblock 355 228 597 minecraft:oak_log
fill 355 228 598 355 231 598 minecraft:green_terracotta
setblock 356 228 596 minecraft:oak_log
fill 356 228 597 356 231 597 minecraft:green_terracotta
setblock 357 228 560 minecraft:oak_log
fill 357 228 596 357 231 596 minecraft:green_terracotta
setblock 358 228 559 minecraft:oak_log
fill 358 228 560 358 231 560 minecraft:green_terracotta
setblock 359 228 558 minecraft:oak_log
fill 359 228 559 359 231 559 minecraft:green_terracotta
setblock 359 228 598 minecraft:oak_log
fill 360 228 558 360 231 558 minecraft:green_terracotta
fill 360 228 560 360 229 560 minecraft:green_terracotta
setblock 360 228 597 minecraft:oak_log
fill 360 228 598 360 231 598 minecraft:green_terracotta
fill 361 228 597 361 231 597 minecraft:green_terracotta
setblock 363 228 559 minecraft:oak_log
setblock 364 228 558 minecraft:oak_log
setblock 364 228 598 minecraft:oak_log
fill 365 228 558 365 229 558 minecraft:green_terracotta
fill 365 228 598 365 229 598 minecraft:green_terracotta
setblock 369 228 578 minecraft:oak_log
fill 369 228 579 369 231 579 minecraft:green_terracotta
setblock 369 228 583 minecraft:oak_log
fill 369 228 584 369 230 585 minecraft:green_terracotta
setblock 370 228 568 minecraft:oak_leaves[persistent=true]
setblock 370 228 577 minecraft:oak_log
fill 370 228 578 370 231 578 minecraft:green_terracotta
setblock 370 228 582 minecraft:oak_log
fill 370 228 583 370 231 583 minecraft:green_terracotta
setblock 370 228 587 minecraft:oak_log
fill 330 229 558 330 229 560 minecraft:green_terracotta
setblock 330 229 561 minecraft:oak_log
fill 330 229 562 330 229 565 minecraft:green_terracotta
setblock 330 229 566 minecraft:oak_log
fill 330 229 567 330 229 570 minecraft:green_terracotta
setblock 330 229 571 minecraft:oak_log
fill 330 229 572 330 232 572 minecraft:green_terracotta
setblock 330 229 576 minecraft:oak_log
fill 330 229 577 330 232 577 minecraft:green_terracotta
setblock 330 229 580 minecraft:green_terracotta
setblock 330 229 581 minecraft:oak_log
fill 330 229 582 330 232 582 minecraft:green_terracotta
setblock 330 229 586 minecraft:oak_log
setblock 330 229 594 minecraft:oak_leaves[persistent=true]
setblock 331 229 559 minecraft:green_terracotta
setblock 331 229 560 minecraft:oak_log
fill 331 229 561 332 231 561 minecraft:green_terracotta
setblock 331 229 564 minecraft:green_terracotta
setblock 331 229 565 minecraft:oak_log
fill 331 229 566 331 232 566 minecraft:green_terracotta
fill 331 229 576 331 232 576 minecraft:green_terracotta
setblock 331 229 580 minecraft:oak_log
fill 331 229 581 331 232 581 minecraft:green_terracotta
setblock 331 229 584 minecraft:green_terracotta
setblock 332 229 559 minecraft:oak_log
fill 332 229 560 332 232 560 minecraft:green_terracotta
fill 332 229 562 332 229 563 minecraft:green_terracotta
setblock 332 229 564 minecraft:oak_log
fill 332 229 580 332 231 580 minecraft:green_terracotta
setblock 333 229 558 minecraft:oak_log
fill 333 229 559 333 232 559 minecraft:green_terracotta
setblock 333 229 598 minecraft:oak_log
fill 334 229 558 334 232 558 minecraft:green_terracotta
setblock 334 229 561 minecraft:green_terracotta
fill 334 229 598 334 232 598 minecraft:green_terracotta
setblock 335 229 561 minecraft:oak_log
setblock 336 229 559 minecraft:green_terracotta
setblock 336 229 560 minecraft:oak_log
fill 336 229 561 336 232 561 minecraft:green_terracotta
fill 336 229 562 336 229 563 minecraft:oak_log
setblock 337 229 559 minecraft:oak_log
fill 337 229 560 337 232 560 minecraft:green_terracotta
setblock 338 229 558 minecraft:oak_log
fill 338 229 559 338 232 559 minecraft:green_terracotta
setblock 338 229 562 minecraft:green_terracotta
fill 338 229 563 338 233 563 minecraft:oak_log
setblock 338 229 598 minecraft:oak_log
fill 339 229 558 339 232 558 minecraft:green_terracotta
setblock 339 229 561 minecraft:green_terracotta
setblock 339 229 597 minecraft:oak_log
fill 339 229 598 342 229 598 minecraft:green_terracotta
setblock 340 229 561 minecraft:oak_log
fill 340 229 597 340 230 597 minecraft:green_terracotta
setblock 341 229 560 minecraft:oak_log
fill 341 229 561 341 232 561 minecraft:green_terracotta
setblock 342 229 559 minecraft:oak_log
fill 342 229 560 342 232 560 minecraft:green_terracotta
setblock 343 229 558 minecraft:oak_log
fill 343 229 559 343 232 559 minecraft:green_terracotta
setblock 343 229 598 minecraft:oak_log
fill 344 229 558 344 232 558 minecraft:green_terracotta
fill 344 229 598 344 232 598 minecraft:green_terracotta
setblock 346 229 560 minecraft:oak_log
setblock 347 229 559 minecraft:oak_log
setblock 348 229 558 minecraft:oak_log
fill 348 229 559 348 232 559 minecraft:green_terracotta
setblock 348 229 598 minecraft:oak_log
fill 349 229 558 349 232 558 minecraft:green_terracotta
fill 349 229 598 349 232 598 minecraft:green_terracotta
setblock 351 229 559 minecraft:green_terracotta
fill 351 229 597 351 231 597 minecraft:green_terracotta
setblock 352 229 559 minecraft:oak_log
fill 352 229 560 353 231 560 minecraft:green_terracotta
setblock 353 229 558 minecraft:oak_log
fill 353 229 559 353 232 559 minecraft:green_terracotta
setblock 353 229 598 minecraft:oak_log
fill 354 229 558 354 232 558 minecraft:green_terracotta
setblock 354 229 597 minecraft:oak_log
fill 354 229 598 354 232 598 minecraft:green_terracotta
setblock 355 229 560 minecraft:green_terracotta
setblock 355 229 596 minecraft:oak_log
fill 355 229 597 355 232 597 minecraft:green_terracotta
setblock 356 229 560 minecraft:oak_log
fill 356 229 596 356 232 596 minecraft:green_terracotta
setblock 357 229 559 minecraft:oak_log
fill 357 229 560 357 232 560 minecraft:green_terracotta
setblock 358 229 558 minecraft:oak_log
fill 358 229 559 358 232 559 minecraft:green_terracotta
setblock 358 229 598 minecraft:oak_log
fill 359 229 558 359 232 558 minecraft:green_terracotta
setblock 359 229 597 minecraft:oak_log
fill 359 229 598 359 232 598 minecraft:green_terracotta
setblock 360 229 596 minecraft:oak_log
fill 360 229 597 360 232 597 minecraft:green_terracotta
setblock 362 229 559 minecraft:oak_log
setblock 363 229 558 minecraft:oak_log
setblock 363 229 559 minecraft:green_terracotta
setblock 363 229 598 minecraft:oak_log
fill 364 229 558 364 231 558 minecraft:green_terracotta
fill 364 229 598 364 230 598 minecraft:green_terracotta
setblock 368 229 582 minecraft:green_terracotta
setblock 369 229 577 minecraft:oak_log
fill 369 229 578 369 232 578 minecraft:green_terracotta
setblock 369 229 581 minecraft:green_terracotta
setblock 369 229 582 minecraft:oak_log
fill 369 229 583 369 232 583 minecraft:green_terracotta
setblock 369 229 586 minecraft:green_terracotta
fill 370 229 559 370 229 560 minecraft:green_terracotta
setblock 370 229 561 minecraft:oak_log
fill 370 229 562 370 231 563 minecraft:green_terracotta
fill 370 229 574 370 230 574 minecraft:green_terracotta
setblock 370 229 576 minecraft:oak_log
fill 370 229 577 370 232 577 minecraft:green_terracotta
setblock 370 229 581 minecraft:oak_log
fill 370 229 582 370 232 582 minecraft:green_terracotta
setblock 370 229 586 minecraft:oak_log
fill 370 229 587 370 231 588 minecraft:green_terracotta
setblock 370 229 598 minecraft:oak_leaves[persistent=true]
fill 330 230 558 330 230 559 minecraft:green_terracotta
setblock 330 230 560 minecraft:oak_log
fill 330 230 561 330 230 564 minecraft:green_terracotta
setblock 330 230 565 minecraft:oak_log
fill 330 230 566 330 230 569 minecraft:green_terracotta
setblock 330 230 570 minecraft:oak_log
fill 330 230 571 330 233 571 minecraft:green_terracotta
setblock 330 230 575 minecraft:oak_log
fill 330 230 576 330 233 576 minecraft:green_terracotta
setblock 330 230 580 minecraft:oak_log
fill 330 230 581 330 233 581 minecraft:green_terracotta
setblock 330 230 585 minecraft:oak_log
fill 330 230 586 330 232 587 minecraft:green_terracotta
setblock 331 230 559 minecraft:oak_log
fill 331 230 560 331 233 560 minecraft:green_terracotta
setblock 331 230 564 minecraft:oak_log
fill 331 230 565 332 232 565 minecraft:green_terracotta
fill 331 230 567 331 230 568 minecraft:green_terracotta
setblock 331 230 569 minecraft:oak_log
fill 331 230 570 332 230 574 minecraft:oak_leaves[persistent=true]
fill 331 230 575 331 232 575 minecraft:green_terracotta
setblock 331 230 579 minecraft:oak_log
fill 331 230 580 331 233 580 minecraft:green_terracotta
setblock 331 230 584 minecraft:oak_log
fill 331 230 585 331 233 585 minecraft:green_terracotta
setblock 332 230 558 minecraft:oak_log
fill 332 230 559 332 233 559 minecraft:green_terracotta
setblock 332 230 562 minecraft:green_terracotta
setblock 332 230 563 minecraft:oak_log
fill 332 230 564 333 232 564 minecraft:green_terracotta
fill 332 230 566 332 231 566 minecraft:green_terracotta
fill 332 230 568 337 230 569 minecraft:oak_leaves[persistent=true]
fill 332 230 575 338 230 576 minecraft:oak_leaves[persistent=true]
setblock 332 230 579 minecraft:green_terracotta
fill 332 230 581 332 230 582 minecraft:green_terracotta
setblock 332 230 598 minecraft:oak_leaves[persistent=true]
fill 333 230 558 333 233 558 minecraft:green_terracotta
setblock 333 230 561 minecraft:green_terracotta
setblock 333 230 562 minecraft:oak_log
fill 333 230 563 333 233 563 minecraft:green_terracotta
fill 333 230 570 333 232 570 minecraft:oak_leaves[persistent=true]
fill 333 230 598 333 233 598 minecraft:green_terracotta
setblock 334 230 560 minecraft:green_terracotta
setblock 334 230 561 minecraft:oak_log
fill 334 230 562 335 230 563 minecraft:oak_leaves[persistent=true]
fill 334 230 577 336 230 577 minecraft:oak_leaves[persistent=true]
setblock 335 230 560 minecraft:oak_log
fill 335 230 561 335 233 561 minecraft:green_terracotta
fill 335 230 564 340 230 565 minecraft:oak_leaves[persistent=true]
setblock 336 230 559 minecraft:oak_log
fill 336 230 560 336 233 560 minecraft:green_terracotta
fill 336 230 562 337 230 562 minecraft:green_terracotta
fill 336 230 563 337 233 563 minecraft:oak_log
fill 336 230 578 336 230 580 minecraft:oak_leaves[persistent=true]
setblock 337 230 558 minecraft:oak_log
fill 337 230 559 337 233 559 minecraft:green_terracotta
fill 337 230 570 339 230 570 minecraft:oak_leaves[persistent=true]
fill 337 230 574 339 230 574 minecraft:oak_leaves[persistent=true]
fill 337 230 580 340 230 580 minecraft:oak_leaves[persistent=true]
setblock 337 230 598 minecraft:oak_log
fill 338 230 558 338 233 558 minecraft:green_terracotta
setblock 338 230 562 minecraft:oak_log
setblock 338 230 569 minecraft:oak_leaves[persistent=true]
fill 338 230 571 339 230 573 minecraft:oak_leaves[persistent=true]
setblock 338 230 581 minecraft:oak_leaves[persistent=true]
setblock 338 230 597 minecraft:oak_log
fill 338 230 598 341 230 598 minecraft:green_terracotta
setblock 339 230 561 minecraft:oak_log
fill 339 230 562 339 231 562 minecraft:green_terracotta
fill 339 230 563 339 233 563 minecraft:oak_log
fill 339 230 576 340 230 576 minecraft:oak_leaves[persistent=true]
fill 339 230 597 339 231 597 minecraft:green_terracotta
setblock 340 230 560 minecraft:oak_log
fill 340 230 561 340 233 561 minecraft:green_terracotta
fill 340 230 563 342 230 563 minecraft:oak_leaves[persistent=true]
fill 340 230 577 340 231 579 minecraft:oak_leaves[persistent=true]
setblock 341 230 559 minecraft:oak_log
fill 341 230 560 341 233 560 minecraft:green_terracotta
fill 341 230 562 342 230 562 minecraft:oak_leaves[persistent=true]
setblock 341 230 564 minecraft:oak_leaves[persistent=true]
fill 341 230 578 341 230 579 minecraft:oak_leaves[persistent=true]
setblock 342 230 558 minecraft:oak_log
fill 342 230 559 342 233 559 minecraft:green_terracotta
setblock 342 230 598 minecraft:oak_log
fill 343 230 558 343 233 558 minecraft:green_terracotta
fill 343 230 598 343 233 598 minecraft:green_terracotta
setblock 345 230 560 minecraft:oak_log
setblock 346 230 559 minecraft:oak_log
setblock 346 230 560 minecraft:green_terracotta
setblock 347 230 558 minecraft:oak_log
fill 347 230 559 347 233 559 minecraft:green_terracotta
setblock 347 230 598 minecraft:oak_log
fill 348 230 558 348 233 558 minecraft:green_terracotta
fill 348 230 598 348 233 598 minecraft:green_terracotta
setblock 351 230 559 minecraft:oak_log
fill 351 230 560 351 232 560 minecraft:green_terracotta
setblock 352 230 558 minecraft:oak_log
fill 352 230 559 352 233 559 minecraft:green_terracotta
setblock 352 230 598 minecraft:oak_log
fill 353 230 558 353 233 558 minecraft:green_terracotta
setblock 353 230 597 minecraft:oak_log
fill 353 230 598 353 233 598 minecraft:green_terracotta
fill 354 230 597 354 233 597 minecraft:green_terracotta
setblock 355 230 560 minecraft:oak_log
fill 355 230 596 355 232 596 minecraft:green_terracotta
setblock 356 230 559 minecraft:oak_log
fill 356 230 560 356 233 560 minecraft:green_terracotta
setblock 357 230 558 minecraft:oak_log
fill 357 230 559 357 233 559 minecraft:green_terracotta
setblock 357 230 598 minecraft:oak_log
fill 358 230 558 358 233 558 minecraft:green_terracotta
setblock 358 230 597 minecraft:oak_log
fill 358 230 598 358 233 598 minecraft:green_terracotta
fill 359 230 563 360 230 563 minecraft:oak_leaves[persistent=true]
setblock 359 230 596 minecraft:oak_log
fill 359 230 597 359 233 597 minecraft:green_terracotta
setblock 360 230 560 minecraft:oak_log
fill 360 230 561 360 230 562 minecraft:oak_leaves[persistent=true]
fill 360 230 564 360 230 565 minecraft:oak_leaves[persistent=true]
setblock 361 230 559 minecraft:oak_log
fill 361 230 560 364 230 561 minecraft:oak_leaves[persistent=true]
fill 361 230 565 364 230 566 minecraft:oak_leaves[persistent=true]
setblock 362 230 558 minecraft:oak_log
setblock 362 230 559 minecraft:green_terracotta
setblock 362 230 598 minecraft:oak_log
fill 363 230 558 363 231 558 minecraft:green_terracotta
fill 363 230 598 363 231 598 minecraft:green_terracotta
fill 365 230 561 365 231 565 minecraft:oak_leaves[persistent=true]
fill 366 230 562 366 230 564 minecraft:oak_leaves[persistent=true]
setblock 368 230 558 minecraft:oak_leaves[persistent=true]
setblock 368 230 581 minecraft:green_terracotta
setblock 368 230 582 minecraft:oak_log
fill 368 230 583 368 232 584 minecraft:green_terracotta
fill 369 230 577 369 231 577 minecraft:green_terracotta
setblock 369 230 581 minecraft:oak_log
fill 369 230 582 369 233 582 minecraft:green_terracotta
setblock 369 230 586 minecraft:oak_log
fill 369 230 587 369 233 587 minecraft:green_terracotta
fill 370 230 558 370 230 559 minecraft:green_terracotta
setblock 370 230 560 minecraft:oak_log
fill 370 230 561 370 233 561 minecraft:green_terracotta
setblock 370 230 564 minecraft:green_terracotta
setblock 370 230 565 minecraft:oak_log
fill 370 230 566 370 233 566 minecraft:green_terracotta
fill 370 230 573 370 231 573 minecraft:green_terracotta
setblock 370 230 575 minecraft:oak_log
fill 370 230 576 370 233 576 minecraft:green_terracotta
setblock 370 230 580 minecraft:oak_log
fill 370 230 581 370 233 581 minecraft:green_terracotta
setblock 370 230 585 minecraft:oak_log
fill 370 230 586 370 233 586 minecraft:green_terracotta
setblock 370 230 589 minecraft:green_terracotta
setblock 330 231 558 minecraft:green_terracotta
setblock 330 231 559 minecraft:oak_log
fill 330 231 560 330 231 563 minecraft:green_terracotta
setblock 330 231 564 minecraft:oak_log
fill 330 231 565 330 231 568 minecraft:green_terracotta
setblock 330 231 569 minecraft:oak_log
fill 330 231 570 331 233 570 minecraft:green_terracotta
setblock 330 231 574 minecraft:oak_log
fill 330 231 575 330 233 575 minecraft:green_terracotta
setblock 330 231 579 minecraft:oak_log
fill 330 231 580 330 233 580 minecraft:green_terracotta
setblock 330 231 583 minecraft:green_terracotta
setblock 330 231 584 minecraft:oak_log
fill 330 231 585 330 233 585 minecraft:green_terracotta
setblock 330 231 588 minecraft:green_terracotta
setblock 331 231 558 minecraft:oak_log
fill 331 231 559 331 233 559 minecraft:green_terracotta
setblock 331 231 562 minecraft:green_terracotta
setblock 331 231 563 minecraft:oak_log
fill 331 231 564 331 233 564 minecraft:green_terracotta
setblock 331 231 567 minecraft:green_terracotta
setblock 331 231 568 minecraft:oak_log
fill 331 231 569 331 233 569 minecraft:green_terracotta
fill 331 231 571 331 232 571 minecraft:green_terracotta
fill 331 231 572 332 231 573 minecraft:oak_leaves[persistent=true]
setblock 331 231 578 minecraft:oak_log
fill 331 231 579 331 233 579 minecraft:green_terracotta
setblock 331 231 583 minecraft:oak_log
fill 331 231 584 331 233 584 minecraft:green_terracotta
fill 331 231 586 331 232 586 minecraft:green_terracotta
fill 332 231 558 332 233 558 minecraft:green_terracotta
setblock 332 231 562 minecraft:oak_log
fill 332 231 563 332 233 563 minecraft:green_terracotta
setblock 332 231 567 minecraft:oak_log
fill 332 231 568 332 233 568 minecraft:green_terracotta
fill 332 231 569 332 231 571 minecraft:oak_leaves[persistent=true]
fill 332 231 574 332 231 575 minecraft:oak_leaves[persistent=true]
setblock 332 231 581 minecraft:green_terracotta
setblock 332 231 582 minecraft:oak_log
fill 332 231 583 332 233 583 minecraft:green_terracotta
fill 332 231 598 332 232 598 minecraft:green_terracotta
setblock 333 231 561 minecraft:oak_log
fill 333 231 562 333 233 562 minecraft:green_terracotta
setblock 333 231 565 minecraft:green_terracotta
setblock 333 231 566 minecraft:oak_log
fill 333 231 569 337 231 569 minecraft:oak_leaves[persistent=true]
fill 333 231 575 337 231 575 minecraft:oak_leaves[persistent=true]
setblock 334 231 560 minecraft:oak_log
fill 334 231 561 334 233 561 minecraft:green_terracotta
fill 334 231 576 339 231 576 minecraft:oak_leaves[persistent=true]
setblock 335 231 559 minecraft:oak_log
fill 335 231 560 335 233 560 minecraft:green_terracotta
fill 335 231 562 336 231 562 minecraft:green_terracotta
fill 335 231 563 335 231 564 minecraft:oak_leaves[persistent=true]
setblock 335 231 568 minecraft:oak_leaves[persistent=true]
setblock 336 231 558 minecraft:oak_log
fill 336 231 559 336 233 559 minecraft:green_terracotta
fill 336 231 564 340 231 564 minecraft:oak_leaves[persistent=true]
fill 336 231 577 336 231 579 minecraft:oak_leaves[persistent=true]
setblock 336 231 598 minecraft:oak_log
fill 337 231 558 337 233 558 minecraft:green_terracotta
setblock 337 231 562 minecraft:oak_log
fill 337 231 565 339 231 565 minecraft:oak_leaves[persistent=true]
fill 337 231 570 338 231 570 minecraft:oak_leaves[persistent=true]
fill 337 231 574 338 231 574 minecraft:oak_leaves[persistent=true]
fill 337 231 580 339 231 580 minecraft:oak_leaves[persistent=true]
setblock 337 231 597 minecraft:oak_log
fill 337 231 598 340 231 598 minecraft:green_terracotta
setblock 338 231 561 minecraft:oak_log
fill 338 231 562 338 232 562 minecraft:green_terracotta
fill 338 231 571 338 231 573 minecraft:oak_leaves[persistent=true]
setblock 338 231 597 minecraft:green_terracotta
setblock 339 231 560 minecraft:oak_log
fill 339 231 561 339 233 561 minecraft:green_terracotta
setblock 340 231 559 minecraft:oak_log
fill 340 231 560 340 233 560 minecraft:green_terracotta
fill 340 231 563 341 231 563 minecraft:oak_leaves[persistent=true]
setblock 341 231 558 minecraft:oak_log
fill 341 231 559 341 233 559 minecraft:green_terracotta
setblock 341 231 562 minecraft:oak_leaves[persistent=true]
setblock 341 231 598 minecraft:oak_log
fill 342 231 558 342 233 558 minecraft:green_terracotta
fill 342 231 598 342 233 598 minecraft:green_terracotta
setblock 344 231 560 minecraft:oak_log
setblock 345 231 559 minecraft:oak_log
setblock 345 231 560 minecraft:green_terracotta
setblock 346 231 558 minecraft:oak_log
fill 346 231 559 346 233 559 minecraft:green_terracotta
setblock 346 231 598 minecraft:oak_log
fill 347 231 558 347 233 558 minecraft:green_terracotta
fill 347 231 598 347 233 598 minecraft:green_terracotta
setblock 350 231 559 minecraft:oak_log
setblock 351 231 558 minecraft:oak_log
fill 351 231 559 351 233 559 minecraft:green_terracotta
setblock 351 231 598 minecraft:oak_log
fill 352 231 558 352 233 558 minecraft:green_terracotta
setblock 352 231 597 minecraft:oak_log
fill 352 231 598 352 233 598 minecraft:green_terracotta
fill 353 231 597 353 233 597 minecraft:green_terracotta
setblock 354 231 559 minecraft:green_terracotta
setblock 354 231 560 minecraft:oak_log
fill 354 231 596 354 232 596 minecraft:green_terracotta
setblock 355 231 559 minecraft:oak_log
fill 355 231 560 355 233 560 minecraft:green_terracotta
setblock 356 231 558 minecraft:oak_log
fill 356 231 559 356 233 559 minecraft:green_terracotta
setblock 356 231 598 minecraft:oak_log
fill 357 231 558 357 233 558 minecraft:green_terracotta
setblock 357 231 597 minecraft:oak_log
fill 357 231 598 357 233 598 minecraft:green_terracotta
setblock 358 231 596 minecraft:oak_log
fill 358 231 597 358 233 597 minecraft:green_terracotta
setblock 359 231 560 minecraft:oak_log
setblock 360 231 559 minecraft:oak_log
fill 360 231 562 360 231 564 minecraft:oak_leaves[persistent=true]
setblock 361 231 558 minecraft:oak_log
setblock 361 231 559 minecraft:green_terracotta
fill 361 231 561 364 231 561 minecraft:oak_leaves[persistent=true]
fill 361 231 565 364 231 565 minecraft:oak_leaves[persistent=true]
setblock 361 231 598 minecraft:oak_log
fill 362 231 558 362 232 558 minecraft:green_terracotta
fill 362 231 560 363 231 560 minecraft:oak_leaves[persistent=true]
fill 362 231 566 363 231 566 minecraft:oak_leaves[persistent=true]
fill 362 231 598 362 232 598 minecraft:green_terracotta
setblock 368 231 581 minecraft:oak_log
fill 368 231 582 368 232 582 minecraft:green_terracotta
setblock 368 231 585 minecraft:green_terracotta
setblock 369 231 580 minecraft:oak_log
fill 369 231 581 369 233 581 minecraft:green_terracotta
setblock 369 231 584 minecraft:green_terracotta
setblock 369 231 585 minecraft:oak_log
fill 369 231 586 369 233 586 minecraft:green_terracotta
fill 369 231 588 369 232 588 minecraft:green_terracotta
setblock 370 231 558 minecraft:green_terracotta
setblock 370 231 559 minecraft:oak_log
fill 370 231 560 370 233 560 minecraft:green_terracotta
setblock 370 231 564 minecraft:oak_log
fill 370 231 565 370 233 565 minecraft:green_terracotta
fill 370 231 567 370 231 568 minecraft:green_terracotta
setblock 370 231 569 minecraft:oak_log
fill 370 231 570 370 232 572 minecraft:green_terracotta
setblock 370 231 574 minecraft:oak_log
fill 370 231 575 370 233 575 minecraft:green_terracotta
setblock 370 231 579 minecraft:oak_log
fill 370 231 580 370 233 580 minecraft:green_terracotta
setblock 370 231 584 minecraft:oak_log
fill 370 231 585 370 233 585 minecraft:green_terracotta
setblock 370 231 589 minecraft:oak_log
fill 370 231 590 370 233 590 minecraft:green_terracotta
setblock 370 231 594 minecraft:oak_leaves[persistent=true]
setblock 330 232 558 minecraft:oak_log
fill 330 232 559 330 232 562 minecraft:green_terracotta
setblock 330 232 563 minecraft:oak_log
fill 330 232 564 330 232 567 minecraft:green_terracotta
setblock 330 232 568 minecraft:oak_log
fill 330 232 569 330 233 569 minecraft:green_terracotta
setblock 330 232 573 minecraft:oak_log
fill 330 232 574 330 233 574 minecraft:green_terracotta
setblock 330 232 578 minecraft:oak_log
fill 330 232 579 330 233 579 minecraft:green_terracotta
setblock 330 232 583 minecraft:oak_log
fill 330 232 584 330 233 584 minecraft:green_terracotta
setblock 330 232 588 minecraft:oak_log
fill 330 232 589 330 233 589 minecraft:green_terracotta
setblock 330 232 593 minecraft:oak_leaves[persistent=true]
fill 331 232 558 331 233 558 minecraft:green_terracotta
setblock 331 232 561 minecraft:green_terracotta
setblock 331 232 562 minecraft:oak_log
fill 331 232 563 331 233 563 minecraft:green_terracotta
setblock 331 232 567 minecraft:oak_log
fill 331 232 568 331 233 568 minecraft:green_terracotta
setblock 331 232 572 minecraft:oak_log
fill 331 232 573 331 233 573 minecraft:green_terracotta
setblock 331 232 577 minecraft:oak_log
fill 331 232 578 331 233 578 minecraft:green_terracotta
setblock 331 232 582 minecraft:oak_log
fill 331 232 583 331 233 583 minecraft:green_terracotta
setblock 331 232 587 minecraft:oak_log
setblock 332 232 561 minecraft:oak_log
fill 332 232 562 332 233 562 minecraft:green_terracotta
setblock 332 232 566 minecraft:oak_log
fill 332 232 567 333 233 567 minecraft:green_terracotta
fill 332 232 569 332 233 569 minecraft:green_terracotta
fill 332 232 571 332 232 574 minecraft:oak_leaves[persistent=true]
setblock 332 232 581 minecraft:oak_log
setblock 332 232 582 minecraft:green_terracotta
setblock 332 232 584 minecraft:green_terracotta
setblock 333 232 560 minecraft:oak_log
fill 333 232 561 333 233 561 minecraft:green_terracotta
setblock 333 232 565 minecraft:oak_log
fill 333 232 566 333 233 566 minecraft:green_terracotta
fill 333 232 575 336 232 575 minecraft:oak_leaves[persistent=true]
setblock 334 232 559 minecraft:oak_log
fill 334 232 560 334 233 560 minecraft:green_terracotta
fill 334 232 562 334 232 563 minecraft:green_terracotta
setblock 334 232 564 minecraft:oak_log
fill 334 232 569 336 232 569 minecraft:oak_leaves[persistent=true]
setblock 335 232 558 minecraft:oak_log
fill 335 232 559 335 233 559 minecraft:green_terracotta
setblock 335 232 562 minecraft:green_terracotta
setblock 335 232 598 minecraft:oak_log
fill 336 232 558 336 233 558 minecraft:green_terracotta
setblock 336 232 562 minecraft:oak_log
fill 336 232 598 339 232 598 minecraft:green_terracotta
setblock 337 232 561 minecraft:oak_log
fill 337 232 562 337 233 562 minecraft:green_terracotta
fill 337 232 564 339 232 564 minecraft:oak_leaves[persistent=true]
setblock 337 232 570 minecraft:oak_leaves[persistent=true]
setblock 337 232 574 minecraft:oak_leaves[persistent=true]
setblock 338 232 560 minecraft:oak_log
fill 338 232 561 338 233 561 minecraft:green_terracotta
setblock 338 232 572 minecraft:oak_leaves[persistent=true]
setblock 338 232 580 minecraft:oak_leaves[persistent=true]
setblock 339 232 559 minecraft:oak_log
fill 339 232 560 339 233 560 minecraft:green_terracotta
fill 339 232 562 339 233 562 minecraft:oak_log
setblock 340 232 558 minecraft:oak_log
fill 340 232 559 340 233 559 minecraft:green_terracotta
setblock 340 232 563 minecraft:oak_leaves[persistent=true]
setblock 340 232 578 minecraft:oak_leaves[persistent=true]
setblock 340 232 598 minecraft:oak_log
fill 341 232 558 341 233 558 minecraft:green_terracotta
fill 341 232 598 341 233 598 minecraft:green_terracotta
setblock 343 232 560 minecraft:oak_log
setblock 344 232 559 minecraft:oak_log
setblock 344 232 560 minecraft:green_terracotta
setblock 345 232 558 minecraft:oak_log
fill 345 232 559 345 233 559 minecraft:green_terracotta
setblock 345 232 598 minecraft:oak_log
fill 346 232 558 346 233 558 minecraft:green_terracotta
fill 346 232 598 346 233 598 minecraft:green_terracotta
setblock 349 232 559 minecraft:oak_log
setblock 350 232 558 minecraft:oak_log
fill 350 232 559 350 233 559 minecraft:green_terracotta
setblock 350 232 598 minecraft:oak_log
fill 351 232 558 351 233 558 minecraft:green_terracotta
setblock 351 232 597 minecraft:oak_log
fill 351 232 598 351 233 598 minecraft:green_terracotta
setblock 352 232 560 minecraft:green_terracotta
fill 352 232 597 352 233 597 minecraft:green_terracotta
setblock 353 232 560 minecraft:oak_log
setblock 354 232 559 minecraft:oak_log
fill 354 232 560 354 233 560 minecraft:green_terracotta
setblock 355 232 558 minecraft:oak_log
fill 355 232 559 355 233 559 minecraft:green_terracotta
setblock 355 232 598 minecraft:oak_log
fill 356 232 558 356 233 558 minecraft:green_terracotta
setblock 356 232 597 minecraft:oak_log
fill 356 232 598 356 233 598 minecraft:green_terracotta
setblock 357 232 596 minecraft:oak_log
fill 357 232 597 357 233 597 minecraft:green_terracotta
setblock 358 232 560 minecraft:oak_log
setblock 359 232 559 minecraft:oak_log
setblock 360 232 558 minecraft:oak_log
setblock 360 232 559 minecraft:green_terracotta
setblock 360 232 598 minecraft:oak_log
fill 361 232 558 361 233 558 minecraft:green_terracotta
fill 361 232 598 361 233 598 minecraft:green_terracotta
fill 362 232 561 364 232 561 minecraft:oak_leaves[persistent=true]
fill 362 232 565 364 232 565 minecraft:oak_leaves[persistent=true]
fill 365 232 563 365 232 564 minecraft:oak_leaves[persistent=true]
setblock 368 232 585 minecraft:oak_log
setblock 369 232 579 minecraft:oak_log
fill 369 232 580 369 233 580 minecraft:green_terracotta
setblock 369 232 584 minecraft:oak_log
fill 369 232 585 369 233 585 minecraft:green_terracotta
setblock 369 232 598 minecraft:oak_leaves[persistent=true]
setblock 370 232 558 minecraft:oak_log
fill 370 232 559 370 233 559 minecraft:green_terracotta
setblock 370 232 562 minecraft:green_terracotta
setblock 370 232 563 minecraft:oak_log
fill 370 232 564 370 233 564 minecraft:green_terracotta
setblock 370 232 567 minecraft:green_terracotta
setblock 370 232 568 minecraft:oak_log
fill 370 232 569 370 233 569 minecraft:green_terracotta
setblock 370 232 573 minecraft:oak_log
fill 370 232 574 370 233 574 minecraft:green_terracotta
setblock 370 232 578 minecraft:oak_log
fill 370 232 579 370 233 579 minecraft:green_terracotta
setblock 370 232 583 minecraft:oak_log
fill 370 232 584 370 233 584 minecraft:green_terracotta
setblock 370 232 587 minecraft:green_terracotta
setblock 370 232 588 minecraft:oak_log
fill 370 232 589 370 233 589 minecraft:green_terracotta
fill 370 232 591 370 233 591 minecraft:green_terracotta
fill 330 233 558 330 233 561 minecraft:green_terracotta
setblock 330 233 562 minecraft:oak_log
fill 330 233 563 330 233 566 minecraft:green_terracotta
setblock 330 233 567 minecraft:oak_log
setblock 330 233 568 minecraft:green_terracotta
setblock 330 233 572 minecraft:oak_log
setblock 330 233 573 minecraft:green_terracotta
setblock 330 233 577 minecraft:oak_log
setblock 330 233 578 minecraft:green_terracotta
setblock 330 233 582 minecraft:oak_log
setblock 330 233 583 minecraft:green_terracotta
setblock 330 233 586 minecraft:green_terracotta
setblock 330 233 587 minecraft:oak_log
setblock 330 233 588 minecraft:green_terracotta
setblock 331 233 561 minecraft:oak_log
setblock 331 233 562 minecraft:green_terracotta
setblock 331 233 565 minecraft:green_terracotta
setblock 331 233 566 minecraft:oak_log
setblock 331 233 567 minecraft:green_terracotta
setblock 331 233 571 minecraft:oak_log
setblock 331 233 572 minecraft:green_terracotta
setblock 331 233 577 minecraft:green_terracotta
setblock 331 233 581 minecraft:oak_log
setblock 331 233 582 minecraft:green_terracotta
setblock 331 233 586 minecraft:oak_log
setblock 331 233 587 minecraft:green_terracotta
setblock 331 233 598 minecraft:oak_leaves[persistent=true]
setblock 332 233 560 minecraft:oak_log
setblock 332 233 561 minecraft:green_terracotta
setblock 332 233 564 minecraft:green_terracotta
setblock 332 233 565 minecraft:oak_log
setblock 332 233 566 minecraft:green_terracotta
setblock 332 233 570 minecraft:oak_log
setblock 332 233 576 minecraft:light[level=14]
setblock 332 233 584 minecraft:light[level=14]
setblock 332 233 592 minecraft:light[level=14]
setblock 333 233 559 minecraft:oak_log
setblock 333 233 560 minecraft:green_terracotta
setblock 333 233 564 minecraft:oak_log
fill 333 233 565 334 233 565 minecraft:green_terracotta
setblock 334 233 558 minecraft:oak_log
setblock 334 233 559 minecraft:green_terracotta
setblock 334 233 562 minecraft:green_terracotta
setblock 334 233 563 minecraft:oak_log
setblock 334 233 564 minecraft:green_terracotta
setblock 334 233 598 minecraft:oak_log
setblock 335 233 558 minecraft:green_terracotta
setblock 335 233 562 minecraft:oak_log
fill 335 233 598 338 233 598 minecraft:green_terracotta
setblock 336 233 561 minecraft:oak_log
setblock 336 233 562 minecraft:green_terracotta
setblock 337 233 560 minecraft:oak_log
setblock 337 233 561 minecraft:green_terracotta
setblock 338 233 559 minecraft:oak_log
setblock 338 233 560 minecraft:green_terracotta
setblock 338 233 562 minecraft:oak_log
setblock 339 233 558 minecraft:oak_log
setblock 339 233 559 minecraft:green_terracotta
setblock 339 233 598 minecraft:oak_log
setblock 340 233 558 minecraft:green_terracotta
setblock 340 233 568 minecraft:light[level=14]
setblock 340 233 576 minecraft:light[level=14]
setblock 340 233 584 minecraft:light[level=14]
setblock 340 233 592 minecraft:light[level=14]
setblock 340 233 598 minecraft:green_terracotta
setblock 342 233 560 minecraft:oak_log
setblock 343 233 559 minecraft:oak_log
setblock 344 233 558 minecraft:oak_log
setblock 344 233 559 minecraft:green_terracotta
setblock 344 233 598 minecraft:oak_log
setblock 345 233 558 minecraft:green_terracotta
setblock 348 233 559 minecraft:oak_log
setblock 348 233 560 minecraft:light[level=14]
setblock 348 233 568 minecraft:light[level=14]
setblock 348 233 576 minecraft:light[level=14]
setblock 348 233 584 minecraft:light[level=14]
setblock 348 233 592 minecraft:light[level=14]
setblock 349 233 558 minecraft:oak_log
setblock 349 233 559 minecraft:green_terracotta
setblock 349 233 598 minecraft:oak_log
setblock 350 233 558 minecraft:green_terracotta
setblock 350 233 598 minecraft:green_terracotta
setblock 351 233 597 minecraft:green_terracotta
setblock 352 233 560 minecraft:oak_log
setblock 353 233 559 minecraft:oak_log
setblock 353 233 560 minecraft:green_terracotta
setblock 354 233 558 minecraft:oak_log
setblock 354 233 559 minecraft:green_terracotta
setblock 354 233 598 minecraft:oak_log
setblock 355 233 558 minecraft:green_terracotta
setblock 355 233 597 minecraft:oak_log
setblock 355 233 598 minecraft:green_terracotta
setblock 356 233 568 minecraft:light[level=14]
setblock 356 233 576 minecraft:light[level=14]
setblock 356 233 584 minecraft:light[level=14]
setblock 356 233 592 minecraft:light[level=14]
setblock 356 233 597 minecraft:green_terracotta
setblock 358 233 559 minecraft:oak_log
setblock 359 233 558 minecraft:oak_log
setblock 359 233 559 minecraft:green_terracotta
setblock 359 233 598 minecraft:oak_log
setblock 360 233 558 minecraft:green_terracotta
setblock 360 233 598 minecraft:green_terracotta
setblock 364 233 560 minecraft:light[level=14]
setblock 364 233 568 minecraft:light[level=14]
setblock 364 233 576 minecraft:light[level=14]
setblock 364 233 584 minecraft:light[level=14]
setblock 364 233 592 minecraft:light[level=14]
setblock 368 233 583 minecraft:green_terracotta
setblock 368 233 584 minecraft:oak_log
setblock 368 233 585 minecraft:green_terracotta
setblock 369 233 558 minecraft:oak_leaves[persistent=true]
setblock 369 233 563 minecraft:oak_log
fill 369 233 564 369 233 566 minecraft:green_terracotta
setblock 369 233 578 minecraft:oak_log
setblock 369 233 579 minecraft:green_terracotta
setblock 369 233 583 minecraft:oak_log
setblock 369 233 584 minecraft:green_terracotta
setblock 369 233 588 minecraft:oak_log
setblock 370 233 562 minecraft:oak_log
setblock 370 233 563 minecraft:green_terracotta
setblock 370 233 567 minecraft:oak_log
setblock 370 233 568 minecraft:green_terracotta
fill 370 233 570 370 233 571 minecraft:green_terracotta
setblock 370 233 572 minecraft:oak_log
setblock 370 233 573 minecraft:green_terracotta
setblock 370 233 577 minecraft:oak_log
setblock 370 233 578 minecraft:green_terracotta
setblock 370 233 582 minecraft:oak_log
setblock 370 233 583 minecraft:green_terracotta
setblock 370 233 587 minecraft:oak_log
setblock 370 233 588 minecraft:green_terracotta
fill 329 235 559 329 238 562 minecraft:green_terracotta
setblock 329 235 563 minecraft:light_blue_concrete
fill 329 235 564 329 235 567 minecraft:green_terracotta
setblock 329 235 568 minecraft:light_blue_concrete
fill 329 235 570 329 239 570 minecraft:green_terracotta
setblock 329 235 571 minecraft:light_blue_concrete
fill 329 235 572 329 235 573 minecraft:green_terracotta
fill 329 235 586 329 237 586 minecraft:light_blue_concrete
fill 329 235 587 329 236 587 minecraft:green_terracotta
setblock 329 235 588 minecraft:light_blue_concrete
fill 345 235 557 346 235 557 minecraft:green_terracotta
setblock 347 235 557 minecraft:light_blue_concrete
fill 348 235 557 349 235 557 minecraft:green_terracotta
fill 354 235 557 355 235 557 minecraft:green_terracotta
setblock 356 235 557 minecraft:light_blue_concrete
fill 357 235 557 357 238 557 minecraft:green_terracotta
setblock 358 235 557 minecraft:light_blue_concrete
fill 359 235 557 360 236 557 minecraft:green_terracotta
setblock 361 235 557 minecraft:light_blue_concrete
setblock 361 235 599 minecraft:light_blue_concrete
fill 362 235 557 367 238 557 minecraft:green_terracotta
fill 362 235 599 363 238 599 minecraft:green_terracotta
fill 370 235 557 370 238 557 minecraft:green_terracotta
setblock 371 235 557 minecraft:light_blue_concrete
fill 371 235 559 371 236 559 minecraft:light_blue_concrete
fill 371 235 560 371 238 560 minecraft:green_terracotta
setblock 371 235 569 minecraft:light_blue_concrete
fill 371 235 570 371 236 571 minecraft:green_terracotta
fill 371 235 574 371 236 574 minecraft:light_blue_concrete
setblock 371 235 582 minecraft:light_blue_concrete
setblock 329 236 558 minecraft:light_blue_concrete
fill 329 236 563 329 236 564 minecraft:green_terracotta
setblock 329 236 565 minecraft:light_blue_concrete
fill 329 236 566 329 238 568 minecraft:green_terracotta
fill 329 236 571 329 238 571 minecraft:green_terracotta
setblock 329 236 572 minecraft:light_blue_concrete
fill 329 236 573 329 238 573 minecraft:green_terracotta
fill 329 236 579 329 236 584 minecraft:green_terracotta
setblock 329 236 585 minecraft:light_blue_concrete
fill 329 236 588 329 238 588 minecraft:green_terracotta
setblock 329 236 599 minecraft:light_blue_concrete
fill 330 236 557 333 238 557 minecraft:green_terracotta
setblock 334 236 557 minecraft:light_blue_concrete
fill 335 236 557 335 238 557 minecraft:green_terracotta
setblock 336 236 557 minecraft:light_blue_concrete
fill 338 236 557 338 237 557 minecraft:light_blue_concrete
fill 340 236 599 340 237 599 minecraft:light_blue_concrete
fill 342 236 599 344 236 599 minecraft:green_terracotta
setblock 345 236 557 minecraft:green_terracotta
setblock 345 236 599 minecraft:light_blue_concrete
setblock 346 236 557 minecraft:light_blue_concrete
fill 346 236 599 348 238 599 minecraft:green_terracotta
fill 347 236 557 348 238 557 minecraft:green_terracotta
setblock 349 236 557 minecraft:light_blue_concrete
fill 350 236 557 350 238 557 minecraft:green_terracotta
setblock 350 236 599 minecraft:light_blue_concrete
setblock 351 236 557 minecraft:light_blue_concrete
fill 351 236 599 359 236 599 minecraft:green_terracotta
fill 354 236 557 354 238 557 minecraft:green_terracotta
setblock 355 236 557 minecraft:light_blue_concrete
fill 356 236 557 356 238 557 minecraft:green_terracotta
fill 358 236 557 358 238 557 minecraft:green_terracotta
fill 361 236 557 361 238 557 minecraft:green_terracotta
fill 361 236 599 361 238 599 minecraft:green_terracotta
setblock 371 236 557 minecraft:green_terracotta
fill 371 236 562 371 238 563 minecraft:green_terracotta
fill 371 236 564 371 236 565 minecraft:light_blue_concrete
fill 371 236 569 371 238 569 minecraft:green_terracotta
fill 371 236 582 371 238 582 minecraft:green_terracotta
fill 371 236 596 371 237 596 minecraft:light_blue_concrete
fill 371 236 597 371 238 597 minecraft:green_terracotta
setblock 371 236 598 minecraft:light_blue_concrete
fill 329 237 558 329 238 558 minecraft:green_terracotta
fill 329 237 563 329 238 563 minecraft:green_terracotta
setblock 329 237 564 minecraft:light_blue_concrete
fill 329 237 565 329 238 565 minecraft:green_terracotta
setblock 329 237 569 minecraft:light_blue_concrete
fill 329 237 572 329 238 572 minecraft:green_terracotta
setblock 329 237 574 minecraft:light_blue_concrete
fill 329 237 575 329 238 575 minecraft:green_terracotta
fill 329 237 576 329 237 577 minecraft:light_blue_concrete
fill 329 237 579 329 238 583 minecraft:green_terracotta
setblock 329 237 584 minecraft:light_blue_concrete
fill 329 237 585 329 238 585 minecraft:green_terracotta
setblock 329 237 587 minecraft:light_blue_concrete
fill 329 237 592 329 237 593 minecraft:light_blue_concrete
fill 329 237 594 329 238 595 minecraft:green_terracotta
setblock 329 237 596 minecraft:light_blue_concrete
fill 329 237 597 329 238 597 minecraft:green_terracotta
setblock 329 237 598 minecraft:light_blue_concrete
fill 329 237 599 329 238 599 minecraft:green_terracotta
fill 333 237 599 337 238 599 minecraft:green_terracotta
fill 334 237 557 334 238 557 minecraft:green_terracotta
fill 336 237 557 336 238 557 minecraft:green_terracotta
setblock 338 237 599 minecraft:light_blue_concrete
setblock 339 237 557 minecraft:light_blue_concrete
fill 339 237 599 339 238 599 minecraft:green_terracotta
setblock 342 237 599 minecraft:light_blue_concrete
fill 343 237 599 343 239 599 minecraft:green_terracotta
setblock 344 237 599 minecraft:light_blue_concrete
setblock 345 237 557 minecraft:light_blue_concrete
fill 345 237 599 345 238 599 minecraft:green_terracotta
fill 346 237 557 346 238 557 minecraft:green_terracotta
fill 349 237 557 349 239 557 minecraft:green_terracotta
fill 350 237 599 355 238 599 minecraft:green_terracotta
fill 351 237 557 351 238 557 minecraft:green_terracotta
fill 355 237 557 355 238 557 minecraft:green_terracotta
setblock 356 237 599 minecraft:light_blue_concrete
fill 357 237 599 359 238 599 minecraft:green_terracotta
setblock 359 237 557 minecraft:light_blue_concrete
fill 360 237 557 360 238 557 minecraft:green_terracotta
setblock 369 237 557 minecraft:light_blue_concrete
setblock 371 237 557 minecraft:light_blue_concrete
fill 371 237 559 371 238 559 minecraft:green_terracotta
fill 371 237 564 371 238 565 minecraft:green_terracotta
fill 371 237 570 371 238 570 minecraft:green_terracotta
setblock 371 237 571 minecraft:light_blue_concrete
fill 371 237 574 371 238 574 minecraft:green_terracotta
setblock 371 237 575 minecraft:light_blue_concrete
setblock 371 237 584 minecraft:light_blue_concrete
setblock 371 237 591 minecraft:light_blue_concrete
fill 371 237 598 371 238 598 minecraft:green_terracotta
setblock 329 238 564 minecraft:green_terracotta
setblock 329 238 569 minecraft:green_terracotta
setblock 329 238 574 minecraft:green_terracotta
fill 329 238 576 329 238 577 minecraft:green_terracotta
setblock 329 238 584 minecraft:green_terracotta
fill 329 238 586 329 238 587 minecraft:green_terracotta
fill 329 238 592 329 238 593 minecraft:green_terracotta
setblock 329 238 596 minecraft:green_terracotta
setblock 329 238 598 minecraft:green_terracotta
fill 338 238 557 339 238 557 minecraft:green_terracotta
setblock 338 238 599 minecraft:green_terracotta
setblock 340 238 599 minecraft:green_terracotta
setblock 342 238 599 minecraft:green_terracotta
setblock 344 238 599 minecraft:green_terracotta
setblock 345 238 557 minecraft:green_terracotta
fill 347 238 573 349 238 575 minecraft:redstone_block
fill 348 238 580 350 238 582 minecraft:redstone_block
fill 354 238 572 356 238 574 minecraft:redstone_block
fill 355 238 579 357 238 581 minecraft:redstone_block
fill 356 238 599 356 239 599 minecraft:green_terracotta
setblock 359 238 557 minecraft:green_terracotta
setblock 369 238 557 minecraft:green_terracotta
setblock 371 238 557 minecraft:green_terracotta
setblock 371 238 571 minecraft:green_terracotta
setblock 371 238 575 minecraft:green_terracotta
setblock 371 238 584 minecraft:green_terracotta
setblock 371 238 591 minecraft:green_terracotta
setblock 371 238 596 minecraft:green_terracotta
fill 329 239 557 329 240 565 minecraft:light_blue_concrete
setblock 329 239 566 minecraft:green_terracotta
fill 329 239 567 329 307 569 minecraft:light_blue_concrete
fill 329 239 571 329 239 585 minecraft:light_blue_concrete
setblock 329 239 586 minecraft:green_terracotta
fill 329 239 587 329 239 594 minecraft:light_blue_concrete
setblock 329 239 595 minecraft:green_terracotta
fill 329 239 596 329 307 599 minecraft:light_blue_concrete
fill 330 239 557 337 240 557 minecraft:light_blue_concrete
fill 330 239 599 332 307 599 minecraft:light_blue_concrete
fill 333 239 574 346 239 580 minecraft:oak_log
setblock 333 239 599 minecraft:green_terracotta
fill 334 239 599 340 239 599 minecraft:light_blue_concrete
setblock 338 239 557 minecraft:green_terracotta
fill 339 239 557 342 239 557 minecraft:light_blue_concrete
fill 342 239 599 342 307 599 minecraft:light_blue_concrete
setblock 343 239 557 minecraft:green_terracotta
fill 344 239 557 348 307 557 minecraft:light_blue_concrete
fill 344 239 599 355 239 599 minecraft:light_blue_concrete
fill 347 239 576 347 239 580 minecraft:oak_log
fill 348 239 576 350 239 579 minecraft:oak_log
fill 349 239 558 353 239 572 minecraft:oak_log
fill 349 239 583 355 239 596 minecraft:oak_log
fill 350 239 557 363 239 557 minecraft:light_blue_concrete
fill 350 239 573 353 239 575 minecraft:oak_log
fill 351 239 579 354 239 582 minecraft:oak_log
fill 354 239 558 355 239 571 minecraft:oak_log
fill 354 239 575 371 239 578 minecraft:oak_log
setblock 355 239 582 minecraft:oak_log
fill 357 239 574 371 239 574 minecraft:oak_log
fill 357 239 599 358 307 599 minecraft:light_blue_concrete
fill 358 239 579 371 239 580 minecraft:oak_log
setblock 359 239 599 minecraft:green_terracotta
fill 360 239 599 361 239 599 minecraft:light_blue_concrete
setblock 362 239 599 minecraft:green_terracotta
fill 363 239 599 371 239 599 minecraft:light_blue_concrete
setblock 364 239 557 minecraft:green_terracotta
fill 365 239 557 371 307 557 minecraft:light_blue_concrete
fill 371 239 558 371 239 564 minecraft:light_blue_concrete
setblock 371 239 565 minecraft:green_terracotta
fill 371 239 567 371 239 573 minecraft:light_blue_concrete
fill 371 239 581 371 239 598 minecraft:light_blue_concrete
fill 329 240 566 329 307 566 minecraft:light_blue_concrete
fill 329 240 570 329 307 573 minecraft:light_blue_concrete
setblock 329 240 574 minecraft:green_terracotta
fill 329 240 575 329 307 579 minecraft:light_blue_concrete
fill 329 240 580 329 240 581 minecraft:green_terracotta
fill 329 240 582 329 307 584 minecraft:light_blue_concrete
setblock 329 240 585 minecraft:green_terracotta
fill 329 240 586 329 307 590 minecraft:light_blue_concrete
setblock 329 240 591 minecraft:green_terracotta
fill 329 240 592 329 240 595 minecraft:light_blue_concrete
fill 330 240 558 332 240 598 minecraft:jungle_leaves[persistent=true]
fill 333 240 558 345 240 573 minecraft:jungle_leaves[persistent=true]
fill 333 240 574 345 240 574 minecraft:moss_block
fill 333 240 575 345 240 579 minecraft:oak_log
fill 333 240 580 346 240 580 minecraft:moss_block
fill 333 240 581 346 240 598 minecraft:jungle_leaves[persistent=true]
fill 333 240 599 335 307 599 minecraft:light_blue_concrete
setblock 336 240 599 minecraft:green_terracotta
fill 337 240 599 337 307 599 minecraft:light_blue_concrete
fill 338 240 557 338 307 557 minecraft:light_blue_concrete
fill 338 240 599 338 241 599 minecraft:green_terracotta
setblock 339 240 557 minecraft:green_terracotta
fill 339 240 599 341 307 599 minecraft:light_blue_concrete
fill 340 240 557 343 307 557 minecraft:light_blue_concrete
fill 343 240 599 347 307 599 minecraft:light_blue_concrete
fill 346 240 558 348 240 571 minecraft:jungle_leaves[persistent=true]
fill 346 240 572 346 240 576 minecraft:ochre_froglight
fill 346 240 577 346 240 579 minecraft:oak_log
fill 347 240 572 350 240 572 minecraft:ochre_froglight
fill 347 240 573 349 240 575 minecraft:jungle_leaves[persistent=true]
fill 347 240 576 350 240 576 minecraft:ochre_froglight
fill 347 240 577 348 240 578 minecraft:oak_log
fill 347 240 579 347 240 583 minecraft:ochre_froglight
fill 347 240 584 348 240 598 minecraft:jungle_leaves[persistent=true]
fill 348 240 579 354 240 579 minecraft:ochre_froglight
fill 348 240 580 350 240 582 minecraft:jungle_leaves[persistent=true]
fill 348 240 583 351 240 583 minecraft:ochre_froglight
setblock 348 240 599 minecraft:green_terracotta
fill 349 240 557 361 240 557 minecraft:light_blue_concrete
fill 349 240 558 349 240 571 minecraft:moss_block
fill 349 240 577 349 240 578 minecraft:moss_block
fill 349 240 584 349 240 596 minecraft:moss_block
fill 349 240 597 370 240 598 minecraft:jungle_leaves[persistent=true]
fill 349 240 599 356 240 599 minecraft:light_blue_concrete
fill 350 240 558 352 240 571 minecraft:oak_log
fill 350 240 573 350 240 575 minecraft:ochre_froglight
fill 350 240 577 350 240 578 minecraft:ochre_froglight
fill 350 240 584 354 240 596 minecraft:oak_log
fill 351 240 572 352 240 573 minecraft:oak_log
fill 351 240 574 352 240 574 minecraft:moss_block
fill 351 240 575 357 240 575 minecraft:ochre_froglight
fill 351 240 580 351 240 582 minecraft:ochre_froglight
fill 352 240 580 353 240 580 minecraft:moss_block
fill 352 240 581 353 240 583 minecraft:oak_log
fill 353 240 558 354 240 570 minecraft:oak_log
fill 353 240 571 353 240 574 minecraft:ochre_froglight
fill 354 240 571 357 240 571 minecraft:ochre_froglight
fill 354 240 572 356 240 574 minecraft:jungle_leaves[persistent=true]
fill 354 240 576 354 240 578 minecraft:ochre_froglight
fill 354 240 580 354 240 582 minecraft:ochre_froglight
setblock 354 240 583 minecraft:oak_log
fill 355 240 558 355 240 570 minecraft:moss_block
fill 355 240 576 355 240 577 minecraft:moss_block
fill 355 240 578 358 240 578 minecraft:ochre_froglight
fill 355 240 579 357 240 581 minecraft:jungle_leaves[persistent=true]
fill 355 240 582 358 240 582 minecraft:ochre_froglight
fill 355 240 583 355 240 596 minecraft:moss_block
fill 356 240 558 370 240 570 minecraft:jungle_leaves[persistent=true]
fill 356 240 576 371 240 577 minecraft:oak_log
fill 356 240 583 370 240 596 minecraft:jungle_leaves[persistent=true]
fill 357 240 572 357 240 574 minecraft:ochre_froglight
fill 358 240 571 370 240 573 minecraft:jungle_leaves[persistent=true]
fill 358 240 574 371 240 574 minecraft:moss_block
fill 358 240 575 371 240 575 minecraft:oak_log
fill 358 240 579 358 240 581 minecraft:ochre_froglight
fill 359 240 578 371 240 579 minecraft:oak_log
fill 359 240 580 371 240 580 minecraft:moss_block
fill 359 240 581 370 240 582 minecraft:jungle_leaves[persistent=true]
setblock 359 240 599 minecraft:light_blue_concrete
fill 360 240 599 361 240 599 minecraft:green_terracotta
setblock 362 240 557 minecraft:green_terracotta
fill 362 240 599 364 307 599 minecraft:light_blue_concrete
fill 363 240 557 364 307 557 minecraft:light_blue_concrete
fill 365 240 599 366 240 599 minecraft:green_terracotta
fill 367 240 599 371 307 599 minecraft:light_blue_concrete
fill 371 240 558 371 307 558 minecraft:light_blue_concrete
setblock 371 240 559 minecraft:green_terracotta
fill 371 240 560 371 240 571 minecraft:light_blue_concrete
setblock 371 240 572 minecraft:green_terracotta
fill 371 240 573 371 307 573 minecraft:light_blue_concrete
fill 371 240 581 371 307 582 minecraft:light_blue_concrete
fill 371 240 583 371 241 583 minecraft:green_terracotta
fill 371 240 584 371 307 586 minecraft:light_blue_concrete
setblock 371 240 587 minecraft:green_terracotta
fill 371 240 588 371 307 588 minecraft:light_blue_concrete
setblock 371 240 589 minecraft:green_terracotta
fill 371 240 590 371 240 598 minecraft:light_blue_concrete
fill 329 241 557 329 307 559 minecraft:light_blue_concrete
setblock 329 241 560 minecraft:green_terracotta
fill 329 241 561 329 307 565 minecraft:light_blue_concrete
fill 329 241 574 329 307 574 minecraft:light_blue_concrete
setblock 329 241 580 minecraft:green_terracotta
fill 329 241 581 329 307 581 minecraft:light_blue_concrete
fill 329 241 585 329 307 585 minecraft:light_blue_concrete
fill 329 241 591 329 307 593 minecraft:light_blue_concrete
setblock 329 241 594 minecraft:green_terracotta
fill 329 241 595 329 307 595 minecraft:light_blue_concrete
fill 330 241 557 335 307 557 minecraft:light_blue_concrete
setblock 332 241 560 minecraft:light[level=14]
setblock 332 241 568 minecraft:light[level=14]
setblock 332 241 576 minecraft:light[level=14]
setblock 332 241 584 minecraft:light[level=14]
setblock 332 241 592 minecraft:light[level=14]
setblock 336 241 557 minecraft:green_terracotta
fill 336 241 599 336 307 599 minecraft:light_blue_concrete
fill 337 241 557 337 307 557 minecraft:light_blue_concrete
fill 339 241 557 339 307 557 minecraft:light_blue_concrete
setblock 340 241 560 minecraft:light[level=14]
setblock 340 241 568 minecraft:light[level=14]
setblock 340 241 576 minecraft:light[level=14]
setblock 340 241 584 minecraft:light[level=14]
setblock 340 241 592 minecraft:light[level=14]
setblock 348 241 560 minecraft:light[level=14]
setblock 348 241 568 minecraft:light[level=14]
setblock 348 241 576 minecraft:light[level=14]
setblock 348 241 584 minecraft:light[level=14]
setblock 348 241 592 minecraft:light[level=14]
fill 348 241 599 352 307 599 minecraft:light_blue_concrete
fill 349 241 557 352 307 557 minecraft:light_blue_concrete
setblock 353 241 557 minecraft:green_terracotta
setblock 353 241 599 minecraft:green_terracotta
fill 354 241 557 362 307 557 minecraft:light_blue_concrete
fill 354 241 599 355 307 599 minecraft:light_blue_concrete
setblock 356 241 560 minecraft:light[level=14]
setblock 356 241 568 minecraft:light[level=14]
setblock 356 241 576 minecraft:light[level=14]
setblock 356 241 584 minecraft:light[level=14]
setblock 356 241 592 minecraft:light[level=14]
setblock 356 241 599 minecraft:green_terracotta
fill 359 241 599 360 241 599 minecraft:green_terracotta
fill 361 241 599 361 307 599 minecraft:light_blue_concrete
setblock 364 241 560 minecraft:light[level=14]
setblock 364 241 568 minecraft:light[level=14]
setblock 364 241 576 minecraft:light[level=14]
setblock 364 241 584 minecraft:light[level=14]
setblock 364 241 592 minecraft:light[level=14]
fill 365 241 599 366 307 599 minecraft:light_blue_concrete
fill 371 241 559 371 307 566 minecraft:light_blue_concrete
setblock 371 241 567 minecraft:green_terracotta
fill 371 241 568 371 307 572 minecraft:light_blue_concrete
setblock 371 241 574 minecraft:green_terracotta
fill 371 241 575 371 307 577 minecraft:light_blue_concrete
setblock 371 241 578 minecraft:green_terracotta
fill 371 241 579 371 307 580 minecraft:light_blue_concrete
fill 371 241 587 371 307 587 minecraft:light_blue_concrete
fill 371 241 589 371 307 590 minecraft:light_blue_concrete
setblock 371 241 591 minecraft:green_terracotta
fill 371 241 592 371 307 598 minecraft:light_blue_concrete
fill 329 242 560 329 307 560 minecraft:light_blue_concrete
fill 329 242 580 329 307 580 minecraft:light_blue_concrete
fill 329 242 594 329 307 594 minecraft:light_blue_concrete
fill 336 242 557 336 307 557 minecraft:light_blue_concrete
fill 338 242 599 338 307 599 minecraft:light_blue_concrete
fill 353 242 557 353 307 557 minecraft:light_blue_concrete
fill 353 242 599 353 307 599 minecraft:light_blue_concrete
fill 356 242 599 356 307 599 minecraft:light_blue_concrete
fill 359 242 599 360 307 599 minecraft:light_blue_concrete
fill 371 242 567 371 307 567 minecraft:light_blue_concrete
fill 371 242 574 371 307 574 minecraft:light_blue_concrete
fill 371 242 578 371 307 578 minecraft:light_blue_concrete
fill 371 242 583 371 307 583 minecraft:light_blue_concrete
fill 371 242 591 371 307 591 minecraft:light_blue_concrete
fill 330 244 558 330 244 560 minecraft:green_terracotta
setblock 330 244 561 minecraft:oak_log
fill 330 244 562 330 244 565 minecraft:green_terracotta
setblock 330 244 566 minecraft:oak_log
fill 330 244 567 330 244 570 minecraft:green_terracotta
setblock 330 244 571 minecraft:oak_log
fill 330 244 572 330 244 575 minecraft:green_terracotta
setblock 330 244 576 minecraft:oak_log
fill 330 244 577 330 244 580 minecraft:green_terracotta
setblock 330 244 581 minecraft:oak_log
fill 330 244 582 330 244 585 minecraft:green_terracotta
setblock 330 244 586 minecraft:oak_log
fill 330 244 587 330 244 590 minecraft:green_terracotta
setblock 330 244 591 minecraft:oak_log
fill 330 244 592 330 244 595 minecraft:green_terracotta
setblock 330 244 596 minecraft:oak_log
fill 330 244 597 332 244 598 minecraft:green_terracotta
fill 331 244 558 331 244 559 minecraft:green_terracotta
setblock 331 244 560 minecraft:oak_log
fill 331 244 561 331 244 564 minecraft:green_terracotta
setblock 331 244 565 minecraft:oak_log
fill 331 244 566 331 244 569 minecraft:green_terracotta
setblock 331 244 570 minecraft:oak_log
fill 331 244 571 331 244 574 minecraft:green_terracotta
setblock 331 244 575 minecraft:oak_log
fill 331 244 576 331 246 577 minecraft:green_terracotta
fill 331 244 588 331 244 589 minecraft:green_terracotta
setblock 331 244 590 minecraft:oak_log
fill 331 244 591 331 244 594 minecraft:green_terracotta
setblock 331 244 595 minecraft:oak_log
fill 331 244 596 334 244 596 minecraft:green_terracotta
setblock 332 244 558 minecraft:green_terracotta
setblock 332 244 559 minecraft:oak_log
setblock 332 244 563 minecraft:green_terracotta
setblock 332 244 564 minecraft:oak_log
fill 332 244 565 332 244 568 minecraft:green_terracotta
setblock 332 244 569 minecraft:oak_log
fill 332 244 570 332 244 573 minecraft:green_terracotta
setblock 332 244 574 minecraft:oak_log
fill 332 244 591 332 244 593 minecraft:green_terracotta
setblock 332 244 594 minecraft:oak_log
fill 332 244 595 332 247 595 minecraft:green_terracotta
setblock 333 244 558 minecraft:oak_log
fill 333 244 559 334 246 559 minecraft:green_terracotta
setblock 333 244 597 minecraft:green_terracotta
setblock 333 244 598 minecraft:oak_log
fill 334 244 558 337 244 558 minecraft:green_terracotta
setblock 334 244 597 minecraft:oak_log
fill 334 244 598 337 244 598 minecraft:green_terracotta
fill 335 244 564 335 248 564 minecraft:iron_block
fill 335 244 597 338 244 597 minecraft:green_terracotta
setblock 338 244 558 minecraft:oak_log
setblock 338 244 598 minecraft:oak_log
setblock 339 244 597 minecraft:oak_log
fill 339 244 598 342 244 598 minecraft:green_terracotta
fill 340 244 597 343 244 597 minecraft:green_terracotta
setblock 341 244 558 minecraft:oak_leaves[persistent=true]
fill 343 244 596 344 244 596 minecraft:green_terracotta
setblock 343 244 598 minecraft:oak_log
fill 344 244 558 347 244 558 minecraft:green_terracotta
setblock 344 244 597 minecraft:oak_log
fill 344 244 598 347 244 598 minecraft:green_terracotta
setblock 345 244 595 minecraft:green_terracotta
setblock 345 244 596 minecraft:oak_log
fill 345 244 597 348 244 597 minecraft:green_terracotta
setblock 346 244 595 minecraft:oak_log
fill 346 244 596 349 244 596 minecraft:green_terracotta
fill 347 244 595 350 244 595 minecraft:green_terracotta
setblock 348 244 558 minecraft:oak_log
fill 348 244 594 350 245 594 minecraft:green_terracotta
setblock 348 244 598 minecraft:oak_log
fill 349 244 558 352 244 558 minecraft:green_terracotta
setblock 349 244 597 minecraft:oak_log
fill 349 244 598 352 244 598 minecraft:green_terracotta
setblock 350 244 596 minecraft:oak_log
fill 350 244 597 353 244 597 minecraft:green_terracotta
setblock 351 244 595 minecraft:oak_log
fill 351 244 596 354 244 596 minecraft:green_terracotta
fill 352 244 595 352 246 595 minecraft:green_terracotta
setblock 353 244 598 minecraft:oak_log
setblock 354 244 597 minecraft:oak_log
fill 354 244 598 356 245 598 minecraft:green_terracotta
fill 355 244 597 355 247 597 minecraft:green_terracotta
fill 356 244 593 358 247 594 minecraft:dark_oak_log
fill 357 244 592 358 247 592 minecraft:dark_oak_log
setblock 366 244 558 minecraft:oak_leaves[persistent=true]
fill 366 244 598 367 244 598 minecraft:green_terracotta
setblock 367 244 558 minecraft:green_terracotta
setblock 367 244 568 minecraft:green_terracotta
setblock 367 244 569 minecraft:oak_log
fill 367 244 570 367 244 573 minecraft:green_terracotta
setblock 367 244 574 minecraft:oak_log
fill 367 244 575 370 244 575 minecraft:green_terracotta
setblock 368 244 558 minecraft:oak_log
fill 368 244 564 368 244 567 minecraft:green_terracotta
setblock 368 244 568 minecraft:oak_log
fill 368 244 569 368 244 572 minecraft:green_terracotta
setblock 368 244 573 minecraft:oak_log
fill 368 244 574 370 245 574 minecraft:green_terracotta
fill 368 244 576 368 244 577 minecraft:green_terracotta
setblock 368 244 578 minecraft:oak_log
fill 368 244 591 368 244 592 minecraft:green_terracotta
setblock 368 244 593 minecraft:oak_log
setblock 368 244 597 minecraft:green_terracotta
setblock 368 244 598 minecraft:oak_log
fill 369 244 558 369 244 561 minecraft:green_terracotta
setblock 369 244 562 minecraft:oak_log
fill 369 244 563 369 244 566 minecraft:green_terracotta
setblock 369 244 567 minecraft:oak_log
fill 369 244 568 369 244 571 minecraft:green_terracotta
setblock 369 244 572 minecraft:oak_log
fill 369 244 573 370 246 573 minecraft:green_terracotta
setblock 369 244 576 minecraft:green_terracotta
setblock 369 244 577 minecraft:oak_log
fill 369 244 578 369 244 581 minecraft:green_terracotta
setblock 369 244 582 minecraft:oak_log
fill 369 244 583 369 244 586 minecraft:green_terracotta
setblock 369 244 587 minecraft:oak_log
fill 369 244 588 369 244 591 minecraft:green_terracotta
setblock 369 244 592 minecraft:oak_log
fill 369 244 593 369 244 596 minecraft:green_terracotta
setblock 369 244 597 minecraft:oak_log
fill 369 244 598 370 246 598 minecraft:green_terracotta
fill 370 244 558 370 244 560 minecraft:green_terracotta
setblock 370 244 561 minecraft:oak_log
fill 370 244 562 370 244 565 minecraft:green_terracotta
setblock 370 244 566 minecraft:oak_log
fill 370 244 567 370 244 570 minecraft:green_terracotta
setblock 370 244 571 minecraft:oak_log
fill 370 244 572 370 247 572 minecraft:green_terracotta
setblock 370 244 576 minecraft:oak_log
fill 370 244 577 370 244 580 minecraft:green_terracotta
setblock 370 244 581 minecraft:oak_log
fill 370 244 582 370 244 585 minecraft:green_terracotta
setblock 370 244 586 minecraft:oak_log
fill 370 244 587 370 244 590 minecraft:green_terracotta
setblock 370 244 591 minecraft:oak_log
fill 370 244 592 370 244 595 minecraft:green_terracotta
setblock 370 244 596 minecraft:oak_log
fill 370 244 597 370 247 597 minecraft:green_terracotta
fill 330 245 558 330 245 559 minecraft:green_terracotta
setblock 330 245 560 minecraft:oak_log
fill 330 245 561 330 245 564 minecraft:green_terracotta
setblock 330 245 565 minecraft:oak_log
fill 330 245 566 330 245 569 minecraft:green_terracotta
setblock 330 245 570 minecraft:oak_log
fill 330 245 571 330 245 574 minecraft:green_terracotta
setblock 330 245 575 minecraft:oak_log
fill 330 245 576 330 245 579 minecraft:green_terracotta
setblock 330 245 580 minecraft:oak_log
fill 330 245 581 330 246 582 minecraft:green_terracotta
setblock 330 245 583 minecraft:oak_leaves[persistent=true]
setblock 330 245 584 minecraft:green_terracotta
setblock 330 245 585 minecraft:oak_log
fill 330 245 586 330 245 589 minecraft:green_terracotta
setblock 330 245 590 minecraft:oak_log
fill 330 245 591 330 245 594 minecraft:green_terracotta
setblock 330 245 595 minecraft:oak_log
fill 330 245 596 331 245 598 minecraft:green_terracotta
setblock 331 245 558 minecraft:green_terracotta
setblock 331 245 559 minecraft:oak_log
fill 331 245 560 331 245 563 minecraft:green_terracotta
setblock 331 245 564 minecraft:oak_log
fill 331 245 565 331 245 568 minecraft:green_terracotta
setblock 331 245 569 minecraft:oak_log
fill 331 245 570 331 245 573 minecraft:green_terracotta
setblock 331 245 574 minecraft:oak_log
fill 331 245 575 331 248 575 minecraft:green_terracotta
setblock 331 245 588 minecraft:green_terracotta
setblock 331 245 589 minecraft:oak_log
fill 331 245 590 331 245 593 minecraft:green_terracotta
setblock 331 245 594 minecraft:oak_log
fill 331 245 595 331 248 595 minecraft:green_terracotta
setblock 332 245 558 minecraft:oak_log
fill 332 245 559 332 248 559 minecraft:green_terracotta
fill 332 245 565 332 245 567 minecraft:green_terracotta
setblock 332 245 568 minecraft:oak_log
fill 332 245 569 332 245 572 minecraft:green_terracotta
setblock 332 245 573 minecraft:oak_log
fill 332 245 574 332 246 574 minecraft:green_terracotta
fill 332 245 591 332 245 592 minecraft:green_terracotta
setblock 332 245 593 minecraft:oak_log
fill 332 245 594 332 248 594 minecraft:green_terracotta
fill 332 245 596 332 245 597 minecraft:green_terracotta
setblock 332 245 598 minecraft:oak_log
fill 333 245 558 336 245 558 minecraft:green_terracotta
setblock 333 245 596 minecraft:green_terracotta
setblock 333 245 597 minecraft:oak_log
fill 333 245 598 336 245 598 minecraft:green_terracotta
setblock 334 245 596 minecraft:oak_log
fill 334 245 597 337 245 597 minecraft:green_terracotta
fill 335 245 596 335 247 596 minecraft:green_terracotta
setblock 337 245 558 minecraft:oak_log
setblock 337 245 598 minecraft:oak_log
fill 338 245 558 341 245 558 minecraft:green_terracotta
setblock 338 245 597 minecraft:oak_log
fill 338 245 598 341 245 598 minecraft:green_terracotta
fill 339 245 597 342 245 597 minecraft:green_terracotta
fill 341 245 596 343 245 596 minecraft:green_terracotta
setblock 342 245 558 minecraft:oak_log
setblock 342 245 598 minecraft:oak_log
fill 343 245 558 346 245 558 minecraft:green_terracotta
setblock 343 245 597 minecraft:oak_log
fill 343 245 598 346 245 598 minecraft:green_terracotta
setblock 344 245 595 minecraft:green_terracotta
setblock 344 245 596 minecraft:oak_log
fill 344 245 597 347 245 597 minecraft:green_terracotta
setblock 345 245 595 minecraft:oak_log
fill 345 245 596 348 245 596 minecraft:green_terracotta
fill 346 245 595 349 245 595 minecraft:green_terracotta
setblock 347 245 558 minecraft:oak_log
fill 347 245 594 347 247 594 minecraft:green_terracotta
setblock 347 245 598 minecraft:oak_log
fill 348 245 558 351 245 558 minecraft:green_terracotta
setblock 348 245 597 minecraft:oak_log
fill 348 245 598 351 245 598 minecraft:green_terracotta
setblock 349 245 596 minecraft:oak_log
fill 349 245 597 352 245 597 minecraft:green_terracotta
setblock 350 245 595 minecraft:oak_log
fill 350 245 596 353 245 596 minecraft:green_terracotta
fill 351 245 595 351 247 595 minecraft:green_terracotta
setblock 352 245 558 minecraft:oak_log
setblock 352 245 598 minecraft:oak_log
setblock 353 245 597 minecraft:oak_log
fill 353 245 598 353 248 598 minecraft:green_terracotta
setblock 354 245 596 minecraft:oak_log
fill 354 245 597 354 248 597 minecraft:green_terracotta
fill 356 245 592 356 247 592 minecraft:dark_oak_log
fill 356 245 595 358 247 595 minecraft:dark_oak_log
setblock 357 245 598 minecraft:oak_log
fill 359 245 593 359 247 594 minecraft:dark_oak_log
setblock 359 245 598 minecraft:oak_leaves[persistent=true]
setblock 360 245 558 minecraft:oak_leaves[persistent=true]
fill 364 245 598 366 245 598 minecraft:green_terracotta
fill 365 245 558 366 245 558 minecraft:green_terracotta
fill 366 245 597 367 245 597 minecraft:green_terracotta
setblock 367 245 558 minecraft:oak_log
setblock 367 245 567 minecraft:green_terracotta
setblock 367 245 568 minecraft:oak_log
fill 367 245 569 367 245 572 minecraft:green_terracotta
setblock 367 245 573 minecraft:oak_log
fill 367 245 574 367 246 576 minecraft:green_terracotta
setblock 367 245 598 minecraft:oak_log
fill 368 245 558 370 245 559 minecraft:green_terracotta
fill 368 245 564 368 245 566 minecraft:green_terracotta
setblock 368 245 567 minecraft:oak_log
fill 368 245 568 368 245 571 minecraft:green_terracotta
setblock 368 245 572 minecraft:oak_log
fill 368 245 573 368 248 573 minecraft:green_terracotta
fill 368 245 575 368 245 576 minecraft:green_terracotta
setblock 368 245 577 minecraft:oak_log
fill 368 245 578 370 245 579 minecraft:green_terracotta
setblock 368 245 591 minecraft:green_terracotta
setblock 368 245 592 minecraft:oak_log
fill 368 245 593 369 245 595 minecraft:green_terracotta
setblock 368 245 597 minecraft:oak_log
fill 368 245 598 368 248 598 minecraft:green_terracotta
setblock 369 245 560 minecraft:green_terracotta
setblock 369 245 561 minecraft:oak_log
fill 369 245 562 369 245 565 minecraft:green_terracotta
setblock 369 245 566 minecraft:oak_log
fill 369 245 567 369 245 570 minecraft:green_terracotta
setblock 369 245 571 minecraft:oak_log
fill 369 245 572 369 248 572 minecraft:green_terracotta
setblock 369 245 575 minecraft:green_terracotta
setblock 369 245 576 minecraft:oak_log
fill 369 245 577 370 247 577 minecraft:green_terracotta
setblock 369 245 580 minecraft:green_terracotta
setblock 369 245 581 minecraft:oak_log
fill 369 245 582 370 245 583 minecraft:green_terracotta
setblock 369 245 585 minecraft:green_terracotta
setblock 369 245 586 minecraft:oak_log
fill 369 245 587 369 245 590 minecraft:green_terracotta
setblock 369 245 591 minecraft:oak_log
fill 369 245 592 370 247 592 minecraft:green_terracotta
setblock 369 245 596 minecraft:oak_log
fill 369 245 597 369 248 597 minecraft:green_terracotta
setblock 370 245 560 minecraft:oak_log
fill 370 245 561 370 245 564 minecraft:green_terracotta
setblock 370 245 565 minecraft:oak_log
fill 370 245 566 370 245 569 minecraft:green_terracotta
setblock 370 245 570 minecraft:oak_log
fill 370 245 571 370 248 571 minecraft:green_terracotta
setblock 370 245 575 minecraft:oak_log
fill 370 245 576 370 248 576 minecraft:green_terracotta
setblock 370 245 580 minecraft:oak_log
fill 370 245 581 370 248 581 minecraft:green_terracotta
setblock 370 245 584 minecraft:green_terracotta
setblock 370 245 585 minecraft:oak_log
fill 370 245 586 370 245 589 minecraft:green_terracotta
setblock 370 245 590 minecraft:oak_log
fill 370 245 591 370 248 591 minecraft:green_terracotta
fill 370 245 593 370 245 594 minecraft:green_terracotta
setblock 370 245 595 minecraft:oak_log
fill 370 245 596 370 248 596 minecraft:green_terracotta
setblock 330 246 558 minecraft:green_terracotta
setblock 330 246 559 minecraft:oak_log
fill 330 246 560 330 246 563 minecraft:green_terracotta
setblock 330 246 564 minecraft:oak_log
fill 330 246 565 330 246 568 minecraft:green_terracotta
setblock 330 246 569 minecraft:oak_log
fill 330 246 570 330 246 573 minecraft:green_terracotta
setblock 330 246 574 minecraft:oak_log
fill 330 246 575 330 246 578 minecraft:green_terracotta
setblock 330 246 579 minecraft:oak_log
fill 330 246 580 330 249 580 minecraft:green_terracotta
fill 330 246 585 330 246 588 minecraft:green_terracotta
setblock 330 246 589 minecraft:oak_log
fill 330 246 590 330 246 593 minecraft:green_terracotta
setblock 330 246 594 minecraft:oak_log
fill 330 246 595 330 246 598 minecraft:green_terracotta
setblock 331 246 558 minecraft:oak_log
fill 331 246 559 331 246 562 minecraft:green_terracotta
setblock 331 246 563 minecraft:oak_log
fill 331 246 564 331 246 567 minecraft:green_terracotta
setblock 331 246 568 minecraft:oak_log
fill 331 246 569 331 246 572 minecraft:green_terracotta
setblock 331 246 573 minecraft:oak_log
fill 331 246 574 331 249 574 minecraft:green_terracotta
fill 331 246 589 331 246 592 minecraft:green_terracotta
setblock 331 246 593 minecraft:oak_log
fill 331 246 594 331 249 594 minecraft:green_terracotta
fill 331 246 596 331 246 597 minecraft:green_terracotta
setblock 331 246 598 minecraft:oak_log
fill 332 246 558 335 246 558 minecraft:green_terracotta
setblock 332 246 567 minecraft:oak_log
fill 332 246 568 332 246 571 minecraft:green_terracotta
setblock 332 246 572 minecraft:oak_log
setblock 332 246 573 minecraft:green_terracotta
setblock 332 246 592 minecraft:oak_log
fill 332 246 593 332 247 593 minecraft:green_terracotta
setblock 332 246 596 minecraft:green_terracotta
setblock 332 246 597 minecraft:oak_log
fill 332 246 598 335 246 598 minecraft:green_terracotta
setblock 333 246 596 minecraft:oak_log
fill 333 246 597 336 246 597 minecraft:green_terracotta
fill 334 246 596 334 248 596 minecraft:green_terracotta
setblock 336 246 558 minecraft:oak_log
setblock 336 246 598 minecraft:oak_log
fill 337 246 558 340 246 558 minecraft:green_terracotta
setblock 337 246 597 minecraft:oak_log
fill 337 246 598 340 246 598 minecraft:green_terracotta
fill 338 246 597 341 246 597 minecraft:green_terracotta
fill 340 246 596 342 246 596 minecraft:green_terracotta
setblock 341 246 558 minecraft:oak_log
setblock 341 246 598 minecraft:oak_log
fill 342 246 558 345 246 558 minecraft:green_terracotta
setblock 342 246 597 minecraft:oak_log
fill 342 246 598 345 246 598 minecraft:green_terracotta
setblock 343 246 595 minecraft:green_terracotta
setblock 343 246 596 minecraft:oak_log
fill 343 246 597 346 246 597 minecraft:green_terracotta
setblock 344 246 595 minecraft:oak_log
fill 344 246 596 347 246 596 minecraft:green_terracotta
fill 345 246 595 348 246 595 minecraft:green_terracotta
setblock 346 246 558 minecraft:oak_log
fill 346 246 594 346 247 594 minecraft:green_terracotta
setblock 346 246 598 minecraft:oak_log
fill 347 246 558 350 246 558 minecraft:green_terracotta
setblock 347 246 597 minecraft:oak_log
fill 347 246 598 350 246 598 minecraft:green_terracotta
fill 348 246 594 349 246 594 minecraft:green_terracotta
setblock 348 246 596 minecraft:oak_log
fill 348 246 597 351 246 597 minecraft:green_terracotta
setblock 349 246 595 minecraft:oak_log
fill 349 246 596 352 246 596 minecraft:green_terracotta
setblock 350 246 594 minecraft:oak_log
fill 350 246 595 350 248 595 minecraft:green_terracotta
setblock 351 246 558 minecraft:oak_log
setblock 351 246 598 minecraft:oak_log
fill 352 246 558 352 247 558 minecraft:green_terracotta
setblock 352 246 597 minecraft:oak_log
fill 352 246 598 352 249 598 minecraft:green_terracotta
setblock 353 246 596 minecraft:oak_log
fill 353 246 597 353 249 597 minecraft:green_terracotta
setblock 354 246 558 minecraft:oak_leaves[persistent=true]
setblock 354 246 596 minecraft:green_terracotta
fill 354 246 598 355 246 598 minecraft:green_terracotta
fill 355 246 592 355 247 594 minecraft:dark_oak_log
fill 356 246 591 358 247 591 minecraft:dark_oak_log
setblock 356 246 598 minecraft:oak_log
fill 357 246 598 357 247 598 minecraft:green_terracotta
fill 359 246 592 359 247 592 minecraft:dark_oak_log
fill 359 246 595 359 247 595 minecraft:dark_oak_log
fill 362 246 598 365 246 598 minecraft:green_terracotta
fill 364 246 558 365 246 558 minecraft:green_terracotta
fill 365 246 597 366 246 597 minecraft:green_terracotta
setblock 366 246 558 minecraft:oak_log
setblock 366 246 572 minecraft:green_terracotta
setblock 366 246 573 minecraft:oak_log
setblock 366 246 598 minecraft:oak_log
fill 367 246 558 369 246 559 minecraft:green_terracotta
setblock 367 246 567 minecraft:oak_log
fill 367 246 568 367 246 571 minecraft:green_terracotta
setblock 367 246 572 minecraft:oak_log
fill 367 246 573 367 249 573 minecraft:green_terracotta
setblock 367 246 577 minecraft:oak_log
setblock 367 246 597 minecraft:oak_log
fill 367 246 598 367 249 598 minecraft:green_terracotta
fill 368 246 564 368 246 565 minecraft:green_terracotta
setblock 368 246 566 minecraft:oak_log
fill 368 246 567 368 246 570 minecraft:green_terracotta
setblock 368 246 571 minecraft:oak_log
fill 368 246 572 368 249 572 minecraft:green_terracotta
fill 368 246 574 368 246 575 minecraft:green_terracotta
setblock 368 246 576 minecraft:oak_log
fill 368 246 577 368 247 579 minecraft:green_terracotta
fill 368 246 592 368 246 595 minecraft:green_terracotta
setblock 368 246 596 minecraft:oak_log
fill 368 246 597 368 249 597 minecraft:green_terracotta
setblock 369 246 560 minecraft:oak_log
fill 369 246 561 369 246 564 minecraft:green_terracotta
setblock 369 246 565 minecraft:oak_log
fill 369 246 566 369 246 569 minecraft:green_terracotta
setblock 369 246 570 minecraft:oak_log
fill 369 246 571 369 249 571 minecraft:green_terracotta
setblock 369 246 574 minecraft:green_terracotta
setblock 369 246 575 minecraft:oak_log
fill 369 246 576 369 249 576 minecraft:green_terracotta
fill 369 246 578 369 246 579 minecraft:green_terracotta
setblock 369 246 580 minecraft:oak_log
fill 369 246 581 369 247 582 minecraft:green_terracotta
fill 369 246 587 369 246 589 minecraft:green_terracotta
setblock 369 246 590 minecraft:oak_log
fill 369 246 591 369 248 591 minecraft:green_terracotta
fill 369 246 593 369 246 594 minecraft:green_terracotta
setblock 369 246 595 minecraft:oak_log
fill 369 246 596 369 249 596 minecraft:green_terracotta
setblock 370 246 558 minecraft:green_terracotta
setblock 370 246 559 minecraft:oak_log
fill 370 246 560 370 246 563 minecraft:green_terracotta
setblock 370 246 564 minecraft:oak_log
fill 370 246 565 370 246 568 minecraft:green_terracotta
setblock 370 246 569 minecraft:oak_log
fill 370 246 570 370 249 570 minecraft:green_terracotta
setblock 370 246 574 minecraft:oak_log
fill 370 246 575 370 249 575 minecraft:green_terracotta
setblock 370 246 578 minecraft:green_terracotta
setblock 370 246 579 minecraft:oak_log
fill 370 246 580 370 249 580 minecraft:green_terracotta
fill 370 246 582 370 246 583 minecraft:green_terracotta
setblock 370 246 584 minecraft:oak_log
fill 370 246 585 370 246 588 minecraft:green_terracotta
setblock 370 246 589 minecraft:oak_log
fill 370 246 590 370 249 590 minecraft:green_terracotta
setblock 370 246 593 minecraft:green_terracotta
setblock 370 246 594 minecraft:oak_log
fill 370 246 595 370 249 595 minecraft:green_terracotta
setblock 330 247 558 minecraft:oak_log
fill 330 247 559 330 247 562 minecraft:green_terracotta
setblock 330 247 563 minecraft:oak_log
fill 330 247 564 330 247 567 minecraft:green_terracotta
setblock 330 247 568 minecraft:oak_log
fill 330 247 569 330 247 572 minecraft:green_terracotta
setblock 330 247 573 minecraft:oak_log
fill 330 247 574 330 247 577 minecraft:green_terracotta
setblock 330 247 578 minecraft:oak_log
fill 330 247 579 330 250 579 minecraft:green_terracotta
fill 330 247 581 330 248 581 minecraft:green_terracotta
setblock 330 247 587 minecraft:green_terracotta
setblock 330 247 588 minecraft:oak_log
fill 330 247 589 330 247 592 minecraft:green_terracotta
setblock 330 247 593 minecraft:oak_log
fill 330 247 594 330 247 597 minecraft:green_terracotta
setblock 330 247 598 minecraft:oak_log
fill 331 247 558 331 247 561 minecraft:green_terracotta
setblock 331 247 562 minecraft:oak_log
fill 331 247 563 331 247 566 minecraft:green_terracotta
setblock 331 247 567 minecraft:oak_log
fill 331 247 568 331 247 571 minecraft:green_terracotta
setblock 331 247 572 minecraft:oak_log
fill 331 247 573 331 249 573 minecraft:green_terracotta
setblock 331 247 576 minecraft:green_terracotta
setblock 331 247 577 minecraft:oak_log
fill 331 247 590 331 247 591 minecraft:green_terracotta
setblock 331 247 592 minecraft:oak_log
fill 331 247 593 331 249 593 minecraft:green_terracotta
setblock 331 247 596 minecraft:green_terracotta
setblock 331 247 597 minecraft:oak_log
fill 331 247 598 334 247 598 minecraft:green_terracotta
fill 332 247 558 334 247 558 minecraft:green_terracotta
fill 332 247 564 334 273 566 minecraft:oak_log
setblock 332 247 571 minecraft:oak_log
setblock 332 247 572 minecraft:green_terracotta
setblock 332 247 596 minecraft:oak_log
fill 332 247 597 335 247 597 minecraft:green_terracotta
setblock 333 247 559 minecraft:green_terracotta
fill 333 247 596 333 248 596 minecraft:green_terracotta
setblock 334 247 559 minecraft:oak_log
setblock 335 247 558 minecraft:oak_log
setblock 335 247 598 minecraft:oak_log
fill 336 247 558 339 247 558 minecraft:green_terracotta
setblock 336 247 597 minecraft:oak_log
fill 336 247 598 339 247 598 minecraft:green_terracotta
fill 337 247 597 340 247 597 minecraft:green_terracotta
fill 339 247 596 341 247 596 minecraft:green_terracotta
setblock 340 247 558 minecraft:oak_log
setblock 340 247 598 minecraft:oak_log
fill 341 247 558 344 247 558 minecraft:green_terracotta
setblock 341 247 597 minecraft:oak_log
fill 341 247 598 344 247 598 minecraft:green_terracotta
setblock 342 247 596 minecraft:oak_log
fill 342 247 597 345 247 597 minecraft:green_terracotta
setblock 343 247 595 minecraft:oak_log
fill 343 247 596 346 247 596 minecraft:green_terracotta
fill 344 247 595 347 247 595 minecraft:green_terracotta
setblock 345 247 558 minecraft:oak_log
setblock 345 247 598 minecraft:oak_log
fill 346 247 558 349 247 558 minecraft:green_terracotta
setblock 346 247 597 minecraft:oak_log
fill 346 247 598 349 247 598 minecraft:green_terracotta
setblock 347 247 596 minecraft:oak_log
fill 347 247 597 350 247 597 minecraft:green_terracotta
setblock 348 247 594 minecraft:green_terracotta
setblock 348 247 595 minecraft:oak_log
fill 348 247 596 351 247 596 minecraft:green_terracotta
fill 349 247 583 352 273 584 minecraft:oak_log
setblock 349 247 594 minecraft:oak_log
fill 349 247 595 349 249 595 minecraft:green_terracotta
setblock 350 247 558 minecraft:oak_log
fill 350 247 582 351 264 582 minecraft:oak_log
setblock 350 247 598 minecraft:oak_log
fill 351 247 558 351 249 558 minecraft:green_terracotta
setblock 351 247 597 minecraft:oak_log
fill 351 247 598 351 250 598 minecraft:green_terracotta
setblock 352 247 596 minecraft:oak_log
fill 352 247 597 352 250 597 minecraft:green_terracotta
setblock 353 247 596 minecraft:green_terracotta
setblock 354 247 598 minecraft:green_terracotta
setblock 355 247 595 minecraft:dark_oak_log
setblock 355 247 598 minecraft:oak_log
fill 356 247 596 358 247 596 minecraft:dark_oak_log
fill 356 247 598 356 248 598 minecraft:green_terracotta
setblock 359 247 591 minecraft:dark_oak_log
fill 360 247 593 360 247 594 minecraft:dark_oak_log
fill 361 247 598 364 247 598 minecraft:green_terracotta
fill 363 247 558 364 247 558 minecraft:green_terracotta
fill 364 247 597 365 247 597 minecraft:green_terracotta
setblock 365 247 558 minecraft:oak_log
setblock 365 247 598 minecraft:oak_log
fill 366 247 558 368 247 559 minecraft:green_terracotta
setblock 366 247 572 minecraft:oak_log
fill 366 247 573 366 247 574 minecraft:green_terracotta
setblock 366 247 597 minecraft:oak_log
fill 366 247 598 366 250 598 minecraft:green_terracotta
fill 367 247 568 367 247 570 minecraft:green_terracotta
setblock 367 247 571 minecraft:oak_log
fill 367 247 572 367 250 572 minecraft:green_terracotta
fill 367 247 574 367 247 575 minecraft:green_terracotta
setblock 367 247 576 minecraft:oak_log
fill 367 247 577 367 250 577 minecraft:green_terracotta
setblock 367 247 596 minecraft:oak_log
fill 367 247 597 367 250 597 minecraft:green_terracotta
setblock 368 247 565 minecraft:oak_log
fill 368 247 566 368 247 569 minecraft:green_terracotta
setblock 368 247 570 minecraft:oak_log
fill 368 247 571 368 250 571 minecraft:green_terracotta
setblock 368 247 574 minecraft:green_terracotta
setblock 368 247 575 minecraft:oak_log
fill 368 247 576 368 250 576 minecraft:green_terracotta
fill 368 247 593 368 247 594 minecraft:green_terracotta
setblock 368 247 595 minecraft:oak_log
fill 368 247 596 368 248 596 minecraft:green_terracotta
setblock 369 247 558 minecraft:green_terracotta
setblock 369 247 559 minecraft:oak_log
fill 369 247 560 369 247 563 minecraft:green_terracotta
setblock 369 247 564 minecraft:oak_log
fill 369 247 565 369 247 568 minecraft:green_terracotta
setblock 369 247 569 minecraft:oak_log
fill 369 247 570 369 250 570 minecraft:green_terracotta
setblock 369 247 573 minecraft:green_terracotta
setblock 369 247 574 minecraft:oak_log
fill 369 247 575 369 250 575 minecraft:green_terracotta
setblock 369 247 578 minecraft:green_terracotta
setblock 369 247 579 minecraft:oak_log
fill 369 247 580 369 250 580 minecraft:green_terracotta
setblock 369 247 589 minecraft:oak_log
setblock 369 247 590 minecraft:green_terracotta
setblock 369 247 593 minecraft:green_terracotta
setblock 369 247 594 minecraft:oak_log
fill 369 247 595 369 250 595 minecraft:green_terracotta
setblock 369 247 598 minecraft:green_terracotta
setblock 370 247 558 minecraft:oak_log
fill 370 247 559 370 247 562 minecraft:green_terracotta
setblock 370 247 563 minecraft:oak_log
fill 370 247 564 370 247 567 minecraft:green_terracotta
setblock 370 247 568 minecraft:oak_log
fill 370 247 569 370 250 569 minecraft:green_terracotta
setblock 370 247 573 minecraft:oak_log
fill 370 247 574 370 250 574 minecraft:green_terracotta
setblock 370 247 578 minecraft:oak_log
fill 370 247 579 370 250 579 minecraft:green_terracotta
setblock 370 247 582 minecraft:green_terracotta
setblock 370 247 583 minecraft:oak_log
fill 370 247 584 370 247 587 minecraft:green_terracotta
setblock 370 247 588 minecraft:oak_log
fill 370 247 589 370 248 589 minecraft:green_terracotta
setblock 370 247 593 minecraft:oak_log
fill 370 247 594 370 250 594 minecraft:green_terracotta
setblock 370 247 598 minecraft:oak_log
fill 330 248 558 330 248 561 minecraft:green_terracotta
setblock 330 248 562 minecraft:oak_log
fill 330 248 563 330 248 566 minecraft:green_terracotta
setblock 330 248 567 minecraft:oak_log
fill 330 248 568 330 248 571 minecraft:green_terracotta
setblock 330 248 572 minecraft:oak_log
fill 330 248 573 330 248 576 minecraft:green_terracotta
setblock 330 248 577 minecraft:oak_log
fill 330 248 578 330 251 578 minecraft:green_terracotta
setblock 330 248 582 minecraft:oak_leaves[persistent=true]
fill 330 248 588 330 248 591 minecraft:green_terracotta
setblock 330 248 592 minecraft:oak_log
fill 330 248 593 330 248 596 minecraft:green_terracotta
setblock 330 248 597 minecraft:oak_log
fill 330 248 598 333 248 598 minecraft:green_terracotta
fill 331 248 558 331 248 560 minecraft:green_terracotta
setblock 331 248 561 minecraft:oak_log
fill 331 248 562 331 248 565 minecraft:green_terracotta
setblock 331 248 566 minecraft:oak_log
fill 331 248 567 331 248 570 minecraft:green_terracotta
setblock 331 248 571 minecraft:oak_log
fill 331 248 572 331 249 572 minecraft:green_terracotta
setblock 331 248 576 minecraft:oak_log
setblock 331 248 577 minecraft:green_terracotta
setblock 331 248 591 minecraft:oak_log
fill 331 248 592 331 249 592 minecraft:green_terracotta
setblock 331 248 596 minecraft:oak_log
fill 331 248 597 334 248 597 minecraft:green_terracotta
fill 332 248 558 333 248 558 minecraft:green_terracotta
fill 332 248 563 333 249 563 minecraft:dark_oak_log
fill 332 248 567 334 249 567 minecraft:dark_oak_log
setblock 332 248 595 minecraft:oak_log
fill 332 248 596 332 249 596 minecraft:green_terracotta
setblock 333 248 559 minecraft:oak_log
setblock 334 248 558 minecraft:oak_log
setblock 334 248 598 minecraft:oak_log
fill 335 248 558 338 248 558 minecraft:green_terracotta
fill 335 248 565 335 249 566 minecraft:dark_oak_log
setblock 335 248 597 minecraft:oak_log
fill 335 248 598 338 248 598 minecraft:green_terracotta
fill 336 248 597 339 248 597 minecraft:green_terracotta
setblock 339 248 558 minecraft:oak_log
fill 339 248 596 340 248 596 minecraft:green_terracotta
setblock 339 248 598 minecraft:oak_log
fill 340 248 558 343 248 558 minecraft:green_terracotta
setblock 340 248 597 minecraft:oak_log
fill 340 248 598 343 248 598 minecraft:green_terracotta
setblock 341 248 596 minecraft:oak_log
fill 341 248 597 344 248 597 minecraft:green_terracotta
fill 342 248 596 345 248 596 minecraft:green_terracotta
fill 343 248 595 346 248 595 minecraft:green_terracotta
setblock 344 248 558 minecraft:oak_log
setblock 344 248 598 minecraft:oak_log
fill 345 248 558 348 248 558 minecraft:green_terracotta
setblock 345 248 597 minecraft:oak_log
fill 345 248 598 348 248 598 minecraft:green_terracotta
setblock 346 248 596 minecraft:oak_log
fill 346 248 597 349 248 597 minecraft:green_terracotta
setblock 347 248 595 minecraft:oak_log
fill 347 248 596 350 248 596 minecraft:green_terracotta
fill 348 248 583 348 249 583 minecraft:dark_oak_log
fill 348 248 595 348 249 595 minecraft:green_terracotta
setblock 349 248 558 minecraft:oak_log
fill 349 248 582 349 249 582 minecraft:dark_oak_log
fill 349 248 585 352 249 585 minecraft:dark_oak_log
setblock 349 248 598 minecraft:oak_log
fill 350 248 558 350 251 558 minecraft:green_terracotta
fill 350 248 581 350 249 581 minecraft:dark_oak_log
setblock 350 248 597 minecraft:oak_log
fill 350 248 598 350 251 598 minecraft:green_terracotta
setblock 351 248 596 minecraft:oak_log
fill 351 248 597 351 251 597 minecraft:green_terracotta
fill 352 248 582 352 249 582 minecraft:dark_oak_log
setblock 352 248 596 minecraft:green_terracotta
setblock 354 248 598 minecraft:oak_log
fill 355 248 598 355 249 598 minecraft:green_terracotta
fill 357 248 593 357 249 593 minecraft:oak_log
setblock 358 248 598 minecraft:oak_leaves[persistent=true]
setblock 361 248 558 minecraft:oak_leaves[persistent=true]
fill 361 248 598 363 248 598 minecraft:green_terracotta
setblock 363 248 558 minecraft:green_terracotta
setblock 364 248 558 minecraft:oak_log
setblock 364 248 597 minecraft:green_terracotta
setblock 364 248 598 minecraft:oak_log
fill 365 248 558 367 248 559 minecraft:green_terracotta
setblock 365 248 597 minecraft:oak_log
fill 365 248 598 365 251 598 minecraft:green_terracotta
setblock 366 248 573 minecraft:green_terracotta
fill 366 248 597 366 251 597 minecraft:green_terracotta
setblock 367 248 569 minecraft:green_terracotta
setblock 367 248 570 minecraft:oak_log
fill 367 248 571 367 249 571 minecraft:green_terracotta
setblock 367 248 574 minecraft:green_terracotta
setblock 367 248 575 minecraft:oak_log
fill 367 248 576 367 250 576 minecraft:green_terracotta
setblock 367 248 596 minecraft:green_terracotta
setblock 368 248 558 minecraft:green_terracotta
setblock 368 248 559 minecraft:oak_log
fill 368 248 565 368 248 568 minecraft:green_terracotta
setblock 368 248 569 minecraft:oak_log
fill 368 248 570 368 250 570 minecraft:green_terracotta
setblock 368 248 574 minecraft:oak_log
fill 368 248 575 368 251 575 minecraft:green_terracotta
fill 368 248 577 368 248 578 minecraft:green_terracotta
setblock 368 248 579 minecraft:oak_log
setblock 368 248 595 minecraft:green_terracotta
setblock 369 248 558 minecraft:oak_log
fill 369 248 559 369 248 562 minecraft:green_terracotta
setblock 369 248 563 minecraft:oak_log
fill 369 248 564 369 248 567 minecraft:green_terracotta
setblock 369 248 568 minecraft:oak_log
fill 369 248 569 369 251 569 minecraft:green_terracotta
schedule function dropper:buildpart/139_8 1t
