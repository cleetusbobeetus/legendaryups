fill 380 265 222 380 268 222 minecraft:mossy_cobblestone
setblock 381 265 221 minecraft:mossy_cobblestone
setblock 384 265 222 minecraft:stone_bricks
setblock 387 265 184 minecraft:light[level=12]
setblock 387 265 192 minecraft:light[level=12]
setblock 387 265 200 minecraft:light[level=12]
setblock 387 265 208 minecraft:light[level=12]
setblock 387 265 216 minecraft:light[level=12]
setblock 393 265 182 minecraft:mossy_cobblestone
setblock 394 265 182 minecraft:stone_bricks
setblock 394 265 222 minecraft:stone_bricks
fill 395 265 182 395 267 183 minecraft:mossy_cobblestone
setblock 395 265 184 minecraft:light[level=12]
setblock 395 265 192 minecraft:light[level=12]
setblock 395 265 200 minecraft:light[level=12]
setblock 395 265 208 minecraft:light[level=12]
setblock 395 265 216 minecraft:light[level=12]
fill 395 265 222 395 268 222 minecraft:mossy_cobblestone
setblock 398 265 183 minecraft:stone_bricks
setblock 399 265 182 minecraft:stone_bricks
fill 399 265 183 399 268 183 minecraft:mossy_cobblestone
setblock 399 265 222 minecraft:stone_bricks
fill 400 265 182 403 265 182 minecraft:mossy_cobblestone
setblock 403 265 183 minecraft:stone_bricks
setblock 403 265 184 minecraft:light[level=12]
setblock 403 265 192 minecraft:light[level=12]
setblock 403 265 200 minecraft:light[level=12]
setblock 403 265 208 minecraft:light[level=12]
setblock 403 265 216 minecraft:light[level=12]
setblock 404 265 182 minecraft:stone_bricks
fill 405 265 182 405 268 182 minecraft:mossy_cobblestone
setblock 409 265 182 minecraft:stone_bricks
fill 409 265 183 409 268 183 minecraft:mossy_cobblestone
fill 410 265 182 410 268 182 minecraft:mossy_cobblestone
setblock 411 265 184 minecraft:light[level=12]
setblock 411 265 192 minecraft:light[level=12]
setblock 411 265 200 minecraft:light[level=12]
setblock 411 265 208 minecraft:light[level=12]
setblock 411 265 216 minecraft:light[level=12]
setblock 412 265 184 minecraft:stone_bricks
setblock 413 265 183 minecraft:stone_bricks
fill 413 265 184 413 268 184 minecraft:mossy_cobblestone
setblock 414 265 182 minecraft:stone_bricks
fill 414 265 183 414 268 183 minecraft:mossy_cobblestone
setblock 414 265 222 minecraft:stone_bricks
fill 415 265 182 415 268 182 minecraft:mossy_cobblestone
setblock 415 265 186 minecraft:stone_bricks
fill 415 265 187 415 268 187 minecraft:mossy_cobblestone
setblock 415 265 221 minecraft:stone_bricks
fill 415 265 222 415 268 222 minecraft:mossy_cobblestone
setblock 416 265 185 minecraft:stone_bricks
fill 416 265 186 416 268 186 minecraft:mossy_cobblestone
setblock 416 265 190 minecraft:stone_bricks
setblock 416 265 205 minecraft:stone_bricks
setblock 416 265 220 minecraft:stone_bricks
fill 416 265 221 416 268 221 minecraft:mossy_cobblestone
setblock 417 265 184 minecraft:stone_bricks
fill 417 265 185 417 268 185 minecraft:mossy_cobblestone
setblock 417 265 189 minecraft:stone_bricks
fill 417 265 190 417 268 190 minecraft:mossy_cobblestone
setblock 417 265 199 minecraft:stone_bricks
fill 417 265 200 417 268 200 minecraft:mossy_cobblestone
setblock 417 265 204 minecraft:stone_bricks
fill 417 265 205 417 268 205 minecraft:mossy_cobblestone
setblock 417 265 209 minecraft:stone_bricks
fill 417 265 210 417 266 212 minecraft:mossy_cobblestone
fill 417 265 216 417 267 216 minecraft:mossy_cobblestone
setblock 417 265 219 minecraft:stone_bricks
fill 417 265 220 417 268 220 minecraft:mossy_cobblestone
setblock 377 266 183 minecraft:stone_bricks
fill 377 266 184 377 269 184 minecraft:mossy_cobblestone
setblock 377 266 188 minecraft:stone_bricks
fill 377 266 189 377 268 190 minecraft:mossy_cobblestone
fill 377 266 200 377 266 202 minecraft:mossy_cobblestone
setblock 377 266 203 minecraft:stone_bricks
fill 377 266 204 377 269 204 minecraft:mossy_cobblestone
setblock 377 266 208 minecraft:stone_bricks
fill 377 266 209 377 269 209 minecraft:mossy_cobblestone
setblock 377 266 213 minecraft:stone_bricks
fill 377 266 214 377 269 214 minecraft:mossy_cobblestone
setblock 377 266 218 minecraft:stone_bricks
fill 377 266 219 377 269 219 minecraft:mossy_cobblestone
setblock 378 266 182 minecraft:stone_bricks
fill 378 266 183 378 269 183 minecraft:mossy_cobblestone
setblock 378 266 187 minecraft:stone_bricks
setblock 378 266 202 minecraft:stone_bricks
fill 378 266 203 378 269 203 minecraft:mossy_cobblestone
setblock 378 266 207 minecraft:stone_bricks
fill 378 266 208 379 268 208 minecraft:mossy_cobblestone
setblock 378 266 212 minecraft:stone_bricks
fill 378 266 213 378 269 213 minecraft:mossy_cobblestone
setblock 378 266 217 minecraft:stone_bricks
fill 378 266 218 378 269 218 minecraft:mossy_cobblestone
setblock 378 266 222 minecraft:stone_bricks
fill 379 266 182 379 269 182 minecraft:mossy_cobblestone
setblock 379 266 205 minecraft:mossy_cobblestone
setblock 379 266 206 minecraft:stone_bricks
fill 379 266 207 379 269 207 minecraft:mossy_cobblestone
fill 379 266 209 379 267 209 minecraft:mossy_cobblestone
setblock 379 266 221 minecraft:stone_bricks
fill 379 266 222 379 269 222 minecraft:mossy_cobblestone
setblock 380 266 221 minecraft:mossy_cobblestone
setblock 383 266 222 minecraft:stone_bricks
setblock 392 266 182 minecraft:mossy_cobblestone
setblock 393 266 182 minecraft:stone_bricks
fill 394 266 182 394 268 183 minecraft:mossy_cobblestone
setblock 397 266 183 minecraft:stone_bricks
setblock 398 266 182 minecraft:stone_bricks
fill 398 266 183 398 269 183 minecraft:mossy_cobblestone
setblock 398 266 222 minecraft:stone_bricks
fill 399 266 182 402 266 182 minecraft:mossy_cobblestone
setblock 402 266 183 minecraft:stone_bricks
setblock 403 266 182 minecraft:stone_bricks
fill 403 266 183 403 269 183 minecraft:mossy_cobblestone
fill 404 266 182 404 269 182 minecraft:mossy_cobblestone
setblock 408 266 182 minecraft:stone_bricks
fill 408 266 183 408 269 183 minecraft:mossy_cobblestone
fill 409 266 182 409 269 182 minecraft:mossy_cobblestone
setblock 411 266 184 minecraft:stone_bricks
setblock 412 266 183 minecraft:stone_bricks
fill 412 266 184 412 269 184 minecraft:mossy_cobblestone
setblock 413 266 182 minecraft:stone_bricks
fill 413 266 183 413 269 183 minecraft:mossy_cobblestone
setblock 413 266 222 minecraft:stone_bricks
fill 414 266 182 414 269 182 minecraft:mossy_cobblestone
fill 414 266 222 414 269 222 minecraft:mossy_cobblestone
setblock 415 266 185 minecraft:stone_bricks
fill 415 266 186 415 269 186 minecraft:mossy_cobblestone
fill 415 266 188 416 266 188 minecraft:mossy_cobblestone
fill 415 266 221 415 269 221 minecraft:mossy_cobblestone
setblock 416 266 184 minecraft:stone_bricks
fill 416 266 185 416 269 185 minecraft:mossy_cobblestone
setblock 416 266 189 minecraft:stone_bricks
fill 416 266 190 416 269 190 minecraft:mossy_cobblestone
setblock 416 266 204 minecraft:stone_bricks
fill 416 266 205 416 266 208 minecraft:mossy_cobblestone
fill 416 266 220 416 269 220 minecraft:mossy_cobblestone
setblock 417 266 183 minecraft:stone_bricks
fill 417 266 184 417 269 184 minecraft:mossy_cobblestone
setblock 417 266 188 minecraft:stone_bricks
fill 417 266 189 417 269 189 minecraft:mossy_cobblestone
setblock 417 266 193 minecraft:stone_bricks
setblock 417 266 203 minecraft:stone_bricks
fill 417 266 204 417 269 204 minecraft:mossy_cobblestone
setblock 417 266 208 minecraft:stone_bricks
fill 417 266 209 417 269 209 minecraft:mossy_cobblestone
setblock 417 266 213 minecraft:stone_bricks
fill 417 266 214 417 268 215 minecraft:mossy_cobblestone
setblock 417 266 218 minecraft:stone_bricks
fill 417 266 219 417 269 219 minecraft:mossy_cobblestone
setblock 377 267 182 minecraft:stone_bricks
fill 377 267 183 377 270 183 minecraft:mossy_cobblestone
setblock 377 267 187 minecraft:stone_bricks
fill 377 267 188 377 270 188 minecraft:mossy_cobblestone
setblock 377 267 191 minecraft:mossy_cobblestone
fill 377 267 200 377 267 201 minecraft:mossy_cobblestone
setblock 377 267 202 minecraft:stone_bricks
fill 377 267 203 377 270 203 minecraft:mossy_cobblestone
setblock 377 267 207 minecraft:stone_bricks
fill 377 267 208 377 270 208 minecraft:mossy_cobblestone
setblock 377 267 212 minecraft:stone_bricks
fill 377 267 213 377 270 213 minecraft:mossy_cobblestone
setblock 377 267 217 minecraft:stone_bricks
fill 377 267 218 377 270 218 minecraft:mossy_cobblestone
setblock 377 267 222 minecraft:stone_bricks
fill 378 267 182 378 270 182 minecraft:mossy_cobblestone
setblock 378 267 186 minecraft:stone_bricks
fill 378 267 187 378 270 187 minecraft:mossy_cobblestone
fill 378 267 202 378 268 202 minecraft:mossy_cobblestone
setblock 378 267 206 minecraft:stone_bricks
fill 378 267 207 378 270 207 minecraft:mossy_cobblestone
setblock 378 267 211 minecraft:stone_bricks
fill 378 267 212 378 270 212 minecraft:mossy_cobblestone
setblock 378 267 216 minecraft:stone_bricks
fill 378 267 217 378 270 217 minecraft:mossy_cobblestone
setblock 378 267 221 minecraft:stone_bricks
fill 378 267 222 378 270 222 minecraft:mossy_cobblestone
setblock 379 267 205 minecraft:stone_bricks
fill 379 267 206 379 270 206 minecraft:mossy_cobblestone
setblock 379 267 210 minecraft:stone_bricks
fill 379 267 211 379 270 211 minecraft:mossy_cobblestone
fill 379 267 221 379 269 221 minecraft:mossy_cobblestone
setblock 382 267 182 minecraft:stone_bricks
setblock 382 267 222 minecraft:stone_bricks
setblock 392 267 182 minecraft:stone_bricks
fill 393 267 182 393 270 182 minecraft:mossy_cobblestone
setblock 396 267 183 minecraft:stone_bricks
fill 396 267 184 399 267 184 minecraft:mossy_cobblestone
setblock 397 267 182 minecraft:stone_bricks
fill 397 267 183 397 270 183 minecraft:mossy_cobblestone
setblock 397 267 222 minecraft:stone_bricks
fill 398 267 182 401 267 182 minecraft:mossy_cobblestone
setblock 401 267 183 minecraft:stone_bricks
setblock 402 267 182 minecraft:stone_bricks
fill 402 267 183 402 270 183 minecraft:mossy_cobblestone
fill 403 267 182 403 270 182 minecraft:mossy_cobblestone
setblock 407 267 182 minecraft:stone_bricks
fill 407 267 183 407 270 183 minecraft:mossy_cobblestone
fill 408 267 182 408 270 182 minecraft:mossy_cobblestone
setblock 410 267 184 minecraft:stone_bricks
setblock 411 267 183 minecraft:stone_bricks
fill 411 267 184 411 270 184 minecraft:mossy_cobblestone
setblock 411 267 222 minecraft:mossy_cobblestone
setblock 412 267 182 minecraft:stone_bricks
fill 412 267 183 412 270 183 minecraft:mossy_cobblestone
setblock 412 267 222 minecraft:stone_bricks
fill 413 267 182 413 270 182 minecraft:mossy_cobblestone
fill 413 267 222 413 270 222 minecraft:mossy_cobblestone
setblock 414 267 185 minecraft:stone_bricks
fill 414 267 186 414 270 186 minecraft:mossy_cobblestone
fill 414 267 221 414 270 221 minecraft:mossy_cobblestone
setblock 415 267 184 minecraft:stone_bricks
fill 415 267 185 415 270 185 minecraft:mossy_cobblestone
setblock 415 267 188 minecraft:mossy_cobblestone
setblock 415 267 189 minecraft:stone_bricks
setblock 416 267 183 minecraft:stone_bricks
fill 416 267 184 416 270 184 minecraft:mossy_cobblestone
setblock 416 267 188 minecraft:stone_bricks
fill 416 267 189 416 270 189 minecraft:mossy_cobblestone
fill 416 267 191 416 268 191 minecraft:mossy_cobblestone
fill 416 267 204 416 267 207 minecraft:mossy_cobblestone
setblock 416 267 208 minecraft:stone_bricks
fill 416 267 209 416 268 211 minecraft:mossy_cobblestone
setblock 417 267 182 minecraft:stone_bricks
fill 417 267 183 417 270 183 minecraft:mossy_cobblestone
setblock 417 267 187 minecraft:stone_bricks
fill 417 267 188 417 270 188 minecraft:mossy_cobblestone
setblock 417 267 192 minecraft:stone_bricks
fill 417 267 193 417 270 193 minecraft:mossy_cobblestone
setblock 417 267 202 minecraft:stone_bricks
fill 417 267 203 417 270 203 minecraft:mossy_cobblestone
setblock 417 267 207 minecraft:stone_bricks
fill 417 267 208 417 270 208 minecraft:mossy_cobblestone
fill 417 267 210 417 267 211 minecraft:mossy_cobblestone
setblock 417 267 212 minecraft:stone_bricks
fill 417 267 213 417 270 213 minecraft:mossy_cobblestone
setblock 417 267 217 minecraft:stone_bricks
fill 417 267 218 417 270 218 minecraft:mossy_cobblestone
setblock 417 267 222 minecraft:stone_bricks
fill 377 268 182 377 271 182 minecraft:mossy_cobblestone
setblock 377 268 186 minecraft:stone_bricks
fill 377 268 187 377 271 187 minecraft:mossy_cobblestone
setblock 377 268 191 minecraft:stone_bricks
fill 377 268 192 377 271 192 minecraft:mossy_cobblestone
setblock 377 268 200 minecraft:mossy_cobblestone
setblock 377 268 201 minecraft:stone_bricks
fill 377 268 202 377 271 202 minecraft:mossy_cobblestone
setblock 377 268 206 minecraft:stone_bricks
fill 377 268 207 377 271 207 minecraft:mossy_cobblestone
setblock 377 268 211 minecraft:stone_bricks
fill 377 268 212 377 271 212 minecraft:mossy_cobblestone
setblock 377 268 215 minecraft:mossy_cobblestone
setblock 377 268 216 minecraft:stone_bricks
fill 377 268 217 377 271 217 minecraft:mossy_cobblestone
setblock 377 268 221 minecraft:stone_bricks
fill 377 268 222 377 271 222 minecraft:mossy_cobblestone
setblock 378 268 185 minecraft:stone_bricks
fill 378 268 186 378 271 186 minecraft:mossy_cobblestone
fill 378 268 188 378 269 188 minecraft:mossy_cobblestone
setblock 378 268 205 minecraft:stone_bricks
fill 378 268 206 378 271 206 minecraft:mossy_cobblestone
setblock 378 268 210 minecraft:stone_bricks
fill 378 268 211 378 271 211 minecraft:mossy_cobblestone
setblock 378 268 215 minecraft:stone_bricks
fill 378 268 216 378 271 216 minecraft:mossy_cobblestone
setblock 378 268 220 minecraft:stone_bricks
fill 378 268 221 378 271 221 minecraft:mossy_cobblestone
fill 379 268 205 379 270 205 minecraft:mossy_cobblestone
setblock 379 268 209 minecraft:stone_bricks
fill 379 268 210 379 271 210 minecraft:mossy_cobblestone
fill 379 268 212 379 269 212 minecraft:mossy_cobblestone
setblock 381 268 182 minecraft:stone_bricks
setblock 381 268 222 minecraft:stone_bricks
setblock 382 268 222 minecraft:mossy_cobblestone
setblock 391 268 182 minecraft:stone_bricks
fill 392 268 182 392 271 182 minecraft:mossy_cobblestone
fill 393 268 183 393 269 183 minecraft:mossy_cobblestone
fill 394 268 222 394 269 222 minecraft:mossy_cobblestone
setblock 395 268 182 minecraft:mossy_cobblestone
setblock 395 268 183 minecraft:stone_bricks
fill 395 268 184 398 268 184 minecraft:mossy_cobblestone
setblock 396 268 182 minecraft:stone_bricks
fill 396 268 183 396 271 183 minecraft:mossy_cobblestone
setblock 396 268 222 minecraft:stone_bricks
fill 397 268 182 400 268 182 minecraft:mossy_cobblestone
setblock 397 268 222 minecraft:mossy_cobblestone
setblock 399 268 184 minecraft:stone_bricks
setblock 400 268 183 minecraft:stone_bricks
fill 400 268 184 400 269 184 minecraft:mossy_cobblestone
setblock 401 268 182 minecraft:stone_bricks
fill 401 268 183 401 271 183 minecraft:mossy_cobblestone
fill 402 268 182 402 271 182 minecraft:mossy_cobblestone
setblock 404 268 183 minecraft:mossy_cobblestone
setblock 405 268 183 minecraft:stone_bricks
setblock 406 268 182 minecraft:stone_bricks
fill 406 268 183 406 271 183 minecraft:mossy_cobblestone
fill 407 268 182 407 271 182 minecraft:mossy_cobblestone
setblock 409 268 184 minecraft:stone_bricks
setblock 410 268 183 minecraft:stone_bricks
fill 410 268 184 410 271 184 minecraft:mossy_cobblestone
setblock 411 268 182 minecraft:stone_bricks
fill 411 268 183 411 271 183 minecraft:mossy_cobblestone
setblock 411 268 222 minecraft:stone_bricks
fill 412 268 182 412 271 182 minecraft:mossy_cobblestone
setblock 412 268 185 minecraft:mossy_cobblestone
fill 412 268 222 412 271 222 minecraft:mossy_cobblestone
setblock 413 268 185 minecraft:stone_bricks
setblock 414 268 184 minecraft:stone_bricks
fill 414 268 185 414 271 185 minecraft:mossy_cobblestone
fill 414 268 187 414 269 187 minecraft:mossy_cobblestone
setblock 415 268 183 minecraft:stone_bricks
fill 415 268 184 415 271 184 minecraft:mossy_cobblestone
setblock 415 268 188 minecraft:stone_bricks
fill 415 268 189 415 270 190 minecraft:mossy_cobblestone
setblock 416 268 182 minecraft:stone_bricks
fill 416 268 183 416 271 183 minecraft:mossy_cobblestone
setblock 416 268 187 minecraft:stone_bricks
fill 416 268 188 416 271 188 minecraft:mossy_cobblestone
setblock 416 268 192 minecraft:stone_bricks
fill 416 268 204 416 268 206 minecraft:mossy_cobblestone
setblock 416 268 207 minecraft:stone_bricks
fill 416 268 208 416 271 208 minecraft:mossy_cobblestone
setblock 416 268 212 minecraft:stone_bricks
fill 416 268 213 416 270 214 minecraft:mossy_cobblestone
fill 416 268 219 416 270 219 minecraft:mossy_cobblestone
setblock 416 268 222 minecraft:stone_bricks
fill 417 268 182 417 271 182 minecraft:mossy_cobblestone
setblock 417 268 186 minecraft:stone_bricks
fill 417 268 187 417 271 187 minecraft:mossy_cobblestone
setblock 417 268 191 minecraft:stone_bricks
fill 417 268 192 417 271 192 minecraft:mossy_cobblestone
fill 417 268 194 417 269 194 minecraft:mossy_cobblestone
setblock 417 268 201 minecraft:stone_bricks
fill 417 268 202 417 271 202 minecraft:mossy_cobblestone
setblock 417 268 206 minecraft:stone_bricks
fill 417 268 207 417 271 207 minecraft:mossy_cobblestone
setblock 417 268 210 minecraft:mossy_cobblestone
setblock 417 268 211 minecraft:stone_bricks
fill 417 268 212 417 271 212 minecraft:mossy_cobblestone
setblock 417 268 216 minecraft:stone_bricks
fill 417 268 217 417 271 217 minecraft:mossy_cobblestone
setblock 417 268 221 minecraft:stone_bricks
fill 417 268 222 417 271 222 minecraft:mossy_cobblestone
setblock 377 269 185 minecraft:stone_bricks
fill 377 269 186 377 272 186 minecraft:mossy_cobblestone
setblock 377 269 189 minecraft:mossy_cobblestone
setblock 377 269 190 minecraft:stone_bricks
fill 377 269 191 377 272 191 minecraft:mossy_cobblestone
fill 377 269 193 377 270 193 minecraft:mossy_cobblestone
setblock 377 269 200 minecraft:stone_bricks
fill 377 269 201 377 272 201 minecraft:mossy_cobblestone
setblock 377 269 205 minecraft:stone_bricks
fill 377 269 206 377 272 206 minecraft:mossy_cobblestone
setblock 377 269 210 minecraft:stone_bricks
fill 377 269 211 377 272 211 minecraft:mossy_cobblestone
setblock 377 269 215 minecraft:stone_bricks
fill 377 269 216 377 272 216 minecraft:mossy_cobblestone
setblock 377 269 220 minecraft:stone_bricks
fill 377 269 221 377 272 221 minecraft:mossy_cobblestone
setblock 378 269 184 minecraft:stone_bricks
fill 378 269 185 378 271 185 minecraft:mossy_cobblestone
setblock 378 269 189 minecraft:stone_bricks
setblock 378 269 204 minecraft:stone_bricks
fill 378 269 205 378 272 205 minecraft:mossy_cobblestone
setblock 378 269 208 minecraft:mossy_cobblestone
setblock 378 269 209 minecraft:stone_bricks
fill 378 269 210 378 272 210 minecraft:mossy_cobblestone
setblock 378 269 214 minecraft:stone_bricks
fill 378 269 215 378 272 215 minecraft:mossy_cobblestone
setblock 378 269 219 minecraft:stone_bricks
fill 378 269 220 378 271 220 minecraft:mossy_cobblestone
setblock 379 269 183 minecraft:stone_bricks
setblock 379 269 208 minecraft:stone_bricks
fill 379 269 209 379 272 209 minecraft:mossy_cobblestone
setblock 379 269 213 minecraft:stone_bricks
setblock 380 269 182 minecraft:stone_bricks
setblock 380 269 222 minecraft:stone_bricks
setblock 381 269 182 minecraft:mossy_cobblestone
setblock 381 269 222 minecraft:mossy_cobblestone
setblock 390 269 182 minecraft:stone_bricks
fill 391 269 182 391 272 182 minecraft:mossy_cobblestone
fill 392 269 183 392 270 183 minecraft:mossy_cobblestone
fill 393 269 222 393 270 222 minecraft:mossy_cobblestone
setblock 394 269 182 minecraft:mossy_cobblestone
setblock 394 269 183 minecraft:stone_bricks
fill 394 269 184 397 269 184 minecraft:mossy_cobblestone
setblock 395 269 182 minecraft:stone_bricks
fill 395 269 183 395 272 183 minecraft:mossy_cobblestone
setblock 395 269 222 minecraft:stone_bricks
fill 396 269 182 399 269 182 minecraft:mossy_cobblestone
fill 396 269 222 396 270 222 minecraft:mossy_cobblestone
setblock 398 269 184 minecraft:stone_bricks
setblock 399 269 183 minecraft:stone_bricks
fill 399 269 184 399 271 184 minecraft:mossy_cobblestone
setblock 400 269 182 minecraft:stone_bricks
fill 400 269 183 400 272 183 minecraft:mossy_cobblestone
fill 401 269 182 401 272 182 minecraft:mossy_cobblestone
setblock 404 269 183 minecraft:stone_bricks
setblock 405 269 182 minecraft:stone_bricks
fill 405 269 183 405 272 183 minecraft:mossy_cobblestone
fill 406 269 182 406 272 182 minecraft:mossy_cobblestone
setblock 408 269 184 minecraft:stone_bricks
setblock 409 269 183 minecraft:stone_bricks
fill 409 269 184 409 272 184 minecraft:mossy_cobblestone
setblock 410 269 182 minecraft:stone_bricks
fill 410 269 183 410 272 183 minecraft:mossy_cobblestone
setblock 410 269 222 minecraft:stone_bricks
fill 411 269 182 411 272 182 minecraft:mossy_cobblestone
setblock 411 269 185 minecraft:mossy_cobblestone
fill 411 269 222 411 272 222 minecraft:mossy_cobblestone
setblock 412 269 185 minecraft:stone_bricks
setblock 413 269 184 minecraft:stone_bricks
fill 413 269 185 413 272 185 minecraft:mossy_cobblestone
fill 413 269 221 413 271 221 minecraft:mossy_cobblestone
setblock 414 269 183 minecraft:stone_bricks
fill 414 269 184 414 272 184 minecraft:mossy_cobblestone
setblock 414 269 188 minecraft:stone_bricks
setblock 415 269 182 minecraft:stone_bricks
fill 415 269 183 415 272 183 minecraft:mossy_cobblestone
setblock 415 269 187 minecraft:stone_bricks
fill 415 269 188 415 272 188 minecraft:mossy_cobblestone
setblock 415 269 191 minecraft:mossy_cobblestone
fill 415 269 208 415 270 210 minecraft:mossy_cobblestone
setblock 415 269 222 minecraft:stone_bricks
fill 416 269 182 416 272 182 minecraft:mossy_cobblestone
setblock 416 269 186 minecraft:stone_bricks
fill 416 269 187 416 272 187 minecraft:mossy_cobblestone
setblock 416 269 191 minecraft:stone_bricks
fill 416 269 192 416 271 193 minecraft:mossy_cobblestone
fill 416 269 204 416 269 205 minecraft:mossy_cobblestone
setblock 416 269 206 minecraft:stone_bricks
fill 416 269 207 416 272 207 minecraft:mossy_cobblestone
fill 416 269 209 416 269 210 minecraft:mossy_cobblestone
setblock 416 269 211 minecraft:stone_bricks
fill 416 269 212 416 272 212 minecraft:mossy_cobblestone
setblock 416 269 215 minecraft:mossy_cobblestone
setblock 416 269 216 minecraft:stone_bricks
fill 416 269 217 416 271 218 minecraft:mossy_cobblestone
setblock 416 269 221 minecraft:stone_bricks
fill 416 269 222 416 272 222 minecraft:mossy_cobblestone
setblock 417 269 185 minecraft:stone_bricks
fill 417 269 186 417 272 186 minecraft:mossy_cobblestone
setblock 417 269 190 minecraft:stone_bricks
fill 417 269 191 417 272 191 minecraft:mossy_cobblestone
setblock 417 269 195 minecraft:stone_bricks
fill 417 269 201 417 270 201 minecraft:mossy_cobblestone
setblock 417 269 205 minecraft:stone_bricks
fill 417 269 206 417 272 206 minecraft:mossy_cobblestone
setblock 417 269 210 minecraft:stone_bricks
fill 417 269 211 417 272 211 minecraft:mossy_cobblestone
setblock 417 269 214 minecraft:mossy_cobblestone
setblock 417 269 215 minecraft:stone_bricks
fill 417 269 216 417 272 216 minecraft:mossy_cobblestone
setblock 417 269 220 minecraft:stone_bricks
fill 417 269 221 417 272 221 minecraft:mossy_cobblestone
setblock 377 270 184 minecraft:stone_bricks
fill 377 270 185 377 272 185 minecraft:mossy_cobblestone
setblock 377 270 189 minecraft:stone_bricks
fill 377 270 190 378 272 190 minecraft:mossy_cobblestone
setblock 377 270 194 minecraft:stone_bricks
setblock 377 270 199 minecraft:stone_bricks
fill 377 270 200 377 272 200 minecraft:mossy_cobblestone
setblock 377 270 204 minecraft:stone_bricks
fill 377 270 205 377 272 205 minecraft:mossy_cobblestone
setblock 377 270 209 minecraft:stone_bricks
fill 377 270 210 377 272 210 minecraft:mossy_cobblestone
setblock 377 270 214 minecraft:stone_bricks
fill 377 270 215 377 272 215 minecraft:mossy_cobblestone
setblock 377 270 219 minecraft:stone_bricks
fill 377 270 220 377 272 220 minecraft:mossy_cobblestone
setblock 378 270 183 minecraft:stone_bricks
fill 378 270 184 378 271 184 minecraft:mossy_cobblestone
setblock 378 270 188 minecraft:stone_bricks
fill 378 270 189 378 272 189 minecraft:mossy_cobblestone
setblock 378 270 203 minecraft:stone_bricks
fill 378 270 204 378 272 204 minecraft:mossy_cobblestone
setblock 378 270 208 minecraft:stone_bricks
fill 378 270 209 378 272 209 minecraft:mossy_cobblestone
setblock 378 270 213 minecraft:stone_bricks
fill 378 270 214 379 272 214 minecraft:mossy_cobblestone
setblock 378 270 218 minecraft:stone_bricks
fill 378 270 219 378 272 219 minecraft:mossy_cobblestone
setblock 379 270 182 minecraft:stone_bricks
setblock 379 270 207 minecraft:stone_bricks
fill 379 270 208 379 272 208 minecraft:mossy_cobblestone
setblock 379 270 212 minecraft:stone_bricks
fill 379 270 213 379 272 213 minecraft:mossy_cobblestone
setblock 379 270 222 minecraft:stone_bricks
setblock 380 270 182 minecraft:mossy_cobblestone
fill 380 270 222 380 271 222 minecraft:mossy_cobblestone
fill 390 270 182 390 272 182 minecraft:mossy_cobblestone
fill 391 270 183 391 271 183 minecraft:mossy_cobblestone
setblock 393 270 183 minecraft:stone_bricks
fill 393 270 184 396 270 184 minecraft:mossy_cobblestone
setblock 394 270 182 minecraft:stone_bricks
fill 394 270 183 394 272 183 minecraft:mossy_cobblestone
setblock 394 270 222 minecraft:stone_bricks
fill 395 270 182 398 270 182 minecraft:mossy_cobblestone
fill 395 270 222 395 272 222 minecraft:mossy_cobblestone
setblock 397 270 184 minecraft:stone_bricks
setblock 398 270 183 minecraft:stone_bricks
fill 398 270 184 398 271 184 minecraft:mossy_cobblestone
setblock 399 270 182 minecraft:stone_bricks
fill 399 270 183 399 272 183 minecraft:mossy_cobblestone
fill 400 270 182 400 272 182 minecraft:mossy_cobblestone
setblock 403 270 183 minecraft:stone_bricks
setblock 404 270 182 minecraft:stone_bricks
fill 404 270 183 404 271 183 minecraft:mossy_cobblestone
fill 405 270 182 405 272 182 minecraft:mossy_cobblestone
setblock 408 270 183 minecraft:stone_bricks
fill 408 270 184 408 272 184 minecraft:mossy_cobblestone
setblock 409 270 182 minecraft:stone_bricks
fill 409 270 183 409 272 183 minecraft:mossy_cobblestone
setblock 409 270 222 minecraft:stone_bricks
fill 410 270 182 410 272 182 minecraft:mossy_cobblestone
setblock 410 270 185 minecraft:mossy_cobblestone
fill 410 270 222 410 272 222 minecraft:mossy_cobblestone
setblock 411 270 185 minecraft:stone_bricks
setblock 412 270 184 minecraft:stone_bricks
fill 412 270 185 412 272 185 minecraft:mossy_cobblestone
fill 412 270 221 412 272 221 minecraft:mossy_cobblestone
setblock 413 270 183 minecraft:stone_bricks
fill 413 270 184 413 272 184 minecraft:mossy_cobblestone
setblock 414 270 182 minecraft:stone_bricks
fill 414 270 183 414 272 183 minecraft:mossy_cobblestone
setblock 414 270 187 minecraft:stone_bricks
fill 414 270 188 414 272 189 minecraft:mossy_cobblestone
setblock 414 270 222 minecraft:stone_bricks
fill 415 270 182 415 272 182 minecraft:mossy_cobblestone
setblock 415 270 186 minecraft:stone_bricks
fill 415 270 187 415 272 187 minecraft:mossy_cobblestone
setblock 415 270 191 minecraft:stone_bricks
fill 415 270 207 415 272 207 minecraft:mossy_cobblestone
setblock 415 270 211 minecraft:stone_bricks
fill 415 270 212 415 272 213 minecraft:mossy_cobblestone
setblock 415 270 221 minecraft:stone_bricks
fill 415 270 222 415 272 222 minecraft:mossy_cobblestone
setblock 416 270 185 minecraft:stone_bricks
fill 416 270 186 416 272 186 minecraft:mossy_cobblestone
setblock 416 270 190 minecraft:stone_bricks
fill 416 270 191 416 272 191 minecraft:mossy_cobblestone
setblock 416 270 204 minecraft:mossy_cobblestone
setblock 416 270 205 minecraft:stone_bricks
fill 416 270 206 416 272 206 minecraft:mossy_cobblestone
setblock 416 270 209 minecraft:mossy_cobblestone
setblock 416 270 210 minecraft:stone_bricks
fill 416 270 211 416 272 211 minecraft:mossy_cobblestone
setblock 416 270 215 minecraft:stone_bricks
fill 416 270 216 416 272 216 minecraft:mossy_cobblestone
setblock 416 270 220 minecraft:stone_bricks
fill 416 270 221 416 272 221 minecraft:mossy_cobblestone
setblock 417 270 184 minecraft:stone_bricks
fill 417 270 185 417 272 185 minecraft:mossy_cobblestone
setblock 417 270 189 minecraft:stone_bricks
fill 417 270 190 417 272 190 minecraft:mossy_cobblestone
setblock 417 270 194 minecraft:stone_bricks
fill 417 270 195 417 272 195 minecraft:mossy_cobblestone
setblock 417 270 204 minecraft:stone_bricks
fill 417 270 205 417 272 205 minecraft:mossy_cobblestone
setblock 417 270 209 minecraft:stone_bricks
fill 417 270 210 417 272 210 minecraft:mossy_cobblestone
setblock 417 270 214 minecraft:stone_bricks
fill 417 270 215 417 272 215 minecraft:mossy_cobblestone
setblock 417 270 219 minecraft:stone_bricks
fill 417 270 220 417 272 220 minecraft:mossy_cobblestone
setblock 377 271 183 minecraft:stone_bricks
fill 377 271 184 377 272 184 minecraft:mossy_cobblestone
setblock 377 271 188 minecraft:stone_bricks
fill 377 271 189 377 272 189 minecraft:mossy_cobblestone
setblock 377 271 193 minecraft:stone_bricks
fill 377 271 194 377 272 195 minecraft:mossy_cobblestone
setblock 377 271 199 minecraft:mossy_cobblestone
setblock 377 271 203 minecraft:stone_bricks
fill 377 271 204 377 272 204 minecraft:mossy_cobblestone
setblock 377 271 208 minecraft:stone_bricks
fill 377 271 209 377 272 209 minecraft:mossy_cobblestone
setblock 377 271 213 minecraft:stone_bricks
fill 377 271 214 377 272 214 minecraft:mossy_cobblestone
setblock 377 271 218 minecraft:stone_bricks
fill 377 271 219 377 272 219 minecraft:mossy_cobblestone
setblock 378 271 182 minecraft:stone_bricks
setblock 378 271 183 minecraft:mossy_cobblestone
setblock 378 271 187 minecraft:stone_bricks
fill 378 271 188 378 272 188 minecraft:mossy_cobblestone
setblock 378 271 203 minecraft:mossy_cobblestone
setblock 378 271 207 minecraft:stone_bricks
fill 378 271 208 378 272 208 minecraft:mossy_cobblestone
setblock 378 271 212 minecraft:stone_bricks
fill 378 271 213 378 272 213 minecraft:mossy_cobblestone
setblock 378 271 217 minecraft:stone_bricks
fill 378 271 218 378 272 218 minecraft:mossy_cobblestone
setblock 378 271 222 minecraft:stone_bricks
setblock 379 271 182 minecraft:mossy_cobblestone
setblock 379 271 206 minecraft:stone_bricks
fill 379 271 207 379 272 207 minecraft:mossy_cobblestone
setblock 379 271 211 minecraft:stone_bricks
fill 379 271 212 379 272 212 minecraft:mossy_cobblestone
setblock 379 271 215 minecraft:mossy_cobblestone
fill 379 271 222 379 272 222 minecraft:mossy_cobblestone
fill 389 271 182 389 272 182 minecraft:mossy_cobblestone
setblock 392 271 183 minecraft:stone_bricks
setblock 392 271 222 minecraft:mossy_cobblestone
setblock 393 271 182 minecraft:stone_bricks
fill 393 271 183 393 272 184 minecraft:mossy_cobblestone
setblock 393 271 222 minecraft:stone_bricks
fill 394 271 182 397 271 182 minecraft:mossy_cobblestone
fill 394 271 184 395 271 184 minecraft:mossy_cobblestone
fill 394 271 222 394 272 222 minecraft:mossy_cobblestone
setblock 396 271 184 minecraft:stone_bricks
setblock 397 271 183 minecraft:stone_bricks
fill 397 271 184 397 272 184 minecraft:mossy_cobblestone
setblock 398 271 182 minecraft:stone_bricks
fill 398 271 183 398 272 183 minecraft:mossy_cobblestone
fill 399 271 182 399 272 182 minecraft:mossy_cobblestone
setblock 402 271 183 minecraft:stone_bricks
setblock 403 271 182 minecraft:stone_bricks
setblock 403 271 183 minecraft:mossy_cobblestone
fill 404 271 182 404 272 182 minecraft:mossy_cobblestone
setblock 407 271 183 minecraft:stone_bricks
fill 407 271 184 407 272 184 minecraft:mossy_cobblestone
setblock 408 271 182 minecraft:stone_bricks
fill 408 271 183 408 272 183 minecraft:mossy_cobblestone
fill 409 271 182 409 272 182 minecraft:mossy_cobblestone
fill 409 271 222 409 272 222 minecraft:mossy_cobblestone
setblock 410 271 185 minecraft:stone_bricks
setblock 411 271 184 minecraft:stone_bricks
fill 411 271 185 411 272 185 minecraft:mossy_cobblestone
fill 411 271 221 411 272 221 minecraft:mossy_cobblestone
setblock 412 271 183 minecraft:stone_bricks
fill 412 271 184 412 272 184 minecraft:mossy_cobblestone
setblock 413 271 182 minecraft:stone_bricks
fill 413 271 183 413 272 183 minecraft:mossy_cobblestone
setblock 413 271 222 minecraft:stone_bricks
fill 414 271 182 414 272 182 minecraft:mossy_cobblestone
setblock 414 271 186 minecraft:stone_bricks
fill 414 271 187 414 272 187 minecraft:mossy_cobblestone
setblock 414 271 190 minecraft:mossy_cobblestone
setblock 414 271 221 minecraft:stone_bricks
fill 414 271 222 414 272 222 minecraft:mossy_cobblestone
setblock 415 271 185 minecraft:stone_bricks
fill 415 271 186 415 272 186 minecraft:mossy_cobblestone
setblock 415 271 189 minecraft:mossy_cobblestone
setblock 415 271 190 minecraft:stone_bricks
fill 415 271 191 415 272 192 minecraft:mossy_cobblestone
fill 415 271 208 415 271 209 minecraft:mossy_cobblestone
setblock 415 271 210 minecraft:stone_bricks
fill 415 271 211 415 272 211 minecraft:mossy_cobblestone
setblock 415 271 214 minecraft:mossy_cobblestone
setblock 415 271 215 minecraft:stone_bricks
fill 415 271 216 415 272 216 minecraft:mossy_cobblestone
fill 415 271 221 415 272 221 minecraft:mossy_cobblestone
setblock 416 271 184 minecraft:stone_bricks
fill 416 271 185 416 272 185 minecraft:mossy_cobblestone
setblock 416 271 189 minecraft:stone_bricks
fill 416 271 190 416 272 190 minecraft:mossy_cobblestone
setblock 416 271 194 minecraft:stone_bricks
setblock 416 271 204 minecraft:stone_bricks
fill 416 271 205 416 272 205 minecraft:mossy_cobblestone
setblock 416 271 209 minecraft:stone_bricks
fill 416 271 210 416 272 210 minecraft:mossy_cobblestone
setblock 416 271 213 minecraft:mossy_cobblestone
setblock 416 271 214 minecraft:stone_bricks
fill 416 271 215 416 272 215 minecraft:mossy_cobblestone
setblock 416 271 219 minecraft:stone_bricks
fill 416 271 220 416 272 220 minecraft:mossy_cobblestone
setblock 417 271 183 minecraft:stone_bricks
fill 417 271 184 417 272 184 minecraft:mossy_cobblestone
setblock 417 271 188 minecraft:stone_bricks
fill 417 271 189 417 272 189 minecraft:mossy_cobblestone
setblock 417 271 193 minecraft:stone_bricks
fill 417 271 194 417 272 194 minecraft:mossy_cobblestone
fill 417 271 196 417 272 196 minecraft:mossy_cobblestone
setblock 417 271 203 minecraft:stone_bricks
fill 417 271 204 417 272 204 minecraft:mossy_cobblestone
setblock 417 271 208 minecraft:stone_bricks
fill 417 271 209 417 272 209 minecraft:mossy_cobblestone
setblock 417 271 213 minecraft:stone_bricks
fill 417 271 214 417 272 214 minecraft:mossy_cobblestone
setblock 417 271 218 minecraft:stone_bricks
fill 417 271 219 417 272 219 minecraft:mossy_cobblestone
setblock 377 272 182 minecraft:stone_bricks
setblock 377 272 183 minecraft:mossy_cobblestone
setblock 377 272 187 minecraft:stone_bricks
setblock 377 272 188 minecraft:mossy_cobblestone
setblock 377 272 192 minecraft:stone_bricks
setblock 377 272 193 minecraft:mossy_cobblestone
setblock 377 272 196 minecraft:mossy_cobblestone
setblock 377 272 202 minecraft:stone_bricks
setblock 377 272 203 minecraft:mossy_cobblestone
setblock 377 272 207 minecraft:stone_bricks
setblock 377 272 208 minecraft:mossy_cobblestone
setblock 377 272 212 minecraft:stone_bricks
setblock 377 272 213 minecraft:mossy_cobblestone
setblock 377 272 217 minecraft:stone_bricks
setblock 377 272 218 minecraft:mossy_cobblestone
setblock 377 272 222 minecraft:stone_bricks
setblock 378 272 182 minecraft:mossy_cobblestone
setblock 378 272 186 minecraft:stone_bricks
setblock 378 272 187 minecraft:mossy_cobblestone
setblock 378 272 206 minecraft:stone_bricks
setblock 378 272 207 minecraft:mossy_cobblestone
setblock 378 272 211 minecraft:stone_bricks
setblock 378 272 212 minecraft:mossy_cobblestone
setblock 378 272 216 minecraft:stone_bricks
setblock 378 272 217 minecraft:mossy_cobblestone
setblock 378 272 222 minecraft:mossy_cobblestone
setblock 379 272 206 minecraft:mossy_cobblestone
setblock 379 272 210 minecraft:stone_bricks
setblock 379 272 211 minecraft:mossy_cobblestone
setblock 379 272 215 minecraft:stone_bricks
setblock 391 272 183 minecraft:stone_bricks
setblock 392 272 182 minecraft:stone_bricks
setblock 392 272 183 minecraft:mossy_cobblestone
setblock 392 272 222 minecraft:stone_bricks
fill 393 272 182 396 272 182 minecraft:mossy_cobblestone
setblock 393 272 222 minecraft:mossy_cobblestone
setblock 394 272 184 minecraft:mossy_cobblestone
setblock 395 272 184 minecraft:stone_bricks
setblock 396 272 183 minecraft:stone_bricks
setblock 396 272 184 minecraft:mossy_cobblestone
setblock 397 272 182 minecraft:stone_bricks
setblock 397 272 183 minecraft:mossy_cobblestone
setblock 398 272 182 minecraft:mossy_cobblestone
setblock 402 272 182 minecraft:stone_bricks
setblock 403 272 182 minecraft:mossy_cobblestone
setblock 406 272 183 minecraft:stone_bricks
setblock 407 272 182 minecraft:stone_bricks
setblock 407 272 183 minecraft:mossy_cobblestone
setblock 408 272 182 minecraft:mossy_cobblestone
setblock 408 272 222 minecraft:mossy_cobblestone
setblock 410 272 184 minecraft:stone_bricks
setblock 410 272 185 minecraft:mossy_cobblestone
setblock 411 272 183 minecraft:stone_bricks
setblock 411 272 184 minecraft:mossy_cobblestone
setblock 412 272 182 minecraft:stone_bricks
setblock 412 272 183 minecraft:mossy_cobblestone
setblock 412 272 222 minecraft:stone_bricks
setblock 413 272 182 minecraft:mossy_cobblestone
setblock 413 272 221 minecraft:stone_bricks
setblock 413 272 222 minecraft:mossy_cobblestone
setblock 414 272 185 minecraft:stone_bricks
setblock 414 272 186 minecraft:mossy_cobblestone
setblock 414 272 190 minecraft:stone_bricks
setblock 414 272 221 minecraft:mossy_cobblestone
setblock 415 272 184 minecraft:stone_bricks
setblock 415 272 185 minecraft:mossy_cobblestone
setblock 415 272 189 minecraft:stone_bricks
setblock 415 272 190 minecraft:mossy_cobblestone
setblock 415 272 208 minecraft:mossy_cobblestone
setblock 415 272 209 minecraft:stone_bricks
setblock 415 272 210 minecraft:mossy_cobblestone
setblock 415 272 214 minecraft:stone_bricks
setblock 415 272 215 minecraft:mossy_cobblestone
fill 415 272 217 415 272 218 minecraft:mossy_cobblestone
setblock 416 272 183 minecraft:stone_bricks
setblock 416 272 184 minecraft:mossy_cobblestone
setblock 416 272 188 minecraft:stone_bricks
setblock 416 272 189 minecraft:mossy_cobblestone
setblock 416 272 192 minecraft:mossy_cobblestone
setblock 416 272 193 minecraft:stone_bricks
setblock 416 272 194 minecraft:mossy_cobblestone
setblock 416 272 208 minecraft:stone_bricks
setblock 416 272 209 minecraft:mossy_cobblestone
setblock 416 272 213 minecraft:stone_bricks
setblock 416 272 214 minecraft:mossy_cobblestone
setblock 416 272 217 minecraft:mossy_cobblestone
setblock 416 272 218 minecraft:stone_bricks
setblock 416 272 219 minecraft:mossy_cobblestone
setblock 417 272 182 minecraft:stone_bricks
setblock 417 272 183 minecraft:mossy_cobblestone
setblock 417 272 187 minecraft:stone_bricks
setblock 417 272 188 minecraft:mossy_cobblestone
setblock 417 272 192 minecraft:stone_bricks
setblock 417 272 193 minecraft:mossy_cobblestone
setblock 417 272 203 minecraft:mossy_cobblestone
setblock 417 272 207 minecraft:stone_bricks
setblock 417 272 208 minecraft:mossy_cobblestone
setblock 417 272 212 minecraft:stone_bricks
setblock 417 272 213 minecraft:mossy_cobblestone
setblock 417 272 217 minecraft:stone_bricks
setblock 417 272 218 minecraft:mossy_cobblestone
setblock 417 272 222 minecraft:stone_bricks
setblock 379 273 184 minecraft:light[level=12]
setblock 379 273 192 minecraft:light[level=12]
setblock 379 273 200 minecraft:light[level=12]
setblock 379 273 208 minecraft:light[level=12]
setblock 379 273 216 minecraft:light[level=12]
setblock 387 273 184 minecraft:light[level=12]
setblock 387 273 192 minecraft:light[level=12]
setblock 387 273 200 minecraft:light[level=12]
setblock 387 273 208 minecraft:light[level=12]
setblock 387 273 216 minecraft:light[level=12]
setblock 395 273 184 minecraft:light[level=12]
setblock 395 273 192 minecraft:light[level=12]
setblock 395 273 208 minecraft:light[level=12]
setblock 395 273 216 minecraft:light[level=12]
setblock 403 273 184 minecraft:light[level=12]
setblock 403 273 192 minecraft:light[level=12]
setblock 403 273 200 minecraft:light[level=12]
setblock 403 273 208 minecraft:light[level=12]
setblock 403 273 216 minecraft:light[level=12]
setblock 411 273 184 minecraft:light[level=12]
setblock 411 273 192 minecraft:light[level=12]
setblock 411 273 200 minecraft:light[level=12]
setblock 411 273 208 minecraft:light[level=12]
setblock 411 273 216 minecraft:light[level=12]
fill 377 278 182 379 279 192 minecraft:cobbled_deepslate
fill 377 278 193 417 279 193 minecraft:spruce_log
fill 377 278 194 379 279 204 minecraft:cobbled_deepslate
fill 377 278 205 417 279 205 minecraft:spruce_log
fill 377 278 206 379 279 216 minecraft:cobbled_deepslate
fill 377 278 217 417 279 217 minecraft:spruce_log
fill 377 278 218 379 279 222 minecraft:cobbled_deepslate
fill 380 278 182 380 279 192 minecraft:spruce_planks
fill 380 278 194 380 279 204 minecraft:spruce_planks
fill 380 278 206 380 279 216 minecraft:spruce_planks
fill 380 278 218 380 279 222 minecraft:spruce_planks
fill 381 278 182 383 279 192 minecraft:cobbled_deepslate
fill 381 278 194 383 279 204 minecraft:cobbled_deepslate
fill 381 278 206 383 279 216 minecraft:cobbled_deepslate
fill 381 278 218 383 279 222 minecraft:cobbled_deepslate
fill 384 278 182 384 279 192 minecraft:spruce_planks
fill 384 278 194 384 279 204 minecraft:spruce_planks
fill 384 278 206 384 279 216 minecraft:spruce_planks
fill 384 278 218 384 279 222 minecraft:spruce_planks
fill 385 278 182 387 279 192 minecraft:cobbled_deepslate
fill 385 278 194 387 279 204 minecraft:cobbled_deepslate
fill 385 278 206 387 279 216 minecraft:cobbled_deepslate
fill 385 278 218 387 279 222 minecraft:cobbled_deepslate
fill 388 278 182 388 279 192 minecraft:spruce_planks
fill 388 278 194 388 279 204 minecraft:spruce_planks
fill 388 278 206 388 279 216 minecraft:spruce_planks
fill 388 278 218 388 279 222 minecraft:spruce_planks
fill 389 278 182 391 279 192 minecraft:cobbled_deepslate
fill 389 278 194 391 279 204 minecraft:cobbled_deepslate
fill 389 278 206 391 279 216 minecraft:cobbled_deepslate
fill 389 278 218 391 279 222 minecraft:cobbled_deepslate
fill 392 278 182 392 279 192 minecraft:spruce_planks
fill 392 278 194 392 278 204 minecraft:spruce_planks
fill 392 278 206 392 279 216 minecraft:spruce_planks
fill 392 278 218 392 279 222 minecraft:spruce_planks
fill 393 278 182 395 279 192 minecraft:cobbled_deepslate
fill 393 278 194 393 278 199 minecraft:cobbled_deepslate
fill 393 278 201 393 278 204 minecraft:cobbled_deepslate
fill 393 278 206 395 279 216 minecraft:cobbled_deepslate
fill 393 278 218 395 279 222 minecraft:cobbled_deepslate
fill 394 278 194 395 278 197 minecraft:cobbled_deepslate
fill 394 278 203 395 278 204 minecraft:cobbled_deepslate
fill 396 278 182 396 279 192 minecraft:spruce_planks
fill 396 278 194 396 278 196 minecraft:spruce_planks
setblock 396 278 204 minecraft:spruce_planks
fill 396 278 206 396 279 216 minecraft:spruce_planks
fill 396 278 218 396 279 222 minecraft:spruce_planks
fill 397 278 182 399 279 192 minecraft:cobbled_deepslate
fill 397 278 194 399 278 197 minecraft:cobbled_deepslate
fill 397 278 203 399 278 204 minecraft:cobbled_deepslate
fill 397 278 206 399 279 216 minecraft:cobbled_deepslate
fill 397 278 218 399 279 222 minecraft:cobbled_deepslate
fill 399 278 198 399 278 199 minecraft:cobbled_deepslate
fill 399 278 201 399 278 202 minecraft:cobbled_deepslate
fill 400 278 182 400 279 192 minecraft:spruce_planks
fill 400 278 194 400 278 204 minecraft:spruce_planks
fill 400 278 206 400 279 216 minecraft:spruce_planks
fill 400 278 218 400 279 222 minecraft:spruce_planks
fill 401 278 182 403 279 192 minecraft:cobbled_deepslate
fill 401 278 194 403 279 204 minecraft:cobbled_deepslate
fill 401 278 206 403 279 216 minecraft:cobbled_deepslate
fill 401 278 218 403 279 222 minecraft:cobbled_deepslate
fill 404 278 182 404 279 192 minecraft:spruce_planks
fill 404 278 194 404 279 204 minecraft:spruce_planks
fill 404 278 206 404 279 216 minecraft:spruce_planks
fill 404 278 218 404 279 222 minecraft:spruce_planks
fill 405 278 182 407 279 192 minecraft:cobbled_deepslate
fill 405 278 194 407 279 204 minecraft:cobbled_deepslate
fill 405 278 206 407 279 216 minecraft:cobbled_deepslate
fill 405 278 218 407 279 222 minecraft:cobbled_deepslate
fill 408 278 182 408 279 192 minecraft:spruce_planks
fill 408 278 194 408 279 204 minecraft:spruce_planks
fill 408 278 206 408 279 216 minecraft:spruce_planks
fill 408 278 218 408 279 222 minecraft:spruce_planks
fill 409 278 182 411 279 192 minecraft:cobbled_deepslate
fill 409 278 194 411 279 204 minecraft:cobbled_deepslate
fill 409 278 206 411 279 216 minecraft:cobbled_deepslate
fill 409 278 218 411 279 222 minecraft:cobbled_deepslate
fill 412 278 182 412 279 192 minecraft:spruce_planks
fill 412 278 194 412 279 204 minecraft:spruce_planks
fill 412 278 206 412 279 216 minecraft:spruce_planks
fill 412 278 218 412 279 222 minecraft:spruce_planks
fill 413 278 182 415 279 192 minecraft:cobbled_deepslate
fill 413 278 194 415 279 204 minecraft:cobbled_deepslate
fill 413 278 206 415 279 216 minecraft:cobbled_deepslate
fill 413 278 218 415 279 222 minecraft:cobbled_deepslate
fill 416 278 182 416 279 192 minecraft:spruce_planks
fill 416 278 194 416 279 204 minecraft:spruce_planks
fill 416 278 206 416 279 216 minecraft:spruce_planks
fill 416 278 218 416 279 222 minecraft:spruce_planks
fill 417 278 182 417 279 192 minecraft:cobbled_deepslate
fill 417 278 194 417 279 204 minecraft:cobbled_deepslate
fill 417 278 206 417 279 216 minecraft:cobbled_deepslate
fill 417 278 218 417 279 222 minecraft:cobbled_deepslate
fill 392 279 194 392 279 198 minecraft:spruce_planks
fill 392 279 199 392 279 201 minecraft:lantern
fill 392 279 202 392 279 204 minecraft:spruce_planks
fill 393 279 194 394 279 196 minecraft:cobbled_deepslate
fill 393 279 197 393 279 199 minecraft:lantern
fill 393 279 201 393 279 203 minecraft:lantern
fill 393 279 204 394 279 204 minecraft:cobbled_deepslate
fill 394 279 197 395 279 197 minecraft:lantern
fill 394 279 203 395 279 203 minecraft:lantern
fill 395 279 194 395 279 195 minecraft:cobbled_deepslate
fill 395 279 196 397 279 196 minecraft:lantern
fill 395 279 204 397 279 204 minecraft:lantern
fill 396 279 194 396 279 195 minecraft:spruce_planks
fill 397 279 194 399 279 195 minecraft:cobbled_deepslate
fill 397 279 197 399 279 197 minecraft:lantern
fill 397 279 203 399 279 203 minecraft:lantern
fill 398 279 196 399 279 196 minecraft:cobbled_deepslate
fill 398 279 204 399 279 204 minecraft:cobbled_deepslate
fill 399 279 198 399 279 199 minecraft:lantern
fill 399 279 201 399 279 202 minecraft:lantern
fill 400 279 194 400 279 198 minecraft:spruce_planks
fill 400 279 199 400 279 201 minecraft:lantern
fill 400 279 202 400 279 204 minecraft:spruce_planks
setblock 379 281 184 minecraft:light[level=12]
setblock 379 281 192 minecraft:light[level=12]
setblock 379 281 200 minecraft:light[level=12]
setblock 379 281 208 minecraft:light[level=12]
setblock 379 281 216 minecraft:light[level=12]
setblock 387 281 184 minecraft:light[level=12]
setblock 387 281 192 minecraft:light[level=12]
setblock 387 281 200 minecraft:light[level=12]
setblock 387 281 208 minecraft:light[level=12]
setblock 387 281 216 minecraft:light[level=12]
setblock 395 281 184 minecraft:light[level=12]
setblock 395 281 192 minecraft:light[level=12]
setblock 395 281 208 minecraft:light[level=12]
setblock 395 281 216 minecraft:light[level=12]
setblock 403 281 184 minecraft:light[level=12]
setblock 403 281 192 minecraft:light[level=12]
setblock 403 281 200 minecraft:light[level=12]
setblock 403 281 208 minecraft:light[level=12]
setblock 403 281 216 minecraft:light[level=12]
setblock 411 281 184 minecraft:light[level=12]
setblock 411 281 192 minecraft:light[level=12]
setblock 411 281 200 minecraft:light[level=12]
setblock 411 281 208 minecraft:light[level=12]
setblock 411 281 216 minecraft:light[level=12]
fill 377 283 194 377 283 195 minecraft:mossy_cobblestone
setblock 377 283 196 minecraft:stone_bricks
fill 377 283 197 377 283 200 minecraft:mossy_cobblestone
setblock 377 283 201 minecraft:stone_bricks
fill 377 283 202 377 285 203 minecraft:mossy_cobblestone
setblock 377 283 211 minecraft:stone_bricks
fill 377 283 212 377 283 215 minecraft:mossy_cobblestone
setblock 377 283 216 minecraft:stone_bricks
fill 377 283 217 377 283 220 minecraft:mossy_cobblestone
setblock 377 283 221 minecraft:stone_bricks
fill 378 283 197 378 284 198 minecraft:mossy_cobblestone
fill 382 283 222 385 283 222 minecraft:mossy_cobblestone
setblock 385 283 182 minecraft:mossy_cobblestone
fill 385 283 221 386 283 221 minecraft:mossy_cobblestone
setblock 386 283 182 minecraft:stone_bricks
setblock 386 283 222 minecraft:stone_bricks
fill 387 283 182 390 283 182 minecraft:mossy_cobblestone
setblock 387 283 221 minecraft:stone_bricks
fill 387 283 222 390 283 222 minecraft:mossy_cobblestone
fill 388 283 221 390 284 221 minecraft:mossy_cobblestone
setblock 391 283 182 minecraft:stone_bricks
fill 391 283 184 391 298 184 minecraft:spruce_log
setblock 391 283 222 minecraft:stone_bricks
fill 392 283 182 394 284 182 minecraft:mossy_cobblestone
fill 392 283 222 393 285 222 minecraft:mossy_cobblestone
fill 399 283 182 400 283 182 minecraft:mossy_cobblestone
fill 399 283 222 400 283 222 minecraft:mossy_cobblestone
setblock 401 283 182 minecraft:stone_bricks
setblock 401 283 222 minecraft:stone_bricks
fill 402 283 182 405 283 182 minecraft:mossy_cobblestone
setblock 402 283 221 minecraft:stone_bricks
fill 402 283 222 405 283 222 minecraft:mossy_cobblestone
setblock 403 283 220 minecraft:stone_bricks
fill 403 283 221 406 283 221 minecraft:mossy_cobblestone
setblock 404 283 183 minecraft:mossy_cobblestone
fill 404 283 220 407 283 220 minecraft:mossy_cobblestone
setblock 405 283 183 minecraft:stone_bricks
setblock 406 283 182 minecraft:stone_bricks
fill 406 283 183 409 283 183 minecraft:mossy_cobblestone
fill 406 283 219 408 283 219 minecraft:mossy_cobblestone
setblock 406 283 222 minecraft:stone_bricks
fill 407 283 182 410 283 182 minecraft:mossy_cobblestone
setblock 407 283 221 minecraft:stone_bricks
fill 407 283 222 410 283 222 minecraft:mossy_cobblestone
setblock 408 283 220 minecraft:stone_bricks
fill 408 283 221 411 283 221 minecraft:mossy_cobblestone
setblock 409 283 219 minecraft:stone_bricks
fill 409 283 220 412 283 220 minecraft:mossy_cobblestone
setblock 410 283 183 minecraft:stone_bricks
fill 410 283 219 412 284 219 minecraft:mossy_cobblestone
setblock 411 283 182 minecraft:stone_bricks
setblock 411 283 222 minecraft:stone_bricks
fill 412 283 182 413 285 182 minecraft:mossy_cobblestone
setblock 412 283 221 minecraft:stone_bricks
fill 412 283 222 415 283 222 minecraft:mossy_cobblestone
setblock 413 283 220 minecraft:stone_bricks
fill 413 283 221 416 283 221 minecraft:mossy_cobblestone
fill 414 283 220 414 286 220 minecraft:mossy_cobblestone
setblock 415 283 217 minecraft:mossy_cobblestone
setblock 415 283 218 minecraft:stone_bricks
fill 415 283 219 417 284 219 minecraft:mossy_cobblestone
fill 416 283 214 416 283 216 minecraft:mossy_cobblestone
setblock 416 283 217 minecraft:stone_bricks
fill 416 283 218 417 285 218 minecraft:mossy_cobblestone
fill 416 283 220 417 283 220 minecraft:mossy_cobblestone
setblock 416 283 222 minecraft:stone_bricks
setblock 417 283 211 minecraft:stone_bricks
fill 417 283 212 417 283 215 minecraft:mossy_cobblestone
setblock 417 283 216 minecraft:stone_bricks
fill 417 283 217 417 286 217 minecraft:mossy_cobblestone
setblock 417 283 221 minecraft:stone_bricks
fill 417 283 222 417 286 222 minecraft:mossy_cobblestone
setblock 377 284 194 minecraft:mossy_cobblestone
setblock 377 284 195 minecraft:stone_bricks
fill 377 284 196 377 284 199 minecraft:mossy_cobblestone
setblock 377 284 200 minecraft:stone_bricks
fill 377 284 201 378 286 201 minecraft:mossy_cobblestone
setblock 377 284 204 minecraft:mossy_cobblestone
setblock 377 284 205 minecraft:stone_bricks
fill 377 284 211 377 284 214 minecraft:mossy_cobblestone
setblock 377 284 215 minecraft:stone_bricks
fill 377 284 216 377 284 219 minecraft:mossy_cobblestone
setblock 377 284 220 minecraft:stone_bricks
fill 377 284 221 377 287 221 minecraft:mossy_cobblestone
fill 378 284 196 378 286 196 minecraft:mossy_cobblestone
setblock 378 284 199 minecraft:stone_bricks
fill 378 284 200 378 287 200 minecraft:mossy_cobblestone
setblock 380 284 222 minecraft:stone_bricks
fill 381 284 222 384 284 222 minecraft:mossy_cobblestone
fill 383 284 182 384 284 182 minecraft:mossy_cobblestone
fill 383 284 221 385 284 221 minecraft:mossy_cobblestone
setblock 385 284 182 minecraft:stone_bricks
setblock 385 284 222 minecraft:stone_bricks
fill 386 284 182 389 284 182 minecraft:mossy_cobblestone
setblock 386 284 221 minecraft:stone_bricks
fill 386 284 222 389 284 222 minecraft:mossy_cobblestone
fill 387 284 183 388 284 183 minecraft:mossy_cobblestone
fill 387 284 221 387 287 221 minecraft:mossy_cobblestone
setblock 389 284 183 minecraft:stone_bricks
setblock 390 284 182 minecraft:stone_bricks
fill 390 284 183 390 287 183 minecraft:mossy_cobblestone
setblock 390 284 222 minecraft:stone_bricks
fill 391 284 182 391 287 182 minecraft:mossy_cobblestone
setblock 391 284 221 minecraft:stone_bricks
fill 391 284 222 391 287 222 minecraft:mossy_cobblestone
setblock 394 284 222 minecraft:mossy_cobblestone
setblock 395 284 182 minecraft:stone_bricks
setblock 395 284 222 minecraft:stone_bricks
fill 396 284 182 399 284 182 minecraft:mossy_cobblestone
fill 396 284 222 399 284 222 minecraft:mossy_cobblestone
setblock 400 284 182 minecraft:stone_bricks
setblock 400 284 221 minecraft:mossy_cobblestone
setblock 400 284 222 minecraft:stone_bricks
fill 401 284 182 404 284 182 minecraft:mossy_cobblestone
setblock 401 284 221 minecraft:stone_bricks
fill 401 284 222 404 284 222 minecraft:mossy_cobblestone
fill 402 284 183 403 284 183 minecraft:mossy_cobblestone
setblock 402 284 220 minecraft:stone_bricks
fill 402 284 221 405 284 221 minecraft:mossy_cobblestone
fill 403 284 220 406 284 220 minecraft:mossy_cobblestone
setblock 404 284 183 minecraft:stone_bricks
setblock 405 284 182 minecraft:stone_bricks
fill 405 284 183 408 284 183 minecraft:mossy_cobblestone
fill 405 284 219 407 284 219 minecraft:mossy_cobblestone
setblock 405 284 222 minecraft:stone_bricks
fill 406 284 182 409 284 182 minecraft:mossy_cobblestone
setblock 406 284 221 minecraft:stone_bricks
fill 406 284 222 409 284 222 minecraft:mossy_cobblestone
setblock 407 284 220 minecraft:stone_bricks
fill 407 284 221 410 284 221 minecraft:mossy_cobblestone
setblock 408 284 219 minecraft:stone_bricks
fill 408 284 220 411 284 220 minecraft:mossy_cobblestone
setblock 409 284 183 minecraft:stone_bricks
fill 409 284 219 409 287 219 minecraft:mossy_cobblestone
setblock 410 284 182 minecraft:stone_bricks
fill 410 284 183 410 287 183 minecraft:mossy_cobblestone
setblock 410 284 222 minecraft:stone_bricks
fill 411 284 182 411 287 182 minecraft:mossy_cobblestone
setblock 411 284 221 minecraft:stone_bricks
fill 411 284 222 414 284 222 minecraft:mossy_cobblestone
setblock 412 284 220 minecraft:stone_bricks
fill 412 284 221 415 284 221 minecraft:mossy_cobblestone
fill 413 284 220 413 287 220 minecraft:mossy_cobblestone
setblock 415 284 217 minecraft:stone_bricks
fill 415 284 218 415 286 218 minecraft:mossy_cobblestone
fill 415 284 220 416 284 220 minecraft:mossy_cobblestone
setblock 415 284 222 minecraft:stone_bricks
fill 416 284 214 416 284 215 minecraft:mossy_cobblestone
setblock 416 284 216 minecraft:stone_bricks
fill 416 284 217 416 287 217 minecraft:mossy_cobblestone
setblock 416 284 221 minecraft:stone_bricks
fill 416 284 222 416 287 222 minecraft:mossy_cobblestone
fill 417 284 197 417 284 199 minecraft:mossy_cobblestone
setblock 417 284 200 minecraft:stone_bricks
fill 417 284 211 417 284 214 minecraft:mossy_cobblestone
setblock 417 284 215 minecraft:stone_bricks
fill 417 284 216 417 287 216 minecraft:mossy_cobblestone
setblock 417 284 220 minecraft:stone_bricks
fill 417 284 221 417 287 221 minecraft:mossy_cobblestone
setblock 377 285 193 minecraft:mossy_cobblestone
setblock 377 285 194 minecraft:stone_bricks
fill 377 285 195 377 285 198 minecraft:mossy_cobblestone
setblock 377 285 199 minecraft:stone_bricks
fill 377 285 200 377 288 200 minecraft:mossy_cobblestone
setblock 377 285 204 minecraft:stone_bricks
fill 377 285 205 377 286 207 minecraft:mossy_cobblestone
fill 377 285 211 377 285 213 minecraft:mossy_cobblestone
setblock 377 285 214 minecraft:stone_bricks
fill 377 285 215 377 285 218 minecraft:mossy_cobblestone
setblock 377 285 219 minecraft:stone_bricks
fill 377 285 220 377 288 220 minecraft:mossy_cobblestone
fill 377 285 222 378 285 222 minecraft:mossy_cobblestone
fill 378 285 195 378 287 195 minecraft:mossy_cobblestone
setblock 378 285 197 minecraft:mossy_cobblestone
setblock 378 285 198 minecraft:stone_bricks
fill 378 285 199 379 287 199 minecraft:mossy_cobblestone
setblock 378 285 202 minecraft:mossy_cobblestone
setblock 378 285 203 minecraft:stone_bricks
setblock 379 285 197 minecraft:stone_bricks
fill 379 285 198 379 288 198 minecraft:mossy_cobblestone
fill 379 285 200 379 286 200 minecraft:mossy_cobblestone
setblock 379 285 222 minecraft:stone_bricks
fill 380 285 222 383 285 222 minecraft:mossy_cobblestone
fill 381 285 221 384 285 221 minecraft:mossy_cobblestone
fill 382 285 182 383 285 182 minecraft:mossy_cobblestone
setblock 384 285 182 minecraft:stone_bricks
setblock 384 285 222 minecraft:stone_bricks
fill 385 285 182 387 285 183 minecraft:mossy_cobblestone
setblock 385 285 220 minecraft:mossy_cobblestone
setblock 385 285 221 minecraft:stone_bricks
fill 385 285 222 388 285 222 minecraft:mossy_cobblestone
setblock 386 285 220 minecraft:stone_bricks
fill 386 285 221 386 288 221 minecraft:mossy_cobblestone
fill 387 285 220 387 287 220 minecraft:mossy_cobblestone
setblock 388 285 182 minecraft:mossy_cobblestone
setblock 388 285 183 minecraft:stone_bricks
fill 388 285 221 389 285 221 minecraft:mossy_cobblestone
setblock 389 285 182 minecraft:stone_bricks
fill 389 285 183 389 288 183 minecraft:mossy_cobblestone
setblock 389 285 222 minecraft:stone_bricks
fill 390 285 182 390 288 182 minecraft:mossy_cobblestone
setblock 390 285 221 minecraft:stone_bricks
fill 390 285 222 390 288 222 minecraft:mossy_cobblestone
fill 391 285 183 391 286 183 minecraft:mossy_cobblestone
fill 391 285 221 392 287 221 minecraft:mossy_cobblestone
fill 392 285 182 393 285 182 minecraft:mossy_cobblestone
setblock 394 285 182 minecraft:stone_bricks
setblock 394 285 222 minecraft:stone_bricks
fill 395 285 182 398 285 182 minecraft:mossy_cobblestone
fill 395 285 222 398 285 222 minecraft:mossy_cobblestone
fill 398 285 221 399 285 221 minecraft:mossy_cobblestone
setblock 399 285 182 minecraft:stone_bricks
setblock 399 285 222 minecraft:stone_bricks
fill 400 285 182 402 285 183 minecraft:mossy_cobblestone
setblock 400 285 221 minecraft:stone_bricks
fill 400 285 222 403 285 222 minecraft:mossy_cobblestone
setblock 401 285 220 minecraft:stone_bricks
fill 401 285 221 404 285 221 minecraft:mossy_cobblestone
fill 402 285 220 405 285 220 minecraft:mossy_cobblestone
setblock 403 285 182 minecraft:mossy_cobblestone
setblock 403 285 183 minecraft:stone_bricks
setblock 404 285 182 minecraft:stone_bricks
fill 404 285 183 407 285 183 minecraft:mossy_cobblestone
fill 404 285 219 406 285 219 minecraft:mossy_cobblestone
setblock 404 285 222 minecraft:stone_bricks
fill 405 285 182 408 285 182 minecraft:mossy_cobblestone
fill 405 285 184 406 285 184 minecraft:mossy_cobblestone
setblock 405 285 221 minecraft:stone_bricks
fill 405 285 222 408 285 222 minecraft:mossy_cobblestone
setblock 406 285 220 minecraft:stone_bricks
fill 406 285 221 409 285 221 minecraft:mossy_cobblestone
setblock 407 285 219 minecraft:stone_bricks
fill 407 285 220 410 285 220 minecraft:mossy_cobblestone
setblock 408 285 183 minecraft:stone_bricks
fill 408 285 219 408 288 219 minecraft:mossy_cobblestone
setblock 409 285 182 minecraft:stone_bricks
fill 409 285 183 409 288 183 minecraft:mossy_cobblestone
setblock 409 285 222 minecraft:stone_bricks
fill 410 285 182 410 288 182 minecraft:mossy_cobblestone
fill 410 285 219 411 285 219 minecraft:mossy_cobblestone
setblock 410 285 221 minecraft:stone_bricks
fill 410 285 222 413 285 222 minecraft:mossy_cobblestone
setblock 411 285 220 minecraft:stone_bricks
fill 411 285 221 414 285 221 minecraft:mossy_cobblestone
setblock 412 285 219 minecraft:stone_bricks
fill 412 285 220 412 288 220 minecraft:mossy_cobblestone
setblock 414 285 182 minecraft:stone_bricks
setblock 414 285 222 minecraft:stone_bricks
setblock 415 285 217 minecraft:mossy_cobblestone
fill 415 285 219 415 285 220 minecraft:mossy_cobblestone
setblock 415 285 221 minecraft:stone_bricks
fill 415 285 222 415 288 222 minecraft:mossy_cobblestone
setblock 416 285 214 minecraft:mossy_cobblestone
setblock 416 285 215 minecraft:stone_bricks
fill 416 285 216 416 287 216 minecraft:mossy_cobblestone
setblock 416 285 219 minecraft:mossy_cobblestone
setblock 416 285 220 minecraft:stone_bricks
fill 416 285 221 416 288 221 minecraft:mossy_cobblestone
fill 417 285 196 417 285 198 minecraft:mossy_cobblestone
setblock 417 285 199 minecraft:stone_bricks
fill 417 285 200 417 285 203 minecraft:mossy_cobblestone
fill 417 285 211 417 285 213 minecraft:mossy_cobblestone
setblock 417 285 214 minecraft:stone_bricks
fill 417 285 215 417 288 215 minecraft:mossy_cobblestone
setblock 417 285 219 minecraft:stone_bricks
fill 417 285 220 417 288 220 minecraft:mossy_cobblestone
setblock 377 286 193 minecraft:stone_bricks
fill 377 286 194 377 286 197 minecraft:mossy_cobblestone
setblock 377 286 198 minecraft:stone_bricks
fill 377 286 199 377 289 199 minecraft:mossy_cobblestone
setblock 377 286 202 minecraft:mossy_cobblestone
setblock 377 286 203 minecraft:stone_bricks
fill 377 286 204 378 288 204 minecraft:mossy_cobblestone
setblock 377 286 208 minecraft:stone_bricks
fill 377 286 209 377 289 209 minecraft:mossy_cobblestone
setblock 377 286 212 minecraft:mossy_cobblestone
setblock 377 286 213 minecraft:stone_bricks
fill 377 286 214 377 286 217 minecraft:mossy_cobblestone
setblock 377 286 218 minecraft:stone_bricks
fill 377 286 219 377 289 219 minecraft:mossy_cobblestone
setblock 377 286 222 minecraft:mossy_cobblestone
setblock 378 286 197 minecraft:stone_bricks
fill 378 286 198 378 289 198 minecraft:mossy_cobblestone
setblock 378 286 202 minecraft:stone_bricks
fill 378 286 203 378 289 203 minecraft:mossy_cobblestone
fill 378 286 205 378 287 205 minecraft:mossy_cobblestone
setblock 378 286 222 minecraft:stone_bricks
setblock 379 286 196 minecraft:stone_bricks
fill 379 286 197 379 289 197 minecraft:mossy_cobblestone
setblock 379 286 201 minecraft:stone_bricks
fill 379 286 202 379 289 202 minecraft:mossy_cobblestone
fill 379 286 222 382 286 222 minecraft:mossy_cobblestone
fill 380 286 221 383 286 221 minecraft:mossy_cobblestone
fill 381 286 182 382 286 182 minecraft:mossy_cobblestone
setblock 383 286 182 minecraft:stone_bricks
fill 383 286 183 386 286 183 minecraft:mossy_cobblestone
setblock 383 286 222 minecraft:stone_bricks
fill 384 286 182 387 286 182 minecraft:mossy_cobblestone
setblock 384 286 220 minecraft:mossy_cobblestone
setblock 384 286 221 minecraft:stone_bricks
fill 384 286 222 387 286 222 minecraft:mossy_cobblestone
setblock 385 286 220 minecraft:stone_bricks
fill 385 286 221 385 289 221 minecraft:mossy_cobblestone
fill 386 286 220 386 287 220 minecraft:mossy_cobblestone
setblock 387 286 183 minecraft:stone_bricks
setblock 388 286 182 minecraft:stone_bricks
fill 388 286 183 388 289 183 minecraft:mossy_cobblestone
fill 388 286 220 388 286 221 minecraft:mossy_cobblestone
setblock 388 286 222 minecraft:stone_bricks
fill 389 286 182 389 289 182 minecraft:mossy_cobblestone
setblock 389 286 221 minecraft:stone_bricks
fill 389 286 222 389 289 222 minecraft:mossy_cobblestone
fill 390 286 221 390 288 221 minecraft:mossy_cobblestone
setblock 392 286 182 minecraft:mossy_cobblestone
setblock 392 286 183 minecraft:stone_bricks
setblock 392 286 222 minecraft:mossy_cobblestone
setblock 393 286 182 minecraft:stone_bricks
setblock 393 286 222 minecraft:stone_bricks
fill 394 286 182 397 286 182 minecraft:mossy_cobblestone
fill 394 286 222 397 286 222 minecraft:mossy_cobblestone
fill 397 286 221 398 286 221 minecraft:mossy_cobblestone
setblock 398 286 182 minecraft:stone_bricks
fill 398 286 183 401 286 183 minecraft:mossy_cobblestone
setblock 398 286 222 minecraft:stone_bricks
fill 399 286 182 402 286 182 minecraft:mossy_cobblestone
setblock 399 286 221 minecraft:stone_bricks
fill 399 286 222 402 286 222 minecraft:mossy_cobblestone
setblock 400 286 220 minecraft:stone_bricks
fill 400 286 221 403 286 221 minecraft:mossy_cobblestone
fill 401 286 220 404 286 220 minecraft:mossy_cobblestone
setblock 402 286 183 minecraft:stone_bricks
setblock 403 286 182 minecraft:stone_bricks
fill 403 286 183 405 286 184 minecraft:mossy_cobblestone
fill 403 286 219 405 286 219 minecraft:mossy_cobblestone
setblock 403 286 222 minecraft:stone_bricks
fill 404 286 182 407 286 182 minecraft:mossy_cobblestone
setblock 404 286 221 minecraft:stone_bricks
fill 404 286 222 407 286 222 minecraft:mossy_cobblestone
setblock 405 286 220 minecraft:stone_bricks
fill 405 286 221 408 286 221 minecraft:mossy_cobblestone
setblock 406 286 183 minecraft:mossy_cobblestone
setblock 406 286 184 minecraft:stone_bricks
setblock 406 286 219 minecraft:stone_bricks
fill 406 286 220 409 286 220 minecraft:mossy_cobblestone
setblock 407 286 183 minecraft:stone_bricks
fill 407 286 184 407 288 184 minecraft:mossy_cobblestone
fill 407 286 219 407 289 219 minecraft:mossy_cobblestone
setblock 408 286 182 minecraft:stone_bricks
fill 408 286 183 408 289 183 minecraft:mossy_cobblestone
setblock 408 286 222 minecraft:stone_bricks
fill 409 286 182 409 289 182 minecraft:mossy_cobblestone
setblock 409 286 221 minecraft:stone_bricks
fill 409 286 222 412 286 222 minecraft:mossy_cobblestone
setblock 410 286 219 minecraft:mossy_cobblestone
setblock 410 286 220 minecraft:stone_bricks
fill 410 286 221 413 286 221 minecraft:mossy_cobblestone
setblock 411 286 219 minecraft:stone_bricks
fill 411 286 220 411 289 220 minecraft:mossy_cobblestone
setblock 412 286 182 minecraft:mossy_cobblestone
setblock 413 286 182 minecraft:stone_bricks
setblock 413 286 222 minecraft:stone_bricks
fill 414 286 182 414 288 182 minecraft:mossy_cobblestone
setblock 414 286 221 minecraft:stone_bricks
fill 414 286 222 414 289 222 minecraft:mossy_cobblestone
setblock 415 286 219 minecraft:mossy_cobblestone
setblock 415 286 220 minecraft:stone_bricks
fill 415 286 221 415 289 221 minecraft:mossy_cobblestone
setblock 416 286 215 minecraft:mossy_cobblestone
setblock 416 286 218 minecraft:mossy_cobblestone
setblock 416 286 219 minecraft:stone_bricks
fill 416 286 220 416 289 220 minecraft:mossy_cobblestone
fill 417 286 196 417 286 197 minecraft:mossy_cobblestone
setblock 417 286 198 minecraft:stone_bricks
fill 417 286 199 417 286 202 minecraft:mossy_cobblestone
setblock 417 286 203 minecraft:stone_bricks
fill 417 286 204 417 287 206 minecraft:mossy_cobblestone
fill 417 286 211 417 286 212 minecraft:mossy_cobblestone
setblock 417 286 213 minecraft:stone_bricks
fill 417 286 214 417 289 214 minecraft:mossy_cobblestone
setblock 417 286 218 minecraft:stone_bricks
fill 417 286 219 417 289 219 minecraft:mossy_cobblestone
fill 377 287 193 377 287 196 minecraft:mossy_cobblestone
setblock 377 287 197 minecraft:stone_bricks
fill 377 287 198 377 290 198 minecraft:mossy_cobblestone
setblock 377 287 201 minecraft:mossy_cobblestone
setblock 377 287 202 minecraft:stone_bricks
fill 377 287 203 377 290 203 minecraft:mossy_cobblestone
fill 377 287 205 377 287 206 minecraft:mossy_cobblestone
setblock 377 287 207 minecraft:stone_bricks
fill 377 287 208 377 290 208 minecraft:mossy_cobblestone
fill 377 287 213 377 287 216 minecraft:mossy_cobblestone
setblock 377 287 217 minecraft:stone_bricks
fill 377 287 218 377 289 218 minecraft:mossy_cobblestone
setblock 377 287 222 minecraft:stone_bricks
setblock 378 287 196 minecraft:stone_bricks
fill 378 287 197 378 290 197 minecraft:mossy_cobblestone
setblock 378 287 201 minecraft:stone_bricks
fill 378 287 202 378 290 202 minecraft:mossy_cobblestone
setblock 378 287 206 minecraft:stone_bricks
fill 378 287 222 381 287 222 minecraft:mossy_cobblestone
fill 379 287 182 381 287 182 minecraft:mossy_cobblestone
fill 379 287 196 379 288 196 minecraft:mossy_cobblestone
setblock 379 287 200 minecraft:stone_bricks
fill 379 287 201 380 289 201 minecraft:mossy_cobblestone
fill 379 287 203 379 287 204 minecraft:mossy_cobblestone
fill 379 287 221 382 287 221 minecraft:mossy_cobblestone
setblock 380 287 198 minecraft:mossy_cobblestone
setblock 380 287 199 minecraft:stone_bricks
fill 380 287 200 380 290 200 minecraft:mossy_cobblestone
setblock 382 287 182 minecraft:stone_bricks
fill 382 287 183 385 287 183 minecraft:mossy_cobblestone
setblock 382 287 222 minecraft:stone_bricks
fill 383 287 182 386 287 182 minecraft:mossy_cobblestone
setblock 383 287 220 minecraft:mossy_cobblestone
setblock 383 287 221 minecraft:stone_bricks
fill 383 287 222 386 287 222 minecraft:mossy_cobblestone
setblock 384 287 220 minecraft:stone_bricks
fill 384 287 221 384 290 221 minecraft:mossy_cobblestone
fill 385 287 220 385 288 220 minecraft:mossy_cobblestone
setblock 386 287 183 minecraft:stone_bricks
setblock 387 287 182 minecraft:stone_bricks
fill 387 287 183 387 290 183 minecraft:mossy_cobblestone
setblock 387 287 222 minecraft:stone_bricks
fill 388 287 182 388 290 182 minecraft:mossy_cobblestone
setblock 388 287 221 minecraft:stone_bricks
fill 388 287 222 388 290 222 minecraft:mossy_cobblestone
fill 389 287 221 389 289 221 minecraft:mossy_cobblestone
setblock 391 287 183 minecraft:stone_bricks
setblock 392 287 182 minecraft:stone_bricks
fill 392 287 183 395 287 183 minecraft:mossy_cobblestone
setblock 392 287 222 minecraft:stone_bricks
fill 393 287 182 396 287 182 minecraft:mossy_cobblestone
fill 393 287 222 396 287 222 minecraft:mossy_cobblestone
setblock 396 287 183 minecraft:stone_bricks
fill 396 287 221 397 287 221 minecraft:mossy_cobblestone
setblock 397 287 182 minecraft:stone_bricks
fill 397 287 183 400 287 183 minecraft:mossy_cobblestone
setblock 397 287 222 minecraft:stone_bricks
fill 398 287 182 401 287 182 minecraft:mossy_cobblestone
setblock 398 287 221 minecraft:stone_bricks
fill 398 287 222 401 287 222 minecraft:mossy_cobblestone
fill 399 287 221 402 287 221 minecraft:mossy_cobblestone
fill 400 287 220 403 287 220 minecraft:mossy_cobblestone
setblock 401 287 183 minecraft:stone_bricks
setblock 402 287 182 minecraft:stone_bricks
fill 402 287 183 404 287 184 minecraft:mossy_cobblestone
fill 402 287 219 404 287 219 minecraft:mossy_cobblestone
setblock 402 287 222 minecraft:stone_bricks
fill 403 287 182 406 287 182 minecraft:mossy_cobblestone
setblock 403 287 221 minecraft:stone_bricks
fill 403 287 222 406 287 222 minecraft:mossy_cobblestone
setblock 404 287 220 minecraft:stone_bricks
fill 404 287 221 407 287 221 minecraft:mossy_cobblestone
setblock 405 287 183 minecraft:mossy_cobblestone
setblock 405 287 184 minecraft:stone_bricks
setblock 405 287 219 minecraft:stone_bricks
fill 405 287 220 408 287 220 minecraft:mossy_cobblestone
setblock 406 287 183 minecraft:stone_bricks
fill 406 287 184 406 290 184 minecraft:mossy_cobblestone
fill 406 287 219 406 289 219 minecraft:mossy_cobblestone
setblock 407 287 182 minecraft:stone_bricks
fill 407 287 183 407 290 183 minecraft:mossy_cobblestone
setblock 407 287 222 minecraft:stone_bricks
fill 408 287 182 408 290 182 minecraft:mossy_cobblestone
setblock 408 287 221 minecraft:stone_bricks
fill 408 287 222 411 287 222 minecraft:mossy_cobblestone
setblock 409 287 220 minecraft:stone_bricks
fill 409 287 221 412 287 221 minecraft:mossy_cobblestone
setblock 410 287 219 minecraft:stone_bricks
fill 410 287 220 410 290 220 minecraft:mossy_cobblestone
setblock 411 287 219 minecraft:mossy_cobblestone
setblock 412 287 182 minecraft:stone_bricks
setblock 412 287 222 minecraft:stone_bricks
fill 413 287 182 413 289 182 minecraft:mossy_cobblestone
setblock 413 287 221 minecraft:stone_bricks
fill 413 287 222 413 290 222 minecraft:mossy_cobblestone
setblock 414 287 220 minecraft:stone_bricks
fill 414 287 221 414 290 221 minecraft:mossy_cobblestone
setblock 416 287 218 minecraft:stone_bricks
fill 416 287 219 416 289 219 minecraft:mossy_cobblestone
setblock 417 287 196 minecraft:mossy_cobblestone
setblock 417 287 197 minecraft:stone_bricks
fill 417 287 198 417 287 201 minecraft:mossy_cobblestone
setblock 417 287 202 minecraft:stone_bricks
fill 417 287 203 417 290 203 minecraft:mossy_cobblestone
setblock 417 287 207 minecraft:stone_bricks
fill 417 287 208 417 287 211 minecraft:mossy_cobblestone
setblock 417 287 212 minecraft:stone_bricks
fill 417 287 213 417 289 213 minecraft:mossy_cobblestone
setblock 417 287 217 minecraft:stone_bricks
fill 417 287 218 417 290 218 minecraft:mossy_cobblestone
setblock 417 287 222 minecraft:stone_bricks
fill 377 288 194 377 288 195 minecraft:mossy_cobblestone
setblock 377 288 196 minecraft:stone_bricks
fill 377 288 197 377 291 197 minecraft:mossy_cobblestone
setblock 377 288 201 minecraft:stone_bricks
fill 377 288 202 377 291 202 minecraft:mossy_cobblestone
setblock 377 288 205 minecraft:mossy_cobblestone
setblock 377 288 206 minecraft:stone_bricks
fill 377 288 207 377 291 207 minecraft:mossy_cobblestone
setblock 377 288 215 minecraft:mossy_cobblestone
setblock 377 288 216 minecraft:stone_bricks
setblock 377 288 217 minecraft:mossy_cobblestone
setblock 377 288 221 minecraft:stone_bricks
fill 377 288 222 380 288 222 minecraft:mossy_cobblestone
fill 378 288 182 380 288 182 minecraft:mossy_cobblestone
setblock 378 288 195 minecraft:stone_bricks
fill 378 288 196 378 291 196 minecraft:mossy_cobblestone
setblock 378 288 199 minecraft:mossy_cobblestone
setblock 378 288 200 minecraft:stone_bricks
fill 378 288 201 378 291 201 minecraft:mossy_cobblestone
setblock 378 288 205 minecraft:stone_bricks
fill 378 288 206 378 291 206 minecraft:mossy_cobblestone
setblock 379 288 199 minecraft:stone_bricks
fill 379 288 200 379 291 200 minecraft:mossy_cobblestone
setblock 379 288 203 minecraft:mossy_cobblestone
setblock 379 288 204 minecraft:stone_bricks
fill 379 288 221 381 288 221 minecraft:mossy_cobblestone
setblock 380 288 198 minecraft:stone_bricks
fill 380 288 199 380 290 199 minecraft:mossy_cobblestone
setblock 380 288 202 minecraft:mossy_cobblestone
setblock 381 288 182 minecraft:stone_bricks
fill 381 288 183 384 288 183 minecraft:mossy_cobblestone
setblock 381 288 222 minecraft:stone_bricks
fill 382 288 182 385 288 182 minecraft:mossy_cobblestone
setblock 382 288 221 minecraft:stone_bricks
fill 382 288 222 385 288 222 minecraft:mossy_cobblestone
fill 383 288 221 383 291 221 minecraft:mossy_cobblestone
setblock 384 288 220 minecraft:mossy_cobblestone
setblock 385 288 183 minecraft:stone_bricks
fill 385 288 184 387 289 184 minecraft:mossy_cobblestone
setblock 386 288 182 minecraft:stone_bricks
fill 386 288 183 386 291 183 minecraft:mossy_cobblestone
setblock 386 288 222 minecraft:stone_bricks
fill 387 288 182 387 291 182 minecraft:mossy_cobblestone
setblock 387 288 221 minecraft:stone_bricks
fill 387 288 222 387 291 222 minecraft:mossy_cobblestone
fill 388 288 221 388 289 221 minecraft:mossy_cobblestone
setblock 390 288 183 minecraft:stone_bricks
setblock 391 288 182 minecraft:stone_bricks
fill 391 288 183 394 288 183 minecraft:mossy_cobblestone
setblock 391 288 221 minecraft:mossy_cobblestone
setblock 391 288 222 minecraft:stone_bricks
fill 392 288 182 395 288 182 minecraft:mossy_cobblestone
fill 392 288 222 395 288 222 minecraft:mossy_cobblestone
setblock 395 288 183 minecraft:stone_bricks
setblock 396 288 182 minecraft:stone_bricks
fill 396 288 183 399 288 183 minecraft:mossy_cobblestone
setblock 396 288 221 minecraft:mossy_cobblestone
setblock 396 288 222 minecraft:stone_bricks
fill 397 288 182 400 288 182 minecraft:mossy_cobblestone
setblock 397 288 221 minecraft:stone_bricks
fill 397 288 222 400 288 222 minecraft:mossy_cobblestone
fill 398 288 221 401 288 221 minecraft:mossy_cobblestone
setblock 400 288 183 minecraft:stone_bricks
fill 400 288 220 402 288 220 minecraft:mossy_cobblestone
setblock 401 288 182 minecraft:stone_bricks
fill 401 288 183 403 288 184 minecraft:mossy_cobblestone
setblock 401 288 222 minecraft:stone_bricks
fill 402 288 182 405 288 182 minecraft:mossy_cobblestone
fill 402 288 219 403 288 219 minecraft:mossy_cobblestone
setblock 402 288 221 minecraft:stone_bricks
fill 402 288 222 405 288 222 minecraft:mossy_cobblestone
setblock 403 288 220 minecraft:stone_bricks
fill 403 288 221 406 288 221 minecraft:mossy_cobblestone
setblock 404 288 183 minecraft:mossy_cobblestone
setblock 404 288 184 minecraft:stone_bricks
setblock 404 288 219 minecraft:stone_bricks
fill 404 288 220 407 288 220 minecraft:mossy_cobblestone
setblock 405 288 183 minecraft:stone_bricks
fill 405 288 184 405 291 184 minecraft:mossy_cobblestone
fill 405 288 219 405 290 219 minecraft:mossy_cobblestone
setblock 406 288 182 minecraft:stone_bricks
fill 406 288 183 406 291 183 minecraft:mossy_cobblestone
setblock 406 288 222 minecraft:stone_bricks
fill 407 288 182 407 291 182 minecraft:mossy_cobblestone
setblock 407 288 221 minecraft:stone_bricks
fill 407 288 222 410 288 222 minecraft:mossy_cobblestone
setblock 408 288 220 minecraft:stone_bricks
fill 408 288 221 411 288 221 minecraft:mossy_cobblestone
setblock 409 288 219 minecraft:stone_bricks
fill 409 288 220 409 290 220 minecraft:mossy_cobblestone
setblock 410 288 183 minecraft:stone_bricks
setblock 411 288 182 minecraft:stone_bricks
setblock 411 288 222 minecraft:stone_bricks
fill 412 288 182 412 290 182 minecraft:mossy_cobblestone
setblock 412 288 221 minecraft:stone_bricks
fill 412 288 222 412 291 222 minecraft:mossy_cobblestone
setblock 413 288 220 minecraft:stone_bricks
fill 413 288 221 413 290 221 minecraft:mossy_cobblestone
setblock 416 288 201 minecraft:mossy_cobblestone
setblock 416 288 202 minecraft:stone_bricks
setblock 416 288 217 minecraft:stone_bricks
fill 416 288 218 416 289 218 minecraft:mossy_cobblestone
setblock 416 288 222 minecraft:stone_bricks
setblock 417 288 196 minecraft:stone_bricks
fill 417 288 197 417 288 200 minecraft:mossy_cobblestone
setblock 417 288 201 minecraft:stone_bricks
fill 417 288 202 417 291 202 minecraft:mossy_cobblestone
fill 417 288 204 417 288 205 minecraft:mossy_cobblestone
setblock 417 288 206 minecraft:stone_bricks
fill 417 288 207 417 288 210 minecraft:mossy_cobblestone
setblock 417 288 211 minecraft:stone_bricks
fill 417 288 212 417 289 212 minecraft:mossy_cobblestone
setblock 417 288 216 minecraft:stone_bricks
fill 417 288 217 417 291 217 minecraft:mossy_cobblestone
setblock 417 288 221 minecraft:stone_bricks
fill 417 288 222 417 291 222 minecraft:mossy_cobblestone
setblock 377 289 194 minecraft:mossy_cobblestone
setblock 377 289 195 minecraft:stone_bricks
fill 377 289 196 377 292 196 minecraft:mossy_cobblestone
setblock 377 289 200 minecraft:stone_bricks
fill 377 289 201 377 292 201 minecraft:mossy_cobblestone
setblock 377 289 204 minecraft:mossy_cobblestone
setblock 377 289 205 minecraft:stone_bricks
fill 377 289 206 377 292 206 minecraft:mossy_cobblestone
setblock 377 289 220 minecraft:stone_bricks
fill 377 289 221 377 290 222 minecraft:mossy_cobblestone
fill 378 289 182 379 289 182 minecraft:mossy_cobblestone
setblock 378 289 195 minecraft:mossy_cobblestone
setblock 378 289 199 minecraft:stone_bricks
fill 378 289 200 378 292 200 minecraft:mossy_cobblestone
setblock 378 289 204 minecraft:stone_bricks
fill 378 289 205 379 291 205 minecraft:mossy_cobblestone
fill 378 289 207 378 290 207 minecraft:mossy_cobblestone
fill 378 289 222 379 289 222 minecraft:mossy_cobblestone
setblock 379 289 184 minecraft:light[level=12]
setblock 379 289 192 minecraft:light[level=12]
setblock 379 289 198 minecraft:stone_bricks
fill 379 289 199 379 292 199 minecraft:mossy_cobblestone
setblock 379 289 203 minecraft:stone_bricks
fill 379 289 204 379 292 204 minecraft:mossy_cobblestone
setblock 379 289 208 minecraft:light[level=12]
setblock 379 289 216 minecraft:light[level=12]
setblock 380 289 182 minecraft:stone_bricks
setblock 380 289 198 minecraft:mossy_cobblestone
setblock 380 289 202 minecraft:stone_bricks
fill 380 289 203 380 291 203 minecraft:mossy_cobblestone
setblock 380 289 221 minecraft:mossy_cobblestone
setblock 380 289 222 minecraft:stone_bricks
fill 381 289 182 383 289 183 minecraft:mossy_cobblestone
setblock 381 289 221 minecraft:stone_bricks
fill 381 289 222 384 289 222 minecraft:mossy_cobblestone
fill 382 289 221 382 291 221 minecraft:mossy_cobblestone
setblock 384 289 182 minecraft:mossy_cobblestone
setblock 384 289 183 minecraft:stone_bricks
fill 384 289 184 384 292 184 minecraft:mossy_cobblestone
setblock 385 289 182 minecraft:stone_bricks
fill 385 289 183 385 292 183 minecraft:mossy_cobblestone
setblock 385 289 222 minecraft:stone_bricks
fill 386 289 182 386 292 182 minecraft:mossy_cobblestone
setblock 386 289 221 minecraft:stone_bricks
fill 386 289 222 386 292 222 minecraft:mossy_cobblestone
setblock 387 289 192 minecraft:light[level=12]
setblock 387 289 200 minecraft:light[level=12]
setblock 387 289 208 minecraft:light[level=12]
setblock 387 289 216 minecraft:light[level=12]
fill 387 289 221 387 290 221 minecraft:mossy_cobblestone
setblock 389 289 183 minecraft:stone_bricks
setblock 390 289 182 minecraft:stone_bricks
fill 390 289 183 393 289 183 minecraft:mossy_cobblestone
setblock 390 289 222 minecraft:stone_bricks
fill 391 289 182 394 289 182 minecraft:mossy_cobblestone
fill 391 289 222 394 289 222 minecraft:mossy_cobblestone
setblock 394 289 183 minecraft:stone_bricks
setblock 395 289 182 minecraft:stone_bricks
fill 395 289 183 398 289 183 minecraft:mossy_cobblestone
setblock 395 289 184 minecraft:light[level=12]
setblock 395 289 192 minecraft:light[level=12]
setblock 395 289 208 minecraft:light[level=12]
setblock 395 289 216 minecraft:light[level=12]
setblock 395 289 222 minecraft:stone_bricks
fill 396 289 182 399 289 182 minecraft:mossy_cobblestone
setblock 396 289 221 minecraft:stone_bricks
fill 396 289 222 399 289 222 minecraft:mossy_cobblestone
fill 397 289 221 400 289 221 minecraft:mossy_cobblestone
setblock 399 289 183 minecraft:stone_bricks
setblock 400 289 182 minecraft:stone_bricks
fill 400 289 183 402 289 184 minecraft:mossy_cobblestone
fill 400 289 220 401 289 220 minecraft:mossy_cobblestone
setblock 400 289 222 minecraft:stone_bricks
fill 401 289 182 404 289 182 minecraft:mossy_cobblestone
setblock 401 289 221 minecraft:stone_bricks
fill 401 289 222 404 289 222 minecraft:mossy_cobblestone
setblock 402 289 220 minecraft:stone_bricks
fill 402 289 221 405 289 221 minecraft:mossy_cobblestone
setblock 403 289 183 minecraft:mossy_cobblestone
setblock 403 289 184 minecraft:stone_bricks
setblock 403 289 192 minecraft:light[level=12]
setblock 403 289 200 minecraft:light[level=12]
setblock 403 289 208 minecraft:light[level=12]
setblock 403 289 216 minecraft:light[level=12]
setblock 403 289 219 minecraft:stone_bricks
fill 403 289 220 406 289 220 minecraft:mossy_cobblestone
setblock 404 289 183 minecraft:stone_bricks
fill 404 289 184 404 292 184 minecraft:mossy_cobblestone
fill 404 289 219 404 290 219 minecraft:mossy_cobblestone
setblock 405 289 182 minecraft:stone_bricks
fill 405 289 183 405 292 183 minecraft:mossy_cobblestone
setblock 405 289 222 minecraft:stone_bricks
fill 406 289 182 406 292 182 minecraft:mossy_cobblestone
setblock 406 289 221 minecraft:stone_bricks
fill 406 289 222 409 289 222 minecraft:mossy_cobblestone
setblock 407 289 220 minecraft:stone_bricks
fill 407 289 221 410 289 221 minecraft:mossy_cobblestone
setblock 408 289 219 minecraft:stone_bricks
fill 408 289 220 408 291 220 minecraft:mossy_cobblestone
setblock 409 289 183 minecraft:stone_bricks
setblock 410 289 182 minecraft:stone_bricks
setblock 410 289 183 minecraft:mossy_cobblestone
setblock 410 289 222 minecraft:stone_bricks
fill 411 289 182 411 291 182 minecraft:mossy_cobblestone
setblock 411 289 184 minecraft:light[level=12]
setblock 411 289 192 minecraft:light[level=12]
setblock 411 289 200 minecraft:light[level=12]
setblock 411 289 208 minecraft:light[level=12]
setblock 411 289 216 minecraft:light[level=12]
setblock 411 289 221 minecraft:stone_bricks
fill 411 289 222 411 292 222 minecraft:mossy_cobblestone
fill 412 289 221 412 290 221 minecraft:mossy_cobblestone
setblock 415 289 222 minecraft:stone_bricks
setblock 416 289 201 minecraft:stone_bricks
fill 416 289 202 416 291 203 minecraft:mossy_cobblestone
setblock 416 289 221 minecraft:stone_bricks
fill 416 289 222 416 292 222 minecraft:mossy_cobblestone
fill 417 289 197 417 289 199 minecraft:mossy_cobblestone
setblock 417 289 200 minecraft:stone_bricks
fill 417 289 201 417 292 201 minecraft:mossy_cobblestone
setblock 417 289 204 minecraft:mossy_cobblestone
setblock 417 289 205 minecraft:stone_bricks
fill 417 289 206 417 289 209 minecraft:mossy_cobblestone
setblock 417 289 210 minecraft:stone_bricks
fill 417 289 211 417 292 211 minecraft:mossy_cobblestone
setblock 417 289 215 minecraft:stone_bricks
fill 417 289 216 417 291 216 minecraft:mossy_cobblestone
setblock 417 289 220 minecraft:stone_bricks
fill 417 289 221 417 292 221 minecraft:mossy_cobblestone
fill 377 290 182 378 290 182 minecraft:mossy_cobblestone
setblock 377 290 194 minecraft:stone_bricks
fill 377 290 195 377 293 195 minecraft:mossy_cobblestone
setblock 377 290 199 minecraft:stone_bricks
fill 377 290 200 377 293 200 minecraft:mossy_cobblestone
setblock 377 290 204 minecraft:stone_bricks
fill 377 290 205 377 293 205 minecraft:mossy_cobblestone
setblock 377 290 209 minecraft:stone_bricks
setblock 377 290 220 minecraft:mossy_cobblestone
setblock 378 290 198 minecraft:stone_bricks
fill 378 290 199 378 293 199 minecraft:mossy_cobblestone
setblock 378 290 203 minecraft:stone_bricks
fill 378 290 204 378 293 204 minecraft:mossy_cobblestone
setblock 378 290 222 minecraft:mossy_cobblestone
setblock 379 290 182 minecraft:stone_bricks
setblock 379 290 197 minecraft:stone_bricks
fill 379 290 198 379 291 198 minecraft:mossy_cobblestone
setblock 379 290 201 minecraft:mossy_cobblestone
setblock 379 290 202 minecraft:stone_bricks
fill 379 290 203 379 293 203 minecraft:mossy_cobblestone
setblock 379 290 222 minecraft:stone_bricks
fill 380 290 182 382 290 183 minecraft:mossy_cobblestone
setblock 380 290 201 minecraft:stone_bricks
fill 380 290 202 380 292 202 minecraft:mossy_cobblestone
fill 380 290 222 383 290 222 minecraft:mossy_cobblestone
setblock 381 290 221 minecraft:mossy_cobblestone
setblock 383 290 182 minecraft:mossy_cobblestone
setblock 383 290 183 minecraft:stone_bricks
fill 383 290 184 383 293 184 minecraft:mossy_cobblestone
setblock 384 290 182 minecraft:stone_bricks
fill 384 290 183 384 293 183 minecraft:mossy_cobblestone
setblock 384 290 222 minecraft:stone_bricks
fill 385 290 182 385 293 182 minecraft:mossy_cobblestone
fill 385 290 184 386 290 184 minecraft:mossy_cobblestone
setblock 385 290 221 minecraft:stone_bricks
fill 385 290 222 385 293 222 minecraft:mossy_cobblestone
setblock 386 290 221 minecraft:mossy_cobblestone
setblock 387 290 184 minecraft:stone_bricks
setblock 388 290 183 minecraft:stone_bricks
setblock 389 290 182 minecraft:stone_bricks
fill 389 290 183 392 290 183 minecraft:mossy_cobblestone
setblock 389 290 222 minecraft:stone_bricks
fill 390 290 182 393 290 182 minecraft:mossy_cobblestone
fill 390 290 222 393 290 222 minecraft:mossy_cobblestone
setblock 393 290 183 minecraft:stone_bricks
setblock 394 290 182 minecraft:stone_bricks
fill 394 290 183 397 290 183 minecraft:mossy_cobblestone
setblock 394 290 222 minecraft:stone_bricks
fill 395 290 182 398 290 182 minecraft:mossy_cobblestone
fill 395 290 222 398 290 222 minecraft:mossy_cobblestone
fill 397 290 221 399 290 221 minecraft:mossy_cobblestone
setblock 398 290 183 minecraft:stone_bricks
setblock 399 290 182 minecraft:stone_bricks
fill 399 290 183 401 290 184 minecraft:mossy_cobblestone
setblock 399 290 222 minecraft:stone_bricks
fill 400 290 182 403 290 182 minecraft:mossy_cobblestone
setblock 400 290 220 minecraft:mossy_cobblestone
setblock 400 290 221 minecraft:stone_bricks
fill 400 290 222 403 290 222 minecraft:mossy_cobblestone
setblock 401 290 220 minecraft:stone_bricks
fill 401 290 221 404 290 221 minecraft:mossy_cobblestone
setblock 402 290 183 minecraft:mossy_cobblestone
setblock 402 290 184 minecraft:stone_bricks
fill 402 290 220 405 290 220 minecraft:mossy_cobblestone
setblock 403 290 183 minecraft:stone_bricks
fill 403 290 184 403 293 184 minecraft:mossy_cobblestone
setblock 404 290 182 minecraft:stone_bricks
fill 404 290 183 404 293 183 minecraft:mossy_cobblestone
setblock 404 290 222 minecraft:stone_bricks
fill 405 290 182 405 293 182 minecraft:mossy_cobblestone
setblock 405 290 221 minecraft:stone_bricks
fill 405 290 222 408 290 222 minecraft:mossy_cobblestone
setblock 406 290 220 minecraft:stone_bricks
fill 406 290 221 409 290 221 minecraft:mossy_cobblestone
fill 407 290 220 407 291 220 minecraft:mossy_cobblestone
setblock 408 290 183 minecraft:stone_bricks
setblock 409 290 182 minecraft:stone_bricks
setblock 409 290 183 minecraft:mossy_cobblestone
setblock 409 290 222 minecraft:stone_bricks
fill 410 290 182 410 293 182 minecraft:mossy_cobblestone
setblock 410 290 221 minecraft:stone_bricks
fill 410 290 222 410 293 222 minecraft:mossy_cobblestone
fill 411 290 221 411 291 221 minecraft:mossy_cobblestone
setblock 414 290 222 minecraft:stone_bricks
setblock 415 290 221 minecraft:stone_bricks
fill 415 290 222 415 293 222 minecraft:mossy_cobblestone
setblock 416 290 201 minecraft:mossy_cobblestone
setblock 416 290 204 minecraft:mossy_cobblestone
setblock 416 290 221 minecraft:mossy_cobblestone
fill 417 290 197 417 290 198 minecraft:mossy_cobblestone
setblock 417 290 199 minecraft:stone_bricks
fill 417 290 200 417 293 200 minecraft:mossy_cobblestone
setblock 417 290 204 minecraft:stone_bricks
fill 417 290 205 417 290 208 minecraft:mossy_cobblestone
setblock 417 290 209 minecraft:stone_bricks
fill 417 290 210 417 293 210 minecraft:mossy_cobblestone
setblock 417 290 214 minecraft:stone_bricks
setblock 417 290 215 minecraft:mossy_cobblestone
setblock 417 290 219 minecraft:stone_bricks
fill 417 290 220 417 293 220 minecraft:mossy_cobblestone
setblock 377 291 182 minecraft:mossy_cobblestone
setblock 377 291 183 minecraft:stone_bricks
setblock 377 291 198 minecraft:stone_bricks
fill 377 291 199 377 294 199 minecraft:mossy_cobblestone
setblock 377 291 203 minecraft:stone_bricks
fill 377 291 204 377 294 204 minecraft:mossy_cobblestone
setblock 377 291 208 minecraft:stone_bricks
fill 377 291 209 377 294 209 minecraft:mossy_cobblestone
setblock 377 291 222 minecraft:mossy_cobblestone
setblock 378 291 182 minecraft:stone_bricks
setblock 378 291 197 minecraft:stone_bricks
fill 378 291 198 378 294 198 minecraft:mossy_cobblestone
setblock 378 291 202 minecraft:stone_bricks
fill 378 291 203 378 294 203 minecraft:mossy_cobblestone
setblock 378 291 207 minecraft:stone_bricks
setblock 378 291 222 minecraft:stone_bricks
fill 379 291 182 382 291 182 minecraft:mossy_cobblestone
setblock 379 291 201 minecraft:stone_bricks
fill 379 291 202 379 294 202 minecraft:mossy_cobblestone
fill 379 291 222 382 291 222 minecraft:mossy_cobblestone
fill 380 291 183 381 291 183 minecraft:mossy_cobblestone
setblock 380 291 200 minecraft:stone_bricks
setblock 380 291 201 minecraft:mossy_cobblestone
setblock 382 291 183 minecraft:stone_bricks
setblock 383 291 182 minecraft:stone_bricks
fill 383 291 183 383 294 183 minecraft:mossy_cobblestone
setblock 383 291 222 minecraft:stone_bricks
fill 384 291 182 384 294 182 minecraft:mossy_cobblestone
setblock 384 291 221 minecraft:stone_bricks
fill 384 291 222 384 294 222 minecraft:mossy_cobblestone
setblock 385 291 184 minecraft:mossy_cobblestone
setblock 385 291 221 minecraft:mossy_cobblestone
setblock 386 291 184 minecraft:stone_bricks
setblock 387 291 183 minecraft:stone_bricks
setblock 388 291 182 minecraft:stone_bricks
fill 388 291 183 391 291 183 minecraft:mossy_cobblestone
setblock 388 291 222 minecraft:stone_bricks
fill 389 291 182 392 291 182 minecraft:mossy_cobblestone
fill 389 291 222 392 291 222 minecraft:mossy_cobblestone
setblock 392 291 183 minecraft:stone_bricks
setblock 393 291 182 minecraft:stone_bricks
fill 393 291 183 396 291 183 minecraft:mossy_cobblestone
setblock 393 291 222 minecraft:stone_bricks
fill 394 291 182 397 291 182 minecraft:mossy_cobblestone
fill 394 291 222 397 291 222 minecraft:mossy_cobblestone
setblock 397 291 183 minecraft:stone_bricks
fill 397 291 221 398 291 221 minecraft:mossy_cobblestone
setblock 398 291 182 minecraft:stone_bricks
fill 398 291 183 401 291 183 minecraft:mossy_cobblestone
setblock 398 291 222 minecraft:stone_bricks
fill 399 291 182 402 291 182 minecraft:mossy_cobblestone
fill 399 291 184 400 291 184 minecraft:mossy_cobblestone
setblock 399 291 221 minecraft:stone_bricks
fill 399 291 222 402 291 222 minecraft:mossy_cobblestone
setblock 400 291 220 minecraft:stone_bricks
fill 400 291 221 403 291 221 minecraft:mossy_cobblestone
setblock 401 291 184 minecraft:stone_bricks
fill 401 291 220 404 291 220 minecraft:mossy_cobblestone
setblock 402 291 183 minecraft:stone_bricks
fill 402 291 184 402 294 184 minecraft:mossy_cobblestone
setblock 403 291 182 minecraft:stone_bricks
fill 403 291 183 403 294 183 minecraft:mossy_cobblestone
setblock 403 291 222 minecraft:stone_bricks
fill 404 291 182 404 294 182 minecraft:mossy_cobblestone
setblock 404 291 221 minecraft:stone_bricks
fill 404 291 222 407 291 222 minecraft:mossy_cobblestone
setblock 405 291 220 minecraft:stone_bricks
fill 405 291 221 408 291 221 minecraft:mossy_cobblestone
fill 406 291 220 406 292 220 minecraft:mossy_cobblestone
setblock 407 291 183 minecraft:stone_bricks
setblock 408 291 182 minecraft:stone_bricks
setblock 408 291 183 minecraft:mossy_cobblestone
setblock 408 291 222 minecraft:stone_bricks
fill 409 291 182 409 294 182 minecraft:mossy_cobblestone
setblock 409 291 221 minecraft:stone_bricks
fill 409 291 222 409 294 222 minecraft:mossy_cobblestone
fill 410 291 221 410 292 221 minecraft:mossy_cobblestone
setblock 413 291 222 minecraft:stone_bricks
fill 414 291 222 414 293 222 minecraft:mossy_cobblestone
setblock 416 291 204 minecraft:stone_bricks
fill 416 291 205 417 293 205 minecraft:mossy_cobblestone
setblock 417 291 198 minecraft:stone_bricks
fill 417 291 199 417 294 199 minecraft:mossy_cobblestone
setblock 417 291 203 minecraft:stone_bricks
fill 417 291 204 417 294 204 minecraft:mossy_cobblestone
fill 417 291 206 417 291 207 minecraft:mossy_cobblestone
setblock 417 291 208 minecraft:stone_bricks
fill 417 291 209 417 294 209 minecraft:mossy_cobblestone
setblock 417 291 218 minecraft:stone_bricks
fill 417 291 219 417 292 219 minecraft:mossy_cobblestone
setblock 377 292 182 minecraft:stone_bricks
fill 377 292 183 377 294 184 minecraft:mossy_cobblestone
setblock 377 292 197 minecraft:stone_bricks
fill 377 292 198 377 295 198 minecraft:mossy_cobblestone
setblock 377 292 202 minecraft:stone_bricks
fill 377 292 203 377 295 203 minecraft:mossy_cobblestone
setblock 377 292 207 minecraft:stone_bricks
fill 377 292 208 378 294 208 minecraft:mossy_cobblestone
fill 378 292 182 381 292 182 minecraft:mossy_cobblestone
fill 378 292 197 378 295 197 minecraft:mossy_cobblestone
setblock 378 292 201 minecraft:stone_bricks
fill 378 292 202 378 295 202 minecraft:mossy_cobblestone
setblock 378 292 205 minecraft:mossy_cobblestone
setblock 378 292 206 minecraft:stone_bricks
fill 378 292 207 378 295 207 minecraft:mossy_cobblestone
fill 378 292 222 381 292 222 minecraft:mossy_cobblestone
fill 379 292 183 380 292 183 minecraft:mossy_cobblestone
setblock 379 292 200 minecraft:stone_bricks
fill 379 292 201 379 295 201 minecraft:mossy_cobblestone
setblock 379 292 205 minecraft:stone_bricks
fill 379 292 206 379 295 206 minecraft:mossy_cobblestone
setblock 381 292 183 minecraft:stone_bricks
setblock 382 292 182 minecraft:stone_bricks
fill 382 292 183 382 294 184 minecraft:mossy_cobblestone
setblock 382 292 222 minecraft:stone_bricks
fill 383 292 182 383 295 182 minecraft:mossy_cobblestone
fill 383 292 222 383 295 222 minecraft:mossy_cobblestone
setblock 385 292 184 minecraft:stone_bricks
setblock 386 292 183 minecraft:stone_bricks
setblock 386 292 184 minecraft:mossy_cobblestone
setblock 387 292 182 minecraft:stone_bricks
fill 387 292 183 390 292 183 minecraft:mossy_cobblestone
setblock 387 292 222 minecraft:stone_bricks
fill 388 292 182 391 292 182 minecraft:mossy_cobblestone
fill 388 292 222 389 292 222 minecraft:mossy_cobblestone
setblock 391 292 183 minecraft:stone_bricks
setblock 392 292 182 minecraft:stone_bricks
fill 392 292 183 395 292 183 minecraft:mossy_cobblestone
fill 393 292 182 396 292 182 minecraft:mossy_cobblestone
fill 393 292 222 396 292 222 minecraft:mossy_cobblestone
setblock 396 292 183 minecraft:stone_bricks
setblock 397 292 182 minecraft:stone_bricks
fill 397 292 183 400 292 183 minecraft:mossy_cobblestone
setblock 397 292 221 minecraft:mossy_cobblestone
setblock 397 292 222 minecraft:stone_bricks
fill 398 292 182 401 292 182 minecraft:mossy_cobblestone
fill 398 292 184 399 292 184 minecraft:mossy_cobblestone
setblock 398 292 221 minecraft:stone_bricks
fill 398 292 222 401 292 222 minecraft:mossy_cobblestone
fill 399 292 221 402 292 221 minecraft:mossy_cobblestone
setblock 400 292 184 minecraft:stone_bricks
setblock 401 292 183 minecraft:stone_bricks
fill 401 292 184 401 295 184 minecraft:mossy_cobblestone
fill 401 292 220 403 292 220 minecraft:mossy_cobblestone
setblock 402 292 182 minecraft:stone_bricks
fill 402 292 183 402 295 183 minecraft:mossy_cobblestone
setblock 402 292 222 minecraft:stone_bricks
fill 403 292 182 403 295 182 minecraft:mossy_cobblestone
setblock 403 292 221 minecraft:stone_bricks
fill 403 292 222 406 292 222 minecraft:mossy_cobblestone
setblock 404 292 220 minecraft:stone_bricks
fill 404 292 221 407 292 221 minecraft:mossy_cobblestone
setblock 405 292 220 minecraft:mossy_cobblestone
setblock 406 292 183 minecraft:stone_bricks
setblock 407 292 182 minecraft:stone_bricks
fill 407 292 183 407 293 183 minecraft:mossy_cobblestone
setblock 407 292 222 minecraft:stone_bricks
fill 408 292 182 408 295 182 minecraft:mossy_cobblestone
setblock 408 292 221 minecraft:stone_bricks
fill 408 292 222 408 295 222 minecraft:mossy_cobblestone
setblock 409 292 221 minecraft:mossy_cobblestone
setblock 412 292 222 minecraft:stone_bricks
fill 413 292 222 413 293 222 minecraft:mossy_cobblestone
setblock 416 292 202 minecraft:mossy_cobblestone
setblock 416 292 203 minecraft:stone_bricks
fill 416 292 204 416 295 204 minecraft:mossy_cobblestone
fill 416 292 206 417 292 206 minecraft:mossy_cobblestone
fill 417 292 198 417 295 198 minecraft:mossy_cobblestone
setblock 417 292 202 minecraft:stone_bricks
fill 417 292 203 417 295 203 minecraft:mossy_cobblestone
setblock 417 292 207 minecraft:stone_bricks
fill 417 292 208 417 295 208 minecraft:mossy_cobblestone
setblock 417 292 218 minecraft:mossy_cobblestone
setblock 417 292 222 minecraft:stone_bricks
fill 377 293 182 380 293 182 minecraft:mossy_cobblestone
setblock 377 293 185 minecraft:mossy_cobblestone
setblock 377 293 186 minecraft:stone_bricks
fill 377 293 187 377 296 187 minecraft:mossy_cobblestone
setblock 377 293 196 minecraft:stone_bricks
fill 377 293 197 377 296 197 minecraft:mossy_cobblestone
setblock 377 293 201 minecraft:stone_bricks
fill 377 293 202 377 296 202 minecraft:mossy_cobblestone
setblock 377 293 206 minecraft:stone_bricks
fill 377 293 207 377 296 207 minecraft:mossy_cobblestone
setblock 377 293 210 minecraft:mossy_cobblestone
setblock 378 293 200 minecraft:stone_bricks
fill 378 293 201 378 296 201 minecraft:mossy_cobblestone
setblock 378 293 205 minecraft:stone_bricks
fill 378 293 206 378 296 206 minecraft:mossy_cobblestone
fill 378 293 222 380 293 222 minecraft:mossy_cobblestone
setblock 379 293 183 minecraft:mossy_cobblestone
setblock 379 293 199 minecraft:stone_bricks
fill 379 293 200 379 296 200 minecraft:mossy_cobblestone
setblock 379 293 204 minecraft:stone_bricks
fill 379 293 205 379 296 205 minecraft:mossy_cobblestone
setblock 380 293 183 minecraft:stone_bricks
setblock 381 293 182 minecraft:stone_bricks
fill 381 293 183 381 296 183 minecraft:mossy_cobblestone
setblock 381 293 222 minecraft:stone_bricks
fill 382 293 182 382 296 182 minecraft:mossy_cobblestone
fill 382 293 222 382 296 222 minecraft:mossy_cobblestone
setblock 384 293 184 minecraft:stone_bricks
setblock 385 293 183 minecraft:stone_bricks
fill 385 293 184 385 296 184 minecraft:mossy_cobblestone
setblock 386 293 182 minecraft:stone_bricks
fill 386 293 183 389 293 183 minecraft:mossy_cobblestone
setblock 386 293 222 minecraft:stone_bricks
fill 387 293 182 390 293 182 minecraft:mossy_cobblestone
setblock 387 293 222 minecraft:mossy_cobblestone
setblock 390 293 183 minecraft:stone_bricks
setblock 391 293 182 minecraft:stone_bricks
fill 391 293 183 394 293 183 minecraft:mossy_cobblestone
fill 392 293 182 395 293 182 minecraft:mossy_cobblestone
fill 394 293 222 395 293 222 minecraft:mossy_cobblestone
setblock 395 293 183 minecraft:stone_bricks
setblock 396 293 182 minecraft:stone_bricks
fill 396 293 183 399 293 183 minecraft:mossy_cobblestone
setblock 396 293 222 minecraft:stone_bricks
fill 397 293 182 400 293 182 minecraft:mossy_cobblestone
fill 397 293 222 400 293 222 minecraft:mossy_cobblestone
setblock 398 293 184 minecraft:mossy_cobblestone
fill 398 293 221 401 293 221 minecraft:mossy_cobblestone
setblock 399 293 184 minecraft:stone_bricks
setblock 400 293 183 minecraft:stone_bricks
fill 400 293 184 400 296 184 minecraft:mossy_cobblestone
setblock 401 293 182 minecraft:stone_bricks
fill 401 293 183 401 296 183 minecraft:mossy_cobblestone
fill 401 293 220 402 293 220 minecraft:mossy_cobblestone
setblock 401 293 222 minecraft:stone_bricks
fill 402 293 182 402 296 182 minecraft:mossy_cobblestone
setblock 402 293 221 minecraft:stone_bricks
fill 402 293 222 405 293 222 minecraft:mossy_cobblestone
setblock 403 293 220 minecraft:stone_bricks
fill 403 293 221 406 293 221 minecraft:mossy_cobblestone
setblock 404 293 184 minecraft:stone_bricks
setblock 404 293 220 minecraft:mossy_cobblestone
setblock 405 293 183 minecraft:stone_bricks
setblock 406 293 182 minecraft:stone_bricks
fill 406 293 183 406 295 183 minecraft:mossy_cobblestone
setblock 406 293 222 minecraft:stone_bricks
fill 407 293 182 407 296 182 minecraft:mossy_cobblestone
setblock 407 293 221 minecraft:stone_bricks
fill 407 293 222 407 296 222 minecraft:mossy_cobblestone
setblock 408 293 221 minecraft:mossy_cobblestone
setblock 411 293 222 minecraft:stone_bricks
setblock 412 293 222 minecraft:mossy_cobblestone
setblock 416 293 202 minecraft:stone_bricks
fill 416 293 203 416 296 203 minecraft:mossy_cobblestone
setblock 416 293 206 minecraft:mossy_cobblestone
setblock 416 293 207 minecraft:stone_bricks
setblock 416 293 222 minecraft:stone_bricks
setblock 417 293 201 minecraft:stone_bricks
fill 417 293 202 417 296 202 minecraft:mossy_cobblestone
setblock 417 293 206 minecraft:stone_bricks
fill 417 293 207 417 296 207 minecraft:mossy_cobblestone
setblock 417 293 211 minecraft:stone_bricks
fill 417 293 212 417 296 212 minecraft:mossy_cobblestone
setblock 417 293 221 minecraft:stone_bricks
fill 417 293 222 417 296 222 minecraft:mossy_cobblestone
fill 377 294 182 379 294 182 minecraft:mossy_cobblestone
setblock 377 294 185 minecraft:stone_bricks
fill 377 294 186 378 296 186 minecraft:mossy_cobblestone
fill 377 294 188 377 294 189 minecraft:mossy_cobblestone
setblock 377 294 190 minecraft:stone_bricks
setblock 377 294 195 minecraft:stone_bricks
fill 377 294 196 377 297 196 minecraft:mossy_cobblestone
setblock 377 294 200 minecraft:stone_bricks
fill 377 294 201 377 297 201 minecraft:mossy_cobblestone
setblock 377 294 205 minecraft:stone_bricks
fill 377 294 206 377 297 206 minecraft:mossy_cobblestone
setblock 377 294 210 minecraft:stone_bricks
setblock 378 294 183 minecraft:mossy_cobblestone
setblock 378 294 184 minecraft:stone_bricks
fill 378 294 185 378 297 185 minecraft:mossy_cobblestone
setblock 378 294 199 minecraft:stone_bricks
fill 378 294 200 378 297 200 minecraft:mossy_cobblestone
setblock 378 294 204 minecraft:stone_bricks
fill 378 294 205 378 297 205 minecraft:mossy_cobblestone
setblock 378 294 209 minecraft:stone_bricks
setblock 379 294 183 minecraft:stone_bricks
setblock 379 294 203 minecraft:stone_bricks
fill 379 294 204 379 297 204 minecraft:mossy_cobblestone
setblock 379 294 207 minecraft:mossy_cobblestone
setblock 379 294 222 minecraft:mossy_cobblestone
setblock 380 294 182 minecraft:stone_bricks
fill 380 294 183 380 297 183 minecraft:mossy_cobblestone
setblock 380 294 222 minecraft:stone_bricks
fill 381 294 182 381 297 182 minecraft:mossy_cobblestone
fill 381 294 184 381 295 184 minecraft:mossy_cobblestone
fill 381 294 222 381 297 222 minecraft:mossy_cobblestone
setblock 383 294 184 minecraft:stone_bricks
setblock 384 294 183 minecraft:stone_bricks
fill 384 294 184 384 297 184 minecraft:mossy_cobblestone
setblock 385 294 182 minecraft:stone_bricks
fill 385 294 183 388 294 183 minecraft:mossy_cobblestone
setblock 385 294 222 minecraft:stone_bricks
fill 386 294 182 389 294 182 minecraft:mossy_cobblestone
setblock 386 294 222 minecraft:mossy_cobblestone
setblock 389 294 183 minecraft:stone_bricks
setblock 390 294 182 minecraft:stone_bricks
fill 390 294 183 393 294 183 minecraft:mossy_cobblestone
fill 391 294 182 394 294 182 minecraft:mossy_cobblestone
setblock 394 294 183 minecraft:stone_bricks
setblock 394 294 222 minecraft:mossy_cobblestone
setblock 395 294 182 minecraft:stone_bricks
fill 395 294 183 398 294 183 minecraft:mossy_cobblestone
setblock 395 294 222 minecraft:stone_bricks
fill 396 294 182 399 294 182 minecraft:mossy_cobblestone
fill 396 294 222 399 294 222 minecraft:mossy_cobblestone
setblock 397 294 184 minecraft:mossy_cobblestone
fill 397 294 221 400 294 221 minecraft:mossy_cobblestone
setblock 398 294 184 minecraft:stone_bricks
setblock 399 294 183 minecraft:stone_bricks
fill 399 294 184 399 297 184 minecraft:mossy_cobblestone
setblock 400 294 182 minecraft:stone_bricks
fill 400 294 183 400 297 183 minecraft:mossy_cobblestone
setblock 400 294 222 minecraft:stone_bricks
fill 401 294 182 401 297 182 minecraft:mossy_cobblestone
setblock 401 294 221 minecraft:stone_bricks
fill 401 294 222 404 294 222 minecraft:mossy_cobblestone
setblock 402 294 220 minecraft:stone_bricks
fill 402 294 221 405 294 221 minecraft:mossy_cobblestone
setblock 403 294 184 minecraft:stone_bricks
setblock 404 294 183 minecraft:stone_bricks
setblock 404 294 184 minecraft:mossy_cobblestone
setblock 405 294 182 minecraft:stone_bricks
fill 405 294 183 405 297 183 minecraft:mossy_cobblestone
setblock 405 294 222 minecraft:stone_bricks
fill 406 294 182 406 297 182 minecraft:mossy_cobblestone
setblock 406 294 221 minecraft:stone_bricks
fill 406 294 222 406 297 222 minecraft:mossy_cobblestone
setblock 407 294 221 minecraft:mossy_cobblestone
setblock 410 294 222 minecraft:stone_bricks
setblock 411 294 222 minecraft:mossy_cobblestone
fill 416 294 202 416 297 202 minecraft:mossy_cobblestone
setblock 416 294 205 minecraft:mossy_cobblestone
setblock 416 294 206 minecraft:stone_bricks
fill 416 294 207 416 295 209 minecraft:mossy_cobblestone
fill 416 294 222 416 297 222 minecraft:mossy_cobblestone
fill 417 294 182 417 295 183 minecraft:mossy_cobblestone
setblock 417 294 200 minecraft:stone_bricks
fill 417 294 201 417 297 201 minecraft:mossy_cobblestone
setblock 417 294 205 minecraft:stone_bricks
fill 417 294 206 417 297 206 minecraft:mossy_cobblestone
setblock 417 294 210 minecraft:stone_bricks
fill 417 294 211 417 297 211 minecraft:mossy_cobblestone
fill 417 294 213 417 295 213 minecraft:mossy_cobblestone
fill 417 294 221 417 297 221 minecraft:mossy_cobblestone
fill 377 295 182 377 295 183 minecraft:mossy_cobblestone
setblock 377 295 184 minecraft:stone_bricks
fill 377 295 185 377 298 185 minecraft:mossy_cobblestone
setblock 377 295 188 minecraft:mossy_cobblestone
setblock 377 295 189 minecraft:stone_bricks
fill 377 295 190 377 295 193 minecraft:mossy_cobblestone
setblock 377 295 194 minecraft:stone_bricks
fill 377 295 195 377 298 195 minecraft:mossy_cobblestone
setblock 377 295 199 minecraft:stone_bricks
fill 377 295 200 377 298 200 minecraft:mossy_cobblestone
setblock 377 295 204 minecraft:stone_bricks
fill 377 295 205 377 298 205 minecraft:mossy_cobblestone
setblock 377 295 208 minecraft:mossy_cobblestone
setblock 377 295 209 minecraft:stone_bricks
fill 377 295 210 377 297 211 minecraft:mossy_cobblestone
setblock 378 295 182 minecraft:mossy_cobblestone
setblock 378 295 183 minecraft:stone_bricks
fill 378 295 184 378 298 184 minecraft:mossy_cobblestone
setblock 378 295 187 minecraft:mossy_cobblestone
setblock 378 295 188 minecraft:stone_bricks
fill 378 295 189 378 298 189 minecraft:mossy_cobblestone
setblock 378 295 198 minecraft:stone_bricks
fill 378 295 199 378 298 199 minecraft:mossy_cobblestone
setblock 378 295 203 minecraft:stone_bricks
fill 378 295 204 378 298 204 minecraft:mossy_cobblestone
setblock 378 295 208 minecraft:stone_bricks
fill 378 295 209 378 298 209 minecraft:mossy_cobblestone
setblock 379 295 182 minecraft:stone_bricks
fill 379 295 183 379 298 183 minecraft:mossy_cobblestone
fill 379 295 185 379 296 185 minecraft:mossy_cobblestone
setblock 379 295 202 minecraft:stone_bricks
fill 379 295 203 379 298 203 minecraft:mossy_cobblestone
setblock 379 295 207 minecraft:stone_bricks
setblock 379 295 222 minecraft:stone_bricks
fill 380 295 182 380 298 182 minecraft:mossy_cobblestone
fill 380 295 184 380 296 184 minecraft:mossy_cobblestone
fill 380 295 222 380 298 222 minecraft:mossy_cobblestone
setblock 382 295 183 minecraft:mossy_cobblestone
setblock 382 295 184 minecraft:stone_bricks
setblock 383 295 183 minecraft:stone_bricks
fill 383 295 184 383 298 184 minecraft:mossy_cobblestone
setblock 384 295 182 minecraft:stone_bricks
fill 384 295 183 387 295 183 minecraft:mossy_cobblestone
setblock 384 295 222 minecraft:stone_bricks
fill 385 295 182 388 295 182 minecraft:mossy_cobblestone
setblock 388 295 183 minecraft:stone_bricks
setblock 389 295 182 minecraft:stone_bricks
fill 389 295 183 392 295 183 minecraft:mossy_cobblestone
fill 390 295 182 393 295 182 minecraft:mossy_cobblestone
setblock 393 295 183 minecraft:stone_bricks
setblock 394 295 182 minecraft:stone_bricks
fill 394 295 183 397 295 183 minecraft:mossy_cobblestone
setblock 394 295 222 minecraft:stone_bricks
fill 395 295 182 398 295 182 minecraft:mossy_cobblestone
fill 395 295 222 398 295 222 minecraft:mossy_cobblestone
setblock 396 295 184 minecraft:mossy_cobblestone
setblock 397 295 184 minecraft:stone_bricks
fill 397 295 221 399 295 221 minecraft:mossy_cobblestone
setblock 398 295 183 minecraft:stone_bricks
fill 398 295 184 398 298 184 minecraft:mossy_cobblestone
setblock 399 295 182 minecraft:stone_bricks
fill 399 295 183 399 298 183 minecraft:mossy_cobblestone
setblock 399 295 222 minecraft:stone_bricks
fill 400 295 182 400 298 182 minecraft:mossy_cobblestone
setblock 400 295 221 minecraft:stone_bricks
fill 400 295 222 403 295 222 minecraft:mossy_cobblestone
fill 401 295 221 404 295 221 minecraft:mossy_cobblestone
setblock 402 295 184 minecraft:stone_bricks
setblock 403 295 183 minecraft:stone_bricks
fill 403 295 184 403 298 184 minecraft:mossy_cobblestone
setblock 404 295 182 minecraft:stone_bricks
fill 404 295 183 404 298 183 minecraft:mossy_cobblestone
setblock 404 295 222 minecraft:stone_bricks
fill 405 295 182 405 298 182 minecraft:mossy_cobblestone
setblock 405 295 221 minecraft:stone_bricks
fill 405 295 222 405 298 222 minecraft:mossy_cobblestone
setblock 406 295 221 minecraft:mossy_cobblestone
setblock 409 295 222 minecraft:stone_bricks
fill 416 295 201 416 298 201 minecraft:mossy_cobblestone
setblock 416 295 205 minecraft:stone_bricks
fill 416 295 206 416 298 206 minecraft:mossy_cobblestone
setblock 416 295 210 minecraft:stone_bricks
setblock 417 295 184 minecraft:stone_bricks
fill 417 295 185 417 297 186 minecraft:mossy_cobblestone
setblock 417 295 199 minecraft:stone_bricks
fill 417 295 200 417 298 200 minecraft:mossy_cobblestone
setblock 417 295 204 minecraft:stone_bricks
fill 417 295 205 417 298 205 minecraft:mossy_cobblestone
setblock 417 295 209 minecraft:stone_bricks
fill 417 295 210 417 298 210 minecraft:mossy_cobblestone
setblock 417 295 214 minecraft:stone_bricks
setblock 377 296 182 minecraft:mossy_cobblestone
setblock 377 296 183 minecraft:stone_bricks
fill 377 296 184 377 299 184 minecraft:mossy_cobblestone
setblock 377 296 188 minecraft:stone_bricks
fill 377 296 189 377 296 192 minecraft:mossy_cobblestone
setblock 377 296 193 minecraft:stone_bricks
fill 377 296 194 378 298 194 minecraft:mossy_cobblestone
setblock 377 296 198 minecraft:stone_bricks
fill 377 296 199 377 299 199 minecraft:mossy_cobblestone
setblock 377 296 203 minecraft:stone_bricks
fill 377 296 204 377 299 204 minecraft:mossy_cobblestone
setblock 377 296 208 minecraft:stone_bricks
fill 377 296 209 377 299 209 minecraft:mossy_cobblestone
setblock 377 296 212 minecraft:mossy_cobblestone
setblock 378 296 182 minecraft:stone_bricks
fill 378 296 183 378 299 183 minecraft:mossy_cobblestone
setblock 378 296 187 minecraft:stone_bricks
fill 378 296 188 379 298 188 minecraft:mossy_cobblestone
fill 378 296 190 378 296 191 minecraft:mossy_cobblestone
setblock 378 296 192 minecraft:stone_bricks
fill 378 296 193 378 299 193 minecraft:mossy_cobblestone
fill 378 296 195 378 296 196 minecraft:mossy_cobblestone
setblock 378 296 197 minecraft:stone_bricks
fill 378 296 198 378 299 198 minecraft:mossy_cobblestone
setblock 378 296 202 minecraft:stone_bricks
fill 378 296 203 378 299 203 minecraft:mossy_cobblestone
setblock 378 296 207 minecraft:stone_bricks
fill 378 296 208 379 298 208 minecraft:mossy_cobblestone
fill 378 296 210 378 297 210 minecraft:mossy_cobblestone
setblock 378 296 222 minecraft:stone_bricks
fill 379 296 182 379 299 182 minecraft:mossy_cobblestone
fill 379 296 184 379 297 184 minecraft:mossy_cobblestone
setblock 379 296 186 minecraft:stone_bricks
fill 379 296 187 379 299 187 minecraft:mossy_cobblestone
fill 379 296 189 379 297 189 minecraft:mossy_cobblestone
setblock 379 296 201 minecraft:stone_bricks
fill 379 296 202 379 299 202 minecraft:mossy_cobblestone
setblock 379 296 206 minecraft:stone_bricks
fill 379 296 207 379 299 207 minecraft:mossy_cobblestone
fill 379 296 222 379 299 222 minecraft:mossy_cobblestone
setblock 381 296 184 minecraft:stone_bricks
setblock 382 296 183 minecraft:stone_bricks
fill 382 296 184 382 299 184 minecraft:mossy_cobblestone
setblock 383 296 182 minecraft:stone_bricks
fill 383 296 183 386 296 183 minecraft:mossy_cobblestone
setblock 383 296 222 minecraft:stone_bricks
fill 384 296 182 387 296 182 minecraft:mossy_cobblestone
setblock 384 296 222 minecraft:mossy_cobblestone
setblock 386 296 184 minecraft:stone_bricks
setblock 387 296 183 minecraft:stone_bricks
setblock 388 296 182 minecraft:stone_bricks
fill 388 296 183 391 296 183 minecraft:mossy_cobblestone
fill 389 296 182 392 296 182 minecraft:mossy_cobblestone
setblock 392 296 183 minecraft:stone_bricks
setblock 393 296 182 minecraft:stone_bricks
fill 393 296 183 396 296 183 minecraft:mossy_cobblestone
fill 394 296 182 397 296 182 minecraft:mossy_cobblestone
fill 394 296 222 397 296 222 minecraft:mossy_cobblestone
setblock 395 296 184 minecraft:mossy_cobblestone
setblock 396 296 184 minecraft:stone_bricks
setblock 397 296 183 minecraft:stone_bricks
fill 397 296 184 397 299 184 minecraft:mossy_cobblestone
fill 397 296 221 398 296 221 minecraft:mossy_cobblestone
setblock 398 296 182 minecraft:stone_bricks
fill 398 296 183 398 299 183 minecraft:mossy_cobblestone
setblock 398 296 222 minecraft:stone_bricks
fill 399 296 182 399 299 182 minecraft:mossy_cobblestone
setblock 399 296 221 minecraft:stone_bricks
fill 399 296 222 402 296 222 minecraft:mossy_cobblestone
fill 400 296 221 403 296 221 minecraft:mossy_cobblestone
setblock 401 296 184 minecraft:stone_bricks
setblock 402 296 183 minecraft:stone_bricks
fill 402 296 184 402 299 184 minecraft:mossy_cobblestone
setblock 403 296 182 minecraft:stone_bricks
fill 403 296 183 403 299 183 minecraft:mossy_cobblestone
setblock 403 296 222 minecraft:stone_bricks
fill 404 296 182 404 299 182 minecraft:mossy_cobblestone
setblock 404 296 221 minecraft:stone_bricks
fill 404 296 222 404 299 222 minecraft:mossy_cobblestone
fill 405 296 221 405 297 221 minecraft:mossy_cobblestone
setblock 408 296 182 minecraft:stone_bricks
setblock 408 296 222 minecraft:stone_bricks
setblock 415 296 205 minecraft:stone_bricks
fill 415 296 206 415 298 207 minecraft:mossy_cobblestone
fill 416 296 182 417 296 182 minecraft:mossy_cobblestone
setblock 416 296 204 minecraft:stone_bricks
fill 416 296 205 416 299 205 minecraft:mossy_cobblestone
fill 416 296 207 416 296 208 minecraft:mossy_cobblestone
setblock 416 296 209 minecraft:stone_bricks
fill 416 296 210 416 298 211 minecraft:mossy_cobblestone
setblock 417 296 183 minecraft:stone_bricks
fill 417 296 184 417 299 184 minecraft:mossy_cobblestone
setblock 417 296 187 minecraft:mossy_cobblestone
setblock 417 296 188 minecraft:stone_bricks
fill 417 296 189 417 299 189 minecraft:mossy_cobblestone
setblock 417 296 197 minecraft:mossy_cobblestone
setblock 417 296 198 minecraft:stone_bricks
fill 417 296 199 417 299 199 minecraft:mossy_cobblestone
setblock 417 296 203 minecraft:stone_bricks
fill 417 296 204 417 299 204 minecraft:mossy_cobblestone
setblock 417 296 208 minecraft:stone_bricks
fill 417 296 209 417 299 209 minecraft:mossy_cobblestone
setblock 417 296 213 minecraft:stone_bricks
fill 417 296 214 417 298 215 minecraft:mossy_cobblestone
setblock 377 297 182 minecraft:stone_bricks
fill 377 297 183 377 300 183 minecraft:mossy_cobblestone
setblock 377 297 186 minecraft:mossy_cobblestone
setblock 377 297 187 minecraft:stone_bricks
fill 377 297 188 377 297 191 minecraft:mossy_cobblestone
setblock 377 297 192 minecraft:stone_bricks
fill 377 297 193 377 300 193 minecraft:mossy_cobblestone
setblock 377 297 197 minecraft:stone_bricks
fill 377 297 198 377 300 198 minecraft:mossy_cobblestone
setblock 377 297 202 minecraft:stone_bricks
fill 377 297 203 377 300 203 minecraft:mossy_cobblestone
setblock 377 297 207 minecraft:stone_bricks
fill 377 297 208 377 300 208 minecraft:mossy_cobblestone
setblock 377 297 212 minecraft:stone_bricks
fill 377 297 213 377 300 213 minecraft:mossy_cobblestone
fill 378 297 182 378 300 182 minecraft:mossy_cobblestone
setblock 378 297 186 minecraft:stone_bricks
fill 378 297 187 378 300 187 minecraft:mossy_cobblestone
setblock 378 297 190 minecraft:mossy_cobblestone
setblock 378 297 191 minecraft:stone_bricks
fill 378 297 192 378 300 192 minecraft:mossy_cobblestone
setblock 378 297 195 minecraft:mossy_cobblestone
setblock 378 297 196 minecraft:stone_bricks
fill 378 297 197 378 300 197 minecraft:mossy_cobblestone
setblock 378 297 201 minecraft:stone_bricks
fill 378 297 202 378 300 202 minecraft:mossy_cobblestone
setblock 378 297 206 minecraft:stone_bricks
fill 378 297 207 378 300 207 minecraft:mossy_cobblestone
setblock 378 297 211 minecraft:stone_bricks
fill 378 297 222 378 300 222 minecraft:mossy_cobblestone
setblock 379 297 185 minecraft:stone_bricks
fill 379 297 186 380 299 186 minecraft:mossy_cobblestone
setblock 379 297 190 minecraft:stone_bricks
fill 379 297 191 379 300 191 minecraft:mossy_cobblestone
setblock 379 297 192 minecraft:light[level=12]
setblock 379 297 200 minecraft:stone_bricks
fill 379 297 201 379 300 201 minecraft:mossy_cobblestone
setblock 379 297 205 minecraft:stone_bricks
fill 379 297 206 379 300 206 minecraft:mossy_cobblestone
setblock 379 297 209 minecraft:mossy_cobblestone
setblock 379 297 216 minecraft:light[level=12]
setblock 380 297 184 minecraft:stone_bricks
fill 380 297 185 382 298 185 minecraft:mossy_cobblestone
fill 380 297 187 380 298 187 minecraft:mossy_cobblestone
setblock 381 297 183 minecraft:stone_bricks
fill 381 297 184 381 300 184 minecraft:mossy_cobblestone
setblock 382 297 182 minecraft:stone_bricks
fill 382 297 183 385 297 183 minecraft:mossy_cobblestone
setblock 382 297 222 minecraft:stone_bricks
fill 383 297 182 386 297 182 minecraft:mossy_cobblestone
fill 383 297 222 383 298 222 minecraft:mossy_cobblestone
setblock 385 297 184 minecraft:stone_bricks
setblock 386 297 183 minecraft:stone_bricks
fill 386 297 184 386 300 184 minecraft:mossy_cobblestone
setblock 387 297 182 minecraft:stone_bricks
fill 387 297 183 390 297 183 minecraft:mossy_cobblestone
setblock 387 297 184 minecraft:light[level=12]
setblock 387 297 192 minecraft:light[level=12]
setblock 387 297 200 minecraft:light[level=12]
setblock 387 297 208 minecraft:light[level=12]
setblock 387 297 216 minecraft:light[level=12]
fill 388 297 182 391 297 182 minecraft:mossy_cobblestone
setblock 391 297 183 minecraft:stone_bricks
setblock 392 297 182 minecraft:stone_bricks
fill 392 297 183 395 297 183 minecraft:mossy_cobblestone
fill 393 297 182 396 297 182 minecraft:mossy_cobblestone
fill 393 297 222 396 297 222 minecraft:mossy_cobblestone
setblock 394 297 184 minecraft:mossy_cobblestone
setblock 395 297 184 minecraft:stone_bricks
setblock 395 297 192 minecraft:light[level=12]
setblock 395 297 200 minecraft:light[level=12]
setblock 395 297 208 minecraft:light[level=12]
setblock 395 297 216 minecraft:light[level=12]
setblock 396 297 183 minecraft:stone_bricks
fill 396 297 184 396 300 184 minecraft:mossy_cobblestone
fill 396 297 221 397 297 221 minecraft:mossy_cobblestone
setblock 397 297 182 minecraft:stone_bricks
fill 397 297 183 397 300 183 minecraft:mossy_cobblestone
setblock 397 297 222 minecraft:stone_bricks
fill 398 297 182 398 300 182 minecraft:mossy_cobblestone
setblock 398 297 221 minecraft:stone_bricks
fill 398 297 222 401 297 222 minecraft:mossy_cobblestone
setblock 399 297 185 minecraft:stone_bricks
fill 399 297 221 402 297 221 minecraft:mossy_cobblestone
setblock 400 297 184 minecraft:stone_bricks
setblock 401 297 183 minecraft:stone_bricks
fill 401 297 184 401 300 184 minecraft:mossy_cobblestone
setblock 402 297 182 minecraft:stone_bricks
fill 402 297 183 402 300 183 minecraft:mossy_cobblestone
setblock 402 297 222 minecraft:stone_bricks
fill 403 297 182 403 300 182 minecraft:mossy_cobblestone
setblock 403 297 192 minecraft:light[level=12]
setblock 403 297 200 minecraft:light[level=12]
setblock 403 297 208 minecraft:light[level=12]
setblock 403 297 216 minecraft:light[level=12]
setblock 403 297 221 minecraft:stone_bricks
fill 403 297 222 403 300 222 minecraft:mossy_cobblestone
fill 404 297 221 404 299 221 minecraft:mossy_cobblestone
setblock 407 297 182 minecraft:stone_bricks
setblock 407 297 222 minecraft:stone_bricks
setblock 408 297 222 minecraft:mossy_cobblestone
setblock 411 297 184 minecraft:light[level=12]
setblock 411 297 192 minecraft:light[level=12]
setblock 411 297 200 minecraft:light[level=12]
setblock 411 297 208 minecraft:light[level=12]
setblock 411 297 216 minecraft:light[level=12]
fill 415 297 182 416 297 182 minecraft:mossy_cobblestone
setblock 415 297 204 minecraft:stone_bricks
fill 415 297 205 415 300 205 minecraft:mossy_cobblestone
setblock 415 297 208 minecraft:mossy_cobblestone
setblock 415 297 209 minecraft:stone_bricks
fill 415 297 210 415 300 210 minecraft:mossy_cobblestone
fill 416 297 200 416 299 200 minecraft:mossy_cobblestone
setblock 416 297 203 minecraft:stone_bricks
fill 416 297 204 416 300 204 minecraft:mossy_cobblestone
setblock 416 297 207 minecraft:mossy_cobblestone
setblock 416 297 208 minecraft:stone_bricks
fill 416 297 209 416 300 209 minecraft:mossy_cobblestone
setblock 416 297 212 minecraft:mossy_cobblestone
setblock 416 297 213 minecraft:stone_bricks
setblock 417 297 182 minecraft:stone_bricks
fill 417 297 183 417 300 183 minecraft:mossy_cobblestone
setblock 417 297 187 minecraft:stone_bricks
fill 417 297 188 417 300 188 minecraft:mossy_cobblestone
fill 417 297 190 417 297 191 minecraft:mossy_cobblestone
setblock 417 297 192 minecraft:stone_bricks
fill 417 297 193 417 297 196 minecraft:mossy_cobblestone
setblock 417 297 197 minecraft:stone_bricks
fill 417 297 198 417 300 198 minecraft:mossy_cobblestone
setblock 417 297 202 minecraft:stone_bricks
fill 417 297 203 417 300 203 minecraft:mossy_cobblestone
setblock 417 297 207 minecraft:stone_bricks
fill 417 297 208 417 300 208 minecraft:mossy_cobblestone
setblock 417 297 212 minecraft:stone_bricks
fill 417 297 213 417 300 213 minecraft:mossy_cobblestone
setblock 417 297 216 minecraft:mossy_cobblestone
setblock 417 297 217 minecraft:stone_bricks
fill 417 297 220 417 298 220 minecraft:mossy_cobblestone
setblock 417 297 222 minecraft:stone_bricks
fill 377 298 182 377 300 182 minecraft:mossy_cobblestone
setblock 377 298 186 minecraft:stone_bricks
fill 377 298 187 377 298 190 minecraft:mossy_cobblestone
setblock 377 298 191 minecraft:stone_bricks
fill 377 298 192 377 300 192 minecraft:mossy_cobblestone
setblock 377 298 196 minecraft:stone_bricks
fill 377 298 197 377 300 197 minecraft:mossy_cobblestone
setblock 377 298 201 minecraft:stone_bricks
fill 377 298 202 377 300 202 minecraft:mossy_cobblestone
setblock 377 298 206 minecraft:stone_bricks
fill 377 298 207 377 300 207 minecraft:mossy_cobblestone
setblock 377 298 210 minecraft:mossy_cobblestone
setblock 377 298 211 minecraft:stone_bricks
fill 377 298 212 378 300 212 minecraft:mossy_cobblestone
fill 377 298 214 377 298 215 minecraft:mossy_cobblestone
fill 377 298 222 377 300 222 minecraft:mossy_cobblestone
setblock 378 298 185 minecraft:stone_bricks
fill 378 298 186 378 300 186 minecraft:mossy_cobblestone
setblock 378 298 190 minecraft:stone_bricks
fill 378 298 191 378 300 191 minecraft:mossy_cobblestone
setblock 378 298 195 minecraft:stone_bricks
fill 378 298 196 378 300 196 minecraft:mossy_cobblestone
setblock 378 298 200 minecraft:stone_bricks
fill 378 298 201 378 300 201 minecraft:mossy_cobblestone
setblock 378 298 205 minecraft:stone_bricks
fill 378 298 206 378 300 206 minecraft:mossy_cobblestone
setblock 378 298 210 minecraft:stone_bricks
fill 378 298 211 378 300 211 minecraft:mossy_cobblestone
setblock 379 298 184 minecraft:stone_bricks
fill 379 298 185 379 300 185 minecraft:mossy_cobblestone
setblock 379 298 189 minecraft:stone_bricks
fill 379 298 190 380 300 190 minecraft:mossy_cobblestone
fill 379 298 192 379 298 193 minecraft:mossy_cobblestone
setblock 379 298 194 minecraft:stone_bricks
schedule function dropper:buildpart/44_12 1t
