setblock 473 280 259 minecraft:light[level=12]
setblock 473 280 263 minecraft:light[level=15]
fill 473 280 267 475 284 267 minecraft:red_concrete
fill 474 280 235 476 300 235 minecraft:white_concrete
fill 475 280 233 477 300 233 minecraft:white_concrete
fill 476 280 231 476 293 232 minecraft:white_concrete
fill 477 280 232 477 300 232 minecraft:white_concrete
setblock 480 280 231 minecraft:light[level=12]
setblock 480 280 238 minecraft:light[level=12]
setblock 480 280 245 minecraft:light[level=12]
setblock 480 280 252 minecraft:light[level=12]
setblock 480 280 259 minecraft:light[level=12]
setblock 480 280 266 minecraft:light[level=12]
setblock 481 280 231 minecraft:light[level=15]
setblock 481 280 239 minecraft:light[level=15]
setblock 481 280 247 minecraft:light[level=15]
setblock 481 280 255 minecraft:light[level=15]
setblock 481 280 263 minecraft:light[level=15]
setblock 487 280 231 minecraft:light[level=12]
setblock 487 280 238 minecraft:light[level=12]
setblock 487 280 245 minecraft:light[level=12]
setblock 487 280 252 minecraft:light[level=12]
setblock 487 280 259 minecraft:light[level=12]
setblock 487 280 266 minecraft:light[level=12]
setblock 489 280 231 minecraft:light[level=15]
setblock 489 280 239 minecraft:light[level=15]
setblock 489 280 247 minecraft:light[level=15]
setblock 489 280 255 minecraft:light[level=15]
setblock 489 280 263 minecraft:light[level=15]
setblock 494 280 231 minecraft:light[level=12]
setblock 494 280 245 minecraft:light[level=12]
setblock 494 280 252 minecraft:light[level=12]
setblock 494 280 259 minecraft:light[level=12]
setblock 494 280 266 minecraft:light[level=12]
fill 496 280 230 498 293 232 minecraft:white_concrete
setblock 497 280 247 minecraft:light[level=15]
setblock 497 280 255 minecraft:light[level=15]
setblock 497 280 263 minecraft:light[level=15]
setblock 501 280 231 minecraft:light[level=12]
setblock 501 280 238 minecraft:light[level=12]
setblock 501 280 245 minecraft:light[level=12]
setblock 501 280 252 minecraft:light[level=12]
setblock 501 280 259 minecraft:light[level=12]
setblock 501 280 266 minecraft:light[level=12]
setblock 505 280 231 minecraft:light[level=15]
setblock 505 280 239 minecraft:light[level=15]
setblock 505 280 247 minecraft:light[level=15]
setblock 505 280 255 minecraft:light[level=15]
setblock 505 280 263 minecraft:light[level=15]
fill 507 280 231 507 284 232 minecraft:white_concrete
fill 507 280 267 507 284 268 minecraft:white_concrete
fill 508 280 231 508 284 231 minecraft:white_concrete
setblock 508 280 232 minecraft:red_concrete
setblock 508 280 238 minecraft:light[level=12]
setblock 508 280 245 minecraft:light[level=12]
setblock 508 280 252 minecraft:light[level=12]
setblock 508 280 259 minecraft:light[level=12]
fill 508 280 267 508 284 267 minecraft:white_concrete
setblock 508 280 268 minecraft:red_concrete
fill 509 280 229 509 281 230 minecraft:white_concrete
fill 509 280 231 511 284 231 minecraft:red_concrete
fill 509 280 267 511 284 267 minecraft:red_concrete
fill 472 281 232 472 285 233 minecraft:white_concrete
fill 472 281 234 472 282 234 minecraft:brown_terracotta
fill 472 281 268 472 285 269 minecraft:white_concrete
setblock 473 281 233 minecraft:red_concrete
fill 473 281 235 473 282 235 minecraft:brown_terracotta
setblock 473 281 269 minecraft:red_concrete
setblock 474 281 229 minecraft:white_concrete
fill 474 281 230 475 284 230 minecraft:red_concrete
fill 474 281 236 476 282 236 minecraft:brown_terracotta
setblock 474 281 265 minecraft:white_concrete
fill 474 281 266 475 284 266 minecraft:red_concrete
fill 476 281 230 476 282 230 minecraft:brown_terracotta
fill 477 281 231 477 282 231 minecraft:brown_terracotta
fill 477 281 235 477 282 235 minecraft:brown_terracotta
fill 478 281 232 478 282 234 minecraft:brown_terracotta
fill 495 281 231 495 282 232 minecraft:brown_terracotta
fill 496 281 233 498 282 233 minecraft:brown_terracotta
fill 497 281 229 498 282 229 minecraft:brown_terracotta
fill 499 281 230 499 282 232 minecraft:brown_terracotta
fill 508 281 232 508 285 233 minecraft:white_concrete
fill 508 281 268 508 285 269 minecraft:white_concrete
setblock 509 281 233 minecraft:red_concrete
setblock 509 281 269 minecraft:red_concrete
setblock 510 281 229 minecraft:white_concrete
fill 510 281 230 511 284 230 minecraft:red_concrete
setblock 510 281 265 minecraft:white_concrete
fill 510 281 266 511 284 266 minecraft:red_concrete
fill 471 282 233 471 282 234 minecraft:brown_terracotta
fill 472 282 235 472 282 236 minecraft:brown_terracotta
fill 473 282 229 473 286 230 minecraft:red_concrete
fill 473 282 232 473 286 233 minecraft:white_concrete
setblock 473 282 236 minecraft:brown_terracotta
fill 473 282 265 473 286 266 minecraft:red_concrete
fill 473 282 268 473 286 269 minecraft:white_concrete
fill 474 282 229 474 285 229 minecraft:red_concrete
fill 474 282 237 476 282 237 minecraft:brown_terracotta
fill 474 282 265 474 285 265 minecraft:red_concrete
setblock 476 282 229 minecraft:brown_terracotta
fill 477 282 230 478 282 230 minecraft:brown_terracotta
fill 477 282 236 478 282 236 minecraft:brown_terracotta
setblock 478 282 231 minecraft:brown_terracotta
setblock 478 282 235 minecraft:brown_terracotta
fill 479 282 232 479 282 234 minecraft:brown_terracotta
setblock 495 282 230 minecraft:brown_terracotta
setblock 495 282 233 minecraft:brown_terracotta
setblock 496 282 229 minecraft:brown_terracotta
fill 497 282 234 498 282 234 minecraft:brown_terracotta
setblock 499 282 229 minecraft:brown_terracotta
setblock 499 282 233 minecraft:brown_terracotta
fill 500 282 231 500 282 232 minecraft:brown_terracotta
fill 509 282 229 509 286 230 minecraft:red_concrete
fill 509 282 232 509 286 233 minecraft:white_concrete
fill 509 282 265 509 286 266 minecraft:red_concrete
fill 509 282 268 509 286 269 minecraft:white_concrete
fill 510 282 229 510 285 229 minecraft:red_concrete
fill 510 282 265 510 285 265 minecraft:red_concrete
fill 471 283 265 471 286 265 minecraft:brown_terracotta
fill 472 283 229 472 287 229 minecraft:red_concrete
setblock 472 283 230 minecraft:white_concrete
fill 472 283 265 472 287 265 minecraft:red_concrete
setblock 472 283 266 minecraft:white_concrete
fill 474 283 232 474 287 233 minecraft:white_concrete
fill 474 283 268 474 287 269 minecraft:white_concrete
setblock 475 283 232 minecraft:red_concrete
setblock 475 283 268 minecraft:red_concrete
fill 508 283 229 508 287 229 minecraft:red_concrete
setblock 508 283 230 minecraft:white_concrete
fill 508 283 265 508 287 265 minecraft:red_concrete
setblock 508 283 266 minecraft:white_concrete
fill 510 283 232 510 287 233 minecraft:white_concrete
fill 510 283 268 510 287 269 minecraft:white_concrete
setblock 511 283 232 minecraft:red_concrete
setblock 511 283 268 minecraft:red_concrete
fill 471 284 230 472 287 230 minecraft:red_concrete
fill 471 284 266 472 287 266 minecraft:red_concrete
fill 475 284 232 475 288 232 minecraft:white_concrete
fill 475 284 240 477 285 240 minecraft:yellow_concrete
fill 475 284 268 475 288 268 minecraft:white_concrete
fill 476 284 239 476 285 239 minecraft:yellow_concrete
fill 476 284 241 476 285 241 minecraft:yellow_concrete
fill 505 284 242 506 285 243 minecraft:yellow_concrete
fill 507 284 230 508 287 230 minecraft:red_concrete
fill 507 284 266 508 287 266 minecraft:red_concrete
fill 511 284 232 511 288 232 minecraft:white_concrete
fill 511 284 268 511 288 268 minecraft:white_concrete
fill 471 285 231 472 289 231 minecraft:red_concrete
setblock 471 285 232 minecraft:white_concrete
fill 471 285 267 472 289 267 minecraft:red_concrete
setblock 471 285 268 minecraft:white_concrete
fill 473 285 231 475 289 231 minecraft:white_concrete
fill 473 285 267 475 289 267 minecraft:white_concrete
setblock 474 285 230 minecraft:red_concrete
setblock 474 285 266 minecraft:red_concrete
fill 475 285 230 475 290 230 minecraft:white_concrete
fill 475 285 266 475 290 266 minecraft:white_concrete
fill 507 285 231 508 289 231 minecraft:red_concrete
setblock 507 285 232 minecraft:white_concrete
fill 507 285 267 508 289 267 minecraft:red_concrete
setblock 507 285 268 minecraft:white_concrete
fill 509 285 231 511 289 231 minecraft:white_concrete
fill 509 285 267 511 289 267 minecraft:white_concrete
setblock 510 285 230 minecraft:red_concrete
setblock 510 285 266 minecraft:red_concrete
fill 511 285 230 511 290 230 minecraft:white_concrete
fill 511 285 266 511 290 266 minecraft:white_concrete
fill 471 286 232 472 289 232 minecraft:red_concrete
fill 471 286 268 472 289 268 minecraft:red_concrete
setblock 472 286 233 minecraft:white_concrete
setblock 472 286 269 minecraft:white_concrete
setblock 473 286 238 minecraft:light[level=12]
setblock 473 286 245 minecraft:light[level=12]
setblock 473 286 252 minecraft:light[level=12]
setblock 473 286 259 minecraft:light[level=12]
fill 474 286 229 474 290 230 minecraft:white_concrete
fill 474 286 265 474 290 266 minecraft:white_concrete
setblock 480 286 231 minecraft:light[level=12]
setblock 480 286 238 minecraft:light[level=12]
setblock 480 286 245 minecraft:light[level=12]
setblock 480 286 252 minecraft:light[level=12]
setblock 480 286 259 minecraft:light[level=12]
setblock 480 286 266 minecraft:light[level=12]
setblock 487 286 231 minecraft:light[level=12]
setblock 487 286 238 minecraft:light[level=12]
setblock 487 286 245 minecraft:light[level=12]
setblock 487 286 252 minecraft:light[level=12]
setblock 487 286 259 minecraft:light[level=12]
setblock 487 286 266 minecraft:light[level=12]
setblock 494 286 231 minecraft:light[level=12]
setblock 494 286 245 minecraft:light[level=12]
setblock 494 286 252 minecraft:light[level=12]
setblock 494 286 259 minecraft:light[level=12]
setblock 494 286 266 minecraft:light[level=12]
setblock 501 286 231 minecraft:light[level=12]
setblock 501 286 238 minecraft:light[level=12]
setblock 501 286 245 minecraft:light[level=12]
setblock 501 286 252 minecraft:light[level=12]
setblock 501 286 259 minecraft:light[level=12]
setblock 501 286 266 minecraft:light[level=12]
fill 507 286 232 508 289 232 minecraft:red_concrete
fill 507 286 268 508 289 268 minecraft:red_concrete
setblock 508 286 233 minecraft:white_concrete
setblock 508 286 238 minecraft:light[level=12]
setblock 508 286 245 minecraft:light[level=12]
setblock 508 286 252 minecraft:light[level=12]
setblock 508 286 259 minecraft:light[level=12]
setblock 508 286 269 minecraft:white_concrete
fill 510 286 229 510 290 230 minecraft:white_concrete
fill 510 286 265 510 290 266 minecraft:white_concrete
fill 472 287 233 473 290 233 minecraft:red_concrete
fill 472 287 269 473 290 269 minecraft:red_concrete
fill 473 287 229 473 291 230 minecraft:white_concrete
fill 473 287 232 473 291 232 minecraft:red_concrete
setblock 473 287 239 minecraft:light[level=15]
setblock 473 287 247 minecraft:light[level=15]
setblock 473 287 255 minecraft:light[level=15]
setblock 473 287 263 minecraft:light[level=15]
fill 473 287 265 473 291 266 minecraft:white_concrete
fill 473 287 268 473 291 268 minecraft:red_concrete
setblock 481 287 231 minecraft:light[level=15]
setblock 481 287 239 minecraft:light[level=15]
setblock 481 287 247 minecraft:light[level=15]
setblock 481 287 255 minecraft:light[level=15]
setblock 481 287 263 minecraft:light[level=15]
setblock 489 287 231 minecraft:light[level=15]
setblock 489 287 239 minecraft:light[level=15]
setblock 489 287 247 minecraft:light[level=15]
setblock 489 287 255 minecraft:light[level=15]
setblock 489 287 263 minecraft:light[level=15]
setblock 497 287 247 minecraft:light[level=15]
setblock 497 287 255 minecraft:light[level=15]
setblock 497 287 263 minecraft:light[level=15]
setblock 505 287 231 minecraft:light[level=15]
setblock 505 287 239 minecraft:light[level=15]
setblock 505 287 247 minecraft:light[level=15]
setblock 505 287 255 minecraft:light[level=15]
setblock 505 287 263 minecraft:light[level=15]
fill 508 287 233 509 290 233 minecraft:red_concrete
fill 508 287 269 509 290 269 minecraft:red_concrete
fill 509 287 229 509 291 230 minecraft:white_concrete
fill 509 287 232 509 291 232 minecraft:red_concrete
fill 509 287 265 509 291 266 minecraft:white_concrete
fill 509 287 268 509 291 268 minecraft:red_concrete
setblock 471 288 230 minecraft:red_concrete
setblock 471 288 266 minecraft:red_concrete
fill 472 288 229 472 292 230 minecraft:white_concrete
fill 472 288 265 472 292 266 minecraft:white_concrete
setblock 474 288 232 minecraft:white_concrete
fill 474 288 233 474 292 233 minecraft:red_concrete
setblock 474 288 268 minecraft:white_concrete
fill 474 288 269 474 292 269 minecraft:red_concrete
setblock 507 288 230 minecraft:red_concrete
setblock 507 288 266 minecraft:red_concrete
fill 508 288 229 508 292 230 minecraft:white_concrete
fill 508 288 265 508 292 266 minecraft:white_concrete
fill 509 288 250 509 289 250 minecraft:lime_concrete
setblock 510 288 232 minecraft:white_concrete
fill 510 288 233 510 292 233 minecraft:red_concrete
setblock 510 288 268 minecraft:white_concrete
fill 510 288 269 510 292 269 minecraft:red_concrete
fill 471 289 230 471 293 230 minecraft:white_concrete
fill 471 289 266 471 293 266 minecraft:white_concrete
fill 474 289 232 475 292 232 minecraft:red_concrete
fill 474 289 268 475 292 268 minecraft:red_concrete
fill 507 289 230 507 293 230 minecraft:white_concrete
fill 507 289 266 507 293 266 minecraft:white_concrete
fill 510 289 232 511 292 232 minecraft:red_concrete
fill 510 289 268 511 292 268 minecraft:red_concrete
fill 471 290 231 471 293 232 minecraft:white_concrete
fill 471 290 267 471 293 268 minecraft:white_concrete
fill 472 290 231 472 293 231 minecraft:white_concrete
setblock 472 290 232 minecraft:red_concrete
fill 472 290 267 472 293 267 minecraft:white_concrete
setblock 472 290 268 minecraft:red_concrete
fill 473 290 231 475 293 231 minecraft:red_concrete
fill 473 290 267 475 293 267 minecraft:red_concrete
fill 507 290 231 507 293 232 minecraft:white_concrete
fill 507 290 267 507 293 268 minecraft:white_concrete
fill 508 290 231 508 293 231 minecraft:white_concrete
setblock 508 290 232 minecraft:red_concrete
fill 508 290 267 508 293 267 minecraft:white_concrete
setblock 508 290 268 minecraft:red_concrete
fill 509 290 231 511 293 231 minecraft:red_concrete
fill 509 290 267 511 293 267 minecraft:red_concrete
fill 472 291 232 472 293 233 minecraft:white_concrete
fill 472 291 268 472 293 269 minecraft:white_concrete
setblock 473 291 233 minecraft:red_concrete
setblock 473 291 269 minecraft:red_concrete
setblock 474 291 229 minecraft:white_concrete
fill 474 291 230 475 293 230 minecraft:red_concrete
setblock 474 291 265 minecraft:white_concrete
fill 474 291 266 475 294 266 minecraft:red_concrete
fill 508 291 232 508 295 233 minecraft:white_concrete
fill 508 291 268 508 293 269 minecraft:white_concrete
setblock 509 291 233 minecraft:red_concrete
setblock 509 291 269 minecraft:red_concrete
setblock 510 291 229 minecraft:white_concrete
fill 510 291 230 511 293 230 minecraft:red_concrete
setblock 510 291 265 minecraft:white_concrete
fill 510 291 266 511 293 266 minecraft:red_concrete
fill 473 292 229 473 293 230 minecraft:red_concrete
fill 473 292 232 473 293 233 minecraft:white_concrete
setblock 473 292 238 minecraft:light[level=12]
setblock 473 292 245 minecraft:light[level=12]
setblock 473 292 252 minecraft:light[level=12]
setblock 473 292 259 minecraft:light[level=12]
fill 473 292 265 473 293 266 minecraft:red_concrete
fill 473 292 268 473 293 269 minecraft:white_concrete
fill 474 292 229 474 293 229 minecraft:red_concrete
fill 474 292 265 474 295 265 minecraft:red_concrete
setblock 480 292 231 minecraft:light[level=12]
setblock 480 292 238 minecraft:light[level=12]
setblock 480 292 245 minecraft:light[level=12]
setblock 480 292 252 minecraft:light[level=12]
setblock 480 292 259 minecraft:light[level=12]
setblock 480 292 266 minecraft:light[level=12]
setblock 487 292 231 minecraft:light[level=12]
setblock 487 292 238 minecraft:light[level=12]
setblock 487 292 245 minecraft:light[level=12]
setblock 487 292 252 minecraft:light[level=12]
setblock 487 292 259 minecraft:light[level=12]
setblock 487 292 266 minecraft:light[level=12]
setblock 494 292 231 minecraft:light[level=12]
setblock 494 292 245 minecraft:light[level=12]
setblock 494 292 252 minecraft:light[level=12]
setblock 494 292 259 minecraft:light[level=12]
setblock 494 292 266 minecraft:light[level=12]
setblock 501 292 231 minecraft:light[level=12]
setblock 501 292 238 minecraft:light[level=12]
setblock 501 292 245 minecraft:light[level=12]
setblock 501 292 252 minecraft:light[level=12]
setblock 501 292 259 minecraft:light[level=12]
setblock 501 292 266 minecraft:light[level=12]
setblock 508 292 238 minecraft:light[level=12]
setblock 508 292 245 minecraft:light[level=12]
setblock 508 292 252 minecraft:light[level=12]
setblock 508 292 259 minecraft:light[level=12]
fill 509 292 229 509 293 230 minecraft:red_concrete
fill 509 292 232 509 293 233 minecraft:white_concrete
fill 509 292 265 509 293 266 minecraft:red_concrete
fill 509 292 268 509 293 269 minecraft:white_concrete
fill 510 292 229 510 293 229 minecraft:red_concrete
fill 510 292 265 510 293 265 minecraft:red_concrete
setblock 472 293 229 minecraft:red_concrete
setblock 472 293 230 minecraft:white_concrete
setblock 472 293 265 minecraft:red_concrete
setblock 472 293 266 minecraft:white_concrete
fill 474 293 232 474 297 233 minecraft:white_concrete
fill 474 293 268 474 293 269 minecraft:white_concrete
setblock 475 293 232 minecraft:red_concrete
setblock 475 293 268 minecraft:red_concrete
setblock 508 293 229 minecraft:red_concrete
setblock 508 293 230 minecraft:white_concrete
fill 508 293 265 508 297 265 minecraft:red_concrete
setblock 508 293 266 minecraft:white_concrete
fill 510 293 232 510 293 233 minecraft:white_concrete
fill 510 293 268 510 293 269 minecraft:white_concrete
setblock 511 293 232 minecraft:red_concrete
setblock 511 293 268 minecraft:red_concrete
fill 471 294 229 473 294 269 minecraft:black_concrete
fill 474 294 229 511 294 231 minecraft:black_concrete
fill 474 294 234 477 300 234 minecraft:white_concrete
fill 474 294 267 511 294 269 minecraft:black_concrete
fill 475 294 232 476 298 232 minecraft:white_concrete
setblock 481 294 239 minecraft:light[level=15]
setblock 481 294 247 minecraft:light[level=15]
setblock 481 294 255 minecraft:light[level=15]
setblock 481 294 263 minecraft:light[level=15]
setblock 489 294 239 minecraft:light[level=15]
setblock 489 294 247 minecraft:light[level=15]
setblock 489 294 255 minecraft:light[level=15]
setblock 489 294 263 minecraft:light[level=15]
fill 496 294 232 498 300 232 minecraft:white_concrete
setblock 497 294 247 minecraft:light[level=15]
setblock 497 294 255 minecraft:light[level=15]
setblock 497 294 263 minecraft:light[level=15]
setblock 505 294 239 minecraft:light[level=15]
setblock 505 294 247 minecraft:light[level=15]
setblock 505 294 255 minecraft:light[level=15]
setblock 505 294 263 minecraft:light[level=15]
fill 507 294 232 507 295 232 minecraft:white_concrete
fill 507 294 266 508 297 266 minecraft:red_concrete
fill 509 294 232 511 294 266 minecraft:black_concrete
fill 471 295 229 473 295 269 minecraft:gray_concrete
fill 474 295 229 511 295 231 minecraft:gray_concrete
setblock 474 295 266 minecraft:red_concrete
fill 474 295 267 511 295 269 minecraft:gray_concrete
fill 475 295 266 475 300 266 minecraft:white_concrete
fill 509 295 232 511 295 266 minecraft:gray_concrete
fill 471 296 230 472 297 232 minecraft:red_concrete
setblock 471 296 235 minecraft:red_concrete
setblock 471 296 246 minecraft:lime_concrete
setblock 471 296 247 minecraft:red_concrete
fill 471 296 266 472 297 268 minecraft:red_concrete
fill 472 296 229 473 296 229 minecraft:red_concrete
fill 472 296 233 472 297 233 minecraft:brown_concrete
setblock 472 296 260 minecraft:yellow_concrete
fill 472 296 265 473 296 265 minecraft:red_concrete
fill 472 296 269 474 296 269 minecraft:white_concrete
setblock 473 296 230 minecraft:red_concrete
fill 473 296 231 473 296 234 minecraft:white_concrete
setblock 473 296 249 minecraft:yellow_concrete
setblock 473 296 266 minecraft:red_concrete
fill 473 296 267 475 296 268 minecraft:white_concrete
fill 474 296 229 474 299 231 minecraft:white_concrete
fill 474 296 265 474 300 266 minecraft:white_concrete
fill 475 296 230 475 299 231 minecraft:white_concrete
fill 476 296 231 476 300 231 minecraft:white_concrete
fill 478 296 230 478 297 230 minecraft:brown_concrete
setblock 488 296 230 minecraft:red_concrete
setblock 493 296 231 minecraft:white_concrete
fill 496 296 230 498 300 231 minecraft:white_concrete
fill 498 296 267 498 297 267 minecraft:brown_concrete
setblock 500 296 229 minecraft:light_blue_concrete
fill 507 296 230 508 297 232 minecraft:red_concrete
fill 507 296 267 508 299 268 minecraft:red_concrete
fill 508 296 229 509 296 229 minecraft:red_concrete
fill 508 296 233 510 296 233 minecraft:white_concrete
fill 508 296 269 510 296 269 minecraft:white_concrete
setblock 509 296 230 minecraft:red_concrete
fill 509 296 231 511 296 232 minecraft:white_concrete
setblock 509 296 259 minecraft:magenta_concrete
fill 509 296 265 509 296 266 minecraft:red_concrete
fill 509 296 267 511 296 268 minecraft:white_concrete
fill 510 296 229 510 300 230 minecraft:white_concrete
fill 510 296 258 510 297 258 minecraft:brown_concrete
fill 510 296 265 510 300 266 minecraft:white_concrete
fill 511 296 230 511 300 230 minecraft:white_concrete
fill 511 296 266 511 300 266 minecraft:white_concrete
fill 471 297 233 471 297 235 minecraft:magenta_concrete
fill 471 297 259 471 300 259 minecraft:brown_concrete
setblock 472 297 229 minecraft:red_concrete
fill 472 297 234 472 297 236 minecraft:magenta_concrete
setblock 472 297 260 minecraft:brown_concrete
setblock 472 297 265 minecraft:red_concrete
fill 472 297 269 473 300 269 minecraft:red_concrete
fill 473 297 229 473 299 231 minecraft:white_concrete
fill 473 297 232 473 301 233 minecraft:red_concrete
fill 473 297 234 473 300 234 minecraft:white_concrete
fill 473 297 235 473 297 237 minecraft:magenta_concrete
fill 473 297 265 473 299 267 minecraft:white_concrete
fill 473 297 268 473 301 268 minecraft:red_concrete
fill 474 297 236 477 297 237 minecraft:magenta_concrete
fill 474 297 267 474 297 269 minecraft:white_concrete
fill 475 297 229 477 297 229 minecraft:magenta_concrete
fill 475 297 267 475 298 268 minecraft:white_concrete
fill 476 297 230 477 298 230 minecraft:magenta_concrete
fill 477 297 231 479 297 231 minecraft:magenta_concrete
fill 477 297 235 479 297 235 minecraft:magenta_concrete
fill 478 297 232 479 297 234 minecraft:magenta_concrete
setblock 478 297 236 minecraft:magenta_concrete
fill 492 297 237 493 297 240 minecraft:magenta_concrete
fill 493 297 236 499 297 236 minecraft:magenta_concrete
fill 493 297 241 499 297 241 minecraft:magenta_concrete
fill 494 297 231 495 297 231 minecraft:magenta_concrete
fill 494 297 235 498 297 235 minecraft:magenta_concrete
fill 494 297 237 494 299 237 minecraft:magenta_concrete
fill 494 297 240 494 299 240 minecraft:magenta_concrete
fill 494 297 242 498 297 242 minecraft:magenta_concrete
fill 495 297 229 495 297 230 minecraft:magenta_concrete
fill 495 297 232 495 297 233 minecraft:magenta_concrete
fill 496 297 229 499 297 229 minecraft:magenta_concrete
fill 496 297 233 498 297 234 minecraft:magenta_concrete
fill 498 297 237 500 297 237 minecraft:magenta_concrete
fill 498 297 240 500 297 240 minecraft:magenta_concrete
fill 499 297 230 499 298 233 minecraft:magenta_concrete
fill 499 297 238 500 297 239 minecraft:magenta_concrete
fill 500 297 230 500 297 232 minecraft:magenta_concrete
setblock 508 297 229 minecraft:red_concrete
fill 508 297 233 509 300 233 minecraft:red_concrete
fill 508 297 269 509 300 269 minecraft:red_concrete
fill 509 297 229 509 299 231 minecraft:white_concrete
fill 509 297 232 509 301 232 minecraft:red_concrete
fill 509 297 265 509 299 267 minecraft:white_concrete
fill 509 297 268 509 301 268 minecraft:red_concrete
fill 510 297 231 510 297 233 minecraft:white_concrete
fill 510 297 267 510 297 269 minecraft:white_concrete
fill 511 297 231 511 298 232 minecraft:white_concrete
fill 511 297 267 511 298 268 minecraft:white_concrete
fill 471 298 230 471 298 232 minecraft:red_concrete
fill 471 298 266 471 298 268 minecraft:red_concrete
fill 472 298 229 472 302 230 minecraft:white_concrete
fill 472 298 231 472 299 233 minecraft:red_concrete
fill 472 298 234 472 298 235 minecraft:magenta_concrete
fill 472 298 265 472 302 266 minecraft:white_concrete
fill 472 298 267 472 299 268 minecraft:red_concrete
fill 473 298 235 473 298 236 minecraft:magenta_concrete
setblock 473 298 238 minecraft:light[level=12]
setblock 473 298 245 minecraft:light[level=12]
setblock 473 298 252 minecraft:light[level=12]
setblock 473 298 259 minecraft:light[level=12]
setblock 474 298 232 minecraft:white_concrete
fill 474 298 233 474 302 233 minecraft:red_concrete
fill 474 298 236 477 298 236 minecraft:magenta_concrete
fill 474 298 267 474 298 268 minecraft:white_concrete
fill 474 298 269 474 302 269 minecraft:red_concrete
fill 477 298 231 478 298 231 minecraft:magenta_concrete
fill 477 298 235 478 298 235 minecraft:magenta_concrete
fill 478 298 232 478 299 234 minecraft:magenta_concrete
setblock 480 298 231 minecraft:light[level=12]
setblock 480 298 238 minecraft:light[level=12]
setblock 480 298 245 minecraft:light[level=12]
setblock 480 298 252 minecraft:light[level=12]
setblock 480 298 259 minecraft:light[level=12]
setblock 480 298 266 minecraft:light[level=12]
setblock 487 298 231 minecraft:light[level=12]
setblock 487 298 238 minecraft:light[level=12]
setblock 487 298 245 minecraft:light[level=12]
setblock 487 298 252 minecraft:light[level=12]
setblock 487 298 259 minecraft:light[level=12]
setblock 487 298 266 minecraft:light[level=12]
fill 493 298 237 493 298 240 minecraft:magenta_concrete
setblock 494 298 231 minecraft:light[level=12]
fill 494 298 236 498 298 236 minecraft:magenta_concrete
fill 494 298 241 498 298 241 minecraft:magenta_concrete
setblock 494 298 245 minecraft:light[level=12]
setblock 494 298 252 minecraft:light[level=12]
setblock 494 298 259 minecraft:light[level=12]
setblock 494 298 266 minecraft:light[level=12]
fill 495 298 230 495 298 232 minecraft:magenta_concrete
fill 495 298 235 497 298 235 minecraft:magenta_concrete
fill 495 298 242 497 298 242 minecraft:magenta_concrete
fill 496 298 229 498 298 229 minecraft:magenta_concrete
fill 496 298 233 498 299 233 minecraft:magenta_concrete
fill 498 298 237 499 298 237 minecraft:magenta_concrete
fill 498 298 240 499 298 240 minecraft:magenta_concrete
fill 499 298 238 499 299 239 minecraft:magenta_concrete
setblock 501 298 231 minecraft:light[level=12]
setblock 501 298 238 minecraft:light[level=12]
setblock 501 298 245 minecraft:light[level=12]
setblock 501 298 252 minecraft:light[level=12]
setblock 501 298 259 minecraft:light[level=12]
fill 501 298 265 502 299 265 minecraft:lime_concrete
setblock 501 298 266 minecraft:light[level=12]
fill 507 298 230 507 298 232 minecraft:red_concrete
setblock 507 298 266 minecraft:red_concrete
fill 508 298 229 508 302 230 minecraft:white_concrete
fill 508 298 231 508 299 232 minecraft:red_concrete
setblock 508 298 238 minecraft:light[level=12]
setblock 508 298 245 minecraft:light[level=12]
setblock 508 298 252 minecraft:light[level=12]
setblock 508 298 259 minecraft:light[level=12]
fill 508 298 265 508 302 266 minecraft:white_concrete
fill 510 298 231 510 298 232 minecraft:white_concrete
fill 510 298 233 510 302 233 minecraft:red_concrete
fill 510 298 267 510 298 268 minecraft:white_concrete
fill 510 298 269 510 302 269 minecraft:red_concrete
fill 471 299 230 471 303 230 minecraft:white_concrete
fill 471 299 231 471 299 232 minecraft:red_concrete
fill 471 299 266 471 303 266 minecraft:white_concrete
fill 471 299 267 471 299 268 minecraft:red_concrete
setblock 473 299 235 minecraft:magenta_concrete
fill 474 299 232 475 302 232 minecraft:red_concrete
fill 474 299 267 475 299 267 minecraft:white_concrete
fill 474 299 268 475 302 268 minecraft:red_concrete
setblock 475 299 236 minecraft:magenta_concrete
setblock 476 299 230 minecraft:magenta_concrete
fill 476 299 232 476 300 232 minecraft:white_concrete
setblock 477 299 231 minecraft:magenta_concrete
setblock 477 299 235 minecraft:magenta_concrete
setblock 495 299 231 minecraft:magenta_concrete
fill 495 299 236 497 299 236 minecraft:magenta_concrete
fill 495 299 241 497 299 241 minecraft:magenta_concrete
setblock 497 299 229 minecraft:magenta_concrete
setblock 498 299 237 minecraft:magenta_concrete
setblock 498 299 240 minecraft:magenta_concrete
fill 499 299 231 499 299 232 minecraft:magenta_concrete
fill 507 299 230 507 303 230 minecraft:white_concrete
fill 507 299 231 507 299 232 minecraft:red_concrete
fill 507 299 266 507 303 266 minecraft:white_concrete
fill 509 299 250 510 300 250 minecraft:lime_concrete
fill 510 299 231 511 299 231 minecraft:white_concrete
fill 510 299 232 511 302 232 minecraft:red_concrete
fill 510 299 267 511 299 267 minecraft:white_concrete
fill 510 299 268 511 302 268 minecraft:red_concrete
fill 471 300 231 471 303 232 minecraft:white_concrete
fill 471 300 267 471 303 268 minecraft:white_concrete
fill 472 300 231 472 303 231 minecraft:white_concrete
fill 472 300 232 472 300 233 minecraft:red_concrete
fill 472 300 267 472 303 267 minecraft:white_concrete
setblock 472 300 268 minecraft:red_concrete
fill 473 300 229 474 300 230 minecraft:white_concrete
fill 473 300 231 475 303 231 minecraft:red_concrete
fill 473 300 265 473 301 266 minecraft:white_concrete
fill 473 300 267 475 303 267 minecraft:red_concrete
setblock 475 300 230 minecraft:white_concrete
fill 507 300 231 507 303 232 minecraft:white_concrete
fill 507 300 267 507 303 268 minecraft:white_concrete
fill 508 300 231 508 303 231 minecraft:white_concrete
setblock 508 300 232 minecraft:red_concrete
fill 508 300 267 508 303 267 minecraft:white_concrete
setblock 508 300 268 minecraft:red_concrete
fill 509 300 229 509 301 230 minecraft:white_concrete
fill 509 300 231 511 303 231 minecraft:red_concrete
fill 509 300 265 509 301 266 minecraft:white_concrete
fill 509 300 267 511 303 267 minecraft:red_concrete
fill 472 301 232 472 303 233 minecraft:white_concrete
fill 472 301 268 472 303 269 minecraft:white_concrete
fill 473 301 229 473 301 230 minecraft:white_concrete
setblock 473 301 239 minecraft:light[level=15]
setblock 473 301 247 minecraft:light[level=15]
setblock 473 301 255 minecraft:light[level=15]
setblock 473 301 263 minecraft:light[level=15]
setblock 473 301 269 minecraft:red_concrete
setblock 474 301 229 minecraft:white_concrete
fill 474 301 230 475 303 230 minecraft:red_concrete
setblock 474 301 265 minecraft:white_concrete
fill 474 301 266 475 303 266 minecraft:red_concrete
setblock 481 301 231 minecraft:light[level=15]
setblock 481 301 239 minecraft:light[level=15]
setblock 481 301 247 minecraft:light[level=15]
setblock 481 301 255 minecraft:light[level=15]
setblock 481 301 263 minecraft:light[level=15]
setblock 489 301 231 minecraft:light[level=15]
setblock 489 301 239 minecraft:light[level=15]
setblock 489 301 247 minecraft:light[level=15]
setblock 489 301 255 minecraft:light[level=15]
setblock 489 301 263 minecraft:light[level=15]
setblock 497 301 231 minecraft:light[level=15]
setblock 497 301 239 minecraft:light[level=15]
setblock 497 301 247 minecraft:light[level=15]
setblock 497 301 255 minecraft:light[level=15]
setblock 497 301 263 minecraft:light[level=15]
setblock 505 301 231 minecraft:light[level=15]
setblock 505 301 239 minecraft:light[level=15]
setblock 505 301 247 minecraft:light[level=15]
setblock 505 301 255 minecraft:light[level=15]
setblock 505 301 263 minecraft:light[level=15]
fill 508 301 232 508 303 233 minecraft:white_concrete
fill 508 301 268 508 303 269 minecraft:white_concrete
setblock 509 301 233 minecraft:red_concrete
setblock 509 301 269 minecraft:red_concrete
setblock 510 301 229 minecraft:white_concrete
fill 510 301 230 511 303 230 minecraft:red_concrete
setblock 510 301 265 minecraft:white_concrete
fill 510 301 266 511 303 266 minecraft:red_concrete
fill 473 302 229 473 303 230 minecraft:red_concrete
fill 473 302 232 473 303 233 minecraft:white_concrete
fill 473 302 265 473 303 266 minecraft:red_concrete
fill 473 302 268 473 303 269 minecraft:white_concrete
fill 474 302 229 474 303 229 minecraft:red_concrete
fill 474 302 265 474 303 265 minecraft:red_concrete
fill 509 302 229 509 303 230 minecraft:red_concrete
fill 509 302 232 509 303 233 minecraft:white_concrete
fill 509 302 265 509 303 266 minecraft:red_concrete
fill 509 302 268 509 303 269 minecraft:white_concrete
fill 510 302 229 510 303 229 minecraft:red_concrete
fill 510 302 265 510 303 265 minecraft:red_concrete
setblock 472 303 229 minecraft:red_concrete
setblock 472 303 230 minecraft:white_concrete
setblock 472 303 265 minecraft:red_concrete
setblock 472 303 266 minecraft:white_concrete
fill 474 303 232 474 303 233 minecraft:white_concrete
fill 474 303 268 474 303 269 minecraft:white_concrete
setblock 475 303 232 minecraft:red_concrete
setblock 475 303 268 minecraft:red_concrete
setblock 508 303 229 minecraft:red_concrete
setblock 508 303 230 minecraft:white_concrete
setblock 508 303 265 minecraft:red_concrete
setblock 508 303 266 minecraft:white_concrete
fill 510 303 232 510 303 233 minecraft:white_concrete
fill 510 303 268 510 303 269 minecraft:white_concrete
setblock 511 303 232 minecraft:red_concrete
setblock 511 303 268 minecraft:red_concrete
