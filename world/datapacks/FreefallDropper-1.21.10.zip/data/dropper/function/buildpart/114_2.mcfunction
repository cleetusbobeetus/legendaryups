setblock 317 220 470 minecraft:shroomlight
setblock 317 220 472 minecraft:shroomlight
fill 318 220 465 320 225 465 minecraft:polished_blackstone_bricks
fill 321 220 505 321 222 505 minecraft:nether_bricks
fill 322 220 473 322 225 475 minecraft:polished_blackstone_bricks
fill 322 220 485 322 225 487 minecraft:polished_blackstone_bricks
fill 322 220 497 322 225 499 minecraft:polished_blackstone_bricks
fill 323 220 505 323 223 505 minecraft:nether_bricks
setblock 324 220 465 minecraft:red_nether_bricks
fill 324 220 466 324 222 466 minecraft:nether_bricks
setblock 324 220 469 minecraft:nether_bricks
fill 324 220 481 324 222 481 minecraft:nether_bricks
fill 324 220 482 324 220 483 minecraft:red_nether_bricks
fill 324 220 484 324 222 486 minecraft:nether_bricks
fill 324 220 490 324 222 490 minecraft:nether_bricks
fill 324 220 492 324 222 495 minecraft:nether_bricks
fill 324 220 496 324 221 496 minecraft:red_nether_bricks
fill 324 220 500 324 222 500 minecraft:nether_bricks
fill 324 220 502 324 222 502 minecraft:nether_bricks
fill 324 220 504 324 222 504 minecraft:nether_bricks
fill 324 220 505 324 221 505 minecraft:red_nether_bricks
fill 282 221 473 282 222 473 minecraft:nether_bricks
setblock 282 221 474 minecraft:red_nether_bricks
fill 282 221 478 282 222 478 minecraft:nether_bricks
setblock 282 221 479 minecraft:red_nether_bricks
fill 282 221 480 282 222 480 minecraft:nether_bricks
fill 282 221 488 282 222 488 minecraft:nether_bricks
setblock 282 221 494 minecraft:red_nether_bricks
fill 282 221 495 282 222 495 minecraft:nether_bricks
setblock 282 221 497 minecraft:red_nether_bricks
setblock 283 221 505 minecraft:red_nether_bricks
fill 285 221 463 285 222 463 minecraft:nether_bricks
fill 285 221 505 285 222 505 minecraft:nether_bricks
setblock 286 221 463 minecraft:red_nether_bricks
fill 287 221 463 287 222 463 minecraft:nether_bricks
fill 288 221 505 290 222 505 minecraft:nether_bricks
fill 291 221 505 292 221 505 minecraft:red_nether_bricks
fill 292 221 463 292 222 463 minecraft:nether_bricks
fill 293 221 505 293 222 505 minecraft:nether_bricks
fill 298 221 463 298 222 463 minecraft:nether_bricks
setblock 298 221 505 minecraft:red_nether_bricks
fill 305 221 505 305 222 505 minecraft:nether_bricks
setblock 309 221 505 minecraft:red_nether_bricks
setblock 310 221 463 minecraft:red_nether_bricks
fill 310 221 505 310 222 505 minecraft:nether_bricks
fill 311 221 463 312 222 463 minecraft:nether_bricks
fill 311 221 464 311 223 464 minecraft:polished_blackstone_bricks
fill 311 221 466 311 223 466 minecraft:polished_blackstone_bricks
fill 311 221 468 311 223 468 minecraft:polished_blackstone_bricks
fill 311 221 470 311 223 470 minecraft:polished_blackstone_bricks
fill 311 221 472 311 223 472 minecraft:polished_blackstone_bricks
fill 312 221 465 312 223 465 minecraft:polished_blackstone_bricks
fill 312 221 467 312 223 467 minecraft:polished_blackstone_bricks
fill 312 221 469 312 223 469 minecraft:polished_blackstone_bricks
fill 312 221 471 312 223 471 minecraft:polished_blackstone_bricks
fill 312 221 473 312 223 473 minecraft:polished_blackstone_bricks
setblock 312 221 505 minecraft:red_nether_bricks
fill 313 221 464 313 223 464 minecraft:polished_blackstone_bricks
fill 313 221 466 313 223 466 minecraft:polished_blackstone_bricks
fill 313 221 468 313 223 468 minecraft:polished_blackstone_bricks
fill 313 221 470 313 223 470 minecraft:polished_blackstone_bricks
fill 313 221 472 313 223 472 minecraft:polished_blackstone_bricks
fill 313 221 505 313 222 505 minecraft:nether_bricks
fill 314 221 465 314 223 465 minecraft:polished_blackstone_bricks
fill 314 221 467 314 223 467 minecraft:polished_blackstone_bricks
fill 314 221 469 314 223 469 minecraft:polished_blackstone_bricks
fill 314 221 471 314 223 471 minecraft:polished_blackstone_bricks
fill 314 221 473 314 223 473 minecraft:polished_blackstone_bricks
setblock 314 221 505 minecraft:red_nether_bricks
fill 315 221 464 315 223 464 minecraft:polished_blackstone_bricks
fill 315 221 466 315 223 466 minecraft:polished_blackstone_bricks
fill 315 221 468 315 223 468 minecraft:polished_blackstone_bricks
fill 315 221 470 315 223 470 minecraft:polished_blackstone_bricks
fill 315 221 472 315 223 472 minecraft:polished_blackstone_bricks
fill 315 221 505 315 222 505 minecraft:nether_bricks
fill 316 221 465 316 223 465 minecraft:polished_blackstone_bricks
fill 316 221 467 316 223 467 minecraft:polished_blackstone_bricks
fill 316 221 469 316 223 469 minecraft:polished_blackstone_bricks
fill 316 221 471 316 223 471 minecraft:polished_blackstone_bricks
fill 316 221 473 316 223 473 minecraft:polished_blackstone_bricks
fill 317 221 463 318 221 463 minecraft:red_nether_bricks
fill 317 221 464 317 223 464 minecraft:polished_blackstone_bricks
fill 317 221 466 317 223 466 minecraft:polished_blackstone_bricks
fill 317 221 468 317 223 468 minecraft:polished_blackstone_bricks
fill 317 221 470 317 223 470 minecraft:polished_blackstone_bricks
fill 317 221 472 317 223 472 minecraft:polished_blackstone_bricks
fill 323 221 463 323 222 463 minecraft:nether_bricks
setblock 324 221 463 minecraft:red_nether_bricks
fill 324 221 465 324 222 465 minecraft:nether_bricks
setblock 324 221 469 minecraft:red_nether_bricks
fill 324 221 477 324 221 479 minecraft:red_nether_bricks
fill 324 221 482 324 222 483 minecraft:nether_bricks
setblock 324 221 489 minecraft:red_nether_bricks
setblock 324 221 491 minecraft:red_nether_bricks
fill 324 221 498 324 222 498 minecraft:nether_bricks
setblock 324 221 499 minecraft:red_nether_bricks
setblock 282 222 474 minecraft:nether_bricks
fill 282 222 479 282 223 479 minecraft:nether_bricks
setblock 282 222 494 minecraft:nether_bricks
setblock 282 222 497 minecraft:nether_bricks
fill 283 222 505 283 223 505 minecraft:nether_bricks
setblock 286 222 463 minecraft:nether_bricks
fill 291 222 505 292 222 505 minecraft:nether_bricks
setblock 298 222 505 minecraft:nether_bricks
setblock 303 222 505 minecraft:nether_bricks
setblock 309 222 505 minecraft:nether_bricks
setblock 310 222 463 minecraft:nether_bricks
setblock 312 222 505 minecraft:nether_bricks
setblock 314 222 505 minecraft:nether_bricks
fill 317 222 463 318 222 463 minecraft:nether_bricks
setblock 324 222 463 minecraft:nether_bricks
setblock 324 222 469 minecraft:nether_bricks
fill 324 222 477 324 222 479 minecraft:nether_bricks
setblock 324 222 489 minecraft:nether_bricks
fill 324 222 491 324 223 491 minecraft:nether_bricks
setblock 324 222 496 minecraft:nether_bricks
setblock 324 222 499 minecraft:nether_bricks
setblock 324 222 505 minecraft:nether_bricks
fill 282 223 463 282 223 464 minecraft:red_nether_bricks
setblock 282 223 465 minecraft:nether_bricks
fill 282 223 466 282 223 469 minecraft:red_nether_bricks
setblock 282 223 470 minecraft:nether_bricks
fill 282 223 471 282 223 478 minecraft:red_nether_bricks
fill 282 223 480 282 223 505 minecraft:red_nether_bricks
fill 283 223 463 290 223 463 minecraft:red_nether_bricks
fill 284 223 505 287 223 505 minecraft:red_nether_bricks
setblock 285 223 466 minecraft:light[level=14]
setblock 285 223 474 minecraft:light[level=14]
setblock 285 223 482 minecraft:light[level=14]
setblock 285 223 490 minecraft:light[level=14]
setblock 285 223 498 minecraft:light[level=14]
setblock 288 223 505 minecraft:nether_bricks
fill 289 223 505 294 223 505 minecraft:red_nether_bricks
setblock 291 223 463 minecraft:nether_bricks
fill 292 223 463 295 223 463 minecraft:red_nether_bricks
setblock 293 223 466 minecraft:light[level=14]
setblock 293 223 474 minecraft:light[level=14]
setblock 293 223 482 minecraft:light[level=14]
setblock 293 223 490 minecraft:light[level=14]
setblock 293 223 498 minecraft:light[level=14]
setblock 295 223 505 minecraft:nether_bricks
setblock 296 223 463 minecraft:nether_bricks
fill 296 223 505 299 223 505 minecraft:red_nether_bricks
fill 297 223 463 303 224 463 minecraft:red_nether_bricks
setblock 300 223 505 minecraft:nether_bricks
setblock 301 223 466 minecraft:light[level=14]
setblock 301 223 474 minecraft:light[level=14]
setblock 301 223 482 minecraft:light[level=14]
setblock 301 223 490 minecraft:light[level=14]
setblock 301 223 498 minecraft:light[level=14]
fill 301 223 505 306 223 505 minecraft:red_nether_bricks
fill 305 223 463 306 307 463 minecraft:red_nether_bricks
fill 308 223 505 322 224 505 minecraft:red_nether_bricks
fill 309 223 463 317 223 463 minecraft:red_nether_bricks
setblock 309 223 466 minecraft:light[level=14]
setblock 309 223 474 minecraft:light[level=14]
setblock 309 223 482 minecraft:light[level=14]
setblock 309 223 490 minecraft:light[level=14]
setblock 309 223 498 minecraft:light[level=14]
setblock 317 223 474 minecraft:light[level=14]
setblock 317 223 482 minecraft:light[level=14]
setblock 317 223 490 minecraft:light[level=14]
setblock 317 223 498 minecraft:light[level=14]
setblock 318 223 463 minecraft:nether_bricks
fill 319 223 463 324 223 463 minecraft:red_nether_bricks
fill 324 223 464 324 224 490 minecraft:red_nether_bricks
fill 324 223 492 324 223 496 minecraft:red_nether_bricks
fill 324 223 498 324 224 505 minecraft:red_nether_bricks
setblock 282 224 463 minecraft:nether_bricks
fill 282 224 464 282 307 468 minecraft:red_nether_bricks
setblock 282 224 469 minecraft:nether_bricks
fill 282 224 470 282 225 473 minecraft:red_nether_bricks
setblock 282 224 474 minecraft:nether_bricks
fill 282 224 475 282 307 476 minecraft:red_nether_bricks
setblock 282 224 477 minecraft:nether_bricks
fill 282 224 478 282 225 481 minecraft:red_nether_bricks
setblock 282 224 482 minecraft:nether_bricks
fill 282 224 483 282 224 505 minecraft:red_nether_bricks
fill 283 224 463 286 224 463 minecraft:red_nether_bricks
fill 283 224 505 285 224 505 minecraft:red_nether_bricks
setblock 286 224 505 minecraft:nether_bricks
setblock 287 224 463 minecraft:nether_bricks
fill 287 224 505 290 307 505 minecraft:red_nether_bricks
fill 288 224 463 289 225 463 minecraft:red_nether_bricks
setblock 290 224 463 minecraft:nether_bricks
fill 291 224 463 294 225 463 minecraft:red_nether_bricks
setblock 291 224 505 minecraft:nether_bricks
fill 292 224 505 298 225 505 minecraft:red_nether_bricks
setblock 295 224 463 minecraft:nether_bricks
setblock 296 224 463 minecraft:red_nether_bricks
setblock 299 224 505 minecraft:nether_bricks
fill 300 224 505 302 307 505 minecraft:red_nether_bricks
setblock 303 224 505 minecraft:nether_bricks
fill 304 224 463 304 225 463 minecraft:red_nether_bricks
fill 304 224 464 306 224 464 minecraft:polished_blackstone_bricks
fill 304 224 504 306 224 504 minecraft:polished_blackstone_bricks
fill 304 224 505 304 307 505 minecraft:red_nether_bricks
fill 305 224 503 306 225 503 minecraft:polished_blackstone_bricks
setblock 305 224 505 minecraft:nether_bricks
fill 306 224 505 307 225 505 minecraft:red_nether_bricks
fill 307 224 463 308 307 463 minecraft:red_nether_bricks
setblock 309 224 463 minecraft:nether_bricks
fill 310 224 463 315 224 463 minecraft:red_nether_bricks
fill 312 224 465 316 224 472 minecraft:gold_block
setblock 316 224 463 minecraft:nether_bricks
fill 317 224 463 319 224 463 minecraft:red_nether_bricks
setblock 320 224 463 minecraft:nether_bricks
fill 321 224 463 324 307 463 minecraft:red_nether_bricks
setblock 323 224 505 minecraft:red_nether_bricks
fill 324 224 491 324 224 493 minecraft:red_nether_bricks
setblock 324 224 494 minecraft:nether_bricks
fill 324 224 495 324 307 496 minecraft:red_nether_bricks
fill 282 225 463 282 307 463 minecraft:red_nether_bricks
setblock 282 225 469 minecraft:red_nether_bricks
fill 282 225 474 282 307 474 minecraft:red_nether_bricks
fill 282 225 477 282 307 477 minecraft:red_nether_bricks
fill 282 225 482 282 225 485 minecraft:red_nether_bricks
setblock 282 225 486 minecraft:nether_bricks
fill 282 225 487 282 225 505 minecraft:red_nether_bricks
setblock 283 225 463 minecraft:nether_bricks
fill 283 225 467 283 225 472 minecraft:nether_bricks
fill 283 225 479 283 225 484 minecraft:nether_bricks
fill 283 225 491 283 225 496 minecraft:nether_bricks
fill 283 225 503 283 225 504 minecraft:nether_bricks
setblock 283 225 505 minecraft:red_nether_bricks
fill 284 225 463 287 307 463 minecraft:red_nether_bricks
fill 284 225 504 284 225 505 minecraft:nether_bricks
fill 285 225 504 287 225 504 minecraft:nether_bricks
fill 285 225 505 286 225 505 minecraft:red_nether_bricks
fill 287 225 464 292 225 464 minecraft:nether_bricks
setblock 290 225 463 minecraft:red_nether_bricks
fill 291 225 505 291 307 505 minecraft:red_nether_bricks
fill 294 225 504 299 225 504 minecraft:nether_bricks
fill 295 225 463 295 307 463 minecraft:red_nether_bricks
setblock 296 225 463 minecraft:nether_bricks
fill 297 225 463 300 307 463 minecraft:red_nether_bricks
fill 299 225 464 304 225 464 minecraft:nether_bricks
fill 299 225 505 299 307 505 minecraft:red_nether_bricks
fill 301 225 463 302 225 463 minecraft:nether_bricks
setblock 303 225 463 minecraft:red_nether_bricks
fill 303 225 505 303 307 505 minecraft:red_nether_bricks
fill 304 225 465 305 226 465 minecraft:polished_blackstone_bricks
fill 304 225 502 306 226 502 minecraft:polished_blackstone_bricks
fill 304 225 504 305 225 504 minecraft:polished_blackstone_bricks
fill 305 225 464 306 225 464 minecraft:polished_blackstone_bricks
fill 305 225 466 305 227 466 minecraft:polished_blackstone_bricks
fill 305 225 501 305 227 501 minecraft:polished_blackstone_bricks
fill 305 225 505 305 307 505 minecraft:red_nether_bricks
fill 306 225 504 311 225 504 minecraft:nether_bricks
setblock 308 225 505 minecraft:red_nether_bricks
fill 309 225 463 309 307 463 minecraft:red_nether_bricks
setblock 309 225 505 minecraft:nether_bricks
fill 310 225 463 311 225 463 minecraft:nether_bricks
fill 310 225 505 322 225 505 minecraft:red_nether_bricks
fill 311 225 464 316 225 464 minecraft:nether_bricks
fill 312 225 463 317 225 463 minecraft:red_nether_bricks
fill 313 225 466 315 225 471 minecraft:gold_block
setblock 318 225 463 minecraft:nether_bricks
fill 318 225 504 323 225 504 minecraft:nether_bricks
fill 319 225 463 320 307 463 minecraft:red_nether_bricks
fill 321 225 494 321 226 500 minecraft:gilded_blackstone
fill 323 225 464 323 225 469 minecraft:nether_bricks
fill 323 225 476 323 225 481 minecraft:nether_bricks
fill 323 225 488 323 225 493 minecraft:nether_bricks
fill 323 225 500 323 225 503 minecraft:nether_bricks
fill 323 225 505 324 225 505 minecraft:nether_bricks
setblock 324 225 464 minecraft:nether_bricks
fill 324 225 465 324 225 466 minecraft:red_nether_bricks
setblock 324 225 467 minecraft:nether_bricks
fill 324 225 468 324 307 474 minecraft:red_nether_bricks
fill 324 225 475 324 225 476 minecraft:nether_bricks
fill 324 225 477 324 225 478 minecraft:red_nether_bricks
setblock 324 225 479 minecraft:nether_bricks
fill 324 225 480 324 225 491 minecraft:red_nether_bricks
setblock 324 225 492 minecraft:nether_bricks
fill 324 225 493 324 307 494 minecraft:red_nether_bricks
fill 324 225 497 324 307 499 minecraft:red_nether_bricks
setblock 324 225 500 minecraft:nether_bricks
fill 324 225 501 324 225 504 minecraft:red_nether_bricks
fill 282 226 469 282 231 472 minecraft:shroomlight
fill 282 226 473 282 307 473 minecraft:red_nether_bricks
fill 282 226 478 282 307 480 minecraft:red_nether_bricks
fill 282 226 481 282 231 484 minecraft:shroomlight
fill 282 226 485 282 307 492 minecraft:red_nether_bricks
fill 282 226 493 282 231 496 minecraft:shroomlight
fill 282 226 497 282 307 504 minecraft:red_nether_bricks
fill 282 226 505 285 231 505 minecraft:shroomlight
fill 283 226 463 283 307 463 minecraft:red_nether_bricks
fill 286 226 505 286 307 505 minecraft:red_nether_bricks
fill 288 226 463 288 307 463 minecraft:red_nether_bricks
fill 289 226 463 292 231 463 minecraft:shroomlight
fill 292 226 505 293 307 505 minecraft:red_nether_bricks
fill 293 226 463 294 307 463 minecraft:red_nether_bricks
fill 294 226 505 297 231 505 minecraft:shroomlight
fill 296 226 463 296 307 463 minecraft:red_nether_bricks
fill 298 226 505 298 307 505 minecraft:red_nether_bricks
fill 301 226 463 304 231 463 minecraft:shroomlight
fill 304 226 466 304 227 466 minecraft:polished_blackstone_bricks
fill 304 226 501 304 227 501 minecraft:polished_blackstone_bricks
setblock 305 226 464 minecraft:polished_blackstone_bricks
fill 305 226 467 305 228 467 minecraft:polished_blackstone_bricks
fill 305 226 500 305 228 500 minecraft:polished_blackstone_bricks
setblock 305 226 503 minecraft:polished_blackstone_bricks
setblock 305 226 504 minecraft:gold_block
fill 306 226 465 306 226 466 minecraft:polished_blackstone_bricks
fill 306 226 501 306 227 501 minecraft:polished_blackstone_bricks
fill 306 226 505 309 231 505 minecraft:shroomlight
fill 310 226 463 312 307 463 minecraft:red_nether_bricks
fill 310 226 505 317 307 505 minecraft:red_nether_bricks
fill 313 226 463 316 231 463 minecraft:shroomlight
fill 314 226 467 314 226 470 minecraft:gold_block
fill 317 226 463 318 307 463 minecraft:red_nether_bricks
fill 318 226 505 321 231 505 minecraft:shroomlight
fill 322 226 505 324 307 505 minecraft:red_nether_bricks
fill 324 226 464 324 231 467 minecraft:shroomlight
fill 324 226 475 324 307 475 minecraft:red_nether_bricks
fill 324 226 476 324 231 479 minecraft:shroomlight
fill 324 226 480 324 307 487 minecraft:red_nether_bricks
fill 324 226 488 324 231 491 minecraft:shroomlight
fill 324 226 492 324 307 492 minecraft:red_nether_bricks
fill 324 226 500 324 231 503 minecraft:shroomlight
fill 324 226 504 324 307 504 minecraft:red_nether_bricks
fill 304 227 467 304 228 468 minecraft:polished_blackstone_bricks
fill 304 227 499 304 228 500 minecraft:polished_blackstone_bricks
setblock 305 227 464 minecraft:gold_block
setblock 305 227 465 minecraft:polished_blackstone_bricks
fill 305 227 468 306 228 468 minecraft:polished_blackstone_bricks
fill 305 227 499 306 228 499 minecraft:polished_blackstone_bricks
setblock 305 227 502 minecraft:polished_blackstone_bricks
setblock 305 227 503 minecraft:gold_block
fill 306 227 466 306 227 467 minecraft:polished_blackstone_bricks
fill 306 227 500 306 228 500 minecraft:polished_blackstone_bricks
fill 313 227 468 315 227 469 minecraft:gold_block
fill 304 228 469 306 229 469 minecraft:polished_blackstone_bricks
fill 304 228 498 306 229 498 minecraft:polished_blackstone_bricks
setblock 305 228 466 minecraft:gold_block
fill 305 228 470 305 230 470 minecraft:polished_blackstone_bricks
fill 305 228 497 305 230 497 minecraft:polished_blackstone_bricks
setblock 305 228 501 minecraft:gold_block
setblock 306 228 467 minecraft:polished_blackstone_bricks
fill 304 229 470 304 230 470 minecraft:polished_blackstone_bricks
fill 304 229 497 304 230 497 minecraft:polished_blackstone_bricks
setblock 305 229 467 minecraft:gold_block
setblock 305 229 468 minecraft:polished_blackstone_bricks
fill 305 229 471 305 231 471 minecraft:polished_blackstone_bricks
fill 305 229 496 305 231 496 minecraft:polished_blackstone_bricks
setblock 305 229 499 minecraft:polished_blackstone_bricks
setblock 305 229 500 minecraft:gold_block
fill 306 229 470 306 230 470 minecraft:polished_blackstone_bricks
fill 306 229 497 306 230 497 minecraft:polished_blackstone_bricks
fill 304 230 471 304 230 472 minecraft:polished_blackstone_bricks
fill 304 230 495 304 230 496 minecraft:polished_blackstone_bricks
setblock 305 230 468 minecraft:gold_block
setblock 305 230 469 minecraft:polished_blackstone_bricks
fill 305 230 472 305 232 473 minecraft:polished_blackstone_bricks
fill 305 230 494 305 232 495 minecraft:polished_blackstone_bricks
setblock 305 230 498 minecraft:polished_blackstone_bricks
setblock 305 230 499 minecraft:gold_block
fill 306 230 471 306 230 472 minecraft:polished_blackstone_bricks
fill 306 230 495 306 230 496 minecraft:polished_blackstone_bricks
setblock 285 231 466 minecraft:light[level=14]
setblock 285 231 474 minecraft:light[level=14]
setblock 285 231 482 minecraft:light[level=14]
setblock 285 231 490 minecraft:light[level=14]
setblock 285 231 498 minecraft:light[level=14]
setblock 293 231 466 minecraft:light[level=14]
setblock 293 231 474 minecraft:light[level=14]
setblock 293 231 482 minecraft:light[level=14]
setblock 293 231 490 minecraft:light[level=14]
setblock 293 231 498 minecraft:light[level=14]
setblock 301 231 466 minecraft:light[level=14]
setblock 301 231 474 minecraft:light[level=14]
setblock 301 231 482 minecraft:light[level=14]
setblock 301 231 490 minecraft:light[level=14]
setblock 301 231 498 minecraft:light[level=14]
fill 304 231 472 304 231 474 minecraft:polished_blackstone_bricks
fill 304 231 493 304 231 495 minecraft:polished_blackstone_bricks
fill 305 231 469 305 231 470 minecraft:gold_block
fill 305 231 474 305 233 475 minecraft:polished_blackstone_bricks
fill 305 231 492 305 233 493 minecraft:polished_blackstone_bricks
fill 305 231 497 305 231 498 minecraft:gold_block
fill 306 231 472 306 231 474 minecraft:polished_blackstone_bricks
fill 306 231 493 306 231 495 minecraft:polished_blackstone_bricks
setblock 309 231 466 minecraft:light[level=14]
setblock 309 231 474 minecraft:light[level=14]
setblock 309 231 482 minecraft:light[level=14]
setblock 309 231 490 minecraft:light[level=14]
setblock 309 231 498 minecraft:light[level=14]
setblock 317 231 466 minecraft:light[level=14]
setblock 317 231 474 minecraft:light[level=14]
setblock 317 231 482 minecraft:light[level=14]
setblock 317 231 490 minecraft:light[level=14]
setblock 317 231 498 minecraft:light[level=14]
fill 282 232 469 282 245 469 minecraft:red_nether_bricks
fill 282 232 470 282 232 471 minecraft:shroomlight
fill 282 232 472 282 245 472 minecraft:red_nether_bricks
fill 282 232 481 282 245 481 minecraft:red_nether_bricks
fill 282 232 482 282 232 483 minecraft:shroomlight
fill 282 232 484 282 245 484 minecraft:red_nether_bricks
fill 282 232 493 282 245 493 minecraft:red_nether_bricks
fill 282 232 494 282 232 495 minecraft:shroomlight
fill 282 232 496 282 245 496 minecraft:red_nether_bricks
fill 282 232 505 282 245 505 minecraft:red_nether_bricks
fill 283 232 505 284 232 505 minecraft:shroomlight
fill 285 232 505 285 245 505 minecraft:red_nether_bricks
fill 289 232 463 289 245 463 minecraft:red_nether_bricks
fill 290 232 463 291 232 463 minecraft:shroomlight
fill 292 232 463 292 245 463 minecraft:red_nether_bricks
fill 294 232 505 294 245 505 minecraft:red_nether_bricks
fill 295 232 505 296 232 505 minecraft:shroomlight
fill 297 232 505 297 245 505 minecraft:red_nether_bricks
fill 301 232 463 301 245 463 minecraft:red_nether_bricks
fill 302 232 463 303 232 463 minecraft:shroomlight
fill 304 232 463 304 245 463 minecraft:red_nether_bricks
fill 304 232 473 304 232 476 minecraft:polished_blackstone_bricks
fill 304 232 491 304 232 494 minecraft:polished_blackstone_bricks
setblock 305 232 471 minecraft:gold_block
fill 305 232 476 305 234 477 minecraft:polished_blackstone_bricks
fill 305 232 490 305 234 491 minecraft:polished_blackstone_bricks
setblock 305 232 496 minecraft:gold_block
fill 306 232 473 306 232 476 minecraft:polished_blackstone_bricks
fill 306 232 491 306 232 494 minecraft:polished_blackstone_bricks
fill 306 232 505 306 245 505 minecraft:red_nether_bricks
fill 307 232 505 308 232 505 minecraft:shroomlight
fill 309 232 505 309 245 505 minecraft:red_nether_bricks
fill 313 232 463 313 245 463 minecraft:red_nether_bricks
fill 314 232 463 315 232 463 minecraft:shroomlight
fill 316 232 463 316 245 463 minecraft:red_nether_bricks
fill 318 232 505 318 245 505 minecraft:red_nether_bricks
fill 319 232 505 320 232 505 minecraft:shroomlight
fill 321 232 505 321 245 505 minecraft:red_nether_bricks
fill 324 232 464 324 245 464 minecraft:red_nether_bricks
fill 324 232 465 324 232 466 minecraft:shroomlight
fill 324 232 467 324 245 467 minecraft:red_nether_bricks
fill 324 232 476 324 245 476 minecraft:red_nether_bricks
fill 324 232 477 324 232 478 minecraft:shroomlight
fill 324 232 479 324 245 479 minecraft:red_nether_bricks
fill 324 232 488 324 245 488 minecraft:red_nether_bricks
fill 324 232 489 324 232 490 minecraft:shroomlight
fill 324 232 491 324 245 491 minecraft:red_nether_bricks
fill 324 232 500 324 245 500 minecraft:red_nether_bricks
fill 324 232 501 324 232 502 minecraft:shroomlight
fill 324 232 503 324 245 503 minecraft:red_nether_bricks
fill 282 233 470 282 245 471 minecraft:red_nether_bricks
fill 282 233 482 282 245 483 minecraft:red_nether_bricks
fill 282 233 494 282 245 495 minecraft:red_nether_bricks
fill 283 233 505 284 245 505 minecraft:red_nether_bricks
fill 290 233 463 291 245 463 minecraft:red_nether_bricks
fill 295 233 505 296 245 505 minecraft:red_nether_bricks
fill 302 233 463 303 245 463 minecraft:red_nether_bricks
fill 304 233 475 304 233 479 minecraft:polished_blackstone_bricks
fill 304 233 488 304 233 492 minecraft:polished_blackstone_bricks
setblock 305 233 473 minecraft:gold_block
fill 305 233 478 305 234 483 minecraft:polished_blackstone_bricks
fill 305 233 486 305 234 489 minecraft:polished_blackstone_bricks
setblock 305 233 494 minecraft:gold_block
fill 306 233 475 306 233 479 minecraft:polished_blackstone_bricks
fill 306 233 488 306 233 492 minecraft:polished_blackstone_bricks
fill 307 233 505 308 245 505 minecraft:red_nether_bricks
fill 314 233 463 315 245 463 minecraft:red_nether_bricks
fill 319 233 505 320 245 505 minecraft:red_nether_bricks
fill 324 233 465 324 245 466 minecraft:red_nether_bricks
fill 324 233 477 324 245 478 minecraft:red_nether_bricks
fill 324 233 489 324 245 490 minecraft:red_nether_bricks
fill 324 233 501 324 245 502 minecraft:red_nether_bricks
fill 304 234 478 304 234 482 minecraft:polished_blackstone_bricks
fill 304 234 488 304 234 489 minecraft:polished_blackstone_bricks
fill 305 234 474 305 234 475 minecraft:gold_block
fill 305 234 492 305 234 493 minecraft:gold_block
fill 306 234 478 306 234 489 minecraft:polished_blackstone_bricks
fill 304 235 481 306 235 482 minecraft:polished_blackstone_bricks
fill 305 235 477 305 235 478 minecraft:gold_block
fill 305 235 479 305 235 480 minecraft:polished_blackstone_bricks
fill 305 235 483 306 235 483 minecraft:polished_blackstone_bricks
fill 305 235 486 305 235 488 minecraft:polished_blackstone_bricks
fill 305 235 489 305 235 490 minecraft:gold_block
fill 306 235 484 306 235 486 minecraft:polished_blackstone_bricks
setblock 285 239 466 minecraft:light[level=14]
setblock 285 239 474 minecraft:light[level=14]
setblock 285 239 482 minecraft:light[level=14]
setblock 285 239 490 minecraft:light[level=14]
setblock 285 239 498 minecraft:light[level=14]
setblock 293 239 466 minecraft:light[level=14]
setblock 293 239 474 minecraft:light[level=14]
setblock 293 239 482 minecraft:light[level=14]
setblock 293 239 490 minecraft:light[level=14]
setblock 293 239 498 minecraft:light[level=14]
setblock 301 239 466 minecraft:light[level=14]
setblock 301 239 474 minecraft:light[level=14]
setblock 301 239 482 minecraft:light[level=14]
setblock 301 239 490 minecraft:light[level=14]
setblock 301 239 498 minecraft:light[level=14]
setblock 309 239 466 minecraft:light[level=14]
setblock 309 239 474 minecraft:light[level=14]
setblock 309 239 482 minecraft:light[level=14]
setblock 309 239 490 minecraft:light[level=14]
setblock 309 239 498 minecraft:light[level=14]
setblock 317 239 466 minecraft:light[level=14]
setblock 317 239 474 minecraft:light[level=14]
setblock 317 239 482 minecraft:light[level=14]
setblock 317 239 490 minecraft:light[level=14]
setblock 317 239 498 minecraft:light[level=14]
fill 283 241 464 284 242 474 minecraft:black_concrete
fill 283 241 475 323 242 475 minecraft:gold_block
fill 283 241 476 284 242 486 minecraft:black_concrete
fill 283 241 487 323 241 487 minecraft:gold_block
fill 283 241 488 284 242 498 minecraft:black_concrete
fill 283 241 499 323 242 499 minecraft:gold_block
fill 283 241 500 284 242 504 minecraft:black_concrete
fill 285 241 464 285 242 474 minecraft:polished_blackstone
fill 285 241 476 285 242 486 minecraft:polished_blackstone
fill 285 241 488 285 242 498 minecraft:polished_blackstone
fill 285 241 500 285 242 504 minecraft:polished_blackstone
fill 286 241 464 287 242 474 minecraft:black_concrete
fill 286 241 476 287 242 486 minecraft:black_concrete
fill 286 241 488 287 242 498 minecraft:black_concrete
fill 286 241 500 287 242 504 minecraft:black_concrete
fill 288 241 464 288 242 474 minecraft:polished_blackstone
fill 288 241 476 288 242 486 minecraft:polished_blackstone
fill 288 241 488 288 242 498 minecraft:polished_blackstone
fill 288 241 500 288 242 504 minecraft:polished_blackstone
fill 289 241 464 290 242 474 minecraft:black_concrete
fill 289 241 476 290 242 486 minecraft:black_concrete
fill 289 241 488 290 242 498 minecraft:black_concrete
fill 289 241 500 290 242 504 minecraft:black_concrete
fill 291 241 464 291 242 474 minecraft:polished_blackstone
fill 291 241 476 291 242 486 minecraft:polished_blackstone
fill 291 241 488 291 242 498 minecraft:polished_blackstone
fill 291 241 500 291 242 504 minecraft:polished_blackstone
fill 292 241 464 293 242 474 minecraft:black_concrete
fill 292 241 476 293 242 486 minecraft:black_concrete
fill 292 241 488 293 242 498 minecraft:black_concrete
fill 292 241 500 293 242 504 minecraft:black_concrete
fill 294 241 464 294 242 474 minecraft:polished_blackstone
fill 294 241 476 294 242 486 minecraft:polished_blackstone
fill 294 241 488 294 242 498 minecraft:polished_blackstone
fill 294 241 500 294 242 504 minecraft:polished_blackstone
fill 295 241 464 296 242 474 minecraft:black_concrete
fill 295 241 476 296 242 486 minecraft:black_concrete
fill 295 241 488 296 242 498 minecraft:black_concrete
fill 295 241 500 296 242 504 minecraft:black_concrete
fill 297 241 464 297 242 474 minecraft:polished_blackstone
fill 297 241 476 297 242 486 minecraft:polished_blackstone
fill 297 241 488 297 242 498 minecraft:polished_blackstone
fill 297 241 500 297 242 504 minecraft:polished_blackstone
fill 298 241 464 299 242 474 minecraft:black_concrete
fill 298 241 476 299 242 486 minecraft:black_concrete
fill 298 241 488 299 242 498 minecraft:black_concrete
fill 298 241 500 299 242 504 minecraft:black_concrete
fill 300 241 464 300 242 474 minecraft:polished_blackstone
fill 300 241 476 300 241 486 minecraft:polished_blackstone
fill 300 241 488 300 242 498 minecraft:polished_blackstone
fill 300 241 500 300 242 504 minecraft:polished_blackstone
fill 301 241 464 302 242 474 minecraft:black_concrete
fill 301 241 476 301 241 483 minecraft:black_concrete
fill 301 241 485 301 241 486 minecraft:black_concrete
fill 301 241 488 302 242 498 minecraft:black_concrete
fill 301 241 500 302 242 504 minecraft:black_concrete
fill 302 241 476 302 241 482 minecraft:black_concrete
setblock 302 241 486 minecraft:black_concrete
fill 303 241 464 303 242 474 minecraft:polished_blackstone
fill 303 241 476 303 241 481 minecraft:polished_blackstone
fill 303 241 488 303 242 498 minecraft:polished_blackstone
fill 303 241 500 303 242 504 minecraft:polished_blackstone
fill 304 241 464 305 242 474 minecraft:black_concrete
fill 304 241 476 305 241 482 minecraft:black_concrete
fill 304 241 486 305 241 486 minecraft:black_concrete
fill 304 241 488 305 242 498 minecraft:black_concrete
fill 304 241 500 305 242 504 minecraft:black_concrete
setblock 305 241 483 minecraft:black_concrete
setblock 305 241 485 minecraft:black_concrete
fill 306 241 464 306 242 474 minecraft:polished_blackstone
fill 306 241 476 306 241 486 minecraft:polished_blackstone
fill 306 241 488 306 242 498 minecraft:polished_blackstone
fill 306 241 500 306 242 504 minecraft:polished_blackstone
fill 307 241 464 308 242 474 minecraft:black_concrete
fill 307 241 476 308 242 486 minecraft:black_concrete
fill 307 241 488 308 242 498 minecraft:black_concrete
fill 307 241 500 308 242 504 minecraft:black_concrete
fill 309 241 464 309 242 474 minecraft:polished_blackstone
fill 309 241 476 309 242 486 minecraft:polished_blackstone
fill 309 241 488 309 242 498 minecraft:polished_blackstone
fill 309 241 500 309 242 504 minecraft:polished_blackstone
fill 310 241 464 311 242 474 minecraft:black_concrete
fill 310 241 476 311 242 486 minecraft:black_concrete
fill 310 241 488 311 242 498 minecraft:black_concrete
fill 310 241 500 311 242 504 minecraft:black_concrete
fill 312 241 464 312 242 474 minecraft:polished_blackstone
fill 312 241 476 312 242 486 minecraft:polished_blackstone
fill 312 241 488 312 242 498 minecraft:polished_blackstone
fill 312 241 500 312 242 504 minecraft:polished_blackstone
fill 313 241 464 314 242 474 minecraft:black_concrete
fill 313 241 476 314 242 486 minecraft:black_concrete
fill 313 241 488 314 242 498 minecraft:black_concrete
fill 313 241 500 314 242 504 minecraft:black_concrete
fill 315 241 464 315 242 474 minecraft:polished_blackstone
fill 315 241 476 315 242 486 minecraft:polished_blackstone
fill 315 241 488 315 242 498 minecraft:polished_blackstone
fill 315 241 500 315 242 504 minecraft:polished_blackstone
fill 316 241 464 317 242 474 minecraft:black_concrete
fill 316 241 476 317 242 486 minecraft:black_concrete
fill 316 241 488 317 242 498 minecraft:black_concrete
fill 316 241 500 317 242 504 minecraft:black_concrete
fill 318 241 464 318 242 474 minecraft:polished_blackstone
fill 318 241 476 318 242 486 minecraft:polished_blackstone
fill 318 241 488 318 242 498 minecraft:polished_blackstone
fill 318 241 500 318 242 504 minecraft:polished_blackstone
fill 319 241 464 320 242 474 minecraft:black_concrete
fill 319 241 476 320 242 486 minecraft:black_concrete
fill 319 241 488 320 242 498 minecraft:black_concrete
fill 319 241 500 320 242 504 minecraft:black_concrete
fill 321 241 464 321 242 474 minecraft:polished_blackstone
fill 321 241 476 321 242 486 minecraft:polished_blackstone
fill 321 241 488 321 242 498 minecraft:polished_blackstone
fill 321 241 500 321 242 504 minecraft:polished_blackstone
fill 322 241 464 323 242 474 minecraft:black_concrete
fill 322 241 476 323 242 486 minecraft:black_concrete
fill 322 241 488 323 242 498 minecraft:black_concrete
fill 322 241 500 323 242 504 minecraft:black_concrete
fill 283 242 487 301 242 487 minecraft:gold_block
fill 300 242 476 300 242 482 minecraft:polished_blackstone
fill 300 242 483 300 242 485 minecraft:shroomlight
setblock 300 242 486 minecraft:polished_blackstone
fill 301 242 476 301 242 481 minecraft:black_concrete
fill 301 242 482 301 242 483 minecraft:shroomlight
fill 301 242 485 301 242 486 minecraft:shroomlight
fill 302 242 476 302 242 480 minecraft:black_concrete
fill 302 242 481 302 242 482 minecraft:shroomlight
fill 302 242 486 302 242 487 minecraft:shroomlight
fill 303 242 476 303 242 480 minecraft:polished_blackstone
fill 303 242 481 304 242 481 minecraft:shroomlight
fill 303 242 487 304 242 487 minecraft:shroomlight
fill 304 242 476 305 242 480 minecraft:black_concrete
fill 304 242 482 305 242 482 minecraft:shroomlight
fill 304 242 486 305 242 486 minecraft:shroomlight
setblock 305 242 481 minecraft:black_concrete
fill 305 242 483 306 242 483 minecraft:shroomlight
fill 305 242 485 306 242 485 minecraft:shroomlight
fill 305 242 487 323 242 487 minecraft:gold_block
fill 306 242 476 306 242 482 minecraft:polished_blackstone
setblock 306 242 484 minecraft:shroomlight
setblock 306 242 486 minecraft:polished_blackstone
fill 282 246 469 282 251 472 minecraft:shroomlight
fill 282 246 481 282 251 484 minecraft:shroomlight
fill 282 246 493 282 251 496 minecraft:shroomlight
fill 282 246 505 285 251 505 minecraft:shroomlight
fill 283 246 464 285 273 464 minecraft:polished_blackstone_bricks
fill 283 246 474 283 273 476 minecraft:polished_blackstone_bricks
fill 283 246 486 283 273 488 minecraft:polished_blackstone_bricks
fill 283 246 498 283 273 500 minecraft:polished_blackstone_bricks
fill 289 246 463 292 251 463 minecraft:shroomlight
fill 289 246 504 291 273 504 minecraft:polished_blackstone_bricks
fill 294 246 505 297 251 505 minecraft:shroomlight
fill 295 246 464 297 273 464 minecraft:polished_blackstone_bricks
fill 301 246 463 304 251 463 minecraft:shroomlight
fill 301 246 504 303 273 504 minecraft:polished_blackstone_bricks
fill 306 246 505 309 251 505 minecraft:shroomlight
fill 307 246 464 309 273 464 minecraft:polished_blackstone_bricks
fill 309 246 494 321 246 504 minecraft:polished_blackstone_bricks
fill 313 246 463 316 251 463 minecraft:shroomlight
fill 318 246 505 321 251 505 minecraft:shroomlight
fill 319 246 464 321 273 464 minecraft:polished_blackstone_bricks
fill 323 246 472 323 273 474 minecraft:polished_blackstone_bricks
fill 323 246 484 323 273 486 minecraft:polished_blackstone_bricks
fill 323 246 496 323 273 498 minecraft:polished_blackstone_bricks
fill 324 246 464 324 251 467 minecraft:shroomlight
fill 324 246 476 324 251 479 minecraft:shroomlight
fill 324 246 488 324 251 491 minecraft:shroomlight
fill 324 246 500 324 251 503 minecraft:shroomlight
setblock 285 247 466 minecraft:light[level=14]
setblock 285 247 474 minecraft:light[level=14]
setblock 285 247 482 minecraft:light[level=14]
setblock 285 247 490 minecraft:light[level=14]
setblock 285 247 498 minecraft:light[level=14]
setblock 293 247 466 minecraft:light[level=14]
setblock 293 247 474 minecraft:light[level=14]
setblock 293 247 482 minecraft:light[level=14]
setblock 293 247 490 minecraft:light[level=14]
setblock 293 247 498 minecraft:light[level=14]
setblock 301 247 466 minecraft:light[level=14]
setblock 301 247 474 minecraft:light[level=14]
setblock 301 247 482 minecraft:light[level=14]
setblock 301 247 490 minecraft:light[level=14]
setblock 301 247 498 minecraft:light[level=14]
setblock 309 247 466 minecraft:light[level=14]
setblock 309 247 474 minecraft:light[level=14]
setblock 309 247 482 minecraft:light[level=14]
setblock 309 247 490 minecraft:light[level=14]
setblock 309 247 494 minecraft:shroomlight
fill 309 247 495 309 263 495 minecraft:polished_blackstone_bricks
setblock 309 247 496 minecraft:shroomlight
fill 309 247 497 309 263 497 minecraft:polished_blackstone_bricks
setblock 309 247 498 minecraft:shroomlight
fill 309 247 499 309 263 499 minecraft:polished_blackstone_bricks
setblock 309 247 500 minecraft:shroomlight
fill 309 247 501 309 263 501 minecraft:polished_blackstone_bricks
setblock 309 247 502 minecraft:shroomlight
fill 309 247 503 309 263 503 minecraft:polished_blackstone_bricks
setblock 309 247 504 minecraft:shroomlight
fill 310 247 494 310 263 494 minecraft:polished_blackstone_bricks
setblock 310 247 495 minecraft:shroomlight
fill 310 247 496 310 263 496 minecraft:polished_blackstone_bricks
setblock 310 247 497 minecraft:shroomlight
fill 310 247 498 310 263 498 minecraft:polished_blackstone_bricks
setblock 310 247 499 minecraft:shroomlight
fill 310 247 500 310 263 500 minecraft:polished_blackstone_bricks
setblock 310 247 501 minecraft:shroomlight
fill 310 247 502 310 263 502 minecraft:polished_blackstone_bricks
setblock 310 247 503 minecraft:shroomlight
fill 310 247 504 310 263 504 minecraft:polished_blackstone_bricks
setblock 311 247 494 minecraft:shroomlight
fill 311 247 495 311 263 495 minecraft:polished_blackstone_bricks
setblock 311 247 496 minecraft:shroomlight
fill 311 247 497 311 263 497 minecraft:polished_blackstone_bricks
setblock 311 247 498 minecraft:shroomlight
fill 311 247 499 311 263 499 minecraft:polished_blackstone_bricks
setblock 311 247 500 minecraft:shroomlight
fill 311 247 501 311 263 501 minecraft:polished_blackstone_bricks
setblock 311 247 502 minecraft:shroomlight
fill 311 247 503 311 263 503 minecraft:polished_blackstone_bricks
setblock 311 247 504 minecraft:shroomlight
fill 312 247 494 312 263 494 minecraft:polished_blackstone_bricks
setblock 312 247 495 minecraft:shroomlight
fill 312 247 496 312 263 496 minecraft:polished_blackstone_bricks
setblock 312 247 497 minecraft:shroomlight
fill 312 247 498 312 263 498 minecraft:polished_blackstone_bricks
setblock 312 247 499 minecraft:shroomlight
fill 312 247 500 312 263 500 minecraft:polished_blackstone_bricks
setblock 312 247 501 minecraft:shroomlight
fill 312 247 502 312 263 502 minecraft:polished_blackstone_bricks
setblock 312 247 503 minecraft:shroomlight
fill 312 247 504 312 263 504 minecraft:polished_blackstone_bricks
setblock 313 247 494 minecraft:shroomlight
fill 313 247 495 313 263 495 minecraft:polished_blackstone_bricks
setblock 313 247 496 minecraft:shroomlight
fill 313 247 497 313 263 497 minecraft:polished_blackstone_bricks
setblock 313 247 498 minecraft:shroomlight
fill 313 247 499 313 263 499 minecraft:polished_blackstone_bricks
setblock 313 247 500 minecraft:shroomlight
fill 313 247 501 313 263 501 minecraft:polished_blackstone_bricks
setblock 313 247 502 minecraft:shroomlight
fill 313 247 503 313 263 503 minecraft:polished_blackstone_bricks
setblock 313 247 504 minecraft:shroomlight
fill 314 247 494 314 263 494 minecraft:polished_blackstone_bricks
setblock 314 247 495 minecraft:shroomlight
fill 314 247 496 314 263 496 minecraft:polished_blackstone_bricks
setblock 314 247 497 minecraft:shroomlight
fill 314 247 498 314 263 498 minecraft:polished_blackstone_bricks
setblock 314 247 499 minecraft:shroomlight
fill 314 247 500 314 263 500 minecraft:polished_blackstone_bricks
setblock 314 247 501 minecraft:shroomlight
fill 314 247 502 314 263 502 minecraft:polished_blackstone_bricks
setblock 314 247 503 minecraft:shroomlight
fill 314 247 504 314 273 504 minecraft:polished_blackstone_bricks
setblock 315 247 494 minecraft:shroomlight
fill 315 247 495 315 263 495 minecraft:polished_blackstone_bricks
setblock 315 247 496 minecraft:shroomlight
fill 315 247 497 315 263 497 minecraft:polished_blackstone_bricks
setblock 315 247 498 minecraft:shroomlight
fill 315 247 499 315 263 499 minecraft:polished_blackstone_bricks
setblock 315 247 500 minecraft:shroomlight
fill 315 247 501 315 263 501 minecraft:polished_blackstone_bricks
setblock 315 247 502 minecraft:shroomlight
fill 315 247 503 315 265 503 minecraft:polished_blackstone_bricks
setblock 315 247 504 minecraft:shroomlight
fill 316 247 494 316 263 494 minecraft:polished_blackstone_bricks
setblock 316 247 495 minecraft:shroomlight
fill 316 247 496 316 263 496 minecraft:polished_blackstone_bricks
setblock 316 247 497 minecraft:shroomlight
fill 316 247 498 316 263 498 minecraft:polished_blackstone_bricks
setblock 316 247 499 minecraft:shroomlight
fill 316 247 500 316 263 500 minecraft:polished_blackstone_bricks
setblock 316 247 501 minecraft:shroomlight
fill 316 247 502 316 263 502 minecraft:polished_blackstone_bricks
setblock 316 247 503 minecraft:shroomlight
fill 316 247 504 316 263 504 minecraft:polished_blackstone_bricks
setblock 317 247 466 minecraft:light[level=14]
setblock 317 247 474 minecraft:light[level=14]
setblock 317 247 482 minecraft:light[level=14]
setblock 317 247 490 minecraft:light[level=14]
setblock 317 247 494 minecraft:shroomlight
fill 317 247 495 317 263 495 minecraft:polished_blackstone_bricks
setblock 317 247 496 minecraft:shroomlight
fill 317 247 497 317 263 497 minecraft:polished_blackstone_bricks
setblock 317 247 498 minecraft:shroomlight
fill 317 247 499 317 263 499 minecraft:polished_blackstone_bricks
setblock 317 247 500 minecraft:shroomlight
fill 317 247 501 317 263 501 minecraft:polished_blackstone_bricks
setblock 317 247 502 minecraft:shroomlight
fill 317 247 503 317 263 503 minecraft:polished_blackstone_bricks
setblock 317 247 504 minecraft:shroomlight
fill 318 247 494 318 263 494 minecraft:polished_blackstone_bricks
setblock 318 247 495 minecraft:shroomlight
fill 318 247 496 318 263 496 minecraft:polished_blackstone_bricks
setblock 318 247 497 minecraft:shroomlight
fill 318 247 498 318 263 498 minecraft:polished_blackstone_bricks
setblock 318 247 499 minecraft:shroomlight
fill 318 247 500 318 263 500 minecraft:polished_blackstone_bricks
setblock 318 247 501 minecraft:shroomlight
fill 318 247 502 318 263 502 minecraft:polished_blackstone_bricks
setblock 318 247 503 minecraft:shroomlight
fill 318 247 504 318 263 504 minecraft:polished_blackstone_bricks
setblock 319 247 494 minecraft:shroomlight
fill 319 247 495 319 263 495 minecraft:polished_blackstone_bricks
setblock 319 247 496 minecraft:shroomlight
fill 319 247 497 319 263 497 minecraft:polished_blackstone_bricks
setblock 319 247 498 minecraft:shroomlight
fill 319 247 499 319 263 499 minecraft:polished_blackstone_bricks
setblock 319 247 500 minecraft:shroomlight
fill 319 247 501 319 263 501 minecraft:polished_blackstone_bricks
setblock 319 247 502 minecraft:shroomlight
fill 319 247 503 319 263 503 minecraft:polished_blackstone_bricks
setblock 319 247 504 minecraft:shroomlight
fill 320 247 494 320 263 494 minecraft:polished_blackstone_bricks
setblock 320 247 495 minecraft:shroomlight
fill 320 247 496 320 263 496 minecraft:polished_blackstone_bricks
setblock 320 247 497 minecraft:shroomlight
fill 320 247 498 320 263 498 minecraft:polished_blackstone_bricks
setblock 320 247 499 minecraft:shroomlight
fill 320 247 500 320 263 500 minecraft:polished_blackstone_bricks
setblock 320 247 501 minecraft:shroomlight
fill 320 247 502 320 263 502 minecraft:polished_blackstone_bricks
setblock 320 247 503 minecraft:shroomlight
fill 320 247 504 320 263 504 minecraft:polished_blackstone_bricks
setblock 321 247 494 minecraft:shroomlight
fill 321 247 495 321 263 495 minecraft:polished_blackstone_bricks
setblock 321 247 496 minecraft:shroomlight
fill 321 247 497 321 263 497 minecraft:polished_blackstone_bricks
setblock 321 247 498 minecraft:shroomlight
fill 321 247 499 321 263 499 minecraft:polished_blackstone_bricks
setblock 321 247 500 minecraft:shroomlight
fill 321 247 501 321 263 501 minecraft:polished_blackstone_bricks
setblock 321 247 502 minecraft:shroomlight
fill 321 247 503 321 263 503 minecraft:polished_blackstone_bricks
setblock 321 247 504 minecraft:shroomlight
fill 309 248 494 309 249 494 minecraft:polished_blackstone_bricks
fill 309 248 496 309 249 496 minecraft:polished_blackstone_bricks
fill 309 248 498 309 249 498 minecraft:polished_blackstone_bricks
fill 309 248 500 309 249 500 minecraft:polished_blackstone_bricks
fill 309 248 502 309 249 502 minecraft:polished_blackstone_bricks
fill 309 248 504 309 249 504 minecraft:polished_blackstone_bricks
fill 310 248 495 310 249 495 minecraft:polished_blackstone_bricks
fill 310 248 497 310 249 497 minecraft:polished_blackstone_bricks
fill 310 248 499 310 249 499 minecraft:polished_blackstone_bricks
fill 310 248 501 310 249 501 minecraft:polished_blackstone_bricks
fill 310 248 503 310 249 503 minecraft:polished_blackstone_bricks
fill 311 248 494 311 249 494 minecraft:polished_blackstone_bricks
fill 311 248 496 311 249 496 minecraft:polished_blackstone_bricks
fill 311 248 498 311 249 498 minecraft:polished_blackstone_bricks
fill 311 248 500 311 249 500 minecraft:polished_blackstone_bricks
fill 311 248 502 311 249 502 minecraft:polished_blackstone_bricks
fill 311 248 504 311 249 504 minecraft:polished_blackstone_bricks
fill 312 248 495 312 249 495 minecraft:polished_blackstone_bricks
fill 312 248 497 312 249 497 minecraft:polished_blackstone_bricks
fill 312 248 499 312 249 499 minecraft:polished_blackstone_bricks
fill 312 248 501 312 249 501 minecraft:polished_blackstone_bricks
fill 312 248 503 312 249 503 minecraft:polished_blackstone_bricks
fill 313 248 494 313 249 494 minecraft:polished_blackstone_bricks
fill 313 248 496 313 249 496 minecraft:polished_blackstone_bricks
fill 313 248 498 313 249 498 minecraft:polished_blackstone_bricks
fill 313 248 500 313 249 500 minecraft:polished_blackstone_bricks
fill 313 248 502 313 249 502 minecraft:polished_blackstone_bricks
fill 313 248 504 313 249 504 minecraft:polished_blackstone_bricks
fill 314 248 495 314 249 495 minecraft:polished_blackstone_bricks
fill 314 248 497 314 249 497 minecraft:polished_blackstone_bricks
fill 314 248 499 314 249 499 minecraft:polished_blackstone_bricks
fill 314 248 501 314 249 501 minecraft:polished_blackstone_bricks
fill 314 248 503 314 249 503 minecraft:polished_blackstone_bricks
fill 315 248 494 315 249 494 minecraft:polished_blackstone_bricks
fill 315 248 496 315 249 496 minecraft:polished_blackstone_bricks
fill 315 248 498 315 249 498 minecraft:polished_blackstone_bricks
fill 315 248 500 315 249 500 minecraft:polished_blackstone_bricks
fill 315 248 502 315 249 502 minecraft:polished_blackstone_bricks
fill 315 248 504 315 249 504 minecraft:polished_blackstone_bricks
fill 316 248 495 316 249 495 minecraft:polished_blackstone_bricks
fill 316 248 497 316 249 497 minecraft:polished_blackstone_bricks
fill 316 248 499 316 249 499 minecraft:polished_blackstone_bricks
fill 316 248 501 316 249 501 minecraft:polished_blackstone_bricks
fill 316 248 503 316 249 503 minecraft:polished_blackstone_bricks
fill 317 248 494 317 249 494 minecraft:polished_blackstone_bricks
fill 317 248 496 317 249 496 minecraft:polished_blackstone_bricks
fill 317 248 498 317 249 498 minecraft:polished_blackstone_bricks
fill 317 248 500 317 249 500 minecraft:polished_blackstone_bricks
fill 317 248 502 317 249 502 minecraft:polished_blackstone_bricks
fill 317 248 504 317 249 504 minecraft:polished_blackstone_bricks
fill 318 248 495 318 249 495 minecraft:polished_blackstone_bricks
fill 318 248 497 318 249 497 minecraft:polished_blackstone_bricks
fill 318 248 499 318 249 499 minecraft:polished_blackstone_bricks
fill 318 248 501 318 249 501 minecraft:polished_blackstone_bricks
fill 318 248 503 318 249 503 minecraft:polished_blackstone_bricks
fill 319 248 494 319 249 494 minecraft:polished_blackstone_bricks
fill 319 248 496 319 249 496 minecraft:polished_blackstone_bricks
fill 319 248 498 319 249 498 minecraft:polished_blackstone_bricks
fill 319 248 500 319 249 500 minecraft:polished_blackstone_bricks
fill 319 248 502 319 249 502 minecraft:polished_blackstone_bricks
fill 319 248 504 319 249 504 minecraft:polished_blackstone_bricks
fill 320 248 495 320 249 495 minecraft:polished_blackstone_bricks
fill 320 248 497 320 249 497 minecraft:polished_blackstone_bricks
fill 320 248 499 320 249 499 minecraft:polished_blackstone_bricks
fill 320 248 501 320 249 501 minecraft:polished_blackstone_bricks
fill 320 248 503 320 249 503 minecraft:polished_blackstone_bricks
fill 321 248 494 321 249 494 minecraft:polished_blackstone_bricks
fill 321 248 496 321 249 496 minecraft:polished_blackstone_bricks
fill 321 248 498 321 249 498 minecraft:polished_blackstone_bricks
fill 321 248 500 321 249 500 minecraft:polished_blackstone_bricks
fill 321 248 502 321 249 502 minecraft:polished_blackstone_bricks
fill 321 248 504 321 249 504 minecraft:polished_blackstone_bricks
fill 284 249 481 284 261 481 minecraft:red_wool
fill 284 250 479 284 261 480 minecraft:red_wool
fill 284 250 482 284 261 483 minecraft:red_wool
setblock 309 250 494 minecraft:shroomlight
setblock 309 250 496 minecraft:shroomlight
setblock 309 250 498 minecraft:shroomlight
setblock 309 250 500 minecraft:shroomlight
setblock 309 250 502 minecraft:shroomlight
setblock 309 250 504 minecraft:shroomlight
setblock 310 250 495 minecraft:shroomlight
setblock 310 250 497 minecraft:shroomlight
setblock 310 250 499 minecraft:shroomlight
setblock 310 250 501 minecraft:shroomlight
setblock 310 250 503 minecraft:shroomlight
setblock 311 250 494 minecraft:shroomlight
setblock 311 250 496 minecraft:shroomlight
setblock 311 250 498 minecraft:shroomlight
setblock 311 250 500 minecraft:shroomlight
setblock 311 250 502 minecraft:shroomlight
setblock 311 250 504 minecraft:shroomlight
setblock 312 250 495 minecraft:shroomlight
setblock 312 250 497 minecraft:shroomlight
setblock 312 250 499 minecraft:shroomlight
setblock 312 250 501 minecraft:shroomlight
setblock 312 250 503 minecraft:shroomlight
setblock 313 250 494 minecraft:shroomlight
setblock 313 250 496 minecraft:shroomlight
setblock 313 250 498 minecraft:shroomlight
setblock 313 250 500 minecraft:shroomlight
setblock 313 250 502 minecraft:shroomlight
setblock 313 250 504 minecraft:shroomlight
setblock 314 250 495 minecraft:shroomlight
setblock 314 250 497 minecraft:shroomlight
setblock 314 250 499 minecraft:shroomlight
setblock 314 250 501 minecraft:shroomlight
setblock 314 250 503 minecraft:shroomlight
setblock 315 250 494 minecraft:shroomlight
setblock 315 250 496 minecraft:shroomlight
setblock 315 250 498 minecraft:shroomlight
setblock 315 250 500 minecraft:shroomlight
setblock 315 250 502 minecraft:shroomlight
setblock 315 250 504 minecraft:shroomlight
setblock 316 250 495 minecraft:shroomlight
setblock 316 250 497 minecraft:shroomlight
setblock 316 250 499 minecraft:shroomlight
setblock 316 250 501 minecraft:shroomlight
setblock 316 250 503 minecraft:shroomlight
setblock 317 250 494 minecraft:shroomlight
setblock 317 250 496 minecraft:shroomlight
setblock 317 250 498 minecraft:shroomlight
setblock 317 250 500 minecraft:shroomlight
setblock 317 250 502 minecraft:shroomlight
setblock 317 250 504 minecraft:shroomlight
setblock 318 250 495 minecraft:shroomlight
setblock 318 250 497 minecraft:shroomlight
setblock 318 250 499 minecraft:shroomlight
setblock 318 250 501 minecraft:shroomlight
setblock 318 250 503 minecraft:shroomlight
setblock 319 250 494 minecraft:shroomlight
setblock 319 250 496 minecraft:shroomlight
setblock 319 250 498 minecraft:shroomlight
setblock 319 250 500 minecraft:shroomlight
setblock 319 250 502 minecraft:shroomlight
setblock 319 250 504 minecraft:shroomlight
setblock 320 250 495 minecraft:shroomlight
setblock 320 250 497 minecraft:shroomlight
setblock 320 250 499 minecraft:shroomlight
setblock 320 250 501 minecraft:shroomlight
setblock 320 250 503 minecraft:shroomlight
setblock 321 250 494 minecraft:shroomlight
setblock 321 250 496 minecraft:shroomlight
setblock 321 250 498 minecraft:shroomlight
setblock 321 250 500 minecraft:shroomlight
setblock 321 250 502 minecraft:shroomlight
setblock 321 250 504 minecraft:shroomlight
fill 309 251 494 309 252 494 minecraft:polished_blackstone_bricks
fill 309 251 496 309 252 496 minecraft:polished_blackstone_bricks
fill 309 251 498 309 252 498 minecraft:polished_blackstone_bricks
fill 309 251 500 309 252 500 minecraft:polished_blackstone_bricks
fill 309 251 502 309 252 502 minecraft:polished_blackstone_bricks
fill 309 251 504 309 252 504 minecraft:polished_blackstone_bricks
fill 310 251 495 310 252 495 minecraft:polished_blackstone_bricks
fill 310 251 497 310 252 497 minecraft:polished_blackstone_bricks
fill 310 251 499 310 252 499 minecraft:polished_blackstone_bricks
fill 310 251 501 310 252 501 minecraft:polished_blackstone_bricks
fill 310 251 503 310 252 503 minecraft:polished_blackstone_bricks
fill 311 251 494 311 252 494 minecraft:polished_blackstone_bricks
fill 311 251 496 311 252 496 minecraft:polished_blackstone_bricks
fill 311 251 498 311 252 498 minecraft:polished_blackstone_bricks
fill 311 251 500 311 252 500 minecraft:polished_blackstone_bricks
fill 311 251 502 311 252 502 minecraft:polished_blackstone_bricks
fill 311 251 504 311 252 504 minecraft:polished_blackstone_bricks
fill 312 251 495 312 252 495 minecraft:polished_blackstone_bricks
fill 312 251 497 312 252 497 minecraft:polished_blackstone_bricks
fill 312 251 499 312 252 499 minecraft:polished_blackstone_bricks
fill 312 251 501 312 252 501 minecraft:polished_blackstone_bricks
fill 312 251 503 312 252 503 minecraft:polished_blackstone_bricks
fill 313 251 494 313 252 494 minecraft:polished_blackstone_bricks
fill 313 251 496 313 252 496 minecraft:polished_blackstone_bricks
fill 313 251 498 313 252 498 minecraft:polished_blackstone_bricks
fill 313 251 500 313 252 500 minecraft:polished_blackstone_bricks
fill 313 251 502 313 252 502 minecraft:polished_blackstone_bricks
fill 313 251 504 313 252 504 minecraft:polished_blackstone_bricks
fill 314 251 495 314 252 495 minecraft:polished_blackstone_bricks
fill 314 251 497 314 252 497 minecraft:polished_blackstone_bricks
fill 314 251 499 314 252 499 minecraft:polished_blackstone_bricks
fill 314 251 501 314 252 501 minecraft:polished_blackstone_bricks
fill 314 251 503 314 252 503 minecraft:polished_blackstone_bricks
fill 315 251 494 315 252 494 minecraft:polished_blackstone_bricks
fill 315 251 496 315 252 496 minecraft:polished_blackstone_bricks
fill 315 251 498 315 252 498 minecraft:polished_blackstone_bricks
fill 315 251 500 315 252 500 minecraft:polished_blackstone_bricks
fill 315 251 502 315 252 502 minecraft:polished_blackstone_bricks
fill 315 251 504 315 252 504 minecraft:polished_blackstone_bricks
fill 316 251 495 316 252 495 minecraft:polished_blackstone_bricks
fill 316 251 497 316 252 497 minecraft:polished_blackstone_bricks
fill 316 251 499 316 252 499 minecraft:polished_blackstone_bricks
fill 316 251 501 316 252 501 minecraft:polished_blackstone_bricks
fill 316 251 503 316 252 503 minecraft:polished_blackstone_bricks
fill 317 251 494 317 252 494 minecraft:polished_blackstone_bricks
fill 317 251 496 317 252 496 minecraft:polished_blackstone_bricks
fill 317 251 498 317 252 498 minecraft:polished_blackstone_bricks
fill 317 251 500 317 252 500 minecraft:polished_blackstone_bricks
fill 317 251 502 317 252 502 minecraft:polished_blackstone_bricks
fill 317 251 504 317 252 504 minecraft:polished_blackstone_bricks
fill 318 251 495 318 252 495 minecraft:polished_blackstone_bricks
fill 318 251 497 318 252 497 minecraft:polished_blackstone_bricks
fill 318 251 499 318 252 499 minecraft:polished_blackstone_bricks
fill 318 251 501 318 252 501 minecraft:polished_blackstone_bricks
fill 318 251 503 318 252 503 minecraft:polished_blackstone_bricks
fill 319 251 494 319 252 494 minecraft:polished_blackstone_bricks
fill 319 251 496 319 252 496 minecraft:polished_blackstone_bricks
fill 319 251 498 319 252 498 minecraft:polished_blackstone_bricks
fill 319 251 500 319 252 500 minecraft:polished_blackstone_bricks
fill 319 251 502 319 252 502 minecraft:polished_blackstone_bricks
fill 319 251 504 319 252 504 minecraft:polished_blackstone_bricks
fill 320 251 495 320 252 495 minecraft:polished_blackstone_bricks
fill 320 251 497 320 252 497 minecraft:polished_blackstone_bricks
fill 320 251 499 320 252 499 minecraft:polished_blackstone_bricks
fill 320 251 501 320 252 501 minecraft:polished_blackstone_bricks
fill 320 251 503 320 252 503 minecraft:polished_blackstone_bricks
fill 321 251 494 321 252 494 minecraft:polished_blackstone_bricks
fill 321 251 496 321 252 496 minecraft:polished_blackstone_bricks
fill 321 251 498 321 252 498 minecraft:polished_blackstone_bricks
fill 321 251 500 321 252 500 minecraft:polished_blackstone_bricks
fill 321 251 502 321 252 502 minecraft:polished_blackstone_bricks
fill 321 251 504 321 252 504 minecraft:polished_blackstone_bricks
fill 282 252 469 282 265 469 minecraft:red_nether_bricks
fill 282 252 470 282 252 471 minecraft:shroomlight
fill 282 252 472 282 265 472 minecraft:red_nether_bricks
fill 282 252 481 282 265 481 minecraft:red_nether_bricks
fill 282 252 482 282 252 483 minecraft:shroomlight
fill 282 252 484 282 265 484 minecraft:red_nether_bricks
fill 282 252 493 282 265 493 minecraft:red_nether_bricks
fill 282 252 494 282 252 495 minecraft:shroomlight
fill 282 252 496 282 265 496 minecraft:red_nether_bricks
fill 282 252 505 282 265 505 minecraft:red_nether_bricks
fill 283 252 505 284 252 505 minecraft:shroomlight
fill 285 252 505 285 265 505 minecraft:red_nether_bricks
fill 289 252 463 289 265 463 minecraft:red_nether_bricks
fill 290 252 463 291 252 463 minecraft:shroomlight
fill 292 252 463 292 265 463 minecraft:red_nether_bricks
fill 294 252 505 294 265 505 minecraft:red_nether_bricks
fill 295 252 505 296 252 505 minecraft:shroomlight
fill 297 252 505 297 265 505 minecraft:red_nether_bricks
fill 301 252 463 301 265 463 minecraft:red_nether_bricks
fill 302 252 463 303 252 463 minecraft:shroomlight
fill 304 252 463 304 265 463 minecraft:red_nether_bricks
fill 306 252 505 306 265 505 minecraft:red_nether_bricks
fill 307 252 505 308 252 505 minecraft:shroomlight
fill 309 252 505 309 265 505 minecraft:red_nether_bricks
fill 313 252 463 313 265 463 minecraft:red_nether_bricks
fill 314 252 463 315 252 463 minecraft:shroomlight
fill 316 252 463 316 265 463 minecraft:red_nether_bricks
fill 318 252 505 318 265 505 minecraft:red_nether_bricks
fill 319 252 505 320 252 505 minecraft:shroomlight
fill 321 252 505 321 265 505 minecraft:red_nether_bricks
fill 324 252 464 324 265 464 minecraft:red_nether_bricks
fill 324 252 465 324 252 466 minecraft:shroomlight
fill 324 252 467 324 265 467 minecraft:red_nether_bricks
fill 324 252 476 324 265 476 minecraft:red_nether_bricks
fill 324 252 477 324 252 478 minecraft:shroomlight
fill 324 252 479 324 265 479 minecraft:red_nether_bricks
fill 324 252 488 324 265 488 minecraft:red_nether_bricks
fill 324 252 489 324 252 490 minecraft:shroomlight
fill 324 252 491 324 265 491 minecraft:red_nether_bricks
fill 324 252 500 324 265 500 minecraft:red_nether_bricks
fill 324 252 501 324 252 502 minecraft:shroomlight
fill 324 252 503 324 265 503 minecraft:red_nether_bricks
fill 282 253 470 282 265 471 minecraft:red_nether_bricks
fill 282 253 482 282 265 483 minecraft:red_nether_bricks
fill 282 253 494 282 265 495 minecraft:red_nether_bricks
fill 283 253 505 284 265 505 minecraft:red_nether_bricks
fill 290 253 463 291 265 463 minecraft:red_nether_bricks
fill 295 253 505 296 265 505 minecraft:red_nether_bricks
fill 302 253 463 303 265 463 minecraft:red_nether_bricks
fill 307 253 505 308 265 505 minecraft:red_nether_bricks
setblock 309 253 494 minecraft:shroomlight
setblock 309 253 496 minecraft:shroomlight
setblock 309 253 498 minecraft:shroomlight
setblock 309 253 500 minecraft:shroomlight
setblock 309 253 502 minecraft:shroomlight
setblock 309 253 504 minecraft:shroomlight
setblock 310 253 495 minecraft:shroomlight
setblock 310 253 497 minecraft:shroomlight
setblock 310 253 499 minecraft:shroomlight
setblock 310 253 501 minecraft:shroomlight
setblock 310 253 503 minecraft:shroomlight
setblock 311 253 494 minecraft:shroomlight
setblock 311 253 496 minecraft:shroomlight
setblock 311 253 498 minecraft:shroomlight
setblock 311 253 500 minecraft:shroomlight
setblock 311 253 502 minecraft:shroomlight
setblock 311 253 504 minecraft:shroomlight
setblock 312 253 495 minecraft:shroomlight
setblock 312 253 497 minecraft:shroomlight
setblock 312 253 499 minecraft:shroomlight
setblock 312 253 501 minecraft:shroomlight
setblock 312 253 503 minecraft:shroomlight
setblock 313 253 494 minecraft:shroomlight
setblock 313 253 496 minecraft:shroomlight
setblock 313 253 498 minecraft:shroomlight
setblock 313 253 500 minecraft:shroomlight
setblock 313 253 502 minecraft:shroomlight
setblock 313 253 504 minecraft:shroomlight
fill 314 253 463 315 265 463 minecraft:red_nether_bricks
setblock 314 253 495 minecraft:shroomlight
setblock 314 253 497 minecraft:shroomlight
setblock 314 253 499 minecraft:shroomlight
setblock 314 253 501 minecraft:shroomlight
setblock 314 253 503 minecraft:shroomlight
setblock 315 253 494 minecraft:shroomlight
setblock 315 253 496 minecraft:shroomlight
setblock 315 253 498 minecraft:shroomlight
setblock 315 253 500 minecraft:shroomlight
setblock 315 253 502 minecraft:shroomlight
setblock 315 253 504 minecraft:shroomlight
setblock 316 253 495 minecraft:shroomlight
setblock 316 253 497 minecraft:shroomlight
setblock 316 253 499 minecraft:shroomlight
setblock 316 253 501 minecraft:shroomlight
setblock 316 253 503 minecraft:shroomlight
setblock 317 253 494 minecraft:shroomlight
setblock 317 253 496 minecraft:shroomlight
setblock 317 253 498 minecraft:shroomlight
setblock 317 253 500 minecraft:shroomlight
setblock 317 253 502 minecraft:shroomlight
setblock 317 253 504 minecraft:shroomlight
setblock 318 253 495 minecraft:shroomlight
setblock 318 253 497 minecraft:shroomlight
setblock 318 253 499 minecraft:shroomlight
setblock 318 253 501 minecraft:shroomlight
setblock 318 253 503 minecraft:shroomlight
setblock 319 253 494 minecraft:shroomlight
setblock 319 253 496 minecraft:shroomlight
setblock 319 253 498 minecraft:shroomlight
setblock 319 253 500 minecraft:shroomlight
setblock 319 253 502 minecraft:shroomlight
setblock 319 253 504 minecraft:shroomlight
fill 319 253 505 320 265 505 minecraft:red_nether_bricks
setblock 320 253 495 minecraft:shroomlight
setblock 320 253 497 minecraft:shroomlight
setblock 320 253 499 minecraft:shroomlight
setblock 320 253 501 minecraft:shroomlight
setblock 320 253 503 minecraft:shroomlight
setblock 321 253 494 minecraft:shroomlight
setblock 321 253 496 minecraft:shroomlight
setblock 321 253 498 minecraft:shroomlight
setblock 321 253 500 minecraft:shroomlight
setblock 321 253 502 minecraft:shroomlight
setblock 321 253 504 minecraft:shroomlight
fill 324 253 465 324 265 466 minecraft:red_nether_bricks
fill 324 253 477 324 265 478 minecraft:red_nether_bricks
fill 324 253 489 324 265 490 minecraft:red_nether_bricks
fill 324 253 501 324 265 502 minecraft:red_nether_bricks
fill 309 254 494 309 255 494 minecraft:polished_blackstone_bricks
fill 309 254 496 309 255 496 minecraft:polished_blackstone_bricks
fill 309 254 498 309 255 498 minecraft:polished_blackstone_bricks
fill 309 254 500 309 255 500 minecraft:polished_blackstone_bricks
fill 309 254 502 309 255 502 minecraft:polished_blackstone_bricks
fill 309 254 504 309 255 504 minecraft:polished_blackstone_bricks
fill 310 254 495 310 255 495 minecraft:polished_blackstone_bricks
fill 310 254 497 310 255 497 minecraft:polished_blackstone_bricks
fill 310 254 499 310 255 499 minecraft:polished_blackstone_bricks
fill 310 254 501 310 255 501 minecraft:polished_blackstone_bricks
fill 310 254 503 310 255 503 minecraft:polished_blackstone_bricks
fill 311 254 494 311 255 494 minecraft:polished_blackstone_bricks
fill 311 254 496 311 255 496 minecraft:polished_blackstone_bricks
fill 311 254 498 311 255 498 minecraft:polished_blackstone_bricks
fill 311 254 500 311 255 500 minecraft:polished_blackstone_bricks
fill 311 254 502 311 255 502 minecraft:polished_blackstone_bricks
fill 311 254 504 311 255 504 minecraft:polished_blackstone_bricks
fill 312 254 495 312 255 495 minecraft:polished_blackstone_bricks
fill 312 254 497 312 255 497 minecraft:polished_blackstone_bricks
fill 312 254 499 312 255 499 minecraft:polished_blackstone_bricks
fill 312 254 501 312 255 501 minecraft:polished_blackstone_bricks
fill 312 254 503 312 255 503 minecraft:polished_blackstone_bricks
fill 313 254 494 313 255 494 minecraft:polished_blackstone_bricks
fill 313 254 496 313 255 496 minecraft:polished_blackstone_bricks
fill 313 254 498 313 255 498 minecraft:polished_blackstone_bricks
fill 313 254 500 313 255 500 minecraft:polished_blackstone_bricks
fill 313 254 502 313 255 502 minecraft:polished_blackstone_bricks
fill 313 254 504 313 255 504 minecraft:polished_blackstone_bricks
fill 314 254 495 314 255 495 minecraft:polished_blackstone_bricks
fill 314 254 497 314 255 497 minecraft:polished_blackstone_bricks
fill 314 254 499 314 255 499 minecraft:polished_blackstone_bricks
fill 314 254 501 314 255 501 minecraft:polished_blackstone_bricks
fill 314 254 503 314 255 503 minecraft:polished_blackstone_bricks
fill 315 254 494 315 255 494 minecraft:polished_blackstone_bricks
fill 315 254 496 315 255 496 minecraft:polished_blackstone_bricks
fill 315 254 498 315 255 498 minecraft:polished_blackstone_bricks
fill 315 254 500 315 255 500 minecraft:polished_blackstone_bricks
fill 315 254 502 315 255 502 minecraft:polished_blackstone_bricks
fill 315 254 504 315 255 504 minecraft:polished_blackstone_bricks
fill 316 254 495 316 255 495 minecraft:polished_blackstone_bricks
fill 316 254 497 316 255 497 minecraft:polished_blackstone_bricks
fill 316 254 499 316 255 499 minecraft:polished_blackstone_bricks
fill 316 254 501 316 255 501 minecraft:polished_blackstone_bricks
fill 316 254 503 316 255 503 minecraft:polished_blackstone_bricks
fill 317 254 494 317 255 494 minecraft:polished_blackstone_bricks
fill 317 254 496 317 255 496 minecraft:polished_blackstone_bricks
fill 317 254 498 317 255 498 minecraft:polished_blackstone_bricks
fill 317 254 500 317 255 500 minecraft:polished_blackstone_bricks
fill 317 254 502 317 255 502 minecraft:polished_blackstone_bricks
fill 317 254 504 317 255 504 minecraft:polished_blackstone_bricks
fill 318 254 495 318 255 495 minecraft:polished_blackstone_bricks
fill 318 254 497 318 255 497 minecraft:polished_blackstone_bricks
fill 318 254 499 318 255 499 minecraft:polished_blackstone_bricks
fill 318 254 501 318 255 501 minecraft:polished_blackstone_bricks
fill 318 254 503 318 255 503 minecraft:polished_blackstone_bricks
fill 319 254 494 319 255 494 minecraft:polished_blackstone_bricks
fill 319 254 496 319 255 496 minecraft:polished_blackstone_bricks
fill 319 254 498 319 255 498 minecraft:polished_blackstone_bricks
fill 319 254 500 319 255 500 minecraft:polished_blackstone_bricks
fill 319 254 502 319 255 502 minecraft:polished_blackstone_bricks
fill 319 254 504 319 255 504 minecraft:polished_blackstone_bricks
fill 320 254 495 320 255 495 minecraft:polished_blackstone_bricks
fill 320 254 497 320 255 497 minecraft:polished_blackstone_bricks
fill 320 254 499 320 255 499 minecraft:polished_blackstone_bricks
fill 320 254 501 320 255 501 minecraft:polished_blackstone_bricks
fill 320 254 503 320 255 503 minecraft:polished_blackstone_bricks
fill 321 254 494 321 255 494 minecraft:polished_blackstone_bricks
fill 321 254 496 321 255 496 minecraft:polished_blackstone_bricks
fill 321 254 498 321 255 498 minecraft:polished_blackstone_bricks
fill 321 254 500 321 255 500 minecraft:polished_blackstone_bricks
fill 321 254 502 321 255 502 minecraft:polished_blackstone_bricks
fill 321 254 504 321 255 504 minecraft:polished_blackstone_bricks
setblock 285 255 466 minecraft:light[level=14]
setblock 285 255 474 minecraft:light[level=14]
setblock 285 255 482 minecraft:light[level=14]
setblock 285 255 490 minecraft:light[level=14]
setblock 285 255 498 minecraft:light[level=14]
setblock 293 255 466 minecraft:light[level=14]
setblock 293 255 474 minecraft:light[level=14]
setblock 293 255 482 minecraft:light[level=14]
setblock 293 255 490 minecraft:light[level=14]
setblock 293 255 498 minecraft:light[level=14]
setblock 301 255 466 minecraft:light[level=14]
setblock 301 255 474 minecraft:light[level=14]
setblock 301 255 482 minecraft:light[level=14]
setblock 301 255 490 minecraft:light[level=14]
setblock 301 255 498 minecraft:light[level=14]
setblock 309 255 466 minecraft:light[level=14]
setblock 309 255 474 minecraft:light[level=14]
setblock 309 255 482 minecraft:light[level=14]
setblock 309 255 490 minecraft:light[level=14]
setblock 317 255 466 minecraft:light[level=14]
setblock 317 255 474 minecraft:light[level=14]
setblock 317 255 482 minecraft:light[level=14]
setblock 317 255 490 minecraft:light[level=14]
setblock 309 256 494 minecraft:shroomlight
setblock 309 256 496 minecraft:shroomlight
setblock 309 256 498 minecraft:shroomlight
setblock 309 256 500 minecraft:shroomlight
setblock 309 256 502 minecraft:shroomlight
setblock 309 256 504 minecraft:shroomlight
setblock 310 256 495 minecraft:shroomlight
setblock 310 256 497 minecraft:shroomlight
setblock 310 256 499 minecraft:shroomlight
setblock 310 256 501 minecraft:shroomlight
setblock 310 256 503 minecraft:shroomlight
setblock 311 256 494 minecraft:shroomlight
setblock 311 256 496 minecraft:shroomlight
setblock 311 256 498 minecraft:shroomlight
setblock 311 256 500 minecraft:shroomlight
setblock 311 256 502 minecraft:shroomlight
setblock 311 256 504 minecraft:shroomlight
setblock 312 256 495 minecraft:shroomlight
setblock 312 256 497 minecraft:shroomlight
setblock 312 256 499 minecraft:shroomlight
setblock 312 256 501 minecraft:shroomlight
setblock 312 256 503 minecraft:shroomlight
setblock 313 256 494 minecraft:shroomlight
setblock 313 256 496 minecraft:shroomlight
setblock 313 256 498 minecraft:shroomlight
setblock 313 256 500 minecraft:shroomlight
setblock 313 256 502 minecraft:shroomlight
setblock 313 256 504 minecraft:shroomlight
setblock 314 256 495 minecraft:shroomlight
setblock 314 256 497 minecraft:shroomlight
setblock 314 256 499 minecraft:shroomlight
setblock 314 256 501 minecraft:shroomlight
setblock 314 256 503 minecraft:shroomlight
setblock 315 256 494 minecraft:shroomlight
setblock 315 256 496 minecraft:shroomlight
setblock 315 256 498 minecraft:shroomlight
setblock 315 256 500 minecraft:shroomlight
setblock 315 256 502 minecraft:shroomlight
setblock 315 256 504 minecraft:shroomlight
setblock 316 256 495 minecraft:shroomlight
setblock 316 256 497 minecraft:shroomlight
setblock 316 256 499 minecraft:shroomlight
setblock 316 256 501 minecraft:shroomlight
setblock 316 256 503 minecraft:shroomlight
setblock 317 256 494 minecraft:shroomlight
setblock 317 256 496 minecraft:shroomlight
setblock 317 256 498 minecraft:shroomlight
setblock 317 256 500 minecraft:shroomlight
setblock 317 256 502 minecraft:shroomlight
setblock 317 256 504 minecraft:shroomlight
setblock 318 256 495 minecraft:shroomlight
setblock 318 256 497 minecraft:shroomlight
setblock 318 256 499 minecraft:shroomlight
setblock 318 256 501 minecraft:shroomlight
setblock 318 256 503 minecraft:shroomlight
setblock 319 256 494 minecraft:shroomlight
setblock 319 256 496 minecraft:shroomlight
setblock 319 256 498 minecraft:shroomlight
setblock 319 256 500 minecraft:shroomlight
setblock 319 256 502 minecraft:shroomlight
setblock 319 256 504 minecraft:shroomlight
setblock 320 256 495 minecraft:shroomlight
setblock 320 256 497 minecraft:shroomlight
setblock 320 256 499 minecraft:shroomlight
setblock 320 256 501 minecraft:shroomlight
setblock 320 256 503 minecraft:shroomlight
setblock 321 256 494 minecraft:shroomlight
setblock 321 256 496 minecraft:shroomlight
setblock 321 256 498 minecraft:shroomlight
setblock 321 256 500 minecraft:shroomlight
setblock 321 256 502 minecraft:shroomlight
setblock 321 256 504 minecraft:shroomlight
fill 309 257 494 309 258 494 minecraft:polished_blackstone_bricks
fill 309 257 496 309 258 496 minecraft:polished_blackstone_bricks
fill 309 257 498 309 258 498 minecraft:polished_blackstone_bricks
fill 309 257 500 309 258 500 minecraft:polished_blackstone_bricks
fill 309 257 502 309 258 502 minecraft:polished_blackstone_bricks
fill 309 257 504 309 258 504 minecraft:polished_blackstone_bricks
fill 310 257 495 310 258 495 minecraft:polished_blackstone_bricks
fill 310 257 497 310 258 497 minecraft:polished_blackstone_bricks
fill 310 257 499 310 258 499 minecraft:polished_blackstone_bricks
fill 310 257 501 310 258 501 minecraft:polished_blackstone_bricks
fill 310 257 503 310 258 503 minecraft:polished_blackstone_bricks
fill 311 257 494 311 258 494 minecraft:polished_blackstone_bricks
fill 311 257 496 311 258 496 minecraft:polished_blackstone_bricks
fill 311 257 498 311 258 498 minecraft:polished_blackstone_bricks
fill 311 257 500 311 258 500 minecraft:polished_blackstone_bricks
fill 311 257 502 311 258 502 minecraft:polished_blackstone_bricks
fill 311 257 504 311 258 504 minecraft:polished_blackstone_bricks
fill 312 257 495 312 258 495 minecraft:polished_blackstone_bricks
fill 312 257 497 312 258 497 minecraft:polished_blackstone_bricks
fill 312 257 499 312 258 499 minecraft:polished_blackstone_bricks
fill 312 257 501 312 258 501 minecraft:polished_blackstone_bricks
fill 312 257 503 312 258 503 minecraft:polished_blackstone_bricks
fill 313 257 494 313 258 494 minecraft:polished_blackstone_bricks
fill 313 257 496 313 258 496 minecraft:polished_blackstone_bricks
fill 313 257 498 313 258 498 minecraft:polished_blackstone_bricks
fill 313 257 500 313 258 500 minecraft:polished_blackstone_bricks
fill 313 257 502 313 258 502 minecraft:polished_blackstone_bricks
fill 313 257 504 313 258 504 minecraft:polished_blackstone_bricks
fill 314 257 495 314 258 495 minecraft:polished_blackstone_bricks
fill 314 257 497 314 258 497 minecraft:polished_blackstone_bricks
fill 314 257 499 314 258 499 minecraft:polished_blackstone_bricks
fill 314 257 501 314 258 501 minecraft:polished_blackstone_bricks
fill 314 257 503 314 258 503 minecraft:polished_blackstone_bricks
fill 315 257 494 315 258 494 minecraft:polished_blackstone_bricks
fill 315 257 496 315 258 496 minecraft:polished_blackstone_bricks
fill 315 257 498 315 258 498 minecraft:polished_blackstone_bricks
fill 315 257 500 315 258 500 minecraft:polished_blackstone_bricks
fill 315 257 502 315 258 502 minecraft:polished_blackstone_bricks
fill 315 257 504 315 258 504 minecraft:polished_blackstone_bricks
fill 316 257 495 316 258 495 minecraft:polished_blackstone_bricks
fill 316 257 497 316 258 497 minecraft:polished_blackstone_bricks
fill 316 257 499 316 258 499 minecraft:polished_blackstone_bricks
fill 316 257 501 316 258 501 minecraft:polished_blackstone_bricks
fill 316 257 503 316 258 503 minecraft:polished_blackstone_bricks
fill 317 257 494 317 258 494 minecraft:polished_blackstone_bricks
fill 317 257 496 317 258 496 minecraft:polished_blackstone_bricks
fill 317 257 498 317 258 498 minecraft:polished_blackstone_bricks
fill 317 257 500 317 258 500 minecraft:polished_blackstone_bricks
fill 317 257 502 317 258 502 minecraft:polished_blackstone_bricks
fill 317 257 504 317 258 504 minecraft:polished_blackstone_bricks
fill 318 257 495 318 258 495 minecraft:polished_blackstone_bricks
fill 318 257 497 318 258 497 minecraft:polished_blackstone_bricks
fill 318 257 499 318 258 499 minecraft:polished_blackstone_bricks
fill 318 257 501 318 258 501 minecraft:polished_blackstone_bricks
fill 318 257 503 318 258 503 minecraft:polished_blackstone_bricks
fill 319 257 494 319 258 494 minecraft:polished_blackstone_bricks
fill 319 257 496 319 258 496 minecraft:polished_blackstone_bricks
fill 319 257 498 319 258 498 minecraft:polished_blackstone_bricks
fill 319 257 500 319 258 500 minecraft:polished_blackstone_bricks
fill 319 257 502 319 258 502 minecraft:polished_blackstone_bricks
fill 319 257 504 319 258 504 minecraft:polished_blackstone_bricks
fill 320 257 495 320 258 495 minecraft:polished_blackstone_bricks
fill 320 257 497 320 258 497 minecraft:polished_blackstone_bricks
fill 320 257 499 320 258 499 minecraft:polished_blackstone_bricks
fill 320 257 501 320 258 501 minecraft:polished_blackstone_bricks
fill 320 257 503 320 258 503 minecraft:polished_blackstone_bricks
fill 321 257 494 321 258 494 minecraft:polished_blackstone_bricks
fill 321 257 496 321 258 496 minecraft:polished_blackstone_bricks
fill 321 257 498 321 258 498 minecraft:polished_blackstone_bricks
fill 321 257 500 321 258 500 minecraft:polished_blackstone_bricks
fill 321 257 502 321 258 502 minecraft:polished_blackstone_bricks
fill 321 257 504 321 258 504 minecraft:polished_blackstone_bricks
setblock 309 259 494 minecraft:shroomlight
setblock 309 259 496 minecraft:shroomlight
setblock 309 259 498 minecraft:shroomlight
setblock 309 259 500 minecraft:shroomlight
setblock 309 259 502 minecraft:shroomlight
setblock 309 259 504 minecraft:shroomlight
setblock 310 259 495 minecraft:shroomlight
setblock 310 259 497 minecraft:shroomlight
setblock 310 259 499 minecraft:shroomlight
setblock 310 259 501 minecraft:shroomlight
setblock 310 259 503 minecraft:shroomlight
setblock 311 259 494 minecraft:shroomlight
setblock 311 259 496 minecraft:shroomlight
setblock 311 259 498 minecraft:shroomlight
setblock 311 259 500 minecraft:shroomlight
setblock 311 259 502 minecraft:shroomlight
setblock 311 259 504 minecraft:shroomlight
setblock 312 259 495 minecraft:shroomlight
setblock 312 259 497 minecraft:shroomlight
setblock 312 259 499 minecraft:shroomlight
setblock 312 259 501 minecraft:shroomlight
setblock 312 259 503 minecraft:shroomlight
setblock 313 259 494 minecraft:shroomlight
setblock 313 259 496 minecraft:shroomlight
setblock 313 259 498 minecraft:shroomlight
setblock 313 259 500 minecraft:shroomlight
setblock 313 259 502 minecraft:shroomlight
setblock 313 259 504 minecraft:shroomlight
setblock 314 259 495 minecraft:shroomlight
setblock 314 259 497 minecraft:shroomlight
setblock 314 259 499 minecraft:shroomlight
setblock 314 259 501 minecraft:shroomlight
setblock 314 259 503 minecraft:shroomlight
setblock 315 259 494 minecraft:shroomlight
setblock 315 259 496 minecraft:shroomlight
setblock 315 259 498 minecraft:shroomlight
setblock 315 259 500 minecraft:shroomlight
setblock 315 259 502 minecraft:shroomlight
setblock 315 259 504 minecraft:shroomlight
setblock 316 259 495 minecraft:shroomlight
setblock 316 259 497 minecraft:shroomlight
setblock 316 259 499 minecraft:shroomlight
setblock 316 259 501 minecraft:shroomlight
setblock 316 259 503 minecraft:shroomlight
setblock 317 259 494 minecraft:shroomlight
setblock 317 259 496 minecraft:shroomlight
setblock 317 259 498 minecraft:shroomlight
setblock 317 259 500 minecraft:shroomlight
setblock 317 259 502 minecraft:shroomlight
setblock 317 259 504 minecraft:shroomlight
setblock 318 259 495 minecraft:shroomlight
setblock 318 259 497 minecraft:shroomlight
setblock 318 259 499 minecraft:shroomlight
setblock 318 259 501 minecraft:shroomlight
setblock 318 259 503 minecraft:shroomlight
setblock 319 259 494 minecraft:shroomlight
setblock 319 259 496 minecraft:shroomlight
setblock 319 259 498 minecraft:shroomlight
setblock 319 259 500 minecraft:shroomlight
setblock 319 259 502 minecraft:shroomlight
setblock 319 259 504 minecraft:shroomlight
setblock 320 259 495 minecraft:shroomlight
setblock 320 259 497 minecraft:shroomlight
setblock 320 259 499 minecraft:shroomlight
setblock 320 259 501 minecraft:shroomlight
setblock 320 259 503 minecraft:shroomlight
setblock 321 259 494 minecraft:shroomlight
setblock 321 259 496 minecraft:shroomlight
setblock 321 259 498 minecraft:shroomlight
setblock 321 259 500 minecraft:shroomlight
setblock 321 259 502 minecraft:shroomlight
setblock 321 259 504 minecraft:shroomlight
fill 284 260 473 284 265 475 minecraft:polished_blackstone_bricks
fill 284 260 485 284 265 487 minecraft:polished_blackstone_bricks
fill 284 260 497 284 265 499 minecraft:polished_blackstone_bricks
fill 290 260 503 292 265 503 minecraft:polished_blackstone_bricks
fill 294 260 465 296 265 465 minecraft:polished_blackstone_bricks
fill 298 260 465 298 272 465 minecraft:red_wool
fill 302 260 503 304 265 503 minecraft:polished_blackstone_bricks
fill 306 260 465 308 265 465 minecraft:polished_blackstone_bricks
fill 309 260 494 309 261 494 minecraft:polished_blackstone_bricks
fill 309 260 496 309 261 496 minecraft:polished_blackstone_bricks
fill 309 260 498 309 261 498 minecraft:polished_blackstone_bricks
fill 309 260 500 309 261 500 minecraft:polished_blackstone_bricks
fill 309 260 502 309 261 502 minecraft:polished_blackstone_bricks
fill 309 260 504 309 261 504 minecraft:polished_blackstone_bricks
fill 310 260 495 310 261 495 minecraft:polished_blackstone_bricks
fill 310 260 497 310 261 497 minecraft:polished_blackstone_bricks
fill 310 260 499 310 261 499 minecraft:polished_blackstone_bricks
fill 310 260 501 310 261 501 minecraft:polished_blackstone_bricks
fill 310 260 503 310 261 503 minecraft:polished_blackstone_bricks
fill 311 260 494 311 261 494 minecraft:polished_blackstone_bricks
fill 311 260 496 311 261 496 minecraft:polished_blackstone_bricks
fill 311 260 498 311 261 498 minecraft:polished_blackstone_bricks
fill 311 260 500 311 261 500 minecraft:polished_blackstone_bricks
fill 311 260 502 311 261 502 minecraft:polished_blackstone_bricks
fill 311 260 504 311 261 504 minecraft:polished_blackstone_bricks
fill 312 260 495 312 261 495 minecraft:polished_blackstone_bricks
fill 312 260 497 312 261 497 minecraft:polished_blackstone_bricks
fill 312 260 499 312 261 499 minecraft:polished_blackstone_bricks
fill 312 260 501 312 261 501 minecraft:polished_blackstone_bricks
fill 312 260 503 312 261 503 minecraft:polished_blackstone_bricks
fill 313 260 494 313 261 494 minecraft:polished_blackstone_bricks
fill 313 260 496 313 261 496 minecraft:polished_blackstone_bricks
fill 313 260 498 313 261 498 minecraft:polished_blackstone_bricks
fill 313 260 500 313 261 500 minecraft:polished_blackstone_bricks
fill 313 260 502 313 261 502 minecraft:polished_blackstone_bricks
fill 313 260 504 313 261 504 minecraft:polished_blackstone_bricks
fill 314 260 495 314 261 495 minecraft:polished_blackstone_bricks
fill 314 260 497 314 261 497 minecraft:polished_blackstone_bricks
fill 314 260 499 314 261 499 minecraft:polished_blackstone_bricks
fill 314 260 501 314 261 501 minecraft:polished_blackstone_bricks
fill 314 260 503 314 261 503 minecraft:polished_blackstone_bricks
fill 315 260 494 315 261 494 minecraft:polished_blackstone_bricks
fill 315 260 496 315 261 496 minecraft:polished_blackstone_bricks
fill 315 260 498 315 261 498 minecraft:polished_blackstone_bricks
fill 315 260 500 315 261 500 minecraft:polished_blackstone_bricks
fill 315 260 502 315 261 502 minecraft:polished_blackstone_bricks
fill 315 260 504 315 261 504 minecraft:polished_blackstone_bricks
fill 316 260 495 316 261 495 minecraft:polished_blackstone_bricks
fill 316 260 497 316 261 497 minecraft:polished_blackstone_bricks
fill 316 260 499 316 261 499 minecraft:polished_blackstone_bricks
fill 316 260 501 316 261 501 minecraft:polished_blackstone_bricks
fill 316 260 503 316 261 503 minecraft:polished_blackstone_bricks
fill 317 260 494 317 261 494 minecraft:polished_blackstone_bricks
fill 317 260 496 317 261 496 minecraft:polished_blackstone_bricks
fill 317 260 498 317 261 498 minecraft:polished_blackstone_bricks
fill 317 260 500 317 261 500 minecraft:polished_blackstone_bricks
fill 317 260 502 317 261 502 minecraft:polished_blackstone_bricks
fill 317 260 504 317 261 504 minecraft:polished_blackstone_bricks
fill 318 260 465 320 265 465 minecraft:polished_blackstone_bricks
fill 318 260 495 318 261 495 minecraft:polished_blackstone_bricks
fill 318 260 497 318 261 497 minecraft:polished_blackstone_bricks
fill 318 260 499 318 261 499 minecraft:polished_blackstone_bricks
fill 318 260 501 318 261 501 minecraft:polished_blackstone_bricks
fill 318 260 503 318 261 503 minecraft:polished_blackstone_bricks
fill 319 260 494 319 261 494 minecraft:polished_blackstone_bricks
fill 319 260 496 319 261 496 minecraft:polished_blackstone_bricks
fill 319 260 498 319 261 498 minecraft:polished_blackstone_bricks
fill 319 260 500 319 261 500 minecraft:polished_blackstone_bricks
fill 319 260 502 319 261 502 minecraft:polished_blackstone_bricks
fill 319 260 504 319 261 504 minecraft:polished_blackstone_bricks
fill 320 260 495 320 261 495 minecraft:polished_blackstone_bricks
fill 320 260 497 320 261 497 minecraft:polished_blackstone_bricks
fill 320 260 499 320 261 499 minecraft:polished_blackstone_bricks
fill 320 260 501 320 261 501 minecraft:polished_blackstone_bricks
fill 320 260 503 320 261 503 minecraft:polished_blackstone_bricks
fill 321 260 494 321 261 494 minecraft:polished_blackstone_bricks
fill 321 260 496 321 261 496 minecraft:polished_blackstone_bricks
fill 321 260 498 322 261 498 minecraft:polished_blackstone_bricks
fill 321 260 500 321 261 500 minecraft:polished_blackstone_bricks
fill 321 260 502 321 261 502 minecraft:polished_blackstone_bricks
fill 321 260 504 321 261 504 minecraft:polished_blackstone_bricks
fill 322 260 473 322 265 475 minecraft:polished_blackstone_bricks
fill 322 260 485 322 265 487 minecraft:polished_blackstone_bricks
fill 322 260 497 322 265 497 minecraft:polished_blackstone_bricks
fill 322 260 499 322 265 499 minecraft:polished_blackstone_bricks
fill 297 261 465 297 272 465 minecraft:red_wool
fill 299 261 465 300 272 465 minecraft:red_wool
fill 284 262 478 284 263 484 minecraft:gilded_blackstone
setblock 309 262 494 minecraft:shroomlight
setblock 309 262 496 minecraft:shroomlight
setblock 309 262 498 minecraft:shroomlight
setblock 309 262 500 minecraft:shroomlight
setblock 309 262 502 minecraft:shroomlight
setblock 309 262 504 minecraft:shroomlight
setblock 310 262 495 minecraft:shroomlight
setblock 310 262 497 minecraft:shroomlight
setblock 310 262 499 minecraft:shroomlight
setblock 310 262 501 minecraft:shroomlight
setblock 310 262 503 minecraft:shroomlight
setblock 311 262 494 minecraft:shroomlight
setblock 311 262 496 minecraft:shroomlight
setblock 311 262 498 minecraft:shroomlight
setblock 311 262 500 minecraft:shroomlight
setblock 311 262 502 minecraft:shroomlight
setblock 311 262 504 minecraft:shroomlight
setblock 312 262 495 minecraft:shroomlight
setblock 312 262 497 minecraft:shroomlight
setblock 312 262 499 minecraft:shroomlight
setblock 312 262 501 minecraft:shroomlight
setblock 312 262 503 minecraft:shroomlight
setblock 313 262 494 minecraft:shroomlight
setblock 313 262 496 minecraft:shroomlight
setblock 313 262 498 minecraft:shroomlight
setblock 313 262 500 minecraft:shroomlight
setblock 313 262 502 minecraft:shroomlight
setblock 313 262 504 minecraft:shroomlight
setblock 314 262 495 minecraft:shroomlight
setblock 314 262 497 minecraft:shroomlight
setblock 314 262 499 minecraft:shroomlight
setblock 314 262 501 minecraft:shroomlight
setblock 314 262 503 minecraft:shroomlight
setblock 315 262 494 minecraft:shroomlight
setblock 315 262 496 minecraft:shroomlight
setblock 315 262 498 minecraft:shroomlight
setblock 315 262 500 minecraft:shroomlight
setblock 315 262 502 minecraft:shroomlight
setblock 315 262 504 minecraft:shroomlight
setblock 316 262 495 minecraft:shroomlight
setblock 316 262 497 minecraft:shroomlight
setblock 316 262 499 minecraft:shroomlight
setblock 316 262 501 minecraft:shroomlight
setblock 316 262 503 minecraft:shroomlight
setblock 317 262 494 minecraft:shroomlight
setblock 317 262 496 minecraft:shroomlight
setblock 317 262 498 minecraft:shroomlight
setblock 317 262 500 minecraft:shroomlight
setblock 317 262 502 minecraft:shroomlight
setblock 317 262 504 minecraft:shroomlight
setblock 318 262 495 minecraft:shroomlight
setblock 318 262 497 minecraft:shroomlight
setblock 318 262 499 minecraft:shroomlight
setblock 318 262 501 minecraft:shroomlight
setblock 318 262 503 minecraft:shroomlight
setblock 319 262 494 minecraft:shroomlight
setblock 319 262 496 minecraft:shroomlight
setblock 319 262 498 minecraft:shroomlight
setblock 319 262 500 minecraft:shroomlight
setblock 319 262 502 minecraft:shroomlight
setblock 319 262 504 minecraft:shroomlight
setblock 320 262 495 minecraft:shroomlight
setblock 320 262 497 minecraft:shroomlight
setblock 320 262 499 minecraft:shroomlight
setblock 320 262 501 minecraft:shroomlight
setblock 320 262 503 minecraft:shroomlight
setblock 321 262 494 minecraft:shroomlight
setblock 321 262 496 minecraft:shroomlight
setblock 321 262 498 minecraft:shroomlight
setblock 321 262 500 minecraft:shroomlight
setblock 321 262 502 minecraft:shroomlight
setblock 321 262 504 minecraft:shroomlight
fill 322 262 498 322 265 498 minecraft:polished_blackstone_bricks
setblock 285 263 466 minecraft:light[level=14]
setblock 285 263 474 minecraft:light[level=14]
setblock 285 263 482 minecraft:light[level=14]
setblock 285 263 490 minecraft:light[level=14]
setblock 285 263 498 minecraft:light[level=14]
setblock 293 263 466 minecraft:light[level=14]
setblock 293 263 474 minecraft:light[level=14]
setblock 293 263 482 minecraft:light[level=14]
setblock 293 263 490 minecraft:light[level=14]
setblock 293 263 498 minecraft:light[level=14]
setblock 301 263 466 minecraft:light[level=14]
setblock 301 263 474 minecraft:light[level=14]
setblock 301 263 482 minecraft:light[level=14]
setblock 301 263 490 minecraft:light[level=14]
setblock 301 263 498 minecraft:light[level=14]
setblock 309 263 466 minecraft:light[level=14]
setblock 309 263 474 minecraft:light[level=14]
setblock 309 263 482 minecraft:light[level=14]
setblock 309 263 490 minecraft:light[level=14]
setblock 309 263 494 minecraft:polished_blackstone_bricks
setblock 309 263 496 minecraft:polished_blackstone_bricks
setblock 309 263 498 minecraft:polished_blackstone_bricks
setblock 309 263 500 minecraft:polished_blackstone_bricks
setblock 309 263 502 minecraft:polished_blackstone_bricks
setblock 309 263 504 minecraft:polished_blackstone_bricks
setblock 310 263 495 minecraft:polished_blackstone_bricks
setblock 310 263 497 minecraft:polished_blackstone_bricks
setblock 310 263 499 minecraft:polished_blackstone_bricks
setblock 310 263 501 minecraft:polished_blackstone_bricks
setblock 310 263 503 minecraft:polished_blackstone_bricks
setblock 311 263 494 minecraft:polished_blackstone_bricks
setblock 311 263 496 minecraft:polished_blackstone_bricks
setblock 311 263 498 minecraft:polished_blackstone_bricks
setblock 311 263 500 minecraft:polished_blackstone_bricks
setblock 311 263 502 minecraft:polished_blackstone_bricks
setblock 311 263 504 minecraft:polished_blackstone_bricks
setblock 312 263 495 minecraft:polished_blackstone_bricks
setblock 312 263 497 minecraft:polished_blackstone_bricks
setblock 312 263 499 minecraft:polished_blackstone_bricks
setblock 312 263 501 minecraft:polished_blackstone_bricks
setblock 312 263 503 minecraft:polished_blackstone_bricks
setblock 313 263 494 minecraft:polished_blackstone_bricks
setblock 313 263 496 minecraft:polished_blackstone_bricks
setblock 313 263 498 minecraft:polished_blackstone_bricks
setblock 313 263 500 minecraft:polished_blackstone_bricks
setblock 313 263 502 minecraft:polished_blackstone_bricks
fill 313 263 504 313 273 504 minecraft:polished_blackstone_bricks
setblock 314 263 495 minecraft:polished_blackstone_bricks
setblock 314 263 497 minecraft:polished_blackstone_bricks
setblock 314 263 499 minecraft:polished_blackstone_bricks
setblock 314 263 501 minecraft:polished_blackstone_bricks
fill 314 263 503 314 265 503 minecraft:polished_blackstone_bricks
setblock 315 263 494 minecraft:polished_blackstone_bricks
setblock 315 263 496 minecraft:polished_blackstone_bricks
setblock 315 263 498 minecraft:polished_blackstone_bricks
setblock 315 263 500 minecraft:polished_blackstone_bricks
setblock 315 263 502 minecraft:polished_blackstone_bricks
fill 315 263 504 315 273 504 minecraft:polished_blackstone_bricks
setblock 316 263 495 minecraft:polished_blackstone_bricks
setblock 316 263 497 minecraft:polished_blackstone_bricks
setblock 316 263 499 minecraft:polished_blackstone_bricks
setblock 316 263 501 minecraft:polished_blackstone_bricks
fill 316 263 503 316 265 503 minecraft:polished_blackstone_bricks
setblock 317 263 466 minecraft:light[level=14]
setblock 317 263 474 minecraft:light[level=14]
setblock 317 263 482 minecraft:light[level=14]
setblock 317 263 490 minecraft:light[level=14]
setblock 317 263 494 minecraft:polished_blackstone_bricks
setblock 317 263 496 minecraft:polished_blackstone_bricks
setblock 317 263 498 minecraft:polished_blackstone_bricks
setblock 317 263 500 minecraft:polished_blackstone_bricks
setblock 317 263 502 minecraft:polished_blackstone_bricks
setblock 317 263 504 minecraft:polished_blackstone_bricks
setblock 318 263 495 minecraft:polished_blackstone_bricks
setblock 318 263 497 minecraft:polished_blackstone_bricks
setblock 318 263 499 minecraft:polished_blackstone_bricks
setblock 318 263 501 minecraft:polished_blackstone_bricks
setblock 318 263 503 minecraft:polished_blackstone_bricks
setblock 319 263 494 minecraft:polished_blackstone_bricks
setblock 319 263 496 minecraft:polished_blackstone_bricks
setblock 319 263 498 minecraft:polished_blackstone_bricks
setblock 319 263 500 minecraft:polished_blackstone_bricks
setblock 319 263 502 minecraft:polished_blackstone_bricks
setblock 319 263 504 minecraft:polished_blackstone_bricks
setblock 320 263 495 minecraft:polished_blackstone_bricks
setblock 320 263 497 minecraft:polished_blackstone_bricks
setblock 320 263 499 minecraft:polished_blackstone_bricks
setblock 320 263 501 minecraft:polished_blackstone_bricks
setblock 320 263 503 minecraft:polished_blackstone_bricks
setblock 321 263 494 minecraft:polished_blackstone_bricks
setblock 321 263 496 minecraft:polished_blackstone_bricks
setblock 321 263 498 minecraft:polished_blackstone_bricks
setblock 321 263 500 minecraft:polished_blackstone_bricks
setblock 321 263 502 minecraft:polished_blackstone_bricks
setblock 321 263 504 minecraft:polished_blackstone_bricks
fill 310 264 495 313 264 503 minecraft:gold_block
fill 314 264 495 320 264 502 minecraft:gold_block
fill 317 264 503 320 264 503 minecraft:gold_block
fill 283 265 467 283 265 472 minecraft:nether_bricks
fill 283 265 479 283 265 484 minecraft:nether_bricks
fill 283 265 491 283 265 496 minecraft:nether_bricks
fill 283 265 503 283 265 504 minecraft:nether_bricks
fill 284 265 504 287 265 504 minecraft:nether_bricks
fill 287 265 464 292 265 464 minecraft:nether_bricks
fill 294 265 504 299 265 504 minecraft:nether_bricks
fill 299 265 464 304 265 464 minecraft:nether_bricks
fill 306 265 504 311 265 504 minecraft:nether_bricks
fill 311 265 464 316 265 464 minecraft:nether_bricks
fill 311 265 496 319 265 502 minecraft:gold_block
fill 318 265 504 323 265 504 minecraft:nether_bricks
fill 323 265 464 323 265 469 minecraft:nether_bricks
fill 323 265 476 323 265 481 minecraft:nether_bricks
fill 323 265 488 323 265 493 minecraft:nether_bricks
fill 323 265 500 323 265 503 minecraft:nether_bricks
fill 282 266 469 282 271 472 minecraft:shroomlight
fill 282 266 481 282 271 484 minecraft:shroomlight
fill 282 266 493 282 271 496 minecraft:shroomlight
fill 282 266 505 285 271 505 minecraft:shroomlight
fill 289 266 463 292 271 463 minecraft:shroomlight
fill 294 266 505 297 271 505 minecraft:shroomlight
fill 296 266 465 296 272 465 minecraft:red_wool
fill 301 266 463 304 271 463 minecraft:shroomlight
fill 306 266 505 309 271 505 minecraft:shroomlight
fill 312 266 497 318 266 501 minecraft:gold_block
fill 313 266 463 316 271 463 minecraft:shroomlight
fill 318 266 505 321 271 505 minecraft:shroomlight
fill 319 266 499 319 271 499 minecraft:gilded_blackstone
fill 324 266 464 324 271 467 minecraft:shroomlight
fill 324 266 476 324 271 479 minecraft:shroomlight
fill 324 266 488 324 271 491 minecraft:shroomlight
fill 324 266 500 324 271 503 minecraft:shroomlight
fill 313 267 498 317 267 500 minecraft:gold_block
setblock 285 271 466 minecraft:light[level=14]
setblock 285 271 474 minecraft:light[level=14]
setblock 285 271 482 minecraft:light[level=14]
setblock 285 271 490 minecraft:light[level=14]
setblock 285 271 498 minecraft:light[level=14]
setblock 293 271 466 minecraft:light[level=14]
setblock 293 271 474 minecraft:light[level=14]
setblock 293 271 482 minecraft:light[level=14]
setblock 293 271 490 minecraft:light[level=14]
setblock 293 271 498 minecraft:light[level=14]
setblock 301 271 466 minecraft:light[level=14]
setblock 301 271 474 minecraft:light[level=14]
setblock 301 271 482 minecraft:light[level=14]
setblock 301 271 490 minecraft:light[level=14]
setblock 301 271 498 minecraft:light[level=14]
setblock 309 271 466 minecraft:light[level=14]
setblock 309 271 474 minecraft:light[level=14]
setblock 309 271 482 minecraft:light[level=14]
setblock 309 271 490 minecraft:light[level=14]
setblock 309 271 498 minecraft:light[level=14]
setblock 317 271 466 minecraft:light[level=14]
setblock 317 271 474 minecraft:light[level=14]
setblock 317 271 482 minecraft:light[level=14]
setblock 317 271 490 minecraft:light[level=14]
setblock 317 271 498 minecraft:light[level=14]
fill 282 272 469 282 285 469 minecraft:red_nether_bricks
fill 282 272 470 282 272 471 minecraft:shroomlight
fill 282 272 472 282 285 472 minecraft:red_nether_bricks
fill 282 272 481 282 285 481 minecraft:red_nether_bricks
fill 282 272 482 282 272 483 minecraft:shroomlight
fill 282 272 484 282 285 484 minecraft:red_nether_bricks
fill 282 272 493 282 285 493 minecraft:red_nether_bricks
fill 282 272 494 282 272 495 minecraft:shroomlight
fill 282 272 496 282 285 496 minecraft:red_nether_bricks
fill 282 272 505 282 285 505 minecraft:red_nether_bricks
fill 283 272 505 284 272 505 minecraft:shroomlight
fill 285 272 505 285 285 505 minecraft:red_nether_bricks
fill 289 272 463 289 285 463 minecraft:red_nether_bricks
fill 290 272 463 291 272 463 minecraft:shroomlight
fill 292 272 463 292 285 463 minecraft:red_nether_bricks
fill 294 272 505 294 285 505 minecraft:red_nether_bricks
fill 295 272 505 296 272 505 minecraft:shroomlight
fill 297 272 505 297 285 505 minecraft:red_nether_bricks
fill 301 272 463 301 285 463 minecraft:red_nether_bricks
fill 302 272 463 303 272 463 minecraft:shroomlight
fill 304 272 463 304 285 463 minecraft:red_nether_bricks
fill 306 272 505 306 285 505 minecraft:red_nether_bricks
fill 307 272 505 308 272 505 minecraft:shroomlight
fill 309 272 505 309 285 505 minecraft:red_nether_bricks
fill 313 272 463 313 285 463 minecraft:red_nether_bricks
fill 314 272 463 315 272 463 minecraft:shroomlight
fill 316 272 463 316 285 463 minecraft:red_nether_bricks
fill 318 272 505 318 285 505 minecraft:red_nether_bricks
fill 319 272 505 320 272 505 minecraft:shroomlight
fill 321 272 505 321 285 505 minecraft:red_nether_bricks
fill 324 272 464 324 285 464 minecraft:red_nether_bricks
fill 324 272 465 324 272 466 minecraft:shroomlight
fill 324 272 467 324 285 467 minecraft:red_nether_bricks
fill 324 272 476 324 285 476 minecraft:red_nether_bricks
fill 324 272 477 324 272 478 minecraft:shroomlight
fill 324 272 479 324 285 479 minecraft:red_nether_bricks
fill 324 272 488 324 285 488 minecraft:red_nether_bricks
fill 324 272 489 324 272 490 minecraft:shroomlight
fill 324 272 491 324 285 491 minecraft:red_nether_bricks
fill 324 272 500 324 285 500 minecraft:red_nether_bricks
fill 324 272 501 324 272 502 minecraft:shroomlight
fill 324 272 503 324 285 503 minecraft:red_nether_bricks
fill 282 273 470 282 285 471 minecraft:red_nether_bricks
fill 282 273 482 282 285 483 minecraft:red_nether_bricks
fill 282 273 494 282 285 495 minecraft:red_nether_bricks
fill 283 273 505 284 285 505 minecraft:red_nether_bricks
fill 290 273 463 291 285 463 minecraft:red_nether_bricks
fill 295 273 465 301 273 465 minecraft:gilded_blackstone
fill 295 273 505 296 285 505 minecraft:red_nether_bricks
fill 302 273 463 303 285 463 minecraft:red_nether_bricks
fill 307 273 505 308 285 505 minecraft:red_nether_bricks
fill 314 273 463 315 285 463 minecraft:red_nether_bricks
fill 319 273 505 320 285 505 minecraft:red_nether_bricks
fill 324 273 465 324 285 466 minecraft:red_nether_bricks
fill 324 273 477 324 285 478 minecraft:red_nether_bricks
fill 324 273 489 324 285 490 minecraft:red_nether_bricks
fill 324 273 501 324 285 502 minecraft:red_nether_bricks
fill 283 279 464 284 280 465 minecraft:nether_bricks
fill 283 279 466 284 279 469 minecraft:red_nether_bricks
fill 283 279 470 284 279 473 minecraft:nether_bricks
fill 283 279 474 284 279 477 minecraft:red_nether_bricks
fill 283 279 478 284 279 481 minecraft:nether_bricks
fill 283 279 482 284 279 485 minecraft:red_nether_bricks
fill 283 279 486 284 279 489 minecraft:nether_bricks
fill 283 279 490 284 279 493 minecraft:red_nether_bricks
fill 283 279 494 284 279 497 minecraft:nether_bricks
fill 283 279 498 284 279 501 minecraft:red_nether_bricks
fill 283 279 502 284 279 504 minecraft:nether_bricks
fill 285 279 464 288 279 465 minecraft:red_nether_bricks
fill 285 279 466 288 279 469 minecraft:nether_bricks
fill 285 279 470 288 279 473 minecraft:red_nether_bricks
fill 285 279 474 288 279 477 minecraft:nether_bricks
fill 285 279 478 288 279 481 minecraft:red_nether_bricks
fill 285 279 482 288 279 485 minecraft:nether_bricks
fill 285 279 486 288 279 489 minecraft:red_nether_bricks
fill 285 279 490 288 279 493 minecraft:nether_bricks
fill 285 279 494 288 279 497 minecraft:red_nether_bricks
fill 285 279 498 288 279 501 minecraft:nether_bricks
fill 285 279 502 288 279 504 minecraft:red_nether_bricks
fill 289 279 464 292 279 465 minecraft:nether_bricks
fill 289 279 466 292 279 469 minecraft:red_nether_bricks
fill 289 279 470 292 279 473 minecraft:nether_bricks
fill 289 279 474 292 279 477 minecraft:red_nether_bricks
fill 289 279 478 292 279 481 minecraft:nether_bricks
fill 289 279 482 292 279 485 minecraft:red_nether_bricks
fill 289 279 486 292 279 489 minecraft:nether_bricks
fill 289 279 490 292 279 493 minecraft:red_nether_bricks
fill 289 279 494 292 279 497 minecraft:nether_bricks
fill 289 279 498 292 279 501 minecraft:red_nether_bricks
fill 289 279 502 292 279 504 minecraft:nether_bricks
fill 293 279 464 296 279 465 minecraft:red_nether_bricks
fill 293 279 466 296 279 469 minecraft:nether_bricks
fill 293 279 470 296 279 473 minecraft:red_nether_bricks
fill 293 279 474 296 279 477 minecraft:nether_bricks
fill 293 279 478 296 279 481 minecraft:red_nether_bricks
fill 293 279 482 296 279 485 minecraft:nether_bricks
fill 293 279 486 296 279 489 minecraft:red_nether_bricks
fill 293 279 490 296 279 493 minecraft:nether_bricks
fill 293 279 494 296 279 497 minecraft:red_nether_bricks
fill 293 279 498 296 279 501 minecraft:nether_bricks
fill 293 279 502 296 279 504 minecraft:red_nether_bricks
fill 297 279 464 300 279 465 minecraft:nether_bricks
fill 297 279 466 300 279 469 minecraft:red_nether_bricks
fill 297 279 470 300 279 473 minecraft:nether_bricks
fill 297 279 474 300 279 477 minecraft:red_nether_bricks
fill 297 279 478 300 279 481 minecraft:nether_bricks
fill 297 279 482 299 279 485 minecraft:red_nether_bricks
fill 297 279 486 298 279 489 minecraft:nether_bricks
fill 297 279 490 300 279 493 minecraft:red_nether_bricks
fill 297 279 494 300 279 497 minecraft:nether_bricks
fill 297 279 498 300 279 501 minecraft:red_nether_bricks
fill 297 279 502 300 279 504 minecraft:nether_bricks
fill 299 279 487 299 279 489 minecraft:nether_bricks
fill 300 279 482 300 279 484 minecraft:red_nether_bricks
fill 300 279 488 300 279 489 minecraft:nether_bricks
fill 301 279 464 304 279 465 minecraft:red_nether_bricks
fill 301 279 466 304 279 469 minecraft:nether_bricks
fill 301 279 470 304 279 473 minecraft:red_nether_bricks
fill 301 279 474 304 279 477 minecraft:nether_bricks
fill 301 279 478 304 279 481 minecraft:red_nether_bricks
fill 301 279 482 304 279 483 minecraft:nether_bricks
fill 301 279 489 304 279 489 minecraft:red_nether_bricks
fill 301 279 490 304 279 493 minecraft:nether_bricks
fill 301 279 494 304 279 497 minecraft:red_nether_bricks
fill 301 279 498 304 279 501 minecraft:nether_bricks
fill 301 279 502 304 279 504 minecraft:red_nether_bricks
fill 302 279 484 304 279 484 minecraft:nether_bricks
fill 302 279 488 304 279 488 minecraft:red_nether_bricks
fill 303 279 485 304 279 485 minecraft:nether_bricks
fill 303 279 487 304 279 487 minecraft:red_nether_bricks
setblock 304 279 486 minecraft:red_nether_bricks
fill 305 279 464 308 279 465 minecraft:nether_bricks
fill 305 279 466 308 279 469 minecraft:red_nether_bricks
fill 305 279 470 308 279 473 minecraft:nether_bricks
fill 305 279 474 308 279 477 minecraft:red_nether_bricks
fill 305 279 478 308 279 481 minecraft:nether_bricks
fill 305 279 482 308 279 485 minecraft:red_nether_bricks
fill 305 279 486 308 279 489 minecraft:nether_bricks
fill 305 279 490 308 279 493 minecraft:red_nether_bricks
fill 305 279 494 308 279 497 minecraft:nether_bricks
fill 305 279 498 308 279 501 minecraft:red_nether_bricks
fill 305 279 502 308 279 504 minecraft:nether_bricks
fill 309 279 464 312 279 465 minecraft:red_nether_bricks
fill 309 279 466 312 279 469 minecraft:nether_bricks
fill 309 279 470 312 279 473 minecraft:red_nether_bricks
fill 309 279 474 312 279 477 minecraft:nether_bricks
fill 309 279 478 312 279 481 minecraft:red_nether_bricks
fill 309 279 482 312 279 485 minecraft:nether_bricks
fill 309 279 486 312 279 489 minecraft:red_nether_bricks
fill 309 279 490 312 279 493 minecraft:nether_bricks
fill 309 279 494 312 279 497 minecraft:red_nether_bricks
fill 309 279 498 312 279 501 minecraft:nether_bricks
fill 309 279 502 312 279 504 minecraft:red_nether_bricks
fill 313 279 464 316 279 465 minecraft:nether_bricks
fill 313 279 466 316 279 469 minecraft:red_nether_bricks
fill 313 279 470 316 279 473 minecraft:nether_bricks
fill 313 279 474 316 279 477 minecraft:red_nether_bricks
fill 313 279 478 316 279 481 minecraft:nether_bricks
fill 313 279 482 316 279 485 minecraft:red_nether_bricks
fill 313 279 486 316 279 489 minecraft:nether_bricks
fill 313 279 490 316 279 493 minecraft:red_nether_bricks
fill 313 279 494 316 279 497 minecraft:nether_bricks
fill 313 279 498 316 279 501 minecraft:red_nether_bricks
fill 313 279 502 316 279 504 minecraft:nether_bricks
fill 317 279 464 320 279 465 minecraft:red_nether_bricks
fill 317 279 466 320 279 469 minecraft:nether_bricks
fill 317 279 470 320 279 473 minecraft:red_nether_bricks
fill 317 279 474 320 279 477 minecraft:nether_bricks
fill 317 279 478 320 279 481 minecraft:red_nether_bricks
fill 317 279 482 320 279 485 minecraft:nether_bricks
fill 317 279 486 320 279 489 minecraft:red_nether_bricks
fill 317 279 490 320 279 493 minecraft:nether_bricks
fill 317 279 494 320 279 497 minecraft:red_nether_bricks
fill 317 279 498 320 279 501 minecraft:nether_bricks
fill 317 279 502 320 279 504 minecraft:red_nether_bricks
fill 321 279 464 323 279 465 minecraft:nether_bricks
fill 321 279 466 323 279 469 minecraft:red_nether_bricks
fill 321 279 470 323 279 473 minecraft:nether_bricks
fill 321 279 474 323 279 477 minecraft:red_nether_bricks
fill 321 279 478 323 279 481 minecraft:nether_bricks
fill 321 279 482 323 279 485 minecraft:red_nether_bricks
fill 321 279 486 323 279 489 minecraft:nether_bricks
fill 321 279 490 323 279 493 minecraft:red_nether_bricks
fill 321 279 494 323 279 497 minecraft:nether_bricks
fill 321 279 498 323 279 501 minecraft:red_nether_bricks
fill 321 279 502 323 279 504 minecraft:nether_bricks
fill 283 280 466 323 280 466 minecraft:polished_blackstone_bricks
fill 283 280 467 284 280 469 minecraft:red_nether_bricks
fill 283 280 470 323 280 470 minecraft:polished_blackstone_bricks
fill 283 280 471 284 280 473 minecraft:nether_bricks
fill 283 280 474 323 280 474 minecraft:polished_blackstone_bricks
fill 283 280 475 284 280 477 minecraft:red_nether_bricks
fill 283 280 478 323 280 478 minecraft:polished_blackstone_bricks
fill 283 280 479 284 280 481 minecraft:nether_bricks
fill 283 280 482 323 280 482 minecraft:polished_blackstone_bricks
fill 283 280 483 284 280 485 minecraft:red_nether_bricks
fill 283 280 486 297 280 486 minecraft:polished_blackstone_bricks
fill 283 280 487 284 280 489 minecraft:nether_bricks
fill 283 280 490 323 280 490 minecraft:polished_blackstone_bricks
fill 283 280 491 284 280 493 minecraft:red_nether_bricks
fill 283 280 494 323 280 494 minecraft:polished_blackstone_bricks
fill 283 280 495 284 280 497 minecraft:nether_bricks
fill 283 280 498 323 280 498 minecraft:polished_blackstone_bricks
fill 283 280 499 284 280 501 minecraft:red_nether_bricks
fill 283 280 502 323 280 502 minecraft:polished_blackstone_bricks
fill 283 280 503 284 280 504 minecraft:nether_bricks
fill 285 280 464 285 280 465 minecraft:polished_blackstone_bricks
fill 285 280 467 285 280 469 minecraft:polished_blackstone_bricks
fill 285 280 471 285 280 473 minecraft:polished_blackstone_bricks
fill 285 280 475 285 280 477 minecraft:polished_blackstone_bricks
fill 285 280 479 285 280 481 minecraft:polished_blackstone_bricks
fill 285 280 483 285 280 485 minecraft:polished_blackstone_bricks
fill 285 280 487 285 280 489 minecraft:polished_blackstone_bricks
fill 285 280 491 285 280 493 minecraft:polished_blackstone_bricks
fill 285 280 495 285 280 497 minecraft:polished_blackstone_bricks
fill 285 280 499 285 280 501 minecraft:polished_blackstone_bricks
fill 285 280 503 285 280 504 minecraft:polished_blackstone_bricks
fill 286 280 464 288 280 465 minecraft:red_nether_bricks
fill 286 280 467 288 280 469 minecraft:nether_bricks
fill 286 280 471 288 280 473 minecraft:red_nether_bricks
fill 286 280 475 288 280 477 minecraft:nether_bricks
fill 286 280 479 288 280 481 minecraft:red_nether_bricks
fill 286 280 483 288 280 485 minecraft:nether_bricks
fill 286 280 487 288 280 489 minecraft:red_nether_bricks
fill 286 280 491 288 280 493 minecraft:nether_bricks
fill 286 280 495 288 280 497 minecraft:red_nether_bricks
fill 286 280 499 288 280 501 minecraft:nether_bricks
fill 286 280 503 288 280 504 minecraft:red_nether_bricks
fill 289 280 464 289 280 465 minecraft:polished_blackstone_bricks
fill 289 280 467 289 280 469 minecraft:polished_blackstone_bricks
fill 289 280 471 289 280 473 minecraft:polished_blackstone_bricks
fill 289 280 475 289 280 477 minecraft:polished_blackstone_bricks
fill 289 280 479 289 280 481 minecraft:polished_blackstone_bricks
fill 289 280 483 289 280 485 minecraft:polished_blackstone_bricks
fill 289 280 487 289 280 489 minecraft:polished_blackstone_bricks
fill 289 280 491 289 280 493 minecraft:polished_blackstone_bricks
fill 289 280 495 289 280 497 minecraft:polished_blackstone_bricks
fill 289 280 499 289 280 501 minecraft:polished_blackstone_bricks
fill 289 280 503 289 280 504 minecraft:polished_blackstone_bricks
fill 290 280 464 292 280 465 minecraft:nether_bricks
fill 290 280 467 292 280 469 minecraft:red_nether_bricks
fill 290 280 471 292 280 473 minecraft:nether_bricks
fill 290 280 475 292 280 477 minecraft:red_nether_bricks
fill 290 280 479 292 280 481 minecraft:nether_bricks
fill 290 280 483 292 280 485 minecraft:red_nether_bricks
fill 290 280 487 292 280 489 minecraft:nether_bricks
fill 290 280 491 292 280 493 minecraft:red_nether_bricks
fill 290 280 495 292 280 497 minecraft:nether_bricks
fill 290 280 499 292 280 501 minecraft:red_nether_bricks
fill 290 280 503 292 280 504 minecraft:nether_bricks
fill 293 280 464 293 280 465 minecraft:polished_blackstone_bricks
fill 293 280 467 293 280 469 minecraft:polished_blackstone_bricks
fill 293 280 471 293 280 473 minecraft:polished_blackstone_bricks
fill 293 280 475 293 280 477 minecraft:polished_blackstone_bricks
fill 293 280 479 293 280 481 minecraft:polished_blackstone_bricks
fill 293 280 483 293 280 485 minecraft:polished_blackstone_bricks
fill 293 280 487 293 280 489 minecraft:polished_blackstone_bricks
fill 293 280 491 293 280 493 minecraft:polished_blackstone_bricks
fill 293 280 495 293 280 497 minecraft:polished_blackstone_bricks
fill 293 280 499 293 280 501 minecraft:polished_blackstone_bricks
fill 293 280 503 293 280 504 minecraft:polished_blackstone_bricks
fill 294 280 464 296 280 465 minecraft:red_nether_bricks
fill 294 280 467 296 280 469 minecraft:nether_bricks
fill 294 280 471 296 280 473 minecraft:red_nether_bricks
fill 294 280 475 296 280 477 minecraft:nether_bricks
fill 294 280 479 296 280 481 minecraft:red_nether_bricks
fill 294 280 483 296 280 485 minecraft:nether_bricks
fill 294 280 487 296 280 489 minecraft:red_nether_bricks
fill 294 280 491 296 280 493 minecraft:nether_bricks
fill 294 280 495 296 280 497 minecraft:red_nether_bricks
fill 294 280 499 296 280 501 minecraft:nether_bricks
fill 294 280 503 296 280 504 minecraft:red_nether_bricks
fill 297 280 464 297 280 465 minecraft:polished_blackstone_bricks
fill 297 280 467 297 280 469 minecraft:polished_blackstone_bricks
fill 297 280 471 297 280 473 minecraft:polished_blackstone_bricks
fill 297 280 475 297 280 477 minecraft:polished_blackstone_bricks
fill 297 280 479 297 280 481 minecraft:polished_blackstone_bricks
fill 297 280 483 297 280 485 minecraft:polished_blackstone_bricks
fill 297 280 487 297 280 489 minecraft:polished_blackstone_bricks
fill 297 280 491 297 280 493 minecraft:polished_blackstone_bricks
fill 297 280 495 297 280 497 minecraft:polished_blackstone_bricks
fill 297 280 499 297 280 501 minecraft:polished_blackstone_bricks
fill 297 280 503 297 280 504 minecraft:polished_blackstone_bricks
fill 298 280 464 300 280 465 minecraft:nether_bricks
fill 298 280 467 300 280 469 minecraft:red_nether_bricks
fill 298 280 471 300 280 473 minecraft:nether_bricks
fill 298 280 475 300 280 477 minecraft:red_nether_bricks
fill 298 280 479 300 280 481 minecraft:nether_bricks
fill 298 280 483 298 280 484 minecraft:red_nether_bricks
fill 298 280 485 298 280 487 minecraft:shroomlight
fill 298 280 488 298 280 489 minecraft:nether_bricks
fill 298 280 491 300 280 493 minecraft:red_nether_bricks
fill 298 280 495 300 280 497 minecraft:nether_bricks
fill 298 280 499 300 280 501 minecraft:red_nether_bricks
fill 298 280 503 300 280 504 minecraft:nether_bricks
setblock 299 280 483 minecraft:red_nether_bricks
fill 299 280 484 299 280 485 minecraft:shroomlight
fill 299 280 487 299 280 488 minecraft:shroomlight
setblock 299 280 489 minecraft:nether_bricks
fill 300 280 483 300 280 484 minecraft:shroomlight
fill 300 280 488 300 280 489 minecraft:shroomlight
fill 301 280 464 301 280 465 minecraft:polished_blackstone_bricks
fill 301 280 467 301 280 469 minecraft:polished_blackstone_bricks
fill 301 280 471 301 280 473 minecraft:polished_blackstone_bricks
fill 301 280 475 301 280 477 minecraft:polished_blackstone_bricks
fill 301 280 479 301 280 481 minecraft:polished_blackstone_bricks
fill 301 280 483 302 280 483 minecraft:shroomlight
fill 301 280 489 302 280 489 minecraft:shroomlight
fill 301 280 491 301 280 493 minecraft:polished_blackstone_bricks
fill 301 280 495 301 280 497 minecraft:polished_blackstone_bricks
fill 301 280 499 301 280 501 minecraft:polished_blackstone_bricks
fill 301 280 503 301 280 504 minecraft:polished_blackstone_bricks
fill 302 280 464 304 280 465 minecraft:red_nether_bricks
fill 302 280 467 304 280 469 minecraft:nether_bricks
fill 302 280 471 304 280 473 minecraft:red_nether_bricks
fill 302 280 475 304 280 477 minecraft:nether_bricks
fill 302 280 479 304 280 481 minecraft:red_nether_bricks
fill 302 280 484 303 280 484 minecraft:shroomlight
fill 302 280 488 303 280 488 minecraft:shroomlight
fill 302 280 491 304 280 493 minecraft:nether_bricks
fill 302 280 495 304 280 497 minecraft:red_nether_bricks
fill 302 280 499 304 280 501 minecraft:nether_bricks
fill 302 280 503 304 280 504 minecraft:red_nether_bricks
fill 303 280 483 304 280 483 minecraft:nether_bricks
fill 303 280 485 304 280 485 minecraft:shroomlight
fill 303 280 487 304 280 487 minecraft:shroomlight
fill 303 280 489 304 280 489 minecraft:red_nether_bricks
setblock 304 280 484 minecraft:nether_bricks
setblock 304 280 486 minecraft:shroomlight
setblock 304 280 488 minecraft:red_nether_bricks
fill 305 280 464 305 280 465 minecraft:polished_blackstone_bricks
fill 305 280 467 305 280 469 minecraft:polished_blackstone_bricks
fill 305 280 471 305 280 473 minecraft:polished_blackstone_bricks
fill 305 280 475 305 280 477 minecraft:polished_blackstone_bricks
fill 305 280 479 305 280 481 minecraft:polished_blackstone_bricks
fill 305 280 483 305 280 489 minecraft:polished_blackstone_bricks
fill 305 280 491 305 280 493 minecraft:polished_blackstone_bricks
fill 305 280 495 305 280 497 minecraft:polished_blackstone_bricks
fill 305 280 499 305 280 501 minecraft:polished_blackstone_bricks
fill 305 280 503 305 280 504 minecraft:polished_blackstone_bricks
fill 306 280 464 308 280 465 minecraft:nether_bricks
fill 306 280 467 308 280 469 minecraft:red_nether_bricks
fill 306 280 471 308 280 473 minecraft:nether_bricks
fill 306 280 475 308 280 477 minecraft:red_nether_bricks
fill 306 280 479 308 280 481 minecraft:nether_bricks
fill 306 280 483 308 280 485 minecraft:red_nether_bricks
fill 306 280 486 323 280 486 minecraft:polished_blackstone_bricks
fill 306 280 487 308 280 489 minecraft:nether_bricks
fill 306 280 491 308 280 493 minecraft:red_nether_bricks
fill 306 280 495 308 280 497 minecraft:nether_bricks
fill 306 280 499 308 280 501 minecraft:red_nether_bricks
fill 306 280 503 308 280 504 minecraft:nether_bricks
fill 309 280 464 309 280 465 minecraft:polished_blackstone_bricks
fill 309 280 467 309 280 469 minecraft:polished_blackstone_bricks
fill 309 280 471 309 280 473 minecraft:polished_blackstone_bricks
fill 309 280 475 309 280 477 minecraft:polished_blackstone_bricks
fill 309 280 479 309 280 481 minecraft:polished_blackstone_bricks
fill 309 280 483 309 280 485 minecraft:polished_blackstone_bricks
fill 309 280 487 309 280 489 minecraft:polished_blackstone_bricks
fill 309 280 491 309 280 493 minecraft:polished_blackstone_bricks
fill 309 280 495 309 280 497 minecraft:polished_blackstone_bricks
fill 309 280 499 309 280 501 minecraft:polished_blackstone_bricks
fill 309 280 503 309 280 504 minecraft:polished_blackstone_bricks
fill 310 280 464 312 280 465 minecraft:red_nether_bricks
fill 310 280 467 312 280 469 minecraft:nether_bricks
fill 310 280 471 312 280 473 minecraft:red_nether_bricks
fill 310 280 475 312 280 477 minecraft:nether_bricks
fill 310 280 479 312 280 481 minecraft:red_nether_bricks
fill 310 280 483 312 280 485 minecraft:nether_bricks
fill 310 280 487 312 280 489 minecraft:red_nether_bricks
fill 310 280 491 312 280 493 minecraft:nether_bricks
fill 310 280 495 312 280 497 minecraft:red_nether_bricks
fill 310 280 499 312 280 501 minecraft:nether_bricks
fill 310 280 503 312 280 504 minecraft:red_nether_bricks
fill 313 280 464 313 280 465 minecraft:polished_blackstone_bricks
fill 313 280 467 313 280 469 minecraft:polished_blackstone_bricks
fill 313 280 471 313 280 473 minecraft:polished_blackstone_bricks
fill 313 280 475 313 280 477 minecraft:polished_blackstone_bricks
fill 313 280 479 313 280 481 minecraft:polished_blackstone_bricks
fill 313 280 483 313 280 485 minecraft:polished_blackstone_bricks
fill 313 280 487 313 280 489 minecraft:polished_blackstone_bricks
fill 313 280 491 313 280 493 minecraft:polished_blackstone_bricks
fill 313 280 495 313 280 497 minecraft:polished_blackstone_bricks
fill 313 280 499 313 280 501 minecraft:polished_blackstone_bricks
fill 313 280 503 313 280 504 minecraft:polished_blackstone_bricks
fill 314 280 464 316 280 465 minecraft:nether_bricks
fill 314 280 467 316 280 469 minecraft:red_nether_bricks
fill 314 280 471 316 280 473 minecraft:nether_bricks
fill 314 280 475 316 280 477 minecraft:red_nether_bricks
fill 314 280 479 316 280 481 minecraft:nether_bricks
fill 314 280 483 316 280 485 minecraft:red_nether_bricks
fill 314 280 487 316 280 489 minecraft:nether_bricks
fill 314 280 491 316 280 493 minecraft:red_nether_bricks
fill 314 280 495 316 280 497 minecraft:nether_bricks
fill 314 280 499 316 280 501 minecraft:red_nether_bricks
fill 314 280 503 316 280 504 minecraft:nether_bricks
fill 317 280 464 317 280 465 minecraft:polished_blackstone_bricks
fill 317 280 467 317 280 469 minecraft:polished_blackstone_bricks
fill 317 280 471 317 280 473 minecraft:polished_blackstone_bricks
fill 317 280 475 317 280 477 minecraft:polished_blackstone_bricks
fill 317 280 479 317 280 481 minecraft:polished_blackstone_bricks
fill 317 280 483 317 280 485 minecraft:polished_blackstone_bricks
fill 317 280 487 317 280 489 minecraft:polished_blackstone_bricks
fill 317 280 491 317 280 493 minecraft:polished_blackstone_bricks
fill 317 280 495 317 280 497 minecraft:polished_blackstone_bricks
fill 317 280 499 317 280 501 minecraft:polished_blackstone_bricks
fill 317 280 503 317 280 504 minecraft:polished_blackstone_bricks
fill 318 280 464 320 280 465 minecraft:red_nether_bricks
fill 318 280 467 320 280 469 minecraft:nether_bricks
fill 318 280 471 320 280 473 minecraft:red_nether_bricks
fill 318 280 475 320 280 477 minecraft:nether_bricks
fill 318 280 479 320 280 481 minecraft:red_nether_bricks
fill 318 280 483 320 280 485 minecraft:nether_bricks
fill 318 280 487 320 280 489 minecraft:red_nether_bricks
fill 318 280 491 320 280 493 minecraft:nether_bricks
fill 318 280 495 320 280 497 minecraft:red_nether_bricks
fill 318 280 499 320 280 501 minecraft:nether_bricks
fill 318 280 503 320 280 504 minecraft:red_nether_bricks
fill 321 280 464 321 280 465 minecraft:polished_blackstone_bricks
fill 321 280 467 321 280 469 minecraft:polished_blackstone_bricks
fill 321 280 471 321 280 473 minecraft:polished_blackstone_bricks
fill 321 280 475 321 280 477 minecraft:polished_blackstone_bricks
fill 321 280 479 321 280 481 minecraft:polished_blackstone_bricks
fill 321 280 483 321 280 485 minecraft:polished_blackstone_bricks
fill 321 280 487 321 280 489 minecraft:polished_blackstone_bricks
fill 321 280 491 321 280 493 minecraft:polished_blackstone_bricks
fill 321 280 495 321 280 497 minecraft:polished_blackstone_bricks
fill 321 280 499 321 280 501 minecraft:polished_blackstone_bricks
fill 321 280 503 321 280 504 minecraft:polished_blackstone_bricks
fill 322 280 464 323 280 465 minecraft:nether_bricks
fill 322 280 467 323 280 469 minecraft:red_nether_bricks
fill 322 280 471 323 280 473 minecraft:nether_bricks
fill 322 280 475 323 280 477 minecraft:red_nether_bricks
fill 322 280 479 323 280 481 minecraft:nether_bricks
fill 322 280 483 323 280 485 minecraft:red_nether_bricks
fill 322 280 487 323 280 489 minecraft:nether_bricks
fill 322 280 491 323 280 493 minecraft:red_nether_bricks
fill 322 280 495 323 280 497 minecraft:nether_bricks
fill 322 280 499 323 280 501 minecraft:red_nether_bricks
fill 322 280 503 323 280 504 minecraft:nether_bricks
fill 283 284 464 285 300 464 minecraft:polished_blackstone_bricks
fill 283 284 474 283 300 476 minecraft:polished_blackstone_bricks
fill 283 284 486 283 300 488 minecraft:polished_blackstone_bricks
fill 283 284 498 283 300 500 minecraft:polished_blackstone_bricks
fill 284 284 473 284 285 475 minecraft:polished_blackstone_bricks
fill 284 284 485 284 285 487 minecraft:polished_blackstone_bricks
fill 284 284 497 284 285 499 minecraft:polished_blackstone_bricks
fill 287 284 496 295 284 504 minecraft:polished_blackstone_bricks
fill 294 284 465 296 285 465 minecraft:polished_blackstone_bricks
fill 295 284 464 297 300 464 minecraft:polished_blackstone_bricks
fill 296 284 499 299 284 504 minecraft:polished_blackstone_bricks
fill 301 284 504 303 300 504 minecraft:polished_blackstone_bricks
fill 302 284 503 304 285 503 minecraft:polished_blackstone_bricks
fill 306 284 465 322 285 465 minecraft:polished_blackstone_bricks
fill 307 284 464 322 284 464 minecraft:polished_blackstone_bricks
fill 308 284 466 322 285 468 minecraft:polished_blackstone_bricks
fill 313 284 504 315 300 504 minecraft:polished_blackstone_bricks
fill 314 284 469 322 285 470 minecraft:polished_blackstone_bricks
fill 314 284 503 316 285 503 minecraft:polished_blackstone_bricks
fill 319 284 471 319 298 471 minecraft:gilded_blackstone
fill 322 284 473 322 285 475 minecraft:polished_blackstone_bricks
fill 322 284 485 322 285 487 minecraft:polished_blackstone_bricks
fill 322 284 497 322 285 499 minecraft:polished_blackstone_bricks
fill 323 284 472 323 300 474 minecraft:polished_blackstone_bricks
fill 323 284 484 323 300 486 minecraft:polished_blackstone_bricks
fill 323 284 496 323 300 498 minecraft:polished_blackstone_bricks
fill 283 285 467 283 285 472 minecraft:nether_bricks
fill 283 285 479 283 285 484 minecraft:nether_bricks
fill 283 285 491 283 285 496 minecraft:nether_bricks
fill 283 285 503 283 285 504 minecraft:nether_bricks
fill 284 285 504 287 285 504 minecraft:nether_bricks
fill 287 285 464 292 285 464 minecraft:nether_bricks
fill 287 285 496 295 285 503 minecraft:polished_blackstone_bricks
fill 288 285 504 293 285 504 minecraft:polished_blackstone_bricks
fill 294 285 504 299 285 504 minecraft:nether_bricks
fill 296 285 499 299 285 503 minecraft:polished_blackstone_bricks
fill 299 285 464 304 285 464 minecraft:nether_bricks
fill 306 285 504 311 285 504 minecraft:nether_bricks
fill 307 285 464 310 285 464 minecraft:polished_blackstone_bricks
fill 311 285 464 316 285 464 minecraft:nether_bricks
fill 317 285 464 322 285 464 minecraft:polished_blackstone_bricks
fill 318 285 504 323 285 504 minecraft:nether_bricks
fill 323 285 464 323 285 469 minecraft:nether_bricks
fill 323 285 476 323 285 481 minecraft:nether_bricks
fill 323 285 488 323 285 493 minecraft:nether_bricks
fill 323 285 500 323 285 503 minecraft:nether_bricks
fill 282 286 469 282 291 472 minecraft:shroomlight
fill 282 286 481 282 291 484 minecraft:shroomlight
fill 282 286 493 282 291 496 minecraft:shroomlight
fill 282 286 505 285 291 505 minecraft:shroomlight
fill 287 286 496 287 299 499 minecraft:polished_blackstone_bricks
setblock 287 286 500 minecraft:shroomlight
fill 287 286 501 287 299 501 minecraft:polished_blackstone_bricks
setblock 287 286 502 minecraft:shroomlight
fill 287 286 503 287 299 503 minecraft:polished_blackstone_bricks
setblock 287 286 504 minecraft:shroomlight
fill 288 286 496 295 299 498 minecraft:polished_blackstone_bricks
setblock 288 286 499 minecraft:shroomlight
fill 288 286 500 288 296 500 minecraft:polished_blackstone_bricks
setblock 288 286 501 minecraft:shroomlight
fill 288 286 502 288 296 502 minecraft:polished_blackstone_bricks
setblock 288 286 503 minecraft:shroomlight
fill 288 286 504 288 299 504 minecraft:polished_blackstone_bricks
fill 289 286 463 292 291 463 minecraft:shroomlight
fill 289 286 499 289 299 499 minecraft:polished_blackstone_bricks
setblock 289 286 500 minecraft:shroomlight
fill 289 286 501 289 296 501 minecraft:polished_blackstone_bricks
setblock 289 286 502 minecraft:shroomlight
fill 289 286 503 289 296 503 minecraft:polished_blackstone_bricks
setblock 289 286 504 minecraft:shroomlight
setblock 290 286 499 minecraft:shroomlight
fill 290 286 500 290 296 500 minecraft:polished_blackstone_bricks
setblock 290 286 501 minecraft:shroomlight
fill 290 286 502 290 296 502 minecraft:polished_blackstone_bricks
setblock 290 286 503 minecraft:shroomlight
fill 290 286 504 290 300 504 minecraft:polished_blackstone_bricks
fill 291 286 499 291 299 499 minecraft:polished_blackstone_bricks
setblock 291 286 500 minecraft:shroomlight
fill 291 286 501 291 296 501 minecraft:polished_blackstone_bricks
setblock 291 286 502 minecraft:shroomlight
fill 291 286 503 291 296 503 minecraft:polished_blackstone_bricks
setblock 291 286 504 minecraft:shroomlight
setblock 292 286 499 minecraft:shroomlight
fill 292 286 500 292 296 500 minecraft:polished_blackstone_bricks
setblock 292 286 501 minecraft:shroomlight
fill 292 286 502 292 296 502 minecraft:polished_blackstone_bricks
setblock 292 286 503 minecraft:shroomlight
fill 292 286 504 292 299 504 minecraft:polished_blackstone_bricks
fill 293 286 499 293 299 499 minecraft:polished_blackstone_bricks
setblock 293 286 500 minecraft:shroomlight
fill 293 286 501 293 296 501 minecraft:polished_blackstone_bricks
setblock 293 286 502 minecraft:shroomlight
fill 293 286 503 293 296 503 minecraft:polished_blackstone_bricks
setblock 293 286 504 minecraft:shroomlight
setblock 294 286 499 minecraft:shroomlight
fill 294 286 500 294 296 500 minecraft:polished_blackstone_bricks
setblock 294 286 501 minecraft:shroomlight
fill 294 286 502 294 296 502 minecraft:polished_blackstone_bricks
setblock 294 286 503 minecraft:shroomlight
fill 294 286 504 294 299 504 minecraft:polished_blackstone_bricks
fill 294 286 505 297 291 505 minecraft:shroomlight
fill 295 286 499 295 299 499 minecraft:polished_blackstone_bricks
setblock 295 286 500 minecraft:shroomlight
fill 295 286 501 295 296 501 minecraft:polished_blackstone_bricks
setblock 295 286 502 minecraft:shroomlight
fill 295 286 503 295 296 503 minecraft:polished_blackstone_bricks
setblock 295 286 504 minecraft:shroomlight
setblock 296 286 499 minecraft:shroomlight
fill 296 286 500 296 296 500 minecraft:polished_blackstone_bricks
setblock 296 286 501 minecraft:shroomlight
fill 296 286 502 296 296 502 minecraft:polished_blackstone_bricks
setblock 296 286 503 minecraft:shroomlight
fill 296 286 504 296 296 504 minecraft:polished_blackstone_bricks
fill 297 286 499 297 296 499 minecraft:polished_blackstone_bricks
setblock 297 286 500 minecraft:shroomlight
fill 297 286 501 297 296 501 minecraft:polished_blackstone_bricks
setblock 297 286 502 minecraft:shroomlight
fill 297 286 503 297 296 503 minecraft:polished_blackstone_bricks
setblock 297 286 504 minecraft:shroomlight
setblock 298 286 499 minecraft:shroomlight
fill 298 286 500 298 296 500 minecraft:polished_blackstone_bricks
setblock 298 286 501 minecraft:shroomlight
fill 298 286 502 298 296 502 minecraft:polished_blackstone_bricks
setblock 298 286 503 minecraft:shroomlight
fill 298 286 504 298 296 504 minecraft:polished_blackstone_bricks
fill 299 286 499 299 296 499 minecraft:polished_blackstone_bricks
setblock 299 286 500 minecraft:shroomlight
fill 299 286 501 299 296 501 minecraft:polished_blackstone_bricks
setblock 299 286 502 minecraft:shroomlight
fill 299 286 503 299 296 503 minecraft:polished_blackstone_bricks
setblock 299 286 504 minecraft:shroomlight
fill 301 286 463 304 291 463 minecraft:shroomlight
fill 306 286 505 309 291 505 minecraft:shroomlight
fill 307 286 464 308 300 464 minecraft:polished_blackstone_bricks
setblock 308 286 465 minecraft:shroomlight
fill 308 286 466 308 300 466 minecraft:polished_blackstone_bricks
setblock 308 286 467 minecraft:shroomlight
fill 308 286 468 308 300 468 minecraft:polished_blackstone_bricks
setblock 309 286 464 minecraft:shroomlight
fill 309 286 465 309 300 465 minecraft:polished_blackstone_bricks
setblock 309 286 466 minecraft:shroomlight
fill 309 286 467 309 300 467 minecraft:polished_blackstone_bricks
setblock 309 286 468 minecraft:shroomlight
fill 310 286 464 310 300 464 minecraft:polished_blackstone_bricks
setblock 310 286 465 minecraft:shroomlight
fill 310 286 466 310 300 466 minecraft:polished_blackstone_bricks
setblock 310 286 467 minecraft:shroomlight
fill 310 286 468 310 300 468 minecraft:polished_blackstone_bricks
setblock 311 286 464 minecraft:shroomlight
fill 311 286 465 311 300 465 minecraft:polished_blackstone_bricks
setblock 311 286 466 minecraft:shroomlight
fill 311 286 467 311 300 467 minecraft:polished_blackstone_bricks
setblock 311 286 468 minecraft:shroomlight
fill 312 286 464 312 300 464 minecraft:polished_blackstone_bricks
setblock 312 286 465 minecraft:shroomlight
fill 312 286 466 312 300 466 minecraft:polished_blackstone_bricks
setblock 312 286 467 minecraft:shroomlight
fill 312 286 468 312 300 468 minecraft:polished_blackstone_bricks
fill 313 286 463 313 286 464 minecraft:shroomlight
fill 313 286 465 313 300 465 minecraft:polished_blackstone_bricks
setblock 313 286 466 minecraft:shroomlight
fill 313 286 467 313 300 467 minecraft:polished_blackstone_bricks
setblock 313 286 468 minecraft:shroomlight
fill 314 286 463 316 291 463 minecraft:shroomlight
fill 314 286 464 314 300 464 minecraft:polished_blackstone_bricks
setblock 314 286 465 minecraft:shroomlight
fill 314 286 466 314 300 466 minecraft:polished_blackstone_bricks
setblock 314 286 467 minecraft:shroomlight
fill 314 286 468 314 300 468 minecraft:polished_blackstone_bricks
setblock 314 286 469 minecraft:shroomlight
fill 314 286 470 314 300 470 minecraft:polished_blackstone_bricks
setblock 315 286 464 minecraft:shroomlight
fill 315 286 465 315 300 465 minecraft:polished_blackstone_bricks
setblock 315 286 466 minecraft:shroomlight
fill 315 286 467 315 300 467 minecraft:polished_blackstone_bricks
setblock 315 286 468 minecraft:shroomlight
fill 315 286 469 315 300 469 minecraft:polished_blackstone_bricks
setblock 315 286 470 minecraft:shroomlight
fill 316 286 464 316 300 464 minecraft:polished_blackstone_bricks
setblock 316 286 465 minecraft:shroomlight
fill 316 286 466 316 300 466 minecraft:polished_blackstone_bricks
setblock 316 286 467 minecraft:shroomlight
fill 316 286 468 316 300 468 minecraft:polished_blackstone_bricks
setblock 316 286 469 minecraft:shroomlight
fill 316 286 470 316 300 470 minecraft:polished_blackstone_bricks
setblock 317 286 464 minecraft:shroomlight
fill 317 286 465 317 300 465 minecraft:polished_blackstone_bricks
setblock 317 286 466 minecraft:shroomlight
fill 317 286 467 317 300 467 minecraft:polished_blackstone_bricks
setblock 317 286 468 minecraft:shroomlight
fill 317 286 469 317 300 469 minecraft:polished_blackstone_bricks
setblock 317 286 470 minecraft:shroomlight
fill 318 286 464 318 300 464 minecraft:polished_blackstone_bricks
setblock 318 286 465 minecraft:shroomlight
fill 318 286 466 318 300 466 minecraft:polished_blackstone_bricks
setblock 318 286 467 minecraft:shroomlight
fill 318 286 468 318 300 468 minecraft:polished_blackstone_bricks
setblock 318 286 469 minecraft:shroomlight
fill 318 286 470 318 300 470 minecraft:polished_blackstone_bricks
fill 318 286 505 321 291 505 minecraft:shroomlight
setblock 319 286 464 minecraft:shroomlight
fill 319 286 465 319 300 465 minecraft:polished_blackstone_bricks
setblock 319 286 466 minecraft:shroomlight
fill 319 286 467 319 300 467 minecraft:polished_blackstone_bricks
setblock 319 286 468 minecraft:shroomlight
fill 319 286 469 319 300 469 minecraft:polished_blackstone_bricks
setblock 319 286 470 minecraft:shroomlight
fill 320 286 464 320 300 464 minecraft:polished_blackstone_bricks
setblock 320 286 465 minecraft:shroomlight
fill 320 286 466 320 300 466 minecraft:polished_blackstone_bricks
setblock 320 286 467 minecraft:shroomlight
fill 320 286 468 320 300 468 minecraft:polished_blackstone_bricks
setblock 320 286 469 minecraft:shroomlight
fill 320 286 470 320 300 470 minecraft:polished_blackstone_bricks
setblock 321 286 464 minecraft:shroomlight
fill 321 286 465 321 300 465 minecraft:polished_blackstone_bricks
setblock 321 286 466 minecraft:shroomlight
fill 321 286 467 321 300 467 minecraft:polished_blackstone_bricks
setblock 321 286 468 minecraft:shroomlight
fill 321 286 469 321 300 469 minecraft:polished_blackstone_bricks
setblock 321 286 470 minecraft:shroomlight
fill 322 286 464 322 300 464 minecraft:polished_blackstone_bricks
setblock 322 286 465 minecraft:shroomlight
fill 322 286 466 322 300 466 minecraft:polished_blackstone_bricks
setblock 322 286 467 minecraft:shroomlight
fill 322 286 468 322 300 468 minecraft:polished_blackstone_bricks
setblock 322 286 469 minecraft:shroomlight
fill 322 286 470 322 300 470 minecraft:polished_blackstone_bricks
fill 324 286 464 324 291 467 minecraft:shroomlight
fill 324 286 476 324 291 479 minecraft:shroomlight
fill 324 286 488 324 291 491 minecraft:shroomlight
fill 324 286 500 324 291 503 minecraft:shroomlight
setblock 285 287 466 minecraft:light[level=14]
setblock 285 287 474 minecraft:light[level=14]
setblock 285 287 482 minecraft:light[level=14]
setblock 285 287 490 minecraft:light[level=14]
setblock 285 287 498 minecraft:light[level=14]
fill 287 287 500 287 288 500 minecraft:polished_blackstone_bricks
fill 287 287 502 287 288 502 minecraft:polished_blackstone_bricks
fill 287 287 504 287 288 504 minecraft:polished_blackstone_bricks
fill 288 287 499 288 288 499 minecraft:polished_blackstone_bricks
fill 288 287 501 288 288 501 minecraft:polished_blackstone_bricks
fill 288 287 503 288 288 503 minecraft:polished_blackstone_bricks
fill 289 287 500 289 288 500 minecraft:polished_blackstone_bricks
fill 289 287 502 289 288 502 minecraft:polished_blackstone_bricks
fill 289 287 504 289 288 504 minecraft:polished_blackstone_bricks
fill 290 287 499 290 288 499 minecraft:polished_blackstone_bricks
fill 290 287 501 290 288 501 minecraft:polished_blackstone_bricks
fill 290 287 503 290 288 503 minecraft:polished_blackstone_bricks
schedule function dropper:buildpart/114_3 1t
