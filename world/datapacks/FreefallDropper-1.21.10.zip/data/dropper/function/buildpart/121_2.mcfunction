fill 87 160 544 87 165 546 minecraft:polished_blackstone_bricks
setblock 50 163 513 minecraft:light[level=11]
setblock 50 163 521 minecraft:light[level=11]
setblock 50 163 529 minecraft:light[level=11]
setblock 50 163 537 minecraft:light[level=11]
setblock 50 163 545 minecraft:light[level=11]
setblock 58 163 513 minecraft:light[level=11]
setblock 58 163 521 minecraft:light[level=11]
setblock 58 163 529 minecraft:light[level=11]
setblock 58 163 537 minecraft:light[level=11]
setblock 58 163 545 minecraft:light[level=11]
setblock 66 163 513 minecraft:light[level=11]
setblock 66 163 521 minecraft:light[level=11]
setblock 66 163 529 minecraft:light[level=11]
setblock 66 163 537 minecraft:light[level=11]
setblock 66 163 545 minecraft:light[level=11]
setblock 74 163 513 minecraft:light[level=11]
setblock 74 163 521 minecraft:light[level=11]
setblock 74 163 529 minecraft:light[level=11]
setblock 74 163 537 minecraft:light[level=11]
setblock 74 163 545 minecraft:light[level=11]
fill 81 163 527 85 164 531 minecraft:blackstone
setblock 82 163 513 minecraft:light[level=11]
setblock 82 163 521 minecraft:light[level=11]
setblock 82 163 537 minecraft:light[level=11]
setblock 82 163 545 minecraft:light[level=11]
fill 86 163 529 87 163 529 minecraft:blackstone
fill 48 165 514 48 165 519 minecraft:blackstone
fill 48 165 526 48 165 531 minecraft:blackstone
fill 48 165 538 48 165 543 minecraft:blackstone
fill 48 165 550 48 165 551 minecraft:blackstone
fill 49 165 551 52 165 551 minecraft:blackstone
fill 52 165 511 57 165 511 minecraft:blackstone
fill 59 165 551 64 165 551 minecraft:blackstone
fill 64 165 511 69 165 511 minecraft:blackstone
fill 71 165 551 76 165 551 minecraft:blackstone
fill 76 165 511 81 165 511 minecraft:blackstone
fill 82 165 529 84 172 529 minecraft:purple_stained_glass
fill 83 165 528 83 172 528 minecraft:purple_stained_glass
fill 83 165 530 83 172 530 minecraft:purple_stained_glass
fill 83 165 551 88 165 551 minecraft:blackstone
fill 88 165 511 88 165 516 minecraft:blackstone
fill 88 165 523 88 165 528 minecraft:blackstone
fill 88 165 535 88 165 540 minecraft:blackstone
fill 88 165 547 88 165 550 minecraft:blackstone
fill 47 166 516 47 171 519 minecraft:crying_obsidian
fill 47 166 528 47 171 531 minecraft:crying_obsidian
fill 47 166 540 47 171 543 minecraft:crying_obsidian
fill 47 166 552 50 171 552 minecraft:crying_obsidian
fill 54 166 510 57 171 510 minecraft:crying_obsidian
fill 59 166 552 62 171 552 minecraft:crying_obsidian
fill 66 166 510 69 171 510 minecraft:crying_obsidian
fill 71 166 552 74 171 552 minecraft:crying_obsidian
fill 78 166 510 81 171 510 minecraft:crying_obsidian
fill 83 166 552 86 171 552 minecraft:crying_obsidian
fill 89 166 511 89 171 514 minecraft:crying_obsidian
fill 89 166 523 89 171 526 minecraft:crying_obsidian
fill 89 166 535 89 171 538 minecraft:crying_obsidian
fill 89 166 547 89 171 550 minecraft:crying_obsidian
fill 48 167 524 48 168 526 minecraft:polished_blackstone_bricks
fill 87 167 524 88 168 526 minecraft:polished_blackstone_bricks
fill 49 168 524 49 169 526 minecraft:polished_blackstone_bricks
fill 50 168 525 50 171 525 minecraft:polished_blackstone_bricks
fill 85 168 525 86 170 525 minecraft:polished_blackstone_bricks
fill 86 168 524 86 169 524 minecraft:polished_blackstone_bricks
fill 86 168 526 86 169 526 minecraft:polished_blackstone_bricks
setblock 48 169 525 minecraft:polished_blackstone_bricks
fill 50 169 524 50 170 524 minecraft:polished_blackstone_bricks
fill 50 169 526 50 170 526 minecraft:polished_blackstone_bricks
fill 51 169 525 51 171 525 minecraft:polished_blackstone_bricks
setblock 69 169 546 minecraft:crying_obsidian
fill 84 169 525 84 171 525 minecraft:polished_blackstone_bricks
fill 85 169 524 85 170 524 minecraft:polished_blackstone_bricks
fill 85 169 526 85 170 526 minecraft:polished_blackstone_bricks
setblock 87 169 525 minecraft:polished_blackstone_bricks
setblock 88 169 525 minecraft:purple_stained_glass
setblock 48 170 525 minecraft:purple_stained_glass
setblock 49 170 525 minecraft:polished_blackstone_bricks
fill 51 170 524 52 171 524 minecraft:polished_blackstone_bricks
fill 51 170 526 52 171 526 minecraft:polished_blackstone_bricks
fill 52 170 525 52 172 525 minecraft:polished_blackstone_bricks
fill 83 170 524 83 171 526 minecraft:polished_blackstone_bricks
fill 84 170 524 84 171 524 minecraft:polished_blackstone_bricks
fill 84 170 526 84 171 526 minecraft:polished_blackstone_bricks
setblock 87 170 525 minecraft:purple_stained_glass
setblock 49 171 525 minecraft:purple_stained_glass
setblock 50 171 513 minecraft:light[level=11]
setblock 50 171 521 minecraft:light[level=11]
setblock 50 171 529 minecraft:light[level=11]
setblock 50 171 537 minecraft:light[level=11]
setblock 50 171 545 minecraft:light[level=11]
fill 53 171 524 53 172 526 minecraft:polished_blackstone_bricks
fill 54 171 525 54 172 525 minecraft:polished_blackstone_bricks
setblock 58 171 513 minecraft:light[level=11]
setblock 58 171 521 minecraft:light[level=11]
setblock 58 171 529 minecraft:light[level=11]
setblock 58 171 537 minecraft:light[level=11]
setblock 58 171 545 minecraft:light[level=11]
setblock 66 171 513 minecraft:light[level=11]
setblock 66 171 521 minecraft:light[level=11]
setblock 66 171 529 minecraft:light[level=11]
setblock 66 171 537 minecraft:light[level=11]
setblock 66 171 545 minecraft:light[level=11]
setblock 74 171 513 minecraft:light[level=11]
setblock 74 171 521 minecraft:light[level=11]
setblock 74 171 529 minecraft:light[level=11]
setblock 74 171 537 minecraft:light[level=11]
setblock 74 171 545 minecraft:light[level=11]
fill 81 171 525 82 172 525 minecraft:polished_blackstone_bricks
setblock 82 171 513 minecraft:light[level=11]
setblock 82 171 521 minecraft:light[level=11]
fill 82 171 524 82 172 524 minecraft:polished_blackstone_bricks
fill 82 171 526 82 172 526 minecraft:polished_blackstone_bricks
setblock 82 171 537 minecraft:light[level=11]
setblock 82 171 545 minecraft:light[level=11]
setblock 85 171 525 minecraft:polished_blackstone_bricks
setblock 86 171 525 minecraft:purple_stained_glass
fill 47 172 516 47 185 516 minecraft:polished_blackstone_bricks
fill 47 172 517 47 172 518 minecraft:crying_obsidian
fill 47 172 519 47 185 519 minecraft:polished_blackstone_bricks
fill 47 172 528 47 185 528 minecraft:polished_blackstone_bricks
fill 47 172 529 47 172 530 minecraft:crying_obsidian
fill 47 172 531 47 185 531 minecraft:polished_blackstone_bricks
fill 47 172 540 47 185 540 minecraft:polished_blackstone_bricks
fill 47 172 541 47 172 542 minecraft:crying_obsidian
fill 47 172 543 47 185 543 minecraft:polished_blackstone_bricks
fill 47 172 552 47 185 552 minecraft:polished_blackstone_bricks
fill 48 172 552 49 172 552 minecraft:crying_obsidian
fill 50 172 552 50 185 552 minecraft:polished_blackstone_bricks
setblock 51 172 525 minecraft:purple_stained_glass
fill 54 172 510 54 185 510 minecraft:polished_blackstone_bricks
setblock 54 172 524 minecraft:polished_blackstone_bricks
setblock 54 172 526 minecraft:polished_blackstone_bricks
fill 55 172 510 56 172 510 minecraft:crying_obsidian
setblock 55 172 525 minecraft:polished_blackstone_bricks
fill 57 172 510 57 185 510 minecraft:polished_blackstone_bricks
fill 59 172 552 59 185 552 minecraft:polished_blackstone_bricks
fill 60 172 552 61 172 552 minecraft:crying_obsidian
fill 62 172 552 62 185 552 minecraft:polished_blackstone_bricks
fill 66 172 510 66 185 510 minecraft:polished_blackstone_bricks
fill 67 172 510 68 172 510 minecraft:crying_obsidian
fill 69 172 510 69 185 510 minecraft:polished_blackstone_bricks
fill 71 172 552 71 185 552 minecraft:polished_blackstone_bricks
fill 72 172 552 73 172 552 minecraft:crying_obsidian
fill 74 172 552 74 185 552 minecraft:polished_blackstone_bricks
fill 78 172 510 78 185 510 minecraft:polished_blackstone_bricks
fill 79 172 510 80 172 510 minecraft:crying_obsidian
setblock 80 172 525 minecraft:polished_blackstone_bricks
fill 81 172 510 81 185 510 minecraft:polished_blackstone_bricks
setblock 81 172 524 minecraft:polished_blackstone_bricks
setblock 81 172 526 minecraft:polished_blackstone_bricks
setblock 83 172 525 minecraft:polished_blackstone_bricks
fill 83 172 552 83 185 552 minecraft:polished_blackstone_bricks
setblock 84 172 525 minecraft:purple_stained_glass
fill 84 172 552 85 172 552 minecraft:crying_obsidian
fill 86 172 552 86 185 552 minecraft:polished_blackstone_bricks
fill 89 172 511 89 185 511 minecraft:polished_blackstone_bricks
fill 89 172 512 89 172 513 minecraft:crying_obsidian
fill 89 172 514 89 185 514 minecraft:polished_blackstone_bricks
fill 89 172 523 89 185 523 minecraft:polished_blackstone_bricks
fill 89 172 524 89 172 525 minecraft:crying_obsidian
fill 89 172 526 89 185 526 minecraft:polished_blackstone_bricks
fill 89 172 535 89 185 535 minecraft:polished_blackstone_bricks
fill 89 172 536 89 172 537 minecraft:crying_obsidian
fill 89 172 538 89 185 538 minecraft:polished_blackstone_bricks
fill 89 172 547 89 185 547 minecraft:polished_blackstone_bricks
fill 89 172 548 89 172 549 minecraft:crying_obsidian
fill 89 172 550 89 185 550 minecraft:polished_blackstone_bricks
fill 47 173 517 47 185 518 minecraft:polished_blackstone_bricks
fill 47 173 529 47 185 530 minecraft:polished_blackstone_bricks
fill 47 173 541 47 185 542 minecraft:polished_blackstone_bricks
fill 48 173 552 49 185 552 minecraft:polished_blackstone_bricks
fill 55 173 510 56 185 510 minecraft:polished_blackstone_bricks
fill 60 173 552 61 185 552 minecraft:polished_blackstone_bricks
fill 67 173 510 68 185 510 minecraft:polished_blackstone_bricks
fill 72 173 552 73 185 552 minecraft:polished_blackstone_bricks
fill 79 173 510 80 185 510 minecraft:polished_blackstone_bricks
fill 84 173 510 86 210 510 minecraft:polished_blackstone_bricks
fill 84 173 552 85 185 552 minecraft:polished_blackstone_bricks
fill 89 173 512 89 185 513 minecraft:polished_blackstone_bricks
fill 89 173 520 89 213 520 minecraft:polished_blackstone_bricks
fill 89 173 524 89 185 525 minecraft:polished_blackstone_bricks
fill 89 173 531 89 209 533 minecraft:polished_blackstone_bricks
fill 89 173 536 89 185 537 minecraft:polished_blackstone_bricks
fill 89 173 543 89 211 545 minecraft:polished_blackstone_bricks
fill 89 173 548 89 185 549 minecraft:polished_blackstone_bricks
fill 63 177 531 65 177 533 minecraft:redstone_block
fill 64 177 524 66 177 526 minecraft:redstone_block
fill 70 177 524 72 177 526 minecraft:redstone_block
fill 70 177 532 72 177 534 minecraft:redstone_block
fill 50 178 526 62 178 532 minecraft:polished_blackstone
fill 63 178 526 63 178 530 minecraft:polished_blackstone
fill 64 178 527 66 178 530 minecraft:polished_blackstone
fill 65 178 511 71 178 523 minecraft:polished_blackstone
fill 65 178 534 69 178 547 minecraft:polished_blackstone
fill 66 178 531 69 178 533 minecraft:polished_blackstone
fill 67 178 524 69 178 527 minecraft:polished_blackstone
fill 70 178 527 86 178 531 minecraft:polished_blackstone
fill 70 178 535 71 178 547 minecraft:polished_blackstone
fill 73 178 526 86 178 526 minecraft:polished_blackstone
fill 73 178 532 86 178 532 minecraft:polished_blackstone
fill 48 179 511 49 179 551 minecraft:blackstone
fill 50 179 511 62 179 525 minecraft:blackstone
fill 50 179 526 62 179 526 minecraft:gold_block
fill 50 179 527 61 179 531 minecraft:polished_blackstone
fill 50 179 532 61 179 532 minecraft:gold_block
fill 50 179 533 61 179 551 minecraft:blackstone
fill 62 179 527 62 179 529 minecraft:polished_blackstone
fill 62 179 530 62 179 534 minecraft:crying_obsidian
fill 62 179 535 64 179 551 minecraft:blackstone
fill 63 179 511 64 179 522 minecraft:blackstone
fill 63 179 523 63 179 527 minecraft:crying_obsidian
fill 63 179 528 64 179 529 minecraft:polished_blackstone
fill 63 179 530 66 179 530 minecraft:crying_obsidian
fill 63 179 531 65 179 533 minecraft:blackstone
fill 63 179 534 66 179 534 minecraft:crying_obsidian
fill 64 179 523 67 179 523 minecraft:crying_obsidian
fill 64 179 524 66 179 526 minecraft:blackstone
fill 64 179 527 73 179 527 minecraft:crying_obsidian
fill 65 179 511 65 179 522 minecraft:gold_block
fill 65 179 528 65 179 529 minecraft:gold_block
fill 65 179 535 65 179 547 minecraft:gold_block
fill 65 179 548 88 179 551 minecraft:blackstone
fill 66 179 511 70 179 522 minecraft:polished_blackstone
fill 66 179 528 66 179 529 minecraft:crying_obsidian
fill 66 179 531 66 179 533 minecraft:crying_obsidian
fill 66 179 535 68 179 547 minecraft:polished_blackstone
fill 67 179 524 67 179 526 minecraft:crying_obsidian
fill 67 179 531 73 179 531 minecraft:crying_obsidian
fill 67 179 532 68 179 532 minecraft:gold_block
fill 67 179 533 68 179 534 minecraft:polished_blackstone
fill 68 179 523 68 179 525 minecraft:polished_blackstone
setblock 68 179 526 minecraft:gold_block
fill 69 179 523 69 179 526 minecraft:crying_obsidian
fill 69 179 532 69 179 535 minecraft:crying_obsidian
fill 69 179 536 70 179 547 minecraft:polished_blackstone
fill 70 179 523 73 179 523 minecraft:crying_obsidian
fill 70 179 524 72 179 526 minecraft:blackstone
fill 70 179 528 70 179 530 minecraft:crying_obsidian
fill 70 179 532 72 179 534 minecraft:blackstone
fill 70 179 535 73 179 535 minecraft:crying_obsidian
fill 71 179 511 71 179 522 minecraft:gold_block
fill 71 179 528 71 179 530 minecraft:gold_block
fill 71 179 536 71 179 547 minecraft:gold_block
fill 72 179 511 88 179 522 minecraft:blackstone
fill 72 179 528 86 179 530 minecraft:polished_blackstone
fill 72 179 536 88 179 547 minecraft:blackstone
fill 73 179 524 73 179 526 minecraft:crying_obsidian
fill 73 179 532 73 179 534 minecraft:crying_obsidian
fill 74 179 523 88 179 525 minecraft:blackstone
fill 74 179 526 86 179 526 minecraft:gold_block
fill 74 179 527 86 179 527 minecraft:polished_blackstone
fill 74 179 531 86 179 531 minecraft:polished_blackstone
fill 74 179 532 86 179 532 minecraft:gold_block
fill 74 179 533 88 179 535 minecraft:blackstone
fill 87 179 526 88 179 532 minecraft:blackstone
fill 48 183 511 50 229 511 minecraft:polished_blackstone_bricks
fill 48 183 521 48 229 523 minecraft:polished_blackstone_bricks
fill 48 183 533 48 229 535 minecraft:polished_blackstone_bricks
fill 48 183 545 48 229 547 minecraft:polished_blackstone_bricks
fill 49 183 520 49 185 522 minecraft:polished_blackstone_bricks
fill 49 183 532 49 185 534 minecraft:polished_blackstone_bricks
fill 49 183 544 49 185 546 minecraft:polished_blackstone_bricks
fill 54 183 551 56 229 551 minecraft:polished_blackstone_bricks
fill 55 183 550 57 185 550 minecraft:polished_blackstone_bricks
fill 57 183 526 57 186 532 minecraft:iron_block
fill 58 183 524 58 186 525 minecraft:iron_block
fill 58 183 533 58 186 534 minecraft:iron_block
fill 59 183 512 61 185 512 minecraft:polished_blackstone_bricks
fill 59 183 522 59 186 523 minecraft:iron_block
fill 59 183 535 59 186 536 minecraft:iron_block
fill 60 183 511 62 229 511 minecraft:polished_blackstone_bricks
fill 60 183 521 60 183 522 minecraft:iron_block
fill 60 183 536 60 183 537 minecraft:iron_block
fill 61 183 520 61 186 521 minecraft:iron_block
fill 61 183 537 61 186 538 minecraft:iron_block
fill 62 183 520 62 186 520 minecraft:iron_block
fill 62 183 538 62 186 538 minecraft:iron_block
fill 63 183 519 64 186 519 minecraft:iron_block
fill 63 183 539 64 186 539 minecraft:iron_block
fill 65 183 518 71 186 518 minecraft:iron_block
fill 65 183 540 71 186 540 minecraft:iron_block
fill 66 183 551 68 229 551 minecraft:polished_blackstone_bricks
fill 67 183 550 69 185 550 minecraft:polished_blackstone_bricks
fill 71 183 512 73 185 512 minecraft:polished_blackstone_bricks
fill 72 183 511 74 229 511 minecraft:polished_blackstone_bricks
fill 72 183 519 73 186 519 minecraft:iron_block
fill 72 183 539 73 186 539 minecraft:iron_block
fill 74 183 520 75 186 520 minecraft:iron_block
fill 74 183 538 75 186 538 minecraft:iron_block
fill 75 183 521 76 183 521 minecraft:iron_block
fill 75 183 537 76 183 537 minecraft:iron_block
fill 76 183 522 77 186 522 minecraft:iron_block
fill 76 183 536 77 186 536 minecraft:iron_block
fill 77 183 523 77 186 523 minecraft:iron_block
fill 77 183 535 77 186 535 minecraft:iron_block
fill 78 183 524 78 186 525 minecraft:iron_block
fill 78 183 533 78 186 534 minecraft:iron_block
fill 78 183 551 80 229 551 minecraft:polished_blackstone_bricks
fill 79 183 526 79 186 532 minecraft:iron_block
fill 79 183 550 81 185 550 minecraft:polished_blackstone_bricks
fill 83 183 512 85 185 512 minecraft:polished_blackstone_bricks
fill 84 183 511 86 229 511 minecraft:polished_blackstone_bricks
fill 87 183 520 87 185 522 minecraft:polished_blackstone_bricks
fill 87 183 532 87 185 534 minecraft:polished_blackstone_bricks
fill 87 183 544 87 185 546 minecraft:polished_blackstone_bricks
fill 88 183 519 88 229 521 minecraft:polished_blackstone_bricks
fill 88 183 531 88 229 533 minecraft:polished_blackstone_bricks
fill 88 183 543 88 229 545 minecraft:polished_blackstone_bricks
fill 56 184 526 56 184 532 minecraft:iron_block
fill 57 184 524 57 185 525 minecraft:iron_block
fill 57 184 533 57 185 534 minecraft:iron_block
fill 58 184 522 58 185 523 minecraft:iron_block
fill 58 184 526 58 185 532 minecraft:iron_block
fill 58 184 535 58 185 536 minecraft:iron_block
fill 59 184 521 59 185 521 minecraft:iron_block
fill 59 184 524 59 185 526 minecraft:iron_block
fill 59 184 532 59 185 534 minecraft:iron_block
fill 59 184 537 59 185 537 minecraft:iron_block
fill 60 184 520 60 185 520 minecraft:iron_block
fill 60 184 521 60 185 521 minecraft:light_gray_concrete
fill 60 184 522 60 185 523 minecraft:iron_block
fill 60 184 535 60 185 536 minecraft:iron_block
fill 60 184 537 60 185 537 minecraft:light_gray_concrete
fill 60 184 538 60 185 538 minecraft:iron_block
fill 61 184 519 62 185 519 minecraft:iron_block
fill 61 184 522 61 185 522 minecraft:light_gray_concrete
fill 61 184 536 61 185 536 minecraft:light_gray_concrete
fill 61 184 539 62 185 539 minecraft:iron_block
fill 62 184 521 62 185 521 minecraft:iron_block
fill 62 184 523 62 185 523 minecraft:light_gray_concrete
fill 62 184 535 62 185 535 minecraft:light_gray_concrete
fill 62 184 537 62 185 537 minecraft:iron_block
fill 63 184 518 64 185 518 minecraft:iron_block
fill 63 184 520 65 185 520 minecraft:iron_block
fill 63 184 524 63 185 524 minecraft:light_gray_concrete
fill 63 184 534 63 185 534 minecraft:light_gray_concrete
fill 63 184 538 65 185 538 minecraft:iron_block
fill 63 184 540 64 185 540 minecraft:iron_block
fill 64 184 525 64 185 525 minecraft:light_gray_concrete
fill 64 184 528 65 185 530 minecraft:white_concrete
fill 64 184 533 64 185 533 minecraft:light_gray_concrete
fill 65 184 517 71 185 517 minecraft:iron_block
fill 65 184 519 71 185 519 minecraft:iron_block
fill 65 184 526 65 185 526 minecraft:light_gray_concrete
fill 65 184 527 65 185 527 minecraft:white_concrete
fill 65 184 531 65 185 531 minecraft:white_concrete
fill 65 184 532 65 185 532 minecraft:light_gray_concrete
fill 65 184 539 71 185 539 minecraft:iron_block
fill 65 184 541 71 185 541 minecraft:iron_block
fill 66 184 526 70 185 526 minecraft:white_concrete
fill 66 184 532 70 185 532 minecraft:white_concrete
fill 67 184 525 69 185 525 minecraft:white_concrete
fill 67 184 533 69 185 533 minecraft:white_concrete
fill 71 184 520 73 185 520 minecraft:iron_block
fill 71 184 526 71 185 526 minecraft:light_gray_concrete
fill 71 184 527 71 185 531 minecraft:white_concrete
fill 71 184 532 71 185 532 minecraft:light_gray_concrete
fill 71 184 538 73 185 538 minecraft:iron_block
fill 72 184 518 73 185 518 minecraft:iron_block
fill 72 184 525 72 185 525 minecraft:light_gray_concrete
fill 72 184 528 72 185 530 minecraft:white_concrete
fill 72 184 533 72 185 533 minecraft:light_gray_concrete
fill 72 184 540 73 185 540 minecraft:iron_block
fill 73 184 524 73 185 524 minecraft:light_gray_concrete
fill 73 184 534 73 185 534 minecraft:light_gray_concrete
fill 74 184 519 75 185 519 minecraft:iron_block
fill 74 184 521 75 185 521 minecraft:iron_block
fill 74 184 523 74 185 523 minecraft:light_gray_concrete
fill 74 184 535 74 185 535 minecraft:light_gray_concrete
fill 74 184 537 75 185 537 minecraft:iron_block
fill 74 184 539 75 185 539 minecraft:iron_block
fill 75 184 522 75 185 522 minecraft:light_gray_concrete
fill 75 184 536 75 185 536 minecraft:light_gray_concrete
fill 76 184 520 76 185 520 minecraft:iron_block
fill 76 184 521 76 185 521 minecraft:light_gray_concrete
fill 76 184 523 76 185 523 minecraft:iron_block
fill 76 184 535 76 185 535 minecraft:iron_block
fill 76 184 537 76 185 537 minecraft:light_gray_concrete
fill 76 184 538 76 185 538 minecraft:iron_block
fill 77 184 521 77 185 521 minecraft:iron_block
fill 77 184 524 77 185 526 minecraft:iron_block
fill 77 184 532 77 185 534 minecraft:iron_block
fill 77 184 537 77 185 537 minecraft:iron_block
fill 78 184 522 78 185 523 minecraft:iron_block
fill 78 184 526 78 185 532 minecraft:iron_block
fill 78 184 535 78 185 536 minecraft:iron_block
fill 79 184 524 79 185 525 minecraft:iron_block
fill 79 184 533 79 185 534 minecraft:iron_block
fill 80 184 526 80 184 532 minecraft:iron_block
fill 48 185 514 48 185 519 minecraft:blackstone
fill 48 185 526 48 185 531 minecraft:blackstone
fill 48 185 538 48 185 543 minecraft:blackstone
fill 48 185 550 48 185 551 minecraft:blackstone
fill 49 185 551 52 185 551 minecraft:blackstone
fill 52 185 511 57 185 511 minecraft:blackstone
fill 52 185 526 56 185 532 minecraft:blue_stained_glass
fill 59 185 551 64 185 551 minecraft:blackstone
fill 64 185 511 69 185 511 minecraft:blackstone
fill 71 185 551 76 185 551 minecraft:blackstone
fill 76 185 511 81 185 511 minecraft:blackstone
fill 80 185 526 84 185 532 minecraft:blue_stained_glass
fill 83 185 551 88 185 551 minecraft:blackstone
fill 88 185 511 88 185 516 minecraft:blackstone
fill 88 185 523 88 185 528 minecraft:blackstone
fill 88 185 535 88 185 540 minecraft:blackstone
fill 88 185 547 88 185 550 minecraft:blackstone
fill 47 186 516 47 191 519 minecraft:crying_obsidian
fill 47 186 528 47 191 531 minecraft:crying_obsidian
fill 47 186 540 47 191 543 minecraft:crying_obsidian
fill 47 186 552 50 191 552 minecraft:crying_obsidian
fill 54 186 510 57 191 510 minecraft:crying_obsidian
fill 59 186 552 62 191 552 minecraft:crying_obsidian
fill 60 186 521 60 186 522 minecraft:iron_block
fill 60 186 536 60 186 537 minecraft:iron_block
fill 66 186 510 69 191 510 minecraft:crying_obsidian
fill 71 186 552 74 191 552 minecraft:crying_obsidian
fill 75 186 521 76 186 521 minecraft:iron_block
fill 75 186 537 76 186 537 minecraft:iron_block
fill 78 186 510 81 191 510 minecraft:crying_obsidian
fill 83 186 552 86 191 552 minecraft:crying_obsidian
fill 89 186 511 89 191 514 minecraft:crying_obsidian
fill 89 186 523 89 191 526 minecraft:crying_obsidian
fill 89 186 535 89 191 538 minecraft:crying_obsidian
fill 89 186 547 89 191 550 minecraft:crying_obsidian
setblock 50 187 513 minecraft:light[level=11]
setblock 50 187 521 minecraft:light[level=11]
setblock 50 187 529 minecraft:light[level=11]
setblock 50 187 537 minecraft:light[level=11]
setblock 50 187 545 minecraft:light[level=11]
setblock 58 187 513 minecraft:light[level=11]
setblock 58 187 521 minecraft:light[level=11]
setblock 58 187 529 minecraft:light[level=11]
setblock 58 187 537 minecraft:light[level=11]
setblock 58 187 545 minecraft:light[level=11]
setblock 66 187 513 minecraft:light[level=11]
setblock 66 187 521 minecraft:light[level=11]
setblock 66 187 529 minecraft:light[level=11]
setblock 66 187 537 minecraft:light[level=11]
setblock 66 187 545 minecraft:light[level=11]
setblock 74 187 513 minecraft:light[level=11]
setblock 74 187 521 minecraft:light[level=11]
setblock 74 187 529 minecraft:light[level=11]
setblock 74 187 537 minecraft:light[level=11]
setblock 74 187 545 minecraft:light[level=11]
setblock 82 187 513 minecraft:light[level=11]
setblock 82 187 521 minecraft:light[level=11]
setblock 82 187 529 minecraft:light[level=11]
setblock 82 187 537 minecraft:light[level=11]
setblock 82 187 545 minecraft:light[level=11]
fill 53 188 544 57 189 548 minecraft:blackstone
fill 55 188 549 55 188 550 minecraft:blackstone
fill 54 190 546 56 199 546 minecraft:purple_stained_glass
fill 55 190 545 55 199 545 minecraft:purple_stained_glass
fill 55 190 547 55 199 547 minecraft:purple_stained_glass
fill 47 192 516 47 205 516 minecraft:polished_blackstone_bricks
fill 47 192 517 47 192 518 minecraft:crying_obsidian
fill 47 192 519 47 205 519 minecraft:polished_blackstone_bricks
fill 47 192 528 47 205 528 minecraft:polished_blackstone_bricks
fill 47 192 529 47 192 530 minecraft:crying_obsidian
fill 47 192 531 47 205 531 minecraft:polished_blackstone_bricks
fill 47 192 540 47 205 540 minecraft:polished_blackstone_bricks
fill 47 192 541 47 192 542 minecraft:crying_obsidian
fill 47 192 543 47 205 543 minecraft:polished_blackstone_bricks
fill 47 192 552 47 205 552 minecraft:polished_blackstone_bricks
fill 48 192 552 49 192 552 minecraft:crying_obsidian
fill 50 192 552 50 205 552 minecraft:polished_blackstone_bricks
fill 54 192 510 54 205 510 minecraft:polished_blackstone_bricks
fill 55 192 510 56 192 510 minecraft:crying_obsidian
fill 57 192 510 57 205 510 minecraft:polished_blackstone_bricks
fill 59 192 552 59 205 552 minecraft:polished_blackstone_bricks
fill 60 192 552 61 192 552 minecraft:crying_obsidian
fill 61 192 550 63 193 551 minecraft:polished_blackstone_bricks
fill 62 192 552 62 205 552 minecraft:polished_blackstone_bricks
fill 63 192 511 63 193 511 minecraft:polished_blackstone_bricks
fill 66 192 510 66 205 510 minecraft:polished_blackstone_bricks
fill 67 192 510 68 192 510 minecraft:crying_obsidian
fill 69 192 510 69 205 510 minecraft:polished_blackstone_bricks
fill 71 192 552 71 205 552 minecraft:polished_blackstone_bricks
fill 72 192 552 73 192 552 minecraft:crying_obsidian
fill 74 192 552 74 205 552 minecraft:polished_blackstone_bricks
fill 78 192 510 78 205 510 minecraft:polished_blackstone_bricks
fill 79 192 510 80 192 510 minecraft:crying_obsidian
fill 81 192 510 81 205 510 minecraft:polished_blackstone_bricks
fill 83 192 552 83 205 552 minecraft:polished_blackstone_bricks
fill 84 192 552 85 192 552 minecraft:crying_obsidian
fill 86 192 552 86 205 552 minecraft:polished_blackstone_bricks
fill 89 192 511 89 205 511 minecraft:polished_blackstone_bricks
fill 89 192 512 89 192 513 minecraft:crying_obsidian
fill 89 192 514 89 205 514 minecraft:polished_blackstone_bricks
fill 89 192 523 89 205 523 minecraft:polished_blackstone_bricks
fill 89 192 524 89 192 525 minecraft:crying_obsidian
fill 89 192 526 89 205 526 minecraft:polished_blackstone_bricks
fill 89 192 535 89 205 535 minecraft:polished_blackstone_bricks
fill 89 192 536 89 192 537 minecraft:crying_obsidian
fill 89 192 538 89 205 538 minecraft:polished_blackstone_bricks
fill 89 192 547 89 205 547 minecraft:polished_blackstone_bricks
fill 89 192 548 89 192 549 minecraft:crying_obsidian
fill 89 192 550 89 205 550 minecraft:polished_blackstone_bricks
fill 47 193 517 47 205 518 minecraft:polished_blackstone_bricks
fill 47 193 529 47 205 530 minecraft:polished_blackstone_bricks
fill 47 193 541 47 205 542 minecraft:polished_blackstone_bricks
fill 48 193 515 48 194 517 minecraft:polished_blackstone_bricks
fill 48 193 552 49 205 552 minecraft:polished_blackstone_bricks
fill 55 193 510 56 205 510 minecraft:polished_blackstone_bricks
fill 60 193 552 61 205 552 minecraft:polished_blackstone_bricks
fill 61 193 512 63 194 512 minecraft:polished_blackstone_bricks
fill 61 193 549 63 194 549 minecraft:polished_blackstone_bricks
fill 62 193 513 62 196 513 minecraft:polished_blackstone_bricks
fill 62 193 548 62 196 548 minecraft:polished_blackstone_bricks
fill 67 193 510 68 205 510 minecraft:polished_blackstone_bricks
fill 72 193 552 73 205 552 minecraft:polished_blackstone_bricks
fill 79 193 510 80 205 510 minecraft:polished_blackstone_bricks
fill 84 193 552 85 205 552 minecraft:polished_blackstone_bricks
fill 87 193 515 88 194 517 minecraft:polished_blackstone_bricks
fill 89 193 512 89 205 513 minecraft:polished_blackstone_bricks
fill 89 193 524 89 205 525 minecraft:polished_blackstone_bricks
fill 89 193 536 89 205 537 minecraft:polished_blackstone_bricks
fill 89 193 548 89 205 549 minecraft:polished_blackstone_bricks
fill 49 194 515 49 195 517 minecraft:polished_blackstone_bricks
fill 50 194 516 50 197 516 minecraft:polished_blackstone_bricks
fill 61 194 513 61 195 513 minecraft:polished_blackstone_bricks
fill 61 194 548 61 195 548 minecraft:polished_blackstone_bricks
fill 62 194 514 62 196 514 minecraft:polished_blackstone_bricks
fill 62 194 547 62 196 547 minecraft:polished_blackstone_bricks
setblock 62 194 550 minecraft:polished_blackstone_bricks
setblock 62 194 551 minecraft:purple_stained_glass
fill 63 194 513 63 195 513 minecraft:polished_blackstone_bricks
fill 63 194 548 63 195 548 minecraft:polished_blackstone_bricks
fill 85 194 516 86 196 516 minecraft:polished_blackstone_bricks
fill 86 194 515 86 195 515 minecraft:polished_blackstone_bricks
fill 86 194 517 86 195 517 minecraft:polished_blackstone_bricks
setblock 48 195 516 minecraft:polished_blackstone_bricks
setblock 50 195 513 minecraft:light[level=11]
fill 50 195 515 50 196 515 minecraft:polished_blackstone_bricks
fill 50 195 517 50 196 517 minecraft:polished_blackstone_bricks
setblock 50 195 521 minecraft:light[level=11]
setblock 50 195 529 minecraft:light[level=11]
setblock 50 195 537 minecraft:light[level=11]
setblock 50 195 545 minecraft:light[level=11]
fill 51 195 516 51 197 516 minecraft:polished_blackstone_bricks
setblock 58 195 513 minecraft:light[level=11]
setblock 58 195 521 minecraft:light[level=11]
setblock 58 195 529 minecraft:light[level=11]
setblock 58 195 537 minecraft:light[level=11]
setblock 58 195 545 minecraft:light[level=11]
fill 61 195 514 61 196 515 minecraft:polished_blackstone_bricks
fill 61 195 546 61 196 547 minecraft:polished_blackstone_bricks
setblock 62 195 512 minecraft:polished_blackstone_bricks
fill 62 195 515 63 196 515 minecraft:polished_blackstone_bricks
fill 62 195 546 63 196 546 minecraft:polished_blackstone_bricks
setblock 62 195 549 minecraft:polished_blackstone_bricks
setblock 62 195 550 minecraft:purple_stained_glass
fill 63 195 514 63 196 514 minecraft:polished_blackstone_bricks
fill 63 195 547 63 196 547 minecraft:polished_blackstone_bricks
setblock 66 195 513 minecraft:light[level=11]
setblock 66 195 521 minecraft:light[level=11]
setblock 66 195 529 minecraft:light[level=11]
setblock 66 195 537 minecraft:light[level=11]
setblock 66 195 545 minecraft:light[level=11]
setblock 74 195 513 minecraft:light[level=11]
setblock 74 195 521 minecraft:light[level=11]
setblock 74 195 529 minecraft:light[level=11]
setblock 74 195 537 minecraft:light[level=11]
setblock 74 195 545 minecraft:light[level=11]
setblock 82 195 513 minecraft:light[level=11]
setblock 82 195 521 minecraft:light[level=11]
setblock 82 195 529 minecraft:light[level=11]
setblock 82 195 537 minecraft:light[level=11]
setblock 82 195 545 minecraft:light[level=11]
fill 84 195 516 84 197 516 minecraft:polished_blackstone_bricks
fill 85 195 515 85 196 515 minecraft:polished_blackstone_bricks
fill 85 195 517 85 196 517 minecraft:polished_blackstone_bricks
setblock 87 195 516 minecraft:polished_blackstone_bricks
setblock 88 195 516 minecraft:purple_stained_glass
setblock 48 196 516 minecraft:purple_stained_glass
setblock 49 196 516 minecraft:polished_blackstone_bricks
fill 51 196 515 52 197 515 minecraft:polished_blackstone_bricks
fill 51 196 517 52 197 517 minecraft:polished_blackstone_bricks
fill 52 196 516 52 198 516 minecraft:polished_blackstone_bricks
fill 61 196 516 63 197 516 minecraft:polished_blackstone_bricks
fill 61 196 545 63 197 545 minecraft:polished_blackstone_bricks
setblock 62 196 512 minecraft:purple_stained_glass
fill 62 196 517 62 198 517 minecraft:polished_blackstone_bricks
fill 62 196 544 62 198 544 minecraft:polished_blackstone_bricks
setblock 62 196 549 minecraft:purple_stained_glass
fill 83 196 515 83 197 517 minecraft:polished_blackstone_bricks
fill 84 196 515 84 197 515 minecraft:polished_blackstone_bricks
fill 84 196 517 84 197 517 minecraft:polished_blackstone_bricks
setblock 87 196 516 minecraft:purple_stained_glass
setblock 49 197 516 minecraft:purple_stained_glass
fill 53 197 515 53 198 517 minecraft:polished_blackstone_bricks
fill 54 197 516 54 199 516 minecraft:polished_blackstone_bricks
fill 61 197 517 61 198 517 minecraft:polished_blackstone_bricks
fill 61 197 544 61 198 544 minecraft:polished_blackstone_bricks
setblock 62 197 514 minecraft:purple_stained_glass
setblock 62 197 515 minecraft:polished_blackstone_bricks
fill 62 197 518 62 199 518 minecraft:polished_blackstone_bricks
fill 62 197 543 62 199 543 minecraft:polished_blackstone_bricks
setblock 62 197 546 minecraft:polished_blackstone_bricks
setblock 62 197 547 minecraft:purple_stained_glass
fill 63 197 517 63 198 517 minecraft:polished_blackstone_bricks
fill 63 197 544 63 198 544 minecraft:polished_blackstone_bricks
fill 81 197 516 82 199 516 minecraft:polished_blackstone_bricks
fill 82 197 515 82 198 515 minecraft:polished_blackstone_bricks
fill 82 197 517 82 198 517 minecraft:polished_blackstone_bricks
setblock 85 197 516 minecraft:polished_blackstone_bricks
setblock 86 197 516 minecraft:purple_stained_glass
setblock 51 198 516 minecraft:purple_stained_glass
fill 54 198 515 54 199 515 minecraft:polished_blackstone_bricks
fill 54 198 517 54 199 517 minecraft:polished_blackstone_bricks
fill 55 198 516 55 200 516 minecraft:polished_blackstone_bricks
fill 61 198 518 61 198 519 minecraft:polished_blackstone_bricks
fill 61 198 542 61 198 543 minecraft:polished_blackstone_bricks
setblock 62 198 515 minecraft:purple_stained_glass
setblock 62 198 516 minecraft:polished_blackstone_bricks
fill 62 198 519 62 200 520 minecraft:polished_blackstone_bricks
fill 62 198 541 62 200 542 minecraft:polished_blackstone_bricks
setblock 62 198 545 minecraft:polished_blackstone_bricks
setblock 62 198 546 minecraft:purple_stained_glass
fill 63 198 518 63 198 519 minecraft:polished_blackstone_bricks
fill 63 198 542 63 198 543 minecraft:polished_blackstone_bricks
fill 80 198 516 80 200 516 minecraft:polished_blackstone_bricks
fill 81 198 515 81 199 515 minecraft:polished_blackstone_bricks
fill 81 198 517 81 199 517 minecraft:polished_blackstone_bricks
setblock 83 198 516 minecraft:polished_blackstone_bricks
setblock 84 198 516 minecraft:purple_stained_glass
fill 52 199 516 53 199 516 minecraft:purple_stained_glass
fill 55 199 515 56 199 515 minecraft:polished_blackstone_bricks
fill 55 199 517 56 199 517 minecraft:polished_blackstone_bricks
fill 56 199 516 57 201 516 minecraft:polished_blackstone_bricks
fill 61 199 519 61 199 521 minecraft:polished_blackstone_bricks
fill 61 199 540 61 199 542 minecraft:polished_blackstone_bricks
setblock 62 199 517 minecraft:purple_stained_glass
fill 62 199 521 62 200 522 minecraft:polished_blackstone_bricks
fill 62 199 539 62 201 540 minecraft:polished_blackstone_bricks
setblock 62 199 544 minecraft:purple_stained_glass
fill 63 199 519 63 199 521 minecraft:polished_blackstone_bricks
fill 63 199 540 63 199 542 minecraft:polished_blackstone_bricks
fill 78 199 516 79 201 516 minecraft:polished_blackstone_bricks
fill 79 199 515 80 199 515 minecraft:polished_blackstone_bricks
fill 79 199 517 80 199 517 minecraft:polished_blackstone_bricks
setblock 83 199 516 minecraft:purple_stained_glass
fill 49 200 520 49 205 522 minecraft:polished_blackstone_bricks
fill 49 200 532 49 205 534 minecraft:polished_blackstone_bricks
fill 49 200 544 49 205 546 minecraft:polished_blackstone_bricks
setblock 54 200 516 minecraft:purple_stained_glass
setblock 55 200 546 minecraft:crying_obsidian
fill 55 200 550 57 205 550 minecraft:polished_blackstone_bricks
fill 56 200 515 58 200 515 minecraft:polished_blackstone_bricks
fill 56 200 517 58 200 517 minecraft:polished_blackstone_bricks
fill 58 200 516 59 201 516 minecraft:polished_blackstone_bricks
fill 59 200 512 61 205 512 minecraft:polished_blackstone_bricks
fill 61 200 520 61 200 523 minecraft:polished_blackstone_bricks
fill 61 200 538 61 200 541 minecraft:polished_blackstone_bricks
setblock 62 200 518 minecraft:purple_stained_glass
fill 62 200 523 62 202 524 minecraft:polished_blackstone_bricks
fill 62 200 537 62 202 538 minecraft:polished_blackstone_bricks
setblock 62 200 543 minecraft:purple_stained_glass
fill 63 200 520 63 200 523 minecraft:polished_blackstone_bricks
fill 63 200 538 63 200 541 minecraft:polished_blackstone_bricks
fill 67 200 550 69 205 550 minecraft:polished_blackstone_bricks
fill 71 200 512 73 205 512 minecraft:polished_blackstone_bricks
fill 76 200 516 77 202 516 minecraft:polished_blackstone_bricks
fill 77 200 515 79 200 515 minecraft:polished_blackstone_bricks
fill 77 200 517 79 200 517 minecraft:polished_blackstone_bricks
fill 79 200 550 81 205 550 minecraft:polished_blackstone_bricks
setblock 81 200 516 minecraft:purple_stained_glass
fill 83 200 512 85 205 512 minecraft:polished_blackstone_bricks
fill 87 200 520 87 205 522 minecraft:polished_blackstone_bricks
fill 87 200 532 87 205 534 minecraft:polished_blackstone_bricks
fill 87 200 544 87 205 546 minecraft:polished_blackstone_bricks
setblock 55 201 516 minecraft:purple_stained_glass
fill 57 201 515 60 201 515 minecraft:polished_blackstone_bricks
fill 57 201 517 60 201 517 minecraft:polished_blackstone_bricks
fill 60 201 516 61 203 516 minecraft:polished_blackstone_bricks
fill 61 201 522 61 201 525 minecraft:polished_blackstone_bricks
fill 61 201 536 61 201 539 minecraft:polished_blackstone_bricks
fill 62 201 520 62 201 521 minecraft:purple_stained_glass
fill 62 201 522 63 201 522 minecraft:polished_blackstone_bricks
fill 62 201 525 62 202 528 minecraft:polished_blackstone_bricks
fill 62 201 533 62 202 536 minecraft:polished_blackstone_bricks
setblock 62 201 541 minecraft:purple_stained_glass
fill 63 201 523 63 201 525 minecraft:polished_blackstone_bricks
fill 63 201 536 63 201 539 minecraft:polished_blackstone_bricks
fill 74 201 516 75 203 516 minecraft:polished_blackstone_bricks
fill 75 201 515 78 201 515 minecraft:polished_blackstone_bricks
fill 75 201 517 78 201 517 minecraft:polished_blackstone_bricks
setblock 80 201 516 minecraft:purple_stained_glass
fill 57 202 516 58 202 516 minecraft:purple_stained_glass
fill 59 202 515 59 202 517 minecraft:polished_blackstone_bricks
fill 60 202 515 62 202 515 minecraft:polished_blackstone_bricks
fill 60 202 517 62 202 517 minecraft:polished_blackstone_bricks
fill 61 202 524 61 202 537 minecraft:polished_blackstone_bricks
fill 62 202 516 66 203 516 minecraft:polished_blackstone_bricks
fill 62 202 521 62 202 522 minecraft:purple_stained_glass
fill 62 202 529 63 203 532 minecraft:polished_blackstone_bricks
fill 62 202 539 62 202 540 minecraft:purple_stained_glass
fill 63 202 524 63 202 528 minecraft:polished_blackstone_bricks
fill 63 202 533 63 202 537 minecraft:polished_blackstone_bricks
fill 69 202 516 73 203 516 minecraft:polished_blackstone_bricks
fill 73 202 515 76 202 515 minecraft:polished_blackstone_bricks
fill 73 202 517 76 202 517 minecraft:polished_blackstone_bricks
setblock 78 202 516 minecraft:purple_stained_glass
setblock 50 203 513 minecraft:light[level=11]
setblock 50 203 521 minecraft:light[level=11]
setblock 50 203 529 minecraft:light[level=11]
setblock 50 203 537 minecraft:light[level=11]
setblock 50 203 545 minecraft:light[level=11]
setblock 58 203 513 minecraft:light[level=11]
fill 58 203 516 59 203 516 minecraft:purple_stained_glass
setblock 58 203 521 minecraft:light[level=11]
setblock 58 203 529 minecraft:light[level=11]
setblock 58 203 537 minecraft:light[level=11]
setblock 58 203 545 minecraft:light[level=11]
fill 61 203 528 61 203 533 minecraft:polished_blackstone_bricks
fill 62 203 515 73 203 515 minecraft:polished_blackstone_bricks
fill 62 203 517 73 203 517 minecraft:polished_blackstone_bricks
fill 62 203 523 62 203 525 minecraft:purple_stained_glass
fill 62 203 526 62 203 528 minecraft:polished_blackstone_bricks
fill 62 203 533 62 203 535 minecraft:polished_blackstone_bricks
fill 62 203 536 62 203 538 minecraft:purple_stained_glass
setblock 63 203 528 minecraft:polished_blackstone_bricks
setblock 63 203 533 minecraft:polished_blackstone_bricks
setblock 66 203 513 minecraft:light[level=11]
setblock 66 203 521 minecraft:light[level=11]
setblock 66 203 529 minecraft:light[level=11]
setblock 66 203 537 minecraft:light[level=11]
setblock 66 203 545 minecraft:light[level=11]
fill 67 203 516 68 204 516 minecraft:polished_blackstone_bricks
setblock 74 203 513 minecraft:light[level=11]
setblock 74 203 521 minecraft:light[level=11]
setblock 74 203 529 minecraft:light[level=11]
setblock 74 203 537 minecraft:light[level=11]
setblock 74 203 545 minecraft:light[level=11]
fill 76 203 516 77 203 516 minecraft:purple_stained_glass
setblock 82 203 513 minecraft:light[level=11]
setblock 82 203 521 minecraft:light[level=11]
setblock 82 203 529 minecraft:light[level=11]
setblock 82 203 537 minecraft:light[level=11]
setblock 82 203 545 minecraft:light[level=11]
fill 61 204 516 62 204 516 minecraft:purple_stained_glass
fill 62 204 526 62 204 535 minecraft:purple_stained_glass
fill 63 204 516 66 204 516 minecraft:polished_blackstone_bricks
fill 66 204 515 69 204 515 minecraft:polished_blackstone_bricks
fill 66 204 517 69 204 517 minecraft:polished_blackstone_bricks
fill 69 204 516 72 204 516 minecraft:polished_blackstone_bricks
fill 73 204 516 74 204 516 minecraft:purple_stained_glass
fill 48 205 514 48 205 519 minecraft:blackstone
fill 48 205 526 48 205 531 minecraft:blackstone
fill 48 205 538 48 205 543 minecraft:blackstone
fill 48 205 550 48 205 551 minecraft:blackstone
fill 49 205 551 52 205 551 minecraft:blackstone
fill 52 205 511 57 205 511 minecraft:blackstone
fill 59 205 551 64 205 551 minecraft:blackstone
fill 63 205 516 72 205 516 minecraft:purple_stained_glass
fill 64 205 511 69 205 511 minecraft:blackstone
fill 71 205 551 76 205 551 minecraft:blackstone
fill 76 205 511 81 205 511 minecraft:blackstone
fill 83 205 551 88 205 551 minecraft:blackstone
fill 88 205 511 88 205 516 minecraft:blackstone
fill 88 205 523 88 205 528 minecraft:blackstone
fill 88 205 535 88 205 540 minecraft:blackstone
fill 88 205 547 88 205 550 minecraft:blackstone
fill 47 206 516 47 211 519 minecraft:crying_obsidian
fill 47 206 528 47 211 531 minecraft:crying_obsidian
fill 47 206 540 47 211 543 minecraft:crying_obsidian
fill 47 206 552 50 211 552 minecraft:crying_obsidian
fill 54 206 510 57 211 510 minecraft:crying_obsidian
fill 59 206 552 62 211 552 minecraft:crying_obsidian
fill 66 206 510 69 211 510 minecraft:crying_obsidian
fill 71 206 552 74 211 552 minecraft:crying_obsidian
fill 78 206 510 81 211 510 minecraft:crying_obsidian
fill 83 206 552 86 211 552 minecraft:crying_obsidian
fill 89 206 511 89 211 514 minecraft:crying_obsidian
fill 89 206 523 89 211 526 minecraft:crying_obsidian
fill 89 206 535 89 211 538 minecraft:crying_obsidian
fill 89 206 547 89 211 550 minecraft:crying_obsidian
fill 47 210 511 47 213 511 minecraft:polished_blackstone_bricks
setblock 47 210 512 minecraft:blackstone
fill 47 210 513 47 211 513 minecraft:polished_blackstone_bricks
setblock 47 210 544 minecraft:blackstone
fill 47 210 545 47 210 551 minecraft:polished_blackstone_bricks
fill 51 210 552 57 210 552 minecraft:polished_blackstone_bricks
setblock 52 210 510 minecraft:polished_blackstone_bricks
setblock 53 210 510 minecraft:blackstone
setblock 58 210 510 minecraft:blackstone
setblock 58 210 552 minecraft:blackstone
setblock 60 210 510 minecraft:blackstone
fill 61 210 510 61 213 510 minecraft:polished_blackstone_bricks
setblock 62 210 510 minecraft:blackstone
fill 63 210 510 65 211 510 minecraft:polished_blackstone_bricks
setblock 78 210 552 minecraft:blackstone
fill 79 210 552 82 210 552 minecraft:polished_blackstone_bricks
setblock 83 210 510 minecraft:blackstone
setblock 89 210 531 minecraft:blackstone
fill 89 210 532 89 210 533 minecraft:polished_blackstone_bricks
fill 89 210 539 89 213 539 minecraft:polished_blackstone_bricks
setblock 89 210 540 minecraft:blackstone
fill 89 210 541 89 210 542 minecraft:polished_blackstone_bricks
fill 47 211 512 47 213 512 minecraft:polished_blackstone_bricks
setblock 47 211 514 minecraft:blackstone
setblock 47 211 532 minecraft:blackstone
fill 47 211 533 47 213 534 minecraft:polished_blackstone_bricks
fill 47 211 544 47 213 547 minecraft:polished_blackstone_bricks
fill 47 211 548 47 212 548 minecraft:blackstone
fill 47 211 549 47 213 550 minecraft:polished_blackstone_bricks
fill 47 211 551 47 212 551 minecraft:blackstone
setblock 50 211 513 minecraft:light[level=11]
setblock 50 211 521 minecraft:light[level=11]
setblock 50 211 529 minecraft:light[level=11]
setblock 50 211 537 minecraft:light[level=11]
setblock 50 211 545 minecraft:light[level=11]
fill 51 211 552 55 211 552 minecraft:polished_blackstone_bricks
setblock 52 211 510 minecraft:blackstone
fill 53 211 510 53 213 510 minecraft:polished_blackstone_bricks
setblock 56 211 552 minecraft:blackstone
fill 57 211 552 58 213 552 minecraft:polished_blackstone_bricks
fill 58 211 510 58 213 510 minecraft:polished_blackstone_bricks
setblock 58 211 513 minecraft:light[level=11]
setblock 58 211 521 minecraft:light[level=11]
setblock 58 211 529 minecraft:light[level=11]
setblock 58 211 537 minecraft:light[level=11]
setblock 58 211 545 minecraft:light[level=11]
fill 60 211 510 60 213 510 minecraft:polished_blackstone_bricks
fill 62 211 510 62 213 510 minecraft:polished_blackstone_bricks
fill 63 211 552 67 211 552 minecraft:polished_blackstone_bricks
setblock 66 211 513 minecraft:light[level=11]
setblock 66 211 521 minecraft:light[level=11]
setblock 66 211 529 minecraft:light[level=11]
setblock 66 211 537 minecraft:light[level=11]
setblock 66 211 545 minecraft:light[level=11]
fill 68 211 552 69 211 552 minecraft:blackstone
setblock 70 211 552 minecraft:polished_blackstone_bricks
setblock 74 211 513 minecraft:light[level=11]
setblock 74 211 521 minecraft:light[level=11]
setblock 74 211 529 minecraft:light[level=11]
setblock 74 211 537 minecraft:light[level=11]
setblock 74 211 545 minecraft:light[level=11]
fill 78 211 552 79 213 552 minecraft:polished_blackstone_bricks
setblock 80 211 552 minecraft:blackstone
fill 81 211 552 82 211 552 minecraft:polished_blackstone_bricks
setblock 82 211 513 minecraft:light[level=11]
setblock 82 211 521 minecraft:light[level=11]
setblock 82 211 529 minecraft:light[level=11]
setblock 82 211 537 minecraft:light[level=11]
setblock 82 211 545 minecraft:light[level=11]
fill 83 211 510 84 213 510 minecraft:polished_blackstone_bricks
setblock 85 211 510 minecraft:blackstone
fill 86 211 510 86 213 510 minecraft:polished_blackstone_bricks
setblock 87 211 552 minecraft:blackstone
fill 88 211 552 88 213 552 minecraft:polished_blackstone_bricks
setblock 89 211 517 minecraft:blackstone
setblock 89 211 527 minecraft:blackstone
fill 89 211 528 89 213 529 minecraft:polished_blackstone_bricks
fill 89 211 531 89 213 531 minecraft:polished_blackstone_bricks
fill 89 211 532 89 211 533 minecraft:blackstone
fill 89 211 540 89 213 540 minecraft:polished_blackstone_bricks
setblock 89 211 541 minecraft:blackstone
fill 89 211 542 89 213 542 minecraft:polished_blackstone_bricks
setblock 47 212 513 minecraft:blackstone
fill 47 212 514 47 213 514 minecraft:polished_blackstone_bricks
fill 47 212 516 47 213 516 minecraft:polished_blackstone_bricks
fill 47 212 517 47 212 518 minecraft:crying_obsidian
fill 47 212 519 47 213 519 minecraft:polished_blackstone_bricks
setblock 47 212 528 minecraft:blackstone
fill 47 212 529 47 212 530 minecraft:crying_obsidian
fill 47 212 531 47 213 532 minecraft:polished_blackstone_bricks
fill 47 212 536 47 213 537 minecraft:polished_blackstone_bricks
setblock 47 212 538 minecraft:blackstone
fill 47 212 539 47 213 539 minecraft:polished_blackstone_bricks
setblock 47 212 540 minecraft:blackstone
fill 47 212 541 47 212 542 minecraft:crying_obsidian
fill 47 212 543 47 213 543 minecraft:polished_blackstone_bricks
fill 47 212 552 47 214 552 minecraft:polished_blackstone_bricks
fill 48 212 552 49 212 552 minecraft:crying_obsidian
fill 50 212 552 51 213 552 minecraft:polished_blackstone_bricks
fill 52 212 510 52 213 510 minecraft:polished_blackstone_bricks
setblock 52 212 552 minecraft:blackstone
fill 53 212 552 56 213 552 minecraft:polished_blackstone_bricks
fill 54 212 510 54 213 510 minecraft:polished_blackstone_bricks
fill 55 212 510 56 212 510 minecraft:crying_obsidian
fill 57 212 510 57 213 510 minecraft:polished_blackstone_bricks
fill 59 212 552 59 213 552 minecraft:polished_blackstone_bricks
fill 60 212 552 61 212 552 minecraft:crying_obsidian
fill 62 212 552 63 213 552 minecraft:polished_blackstone_bricks
setblock 63 212 510 minecraft:blackstone
fill 64 212 510 66 213 510 minecraft:polished_blackstone_bricks
setblock 64 212 552 minecraft:blackstone
fill 65 212 552 69 213 552 minecraft:polished_blackstone_bricks
fill 67 212 510 68 212 510 minecraft:crying_obsidian
fill 69 212 510 69 213 510 minecraft:polished_blackstone_bricks
setblock 70 212 552 minecraft:blackstone
fill 71 212 552 71 213 552 minecraft:polished_blackstone_bricks
fill 72 212 552 73 212 552 minecraft:crying_obsidian
fill 74 212 552 74 214 552 minecraft:polished_blackstone_bricks
setblock 78 212 510 minecraft:blackstone
fill 79 212 510 80 212 510 minecraft:crying_obsidian
fill 80 212 552 80 213 552 minecraft:polished_blackstone_bricks
fill 81 212 510 81 213 510 minecraft:polished_blackstone_bricks
setblock 81 212 552 minecraft:blackstone
fill 82 212 552 83 213 552 minecraft:polished_blackstone_bricks
fill 84 212 552 85 212 552 minecraft:crying_obsidian
fill 85 212 510 85 213 510 minecraft:polished_blackstone_bricks
setblock 86 212 552 minecraft:blackstone
fill 87 212 552 87 213 552 minecraft:polished_blackstone_bricks
fill 89 212 511 89 213 511 minecraft:polished_blackstone_bricks
fill 89 212 512 89 212 513 minecraft:crying_obsidian
fill 89 212 514 89 213 514 minecraft:polished_blackstone_bricks
fill 89 212 517 89 214 517 minecraft:polished_blackstone_bricks
fill 89 212 523 89 213 523 minecraft:polished_blackstone_bricks
fill 89 212 524 89 212 525 minecraft:crying_obsidian
fill 89 212 526 89 213 527 minecraft:polished_blackstone_bricks
fill 89 212 532 89 213 532 minecraft:polished_blackstone_bricks
setblock 89 212 533 minecraft:blackstone
fill 89 212 535 89 213 535 minecraft:polished_blackstone_bricks
fill 89 212 536 89 212 537 minecraft:crying_obsidian
fill 89 212 538 89 213 538 minecraft:polished_blackstone_bricks
fill 89 212 541 89 213 541 minecraft:polished_blackstone_bricks
fill 89 212 543 89 213 543 minecraft:polished_blackstone_bricks
setblock 89 212 544 minecraft:blackstone
fill 89 212 545 89 213 545 minecraft:polished_blackstone_bricks
fill 89 212 547 89 213 547 minecraft:polished_blackstone_bricks
fill 89 212 548 89 212 549 minecraft:crying_obsidian
fill 89 212 550 89 213 550 minecraft:polished_blackstone_bricks
setblock 47 213 513 minecraft:polished_blackstone_bricks
fill 47 213 517 47 213 518 minecraft:polished_blackstone_bricks
fill 47 213 528 47 213 530 minecraft:polished_blackstone_bricks
setblock 47 213 538 minecraft:polished_blackstone_bricks
fill 47 213 540 47 213 542 minecraft:polished_blackstone_bricks
setblock 47 213 548 minecraft:polished_blackstone_bricks
setblock 47 213 551 minecraft:polished_blackstone_bricks
fill 48 213 552 49 213 552 minecraft:polished_blackstone_bricks
setblock 52 213 552 minecraft:polished_blackstone_bricks
fill 55 213 510 56 213 510 minecraft:polished_blackstone_bricks
fill 60 213 552 61 213 552 minecraft:polished_blackstone_bricks
setblock 63 213 510 minecraft:polished_blackstone_bricks
fill 64 213 552 64 214 552 minecraft:polished_blackstone_bricks
fill 67 213 510 68 213 510 minecraft:polished_blackstone_bricks
setblock 70 213 552 minecraft:polished_blackstone_bricks
fill 72 213 552 73 213 552 minecraft:polished_blackstone_bricks
fill 78 213 510 80 213 510 minecraft:polished_blackstone_bricks
setblock 81 213 552 minecraft:polished_blackstone_bricks
fill 84 213 552 86 213 552 minecraft:polished_blackstone_bricks
fill 89 213 512 89 213 513 minecraft:polished_blackstone_bricks
fill 89 213 524 89 213 525 minecraft:polished_blackstone_bricks
fill 89 213 533 89 214 533 minecraft:polished_blackstone_bricks
fill 89 213 536 89 213 537 minecraft:polished_blackstone_bricks
setblock 89 213 544 minecraft:polished_blackstone_bricks
fill 89 213 548 89 213 549 minecraft:polished_blackstone_bricks
fill 47 214 510 47 214 520 minecraft:blackstone
setblock 47 214 521 minecraft:polished_blackstone_bricks
fill 47 214 522 47 214 531 minecraft:blackstone
fill 47 214 532 47 215 532 minecraft:polished_blackstone_bricks
fill 47 214 533 47 214 539 minecraft:blackstone
setblock 47 214 540 minecraft:polished_blackstone_bricks
fill 47 214 541 47 214 551 minecraft:blackstone
fill 48 214 510 86 214 510 minecraft:blackstone
fill 48 214 552 63 214 552 minecraft:blackstone
fill 65 214 552 73 214 552 minecraft:blackstone
fill 75 214 552 89 214 552 minecraft:blackstone
fill 88 214 510 89 307 510 minecraft:blackstone
fill 89 214 511 89 225 514 minecraft:blackstone
fill 89 214 518 89 214 525 minecraft:blackstone
setblock 89 214 526 minecraft:polished_blackstone_bricks
fill 89 214 527 89 307 532 minecraft:blackstone
fill 89 214 534 89 214 536 minecraft:blackstone
setblock 89 214 537 minecraft:polished_blackstone_bricks
fill 89 214 538 89 214 551 minecraft:blackstone
fill 47 215 510 47 215 516 minecraft:blackstone
setblock 47 215 517 minecraft:polished_blackstone_bricks
fill 47 215 518 47 225 522 minecraft:blackstone
fill 47 215 523 47 215 524 minecraft:polished_blackstone_bricks
fill 47 215 525 47 215 531 minecraft:blackstone
fill 47 215 533 47 307 533 minecraft:blackstone
setblock 47 215 534 minecraft:polished_blackstone_bricks
fill 47 215 535 47 215 545 minecraft:blackstone
setblock 47 215 546 minecraft:polished_blackstone_bricks
setblock 47 215 547 minecraft:blackstone
setblock 47 215 548 minecraft:polished_blackstone_bricks
fill 47 215 549 47 225 552 minecraft:blackstone
fill 48 215 510 54 215 510 minecraft:blackstone
fill 48 215 552 49 215 552 minecraft:blackstone
setblock 50 215 552 minecraft:polished_blackstone_bricks
fill 51 215 552 52 307 552 minecraft:blackstone
setblock 53 215 552 minecraft:polished_blackstone_bricks
fill 54 215 552 65 215 552 minecraft:blackstone
fill 55 215 510 55 216 510 minecraft:polished_blackstone_bricks
fill 56 215 510 68 215 510 minecraft:blackstone
setblock 66 215 552 minecraft:polished_blackstone_bricks
fill 67 215 552 74 225 552 minecraft:blackstone
setblock 69 215 510 minecraft:polished_blackstone_bricks
fill 70 215 510 78 215 510 minecraft:blackstone
setblock 75 215 552 minecraft:polished_blackstone_bricks
fill 76 215 552 89 215 552 minecraft:blackstone
setblock 79 215 510 minecraft:polished_blackstone_bricks
fill 80 215 510 85 215 510 minecraft:blackstone
setblock 86 215 510 minecraft:polished_blackstone_bricks
fill 87 215 510 87 307 510 minecraft:blackstone
fill 89 215 515 89 307 515 minecraft:blackstone
setblock 89 215 516 minecraft:polished_blackstone_bricks
fill 89 215 517 89 307 518 minecraft:blackstone
setblock 89 215 519 minecraft:polished_blackstone_bricks
fill 89 215 520 89 215 526 minecraft:blackstone
fill 89 215 533 89 307 533 minecraft:blackstone
setblock 89 215 534 minecraft:polished_blackstone_bricks
fill 89 215 535 89 225 537 minecraft:blackstone
setblock 89 215 538 minecraft:polished_blackstone_bricks
fill 89 215 539 89 215 551 minecraft:blackstone
fill 47 216 510 47 307 513 minecraft:blackstone
setblock 47 216 514 minecraft:polished_blackstone_bricks
fill 47 216 515 47 225 517 minecraft:blackstone
fill 47 216 523 47 307 523 minecraft:blackstone
setblock 47 216 524 minecraft:polished_blackstone_bricks
fill 47 216 525 47 307 525 minecraft:blackstone
setblock 47 216 526 minecraft:polished_blackstone_bricks
fill 47 216 527 47 225 532 minecraft:blackstone
fill 47 216 534 47 225 542 minecraft:blackstone
fill 47 216 543 47 216 544 minecraft:polished_blackstone_bricks
fill 47 216 545 47 307 546 minecraft:blackstone
setblock 47 216 547 minecraft:polished_blackstone_bricks
fill 47 216 548 47 307 548 minecraft:blackstone
setblock 48 216 510 minecraft:polished_blackstone_bricks
fill 48 216 552 48 225 552 minecraft:blackstone
fill 49 216 510 51 307 510 minecraft:blackstone
setblock 49 216 552 minecraft:polished_blackstone_bricks
fill 50 216 552 50 225 552 minecraft:blackstone
setblock 52 216 510 minecraft:polished_blackstone_bricks
fill 53 216 510 53 307 510 minecraft:blackstone
fill 53 216 552 54 307 552 minecraft:blackstone
setblock 54 216 510 minecraft:polished_blackstone_bricks
fill 55 216 552 57 216 552 minecraft:polished_blackstone_bricks
fill 56 216 510 57 225 510 minecraft:blackstone
setblock 58 216 510 minecraft:polished_blackstone_bricks
fill 58 216 552 66 225 552 minecraft:blackstone
fill 59 216 510 60 307 510 minecraft:blackstone
setblock 61 216 510 minecraft:polished_blackstone_bricks
fill 62 216 510 64 307 510 minecraft:blackstone
setblock 65 216 510 minecraft:polished_blackstone_bricks
fill 66 216 510 75 225 510 minecraft:blackstone
fill 75 216 552 78 307 552 minecraft:blackstone
setblock 76 216 510 minecraft:polished_blackstone_bricks
fill 77 216 510 84 225 510 minecraft:blackstone
fill 79 216 552 80 216 552 minecraft:polished_blackstone_bricks
fill 81 216 552 89 225 552 minecraft:blackstone
setblock 85 216 510 minecraft:polished_blackstone_bricks
fill 86 216 510 86 307 510 minecraft:blackstone
fill 89 216 516 89 307 516 minecraft:blackstone
fill 89 216 519 89 307 519 minecraft:blackstone
setblock 89 216 520 minecraft:polished_blackstone_bricks
fill 89 216 521 89 307 521 minecraft:blackstone
setblock 89 216 522 minecraft:polished_blackstone_bricks
fill 89 216 523 89 225 526 minecraft:blackstone
fill 89 216 534 89 307 534 minecraft:blackstone
fill 89 216 538 89 225 539 minecraft:blackstone
setblock 89 216 540 minecraft:polished_blackstone_bricks
fill 89 216 541 89 307 545 minecraft:blackstone
setblock 89 216 546 minecraft:polished_blackstone_bricks
fill 89 216 547 89 225 551 minecraft:blackstone
fill 47 217 514 47 307 514 minecraft:blackstone
fill 47 217 524 47 307 524 minecraft:blackstone
fill 47 217 526 47 307 526 minecraft:blackstone
fill 47 217 543 47 225 544 minecraft:blackstone
fill 47 217 547 47 307 547 minecraft:blackstone
fill 48 217 510 48 307 510 minecraft:blackstone
fill 49 217 552 49 225 552 minecraft:blackstone
fill 52 217 510 52 307 510 minecraft:blackstone
fill 54 217 510 55 225 510 minecraft:blackstone
fill 55 217 552 57 307 552 minecraft:blackstone
fill 58 217 510 58 307 510 minecraft:blackstone
fill 61 217 510 61 307 510 minecraft:blackstone
fill 65 217 510 65 307 510 minecraft:blackstone
fill 76 217 510 76 307 510 minecraft:blackstone
fill 79 217 552 80 307 552 minecraft:blackstone
fill 85 217 510 85 307 510 minecraft:blackstone
fill 89 217 520 89 307 520 minecraft:blackstone
fill 89 217 522 89 307 522 minecraft:blackstone
fill 89 217 540 89 307 540 minecraft:blackstone
fill 89 217 546 89 307 546 minecraft:blackstone
setblock 50 219 513 minecraft:light[level=11]
setblock 50 219 521 minecraft:light[level=11]
setblock 50 219 529 minecraft:light[level=11]
setblock 50 219 537 minecraft:light[level=11]
setblock 50 219 545 minecraft:light[level=11]
setblock 58 219 513 minecraft:light[level=11]
setblock 58 219 521 minecraft:light[level=11]
setblock 58 219 529 minecraft:light[level=11]
setblock 58 219 537 minecraft:light[level=11]
setblock 58 219 545 minecraft:light[level=11]
setblock 66 219 513 minecraft:light[level=11]
setblock 66 219 521 minecraft:light[level=11]
setblock 66 219 529 minecraft:light[level=11]
setblock 66 219 537 minecraft:light[level=11]
setblock 66 219 545 minecraft:light[level=11]
setblock 74 219 513 minecraft:light[level=11]
setblock 74 219 521 minecraft:light[level=11]
setblock 74 219 529 minecraft:light[level=11]
setblock 74 219 537 minecraft:light[level=11]
setblock 74 219 545 minecraft:light[level=11]
setblock 82 219 513 minecraft:light[level=11]
setblock 82 219 521 minecraft:light[level=11]
setblock 82 219 529 minecraft:light[level=11]
setblock 82 219 537 minecraft:light[level=11]
setblock 82 219 545 minecraft:light[level=11]
fill 49 220 520 49 225 522 minecraft:polished_blackstone_bricks
fill 49 220 532 49 225 534 minecraft:polished_blackstone_bricks
fill 49 220 544 49 225 546 minecraft:polished_blackstone_bricks
fill 55 220 550 57 225 550 minecraft:polished_blackstone_bricks
fill 59 220 512 61 225 512 minecraft:polished_blackstone_bricks
fill 67 220 550 69 225 550 minecraft:polished_blackstone_bricks
fill 71 220 512 73 225 512 minecraft:polished_blackstone_bricks
fill 79 220 550 81 225 550 minecraft:polished_blackstone_bricks
fill 83 220 512 85 225 512 minecraft:polished_blackstone_bricks
fill 87 220 520 87 225 522 minecraft:polished_blackstone_bricks
fill 87 220 532 87 225 534 minecraft:polished_blackstone_bricks
fill 87 220 544 87 225 546 minecraft:polished_blackstone_bricks
fill 48 225 514 48 225 519 minecraft:blackstone
fill 48 225 526 48 225 531 minecraft:blackstone
fill 48 225 538 48 225 543 minecraft:blackstone
fill 48 225 550 48 225 551 minecraft:blackstone
fill 49 225 551 52 225 551 minecraft:blackstone
fill 52 225 511 57 225 511 minecraft:blackstone
fill 59 225 551 64 225 551 minecraft:blackstone
fill 64 225 511 69 225 511 minecraft:blackstone
fill 71 225 551 76 225 551 minecraft:blackstone
fill 76 225 511 81 225 511 minecraft:blackstone
fill 83 225 551 88 225 551 minecraft:blackstone
fill 88 225 511 88 225 516 minecraft:blackstone
fill 88 225 523 88 225 528 minecraft:blackstone
fill 88 225 535 88 225 540 minecraft:blackstone
fill 88 225 547 88 225 550 minecraft:blackstone
fill 47 226 515 47 307 515 minecraft:blackstone
fill 47 226 516 47 229 519 minecraft:crying_obsidian
fill 47 226 520 47 307 522 minecraft:blackstone
fill 47 226 527 47 307 527 minecraft:blackstone
fill 47 226 528 47 229 531 minecraft:crying_obsidian
fill 47 226 532 47 307 532 minecraft:blackstone
fill 47 226 534 47 307 539 minecraft:blackstone
fill 47 226 540 47 229 543 minecraft:crying_obsidian
fill 47 226 544 47 307 544 minecraft:blackstone
fill 47 226 549 47 307 551 minecraft:blackstone
fill 47 226 552 50 229 552 minecraft:crying_obsidian
fill 54 226 510 57 229 510 minecraft:crying_obsidian
fill 58 226 552 58 307 552 minecraft:blackstone
fill 59 226 552 62 229 552 minecraft:crying_obsidian
fill 63 226 552 70 307 552 minecraft:blackstone
fill 66 226 510 69 229 510 minecraft:crying_obsidian
fill 70 226 510 75 307 510 minecraft:blackstone
fill 71 226 552 74 229 552 minecraft:crying_obsidian
fill 77 226 510 77 307 510 minecraft:blackstone
fill 78 226 510 81 229 510 minecraft:crying_obsidian
fill 81 226 552 82 307 552 minecraft:blackstone
fill 82 226 510 84 307 510 minecraft:blackstone
fill 83 226 552 86 229 552 minecraft:crying_obsidian
fill 87 226 552 89 307 552 minecraft:blackstone
fill 89 226 511 89 229 514 minecraft:crying_obsidian
fill 89 226 523 89 229 526 minecraft:crying_obsidian
fill 89 226 535 89 229 538 minecraft:crying_obsidian
fill 89 226 539 89 307 539 minecraft:blackstone
fill 89 226 547 89 229 550 minecraft:crying_obsidian
fill 89 226 551 89 307 551 minecraft:blackstone
setblock 50 227 513 minecraft:light[level=11]
setblock 50 227 521 minecraft:light[level=11]
setblock 50 227 529 minecraft:light[level=11]
setblock 50 227 537 minecraft:light[level=11]
setblock 50 227 545 minecraft:light[level=11]
setblock 58 227 513 minecraft:light[level=11]
setblock 58 227 521 minecraft:light[level=11]
setblock 58 227 529 minecraft:light[level=11]
setblock 58 227 537 minecraft:light[level=11]
setblock 58 227 545 minecraft:light[level=11]
setblock 66 227 513 minecraft:light[level=11]
setblock 66 227 521 minecraft:light[level=11]
setblock 66 227 529 minecraft:light[level=11]
setblock 66 227 537 minecraft:light[level=11]
setblock 66 227 545 minecraft:light[level=11]
setblock 74 227 513 minecraft:light[level=11]
setblock 74 227 521 minecraft:light[level=11]
setblock 74 227 529 minecraft:light[level=11]
setblock 74 227 537 minecraft:light[level=11]
setblock 74 227 545 minecraft:light[level=11]
setblock 82 227 513 minecraft:light[level=11]
setblock 82 227 521 minecraft:light[level=11]
setblock 82 227 529 minecraft:light[level=11]
setblock 82 227 537 minecraft:light[level=11]
setblock 82 227 545 minecraft:light[level=11]
fill 47 230 516 47 245 519 minecraft:blackstone
fill 47 230 528 47 245 531 minecraft:blackstone
fill 47 230 540 47 245 543 minecraft:blackstone
fill 47 230 552 50 245 552 minecraft:blackstone
fill 54 230 510 57 245 510 minecraft:blackstone
fill 59 230 552 62 245 552 minecraft:blackstone
fill 66 230 510 69 245 510 minecraft:blackstone
fill 71 230 552 74 245 552 minecraft:blackstone
fill 78 230 510 81 245 510 minecraft:blackstone
fill 83 230 552 86 245 552 minecraft:blackstone
fill 89 230 511 89 245 514 minecraft:blackstone
fill 89 230 523 89 245 526 minecraft:blackstone
fill 89 230 535 89 245 538 minecraft:blackstone
fill 89 230 547 89 245 550 minecraft:blackstone
setblock 50 235 513 minecraft:light[level=11]
setblock 50 235 521 minecraft:light[level=11]
setblock 50 235 529 minecraft:light[level=11]
setblock 50 235 537 minecraft:light[level=11]
setblock 50 235 545 minecraft:light[level=11]
fill 56 235 529 68 235 529 minecraft:purple_stained_glass
setblock 58 235 513 minecraft:light[level=11]
setblock 58 235 521 minecraft:light[level=11]
setblock 58 235 537 minecraft:light[level=11]
setblock 58 235 545 minecraft:light[level=11]
fill 59 235 528 69 235 528 minecraft:purple_stained_glass
fill 59 235 530 69 235 530 minecraft:purple_stained_glass
fill 60 235 521 62 236 522 minecraft:purple_stained_glass
fill 60 235 536 62 236 537 minecraft:purple_stained_glass
fill 61 235 523 81 235 523 minecraft:purple_stained_glass
fill 61 235 535 81 235 535 minecraft:purple_stained_glass
fill 62 235 524 80 235 524 minecraft:purple_stained_glass
fill 62 235 527 70 235 527 minecraft:purple_stained_glass
fill 62 235 531 70 235 531 minecraft:purple_stained_glass
fill 62 235 534 80 235 534 minecraft:purple_stained_glass
fill 63 235 522 64 236 522 minecraft:purple_stained_glass
fill 63 235 525 79 235 525 minecraft:purple_stained_glass
fill 63 235 533 79 235 533 minecraft:purple_stained_glass
fill 63 235 536 64 236 536 minecraft:purple_stained_glass
fill 64 235 526 78 235 526 minecraft:purple_stained_glass
fill 64 235 532 78 235 532 minecraft:purple_stained_glass
setblock 66 235 513 minecraft:light[level=11]
setblock 66 235 521 minecraft:light[level=11]
setblock 66 235 537 minecraft:light[level=11]
setblock 66 235 545 minecraft:light[level=11]
fill 67 235 516 67 236 522 minecraft:purple_stained_glass
fill 67 235 536 67 236 542 minecraft:purple_stained_glass
fill 68 235 517 68 235 522 minecraft:purple_stained_glass
fill 68 235 536 68 235 541 minecraft:purple_stained_glass
fill 69 235 518 69 235 522 minecraft:purple_stained_glass
fill 69 235 536 69 235 540 minecraft:purple_stained_glass
fill 70 235 520 70 235 522 minecraft:purple_stained_glass
fill 70 235 536 70 235 538 minecraft:purple_stained_glass
fill 72 235 520 75 235 522 minecraft:purple_stained_glass
fill 72 235 527 80 235 527 minecraft:purple_stained_glass
fill 72 235 531 80 235 531 minecraft:purple_stained_glass
fill 72 235 536 75 235 538 minecraft:purple_stained_glass
fill 73 235 518 75 236 519 minecraft:purple_stained_glass
fill 73 235 528 83 235 528 minecraft:purple_stained_glass
fill 73 235 530 83 235 530 minecraft:purple_stained_glass
fill 73 235 539 75 236 540 minecraft:purple_stained_glass
setblock 74 235 513 minecraft:light[level=11]
fill 74 235 517 75 236 517 minecraft:purple_stained_glass
fill 74 235 529 86 235 529 minecraft:purple_stained_glass
fill 74 235 541 75 236 541 minecraft:purple_stained_glass
setblock 74 235 545 minecraft:light[level=11]
fill 75 235 516 75 236 516 minecraft:purple_stained_glass
fill 75 235 542 75 236 542 minecraft:purple_stained_glass
fill 78 235 522 82 236 522 minecraft:purple_stained_glass
fill 78 235 536 82 236 536 minecraft:purple_stained_glass
fill 80 235 521 82 236 521 minecraft:purple_stained_glass
fill 80 235 537 82 236 537 minecraft:purple_stained_glass
setblock 82 235 513 minecraft:light[level=11]
setblock 82 235 545 minecraft:light[level=11]
fill 48 236 511 55 236 551 minecraft:polished_blackstone
fill 56 236 511 58 236 528 minecraft:polished_blackstone
fill 56 236 529 60 236 529 minecraft:purple_stained_glass
fill 56 236 530 58 236 551 minecraft:polished_blackstone
fill 59 236 511 59 236 527 minecraft:polished_blackstone
fill 59 236 528 62 236 528 minecraft:purple_stained_glass
fill 59 236 530 62 236 530 minecraft:purple_stained_glass
fill 59 236 531 59 236 551 minecraft:polished_blackstone
fill 60 236 511 66 236 520 minecraft:polished_blackstone
fill 60 236 523 60 236 527 minecraft:polished_blackstone
fill 60 236 531 60 236 535 minecraft:polished_blackstone
fill 60 236 538 66 236 551 minecraft:polished_blackstone
fill 61 236 523 62 236 523 minecraft:purple_stained_glass
fill 61 236 524 61 236 527 minecraft:polished_blackstone
fill 61 236 529 66 236 529 minecraft:magenta_stained_glass
fill 61 236 531 61 236 534 minecraft:polished_blackstone
fill 61 236 535 62 236 535 minecraft:purple_stained_glass
fill 62 236 524 63 236 524 minecraft:purple_stained_glass
fill 62 236 525 62 236 526 minecraft:polished_blackstone
fill 62 236 527 65 236 527 minecraft:purple_stained_glass
fill 62 236 531 65 236 531 minecraft:purple_stained_glass
fill 62 236 532 62 236 533 minecraft:polished_blackstone
fill 62 236 534 63 236 534 minecraft:purple_stained_glass
fill 63 236 521 66 236 521 minecraft:polished_blackstone
setblock 63 236 523 minecraft:magenta_stained_glass
setblock 63 236 525 minecraft:purple_stained_glass
setblock 63 236 526 minecraft:polished_blackstone
fill 63 236 528 67 236 528 minecraft:magenta_stained_glass
fill 63 236 530 67 236 530 minecraft:magenta_stained_glass
setblock 63 236 532 minecraft:polished_blackstone
setblock 63 236 533 minecraft:purple_stained_glass
setblock 63 236 535 minecraft:magenta_stained_glass
fill 63 236 537 66 236 537 minecraft:polished_blackstone
fill 64 236 523 67 236 523 minecraft:purple_stained_glass
fill 64 236 524 66 236 525 minecraft:magenta_stained_glass
setblock 64 236 526 minecraft:purple_stained_glass
setblock 64 236 532 minecraft:purple_stained_glass
fill 64 236 533 66 236 534 minecraft:magenta_stained_glass
fill 64 236 535 67 236 535 minecraft:purple_stained_glass
fill 65 236 522 66 236 522 minecraft:polished_blackstone
fill 65 236 526 68 236 526 minecraft:magenta_stained_glass
fill 65 236 532 68 236 532 minecraft:magenta_stained_glass
fill 65 236 536 66 236 536 minecraft:polished_blackstone
fill 66 236 527 67 236 527 minecraft:magenta_stained_glass
fill 66 236 531 67 236 531 minecraft:magenta_stained_glass
fill 67 236 511 88 236 515 minecraft:polished_blackstone
setblock 67 236 524 minecraft:purple_stained_glass
fill 67 236 525 70 236 525 minecraft:magenta_stained_glass
fill 67 236 529 68 236 529 minecraft:crying_obsidian
fill 67 236 533 70 236 533 minecraft:magenta_stained_glass
setblock 67 236 534 minecraft:purple_stained_glass
fill 67 236 543 88 236 551 minecraft:polished_blackstone
fill 68 236 516 74 236 516 minecraft:polished_blackstone
fill 68 236 517 68 236 519 minecraft:purple_stained_glass
fill 68 236 520 68 236 524 minecraft:magenta_stained_glass
fill 68 236 527 69 236 528 minecraft:crying_obsidian
fill 68 236 530 69 236 531 minecraft:crying_obsidian
fill 68 236 534 68 236 538 minecraft:magenta_stained_glass
fill 68 236 539 68 236 541 minecraft:purple_stained_glass
fill 68 236 542 74 236 542 minecraft:polished_blackstone
fill 69 236 517 73 236 517 minecraft:polished_blackstone
fill 69 236 518 69 236 520 minecraft:purple_stained_glass
fill 69 236 521 69 236 524 minecraft:magenta_stained_glass
fill 69 236 526 73 236 526 minecraft:crying_obsidian
fill 69 236 532 73 236 532 minecraft:crying_obsidian
fill 69 236 534 69 236 537 minecraft:magenta_stained_glass
fill 69 236 538 69 236 540 minecraft:purple_stained_glass
fill 69 236 541 73 236 541 minecraft:polished_blackstone
fill 70 236 518 72 236 519 minecraft:polished_blackstone
fill 70 236 520 70 236 521 minecraft:purple_stained_glass
fill 70 236 522 70 236 524 minecraft:magenta_stained_glass
setblock 70 236 527 minecraft:crying_obsidian
setblock 70 236 531 minecraft:crying_obsidian
fill 70 236 534 70 236 536 minecraft:magenta_stained_glass
fill 70 236 537 70 236 538 minecraft:purple_stained_glass
fill 70 236 539 72 236 540 minecraft:polished_blackstone
fill 71 236 520 71 236 522 minecraft:polished_blackstone
fill 71 236 523 71 236 524 minecraft:purple_stained_glass
setblock 71 236 525 minecraft:crying_obsidian
setblock 71 236 533 minecraft:crying_obsidian
fill 71 236 534 71 236 535 minecraft:purple_stained_glass
fill 71 236 536 71 236 538 minecraft:polished_blackstone
fill 72 236 520 72 236 521 minecraft:purple_stained_glass
fill 72 236 522 74 236 525 minecraft:magenta_stained_glass
fill 72 236 527 74 236 527 minecraft:crying_obsidian
fill 72 236 531 74 236 531 minecraft:crying_obsidian
fill 72 236 533 74 236 536 minecraft:magenta_stained_glass
fill 72 236 537 72 236 538 minecraft:purple_stained_glass
setblock 73 236 520 minecraft:purple_stained_glass
fill 73 236 521 74 236 521 minecraft:magenta_stained_glass
fill 73 236 528 74 236 528 minecraft:crying_obsidian
fill 73 236 530 74 236 530 minecraft:crying_obsidian
fill 73 236 537 74 236 537 minecraft:magenta_stained_glass
setblock 73 236 538 minecraft:purple_stained_glass
setblock 74 236 520 minecraft:magenta_stained_glass
fill 74 236 526 77 236 526 minecraft:magenta_stained_glass
fill 74 236 529 75 236 529 minecraft:crying_obsidian
fill 74 236 532 77 236 532 minecraft:magenta_stained_glass
setblock 74 236 538 minecraft:magenta_stained_glass
fill 75 236 520 75 236 524 minecraft:purple_stained_glass
fill 75 236 525 78 236 525 minecraft:magenta_stained_glass
fill 75 236 527 76 236 528 minecraft:magenta_stained_glass
fill 75 236 530 76 236 531 minecraft:magenta_stained_glass
fill 75 236 533 78 236 533 minecraft:magenta_stained_glass
fill 75 236 534 75 236 538 minecraft:purple_stained_glass
fill 76 236 516 77 236 522 minecraft:polished_blackstone
fill 76 236 523 78 236 523 minecraft:purple_stained_glass
fill 76 236 524 78 236 524 minecraft:magenta_stained_glass
fill 76 236 529 81 236 529 minecraft:magenta_stained_glass
fill 76 236 534 78 236 534 minecraft:magenta_stained_glass
fill 76 236 535 78 236 535 minecraft:purple_stained_glass
fill 76 236 536 77 236 542 minecraft:polished_blackstone
fill 77 236 527 80 236 527 minecraft:purple_stained_glass
fill 77 236 528 79 236 528 minecraft:magenta_stained_glass
fill 77 236 530 79 236 530 minecraft:magenta_stained_glass
fill 77 236 531 80 236 531 minecraft:purple_stained_glass
fill 78 236 516 79 236 521 minecraft:polished_blackstone
setblock 78 236 526 minecraft:purple_stained_glass
setblock 78 236 532 minecraft:purple_stained_glass
fill 78 236 537 79 236 542 minecraft:polished_blackstone
setblock 79 236 523 minecraft:magenta_stained_glass
fill 79 236 524 79 236 525 minecraft:purple_stained_glass
fill 79 236 526 88 236 526 minecraft:polished_blackstone
fill 79 236 532 88 236 532 minecraft:polished_blackstone
fill 79 236 533 79 236 534 minecraft:purple_stained_glass
setblock 79 236 535 minecraft:magenta_stained_glass
fill 80 236 516 88 236 520 minecraft:polished_blackstone
fill 80 236 523 80 236 524 minecraft:purple_stained_glass
fill 80 236 525 88 236 525 minecraft:polished_blackstone
fill 80 236 528 83 236 528 minecraft:purple_stained_glass
fill 80 236 530 83 236 530 minecraft:purple_stained_glass
fill 80 236 533 88 236 533 minecraft:polished_blackstone
fill 80 236 534 80 236 535 minecraft:purple_stained_glass
fill 80 236 538 88 236 542 minecraft:polished_blackstone
setblock 81 236 523 minecraft:purple_stained_glass
fill 81 236 524 88 236 524 minecraft:polished_blackstone
fill 81 236 527 88 236 527 minecraft:polished_blackstone
fill 81 236 531 88 236 531 minecraft:polished_blackstone
fill 81 236 534 88 236 534 minecraft:polished_blackstone
setblock 81 236 535 minecraft:purple_stained_glass
fill 82 236 523 88 236 523 minecraft:polished_blackstone
fill 82 236 529 86 236 529 minecraft:purple_stained_glass
fill 82 236 535 88 236 535 minecraft:polished_blackstone
fill 83 236 521 88 236 522 minecraft:polished_blackstone
fill 83 236 536 88 236 537 minecraft:polished_blackstone
fill 84 236 528 88 236 528 minecraft:polished_blackstone
fill 84 236 530 88 236 530 minecraft:polished_blackstone
fill 87 236 529 88 236 529 minecraft:polished_blackstone
fill 48 240 511 50 273 511 minecraft:polished_blackstone_bricks
fill 48 240 521 48 273 523 minecraft:polished_blackstone_bricks
fill 48 240 533 48 273 535 minecraft:polished_blackstone_bricks
fill 48 240 545 48 273 547 minecraft:polished_blackstone_bricks
fill 49 240 520 49 245 522 minecraft:polished_blackstone_bricks
fill 49 240 532 49 245 534 minecraft:polished_blackstone_bricks
fill 49 240 544 49 245 546 minecraft:polished_blackstone_bricks
fill 54 240 551 56 273 551 minecraft:polished_blackstone_bricks
fill 55 240 550 57 245 550 minecraft:polished_blackstone_bricks
fill 59 240 512 61 245 512 minecraft:polished_blackstone_bricks
fill 60 240 511 62 273 511 minecraft:polished_blackstone_bricks
fill 66 240 551 68 273 551 minecraft:polished_blackstone_bricks
fill 67 240 550 69 245 550 minecraft:polished_blackstone_bricks
fill 71 240 512 73 245 512 minecraft:polished_blackstone_bricks
fill 72 240 511 74 273 511 minecraft:polished_blackstone_bricks
fill 78 240 551 80 273 551 minecraft:polished_blackstone_bricks
fill 79 240 550 81 245 550 minecraft:polished_blackstone_bricks
fill 80 240 514 88 240 520 minecraft:polished_blackstone_bricks
fill 83 240 512 85 245 512 minecraft:polished_blackstone_bricks
setblock 83 240 545 minecraft:blackstone
fill 83 240 546 86 273 547 minecraft:polished_blackstone_bricks
setblock 83 240 548 minecraft:blackstone
fill 84 240 511 86 273 511 minecraft:polished_blackstone_bricks
fill 84 240 544 85 240 544 minecraft:blackstone
fill 84 240 545 85 273 545 minecraft:polished_blackstone_bricks
fill 84 240 548 85 273 548 minecraft:polished_blackstone_bricks
setblock 85 240 549 minecraft:blackstone
setblock 86 240 545 minecraft:blackstone
setblock 86 240 548 minecraft:blackstone
fill 87 240 521 87 245 522 minecraft:polished_blackstone_bricks
fill 87 240 532 87 245 534 minecraft:polished_blackstone_bricks
fill 87 240 544 87 245 546 minecraft:polished_blackstone_bricks
setblock 87 240 547 minecraft:blackstone
fill 88 240 521 88 273 521 minecraft:polished_blackstone_bricks
fill 88 240 531 88 273 533 minecraft:polished_blackstone_bricks
fill 88 240 543 88 273 545 minecraft:polished_blackstone_bricks
fill 80 241 514 80 257 514 minecraft:polished_blackstone_bricks
setblock 80 241 515 minecraft:crying_obsidian
fill 80 241 516 80 257 516 minecraft:polished_blackstone_bricks
setblock 80 241 517 minecraft:crying_obsidian
fill 80 241 518 80 257 518 minecraft:polished_blackstone_bricks
setblock 80 241 519 minecraft:crying_obsidian
fill 80 241 520 80 257 520 minecraft:polished_blackstone_bricks
setblock 81 241 514 minecraft:crying_obsidian
fill 81 241 515 81 257 515 minecraft:polished_blackstone_bricks
setblock 81 241 516 minecraft:crying_obsidian
fill 81 241 517 81 257 517 minecraft:polished_blackstone_bricks
setblock 81 241 518 minecraft:crying_obsidian
fill 81 241 519 81 257 519 minecraft:polished_blackstone_bricks
setblock 81 241 520 minecraft:crying_obsidian
fill 82 241 514 82 257 514 minecraft:polished_blackstone_bricks
setblock 82 241 515 minecraft:crying_obsidian
fill 82 241 516 82 257 516 minecraft:polished_blackstone_bricks
setblock 82 241 517 minecraft:crying_obsidian
fill 82 241 518 82 257 518 minecraft:polished_blackstone_bricks
setblock 82 241 519 minecraft:crying_obsidian
fill 82 241 520 82 257 520 minecraft:polished_blackstone_bricks
setblock 83 241 514 minecraft:crying_obsidian
fill 83 241 515 83 257 515 minecraft:polished_blackstone_bricks
setblock 83 241 516 minecraft:crying_obsidian
fill 83 241 517 83 257 517 minecraft:polished_blackstone_bricks
setblock 83 241 518 minecraft:crying_obsidian
fill 83 241 519 83 257 519 minecraft:polished_blackstone_bricks
setblock 83 241 520 minecraft:crying_obsidian
fill 84 241 514 84 257 514 minecraft:polished_blackstone_bricks
setblock 84 241 515 minecraft:crying_obsidian
fill 84 241 516 84 257 516 minecraft:polished_blackstone_bricks
setblock 84 241 517 minecraft:crying_obsidian
fill 84 241 518 84 257 518 minecraft:polished_blackstone_bricks
setblock 84 241 519 minecraft:crying_obsidian
fill 84 241 520 84 257 520 minecraft:polished_blackstone_bricks
setblock 85 241 514 minecraft:crying_obsidian
fill 85 241 515 85 257 515 minecraft:polished_blackstone_bricks
setblock 85 241 516 minecraft:crying_obsidian
fill 85 241 517 85 257 517 minecraft:polished_blackstone_bricks
setblock 85 241 518 minecraft:crying_obsidian
fill 85 241 519 85 257 519 minecraft:polished_blackstone_bricks
setblock 85 241 520 minecraft:crying_obsidian
fill 86 241 514 86 257 514 minecraft:polished_blackstone_bricks
setblock 86 241 515 minecraft:crying_obsidian
fill 86 241 516 86 257 516 minecraft:polished_blackstone_bricks
setblock 86 241 517 minecraft:crying_obsidian
fill 86 241 518 86 257 518 minecraft:polished_blackstone_bricks
setblock 86 241 519 minecraft:crying_obsidian
fill 86 241 520 86 257 520 minecraft:polished_blackstone_bricks
setblock 87 241 514 minecraft:crying_obsidian
fill 87 241 515 87 257 515 minecraft:polished_blackstone_bricks
setblock 87 241 516 minecraft:crying_obsidian
fill 87 241 517 87 257 517 minecraft:polished_blackstone_bricks
setblock 87 241 518 minecraft:crying_obsidian
fill 87 241 519 87 257 519 minecraft:polished_blackstone_bricks
setblock 87 241 520 minecraft:crying_obsidian
fill 88 241 514 88 244 514 minecraft:polished_blackstone_bricks
setblock 88 241 515 minecraft:crying_obsidian
fill 88 241 516 88 244 516 minecraft:polished_blackstone_bricks
setblock 88 241 517 minecraft:crying_obsidian
fill 88 241 518 88 257 518 minecraft:polished_blackstone_bricks
setblock 88 241 519 minecraft:crying_obsidian
fill 88 241 520 88 273 520 minecraft:polished_blackstone_bricks
fill 80 242 515 80 243 515 minecraft:polished_blackstone_bricks
fill 80 242 517 80 243 517 minecraft:polished_blackstone_bricks
fill 80 242 519 80 243 519 minecraft:polished_blackstone_bricks
fill 81 242 514 81 243 514 minecraft:polished_blackstone_bricks
fill 81 242 516 81 243 516 minecraft:polished_blackstone_bricks
fill 81 242 518 81 243 518 minecraft:polished_blackstone_bricks
fill 81 242 520 81 243 520 minecraft:polished_blackstone_bricks
fill 82 242 515 82 243 515 minecraft:polished_blackstone_bricks
fill 82 242 517 82 243 517 minecraft:polished_blackstone_bricks
fill 82 242 519 82 243 519 minecraft:polished_blackstone_bricks
fill 83 242 514 83 243 514 minecraft:polished_blackstone_bricks
fill 83 242 516 83 243 516 minecraft:polished_blackstone_bricks
fill 83 242 518 83 243 518 minecraft:polished_blackstone_bricks
fill 83 242 520 83 243 520 minecraft:polished_blackstone_bricks
fill 84 242 515 84 243 515 minecraft:polished_blackstone_bricks
fill 84 242 517 84 243 517 minecraft:polished_blackstone_bricks
fill 84 242 519 84 243 519 minecraft:polished_blackstone_bricks
fill 85 242 514 85 243 514 minecraft:polished_blackstone_bricks
fill 85 242 516 85 243 516 minecraft:polished_blackstone_bricks
fill 85 242 518 85 243 518 minecraft:polished_blackstone_bricks
fill 85 242 520 85 243 520 minecraft:polished_blackstone_bricks
fill 86 242 515 86 243 515 minecraft:polished_blackstone_bricks
fill 86 242 517 86 243 517 minecraft:polished_blackstone_bricks
fill 86 242 519 86 243 519 minecraft:polished_blackstone_bricks
fill 87 242 514 87 243 514 minecraft:polished_blackstone_bricks
fill 87 242 516 87 243 516 minecraft:polished_blackstone_bricks
fill 87 242 518 87 243 518 minecraft:polished_blackstone_bricks
fill 87 242 520 87 243 520 minecraft:polished_blackstone_bricks
fill 88 242 515 88 243 515 minecraft:polished_blackstone_bricks
fill 88 242 517 88 243 517 minecraft:polished_blackstone_bricks
fill 88 242 519 88 243 519 minecraft:polished_blackstone_bricks
setblock 50 243 513 minecraft:light[level=11]
setblock 50 243 521 minecraft:light[level=11]
setblock 50 243 529 minecraft:light[level=11]
setblock 50 243 537 minecraft:light[level=11]
setblock 50 243 545 minecraft:light[level=11]
setblock 58 243 513 minecraft:light[level=11]
setblock 58 243 521 minecraft:light[level=11]
setblock 58 243 529 minecraft:light[level=11]
setblock 58 243 537 minecraft:light[level=11]
setblock 58 243 545 minecraft:light[level=11]
setblock 66 243 513 minecraft:light[level=11]
setblock 66 243 521 minecraft:light[level=11]
setblock 66 243 529 minecraft:light[level=11]
setblock 66 243 537 minecraft:light[level=11]
setblock 66 243 545 minecraft:light[level=11]
setblock 74 243 513 minecraft:light[level=11]
setblock 74 243 521 minecraft:light[level=11]
setblock 74 243 529 minecraft:light[level=11]
setblock 74 243 537 minecraft:light[level=11]
setblock 74 243 545 minecraft:light[level=11]
setblock 82 243 513 minecraft:light[level=11]
setblock 82 243 521 minecraft:light[level=11]
setblock 82 243 529 minecraft:light[level=11]
setblock 82 243 537 minecraft:light[level=11]
setblock 82 243 545 minecraft:light[level=11]
setblock 80 244 515 minecraft:crying_obsidian
setblock 80 244 517 minecraft:crying_obsidian
setblock 80 244 519 minecraft:crying_obsidian
setblock 81 244 514 minecraft:crying_obsidian
setblock 81 244 516 minecraft:crying_obsidian
setblock 81 244 518 minecraft:crying_obsidian
setblock 81 244 520 minecraft:crying_obsidian
setblock 82 244 515 minecraft:crying_obsidian
setblock 82 244 517 minecraft:crying_obsidian
setblock 82 244 519 minecraft:crying_obsidian
setblock 83 244 514 minecraft:crying_obsidian
setblock 83 244 516 minecraft:crying_obsidian
setblock 83 244 518 minecraft:crying_obsidian
setblock 83 244 520 minecraft:crying_obsidian
setblock 84 244 515 minecraft:crying_obsidian
setblock 84 244 517 minecraft:crying_obsidian
setblock 84 244 519 minecraft:crying_obsidian
setblock 85 244 514 minecraft:crying_obsidian
setblock 85 244 516 minecraft:crying_obsidian
setblock 85 244 518 minecraft:crying_obsidian
setblock 85 244 520 minecraft:crying_obsidian
setblock 86 244 515 minecraft:crying_obsidian
setblock 86 244 517 minecraft:crying_obsidian
setblock 86 244 519 minecraft:crying_obsidian
setblock 87 244 514 minecraft:crying_obsidian
setblock 87 244 516 minecraft:crying_obsidian
setblock 87 244 518 minecraft:crying_obsidian
setblock 87 244 520 minecraft:crying_obsidian
setblock 88 244 515 minecraft:crying_obsidian
setblock 88 244 517 minecraft:crying_obsidian
setblock 88 244 519 minecraft:crying_obsidian
fill 48 245 514 48 245 519 minecraft:blackstone
fill 48 245 526 48 245 531 minecraft:blackstone
fill 48 245 538 48 245 543 minecraft:blackstone
fill 48 245 550 48 245 551 minecraft:blackstone
fill 49 245 551 52 245 551 minecraft:blackstone
fill 52 245 511 57 245 511 minecraft:blackstone
fill 59 245 551 64 245 551 minecraft:blackstone
fill 64 245 511 69 245 511 minecraft:blackstone
fill 71 245 551 76 245 551 minecraft:blackstone
fill 76 245 511 81 245 511 minecraft:blackstone
fill 80 245 515 80 246 515 minecraft:polished_blackstone_bricks
fill 80 245 517 80 246 517 minecraft:polished_blackstone_bricks
fill 80 245 519 80 246 519 minecraft:polished_blackstone_bricks
fill 81 245 514 81 246 514 minecraft:polished_blackstone_bricks
fill 81 245 516 81 246 516 minecraft:polished_blackstone_bricks
fill 81 245 518 81 246 518 minecraft:polished_blackstone_bricks
fill 81 245 520 81 246 520 minecraft:polished_blackstone_bricks
fill 82 245 515 82 246 515 minecraft:polished_blackstone_bricks
fill 82 245 517 82 246 517 minecraft:polished_blackstone_bricks
fill 82 245 519 82 246 519 minecraft:polished_blackstone_bricks
fill 83 245 514 83 246 514 minecraft:polished_blackstone_bricks
fill 83 245 516 83 246 516 minecraft:polished_blackstone_bricks
fill 83 245 518 83 246 518 minecraft:polished_blackstone_bricks
fill 83 245 520 83 246 520 minecraft:polished_blackstone_bricks
fill 83 245 551 88 245 551 minecraft:blackstone
fill 84 245 515 84 246 515 minecraft:polished_blackstone_bricks
fill 84 245 517 84 246 517 minecraft:polished_blackstone_bricks
fill 84 245 519 84 246 519 minecraft:polished_blackstone_bricks
fill 85 245 514 85 246 514 minecraft:polished_blackstone_bricks
fill 85 245 516 85 246 516 minecraft:polished_blackstone_bricks
fill 85 245 518 85 246 518 minecraft:polished_blackstone_bricks
fill 85 245 520 85 246 520 minecraft:polished_blackstone_bricks
fill 86 245 515 86 246 515 minecraft:polished_blackstone_bricks
fill 86 245 517 86 246 517 minecraft:polished_blackstone_bricks
fill 86 245 519 86 246 519 minecraft:polished_blackstone_bricks
fill 87 245 514 87 246 514 minecraft:polished_blackstone_bricks
fill 87 245 516 87 246 516 minecraft:polished_blackstone_bricks
fill 87 245 518 87 246 518 minecraft:polished_blackstone_bricks
fill 87 245 520 87 246 520 minecraft:polished_blackstone_bricks
fill 88 245 511 88 245 516 minecraft:blackstone
fill 88 245 517 88 246 517 minecraft:polished_blackstone_bricks
fill 88 245 519 88 246 519 minecraft:polished_blackstone_bricks
fill 88 245 523 88 245 528 minecraft:blackstone
fill 88 245 535 88 245 540 minecraft:blackstone
fill 88 245 547 88 245 550 minecraft:blackstone
fill 47 246 516 47 251 519 minecraft:crying_obsidian
fill 47 246 528 47 251 531 minecraft:crying_obsidian
fill 47 246 540 47 251 543 minecraft:crying_obsidian
fill 47 246 552 50 251 552 minecraft:crying_obsidian
fill 54 246 510 57 251 510 minecraft:crying_obsidian
fill 59 246 552 62 251 552 minecraft:crying_obsidian
fill 66 246 510 69 251 510 minecraft:crying_obsidian
fill 71 246 552 74 251 552 minecraft:crying_obsidian
fill 78 246 510 81 251 510 minecraft:crying_obsidian
fill 83 246 552 86 251 552 minecraft:crying_obsidian
fill 88 246 514 88 246 516 minecraft:polished_blackstone_bricks
fill 89 246 511 89 251 514 minecraft:crying_obsidian
fill 89 246 523 89 251 526 minecraft:crying_obsidian
fill 89 246 535 89 251 538 minecraft:crying_obsidian
fill 89 246 547 89 251 550 minecraft:crying_obsidian
setblock 80 247 515 minecraft:crying_obsidian
setblock 80 247 517 minecraft:crying_obsidian
setblock 80 247 519 minecraft:crying_obsidian
setblock 81 247 514 minecraft:crying_obsidian
setblock 81 247 516 minecraft:crying_obsidian
setblock 81 247 518 minecraft:crying_obsidian
setblock 81 247 520 minecraft:crying_obsidian
setblock 82 247 515 minecraft:crying_obsidian
setblock 82 247 517 minecraft:crying_obsidian
setblock 82 247 519 minecraft:crying_obsidian
setblock 83 247 514 minecraft:crying_obsidian
setblock 83 247 516 minecraft:crying_obsidian
setblock 83 247 518 minecraft:crying_obsidian
setblock 83 247 520 minecraft:crying_obsidian
setblock 84 247 515 minecraft:crying_obsidian
setblock 84 247 517 minecraft:crying_obsidian
setblock 84 247 519 minecraft:crying_obsidian
setblock 85 247 514 minecraft:crying_obsidian
setblock 85 247 516 minecraft:crying_obsidian
setblock 85 247 518 minecraft:crying_obsidian
setblock 85 247 520 minecraft:crying_obsidian
setblock 86 247 515 minecraft:crying_obsidian
setblock 86 247 517 minecraft:crying_obsidian
setblock 86 247 519 minecraft:crying_obsidian
setblock 87 247 514 minecraft:crying_obsidian
setblock 87 247 516 minecraft:crying_obsidian
setblock 87 247 518 minecraft:crying_obsidian
setblock 87 247 520 minecraft:crying_obsidian
fill 88 247 514 88 257 514 minecraft:polished_blackstone_bricks
setblock 88 247 515 minecraft:crying_obsidian
fill 88 247 516 88 257 516 minecraft:polished_blackstone_bricks
setblock 88 247 517 minecraft:crying_obsidian
setblock 88 247 519 minecraft:crying_obsidian
fill 80 248 515 80 249 515 minecraft:polished_blackstone_bricks
fill 80 248 517 80 249 517 minecraft:polished_blackstone_bricks
fill 80 248 519 80 249 519 minecraft:polished_blackstone_bricks
fill 81 248 514 81 249 514 minecraft:polished_blackstone_bricks
fill 81 248 516 81 249 516 minecraft:polished_blackstone_bricks
fill 81 248 518 81 249 518 minecraft:polished_blackstone_bricks
fill 81 248 520 81 249 520 minecraft:polished_blackstone_bricks
fill 82 248 515 82 249 515 minecraft:polished_blackstone_bricks
fill 82 248 517 82 249 517 minecraft:polished_blackstone_bricks
fill 82 248 519 82 249 519 minecraft:polished_blackstone_bricks
fill 83 248 514 83 249 514 minecraft:polished_blackstone_bricks
fill 83 248 516 83 249 516 minecraft:polished_blackstone_bricks
fill 83 248 518 83 249 518 minecraft:polished_blackstone_bricks
fill 83 248 520 83 249 520 minecraft:polished_blackstone_bricks
setblock 83 248 545 minecraft:blackstone
setblock 83 248 548 minecraft:blackstone
fill 84 248 515 84 249 515 minecraft:polished_blackstone_bricks
fill 84 248 517 84 249 517 minecraft:polished_blackstone_bricks
fill 84 248 519 84 249 519 minecraft:polished_blackstone_bricks
fill 84 248 544 85 248 544 minecraft:blackstone
fill 85 248 514 85 249 514 minecraft:polished_blackstone_bricks
fill 85 248 516 85 249 516 minecraft:polished_blackstone_bricks
fill 85 248 518 85 249 518 minecraft:polished_blackstone_bricks
fill 85 248 520 85 249 520 minecraft:polished_blackstone_bricks
setblock 85 248 549 minecraft:blackstone
fill 86 248 515 86 249 515 minecraft:polished_blackstone_bricks
fill 86 248 517 86 249 517 minecraft:polished_blackstone_bricks
fill 86 248 519 86 249 519 minecraft:polished_blackstone_bricks
setblock 86 248 545 minecraft:blackstone
setblock 86 248 548 minecraft:blackstone
fill 87 248 514 87 249 514 minecraft:polished_blackstone_bricks
fill 87 248 516 87 249 516 minecraft:polished_blackstone_bricks
fill 87 248 518 87 249 518 minecraft:polished_blackstone_bricks
fill 87 248 520 87 249 520 minecraft:polished_blackstone_bricks
fill 87 248 546 87 248 547 minecraft:blackstone
fill 88 248 515 88 249 515 minecraft:polished_blackstone_bricks
fill 88 248 517 88 249 517 minecraft:polished_blackstone_bricks
fill 88 248 519 88 249 519 minecraft:polished_blackstone_bricks
setblock 80 250 515 minecraft:crying_obsidian
setblock 80 250 517 minecraft:crying_obsidian
setblock 80 250 519 minecraft:crying_obsidian
setblock 81 250 514 minecraft:crying_obsidian
setblock 81 250 516 minecraft:crying_obsidian
setblock 81 250 518 minecraft:crying_obsidian
setblock 81 250 520 minecraft:crying_obsidian
setblock 82 250 515 minecraft:crying_obsidian
setblock 82 250 517 minecraft:crying_obsidian
setblock 82 250 519 minecraft:crying_obsidian
setblock 83 250 514 minecraft:crying_obsidian
setblock 83 250 516 minecraft:crying_obsidian
setblock 83 250 518 minecraft:crying_obsidian
setblock 83 250 520 minecraft:crying_obsidian
setblock 84 250 515 minecraft:crying_obsidian
setblock 84 250 517 minecraft:crying_obsidian
setblock 84 250 519 minecraft:crying_obsidian
setblock 85 250 514 minecraft:crying_obsidian
setblock 85 250 516 minecraft:crying_obsidian
setblock 85 250 518 minecraft:crying_obsidian
setblock 85 250 520 minecraft:crying_obsidian
setblock 86 250 515 minecraft:crying_obsidian
setblock 86 250 517 minecraft:crying_obsidian
setblock 86 250 519 minecraft:crying_obsidian
setblock 87 250 514 minecraft:crying_obsidian
setblock 87 250 516 minecraft:crying_obsidian
setblock 87 250 518 minecraft:crying_obsidian
setblock 87 250 520 minecraft:crying_obsidian
setblock 88 250 515 minecraft:crying_obsidian
setblock 88 250 517 minecraft:crying_obsidian
setblock 88 250 519 minecraft:crying_obsidian
setblock 50 251 513 minecraft:light[level=11]
setblock 50 251 521 minecraft:light[level=11]
setblock 50 251 529 minecraft:light[level=11]
setblock 50 251 537 minecraft:light[level=11]
setblock 50 251 545 minecraft:light[level=11]
setblock 58 251 513 minecraft:light[level=11]
setblock 58 251 521 minecraft:light[level=11]
setblock 58 251 529 minecraft:light[level=11]
setblock 58 251 537 minecraft:light[level=11]
setblock 58 251 545 minecraft:light[level=11]
setblock 66 251 513 minecraft:light[level=11]
setblock 66 251 521 minecraft:light[level=11]
setblock 66 251 529 minecraft:light[level=11]
setblock 66 251 537 minecraft:light[level=11]
setblock 66 251 545 minecraft:light[level=11]
setblock 74 251 513 minecraft:light[level=11]
setblock 74 251 521 minecraft:light[level=11]
setblock 74 251 529 minecraft:light[level=11]
setblock 74 251 537 minecraft:light[level=11]
setblock 74 251 545 minecraft:light[level=11]
fill 80 251 515 80 252 515 minecraft:polished_blackstone_bricks
fill 80 251 517 80 252 517 minecraft:polished_blackstone_bricks
fill 80 251 519 80 252 519 minecraft:polished_blackstone_bricks
fill 81 251 514 81 252 514 minecraft:polished_blackstone_bricks
fill 81 251 516 81 252 516 minecraft:polished_blackstone_bricks
fill 81 251 518 81 252 518 minecraft:polished_blackstone_bricks
fill 81 251 520 81 252 520 minecraft:polished_blackstone_bricks
setblock 82 251 513 minecraft:light[level=11]
fill 82 251 515 82 252 515 minecraft:polished_blackstone_bricks
fill 82 251 517 82 252 517 minecraft:polished_blackstone_bricks
fill 82 251 519 82 252 519 minecraft:polished_blackstone_bricks
setblock 82 251 521 minecraft:light[level=11]
setblock 82 251 529 minecraft:light[level=11]
setblock 82 251 537 minecraft:light[level=11]
setblock 82 251 545 minecraft:light[level=11]
fill 83 251 514 83 252 514 minecraft:polished_blackstone_bricks
fill 83 251 516 83 252 516 minecraft:polished_blackstone_bricks
fill 83 251 518 83 252 518 minecraft:polished_blackstone_bricks
fill 83 251 520 83 252 520 minecraft:polished_blackstone_bricks
fill 84 251 515 84 252 515 minecraft:polished_blackstone_bricks
fill 84 251 517 84 252 517 minecraft:polished_blackstone_bricks
fill 84 251 519 84 252 519 minecraft:polished_blackstone_bricks
fill 85 251 514 85 252 514 minecraft:polished_blackstone_bricks
fill 85 251 516 85 252 516 minecraft:polished_blackstone_bricks
fill 85 251 518 85 252 518 minecraft:polished_blackstone_bricks
fill 85 251 520 85 252 520 minecraft:polished_blackstone_bricks
fill 86 251 515 86 252 515 minecraft:polished_blackstone_bricks
fill 86 251 517 86 252 517 minecraft:polished_blackstone_bricks
fill 86 251 519 86 252 519 minecraft:polished_blackstone_bricks
fill 87 251 514 87 252 514 minecraft:polished_blackstone_bricks
fill 87 251 516 87 252 516 minecraft:polished_blackstone_bricks
fill 87 251 518 87 252 518 minecraft:polished_blackstone_bricks
fill 87 251 520 87 252 520 minecraft:polished_blackstone_bricks
fill 88 251 515 88 252 515 minecraft:polished_blackstone_bricks
fill 88 251 517 88 252 517 minecraft:polished_blackstone_bricks
fill 88 251 519 88 252 519 minecraft:polished_blackstone_bricks
fill 47 252 516 47 265 516 minecraft:blackstone
fill 47 252 517 47 252 518 minecraft:crying_obsidian
fill 47 252 519 47 265 519 minecraft:blackstone
fill 47 252 528 47 265 528 minecraft:blackstone
fill 47 252 529 47 252 530 minecraft:crying_obsidian
fill 47 252 531 47 265 531 minecraft:blackstone
fill 47 252 540 47 265 540 minecraft:blackstone
fill 47 252 541 47 252 542 minecraft:crying_obsidian
fill 47 252 543 47 265 543 minecraft:blackstone
fill 47 252 552 47 265 552 minecraft:blackstone
fill 48 252 552 49 252 552 minecraft:crying_obsidian
fill 50 252 552 50 265 552 minecraft:blackstone
fill 54 252 510 54 265 510 minecraft:blackstone
fill 55 252 510 56 252 510 minecraft:crying_obsidian
fill 57 252 510 57 265 510 minecraft:blackstone
fill 59 252 552 59 265 552 minecraft:blackstone
fill 60 252 552 61 252 552 minecraft:crying_obsidian
fill 62 252 552 62 265 552 minecraft:blackstone
fill 66 252 510 66 265 510 minecraft:blackstone
fill 67 252 510 68 252 510 minecraft:crying_obsidian
fill 69 252 510 69 265 510 minecraft:blackstone
fill 71 252 552 71 265 552 minecraft:blackstone
fill 72 252 552 73 252 552 minecraft:crying_obsidian
fill 74 252 552 74 265 552 minecraft:blackstone
fill 78 252 510 78 265 510 minecraft:blackstone
fill 79 252 510 80 252 510 minecraft:crying_obsidian
fill 81 252 510 81 265 510 minecraft:blackstone
fill 83 252 552 83 265 552 minecraft:blackstone
fill 84 252 552 85 252 552 minecraft:crying_obsidian
fill 86 252 552 86 265 552 minecraft:blackstone
fill 89 252 511 89 265 511 minecraft:blackstone
fill 89 252 512 89 252 513 minecraft:crying_obsidian
fill 89 252 514 89 265 514 minecraft:blackstone
fill 89 252 523 89 265 523 minecraft:blackstone
fill 89 252 524 89 252 525 minecraft:crying_obsidian
fill 89 252 526 89 265 526 minecraft:blackstone
fill 89 252 535 89 265 535 minecraft:blackstone
fill 89 252 536 89 252 537 minecraft:crying_obsidian
fill 89 252 538 89 265 538 minecraft:blackstone
fill 89 252 547 89 265 547 minecraft:blackstone
fill 89 252 548 89 252 549 minecraft:crying_obsidian
fill 89 252 550 89 265 550 minecraft:blackstone
fill 47 253 517 47 265 518 minecraft:blackstone
fill 47 253 529 47 265 530 minecraft:blackstone
fill 47 253 541 47 265 542 minecraft:blackstone
fill 48 253 552 49 265 552 minecraft:blackstone
fill 55 253 510 56 265 510 minecraft:blackstone
fill 60 253 552 61 265 552 minecraft:blackstone
fill 67 253 510 68 265 510 minecraft:blackstone
fill 72 253 552 73 265 552 minecraft:blackstone
fill 79 253 510 80 265 510 minecraft:blackstone
setblock 80 253 515 minecraft:crying_obsidian
setblock 80 253 517 minecraft:crying_obsidian
setblock 80 253 519 minecraft:crying_obsidian
setblock 81 253 514 minecraft:crying_obsidian
setblock 81 253 516 minecraft:crying_obsidian
setblock 81 253 518 minecraft:crying_obsidian
setblock 81 253 520 minecraft:crying_obsidian
setblock 82 253 515 minecraft:crying_obsidian
setblock 82 253 517 minecraft:crying_obsidian
setblock 82 253 519 minecraft:crying_obsidian
setblock 83 253 514 minecraft:crying_obsidian
setblock 83 253 516 minecraft:crying_obsidian
setblock 83 253 518 minecraft:crying_obsidian
setblock 83 253 520 minecraft:crying_obsidian
setblock 84 253 515 minecraft:crying_obsidian
setblock 84 253 517 minecraft:crying_obsidian
setblock 84 253 519 minecraft:crying_obsidian
fill 84 253 552 85 265 552 minecraft:blackstone
setblock 85 253 514 minecraft:crying_obsidian
setblock 85 253 516 minecraft:crying_obsidian
setblock 85 253 518 minecraft:crying_obsidian
setblock 85 253 520 minecraft:crying_obsidian
setblock 86 253 515 minecraft:crying_obsidian
setblock 86 253 517 minecraft:crying_obsidian
setblock 86 253 519 minecraft:crying_obsidian
setblock 87 253 514 minecraft:crying_obsidian
setblock 87 253 516 minecraft:crying_obsidian
setblock 87 253 518 minecraft:crying_obsidian
setblock 87 253 520 minecraft:crying_obsidian
setblock 88 253 515 minecraft:crying_obsidian
setblock 88 253 517 minecraft:crying_obsidian
setblock 88 253 519 minecraft:crying_obsidian
fill 89 253 512 89 265 513 minecraft:blackstone
fill 89 253 524 89 265 525 minecraft:blackstone
fill 89 253 536 89 265 537 minecraft:blackstone
fill 89 253 548 89 265 549 minecraft:blackstone
fill 80 254 515 80 255 515 minecraft:polished_blackstone_bricks
fill 80 254 517 80 255 517 minecraft:polished_blackstone_bricks
fill 80 254 519 80 255 519 minecraft:polished_blackstone_bricks
fill 81 254 514 81 255 514 minecraft:polished_blackstone_bricks
fill 81 254 516 81 255 516 minecraft:polished_blackstone_bricks
fill 81 254 518 81 255 518 minecraft:polished_blackstone_bricks
fill 81 254 520 81 255 520 minecraft:polished_blackstone_bricks
fill 82 254 515 82 255 515 minecraft:polished_blackstone_bricks
fill 82 254 517 82 255 517 minecraft:polished_blackstone_bricks
fill 82 254 519 82 255 519 minecraft:polished_blackstone_bricks
fill 83 254 514 83 255 514 minecraft:polished_blackstone_bricks
fill 83 254 516 83 255 516 minecraft:polished_blackstone_bricks
fill 83 254 518 83 255 518 minecraft:polished_blackstone_bricks
fill 83 254 520 83 255 520 minecraft:polished_blackstone_bricks
fill 84 254 515 84 255 515 minecraft:polished_blackstone_bricks
fill 84 254 517 84 255 517 minecraft:polished_blackstone_bricks
fill 84 254 519 84 255 519 minecraft:polished_blackstone_bricks
fill 85 254 514 85 255 514 minecraft:polished_blackstone_bricks
fill 85 254 516 85 255 516 minecraft:polished_blackstone_bricks
fill 85 254 518 85 255 518 minecraft:polished_blackstone_bricks
fill 85 254 520 85 255 520 minecraft:polished_blackstone_bricks
fill 86 254 515 86 255 515 minecraft:polished_blackstone_bricks
fill 86 254 517 86 255 517 minecraft:polished_blackstone_bricks
fill 86 254 519 86 255 519 minecraft:polished_blackstone_bricks
fill 87 254 514 87 255 514 minecraft:polished_blackstone_bricks
fill 87 254 516 87 255 516 minecraft:polished_blackstone_bricks
fill 87 254 518 87 255 518 minecraft:polished_blackstone_bricks
fill 87 254 520 87 255 520 minecraft:polished_blackstone_bricks
fill 88 254 515 88 255 515 minecraft:polished_blackstone_bricks
fill 88 254 517 88 255 517 minecraft:polished_blackstone_bricks
fill 88 254 519 88 255 519 minecraft:polished_blackstone_bricks
setblock 80 256 515 minecraft:crying_obsidian
setblock 80 256 517 minecraft:crying_obsidian
setblock 80 256 519 minecraft:crying_obsidian
setblock 81 256 514 minecraft:crying_obsidian
setblock 81 256 516 minecraft:crying_obsidian
setblock 81 256 518 minecraft:crying_obsidian
setblock 81 256 520 minecraft:crying_obsidian
setblock 82 256 515 minecraft:crying_obsidian
setblock 82 256 517 minecraft:crying_obsidian
setblock 82 256 519 minecraft:crying_obsidian
setblock 83 256 514 minecraft:crying_obsidian
setblock 83 256 516 minecraft:crying_obsidian
setblock 83 256 518 minecraft:crying_obsidian
setblock 83 256 520 minecraft:crying_obsidian
setblock 83 256 545 minecraft:blackstone
setblock 83 256 548 minecraft:blackstone
setblock 84 256 515 minecraft:crying_obsidian
setblock 84 256 517 minecraft:crying_obsidian
setblock 84 256 519 minecraft:crying_obsidian
fill 84 256 544 85 256 544 minecraft:blackstone
setblock 85 256 514 minecraft:crying_obsidian
setblock 85 256 516 minecraft:crying_obsidian
setblock 85 256 518 minecraft:crying_obsidian
setblock 85 256 520 minecraft:crying_obsidian
setblock 85 256 549 minecraft:blackstone
setblock 86 256 515 minecraft:crying_obsidian
setblock 86 256 517 minecraft:crying_obsidian
setblock 86 256 519 minecraft:crying_obsidian
setblock 86 256 545 minecraft:blackstone
setblock 86 256 548 minecraft:blackstone
setblock 87 256 514 minecraft:crying_obsidian
setblock 87 256 516 minecraft:crying_obsidian
setblock 87 256 518 minecraft:crying_obsidian
setblock 87 256 520 minecraft:crying_obsidian
fill 87 256 546 87 256 547 minecraft:blackstone
setblock 88 256 515 minecraft:crying_obsidian
setblock 88 256 517 minecraft:crying_obsidian
setblock 88 256 519 minecraft:crying_obsidian
setblock 80 257 515 minecraft:polished_blackstone_bricks
setblock 80 257 517 minecraft:polished_blackstone_bricks
setblock 80 257 519 minecraft:polished_blackstone_bricks
setblock 81 257 514 minecraft:polished_blackstone_bricks
setblock 81 257 516 minecraft:polished_blackstone_bricks
setblock 81 257 518 minecraft:polished_blackstone_bricks
setblock 81 257 520 minecraft:polished_blackstone_bricks
setblock 82 257 515 minecraft:polished_blackstone_bricks
setblock 82 257 517 minecraft:polished_blackstone_bricks
setblock 82 257 519 minecraft:polished_blackstone_bricks
setblock 83 257 514 minecraft:polished_blackstone_bricks
setblock 83 257 516 minecraft:polished_blackstone_bricks
setblock 83 257 518 minecraft:polished_blackstone_bricks
setblock 83 257 520 minecraft:polished_blackstone_bricks
setblock 84 257 515 minecraft:polished_blackstone_bricks
setblock 84 257 517 minecraft:polished_blackstone_bricks
setblock 84 257 519 minecraft:polished_blackstone_bricks
setblock 85 257 514 minecraft:polished_blackstone_bricks
setblock 85 257 516 minecraft:polished_blackstone_bricks
setblock 85 257 518 minecraft:polished_blackstone_bricks
setblock 85 257 520 minecraft:polished_blackstone_bricks
setblock 86 257 515 minecraft:polished_blackstone_bricks
setblock 86 257 517 minecraft:polished_blackstone_bricks
setblock 86 257 519 minecraft:polished_blackstone_bricks
setblock 87 257 514 minecraft:polished_blackstone_bricks
setblock 87 257 516 minecraft:polished_blackstone_bricks
setblock 87 257 518 minecraft:polished_blackstone_bricks
setblock 87 257 520 minecraft:polished_blackstone_bricks
setblock 88 257 515 minecraft:polished_blackstone_bricks
setblock 88 257 517 minecraft:polished_blackstone_bricks
fill 88 257 519 88 273 519 minecraft:polished_blackstone_bricks
fill 81 258 515 87 258 519 minecraft:purple_stained_glass
setblock 50 259 513 minecraft:light[level=11]
setblock 50 259 521 minecraft:light[level=11]
setblock 50 259 529 minecraft:light[level=11]
setblock 50 259 537 minecraft:light[level=11]
setblock 50 259 545 minecraft:light[level=11]
setblock 58 259 513 minecraft:light[level=11]
setblock 58 259 521 minecraft:light[level=11]
setblock 58 259 529 minecraft:light[level=11]
setblock 58 259 537 minecraft:light[level=11]
setblock 58 259 545 minecraft:light[level=11]
setblock 66 259 513 minecraft:light[level=11]
setblock 66 259 521 minecraft:light[level=11]
setblock 66 259 529 minecraft:light[level=11]
setblock 66 259 537 minecraft:light[level=11]
setblock 66 259 545 minecraft:light[level=11]
setblock 74 259 513 minecraft:light[level=11]
setblock 74 259 521 minecraft:light[level=11]
setblock 74 259 529 minecraft:light[level=11]
setblock 74 259 537 minecraft:light[level=11]
setblock 74 259 545 minecraft:light[level=11]
setblock 82 259 513 minecraft:light[level=11]
fill 82 259 516 86 259 518 minecraft:purple_stained_glass
setblock 82 259 521 minecraft:light[level=11]
setblock 82 259 529 minecraft:light[level=11]
setblock 82 259 537 minecraft:light[level=11]
setblock 82 259 545 minecraft:light[level=11]
fill 49 260 520 49 265 522 minecraft:polished_blackstone_bricks
fill 49 260 532 49 265 534 minecraft:polished_blackstone_bricks
fill 49 260 544 49 265 546 minecraft:polished_blackstone_bricks
fill 55 260 550 57 265 550 minecraft:polished_blackstone_bricks
fill 59 260 512 61 265 512 minecraft:polished_blackstone_bricks
fill 67 260 550 69 265 550 minecraft:polished_blackstone_bricks
fill 71 260 512 73 265 512 minecraft:polished_blackstone_bricks
fill 79 260 550 81 265 550 minecraft:polished_blackstone_bricks
fill 83 260 512 85 265 512 minecraft:polished_blackstone_bricks
fill 83 260 517 85 260 517 minecraft:purple_stained_glass
fill 87 260 520 87 265 522 minecraft:polished_blackstone_bricks
fill 87 260 532 87 265 534 minecraft:polished_blackstone_bricks
fill 87 260 544 87 265 546 minecraft:polished_blackstone_bricks
fill 84 261 516 84 261 518 minecraft:purple_stained_glass
setblock 83 264 545 minecraft:blackstone
setblock 83 264 548 minecraft:blackstone
fill 84 264 544 85 264 544 minecraft:blackstone
setblock 85 264 549 minecraft:blackstone
setblock 86 264 545 minecraft:blackstone
setblock 86 264 548 minecraft:blackstone
setblock 87 264 547 minecraft:blackstone
fill 48 265 514 48 265 519 minecraft:blackstone
fill 48 265 526 48 265 531 minecraft:blackstone
fill 48 265 538 48 265 543 minecraft:blackstone
fill 48 265 550 48 265 551 minecraft:blackstone
fill 49 265 551 52 265 551 minecraft:blackstone
fill 52 265 511 57 265 511 minecraft:blackstone
fill 59 265 551 64 265 551 minecraft:blackstone
fill 64 265 511 69 265 511 minecraft:blackstone
fill 71 265 551 76 265 551 minecraft:blackstone
fill 76 265 511 81 265 511 minecraft:blackstone
fill 83 265 551 88 265 551 minecraft:blackstone
fill 88 265 511 88 265 516 minecraft:blackstone
fill 88 265 523 88 265 528 minecraft:blackstone
fill 88 265 535 88 265 540 minecraft:blackstone
fill 88 265 547 88 265 550 minecraft:blackstone
fill 47 266 516 47 271 519 minecraft:crying_obsidian
fill 47 266 528 47 271 531 minecraft:crying_obsidian
fill 47 266 540 47 271 543 minecraft:crying_obsidian
fill 47 266 552 50 271 552 minecraft:crying_obsidian
fill 54 266 510 57 271 510 minecraft:crying_obsidian
fill 59 266 552 62 271 552 minecraft:crying_obsidian
fill 66 266 510 69 271 510 minecraft:crying_obsidian
fill 71 266 552 74 271 552 minecraft:crying_obsidian
fill 78 266 510 81 271 510 minecraft:crying_obsidian
fill 83 266 552 86 271 552 minecraft:crying_obsidian
fill 89 266 511 89 271 514 minecraft:crying_obsidian
fill 89 266 523 89 271 526 minecraft:crying_obsidian
fill 89 266 535 89 271 538 minecraft:crying_obsidian
fill 89 266 547 89 271 550 minecraft:crying_obsidian
setblock 50 267 513 minecraft:light[level=11]
setblock 50 267 521 minecraft:light[level=11]
setblock 50 267 529 minecraft:light[level=11]
setblock 50 267 537 minecraft:light[level=11]
setblock 50 267 545 minecraft:light[level=11]
setblock 58 267 513 minecraft:light[level=11]
setblock 58 267 521 minecraft:light[level=11]
setblock 58 267 529 minecraft:light[level=11]
setblock 58 267 537 minecraft:light[level=11]
setblock 58 267 545 minecraft:light[level=11]
setblock 66 267 513 minecraft:light[level=11]
setblock 66 267 521 minecraft:light[level=11]
setblock 66 267 529 minecraft:light[level=11]
setblock 66 267 537 minecraft:light[level=11]
setblock 66 267 545 minecraft:light[level=11]
setblock 74 267 513 minecraft:light[level=11]
setblock 74 267 521 minecraft:light[level=11]
setblock 74 267 529 minecraft:light[level=11]
setblock 74 267 537 minecraft:light[level=11]
setblock 74 267 545 minecraft:light[level=11]
setblock 82 267 513 minecraft:light[level=11]
setblock 82 267 521 minecraft:light[level=11]
setblock 82 267 529 minecraft:light[level=11]
setblock 82 267 537 minecraft:light[level=11]
setblock 82 267 545 minecraft:light[level=11]
fill 47 272 516 47 285 516 minecraft:blackstone
fill 47 272 517 47 272 518 minecraft:crying_obsidian
fill 47 272 519 47 285 519 minecraft:blackstone
fill 47 272 528 47 285 528 minecraft:blackstone
fill 47 272 529 47 272 530 minecraft:crying_obsidian
fill 47 272 531 47 285 531 minecraft:blackstone
fill 47 272 540 47 285 540 minecraft:blackstone
fill 47 272 541 47 272 542 minecraft:crying_obsidian
fill 47 272 543 47 285 543 minecraft:blackstone
fill 47 272 552 47 285 552 minecraft:blackstone
fill 48 272 552 49 272 552 minecraft:crying_obsidian
fill 50 272 552 50 285 552 minecraft:blackstone
fill 54 272 510 54 285 510 minecraft:blackstone
fill 55 272 510 56 272 510 minecraft:crying_obsidian
fill 57 272 510 57 285 510 minecraft:blackstone
fill 59 272 552 59 285 552 minecraft:blackstone
fill 60 272 552 61 272 552 minecraft:crying_obsidian
fill 62 272 552 62 285 552 minecraft:blackstone
fill 66 272 510 66 285 510 minecraft:blackstone
fill 67 272 510 68 272 510 minecraft:crying_obsidian
fill 69 272 510 69 285 510 minecraft:blackstone
fill 71 272 552 71 285 552 minecraft:blackstone
fill 72 272 552 73 272 552 minecraft:crying_obsidian
fill 74 272 552 74 285 552 minecraft:blackstone
fill 78 272 510 78 285 510 minecraft:blackstone
fill 79 272 510 80 272 510 minecraft:crying_obsidian
fill 81 272 510 81 285 510 minecraft:blackstone
setblock 83 272 545 minecraft:blackstone
setblock 83 272 548 minecraft:blackstone
fill 83 272 552 83 285 552 minecraft:blackstone
fill 84 272 544 85 272 544 minecraft:blackstone
fill 84 272 552 85 272 552 minecraft:crying_obsidian
setblock 85 272 549 minecraft:blackstone
setblock 86 272 545 minecraft:blackstone
setblock 86 272 548 minecraft:blackstone
fill 86 272 552 86 285 552 minecraft:blackstone
fill 87 272 546 87 272 547 minecraft:blackstone
fill 89 272 511 89 285 511 minecraft:blackstone
fill 89 272 512 89 272 513 minecraft:crying_obsidian
fill 89 272 514 89 285 514 minecraft:blackstone
fill 89 272 523 89 285 523 minecraft:blackstone
fill 89 272 524 89 272 525 minecraft:crying_obsidian
fill 89 272 526 89 285 526 minecraft:blackstone
fill 89 272 535 89 285 535 minecraft:blackstone
fill 89 272 536 89 272 537 minecraft:crying_obsidian
fill 89 272 538 89 285 538 minecraft:blackstone
fill 89 272 547 89 285 547 minecraft:blackstone
fill 89 272 548 89 272 549 minecraft:crying_obsidian
fill 89 272 550 89 285 550 minecraft:blackstone
fill 47 273 517 47 285 518 minecraft:blackstone
fill 47 273 529 47 285 530 minecraft:blackstone
fill 47 273 541 47 285 542 minecraft:blackstone
fill 48 273 552 49 285 552 minecraft:blackstone
fill 55 273 510 56 285 510 minecraft:blackstone
fill 60 273 552 61 285 552 minecraft:blackstone
fill 67 273 510 68 285 510 minecraft:blackstone
fill 72 273 552 73 285 552 minecraft:blackstone
fill 79 273 510 80 285 510 minecraft:blackstone
setblock 83 273 545 minecraft:purple_stained_glass
setblock 83 273 548 minecraft:purple_stained_glass
fill 84 273 552 85 285 552 minecraft:blackstone
setblock 86 273 545 minecraft:purple_stained_glass
setblock 86 273 548 minecraft:purple_stained_glass
fill 89 273 512 89 285 513 minecraft:blackstone
fill 89 273 524 89 285 525 minecraft:blackstone
fill 89 273 536 89 285 537 minecraft:blackstone
fill 89 273 548 89 285 549 minecraft:blackstone
setblock 50 275 513 minecraft:light[level=11]
setblock 50 275 521 minecraft:light[level=11]
setblock 50 275 529 minecraft:light[level=11]
setblock 50 275 537 minecraft:light[level=11]
setblock 50 275 545 minecraft:light[level=11]
setblock 58 275 513 minecraft:light[level=11]
setblock 58 275 521 minecraft:light[level=11]
setblock 58 275 529 minecraft:light[level=11]
setblock 58 275 537 minecraft:light[level=11]
setblock 58 275 545 minecraft:light[level=11]
setblock 66 275 513 minecraft:light[level=11]
setblock 66 275 521 minecraft:light[level=11]
setblock 66 275 529 minecraft:light[level=11]
setblock 66 275 537 minecraft:light[level=11]
setblock 66 275 545 minecraft:light[level=11]
setblock 74 275 513 minecraft:light[level=11]
setblock 74 275 521 minecraft:light[level=11]
setblock 74 275 529 minecraft:light[level=11]
setblock 74 275 537 minecraft:light[level=11]
setblock 74 275 545 minecraft:light[level=11]
setblock 82 275 513 minecraft:light[level=11]
setblock 82 275 521 minecraft:light[level=11]
setblock 82 275 529 minecraft:light[level=11]
setblock 82 275 537 minecraft:light[level=11]
setblock 82 275 545 minecraft:light[level=11]
fill 48 279 511 68 279 551 minecraft:blackstone
fill 69 279 511 69 279 530 minecraft:blackstone
fill 69 279 531 69 280 531 minecraft:crying_obsidian
fill 69 279 533 69 280 533 minecraft:crying_obsidian
fill 69 279 534 69 279 551 minecraft:blackstone
fill 70 279 511 88 279 529 minecraft:blackstone
fill 70 279 530 70 280 530 minecraft:crying_obsidian
fill 70 279 534 70 280 534 minecraft:crying_obsidian
fill 70 279 535 88 279 551 minecraft:blackstone
fill 72 279 530 72 280 530 minecraft:crying_obsidian
fill 72 279 534 72 280 534 minecraft:crying_obsidian
fill 73 279 530 88 279 530 minecraft:blackstone
fill 73 279 531 73 280 531 minecraft:crying_obsidian
fill 73 279 533 73 280 533 minecraft:crying_obsidian
fill 73 279 534 88 279 534 minecraft:blackstone
fill 74 279 531 88 279 533 minecraft:blackstone
fill 48 280 511 48 292 551 minecraft:blackstone
fill 49 280 511 88 292 511 minecraft:blackstone
fill 49 280 512 67 280 550 minecraft:polished_blackstone_bricks
fill 49 280 551 88 292 551 minecraft:blackstone
fill 68 280 512 68 280 530 minecraft:polished_blackstone_bricks
fill 68 280 531 68 280 533 minecraft:crying_obsidian
fill 68 280 534 68 280 550 minecraft:polished_blackstone_bricks
fill 69 280 512 69 280 529 minecraft:polished_blackstone_bricks
setblock 69 280 530 minecraft:crying_obsidian
setblock 69 280 534 minecraft:crying_obsidian
fill 69 280 535 69 280 550 minecraft:polished_blackstone_bricks
fill 70 280 512 87 281 528 minecraft:polished_blackstone_bricks
fill 70 280 529 72 281 529 minecraft:crying_obsidian
fill 70 280 535 72 281 535 minecraft:crying_obsidian
fill 70 280 536 87 281 550 minecraft:polished_blackstone_bricks
fill 73 280 529 87 281 529 minecraft:polished_blackstone_bricks
fill 73 280 530 73 281 530 minecraft:crying_obsidian
fill 73 280 534 73 282 534 minecraft:crying_obsidian
fill 73 280 535 87 282 535 minecraft:polished_blackstone_bricks
fill 74 280 530 87 281 530 minecraft:polished_blackstone_bricks
fill 74 280 531 74 283 533 minecraft:crying_obsidian
fill 74 280 534 87 282 534 minecraft:polished_blackstone_bricks
fill 75 280 531 87 283 533 minecraft:polished_blackstone_bricks
fill 88 280 512 88 292 550 minecraft:blackstone
fill 49 281 512 66 282 550 minecraft:polished_blackstone_bricks
fill 67 281 512 67 281 530 minecraft:polished_blackstone_bricks
fill 67 281 531 67 282 532 minecraft:crying_obsidian
fill 67 281 533 67 281 550 minecraft:polished_blackstone_bricks
fill 68 281 512 68 281 529 minecraft:polished_blackstone_bricks
setblock 68 281 530 minecraft:crying_obsidian
fill 68 281 533 68 281 534 minecraft:crying_obsidian
fill 68 281 535 68 281 550 minecraft:polished_blackstone_bricks
fill 69 281 512 69 281 528 minecraft:polished_blackstone_bricks
setblock 69 281 529 minecraft:crying_obsidian
fill 69 281 535 69 282 535 minecraft:crying_obsidian
fill 69 281 536 69 282 550 minecraft:polished_blackstone_bricks
fill 67 282 512 67 282 529 minecraft:polished_blackstone_bricks
setblock 67 282 530 minecraft:crying_obsidian
fill 67 282 533 67 282 534 minecraft:crying_obsidian
fill 67 282 535 67 283 550 minecraft:polished_blackstone_bricks
fill 68 282 512 68 282 528 minecraft:polished_blackstone_bricks
setblock 68 282 529 minecraft:crying_obsidian
fill 68 282 535 68 283 535 minecraft:crying_obsidian
fill 68 282 536 68 283 550 minecraft:polished_blackstone_bricks
fill 69 282 512 87 282 527 minecraft:polished_blackstone_bricks
fill 69 282 528 72 282 528 minecraft:crying_obsidian
fill 70 282 536 71 284 536 minecraft:crying_obsidian
fill 70 282 537 87 284 550 minecraft:polished_blackstone_bricks
setblock 72 282 535 minecraft:crying_obsidian
fill 72 282 536 87 282 536 minecraft:polished_blackstone_bricks
fill 73 282 528 87 283 528 minecraft:polished_blackstone_bricks
fill 73 282 529 73 283 529 minecraft:crying_obsidian
fill 74 282 529 87 283 529 minecraft:polished_blackstone_bricks
fill 74 282 530 74 284 530 minecraft:crying_obsidian
fill 75 282 530 87 284 530 minecraft:polished_blackstone_bricks
fill 49 283 512 65 283 550 minecraft:polished_blackstone_bricks
fill 66 283 512 66 283 529 minecraft:polished_blackstone_bricks
fill 66 283 530 66 283 533 minecraft:crying_obsidian
fill 66 283 534 66 283 550 minecraft:polished_blackstone_bricks
fill 67 283 512 67 283 528 minecraft:polished_blackstone_bricks
setblock 67 283 529 minecraft:crying_obsidian
setblock 67 283 534 minecraft:crying_obsidian
fill 68 283 512 69 283 527 minecraft:polished_blackstone_bricks
fill 68 283 528 69 283 528 minecraft:crying_obsidian
fill 69 283 536 69 284 536 minecraft:crying_obsidian
fill 69 283 537 69 284 550 minecraft:polished_blackstone_bricks
fill 70 283 512 87 284 526 minecraft:polished_blackstone_bricks
fill 70 283 527 70 284 527 minecraft:crying_obsidian
fill 71 283 527 87 283 527 minecraft:polished_blackstone_bricks
fill 71 283 528 72 283 528 minecraft:crying_obsidian
fill 72 283 536 72 286 536 minecraft:crying_obsidian
fill 73 283 535 73 285 535 minecraft:crying_obsidian
fill 73 283 536 87 285 536 minecraft:polished_blackstone_bricks
fill 74 283 534 74 286 534 minecraft:crying_obsidian
fill 74 283 535 87 285 535 minecraft:polished_blackstone_bricks
fill 75 283 534 87 286 534 minecraft:polished_blackstone_bricks
fill 49 284 512 64 285 550 minecraft:polished_blackstone_bricks
fill 65 284 512 65 284 530 minecraft:polished_blackstone_bricks
fill 65 284 531 65 285 533 minecraft:crying_obsidian
fill 65 284 534 65 284 550 minecraft:polished_blackstone_bricks
fill 66 284 512 66 284 528 minecraft:polished_blackstone_bricks
fill 66 284 529 66 284 530 minecraft:crying_obsidian
setblock 66 284 534 minecraft:crying_obsidian
fill 66 284 535 66 284 550 minecraft:polished_blackstone_bricks
fill 67 284 512 67 284 527 minecraft:polished_blackstone_bricks
setblock 67 284 528 minecraft:crying_obsidian
setblock 67 284 535 minecraft:crying_obsidian
fill 67 284 536 67 284 550 minecraft:polished_blackstone_bricks
fill 68 284 512 69 284 526 minecraft:polished_blackstone_bricks
fill 68 284 527 69 284 527 minecraft:crying_obsidian
fill 68 284 536 68 285 536 minecraft:crying_obsidian
fill 68 284 537 68 285 550 minecraft:polished_blackstone_bricks
fill 71 284 527 72 285 527 minecraft:crying_obsidian
fill 73 284 527 87 285 527 minecraft:polished_blackstone_bricks
fill 73 284 528 73 285 528 minecraft:crying_obsidian
fill 74 284 528 87 285 528 minecraft:polished_blackstone_bricks
fill 74 284 529 74 286 529 minecraft:crying_obsidian
setblock 74 284 533 minecraft:crying_obsidian
fill 75 284 529 87 286 529 minecraft:polished_blackstone_bricks
fill 75 284 531 75 287 532 minecraft:crying_obsidian
fill 75 284 533 87 284 533 minecraft:polished_blackstone_bricks
fill 76 284 531 87 287 532 minecraft:polished_blackstone_bricks
fill 65 285 512 65 285 528 minecraft:polished_blackstone_bricks
fill 65 285 529 65 285 530 minecraft:crying_obsidian
fill 65 285 534 65 286 534 minecraft:crying_obsidian
fill 65 285 535 65 285 550 minecraft:polished_blackstone_bricks
fill 66 285 512 66 285 527 minecraft:polished_blackstone_bricks
setblock 66 285 528 minecraft:crying_obsidian
setblock 66 285 535 minecraft:crying_obsidian
fill 66 285 536 66 285 550 minecraft:polished_blackstone_bricks
fill 67 285 512 68 285 526 minecraft:polished_blackstone_bricks
fill 67 285 527 68 285 527 minecraft:crying_obsidian
fill 67 285 536 67 286 536 minecraft:crying_obsidian
fill 67 285 537 67 286 550 minecraft:polished_blackstone_bricks
fill 69 285 512 87 286 525 minecraft:polished_blackstone_bricks
fill 69 285 526 70 286 526 minecraft:crying_obsidian
fill 69 285 537 71 287 537 minecraft:crying_obsidian
fill 69 285 538 87 287 550 minecraft:polished_blackstone_bricks
fill 71 285 526 87 285 526 minecraft:polished_blackstone_bricks
fill 72 285 537 87 286 537 minecraft:polished_blackstone_bricks
fill 75 285 530 75 288 530 minecraft:crying_obsidian
fill 75 285 533 75 288 533 minecraft:crying_obsidian
fill 76 285 530 87 288 530 minecraft:polished_blackstone_bricks
fill 76 285 533 87 288 533 minecraft:polished_blackstone_bricks
fill 47 286 516 47 291 519 minecraft:crying_obsidian
fill 47 286 528 47 291 531 minecraft:crying_obsidian
fill 47 286 540 47 291 543 minecraft:crying_obsidian
fill 47 286 552 50 291 552 minecraft:crying_obsidian
fill 49 286 512 63 286 550 minecraft:polished_blackstone_bricks
fill 54 286 510 57 291 510 minecraft:crying_obsidian
fill 59 286 552 62 291 552 minecraft:crying_obsidian
fill 64 286 512 64 286 529 minecraft:polished_blackstone_bricks
fill 64 286 530 64 286 533 minecraft:crying_obsidian
fill 64 286 534 64 286 550 minecraft:polished_blackstone_bricks
fill 65 286 512 65 286 527 minecraft:polished_blackstone_bricks
fill 65 286 528 65 286 529 minecraft:crying_obsidian
fill 65 286 535 65 287 535 minecraft:crying_obsidian
fill 65 286 536 65 287 550 minecraft:polished_blackstone_bricks
fill 66 286 510 69 291 510 minecraft:crying_obsidian
fill 66 286 512 67 286 526 minecraft:polished_blackstone_bricks
fill 66 286 527 67 286 527 minecraft:crying_obsidian
fill 66 286 536 66 287 536 minecraft:crying_obsidian
fill 66 286 537 66 287 550 minecraft:polished_blackstone_bricks
fill 68 286 512 68 287 525 minecraft:polished_blackstone_bricks
fill 68 286 526 68 287 526 minecraft:crying_obsidian
fill 68 286 537 68 287 537 minecraft:crying_obsidian
fill 68 286 538 68 287 550 minecraft:polished_blackstone_bricks
fill 71 286 526 71 287 526 minecraft:crying_obsidian
fill 71 286 552 74 291 552 minecraft:crying_obsidian
fill 72 286 526 87 286 526 minecraft:polished_blackstone_bricks
fill 72 286 527 73 286 527 minecraft:crying_obsidian
fill 73 286 536 73 288 536 minecraft:crying_obsidian
fill 74 286 527 87 287 527 minecraft:polished_blackstone_bricks
fill 74 286 528 74 287 528 minecraft:crying_obsidian
fill 74 286 535 74 288 535 minecraft:crying_obsidian
fill 74 286 536 87 288 536 minecraft:polished_blackstone_bricks
fill 75 286 528 87 287 528 minecraft:polished_blackstone_bricks
fill 75 286 535 87 288 535 minecraft:polished_blackstone_bricks
fill 78 286 510 81 291 510 minecraft:crying_obsidian
fill 83 286 552 86 291 552 minecraft:crying_obsidian
fill 89 286 511 89 291 514 minecraft:crying_obsidian
fill 89 286 523 89 291 526 minecraft:crying_obsidian
fill 89 286 535 89 291 538 minecraft:crying_obsidian
fill 89 286 547 89 291 550 minecraft:crying_obsidian
fill 49 287 512 62 288 550 minecraft:polished_blackstone_bricks
fill 63 287 512 63 287 529 minecraft:polished_blackstone_bricks
fill 63 287 530 63 288 533 minecraft:crying_obsidian
fill 63 287 534 63 287 550 minecraft:polished_blackstone_bricks
fill 64 287 512 64 287 527 minecraft:polished_blackstone_bricks
fill 64 287 528 64 287 529 minecraft:crying_obsidian
setblock 64 287 534 minecraft:crying_obsidian
fill 64 287 535 64 287 550 minecraft:polished_blackstone_bricks
fill 65 287 512 65 287 526 minecraft:polished_blackstone_bricks
setblock 65 287 527 minecraft:crying_obsidian
fill 66 287 512 67 287 525 minecraft:polished_blackstone_bricks
fill 66 287 526 67 287 526 minecraft:crying_obsidian
fill 67 287 537 67 288 537 minecraft:crying_obsidian
fill 67 287 538 67 288 550 minecraft:polished_blackstone_bricks
fill 69 287 512 87 288 524 minecraft:polished_blackstone_bricks
fill 69 287 525 70 288 525 minecraft:crying_obsidian
fill 71 287 525 87 287 525 minecraft:polished_blackstone_bricks
fill 72 287 526 72 288 526 minecraft:crying_obsidian
fill 72 287 537 72 289 537 minecraft:crying_obsidian
fill 73 287 526 87 287 526 minecraft:polished_blackstone_bricks
setblock 73 287 527 minecraft:crying_obsidian
fill 73 287 537 87 288 537 minecraft:polished_blackstone_bricks
fill 75 287 529 75 289 529 minecraft:crying_obsidian
fill 75 287 534 75 290 534 minecraft:crying_obsidian
fill 76 287 529 87 289 529 minecraft:polished_blackstone_bricks
fill 76 287 534 87 290 534 minecraft:polished_blackstone_bricks
fill 63 288 512 63 288 528 minecraft:polished_blackstone_bricks
setblock 63 288 529 minecraft:crying_obsidian
setblock 63 288 534 minecraft:crying_obsidian
fill 63 288 535 63 288 550 minecraft:polished_blackstone_bricks
fill 64 288 512 64 288 526 minecraft:polished_blackstone_bricks
fill 64 288 527 64 288 528 minecraft:crying_obsidian
setblock 64 288 535 minecraft:crying_obsidian
fill 64 288 536 64 288 550 minecraft:polished_blackstone_bricks
fill 65 288 512 66 288 525 minecraft:polished_blackstone_bricks
fill 65 288 526 66 288 526 minecraft:crying_obsidian
setblock 65 288 536 minecraft:crying_obsidian
fill 65 288 537 65 288 550 minecraft:polished_blackstone_bricks
setblock 66 288 537 minecraft:crying_obsidian
fill 66 288 538 66 288 550 minecraft:polished_blackstone_bricks
fill 67 288 512 68 288 524 minecraft:polished_blackstone_bricks
fill 67 288 525 68 288 525 minecraft:crying_obsidian
fill 68 288 538 71 289 538 minecraft:crying_obsidian
fill 68 288 539 87 289 550 minecraft:polished_blackstone_bricks
fill 71 288 525 71 289 525 minecraft:crying_obsidian
fill 72 288 525 87 288 525 minecraft:polished_blackstone_bricks
fill 72 288 538 87 289 538 minecraft:polished_blackstone_bricks
fill 73 288 526 73 289 526 minecraft:crying_obsidian
fill 74 288 526 87 289 526 minecraft:polished_blackstone_bricks
fill 74 288 527 74 289 527 minecraft:crying_obsidian
fill 75 288 527 87 289 527 minecraft:polished_blackstone_bricks
fill 75 288 528 75 291 528 minecraft:crying_obsidian
setblock 75 288 532 minecraft:crying_obsidian
fill 76 288 528 87 291 528 minecraft:polished_blackstone_bricks
fill 76 288 531 76 292 531 minecraft:crying_obsidian
fill 76 288 532 87 288 532 minecraft:polished_blackstone_bricks
fill 77 288 531 87 291 531 minecraft:polished_blackstone_bricks
fill 49 289 512 61 289 550 minecraft:polished_blackstone_bricks
fill 62 289 512 62 289 528 minecraft:polished_blackstone_bricks
fill 62 289 529 62 289 534 minecraft:crying_obsidian
fill 62 289 535 62 289 550 minecraft:polished_blackstone_bricks
fill 63 289 512 63 290 526 minecraft:polished_blackstone_bricks
fill 63 289 527 63 289 528 minecraft:crying_obsidian
setblock 63 289 535 minecraft:crying_obsidian
fill 63 289 536 63 289 550 minecraft:polished_blackstone_bricks
fill 64 289 512 65 289 525 minecraft:polished_blackstone_bricks
fill 64 289 526 65 289 526 minecraft:crying_obsidian
setblock 64 289 536 minecraft:crying_obsidian
fill 64 289 537 64 289 550 minecraft:polished_blackstone_bricks
setblock 65 289 537 minecraft:crying_obsidian
fill 65 289 538 65 289 550 minecraft:polished_blackstone_bricks
fill 66 289 512 67 289 524 minecraft:polished_blackstone_bricks
fill 66 289 525 67 289 525 minecraft:crying_obsidian
fill 66 289 538 67 290 538 minecraft:crying_obsidian
fill 66 289 539 67 290 550 minecraft:polished_blackstone_bricks
fill 68 289 512 87 290 523 minecraft:polished_blackstone_bricks
fill 68 289 524 70 290 524 minecraft:crying_obsidian
fill 71 289 524 87 289 524 minecraft:polished_blackstone_bricks
fill 72 289 525 72 290 525 minecraft:crying_obsidian
fill 73 289 525 87 289 525 minecraft:polished_blackstone_bricks
fill 73 289 537 73 291 537 minecraft:crying_obsidian
fill 74 289 536 74 291 536 minecraft:crying_obsidian
fill 74 289 537 87 291 537 minecraft:polished_blackstone_bricks
fill 75 289 535 75 292 535 minecraft:crying_obsidian
fill 75 289 536 87 291 536 minecraft:polished_blackstone_bricks
fill 76 289 530 76 292 530 minecraft:crying_obsidian
fill 76 289 532 76 292 533 minecraft:crying_obsidian
fill 76 289 535 87 291 535 minecraft:polished_blackstone_bricks
fill 77 289 530 87 291 530 minecraft:polished_blackstone_bricks
fill 77 289 532 87 291 533 minecraft:polished_blackstone_bricks
fill 49 290 512 60 291 550 minecraft:polished_blackstone_bricks
fill 61 290 512 61 290 529 minecraft:polished_blackstone_bricks
fill 61 290 530 61 291 533 minecraft:crying_obsidian
fill 61 290 534 61 290 550 minecraft:polished_blackstone_bricks
fill 62 290 512 62 290 527 minecraft:polished_blackstone_bricks
fill 62 290 528 62 290 529 minecraft:crying_obsidian
fill 62 290 534 62 290 535 minecraft:crying_obsidian
fill 62 290 536 62 290 550 minecraft:polished_blackstone_bricks
setblock 63 290 527 minecraft:crying_obsidian
setblock 63 290 536 minecraft:crying_obsidian
fill 63 290 537 63 290 550 minecraft:polished_blackstone_bricks
fill 64 290 512 64 290 525 minecraft:polished_blackstone_bricks
setblock 64 290 526 minecraft:crying_obsidian
setblock 64 290 537 minecraft:crying_obsidian
fill 64 290 538 64 290 550 minecraft:polished_blackstone_bricks
fill 65 290 512 65 290 524 minecraft:polished_blackstone_bricks
setblock 65 290 525 minecraft:crying_obsidian
fill 65 290 538 65 291 538 minecraft:crying_obsidian
fill 65 290 539 65 291 550 minecraft:polished_blackstone_bricks
fill 66 290 512 67 290 523 minecraft:polished_blackstone_bricks
fill 66 290 524 67 290 524 minecraft:crying_obsidian
fill 68 290 539 69 292 539 minecraft:crying_obsidian
fill 68 290 540 87 291 550 minecraft:polished_blackstone_bricks
fill 70 290 538 72 290 538 minecraft:crying_obsidian
fill 70 290 539 87 290 539 minecraft:polished_blackstone_bricks
fill 71 290 524 71 291 524 minecraft:crying_obsidian
fill 72 290 524 87 290 524 minecraft:polished_blackstone_bricks
fill 73 290 525 73 291 525 minecraft:crying_obsidian
fill 73 290 538 87 291 538 minecraft:polished_blackstone_bricks
fill 74 290 525 87 291 525 minecraft:polished_blackstone_bricks
fill 74 290 526 74 291 526 minecraft:crying_obsidian
fill 75 290 526 87 291 526 minecraft:polished_blackstone_bricks
fill 75 290 527 75 292 527 minecraft:crying_obsidian
fill 76 290 527 87 291 527 minecraft:polished_blackstone_bricks
fill 76 290 529 76 292 529 minecraft:crying_obsidian
fill 77 290 529 87 291 529 minecraft:polished_blackstone_bricks
fill 61 291 512 61 291 527 minecraft:polished_blackstone_bricks
fill 61 291 528 61 291 529 minecraft:crying_obsidian
schedule function dropper:buildpart/121_3 1t
