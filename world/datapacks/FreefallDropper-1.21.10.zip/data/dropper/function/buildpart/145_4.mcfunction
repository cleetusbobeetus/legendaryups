fill 61 287 606 61 288 606 minecraft:light_gray_concrete
fill 61 287 608 61 288 608 minecraft:light_gray_concrete
fill 61 287 610 61 288 610 minecraft:light_gray_concrete
fill 61 287 612 61 288 612 minecraft:light_gray_concrete
fill 61 287 639 61 289 641 minecraft:magenta_concrete
fill 62 287 605 62 288 605 minecraft:light_gray_concrete
fill 62 287 607 62 288 607 minecraft:light_gray_concrete
fill 62 287 609 62 288 609 minecraft:light_gray_concrete
fill 62 287 611 62 288 611 minecraft:light_gray_concrete
fill 62 287 613 62 288 613 minecraft:light_gray_concrete
fill 62 287 638 62 289 638 minecraft:magenta_concrete
fill 62 287 642 64 289 642 minecraft:magenta_concrete
fill 63 287 606 63 288 606 minecraft:light_gray_concrete
fill 63 287 608 63 288 608 minecraft:light_gray_concrete
fill 63 287 610 63 288 610 minecraft:light_gray_concrete
fill 63 287 612 63 288 612 minecraft:light_gray_concrete
fill 64 287 605 64 288 605 minecraft:light_gray_concrete
fill 64 287 607 64 288 607 minecraft:light_gray_concrete
fill 64 287 609 64 288 609 minecraft:light_gray_concrete
fill 64 287 611 64 288 611 minecraft:light_gray_concrete
fill 64 287 613 64 288 613 minecraft:light_gray_concrete
fill 64 287 638 64 289 638 minecraft:magenta_concrete
fill 65 287 606 65 288 606 minecraft:light_gray_concrete
fill 65 287 608 65 288 608 minecraft:light_gray_concrete
fill 65 287 610 65 288 610 minecraft:light_gray_concrete
fill 65 287 612 65 288 612 minecraft:light_gray_concrete
fill 65 287 639 65 289 641 minecraft:magenta_concrete
fill 66 287 605 66 288 605 minecraft:light_gray_concrete
fill 66 287 607 66 288 607 minecraft:light_gray_concrete
fill 66 287 609 66 288 609 minecraft:light_gray_concrete
fill 66 287 611 66 288 611 minecraft:light_gray_concrete
fill 66 287 613 66 288 613 minecraft:light_gray_concrete
fill 67 287 606 67 288 606 minecraft:light_gray_concrete
fill 67 287 608 67 288 608 minecraft:light_gray_concrete
fill 67 287 610 67 288 610 minecraft:light_gray_concrete
fill 67 287 612 67 288 612 minecraft:light_gray_concrete
fill 68 287 605 68 288 605 minecraft:light_gray_concrete
fill 68 287 607 68 288 607 minecraft:light_gray_concrete
fill 68 287 609 68 288 609 minecraft:light_gray_concrete
fill 68 287 611 68 288 611 minecraft:light_gray_concrete
fill 68 287 613 68 288 613 minecraft:light_gray_concrete
fill 69 287 606 69 288 606 minecraft:light_gray_concrete
fill 69 287 608 69 288 608 minecraft:light_gray_concrete
fill 69 287 610 69 288 610 minecraft:light_gray_concrete
fill 69 287 612 69 288 612 minecraft:light_gray_concrete
fill 70 287 605 70 288 605 minecraft:light_gray_concrete
fill 70 287 607 70 288 607 minecraft:light_gray_concrete
fill 70 287 609 70 288 609 minecraft:light_gray_concrete
fill 70 287 611 70 288 611 minecraft:light_gray_concrete
fill 70 287 613 70 288 613 minecraft:light_gray_concrete
fill 74 287 639 74 288 639 minecraft:light_gray_concrete
fill 74 287 641 74 288 641 minecraft:light_gray_concrete
fill 74 287 643 74 288 643 minecraft:light_gray_concrete
fill 74 287 645 74 288 645 minecraft:light_gray_concrete
fill 75 287 638 75 288 638 minecraft:light_gray_concrete
fill 75 287 640 75 288 640 minecraft:light_gray_concrete
fill 75 287 642 75 288 642 minecraft:light_gray_concrete
fill 75 287 644 75 288 644 minecraft:light_gray_concrete
fill 76 287 639 76 288 639 minecraft:light_gray_concrete
fill 76 287 641 76 288 641 minecraft:light_gray_concrete
fill 76 287 643 76 288 643 minecraft:light_gray_concrete
fill 76 287 645 76 288 645 minecraft:light_gray_concrete
fill 77 287 638 77 288 638 minecraft:light_gray_concrete
fill 77 287 640 77 288 640 minecraft:light_gray_concrete
fill 77 287 642 77 288 642 minecraft:light_gray_concrete
fill 77 287 644 77 288 644 minecraft:light_gray_concrete
fill 78 287 639 78 288 639 minecraft:light_gray_concrete
fill 78 287 641 78 288 641 minecraft:light_gray_concrete
fill 78 287 643 78 288 643 minecraft:light_gray_concrete
fill 78 287 645 78 288 645 minecraft:light_gray_concrete
fill 79 287 638 79 288 638 minecraft:light_gray_concrete
fill 79 287 640 79 288 640 minecraft:light_gray_concrete
fill 79 287 642 79 288 642 minecraft:light_gray_concrete
fill 79 287 644 79 288 644 minecraft:light_gray_concrete
fill 80 287 639 80 288 639 minecraft:light_gray_concrete
fill 80 287 641 80 288 641 minecraft:light_gray_concrete
fill 80 287 643 80 288 643 minecraft:light_gray_concrete
fill 80 287 645 80 288 645 minecraft:light_gray_concrete
fill 81 287 638 81 288 638 minecraft:light_gray_concrete
fill 81 287 640 81 288 640 minecraft:light_gray_concrete
fill 81 287 642 81 288 642 minecraft:light_gray_concrete
fill 81 287 644 81 288 644 minecraft:light_gray_concrete
fill 82 287 639 82 288 639 minecraft:light_gray_concrete
fill 82 287 641 82 288 641 minecraft:light_gray_concrete
fill 82 287 643 82 288 643 minecraft:light_gray_concrete
fill 82 287 645 82 288 645 minecraft:light_gray_concrete
setblock 50 288 607 minecraft:light[level=14]
setblock 50 288 615 minecraft:light[level=14]
setblock 50 288 623 minecraft:light[level=14]
setblock 50 288 631 minecraft:light[level=14]
setblock 50 288 639 minecraft:light[level=14]
setblock 58 288 607 minecraft:light[level=14]
setblock 58 288 615 minecraft:light[level=14]
setblock 58 288 623 minecraft:light[level=14]
setblock 58 288 631 minecraft:light[level=14]
setblock 58 288 639 minecraft:light[level=14]
fill 60 288 622 61 289 623 minecraft:glass
fill 60 288 639 60 289 641 minecraft:magenta_concrete
fill 61 288 638 61 289 638 minecraft:magenta_concrete
fill 61 288 642 61 289 642 minecraft:magenta_concrete
fill 62 288 637 64 289 637 minecraft:magenta_concrete
fill 63 288 643 63 289 643 minecraft:magenta_concrete
fill 65 288 638 65 289 638 minecraft:magenta_concrete
fill 65 288 642 65 289 642 minecraft:magenta_concrete
setblock 66 288 615 minecraft:light[level=14]
setblock 66 288 623 minecraft:light[level=14]
setblock 66 288 631 minecraft:light[level=14]
fill 66 288 639 66 289 641 minecraft:magenta_concrete
setblock 74 288 607 minecraft:light[level=14]
setblock 74 288 615 minecraft:light[level=14]
setblock 74 288 623 minecraft:light[level=14]
setblock 74 288 631 minecraft:light[level=14]
setblock 82 288 615 minecraft:light[level=14]
setblock 82 288 623 minecraft:light[level=14]
setblock 82 288 631 minecraft:light[level=14]
fill 84 288 621 87 288 631 minecraft:light_gray_concrete
setblock 88 288 621 minecraft:light_gray_concrete
fill 88 288 624 88 288 629 minecraft:light_gray_concrete
setblock 59 289 640 minecraft:magenta_concrete
setblock 60 289 605 minecraft:sea_lantern
setblock 60 289 607 minecraft:sea_lantern
setblock 60 289 609 minecraft:sea_lantern
setblock 60 289 611 minecraft:sea_lantern
setblock 60 289 613 minecraft:sea_lantern
setblock 60 289 638 minecraft:magenta_concrete
setblock 60 289 642 minecraft:magenta_concrete
setblock 61 289 606 minecraft:sea_lantern
setblock 61 289 608 minecraft:sea_lantern
setblock 61 289 610 minecraft:sea_lantern
setblock 61 289 612 minecraft:sea_lantern
setblock 61 289 637 minecraft:magenta_concrete
fill 61 289 643 62 289 643 minecraft:magenta_concrete
setblock 62 289 605 minecraft:sea_lantern
setblock 62 289 607 minecraft:sea_lantern
setblock 62 289 609 minecraft:sea_lantern
setblock 62 289 611 minecraft:sea_lantern
setblock 62 289 613 minecraft:sea_lantern
fill 62 289 636 64 289 636 minecraft:magenta_concrete
setblock 63 289 606 minecraft:sea_lantern
setblock 63 289 608 minecraft:sea_lantern
setblock 63 289 610 minecraft:sea_lantern
setblock 63 289 612 minecraft:sea_lantern
setblock 64 289 605 minecraft:sea_lantern
setblock 64 289 607 minecraft:sea_lantern
setblock 64 289 609 minecraft:sea_lantern
setblock 64 289 611 minecraft:sea_lantern
setblock 64 289 613 minecraft:sea_lantern
fill 64 289 643 65 289 643 minecraft:magenta_concrete
setblock 65 289 606 minecraft:sea_lantern
setblock 65 289 608 minecraft:sea_lantern
setblock 65 289 610 minecraft:sea_lantern
setblock 65 289 612 minecraft:sea_lantern
setblock 65 289 637 minecraft:magenta_concrete
setblock 66 289 605 minecraft:sea_lantern
setblock 66 289 607 minecraft:sea_lantern
setblock 66 289 609 minecraft:sea_lantern
setblock 66 289 611 minecraft:sea_lantern
setblock 66 289 613 minecraft:sea_lantern
setblock 66 289 638 minecraft:magenta_concrete
setblock 66 289 642 minecraft:magenta_concrete
setblock 67 289 606 minecraft:sea_lantern
setblock 67 289 608 minecraft:sea_lantern
setblock 67 289 610 minecraft:sea_lantern
setblock 67 289 612 minecraft:sea_lantern
setblock 67 289 640 minecraft:magenta_concrete
setblock 68 289 605 minecraft:sea_lantern
setblock 68 289 607 minecraft:sea_lantern
setblock 68 289 609 minecraft:sea_lantern
setblock 68 289 611 minecraft:sea_lantern
setblock 68 289 613 minecraft:sea_lantern
setblock 69 289 606 minecraft:sea_lantern
setblock 69 289 608 minecraft:sea_lantern
setblock 69 289 610 minecraft:sea_lantern
setblock 69 289 612 minecraft:sea_lantern
setblock 70 289 605 minecraft:sea_lantern
setblock 70 289 607 minecraft:sea_lantern
setblock 70 289 609 minecraft:sea_lantern
setblock 70 289 611 minecraft:sea_lantern
setblock 70 289 613 minecraft:sea_lantern
setblock 74 289 639 minecraft:sea_lantern
setblock 74 289 641 minecraft:sea_lantern
setblock 74 289 643 minecraft:sea_lantern
setblock 74 289 645 minecraft:sea_lantern
setblock 75 289 638 minecraft:sea_lantern
setblock 75 289 640 minecraft:sea_lantern
setblock 75 289 642 minecraft:sea_lantern
setblock 75 289 644 minecraft:sea_lantern
setblock 76 289 639 minecraft:sea_lantern
setblock 76 289 641 minecraft:sea_lantern
setblock 76 289 643 minecraft:sea_lantern
setblock 76 289 645 minecraft:sea_lantern
setblock 77 289 638 minecraft:sea_lantern
setblock 77 289 640 minecraft:sea_lantern
setblock 77 289 642 minecraft:sea_lantern
setblock 77 289 644 minecraft:sea_lantern
setblock 78 289 639 minecraft:sea_lantern
setblock 78 289 641 minecraft:sea_lantern
setblock 78 289 643 minecraft:sea_lantern
setblock 78 289 645 minecraft:sea_lantern
setblock 79 289 638 minecraft:sea_lantern
setblock 79 289 640 minecraft:sea_lantern
setblock 79 289 642 minecraft:sea_lantern
setblock 79 289 644 minecraft:sea_lantern
setblock 80 289 639 minecraft:sea_lantern
setblock 80 289 641 minecraft:sea_lantern
setblock 80 289 643 minecraft:sea_lantern
setblock 80 289 645 minecraft:sea_lantern
setblock 81 289 638 minecraft:sea_lantern
setblock 81 289 640 minecraft:sea_lantern
setblock 81 289 642 minecraft:sea_lantern
setblock 81 289 644 minecraft:sea_lantern
setblock 82 289 639 minecraft:sea_lantern
setblock 82 289 641 minecraft:sea_lantern
setblock 82 289 643 minecraft:sea_lantern
setblock 82 289 645 minecraft:sea_lantern
setblock 84 289 621 minecraft:sea_lantern
fill 84 289 622 84 300 622 minecraft:light_gray_concrete
setblock 84 289 623 minecraft:sea_lantern
fill 84 289 624 84 300 624 minecraft:light_gray_concrete
setblock 84 289 625 minecraft:sea_lantern
fill 84 289 626 84 300 626 minecraft:light_gray_concrete
setblock 84 289 627 minecraft:sea_lantern
fill 84 289 628 84 300 628 minecraft:light_gray_concrete
setblock 84 289 629 minecraft:sea_lantern
fill 84 289 630 84 300 630 minecraft:light_gray_concrete
setblock 84 289 631 minecraft:sea_lantern
fill 85 289 621 85 300 621 minecraft:light_gray_concrete
setblock 85 289 622 minecraft:sea_lantern
fill 85 289 623 85 300 623 minecraft:light_gray_concrete
setblock 85 289 624 minecraft:sea_lantern
fill 85 289 625 85 300 625 minecraft:light_gray_concrete
setblock 85 289 626 minecraft:sea_lantern
fill 85 289 627 85 300 627 minecraft:light_gray_concrete
setblock 85 289 628 minecraft:sea_lantern
fill 85 289 629 85 300 629 minecraft:light_gray_concrete
setblock 85 289 630 minecraft:sea_lantern
fill 85 289 631 85 300 631 minecraft:light_gray_concrete
setblock 86 289 621 minecraft:sea_lantern
fill 86 289 622 86 300 622 minecraft:light_gray_concrete
setblock 86 289 623 minecraft:sea_lantern
fill 86 289 624 86 300 624 minecraft:light_gray_concrete
setblock 86 289 625 minecraft:sea_lantern
fill 86 289 626 86 300 626 minecraft:light_gray_concrete
setblock 86 289 627 minecraft:sea_lantern
fill 86 289 628 86 300 628 minecraft:light_gray_concrete
setblock 86 289 629 minecraft:sea_lantern
fill 86 289 630 86 300 630 minecraft:light_gray_concrete
setblock 86 289 631 minecraft:sea_lantern
fill 87 289 621 87 300 621 minecraft:light_gray_concrete
setblock 87 289 622 minecraft:sea_lantern
fill 87 289 623 87 300 623 minecraft:light_gray_concrete
setblock 87 289 624 minecraft:sea_lantern
fill 87 289 625 87 300 625 minecraft:light_gray_concrete
setblock 87 289 626 minecraft:sea_lantern
fill 87 289 627 87 300 627 minecraft:light_gray_concrete
setblock 87 289 628 minecraft:sea_lantern
fill 87 289 629 87 300 629 minecraft:light_gray_concrete
setblock 87 289 630 minecraft:sea_lantern
fill 87 289 631 87 300 631 minecraft:light_gray_concrete
setblock 88 289 621 minecraft:sea_lantern
fill 88 289 622 88 300 622 minecraft:light_gray_concrete
setblock 88 289 623 minecraft:sea_lantern
fill 88 289 624 88 300 624 minecraft:light_gray_concrete
setblock 88 289 625 minecraft:sea_lantern
fill 88 289 626 88 300 626 minecraft:light_gray_concrete
setblock 88 289 627 minecraft:sea_lantern
fill 88 289 628 88 300 628 minecraft:light_gray_concrete
setblock 88 289 629 minecraft:sea_lantern
fill 88 289 630 88 300 630 minecraft:light_gray_concrete
setblock 88 289 631 minecraft:sea_lantern
fill 47 290 609 47 297 609 minecraft:gray_concrete
fill 47 290 617 47 297 617 minecraft:gray_concrete
fill 47 290 625 47 297 625 minecraft:gray_concrete
fill 47 290 633 47 297 633 minecraft:gray_concrete
fill 47 290 641 47 297 641 minecraft:gray_concrete
fill 50 290 646 50 297 646 minecraft:gray_concrete
fill 54 290 604 54 297 604 minecraft:gray_concrete
fill 58 290 635 61 291 645 minecraft:light_gray_concrete
fill 58 290 646 58 297 646 minecraft:gray_concrete
fill 60 290 605 60 291 605 minecraft:light_gray_concrete
fill 60 290 607 60 291 607 minecraft:light_gray_concrete
fill 60 290 609 60 291 609 minecraft:light_gray_concrete
fill 60 290 611 60 291 611 minecraft:light_gray_concrete
fill 60 290 613 60 291 613 minecraft:light_gray_concrete
fill 61 290 606 61 291 606 minecraft:light_gray_concrete
fill 61 290 608 61 291 608 minecraft:light_gray_concrete
fill 61 290 610 61 291 610 minecraft:light_gray_concrete
fill 61 290 612 61 291 612 minecraft:light_gray_concrete
fill 62 290 604 62 297 604 minecraft:gray_concrete
fill 62 290 605 62 291 605 minecraft:light_gray_concrete
fill 62 290 607 62 291 607 minecraft:light_gray_concrete
fill 62 290 609 62 291 609 minecraft:light_gray_concrete
fill 62 290 611 62 291 611 minecraft:light_gray_concrete
fill 62 290 613 62 291 613 minecraft:light_gray_concrete
fill 62 290 635 68 291 644 minecraft:light_gray_concrete
fill 63 290 606 63 291 606 minecraft:light_gray_concrete
fill 63 290 608 63 291 608 minecraft:light_gray_concrete
fill 63 290 610 63 291 610 minecraft:light_gray_concrete
fill 63 290 612 63 291 612 minecraft:light_gray_concrete
fill 64 290 605 64 291 605 minecraft:light_gray_concrete
fill 64 290 607 64 291 607 minecraft:light_gray_concrete
fill 64 290 609 64 291 609 minecraft:light_gray_concrete
fill 64 290 611 64 291 611 minecraft:light_gray_concrete
fill 64 290 613 64 291 613 minecraft:light_gray_concrete
fill 64 290 645 68 291 645 minecraft:light_gray_concrete
fill 65 290 606 65 291 606 minecraft:light_gray_concrete
fill 65 290 608 65 291 608 minecraft:light_gray_concrete
fill 65 290 610 65 291 610 minecraft:light_gray_concrete
fill 65 290 612 65 291 612 minecraft:light_gray_concrete
fill 66 290 605 66 291 605 minecraft:light_gray_concrete
fill 66 290 607 66 291 607 minecraft:light_gray_concrete
fill 66 290 609 66 291 609 minecraft:light_gray_concrete
fill 66 290 611 66 291 611 minecraft:light_gray_concrete
fill 66 290 613 66 291 613 minecraft:light_gray_concrete
fill 66 290 646 66 297 646 minecraft:gray_concrete
fill 67 290 606 67 291 606 minecraft:light_gray_concrete
fill 67 290 608 67 291 608 minecraft:light_gray_concrete
fill 67 290 610 67 291 610 minecraft:light_gray_concrete
fill 67 290 612 67 291 612 minecraft:light_gray_concrete
fill 68 290 605 68 291 605 minecraft:light_gray_concrete
fill 68 290 607 68 291 607 minecraft:light_gray_concrete
fill 68 290 609 68 291 609 minecraft:light_gray_concrete
fill 68 290 611 68 291 611 minecraft:light_gray_concrete
fill 68 290 613 68 291 613 minecraft:light_gray_concrete
fill 69 290 606 69 291 606 minecraft:light_gray_concrete
fill 69 290 608 69 291 608 minecraft:light_gray_concrete
fill 69 290 610 69 291 610 minecraft:light_gray_concrete
fill 69 290 612 69 291 612 minecraft:light_gray_concrete
fill 70 290 604 70 297 604 minecraft:gray_concrete
fill 70 290 605 70 291 605 minecraft:light_gray_concrete
fill 70 290 607 70 291 607 minecraft:light_gray_concrete
fill 70 290 609 70 291 609 minecraft:light_gray_concrete
fill 70 290 611 70 291 611 minecraft:light_gray_concrete
fill 70 290 613 70 291 613 minecraft:light_gray_concrete
fill 74 290 639 74 291 639 minecraft:light_gray_concrete
fill 74 290 641 74 291 641 minecraft:light_gray_concrete
fill 74 290 643 74 291 643 minecraft:light_gray_concrete
fill 74 290 645 74 291 645 minecraft:light_gray_concrete
fill 74 290 646 74 297 646 minecraft:gray_concrete
fill 75 290 638 75 291 638 minecraft:light_gray_concrete
fill 75 290 640 75 291 640 minecraft:light_gray_concrete
fill 75 290 642 75 291 642 minecraft:light_gray_concrete
fill 75 290 644 75 291 644 minecraft:light_gray_concrete
fill 76 290 639 76 291 639 minecraft:light_gray_concrete
fill 76 290 641 76 291 641 minecraft:light_gray_concrete
fill 76 290 643 76 291 643 minecraft:light_gray_concrete
fill 76 290 645 76 291 645 minecraft:light_gray_concrete
fill 77 290 638 77 291 638 minecraft:light_gray_concrete
fill 77 290 640 77 291 640 minecraft:light_gray_concrete
fill 77 290 642 77 291 642 minecraft:light_gray_concrete
fill 77 290 644 77 291 644 minecraft:light_gray_concrete
fill 78 290 604 78 297 604 minecraft:gray_concrete
fill 78 290 639 78 291 639 minecraft:light_gray_concrete
fill 78 290 641 78 291 641 minecraft:light_gray_concrete
fill 78 290 643 78 291 643 minecraft:light_gray_concrete
fill 78 290 645 78 291 645 minecraft:light_gray_concrete
fill 79 290 638 79 291 638 minecraft:light_gray_concrete
fill 79 290 640 79 291 640 minecraft:light_gray_concrete
fill 79 290 642 79 291 642 minecraft:light_gray_concrete
fill 79 290 644 79 291 644 minecraft:light_gray_concrete
fill 80 290 639 80 291 639 minecraft:light_gray_concrete
fill 80 290 641 80 291 641 minecraft:light_gray_concrete
fill 80 290 643 80 291 643 minecraft:light_gray_concrete
fill 80 290 645 80 291 645 minecraft:light_gray_concrete
fill 81 290 638 81 291 638 minecraft:light_gray_concrete
fill 81 290 640 81 291 640 minecraft:light_gray_concrete
fill 81 290 642 81 291 642 minecraft:light_gray_concrete
fill 81 290 644 81 291 644 minecraft:light_gray_concrete
fill 82 290 639 82 291 639 minecraft:light_gray_concrete
fill 82 290 641 82 291 641 minecraft:light_gray_concrete
fill 82 290 643 82 291 643 minecraft:light_gray_concrete
fill 82 290 645 82 291 645 minecraft:light_gray_concrete
fill 82 290 646 82 297 646 minecraft:gray_concrete
fill 84 290 621 84 291 621 minecraft:light_gray_concrete
fill 84 290 623 84 291 623 minecraft:light_gray_concrete
fill 84 290 625 84 291 625 minecraft:light_gray_concrete
fill 84 290 627 84 291 627 minecraft:light_gray_concrete
fill 84 290 629 84 291 629 minecraft:light_gray_concrete
fill 84 290 631 84 291 631 minecraft:light_gray_concrete
fill 85 290 622 85 291 622 minecraft:light_gray_concrete
fill 85 290 624 85 291 624 minecraft:light_gray_concrete
fill 85 290 626 85 291 626 minecraft:light_gray_concrete
fill 85 290 628 85 291 628 minecraft:light_gray_concrete
fill 85 290 630 85 291 630 minecraft:light_gray_concrete
fill 86 290 604 86 297 604 minecraft:gray_concrete
fill 86 290 621 86 291 621 minecraft:light_gray_concrete
fill 86 290 623 86 291 623 minecraft:light_gray_concrete
fill 86 290 625 86 291 625 minecraft:light_gray_concrete
fill 86 290 627 86 291 627 minecraft:light_gray_concrete
fill 86 290 629 86 291 629 minecraft:light_gray_concrete
fill 86 290 631 86 291 631 minecraft:light_gray_concrete
fill 87 290 622 87 291 622 minecraft:light_gray_concrete
fill 87 290 624 87 291 624 minecraft:light_gray_concrete
fill 87 290 626 87 291 626 minecraft:light_gray_concrete
fill 87 290 628 87 291 628 minecraft:light_gray_concrete
fill 87 290 630 87 291 630 minecraft:light_gray_concrete
fill 88 290 621 88 291 621 minecraft:light_gray_concrete
fill 88 290 623 88 291 623 minecraft:light_gray_concrete
fill 88 290 625 88 291 625 minecraft:light_gray_concrete
fill 88 290 627 88 291 627 minecraft:light_gray_concrete
fill 88 290 629 88 291 629 minecraft:light_gray_concrete
fill 88 290 631 88 291 631 minecraft:light_gray_concrete
fill 89 290 609 89 297 609 minecraft:gray_concrete
fill 89 290 617 89 297 617 minecraft:gray_concrete
fill 89 290 625 89 297 625 minecraft:gray_concrete
fill 89 290 633 89 297 633 minecraft:gray_concrete
fill 89 290 641 89 297 641 minecraft:gray_concrete
fill 60 291 620 60 292 621 minecraft:magenta_concrete
setblock 58 292 635 minecraft:sea_lantern
fill 58 292 636 58 300 636 minecraft:light_gray_concrete
setblock 58 292 637 minecraft:sea_lantern
fill 58 292 638 58 300 638 minecraft:light_gray_concrete
setblock 58 292 639 minecraft:sea_lantern
fill 58 292 640 58 300 640 minecraft:light_gray_concrete
setblock 58 292 641 minecraft:sea_lantern
fill 58 292 642 58 300 642 minecraft:light_gray_concrete
setblock 58 292 643 minecraft:sea_lantern
fill 58 292 644 58 300 644 minecraft:light_gray_concrete
setblock 58 292 645 minecraft:sea_lantern
fill 59 292 635 59 300 635 minecraft:light_gray_concrete
setblock 59 292 636 minecraft:sea_lantern
fill 59 292 637 59 300 637 minecraft:light_gray_concrete
setblock 59 292 638 minecraft:sea_lantern
fill 59 292 639 59 300 639 minecraft:light_gray_concrete
setblock 59 292 640 minecraft:sea_lantern
fill 59 292 641 59 300 641 minecraft:light_gray_concrete
setblock 59 292 642 minecraft:sea_lantern
fill 59 292 643 59 300 643 minecraft:light_gray_concrete
setblock 59 292 644 minecraft:sea_lantern
fill 59 292 645 59 300 645 minecraft:light_gray_concrete
setblock 60 292 605 minecraft:sea_lantern
setblock 60 292 607 minecraft:sea_lantern
setblock 60 292 609 minecraft:sea_lantern
setblock 60 292 611 minecraft:sea_lantern
setblock 60 292 613 minecraft:sea_lantern
setblock 60 292 635 minecraft:sea_lantern
fill 60 292 636 60 300 636 minecraft:light_gray_concrete
setblock 60 292 637 minecraft:sea_lantern
fill 60 292 638 60 300 638 minecraft:light_gray_concrete
setblock 60 292 639 minecraft:sea_lantern
fill 60 292 640 60 300 640 minecraft:light_gray_concrete
setblock 60 292 641 minecraft:sea_lantern
fill 60 292 642 60 300 642 minecraft:light_gray_concrete
setblock 60 292 643 minecraft:sea_lantern
fill 60 292 644 60 300 644 minecraft:light_gray_concrete
setblock 60 292 645 minecraft:sea_lantern
setblock 61 292 606 minecraft:sea_lantern
setblock 61 292 608 minecraft:sea_lantern
setblock 61 292 610 minecraft:sea_lantern
setblock 61 292 612 minecraft:sea_lantern
fill 61 292 635 61 300 635 minecraft:light_gray_concrete
setblock 61 292 636 minecraft:sea_lantern
fill 61 292 637 61 300 637 minecraft:light_gray_concrete
setblock 61 292 638 minecraft:sea_lantern
fill 61 292 639 61 300 639 minecraft:light_gray_concrete
setblock 61 292 640 minecraft:sea_lantern
fill 61 292 641 61 300 641 minecraft:light_gray_concrete
setblock 61 292 642 minecraft:sea_lantern
fill 61 292 643 61 300 643 minecraft:light_gray_concrete
setblock 61 292 644 minecraft:sea_lantern
fill 61 292 645 61 300 645 minecraft:light_gray_concrete
setblock 62 292 605 minecraft:sea_lantern
setblock 62 292 607 minecraft:sea_lantern
setblock 62 292 609 minecraft:sea_lantern
setblock 62 292 611 minecraft:sea_lantern
setblock 62 292 613 minecraft:sea_lantern
setblock 62 292 635 minecraft:sea_lantern
fill 62 292 636 62 300 636 minecraft:light_gray_concrete
setblock 62 292 637 minecraft:sea_lantern
fill 62 292 638 62 300 638 minecraft:light_gray_concrete
setblock 62 292 639 minecraft:sea_lantern
fill 62 292 640 62 300 640 minecraft:light_gray_concrete
setblock 62 292 641 minecraft:sea_lantern
fill 62 292 642 62 300 642 minecraft:light_gray_concrete
setblock 62 292 643 minecraft:sea_lantern
fill 62 292 644 62 300 644 minecraft:light_gray_concrete
setblock 62 292 645 minecraft:sea_lantern
setblock 63 292 606 minecraft:sea_lantern
setblock 63 292 608 minecraft:sea_lantern
setblock 63 292 610 minecraft:sea_lantern
setblock 63 292 612 minecraft:sea_lantern
fill 63 292 635 63 300 635 minecraft:light_gray_concrete
setblock 63 292 636 minecraft:sea_lantern
fill 63 292 637 63 300 637 minecraft:light_gray_concrete
setblock 63 292 638 minecraft:sea_lantern
fill 63 292 639 63 300 639 minecraft:light_gray_concrete
setblock 63 292 640 minecraft:sea_lantern
fill 63 292 641 63 300 641 minecraft:light_gray_concrete
setblock 63 292 642 minecraft:sea_lantern
fill 63 292 643 63 300 643 minecraft:light_gray_concrete
setblock 63 292 644 minecraft:sea_lantern
fill 63 292 645 63 300 645 minecraft:light_gray_concrete
setblock 64 292 605 minecraft:sea_lantern
setblock 64 292 607 minecraft:sea_lantern
setblock 64 292 609 minecraft:sea_lantern
setblock 64 292 611 minecraft:sea_lantern
setblock 64 292 613 minecraft:sea_lantern
setblock 64 292 635 minecraft:sea_lantern
fill 64 292 636 64 300 636 minecraft:light_gray_concrete
setblock 64 292 637 minecraft:sea_lantern
fill 64 292 638 64 300 638 minecraft:light_gray_concrete
setblock 64 292 639 minecraft:sea_lantern
fill 64 292 640 64 300 640 minecraft:light_gray_concrete
setblock 64 292 641 minecraft:sea_lantern
fill 64 292 642 64 300 642 minecraft:light_gray_concrete
setblock 64 292 643 minecraft:sea_lantern
fill 64 292 644 64 300 644 minecraft:light_gray_concrete
setblock 64 292 645 minecraft:sea_lantern
setblock 65 292 606 minecraft:sea_lantern
setblock 65 292 608 minecraft:sea_lantern
setblock 65 292 610 minecraft:sea_lantern
setblock 65 292 612 minecraft:sea_lantern
fill 65 292 635 65 300 635 minecraft:light_gray_concrete
setblock 65 292 636 minecraft:sea_lantern
fill 65 292 637 65 300 637 minecraft:light_gray_concrete
setblock 65 292 638 minecraft:sea_lantern
fill 65 292 639 65 300 639 minecraft:light_gray_concrete
setblock 65 292 640 minecraft:sea_lantern
fill 65 292 641 65 300 641 minecraft:light_gray_concrete
setblock 65 292 642 minecraft:sea_lantern
fill 65 292 643 65 300 643 minecraft:light_gray_concrete
setblock 65 292 644 minecraft:sea_lantern
fill 65 292 645 65 300 645 minecraft:light_gray_concrete
setblock 66 292 605 minecraft:sea_lantern
setblock 66 292 607 minecraft:sea_lantern
setblock 66 292 609 minecraft:sea_lantern
setblock 66 292 611 minecraft:sea_lantern
setblock 66 292 613 minecraft:sea_lantern
setblock 66 292 635 minecraft:sea_lantern
fill 66 292 636 66 300 636 minecraft:light_gray_concrete
setblock 66 292 637 minecraft:sea_lantern
fill 66 292 638 66 300 638 minecraft:light_gray_concrete
setblock 66 292 639 minecraft:sea_lantern
fill 66 292 640 66 300 640 minecraft:light_gray_concrete
setblock 66 292 641 minecraft:sea_lantern
fill 66 292 642 66 300 642 minecraft:light_gray_concrete
setblock 66 292 643 minecraft:sea_lantern
fill 66 292 644 66 300 644 minecraft:light_gray_concrete
setblock 66 292 645 minecraft:sea_lantern
setblock 67 292 606 minecraft:sea_lantern
setblock 67 292 608 minecraft:sea_lantern
setblock 67 292 610 minecraft:sea_lantern
setblock 67 292 612 minecraft:sea_lantern
fill 67 292 635 67 300 635 minecraft:light_gray_concrete
setblock 67 292 636 minecraft:sea_lantern
fill 67 292 637 67 300 637 minecraft:light_gray_concrete
setblock 67 292 638 minecraft:sea_lantern
fill 67 292 639 67 300 639 minecraft:light_gray_concrete
setblock 67 292 640 minecraft:sea_lantern
fill 67 292 641 67 300 641 minecraft:light_gray_concrete
setblock 67 292 642 minecraft:sea_lantern
fill 67 292 643 67 300 643 minecraft:light_gray_concrete
setblock 67 292 644 minecraft:sea_lantern
fill 67 292 645 67 300 645 minecraft:light_gray_concrete
setblock 68 292 605 minecraft:sea_lantern
setblock 68 292 607 minecraft:sea_lantern
setblock 68 292 609 minecraft:sea_lantern
setblock 68 292 611 minecraft:sea_lantern
setblock 68 292 613 minecraft:sea_lantern
setblock 68 292 635 minecraft:sea_lantern
fill 68 292 636 68 300 636 minecraft:light_gray_concrete
setblock 68 292 637 minecraft:sea_lantern
fill 68 292 638 68 300 638 minecraft:light_gray_concrete
setblock 68 292 639 minecraft:sea_lantern
fill 68 292 640 68 300 640 minecraft:light_gray_concrete
setblock 68 292 641 minecraft:sea_lantern
fill 68 292 642 68 300 642 minecraft:light_gray_concrete
setblock 68 292 643 minecraft:sea_lantern
fill 68 292 644 68 300 644 minecraft:light_gray_concrete
setblock 68 292 645 minecraft:sea_lantern
setblock 69 292 606 minecraft:sea_lantern
setblock 69 292 608 minecraft:sea_lantern
setblock 69 292 610 minecraft:sea_lantern
setblock 69 292 612 minecraft:sea_lantern
setblock 70 292 605 minecraft:sea_lantern
setblock 70 292 607 minecraft:sea_lantern
setblock 70 292 609 minecraft:sea_lantern
setblock 70 292 611 minecraft:sea_lantern
setblock 70 292 613 minecraft:sea_lantern
fill 70 292 614 70 293 614 minecraft:glass
setblock 74 292 639 minecraft:sea_lantern
setblock 74 292 641 minecraft:sea_lantern
setblock 74 292 643 minecraft:sea_lantern
setblock 74 292 645 minecraft:sea_lantern
setblock 75 292 638 minecraft:sea_lantern
setblock 75 292 640 minecraft:sea_lantern
setblock 75 292 642 minecraft:sea_lantern
setblock 75 292 644 minecraft:sea_lantern
setblock 76 292 639 minecraft:sea_lantern
setblock 76 292 641 minecraft:sea_lantern
setblock 76 292 643 minecraft:sea_lantern
setblock 76 292 645 minecraft:sea_lantern
setblock 77 292 638 minecraft:sea_lantern
setblock 77 292 640 minecraft:sea_lantern
setblock 77 292 642 minecraft:sea_lantern
setblock 77 292 644 minecraft:sea_lantern
setblock 78 292 639 minecraft:sea_lantern
setblock 78 292 641 minecraft:sea_lantern
setblock 78 292 643 minecraft:sea_lantern
setblock 78 292 645 minecraft:sea_lantern
setblock 79 292 638 minecraft:sea_lantern
setblock 79 292 640 minecraft:sea_lantern
setblock 79 292 642 minecraft:sea_lantern
setblock 79 292 644 minecraft:sea_lantern
setblock 80 292 639 minecraft:sea_lantern
setblock 80 292 641 minecraft:sea_lantern
setblock 80 292 643 minecraft:sea_lantern
setblock 80 292 645 minecraft:sea_lantern
setblock 81 292 638 minecraft:sea_lantern
setblock 81 292 640 minecraft:sea_lantern
setblock 81 292 642 minecraft:sea_lantern
setblock 81 292 644 minecraft:sea_lantern
setblock 82 292 639 minecraft:sea_lantern
setblock 82 292 641 minecraft:sea_lantern
setblock 82 292 643 minecraft:sea_lantern
setblock 82 292 645 minecraft:sea_lantern
setblock 84 292 621 minecraft:sea_lantern
setblock 84 292 623 minecraft:sea_lantern
setblock 84 292 625 minecraft:sea_lantern
setblock 84 292 627 minecraft:sea_lantern
setblock 84 292 629 minecraft:sea_lantern
setblock 84 292 631 minecraft:sea_lantern
setblock 85 292 622 minecraft:sea_lantern
setblock 85 292 624 minecraft:sea_lantern
setblock 85 292 626 minecraft:sea_lantern
setblock 85 292 628 minecraft:sea_lantern
setblock 85 292 630 minecraft:sea_lantern
setblock 86 292 621 minecraft:sea_lantern
setblock 86 292 623 minecraft:sea_lantern
setblock 86 292 625 minecraft:sea_lantern
setblock 86 292 627 minecraft:sea_lantern
setblock 86 292 629 minecraft:sea_lantern
setblock 86 292 631 minecraft:sea_lantern
setblock 87 292 622 minecraft:sea_lantern
setblock 87 292 624 minecraft:sea_lantern
setblock 87 292 626 minecraft:sea_lantern
setblock 87 292 628 minecraft:sea_lantern
setblock 87 292 630 minecraft:sea_lantern
setblock 88 292 621 minecraft:sea_lantern
setblock 88 292 623 minecraft:sea_lantern
setblock 88 292 625 minecraft:sea_lantern
setblock 88 292 627 minecraft:sea_lantern
setblock 88 292 629 minecraft:sea_lantern
setblock 88 292 631 minecraft:sea_lantern
fill 58 293 635 58 294 635 minecraft:light_gray_concrete
fill 58 293 637 58 294 637 minecraft:light_gray_concrete
fill 58 293 639 58 294 639 minecraft:light_gray_concrete
fill 58 293 641 58 294 641 minecraft:light_gray_concrete
fill 58 293 643 58 294 643 minecraft:light_gray_concrete
fill 58 293 645 58 294 645 minecraft:light_gray_concrete
fill 59 293 636 59 294 636 minecraft:light_gray_concrete
fill 59 293 638 59 294 638 minecraft:light_gray_concrete
fill 59 293 640 59 294 640 minecraft:light_gray_concrete
fill 59 293 642 59 294 642 minecraft:light_gray_concrete
fill 59 293 644 59 294 644 minecraft:light_gray_concrete
fill 60 293 605 60 294 605 minecraft:light_gray_concrete
fill 60 293 607 60 294 607 minecraft:light_gray_concrete
fill 60 293 609 60 294 609 minecraft:light_gray_concrete
fill 60 293 611 60 294 611 minecraft:light_gray_concrete
fill 60 293 613 60 294 613 minecraft:light_gray_concrete
fill 60 293 635 60 294 635 minecraft:light_gray_concrete
fill 60 293 637 60 294 637 minecraft:light_gray_concrete
fill 60 293 639 60 294 639 minecraft:light_gray_concrete
fill 60 293 641 60 294 641 minecraft:light_gray_concrete
fill 60 293 643 60 294 643 minecraft:light_gray_concrete
fill 60 293 645 60 294 645 minecraft:light_gray_concrete
fill 61 293 606 61 294 606 minecraft:light_gray_concrete
fill 61 293 608 61 294 608 minecraft:light_gray_concrete
fill 61 293 610 61 294 610 minecraft:light_gray_concrete
fill 61 293 612 61 294 612 minecraft:light_gray_concrete
fill 61 293 636 61 294 636 minecraft:light_gray_concrete
fill 61 293 638 61 294 638 minecraft:light_gray_concrete
fill 61 293 640 61 294 640 minecraft:light_gray_concrete
fill 61 293 642 61 294 642 minecraft:light_gray_concrete
fill 61 293 644 61 294 644 minecraft:light_gray_concrete
fill 62 293 605 62 294 605 minecraft:light_gray_concrete
fill 62 293 607 62 294 607 minecraft:light_gray_concrete
fill 62 293 609 62 294 609 minecraft:light_gray_concrete
fill 62 293 611 62 294 611 minecraft:light_gray_concrete
fill 62 293 613 62 294 613 minecraft:light_gray_concrete
fill 62 293 635 62 294 635 minecraft:light_gray_concrete
fill 62 293 637 62 294 637 minecraft:light_gray_concrete
fill 62 293 639 62 294 639 minecraft:light_gray_concrete
fill 62 293 641 62 294 641 minecraft:light_gray_concrete
fill 62 293 643 62 294 643 minecraft:light_gray_concrete
fill 62 293 645 62 294 645 minecraft:light_gray_concrete
fill 63 293 606 63 294 606 minecraft:light_gray_concrete
fill 63 293 608 63 294 608 minecraft:light_gray_concrete
fill 63 293 610 63 294 610 minecraft:light_gray_concrete
fill 63 293 612 63 294 612 minecraft:light_gray_concrete
fill 63 293 636 63 294 636 minecraft:light_gray_concrete
fill 63 293 638 63 294 638 minecraft:light_gray_concrete
fill 63 293 640 63 294 640 minecraft:light_gray_concrete
fill 63 293 642 63 294 642 minecraft:light_gray_concrete
fill 63 293 644 63 294 644 minecraft:light_gray_concrete
fill 64 293 605 64 294 605 minecraft:light_gray_concrete
fill 64 293 607 64 294 607 minecraft:light_gray_concrete
fill 64 293 609 64 294 609 minecraft:light_gray_concrete
fill 64 293 611 64 294 611 minecraft:light_gray_concrete
fill 64 293 613 64 294 613 minecraft:light_gray_concrete
fill 64 293 635 64 294 635 minecraft:light_gray_concrete
fill 64 293 637 64 294 637 minecraft:light_gray_concrete
fill 64 293 639 64 294 639 minecraft:light_gray_concrete
fill 64 293 641 64 294 641 minecraft:light_gray_concrete
fill 64 293 643 64 294 643 minecraft:light_gray_concrete
fill 64 293 645 64 294 645 minecraft:light_gray_concrete
fill 65 293 606 65 294 606 minecraft:light_gray_concrete
fill 65 293 608 65 294 608 minecraft:light_gray_concrete
fill 65 293 610 65 294 610 minecraft:light_gray_concrete
fill 65 293 612 65 294 612 minecraft:light_gray_concrete
fill 65 293 636 65 294 636 minecraft:light_gray_concrete
fill 65 293 638 65 294 638 minecraft:light_gray_concrete
fill 65 293 640 65 294 640 minecraft:light_gray_concrete
fill 65 293 642 65 294 642 minecraft:light_gray_concrete
fill 65 293 644 65 294 644 minecraft:light_gray_concrete
fill 66 293 605 66 294 605 minecraft:light_gray_concrete
fill 66 293 607 66 294 607 minecraft:light_gray_concrete
fill 66 293 609 66 294 609 minecraft:light_gray_concrete
fill 66 293 611 66 294 611 minecraft:light_gray_concrete
fill 66 293 613 66 294 613 minecraft:light_gray_concrete
fill 66 293 635 66 294 635 minecraft:light_gray_concrete
fill 66 293 637 66 294 637 minecraft:light_gray_concrete
fill 66 293 639 66 294 639 minecraft:light_gray_concrete
fill 66 293 641 66 294 641 minecraft:light_gray_concrete
fill 66 293 643 66 294 643 minecraft:light_gray_concrete
fill 66 293 645 66 294 645 minecraft:light_gray_concrete
fill 67 293 606 67 294 606 minecraft:light_gray_concrete
fill 67 293 608 67 294 608 minecraft:light_gray_concrete
fill 67 293 610 67 294 610 minecraft:light_gray_concrete
fill 67 293 612 67 294 612 minecraft:light_gray_concrete
fill 67 293 636 67 294 636 minecraft:light_gray_concrete
fill 67 293 638 67 294 638 minecraft:light_gray_concrete
fill 67 293 640 67 294 640 minecraft:light_gray_concrete
fill 67 293 642 67 294 642 minecraft:light_gray_concrete
fill 67 293 644 67 294 644 minecraft:light_gray_concrete
fill 68 293 605 68 294 605 minecraft:light_gray_concrete
fill 68 293 607 68 294 607 minecraft:light_gray_concrete
fill 68 293 609 68 294 609 minecraft:light_gray_concrete
fill 68 293 611 68 294 611 minecraft:light_gray_concrete
fill 68 293 613 68 294 613 minecraft:light_gray_concrete
fill 68 293 635 68 294 635 minecraft:light_gray_concrete
fill 68 293 637 68 294 637 minecraft:light_gray_concrete
fill 68 293 639 68 294 639 minecraft:light_gray_concrete
fill 68 293 641 68 294 641 minecraft:light_gray_concrete
fill 68 293 643 68 294 643 minecraft:light_gray_concrete
fill 68 293 645 68 294 645 minecraft:light_gray_concrete
fill 69 293 606 69 294 606 minecraft:light_gray_concrete
fill 69 293 608 69 294 608 minecraft:light_gray_concrete
fill 69 293 610 69 294 610 minecraft:light_gray_concrete
fill 69 293 612 69 294 612 minecraft:light_gray_concrete
fill 70 293 605 70 294 605 minecraft:light_gray_concrete
fill 70 293 607 70 294 607 minecraft:light_gray_concrete
fill 70 293 609 70 294 609 minecraft:light_gray_concrete
fill 70 293 611 70 294 611 minecraft:light_gray_concrete
fill 70 293 613 70 294 613 minecraft:light_gray_concrete
fill 74 293 639 74 294 639 minecraft:light_gray_concrete
fill 74 293 641 74 294 641 minecraft:light_gray_concrete
fill 74 293 643 74 294 643 minecraft:light_gray_concrete
fill 74 293 645 74 294 645 minecraft:light_gray_concrete
fill 75 293 638 75 294 638 minecraft:light_gray_concrete
fill 75 293 640 75 294 640 minecraft:light_gray_concrete
fill 75 293 642 75 294 642 minecraft:light_gray_concrete
fill 75 293 644 75 294 644 minecraft:light_gray_concrete
fill 76 293 639 76 294 639 minecraft:light_gray_concrete
fill 76 293 641 76 294 641 minecraft:light_gray_concrete
fill 76 293 643 76 294 643 minecraft:light_gray_concrete
fill 76 293 645 76 294 645 minecraft:light_gray_concrete
fill 77 293 638 77 294 638 minecraft:light_gray_concrete
fill 77 293 640 77 294 640 minecraft:light_gray_concrete
fill 77 293 642 77 294 642 minecraft:light_gray_concrete
fill 77 293 644 77 294 644 minecraft:light_gray_concrete
fill 78 293 639 78 294 639 minecraft:light_gray_concrete
fill 78 293 641 78 294 641 minecraft:light_gray_concrete
fill 78 293 643 78 294 643 minecraft:light_gray_concrete
fill 78 293 645 78 294 645 minecraft:light_gray_concrete
fill 79 293 638 79 294 638 minecraft:light_gray_concrete
fill 79 293 640 79 294 640 minecraft:light_gray_concrete
fill 79 293 642 79 294 642 minecraft:light_gray_concrete
fill 79 293 644 79 294 644 minecraft:light_gray_concrete
fill 80 293 639 80 294 639 minecraft:light_gray_concrete
fill 80 293 641 80 294 641 minecraft:light_gray_concrete
fill 80 293 643 80 294 643 minecraft:light_gray_concrete
fill 80 293 645 80 294 645 minecraft:light_gray_concrete
fill 81 293 638 81 294 638 minecraft:light_gray_concrete
fill 81 293 640 81 294 640 minecraft:light_gray_concrete
fill 81 293 642 81 294 642 minecraft:light_gray_concrete
fill 81 293 644 81 294 644 minecraft:light_gray_concrete
fill 82 293 639 82 294 639 minecraft:light_gray_concrete
fill 82 293 641 82 294 641 minecraft:light_gray_concrete
fill 82 293 643 82 294 643 minecraft:light_gray_concrete
fill 82 293 645 82 294 645 minecraft:light_gray_concrete
fill 84 293 621 84 294 621 minecraft:light_gray_concrete
fill 84 293 623 84 294 623 minecraft:light_gray_concrete
fill 84 293 625 84 294 625 minecraft:light_gray_concrete
fill 84 293 627 84 294 627 minecraft:light_gray_concrete
fill 84 293 629 84 294 629 minecraft:light_gray_concrete
fill 84 293 631 84 294 631 minecraft:light_gray_concrete
fill 85 293 622 85 294 622 minecraft:light_gray_concrete
fill 85 293 624 85 294 624 minecraft:light_gray_concrete
fill 85 293 626 85 294 626 minecraft:light_gray_concrete
fill 85 293 628 85 294 628 minecraft:light_gray_concrete
fill 85 293 630 85 294 630 minecraft:light_gray_concrete
fill 86 293 621 86 294 621 minecraft:light_gray_concrete
fill 86 293 623 86 294 623 minecraft:light_gray_concrete
fill 86 293 625 86 294 625 minecraft:light_gray_concrete
fill 86 293 627 86 294 627 minecraft:light_gray_concrete
fill 86 293 629 86 294 629 minecraft:light_gray_concrete
fill 86 293 631 86 294 631 minecraft:light_gray_concrete
fill 87 293 622 87 294 622 minecraft:light_gray_concrete
fill 87 293 624 87 294 624 minecraft:light_gray_concrete
fill 87 293 626 87 294 626 minecraft:light_gray_concrete
fill 87 293 628 87 294 628 minecraft:light_gray_concrete
fill 87 293 630 87 294 630 minecraft:light_gray_concrete
fill 88 293 621 88 294 621 minecraft:light_gray_concrete
fill 88 293 623 88 294 623 minecraft:light_gray_concrete
fill 88 293 625 88 294 625 minecraft:light_gray_concrete
fill 88 293 627 88 294 627 minecraft:light_gray_concrete
fill 88 293 629 88 294 629 minecraft:light_gray_concrete
fill 88 293 631 88 294 631 minecraft:light_gray_concrete
fill 48 294 605 48 295 610 minecraft:light_gray_concrete
fill 48 294 613 49 294 618 minecraft:light_gray_concrete
fill 48 294 621 49 294 626 minecraft:light_gray_concrete
fill 48 294 629 49 294 634 minecraft:light_gray_concrete
fill 48 294 637 49 294 642 minecraft:light_gray_concrete
fill 48 294 645 53 295 645 minecraft:light_gray_concrete
fill 49 294 606 49 294 612 minecraft:light_gray_concrete
fill 49 294 619 49 294 620 minecraft:light_gray_concrete
fill 49 294 627 49 294 628 minecraft:light_gray_concrete
fill 49 294 635 49 294 636 minecraft:light_gray_concrete
fill 49 294 643 49 294 644 minecraft:light_gray_concrete
fill 50 294 606 59 294 606 minecraft:light_gray_concrete
fill 50 294 644 57 294 644 minecraft:light_gray_concrete
fill 51 294 605 56 295 605 minecraft:light_gray_concrete
fill 56 294 645 57 295 645 minecraft:light_gray_concrete
fill 59 294 605 59 295 605 minecraft:light_gray_concrete
fill 69 294 644 69 294 645 minecraft:light_gray_concrete
fill 70 294 644 73 294 644 minecraft:light_gray_concrete
fill 71 294 605 72 294 606 minecraft:light_gray_concrete
fill 72 294 645 73 295 645 minecraft:light_gray_concrete
fill 73 294 606 78 294 606 minecraft:light_gray_concrete
fill 75 294 605 80 295 605 minecraft:light_gray_concrete
fill 80 294 622 82 295 623 minecraft:glass
fill 83 294 605 88 295 605 minecraft:light_gray_concrete
fill 83 294 644 85 294 645 minecraft:light_gray_concrete
fill 86 294 644 88 294 644 minecraft:light_gray_concrete
fill 87 294 615 87 294 620 minecraft:light_gray_concrete
fill 87 294 632 87 294 643 minecraft:light_gray_concrete
fill 88 294 616 88 295 620 minecraft:light_gray_concrete
fill 88 294 632 88 295 637 minecraft:light_gray_concrete
fill 88 294 640 88 295 643 minecraft:light_gray_concrete
fill 88 294 645 88 295 645 minecraft:light_gray_concrete
fill 48 295 613 48 295 618 minecraft:light_gray_concrete
fill 48 295 621 48 295 626 minecraft:light_gray_concrete
fill 48 295 629 48 295 634 minecraft:light_gray_concrete
fill 48 295 637 48 295 642 minecraft:light_gray_concrete
setblock 58 295 635 minecraft:sea_lantern
setblock 58 295 637 minecraft:sea_lantern
setblock 58 295 639 minecraft:sea_lantern
setblock 58 295 641 minecraft:sea_lantern
setblock 58 295 643 minecraft:sea_lantern
setblock 58 295 645 minecraft:sea_lantern
setblock 59 295 636 minecraft:sea_lantern
setblock 59 295 638 minecraft:sea_lantern
setblock 59 295 640 minecraft:sea_lantern
setblock 59 295 642 minecraft:sea_lantern
setblock 59 295 644 minecraft:sea_lantern
setblock 60 295 605 minecraft:sea_lantern
setblock 60 295 607 minecraft:sea_lantern
setblock 60 295 609 minecraft:sea_lantern
setblock 60 295 611 minecraft:sea_lantern
setblock 60 295 613 minecraft:sea_lantern
setblock 60 295 635 minecraft:sea_lantern
setblock 60 295 637 minecraft:sea_lantern
setblock 60 295 639 minecraft:sea_lantern
setblock 60 295 641 minecraft:sea_lantern
setblock 60 295 643 minecraft:sea_lantern
setblock 60 295 645 minecraft:sea_lantern
setblock 61 295 606 minecraft:sea_lantern
setblock 61 295 608 minecraft:sea_lantern
setblock 61 295 610 minecraft:sea_lantern
setblock 61 295 612 minecraft:sea_lantern
setblock 61 295 636 minecraft:sea_lantern
setblock 61 295 638 minecraft:sea_lantern
setblock 61 295 640 minecraft:sea_lantern
setblock 61 295 642 minecraft:sea_lantern
setblock 61 295 644 minecraft:sea_lantern
setblock 62 295 605 minecraft:sea_lantern
setblock 62 295 607 minecraft:sea_lantern
setblock 62 295 609 minecraft:sea_lantern
setblock 62 295 611 minecraft:sea_lantern
setblock 62 295 613 minecraft:sea_lantern
setblock 62 295 635 minecraft:sea_lantern
setblock 62 295 637 minecraft:sea_lantern
setblock 62 295 639 minecraft:sea_lantern
setblock 62 295 641 minecraft:sea_lantern
setblock 62 295 643 minecraft:sea_lantern
setblock 62 295 645 minecraft:sea_lantern
setblock 63 295 606 minecraft:sea_lantern
setblock 63 295 608 minecraft:sea_lantern
setblock 63 295 610 minecraft:sea_lantern
setblock 63 295 612 minecraft:sea_lantern
setblock 63 295 636 minecraft:sea_lantern
setblock 63 295 638 minecraft:sea_lantern
setblock 63 295 640 minecraft:sea_lantern
setblock 63 295 642 minecraft:sea_lantern
setblock 63 295 644 minecraft:sea_lantern
setblock 64 295 605 minecraft:sea_lantern
setblock 64 295 607 minecraft:sea_lantern
setblock 64 295 609 minecraft:sea_lantern
setblock 64 295 611 minecraft:sea_lantern
setblock 64 295 613 minecraft:sea_lantern
setblock 64 295 635 minecraft:sea_lantern
setblock 64 295 637 minecraft:sea_lantern
setblock 64 295 639 minecraft:sea_lantern
setblock 64 295 641 minecraft:sea_lantern
setblock 64 295 643 minecraft:sea_lantern
setblock 64 295 645 minecraft:sea_lantern
setblock 65 295 606 minecraft:sea_lantern
setblock 65 295 608 minecraft:sea_lantern
setblock 65 295 610 minecraft:sea_lantern
setblock 65 295 612 minecraft:sea_lantern
setblock 65 295 636 minecraft:sea_lantern
setblock 65 295 638 minecraft:sea_lantern
setblock 65 295 640 minecraft:sea_lantern
setblock 65 295 642 minecraft:sea_lantern
setblock 65 295 644 minecraft:sea_lantern
setblock 66 295 605 minecraft:sea_lantern
setblock 66 295 607 minecraft:sea_lantern
setblock 66 295 609 minecraft:sea_lantern
setblock 66 295 611 minecraft:sea_lantern
setblock 66 295 613 minecraft:sea_lantern
setblock 66 295 635 minecraft:sea_lantern
setblock 66 295 637 minecraft:sea_lantern
setblock 66 295 639 minecraft:sea_lantern
setblock 66 295 641 minecraft:sea_lantern
setblock 66 295 643 minecraft:sea_lantern
setblock 66 295 645 minecraft:sea_lantern
setblock 67 295 606 minecraft:sea_lantern
setblock 67 295 608 minecraft:sea_lantern
setblock 67 295 610 minecraft:sea_lantern
setblock 67 295 612 minecraft:sea_lantern
setblock 67 295 636 minecraft:sea_lantern
setblock 67 295 638 minecraft:sea_lantern
setblock 67 295 640 minecraft:sea_lantern
setblock 67 295 642 minecraft:sea_lantern
setblock 67 295 644 minecraft:sea_lantern
setblock 68 295 605 minecraft:sea_lantern
setblock 68 295 607 minecraft:sea_lantern
setblock 68 295 609 minecraft:sea_lantern
setblock 68 295 611 minecraft:sea_lantern
setblock 68 295 613 minecraft:sea_lantern
setblock 68 295 635 minecraft:sea_lantern
setblock 68 295 637 minecraft:sea_lantern
setblock 68 295 639 minecraft:sea_lantern
setblock 68 295 641 minecraft:sea_lantern
setblock 68 295 643 minecraft:sea_lantern
setblock 68 295 645 minecraft:sea_lantern
setblock 69 295 606 minecraft:sea_lantern
setblock 69 295 608 minecraft:sea_lantern
setblock 69 295 610 minecraft:sea_lantern
setblock 69 295 612 minecraft:sea_lantern
setblock 69 295 645 minecraft:light_gray_concrete
setblock 70 295 605 minecraft:sea_lantern
setblock 70 295 607 minecraft:sea_lantern
setblock 70 295 609 minecraft:sea_lantern
setblock 70 295 611 minecraft:sea_lantern
setblock 70 295 613 minecraft:sea_lantern
fill 71 295 605 72 295 605 minecraft:light_gray_concrete
setblock 74 295 639 minecraft:sea_lantern
setblock 74 295 641 minecraft:sea_lantern
setblock 74 295 643 minecraft:sea_lantern
setblock 74 295 645 minecraft:sea_lantern
setblock 75 295 638 minecraft:sea_lantern
setblock 75 295 640 minecraft:sea_lantern
setblock 75 295 642 minecraft:sea_lantern
setblock 75 295 644 minecraft:sea_lantern
setblock 76 295 639 minecraft:sea_lantern
setblock 76 295 641 minecraft:sea_lantern
setblock 76 295 643 minecraft:sea_lantern
setblock 76 295 645 minecraft:sea_lantern
setblock 77 295 638 minecraft:sea_lantern
setblock 77 295 640 minecraft:sea_lantern
setblock 77 295 642 minecraft:sea_lantern
setblock 77 295 644 minecraft:sea_lantern
setblock 78 295 639 minecraft:sea_lantern
setblock 78 295 641 minecraft:sea_lantern
setblock 78 295 643 minecraft:sea_lantern
setblock 78 295 645 minecraft:sea_lantern
setblock 79 295 638 minecraft:sea_lantern
setblock 79 295 640 minecraft:sea_lantern
setblock 79 295 642 minecraft:sea_lantern
setblock 79 295 644 minecraft:sea_lantern
setblock 80 295 639 minecraft:sea_lantern
setblock 80 295 641 minecraft:sea_lantern
setblock 80 295 643 minecraft:sea_lantern
setblock 80 295 645 minecraft:sea_lantern
setblock 81 295 638 minecraft:sea_lantern
setblock 81 295 640 minecraft:sea_lantern
setblock 81 295 642 minecraft:sea_lantern
setblock 81 295 644 minecraft:sea_lantern
setblock 82 295 639 minecraft:sea_lantern
setblock 82 295 641 minecraft:sea_lantern
setblock 82 295 643 minecraft:sea_lantern
setblock 82 295 645 minecraft:sea_lantern
fill 83 295 645 85 295 645 minecraft:light_gray_concrete
setblock 84 295 621 minecraft:sea_lantern
setblock 84 295 623 minecraft:sea_lantern
setblock 84 295 625 minecraft:sea_lantern
setblock 84 295 627 minecraft:sea_lantern
setblock 84 295 629 minecraft:sea_lantern
setblock 84 295 631 minecraft:sea_lantern
setblock 85 295 622 minecraft:sea_lantern
setblock 85 295 624 minecraft:sea_lantern
setblock 85 295 626 minecraft:sea_lantern
setblock 85 295 628 minecraft:sea_lantern
setblock 85 295 630 minecraft:sea_lantern
setblock 86 295 621 minecraft:sea_lantern
setblock 86 295 623 minecraft:sea_lantern
setblock 86 295 625 minecraft:sea_lantern
setblock 86 295 627 minecraft:sea_lantern
setblock 86 295 629 minecraft:sea_lantern
setblock 86 295 631 minecraft:sea_lantern
setblock 87 295 622 minecraft:sea_lantern
setblock 87 295 624 minecraft:sea_lantern
setblock 87 295 626 minecraft:sea_lantern
setblock 87 295 628 minecraft:sea_lantern
setblock 87 295 630 minecraft:sea_lantern
fill 88 295 606 88 295 614 minecraft:light_gray_concrete
setblock 88 295 621 minecraft:sea_lantern
setblock 88 295 623 minecraft:sea_lantern
setblock 88 295 625 minecraft:sea_lantern
setblock 88 295 627 minecraft:sea_lantern
setblock 88 295 629 minecraft:sea_lantern
setblock 88 295 631 minecraft:sea_lantern
setblock 88 295 644 minecraft:light_gray_concrete
setblock 50 296 607 minecraft:light[level=14]
setblock 50 296 615 minecraft:light[level=14]
setblock 50 296 623 minecraft:light[level=14]
setblock 50 296 631 minecraft:light[level=14]
setblock 50 296 639 minecraft:light[level=14]
setblock 58 296 607 minecraft:light[level=14]
setblock 58 296 615 minecraft:light[level=14]
setblock 58 296 623 minecraft:light[level=14]
setblock 58 296 631 minecraft:light[level=14]
fill 58 296 635 58 297 635 minecraft:light_gray_concrete
fill 58 296 637 58 297 637 minecraft:light_gray_concrete
fill 58 296 639 58 297 639 minecraft:light_gray_concrete
fill 58 296 641 58 297 641 minecraft:light_gray_concrete
fill 58 296 643 58 297 643 minecraft:light_gray_concrete
fill 58 296 645 58 297 645 minecraft:light_gray_concrete
fill 59 296 636 59 297 636 minecraft:light_gray_concrete
fill 59 296 638 59 297 638 minecraft:light_gray_concrete
fill 59 296 640 59 297 640 minecraft:light_gray_concrete
fill 59 296 642 59 297 642 minecraft:light_gray_concrete
fill 59 296 644 59 297 644 minecraft:light_gray_concrete
fill 60 296 605 60 297 605 minecraft:light_gray_concrete
fill 60 296 607 60 297 607 minecraft:light_gray_concrete
fill 60 296 609 60 297 609 minecraft:light_gray_concrete
fill 60 296 611 60 297 611 minecraft:light_gray_concrete
fill 60 296 613 60 297 613 minecraft:light_gray_concrete
fill 60 296 635 60 297 635 minecraft:light_gray_concrete
fill 60 296 637 60 297 637 minecraft:light_gray_concrete
fill 60 296 639 60 297 639 minecraft:light_gray_concrete
fill 60 296 641 60 297 641 minecraft:light_gray_concrete
fill 60 296 643 60 297 643 minecraft:light_gray_concrete
fill 60 296 645 60 297 645 minecraft:light_gray_concrete
fill 61 296 606 61 297 606 minecraft:light_gray_concrete
fill 61 296 608 61 297 608 minecraft:light_gray_concrete
fill 61 296 610 61 297 610 minecraft:light_gray_concrete
fill 61 296 612 61 297 612 minecraft:light_gray_concrete
fill 61 296 636 61 297 636 minecraft:light_gray_concrete
fill 61 296 638 61 297 638 minecraft:light_gray_concrete
fill 61 296 640 61 297 640 minecraft:light_gray_concrete
fill 61 296 642 61 297 642 minecraft:light_gray_concrete
fill 61 296 644 61 297 644 minecraft:light_gray_concrete
fill 62 296 605 62 297 605 minecraft:light_gray_concrete
fill 62 296 607 62 297 607 minecraft:light_gray_concrete
fill 62 296 609 62 297 609 minecraft:light_gray_concrete
fill 62 296 611 62 297 611 minecraft:light_gray_concrete
fill 62 296 613 62 297 613 minecraft:light_gray_concrete
fill 62 296 635 62 297 635 minecraft:light_gray_concrete
fill 62 296 637 62 297 637 minecraft:light_gray_concrete
fill 62 296 639 62 297 639 minecraft:light_gray_concrete
fill 62 296 641 62 297 641 minecraft:light_gray_concrete
fill 62 296 643 62 297 643 minecraft:light_gray_concrete
fill 62 296 645 62 297 645 minecraft:light_gray_concrete
fill 63 296 606 63 297 606 minecraft:light_gray_concrete
fill 63 296 608 63 297 608 minecraft:light_gray_concrete
fill 63 296 610 63 297 610 minecraft:light_gray_concrete
fill 63 296 612 63 297 612 minecraft:light_gray_concrete
fill 63 296 636 63 297 636 minecraft:light_gray_concrete
fill 63 296 638 63 297 638 minecraft:light_gray_concrete
fill 63 296 640 63 297 640 minecraft:light_gray_concrete
fill 63 296 642 63 297 642 minecraft:light_gray_concrete
fill 63 296 644 63 297 644 minecraft:light_gray_concrete
fill 64 296 605 64 297 605 minecraft:light_gray_concrete
fill 64 296 607 64 297 607 minecraft:light_gray_concrete
fill 64 296 609 64 297 609 minecraft:light_gray_concrete
fill 64 296 611 64 297 611 minecraft:light_gray_concrete
fill 64 296 613 64 297 613 minecraft:light_gray_concrete
fill 64 296 635 64 297 635 minecraft:light_gray_concrete
fill 64 296 637 64 297 637 minecraft:light_gray_concrete
fill 64 296 639 64 297 639 minecraft:light_gray_concrete
fill 64 296 641 64 297 641 minecraft:light_gray_concrete
fill 64 296 643 64 297 643 minecraft:light_gray_concrete
fill 64 296 645 64 297 645 minecraft:light_gray_concrete
fill 65 296 606 65 297 606 minecraft:light_gray_concrete
fill 65 296 608 65 297 608 minecraft:light_gray_concrete
fill 65 296 610 65 297 610 minecraft:light_gray_concrete
fill 65 296 612 65 297 612 minecraft:light_gray_concrete
fill 65 296 636 65 297 636 minecraft:light_gray_concrete
fill 65 296 638 65 297 638 minecraft:light_gray_concrete
fill 65 296 640 65 297 640 minecraft:light_gray_concrete
fill 65 296 642 65 297 642 minecraft:light_gray_concrete
fill 65 296 644 65 297 644 minecraft:light_gray_concrete
fill 66 296 605 66 297 605 minecraft:light_gray_concrete
fill 66 296 607 66 297 607 minecraft:light_gray_concrete
fill 66 296 609 66 297 609 minecraft:light_gray_concrete
fill 66 296 611 66 297 611 minecraft:light_gray_concrete
fill 66 296 613 66 297 613 minecraft:light_gray_concrete
setblock 66 296 615 minecraft:light[level=14]
setblock 66 296 623 minecraft:light[level=14]
setblock 66 296 631 minecraft:light[level=14]
fill 66 296 635 66 297 635 minecraft:light_gray_concrete
fill 66 296 637 66 297 637 minecraft:light_gray_concrete
fill 66 296 639 66 297 639 minecraft:light_gray_concrete
fill 66 296 641 66 297 641 minecraft:light_gray_concrete
fill 66 296 643 66 297 643 minecraft:light_gray_concrete
fill 66 296 645 66 297 645 minecraft:light_gray_concrete
fill 67 296 606 67 297 606 minecraft:light_gray_concrete
fill 67 296 608 67 297 608 minecraft:light_gray_concrete
fill 67 296 610 67 297 610 minecraft:light_gray_concrete
fill 67 296 612 67 297 612 minecraft:light_gray_concrete
fill 67 296 636 67 297 636 minecraft:light_gray_concrete
fill 67 296 638 67 297 638 minecraft:light_gray_concrete
fill 67 296 640 67 297 640 minecraft:light_gray_concrete
fill 67 296 642 67 297 642 minecraft:light_gray_concrete
fill 67 296 644 67 297 644 minecraft:light_gray_concrete
fill 68 296 605 68 297 605 minecraft:light_gray_concrete
fill 68 296 607 68 297 607 minecraft:light_gray_concrete
fill 68 296 609 68 297 609 minecraft:light_gray_concrete
fill 68 296 611 68 297 611 minecraft:light_gray_concrete
fill 68 296 613 68 297 613 minecraft:light_gray_concrete
fill 68 296 635 68 297 635 minecraft:light_gray_concrete
fill 68 296 637 68 297 637 minecraft:light_gray_concrete
fill 68 296 639 68 297 639 minecraft:light_gray_concrete
fill 68 296 641 68 297 641 minecraft:light_gray_concrete
fill 68 296 643 68 297 643 minecraft:light_gray_concrete
fill 68 296 645 68 297 645 minecraft:light_gray_concrete
fill 69 296 606 69 297 606 minecraft:light_gray_concrete
fill 69 296 608 69 297 608 minecraft:light_gray_concrete
fill 69 296 610 69 297 610 minecraft:light_gray_concrete
fill 69 296 612 69 297 612 minecraft:light_gray_concrete
fill 70 296 605 70 297 605 minecraft:light_gray_concrete
fill 70 296 607 70 297 607 minecraft:light_gray_concrete
fill 70 296 609 70 297 609 minecraft:light_gray_concrete
fill 70 296 611 70 297 611 minecraft:light_gray_concrete
fill 70 296 613 70 297 613 minecraft:light_gray_concrete
setblock 74 296 607 minecraft:light[level=14]
setblock 74 296 615 minecraft:light[level=14]
setblock 74 296 623 minecraft:light[level=14]
setblock 74 296 631 minecraft:light[level=14]
fill 74 296 639 74 297 639 minecraft:light_gray_concrete
fill 74 296 641 74 297 641 minecraft:light_gray_concrete
fill 74 296 643 74 297 643 minecraft:light_gray_concrete
fill 74 296 645 74 297 645 minecraft:light_gray_concrete
fill 75 296 638 75 297 638 minecraft:light_gray_concrete
fill 75 296 640 75 297 640 minecraft:light_gray_concrete
fill 75 296 642 75 297 642 minecraft:light_gray_concrete
fill 75 296 644 75 297 644 minecraft:light_gray_concrete
fill 76 296 639 76 297 639 minecraft:light_gray_concrete
fill 76 296 641 76 297 641 minecraft:light_gray_concrete
fill 76 296 643 76 297 643 minecraft:light_gray_concrete
fill 76 296 645 76 297 645 minecraft:light_gray_concrete
fill 77 296 638 77 297 638 minecraft:light_gray_concrete
fill 77 296 640 77 297 640 minecraft:light_gray_concrete
fill 77 296 642 77 297 642 minecraft:light_gray_concrete
fill 77 296 644 77 297 644 minecraft:light_gray_concrete
fill 78 296 639 78 297 639 minecraft:light_gray_concrete
fill 78 296 641 78 297 641 minecraft:light_gray_concrete
fill 78 296 643 78 297 643 minecraft:light_gray_concrete
fill 78 296 645 78 297 645 minecraft:light_gray_concrete
fill 79 296 638 79 297 638 minecraft:light_gray_concrete
fill 79 296 640 79 297 640 minecraft:light_gray_concrete
fill 79 296 642 79 297 642 minecraft:light_gray_concrete
fill 79 296 644 79 297 644 minecraft:light_gray_concrete
fill 80 296 639 80 297 639 minecraft:light_gray_concrete
fill 80 296 641 80 297 641 minecraft:light_gray_concrete
fill 80 296 643 80 297 643 minecraft:light_gray_concrete
fill 80 296 645 80 297 645 minecraft:light_gray_concrete
fill 81 296 638 81 297 638 minecraft:light_gray_concrete
fill 81 296 640 81 297 640 minecraft:light_gray_concrete
fill 81 296 642 81 297 642 minecraft:light_gray_concrete
fill 81 296 644 81 297 644 minecraft:light_gray_concrete
setblock 82 296 607 minecraft:light[level=14]
setblock 82 296 615 minecraft:light[level=14]
setblock 82 296 623 minecraft:light[level=14]
setblock 82 296 631 minecraft:light[level=14]
fill 82 296 639 82 297 639 minecraft:light_gray_concrete
fill 82 296 641 82 297 641 minecraft:light_gray_concrete
fill 82 296 643 82 297 643 minecraft:light_gray_concrete
fill 82 296 645 82 297 645 minecraft:light_gray_concrete
fill 84 296 621 84 297 621 minecraft:light_gray_concrete
fill 84 296 623 84 297 623 minecraft:light_gray_concrete
fill 84 296 625 84 297 625 minecraft:light_gray_concrete
fill 84 296 627 84 297 627 minecraft:light_gray_concrete
fill 84 296 629 84 297 629 minecraft:light_gray_concrete
fill 84 296 631 84 297 631 minecraft:light_gray_concrete
fill 85 296 622 85 297 622 minecraft:light_gray_concrete
fill 85 296 624 85 297 624 minecraft:light_gray_concrete
fill 85 296 626 85 297 626 minecraft:light_gray_concrete
fill 85 296 628 85 297 628 minecraft:light_gray_concrete
fill 85 296 630 85 297 630 minecraft:light_gray_concrete
fill 86 296 621 86 297 621 minecraft:light_gray_concrete
fill 86 296 623 86 297 623 minecraft:light_gray_concrete
fill 86 296 625 86 297 625 minecraft:light_gray_concrete
fill 86 296 627 86 297 627 minecraft:light_gray_concrete
fill 86 296 629 86 297 629 minecraft:light_gray_concrete
fill 86 296 631 86 297 631 minecraft:light_gray_concrete
fill 87 296 622 87 297 622 minecraft:light_gray_concrete
fill 87 296 624 87 297 624 minecraft:light_gray_concrete
fill 87 296 626 87 297 626 minecraft:light_gray_concrete
fill 87 296 628 87 297 628 minecraft:light_gray_concrete
fill 87 296 630 87 297 630 minecraft:light_gray_concrete
fill 88 296 606 88 300 607 minecraft:light_gray_concrete
fill 88 296 614 88 300 614 minecraft:light_gray_concrete
fill 88 296 621 88 297 621 minecraft:light_gray_concrete
fill 88 296 623 88 297 623 minecraft:light_gray_concrete
fill 88 296 625 88 297 625 minecraft:light_gray_concrete
fill 88 296 627 88 297 627 minecraft:light_gray_concrete
fill 88 296 629 88 297 629 minecraft:light_gray_concrete
fill 88 296 631 88 297 631 minecraft:light_gray_concrete
fill 47 298 609 47 300 609 minecraft:sea_lantern
fill 47 298 617 47 300 617 minecraft:sea_lantern
fill 47 298 625 47 300 625 minecraft:sea_lantern
fill 47 298 633 47 300 633 minecraft:sea_lantern
fill 47 298 641 47 300 641 minecraft:sea_lantern
fill 50 298 646 50 300 646 minecraft:sea_lantern
fill 54 298 604 54 300 604 minecraft:sea_lantern
setblock 58 298 635 minecraft:sea_lantern
setblock 58 298 637 minecraft:sea_lantern
setblock 58 298 639 minecraft:sea_lantern
setblock 58 298 641 minecraft:sea_lantern
setblock 58 298 643 minecraft:sea_lantern
fill 58 298 645 58 298 646 minecraft:sea_lantern
setblock 59 298 636 minecraft:sea_lantern
setblock 59 298 638 minecraft:sea_lantern
setblock 59 298 640 minecraft:sea_lantern
setblock 59 298 642 minecraft:sea_lantern
setblock 59 298 644 minecraft:sea_lantern
setblock 60 298 605 minecraft:sea_lantern
setblock 60 298 607 minecraft:sea_lantern
setblock 60 298 609 minecraft:sea_lantern
setblock 60 298 611 minecraft:sea_lantern
setblock 60 298 613 minecraft:sea_lantern
setblock 60 298 635 minecraft:sea_lantern
setblock 60 298 637 minecraft:sea_lantern
setblock 60 298 639 minecraft:sea_lantern
setblock 60 298 641 minecraft:sea_lantern
setblock 60 298 643 minecraft:sea_lantern
setblock 60 298 645 minecraft:sea_lantern
setblock 61 298 606 minecraft:sea_lantern
setblock 61 298 608 minecraft:sea_lantern
setblock 61 298 610 minecraft:sea_lantern
setblock 61 298 612 minecraft:sea_lantern
setblock 61 298 636 minecraft:sea_lantern
setblock 61 298 638 minecraft:sea_lantern
setblock 61 298 640 minecraft:sea_lantern
setblock 61 298 642 minecraft:sea_lantern
setblock 61 298 644 minecraft:sea_lantern
fill 62 298 604 62 298 605 minecraft:sea_lantern
setblock 62 298 607 minecraft:sea_lantern
setblock 62 298 609 minecraft:sea_lantern
setblock 62 298 611 minecraft:sea_lantern
setblock 62 298 613 minecraft:sea_lantern
setblock 62 298 635 minecraft:sea_lantern
setblock 62 298 637 minecraft:sea_lantern
setblock 62 298 639 minecraft:sea_lantern
setblock 62 298 641 minecraft:sea_lantern
setblock 62 298 643 minecraft:sea_lantern
setblock 62 298 645 minecraft:sea_lantern
setblock 63 298 606 minecraft:sea_lantern
setblock 63 298 608 minecraft:sea_lantern
setblock 63 298 610 minecraft:sea_lantern
setblock 63 298 612 minecraft:sea_lantern
setblock 63 298 636 minecraft:sea_lantern
setblock 63 298 638 minecraft:sea_lantern
setblock 63 298 640 minecraft:sea_lantern
setblock 63 298 642 minecraft:sea_lantern
setblock 63 298 644 minecraft:sea_lantern
setblock 64 298 605 minecraft:sea_lantern
setblock 64 298 607 minecraft:sea_lantern
setblock 64 298 609 minecraft:sea_lantern
setblock 64 298 611 minecraft:sea_lantern
setblock 64 298 613 minecraft:sea_lantern
setblock 64 298 635 minecraft:sea_lantern
setblock 64 298 637 minecraft:sea_lantern
setblock 64 298 639 minecraft:sea_lantern
setblock 64 298 641 minecraft:sea_lantern
setblock 64 298 643 minecraft:sea_lantern
setblock 64 298 645 minecraft:sea_lantern
setblock 65 298 606 minecraft:sea_lantern
setblock 65 298 608 minecraft:sea_lantern
setblock 65 298 610 minecraft:sea_lantern
setblock 65 298 612 minecraft:sea_lantern
setblock 65 298 636 minecraft:sea_lantern
setblock 65 298 638 minecraft:sea_lantern
setblock 65 298 640 minecraft:sea_lantern
setblock 65 298 642 minecraft:sea_lantern
setblock 65 298 644 minecraft:sea_lantern
setblock 66 298 605 minecraft:sea_lantern
setblock 66 298 607 minecraft:sea_lantern
setblock 66 298 609 minecraft:sea_lantern
setblock 66 298 611 minecraft:sea_lantern
setblock 66 298 613 minecraft:sea_lantern
setblock 66 298 635 minecraft:sea_lantern
setblock 66 298 637 minecraft:sea_lantern
setblock 66 298 639 minecraft:sea_lantern
setblock 66 298 641 minecraft:sea_lantern
setblock 66 298 643 minecraft:sea_lantern
fill 66 298 645 66 298 646 minecraft:sea_lantern
setblock 67 298 606 minecraft:sea_lantern
setblock 67 298 608 minecraft:sea_lantern
setblock 67 298 610 minecraft:sea_lantern
setblock 67 298 612 minecraft:sea_lantern
setblock 67 298 636 minecraft:sea_lantern
setblock 67 298 638 minecraft:sea_lantern
setblock 67 298 640 minecraft:sea_lantern
setblock 67 298 642 minecraft:sea_lantern
setblock 67 298 644 minecraft:sea_lantern
setblock 68 298 605 minecraft:sea_lantern
setblock 68 298 607 minecraft:sea_lantern
setblock 68 298 609 minecraft:sea_lantern
setblock 68 298 611 minecraft:sea_lantern
setblock 68 298 613 minecraft:sea_lantern
setblock 68 298 635 minecraft:sea_lantern
setblock 68 298 637 minecraft:sea_lantern
setblock 68 298 639 minecraft:sea_lantern
setblock 68 298 641 minecraft:sea_lantern
setblock 68 298 643 minecraft:sea_lantern
setblock 68 298 645 minecraft:sea_lantern
setblock 69 298 606 minecraft:sea_lantern
setblock 69 298 608 minecraft:sea_lantern
setblock 69 298 610 minecraft:sea_lantern
setblock 69 298 612 minecraft:sea_lantern
fill 70 298 604 70 298 605 minecraft:sea_lantern
setblock 70 298 607 minecraft:sea_lantern
setblock 70 298 609 minecraft:sea_lantern
setblock 70 298 611 minecraft:sea_lantern
setblock 70 298 613 minecraft:sea_lantern
setblock 74 298 639 minecraft:sea_lantern
setblock 74 298 641 minecraft:sea_lantern
setblock 74 298 643 minecraft:sea_lantern
fill 74 298 645 74 298 646 minecraft:sea_lantern
setblock 75 298 638 minecraft:sea_lantern
setblock 75 298 640 minecraft:sea_lantern
setblock 75 298 642 minecraft:sea_lantern
setblock 75 298 644 minecraft:sea_lantern
setblock 76 298 639 minecraft:sea_lantern
setblock 76 298 641 minecraft:sea_lantern
setblock 76 298 643 minecraft:sea_lantern
setblock 76 298 645 minecraft:sea_lantern
setblock 77 298 638 minecraft:sea_lantern
setblock 77 298 640 minecraft:sea_lantern
setblock 77 298 642 minecraft:sea_lantern
setblock 77 298 644 minecraft:sea_lantern
fill 78 298 604 78 300 604 minecraft:sea_lantern
setblock 78 298 639 minecraft:sea_lantern
setblock 78 298 641 minecraft:sea_lantern
setblock 78 298 643 minecraft:sea_lantern
setblock 78 298 645 minecraft:sea_lantern
setblock 79 298 638 minecraft:sea_lantern
setblock 79 298 640 minecraft:sea_lantern
setblock 79 298 642 minecraft:sea_lantern
setblock 79 298 644 minecraft:sea_lantern
setblock 80 298 639 minecraft:sea_lantern
setblock 80 298 641 minecraft:sea_lantern
setblock 80 298 643 minecraft:sea_lantern
setblock 80 298 645 minecraft:sea_lantern
setblock 81 298 638 minecraft:sea_lantern
setblock 81 298 640 minecraft:sea_lantern
setblock 81 298 642 minecraft:sea_lantern
setblock 81 298 644 minecraft:sea_lantern
setblock 82 298 639 minecraft:sea_lantern
setblock 82 298 641 minecraft:sea_lantern
setblock 82 298 643 minecraft:sea_lantern
fill 82 298 645 82 298 646 minecraft:sea_lantern
setblock 84 298 621 minecraft:sea_lantern
setblock 84 298 623 minecraft:sea_lantern
setblock 84 298 625 minecraft:sea_lantern
setblock 84 298 627 minecraft:sea_lantern
setblock 84 298 629 minecraft:sea_lantern
setblock 84 298 631 minecraft:sea_lantern
setblock 85 298 622 minecraft:sea_lantern
setblock 85 298 624 minecraft:sea_lantern
setblock 85 298 626 minecraft:sea_lantern
setblock 85 298 628 minecraft:sea_lantern
setblock 85 298 630 minecraft:sea_lantern
fill 86 298 604 86 300 604 minecraft:sea_lantern
setblock 86 298 621 minecraft:sea_lantern
setblock 86 298 623 minecraft:sea_lantern
setblock 86 298 625 minecraft:sea_lantern
setblock 86 298 627 minecraft:sea_lantern
setblock 86 298 629 minecraft:sea_lantern
setblock 86 298 631 minecraft:sea_lantern
setblock 87 298 622 minecraft:sea_lantern
setblock 87 298 624 minecraft:sea_lantern
setblock 87 298 626 minecraft:sea_lantern
setblock 87 298 628 minecraft:sea_lantern
setblock 87 298 630 minecraft:sea_lantern
setblock 88 298 621 minecraft:sea_lantern
setblock 88 298 623 minecraft:sea_lantern
fill 88 298 625 89 298 625 minecraft:sea_lantern
setblock 88 298 627 minecraft:sea_lantern
setblock 88 298 629 minecraft:sea_lantern
setblock 88 298 631 minecraft:sea_lantern
fill 89 298 609 89 300 609 minecraft:sea_lantern
fill 89 298 617 89 300 617 minecraft:sea_lantern
fill 89 298 633 89 300 633 minecraft:sea_lantern
fill 89 298 641 89 300 641 minecraft:sea_lantern
fill 58 299 635 58 300 635 minecraft:light_gray_concrete
fill 58 299 637 58 300 637 minecraft:light_gray_concrete
fill 58 299 639 58 300 639 minecraft:light_gray_concrete
fill 58 299 641 58 300 641 minecraft:light_gray_concrete
fill 58 299 643 58 300 643 minecraft:light_gray_concrete
fill 58 299 645 58 300 645 minecraft:light_gray_concrete
fill 58 299 646 58 300 646 minecraft:sea_lantern
fill 59 299 636 59 300 636 minecraft:light_gray_concrete
fill 59 299 638 59 300 638 minecraft:light_gray_concrete
fill 59 299 640 59 300 640 minecraft:light_gray_concrete
fill 59 299 642 59 300 642 minecraft:light_gray_concrete
fill 59 299 644 59 300 644 minecraft:light_gray_concrete
fill 60 299 605 60 300 605 minecraft:light_gray_concrete
fill 60 299 607 60 300 607 minecraft:light_gray_concrete
fill 60 299 609 60 300 609 minecraft:light_gray_concrete
fill 60 299 611 60 300 611 minecraft:light_gray_concrete
fill 60 299 613 60 300 613 minecraft:light_gray_concrete
fill 60 299 635 60 300 635 minecraft:light_gray_concrete
fill 60 299 637 60 300 637 minecraft:light_gray_concrete
fill 60 299 639 60 300 639 minecraft:light_gray_concrete
fill 60 299 641 60 300 641 minecraft:light_gray_concrete
fill 60 299 643 60 300 643 minecraft:light_gray_concrete
fill 60 299 645 60 300 645 minecraft:light_gray_concrete
fill 61 299 606 61 300 606 minecraft:light_gray_concrete
fill 61 299 608 61 300 608 minecraft:light_gray_concrete
fill 61 299 610 61 300 610 minecraft:light_gray_concrete
fill 61 299 612 61 300 612 minecraft:light_gray_concrete
fill 61 299 636 61 300 636 minecraft:light_gray_concrete
fill 61 299 638 61 300 638 minecraft:light_gray_concrete
fill 61 299 640 61 300 640 minecraft:light_gray_concrete
fill 61 299 642 61 300 642 minecraft:light_gray_concrete
fill 61 299 644 61 300 644 minecraft:light_gray_concrete
fill 62 299 604 62 300 604 minecraft:sea_lantern
fill 62 299 605 62 300 605 minecraft:light_gray_concrete
fill 62 299 607 62 300 607 minecraft:light_gray_concrete
fill 62 299 609 62 300 609 minecraft:light_gray_concrete
fill 62 299 611 62 300 611 minecraft:light_gray_concrete
fill 62 299 613 62 300 613 minecraft:light_gray_concrete
fill 62 299 635 62 300 635 minecraft:light_gray_concrete
fill 62 299 637 62 300 637 minecraft:light_gray_concrete
fill 62 299 639 62 300 639 minecraft:light_gray_concrete
fill 62 299 641 62 300 641 minecraft:light_gray_concrete
fill 62 299 643 62 300 643 minecraft:light_gray_concrete
fill 62 299 645 62 300 645 minecraft:light_gray_concrete
fill 63 299 606 63 300 606 minecraft:light_gray_concrete
fill 63 299 608 63 300 608 minecraft:light_gray_concrete
fill 63 299 610 63 300 610 minecraft:light_gray_concrete
fill 63 299 612 63 300 612 minecraft:light_gray_concrete
fill 63 299 636 63 300 636 minecraft:light_gray_concrete
fill 63 299 638 63 300 638 minecraft:light_gray_concrete
fill 63 299 640 63 300 640 minecraft:light_gray_concrete
fill 63 299 642 63 300 642 minecraft:light_gray_concrete
fill 63 299 644 63 300 644 minecraft:light_gray_concrete
fill 64 299 605 64 300 605 minecraft:light_gray_concrete
fill 64 299 607 64 300 607 minecraft:light_gray_concrete
fill 64 299 609 64 300 609 minecraft:light_gray_concrete
fill 64 299 611 64 300 611 minecraft:light_gray_concrete
fill 64 299 613 64 300 613 minecraft:light_gray_concrete
fill 64 299 635 64 300 635 minecraft:light_gray_concrete
fill 64 299 637 64 300 637 minecraft:light_gray_concrete
fill 64 299 639 64 300 639 minecraft:light_gray_concrete
fill 64 299 641 64 300 641 minecraft:light_gray_concrete
fill 64 299 643 64 300 643 minecraft:light_gray_concrete
fill 64 299 645 64 300 645 minecraft:light_gray_concrete
fill 65 299 606 65 300 606 minecraft:light_gray_concrete
fill 65 299 608 65 300 608 minecraft:light_gray_concrete
fill 65 299 610 65 300 610 minecraft:light_gray_concrete
fill 65 299 612 65 300 612 minecraft:light_gray_concrete
fill 65 299 636 65 300 636 minecraft:light_gray_concrete
fill 65 299 638 65 300 638 minecraft:light_gray_concrete
fill 65 299 640 65 300 640 minecraft:light_gray_concrete
fill 65 299 642 65 300 642 minecraft:light_gray_concrete
fill 65 299 644 65 300 644 minecraft:light_gray_concrete
fill 66 299 605 66 300 605 minecraft:light_gray_concrete
fill 66 299 607 66 300 607 minecraft:light_gray_concrete
fill 66 299 609 66 300 609 minecraft:light_gray_concrete
fill 66 299 611 66 300 611 minecraft:light_gray_concrete
fill 66 299 613 66 300 613 minecraft:light_gray_concrete
fill 66 299 635 66 300 635 minecraft:light_gray_concrete
fill 66 299 637 66 300 637 minecraft:light_gray_concrete
fill 66 299 639 66 300 639 minecraft:light_gray_concrete
fill 66 299 641 66 300 641 minecraft:light_gray_concrete
fill 66 299 643 66 300 643 minecraft:light_gray_concrete
fill 66 299 645 66 300 645 minecraft:light_gray_concrete
fill 66 299 646 66 300 646 minecraft:sea_lantern
fill 67 299 606 67 300 606 minecraft:light_gray_concrete
fill 67 299 608 67 300 608 minecraft:light_gray_concrete
fill 67 299 610 67 300 610 minecraft:light_gray_concrete
fill 67 299 612 67 300 612 minecraft:light_gray_concrete
fill 67 299 636 67 300 636 minecraft:light_gray_concrete
fill 67 299 638 67 300 638 minecraft:light_gray_concrete
fill 67 299 640 67 300 640 minecraft:light_gray_concrete
fill 67 299 642 67 300 642 minecraft:light_gray_concrete
fill 67 299 644 67 300 644 minecraft:light_gray_concrete
fill 68 299 605 68 300 605 minecraft:light_gray_concrete
fill 68 299 607 68 300 607 minecraft:light_gray_concrete
fill 68 299 609 68 300 609 minecraft:light_gray_concrete
fill 68 299 611 68 300 611 minecraft:light_gray_concrete
fill 68 299 613 68 300 613 minecraft:light_gray_concrete
fill 68 299 635 68 300 635 minecraft:light_gray_concrete
fill 68 299 637 68 300 637 minecraft:light_gray_concrete
fill 68 299 639 68 300 639 minecraft:light_gray_concrete
fill 68 299 641 68 300 641 minecraft:light_gray_concrete
fill 68 299 643 68 300 643 minecraft:light_gray_concrete
fill 68 299 645 68 300 645 minecraft:light_gray_concrete
fill 69 299 606 69 300 606 minecraft:light_gray_concrete
fill 69 299 608 69 300 608 minecraft:light_gray_concrete
fill 69 299 610 69 300 610 minecraft:light_gray_concrete
fill 69 299 612 69 300 612 minecraft:light_gray_concrete
fill 70 299 604 70 300 604 minecraft:sea_lantern
fill 70 299 605 70 300 605 minecraft:light_gray_concrete
fill 70 299 607 70 300 607 minecraft:light_gray_concrete
fill 70 299 609 70 300 609 minecraft:light_gray_concrete
fill 70 299 611 70 300 611 minecraft:light_gray_concrete
fill 70 299 613 70 300 613 minecraft:light_gray_concrete
fill 74 299 639 74 300 639 minecraft:light_gray_concrete
fill 74 299 641 74 300 641 minecraft:light_gray_concrete
fill 74 299 643 74 300 643 minecraft:light_gray_concrete
fill 74 299 645 74 300 645 minecraft:light_gray_concrete
fill 74 299 646 74 300 646 minecraft:sea_lantern
fill 75 299 638 75 300 638 minecraft:light_gray_concrete
fill 75 299 640 75 300 640 minecraft:light_gray_concrete
fill 75 299 642 75 300 642 minecraft:light_gray_concrete
fill 75 299 644 75 300 644 minecraft:light_gray_concrete
fill 76 299 639 76 300 639 minecraft:light_gray_concrete
fill 76 299 641 76 300 641 minecraft:light_gray_concrete
fill 76 299 643 76 300 643 minecraft:light_gray_concrete
fill 76 299 645 76 300 645 minecraft:light_gray_concrete
fill 77 299 638 77 300 638 minecraft:light_gray_concrete
fill 77 299 640 77 300 640 minecraft:light_gray_concrete
fill 77 299 642 77 300 642 minecraft:light_gray_concrete
fill 77 299 644 77 300 644 minecraft:light_gray_concrete
fill 78 299 639 78 300 639 minecraft:light_gray_concrete
fill 78 299 641 78 300 641 minecraft:light_gray_concrete
fill 78 299 643 78 300 643 minecraft:light_gray_concrete
fill 78 299 645 78 300 645 minecraft:light_gray_concrete
fill 79 299 638 79 300 638 minecraft:light_gray_concrete
fill 79 299 640 79 300 640 minecraft:light_gray_concrete
fill 79 299 642 79 300 642 minecraft:light_gray_concrete
fill 79 299 644 79 300 644 minecraft:light_gray_concrete
fill 80 299 639 80 300 639 minecraft:light_gray_concrete
fill 80 299 641 80 300 641 minecraft:light_gray_concrete
fill 80 299 643 80 300 643 minecraft:light_gray_concrete
fill 80 299 645 80 300 645 minecraft:light_gray_concrete
fill 81 299 638 81 300 638 minecraft:light_gray_concrete
fill 81 299 640 81 300 640 minecraft:light_gray_concrete
fill 81 299 642 81 300 642 minecraft:light_gray_concrete
fill 81 299 644 81 300 644 minecraft:light_gray_concrete
fill 82 299 639 82 300 639 minecraft:light_gray_concrete
fill 82 299 641 82 300 641 minecraft:light_gray_concrete
fill 82 299 643 82 300 643 minecraft:light_gray_concrete
fill 82 299 645 82 300 645 minecraft:light_gray_concrete
fill 82 299 646 82 300 646 minecraft:sea_lantern
fill 84 299 621 84 300 621 minecraft:light_gray_concrete
fill 84 299 623 84 300 623 minecraft:light_gray_concrete
fill 84 299 625 84 300 625 minecraft:light_gray_concrete
fill 84 299 627 84 300 627 minecraft:light_gray_concrete
fill 84 299 629 84 300 629 minecraft:light_gray_concrete
fill 84 299 631 84 300 631 minecraft:light_gray_concrete
fill 85 299 622 85 300 622 minecraft:light_gray_concrete
fill 85 299 624 85 300 624 minecraft:light_gray_concrete
fill 85 299 626 85 300 626 minecraft:light_gray_concrete
fill 85 299 628 85 300 628 minecraft:light_gray_concrete
fill 85 299 630 85 300 630 minecraft:light_gray_concrete
fill 86 299 621 86 300 621 minecraft:light_gray_concrete
fill 86 299 623 86 300 623 minecraft:light_gray_concrete
fill 86 299 625 86 300 625 minecraft:light_gray_concrete
fill 86 299 627 86 300 627 minecraft:light_gray_concrete
fill 86 299 629 86 300 629 minecraft:light_gray_concrete
fill 86 299 631 86 300 631 minecraft:light_gray_concrete
fill 87 299 622 87 300 622 minecraft:light_gray_concrete
fill 87 299 624 87 300 624 minecraft:light_gray_concrete
fill 87 299 626 87 300 626 minecraft:light_gray_concrete
fill 87 299 628 87 300 628 minecraft:light_gray_concrete
fill 87 299 630 87 300 630 minecraft:light_gray_concrete
fill 88 299 621 88 300 621 minecraft:light_gray_concrete
fill 88 299 623 88 300 623 minecraft:light_gray_concrete
fill 88 299 625 88 300 625 minecraft:light_gray_concrete
fill 88 299 627 88 300 627 minecraft:light_gray_concrete
fill 88 299 629 88 300 629 minecraft:light_gray_concrete
fill 88 299 631 88 300 631 minecraft:light_gray_concrete
fill 89 299 625 89 300 625 minecraft:sea_lantern
fill 47 301 609 47 307 609 minecraft:gray_concrete
fill 47 301 617 47 307 617 minecraft:gray_concrete
fill 47 301 625 47 307 625 minecraft:gray_concrete
fill 47 301 633 47 307 633 minecraft:gray_concrete
fill 47 301 641 47 307 641 minecraft:gray_concrete
fill 50 301 646 50 307 646 minecraft:gray_concrete
fill 54 301 604 54 307 604 minecraft:gray_concrete
fill 58 301 646 58 307 646 minecraft:gray_concrete
fill 62 301 604 62 307 604 minecraft:gray_concrete
fill 66 301 646 66 307 646 minecraft:gray_concrete
fill 70 301 604 70 307 604 minecraft:gray_concrete
fill 74 301 646 74 307 646 minecraft:gray_concrete
fill 78 301 604 78 307 604 minecraft:gray_concrete
fill 82 301 646 82 307 646 minecraft:gray_concrete
fill 86 301 604 86 307 604 minecraft:gray_concrete
fill 89 301 609 89 307 609 minecraft:gray_concrete
fill 89 301 617 89 307 617 minecraft:gray_concrete
fill 89 301 625 89 307 625 minecraft:gray_concrete
fill 89 301 633 89 307 633 minecraft:gray_concrete
fill 89 301 641 89 307 641 minecraft:gray_concrete
