fill 135 162 517 135 165 517 minecraft:blackstone
setblock 135 162 521 minecraft:smooth_basalt
fill 135 162 522 135 165 522 minecraft:blackstone
setblock 135 162 526 minecraft:smooth_basalt
fill 135 162 527 135 165 527 minecraft:blackstone
setblock 135 162 531 minecraft:smooth_basalt
fill 135 162 532 135 165 532 minecraft:blackstone
setblock 135 162 536 minecraft:smooth_basalt
fill 135 162 537 135 165 537 minecraft:blackstone
setblock 135 162 546 minecraft:smooth_basalt
fill 135 162 547 135 163 547 minecraft:blackstone
setblock 135 162 551 minecraft:smooth_basalt
fill 95 163 511 95 163 514 minecraft:blackstone
setblock 95 163 515 minecraft:smooth_basalt
fill 95 163 516 95 163 519 minecraft:blackstone
setblock 95 163 520 minecraft:smooth_basalt
setblock 95 163 521 minecraft:blackstone
setblock 95 163 525 minecraft:smooth_basalt
fill 95 163 526 95 164 526 minecraft:blackstone
setblock 95 163 530 minecraft:smooth_basalt
fill 95 163 531 95 166 531 minecraft:blackstone
setblock 95 163 535 minecraft:smooth_basalt
fill 95 163 536 95 166 536 minecraft:blackstone
setblock 95 163 545 minecraft:smooth_basalt
fill 95 163 546 95 163 549 minecraft:blackstone
setblock 95 163 550 minecraft:smooth_basalt
fill 95 163 551 98 163 551 minecraft:blackstone
fill 96 163 511 96 163 513 minecraft:blackstone
setblock 96 163 514 minecraft:smooth_basalt
fill 96 163 515 96 166 515 minecraft:blackstone
setblock 96 163 549 minecraft:smooth_basalt
fill 96 163 550 99 163 550 minecraft:blackstone
setblock 98 163 512 minecraft:smooth_basalt
setblock 99 163 511 minecraft:smooth_basalt
fill 99 163 512 99 166 512 minecraft:blackstone
fill 99 163 526 101 163 526 minecraft:jungle_log
setblock 99 163 551 minecraft:smooth_basalt
fill 100 163 511 103 163 511 minecraft:blackstone
setblock 100 163 550 minecraft:smooth_basalt
fill 100 163 551 103 163 551 minecraft:blackstone
fill 101 163 514 101 164 515 minecraft:blackstone
setblock 101 163 550 minecraft:blackstone
fill 102 163 513 104 164 513 minecraft:blackstone
fill 103 163 517 104 164 517 minecraft:blackstone
fill 103 163 519 103 163 520 minecraft:jungle_log
fill 103 163 532 103 163 533 minecraft:jungle_log
setblock 104 163 511 minecraft:smooth_basalt
fill 104 163 520 104 163 521 minecraft:jungle_log
fill 104 163 525 104 163 527 minecraft:jungle_log
fill 104 163 531 104 163 532 minecraft:jungle_log
setblock 104 163 551 minecraft:smooth_basalt
fill 105 163 511 108 163 511 minecraft:blackstone
fill 105 163 514 105 164 516 minecraft:blackstone
setblock 105 163 524 minecraft:jungle_log
fill 105 163 525 112 163 527 minecraft:jungle_leaves[persistent=true]
setblock 105 163 528 minecraft:jungle_log
setblock 105 163 550 minecraft:smooth_basalt
fill 105 163 551 108 163 551 minecraft:blackstone
fill 106 163 523 109 163 524 minecraft:jungle_leaves[persistent=true]
fill 106 163 528 109 163 529 minecraft:jungle_leaves[persistent=true]
fill 106 163 550 109 163 550 minecraft:blackstone
fill 107 163 521 109 163 522 minecraft:jungle_leaves[persistent=true]
fill 107 163 530 109 163 531 minecraft:jungle_leaves[persistent=true]
fill 108 163 520 109 168 520 minecraft:jungle_leaves[persistent=true]
fill 108 163 532 109 168 532 minecraft:jungle_leaves[persistent=true]
setblock 109 163 511 minecraft:smooth_basalt
setblock 109 163 551 minecraft:smooth_basalt
fill 110 163 511 110 166 511 minecraft:blackstone
fill 110 163 519 110 168 519 minecraft:jungle_leaves[persistent=true]
fill 110 163 520 110 163 521 minecraft:jungle_log
fill 110 163 522 110 172 522 minecraft:jungle_leaves[persistent=true]
fill 110 163 530 110 172 530 minecraft:jungle_leaves[persistent=true]
fill 110 163 531 110 163 532 minecraft:jungle_log
fill 110 163 533 110 168 533 minecraft:jungle_leaves[persistent=true]
setblock 110 163 550 minecraft:smooth_basalt
fill 110 163 551 113 163 551 minecraft:blackstone
fill 111 163 519 111 163 520 minecraft:jungle_log
fill 111 163 521 112 168 521 minecraft:jungle_leaves[persistent=true]
fill 111 163 531 112 168 531 minecraft:jungle_leaves[persistent=true]
fill 111 163 532 111 163 533 minecraft:jungle_log
setblock 111 163 549 minecraft:smooth_basalt
fill 111 163 550 114 163 550 minecraft:blackstone
fill 112 163 518 118 168 520 minecraft:jungle_leaves[persistent=true]
fill 112 163 532 118 168 534 minecraft:jungle_leaves[persistent=true]
setblock 112 163 549 minecraft:blackstone
fill 113 163 525 114 165 525 minecraft:jungle_leaves[persistent=true]
fill 113 163 526 115 163 526 minecraft:jungle_log
fill 113 163 527 114 165 527 minecraft:jungle_leaves[persistent=true]
setblock 114 163 511 minecraft:smooth_basalt
setblock 114 163 551 minecraft:smooth_basalt
fill 115 163 511 115 166 511 minecraft:blackstone
setblock 115 163 550 minecraft:smooth_basalt
fill 115 163 551 115 166 551 minecraft:blackstone
fill 116 163 550 116 164 550 minecraft:blackstone
fill 118 163 521 123 168 521 minecraft:jungle_leaves[persistent=true]
fill 118 163 531 123 168 531 minecraft:jungle_leaves[persistent=true]
fill 119 163 519 120 168 520 minecraft:jungle_leaves[persistent=true]
fill 119 163 532 120 168 533 minecraft:jungle_leaves[persistent=true]
setblock 119 163 551 minecraft:smooth_basalt
fill 120 163 522 123 167 522 minecraft:jungle_leaves[persistent=true]
fill 120 163 530 123 167 530 minecraft:jungle_leaves[persistent=true]
fill 121 163 520 122 168 520 minecraft:jungle_leaves[persistent=true]
fill 121 163 523 124 166 523 minecraft:jungle_leaves[persistent=true]
fill 121 163 529 124 166 529 minecraft:jungle_leaves[persistent=true]
fill 121 163 532 122 168 532 minecraft:jungle_leaves[persistent=true]
fill 122 163 524 124 164 528 minecraft:jungle_leaves[persistent=true]
fill 125 163 525 125 168 527 minecraft:jungle_leaves[persistent=true]
fill 127 163 511 127 164 511 minecraft:blackstone
setblock 129 163 511 minecraft:smooth_basalt
setblock 129 163 551 minecraft:smooth_basalt
fill 130 163 511 130 166 511 minecraft:blackstone
fill 130 163 551 130 166 551 minecraft:blackstone
setblock 132 163 513 minecraft:smooth_basalt
setblock 133 163 512 minecraft:smooth_basalt
fill 133 163 513 135 163 514 minecraft:blackstone
setblock 133 163 527 minecraft:smooth_basalt
fill 133 163 528 133 164 528 minecraft:blackstone
setblock 133 163 532 minecraft:smooth_basalt
setblock 134 163 511 minecraft:smooth_basalt
fill 134 163 512 135 165 512 minecraft:blackstone
setblock 134 163 515 minecraft:blackstone
setblock 134 163 516 minecraft:smooth_basalt
fill 134 163 517 134 166 517 minecraft:blackstone
setblock 134 163 521 minecraft:smooth_basalt
fill 134 163 522 134 164 522 minecraft:blackstone
setblock 134 163 526 minecraft:smooth_basalt
fill 134 163 527 134 166 527 minecraft:blackstone
setblock 134 163 531 minecraft:smooth_basalt
fill 134 163 532 134 166 532 minecraft:blackstone
setblock 134 163 535 minecraft:blackstone
setblock 134 163 551 minecraft:smooth_basalt
fill 135 163 511 135 166 511 minecraft:blackstone
setblock 135 163 515 minecraft:smooth_basalt
fill 135 163 516 135 166 516 minecraft:blackstone
setblock 135 163 520 minecraft:smooth_basalt
fill 135 163 521 135 166 521 minecraft:blackstone
setblock 135 163 525 minecraft:smooth_basalt
fill 135 163 526 135 166 526 minecraft:blackstone
setblock 135 163 530 minecraft:smooth_basalt
fill 135 163 531 135 166 531 minecraft:blackstone
setblock 135 163 535 minecraft:smooth_basalt
fill 135 163 536 135 166 536 minecraft:blackstone
setblock 135 163 550 minecraft:smooth_basalt
fill 135 163 551 135 166 551 minecraft:blackstone
fill 95 164 511 95 164 513 minecraft:blackstone
setblock 95 164 514 minecraft:smooth_basalt
fill 95 164 515 95 164 518 minecraft:blackstone
setblock 95 164 519 minecraft:smooth_basalt
setblock 95 164 529 minecraft:smooth_basalt
fill 95 164 530 95 167 530 minecraft:blackstone
setblock 95 164 534 minecraft:smooth_basalt
fill 95 164 535 95 167 535 minecraft:blackstone
fill 95 164 545 95 164 548 minecraft:blackstone
setblock 95 164 549 minecraft:smooth_basalt
fill 95 164 550 97 164 551 minecraft:blackstone
fill 96 164 511 96 164 512 minecraft:blackstone
setblock 96 164 513 minecraft:smooth_basalt
fill 96 164 514 96 167 514 minecraft:blackstone
setblock 96 164 548 minecraft:smooth_basalt
fill 96 164 549 96 167 549 minecraft:blackstone
setblock 97 164 512 minecraft:smooth_basalt
setblock 98 164 511 minecraft:smooth_basalt
fill 98 164 512 98 167 512 minecraft:blackstone
setblock 98 164 550 minecraft:blackstone
setblock 98 164 551 minecraft:smooth_basalt
fill 99 164 511 102 164 511 minecraft:blackstone
setblock 99 164 550 minecraft:smooth_basalt
fill 99 164 551 102 164 551 minecraft:blackstone
setblock 100 164 550 minecraft:blackstone
setblock 101 164 513 minecraft:blackstone
fill 101 164 516 101 164 517 minecraft:blackstone
fill 101 164 526 104 164 526 minecraft:jungle_log
setblock 102 164 517 minecraft:blackstone
setblock 103 164 511 minecraft:smooth_basalt
setblock 103 164 512 minecraft:blackstone
setblock 103 164 551 minecraft:smooth_basalt
fill 104 164 511 107 164 511 minecraft:blackstone
setblock 104 164 521 minecraft:jungle_log
fill 104 164 522 104 167 525 minecraft:jungle_leaves[persistent=true]
fill 104 164 527 104 167 530 minecraft:jungle_leaves[persistent=true]
setblock 104 164 531 minecraft:jungle_log
fill 104 164 551 107 164 551 minecraft:blackstone
setblock 105 164 513 minecraft:blackstone
setblock 105 164 517 minecraft:blackstone
fill 105 164 521 109 167 521 minecraft:jungle_leaves[persistent=true]
fill 105 164 522 105 164 523 minecraft:jungle_log
fill 105 164 524 109 164 528 minecraft:jungle_leaves[persistent=true]
fill 105 164 529 105 164 530 minecraft:jungle_log
fill 105 164 531 109 167 531 minecraft:jungle_leaves[persistent=true]
setblock 106 164 515 minecraft:blackstone
fill 106 164 520 107 167 520 minecraft:jungle_leaves[persistent=true]
fill 106 164 522 108 167 523 minecraft:jungle_leaves[persistent=true]
fill 106 164 529 108 167 530 minecraft:jungle_leaves[persistent=true]
fill 106 164 532 107 167 532 minecraft:jungle_leaves[persistent=true]
fill 106 164 550 108 164 550 minecraft:blackstone
fill 107 164 519 109 167 519 minecraft:jungle_leaves[persistent=true]
fill 107 164 533 109 167 533 minecraft:jungle_leaves[persistent=true]
setblock 108 164 511 minecraft:smooth_basalt
fill 108 164 518 111 167 518 minecraft:jungle_leaves[persistent=true]
fill 108 164 534 111 167 534 minecraft:jungle_leaves[persistent=true]
setblock 108 164 551 minecraft:smooth_basalt
fill 109 164 511 109 167 511 minecraft:blackstone
fill 109 164 522 109 164 523 minecraft:jungle_log
fill 109 164 529 109 164 530 minecraft:jungle_log
setblock 109 164 550 minecraft:smooth_basalt
fill 109 164 551 112 164 551 minecraft:blackstone
fill 110 164 517 120 167 517 minecraft:jungle_leaves[persistent=true]
fill 110 164 520 111 168 520 minecraft:jungle_leaves[persistent=true]
setblock 110 164 521 minecraft:jungle_log
fill 110 164 525 112 172 525 minecraft:jungle_leaves[persistent=true]
fill 110 164 526 113 164 526 minecraft:jungle_log
fill 110 164 527 112 172 527 minecraft:jungle_leaves[persistent=true]
setblock 110 164 531 minecraft:jungle_log
fill 110 164 532 111 168 532 minecraft:jungle_leaves[persistent=true]
fill 110 164 535 120 167 535 minecraft:jungle_leaves[persistent=true]
fill 110 164 550 113 164 550 minecraft:blackstone
setblock 111 164 512 minecraft:blackstone
fill 111 164 519 111 168 519 minecraft:jungle_leaves[persistent=true]
fill 111 164 533 111 168 533 minecraft:jungle_leaves[persistent=true]
setblock 112 164 512 minecraft:smooth_basalt
setblock 113 164 511 minecraft:smooth_basalt
fill 113 164 512 113 167 512 minecraft:blackstone
fill 113 164 516 117 167 516 minecraft:jungle_leaves[persistent=true]
fill 113 164 536 117 167 536 minecraft:jungle_leaves[persistent=true]
setblock 113 164 551 minecraft:smooth_basalt
fill 114 164 511 114 167 511 minecraft:blackstone
setblock 114 164 526 minecraft:jungle_leaves[persistent=true]
setblock 114 164 550 minecraft:smooth_basalt
fill 114 164 551 114 167 551 minecraft:blackstone
fill 115 164 550 115 165 550 minecraft:blackstone
setblock 118 164 551 minecraft:smooth_basalt
fill 119 164 518 122 167 518 minecraft:jungle_leaves[persistent=true]
fill 119 164 534 122 167 534 minecraft:jungle_leaves[persistent=true]
fill 121 164 519 123 167 519 minecraft:jungle_leaves[persistent=true]
fill 121 164 533 123 167 533 minecraft:jungle_leaves[persistent=true]
fill 123 164 520 124 167 520 minecraft:jungle_leaves[persistent=true]
fill 123 164 532 124 167 532 minecraft:jungle_leaves[persistent=true]
fill 124 164 521 125 167 522 minecraft:jungle_leaves[persistent=true]
fill 124 164 530 125 167 531 minecraft:jungle_leaves[persistent=true]
fill 125 164 523 126 167 524 minecraft:jungle_leaves[persistent=true]
fill 125 164 528 126 167 529 minecraft:jungle_leaves[persistent=true]
fill 126 164 522 126 167 522 minecraft:jungle_leaves[persistent=true]
fill 126 164 525 126 167 527 minecraft:jungle_leaves[persistent=true]
fill 126 164 530 126 167 530 minecraft:jungle_leaves[persistent=true]
fill 127 164 526 127 167 526 minecraft:jungle_leaves[persistent=true]
setblock 128 164 511 minecraft:smooth_basalt
fill 129 164 511 129 166 512 minecraft:blackstone
fill 129 164 551 129 167 551 minecraft:blackstone
setblock 131 164 513 minecraft:smooth_basalt
setblock 132 164 512 minecraft:smooth_basalt
fill 132 164 513 135 164 513 minecraft:blackstone
setblock 133 164 511 minecraft:smooth_basalt
fill 133 164 512 133 167 512 minecraft:blackstone
fill 133 164 514 133 164 515 minecraft:blackstone
setblock 133 164 527 minecraft:blackstone
setblock 133 164 531 minecraft:smooth_basalt
fill 133 164 532 133 167 532 minecraft:blackstone
setblock 133 164 551 minecraft:smooth_basalt
fill 134 164 511 134 167 511 minecraft:blackstone
setblock 134 164 514 minecraft:blackstone
setblock 134 164 515 minecraft:smooth_basalt
fill 134 164 516 134 167 516 minecraft:blackstone
setblock 134 164 520 minecraft:smooth_basalt
fill 134 164 521 134 167 521 minecraft:blackstone
setblock 134 164 525 minecraft:smooth_basalt
fill 134 164 526 134 166 526 minecraft:blackstone
setblock 134 164 530 minecraft:smooth_basalt
fill 134 164 531 134 167 531 minecraft:blackstone
setblock 134 164 535 minecraft:smooth_basalt
setblock 134 164 550 minecraft:smooth_basalt
fill 134 164 551 134 167 551 minecraft:blackstone
setblock 135 164 514 minecraft:smooth_basalt
fill 135 164 515 135 167 515 minecraft:blackstone
setblock 135 164 519 minecraft:smooth_basalt
fill 135 164 520 135 167 520 minecraft:blackstone
setblock 135 164 524 minecraft:smooth_basalt
fill 135 164 525 135 167 525 minecraft:blackstone
setblock 135 164 529 minecraft:smooth_basalt
fill 135 164 530 135 167 530 minecraft:blackstone
setblock 135 164 534 minecraft:smooth_basalt
fill 135 164 535 135 167 535 minecraft:blackstone
setblock 135 164 549 minecraft:smooth_basalt
fill 135 164 550 135 167 550 minecraft:blackstone
fill 95 165 511 95 165 512 minecraft:blackstone
setblock 95 165 513 minecraft:smooth_basalt
fill 95 165 514 95 165 517 minecraft:blackstone
setblock 95 165 518 minecraft:smooth_basalt
fill 95 165 519 95 168 519 minecraft:blackstone
setblock 95 165 528 minecraft:smooth_basalt
fill 95 165 529 95 167 529 minecraft:blackstone
setblock 95 165 533 minecraft:smooth_basalt
fill 95 165 534 95 168 534 minecraft:blackstone
setblock 95 165 537 minecraft:blackstone
fill 95 165 546 95 165 547 minecraft:blackstone
setblock 95 165 548 minecraft:smooth_basalt
fill 95 165 549 95 166 551 minecraft:blackstone
setblock 96 165 511 minecraft:blackstone
setblock 96 165 512 minecraft:smooth_basalt
fill 96 165 513 96 168 513 minecraft:blackstone
setblock 96 165 516 minecraft:blackstone
fill 96 165 550 96 165 551 minecraft:blackstone
setblock 97 165 511 minecraft:smooth_basalt
fill 97 165 512 97 168 512 minecraft:blackstone
setblock 97 165 513 minecraft:light[level=12]
setblock 97 165 521 minecraft:light[level=12]
setblock 97 165 529 minecraft:light[level=12]
setblock 97 165 537 minecraft:light[level=12]
setblock 97 165 545 minecraft:light[level=12]
setblock 97 165 550 minecraft:blackstone
setblock 97 165 551 minecraft:smooth_basalt
fill 98 165 511 101 165 511 minecraft:blackstone
setblock 98 165 550 minecraft:smooth_basalt
fill 98 165 551 101 165 551 minecraft:blackstone
setblock 102 165 511 minecraft:smooth_basalt
setblock 102 165 551 minecraft:smooth_basalt
fill 103 165 511 106 165 511 minecraft:blackstone
fill 103 165 522 103 166 530 minecraft:jungle_leaves[persistent=true]
fill 103 165 551 106 165 551 minecraft:blackstone
fill 104 165 521 104 166 521 minecraft:jungle_leaves[persistent=true]
fill 104 165 526 110 165 526 minecraft:jungle_log
fill 104 165 531 104 166 531 minecraft:jungle_leaves[persistent=true]
setblock 105 165 513 minecraft:light[level=12]
fill 105 165 520 105 166 520 minecraft:jungle_leaves[persistent=true]
fill 105 165 522 105 167 525 minecraft:jungle_leaves[persistent=true]
fill 105 165 527 105 167 530 minecraft:jungle_leaves[persistent=true]
fill 105 165 532 105 166 532 minecraft:jungle_leaves[persistent=true]
setblock 105 165 537 minecraft:light[level=12]
setblock 105 165 545 minecraft:light[level=12]
fill 106 165 519 106 166 519 minecraft:jungle_leaves[persistent=true]
fill 106 165 524 106 165 525 minecraft:jungle_log
fill 106 165 527 106 165 528 minecraft:jungle_log
fill 106 165 533 106 166 533 minecraft:jungle_leaves[persistent=true]
fill 106 165 550 107 165 550 minecraft:blackstone
setblock 107 165 511 minecraft:smooth_basalt
fill 107 165 518 107 166 518 minecraft:jungle_leaves[persistent=true]
fill 107 165 524 107 173 524 minecraft:jungle_leaves[persistent=true]
fill 107 165 525 108 165 525 minecraft:jungle_log
fill 107 165 527 108 165 527 minecraft:jungle_log
fill 107 165 528 107 173 528 minecraft:jungle_leaves[persistent=true]
fill 107 165 534 107 166 534 minecraft:jungle_leaves[persistent=true]
setblock 107 165 551 minecraft:smooth_basalt
fill 108 165 511 108 168 511 minecraft:blackstone
fill 108 165 517 109 166 517 minecraft:jungle_leaves[persistent=true]
setblock 108 165 524 minecraft:jungle_log
setblock 108 165 528 minecraft:jungle_log
fill 108 165 535 109 166 535 minecraft:jungle_leaves[persistent=true]
setblock 108 165 550 minecraft:smooth_basalt
fill 108 165 551 111 165 551 minecraft:blackstone
fill 109 165 512 110 165 512 minecraft:blackstone
fill 109 165 522 109 172 525 minecraft:jungle_leaves[persistent=true]
fill 109 165 527 109 172 530 minecraft:jungle_leaves[persistent=true]
fill 109 165 550 112 165 550 minecraft:blackstone
fill 110 165 516 112 166 516 minecraft:jungle_leaves[persistent=true]
fill 110 165 521 110 172 521 minecraft:jungle_leaves[persistent=true]
fill 110 165 531 110 172 531 minecraft:jungle_leaves[persistent=true]
fill 110 165 536 112 166 536 minecraft:jungle_leaves[persistent=true]
setblock 111 165 512 minecraft:smooth_basalt
fill 111 165 522 117 165 522 minecraft:jungle_leaves[persistent=true]
fill 111 165 526 113 172 526 minecraft:jungle_leaves[persistent=true]
fill 111 165 530 117 165 530 minecraft:jungle_leaves[persistent=true]
setblock 112 165 511 minecraft:smooth_basalt
fill 112 165 512 112 168 512 minecraft:blackstone
setblock 112 165 551 minecraft:smooth_basalt
fill 113 165 511 113 168 511 minecraft:blackstone
setblock 113 165 513 minecraft:light[level=12]
setblock 113 165 537 minecraft:light[level=12]
setblock 113 165 545 minecraft:light[level=12]
setblock 113 165 550 minecraft:smooth_basalt
fill 113 165 551 113 168 551 minecraft:blackstone
fill 114 165 512 114 166 512 minecraft:blackstone
fill 114 165 550 114 166 550 minecraft:blackstone
setblock 117 165 511 minecraft:smooth_basalt
setblock 117 165 551 minecraft:smooth_basalt
fill 118 165 516 120 166 516 minecraft:jungle_leaves[persistent=true]
fill 118 165 536 120 166 536 minecraft:jungle_leaves[persistent=true]
setblock 119 165 522 minecraft:jungle_leaves[persistent=true]
setblock 119 165 530 minecraft:jungle_leaves[persistent=true]
setblock 121 165 513 minecraft:light[level=12]
fill 121 165 517 122 166 517 minecraft:jungle_leaves[persistent=true]
fill 121 165 535 122 166 535 minecraft:jungle_leaves[persistent=true]
setblock 121 165 537 minecraft:light[level=12]
setblock 121 165 545 minecraft:light[level=12]
fill 122 165 524 124 165 525 minecraft:jungle_leaves[persistent=true]
fill 122 165 527 124 165 528 minecraft:jungle_leaves[persistent=true]
fill 123 165 518 123 166 518 minecraft:jungle_leaves[persistent=true]
fill 123 165 526 124 168 526 minecraft:jungle_leaves[persistent=true]
fill 123 165 534 123 166 534 minecraft:jungle_leaves[persistent=true]
fill 124 165 519 124 166 519 minecraft:jungle_leaves[persistent=true]
fill 124 165 533 124 166 533 minecraft:jungle_leaves[persistent=true]
fill 125 165 520 125 166 520 minecraft:jungle_leaves[persistent=true]
fill 125 165 532 125 166 532 minecraft:jungle_leaves[persistent=true]
setblock 126 165 511 minecraft:blackstone
fill 126 165 521 126 166 521 minecraft:jungle_leaves[persistent=true]
fill 126 165 531 126 166 531 minecraft:jungle_leaves[persistent=true]
setblock 127 165 511 minecraft:smooth_basalt
fill 127 165 522 127 166 525 minecraft:jungle_leaves[persistent=true]
fill 127 165 527 127 166 530 minecraft:jungle_leaves[persistent=true]
fill 128 165 511 128 167 512 minecraft:blackstone
fill 128 165 551 128 168 551 minecraft:blackstone
setblock 129 165 513 minecraft:light[level=12]
setblock 129 165 521 minecraft:light[level=12]
setblock 129 165 529 minecraft:light[level=12]
setblock 129 165 537 minecraft:light[level=12]
setblock 129 165 545 minecraft:light[level=12]
setblock 130 165 513 minecraft:smooth_basalt
setblock 131 165 512 minecraft:smooth_basalt
fill 131 165 513 134 165 513 minecraft:blackstone
setblock 132 165 511 minecraft:smooth_basalt
fill 132 165 512 132 168 512 minecraft:blackstone
setblock 132 165 551 minecraft:smooth_basalt
fill 133 165 511 133 168 511 minecraft:blackstone
setblock 133 165 514 minecraft:blackstone
setblock 133 165 515 minecraft:smooth_basalt
fill 133 165 516 133 167 517 minecraft:blackstone
setblock 133 165 530 minecraft:smooth_basalt
fill 133 165 531 133 167 531 minecraft:blackstone
setblock 133 165 550 minecraft:smooth_basalt
fill 133 165 551 133 168 551 minecraft:blackstone
setblock 134 165 514 minecraft:smooth_basalt
fill 134 165 515 134 168 515 minecraft:blackstone
setblock 134 165 519 minecraft:smooth_basalt
fill 134 165 520 134 168 520 minecraft:blackstone
setblock 134 165 524 minecraft:smooth_basalt
setblock 134 165 525 minecraft:blackstone
setblock 134 165 529 minecraft:smooth_basalt
fill 134 165 530 134 168 530 minecraft:blackstone
setblock 134 165 534 minecraft:smooth_basalt
fill 134 165 535 134 168 535 minecraft:blackstone
setblock 134 165 550 minecraft:blackstone
setblock 135 165 513 minecraft:smooth_basalt
fill 135 165 514 135 168 514 minecraft:blackstone
setblock 135 165 518 minecraft:smooth_basalt
fill 135 165 519 135 168 519 minecraft:blackstone
setblock 135 165 523 minecraft:smooth_basalt
fill 135 165 524 135 168 524 minecraft:blackstone
setblock 135 165 528 minecraft:smooth_basalt
fill 135 165 529 135 168 529 minecraft:blackstone
setblock 135 165 533 minecraft:smooth_basalt
fill 135 165 534 135 168 534 minecraft:blackstone
setblock 135 165 548 minecraft:smooth_basalt
fill 135 165 549 135 168 549 minecraft:blackstone
setblock 95 166 511 minecraft:blackstone
setblock 95 166 512 minecraft:smooth_basalt
fill 95 166 513 95 166 516 minecraft:blackstone
setblock 95 166 517 minecraft:smooth_basalt
fill 95 166 518 95 169 518 minecraft:blackstone
setblock 95 166 532 minecraft:smooth_basalt
fill 95 166 533 95 169 533 minecraft:blackstone
setblock 95 166 537 minecraft:smooth_basalt
fill 95 166 538 95 168 539 minecraft:blackstone
setblock 95 166 546 minecraft:blackstone
setblock 95 166 547 minecraft:smooth_basalt
fill 95 166 548 95 169 548 minecraft:blackstone
setblock 96 166 511 minecraft:smooth_basalt
fill 96 166 512 96 169 512 minecraft:blackstone
setblock 96 166 516 minecraft:smooth_basalt
setblock 96 166 550 minecraft:blackstone
setblock 96 166 551 minecraft:smooth_basalt
fill 97 166 511 100 166 511 minecraft:blackstone
setblock 97 166 550 minecraft:smooth_basalt
fill 97 166 551 100 166 551 minecraft:blackstone
setblock 98 166 550 minecraft:blackstone
setblock 101 166 511 minecraft:smooth_basalt
setblock 101 166 551 minecraft:smooth_basalt
fill 102 166 511 105 166 511 minecraft:blackstone
fill 102 166 551 105 166 551 minecraft:blackstone
fill 104 166 526 106 173 526 minecraft:jungle_leaves[persistent=true]
setblock 106 166 511 minecraft:smooth_basalt
fill 106 166 524 106 173 525 minecraft:jungle_leaves[persistent=true]
fill 106 166 527 106 173 528 minecraft:jungle_leaves[persistent=true]
setblock 106 166 550 minecraft:blackstone
setblock 106 166 551 minecraft:smooth_basalt
fill 107 166 511 107 169 511 minecraft:blackstone
fill 107 166 525 108 173 525 minecraft:jungle_leaves[persistent=true]
setblock 107 166 526 minecraft:jungle_log
fill 107 166 527 108 173 527 minecraft:jungle_leaves[persistent=true]
setblock 107 166 550 minecraft:smooth_basalt
fill 107 166 551 110 166 551 minecraft:blackstone
fill 108 166 512 109 166 512 minecraft:blackstone
fill 108 166 524 108 173 524 minecraft:jungle_leaves[persistent=true]
fill 108 166 526 110 173 526 minecraft:jungle_leaves[persistent=true]
fill 108 166 528 108 173 528 minecraft:jungle_leaves[persistent=true]
fill 108 166 550 111 166 550 minecraft:blackstone
setblock 110 166 512 minecraft:smooth_basalt
setblock 111 166 511 minecraft:smooth_basalt
fill 111 166 512 111 169 512 minecraft:blackstone
fill 111 166 522 116 167 522 minecraft:jungle_leaves[persistent=true]
fill 111 166 530 116 167 530 minecraft:jungle_leaves[persistent=true]
setblock 111 166 551 minecraft:smooth_basalt
fill 112 166 511 112 169 511 minecraft:blackstone
setblock 112 166 550 minecraft:smooth_basalt
fill 112 166 551 112 169 551 minecraft:blackstone
fill 113 166 525 113 171 525 minecraft:jungle_leaves[persistent=true]
fill 113 166 527 113 171 527 minecraft:jungle_leaves[persistent=true]
fill 113 166 550 113 168 550 minecraft:blackstone
setblock 116 166 511 minecraft:smooth_basalt
setblock 116 166 551 minecraft:smooth_basalt
fill 117 166 511 117 169 511 minecraft:blackstone
setblock 117 166 551 minecraft:blackstone
fill 122 166 524 124 167 524 minecraft:jungle_leaves[persistent=true]
fill 122 166 528 124 167 528 minecraft:jungle_leaves[persistent=true]
fill 123 166 525 124 168 525 minecraft:jungle_leaves[persistent=true]
fill 123 166 527 124 168 527 minecraft:jungle_leaves[persistent=true]
setblock 125 166 511 minecraft:blackstone
setblock 126 166 511 minecraft:smooth_basalt
fill 127 166 511 127 168 512 minecraft:blackstone
setblock 129 166 513 minecraft:smooth_basalt
setblock 130 166 512 minecraft:smooth_basalt
fill 130 166 513 133 166 513 minecraft:blackstone
setblock 131 166 511 minecraft:smooth_basalt
fill 131 166 512 131 169 512 minecraft:blackstone
setblock 131 166 551 minecraft:smooth_basalt
fill 132 166 511 132 169 511 minecraft:blackstone
setblock 132 166 514 minecraft:blackstone
fill 132 166 551 132 169 551 minecraft:blackstone
setblock 133 166 514 minecraft:smooth_basalt
fill 133 166 515 133 169 515 minecraft:blackstone
setblock 133 166 518 minecraft:blackstone
setblock 133 166 530 minecraft:blackstone
setblock 133 166 533 minecraft:blackstone
setblock 134 166 512 minecraft:blackstone
setblock 134 166 513 minecraft:smooth_basalt
fill 134 166 514 134 169 514 minecraft:blackstone
setblock 134 166 518 minecraft:smooth_basalt
fill 134 166 519 134 169 519 minecraft:blackstone
setblock 134 166 528 minecraft:smooth_basalt
fill 134 166 529 134 168 529 minecraft:blackstone
setblock 134 166 533 minecraft:smooth_basalt
fill 134 166 534 134 169 534 minecraft:blackstone
fill 134 166 536 134 167 536 minecraft:blackstone
setblock 135 166 512 minecraft:smooth_basalt
fill 135 166 513 135 169 513 minecraft:blackstone
setblock 135 166 517 minecraft:smooth_basalt
fill 135 166 518 135 169 518 minecraft:blackstone
setblock 135 166 522 minecraft:smooth_basalt
fill 135 166 523 135 169 523 minecraft:blackstone
setblock 135 166 527 minecraft:smooth_basalt
fill 135 166 528 135 169 528 minecraft:blackstone
setblock 135 166 532 minecraft:smooth_basalt
fill 135 166 533 135 169 533 minecraft:blackstone
setblock 135 166 537 minecraft:smooth_basalt
fill 135 166 538 135 169 538 minecraft:blackstone
setblock 95 167 511 minecraft:smooth_basalt
fill 95 167 512 95 167 515 minecraft:blackstone
setblock 95 167 516 minecraft:smooth_basalt
fill 95 167 517 95 170 517 minecraft:blackstone
setblock 95 167 520 minecraft:blackstone
setblock 95 167 531 minecraft:smooth_basalt
fill 95 167 532 95 170 532 minecraft:blackstone
setblock 95 167 536 minecraft:smooth_basalt
fill 95 167 537 95 170 537 minecraft:blackstone
setblock 95 167 540 minecraft:blackstone
setblock 95 167 541 minecraft:smooth_basalt
setblock 95 167 545 minecraft:blackstone
setblock 95 167 546 minecraft:smooth_basalt
fill 95 167 547 95 170 547 minecraft:blackstone
fill 95 167 549 95 167 550 minecraft:blackstone
setblock 95 167 551 minecraft:smooth_basalt
fill 96 167 511 99 167 511 minecraft:blackstone
setblock 96 167 515 minecraft:smooth_basalt
fill 96 167 516 96 170 516 minecraft:blackstone
setblock 96 167 550 minecraft:smooth_basalt
fill 96 167 551 99 167 551 minecraft:blackstone
fill 97 167 550 97 168 550 minecraft:blackstone
setblock 99 167 512 minecraft:smooth_basalt
fill 99 167 531 102 216 532 minecraft:smooth_basalt
setblock 100 167 511 minecraft:smooth_basalt
fill 100 167 530 101 216 530 minecraft:smooth_basalt
fill 100 167 533 102 216 533 minecraft:smooth_basalt
setblock 100 167 551 minecraft:smooth_basalt
fill 101 167 511 104 167 511 minecraft:blackstone
fill 101 167 551 104 167 551 minecraft:blackstone
setblock 103 167 526 minecraft:jungle_leaves[persistent=true]
setblock 105 167 511 minecraft:smooth_basalt
setblock 105 167 550 minecraft:blackstone
setblock 105 167 551 minecraft:smooth_basalt
fill 106 167 511 106 169 512 minecraft:blackstone
setblock 106 167 550 minecraft:smooth_basalt
fill 106 167 551 109 167 551 minecraft:blackstone
fill 107 167 512 108 167 512 minecraft:blackstone
fill 107 167 526 107 173 526 minecraft:jungle_leaves[persistent=true]
fill 107 167 550 110 167 550 minecraft:blackstone
setblock 109 167 512 minecraft:smooth_basalt
setblock 110 167 511 minecraft:smooth_basalt
fill 110 167 512 110 170 512 minecraft:blackstone
setblock 110 167 551 minecraft:smooth_basalt
fill 111 167 511 111 170 511 minecraft:blackstone
setblock 111 167 550 minecraft:smooth_basalt
fill 111 167 551 111 170 551 minecraft:blackstone
fill 112 167 550 112 170 550 minecraft:blackstone
setblock 114 167 512 minecraft:smooth_basalt
setblock 115 167 511 minecraft:smooth_basalt
setblock 115 167 551 minecraft:smooth_basalt
fill 116 167 511 116 170 511 minecraft:blackstone
fill 116 167 551 116 168 551 minecraft:blackstone
fill 122 167 523 124 168 523 minecraft:jungle_leaves[persistent=true]
fill 122 167 529 124 168 529 minecraft:jungle_leaves[persistent=true]
fill 123 167 511 124 167 511 minecraft:blackstone
setblock 125 167 511 minecraft:smooth_basalt
fill 126 167 511 126 169 512 minecraft:blackstone
setblock 127 167 513 minecraft:blackstone
fill 127 167 551 127 169 551 minecraft:blackstone
setblock 128 167 513 minecraft:smooth_basalt
setblock 129 167 511 minecraft:blackstone
setblock 129 167 512 minecraft:smooth_basalt
fill 129 167 513 132 167 513 minecraft:blackstone
setblock 130 167 511 minecraft:smooth_basalt
fill 130 167 512 130 170 512 minecraft:blackstone
fill 130 167 514 131 167 514 minecraft:blackstone
setblock 130 167 551 minecraft:smooth_basalt
fill 131 167 511 131 170 511 minecraft:blackstone
fill 131 167 551 131 170 551 minecraft:blackstone
setblock 132 167 514 minecraft:smooth_basalt
fill 132 167 515 132 169 516 minecraft:blackstone
setblock 133 167 513 minecraft:smooth_basalt
fill 133 167 514 133 170 514 minecraft:blackstone
setblock 133 167 518 minecraft:smooth_basalt
fill 133 167 519 133 170 519 minecraft:blackstone
setblock 133 167 533 minecraft:smooth_basalt
fill 133 167 550 133 168 550 minecraft:blackstone
setblock 134 167 512 minecraft:smooth_basalt
fill 134 167 513 134 170 513 minecraft:blackstone
setblock 134 167 517 minecraft:smooth_basalt
fill 134 167 518 134 170 518 minecraft:blackstone
setblock 134 167 522 minecraft:smooth_basalt
setblock 134 167 527 minecraft:smooth_basalt
fill 134 167 528 134 168 528 minecraft:blackstone
setblock 134 167 532 minecraft:smooth_basalt
fill 134 167 533 134 170 533 minecraft:blackstone
setblock 135 167 511 minecraft:smooth_basalt
fill 135 167 512 135 170 512 minecraft:blackstone
setblock 135 167 516 minecraft:smooth_basalt
fill 135 167 517 135 170 517 minecraft:blackstone
setblock 135 167 521 minecraft:smooth_basalt
fill 135 167 522 135 170 522 minecraft:blackstone
setblock 135 167 526 minecraft:smooth_basalt
fill 135 167 527 135 169 527 minecraft:blackstone
setblock 135 167 531 minecraft:smooth_basalt
fill 135 167 532 135 170 532 minecraft:blackstone
setblock 135 167 536 minecraft:smooth_basalt
fill 135 167 537 135 170 537 minecraft:blackstone
fill 135 167 539 135 168 539 minecraft:blackstone
setblock 135 167 551 minecraft:smooth_basalt
fill 95 168 511 95 168 514 minecraft:blackstone
setblock 95 168 515 minecraft:smooth_basalt
fill 95 168 516 95 171 516 minecraft:blackstone
setblock 95 168 520 minecraft:smooth_basalt
setblock 95 168 530 minecraft:smooth_basalt
fill 95 168 531 95 169 531 minecraft:blackstone
setblock 95 168 535 minecraft:smooth_basalt
fill 95 168 536 95 171 536 minecraft:blackstone
setblock 95 168 540 minecraft:smooth_basalt
fill 95 168 541 95 168 544 minecraft:blackstone
setblock 95 168 545 minecraft:smooth_basalt
fill 95 168 546 95 171 546 minecraft:blackstone
setblock 95 168 549 minecraft:blackstone
setblock 95 168 550 minecraft:smooth_basalt
fill 95 168 551 98 168 551 minecraft:blackstone
fill 96 168 511 98 168 511 minecraft:blackstone
setblock 96 168 514 minecraft:smooth_basalt
fill 96 168 515 96 171 515 minecraft:blackstone
fill 96 168 517 96 169 517 minecraft:blackstone
fill 96 168 550 96 169 550 minecraft:blackstone
setblock 98 168 512 minecraft:smooth_basalt
fill 98 168 531 98 169 532 minecraft:blackstone
setblock 99 168 511 minecraft:smooth_basalt
fill 99 168 512 99 170 512 minecraft:blackstone
fill 99 168 530 99 169 530 minecraft:blackstone
fill 99 168 533 99 169 534 minecraft:blackstone
setblock 99 168 551 minecraft:smooth_basalt
fill 100 168 511 103 168 511 minecraft:blackstone
fill 100 168 529 101 169 529 minecraft:blackstone
fill 100 168 534 102 169 534 minecraft:blackstone
fill 100 168 551 103 168 551 minecraft:blackstone
fill 102 168 530 102 169 530 minecraft:blackstone
fill 103 168 531 103 169 533 minecraft:blackstone
setblock 104 168 511 minecraft:smooth_basalt
fill 104 168 524 105 173 525 minecraft:jungle_leaves[persistent=true]
fill 104 168 527 105 173 528 minecraft:jungle_leaves[persistent=true]
setblock 104 168 551 minecraft:smooth_basalt
fill 105 168 511 105 170 512 minecraft:blackstone
fill 105 168 523 108 173 523 minecraft:jungle_leaves[persistent=true]
fill 105 168 529 108 173 529 minecraft:jungle_leaves[persistent=true]
setblock 105 168 550 minecraft:smooth_basalt
fill 105 168 551 108 168 551 minecraft:blackstone
fill 106 168 550 109 168 550 minecraft:blackstone
setblock 107 168 512 minecraft:blackstone
fill 107 168 521 108 172 522 minecraft:jungle_leaves[persistent=true]
fill 107 168 530 108 172 531 minecraft:jungle_leaves[persistent=true]
setblock 108 168 512 minecraft:smooth_basalt
setblock 109 168 511 minecraft:smooth_basalt
fill 109 168 512 109 171 512 minecraft:blackstone
fill 109 168 521 109 172 521 minecraft:jungle_leaves[persistent=true]
fill 109 168 531 109 172 531 minecraft:jungle_leaves[persistent=true]
setblock 109 168 551 minecraft:smooth_basalt
fill 110 168 511 110 171 511 minecraft:blackstone
fill 110 168 523 113 171 524 minecraft:jungle_leaves[persistent=true]
fill 110 168 528 113 171 529 minecraft:jungle_leaves[persistent=true]
setblock 110 168 550 minecraft:smooth_basalt
fill 110 168 551 110 171 551 minecraft:blackstone
fill 111 168 522 115 169 522 minecraft:jungle_leaves[persistent=true]
fill 111 168 530 115 169 530 minecraft:jungle_leaves[persistent=true]
fill 111 168 550 111 171 550 minecraft:blackstone
setblock 113 168 512 minecraft:smooth_basalt
setblock 114 168 511 minecraft:smooth_basalt
fill 114 168 512 114 170 512 minecraft:blackstone
fill 114 168 523 114 169 523 minecraft:jungle_leaves[persistent=true]
fill 114 168 529 114 169 529 minecraft:jungle_leaves[persistent=true]
setblock 114 168 551 minecraft:smooth_basalt
fill 115 168 511 115 171 511 minecraft:blackstone
fill 115 168 551 115 169 551 minecraft:blackstone
setblock 118 168 511 minecraft:blackstone
fill 121 168 522 123 168 522 minecraft:jungle_leaves[persistent=true]
fill 121 168 530 123 168 530 minecraft:jungle_leaves[persistent=true]
fill 122 168 511 123 168 511 minecraft:blackstone
fill 123 168 524 124 168 524 minecraft:jungle_leaves[persistent=true]
fill 123 168 528 124 168 528 minecraft:jungle_leaves[persistent=true]
setblock 124 168 511 minecraft:smooth_basalt
fill 124 168 512 125 170 512 minecraft:blackstone
fill 125 168 511 125 171 511 minecraft:blackstone
setblock 126 168 513 minecraft:blackstone
setblock 127 168 513 minecraft:smooth_basalt
fill 127 168 519 128 169 520 minecraft:gold_block
setblock 128 168 511 minecraft:blackstone
setblock 128 168 512 minecraft:smooth_basalt
fill 128 168 513 130 168 514 minecraft:blackstone
fill 128 168 535 132 169 539 minecraft:blackstone
setblock 129 168 511 minecraft:smooth_basalt
fill 129 168 512 129 171 512 minecraft:blackstone
setblock 129 168 551 minecraft:smooth_basalt
fill 130 168 511 130 171 511 minecraft:blackstone
fill 130 168 551 130 171 551 minecraft:blackstone
setblock 131 168 513 minecraft:blackstone
setblock 131 168 514 minecraft:smooth_basalt
setblock 132 168 513 minecraft:smooth_basalt
fill 132 168 514 132 171 514 minecraft:blackstone
setblock 132 168 517 minecraft:blackstone
fill 132 168 550 132 169 550 minecraft:blackstone
setblock 133 168 512 minecraft:smooth_basalt
fill 133 168 513 133 171 513 minecraft:blackstone
setblock 133 168 516 minecraft:blackstone
setblock 133 168 517 minecraft:smooth_basalt
fill 133 168 518 133 171 518 minecraft:blackstone
fill 133 168 520 133 169 520 minecraft:blackstone
setblock 133 168 532 minecraft:smooth_basalt
fill 133 168 533 133 168 534 minecraft:blackstone
fill 133 168 537 134 168 537 minecraft:blackstone
setblock 134 168 511 minecraft:smooth_basalt
fill 134 168 512 134 171 512 minecraft:blackstone
setblock 134 168 516 minecraft:smooth_basalt
fill 134 168 517 134 171 517 minecraft:blackstone
setblock 134 168 521 minecraft:smooth_basalt
fill 134 168 522 134 171 522 minecraft:blackstone
setblock 134 168 531 minecraft:smooth_basalt
fill 134 168 532 134 170 532 minecraft:blackstone
setblock 134 168 536 minecraft:smooth_basalt
setblock 134 168 551 minecraft:smooth_basalt
fill 135 168 511 135 171 511 minecraft:blackstone
setblock 135 168 515 minecraft:smooth_basalt
fill 135 168 516 135 171 516 minecraft:blackstone
setblock 135 168 520 minecraft:smooth_basalt
fill 135 168 521 135 171 521 minecraft:blackstone
setblock 135 168 525 minecraft:smooth_basalt
fill 135 168 526 135 169 526 minecraft:blackstone
setblock 135 168 530 minecraft:smooth_basalt
fill 135 168 531 135 171 531 minecraft:blackstone
setblock 135 168 535 minecraft:smooth_basalt
fill 135 168 536 135 171 536 minecraft:blackstone
setblock 135 168 550 minecraft:smooth_basalt
fill 135 168 551 135 171 551 minecraft:blackstone
fill 95 169 511 95 169 513 minecraft:blackstone
setblock 95 169 514 minecraft:smooth_basalt
fill 95 169 515 95 172 515 minecraft:blackstone
setblock 95 169 519 minecraft:smooth_basalt
fill 95 169 520 95 172 520 minecraft:blackstone
setblock 95 169 534 minecraft:smooth_basalt
fill 95 169 535 95 172 535 minecraft:blackstone
setblock 95 169 538 minecraft:blackstone
setblock 95 169 539 minecraft:smooth_basalt
fill 95 169 540 95 169 543 minecraft:blackstone
setblock 95 169 544 minecraft:smooth_basalt
fill 95 169 545 95 172 545 minecraft:blackstone
setblock 95 169 549 minecraft:smooth_basalt
fill 95 169 550 95 171 551 minecraft:blackstone
fill 96 169 511 97 169 511 minecraft:blackstone
setblock 96 169 513 minecraft:smooth_basalt
fill 96 169 514 96 172 514 minecraft:blackstone
fill 96 169 536 96 169 537 minecraft:blackstone
fill 96 169 551 97 169 551 minecraft:blackstone
setblock 97 169 512 minecraft:smooth_basalt
fill 97 169 531 97 169 532 minecraft:blackstone
setblock 98 169 511 minecraft:smooth_basalt
fill 98 169 512 98 170 512 minecraft:blackstone
fill 98 169 529 98 169 530 minecraft:blackstone
fill 98 169 533 98 169 534 minecraft:blackstone
setblock 98 169 551 minecraft:smooth_basalt
fill 99 169 511 102 169 511 minecraft:blackstone
setblock 99 169 529 minecraft:blackstone
fill 99 169 551 102 169 551 minecraft:blackstone
fill 100 169 528 101 169 528 minecraft:blackstone
fill 100 169 535 101 169 535 minecraft:blackstone
fill 101 169 526 103 172 526 minecraft:jungle_leaves[persistent=true]
fill 102 169 523 103 172 525 minecraft:jungle_leaves[persistent=true]
fill 102 169 527 103 172 529 minecraft:jungle_leaves[persistent=true]
setblock 103 169 511 minecraft:smooth_basalt
fill 103 169 522 106 172 522 minecraft:jungle_leaves[persistent=true]
fill 103 169 530 106 172 530 minecraft:jungle_leaves[persistent=true]
setblock 103 169 534 minecraft:blackstone
setblock 103 169 551 minecraft:smooth_basalt
fill 104 169 511 104 171 512 minecraft:blackstone
fill 104 169 521 106 172 521 minecraft:jungle_leaves[persistent=true]
fill 104 169 523 104 172 523 minecraft:jungle_leaves[persistent=true]
fill 104 169 529 104 172 529 minecraft:jungle_leaves[persistent=true]
fill 104 169 531 106 172 531 minecraft:jungle_leaves[persistent=true]
setblock 104 169 532 minecraft:blackstone
setblock 104 169 550 minecraft:smooth_basalt
fill 104 169 551 107 169 551 minecraft:blackstone
fill 105 169 550 108 169 550 minecraft:blackstone
setblock 107 169 512 minecraft:smooth_basalt
fill 107 169 520 107 172 520 minecraft:jungle_leaves[persistent=true]
fill 107 169 532 107 172 532 minecraft:jungle_leaves[persistent=true]
setblock 108 169 511 minecraft:smooth_basalt
fill 108 169 512 108 172 512 minecraft:blackstone
setblock 108 169 551 minecraft:smooth_basalt
fill 109 169 511 109 172 511 minecraft:blackstone
fill 109 169 513 110 169 513 minecraft:blackstone
setblock 109 169 550 minecraft:smooth_basalt
fill 109 169 551 109 172 551 minecraft:blackstone
fill 110 169 550 110 171 550 minecraft:blackstone
setblock 111 169 513 minecraft:smooth_basalt
setblock 112 169 512 minecraft:smooth_basalt
setblock 113 169 511 minecraft:smooth_basalt
fill 113 169 512 113 171 512 minecraft:blackstone
setblock 113 169 551 minecraft:smooth_basalt
fill 114 169 511 114 172 511 minecraft:blackstone
fill 114 169 551 114 170 551 minecraft:blackstone
fill 121 169 511 122 169 511 minecraft:blackstone
setblock 123 169 511 minecraft:smooth_basalt
fill 124 169 511 124 172 511 minecraft:blackstone
setblock 125 169 513 minecraft:blackstone
setblock 126 169 513 minecraft:smooth_basalt
fill 126 169 551 126 170 551 minecraft:blackstone
setblock 127 169 511 minecraft:blackstone
setblock 127 169 512 minecraft:smooth_basalt
fill 127 169 513 129 169 514 minecraft:blackstone
setblock 128 169 511 minecraft:smooth_basalt
fill 128 169 512 128 172 512 minecraft:blackstone
setblock 128 169 551 minecraft:smooth_basalt
fill 129 169 511 129 172 511 minecraft:blackstone
fill 129 169 551 129 172 551 minecraft:blackstone
setblock 130 169 513 minecraft:blackstone
setblock 130 169 514 minecraft:smooth_basalt
fill 130 169 515 131 171 515 minecraft:blackstone
setblock 131 169 513 minecraft:smooth_basalt
fill 131 169 514 131 172 514 minecraft:blackstone
setblock 131 169 550 minecraft:blackstone
setblock 132 169 512 minecraft:smooth_basalt
fill 132 169 513 132 172 513 minecraft:blackstone
setblock 132 169 517 minecraft:smooth_basalt
fill 132 169 518 132 172 518 minecraft:blackstone
setblock 133 169 511 minecraft:smooth_basalt
fill 133 169 512 133 172 512 minecraft:blackstone
setblock 133 169 516 minecraft:smooth_basalt
fill 133 169 517 133 172 517 minecraft:blackstone
setblock 133 169 551 minecraft:smooth_basalt
fill 134 169 511 134 172 511 minecraft:blackstone
setblock 134 169 515 minecraft:smooth_basalt
fill 134 169 516 134 172 516 minecraft:blackstone
setblock 134 169 520 minecraft:smooth_basalt
fill 134 169 521 134 172 521 minecraft:blackstone
setblock 134 169 530 minecraft:smooth_basalt
setblock 134 169 531 minecraft:blackstone
setblock 134 169 535 minecraft:smooth_basalt
fill 134 169 536 134 170 538 minecraft:blackstone
fill 134 169 551 134 172 551 minecraft:blackstone
setblock 135 169 514 minecraft:smooth_basalt
fill 135 169 515 135 172 515 minecraft:blackstone
setblock 135 169 519 minecraft:smooth_basalt
fill 135 169 520 135 172 520 minecraft:blackstone
setblock 135 169 524 minecraft:smooth_basalt
fill 135 169 525 135 170 525 minecraft:blackstone
setblock 135 169 529 minecraft:smooth_basalt
fill 135 169 530 135 170 530 minecraft:blackstone
setblock 135 169 534 minecraft:smooth_basalt
fill 135 169 535 135 172 535 minecraft:blackstone
setblock 135 169 539 minecraft:smooth_basalt
fill 135 169 540 135 172 540 minecraft:blackstone
setblock 135 169 549 minecraft:smooth_basalt
fill 135 169 550 135 172 550 minecraft:blackstone
fill 95 170 511 95 170 512 minecraft:blackstone
setblock 95 170 513 minecraft:smooth_basalt
fill 95 170 514 95 173 514 minecraft:blackstone
setblock 95 170 518 minecraft:smooth_basalt
fill 95 170 519 95 173 519 minecraft:blackstone
setblock 95 170 533 minecraft:smooth_basalt
fill 95 170 534 95 172 534 minecraft:blackstone
setblock 95 170 538 minecraft:smooth_basalt
fill 95 170 539 95 170 542 minecraft:blackstone
setblock 95 170 543 minecraft:smooth_basalt
fill 95 170 544 95 173 544 minecraft:blackstone
setblock 95 170 548 minecraft:smooth_basalt
fill 95 170 549 95 173 549 minecraft:blackstone
setblock 96 170 511 minecraft:blackstone
setblock 96 170 512 minecraft:smooth_basalt
fill 96 170 513 96 172 513 minecraft:blackstone
setblock 96 170 517 minecraft:smooth_basalt
setblock 96 170 536 minecraft:blackstone
setblock 96 170 537 minecraft:smooth_basalt
fill 96 170 538 96 172 539 minecraft:blackstone
setblock 96 170 551 minecraft:blackstone
setblock 97 170 511 minecraft:smooth_basalt
fill 97 170 512 97 171 512 minecraft:blackstone
setblock 97 170 551 minecraft:smooth_basalt
fill 98 170 511 101 170 511 minecraft:blackstone
fill 98 170 551 101 170 551 minecraft:blackstone
fill 101 170 523 101 171 525 minecraft:jungle_leaves[persistent=true]
fill 101 170 527 101 171 529 minecraft:jungle_leaves[persistent=true]
setblock 102 170 511 minecraft:smooth_basalt
fill 102 170 522 102 171 522 minecraft:jungle_leaves[persistent=true]
fill 102 170 530 102 171 530 minecraft:jungle_leaves[persistent=true]
setblock 102 170 551 minecraft:smooth_basalt
fill 103 170 511 103 171 512 minecraft:blackstone
fill 103 170 521 103 171 521 minecraft:jungle_leaves[persistent=true]
fill 103 170 531 103 171 531 minecraft:jungle_leaves[persistent=true]
fill 103 170 551 106 170 551 minecraft:blackstone
fill 104 170 520 106 171 520 minecraft:jungle_leaves[persistent=true]
fill 104 170 532 106 171 532 minecraft:jungle_leaves[persistent=true]
fill 104 170 550 107 170 550 minecraft:blackstone
setblock 106 170 511 minecraft:blackstone
setblock 106 170 512 minecraft:smooth_basalt
setblock 107 170 511 minecraft:smooth_basalt
fill 107 170 512 107 173 512 minecraft:blackstone
setblock 107 170 551 minecraft:smooth_basalt
fill 108 170 511 108 173 511 minecraft:blackstone
fill 108 170 513 109 170 513 minecraft:blackstone
fill 108 170 520 110 171 520 minecraft:jungle_leaves[persistent=true]
fill 108 170 532 110 171 532 minecraft:jungle_leaves[persistent=true]
setblock 108 170 550 minecraft:smooth_basalt
fill 108 170 551 108 173 551 minecraft:blackstone
fill 109 170 550 109 172 550 minecraft:blackstone
setblock 110 170 513 minecraft:smooth_basalt
setblock 111 170 512 minecraft:smooth_basalt
setblock 111 170 513 minecraft:blackstone
fill 111 170 521 111 171 522 minecraft:jungle_leaves[persistent=true]
fill 111 170 530 111 171 531 minecraft:jungle_leaves[persistent=true]
setblock 112 170 511 minecraft:smooth_basalt
fill 112 170 512 112 172 512 minecraft:blackstone
fill 112 170 522 112 171 522 minecraft:jungle_leaves[persistent=true]
fill 112 170 530 112 171 530 minecraft:jungle_leaves[persistent=true]
setblock 112 170 551 minecraft:smooth_basalt
fill 113 170 511 113 172 511 minecraft:blackstone
fill 113 170 551 113 171 551 minecraft:blackstone
setblock 117 170 511 minecraft:smooth_basalt
setblock 121 170 511 minecraft:blackstone
setblock 122 170 511 minecraft:smooth_basalt
fill 123 170 511 123 172 512 minecraft:blackstone
setblock 125 170 513 minecraft:smooth_basalt
setblock 126 170 511 minecraft:blackstone
setblock 126 170 512 minecraft:smooth_basalt
fill 126 170 513 128 170 514 minecraft:blackstone
setblock 127 170 511 minecraft:smooth_basalt
fill 127 170 512 127 173 512 minecraft:blackstone
setblock 127 170 551 minecraft:smooth_basalt
fill 128 170 511 128 173 511 minecraft:blackstone
fill 128 170 551 128 173 551 minecraft:blackstone
setblock 129 170 513 minecraft:blackstone
setblock 129 170 514 minecraft:smooth_basalt
fill 129 170 515 129 173 515 minecraft:blackstone
fill 129 170 536 131 171 538 minecraft:smooth_basalt
setblock 130 170 513 minecraft:smooth_basalt
fill 130 170 514 130 173 514 minecraft:blackstone
setblock 131 170 512 minecraft:smooth_basalt
fill 131 170 513 131 173 513 minecraft:blackstone
setblock 131 170 516 minecraft:blackstone
setblock 131 170 517 minecraft:smooth_basalt
setblock 132 170 511 minecraft:smooth_basalt
fill 132 170 512 132 173 512 minecraft:blackstone
setblock 132 170 515 minecraft:blackstone
setblock 132 170 516 minecraft:smooth_basalt
fill 132 170 517 132 173 517 minecraft:blackstone
fill 132 170 519 132 171 519 minecraft:blackstone
setblock 132 170 551 minecraft:smooth_basalt
fill 133 170 511 133 173 511 minecraft:blackstone
setblock 133 170 515 minecraft:smooth_basalt
fill 133 170 516 133 173 516 minecraft:blackstone
setblock 133 170 520 minecraft:smooth_basalt
fill 133 170 521 133 172 521 minecraft:blackstone
fill 133 170 551 133 173 551 minecraft:blackstone
setblock 134 170 514 minecraft:smooth_basalt
fill 134 170 515 134 173 515 minecraft:blackstone
setblock 134 170 519 minecraft:smooth_basalt
fill 134 170 520 134 173 520 minecraft:blackstone
setblock 134 170 534 minecraft:smooth_basalt
fill 134 170 535 134 171 535 minecraft:blackstone
setblock 134 170 539 minecraft:smooth_basalt
setblock 135 170 513 minecraft:smooth_basalt
fill 135 170 514 135 173 514 minecraft:blackstone
setblock 135 170 518 minecraft:smooth_basalt
fill 135 170 519 135 173 519 minecraft:blackstone
setblock 135 170 523 minecraft:smooth_basalt
fill 135 170 524 135 171 524 minecraft:blackstone
setblock 135 170 529 minecraft:blackstone
setblock 135 170 533 minecraft:smooth_basalt
fill 135 170 534 135 172 534 minecraft:blackstone
setblock 135 170 538 minecraft:smooth_basalt
fill 135 170 539 135 173 539 minecraft:blackstone
fill 135 170 541 135 171 541 minecraft:blackstone
setblock 135 170 549 minecraft:blackstone
setblock 95 171 511 minecraft:blackstone
setblock 95 171 512 minecraft:smooth_basalt
fill 95 171 513 95 174 513 minecraft:blackstone
setblock 95 171 517 minecraft:smooth_basalt
fill 95 171 518 95 174 518 minecraft:blackstone
setblock 95 171 532 minecraft:smooth_basalt
setblock 95 171 533 minecraft:blackstone
setblock 95 171 537 minecraft:smooth_basalt
fill 95 171 538 95 171 541 minecraft:blackstone
setblock 95 171 542 minecraft:smooth_basalt
fill 95 171 543 95 174 543 minecraft:blackstone
setblock 95 171 547 minecraft:smooth_basalt
fill 95 171 548 95 173 548 minecraft:blackstone
setblock 96 171 511 minecraft:smooth_basalt
fill 96 171 512 96 172 512 minecraft:blackstone
setblock 96 171 516 minecraft:smooth_basalt
setblock 96 171 517 minecraft:blackstone
setblock 96 171 536 minecraft:smooth_basalt
fill 96 171 537 96 172 537 minecraft:blackstone
setblock 96 171 540 minecraft:blackstone
setblock 96 171 541 minecraft:smooth_basalt
setblock 96 171 551 minecraft:smooth_basalt
fill 97 171 511 100 171 511 minecraft:blackstone
fill 97 171 551 100 171 551 minecraft:blackstone
setblock 101 171 511 minecraft:smooth_basalt
setblock 101 171 551 minecraft:smooth_basalt
fill 102 171 511 102 173 511 minecraft:blackstone
fill 102 171 551 105 171 551 minecraft:blackstone
fill 104 171 550 106 171 550 minecraft:blackstone
setblock 105 171 511 minecraft:blackstone
setblock 105 171 512 minecraft:smooth_basalt
setblock 106 171 511 minecraft:smooth_basalt
fill 106 171 512 106 173 512 minecraft:blackstone
setblock 106 171 551 minecraft:smooth_basalt
fill 107 171 511 107 174 511 minecraft:blackstone
setblock 107 171 550 minecraft:smooth_basalt
fill 107 171 551 107 174 551 minecraft:blackstone
setblock 108 171 513 minecraft:blackstone
fill 108 171 550 108 173 550 minecraft:blackstone
setblock 109 171 513 minecraft:smooth_basalt
setblock 110 171 512 minecraft:smooth_basalt
setblock 110 171 513 minecraft:blackstone
setblock 111 171 511 minecraft:smooth_basalt
fill 111 171 512 111 172 512 minecraft:blackstone
setblock 111 171 551 minecraft:smooth_basalt
fill 112 171 511 112 173 511 minecraft:blackstone
fill 112 171 551 112 172 551 minecraft:blackstone
setblock 121 171 511 minecraft:smooth_basalt
fill 122 171 511 122 174 511 minecraft:blackstone
setblock 124 171 512 minecraft:blackstone
setblock 124 171 513 minecraft:smooth_basalt
setblock 125 171 512 minecraft:smooth_basalt
fill 125 171 513 128 171 513 minecraft:blackstone
setblock 126 171 511 minecraft:smooth_basalt
fill 126 171 512 126 174 512 minecraft:blackstone
fill 126 171 514 127 171 514 minecraft:blackstone
setblock 126 171 551 minecraft:smooth_basalt
fill 127 171 511 127 174 511 minecraft:blackstone
fill 127 171 551 127 174 551 minecraft:blackstone
setblock 128 171 514 minecraft:smooth_basalt
fill 128 171 515 128 173 515 minecraft:blackstone
setblock 129 171 513 minecraft:smooth_basalt
fill 129 171 514 129 174 514 minecraft:blackstone
setblock 130 171 512 minecraft:smooth_basalt
fill 130 171 513 130 174 513 minecraft:blackstone
setblock 131 171 511 minecraft:smooth_basalt
fill 131 171 512 131 174 512 minecraft:blackstone
setblock 131 171 516 minecraft:smooth_basalt
fill 131 171 517 131 172 517 minecraft:blackstone
setblock 131 171 551 minecraft:smooth_basalt
fill 132 171 511 132 174 511 minecraft:blackstone
setblock 132 171 515 minecraft:smooth_basalt
fill 132 171 516 132 174 516 minecraft:blackstone
fill 132 171 551 132 174 551 minecraft:blackstone
setblock 133 171 514 minecraft:smooth_basalt
fill 133 171 515 133 174 515 minecraft:blackstone
setblock 133 171 519 minecraft:smooth_basalt
fill 133 171 520 133 174 520 minecraft:blackstone
setblock 134 171 513 minecraft:smooth_basalt
fill 134 171 514 134 174 514 minecraft:blackstone
setblock 134 171 518 minecraft:smooth_basalt
fill 134 171 519 134 174 519 minecraft:blackstone
setblock 134 171 534 minecraft:blackstone
fill 134 171 536 134 171 537 minecraft:blackstone
setblock 134 171 538 minecraft:smooth_basalt
setblock 134 171 539 minecraft:blackstone
setblock 135 171 512 minecraft:smooth_basalt
fill 135 171 513 135 174 513 minecraft:blackstone
setblock 135 171 517 minecraft:smooth_basalt
fill 135 171 518 135 174 518 minecraft:blackstone
setblock 135 171 522 minecraft:smooth_basalt
fill 135 171 523 135 173 523 minecraft:blackstone
setblock 135 171 532 minecraft:smooth_basalt
setblock 135 171 533 minecraft:blackstone
setblock 135 171 537 minecraft:smooth_basalt
fill 135 171 538 135 174 538 minecraft:blackstone
setblock 135 171 542 minecraft:smooth_basalt
setblock 95 172 511 minecraft:smooth_basalt
fill 95 172 512 95 174 512 minecraft:blackstone
setblock 95 172 516 minecraft:smooth_basalt
fill 95 172 517 95 175 517 minecraft:blackstone
setblock 95 172 536 minecraft:smooth_basalt
fill 95 172 537 95 172 540 minecraft:blackstone
setblock 95 172 541 minecraft:smooth_basalt
fill 95 172 542 95 175 542 minecraft:blackstone
setblock 95 172 546 minecraft:smooth_basalt
fill 95 172 547 95 174 547 minecraft:blackstone
setblock 95 172 550 minecraft:blackstone
setblock 95 172 551 minecraft:smooth_basalt
fill 96 172 511 99 172 511 minecraft:blackstone
setblock 96 172 515 minecraft:smooth_basalt
setblock 96 172 516 minecraft:blackstone
setblock 96 172 540 minecraft:smooth_basalt
fill 96 172 541 96 175 541 minecraft:blackstone
fill 96 172 551 99 172 551 minecraft:blackstone
setblock 100 172 511 minecraft:smooth_basalt
setblock 100 172 551 minecraft:smooth_basalt
fill 101 172 511 101 173 511 minecraft:blackstone
fill 101 172 551 104 172 551 minecraft:blackstone
fill 103 172 511 104 172 511 minecraft:blackstone
setblock 104 172 512 minecraft:smooth_basalt
setblock 105 172 511 minecraft:smooth_basalt
fill 105 172 512 105 173 512 minecraft:blackstone
setblock 105 172 550 minecraft:blackstone
setblock 105 172 551 minecraft:smooth_basalt
fill 106 172 511 106 175 511 minecraft:blackstone
setblock 106 172 550 minecraft:smooth_basalt
fill 106 172 551 106 175 551 minecraft:blackstone
fill 107 172 550 107 173 550 minecraft:blackstone
setblock 109 172 512 minecraft:smooth_basalt
setblock 110 172 511 minecraft:smooth_basalt
fill 110 172 512 110 173 512 minecraft:blackstone
fill 110 172 523 112 172 524 minecraft:jungle_leaves[persistent=true]
fill 110 172 528 112 172 529 minecraft:jungle_leaves[persistent=true]
setblock 110 172 551 minecraft:smooth_basalt
fill 111 172 511 111 173 511 minecraft:blackstone
setblock 111 172 522 minecraft:jungle_leaves[persistent=true]
setblock 111 172 530 minecraft:jungle_leaves[persistent=true]
fill 111 172 551 111 173 551 minecraft:blackstone
setblock 121 172 511 minecraft:blackstone
setblock 124 172 512 minecraft:smooth_basalt
fill 124 172 513 127 172 513 minecraft:blackstone
setblock 125 172 511 minecraft:smooth_basalt
fill 125 172 512 125 175 512 minecraft:blackstone
fill 125 172 514 126 172 514 minecraft:blackstone
fill 126 172 511 126 175 511 minecraft:blackstone
fill 126 172 551 126 174 551 minecraft:blackstone
setblock 127 172 514 minecraft:smooth_basalt
setblock 127 172 515 minecraft:blackstone
setblock 128 172 513 minecraft:smooth_basalt
fill 128 172 514 128 175 514 minecraft:blackstone
setblock 129 172 512 minecraft:smooth_basalt
fill 129 172 513 129 175 513 minecraft:blackstone
fill 129 172 537 131 174 537 minecraft:smooth_basalt
setblock 130 172 511 minecraft:smooth_basalt
fill 130 172 512 130 175 512 minecraft:blackstone
setblock 130 172 515 minecraft:blackstone
fill 130 172 536 130 174 536 minecraft:smooth_basalt
fill 130 172 538 130 174 538 minecraft:smooth_basalt
setblock 130 172 551 minecraft:smooth_basalt
fill 131 172 511 131 175 511 minecraft:blackstone
setblock 131 172 515 minecraft:smooth_basalt
setblock 131 172 516 minecraft:blackstone
fill 131 172 551 131 174 551 minecraft:blackstone
setblock 132 172 514 minecraft:smooth_basalt
fill 132 172 515 132 173 515 minecraft:blackstone
setblock 132 172 519 minecraft:smooth_basalt
setblock 133 172 513 minecraft:smooth_basalt
fill 133 172 514 133 174 514 minecraft:blackstone
setblock 133 172 518 minecraft:smooth_basalt
fill 133 172 519 133 174 519 minecraft:blackstone
setblock 134 172 512 minecraft:smooth_basalt
fill 134 172 513 134 175 513 minecraft:blackstone
setblock 134 172 517 minecraft:smooth_basalt
fill 134 172 518 134 175 518 minecraft:blackstone
setblock 134 172 522 minecraft:smooth_basalt
setblock 134 172 537 minecraft:smooth_basalt
setblock 134 172 538 minecraft:blackstone
setblock 135 172 511 minecraft:smooth_basalt
fill 135 172 512 135 175 512 minecraft:blackstone
setblock 135 172 516 minecraft:smooth_basalt
fill 135 172 517 135 175 517 minecraft:blackstone
setblock 135 172 521 minecraft:smooth_basalt
fill 135 172 522 135 175 522 minecraft:blackstone
setblock 135 172 536 minecraft:smooth_basalt
fill 135 172 537 135 173 537 minecraft:blackstone
setblock 135 172 541 minecraft:smooth_basalt
fill 135 172 542 135 174 542 minecraft:blackstone
setblock 135 172 551 minecraft:smooth_basalt
fill 95 173 511 97 173 511 minecraft:blackstone
setblock 95 173 515 minecraft:smooth_basalt
fill 95 173 516 95 175 516 minecraft:blackstone
setblock 95 173 520 minecraft:smooth_basalt
setblock 95 173 535 minecraft:smooth_basalt
fill 95 173 536 95 173 539 minecraft:blackstone
setblock 95 173 540 minecraft:smooth_basalt
fill 95 173 541 95 176 541 minecraft:blackstone
setblock 95 173 545 minecraft:smooth_basalt
fill 95 173 546 95 176 546 minecraft:blackstone
setblock 95 173 550 minecraft:smooth_basalt
fill 95 173 551 97 173 551 minecraft:blackstone
setblock 96 173 538 minecraft:blackstone
setblock 96 173 539 minecraft:smooth_basalt
fill 96 173 540 96 174 540 minecraft:blackstone
fill 96 173 542 96 174 542 minecraft:blackstone
setblock 97 173 513 minecraft:light[level=12]
setblock 97 173 521 minecraft:light[level=12]
setblock 97 173 529 minecraft:light[level=12]
setblock 97 173 537 minecraft:light[level=12]
setblock 97 173 545 minecraft:light[level=12]
fill 100 173 551 103 173 551 minecraft:blackstone
setblock 103 173 511 minecraft:blackstone
setblock 104 173 511 minecraft:smooth_basalt
setblock 104 173 551 minecraft:smooth_basalt
fill 105 173 511 105 175 511 minecraft:blackstone
setblock 105 173 513 minecraft:light[level=12]
setblock 105 173 521 minecraft:light[level=12]
setblock 105 173 537 minecraft:light[level=12]
setblock 105 173 545 minecraft:light[level=12]
setblock 105 173 550 minecraft:smooth_basalt
fill 105 173 551 105 176 551 minecraft:blackstone
setblock 106 173 550 minecraft:blackstone
setblock 108 173 512 minecraft:smooth_basalt
setblock 109 173 511 minecraft:smooth_basalt
setblock 109 173 512 minecraft:blackstone
fill 109 173 523 109 173 525 minecraft:jungle_leaves[persistent=true]
fill 109 173 527 109 173 529 minecraft:jungle_leaves[persistent=true]
setblock 109 173 551 minecraft:smooth_basalt
fill 110 173 511 110 174 511 minecraft:blackstone
fill 110 173 524 110 173 525 minecraft:jungle_leaves[persistent=true]
fill 110 173 527 110 173 528 minecraft:jungle_leaves[persistent=true]
setblock 110 173 551 minecraft:blackstone
setblock 113 173 513 minecraft:light[level=12]
setblock 113 173 521 minecraft:light[level=12]
setblock 113 173 529 minecraft:light[level=12]
setblock 113 173 537 minecraft:light[level=12]
setblock 113 173 545 minecraft:light[level=12]
setblock 121 173 513 minecraft:light[level=12]
setblock 121 173 521 minecraft:light[level=12]
setblock 121 173 529 minecraft:light[level=12]
setblock 121 173 537 minecraft:light[level=12]
setblock 121 173 545 minecraft:light[level=12]
setblock 123 173 511 minecraft:blackstone
setblock 123 173 512 minecraft:smooth_basalt
setblock 124 173 511 minecraft:smooth_basalt
fill 124 173 512 124 174 513 minecraft:blackstone
fill 125 173 511 125 176 511 minecraft:blackstone
fill 125 173 513 125 173 514 minecraft:blackstone
setblock 126 173 513 minecraft:blackstone
setblock 126 173 514 minecraft:smooth_basalt
setblock 127 173 513 minecraft:smooth_basalt
fill 127 173 514 127 175 514 minecraft:blackstone
setblock 128 173 512 minecraft:smooth_basalt
fill 128 173 513 128 176 513 minecraft:blackstone
setblock 129 173 511 minecraft:smooth_basalt
fill 129 173 512 129 176 512 minecraft:blackstone
setblock 129 173 521 minecraft:light[level=12]
setblock 129 173 529 minecraft:light[level=12]
setblock 129 173 545 minecraft:light[level=12]
setblock 129 173 551 minecraft:smooth_basalt
fill 130 173 511 130 176 511 minecraft:blackstone
fill 130 173 551 130 175 551 minecraft:blackstone
setblock 131 173 514 minecraft:smooth_basalt
setblock 132 173 513 minecraft:smooth_basalt
setblock 132 173 514 minecraft:blackstone
setblock 132 173 518 minecraft:smooth_basalt
setblock 132 173 519 minecraft:blackstone
setblock 133 173 512 minecraft:smooth_basalt
fill 133 173 513 133 174 513 minecraft:blackstone
setblock 133 173 517 minecraft:smooth_basalt
fill 133 173 518 133 175 518 minecraft:blackstone
setblock 134 173 511 minecraft:smooth_basalt
fill 134 173 512 134 174 512 minecraft:blackstone
setblock 134 173 516 minecraft:smooth_basalt
fill 134 173 517 134 176 517 minecraft:blackstone
setblock 134 173 521 minecraft:smooth_basalt
setblock 134 173 551 minecraft:smooth_basalt
fill 135 173 511 135 175 511 minecraft:blackstone
setblock 135 173 515 minecraft:smooth_basalt
fill 135 173 516 135 176 516 minecraft:blackstone
setblock 135 173 520 minecraft:smooth_basalt
fill 135 173 521 135 176 521 minecraft:blackstone
setblock 135 173 536 minecraft:blackstone
setblock 135 173 540 minecraft:smooth_basalt
fill 135 173 541 135 174 541 minecraft:blackstone
setblock 95 174 511 minecraft:blackstone
setblock 95 174 514 minecraft:smooth_basalt
fill 95 174 515 95 175 515 minecraft:blackstone
setblock 95 174 519 minecraft:smooth_basalt
fill 95 174 536 95 174 538 minecraft:blackstone
setblock 95 174 539 minecraft:smooth_basalt
fill 95 174 540 95 177 540 minecraft:blackstone
setblock 95 174 544 minecraft:smooth_basalt
fill 95 174 545 95 177 545 minecraft:blackstone
setblock 96 174 539 minecraft:blackstone
fill 101 174 551 102 174 551 minecraft:blackstone
setblock 103 174 511 minecraft:smooth_basalt
setblock 103 174 551 minecraft:smooth_basalt
setblock 104 174 511 minecraft:blackstone
fill 104 174 551 104 177 551 minecraft:blackstone
setblock 108 174 511 minecraft:smooth_basalt
setblock 108 174 551 minecraft:smooth_basalt
setblock 109 174 511 minecraft:blackstone
setblock 109 174 551 minecraft:blackstone
setblock 123 174 511 minecraft:smooth_basalt
fill 123 174 512 123 175 512 minecraft:blackstone
fill 124 174 511 124 177 511 minecraft:blackstone
setblock 125 174 513 minecraft:blackstone
setblock 126 174 513 minecraft:smooth_basalt
setblock 126 174 514 minecraft:blackstone
setblock 127 174 512 minecraft:smooth_basalt
fill 127 174 513 127 176 513 minecraft:blackstone
setblock 128 174 511 minecraft:smooth_basalt
fill 128 174 512 128 177 512 minecraft:blackstone
setblock 128 174 551 minecraft:smooth_basalt
fill 129 174 511 129 177 511 minecraft:blackstone
fill 129 174 551 129 175 551 minecraft:blackstone
setblock 130 174 514 minecraft:smooth_basalt
setblock 131 174 513 minecraft:smooth_basalt
setblock 131 174 514 minecraft:blackstone
setblock 132 174 512 minecraft:smooth_basalt
setblock 132 174 513 minecraft:blackstone
setblock 132 174 517 minecraft:smooth_basalt
setblock 133 174 511 minecraft:smooth_basalt
fill 133 174 512 133 175 512 minecraft:blackstone
setblock 133 174 516 minecraft:smooth_basalt
fill 133 174 517 133 175 517 minecraft:blackstone
fill 134 174 511 134 175 511 minecraft:blackstone
setblock 134 174 515 minecraft:smooth_basalt
fill 134 174 516 134 176 516 minecraft:blackstone
setblock 134 174 520 minecraft:smooth_basalt
setblock 134 174 521 minecraft:blackstone
setblock 135 174 514 minecraft:smooth_basalt
fill 135 174 515 135 177 515 minecraft:blackstone
setblock 135 174 519 minecraft:smooth_basalt
fill 135 174 520 135 177 520 minecraft:blackstone
setblock 135 174 539 minecraft:smooth_basalt
setblock 135 174 540 minecraft:blackstone
setblock 95 175 518 minecraft:smooth_basalt
setblock 95 175 537 minecraft:blackstone
setblock 95 175 538 minecraft:smooth_basalt
fill 95 175 539 95 178 539 minecraft:blackstone
setblock 95 175 543 minecraft:smooth_basalt
fill 95 175 544 95 178 544 minecraft:blackstone
setblock 102 175 551 minecraft:smooth_basalt
fill 103 175 551 103 178 551 minecraft:blackstone
setblock 107 175 511 minecraft:smooth_basalt
setblock 107 175 551 minecraft:smooth_basalt
setblock 108 175 551 minecraft:blackstone
setblock 122 175 511 minecraft:smooth_basalt
fill 123 175 511 123 178 511 minecraft:blackstone
fill 124 175 512 124 176 512 minecraft:blackstone
setblock 125 175 513 minecraft:smooth_basalt
setblock 126 175 512 minecraft:smooth_basalt
fill 126 175 513 126 176 513 minecraft:blackstone
setblock 127 175 511 minecraft:smooth_basalt
fill 127 175 512 127 178 512 minecraft:blackstone
setblock 127 175 551 minecraft:smooth_basalt
fill 128 175 511 128 178 511 minecraft:blackstone
setblock 128 175 551 minecraft:blackstone
setblock 130 175 513 minecraft:smooth_basalt
fill 130 175 537 130 179 537 minecraft:smooth_basalt
setblock 131 175 512 minecraft:smooth_basalt
setblock 131 175 513 minecraft:blackstone
setblock 132 175 511 minecraft:smooth_basalt
setblock 132 175 512 minecraft:blackstone
fill 133 175 511 133 176 511 minecraft:blackstone
setblock 133 175 516 minecraft:blackstone
setblock 134 175 514 minecraft:smooth_basalt
setblock 134 175 515 minecraft:blackstone
setblock 134 175 519 minecraft:smooth_basalt
setblock 134 175 520 minecraft:blackstone
setblock 135 175 513 minecraft:smooth_basalt
fill 135 175 514 135 176 514 minecraft:blackstone
setblock 135 175 518 minecraft:smooth_basalt
fill 135 175 519 135 178 519 minecraft:blackstone
setblock 95 176 538 minecraft:blackstone
setblock 95 176 542 minecraft:smooth_basalt
fill 95 176 543 95 179 543 minecraft:blackstone
setblock 106 176 551 minecraft:smooth_basalt
setblock 125 176 512 minecraft:smooth_basalt
setblock 126 176 511 minecraft:smooth_basalt
fill 126 176 512 126 179 512 minecraft:blackstone
fill 127 176 511 127 179 511 minecraft:blackstone
setblock 129 176 513 minecraft:smooth_basalt
setblock 130 176 512 minecraft:smooth_basalt
setblock 131 176 511 minecraft:smooth_basalt
setblock 131 176 512 minecraft:blackstone
fill 132 176 511 132 177 511 minecraft:blackstone
setblock 134 176 518 minecraft:smooth_basalt
setblock 134 176 519 minecraft:blackstone
setblock 135 176 513 minecraft:blackstone
setblock 135 176 517 minecraft:smooth_basalt
fill 135 176 518 135 178 518 minecraft:blackstone
setblock 95 177 541 minecraft:smooth_basalt
fill 95 177 542 95 180 542 minecraft:blackstone
setblock 95 177 546 minecraft:smooth_basalt
setblock 105 177 551 minecraft:smooth_basalt
setblock 124 177 512 minecraft:smooth_basalt
setblock 125 177 511 minecraft:smooth_basalt
fill 125 177 512 125 180 512 minecraft:blackstone
fill 126 177 511 126 180 511 minecraft:blackstone
setblock 129 177 512 minecraft:smooth_basalt
setblock 130 177 511 minecraft:smooth_basalt
fill 131 177 511 131 178 511 minecraft:blackstone
setblock 135 177 516 minecraft:smooth_basalt
fill 135 177 517 135 178 517 minecraft:blackstone
setblock 95 178 540 minecraft:smooth_basalt
fill 95 178 541 95 181 541 minecraft:blackstone
setblock 95 178 545 minecraft:smooth_basalt
fill 95 178 546 95 180 547 minecraft:blackstone
fill 96 178 542 96 178 543 minecraft:blackstone
setblock 104 178 551 minecraft:smooth_basalt
setblock 124 178 511 minecraft:smooth_basalt
fill 125 178 511 125 181 511 minecraft:blackstone
setblock 128 178 512 minecraft:smooth_basalt
setblock 129 178 511 minecraft:smooth_basalt
fill 130 178 511 130 181 511 minecraft:blackstone
setblock 135 178 520 minecraft:smooth_basalt
setblock 95 179 539 minecraft:smooth_basalt
fill 95 179 540 95 182 540 minecraft:blackstone
setblock 95 179 544 minecraft:smooth_basalt
fill 95 179 545 96 181 545 minecraft:blackstone
setblock 95 179 548 minecraft:blackstone
setblock 96 179 542 minecraft:blackstone
setblock 96 179 543 minecraft:smooth_basalt
fill 96 179 544 96 182 544 minecraft:blackstone
setblock 102 179 551 minecraft:blackstone
setblock 103 179 551 minecraft:smooth_basalt
fill 104 179 551 105 181 551 minecraft:blackstone
setblock 122 179 511 minecraft:blackstone
setblock 123 179 511 minecraft:smooth_basalt
fill 124 179 511 124 181 512 minecraft:blackstone
fill 125 179 551 127 179 551 minecraft:blackstone
setblock 127 179 512 minecraft:smooth_basalt
setblock 128 179 511 minecraft:smooth_basalt
fill 129 179 511 129 182 511 minecraft:blackstone
setblock 135 179 543 minecraft:blackstone
setblock 135 179 544 minecraft:smooth_basalt
fill 135 179 545 135 182 545 minecraft:blackstone
fill 95 180 539 95 183 539 minecraft:blackstone
setblock 95 180 543 minecraft:smooth_basalt
fill 95 180 544 95 183 544 minecraft:blackstone
setblock 95 180 548 minecraft:smooth_basalt
fill 95 180 549 95 183 549 minecraft:blackstone
setblock 96 180 541 minecraft:blackstone
setblock 96 180 542 minecraft:smooth_basalt
fill 96 180 543 96 183 543 minecraft:blackstone
setblock 96 180 546 minecraft:blackstone
fill 100 180 551 101 180 551 minecraft:blackstone
setblock 102 180 551 minecraft:smooth_basalt
fill 103 180 551 103 183 551 minecraft:blackstone
setblock 121 180 511 minecraft:blackstone
setblock 122 180 511 minecraft:smooth_basalt
fill 123 180 511 123 183 511 minecraft:blackstone
fill 123 180 551 126 180 551 minecraft:blackstone
setblock 126 180 512 minecraft:smooth_basalt
setblock 127 180 511 minecraft:smooth_basalt
setblock 127 180 551 minecraft:smooth_basalt
fill 128 180 511 128 183 511 minecraft:blackstone
fill 128 180 551 128 183 551 minecraft:blackstone
setblock 130 180 537 minecraft:shroomlight
setblock 135 180 542 minecraft:blackstone
setblock 135 180 543 minecraft:smooth_basalt
fill 135 180 544 135 183 544 minecraft:blackstone
fill 135 180 546 135 180 547 minecraft:blackstone
setblock 135 180 548 minecraft:smooth_basalt
setblock 95 181 542 minecraft:smooth_basalt
fill 95 181 543 95 184 543 minecraft:blackstone
setblock 95 181 546 minecraft:blackstone
setblock 95 181 547 minecraft:smooth_basalt
fill 95 181 548 96 183 548 minecraft:blackstone
fill 95 181 550 95 182 550 minecraft:blackstone
setblock 96 181 541 minecraft:smooth_basalt
fill 96 181 542 96 184 542 minecraft:blackstone
setblock 96 181 546 minecraft:smooth_basalt
fill 96 181 547 96 184 547 minecraft:blackstone
setblock 97 181 513 minecraft:light[level=12]
setblock 97 181 521 minecraft:light[level=12]
setblock 97 181 529 minecraft:light[level=12]
setblock 97 181 537 minecraft:light[level=12]
fill 97 181 543 97 181 544 minecraft:blackstone
setblock 97 181 545 minecraft:smooth_basalt
fill 97 181 551 100 181 551 minecraft:blackstone
fill 100 181 550 101 181 550 minecraft:blackstone
setblock 101 181 551 minecraft:smooth_basalt
setblock 102 181 550 minecraft:smooth_basalt
fill 102 181 551 102 184 551 minecraft:blackstone
fill 103 181 550 104 183 550 minecraft:blackstone
setblock 105 181 513 minecraft:light[level=12]
setblock 105 181 521 minecraft:light[level=12]
setblock 105 181 529 minecraft:light[level=12]
setblock 105 181 537 minecraft:light[level=12]
setblock 105 181 545 minecraft:light[level=12]
setblock 106 181 551 minecraft:smooth_basalt
setblock 113 181 513 minecraft:light[level=12]
setblock 113 181 521 minecraft:light[level=12]
setblock 113 181 529 minecraft:light[level=12]
setblock 113 181 537 minecraft:light[level=12]
setblock 113 181 545 minecraft:light[level=12]
setblock 120 181 511 minecraft:blackstone
setblock 121 181 511 minecraft:smooth_basalt
setblock 121 181 513 minecraft:light[level=12]
setblock 121 181 521 minecraft:light[level=12]
setblock 121 181 529 minecraft:light[level=12]
setblock 121 181 537 minecraft:light[level=12]
setblock 121 181 545 minecraft:light[level=12]
fill 122 181 511 122 184 511 minecraft:blackstone
fill 122 181 551 125 181 551 minecraft:blackstone
fill 123 181 512 123 182 512 minecraft:blackstone
setblock 125 181 512 minecraft:smooth_basalt
setblock 126 181 511 minecraft:smooth_basalt
fill 126 181 512 126 184 512 minecraft:blackstone
setblock 126 181 551 minecraft:smooth_basalt
fill 127 181 511 127 184 511 minecraft:blackstone
fill 127 181 551 127 184 551 minecraft:blackstone
setblock 129 181 513 minecraft:light[level=12]
setblock 129 181 521 minecraft:light[level=12]
setblock 129 181 529 minecraft:light[level=12]
setblock 129 181 537 minecraft:light[level=12]
setblock 129 181 545 minecraft:light[level=12]
fill 129 181 551 130 181 551 minecraft:blackstone
setblock 135 181 542 minecraft:smooth_basalt
fill 135 181 543 135 184 543 minecraft:blackstone
setblock 135 181 546 minecraft:blackstone
setblock 135 181 547 minecraft:smooth_basalt
fill 135 181 548 135 182 550 minecraft:blackstone
fill 95 182 538 95 184 538 minecraft:blackstone
setblock 95 182 541 minecraft:smooth_basalt
fill 95 182 542 95 185 542 minecraft:blackstone
setblock 95 182 545 minecraft:blackstone
setblock 95 182 546 minecraft:smooth_basalt
fill 95 182 547 95 185 547 minecraft:blackstone
setblock 95 182 551 minecraft:smooth_basalt
setblock 96 182 540 minecraft:smooth_basalt
fill 96 182 541 96 185 541 minecraft:blackstone
setblock 96 182 545 minecraft:smooth_basalt
fill 96 182 546 97 184 546 minecraft:blackstone
setblock 96 182 549 minecraft:blackstone
fill 96 182 551 99 182 551 minecraft:blackstone
fill 97 182 542 97 182 543 minecraft:blackstone
setblock 97 182 544 minecraft:smooth_basalt
fill 97 182 545 97 185 545 minecraft:blackstone
fill 97 182 547 97 183 547 minecraft:blackstone
fill 97 182 550 100 182 550 minecraft:blackstone
fill 100 182 549 101 182 549 minecraft:blackstone
setblock 100 182 551 minecraft:smooth_basalt
setblock 101 182 550 minecraft:smooth_basalt
fill 101 182 551 101 185 551 minecraft:blackstone
setblock 102 182 549 minecraft:smooth_basalt
fill 102 182 550 102 185 550 minecraft:blackstone
fill 103 182 549 103 185 549 minecraft:blackstone
setblock 104 182 551 minecraft:blackstone
setblock 105 182 550 minecraft:blackstone
setblock 105 182 551 minecraft:smooth_basalt
fill 106 182 551 106 185 551 minecraft:blackstone
setblock 119 182 511 minecraft:blackstone
setblock 120 182 511 minecraft:smooth_basalt
setblock 120 182 551 minecraft:smooth_basalt
fill 121 182 511 121 184 512 minecraft:blackstone
fill 121 182 551 124 182 551 minecraft:blackstone
fill 122 182 512 122 183 512 minecraft:blackstone
fill 122 182 550 125 182 550 minecraft:blackstone
setblock 124 182 511 minecraft:blackstone
setblock 124 182 512 minecraft:smooth_basalt
setblock 125 182 511 minecraft:smooth_basalt
fill 125 182 512 125 185 512 minecraft:blackstone
setblock 125 182 551 minecraft:smooth_basalt
fill 126 182 511 126 185 511 minecraft:blackstone
setblock 126 182 550 minecraft:smooth_basalt
fill 126 182 551 126 185 551 minecraft:blackstone
fill 127 182 512 127 183 512 minecraft:blackstone
fill 127 182 550 128 184 550 minecraft:blackstone
setblock 129 182 551 minecraft:blackstone
setblock 130 182 511 minecraft:smooth_basalt
setblock 130 182 551 minecraft:smooth_basalt
fill 131 182 551 134 182 551 minecraft:blackstone
fill 134 182 545 134 182 546 minecraft:blackstone
setblock 134 182 547 minecraft:smooth_basalt
setblock 135 182 521 minecraft:smooth_basalt
fill 135 182 522 135 185 522 minecraft:blackstone
setblock 135 182 541 minecraft:smooth_basalt
fill 135 182 542 135 185 542 minecraft:blackstone
setblock 135 182 546 minecraft:smooth_basalt
fill 135 182 547 135 185 547 minecraft:blackstone
setblock 135 182 551 minecraft:smooth_basalt
fill 95 183 522 95 183 524 minecraft:blackstone
setblock 95 183 525 minecraft:smooth_basalt
fill 95 183 526 95 185 527 minecraft:blackstone
setblock 95 183 540 minecraft:smooth_basalt
fill 95 183 541 95 186 541 minecraft:blackstone
setblock 95 183 545 minecraft:smooth_basalt
fill 95 183 546 95 186 546 minecraft:blackstone
setblock 95 183 550 minecraft:smooth_basalt
fill 95 183 551 98 183 551 minecraft:blackstone
setblock 96 183 539 minecraft:smooth_basalt
fill 96 183 540 96 186 540 minecraft:blackstone
setblock 96 183 544 minecraft:smooth_basalt
fill 96 183 545 96 186 545 minecraft:blackstone
setblock 96 183 549 minecraft:smooth_basalt
fill 96 183 550 99 183 550 minecraft:blackstone
fill 97 183 541 97 183 542 minecraft:blackstone
setblock 97 183 543 minecraft:smooth_basalt
fill 97 183 544 98 185 544 minecraft:blackstone
setblock 97 183 548 minecraft:smooth_basalt
fill 98 183 545 98 183 546 minecraft:blackstone
fill 98 183 549 100 183 549 minecraft:blackstone
setblock 99 183 551 minecraft:smooth_basalt
setblock 100 183 550 minecraft:smooth_basalt
fill 100 183 551 100 186 551 minecraft:blackstone
setblock 101 183 549 minecraft:smooth_basalt
fill 101 183 550 101 186 550 minecraft:blackstone
fill 102 183 549 102 186 549 minecraft:blackstone
fill 104 183 549 104 184 549 minecraft:blackstone
setblock 104 183 551 minecraft:smooth_basalt
setblock 105 183 550 minecraft:smooth_basalt
fill 105 183 551 105 186 551 minecraft:blackstone
fill 107 183 551 107 184 551 minecraft:blackstone
setblock 118 183 511 minecraft:blackstone
setblock 118 183 551 minecraft:blackstone
setblock 119 183 511 minecraft:smooth_basalt
setblock 119 183 551 minecraft:smooth_basalt
fill 120 183 511 120 185 512 minecraft:blackstone
setblock 120 183 550 minecraft:smooth_basalt
fill 120 183 551 123 183 551 minecraft:blackstone
fill 121 183 550 124 183 550 minecraft:blackstone
setblock 123 183 512 minecraft:smooth_basalt
fill 123 183 549 125 183 549 minecraft:blackstone
setblock 124 183 511 minecraft:smooth_basalt
fill 124 183 512 124 186 512 minecraft:blackstone
setblock 124 183 551 minecraft:smooth_basalt
fill 125 183 511 125 186 511 minecraft:blackstone
setblock 125 183 550 minecraft:smooth_basalt
fill 125 183 551 125 186 551 minecraft:blackstone
fill 126 183 550 126 186 550 minecraft:blackstone
setblock 129 183 511 minecraft:smooth_basalt
setblock 129 183 550 minecraft:blackstone
setblock 129 183 551 minecraft:smooth_basalt
fill 130 183 511 131 185 511 minecraft:blackstone
setblock 130 183 550 minecraft:smooth_basalt
fill 130 183 551 133 183 551 minecraft:blackstone
fill 134 183 544 134 183 545 minecraft:blackstone
setblock 134 183 546 minecraft:smooth_basalt
fill 134 183 547 134 183 550 minecraft:blackstone
setblock 134 183 551 minecraft:smooth_basalt
setblock 135 183 520 minecraft:smooth_basalt
fill 135 183 521 135 186 521 minecraft:blackstone
fill 135 183 523 135 183 524 minecraft:blackstone
setblock 135 183 525 minecraft:smooth_basalt
fill 135 183 541 135 186 541 minecraft:blackstone
setblock 135 183 545 minecraft:smooth_basalt
fill 135 183 546 135 186 546 minecraft:blackstone
fill 135 183 548 135 183 549 minecraft:blackstone
setblock 135 183 550 minecraft:smooth_basalt
fill 135 183 551 135 186 551 minecraft:blackstone
fill 95 184 522 95 184 523 minecraft:blackstone
setblock 95 184 524 minecraft:smooth_basalt
fill 95 184 525 96 186 525 minecraft:blackstone
setblock 95 184 528 minecraft:blackstone
setblock 95 184 529 minecraft:smooth_basalt
fill 95 184 530 95 186 531 minecraft:blackstone
fill 95 184 537 95 185 537 minecraft:blackstone
setblock 95 184 539 minecraft:smooth_basalt
fill 95 184 540 95 187 540 minecraft:blackstone
setblock 95 184 544 minecraft:smooth_basalt
fill 95 184 545 95 187 545 minecraft:blackstone
setblock 95 184 548 minecraft:blackstone
setblock 95 184 549 minecraft:smooth_basalt
fill 95 184 550 97 184 551 minecraft:blackstone
fill 96 184 524 96 187 524 minecraft:blackstone
fill 96 184 526 96 184 527 minecraft:blackstone
fill 96 184 539 96 187 539 minecraft:blackstone
setblock 96 184 543 minecraft:smooth_basalt
fill 96 184 544 96 187 544 minecraft:blackstone
setblock 96 184 548 minecraft:smooth_basalt
fill 96 184 549 99 184 549 minecraft:blackstone
setblock 97 184 541 minecraft:blackstone
setblock 97 184 542 minecraft:smooth_basalt
fill 97 184 543 98 186 543 minecraft:blackstone
setblock 97 184 547 minecraft:smooth_basalt
fill 97 184 548 97 187 548 minecraft:blackstone
setblock 98 184 545 minecraft:blackstone
setblock 98 184 546 minecraft:smooth_basalt
fill 98 184 547 98 187 547 minecraft:blackstone
setblock 98 184 550 minecraft:blackstone
setblock 98 184 551 minecraft:smooth_basalt
fill 99 184 548 100 184 548 minecraft:blackstone
setblock 99 184 550 minecraft:smooth_basalt
fill 99 184 551 99 187 551 minecraft:blackstone
fill 100 184 511 102 184 511 minecraft:blackstone
setblock 100 184 549 minecraft:smooth_basalt
fill 100 184 550 100 187 550 minecraft:blackstone
setblock 101 184 548 minecraft:smooth_basalt
fill 101 184 549 101 187 549 minecraft:blackstone
fill 102 184 548 102 186 548 minecraft:blackstone
setblock 103 184 511 minecraft:smooth_basalt
setblock 103 184 550 minecraft:blackstone
setblock 103 184 551 minecraft:smooth_basalt
fill 104 184 511 104 187 511 minecraft:blackstone
setblock 104 184 550 minecraft:smooth_basalt
fill 104 184 551 104 187 551 minecraft:blackstone
fill 105 184 550 106 186 550 minecraft:blackstone
setblock 117 184 511 minecraft:blackstone
setblock 117 184 551 minecraft:blackstone
setblock 118 184 511 minecraft:smooth_basalt
setblock 118 184 551 minecraft:smooth_basalt
fill 119 184 511 119 186 512 minecraft:blackstone
setblock 119 184 550 minecraft:smooth_basalt
fill 119 184 551 122 184 551 minecraft:blackstone
fill 120 184 550 123 184 550 minecraft:blackstone
fill 121 184 549 124 184 549 minecraft:blackstone
setblock 122 184 512 minecraft:smooth_basalt
fill 122 184 513 123 186 513 minecraft:blackstone
setblock 123 184 511 minecraft:smooth_basalt
fill 123 184 512 123 187 512 minecraft:blackstone
setblock 123 184 551 minecraft:smooth_basalt
fill 124 184 511 124 187 511 minecraft:blackstone
setblock 124 184 550 minecraft:smooth_basalt
fill 124 184 551 124 187 551 minecraft:blackstone
setblock 125 184 549 minecraft:smooth_basalt
fill 125 184 550 125 187 550 minecraft:blackstone
fill 126 184 549 127 186 549 minecraft:blackstone
setblock 127 184 512 minecraft:smooth_basalt
setblock 128 184 511 minecraft:smooth_basalt
setblock 128 184 551 minecraft:smooth_basalt
fill 129 184 511 129 187 511 minecraft:blackstone
setblock 129 184 550 minecraft:smooth_basalt
fill 129 184 551 132 184 551 minecraft:blackstone
fill 130 184 550 133 184 550 minecraft:blackstone
setblock 132 184 511 minecraft:blackstone
setblock 133 184 551 minecraft:smooth_basalt
fill 134 184 511 135 186 511 minecraft:blackstone
fill 134 184 543 134 184 544 minecraft:blackstone
setblock 134 184 545 minecraft:smooth_basalt
fill 134 184 546 134 184 549 minecraft:blackstone
setblock 134 184 550 minecraft:smooth_basalt
fill 134 184 551 134 187 551 minecraft:blackstone
setblock 135 184 520 minecraft:blackstone
setblock 135 184 523 minecraft:blackstone
setblock 135 184 524 minecraft:smooth_basalt
fill 135 184 525 135 185 527 minecraft:blackstone
fill 135 184 540 135 187 540 minecraft:blackstone
setblock 135 184 544 minecraft:smooth_basalt
fill 135 184 545 135 187 545 minecraft:blackstone
setblock 135 184 548 minecraft:blackstone
setblock 135 184 549 minecraft:smooth_basalt
fill 135 184 550 135 187 550 minecraft:blackstone
fill 95 185 521 95 185 522 minecraft:blackstone
setblock 95 185 523 minecraft:smooth_basalt
fill 95 185 524 95 188 524 minecraft:blackstone
setblock 95 185 528 minecraft:smooth_basalt
fill 95 185 529 96 187 529 minecraft:blackstone
setblock 95 185 532 minecraft:blackstone
setblock 95 185 533 minecraft:smooth_basalt
fill 95 185 534 95 186 536 minecraft:blackstone
setblock 95 185 538 minecraft:smooth_basalt
fill 95 185 539 95 188 539 minecraft:blackstone
setblock 95 185 543 minecraft:smooth_basalt
fill 95 185 544 95 188 544 minecraft:blackstone
setblock 95 185 548 minecraft:smooth_basalt
fill 95 185 549 96 185 551 minecraft:blackstone
fill 96 185 523 96 188 523 minecraft:blackstone
setblock 96 185 526 minecraft:blackstone
setblock 96 185 527 minecraft:smooth_basalt
fill 96 185 528 97 187 528 minecraft:blackstone
fill 96 185 530 96 185 531 minecraft:blackstone
fill 96 185 538 96 188 538 minecraft:blackstone
setblock 96 185 542 minecraft:smooth_basalt
fill 96 185 543 96 188 543 minecraft:blackstone
setblock 96 185 546 minecraft:blackstone
setblock 96 185 547 minecraft:smooth_basalt
fill 96 185 548 96 188 548 minecraft:blackstone
setblock 97 185 526 minecraft:smooth_basalt
fill 97 185 527 97 188 527 minecraft:blackstone
setblock 97 185 540 minecraft:blackstone
setblock 97 185 541 minecraft:smooth_basalt
fill 97 185 542 97 188 542 minecraft:blackstone
setblock 97 185 546 minecraft:smooth_basalt
fill 97 185 547 97 188 547 minecraft:blackstone
fill 97 185 549 97 185 550 minecraft:blackstone
setblock 97 185 551 minecraft:smooth_basalt
fill 98 185 511 101 185 511 minecraft:blackstone
setblock 98 185 545 minecraft:smooth_basalt
fill 98 185 546 98 188 546 minecraft:blackstone
fill 98 185 548 98 185 549 minecraft:blackstone
setblock 98 185 550 minecraft:smooth_basalt
fill 98 185 551 98 188 551 minecraft:blackstone
setblock 99 185 548 minecraft:blackstone
setblock 99 185 549 minecraft:smooth_basalt
fill 99 185 550 99 188 550 minecraft:blackstone
setblock 100 185 548 minecraft:smooth_basalt
fill 100 185 549 100 188 549 minecraft:blackstone
fill 101 185 548 101 187 548 minecraft:blackstone
setblock 102 185 511 minecraft:smooth_basalt
setblock 102 185 551 minecraft:smooth_basalt
fill 103 185 511 103 188 511 minecraft:blackstone
setblock 103 185 550 minecraft:smooth_basalt
fill 103 185 551 103 188 551 minecraft:blackstone
setblock 104 185 549 minecraft:smooth_basalt
fill 104 185 550 104 188 550 minecraft:blackstone
setblock 107 185 551 minecraft:smooth_basalt
fill 115 185 511 116 185 511 minecraft:blackstone
fill 115 185 551 116 185 551 minecraft:blackstone
setblock 117 185 511 minecraft:smooth_basalt
setblock 117 185 550 minecraft:blackstone
setblock 117 185 551 minecraft:smooth_basalt
fill 118 185 511 118 187 512 minecraft:blackstone
setblock 118 185 550 minecraft:smooth_basalt
fill 118 185 551 121 185 551 minecraft:blackstone
setblock 119 185 549 minecraft:smooth_basalt
fill 119 185 550 122 185 550 minecraft:blackstone
fill 120 185 549 123 185 549 minecraft:blackstone
setblock 121 185 511 minecraft:blackstone
setblock 121 185 512 minecraft:smooth_basalt
fill 121 185 513 121 188 513 minecraft:blackstone
setblock 122 185 511 minecraft:smooth_basalt
fill 122 185 512 122 188 512 minecraft:blackstone
setblock 122 185 551 minecraft:smooth_basalt
fill 123 185 511 123 188 511 minecraft:blackstone
setblock 123 185 550 minecraft:smooth_basalt
fill 123 185 551 123 188 551 minecraft:blackstone
setblock 124 185 513 minecraft:blackstone
setblock 124 185 549 minecraft:smooth_basalt
fill 124 185 550 124 188 550 minecraft:blackstone
fill 125 185 549 125 188 549 minecraft:blackstone
setblock 126 185 512 minecraft:smooth_basalt
setblock 127 185 511 minecraft:smooth_basalt
fill 127 185 512 127 187 512 minecraft:blackstone
setblock 127 185 550 minecraft:blackstone
setblock 127 185 551 minecraft:smooth_basalt
fill 128 185 511 128 188 511 minecraft:blackstone
setblock 128 185 550 minecraft:smooth_basalt
fill 128 185 551 131 185 551 minecraft:blackstone
fill 129 185 550 132 185 550 minecraft:blackstone
setblock 132 185 511 minecraft:smooth_basalt
setblock 132 185 551 minecraft:smooth_basalt
fill 133 185 511 133 188 511 minecraft:blackstone
fill 133 185 548 134 185 548 minecraft:blackstone
setblock 133 185 550 minecraft:smooth_basalt
fill 133 185 551 133 188 551 minecraft:blackstone
setblock 134 185 543 minecraft:blackstone
setblock 134 185 544 minecraft:smooth_basalt
fill 134 185 545 134 186 547 minecraft:blackstone
setblock 134 185 549 minecraft:smooth_basalt
fill 134 185 550 134 188 550 minecraft:blackstone
setblock 135 185 512 minecraft:blackstone
setblock 135 185 523 minecraft:smooth_basalt
fill 135 185 524 135 188 524 minecraft:blackstone
setblock 135 185 528 minecraft:smooth_basalt
setblock 135 185 543 minecraft:smooth_basalt
fill 135 185 544 135 188 544 minecraft:blackstone
setblock 135 185 548 minecraft:smooth_basalt
fill 135 185 549 135 188 549 minecraft:blackstone
setblock 95 186 521 minecraft:blackstone
setblock 95 186 522 minecraft:smooth_basalt
fill 95 186 523 95 189 523 minecraft:blackstone
setblock 95 186 526 minecraft:blackstone
setblock 95 186 527 minecraft:smooth_basalt
fill 95 186 528 95 189 528 minecraft:blackstone
setblock 95 186 532 minecraft:smooth_basalt
fill 95 186 533 96 188 533 minecraft:blackstone
setblock 95 186 537 minecraft:smooth_basalt
fill 95 186 538 95 189 538 minecraft:blackstone
setblock 95 186 542 minecraft:smooth_basalt
fill 95 186 543 95 189 543 minecraft:blackstone
setblock 95 186 547 minecraft:smooth_basalt
fill 95 186 548 95 186 551 minecraft:blackstone
setblock 96 186 511 minecraft:smooth_basalt
setblock 96 186 526 minecraft:smooth_basalt
fill 96 186 527 96 189 527 minecraft:blackstone
setblock 96 186 530 minecraft:blackstone
setblock 96 186 531 minecraft:smooth_basalt
fill 96 186 532 96 189 532 minecraft:blackstone
fill 96 186 534 96 186 535 minecraft:blackstone
setblock 96 186 536 minecraft:smooth_basalt
fill 96 186 537 96 189 537 minecraft:blackstone
setblock 96 186 541 minecraft:smooth_basalt
fill 96 186 542 96 189 542 minecraft:blackstone
setblock 96 186 546 minecraft:smooth_basalt
fill 96 186 547 96 189 547 minecraft:blackstone
fill 96 186 549 96 186 550 minecraft:blackstone
setblock 96 186 551 minecraft:smooth_basalt
fill 97 186 511 100 186 511 minecraft:blackstone
setblock 97 186 525 minecraft:smooth_basalt
fill 97 186 526 97 189 526 minecraft:blackstone
setblock 97 186 529 minecraft:blackstone
setblock 97 186 530 minecraft:smooth_basalt
fill 97 186 531 97 189 531 minecraft:blackstone
setblock 97 186 540 minecraft:smooth_basalt
fill 97 186 541 97 187 541 minecraft:blackstone
setblock 97 186 544 minecraft:blackstone
setblock 97 186 545 minecraft:smooth_basalt
fill 97 186 546 97 189 546 minecraft:blackstone
setblock 97 186 549 minecraft:blackstone
setblock 97 186 550 minecraft:smooth_basalt
fill 97 186 551 97 189 551 minecraft:blackstone
setblock 98 186 544 minecraft:smooth_basalt
fill 98 186 545 98 187 545 minecraft:blackstone
setblock 98 186 548 minecraft:blackstone
setblock 98 186 549 minecraft:smooth_basalt
fill 98 186 550 98 189 550 minecraft:blackstone
setblock 99 186 548 minecraft:smooth_basalt
fill 99 186 549 99 189 549 minecraft:blackstone
fill 100 186 548 100 187 548 minecraft:blackstone
setblock 101 186 511 minecraft:smooth_basalt
setblock 101 186 551 minecraft:smooth_basalt
fill 102 186 511 102 189 511 minecraft:blackstone
setblock 102 186 550 minecraft:smooth_basalt
fill 102 186 551 102 189 551 minecraft:blackstone
setblock 103 186 549 minecraft:smooth_basalt
fill 103 186 550 103 189 550 minecraft:blackstone
setblock 104 186 549 minecraft:blackstone
setblock 106 186 551 minecraft:smooth_basalt
fill 107 186 551 108 186 551 minecraft:blackstone
fill 114 186 511 115 186 511 minecraft:blackstone
fill 114 186 551 115 186 551 minecraft:blackstone
setblock 116 186 511 minecraft:smooth_basalt
setblock 116 186 550 minecraft:blackstone
setblock 116 186 551 minecraft:smooth_basalt
fill 117 186 511 117 188 512 minecraft:blackstone
setblock 117 186 550 minecraft:smooth_basalt
fill 117 186 551 120 186 551 minecraft:blackstone
fill 118 186 550 121 186 550 minecraft:blackstone
fill 119 186 549 122 186 549 minecraft:blackstone
setblock 120 186 511 minecraft:blackstone
setblock 120 186 512 minecraft:smooth_basalt
fill 120 186 513 120 189 513 minecraft:blackstone
setblock 121 186 511 minecraft:smooth_basalt
fill 121 186 512 121 189 512 minecraft:blackstone
setblock 121 186 551 minecraft:smooth_basalt
fill 122 186 511 122 189 511 minecraft:blackstone
setblock 122 186 550 minecraft:smooth_basalt
fill 122 186 551 122 189 551 minecraft:blackstone
setblock 123 186 549 minecraft:smooth_basalt
fill 123 186 550 123 189 550 minecraft:blackstone
setblock 124 186 513 minecraft:smooth_basalt
fill 124 186 549 124 189 549 minecraft:blackstone
setblock 125 186 512 minecraft:smooth_basalt
setblock 126 186 511 minecraft:smooth_basalt
fill 126 186 512 126 189 512 minecraft:blackstone
setblock 126 186 551 minecraft:smooth_basalt
fill 127 186 511 127 189 511 minecraft:blackstone
setblock 127 186 550 minecraft:smooth_basalt
fill 127 186 551 130 186 551 minecraft:blackstone
setblock 128 186 549 minecraft:smooth_basalt
fill 128 186 550 131 186 550 minecraft:blackstone
setblock 130 186 511 minecraft:blackstone
setblock 131 186 511 minecraft:smooth_basalt
setblock 131 186 551 minecraft:smooth_basalt
fill 132 186 511 132 189 511 minecraft:blackstone
setblock 132 186 550 minecraft:smooth_basalt
fill 132 186 551 132 189 551 minecraft:blackstone
fill 133 186 547 133 186 548 minecraft:blackstone
setblock 133 186 549 minecraft:smooth_basalt
fill 133 186 550 133 189 550 minecraft:blackstone
setblock 134 186 543 minecraft:smooth_basalt
fill 134 186 544 134 189 544 minecraft:blackstone
setblock 134 186 548 minecraft:smooth_basalt
fill 134 186 549 134 189 549 minecraft:blackstone
setblock 135 186 512 minecraft:smooth_basalt
setblock 135 186 522 minecraft:smooth_basalt
fill 135 186 523 135 188 523 minecraft:blackstone
fill 135 186 525 135 186 526 minecraft:blackstone
setblock 135 186 527 minecraft:smooth_basalt
fill 135 186 528 135 187 530 minecraft:blackstone
setblock 135 186 542 minecraft:smooth_basalt
fill 135 186 543 135 189 543 minecraft:blackstone
setblock 135 186 547 minecraft:smooth_basalt
fill 135 186 548 135 189 548 minecraft:blackstone
setblock 95 187 511 minecraft:smooth_basalt
fill 95 187 522 95 188 522 minecraft:blackstone
setblock 95 187 525 minecraft:blackstone
setblock 95 187 526 minecraft:smooth_basalt
fill 95 187 527 95 190 527 minecraft:blackstone
setblock 95 187 530 minecraft:blackstone
setblock 95 187 531 minecraft:smooth_basalt
fill 95 187 532 95 190 532 minecraft:blackstone
fill 95 187 534 95 187 535 minecraft:blackstone
setblock 95 187 536 minecraft:smooth_basalt
fill 95 187 537 95 190 537 minecraft:blackstone
setblock 95 187 541 minecraft:smooth_basalt
fill 95 187 542 95 190 542 minecraft:blackstone
setblock 95 187 546 minecraft:smooth_basalt
fill 95 187 547 95 187 550 minecraft:blackstone
setblock 95 187 551 minecraft:smooth_basalt
fill 96 187 511 99 187 511 minecraft:blackstone
setblock 96 187 525 minecraft:smooth_basalt
fill 96 187 526 96 190 526 minecraft:blackstone
setblock 96 187 530 minecraft:smooth_basalt
fill 96 187 531 96 190 531 minecraft:blackstone
setblock 96 187 534 minecraft:blackstone
setblock 96 187 535 minecraft:smooth_basalt
fill 96 187 536 96 190 536 minecraft:blackstone
setblock 96 187 540 minecraft:smooth_basalt
fill 96 187 541 96 190 541 minecraft:blackstone
setblock 96 187 545 minecraft:smooth_basalt
fill 96 187 546 96 190 546 minecraft:blackstone
setblock 96 187 549 minecraft:blackstone
setblock 96 187 550 minecraft:smooth_basalt
fill 96 187 551 96 190 551 minecraft:blackstone
fill 97 187 525 97 189 525 minecraft:blackstone
setblock 97 187 529 minecraft:smooth_basalt
fill 97 187 530 98 189 530 minecraft:blackstone
fill 97 187 532 97 187 533 minecraft:blackstone
setblock 97 187 543 minecraft:blackstone
setblock 97 187 544 minecraft:smooth_basalt
fill 97 187 545 97 189 545 minecraft:blackstone
setblock 97 187 549 minecraft:smooth_basalt
fill 97 187 550 97 190 550 minecraft:blackstone
setblock 98 187 527 minecraft:blackstone
setblock 98 187 528 minecraft:smooth_basalt
fill 98 187 529 98 190 529 minecraft:blackstone
setblock 98 187 544 minecraft:blackstone
setblock 98 187 548 minecraft:smooth_basalt
fill 98 187 549 98 190 549 minecraft:blackstone
fill 99 187 548 99 188 548 minecraft:blackstone
setblock 100 187 511 minecraft:smooth_basalt
setblock 100 187 551 minecraft:smooth_basalt
fill 101 187 511 101 190 511 minecraft:blackstone
setblock 101 187 550 minecraft:smooth_basalt
fill 101 187 551 101 190 551 minecraft:blackstone
setblock 102 187 549 minecraft:smooth_basalt
fill 102 187 550 102 190 550 minecraft:blackstone
setblock 103 187 549 minecraft:blackstone
setblock 105 187 550 minecraft:blackstone
setblock 105 187 551 minecraft:smooth_basalt
fill 106 187 551 107 188 551 minecraft:blackstone
fill 113 187 511 114 187 511 minecraft:blackstone
fill 113 187 551 114 187 551 minecraft:blackstone
setblock 115 187 511 minecraft:smooth_basalt
setblock 115 187 551 minecraft:smooth_basalt
fill 116 187 511 116 189 512 minecraft:blackstone
setblock 116 187 550 minecraft:smooth_basalt
fill 116 187 551 119 187 551 minecraft:blackstone
fill 117 187 550 120 187 550 minecraft:blackstone
fill 118 187 549 121 187 549 minecraft:blackstone
setblock 119 187 511 minecraft:blackstone
setblock 119 187 512 minecraft:smooth_basalt
fill 119 187 513 119 190 513 minecraft:blackstone
setblock 120 187 511 minecraft:smooth_basalt
fill 120 187 512 120 190 512 minecraft:blackstone
setblock 120 187 551 minecraft:smooth_basalt
fill 121 187 511 121 190 511 minecraft:blackstone
setblock 121 187 550 minecraft:smooth_basalt
fill 121 187 551 121 190 551 minecraft:blackstone
setblock 122 187 513 minecraft:blackstone
setblock 122 187 549 minecraft:smooth_basalt
fill 122 187 550 122 190 550 minecraft:blackstone
setblock 123 187 513 minecraft:smooth_basalt
fill 123 187 549 123 189 549 minecraft:blackstone
setblock 124 187 512 minecraft:smooth_basalt
setblock 125 187 511 minecraft:smooth_basalt
fill 125 187 512 125 190 512 minecraft:blackstone
setblock 125 187 551 minecraft:smooth_basalt
fill 126 187 511 126 190 511 minecraft:blackstone
setblock 126 187 549 minecraft:blackstone
setblock 126 187 550 minecraft:smooth_basalt
fill 126 187 551 129 187 551 minecraft:blackstone
setblock 127 187 549 minecraft:smooth_basalt
fill 127 187 550 130 187 550 minecraft:blackstone
setblock 130 187 511 minecraft:smooth_basalt
setblock 130 187 551 minecraft:smooth_basalt
fill 131 187 511 131 190 511 minecraft:blackstone
setblock 131 187 550 minecraft:smooth_basalt
fill 131 187 551 131 190 551 minecraft:blackstone
setblock 132 187 549 minecraft:smooth_basalt
fill 132 187 550 132 190 550 minecraft:blackstone
setblock 133 187 547 minecraft:blackstone
setblock 133 187 548 minecraft:smooth_basalt
fill 133 187 549 133 190 549 minecraft:blackstone
setblock 134 187 511 minecraft:blackstone
setblock 134 187 543 minecraft:blackstone
fill 134 187 545 134 187 546 minecraft:blackstone
setblock 134 187 547 minecraft:smooth_basalt
fill 134 187 548 134 190 548 minecraft:blackstone
setblock 135 187 511 minecraft:smooth_basalt
fill 135 187 512 135 189 513 minecraft:blackstone
setblock 135 187 522 minecraft:blackstone
setblock 135 187 525 minecraft:blackstone
setblock 135 187 526 minecraft:smooth_basalt
fill 135 187 527 135 190 527 minecraft:blackstone
setblock 135 187 531 minecraft:smooth_basalt
fill 135 187 532 135 190 532 minecraft:blackstone
fill 135 187 539 135 188 539 minecraft:blackstone
setblock 135 187 541 minecraft:smooth_basalt
fill 135 187 542 135 190 542 minecraft:blackstone
setblock 135 187 546 minecraft:smooth_basalt
fill 135 187 547 135 190 547 minecraft:blackstone
setblock 135 187 551 minecraft:smooth_basalt
fill 95 188 511 98 188 511 minecraft:blackstone
setblock 95 188 525 minecraft:smooth_basalt
fill 95 188 526 95 191 526 minecraft:blackstone
setblock 95 188 529 minecraft:blackstone
setblock 95 188 530 minecraft:smooth_basalt
fill 95 188 531 95 191 531 minecraft:blackstone
setblock 95 188 534 minecraft:blackstone
setblock 95 188 535 minecraft:smooth_basalt
fill 95 188 536 95 191 536 minecraft:blackstone
setblock 95 188 540 minecraft:smooth_basalt
fill 95 188 541 95 191 541 minecraft:blackstone
setblock 95 188 545 minecraft:smooth_basalt
fill 95 188 546 95 188 549 minecraft:blackstone
setblock 95 188 550 minecraft:smooth_basalt
fill 95 188 551 95 191 551 minecraft:blackstone
setblock 96 188 524 minecraft:smooth_basalt
fill 96 188 525 96 191 525 minecraft:blackstone
setblock 96 188 528 minecraft:blackstone
setblock 96 188 529 minecraft:smooth_basalt
fill 96 188 530 96 191 530 minecraft:blackstone
setblock 96 188 534 minecraft:smooth_basalt
fill 96 188 535 96 191 535 minecraft:blackstone
setblock 96 188 539 minecraft:smooth_basalt
fill 96 188 540 96 191 540 minecraft:blackstone
setblock 96 188 544 minecraft:smooth_basalt
fill 96 188 545 96 191 545 minecraft:blackstone
setblock 96 188 549 minecraft:smooth_basalt
fill 96 188 550 96 191 550 minecraft:blackstone
setblock 97 188 528 minecraft:smooth_basalt
fill 97 188 529 97 191 529 minecraft:blackstone
setblock 97 188 532 minecraft:blackstone
setblock 97 188 533 minecraft:smooth_basalt
fill 97 188 534 97 191 534 minecraft:blackstone
setblock 97 188 543 minecraft:smooth_basalt
fill 97 188 544 97 189 544 minecraft:blackstone
setblock 97 188 548 minecraft:smooth_basalt
fill 97 188 549 97 191 549 minecraft:blackstone
setblock 98 188 527 minecraft:smooth_basalt
fill 98 188 528 98 190 528 minecraft:blackstone
setblock 98 188 531 minecraft:blackstone
setblock 98 188 547 minecraft:smooth_basalt
setblock 98 188 548 minecraft:blackstone
setblock 99 188 511 minecraft:smooth_basalt
setblock 99 188 551 minecraft:smooth_basalt
fill 100 188 511 100 191 511 minecraft:blackstone
setblock 100 188 550 minecraft:smooth_basalt
fill 100 188 551 100 191 551 minecraft:blackstone
setblock 101 188 549 minecraft:smooth_basalt
fill 101 188 550 101 191 550 minecraft:blackstone
setblock 102 188 549 minecraft:blackstone
setblock 104 188 511 minecraft:smooth_basalt
setblock 104 188 551 minecraft:smooth_basalt
fill 105 188 551 105 190 551 minecraft:blackstone
setblock 113 188 511 minecraft:blackstone
setblock 113 188 551 minecraft:blackstone
setblock 114 188 511 minecraft:smooth_basalt
setblock 114 188 551 minecraft:smooth_basalt
fill 115 188 511 115 190 512 minecraft:blackstone
setblock 115 188 550 minecraft:smooth_basalt
fill 115 188 551 118 188 551 minecraft:blackstone
fill 116 188 550 119 188 550 minecraft:blackstone
setblock 118 188 511 minecraft:blackstone
setblock 118 188 512 minecraft:smooth_basalt
fill 118 188 513 118 191 513 minecraft:blackstone
fill 118 188 549 120 188 549 minecraft:blackstone
setblock 119 188 511 minecraft:smooth_basalt
fill 119 188 512 119 191 512 minecraft:blackstone
setblock 119 188 551 minecraft:smooth_basalt
fill 120 188 511 120 191 511 minecraft:blackstone
setblock 120 188 550 minecraft:smooth_basalt
fill 120 188 551 120 191 551 minecraft:blackstone
setblock 121 188 549 minecraft:smooth_basalt
fill 121 188 550 121 191 550 minecraft:blackstone
setblock 122 188 513 minecraft:smooth_basalt
fill 122 188 549 122 190 549 minecraft:blackstone
setblock 123 188 512 minecraft:smooth_basalt
setblock 123 188 513 minecraft:blackstone
setblock 124 188 511 minecraft:smooth_basalt
fill 124 188 512 124 191 512 minecraft:blackstone
setblock 124 188 551 minecraft:smooth_basalt
fill 125 188 511 125 191 511 minecraft:blackstone
setblock 125 188 550 minecraft:smooth_basalt
fill 125 188 551 128 188 551 minecraft:blackstone
setblock 126 188 549 minecraft:smooth_basalt
fill 126 188 550 129 188 550 minecraft:blackstone
setblock 129 188 511 minecraft:smooth_basalt
setblock 129 188 551 minecraft:smooth_basalt
fill 130 188 511 130 191 511 minecraft:blackstone
setblock 130 188 550 minecraft:smooth_basalt
fill 130 188 551 130 191 551 minecraft:blackstone
fill 131 188 550 131 191 550 minecraft:blackstone
setblock 132 188 549 minecraft:blackstone
setblock 133 188 547 minecraft:smooth_basalt
fill 133 188 548 133 189 548 minecraft:blackstone
setblock 134 188 511 minecraft:smooth_basalt
setblock 134 188 545 minecraft:blackstone
setblock 134 188 546 minecraft:smooth_basalt
fill 134 188 547 134 191 547 minecraft:blackstone
setblock 134 188 551 minecraft:smooth_basalt
fill 135 188 511 135 191 511 minecraft:blackstone
setblock 135 188 525 minecraft:smooth_basalt
fill 135 188 526 135 191 526 minecraft:blackstone
fill 135 188 528 135 188 529 minecraft:blackstone
setblock 135 188 530 minecraft:smooth_basalt
fill 135 188 531 135 191 531 minecraft:blackstone
fill 135 188 533 135 188 534 minecraft:blackstone
setblock 135 188 540 minecraft:smooth_basalt
fill 135 188 541 135 191 541 minecraft:blackstone
setblock 135 188 545 minecraft:smooth_basalt
fill 135 188 546 135 191 546 minecraft:blackstone
setblock 135 188 550 minecraft:smooth_basalt
fill 135 188 551 135 191 551 minecraft:blackstone
fill 95 189 511 97 189 511 minecraft:blackstone
setblock 95 189 524 minecraft:smooth_basalt
fill 95 189 525 95 192 525 minecraft:blackstone
setblock 95 189 529 minecraft:smooth_basalt
fill 95 189 530 95 192 530 minecraft:blackstone
setblock 95 189 533 minecraft:blackstone
setblock 95 189 534 minecraft:smooth_basalt
fill 95 189 535 95 192 535 minecraft:blackstone
setblock 95 189 539 minecraft:smooth_basalt
fill 95 189 540 95 192 540 minecraft:blackstone
setblock 95 189 544 minecraft:smooth_basalt
fill 95 189 545 95 189 548 minecraft:blackstone
setblock 95 189 549 minecraft:smooth_basalt
fill 95 189 550 95 192 550 minecraft:blackstone
fill 96 189 524 96 190 524 minecraft:blackstone
setblock 96 189 528 minecraft:smooth_basalt
fill 96 189 529 96 192 529 minecraft:blackstone
setblock 96 189 533 minecraft:smooth_basalt
fill 96 189 534 96 192 534 minecraft:blackstone
setblock 96 189 538 minecraft:smooth_basalt
fill 96 189 539 96 192 539 minecraft:blackstone
setblock 96 189 543 minecraft:smooth_basalt
fill 96 189 544 96 192 544 minecraft:blackstone
setblock 96 189 548 minecraft:smooth_basalt
fill 96 189 549 96 192 549 minecraft:blackstone
setblock 97 189 513 minecraft:light[level=12]
setblock 97 189 521 minecraft:light[level=12]
setblock 97 189 527 minecraft:smooth_basalt
fill 97 189 528 97 192 528 minecraft:blackstone
setblock 97 189 532 minecraft:smooth_basalt
fill 97 189 533 97 192 533 minecraft:blackstone
fill 97 189 535 97 190 535 minecraft:blackstone
setblock 97 189 537 minecraft:light[level=12]
setblock 97 189 547 minecraft:smooth_basalt
fill 97 189 548 97 191 548 minecraft:blackstone
setblock 98 189 511 minecraft:smooth_basalt
setblock 98 189 527 minecraft:blackstone
setblock 98 189 531 minecraft:smooth_basalt
fill 98 189 532 98 192 532 minecraft:blackstone
setblock 98 189 551 minecraft:smooth_basalt
fill 99 189 511 99 192 511 minecraft:blackstone
setblock 99 189 550 minecraft:smooth_basalt
fill 99 189 551 99 192 551 minecraft:blackstone
setblock 100 189 549 minecraft:smooth_basalt
fill 100 189 550 100 192 550 minecraft:blackstone
setblock 101 189 549 minecraft:blackstone
setblock 103 189 511 minecraft:smooth_basalt
setblock 103 189 551 minecraft:smooth_basalt
setblock 104 189 511 minecraft:blackstone
fill 104 189 551 104 190 551 minecraft:blackstone
setblock 105 189 513 minecraft:light[level=12]
setblock 105 189 521 minecraft:light[level=12]
setblock 105 189 529 minecraft:light[level=12]
setblock 105 189 537 minecraft:light[level=12]
setblock 105 189 545 minecraft:light[level=12]
fill 106 189 524 107 190 525 minecraft:gilded_blackstone
setblock 106 189 551 minecraft:blackstone
setblock 112 189 511 minecraft:blackstone
setblock 113 189 511 minecraft:smooth_basalt
setblock 113 189 513 minecraft:light[level=12]
setblock 113 189 521 minecraft:light[level=12]
setblock 113 189 529 minecraft:light[level=12]
setblock 113 189 537 minecraft:light[level=12]
setblock 113 189 545 minecraft:light[level=12]
setblock 113 189 551 minecraft:smooth_basalt
fill 114 189 511 114 192 511 minecraft:blackstone
fill 114 189 551 117 189 551 minecraft:blackstone
fill 115 189 550 118 189 550 minecraft:blackstone
setblock 117 189 511 minecraft:blackstone
setblock 117 189 512 minecraft:smooth_basalt
setblock 118 189 511 minecraft:smooth_basalt
fill 118 189 512 118 192 512 minecraft:blackstone
fill 118 189 549 119 189 549 minecraft:blackstone
setblock 118 189 551 minecraft:smooth_basalt
fill 119 189 511 119 192 511 minecraft:blackstone
setblock 119 189 550 minecraft:smooth_basalt
fill 119 189 551 119 192 551 minecraft:blackstone
setblock 120 189 549 minecraft:smooth_basalt
fill 120 189 550 120 192 550 minecraft:blackstone
setblock 121 189 513 minecraft:smooth_basalt
setblock 121 189 521 minecraft:light[level=12]
setblock 121 189 529 minecraft:light[level=12]
setblock 121 189 537 minecraft:light[level=12]
setblock 121 189 545 minecraft:light[level=12]
fill 121 189 549 121 190 549 minecraft:blackstone
setblock 122 189 512 minecraft:smooth_basalt
setblock 122 189 513 minecraft:blackstone
setblock 123 189 511 minecraft:smooth_basalt
fill 123 189 512 123 192 512 minecraft:blackstone
setblock 123 189 551 minecraft:smooth_basalt
fill 124 189 511 124 192 511 minecraft:blackstone
setblock 124 189 550 minecraft:smooth_basalt
fill 124 189 551 127 189 551 minecraft:blackstone
fill 125 189 550 128 189 550 minecraft:blackstone
setblock 128 189 511 minecraft:smooth_basalt
setblock 128 189 551 minecraft:smooth_basalt
fill 129 189 511 129 192 511 minecraft:blackstone
setblock 129 189 513 minecraft:light[level=12]
setblock 129 189 521 minecraft:light[level=12]
setblock 129 189 529 minecraft:light[level=12]
setblock 129 189 537 minecraft:light[level=12]
setblock 129 189 545 minecraft:light[level=12]
setblock 129 189 550 minecraft:smooth_basalt
fill 129 189 551 129 192 551 minecraft:blackstone
fill 130 189 550 130 192 550 minecraft:blackstone
setblock 133 189 511 minecraft:smooth_basalt
setblock 133 189 551 minecraft:smooth_basalt
fill 134 189 511 134 192 511 minecraft:blackstone
setblock 134 189 545 minecraft:smooth_basalt
fill 134 189 546 134 192 546 minecraft:blackstone
setblock 134 189 550 minecraft:smooth_basalt
fill 134 189 551 134 192 551 minecraft:blackstone
setblock 135 189 524 minecraft:smooth_basalt
fill 135 189 525 135 190 525 minecraft:blackstone
setblock 135 189 528 minecraft:blackstone
setblock 135 189 529 minecraft:smooth_basalt
fill 135 189 530 135 192 530 minecraft:blackstone
setblock 135 189 533 minecraft:blackstone
setblock 135 189 534 minecraft:smooth_basalt
fill 135 189 535 135 191 536 minecraft:blackstone
setblock 135 189 539 minecraft:smooth_basalt
fill 135 189 540 135 192 540 minecraft:blackstone
setblock 135 189 544 minecraft:smooth_basalt
fill 135 189 545 135 192 545 minecraft:blackstone
setblock 135 189 549 minecraft:smooth_basalt
fill 135 189 550 135 192 550 minecraft:blackstone
fill 95 190 511 95 190 512 minecraft:blackstone
setblock 95 190 523 minecraft:smooth_basalt
fill 95 190 524 95 193 524 minecraft:blackstone
setblock 95 190 528 minecraft:smooth_basalt
fill 95 190 529 95 193 529 minecraft:blackstone
setblock 95 190 533 minecraft:smooth_basalt
fill 95 190 534 95 193 534 minecraft:blackstone
setblock 95 190 538 minecraft:smooth_basalt
fill 95 190 539 95 193 539 minecraft:blackstone
setblock 95 190 543 minecraft:smooth_basalt
fill 95 190 544 95 190 547 minecraft:blackstone
setblock 95 190 548 minecraft:smooth_basalt
fill 95 190 549 95 193 549 minecraft:blackstone
setblock 96 190 511 minecraft:blackstone
setblock 96 190 527 minecraft:smooth_basalt
fill 96 190 528 96 193 528 minecraft:blackstone
setblock 96 190 532 minecraft:smooth_basalt
fill 96 190 533 96 193 533 minecraft:blackstone
setblock 96 190 537 minecraft:smooth_basalt
fill 96 190 538 96 193 538 minecraft:blackstone
setblock 96 190 542 minecraft:smooth_basalt
fill 96 190 543 96 191 543 minecraft:blackstone
setblock 96 190 547 minecraft:smooth_basalt
fill 96 190 548 96 193 548 minecraft:blackstone
setblock 97 190 511 minecraft:smooth_basalt
setblock 97 190 526 minecraft:smooth_basalt
fill 97 190 527 97 193 527 minecraft:blackstone
setblock 97 190 530 minecraft:blackstone
setblock 97 190 531 minecraft:smooth_basalt
fill 97 190 532 97 193 532 minecraft:blackstone
setblock 97 190 546 minecraft:smooth_basalt
setblock 97 190 547 minecraft:blackstone
setblock 97 190 551 minecraft:smooth_basalt
fill 98 190 511 98 193 511 minecraft:blackstone
setblock 98 190 530 minecraft:smooth_basalt
fill 98 190 531 98 193 531 minecraft:blackstone
setblock 98 190 550 minecraft:smooth_basalt
fill 98 190 551 98 193 551 minecraft:blackstone
setblock 99 190 549 minecraft:smooth_basalt
fill 99 190 550 99 193 550 minecraft:blackstone
setblock 100 190 549 minecraft:blackstone
setblock 102 190 511 minecraft:smooth_basalt
setblock 102 190 551 minecraft:smooth_basalt
fill 103 190 511 103 191 511 minecraft:blackstone
fill 103 190 551 103 191 551 minecraft:blackstone
setblock 111 190 511 minecraft:blackstone
setblock 112 190 511 minecraft:smooth_basalt
setblock 112 190 551 minecraft:smooth_basalt
fill 113 190 511 113 193 511 minecraft:blackstone
fill 113 190 551 116 190 551 minecraft:blackstone
fill 114 190 512 114 191 512 minecraft:blackstone
fill 115 190 550 117 190 550 minecraft:blackstone
setblock 116 190 511 minecraft:blackstone
setblock 116 190 512 minecraft:smooth_basalt
setblock 117 190 511 minecraft:smooth_basalt
fill 117 190 512 117 192 513 minecraft:blackstone
setblock 117 190 551 minecraft:smooth_basalt
fill 118 190 511 118 193 511 minecraft:blackstone
setblock 118 190 550 minecraft:smooth_basalt
fill 118 190 551 118 193 551 minecraft:blackstone
setblock 119 190 549 minecraft:smooth_basalt
fill 119 190 550 119 193 550 minecraft:blackstone
setblock 120 190 513 minecraft:smooth_basalt
setblock 120 190 549 minecraft:blackstone
setblock 121 190 512 minecraft:smooth_basalt
fill 121 190 513 121 193 513 minecraft:blackstone
setblock 122 190 511 minecraft:smooth_basalt
fill 122 190 512 122 193 512 minecraft:blackstone
setblock 122 190 551 minecraft:smooth_basalt
fill 123 190 511 123 193 511 minecraft:blackstone
setblock 123 190 550 minecraft:smooth_basalt
fill 123 190 551 126 190 551 minecraft:blackstone
fill 124 190 550 127 190 550 minecraft:blackstone
setblock 127 190 511 minecraft:smooth_basalt
setblock 127 190 551 minecraft:smooth_basalt
fill 128 190 511 128 193 511 minecraft:blackstone
setblock 128 190 550 minecraft:smooth_basalt
fill 128 190 551 128 193 551 minecraft:blackstone
fill 129 190 550 129 192 550 minecraft:blackstone
setblock 132 190 511 minecraft:smooth_basalt
setblock 132 190 551 minecraft:smooth_basalt
fill 133 190 511 133 193 511 minecraft:blackstone
setblock 133 190 550 minecraft:smooth_basalt
fill 133 190 551 133 193 551 minecraft:blackstone
fill 134 190 545 134 192 545 minecraft:blackstone
setblock 134 190 549 minecraft:smooth_basalt
fill 134 190 550 134 193 550 minecraft:blackstone
setblock 135 190 512 minecraft:blackstone
setblock 135 190 513 minecraft:smooth_basalt
setblock 135 190 528 minecraft:smooth_basalt
fill 135 190 529 135 193 529 minecraft:blackstone
setblock 135 190 533 minecraft:smooth_basalt
fill 135 190 534 135 193 534 minecraft:blackstone
setblock 135 190 537 minecraft:blackstone
setblock 135 190 538 minecraft:smooth_basalt
fill 135 190 539 135 193 539 minecraft:blackstone
setblock 135 190 543 minecraft:smooth_basalt
fill 135 190 544 135 193 544 minecraft:blackstone
setblock 135 190 548 minecraft:smooth_basalt
fill 135 190 549 135 193 549 minecraft:blackstone
setblock 95 191 511 minecraft:blackstone
setblock 95 191 512 minecraft:smooth_basalt
setblock 95 191 523 minecraft:blackstone
setblock 95 191 527 minecraft:smooth_basalt
fill 95 191 528 95 194 528 minecraft:blackstone
setblock 95 191 532 minecraft:smooth_basalt
fill 95 191 533 95 194 533 minecraft:blackstone
setblock 95 191 537 minecraft:smooth_basalt
fill 95 191 538 95 194 538 minecraft:blackstone
setblock 95 191 542 minecraft:smooth_basalt
fill 95 191 543 95 191 546 minecraft:blackstone
setblock 95 191 547 minecraft:smooth_basalt
fill 95 191 548 95 194 548 minecraft:blackstone
setblock 96 191 511 minecraft:smooth_basalt
setblock 96 191 526 minecraft:smooth_basalt
fill 96 191 527 96 194 527 minecraft:blackstone
setblock 96 191 531 minecraft:smooth_basalt
fill 96 191 532 96 194 532 minecraft:blackstone
setblock 96 191 536 minecraft:smooth_basalt
fill 96 191 537 96 194 537 minecraft:blackstone
setblock 96 191 541 minecraft:smooth_basalt
setblock 96 191 542 minecraft:blackstone
setblock 96 191 546 minecraft:smooth_basalt
fill 96 191 547 96 194 547 minecraft:blackstone
setblock 96 191 551 minecraft:smooth_basalt
fill 97 191 511 97 194 511 minecraft:blackstone
setblock 97 191 526 minecraft:blackstone
setblock 97 191 530 minecraft:smooth_basalt
fill 97 191 531 97 194 531 minecraft:blackstone
setblock 97 191 535 minecraft:smooth_basalt
fill 97 191 536 97 194 536 minecraft:blackstone
setblock 97 191 550 minecraft:smooth_basalt
fill 97 191 551 97 194 551 minecraft:blackstone
setblock 98 191 529 minecraft:smooth_basalt
fill 98 191 530 98 194 530 minecraft:blackstone
setblock 98 191 549 minecraft:smooth_basalt
fill 98 191 550 98 194 550 minecraft:blackstone
setblock 101 191 511 minecraft:smooth_basalt
setblock 101 191 551 minecraft:smooth_basalt
fill 102 191 511 102 194 511 minecraft:blackstone
fill 102 191 551 102 193 551 minecraft:blackstone
setblock 111 191 511 minecraft:smooth_basalt
fill 112 191 511 112 194 511 minecraft:blackstone
fill 112 191 551 115 191 551 minecraft:blackstone
setblock 115 191 511 minecraft:blackstone
setblock 115 191 512 minecraft:smooth_basalt
fill 115 191 550 116 191 550 minecraft:blackstone
setblock 116 191 511 minecraft:smooth_basalt
fill 116 191 512 116 193 513 minecraft:blackstone
setblock 116 191 551 minecraft:smooth_basalt
fill 117 191 511 117 194 511 minecraft:blackstone
setblock 117 191 550 minecraft:smooth_basalt
fill 117 191 551 117 194 551 minecraft:blackstone
fill 118 191 550 118 194 550 minecraft:blackstone
setblock 119 191 513 minecraft:smooth_basalt
setblock 120 191 512 minecraft:smooth_basalt
fill 120 191 513 120 194 513 minecraft:blackstone
setblock 121 191 511 minecraft:smooth_basalt
fill 121 191 512 121 194 512 minecraft:blackstone
setblock 121 191 551 minecraft:smooth_basalt
fill 122 191 511 122 194 511 minecraft:blackstone
setblock 122 191 550 minecraft:smooth_basalt
fill 122 191 551 125 191 551 minecraft:blackstone
fill 123 191 550 126 191 550 minecraft:blackstone
setblock 125 191 512 minecraft:smooth_basalt
schedule function dropper:buildpart/122_8 1t
