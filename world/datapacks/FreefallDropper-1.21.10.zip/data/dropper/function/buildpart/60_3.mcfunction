setblock 17 145 283 minecraft:nether_wart_block
setblock 18 145 279 minecraft:red_nether_bricks
setblock 18 145 280 minecraft:nether_wart_block
setblock 18 145 282 minecraft:orange_terracotta
setblock 18 145 283 minecraft:red_nether_bricks
fill 19 145 280 21 145 280 minecraft:red_nether_bricks
fill 19 145 281 19 148 281 minecraft:bone_block
fill 19 145 282 19 147 282 minecraft:red_nether_bricks
fill 20 145 279 20 146 279 minecraft:red_nether_bricks
fill 20 145 281 22 145 281 minecraft:red_nether_bricks
setblock 20 145 282 minecraft:nether_wart_block
fill 20 145 283 20 146 283 minecraft:red_nether_bricks
setblock 21 145 279 minecraft:nether_wart_block
setblock 21 145 283 minecraft:nether_wart_block
fill 22 145 279 23 145 279 minecraft:red_nether_bricks
setblock 22 145 280 minecraft:nether_wart_block
setblock 22 145 283 minecraft:red_nether_bricks
setblock 23 145 281 minecraft:nether_wart_block
setblock 23 145 282 minecraft:red_nether_bricks
setblock 24 145 282 minecraft:nether_wart_block
fill 33 145 317 34 210 317 minecraft:blackstone
setblock 35 145 317 minecraft:amethyst_block
fill 42 145 278 42 217 278 minecraft:blackstone
setblock 42 145 279 minecraft:crying_obsidian
fill 42 145 280 42 217 282 minecraft:blackstone
setblock 42 145 310 minecraft:amethyst_block
fill 42 145 311 42 174 312 minecraft:blackstone
fill 12 146 283 14 148 283 minecraft:orange_terracotta
fill 13 146 282 14 147 282 minecraft:orange_terracotta
fill 13 146 284 13 148 284 minecraft:orange_terracotta
fill 14 146 281 14 147 281 minecraft:red_nether_bricks
setblock 14 146 284 minecraft:red_nether_bricks
setblock 15 146 280 minecraft:nether_wart_block
setblock 15 146 284 minecraft:nether_wart_block
fill 16 146 279 17 147 279 minecraft:red_nether_bricks
fill 16 146 283 16 146 284 minecraft:red_nether_bricks
fill 17 146 280 18 147 280 minecraft:red_nether_bricks
fill 17 146 283 17 148 283 minecraft:red_nether_bricks
setblock 18 146 279 minecraft:nether_wart_block
fill 18 146 281 18 146 282 minecraft:red_nether_bricks
setblock 18 146 283 minecraft:nether_wart_block
setblock 19 146 280 minecraft:nether_wart_block
fill 20 146 280 22 146 280 minecraft:red_nether_bricks
fill 20 146 281 20 148 281 minecraft:bone_block
fill 20 146 282 20 147 282 minecraft:red_nether_bricks
setblock 21 146 279 minecraft:red_nether_bricks
fill 21 146 281 23 146 281 minecraft:red_nether_bricks
setblock 21 146 282 minecraft:nether_wart_block
setblock 22 146 282 minecraft:red_nether_bricks
setblock 23 146 280 minecraft:nether_wart_block
fill 28 146 281 28 147 281 minecraft:raw_gold_block
fill 35 146 317 35 219 317 minecraft:blackstone
fill 42 146 279 42 219 279 minecraft:blackstone
fill 42 146 310 42 171 310 minecraft:blackstone
setblock 11 147 283 minecraft:nether_wart_block
setblock 11 147 284 minecraft:red_nether_bricks
fill 11 147 285 11 149 285 minecraft:orange_terracotta
fill 12 147 282 12 148 282 minecraft:red_nether_bricks
fill 12 147 284 12 148 284 minecraft:orange_terracotta
setblock 12 147 285 minecraft:red_nether_bricks
setblock 13 147 281 minecraft:nether_wart_block
setblock 13 147 285 minecraft:nether_wart_block
fill 14 147 280 15 148 280 minecraft:red_nether_bricks
setblock 14 147 284 minecraft:orange_terracotta
fill 15 147 281 16 147 282 minecraft:red_nether_bricks
setblock 15 147 283 minecraft:orange_terracotta
fill 15 147 284 15 149 284 minecraft:red_nether_bricks
setblock 16 147 280 minecraft:nether_wart_block
setblock 16 147 283 minecraft:red_nether_bricks
setblock 16 147 284 minecraft:nether_wart_block
setblock 17 147 281 minecraft:nether_wart_block
fill 17 147 282 17 149 282 minecraft:red_nether_bricks
setblock 17 147 284 minecraft:red_nether_bricks
setblock 18 147 279 minecraft:red_nether_bricks
setblock 18 147 281 minecraft:red_nether_bricks
setblock 18 147 282 minecraft:nether_wart_block
fill 18 147 283 18 148 283 minecraft:red_nether_bricks
setblock 19 147 279 minecraft:nether_wart_block
setblock 19 147 280 minecraft:red_nether_bricks
setblock 19 147 283 minecraft:nether_wart_block
setblock 20 147 280 minecraft:nether_wart_block
setblock 21 147 280 minecraft:red_nether_bricks
setblock 21 147 281 minecraft:nether_wart_block
setblock 42 147 293 minecraft:purple_concrete
fill 42 147 294 42 160 299 minecraft:blackstone
setblock 3 148 278 minecraft:light[level=12]
setblock 3 148 286 minecraft:light[level=12]
setblock 3 148 294 minecraft:light[level=12]
setblock 3 148 302 minecraft:light[level=12]
setblock 3 148 310 minecraft:light[level=12]
fill 10 148 283 11 149 283 minecraft:red_nether_bricks
fill 10 148 284 10 149 286 minecraft:orange_terracotta
setblock 11 148 278 minecraft:light[level=12]
setblock 11 148 282 minecraft:nether_wart_block
fill 11 148 284 11 149 284 minecraft:orange_terracotta
fill 11 148 286 11 149 286 minecraft:orange_terracotta
setblock 11 148 294 minecraft:light[level=12]
setblock 11 148 302 minecraft:light[level=12]
setblock 11 148 310 minecraft:light[level=12]
fill 12 148 281 13 149 281 minecraft:red_nether_bricks
fill 12 148 285 12 149 285 minecraft:orange_terracotta
setblock 12 148 286 minecraft:red_nether_bricks
fill 13 148 282 14 149 282 minecraft:red_nether_bricks
fill 13 148 285 13 150 285 minecraft:red_nether_bricks
setblock 14 148 281 minecraft:nether_wart_block
setblock 14 148 284 minecraft:red_nether_bricks
setblock 14 148 285 minecraft:nether_wart_block
fill 15 148 281 17 148 281 minecraft:red_nether_bricks
setblock 15 148 282 minecraft:nether_wart_block
fill 15 148 283 15 150 283 minecraft:red_nether_bricks
setblock 16 148 280 minecraft:red_nether_bricks
setblock 16 148 282 minecraft:red_nether_bricks
setblock 16 148 283 minecraft:nether_wart_block
setblock 16 148 284 minecraft:red_nether_bricks
setblock 17 148 280 minecraft:nether_wart_block
setblock 18 148 280 minecraft:red_nether_bricks
setblock 18 148 281 minecraft:nether_wart_block
setblock 18 148 282 minecraft:red_nether_bricks
setblock 19 148 278 minecraft:light[level=12]
setblock 19 148 282 minecraft:nether_wart_block
setblock 19 148 286 minecraft:light[level=12]
setblock 19 148 294 minecraft:light[level=12]
setblock 19 148 302 minecraft:light[level=12]
setblock 19 148 310 minecraft:light[level=12]
setblock 27 148 278 minecraft:light[level=12]
setblock 27 148 286 minecraft:light[level=12]
setblock 27 148 294 minecraft:light[level=12]
setblock 27 148 302 minecraft:light[level=12]
setblock 27 148 310 minecraft:light[level=12]
setblock 35 148 278 minecraft:light[level=12]
setblock 35 148 286 minecraft:light[level=12]
setblock 35 148 294 minecraft:light[level=12]
setblock 35 148 302 minecraft:light[level=12]
setblock 35 148 310 minecraft:light[level=12]
fill 42 148 293 42 164 293 minecraft:blackstone
setblock 8 149 285 minecraft:red_nether_bricks
setblock 8 149 286 minecraft:nether_wart_block
fill 8 149 287 9 151 288 minecraft:orange_terracotta
fill 9 149 284 9 151 284 minecraft:red_nether_bricks
fill 9 149 285 9 149 286 minecraft:orange_terracotta
fill 10 149 287 11 149 287 minecraft:red_nether_bricks
fill 11 149 282 11 150 282 minecraft:red_nether_bricks
setblock 12 149 282 minecraft:nether_wart_block
fill 12 149 283 12 150 284 minecraft:red_nether_bricks
setblock 12 149 286 minecraft:nether_wart_block
fill 13 149 283 13 152 283 minecraft:bone_block
fill 13 149 284 13 151 284 minecraft:red_nether_bricks
setblock 13 149 286 minecraft:red_nether_bricks
fill 14 149 281 14 150 281 minecraft:red_nether_bricks
setblock 14 149 283 minecraft:red_nether_bricks
setblock 14 149 284 minecraft:nether_wart_block
fill 14 149 285 14 150 285 minecraft:red_nether_bricks
setblock 15 149 280 minecraft:red_nether_bricks
setblock 15 149 281 minecraft:nether_wart_block
fill 15 149 282 15 150 282 minecraft:red_nether_bricks
fill 16 149 281 17 149 281 minecraft:red_nether_bricks
setblock 16 149 282 minecraft:nether_wart_block
setblock 16 149 283 minecraft:red_nether_bricks
setblock 3 150 278 minecraft:light[level=12]
setblock 3 150 285 minecraft:light[level=12]
setblock 3 150 292 minecraft:light[level=12]
setblock 3 150 299 minecraft:light[level=12]
setblock 3 150 306 minecraft:light[level=12]
setblock 3 150 313 minecraft:light[level=12]
fill 7 150 286 7 150 287 minecraft:red_nether_bricks
fill 7 150 288 7 151 289 minecraft:orange_terracotta
setblock 8 150 284 minecraft:red_nether_bricks
setblock 8 150 285 minecraft:nether_wart_block
fill 8 150 286 8 152 286 minecraft:red_nether_bricks
fill 8 150 289 8 151 289 minecraft:orange_terracotta
setblock 9 150 283 minecraft:red_nether_bricks
setblock 9 150 285 minecraft:red_nether_bricks
fill 9 150 286 10 150 286 minecraft:orange_terracotta
setblock 9 150 289 minecraft:red_nether_bricks
setblock 10 150 278 minecraft:light[level=12]
setblock 10 150 283 minecraft:nether_wart_block
fill 10 150 284 10 152 284 minecraft:red_nether_bricks
setblock 10 150 285 minecraft:orange_terracotta
setblock 10 150 287 minecraft:nether_wart_block
fill 10 150 288 10 152 288 minecraft:red_nether_bricks
setblock 10 150 292 minecraft:light[level=12]
setblock 10 150 299 minecraft:light[level=12]
setblock 10 150 306 minecraft:light[level=12]
setblock 10 150 313 minecraft:light[level=12]
setblock 11 150 283 minecraft:red_nether_bricks
setblock 11 150 284 minecraft:nether_wart_block
fill 11 150 285 11 150 287 minecraft:red_nether_bricks
fill 12 150 282 12 151 282 minecraft:red_nether_bricks
setblock 12 150 285 minecraft:nether_wart_block
fill 12 150 286 12 151 287 minecraft:red_nether_bricks
setblock 13 150 281 minecraft:red_nether_bricks
setblock 13 150 282 minecraft:nether_wart_block
setblock 13 150 286 minecraft:nether_wart_block
setblock 14 150 282 minecraft:red_nether_bricks
setblock 14 150 283 minecraft:nether_wart_block
setblock 14 150 284 minecraft:red_nether_bricks
setblock 15 150 284 minecraft:nether_wart_block
setblock 17 150 278 minecraft:light[level=12]
setblock 17 150 285 minecraft:light[level=12]
setblock 17 150 292 minecraft:light[level=12]
setblock 17 150 299 minecraft:light[level=12]
setblock 17 150 306 minecraft:light[level=12]
setblock 17 150 313 minecraft:light[level=12]
setblock 24 150 278 minecraft:light[level=12]
setblock 24 150 285 minecraft:light[level=12]
setblock 24 150 292 minecraft:light[level=12]
setblock 24 150 299 minecraft:light[level=12]
setblock 24 150 306 minecraft:light[level=12]
setblock 24 150 313 minecraft:light[level=12]
setblock 31 150 278 minecraft:light[level=12]
setblock 31 150 285 minecraft:light[level=12]
setblock 31 150 292 minecraft:light[level=12]
setblock 31 150 299 minecraft:light[level=12]
setblock 31 150 306 minecraft:light[level=12]
setblock 31 150 313 minecraft:light[level=12]
fill 34 150 275 40 162 275 minecraft:blackstone
setblock 38 150 278 minecraft:light[level=12]
setblock 38 150 285 minecraft:light[level=12]
setblock 38 150 292 minecraft:light[level=12]
setblock 38 150 299 minecraft:light[level=12]
setblock 38 150 306 minecraft:light[level=12]
setblock 38 150 313 minecraft:light[level=12]
setblock 41 150 275 minecraft:magma_block
fill 6 151 287 6 151 289 minecraft:red_nether_bricks
fill 6 151 290 7 153 291 minecraft:orange_terracotta
setblock 7 151 286 minecraft:red_nether_bricks
setblock 7 151 287 minecraft:nether_wart_block
setblock 8 151 284 minecraft:nether_wart_block
fill 8 151 285 8 153 285 minecraft:red_nether_bricks
fill 8 151 290 9 151 290 minecraft:red_nether_bricks
setblock 9 151 285 minecraft:nether_wart_block
fill 9 151 286 9 153 286 minecraft:red_nether_bricks
setblock 9 151 289 minecraft:orange_terracotta
setblock 10 151 283 minecraft:red_nether_bricks
fill 10 151 285 12 151 285 minecraft:red_nether_bricks
setblock 10 151 286 minecraft:nether_wart_block
fill 10 151 287 10 153 287 minecraft:red_nether_bricks
setblock 10 151 289 minecraft:red_nether_bricks
setblock 11 151 283 minecraft:nether_wart_block
fill 11 151 284 11 152 284 minecraft:red_nether_bricks
setblock 11 151 286 minecraft:red_nether_bricks
setblock 11 151 287 minecraft:nether_wart_block
fill 11 151 288 11 152 288 minecraft:red_nether_bricks
setblock 12 151 283 minecraft:red_nether_bricks
setblock 12 151 284 minecraft:nether_wart_block
setblock 13 151 282 minecraft:red_nether_bricks
setblock 13 151 285 minecraft:nether_wart_block
fill 41 151 275 41 219 275 minecraft:blackstone
fill 0 152 296 0 202 299 minecraft:blackstone
setblock 0 152 300 minecraft:amethyst_block
fill 5 152 289 5 152 291 minecraft:red_nether_bricks
fill 6 152 287 7 152 288 minecraft:red_nether_bricks
setblock 6 152 289 minecraft:nether_wart_block
fill 6 152 292 7 153 292 minecraft:orange_terracotta
setblock 6 152 293 minecraft:nether_wart_block
setblock 7 152 286 minecraft:nether_wart_block
fill 7 152 289 9 152 289 minecraft:red_nether_bricks
setblock 8 152 287 minecraft:nether_wart_block
setblock 8 152 288 minecraft:orange_terracotta
fill 8 152 290 8 152 291 minecraft:orange_terracotta
fill 8 152 292 8 154 292 minecraft:red_nether_bricks
setblock 9 152 284 minecraft:nether_wart_block
fill 9 152 285 9 153 285 minecraft:red_nether_bricks
setblock 9 152 287 minecraft:red_nether_bricks
setblock 9 152 288 minecraft:nether_wart_block
fill 9 152 290 9 152 291 minecraft:red_nether_bricks
setblock 10 152 285 minecraft:nether_wart_block
fill 10 152 286 10 153 286 minecraft:red_nether_bricks
setblock 10 152 289 minecraft:nether_wart_block
fill 11 152 285 12 152 285 minecraft:red_nether_bricks
setblock 11 152 286 minecraft:nether_wart_block
setblock 11 152 287 minecraft:red_nether_bricks
setblock 12 152 284 minecraft:red_nether_bricks
setblock 12 152 286 minecraft:red_nether_bricks
fill 0 153 300 0 196 300 minecraft:blackstone
fill 5 153 289 5 153 290 minecraft:red_nether_bricks
setblock 5 153 291 minecraft:nether_wart_block
fill 5 153 292 5 153 293 minecraft:red_nether_bricks
fill 5 153 294 7 154 294 minecraft:orange_terracotta
setblock 6 153 275 minecraft:crying_obsidian
fill 6 153 287 8 153 287 minecraft:red_nether_bricks
setblock 6 153 288 minecraft:nether_wart_block
fill 6 153 289 6 155 289 minecraft:red_nether_bricks
fill 6 153 293 6 154 293 minecraft:orange_terracotta
fill 6 153 295 6 155 295 minecraft:orange_terracotta
setblock 7 153 286 minecraft:red_nether_bricks
setblock 7 153 288 minecraft:red_nether_bricks
setblock 7 153 289 minecraft:nether_wart_block
setblock 7 153 293 minecraft:nether_wart_block
setblock 8 153 286 minecraft:nether_wart_block
fill 8 153 288 8 156 288 minecraft:bone_block
fill 8 153 289 10 153 289 minecraft:red_nether_bricks
setblock 8 153 290 minecraft:nether_wart_block
fill 8 153 291 8 155 291 minecraft:red_nether_bricks
setblock 8 153 293 minecraft:red_nether_bricks
setblock 9 153 287 minecraft:nether_wart_block
fill 9 153 288 9 154 288 minecraft:red_nether_bricks
setblock 9 153 290 minecraft:red_nether_bricks
setblock 9 153 291 minecraft:nether_wart_block
setblock 10 153 285 minecraft:red_nether_bricks
setblock 10 153 288 minecraft:nether_wart_block
setblock 11 153 286 minecraft:red_nether_bricks
fill 37 153 314 37 158 314 minecraft:polished_blackstone
setblock 0 154 286 minecraft:crying_obsidian
fill 4 154 291 5 154 292 minecraft:red_nether_bricks
setblock 4 154 293 minecraft:nether_wart_block
fill 4 154 294 4 155 295 minecraft:red_nether_bricks
setblock 5 154 289 minecraft:red_nether_bricks
setblock 5 154 290 minecraft:nether_wart_block
setblock 5 154 293 minecraft:orange_terracotta
fill 5 154 295 5 154 296 minecraft:orange_terracotta
fill 6 154 275 6 219 275 minecraft:blackstone
setblock 6 154 288 minecraft:red_nether_bricks
fill 6 154 290 8 154 290 minecraft:red_nether_bricks
setblock 6 154 291 minecraft:nether_wart_block
fill 6 154 292 6 156 292 minecraft:red_nether_bricks
fill 6 154 296 6 155 296 minecraft:orange_terracotta
fill 7 154 287 9 154 287 minecraft:red_nether_bricks
setblock 7 154 288 minecraft:nether_wart_block
fill 7 154 289 7 155 289 minecraft:red_nether_bricks
setblock 7 154 291 minecraft:red_nether_bricks
setblock 7 154 292 minecraft:nether_wart_block
setblock 7 154 293 minecraft:orange_terracotta
fill 7 154 295 7 155 295 minecraft:orange_terracotta
setblock 7 154 296 minecraft:nether_wart_block
setblock 8 154 289 minecraft:nether_wart_block
setblock 8 154 293 minecraft:nether_wart_block
fill 8 154 294 8 156 294 minecraft:red_nether_bricks
setblock 9 154 289 minecraft:red_nether_bricks
setblock 9 154 290 minecraft:nether_wart_block
fill 9 154 291 9 154 292 minecraft:red_nether_bricks
fill 28 154 314 30 155 315 minecraft:amethyst_block
fill 29 154 310 29 154 313 minecraft:amethyst_block
fill 29 154 316 29 155 316 minecraft:amethyst_block
setblock 0 155 285 minecraft:magma_block
fill 0 155 286 0 181 286 minecraft:blackstone
fill 3 155 278 3 156 278 minecraft:light[level=12]
setblock 3 155 286 minecraft:light[level=12]
setblock 3 155 294 minecraft:light[level=12]
setblock 3 155 302 minecraft:light[level=12]
setblock 3 155 310 minecraft:light[level=12]
setblock 4 155 292 minecraft:nether_wart_block
fill 4 155 293 4 156 293 minecraft:red_nether_bricks
setblock 4 155 296 minecraft:nether_wart_block
fill 4 155 297 4 157 297 minecraft:red_nether_bricks
fill 5 155 290 5 155 292 minecraft:red_nether_bricks
setblock 5 155 293 minecraft:nether_wart_block
fill 5 155 294 5 155 295 minecraft:orange_terracotta
setblock 5 155 296 minecraft:red_nether_bricks
fill 5 155 297 7 156 298 minecraft:orange_terracotta
setblock 6 155 290 minecraft:nether_wart_block
fill 6 155 291 6 156 291 minecraft:red_nether_bricks
fill 6 155 293 8 155 293 minecraft:red_nether_bricks
setblock 6 155 294 minecraft:orange_terracotta
fill 6 155 299 6 157 299 minecraft:orange_terracotta
setblock 7 155 288 minecraft:red_nether_bricks
fill 7 155 290 8 155 290 minecraft:red_nether_bricks
setblock 7 155 291 minecraft:nether_wart_block
fill 7 155 292 7 157 292 minecraft:red_nether_bricks
setblock 7 155 294 minecraft:red_nether_bricks
fill 7 155 296 7 157 296 minecraft:red_nether_bricks
setblock 8 155 289 minecraft:red_nether_bricks
setblock 8 155 292 minecraft:nether_wart_block
setblock 8 155 295 minecraft:red_nether_bricks
setblock 8 155 296 minecraft:nether_wart_block
setblock 11 155 278 minecraft:light[level=12]
setblock 11 155 286 minecraft:light[level=12]
setblock 11 155 294 minecraft:light[level=12]
setblock 11 155 302 minecraft:light[level=12]
setblock 11 155 310 minecraft:light[level=12]
setblock 19 155 278 minecraft:light[level=12]
setblock 19 155 286 minecraft:light[level=12]
setblock 19 155 294 minecraft:light[level=12]
setblock 19 155 302 minecraft:light[level=12]
setblock 19 155 310 minecraft:light[level=12]
setblock 27 155 278 minecraft:light[level=12]
setblock 27 155 286 minecraft:light[level=12]
setblock 27 155 294 minecraft:light[level=12]
setblock 27 155 302 minecraft:light[level=12]
setblock 27 155 310 minecraft:light[level=12]
fill 29 155 311 29 155 313 minecraft:amethyst_block
setblock 35 155 278 minecraft:light[level=12]
setblock 35 155 286 minecraft:light[level=12]
setblock 35 155 294 minecraft:light[level=12]
setblock 35 155 302 minecraft:light[level=12]
setblock 35 155 310 minecraft:light[level=12]
fill 0 156 285 0 219 285 minecraft:blackstone
setblock 3 156 285 minecraft:light[level=12]
setblock 3 156 292 minecraft:light[level=12]
setblock 3 156 299 minecraft:light[level=12]
setblock 3 156 306 minecraft:light[level=12]
setblock 3 156 313 minecraft:light[level=12]
setblock 4 156 292 minecraft:red_nether_bricks
fill 4 156 294 6 156 294 minecraft:red_nether_bricks
setblock 4 156 295 minecraft:nether_wart_block
fill 4 156 296 4 158 296 minecraft:red_nether_bricks
setblock 4 156 298 minecraft:red_nether_bricks
setblock 5 156 291 minecraft:red_nether_bricks
setblock 5 156 292 minecraft:nether_wart_block
fill 5 156 293 5 157 293 minecraft:red_nether_bricks
setblock 5 156 295 minecraft:red_nether_bricks
setblock 5 156 296 minecraft:nether_wart_block
setblock 5 156 299 minecraft:orange_terracotta
setblock 5 156 300 minecraft:nether_wart_block
setblock 6 156 290 minecraft:red_nether_bricks
setblock 6 156 293 minecraft:nether_wart_block
fill 6 156 295 6 159 295 minecraft:bone_block
setblock 6 156 296 minecraft:red_nether_bricks
fill 6 156 300 7 156 300 minecraft:red_nether_bricks
setblock 7 156 290 minecraft:nether_wart_block
setblock 7 156 291 minecraft:red_nether_bricks
fill 7 156 293 8 156 293 minecraft:red_nether_bricks
setblock 7 156 294 minecraft:nether_wart_block
fill 7 156 295 7 158 295 minecraft:red_nether_bricks
setblock 7 156 299 minecraft:orange_terracotta
fill 7 156 301 7 158 301 minecraft:orange_terracotta
setblock 8 156 291 minecraft:nether_wart_block
setblock 8 156 292 minecraft:red_nether_bricks
setblock 8 156 295 minecraft:nether_wart_block
fill 8 156 296 8 156 298 minecraft:red_nether_bricks
setblock 10 156 278 minecraft:light[level=12]
setblock 10 156 285 minecraft:light[level=12]
setblock 10 156 292 minecraft:light[level=12]
setblock 10 156 299 minecraft:light[level=12]
setblock 10 156 306 minecraft:light[level=12]
setblock 10 156 313 minecraft:light[level=12]
setblock 17 156 278 minecraft:light[level=12]
setblock 17 156 285 minecraft:light[level=12]
setblock 17 156 292 minecraft:light[level=12]
setblock 17 156 299 minecraft:light[level=12]
setblock 17 156 306 minecraft:light[level=12]
setblock 17 156 313 minecraft:light[level=12]
setblock 24 156 278 minecraft:light[level=12]
setblock 24 156 285 minecraft:light[level=12]
setblock 24 156 292 minecraft:light[level=12]
setblock 24 156 299 minecraft:light[level=12]
setblock 24 156 306 minecraft:light[level=12]
setblock 24 156 313 minecraft:light[level=12]
setblock 31 156 278 minecraft:light[level=12]
setblock 31 156 285 minecraft:light[level=12]
setblock 31 156 292 minecraft:light[level=12]
setblock 31 156 299 minecraft:light[level=12]
setblock 31 156 306 minecraft:light[level=12]
setblock 31 156 313 minecraft:light[level=12]
setblock 38 156 278 minecraft:light[level=12]
setblock 38 156 285 minecraft:light[level=12]
setblock 38 156 292 minecraft:light[level=12]
setblock 38 156 299 minecraft:light[level=12]
setblock 38 156 306 minecraft:light[level=12]
setblock 38 156 313 minecraft:light[level=12]
setblock 4 157 294 minecraft:nether_wart_block
setblock 4 157 295 minecraft:red_nether_bricks
setblock 4 157 298 minecraft:nether_wart_block
fill 4 157 299 4 158 300 minecraft:red_nether_bricks
setblock 5 157 292 minecraft:red_nether_bricks
fill 5 157 294 7 157 294 minecraft:red_nether_bricks
setblock 5 157 295 minecraft:nether_wart_block
fill 5 157 296 5 157 298 minecraft:red_nether_bricks
setblock 5 157 299 minecraft:nether_wart_block
fill 5 157 300 5 158 301 minecraft:red_nether_bricks
setblock 6 157 292 minecraft:nether_wart_block
setblock 6 157 293 minecraft:red_nether_bricks
setblock 6 157 296 minecraft:nether_wart_block
fill 6 157 297 6 159 297 minecraft:red_nether_bricks
setblock 6 157 298 minecraft:orange_terracotta
fill 6 157 300 6 158 302 minecraft:orange_terracotta
setblock 7 157 293 minecraft:nether_wart_block
setblock 7 157 297 minecraft:nether_wart_block
fill 7 157 298 7 158 299 minecraft:red_nether_bricks
fill 7 157 300 7 158 300 minecraft:orange_terracotta
fill 7 157 302 8 158 302 minecraft:orange_terracotta
setblock 8 157 294 minecraft:nether_wart_block
fill 8 157 295 8 157 297 minecraft:red_nether_bricks
setblock 8 157 298 minecraft:nether_wart_block
fill 8 157 299 8 158 300 minecraft:red_nether_bricks
fill 8 157 301 8 158 301 minecraft:orange_terracotta
fill 36 157 314 36 158 314 minecraft:polished_blackstone
fill 37 157 313 37 158 313 minecraft:polished_blackstone
fill 37 157 315 37 158 315 minecraft:polished_blackstone
fill 38 157 314 38 158 314 minecraft:polished_blackstone
fill 0 158 292 0 171 292 minecraft:blackstone
setblock 0 158 293 minecraft:magma_block
setblock 4 158 297 minecraft:nether_wart_block
fill 4 158 298 4 159 298 minecraft:red_nether_bricks
setblock 4 158 301 minecraft:nether_wart_block
setblock 5 158 294 minecraft:nether_wart_block
fill 5 158 295 5 158 297 minecraft:red_nether_bricks
setblock 5 158 298 minecraft:nether_wart_block
fill 5 158 299 5 160 299 minecraft:red_nether_bricks
setblock 5 158 302 minecraft:nether_wart_block
setblock 6 158 294 minecraft:red_nether_bricks
fill 6 158 296 6 159 296 minecraft:red_nether_bricks
setblock 6 158 298 minecraft:red_nether_bricks
setblock 6 158 299 minecraft:nether_wart_block
setblock 6 158 303 minecraft:nether_wart_block
setblock 7 158 296 minecraft:nether_wart_block
fill 7 158 297 7 159 297 minecraft:red_nether_bricks
setblock 7 158 303 minecraft:orange_terracotta
setblock 7 158 304 minecraft:nether_wart_block
setblock 8 158 296 minecraft:red_nether_bricks
setblock 8 158 297 minecraft:nether_wart_block
fill 8 158 298 8 159 298 minecraft:red_nether_bricks
fill 8 158 303 9 158 303 minecraft:red_nether_bricks
fill 8 158 304 8 160 304 minecraft:orange_terracotta
setblock 9 158 301 minecraft:red_nether_bricks
setblock 9 158 302 minecraft:nether_wart_block
setblock 36 158 313 minecraft:polished_blackstone
setblock 36 158 315 minecraft:polished_blackstone
setblock 38 158 313 minecraft:polished_blackstone
setblock 38 158 315 minecraft:polished_blackstone
fill 0 159 293 0 219 293 minecraft:blackstone
setblock 4 159 299 minecraft:red_nether_bricks
setblock 4 159 300 minecraft:nether_wart_block
setblock 4 159 301 minecraft:red_nether_bricks
setblock 5 159 296 minecraft:red_nether_bricks
setblock 5 159 297 minecraft:nether_wart_block
fill 5 159 298 5 160 298 minecraft:red_nether_bricks
fill 5 159 300 7 159 300 minecraft:red_nether_bricks
setblock 5 159 301 minecraft:nether_wart_block
fill 5 159 302 5 160 303 minecraft:red_nether_bricks
setblock 6 159 298 minecraft:nether_wart_block
fill 6 159 299 6 160 299 minecraft:red_nether_bricks
fill 6 159 301 8 159 301 minecraft:red_nether_bricks
setblock 6 159 302 minecraft:nether_wart_block
fill 6 159 303 6 160 304 minecraft:red_nether_bricks
setblock 7 159 296 minecraft:red_nether_bricks
setblock 7 159 298 minecraft:red_nether_bricks
setblock 7 159 299 minecraft:nether_wart_block
setblock 7 159 302 minecraft:orange_terracotta
setblock 7 159 303 minecraft:nether_wart_block
setblock 7 159 304 minecraft:orange_terracotta
fill 7 159 305 7 160 305 minecraft:red_nether_bricks
setblock 8 159 299 minecraft:red_nether_bricks
setblock 8 159 300 minecraft:nether_wart_block
fill 8 159 302 9 160 302 minecraft:red_nether_bricks
fill 8 159 303 9 159 303 minecraft:orange_terracotta
fill 8 159 305 9 160 305 minecraft:orange_terracotta
setblock 8 159 306 minecraft:red_nether_bricks
setblock 9 159 300 minecraft:red_nether_bricks
setblock 9 159 301 minecraft:nether_wart_block
fill 9 159 304 9 160 304 minecraft:orange_terracotta
fill 9 159 306 9 160 306 minecraft:orange_terracotta
fill 10 159 304 10 159 305 minecraft:red_nether_bricks
fill 0 160 294 0 179 294 minecraft:blackstone
setblock 0 160 295 minecraft:magma_block
setblock 0 160 304 minecraft:purple_concrete
setblock 5 160 300 minecraft:nether_wart_block
fill 5 160 301 5 161 301 minecraft:red_nether_bricks
setblock 6 160 298 minecraft:red_nether_bricks
fill 6 160 300 8 160 300 minecraft:red_nether_bricks
setblock 6 160 301 minecraft:nether_wart_block
fill 6 160 302 6 162 302 minecraft:red_nether_bricks
setblock 6 160 305 minecraft:nether_wart_block
setblock 7 160 298 minecraft:nether_wart_block
setblock 7 160 299 minecraft:red_nether_bricks
fill 7 160 301 9 160 301 minecraft:red_nether_bricks
fill 7 160 302 7 163 302 minecraft:bone_block
fill 7 160 303 7 161 304 minecraft:red_nether_bricks
setblock 7 160 306 minecraft:nether_wart_block
setblock 8 160 299 minecraft:nether_wart_block
setblock 8 160 303 minecraft:orange_terracotta
setblock 8 160 306 minecraft:orange_terracotta
setblock 8 160 307 minecraft:nether_wart_block
fill 9 160 303 10 160 303 minecraft:red_nether_bricks
setblock 9 160 307 minecraft:red_nether_bricks
setblock 10 160 304 minecraft:red_nether_bricks
fill 10 160 305 10 160 307 minecraft:orange_terracotta
setblock 11 160 305 minecraft:red_nether_bricks
fill 11 160 306 11 161 307 minecraft:orange_terracotta
fill 26 160 275 28 176 275 minecraft:blackstone
setblock 29 160 275 minecraft:magma_block
fill 30 160 275 31 166 275 minecraft:blackstone
fill 0 161 295 0 215 295 minecraft:blackstone
fill 0 161 304 0 215 304 minecraft:blackstone
setblock 5 161 302 minecraft:red_nether_bricks
setblock 6 161 300 minecraft:nether_wart_block
setblock 6 161 301 minecraft:red_nether_bricks
setblock 6 161 303 minecraft:red_nether_bricks
setblock 6 161 304 minecraft:nether_wart_block
setblock 6 161 305 minecraft:red_nether_bricks
fill 7 161 300 8 161 300 minecraft:red_nether_bricks
setblock 7 161 301 minecraft:nether_wart_block
setblock 7 161 305 minecraft:nether_wart_block
fill 7 161 306 7 163 306 minecraft:red_nether_bricks
fill 8 161 301 9 161 301 minecraft:red_nether_bricks
setblock 8 161 302 minecraft:nether_wart_block
fill 8 161 303 8 161 305 minecraft:red_nether_bricks
setblock 8 161 306 minecraft:nether_wart_block
fill 8 161 307 8 163 307 minecraft:red_nether_bricks
setblock 9 161 302 minecraft:red_nether_bricks
setblock 9 161 303 minecraft:nether_wart_block
fill 9 161 304 9 163 304 minecraft:red_nether_bricks
setblock 9 161 305 minecraft:orange_terracotta
setblock 9 161 306 minecraft:red_nether_bricks
fill 9 161 307 10 161 307 minecraft:orange_terracotta
fill 9 161 308 9 163 308 minecraft:red_nether_bricks
setblock 10 161 303 minecraft:red_nether_bricks
setblock 10 161 304 minecraft:nether_wart_block
fill 10 161 305 10 163 305 minecraft:red_nether_bricks
fill 10 161 306 10 162 306 minecraft:orange_terracotta
fill 10 161 308 12 162 308 minecraft:orange_terracotta
setblock 11 161 304 minecraft:red_nether_bricks
setblock 11 161 305 minecraft:nether_wart_block
setblock 11 161 309 minecraft:nether_wart_block
setblock 12 161 306 minecraft:nether_wart_block
fill 12 161 307 12 162 307 minecraft:orange_terracotta
fill 29 161 275 29 219 275 minecraft:blackstone
setblock 32 161 275 minecraft:purple_concrete
fill 42 161 294 42 219 295 minecraft:blackstone
setblock 42 161 296 minecraft:purple_concrete
fill 42 161 297 42 174 298 minecraft:blackstone
setblock 42 161 299 minecraft:amethyst_block
fill 42 161 301 42 185 301 minecraft:blackstone
setblock 42 161 302 minecraft:purple_concrete
fill 42 161 303 42 219 303 minecraft:blackstone
setblock 3 162 278 minecraft:light[level=12]
fill 3 162 285 3 162 286 minecraft:light[level=12]
setblock 3 162 292 minecraft:light[level=12]
setblock 3 162 294 minecraft:light[level=12]
setblock 3 162 299 minecraft:light[level=12]
setblock 3 162 302 minecraft:light[level=12]
setblock 3 162 306 minecraft:light[level=12]
setblock 3 162 310 minecraft:light[level=12]
setblock 3 162 313 minecraft:light[level=12]
setblock 6 162 303 minecraft:nether_wart_block
setblock 6 162 304 minecraft:red_nether_bricks
fill 7 162 303 9 162 303 minecraft:red_nether_bricks
setblock 7 162 304 minecraft:nether_wart_block
fill 7 162 305 7 163 305 minecraft:red_nether_bricks
setblock 8 162 302 minecraft:red_nether_bricks
setblock 8 162 304 minecraft:red_nether_bricks
setblock 8 162 305 minecraft:nether_wart_block
fill 8 162 306 8 164 306 minecraft:red_nether_bricks
setblock 8 162 308 minecraft:red_nether_bricks
setblock 9 162 302 minecraft:nether_wart_block
setblock 9 162 305 minecraft:red_nether_bricks
setblock 9 162 306 minecraft:nether_wart_block
fill 9 162 307 9 164 307 minecraft:red_nether_bricks
fill 9 162 309 11 162 309 minecraft:red_nether_bricks
fill 10 162 278 11 162 278 minecraft:light[level=12]
setblock 10 162 285 minecraft:light[level=12]
setblock 10 162 292 minecraft:light[level=12]
setblock 10 162 299 minecraft:light[level=12]
setblock 10 162 303 minecraft:nether_wart_block
fill 10 162 304 10 163 304 minecraft:red_nether_bricks
fill 10 162 307 11 162 307 minecraft:orange_terracotta
setblock 10 162 313 minecraft:light[level=12]
setblock 11 162 286 minecraft:light[level=12]
setblock 11 162 294 minecraft:light[level=12]
setblock 11 162 302 minecraft:light[level=12]
setblock 11 162 304 minecraft:nether_wart_block
fill 11 162 305 11 163 306 minecraft:red_nether_bricks
fill 11 162 310 12 163 310 minecraft:red_nether_bricks
setblock 12 162 305 minecraft:nether_wart_block
fill 12 162 306 12 164 306 minecraft:red_nether_bricks
fill 12 162 309 14 163 309 minecraft:orange_terracotta
fill 13 162 307 13 164 307 minecraft:red_nether_bricks
fill 13 162 308 13 163 308 minecraft:orange_terracotta
fill 13 162 310 14 164 310 minecraft:orange_terracotta
setblock 14 162 308 minecraft:red_nether_bricks
setblock 17 162 278 minecraft:light[level=12]
setblock 17 162 285 minecraft:light[level=12]
setblock 17 162 292 minecraft:light[level=12]
setblock 17 162 299 minecraft:light[level=12]
setblock 17 162 306 minecraft:light[level=12]
setblock 17 162 313 minecraft:light[level=12]
setblock 19 162 278 minecraft:light[level=12]
setblock 19 162 286 minecraft:light[level=12]
setblock 19 162 294 minecraft:light[level=12]
setblock 19 162 302 minecraft:light[level=12]
setblock 19 162 310 minecraft:light[level=12]
setblock 24 162 278 minecraft:light[level=12]
setblock 24 162 285 minecraft:light[level=12]
setblock 24 162 292 minecraft:light[level=12]
setblock 24 162 299 minecraft:light[level=12]
setblock 24 162 306 minecraft:light[level=12]
setblock 24 162 313 minecraft:light[level=12]
setblock 27 162 278 minecraft:light[level=12]
setblock 27 162 286 minecraft:light[level=12]
setblock 27 162 294 minecraft:light[level=12]
setblock 27 162 302 minecraft:light[level=12]
setblock 27 162 310 minecraft:light[level=12]
setblock 31 162 278 minecraft:light[level=12]
setblock 31 162 285 minecraft:light[level=12]
setblock 31 162 292 minecraft:light[level=12]
setblock 31 162 299 minecraft:light[level=12]
setblock 31 162 306 minecraft:light[level=12]
setblock 31 162 313 minecraft:light[level=12]
fill 32 162 275 32 219 275 minecraft:blackstone
setblock 35 162 278 minecraft:light[level=12]
setblock 35 162 286 minecraft:light[level=12]
setblock 35 162 294 minecraft:light[level=12]
setblock 35 162 302 minecraft:light[level=12]
setblock 35 162 310 minecraft:light[level=12]
setblock 38 162 278 minecraft:light[level=12]
setblock 38 162 285 minecraft:light[level=12]
setblock 38 162 292 minecraft:light[level=12]
setblock 38 162 299 minecraft:light[level=12]
setblock 38 162 306 minecraft:light[level=12]
setblock 38 162 313 minecraft:light[level=12]
fill 42 162 296 42 178 296 minecraft:blackstone
fill 42 162 299 42 186 299 minecraft:blackstone
fill 42 162 302 42 167 302 minecraft:blackstone
setblock 7 163 304 minecraft:red_nether_bricks
fill 8 163 303 9 163 303 minecraft:red_nether_bricks
setblock 8 163 304 minecraft:nether_wart_block
setblock 8 163 305 minecraft:red_nether_bricks
setblock 9 163 305 minecraft:nether_wart_block
fill 9 163 306 9 164 306 minecraft:red_nether_bricks
setblock 9 163 309 minecraft:nether_wart_block
setblock 10 163 306 minecraft:nether_wart_block
fill 10 163 307 10 163 309 minecraft:red_nether_bricks
fill 11 163 307 11 166 308 minecraft:bone_block
fill 11 163 309 11 164 309 minecraft:red_nether_bricks
setblock 12 163 305 minecraft:red_nether_bricks
setblock 12 163 307 minecraft:red_nether_bricks
setblock 12 163 308 minecraft:orange_terracotta
fill 13 163 306 13 164 306 minecraft:red_nether_bricks
fill 13 163 311 14 164 311 minecraft:red_nether_bricks
fill 14 163 307 14 165 307 minecraft:red_nether_bricks
setblock 14 163 308 minecraft:orange_terracotta
fill 15 163 308 15 165 308 minecraft:red_nether_bricks
fill 15 163 309 15 164 310 minecraft:orange_terracotta
setblock 15 163 311 minecraft:nether_wart_block
setblock 16 163 310 minecraft:red_nether_bricks
fill 34 163 275 39 216 275 minecraft:blackstone
setblock 40 163 275 minecraft:magma_block
setblock 9 164 305 minecraft:red_nether_bricks
setblock 9 164 308 minecraft:nether_wart_block
setblock 10 164 305 minecraft:nether_wart_block
fill 10 164 306 10 164 308 minecraft:red_nether_bricks
setblock 10 164 309 minecraft:nether_wart_block
setblock 11 164 305 minecraft:red_nether_bricks
setblock 11 164 306 minecraft:nether_wart_block
setblock 11 164 310 minecraft:nether_wart_block
setblock 11 164 317 minecraft:purple_concrete
setblock 12 164 307 minecraft:nether_wart_block
fill 12 164 308 12 164 310 minecraft:red_nether_bricks
setblock 12 164 311 minecraft:nether_wart_block
setblock 13 164 308 minecraft:nether_wart_block
fill 13 164 309 14 164 309 minecraft:orange_terracotta
setblock 14 164 308 minecraft:red_nether_bricks
fill 14 164 312 16 164 312 minecraft:red_nether_bricks
fill 15 164 311 18 164 311 minecraft:orange_terracotta
fill 16 164 308 16 165 309 minecraft:red_nether_bricks
fill 16 164 310 17 165 310 minecraft:orange_terracotta
fill 17 164 309 17 166 309 minecraft:red_nether_bricks
fill 40 164 275 40 217 275 minecraft:blackstone
fill 41 164 292 42 167 292 minecraft:amethyst_block
fill 42 164 290 42 164 291 minecraft:blackstone
setblock 10 165 307 minecraft:red_nether_bricks
setblock 10 165 308 minecraft:nether_wart_block
setblock 10 165 309 minecraft:red_nether_bricks
setblock 11 165 306 minecraft:red_nether_bricks
setblock 11 165 309 minecraft:nether_wart_block
setblock 11 165 310 minecraft:red_nether_bricks
fill 11 165 317 11 219 317 minecraft:blackstone
setblock 12 165 306 minecraft:nether_wart_block
fill 12 165 307 12 165 309 minecraft:red_nether_bricks
setblock 12 165 310 minecraft:nether_wart_block
setblock 12 165 311 minecraft:red_nether_bricks
setblock 13 165 307 minecraft:nether_wart_block
fill 13 165 308 13 165 310 minecraft:red_nether_bricks
setblock 13 165 311 minecraft:nether_wart_block
setblock 14 165 308 minecraft:nether_wart_block
fill 14 165 309 14 165 311 minecraft:red_nether_bricks
setblock 14 165 312 minecraft:nether_wart_block
setblock 15 165 309 minecraft:nether_wart_block
setblock 15 165 310 minecraft:orange_terracotta
fill 15 165 311 15 165 312 minecraft:red_nether_bricks
fill 16 165 311 20 165 311 minecraft:orange_terracotta
fill 16 165 312 16 166 312 minecraft:red_nether_bricks
setblock 17 165 312 minecraft:orange_terracotta
fill 18 165 309 18 167 309 minecraft:red_nether_bricks
setblock 18 165 310 minecraft:orange_terracotta
setblock 18 165 312 minecraft:nether_wart_block
setblock 19 165 310 minecraft:red_nether_bricks
setblock 19 165 312 minecraft:red_nether_bricks
fill 40 165 291 40 166 292 minecraft:amethyst_block
fill 41 165 291 42 166 291 minecraft:amethyst_block
fill 41 165 293 42 166 293 minecraft:amethyst_block
fill 42 165 290 42 219 290 minecraft:blackstone
fill 0 166 280 0 219 280 minecraft:blackstone
setblock 0 166 281 minecraft:amethyst_block
setblock 11 166 309 minecraft:red_nether_bricks
fill 12 166 308 14 166 308 minecraft:red_nether_bricks
setblock 12 166 309 minecraft:nether_wart_block
setblock 12 166 310 minecraft:red_nether_bricks
fill 13 166 309 15 166 309 minecraft:red_nether_bricks
setblock 13 166 310 minecraft:nether_wart_block
setblock 13 166 311 minecraft:red_nether_bricks
fill 14 166 310 16 166 310 minecraft:red_nether_bricks
setblock 14 166 311 minecraft:nether_wart_block
setblock 14 166 312 minecraft:red_nether_bricks
setblock 15 166 308 minecraft:nether_wart_block
fill 15 166 311 16 166 311 minecraft:red_nether_bricks
setblock 15 166 312 minecraft:nether_wart_block
fill 16 166 308 17 166 308 minecraft:red_nether_bricks
setblock 16 166 309 minecraft:nether_wart_block
setblock 16 166 313 minecraft:nether_wart_block
fill 17 166 310 17 166 311 minecraft:orange_terracotta
fill 17 166 312 18 166 313 minecraft:red_nether_bricks
setblock 18 166 310 minecraft:red_nether_bricks
fill 18 166 311 21 166 311 minecraft:orange_terracotta
fill 19 166 309 19 168 309 minecraft:red_nether_bricks
fill 19 166 310 20 166 310 minecraft:orange_terracotta
fill 19 166 312 21 167 312 minecraft:orange_terracotta
fill 19 166 313 19 168 313 minecraft:red_nether_bricks
setblock 21 166 275 minecraft:amethyst_block
setblock 21 166 310 minecraft:nether_wart_block
fill 0 167 281 0 216 281 minecraft:blackstone
fill 12 167 317 12 219 317 minecraft:blackstone
setblock 13 167 309 minecraft:nether_wart_block
setblock 13 167 310 minecraft:red_nether_bricks
setblock 13 167 317 minecraft:magma_block
fill 14 167 309 16 167 309 minecraft:red_nether_bricks
setblock 14 167 310 minecraft:nether_wart_block
setblock 14 167 311 minecraft:red_nether_bricks
fill 14 167 317 18 199 317 minecraft:blackstone
setblock 15 167 308 minecraft:red_nether_bricks
fill 15 167 310 17 167 310 minecraft:red_nether_bricks
setblock 15 167 311 minecraft:nether_wart_block
setblock 15 167 312 minecraft:red_nether_bricks
setblock 16 167 308 minecraft:nether_wart_block
setblock 16 167 311 minecraft:red_nether_bricks
setblock 16 167 312 minecraft:nether_wart_block
setblock 17 167 309 minecraft:nether_wart_block
fill 17 167 311 17 170 311 minecraft:bone_block
fill 17 167 312 18 167 312 minecraft:red_nether_bricks
setblock 17 167 313 minecraft:nether_wart_block
setblock 18 167 310 minecraft:nether_wart_block
fill 18 167 311 18 169 311 minecraft:red_nether_bricks
setblock 18 167 313 minecraft:red_nether_bricks
setblock 19 167 310 minecraft:red_nether_bricks
fill 19 167 311 24 167 311 minecraft:orange_terracotta
fill 20 167 309 20 169 309 minecraft:red_nether_bricks
fill 20 167 310 21 167 310 minecraft:orange_terracotta
fill 20 167 313 20 169 313 minecraft:red_nether_bricks
fill 21 167 275 21 220 275 minecraft:blackstone
setblock 21 167 309 minecraft:nether_wart_block
setblock 21 167 313 minecraft:nether_wart_block
setblock 22 167 310 minecraft:nether_wart_block
fill 22 167 312 22 167 313 minecraft:red_nether_bricks
setblock 23 167 310 minecraft:red_nether_bricks
fill 23 167 312 23 169 312 minecraft:orange_terracotta
fill 30 167 275 30 219 275 minecraft:blackstone
setblock 31 167 275 minecraft:purple_concrete
fill 42 167 291 42 216 291 minecraft:blackstone
fill 42 167 293 42 174 293 minecraft:blackstone
fill 3 168 278 3 169 278 minecraft:light[level=12]
setblock 3 168 285 minecraft:light[level=12]
setblock 3 168 292 minecraft:light[level=12]
setblock 3 168 299 minecraft:light[level=12]
setblock 3 168 306 minecraft:light[level=12]
setblock 3 168 313 minecraft:light[level=12]
setblock 10 168 278 minecraft:light[level=12]
setblock 10 168 285 minecraft:light[level=12]
setblock 10 168 292 minecraft:light[level=12]
setblock 10 168 299 minecraft:light[level=12]
setblock 10 168 306 minecraft:light[level=12]
setblock 10 168 313 minecraft:light[level=12]
fill 13 168 317 13 219 317 minecraft:blackstone
setblock 15 168 310 minecraft:nether_wart_block
setblock 15 168 311 minecraft:red_nether_bricks
fill 16 168 309 17 168 310 minecraft:red_nether_bricks
setblock 16 168 311 minecraft:nether_wart_block
setblock 16 168 312 minecraft:red_nether_bricks
setblock 17 168 278 minecraft:light[level=12]
setblock 17 168 285 minecraft:light[level=12]
setblock 17 168 292 minecraft:light[level=12]
setblock 17 168 299 minecraft:light[level=12]
setblock 17 168 306 minecraft:light[level=12]
setblock 17 168 312 minecraft:nether_wart_block
setblock 17 168 313 minecraft:red_nether_bricks
setblock 18 168 309 minecraft:nether_wart_block
fill 18 168 310 18 169 310 minecraft:red_nether_bricks
fill 18 168 312 20 168 312 minecraft:red_nether_bricks
setblock 18 168 313 minecraft:nether_wart_block
setblock 19 168 310 minecraft:nether_wart_block
fill 19 168 311 19 170 311 minecraft:red_nether_bricks
fill 20 168 310 22 168 310 minecraft:red_nether_bricks
setblock 20 168 311 minecraft:nether_wart_block
fill 21 168 309 21 170 309 minecraft:red_nether_bricks
fill 21 168 311 25 168 311 minecraft:orange_terracotta
setblock 21 168 312 minecraft:nether_wart_block
fill 21 168 313 21 170 313 minecraft:red_nether_bricks
setblock 22 168 309 minecraft:nether_wart_block
setblock 22 168 312 minecraft:red_nether_bricks
setblock 22 168 313 minecraft:nether_wart_block
setblock 23 168 309 minecraft:red_nether_bricks
fill 23 168 310 25 169 310 minecraft:orange_terracotta
setblock 23 168 313 minecraft:red_nether_bricks
setblock 24 168 278 minecraft:light[level=12]
setblock 24 168 285 minecraft:light[level=12]
setblock 24 168 292 minecraft:light[level=12]
setblock 24 168 299 minecraft:light[level=12]
setblock 24 168 306 minecraft:light[level=12]
fill 24 168 312 24 169 312 minecraft:orange_terracotta
setblock 24 168 313 minecraft:light[level=12]
setblock 25 168 312 minecraft:nether_wart_block
fill 31 168 275 31 219 275 minecraft:blackstone
setblock 31 168 278 minecraft:light[level=12]
setblock 31 168 285 minecraft:light[level=12]
setblock 31 168 292 minecraft:light[level=12]
setblock 31 168 299 minecraft:light[level=12]
setblock 31 168 306 minecraft:light[level=12]
setblock 31 168 313 minecraft:light[level=12]
setblock 38 168 278 minecraft:light[level=12]
setblock 38 168 285 minecraft:light[level=12]
setblock 38 168 292 minecraft:light[level=12]
setblock 38 168 299 minecraft:light[level=12]
setblock 38 168 306 minecraft:light[level=12]
setblock 38 168 313 minecraft:light[level=12]
fill 42 168 292 42 219 292 minecraft:blackstone
setblock 42 168 302 minecraft:amethyst_block
setblock 3 169 286 minecraft:light[level=12]
setblock 3 169 294 minecraft:light[level=12]
setblock 3 169 302 minecraft:light[level=12]
setblock 3 169 310 minecraft:light[level=12]
setblock 11 169 278 minecraft:light[level=12]
setblock 11 169 286 minecraft:light[level=12]
setblock 11 169 294 minecraft:light[level=12]
setblock 11 169 302 minecraft:light[level=12]
setblock 11 169 310 minecraft:light[level=12]
setblock 17 169 310 minecraft:red_nether_bricks
setblock 17 169 312 minecraft:red_nether_bricks
setblock 18 169 312 minecraft:nether_wart_block
setblock 19 169 278 minecraft:light[level=12]
setblock 19 169 286 minecraft:light[level=12]
setblock 19 169 294 minecraft:light[level=12]
setblock 19 169 302 minecraft:light[level=12]
setblock 19 169 309 minecraft:nether_wart_block
fill 19 169 310 19 170 310 minecraft:red_nether_bricks
fill 19 169 312 21 169 312 minecraft:red_nether_bricks
setblock 19 169 313 minecraft:nether_wart_block
setblock 20 169 310 minecraft:nether_wart_block
fill 20 169 311 20 170 311 minecraft:red_nether_bricks
fill 21 169 310 22 169 310 minecraft:red_nether_bricks
setblock 21 169 311 minecraft:nether_wart_block
fill 22 169 309 22 170 309 minecraft:red_nether_bricks
setblock 22 169 311 minecraft:red_nether_bricks
setblock 22 169 312 minecraft:nether_wart_block
fill 22 169 313 22 171 313 minecraft:red_nether_bricks
setblock 23 169 309 minecraft:nether_wart_block
fill 23 169 311 27 169 311 minecraft:orange_terracotta
setblock 23 169 313 minecraft:nether_wart_block
fill 24 169 309 26 169 309 minecraft:red_nether_bricks
fill 24 169 313 25 169 313 minecraft:red_nether_bricks
fill 25 169 312 25 171 312 minecraft:red_nether_bricks
fill 26 169 310 27 171 310 minecraft:orange_terracotta
setblock 26 169 312 minecraft:nether_wart_block
setblock 27 169 278 minecraft:light[level=12]
setblock 27 169 286 minecraft:light[level=12]
setblock 27 169 294 minecraft:light[level=12]
setblock 27 169 302 minecraft:light[level=12]
setblock 35 169 278 minecraft:light[level=12]
setblock 35 169 286 minecraft:light[level=12]
setblock 35 169 294 minecraft:light[level=12]
setblock 35 169 302 minecraft:light[level=12]
setblock 35 169 310 minecraft:light[level=12]
fill 42 169 302 42 198 302 minecraft:blackstone
setblock 19 170 312 minecraft:nether_wart_block
setblock 20 170 310 minecraft:red_nether_bricks
fill 20 170 312 22 170 312 minecraft:red_nether_bricks
setblock 20 170 313 minecraft:nether_wart_block
fill 20 170 317 20 219 317 minecraft:blackstone
setblock 21 170 310 minecraft:nether_wart_block
fill 21 170 311 21 171 311 minecraft:red_nether_bricks
fill 21 170 316 22 171 317 minecraft:amethyst_block
fill 22 170 310 24 170 310 minecraft:red_nether_bricks
setblock 22 170 311 minecraft:nether_wart_block
fill 22 170 315 23 171 315 minecraft:amethyst_block
fill 23 170 309 23 171 309 minecraft:red_nether_bricks
setblock 23 170 311 minecraft:red_nether_bricks
setblock 23 170 312 minecraft:nether_wart_block
fill 23 170 313 23 171 313 minecraft:red_nether_bricks
fill 23 170 316 23 171 316 minecraft:amethyst_block
fill 23 170 317 26 198 317 minecraft:blackstone
setblock 24 170 309 minecraft:nether_wart_block
fill 24 170 311 24 174 311 minecraft:bone_block
setblock 24 170 312 minecraft:red_nether_bricks
setblock 24 170 313 minecraft:nether_wart_block
setblock 25 170 309 minecraft:red_nether_bricks
setblock 25 170 310 minecraft:nether_wart_block
fill 25 170 311 25 172 311 minecraft:red_nether_bricks
setblock 25 170 313 minecraft:red_nether_bricks
fill 26 170 308 26 172 308 minecraft:red_nether_bricks
fill 26 170 309 28 170 309 minecraft:orange_terracotta
fill 26 170 311 28 170 311 minecraft:orange_terracotta
fill 26 170 312 26 172 312 minecraft:red_nether_bricks
setblock 27 170 308 minecraft:nether_wart_block
setblock 27 170 312 minecraft:nether_wart_block
fill 28 170 310 28 171 310 minecraft:orange_terracotta
setblock 29 170 309 minecraft:red_nether_bricks
setblock 29 170 310 minecraft:nether_wart_block
setblock 1 171 275 minecraft:magma_block
fill 2 171 275 3 189 275 minecraft:blackstone
setblock 21 171 310 minecraft:red_nether_bricks
fill 21 171 312 23 171 312 minecraft:red_nether_bricks
setblock 22 171 310 minecraft:nether_wart_block
setblock 22 171 311 minecraft:red_nether_bricks
fill 23 171 310 25 171 310 minecraft:red_nether_bricks
setblock 23 171 311 minecraft:nether_wart_block
fill 24 171 309 24 172 309 minecraft:red_nether_bricks
setblock 24 171 312 minecraft:nether_wart_block
setblock 24 171 313 minecraft:red_nether_bricks
setblock 25 171 308 minecraft:red_nether_bricks
setblock 25 171 309 minecraft:nether_wart_block
setblock 25 171 313 minecraft:nether_wart_block
setblock 26 171 309 minecraft:red_nether_bricks
fill 26 171 311 26 173 311 minecraft:red_nether_bricks
setblock 26 171 313 minecraft:red_nether_bricks
fill 27 171 308 27 173 308 minecraft:red_nether_bricks
fill 27 171 309 30 171 309 minecraft:orange_terracotta
setblock 27 171 311 minecraft:nether_wart_block
fill 27 171 312 27 173 312 minecraft:red_nether_bricks
setblock 28 171 308 minecraft:nether_wart_block
fill 28 171 311 29 171 311 minecraft:red_nether_bricks
setblock 28 171 312 minecraft:nether_wart_block
fill 29 171 308 31 172 308 minecraft:orange_terracotta
fill 29 171 310 29 173 310 minecraft:red_nether_bricks
setblock 30 171 310 minecraft:nether_wart_block
setblock 0 172 292 minecraft:crying_obsidian
fill 1 172 275 1 216 275 minecraft:blackstone
fill 21 172 317 22 219 317 minecraft:blackstone
setblock 22 172 316 minecraft:amethyst_block
setblock 23 172 310 minecraft:nether_wart_block
fill 23 172 311 23 172 312 minecraft:red_nether_bricks
fill 24 172 310 26 172 310 minecraft:red_nether_bricks
setblock 24 172 312 minecraft:red_nether_bricks
fill 25 172 309 25 173 309 minecraft:red_nether_bricks
setblock 25 172 312 minecraft:nether_wart_block
setblock 26 172 309 minecraft:nether_wart_block
fill 27 172 309 28 172 309 minecraft:red_nether_bricks
setblock 27 172 310 minecraft:nether_wart_block
fill 27 172 311 27 174 311 minecraft:red_nether_bricks
setblock 28 172 307 minecraft:nether_wart_block
fill 28 172 308 28 174 308 minecraft:red_nether_bricks
setblock 28 172 310 minecraft:red_nether_bricks
setblock 28 172 311 minecraft:nether_wart_block
fill 28 172 312 28 173 312 minecraft:red_nether_bricks
setblock 29 172 307 minecraft:red_nether_bricks
fill 29 172 309 31 172 309 minecraft:orange_terracotta
fill 29 172 311 30 172 311 minecraft:red_nether_bricks
fill 30 172 306 30 174 306 minecraft:red_nether_bricks
fill 30 172 307 31 173 307 minecraft:orange_terracotta
fill 30 172 310 30 174 310 minecraft:red_nether_bricks
setblock 31 172 306 minecraft:nether_wart_block
setblock 31 172 310 minecraft:nether_wart_block
setblock 32 172 307 minecraft:nether_wart_block
fill 32 172 308 32 173 309 minecraft:red_nether_bricks
setblock 42 172 310 minecraft:magma_block
fill 0 173 292 0 219 292 minecraft:blackstone
fill 25 173 310 27 173 310 minecraft:red_nether_bricks
setblock 25 173 311 minecraft:nether_wart_block
setblock 26 173 308 minecraft:nether_wart_block
setblock 26 173 309 minecraft:red_nether_bricks
setblock 26 173 312 minecraft:nether_wart_block
setblock 27 173 309 minecraft:nether_wart_block
fill 28 173 307 28 174 307 minecraft:red_nether_bricks
fill 28 173 309 30 173 309 minecraft:red_nether_bricks
setblock 28 173 310 minecraft:nether_wart_block
fill 28 173 311 28 174 311 minecraft:red_nether_bricks
setblock 29 173 306 minecraft:red_nether_bricks
setblock 29 173 307 minecraft:nether_wart_block
fill 29 173 308 29 175 308 minecraft:red_nether_bricks
setblock 29 173 311 minecraft:nether_wart_block
fill 30 173 308 31 173 308 minecraft:orange_terracotta
setblock 30 173 311 minecraft:red_nether_bricks
setblock 31 173 305 minecraft:nether_wart_block
fill 31 173 306 33 173 306 minecraft:orange_terracotta
setblock 31 173 309 minecraft:nether_wart_block
fill 31 173 310 31 175 310 minecraft:red_nether_bricks
fill 32 173 305 34 174 305 minecraft:orange_terracotta
fill 32 173 307 33 174 307 minecraft:orange_terracotta
fill 33 173 308 33 175 308 minecraft:red_nether_bricks
fill 42 173 310 42 216 310 minecraft:blackstone
setblock 3 174 278 minecraft:light[level=12]
setblock 3 174 285 minecraft:light[level=12]
setblock 3 174 292 minecraft:light[level=12]
setblock 3 174 299 minecraft:light[level=12]
setblock 3 174 306 minecraft:light[level=12]
setblock 3 174 313 minecraft:light[level=12]
setblock 10 174 278 minecraft:light[level=12]
setblock 10 174 285 minecraft:light[level=12]
setblock 10 174 292 minecraft:light[level=12]
setblock 10 174 299 minecraft:light[level=12]
setblock 10 174 306 minecraft:light[level=12]
setblock 10 174 313 minecraft:light[level=12]
setblock 17 174 278 minecraft:light[level=12]
setblock 17 174 285 minecraft:light[level=12]
setblock 17 174 292 minecraft:light[level=12]
setblock 17 174 299 minecraft:light[level=12]
setblock 17 174 306 minecraft:light[level=12]
setblock 17 174 313 minecraft:light[level=12]
setblock 24 174 278 minecraft:light[level=12]
setblock 24 174 285 minecraft:light[level=12]
setblock 24 174 292 minecraft:light[level=12]
setblock 24 174 299 minecraft:light[level=12]
setblock 24 174 306 minecraft:light[level=12]
setblock 24 174 313 minecraft:light[level=12]
fill 26 174 310 28 174 310 minecraft:red_nether_bricks
setblock 27 174 308 minecraft:nether_wart_block
setblock 27 174 309 minecraft:red_nether_bricks
setblock 28 174 309 minecraft:nether_wart_block
setblock 29 174 306 minecraft:nether_wart_block
fill 29 174 307 29 175 307 minecraft:red_nether_bricks
fill 29 174 309 31 174 309 minecraft:red_nether_bricks
setblock 29 174 310 minecraft:nether_wart_block
setblock 29 174 311 minecraft:red_nether_bricks
fill 30 174 305 31 175 305 minecraft:red_nether_bricks
setblock 30 174 307 minecraft:nether_wart_block
fill 30 174 308 31 175 308 minecraft:bone_block
setblock 30 174 311 minecraft:nether_wart_block
setblock 31 174 278 minecraft:light[level=12]
setblock 31 174 285 minecraft:light[level=12]
setblock 31 174 292 minecraft:light[level=12]
setblock 31 174 299 minecraft:light[level=12]
fill 31 174 306 31 174 307 minecraft:red_nether_bricks
setblock 31 174 313 minecraft:light[level=12]
setblock 32 174 304 minecraft:red_nether_bricks
fill 32 174 306 34 174 306 minecraft:orange_terracotta
setblock 32 174 308 minecraft:red_nether_bricks
setblock 32 174 309 minecraft:nether_wart_block
fill 33 174 304 34 174 304 minecraft:orange_terracotta
setblock 33 174 309 minecraft:red_nether_bricks
fill 34 174 303 35 175 303 minecraft:orange_terracotta
setblock 34 174 307 minecraft:nether_wart_block
setblock 35 174 304 minecraft:nether_wart_block
fill 35 174 305 35 175 305 minecraft:red_nether_bricks
setblock 38 174 278 minecraft:light[level=12]
setblock 38 174 285 minecraft:light[level=12]
setblock 38 174 292 minecraft:light[level=12]
setblock 38 174 299 minecraft:light[level=12]
setblock 38 174 306 minecraft:light[level=12]
setblock 38 174 313 minecraft:light[level=12]
fill 9 175 293 16 175 293 minecraft:basalt
fill 10 175 289 17 175 292 minecraft:basalt
fill 10 175 294 17 175 297 minecraft:basalt
fill 11 175 287 29 175 288 minecraft:basalt
fill 11 175 298 29 175 299 minecraft:basalt
fill 12 175 286 28 175 286 minecraft:basalt
fill 12 175 300 28 175 300 minecraft:basalt
fill 13 175 285 27 175 285 minecraft:basalt
fill 13 175 301 27 175 301 minecraft:basalt
fill 14 175 284 26 175 284 minecraft:basalt
fill 14 175 302 26 175 302 minecraft:basalt
fill 16 175 283 24 175 283 minecraft:basalt
fill 16 175 303 24 175 303 minecraft:basalt
fill 18 175 289 19 175 290 minecraft:basalt
fill 18 175 296 19 175 297 minecraft:basalt
setblock 20 175 282 minecraft:basalt
fill 20 175 289 30 175 289 minecraft:basalt
fill 20 175 297 30 175 297 minecraft:basalt
setblock 20 175 304 minecraft:basalt
fill 21 175 290 30 175 290 minecraft:basalt
fill 21 175 296 30 175 296 minecraft:basalt
fill 23 175 291 30 175 292 minecraft:basalt
fill 23 175 294 30 175 295 minecraft:basalt
fill 24 175 293 31 175 293 minecraft:basalt
setblock 28 175 308 minecraft:nether_wart_block
setblock 28 175 309 minecraft:red_nether_bricks
setblock 29 175 309 minecraft:nether_wart_block
setblock 29 175 310 minecraft:red_nether_bricks
setblock 30 175 306 minecraft:nether_wart_block
setblock 30 175 307 minecraft:red_nether_bricks
fill 30 175 309 32 175 309 minecraft:red_nether_bricks
setblock 30 175 310 minecraft:nether_wart_block
setblock 31 175 304 minecraft:red_nether_bricks
fill 31 175 306 32 175 306 minecraft:red_nether_bricks
setblock 31 175 307 minecraft:nether_wart_block
setblock 32 175 303 minecraft:red_nether_bricks
setblock 32 175 304 minecraft:nether_wart_block
setblock 32 175 305 minecraft:red_nether_bricks
fill 32 175 307 34 175 307 minecraft:red_nether_bricks
setblock 32 175 308 minecraft:nether_wart_block
setblock 33 175 302 minecraft:red_nether_bricks
setblock 33 175 303 minecraft:orange_terracotta
setblock 33 175 304 minecraft:red_nether_bricks
fill 33 175 305 33 175 306 minecraft:orange_terracotta
setblock 33 175 309 minecraft:nether_wart_block
fill 34 175 302 35 175 302 minecraft:orange_terracotta
fill 34 175 304 35 175 304 minecraft:orange_terracotta
setblock 34 175 305 minecraft:red_nether_bricks
setblock 34 175 306 minecraft:nether_wart_block
setblock 34 175 308 minecraft:red_nether_bricks
setblock 35 175 306 minecraft:red_nether_bricks
setblock 36 175 303 minecraft:red_nether_bricks
setblock 36 175 304 minecraft:nether_wart_block
setblock 42 175 293 minecraft:crying_obsidian
setblock 42 175 297 minecraft:purple_concrete
fill 42 175 298 42 194 298 minecraft:blackstone
setblock 42 175 311 minecraft:purple_concrete
fill 42 175 312 42 219 312 minecraft:blackstone
fill 1 176 276 9 176 316 minecraft:blackstone
fill 10 176 276 10 176 292 minecraft:blackstone
fill 10 176 293 11 176 293 minecraft:basalt
setblock 10 176 294 minecraft:polished_basalt
fill 10 176 295 10 176 296 minecraft:basalt
setblock 10 176 297 minecraft:polished_basalt
fill 10 176 300 10 176 316 minecraft:blackstone
fill 11 176 276 11 176 290 minecraft:blackstone
fill 11 176 291 12 176 291 minecraft:basalt
setblock 11 176 292 minecraft:polished_basalt
fill 11 176 294 12 176 294 minecraft:basalt
setblock 11 176 295 minecraft:polished_basalt
fill 11 176 296 11 176 297 minecraft:basalt
setblock 11 176 298 minecraft:polished_basalt
setblock 11 176 299 minecraft:basalt
fill 11 176 302 11 176 316 minecraft:blackstone
fill 12 176 276 12 176 288 minecraft:blackstone
fill 12 176 289 13 176 289 minecraft:basalt
setblock 12 176 290 minecraft:polished_basalt
fill 12 176 292 13 176 292 minecraft:basalt
setblock 12 176 293 minecraft:polished_basalt
fill 12 176 295 13 176 295 minecraft:basalt
setblock 12 176 296 minecraft:polished_basalt
fill 12 176 297 12 176 298 minecraft:basalt
setblock 12 176 299 minecraft:polished_basalt
setblock 12 176 300 minecraft:basalt
fill 12 176 304 12 176 316 minecraft:blackstone
fill 13 176 276 13 176 287 minecraft:blackstone
setblock 13 176 288 minecraft:polished_basalt
setblock 13 176 290 minecraft:basalt
setblock 13 176 291 minecraft:polished_basalt
fill 13 176 293 14 176 293 minecraft:basalt
setblock 13 176 294 minecraft:polished_basalt
setblock 13 176 296 minecraft:basalt
setblock 13 176 297 minecraft:polished_basalt
fill 13 176 298 13 176 299 minecraft:basalt
setblock 13 176 300 minecraft:polished_basalt
setblock 13 176 301 minecraft:basalt
fill 13 176 305 13 176 316 minecraft:blackstone
fill 14 176 276 15 176 286 minecraft:blackstone
fill 14 176 287 14 176 288 minecraft:basalt
setblock 14 176 289 minecraft:polished_basalt
setblock 14 176 290 minecraft:magma_block
fill 14 176 291 15 176 291 minecraft:basalt
setblock 14 176 292 minecraft:polished_basalt
fill 14 176 294 15 176 294 minecraft:basalt
setblock 14 176 295 minecraft:polished_basalt
setblock 14 176 296 minecraft:magma_block
setblock 14 176 297 minecraft:basalt
setblock 14 176 298 minecraft:polished_basalt
fill 14 176 299 14 176 300 minecraft:basalt
setblock 14 176 301 minecraft:polished_basalt
setblock 14 176 302 minecraft:basalt
fill 14 176 306 15 176 316 minecraft:blackstone
setblock 15 176 287 minecraft:polished_basalt
setblock 15 176 288 minecraft:basalt
setblock 15 176 289 minecraft:magma_block
setblock 15 176 290 minecraft:polished_basalt
setblock 15 176 292 minecraft:basalt
setblock 15 176 293 minecraft:polished_basalt
fill 15 176 295 16 176 295 minecraft:basalt
setblock 15 176 296 minecraft:polished_basalt
setblock 15 176 297 minecraft:magma_block
setblock 15 176 298 minecraft:basalt
setblock 15 176 299 minecraft:polished_basalt
fill 15 176 300 15 176 301 minecraft:basalt
setblock 15 176 302 minecraft:polished_basalt
fill 16 176 276 17 176 285 minecraft:blackstone
fill 16 176 286 16 176 287 minecraft:basalt
setblock 16 176 288 minecraft:magma_block
fill 16 176 289 16 176 290 minecraft:basalt
setblock 16 176 291 minecraft:polished_basalt
fill 16 176 292 16 176 294 minecraft:ochre_froglight
setblock 16 176 296 minecraft:basalt
setblock 16 176 297 minecraft:polished_basalt
setblock 16 176 298 minecraft:magma_block
setblock 16 176 299 minecraft:basalt
setblock 16 176 300 minecraft:polished_basalt
fill 16 176 301 16 176 302 minecraft:basalt
setblock 16 176 303 minecraft:polished_basalt
fill 16 176 307 17 176 316 minecraft:blackstone
setblock 17 176 286 minecraft:polished_basalt
setblock 17 176 287 minecraft:magma_block
fill 17 176 288 18 176 288 minecraft:basalt
setblock 17 176 289 minecraft:polished_basalt
fill 17 176 290 17 176 292 minecraft:ochre_froglight
fill 17 176 294 17 176 296 minecraft:ochre_froglight
fill 17 176 297 18 176 297 minecraft:basalt
setblock 17 176 298 minecraft:polished_basalt
setblock 17 176 299 minecraft:magma_block
fill 17 176 300 18 176 300 minecraft:basalt
setblock 17 176 301 minecraft:polished_basalt
fill 17 176 302 17 176 303 minecraft:basalt
fill 18 176 276 41 176 284 minecraft:blackstone
fill 18 176 285 18 176 286 minecraft:basalt
setblock 18 176 287 minecraft:polished_basalt
setblock 18 176 289 minecraft:basalt
fill 18 176 290 19 176 290 minecraft:ochre_froglight
fill 18 176 296 19 176 296 minecraft:ochre_froglight
fill 18 176 298 19 176 298 minecraft:basalt
setblock 18 176 299 minecraft:polished_basalt
fill 18 176 301 19 176 301 minecraft:basalt
setblock 18 176 302 minecraft:polished_basalt
setblock 18 176 303 minecraft:basalt
fill 18 176 308 41 176 316 minecraft:blackstone
setblock 19 176 285 minecraft:polished_basalt
fill 19 176 286 19 176 287 minecraft:basalt
setblock 19 176 288 minecraft:polished_basalt
fill 19 176 289 21 176 289 minecraft:ochre_froglight
fill 19 176 297 21 176 297 minecraft:ochre_froglight
fill 19 176 299 20 176 299 minecraft:basalt
setblock 19 176 300 minecraft:polished_basalt
fill 19 176 302 20 176 302 minecraft:basalt
setblock 19 176 303 minecraft:polished_basalt
fill 20 176 285 21 176 285 minecraft:basalt
setblock 20 176 286 minecraft:polished_basalt
fill 20 176 287 20 176 288 minecraft:basalt
setblock 20 176 298 minecraft:polished_basalt
fill 20 176 300 21 176 300 minecraft:basalt
setblock 20 176 301 minecraft:polished_basalt
fill 20 176 303 21 176 303 minecraft:basalt
setblock 20 176 304 minecraft:polished_basalt
fill 21 176 286 22 176 286 minecraft:basalt
setblock 21 176 287 minecraft:polished_basalt
setblock 21 176 288 minecraft:basalt
fill 21 176 290 23 176 290 minecraft:ochre_froglight
fill 21 176 296 23 176 296 minecraft:ochre_froglight
fill 21 176 298 22 176 298 minecraft:basalt
setblock 21 176 299 minecraft:polished_basalt
fill 21 176 301 22 176 301 minecraft:basalt
setblock 21 176 302 minecraft:polished_basalt
setblock 22 176 285 minecraft:polished_basalt
setblock 22 176 287 minecraft:basalt
setblock 22 176 288 minecraft:polished_basalt
setblock 22 176 289 minecraft:basalt
setblock 22 176 297 minecraft:polished_basalt
setblock 22 176 299 minecraft:basalt
setblock 22 176 300 minecraft:polished_basalt
fill 22 176 302 23 176 302 minecraft:basalt
setblock 22 176 303 minecraft:polished_basalt
fill 23 176 285 24 176 285 minecraft:basalt
setblock 23 176 286 minecraft:polished_basalt
setblock 23 176 287 minecraft:magma_block
setblock 23 176 288 minecraft:basalt
setblock 23 176 289 minecraft:polished_basalt
fill 23 176 291 23 176 292 minecraft:ochre_froglight
fill 23 176 294 23 176 295 minecraft:ochre_froglight
fill 23 176 297 24 176 297 minecraft:basalt
setblock 23 176 298 minecraft:polished_basalt
setblock 23 176 299 minecraft:magma_block
fill 23 176 300 24 176 300 minecraft:basalt
setblock 23 176 301 minecraft:polished_basalt
fill 23 176 303 24 176 303 minecraft:basalt
fill 24 176 286 25 176 286 minecraft:basalt
setblock 24 176 287 minecraft:polished_basalt
setblock 24 176 288 minecraft:magma_block
setblock 24 176 289 minecraft:basalt
setblock 24 176 290 minecraft:polished_basalt
setblock 24 176 291 minecraft:basalt
fill 24 176 292 24 176 294 minecraft:ochre_froglight
fill 24 176 295 25 176 295 minecraft:basalt
setblock 24 176 296 minecraft:polished_basalt
setblock 24 176 298 minecraft:magma_block
setblock 24 176 299 minecraft:polished_basalt
fill 24 176 301 25 176 301 minecraft:basalt
setblock 24 176 302 minecraft:polished_basalt
fill 25 176 285 41 176 285 minecraft:blackstone
fill 25 176 287 26 176 287 minecraft:basalt
setblock 25 176 288 minecraft:polished_basalt
setblock 25 176 289 minecraft:magma_block
setblock 25 176 290 minecraft:basalt
setblock 25 176 291 minecraft:polished_basalt
fill 25 176 292 25 176 293 minecraft:basalt
setblock 25 176 294 minecraft:polished_basalt
setblock 25 176 296 minecraft:basalt
setblock 25 176 297 minecraft:magma_block
fill 25 176 298 25 176 299 minecraft:basalt
setblock 25 176 300 minecraft:polished_basalt
fill 25 176 302 26 176 302 minecraft:basalt
fill 25 176 307 41 176 307 minecraft:blackstone
setblock 26 176 286 minecraft:polished_basalt
fill 26 176 288 27 176 288 minecraft:basalt
setblock 26 176 289 minecraft:polished_basalt
setblock 26 176 290 minecraft:magma_block
fill 26 176 291 27 176 291 minecraft:basalt
setblock 26 176 292 minecraft:polished_basalt
fill 26 176 293 26 176 294 minecraft:basalt
setblock 26 176 295 minecraft:polished_basalt
setblock 26 176 296 minecraft:magma_block
fill 26 176 297 27 176 297 minecraft:basalt
setblock 26 176 298 minecraft:polished_basalt
fill 26 176 299 26 176 300 minecraft:basalt
setblock 26 176 301 minecraft:polished_basalt
fill 27 176 286 41 176 286 minecraft:blackstone
setblock 27 176 287 minecraft:polished_basalt
fill 27 176 289 28 176 289 minecraft:basalt
setblock 27 176 290 minecraft:polished_basalt
fill 27 176 292 28 176 292 minecraft:basalt
setblock 27 176 293 minecraft:polished_basalt
fill 27 176 294 27 176 295 minecraft:basalt
setblock 27 176 296 minecraft:polished_basalt
fill 27 176 298 28 176 298 minecraft:basalt
setblock 27 176 299 minecraft:polished_basalt
fill 27 176 300 27 176 301 minecraft:basalt
setblock 27 176 302 minecraft:light[level=12]
fill 27 176 306 41 176 306 minecraft:blackstone
setblock 28 176 287 minecraft:basalt
setblock 28 176 288 minecraft:polished_basalt
fill 28 176 290 29 176 290 minecraft:basalt
setblock 28 176 291 minecraft:polished_basalt
fill 28 176 293 29 176 293 minecraft:basalt
setblock 28 176 294 minecraft:polished_basalt
fill 28 176 295 28 176 296 minecraft:basalt
setblock 28 176 297 minecraft:polished_basalt
fill 28 176 299 29 176 299 minecraft:basalt
setblock 28 176 300 minecraft:polished_basalt
fill 29 176 287 41 176 287 minecraft:blackstone
setblock 29 176 288 minecraft:basalt
setblock 29 176 289 minecraft:polished_basalt
fill 29 176 291 30 176 291 minecraft:basalt
setblock 29 176 292 minecraft:polished_basalt
fill 29 176 294 30 176 294 minecraft:basalt
setblock 29 176 295 minecraft:polished_basalt
fill 29 176 296 29 176 297 minecraft:basalt
setblock 29 176 298 minecraft:polished_basalt
fill 29 176 305 41 176 305 minecraft:blackstone
fill 30 176 288 41 176 288 minecraft:blackstone
setblock 30 176 289 minecraft:basalt
setblock 30 176 290 minecraft:polished_basalt
setblock 30 176 292 minecraft:basalt
setblock 30 176 293 minecraft:polished_basalt
setblock 30 176 295 minecraft:basalt
setblock 30 176 296 minecraft:polished_basalt
setblock 30 176 297 minecraft:basalt
fill 30 176 304 41 176 304 minecraft:blackstone
fill 31 176 289 41 176 290 minecraft:blackstone
setblock 31 176 293 minecraft:basalt
fill 31 176 302 41 176 303 minecraft:blackstone
fill 32 176 291 41 176 292 minecraft:blackstone
fill 32 176 300 41 176 301 minecraft:blackstone
fill 33 176 293 41 176 299 minecraft:blackstone
fill 42 176 293 42 217 293 minecraft:blackstone
fill 42 176 297 42 219 297 minecraft:blackstone
fill 42 176 311 42 215 311 minecraft:blackstone
fill 11 177 291 13 177 295 minecraft:shroomlight
fill 12 177 289 14 177 290 minecraft:shroomlight
fill 12 177 296 14 177 297 minecraft:shroomlight
fill 13 177 287 15 177 288 minecraft:shroomlight
fill 13 177 298 15 177 299 minecraft:shroomlight
fill 14 177 286 26 177 286 minecraft:shroomlight
fill 14 177 300 26 177 300 minecraft:shroomlight
fill 16 177 285 24 177 285 minecraft:shroomlight
fill 16 177 287 17 177 287 minecraft:shroomlight
fill 16 177 299 17 177 299 minecraft:shroomlight
fill 16 177 301 24 177 301 minecraft:shroomlight
fill 18 177 284 22 177 284 minecraft:shroomlight
fill 18 177 302 22 177 302 minecraft:shroomlight
fill 23 177 287 27 177 287 minecraft:shroomlight
fill 23 177 299 27 177 299 minecraft:shroomlight
fill 25 177 288 27 177 288 minecraft:shroomlight
fill 25 177 298 27 177 298 minecraft:shroomlight
setblock 26 177 275 minecraft:magma_block
fill 26 177 289 28 177 290 minecraft:shroomlight
fill 26 177 296 28 177 297 minecraft:shroomlight
fill 27 177 275 28 192 275 minecraft:blackstone
fill 27 177 291 29 177 295 minecraft:shroomlight
fill 30 177 308 31 177 308 minecraft:bone_block
setblock 31 177 305 minecraft:nether_wart_block
fill 31 177 306 31 177 307 minecraft:red_nether_bricks
fill 32 177 303 32 177 305 minecraft:red_nether_bricks
setblock 32 177 306 minecraft:nether_wart_block
setblock 32 177 307 minecraft:red_nether_bricks
fill 33 177 301 34 177 302 minecraft:red_nether_bricks
setblock 33 177 303 minecraft:nether_wart_block
fill 33 177 304 33 177 306 minecraft:red_nether_bricks
setblock 33 177 307 minecraft:nether_wart_block
setblock 34 177 299 minecraft:red_nether_bricks
setblock 34 177 300 minecraft:nether_wart_block
fill 34 177 303 36 177 303 minecraft:red_nether_bricks
setblock 34 177 304 minecraft:nether_wart_block
fill 34 177 305 34 177 307 minecraft:red_nether_bricks
setblock 35 177 298 minecraft:red_nether_bricks
fill 35 177 299 35 177 302 minecraft:orange_terracotta
fill 35 177 304 36 177 304 minecraft:red_nether_bricks
setblock 35 177 305 minecraft:nether_wart_block
setblock 35 177 306 minecraft:red_nether_bricks
fill 36 177 298 36 177 301 minecraft:orange_terracotta
setblock 36 177 302 minecraft:nether_wart_block
setblock 36 177 305 minecraft:red_nether_bricks
setblock 37 177 298 minecraft:red_nether_bricks
fill 37 177 299 37 177 300 minecraft:orange_terracotta
fill 37 177 301 37 177 302 minecraft:red_nether_bricks
setblock 37 177 303 minecraft:nether_wart_block
fill 42 177 284 42 187 285 minecraft:blackstone
setblock 42 177 286 minecraft:crying_obsidian
fill 42 177 287 42 219 288 minecraft:blackstone
setblock 0 178 305 minecraft:amethyst_block
fill 0 178 306 0 216 309 minecraft:blackstone
fill 11 178 291 13 178 292 minecraft:yellow_wool
fill 11 178 293 13 178 295 minecraft:orange_wool
fill 12 178 289 14 178 290 minecraft:orange_wool
setblock 12 178 296 minecraft:orange_wool
fill 12 178 297 14 178 297 minecraft:yellow_wool
fill 13 178 287 13 178 288 minecraft:orange_wool
fill 13 178 296 14 178 296 minecraft:yellow_wool
setblock 13 178 298 minecraft:yellow_wool
fill 13 178 299 16 178 299 minecraft:orange_wool
fill 14 178 286 15 178 287 minecraft:yellow_wool
setblock 14 178 288 minecraft:orange_wool
fill 14 178 298 15 178 298 minecraft:orange_wool
fill 14 178 300 16 178 300 minecraft:orange_wool
setblock 15 178 288 minecraft:yellow_wool
fill 16 178 285 19 178 286 minecraft:orange_wool
fill 16 178 287 16 179 287 minecraft:yellow_wool
fill 16 178 301 18 178 301 minecraft:yellow_wool
fill 17 178 287 17 179 287 minecraft:orange_wool
fill 17 178 299 17 178 300 minecraft:yellow_wool
fill 18 178 284 18 179 284 minecraft:orange_wool
setblock 18 178 300 minecraft:yellow_wool
fill 18 178 302 22 178 302 minecraft:orange_wool
fill 19 178 284 21 178 284 minecraft:yellow_wool
fill 19 178 300 21 178 301 minecraft:orange_wool
fill 20 178 285 20 178 286 minecraft:yellow_wool
fill 21 178 285 24 178 286 minecraft:orange_wool
fill 22 178 284 22 179 284 minecraft:orange_wool
fill 22 178 300 23 178 301 minecraft:yellow_wool
fill 23 178 287 23 179 287 minecraft:orange_wool
fill 23 178 299 23 179 299 minecraft:yellow_wool
fill 24 178 287 26 178 287 minecraft:yellow_wool
fill 24 178 299 26 178 300 minecraft:orange_wool
fill 24 178 301 24 179 301 minecraft:yellow_wool
fill 25 178 286 26 178 286 minecraft:yellow_wool
setblock 25 178 288 minecraft:yellow_wool
fill 25 178 298 26 178 298 minecraft:orange_wool
fill 26 178 275 26 215 275 minecraft:blackstone
fill 26 178 288 27 178 290 minecraft:orange_wool
fill 26 178 296 27 178 297 minecraft:yellow_wool
setblock 27 178 287 minecraft:orange_wool
fill 27 178 291 29 178 292 minecraft:yellow_wool
fill 27 178 293 29 178 295 minecraft:orange_wool
setblock 27 178 298 minecraft:yellow_wool
setblock 27 178 299 minecraft:orange_wool
fill 28 178 289 28 178 290 minecraft:orange_wool
setblock 28 178 296 minecraft:orange_wool
setblock 28 178 297 minecraft:yellow_wool
fill 32 178 304 34 178 304 minecraft:red_nether_bricks
setblock 32 178 305 minecraft:nether_wart_block
fill 33 178 300 34 178 301 minecraft:red_nether_bricks
setblock 33 178 302 minecraft:nether_wart_block
fill 33 178 303 33 179 303 minecraft:red_nether_bricks
fill 33 178 305 35 178 305 minecraft:red_nether_bricks
setblock 33 178 306 minecraft:nether_wart_block
setblock 34 178 298 minecraft:red_nether_bricks
setblock 34 178 299 minecraft:nether_wart_block
setblock 34 178 302 minecraft:red_nether_bricks
setblock 34 178 303 minecraft:nether_wart_block
setblock 34 178 306 minecraft:red_nether_bricks
setblock 35 178 297 minecraft:red_nether_bricks
fill 35 178 298 36 178 300 minecraft:orange_terracotta
fill 35 178 301 35 180 301 minecraft:red_nether_bricks
fill 35 178 302 35 181 302 minecraft:bone_block
fill 35 178 303 37 178 303 minecraft:red_nether_bricks
setblock 35 178 304 minecraft:nether_wart_block
fill 36 178 295 36 180 297 minecraft:orange_terracotta
setblock 36 178 301 minecraft:nether_wart_block
fill 36 178 302 36 180 302 minecraft:red_nether_bricks
setblock 36 178 304 minecraft:red_nether_bricks
fill 37 178 296 37 179 297 minecraft:orange_terracotta
setblock 37 178 298 minecraft:nether_wart_block
setblock 37 178 299 minecraft:orange_terracotta
fill 37 178 300 38 178 301 minecraft:red_nether_bricks
setblock 37 178 302 minecraft:nether_wart_block
setblock 38 178 298 minecraft:red_nether_bricks
setblock 38 178 299 minecraft:nether_wart_block
fill 42 178 286 42 219 286 minecraft:blackstone
fill 42 178 314 42 187 315 minecraft:blackstone
setblock 42 178 316 minecraft:crying_obsidian
fill 42 178 317 42 221 317 minecraft:blackstone
fill 0 179 305 0 221 305 minecraft:blackstone
fill 7 179 275 10 186 275 minecraft:blackstone
setblock 11 179 275 minecraft:purple_concrete
fill 11 179 293 13 179 293 minecraft:yellow_wool
fill 11 179 294 13 179 295 minecraft:orange_wool
fill 12 179 275 13 219 275 minecraft:blackstone
fill 12 179 289 14 179 289 minecraft:orange_wool
setblock 12 179 290 minecraft:yellow_wool
fill 12 179 296 13 179 296 minecraft:yellow_wool
setblock 13 179 287 minecraft:yellow_wool
setblock 13 179 288 minecraft:orange_wool
fill 13 179 290 14 179 290 minecraft:orange_wool
setblock 13 179 291 minecraft:yellow_wool
setblock 13 179 299 minecraft:yellow_wool
setblock 14 179 288 minecraft:yellow_wool
setblock 14 179 298 minecraft:yellow_wool
fill 14 179 299 15 179 300 minecraft:orange_wool
setblock 15 179 298 minecraft:orange_wool
fill 16 179 285 18 179 285 minecraft:orange_wool
setblock 16 179 286 minecraft:yellow_wool
setblock 16 179 299 minecraft:orange_wool
fill 16 179 300 16 179 301 minecraft:yellow_wool
fill 17 179 286 18 179 286 minecraft:orange_wool
setblock 17 179 299 minecraft:yellow_wool
fill 18 179 301 18 179 302 minecraft:yellow_wool
fill 19 179 284 19 179 286 minecraft:yellow_wool
fill 19 179 300 19 180 300 minecraft:yellow_wool
fill 19 179 301 21 179 302 minecraft:orange_wool
setblock 20 179 300 minecraft:orange_wool
fill 21 179 284 21 179 286 minecraft:yellow_wool
fill 21 179 300 21 180 300 minecraft:yellow_wool
fill 22 179 285 23 179 286 minecraft:orange_wool
fill 22 179 301 22 179 302 minecraft:yellow_wool
setblock 24 179 285 minecraft:orange_wool
fill 24 179 286 24 179 287 minecraft:yellow_wool
fill 24 179 299 26 179 299 minecraft:orange_wool
setblock 24 179 300 minecraft:yellow_wool
setblock 25 179 298 minecraft:orange_wool
fill 25 179 300 26 179 300 minecraft:orange_wool
setblock 26 179 288 minecraft:yellow_wool
fill 26 179 289 27 179 290 minecraft:orange_wool
setblock 26 179 298 minecraft:yellow_wool
setblock 27 179 287 minecraft:yellow_wool
setblock 27 179 288 minecraft:orange_wool
setblock 27 179 291 minecraft:yellow_wool
fill 27 179 293 29 179 293 minecraft:yellow_wool
fill 27 179 294 29 179 295 minecraft:orange_wool
fill 27 179 296 28 179 296 minecraft:yellow_wool
setblock 27 179 299 minecraft:yellow_wool
setblock 28 179 289 minecraft:orange_wool
setblock 28 179 290 minecraft:yellow_wool
setblock 33 179 301 minecraft:nether_wart_block
setblock 33 179 302 minecraft:red_nether_bricks
setblock 34 179 297 minecraft:red_nether_bricks
setblock 34 179 298 minecraft:nether_wart_block
fill 34 179 299 34 179 301 minecraft:red_nether_bricks
setblock 34 179 302 minecraft:nether_wart_block
fill 34 179 303 34 179 304 minecraft:red_nether_bricks
fill 35 179 295 35 179 297 minecraft:orange_terracotta
fill 35 179 298 37 179 298 minecraft:red_nether_bricks
setblock 35 179 299 minecraft:nether_wart_block
fill 35 179 300 35 181 300 minecraft:red_nether_bricks
setblock 35 179 303 minecraft:nether_wart_block
setblock 35 179 304 minecraft:red_nether_bricks
fill 36 179 294 37 179 294 minecraft:red_nether_bricks
fill 36 179 299 38 179 299 minecraft:red_nether_bricks
setblock 36 179 300 minecraft:nether_wart_block
fill 36 179 301 36 180 301 minecraft:red_nether_bricks
setblock 36 179 303 minecraft:red_nether_bricks
fill 37 179 295 37 180 295 minecraft:orange_terracotta
fill 37 179 300 38 179 300 minecraft:red_nether_bricks
setblock 37 179 301 minecraft:nether_wart_block
setblock 37 179 302 minecraft:red_nether_bricks
fill 38 179 296 38 179 297 minecraft:red_nether_bricks
setblock 38 179 298 minecraft:nether_wart_block
setblock 38 179 301 minecraft:red_nether_bricks
setblock 42 179 296 minecraft:crying_obsidian
fill 42 179 316 42 220 316 minecraft:blackstone
setblock 0 180 294 minecraft:purple_concrete
setblock 3 180 278 minecraft:light[level=12]
setblock 3 180 285 minecraft:light[level=12]
setblock 3 180 292 minecraft:light[level=12]
setblock 3 180 299 minecraft:light[level=12]
setblock 3 180 306 minecraft:light[level=12]
setblock 3 180 313 minecraft:light[level=12]
setblock 10 180 278 minecraft:light[level=12]
setblock 10 180 285 minecraft:light[level=12]
setblock 10 180 292 minecraft:light[level=12]
setblock 10 180 299 minecraft:light[level=12]
setblock 10 180 306 minecraft:light[level=12]
setblock 10 180 313 minecraft:light[level=12]
fill 11 180 275 11 219 275 minecraft:blackstone
fill 11 180 294 13 180 295 minecraft:yellow_wool
fill 12 180 289 14 180 289 minecraft:yellow_wool
setblock 13 180 288 minecraft:yellow_wool
fill 13 180 290 14 180 290 minecraft:yellow_wool
fill 14 180 299 15 180 300 minecraft:yellow_wool
setblock 15 180 298 minecraft:yellow_wool
fill 16 180 285 18 180 285 minecraft:yellow_wool
setblock 16 180 299 minecraft:yellow_wool
setblock 17 180 278 minecraft:light[level=12]
fill 17 180 286 17 180 287 minecraft:yellow_wool
setblock 17 180 292 minecraft:light[level=12]
setblock 17 180 299 minecraft:light[level=12]
setblock 17 180 306 minecraft:light[level=12]
setblock 17 180 313 minecraft:light[level=12]
setblock 18 180 284 minecraft:yellow_wool
setblock 18 180 286 minecraft:yellow_wool
fill 19 180 301 21 180 302 minecraft:yellow_wool
setblock 20 180 300 minecraft:yellow_wool
fill 22 180 284 22 180 286 minecraft:yellow_wool
fill 23 180 285 23 180 287 minecraft:yellow_wool
setblock 24 180 278 minecraft:light[level=12]
setblock 24 180 285 minecraft:yellow_wool
setblock 24 180 292 minecraft:light[level=12]
fill 24 180 299 26 180 299 minecraft:yellow_wool
setblock 24 180 306 minecraft:light[level=12]
setblock 24 180 313 minecraft:light[level=12]
setblock 25 180 298 minecraft:yellow_wool
fill 25 180 300 26 180 300 minecraft:yellow_wool
fill 26 180 289 27 180 290 minecraft:yellow_wool
setblock 27 180 288 minecraft:yellow_wool
fill 27 180 294 29 180 295 minecraft:yellow_wool
setblock 28 180 289 minecraft:yellow_wool
setblock 31 180 278 minecraft:light[level=12]
setblock 31 180 285 minecraft:light[level=12]
setblock 31 180 292 minecraft:light[level=12]
setblock 31 180 299 minecraft:light[level=12]
setblock 31 180 306 minecraft:light[level=12]
setblock 31 180 313 minecraft:light[level=12]
fill 34 180 294 34 180 296 minecraft:red_nether_bricks
setblock 34 180 297 minecraft:nether_wart_block
fill 34 180 298 34 180 300 minecraft:red_nether_bricks
setblock 34 180 301 minecraft:nether_wart_block
setblock 34 180 302 minecraft:red_nether_bricks
fill 35 180 292 36 181 294 minecraft:orange_terracotta
fill 35 180 295 35 180 297 minecraft:red_nether_bricks
setblock 35 180 298 minecraft:nether_wart_block
fill 35 180 299 35 181 299 minecraft:red_nether_bricks
fill 36 180 298 38 180 298 minecraft:red_nether_bricks
setblock 36 180 299 minecraft:nether_wart_block
fill 36 180 300 36 181 300 minecraft:red_nether_bricks
fill 37 180 293 37 181 293 minecraft:orange_terracotta
fill 37 180 294 38 181 294 minecraft:red_nether_bricks
setblock 37 180 296 minecraft:orange_terracotta
fill 37 180 297 37 182 297 minecraft:red_nether_bricks
fill 37 180 299 38 180 299 minecraft:red_nether_bricks
setblock 37 180 300 minecraft:nether_wart_block
setblock 37 180 301 minecraft:red_nether_bricks
setblock 38 180 278 minecraft:light[level=12]
setblock 38 180 285 minecraft:light[level=12]
setblock 38 180 292 minecraft:light[level=12]
fill 38 180 295 38 180 296 minecraft:red_nether_bricks
setblock 38 180 297 minecraft:nether_wart_block
setblock 38 180 300 minecraft:red_nether_bricks
setblock 38 180 306 minecraft:light[level=12]
setblock 38 180 313 minecraft:light[level=12]
fill 42 180 296 42 213 296 minecraft:blackstone
fill 0 181 294 0 202 294 minecraft:blackstone
setblock 34 181 291 minecraft:red_nether_bricks
setblock 34 181 292 minecraft:nether_wart_block
fill 34 181 293 34 181 295 minecraft:red_nether_bricks
setblock 34 181 296 minecraft:nether_wart_block
fill 34 181 297 34 181 298 minecraft:red_nether_bricks
fill 35 181 290 35 182 291 minecraft:orange_terracotta
fill 35 181 295 35 181 296 minecraft:red_nether_bricks
setblock 35 181 297 minecraft:nether_wart_block
fill 35 181 298 35 182 298 minecraft:red_nether_bricks
setblock 36 181 290 minecraft:nether_wart_block
fill 36 181 291 36 182 291 minecraft:orange_terracotta
fill 36 181 295 36 184 296 minecraft:bone_block
setblock 36 181 297 minecraft:red_nether_bricks
setblock 36 181 298 minecraft:nether_wart_block
fill 36 181 299 36 182 299 minecraft:red_nether_bricks
setblock 37 181 291 minecraft:nether_wart_block
setblock 37 181 292 minecraft:orange_terracotta
setblock 37 181 295 minecraft:nether_wart_block
fill 37 181 296 37 183 296 minecraft:red_nether_bricks
fill 37 181 298 38 181 298 minecraft:red_nether_bricks
setblock 37 181 299 minecraft:nether_wart_block
setblock 37 181 300 minecraft:red_nether_bricks
setblock 38 181 292 minecraft:nether_wart_block
fill 38 181 293 38 183 293 minecraft:red_nether_bricks
setblock 38 181 295 minecraft:red_nether_bricks
setblock 38 181 296 minecraft:nether_wart_block
fill 38 181 297 38 182 297 minecraft:red_nether_bricks
setblock 38 181 299 minecraft:red_nether_bricks
setblock 0 182 286 minecraft:amethyst_block
setblock 10 182 317 minecraft:purple_concrete
fill 34 182 288 34 183 290 minecraft:orange_terracotta
setblock 34 182 291 minecraft:nether_wart_block
fill 34 182 292 34 182 294 minecraft:red_nether_bricks
setblock 34 182 295 minecraft:nether_wart_block
setblock 34 182 296 minecraft:red_nether_bricks
fill 35 182 288 35 183 289 minecraft:orange_terracotta
fill 35 182 292 36 182 292 minecraft:orange_terracotta
fill 35 182 293 35 182 295 minecraft:red_nether_bricks
setblock 35 182 296 minecraft:nether_wart_block
setblock 35 182 297 minecraft:red_nether_bricks
fill 36 182 289 36 182 290 minecraft:orange_terracotta
setblock 36 182 293 minecraft:orange_terracotta
fill 36 182 294 36 184 294 minecraft:red_nether_bricks
setblock 36 182 297 minecraft:nether_wart_block
setblock 36 182 298 minecraft:red_nether_bricks
setblock 37 182 290 minecraft:nether_wart_block
fill 37 182 291 37 182 293 minecraft:red_nether_bricks
setblock 37 182 294 minecraft:nether_wart_block
fill 37 182 295 37 183 295 minecraft:red_nether_bricks
setblock 37 182 298 minecraft:nether_wart_block
fill 38 182 292 38 183 292 minecraft:red_nether_bricks
setblock 38 182 294 minecraft:red_nether_bricks
setblock 38 182 295 minecraft:nether_wart_block
setblock 38 182 296 minecraft:red_nether_bricks
setblock 42 182 283 minecraft:magma_block
fill 0 183 286 0 219 286 minecraft:blackstone
setblock 3 183 278 minecraft:light[level=12]
setblock 3 183 286 minecraft:light[level=12]
setblock 3 183 294 minecraft:light[level=12]
setblock 3 183 302 minecraft:light[level=12]
setblock 3 183 310 minecraft:light[level=12]
fill 5 183 317 8 206 317 minecraft:blackstone
setblock 9 183 317 minecraft:purple_concrete
fill 10 183 317 10 199 317 minecraft:blackstone
setblock 11 183 278 minecraft:light[level=12]
setblock 11 183 286 minecraft:light[level=12]
setblock 11 183 294 minecraft:light[level=12]
setblock 11 183 302 minecraft:light[level=12]
setblock 11 183 310 minecraft:light[level=12]
setblock 19 183 278 minecraft:light[level=12]
setblock 19 183 286 minecraft:light[level=12]
setblock 19 183 294 minecraft:light[level=12]
setblock 19 183 302 minecraft:light[level=12]
setblock 19 183 310 minecraft:light[level=12]
setblock 27 183 278 minecraft:light[level=12]
setblock 27 183 286 minecraft:light[level=12]
setblock 27 183 294 minecraft:light[level=12]
setblock 27 183 302 minecraft:light[level=12]
setblock 27 183 310 minecraft:light[level=12]
fill 33 183 286 33 185 287 minecraft:orange_terracotta
setblock 33 183 288 minecraft:red_nether_bricks
setblock 33 183 289 minecraft:orange_terracotta
fill 33 183 290 33 183 292 minecraft:red_nether_bricks
setblock 34 183 287 minecraft:red_nether_bricks
fill 34 183 291 34 183 293 minecraft:red_nether_bricks
setblock 34 183 294 minecraft:nether_wart_block
setblock 35 183 278 minecraft:light[level=12]
setblock 35 183 286 minecraft:light[level=12]
setblock 35 183 287 minecraft:nether_wart_block
fill 35 183 290 36 183 290 minecraft:orange_terracotta
setblock 35 183 291 minecraft:nether_wart_block
fill 35 183 292 35 183 294 minecraft:red_nether_bricks
setblock 35 183 295 minecraft:nether_wart_block
setblock 35 183 296 minecraft:red_nether_bricks
setblock 35 183 302 minecraft:light[level=12]
setblock 35 183 310 minecraft:light[level=12]
setblock 36 183 288 minecraft:nether_wart_block
fill 36 183 289 36 185 289 minecraft:red_nether_bricks
fill 36 183 291 38 183 291 minecraft:red_nether_bricks
setblock 36 183 292 minecraft:nether_wart_block
fill 36 183 293 36 185 293 minecraft:red_nether_bricks
setblock 36 183 297 minecraft:red_nether_bricks
setblock 37 183 289 minecraft:nether_wart_block
fill 37 183 290 37 185 290 minecraft:red_nether_bricks
setblock 37 183 292 minecraft:red_nether_bricks
setblock 37 183 293 minecraft:nether_wart_block
fill 37 183 294 37 184 294 minecraft:red_nether_bricks
setblock 38 183 294 minecraft:nether_wart_block
setblock 38 183 295 minecraft:red_nether_bricks
fill 42 183 283 42 222 283 minecraft:blackstone
fill 9 184 317 9 219 317 minecraft:blackstone
setblock 31 184 286 minecraft:nether_wart_block
fill 32 184 285 32 185 287 minecraft:orange_terracotta
fill 32 184 288 32 185 289 minecraft:red_nether_bricks
fill 33 184 285 33 185 285 minecraft:orange_terracotta
fill 33 184 288 34 184 288 minecraft:orange_terracotta
fill 33 184 289 33 184 291 minecraft:red_nether_bricks
setblock 34 184 285 minecraft:nether_wart_block
fill 34 184 286 34 184 287 minecraft:orange_terracotta
fill 34 184 289 35 184 289 minecraft:orange_terracotta
fill 34 184 290 34 184 292 minecraft:red_nether_bricks
setblock 34 184 293 minecraft:nether_wart_block
fill 34 184 308 35 185 309 minecraft:gold_block
setblock 35 184 286 minecraft:nether_wart_block
fill 35 184 287 35 185 288 minecraft:red_nether_bricks
setblock 35 184 290 minecraft:nether_wart_block
fill 35 184 291 35 184 293 minecraft:red_nether_bricks
setblock 35 184 294 minecraft:nether_wart_block
setblock 36 184 287 minecraft:nether_wart_block
fill 36 184 288 36 186 288 minecraft:red_nether_bricks
setblock 36 184 290 minecraft:red_nether_bricks
setblock 36 184 291 minecraft:nether_wart_block
fill 36 184 292 36 185 292 minecraft:red_nether_bricks
fill 36 184 309 36 185 309 minecraft:gold_block
fill 37 184 289 37 185 289 minecraft:red_nether_bricks
setblock 37 184 291 minecraft:red_nether_bricks
setblock 37 184 292 minecraft:nether_wart_block
setblock 37 184 293 minecraft:red_nether_bricks
fill 11 185 283 11 186 285 minecraft:raw_gold_block
fill 12 185 284 12 186 285 minecraft:raw_gold_block
setblock 25 185 275 minecraft:amethyst_block
fill 30 185 284 31 186 285 minecraft:orange_terracotta
fill 30 185 286 30 186 286 minecraft:red_nether_bricks
setblock 31 185 286 minecraft:orange_terracotta
fill 31 185 287 31 185 288 minecraft:red_nether_bricks
fill 32 185 284 33 186 284 minecraft:red_nether_bricks
fill 33 185 288 33 185 290 minecraft:red_nether_bricks
setblock 33 185 291 minecraft:nether_wart_block
fill 34 185 285 34 186 286 minecraft:red_nether_bricks
setblock 34 185 287 minecraft:orange_terracotta
setblock 34 185 288 minecraft:nether_wart_block
fill 34 185 289 34 188 289 minecraft:bone_block
fill 34 185 290 35 185 291 minecraft:red_nether_bricks
setblock 34 185 292 minecraft:nether_wart_block
fill 35 185 286 35 187 286 minecraft:red_nether_bricks
setblock 35 185 289 minecraft:nether_wart_block
setblock 35 185 292 minecraft:red_nether_bricks
setblock 35 185 293 minecraft:nether_wart_block
fill 36 185 287 36 186 287 minecraft:red_nether_bricks
setblock 36 185 290 minecraft:nether_wart_block
setblock 36 185 291 minecraft:red_nether_bricks
setblock 37 185 291 minecraft:nether_wart_block
setblock 37 185 292 minecraft:red_nether_bricks
setblock 3 186 278 minecraft:light[level=12]
setblock 3 186 285 minecraft:light[level=12]
setblock 3 186 292 minecraft:light[level=12]
setblock 3 186 299 minecraft:light[level=12]
setblock 3 186 306 minecraft:light[level=12]
setblock 3 186 313 minecraft:light[level=12]
setblock 10 186 278 minecraft:light[level=12]
setblock 10 186 285 minecraft:light[level=12]
setblock 10 186 292 minecraft:light[level=12]
setblock 10 186 299 minecraft:light[level=12]
setblock 10 186 306 minecraft:light[level=12]
setblock 10 186 313 minecraft:light[level=12]
fill 17 186 276 17 191 276 minecraft:amethyst_block
setblock 17 186 278 minecraft:light[level=12]
setblock 17 186 285 minecraft:light[level=12]
setblock 17 186 292 minecraft:light[level=12]
setblock 17 186 299 minecraft:light[level=12]
setblock 17 186 306 minecraft:light[level=12]
setblock 17 186 313 minecraft:light[level=12]
setblock 20 186 275 minecraft:crying_obsidian
setblock 24 186 278 minecraft:light[level=12]
setblock 24 186 285 minecraft:light[level=12]
setblock 24 186 292 minecraft:light[level=12]
setblock 24 186 299 minecraft:light[level=12]
setblock 24 186 306 minecraft:light[level=12]
setblock 24 186 313 minecraft:light[level=12]
fill 25 186 275 25 192 275 minecraft:blackstone
fill 29 186 283 29 187 284 minecraft:orange_terracotta
setblock 29 186 285 minecraft:red_nether_bricks
setblock 30 186 282 minecraft:red_nether_bricks
fill 30 186 283 31 186 283 minecraft:orange_terracotta
setblock 30 186 287 minecraft:nether_wart_block
setblock 31 186 278 minecraft:light[level=12]
fill 31 186 286 31 186 287 minecraft:red_nether_bricks
setblock 31 186 288 minecraft:nether_wart_block
setblock 31 186 292 minecraft:light[level=12]
setblock 31 186 299 minecraft:light[level=12]
setblock 31 186 306 minecraft:light[level=12]
setblock 31 186 313 minecraft:light[level=12]
fill 32 186 283 32 187 283 minecraft:red_nether_bricks
setblock 32 186 285 minecraft:nether_wart_block
setblock 32 186 286 minecraft:orange_terracotta
fill 32 186 287 33 186 288 minecraft:red_nether_bricks
setblock 32 186 289 minecraft:nether_wart_block
setblock 33 186 285 minecraft:red_nether_bricks
setblock 33 186 286 minecraft:nether_wart_block
setblock 33 186 289 minecraft:red_nether_bricks
setblock 33 186 290 minecraft:nether_wart_block
fill 34 186 284 34 187 284 minecraft:red_nether_bricks
setblock 34 186 287 minecraft:nether_wart_block
fill 34 186 288 34 187 288 minecraft:red_nether_bricks
fill 34 186 290 36 186 290 minecraft:red_nether_bricks
setblock 34 186 291 minecraft:nether_wart_block
setblock 35 186 287 minecraft:red_nether_bricks
setblock 35 186 288 minecraft:nether_wart_block
fill 35 186 289 35 187 289 minecraft:red_nether_bricks
setblock 35 186 291 minecraft:red_nether_bricks
setblock 36 186 289 minecraft:nether_wart_block
setblock 38 186 278 minecraft:light[level=12]
setblock 38 186 285 minecraft:light[level=12]
setblock 38 186 292 minecraft:light[level=12]
setblock 38 186 299 minecraft:light[level=12]
setblock 38 186 306 minecraft:light[level=12]
setblock 38 186 313 minecraft:light[level=12]
fill 40 186 300 40 188 300 minecraft:amethyst_block
fill 42 186 301 42 187 301 minecraft:amethyst_block
fill 7 187 275 7 205 275 minecraft:blackstone
setblock 8 187 275 minecraft:magma_block
fill 9 187 275 10 209 275 minecraft:blackstone
fill 15 187 276 16 190 276 minecraft:amethyst_block
fill 16 187 277 18 190 277 minecraft:amethyst_block
fill 17 187 278 17 191 278 minecraft:amethyst_block
fill 18 187 276 19 190 276 minecraft:amethyst_block
fill 20 187 275 20 219 275 minecraft:blackstone
fill 26 187 277 26 191 277 minecraft:polished_blackstone
fill 26 187 282 28 189 282 minecraft:orange_terracotta
fill 27 187 283 28 188 283 minecraft:orange_terracotta
setblock 28 187 281 minecraft:red_nether_bricks
setblock 28 187 284 minecraft:nether_wart_block
fill 28 187 285 28 189 285 minecraft:red_nether_bricks
setblock 29 187 281 minecraft:nether_wart_block
fill 29 187 282 29 189 282 minecraft:red_nether_bricks
setblock 29 187 285 minecraft:nether_wart_block
fill 29 187 286 29 188 286 minecraft:red_nether_bricks
setblock 30 187 282 minecraft:nether_wart_block
fill 30 187 283 30 187 284 minecraft:orange_terracotta
fill 30 187 285 32 187 285 minecraft:red_nether_bricks
setblock 30 187 286 minecraft:nether_wart_block
setblock 30 187 287 minecraft:red_nether_bricks
setblock 31 187 282 minecraft:red_nether_bricks
setblock 31 187 283 minecraft:nether_wart_block
setblock 31 187 284 minecraft:orange_terracotta
fill 31 187 286 33 187 286 minecraft:red_nether_bricks
setblock 31 187 287 minecraft:nether_wart_block
setblock 31 187 288 minecraft:red_nether_bricks
setblock 32 187 284 minecraft:nether_wart_block
fill 32 187 287 34 187 287 minecraft:red_nether_bricks
setblock 32 187 288 minecraft:nether_wart_block
fill 33 187 283 33 187 284 minecraft:red_nether_bricks
setblock 33 187 285 minecraft:nether_wart_block
setblock 33 187 288 minecraft:red_nether_bricks
setblock 33 187 289 minecraft:nether_wart_block
setblock 34 187 285 minecraft:red_nether_bricks
setblock 34 187 286 minecraft:nether_wart_block
setblock 35 187 287 minecraft:nether_wart_block
setblock 35 187 288 minecraft:red_nether_bricks
fill 39 187 300 39 188 300 minecraft:amethyst_block
fill 40 187 299 42 188 299 minecraft:amethyst_block
fill 40 187 301 41 188 301 minecraft:amethyst_block
fill 41 187 300 42 188 300 minecraft:amethyst_block
fill 8 188 275 8 215 275 minecraft:blackstone
fill 15 188 277 15 189 277 minecraft:amethyst_block
fill 16 188 278 16 190 278 minecraft:amethyst_block
fill 17 188 279 17 191 279 minecraft:amethyst_block
fill 18 188 278 18 190 278 minecraft:amethyst_block
fill 19 188 277 19 189 277 minecraft:amethyst_block
fill 25 188 281 25 188 282 minecraft:red_nether_bricks
fill 26 188 281 28 188 281 minecraft:orange_terracotta
setblock 26 188 283 minecraft:orange_terracotta
fill 27 188 284 28 189 284 minecraft:red_nether_bricks
fill 29 188 281 29 190 281 minecraft:red_nether_bricks
setblock 29 188 283 minecraft:red_nether_bricks
setblock 29 188 284 minecraft:nether_wart_block
fill 29 188 285 29 190 285 minecraft:red_nether_bricks
setblock 30 188 281 minecraft:nether_wart_block
fill 30 188 282 30 190 282 minecraft:red_nether_bricks
fill 30 188 283 30 191 284 minecraft:bone_block
setblock 30 188 285 minecraft:nether_wart_block
fill 30 188 286 30 189 286 minecraft:red_nether_bricks
setblock 31 188 282 minecraft:nether_wart_block
fill 31 188 283 31 188 285 minecraft:red_nether_bricks
setblock 31 188 286 minecraft:nether_wart_block
setblock 31 188 287 minecraft:red_nether_bricks
setblock 32 188 283 minecraft:nether_wart_block
fill 32 188 284 32 188 286 minecraft:red_nether_bricks
setblock 32 188 287 minecraft:nether_wart_block
setblock 33 188 284 minecraft:nether_wart_block
fill 33 188 285 33 188 287 minecraft:red_nether_bricks
setblock 34 188 285 minecraft:nether_wart_block
fill 34 188 286 34 188 287 minecraft:red_nether_bricks
setblock 42 188 284 minecraft:amethyst_block
fill 42 188 285 42 219 285 minecraft:blackstone
fill 42 188 301 42 199 301 minecraft:blackstone
setblock 42 188 314 minecraft:purple_concrete
fill 42 188 315 42 219 315 minecraft:blackstone
fill 16 189 279 16 190 279 minecraft:amethyst_block
fill 17 189 280 17 191 280 minecraft:amethyst_block
fill 18 189 279 18 190 279 minecraft:amethyst_block
fill 23 189 281 25 190 282 minecraft:orange_terracotta
fill 24 189 280 24 190 280 minecraft:orange_terracotta
fill 24 189 283 24 191 283 minecraft:red_nether_bricks
fill 25 189 280 25 191 280 minecraft:red_nether_bricks
setblock 25 189 283 minecraft:nether_wart_block
setblock 26 189 280 minecraft:nether_wart_block
fill 26 189 281 27 189 281 minecraft:orange_terracotta
setblock 26 189 283 minecraft:red_nether_bricks
setblock 26 189 284 minecraft:nether_wart_block
fill 27 189 280 28 189 280 minecraft:red_nether_bricks
setblock 27 189 283 minecraft:orange_terracotta
setblock 28 189 281 minecraft:red_nether_bricks
fill 28 189 283 28 191 283 minecraft:red_nether_bricks
setblock 29 189 283 minecraft:nether_wart_block
fill 29 189 284 29 191 284 minecraft:red_nether_bricks
setblock 30 189 281 minecraft:red_nether_bricks
fill 30 189 285 30 190 285 minecraft:red_nether_bricks
fill 31 189 282 31 189 284 minecraft:red_nether_bricks
setblock 31 189 285 minecraft:nether_wart_block
setblock 31 189 286 minecraft:red_nether_bricks
fill 32 189 283 32 189 285 minecraft:red_nether_bricks
setblock 32 189 286 minecraft:nether_wart_block
setblock 41 189 301 minecraft:amethyst_block
fill 42 189 284 42 219 284 minecraft:blackstone
fill 42 189 299 42 192 300 minecraft:blackstone
fill 42 189 314 42 220 314 minecraft:blackstone
fill 2 190 275 2 219 275 minecraft:blackstone
setblock 3 190 275 minecraft:magma_block
setblock 3 190 278 minecraft:light[level=12]
setblock 3 190 286 minecraft:light[level=12]
setblock 3 190 294 minecraft:light[level=12]
setblock 3 190 302 minecraft:light[level=12]
setblock 3 190 310 minecraft:light[level=12]
setblock 11 190 278 minecraft:light[level=12]
setblock 11 190 286 minecraft:light[level=12]
setblock 11 190 294 minecraft:light[level=12]
setblock 11 190 302 minecraft:light[level=12]
setblock 11 190 310 minecraft:light[level=12]
setblock 16 190 280 minecraft:amethyst_block
fill 17 190 281 17 191 281 minecraft:amethyst_block
setblock 18 190 280 minecraft:amethyst_block
setblock 19 190 278 minecraft:light[level=12]
setblock 19 190 286 minecraft:light[level=12]
setblock 19 190 294 minecraft:light[level=12]
setblock 19 190 302 minecraft:light[level=12]
setblock 19 190 310 minecraft:light[level=12]
fill 21 190 280 22 190 280 minecraft:red_nether_bricks
fill 21 190 281 22 191 281 minecraft:orange_terracotta
setblock 22 190 282 minecraft:red_nether_bricks
fill 23 190 279 25 190 279 minecraft:red_nether_bricks
fill 23 190 280 23 191 280 minecraft:orange_terracotta
setblock 23 190 283 minecraft:red_nether_bricks
fill 25 190 277 25 191 277 minecraft:polished_blackstone
fill 25 190 283 25 190 284 minecraft:red_nether_bricks
fill 26 190 276 26 191 276 minecraft:polished_blackstone
fill 26 190 278 26 191 278 minecraft:polished_blackstone
setblock 26 190 279 minecraft:nether_wart_block
fill 26 190 280 26 190 282 minecraft:red_nether_bricks
setblock 26 190 283 minecraft:nether_wart_block
fill 26 190 284 26 191 284 minecraft:red_nether_bricks
fill 27 190 277 27 191 277 minecraft:polished_blackstone
setblock 27 190 278 minecraft:light[level=12]
setblock 27 190 280 minecraft:nether_wart_block
fill 27 190 281 27 190 283 minecraft:red_nether_bricks
setblock 27 190 284 minecraft:nether_wart_block
setblock 27 190 286 minecraft:light[level=12]
setblock 27 190 294 minecraft:light[level=12]
setblock 27 190 302 minecraft:light[level=12]
setblock 27 190 310 minecraft:light[level=12]
setblock 28 190 280 minecraft:red_nether_bricks
setblock 28 190 281 minecraft:nether_wart_block
fill 28 190 282 28 192 282 minecraft:red_nether_bricks
setblock 28 190 284 minecraft:red_nether_bricks
setblock 28 190 285 minecraft:nether_wart_block
setblock 29 190 282 minecraft:nether_wart_block
fill 29 190 283 29 191 283 minecraft:red_nether_bricks
setblock 31 190 283 minecraft:red_nether_bricks
setblock 31 190 284 minecraft:nether_wart_block
setblock 35 190 278 minecraft:light[level=12]
setblock 35 190 286 minecraft:light[level=12]
setblock 35 190 294 minecraft:light[level=12]
setblock 35 190 302 minecraft:light[level=12]
setblock 35 190 310 minecraft:light[level=12]
fill 3 191 275 3 215 275 minecraft:blackstone
setblock 17 191 277 minecraft:amethyst_block
setblock 17 191 282 minecraft:amethyst_block
fill 18 191 283 19 192 284 minecraft:gold_block
fill 19 191 280 20 192 281 minecraft:orange_terracotta
fill 20 191 282 21 191 282 minecraft:orange_terracotta
fill 21 191 279 22 192 279 minecraft:red_nether_bricks
fill 21 191 280 21 192 280 minecraft:orange_terracotta
fill 22 191 280 22 192 280 minecraft:red_nether_bricks
setblock 22 191 282 minecraft:nether_wart_block
fill 22 191 283 22 193 283 minecraft:red_nether_bricks
setblock 23 191 279 minecraft:nether_wart_block
fill 23 191 281 24 191 281 minecraft:orange_terracotta
fill 23 191 282 25 191 282 minecraft:red_nether_bricks
setblock 23 191 283 minecraft:nether_wart_block
fill 24 191 279 26 191 279 minecraft:red_nether_bricks
setblock 24 191 280 minecraft:nether_wart_block
setblock 25 191 276 minecraft:polished_blackstone
setblock 25 191 278 minecraft:polished_blackstone
setblock 25 191 281 minecraft:nether_wart_block
fill 25 191 283 26 192 283 minecraft:red_nether_bricks
fill 26 191 280 27 191 281 minecraft:red_nether_bricks
setblock 26 191 282 minecraft:nether_wart_block
setblock 27 191 276 minecraft:polished_blackstone
setblock 27 191 278 minecraft:polished_blackstone
setblock 27 191 282 minecraft:red_nether_bricks
setblock 27 191 283 minecraft:nether_wart_block
setblock 27 191 284 minecraft:red_nether_bricks
setblock 28 191 281 minecraft:red_nether_bricks
setblock 28 191 284 minecraft:nether_wart_block
setblock 29 191 281 minecraft:nether_wart_block
setblock 29 191 282 minecraft:red_nether_bricks
setblock 0 192 302 minecraft:amethyst_block
fill 0 192 303 0 216 303 minecraft:blackstone
setblock 3 192 278 minecraft:light[level=12]
setblock 3 192 285 minecraft:light[level=12]
setblock 3 192 292 minecraft:light[level=12]
setblock 3 192 299 minecraft:light[level=12]
setblock 3 192 306 minecraft:light[level=12]
setblock 3 192 313 minecraft:light[level=12]
setblock 10 192 278 minecraft:light[level=12]
setblock 10 192 285 minecraft:light[level=12]
setblock 10 192 292 minecraft:light[level=12]
setblock 10 192 299 minecraft:light[level=12]
setblock 10 192 306 minecraft:light[level=12]
setblock 10 192 313 minecraft:light[level=12]
setblock 17 192 278 minecraft:light[level=12]
fill 17 192 281 17 194 282 minecraft:orange_terracotta
setblock 17 192 285 minecraft:light[level=12]
setblock 17 192 292 minecraft:light[level=12]
setblock 17 192 299 minecraft:light[level=12]
setblock 17 192 306 minecraft:light[level=12]
setblock 17 192 313 minecraft:light[level=12]
setblock 18 192 280 minecraft:red_nether_bricks
fill 18 192 281 18 194 281 minecraft:orange_terracotta
setblock 18 192 282 minecraft:red_nether_bricks
fill 19 192 279 19 194 279 minecraft:red_nether_bricks
fill 19 192 282 20 192 282 minecraft:orange_terracotta
setblock 20 192 279 minecraft:nether_wart_block
setblock 20 192 283 minecraft:nether_wart_block
setblock 21 192 281 minecraft:orange_terracotta
fill 21 192 282 21 192 283 minecraft:red_nether_bricks
setblock 22 192 281 minecraft:nether_wart_block
fill 22 192 282 22 194 282 minecraft:red_nether_bricks
fill 23 192 279 23 193 280 minecraft:red_nether_bricks
fill 23 192 281 23 195 281 minecraft:bone_block
setblock 23 192 282 minecraft:nether_wart_block
fill 23 192 283 23 193 283 minecraft:red_nether_bricks
setblock 24 192 278 minecraft:light[level=12]
setblock 24 192 279 minecraft:nether_wart_block
fill 24 192 280 24 192 282 minecraft:red_nether_bricks
setblock 24 192 283 minecraft:nether_wart_block
setblock 24 192 285 minecraft:light[level=12]
setblock 24 192 292 minecraft:light[level=12]
setblock 24 192 299 minecraft:light[level=12]
setblock 24 192 306 minecraft:light[level=12]
setblock 24 192 313 minecraft:light[level=12]
setblock 25 192 279 minecraft:red_nether_bricks
setblock 25 192 280 minecraft:nether_wart_block
fill 25 192 281 25 193 282 minecraft:red_nether_bricks
setblock 26 192 280 minecraft:red_nether_bricks
setblock 26 192 281 minecraft:nether_wart_block
setblock 26 192 282 minecraft:red_nether_bricks
setblock 27 192 281 minecraft:red_nether_bricks
setblock 27 192 282 minecraft:nether_wart_block
setblock 27 192 283 minecraft:red_nether_bricks
setblock 31 192 278 minecraft:light[level=12]
setblock 31 192 285 minecraft:light[level=12]
setblock 31 192 292 minecraft:light[level=12]
setblock 31 192 299 minecraft:light[level=12]
setblock 31 192 306 minecraft:light[level=12]
setblock 31 192 313 minecraft:light[level=12]
setblock 38 192 278 minecraft:light[level=12]
setblock 38 192 285 minecraft:light[level=12]
setblock 38 192 292 minecraft:light[level=12]
setblock 38 192 299 minecraft:light[level=12]
setblock 38 192 306 minecraft:light[level=12]
setblock 38 192 313 minecraft:light[level=12]
fill 0 193 302 0 219 302 minecraft:blackstone
setblock 15 193 281 minecraft:nether_wart_block
fill 15 193 282 16 194 282 minecraft:orange_terracotta
fill 16 193 280 16 194 280 minecraft:red_nether_bricks
fill 16 193 281 16 194 281 minecraft:orange_terracotta
fill 16 193 283 16 195 283 minecraft:red_nether_bricks
fill 17 193 275 18 216 275 minecraft:blackstone
setblock 17 193 280 minecraft:orange_terracotta
setblock 17 193 283 minecraft:nether_wart_block
setblock 18 193 279 minecraft:red_nether_bricks
setblock 18 193 280 minecraft:nether_wart_block
setblock 18 193 282 minecraft:orange_terracotta
fill 18 193 283 20 193 283 minecraft:red_nether_bricks
setblock 19 193 275 minecraft:purple_concrete
fill 19 193 280 21 193 280 minecraft:red_nether_bricks
fill 19 193 281 20 193 281 minecraft:orange_terracotta
fill 19 193 282 19 195 282 minecraft:red_nether_bricks
fill 20 193 279 20 195 279 minecraft:red_nether_bricks
setblock 20 193 282 minecraft:nether_wart_block
setblock 21 193 279 minecraft:nether_wart_block
fill 21 193 281 21 193 282 minecraft:red_nether_bricks
setblock 21 193 283 minecraft:nether_wart_block
setblock 22 193 279 minecraft:red_nether_bricks
setblock 22 193 280 minecraft:nether_wart_block
fill 22 193 281 22 195 281 minecraft:red_nether_bricks
fill 23 193 282 23 194 282 minecraft:red_nether_bricks
fill 24 193 279 24 193 281 minecraft:red_nether_bricks
setblock 24 193 282 minecraft:nether_wart_block
setblock 24 193 283 minecraft:red_nether_bricks
setblock 25 193 275 minecraft:purple_concrete
setblock 25 193 280 minecraft:red_nether_bricks
setblock 26 193 281 minecraft:red_nether_bricks
fill 27 193 275 27 219 275 minecraft:blackstone
setblock 28 193 275 minecraft:amethyst_block
setblock 42 193 299 minecraft:magma_block
fill 42 193 300 42 220 300 minecraft:blackstone
fill 13 194 282 14 196 283 minecraft:orange_terracotta
fill 14 194 281 14 195 281 minecraft:red_nether_bricks
setblock 15 194 280 minecraft:nether_wart_block
setblock 15 194 281 minecraft:orange_terracotta
fill 15 194 283 15 195 283 minecraft:orange_terracotta
fill 17 194 279 17 195 280 minecraft:red_nether_bricks
fill 17 194 283 17 196 283 minecraft:red_nether_bricks
setblock 18 194 279 minecraft:nether_wart_block
fill 18 194 280 18 196 280 minecraft:red_nether_bricks
setblock 18 194 282 minecraft:red_nether_bricks
setblock 18 194 283 minecraft:nether_wart_block
fill 19 194 275 19 219 275 minecraft:blackstone
setblock 19 194 280 minecraft:nether_wart_block
fill 19 194 281 19 196 281 minecraft:red_nether_bricks
fill 19 194 283 21 194 283 minecraft:red_nether_bricks
fill 20 194 280 22 194 280 minecraft:red_nether_bricks
setblock 20 194 281 minecraft:nether_wart_block
fill 20 194 282 20 195 282 minecraft:red_nether_bricks
setblock 21 194 279 minecraft:red_nether_bricks
setblock 21 194 281 minecraft:red_nether_bricks
setblock 21 194 282 minecraft:nether_wart_block
setblock 22 194 279 minecraft:nether_wart_block
setblock 23 194 280 minecraft:nether_wart_block
setblock 24 194 281 minecraft:nether_wart_block
fill 25 194 275 25 219 275 minecraft:blackstone
fill 28 194 275 28 219 275 minecraft:blackstone
fill 42 194 299 42 220 299 minecraft:blackstone
fill 12 195 282 12 196 282 minecraft:red_nether_bricks
fill 12 195 283 12 196 283 minecraft:orange_terracotta
setblock 12 195 284 minecraft:nether_wart_block
setblock 13 195 281 minecraft:nether_wart_block
fill 13 195 284 14 195 284 minecraft:orange_terracotta
fill 14 195 280 15 196 280 minecraft:red_nether_bricks
fill 15 195 281 15 196 281 minecraft:red_nether_bricks
setblock 15 195 282 minecraft:orange_terracotta
fill 15 195 284 15 197 284 minecraft:red_nether_bricks
setblock 16 195 279 minecraft:red_nether_bricks
setblock 16 195 280 minecraft:nether_wart_block
fill 16 195 281 16 198 282 minecraft:bone_block
setblock 16 195 284 minecraft:nether_wart_block
setblock 17 195 281 minecraft:nether_wart_block
fill 17 195 282 17 197 282 minecraft:red_nether_bricks
setblock 17 195 284 minecraft:red_nether_bricks
setblock 18 195 279 minecraft:red_nether_bricks
setblock 18 195 281 minecraft:red_nether_bricks
setblock 18 195 282 minecraft:nether_wart_block
fill 18 195 283 18 196 283 minecraft:red_nether_bricks
setblock 19 195 279 minecraft:nether_wart_block
fill 19 195 280 19 196 280 minecraft:red_nether_bricks
setblock 19 195 283 minecraft:nether_wart_block
setblock 20 195 280 minecraft:nether_wart_block
fill 20 195 281 20 196 281 minecraft:red_nether_bricks
setblock 21 195 280 minecraft:red_nether_bricks
setblock 21 195 281 minecraft:nether_wart_block
setblock 21 195 282 minecraft:red_nether_bricks
setblock 42 195 298 minecraft:amethyst_block
fill 10 196 284 12 197 285 minecraft:orange_terracotta
setblock 11 196 282 minecraft:nether_wart_block
fill 11 196 283 11 198 283 minecraft:red_nether_bricks
fill 12 196 281 13 197 281 minecraft:red_nether_bricks
setblock 13 196 284 minecraft:orange_terracotta
fill 13 196 285 13 198 285 minecraft:red_nether_bricks
setblock 14 196 281 minecraft:nether_wart_block
setblock 14 196 284 minecraft:red_nether_bricks
setblock 14 196 285 minecraft:nether_wart_block
setblock 15 196 282 minecraft:nether_wart_block
fill 15 196 283 15 198 283 minecraft:red_nether_bricks
fill 16 196 280 16 197 280 minecraft:red_nether_bricks
setblock 16 196 283 minecraft:nether_wart_block
fill 16 196 284 16 197 284 minecraft:red_nether_bricks
setblock 17 196 280 minecraft:nether_wart_block
fill 17 196 281 17 197 281 minecraft:red_nether_bricks
setblock 18 196 281 minecraft:nether_wart_block
fill 18 196 282 18 197 282 minecraft:red_nether_bricks
setblock 19 196 282 minecraft:nether_wart_block
setblock 30 196 317 minecraft:purple_concrete
fill 42 196 298 42 215 298 minecraft:blackstone
setblock 0 197 300 minecraft:amethyst_block
fill 3 197 278 3 198 278 minecraft:light[level=12]
setblock 3 197 286 minecraft:light[level=12]
setblock 3 197 294 minecraft:light[level=12]
setblock 3 197 302 minecraft:light[level=12]
setblock 3 197 310 minecraft:light[level=12]
fill 9 197 284 9 199 284 minecraft:red_nether_bricks
setblock 9 197 285 minecraft:orange_terracotta
setblock 9 197 286 minecraft:red_nether_bricks
setblock 9 197 287 minecraft:nether_wart_block
setblock 10 197 283 minecraft:red_nether_bricks
fill 10 197 286 11 198 286 minecraft:orange_terracotta
fill 10 197 287 11 197 287 minecraft:red_nether_bricks
setblock 11 197 278 minecraft:light[level=12]
fill 11 197 282 11 199 282 minecraft:red_nether_bricks
setblock 11 197 294 minecraft:light[level=12]
setblock 11 197 302 minecraft:light[level=12]
setblock 11 197 310 minecraft:light[level=12]
setblock 12 197 282 minecraft:nether_wart_block
fill 12 197 283 12 199 283 minecraft:red_nether_bricks
setblock 12 197 286 minecraft:nether_wart_block
fill 13 197 282 15 197 282 minecraft:red_nether_bricks
setblock 13 197 283 minecraft:nether_wart_block
fill 13 197 284 13 199 284 minecraft:red_nether_bricks
setblock 13 197 286 minecraft:red_nether_bricks
setblock 14 197 280 minecraft:nether_wart_block
fill 14 197 281 14 198 281 minecraft:red_nether_bricks
setblock 14 197 283 minecraft:red_nether_bricks
setblock 14 197 284 minecraft:nether_wart_block
fill 14 197 285 14 198 285 minecraft:red_nether_bricks
setblock 15 197 280 minecraft:red_nether_bricks
setblock 15 197 281 minecraft:nether_wart_block
fill 16 197 283 16 198 283 minecraft:red_nether_bricks
setblock 17 197 280 minecraft:red_nether_bricks
setblock 17 197 283 minecraft:nether_wart_block
setblock 18 197 281 minecraft:red_nether_bricks
setblock 19 197 278 minecraft:light[level=12]
setblock 19 197 286 minecraft:light[level=12]
setblock 19 197 294 minecraft:light[level=12]
setblock 19 197 302 minecraft:light[level=12]
setblock 19 197 310 minecraft:light[level=12]
setblock 27 197 278 minecraft:light[level=12]
setblock 27 197 286 minecraft:light[level=12]
setblock 27 197 294 minecraft:light[level=12]
setblock 27 197 302 minecraft:light[level=12]
setblock 27 197 310 minecraft:light[level=12]
fill 30 197 317 30 216 317 minecraft:blackstone
setblock 35 197 278 minecraft:light[level=12]
setblock 35 197 286 minecraft:light[level=12]
setblock 35 197 294 minecraft:light[level=12]
setblock 35 197 302 minecraft:light[level=12]
setblock 35 197 310 minecraft:light[level=12]
fill 0 198 300 0 209 300 minecraft:blackstone
setblock 3 198 285 minecraft:light[level=12]
setblock 3 198 292 minecraft:light[level=12]
setblock 3 198 299 minecraft:light[level=12]
setblock 3 198 306 minecraft:light[level=12]
setblock 3 198 313 minecraft:light[level=12]
setblock 8 198 285 minecraft:nether_wart_block
fill 8 198 286 8 198 289 minecraft:orange_terracotta
fill 9 198 283 9 199 283 minecraft:red_nether_bricks
setblock 9 198 285 minecraft:red_nether_bricks
fill 9 198 286 9 199 288 minecraft:orange_terracotta
setblock 10 198 278 minecraft:light[level=12]
setblock 10 198 283 minecraft:nether_wart_block
fill 10 198 284 10 200 284 minecraft:red_nether_bricks
fill 10 198 285 11 198 285 minecraft:orange_terracotta
setblock 10 198 287 minecraft:orange_terracotta
fill 10 198 288 10 200 288 minecraft:red_nether_bricks
setblock 10 198 292 minecraft:light[level=12]
setblock 10 198 299 minecraft:light[level=12]
setblock 10 198 306 minecraft:light[level=12]
setblock 10 198 313 minecraft:light[level=12]
setblock 11 198 284 minecraft:nether_wart_block
fill 11 198 287 12 198 287 minecraft:red_nether_bricks
setblock 12 198 281 minecraft:nether_wart_block
fill 12 198 282 12 199 282 minecraft:red_nether_bricks
setblock 12 198 284 minecraft:red_nether_bricks
setblock 12 198 285 minecraft:nether_wart_block
fill 12 198 286 12 200 286 minecraft:red_nether_bricks
setblock 13 198 281 minecraft:red_nether_bricks
setblock 13 198 282 minecraft:nether_wart_block
fill 13 198 283 13 199 283 minecraft:red_nether_bricks
setblock 13 198 286 minecraft:nether_wart_block
setblock 14 198 275 minecraft:amethyst_block
fill 14 198 282 15 198 282 minecraft:red_nether_bricks
setblock 14 198 283 minecraft:nether_wart_block
fill 14 198 284 14 199 284 minecraft:red_nether_bricks
setblock 15 198 281 minecraft:red_nether_bricks
setblock 15 198 284 minecraft:nether_wart_block
setblock 17 198 278 minecraft:light[level=12]
setblock 17 198 285 minecraft:light[level=12]
setblock 17 198 292 minecraft:light[level=12]
setblock 17 198 299 minecraft:light[level=12]
setblock 17 198 306 minecraft:light[level=12]
setblock 17 198 313 minecraft:light[level=12]
setblock 24 198 278 minecraft:light[level=12]
setblock 24 198 285 minecraft:light[level=12]
setblock 24 198 292 minecraft:light[level=12]
setblock 24 198 299 minecraft:light[level=12]
setblock 24 198 306 minecraft:light[level=12]
setblock 24 198 313 minecraft:light[level=12]
setblock 31 198 278 minecraft:light[level=12]
setblock 31 198 285 minecraft:light[level=12]
setblock 31 198 292 minecraft:light[level=12]
setblock 31 198 299 minecraft:light[level=12]
setblock 31 198 306 minecraft:light[level=12]
setblock 31 198 313 minecraft:light[level=12]
setblock 38 198 278 minecraft:light[level=12]
setblock 38 198 285 minecraft:light[level=12]
setblock 38 198 292 minecraft:light[level=12]
setblock 38 198 299 minecraft:light[level=12]
setblock 38 198 306 minecraft:light[level=12]
setblock 38 198 313 minecraft:light[level=12]
fill 38 198 315 38 203 315 minecraft:amethyst_block
fill 6 199 288 6 200 288 minecraft:red_nether_bricks
fill 7 199 286 8 199 286 minecraft:red_nether_bricks
setblock 7 199 287 minecraft:nether_wart_block
fill 7 199 288 8 199 288 minecraft:orange_terracotta
setblock 7 199 289 minecraft:red_nether_bricks
fill 7 199 290 7 201 290 minecraft:orange_terracotta
setblock 8 199 284 minecraft:nether_wart_block
fill 8 199 285 8 201 285 minecraft:red_nether_bricks
setblock 8 199 287 minecraft:orange_terracotta
fill 8 199 289 9 199 289 minecraft:orange_terracotta
setblock 8 199 290 minecraft:red_nether_bricks
setblock 9 199 285 minecraft:nether_wart_block
fill 10 199 283 10 200 283 minecraft:red_nether_bricks
fill 10 199 285 10 202 285 minecraft:bone_block
setblock 10 199 286 minecraft:nether_wart_block
fill 10 199 287 10 201 287 minecraft:red_nether_bricks
setblock 10 199 289 minecraft:red_nether_bricks
setblock 11 199 283 minecraft:nether_wart_block
fill 11 199 284 11 199 286 minecraft:red_nether_bricks
setblock 11 199 287 minecraft:nether_wart_block
fill 11 199 288 11 200 288 minecraft:red_nether_bricks
setblock 12 199 284 minecraft:nether_wart_block
fill 12 199 285 12 200 285 minecraft:red_nether_bricks
setblock 12 199 287 minecraft:red_nether_bricks
setblock 13 199 282 minecraft:red_nether_bricks
setblock 13 199 285 minecraft:nether_wart_block
setblock 13 199 286 minecraft:red_nether_bricks
fill 14 199 275 14 219 275 minecraft:blackstone
setblock 14 199 282 minecraft:nether_wart_block
setblock 14 199 283 minecraft:red_nether_bricks
setblock 23 199 317 minecraft:purple_concrete
fill 24 199 317 26 216 317 minecraft:blackstone
fill 36 199 315 37 202 315 minecraft:amethyst_block
fill 37 199 314 39 202 314 minecraft:amethyst_block
fill 37 199 316 39 202 316 minecraft:amethyst_block
fill 38 199 313 38 203 313 minecraft:amethyst_block
fill 38 199 317 38 217 317 minecraft:blackstone
fill 39 199 315 40 202 315 minecraft:amethyst_block
setblock 39 199 317 minecraft:purple_concrete
fill 40 199 317 40 216 317 minecraft:blackstone
setblock 42 199 302 minecraft:magma_block
fill 6 200 287 7 201 287 minecraft:red_nether_bricks
setblock 6 200 289 minecraft:nether_wart_block
fill 6 200 290 6 201 292 minecraft:orange_terracotta
setblock 7 200 286 minecraft:nether_wart_block
fill 7 200 288 7 201 288 minecraft:red_nether_bricks
fill 7 200 289 8 200 289 minecraft:orange_terracotta
fill 7 200 291 7 201 292 minecraft:orange_terracotta
fill 8 200 286 10 200 286 minecraft:red_nether_bricks
schedule function dropper:buildpart/60_4 1t
