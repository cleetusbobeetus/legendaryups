setblock 142 162 354 minecraft:purple_concrete
setblock 142 162 363 minecraft:dark_prismarine
setblock 143 162 323 minecraft:blue_terracotta
setblock 143 162 363 minecraft:blue_terracotta
fill 145 162 362 147 162 362 minecraft:blue_terracotta
setblock 146 162 324 minecraft:dark_prismarine
setblock 147 162 323 minecraft:dark_prismarine
fill 147 162 324 147 162 325 minecraft:blue_terracotta
fill 147 162 348 147 185 349 minecraft:magenta_terracotta
setblock 147 162 363 minecraft:dark_prismarine
setblock 148 162 323 minecraft:blue_terracotta
setblock 148 162 361 minecraft:blue_terracotta
setblock 148 162 362 minecraft:dark_prismarine
setblock 148 162 363 minecraft:blue_terracotta
setblock 149 162 361 minecraft:dark_prismarine
setblock 149 162 362 minecraft:blue_terracotta
setblock 150 162 325 minecraft:dark_prismarine
setblock 150 162 361 minecraft:blue_terracotta
setblock 151 162 324 minecraft:dark_prismarine
setblock 151 162 325 minecraft:blue_terracotta
setblock 152 162 323 minecraft:dark_prismarine
setblock 152 162 324 minecraft:blue_terracotta
fill 152 162 334 152 181 334 minecraft:magenta_terracotta
setblock 152 162 363 minecraft:dark_prismarine
setblock 153 162 323 minecraft:blue_terracotta
setblock 153 162 362 minecraft:dark_prismarine
setblock 153 162 363 minecraft:blue_terracotta
setblock 154 162 361 minecraft:dark_prismarine
fill 154 162 362 157 162 362 minecraft:blue_terracotta
setblock 155 162 357 minecraft:magenta_terracotta
fill 156 162 358 156 186 358 minecraft:magenta_terracotta
setblock 157 162 323 minecraft:dark_prismarine
setblock 157 162 363 minecraft:dark_prismarine
setblock 158 162 323 minecraft:blue_terracotta
setblock 158 162 362 minecraft:dark_prismarine
fill 158 162 363 161 162 363 minecraft:blue_terracotta
setblock 162 162 363 minecraft:dark_prismarine
setblock 163 162 362 minecraft:dark_prismarine
setblock 163 162 363 minecraft:blue_terracotta
setblock 164 162 362 minecraft:blue_terracotta
fill 165 162 323 166 162 323 minecraft:blue_terracotta
setblock 167 162 323 minecraft:dark_prismarine
fill 167 162 329 168 180 329 minecraft:magenta_terracotta
setblock 167 162 363 minecraft:dark_prismarine
setblock 168 162 323 minecraft:blue_terracotta
setblock 168 162 362 minecraft:dark_prismarine
setblock 168 162 363 minecraft:blue_terracotta
setblock 169 162 362 minecraft:blue_terracotta
fill 171 162 352 172 178 352 minecraft:magenta_terracotta
setblock 172 162 323 minecraft:dark_prismarine
setblock 172 162 363 minecraft:dark_prismarine
setblock 173 162 323 minecraft:blue_terracotta
setblock 173 162 362 minecraft:dark_prismarine
setblock 173 162 363 minecraft:blue_terracotta
fill 177 162 338 178 185 338 minecraft:magenta_terracotta
setblock 177 162 363 minecraft:purple_concrete
setblock 182 162 332 minecraft:purple_concrete
setblock 182 162 338 minecraft:dark_prismarine
setblock 182 162 339 minecraft:blue_terracotta
setblock 182 162 343 minecraft:dark_prismarine
setblock 182 162 344 minecraft:blue_terracotta
setblock 182 162 346 minecraft:blue_terracotta
setblock 182 162 351 minecraft:purple_concrete
fill 141 163 345 141 220 345 minecraft:blue_terracotta
setblock 170 163 322 minecraft:cyan_concrete
fill 171 163 322 175 208 322 minecraft:blue_terracotta
fill 183 163 342 183 220 342 minecraft:blue_terracotta
fill 155 164 357 155 187 357 minecraft:magenta_terracotta
fill 169 164 328 169 211 328 minecraft:magenta_terracotta
fill 170 164 322 170 218 322 minecraft:blue_terracotta
fill 143 165 364 143 179 364 minecraft:blue_terracotta
setblock 144 165 325 minecraft:light[level=13]
setblock 144 165 333 minecraft:light[level=13]
setblock 144 165 341 minecraft:light[level=13]
setblock 144 165 349 minecraft:light[level=13]
setblock 144 165 357 minecraft:light[level=13]
setblock 144 165 364 minecraft:cyan_concrete
fill 145 165 364 147 189 364 minecraft:blue_terracotta
fill 147 165 347 147 223 347 minecraft:magenta_terracotta
setblock 152 165 325 minecraft:light[level=13]
setblock 152 165 341 minecraft:light[level=13]
setblock 152 165 349 minecraft:light[level=13]
setblock 152 165 357 minecraft:light[level=13]
setblock 160 165 325 minecraft:light[level=13]
setblock 160 165 333 minecraft:light[level=13]
setblock 160 165 341 minecraft:light[level=13]
setblock 160 165 349 minecraft:light[level=13]
setblock 160 165 357 minecraft:light[level=13]
setblock 168 165 325 minecraft:light[level=13]
setblock 168 165 333 minecraft:light[level=13]
setblock 168 165 341 minecraft:light[level=13]
setblock 168 165 349 minecraft:light[level=13]
setblock 168 165 357 minecraft:light[level=13]
fill 170 165 352 170 187 352 minecraft:magenta_terracotta
setblock 176 165 325 minecraft:light[level=13]
setblock 176 165 333 minecraft:light[level=13]
setblock 176 165 341 minecraft:light[level=13]
setblock 176 165 349 minecraft:light[level=13]
setblock 176 165 357 minecraft:light[level=13]
fill 144 166 364 144 220 364 minecraft:blue_terracotta
fill 176 166 338 176 214 338 minecraft:magenta_terracotta
fill 142 167 322 144 185 322 minecraft:blue_terracotta
setblock 144 167 325 minecraft:light[level=12]
setblock 144 167 332 minecraft:light[level=12]
setblock 144 167 339 minecraft:light[level=12]
setblock 144 167 346 minecraft:light[level=12]
setblock 144 167 353 minecraft:light[level=12]
setblock 144 167 360 minecraft:light[level=12]
setblock 145 167 322 minecraft:light_blue_wool
setblock 151 167 325 minecraft:light[level=12]
setblock 151 167 332 minecraft:light[level=12]
setblock 151 167 339 minecraft:light[level=12]
setblock 151 167 346 minecraft:light[level=12]
setblock 151 167 353 minecraft:light[level=12]
setblock 151 167 360 minecraft:light[level=12]
setblock 158 167 325 minecraft:light[level=12]
setblock 158 167 332 minecraft:light[level=12]
setblock 158 167 339 minecraft:light[level=12]
setblock 158 167 346 minecraft:light[level=12]
setblock 158 167 353 minecraft:light[level=12]
setblock 158 167 360 minecraft:light[level=12]
setblock 158 167 364 minecraft:cyan_concrete
fill 161 167 341 161 182 344 minecraft:white_concrete
fill 162 167 340 162 182 340 minecraft:white_concrete
fill 162 167 344 162 182 345 minecraft:white_concrete
fill 163 167 345 164 182 345 minecraft:white_concrete
setblock 165 167 325 minecraft:light[level=12]
setblock 165 167 332 minecraft:light[level=12]
setblock 165 167 339 minecraft:light[level=12]
setblock 165 167 346 minecraft:light[level=12]
setblock 165 167 353 minecraft:light[level=12]
setblock 165 167 360 minecraft:light[level=12]
setblock 170 167 364 minecraft:cyan_concrete
setblock 172 167 325 minecraft:light[level=12]
setblock 172 167 332 minecraft:light[level=12]
setblock 172 167 339 minecraft:light[level=12]
setblock 172 167 346 minecraft:light[level=12]
setblock 172 167 360 minecraft:light[level=12]
setblock 179 167 325 minecraft:light[level=12]
setblock 179 167 332 minecraft:light[level=12]
setblock 179 167 339 minecraft:light[level=12]
setblock 179 167 346 minecraft:light[level=12]
setblock 179 167 353 minecraft:light[level=12]
setblock 179 167 360 minecraft:light[level=12]
fill 145 168 322 145 185 322 minecraft:blue_terracotta
fill 158 168 364 158 181 364 minecraft:blue_terracotta
fill 159 168 340 160 182 345 minecraft:white_concrete
fill 160 168 339 166 182 339 minecraft:white_concrete
fill 160 168 346 166 182 346 minecraft:white_concrete
fill 161 168 338 165 182 338 minecraft:white_concrete
fill 161 168 340 161 182 340 minecraft:white_concrete
fill 161 168 345 161 182 345 minecraft:white_concrete
fill 161 168 347 165 182 347 minecraft:white_concrete
fill 165 168 345 167 182 345 minecraft:white_concrete
fill 166 168 340 167 182 340 minecraft:white_concrete
fill 166 168 344 167 182 344 minecraft:white_concrete
fill 167 168 341 167 182 343 minecraft:white_concrete
fill 170 168 353 170 203 353 minecraft:magenta_terracotta
fill 170 168 364 170 183 364 minecraft:blue_terracotta
setblock 141 169 343 minecraft:cyan_concrete
fill 154 169 334 154 190 334 minecraft:magenta_terracotta
fill 157 169 341 158 182 344 minecraft:white_concrete
fill 158 169 339 158 182 340 minecraft:white_concrete
fill 158 169 345 158 182 346 minecraft:white_concrete
fill 159 169 338 159 182 339 minecraft:white_concrete
fill 159 169 346 159 182 347 minecraft:white_concrete
fill 160 169 338 160 182 338 minecraft:white_concrete
fill 160 169 347 160 182 347 minecraft:white_concrete
fill 161 169 337 165 181 337 minecraft:white_concrete
fill 161 169 348 165 182 348 minecraft:white_concrete
fill 166 169 338 167 181 338 minecraft:white_concrete
fill 166 169 347 167 181 347 minecraft:white_concrete
fill 167 169 339 168 181 339 minecraft:white_concrete
fill 167 169 346 168 181 346 minecraft:white_concrete
fill 168 169 327 168 234 327 minecraft:magenta_terracotta
fill 168 169 340 168 181 345 minecraft:white_concrete
fill 169 169 341 169 180 344 minecraft:white_concrete
setblock 174 169 364 minecraft:cyan_concrete
fill 141 170 343 141 217 343 minecraft:blue_terracotta
fill 156 170 342 156 181 343 minecraft:white_concrete
fill 157 170 339 157 181 340 minecraft:white_concrete
fill 157 170 345 157 181 346 minecraft:white_concrete
fill 158 170 338 158 181 338 minecraft:white_concrete
fill 158 170 347 158 181 347 minecraft:white_concrete
fill 159 170 337 160 181 337 minecraft:white_concrete
fill 159 170 348 160 181 348 minecraft:white_concrete
fill 161 170 336 165 181 336 minecraft:white_concrete
fill 161 170 349 165 181 349 minecraft:white_concrete
fill 166 170 337 167 180 337 minecraft:white_concrete
fill 166 170 348 167 181 348 minecraft:white_concrete
fill 168 170 338 168 181 338 minecraft:white_concrete
fill 168 170 347 168 181 347 minecraft:white_concrete
fill 169 170 339 169 180 340 minecraft:white_concrete
fill 169 170 345 169 181 346 minecraft:white_concrete
fill 170 170 342 170 181 343 minecraft:white_concrete
fill 174 170 364 174 220 364 minecraft:blue_terracotta
fill 183 170 340 183 220 340 minecraft:blue_terracotta
setblock 183 170 341 minecraft:light_blue_wool
fill 141 171 328 141 180 331 minecraft:blue_terracotta
setblock 141 171 332 minecraft:light_blue_wool
fill 156 171 340 156 180 341 minecraft:white_concrete
fill 156 171 344 156 180 345 minecraft:white_concrete
fill 157 171 338 157 180 338 minecraft:white_concrete
fill 157 171 347 157 180 347 minecraft:white_concrete
fill 158 171 337 158 180 337 minecraft:white_concrete
fill 158 171 348 158 180 348 minecraft:white_concrete
fill 159 171 336 160 180 336 minecraft:white_concrete
fill 159 171 349 160 180 349 minecraft:white_concrete
fill 161 171 335 165 180 335 minecraft:white_concrete
fill 161 171 350 165 180 350 minecraft:white_concrete
fill 166 171 336 167 180 336 minecraft:white_concrete
fill 166 171 349 167 180 349 minecraft:white_concrete
fill 168 171 337 168 180 337 minecraft:white_concrete
fill 168 171 348 168 180 348 minecraft:white_concrete
fill 169 171 338 169 180 338 minecraft:white_concrete
fill 169 171 347 169 180 347 minecraft:white_concrete
fill 170 171 340 170 180 341 minecraft:white_concrete
fill 170 171 344 170 180 345 minecraft:white_concrete
fill 183 171 341 183 220 341 minecraft:blue_terracotta
setblock 183 171 351 minecraft:light_blue_wool
fill 183 171 352 183 218 352 minecraft:blue_terracotta
fill 141 172 332 141 220 332 minecraft:blue_terracotta
setblock 141 172 338 minecraft:light_blue_wool
setblock 141 172 340 minecraft:light_blue_wool
fill 141 172 341 141 221 341 minecraft:blue_terracotta
fill 153 172 364 155 211 364 minecraft:blue_terracotta
fill 154 172 333 154 206 333 minecraft:magenta_terracotta
fill 155 172 341 155 179 344 minecraft:white_concrete
fill 156 172 339 156 179 339 minecraft:white_concrete
fill 156 172 346 156 179 346 minecraft:white_concrete
setblock 156 172 364 minecraft:light_blue_wool
fill 157 172 337 157 179 337 minecraft:white_concrete
fill 157 172 348 157 179 348 minecraft:white_concrete
fill 158 172 336 158 179 336 minecraft:white_concrete
fill 158 172 349 158 179 349 minecraft:white_concrete
fill 160 172 335 160 179 335 minecraft:white_concrete
fill 160 172 350 160 179 350 minecraft:white_concrete
fill 166 172 335 166 179 335 minecraft:white_concrete
fill 166 172 350 166 179 350 minecraft:white_concrete
fill 168 172 336 168 179 336 minecraft:white_concrete
fill 168 172 349 168 179 349 minecraft:white_concrete
fill 169 172 337 169 179 337 minecraft:white_concrete
fill 169 172 348 169 179 348 minecraft:white_concrete
fill 170 172 339 170 179 339 minecraft:white_concrete
fill 170 172 346 170 179 346 minecraft:white_concrete
fill 171 172 341 171 179 344 minecraft:white_concrete
fill 171 172 354 171 205 354 minecraft:magenta_terracotta
setblock 183 172 349 minecraft:light_blue_wool
fill 183 172 351 183 220 351 minecraft:blue_terracotta
fill 141 173 338 141 220 338 minecraft:blue_terracotta
fill 141 173 340 141 220 340 minecraft:blue_terracotta
setblock 144 173 325 minecraft:light[level=13]
setblock 144 173 332 minecraft:light[level=12]
setblock 144 173 333 minecraft:light[level=13]
setblock 144 173 339 minecraft:light[level=12]
setblock 144 173 341 minecraft:light[level=13]
setblock 144 173 346 minecraft:light[level=12]
setblock 144 173 349 minecraft:light[level=13]
setblock 144 173 353 minecraft:light[level=12]
setblock 144 173 357 minecraft:light[level=13]
setblock 144 173 360 minecraft:light[level=12]
setblock 151 173 325 minecraft:light[level=12]
setblock 151 173 332 minecraft:light[level=12]
setblock 151 173 339 minecraft:light[level=12]
setblock 151 173 346 minecraft:light[level=12]
setblock 151 173 353 minecraft:light[level=12]
setblock 151 173 360 minecraft:light[level=12]
setblock 152 173 325 minecraft:light[level=13]
setblock 152 173 341 minecraft:light[level=13]
setblock 152 173 349 minecraft:light[level=13]
setblock 152 173 357 minecraft:light[level=13]
fill 155 173 340 155 178 340 minecraft:white_concrete
fill 155 173 345 155 178 345 minecraft:white_concrete
fill 156 173 338 156 178 338 minecraft:white_concrete
fill 156 173 347 156 178 347 minecraft:white_concrete
fill 156 173 364 156 218 364 minecraft:blue_terracotta
setblock 158 173 325 minecraft:light[level=12]
setblock 158 173 332 minecraft:light[level=12]
setblock 158 173 353 minecraft:light[level=12]
setblock 158 173 360 minecraft:light[level=12]
fill 159 173 335 159 178 335 minecraft:white_concrete
fill 159 173 350 159 178 350 minecraft:white_concrete
setblock 160 173 325 minecraft:light[level=13]
setblock 160 173 333 minecraft:light[level=13]
setblock 160 173 357 minecraft:light[level=13]
fill 162 173 334 164 178 334 minecraft:white_concrete
fill 162 173 351 164 178 351 minecraft:white_concrete
setblock 165 173 325 minecraft:light[level=12]
setblock 165 173 332 minecraft:light[level=12]
setblock 165 173 353 minecraft:light[level=12]
setblock 165 173 360 minecraft:light[level=12]
fill 167 173 335 167 178 335 minecraft:white_concrete
fill 167 173 350 167 178 350 minecraft:white_concrete
setblock 168 173 325 minecraft:light[level=13]
setblock 168 173 333 minecraft:light[level=13]
setblock 168 173 357 minecraft:light[level=13]
fill 170 173 338 170 178 338 minecraft:white_concrete
fill 170 173 347 170 178 347 minecraft:white_concrete
fill 171 173 340 171 178 340 minecraft:white_concrete
fill 171 173 345 171 178 345 minecraft:white_concrete
setblock 172 173 325 minecraft:light[level=12]
setblock 172 173 332 minecraft:light[level=12]
setblock 172 173 339 minecraft:light[level=12]
setblock 172 173 346 minecraft:light[level=12]
setblock 172 173 360 minecraft:light[level=12]
setblock 176 173 325 minecraft:light[level=13]
setblock 176 173 333 minecraft:light[level=13]
setblock 176 173 341 minecraft:light[level=13]
setblock 176 173 349 minecraft:light[level=13]
setblock 176 173 357 minecraft:light[level=13]
setblock 179 173 325 minecraft:light[level=12]
setblock 179 173 332 minecraft:light[level=12]
setblock 179 173 339 minecraft:light[level=12]
setblock 179 173 346 minecraft:light[level=12]
setblock 179 173 353 minecraft:light[level=12]
setblock 179 173 360 minecraft:light[level=12]
fill 183 173 349 183 217 349 minecraft:blue_terracotta
fill 155 174 339 155 177 339 minecraft:white_concrete
fill 155 174 346 155 177 346 minecraft:white_concrete
fill 157 174 336 157 177 336 minecraft:white_concrete
fill 157 174 349 157 177 349 minecraft:white_concrete
fill 161 174 334 161 177 334 minecraft:white_concrete
fill 161 174 351 161 177 351 minecraft:white_concrete
fill 165 174 334 165 177 334 minecraft:white_concrete
fill 165 174 351 165 177 351 minecraft:white_concrete
fill 169 174 336 169 177 336 minecraft:white_concrete
fill 169 174 349 169 177 349 minecraft:white_concrete
fill 171 174 339 171 177 339 minecraft:white_concrete
fill 171 174 346 171 177 346 minecraft:white_concrete
fill 183 174 345 183 217 347 minecraft:blue_terracotta
setblock 183 174 348 minecraft:light_blue_wool
setblock 142 175 323 minecraft:magenta_terracotta
fill 142 175 324 142 175 327 minecraft:purple_terracotta
setblock 142 175 328 minecraft:magenta_terracotta
fill 142 175 329 142 175 332 minecraft:purple_terracotta
setblock 142 175 333 minecraft:magenta_terracotta
fill 142 175 334 142 175 337 minecraft:purple_terracotta
setblock 142 175 338 minecraft:magenta_terracotta
fill 142 175 339 142 175 342 minecraft:purple_terracotta
setblock 142 175 343 minecraft:magenta_terracotta
fill 142 175 344 142 175 347 minecraft:purple_terracotta
setblock 142 175 348 minecraft:magenta_terracotta
fill 142 175 349 142 175 352 minecraft:purple_terracotta
setblock 142 175 353 minecraft:magenta_terracotta
fill 142 175 354 142 175 357 minecraft:purple_terracotta
setblock 142 175 358 minecraft:magenta_terracotta
fill 142 175 359 142 175 362 minecraft:purple_terracotta
setblock 142 175 363 minecraft:magenta_terracotta
fill 143 175 323 146 175 323 minecraft:purple_terracotta
setblock 143 175 324 minecraft:magenta_terracotta
fill 143 175 325 143 175 328 minecraft:purple_terracotta
setblock 143 175 329 minecraft:magenta_terracotta
fill 143 175 330 143 175 333 minecraft:purple_terracotta
setblock 143 175 334 minecraft:magenta_terracotta
fill 143 175 335 143 175 338 minecraft:purple_terracotta
setblock 143 175 339 minecraft:magenta_terracotta
fill 143 175 340 143 175 343 minecraft:purple_terracotta
setblock 143 175 344 minecraft:magenta_terracotta
fill 143 175 345 143 175 348 minecraft:purple_terracotta
setblock 143 175 349 minecraft:magenta_terracotta
fill 143 175 350 143 175 353 minecraft:purple_terracotta
setblock 143 175 354 minecraft:magenta_terracotta
fill 143 175 355 143 175 358 minecraft:purple_terracotta
setblock 143 175 359 minecraft:magenta_terracotta
fill 143 175 360 143 175 363 minecraft:purple_terracotta
fill 144 175 324 147 175 324 minecraft:purple_terracotta
setblock 144 175 325 minecraft:magenta_terracotta
fill 144 175 326 144 175 329 minecraft:purple_terracotta
setblock 144 175 330 minecraft:magenta_terracotta
fill 144 175 331 144 175 334 minecraft:purple_terracotta
setblock 144 175 335 minecraft:magenta_terracotta
fill 144 175 336 144 175 339 minecraft:purple_terracotta
setblock 144 175 340 minecraft:magenta_terracotta
fill 144 175 341 144 175 344 minecraft:purple_terracotta
setblock 144 175 345 minecraft:magenta_terracotta
fill 144 175 346 144 175 349 minecraft:purple_terracotta
setblock 144 175 350 minecraft:magenta_terracotta
fill 144 175 351 144 175 354 minecraft:purple_terracotta
setblock 144 175 355 minecraft:magenta_terracotta
fill 144 175 356 144 175 359 minecraft:purple_terracotta
setblock 144 175 360 minecraft:magenta_terracotta
fill 144 175 361 144 175 363 minecraft:purple_terracotta
fill 145 175 325 148 175 325 minecraft:purple_terracotta
setblock 145 175 326 minecraft:magenta_terracotta
fill 145 175 327 145 175 330 minecraft:purple_terracotta
setblock 145 175 331 minecraft:magenta_terracotta
fill 145 175 332 145 175 335 minecraft:purple_terracotta
setblock 145 175 336 minecraft:magenta_terracotta
fill 145 175 337 145 175 340 minecraft:purple_terracotta
setblock 145 175 341 minecraft:magenta_terracotta
fill 145 175 342 145 175 345 minecraft:purple_terracotta
setblock 145 175 346 minecraft:magenta_terracotta
fill 145 175 347 145 175 350 minecraft:purple_terracotta
setblock 145 175 351 minecraft:magenta_terracotta
fill 145 175 352 145 175 355 minecraft:purple_terracotta
setblock 145 175 356 minecraft:magenta_terracotta
fill 145 175 357 145 175 360 minecraft:purple_terracotta
setblock 145 175 361 minecraft:magenta_terracotta
fill 145 175 362 145 175 363 minecraft:purple_terracotta
fill 146 175 326 149 175 326 minecraft:purple_terracotta
setblock 146 175 327 minecraft:magenta_terracotta
fill 146 175 328 146 175 331 minecraft:purple_terracotta
setblock 146 175 332 minecraft:magenta_terracotta
fill 146 175 333 146 175 336 minecraft:purple_terracotta
setblock 146 175 337 minecraft:magenta_terracotta
fill 146 175 338 146 175 341 minecraft:purple_terracotta
setblock 146 175 342 minecraft:magenta_terracotta
fill 146 175 343 146 175 346 minecraft:purple_terracotta
setblock 146 175 347 minecraft:magenta_terracotta
fill 146 175 350 148 175 351 minecraft:purple_terracotta
setblock 146 175 352 minecraft:magenta_terracotta
fill 146 175 353 146 175 356 minecraft:purple_terracotta
setblock 146 175 357 minecraft:magenta_terracotta
fill 146 175 358 146 175 361 minecraft:purple_terracotta
setblock 146 175 362 minecraft:magenta_terracotta
setblock 146 175 363 minecraft:purple_terracotta
setblock 147 175 323 minecraft:magenta_terracotta
fill 147 175 327 150 175 327 minecraft:purple_terracotta
setblock 147 175 328 minecraft:magenta_terracotta
fill 147 175 329 147 175 332 minecraft:purple_terracotta
setblock 147 175 333 minecraft:magenta_terracotta
fill 147 175 334 147 175 337 minecraft:purple_terracotta
setblock 147 175 338 minecraft:magenta_terracotta
fill 147 175 339 147 175 342 minecraft:purple_terracotta
setblock 147 175 343 minecraft:magenta_terracotta
fill 147 175 344 147 175 346 minecraft:purple_terracotta
fill 147 175 352 150 175 352 minecraft:purple_terracotta
setblock 147 175 353 minecraft:magenta_terracotta
fill 147 175 354 147 175 357 minecraft:purple_terracotta
setblock 147 175 358 minecraft:magenta_terracotta
fill 147 175 359 147 175 362 minecraft:purple_terracotta
setblock 147 175 363 minecraft:magenta_terracotta
fill 148 175 323 151 175 323 minecraft:purple_terracotta
setblock 148 175 324 minecraft:magenta_terracotta
fill 148 175 328 151 175 328 minecraft:purple_terracotta
setblock 148 175 329 minecraft:magenta_terracotta
fill 148 175 330 148 175 333 minecraft:purple_terracotta
setblock 148 175 334 minecraft:magenta_terracotta
fill 148 175 335 148 175 338 minecraft:purple_terracotta
setblock 148 175 339 minecraft:magenta_terracotta
fill 148 175 340 148 175 343 minecraft:purple_terracotta
setblock 148 175 344 minecraft:magenta_terracotta
fill 148 175 345 148 175 347 minecraft:purple_terracotta
fill 148 175 353 151 175 353 minecraft:purple_terracotta
setblock 148 175 354 minecraft:magenta_terracotta
fill 148 175 355 148 175 358 minecraft:purple_terracotta
setblock 148 175 359 minecraft:magenta_terracotta
fill 148 175 360 148 175 363 minecraft:purple_terracotta
fill 149 175 324 152 175 324 minecraft:purple_terracotta
setblock 149 175 325 minecraft:magenta_terracotta
fill 149 175 329 152 175 329 minecraft:purple_terracotta
setblock 149 175 330 minecraft:magenta_terracotta
fill 149 175 331 149 175 334 minecraft:purple_terracotta
setblock 149 175 335 minecraft:magenta_terracotta
fill 149 175 336 149 175 339 minecraft:purple_terracotta
setblock 149 175 340 minecraft:magenta_terracotta
fill 149 175 341 149 175 344 minecraft:purple_terracotta
setblock 149 175 345 minecraft:magenta_terracotta
fill 149 175 346 149 175 349 minecraft:purple_terracotta
setblock 149 175 350 minecraft:magenta_terracotta
setblock 149 175 351 minecraft:purple_terracotta
fill 149 175 354 152 175 354 minecraft:purple_terracotta
setblock 149 175 355 minecraft:magenta_terracotta
fill 149 175 356 149 175 359 minecraft:purple_terracotta
setblock 149 175 360 minecraft:magenta_terracotta
fill 149 175 361 149 175 363 minecraft:purple_terracotta
fill 150 175 325 153 175 325 minecraft:purple_terracotta
setblock 150 175 326 minecraft:magenta_terracotta
fill 150 175 330 153 175 330 minecraft:purple_terracotta
setblock 150 175 331 minecraft:magenta_terracotta
fill 150 175 332 150 175 335 minecraft:purple_terracotta
setblock 150 175 336 minecraft:magenta_terracotta
fill 150 175 337 150 175 340 minecraft:purple_terracotta
setblock 150 175 341 minecraft:magenta_terracotta
fill 150 175 342 150 175 345 minecraft:purple_terracotta
setblock 150 175 346 minecraft:magenta_terracotta
fill 150 175 347 150 175 350 minecraft:purple_terracotta
setblock 150 175 351 minecraft:magenta_terracotta
fill 150 175 355 153 175 355 minecraft:purple_terracotta
setblock 150 175 356 minecraft:magenta_terracotta
fill 150 175 357 150 175 360 minecraft:purple_terracotta
setblock 150 175 361 minecraft:magenta_terracotta
fill 150 175 362 150 175 363 minecraft:purple_terracotta
fill 151 175 326 154 175 326 minecraft:purple_terracotta
setblock 151 175 327 minecraft:magenta_terracotta
fill 151 175 331 154 175 331 minecraft:purple_terracotta
setblock 151 175 332 minecraft:magenta_terracotta
fill 151 175 333 151 175 336 minecraft:purple_terracotta
setblock 151 175 337 minecraft:magenta_terracotta
fill 151 175 338 151 175 341 minecraft:purple_terracotta
setblock 151 175 342 minecraft:magenta_terracotta
fill 151 175 343 151 175 346 minecraft:purple_terracotta
setblock 151 175 347 minecraft:magenta_terracotta
fill 151 175 348 151 175 351 minecraft:purple_terracotta
setblock 151 175 352 minecraft:magenta_terracotta
fill 151 175 356 154 175 356 minecraft:purple_terracotta
setblock 151 175 357 minecraft:magenta_terracotta
fill 151 175 358 151 175 361 minecraft:purple_terracotta
setblock 151 175 362 minecraft:magenta_terracotta
setblock 151 175 363 minecraft:purple_terracotta
setblock 152 175 323 minecraft:magenta_terracotta
fill 152 175 327 155 175 327 minecraft:purple_terracotta
setblock 152 175 328 minecraft:magenta_terracotta
fill 152 175 332 155 175 332 minecraft:purple_terracotta
fill 152 175 335 153 175 337 minecraft:purple_terracotta
setblock 152 175 338 minecraft:magenta_terracotta
fill 152 175 339 152 175 342 minecraft:purple_terracotta
setblock 152 175 343 minecraft:magenta_terracotta
fill 152 175 344 152 175 347 minecraft:purple_terracotta
setblock 152 175 348 minecraft:magenta_terracotta
fill 152 175 349 152 175 352 minecraft:purple_terracotta
setblock 152 175 353 minecraft:magenta_terracotta
fill 152 175 357 154 175 357 minecraft:purple_terracotta
setblock 152 175 358 minecraft:magenta_terracotta
fill 152 175 359 152 175 362 minecraft:purple_terracotta
setblock 152 175 363 minecraft:magenta_terracotta
fill 153 175 323 156 175 323 minecraft:purple_terracotta
setblock 153 175 324 minecraft:magenta_terracotta
fill 153 175 328 156 175 328 minecraft:purple_terracotta
setblock 153 175 329 minecraft:magenta_terracotta
fill 153 175 338 155 175 338 minecraft:purple_terracotta
setblock 153 175 339 minecraft:magenta_terracotta
fill 153 175 340 153 175 343 minecraft:purple_terracotta
setblock 153 175 344 minecraft:magenta_terracotta
fill 153 175 345 153 175 348 minecraft:purple_terracotta
setblock 153 175 349 minecraft:magenta_terracotta
fill 153 175 350 153 175 353 minecraft:purple_terracotta
setblock 153 175 354 minecraft:magenta_terracotta
fill 153 175 358 154 175 358 minecraft:purple_terracotta
setblock 153 175 359 minecraft:magenta_terracotta
fill 153 175 360 153 175 363 minecraft:purple_terracotta
fill 154 175 324 157 175 324 minecraft:purple_terracotta
setblock 154 175 325 minecraft:magenta_terracotta
fill 154 175 329 157 175 329 minecraft:purple_terracotta
setblock 154 175 330 minecraft:magenta_terracotta
setblock 154 175 335 minecraft:magenta_terracotta
fill 154 175 336 154 175 337 minecraft:purple_terracotta
setblock 154 175 339 minecraft:purple_terracotta
setblock 154 175 340 minecraft:magenta_terracotta
fill 154 175 341 154 175 344 minecraft:purple_terracotta
setblock 154 175 345 minecraft:magenta_terracotta
fill 154 175 346 154 175 349 minecraft:purple_terracotta
setblock 154 175 350 minecraft:magenta_terracotta
fill 154 175 351 154 175 354 minecraft:purple_terracotta
setblock 154 175 355 minecraft:magenta_terracotta
fill 154 175 359 155 175 359 minecraft:purple_terracotta
setblock 154 175 360 minecraft:magenta_terracotta
fill 154 175 361 154 175 363 minecraft:purple_terracotta
fill 155 175 325 158 175 325 minecraft:purple_terracotta
setblock 155 175 326 minecraft:magenta_terracotta
fill 155 175 330 158 175 330 minecraft:purple_terracotta
setblock 155 175 331 minecraft:magenta_terracotta
fill 155 175 333 156 175 335 minecraft:purple_terracotta
setblock 155 175 336 minecraft:magenta_terracotta
setblock 155 175 337 minecraft:purple_terracotta
fill 155 175 347 155 175 350 minecraft:purple_terracotta
setblock 155 175 351 minecraft:magenta_terracotta
fill 155 175 352 155 175 355 minecraft:purple_terracotta
setblock 155 175 356 minecraft:magenta_terracotta
fill 155 175 360 158 175 360 minecraft:purple_terracotta
setblock 155 175 361 minecraft:magenta_terracotta
fill 155 175 362 155 175 363 minecraft:purple_terracotta
fill 156 175 326 159 175 326 minecraft:purple_terracotta
setblock 156 175 327 minecraft:magenta_terracotta
fill 156 175 331 159 175 331 minecraft:purple_terracotta
setblock 156 175 332 minecraft:magenta_terracotta
setblock 156 175 336 minecraft:purple_terracotta
fill 156 175 337 156 176 337 minecraft:white_concrete
fill 156 175 348 156 176 348 minecraft:white_concrete
fill 156 175 349 156 175 351 minecraft:purple_terracotta
setblock 156 175 352 minecraft:magenta_terracotta
fill 156 175 353 156 175 356 minecraft:purple_terracotta
fill 156 175 361 159 175 361 minecraft:purple_terracotta
setblock 156 175 362 minecraft:magenta_terracotta
setblock 156 175 363 minecraft:purple_terracotta
setblock 157 175 323 minecraft:magenta_terracotta
fill 157 175 327 160 175 327 minecraft:purple_terracotta
setblock 157 175 328 minecraft:magenta_terracotta
fill 157 175 332 160 175 332 minecraft:purple_terracotta
setblock 157 175 333 minecraft:magenta_terracotta
fill 157 175 334 157 175 335 minecraft:purple_terracotta
fill 157 175 350 158 175 352 minecraft:purple_terracotta
setblock 157 175 353 minecraft:magenta_terracotta
fill 157 175 354 157 175 356 minecraft:purple_terracotta
fill 157 175 362 160 175 362 minecraft:purple_terracotta
setblock 157 175 363 minecraft:magenta_terracotta
fill 158 175 323 161 175 323 minecraft:purple_terracotta
setblock 158 175 324 minecraft:magenta_terracotta
fill 158 175 328 161 175 328 minecraft:purple_terracotta
setblock 158 175 329 minecraft:magenta_terracotta
fill 158 175 333 161 175 333 minecraft:purple_terracotta
setblock 158 175 334 minecraft:magenta_terracotta
setblock 158 175 335 minecraft:purple_terracotta
fill 158 175 353 161 175 353 minecraft:purple_terracotta
setblock 158 175 354 minecraft:magenta_terracotta
fill 158 175 355 158 175 358 minecraft:purple_terracotta
setblock 158 175 359 minecraft:magenta_terracotta
fill 158 175 363 161 175 363 minecraft:purple_terracotta
fill 159 175 324 162 175 324 minecraft:purple_terracotta
setblock 159 175 325 minecraft:magenta_terracotta
fill 159 175 329 162 175 329 minecraft:purple_terracotta
setblock 159 175 330 minecraft:magenta_terracotta
fill 159 175 334 160 175 334 minecraft:purple_terracotta
fill 159 175 351 159 175 352 minecraft:purple_terracotta
fill 159 175 354 162 175 354 minecraft:purple_terracotta
setblock 159 175 355 minecraft:magenta_terracotta
fill 159 175 356 159 175 359 minecraft:purple_terracotta
setblock 159 175 360 minecraft:magenta_terracotta
fill 160 175 325 163 175 325 minecraft:purple_terracotta
setblock 160 175 326 minecraft:magenta_terracotta
fill 160 175 330 163 175 330 minecraft:purple_terracotta
setblock 160 175 331 minecraft:magenta_terracotta
setblock 160 175 351 minecraft:magenta_terracotta
setblock 160 175 352 minecraft:purple_terracotta
fill 160 175 355 163 175 355 minecraft:purple_terracotta
setblock 160 175 356 minecraft:magenta_terracotta
fill 160 175 357 160 175 360 minecraft:purple_terracotta
setblock 160 175 361 minecraft:magenta_terracotta
fill 161 175 326 164 175 326 minecraft:purple_terracotta
setblock 161 175 327 minecraft:magenta_terracotta
fill 161 175 331 164 175 331 minecraft:purple_terracotta
setblock 161 175 332 minecraft:magenta_terracotta
setblock 161 175 352 minecraft:magenta_terracotta
fill 161 175 356 164 175 356 minecraft:purple_terracotta
setblock 161 175 357 minecraft:magenta_terracotta
fill 161 175 358 161 175 361 minecraft:purple_terracotta
setblock 161 175 362 minecraft:magenta_terracotta
setblock 162 175 323 minecraft:magenta_terracotta
fill 162 175 327 165 175 327 minecraft:purple_terracotta
setblock 162 175 328 minecraft:magenta_terracotta
fill 162 175 332 165 175 332 minecraft:purple_terracotta
setblock 162 175 333 minecraft:magenta_terracotta
fill 162 175 352 165 175 352 minecraft:purple_terracotta
setblock 162 175 353 minecraft:magenta_terracotta
fill 162 175 357 165 175 357 minecraft:purple_terracotta
setblock 162 175 358 minecraft:magenta_terracotta
fill 162 175 359 162 175 362 minecraft:purple_terracotta
setblock 162 175 363 minecraft:magenta_terracotta
fill 163 175 323 166 175 323 minecraft:purple_terracotta
setblock 163 175 324 minecraft:magenta_terracotta
fill 163 175 328 166 175 328 minecraft:purple_terracotta
setblock 163 175 329 minecraft:magenta_terracotta
fill 163 175 333 166 175 333 minecraft:purple_terracotta
fill 163 175 353 166 175 353 minecraft:purple_terracotta
setblock 163 175 354 minecraft:magenta_terracotta
fill 163 175 358 166 175 358 minecraft:purple_terracotta
setblock 163 175 359 minecraft:magenta_terracotta
fill 163 175 360 163 175 363 minecraft:purple_terracotta
fill 164 175 324 167 175 324 minecraft:purple_terracotta
setblock 164 175 325 minecraft:magenta_terracotta
fill 164 175 329 166 175 329 minecraft:purple_terracotta
setblock 164 175 330 minecraft:magenta_terracotta
fill 164 175 354 167 175 354 minecraft:purple_terracotta
setblock 164 175 355 minecraft:magenta_terracotta
fill 164 175 359 167 175 359 minecraft:purple_terracotta
setblock 164 175 360 minecraft:magenta_terracotta
fill 164 175 361 164 175 363 minecraft:purple_terracotta
fill 165 175 325 168 175 325 minecraft:purple_terracotta
setblock 165 175 326 minecraft:magenta_terracotta
fill 165 175 330 168 175 330 minecraft:purple_terracotta
setblock 165 175 331 minecraft:magenta_terracotta
fill 165 175 355 168 175 355 minecraft:purple_terracotta
setblock 165 175 356 minecraft:magenta_terracotta
fill 165 175 360 168 175 360 minecraft:purple_terracotta
setblock 165 175 361 minecraft:magenta_terracotta
fill 165 175 362 165 175 363 minecraft:purple_terracotta
fill 166 175 326 169 175 326 minecraft:purple_terracotta
setblock 166 175 327 minecraft:magenta_terracotta
fill 166 175 331 169 175 331 minecraft:purple_terracotta
setblock 166 175 332 minecraft:magenta_terracotta
fill 166 175 334 167 175 334 minecraft:purple_terracotta
fill 166 175 351 169 175 351 minecraft:purple_terracotta
setblock 166 175 352 minecraft:magenta_terracotta
fill 166 175 356 169 175 356 minecraft:purple_terracotta
setblock 166 175 357 minecraft:magenta_terracotta
fill 166 175 361 169 175 361 minecraft:purple_terracotta
setblock 166 175 362 minecraft:magenta_terracotta
setblock 166 175 363 minecraft:purple_terracotta
setblock 167 175 323 minecraft:magenta_terracotta
setblock 167 175 327 minecraft:purple_terracotta
fill 167 175 332 170 175 332 minecraft:purple_terracotta
setblock 167 175 333 minecraft:magenta_terracotta
fill 167 175 352 169 175 352 minecraft:purple_terracotta
setblock 167 175 353 minecraft:magenta_terracotta
fill 167 175 357 170 175 357 minecraft:purple_terracotta
setblock 167 175 358 minecraft:magenta_terracotta
fill 167 175 362 170 175 362 minecraft:purple_terracotta
setblock 167 175 363 minecraft:magenta_terracotta
fill 168 175 323 171 175 323 minecraft:purple_terracotta
setblock 168 175 324 minecraft:magenta_terracotta
fill 168 175 333 171 175 333 minecraft:purple_terracotta
setblock 168 175 334 minecraft:magenta_terracotta
setblock 168 175 335 minecraft:purple_terracotta
setblock 168 175 350 minecraft:purple_terracotta
fill 168 175 353 169 175 353 minecraft:purple_terracotta
setblock 168 175 354 minecraft:magenta_terracotta
fill 168 175 358 171 175 358 minecraft:purple_terracotta
setblock 168 175 359 minecraft:magenta_terracotta
fill 168 175 363 171 175 363 minecraft:purple_terracotta
fill 169 175 324 172 175 324 minecraft:purple_terracotta
setblock 169 175 325 minecraft:magenta_terracotta
fill 169 175 327 170 175 327 minecraft:purple_terracotta
setblock 169 175 330 minecraft:magenta_terracotta
fill 169 175 334 172 175 334 minecraft:purple_terracotta
setblock 169 175 335 minecraft:magenta_terracotta
setblock 169 175 350 minecraft:magenta_terracotta
fill 169 175 354 170 175 354 minecraft:purple_terracotta
setblock 169 175 355 minecraft:magenta_terracotta
fill 169 175 359 172 175 359 minecraft:purple_terracotta
setblock 169 175 360 minecraft:magenta_terracotta
fill 170 175 325 173 175 325 minecraft:purple_terracotta
setblock 170 175 326 minecraft:magenta_terracotta
fill 170 175 328 171 175 330 minecraft:purple_terracotta
setblock 170 175 331 minecraft:magenta_terracotta
fill 170 175 335 173 175 335 minecraft:purple_terracotta
setblock 170 175 336 minecraft:magenta_terracotta
fill 170 175 337 170 176 337 minecraft:white_concrete
fill 170 175 348 170 176 348 minecraft:white_concrete
fill 170 175 349 172 175 350 minecraft:purple_terracotta
setblock 170 175 351 minecraft:magenta_terracotta
fill 170 175 355 173 175 355 minecraft:purple_terracotta
setblock 170 175 356 minecraft:magenta_terracotta
fill 170 175 360 173 175 360 minecraft:purple_terracotta
setblock 170 175 361 minecraft:magenta_terracotta
fill 171 175 326 174 175 326 minecraft:purple_terracotta
setblock 171 175 327 minecraft:magenta_terracotta
fill 171 175 331 174 175 331 minecraft:purple_terracotta
setblock 171 175 332 minecraft:magenta_terracotta
fill 171 175 336 174 175 336 minecraft:purple_terracotta
setblock 171 175 337 minecraft:magenta_terracotta
setblock 171 175 338 minecraft:purple_terracotta
setblock 171 175 347 minecraft:magenta_terracotta
setblock 171 175 348 minecraft:purple_terracotta
fill 171 175 351 174 175 351 minecraft:purple_terracotta
fill 171 175 356 174 175 356 minecraft:purple_terracotta
setblock 171 175 357 minecraft:magenta_terracotta
fill 171 175 361 174 175 361 minecraft:purple_terracotta
setblock 171 175 362 minecraft:magenta_terracotta
setblock 172 175 323 minecraft:magenta_terracotta
fill 172 175 327 175 175 327 minecraft:purple_terracotta
setblock 172 175 328 minecraft:magenta_terracotta
fill 172 175 329 172 175 330 minecraft:purple_terracotta
fill 172 175 332 175 175 332 minecraft:purple_terracotta
setblock 172 175 333 minecraft:magenta_terracotta
fill 172 175 337 175 175 337 minecraft:purple_terracotta
setblock 172 175 338 minecraft:magenta_terracotta
fill 172 175 339 172 175 342 minecraft:purple_terracotta
setblock 172 175 343 minecraft:magenta_terracotta
fill 172 175 344 172 175 347 minecraft:purple_terracotta
setblock 172 175 348 minecraft:magenta_terracotta
setblock 172 175 354 minecraft:purple_terracotta
fill 172 175 357 175 175 357 minecraft:purple_terracotta
setblock 172 175 358 minecraft:magenta_terracotta
fill 172 175 362 175 175 362 minecraft:purple_terracotta
setblock 172 175 363 minecraft:magenta_terracotta
fill 173 175 323 176 175 323 minecraft:purple_terracotta
setblock 173 175 324 minecraft:magenta_terracotta
fill 173 175 328 176 175 328 minecraft:purple_terracotta
setblock 173 175 329 minecraft:magenta_terracotta
setblock 173 175 330 minecraft:purple_terracotta
fill 173 175 333 176 175 333 minecraft:purple_terracotta
setblock 173 175 334 minecraft:magenta_terracotta
fill 173 175 338 175 175 338 minecraft:purple_terracotta
setblock 173 175 339 minecraft:magenta_terracotta
fill 173 175 340 173 175 343 minecraft:purple_terracotta
setblock 173 175 344 minecraft:magenta_terracotta
fill 173 175 345 173 175 348 minecraft:purple_terracotta
setblock 173 175 349 minecraft:magenta_terracotta
setblock 173 175 350 minecraft:purple_terracotta
fill 173 175 352 175 175 353 minecraft:purple_terracotta
setblock 173 175 354 minecraft:magenta_terracotta
fill 173 175 358 176 175 358 minecraft:purple_terracotta
setblock 173 175 359 minecraft:magenta_terracotta
fill 173 175 363 176 175 363 minecraft:purple_terracotta
fill 174 175 324 177 175 324 minecraft:purple_terracotta
setblock 174 175 325 minecraft:magenta_terracotta
fill 174 175 329 177 175 329 minecraft:purple_terracotta
setblock 174 175 330 minecraft:magenta_terracotta
fill 174 175 334 177 175 334 minecraft:purple_terracotta
setblock 174 175 335 minecraft:magenta_terracotta
fill 174 175 339 176 175 339 minecraft:purple_terracotta
setblock 174 175 340 minecraft:magenta_terracotta
fill 174 175 341 174 175 344 minecraft:purple_terracotta
setblock 174 175 345 minecraft:magenta_terracotta
fill 174 175 346 174 175 349 minecraft:purple_terracotta
setblock 174 175 350 minecraft:magenta_terracotta
fill 174 175 354 177 175 354 minecraft:purple_terracotta
setblock 174 175 355 minecraft:magenta_terracotta
fill 174 175 359 177 175 359 minecraft:purple_terracotta
setblock 174 175 360 minecraft:magenta_terracotta
fill 175 175 325 178 175 325 minecraft:purple_terracotta
setblock 175 175 326 minecraft:magenta_terracotta
fill 175 175 330 178 175 330 minecraft:purple_terracotta
setblock 175 175 331 minecraft:magenta_terracotta
fill 175 175 335 178 175 335 minecraft:purple_terracotta
setblock 175 175 336 minecraft:magenta_terracotta
fill 175 175 340 178 175 340 minecraft:purple_terracotta
setblock 175 175 341 minecraft:magenta_terracotta
fill 175 175 342 175 175 345 minecraft:purple_terracotta
setblock 175 175 346 minecraft:magenta_terracotta
fill 175 175 347 175 175 350 minecraft:purple_terracotta
setblock 175 175 351 minecraft:magenta_terracotta
fill 175 175 355 178 175 355 minecraft:purple_terracotta
setblock 175 175 356 minecraft:magenta_terracotta
fill 175 175 360 178 175 360 minecraft:purple_terracotta
setblock 175 175 361 minecraft:magenta_terracotta
fill 176 175 326 179 175 326 minecraft:purple_terracotta
setblock 176 175 327 minecraft:magenta_terracotta
fill 176 175 331 179 175 331 minecraft:purple_terracotta
setblock 176 175 332 minecraft:magenta_terracotta
fill 176 175 336 179 175 336 minecraft:purple_terracotta
setblock 176 175 337 minecraft:magenta_terracotta
fill 176 175 341 179 175 341 minecraft:purple_terracotta
setblock 176 175 342 minecraft:magenta_terracotta
fill 176 175 343 176 175 346 minecraft:purple_terracotta
setblock 176 175 347 minecraft:magenta_terracotta
fill 176 175 348 176 175 351 minecraft:purple_terracotta
setblock 176 175 352 minecraft:magenta_terracotta
setblock 176 175 353 minecraft:purple_terracotta
fill 176 175 356 179 175 356 minecraft:purple_terracotta
setblock 176 175 357 minecraft:magenta_terracotta
fill 176 175 361 179 175 361 minecraft:purple_terracotta
setblock 176 175 362 minecraft:magenta_terracotta
setblock 177 175 323 minecraft:magenta_terracotta
fill 177 175 327 180 175 327 minecraft:purple_terracotta
setblock 177 175 328 minecraft:magenta_terracotta
fill 177 175 332 180 175 332 minecraft:purple_terracotta
setblock 177 175 333 minecraft:magenta_terracotta
fill 177 175 342 180 175 342 minecraft:purple_terracotta
setblock 177 175 343 minecraft:magenta_terracotta
fill 177 175 344 177 175 347 minecraft:purple_terracotta
setblock 177 175 348 minecraft:magenta_terracotta
fill 177 175 349 177 175 352 minecraft:purple_terracotta
setblock 177 175 353 minecraft:magenta_terracotta
fill 177 175 357 180 175 357 minecraft:purple_terracotta
setblock 177 175 358 minecraft:magenta_terracotta
fill 177 175 362 180 175 362 minecraft:purple_terracotta
setblock 177 175 363 minecraft:magenta_terracotta
fill 178 175 323 181 175 323 minecraft:purple_terracotta
setblock 178 175 324 minecraft:magenta_terracotta
fill 178 175 328 181 175 328 minecraft:purple_terracotta
setblock 178 175 329 minecraft:magenta_terracotta
fill 178 175 333 181 175 333 minecraft:purple_terracotta
setblock 178 175 334 minecraft:magenta_terracotta
fill 178 175 343 181 175 343 minecraft:purple_terracotta
setblock 178 175 344 minecraft:magenta_terracotta
fill 178 175 345 178 175 348 minecraft:purple_terracotta
setblock 178 175 349 minecraft:magenta_terracotta
fill 178 175 350 178 175 353 minecraft:purple_terracotta
setblock 178 175 354 minecraft:magenta_terracotta
fill 178 175 358 181 175 358 minecraft:purple_terracotta
setblock 178 175 359 minecraft:magenta_terracotta
fill 178 175 363 181 175 363 minecraft:purple_terracotta
fill 179 175 324 182 175 324 minecraft:purple_terracotta
setblock 179 175 325 minecraft:magenta_terracotta
fill 179 175 329 182 175 329 minecraft:purple_terracotta
setblock 179 175 330 minecraft:magenta_terracotta
fill 179 175 334 182 175 334 minecraft:purple_terracotta
setblock 179 175 335 minecraft:magenta_terracotta
fill 179 175 337 180 175 339 minecraft:purple_terracotta
setblock 179 175 340 minecraft:magenta_terracotta
fill 179 175 344 182 175 344 minecraft:purple_terracotta
setblock 179 175 345 minecraft:magenta_terracotta
fill 179 175 346 179 175 349 minecraft:purple_terracotta
setblock 179 175 350 minecraft:magenta_terracotta
fill 179 175 351 179 175 354 minecraft:purple_terracotta
setblock 179 175 355 minecraft:magenta_terracotta
fill 179 175 359 182 175 359 minecraft:purple_terracotta
setblock 179 175 360 minecraft:magenta_terracotta
fill 180 175 325 182 175 325 minecraft:purple_terracotta
setblock 180 175 326 minecraft:magenta_terracotta
fill 180 175 330 182 175 330 minecraft:purple_terracotta
setblock 180 175 331 minecraft:magenta_terracotta
fill 180 175 335 182 175 335 minecraft:purple_terracotta
setblock 180 175 336 minecraft:magenta_terracotta
fill 180 175 340 182 175 340 minecraft:purple_terracotta
setblock 180 175 341 minecraft:magenta_terracotta
fill 180 175 345 182 175 345 minecraft:purple_terracotta
setblock 180 175 346 minecraft:magenta_terracotta
fill 180 175 347 180 175 350 minecraft:purple_terracotta
setblock 180 175 351 minecraft:magenta_terracotta
fill 180 175 352 180 175 355 minecraft:purple_terracotta
setblock 180 175 356 minecraft:magenta_terracotta
fill 180 175 360 182 175 360 minecraft:purple_terracotta
setblock 180 175 361 minecraft:magenta_terracotta
fill 181 175 326 182 175 326 minecraft:purple_terracotta
setblock 181 175 327 minecraft:magenta_terracotta
fill 181 175 331 182 175 331 minecraft:purple_terracotta
setblock 181 175 332 minecraft:magenta_terracotta
fill 181 175 336 182 175 336 minecraft:purple_terracotta
setblock 181 175 337 minecraft:magenta_terracotta
fill 181 175 338 181 175 339 minecraft:purple_terracotta
fill 181 175 341 182 175 341 minecraft:purple_terracotta
setblock 181 175 342 minecraft:magenta_terracotta
fill 181 175 346 182 175 346 minecraft:purple_terracotta
setblock 181 175 347 minecraft:magenta_terracotta
fill 181 175 348 181 175 351 minecraft:purple_terracotta
setblock 181 175 352 minecraft:magenta_terracotta
fill 181 175 353 181 175 356 minecraft:purple_terracotta
setblock 181 175 357 minecraft:magenta_terracotta
fill 181 175 361 182 175 361 minecraft:purple_terracotta
setblock 181 175 362 minecraft:magenta_terracotta
setblock 182 175 323 minecraft:magenta_terracotta
setblock 182 175 327 minecraft:purple_terracotta
setblock 182 175 328 minecraft:magenta_terracotta
setblock 182 175 332 minecraft:purple_terracotta
setblock 182 175 333 minecraft:magenta_terracotta
setblock 182 175 337 minecraft:purple_terracotta
setblock 182 175 338 minecraft:magenta_terracotta
setblock 182 175 339 minecraft:purple_terracotta
setblock 182 175 342 minecraft:purple_terracotta
setblock 182 175 343 minecraft:magenta_terracotta
setblock 182 175 347 minecraft:purple_terracotta
setblock 182 175 348 minecraft:magenta_terracotta
fill 182 175 349 182 175 352 minecraft:purple_terracotta
setblock 182 175 353 minecraft:magenta_terracotta
fill 182 175 354 182 175 357 minecraft:purple_terracotta
setblock 182 175 358 minecraft:magenta_terracotta
setblock 182 175 362 minecraft:purple_terracotta
setblock 182 175 363 minecraft:magenta_terracotta
fill 183 175 348 183 220 348 minecraft:blue_terracotta
fill 153 176 332 153 208 332 minecraft:magenta_terracotta
fill 155 177 359 155 234 359 minecraft:magenta_terracotta
fill 158 177 322 159 216 322 minecraft:blue_terracotta
setblock 160 177 322 minecraft:cyan_concrete
fill 161 177 322 162 203 322 minecraft:blue_terracotta
fill 160 178 322 160 220 322 minecraft:blue_terracotta
fill 170 178 354 170 216 354 minecraft:magenta_terracotta
setblock 144 179 325 minecraft:light[level=12]
setblock 144 179 332 minecraft:light[level=12]
setblock 144 179 339 minecraft:light[level=12]
setblock 144 179 346 minecraft:light[level=12]
setblock 144 179 353 minecraft:light[level=12]
setblock 144 179 360 minecraft:light[level=12]
setblock 151 179 325 minecraft:light[level=12]
setblock 151 179 332 minecraft:light[level=12]
setblock 151 179 339 minecraft:light[level=12]
setblock 151 179 346 minecraft:light[level=12]
setblock 151 179 353 minecraft:light[level=12]
setblock 151 179 360 minecraft:light[level=12]
setblock 158 179 325 minecraft:light[level=12]
setblock 158 179 332 minecraft:light[level=12]
setblock 158 179 353 minecraft:light[level=12]
setblock 158 179 360 minecraft:light[level=12]
setblock 165 179 325 minecraft:light[level=12]
setblock 165 179 332 minecraft:light[level=12]
setblock 165 179 353 minecraft:light[level=12]
setblock 165 179 360 minecraft:light[level=12]
fill 171 179 352 171 186 352 minecraft:magenta_terracotta
setblock 172 179 325 minecraft:light[level=12]
setblock 172 179 332 minecraft:light[level=12]
setblock 172 179 339 minecraft:light[level=12]
setblock 172 179 346 minecraft:light[level=12]
setblock 172 179 360 minecraft:light[level=12]
setblock 179 179 325 minecraft:light[level=12]
setblock 179 179 332 minecraft:light[level=12]
setblock 179 179 339 minecraft:light[level=12]
setblock 179 179 346 minecraft:light[level=12]
setblock 179 179 353 minecraft:light[level=12]
setblock 179 179 360 minecraft:light[level=12]
setblock 143 180 364 minecraft:cyan_concrete
setblock 141 181 328 minecraft:light_blue_wool
fill 141 181 329 141 218 331 minecraft:blue_terracotta
fill 143 181 364 143 220 364 minecraft:blue_terracotta
setblock 144 181 325 minecraft:light[level=13]
setblock 144 181 333 minecraft:light[level=13]
setblock 144 181 341 minecraft:light[level=13]
setblock 144 181 349 minecraft:light[level=13]
setblock 144 181 357 minecraft:light[level=13]
setblock 152 181 325 minecraft:light[level=13]
setblock 152 181 341 minecraft:light[level=13]
setblock 152 181 349 minecraft:light[level=13]
setblock 152 181 357 minecraft:light[level=13]
setblock 160 181 325 minecraft:light[level=13]
setblock 160 181 333 minecraft:light[level=13]
setblock 160 181 349 minecraft:light[level=13]
setblock 160 181 357 minecraft:light[level=13]
setblock 166 181 337 minecraft:yellow_concrete
setblock 167 181 337 minecraft:white_concrete
setblock 168 181 325 minecraft:light[level=13]
fill 168 181 329 168 198 329 minecraft:magenta_terracotta
setblock 168 181 333 minecraft:light[level=13]
setblock 168 181 349 minecraft:light[level=13]
setblock 168 181 357 minecraft:light[level=13]
setblock 169 181 339 minecraft:white_concrete
fill 169 181 340 169 181 341 minecraft:yellow_concrete
fill 169 181 342 169 181 343 minecraft:white_concrete
fill 169 181 344 169 182 344 minecraft:yellow_concrete
setblock 176 181 325 minecraft:light[level=13]
setblock 176 181 333 minecraft:light[level=13]
setblock 176 181 341 minecraft:light[level=13]
setblock 176 181 349 minecraft:light[level=13]
setblock 176 181 357 minecraft:light[level=13]
setblock 183 181 354 minecraft:light_blue_wool
fill 141 182 328 141 207 328 minecraft:blue_terracotta
setblock 141 182 342 minecraft:cyan_concrete
fill 148 182 347 148 211 347 minecraft:magenta_terracotta
fill 154 182 332 154 220 332 minecraft:magenta_terracotta
fill 155 182 341 156 182 344 minecraft:magenta_terracotta
fill 156 182 338 157 182 340 minecraft:magenta_terracotta
fill 156 182 345 157 182 347 minecraft:magenta_terracotta
fill 157 182 337 160 182 337 minecraft:magenta_terracotta
fill 157 182 348 160 182 348 minecraft:magenta_terracotta
fill 158 182 336 168 182 336 minecraft:magenta_terracotta
fill 158 182 338 158 183 338 minecraft:magenta_terracotta
fill 158 182 347 158 183 347 minecraft:magenta_terracotta
fill 158 182 349 168 182 349 minecraft:magenta_terracotta
setblock 158 182 364 minecraft:light_blue_wool
fill 160 182 335 166 182 335 minecraft:magenta_terracotta
fill 160 182 350 166 182 350 minecraft:magenta_terracotta
setblock 161 182 337 minecraft:white_concrete
fill 162 182 337 165 182 337 minecraft:yellow_concrete
fill 166 182 337 169 182 337 minecraft:magenta_terracotta
fill 166 182 338 167 182 338 minecraft:yellow_concrete
setblock 166 182 347 minecraft:yellow_concrete
fill 166 182 348 169 182 348 minecraft:magenta_terracotta
fill 167 182 339 168 182 339 minecraft:yellow_concrete
setblock 167 182 346 minecraft:yellow_concrete
setblock 167 182 347 minecraft:white_concrete
fill 168 182 338 170 182 338 minecraft:magenta_terracotta
fill 168 182 340 168 182 345 minecraft:yellow_concrete
setblock 168 182 346 minecraft:white_concrete
fill 168 182 347 170 182 347 minecraft:magenta_terracotta
fill 169 182 327 169 234 327 minecraft:magenta_terracotta
fill 169 182 339 170 182 340 minecraft:magenta_terracotta
fill 169 182 341 169 182 343 minecraft:yellow_concrete
fill 169 182 345 170 182 346 minecraft:magenta_terracotta
fill 170 182 341 171 182 344 minecraft:magenta_terracotta
fill 183 182 354 183 220 354 minecraft:blue_terracotta
setblock 183 182 360 minecraft:cyan_concrete
fill 183 182 361 183 218 362 minecraft:blue_terracotta
fill 141 183 342 141 187 342 minecraft:blue_terracotta
fill 142 183 323 145 183 363 minecraft:purple_terracotta
fill 146 183 323 146 183 347 minecraft:purple_terracotta
fill 146 183 349 146 183 363 minecraft:purple_terracotta
fill 147 183 323 151 183 346 minecraft:purple_terracotta
fill 147 183 350 154 183 363 minecraft:purple_terracotta
fill 149 183 347 157 183 349 minecraft:purple_terracotta
fill 152 183 323 152 183 332 minecraft:purple_terracotta
fill 152 183 334 152 183 346 minecraft:purple_terracotta
fill 153 183 323 166 183 331 minecraft:purple_terracotta
fill 153 183 335 155 183 346 minecraft:purple_terracotta
fill 155 183 332 182 183 334 minecraft:purple_terracotta
fill 155 183 350 169 183 356 minecraft:purple_terracotta
fill 155 183 360 182 183 363 minecraft:purple_terracotta
fill 156 183 335 156 183 339 minecraft:purple_terracotta
fill 156 183 340 158 183 345 minecraft:magenta_terracotta
setblock 156 183 346 minecraft:purple_terracotta
fill 157 183 335 157 183 338 minecraft:purple_terracotta
fill 157 183 339 159 183 339 minecraft:magenta_terracotta
fill 157 183 346 159 183 346 minecraft:magenta_terracotta
fill 157 183 357 182 183 357 minecraft:purple_terracotta
fill 157 183 359 182 183 359 minecraft:purple_terracotta
fill 158 183 335 159 183 336 minecraft:purple_terracotta
fill 158 183 337 168 183 337 minecraft:magenta_terracotta
fill 158 183 348 168 183 348 minecraft:magenta_terracotta
fill 158 183 349 159 183 349 minecraft:purple_terracotta
fill 158 183 358 182 183 358 minecraft:purple_terracotta
fill 158 183 364 158 220 364 minecraft:blue_terracotta
fill 159 183 338 160 184 338 minecraft:magenta_terracotta
fill 159 183 340 160 183 344 minecraft:yellow_concrete
setblock 159 183 345 minecraft:white_concrete
fill 159 183 347 160 184 347 minecraft:magenta_terracotta
fill 160 183 335 182 183 335 minecraft:purple_terracotta
fill 160 183 336 166 183 336 minecraft:magenta_terracotta
fill 160 183 339 161 183 339 minecraft:yellow_concrete
fill 160 183 345 161 183 345 minecraft:yellow_concrete
setblock 160 183 346 minecraft:white_concrete
fill 160 183 349 166 183 349 minecraft:magenta_terracotta
fill 161 183 338 165 183 338 minecraft:yellow_concrete
fill 161 183 340 161 183 344 minecraft:black_concrete
fill 161 183 346 166 183 346 minecraft:yellow_concrete
setblock 161 183 347 minecraft:white_concrete
fill 162 183 339 162 183 340 minecraft:black_concrete
fill 162 183 344 162 183 345 minecraft:black_concrete
fill 162 183 347 165 183 347 minecraft:yellow_concrete
fill 163 183 339 166 183 339 minecraft:black_concrete
fill 163 183 345 166 183 345 minecraft:black_concrete
fill 166 183 338 168 183 338 minecraft:magenta_terracotta
fill 166 183 340 167 183 340 minecraft:black_concrete
fill 166 183 344 167 183 344 minecraft:black_concrete
fill 166 183 347 168 183 347 minecraft:magenta_terracotta
fill 167 183 323 167 183 327 minecraft:purple_terracotta
fill 167 183 329 167 183 331 minecraft:purple_terracotta
fill 167 183 336 182 183 336 minecraft:purple_terracotta
fill 167 183 339 169 183 339 minecraft:magenta_terracotta
fill 167 183 341 167 183 343 minecraft:black_concrete
setblock 167 183 345 minecraft:yellow_concrete
fill 167 183 346 169 183 346 minecraft:magenta_terracotta
fill 167 183 349 182 183 349 minecraft:purple_terracotta
fill 168 183 323 182 183 326 minecraft:purple_terracotta
fill 168 183 330 182 183 331 minecraft:purple_terracotta
fill 168 183 340 170 183 345 minecraft:magenta_terracotta
fill 169 183 337 175 183 338 minecraft:purple_terracotta
fill 169 183 347 182 183 348 minecraft:purple_terracotta
fill 170 183 327 182 183 329 minecraft:purple_terracotta
fill 170 183 339 176 183 339 minecraft:purple_terracotta
fill 170 183 346 182 183 346 minecraft:purple_terracotta
fill 170 183 350 182 183 351 minecraft:purple_terracotta
fill 170 183 355 182 183 356 minecraft:purple_terracotta
fill 171 183 340 182 183 345 minecraft:purple_terracotta
fill 172 183 352 182 183 352 minecraft:purple_terracotta
fill 172 183 354 182 183 354 minecraft:purple_terracotta
fill 173 183 353 182 183 353 minecraft:purple_terracotta
setblock 176 183 337 minecraft:purple_terracotta
fill 179 183 337 182 183 339 minecraft:purple_terracotta
fill 183 183 360 183 216 360 minecraft:blue_terracotta
fill 157 184 341 160 184 344 minecraft:magenta_terracotta
fill 158 184 339 161 184 340 minecraft:magenta_terracotta
fill 158 184 345 161 184 346 minecraft:magenta_terracotta
fill 160 184 337 166 184 337 minecraft:magenta_terracotta
fill 160 184 348 166 184 348 minecraft:magenta_terracotta
fill 161 184 338 167 184 338 minecraft:magenta_terracotta
fill 161 184 341 161 184 344 minecraft:orange_concrete
fill 161 184 347 167 184 347 minecraft:magenta_terracotta
fill 162 184 339 168 184 339 minecraft:magenta_terracotta
setblock 162 184 340 minecraft:orange_concrete
fill 162 184 344 162 184 345 minecraft:orange_concrete
fill 162 184 346 168 184 346 minecraft:magenta_terracotta
fill 163 184 345 164 184 345 minecraft:orange_concrete
fill 165 184 345 168 184 345 minecraft:magenta_terracotta
fill 166 184 340 168 184 340 minecraft:magenta_terracotta
fill 166 184 344 169 184 344 minecraft:magenta_terracotta
fill 167 184 341 169 184 343 minecraft:magenta_terracotta
setblock 170 184 364 minecraft:light_blue_wool
setblock 144 185 325 minecraft:light[level=12]
setblock 144 185 332 minecraft:light[level=12]
setblock 144 185 339 minecraft:light[level=12]
setblock 144 185 346 minecraft:light[level=12]
setblock 144 185 353 minecraft:light[level=12]
setblock 144 185 360 minecraft:light[level=12]
setblock 151 185 325 minecraft:light[level=12]
setblock 151 185 332 minecraft:light[level=12]
setblock 151 185 339 minecraft:light[level=12]
setblock 151 185 346 minecraft:light[level=12]
setblock 151 185 353 minecraft:light[level=12]
setblock 151 185 360 minecraft:light[level=12]
setblock 158 185 325 minecraft:light[level=12]
setblock 158 185 332 minecraft:light[level=12]
setblock 158 185 339 minecraft:light[level=12]
setblock 158 185 346 minecraft:light[level=12]
setblock 158 185 353 minecraft:light[level=12]
setblock 158 185 360 minecraft:light[level=12]
fill 159 185 341 161 185 344 minecraft:magenta_terracotta
fill 160 185 339 162 185 340 minecraft:magenta_terracotta
fill 160 185 345 166 185 346 minecraft:magenta_terracotta
fill 162 185 338 164 185 338 minecraft:magenta_terracotta
setblock 162 185 344 minecraft:magenta_terracotta
fill 162 185 347 164 185 347 minecraft:magenta_terracotta
fill 163 185 339 166 185 339 minecraft:magenta_terracotta
setblock 165 185 325 minecraft:light[level=12]
setblock 165 185 332 minecraft:light[level=12]
setblock 165 185 353 minecraft:light[level=12]
setblock 165 185 360 minecraft:light[level=12]
setblock 166 185 340 minecraft:magenta_terracotta
fill 166 185 344 167 185 344 minecraft:magenta_terracotta
fill 167 185 341 167 185 343 minecraft:magenta_terracotta
fill 170 185 364 170 211 364 minecraft:blue_terracotta
setblock 172 185 325 minecraft:light[level=12]
setblock 172 185 332 minecraft:light[level=12]
setblock 172 185 339 minecraft:light[level=12]
setblock 172 185 346 minecraft:light[level=12]
setblock 172 185 353 minecraft:light[level=12]
setblock 172 185 360 minecraft:light[level=12]
setblock 179 185 325 minecraft:light[level=12]
setblock 179 185 332 minecraft:light[level=12]
setblock 179 185 339 minecraft:light[level=12]
setblock 179 185 346 minecraft:light[level=12]
setblock 179 185 353 minecraft:light[level=12]
setblock 179 185 360 minecraft:light[level=12]
fill 142 186 322 143 220 322 minecraft:blue_terracotta
fill 144 186 322 145 186 322 minecraft:cyan_concrete
fill 147 186 348 147 187 348 minecraft:pink_terracotta
fill 147 186 349 147 193 349 minecraft:magenta_terracotta
fill 162 186 342 162 186 343 minecraft:magenta_terracotta
setblock 163 186 342 minecraft:magenta_terracotta
fill 176 186 339 176 211 339 minecraft:magenta_terracotta
fill 177 186 338 177 187 338 minecraft:pink_terracotta
fill 178 186 338 178 199 338 minecraft:magenta_terracotta
setblock 142 187 323 minecraft:dark_prismarine
setblock 142 187 334 minecraft:purple_concrete
fill 142 187 336 142 187 337 minecraft:blue_terracotta
setblock 142 187 338 minecraft:dark_prismarine
fill 142 187 339 142 187 342 minecraft:blue_terracotta
setblock 142 187 343 minecraft:dark_prismarine
fill 142 187 344 142 188 344 minecraft:blue_terracotta
fill 142 187 351 142 187 352 minecraft:blue_terracotta
setblock 142 187 353 minecraft:dark_prismarine
fill 142 187 354 142 187 357 minecraft:blue_terracotta
setblock 142 187 358 minecraft:dark_prismarine
fill 142 187 359 142 187 362 minecraft:blue_terracotta
setblock 142 187 363 minecraft:dark_prismarine
fill 143 187 355 143 187 356 minecraft:blue_terracotta
setblock 143 187 357 minecraft:dark_prismarine
fill 143 187 358 143 187 361 minecraft:blue_terracotta
setblock 143 187 362 minecraft:dark_prismarine
fill 143 187 363 146 187 363 minecraft:blue_terracotta
fill 144 187 322 145 210 322 minecraft:blue_terracotta
fill 144 187 359 144 187 360 minecraft:blue_terracotta
setblock 144 187 361 minecraft:dark_prismarine
fill 144 187 362 147 187 362 minecraft:blue_terracotta
setblock 147 187 363 minecraft:dark_prismarine
setblock 148 187 362 minecraft:dark_prismarine
fill 148 187 363 151 187 363 minecraft:blue_terracotta
fill 149 187 362 152 187 362 minecraft:blue_terracotta
fill 152 187 361 153 187 361 minecraft:blue_terracotta
setblock 152 187 363 minecraft:dark_prismarine
fill 153 187 323 156 187 323 minecraft:blue_terracotta
setblock 153 187 362 minecraft:dark_prismarine
fill 153 187 363 156 187 363 minecraft:blue_terracotta
setblock 154 187 361 minecraft:dark_prismarine
fill 154 187 362 157 187 362 minecraft:blue_terracotta
fill 155 187 361 158 187 361 minecraft:blue_terracotta
fill 156 187 356 156 189 356 minecraft:iron_bars
setblock 156 187 358 minecraft:pink_terracotta
setblock 157 187 323 minecraft:dark_prismarine
setblock 157 187 363 minecraft:dark_prismarine
fill 158 187 323 161 187 323 minecraft:blue_terracotta
setblock 158 187 362 minecraft:dark_prismarine
fill 158 187 363 161 187 363 minecraft:blue_terracotta
fill 159 187 362 160 187 362 minecraft:blue_terracotta
fill 160 187 328 160 194 328 minecraft:green_terracotta
setblock 162 187 363 minecraft:dark_prismarine
setblock 163 187 363 minecraft:blue_terracotta
setblock 168 187 328 minecraft:pink_terracotta
fill 169 187 323 171 187 323 minecraft:blue_terracotta
fill 169 187 363 171 187 363 minecraft:blue_terracotta
setblock 172 187 323 minecraft:dark_prismarine
fill 172 187 324 175 187 324 minecraft:blue_terracotta
setblock 172 187 362 minecraft:blue_terracotta
setblock 172 187 363 minecraft:dark_prismarine
fill 173 187 323 176 187 323 minecraft:blue_terracotta
setblock 173 187 362 minecraft:dark_prismarine
fill 173 187 363 176 187 363 minecraft:blue_terracotta
setblock 174 187 361 minecraft:dark_prismarine
fill 174 187 362 177 187 362 minecraft:blue_terracotta
setblock 175 187 325 minecraft:dark_prismarine
fill 175 187 361 178 187 361 minecraft:blue_terracotta
setblock 176 187 324 minecraft:dark_prismarine
fill 176 187 325 178 188 325 minecraft:blue_terracotta
setblock 177 187 323 minecraft:dark_prismarine
fill 177 187 324 180 187 324 minecraft:blue_terracotta
setblock 177 187 363 minecraft:dark_prismarine
fill 178 187 323 181 187 323 minecraft:blue_terracotta
fill 178 187 344 178 189 344 minecraft:iron_bars
setblock 178 187 362 minecraft:dark_prismarine
fill 178 187 363 181 187 363 minecraft:blue_terracotta
setblock 179 187 361 minecraft:dark_prismarine
fill 179 187 362 182 187 362 minecraft:blue_terracotta
fill 180 187 358 180 187 359 minecraft:blue_terracotta
setblock 180 187 360 minecraft:dark_prismarine
fill 180 187 361 182 188 361 minecraft:blue_terracotta
setblock 181 187 324 minecraft:dark_prismarine
fill 181 187 325 182 187 325 minecraft:blue_terracotta
setblock 181 187 334 minecraft:dark_prismarine
fill 181 187 335 181 187 338 minecraft:blue_terracotta
setblock 181 187 339 minecraft:dark_prismarine
fill 181 187 340 182 187 340 minecraft:blue_terracotta
fill 181 187 356 181 187 358 minecraft:blue_terracotta
setblock 181 187 359 minecraft:dark_prismarine
fill 181 187 360 182 189 360 minecraft:blue_terracotta
setblock 182 187 323 minecraft:dark_prismarine
fill 182 187 324 182 190 324 minecraft:blue_terracotta
fill 182 187 326 182 187 327 minecraft:blue_terracotta
setblock 182 187 328 minecraft:dark_prismarine
fill 182 187 329 182 187 332 minecraft:blue_terracotta
setblock 182 187 333 minecraft:dark_prismarine
fill 182 187 334 182 187 337 minecraft:blue_terracotta
setblock 182 187 338 minecraft:dark_prismarine
fill 182 187 339 182 188 339 minecraft:blue_terracotta
fill 182 187 341 182 187 342 minecraft:blue_terracotta
setblock 182 187 343 minecraft:dark_prismarine
setblock 182 187 346 minecraft:purple_concrete
fill 182 187 354 182 187 357 minecraft:blue_terracotta
setblock 182 187 358 minecraft:dark_prismarine
fill 182 187 359 182 190 359 minecraft:blue_terracotta
setblock 182 187 363 minecraft:dark_prismarine
setblock 141 188 342 minecraft:cyan_concrete
setblock 142 188 323 minecraft:blue_terracotta
fill 142 188 338 142 188 341 minecraft:blue_terracotta
setblock 142 188 342 minecraft:dark_prismarine
fill 142 188 343 142 191 343 minecraft:blue_terracotta
setblock 142 188 346 minecraft:purple_concrete
fill 142 188 353 142 188 356 minecraft:blue_terracotta
setblock 142 188 357 minecraft:dark_prismarine
fill 142 188 358 142 188 361 minecraft:blue_terracotta
setblock 142 188 362 minecraft:dark_prismarine
fill 142 188 363 145 188 363 minecraft:blue_terracotta
setblock 143 188 356 minecraft:dark_prismarine
fill 143 188 357 143 188 360 minecraft:blue_terracotta
setblock 143 188 361 minecraft:dark_prismarine
fill 143 188 362 146 188 362 minecraft:blue_terracotta
setblock 146 188 363 minecraft:dark_prismarine
fill 147 188 348 147 210 348 minecraft:magenta_terracotta
setblock 147 188 362 minecraft:dark_prismarine
fill 147 188 363 150 188 363 minecraft:blue_terracotta
fill 148 188 362 151 188 362 minecraft:blue_terracotta
setblock 151 188 363 minecraft:dark_prismarine
setblock 152 188 362 minecraft:dark_prismarine
fill 152 188 363 155 188 363 minecraft:blue_terracotta
fill 153 188 323 155 188 323 minecraft:blue_terracotta
setblock 153 188 361 minecraft:dark_prismarine
fill 153 188 362 156 188 362 minecraft:blue_terracotta
fill 154 188 361 157 188 361 minecraft:blue_terracotta
setblock 156 188 323 minecraft:dark_prismarine
fill 156 188 358 156 234 358 minecraft:magenta_terracotta
setblock 156 188 363 minecraft:dark_prismarine
fill 157 188 323 160 188 323 minecraft:blue_terracotta
setblock 157 188 362 minecraft:dark_prismarine
fill 157 188 363 160 188 363 minecraft:blue_terracotta
fill 158 188 362 159 188 362 minecraft:blue_terracotta
setblock 161 188 323 minecraft:dark_prismarine
setblock 161 188 363 minecraft:dark_prismarine
setblock 162 188 363 minecraft:blue_terracotta
fill 168 188 323 170 188 323 minecraft:blue_terracotta
fill 168 188 328 168 234 328 minecraft:magenta_terracotta
fill 169 188 363 170 188 363 minecraft:blue_terracotta
setblock 171 188 323 minecraft:dark_prismarine
fill 171 188 324 174 188 324 minecraft:blue_terracotta
setblock 171 188 362 minecraft:blue_terracotta
setblock 171 188 363 minecraft:dark_prismarine
fill 172 188 323 175 188 323 minecraft:blue_terracotta
setblock 172 188 362 minecraft:dark_prismarine
fill 172 188 363 175 188 363 minecraft:blue_terracotta
fill 173 188 331 174 189 331 minecraft:spruce_planks
fill 173 188 362 176 188 362 minecraft:blue_terracotta
fill 174 188 330 174 189 330 minecraft:spruce_planks
fill 174 188 361 177 188 361 minecraft:blue_terracotta
setblock 175 188 324 minecraft:dark_prismarine
fill 175 188 325 175 191 325 minecraft:blue_terracotta
setblock 176 188 323 minecraft:dark_prismarine
fill 176 188 324 179 188 324 minecraft:blue_terracotta
setblock 176 188 363 minecraft:dark_prismarine
fill 177 188 323 180 188 323 minecraft:blue_terracotta
fill 177 188 338 177 213 338 minecraft:magenta_terracotta
setblock 177 188 362 minecraft:dark_prismarine
fill 177 188 363 180 188 363 minecraft:blue_terracotta
setblock 178 188 361 minecraft:dark_prismarine
fill 178 188 362 181 188 362 minecraft:blue_terracotta
fill 179 188 361 179 190 361 minecraft:blue_terracotta
setblock 180 188 324 minecraft:dark_prismarine
setblock 180 188 359 minecraft:dark_prismarine
fill 180 188 360 180 189 360 minecraft:blue_terracotta
setblock 181 188 323 minecraft:dark_prismarine
fill 181 188 324 181 189 324 minecraft:blue_terracotta
setblock 181 188 357 minecraft:blue_terracotta
setblock 181 188 358 minecraft:dark_prismarine
fill 181 188 359 181 190 359 minecraft:blue_terracotta
setblock 181 188 363 minecraft:dark_prismarine
fill 182 188 323 182 191 323 minecraft:blue_terracotta
fill 182 188 325 182 188 326 minecraft:blue_terracotta
fill 182 188 335 182 188 336 minecraft:blue_terracotta
setblock 182 188 337 minecraft:dark_prismarine
setblock 182 188 338 minecraft:blue_terracotta
fill 182 188 340 182 188 341 minecraft:blue_terracotta
setblock 182 188 342 minecraft:dark_prismarine
fill 182 188 355 182 188 356 minecraft:blue_terracotta
setblock 182 188 357 minecraft:dark_prismarine
fill 182 188 358 182 191 358 minecraft:blue_terracotta
setblock 182 188 362 minecraft:dark_prismarine
fill 182 188 363 182 191 363 minecraft:blue_terracotta
fill 141 189 342 142 190 342 minecraft:blue_terracotta
setblock 142 189 327 minecraft:purple_concrete
setblock 142 189 340 minecraft:blue_terracotta
setblock 142 189 341 minecraft:dark_prismarine
setblock 142 189 352 minecraft:purple_concrete
setblock 142 189 355 minecraft:blue_terracotta
setblock 142 189 356 minecraft:dark_prismarine
fill 142 189 357 142 189 360 minecraft:blue_terracotta
setblock 142 189 361 minecraft:dark_prismarine
fill 142 189 362 144 189 363 minecraft:blue_terracotta
fill 143 189 358 143 189 359 minecraft:blue_terracotta
setblock 143 189 360 minecraft:dark_prismarine
fill 143 189 361 143 190 361 minecraft:blue_terracotta
setblock 144 189 325 minecraft:light[level=13]
setblock 144 189 333 minecraft:light[level=13]
setblock 144 189 341 minecraft:light[level=13]
setblock 144 189 349 minecraft:light[level=13]
setblock 144 189 357 minecraft:light[level=13]
setblock 145 189 362 minecraft:blue_terracotta
setblock 145 189 363 minecraft:dark_prismarine
fill 146 189 363 149 189 363 minecraft:blue_terracotta
setblock 149 189 323 minecraft:purple_concrete
fill 149 189 362 150 189 362 minecraft:blue_terracotta
setblock 150 189 363 minecraft:dark_prismarine
setblock 151 189 362 minecraft:dark_prismarine
fill 151 189 363 154 189 363 minecraft:blue_terracotta
fill 152 189 323 154 189 323 minecraft:blue_terracotta
setblock 152 189 325 minecraft:light[level=13]
setblock 152 189 333 minecraft:light[level=13]
setblock 152 189 341 minecraft:light[level=13]
setblock 152 189 349 minecraft:light[level=13]
setblock 152 189 357 minecraft:light[level=13]
fill 152 189 362 155 189 362 minecraft:blue_terracotta
setblock 155 189 323 minecraft:dark_prismarine
setblock 155 189 363 minecraft:dark_prismarine
fill 156 189 323 159 189 323 minecraft:blue_terracotta
setblock 156 189 362 minecraft:dark_prismarine
fill 156 189 363 159 189 363 minecraft:blue_terracotta
fill 157 189 362 158 189 362 minecraft:blue_terracotta
fill 159 189 333 161 190 333 minecraft:dark_prismarine
setblock 160 189 323 minecraft:dark_prismarine
setblock 160 189 325 minecraft:light[level=13]
fill 160 189 332 161 190 332 minecraft:dark_prismarine
setblock 160 189 341 minecraft:light[level=13]
setblock 160 189 349 minecraft:light[level=13]
setblock 160 189 357 minecraft:light[level=13]
setblock 160 189 363 minecraft:dark_prismarine
setblock 161 189 363 minecraft:blue_terracotta
fill 168 189 323 169 189 323 minecraft:blue_terracotta
setblock 168 189 325 minecraft:light[level=13]
setblock 168 189 333 minecraft:light[level=13]
setblock 168 189 341 minecraft:light[level=13]
setblock 168 189 349 minecraft:light[level=13]
setblock 168 189 357 minecraft:light[level=13]
setblock 169 189 363 minecraft:blue_terracotta
setblock 170 189 323 minecraft:dark_prismarine
setblock 170 189 363 minecraft:dark_prismarine
fill 171 189 323 173 189 324 minecraft:blue_terracotta
setblock 171 189 362 minecraft:dark_prismarine
fill 171 189 363 174 189 363 minecraft:blue_terracotta
fill 172 189 362 175 189 362 minecraft:blue_terracotta
setblock 174 189 323 minecraft:blue_terracotta
setblock 174 189 324 minecraft:dark_prismarine
fill 174 189 325 174 192 325 minecraft:blue_terracotta
fill 174 189 339 175 190 339 minecraft:dark_prismarine
fill 174 189 361 176 189 361 minecraft:blue_terracotta
setblock 175 189 323 minecraft:dark_prismarine
fill 175 189 324 178 189 324 minecraft:blue_terracotta
fill 175 189 338 175 190 338 minecraft:dark_prismarine
fill 175 189 340 175 190 340 minecraft:dark_prismarine
setblock 175 189 363 minecraft:dark_prismarine
fill 176 189 323 179 189 323 minecraft:blue_terracotta
fill 176 189 325 177 189 325 minecraft:blue_terracotta
setblock 176 189 333 minecraft:light[level=13]
setblock 176 189 341 minecraft:light[level=13]
setblock 176 189 349 minecraft:light[level=13]
setblock 176 189 357 minecraft:light[level=13]
setblock 176 189 362 minecraft:dark_prismarine
fill 176 189 363 179 189 363 minecraft:blue_terracotta
setblock 177 189 361 minecraft:dark_prismarine
fill 177 189 362 180 189 362 minecraft:blue_terracotta
fill 178 189 361 178 191 361 minecraft:blue_terracotta
setblock 179 189 324 minecraft:dark_prismarine
setblock 180 189 323 minecraft:dark_prismarine
fill 180 189 324 180 192 324 minecraft:blue_terracotta
fill 180 189 361 181 189 361 minecraft:blue_terracotta
setblock 180 189 363 minecraft:dark_prismarine
fill 181 189 323 181 192 323 minecraft:blue_terracotta
setblock 181 189 358 minecraft:blue_terracotta
setblock 181 189 362 minecraft:dark_prismarine
fill 181 189 363 181 192 363 minecraft:blue_terracotta
setblock 182 189 325 minecraft:blue_terracotta
setblock 182 189 334 minecraft:purple_concrete
setblock 182 189 356 minecraft:dark_prismarine
setblock 182 189 357 minecraft:blue_terracotta
setblock 182 189 361 minecraft:dark_prismarine
fill 182 189 362 182 192 362 minecraft:blue_terracotta
setblock 142 190 333 minecraft:purple_concrete
fill 142 190 356 142 190 359 minecraft:blue_terracotta
setblock 142 190 360 minecraft:dark_prismarine
fill 142 190 361 142 191 363 minecraft:blue_terracotta
setblock 143 190 323 minecraft:purple_concrete
fill 143 190 362 143 190 363 minecraft:blue_terracotta
setblock 144 190 363 minecraft:dark_prismarine
fill 145 190 363 146 191 364 minecraft:blue_terracotta
fill 147 190 363 148 190 363 minecraft:blue_terracotta
setblock 147 190 364 minecraft:light_blue_wool
setblock 149 190 362 minecraft:blue_terracotta
setblock 149 190 363 minecraft:dark_prismarine
setblock 150 190 362 minecraft:dark_prismarine
fill 150 190 363 153 190 363 minecraft:blue_terracotta
fill 151 190 362 154 190 362 minecraft:blue_terracotta
fill 152 190 323 153 190 323 minecraft:blue_terracotta
fill 154 190 322 155 220 322 minecraft:blue_terracotta
setblock 154 190 323 minecraft:dark_prismarine
setblock 154 190 363 minecraft:dark_prismarine
fill 155 190 323 158 190 323 minecraft:blue_terracotta
setblock 155 190 362 minecraft:dark_prismarine
fill 155 190 363 158 190 363 minecraft:blue_terracotta
setblock 156 190 322 minecraft:light_blue_wool
fill 156 190 362 157 190 362 minecraft:blue_terracotta
setblock 159 190 323 minecraft:dark_prismarine
setblock 159 190 363 minecraft:dark_prismarine
fill 160 190 323 160 193 323 minecraft:blue_terracotta
setblock 160 190 363 minecraft:blue_terracotta
fill 167 190 323 168 190 323 minecraft:blue_terracotta
setblock 169 190 323 minecraft:dark_prismarine
setblock 169 190 363 minecraft:dark_prismarine
fill 170 190 323 172 190 324 minecraft:blue_terracotta
fill 170 190 363 173 190 363 minecraft:blue_terracotta
fill 171 190 362 174 190 362 minecraft:blue_terracotta
setblock 173 190 323 minecraft:blue_terracotta
setblock 173 190 324 minecraft:dark_prismarine
fill 173 190 325 173 193 325 minecraft:blue_terracotta
setblock 174 190 323 minecraft:dark_prismarine
fill 174 190 324 177 190 324 minecraft:blue_terracotta
fill 174 190 361 175 190 361 minecraft:blue_terracotta
setblock 174 190 363 minecraft:dark_prismarine
fill 175 190 323 178 190 323 minecraft:blue_terracotta
setblock 175 190 362 minecraft:dark_prismarine
fill 175 190 363 178 190 363 minecraft:blue_terracotta
setblock 176 190 325 minecraft:blue_terracotta
setblock 176 190 361 minecraft:dark_prismarine
fill 176 190 362 179 190 362 minecraft:blue_terracotta
setblock 177 190 325 minecraft:dark_prismarine
fill 177 190 361 177 191 361 minecraft:blue_terracotta
setblock 178 190 324 minecraft:dark_prismarine
fill 179 190 322 181 200 322 minecraft:blue_terracotta
setblock 179 190 323 minecraft:dark_prismarine
fill 179 190 324 179 193 324 minecraft:blue_terracotta
setblock 179 190 363 minecraft:dark_prismarine
fill 180 190 323 180 193 323 minecraft:blue_terracotta
setblock 180 190 362 minecraft:dark_prismarine
fill 180 190 363 180 193 363 minecraft:blue_terracotta
setblock 181 190 360 minecraft:blue_terracotta
setblock 181 190 361 minecraft:dark_prismarine
fill 181 190 362 181 193 362 minecraft:blue_terracotta
setblock 182 190 322 minecraft:light_blue_wool
setblock 182 190 325 minecraft:dark_prismarine
setblock 182 190 328 minecraft:purple_concrete
setblock 182 190 353 minecraft:purple_concrete
setblock 182 190 360 minecraft:dark_prismarine
fill 182 190 361 182 193 361 minecraft:blue_terracotta
fill 141 191 342 141 220 342 minecraft:blue_terracotta
setblock 142 191 339 minecraft:purple_concrete
fill 142 191 357 142 191 358 minecraft:blue_terracotta
setblock 142 191 359 minecraft:dark_prismarine
fill 142 191 360 142 194 360 minecraft:blue_terracotta
setblock 143 191 363 minecraft:dark_prismarine
setblock 144 191 325 minecraft:light[level=12]
setblock 144 191 332 minecraft:light[level=12]
setblock 144 191 339 minecraft:light[level=12]
setblock 144 191 346 minecraft:light[level=12]
setblock 144 191 353 minecraft:light[level=12]
setblock 144 191 360 minecraft:light[level=12]
fill 144 191 363 144 194 363 minecraft:blue_terracotta
fill 147 191 363 147 191 364 minecraft:blue_terracotta
setblock 148 191 363 minecraft:dark_prismarine
fill 149 191 363 152 191 363 minecraft:blue_terracotta
fill 150 191 362 153 191 362 minecraft:blue_terracotta
fill 151 191 323 152 191 323 minecraft:blue_terracotta
setblock 151 191 325 minecraft:light[level=12]
setblock 151 191 332 minecraft:light[level=12]
setblock 151 191 339 minecraft:light[level=12]
setblock 151 191 346 minecraft:light[level=12]
setblock 151 191 353 minecraft:light[level=12]
setblock 151 191 360 minecraft:light[level=12]
setblock 153 191 323 minecraft:dark_prismarine
setblock 153 191 363 minecraft:dark_prismarine
fill 154 191 323 157 191 323 minecraft:blue_terracotta
setblock 154 191 362 minecraft:dark_prismarine
fill 154 191 363 157 191 363 minecraft:blue_terracotta
fill 155 191 362 156 191 362 minecraft:blue_terracotta
fill 156 191 322 156 220 322 minecraft:blue_terracotta
setblock 158 191 323 minecraft:dark_prismarine
setblock 158 191 325 minecraft:light[level=12]
setblock 158 191 332 minecraft:light[level=12]
setblock 158 191 339 minecraft:light[level=12]
setblock 158 191 346 minecraft:light[level=12]
setblock 158 191 353 minecraft:light[level=12]
setblock 158 191 360 minecraft:light[level=12]
setblock 158 191 363 minecraft:dark_prismarine
fill 159 191 323 159 194 323 minecraft:blue_terracotta
setblock 159 191 363 minecraft:blue_terracotta
setblock 162 191 323 minecraft:purple_concrete
setblock 162 191 363 minecraft:purple_concrete
setblock 165 191 325 minecraft:light[level=12]
setblock 165 191 332 minecraft:light[level=12]
setblock 165 191 339 minecraft:light[level=12]
setblock 165 191 346 minecraft:light[level=12]
setblock 165 191 353 minecraft:light[level=12]
setblock 165 191 360 minecraft:light[level=12]
fill 166 191 323 167 191 323 minecraft:blue_terracotta
setblock 168 191 323 minecraft:dark_prismarine
setblock 168 191 363 minecraft:dark_prismarine
fill 169 191 323 171 191 324 minecraft:blue_terracotta
fill 169 191 354 169 216 354 minecraft:magenta_terracotta
fill 169 191 363 172 191 363 minecraft:blue_terracotta
fill 171 191 362 173 191 362 minecraft:blue_terracotta
setblock 172 191 323 minecraft:blue_terracotta
setblock 172 191 324 minecraft:dark_prismarine
fill 172 191 325 172 194 325 minecraft:blue_terracotta
setblock 172 191 332 minecraft:light[level=12]
setblock 172 191 339 minecraft:light[level=12]
setblock 172 191 346 minecraft:light[level=12]
setblock 172 191 353 minecraft:light[level=12]
setblock 172 191 360 minecraft:light[level=12]
setblock 173 191 323 minecraft:dark_prismarine
fill 173 191 324 176 191 324 minecraft:blue_terracotta
setblock 173 191 363 minecraft:dark_prismarine
fill 174 191 323 177 191 323 minecraft:blue_terracotta
setblock 174 191 361 minecraft:blue_terracotta
setblock 174 191 362 minecraft:dark_prismarine
fill 174 191 363 177 191 363 minecraft:blue_terracotta
setblock 175 191 361 minecraft:dark_prismarine
fill 175 191 362 178 191 362 minecraft:blue_terracotta
setblock 176 191 325 minecraft:dark_prismarine
fill 176 191 361 176 192 361 minecraft:blue_terracotta
setblock 177 191 324 minecraft:dark_prismarine
setblock 178 191 323 minecraft:dark_prismarine
fill 178 191 324 178 194 324 minecraft:blue_terracotta
setblock 178 191 363 minecraft:dark_prismarine
fill 179 191 323 179 194 323 minecraft:blue_terracotta
setblock 179 191 325 minecraft:light[level=12]
setblock 179 191 332 minecraft:light[level=12]
setblock 179 191 339 minecraft:light[level=12]
setblock 179 191 346 minecraft:light[level=12]
setblock 179 191 353 minecraft:light[level=12]
setblock 179 191 360 minecraft:light[level=12]
setblock 179 191 362 minecraft:dark_prismarine
fill 179 191 363 179 194 363 minecraft:blue_terracotta
fill 180 191 362 180 194 362 minecraft:blue_terracotta
setblock 181 191 360 minecraft:dark_prismarine
fill 181 191 361 181 192 361 minecraft:blue_terracotta
fill 182 191 322 182 192 322 minecraft:blue_terracotta
setblock 182 191 324 minecraft:dark_prismarine
setblock 182 191 347 minecraft:purple_concrete
setblock 182 191 359 minecraft:dark_prismarine
fill 182 191 360 182 194 360 minecraft:blue_terracotta
setblock 142 192 326 minecraft:purple_concrete
setblock 142 192 343 minecraft:dark_prismarine
fill 142 192 344 142 194 345 minecraft:blue_terracotta
setblock 142 192 359 minecraft:blue_terracotta
fill 142 192 361 142 192 362 minecraft:blue_terracotta
setblock 142 192 363 minecraft:dark_prismarine
fill 143 192 363 143 195 363 minecraft:blue_terracotta
fill 145 192 363 146 192 363 minecraft:blue_terracotta
setblock 145 192 364 minecraft:cyan_concrete
fill 146 192 364 147 195 364 minecraft:blue_terracotta
setblock 147 192 363 minecraft:dark_prismarine
fill 148 192 363 151 192 363 minecraft:blue_terracotta
fill 150 192 323 151 192 323 minecraft:blue_terracotta
fill 150 192 362 152 192 362 minecraft:blue_terracotta
setblock 152 192 323 minecraft:dark_prismarine
setblock 152 192 363 minecraft:dark_prismarine
fill 153 192 323 156 192 323 minecraft:blue_terracotta
setblock 153 192 362 minecraft:dark_prismarine
fill 153 192 363 156 192 363 minecraft:blue_terracotta
fill 154 192 362 155 192 362 minecraft:blue_terracotta
setblock 157 192 323 minecraft:dark_prismarine
setblock 157 192 363 minecraft:dark_prismarine
fill 158 192 323 158 195 323 minecraft:blue_terracotta
fill 158 192 363 158 193 363 minecraft:blue_terracotta
fill 164 192 323 166 192 323 minecraft:blue_terracotta
setblock 167 192 323 minecraft:dark_prismarine
fill 168 192 323 170 192 324 minecraft:blue_terracotta
fill 168 192 363 171 192 363 minecraft:blue_terracotta
fill 170 192 355 170 211 355 minecraft:magenta_terracotta
fill 170 192 362 172 192 362 minecraft:blue_terracotta
setblock 171 192 323 minecraft:blue_terracotta
setblock 171 192 324 minecraft:dark_prismarine
fill 171 192 325 171 195 325 minecraft:blue_terracotta
setblock 172 192 323 minecraft:dark_prismarine
fill 172 192 324 175 192 324 minecraft:blue_terracotta
setblock 172 192 363 minecraft:dark_prismarine
fill 173 192 323 176 192 323 minecraft:blue_terracotta
setblock 173 192 362 minecraft:dark_prismarine
fill 173 192 363 176 192 363 minecraft:blue_terracotta
fill 174 192 362 177 192 362 minecraft:blue_terracotta
setblock 175 192 325 minecraft:dark_prismarine
fill 175 192 361 175 193 361 minecraft:blue_terracotta
setblock 176 192 324 minecraft:dark_prismarine
fill 176 192 325 177 194 325 minecraft:blue_terracotta
setblock 177 192 323 minecraft:dark_prismarine
fill 177 192 324 177 195 324 minecraft:blue_terracotta
setblock 177 192 363 minecraft:dark_prismarine
fill 178 192 323 178 195 323 minecraft:blue_terracotta
setblock 178 192 362 minecraft:dark_prismarine
fill 178 192 363 178 195 363 minecraft:blue_terracotta
fill 179 192 362 179 195 362 minecraft:blue_terracotta
setblock 182 192 323 minecraft:dark_prismarine
fill 182 192 324 182 195 324 minecraft:blue_terracotta
setblock 182 192 341 minecraft:purple_concrete
setblock 182 192 359 minecraft:blue_terracotta
setblock 182 192 363 minecraft:dark_prismarine
setblock 142 193 332 minecraft:purple_concrete
setblock 142 193 342 minecraft:dark_prismarine
fill 142 193 343 142 196 343 minecraft:blue_terracotta
setblock 142 193 346 minecraft:blue_terracotta
setblock 142 193 347 minecraft:dark_prismarine
setblock 142 193 351 minecraft:purple_concrete
setblock 142 193 361 minecraft:blue_terracotta
setblock 142 193 362 minecraft:dark_prismarine
fill 142 193 363 142 196 363 minecraft:blue_terracotta
fill 144 193 323 144 194 323 minecraft:purple_concrete
fill 145 193 363 145 193 364 minecraft:blue_terracotta
setblock 146 193 363 minecraft:dark_prismarine
fill 147 193 363 150 193 363 minecraft:blue_terracotta
fill 148 193 323 150 193 323 minecraft:blue_terracotta
fill 150 193 362 151 193 362 minecraft:blue_terracotta
setblock 151 193 323 minecraft:dark_prismarine
setblock 151 193 363 minecraft:dark_prismarine
fill 152 193 323 155 193 323 minecraft:blue_terracotta
setblock 152 193 362 minecraft:dark_prismarine
fill 152 193 363 155 193 363 minecraft:blue_terracotta
fill 153 193 324 154 193 324 minecraft:blue_terracotta
fill 153 193 362 154 194 362 minecraft:blue_terracotta
setblock 155 193 324 minecraft:dark_prismarine
setblock 156 193 323 minecraft:dark_prismarine
fill 156 193 324 156 196 324 minecraft:blue_terracotta
setblock 156 193 363 minecraft:dark_prismarine
fill 157 193 323 157 196 323 minecraft:blue_terracotta
fill 157 193 363 157 196 363 minecraft:blue_terracotta
setblock 161 193 323 minecraft:dark_prismarine
fill 162 193 323 165 193 323 minecraft:blue_terracotta
setblock 166 193 323 minecraft:dark_prismarine
fill 167 193 323 169 193 324 minecraft:blue_terracotta
fill 167 193 363 170 193 363 minecraft:blue_terracotta
setblock 170 193 323 minecraft:blue_terracotta
setblock 170 193 324 minecraft:dark_prismarine
fill 170 193 325 170 196 325 minecraft:blue_terracotta
fill 170 193 362 171 193 362 minecraft:blue_terracotta
setblock 171 193 323 minecraft:dark_prismarine
fill 171 193 324 174 193 324 minecraft:blue_terracotta
setblock 171 193 363 minecraft:dark_prismarine
fill 172 193 323 175 193 323 minecraft:blue_terracotta
setblock 172 193 362 minecraft:dark_prismarine
fill 172 193 363 175 193 363 minecraft:blue_terracotta
fill 173 193 362 176 193 362 minecraft:blue_terracotta
setblock 174 193 325 minecraft:dark_prismarine
setblock 175 193 324 minecraft:dark_prismarine
fill 175 193 325 175 196 325 minecraft:blue_terracotta
setblock 176 193 323 minecraft:dark_prismarine
fill 176 193 324 176 196 324 minecraft:blue_terracotta
setblock 176 193 363 minecraft:dark_prismarine
fill 177 193 323 177 196 323 minecraft:blue_terracotta
setblock 177 193 362 minecraft:dark_prismarine
fill 177 193 363 177 196 363 minecraft:blue_terracotta
fill 178 193 362 178 196 362 minecraft:blue_terracotta
setblock 180 193 324 minecraft:dark_prismarine
setblock 181 193 323 minecraft:dark_prismarine
setblock 181 193 363 minecraft:dark_prismarine
setblock 182 193 322 minecraft:cyan_concrete
fill 182 193 323 182 196 323 minecraft:blue_terracotta
fill 182 193 325 182 194 325 minecraft:blue_terracotta
setblock 182 193 335 minecraft:purple_concrete
setblock 182 193 354 minecraft:purple_concrete
setblock 182 193 362 minecraft:dark_prismarine
fill 182 193 363 182 196 363 minecraft:blue_terracotta
setblock 142 194 338 minecraft:purple_concrete
fill 142 194 342 142 197 342 minecraft:blue_terracotta
setblock 142 194 346 minecraft:dark_prismarine
fill 142 194 347 142 195 349 minecraft:blue_terracotta
setblock 142 194 357 minecraft:purple_concrete
setblock 142 194 361 minecraft:dark_prismarine
fill 142 194 362 142 197 362 minecraft:blue_terracotta
fill 145 194 356 145 211 356 minecraft:iron_bars
setblock 145 194 363 minecraft:dark_prismarine
fill 145 194 364 145 221 364 minecraft:blue_terracotta
fill 146 194 363 149 194 363 minecraft:blue_terracotta
fill 147 194 323 149 194 323 minecraft:blue_terracotta
fill 149 194 362 150 194 362 minecraft:blue_terracotta
setblock 150 194 323 minecraft:dark_prismarine
setblock 150 194 363 minecraft:dark_prismarine
fill 151 194 323 153 194 324 minecraft:blue_terracotta
setblock 151 194 362 minecraft:dark_prismarine
fill 151 194 363 154 194 363 minecraft:blue_terracotta
fill 152 194 362 152 197 362 minecraft:blue_terracotta
setblock 154 194 323 minecraft:blue_terracotta
setblock 154 194 324 minecraft:dark_prismarine
setblock 155 194 323 minecraft:dark_prismarine
fill 155 194 324 155 197 324 minecraft:blue_terracotta
fill 155 194 332 155 221 332 minecraft:magenta_terracotta
setblock 155 194 363 minecraft:dark_prismarine
fill 156 194 323 156 197 323 minecraft:blue_terracotta
fill 156 194 363 156 197 363 minecraft:blue_terracotta
fill 157 194 324 157 195 324 minecraft:blue_terracotta
setblock 160 194 323 minecraft:dark_prismarine
fill 161 194 323 164 194 323 minecraft:blue_terracotta
setblock 161 194 363 minecraft:purple_concrete
setblock 165 194 323 minecraft:dark_prismarine
fill 165 194 324 168 194 324 minecraft:blue_terracotta
fill 166 194 323 169 194 323 minecraft:blue_terracotta
fill 166 194 363 169 194 363 minecraft:blue_terracotta
setblock 168 194 325 minecraft:dark_prismarine
setblock 169 194 324 minecraft:dark_prismarine
fill 169 194 325 169 197 325 minecraft:blue_terracotta
fill 169 194 362 170 194 362 minecraft:blue_terracotta
setblock 170 194 323 minecraft:dark_prismarine
fill 170 194 324 173 194 324 minecraft:blue_terracotta
setblock 170 194 363 minecraft:dark_prismarine
fill 171 194 323 174 194 323 minecraft:blue_terracotta
setblock 171 194 362 minecraft:dark_prismarine
fill 171 194 363 174 194 363 minecraft:blue_terracotta
fill 172 194 362 175 194 362 minecraft:blue_terracotta
setblock 173 194 325 minecraft:dark_prismarine
setblock 174 194 324 minecraft:dark_prismarine
fill 174 194 325 174 197 325 minecraft:blue_terracotta
setblock 175 194 323 minecraft:dark_prismarine
fill 175 194 324 175 197 324 minecraft:blue_terracotta
setblock 175 194 363 minecraft:dark_prismarine
fill 176 194 323 176 197 323 minecraft:blue_terracotta
setblock 176 194 362 minecraft:dark_prismarine
fill 176 194 363 176 197 363 minecraft:blue_terracotta
fill 177 194 362 177 197 362 minecraft:blue_terracotta
setblock 179 194 324 minecraft:dark_prismarine
setblock 180 194 323 minecraft:dark_prismarine
fill 180 194 324 180 197 324 minecraft:blue_terracotta
setblock 180 194 363 minecraft:dark_prismarine
fill 181 194 323 181 197 323 minecraft:blue_terracotta
setblock 181 194 362 minecraft:dark_prismarine
fill 181 194 363 181 197 363 minecraft:blue_terracotta
fill 182 194 322 182 220 322 minecraft:blue_terracotta
setblock 182 194 329 minecraft:purple_concrete
setblock 182 194 348 minecraft:purple_concrete
setblock 182 194 361 minecraft:dark_prismarine
fill 182 194 362 182 197 362 minecraft:blue_terracotta
setblock 142 195 344 minecraft:blue_terracotta
setblock 142 195 345 minecraft:dark_prismarine
fill 142 195 346 143 197 346 minecraft:blue_terracotta
setblock 142 195 350 minecraft:dark_prismarine
fill 142 195 351 142 198 351 minecraft:blue_terracotta
fill 142 195 361 142 197 361 minecraft:blue_terracotta
setblock 143 195 344 minecraft:dark_prismarine
fill 143 195 345 143 198 345 minecraft:blue_terracotta
fill 143 195 347 143 195 348 minecraft:blue_terracotta
setblock 144 195 363 minecraft:dark_prismarine
fill 145 195 323 148 195 323 minecraft:blue_terracotta
fill 145 195 363 148 195 363 minecraft:blue_terracotta
setblock 149 195 323 minecraft:dark_prismarine
fill 149 195 324 152 195 324 minecraft:blue_terracotta
setblock 149 195 362 minecraft:blue_terracotta
setblock 149 195 363 minecraft:dark_prismarine
fill 150 195 323 153 195 323 minecraft:blue_terracotta
setblock 150 195 362 minecraft:dark_prismarine
fill 150 195 363 153 195 363 minecraft:blue_terracotta
fill 151 195 362 151 198 362 minecraft:blue_terracotta
setblock 153 195 324 minecraft:dark_prismarine
fill 153 195 362 153 196 362 minecraft:blue_terracotta
setblock 154 195 323 minecraft:dark_prismarine
fill 154 195 324 154 198 324 minecraft:blue_terracotta
setblock 154 195 363 minecraft:dark_prismarine
fill 155 195 323 155 198 323 minecraft:blue_terracotta
fill 155 195 333 155 196 333 minecraft:magenta_terracotta
fill 155 195 363 155 198 363 minecraft:blue_terracotta
setblock 158 195 324 minecraft:dark_prismarine
setblock 159 195 323 minecraft:dark_prismarine
fill 160 195 323 163 195 323 minecraft:blue_terracotta
setblock 164 195 323 minecraft:dark_prismarine
fill 164 195 324 167 195 324 minecraft:blue_terracotta
fill 165 195 323 168 195 323 minecraft:blue_terracotta
fill 166 195 363 168 195 363 minecraft:blue_terracotta
setblock 167 195 325 minecraft:dark_prismarine
setblock 168 195 324 minecraft:dark_prismarine
fill 168 195 325 168 198 325 minecraft:blue_terracotta
setblock 169 195 323 minecraft:dark_prismarine
fill 169 195 324 172 195 324 minecraft:blue_terracotta
setblock 169 195 362 minecraft:blue_terracotta
setblock 169 195 363 minecraft:dark_prismarine
fill 170 195 323 173 195 323 minecraft:blue_terracotta
setblock 170 195 326 minecraft:blue_terracotta
setblock 170 195 362 minecraft:dark_prismarine
fill 170 195 363 173 195 363 minecraft:blue_terracotta
setblock 171 195 326 minecraft:dark_prismarine
fill 171 195 362 174 195 362 minecraft:blue_terracotta
setblock 172 195 325 minecraft:dark_prismarine
fill 172 195 326 174 196 326 minecraft:blue_terracotta
fill 172 195 330 174 196 330 minecraft:black_concrete
setblock 173 195 324 minecraft:dark_prismarine
fill 173 195 325 173 198 325 minecraft:blue_terracotta
fill 173 195 329 174 196 329 minecraft:black_concrete
setblock 174 195 323 minecraft:dark_prismarine
fill 174 195 324 174 198 324 minecraft:blue_terracotta
setblock 174 195 361 minecraft:blue_terracotta
setblock 174 195 363 minecraft:dark_prismarine
fill 175 195 323 175 198 323 minecraft:blue_terracotta
setblock 175 195 362 minecraft:dark_prismarine
fill 175 195 363 175 198 363 minecraft:blue_terracotta
setblock 176 195 325 minecraft:blue_terracotta
fill 176 195 362 176 198 362 minecraft:blue_terracotta
setblock 177 195 325 minecraft:dark_prismarine
setblock 178 195 324 minecraft:dark_prismarine
setblock 179 195 323 minecraft:dark_prismarine
fill 179 195 324 179 198 324 minecraft:blue_terracotta
setblock 179 195 363 minecraft:dark_prismarine
fill 180 195 323 180 198 323 minecraft:blue_terracotta
setblock 180 195 362 minecraft:dark_prismarine
fill 180 195 363 180 198 363 minecraft:blue_terracotta
fill 181 195 324 181 196 324 minecraft:blue_terracotta
setblock 181 195 362 minecraft:blue_terracotta
setblock 182 195 325 minecraft:dark_prismarine
fill 182 195 326 182 198 326 minecraft:blue_terracotta
setblock 182 195 342 minecraft:purple_concrete
setblock 182 195 360 minecraft:dark_prismarine
fill 182 195 361 182 198 361 minecraft:blue_terracotta
setblock 142 196 323 minecraft:blue_terracotta
setblock 142 196 325 minecraft:purple_concrete
fill 142 196 341 142 198 341 minecraft:blue_terracotta
setblock 142 196 344 minecraft:dark_prismarine
fill 142 196 345 142 199 345 minecraft:blue_terracotta
fill 142 196 347 142 196 348 minecraft:blue_terracotta
setblock 142 196 349 minecraft:dark_prismarine
fill 142 196 350 143 198 350 minecraft:blue_terracotta
fill 142 196 352 142 196 353 minecraft:blue_terracotta
setblock 143 196 323 minecraft:dark_prismarine
setblock 143 196 343 minecraft:dark_prismarine
fill 143 196 344 143 199 344 minecraft:blue_terracotta
setblock 143 196 347 minecraft:blue_terracotta
setblock 143 196 348 minecraft:dark_prismarine
fill 143 196 349 143 199 349 minecraft:blue_terracotta
setblock 143 196 363 minecraft:dark_prismarine
fill 144 196 323 147 196 323 minecraft:blue_terracotta
fill 144 196 363 147 196 363 minecraft:blue_terracotta
setblock 146 196 364 minecraft:light_blue_wool
fill 147 196 364 147 218 364 minecraft:blue_terracotta
setblock 148 196 323 minecraft:dark_prismarine
fill 148 196 324 151 196 324 minecraft:blue_terracotta
setblock 148 196 362 minecraft:blue_terracotta
setblock 148 196 363 minecraft:dark_prismarine
fill 149 196 323 152 196 323 minecraft:blue_terracotta
setblock 149 196 362 minecraft:dark_prismarine
fill 149 196 363 152 196 363 minecraft:blue_terracotta
fill 150 196 362 150 198 362 minecraft:blue_terracotta
setblock 151 196 325 minecraft:dark_prismarine
setblock 152 196 324 minecraft:dark_prismarine
fill 152 196 325 154 197 325 minecraft:blue_terracotta
setblock 153 196 323 minecraft:dark_prismarine
fill 153 196 324 153 199 324 minecraft:blue_terracotta
setblock 153 196 363 minecraft:dark_prismarine
fill 154 196 323 154 199 323 minecraft:blue_terracotta
fill 154 196 331 154 211 331 minecraft:magenta_terracotta
fill 154 196 363 154 199 363 minecraft:blue_terracotta
setblock 157 196 324 minecraft:dark_prismarine
setblock 158 196 323 minecraft:dark_prismarine
fill 158 196 324 161 196 324 minecraft:blue_terracotta
fill 159 196 323 162 196 323 minecraft:blue_terracotta
setblock 162 196 324 minecraft:dark_prismarine
setblock 163 196 323 minecraft:dark_prismarine
fill 163 196 324 166 196 324 minecraft:blue_terracotta
fill 164 196 323 167 196 323 minecraft:blue_terracotta
setblock 165 196 325 minecraft:blue_terracotta
fill 165 196 363 167 196 363 minecraft:blue_terracotta
setblock 166 196 325 minecraft:dark_prismarine
setblock 167 196 324 minecraft:dark_prismarine
fill 167 196 325 167 199 325 minecraft:blue_terracotta
setblock 168 196 323 minecraft:dark_prismarine
fill 168 196 324 171 196 324 minecraft:blue_terracotta
fill 168 196 326 169 196 326 minecraft:blue_terracotta
setblock 168 196 362 minecraft:blue_terracotta
setblock 168 196 363 minecraft:dark_prismarine
fill 169 196 323 172 196 323 minecraft:blue_terracotta
setblock 169 196 362 minecraft:dark_prismarine
fill 169 196 363 172 196 363 minecraft:blue_terracotta
setblock 170 196 326 minecraft:dark_prismarine
fill 170 196 362 173 196 362 minecraft:blue_terracotta
setblock 171 196 325 minecraft:dark_prismarine
fill 171 196 326 171 199 326 minecraft:blue_terracotta
setblock 172 196 324 minecraft:dark_prismarine
fill 172 196 325 172 199 325 minecraft:blue_terracotta
setblock 173 196 323 minecraft:dark_prismarine
fill 173 196 324 173 199 324 minecraft:blue_terracotta
fill 173 196 361 173 197 361 minecraft:blue_terracotta
setblock 173 196 363 minecraft:dark_prismarine
fill 174 196 323 174 199 323 minecraft:blue_terracotta
setblock 174 196 362 minecraft:dark_prismarine
fill 174 196 363 174 199 363 minecraft:blue_terracotta
setblock 175 196 326 minecraft:dark_prismarine
fill 175 196 362 175 199 362 minecraft:blue_terracotta
setblock 176 196 325 minecraft:dark_prismarine
setblock 177 196 324 minecraft:dark_prismarine
fill 177 196 325 178 197 325 minecraft:blue_terracotta
setblock 178 196 323 minecraft:dark_prismarine
fill 178 196 324 178 199 324 minecraft:blue_terracotta
setblock 178 196 363 minecraft:dark_prismarine
fill 179 196 323 179 199 323 minecraft:blue_terracotta
setblock 179 196 362 minecraft:dark_prismarine
fill 179 196 363 179 199 363 minecraft:blue_terracotta
fill 180 196 362 180 197 362 minecraft:blue_terracotta
setblock 182 196 324 minecraft:dark_prismarine
fill 182 196 325 182 199 325 minecraft:blue_terracotta
fill 182 196 327 182 197 327 minecraft:blue_terracotta
setblock 182 196 336 minecraft:purple_concrete
setblock 182 196 344 minecraft:dark_prismarine
fill 182 196 345 182 196 348 minecraft:blue_terracotta
setblock 182 196 349 minecraft:dark_prismarine
fill 182 196 350 182 199 350 minecraft:blue_terracotta
setblock 182 196 355 minecraft:purple_concrete
setblock 182 196 359 minecraft:dark_prismarine
fill 182 196 360 182 199 360 minecraft:blue_terracotta
setblock 142 197 323 minecraft:dark_prismarine
fill 142 197 324 142 199 325 minecraft:blue_terracotta
setblock 142 197 331 minecraft:purple_concrete
fill 142 197 337 142 198 337 minecraft:purple_concrete
setblock 142 197 343 minecraft:dark_prismarine
fill 142 197 344 142 200 344 minecraft:blue_terracotta
setblock 142 197 347 minecraft:blue_terracotta
setblock 142 197 348 minecraft:dark_prismarine
fill 142 197 349 142 200 349 minecraft:blue_terracotta
setblock 142 197 352 minecraft:blue_terracotta
setblock 142 197 353 minecraft:dark_prismarine
fill 142 197 354 142 199 355 minecraft:blue_terracotta
setblock 142 197 356 minecraft:purple_concrete
setblock 142 197 363 minecraft:dark_prismarine
fill 143 197 323 146 197 323 minecraft:blue_terracotta
fill 143 197 343 143 200 343 minecraft:blue_terracotta
setblock 143 197 347 minecraft:dark_prismarine
fill 143 197 348 144 199 348 minecraft:blue_terracotta
setblock 143 197 351 minecraft:blue_terracotta
setblock 143 197 352 minecraft:dark_prismarine
fill 143 197 363 146 197 363 minecraft:blue_terracotta
setblock 144 197 325 minecraft:light[level=13]
setblock 144 197 332 minecraft:light[level=12]
setblock 144 197 333 minecraft:light[level=13]
setblock 144 197 339 minecraft:light[level=12]
setblock 144 197 341 minecraft:light[level=13]
fill 144 197 344 144 197 345 minecraft:blue_terracotta
setblock 144 197 346 minecraft:dark_prismarine
fill 144 197 347 144 200 347 minecraft:blue_terracotta
fill 144 197 349 144 198 349 minecraft:blue_terracotta
setblock 144 197 353 minecraft:light[level=12]
setblock 144 197 357 minecraft:light[level=13]
setblock 144 197 360 minecraft:light[level=12]
setblock 146 197 324 minecraft:dark_prismarine
fill 146 197 364 146 200 364 minecraft:blue_terracotta
setblock 147 197 323 minecraft:dark_prismarine
fill 147 197 324 150 197 324 minecraft:blue_terracotta
setblock 147 197 363 minecraft:dark_prismarine
fill 148 197 323 151 197 323 minecraft:blue_terracotta
setblock 148 197 362 minecraft:dark_prismarine
fill 148 197 363 151 197 363 minecraft:blue_terracotta
fill 149 197 362 149 198 362 minecraft:blue_terracotta
setblock 150 197 325 minecraft:dark_prismarine
setblock 151 197 324 minecraft:dark_prismarine
fill 151 197 325 151 200 325 minecraft:blue_terracotta
setblock 151 197 332 minecraft:light[level=12]
setblock 151 197 339 minecraft:light[level=12]
setblock 151 197 346 minecraft:light[level=12]
setblock 151 197 353 minecraft:light[level=12]
setblock 151 197 360 minecraft:light[level=12]
setblock 152 197 323 minecraft:dark_prismarine
fill 152 197 324 152 200 324 minecraft:blue_terracotta
setblock 152 197 333 minecraft:light[level=13]
setblock 152 197 341 minecraft:light[level=13]
setblock 152 197 349 minecraft:light[level=13]
setblock 152 197 357 minecraft:light[level=13]
setblock 152 197 363 minecraft:dark_prismarine
fill 153 197 323 153 200 323 minecraft:blue_terracotta
fill 153 197 363 153 200 363 minecraft:blue_terracotta
setblock 155 197 325 minecraft:dark_prismarine
setblock 156 197 324 minecraft:dark_prismarine
setblock 157 197 323 minecraft:dark_prismarine
fill 157 197 324 160 197 324 minecraft:blue_terracotta
fill 158 197 323 161 197 323 minecraft:blue_terracotta
setblock 158 197 325 minecraft:light[level=12]
setblock 158 197 332 minecraft:light[level=12]
setblock 158 197 339 minecraft:light[level=12]
setblock 158 197 346 minecraft:light[level=12]
setblock 158 197 353 minecraft:light[level=12]
setblock 158 197 360 minecraft:light[level=12]
setblock 160 197 325 minecraft:light[level=13]
setblock 160 197 333 minecraft:light[level=13]
setblock 160 197 341 minecraft:light[level=13]
setblock 160 197 349 minecraft:light[level=13]
setblock 160 197 357 minecraft:light[level=13]
setblock 160 197 363 minecraft:purple_concrete
setblock 161 197 324 minecraft:dark_prismarine
setblock 162 197 323 minecraft:dark_prismarine
fill 162 197 324 165 197 324 minecraft:blue_terracotta
fill 163 197 323 166 197 323 minecraft:blue_terracotta
setblock 164 197 325 minecraft:blue_terracotta
fill 164 197 363 166 197 363 minecraft:blue_terracotta
setblock 165 197 325 minecraft:dark_prismarine
setblock 165 197 332 minecraft:light[level=12]
setblock 165 197 339 minecraft:light[level=12]
setblock 165 197 346 minecraft:light[level=12]
setblock 165 197 353 minecraft:light[level=12]
setblock 165 197 360 minecraft:light[level=12]
setblock 166 197 324 minecraft:dark_prismarine
fill 166 197 325 166 200 325 minecraft:blue_terracotta
setblock 167 197 323 minecraft:dark_prismarine
fill 167 197 324 170 197 324 minecraft:blue_terracotta
fill 167 197 326 168 197 326 minecraft:blue_terracotta
setblock 167 197 363 minecraft:dark_prismarine
fill 168 197 323 171 197 323 minecraft:blue_terracotta
setblock 168 197 333 minecraft:light[level=13]
setblock 168 197 341 minecraft:light[level=13]
setblock 168 197 349 minecraft:light[level=13]
setblock 168 197 357 minecraft:light[level=13]
setblock 168 197 362 minecraft:dark_prismarine
fill 168 197 363 171 197 363 minecraft:blue_terracotta
setblock 169 197 326 minecraft:dark_prismarine
fill 169 197 362 172 197 362 minecraft:blue_terracotta
setblock 170 197 325 minecraft:dark_prismarine
fill 170 197 326 170 200 326 minecraft:blue_terracotta
setblock 171 197 324 minecraft:dark_prismarine
fill 171 197 325 171 200 325 minecraft:blue_terracotta
setblock 171 197 364 minecraft:light_blue_wool
setblock 172 197 323 minecraft:dark_prismarine
fill 172 197 324 172 200 324 minecraft:blue_terracotta
fill 172 197 326 173 197 326 minecraft:blue_terracotta
setblock 172 197 332 minecraft:light[level=12]
setblock 172 197 339 minecraft:light[level=12]
setblock 172 197 346 minecraft:light[level=12]
setblock 172 197 353 minecraft:light[level=12]
setblock 172 197 360 minecraft:light[level=12]
setblock 172 197 361 minecraft:blue_terracotta
setblock 172 197 363 minecraft:dark_prismarine
fill 173 197 323 173 200 323 minecraft:blue_terracotta
setblock 173 197 362 minecraft:dark_prismarine
fill 173 197 363 173 200 363 minecraft:blue_terracotta
setblock 174 197 326 minecraft:dark_prismarine
fill 174 197 362 174 200 362 minecraft:blue_terracotta
setblock 175 197 325 minecraft:dark_prismarine
fill 175 197 326 175 198 326 minecraft:blue_terracotta
setblock 176 197 324 minecraft:dark_prismarine
fill 176 197 325 176 200 325 minecraft:blue_terracotta
setblock 176 197 333 minecraft:light[level=13]
setblock 176 197 341 minecraft:light[level=13]
setblock 176 197 349 minecraft:light[level=13]
setblock 176 197 357 minecraft:light[level=13]
setblock 177 197 323 minecraft:dark_prismarine
fill 177 197 324 177 200 324 minecraft:blue_terracotta
setblock 177 197 363 minecraft:dark_prismarine
fill 178 197 323 178 200 323 minecraft:blue_terracotta
setblock 178 197 362 minecraft:dark_prismarine
fill 178 197 363 178 200 363 minecraft:blue_terracotta
setblock 179 197 325 minecraft:light[level=12]
setblock 179 197 332 minecraft:light[level=12]
setblock 179 197 339 minecraft:light[level=12]
setblock 179 197 346 minecraft:light[level=12]
setblock 179 197 353 minecraft:light[level=12]
setblock 179 197 360 minecraft:light[level=12]
setblock 179 197 362 minecraft:blue_terracotta
setblock 181 197 324 minecraft:dark_prismarine
fill 181 197 325 181 199 325 minecraft:blue_terracotta
setblock 182 197 323 minecraft:dark_prismarine
fill 182 197 324 182 200 324 minecraft:blue_terracotta
setblock 182 197 330 minecraft:purple_concrete
fill 182 197 344 182 197 347 minecraft:blue_terracotta
setblock 182 197 348 minecraft:dark_prismarine
fill 182 197 349 182 200 349 minecraft:blue_terracotta
fill 182 197 351 182 197 352 minecraft:blue_terracotta
setblock 182 197 353 minecraft:dark_prismarine
fill 182 197 359 182 200 359 minecraft:blue_terracotta
setblock 182 197 363 minecraft:dark_prismarine
fill 142 198 323 145 198 323 minecraft:blue_terracotta
setblock 142 198 326 minecraft:blue_terracotta
setblock 142 198 342 minecraft:dark_prismarine
fill 142 198 343 142 201 343 minecraft:blue_terracotta
setblock 142 198 346 minecraft:blue_terracotta
setblock 142 198 347 minecraft:dark_prismarine
fill 142 198 348 142 201 348 minecraft:blue_terracotta
setblock 142 198 352 minecraft:dark_prismarine
fill 142 198 353 143 200 353 minecraft:blue_terracotta
setblock 142 198 356 minecraft:blue_terracotta
setblock 142 198 362 minecraft:dark_prismarine
fill 142 198 363 145 198 363 minecraft:blue_terracotta
fill 143 198 342 143 200 342 minecraft:blue_terracotta
setblock 143 198 346 minecraft:dark_prismarine
fill 143 198 347 143 201 347 minecraft:blue_terracotta
setblock 143 198 351 minecraft:dark_prismarine
fill 143 198 352 143 201 352 minecraft:blue_terracotta
setblock 144 198 344 minecraft:blue_terracotta
setblock 144 198 345 minecraft:dark_prismarine
fill 144 198 346 145 200 346 minecraft:blue_terracotta
setblock 144 198 350 minecraft:dark_prismarine
fill 144 198 351 144 201 351 minecraft:blue_terracotta
fill 145 198 347 145 198 348 minecraft:blue_terracotta
setblock 146 198 323 minecraft:dark_prismarine
fill 146 198 324 149 198 324 minecraft:blue_terracotta
setblock 146 198 363 minecraft:dark_prismarine
fill 147 198 323 150 198 323 minecraft:blue_terracotta
fill 147 198 363 150 198 363 minecraft:blue_terracotta
setblock 148 198 325 minecraft:blue_terracotta
setblock 148 198 362 minecraft:blue_terracotta
setblock 149 198 325 minecraft:dark_prismarine
setblock 150 198 324 minecraft:dark_prismarine
fill 150 198 325 150 201 325 minecraft:blue_terracotta
setblock 151 198 323 minecraft:dark_prismarine
fill 151 198 324 151 201 324 minecraft:blue_terracotta
setblock 151 198 363 minecraft:dark_prismarine
fill 152 198 323 152 201 323 minecraft:blue_terracotta
fill 152 198 325 153 198 325 minecraft:blue_terracotta
fill 152 198 363 152 200 363 minecraft:blue_terracotta
setblock 154 198 325 minecraft:dark_prismarine
setblock 155 198 324 minecraft:dark_prismarine
fill 155 198 325 155 199 325 minecraft:blue_terracotta
setblock 156 198 323 minecraft:dark_prismarine
fill 156 198 324 159 198 324 minecraft:blue_terracotta
fill 157 198 323 160 198 323 minecraft:blue_terracotta
setblock 160 198 324 minecraft:dark_prismarine
setblock 161 198 323 minecraft:dark_prismarine
fill 161 198 324 164 198 324 minecraft:blue_terracotta
fill 162 198 323 165 198 323 minecraft:blue_terracotta
setblock 163 198 325 minecraft:blue_terracotta
setblock 164 198 325 minecraft:dark_prismarine
fill 164 198 363 165 198 363 minecraft:blue_terracotta
setblock 165 198 324 minecraft:dark_prismarine
fill 165 198 325 165 201 325 minecraft:blue_terracotta
setblock 166 198 323 minecraft:dark_prismarine
fill 166 198 324 169 198 324 minecraft:blue_terracotta
fill 166 198 326 167 198 326 minecraft:blue_terracotta
setblock 166 198 363 minecraft:dark_prismarine
fill 167 198 323 170 198 323 minecraft:blue_terracotta
setblock 167 198 362 minecraft:dark_prismarine
fill 167 198 363 170 198 363 minecraft:blue_terracotta
setblock 168 198 326 minecraft:dark_prismarine
fill 168 198 362 171 198 362 minecraft:blue_terracotta
setblock 169 198 325 minecraft:dark_prismarine
fill 169 198 326 169 201 326 minecraft:blue_terracotta
setblock 170 198 324 minecraft:dark_prismarine
fill 170 198 325 170 201 325 minecraft:blue_terracotta
fill 170 198 327 171 198 327 minecraft:blue_terracotta
setblock 171 198 323 minecraft:dark_prismarine
fill 171 198 324 171 201 324 minecraft:blue_terracotta
setblock 171 198 363 minecraft:dark_prismarine
fill 171 198 364 171 217 364 minecraft:blue_terracotta
fill 172 198 323 172 201 323 minecraft:blue_terracotta
setblock 172 198 326 minecraft:blue_terracotta
setblock 172 198 362 minecraft:dark_prismarine
fill 172 198 363 172 201 363 minecraft:blue_terracotta
setblock 173 198 326 minecraft:dark_prismarine
fill 173 198 362 173 201 362 minecraft:blue_terracotta
setblock 174 198 325 minecraft:dark_prismarine
fill 174 198 326 174 200 326 minecraft:blue_terracotta
setblock 175 198 324 minecraft:dark_prismarine
fill 175 198 325 175 201 325 minecraft:blue_terracotta
setblock 176 198 323 minecraft:dark_prismarine
fill 176 198 324 176 201 324 minecraft:blue_terracotta
setblock 176 198 363 minecraft:dark_prismarine
fill 177 198 323 177 201 323 minecraft:blue_terracotta
fill 177 198 325 177 199 325 minecraft:blue_terracotta
setblock 177 198 362 minecraft:dark_prismarine
fill 177 198 363 177 201 363 minecraft:blue_terracotta
setblock 178 198 362 minecraft:blue_terracotta
setblock 180 198 324 minecraft:dark_prismarine
setblock 181 198 323 minecraft:dark_prismarine
fill 181 198 324 181 199 324 minecraft:blue_terracotta
setblock 181 198 363 minecraft:dark_prismarine
fill 182 198 323 182 201 323 minecraft:blue_terracotta
setblock 182 198 327 minecraft:dark_prismarine
fill 182 198 328 182 201 328 minecraft:blue_terracotta
setblock 182 198 343 minecraft:purple_concrete
fill 182 198 344 182 198 346 minecraft:blue_terracotta
setblock 182 198 347 minecraft:dark_prismarine
fill 182 198 348 182 201 348 minecraft:blue_terracotta
setblock 182 198 351 minecraft:blue_terracotta
setblock 182 198 352 minecraft:dark_prismarine
fill 182 198 353 182 198 356 minecraft:blue_terracotta
setblock 182 198 357 minecraft:dark_prismarine
fill 182 198 358 182 201 358 minecraft:blue_terracotta
setblock 182 198 362 minecraft:dark_prismarine
fill 182 198 363 182 201 363 minecraft:blue_terracotta
fill 142 199 323 144 199 323 minecraft:blue_terracotta
setblock 142 199 326 minecraft:dark_prismarine
fill 142 199 327 142 201 328 minecraft:blue_terracotta
setblock 142 199 341 minecraft:dark_prismarine
fill 142 199 342 142 202 342 minecraft:blue_terracotta
setblock 142 199 346 minecraft:dark_prismarine
fill 142 199 347 142 202 347 minecraft:blue_terracotta
setblock 142 199 350 minecraft:blue_terracotta
setblock 142 199 351 minecraft:dark_prismarine
fill 142 199 352 142 202 352 minecraft:blue_terracotta
setblock 142 199 356 minecraft:dark_prismarine
fill 142 199 357 142 202 357 minecraft:blue_terracotta
fill 142 199 363 144 199 363 minecraft:blue_terracotta
setblock 143 199 345 minecraft:dark_prismarine
fill 143 199 346 143 202 346 minecraft:blue_terracotta
setblock 143 199 350 minecraft:dark_prismarine
fill 143 199 351 143 202 351 minecraft:blue_terracotta
setblock 143 199 354 minecraft:blue_terracotta
setblock 144 199 344 minecraft:dark_prismarine
fill 144 199 345 145 200 345 minecraft:blue_terracotta
setblock 144 199 349 minecraft:dark_prismarine
fill 144 199 350 145 201 350 minecraft:blue_terracotta
fill 144 199 352 144 200 352 minecraft:blue_terracotta
setblock 145 199 323 minecraft:dark_prismarine
fill 145 199 324 148 199 324 minecraft:blue_terracotta
setblock 145 199 347 minecraft:blue_terracotta
setblock 145 199 348 minecraft:dark_prismarine
fill 145 199 349 145 202 349 minecraft:blue_terracotta
setblock 145 199 363 minecraft:dark_prismarine
fill 146 199 323 149 199 323 minecraft:blue_terracotta
fill 146 199 363 149 199 363 minecraft:blue_terracotta
setblock 148 199 325 minecraft:dark_prismarine
setblock 149 199 324 minecraft:dark_prismarine
fill 149 199 325 149 201 325 minecraft:blue_terracotta
setblock 150 199 323 minecraft:dark_prismarine
fill 150 199 324 150 202 324 minecraft:blue_terracotta
setblock 150 199 363 minecraft:dark_prismarine
fill 151 199 323 151 202 323 minecraft:blue_terracotta
fill 151 199 363 151 201 363 minecraft:blue_terracotta
setblock 152 199 325 minecraft:blue_terracotta
setblock 153 199 325 minecraft:dark_prismarine
setblock 154 199 324 minecraft:dark_prismarine
fill 154 199 325 154 200 325 minecraft:blue_terracotta
setblock 155 199 323 minecraft:dark_prismarine
fill 155 199 324 158 199 324 minecraft:blue_terracotta
fill 156 199 323 159 199 323 minecraft:blue_terracotta
setblock 159 199 324 minecraft:dark_prismarine
setblock 160 199 323 minecraft:dark_prismarine
fill 160 199 324 163 199 324 minecraft:blue_terracotta
fill 161 199 323 164 199 323 minecraft:blue_terracotta
setblock 162 199 325 minecraft:blue_terracotta
setblock 163 199 325 minecraft:dark_prismarine
setblock 164 199 324 minecraft:dark_prismarine
fill 164 199 325 164 202 325 minecraft:blue_terracotta
setblock 164 199 363 minecraft:blue_terracotta
setblock 165 199 323 minecraft:dark_prismarine
fill 165 199 324 168 199 324 minecraft:blue_terracotta
fill 165 199 326 166 199 326 minecraft:blue_terracotta
setblock 165 199 363 minecraft:dark_prismarine
fill 166 199 323 169 199 323 minecraft:blue_terracotta
fill 166 199 363 169 199 363 minecraft:blue_terracotta
setblock 167 199 326 minecraft:dark_prismarine
fill 167 199 362 170 199 362 minecraft:blue_terracotta
setblock 168 199 325 minecraft:dark_prismarine
fill 168 199 326 168 202 326 minecraft:blue_terracotta
setblock 169 199 324 minecraft:dark_prismarine
fill 169 199 325 169 202 325 minecraft:blue_terracotta
setblock 170 199 323 minecraft:dark_prismarine
fill 170 199 324 170 202 324 minecraft:blue_terracotta
setblock 170 199 327 minecraft:blue_terracotta
setblock 170 199 363 minecraft:dark_prismarine
fill 171 199 323 171 202 323 minecraft:blue_terracotta
setblock 171 199 327 minecraft:dark_prismarine
setblock 171 199 362 minecraft:dark_prismarine
fill 171 199 363 171 202 363 minecraft:blue_terracotta
setblock 172 199 326 minecraft:dark_prismarine
fill 172 199 362 172 202 362 minecraft:blue_terracotta
setblock 173 199 325 minecraft:dark_prismarine
fill 173 199 326 173 200 326 minecraft:blue_terracotta
setblock 174 199 324 minecraft:dark_prismarine
fill 174 199 325 174 201 325 minecraft:blue_terracotta
setblock 175 199 323 minecraft:dark_prismarine
fill 175 199 324 175 202 324 minecraft:blue_terracotta
setblock 175 199 363 minecraft:dark_prismarine
fill 176 199 323 176 202 323 minecraft:blue_terracotta
setblock 176 199 362 minecraft:dark_prismarine
fill 176 199 363 176 202 363 minecraft:blue_terracotta
setblock 177 199 362 minecraft:blue_terracotta
setblock 179 199 324 minecraft:dark_prismarine
setblock 180 199 323 minecraft:dark_prismarine
setblock 180 199 324 minecraft:blue_terracotta
setblock 180 199 363 minecraft:dark_prismarine
fill 181 199 323 181 201 323 minecraft:blue_terracotta
fill 181 199 348 181 199 351 minecraft:blue_terracotta
fill 181 199 363 181 201 363 minecraft:blue_terracotta
setblock 182 199 326 minecraft:dark_prismarine
fill 182 199 327 182 202 327 minecraft:blue_terracotta
fill 182 199 329 182 200 329 minecraft:blue_terracotta
setblock 182 199 337 minecraft:purple_concrete
fill 182 199 344 182 199 345 minecraft:blue_terracotta
setblock 182 199 346 minecraft:dark_prismarine
fill 182 199 347 182 202 347 minecraft:blue_terracotta
setblock 182 199 351 minecraft:dark_prismarine
fill 182 199 352 182 199 355 minecraft:blue_terracotta
setblock 182 199 356 minecraft:dark_prismarine
fill 182 199 357 182 202 357 minecraft:blue_terracotta
setblock 182 199 361 minecraft:dark_prismarine
fill 182 199 362 182 202 362 minecraft:blue_terracotta
setblock 183 199 324 minecraft:light_blue_wool
setblock 142 200 324 minecraft:blue_terracotta
setblock 142 200 325 minecraft:dark_prismarine
fill 142 200 326 142 202 326 minecraft:blue_terracotta
setblock 142 200 329 minecraft:blue_terracotta
setblock 142 200 330 minecraft:purple_concrete
fill 142 200 341 142 201 341 minecraft:blue_terracotta
setblock 142 200 345 minecraft:dark_prismarine
fill 142 200 346 142 203 346 minecraft:blue_terracotta
setblock 142 200 350 minecraft:dark_prismarine
fill 142 200 351 142 203 351 minecraft:blue_terracotta
setblock 142 200 354 minecraft:blue_terracotta
setblock 142 200 355 minecraft:dark_prismarine
fill 142 200 356 142 203 356 minecraft:blue_terracotta
setblock 143 200 323 minecraft:blue_terracotta
setblock 143 200 344 minecraft:dark_prismarine
fill 143 200 345 143 203 345 minecraft:blue_terracotta
setblock 143 200 348 minecraft:blue_terracotta
setblock 143 200 349 minecraft:dark_prismarine
fill 143 200 350 143 203 350 minecraft:blue_terracotta
setblock 143 200 354 minecraft:dark_prismarine
fill 143 200 355 143 203 355 minecraft:blue_terracotta
setblock 144 200 323 minecraft:dark_prismarine
fill 144 200 344 144 201 344 minecraft:blue_terracotta
setblock 144 200 348 minecraft:dark_prismarine
fill 144 200 349 144 203 349 minecraft:blue_terracotta
setblock 144 200 353 minecraft:dark_prismarine
setblock 144 200 363 minecraft:dark_prismarine
fill 145 200 323 147 200 324 minecraft:blue_terracotta
setblock 145 200 347 minecraft:dark_prismarine
fill 145 200 348 145 203 348 minecraft:blue_terracotta
setblock 145 200 351 minecraft:blue_terracotta
fill 145 200 363 148 200 363 minecraft:blue_terracotta
setblock 148 200 323 minecraft:blue_terracotta
setblock 148 200 324 minecraft:dark_prismarine
fill 148 200 325 148 201 325 minecraft:blue_terracotta
setblock 149 200 323 minecraft:dark_prismarine
fill 149 200 324 149 203 324 minecraft:blue_terracotta
setblock 149 200 363 minecraft:dark_prismarine
fill 150 200 323 150 203 323 minecraft:blue_terracotta
fill 150 200 363 150 201 363 minecraft:blue_terracotta
setblock 152 200 325 minecraft:dark_prismarine
setblock 153 200 324 minecraft:dark_prismarine
setblock 153 200 325 minecraft:blue_terracotta
setblock 154 200 323 minecraft:dark_prismarine
fill 154 200 324 157 200 324 minecraft:blue_terracotta
fill 155 200 323 158 200 323 minecraft:blue_terracotta
setblock 158 200 324 minecraft:dark_prismarine
setblock 159 200 323 minecraft:dark_prismarine
fill 159 200 324 162 200 324 minecraft:blue_terracotta
fill 160 200 323 163 200 323 minecraft:blue_terracotta
setblock 162 200 325 minecraft:dark_prismarine
setblock 163 200 324 minecraft:dark_prismarine
fill 163 200 325 163 203 325 minecraft:blue_terracotta
setblock 164 200 323 minecraft:dark_prismarine
fill 164 200 324 167 200 324 minecraft:blue_terracotta
fill 164 200 326 165 200 326 minecraft:blue_terracotta
setblock 164 200 363 minecraft:dark_prismarine
fill 165 200 323 168 200 323 minecraft:blue_terracotta
fill 165 200 363 168 200 363 minecraft:blue_terracotta
setblock 166 200 326 minecraft:dark_prismarine
setblock 167 200 325 minecraft:dark_prismarine
fill 167 200 326 167 203 326 minecraft:blue_terracotta
fill 167 200 362 169 200 362 minecraft:blue_terracotta
setblock 168 200 324 minecraft:dark_prismarine
fill 168 200 325 168 203 325 minecraft:blue_terracotta
setblock 169 200 323 minecraft:dark_prismarine
fill 169 200 324 169 203 324 minecraft:blue_terracotta
fill 169 200 355 169 233 355 minecraft:magenta_terracotta
setblock 169 200 363 minecraft:dark_prismarine
fill 170 200 323 170 203 323 minecraft:blue_terracotta
setblock 170 200 327 minecraft:dark_prismarine
setblock 170 200 362 minecraft:dark_prismarine
fill 170 200 363 170 203 363 minecraft:blue_terracotta
setblock 171 200 326 minecraft:dark_prismarine
fill 171 200 362 171 202 362 minecraft:blue_terracotta
setblock 172 200 325 minecraft:dark_prismarine
fill 172 200 326 172 201 326 minecraft:blue_terracotta
setblock 173 200 324 minecraft:dark_prismarine
fill 173 200 325 173 202 325 minecraft:blue_terracotta
setblock 174 200 323 minecraft:dark_prismarine
fill 174 200 324 174 202 324 minecraft:blue_terracotta
setblock 174 200 363 minecraft:dark_prismarine
fill 175 200 323 175 203 323 minecraft:blue_terracotta
setblock 175 200 362 minecraft:dark_prismarine
fill 175 200 363 175 202 363 minecraft:blue_terracotta
setblock 178 200 324 minecraft:dark_prismarine
setblock 179 200 323 minecraft:dark_prismarine
setblock 179 200 324 minecraft:blue_terracotta
setblock 179 200 363 minecraft:dark_prismarine
fill 180 200 323 180 201 323 minecraft:blue_terracotta
fill 180 200 363 180 201 363 minecraft:blue_terracotta
fill 181 200 347 181 200 350 minecraft:blue_terracotta
setblock 181 200 351 minecraft:dark_prismarine
fill 181 200 352 182 202 352 minecraft:blue_terracotta
setblock 182 200 325 minecraft:dark_prismarine
fill 182 200 326 182 203 326 minecraft:blue_terracotta
setblock 182 200 331 minecraft:purple_concrete
setblock 182 200 344 minecraft:blue_terracotta
setblock 182 200 345 minecraft:dark_prismarine
fill 182 200 346 182 203 346 minecraft:blue_terracotta
setblock 182 200 350 minecraft:dark_prismarine
fill 182 200 351 182 203 351 minecraft:blue_terracotta
fill 182 200 353 182 200 354 minecraft:blue_terracotta
setblock 182 200 355 minecraft:dark_prismarine
fill 182 200 356 182 203 356 minecraft:blue_terracotta
setblock 182 200 360 minecraft:dark_prismarine
fill 182 200 361 182 202 361 minecraft:blue_terracotta
fill 183 200 324 183 220 324 minecraft:blue_terracotta
setblock 142 201 325 minecraft:blue_terracotta
setblock 142 201 329 minecraft:dark_prismarine
fill 142 201 330 142 203 331 minecraft:blue_terracotta
setblock 142 201 336 minecraft:purple_concrete
setblock 142 201 344 minecraft:dark_prismarine
fill 142 201 345 142 204 345 minecraft:blue_terracotta
setblock 142 201 349 minecraft:dark_prismarine
fill 142 201 350 142 204 350 minecraft:blue_terracotta
setblock 142 201 353 minecraft:blue_terracotta
setblock 142 201 354 minecraft:dark_prismarine
fill 142 201 355 142 204 355 minecraft:blue_terracotta
setblock 142 201 361 minecraft:purple_concrete
setblock 143 201 343 minecraft:dark_prismarine
fill 143 201 344 143 204 344 minecraft:blue_terracotta
setblock 143 201 348 minecraft:dark_prismarine
fill 143 201 349 143 204 349 minecraft:blue_terracotta
setblock 143 201 353 minecraft:dark_prismarine
fill 143 201 354 143 204 354 minecraft:blue_terracotta
fill 144 201 323 147 201 323 minecraft:blue_terracotta
fill 144 201 345 144 201 346 minecraft:blue_terracotta
setblock 144 201 347 minecraft:dark_prismarine
fill 144 201 348 144 204 348 minecraft:blue_terracotta
setblock 144 201 352 minecraft:dark_prismarine
fill 144 201 353 144 204 353 minecraft:blue_terracotta
setblock 145 201 346 minecraft:dark_prismarine
fill 145 201 347 145 202 347 minecraft:blue_terracotta
setblock 145 201 351 minecraft:dark_prismarine
fill 145 201 363 147 201 363 minecraft:blue_terracotta
setblock 146 201 324 minecraft:blue_terracotta
setblock 146 201 364 minecraft:cyan_concrete
setblock 147 201 324 minecraft:dark_prismarine
setblock 148 201 323 minecraft:dark_prismarine
fill 148 201 324 148 202 324 minecraft:blue_terracotta
setblock 148 201 363 minecraft:dark_prismarine
fill 149 201 323 149 204 323 minecraft:blue_terracotta
setblock 149 201 363 minecraft:blue_terracotta
setblock 151 201 325 minecraft:dark_prismarine
setblock 152 201 324 minecraft:dark_prismarine
setblock 152 201 325 minecraft:blue_terracotta
schedule function dropper:buildpart/75_10 1t
