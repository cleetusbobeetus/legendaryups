fill 406 174 222 406 177 222 minecraft:mossy_cobblestone
setblock 407 174 221 minecraft:mossy_cobblestone
setblock 409 174 183 minecraft:stone_bricks
setblock 410 174 182 minecraft:stone_bricks
setblock 410 174 183 minecraft:mossy_cobblestone
setblock 410 174 222 minecraft:stone_bricks
fill 411 174 182 411 176 182 minecraft:mossy_cobblestone
setblock 411 174 222 minecraft:mossy_cobblestone
setblock 415 174 182 minecraft:stone_bricks
fill 416 174 182 416 175 182 minecraft:mossy_cobblestone
setblock 416 174 202 minecraft:mossy_cobblestone
setblock 417 174 185 minecraft:stone_bricks
fill 417 174 186 417 177 186 minecraft:mossy_cobblestone
setblock 417 174 200 minecraft:stone_bricks
fill 417 174 201 417 175 201 minecraft:mossy_cobblestone
setblock 417 174 205 minecraft:stone_bricks
fill 417 174 206 417 176 206 minecraft:mossy_cobblestone
fill 377 175 182 377 175 183 minecraft:mossy_cobblestone
setblock 377 175 184 minecraft:stone_bricks
fill 377 175 185 377 178 185 minecraft:mossy_cobblestone
setblock 377 175 189 minecraft:stone_bricks
setblock 378 175 182 minecraft:mossy_cobblestone
setblock 378 175 183 minecraft:stone_bricks
fill 378 175 184 378 178 184 minecraft:mossy_cobblestone
setblock 379 175 182 minecraft:stone_bricks
fill 379 175 183 379 178 183 minecraft:mossy_cobblestone
setblock 379 175 222 minecraft:stone_bricks
fill 380 175 182 380 178 182 minecraft:mossy_cobblestone
fill 380 175 222 380 178 222 minecraft:mossy_cobblestone
setblock 382 175 184 minecraft:stone_bricks
setblock 383 175 183 minecraft:stone_bricks
fill 383 175 184 383 178 184 minecraft:mossy_cobblestone
setblock 384 175 182 minecraft:stone_bricks
fill 384 175 183 384 178 183 minecraft:mossy_cobblestone
setblock 384 175 222 minecraft:stone_bricks
fill 385 175 182 385 178 182 minecraft:mossy_cobblestone
setblock 385 175 221 minecraft:stone_bricks
fill 385 175 222 385 178 222 minecraft:mossy_cobblestone
fill 386 175 221 386 178 221 minecraft:mossy_cobblestone
setblock 387 175 184 minecraft:stone_bricks
setblock 388 175 183 minecraft:stone_bricks
fill 388 175 184 388 176 184 minecraft:mossy_cobblestone
setblock 389 175 182 minecraft:stone_bricks
fill 389 175 183 389 178 183 minecraft:mossy_cobblestone
setblock 389 175 222 minecraft:stone_bricks
fill 390 175 182 390 178 182 minecraft:mossy_cobblestone
setblock 390 175 221 minecraft:stone_bricks
fill 390 175 222 393 175 222 minecraft:mossy_cobblestone
setblock 391 175 221 minecraft:mossy_cobblestone
setblock 394 175 182 minecraft:stone_bricks
setblock 394 175 222 minecraft:stone_bricks
setblock 395 175 222 minecraft:mossy_cobblestone
setblock 399 175 222 minecraft:stone_bricks
fill 400 175 182 403 175 182 minecraft:mossy_cobblestone
fill 400 175 222 400 176 222 minecraft:mossy_cobblestone
setblock 404 175 182 minecraft:stone_bricks
fill 404 175 183 404 178 183 minecraft:mossy_cobblestone
setblock 404 175 222 minecraft:stone_bricks
fill 405 175 182 405 178 182 minecraft:mossy_cobblestone
fill 405 175 222 405 178 222 minecraft:mossy_cobblestone
setblock 408 175 183 minecraft:stone_bricks
setblock 409 175 182 minecraft:stone_bricks
setblock 409 175 183 minecraft:mossy_cobblestone
setblock 409 175 222 minecraft:stone_bricks
fill 410 175 182 410 177 182 minecraft:mossy_cobblestone
setblock 414 175 182 minecraft:stone_bricks
setblock 415 175 182 minecraft:mossy_cobblestone
setblock 417 175 184 minecraft:stone_bricks
fill 417 175 185 417 178 185 minecraft:mossy_cobblestone
setblock 417 175 188 minecraft:mossy_cobblestone
setblock 417 175 200 minecraft:mossy_cobblestone
setblock 417 175 204 minecraft:stone_bricks
fill 417 175 205 417 178 205 minecraft:mossy_cobblestone
setblock 377 176 182 minecraft:mossy_cobblestone
setblock 377 176 183 minecraft:stone_bricks
fill 377 176 184 377 179 184 minecraft:mossy_cobblestone
setblock 377 176 188 minecraft:stone_bricks
fill 377 176 189 377 179 189 minecraft:mossy_cobblestone
setblock 378 176 182 minecraft:stone_bricks
fill 378 176 183 378 179 183 minecraft:mossy_cobblestone
setblock 378 176 187 minecraft:stone_bricks
fill 379 176 182 379 179 182 minecraft:mossy_cobblestone
fill 379 176 222 379 179 222 minecraft:mossy_cobblestone
setblock 381 176 184 minecraft:stone_bricks
setblock 382 176 183 minecraft:stone_bricks
fill 382 176 184 382 179 184 minecraft:mossy_cobblestone
setblock 383 176 182 minecraft:stone_bricks
fill 383 176 183 383 179 183 minecraft:mossy_cobblestone
setblock 383 176 222 minecraft:stone_bricks
fill 384 176 182 384 179 182 minecraft:mossy_cobblestone
setblock 384 176 221 minecraft:stone_bricks
fill 384 176 222 384 179 222 minecraft:mossy_cobblestone
setblock 385 176 184 minecraft:mossy_cobblestone
fill 385 176 221 385 179 221 minecraft:mossy_cobblestone
setblock 386 176 184 minecraft:stone_bricks
setblock 387 176 183 minecraft:stone_bricks
fill 387 176 184 387 178 184 minecraft:mossy_cobblestone
setblock 388 176 182 minecraft:stone_bricks
fill 388 176 183 388 179 183 minecraft:mossy_cobblestone
setblock 388 176 222 minecraft:stone_bricks
fill 389 176 182 389 179 182 minecraft:mossy_cobblestone
setblock 389 176 221 minecraft:stone_bricks
fill 389 176 222 392 176 222 minecraft:mossy_cobblestone
setblock 390 176 221 minecraft:mossy_cobblestone
setblock 393 176 182 minecraft:stone_bricks
setblock 393 176 222 minecraft:stone_bricks
fill 401 176 182 402 176 182 minecraft:mossy_cobblestone
setblock 403 176 182 minecraft:stone_bricks
setblock 403 176 222 minecraft:stone_bricks
fill 404 176 182 404 179 182 minecraft:mossy_cobblestone
fill 404 176 222 404 179 222 minecraft:mossy_cobblestone
setblock 407 176 183 minecraft:stone_bricks
setblock 408 176 182 minecraft:stone_bricks
setblock 408 176 183 minecraft:mossy_cobblestone
setblock 408 176 222 minecraft:stone_bricks
fill 409 176 182 409 179 182 minecraft:mossy_cobblestone
setblock 417 176 183 minecraft:stone_bricks
fill 417 176 184 417 179 184 minecraft:mossy_cobblestone
setblock 417 176 188 minecraft:stone_bricks
fill 417 176 189 417 179 189 minecraft:mossy_cobblestone
setblock 417 176 203 minecraft:stone_bricks
fill 417 176 204 417 177 204 minecraft:mossy_cobblestone
setblock 377 177 182 minecraft:stone_bricks
fill 377 177 183 377 180 183 minecraft:mossy_cobblestone
setblock 377 177 187 minecraft:stone_bricks
fill 377 177 188 377 180 188 minecraft:mossy_cobblestone
fill 378 177 182 378 180 182 minecraft:mossy_cobblestone
setblock 378 177 186 minecraft:stone_bricks
fill 378 177 187 378 180 187 minecraft:mossy_cobblestone
setblock 379 177 184 minecraft:light[level=12]
setblock 379 177 192 minecraft:light[level=12]
setblock 379 177 200 minecraft:light[level=12]
setblock 379 177 208 minecraft:light[level=12]
setblock 379 177 216 minecraft:light[level=12]
setblock 380 177 183 minecraft:mossy_cobblestone
setblock 380 177 184 minecraft:stone_bricks
setblock 381 177 183 minecraft:stone_bricks
fill 381 177 184 381 180 184 minecraft:mossy_cobblestone
setblock 382 177 182 minecraft:stone_bricks
fill 382 177 183 382 180 183 minecraft:mossy_cobblestone
setblock 382 177 222 minecraft:stone_bricks
fill 383 177 182 383 180 182 minecraft:mossy_cobblestone
setblock 383 177 221 minecraft:stone_bricks
fill 383 177 222 383 180 222 minecraft:mossy_cobblestone
fill 384 177 221 384 180 221 minecraft:mossy_cobblestone
setblock 385 177 184 minecraft:stone_bricks
setblock 386 177 183 minecraft:stone_bricks
fill 386 177 184 386 180 184 minecraft:mossy_cobblestone
setblock 387 177 182 minecraft:stone_bricks
fill 387 177 183 387 180 183 minecraft:mossy_cobblestone
setblock 387 177 192 minecraft:light[level=12]
setblock 387 177 200 minecraft:light[level=12]
setblock 387 177 208 minecraft:light[level=12]
setblock 387 177 216 minecraft:light[level=12]
setblock 387 177 222 minecraft:stone_bricks
fill 388 177 182 388 180 182 minecraft:mossy_cobblestone
setblock 388 177 221 minecraft:stone_bricks
fill 388 177 222 391 177 222 minecraft:mossy_cobblestone
setblock 392 177 182 minecraft:stone_bricks
setblock 392 177 222 minecraft:stone_bricks
setblock 395 177 184 minecraft:light[level=12]
setblock 395 177 192 minecraft:light[level=12]
setblock 395 177 200 minecraft:light[level=12]
setblock 395 177 208 minecraft:light[level=12]
setblock 395 177 216 minecraft:light[level=12]
setblock 401 177 182 minecraft:mossy_cobblestone
setblock 402 177 182 minecraft:stone_bricks
setblock 402 177 222 minecraft:stone_bricks
fill 403 177 182 403 180 182 minecraft:mossy_cobblestone
setblock 403 177 184 minecraft:light[level=12]
setblock 403 177 192 minecraft:light[level=12]
setblock 403 177 200 minecraft:light[level=12]
setblock 403 177 208 minecraft:light[level=12]
setblock 403 177 216 minecraft:light[level=12]
fill 403 177 222 403 180 222 minecraft:mossy_cobblestone
setblock 406 177 183 minecraft:stone_bricks
setblock 407 177 182 minecraft:stone_bricks
setblock 407 177 183 minecraft:mossy_cobblestone
fill 408 177 182 408 180 182 minecraft:mossy_cobblestone
setblock 411 177 184 minecraft:light[level=12]
setblock 411 177 192 minecraft:light[level=12]
setblock 411 177 200 minecraft:light[level=12]
setblock 411 177 208 minecraft:light[level=12]
setblock 411 177 216 minecraft:light[level=12]
setblock 417 177 182 minecraft:stone_bricks
fill 417 177 183 417 180 183 minecraft:mossy_cobblestone
setblock 417 177 187 minecraft:stone_bricks
fill 417 177 188 417 180 188 minecraft:mossy_cobblestone
fill 417 177 190 417 178 190 minecraft:mossy_cobblestone
fill 377 178 182 377 181 182 minecraft:mossy_cobblestone
setblock 377 178 186 minecraft:stone_bricks
fill 377 178 187 377 181 187 minecraft:mossy_cobblestone
setblock 377 178 190 minecraft:mossy_cobblestone
setblock 378 178 185 minecraft:stone_bricks
fill 378 178 186 379 180 186 minecraft:mossy_cobblestone
fill 378 178 188 378 179 188 minecraft:mossy_cobblestone
setblock 379 178 184 minecraft:stone_bricks
fill 379 178 185 379 181 185 minecraft:mossy_cobblestone
setblock 380 178 183 minecraft:stone_bricks
fill 380 178 184 380 181 184 minecraft:mossy_cobblestone
setblock 381 178 182 minecraft:stone_bricks
fill 381 178 183 381 181 183 minecraft:mossy_cobblestone
setblock 381 178 222 minecraft:stone_bricks
fill 382 178 182 382 181 182 minecraft:mossy_cobblestone
setblock 382 178 221 minecraft:stone_bricks
fill 382 178 222 382 181 222 minecraft:mossy_cobblestone
fill 383 178 221 383 181 221 minecraft:mossy_cobblestone
setblock 384 178 184 minecraft:stone_bricks
setblock 385 178 183 minecraft:stone_bricks
fill 385 178 184 385 181 184 minecraft:mossy_cobblestone
setblock 386 178 182 minecraft:stone_bricks
fill 386 178 183 386 181 183 minecraft:mossy_cobblestone
setblock 386 178 222 minecraft:stone_bricks
fill 387 178 182 387 181 182 minecraft:mossy_cobblestone
setblock 387 178 221 minecraft:stone_bricks
fill 387 178 222 390 178 222 minecraft:mossy_cobblestone
setblock 391 178 182 minecraft:stone_bricks
setblock 391 178 222 minecraft:stone_bricks
setblock 401 178 182 minecraft:stone_bricks
fill 402 178 182 402 181 182 minecraft:mossy_cobblestone
fill 402 178 222 402 181 222 minecraft:mossy_cobblestone
setblock 405 178 183 minecraft:stone_bricks
setblock 406 178 182 minecraft:stone_bricks
setblock 406 178 183 minecraft:mossy_cobblestone
fill 407 178 182 407 181 182 minecraft:mossy_cobblestone
fill 417 178 182 417 181 182 minecraft:mossy_cobblestone
setblock 417 178 186 minecraft:stone_bricks
fill 417 178 187 417 181 187 minecraft:mossy_cobblestone
setblock 417 178 191 minecraft:stone_bricks
setblock 417 178 206 minecraft:stone_bricks
setblock 377 179 185 minecraft:stone_bricks
fill 377 179 186 377 182 186 minecraft:mossy_cobblestone
setblock 377 179 190 minecraft:stone_bricks
fill 377 179 191 377 182 191 minecraft:mossy_cobblestone
setblock 378 179 184 minecraft:stone_bricks
fill 378 179 185 378 182 185 minecraft:mossy_cobblestone
setblock 378 179 189 minecraft:stone_bricks
fill 378 179 222 378 180 222 minecraft:mossy_cobblestone
setblock 379 179 183 minecraft:stone_bricks
fill 379 179 184 379 182 184 minecraft:mossy_cobblestone
setblock 379 179 187 minecraft:mossy_cobblestone
setblock 380 179 182 minecraft:stone_bricks
fill 380 179 183 380 182 183 minecraft:mossy_cobblestone
setblock 380 179 222 minecraft:stone_bricks
fill 381 179 182 381 182 182 minecraft:mossy_cobblestone
fill 381 179 222 381 182 222 minecraft:mossy_cobblestone
fill 382 179 221 382 182 221 minecraft:mossy_cobblestone
setblock 383 179 184 minecraft:stone_bricks
setblock 384 179 183 minecraft:stone_bricks
fill 384 179 184 384 182 184 minecraft:mossy_cobblestone
setblock 385 179 182 minecraft:stone_bricks
fill 385 179 183 385 182 183 minecraft:mossy_cobblestone
setblock 385 179 222 minecraft:stone_bricks
fill 386 179 182 386 182 182 minecraft:mossy_cobblestone
setblock 386 179 221 minecraft:stone_bricks
fill 386 179 222 389 179 222 minecraft:mossy_cobblestone
fill 387 179 221 387 180 221 minecraft:mossy_cobblestone
setblock 390 179 182 minecraft:stone_bricks
setblock 390 179 222 minecraft:stone_bricks
setblock 400 179 182 minecraft:stone_bricks
fill 401 179 182 401 182 182 minecraft:mossy_cobblestone
setblock 404 179 183 minecraft:stone_bricks
setblock 405 179 182 minecraft:stone_bricks
fill 405 179 183 405 181 183 minecraft:mossy_cobblestone
fill 406 179 182 406 182 182 minecraft:mossy_cobblestone
fill 416 179 182 416 182 182 minecraft:mossy_cobblestone
setblock 416 179 185 minecraft:mossy_cobblestone
setblock 416 179 186 minecraft:stone_bricks
fill 416 179 187 416 180 189 minecraft:mossy_cobblestone
setblock 417 179 185 minecraft:stone_bricks
fill 417 179 186 417 182 186 minecraft:mossy_cobblestone
setblock 417 179 190 minecraft:stone_bricks
fill 417 179 191 417 180 193 minecraft:mossy_cobblestone
setblock 417 179 205 minecraft:stone_bricks
fill 417 179 206 417 180 208 minecraft:mossy_cobblestone
setblock 377 180 184 minecraft:stone_bricks
fill 377 180 185 377 183 185 minecraft:mossy_cobblestone
setblock 377 180 189 minecraft:stone_bricks
fill 377 180 190 378 182 190 minecraft:mossy_cobblestone
fill 377 180 192 377 181 192 minecraft:mossy_cobblestone
fill 377 180 207 377 180 208 minecraft:mossy_cobblestone
setblock 377 180 209 minecraft:stone_bricks
fill 377 180 210 377 182 211 minecraft:mossy_cobblestone
setblock 378 180 183 minecraft:stone_bricks
fill 378 180 184 378 183 184 minecraft:mossy_cobblestone
setblock 378 180 188 minecraft:stone_bricks
fill 378 180 189 379 182 189 minecraft:mossy_cobblestone
fill 378 180 191 378 181 191 minecraft:mossy_cobblestone
setblock 379 180 182 minecraft:stone_bricks
fill 379 180 183 379 183 183 minecraft:mossy_cobblestone
setblock 379 180 187 minecraft:stone_bricks
fill 379 180 188 379 183 188 minecraft:mossy_cobblestone
setblock 379 180 222 minecraft:stone_bricks
fill 380 180 182 380 183 182 minecraft:mossy_cobblestone
fill 380 180 222 380 183 222 minecraft:mossy_cobblestone
fill 381 180 221 381 183 221 minecraft:mossy_cobblestone
setblock 382 180 184 minecraft:stone_bricks
fill 382 180 185 382 182 185 minecraft:mossy_cobblestone
setblock 383 180 183 minecraft:stone_bricks
fill 383 180 184 383 183 184 minecraft:mossy_cobblestone
setblock 384 180 182 minecraft:stone_bricks
fill 384 180 183 384 183 183 minecraft:mossy_cobblestone
setblock 384 180 222 minecraft:stone_bricks
fill 385 180 182 385 183 182 minecraft:mossy_cobblestone
setblock 385 180 221 minecraft:stone_bricks
fill 385 180 222 388 180 222 minecraft:mossy_cobblestone
fill 386 180 221 386 183 221 minecraft:mossy_cobblestone
setblock 388 180 183 minecraft:stone_bricks
setblock 389 180 182 minecraft:stone_bricks
setblock 389 180 222 minecraft:stone_bricks
setblock 390 180 222 minecraft:mossy_cobblestone
fill 400 180 182 400 183 182 minecraft:mossy_cobblestone
fill 401 180 222 401 182 222 minecraft:mossy_cobblestone
setblock 403 180 183 minecraft:stone_bricks
setblock 404 180 182 minecraft:stone_bricks
fill 404 180 183 404 182 183 minecraft:mossy_cobblestone
fill 405 180 182 405 183 182 minecraft:mossy_cobblestone
setblock 416 180 184 minecraft:mossy_cobblestone
setblock 416 180 185 minecraft:stone_bricks
fill 416 180 186 416 183 186 minecraft:mossy_cobblestone
setblock 416 180 190 minecraft:stone_bricks
fill 416 180 191 416 183 191 minecraft:mossy_cobblestone
setblock 417 180 184 minecraft:stone_bricks
fill 417 180 185 417 183 185 minecraft:mossy_cobblestone
setblock 417 180 189 minecraft:stone_bricks
fill 417 180 190 417 183 190 minecraft:mossy_cobblestone
setblock 417 180 194 minecraft:stone_bricks
fill 417 180 195 417 183 195 minecraft:mossy_cobblestone
setblock 417 180 204 minecraft:stone_bricks
fill 417 180 205 417 183 205 minecraft:mossy_cobblestone
setblock 417 180 209 minecraft:stone_bricks
setblock 377 181 183 minecraft:stone_bricks
fill 377 181 184 377 184 184 minecraft:mossy_cobblestone
setblock 377 181 188 minecraft:stone_bricks
fill 377 181 189 377 184 189 minecraft:mossy_cobblestone
setblock 377 181 193 minecraft:stone_bricks
fill 377 181 194 377 184 194 minecraft:mossy_cobblestone
fill 377 181 206 377 181 207 minecraft:mossy_cobblestone
setblock 377 181 208 minecraft:stone_bricks
fill 377 181 209 378 183 209 minecraft:mossy_cobblestone
setblock 377 181 212 minecraft:mossy_cobblestone
setblock 377 181 213 minecraft:stone_bricks
fill 377 181 214 377 183 215 minecraft:mossy_cobblestone
setblock 377 181 222 minecraft:mossy_cobblestone
setblock 378 181 182 minecraft:stone_bricks
fill 378 181 183 378 184 183 minecraft:mossy_cobblestone
setblock 378 181 186 minecraft:mossy_cobblestone
setblock 378 181 187 minecraft:stone_bricks
fill 378 181 188 378 184 188 minecraft:mossy_cobblestone
setblock 378 181 192 minecraft:stone_bricks
fill 378 181 210 378 181 211 minecraft:mossy_cobblestone
setblock 378 181 222 minecraft:stone_bricks
fill 379 181 182 379 184 182 minecraft:mossy_cobblestone
setblock 379 181 186 minecraft:stone_bricks
fill 379 181 187 380 183 187 minecraft:mossy_cobblestone
setblock 379 181 190 minecraft:mossy_cobblestone
fill 379 181 222 379 184 222 minecraft:mossy_cobblestone
setblock 380 181 185 minecraft:stone_bricks
fill 380 181 186 380 184 186 minecraft:mossy_cobblestone
fill 380 181 221 380 184 221 minecraft:mossy_cobblestone
setblock 381 181 184 minecraft:stone_bricks
fill 381 181 185 381 183 185 minecraft:mossy_cobblestone
setblock 382 181 183 minecraft:stone_bricks
fill 382 181 184 382 184 184 minecraft:mossy_cobblestone
setblock 383 181 182 minecraft:stone_bricks
fill 383 181 183 383 184 183 minecraft:mossy_cobblestone
setblock 383 181 222 minecraft:stone_bricks
fill 384 181 182 384 184 182 minecraft:mossy_cobblestone
setblock 384 181 221 minecraft:stone_bricks
fill 384 181 222 387 181 222 minecraft:mossy_cobblestone
fill 385 181 221 385 184 221 minecraft:mossy_cobblestone
setblock 387 181 183 minecraft:stone_bricks
setblock 388 181 182 minecraft:stone_bricks
setblock 388 181 222 minecraft:stone_bricks
setblock 389 181 182 minecraft:mossy_cobblestone
fill 389 181 222 389 183 222 minecraft:mossy_cobblestone
fill 399 181 182 399 184 182 minecraft:mossy_cobblestone
fill 400 181 222 400 183 222 minecraft:mossy_cobblestone
setblock 402 181 183 minecraft:stone_bricks
setblock 403 181 182 minecraft:stone_bricks
fill 403 181 183 403 183 183 minecraft:mossy_cobblestone
setblock 403 181 222 minecraft:stone_bricks
fill 404 181 182 404 184 182 minecraft:mossy_cobblestone
setblock 408 181 182 minecraft:stone_bricks
fill 415 181 182 415 183 182 minecraft:mossy_cobblestone
setblock 416 181 184 minecraft:stone_bricks
fill 416 181 185 416 184 185 minecraft:mossy_cobblestone
fill 416 181 187 416 181 188 minecraft:mossy_cobblestone
setblock 416 181 189 minecraft:stone_bricks
fill 416 181 190 416 184 190 minecraft:mossy_cobblestone
fill 416 181 192 416 181 193 minecraft:mossy_cobblestone
setblock 417 181 183 minecraft:stone_bricks
fill 417 181 184 417 184 184 minecraft:mossy_cobblestone
setblock 417 181 188 minecraft:stone_bricks
fill 417 181 189 417 184 189 minecraft:mossy_cobblestone
fill 417 181 191 417 181 192 minecraft:mossy_cobblestone
setblock 417 181 193 minecraft:stone_bricks
fill 417 181 194 417 184 194 minecraft:mossy_cobblestone
fill 417 181 196 417 182 196 minecraft:mossy_cobblestone
fill 417 181 204 417 184 204 minecraft:mossy_cobblestone
fill 417 181 206 417 181 207 minecraft:mossy_cobblestone
setblock 417 181 208 minecraft:stone_bricks
fill 417 181 209 417 181 212 minecraft:mossy_cobblestone
setblock 377 182 182 minecraft:stone_bricks
fill 377 182 183 377 185 183 minecraft:mossy_cobblestone
setblock 377 182 187 minecraft:stone_bricks
fill 377 182 188 377 185 188 minecraft:mossy_cobblestone
setblock 377 182 192 minecraft:stone_bricks
fill 377 182 193 378 184 193 minecraft:mossy_cobblestone
fill 377 182 195 377 183 195 minecraft:mossy_cobblestone
fill 377 182 205 377 182 206 minecraft:mossy_cobblestone
setblock 377 182 207 minecraft:stone_bricks
fill 377 182 208 378 184 208 minecraft:mossy_cobblestone
setblock 377 182 212 minecraft:stone_bricks
fill 377 182 213 378 184 213 minecraft:mossy_cobblestone
setblock 377 182 216 minecraft:mossy_cobblestone
setblock 377 182 217 minecraft:stone_bricks
fill 377 182 218 377 182 221 minecraft:mossy_cobblestone
setblock 377 182 222 minecraft:stone_bricks
fill 378 182 182 378 185 182 minecraft:mossy_cobblestone
setblock 378 182 186 minecraft:stone_bricks
fill 378 182 187 378 185 187 minecraft:mossy_cobblestone
setblock 378 182 191 minecraft:stone_bricks
fill 378 182 192 378 185 192 minecraft:mossy_cobblestone
fill 378 182 207 378 185 207 minecraft:mossy_cobblestone
setblock 378 182 210 minecraft:mossy_cobblestone
setblock 378 182 211 minecraft:stone_bricks
fill 378 182 212 379 184 212 minecraft:mossy_cobblestone
fill 378 182 214 378 182 215 minecraft:mossy_cobblestone
setblock 378 182 216 minecraft:stone_bricks
fill 378 182 222 378 185 222 minecraft:mossy_cobblestone
setblock 379 182 185 minecraft:stone_bricks
fill 379 182 186 379 185 186 minecraft:mossy_cobblestone
setblock 379 182 190 minecraft:stone_bricks
fill 379 182 191 379 185 191 minecraft:mossy_cobblestone
setblock 379 182 210 minecraft:stone_bricks
fill 379 182 211 379 185 211 minecraft:mossy_cobblestone
fill 379 182 221 379 185 221 minecraft:mossy_cobblestone
setblock 380 182 184 minecraft:stone_bricks
fill 380 182 185 380 183 185 minecraft:mossy_cobblestone
setblock 380 182 188 minecraft:mossy_cobblestone
setblock 381 182 183 minecraft:stone_bricks
fill 381 182 184 381 185 184 minecraft:mossy_cobblestone
setblock 382 182 182 minecraft:stone_bricks
fill 382 182 183 382 185 183 minecraft:mossy_cobblestone
setblock 382 182 222 minecraft:stone_bricks
fill 383 182 182 383 185 182 minecraft:mossy_cobblestone
setblock 383 182 221 minecraft:stone_bricks
fill 383 182 222 386 182 222 minecraft:mossy_cobblestone
fill 384 182 221 384 185 221 minecraft:mossy_cobblestone
setblock 385 182 184 minecraft:stone_bricks
setblock 386 182 183 minecraft:stone_bricks
setblock 387 182 182 minecraft:stone_bricks
setblock 387 182 222 minecraft:stone_bricks
fill 388 182 182 388 183 182 minecraft:mossy_cobblestone
fill 388 182 222 388 185 222 minecraft:mossy_cobblestone
fill 399 182 222 399 184 222 minecraft:mossy_cobblestone
setblock 402 182 182 minecraft:stone_bricks
fill 402 182 183 402 183 183 minecraft:mossy_cobblestone
setblock 402 182 222 minecraft:stone_bricks
fill 403 182 182 403 185 182 minecraft:mossy_cobblestone
fill 403 182 222 403 184 222 minecraft:mossy_cobblestone
setblock 407 182 182 minecraft:stone_bricks
fill 411 182 199 411 183 199 minecraft:lantern
fill 414 182 182 414 184 182 minecraft:mossy_cobblestone
fill 415 182 187 415 182 188 minecraft:mossy_cobblestone
setblock 415 182 189 minecraft:stone_bricks
fill 415 182 190 415 185 190 minecraft:mossy_cobblestone
setblock 416 182 183 minecraft:stone_bricks
fill 416 182 184 416 185 184 minecraft:mossy_cobblestone
setblock 416 182 187 minecraft:mossy_cobblestone
setblock 416 182 188 minecraft:stone_bricks
fill 416 182 189 416 185 189 minecraft:mossy_cobblestone
setblock 416 182 192 minecraft:mossy_cobblestone
setblock 416 182 193 minecraft:stone_bricks
fill 416 182 194 416 185 194 minecraft:mossy_cobblestone
setblock 417 182 182 minecraft:stone_bricks
fill 417 182 183 417 185 183 minecraft:mossy_cobblestone
setblock 417 182 187 minecraft:stone_bricks
fill 417 182 188 417 185 188 minecraft:mossy_cobblestone
setblock 417 182 191 minecraft:mossy_cobblestone
setblock 417 182 192 minecraft:stone_bricks
fill 417 182 193 417 185 193 minecraft:mossy_cobblestone
setblock 417 182 197 minecraft:stone_bricks
fill 417 182 198 417 185 198 minecraft:mossy_cobblestone
fill 417 182 203 417 184 203 minecraft:mossy_cobblestone
setblock 417 182 206 minecraft:mossy_cobblestone
setblock 417 182 207 minecraft:stone_bricks
fill 417 182 208 417 182 211 minecraft:mossy_cobblestone
setblock 417 182 212 minecraft:stone_bricks
fill 417 182 213 417 184 214 minecraft:mossy_cobblestone
setblock 376 183 206 minecraft:cobblestone
fill 376 183 207 377 184 207 minecraft:mossy_cobblestone
setblock 376 183 208 minecraft:cobblestone
fill 376 183 209 376 186 210 minecraft:mossy_cobblestone
setblock 376 183 211 minecraft:cobblestone
fill 376 183 212 376 183 216 minecraft:mossy_cobblestone
fill 376 183 217 376 184 217 minecraft:cobblestone
fill 376 183 223 382 183 223 minecraft:mossy_cobblestone
fill 377 183 182 377 186 182 minecraft:mossy_cobblestone
setblock 377 183 186 minecraft:stone_bricks
fill 377 183 187 377 186 187 minecraft:mossy_cobblestone
setblock 377 183 190 minecraft:mossy_cobblestone
setblock 377 183 191 minecraft:stone_bricks
fill 377 183 192 377 186 192 minecraft:mossy_cobblestone
setblock 377 183 196 minecraft:stone_bricks
setblock 377 183 205 minecraft:mossy_cobblestone
setblock 377 183 206 minecraft:stone_bricks
setblock 377 183 210 minecraft:mossy_cobblestone
setblock 377 183 211 minecraft:stone_bricks
fill 377 183 212 377 186 212 minecraft:mossy_cobblestone
setblock 377 183 216 minecraft:stone_bricks
fill 377 183 217 377 183 220 minecraft:mossy_cobblestone
setblock 377 183 221 minecraft:stone_bricks
fill 377 183 222 377 186 222 minecraft:mossy_cobblestone
setblock 378 183 185 minecraft:stone_bricks
fill 378 183 186 378 186 186 minecraft:mossy_cobblestone
setblock 378 183 189 minecraft:mossy_cobblestone
setblock 378 183 190 minecraft:stone_bricks
fill 378 183 191 378 186 191 minecraft:mossy_cobblestone
setblock 378 183 194 minecraft:mossy_cobblestone
setblock 378 183 210 minecraft:stone_bricks
fill 378 183 211 378 186 211 minecraft:mossy_cobblestone
setblock 378 183 214 minecraft:mossy_cobblestone
setblock 378 183 215 minecraft:stone_bricks
fill 378 183 216 378 183 219 minecraft:mossy_cobblestone
setblock 378 183 220 minecraft:stone_bricks
fill 378 183 221 378 186 221 minecraft:mossy_cobblestone
fill 379 183 181 379 184 181 minecraft:mossy_cobblestone
setblock 379 183 184 minecraft:stone_bricks
fill 379 183 185 379 186 185 minecraft:mossy_cobblestone
setblock 379 183 189 minecraft:stone_bricks
fill 379 183 190 379 186 190 minecraft:mossy_cobblestone
fill 379 183 192 379 184 192 minecraft:mossy_cobblestone
setblock 379 183 209 minecraft:stone_bricks
fill 379 183 210 379 186 210 minecraft:mossy_cobblestone
setblock 379 183 213 minecraft:mossy_cobblestone
setblock 379 183 214 minecraft:stone_bricks
fill 379 183 215 379 185 216 minecraft:mossy_cobblestone
fill 380 183 181 380 184 181 minecraft:cobblestone
setblock 380 183 183 minecraft:stone_bricks
fill 380 183 184 380 185 184 minecraft:mossy_cobblestone
setblock 380 183 188 minecraft:stone_bricks
fill 380 183 189 380 185 189 minecraft:mossy_cobblestone
setblock 381 183 182 minecraft:stone_bricks
fill 381 183 183 381 186 183 minecraft:mossy_cobblestone
fill 381 183 220 382 183 220 minecraft:mossy_cobblestone
setblock 381 183 222 minecraft:stone_bricks
setblock 382 183 181 minecraft:cobblestone
fill 382 183 182 382 186 182 minecraft:mossy_cobblestone
setblock 382 183 221 minecraft:stone_bricks
fill 382 183 222 385 183 222 minecraft:mossy_cobblestone
fill 383 183 181 383 186 181 minecraft:mossy_cobblestone
setblock 383 183 220 minecraft:stone_bricks
fill 383 183 221 383 186 221 minecraft:mossy_cobblestone
setblock 383 183 223 minecraft:cobblestone
setblock 384 183 184 minecraft:stone_bricks
setblock 385 183 183 minecraft:stone_bricks
setblock 386 183 182 minecraft:stone_bricks
setblock 386 183 183 minecraft:mossy_cobblestone
setblock 386 183 222 minecraft:stone_bricks
fill 387 183 182 387 184 182 minecraft:mossy_cobblestone
fill 387 183 222 387 186 222 minecraft:mossy_cobblestone
fill 394 183 223 395 183 223 minecraft:cobblestone
fill 397 183 223 397 186 223 minecraft:mossy_cobblestone
fill 398 183 222 398 185 222 minecraft:mossy_cobblestone
setblock 398 183 223 minecraft:cobblestone
setblock 401 183 182 minecraft:stone_bricks
setblock 401 183 222 minecraft:stone_bricks
fill 402 183 182 402 186 182 minecraft:mossy_cobblestone
fill 402 183 222 402 185 222 minecraft:mossy_cobblestone
setblock 404 183 181 minecraft:cobblestone
setblock 406 183 182 minecraft:stone_bricks
fill 406 183 223 406 186 223 minecraft:mossy_cobblestone
fill 407 183 181 407 183 182 minecraft:mossy_cobblestone
setblock 407 183 223 minecraft:cobblestone
fill 408 183 181 408 186 181 minecraft:mossy_cobblestone
fill 409 183 181 410 183 181 minecraft:cobblestone
fill 412 183 181 412 186 181 minecraft:mossy_cobblestone
setblock 413 183 181 minecraft:cobblestone
fill 414 183 181 416 183 181 minecraft:mossy_cobblestone
fill 415 183 186 415 183 187 minecraft:mossy_cobblestone
setblock 415 183 188 minecraft:stone_bricks
fill 415 183 189 415 186 189 minecraft:mossy_cobblestone
fill 415 183 191 415 183 192 minecraft:mossy_cobblestone
setblock 415 183 223 minecraft:cobblestone
setblock 416 183 182 minecraft:stone_bricks
fill 416 183 183 416 186 183 minecraft:mossy_cobblestone
setblock 416 183 187 minecraft:stone_bricks
fill 416 183 188 416 186 188 minecraft:mossy_cobblestone
setblock 416 183 192 minecraft:stone_bricks
fill 416 183 193 416 186 193 minecraft:mossy_cobblestone
fill 416 183 195 416 184 195 minecraft:mossy_cobblestone
fill 417 183 182 417 186 182 minecraft:mossy_cobblestone
setblock 417 183 186 minecraft:stone_bricks
fill 417 183 187 417 186 187 minecraft:mossy_cobblestone
setblock 417 183 191 minecraft:stone_bricks
fill 417 183 192 417 186 192 minecraft:mossy_cobblestone
setblock 417 183 196 minecraft:stone_bricks
fill 417 183 197 417 186 197 minecraft:mossy_cobblestone
fill 417 183 199 417 183 200 minecraft:mossy_cobblestone
setblock 417 183 206 minecraft:stone_bricks
fill 417 183 207 417 183 210 minecraft:mossy_cobblestone
setblock 417 183 211 minecraft:stone_bricks
fill 417 183 212 417 186 212 minecraft:mossy_cobblestone
setblock 417 183 215 minecraft:mossy_cobblestone
setblock 417 183 216 minecraft:stone_bricks
fill 417 183 223 417 187 223 minecraft:mossy_cobblestone
setblock 418 183 185 minecraft:cobblestone
fill 418 183 186 418 186 186 minecraft:mossy_cobblestone
setblock 418 183 195 minecraft:cobblestone
fill 418 183 211 418 186 211 minecraft:mossy_cobblestone
setblock 418 183 212 minecraft:cobblestone
setblock 418 183 216 minecraft:cobblestone
fill 418 183 217 418 186 219 minecraft:mossy_cobblestone
fill 418 183 223 418 184 223 minecraft:cobblestone
fill 376 184 184 376 186 184 minecraft:mossy_cobblestone
fill 376 184 185 376 184 186 minecraft:cobblestone
fill 376 184 187 376 186 196 minecraft:mossy_cobblestone
fill 376 184 206 377 186 206 minecraft:mossy_cobblestone
fill 376 184 208 376 186 208 minecraft:mossy_cobblestone
fill 376 184 211 377 186 211 minecraft:mossy_cobblestone
setblock 376 184 212 minecraft:cobblestone
fill 376 184 213 376 184 216 minecraft:mossy_cobblestone
setblock 376 184 223 minecraft:cobblestone
setblock 377 184 185 minecraft:stone_bricks
fill 377 184 186 377 187 186 minecraft:mossy_cobblestone
setblock 377 184 190 minecraft:stone_bricks
fill 377 184 191 377 187 191 minecraft:mossy_cobblestone
setblock 377 184 195 minecraft:stone_bricks
fill 377 184 196 377 186 197 minecraft:mossy_cobblestone
setblock 377 184 205 minecraft:stone_bricks
setblock 377 184 209 minecraft:mossy_cobblestone
setblock 377 184 210 minecraft:stone_bricks
setblock 377 184 214 minecraft:mossy_cobblestone
setblock 377 184 215 minecraft:stone_bricks
fill 377 184 216 377 184 219 minecraft:mossy_cobblestone
setblock 377 184 220 minecraft:stone_bricks
fill 377 184 221 377 187 221 minecraft:mossy_cobblestone
fill 377 184 223 383 184 223 minecraft:mossy_cobblestone
setblock 378 184 184 minecraft:stone_bricks
fill 378 184 185 378 187 185 minecraft:mossy_cobblestone
setblock 378 184 189 minecraft:stone_bricks
fill 378 184 190 378 187 190 minecraft:mossy_cobblestone
setblock 378 184 194 minecraft:stone_bricks
fill 378 184 195 378 187 195 minecraft:mossy_cobblestone
setblock 378 184 209 minecraft:stone_bricks
fill 378 184 210 378 187 210 minecraft:mossy_cobblestone
setblock 378 184 214 minecraft:stone_bricks
fill 378 184 215 378 184 218 minecraft:mossy_cobblestone
setblock 378 184 219 minecraft:stone_bricks
fill 378 184 220 378 187 220 minecraft:mossy_cobblestone
setblock 379 184 183 minecraft:stone_bricks
fill 379 184 184 379 186 184 minecraft:mossy_cobblestone
setblock 379 184 187 minecraft:mossy_cobblestone
setblock 379 184 188 minecraft:stone_bricks
fill 379 184 189 379 187 189 minecraft:mossy_cobblestone
setblock 379 184 193 minecraft:stone_bricks
fill 379 184 209 379 186 209 minecraft:mossy_cobblestone
setblock 379 184 213 minecraft:stone_bricks
fill 379 184 214 380 186 214 minecraft:mossy_cobblestone
setblock 379 184 217 minecraft:mossy_cobblestone
setblock 379 184 218 minecraft:stone_bricks
fill 379 184 219 379 187 219 minecraft:mossy_cobblestone
setblock 380 184 182 minecraft:stone_bricks
fill 380 184 183 380 187 183 minecraft:mossy_cobblestone
setblock 380 184 187 minecraft:stone_bricks
fill 380 184 188 380 185 188 minecraft:mossy_cobblestone
setblock 380 184 190 minecraft:mossy_cobblestone
setblock 380 184 211 minecraft:mossy_cobblestone
setblock 380 184 212 minecraft:stone_bricks
fill 380 184 213 380 187 213 minecraft:mossy_cobblestone
fill 380 184 215 380 185 215 minecraft:mossy_cobblestone
fill 380 184 220 381 184 220 minecraft:mossy_cobblestone
setblock 380 184 222 minecraft:stone_bricks
fill 381 184 182 381 187 182 minecraft:mossy_cobblestone
setblock 381 184 221 minecraft:stone_bricks
fill 381 184 222 384 184 222 minecraft:mossy_cobblestone
fill 382 184 181 382 186 181 minecraft:mossy_cobblestone
setblock 382 184 220 minecraft:stone_bricks
fill 382 184 221 382 187 221 minecraft:mossy_cobblestone
setblock 383 184 184 minecraft:stone_bricks
fill 383 184 220 383 186 220 minecraft:mossy_cobblestone
setblock 384 184 181 minecraft:cobblestone
setblock 384 184 183 minecraft:stone_bricks
setblock 385 184 182 minecraft:stone_bricks
setblock 385 184 183 minecraft:mossy_cobblestone
setblock 385 184 222 minecraft:stone_bricks
setblock 386 184 181 minecraft:cobblestone
fill 386 184 182 386 185 182 minecraft:mossy_cobblestone
setblock 386 184 221 minecraft:stone_bricks
fill 386 184 222 386 187 222 minecraft:mossy_cobblestone
setblock 393 184 223 minecraft:cobblestone
fill 394 184 223 395 184 223 minecraft:mossy_cobblestone
setblock 396 184 223 minecraft:cobblestone
fill 398 184 223 398 186 223 minecraft:mossy_cobblestone
setblock 400 184 182 minecraft:stone_bricks
setblock 400 184 222 minecraft:stone_bricks
fill 401 184 182 401 186 182 minecraft:mossy_cobblestone
fill 401 184 222 401 186 222 minecraft:mossy_cobblestone
fill 404 184 181 404 186 181 minecraft:mossy_cobblestone
setblock 405 184 182 minecraft:stone_bricks
setblock 407 184 181 minecraft:mossy_cobblestone
fill 407 184 223 407 186 223 minecraft:mossy_cobblestone
setblock 408 184 223 minecraft:cobblestone
fill 409 184 181 410 186 181 minecraft:mossy_cobblestone
fill 409 184 223 409 186 223 minecraft:mossy_cobblestone
fill 411 184 199 411 190 199 minecraft:cobbled_deepslate
fill 413 184 181 413 186 181 minecraft:mossy_cobblestone
setblock 414 184 181 minecraft:cobblestone
fill 415 184 181 416 186 181 minecraft:mossy_cobblestone
setblock 415 184 182 minecraft:stone_bricks
fill 415 184 183 415 185 183 minecraft:mossy_cobblestone
setblock 415 184 186 minecraft:mossy_cobblestone
setblock 415 184 187 minecraft:stone_bricks
fill 415 184 188 415 187 188 minecraft:mossy_cobblestone
setblock 415 184 191 minecraft:mossy_cobblestone
setblock 415 184 192 minecraft:stone_bricks
fill 415 184 193 415 187 193 minecraft:mossy_cobblestone
setblock 415 184 223 minecraft:mossy_cobblestone
fill 416 184 182 416 187 182 minecraft:mossy_cobblestone
setblock 416 184 186 minecraft:stone_bricks
fill 416 184 187 416 187 187 minecraft:mossy_cobblestone
setblock 416 184 191 minecraft:stone_bricks
fill 416 184 192 416 187 192 minecraft:mossy_cobblestone
setblock 416 184 196 minecraft:stone_bricks
setblock 416 184 211 minecraft:stone_bricks
setblock 417 184 185 minecraft:stone_bricks
fill 417 184 186 417 187 186 minecraft:mossy_cobblestone
setblock 417 184 190 minecraft:stone_bricks
fill 417 184 191 417 187 191 minecraft:mossy_cobblestone
setblock 417 184 195 minecraft:stone_bricks
fill 417 184 196 417 187 196 minecraft:mossy_cobblestone
setblock 417 184 199 minecraft:mossy_cobblestone
setblock 417 184 200 minecraft:stone_bricks
fill 417 184 201 417 185 202 minecraft:mossy_cobblestone
setblock 417 184 205 minecraft:stone_bricks
fill 417 184 206 417 184 209 minecraft:mossy_cobblestone
setblock 417 184 210 minecraft:stone_bricks
fill 417 184 211 417 187 211 minecraft:mossy_cobblestone
setblock 417 184 215 minecraft:stone_bricks
fill 417 184 216 417 184 219 minecraft:mossy_cobblestone
fill 418 184 185 418 186 185 minecraft:mossy_cobblestone
fill 418 184 188 418 184 189 minecraft:cobblestone
setblock 418 184 194 minecraft:cobblestone
fill 418 184 195 418 186 195 minecraft:mossy_cobblestone
setblock 418 184 207 minecraft:cobblestone
fill 418 184 208 418 186 208 minecraft:mossy_cobblestone
fill 418 184 212 418 187 212 minecraft:mossy_cobblestone
fill 418 184 216 418 186 216 minecraft:mossy_cobblestone
fill 376 185 185 376 186 186 minecraft:mossy_cobblestone
fill 376 185 201 376 186 203 minecraft:mossy_cobblestone
setblock 376 185 204 minecraft:cobblestone
setblock 376 185 207 minecraft:cobblestone
fill 376 185 212 376 186 215 minecraft:mossy_cobblestone
setblock 376 185 216 minecraft:cobblestone
fill 376 185 217 378 185 217 minecraft:mossy_cobblestone
setblock 376 185 218 minecraft:cobblestone
fill 376 185 219 376 186 223 minecraft:mossy_cobblestone
setblock 377 185 184 minecraft:stone_bricks
fill 377 185 185 377 188 185 minecraft:mossy_cobblestone
setblock 377 185 189 minecraft:stone_bricks
fill 377 185 190 377 188 190 minecraft:mossy_cobblestone
setblock 377 185 193 minecraft:mossy_cobblestone
setblock 377 185 194 minecraft:stone_bricks
fill 377 185 195 377 188 195 minecraft:mossy_cobblestone
setblock 377 185 198 minecraft:mossy_cobblestone
setblock 377 185 205 minecraft:mossy_cobblestone
fill 377 185 207 377 185 208 minecraft:mossy_cobblestone
setblock 377 185 209 minecraft:stone_bricks
fill 377 185 210 377 188 210 minecraft:mossy_cobblestone
setblock 377 185 213 minecraft:mossy_cobblestone
setblock 377 185 214 minecraft:stone_bricks
fill 377 185 215 378 186 216 minecraft:mossy_cobblestone
setblock 377 185 218 minecraft:mossy_cobblestone
setblock 377 185 219 minecraft:stone_bricks
fill 377 185 220 377 188 220 minecraft:mossy_cobblestone
fill 377 185 223 382 186 223 minecraft:mossy_cobblestone
setblock 378 185 183 minecraft:stone_bricks
fill 378 185 184 378 188 184 minecraft:mossy_cobblestone
setblock 378 185 188 minecraft:stone_bricks
fill 378 185 189 378 188 189 minecraft:mossy_cobblestone
setblock 378 185 193 minecraft:stone_bricks
fill 378 185 194 378 188 194 minecraft:mossy_cobblestone
fill 378 185 196 378 186 196 minecraft:mossy_cobblestone
setblock 378 185 208 minecraft:stone_bricks
fill 378 185 209 378 188 209 minecraft:mossy_cobblestone
setblock 378 185 212 minecraft:mossy_cobblestone
setblock 378 185 213 minecraft:stone_bricks
fill 378 185 214 378 188 214 minecraft:mossy_cobblestone
setblock 378 185 218 minecraft:stone_bricks
fill 378 185 219 378 188 219 minecraft:mossy_cobblestone
setblock 379 185 181 minecraft:cobblestone
setblock 379 185 182 minecraft:stone_bricks
fill 379 185 183 379 188 183 minecraft:mossy_cobblestone
setblock 379 185 187 minecraft:stone_bricks
fill 379 185 188 379 187 188 minecraft:mossy_cobblestone
setblock 379 185 192 minecraft:stone_bricks
fill 379 185 193 379 187 193 minecraft:mossy_cobblestone
setblock 379 185 200 minecraft:light[level=12]
setblock 379 185 208 minecraft:light[level=12]
setblock 379 185 212 minecraft:stone_bricks
fill 379 185 213 379 188 213 minecraft:mossy_cobblestone
setblock 379 185 217 minecraft:stone_bricks
fill 379 185 218 379 188 218 minecraft:mossy_cobblestone
fill 379 185 220 380 185 220 minecraft:mossy_cobblestone
setblock 379 185 222 minecraft:stone_bricks
fill 380 185 181 380 186 182 minecraft:mossy_cobblestone
setblock 380 185 211 minecraft:stone_bricks
fill 380 185 212 380 187 212 minecraft:mossy_cobblestone
setblock 380 185 216 minecraft:stone_bricks
fill 380 185 217 380 188 217 minecraft:mossy_cobblestone
setblock 380 185 221 minecraft:stone_bricks
fill 380 185 222 383 185 222 minecraft:mossy_cobblestone
setblock 381 185 220 minecraft:stone_bricks
fill 381 185 221 381 188 221 minecraft:mossy_cobblestone
setblock 382 185 184 minecraft:stone_bricks
fill 382 185 220 382 188 220 minecraft:mossy_cobblestone
setblock 383 185 183 minecraft:stone_bricks
setblock 383 185 223 minecraft:cobblestone
fill 384 185 181 384 186 181 minecraft:mossy_cobblestone
setblock 384 185 182 minecraft:stone_bricks
setblock 384 185 183 minecraft:mossy_cobblestone
setblock 384 185 222 minecraft:stone_bricks
setblock 385 185 182 minecraft:mossy_cobblestone
setblock 385 185 221 minecraft:stone_bricks
fill 385 185 222 385 188 222 minecraft:mossy_cobblestone
fill 386 185 181 386 186 181 minecraft:mossy_cobblestone
setblock 387 185 184 minecraft:light[level=12]
setblock 387 185 192 minecraft:light[level=12]
setblock 387 185 200 minecraft:light[level=12]
setblock 387 185 208 minecraft:light[level=12]
setblock 387 185 216 minecraft:light[level=12]
setblock 389 185 181 minecraft:cobblestone
fill 390 185 181 393 186 181 minecraft:mossy_cobblestone
fill 393 185 223 394 186 223 minecraft:mossy_cobblestone
setblock 394 185 181 minecraft:cobblestone
fill 395 185 181 399 186 181 minecraft:mossy_cobblestone
setblock 395 185 184 minecraft:light[level=12]
setblock 395 185 192 minecraft:light[level=12]
setblock 395 185 200 minecraft:light[level=12]
setblock 395 185 208 minecraft:light[level=12]
setblock 395 185 216 minecraft:light[level=12]
setblock 395 185 223 minecraft:cobblestone
fill 396 185 223 396 186 223 minecraft:mossy_cobblestone
fill 397 185 222 397 186 222 minecraft:mossy_cobblestone
setblock 399 185 182 minecraft:stone_bricks
setblock 399 185 222 minecraft:stone_bricks
setblock 400 185 181 minecraft:cobblestone
fill 400 185 182 400 186 182 minecraft:mossy_cobblestone
fill 400 185 222 400 187 222 minecraft:mossy_cobblestone
setblock 403 185 184 minecraft:light[level=12]
setblock 403 185 192 minecraft:light[level=12]
setblock 403 185 200 minecraft:light[level=12]
setblock 403 185 208 minecraft:light[level=12]
setblock 403 185 216 minecraft:light[level=12]
setblock 404 185 182 minecraft:stone_bricks
setblock 407 185 181 minecraft:cobblestone
fill 408 185 223 408 186 223 minecraft:mossy_cobblestone
setblock 411 185 184 minecraft:light[level=12]
setblock 411 185 192 minecraft:light[level=12]
setblock 411 185 200 minecraft:light[level=12]
setblock 411 185 208 minecraft:light[level=12]
setblock 411 185 216 minecraft:light[level=12]
fill 414 185 181 414 186 181 minecraft:mossy_cobblestone
setblock 414 185 182 minecraft:stone_bricks
fill 415 185 182 415 188 182 minecraft:mossy_cobblestone
setblock 415 185 186 minecraft:stone_bricks
fill 415 185 187 415 187 187 minecraft:mossy_cobblestone
setblock 415 185 191 minecraft:stone_bricks
fill 415 185 192 415 188 192 minecraft:mossy_cobblestone
fill 415 185 194 415 186 194 minecraft:mossy_cobblestone
setblock 415 185 223 minecraft:cobblestone
setblock 416 185 185 minecraft:stone_bricks
fill 416 185 186 416 188 186 minecraft:mossy_cobblestone
setblock 416 185 190 minecraft:stone_bricks
fill 416 185 191 416 188 191 minecraft:mossy_cobblestone
setblock 416 185 195 minecraft:stone_bricks
fill 416 185 196 416 187 197 minecraft:mossy_cobblestone
setblock 416 185 210 minecraft:stone_bricks
fill 416 185 211 416 185 214 minecraft:mossy_cobblestone
setblock 417 185 184 minecraft:stone_bricks
fill 417 185 185 417 188 185 minecraft:mossy_cobblestone
setblock 417 185 189 minecraft:stone_bricks
fill 417 185 190 417 188 190 minecraft:mossy_cobblestone
setblock 417 185 194 minecraft:stone_bricks
fill 417 185 195 417 188 195 minecraft:mossy_cobblestone
setblock 417 185 199 minecraft:stone_bricks
fill 417 185 200 417 188 200 minecraft:mossy_cobblestone
setblock 417 185 204 minecraft:stone_bricks
fill 417 185 205 417 185 208 minecraft:mossy_cobblestone
setblock 417 185 209 minecraft:stone_bricks
fill 417 185 210 417 188 210 minecraft:mossy_cobblestone
setblock 417 185 213 minecraft:mossy_cobblestone
setblock 417 185 214 minecraft:stone_bricks
fill 417 185 215 417 185 218 minecraft:mossy_cobblestone
setblock 417 185 219 minecraft:stone_bricks
fill 417 185 220 417 186 222 minecraft:mossy_cobblestone
setblock 418 185 182 minecraft:cobblestone
fill 418 185 188 418 186 189 minecraft:mossy_cobblestone
fill 418 185 194 418 186 194 minecraft:mossy_cobblestone
setblock 418 185 205 minecraft:cobblestone
fill 418 185 206 418 186 207 minecraft:mossy_cobblestone
setblock 418 185 214 minecraft:cobblestone
fill 418 185 223 418 186 223 minecraft:mossy_cobblestone
setblock 376 186 204 minecraft:mossy_cobblestone
fill 376 186 207 377 186 207 minecraft:mossy_cobblestone
fill 376 186 216 376 186 218 minecraft:mossy_cobblestone
setblock 377 186 183 minecraft:stone_bricks
fill 377 186 184 377 189 184 minecraft:mossy_cobblestone
setblock 377 186 188 minecraft:stone_bricks
fill 377 186 189 377 189 189 minecraft:mossy_cobblestone
setblock 377 186 193 minecraft:stone_bricks
fill 377 186 194 377 189 194 minecraft:mossy_cobblestone
setblock 377 186 198 minecraft:stone_bricks
setblock 377 186 208 minecraft:stone_bricks
fill 377 186 209 377 189 209 minecraft:mossy_cobblestone
setblock 377 186 213 minecraft:stone_bricks
fill 377 186 214 377 189 214 minecraft:mossy_cobblestone
setblock 377 186 217 minecraft:mossy_cobblestone
setblock 377 186 218 minecraft:stone_bricks
fill 377 186 219 377 189 219 minecraft:mossy_cobblestone
setblock 378 186 182 minecraft:stone_bricks
fill 378 186 183 378 188 183 minecraft:mossy_cobblestone
setblock 378 186 187 minecraft:stone_bricks
fill 378 186 188 378 189 188 minecraft:mossy_cobblestone
setblock 378 186 192 minecraft:stone_bricks
fill 378 186 193 378 189 193 minecraft:mossy_cobblestone
setblock 378 186 207 minecraft:stone_bricks
fill 378 186 208 378 187 208 minecraft:mossy_cobblestone
setblock 378 186 212 minecraft:stone_bricks
fill 378 186 213 378 189 213 minecraft:mossy_cobblestone
setblock 378 186 217 minecraft:stone_bricks
fill 378 186 218 378 189 218 minecraft:mossy_cobblestone
setblock 378 186 222 minecraft:stone_bricks
fill 379 186 181 379 186 182 minecraft:mossy_cobblestone
setblock 379 186 186 minecraft:stone_bricks
fill 379 186 187 379 187 187 minecraft:mossy_cobblestone
setblock 379 186 191 minecraft:stone_bricks
fill 379 186 192 379 188 192 minecraft:mossy_cobblestone
setblock 379 186 211 minecraft:stone_bricks
fill 379 186 212 379 189 212 minecraft:mossy_cobblestone
setblock 379 186 215 minecraft:mossy_cobblestone
setblock 379 186 216 minecraft:stone_bricks
fill 379 186 217 379 189 217 minecraft:mossy_cobblestone
setblock 379 186 220 minecraft:mossy_cobblestone
setblock 379 186 221 minecraft:stone_bricks
fill 379 186 222 382 186 222 minecraft:mossy_cobblestone
setblock 380 186 211 minecraft:mossy_cobblestone
setblock 380 186 215 minecraft:stone_bricks
fill 380 186 216 380 189 216 minecraft:mossy_cobblestone
setblock 380 186 220 minecraft:stone_bricks
fill 380 186 221 380 189 221 minecraft:mossy_cobblestone
fill 381 186 220 381 189 220 minecraft:mossy_cobblestone
setblock 382 186 183 minecraft:stone_bricks
setblock 383 186 182 minecraft:stone_bricks
setblock 383 186 222 minecraft:stone_bricks
setblock 383 186 223 minecraft:mossy_cobblestone
setblock 384 186 182 minecraft:mossy_cobblestone
setblock 384 186 221 minecraft:stone_bricks
fill 384 186 222 384 189 222 minecraft:mossy_cobblestone
setblock 385 186 221 minecraft:mossy_cobblestone
setblock 389 186 181 minecraft:mossy_cobblestone
setblock 394 186 181 minecraft:mossy_cobblestone
setblock 395 186 223 minecraft:mossy_cobblestone
setblock 398 186 222 minecraft:stone_bricks
setblock 399 186 182 minecraft:mossy_cobblestone
fill 399 186 222 399 188 222 minecraft:mossy_cobblestone
setblock 400 186 181 minecraft:mossy_cobblestone
setblock 407 186 181 minecraft:mossy_cobblestone
fill 410 186 199 410 190 199 minecraft:cobbled_deepslate
fill 411 186 198 411 190 198 minecraft:cobbled_deepslate
fill 411 186 200 411 190 200 minecraft:cobbled_deepslate
fill 412 186 199 412 190 199 minecraft:cobbled_deepslate
fill 414 186 182 414 189 182 minecraft:mossy_cobblestone
setblock 415 186 186 minecraft:mossy_cobblestone
setblock 415 186 190 minecraft:stone_bricks
fill 415 186 191 415 189 191 minecraft:mossy_cobblestone
setblock 415 186 195 minecraft:stone_bricks
setblock 415 186 223 minecraft:mossy_cobblestone
setblock 416 186 184 minecraft:stone_bricks
fill 416 186 185 416 189 185 minecraft:mossy_cobblestone
setblock 416 186 189 minecraft:stone_bricks
fill 416 186 190 416 189 190 minecraft:mossy_cobblestone
setblock 416 186 194 minecraft:stone_bricks
fill 416 186 195 416 189 195 minecraft:mossy_cobblestone
fill 416 186 211 416 186 213 minecraft:mossy_cobblestone
setblock 416 186 214 minecraft:stone_bricks
fill 416 186 215 417 188 215 minecraft:mossy_cobblestone
fill 416 186 222 416 187 222 minecraft:mossy_cobblestone
setblock 417 186 183 minecraft:stone_bricks
fill 417 186 184 417 189 184 minecraft:mossy_cobblestone
setblock 417 186 188 minecraft:stone_bricks
fill 417 186 189 417 189 189 minecraft:mossy_cobblestone
setblock 417 186 193 minecraft:stone_bricks
fill 417 186 194 417 189 194 minecraft:mossy_cobblestone
setblock 417 186 198 minecraft:stone_bricks
fill 417 186 199 417 189 199 minecraft:mossy_cobblestone
fill 417 186 201 417 187 201 minecraft:mossy_cobblestone
fill 417 186 205 417 186 207 minecraft:mossy_cobblestone
setblock 417 186 208 minecraft:stone_bricks
fill 417 186 209 417 189 209 minecraft:mossy_cobblestone
setblock 417 186 213 minecraft:stone_bricks
fill 417 186 214 418 186 214 minecraft:mossy_cobblestone
fill 417 186 216 417 186 217 minecraft:mossy_cobblestone
setblock 417 186 218 minecraft:stone_bricks
fill 417 186 219 417 189 219 minecraft:mossy_cobblestone
setblock 418 186 182 minecraft:mossy_cobblestone
setblock 418 186 205 minecraft:mossy_cobblestone
fill 376 187 181 376 187 191 minecraft:cobblestone
fill 376 187 192 376 189 192 minecraft:mossy_cobblestone
fill 376 187 193 376 188 200 minecraft:cobblestone
setblock 376 187 201 minecraft:mossy_cobblestone
fill 376 187 202 376 307 206 minecraft:cobblestone
setblock 376 187 207 minecraft:mossy_cobblestone
fill 376 187 208 376 187 216 minecraft:cobblestone
setblock 376 187 217 minecraft:mossy_cobblestone
fill 376 187 218 376 307 220 minecraft:cobblestone
setblock 376 187 221 minecraft:mossy_cobblestone
fill 376 187 222 376 307 223 minecraft:cobblestone
fill 377 187 181 380 307 181 minecraft:cobblestone
setblock 377 187 182 minecraft:stone_bricks
fill 377 187 183 377 190 183 minecraft:mossy_cobblestone
setblock 377 187 187 minecraft:stone_bricks
fill 377 187 188 377 190 188 minecraft:mossy_cobblestone
setblock 377 187 192 minecraft:stone_bricks
fill 377 187 193 377 190 193 minecraft:mossy_cobblestone
setblock 377 187 196 minecraft:mossy_cobblestone
setblock 377 187 197 minecraft:stone_bricks
fill 377 187 198 377 189 199 minecraft:mossy_cobblestone
setblock 377 187 206 minecraft:mossy_cobblestone
setblock 377 187 207 minecraft:stone_bricks
fill 377 187 208 377 190 208 minecraft:mossy_cobblestone
setblock 377 187 211 minecraft:mossy_cobblestone
setblock 377 187 212 minecraft:stone_bricks
fill 377 187 213 377 190 213 minecraft:mossy_cobblestone
fill 377 187 215 377 187 216 minecraft:mossy_cobblestone
setblock 377 187 217 minecraft:stone_bricks
fill 377 187 218 377 190 218 minecraft:mossy_cobblestone
setblock 377 187 222 minecraft:stone_bricks
fill 377 187 223 386 307 223 minecraft:cobblestone
fill 378 187 182 380 188 182 minecraft:mossy_cobblestone
setblock 378 187 186 minecraft:stone_bricks
fill 378 187 187 378 189 187 minecraft:mossy_cobblestone
setblock 378 187 191 minecraft:stone_bricks
fill 378 187 192 378 190 192 minecraft:mossy_cobblestone
setblock 378 187 196 minecraft:stone_bricks
setblock 378 187 211 minecraft:stone_bricks
fill 378 187 212 378 190 212 minecraft:mossy_cobblestone
setblock 378 187 215 minecraft:mossy_cobblestone
setblock 378 187 216 minecraft:stone_bricks
fill 378 187 217 378 190 217 minecraft:mossy_cobblestone
setblock 378 187 221 minecraft:stone_bricks
fill 378 187 222 381 187 222 minecraft:mossy_cobblestone
setblock 379 187 190 minecraft:stone_bricks
fill 379 187 191 379 188 191 minecraft:mossy_cobblestone
setblock 379 187 210 minecraft:stone_bricks
fill 379 187 211 379 189 211 minecraft:mossy_cobblestone
setblock 379 187 214 minecraft:mossy_cobblestone
setblock 379 187 215 minecraft:stone_bricks
fill 379 187 216 379 190 216 minecraft:mossy_cobblestone
setblock 379 187 220 minecraft:stone_bricks
fill 379 187 221 379 190 221 minecraft:mossy_cobblestone
setblock 380 187 214 minecraft:stone_bricks
fill 380 187 215 380 189 215 minecraft:mossy_cobblestone
setblock 380 187 218 minecraft:mossy_cobblestone
fill 380 187 220 380 190 220 minecraft:mossy_cobblestone
setblock 381 187 183 minecraft:stone_bricks
fill 382 187 181 398 187 181 minecraft:cobblestone
setblock 382 187 182 minecraft:stone_bricks
setblock 382 187 222 minecraft:stone_bricks
setblock 383 187 182 minecraft:mossy_cobblestone
setblock 383 187 221 minecraft:stone_bricks
fill 383 187 222 383 190 222 minecraft:mossy_cobblestone
fill 384 187 221 384 188 221 minecraft:mossy_cobblestone
setblock 387 187 223 minecraft:mossy_cobblestone
fill 388 187 223 392 188 223 minecraft:cobblestone
setblock 393 187 223 minecraft:mossy_cobblestone
fill 394 187 223 399 307 223 minecraft:cobblestone
setblock 397 187 222 minecraft:stone_bricks
fill 398 187 222 398 190 222 minecraft:mossy_cobblestone
setblock 399 187 181 minecraft:mossy_cobblestone
fill 400 187 181 402 307 181 minecraft:cobblestone
setblock 400 187 223 minecraft:mossy_cobblestone
fill 401 187 223 402 307 223 minecraft:cobblestone
fill 404 187 181 409 187 181 minecraft:cobblestone
fill 404 187 223 416 188 223 minecraft:cobblestone
setblock 410 187 181 minecraft:mossy_cobblestone
fill 410 187 198 410 190 198 minecraft:cobbled_deepslate
fill 410 187 200 410 190 200 minecraft:cobbled_deepslate
fill 411 187 181 417 187 181 minecraft:cobblestone
fill 412 187 198 412 190 198 minecraft:cobbled_deepslate
fill 412 187 200 412 190 200 minecraft:cobbled_deepslate
setblock 415 187 189 minecraft:stone_bricks
fill 415 187 190 415 190 190 minecraft:mossy_cobblestone
setblock 415 187 194 minecraft:stone_bricks
fill 415 187 195 415 190 195 minecraft:mossy_cobblestone
setblock 416 187 183 minecraft:stone_bricks
fill 416 187 184 416 190 184 minecraft:mossy_cobblestone
setblock 416 187 188 minecraft:stone_bricks
fill 416 187 189 416 190 189 minecraft:mossy_cobblestone
setblock 416 187 193 minecraft:stone_bricks
fill 416 187 194 416 190 194 minecraft:mossy_cobblestone
setblock 416 187 198 minecraft:stone_bricks
setblock 416 187 212 minecraft:mossy_cobblestone
setblock 416 187 213 minecraft:stone_bricks
fill 416 187 214 417 189 214 minecraft:mossy_cobblestone
fill 416 187 216 416 187 217 minecraft:mossy_cobblestone
setblock 417 187 182 minecraft:stone_bricks
fill 417 187 183 417 190 183 minecraft:mossy_cobblestone
setblock 417 187 187 minecraft:stone_bricks
fill 417 187 188 417 190 188 minecraft:mossy_cobblestone
setblock 417 187 192 minecraft:stone_bricks
fill 417 187 193 417 190 193 minecraft:mossy_cobblestone
setblock 417 187 197 minecraft:stone_bricks
fill 417 187 198 417 190 198 minecraft:mossy_cobblestone
setblock 417 187 207 minecraft:stone_bricks
fill 417 187 208 417 188 208 minecraft:mossy_cobblestone
setblock 417 187 212 minecraft:stone_bricks
fill 417 187 213 417 190 213 minecraft:mossy_cobblestone
setblock 417 187 216 minecraft:mossy_cobblestone
setblock 417 187 217 minecraft:stone_bricks
fill 417 187 218 417 190 218 minecraft:mossy_cobblestone
fill 417 187 220 417 187 221 minecraft:mossy_cobblestone
setblock 417 187 222 minecraft:stone_bricks
fill 418 187 181 418 188 181 minecraft:mossy_cobblestone
fill 418 187 182 418 187 186 minecraft:cobblestone
fill 418 187 188 418 188 189 minecraft:cobblestone
fill 418 187 191 418 307 191 minecraft:cobblestone
fill 418 187 193 418 187 200 minecraft:cobblestone
setblock 418 187 201 minecraft:mossy_cobblestone
fill 418 187 202 418 307 202 minecraft:cobblestone
fill 418 187 203 418 187 204 minecraft:mossy_cobblestone
fill 418 187 205 418 188 211 minecraft:cobblestone
fill 418 187 213 418 188 218 minecraft:cobblestone
setblock 418 187 219 minecraft:mossy_cobblestone
fill 418 187 220 418 307 223 minecraft:cobblestone
fill 376 188 181 376 188 183 minecraft:cobblestone
setblock 376 188 184 minecraft:mossy_cobblestone
fill 376 188 185 376 307 188 minecraft:cobblestone
setblock 376 188 189 minecraft:mossy_cobblestone
fill 376 188 190 376 307 191 minecraft:cobblestone
fill 376 188 201 376 307 201 minecraft:cobblestone
fill 376 188 207 376 188 215 minecraft:cobblestone
setblock 376 188 216 minecraft:mossy_cobblestone
fill 376 188 217 376 307 217 minecraft:cobblestone
setblock 376 188 221 minecraft:cobblestone
fill 377 188 182 377 191 182 minecraft:mossy_cobblestone
setblock 377 188 186 minecraft:stone_bricks
fill 377 188 187 377 191 187 minecraft:mossy_cobblestone
setblock 377 188 191 minecraft:stone_bricks
fill 377 188 192 377 191 192 minecraft:mossy_cobblestone
setblock 377 188 196 minecraft:stone_bricks
fill 377 188 197 377 191 197 minecraft:mossy_cobblestone
setblock 377 188 207 minecraft:mossy_cobblestone
setblock 377 188 211 minecraft:stone_bricks
fill 377 188 212 377 191 212 minecraft:mossy_cobblestone
setblock 377 188 215 minecraft:mossy_cobblestone
setblock 377 188 216 minecraft:stone_bricks
fill 377 188 217 377 191 217 minecraft:mossy_cobblestone
setblock 377 188 221 minecraft:stone_bricks
fill 377 188 222 380 188 222 minecraft:mossy_cobblestone
setblock 378 188 185 minecraft:stone_bricks
fill 378 188 186 378 189 186 minecraft:mossy_cobblestone
setblock 378 188 190 minecraft:stone_bricks
fill 378 188 191 378 190 191 minecraft:mossy_cobblestone
setblock 378 188 195 minecraft:stone_bricks
fill 378 188 196 378 191 196 minecraft:mossy_cobblestone
setblock 378 188 210 minecraft:stone_bricks
fill 378 188 211 378 191 211 minecraft:mossy_cobblestone
setblock 378 188 215 minecraft:stone_bricks
fill 378 188 216 378 191 216 minecraft:mossy_cobblestone
setblock 378 188 220 minecraft:stone_bricks
fill 378 188 221 378 191 221 minecraft:mossy_cobblestone
setblock 379 188 190 minecraft:mossy_cobblestone
setblock 379 188 214 minecraft:stone_bricks
fill 379 188 215 379 191 215 minecraft:mossy_cobblestone
setblock 379 188 219 minecraft:stone_bricks
fill 379 188 220 379 191 220 minecraft:mossy_cobblestone
setblock 380 188 213 minecraft:stone_bricks
fill 380 188 214 380 189 214 minecraft:mossy_cobblestone
setblock 380 188 218 minecraft:stone_bricks
setblock 381 188 182 minecraft:stone_bricks
setblock 381 188 222 minecraft:stone_bricks
fill 382 188 181 386 188 181 minecraft:cobblestone
setblock 382 188 182 minecraft:mossy_cobblestone
setblock 382 188 221 minecraft:stone_bricks
fill 382 188 222 382 191 222 minecraft:mossy_cobblestone
fill 383 188 221 383 190 221 minecraft:mossy_cobblestone
setblock 387 188 181 minecraft:mossy_cobblestone
fill 387 188 223 387 307 223 minecraft:cobblestone
fill 388 188 181 399 307 181 minecraft:cobblestone
fill 393 188 223 393 307 223 minecraft:cobblestone
fill 397 188 222 397 191 222 minecraft:mossy_cobblestone
fill 400 188 223 400 307 223 minecraft:cobblestone
fill 403 188 181 404 188 181 minecraft:cobblestone
fill 403 188 223 403 307 223 minecraft:cobblestone
setblock 405 188 181 minecraft:mossy_cobblestone
fill 406 188 181 415 307 181 minecraft:cobblestone
fill 409 188 199 409 190 200 minecraft:cobbled_deepslate
fill 410 188 201 411 190 201 minecraft:cobbled_deepslate
fill 411 188 197 411 190 197 minecraft:cobbled_deepslate
fill 413 188 199 413 190 199 minecraft:cobbled_deepslate
setblock 415 188 188 minecraft:stone_bricks
fill 415 188 189 415 189 189 minecraft:mossy_cobblestone
setblock 415 188 193 minecraft:stone_bricks
fill 415 188 194 415 191 194 minecraft:mossy_cobblestone
setblock 416 188 181 minecraft:mossy_cobblestone
setblock 416 188 182 minecraft:stone_bricks
fill 416 188 183 416 191 183 minecraft:mossy_cobblestone
setblock 416 188 187 minecraft:stone_bricks
fill 416 188 188 416 191 188 minecraft:mossy_cobblestone
setblock 416 188 192 minecraft:stone_bricks
fill 416 188 193 416 191 193 minecraft:mossy_cobblestone
setblock 416 188 196 minecraft:mossy_cobblestone
setblock 416 188 197 minecraft:stone_bricks
fill 416 188 198 416 191 198 minecraft:mossy_cobblestone
fill 416 188 213 416 189 213 minecraft:mossy_cobblestone
setblock 416 188 216 minecraft:mossy_cobblestone
setblock 416 188 217 minecraft:stone_bricks
fill 416 188 218 416 191 218 minecraft:mossy_cobblestone
setblock 416 188 222 minecraft:stone_bricks
fill 417 188 181 417 307 181 minecraft:cobblestone
fill 417 188 182 418 188 182 minecraft:mossy_cobblestone
setblock 417 188 186 minecraft:stone_bricks
fill 417 188 187 417 191 187 minecraft:mossy_cobblestone
setblock 417 188 191 minecraft:stone_bricks
fill 417 188 192 417 191 192 minecraft:mossy_cobblestone
setblock 417 188 196 minecraft:stone_bricks
fill 417 188 197 418 188 197 minecraft:mossy_cobblestone
setblock 417 188 211 minecraft:stone_bricks
fill 417 188 212 417 191 212 minecraft:mossy_cobblestone
setblock 417 188 216 minecraft:stone_bricks
fill 417 188 217 417 191 217 minecraft:mossy_cobblestone
setblock 417 188 220 minecraft:mossy_cobblestone
setblock 417 188 221 minecraft:stone_bricks
fill 417 188 222 417 191 222 minecraft:mossy_cobblestone
fill 417 188 223 417 307 223 minecraft:cobblestone
fill 418 188 183 418 307 187 minecraft:cobblestone
fill 418 188 190 418 307 190 minecraft:cobblestone
fill 418 188 192 418 307 193 minecraft:cobblestone
setblock 418 188 194 minecraft:mossy_cobblestone
fill 418 188 195 418 188 196 minecraft:cobblestone
fill 418 188 198 418 188 201 minecraft:cobblestone
fill 418 188 203 418 307 204 minecraft:cobblestone
fill 418 188 212 418 307 212 minecraft:cobblestone
fill 418 188 219 418 307 219 minecraft:cobblestone
fill 376 189 181 376 307 182 minecraft:cobblestone
setblock 376 189 183 minecraft:mossy_cobblestone
fill 376 189 184 376 307 184 minecraft:cobblestone
fill 376 189 189 376 307 189 minecraft:cobblestone
fill 376 189 193 376 307 196 minecraft:cobblestone
setblock 376 189 197 minecraft:mossy_cobblestone
fill 376 189 198 376 307 198 minecraft:cobblestone
setblock 376 189 199 minecraft:mossy_cobblestone
fill 376 189 200 376 307 200 minecraft:cobblestone
fill 376 189 207 376 307 208 minecraft:cobblestone
setblock 376 189 209 minecraft:mossy_cobblestone
fill 376 189 210 376 307 213 minecraft:cobblestone
setblock 376 189 214 minecraft:mossy_cobblestone
fill 376 189 215 376 307 216 minecraft:cobblestone
fill 376 189 221 377 189 221 minecraft:mossy_cobblestone
setblock 377 189 185 minecraft:stone_bricks
fill 377 189 186 377 192 186 minecraft:mossy_cobblestone
setblock 377 189 190 minecraft:stone_bricks
fill 377 189 191 377 192 191 minecraft:mossy_cobblestone
setblock 377 189 195 minecraft:stone_bricks
fill 377 189 196 377 192 196 minecraft:mossy_cobblestone
setblock 377 189 210 minecraft:stone_bricks
fill 377 189 211 377 192 211 minecraft:mossy_cobblestone
setblock 377 189 215 minecraft:stone_bricks
fill 377 189 216 377 192 216 minecraft:mossy_cobblestone
setblock 377 189 220 minecraft:stone_bricks
fill 377 189 222 379 189 222 minecraft:mossy_cobblestone
fill 378 189 182 379 189 182 minecraft:mossy_cobblestone
setblock 378 189 189 minecraft:stone_bricks
fill 378 189 190 378 190 190 minecraft:mossy_cobblestone
setblock 378 189 194 minecraft:stone_bricks
fill 378 189 195 378 192 195 minecraft:mossy_cobblestone
setblock 378 189 209 minecraft:stone_bricks
fill 378 189 210 378 190 210 minecraft:mossy_cobblestone
setblock 378 189 214 minecraft:stone_bricks
fill 378 189 215 378 192 215 minecraft:mossy_cobblestone
setblock 378 189 219 minecraft:stone_bricks
fill 378 189 220 378 192 220 minecraft:mossy_cobblestone
setblock 379 189 213 minecraft:stone_bricks
fill 379 189 214 379 192 214 minecraft:mossy_cobblestone
setblock 379 189 218 minecraft:stone_bricks
fill 379 189 219 379 192 219 minecraft:mossy_cobblestone
setblock 380 189 182 minecraft:stone_bricks
setblock 380 189 217 minecraft:stone_bricks
setblock 380 189 222 minecraft:stone_bricks
fill 381 189 181 381 307 181 minecraft:cobblestone
setblock 381 189 182 minecraft:mossy_cobblestone
setblock 381 189 221 minecraft:stone_bricks
fill 381 189 222 381 192 222 minecraft:mossy_cobblestone
setblock 382 189 181 minecraft:mossy_cobblestone
fill 382 189 221 382 192 221 minecraft:mossy_cobblestone
fill 383 189 181 387 307 181 minecraft:cobblestone
setblock 385 189 222 minecraft:stone_bricks
fill 388 189 223 388 307 223 minecraft:cobblestone
setblock 389 189 223 minecraft:mossy_cobblestone
fill 390 189 223 391 307 223 minecraft:cobblestone
setblock 392 189 223 minecraft:mossy_cobblestone
setblock 403 189 181 minecraft:mossy_cobblestone
fill 404 189 181 405 307 181 minecraft:cobblestone
setblock 404 189 223 minecraft:mossy_cobblestone
fill 405 189 223 407 307 223 minecraft:cobblestone
setblock 408 189 223 minecraft:mossy_cobblestone
fill 409 189 198 409 190 198 minecraft:cobbled_deepslate
fill 409 189 223 414 307 223 minecraft:cobblestone
fill 410 189 197 410 190 197 minecraft:cobbled_deepslate
fill 412 189 197 412 190 197 minecraft:cobbled_deepslate
fill 412 189 201 412 190 201 minecraft:cobbled_deepslate
fill 413 189 198 413 190 198 minecraft:cobbled_deepslate
fill 413 189 200 413 190 200 minecraft:cobbled_deepslate
setblock 415 189 182 minecraft:stone_bricks
setblock 415 189 192 minecraft:stone_bricks
fill 415 189 193 415 192 193 minecraft:mossy_cobblestone
setblock 415 189 222 minecraft:stone_bricks
setblock 415 189 223 minecraft:mossy_cobblestone
fill 416 189 181 416 307 181 minecraft:cobblestone
fill 416 189 182 417 191 182 minecraft:mossy_cobblestone
setblock 416 189 186 minecraft:stone_bricks
fill 416 189 187 416 192 187 minecraft:mossy_cobblestone
setblock 416 189 191 minecraft:stone_bricks
fill 416 189 192 416 192 192 minecraft:mossy_cobblestone
setblock 416 189 196 minecraft:stone_bricks
fill 416 189 197 417 191 197 minecraft:mossy_cobblestone
setblock 416 189 215 minecraft:mossy_cobblestone
setblock 416 189 216 minecraft:stone_bricks
fill 416 189 217 416 192 217 minecraft:mossy_cobblestone
fill 416 189 219 416 190 219 minecraft:mossy_cobblestone
fill 416 189 222 416 192 222 minecraft:mossy_cobblestone
fill 416 189 223 416 307 223 minecraft:cobblestone
setblock 417 189 185 minecraft:stone_bricks
fill 417 189 186 417 192 186 minecraft:mossy_cobblestone
setblock 417 189 190 minecraft:stone_bricks
fill 417 189 191 417 192 191 minecraft:mossy_cobblestone
setblock 417 189 195 minecraft:stone_bricks
fill 417 189 196 418 189 196 minecraft:mossy_cobblestone
setblock 417 189 200 minecraft:stone_bricks
setblock 417 189 210 minecraft:stone_bricks
fill 417 189 211 417 192 211 minecraft:mossy_cobblestone
setblock 417 189 215 minecraft:stone_bricks
fill 417 189 216 417 192 216 minecraft:mossy_cobblestone
setblock 417 189 220 minecraft:stone_bricks
fill 417 189 221 417 192 221 minecraft:mossy_cobblestone
fill 418 189 181 418 307 182 minecraft:cobblestone
setblock 418 189 188 minecraft:mossy_cobblestone
fill 418 189 189 418 307 189 minecraft:cobblestone
fill 418 189 194 418 307 195 minecraft:cobblestone
fill 418 189 197 418 307 198 minecraft:cobblestone
setblock 418 189 199 minecraft:mossy_cobblestone
fill 418 189 200 418 307 201 minecraft:cobblestone
fill 418 189 205 418 307 206 minecraft:cobblestone
setblock 418 189 207 minecraft:mossy_cobblestone
fill 418 189 208 418 307 211 minecraft:cobblestone
fill 418 189 213 418 307 214 minecraft:cobblestone
setblock 418 189 215 minecraft:mossy_cobblestone
fill 418 189 216 418 307 218 minecraft:cobblestone
fill 376 190 183 376 307 183 minecraft:cobblestone
fill 376 190 192 376 307 192 minecraft:cobblestone
fill 376 190 197 376 307 197 minecraft:cobblestone
fill 376 190 199 376 307 199 minecraft:cobblestone
fill 376 190 209 376 307 209 minecraft:cobblestone
fill 376 190 214 376 307 214 minecraft:cobblestone
fill 376 190 221 376 307 221 minecraft:cobblestone
setblock 377 190 184 minecraft:stone_bricks
fill 377 190 185 377 193 185 minecraft:mossy_cobblestone
setblock 377 190 189 minecraft:stone_bricks
fill 377 190 190 377 193 190 minecraft:mossy_cobblestone
setblock 377 190 194 minecraft:stone_bricks
fill 377 190 195 377 193 195 minecraft:mossy_cobblestone
setblock 377 190 198 minecraft:mossy_cobblestone
setblock 377 190 199 minecraft:stone_bricks
setblock 377 190 209 minecraft:stone_bricks
fill 377 190 210 377 193 210 minecraft:mossy_cobblestone
setblock 377 190 214 minecraft:stone_bricks
fill 377 190 215 377 193 215 minecraft:mossy_cobblestone
setblock 377 190 219 minecraft:stone_bricks
fill 377 190 220 377 191 222 minecraft:mossy_cobblestone
setblock 378 190 182 minecraft:mossy_cobblestone
setblock 378 190 189 minecraft:mossy_cobblestone
setblock 378 190 193 minecraft:stone_bricks
fill 378 190 194 378 192 194 minecraft:mossy_cobblestone
setblock 378 190 213 minecraft:stone_bricks
fill 378 190 214 378 193 214 minecraft:mossy_cobblestone
setblock 378 190 218 minecraft:stone_bricks
fill 378 190 219 378 193 219 minecraft:mossy_cobblestone
setblock 378 190 222 minecraft:mossy_cobblestone
setblock 379 190 182 minecraft:stone_bricks
setblock 379 190 212 minecraft:stone_bricks
fill 379 190 213 379 191 213 minecraft:mossy_cobblestone
setblock 379 190 217 minecraft:stone_bricks
fill 379 190 218 379 193 218 minecraft:mossy_cobblestone
setblock 379 190 222 minecraft:stone_bricks
fill 380 190 182 380 191 182 minecraft:mossy_cobblestone
setblock 380 190 216 minecraft:stone_bricks
setblock 380 190 221 minecraft:stone_bricks
fill 380 190 222 380 193 222 minecraft:mossy_cobblestone
setblock 381 190 220 minecraft:stone_bricks
fill 381 190 221 381 193 221 minecraft:mossy_cobblestone
fill 382 190 181 382 307 181 minecraft:cobblestone
setblock 384 190 222 minecraft:stone_bricks
fill 389 190 223 389 307 223 minecraft:cobblestone
fill 392 190 223 392 307 223 minecraft:cobblestone
fill 396 190 222 396 192 222 minecraft:mossy_cobblestone
fill 403 190 181 403 307 181 minecraft:cobblestone
fill 404 190 223 404 307 223 minecraft:cobblestone
setblock 408 190 199 minecraft:cobbled_deepslate
fill 408 190 223 408 307 223 minecraft:cobblestone
setblock 409 190 197 minecraft:cobbled_deepslate
setblock 409 190 201 minecraft:cobbled_deepslate
setblock 411 190 202 minecraft:cobbled_deepslate
setblock 413 190 197 minecraft:cobbled_deepslate
setblock 413 190 201 minecraft:cobbled_deepslate
setblock 414 190 182 minecraft:stone_bricks
setblock 414 190 199 minecraft:cobbled_deepslate
setblock 414 190 222 minecraft:stone_bricks
fill 415 190 182 415 193 182 minecraft:mossy_cobblestone
setblock 415 190 191 minecraft:stone_bricks
fill 415 190 192 415 193 192 minecraft:mossy_cobblestone
fill 415 190 222 415 193 222 minecraft:mossy_cobblestone
fill 415 190 223 415 307 223 minecraft:cobblestone
setblock 416 190 185 minecraft:stone_bricks
fill 416 190 186 416 193 186 minecraft:mossy_cobblestone
setblock 416 190 190 minecraft:stone_bricks
fill 416 190 191 416 193 191 minecraft:mossy_cobblestone
setblock 416 190 195 minecraft:stone_bricks
fill 416 190 196 417 192 196 minecraft:mossy_cobblestone
setblock 416 190 214 minecraft:mossy_cobblestone
setblock 416 190 215 minecraft:stone_bricks
fill 416 190 216 416 193 216 minecraft:mossy_cobblestone
setblock 416 190 220 minecraft:stone_bricks
fill 416 190 221 416 193 221 minecraft:mossy_cobblestone
setblock 417 190 184 minecraft:stone_bricks
fill 417 190 185 417 193 185 minecraft:mossy_cobblestone
setblock 417 190 189 minecraft:stone_bricks
fill 417 190 190 417 193 190 minecraft:mossy_cobblestone
setblock 417 190 194 minecraft:stone_bricks
fill 417 190 195 417 193 195 minecraft:mossy_cobblestone
setblock 417 190 199 minecraft:stone_bricks
fill 417 190 200 417 193 200 minecraft:mossy_cobblestone
setblock 417 190 210 minecraft:mossy_cobblestone
setblock 417 190 214 minecraft:stone_bricks
fill 417 190 215 417 193 215 minecraft:mossy_cobblestone
setblock 417 190 219 minecraft:stone_bricks
fill 417 190 220 417 193 220 minecraft:mossy_cobblestone
fill 418 190 188 418 307 188 minecraft:cobblestone
fill 418 190 196 418 307 196 minecraft:cobblestone
fill 418 190 199 418 307 199 minecraft:cobblestone
fill 418 190 207 418 307 207 minecraft:cobblestone
fill 418 190 215 418 307 215 minecraft:cobblestone
setblock 377 191 183 minecraft:stone_bricks
fill 377 191 184 377 194 184 minecraft:mossy_cobblestone
setblock 377 191 188 minecraft:stone_bricks
fill 377 191 189 377 193 189 minecraft:mossy_cobblestone
setblock 377 191 193 minecraft:stone_bricks
fill 377 191 194 377 194 194 minecraft:mossy_cobblestone
setblock 377 191 198 minecraft:stone_bricks
fill 377 191 199 377 193 200 minecraft:mossy_cobblestone
fill 377 191 209 377 194 209 minecraft:mossy_cobblestone
setblock 377 191 213 minecraft:stone_bricks
fill 377 191 214 377 194 214 minecraft:mossy_cobblestone
setblock 377 191 218 minecraft:stone_bricks
fill 377 191 219 377 194 219 minecraft:mossy_cobblestone
setblock 378 191 182 minecraft:stone_bricks
setblock 378 191 192 minecraft:stone_bricks
setblock 378 191 193 minecraft:mossy_cobblestone
setblock 378 191 212 minecraft:stone_bricks
fill 378 191 213 378 194 213 minecraft:mossy_cobblestone
setblock 378 191 217 minecraft:stone_bricks
fill 378 191 218 378 194 218 minecraft:mossy_cobblestone
setblock 378 191 222 minecraft:stone_bricks
fill 379 191 182 379 194 182 minecraft:mossy_cobblestone
setblock 379 191 216 minecraft:stone_bricks
fill 379 191 217 379 194 217 minecraft:mossy_cobblestone
setblock 379 191 221 minecraft:stone_bricks
fill 379 191 222 379 194 222 minecraft:mossy_cobblestone
setblock 380 191 220 minecraft:stone_bricks
fill 380 191 221 380 194 221 minecraft:mossy_cobblestone
fill 381 191 220 381 194 220 minecraft:mossy_cobblestone
setblock 383 191 222 minecraft:stone_bricks
fill 384 191 222 384 194 222 minecraft:mossy_cobblestone
fill 389 191 212 389 192 212 minecraft:lantern
fill 395 191 222 395 193 222 minecraft:mossy_cobblestone
setblock 398 191 222 minecraft:stone_bricks
fill 410 191 199 412 192 199 minecraft:lantern
setblock 411 191 198 minecraft:lantern
fill 411 191 200 411 192 200 minecraft:lantern
setblock 413 191 182 minecraft:stone_bricks
fill 414 191 182 414 194 182 minecraft:mossy_cobblestone
fill 414 191 222 414 194 222 minecraft:mossy_cobblestone
setblock 415 191 191 minecraft:mossy_cobblestone
setblock 415 191 195 minecraft:stone_bricks
fill 415 191 221 415 194 221 minecraft:mossy_cobblestone
setblock 416 191 184 minecraft:stone_bricks
fill 416 191 185 416 194 185 minecraft:mossy_cobblestone
setblock 416 191 189 minecraft:stone_bricks
fill 416 191 190 416 194 190 minecraft:mossy_cobblestone
setblock 416 191 194 minecraft:stone_bricks
fill 416 191 195 416 194 195 minecraft:mossy_cobblestone
setblock 416 191 214 minecraft:stone_bricks
fill 416 191 215 416 194 215 minecraft:mossy_cobblestone
setblock 416 191 219 minecraft:stone_bricks
fill 416 191 220 416 194 220 minecraft:mossy_cobblestone
setblock 417 191 183 minecraft:stone_bricks
fill 417 191 184 417 194 184 minecraft:mossy_cobblestone
setblock 417 191 188 minecraft:stone_bricks
fill 417 191 189 417 194 189 minecraft:mossy_cobblestone
setblock 417 191 193 minecraft:stone_bricks
fill 417 191 194 417 194 194 minecraft:mossy_cobblestone
setblock 417 191 198 minecraft:stone_bricks
fill 417 191 199 417 194 199 minecraft:mossy_cobblestone
fill 417 191 201 417 192 201 minecraft:mossy_cobblestone
setblock 417 191 213 minecraft:stone_bricks
fill 417 191 214 417 194 214 minecraft:mossy_cobblestone
setblock 417 191 218 minecraft:stone_bricks
fill 417 191 219 417 194 219 minecraft:mossy_cobblestone
setblock 377 192 182 minecraft:stone_bricks
fill 377 192 183 377 195 183 minecraft:mossy_cobblestone
setblock 377 192 187 minecraft:stone_bricks
fill 377 192 188 377 193 188 minecraft:mossy_cobblestone
setblock 377 192 192 minecraft:stone_bricks
fill 377 192 193 377 195 193 minecraft:mossy_cobblestone
setblock 377 192 197 minecraft:stone_bricks
fill 377 192 198 377 195 198 minecraft:mossy_cobblestone
setblock 377 192 201 minecraft:mossy_cobblestone
setblock 377 192 212 minecraft:stone_bricks
fill 377 192 213 377 195 213 minecraft:mossy_cobblestone
setblock 377 192 217 minecraft:stone_bricks
fill 377 192 218 377 195 218 minecraft:mossy_cobblestone
fill 377 192 220 377 192 221 minecraft:mossy_cobblestone
setblock 377 192 222 minecraft:stone_bricks
fill 378 192 182 378 195 182 minecraft:mossy_cobblestone
setblock 378 192 196 minecraft:stone_bricks
setblock 378 192 211 minecraft:stone_bricks
fill 378 192 212 378 195 212 minecraft:mossy_cobblestone
setblock 378 192 216 minecraft:stone_bricks
fill 378 192 217 378 195 217 minecraft:mossy_cobblestone
setblock 378 192 221 minecraft:stone_bricks
fill 378 192 222 378 195 222 minecraft:mossy_cobblestone
setblock 379 192 215 minecraft:stone_bricks
fill 379 192 216 379 195 216 minecraft:mossy_cobblestone
setblock 379 192 220 minecraft:stone_bricks
fill 379 192 221 379 195 221 minecraft:mossy_cobblestone
fill 380 192 220 380 195 220 minecraft:mossy_cobblestone
setblock 382 192 222 minecraft:stone_bricks
fill 383 192 222 383 195 222 minecraft:mossy_cobblestone
fill 393 192 222 394 194 222 minecraft:mossy_cobblestone
setblock 397 192 222 minecraft:stone_bricks
fill 398 192 222 399 194 222 minecraft:mossy_cobblestone
setblock 412 192 182 minecraft:stone_bricks
setblock 412 192 222 minecraft:stone_bricks
fill 413 192 182 413 195 182 minecraft:mossy_cobblestone
fill 413 192 222 413 195 222 minecraft:mossy_cobblestone
fill 414 192 221 414 195 221 minecraft:mossy_cobblestone
setblock 415 192 183 minecraft:mossy_cobblestone
setblock 415 192 194 minecraft:stone_bricks
fill 415 192 195 415 194 196 minecraft:mossy_cobblestone
setblock 416 192 182 minecraft:mossy_cobblestone
setblock 416 192 183 minecraft:stone_bricks
fill 416 192 184 416 195 184 minecraft:mossy_cobblestone
setblock 416 192 188 minecraft:stone_bricks
fill 416 192 189 416 195 189 minecraft:mossy_cobblestone
setblock 416 192 193 minecraft:stone_bricks
fill 416 192 194 416 195 194 minecraft:mossy_cobblestone
setblock 416 192 197 minecraft:mossy_cobblestone
setblock 416 192 198 minecraft:stone_bricks
fill 416 192 199 416 195 199 minecraft:mossy_cobblestone
fill 416 192 214 416 195 214 minecraft:mossy_cobblestone
setblock 416 192 218 minecraft:stone_bricks
fill 416 192 219 416 195 219 minecraft:mossy_cobblestone
setblock 417 192 182 minecraft:stone_bricks
fill 417 192 183 417 195 183 minecraft:mossy_cobblestone
setblock 417 192 187 minecraft:stone_bricks
fill 417 192 188 417 195 188 minecraft:mossy_cobblestone
setblock 417 192 192 minecraft:stone_bricks
fill 417 192 193 417 195 193 minecraft:mossy_cobblestone
setblock 417 192 197 minecraft:stone_bricks
fill 417 192 198 417 195 198 minecraft:mossy_cobblestone
setblock 417 192 212 minecraft:stone_bricks
fill 417 192 213 417 195 213 minecraft:mossy_cobblestone
setblock 417 192 217 minecraft:stone_bricks
fill 417 192 218 417 195 218 minecraft:mossy_cobblestone
setblock 417 192 222 minecraft:stone_bricks
fill 377 193 182 377 196 182 minecraft:mossy_cobblestone
setblock 377 193 191 minecraft:stone_bricks
fill 377 193 192 377 196 192 minecraft:mossy_cobblestone
setblock 377 193 196 minecraft:stone_bricks
fill 377 193 197 378 195 197 minecraft:mossy_cobblestone
setblock 377 193 201 minecraft:stone_bricks
fill 377 193 202 377 196 202 minecraft:mossy_cobblestone
setblock 377 193 211 minecraft:stone_bricks
fill 377 193 212 377 196 212 minecraft:mossy_cobblestone
setblock 377 193 216 minecraft:stone_bricks
fill 377 193 217 377 196 217 minecraft:mossy_cobblestone
setblock 377 193 220 minecraft:mossy_cobblestone
setblock 377 193 221 minecraft:stone_bricks
fill 377 193 222 377 196 222 minecraft:mossy_cobblestone
setblock 378 193 195 minecraft:stone_bricks
fill 378 193 196 378 196 196 minecraft:mossy_cobblestone
setblock 378 193 211 minecraft:mossy_cobblestone
setblock 378 193 215 minecraft:stone_bricks
fill 378 193 216 378 196 216 minecraft:mossy_cobblestone
setblock 378 193 220 minecraft:stone_bricks
fill 378 193 221 378 196 221 minecraft:mossy_cobblestone
setblock 379 193 184 minecraft:light[level=12]
setblock 379 193 192 minecraft:light[level=12]
setblock 379 193 200 minecraft:light[level=12]
setblock 379 193 208 minecraft:light[level=12]
setblock 379 193 214 minecraft:stone_bricks
fill 379 193 215 379 196 215 minecraft:mossy_cobblestone
setblock 379 193 219 minecraft:stone_bricks
fill 379 193 220 379 196 220 minecraft:mossy_cobblestone
setblock 381 193 222 minecraft:stone_bricks
setblock 382 193 221 minecraft:stone_bricks
fill 382 193 222 382 196 222 minecraft:mossy_cobblestone
fill 383 193 221 383 196 221 minecraft:mossy_cobblestone
setblock 387 193 184 minecraft:light[level=12]
setblock 387 193 192 minecraft:light[level=12]
setblock 387 193 200 minecraft:light[level=12]
setblock 387 193 208 minecraft:light[level=12]
setblock 387 193 216 minecraft:light[level=12]
fill 389 193 212 390 202 212 minecraft:cobbled_deepslate
setblock 391 193 222 minecraft:stone_bricks
fill 392 193 222 392 196 222 minecraft:mossy_cobblestone
fill 394 193 221 396 193 221 minecraft:mossy_cobblestone
setblock 395 193 184 minecraft:light[level=12]
setblock 395 193 192 minecraft:light[level=12]
setblock 395 193 200 minecraft:light[level=12]
setblock 395 193 208 minecraft:light[level=12]
setblock 395 193 216 minecraft:light[level=12]
setblock 396 193 222 minecraft:stone_bricks
fill 397 193 222 397 196 222 minecraft:mossy_cobblestone
setblock 403 193 184 minecraft:light[level=12]
setblock 403 193 192 minecraft:light[level=12]
setblock 403 193 200 minecraft:light[level=12]
setblock 403 193 208 minecraft:light[level=12]
setblock 403 193 216 minecraft:light[level=12]
setblock 411 193 182 minecraft:stone_bricks
setblock 411 193 184 minecraft:light[level=12]
setblock 411 193 192 minecraft:light[level=12]
fill 411 193 199 411 195 199 minecraft:lantern
setblock 411 193 200 minecraft:light[level=12]
setblock 411 193 208 minecraft:light[level=12]
setblock 411 193 216 minecraft:light[level=12]
setblock 411 193 222 minecraft:stone_bricks
fill 412 193 182 412 196 182 minecraft:mossy_cobblestone
fill 412 193 222 412 196 222 minecraft:mossy_cobblestone
fill 413 193 221 413 196 221 minecraft:mossy_cobblestone
setblock 414 193 183 minecraft:mossy_cobblestone
setblock 415 193 183 minecraft:stone_bricks
setblock 415 193 193 minecraft:stone_bricks
fill 415 193 194 415 196 194 minecraft:mossy_cobblestone
setblock 415 193 218 minecraft:stone_bricks
fill 415 193 219 415 195 220 minecraft:mossy_cobblestone
setblock 416 193 182 minecraft:stone_bricks
fill 416 193 183 416 196 183 minecraft:mossy_cobblestone
setblock 416 193 187 minecraft:stone_bricks
fill 416 193 188 416 196 188 minecraft:mossy_cobblestone
setblock 416 193 192 minecraft:stone_bricks
fill 416 193 193 416 196 193 minecraft:mossy_cobblestone
setblock 416 193 196 minecraft:mossy_cobblestone
setblock 416 193 197 minecraft:stone_bricks
fill 416 193 198 416 196 198 minecraft:mossy_cobblestone
setblock 416 193 217 minecraft:stone_bricks
fill 416 193 218 416 196 218 minecraft:mossy_cobblestone
setblock 416 193 222 minecraft:stone_bricks
fill 417 193 182 417 196 182 minecraft:mossy_cobblestone
setblock 417 193 186 minecraft:stone_bricks
fill 417 193 187 417 196 187 minecraft:mossy_cobblestone
setblock 417 193 191 minecraft:stone_bricks
fill 417 193 192 417 196 192 minecraft:mossy_cobblestone
setblock 417 193 196 minecraft:stone_bricks
fill 417 193 197 417 196 197 minecraft:mossy_cobblestone
setblock 417 193 201 minecraft:stone_bricks
fill 417 193 202 417 196 202 minecraft:mossy_cobblestone
fill 417 193 212 417 196 212 minecraft:mossy_cobblestone
setblock 417 193 216 minecraft:stone_bricks
fill 417 193 217 417 196 217 minecraft:mossy_cobblestone
setblock 417 193 221 minecraft:stone_bricks
fill 417 193 222 417 196 222 minecraft:mossy_cobblestone
setblock 377 194 185 minecraft:stone_bricks
setblock 377 194 190 minecraft:stone_bricks
fill 377 194 191 377 196 191 minecraft:mossy_cobblestone
setblock 377 194 195 minecraft:stone_bricks
fill 377 194 196 377 197 196 minecraft:mossy_cobblestone
setblock 377 194 199 minecraft:mossy_cobblestone
setblock 377 194 200 minecraft:stone_bricks
fill 377 194 201 377 197 201 minecraft:mossy_cobblestone
fill 377 194 203 377 194 204 minecraft:mossy_cobblestone
setblock 377 194 205 minecraft:stone_bricks
fill 377 194 207 377 195 208 minecraft:mossy_cobblestone
setblock 377 194 210 minecraft:stone_bricks
fill 377 194 211 377 197 211 minecraft:mossy_cobblestone
setblock 377 194 215 minecraft:stone_bricks
fill 377 194 216 377 197 216 minecraft:mossy_cobblestone
setblock 377 194 220 minecraft:stone_bricks
fill 377 194 221 377 197 221 minecraft:mossy_cobblestone
setblock 378 194 198 minecraft:mossy_cobblestone
setblock 378 194 199 minecraft:stone_bricks
setblock 378 194 214 minecraft:stone_bricks
fill 378 194 215 378 197 215 minecraft:mossy_cobblestone
setblock 378 194 219 minecraft:stone_bricks
fill 378 194 220 378 197 220 minecraft:mossy_cobblestone
setblock 379 194 214 minecraft:mossy_cobblestone
setblock 379 194 218 minecraft:stone_bricks
fill 379 194 219 379 197 219 minecraft:mossy_cobblestone
setblock 380 194 222 minecraft:stone_bricks
setblock 381 194 221 minecraft:stone_bricks
fill 381 194 222 381 197 222 minecraft:mossy_cobblestone
fill 382 194 221 382 197 221 minecraft:mossy_cobblestone
setblock 385 194 222 minecraft:stone_bricks
fill 386 194 222 389 194 222 minecraft:mossy_cobblestone
setblock 390 194 222 minecraft:stone_bricks
fill 391 194 222 391 197 222 minecraft:mossy_cobblestone
fill 392 194 221 395 194 221 minecraft:mossy_cobblestone
setblock 395 194 222 minecraft:stone_bricks
fill 396 194 182 398 195 182 minecraft:mossy_cobblestone
setblock 396 194 221 minecraft:stone_bricks
fill 396 194 222 396 197 222 minecraft:mossy_cobblestone
fill 397 194 221 397 197 221 minecraft:mossy_cobblestone
setblock 400 194 222 minecraft:stone_bricks
setblock 410 194 182 minecraft:stone_bricks
setblock 410 194 222 minecraft:stone_bricks
fill 411 194 182 411 197 182 minecraft:mossy_cobblestone
fill 411 194 222 411 197 222 minecraft:mossy_cobblestone
fill 412 194 183 413 194 183 minecraft:mossy_cobblestone
fill 412 194 221 412 197 221 minecraft:mossy_cobblestone
setblock 414 194 183 minecraft:stone_bricks
fill 414 194 220 414 196 220 minecraft:mossy_cobblestone
setblock 415 194 182 minecraft:stone_bricks
fill 415 194 183 415 197 183 minecraft:mossy_cobblestone
fill 415 194 193 415 195 193 minecraft:mossy_cobblestone
setblock 415 194 197 minecraft:stone_bricks
setblock 415 194 217 minecraft:stone_bricks
fill 415 194 218 415 197 218 minecraft:mossy_cobblestone
setblock 415 194 222 minecraft:stone_bricks
fill 416 194 182 416 197 182 minecraft:mossy_cobblestone
setblock 416 194 186 minecraft:stone_bricks
fill 416 194 187 416 197 187 minecraft:mossy_cobblestone
setblock 416 194 191 minecraft:stone_bricks
fill 416 194 192 416 197 192 minecraft:mossy_cobblestone
setblock 416 194 196 minecraft:stone_bricks
fill 416 194 197 416 197 197 minecraft:mossy_cobblestone
setblock 416 194 200 minecraft:mossy_cobblestone
setblock 416 194 216 minecraft:stone_bricks
fill 416 194 217 416 197 217 minecraft:mossy_cobblestone
setblock 416 194 221 minecraft:stone_bricks
fill 416 194 222 416 197 222 minecraft:mossy_cobblestone
setblock 417 194 185 minecraft:stone_bricks
fill 417 194 186 417 197 186 minecraft:mossy_cobblestone
setblock 417 194 190 minecraft:stone_bricks
fill 417 194 191 417 197 191 minecraft:mossy_cobblestone
setblock 417 194 195 minecraft:stone_bricks
fill 417 194 196 417 197 196 minecraft:mossy_cobblestone
setblock 417 194 200 minecraft:stone_bricks
fill 417 194 201 417 197 201 minecraft:mossy_cobblestone
fill 417 194 203 417 195 203 minecraft:mossy_cobblestone
setblock 417 194 215 minecraft:stone_bricks
fill 417 194 216 417 197 216 minecraft:mossy_cobblestone
setblock 417 194 220 minecraft:stone_bricks
fill 417 194 221 417 197 221 minecraft:mossy_cobblestone
setblock 377 195 184 minecraft:stone_bricks
fill 377 195 185 377 197 186 minecraft:mossy_cobblestone
setblock 377 195 194 minecraft:stone_bricks
fill 377 195 195 377 198 195 minecraft:mossy_cobblestone
setblock 377 195 199 minecraft:stone_bricks
fill 377 195 200 378 197 200 minecraft:mossy_cobblestone
setblock 377 195 203 minecraft:mossy_cobblestone
setblock 377 195 204 minecraft:stone_bricks
fill 377 195 205 377 197 206 minecraft:mossy_cobblestone
setblock 377 195 209 minecraft:stone_bricks
fill 377 195 210 377 198 210 minecraft:mossy_cobblestone
setblock 377 195 214 minecraft:stone_bricks
fill 377 195 215 377 198 215 minecraft:mossy_cobblestone
setblock 377 195 219 minecraft:stone_bricks
fill 377 195 220 377 198 220 minecraft:mossy_cobblestone
setblock 378 195 198 minecraft:stone_bricks
fill 378 195 199 378 198 199 minecraft:mossy_cobblestone
fill 378 195 201 378 196 201 minecraft:mossy_cobblestone
setblock 378 195 213 minecraft:stone_bricks
fill 378 195 214 378 198 214 minecraft:mossy_cobblestone
setblock 378 195 218 minecraft:stone_bricks
fill 378 195 219 378 198 219 minecraft:mossy_cobblestone
setblock 379 195 182 minecraft:stone_bricks
setblock 379 195 217 minecraft:stone_bricks
fill 379 195 218 379 198 218 minecraft:mossy_cobblestone
setblock 379 195 222 minecraft:stone_bricks
fill 380 195 182 380 198 182 minecraft:mossy_cobblestone
setblock 380 195 221 minecraft:stone_bricks
fill 380 195 222 380 198 222 minecraft:mossy_cobblestone
setblock 381 195 220 minecraft:stone_bricks
fill 381 195 221 381 198 221 minecraft:mossy_cobblestone
setblock 384 195 221 minecraft:mossy_cobblestone
setblock 384 195 222 minecraft:stone_bricks
fill 385 195 222 388 195 222 minecraft:mossy_cobblestone
fill 389 195 211 389 202 211 minecraft:cobbled_deepslate
fill 389 195 213 389 202 213 minecraft:cobbled_deepslate
setblock 389 195 222 minecraft:stone_bricks
setblock 390 195 221 minecraft:stone_bricks
fill 390 195 222 390 198 222 minecraft:mossy_cobblestone
fill 391 195 221 394 195 221 minecraft:mossy_cobblestone
setblock 393 195 182 minecraft:mossy_cobblestone
setblock 393 195 222 minecraft:mossy_cobblestone
setblock 394 195 182 minecraft:stone_bricks
setblock 394 195 222 minecraft:stone_bricks
fill 395 195 182 395 198 182 minecraft:mossy_cobblestone
setblock 395 195 221 minecraft:stone_bricks
fill 395 195 222 395 198 222 minecraft:mossy_cobblestone
fill 396 195 221 396 198 221 minecraft:mossy_cobblestone
fill 398 195 221 398 195 222 minecraft:mossy_cobblestone
setblock 399 195 182 minecraft:stone_bricks
setblock 399 195 222 minecraft:stone_bricks
fill 400 195 182 400 198 182 minecraft:mossy_cobblestone
fill 400 195 222 401 197 222 minecraft:mossy_cobblestone
setblock 408 195 182 minecraft:mossy_cobblestone
setblock 408 195 222 minecraft:mossy_cobblestone
setblock 409 195 182 minecraft:stone_bricks
setblock 409 195 222 minecraft:stone_bricks
fill 410 195 182 410 198 182 minecraft:mossy_cobblestone
setblock 410 195 221 minecraft:stone_bricks
fill 410 195 222 410 198 222 minecraft:mossy_cobblestone
fill 411 195 183 412 195 183 minecraft:mossy_cobblestone
fill 411 195 221 411 198 221 minecraft:mossy_cobblestone
setblock 413 195 183 minecraft:stone_bricks
fill 413 195 220 413 197 220 minecraft:mossy_cobblestone
setblock 414 195 182 minecraft:stone_bricks
fill 414 195 183 414 198 183 minecraft:mossy_cobblestone
setblock 414 195 222 minecraft:stone_bricks
fill 415 195 182 415 198 182 minecraft:mossy_cobblestone
setblock 415 195 195 minecraft:mossy_cobblestone
setblock 415 195 196 minecraft:stone_bricks
fill 415 195 197 415 197 198 minecraft:mossy_cobblestone
fill 415 195 217 415 198 217 minecraft:mossy_cobblestone
setblock 415 195 221 minecraft:stone_bricks
fill 415 195 222 415 198 222 minecraft:mossy_cobblestone
setblock 416 195 185 minecraft:stone_bricks
fill 416 195 186 416 198 186 minecraft:mossy_cobblestone
setblock 416 195 190 minecraft:stone_bricks
fill 416 195 191 416 198 191 minecraft:mossy_cobblestone
setblock 416 195 195 minecraft:stone_bricks
fill 416 195 196 416 198 196 minecraft:mossy_cobblestone
setblock 416 195 200 minecraft:stone_bricks
fill 416 195 201 416 198 201 minecraft:mossy_cobblestone
setblock 416 195 215 minecraft:stone_bricks
fill 416 195 216 416 198 216 minecraft:mossy_cobblestone
setblock 416 195 220 minecraft:stone_bricks
fill 416 195 221 416 198 221 minecraft:mossy_cobblestone
setblock 417 195 184 minecraft:stone_bricks
fill 417 195 185 417 198 185 minecraft:mossy_cobblestone
setblock 417 195 189 minecraft:stone_bricks
fill 417 195 190 417 198 190 minecraft:mossy_cobblestone
setblock 417 195 194 minecraft:stone_bricks
fill 417 195 195 417 198 195 minecraft:mossy_cobblestone
setblock 417 195 199 minecraft:stone_bricks
fill 417 195 200 417 198 200 minecraft:mossy_cobblestone
setblock 417 195 204 minecraft:stone_bricks
fill 417 195 211 417 197 211 minecraft:mossy_cobblestone
setblock 417 195 214 minecraft:stone_bricks
fill 417 195 215 417 198 215 minecraft:mossy_cobblestone
setblock 417 195 219 minecraft:stone_bricks
fill 417 195 220 417 198 220 minecraft:mossy_cobblestone
setblock 377 196 183 minecraft:stone_bricks
fill 377 196 184 377 199 184 minecraft:mossy_cobblestone
setblock 377 196 193 minecraft:stone_bricks
fill 377 196 194 377 198 194 minecraft:mossy_cobblestone
setblock 377 196 197 minecraft:mossy_cobblestone
setblock 377 196 198 minecraft:stone_bricks
fill 377 196 199 377 199 199 minecraft:mossy_cobblestone
setblock 377 196 203 minecraft:stone_bricks
fill 377 196 204 377 199 204 minecraft:mossy_cobblestone
setblock 377 196 207 minecraft:mossy_cobblestone
setblock 377 196 208 minecraft:stone_bricks
fill 377 196 209 377 199 209 minecraft:mossy_cobblestone
setblock 377 196 213 minecraft:stone_bricks
fill 377 196 214 377 199 214 minecraft:mossy_cobblestone
setblock 377 196 218 minecraft:stone_bricks
fill 377 196 219 377 199 219 minecraft:mossy_cobblestone
setblock 378 196 182 minecraft:stone_bricks
setblock 378 196 197 minecraft:stone_bricks
fill 378 196 198 378 199 198 minecraft:mossy_cobblestone
setblock 378 196 202 minecraft:stone_bricks
fill 378 196 203 378 199 203 minecraft:mossy_cobblestone
setblock 378 196 212 minecraft:stone_bricks
fill 378 196 213 378 199 213 minecraft:mossy_cobblestone
setblock 378 196 217 minecraft:stone_bricks
fill 378 196 218 378 199 218 minecraft:mossy_cobblestone
setblock 378 196 222 minecraft:stone_bricks
fill 379 196 182 379 199 182 minecraft:mossy_cobblestone
setblock 379 196 216 minecraft:stone_bricks
fill 379 196 217 379 198 217 minecraft:mossy_cobblestone
setblock 379 196 221 minecraft:stone_bricks
fill 379 196 222 379 199 222 minecraft:mossy_cobblestone
setblock 380 196 220 minecraft:stone_bricks
fill 380 196 221 380 199 221 minecraft:mossy_cobblestone
fill 381 196 220 381 198 220 minecraft:mossy_cobblestone
setblock 383 196 222 minecraft:stone_bricks
setblock 384 196 221 minecraft:stone_bricks
fill 384 196 222 387 196 222 minecraft:mossy_cobblestone
fill 385 196 221 388 196 221 minecraft:mossy_cobblestone
fill 388 196 212 388 202 212 minecraft:cobbled_deepslate
setblock 388 196 222 minecraft:stone_bricks
setblock 389 196 221 minecraft:stone_bricks
fill 389 196 222 389 199 222 minecraft:mossy_cobblestone
fill 390 196 211 390 202 211 minecraft:cobbled_deepslate
fill 390 196 213 390 202 213 minecraft:cobbled_deepslate
fill 390 196 221 393 196 221 minecraft:mossy_cobblestone
fill 391 196 182 392 196 182 minecraft:mossy_cobblestone
fill 391 196 212 391 202 212 minecraft:cobbled_deepslate
fill 392 196 220 394 196 220 minecraft:mossy_cobblestone
setblock 393 196 182 minecraft:stone_bricks
setblock 393 196 222 minecraft:stone_bricks
fill 394 196 182 394 199 182 minecraft:mossy_cobblestone
setblock 394 196 221 minecraft:stone_bricks
fill 394 196 222 394 199 222 minecraft:mossy_cobblestone
setblock 395 196 220 minecraft:stone_bricks
fill 395 196 221 395 199 221 minecraft:mossy_cobblestone
fill 396 196 182 397 196 182 minecraft:mossy_cobblestone
setblock 398 196 182 minecraft:stone_bricks
setblock 398 196 221 minecraft:mossy_cobblestone
setblock 398 196 222 minecraft:stone_bricks
fill 399 196 182 399 199 182 minecraft:mossy_cobblestone
fill 399 196 222 399 199 222 minecraft:mossy_cobblestone
fill 401 196 182 402 196 182 minecraft:mossy_cobblestone
setblock 402 196 222 minecraft:mossy_cobblestone
fill 405 196 182 407 196 182 minecraft:mossy_cobblestone
fill 406 196 222 407 196 222 minecraft:mossy_cobblestone
setblock 408 196 182 minecraft:stone_bricks
setblock 408 196 222 minecraft:stone_bricks
fill 409 196 182 409 198 183 minecraft:mossy_cobblestone
setblock 409 196 221 minecraft:stone_bricks
fill 409 196 222 409 199 222 minecraft:mossy_cobblestone
fill 410 196 183 411 196 183 minecraft:mossy_cobblestone
fill 410 196 221 410 199 221 minecraft:mossy_cobblestone
fill 411 196 220 412 198 220 minecraft:mossy_cobblestone
setblock 412 196 183 minecraft:stone_bricks
setblock 413 196 182 minecraft:stone_bricks
fill 413 196 183 413 198 184 minecraft:mossy_cobblestone
setblock 413 196 222 minecraft:stone_bricks
fill 414 196 182 414 199 182 minecraft:mossy_cobblestone
fill 414 196 184 415 196 184 minecraft:mossy_cobblestone
setblock 414 196 221 minecraft:stone_bricks
fill 414 196 222 414 199 222 minecraft:mossy_cobblestone
setblock 415 196 185 minecraft:stone_bricks
setblock 415 196 195 minecraft:stone_bricks
fill 415 196 196 415 198 196 minecraft:mossy_cobblestone
setblock 415 196 199 minecraft:mossy_cobblestone
setblock 415 196 200 minecraft:stone_bricks
fill 415 196 216 415 198 216 minecraft:mossy_cobblestone
setblock 415 196 219 minecraft:mossy_cobblestone
setblock 415 196 220 minecraft:stone_bricks
fill 415 196 221 415 199 221 minecraft:mossy_cobblestone
setblock 416 196 184 minecraft:stone_bricks
fill 416 196 185 416 199 185 minecraft:mossy_cobblestone
setblock 416 196 189 minecraft:stone_bricks
fill 416 196 190 416 198 190 minecraft:mossy_cobblestone
setblock 416 196 194 minecraft:stone_bricks
fill 416 196 195 416 199 195 minecraft:mossy_cobblestone
setblock 416 196 199 minecraft:stone_bricks
fill 416 196 200 416 199 200 minecraft:mossy_cobblestone
fill 416 196 202 416 197 202 minecraft:mossy_cobblestone
setblock 416 196 214 minecraft:stone_bricks
fill 416 196 215 416 199 215 minecraft:mossy_cobblestone
setblock 416 196 219 minecraft:stone_bricks
fill 416 196 220 416 199 220 minecraft:mossy_cobblestone
setblock 417 196 183 minecraft:stone_bricks
fill 417 196 184 417 199 184 minecraft:mossy_cobblestone
setblock 417 196 188 minecraft:stone_bricks
fill 417 196 189 417 199 189 minecraft:mossy_cobblestone
setblock 417 196 193 minecraft:stone_bricks
fill 417 196 194 417 199 194 minecraft:mossy_cobblestone
setblock 417 196 198 minecraft:stone_bricks
fill 417 196 199 417 199 199 minecraft:mossy_cobblestone
setblock 417 196 203 minecraft:stone_bricks
fill 417 196 204 417 198 205 minecraft:mossy_cobblestone
setblock 417 196 213 minecraft:stone_bricks
fill 417 196 214 417 199 214 minecraft:mossy_cobblestone
setblock 417 196 218 minecraft:stone_bricks
fill 417 196 219 417 199 219 minecraft:mossy_cobblestone
setblock 377 197 182 minecraft:stone_bricks
fill 377 197 183 377 200 183 minecraft:mossy_cobblestone
setblock 377 197 192 minecraft:stone_bricks
fill 377 197 193 377 198 193 minecraft:mossy_cobblestone
setblock 377 197 197 minecraft:stone_bricks
fill 377 197 198 377 200 198 minecraft:mossy_cobblestone
setblock 377 197 202 minecraft:stone_bricks
fill 377 197 203 377 200 203 minecraft:mossy_cobblestone
setblock 377 197 207 minecraft:stone_bricks
fill 377 197 208 377 200 208 minecraft:mossy_cobblestone
setblock 377 197 212 minecraft:stone_bricks
fill 377 197 213 377 200 213 minecraft:mossy_cobblestone
setblock 377 197 217 minecraft:stone_bricks
fill 377 197 218 377 200 218 minecraft:mossy_cobblestone
setblock 377 197 222 minecraft:stone_bricks
fill 378 197 182 378 200 182 minecraft:mossy_cobblestone
fill 378 197 197 378 198 197 minecraft:mossy_cobblestone
setblock 378 197 201 minecraft:stone_bricks
fill 378 197 202 378 200 202 minecraft:mossy_cobblestone
fill 378 197 204 378 197 205 minecraft:mossy_cobblestone
fill 378 197 212 378 198 212 minecraft:mossy_cobblestone
setblock 378 197 216 minecraft:stone_bricks
fill 378 197 217 378 200 217 minecraft:mossy_cobblestone
setblock 378 197 221 minecraft:stone_bricks
fill 378 197 222 378 200 222 minecraft:mossy_cobblestone
setblock 379 197 216 minecraft:mossy_cobblestone
setblock 379 197 220 minecraft:stone_bricks
fill 379 197 221 379 200 221 minecraft:mossy_cobblestone
fill 380 197 220 380 199 220 minecraft:mossy_cobblestone
setblock 381 197 182 minecraft:mossy_cobblestone
setblock 382 197 222 minecraft:stone_bricks
setblock 383 197 221 minecraft:stone_bricks
fill 383 197 222 386 197 222 minecraft:mossy_cobblestone
fill 384 197 221 387 197 221 minecraft:mossy_cobblestone
setblock 387 197 222 minecraft:stone_bricks
fill 388 197 211 388 202 211 minecraft:cobbled_deepslate
fill 388 197 213 388 202 213 minecraft:cobbled_deepslate
setblock 388 197 221 minecraft:stone_bricks
fill 388 197 222 388 200 222 minecraft:mossy_cobblestone
fill 389 197 182 391 197 182 minecraft:mossy_cobblestone
fill 389 197 210 390 202 210 minecraft:cobbled_deepslate
fill 389 197 214 389 202 214 minecraft:cobbled_deepslate
fill 389 197 221 392 197 221 minecraft:mossy_cobblestone
fill 390 197 220 393 197 220 minecraft:mossy_cobblestone
fill 391 197 211 391 202 211 minecraft:cobbled_deepslate
fill 391 197 213 391 202 213 minecraft:cobbled_deepslate
setblock 392 197 182 minecraft:stone_bricks
setblock 392 197 222 minecraft:stone_bricks
fill 393 197 182 393 199 183 minecraft:mossy_cobblestone
setblock 393 197 221 minecraft:stone_bricks
fill 393 197 222 393 200 222 minecraft:mossy_cobblestone
fill 394 197 183 395 197 183 minecraft:mossy_cobblestone
setblock 394 197 220 minecraft:stone_bricks
fill 394 197 221 394 200 221 minecraft:mossy_cobblestone
fill 395 197 220 396 197 220 minecraft:mossy_cobblestone
setblock 396 197 182 minecraft:mossy_cobblestone
setblock 396 197 183 minecraft:stone_bricks
setblock 397 197 182 minecraft:stone_bricks
fill 397 197 183 397 200 183 minecraft:mossy_cobblestone
setblock 397 197 222 minecraft:stone_bricks
fill 398 197 182 398 200 182 minecraft:mossy_cobblestone
setblock 398 197 221 minecraft:stone_bricks
fill 398 197 222 398 200 222 minecraft:mossy_cobblestone
setblock 399 197 221 minecraft:mossy_cobblestone
setblock 401 197 182 minecraft:mossy_cobblestone
setblock 402 197 182 minecraft:stone_bricks
setblock 402 197 222 minecraft:stone_bricks
fill 403 197 182 406 197 182 minecraft:mossy_cobblestone
fill 403 197 222 406 197 222 minecraft:mossy_cobblestone
setblock 407 197 182 minecraft:stone_bricks
fill 407 197 183 408 199 183 minecraft:mossy_cobblestone
setblock 407 197 222 minecraft:stone_bricks
fill 408 197 182 408 200 182 minecraft:mossy_cobblestone
setblock 408 197 221 minecraft:stone_bricks
fill 408 197 222 408 200 222 minecraft:mossy_cobblestone
fill 409 197 221 409 200 221 minecraft:mossy_cobblestone
setblock 410 197 183 minecraft:mossy_cobblestone
fill 410 197 220 410 200 220 minecraft:mossy_cobblestone
setblock 411 197 183 minecraft:stone_bricks
fill 411 197 184 412 199 184 minecraft:mossy_cobblestone
setblock 412 197 182 minecraft:stone_bricks
fill 412 197 183 412 200 183 minecraft:mossy_cobblestone
setblock 412 197 222 minecraft:stone_bricks
fill 413 197 182 413 200 182 minecraft:mossy_cobblestone
setblock 413 197 221 minecraft:stone_bricks
fill 413 197 222 413 200 222 minecraft:mossy_cobblestone
setblock 414 197 184 minecraft:mossy_cobblestone
setblock 414 197 219 minecraft:mossy_cobblestone
setblock 414 197 220 minecraft:stone_bricks
fill 414 197 221 414 200 221 minecraft:mossy_cobblestone
setblock 415 197 184 minecraft:stone_bricks
fill 415 197 185 415 199 186 minecraft:mossy_cobblestone
setblock 415 197 195 minecraft:mossy_cobblestone
setblock 415 197 199 minecraft:stone_bricks
fill 415 197 200 415 199 201 minecraft:mossy_cobblestone
setblock 415 197 219 minecraft:stone_bricks
fill 415 197 220 415 200 220 minecraft:mossy_cobblestone
setblock 416 197 183 minecraft:stone_bricks
fill 416 197 184 416 200 184 minecraft:mossy_cobblestone
setblock 416 197 188 minecraft:stone_bricks
fill 416 197 189 416 198 189 minecraft:mossy_cobblestone
setblock 416 197 193 minecraft:stone_bricks
fill 416 197 194 416 199 194 minecraft:mossy_cobblestone
setblock 416 197 198 minecraft:stone_bricks
fill 416 197 199 416 200 199 minecraft:mossy_cobblestone
setblock 416 197 203 minecraft:stone_bricks
fill 416 197 214 416 199 214 minecraft:mossy_cobblestone
setblock 416 197 218 minecraft:stone_bricks
fill 416 197 219 416 200 219 minecraft:mossy_cobblestone
setblock 417 197 182 minecraft:stone_bricks
fill 417 197 183 417 200 183 minecraft:mossy_cobblestone
setblock 417 197 187 minecraft:stone_bricks
fill 417 197 188 417 200 188 minecraft:mossy_cobblestone
setblock 417 197 192 minecraft:stone_bricks
fill 417 197 193 417 199 193 minecraft:mossy_cobblestone
setblock 417 197 197 minecraft:stone_bricks
fill 417 197 198 417 200 198 minecraft:mossy_cobblestone
setblock 417 197 202 minecraft:stone_bricks
fill 417 197 203 417 200 203 minecraft:mossy_cobblestone
setblock 417 197 206 minecraft:mossy_cobblestone
setblock 417 197 207 minecraft:stone_bricks
setblock 417 197 212 minecraft:stone_bricks
fill 417 197 213 417 200 213 minecraft:mossy_cobblestone
setblock 417 197 217 minecraft:stone_bricks
fill 417 197 218 417 200 218 minecraft:mossy_cobblestone
setblock 417 197 222 minecraft:stone_bricks
fill 377 198 182 377 201 182 minecraft:mossy_cobblestone
setblock 377 198 185 minecraft:mossy_cobblestone
setblock 377 198 186 minecraft:stone_bricks
setblock 377 198 196 minecraft:stone_bricks
fill 377 198 197 377 201 197 minecraft:mossy_cobblestone
setblock 377 198 200 minecraft:mossy_cobblestone
setblock 377 198 201 minecraft:stone_bricks
fill 377 198 202 377 201 202 minecraft:mossy_cobblestone
setblock 377 198 205 minecraft:mossy_cobblestone
setblock 377 198 206 minecraft:stone_bricks
fill 377 198 207 377 201 207 minecraft:mossy_cobblestone
setblock 377 198 211 minecraft:stone_bricks
fill 377 198 212 377 201 212 minecraft:mossy_cobblestone
setblock 377 198 216 minecraft:stone_bricks
fill 377 198 217 377 201 217 minecraft:mossy_cobblestone
setblock 377 198 221 minecraft:stone_bricks
fill 377 198 222 377 201 222 minecraft:mossy_cobblestone
fill 378 198 183 378 199 183 minecraft:mossy_cobblestone
setblock 378 198 200 minecraft:stone_bricks
fill 378 198 201 378 201 201 minecraft:mossy_cobblestone
setblock 378 198 204 minecraft:mossy_cobblestone
setblock 378 198 205 minecraft:stone_bricks
fill 378 198 206 378 201 206 minecraft:mossy_cobblestone
setblock 378 198 215 minecraft:stone_bricks
fill 378 198 216 378 200 216 minecraft:mossy_cobblestone
setblock 378 198 220 minecraft:stone_bricks
fill 378 198 221 378 201 221 minecraft:mossy_cobblestone
setblock 379 198 219 minecraft:stone_bricks
fill 379 198 220 379 200 220 minecraft:mossy_cobblestone
setblock 381 198 182 minecraft:stone_bricks
setblock 381 198 222 minecraft:stone_bricks
setblock 382 198 221 minecraft:stone_bricks
fill 382 198 222 385 198 222 minecraft:mossy_cobblestone
fill 383 198 221 386 198 221 minecraft:mossy_cobblestone
setblock 386 198 222 minecraft:stone_bricks
fill 387 198 182 390 198 182 minecraft:mossy_cobblestone
fill 387 198 212 387 202 212 minecraft:cobbled_deepslate
setblock 387 198 221 minecraft:stone_bricks
fill 387 198 222 387 201 222 minecraft:mossy_cobblestone
fill 388 198 210 388 202 210 minecraft:cobbled_deepslate
fill 388 198 214 388 202 214 minecraft:cobbled_deepslate
fill 388 198 221 391 198 221 minecraft:mossy_cobblestone
fill 389 198 220 392 198 220 minecraft:mossy_cobblestone
fill 390 198 214 390 202 214 minecraft:cobbled_deepslate
setblock 391 198 182 minecraft:stone_bricks
fill 391 198 183 392 200 183 minecraft:mossy_cobblestone
fill 391 198 210 391 202 210 minecraft:cobbled_deepslate
setblock 391 198 222 minecraft:stone_bricks
fill 392 198 182 392 201 182 minecraft:mossy_cobblestone
setblock 392 198 221 minecraft:stone_bricks
fill 392 198 222 392 201 222 minecraft:mossy_cobblestone
setblock 393 198 220 minecraft:stone_bricks
fill 393 198 221 393 201 221 minecraft:mossy_cobblestone
setblock 394 198 183 minecraft:mossy_cobblestone
fill 394 198 220 395 198 220 minecraft:mossy_cobblestone
setblock 395 198 183 minecraft:stone_bricks
setblock 396 198 182 minecraft:stone_bricks
fill 396 198 183 396 201 183 minecraft:mossy_cobblestone
setblock 396 198 222 minecraft:stone_bricks
fill 397 198 182 397 201 182 minecraft:mossy_cobblestone
setblock 397 198 221 minecraft:stone_bricks
fill 397 198 222 397 201 222 minecraft:mossy_cobblestone
fill 398 198 183 399 198 183 minecraft:mossy_cobblestone
fill 398 198 221 398 199 221 minecraft:mossy_cobblestone
setblock 400 198 222 minecraft:mossy_cobblestone
setblock 401 198 182 minecraft:stone_bricks
setblock 401 198 222 minecraft:stone_bricks
fill 402 198 182 405 198 182 minecraft:mossy_cobblestone
fill 402 198 222 405 198 222 minecraft:mossy_cobblestone
setblock 406 198 182 minecraft:stone_bricks
fill 406 198 183 406 201 183 minecraft:mossy_cobblestone
setblock 406 198 222 minecraft:stone_bricks
fill 407 198 182 407 201 182 minecraft:mossy_cobblestone
setblock 407 198 221 minecraft:stone_bricks
fill 407 198 222 407 201 222 minecraft:mossy_cobblestone
fill 408 198 221 408 201 221 minecraft:mossy_cobblestone
setblock 409 198 184 minecraft:stone_bricks
setblock 410 198 183 minecraft:stone_bricks
fill 410 198 184 410 201 184 minecraft:mossy_cobblestone
setblock 411 198 182 minecraft:stone_bricks
fill 411 198 183 411 201 183 minecraft:mossy_cobblestone
setblock 411 198 222 minecraft:stone_bricks
fill 412 198 182 412 201 182 minecraft:mossy_cobblestone
setblock 412 198 221 minecraft:stone_bricks
fill 412 198 222 412 201 222 minecraft:mossy_cobblestone
setblock 413 198 219 minecraft:mossy_cobblestone
setblock 413 198 220 minecraft:stone_bricks
fill 413 198 221 413 201 221 minecraft:mossy_cobblestone
setblock 414 198 184 minecraft:stone_bricks
setblock 414 198 219 minecraft:stone_bricks
fill 414 198 220 414 201 220 minecraft:mossy_cobblestone
setblock 415 198 183 minecraft:stone_bricks
fill 415 198 184 415 201 184 minecraft:mossy_cobblestone
setblock 415 198 197 minecraft:mossy_cobblestone
setblock 415 198 198 minecraft:stone_bricks
fill 415 198 199 415 199 199 minecraft:mossy_cobblestone
setblock 415 198 218 minecraft:stone_bricks
fill 415 198 219 415 201 219 minecraft:mossy_cobblestone
setblock 416 198 182 minecraft:stone_bricks
fill 416 198 183 416 201 183 minecraft:mossy_cobblestone
setblock 416 198 187 minecraft:stone_bricks
fill 416 198 188 416 200 188 minecraft:mossy_cobblestone
setblock 416 198 192 minecraft:stone_bricks
setblock 416 198 193 minecraft:mossy_cobblestone
setblock 416 198 197 minecraft:stone_bricks
fill 416 198 198 416 200 198 minecraft:mossy_cobblestone
setblock 416 198 202 minecraft:stone_bricks
fill 416 198 203 416 200 204 minecraft:mossy_cobblestone
setblock 416 198 217 minecraft:stone_bricks
fill 416 198 218 416 201 218 minecraft:mossy_cobblestone
setblock 416 198 222 minecraft:stone_bricks
fill 417 198 182 417 201 182 minecraft:mossy_cobblestone
setblock 417 198 186 minecraft:stone_bricks
fill 417 198 187 417 201 187 minecraft:mossy_cobblestone
setblock 417 198 191 minecraft:stone_bricks
fill 417 198 192 417 199 192 minecraft:mossy_cobblestone
setblock 417 198 196 minecraft:stone_bricks
fill 417 198 197 417 201 197 minecraft:mossy_cobblestone
setblock 417 198 201 minecraft:stone_bricks
fill 417 198 202 417 201 202 minecraft:mossy_cobblestone
setblock 417 198 206 minecraft:stone_bricks
fill 417 198 207 417 198 210 minecraft:mossy_cobblestone
setblock 417 198 211 minecraft:stone_bricks
fill 417 198 212 417 200 212 minecraft:mossy_cobblestone
setblock 417 198 216 minecraft:stone_bricks
fill 417 198 217 417 201 217 minecraft:mossy_cobblestone
setblock 417 198 221 minecraft:stone_bricks
fill 417 198 222 417 201 222 minecraft:mossy_cobblestone
setblock 377 199 185 minecraft:stone_bricks
fill 377 199 186 377 200 186 minecraft:mossy_cobblestone
setblock 377 199 195 minecraft:stone_bricks
fill 377 199 196 377 200 196 minecraft:mossy_cobblestone
setblock 377 199 200 minecraft:stone_bricks
fill 377 199 201 377 202 201 minecraft:mossy_cobblestone
setblock 377 199 205 minecraft:stone_bricks
fill 377 199 206 377 202 206 minecraft:mossy_cobblestone
setblock 377 199 210 minecraft:stone_bricks
fill 377 199 211 377 202 211 minecraft:mossy_cobblestone
setblock 377 199 215 minecraft:stone_bricks
fill 377 199 216 377 202 216 minecraft:mossy_cobblestone
setblock 377 199 220 minecraft:stone_bricks
fill 377 199 221 377 202 221 minecraft:mossy_cobblestone
setblock 378 199 199 minecraft:stone_bricks
fill 378 199 200 378 201 200 minecraft:mossy_cobblestone
setblock 378 199 204 minecraft:stone_bricks
fill 378 199 205 378 202 205 minecraft:mossy_cobblestone
fill 378 199 207 378 200 207 minecraft:mossy_cobblestone
setblock 378 199 214 minecraft:stone_bricks
fill 378 199 215 378 200 215 minecraft:mossy_cobblestone
setblock 378 199 219 minecraft:stone_bricks
fill 378 199 220 378 202 220 minecraft:mossy_cobblestone
setblock 379 199 218 minecraft:stone_bricks
setblock 379 199 219 minecraft:mossy_cobblestone
setblock 380 199 182 minecraft:stone_bricks
setblock 380 199 222 minecraft:stone_bricks
fill 381 199 182 381 200 182 minecraft:mossy_cobblestone
setblock 381 199 221 minecraft:stone_bricks
fill 381 199 222 384 199 222 minecraft:mossy_cobblestone
fill 382 199 221 385 199 221 minecraft:mossy_cobblestone
setblock 385 199 222 minecraft:stone_bricks
fill 386 199 182 389 199 182 minecraft:mossy_cobblestone
setblock 386 199 221 minecraft:stone_bricks
fill 386 199 222 386 202 222 minecraft:mossy_cobblestone
fill 387 199 211 387 202 211 minecraft:cobbled_deepslate
fill 387 199 213 387 202 213 minecraft:cobbled_deepslate
fill 387 199 221 390 199 221 minecraft:mossy_cobblestone
fill 389 199 209 389 202 209 minecraft:cobbled_deepslate
fill 389 199 220 391 199 220 minecraft:mossy_cobblestone
setblock 390 199 182 minecraft:stone_bricks
fill 390 199 183 390 202 183 minecraft:mossy_cobblestone
setblock 390 199 222 minecraft:stone_bricks
fill 391 199 182 391 202 182 minecraft:mossy_cobblestone
fill 391 199 214 391 202 214 minecraft:cobbled_deepslate
setblock 391 199 221 minecraft:stone_bricks
fill 391 199 222 391 202 222 minecraft:mossy_cobblestone
fill 392 199 211 392 202 213 minecraft:cobbled_deepslate
setblock 392 199 220 minecraft:stone_bricks
fill 392 199 221 392 202 221 minecraft:mossy_cobblestone
fill 393 199 220 394 199 220 minecraft:mossy_cobblestone
setblock 394 199 183 minecraft:stone_bricks
setblock 395 199 182 minecraft:stone_bricks
fill 395 199 183 395 202 183 minecraft:mossy_cobblestone
setblock 395 199 222 minecraft:stone_bricks
fill 396 199 182 396 202 182 minecraft:mossy_cobblestone
setblock 396 199 221 minecraft:stone_bricks
fill 396 199 222 396 202 222 minecraft:mossy_cobblestone
fill 397 199 221 397 200 221 minecraft:mossy_cobblestone
setblock 398 199 183 minecraft:mossy_cobblestone
setblock 399 199 183 minecraft:stone_bricks
setblock 400 199 182 minecraft:stone_bricks
fill 400 199 183 400 202 183 minecraft:mossy_cobblestone
setblock 400 199 222 minecraft:stone_bricks
fill 401 199 182 404 199 182 minecraft:mossy_cobblestone
fill 401 199 222 404 199 222 minecraft:mossy_cobblestone
setblock 404 199 183 minecraft:stone_bricks
setblock 405 199 182 minecraft:stone_bricks
fill 405 199 183 405 202 183 minecraft:mossy_cobblestone
setblock 405 199 222 minecraft:stone_bricks
fill 406 199 182 406 202 182 minecraft:mossy_cobblestone
setblock 406 199 221 minecraft:stone_bricks
fill 406 199 222 406 202 222 minecraft:mossy_cobblestone
fill 407 199 221 407 202 221 minecraft:mossy_cobblestone
setblock 408 199 184 minecraft:stone_bricks
setblock 409 199 182 minecraft:mossy_cobblestone
setblock 409 199 183 minecraft:stone_bricks
fill 409 199 184 409 202 184 minecraft:mossy_cobblestone
fill 409 199 220 409 201 220 minecraft:mossy_cobblestone
setblock 410 199 182 minecraft:stone_bricks
fill 410 199 183 410 202 183 minecraft:mossy_cobblestone
setblock 410 199 222 minecraft:stone_bricks
fill 411 199 182 411 202 182 minecraft:mossy_cobblestone
setblock 411 199 220 minecraft:mossy_cobblestone
setblock 411 199 221 minecraft:stone_bricks
fill 411 199 222 411 202 222 minecraft:mossy_cobblestone
setblock 412 199 220 minecraft:stone_bricks
fill 412 199 221 412 202 221 minecraft:mossy_cobblestone
setblock 413 199 183 minecraft:mossy_cobblestone
setblock 413 199 184 minecraft:stone_bricks
setblock 413 199 219 minecraft:stone_bricks
fill 413 199 220 413 202 220 minecraft:mossy_cobblestone
setblock 414 199 183 minecraft:stone_bricks
fill 414 199 184 414 202 184 minecraft:mossy_cobblestone
fill 414 199 219 414 200 219 minecraft:mossy_cobblestone
setblock 415 199 182 minecraft:stone_bricks
fill 415 199 183 415 202 183 minecraft:mossy_cobblestone
setblock 415 199 198 minecraft:mossy_cobblestone
setblock 415 199 217 minecraft:stone_bricks
fill 415 199 218 415 201 218 minecraft:mossy_cobblestone
setblock 415 199 222 minecraft:stone_bricks
fill 416 199 182 416 202 182 minecraft:mossy_cobblestone
setblock 416 199 186 minecraft:stone_bricks
fill 416 199 187 416 201 187 minecraft:mossy_cobblestone
setblock 416 199 196 minecraft:stone_bricks
fill 416 199 197 416 200 197 minecraft:mossy_cobblestone
setblock 416 199 201 minecraft:stone_bricks
fill 416 199 202 416 201 202 minecraft:mossy_cobblestone
setblock 416 199 205 minecraft:mossy_cobblestone
setblock 416 199 216 minecraft:stone_bricks
fill 416 199 217 416 202 217 minecraft:mossy_cobblestone
setblock 416 199 221 minecraft:stone_bricks
fill 416 199 222 416 202 222 minecraft:mossy_cobblestone
setblock 417 199 185 minecraft:stone_bricks
fill 417 199 186 417 202 186 minecraft:mossy_cobblestone
setblock 417 199 190 minecraft:stone_bricks
setblock 417 199 191 minecraft:mossy_cobblestone
setblock 417 199 195 minecraft:stone_bricks
fill 417 199 196 417 200 196 minecraft:mossy_cobblestone
setblock 417 199 200 minecraft:stone_bricks
fill 417 199 201 417 202 201 minecraft:mossy_cobblestone
setblock 417 199 204 minecraft:mossy_cobblestone
setblock 417 199 205 minecraft:stone_bricks
fill 417 199 206 417 199 209 minecraft:mossy_cobblestone
setblock 417 199 210 minecraft:stone_bricks
fill 417 199 211 417 200 211 minecraft:mossy_cobblestone
setblock 417 199 215 minecraft:stone_bricks
fill 417 199 216 417 202 216 minecraft:mossy_cobblestone
setblock 417 199 220 minecraft:stone_bricks
fill 417 199 221 417 202 221 minecraft:mossy_cobblestone
setblock 377 200 184 minecraft:stone_bricks
fill 377 200 185 377 202 185 minecraft:mossy_cobblestone
setblock 377 200 199 minecraft:stone_bricks
fill 377 200 200 377 203 200 minecraft:mossy_cobblestone
setblock 377 200 204 minecraft:stone_bricks
fill 377 200 205 377 203 205 minecraft:mossy_cobblestone
setblock 377 200 209 minecraft:stone_bricks
fill 377 200 210 377 203 210 minecraft:mossy_cobblestone
setblock 377 200 214 minecraft:stone_bricks
fill 377 200 215 377 203 215 minecraft:mossy_cobblestone
setblock 377 200 219 minecraft:stone_bricks
fill 377 200 220 377 203 220 minecraft:mossy_cobblestone
setblock 378 200 199 minecraft:mossy_cobblestone
setblock 378 200 203 minecraft:stone_bricks
fill 378 200 204 378 203 204 minecraft:mossy_cobblestone
setblock 378 200 208 minecraft:stone_bricks
setblock 378 200 218 minecraft:stone_bricks
fill 378 200 219 378 202 219 minecraft:mossy_cobblestone
setblock 379 200 182 minecraft:stone_bricks
setblock 379 200 222 minecraft:stone_bricks
fill 380 200 182 380 201 182 minecraft:mossy_cobblestone
setblock 380 200 221 minecraft:stone_bricks
fill 380 200 222 383 200 222 minecraft:mossy_cobblestone
fill 381 200 221 384 200 221 minecraft:mossy_cobblestone
setblock 384 200 222 minecraft:stone_bricks
fill 385 200 182 388 200 182 minecraft:mossy_cobblestone
setblock 385 200 221 minecraft:stone_bricks
fill 385 200 222 385 203 222 minecraft:mossy_cobblestone
fill 386 200 212 386 202 212 minecraft:cobbled_deepslate
fill 386 200 221 389 200 221 minecraft:mossy_cobblestone
fill 387 200 210 387 202 210 minecraft:cobbled_deepslate
fill 387 200 214 387 202 214 minecraft:cobbled_deepslate
fill 388 200 209 388 202 209 minecraft:cobbled_deepslate
fill 388 200 215 391 202 215 minecraft:cobbled_deepslate
setblock 389 200 182 minecraft:stone_bricks
fill 389 200 183 389 203 183 minecraft:mossy_cobblestone
setblock 389 200 222 minecraft:stone_bricks
fill 390 200 182 390 203 182 minecraft:mossy_cobblestone
fill 390 200 209 391 202 209 minecraft:cobbled_deepslate
setblock 390 200 220 minecraft:mossy_cobblestone
setblock 390 200 221 minecraft:stone_bricks
fill 390 200 222 390 203 222 minecraft:mossy_cobblestone
setblock 391 200 220 minecraft:stone_bricks
fill 391 200 221 391 203 221 minecraft:mossy_cobblestone
fill 392 200 210 392 202 210 minecraft:cobbled_deepslate
fill 392 200 214 392 202 214 minecraft:cobbled_deepslate
fill 392 200 220 393 200 220 minecraft:mossy_cobblestone
setblock 393 200 182 minecraft:mossy_cobblestone
setblock 393 200 183 minecraft:stone_bricks
setblock 394 200 182 minecraft:stone_bricks
fill 394 200 183 394 203 183 minecraft:mossy_cobblestone
setblock 394 200 222 minecraft:stone_bricks
fill 395 200 182 395 203 182 minecraft:mossy_cobblestone
setblock 395 200 221 minecraft:stone_bricks
fill 395 200 222 395 203 222 minecraft:mossy_cobblestone
setblock 396 200 221 minecraft:mossy_cobblestone
setblock 398 200 183 minecraft:stone_bricks
setblock 399 200 182 minecraft:stone_bricks
fill 399 200 183 399 202 183 minecraft:mossy_cobblestone
setblock 399 200 222 minecraft:stone_bricks
fill 400 200 182 403 200 182 minecraft:mossy_cobblestone
fill 400 200 222 403 200 222 minecraft:mossy_cobblestone
fill 401 200 183 402 200 183 minecraft:mossy_cobblestone
setblock 403 200 183 minecraft:stone_bricks
setblock 404 200 182 minecraft:stone_bricks
fill 404 200 183 404 203 183 minecraft:mossy_cobblestone
setblock 404 200 222 minecraft:stone_bricks
fill 405 200 182 405 203 182 minecraft:mossy_cobblestone
fill 405 200 222 405 203 222 minecraft:mossy_cobblestone
fill 406 200 221 406 201 221 minecraft:mossy_cobblestone
setblock 407 200 183 minecraft:mossy_cobblestone
setblock 407 200 184 minecraft:stone_bricks
setblock 408 200 183 minecraft:stone_bricks
fill 408 200 184 408 203 184 minecraft:mossy_cobblestone
setblock 409 200 182 minecraft:stone_bricks
fill 409 200 183 409 203 183 minecraft:mossy_cobblestone
setblock 409 200 222 minecraft:stone_bricks
fill 410 200 182 410 203 182 minecraft:mossy_cobblestone
setblock 410 200 221 minecraft:stone_bricks
fill 410 200 222 410 203 222 minecraft:mossy_cobblestone
setblock 411 200 184 minecraft:mossy_cobblestone
setblock 411 200 185 minecraft:stone_bricks
setblock 411 200 220 minecraft:stone_bricks
fill 411 200 221 411 203 221 minecraft:mossy_cobblestone
setblock 412 200 184 minecraft:stone_bricks
fill 412 200 185 413 201 185 minecraft:mossy_cobblestone
fill 412 200 220 412 203 220 minecraft:mossy_cobblestone
setblock 413 200 183 minecraft:stone_bricks
fill 413 200 184 413 203 184 minecraft:mossy_cobblestone
setblock 414 200 182 minecraft:stone_bricks
fill 414 200 183 414 203 183 minecraft:mossy_cobblestone
setblock 414 200 222 minecraft:stone_bricks
fill 415 200 182 415 203 182 minecraft:mossy_cobblestone
setblock 415 200 185 minecraft:mossy_cobblestone
setblock 415 200 186 minecraft:stone_bricks
setblock 415 200 217 minecraft:mossy_cobblestone
setblock 415 200 221 minecraft:stone_bricks
fill 415 200 222 415 203 222 minecraft:mossy_cobblestone
setblock 416 200 185 minecraft:stone_bricks
fill 416 200 186 416 203 186 minecraft:mossy_cobblestone
setblock 416 200 200 minecraft:stone_bricks
fill 416 200 201 416 201 201 minecraft:mossy_cobblestone
setblock 416 200 205 minecraft:stone_bricks
setblock 416 200 215 minecraft:stone_bricks
fill 416 200 216 416 201 216 minecraft:mossy_cobblestone
setblock 416 200 220 minecraft:stone_bricks
fill 416 200 221 416 203 221 minecraft:mossy_cobblestone
setblock 417 200 184 minecraft:stone_bricks
fill 417 200 185 417 203 185 minecraft:mossy_cobblestone
setblock 417 200 189 minecraft:stone_bricks
setblock 417 200 190 minecraft:mossy_cobblestone
setblock 417 200 194 minecraft:stone_bricks
setblock 417 200 195 minecraft:mossy_cobblestone
setblock 417 200 199 minecraft:stone_bricks
fill 417 200 200 417 202 200 minecraft:mossy_cobblestone
setblock 417 200 204 minecraft:stone_bricks
fill 417 200 205 417 200 208 minecraft:mossy_cobblestone
setblock 417 200 209 minecraft:stone_bricks
setblock 417 200 210 minecraft:mossy_cobblestone
setblock 417 200 214 minecraft:stone_bricks
fill 417 200 215 417 202 215 minecraft:mossy_cobblestone
setblock 417 200 219 minecraft:stone_bricks
fill 417 200 220 417 203 220 minecraft:mossy_cobblestone
setblock 377 201 183 minecraft:stone_bricks
fill 377 201 184 377 203 184 minecraft:mossy_cobblestone
setblock 377 201 198 minecraft:stone_bricks
fill 377 201 199 377 202 199 minecraft:mossy_cobblestone
setblock 377 201 203 minecraft:stone_bricks
fill 377 201 204 377 204 204 minecraft:mossy_cobblestone
setblock 377 201 208 minecraft:stone_bricks
fill 377 201 209 377 204 209 minecraft:mossy_cobblestone
setblock 377 201 213 minecraft:stone_bricks
fill 377 201 214 377 203 214 minecraft:mossy_cobblestone
setblock 377 201 218 minecraft:stone_bricks
schedule function dropper:buildpart/44_9 1t
