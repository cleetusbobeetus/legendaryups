setblock 95 189 346 minecraft:stripped_spruce_log
fill 95 189 347 95 192 347 minecraft:stone
fill 95 189 349 95 190 349 minecraft:stone
setblock 95 189 360 minecraft:stone
setblock 95 189 361 minecraft:stripped_spruce_log
fill 95 189 362 95 191 363 minecraft:stone
fill 96 189 323 97 189 323 minecraft:stone
setblock 96 189 325 minecraft:stripped_spruce_log
fill 96 189 326 96 192 326 minecraft:stone
setblock 96 189 330 minecraft:stripped_spruce_log
fill 96 189 363 97 189 363 minecraft:stone
setblock 97 189 324 minecraft:stripped_spruce_log
fill 97 189 325 97 192 325 minecraft:stone
setblock 97 189 328 minecraft:stone
fill 97 189 362 98 189 362 minecraft:stone
setblock 98 189 323 minecraft:stripped_spruce_log
fill 98 189 324 98 192 324 minecraft:stone
setblock 98 189 363 minecraft:stripped_spruce_log
fill 99 189 323 99 192 323 minecraft:stone
setblock 99 189 362 minecraft:stripped_spruce_log
fill 99 189 363 102 189 363 minecraft:stone
fill 100 189 362 103 189 362 minecraft:stone
setblock 101 189 325 minecraft:stripped_spruce_log
setblock 102 189 324 minecraft:stripped_spruce_log
setblock 103 189 323 minecraft:stripped_spruce_log
fill 103 189 324 103 191 324 minecraft:stone
setblock 103 189 363 minecraft:stripped_spruce_log
fill 104 189 323 104 192 323 minecraft:stone
setblock 104 189 362 minecraft:stripped_spruce_log
fill 104 189 363 107 189 363 minecraft:stone
setblock 108 189 363 minecraft:stripped_spruce_log
fill 112 189 329 114 189 331 minecraft:raw_gold_block
setblock 112 189 363 minecraft:stone
setblock 113 189 363 minecraft:stripped_spruce_log
fill 114 189 323 114 192 323 minecraft:stone
fill 114 189 363 117 189 363 minecraft:stone
fill 117 189 325 117 195 325 minecraft:stripped_spruce_log
setblock 118 189 323 minecraft:stripped_spruce_log
fill 118 189 324 118 192 324 minecraft:stone
setblock 118 189 363 minecraft:stripped_spruce_log
fill 119 189 323 119 192 323 minecraft:stone
fill 119 189 363 119 192 363 minecraft:stone
setblock 123 189 323 minecraft:stripped_spruce_log
fill 124 189 323 125 189 323 minecraft:stone
fill 130 189 323 130 191 323 minecraft:stone
setblock 133 189 323 minecraft:stripped_spruce_log
fill 133 189 324 133 192 324 minecraft:stone
fill 134 189 323 134 192 323 minecraft:stone
fill 134 189 325 134 189 326 minecraft:stone
setblock 134 189 327 minecraft:stripped_spruce_log
fill 134 189 328 134 191 329 minecraft:stone
setblock 135 189 325 minecraft:stone
setblock 135 189 326 minecraft:stripped_spruce_log
fill 135 189 327 135 192 327 minecraft:stone
setblock 135 189 331 minecraft:stripped_spruce_log
fill 135 189 332 135 192 332 minecraft:stone
setblock 135 189 336 minecraft:stripped_spruce_log
fill 135 189 337 135 192 337 minecraft:stone
setblock 135 189 341 minecraft:stripped_spruce_log
fill 135 189 342 135 192 342 minecraft:stone
setblock 135 189 346 minecraft:stripped_spruce_log
fill 135 189 347 135 192 347 minecraft:stone
fill 135 189 349 135 190 349 minecraft:stone
fill 94 190 329 94 238 329 minecraft:andesite
fill 94 190 358 94 237 359 minecraft:andesite
setblock 94 190 360 minecraft:gold_block
fill 94 190 361 94 242 361 minecraft:andesite
fill 95 190 323 95 190 324 minecraft:stone
setblock 95 190 325 minecraft:stripped_spruce_log
fill 95 190 326 95 192 326 minecraft:stone
setblock 95 190 330 minecraft:stripped_spruce_log
fill 95 190 331 95 192 331 minecraft:stone
fill 95 190 333 95 191 333 minecraft:stone
setblock 95 190 345 minecraft:stripped_spruce_log
fill 95 190 346 95 192 346 minecraft:stone
setblock 95 190 350 minecraft:stripped_spruce_log
fill 95 190 351 95 192 352 minecraft:stone
setblock 95 190 360 minecraft:stripped_spruce_log
fill 95 190 361 96 192 361 minecraft:stone
setblock 96 190 323 minecraft:stone
fill 96 190 325 96 192 325 minecraft:stone
setblock 96 190 329 minecraft:stripped_spruce_log
fill 96 190 330 96 192 330 minecraft:stone
fill 96 190 347 96 190 348 minecraft:stone
setblock 96 190 363 minecraft:stone
setblock 97 190 323 minecraft:stripped_spruce_log
fill 97 190 324 97 192 324 minecraft:stone
setblock 97 190 328 minecraft:stripped_spruce_log
setblock 97 190 362 minecraft:stone
setblock 97 190 363 minecraft:stripped_spruce_log
fill 98 190 323 98 192 323 minecraft:stone
setblock 98 190 362 minecraft:stripped_spruce_log
fill 98 190 363 101 190 363 minecraft:stone
fill 99 190 362 102 190 362 minecraft:stone
setblock 100 190 325 minecraft:stripped_spruce_log
setblock 101 190 324 minecraft:stripped_spruce_log
fill 101 190 325 101 191 325 minecraft:stone
setblock 102 190 323 minecraft:stripped_spruce_log
fill 102 190 324 102 192 324 minecraft:stone
setblock 102 190 363 minecraft:stripped_spruce_log
fill 103 190 323 103 192 323 minecraft:stone
fill 103 190 363 106 190 363 minecraft:stone
setblock 111 190 364 minecraft:diamond_block
fill 113 190 363 116 190 363 minecraft:stone
setblock 116 190 322 minecraft:raw_gold_block
setblock 117 190 323 minecraft:stripped_spruce_log
fill 117 190 324 117 192 324 minecraft:stone
setblock 117 190 363 minecraft:stripped_spruce_log
fill 118 190 323 118 192 323 minecraft:stone
fill 118 190 363 118 192 363 minecraft:stone
setblock 121 190 324 minecraft:stripped_spruce_log
setblock 122 190 323 minecraft:stripped_spruce_log
fill 123 190 323 124 191 323 minecraft:stone
setblock 132 190 323 minecraft:stripped_spruce_log
fill 132 190 324 132 192 324 minecraft:stone
fill 133 190 323 133 192 323 minecraft:stone
setblock 134 190 325 minecraft:stone
setblock 134 190 326 minecraft:stripped_spruce_log
fill 134 190 327 134 192 327 minecraft:stone
setblock 134 190 330 minecraft:stone
setblock 134 190 331 minecraft:stripped_spruce_log
setblock 135 190 325 minecraft:stripped_spruce_log
fill 135 190 326 135 192 326 minecraft:stone
setblock 135 190 330 minecraft:stripped_spruce_log
fill 135 190 331 135 192 331 minecraft:stone
setblock 135 190 335 minecraft:stripped_spruce_log
fill 135 190 336 135 192 336 minecraft:stone
setblock 135 190 340 minecraft:stripped_spruce_log
fill 135 190 341 135 192 341 minecraft:stone
setblock 135 190 345 minecraft:stripped_spruce_log
fill 135 190 346 135 192 346 minecraft:stone
setblock 135 190 350 minecraft:stripped_spruce_log
setblock 136 190 345 minecraft:raw_iron_block
fill 136 190 346 136 241 347 minecraft:andesite
fill 136 190 356 136 200 361 minecraft:andesite
setblock 136 190 362 minecraft:diamond_block
fill 94 191 360 94 200 360 minecraft:andesite
setblock 95 191 323 minecraft:stone
setblock 95 191 324 minecraft:stripped_spruce_log
fill 95 191 325 95 192 325 minecraft:stone
setblock 95 191 329 minecraft:stripped_spruce_log
fill 95 191 330 95 192 330 minecraft:stone
fill 95 191 342 95 192 342 minecraft:stone
setblock 95 191 344 minecraft:stripped_spruce_log
fill 95 191 345 95 192 345 minecraft:stone
setblock 95 191 349 minecraft:stripped_spruce_log
fill 95 191 350 96 192 350 minecraft:stone
setblock 95 191 353 minecraft:stone
setblock 95 191 354 minecraft:stripped_spruce_log
fill 95 191 355 95 191 358 minecraft:stone
setblock 95 191 359 minecraft:stripped_spruce_log
fill 95 191 360 95 192 360 minecraft:stone
setblock 96 191 323 minecraft:stripped_spruce_log
setblock 96 191 324 minecraft:glowstone
setblock 96 191 328 minecraft:stripped_spruce_log
fill 96 191 329 97 192 329 minecraft:stone
fill 96 191 331 96 192 331 minecraft:stone
setblock 96 191 343 minecraft:glowstone
fill 96 191 346 96 191 347 minecraft:stone
setblock 96 191 348 minecraft:stripped_spruce_log
fill 96 191 349 96 192 349 minecraft:stone
fill 96 191 351 96 192 351 minecraft:stone
setblock 96 191 362 minecraft:glowstone
setblock 96 191 363 minecraft:stripped_spruce_log
fill 97 191 323 97 192 323 minecraft:stone
setblock 97 191 327 minecraft:stripped_spruce_log
fill 97 191 328 97 194 328 minecraft:stone
setblock 97 191 362 minecraft:stripped_spruce_log
fill 97 191 363 100 191 363 minecraft:stone
fill 98 191 362 101 191 362 minecraft:stone
setblock 99 191 325 minecraft:stripped_spruce_log
setblock 100 191 324 minecraft:stripped_spruce_log
fill 100 191 325 100 194 325 minecraft:stone
setblock 101 191 323 minecraft:stripped_spruce_log
fill 101 191 324 101 192 324 minecraft:stone
setblock 101 191 363 minecraft:stripped_spruce_log
fill 102 191 323 102 192 323 minecraft:stone
setblock 102 191 362 minecraft:stripped_spruce_log
fill 102 191 363 105 191 363 minecraft:stone
fill 111 191 364 111 201 364 minecraft:andesite
fill 113 191 323 113 192 323 minecraft:stone
fill 113 191 363 115 191 363 minecraft:stone
setblock 115 191 324 minecraft:glowstone
setblock 115 191 362 minecraft:glowstone
fill 116 191 322 116 237 322 minecraft:andesite
setblock 116 191 323 minecraft:stripped_spruce_log
fill 116 191 324 116 192 324 minecraft:stone
setblock 116 191 363 minecraft:stripped_spruce_log
fill 117 191 323 117 192 323 minecraft:stone
fill 117 191 363 117 192 363 minecraft:stone
setblock 120 191 324 minecraft:stripped_spruce_log
setblock 121 191 323 minecraft:stripped_spruce_log
fill 122 191 323 122 192 323 minecraft:stone
fill 129 191 323 129 192 323 minecraft:stone
setblock 131 191 323 minecraft:stripped_spruce_log
fill 131 191 324 131 192 324 minecraft:stone
fill 132 191 323 132 192 323 minecraft:stone
setblock 133 191 325 minecraft:stone
setblock 133 191 326 minecraft:stripped_spruce_log
fill 133 191 327 133 193 328 minecraft:stone
setblock 134 191 324 minecraft:glowstone
setblock 134 191 325 minecraft:stripped_spruce_log
fill 134 191 326 134 192 326 minecraft:stone
setblock 134 191 330 minecraft:stripped_spruce_log
fill 134 191 331 134 192 332 minecraft:stone
setblock 134 191 343 minecraft:glowstone
fill 134 191 346 134 192 346 minecraft:stone
setblock 134 191 362 minecraft:glowstone
setblock 135 191 324 minecraft:stripped_spruce_log
fill 135 191 325 135 192 325 minecraft:stone
setblock 135 191 329 minecraft:stripped_spruce_log
fill 135 191 330 135 192 330 minecraft:stone
setblock 135 191 334 minecraft:stripped_spruce_log
fill 135 191 335 135 192 335 minecraft:stone
setblock 135 191 339 minecraft:stripped_spruce_log
fill 135 191 340 135 192 340 minecraft:stone
setblock 135 191 344 minecraft:stripped_spruce_log
fill 135 191 345 135 192 345 minecraft:stone
setblock 135 191 349 minecraft:stripped_spruce_log
fill 135 191 350 135 192 352 minecraft:stone
setblock 136 191 344 minecraft:diamond_block
fill 136 191 345 136 205 345 minecraft:andesite
fill 136 191 362 136 215 362 minecraft:andesite
setblock 94 192 323 minecraft:diamond_block
fill 94 192 330 94 194 335 minecraft:andesite
setblock 94 192 336 minecraft:gold_block
fill 94 192 337 94 212 338 minecraft:andesite
setblock 95 192 323 minecraft:stripped_spruce_log
setblock 95 192 324 minecraft:stone
setblock 95 192 328 minecraft:stripped_spruce_log
setblock 95 192 329 minecraft:stone
setblock 95 192 333 minecraft:stripped_spruce_log
fill 95 192 334 95 192 335 minecraft:stone
setblock 95 192 343 minecraft:stripped_spruce_log
setblock 95 192 344 minecraft:stone
setblock 95 192 348 minecraft:stripped_spruce_log
setblock 95 192 349 minecraft:stone
setblock 95 192 353 minecraft:stripped_spruce_log
fill 95 192 354 95 192 357 minecraft:stone
setblock 95 192 358 minecraft:stripped_spruce_log
setblock 95 192 359 minecraft:stone
setblock 95 192 362 minecraft:stone
setblock 95 192 363 minecraft:stripped_spruce_log
setblock 96 192 323 minecraft:stone
fill 96 192 324 96 193 324 minecraft:spruce_log
setblock 96 192 327 minecraft:stripped_spruce_log
setblock 96 192 328 minecraft:stone
setblock 96 192 332 minecraft:stripped_spruce_log
fill 96 192 343 96 193 343 minecraft:spruce_log
fill 96 192 345 96 192 346 minecraft:stone
setblock 96 192 347 minecraft:stripped_spruce_log
setblock 96 192 348 minecraft:stone
setblock 96 192 352 minecraft:stripped_spruce_log
fill 96 192 353 96 192 355 minecraft:stone
setblock 96 192 360 minecraft:stone
fill 96 192 362 96 193 362 minecraft:spruce_log
fill 96 192 363 99 192 363 minecraft:stone
setblock 97 192 326 minecraft:stripped_spruce_log
fill 97 192 327 97 195 327 minecraft:stone
setblock 97 192 330 minecraft:stone
setblock 97 192 332 minecraft:light[level=12]
setblock 97 192 339 minecraft:light[level=12]
setblock 97 192 346 minecraft:light[level=12]
setblock 97 192 353 minecraft:light[level=12]
setblock 97 192 360 minecraft:light[level=12]
fill 97 192 362 100 192 362 minecraft:stone
setblock 98 192 325 minecraft:stripped_spruce_log
setblock 99 192 324 minecraft:stripped_spruce_log
fill 99 192 325 99 195 325 minecraft:stone
setblock 100 192 323 minecraft:stripped_spruce_log
setblock 100 192 324 minecraft:stone
setblock 100 192 363 minecraft:stripped_spruce_log
setblock 101 192 323 minecraft:stone
setblock 101 192 362 minecraft:stripped_spruce_log
fill 101 192 363 104 192 363 minecraft:stone
setblock 104 192 325 minecraft:light[level=12]
setblock 104 192 332 minecraft:light[level=12]
setblock 104 192 339 minecraft:light[level=12]
setblock 104 192 346 minecraft:light[level=12]
setblock 104 192 353 minecraft:light[level=12]
setblock 104 192 360 minecraft:light[level=12]
setblock 105 192 323 minecraft:stripped_spruce_log
setblock 105 192 363 minecraft:stripped_spruce_log
setblock 111 192 325 minecraft:light[level=12]
setblock 111 192 332 minecraft:light[level=12]
setblock 111 192 339 minecraft:light[level=12]
setblock 111 192 346 minecraft:light[level=12]
setblock 111 192 353 minecraft:light[level=12]
setblock 111 192 360 minecraft:light[level=12]
setblock 112 192 323 minecraft:stone
fill 113 192 363 114 192 363 minecraft:stone
setblock 113 192 364 minecraft:raw_iron_block
fill 114 192 364 114 209 364 minecraft:andesite
setblock 115 192 323 minecraft:stripped_spruce_log
fill 115 192 324 115 193 324 minecraft:spruce_log
fill 115 192 362 115 193 362 minecraft:spruce_log
setblock 115 192 363 minecraft:stripped_spruce_log
setblock 116 192 323 minecraft:stone
setblock 116 192 363 minecraft:stone
setblock 118 192 325 minecraft:light[level=12]
setblock 118 192 332 minecraft:light[level=12]
setblock 118 192 339 minecraft:light[level=12]
setblock 118 192 346 minecraft:light[level=12]
setblock 118 192 353 minecraft:light[level=12]
setblock 118 192 360 minecraft:light[level=12]
setblock 119 192 324 minecraft:stripped_spruce_log
setblock 120 192 323 minecraft:stripped_spruce_log
setblock 120 192 324 minecraft:stone
setblock 121 192 323 minecraft:stone
setblock 123 192 323 minecraft:stone
setblock 125 192 325 minecraft:light[level=12]
setblock 125 192 332 minecraft:light[level=12]
setblock 125 192 339 minecraft:light[level=12]
setblock 125 192 346 minecraft:light[level=12]
setblock 125 192 353 minecraft:light[level=12]
setblock 125 192 360 minecraft:light[level=12]
fill 129 192 343 133 193 343 minecraft:stripped_spruce_log
setblock 130 192 323 minecraft:stripped_spruce_log
setblock 131 192 323 minecraft:stone
setblock 132 192 325 minecraft:stone
setblock 132 192 332 minecraft:light[level=12]
setblock 132 192 339 minecraft:light[level=12]
setblock 132 192 346 minecraft:light[level=12]
setblock 132 192 353 minecraft:light[level=12]
setblock 132 192 360 minecraft:light[level=12]
setblock 133 192 325 minecraft:stripped_spruce_log
fill 133 192 326 133 195 326 minecraft:stone
setblock 133 192 329 minecraft:stone
setblock 133 192 330 minecraft:stripped_spruce_log
fill 134 192 324 134 193 324 minecraft:spruce_log
setblock 134 192 325 minecraft:stone
setblock 134 192 328 minecraft:stone
setblock 134 192 329 minecraft:stripped_spruce_log
setblock 134 192 330 minecraft:stone
setblock 134 192 333 minecraft:stone
setblock 134 192 334 minecraft:stripped_spruce_log
setblock 134 192 342 minecraft:stripped_spruce_log
fill 134 192 343 134 193 343 minecraft:spruce_log
setblock 134 192 345 minecraft:stone
fill 134 192 347 134 192 348 minecraft:stone
setblock 134 192 349 minecraft:stripped_spruce_log
fill 134 192 362 134 193 362 minecraft:spruce_log
setblock 134 192 363 minecraft:stone
fill 134 192 364 134 241 364 minecraft:andesite
setblock 135 192 323 minecraft:stripped_spruce_log
setblock 135 192 324 minecraft:stone
setblock 135 192 328 minecraft:stripped_spruce_log
setblock 135 192 329 minecraft:stone
setblock 135 192 333 minecraft:stripped_spruce_log
setblock 135 192 334 minecraft:stone
setblock 135 192 338 minecraft:stripped_spruce_log
setblock 135 192 339 minecraft:stone
setblock 135 192 343 minecraft:stripped_spruce_log
setblock 135 192 344 minecraft:stone
setblock 135 192 348 minecraft:stripped_spruce_log
setblock 135 192 349 minecraft:stone
setblock 135 192 353 minecraft:stripped_spruce_log
setblock 135 192 362 minecraft:stone
setblock 135 192 363 minecraft:stripped_spruce_log
setblock 135 192 364 minecraft:raw_gold_block
setblock 136 192 323 minecraft:gold_block
fill 136 192 324 136 241 324 minecraft:andesite
fill 136 192 344 136 241 344 minecraft:andesite
fill 94 193 323 94 238 323 minecraft:andesite
fill 94 193 336 94 238 336 minecraft:andesite
fill 95 193 323 95 193 363 minecraft:spruce_planks
fill 96 193 323 135 193 323 minecraft:spruce_planks
fill 96 193 325 96 193 342 minecraft:spruce_planks
fill 96 193 344 96 193 361 minecraft:spruce_planks
fill 96 193 363 135 193 363 minecraft:spruce_planks
fill 97 193 324 114 193 324 minecraft:spruce_planks
setblock 97 193 325 minecraft:stripped_spruce_log
fill 97 193 326 98 193 326 minecraft:stone
setblock 97 193 329 minecraft:stone
setblock 97 193 330 minecraft:stripped_spruce_log
fill 97 193 348 97 193 349 minecraft:stone
setblock 97 193 350 minecraft:stripped_spruce_log
fill 97 193 351 97 194 353 minecraft:stone
fill 97 193 362 114 193 362 minecraft:spruce_planks
fill 98 193 325 98 196 325 minecraft:stone
fill 99 193 327 99 196 327 minecraft:cobbled_deepslate
fill 100 193 326 100 196 326 minecraft:cobbled_deepslate
fill 113 193 364 113 241 364 minecraft:andesite
setblock 115 193 322 minecraft:raw_gold_block
fill 115 193 345 120 194 345 minecraft:stripped_spruce_log
fill 116 193 324 133 193 324 minecraft:spruce_planks
fill 116 193 362 133 193 362 minecraft:spruce_planks
fill 117 193 344 130 193 344 minecraft:stripped_spruce_log
setblock 123 193 343 minecraft:stripped_spruce_log
fill 127 193 343 128 193 343 minecraft:stripped_spruce_log
setblock 132 193 325 minecraft:stripped_spruce_log
fill 132 193 342 133 193 342 minecraft:stripped_spruce_log
fill 133 193 325 133 196 325 minecraft:stone
setblock 133 193 329 minecraft:stripped_spruce_log
fill 133 193 330 133 194 332 minecraft:stone
fill 133 193 355 133 196 357 minecraft:raw_gold_block
fill 134 193 325 135 193 342 minecraft:spruce_planks
fill 134 193 344 135 193 361 minecraft:spruce_planks
setblock 135 193 324 minecraft:spruce_planks
setblock 135 193 343 minecraft:spruce_planks
setblock 135 193 362 minecraft:spruce_planks
fill 135 193 364 135 241 364 minecraft:andesite
fill 136 193 323 136 237 323 minecraft:andesite
fill 95 194 323 95 194 325 minecraft:stone
setblock 95 194 326 minecraft:stripped_spruce_log
fill 95 194 327 95 194 330 minecraft:stone
setblock 95 194 331 minecraft:stripped_spruce_log
fill 95 194 332 95 194 335 minecraft:stone
setblock 95 194 336 minecraft:stripped_spruce_log
fill 95 194 337 95 197 337 minecraft:stone
setblock 95 194 341 minecraft:stripped_spruce_log
fill 95 194 342 95 194 345 minecraft:stone
setblock 95 194 346 minecraft:stripped_spruce_log
fill 95 194 347 95 194 350 minecraft:stone
setblock 95 194 351 minecraft:stripped_spruce_log
fill 95 194 352 95 194 355 minecraft:stone
setblock 95 194 356 minecraft:stripped_spruce_log
fill 95 194 357 95 194 360 minecraft:stone
setblock 95 194 361 minecraft:stripped_spruce_log
fill 95 194 362 97 194 363 minecraft:stone
fill 96 194 323 96 194 324 minecraft:stone
setblock 96 194 325 minecraft:stripped_spruce_log
fill 96 194 326 96 194 329 minecraft:stone
setblock 96 194 330 minecraft:stripped_spruce_log
fill 96 194 331 96 194 334 minecraft:stone
setblock 96 194 345 minecraft:stripped_spruce_log
fill 96 194 346 96 194 349 minecraft:stone
setblock 96 194 350 minecraft:stripped_spruce_log
fill 96 194 351 96 194 354 minecraft:stone
setblock 96 194 355 minecraft:stripped_spruce_log
fill 96 194 356 96 194 359 minecraft:stone
setblock 96 194 360 minecraft:stripped_spruce_log
fill 96 194 361 96 197 361 minecraft:stone
setblock 97 194 323 minecraft:stone
setblock 97 194 324 minecraft:stripped_spruce_log
fill 97 194 325 97 196 326 minecraft:stone
setblock 97 194 329 minecraft:stripped_spruce_log
fill 97 194 330 97 196 331 minecraft:stone
setblock 97 194 333 minecraft:light[level=15]
setblock 97 194 341 minecraft:light[level=15]
fill 97 194 347 97 194 348 minecraft:stone
setblock 97 194 349 minecraft:stripped_spruce_log
fill 97 194 350 97 197 350 minecraft:stone
setblock 97 194 354 minecraft:stripped_spruce_log
fill 97 194 355 97 196 356 minecraft:stone
setblock 97 194 357 minecraft:light[level=15]
setblock 98 194 323 minecraft:stripped_spruce_log
fill 98 194 324 101 194 324 minecraft:stone
fill 98 194 326 98 196 326 minecraft:cobbled_deepslate
setblock 98 194 362 minecraft:stone
setblock 98 194 363 minecraft:stripped_spruce_log
fill 99 194 323 102 194 323 minecraft:stone
setblock 99 194 362 minecraft:stripped_spruce_log
fill 99 194 363 102 194 363 minecraft:stone
fill 100 194 362 101 194 362 minecraft:stone
fill 102 194 346 112 194 346 minecraft:stripped_spruce_log
setblock 103 194 323 minecraft:stripped_spruce_log
setblock 103 194 363 minecraft:stripped_spruce_log
setblock 104 194 363 minecraft:stone
setblock 105 194 325 minecraft:light[level=15]
setblock 105 194 333 minecraft:light[level=15]
setblock 105 194 341 minecraft:light[level=15]
setblock 105 194 349 minecraft:light[level=15]
setblock 105 194 357 minecraft:light[level=15]
fill 106 194 345 114 195 345 minecraft:stripped_spruce_log
fill 111 194 323 112 194 323 minecraft:stone
fill 111 194 363 112 194 363 minecraft:stone
setblock 113 194 323 minecraft:stripped_spruce_log
setblock 113 194 325 minecraft:light[level=15]
setblock 113 194 333 minecraft:light[level=15]
setblock 113 194 341 minecraft:light[level=15]
fill 113 194 344 126 194 344 minecraft:stripped_spruce_log
setblock 113 194 349 minecraft:light[level=15]
setblock 113 194 357 minecraft:light[level=15]
setblock 113 194 363 minecraft:stripped_spruce_log
fill 114 194 323 116 194 324 minecraft:stone
fill 114 194 363 117 194 363 minecraft:stone
fill 115 194 322 115 232 322 minecraft:andesite
fill 116 194 325 116 195 325 minecraft:stripped_spruce_log
setblock 117 194 323 minecraft:stone
setblock 117 194 324 minecraft:stripped_spruce_log
fill 117 194 326 117 195 326 minecraft:stripped_spruce_log
setblock 118 194 323 minecraft:stripped_spruce_log
fill 118 194 324 120 194 324 minecraft:stone
fill 118 194 325 118 195 325 minecraft:stripped_spruce_log
setblock 118 194 363 minecraft:stripped_spruce_log
fill 119 194 323 122 194 323 minecraft:stone
setblock 121 194 325 minecraft:light[level=15]
setblock 121 194 333 minecraft:light[level=15]
setblock 121 194 341 minecraft:light[level=15]
setblock 121 194 349 minecraft:light[level=15]
setblock 121 194 357 minecraft:light[level=15]
setblock 123 194 323 minecraft:stripped_spruce_log
setblock 127 194 323 minecraft:stone
setblock 128 194 322 minecraft:diamond_block
setblock 128 194 323 minecraft:stripped_spruce_log
fill 128 194 343 134 194 343 minecraft:stripped_dark_oak_log
fill 129 194 323 131 194 324 minecraft:stone
setblock 129 194 325 minecraft:light[level=15]
setblock 129 194 333 minecraft:light[level=15]
setblock 129 194 341 minecraft:light[level=15]
setblock 129 194 349 minecraft:light[level=15]
setblock 129 194 357 minecraft:light[level=15]
setblock 131 194 325 minecraft:stripped_spruce_log
fill 131 194 356 132 197 356 minecraft:raw_gold_block
setblock 132 194 323 minecraft:stone
setblock 132 194 324 minecraft:stripped_spruce_log
fill 132 194 325 132 194 328 minecraft:stone
setblock 132 194 329 minecraft:stripped_spruce_log
fill 132 194 330 132 197 330 minecraft:stone
fill 132 194 355 132 196 355 minecraft:raw_gold_block
fill 132 194 357 132 196 357 minecraft:raw_gold_block
setblock 133 194 323 minecraft:stripped_spruce_log
fill 133 194 324 135 195 324 minecraft:stone
setblock 133 194 327 minecraft:stone
setblock 133 194 328 minecraft:stripped_spruce_log
fill 133 194 329 135 195 329 minecraft:stone
setblock 133 194 333 minecraft:stripped_spruce_log
fill 133 194 334 135 195 334 minecraft:stone
fill 133 194 354 134 194 354 minecraft:raw_gold_block
fill 133 194 358 134 195 358 minecraft:raw_gold_block
setblock 133 194 363 minecraft:stripped_spruce_log
fill 134 194 323 135 196 323 minecraft:stone
fill 134 194 325 134 194 326 minecraft:stone
setblock 134 194 327 minecraft:stripped_spruce_log
fill 134 194 328 135 196 328 minecraft:stone
fill 134 194 330 134 194 331 minecraft:stone
setblock 134 194 332 minecraft:stripped_spruce_log
fill 134 194 333 135 196 333 minecraft:stone
fill 134 194 335 134 194 336 minecraft:stone
setblock 134 194 337 minecraft:stripped_spruce_log
fill 134 194 344 134 194 346 minecraft:stone
setblock 134 194 347 minecraft:stripped_spruce_log
fill 134 194 348 134 194 351 minecraft:stone
setblock 134 194 352 minecraft:stripped_spruce_log
fill 134 194 353 135 196 353 minecraft:stone
fill 134 194 355 134 194 357 minecraft:raw_gold_block
fill 134 194 363 135 196 363 minecraft:stone
setblock 135 194 325 minecraft:stone
setblock 135 194 326 minecraft:stripped_spruce_log
fill 135 194 327 135 197 327 minecraft:stone
setblock 135 194 330 minecraft:stone
setblock 135 194 331 minecraft:stripped_spruce_log
fill 135 194 332 135 197 332 minecraft:stone
setblock 135 194 335 minecraft:stone
setblock 135 194 336 minecraft:stripped_spruce_log
fill 135 194 337 135 194 340 minecraft:stone
setblock 135 194 341 minecraft:stripped_spruce_log
fill 135 194 342 135 194 345 minecraft:stone
setblock 135 194 346 minecraft:stripped_spruce_log
fill 135 194 347 135 194 350 minecraft:stone
setblock 135 194 351 minecraft:stripped_spruce_log
fill 135 194 352 135 197 352 minecraft:stone
fill 135 194 354 135 194 355 minecraft:stone
setblock 135 194 356 minecraft:stripped_spruce_log
fill 135 194 357 135 194 360 minecraft:stone
setblock 135 194 361 minecraft:stripped_spruce_log
fill 135 194 362 135 197 362 minecraft:stone
fill 94 195 330 94 207 334 minecraft:andesite
setblock 94 195 335 minecraft:diamond_block
setblock 94 195 350 minecraft:gold_block
fill 95 195 323 95 195 324 minecraft:stone
setblock 95 195 325 minecraft:stripped_spruce_log
fill 95 195 326 95 195 329 minecraft:stone
setblock 95 195 330 minecraft:stripped_spruce_log
fill 95 195 331 95 195 334 minecraft:stone
setblock 95 195 335 minecraft:stripped_spruce_log
fill 95 195 336 95 198 336 minecraft:stone
fill 95 195 338 95 195 339 minecraft:stone
setblock 95 195 340 minecraft:stripped_spruce_log
fill 95 195 341 95 195 344 minecraft:stone
setblock 95 195 345 minecraft:stripped_spruce_log
fill 95 195 346 95 195 349 minecraft:stone
setblock 95 195 350 minecraft:stripped_spruce_log
fill 95 195 351 95 195 354 minecraft:stone
setblock 95 195 355 minecraft:stripped_spruce_log
fill 95 195 356 95 195 359 minecraft:stone
setblock 95 195 360 minecraft:stripped_spruce_log
fill 95 195 361 95 196 363 minecraft:stone
setblock 96 195 323 minecraft:stone
setblock 96 195 324 minecraft:stripped_spruce_log
fill 96 195 325 96 195 328 minecraft:stone
setblock 96 195 329 minecraft:stripped_spruce_log
fill 96 195 330 96 195 333 minecraft:stone
setblock 96 195 334 minecraft:stripped_spruce_log
fill 96 195 335 96 198 335 minecraft:stone
fill 96 195 345 96 195 348 minecraft:stone
setblock 96 195 349 minecraft:stripped_spruce_log
fill 96 195 350 96 195 353 minecraft:stone
setblock 96 195 354 minecraft:stripped_spruce_log
fill 96 195 355 96 195 358 minecraft:stone
setblock 96 195 359 minecraft:stripped_spruce_log
fill 96 195 360 96 198 360 minecraft:stone
fill 96 195 362 96 195 363 minecraft:stone
setblock 97 195 323 minecraft:stripped_spruce_log
fill 97 195 324 100 195 324 minecraft:stone
setblock 97 195 328 minecraft:stripped_spruce_log
fill 97 195 329 97 198 329 minecraft:stone
setblock 97 195 332 minecraft:stone
fill 97 195 346 110 195 346 minecraft:stripped_spruce_log
setblock 97 195 347 minecraft:stone
setblock 97 195 348 minecraft:stripped_spruce_log
fill 97 195 349 97 198 349 minecraft:stone
fill 97 195 351 97 195 352 minecraft:stone
setblock 97 195 353 minecraft:stripped_spruce_log
fill 97 195 354 97 198 354 minecraft:stone
setblock 97 195 357 minecraft:stone
setblock 97 195 358 minecraft:stripped_spruce_log
setblock 97 195 362 minecraft:stone
setblock 97 195 363 minecraft:stripped_spruce_log
fill 98 195 323 101 195 323 minecraft:stone
fill 98 195 327 98 196 327 minecraft:cobbled_deepslate
fill 98 195 347 103 195 347 minecraft:stripped_spruce_log
setblock 98 195 362 minecraft:stripped_spruce_log
fill 98 195 363 101 195 363 minecraft:stone
fill 99 195 358 99 201 358 minecraft:stripped_spruce_log
fill 99 195 362 100 196 362 minecraft:stone
fill 100 195 325 100 196 325 minecraft:cobbled_deepslate
fill 100 195 327 100 196 327 minecraft:cobbled_deepslate
setblock 101 195 324 minecraft:stripped_spruce_log
setblock 102 195 323 minecraft:stripped_spruce_log
setblock 102 195 363 minecraft:stripped_spruce_log
setblock 103 195 323 minecraft:stone
fill 103 195 363 103 196 363 minecraft:stone
setblock 103 195 364 minecraft:raw_iron_block
fill 104 195 345 105 195 345 minecraft:stripped_spruce_log
setblock 111 195 323 minecraft:stone
setblock 111 195 363 minecraft:stone
setblock 112 195 323 minecraft:stripped_spruce_log
setblock 112 195 363 minecraft:stripped_spruce_log
fill 113 195 323 116 195 323 minecraft:stone
fill 113 195 363 116 195 363 minecraft:stone
fill 114 195 324 115 195 324 minecraft:stone
fill 115 195 345 117 195 345 minecraft:stripped_dark_oak_log
setblock 116 195 324 minecraft:stripped_spruce_log
setblock 117 195 323 minecraft:stripped_spruce_log
fill 117 195 324 119 195 324 minecraft:stone
setblock 117 195 363 minecraft:stripped_spruce_log
fill 118 195 323 121 195 323 minecraft:stone
fill 118 195 344 125 195 344 minecraft:stripped_dark_oak_log
setblock 118 195 363 minecraft:stone
setblock 122 195 323 minecraft:stripped_spruce_log
setblock 127 195 323 minecraft:stripped_spruce_log
fill 128 195 322 128 238 322 minecraft:andesite
fill 128 195 323 131 195 323 minecraft:stone
fill 129 195 324 130 195 324 minecraft:stone
fill 129 195 356 130 197 356 minecraft:raw_gold_block
setblock 130 195 325 minecraft:stripped_spruce_log
fill 130 195 355 131 196 355 minecraft:raw_gold_block
fill 130 195 357 131 196 357 minecraft:raw_gold_block
setblock 131 195 324 minecraft:stripped_spruce_log
fill 131 195 325 132 197 325 minecraft:stone
setblock 132 195 323 minecraft:stripped_spruce_log
fill 132 195 324 132 198 324 minecraft:stone
fill 132 195 326 132 195 327 minecraft:stone
setblock 132 195 328 minecraft:stripped_spruce_log
fill 132 195 329 132 198 329 minecraft:stone
fill 132 195 331 132 195 332 minecraft:stone
setblock 132 195 363 minecraft:stripped_spruce_log
fill 133 195 323 133 198 323 minecraft:stone
setblock 133 195 327 minecraft:stripped_spruce_log
fill 133 195 328 133 198 328 minecraft:stone
fill 133 195 330 133 195 331 minecraft:stone
setblock 133 195 332 minecraft:stripped_spruce_log
fill 133 195 333 133 198 333 minecraft:stone
fill 133 195 335 134 195 335 minecraft:stone
setblock 133 195 354 minecraft:raw_gold_block
fill 133 195 363 133 198 363 minecraft:stone
setblock 134 195 325 minecraft:stone
setblock 134 195 326 minecraft:stripped_spruce_log
fill 134 195 327 134 198 327 minecraft:stone
setblock 134 195 330 minecraft:stone
setblock 134 195 331 minecraft:stripped_spruce_log
fill 134 195 332 134 198 332 minecraft:stone
setblock 134 195 336 minecraft:stripped_spruce_log
fill 134 195 337 135 196 338 minecraft:stone
fill 134 195 344 134 195 345 minecraft:stone
setblock 134 195 346 minecraft:stripped_spruce_log
fill 134 195 347 134 195 350 minecraft:stone
setblock 134 195 351 minecraft:stripped_spruce_log
fill 134 195 352 134 198 352 minecraft:stone
fill 134 195 354 134 195 355 minecraft:stone
fill 134 195 356 134 195 357 minecraft:raw_gold_block
setblock 135 195 325 minecraft:stripped_spruce_log
fill 135 195 326 135 198 326 minecraft:stone
setblock 135 195 330 minecraft:stripped_spruce_log
fill 135 195 331 135 198 331 minecraft:stone
setblock 135 195 335 minecraft:stripped_spruce_log
fill 135 195 336 135 198 336 minecraft:stone
setblock 135 195 339 minecraft:stone
setblock 135 195 340 minecraft:stripped_spruce_log
fill 135 195 341 135 195 344 minecraft:stone
setblock 135 195 345 minecraft:stripped_spruce_log
fill 135 195 346 135 195 349 minecraft:stone
setblock 135 195 350 minecraft:stripped_spruce_log
fill 135 195 351 135 198 351 minecraft:stone
setblock 135 195 354 minecraft:stone
setblock 135 195 355 minecraft:stripped_spruce_log
fill 135 195 356 135 195 359 minecraft:stone
setblock 135 195 360 minecraft:stripped_spruce_log
fill 135 195 361 135 198 361 minecraft:stone
setblock 136 195 329 minecraft:raw_iron_block
fill 94 196 322 94 237 322 minecraft:andesite
fill 94 196 335 94 243 335 minecraft:andesite
fill 94 196 350 94 219 350 minecraft:andesite
setblock 95 196 322 minecraft:diamond_block
setblock 95 196 323 minecraft:stone
setblock 95 196 324 minecraft:stripped_spruce_log
fill 95 196 325 95 196 328 minecraft:stone
setblock 95 196 329 minecraft:stripped_spruce_log
fill 95 196 330 95 196 333 minecraft:stone
setblock 95 196 334 minecraft:stripped_spruce_log
fill 95 196 335 95 199 335 minecraft:stone
setblock 95 196 338 minecraft:stone
setblock 95 196 339 minecraft:stripped_spruce_log
fill 95 196 340 95 196 343 minecraft:stone
setblock 95 196 344 minecraft:stripped_spruce_log
fill 95 196 345 95 196 348 minecraft:stone
setblock 95 196 349 minecraft:stripped_spruce_log
fill 95 196 350 95 196 353 minecraft:stone
setblock 95 196 354 minecraft:stripped_spruce_log
fill 95 196 355 95 196 358 minecraft:stone
setblock 95 196 359 minecraft:stripped_spruce_log
fill 95 196 360 95 199 360 minecraft:stone
fill 96 196 322 98 237 322 minecraft:andesite
setblock 96 196 323 minecraft:stripped_spruce_log
fill 96 196 324 96 196 327 minecraft:stone
setblock 96 196 328 minecraft:stripped_spruce_log
fill 96 196 329 96 196 332 minecraft:stone
setblock 96 196 333 minecraft:stripped_spruce_log
fill 96 196 334 96 199 334 minecraft:stone
fill 96 196 345 96 196 347 minecraft:stone
setblock 96 196 348 minecraft:stripped_spruce_log
fill 96 196 349 96 196 352 minecraft:stone
setblock 96 196 353 minecraft:stripped_spruce_log
fill 96 196 354 96 196 357 minecraft:stone
setblock 96 196 358 minecraft:stripped_spruce_log
fill 96 196 359 97 198 359 minecraft:stone
setblock 96 196 362 minecraft:stone
setblock 96 196 363 minecraft:stripped_spruce_log
fill 97 196 323 99 196 324 minecraft:stone
setblock 97 196 327 minecraft:stripped_spruce_log
fill 97 196 328 97 198 328 minecraft:stone
setblock 97 196 332 minecraft:stripped_spruce_log
fill 97 196 346 99 196 347 minecraft:stripped_spruce_log
fill 97 196 348 97 197 348 minecraft:stone
setblock 97 196 351 minecraft:stone
setblock 97 196 352 minecraft:stripped_spruce_log
fill 97 196 353 98 197 353 minecraft:stone
setblock 97 196 357 minecraft:stripped_spruce_log
fill 97 196 358 97 199 358 minecraft:stone
fill 97 196 360 97 197 360 minecraft:stone
setblock 97 196 362 minecraft:stripped_spruce_log
fill 97 196 363 100 196 363 minecraft:stone
fill 98 196 352 98 197 352 minecraft:stone
fill 98 196 362 98 199 362 minecraft:stone
setblock 99 196 322 minecraft:gold_block
setblock 99 196 325 minecraft:cobbled_deepslate
setblock 100 196 323 minecraft:stone
setblock 100 196 324 minecraft:stripped_spruce_log
setblock 100 196 346 minecraft:stripped_spruce_log
setblock 101 196 323 minecraft:stripped_spruce_log
fill 101 196 346 108 196 346 minecraft:stripped_dark_oak_log
setblock 101 196 363 minecraft:stripped_spruce_log
setblock 102 196 323 minecraft:stone
fill 102 196 363 102 197 363 minecraft:stone
fill 103 196 364 103 241 364 minecraft:andesite
fill 108 196 345 113 196 345 minecraft:stripped_dark_oak_log
setblock 110 196 363 minecraft:stone
setblock 111 196 323 minecraft:stripped_spruce_log
setblock 111 196 363 minecraft:stripped_spruce_log
fill 112 196 323 115 196 323 minecraft:stone
fill 112 196 363 115 196 363 minecraft:stone
setblock 114 196 324 minecraft:stone
setblock 115 196 324 minecraft:stripped_spruce_log
setblock 116 196 323 minecraft:stripped_spruce_log
fill 116 196 324 118 196 324 minecraft:stone
setblock 116 196 363 minecraft:stripped_spruce_log
fill 117 196 323 120 196 323 minecraft:stone
setblock 117 196 363 minecraft:stone
setblock 121 196 323 minecraft:stripped_spruce_log
fill 127 196 323 130 196 323 minecraft:stone
fill 128 196 356 128 197 356 minecraft:raw_gold_block
setblock 129 196 324 minecraft:stone
setblock 129 196 355 minecraft:raw_gold_block
setblock 129 196 357 minecraft:raw_gold_block
setblock 130 196 324 minecraft:stripped_spruce_log
fill 130 196 325 130 198 325 minecraft:stone
setblock 131 196 323 minecraft:stripped_spruce_log
fill 131 196 324 131 199 324 minecraft:stone
fill 131 196 326 132 196 326 minecraft:stone
fill 132 196 323 132 199 323 minecraft:stone
setblock 132 196 327 minecraft:stripped_spruce_log
fill 132 196 328 132 199 328 minecraft:stone
setblock 132 196 331 minecraft:stone
setblock 132 196 332 minecraft:stripped_spruce_log
fill 132 196 333 132 199 333 minecraft:stone
fill 132 196 363 132 199 363 minecraft:stone
fill 133 196 324 134 196 324 minecraft:stone
setblock 133 196 326 minecraft:stripped_spruce_log
fill 133 196 327 133 199 327 minecraft:stone
fill 133 196 329 133 196 330 minecraft:stone
setblock 133 196 331 minecraft:stripped_spruce_log
fill 133 196 332 133 199 332 minecraft:stone
fill 133 196 334 133 196 335 minecraft:stone
setblock 133 196 336 minecraft:stripped_spruce_log
setblock 134 196 325 minecraft:stripped_spruce_log
fill 134 196 326 134 199 326 minecraft:stone
setblock 134 196 329 minecraft:stone
setblock 134 196 330 minecraft:stripped_spruce_log
fill 134 196 331 134 199 331 minecraft:stone
setblock 134 196 334 minecraft:stone
setblock 134 196 335 minecraft:stripped_spruce_log
fill 134 196 336 134 199 336 minecraft:stone
setblock 134 196 339 minecraft:stone
setblock 134 196 345 minecraft:stripped_spruce_log
fill 134 196 346 134 196 349 minecraft:stone
setblock 134 196 350 minecraft:stripped_spruce_log
fill 134 196 351 134 199 351 minecraft:stone
setblock 134 196 354 minecraft:stone
setblock 134 196 355 minecraft:stripped_spruce_log
fill 134 196 356 135 196 358 minecraft:stone
setblock 135 196 324 minecraft:stripped_spruce_log
fill 135 196 325 135 199 325 minecraft:stone
setblock 135 196 329 minecraft:stripped_spruce_log
fill 135 196 330 135 199 330 minecraft:stone
setblock 135 196 334 minecraft:stripped_spruce_log
fill 135 196 335 135 199 335 minecraft:stone
setblock 135 196 339 minecraft:stripped_spruce_log
fill 135 196 340 135 196 343 minecraft:stone
setblock 135 196 344 minecraft:stripped_spruce_log
fill 135 196 345 135 196 348 minecraft:stone
setblock 135 196 349 minecraft:stripped_spruce_log
fill 135 196 350 135 199 350 minecraft:stone
setblock 135 196 354 minecraft:stripped_spruce_log
fill 135 196 355 135 199 355 minecraft:stone
setblock 135 196 359 minecraft:stripped_spruce_log
fill 135 196 360 135 199 360 minecraft:stone
fill 136 196 329 136 216 329 minecraft:andesite
fill 94 197 362 94 215 362 minecraft:andesite
setblock 94 197 363 minecraft:diamond_block
fill 95 197 322 95 228 322 minecraft:andesite
setblock 95 197 323 minecraft:stripped_spruce_log
fill 95 197 324 95 197 327 minecraft:stone
setblock 95 197 328 minecraft:stripped_spruce_log
fill 95 197 329 95 197 332 minecraft:stone
setblock 95 197 333 minecraft:stripped_spruce_log
fill 95 197 334 95 200 334 minecraft:stone
setblock 95 197 338 minecraft:stripped_spruce_log
fill 95 197 339 95 197 342 minecraft:stone
setblock 95 197 343 minecraft:stripped_spruce_log
fill 95 197 344 95 197 347 minecraft:stone
setblock 95 197 348 minecraft:stripped_spruce_log
fill 95 197 349 95 197 352 minecraft:stone
setblock 95 197 353 minecraft:stripped_spruce_log
fill 95 197 354 95 197 357 minecraft:stone
setblock 95 197 358 minecraft:stripped_spruce_log
fill 95 197 359 95 200 359 minecraft:stone
fill 95 197 361 95 197 362 minecraft:stone
setblock 95 197 363 minecraft:stripped_spruce_log
fill 96 197 323 96 197 326 minecraft:stone
setblock 96 197 327 minecraft:stripped_spruce_log
fill 96 197 328 96 197 331 minecraft:stone
setblock 96 197 332 minecraft:stripped_spruce_log
fill 96 197 333 96 200 333 minecraft:stone
setblock 96 197 346 minecraft:stone
setblock 96 197 347 minecraft:stripped_spruce_log
fill 96 197 348 96 197 351 minecraft:stone
setblock 96 197 352 minecraft:stripped_spruce_log
fill 96 197 353 96 197 356 minecraft:stone
setblock 96 197 357 minecraft:stripped_spruce_log
fill 96 197 358 96 200 358 minecraft:stone
setblock 96 197 362 minecraft:stripped_spruce_log
fill 96 197 363 99 197 363 minecraft:stone
fill 97 197 323 97 197 325 minecraft:stone
setblock 97 197 326 minecraft:stripped_spruce_log
setblock 97 197 327 minecraft:stone
setblock 97 197 330 minecraft:stone
setblock 97 197 331 minecraft:stripped_spruce_log
setblock 97 197 332 minecraft:stone
setblock 97 197 347 minecraft:stripped_dark_oak_log
setblock 97 197 351 minecraft:stripped_spruce_log
fill 97 197 352 97 200 352 minecraft:stone
setblock 97 197 355 minecraft:stone
setblock 97 197 356 minecraft:stripped_spruce_log
fill 97 197 357 97 200 357 minecraft:stone
fill 97 197 362 97 200 362 minecraft:stone
fill 98 197 323 98 197 324 minecraft:stone
setblock 98 197 354 minecraft:stone
fill 99 197 322 99 213 322 minecraft:andesite
setblock 99 197 323 minecraft:stone
setblock 99 197 324 minecraft:stripped_spruce_log
setblock 99 197 362 minecraft:stone
setblock 100 197 323 minecraft:stripped_spruce_log
setblock 100 197 363 minecraft:stripped_spruce_log
setblock 101 197 323 minecraft:stone
fill 101 197 363 101 198 363 minecraft:stone
setblock 110 197 363 minecraft:stripped_spruce_log
fill 111 197 323 114 197 323 minecraft:stone
fill 111 197 363 114 197 363 minecraft:stone
setblock 115 197 323 minecraft:stripped_spruce_log
fill 115 197 324 116 197 324 minecraft:stone
setblock 115 197 363 minecraft:stripped_spruce_log
fill 116 197 323 119 197 323 minecraft:stone
setblock 116 197 363 minecraft:stone
fill 127 197 323 129 197 323 minecraft:stone
setblock 127 197 356 minecraft:raw_gold_block
setblock 129 197 324 minecraft:stripped_spruce_log
setblock 130 197 323 minecraft:stripped_spruce_log
fill 130 197 324 130 200 324 minecraft:stone
fill 131 197 323 131 200 323 minecraft:stone
setblock 131 197 326 minecraft:stone
fill 131 197 363 131 200 363 minecraft:stone
setblock 132 197 326 minecraft:stripped_spruce_log
fill 132 197 327 132 199 327 minecraft:stone
setblock 132 197 331 minecraft:stripped_spruce_log
fill 132 197 332 132 200 332 minecraft:stone
fill 132 197 334 133 197 334 minecraft:stone
setblock 133 197 324 minecraft:stone
setblock 133 197 325 minecraft:stripped_spruce_log
fill 133 197 326 133 200 326 minecraft:stone
setblock 133 197 329 minecraft:stone
setblock 133 197 330 minecraft:stripped_spruce_log
fill 133 197 331 133 200 331 minecraft:stone
setblock 133 197 335 minecraft:stripped_spruce_log
fill 133 197 336 133 200 336 minecraft:stone
fill 133 197 351 133 197 353 minecraft:stone
setblock 133 197 356 minecraft:raw_gold_block
setblock 134 197 323 minecraft:stone
setblock 134 197 324 minecraft:stripped_spruce_log
fill 134 197 325 134 200 325 minecraft:stone
setblock 134 197 328 minecraft:stone
setblock 134 197 329 minecraft:stripped_spruce_log
fill 134 197 330 134 200 330 minecraft:stone
setblock 134 197 333 minecraft:stone
setblock 134 197 334 minecraft:stripped_spruce_log
fill 134 197 335 134 200 335 minecraft:stone
fill 134 197 337 134 197 338 minecraft:stone
setblock 134 197 339 minecraft:stripped_spruce_log
fill 134 197 346 134 197 348 minecraft:stone
setblock 134 197 349 minecraft:stripped_spruce_log
fill 134 197 350 134 200 350 minecraft:stone
setblock 134 197 353 minecraft:stone
setblock 134 197 354 minecraft:stripped_spruce_log
fill 134 197 355 134 197 358 minecraft:stone
setblock 134 197 359 minecraft:stripped_spruce_log
fill 134 197 360 134 197 363 minecraft:stone
setblock 135 197 323 minecraft:stripped_spruce_log
fill 135 197 324 135 200 324 minecraft:stone
setblock 135 197 328 minecraft:stripped_spruce_log
fill 135 197 329 135 200 329 minecraft:stone
setblock 135 197 333 minecraft:stripped_spruce_log
fill 135 197 334 135 200 334 minecraft:stone
setblock 135 197 337 minecraft:stone
setblock 135 197 338 minecraft:stripped_spruce_log
fill 135 197 339 135 197 342 minecraft:stone
setblock 135 197 343 minecraft:stripped_spruce_log
fill 135 197 344 135 197 347 minecraft:stone
setblock 135 197 348 minecraft:stripped_spruce_log
fill 135 197 349 135 200 349 minecraft:stone
setblock 135 197 353 minecraft:stripped_spruce_log
fill 135 197 354 135 200 354 minecraft:stone
fill 135 197 356 135 197 357 minecraft:stone
setblock 135 197 358 minecraft:stripped_spruce_log
fill 135 197 359 135 200 359 minecraft:stone
setblock 135 197 363 minecraft:stripped_spruce_log
fill 94 198 363 94 236 363 minecraft:andesite
fill 95 198 323 95 198 326 minecraft:stone
setblock 95 198 327 minecraft:stripped_spruce_log
fill 95 198 328 95 198 331 minecraft:stone
setblock 95 198 332 minecraft:stripped_spruce_log
fill 95 198 333 95 201 333 minecraft:stone
setblock 95 198 337 minecraft:stripped_spruce_log
fill 95 198 338 95 199 339 minecraft:stone
fill 95 198 343 95 198 346 minecraft:stone
setblock 95 198 347 minecraft:stripped_spruce_log
fill 95 198 348 95 198 351 minecraft:stone
setblock 95 198 352 minecraft:stripped_spruce_log
fill 95 198 353 95 198 356 minecraft:stone
setblock 95 198 357 minecraft:stripped_spruce_log
fill 95 198 358 95 201 358 minecraft:stone
setblock 95 198 361 minecraft:stone
setblock 95 198 362 minecraft:stripped_spruce_log
fill 95 198 363 98 198 363 minecraft:stone
fill 96 198 323 96 198 325 minecraft:stone
setblock 96 198 326 minecraft:stripped_spruce_log
fill 96 198 327 96 198 330 minecraft:stone
setblock 96 198 331 minecraft:stripped_spruce_log
fill 96 198 332 96 200 332 minecraft:stone
fill 96 198 347 96 198 350 minecraft:stone
setblock 96 198 351 minecraft:stripped_spruce_log
fill 96 198 352 96 198 355 minecraft:stone
setblock 96 198 356 minecraft:stripped_spruce_log
fill 96 198 357 96 201 357 minecraft:stone
setblock 96 198 361 minecraft:stripped_spruce_log
fill 96 198 362 96 201 362 minecraft:stone
fill 97 198 323 97 198 324 minecraft:stone
setblock 97 198 325 minecraft:light[level=12]
setblock 97 198 330 minecraft:stripped_spruce_log
setblock 97 198 332 minecraft:light[level=12]
setblock 97 198 339 minecraft:light[level=12]
setblock 97 198 346 minecraft:light[level=12]
setblock 97 198 350 minecraft:stripped_spruce_log
fill 97 198 351 97 199 351 minecraft:stone
fill 97 198 353 97 199 353 minecraft:stone
setblock 97 198 355 minecraft:stripped_spruce_log
fill 97 198 356 97 201 356 minecraft:stone
setblock 97 198 360 minecraft:stripped_spruce_log
setblock 98 198 323 minecraft:stone
fill 98 198 358 98 201 358 minecraft:stripped_spruce_log
setblock 99 198 323 minecraft:stripped_spruce_log
fill 99 198 357 99 201 357 minecraft:stripped_spruce_log
fill 99 198 359 99 201 359 minecraft:stripped_spruce_log
setblock 99 198 363 minecraft:stripped_spruce_log
fill 100 198 358 100 201 358 minecraft:stripped_spruce_log
fill 100 198 363 100 199 363 minecraft:stone
setblock 104 198 325 minecraft:light[level=12]
setblock 104 198 332 minecraft:light[level=12]
setblock 104 198 339 minecraft:light[level=12]
setblock 104 198 346 minecraft:light[level=12]
setblock 104 198 353 minecraft:light[level=12]
setblock 104 198 360 minecraft:light[level=12]
fill 110 198 363 113 198 363 minecraft:stone
setblock 111 198 325 minecraft:light[level=12]
setblock 111 198 332 minecraft:light[level=12]
setblock 111 198 339 minecraft:light[level=12]
setblock 111 198 346 minecraft:light[level=12]
setblock 111 198 353 minecraft:light[level=12]
setblock 111 198 360 minecraft:light[level=12]
fill 112 198 323 113 198 323 minecraft:stone
setblock 114 198 323 minecraft:stripped_spruce_log
setblock 114 198 363 minecraft:stripped_spruce_log
fill 115 198 323 117 198 323 minecraft:stone
setblock 115 198 363 minecraft:stone
setblock 118 198 325 minecraft:light[level=12]
setblock 118 198 332 minecraft:light[level=12]
setblock 118 198 339 minecraft:light[level=12]
setblock 118 198 346 minecraft:light[level=12]
setblock 118 198 353 minecraft:light[level=12]
setblock 118 198 360 minecraft:light[level=12]
setblock 125 198 325 minecraft:light[level=12]
setblock 125 198 332 minecraft:light[level=12]
setblock 125 198 339 minecraft:light[level=12]
setblock 125 198 346 minecraft:light[level=12]
setblock 125 198 353 minecraft:light[level=12]
setblock 125 198 360 minecraft:light[level=12]
fill 127 198 323 128 198 323 minecraft:stone
setblock 129 198 323 minecraft:stripped_spruce_log
fill 129 198 324 129 200 324 minecraft:stone
fill 130 198 323 130 201 323 minecraft:stone
setblock 131 198 325 minecraft:stone
setblock 132 198 325 minecraft:stripped_spruce_log
setblock 132 198 326 minecraft:stone
setblock 132 198 330 minecraft:stripped_spruce_log
fill 132 198 331 132 201 331 minecraft:stone
setblock 132 198 334 minecraft:stone
setblock 132 198 339 minecraft:light[level=12]
setblock 132 198 346 minecraft:light[level=12]
setblock 132 198 353 minecraft:light[level=12]
setblock 132 198 360 minecraft:light[level=12]
setblock 133 198 324 minecraft:stripped_spruce_log
fill 133 198 325 133 200 325 minecraft:stone
setblock 133 198 329 minecraft:stripped_spruce_log
fill 133 198 330 133 201 330 minecraft:stone
setblock 133 198 334 minecraft:stripped_spruce_log
fill 133 198 335 133 201 335 minecraft:stone
fill 133 198 352 133 198 353 minecraft:stone
setblock 133 198 354 minecraft:stripped_spruce_log
setblock 134 198 323 minecraft:stripped_spruce_log
fill 134 198 324 134 201 324 minecraft:stone
setblock 134 198 328 minecraft:stripped_spruce_log
fill 134 198 329 134 201 329 minecraft:stone
setblock 134 198 333 minecraft:stripped_spruce_log
fill 134 198 334 134 201 334 minecraft:stone
setblock 134 198 337 minecraft:stone
setblock 134 198 338 minecraft:stripped_spruce_log
fill 134 198 339 135 198 339 minecraft:stone
setblock 134 198 347 minecraft:stone
setblock 134 198 348 minecraft:stripped_spruce_log
fill 134 198 349 134 199 349 minecraft:stone
setblock 134 198 353 minecraft:stripped_spruce_log
fill 134 198 354 134 198 357 minecraft:stone
setblock 134 198 358 minecraft:stripped_spruce_log
fill 134 198 359 134 198 362 minecraft:stone
setblock 134 198 363 minecraft:stripped_spruce_log
fill 135 198 323 135 201 323 minecraft:stone
setblock 135 198 327 minecraft:stripped_spruce_log
fill 135 198 328 135 201 328 minecraft:stone
setblock 135 198 332 minecraft:stripped_spruce_log
fill 135 198 333 135 201 333 minecraft:stone
setblock 135 198 337 minecraft:stripped_spruce_log
fill 135 198 338 135 201 338 minecraft:stone
fill 135 198 340 135 198 341 minecraft:stone
setblock 135 198 342 minecraft:stripped_spruce_log
fill 135 198 343 135 198 346 minecraft:stone
setblock 135 198 347 minecraft:stripped_spruce_log
fill 135 198 348 135 200 348 minecraft:stone
setblock 135 198 352 minecraft:stripped_spruce_log
fill 135 198 353 135 201 353 minecraft:stone
setblock 135 198 356 minecraft:stone
setblock 135 198 357 minecraft:stripped_spruce_log
fill 135 198 358 135 201 358 minecraft:stone
setblock 135 198 362 minecraft:stripped_spruce_log
fill 135 198 363 135 201 363 minecraft:stone
fill 94 199 326 94 241 326 minecraft:andesite
setblock 94 199 327 minecraft:diamond_block
fill 94 199 328 94 203 328 minecraft:andesite
fill 95 199 323 95 199 325 minecraft:stone
setblock 95 199 326 minecraft:stripped_spruce_log
fill 95 199 327 95 199 330 minecraft:stone
setblock 95 199 331 minecraft:stripped_spruce_log
fill 95 199 332 95 202 332 minecraft:stone
setblock 95 199 336 minecraft:stripped_spruce_log
fill 95 199 337 95 202 337 minecraft:stone
setblock 95 199 345 minecraft:stone
setblock 95 199 346 minecraft:stripped_spruce_log
fill 95 199 347 95 199 350 minecraft:stone
setblock 95 199 351 minecraft:stripped_spruce_log
fill 95 199 352 95 199 355 minecraft:stone
setblock 95 199 356 minecraft:stripped_spruce_log
fill 95 199 357 95 202 357 minecraft:stone
setblock 95 199 361 minecraft:stripped_spruce_log
fill 95 199 362 95 201 363 minecraft:stone
fill 96 199 323 96 199 324 minecraft:stone
setblock 96 199 325 minecraft:stripped_spruce_log
fill 96 199 326 96 199 329 minecraft:stone
setblock 96 199 330 minecraft:stripped_spruce_log
fill 96 199 331 96 200 331 minecraft:stone
setblock 96 199 335 minecraft:stripped_spruce_log
fill 96 199 348 96 199 349 minecraft:stone
setblock 96 199 350 minecraft:stripped_spruce_log
fill 96 199 351 96 199 354 minecraft:stone
setblock 96 199 355 minecraft:stripped_spruce_log
fill 96 199 356 96 202 356 minecraft:stone
setblock 96 199 359 minecraft:stone
setblock 96 199 360 minecraft:stripped_spruce_log
fill 96 199 361 96 202 361 minecraft:stone
fill 96 199 363 97 199 363 minecraft:stone
setblock 97 199 323 minecraft:stone
setblock 97 199 350 minecraft:stone
setblock 97 199 354 minecraft:stripped_spruce_log
fill 97 199 355 97 202 355 minecraft:stone
fill 97 199 359 98 199 359 minecraft:stripped_spruce_log
setblock 98 199 323 minecraft:stripped_spruce_log
fill 98 199 357 98 201 357 minecraft:stripped_spruce_log
setblock 98 199 363 minecraft:stripped_spruce_log
fill 99 199 363 99 200 363 minecraft:stone
fill 100 199 357 100 201 357 minecraft:stripped_spruce_log
fill 100 199 359 100 201 359 minecraft:stripped_spruce_log
setblock 103 199 322 minecraft:gold_block
fill 111 199 363 112 199 363 minecraft:stone
setblock 113 199 363 minecraft:stripped_spruce_log
setblock 114 199 323 minecraft:stone
setblock 114 199 363 minecraft:stone
setblock 128 199 323 minecraft:stripped_spruce_log
fill 129 199 323 129 202 323 minecraft:stone
setblock 131 199 325 minecraft:stripped_spruce_log
setblock 132 199 324 minecraft:stripped_spruce_log
fill 132 199 325 132 200 325 minecraft:stone
setblock 132 199 329 minecraft:stripped_spruce_log
fill 132 199 330 132 201 330 minecraft:stone
setblock 132 199 334 minecraft:stripped_spruce_log
setblock 133 199 323 minecraft:stripped_spruce_log
fill 133 199 324 133 202 324 minecraft:stone
setblock 133 199 328 minecraft:stripped_spruce_log
fill 133 199 329 133 202 329 minecraft:stone
setblock 133 199 333 minecraft:stripped_spruce_log
fill 133 199 334 133 202 334 minecraft:stone
fill 133 199 346 134 202 346 minecraft:raw_gold_block
setblock 133 199 353 minecraft:stripped_spruce_log
fill 133 199 354 134 199 355 minecraft:stone
setblock 133 199 362 minecraft:stone
setblock 133 199 363 minecraft:stripped_spruce_log
fill 134 199 323 134 202 323 minecraft:stone
setblock 134 199 327 minecraft:stripped_spruce_log
fill 134 199 328 134 202 328 minecraft:stone
setblock 134 199 332 minecraft:stripped_spruce_log
fill 134 199 333 134 202 333 minecraft:stone
setblock 134 199 337 minecraft:stripped_spruce_log
fill 134 199 338 134 201 338 minecraft:stone
fill 134 199 345 134 202 345 minecraft:raw_gold_block
fill 134 199 347 134 202 347 minecraft:raw_gold_block
setblock 134 199 352 minecraft:stripped_spruce_log
fill 134 199 353 134 202 353 minecraft:stone
setblock 134 199 356 minecraft:stone
setblock 134 199 357 minecraft:stripped_spruce_log
fill 134 199 358 134 199 361 minecraft:stone
setblock 134 199 362 minecraft:stripped_spruce_log
fill 134 199 363 134 202 363 minecraft:stone
setblock 135 199 326 minecraft:stripped_spruce_log
fill 135 199 327 135 202 327 minecraft:stone
setblock 135 199 331 minecraft:stripped_spruce_log
fill 135 199 332 135 202 332 minecraft:stone
setblock 135 199 336 minecraft:stripped_spruce_log
fill 135 199 337 135 202 337 minecraft:stone
fill 135 199 339 135 199 340 minecraft:stone
setblock 135 199 341 minecraft:stripped_spruce_log
setblock 135 199 345 minecraft:stone
setblock 135 199 346 minecraft:stripped_spruce_log
setblock 135 199 347 minecraft:stone
setblock 135 199 351 minecraft:stripped_spruce_log
fill 135 199 352 135 202 352 minecraft:stone
setblock 135 199 356 minecraft:stripped_spruce_log
fill 135 199 357 135 202 357 minecraft:stone
setblock 135 199 361 minecraft:stripped_spruce_log
fill 135 199 362 135 202 362 minecraft:stone
setblock 136 199 355 minecraft:raw_iron_block
fill 94 200 327 94 241 327 minecraft:andesite
setblock 94 200 347 minecraft:raw_gold_block
fill 95 200 323 95 200 324 minecraft:stone
setblock 95 200 325 minecraft:stripped_spruce_log
fill 95 200 326 95 200 329 minecraft:stone
setblock 95 200 330 minecraft:stripped_spruce_log
fill 95 200 331 95 203 331 minecraft:stone
setblock 95 200 335 minecraft:stripped_spruce_log
fill 95 200 336 95 203 336 minecraft:stone
fill 95 200 338 95 201 338 minecraft:stone
fill 95 200 346 95 200 349 minecraft:stone
setblock 95 200 350 minecraft:stripped_spruce_log
fill 95 200 351 95 200 354 minecraft:stone
setblock 95 200 355 minecraft:stripped_spruce_log
fill 95 200 356 95 203 356 minecraft:stone
setblock 95 200 360 minecraft:stripped_spruce_log
fill 95 200 361 95 203 361 minecraft:stone
setblock 96 200 323 minecraft:stone
setblock 96 200 328 minecraft:stone
setblock 96 200 329 minecraft:stripped_spruce_log
setblock 96 200 330 minecraft:stone
setblock 96 200 334 minecraft:stripped_spruce_log
setblock 96 200 349 minecraft:stripped_spruce_log
fill 96 200 350 96 200 353 minecraft:stone
setblock 96 200 354 minecraft:stripped_spruce_log
fill 96 200 355 96 203 355 minecraft:stone
setblock 96 200 359 minecraft:stripped_spruce_log
fill 96 200 360 96 203 360 minecraft:stone
setblock 96 200 363 minecraft:stone
setblock 97 200 323 minecraft:stripped_spruce_log
setblock 97 200 353 minecraft:stripped_spruce_log
fill 97 200 354 97 201 354 minecraft:stone
setblock 97 200 358 minecraft:stripped_spruce_log
setblock 97 200 363 minecraft:stripped_spruce_log
fill 98 200 359 98 201 359 minecraft:stripped_spruce_log
fill 98 200 363 98 201 363 minecraft:stone
fill 103 200 322 103 241 322 minecraft:andesite
setblock 112 200 364 minecraft:gold_block
fill 128 200 323 128 203 323 minecraft:stone
fill 128 200 346 132 201 346 minecraft:raw_gold_block
fill 130 200 363 130 201 363 minecraft:stone
setblock 131 200 324 minecraft:stripped_spruce_log
fill 131 200 345 133 201 345 minecraft:raw_gold_block
fill 131 200 347 133 201 347 minecraft:raw_gold_block
setblock 132 200 323 minecraft:stripped_spruce_log
fill 132 200 324 132 203 324 minecraft:stone
setblock 132 200 328 minecraft:stripped_spruce_log
setblock 132 200 329 minecraft:stone
setblock 132 200 333 minecraft:stripped_spruce_log
setblock 132 200 334 minecraft:stone
setblock 132 200 363 minecraft:stripped_spruce_log
fill 133 200 323 133 203 323 minecraft:stone
setblock 133 200 327 minecraft:stripped_spruce_log
fill 133 200 328 133 202 328 minecraft:stone
setblock 133 200 332 minecraft:stripped_spruce_log
fill 133 200 333 133 203 333 minecraft:stone
setblock 133 200 362 minecraft:stripped_spruce_log
fill 133 200 363 133 203 363 minecraft:stone
setblock 134 200 326 minecraft:stripped_spruce_log
fill 134 200 327 134 203 327 minecraft:stone
setblock 134 200 331 minecraft:stripped_spruce_log
fill 134 200 332 134 203 332 minecraft:stone
setblock 134 200 336 minecraft:stripped_spruce_log
fill 134 200 337 134 203 337 minecraft:stone
setblock 134 200 351 minecraft:stripped_spruce_log
fill 134 200 352 134 201 352 minecraft:stone
fill 134 200 354 134 200 355 minecraft:stone
setblock 134 200 356 minecraft:stripped_spruce_log
fill 134 200 357 134 200 360 minecraft:stone
setblock 134 200 361 minecraft:stripped_spruce_log
fill 134 200 362 134 202 362 minecraft:stone
setblock 135 200 325 minecraft:stripped_spruce_log
fill 135 200 326 135 203 326 minecraft:stone
setblock 135 200 330 minecraft:stripped_spruce_log
fill 135 200 331 135 203 331 minecraft:stone
setblock 135 200 335 minecraft:stripped_spruce_log
fill 135 200 336 135 203 336 minecraft:stone
setblock 135 200 339 minecraft:stone
setblock 135 200 340 minecraft:stripped_spruce_log
fill 135 200 345 135 201 347 minecraft:raw_gold_block
setblock 135 200 350 minecraft:stripped_spruce_log
fill 135 200 351 135 202 351 minecraft:stone
setblock 135 200 355 minecraft:stripped_spruce_log
fill 135 200 356 135 203 356 minecraft:stone
setblock 135 200 360 minecraft:stripped_spruce_log
fill 135 200 361 135 203 361 minecraft:stone
fill 136 200 355 136 207 355 minecraft:andesite
fill 94 201 347 94 241 347 minecraft:andesite
setblock 94 201 360 minecraft:gold_block
setblock 95 201 323 minecraft:stone
setblock 95 201 324 minecraft:stripped_spruce_log
fill 95 201 325 95 201 328 minecraft:stone
setblock 95 201 329 minecraft:stripped_spruce_log
fill 95 201 330 95 203 330 minecraft:stone
setblock 95 201 334 minecraft:stripped_spruce_log
fill 95 201 335 95 204 335 minecraft:stone
fill 95 201 347 95 201 348 minecraft:stone
setblock 95 201 349 minecraft:stripped_spruce_log
fill 95 201 350 95 201 353 minecraft:stone
setblock 95 201 354 minecraft:stripped_spruce_log
fill 95 201 355 95 204 355 minecraft:stone
setblock 95 201 359 minecraft:stripped_spruce_log
fill 95 201 360 95 204 360 minecraft:stone
fill 96 201 350 96 201 352 minecraft:stone
setblock 96 201 353 minecraft:stripped_spruce_log
fill 96 201 354 96 204 354 minecraft:stone
setblock 96 201 358 minecraft:stripped_spruce_log
fill 96 201 359 96 204 359 minecraft:stone
setblock 96 201 363 minecraft:stripped_spruce_log
setblock 97 201 353 minecraft:stone
setblock 97 201 357 minecraft:stripped_spruce_log
setblock 97 201 358 minecraft:stone
fill 97 201 363 97 204 363 minecraft:stone
setblock 99 201 356 minecraft:stripped_spruce_log
setblock 99 201 360 minecraft:stripped_spruce_log
setblock 101 201 358 minecraft:stripped_spruce_log
fill 106 201 347 107 201 350 minecraft:stripped_dark_oak_log
fill 107 201 346 112 201 346 minecraft:stripped_dark_oak_log
fill 107 201 351 112 201 351 minecraft:stripped_dark_oak_log
fill 108 201 345 111 201 345 minecraft:stripped_dark_oak_log
fill 108 201 347 108 203 347 minecraft:stripped_dark_oak_log
fill 108 201 350 108 203 350 minecraft:stripped_dark_oak_log
fill 108 201 352 111 201 352 minecraft:stripped_dark_oak_log
fill 111 201 350 113 201 350 minecraft:stripped_dark_oak_log
fill 112 201 322 112 211 322 minecraft:andesite
fill 112 201 347 113 201 349 minecraft:stripped_dark_oak_log
fill 112 201 364 112 238 364 minecraft:andesite
setblock 113 201 322 minecraft:gold_block
fill 122 201 341 123 201 343 minecraft:stripped_dark_oak_log
fill 123 201 340 124 202 340 minecraft:stripped_dark_oak_log
fill 123 201 344 128 201 344 minecraft:stripped_dark_oak_log
fill 124 201 339 127 201 339 minecraft:stripped_dark_oak_log
fill 124 201 345 126 201 345 minecraft:stripped_dark_oak_log
fill 126 201 340 128 201 340 minecraft:stripped_dark_oak_log
fill 127 201 341 128 202 341 minecraft:stripped_dark_oak_log
fill 127 201 343 128 202 343 minecraft:stripped_dark_oak_log
fill 128 201 342 128 202 342 minecraft:stripped_dark_oak_log
setblock 130 201 324 minecraft:stripped_spruce_log
setblock 131 201 323 minecraft:stripped_spruce_log
fill 131 201 324 131 204 324 minecraft:stone
setblock 131 201 363 minecraft:stripped_spruce_log
fill 132 201 323 132 204 323 minecraft:stone
setblock 132 201 332 minecraft:stripped_spruce_log
setblock 132 201 333 minecraft:stone
fill 132 201 363 132 204 363 minecraft:stone
setblock 133 201 326 minecraft:stripped_spruce_log
setblock 133 201 327 minecraft:stone
setblock 133 201 331 minecraft:stripped_spruce_log
fill 133 201 332 133 203 332 minecraft:stone
setblock 133 201 336 minecraft:stripped_spruce_log
fill 133 201 362 133 204 362 minecraft:stone
setblock 134 201 325 minecraft:stripped_spruce_log
fill 134 201 326 134 202 326 minecraft:stone
setblock 134 201 330 minecraft:stripped_spruce_log
fill 134 201 331 134 204 331 minecraft:stone
setblock 134 201 335 minecraft:stripped_spruce_log
fill 134 201 336 134 204 336 minecraft:stone
setblock 134 201 354 minecraft:stone
setblock 134 201 355 minecraft:stripped_spruce_log
fill 134 201 356 134 201 359 minecraft:stone
setblock 134 201 360 minecraft:stripped_spruce_log
fill 134 201 361 134 204 361 minecraft:stone
setblock 135 201 324 minecraft:stripped_spruce_log
fill 135 201 325 135 204 325 minecraft:stone
setblock 135 201 329 minecraft:stripped_spruce_log
fill 135 201 330 135 204 330 minecraft:stone
setblock 135 201 334 minecraft:stripped_spruce_log
fill 135 201 335 135 204 335 minecraft:stone
setblock 135 201 339 minecraft:stripped_spruce_log
setblock 135 201 349 minecraft:stripped_spruce_log
setblock 135 201 350 minecraft:stone
setblock 135 201 354 minecraft:stripped_spruce_log
fill 135 201 355 135 204 355 minecraft:stone
setblock 135 201 359 minecraft:stripped_spruce_log
fill 135 201 360 135 204 360 minecraft:stone
setblock 136 201 356 minecraft:raw_gold_block
fill 136 201 357 136 230 361 minecraft:andesite
fill 94 202 360 94 229 360 minecraft:andesite
setblock 95 202 327 minecraft:stone
setblock 95 202 328 minecraft:stripped_spruce_log
setblock 95 202 329 minecraft:stone
setblock 95 202 333 minecraft:stripped_spruce_log
fill 95 202 334 95 204 334 minecraft:stone
fill 95 202 349 95 202 352 minecraft:stone
setblock 95 202 353 minecraft:stripped_spruce_log
fill 95 202 354 95 204 354 minecraft:stone
setblock 95 202 358 minecraft:stripped_spruce_log
fill 95 202 359 95 204 359 minecraft:stone
setblock 95 202 362 minecraft:stone
setblock 95 202 363 minecraft:stripped_spruce_log
setblock 96 202 351 minecraft:stone
setblock 96 202 352 minecraft:stripped_spruce_log
fill 96 202 353 96 204 353 minecraft:stone
setblock 96 202 357 minecraft:stripped_spruce_log
fill 96 202 358 96 204 358 minecraft:stone
setblock 96 202 362 minecraft:stripped_spruce_log
fill 96 202 363 96 204 363 minecraft:stone
setblock 97 202 325 minecraft:light[level=15]
setblock 97 202 333 minecraft:light[level=15]
setblock 97 202 341 minecraft:light[level=15]
setblock 97 202 349 minecraft:light[level=15]
setblock 97 202 356 minecraft:stripped_spruce_log
setblock 97 202 357 minecraft:stone
setblock 105 202 325 minecraft:light[level=15]
setblock 105 202 333 minecraft:light[level=15]
setblock 105 202 341 minecraft:light[level=15]
setblock 105 202 349 minecraft:light[level=15]
setblock 105 202 357 minecraft:light[level=15]
fill 107 202 347 107 202 350 minecraft:stripped_dark_oak_log
fill 108 202 346 111 202 346 minecraft:stripped_dark_oak_log
fill 108 202 351 111 202 351 minecraft:stripped_dark_oak_log
fill 111 202 350 112 202 350 minecraft:stripped_dark_oak_log
setblock 111 202 364 minecraft:diamond_block
fill 112 202 347 112 202 349 minecraft:stripped_dark_oak_log
fill 113 202 322 113 242 322 minecraft:andesite
setblock 113 202 325 minecraft:light[level=15]
setblock 113 202 333 minecraft:light[level=15]
setblock 113 202 349 minecraft:light[level=15]
setblock 113 202 357 minecraft:light[level=15]
fill 119 202 330 121 203 332 minecraft:iron_block
setblock 121 202 325 minecraft:light[level=15]
setblock 121 202 333 minecraft:light[level=15]
setblock 121 202 341 minecraft:light[level=15]
setblock 121 202 349 minecraft:light[level=15]
setblock 121 202 357 minecraft:light[level=15]
fill 123 202 341 123 202 343 minecraft:stripped_dark_oak_log
fill 124 202 344 127 202 344 minecraft:stripped_dark_oak_log
fill 125 202 339 126 202 339 minecraft:stripped_dark_oak_log
fill 126 202 340 127 202 340 minecraft:stripped_dark_oak_log
setblock 129 202 325 minecraft:light[level=15]
setblock 129 202 333 minecraft:light[level=15]
setblock 129 202 341 minecraft:light[level=15]
setblock 129 202 349 minecraft:light[level=15]
setblock 129 202 357 minecraft:light[level=15]
setblock 129 202 363 minecraft:stone
setblock 130 202 323 minecraft:stripped_spruce_log
fill 130 202 324 130 204 324 minecraft:stone
setblock 130 202 363 minecraft:stripped_spruce_log
fill 131 202 323 131 204 323 minecraft:stone
fill 131 202 363 131 204 363 minecraft:stone
fill 132 202 362 132 204 362 minecraft:stone
fill 133 202 322 133 204 322 minecraft:andesite
setblock 133 202 330 minecraft:stripped_spruce_log
fill 133 202 331 133 203 331 minecraft:stone
setblock 133 202 335 minecraft:stripped_spruce_log
setblock 134 202 322 minecraft:gold_block
setblock 134 202 324 minecraft:stripped_spruce_log
setblock 134 202 325 minecraft:stone
setblock 134 202 329 minecraft:stripped_spruce_log
fill 134 202 330 134 204 330 minecraft:stone
setblock 134 202 334 minecraft:stripped_spruce_log
fill 134 202 335 134 204 335 minecraft:stone
setblock 134 202 354 minecraft:stripped_spruce_log
fill 134 202 355 134 202 358 minecraft:stone
setblock 134 202 359 minecraft:stripped_spruce_log
fill 134 202 360 134 204 360 minecraft:stone
fill 135 202 322 136 229 322 minecraft:andesite
setblock 135 202 323 minecraft:stripped_spruce_log
fill 135 202 324 135 204 324 minecraft:stone
setblock 135 202 328 minecraft:stripped_spruce_log
fill 135 202 329 135 204 329 minecraft:stone
setblock 135 202 333 minecraft:stripped_spruce_log
fill 135 202 334 135 204 334 minecraft:stone
setblock 135 202 338 minecraft:stripped_spruce_log
fill 135 202 339 135 203 339 minecraft:stone
setblock 135 202 346 minecraft:raw_gold_block
setblock 135 202 353 minecraft:stripped_spruce_log
fill 135 202 354 135 204 354 minecraft:stone
setblock 135 202 358 minecraft:stripped_spruce_log
fill 135 202 359 135 204 359 minecraft:stone
setblock 135 202 363 minecraft:stripped_spruce_log
fill 136 202 356 136 237 356 minecraft:andesite
setblock 95 203 332 minecraft:stripped_spruce_log
fill 95 203 333 95 204 333 minecraft:stone
setblock 95 203 337 minecraft:stripped_spruce_log
fill 95 203 349 95 203 351 minecraft:stone
setblock 95 203 352 minecraft:stripped_spruce_log
fill 95 203 353 95 204 353 minecraft:stone
setblock 95 203 357 minecraft:stripped_spruce_log
fill 95 203 358 95 204 358 minecraft:stone
setblock 95 203 362 minecraft:stripped_spruce_log
fill 95 203 363 95 204 363 minecraft:stone
fill 96 203 324 96 206 324 minecraft:spruce_log
fill 96 203 343 96 206 343 minecraft:spruce_log
setblock 96 203 352 minecraft:stone
setblock 96 203 356 minecraft:stripped_spruce_log
fill 96 203 357 96 204 357 minecraft:stone
setblock 96 203 361 minecraft:stripped_spruce_log
fill 96 203 362 96 206 362 minecraft:spruce_log
fill 107 203 348 107 203 349 minecraft:stripped_dark_oak_log
fill 109 203 346 110 203 346 minecraft:stripped_dark_oak_log
fill 109 203 351 110 203 351 minecraft:stripped_dark_oak_log
setblock 110 203 322 minecraft:diamond_block
setblock 111 203 350 minecraft:stripped_dark_oak_log
fill 111 203 364 111 224 364 minecraft:andesite
fill 112 203 348 112 203 349 minecraft:stripped_dark_oak_log
fill 115 203 324 115 206 324 minecraft:spruce_log
fill 115 203 362 115 206 362 minecraft:spruce_log
fill 123 203 341 123 203 342 minecraft:stripped_dark_oak_log
setblock 124 203 340 minecraft:stripped_dark_oak_log
fill 125 203 344 126 203 344 minecraft:stripped_dark_oak_log
setblock 126 203 340 minecraft:stripped_dark_oak_log
setblock 127 203 341 minecraft:stripped_dark_oak_log
setblock 127 203 343 minecraft:stripped_dark_oak_log
setblock 129 203 323 minecraft:stripped_spruce_log
setblock 129 203 363 minecraft:stripped_spruce_log
fill 130 203 323 130 204 323 minecraft:stone
fill 130 203 363 130 204 363 minecraft:stone
fill 131 203 362 131 204 362 minecraft:stone
setblock 133 203 324 minecraft:stripped_spruce_log
setblock 133 203 330 minecraft:stone
setblock 133 203 334 minecraft:stripped_spruce_log
setblock 133 203 335 minecraft:stone
fill 134 203 322 134 243 322 minecraft:andesite
setblock 134 203 323 minecraft:stripped_spruce_log
fill 134 203 324 134 206 324 minecraft:spruce_log
setblock 134 203 328 minecraft:stripped_spruce_log
fill 134 203 329 134 204 329 minecraft:stone
setblock 134 203 333 minecraft:stripped_spruce_log
fill 134 203 334 134 204 334 minecraft:stone
fill 134 203 343 134 206 343 minecraft:spruce_log
fill 134 203 354 134 203 357 minecraft:stone
setblock 134 203 358 minecraft:stripped_spruce_log
fill 134 203 359 134 204 359 minecraft:stone
fill 134 203 362 134 206 362 minecraft:spruce_log
setblock 134 203 363 minecraft:stripped_spruce_log
fill 135 203 323 135 204 323 minecraft:stone
setblock 135 203 327 minecraft:stripped_spruce_log
fill 135 203 328 135 204 328 minecraft:stone
setblock 135 203 332 minecraft:stripped_spruce_log
fill 135 203 333 135 204 333 minecraft:stone
setblock 135 203 337 minecraft:stripped_spruce_log
fill 135 203 338 135 204 338 minecraft:stone
setblock 135 203 352 minecraft:stripped_spruce_log
fill 135 203 353 135 204 353 minecraft:stone
setblock 135 203 357 minecraft:stripped_spruce_log
fill 135 203 358 135 204 358 minecraft:stone
setblock 135 203 362 minecraft:stripped_spruce_log
fill 135 203 363 135 204 363 minecraft:stone
setblock 136 203 348 minecraft:diamond_block
fill 136 203 349 136 241 349 minecraft:andesite
setblock 94 204 328 minecraft:diamond_block
setblock 95 204 336 minecraft:stripped_spruce_log
setblock 95 204 337 minecraft:stone
setblock 95 204 350 minecraft:stone
setblock 95 204 351 minecraft:stripped_spruce_log
setblock 95 204 352 minecraft:stone
setblock 95 204 356 minecraft:stripped_spruce_log
setblock 95 204 357 minecraft:stone
setblock 95 204 361 minecraft:stripped_spruce_log
setblock 95 204 362 minecraft:stone
setblock 96 204 355 minecraft:stripped_spruce_log
setblock 96 204 356 minecraft:stone
setblock 96 204 360 minecraft:stripped_spruce_log
setblock 96 204 361 minecraft:stone
setblock 97 204 325 minecraft:light[level=12]
setblock 97 204 332 minecraft:light[level=12]
setblock 97 204 339 minecraft:light[level=12]
setblock 97 204 346 minecraft:light[level=12]
setblock 97 204 353 minecraft:light[level=12]
setblock 97 204 360 minecraft:light[level=12]
setblock 104 204 325 minecraft:light[level=12]
setblock 104 204 332 minecraft:light[level=12]
setblock 104 204 339 minecraft:light[level=12]
setblock 104 204 346 minecraft:light[level=12]
setblock 104 204 353 minecraft:light[level=12]
setblock 104 204 360 minecraft:light[level=12]
fill 108 204 364 108 241 364 minecraft:andesite
fill 109 204 363 111 204 363 minecraft:stone
setblock 109 204 364 minecraft:raw_gold_block
fill 110 204 322 110 213 322 minecraft:andesite
setblock 111 204 325 minecraft:light[level=12]
setblock 111 204 332 minecraft:light[level=12]
setblock 111 204 339 minecraft:light[level=12]
setblock 111 204 346 minecraft:light[level=12]
setblock 111 204 353 minecraft:light[level=12]
setblock 111 204 360 minecraft:light[level=12]
setblock 118 204 325 minecraft:light[level=12]
setblock 118 204 332 minecraft:light[level=12]
setblock 118 204 339 minecraft:light[level=12]
setblock 118 204 346 minecraft:light[level=12]
setblock 118 204 353 minecraft:light[level=12]
setblock 118 204 360 minecraft:light[level=12]
fill 119 204 330 121 204 332 minecraft:raw_gold_block
setblock 120 204 322 minecraft:gold_block
fill 121 204 322 122 210 322 minecraft:andesite
setblock 125 204 325 minecraft:light[level=12]
setblock 125 204 332 minecraft:light[level=12]
setblock 125 204 339 minecraft:light[level=12]
setblock 125 204 346 minecraft:light[level=12]
setblock 125 204 353 minecraft:light[level=12]
setblock 125 204 360 minecraft:light[level=12]
setblock 127 204 323 minecraft:stone
setblock 127 204 363 minecraft:stone
setblock 128 204 323 minecraft:stripped_spruce_log
setblock 128 204 363 minecraft:stripped_spruce_log
setblock 129 204 323 minecraft:stone
setblock 129 204 363 minecraft:stone
setblock 130 204 362 minecraft:stone
setblock 132 204 324 minecraft:stripped_spruce_log
setblock 132 204 325 minecraft:light[level=12]
setblock 132 204 332 minecraft:light[level=12]
setblock 132 204 339 minecraft:light[level=12]
setblock 132 204 346 minecraft:light[level=12]
setblock 132 204 353 minecraft:light[level=12]
setblock 132 204 360 minecraft:light[level=12]
setblock 133 204 323 minecraft:stripped_spruce_log
setblock 133 204 363 minecraft:stripped_spruce_log
setblock 134 204 323 minecraft:stone
setblock 134 204 332 minecraft:stripped_spruce_log
setblock 134 204 333 minecraft:stone
setblock 134 204 337 minecraft:stripped_spruce_log
fill 134 204 354 134 204 356 minecraft:stone
setblock 134 204 357 minecraft:stripped_spruce_log
setblock 134 204 358 minecraft:stone
setblock 134 204 363 minecraft:stone
setblock 135 204 326 minecraft:stripped_spruce_log
setblock 135 204 327 minecraft:stone
setblock 135 204 331 minecraft:stripped_spruce_log
setblock 135 204 332 minecraft:stone
setblock 135 204 336 minecraft:stripped_spruce_log
setblock 135 204 337 minecraft:stone
setblock 135 204 352 minecraft:stone
setblock 135 204 356 minecraft:stripped_spruce_log
setblock 135 204 357 minecraft:stone
setblock 135 204 361 minecraft:stripped_spruce_log
setblock 135 204 362 minecraft:stone
setblock 136 204 334 minecraft:gold_block
fill 136 204 336 136 241 337 minecraft:andesite
setblock 136 204 338 minecraft:diamond_block
fill 136 204 339 136 241 339 minecraft:andesite
fill 136 204 348 136 241 348 minecraft:andesite
fill 94 205 328 94 220 328 minecraft:andesite
fill 109 205 364 109 241 364 minecraft:andesite
fill 120 205 322 120 237 322 minecraft:andesite
setblock 133 205 322 minecraft:raw_iron_block
fill 136 205 334 136 209 334 minecraft:andesite
fill 136 205 338 136 214 338 minecraft:andesite
fill 133 206 322 133 237 322 minecraft:andesite
setblock 136 206 345 minecraft:raw_gold_block
setblock 96 207 324 minecraft:glowstone
setblock 96 207 343 minecraft:glowstone
setblock 96 207 362 minecraft:glowstone
setblock 115 207 324 minecraft:glowstone
setblock 115 207 362 minecraft:glowstone
setblock 134 207 324 minecraft:glowstone
setblock 134 207 343 minecraft:glowstone
setblock 134 207 362 minecraft:glowstone
fill 136 207 345 136 216 345 minecraft:andesite
setblock 94 208 330 minecraft:raw_gold_block
fill 94 208 331 94 214 334 minecraft:andesite
setblock 94 208 343 minecraft:raw_iron_block
fill 94 208 344 94 235 345 minecraft:andesite
fill 96 208 324 96 209 324 minecraft:spruce_log
fill 96 208 343 96 209 343 minecraft:spruce_log
fill 96 208 362 96 209 362 minecraft:spruce_log
fill 98 208 364 100 227 364 minecraft:andesite
setblock 101 208 364 minecraft:raw_iron_block
setblock 111 208 322 minecraft:raw_gold_block
fill 115 208 324 115 209 324 minecraft:spruce_log
fill 115 208 362 115 209 362 minecraft:spruce_log
fill 134 208 324 134 209 324 minecraft:spruce_log
fill 134 208 343 134 209 343 minecraft:spruce_log
fill 134 208 362 134 209 362 minecraft:spruce_log
setblock 136 208 355 minecraft:raw_iron_block
fill 94 209 330 94 241 330 minecraft:andesite
fill 94 209 343 94 241 343 minecraft:andesite
fill 95 209 323 95 209 363 minecraft:spruce_planks
fill 96 209 323 135 209 323 minecraft:spruce_planks
fill 96 209 325 96 209 342 minecraft:spruce_planks
fill 96 209 344 96 209 361 minecraft:spruce_planks
fill 96 209 363 135 209 363 minecraft:spruce_planks
fill 97 209 324 114 209 324 minecraft:spruce_planks
fill 97 209 362 114 209 362 minecraft:spruce_planks
fill 101 209 364 101 241 364 minecraft:andesite
setblock 110 209 364 minecraft:gold_block
fill 111 209 322 111 241 322 minecraft:andesite
fill 116 209 324 133 209 324 minecraft:spruce_planks
fill 116 209 362 133 209 362 minecraft:spruce_planks
fill 134 209 325 135 209 342 minecraft:spruce_planks
fill 134 209 344 135 209 361 minecraft:spruce_planks
setblock 135 209 324 minecraft:spruce_planks
setblock 135 209 343 minecraft:spruce_planks
setblock 135 209 362 minecraft:spruce_planks
fill 136 209 355 136 237 355 minecraft:andesite
setblock 94 210 324 minecraft:raw_iron_block
setblock 94 210 356 minecraft:raw_iron_block
setblock 97 210 325 minecraft:light[level=15]
setblock 97 210 332 minecraft:light[level=12]
setblock 97 210 333 minecraft:light[level=15]
setblock 97 210 339 minecraft:light[level=12]
setblock 97 210 341 minecraft:light[level=15]
setblock 97 210 346 minecraft:light[level=12]
setblock 97 210 349 minecraft:light[level=15]
setblock 97 210 353 minecraft:light[level=12]
setblock 97 210 357 minecraft:light[level=15]
setblock 97 210 360 minecraft:light[level=12]
fill 103 210 337 110 210 339 minecraft:iron_block
fill 103 210 342 120 210 342 minecraft:iron_block
setblock 104 210 325 minecraft:light[level=12]
setblock 104 210 332 minecraft:light[level=12]
fill 104 210 334 119 210 334 minecraft:iron_block
fill 104 210 343 104 211 343 minecraft:iron_block
setblock 104 210 346 minecraft:light[level=12]
setblock 104 210 353 minecraft:light[level=12]
setblock 104 210 360 minecraft:light[level=12]
setblock 105 210 325 minecraft:light[level=15]
fill 105 210 333 105 211 333 minecraft:iron_block
fill 105 210 335 120 210 335 minecraft:iron_block
fill 105 210 340 110 210 341 minecraft:iron_block
setblock 105 210 349 minecraft:light[level=15]
setblock 105 210 357 minecraft:light[level=15]
fill 106 210 336 123 210 336 minecraft:iron_block
fill 106 210 343 121 210 343 minecraft:iron_block
fill 106 210 345 107 211 346 minecraft:iron_block
fill 107 210 331 109 211 331 minecraft:iron_block
fill 107 210 333 120 211 333 minecraft:iron_block
fill 107 210 344 122 210 344 minecraft:iron_block
fill 108 210 330 108 211 330 minecraft:iron_block
fill 108 210 332 117 211 332 minecraft:iron_block
fill 108 210 345 119 211 345 minecraft:iron_block
fill 109 210 346 118 211 346 minecraft:iron_block
fill 109 210 348 110 211 348 minecraft:iron_block
fill 110 210 347 115 211 347 minecraft:iron_block
fill 110 210 349 110 211 349 minecraft:iron_block
fill 110 210 364 110 242 364 minecraft:andesite
setblock 111 210 325 minecraft:light[level=12]
fill 111 210 329 112 211 331 minecraft:iron_block
setblock 111 210 337 minecraft:iron_block
setblock 111 210 341 minecraft:iron_block
setblock 111 210 353 minecraft:light[level=12]
setblock 111 210 360 minecraft:light[level=12]
setblock 113 210 325 minecraft:light[level=15]
fill 113 210 331 116 211 331 minecraft:iron_block
setblock 113 210 349 minecraft:light[level=15]
setblock 113 210 357 minecraft:light[level=15]
fill 114 210 348 115 211 349 minecraft:iron_block
setblock 114 210 364 minecraft:gold_block
fill 115 210 337 121 210 337 minecraft:iron_block
fill 115 210 341 123 210 341 minecraft:iron_block
fill 116 210 329 116 211 330 minecraft:iron_block
fill 116 210 338 121 210 340 minecraft:iron_block
fill 117 210 330 117 211 330 minecraft:iron_block
fill 117 210 347 119 211 347 minecraft:iron_block
setblock 118 210 325 minecraft:light[level=12]
setblock 118 210 332 minecraft:light[level=12]
fill 118 210 348 118 211 348 minecraft:iron_block
setblock 118 210 353 minecraft:light[level=12]
setblock 118 210 360 minecraft:light[level=12]
fill 119 210 332 120 211 332 minecraft:iron_block
setblock 121 210 325 minecraft:light[level=15]
setblock 121 210 333 minecraft:light[level=15]
fill 121 210 345 121 211 345 minecraft:iron_block
setblock 121 210 349 minecraft:light[level=15]
setblock 121 210 357 minecraft:light[level=15]
fill 122 210 335 122 211 335 minecraft:iron_block
fill 122 210 339 123 211 340 minecraft:iron_block
setblock 125 210 325 minecraft:light[level=12]
setblock 125 210 332 minecraft:light[level=12]
setblock 125 210 339 minecraft:light[level=12]
setblock 125 210 346 minecraft:light[level=12]
setblock 125 210 353 minecraft:light[level=12]
setblock 125 210 360 minecraft:light[level=12]
setblock 129 210 325 minecraft:light[level=15]
setblock 129 210 333 minecraft:light[level=15]
setblock 129 210 341 minecraft:light[level=15]
setblock 129 210 349 minecraft:light[level=15]
setblock 129 210 357 minecraft:light[level=15]
setblock 132 210 325 minecraft:light[level=12]
setblock 132 210 332 minecraft:light[level=12]
setblock 132 210 339 minecraft:light[level=12]
setblock 132 210 346 minecraft:light[level=12]
setblock 132 210 353 minecraft:light[level=12]
setblock 132 210 360 minecraft:light[level=12]
setblock 136 210 334 minecraft:gold_block
fill 94 211 324 94 238 324 minecraft:andesite
fill 94 211 356 94 224 356 minecraft:andesite
fill 95 211 323 135 211 324 minecraft:cobbled_deepslate
setblock 95 211 325 minecraft:raw_gold_block
fill 95 211 326 95 211 330 minecraft:cobbled_deepslate
setblock 95 211 331 minecraft:raw_gold_block
fill 95 211 332 95 211 336 minecraft:cobbled_deepslate
setblock 95 211 337 minecraft:raw_gold_block
fill 95 211 338 95 211 342 minecraft:cobbled_deepslate
setblock 95 211 343 minecraft:raw_gold_block
fill 95 211 344 95 211 348 minecraft:cobbled_deepslate
setblock 95 211 349 minecraft:raw_gold_block
fill 95 211 350 95 211 354 minecraft:cobbled_deepslate
setblock 95 211 355 minecraft:raw_gold_block
fill 95 211 356 95 211 360 minecraft:cobbled_deepslate
setblock 95 211 361 minecraft:raw_gold_block
fill 95 211 362 135 211 363 minecraft:cobbled_deepslate
fill 96 211 325 96 211 327 minecraft:cobbled_deepslate
setblock 96 211 328 minecraft:raw_gold_block
fill 96 211 329 96 211 333 minecraft:cobbled_deepslate
setblock 96 211 334 minecraft:raw_gold_block
fill 96 211 335 96 211 339 minecraft:cobbled_deepslate
setblock 96 211 340 minecraft:raw_gold_block
fill 96 211 341 96 211 345 minecraft:cobbled_deepslate
setblock 96 211 346 minecraft:raw_gold_block
fill 96 211 347 96 211 351 minecraft:cobbled_deepslate
setblock 96 211 352 minecraft:raw_gold_block
fill 96 211 353 96 211 357 minecraft:cobbled_deepslate
setblock 96 211 358 minecraft:raw_gold_block
fill 96 211 359 96 211 361 minecraft:cobbled_deepslate
setblock 97 211 325 minecraft:raw_gold_block
fill 97 211 326 97 211 330 minecraft:cobbled_deepslate
setblock 97 211 331 minecraft:raw_gold_block
fill 97 211 332 97 211 336 minecraft:cobbled_deepslate
setblock 97 211 337 minecraft:raw_gold_block
fill 97 211 338 97 211 342 minecraft:cobbled_deepslate
setblock 97 211 343 minecraft:raw_gold_block
fill 97 211 344 97 211 348 minecraft:cobbled_deepslate
setblock 97 211 349 minecraft:raw_gold_block
fill 97 211 350 97 211 354 minecraft:cobbled_deepslate
setblock 97 211 355 minecraft:raw_gold_block
fill 97 211 356 97 211 360 minecraft:cobbled_deepslate
setblock 97 211 361 minecraft:raw_gold_block
fill 98 211 325 98 211 327 minecraft:cobbled_deepslate
setblock 98 211 328 minecraft:raw_gold_block
fill 98 211 329 98 211 333 minecraft:cobbled_deepslate
setblock 98 211 334 minecraft:raw_gold_block
fill 98 211 335 98 211 339 minecraft:cobbled_deepslate
setblock 98 211 340 minecraft:raw_gold_block
fill 98 211 341 98 211 345 minecraft:cobbled_deepslate
setblock 98 211 346 minecraft:raw_gold_block
fill 98 211 347 98 211 351 minecraft:cobbled_deepslate
setblock 98 211 352 minecraft:raw_gold_block
fill 98 211 353 98 211 357 minecraft:cobbled_deepslate
setblock 98 211 358 minecraft:raw_gold_block
fill 98 211 359 98 211 361 minecraft:cobbled_deepslate
setblock 99 211 325 minecraft:raw_gold_block
fill 99 211 326 99 211 330 minecraft:cobbled_deepslate
setblock 99 211 331 minecraft:raw_gold_block
fill 99 211 332 99 211 336 minecraft:cobbled_deepslate
setblock 99 211 337 minecraft:raw_gold_block
fill 99 211 338 99 211 342 minecraft:cobbled_deepslate
setblock 99 211 343 minecraft:raw_gold_block
fill 99 211 344 99 211 348 minecraft:cobbled_deepslate
setblock 99 211 349 minecraft:raw_gold_block
fill 99 211 350 99 211 354 minecraft:cobbled_deepslate
setblock 99 211 355 minecraft:raw_gold_block
fill 99 211 356 99 211 360 minecraft:cobbled_deepslate
setblock 99 211 361 minecraft:raw_gold_block
fill 100 211 325 100 211 327 minecraft:cobbled_deepslate
setblock 100 211 328 minecraft:raw_gold_block
fill 100 211 329 100 211 333 minecraft:cobbled_deepslate
setblock 100 211 334 minecraft:raw_gold_block
fill 100 211 335 100 211 339 minecraft:cobbled_deepslate
setblock 100 211 340 minecraft:raw_gold_block
fill 100 211 341 100 211 345 minecraft:cobbled_deepslate
setblock 100 211 346 minecraft:raw_gold_block
fill 100 211 347 100 211 351 minecraft:cobbled_deepslate
setblock 100 211 352 minecraft:raw_gold_block
fill 100 211 353 100 211 357 minecraft:cobbled_deepslate
setblock 100 211 358 minecraft:raw_gold_block
fill 100 211 359 100 211 361 minecraft:cobbled_deepslate
setblock 101 211 325 minecraft:raw_gold_block
fill 101 211 326 101 211 330 minecraft:cobbled_deepslate
setblock 101 211 331 minecraft:raw_gold_block
fill 101 211 332 101 211 336 minecraft:cobbled_deepslate
setblock 101 211 337 minecraft:raw_gold_block
fill 101 211 338 101 211 342 minecraft:cobbled_deepslate
setblock 101 211 343 minecraft:raw_gold_block
fill 101 211 344 101 211 348 minecraft:cobbled_deepslate
setblock 101 211 349 minecraft:raw_gold_block
fill 101 211 350 101 211 354 minecraft:cobbled_deepslate
setblock 101 211 355 minecraft:raw_gold_block
fill 101 211 356 101 211 360 minecraft:cobbled_deepslate
setblock 101 211 361 minecraft:raw_gold_block
setblock 102 211 322 minecraft:raw_iron_block
fill 102 211 325 102 211 327 minecraft:cobbled_deepslate
setblock 102 211 328 minecraft:raw_gold_block
fill 102 211 329 102 211 333 minecraft:cobbled_deepslate
setblock 102 211 334 minecraft:raw_gold_block
fill 102 211 335 102 211 339 minecraft:cobbled_deepslate
setblock 102 211 340 minecraft:raw_gold_block
fill 102 211 341 102 211 345 minecraft:cobbled_deepslate
setblock 102 211 346 minecraft:raw_gold_block
fill 102 211 347 102 211 351 minecraft:cobbled_deepslate
setblock 102 211 352 minecraft:raw_gold_block
fill 102 211 353 102 211 357 minecraft:cobbled_deepslate
setblock 102 211 358 minecraft:raw_gold_block
fill 102 211 359 102 211 361 minecraft:cobbled_deepslate
setblock 103 211 325 minecraft:raw_gold_block
fill 103 211 326 103 211 330 minecraft:cobbled_deepslate
setblock 103 211 331 minecraft:raw_gold_block
fill 103 211 332 103 211 336 minecraft:cobbled_deepslate
fill 103 211 337 109 211 339 minecraft:iron_block
fill 103 211 340 103 211 341 minecraft:cobbled_deepslate
fill 103 211 342 107 211 342 minecraft:iron_block
setblock 103 211 343 minecraft:raw_gold_block
fill 103 211 344 103 211 348 minecraft:cobbled_deepslate
setblock 103 211 349 minecraft:raw_gold_block
fill 103 211 350 103 211 354 minecraft:cobbled_deepslate
setblock 103 211 355 minecraft:raw_gold_block
fill 103 211 356 103 211 360 minecraft:cobbled_deepslate
setblock 103 211 361 minecraft:raw_gold_block
fill 104 211 325 104 211 327 minecraft:cobbled_deepslate
setblock 104 211 328 minecraft:raw_gold_block
fill 104 211 329 104 211 333 minecraft:cobbled_deepslate
fill 104 211 334 110 211 334 minecraft:iron_block
fill 104 211 335 104 211 336 minecraft:cobbled_deepslate
setblock 104 211 340 minecraft:raw_gold_block
setblock 104 211 341 minecraft:cobbled_deepslate
fill 104 211 344 105 211 345 minecraft:cobbled_deepslate
setblock 104 211 346 minecraft:raw_gold_block
fill 104 211 347 104 211 351 minecraft:cobbled_deepslate
setblock 104 211 352 minecraft:raw_gold_block
fill 104 211 353 104 211 357 minecraft:cobbled_deepslate
setblock 104 211 358 minecraft:raw_gold_block
fill 104 211 359 104 211 361 minecraft:cobbled_deepslate
setblock 105 211 325 minecraft:raw_gold_block
fill 105 211 326 105 211 330 minecraft:cobbled_deepslate
setblock 105 211 331 minecraft:raw_gold_block
fill 105 211 332 107 211 332 minecraft:cobbled_deepslate
fill 105 211 335 110 211 335 minecraft:iron_block
setblock 105 211 336 minecraft:cobbled_deepslate
fill 105 211 340 107 211 341 minecraft:iron_block
setblock 105 211 343 minecraft:raw_gold_block
fill 105 211 346 105 211 348 minecraft:cobbled_deepslate
setblock 105 211 349 minecraft:raw_gold_block
fill 105 211 350 105 211 354 minecraft:cobbled_deepslate
setblock 105 211 355 minecraft:raw_gold_block
fill 105 211 356 105 211 360 minecraft:cobbled_deepslate
setblock 105 211 361 minecraft:raw_gold_block
fill 106 211 325 106 211 327 minecraft:cobbled_deepslate
setblock 106 211 328 minecraft:raw_gold_block
fill 106 211 329 106 211 331 minecraft:cobbled_deepslate
setblock 106 211 333 minecraft:cobbled_deepslate
fill 106 211 336 110 211 336 minecraft:iron_block
fill 106 211 343 108 211 343 minecraft:iron_block
setblock 106 211 344 minecraft:cobbled_deepslate
fill 106 211 347 106 211 351 minecraft:cobbled_deepslate
setblock 106 211 352 minecraft:raw_gold_block
fill 106 211 353 106 211 357 minecraft:cobbled_deepslate
setblock 106 211 358 minecraft:raw_gold_block
fill 106 211 359 106 211 361 minecraft:cobbled_deepslate
setblock 107 211 325 minecraft:raw_gold_block
fill 107 211 326 107 211 330 minecraft:cobbled_deepslate
fill 107 211 344 109 211 344 minecraft:iron_block
fill 107 211 347 108 211 348 minecraft:cobbled_deepslate
setblock 107 211 349 minecraft:raw_gold_block
fill 107 211 350 107 211 354 minecraft:cobbled_deepslate
setblock 107 211 355 minecraft:raw_gold_block
fill 107 211 356 107 211 360 minecraft:cobbled_deepslate
setblock 107 211 361 minecraft:raw_gold_block
fill 108 211 325 108 211 327 minecraft:cobbled_deepslate
setblock 108 211 328 minecraft:raw_gold_block
fill 108 211 329 110 211 329 minecraft:cobbled_deepslate
fill 108 211 340 109 211 342 minecraft:gray_concrete
setblock 108 211 346 minecraft:raw_gold_block
fill 108 211 349 108 211 351 minecraft:cobbled_deepslate
setblock 108 211 352 minecraft:raw_gold_block
fill 108 211 353 108 211 357 minecraft:cobbled_deepslate
setblock 108 211 358 minecraft:raw_gold_block
fill 108 211 359 108 211 361 minecraft:cobbled_deepslate
setblock 109 211 325 minecraft:raw_gold_block
fill 109 211 326 109 211 328 minecraft:cobbled_deepslate
fill 109 211 330 110 211 330 minecraft:cobbled_deepslate
fill 109 211 343 110 211 343 minecraft:gray_concrete
setblock 109 211 347 minecraft:cobbled_deepslate
setblock 109 211 349 minecraft:raw_gold_block
fill 109 211 350 109 211 354 minecraft:cobbled_deepslate
setblock 109 211 355 minecraft:raw_gold_block
fill 109 211 356 109 211 360 minecraft:cobbled_deepslate
setblock 109 211 361 minecraft:raw_gold_block
fill 110 211 325 110 211 327 minecraft:cobbled_deepslate
setblock 110 211 328 minecraft:raw_gold_block
setblock 110 211 331 minecraft:cobbled_deepslate
fill 110 211 337 110 211 341 minecraft:glowstone
setblock 110 211 342 minecraft:gray_concrete
setblock 110 211 344 minecraft:gray_concrete
fill 110 211 350 135 211 351 minecraft:cobbled_deepslate
setblock 110 211 352 minecraft:raw_gold_block
fill 110 211 353 110 211 357 minecraft:cobbled_deepslate
setblock 110 211 358 minecraft:raw_gold_block
fill 110 211 359 110 211 361 minecraft:cobbled_deepslate
setblock 111 211 325 minecraft:raw_gold_block
fill 111 211 326 111 211 328 minecraft:cobbled_deepslate
fill 111 211 334 115 211 335 minecraft:gray_concrete
fill 111 211 336 111 211 337 minecraft:glowstone
fill 111 211 341 111 211 342 minecraft:glowstone
fill 111 211 343 115 211 344 minecraft:iron_block
fill 111 211 348 113 211 348 minecraft:cobbled_deepslate
setblock 111 211 349 minecraft:raw_gold_block
fill 111 211 352 111 211 354 minecraft:cobbled_deepslate
setblock 111 211 355 minecraft:raw_gold_block
fill 111 211 356 111 211 360 minecraft:cobbled_deepslate
setblock 111 211 361 minecraft:raw_gold_block
fill 112 211 325 112 211 327 minecraft:cobbled_deepslate
setblock 112 211 328 minecraft:raw_gold_block
fill 112 211 336 115 211 336 minecraft:glowstone
fill 112 211 342 115 211 342 minecraft:glowstone
setblock 112 211 349 minecraft:cobbled_deepslate
setblock 112 211 352 minecraft:raw_gold_block
fill 112 211 353 112 211 357 minecraft:cobbled_deepslate
setblock 112 211 358 minecraft:raw_gold_block
fill 112 211 359 112 211 361 minecraft:cobbled_deepslate
setblock 113 211 325 minecraft:raw_gold_block
fill 113 211 326 113 211 330 minecraft:cobbled_deepslate
setblock 113 211 349 minecraft:raw_gold_block
fill 113 211 352 113 211 354 minecraft:cobbled_deepslate
setblock 113 211 355 minecraft:raw_gold_block
fill 113 211 356 113 211 360 minecraft:cobbled_deepslate
setblock 113 211 361 minecraft:raw_gold_block
fill 114 211 325 114 211 327 minecraft:cobbled_deepslate
setblock 114 211 328 minecraft:raw_gold_block
fill 114 211 329 115 211 330 minecraft:cobbled_deepslate
setblock 114 211 352 minecraft:raw_gold_block
fill 114 211 353 114 211 357 minecraft:cobbled_deepslate
setblock 114 211 358 minecraft:raw_gold_block
fill 114 211 359 114 211 361 minecraft:cobbled_deepslate
fill 114 211 364 114 241 364 minecraft:andesite
setblock 115 211 325 minecraft:raw_gold_block
fill 115 211 326 115 211 328 minecraft:cobbled_deepslate
fill 115 211 337 116 211 337 minecraft:glowstone
fill 115 211 341 116 211 341 minecraft:glowstone
fill 115 211 352 115 211 354 minecraft:cobbled_deepslate
setblock 115 211 355 minecraft:raw_gold_block
fill 115 211 356 115 211 360 minecraft:cobbled_deepslate
setblock 115 211 361 minecraft:raw_gold_block
fill 116 211 325 116 211 327 minecraft:cobbled_deepslate
setblock 116 211 328 minecraft:raw_gold_block
fill 116 211 334 119 211 336 minecraft:iron_block
fill 116 211 338 116 211 340 minecraft:glowstone
fill 116 211 342 116 211 344 minecraft:gray_concrete
fill 116 211 347 116 211 349 minecraft:cobbled_deepslate
setblock 116 211 352 minecraft:raw_gold_block
fill 116 211 353 116 211 357 minecraft:cobbled_deepslate
setblock 116 211 358 minecraft:raw_gold_block
fill 116 211 359 116 211 361 minecraft:cobbled_deepslate
setblock 117 211 325 minecraft:raw_gold_block
fill 117 211 326 117 211 329 minecraft:cobbled_deepslate
setblock 117 211 331 minecraft:raw_gold_block
fill 117 211 337 121 211 338 minecraft:iron_block
fill 117 211 339 117 211 343 minecraft:gray_concrete
fill 117 211 344 122 211 344 minecraft:iron_block
setblock 117 211 348 minecraft:cobbled_deepslate
setblock 117 211 349 minecraft:raw_gold_block
fill 117 211 352 117 211 354 minecraft:cobbled_deepslate
setblock 117 211 355 minecraft:raw_gold_block
fill 117 211 356 117 211 360 minecraft:cobbled_deepslate
setblock 117 211 361 minecraft:raw_gold_block
fill 118 211 325 118 211 327 minecraft:cobbled_deepslate
setblock 118 211 328 minecraft:raw_gold_block
fill 118 211 329 118 211 332 minecraft:cobbled_deepslate
fill 118 211 339 118 211 342 minecraft:gray_concrete
fill 118 211 343 121 211 343 minecraft:iron_block
setblock 118 211 349 minecraft:cobbled_deepslate
setblock 118 211 352 minecraft:raw_gold_block
fill 118 211 353 118 211 357 minecraft:cobbled_deepslate
setblock 118 211 358 minecraft:raw_gold_block
fill 118 211 359 118 211 361 minecraft:cobbled_deepslate
setblock 119 211 325 minecraft:raw_gold_block
fill 119 211 326 119 211 330 minecraft:cobbled_deepslate
setblock 119 211 331 minecraft:raw_gold_block
fill 119 211 339 120 211 342 minecraft:iron_block
setblock 119 211 346 minecraft:cobbled_deepslate
fill 119 211 348 135 211 348 minecraft:cobbled_deepslate
setblock 119 211 349 minecraft:raw_gold_block
fill 119 211 352 119 211 354 minecraft:cobbled_deepslate
setblock 119 211 355 minecraft:raw_gold_block
fill 119 211 356 119 211 360 minecraft:cobbled_deepslate
setblock 119 211 361 minecraft:raw_gold_block
fill 120 211 325 120 211 327 minecraft:cobbled_deepslate
setblock 120 211 328 minecraft:raw_gold_block
fill 120 211 329 120 211 331 minecraft:cobbled_deepslate
setblock 120 211 334 minecraft:raw_gold_block
fill 120 211 335 120 211 336 minecraft:iron_block
setblock 120 211 345 minecraft:cobbled_deepslate
setblock 120 211 346 minecraft:raw_gold_block
fill 120 211 347 135 211 347 minecraft:cobbled_deepslate
setblock 120 211 349 minecraft:cobbled_deepslate
setblock 120 211 352 minecraft:raw_gold_block
fill 120 211 353 120 211 357 minecraft:cobbled_deepslate
setblock 120 211 358 minecraft:raw_gold_block
fill 120 211 359 120 211 361 minecraft:cobbled_deepslate
fill 121 211 322 121 241 322 minecraft:andesite
setblock 121 211 325 minecraft:raw_gold_block
fill 121 211 326 121 211 330 minecraft:cobbled_deepslate
setblock 121 211 331 minecraft:raw_gold_block
fill 121 211 332 121 211 335 minecraft:cobbled_deepslate
fill 121 211 336 123 211 336 minecraft:iron_block
fill 121 211 339 121 211 341 minecraft:iron_block
fill 121 211 342 135 211 342 minecraft:cobbled_deepslate
setblock 121 211 346 minecraft:cobbled_deepslate
setblock 121 211 349 minecraft:raw_gold_block
fill 121 211 352 121 211 354 minecraft:cobbled_deepslate
setblock 121 211 355 minecraft:raw_gold_block
fill 121 211 356 121 211 360 minecraft:cobbled_deepslate
setblock 121 211 361 minecraft:raw_gold_block
setblock 122 211 322 minecraft:gold_block
fill 122 211 325 122 211 327 minecraft:cobbled_deepslate
setblock 122 211 328 minecraft:raw_gold_block
fill 122 211 329 122 211 333 minecraft:cobbled_deepslate
setblock 122 211 334 minecraft:raw_gold_block
fill 122 211 337 122 211 338 minecraft:cobbled_deepslate
fill 122 211 341 123 211 341 minecraft:iron_block
setblock 122 211 343 minecraft:cobbled_deepslate
fill 122 211 345 135 211 345 minecraft:cobbled_deepslate
setblock 122 211 346 minecraft:raw_gold_block
setblock 122 211 349 minecraft:cobbled_deepslate
setblock 122 211 352 minecraft:raw_gold_block
fill 122 211 353 122 211 357 minecraft:cobbled_deepslate
setblock 122 211 358 minecraft:raw_gold_block
fill 122 211 359 122 211 361 minecraft:cobbled_deepslate
setblock 123 211 325 minecraft:raw_gold_block
fill 123 211 326 123 211 330 minecraft:cobbled_deepslate
setblock 123 211 331 minecraft:raw_gold_block
fill 123 211 332 123 211 335 minecraft:cobbled_deepslate
setblock 123 211 337 minecraft:raw_gold_block
fill 123 211 338 135 211 338 minecraft:cobbled_deepslate
setblock 123 211 343 minecraft:raw_gold_block
fill 123 211 344 135 211 344 minecraft:cobbled_deepslate
setblock 123 211 346 minecraft:cobbled_deepslate
setblock 123 211 349 minecraft:raw_gold_block
fill 123 211 352 123 211 354 minecraft:cobbled_deepslate
setblock 123 211 355 minecraft:raw_gold_block
fill 123 211 356 123 211 360 minecraft:cobbled_deepslate
setblock 123 211 361 minecraft:raw_gold_block
fill 124 211 325 124 211 327 minecraft:cobbled_deepslate
setblock 124 211 328 minecraft:raw_gold_block
fill 124 211 329 124 211 333 minecraft:cobbled_deepslate
setblock 124 211 334 minecraft:raw_gold_block
fill 124 211 335 124 211 337 minecraft:cobbled_deepslate
fill 124 211 339 135 211 339 minecraft:cobbled_deepslate
setblock 124 211 340 minecraft:raw_gold_block
fill 124 211 341 135 211 341 minecraft:cobbled_deepslate
setblock 124 211 343 minecraft:cobbled_deepslate
setblock 124 211 346 minecraft:raw_gold_block
setblock 124 211 349 minecraft:cobbled_deepslate
setblock 124 211 352 minecraft:raw_gold_block
fill 124 211 353 124 211 357 minecraft:cobbled_deepslate
setblock 124 211 358 minecraft:raw_gold_block
fill 124 211 359 124 211 361 minecraft:cobbled_deepslate
setblock 125 211 325 minecraft:raw_gold_block
fill 125 211 326 125 211 330 minecraft:cobbled_deepslate
setblock 125 211 331 minecraft:raw_gold_block
fill 125 211 332 125 211 336 minecraft:cobbled_deepslate
setblock 125 211 337 minecraft:raw_gold_block
setblock 125 211 340 minecraft:cobbled_deepslate
setblock 125 211 343 minecraft:raw_gold_block
setblock 125 211 346 minecraft:cobbled_deepslate
setblock 125 211 349 minecraft:raw_gold_block
fill 125 211 352 125 211 354 minecraft:cobbled_deepslate
setblock 125 211 355 minecraft:raw_gold_block
fill 125 211 356 125 211 360 minecraft:cobbled_deepslate
setblock 125 211 361 minecraft:raw_gold_block
fill 126 211 325 126 211 327 minecraft:cobbled_deepslate
setblock 126 211 328 minecraft:raw_gold_block
fill 126 211 329 126 211 333 minecraft:cobbled_deepslate
setblock 126 211 334 minecraft:raw_gold_block
fill 126 211 335 126 211 337 minecraft:cobbled_deepslate
setblock 126 211 340 minecraft:raw_gold_block
setblock 126 211 343 minecraft:cobbled_deepslate
setblock 126 211 346 minecraft:raw_gold_block
setblock 126 211 349 minecraft:cobbled_deepslate
setblock 126 211 352 minecraft:raw_gold_block
fill 126 211 353 126 211 357 minecraft:cobbled_deepslate
setblock 126 211 358 minecraft:raw_gold_block
fill 126 211 359 126 211 361 minecraft:cobbled_deepslate
setblock 127 211 325 minecraft:raw_gold_block
fill 127 211 326 127 211 330 minecraft:cobbled_deepslate
setblock 127 211 331 minecraft:raw_gold_block
fill 127 211 332 127 211 336 minecraft:cobbled_deepslate
setblock 127 211 337 minecraft:raw_gold_block
setblock 127 211 340 minecraft:cobbled_deepslate
setblock 127 211 343 minecraft:raw_gold_block
setblock 127 211 346 minecraft:cobbled_deepslate
setblock 127 211 349 minecraft:raw_gold_block
fill 127 211 352 127 211 354 minecraft:cobbled_deepslate
setblock 127 211 355 minecraft:raw_gold_block
fill 127 211 356 127 211 360 minecraft:cobbled_deepslate
setblock 127 211 361 minecraft:raw_gold_block
fill 128 211 325 128 211 327 minecraft:cobbled_deepslate
setblock 128 211 328 minecraft:raw_gold_block
fill 128 211 329 128 211 333 minecraft:cobbled_deepslate
setblock 128 211 334 minecraft:raw_gold_block
fill 128 211 335 128 211 337 minecraft:cobbled_deepslate
setblock 128 211 340 minecraft:raw_gold_block
setblock 128 211 343 minecraft:cobbled_deepslate
setblock 128 211 346 minecraft:raw_gold_block
setblock 128 211 349 minecraft:cobbled_deepslate
setblock 128 211 352 minecraft:raw_gold_block
fill 128 211 353 128 211 357 minecraft:cobbled_deepslate
setblock 128 211 358 minecraft:raw_gold_block
fill 128 211 359 128 211 361 minecraft:cobbled_deepslate
setblock 129 211 325 minecraft:raw_gold_block
fill 129 211 326 129 211 330 minecraft:cobbled_deepslate
setblock 129 211 331 minecraft:raw_gold_block
fill 129 211 332 129 211 336 minecraft:cobbled_deepslate
setblock 129 211 337 minecraft:raw_gold_block
setblock 129 211 340 minecraft:cobbled_deepslate
setblock 129 211 343 minecraft:raw_gold_block
setblock 129 211 346 minecraft:cobbled_deepslate
setblock 129 211 349 minecraft:raw_gold_block
fill 129 211 352 129 211 354 minecraft:cobbled_deepslate
setblock 129 211 355 minecraft:raw_gold_block
fill 129 211 356 129 211 360 minecraft:cobbled_deepslate
setblock 129 211 361 minecraft:raw_gold_block
setblock 130 211 322 minecraft:diamond_block
fill 130 211 325 130 211 327 minecraft:cobbled_deepslate
setblock 130 211 328 minecraft:raw_gold_block
fill 130 211 329 130 211 333 minecraft:cobbled_deepslate
setblock 130 211 334 minecraft:raw_gold_block
fill 130 211 335 130 211 337 minecraft:cobbled_deepslate
setblock 130 211 340 minecraft:raw_gold_block
setblock 130 211 343 minecraft:cobbled_deepslate
setblock 130 211 346 minecraft:raw_gold_block
setblock 130 211 349 minecraft:cobbled_deepslate
setblock 130 211 352 minecraft:raw_gold_block
fill 130 211 353 130 211 357 minecraft:cobbled_deepslate
setblock 130 211 358 minecraft:raw_gold_block
fill 130 211 359 130 211 361 minecraft:cobbled_deepslate
setblock 131 211 325 minecraft:raw_gold_block
fill 131 211 326 131 211 330 minecraft:cobbled_deepslate
setblock 131 211 331 minecraft:raw_gold_block
fill 131 211 332 131 211 336 minecraft:cobbled_deepslate
setblock 131 211 337 minecraft:raw_gold_block
setblock 131 211 340 minecraft:cobbled_deepslate
setblock 131 211 343 minecraft:raw_gold_block
setblock 131 211 346 minecraft:cobbled_deepslate
setblock 131 211 349 minecraft:raw_gold_block
fill 131 211 352 131 211 354 minecraft:cobbled_deepslate
setblock 131 211 355 minecraft:raw_gold_block
fill 131 211 356 131 211 360 minecraft:cobbled_deepslate
setblock 131 211 361 minecraft:raw_gold_block
fill 132 211 325 132 211 327 minecraft:cobbled_deepslate
setblock 132 211 328 minecraft:raw_gold_block
fill 132 211 329 132 211 333 minecraft:cobbled_deepslate
setblock 132 211 334 minecraft:raw_gold_block
fill 132 211 335 132 211 337 minecraft:cobbled_deepslate
setblock 132 211 340 minecraft:raw_gold_block
setblock 132 211 343 minecraft:cobbled_deepslate
setblock 132 211 346 minecraft:raw_gold_block
setblock 132 211 349 minecraft:cobbled_deepslate
setblock 132 211 352 minecraft:raw_gold_block
fill 132 211 353 132 211 357 minecraft:cobbled_deepslate
setblock 132 211 358 minecraft:raw_gold_block
fill 132 211 359 132 211 361 minecraft:cobbled_deepslate
setblock 133 211 325 minecraft:raw_gold_block
fill 133 211 326 133 211 330 minecraft:cobbled_deepslate
setblock 133 211 331 minecraft:raw_gold_block
fill 133 211 332 133 211 336 minecraft:cobbled_deepslate
setblock 133 211 337 minecraft:raw_gold_block
setblock 133 211 340 minecraft:cobbled_deepslate
setblock 133 211 343 minecraft:raw_gold_block
setblock 133 211 346 minecraft:cobbled_deepslate
setblock 133 211 349 minecraft:raw_gold_block
fill 133 211 352 133 211 354 minecraft:cobbled_deepslate
setblock 133 211 355 minecraft:raw_gold_block
fill 133 211 356 133 211 360 minecraft:cobbled_deepslate
setblock 133 211 361 minecraft:raw_gold_block
setblock 133 211 364 minecraft:raw_gold_block
fill 134 211 325 134 211 327 minecraft:cobbled_deepslate
setblock 134 211 328 minecraft:raw_gold_block
fill 134 211 329 134 211 333 minecraft:cobbled_deepslate
setblock 134 211 334 minecraft:raw_gold_block
fill 134 211 335 134 211 337 minecraft:cobbled_deepslate
setblock 134 211 340 minecraft:raw_gold_block
setblock 134 211 343 minecraft:cobbled_deepslate
setblock 134 211 346 minecraft:raw_gold_block
setblock 134 211 349 minecraft:cobbled_deepslate
setblock 134 211 352 minecraft:raw_gold_block
fill 134 211 353 134 211 357 minecraft:cobbled_deepslate
setblock 134 211 358 minecraft:raw_gold_block
fill 134 211 359 134 211 361 minecraft:cobbled_deepslate
setblock 135 211 325 minecraft:raw_gold_block
fill 135 211 326 135 211 330 minecraft:cobbled_deepslate
setblock 135 211 331 minecraft:raw_gold_block
fill 135 211 332 135 211 336 minecraft:cobbled_deepslate
setblock 135 211 337 minecraft:raw_gold_block
setblock 135 211 340 minecraft:cobbled_deepslate
setblock 135 211 343 minecraft:raw_gold_block
setblock 135 211 346 minecraft:cobbled_deepslate
setblock 135 211 349 minecraft:raw_gold_block
fill 135 211 352 135 211 354 minecraft:cobbled_deepslate
setblock 135 211 355 minecraft:raw_gold_block
fill 135 211 356 135 211 360 minecraft:cobbled_deepslate
setblock 135 211 361 minecraft:raw_gold_block
setblock 136 211 334 minecraft:raw_gold_block
fill 102 212 322 102 218 322 minecraft:andesite
setblock 107 212 364 minecraft:raw_iron_block
setblock 112 212 322 minecraft:diamond_block
fill 122 212 322 122 227 322 minecraft:andesite
fill 130 212 322 130 241 322 minecraft:andesite
fill 133 212 364 133 241 364 minecraft:andesite
fill 136 212 334 136 241 334 minecraft:andesite
setblock 94 213 337 minecraft:diamond_block
fill 94 213 338 94 238 338 minecraft:andesite
fill 94 213 351 94 225 352 minecraft:andesite
setblock 94 213 353 minecraft:raw_gold_block
fill 107 213 364 107 237 364 minecraft:andesite
fill 112 213 322 112 217 322 minecraft:andesite
setblock 126 213 322 minecraft:raw_iron_block
setblock 131 213 322 minecraft:diamond_block
fill 132 213 322 132 241 322 minecraft:andesite
fill 94 214 337 94 241 337 minecraft:andesite
setblock 94 214 342 minecraft:raw_gold_block
fill 94 214 353 94 218 353 minecraft:andesite
setblock 99 214 322 minecraft:diamond_block
setblock 110 214 322 minecraft:gold_block
fill 126 214 322 126 237 322 minecraft:andesite
fill 131 214 322 131 241 322 minecraft:andesite
fill 94 215 331 94 229 333 minecraft:andesite
setblock 94 215 334 minecraft:gold_block
fill 94 215 342 94 218 342 minecraft:andesite
setblock 95 215 340 minecraft:stripped_spruce_log
fill 95 215 341 95 215 344 minecraft:stone
setblock 95 215 345 minecraft:stripped_spruce_log
fill 95 215 346 95 215 349 minecraft:stone
setblock 95 215 359 minecraft:stone
setblock 95 215 360 minecraft:stripped_spruce_log
fill 95 215 361 95 215 363 minecraft:stone
setblock 96 215 343 minecraft:stone
setblock 96 215 344 minecraft:stripped_spruce_log
fill 96 215 345 96 217 346 minecraft:stone
setblock 96 215 363 minecraft:stone
setblock 97 215 363 minecraft:stripped_spruce_log
fill 98 215 363 101 215 363 minecraft:stone
fill 99 215 322 99 216 322 minecraft:andesite
fill 99 215 323 101 215 323 minecraft:stone
fill 100 215 362 102 215 362 minecraft:stone
setblock 102 215 323 minecraft:stripped_spruce_log
fill 102 215 324 105 215 324 minecraft:stone
fill 102 215 336 102 218 342 minecraft:iron_block
setblock 102 215 363 minecraft:stripped_spruce_log
fill 103 215 323 106 215 323 minecraft:stone
fill 103 215 334 103 218 335 minecraft:iron_block
fill 103 215 343 103 218 344 minecraft:iron_block
setblock 103 215 362 minecraft:stripped_spruce_log
fill 103 215 363 106 215 363 minecraft:stone
fill 104 215 332 104 218 333 minecraft:iron_block
fill 104 215 345 104 218 346 minecraft:iron_block
fill 104 215 362 107 215 362 minecraft:stone
fill 105 215 331 105 215 332 minecraft:iron_block
fill 105 215 346 105 215 347 minecraft:iron_block
setblock 106 215 324 minecraft:stripped_spruce_log
fill 106 215 330 106 218 331 minecraft:iron_block
fill 106 215 347 106 218 348 minecraft:iron_block
setblock 107 215 323 minecraft:stripped_spruce_log
fill 107 215 324 110 215 324 minecraft:stone
fill 107 215 330 107 218 330 minecraft:iron_block
fill 107 215 348 107 218 348 minecraft:iron_block
setblock 107 215 363 minecraft:stripped_spruce_log
fill 108 215 323 111 215 323 minecraft:stone
fill 108 215 329 109 218 329 minecraft:iron_block
fill 108 215 349 109 218 349 minecraft:iron_block
fill 108 215 363 111 215 363 minecraft:stone
fill 110 215 322 110 237 322 minecraft:andesite
fill 110 215 328 116 218 328 minecraft:iron_block
fill 110 215 350 116 218 350 minecraft:iron_block
setblock 112 215 323 minecraft:stripped_spruce_log
fill 113 215 323 116 215 323 minecraft:stone
setblock 117 215 323 minecraft:stripped_spruce_log
fill 117 215 324 120 215 324 minecraft:stone
fill 117 215 329 118 218 329 minecraft:iron_block
fill 117 215 349 118 218 349 minecraft:iron_block
setblock 117 215 363 minecraft:stripped_spruce_log
fill 118 215 323 121 215 323 minecraft:stone
fill 118 215 363 121 215 363 minecraft:stone
fill 119 215 330 120 218 330 minecraft:iron_block
fill 119 215 348 120 218 348 minecraft:iron_block
setblock 120 215 325 minecraft:stripped_spruce_log
fill 120 215 331 121 215 331 minecraft:iron_block
fill 120 215 347 121 215 347 minecraft:iron_block
fill 120 215 362 122 215 362 minecraft:stone
setblock 121 215 324 minecraft:stripped_spruce_log
fill 121 215 325 124 215 325 minecraft:stone
fill 121 215 332 122 218 332 minecraft:iron_block
fill 121 215 346 122 218 346 minecraft:iron_block
setblock 122 215 323 minecraft:stripped_spruce_log
fill 122 215 324 125 215 324 minecraft:stone
fill 122 215 333 122 218 333 minecraft:iron_block
fill 122 215 345 122 218 345 minecraft:iron_block
setblock 122 215 363 minecraft:stripped_spruce_log
fill 123 215 323 126 215 323 minecraft:stone
fill 123 215 334 123 218 335 minecraft:iron_block
fill 123 215 343 123 218 344 minecraft:iron_block
fill 123 215 360 123 218 360 minecraft:cobbled_deepslate
setblock 123 215 361 minecraft:stone
setblock 123 215 362 minecraft:stripped_spruce_log
fill 123 215 363 126 215 363 minecraft:stone
fill 124 215 336 124 218 342 minecraft:iron_block
setblock 124 215 361 minecraft:stripped_spruce_log
fill 124 215 362 127 215 362 minecraft:stone
setblock 125 215 325 minecraft:stripped_spruce_log
fill 125 215 361 128 215 361 minecraft:stone
setblock 126 215 324 minecraft:stripped_spruce_log
fill 126 215 325 129 215 325 minecraft:stone
setblock 127 215 323 minecraft:stripped_spruce_log
fill 127 215 324 130 215 324 minecraft:stone
setblock 127 215 363 minecraft:stripped_spruce_log
fill 128 215 323 131 215 323 minecraft:stone
setblock 128 215 362 minecraft:stripped_spruce_log
fill 128 215 363 131 215 363 minecraft:stone
setblock 129 215 361 minecraft:stripped_spruce_log
fill 129 215 362 132 215 362 minecraft:stone
setblock 131 215 324 minecraft:stripped_spruce_log
setblock 132 215 323 minecraft:stripped_spruce_log
setblock 132 215 324 minecraft:stone
fill 132 215 360 135 215 360 minecraft:stripped_spruce_log
setblock 132 215 363 minecraft:stripped_spruce_log
fill 133 215 323 135 216 323 minecraft:stone
fill 133 215 359 133 219 359 minecraft:stripped_spruce_log
fill 133 215 361 133 215 362 minecraft:stripped_spruce_log
fill 133 215 363 135 216 363 minecraft:stone
setblock 134 215 361 minecraft:stripped_spruce_log
fill 134 215 362 135 215 362 minecraft:stone
setblock 135 215 324 minecraft:stone
fill 135 215 358 135 215 359 minecraft:stone
fill 135 215 361 135 217 361 minecraft:stone
fill 136 215 332 136 241 332 minecraft:andesite
setblock 136 215 333 minecraft:diamond_block
setblock 136 215 338 minecraft:diamond_block
fill 94 216 334 94 241 334 minecraft:andesite
setblock 94 216 362 minecraft:gold_block
fill 95 216 341 95 216 343 minecraft:stone
setblock 95 216 344 minecraft:stripped_spruce_log
fill 95 216 345 95 216 348 minecraft:stone
setblock 95 216 349 minecraft:stripped_spruce_log
fill 95 216 350 95 219 350 minecraft:stone
fill 95 216 362 95 216 363 minecraft:stone
setblock 96 216 343 minecraft:stripped_spruce_log
fill 96 216 344 96 219 344 minecraft:stone
setblock 96 216 347 minecraft:stone
setblock 96 216 363 minecraft:stripped_spruce_log
setblock 97 216 325 minecraft:light[level=12]
setblock 97 216 332 minecraft:light[level=12]
setblock 97 216 339 minecraft:light[level=12]
setblock 97 216 346 minecraft:light[level=12]
setblock 97 216 353 minecraft:light[level=12]
setblock 97 216 360 minecraft:light[level=12]
fill 97 216 363 100 216 363 minecraft:stone
fill 99 216 323 100 216 323 minecraft:stone
fill 100 216 361 101 217 362 minecraft:raw_gold_block
setblock 101 216 323 minecraft:stripped_spruce_log
fill 101 216 336 101 216 342 minecraft:iron_block
fill 101 216 359 101 217 360 minecraft:raw_gold_block
setblock 101 216 363 minecraft:stripped_spruce_log
fill 102 216 323 104 216 324 minecraft:stone
fill 102 216 334 102 217 335 minecraft:iron_block
fill 102 216 343 102 217 344 minecraft:iron_block
fill 102 216 361 102 217 361 minecraft:raw_gold_block
setblock 102 216 362 minecraft:stripped_spruce_log
fill 102 216 363 105 216 363 minecraft:stone
fill 103 216 332 103 217 333 minecraft:iron_block
fill 103 216 336 103 217 342 minecraft:iron_block
fill 103 216 345 103 217 346 minecraft:iron_block
fill 103 216 362 104 216 362 minecraft:stone
setblock 104 216 325 minecraft:light[level=12]
fill 104 216 331 104 217 331 minecraft:iron_block
fill 104 216 334 104 217 336 minecraft:iron_block
setblock 104 216 339 minecraft:light[level=12]
fill 104 216 342 104 217 344 minecraft:iron_block
fill 104 216 347 104 217 347 minecraft:iron_block
setblock 104 216 353 minecraft:light[level=12]
setblock 104 216 360 minecraft:light[level=12]
setblock 105 216 323 minecraft:stone
setblock 105 216 324 minecraft:stripped_spruce_log
fill 105 216 330 105 217 330 minecraft:iron_block
fill 105 216 331 105 217 331 minecraft:light_gray_concrete
fill 105 216 332 105 217 333 minecraft:iron_block
fill 105 216 345 105 217 346 minecraft:iron_block
fill 105 216 347 105 217 347 minecraft:light_gray_concrete
fill 105 216 348 105 217 348 minecraft:iron_block
setblock 106 216 323 minecraft:stripped_spruce_log
fill 106 216 324 109 216 324 minecraft:stone
fill 106 216 329 107 217 329 minecraft:iron_block
fill 106 216 332 106 217 332 minecraft:light_gray_concrete
fill 106 216 346 106 217 346 minecraft:light_gray_concrete
fill 106 216 349 107 217 349 minecraft:iron_block
setblock 106 216 363 minecraft:stripped_spruce_log
fill 107 216 323 110 216 323 minecraft:stone
fill 107 216 331 107 217 331 minecraft:iron_block
fill 107 216 333 107 217 333 minecraft:light_gray_concrete
fill 107 216 345 107 217 345 minecraft:light_gray_concrete
fill 107 216 347 107 217 347 minecraft:iron_block
fill 107 216 363 109 216 363 minecraft:stone
fill 108 216 328 109 217 328 minecraft:iron_block
fill 108 216 330 110 217 330 minecraft:iron_block
fill 108 216 334 108 217 334 minecraft:light_gray_concrete
fill 108 216 338 109 217 340 minecraft:white_concrete
fill 108 216 344 108 217 344 minecraft:light_gray_concrete
fill 108 216 348 110 217 348 minecraft:iron_block
fill 108 216 350 109 217 350 minecraft:iron_block
fill 109 216 335 109 217 335 minecraft:light_gray_concrete
fill 109 216 336 109 217 337 minecraft:white_concrete
fill 109 216 341 109 217 342 minecraft:white_concrete
fill 109 216 343 109 217 343 minecraft:light_gray_concrete
fill 110 216 327 116 217 327 minecraft:iron_block
fill 110 216 329 116 217 329 minecraft:iron_block
schedule function dropper:buildpart/74_7 1t
