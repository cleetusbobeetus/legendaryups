setblock 17 51 362 minecraft:honeycomb_block
setblock 17 51 363 minecraft:yellow_terracotta
fill 18 51 323 18 54 323 minecraft:honeycomb_block
setblock 18 51 362 minecraft:yellow_terracotta
fill 18 51 363 21 51 363 minecraft:honeycomb_block
fill 19 51 362 22 51 362 minecraft:honeycomb_block
setblock 20 51 325 minecraft:yellow_terracotta
setblock 21 51 324 minecraft:yellow_terracotta
fill 22 51 322 22 106 322 minecraft:honeycomb_block
setblock 22 51 323 minecraft:yellow_terracotta
setblock 22 51 324 minecraft:honeycomb_block
setblock 22 51 363 minecraft:yellow_terracotta
fill 23 51 323 23 52 323 minecraft:honeycomb_block
setblock 23 51 362 minecraft:yellow_terracotta
fill 23 51 363 25 51 363 minecraft:honeycomb_block
setblock 24 51 325 minecraft:light[level=12]
setblock 24 51 332 minecraft:light[level=12]
setblock 24 51 339 minecraft:light[level=12]
setblock 24 51 346 minecraft:light[level=12]
setblock 24 51 353 minecraft:light[level=12]
setblock 24 51 360 minecraft:light[level=12]
setblock 31 51 325 minecraft:light[level=12]
setblock 31 51 332 minecraft:light[level=12]
setblock 31 51 339 minecraft:light[level=12]
setblock 31 51 346 minecraft:light[level=12]
setblock 31 51 353 minecraft:light[level=12]
setblock 31 51 360 minecraft:light[level=12]
setblock 37 51 323 minecraft:yellow_terracotta
fill 38 51 323 38 54 323 minecraft:honeycomb_block
setblock 38 51 325 minecraft:light[level=12]
setblock 38 51 332 minecraft:light[level=12]
setblock 38 51 339 minecraft:light[level=12]
setblock 38 51 346 minecraft:light[level=12]
setblock 38 51 353 minecraft:light[level=12]
setblock 38 51 360 minecraft:light[level=12]
setblock 39 51 325 minecraft:honeycomb_block
setblock 39 51 326 minecraft:yellow_terracotta
fill 39 51 327 39 51 330 minecraft:honeycomb_block
setblock 39 51 331 minecraft:yellow_terracotta
fill 39 51 332 39 54 332 minecraft:honeycomb_block
setblock 39 51 342 minecraft:honeycomb_block
setblock 39 51 346 minecraft:yellow_terracotta
fill 39 51 347 39 53 347 minecraft:honeycomb_block
setblock 39 51 351 minecraft:yellow_terracotta
fill 39 51 352 39 52 352 minecraft:honeycomb_block
setblock 40 51 325 minecraft:yellow_terracotta
fill 40 51 326 40 54 326 minecraft:honeycomb_block
setblock 40 51 329 minecraft:honeycomb_block
setblock 40 51 330 minecraft:yellow_terracotta
fill 40 51 331 40 54 331 minecraft:honeycomb_block
setblock 40 51 334 minecraft:honeycomb_block
setblock 40 51 335 minecraft:yellow_terracotta
fill 40 51 336 40 54 336 minecraft:honeycomb_block
setblock 40 51 340 minecraft:yellow_terracotta
fill 40 51 341 40 53 341 minecraft:honeycomb_block
setblock 40 51 345 minecraft:yellow_terracotta
fill 40 51 346 40 54 346 minecraft:honeycomb_block
setblock 40 51 350 minecraft:yellow_terracotta
fill 40 51 351 40 54 351 minecraft:honeycomb_block
setblock 40 51 354 minecraft:honeycomb_block
setblock 41 51 324 minecraft:yellow_terracotta
fill 41 51 325 41 54 325 minecraft:honeycomb_block
setblock 41 51 329 minecraft:yellow_terracotta
fill 41 51 330 41 54 330 minecraft:honeycomb_block
setblock 41 51 334 minecraft:yellow_terracotta
fill 41 51 335 42 54 335 minecraft:honeycomb_block
setblock 41 51 339 minecraft:yellow_terracotta
fill 41 51 340 41 54 340 minecraft:honeycomb_block
setblock 41 51 344 minecraft:yellow_terracotta
fill 41 51 345 41 54 345 minecraft:honeycomb_block
setblock 41 51 349 minecraft:yellow_terracotta
fill 41 51 350 41 54 350 minecraft:honeycomb_block
setblock 41 51 354 minecraft:yellow_terracotta
fill 41 51 355 41 54 355 minecraft:honeycomb_block
fill 42 51 326 42 91 326 minecraft:honeycomb_block
fill 42 51 329 42 80 329 minecraft:honeycomb_block
fill 42 51 336 42 123 337 minecraft:honeycomb_block
setblock 42 51 338 minecraft:yellow_terracotta
setblock 42 51 356 minecraft:orange_terracotta
fill 0 52 342 0 145 342 minecraft:honeycomb_block
fill 1 52 322 1 84 322 minecraft:honeycomb_block
setblock 1 52 323 minecraft:yellow_terracotta
fill 1 52 324 1 52 327 minecraft:honeycomb_block
setblock 1 52 328 minecraft:yellow_terracotta
fill 1 52 329 1 52 332 minecraft:honeycomb_block
setblock 1 52 333 minecraft:yellow_terracotta
fill 1 52 334 1 52 337 minecraft:honeycomb_block
setblock 1 52 338 minecraft:yellow_terracotta
fill 1 52 339 1 53 339 minecraft:honeycomb_block
setblock 1 52 343 minecraft:yellow_terracotta
fill 1 52 344 1 53 344 minecraft:honeycomb_block
setblock 1 52 348 minecraft:yellow_terracotta
fill 1 52 349 1 55 349 minecraft:honeycomb_block
setblock 1 52 353 minecraft:yellow_terracotta
fill 1 52 354 1 55 354 minecraft:honeycomb_block
setblock 1 52 363 minecraft:yellow_terracotta
fill 2 52 323 2 52 326 minecraft:honeycomb_block
setblock 2 52 327 minecraft:yellow_terracotta
fill 2 52 328 2 52 331 minecraft:honeycomb_block
setblock 2 52 332 minecraft:yellow_terracotta
fill 2 52 333 2 53 335 minecraft:honeycomb_block
setblock 2 52 344 minecraft:brown_terracotta
setblock 2 52 348 minecraft:honeycomb_block
fill 2 52 363 3 52 363 minecraft:honeycomb_block
setblock 3 52 322 minecraft:yellow_concrete
fill 3 52 323 4 52 324 minecraft:honeycomb_block
setblock 3 52 326 minecraft:yellow_terracotta
fill 3 52 327 3 54 327 minecraft:honeycomb_block
setblock 3 52 331 minecraft:yellow_terracotta
setblock 3 52 332 minecraft:honeycomb_block
setblock 4 52 325 minecraft:yellow_terracotta
fill 4 52 358 4 62 358 minecraft:brown_terracotta
setblock 5 52 323 minecraft:honeycomb_block
setblock 5 52 324 minecraft:yellow_terracotta
setblock 6 52 323 minecraft:yellow_terracotta
fill 6 52 324 7 52 324 minecraft:honeycomb_block
setblock 6 52 363 minecraft:honey_block
fill 7 52 323 10 52 323 minecraft:honeycomb_block
setblock 11 52 323 minecraft:yellow_terracotta
fill 12 52 323 15 52 323 minecraft:honeycomb_block
fill 14 52 363 15 52 363 minecraft:honeycomb_block
setblock 15 52 324 minecraft:yellow_terracotta
setblock 16 52 323 minecraft:yellow_terracotta
fill 16 52 324 19 52 324 minecraft:honeycomb_block
setblock 16 52 363 minecraft:yellow_terracotta
fill 17 52 323 17 55 323 minecraft:honeycomb_block
setblock 17 52 362 minecraft:yellow_terracotta
fill 17 52 363 20 52 363 minecraft:honeycomb_block
fill 18 52 362 21 52 362 minecraft:honeycomb_block
fill 19 52 322 20 52 323 minecraft:honeycomb_block
setblock 20 52 324 minecraft:yellow_terracotta
fill 21 52 322 21 56 322 minecraft:honeycomb_block
setblock 21 52 323 minecraft:yellow_terracotta
setblock 21 52 324 minecraft:honeycomb_block
setblock 21 52 363 minecraft:yellow_terracotta
fill 22 52 323 22 53 323 minecraft:honeycomb_block
fill 22 52 363 24 52 363 minecraft:honeycomb_block
fill 25 52 322 25 184 322 minecraft:honeycomb_block
setblock 25 52 363 minecraft:honey_block
setblock 36 52 323 minecraft:honey_block
fill 37 52 323 37 55 323 minecraft:honeycomb_block
fill 39 52 326 39 52 329 minecraft:honeycomb_block
setblock 39 52 330 minecraft:yellow_terracotta
fill 39 52 331 39 55 331 minecraft:honeycomb_block
fill 39 52 333 39 52 334 minecraft:honeycomb_block
setblock 39 52 345 minecraft:yellow_terracotta
fill 39 52 346 39 53 346 minecraft:honeycomb_block
setblock 39 52 350 minecraft:yellow_terracotta
fill 39 52 351 39 54 351 minecraft:honeycomb_block
setblock 40 52 324 minecraft:yellow_terracotta
fill 40 52 325 40 55 325 minecraft:honeycomb_block
setblock 40 52 328 minecraft:honeycomb_block
setblock 40 52 329 minecraft:yellow_terracotta
fill 40 52 330 40 55 330 minecraft:honeycomb_block
setblock 40 52 333 minecraft:honeycomb_block
setblock 40 52 334 minecraft:yellow_terracotta
fill 40 52 335 40 55 335 minecraft:honeycomb_block
setblock 40 52 339 minecraft:yellow_terracotta
fill 40 52 340 40 53 340 minecraft:honeycomb_block
setblock 40 52 344 minecraft:yellow_terracotta
fill 40 52 345 40 54 345 minecraft:honeycomb_block
setblock 40 52 349 minecraft:yellow_terracotta
fill 40 52 350 40 55 350 minecraft:honeycomb_block
setblock 40 52 354 minecraft:yellow_terracotta
setblock 41 52 323 minecraft:yellow_terracotta
fill 41 52 324 41 55 324 minecraft:honeycomb_block
setblock 41 52 328 minecraft:yellow_terracotta
fill 41 52 329 41 55 329 minecraft:honeycomb_block
setblock 41 52 333 minecraft:yellow_terracotta
fill 41 52 334 41 55 334 minecraft:honeycomb_block
setblock 41 52 338 minecraft:yellow_terracotta
fill 41 52 339 41 55 339 minecraft:honeycomb_block
setblock 41 52 343 minecraft:yellow_terracotta
fill 41 52 344 41 55 344 minecraft:honeycomb_block
setblock 41 52 348 minecraft:yellow_terracotta
fill 41 52 349 41 55 349 minecraft:honeycomb_block
setblock 41 52 353 minecraft:yellow_terracotta
fill 41 52 354 41 55 354 minecraft:honeycomb_block
setblock 41 52 362 minecraft:honey_block
fill 42 52 338 42 170 338 minecraft:honeycomb_block
fill 42 52 356 42 125 356 minecraft:honeycomb_block
fill 1 53 323 1 53 326 minecraft:honeycomb_block
setblock 1 53 327 minecraft:yellow_terracotta
fill 1 53 328 1 53 331 minecraft:honeycomb_block
setblock 1 53 332 minecraft:yellow_terracotta
fill 1 53 333 1 53 336 minecraft:honeycomb_block
setblock 1 53 337 minecraft:yellow_terracotta
fill 1 53 338 1 56 338 minecraft:honeycomb_block
setblock 1 53 347 minecraft:yellow_terracotta
fill 1 53 348 1 55 348 minecraft:honeycomb_block
setblock 1 53 352 minecraft:yellow_terracotta
fill 1 53 353 1 56 353 minecraft:honeycomb_block
setblock 2 53 322 minecraft:yellow_concrete
fill 2 53 323 2 53 325 minecraft:honeycomb_block
setblock 2 53 326 minecraft:yellow_terracotta
fill 2 53 327 2 53 330 minecraft:honeycomb_block
setblock 2 53 331 minecraft:yellow_terracotta
fill 2 53 332 2 56 332 minecraft:honeycomb_block
fill 3 53 322 3 53 324 minecraft:honeycomb_block
setblock 3 53 325 minecraft:yellow_terracotta
setblock 3 53 326 minecraft:honeycomb_block
setblock 3 53 330 minecraft:yellow_terracotta
fill 3 53 331 3 54 331 minecraft:honeycomb_block
setblock 4 53 323 minecraft:honeycomb_block
setblock 4 53 324 minecraft:yellow_terracotta
setblock 5 53 323 minecraft:yellow_terracotta
setblock 5 53 324 minecraft:honeycomb_block
fill 6 53 323 8 53 323 minecraft:honeycomb_block
setblock 11 53 323 minecraft:honey_block
fill 12 53 323 14 53 323 minecraft:honeycomb_block
setblock 12 53 363 minecraft:honey_block
setblock 14 53 363 minecraft:honeycomb_block
setblock 15 53 323 minecraft:yellow_terracotta
setblock 15 53 363 minecraft:yellow_terracotta
fill 16 53 323 16 53 324 minecraft:honeycomb_block
fill 16 53 363 19 53 363 minecraft:honeycomb_block
fill 17 53 324 18 53 324 minecraft:honeycomb_block
fill 18 53 362 20 53 362 minecraft:honeycomb_block
fill 19 53 322 19 53 323 minecraft:honeycomb_block
setblock 19 53 324 minecraft:yellow_terracotta
fill 19 53 364 23 62 364 minecraft:honeycomb_block
fill 20 53 322 20 73 322 minecraft:honeycomb_block
setblock 20 53 323 minecraft:yellow_terracotta
setblock 20 53 363 minecraft:yellow_terracotta
fill 21 53 323 21 54 323 minecraft:honeycomb_block
fill 21 53 363 23 53 363 minecraft:honeycomb_block
setblock 24 53 364 minecraft:yellow_concrete
fill 25 53 364 34 67 364 minecraft:honeycomb_block
setblock 30 53 323 minecraft:honey_block
setblock 31 53 363 minecraft:honey_block
setblock 39 53 324 minecraft:yellow_terracotta
fill 39 53 326 39 53 328 minecraft:honeycomb_block
setblock 39 53 329 minecraft:yellow_terracotta
fill 39 53 330 39 56 330 minecraft:honeycomb_block
setblock 39 53 333 minecraft:honeycomb_block
setblock 39 53 334 minecraft:yellow_terracotta
fill 39 53 335 39 56 335 minecraft:honeycomb_block
fill 39 53 345 39 59 345 minecraft:flowering_azalea_leaves[persistent=true]
setblock 39 53 349 minecraft:yellow_terracotta
fill 39 53 350 39 54 350 minecraft:honeycomb_block
setblock 40 53 323 minecraft:yellow_terracotta
fill 40 53 324 40 54 324 minecraft:honeycomb_block
setblock 40 53 328 minecraft:yellow_terracotta
fill 40 53 329 40 56 329 minecraft:honeycomb_block
setblock 40 53 332 minecraft:honeycomb_block
setblock 40 53 333 minecraft:yellow_terracotta
fill 40 53 334 40 56 334 minecraft:honeycomb_block
setblock 40 53 338 minecraft:yellow_terracotta
fill 40 53 339 40 56 339 minecraft:honeycomb_block
setblock 40 53 343 minecraft:yellow_terracotta
fill 40 53 344 40 54 344 minecraft:honeycomb_block
setblock 40 53 348 minecraft:yellow_terracotta
fill 40 53 349 40 56 349 minecraft:honeycomb_block
setblock 40 53 353 minecraft:yellow_terracotta
fill 40 53 354 40 56 354 minecraft:honeycomb_block
fill 41 53 323 41 56 323 minecraft:honeycomb_block
setblock 41 53 327 minecraft:yellow_terracotta
fill 41 53 328 41 56 328 minecraft:honeycomb_block
setblock 41 53 332 minecraft:yellow_terracotta
fill 41 53 333 41 56 333 minecraft:honeycomb_block
setblock 41 53 337 minecraft:yellow_terracotta
fill 41 53 338 41 56 338 minecraft:honeycomb_block
setblock 41 53 342 minecraft:yellow_terracotta
fill 41 53 343 41 56 343 minecraft:honeycomb_block
setblock 41 53 347 minecraft:yellow_terracotta
fill 41 53 348 41 56 348 minecraft:honeycomb_block
setblock 41 53 352 minecraft:yellow_terracotta
fill 41 53 353 41 56 353 minecraft:honeycomb_block
fill 42 53 332 42 78 332 minecraft:honeycomb_block
setblock 42 53 333 minecraft:yellow_concrete
setblock 0 54 337 minecraft:yellow_terracotta
fill 1 54 323 1 54 325 minecraft:honeycomb_block
setblock 1 54 326 minecraft:yellow_terracotta
fill 1 54 327 1 54 330 minecraft:honeycomb_block
setblock 1 54 331 minecraft:yellow_terracotta
fill 1 54 332 1 54 335 minecraft:honeycomb_block
setblock 1 54 336 minecraft:yellow_terracotta
fill 1 54 337 1 57 337 minecraft:honeycomb_block
setblock 1 54 346 minecraft:yellow_terracotta
setblock 1 54 347 minecraft:honeycomb_block
setblock 1 54 351 minecraft:yellow_terracotta
fill 1 54 352 1 57 352 minecraft:honeycomb_block
setblock 1 54 356 minecraft:yellow_terracotta
fill 1 54 364 9 59 364 minecraft:honeycomb_block
fill 2 54 322 2 54 324 minecraft:honeycomb_block
setblock 2 54 325 minecraft:yellow_terracotta
fill 2 54 326 2 54 329 minecraft:honeycomb_block
setblock 2 54 330 minecraft:yellow_terracotta
fill 2 54 331 2 57 331 minecraft:honeycomb_block
fill 2 54 333 2 54 334 minecraft:honeycomb_block
fill 3 54 322 3 54 323 minecraft:honeycomb_block
setblock 3 54 324 minecraft:yellow_terracotta
setblock 3 54 329 minecraft:yellow_terracotta
setblock 3 54 330 minecraft:honeycomb_block
setblock 4 54 323 minecraft:yellow_terracotta
fill 5 54 323 6 54 323 minecraft:honeycomb_block
setblock 10 54 364 minecraft:yellow_concrete
fill 11 54 364 11 97 364 minecraft:honeycomb_block
setblock 13 54 323 minecraft:honeycomb_block
setblock 14 54 323 minecraft:yellow_terracotta
setblock 14 54 363 minecraft:yellow_terracotta
fill 15 54 323 16 56 323 minecraft:honeycomb_block
fill 15 54 363 18 54 363 minecraft:honeycomb_block
fill 18 54 362 18 55 362 minecraft:honeycomb_block
fill 19 54 322 19 118 322 minecraft:honeycomb_block
setblock 19 54 323 minecraft:yellow_terracotta
setblock 19 54 363 minecraft:yellow_terracotta
setblock 20 54 323 minecraft:honeycomb_block
fill 20 54 363 22 54 363 minecraft:honeycomb_block
setblock 24 54 323 minecraft:honey_block
fill 24 54 364 24 134 364 minecraft:honeycomb_block
setblock 37 54 363 minecraft:honey_block
setblock 39 54 323 minecraft:yellow_terracotta
setblock 39 54 327 minecraft:honeycomb_block
setblock 39 54 328 minecraft:yellow_terracotta
fill 39 54 329 39 57 329 minecraft:honeycomb_block
setblock 39 54 333 minecraft:yellow_terracotta
fill 39 54 334 39 57 334 minecraft:honeycomb_block
setblock 39 54 348 minecraft:yellow_terracotta
setblock 39 54 349 minecraft:honeycomb_block
fill 40 54 323 40 57 323 minecraft:honeycomb_block
setblock 40 54 327 minecraft:yellow_terracotta
fill 40 54 328 40 57 328 minecraft:honeycomb_block
setblock 40 54 332 minecraft:yellow_terracotta
fill 40 54 333 40 57 333 minecraft:honeycomb_block
setblock 40 54 337 minecraft:yellow_terracotta
fill 40 54 338 40 57 338 minecraft:honeycomb_block
setblock 40 54 343 minecraft:honeycomb_block
setblock 40 54 347 minecraft:yellow_terracotta
fill 40 54 348 40 56 348 minecraft:honeycomb_block
setblock 40 54 352 minecraft:yellow_terracotta
fill 40 54 353 40 57 353 minecraft:honeycomb_block
setblock 41 54 326 minecraft:yellow_terracotta
fill 41 54 327 41 57 327 minecraft:honeycomb_block
setblock 41 54 331 minecraft:yellow_terracotta
fill 41 54 332 41 57 332 minecraft:honeycomb_block
setblock 41 54 336 minecraft:yellow_terracotta
fill 41 54 337 41 57 337 minecraft:honeycomb_block
setblock 41 54 341 minecraft:yellow_terracotta
fill 41 54 342 41 57 342 minecraft:honeycomb_block
setblock 41 54 346 minecraft:yellow_terracotta
fill 41 54 347 41 57 347 minecraft:honeycomb_block
setblock 41 54 351 minecraft:yellow_terracotta
fill 41 54 352 41 57 352 minecraft:honeycomb_block
setblock 41 54 356 minecraft:yellow_terracotta
fill 42 54 331 42 64 331 minecraft:honeycomb_block
fill 42 54 333 42 179 333 minecraft:honeycomb_block
fill 0 55 337 0 91 337 minecraft:honeycomb_block
fill 1 55 323 1 55 324 minecraft:honeycomb_block
setblock 1 55 325 minecraft:yellow_terracotta
fill 1 55 326 1 55 329 minecraft:honeycomb_block
setblock 1 55 330 minecraft:yellow_terracotta
fill 1 55 331 1 55 334 minecraft:honeycomb_block
setblock 1 55 335 minecraft:yellow_terracotta
fill 1 55 336 1 58 336 minecraft:honeycomb_block
setblock 1 55 342 minecraft:honey_block
setblock 1 55 350 minecraft:yellow_terracotta
fill 1 55 351 1 58 351 minecraft:honeycomb_block
setblock 1 55 355 minecraft:yellow_terracotta
fill 1 55 356 1 57 357 minecraft:honeycomb_block
setblock 1 55 361 minecraft:honey_block
fill 2 55 322 2 55 323 minecraft:honeycomb_block
setblock 2 55 324 minecraft:yellow_terracotta
fill 2 55 325 2 55 328 minecraft:honeycomb_block
setblock 2 55 329 minecraft:yellow_terracotta
fill 2 55 330 2 58 330 minecraft:honeycomb_block
setblock 2 55 333 minecraft:honeycomb_block
setblock 2 55 334 minecraft:yellow_terracotta
fill 3 55 322 3 172 322 minecraft:honeycomb_block
setblock 3 55 323 minecraft:yellow_terracotta
setblock 3 55 325 minecraft:light[level=15]
setblock 3 55 333 minecraft:light[level=15]
setblock 3 55 341 minecraft:light[level=15]
setblock 3 55 349 minecraft:light[level=15]
setblock 3 55 357 minecraft:light[level=15]
fill 4 55 323 4 56 323 minecraft:honeycomb_block
fill 10 55 364 10 95 364 minecraft:honeycomb_block
setblock 11 55 325 minecraft:light[level=15]
setblock 11 55 333 minecraft:light[level=15]
setblock 11 55 341 minecraft:light[level=15]
setblock 11 55 349 minecraft:light[level=15]
setblock 11 55 357 minecraft:light[level=15]
setblock 13 55 363 minecraft:yellow_terracotta
fill 14 55 323 14 58 323 minecraft:honeycomb_block
fill 14 55 363 17 55 363 minecraft:honeycomb_block
fill 17 55 362 17 56 362 minecraft:honeycomb_block
setblock 18 55 323 minecraft:yellow_terracotta
setblock 18 55 363 minecraft:yellow_terracotta
setblock 19 55 323 minecraft:honeycomb_block
setblock 19 55 325 minecraft:light[level=15]
setblock 19 55 333 minecraft:light[level=15]
setblock 19 55 341 minecraft:light[level=15]
setblock 19 55 349 minecraft:light[level=15]
setblock 19 55 357 minecraft:light[level=15]
fill 19 55 363 21 56 363 minecraft:honeycomb_block
fill 23 55 322 23 188 322 minecraft:honeycomb_block
setblock 24 55 322 minecraft:orange_terracotta
setblock 24 55 363 minecraft:honey_block
setblock 27 55 325 minecraft:light[level=15]
setblock 27 55 333 minecraft:light[level=15]
setblock 27 55 341 minecraft:light[level=15]
setblock 27 55 349 minecraft:light[level=15]
setblock 27 55 357 minecraft:light[level=15]
fill 29 55 333 29 56 333 minecraft:honey_block
setblock 35 55 325 minecraft:light[level=15]
setblock 35 55 333 minecraft:light[level=15]
setblock 35 55 341 minecraft:light[level=15]
setblock 35 55 349 minecraft:light[level=15]
setblock 35 55 357 minecraft:light[level=15]
setblock 38 55 323 minecraft:yellow_terracotta
fill 39 55 323 39 58 323 minecraft:honeycomb_block
setblock 39 55 327 minecraft:yellow_terracotta
fill 39 55 328 39 58 328 minecraft:honeycomb_block
setblock 39 55 332 minecraft:yellow_terracotta
fill 39 55 333 39 58 333 minecraft:honeycomb_block
setblock 39 55 336 minecraft:honeycomb_block
setblock 40 55 326 minecraft:yellow_terracotta
fill 40 55 327 40 58 327 minecraft:honeycomb_block
setblock 40 55 331 minecraft:yellow_terracotta
fill 40 55 332 40 58 332 minecraft:honeycomb_block
setblock 40 55 336 minecraft:yellow_terracotta
fill 40 55 337 40 58 337 minecraft:honeycomb_block
setblock 40 55 346 minecraft:yellow_terracotta
setblock 40 55 347 minecraft:honeycomb_block
setblock 40 55 351 minecraft:yellow_terracotta
fill 40 55 352 40 58 352 minecraft:honeycomb_block
setblock 41 55 325 minecraft:yellow_terracotta
fill 41 55 326 41 58 326 minecraft:honeycomb_block
setblock 41 55 330 minecraft:yellow_terracotta
fill 41 55 331 41 58 331 minecraft:honeycomb_block
setblock 41 55 335 minecraft:yellow_terracotta
fill 41 55 336 41 58 336 minecraft:honeycomb_block
setblock 41 55 340 minecraft:yellow_terracotta
fill 41 55 341 41 58 341 minecraft:honeycomb_block
setblock 41 55 345 minecraft:yellow_terracotta
fill 41 55 346 41 57 346 minecraft:honeycomb_block
setblock 41 55 350 minecraft:yellow_terracotta
fill 41 55 351 41 58 351 minecraft:honeycomb_block
setblock 41 55 355 minecraft:yellow_terracotta
fill 41 55 356 41 58 356 minecraft:honeycomb_block
fill 42 55 335 42 70 335 minecraft:honeycomb_block
setblock 1 56 323 minecraft:honeycomb_block
setblock 1 56 324 minecraft:yellow_terracotta
fill 1 56 325 1 56 328 minecraft:honeycomb_block
setblock 1 56 329 minecraft:yellow_terracotta
fill 1 56 330 1 56 333 minecraft:honeycomb_block
setblock 1 56 334 minecraft:yellow_terracotta
fill 1 56 335 1 59 335 minecraft:honeycomb_block
setblock 1 56 348 minecraft:honey_block
setblock 1 56 349 minecraft:yellow_terracotta
fill 1 56 350 1 58 350 minecraft:honeycomb_block
setblock 1 56 354 minecraft:yellow_terracotta
fill 1 56 355 1 59 355 minecraft:honeycomb_block
setblock 1 56 358 minecraft:honeycomb_block
fill 2 56 322 2 177 322 minecraft:honeycomb_block
setblock 2 56 323 minecraft:yellow_terracotta
fill 2 56 325 2 56 327 minecraft:honeycomb_block
setblock 2 56 328 minecraft:yellow_terracotta
fill 2 56 329 2 59 329 minecraft:honeycomb_block
setblock 2 56 333 minecraft:yellow_terracotta
fill 2 56 334 2 59 334 minecraft:honeycomb_block
fill 3 56 323 3 59 323 minecraft:honeycomb_block
setblock 5 56 363 minecraft:honey_block
setblock 12 56 323 minecraft:honey_block
setblock 12 56 364 minecraft:yellow_terracotta
fill 13 56 363 16 56 363 minecraft:honeycomb_block
fill 16 56 362 16 57 362 minecraft:honeycomb_block
setblock 17 56 323 minecraft:yellow_terracotta
setblock 17 56 363 minecraft:yellow_terracotta
fill 18 56 323 18 59 323 minecraft:honeycomb_block
setblock 18 56 362 minecraft:yellow_terracotta
fill 18 56 363 18 59 363 minecraft:honeycomb_block
fill 24 56 322 24 77 322 minecraft:honeycomb_block
setblock 30 56 363 minecraft:honey_block
setblock 31 56 323 minecraft:honey_block
setblock 37 56 323 minecraft:yellow_terracotta
fill 38 56 323 38 59 323 minecraft:honeycomb_block
fill 38 56 330 38 56 331 minecraft:honeycomb_block
setblock 38 56 332 minecraft:yellow_terracotta
fill 38 56 333 38 59 333 minecraft:honeycomb_block
fill 39 56 327 39 58 327 minecraft:honeycomb_block
setblock 39 56 331 minecraft:yellow_terracotta
fill 39 56 332 39 59 332 minecraft:honeycomb_block
setblock 39 56 336 minecraft:yellow_terracotta
fill 39 56 337 39 59 337 minecraft:honeycomb_block
setblock 40 56 325 minecraft:yellow_terracotta
fill 40 56 326 40 59 326 minecraft:honeycomb_block
setblock 40 56 330 minecraft:yellow_terracotta
fill 40 56 331 40 59 331 minecraft:honeycomb_block
setblock 40 56 335 minecraft:yellow_terracotta
fill 40 56 336 40 59 336 minecraft:honeycomb_block
setblock 40 56 350 minecraft:yellow_terracotta
fill 40 56 351 40 58 351 minecraft:honeycomb_block
setblock 41 56 324 minecraft:yellow_terracotta
fill 41 56 325 41 59 325 minecraft:honeycomb_block
setblock 41 56 329 minecraft:yellow_terracotta
fill 41 56 330 41 59 330 minecraft:honeycomb_block
setblock 41 56 334 minecraft:yellow_terracotta
fill 41 56 335 41 59 335 minecraft:honeycomb_block
setblock 41 56 339 minecraft:yellow_terracotta
fill 41 56 340 41 59 340 minecraft:honeycomb_block
setblock 41 56 344 minecraft:yellow_terracotta
fill 41 56 345 41 57 345 minecraft:honeycomb_block
setblock 41 56 349 minecraft:yellow_terracotta
fill 41 56 350 41 59 350 minecraft:honeycomb_block
setblock 41 56 354 minecraft:yellow_terracotta
fill 41 56 355 41 59 355 minecraft:honeycomb_block
fill 41 56 357 41 57 357 minecraft:honeycomb_block
setblock 1 57 323 minecraft:yellow_terracotta
fill 1 57 324 1 57 327 minecraft:honeycomb_block
setblock 1 57 328 minecraft:yellow_terracotta
fill 1 57 329 1 57 332 minecraft:honeycomb_block
setblock 1 57 333 minecraft:yellow_terracotta
fill 1 57 334 1 60 334 minecraft:honeycomb_block
setblock 1 57 338 minecraft:yellow_terracotta
setblock 1 57 353 minecraft:yellow_terracotta
fill 1 57 354 1 60 354 minecraft:honeycomb_block
setblock 1 57 358 minecraft:yellow_terracotta
fill 1 57 359 1 59 360 minecraft:honeycomb_block
fill 2 57 323 2 60 323 minecraft:honeycomb_block
setblock 2 57 326 minecraft:honeycomb_block
setblock 2 57 327 minecraft:yellow_terracotta
fill 2 57 328 2 60 328 minecraft:honeycomb_block
setblock 2 57 332 minecraft:yellow_terracotta
fill 2 57 333 2 60 333 minecraft:honeycomb_block
fill 2 57 335 2 58 335 minecraft:honeycomb_block
setblock 3 57 325 minecraft:light[level=12]
setblock 3 57 332 minecraft:light[level=12]
setblock 3 57 339 minecraft:light[level=12]
setblock 3 57 346 minecraft:light[level=12]
setblock 3 57 353 minecraft:light[level=12]
setblock 3 57 360 minecraft:light[level=12]
setblock 6 57 323 minecraft:honey_block
setblock 10 57 325 minecraft:light[level=12]
setblock 10 57 332 minecraft:light[level=12]
setblock 10 57 339 minecraft:light[level=12]
setblock 10 57 346 minecraft:light[level=12]
setblock 10 57 353 minecraft:light[level=12]
setblock 10 57 360 minecraft:light[level=12]
setblock 11 57 363 minecraft:yellow_terracotta
fill 12 57 363 12 60 364 minecraft:honeycomb_block
fill 13 57 323 13 59 323 minecraft:honeycomb_block
fill 13 57 363 15 57 363 minecraft:honeycomb_block
fill 14 57 362 15 58 362 minecraft:honeycomb_block
setblock 15 57 323 minecraft:honeycomb_block
setblock 16 57 323 minecraft:yellow_terracotta
fill 16 57 343 18 57 346 minecraft:yellow_terracotta
setblock 16 57 363 minecraft:yellow_terracotta
fill 17 57 323 17 60 323 minecraft:honeycomb_block
setblock 17 57 325 minecraft:light[level=12]
setblock 17 57 332 minecraft:light[level=12]
setblock 17 57 339 minecraft:light[level=12]
fill 17 57 347 18 119 347 minecraft:yellow_terracotta
setblock 17 57 353 minecraft:light[level=12]
setblock 17 57 360 minecraft:light[level=12]
setblock 17 57 362 minecraft:yellow_terracotta
fill 17 57 363 17 60 363 minecraft:honeycomb_block
fill 18 57 362 19 59 362 minecraft:honeycomb_block
fill 19 57 344 19 72 346 minecraft:yellow_terracotta
fill 19 57 363 20 57 363 minecraft:honeycomb_block
fill 20 57 345 20 98 345 minecraft:yellow_terracotta
setblock 21 57 322 minecraft:orange_terracotta
setblock 21 57 363 minecraft:yellow_terracotta
setblock 24 57 325 minecraft:light[level=12]
setblock 24 57 332 minecraft:light[level=12]
setblock 24 57 339 minecraft:light[level=12]
setblock 24 57 346 minecraft:light[level=12]
setblock 24 57 353 minecraft:light[level=12]
setblock 24 57 360 minecraft:light[level=12]
setblock 25 57 323 minecraft:honey_block
setblock 26 57 322 minecraft:yellow_terracotta
fill 27 57 322 35 77 322 minecraft:honeycomb_block
setblock 31 57 325 minecraft:light[level=12]
setblock 31 57 332 minecraft:light[level=12]
setblock 31 57 339 minecraft:light[level=12]
setblock 31 57 346 minecraft:light[level=12]
setblock 31 57 353 minecraft:light[level=12]
setblock 31 57 360 minecraft:light[level=12]
setblock 36 57 323 minecraft:yellow_terracotta
setblock 36 57 363 minecraft:honey_block
fill 37 57 322 37 60 323 minecraft:honeycomb_block
fill 38 57 322 38 75 322 minecraft:honeycomb_block
setblock 38 57 325 minecraft:light[level=12]
setblock 38 57 330 minecraft:honeycomb_block
setblock 38 57 331 minecraft:yellow_terracotta
fill 38 57 332 38 60 332 minecraft:honeycomb_block
fill 38 57 334 38 57 335 minecraft:honeycomb_block
setblock 38 57 339 minecraft:light[level=12]
setblock 38 57 346 minecraft:light[level=12]
setblock 38 57 353 minecraft:light[level=12]
setblock 38 57 360 minecraft:light[level=12]
setblock 39 57 322 minecraft:orange_terracotta
setblock 39 57 330 minecraft:yellow_terracotta
fill 39 57 331 39 60 331 minecraft:honeycomb_block
setblock 39 57 335 minecraft:yellow_terracotta
fill 39 57 336 39 60 336 minecraft:honeycomb_block
fill 39 57 338 39 58 338 minecraft:honeycomb_block
fill 40 57 325 40 60 325 minecraft:honeycomb_block
setblock 40 57 329 minecraft:yellow_terracotta
fill 40 57 330 40 60 330 minecraft:honeycomb_block
setblock 40 57 334 minecraft:yellow_terracotta
fill 40 57 335 40 60 335 minecraft:honeycomb_block
setblock 40 57 339 minecraft:yellow_terracotta
fill 40 57 340 40 60 340 minecraft:honeycomb_block
setblock 40 57 349 minecraft:yellow_terracotta
setblock 40 57 350 minecraft:honeycomb_block
setblock 40 57 354 minecraft:yellow_terracotta
fill 40 57 355 40 60 355 minecraft:honeycomb_block
setblock 41 57 323 minecraft:yellow_terracotta
fill 41 57 324 41 60 324 minecraft:honeycomb_block
setblock 41 57 328 minecraft:yellow_terracotta
fill 41 57 329 41 60 329 minecraft:honeycomb_block
setblock 41 57 333 minecraft:yellow_terracotta
fill 41 57 334 41 60 334 minecraft:honeycomb_block
setblock 41 57 338 minecraft:yellow_terracotta
fill 41 57 339 41 60 339 minecraft:honeycomb_block
setblock 41 57 343 minecraft:yellow_terracotta
setblock 41 57 348 minecraft:yellow_terracotta
fill 41 57 349 41 59 349 minecraft:honeycomb_block
setblock 41 57 353 minecraft:yellow_terracotta
fill 41 57 354 41 60 354 minecraft:honeycomb_block
fill 1 58 323 1 58 326 minecraft:honeycomb_block
setblock 1 58 327 minecraft:yellow_terracotta
fill 1 58 328 1 58 331 minecraft:honeycomb_block
setblock 1 58 332 minecraft:yellow_terracotta
fill 1 58 333 1 61 333 minecraft:honeycomb_block
setblock 1 58 337 minecraft:yellow_terracotta
fill 1 58 338 1 61 338 minecraft:honeycomb_block
fill 1 58 341 1 59 341 minecraft:honey_block
setblock 1 58 352 minecraft:yellow_terracotta
fill 1 58 353 1 61 353 minecraft:honeycomb_block
setblock 1 58 356 minecraft:honeycomb_block
setblock 1 58 357 minecraft:yellow_terracotta
fill 1 58 358 1 61 358 minecraft:honeycomb_block
setblock 1 58 361 minecraft:honeycomb_block
setblock 1 58 362 minecraft:yellow_terracotta
fill 1 58 363 1 61 363 minecraft:honeycomb_block
setblock 2 58 326 minecraft:yellow_terracotta
fill 2 58 327 2 59 327 minecraft:honeycomb_block
setblock 2 58 331 minecraft:yellow_terracotta
fill 2 58 332 2 61 332 minecraft:honeycomb_block
setblock 10 58 363 minecraft:yellow_terracotta
fill 11 58 363 11 61 363 minecraft:honeycomb_block
fill 12 58 323 12 60 323 minecraft:honeycomb_block
fill 12 58 362 13 60 362 minecraft:honeycomb_block
fill 13 58 354 14 59 354 minecraft:yellow_concrete
fill 13 58 363 14 58 363 minecraft:honeycomb_block
setblock 15 58 323 minecraft:yellow_terracotta
fill 15 58 343 15 59 347 minecraft:brown_terracotta
fill 15 58 361 16 58 361 minecraft:honeycomb_block
setblock 15 58 363 minecraft:yellow_terracotta
fill 16 58 323 16 61 323 minecraft:honeycomb_block
fill 16 58 342 16 59 342 minecraft:brown_terracotta
fill 16 58 343 17 79 346 minecraft:yellow_terracotta
fill 16 58 347 16 59 347 minecraft:brown_terracotta
setblock 16 58 362 minecraft:yellow_terracotta
fill 16 58 363 16 61 363 minecraft:honeycomb_block
fill 17 58 348 19 59 348 minecraft:brown_terracotta
setblock 17 58 361 minecraft:yellow_terracotta
fill 17 58 362 17 61 362 minecraft:honeycomb_block
fill 18 58 344 18 83 346 minecraft:yellow_terracotta
setblock 19 58 323 minecraft:honey_block
fill 19 58 347 20 59 347 minecraft:brown_terracotta
setblock 19 58 363 minecraft:honeycomb_block
fill 20 58 344 20 59 344 minecraft:brown_terracotta
fill 20 58 346 20 59 346 minecraft:brown_terracotta
setblock 20 58 363 minecraft:yellow_terracotta
fill 21 58 322 21 74 322 minecraft:honeycomb_block
fill 21 58 345 21 59 345 minecraft:brown_terracotta
fill 21 58 363 21 61 363 minecraft:honeycomb_block
setblock 23 58 363 minecraft:honey_block
fill 26 58 322 26 119 322 minecraft:honeycomb_block
setblock 35 58 323 minecraft:yellow_terracotta
fill 36 58 323 36 61 323 minecraft:honeycomb_block
setblock 38 58 330 minecraft:yellow_terracotta
fill 38 58 331 38 61 331 minecraft:honeycomb_block
setblock 38 58 334 minecraft:honeycomb_block
setblock 38 58 335 minecraft:yellow_terracotta
fill 38 58 336 38 61 336 minecraft:honeycomb_block
fill 39 58 322 39 106 322 minecraft:honeycomb_block
setblock 39 58 329 minecraft:yellow_terracotta
fill 39 58 330 39 61 330 minecraft:honeycomb_block
setblock 39 58 334 minecraft:yellow_terracotta
fill 39 58 335 39 61 335 minecraft:honeycomb_block
setblock 40 58 323 minecraft:yellow_terracotta
setblock 40 58 328 minecraft:yellow_terracotta
fill 40 58 329 40 61 329 minecraft:honeycomb_block
setblock 40 58 333 minecraft:yellow_terracotta
fill 40 58 334 40 61 334 minecraft:honeycomb_block
setblock 40 58 338 minecraft:yellow_terracotta
fill 40 58 339 40 61 339 minecraft:honeycomb_block
setblock 40 58 353 minecraft:yellow_terracotta
fill 40 58 354 40 60 354 minecraft:honeycomb_block
fill 40 58 356 40 59 356 minecraft:honeycomb_block
fill 41 58 323 41 61 323 minecraft:honeycomb_block
setblock 41 58 327 minecraft:yellow_terracotta
fill 41 58 328 41 61 328 minecraft:honeycomb_block
setblock 41 58 332 minecraft:yellow_terracotta
fill 41 58 333 41 61 333 minecraft:honeycomb_block
setblock 41 58 337 minecraft:yellow_terracotta
fill 41 58 338 41 61 338 minecraft:honeycomb_block
setblock 41 58 342 minecraft:yellow_terracotta
setblock 41 58 345 minecraft:honey_block
setblock 41 58 347 minecraft:yellow_terracotta
setblock 41 58 348 minecraft:honeycomb_block
setblock 41 58 352 minecraft:yellow_terracotta
fill 41 58 353 41 61 353 minecraft:honeycomb_block
setblock 41 58 357 minecraft:yellow_terracotta
fill 41 58 358 41 61 358 minecraft:honeycomb_block
fill 1 59 323 1 59 325 minecraft:honeycomb_block
setblock 1 59 326 minecraft:yellow_terracotta
fill 1 59 327 1 59 330 minecraft:honeycomb_block
setblock 1 59 331 minecraft:yellow_terracotta
fill 1 59 332 1 62 332 minecraft:honeycomb_block
setblock 1 59 336 minecraft:yellow_terracotta
fill 1 59 337 1 62 337 minecraft:honeycomb_block
fill 1 59 339 1 60 339 minecraft:honeycomb_block
setblock 1 59 347 minecraft:honey_block
setblock 1 59 351 minecraft:yellow_terracotta
fill 1 59 352 1 61 352 minecraft:honeycomb_block
setblock 1 59 356 minecraft:yellow_terracotta
fill 1 59 357 2 61 357 minecraft:honeycomb_block
setblock 1 59 361 minecraft:yellow_terracotta
fill 1 59 362 1 62 362 minecraft:honeycomb_block
setblock 2 59 330 minecraft:yellow_terracotta
fill 2 59 331 2 61 331 minecraft:honeycomb_block
setblock 2 59 335 minecraft:yellow_terracotta
fill 2 59 356 2 62 356 minecraft:honeycomb_block
fill 2 59 363 3 59 363 minecraft:honeycomb_block
fill 3 59 358 3 62 358 minecraft:brown_terracotta
fill 4 59 357 4 62 357 minecraft:brown_terracotta
fill 4 59 359 4 62 359 minecraft:brown_terracotta
setblock 4 59 363 minecraft:honey_block
fill 5 59 322 9 94 322 minecraft:honeycomb_block
fill 5 59 358 5 62 358 minecraft:brown_terracotta
fill 7 59 363 8 59 363 minecraft:honeycomb_block
setblock 9 59 363 minecraft:yellow_terracotta
setblock 10 59 322 minecraft:orange_terracotta
setblock 10 59 362 minecraft:yellow_terracotta
fill 10 59 363 10 62 363 minecraft:honeycomb_block
fill 11 59 323 11 61 323 minecraft:honeycomb_block
fill 11 59 362 11 62 362 minecraft:honeycomb_block
fill 12 59 361 15 59 361 minecraft:honeycomb_block
setblock 13 59 363 minecraft:honeycomb_block
setblock 14 59 323 minecraft:yellow_terracotta
fill 14 59 343 14 59 347 minecraft:brown_terracotta
setblock 14 59 362 minecraft:honeycomb_block
setblock 14 59 363 minecraft:yellow_terracotta
fill 15 59 323 15 62 323 minecraft:honeycomb_block
setblock 15 59 342 minecraft:brown_terracotta
fill 15 59 348 16 59 348 minecraft:brown_terracotta
setblock 15 59 362 minecraft:yellow_terracotta
fill 15 59 363 15 62 363 minecraft:honeycomb_block
setblock 16 59 341 minecraft:brown_terracotta
setblock 16 59 361 minecraft:yellow_terracotta
fill 16 59 362 16 62 362 minecraft:honeycomb_block
fill 17 59 349 19 59 349 minecraft:brown_terracotta
fill 17 59 361 18 61 361 minecraft:honeycomb_block
setblock 19 59 363 minecraft:yellow_terracotta
setblock 20 59 348 minecraft:brown_terracotta
setblock 20 59 362 minecraft:yellow_terracotta
fill 20 59 363 20 62 363 minecraft:honeycomb_block
fill 21 59 344 22 59 344 minecraft:brown_terracotta
fill 21 59 346 21 59 347 minecraft:brown_terracotta
setblock 22 59 345 minecraft:brown_terracotta
fill 27 59 330 28 60 331 minecraft:yellow_concrete
setblock 29 59 363 minecraft:honey_block
setblock 34 59 323 minecraft:yellow_terracotta
fill 35 59 323 35 62 323 minecraft:honeycomb_block
fill 36 59 363 38 59 363 minecraft:honeycomb_block
setblock 37 59 334 minecraft:honeycomb_block
fill 38 59 330 38 61 330 minecraft:honeycomb_block
setblock 38 59 334 minecraft:yellow_terracotta
fill 38 59 335 38 62 335 minecraft:honeycomb_block
fill 38 59 337 38 60 337 minecraft:honeycomb_block
setblock 39 59 323 minecraft:yellow_terracotta
setblock 39 59 328 minecraft:yellow_terracotta
fill 39 59 329 39 62 329 minecraft:honeycomb_block
setblock 39 59 333 minecraft:yellow_terracotta
fill 39 59 334 39 62 334 minecraft:honeycomb_block
setblock 39 59 338 minecraft:yellow_terracotta
fill 39 59 339 39 62 339 minecraft:honeycomb_block
fill 40 59 323 40 62 323 minecraft:honeycomb_block
setblock 40 59 327 minecraft:yellow_terracotta
fill 40 59 328 40 62 328 minecraft:honeycomb_block
setblock 40 59 332 minecraft:yellow_terracotta
fill 40 59 333 40 62 333 minecraft:honeycomb_block
setblock 40 59 337 minecraft:yellow_terracotta
fill 40 59 338 40 62 338 minecraft:honeycomb_block
setblock 40 59 341 minecraft:honeycomb_block
setblock 40 59 352 minecraft:yellow_terracotta
fill 40 59 353 40 60 353 minecraft:honeycomb_block
setblock 40 59 357 minecraft:yellow_terracotta
setblock 41 59 326 minecraft:yellow_terracotta
fill 41 59 327 41 62 327 minecraft:honeycomb_block
setblock 41 59 331 minecraft:yellow_terracotta
fill 41 59 332 41 62 332 minecraft:honeycomb_block
setblock 41 59 336 minecraft:yellow_terracotta
fill 41 59 337 41 62 337 minecraft:honeycomb_block
setblock 41 59 341 minecraft:yellow_terracotta
fill 41 59 342 41 62 342 minecraft:honeycomb_block
setblock 41 59 351 minecraft:yellow_terracotta
fill 41 59 352 41 61 352 minecraft:honeycomb_block
setblock 41 59 356 minecraft:yellow_terracotta
fill 41 59 357 41 62 357 minecraft:honeycomb_block
fill 41 59 359 41 59 360 minecraft:honeycomb_block
fill 1 60 323 1 60 324 minecraft:honeycomb_block
setblock 1 60 325 minecraft:yellow_terracotta
fill 1 60 326 1 60 329 minecraft:honeycomb_block
setblock 1 60 330 minecraft:yellow_terracotta
fill 1 60 331 1 63 331 minecraft:honeycomb_block
setblock 1 60 335 minecraft:yellow_terracotta
fill 1 60 336 2 61 336 minecraft:honeycomb_block
setblock 1 60 351 minecraft:honeycomb_block
setblock 1 60 355 minecraft:yellow_terracotta
fill 1 60 356 1 63 356 minecraft:honeycomb_block
setblock 1 60 359 minecraft:honeycomb_block
setblock 1 60 360 minecraft:yellow_terracotta
fill 1 60 361 1 63 361 minecraft:honeycomb_block
fill 1 60 364 6 98 364 minecraft:honeycomb_block
setblock 2 60 329 minecraft:yellow_terracotta
fill 2 60 330 2 61 330 minecraft:honeycomb_block
setblock 2 60 334 minecraft:yellow_terracotta
fill 2 60 335 2 62 335 minecraft:honeycomb_block
fill 2 60 355 2 61 355 minecraft:honeycomb_block
setblock 2 60 358 minecraft:honeycomb_block
setblock 2 60 359 minecraft:yellow_terracotta
fill 2 60 360 2 63 360 minecraft:honeycomb_block
setblock 2 60 363 minecraft:honeycomb_block
setblock 3 60 323 minecraft:yellow_terracotta
setblock 3 60 363 minecraft:yellow_terracotta
fill 4 60 363 7 60 363 minecraft:honeycomb_block
setblock 7 60 323 minecraft:honey_block
fill 7 60 349 8 61 350 minecraft:yellow_concrete
setblock 7 60 364 minecraft:yellow_concrete
setblock 8 60 363 minecraft:yellow_terracotta
fill 8 60 364 9 134 364 minecraft:honeycomb_block
setblock 9 60 362 minecraft:yellow_terracotta
fill 9 60 363 9 63 363 minecraft:honeycomb_block
fill 10 60 322 10 62 323 minecraft:honeycomb_block
fill 10 60 362 10 63 362 minecraft:honeycomb_block
fill 11 60 361 14 60 361 minecraft:honeycomb_block
setblock 13 60 323 minecraft:yellow_terracotta
fill 13 60 360 15 60 360 minecraft:honeycomb_block
setblock 13 60 363 minecraft:yellow_terracotta
fill 14 60 323 14 63 323 minecraft:honeycomb_block
setblock 14 60 362 minecraft:yellow_terracotta
fill 14 60 363 14 63 363 minecraft:honeycomb_block
setblock 15 60 361 minecraft:yellow_terracotta
fill 15 60 362 15 63 362 minecraft:honeycomb_block
fill 16 60 328 16 61 329 minecraft:yellow_concrete
setblock 16 60 360 minecraft:yellow_terracotta
fill 16 60 361 16 63 361 minecraft:honeycomb_block
fill 17 60 360 17 63 360 minecraft:honeycomb_block
setblock 18 60 362 minecraft:honeycomb_block
setblock 18 60 363 minecraft:yellow_terracotta
setblock 19 60 361 minecraft:honeycomb_block
setblock 19 60 362 minecraft:yellow_terracotta
fill 19 60 363 19 63 363 minecraft:honeycomb_block
fill 20 60 362 20 63 362 minecraft:honeycomb_block
setblock 32 60 323 minecraft:honey_block
setblock 33 60 323 minecraft:yellow_terracotta
setblock 33 60 363 minecraft:yellow_terracotta
fill 34 60 323 34 63 323 minecraft:honeycomb_block
fill 34 60 363 37 60 363 minecraft:honeycomb_block
setblock 36 60 324 minecraft:honeycomb_block
setblock 37 60 324 minecraft:yellow_terracotta
setblock 37 60 333 minecraft:honeycomb_block
setblock 37 60 334 minecraft:yellow_terracotta
fill 37 60 335 37 62 336 minecraft:honeycomb_block
setblock 38 60 323 minecraft:yellow_terracotta
fill 38 60 324 38 62 324 minecraft:honeycomb_block
setblock 38 60 333 minecraft:yellow_terracotta
fill 38 60 334 38 63 334 minecraft:honeycomb_block
setblock 38 60 338 minecraft:yellow_terracotta
setblock 38 60 363 minecraft:yellow_terracotta
fill 39 60 323 39 63 323 minecraft:honeycomb_block
fill 39 60 328 39 61 328 minecraft:honeycomb_block
setblock 39 60 332 minecraft:yellow_terracotta
fill 39 60 333 39 63 333 minecraft:honeycomb_block
setblock 39 60 337 minecraft:yellow_terracotta
fill 39 60 338 39 63 338 minecraft:honeycomb_block
fill 39 60 340 39 61 340 minecraft:honeycomb_block
fill 39 60 363 39 63 363 minecraft:honeycomb_block
setblock 40 60 326 minecraft:yellow_terracotta
fill 40 60 327 40 62 327 minecraft:honeycomb_block
setblock 40 60 331 minecraft:yellow_terracotta
fill 40 60 332 40 63 332 minecraft:honeycomb_block
setblock 40 60 336 minecraft:yellow_terracotta
fill 40 60 337 40 63 337 minecraft:honeycomb_block
setblock 40 60 341 minecraft:yellow_terracotta
setblock 40 60 356 minecraft:yellow_terracotta
fill 40 60 357 40 62 358 minecraft:honeycomb_block
setblock 41 60 325 minecraft:yellow_terracotta
fill 41 60 326 41 63 326 minecraft:honeycomb_block
setblock 41 60 330 minecraft:yellow_terracotta
fill 41 60 331 41 63 331 minecraft:honeycomb_block
setblock 41 60 335 minecraft:yellow_terracotta
fill 41 60 336 41 63 336 minecraft:honeycomb_block
setblock 41 60 340 minecraft:yellow_terracotta
fill 41 60 341 41 63 341 minecraft:honeycomb_block
setblock 41 60 350 minecraft:yellow_terracotta
setblock 41 60 351 minecraft:honeycomb_block
setblock 41 60 355 minecraft:yellow_terracotta
fill 41 60 356 41 63 356 minecraft:honeycomb_block
setblock 41 60 359 minecraft:honeycomb_block
setblock 41 60 360 minecraft:yellow_terracotta
fill 41 60 361 41 63 361 minecraft:honeycomb_block
fill 0 61 348 0 61 354 minecraft:honeycomb_block
setblock 0 61 355 minecraft:yellow_terracotta
fill 0 61 356 0 67 358 minecraft:honeycomb_block
setblock 1 61 323 minecraft:honeycomb_block
setblock 1 61 324 minecraft:yellow_terracotta
fill 1 61 325 1 61 328 minecraft:honeycomb_block
setblock 1 61 329 minecraft:yellow_terracotta
fill 1 61 330 1 63 330 minecraft:honeycomb_block
setblock 1 61 334 minecraft:yellow_terracotta
fill 1 61 335 1 64 335 minecraft:honeycomb_block
setblock 1 61 339 minecraft:yellow_terracotta
setblock 1 61 354 minecraft:yellow_terracotta
fill 1 61 355 1 64 355 minecraft:honeycomb_block
setblock 1 61 359 minecraft:yellow_terracotta
fill 1 61 360 1 64 360 minecraft:honeycomb_block
setblock 2 61 323 minecraft:yellow_terracotta
setblock 2 61 333 minecraft:yellow_terracotta
fill 2 61 334 2 62 334 minecraft:honeycomb_block
setblock 2 61 358 minecraft:yellow_terracotta
fill 2 61 359 2 64 359 minecraft:honeycomb_block
fill 2 61 361 2 62 361 minecraft:honeycomb_block
setblock 2 61 363 minecraft:yellow_terracotta
fill 3 61 323 3 63 323 minecraft:honeycomb_block
fill 3 61 363 6 61 363 minecraft:honeycomb_block
setblock 7 61 362 minecraft:honeycomb_block
setblock 7 61 363 minecraft:yellow_terracotta
fill 7 61 364 7 86 364 minecraft:honeycomb_block
fill 8 61 323 9 63 323 minecraft:honeycomb_block
setblock 8 61 362 minecraft:yellow_terracotta
fill 8 61 363 8 64 363 minecraft:honeycomb_block
setblock 9 61 361 minecraft:yellow_terracotta
fill 9 61 362 9 64 362 minecraft:honeycomb_block
fill 10 61 361 13 61 361 minecraft:honeycomb_block
fill 11 61 360 14 61 360 minecraft:honeycomb_block
setblock 12 61 323 minecraft:yellow_terracotta
setblock 12 61 362 minecraft:honeycomb_block
setblock 12 61 363 minecraft:yellow_terracotta
fill 12 61 364 12 84 364 minecraft:honeycomb_block
fill 13 61 323 13 64 323 minecraft:honeycomb_block
setblock 13 61 362 minecraft:yellow_terracotta
fill 13 61 363 13 64 363 minecraft:honeycomb_block
fill 14 61 359 15 61 359 minecraft:honeycomb_block
setblock 14 61 361 minecraft:yellow_terracotta
fill 14 61 362 14 64 362 minecraft:honeycomb_block
setblock 15 61 360 minecraft:yellow_terracotta
fill 15 61 361 15 64 361 minecraft:honeycomb_block
fill 16 61 360 16 64 360 minecraft:honeycomb_block
setblock 17 61 323 minecraft:yellow_terracotta
setblock 17 61 363 minecraft:yellow_terracotta
setblock 18 61 362 minecraft:yellow_terracotta
fill 18 61 363 18 64 363 minecraft:honeycomb_block
setblock 19 61 361 minecraft:yellow_terracotta
fill 19 61 362 19 64 362 minecraft:honeycomb_block
setblock 26 61 323 minecraft:honey_block
setblock 32 61 323 minecraft:yellow_terracotta
setblock 32 61 363 minecraft:yellow_terracotta
fill 33 61 323 33 64 323 minecraft:honeycomb_block
fill 33 61 363 36 61 363 minecraft:honeycomb_block
setblock 35 61 324 minecraft:honeycomb_block
fill 35 61 362 36 62 362 minecraft:honeycomb_block
setblock 36 61 324 minecraft:yellow_terracotta
fill 37 61 322 37 67 322 minecraft:honeycomb_block
setblock 37 61 323 minecraft:yellow_terracotta
fill 37 61 324 37 64 324 minecraft:honeycomb_block
setblock 37 61 333 minecraft:yellow_terracotta
fill 37 61 334 37 62 334 minecraft:honeycomb_block
setblock 37 61 363 minecraft:yellow_terracotta
fill 38 61 323 38 64 323 minecraft:honeycomb_block
setblock 38 61 332 minecraft:yellow_terracotta
fill 38 61 333 38 63 333 minecraft:honeycomb_block
setblock 38 61 337 minecraft:yellow_terracotta
fill 38 61 338 38 63 338 minecraft:honeycomb_block
fill 38 61 363 38 64 363 minecraft:honeycomb_block
setblock 39 61 331 minecraft:yellow_terracotta
fill 39 61 332 39 64 332 minecraft:honeycomb_block
setblock 39 61 336 minecraft:yellow_terracotta
fill 39 61 337 39 64 337 minecraft:honeycomb_block
setblock 40 61 326 minecraft:honeycomb_block
setblock 40 61 330 minecraft:yellow_terracotta
fill 40 61 331 40 64 331 minecraft:honeycomb_block
setblock 40 61 335 minecraft:yellow_terracotta
fill 40 61 336 40 64 336 minecraft:honeycomb_block
setblock 40 61 340 minecraft:yellow_terracotta
fill 40 61 341 40 63 341 minecraft:honeycomb_block
setblock 40 61 355 minecraft:yellow_terracotta
fill 40 61 356 40 62 356 minecraft:honeycomb_block
fill 40 61 363 40 62 363 minecraft:honeycomb_block
setblock 41 61 324 minecraft:yellow_terracotta
fill 41 61 325 41 64 325 minecraft:honeycomb_block
setblock 41 61 329 minecraft:yellow_terracotta
fill 41 61 330 41 64 330 minecraft:honeycomb_block
setblock 41 61 334 minecraft:yellow_terracotta
fill 41 61 335 41 64 335 minecraft:honeycomb_block
setblock 41 61 339 minecraft:yellow_terracotta
fill 41 61 340 41 64 340 minecraft:honeycomb_block
setblock 41 61 354 minecraft:yellow_terracotta
fill 41 61 355 41 63 355 minecraft:honeycomb_block
setblock 41 61 359 minecraft:yellow_terracotta
fill 41 61 360 41 64 360 minecraft:honeycomb_block
fill 41 61 362 41 62 362 minecraft:honeycomb_block
setblock 41 61 363 minecraft:honey_block
fill 0 62 348 0 69 351 minecraft:honeycomb_block
setblock 0 62 352 minecraft:orange_terracotta
fill 0 62 353 0 62 355 minecraft:honeycomb_block
setblock 1 62 323 minecraft:yellow_terracotta
fill 1 62 324 1 62 327 minecraft:honeycomb_block
setblock 1 62 328 minecraft:yellow_terracotta
fill 1 62 329 1 63 329 minecraft:honeycomb_block
setblock 1 62 333 minecraft:yellow_terracotta
fill 1 62 334 1 64 334 minecraft:honeycomb_block
fill 1 62 336 1 63 336 minecraft:honeycomb_block
setblock 1 62 338 minecraft:yellow_terracotta
fill 1 62 339 1 64 339 minecraft:honeycomb_block
setblock 1 62 340 minecraft:honey_block
setblock 1 62 353 minecraft:yellow_terracotta
fill 1 62 354 1 64 354 minecraft:honeycomb_block
setblock 1 62 357 minecraft:honeycomb_block
setblock 1 62 358 minecraft:yellow_terracotta
fill 1 62 359 1 65 359 minecraft:honeycomb_block
setblock 1 62 363 minecraft:yellow_terracotta
fill 2 62 323 2 64 323 minecraft:honeycomb_block
setblock 2 62 333 minecraft:honeycomb_block
setblock 2 62 357 minecraft:yellow_terracotta
fill 2 62 358 2 65 358 minecraft:honeycomb_block
setblock 2 62 362 minecraft:yellow_terracotta
fill 2 62 363 5 62 363 minecraft:honeycomb_block
fill 3 62 362 6 62 362 minecraft:honeycomb_block
setblock 6 62 363 minecraft:yellow_terracotta
fill 7 62 323 7 65 323 minecraft:honeycomb_block
setblock 7 62 362 minecraft:yellow_terracotta
fill 7 62 363 7 65 363 minecraft:honeycomb_block
setblock 8 62 361 minecraft:yellow_terracotta
fill 8 62 362 8 65 362 minecraft:honeycomb_block
fill 9 62 361 12 62 361 minecraft:honeycomb_block
fill 10 62 360 13 62 360 minecraft:honeycomb_block
setblock 11 62 323 minecraft:yellow_terracotta
setblock 11 62 363 minecraft:yellow_terracotta
fill 12 62 323 12 65 323 minecraft:honeycomb_block
setblock 12 62 362 minecraft:yellow_terracotta
fill 12 62 363 12 65 363 minecraft:honeycomb_block
fill 13 62 359 14 62 359 minecraft:honeycomb_block
setblock 13 62 361 minecraft:yellow_terracotta
fill 13 62 362 13 65 362 minecraft:honeycomb_block
setblock 14 62 360 minecraft:yellow_terracotta
fill 14 62 361 14 65 361 minecraft:honeycomb_block
setblock 15 62 359 minecraft:yellow_terracotta
fill 15 62 360 15 65 360 minecraft:honeycomb_block
setblock 16 62 323 minecraft:yellow_terracotta
setblock 16 62 363 minecraft:yellow_terracotta
fill 17 62 323 17 63 323 minecraft:honeycomb_block
setblock 17 62 361 minecraft:honeycomb_block
setblock 17 62 362 minecraft:yellow_terracotta
fill 17 62 363 17 65 363 minecraft:honeycomb_block
setblock 18 62 361 minecraft:yellow_terracotta
fill 18 62 362 18 65 362 minecraft:honeycomb_block
setblock 19 62 361 minecraft:honeycomb_block
setblock 20 62 323 minecraft:honey_block
setblock 21 62 363 minecraft:yellow_terracotta
setblock 22 62 363 minecraft:honey_block
setblock 30 62 363 minecraft:honeycomb_block
setblock 31 62 323 minecraft:yellow_terracotta
setblock 31 62 363 minecraft:yellow_terracotta
fill 32 62 323 32 65 323 minecraft:honeycomb_block
fill 32 62 363 35 62 363 minecraft:honeycomb_block
fill 33 62 362 34 64 362 minecraft:honeycomb_block
setblock 34 62 324 minecraft:honeycomb_block
setblock 35 62 324 minecraft:yellow_terracotta
setblock 36 62 323 minecraft:yellow_terracotta
fill 36 62 324 36 65 324 minecraft:honeycomb_block
setblock 36 62 363 minecraft:yellow_terracotta
fill 37 62 323 37 65 323 minecraft:honeycomb_block
setblock 37 62 362 minecraft:yellow_terracotta
fill 37 62 363 37 65 363 minecraft:honeycomb_block
setblock 38 62 331 minecraft:yellow_terracotta
setblock 38 62 332 minecraft:honeycomb_block
setblock 38 62 336 minecraft:yellow_terracotta
fill 38 62 337 38 64 337 minecraft:honeycomb_block
setblock 39 62 330 minecraft:yellow_terracotta
fill 39 62 331 39 63 331 minecraft:honeycomb_block
setblock 39 62 335 minecraft:yellow_terracotta
fill 39 62 336 39 65 336 minecraft:honeycomb_block
setblock 39 62 340 minecraft:yellow_terracotta
setblock 40 62 329 minecraft:yellow_terracotta
fill 40 62 330 40 64 330 minecraft:honeycomb_block
setblock 40 62 334 minecraft:yellow_terracotta
fill 40 62 335 40 65 335 minecraft:honeycomb_block
setblock 40 62 339 minecraft:yellow_terracotta
fill 40 62 340 40 65 340 minecraft:honeycomb_block
setblock 40 62 359 minecraft:yellow_terracotta
setblock 41 62 323 minecraft:yellow_terracotta
fill 41 62 324 41 65 324 minecraft:honeycomb_block
setblock 41 62 328 minecraft:yellow_terracotta
fill 41 62 329 41 65 329 minecraft:honeycomb_block
setblock 41 62 333 minecraft:yellow_terracotta
fill 41 62 334 41 65 334 minecraft:honeycomb_block
setblock 41 62 338 minecraft:yellow_terracotta
fill 41 62 339 41 65 339 minecraft:honeycomb_block
setblock 41 62 346 minecraft:honey_block
setblock 41 62 353 minecraft:yellow_terracotta
setblock 41 62 354 minecraft:honeycomb_block
setblock 41 62 358 minecraft:yellow_terracotta
fill 41 62 359 41 65 359 minecraft:honeycomb_block
setblock 41 62 363 minecraft:yellow_terracotta
fill 0 63 352 0 148 353 minecraft:honeycomb_block
setblock 0 63 354 minecraft:orange_terracotta
fill 0 63 355 0 97 355 minecraft:honeycomb_block
fill 1 63 323 1 63 326 minecraft:honeycomb_block
setblock 1 63 327 minecraft:yellow_terracotta
setblock 1 63 328 minecraft:honeycomb_block
setblock 1 63 332 minecraft:yellow_terracotta
fill 1 63 333 1 64 333 minecraft:honeycomb_block
setblock 1 63 337 minecraft:yellow_terracotta
fill 1 63 338 1 64 338 minecraft:honeycomb_block
setblock 1 63 346 minecraft:honey_block
setblock 1 63 353 minecraft:honeycomb_block
setblock 1 63 357 minecraft:yellow_terracotta
fill 1 63 358 1 66 358 minecraft:honeycomb_block
setblock 1 63 362 minecraft:yellow_terracotta
fill 1 63 363 4 63 363 minecraft:honeycomb_block
setblock 2 63 356 minecraft:yellow_terracotta
fill 2 63 357 2 64 357 minecraft:honeycomb_block
setblock 2 63 361 minecraft:yellow_terracotta
fill 2 63 362 5 63 362 minecraft:honeycomb_block
setblock 3 63 325 minecraft:light[level=15]
setblock 3 63 332 minecraft:light[level=12]
setblock 3 63 333 minecraft:light[level=15]
setblock 3 63 339 minecraft:light[level=12]
setblock 3 63 341 minecraft:light[level=15]
setblock 3 63 346 minecraft:light[level=12]
setblock 3 63 349 minecraft:light[level=15]
setblock 3 63 353 minecraft:light[level=12]
setblock 3 63 357 minecraft:light[level=15]
setblock 3 63 360 minecraft:light[level=12]
fill 5 63 329 6 119 330 minecraft:yellow_terracotta
fill 5 63 358 5 69 358 minecraft:iron_block
setblock 5 63 363 minecraft:yellow_terracotta
fill 6 63 323 6 66 323 minecraft:honeycomb_block
fill 6 63 331 6 119 331 minecraft:yellow_terracotta
setblock 6 63 362 minecraft:yellow_terracotta
fill 6 63 363 6 66 363 minecraft:honeycomb_block
fill 7 63 330 7 119 330 minecraft:yellow_terracotta
setblock 7 63 361 minecraft:yellow_terracotta
fill 7 63 362 7 66 362 minecraft:honeycomb_block
fill 8 63 361 11 63 361 minecraft:honeycomb_block
fill 9 63 360 12 63 360 minecraft:honeycomb_block
fill 10 63 322 10 88 322 minecraft:honeycomb_block
setblock 10 63 323 minecraft:yellow_terracotta
setblock 10 63 325 minecraft:light[level=12]
setblock 10 63 332 minecraft:light[level=12]
setblock 10 63 339 minecraft:light[level=12]
setblock 10 63 346 minecraft:light[level=12]
setblock 10 63 353 minecraft:light[level=12]
setblock 10 63 363 minecraft:yellow_terracotta
fill 11 63 323 11 66 323 minecraft:honeycomb_block
setblock 11 63 325 minecraft:light[level=15]
setblock 11 63 333 minecraft:light[level=15]
setblock 11 63 341 minecraft:light[level=15]
setblock 11 63 349 minecraft:light[level=15]
setblock 11 63 357 minecraft:light[level=15]
setblock 11 63 362 minecraft:yellow_terracotta
fill 11 63 363 11 66 363 minecraft:honeycomb_block
fill 12 63 359 13 63 359 minecraft:honeycomb_block
setblock 12 63 361 minecraft:yellow_terracotta
fill 12 63 362 12 66 362 minecraft:honeycomb_block
setblock 13 63 360 minecraft:yellow_terracotta
fill 13 63 361 13 66 361 minecraft:honeycomb_block
setblock 14 63 359 minecraft:yellow_terracotta
fill 14 63 360 14 66 360 minecraft:honeycomb_block
setblock 15 63 323 minecraft:yellow_terracotta
setblock 15 63 359 minecraft:honeycomb_block
setblock 15 63 363 minecraft:yellow_terracotta
fill 16 63 323 16 64 323 minecraft:honeycomb_block
setblock 16 63 362 minecraft:yellow_terracotta
fill 16 63 363 16 66 363 minecraft:honeycomb_block
setblock 17 63 325 minecraft:light[level=12]
setblock 17 63 332 minecraft:light[level=12]
setblock 17 63 339 minecraft:light[level=12]
setblock 17 63 353 minecraft:light[level=12]
setblock 17 63 361 minecraft:yellow_terracotta
fill 17 63 362 17 66 362 minecraft:honeycomb_block
fill 18 63 361 18 64 361 minecraft:honeycomb_block
setblock 19 63 325 minecraft:light[level=15]
setblock 19 63 333 minecraft:light[level=15]
setblock 19 63 349 minecraft:light[level=15]
setblock 19 63 357 minecraft:light[level=15]
fill 19 63 364 19 96 364 minecraft:honeycomb_block
setblock 20 63 363 minecraft:yellow_terracotta
setblock 20 63 364 minecraft:yellow_concrete
fill 21 63 363 21 64 364 minecraft:honeycomb_block
fill 22 63 364 22 115 364 minecraft:honeycomb_block
setblock 23 63 364 minecraft:yellow_concrete
setblock 24 63 325 minecraft:light[level=12]
setblock 24 63 332 minecraft:light[level=12]
setblock 24 63 339 minecraft:light[level=12]
setblock 24 63 346 minecraft:light[level=12]
setblock 24 63 353 minecraft:light[level=12]
setblock 24 63 360 minecraft:light[level=12]
setblock 27 63 325 minecraft:light[level=15]
setblock 27 63 333 minecraft:light[level=15]
setblock 27 63 341 minecraft:light[level=15]
setblock 27 63 349 minecraft:light[level=15]
setblock 27 63 357 minecraft:light[level=15]
setblock 28 63 363 minecraft:honey_block
setblock 29 63 363 minecraft:honeycomb_block
setblock 30 63 363 minecraft:yellow_terracotta
fill 31 63 323 31 66 323 minecraft:honeycomb_block
setblock 31 63 325 minecraft:light[level=12]
setblock 31 63 332 minecraft:light[level=12]
setblock 31 63 339 minecraft:light[level=12]
setblock 31 63 346 minecraft:light[level=12]
setblock 31 63 353 minecraft:light[level=12]
setblock 31 63 360 minecraft:light[level=12]
fill 31 63 363 34 63 363 minecraft:honeycomb_block
fill 32 63 362 32 66 362 minecraft:honeycomb_block
setblock 34 63 324 minecraft:yellow_terracotta
setblock 35 63 323 minecraft:yellow_terracotta
fill 35 63 324 35 66 324 minecraft:honeycomb_block
setblock 35 63 325 minecraft:light[level=15]
setblock 35 63 333 minecraft:light[level=15]
setblock 35 63 341 minecraft:light[level=15]
setblock 35 63 349 minecraft:light[level=15]
setblock 35 63 357 minecraft:light[level=15]
setblock 35 63 362 minecraft:honeycomb_block
setblock 35 63 363 minecraft:yellow_terracotta
fill 36 63 323 36 66 323 minecraft:honeycomb_block
setblock 36 63 362 minecraft:yellow_terracotta
fill 36 63 363 36 66 363 minecraft:honeycomb_block
fill 37 63 362 38 63 362 minecraft:honeycomb_block
setblock 38 63 325 minecraft:light[level=12]
setblock 38 63 332 minecraft:light[level=12]
setblock 38 63 335 minecraft:yellow_terracotta
fill 38 63 336 38 64 336 minecraft:honeycomb_block
setblock 38 63 339 minecraft:light[level=12]
setblock 38 63 346 minecraft:light[level=12]
setblock 38 63 353 minecraft:light[level=12]
setblock 38 63 360 minecraft:light[level=12]
setblock 39 63 330 minecraft:honeycomb_block
setblock 39 63 334 minecraft:yellow_terracotta
fill 39 63 335 39 65 335 minecraft:honeycomb_block
setblock 39 63 339 minecraft:yellow_terracotta
setblock 39 63 340 minecraft:honeycomb_block
setblock 40 63 323 minecraft:yellow_terracotta
setblock 40 63 328 minecraft:yellow_terracotta
setblock 40 63 329 minecraft:honeycomb_block
setblock 40 63 333 minecraft:yellow_terracotta
fill 40 63 334 40 65 334 minecraft:honeycomb_block
setblock 40 63 338 minecraft:yellow_terracotta
fill 40 63 339 40 65 339 minecraft:honeycomb_block
setblock 40 63 363 minecraft:yellow_terracotta
fill 41 63 323 41 66 323 minecraft:honeycomb_block
setblock 41 63 327 minecraft:yellow_terracotta
fill 41 63 328 41 64 328 minecraft:honeycomb_block
setblock 41 63 332 minecraft:yellow_terracotta
fill 41 63 333 41 66 333 minecraft:honeycomb_block
setblock 41 63 337 minecraft:yellow_terracotta
fill 41 63 338 41 66 338 minecraft:honeycomb_block
setblock 41 63 342 minecraft:yellow_terracotta
setblock 41 63 357 minecraft:yellow_terracotta
fill 41 63 358 41 65 358 minecraft:honeycomb_block
setblock 41 63 362 minecraft:yellow_terracotta
fill 41 63 363 41 66 363 minecraft:honeycomb_block
setblock 0 64 354 minecraft:yellow_concrete
fill 1 64 323 1 64 324 minecraft:honeycomb_block
setblock 1 64 331 minecraft:yellow_terracotta
setblock 1 64 332 minecraft:honeycomb_block
setblock 1 64 336 minecraft:yellow_terracotta
fill 1 64 337 1 65 337 minecraft:honeycomb_block
setblock 1 64 352 minecraft:honey_block
setblock 1 64 356 minecraft:yellow_terracotta
fill 1 64 357 1 67 357 minecraft:honeycomb_block
setblock 1 64 361 minecraft:yellow_terracotta
fill 1 64 362 3 64 363 minecraft:honeycomb_block
setblock 2 64 360 minecraft:yellow_terracotta
fill 2 64 361 2 67 361 minecraft:honeycomb_block
fill 4 64 329 4 65 330 minecraft:brown_terracotta
setblock 4 64 362 minecraft:honeycomb_block
setblock 4 64 363 minecraft:yellow_terracotta
fill 5 64 328 6 65 328 minecraft:brown_terracotta
fill 5 64 331 5 65 331 minecraft:brown_terracotta
setblock 5 64 362 minecraft:yellow_terracotta
fill 5 64 363 5 67 363 minecraft:honeycomb_block
setblock 6 64 361 minecraft:yellow_terracotta
fill 6 64 362 6 67 362 minecraft:honeycomb_block
fill 7 64 329 7 65 329 minecraft:brown_terracotta
fill 7 64 331 7 65 331 minecraft:brown_terracotta
fill 7 64 361 10 64 361 minecraft:honeycomb_block
setblock 8 64 323 minecraft:honeycomb_block
setblock 9 64 323 minecraft:yellow_terracotta
fill 9 64 360 11 64 360 minecraft:honeycomb_block
setblock 9 64 363 minecraft:yellow_terracotta
fill 10 64 323 10 67 323 minecraft:honeycomb_block
setblock 10 64 362 minecraft:yellow_terracotta
fill 10 64 363 10 67 363 minecraft:honeycomb_block
setblock 11 64 361 minecraft:yellow_terracotta
fill 11 64 362 11 67 362 minecraft:honeycomb_block
setblock 12 64 359 minecraft:honeycomb_block
setblock 12 64 360 minecraft:yellow_terracotta
fill 12 64 361 12 67 361 minecraft:honeycomb_block
setblock 13 64 359 minecraft:yellow_terracotta
fill 13 64 360 13 67 360 minecraft:honeycomb_block
setblock 13 64 364 minecraft:yellow_terracotta
fill 14 64 322 14 64 323 minecraft:yellow_terracotta
setblock 14 64 359 minecraft:honeycomb_block
setblock 14 64 363 minecraft:yellow_terracotta
fill 15 64 323 15 66 323 minecraft:honeycomb_block
setblock 15 64 362 minecraft:yellow_terracotta
fill 15 64 363 15 67 363 minecraft:honeycomb_block
setblock 16 64 361 minecraft:yellow_terracotta
fill 16 64 362 16 67 362 minecraft:honeycomb_block
fill 17 64 361 17 65 361 minecraft:honeycomb_block
setblock 19 64 363 minecraft:yellow_terracotta
fill 20 64 363 20 65 364 minecraft:honeycomb_block
fill 23 64 364 23 100 364 minecraft:honeycomb_block
setblock 27 64 323 minecraft:honey_block
setblock 29 64 363 minecraft:yellow_terracotta
fill 30 64 323 30 67 323 minecraft:honeycomb_block
fill 30 64 363 33 64 363 minecraft:honeycomb_block
fill 31 64 362 31 67 362 minecraft:honeycomb_block
setblock 33 64 324 minecraft:yellow_terracotta
setblock 34 64 323 minecraft:yellow_terracotta
fill 34 64 324 34 67 324 minecraft:honeycomb_block
setblock 34 64 363 minecraft:yellow_terracotta
fill 35 64 323 35 67 323 minecraft:honeycomb_block
setblock 35 64 362 minecraft:yellow_terracotta
fill 35 64 363 35 67 363 minecraft:honeycomb_block
fill 36 64 335 36 74 335 minecraft:yellow_terracotta
fill 36 64 362 37 65 362 minecraft:honeycomb_block
setblock 38 64 335 minecraft:honeycomb_block
setblock 39 64 323 minecraft:yellow_terracotta
setblock 39 64 333 minecraft:yellow_terracotta
setblock 39 64 334 minecraft:honeycomb_block
setblock 39 64 338 minecraft:yellow_terracotta
setblock 39 64 339 minecraft:honeycomb_block
setblock 39 64 363 minecraft:yellow_terracotta
fill 40 64 323 40 67 323 minecraft:honeycomb_block
setblock 40 64 332 minecraft:yellow_terracotta
fill 40 64 333 40 65 333 minecraft:honeycomb_block
setblock 40 64 337 minecraft:yellow_terracotta
fill 40 64 338 40 66 338 minecraft:honeycomb_block
fill 40 64 363 40 67 363 minecraft:honeycomb_block
setblock 41 64 326 minecraft:yellow_terracotta
setblock 41 64 327 minecraft:honeycomb_block
setblock 41 64 331 minecraft:yellow_terracotta
fill 41 64 332 41 66 332 minecraft:honeycomb_block
setblock 41 64 336 minecraft:yellow_terracotta
fill 41 64 337 41 67 337 minecraft:honeycomb_block
setblock 41 64 341 minecraft:yellow_terracotta
setblock 41 64 342 minecraft:honeycomb_block
setblock 41 64 353 minecraft:honey_block
setblock 41 64 356 minecraft:yellow_terracotta
setblock 41 64 357 minecraft:honeycomb_block
setblock 41 64 361 minecraft:yellow_terracotta
fill 41 64 362 41 67 362 minecraft:honeycomb_block
setblock 42 64 354 minecraft:yellow_terracotta
fill 0 65 354 0 77 354 minecraft:honeycomb_block
fill 1 65 323 1 66 323 minecraft:honeycomb_block
setblock 1 65 335 minecraft:yellow_terracotta
setblock 1 65 336 minecraft:honeycomb_block
setblock 1 65 339 minecraft:honey_block
setblock 1 65 355 minecraft:yellow_terracotta
fill 1 65 356 1 66 356 minecraft:honeycomb_block
setblock 1 65 360 minecraft:yellow_terracotta
fill 1 65 361 1 66 363 minecraft:honeycomb_block
setblock 2 65 323 minecraft:honey_block
setblock 2 65 359 minecraft:yellow_terracotta
fill 2 65 360 2 68 360 minecraft:honeycomb_block
fill 2 65 362 2 65 363 minecraft:honeycomb_block
fill 3 65 329 3 65 330 minecraft:brown_terracotta
setblock 3 65 362 minecraft:honeycomb_block
setblock 3 65 363 minecraft:yellow_terracotta
setblock 4 65 328 minecraft:brown_terracotta
setblock 4 65 331 minecraft:brown_terracotta
setblock 4 65 362 minecraft:yellow_terracotta
fill 4 65 363 4 68 363 minecraft:honeycomb_block
fill 5 65 327 6 65 327 minecraft:brown_terracotta
fill 5 65 332 6 65 332 minecraft:brown_terracotta
fill 5 65 362 5 68 362 minecraft:honeycomb_block
fill 6 65 361 9 65 361 minecraft:honeycomb_block
setblock 7 65 328 minecraft:brown_terracotta
setblock 8 65 323 minecraft:yellow_terracotta
fill 8 65 329 8 65 330 minecraft:brown_terracotta
setblock 8 65 363 minecraft:yellow_terracotta
fill 9 65 323 9 68 323 minecraft:honeycomb_block
fill 9 65 360 10 65 360 minecraft:honeycomb_block
setblock 9 65 362 minecraft:yellow_terracotta
fill 9 65 363 9 68 363 minecraft:honeycomb_block
setblock 10 65 361 minecraft:yellow_terracotta
fill 10 65 362 10 68 362 minecraft:honeycomb_block
setblock 11 65 360 minecraft:yellow_terracotta
fill 11 65 361 11 68 361 minecraft:honeycomb_block
fill 12 65 360 12 68 360 minecraft:honeycomb_block
setblock 13 65 323 minecraft:yellow_terracotta
setblock 13 65 363 minecraft:yellow_terracotta
fill 13 65 364 13 138 364 minecraft:honeycomb_block
fill 14 65 322 14 68 323 minecraft:honeycomb_block
setblock 14 65 362 minecraft:yellow_terracotta
fill 14 65 363 14 68 363 minecraft:honeycomb_block
setblock 15 65 361 minecraft:yellow_terracotta
fill 15 65 362 15 68 362 minecraft:honeycomb_block
fill 15 65 364 15 120 364 minecraft:honeycomb_block
fill 16 65 361 16 66 361 minecraft:honeycomb_block
setblock 16 65 364 minecraft:orange_terracotta
fill 17 65 364 18 83 364 minecraft:honeycomb_block
setblock 18 65 363 minecraft:yellow_terracotta
setblock 19 65 362 minecraft:yellow_terracotta
fill 19 65 363 19 67 363 minecraft:honeycomb_block
setblock 21 65 323 minecraft:honey_block
setblock 21 65 363 minecraft:honey_block
fill 21 65 364 21 66 364 minecraft:honeycomb_block
fill 22 65 357 22 66 357 minecraft:yellow_concrete
setblock 28 65 363 minecraft:yellow_terracotta
fill 29 65 363 32 65 363 minecraft:honeycomb_block
fill 30 65 362 30 68 362 minecraft:honeycomb_block
setblock 33 65 323 minecraft:yellow_terracotta
fill 33 65 324 33 68 324 minecraft:honeycomb_block
setblock 33 65 362 minecraft:honeycomb_block
setblock 33 65 363 minecraft:yellow_terracotta
fill 34 65 323 34 68 323 minecraft:honeycomb_block
setblock 34 65 362 minecraft:yellow_terracotta
fill 34 65 363 34 68 363 minecraft:honeycomb_block
fill 35 65 362 35 67 362 minecraft:honeycomb_block
setblock 38 65 323 minecraft:yellow_terracotta
setblock 38 65 363 minecraft:yellow_terracotta
fill 39 65 323 39 68 323 minecraft:honeycomb_block
setblock 39 65 337 minecraft:yellow_terracotta
fill 39 65 363 39 68 363 minecraft:honeycomb_block
setblock 40 65 332 minecraft:honeycomb_block
setblock 40 65 336 minecraft:yellow_terracotta
fill 40 65 337 40 66 337 minecraft:honeycomb_block
setblock 41 65 328 minecraft:honey_block
setblock 41 65 330 minecraft:yellow_terracotta
setblock 41 65 331 minecraft:honeycomb_block
setblock 41 65 335 minecraft:yellow_terracotta
fill 41 65 336 41 67 336 minecraft:honeycomb_block
fill 41 65 340 42 65 340 minecraft:yellow_terracotta
setblock 41 65 341 minecraft:honeycomb_block
setblock 41 65 347 minecraft:honey_block
setblock 41 65 360 minecraft:yellow_terracotta
fill 41 65 361 41 68 361 minecraft:honeycomb_block
setblock 42 65 331 minecraft:yellow_terracotta
fill 42 65 354 42 99 354 minecraft:honeycomb_block
setblock 1 66 345 minecraft:honey_block
setblock 1 66 359 minecraft:yellow_terracotta
fill 1 66 360 1 69 360 minecraft:honeycomb_block
setblock 2 66 359 minecraft:honeycomb_block
setblock 2 66 362 minecraft:honeycomb_block
setblock 2 66 363 minecraft:yellow_terracotta
setblock 3 66 362 minecraft:yellow_terracotta
fill 3 66 363 3 69 363 minecraft:honeycomb_block
fill 4 66 362 4 69 362 minecraft:honeycomb_block
fill 6 66 361 8 66 361 minecraft:honeycomb_block
setblock 7 66 323 minecraft:yellow_terracotta
setblock 7 66 363 minecraft:yellow_terracotta
fill 8 66 323 8 69 323 minecraft:honeycomb_block
setblock 8 66 362 minecraft:yellow_terracotta
fill 8 66 363 8 69 363 minecraft:honeycomb_block
setblock 9 66 360 minecraft:honeycomb_block
setblock 9 66 361 minecraft:yellow_terracotta
fill 9 66 362 9 69 362 minecraft:honeycomb_block
setblock 10 66 360 minecraft:yellow_terracotta
fill 10 66 361 10 69 361 minecraft:honeycomb_block
fill 11 66 360 11 68 360 minecraft:honeycomb_block
setblock 12 66 323 minecraft:yellow_terracotta
setblock 12 66 363 minecraft:yellow_terracotta
fill 13 66 323 13 69 323 minecraft:honeycomb_block
setblock 13 66 362 minecraft:yellow_terracotta
fill 13 66 363 13 69 363 minecraft:honeycomb_block
setblock 14 66 361 minecraft:yellow_terracotta
fill 14 66 362 14 69 362 minecraft:honeycomb_block
fill 15 66 361 15 67 361 minecraft:honeycomb_block
fill 16 66 364 16 72 364 minecraft:honeycomb_block
setblock 17 66 363 minecraft:yellow_terracotta
setblock 18 66 362 minecraft:yellow_terracotta
fill 18 66 363 18 68 363 minecraft:honeycomb_block
fill 20 66 364 20 258 364 minecraft:honeycomb_block
setblock 27 66 363 minecraft:honey_block
fill 28 66 363 31 66 363 minecraft:honeycomb_block
fill 29 66 323 29 68 323 minecraft:honeycomb_block
setblock 32 66 323 minecraft:yellow_terracotta
setblock 32 66 363 minecraft:yellow_terracotta
fill 33 66 323 33 69 323 minecraft:honeycomb_block
setblock 33 66 362 minecraft:yellow_terracotta
fill 33 66 363 33 69 363 minecraft:honeycomb_block
fill 34 66 362 34 68 362 minecraft:honeycomb_block
setblock 36 66 362 minecraft:honeycomb_block
setblock 37 66 323 minecraft:yellow_terracotta
setblock 37 66 363 minecraft:yellow_terracotta
fill 38 66 323 38 69 323 minecraft:honeycomb_block
fill 38 66 363 38 69 363 minecraft:honeycomb_block
setblock 40 66 335 minecraft:yellow_terracotta
setblock 40 66 336 minecraft:honeycomb_block
setblock 41 66 334 minecraft:yellow_terracotta
fill 41 66 335 41 67 335 minecraft:honeycomb_block
setblock 41 66 339 minecraft:yellow_terracotta
fill 41 66 340 42 67 340 minecraft:honeycomb_block
setblock 41 66 341 minecraft:honey_block
setblock 41 66 360 minecraft:honeycomb_block
fill 42 66 331 42 140 331 minecraft:honeycomb_block
setblock 42 66 348 minecraft:yellow_terracotta
setblock 1 67 326 minecraft:honey_block
setblock 1 67 351 minecraft:honey_block
setblock 1 67 358 minecraft:yellow_terracotta
fill 1 67 359 1 70 359 minecraft:honeycomb_block
fill 1 67 361 1 67 362 minecraft:honeycomb_block
setblock 1 67 363 minecraft:yellow_terracotta
setblock 2 67 362 minecraft:yellow_terracotta
fill 2 67 363 2 70 363 minecraft:honeycomb_block
fill 3 67 362 3 70 362 minecraft:honeycomb_block
setblock 4 67 322 minecraft:orange_terracotta
setblock 5 67 323 minecraft:honeycomb_block
setblock 6 67 323 minecraft:yellow_terracotta
fill 6 67 361 7 67 361 minecraft:honeycomb_block
setblock 6 67 363 minecraft:yellow_terracotta
fill 7 67 323 7 70 323 minecraft:honeycomb_block
setblock 7 67 362 minecraft:yellow_terracotta
fill 7 67 363 7 70 363 minecraft:honeycomb_block
setblock 8 67 361 minecraft:yellow_terracotta
fill 8 67 362 8 70 362 minecraft:honeycomb_block
setblock 9 67 360 minecraft:yellow_terracotta
fill 9 67 361 9 70 361 minecraft:honeycomb_block
fill 10 67 360 10 68 360 minecraft:honeycomb_block
setblock 11 67 323 minecraft:yellow_terracotta
setblock 11 67 363 minecraft:yellow_terracotta
fill 12 67 323 12 70 323 minecraft:honeycomb_block
setblock 12 67 362 minecraft:yellow_terracotta
fill 12 67 363 12 70 363 minecraft:honeycomb_block
setblock 13 67 361 minecraft:yellow_terracotta
fill 13 67 362 13 70 362 minecraft:honeycomb_block
fill 14 67 361 14 69 361 minecraft:honeycomb_block
setblock 16 67 363 minecraft:yellow_terracotta
setblock 17 67 362 minecraft:yellow_terracotta
fill 17 67 363 17 70 363 minecraft:honeycomb_block
setblock 21 67 364 minecraft:yellow_terracotta
fill 27 67 363 30 67 363 minecraft:honeycomb_block
setblock 28 67 323 minecraft:honey_block
setblock 31 67 323 minecraft:yellow_terracotta
setblock 31 67 363 minecraft:yellow_terracotta
fill 32 67 323 32 69 324 minecraft:honeycomb_block
setblock 32 67 362 minecraft:yellow_terracotta
fill 32 67 363 32 70 363 minecraft:honeycomb_block
fill 33 67 362 33 70 362 minecraft:honeycomb_block
setblock 35 67 324 minecraft:yellow_terracotta
setblock 36 67 323 minecraft:yellow_terracotta
setblock 36 67 363 minecraft:yellow_terracotta
fill 36 67 364 37 148 364 minecraft:honeycomb_block
fill 37 67 323 37 70 323 minecraft:honeycomb_block
fill 37 67 363 37 70 363 minecraft:honeycomb_block
setblock 38 67 364 minecraft:orange_terracotta
fill 39 67 364 42 71 364 minecraft:honeycomb_block
setblock 41 67 323 minecraft:yellow_terracotta
setblock 41 67 338 minecraft:yellow_terracotta
setblock 41 67 339 minecraft:honeycomb_block
setblock 41 67 354 minecraft:honey_block
setblock 41 67 360 minecraft:honey_block
setblock 41 67 363 minecraft:yellow_terracotta
fill 42 67 348 42 86 348 minecraft:honeycomb_block
setblock 42 67 349 minecraft:yellow_concrete
fill 0 68 330 0 74 331 minecraft:honeycomb_block
setblock 0 68 332 minecraft:orange_terracotta
fill 0 68 333 0 89 333 minecraft:honeycomb_block
setblock 0 68 356 minecraft:orange_terracotta
fill 0 68 357 0 127 358 minecraft:honeycomb_block
setblock 0 68 360 minecraft:yellow_terracotta
fill 0 68 361 0 83 363 minecraft:honeycomb_block
setblock 1 68 332 minecraft:honey_block
fill 1 68 338 1 69 338 minecraft:honey_block
setblock 1 68 357 minecraft:honey_block
fill 1 68 358 1 71 358 minecraft:honeycomb_block
setblock 1 68 361 minecraft:honeycomb_block
setblock 1 68 362 minecraft:yellow_terracotta
fill 1 68 363 1 71 363 minecraft:honeycomb_block
setblock 2 68 361 minecraft:yellow_terracotta
fill 2 68 362 2 71 362 minecraft:honeycomb_block
setblock 3 68 323 minecraft:honey_block
fill 4 68 322 4 68 323 minecraft:honeycomb_block
setblock 5 68 323 minecraft:yellow_terracotta
setblock 5 68 363 minecraft:yellow_terracotta
fill 6 68 323 6 71 323 minecraft:honeycomb_block
setblock 6 68 361 minecraft:honeycomb_block
setblock 6 68 362 minecraft:yellow_terracotta
fill 6 68 363 6 71 363 minecraft:honeycomb_block
setblock 7 68 361 minecraft:yellow_terracotta
fill 7 68 362 7 71 362 minecraft:honeycomb_block
fill 8 68 361 8 71 361 minecraft:honeycomb_block
setblock 9 68 360 minecraft:honeycomb_block
setblock 10 68 323 minecraft:yellow_terracotta
setblock 10 68 363 minecraft:yellow_terracotta
fill 11 68 323 11 71 323 minecraft:honeycomb_block
setblock 11 68 362 minecraft:yellow_terracotta
fill 11 68 363 11 71 363 minecraft:honeycomb_block
setblock 12 68 361 minecraft:yellow_terracotta
fill 12 68 362 12 71 362 minecraft:honeycomb_block
fill 13 68 361 13 70 361 minecraft:honeycomb_block
setblock 15 68 363 minecraft:yellow_terracotta
setblock 16 68 362 minecraft:yellow_terracotta
fill 16 68 363 16 71 363 minecraft:honeycomb_block
setblock 20 68 363 minecraft:honey_block
fill 21 68 364 21 203 364 minecraft:honeycomb_block
setblock 22 68 323 minecraft:honey_block
fill 25 68 364 30 90 364 minecraft:honeycomb_block
fill 27 68 363 29 68 363 minecraft:honeycomb_block
fill 28 68 323 28 69 323 minecraft:honeycomb_block
setblock 30 68 323 minecraft:yellow_terracotta
setblock 30 68 363 minecraft:yellow_terracotta
fill 31 68 323 31 70 324 minecraft:honeycomb_block
setblock 31 68 362 minecraft:yellow_terracotta
fill 31 68 363 31 71 363 minecraft:honeycomb_block
setblock 31 68 364 minecraft:yellow_terracotta
fill 32 68 362 32 71 362 minecraft:honeycomb_block
fill 32 68 364 34 73 364 minecraft:honeycomb_block
setblock 34 68 324 minecraft:yellow_terracotta
setblock 35 68 323 minecraft:yellow_terracotta
fill 35 68 324 35 71 324 minecraft:honeycomb_block
setblock 35 68 363 minecraft:yellow_terracotta
fill 36 68 323 36 71 323 minecraft:honeycomb_block
fill 36 68 363 36 71 363 minecraft:honeycomb_block
setblock 37 68 322 minecraft:orange_terracotta
fill 38 68 364 38 234 364 minecraft:honeycomb_block
setblock 40 68 323 minecraft:yellow_terracotta
setblock 40 68 363 minecraft:yellow_terracotta
fill 41 68 323 41 71 323 minecraft:honeycomb_block
setblock 41 68 329 minecraft:honey_block
setblock 41 68 348 minecraft:honey_block
setblock 41 68 362 minecraft:yellow_terracotta
fill 41 68 363 41 71 363 minecraft:honeycomb_block
fill 42 68 340 42 308 340 minecraft:honeycomb_block
fill 42 68 349 42 172 349 minecraft:honeycomb_block
setblock 42 68 359 minecraft:orange_terracotta
fill 42 68 360 42 99 361 minecraft:honeycomb_block
fill 0 69 332 0 108 332 minecraft:honeycomb_block
fill 0 69 356 0 101 356 minecraft:honeycomb_block
fill 0 69 360 0 109 360 minecraft:honeycomb_block
fill 1 69 323 3 69 323 minecraft:honeycomb_block
setblock 1 69 344 minecraft:honey_block
setblock 1 69 361 minecraft:yellow_terracotta
fill 1 69 362 1 72 362 minecraft:honeycomb_block
fill 2 69 361 2 72 361 minecraft:honeycomb_block
setblock 3 69 325 minecraft:light[level=12]
setblock 3 69 332 minecraft:light[level=12]
setblock 3 69 339 minecraft:light[level=12]
setblock 3 69 346 minecraft:light[level=12]
setblock 3 69 353 minecraft:light[level=12]
setblock 3 69 360 minecraft:light[level=12]
fill 4 69 322 4 83 322 minecraft:honeycomb_block
setblock 4 69 323 minecraft:yellow_terracotta
setblock 4 69 363 minecraft:yellow_terracotta
fill 5 69 323 5 72 323 minecraft:honeycomb_block
setblock 5 69 361 minecraft:honeycomb_block
setblock 5 69 362 minecraft:yellow_terracotta
fill 5 69 363 5 72 363 minecraft:honeycomb_block
setblock 6 69 361 minecraft:yellow_terracotta
fill 6 69 362 6 72 362 minecraft:honeycomb_block
fill 7 69 361 7 72 361 minecraft:honeycomb_block
setblock 9 69 323 minecraft:yellow_terracotta
setblock 9 69 363 minecraft:yellow_terracotta
fill 10 69 323 10 72 323 minecraft:honeycomb_block
setblock 10 69 325 minecraft:light[level=12]
setblock 10 69 332 minecraft:light[level=12]
setblock 10 69 339 minecraft:light[level=12]
setblock 10 69 346 minecraft:light[level=12]
setblock 10 69 353 minecraft:light[level=12]
setblock 10 69 360 minecraft:light[level=12]
setblock 10 69 362 minecraft:yellow_terracotta
fill 10 69 363 10 72 363 minecraft:honeycomb_block
setblock 11 69 361 minecraft:yellow_terracotta
fill 11 69 362 11 72 362 minecraft:honeycomb_block
fill 12 69 361 12 72 361 minecraft:honeycomb_block
fill 14 69 322 14 70 322 minecraft:honeycomb_block
setblock 14 69 323 minecraft:yellow_terracotta
setblock 14 69 363 minecraft:yellow_terracotta
setblock 15 69 362 minecraft:yellow_terracotta
fill 15 69 363 15 72 363 minecraft:honeycomb_block
setblock 16 69 323 minecraft:honey_block
setblock 16 69 362 minecraft:honeycomb_block
setblock 17 69 325 minecraft:light[level=12]
setblock 17 69 332 minecraft:light[level=12]
setblock 17 69 339 minecraft:light[level=12]
setblock 17 69 353 minecraft:light[level=12]
setblock 17 69 360 minecraft:light[level=12]
setblock 24 69 325 minecraft:light[level=12]
setblock 24 69 332 minecraft:light[level=12]
setblock 24 69 339 minecraft:light[level=12]
setblock 24 69 346 minecraft:light[level=12]
setblock 24 69 353 minecraft:light[level=12]
setblock 24 69 360 minecraft:light[level=12]
fill 26 69 363 28 69 363 minecraft:honeycomb_block
fill 27 69 323 27 70 323 minecraft:honeycomb_block
setblock 29 69 323 minecraft:yellow_terracotta
setblock 29 69 363 minecraft:yellow_terracotta
fill 30 69 323 30 71 324 minecraft:honeycomb_block
setblock 30 69 362 minecraft:yellow_terracotta
fill 30 69 363 30 72 363 minecraft:honeycomb_block
setblock 31 69 325 minecraft:light[level=12]
setblock 31 69 332 minecraft:light[level=12]
setblock 31 69 339 minecraft:light[level=12]
setblock 31 69 346 minecraft:light[level=12]
setblock 31 69 353 minecraft:light[level=12]
setblock 31 69 360 minecraft:light[level=12]
fill 31 69 362 31 72 362 minecraft:honeycomb_block
fill 31 69 364 31 75 364 minecraft:honeycomb_block
setblock 33 69 324 minecraft:yellow_terracotta
setblock 34 69 323 minecraft:yellow_terracotta
fill 34 69 324 34 72 324 minecraft:honeycomb_block
setblock 34 69 363 minecraft:yellow_terracotta
fill 35 69 323 35 72 323 minecraft:honeycomb_block
fill 35 69 335 35 74 335 minecraft:yellow_terracotta
fill 35 69 363 35 72 363 minecraft:honeycomb_block
fill 36 69 334 36 74 334 minecraft:yellow_terracotta
fill 36 69 336 36 74 336 minecraft:yellow_terracotta
fill 37 69 322 37 124 322 minecraft:honeycomb_block
fill 37 69 335 37 74 335 minecraft:yellow_terracotta
setblock 38 69 325 minecraft:light[level=12]
setblock 38 69 332 minecraft:light[level=12]
setblock 38 69 339 minecraft:light[level=12]
setblock 38 69 346 minecraft:light[level=12]
setblock 38 69 353 minecraft:light[level=12]
setblock 38 69 360 minecraft:light[level=12]
setblock 39 69 323 minecraft:yellow_terracotta
setblock 39 69 363 minecraft:yellow_terracotta
fill 40 69 323 40 72 323 minecraft:honeycomb_block
fill 40 69 363 40 72 363 minecraft:honeycomb_block
fill 41 69 324 41 70 324 minecraft:honeycomb_block
setblock 41 69 342 minecraft:honey_block
fill 41 69 362 41 72 362 minecraft:honeycomb_block
fill 42 69 359 42 106 359 minecraft:honeycomb_block
fill 0 70 348 0 92 350 minecraft:honeycomb_block
setblock 0 70 351 minecraft:yellow_concrete
fill 1 70 323 2 70 323 minecraft:honeycomb_block
setblock 1 70 325 minecraft:honey_block
setblock 1 70 350 minecraft:honey_block
setblock 1 70 360 minecraft:yellow_terracotta
fill 1 70 361 1 73 361 minecraft:honeycomb_block
setblock 3 70 323 minecraft:yellow_terracotta
setblock 3 70 363 minecraft:yellow_terracotta
fill 4 70 323 4 73 323 minecraft:honeycomb_block
setblock 4 70 362 minecraft:yellow_terracotta
fill 4 70 363 4 73 363 minecraft:honeycomb_block
setblock 5 70 361 minecraft:yellow_terracotta
fill 5 70 362 5 73 362 minecraft:honeycomb_block
fill 6 70 361 6 73 361 minecraft:honeycomb_block
setblock 8 70 323 minecraft:yellow_terracotta
setblock 8 70 363 minecraft:yellow_terracotta
fill 9 70 323 9 73 323 minecraft:honeycomb_block
setblock 9 70 362 minecraft:yellow_terracotta
fill 9 70 363 9 73 363 minecraft:honeycomb_block
setblock 10 70 361 minecraft:yellow_terracotta
fill 10 70 362 10 73 362 minecraft:honeycomb_block
fill 11 70 361 11 73 361 minecraft:honeycomb_block
setblock 13 70 323 minecraft:yellow_terracotta
setblock 13 70 363 minecraft:yellow_terracotta
fill 14 70 323 14 73 323 minecraft:honeycomb_block
setblock 14 70 362 minecraft:yellow_terracotta
fill 14 70 363 14 73 363 minecraft:honeycomb_block
setblock 15 70 362 minecraft:honeycomb_block
fill 25 70 363 27 70 363 minecraft:honeycomb_block
fill 26 70 323 26 71 323 minecraft:honeycomb_block
setblock 28 70 323 minecraft:yellow_terracotta
fill 28 70 324 29 72 324 minecraft:honeycomb_block
setblock 28 70 363 minecraft:yellow_terracotta
fill 29 70 323 29 73 323 minecraft:honeycomb_block
setblock 29 70 362 minecraft:yellow_terracotta
fill 29 70 363 29 73 363 minecraft:honeycomb_block
fill 30 70 362 30 73 362 minecraft:honeycomb_block
setblock 32 70 323 minecraft:honeycomb_block
setblock 32 70 324 minecraft:yellow_terracotta
setblock 33 70 323 minecraft:yellow_terracotta
fill 33 70 324 33 73 324 minecraft:honeycomb_block
setblock 33 70 363 minecraft:yellow_terracotta
fill 34 70 323 34 73 323 minecraft:honeycomb_block
fill 34 70 363 34 73 363 minecraft:honeycomb_block
setblock 38 70 323 minecraft:yellow_terracotta
setblock 38 70 363 minecraft:yellow_terracotta
fill 39 70 323 39 73 323 minecraft:honeycomb_block
fill 39 70 363 39 73 363 minecraft:honeycomb_block
setblock 41 70 325 minecraft:yellow_terracotta
setblock 41 70 336 minecraft:honey_block
fill 41 70 361 41 73 361 minecraft:honeycomb_block
fill 42 70 345 42 264 345 minecraft:honeycomb_block
setblock 42 70 346 minecraft:orange_terracotta
fill 0 71 351 0 80 351 minecraft:honeycomb_block
setblock 1 71 323 minecraft:honeycomb_block
setblock 1 71 324 minecraft:yellow_terracotta
setblock 1 71 331 minecraft:honey_block
setblock 1 71 356 minecraft:honey_block
setblock 1 71 359 minecraft:yellow_terracotta
fill 1 71 360 2 73 360 minecraft:honeycomb_block
setblock 2 71 323 minecraft:yellow_terracotta
setblock 2 71 363 minecraft:yellow_terracotta
fill 3 71 323 3 74 323 minecraft:honeycomb_block
setblock 3 71 325 minecraft:light[level=15]
setblock 3 71 333 minecraft:light[level=15]
setblock 3 71 341 minecraft:light[level=15]
setblock 3 71 349 minecraft:light[level=15]
setblock 3 71 357 minecraft:light[level=15]
setblock 3 71 362 minecraft:yellow_terracotta
fill 3 71 363 3 74 363 minecraft:honeycomb_block
setblock 4 71 361 minecraft:yellow_terracotta
fill 4 71 362 4 74 362 minecraft:honeycomb_block
fill 5 71 361 5 74 361 minecraft:honeycomb_block
setblock 7 71 323 minecraft:yellow_terracotta
fill 7 71 324 10 71 324 minecraft:honeycomb_block
setblock 7 71 363 minecraft:yellow_terracotta
fill 8 71 323 8 74 323 minecraft:honeycomb_block
fill 8 71 349 8 72 349 minecraft:yellow_concrete
setblock 8 71 362 minecraft:yellow_terracotta
fill 8 71 363 8 74 363 minecraft:honeycomb_block
fill 9 71 349 9 72 349 minecraft:black_concrete
setblock 9 71 361 minecraft:yellow_terracotta
fill 9 71 362 9 74 362 minecraft:honeycomb_block
fill 10 71 361 10 74 361 minecraft:honeycomb_block
setblock 11 71 325 minecraft:light[level=15]
setblock 11 71 333 minecraft:light[level=15]
setblock 11 71 341 minecraft:light[level=15]
setblock 11 71 349 minecraft:light[level=15]
setblock 11 71 357 minecraft:light[level=15]
setblock 12 71 323 minecraft:yellow_terracotta
setblock 12 71 363 minecraft:yellow_terracotta
fill 13 71 323 13 74 323 minecraft:honeycomb_block
setblock 13 71 362 minecraft:yellow_terracotta
fill 13 71 363 13 74 363 minecraft:honeycomb_block
setblock 14 71 322 minecraft:orange_terracotta
fill 14 71 362 14 73 362 minecraft:honeycomb_block
setblock 17 71 363 minecraft:yellow_terracotta
setblock 19 71 325 minecraft:light[level=15]
setblock 19 71 333 minecraft:light[level=15]
setblock 19 71 349 minecraft:light[level=15]
setblock 19 71 357 minecraft:light[level=15]
fill 24 71 323 25 72 323 minecraft:honeycomb_block
fill 24 71 363 26 71 363 minecraft:honeycomb_block
setblock 27 71 323 minecraft:yellow_terracotta
fill 27 71 324 27 74 324 minecraft:honeycomb_block
setblock 27 71 325 minecraft:light[level=15]
setblock 27 71 333 minecraft:light[level=15]
setblock 27 71 341 minecraft:light[level=15]
setblock 27 71 349 minecraft:light[level=15]
setblock 27 71 357 minecraft:light[level=15]
setblock 27 71 363 minecraft:yellow_terracotta
fill 28 71 323 28 74 323 minecraft:honeycomb_block
setblock 28 71 362 minecraft:yellow_terracotta
fill 28 71 363 28 74 363 minecraft:honeycomb_block
fill 29 71 362 29 74 362 minecraft:honeycomb_block
setblock 31 71 323 minecraft:honeycomb_block
setblock 31 71 324 minecraft:yellow_terracotta
setblock 32 71 323 minecraft:yellow_terracotta
fill 32 71 324 32 74 324 minecraft:honeycomb_block
setblock 32 71 363 minecraft:yellow_terracotta
fill 33 71 323 33 74 323 minecraft:honeycomb_block
setblock 33 71 362 minecraft:yellow_terracotta
fill 33 71 363 33 74 363 minecraft:honeycomb_block
setblock 35 71 325 minecraft:light[level=15]
setblock 35 71 333 minecraft:light[level=15]
fill 35 71 334 35 74 334 minecraft:yellow_terracotta
fill 35 71 336 35 74 336 minecraft:yellow_terracotta
setblock 35 71 341 minecraft:light[level=15]
setblock 35 71 349 minecraft:light[level=15]
setblock 35 71 357 minecraft:light[level=15]
setblock 36 71 324 minecraft:yellow_terracotta
setblock 37 71 323 minecraft:yellow_terracotta
fill 37 71 324 37 74 324 minecraft:honeycomb_block
fill 37 71 334 37 74 334 minecraft:yellow_terracotta
fill 37 71 336 37 74 336 minecraft:yellow_terracotta
setblock 37 71 363 minecraft:yellow_terracotta
fill 38 71 323 38 74 323 minecraft:honeycomb_block
fill 38 71 363 38 74 363 minecraft:honeycomb_block
setblock 41 71 324 minecraft:yellow_terracotta
fill 41 71 325 41 73 326 minecraft:honeycomb_block
setblock 41 71 330 minecraft:honey_block
setblock 41 71 355 minecraft:honey_block
setblock 42 71 335 minecraft:yellow_concrete
fill 42 71 346 42 95 346 minecraft:honeycomb_block
setblock 1 72 323 minecraft:yellow_terracotta
fill 1 72 324 1 74 325 minecraft:honeycomb_block
setblock 1 72 337 minecraft:honey_block
setblock 1 72 358 minecraft:yellow_terracotta
fill 1 72 359 1 75 359 minecraft:honeycomb_block
setblock 1 72 363 minecraft:yellow_terracotta
fill 2 72 323 2 75 323 minecraft:honeycomb_block
setblock 2 72 362 minecraft:yellow_terracotta
fill 2 72 363 2 75 363 minecraft:honeycomb_block
fill 3 72 362 3 75 362 minecraft:honeycomb_block
setblock 4 72 324 minecraft:honeycomb_block
fill 4 72 361 4 75 361 minecraft:honeycomb_block
setblock 5 72 324 minecraft:yellow_terracotta
setblock 6 72 323 minecraft:yellow_terracotta
fill 6 72 324 9 72 324 minecraft:honeycomb_block
setblock 6 72 363 minecraft:yellow_terracotta
fill 7 72 323 7 75 323 minecraft:honeycomb_block
setblock 7 72 362 minecraft:yellow_terracotta
fill 7 72 363 7 75 363 minecraft:honeycomb_block
setblock 8 72 361 minecraft:yellow_terracotta
fill 8 72 362 8 75 362 minecraft:honeycomb_block
fill 9 72 361 9 75 361 minecraft:honeycomb_block
setblock 10 72 324 minecraft:yellow_terracotta
setblock 11 72 323 minecraft:yellow_terracotta
fill 11 72 324 11 75 324 minecraft:honeycomb_block
setblock 11 72 363 minecraft:yellow_terracotta
fill 12 72 323 12 75 323 minecraft:honeycomb_block
setblock 12 72 362 minecraft:yellow_terracotta
fill 12 72 363 12 75 363 minecraft:honeycomb_block
fill 13 72 362 13 74 362 minecraft:honeycomb_block
fill 14 72 322 14 179 322 minecraft:honeycomb_block
setblock 16 72 363 minecraft:yellow_terracotta
setblock 19 72 363 minecraft:honey_block
fill 23 72 323 23 74 323 minecraft:honeycomb_block
fill 23 72 363 25 72 363 minecraft:honeycomb_block
setblock 25 72 324 minecraft:yellow_terracotta
setblock 26 72 323 minecraft:yellow_terracotta
fill 26 72 324 26 75 324 minecraft:honeycomb_block
fill 26 72 326 28 73 328 minecraft:honey_block
setblock 26 72 363 minecraft:yellow_terracotta
fill 27 72 323 27 75 323 minecraft:honeycomb_block
setblock 27 72 362 minecraft:yellow_terracotta
fill 27 72 363 27 75 363 minecraft:honeycomb_block
setblock 28 72 325 minecraft:honeycomb_block
fill 28 72 362 28 75 362 minecraft:honeycomb_block
setblock 29 72 325 minecraft:yellow_terracotta
setblock 30 72 323 minecraft:honeycomb_block
setblock 30 72 324 minecraft:yellow_terracotta
fill 30 72 325 33 72 325 minecraft:honeycomb_block
setblock 31 72 323 minecraft:yellow_terracotta
fill 31 72 324 31 75 324 minecraft:honeycomb_block
setblock 31 72 363 minecraft:yellow_terracotta
fill 32 72 323 32 75 323 minecraft:honeycomb_block
setblock 32 72 362 minecraft:yellow_terracotta
fill 32 72 363 32 75 363 minecraft:honeycomb_block
fill 33 72 362 33 73 362 minecraft:honeycomb_block
setblock 35 72 324 minecraft:yellow_terracotta
setblock 36 72 323 minecraft:yellow_terracotta
fill 36 72 324 36 75 324 minecraft:honeycomb_block
setblock 36 72 363 minecraft:yellow_terracotta
fill 37 72 323 37 75 323 minecraft:honeycomb_block
fill 37 72 363 37 75 363 minecraft:honeycomb_block
fill 38 72 324 39 72 324 minecraft:honeycomb_block
fill 39 72 364 40 74 364 minecraft:honeycomb_block
setblock 40 72 324 minecraft:yellow_terracotta
setblock 41 72 323 minecraft:yellow_terracotta
fill 41 72 324 41 75 324 minecraft:honeycomb_block
setblock 41 72 327 minecraft:honeycomb_block
setblock 41 72 349 minecraft:honey_block
setblock 41 72 363 minecraft:yellow_terracotta
setblock 41 72 364 minecraft:yellow_concrete
fill 42 72 335 42 247 335 minecraft:honeycomb_block
setblock 42 72 339 minecraft:yellow_terracotta
fill 42 72 364 42 308 364 minecraft:honeycomb_block
fill 1 73 323 1 76 323 minecraft:honeycomb_block
setblock 1 73 326 minecraft:honeycomb_block
setblock 1 73 342 minecraft:yellow_terracotta
fill 1 73 343 1 73 346 minecraft:honeycomb_block
setblock 1 73 347 minecraft:yellow_terracotta
setblock 1 73 357 minecraft:yellow_terracotta
fill 1 73 358 1 76 358 minecraft:honeycomb_block
setblock 1 73 362 minecraft:yellow_terracotta
fill 1 73 363 1 76 363 minecraft:honeycomb_block
fill 2 73 324 3 73 324 minecraft:honeycomb_block
fill 2 73 359 2 74 359 minecraft:honeycomb_block
setblock 2 73 361 minecraft:yellow_terracotta
fill 2 73 362 2 76 362 minecraft:honeycomb_block
fill 3 73 361 3 76 361 minecraft:honeycomb_block
setblock 4 73 324 minecraft:yellow_terracotta
setblock 5 73 323 minecraft:yellow_terracotta
fill 5 73 324 8 73 324 minecraft:honeycomb_block
setblock 5 73 363 minecraft:yellow_terracotta
fill 6 73 323 6 76 323 minecraft:honeycomb_block
setblock 6 73 362 minecraft:yellow_terracotta
fill 6 73 363 6 76 363 minecraft:honeycomb_block
setblock 7 73 361 minecraft:yellow_terracotta
fill 7 73 362 7 76 362 minecraft:honeycomb_block
fill 8 73 361 8 76 361 minecraft:honeycomb_block
setblock 9 73 324 minecraft:yellow_terracotta
setblock 10 73 323 minecraft:yellow_terracotta
fill 10 73 324 10 76 324 minecraft:honeycomb_block
setblock 10 73 363 minecraft:yellow_terracotta
fill 11 73 323 11 76 323 minecraft:honeycomb_block
setblock 11 73 362 minecraft:yellow_terracotta
fill 11 73 363 11 76 363 minecraft:honeycomb_block
fill 12 73 362 12 76 362 minecraft:honeycomb_block
setblock 15 73 323 minecraft:yellow_terracotta
setblock 15 73 363 minecraft:yellow_terracotta
fill 16 73 363 16 74 363 minecraft:honeycomb_block
setblock 16 73 364 minecraft:orange_terracotta
setblock 17 73 323 minecraft:honey_block
fill 19 73 345 19 119 346 minecraft:yellow_terracotta
fill 21 73 323 22 75 323 minecraft:honeycomb_block
fill 22 73 363 24 73 363 minecraft:honeycomb_block
setblock 24 73 323 minecraft:honeycomb_block
setblock 24 73 324 minecraft:yellow_terracotta
fill 24 73 326 25 75 328 minecraft:honey_block
setblock 25 73 323 minecraft:yellow_terracotta
fill 25 73 324 25 76 324 minecraft:honeycomb_block
setblock 25 73 325 minecraft:honey_block
fill 25 73 329 29 88 329 minecraft:honey_block
setblock 25 73 363 minecraft:yellow_terracotta
fill 26 73 323 26 76 323 minecraft:honeycomb_block
fill 26 73 325 27 73 325 minecraft:honeycomb_block
fill 26 73 330 28 88 330 minecraft:honey_block
setblock 26 73 362 minecraft:yellow_terracotta
fill 26 73 363 26 76 363 minecraft:honeycomb_block
fill 27 73 362 27 76 362 minecraft:honeycomb_block
setblock 28 73 324 minecraft:honeycomb_block
setblock 28 73 325 minecraft:yellow_terracotta
setblock 29 73 324 minecraft:yellow_terracotta
fill 29 73 325 32 73 325 minecraft:honeycomb_block
fill 29 73 326 30 73 328 minecraft:honey_block
setblock 30 73 323 minecraft:yellow_terracotta
fill 30 73 324 30 76 324 minecraft:honeycomb_block
setblock 30 73 363 minecraft:yellow_terracotta
fill 31 73 323 31 76 323 minecraft:honeycomb_block
setblock 31 73 362 minecraft:yellow_terracotta
fill 31 73 363 31 76 363 minecraft:honeycomb_block
fill 32 73 362 32 75 362 minecraft:honeycomb_block
setblock 33 73 325 minecraft:yellow_terracotta
setblock 34 73 324 minecraft:yellow_terracotta
fill 34 73 325 34 76 325 minecraft:honeycomb_block
setblock 35 73 323 minecraft:yellow_terracotta
fill 35 73 324 35 76 324 minecraft:honeycomb_block
setblock 35 73 363 minecraft:yellow_terracotta
fill 36 73 323 36 76 323 minecraft:honeycomb_block
fill 36 73 363 36 76 363 minecraft:honeycomb_block
setblock 38 73 324 minecraft:honeycomb_block
setblock 39 73 324 minecraft:yellow_terracotta
setblock 40 73 323 minecraft:yellow_terracotta
fill 40 73 324 40 75 325 minecraft:honeycomb_block
setblock 40 73 363 minecraft:yellow_terracotta
fill 41 73 323 41 76 323 minecraft:honeycomb_block
setblock 41 73 327 minecraft:yellow_terracotta
fill 41 73 328 41 76 328 minecraft:honeycomb_block
setblock 41 73 343 minecraft:honey_block
fill 41 73 360 41 74 360 minecraft:honeycomb_block
setblock 41 73 362 minecraft:yellow_terracotta
fill 41 73 363 41 76 364 minecraft:honeycomb_block
fill 42 73 339 42 250 339 minecraft:honeycomb_block
setblock 42 73 343 minecraft:yellow_concrete
setblock 1 74 326 minecraft:yellow_terracotta
fill 1 74 327 1 77 327 minecraft:honeycomb_block
setblock 1 74 330 minecraft:honey_block
setblock 1 74 341 minecraft:yellow_terracotta
fill 1 74 342 1 74 345 minecraft:honeycomb_block
setblock 1 74 346 minecraft:yellow_terracotta
fill 1 74 347 1 74 350 minecraft:honeycomb_block
setblock 1 74 351 minecraft:yellow_terracotta
setblock 1 74 356 minecraft:yellow_terracotta
fill 1 74 357 1 77 357 minecraft:honeycomb_block
setblock 1 74 360 minecraft:honeycomb_block
setblock 1 74 361 minecraft:yellow_terracotta
fill 1 74 362 1 77 362 minecraft:honeycomb_block
setblock 2 74 324 minecraft:honeycomb_block
setblock 2 74 325 minecraft:yellow_terracotta
setblock 2 74 344 minecraft:honeycomb_block
setblock 2 74 345 minecraft:yellow_terracotta
fill 2 74 346 2 75 348 minecraft:honeycomb_block
fill 2 74 358 2 75 358 minecraft:honeycomb_block
setblock 2 74 360 minecraft:yellow_terracotta
fill 2 74 361 2 77 361 minecraft:honeycomb_block
setblock 3 74 324 minecraft:yellow_terracotta
setblock 4 74 323 minecraft:yellow_terracotta
fill 4 74 324 7 74 324 minecraft:honeycomb_block
setblock 4 74 363 minecraft:yellow_terracotta
fill 5 74 323 5 77 323 minecraft:honeycomb_block
setblock 5 74 362 minecraft:yellow_terracotta
fill 5 74 363 5 77 363 minecraft:honeycomb_block
setblock 6 74 361 minecraft:yellow_terracotta
fill 6 74 362 6 77 362 minecraft:honeycomb_block
fill 7 74 361 7 77 361 minecraft:honeycomb_block
setblock 8 74 324 minecraft:yellow_terracotta
setblock 9 74 323 minecraft:yellow_terracotta
fill 9 74 324 9 77 324 minecraft:honeycomb_block
setblock 9 74 363 minecraft:yellow_terracotta
fill 10 74 323 10 77 323 minecraft:honeycomb_block
setblock 10 74 362 minecraft:yellow_terracotta
fill 10 74 363 10 77 363 minecraft:honeycomb_block
setblock 11 74 361 minecraft:yellow_terracotta
fill 11 74 362 11 76 362 minecraft:honeycomb_block
setblock 12 74 324 minecraft:honeycomb_block
setblock 14 74 323 minecraft:yellow_terracotta
setblock 14 74 363 minecraft:yellow_terracotta
fill 15 74 323 15 77 323 minecraft:honeycomb_block
fill 15 74 363 15 75 363 minecraft:honeycomb_block
fill 16 74 364 16 134 364 minecraft:honeycomb_block
setblock 20 74 322 minecraft:yellow_concrete
fill 20 74 323 20 77 323 minecraft:honeycomb_block
fill 22 74 363 23 74 363 minecraft:honeycomb_block
setblock 23 74 324 minecraft:yellow_terracotta
fill 23 74 326 23 77 328 minecraft:honey_block
setblock 24 74 323 minecraft:yellow_terracotta
fill 24 74 324 24 77 324 minecraft:honeycomb_block
setblock 24 74 325 minecraft:honey_block
fill 24 74 329 24 87 330 minecraft:honey_block
setblock 24 74 363 minecraft:yellow_terracotta
fill 25 74 323 25 77 323 minecraft:honeycomb_block
fill 25 74 325 26 74 325 minecraft:honeycomb_block
fill 25 74 330 25 87 330 minecraft:honey_block
fill 25 74 363 25 77 363 minecraft:honeycomb_block
fill 26 74 326 27 74 328 minecraft:honey_block
fill 26 74 331 28 87 331 minecraft:honey_block
fill 26 74 362 26 77 362 minecraft:honeycomb_block
setblock 27 74 325 minecraft:yellow_terracotta
setblock 28 74 324 minecraft:yellow_terracotta
fill 28 74 325 30 74 326 minecraft:honeycomb_block
fill 28 74 327 31 87 328 minecraft:honey_block
setblock 29 74 323 minecraft:yellow_terracotta
fill 29 74 324 29 77 324 minecraft:honeycomb_block
fill 29 74 330 30 87 330 minecraft:honey_block
setblock 29 74 363 minecraft:yellow_terracotta
fill 30 74 323 30 77 323 minecraft:honeycomb_block
fill 30 74 329 30 87 329 minecraft:honey_block
setblock 30 74 362 minecraft:yellow_terracotta
fill 30 74 363 30 77 363 minecraft:honeycomb_block
setblock 31 74 325 minecraft:honeycomb_block
setblock 31 74 326 minecraft:honey_block
fill 31 74 362 31 75 362 minecraft:honeycomb_block
setblock 32 74 325 minecraft:yellow_terracotta
fill 32 74 364 33 136 364 minecraft:honeycomb_block
setblock 33 74 324 minecraft:yellow_terracotta
fill 33 74 325 33 77 325 minecraft:honeycomb_block
setblock 34 74 323 minecraft:yellow_terracotta
fill 34 74 324 34 77 324 minecraft:honeycomb_block
fill 34 74 363 34 74 364 minecraft:yellow_terracotta
fill 35 74 323 35 77 323 minecraft:honeycomb_block
fill 35 74 325 35 75 325 minecraft:honeycomb_block
fill 35 74 363 35 77 363 minecraft:honeycomb_block
setblock 38 74 324 minecraft:yellow_terracotta
setblock 39 74 323 minecraft:yellow_terracotta
fill 39 74 324 39 77 324 minecraft:honeycomb_block
setblock 39 74 363 minecraft:yellow_terracotta
fill 40 74 323 40 77 323 minecraft:honeycomb_block
setblock 40 74 326 minecraft:honeycomb_block
setblock 40 74 327 minecraft:yellow_terracotta
fill 40 74 363 40 77 363 minecraft:honeycomb_block
setblock 41 74 325 minecraft:honeycomb_block
setblock 41 74 326 minecraft:yellow_terracotta
fill 41 74 327 41 77 327 minecraft:honeycomb_block
fill 41 74 329 41 75 329 minecraft:honeycomb_block
setblock 41 74 337 minecraft:honey_block
fill 41 74 342 41 74 345 minecraft:honeycomb_block
setblock 41 74 356 minecraft:honey_block
setblock 41 74 361 minecraft:yellow_terracotta
fill 41 74 362 41 77 362 minecraft:honeycomb_block
fill 42 74 343 42 134 343 minecraft:honeycomb_block
fill 0 75 330 0 83 330 minecraft:honeycomb_block
setblock 0 75 331 minecraft:yellow_terracotta
setblock 1 75 324 minecraft:honeycomb_block
setblock 1 75 325 minecraft:yellow_terracotta
fill 1 75 326 2 77 326 minecraft:honeycomb_block
fill 1 75 328 1 76 328 minecraft:honeycomb_block
setblock 1 75 336 minecraft:honey_block
fill 1 75 341 1 75 344 minecraft:honeycomb_block
setblock 1 75 345 minecraft:yellow_terracotta
fill 1 75 346 1 75 349 minecraft:honeycomb_block
setblock 1 75 350 minecraft:yellow_terracotta
fill 1 75 351 1 75 354 minecraft:honeycomb_block
setblock 1 75 355 minecraft:yellow_terracotta
fill 1 75 356 1 78 356 minecraft:honeycomb_block
setblock 1 75 360 minecraft:yellow_terracotta
fill 1 75 361 1 78 361 minecraft:honeycomb_block
setblock 2 75 324 minecraft:yellow_terracotta
fill 2 75 325 2 78 325 minecraft:honeycomb_block
fill 2 75 342 2 75 343 minecraft:honeycomb_block
setblock 2 75 344 minecraft:yellow_terracotta
fill 2 75 345 3 77 345 minecraft:honeycomb_block
setblock 2 75 349 minecraft:yellow_terracotta
fill 2 75 350 2 76 352 minecraft:honeycomb_block
fill 2 75 357 2 76 357 minecraft:honeycomb_block
setblock 2 75 359 minecraft:yellow_terracotta
fill 2 75 360 3 77 360 minecraft:honeycomb_block
setblock 3 75 323 minecraft:yellow_terracotta
fill 3 75 324 6 75 324 minecraft:honeycomb_block
setblock 3 75 325 minecraft:light[level=12]
setblock 3 75 332 minecraft:light[level=12]
setblock 3 75 339 minecraft:light[level=12]
fill 3 75 340 3 80 340 minecraft:brown_terracotta
fill 3 75 344 3 78 344 minecraft:honeycomb_block
fill 3 75 346 3 75 347 minecraft:honeycomb_block
setblock 3 75 348 minecraft:yellow_terracotta
fill 3 75 349 3 78 349 minecraft:honeycomb_block
setblock 3 75 353 minecraft:light[level=12]
setblock 3 75 363 minecraft:yellow_terracotta
fill 4 75 323 4 78 323 minecraft:honeycomb_block
fill 4 75 325 5 75 325 minecraft:honeycomb_block
setblock 4 75 362 minecraft:yellow_terracotta
fill 4 75 363 4 78 363 minecraft:honeycomb_block
setblock 5 75 361 minecraft:yellow_terracotta
fill 5 75 362 5 78 362 minecraft:honeycomb_block
setblock 6 75 325 minecraft:yellow_terracotta
fill 6 75 361 6 78 361 minecraft:honeycomb_block
setblock 7 75 324 minecraft:yellow_terracotta
fill 7 75 325 8 77 325 minecraft:honeycomb_block
setblock 8 75 323 minecraft:yellow_terracotta
fill 8 75 324 8 78 324 minecraft:honeycomb_block
setblock 8 75 363 minecraft:yellow_terracotta
fill 9 75 323 9 78 323 minecraft:honeycomb_block
setblock 9 75 362 minecraft:yellow_terracotta
fill 9 75 363 9 78 363 minecraft:honeycomb_block
setblock 10 75 325 minecraft:light[level=12]
setblock 10 75 332 minecraft:light[level=12]
setblock 10 75 339 minecraft:light[level=12]
setblock 10 75 346 minecraft:light[level=12]
setblock 10 75 353 minecraft:light[level=12]
setblock 10 75 360 minecraft:light[level=12]
setblock 10 75 361 minecraft:yellow_terracotta
fill 10 75 362 10 77 362 minecraft:honeycomb_block
setblock 12 75 324 minecraft:yellow_terracotta
setblock 13 75 323 minecraft:yellow_terracotta
setblock 13 75 363 minecraft:yellow_terracotta
fill 14 75 323 14 77 323 minecraft:honeycomb_block
fill 14 75 363 14 76 363 minecraft:honeycomb_block
fill 16 75 323 17 75 323 minecraft:honeycomb_block
setblock 17 75 325 minecraft:light[level=12]
setblock 17 75 332 minecraft:light[level=12]
setblock 17 75 339 minecraft:light[level=12]
setblock 17 75 353 minecraft:light[level=12]
setblock 17 75 360 minecraft:light[level=12]
setblock 18 75 323 minecraft:yellow_terracotta
setblock 18 75 363 minecraft:honey_block
fill 19 75 323 19 78 323 minecraft:honeycomb_block
fill 20 75 322 20 127 322 minecraft:honeycomb_block
setblock 21 75 322 minecraft:yellow_concrete
setblock 21 75 324 minecraft:honeycomb_block
fill 21 75 363 22 75 363 minecraft:honeycomb_block
setblock 22 75 324 minecraft:yellow_terracotta
setblock 22 75 327 minecraft:ochre_froglight
setblock 23 75 323 minecraft:yellow_terracotta
fill 23 75 324 23 78 324 minecraft:honeycomb_block
setblock 23 75 325 minecraft:honey_block
fill 23 75 329 23 86 329 minecraft:honey_block
setblock 23 75 330 minecraft:ochre_froglight
setblock 23 75 363 minecraft:yellow_terracotta
fill 24 75 323 24 78 323 minecraft:honeycomb_block
fill 24 75 325 25 75 325 minecraft:honeycomb_block
setblock 24 75 331 minecraft:ochre_froglight
setblock 24 75 332 minecraft:light[level=12]
setblock 24 75 339 minecraft:light[level=12]
setblock 24 75 346 minecraft:light[level=12]
setblock 24 75 353 minecraft:light[level=12]
setblock 24 75 360 minecraft:light[level=12]
fill 24 75 363 24 78 363 minecraft:honeycomb_block
fill 25 75 331 25 86 331 minecraft:honey_block
fill 25 75 362 25 76 362 minecraft:honeycomb_block
setblock 26 75 325 minecraft:yellow_terracotta
fill 26 75 326 29 75 326 minecraft:honeycomb_block
fill 26 75 327 27 89 328 minecraft:honey_block
setblock 27 75 324 minecraft:yellow_terracotta
fill 27 75 325 30 75 325 minecraft:honeycomb_block
setblock 27 75 332 minecraft:ochre_froglight
setblock 28 75 323 minecraft:yellow_terracotta
fill 28 75 324 28 78 324 minecraft:honeycomb_block
setblock 28 75 363 minecraft:yellow_terracotta
fill 29 75 323 29 78 323 minecraft:honeycomb_block
fill 29 75 331 29 86 331 minecraft:honey_block
setblock 29 75 362 minecraft:yellow_terracotta
fill 29 75 363 29 78 363 minecraft:honeycomb_block
setblock 30 75 326 minecraft:yellow_terracotta
setblock 30 75 331 minecraft:ochre_froglight
fill 30 75 362 30 76 362 minecraft:honeycomb_block
setblock 31 75 325 minecraft:yellow_terracotta
fill 31 75 326 31 78 326 minecraft:honeycomb_block
fill 31 75 329 31 86 329 minecraft:honey_block
setblock 31 75 330 minecraft:ochre_froglight
setblock 31 75 332 minecraft:light[level=12]
setblock 31 75 339 minecraft:light[level=12]
setblock 31 75 346 minecraft:light[level=12]
setblock 31 75 353 minecraft:light[level=12]
setblock 31 75 360 minecraft:light[level=12]
setblock 32 75 324 minecraft:yellow_terracotta
fill 32 75 325 32 78 325 minecraft:honeycomb_block
setblock 32 75 327 minecraft:ochre_froglight
setblock 33 75 323 minecraft:yellow_terracotta
fill 33 75 324 33 78 324 minecraft:honeycomb_block
setblock 33 75 363 minecraft:yellow_terracotta
fill 34 75 323 34 78 323 minecraft:honeycomb_block
fill 34 75 363 34 78 364 minecraft:honeycomb_block
setblock 36 75 325 minecraft:yellow_terracotta
setblock 37 75 324 minecraft:yellow_terracotta
fill 37 75 325 37 78 325 minecraft:honeycomb_block
setblock 38 75 323 minecraft:yellow_terracotta
fill 38 75 324 38 78 324 minecraft:honeycomb_block
setblock 38 75 325 minecraft:light[level=12]
setblock 38 75 332 minecraft:light[level=12]
setblock 38 75 339 minecraft:light[level=12]
setblock 38 75 346 minecraft:light[level=12]
setblock 38 75 353 minecraft:light[level=12]
setblock 38 75 360 minecraft:light[level=12]
setblock 38 75 363 minecraft:yellow_terracotta
fill 39 75 323 39 78 323 minecraft:honeycomb_block
fill 39 75 325 39 76 325 minecraft:honeycomb_block
fill 39 75 363 39 78 363 minecraft:honeycomb_block
setblock 39 75 364 minecraft:yellow_concrete
setblock 40 75 326 minecraft:yellow_terracotta
fill 40 75 327 40 77 328 minecraft:honeycomb_block
fill 40 75 362 40 78 362 minecraft:honeycomb_block
fill 40 75 364 40 77 364 minecraft:honeycomb_block
setblock 41 75 325 minecraft:yellow_terracotta
fill 41 75 326 41 78 326 minecraft:honeycomb_block
setblock 41 75 330 minecraft:yellow_terracotta
fill 41 75 331 41 78 331 minecraft:honeycomb_block
fill 41 75 341 41 75 344 minecraft:honeycomb_block
setblock 41 75 345 minecraft:yellow_terracotta
fill 41 75 346 41 76 348 minecraft:honeycomb_block
setblock 41 75 350 minecraft:honey_block
setblock 41 75 359 minecraft:honeycomb_block
setblock 41 75 360 minecraft:yellow_terracotta
fill 41 75 361 41 78 361 minecraft:honeycomb_block
fill 0 76 322 0 244 323 minecraft:honeycomb_block
setblock 0 76 324 minecraft:yellow_concrete
fill 0 76 325 0 114 328 minecraft:honeycomb_block
fill 0 76 331 0 142 331 minecraft:honeycomb_block
setblock 1 76 324 minecraft:yellow_terracotta
fill 1 76 325 1 79 325 minecraft:honeycomb_block
setblock 1 76 329 minecraft:yellow_terracotta
fill 1 76 341 1 76 343 minecraft:honeycomb_block
setblock 1 76 344 minecraft:yellow_terracotta
fill 1 76 345 1 76 348 minecraft:honeycomb_block
setblock 1 76 349 minecraft:yellow_terracotta
fill 1 76 350 1 76 353 minecraft:honeycomb_block
setblock 1 76 354 minecraft:yellow_terracotta
fill 1 76 355 2 78 355 minecraft:honeycomb_block
setblock 1 76 359 minecraft:yellow_terracotta
fill 1 76 360 1 79 360 minecraft:honeycomb_block
setblock 2 76 323 minecraft:yellow_terracotta
fill 2 76 324 5 76 324 minecraft:honeycomb_block
setblock 2 76 327 minecraft:honeycomb_block
setblock 2 76 342 minecraft:honeycomb_block
setblock 2 76 343 minecraft:yellow_terracotta
fill 2 76 344 2 79 344 minecraft:honeycomb_block
fill 2 76 346 2 76 347 minecraft:honeycomb_block
setblock 2 76 348 minecraft:yellow_terracotta
fill 2 76 349 2 79 349 minecraft:honeycomb_block
setblock 2 76 353 minecraft:yellow_terracotta
fill 2 76 354 2 79 354 minecraft:honeycomb_block
fill 2 76 356 2 77 356 minecraft:honeycomb_block
setblock 2 76 358 minecraft:yellow_terracotta
fill 2 76 359 2 79 359 minecraft:honeycomb_block
setblock 2 76 363 minecraft:yellow_terracotta
fill 3 76 323 3 79 323 minecraft:honeycomb_block
fill 3 76 325 4 76 325 minecraft:honeycomb_block
fill 3 76 343 3 78 343 minecraft:honeycomb_block
setblock 3 76 346 minecraft:honeycomb_block
setblock 3 76 347 minecraft:yellow_terracotta
fill 3 76 348 4 78 348 minecraft:honeycomb_block
fill 3 76 350 3 76 351 minecraft:honeycomb_block
setblock 3 76 352 minecraft:yellow_terracotta
setblock 3 76 362 minecraft:yellow_terracotta
fill 3 76 363 3 79 363 minecraft:honeycomb_block
setblock 4 76 346 minecraft:yellow_terracotta
fill 4 76 347 4 79 347 minecraft:honeycomb_block
fill 4 76 349 4 77 349 minecraft:honeycomb_block
setblock 4 76 361 minecraft:yellow_terracotta
fill 4 76 362 4 79 362 minecraft:honeycomb_block
setblock 5 76 325 minecraft:yellow_terracotta
fill 5 76 361 5 78 361 minecraft:honeycomb_block
setblock 6 76 324 minecraft:yellow_terracotta
fill 6 76 325 6 78 325 minecraft:honeycomb_block
setblock 7 76 323 minecraft:yellow_terracotta
fill 7 76 324 7 79 324 minecraft:honeycomb_block
setblock 7 76 363 minecraft:yellow_terracotta
fill 8 76 323 8 79 323 minecraft:honeycomb_block
setblock 8 76 362 minecraft:yellow_terracotta
fill 8 76 363 8 79 363 minecraft:honeycomb_block
setblock 9 76 361 minecraft:yellow_terracotta
fill 9 76 362 9 78 362 minecraft:honeycomb_block
setblock 11 76 324 minecraft:yellow_terracotta
setblock 12 76 323 minecraft:yellow_terracotta
setblock 12 76 324 minecraft:honeycomb_block
setblock 12 76 363 minecraft:yellow_terracotta
fill 13 76 323 13 78 323 minecraft:honeycomb_block
fill 13 76 363 13 77 363 minecraft:honeycomb_block
setblock 16 76 323 minecraft:honeycomb_block
setblock 17 76 323 minecraft:yellow_terracotta
fill 18 76 323 18 79 323 minecraft:honeycomb_block
fill 21 76 322 21 76 323 minecraft:honeycomb_block
setblock 21 76 324 minecraft:yellow_terracotta
setblock 21 76 363 minecraft:honeycomb_block
setblock 22 76 323 minecraft:yellow_terracotta
fill 22 76 324 22 79 324 minecraft:honeycomb_block
fill 22 76 325 22 76 329 minecraft:honey_block
setblock 22 76 363 minecraft:yellow_terracotta
fill 23 76 323 23 79 323 minecraft:honeycomb_block
fill 23 76 325 24 76 325 minecraft:honeycomb_block
fill 23 76 330 23 85 330 minecraft:honey_block
fill 23 76 363 23 79 363 minecraft:honeycomb_block
fill 24 76 326 24 76 328 minecraft:honey_block
fill 24 76 331 24 85 331 minecraft:honey_block
setblock 25 76 325 minecraft:yellow_terracotta
fill 25 76 326 28 76 326 minecraft:honeycomb_block
fill 25 76 327 25 88 328 minecraft:honey_block
fill 25 76 332 29 85 332 minecraft:honey_block
setblock 26 76 324 minecraft:yellow_terracotta
fill 26 76 325 29 76 325 minecraft:honeycomb_block
setblock 27 76 323 minecraft:yellow_terracotta
fill 27 76 324 27 79 324 minecraft:honeycomb_block
setblock 27 76 363 minecraft:yellow_terracotta
fill 28 76 323 28 79 323 minecraft:honeycomb_block
setblock 28 76 362 minecraft:yellow_terracotta
fill 28 76 363 28 79 363 minecraft:honeycomb_block
setblock 29 76 326 minecraft:yellow_terracotta
fill 29 76 362 29 77 362 minecraft:honeycomb_block
setblock 30 76 325 minecraft:yellow_terracotta
fill 30 76 326 30 79 326 minecraft:honeycomb_block
fill 30 76 331 30 85 331 minecraft:honey_block
setblock 31 76 324 minecraft:yellow_terracotta
fill 31 76 325 31 79 325 minecraft:honeycomb_block
fill 31 76 330 31 85 330 minecraft:honey_block
setblock 31 76 364 minecraft:yellow_terracotta
setblock 32 76 323 minecraft:yellow_terracotta
fill 32 76 324 32 79 324 minecraft:honeycomb_block
fill 32 76 326 32 77 326 minecraft:honeycomb_block
fill 32 76 327 32 85 329 minecraft:honey_block
setblock 32 76 363 minecraft:yellow_terracotta
fill 33 76 323 33 79 323 minecraft:honeycomb_block
fill 33 76 363 33 78 363 minecraft:honeycomb_block
setblock 35 76 325 minecraft:yellow_terracotta
setblock 36 76 324 minecraft:yellow_terracotta
fill 36 76 325 36 78 325 minecraft:honeycomb_block
setblock 37 76 323 minecraft:yellow_terracotta
fill 37 76 324 37 79 324 minecraft:honeycomb_block
setblock 37 76 363 minecraft:yellow_terracotta
setblock 38 76 322 minecraft:yellow_terracotta
fill 38 76 323 38 79 323 minecraft:honeycomb_block
fill 38 76 325 38 77 325 minecraft:honeycomb_block
fill 38 76 363 38 79 363 minecraft:honeycomb_block
setblock 39 76 326 minecraft:yellow_terracotta
fill 39 76 353 39 85 353 minecraft:brown_terracotta
fill 39 76 364 39 190 364 minecraft:honeycomb_block
setblock 40 76 324 minecraft:honeycomb_block
setblock 40 76 325 minecraft:yellow_terracotta
fill 40 76 326 40 79 326 minecraft:honeycomb_block
setblock 40 76 329 minecraft:honeycomb_block
setblock 41 76 324 minecraft:yellow_terracotta
fill 41 76 325 41 79 325 minecraft:honeycomb_block
setblock 41 76 329 minecraft:yellow_terracotta
fill 41 76 330 41 79 330 minecraft:honeycomb_block
fill 41 76 341 41 76 343 minecraft:honeycomb_block
setblock 41 76 344 minecraft:yellow_terracotta
fill 41 76 345 41 79 345 minecraft:honeycomb_block
setblock 41 76 349 minecraft:yellow_terracotta
fill 41 76 350 41 78 351 minecraft:honeycomb_block
setblock 41 76 358 minecraft:honeycomb_block
setblock 41 76 359 minecraft:yellow_terracotta
fill 41 76 360 41 79 360 minecraft:honeycomb_block
fill 0 77 324 4 77 324 minecraft:honeycomb_block
setblock 1 77 323 minecraft:yellow_terracotta
setblock 1 77 328 minecraft:yellow_terracotta
fill 1 77 329 1 79 330 minecraft:honeycomb_block
fill 1 77 341 1 77 342 minecraft:honeycomb_block
setblock 1 77 343 minecraft:yellow_terracotta
fill 1 77 344 1 77 347 minecraft:honeycomb_block
setblock 1 77 348 minecraft:yellow_terracotta
fill 1 77 349 1 77 352 minecraft:honeycomb_block
setblock 1 77 353 minecraft:yellow_terracotta
fill 1 77 354 1 80 354 minecraft:honeycomb_block
setblock 1 77 358 minecraft:yellow_terracotta
fill 1 77 359 1 80 359 minecraft:honeycomb_block
setblock 1 77 363 minecraft:yellow_terracotta
fill 2 77 323 2 80 323 minecraft:honeycomb_block
setblock 2 77 327 minecraft:yellow_terracotta
fill 2 77 328 2 80 328 minecraft:honeycomb_block
setblock 2 77 342 minecraft:yellow_terracotta
fill 2 77 343 2 80 343 minecraft:honeycomb_block
setblock 2 77 346 minecraft:honeycomb_block
setblock 2 77 347 minecraft:yellow_terracotta
fill 2 77 348 2 80 348 minecraft:honeycomb_block
fill 2 77 350 2 77 351 minecraft:honeycomb_block
setblock 2 77 352 minecraft:yellow_terracotta
fill 2 77 353 3 79 353 minecraft:honeycomb_block
setblock 2 77 357 minecraft:yellow_terracotta
fill 2 77 358 2 80 358 minecraft:honeycomb_block
setblock 2 77 362 minecraft:yellow_terracotta
fill 2 77 363 2 80 363 minecraft:honeycomb_block
setblock 3 77 325 minecraft:honeycomb_block
setblock 3 77 326 minecraft:yellow_terracotta
setblock 3 77 346 minecraft:yellow_terracotta
fill 3 77 347 3 80 347 minecraft:honeycomb_block
setblock 3 77 350 minecraft:honeycomb_block
setblock 3 77 351 minecraft:yellow_terracotta
fill 3 77 352 3 80 352 minecraft:honeycomb_block
fill 3 77 354 3 78 354 minecraft:honeycomb_block
setblock 3 77 361 minecraft:yellow_terracotta
fill 3 77 362 3 80 362 minecraft:honeycomb_block
setblock 4 77 325 minecraft:yellow_terracotta
setblock 4 77 345 minecraft:yellow_terracotta
fill 4 77 346 4 80 346 minecraft:honeycomb_block
setblock 4 77 350 minecraft:yellow_terracotta
fill 4 77 351 4 80 351 minecraft:honeycomb_block
fill 4 77 361 4 78 361 minecraft:honeycomb_block
setblock 5 77 324 minecraft:yellow_terracotta
fill 5 77 325 5 79 325 minecraft:honeycomb_block
setblock 6 77 323 minecraft:yellow_terracotta
fill 6 77 324 6 80 324 minecraft:honeycomb_block
setblock 6 77 363 minecraft:yellow_terracotta
fill 7 77 323 7 80 323 minecraft:honeycomb_block
setblock 7 77 362 minecraft:yellow_terracotta
fill 7 77 363 7 80 363 minecraft:honeycomb_block
setblock 8 77 361 minecraft:yellow_terracotta
schedule function dropper:buildpart/72_2 1t
