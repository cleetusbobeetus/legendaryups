fill 216 242 597 216 243 597 minecraft:quartz_block
fill 217 242 592 217 243 592 minecraft:quartz_block
fill 217 242 594 217 243 594 minecraft:quartz_block
fill 217 242 596 217 243 596 minecraft:quartz_block
fill 217 242 598 217 243 598 minecraft:quartz_block
fill 218 242 593 218 243 593 minecraft:quartz_block
fill 218 242 595 218 243 595 minecraft:quartz_block
fill 218 242 597 218 243 597 minecraft:quartz_block
fill 219 242 592 219 243 592 minecraft:quartz_block
fill 219 242 594 219 243 594 minecraft:quartz_block
fill 219 242 596 219 243 596 minecraft:quartz_block
fill 219 242 598 219 273 598 minecraft:quartz_block
fill 220 242 593 220 243 593 minecraft:quartz_block
fill 220 242 595 220 243 595 minecraft:quartz_block
fill 220 242 597 220 245 597 minecraft:quartz_block
fill 221 242 592 221 243 592 minecraft:quartz_block
fill 221 242 594 221 243 594 minecraft:quartz_block
fill 221 242 596 221 243 596 minecraft:quartz_block
fill 221 242 598 221 273 598 minecraft:quartz_block
fill 222 242 593 222 243 593 minecraft:quartz_block
fill 222 242 595 222 243 595 minecraft:quartz_block
fill 222 242 597 222 245 597 minecraft:quartz_block
fill 223 242 592 223 243 592 minecraft:quartz_block
fill 223 242 594 223 243 594 minecraft:quartz_block
fill 223 242 596 223 243 596 minecraft:quartz_block
fill 223 242 598 223 243 598 minecraft:quartz_block
fill 224 242 593 224 243 593 minecraft:quartz_block
fill 224 242 595 224 243 595 minecraft:quartz_block
fill 224 242 597 224 243 597 minecraft:quartz_block
fill 225 242 592 225 243 592 minecraft:quartz_block
fill 225 242 594 225 243 594 minecraft:quartz_block
fill 225 242 596 225 243 596 minecraft:quartz_block
fill 225 242 598 225 243 598 minecraft:quartz_block
fill 226 242 593 226 243 593 minecraft:quartz_block
fill 226 242 595 226 243 595 minecraft:quartz_block
fill 226 242 597 226 243 597 minecraft:quartz_block
setblock 191 243 568 minecraft:light[level=14]
setblock 191 243 576 minecraft:light[level=14]
setblock 191 243 584 minecraft:light[level=14]
setblock 199 243 560 minecraft:light[level=14]
setblock 199 243 568 minecraft:light[level=14]
setblock 199 243 576 minecraft:light[level=14]
setblock 199 243 584 minecraft:light[level=14]
setblock 199 243 592 minecraft:light[level=14]
setblock 207 243 560 minecraft:light[level=14]
setblock 207 243 568 minecraft:light[level=14]
setblock 207 243 576 minecraft:light[level=14]
setblock 207 243 584 minecraft:light[level=14]
setblock 215 243 560 minecraft:light[level=14]
setblock 215 243 568 minecraft:light[level=14]
setblock 215 243 576 minecraft:light[level=14]
setblock 215 243 584 minecraft:light[level=14]
setblock 215 243 592 minecraft:light[level=14]
setblock 223 243 560 minecraft:light[level=14]
setblock 223 243 568 minecraft:light[level=14]
setblock 223 243 576 minecraft:light[level=14]
setblock 223 243 584 minecraft:light[level=14]
setblock 189 244 560 minecraft:ochre_froglight
setblock 189 244 562 minecraft:ochre_froglight
setblock 189 244 564 minecraft:ochre_froglight
setblock 189 244 590 minecraft:ochre_froglight
setblock 189 244 592 minecraft:ochre_froglight
setblock 189 244 594 minecraft:ochre_froglight
setblock 190 244 559 minecraft:ochre_froglight
setblock 190 244 561 minecraft:ochre_froglight
setblock 190 244 563 minecraft:ochre_froglight
setblock 190 244 565 minecraft:ochre_froglight
setblock 190 244 589 minecraft:ochre_froglight
setblock 190 244 591 minecraft:ochre_froglight
setblock 190 244 593 minecraft:ochre_froglight
setblock 190 244 595 minecraft:ochre_froglight
setblock 191 244 560 minecraft:ochre_froglight
setblock 191 244 562 minecraft:ochre_froglight
setblock 191 244 564 minecraft:ochre_froglight
setblock 191 244 590 minecraft:ochre_froglight
setblock 191 244 592 minecraft:ochre_froglight
setblock 191 244 594 minecraft:ochre_froglight
setblock 192 244 559 minecraft:ochre_froglight
setblock 192 244 561 minecraft:ochre_froglight
setblock 192 244 563 minecraft:ochre_froglight
setblock 192 244 565 minecraft:ochre_froglight
setblock 192 244 589 minecraft:ochre_froglight
setblock 192 244 591 minecraft:ochre_froglight
setblock 192 244 593 minecraft:ochre_froglight
setblock 192 244 595 minecraft:ochre_froglight
setblock 193 244 560 minecraft:ochre_froglight
setblock 193 244 562 minecraft:ochre_froglight
setblock 193 244 564 minecraft:ochre_froglight
setblock 193 244 590 minecraft:ochre_froglight
setblock 193 244 592 minecraft:ochre_froglight
setblock 193 244 594 minecraft:ochre_froglight
setblock 194 244 559 minecraft:ochre_froglight
setblock 194 244 561 minecraft:ochre_froglight
setblock 194 244 563 minecraft:ochre_froglight
setblock 194 244 565 minecraft:ochre_froglight
setblock 194 244 589 minecraft:ochre_froglight
setblock 194 244 591 minecraft:ochre_froglight
setblock 194 244 593 minecraft:ochre_froglight
setblock 194 244 595 minecraft:ochre_froglight
setblock 195 244 560 minecraft:ochre_froglight
setblock 195 244 562 minecraft:ochre_froglight
setblock 195 244 564 minecraft:ochre_froglight
setblock 195 244 590 minecraft:ochre_froglight
setblock 195 244 592 minecraft:ochre_froglight
setblock 195 244 594 minecraft:ochre_froglight
setblock 196 244 559 minecraft:ochre_froglight
setblock 196 244 561 minecraft:ochre_froglight
setblock 196 244 563 minecraft:ochre_froglight
setblock 196 244 565 minecraft:ochre_froglight
setblock 196 244 589 minecraft:ochre_froglight
setblock 196 244 591 minecraft:ochre_froglight
setblock 196 244 593 minecraft:ochre_froglight
setblock 196 244 595 minecraft:ochre_froglight
setblock 197 244 560 minecraft:ochre_froglight
setblock 197 244 562 minecraft:ochre_froglight
setblock 197 244 564 minecraft:ochre_froglight
setblock 197 244 590 minecraft:ochre_froglight
setblock 197 244 592 minecraft:ochre_froglight
setblock 197 244 594 minecraft:ochre_froglight
setblock 198 244 559 minecraft:ochre_froglight
setblock 198 244 561 minecraft:ochre_froglight
setblock 198 244 563 minecraft:ochre_froglight
setblock 198 244 565 minecraft:ochre_froglight
setblock 198 244 589 minecraft:ochre_froglight
setblock 198 244 591 minecraft:ochre_froglight
setblock 198 244 593 minecraft:ochre_froglight
setblock 198 244 595 minecraft:ochre_froglight
setblock 205 244 590 minecraft:ochre_froglight
setblock 205 244 592 minecraft:ochre_froglight
setblock 205 244 594 minecraft:ochre_froglight
setblock 205 244 596 minecraft:ochre_froglight
setblock 205 244 598 minecraft:ochre_froglight
setblock 206 244 591 minecraft:ochre_froglight
setblock 206 244 593 minecraft:ochre_froglight
setblock 206 244 595 minecraft:ochre_froglight
setblock 206 244 597 minecraft:ochre_froglight
setblock 207 244 590 minecraft:ochre_froglight
setblock 207 244 592 minecraft:ochre_froglight
setblock 207 244 594 minecraft:ochre_froglight
setblock 207 244 596 minecraft:ochre_froglight
setblock 207 244 598 minecraft:ochre_froglight
setblock 208 244 591 minecraft:ochre_froglight
setblock 208 244 593 minecraft:ochre_froglight
setblock 208 244 595 minecraft:ochre_froglight
setblock 208 244 597 minecraft:ochre_froglight
setblock 209 244 590 minecraft:ochre_froglight
setblock 209 244 592 minecraft:ochre_froglight
setblock 209 244 594 minecraft:ochre_froglight
setblock 209 244 596 minecraft:ochre_froglight
setblock 209 244 598 minecraft:ochre_froglight
setblock 210 244 591 minecraft:ochre_froglight
setblock 210 244 593 minecraft:ochre_froglight
setblock 210 244 595 minecraft:ochre_froglight
setblock 210 244 597 minecraft:ochre_froglight
setblock 211 244 590 minecraft:ochre_froglight
setblock 211 244 592 minecraft:ochre_froglight
setblock 211 244 594 minecraft:ochre_froglight
setblock 211 244 596 minecraft:ochre_froglight
setblock 211 244 598 minecraft:ochre_froglight
fill 217 244 593 219 244 597 minecraft:gold_block
fill 220 244 593 225 244 596 minecraft:gold_block
fill 223 244 597 225 244 597 minecraft:gold_block
fill 189 245 560 189 246 560 minecraft:quartz_block
fill 189 245 561 189 245 566 minecraft:yellow_terracotta
fill 189 245 573 189 245 578 minecraft:yellow_terracotta
fill 189 245 585 189 245 590 minecraft:yellow_terracotta
fill 189 245 592 189 273 592 minecraft:quartz_block
fill 189 245 594 189 273 594 minecraft:quartz_block
fill 189 245 597 189 245 598 minecraft:yellow_terracotta
fill 190 245 559 190 246 559 minecraft:quartz_block
fill 190 245 561 190 246 561 minecraft:quartz_block
fill 190 245 563 190 246 563 minecraft:quartz_block
fill 190 245 565 190 246 565 minecraft:quartz_block
fill 190 245 589 190 247 589 minecraft:quartz_block
fill 190 245 591 190 247 591 minecraft:quartz_block
fill 190 245 593 190 247 593 minecraft:quartz_block
fill 190 245 595 190 247 595 minecraft:quartz_block
fill 190 245 598 193 245 598 minecraft:yellow_terracotta
fill 191 245 560 191 246 560 minecraft:quartz_block
fill 191 245 562 191 246 562 minecraft:quartz_block
fill 191 245 564 191 246 564 minecraft:quartz_block
fill 191 245 590 191 247 590 minecraft:quartz_block
fill 191 245 592 191 247 592 minecraft:quartz_block
fill 191 245 594 191 247 594 minecraft:quartz_block
fill 192 245 559 192 246 559 minecraft:quartz_block
fill 192 245 561 192 246 561 minecraft:quartz_block
fill 192 245 563 192 246 563 minecraft:quartz_block
fill 192 245 565 192 246 565 minecraft:quartz_block
fill 192 245 589 192 247 589 minecraft:quartz_block
fill 192 245 591 192 247 591 minecraft:quartz_block
fill 192 245 593 192 247 593 minecraft:quartz_block
fill 192 245 595 192 247 595 minecraft:quartz_block
fill 193 245 558 198 245 558 minecraft:yellow_terracotta
fill 193 245 560 193 246 560 minecraft:quartz_block
fill 193 245 562 193 246 562 minecraft:quartz_block
fill 193 245 564 193 246 564 minecraft:quartz_block
fill 193 245 590 193 247 590 minecraft:quartz_block
fill 193 245 592 193 247 592 minecraft:quartz_block
fill 193 245 594 193 247 594 minecraft:quartz_block
fill 194 245 559 194 246 559 minecraft:quartz_block
fill 194 245 561 194 246 561 minecraft:quartz_block
fill 194 245 563 194 246 563 minecraft:quartz_block
fill 194 245 565 194 246 565 minecraft:quartz_block
fill 194 245 589 194 247 589 minecraft:quartz_block
fill 194 245 591 194 247 591 minecraft:quartz_block
fill 194 245 593 194 247 593 minecraft:quartz_block
fill 194 245 595 194 247 595 minecraft:quartz_block
fill 195 245 560 195 246 560 minecraft:quartz_block
fill 195 245 562 195 246 562 minecraft:quartz_block
fill 195 245 564 195 246 564 minecraft:quartz_block
fill 195 245 590 195 247 590 minecraft:quartz_block
fill 195 245 592 195 247 592 minecraft:quartz_block
fill 195 245 594 195 247 594 minecraft:quartz_block
fill 196 245 559 196 246 559 minecraft:quartz_block
fill 196 245 561 196 246 561 minecraft:quartz_block
fill 196 245 563 196 246 563 minecraft:quartz_block
fill 196 245 565 196 246 565 minecraft:quartz_block
fill 196 245 589 196 247 589 minecraft:quartz_block
fill 196 245 591 196 247 591 minecraft:quartz_block
fill 196 245 593 196 247 593 minecraft:quartz_block
fill 196 245 595 196 247 595 minecraft:quartz_block
fill 197 245 560 197 246 560 minecraft:quartz_block
fill 197 245 562 197 246 562 minecraft:quartz_block
fill 197 245 564 197 246 564 minecraft:quartz_block
fill 197 245 590 197 247 590 minecraft:quartz_block
fill 197 245 592 197 247 592 minecraft:quartz_block
fill 197 245 594 197 247 594 minecraft:quartz_block
fill 198 245 559 198 246 559 minecraft:quartz_block
fill 198 245 561 198 246 561 minecraft:quartz_block
fill 198 245 563 198 246 563 minecraft:quartz_block
fill 198 245 565 198 246 565 minecraft:quartz_block
fill 198 245 589 198 247 589 minecraft:quartz_block
fill 198 245 591 198 247 591 minecraft:quartz_block
fill 198 245 593 198 247 593 minecraft:quartz_block
fill 198 245 595 198 247 595 minecraft:quartz_block
fill 200 245 598 205 245 598 minecraft:yellow_terracotta
fill 205 245 558 210 245 558 minecraft:yellow_terracotta
fill 205 245 590 205 246 590 minecraft:quartz_block
fill 205 245 592 205 246 592 minecraft:quartz_block
fill 205 245 594 205 246 594 minecraft:quartz_block
fill 205 245 596 205 246 596 minecraft:quartz_block
fill 206 245 591 206 246 591 minecraft:quartz_block
fill 206 245 593 206 246 593 minecraft:quartz_block
fill 206 245 595 206 246 595 minecraft:quartz_block
fill 206 245 597 206 246 597 minecraft:quartz_block
fill 207 245 590 207 246 590 minecraft:quartz_block
fill 207 245 592 207 246 592 minecraft:quartz_block
fill 207 245 594 207 246 594 minecraft:quartz_block
fill 207 245 596 207 246 596 minecraft:quartz_block
fill 207 245 598 207 246 598 minecraft:quartz_block
fill 208 245 591 208 246 591 minecraft:quartz_block
fill 208 245 593 208 246 593 minecraft:quartz_block
fill 208 245 595 208 246 595 minecraft:quartz_block
fill 208 245 597 208 246 597 minecraft:quartz_block
fill 209 245 590 209 246 590 minecraft:quartz_block
fill 209 245 592 209 246 592 minecraft:quartz_block
fill 209 245 594 209 246 594 minecraft:quartz_block
fill 209 245 596 209 246 596 minecraft:quartz_block
fill 209 245 598 209 246 598 minecraft:quartz_block
fill 210 245 591 210 246 591 minecraft:quartz_block
fill 210 245 593 210 246 593 minecraft:quartz_block
fill 210 245 595 210 246 595 minecraft:quartz_block
fill 210 245 597 210 246 597 minecraft:quartz_block
fill 211 245 590 211 246 590 minecraft:quartz_block
fill 211 245 592 211 246 592 minecraft:quartz_block
fill 211 245 594 211 246 594 minecraft:quartz_block
fill 211 245 596 211 246 596 minecraft:quartz_block
fill 211 245 598 211 246 598 minecraft:quartz_block
fill 212 245 598 217 245 598 minecraft:yellow_terracotta
fill 217 245 558 222 245 558 minecraft:yellow_terracotta
fill 218 245 594 224 245 596 minecraft:gold_block
fill 224 245 598 229 245 598 minecraft:yellow_terracotta
fill 229 245 558 229 245 563 minecraft:yellow_terracotta
fill 229 245 570 229 245 575 minecraft:yellow_terracotta
fill 229 245 582 229 245 587 minecraft:yellow_terracotta
fill 229 245 594 229 245 597 minecraft:yellow_terracotta
fill 188 246 563 188 251 566 minecraft:ochre_froglight
fill 188 246 575 188 251 578 minecraft:ochre_froglight
fill 188 246 587 188 251 590 minecraft:ochre_froglight
fill 188 246 599 191 251 599 minecraft:ochre_froglight
fill 189 246 561 189 246 565 minecraft:quartz_block
fill 189 246 589 189 247 590 minecraft:quartz_block
fill 195 246 557 198 251 557 minecraft:ochre_froglight
fill 200 246 599 203 251 599 minecraft:ochre_froglight
setblock 205 246 598 minecraft:quartz_block
fill 207 246 557 210 251 557 minecraft:ochre_froglight
fill 212 246 599 215 251 599 minecraft:ochre_froglight
fill 219 246 557 222 251 557 minecraft:ochre_froglight
fill 219 246 595 223 246 595 minecraft:gold_block
fill 220 246 581 222 247 581 minecraft:gold_block
fill 221 246 580 221 247 580 minecraft:gold_block
fill 221 246 582 221 247 582 minecraft:gold_block
fill 224 246 599 227 251 599 minecraft:ochre_froglight
fill 230 246 558 230 251 561 minecraft:ochre_froglight
fill 230 246 570 230 251 573 minecraft:ochre_froglight
fill 230 246 582 230 251 585 minecraft:ochre_froglight
fill 230 246 594 230 251 597 minecraft:ochre_froglight
setblock 189 247 560 minecraft:ochre_froglight
fill 189 247 561 189 257 561 minecraft:quartz_block
setblock 189 247 562 minecraft:ochre_froglight
fill 189 247 563 189 257 563 minecraft:quartz_block
setblock 189 247 564 minecraft:ochre_froglight
fill 189 247 565 189 257 565 minecraft:quartz_block
setblock 190 247 559 minecraft:ochre_froglight
setblock 190 247 561 minecraft:ochre_froglight
setblock 190 247 563 minecraft:ochre_froglight
setblock 190 247 565 minecraft:ochre_froglight
setblock 191 247 560 minecraft:ochre_froglight
setblock 191 247 562 minecraft:ochre_froglight
setblock 191 247 564 minecraft:ochre_froglight
setblock 192 247 559 minecraft:ochre_froglight
setblock 192 247 561 minecraft:ochre_froglight
setblock 192 247 563 minecraft:ochre_froglight
setblock 192 247 565 minecraft:ochre_froglight
setblock 193 247 560 minecraft:ochre_froglight
setblock 193 247 562 minecraft:ochre_froglight
setblock 193 247 564 minecraft:ochre_froglight
setblock 194 247 559 minecraft:ochre_froglight
setblock 194 247 561 minecraft:ochre_froglight
setblock 194 247 563 minecraft:ochre_froglight
setblock 194 247 565 minecraft:ochre_froglight
setblock 195 247 560 minecraft:ochre_froglight
setblock 195 247 562 minecraft:ochre_froglight
setblock 195 247 564 minecraft:ochre_froglight
setblock 196 247 559 minecraft:ochre_froglight
setblock 196 247 561 minecraft:ochre_froglight
setblock 196 247 563 minecraft:ochre_froglight
setblock 196 247 565 minecraft:ochre_froglight
setblock 197 247 560 minecraft:ochre_froglight
setblock 197 247 562 minecraft:ochre_froglight
setblock 197 247 564 minecraft:ochre_froglight
setblock 198 247 559 minecraft:ochre_froglight
setblock 198 247 561 minecraft:ochre_froglight
setblock 198 247 563 minecraft:ochre_froglight
setblock 198 247 565 minecraft:ochre_froglight
setblock 205 247 590 minecraft:ochre_froglight
setblock 205 247 592 minecraft:ochre_froglight
setblock 205 247 594 minecraft:ochre_froglight
setblock 205 247 596 minecraft:ochre_froglight
setblock 205 247 598 minecraft:ochre_froglight
setblock 206 247 591 minecraft:ochre_froglight
setblock 206 247 593 minecraft:ochre_froglight
setblock 206 247 595 minecraft:ochre_froglight
setblock 206 247 597 minecraft:ochre_froglight
setblock 207 247 590 minecraft:ochre_froglight
setblock 207 247 592 minecraft:ochre_froglight
setblock 207 247 594 minecraft:ochre_froglight
setblock 207 247 596 minecraft:ochre_froglight
setblock 207 247 598 minecraft:ochre_froglight
setblock 208 247 591 minecraft:ochre_froglight
setblock 208 247 593 minecraft:ochre_froglight
setblock 208 247 595 minecraft:ochre_froglight
setblock 208 247 597 minecraft:ochre_froglight
fill 209 247 569 210 248 570 minecraft:raw_gold_block
setblock 209 247 590 minecraft:ochre_froglight
setblock 209 247 592 minecraft:ochre_froglight
setblock 209 247 594 minecraft:ochre_froglight
setblock 209 247 596 minecraft:ochre_froglight
setblock 209 247 598 minecraft:ochre_froglight
fill 210 247 571 210 248 571 minecraft:raw_gold_block
setblock 210 247 591 minecraft:ochre_froglight
setblock 210 247 593 minecraft:ochre_froglight
setblock 210 247 595 minecraft:ochre_froglight
setblock 210 247 597 minecraft:ochre_froglight
setblock 211 247 590 minecraft:ochre_froglight
setblock 211 247 592 minecraft:ochre_froglight
setblock 211 247 594 minecraft:ochre_froglight
setblock 211 247 596 minecraft:ochre_froglight
setblock 211 247 598 minecraft:ochre_froglight
fill 220 247 594 222 247 596 minecraft:gold_block
fill 222 247 562 222 247 564 minecraft:yellow_terracotta
setblock 223 247 561 minecraft:yellow_terracotta
fill 223 247 565 225 247 565 minecraft:yellow_terracotta
fill 225 247 561 226 247 561 minecraft:yellow_terracotta
fill 226 247 562 226 247 564 minecraft:yellow_terracotta
fill 189 248 560 189 249 560 minecraft:quartz_block
fill 189 248 562 189 249 562 minecraft:quartz_block
fill 189 248 564 189 249 564 minecraft:quartz_block
fill 190 248 559 190 249 559 minecraft:quartz_block
fill 190 248 561 190 249 561 minecraft:quartz_block
fill 190 248 563 190 249 563 minecraft:quartz_block
fill 190 248 565 190 249 565 minecraft:quartz_block
fill 190 248 590 197 248 594 minecraft:gold_block
fill 191 248 560 191 249 560 minecraft:quartz_block
fill 191 248 562 191 249 562 minecraft:quartz_block
fill 191 248 564 191 249 564 minecraft:quartz_block
fill 192 248 559 192 249 559 minecraft:quartz_block
fill 192 248 561 192 249 561 minecraft:quartz_block
fill 192 248 563 192 249 563 minecraft:quartz_block
fill 192 248 565 192 249 565 minecraft:quartz_block
fill 193 248 560 193 249 560 minecraft:quartz_block
fill 193 248 562 193 249 562 minecraft:quartz_block
fill 193 248 564 193 249 564 minecraft:quartz_block
fill 194 248 559 194 249 559 minecraft:quartz_block
fill 194 248 561 194 249 561 minecraft:quartz_block
fill 194 248 563 194 249 563 minecraft:quartz_block
fill 194 248 565 194 249 565 minecraft:quartz_block
fill 195 248 560 195 249 560 minecraft:quartz_block
fill 195 248 562 195 249 562 minecraft:quartz_block
fill 195 248 564 195 249 564 minecraft:quartz_block
fill 196 248 559 196 249 559 minecraft:quartz_block
fill 196 248 561 196 249 561 minecraft:quartz_block
fill 196 248 563 196 249 563 minecraft:quartz_block
fill 196 248 565 196 249 565 minecraft:quartz_block
fill 197 248 560 197 249 560 minecraft:quartz_block
fill 197 248 562 197 249 562 minecraft:quartz_block
fill 197 248 564 197 249 564 minecraft:quartz_block
fill 198 248 559 198 249 559 minecraft:quartz_block
fill 198 248 561 198 249 561 minecraft:quartz_block
fill 198 248 563 198 249 563 minecraft:quartz_block
fill 198 248 565 198 249 565 minecraft:quartz_block
fill 205 248 590 205 249 590 minecraft:quartz_block
fill 205 248 592 205 249 592 minecraft:quartz_block
fill 205 248 594 205 249 594 minecraft:quartz_block
fill 205 248 596 205 249 596 minecraft:quartz_block
fill 205 248 598 205 249 598 minecraft:quartz_block
fill 206 248 591 206 249 591 minecraft:quartz_block
fill 206 248 593 206 249 593 minecraft:quartz_block
fill 206 248 595 206 249 595 minecraft:quartz_block
fill 206 248 597 206 249 597 minecraft:quartz_block
fill 207 248 590 207 249 590 minecraft:quartz_block
fill 207 248 592 207 249 592 minecraft:quartz_block
fill 207 248 594 207 249 594 minecraft:quartz_block
fill 207 248 596 207 249 596 minecraft:quartz_block
fill 207 248 598 207 249 598 minecraft:quartz_block
fill 208 248 591 208 249 591 minecraft:quartz_block
fill 208 248 593 208 249 593 minecraft:quartz_block
fill 208 248 595 208 249 595 minecraft:quartz_block
fill 208 248 597 208 249 597 minecraft:quartz_block
fill 209 248 590 209 249 590 minecraft:quartz_block
fill 209 248 592 209 249 592 minecraft:quartz_block
fill 209 248 594 209 249 594 minecraft:quartz_block
fill 209 248 596 209 249 596 minecraft:quartz_block
fill 209 248 598 209 249 598 minecraft:quartz_block
fill 210 248 591 210 249 591 minecraft:quartz_block
fill 210 248 593 210 249 593 minecraft:quartz_block
fill 210 248 595 210 249 595 minecraft:quartz_block
fill 210 248 597 210 249 597 minecraft:quartz_block
fill 211 248 590 211 249 590 minecraft:quartz_block
fill 211 248 592 211 249 592 minecraft:quartz_block
fill 211 248 594 211 249 594 minecraft:quartz_block
fill 211 248 596 211 249 596 minecraft:quartz_block
fill 211 248 598 211 249 598 minecraft:quartz_block
fill 191 249 591 196 249 593 minecraft:gold_block
setblock 189 250 560 minecraft:ochre_froglight
setblock 189 250 562 minecraft:ochre_froglight
setblock 189 250 564 minecraft:ochre_froglight
setblock 190 250 559 minecraft:ochre_froglight
setblock 190 250 561 minecraft:ochre_froglight
setblock 190 250 563 minecraft:ochre_froglight
setblock 190 250 565 minecraft:ochre_froglight
fill 190 250 587 190 262 587 minecraft:red_wool
setblock 191 250 560 minecraft:ochre_froglight
setblock 191 250 562 minecraft:ochre_froglight
setblock 191 250 564 minecraft:ochre_froglight
setblock 192 250 559 minecraft:ochre_froglight
setblock 192 250 561 minecraft:ochre_froglight
setblock 192 250 563 minecraft:ochre_froglight
setblock 192 250 565 minecraft:ochre_froglight
fill 192 250 592 195 250 592 minecraft:gold_block
setblock 193 250 560 minecraft:ochre_froglight
setblock 193 250 562 minecraft:ochre_froglight
setblock 193 250 564 minecraft:ochre_froglight
setblock 194 250 559 minecraft:ochre_froglight
setblock 194 250 561 minecraft:ochre_froglight
setblock 194 250 563 minecraft:ochre_froglight
setblock 194 250 565 minecraft:ochre_froglight
setblock 195 250 560 minecraft:ochre_froglight
setblock 195 250 562 minecraft:ochre_froglight
setblock 195 250 564 minecraft:ochre_froglight
setblock 196 250 559 minecraft:ochre_froglight
setblock 196 250 561 minecraft:ochre_froglight
setblock 196 250 563 minecraft:ochre_froglight
setblock 196 250 565 minecraft:ochre_froglight
setblock 197 250 560 minecraft:ochre_froglight
setblock 197 250 562 minecraft:ochre_froglight
setblock 197 250 564 minecraft:ochre_froglight
setblock 198 250 559 minecraft:ochre_froglight
setblock 198 250 561 minecraft:ochre_froglight
setblock 198 250 563 minecraft:ochre_froglight
setblock 198 250 565 minecraft:ochre_froglight
setblock 205 250 590 minecraft:ochre_froglight
setblock 205 250 592 minecraft:ochre_froglight
setblock 205 250 594 minecraft:ochre_froglight
setblock 205 250 596 minecraft:ochre_froglight
setblock 205 250 598 minecraft:ochre_froglight
setblock 206 250 591 minecraft:ochre_froglight
setblock 206 250 593 minecraft:ochre_froglight
setblock 206 250 595 minecraft:ochre_froglight
setblock 206 250 597 minecraft:ochre_froglight
setblock 207 250 590 minecraft:ochre_froglight
setblock 207 250 592 minecraft:ochre_froglight
setblock 207 250 594 minecraft:ochre_froglight
setblock 207 250 596 minecraft:ochre_froglight
setblock 207 250 598 minecraft:ochre_froglight
setblock 208 250 591 minecraft:ochre_froglight
setblock 208 250 593 minecraft:ochre_froglight
setblock 208 250 595 minecraft:ochre_froglight
setblock 208 250 597 minecraft:ochre_froglight
setblock 209 250 590 minecraft:ochre_froglight
setblock 209 250 592 minecraft:ochre_froglight
setblock 209 250 594 minecraft:ochre_froglight
setblock 209 250 596 minecraft:ochre_froglight
setblock 209 250 598 minecraft:ochre_froglight
setblock 210 250 591 minecraft:ochre_froglight
setblock 210 250 593 minecraft:ochre_froglight
setblock 210 250 595 minecraft:ochre_froglight
setblock 210 250 597 minecraft:ochre_froglight
setblock 211 250 590 minecraft:ochre_froglight
setblock 211 250 592 minecraft:ochre_froglight
setblock 211 250 594 minecraft:ochre_froglight
setblock 211 250 596 minecraft:ochre_froglight
setblock 211 250 598 minecraft:ochre_froglight
fill 189 251 560 189 252 560 minecraft:quartz_block
fill 189 251 562 189 252 562 minecraft:quartz_block
fill 189 251 564 189 252 564 minecraft:quartz_block
fill 190 251 559 190 252 559 minecraft:quartz_block
fill 190 251 561 190 252 561 minecraft:quartz_block
fill 190 251 563 190 252 563 minecraft:quartz_block
fill 190 251 565 190 252 565 minecraft:quartz_block
fill 190 251 585 190 262 586 minecraft:red_wool
fill 190 251 588 190 262 589 minecraft:red_wool
fill 191 251 560 191 252 560 minecraft:quartz_block
fill 191 251 562 191 252 562 minecraft:quartz_block
fill 191 251 564 191 252 564 minecraft:quartz_block
setblock 191 251 568 minecraft:light[level=14]
setblock 191 251 576 minecraft:light[level=14]
setblock 191 251 584 minecraft:light[level=14]
setblock 191 251 592 minecraft:light[level=14]
fill 192 251 559 192 252 559 minecraft:quartz_block
fill 192 251 561 192 252 561 minecraft:quartz_block
fill 192 251 563 192 252 563 minecraft:quartz_block
fill 192 251 565 192 252 565 minecraft:quartz_block
fill 193 251 560 193 252 560 minecraft:quartz_block
fill 193 251 562 193 252 562 minecraft:quartz_block
fill 193 251 564 193 252 564 minecraft:quartz_block
fill 193 251 591 194 251 593 minecraft:gold_block
fill 194 251 559 194 252 559 minecraft:quartz_block
fill 194 251 561 194 252 561 minecraft:quartz_block
fill 194 251 563 194 252 563 minecraft:quartz_block
fill 194 251 565 194 252 565 minecraft:quartz_block
fill 195 251 560 195 252 560 minecraft:quartz_block
fill 195 251 562 195 252 562 minecraft:quartz_block
fill 195 251 564 195 252 564 minecraft:quartz_block
fill 196 251 559 196 252 559 minecraft:quartz_block
fill 196 251 561 196 252 561 minecraft:quartz_block
fill 196 251 563 196 252 563 minecraft:quartz_block
fill 196 251 565 196 252 565 minecraft:quartz_block
fill 197 251 560 197 252 560 minecraft:quartz_block
fill 197 251 562 197 252 562 minecraft:quartz_block
fill 197 251 564 197 252 564 minecraft:quartz_block
fill 198 251 559 198 252 559 minecraft:quartz_block
fill 198 251 561 198 252 561 minecraft:quartz_block
fill 198 251 563 198 252 563 minecraft:quartz_block
fill 198 251 565 198 252 565 minecraft:quartz_block
setblock 199 251 560 minecraft:light[level=14]
setblock 199 251 568 minecraft:light[level=14]
setblock 199 251 576 minecraft:light[level=14]
setblock 199 251 584 minecraft:light[level=14]
setblock 199 251 592 minecraft:light[level=14]
fill 205 251 590 205 252 590 minecraft:quartz_block
fill 205 251 592 205 252 592 minecraft:quartz_block
fill 205 251 594 205 252 594 minecraft:quartz_block
fill 205 251 596 205 252 596 minecraft:quartz_block
fill 205 251 598 205 252 598 minecraft:quartz_block
fill 206 251 591 206 252 591 minecraft:quartz_block
fill 206 251 593 206 252 593 minecraft:quartz_block
fill 206 251 595 206 252 595 minecraft:quartz_block
fill 206 251 597 206 252 597 minecraft:quartz_block
setblock 207 251 560 minecraft:light[level=14]
setblock 207 251 568 minecraft:light[level=14]
setblock 207 251 576 minecraft:light[level=14]
setblock 207 251 584 minecraft:light[level=14]
fill 207 251 590 207 252 590 minecraft:quartz_block
fill 207 251 592 207 252 592 minecraft:quartz_block
fill 207 251 594 207 252 594 minecraft:quartz_block
fill 207 251 596 207 252 596 minecraft:quartz_block
fill 207 251 598 207 273 598 minecraft:quartz_block
fill 208 251 591 208 252 591 minecraft:quartz_block
fill 208 251 593 208 252 593 minecraft:quartz_block
fill 208 251 595 208 252 595 minecraft:quartz_block
fill 208 251 597 208 252 597 minecraft:quartz_block
fill 209 251 590 209 252 590 minecraft:quartz_block
fill 209 251 592 209 252 592 minecraft:quartz_block
fill 209 251 594 209 252 594 minecraft:quartz_block
fill 209 251 596 209 252 596 minecraft:quartz_block
fill 209 251 598 209 273 598 minecraft:quartz_block
fill 210 251 591 210 252 591 minecraft:quartz_block
fill 210 251 593 210 252 593 minecraft:quartz_block
fill 210 251 595 210 252 595 minecraft:quartz_block
fill 210 251 597 210 252 597 minecraft:quartz_block
fill 211 251 590 211 252 590 minecraft:quartz_block
fill 211 251 592 211 252 592 minecraft:quartz_block
fill 211 251 594 211 252 594 minecraft:quartz_block
fill 211 251 596 211 252 596 minecraft:quartz_block
fill 211 251 598 211 252 598 minecraft:quartz_block
fill 212 251 596 212 252 597 minecraft:raw_gold_block
setblock 215 251 560 minecraft:light[level=14]
setblock 215 251 568 minecraft:light[level=14]
setblock 215 251 576 minecraft:light[level=14]
setblock 215 251 584 minecraft:light[level=14]
setblock 215 251 592 minecraft:light[level=14]
setblock 223 251 560 minecraft:light[level=14]
setblock 223 251 568 minecraft:light[level=14]
setblock 223 251 576 minecraft:light[level=14]
setblock 223 251 584 minecraft:light[level=14]
setblock 223 251 592 minecraft:light[level=14]
fill 188 252 563 188 265 563 minecraft:gold_block
fill 188 252 564 188 252 565 minecraft:ochre_froglight
fill 188 252 566 188 265 566 minecraft:gold_block
fill 188 252 575 188 265 575 minecraft:gold_block
fill 188 252 576 188 252 577 minecraft:ochre_froglight
fill 188 252 578 188 265 578 minecraft:gold_block
fill 188 252 587 188 265 587 minecraft:gold_block
fill 188 252 588 188 252 589 minecraft:ochre_froglight
fill 188 252 590 188 265 590 minecraft:gold_block
fill 188 252 599 188 265 599 minecraft:gold_block
fill 189 252 599 190 252 599 minecraft:ochre_froglight
fill 191 252 599 191 265 599 minecraft:gold_block
fill 195 252 557 195 265 557 minecraft:gold_block
fill 196 252 557 197 252 557 minecraft:ochre_froglight
fill 198 252 557 198 265 557 minecraft:gold_block
fill 200 252 599 200 265 599 minecraft:gold_block
fill 201 252 599 202 252 599 minecraft:ochre_froglight
fill 203 252 599 203 265 599 minecraft:gold_block
fill 207 252 557 207 265 557 minecraft:gold_block
fill 208 252 557 209 252 557 minecraft:ochre_froglight
fill 210 252 557 210 265 557 minecraft:gold_block
fill 212 252 599 212 265 599 minecraft:gold_block
fill 213 252 599 214 252 599 minecraft:ochre_froglight
fill 215 252 599 215 265 599 minecraft:gold_block
fill 219 252 557 219 265 557 minecraft:gold_block
fill 220 252 557 221 252 557 minecraft:ochre_froglight
fill 222 252 557 222 265 557 minecraft:gold_block
fill 224 252 599 224 265 599 minecraft:gold_block
fill 225 252 599 226 252 599 minecraft:ochre_froglight
fill 227 252 599 227 265 599 minecraft:gold_block
fill 230 252 558 230 265 558 minecraft:gold_block
fill 230 252 559 230 252 560 minecraft:ochre_froglight
fill 230 252 561 230 265 561 minecraft:gold_block
fill 230 252 570 230 265 570 minecraft:gold_block
fill 230 252 571 230 252 572 minecraft:ochre_froglight
fill 230 252 573 230 265 573 minecraft:gold_block
fill 230 252 582 230 265 582 minecraft:gold_block
fill 230 252 583 230 252 584 minecraft:ochre_froglight
fill 230 252 585 230 265 585 minecraft:gold_block
fill 230 252 594 230 265 594 minecraft:gold_block
fill 230 252 595 230 252 596 minecraft:ochre_froglight
fill 230 252 597 230 265 597 minecraft:gold_block
fill 188 253 564 188 265 565 minecraft:gold_block
fill 188 253 576 188 265 577 minecraft:gold_block
fill 188 253 588 188 265 589 minecraft:gold_block
setblock 189 253 560 minecraft:ochre_froglight
setblock 189 253 562 minecraft:ochre_froglight
setblock 189 253 564 minecraft:ochre_froglight
fill 189 253 599 190 265 599 minecraft:gold_block
setblock 190 253 559 minecraft:ochre_froglight
setblock 190 253 561 minecraft:ochre_froglight
setblock 190 253 563 minecraft:ochre_froglight
setblock 190 253 565 minecraft:ochre_froglight
setblock 191 253 560 minecraft:ochre_froglight
setblock 191 253 562 minecraft:ochre_froglight
setblock 191 253 564 minecraft:ochre_froglight
setblock 192 253 559 minecraft:ochre_froglight
setblock 192 253 561 minecraft:ochre_froglight
setblock 192 253 563 minecraft:ochre_froglight
setblock 192 253 565 minecraft:ochre_froglight
setblock 193 253 560 minecraft:ochre_froglight
setblock 193 253 562 minecraft:ochre_froglight
setblock 193 253 564 minecraft:ochre_froglight
setblock 194 253 559 minecraft:ochre_froglight
setblock 194 253 561 minecraft:ochre_froglight
setblock 194 253 563 minecraft:ochre_froglight
setblock 194 253 565 minecraft:ochre_froglight
setblock 195 253 560 minecraft:ochre_froglight
setblock 195 253 562 minecraft:ochre_froglight
setblock 195 253 564 minecraft:ochre_froglight
fill 196 253 557 197 265 557 minecraft:gold_block
setblock 196 253 559 minecraft:ochre_froglight
setblock 196 253 561 minecraft:ochre_froglight
setblock 196 253 563 minecraft:ochre_froglight
setblock 196 253 565 minecraft:ochre_froglight
setblock 197 253 560 minecraft:ochre_froglight
setblock 197 253 562 minecraft:ochre_froglight
setblock 197 253 564 minecraft:ochre_froglight
setblock 198 253 559 minecraft:ochre_froglight
setblock 198 253 561 minecraft:ochre_froglight
setblock 198 253 563 minecraft:ochre_froglight
setblock 198 253 565 minecraft:ochre_froglight
fill 201 253 599 202 265 599 minecraft:gold_block
fill 206 253 591 210 253 597 minecraft:gold_block
fill 208 253 557 209 265 557 minecraft:gold_block
fill 213 253 599 214 265 599 minecraft:gold_block
fill 220 253 557 221 265 557 minecraft:gold_block
fill 225 253 599 226 265 599 minecraft:gold_block
fill 230 253 559 230 265 560 minecraft:gold_block
fill 230 253 571 230 265 572 minecraft:gold_block
fill 230 253 583 230 265 584 minecraft:gold_block
fill 230 253 595 230 265 596 minecraft:gold_block
fill 189 254 560 189 255 560 minecraft:quartz_block
fill 189 254 562 189 255 562 minecraft:quartz_block
fill 189 254 564 189 255 564 minecraft:quartz_block
fill 190 254 559 190 255 559 minecraft:quartz_block
fill 190 254 561 190 255 561 minecraft:quartz_block
fill 190 254 563 190 255 563 minecraft:quartz_block
fill 190 254 565 190 255 565 minecraft:quartz_block
fill 191 254 560 191 255 560 minecraft:quartz_block
fill 191 254 562 191 255 562 minecraft:quartz_block
fill 191 254 564 191 255 564 minecraft:quartz_block
fill 192 254 559 192 255 559 minecraft:quartz_block
fill 192 254 561 192 255 561 minecraft:quartz_block
fill 192 254 563 192 255 563 minecraft:quartz_block
fill 192 254 565 192 255 565 minecraft:quartz_block
fill 193 254 560 193 255 560 minecraft:quartz_block
fill 193 254 562 193 255 562 minecraft:quartz_block
fill 193 254 564 193 255 564 minecraft:quartz_block
fill 194 254 559 194 255 559 minecraft:quartz_block
fill 194 254 561 194 255 561 minecraft:quartz_block
fill 194 254 563 194 255 563 minecraft:quartz_block
fill 194 254 565 194 255 565 minecraft:quartz_block
fill 195 254 560 195 255 560 minecraft:quartz_block
fill 195 254 562 195 255 562 minecraft:quartz_block
fill 195 254 564 195 255 564 minecraft:quartz_block
fill 196 254 559 196 255 559 minecraft:quartz_block
fill 196 254 561 196 255 561 minecraft:quartz_block
fill 196 254 563 196 255 563 minecraft:quartz_block
fill 196 254 565 196 255 565 minecraft:quartz_block
fill 197 254 560 197 255 560 minecraft:quartz_block
fill 197 254 562 197 255 562 minecraft:quartz_block
fill 197 254 564 197 255 564 minecraft:quartz_block
fill 198 254 559 198 255 559 minecraft:quartz_block
fill 198 254 561 198 255 561 minecraft:quartz_block
fill 198 254 563 198 255 563 minecraft:quartz_block
fill 198 254 565 198 255 565 minecraft:quartz_block
fill 207 254 592 209 254 596 minecraft:gold_block
fill 208 255 593 208 255 595 minecraft:gold_block
fill 222 255 562 222 255 564 minecraft:yellow_terracotta
setblock 223 255 561 minecraft:yellow_terracotta
fill 223 255 565 225 255 565 minecraft:yellow_terracotta
fill 225 255 561 226 255 561 minecraft:yellow_terracotta
fill 226 255 562 226 255 564 minecraft:yellow_terracotta
setblock 189 256 560 minecraft:ochre_froglight
setblock 189 256 562 minecraft:ochre_froglight
setblock 189 256 564 minecraft:ochre_froglight
setblock 190 256 559 minecraft:ochre_froglight
setblock 190 256 561 minecraft:ochre_froglight
setblock 190 256 563 minecraft:ochre_froglight
setblock 190 256 565 minecraft:ochre_froglight
setblock 191 256 560 minecraft:ochre_froglight
setblock 191 256 562 minecraft:ochre_froglight
setblock 191 256 564 minecraft:ochre_froglight
setblock 192 256 559 minecraft:ochre_froglight
setblock 192 256 561 minecraft:ochre_froglight
setblock 192 256 563 minecraft:ochre_froglight
setblock 192 256 565 minecraft:ochre_froglight
setblock 193 256 560 minecraft:ochre_froglight
setblock 193 256 562 minecraft:ochre_froglight
setblock 193 256 564 minecraft:ochre_froglight
setblock 194 256 559 minecraft:ochre_froglight
setblock 194 256 561 minecraft:ochre_froglight
setblock 194 256 563 minecraft:ochre_froglight
setblock 194 256 565 minecraft:ochre_froglight
setblock 195 256 560 minecraft:ochre_froglight
setblock 195 256 562 minecraft:ochre_froglight
setblock 195 256 564 minecraft:ochre_froglight
setblock 196 256 559 minecraft:ochre_froglight
setblock 196 256 561 minecraft:ochre_froglight
setblock 196 256 563 minecraft:ochre_froglight
setblock 196 256 565 minecraft:ochre_froglight
setblock 197 256 560 minecraft:ochre_froglight
setblock 197 256 562 minecraft:ochre_froglight
setblock 197 256 564 minecraft:ochre_froglight
setblock 198 256 559 minecraft:ochre_froglight
setblock 198 256 561 minecraft:ochre_froglight
setblock 198 256 563 minecraft:ochre_froglight
setblock 198 256 565 minecraft:ochre_froglight
fill 207 256 594 209 256 594 minecraft:gold_block
setblock 189 257 560 minecraft:quartz_block
setblock 189 257 562 minecraft:quartz_block
setblock 189 257 564 minecraft:quartz_block
setblock 190 257 559 minecraft:quartz_block
setblock 190 257 561 minecraft:quartz_block
setblock 190 257 563 minecraft:quartz_block
setblock 190 257 565 minecraft:quartz_block
setblock 191 257 560 minecraft:quartz_block
setblock 191 257 562 minecraft:quartz_block
setblock 191 257 564 minecraft:quartz_block
setblock 192 257 559 minecraft:quartz_block
setblock 192 257 561 minecraft:quartz_block
setblock 192 257 563 minecraft:quartz_block
setblock 192 257 565 minecraft:quartz_block
setblock 193 257 560 minecraft:quartz_block
setblock 193 257 562 minecraft:quartz_block
setblock 193 257 564 minecraft:quartz_block
setblock 194 257 559 minecraft:quartz_block
setblock 194 257 561 minecraft:quartz_block
setblock 194 257 563 minecraft:quartz_block
setblock 194 257 565 minecraft:quartz_block
setblock 195 257 560 minecraft:quartz_block
setblock 195 257 562 minecraft:quartz_block
setblock 195 257 564 minecraft:quartz_block
setblock 196 257 559 minecraft:quartz_block
setblock 196 257 561 minecraft:quartz_block
setblock 196 257 563 minecraft:quartz_block
setblock 196 257 565 minecraft:quartz_block
setblock 197 257 560 minecraft:quartz_block
setblock 197 257 562 minecraft:quartz_block
setblock 197 257 564 minecraft:quartz_block
setblock 198 257 559 minecraft:quartz_block
setblock 198 257 561 minecraft:quartz_block
setblock 198 257 563 minecraft:quartz_block
setblock 198 257 565 minecraft:quartz_block
fill 189 258 558 189 273 558 minecraft:quartz_block
fill 190 258 560 197 258 564 minecraft:gold_block
fill 190 258 565 190 261 565 minecraft:red_wool
fill 190 259 561 190 261 564 minecraft:red_wool
setblock 191 259 560 minecraft:light[level=14]
fill 191 259 561 196 259 563 minecraft:gold_block
setblock 191 259 568 minecraft:light[level=14]
setblock 191 259 576 minecraft:light[level=14]
setblock 191 259 584 minecraft:light[level=14]
setblock 191 259 592 minecraft:light[level=14]
setblock 199 259 560 minecraft:light[level=14]
setblock 199 259 568 minecraft:light[level=14]
setblock 199 259 576 minecraft:light[level=14]
setblock 199 259 584 minecraft:light[level=14]
setblock 199 259 592 minecraft:light[level=14]
setblock 207 259 560 minecraft:light[level=14]
setblock 207 259 568 minecraft:light[level=14]
setblock 207 259 576 minecraft:light[level=14]
setblock 207 259 584 minecraft:light[level=14]
setblock 207 259 592 minecraft:light[level=14]
setblock 215 259 560 minecraft:light[level=14]
setblock 215 259 568 minecraft:light[level=14]
setblock 215 259 576 minecraft:light[level=14]
setblock 215 259 584 minecraft:light[level=14]
setblock 215 259 592 minecraft:light[level=14]
setblock 223 259 560 minecraft:light[level=14]
setblock 223 259 568 minecraft:light[level=14]
setblock 223 259 576 minecraft:light[level=14]
setblock 223 259 584 minecraft:light[level=14]
setblock 223 259 592 minecraft:light[level=14]
fill 190 260 567 190 265 569 minecraft:quartz_block
fill 190 260 579 190 265 581 minecraft:quartz_block
fill 190 260 591 190 265 593 minecraft:quartz_block
fill 192 260 562 195 260 562 minecraft:gold_block
fill 196 260 597 198 265 597 minecraft:quartz_block
fill 200 260 559 202 265 559 minecraft:quartz_block
fill 208 260 597 210 265 597 minecraft:quartz_block
fill 212 260 559 214 265 559 minecraft:quartz_block
fill 220 260 597 222 265 597 minecraft:quartz_block
fill 224 260 559 226 265 559 minecraft:quartz_block
fill 228 260 567 228 265 569 minecraft:quartz_block
fill 228 260 579 228 265 581 minecraft:quartz_block
fill 228 260 591 228 265 593 minecraft:quartz_block
fill 193 261 561 194 261 563 minecraft:gold_block
fill 214 261 597 216 262 598 minecraft:quartz_block
fill 216 261 558 216 262 558 minecraft:quartz_block
fill 190 262 560 190 263 566 minecraft:gold_block
fill 206 262 567 206 263 567 minecraft:raw_gold_block
fill 214 262 596 216 263 596 minecraft:quartz_block
fill 215 262 559 215 264 560 minecraft:quartz_block
fill 215 262 595 215 264 595 minecraft:quartz_block
fill 216 262 559 216 263 559 minecraft:quartz_block
fill 222 262 573 223 263 574 minecraft:gold_block
fill 190 263 584 190 264 590 minecraft:gold_block
fill 214 263 560 214 264 560 minecraft:quartz_block
fill 214 263 595 214 264 595 minecraft:quartz_block
fill 215 263 561 215 265 561 minecraft:quartz_block
fill 215 263 594 215 265 594 minecraft:quartz_block
setblock 215 263 597 minecraft:quartz_block
setblock 215 263 598 minecraft:gold_block
fill 216 263 560 216 264 560 minecraft:quartz_block
fill 216 263 595 216 264 595 minecraft:quartz_block
fill 222 263 562 222 263 564 minecraft:yellow_terracotta
setblock 223 263 561 minecraft:yellow_terracotta
fill 223 263 565 225 263 565 minecraft:yellow_terracotta
fill 225 263 561 226 263 561 minecraft:yellow_terracotta
fill 226 263 562 226 263 564 minecraft:yellow_terracotta
fill 214 264 561 214 265 562 minecraft:quartz_block
fill 214 264 593 214 265 594 minecraft:quartz_block
fill 215 264 562 216 265 562 minecraft:quartz_block
fill 215 264 593 216 265 593 minecraft:quartz_block
setblock 215 264 596 minecraft:quartz_block
setblock 215 264 597 minecraft:gold_block
fill 216 264 561 216 265 561 minecraft:quartz_block
fill 216 264 594 216 265 594 minecraft:quartz_block
fill 189 265 561 189 265 566 minecraft:yellow_terracotta
fill 189 265 573 189 265 578 minecraft:yellow_terracotta
fill 189 265 585 189 265 590 minecraft:yellow_terracotta
fill 189 265 597 189 265 598 minecraft:yellow_terracotta
fill 190 265 598 193 265 598 minecraft:yellow_terracotta
fill 193 265 558 198 265 558 minecraft:yellow_terracotta
fill 200 265 598 205 265 598 minecraft:yellow_terracotta
fill 205 265 558 210 265 558 minecraft:yellow_terracotta
fill 212 265 598 217 265 598 minecraft:yellow_terracotta
fill 214 265 563 216 266 563 minecraft:quartz_block
fill 214 265 592 216 266 592 minecraft:quartz_block
setblock 215 265 560 minecraft:gold_block
fill 215 265 564 215 267 564 minecraft:quartz_block
fill 215 265 591 215 267 591 minecraft:quartz_block
setblock 215 265 595 minecraft:gold_block
fill 217 265 558 222 265 558 minecraft:yellow_terracotta
fill 224 265 598 229 265 598 minecraft:yellow_terracotta
fill 229 265 558 229 265 563 minecraft:yellow_terracotta
fill 229 265 570 229 265 575 minecraft:yellow_terracotta
fill 229 265 582 229 265 587 minecraft:yellow_terracotta
fill 229 265 594 229 265 597 minecraft:yellow_terracotta
fill 188 266 563 188 271 566 minecraft:ochre_froglight
fill 188 266 575 188 271 578 minecraft:ochre_froglight
fill 188 266 587 188 271 590 minecraft:ochre_froglight
fill 188 266 599 191 271 599 minecraft:ochre_froglight
fill 195 266 557 198 271 557 minecraft:ochre_froglight
fill 200 266 599 203 271 599 minecraft:ochre_froglight
fill 207 266 557 210 271 557 minecraft:ochre_froglight
fill 212 266 599 215 271 599 minecraft:ochre_froglight
fill 214 266 564 214 267 564 minecraft:quartz_block
fill 214 266 591 214 267 591 minecraft:quartz_block
setblock 215 266 561 minecraft:gold_block
setblock 215 266 562 minecraft:quartz_block
fill 215 266 565 215 268 565 minecraft:quartz_block
fill 215 266 590 215 268 590 minecraft:quartz_block
setblock 215 266 593 minecraft:quartz_block
setblock 215 266 594 minecraft:gold_block
fill 216 266 564 216 267 564 minecraft:quartz_block
fill 216 266 591 216 267 591 minecraft:quartz_block
fill 219 266 557 222 271 557 minecraft:ochre_froglight
fill 224 266 599 227 271 599 minecraft:ochre_froglight
fill 230 266 558 230 271 561 minecraft:ochre_froglight
fill 230 266 570 230 271 573 minecraft:ochre_froglight
fill 230 266 582 230 271 585 minecraft:ochre_froglight
fill 230 266 594 230 271 597 minecraft:ochre_froglight
setblock 191 267 560 minecraft:light[level=14]
setblock 191 267 568 minecraft:light[level=14]
setblock 191 267 576 minecraft:light[level=14]
setblock 191 267 584 minecraft:light[level=14]
setblock 191 267 592 minecraft:light[level=14]
setblock 199 267 560 minecraft:light[level=14]
setblock 199 267 568 minecraft:light[level=14]
setblock 199 267 576 minecraft:light[level=14]
setblock 199 267 584 minecraft:light[level=14]
setblock 199 267 592 minecraft:light[level=14]
setblock 207 267 560 minecraft:light[level=14]
setblock 207 267 568 minecraft:light[level=14]
setblock 207 267 576 minecraft:light[level=14]
setblock 207 267 584 minecraft:light[level=14]
setblock 207 267 592 minecraft:light[level=14]
fill 214 267 565 214 267 566 minecraft:quartz_block
fill 214 267 589 214 267 590 minecraft:quartz_block
setblock 215 267 560 minecraft:light[level=14]
setblock 215 267 562 minecraft:gold_block
setblock 215 267 563 minecraft:quartz_block
fill 215 267 566 215 268 567 minecraft:quartz_block
setblock 215 267 568 minecraft:light[level=14]
setblock 215 267 576 minecraft:light[level=14]
setblock 215 267 584 minecraft:light[level=14]
fill 215 267 588 215 268 589 minecraft:quartz_block
setblock 215 267 592 minecraft:quartz_block
setblock 215 267 593 minecraft:gold_block
fill 216 267 565 216 267 566 minecraft:quartz_block
fill 216 267 589 216 267 590 minecraft:quartz_block
setblock 223 267 560 minecraft:light[level=14]
setblock 223 267 568 minecraft:light[level=14]
setblock 223 267 576 minecraft:light[level=14]
setblock 223 267 584 minecraft:light[level=14]
setblock 223 267 592 minecraft:light[level=14]
fill 214 268 566 214 268 568 minecraft:quartz_block
fill 214 268 587 214 268 589 minecraft:quartz_block
setblock 215 268 564 minecraft:gold_block
fill 215 268 568 215 270 569 minecraft:quartz_block
fill 215 268 586 215 270 587 minecraft:quartz_block
setblock 215 268 591 minecraft:gold_block
fill 216 268 566 216 268 568 minecraft:quartz_block
fill 216 268 587 216 268 589 minecraft:quartz_block
fill 196 269 576 196 271 576 minecraft:yellow_stained_glass
fill 196 269 577 196 272 577 minecraft:gold_block
fill 196 269 578 196 273 582 minecraft:yellow_stained_glass
fill 196 269 583 196 272 583 minecraft:gold_block
fill 196 269 584 196 271 584 minecraft:yellow_stained_glass
fill 197 269 574 197 271 575 minecraft:yellow_stained_glass
fill 197 269 585 197 271 586 minecraft:yellow_stained_glass
fill 198 269 572 198 270 573 minecraft:yellow_stained_glass
fill 198 269 587 198 270 588 minecraft:yellow_stained_glass
fill 199 269 571 199 271 571 minecraft:gold_block
fill 199 269 572 199 273 572 minecraft:yellow_stained_glass
fill 199 269 588 199 273 588 minecraft:yellow_stained_glass
fill 199 269 589 199 271 589 minecraft:gold_block
fill 200 269 570 200 270 571 minecraft:yellow_stained_glass
fill 200 269 589 200 270 590 minecraft:yellow_stained_glass
fill 201 269 570 201 272 570 minecraft:yellow_stained_glass
fill 201 269 590 201 272 590 minecraft:yellow_stained_glass
fill 202 269 569 203 271 569 minecraft:yellow_stained_glass
fill 202 269 591 203 271 591 minecraft:yellow_stained_glass
fill 204 269 568 204 271 568 minecraft:yellow_stained_glass
fill 204 269 592 204 271 592 minecraft:yellow_stained_glass
fill 205 269 568 205 272 568 minecraft:gold_block
fill 205 269 592 205 272 592 minecraft:gold_block
fill 206 269 568 210 273 568 minecraft:yellow_stained_glass
fill 206 269 592 210 273 592 minecraft:yellow_stained_glass
fill 211 269 568 211 272 568 minecraft:gold_block
fill 211 269 592 211 272 592 minecraft:gold_block
fill 212 269 568 212 271 568 minecraft:yellow_stained_glass
fill 212 269 592 212 271 592 minecraft:yellow_stained_glass
fill 213 269 569 214 271 569 minecraft:yellow_stained_glass
fill 213 269 591 214 271 591 minecraft:yellow_stained_glass
setblock 214 269 568 minecraft:quartz_block
fill 214 269 570 214 270 570 minecraft:quartz_block
fill 214 269 585 214 269 587 minecraft:quartz_block
fill 215 269 565 215 269 566 minecraft:gold_block
setblock 215 269 567 minecraft:quartz_block
fill 215 269 570 216 270 570 minecraft:yellow_stained_glass
fill 215 269 571 215 271 571 minecraft:quartz_block
fill 215 269 584 215 271 585 minecraft:quartz_block
setblock 215 269 588 minecraft:quartz_block
setblock 215 269 589 minecraft:gold_block
fill 215 269 590 216 270 590 minecraft:yellow_stained_glass
fill 216 269 568 216 269 569 minecraft:quartz_block
fill 216 269 571 216 273 571 minecraft:yellow_stained_glass
fill 216 269 585 216 269 587 minecraft:quartz_block
fill 216 269 589 216 273 589 minecraft:yellow_stained_glass
fill 217 269 571 217 271 571 minecraft:gold_block
fill 217 269 572 218 270 572 minecraft:yellow_stained_glass
fill 217 269 588 218 270 588 minecraft:yellow_stained_glass
fill 217 269 589 217 271 589 minecraft:gold_block
fill 218 269 573 218 272 573 minecraft:yellow_stained_glass
fill 218 269 587 218 272 587 minecraft:yellow_stained_glass
fill 219 269 574 219 271 575 minecraft:yellow_stained_glass
fill 219 269 585 219 271 586 minecraft:yellow_stained_glass
fill 220 269 576 220 271 576 minecraft:yellow_stained_glass
fill 220 269 577 220 272 577 minecraft:gold_block
fill 220 269 578 220 273 582 minecraft:yellow_stained_glass
fill 220 269 583 220 272 583 minecraft:gold_block
fill 220 269 584 220 271 584 minecraft:yellow_stained_glass
fill 214 270 571 214 270 573 minecraft:quartz_block
fill 214 270 582 214 270 586 minecraft:quartz_block
setblock 215 270 567 minecraft:gold_block
fill 215 270 572 215 271 576 minecraft:quartz_block
fill 215 270 579 215 271 583 minecraft:quartz_block
setblock 215 270 588 minecraft:gold_block
setblock 216 270 569 minecraft:quartz_block
fill 216 270 572 216 271 573 minecraft:quartz_block
fill 216 270 582 216 270 586 minecraft:quartz_block
fill 197 271 576 197 274 576 minecraft:yellow_stained_glass
fill 197 271 584 197 274 584 minecraft:yellow_stained_glass
fill 198 271 573 198 272 574 minecraft:yellow_stained_glass
fill 198 271 586 198 272 587 minecraft:yellow_stained_glass
fill 200 271 571 200 273 571 minecraft:yellow_stained_glass
fill 200 271 589 200 273 589 minecraft:yellow_stained_glass
fill 202 271 570 202 274 570 minecraft:yellow_stained_glass
fill 202 271 590 202 274 590 minecraft:yellow_stained_glass
fill 204 271 569 204 274 569 minecraft:yellow_stained_glass
fill 204 271 591 204 274 591 minecraft:yellow_stained_glass
fill 212 271 569 212 274 569 minecraft:yellow_stained_glass
fill 212 271 591 212 274 591 minecraft:yellow_stained_glass
fill 214 271 570 215 272 570 minecraft:yellow_stained_glass
fill 214 271 572 214 271 583 minecraft:quartz_block
fill 214 271 590 215 272 590 minecraft:yellow_stained_glass
setblock 215 271 569 minecraft:gold_block
fill 215 271 577 216 272 578 minecraft:quartz_block
setblock 215 271 586 minecraft:gold_block
fill 216 271 574 216 271 576 minecraft:quartz_block
fill 216 271 579 216 271 583 minecraft:quartz_block
fill 217 271 572 217 273 572 minecraft:yellow_stained_glass
fill 217 271 588 217 273 588 minecraft:yellow_stained_glass
fill 218 271 574 218 274 574 minecraft:yellow_stained_glass
fill 218 271 586 218 274 586 minecraft:yellow_stained_glass
fill 219 271 576 219 274 576 minecraft:yellow_stained_glass
fill 219 271 584 219 274 584 minecraft:yellow_stained_glass
fill 222 271 562 222 271 564 minecraft:yellow_terracotta
setblock 223 271 561 minecraft:yellow_terracotta
fill 223 271 565 225 271 565 minecraft:yellow_terracotta
fill 225 271 561 226 271 561 minecraft:yellow_terracotta
fill 226 271 562 226 271 564 minecraft:yellow_terracotta
fill 188 272 563 188 285 563 minecraft:gold_block
fill 188 272 564 188 272 565 minecraft:ochre_froglight
fill 188 272 566 188 285 566 minecraft:gold_block
fill 188 272 575 188 285 575 minecraft:gold_block
fill 188 272 576 188 272 577 minecraft:ochre_froglight
fill 188 272 578 188 285 578 minecraft:gold_block
fill 188 272 587 188 285 587 minecraft:gold_block
fill 188 272 588 188 272 589 minecraft:ochre_froglight
fill 188 272 590 188 285 590 minecraft:gold_block
fill 188 272 599 188 285 599 minecraft:gold_block
fill 189 272 599 190 272 599 minecraft:ochre_froglight
fill 191 272 599 191 285 599 minecraft:gold_block
fill 195 272 557 195 285 557 minecraft:gold_block
fill 196 272 557 197 272 557 minecraft:ochre_froglight
fill 197 272 575 197 273 575 minecraft:yellow_stained_glass
fill 197 272 577 197 274 577 minecraft:gold_block
fill 197 272 583 197 274 583 minecraft:gold_block
fill 197 272 585 197 273 585 minecraft:yellow_stained_glass
fill 198 272 557 198 285 557 minecraft:gold_block
fill 199 272 573 199 274 573 minecraft:yellow_stained_glass
fill 199 272 587 199 274 587 minecraft:yellow_stained_glass
fill 200 272 599 200 285 599 minecraft:gold_block
fill 201 272 571 201 274 571 minecraft:yellow_stained_glass
fill 201 272 589 201 274 589 minecraft:yellow_stained_glass
fill 201 272 599 202 272 599 minecraft:ochre_froglight
fill 203 272 569 203 273 569 minecraft:yellow_stained_glass
fill 203 272 591 203 273 591 minecraft:yellow_stained_glass
fill 203 272 599 203 285 599 minecraft:gold_block
fill 205 272 569 205 274 569 minecraft:gold_block
fill 205 272 591 205 274 591 minecraft:gold_block
fill 207 272 557 207 285 557 minecraft:gold_block
fill 208 272 557 209 272 557 minecraft:ochre_froglight
fill 210 272 557 210 285 557 minecraft:gold_block
fill 211 272 569 211 274 569 minecraft:gold_block
fill 211 272 591 211 274 591 minecraft:gold_block
fill 212 272 599 212 285 599 minecraft:gold_block
fill 213 272 569 213 273 569 minecraft:yellow_stained_glass
fill 213 272 591 213 273 591 minecraft:yellow_stained_glass
fill 213 272 599 214 272 599 minecraft:ochre_froglight
fill 214 272 577 214 272 578 minecraft:quartz_block
fill 215 272 571 215 274 571 minecraft:yellow_stained_glass
fill 215 272 572 215 272 573 minecraft:gold_block
fill 215 272 574 215 272 576 minecraft:quartz_block
fill 215 272 579 215 272 581 minecraft:quartz_block
fill 215 272 582 215 272 584 minecraft:gold_block
fill 215 272 589 215 274 589 minecraft:yellow_stained_glass
fill 215 272 599 215 285 599 minecraft:gold_block
fill 217 272 573 217 274 573 minecraft:yellow_stained_glass
fill 217 272 587 217 274 587 minecraft:yellow_stained_glass
fill 219 272 557 219 285 557 minecraft:gold_block
fill 219 272 575 219 273 575 minecraft:yellow_stained_glass
fill 219 272 577 219 274 577 minecraft:gold_block
fill 219 272 583 219 274 583 minecraft:gold_block
fill 219 272 585 219 273 585 minecraft:yellow_stained_glass
fill 220 272 557 221 272 557 minecraft:ochre_froglight
fill 222 272 557 222 285 557 minecraft:gold_block
fill 222 272 562 222 273 563 minecraft:gold_block
fill 223 272 561 223 273 561 minecraft:gold_block
fill 224 272 565 224 273 565 minecraft:gold_block
fill 224 272 599 224 285 599 minecraft:gold_block
fill 225 272 561 225 273 561 minecraft:gold_block
fill 225 272 599 226 272 599 minecraft:ochre_froglight
fill 226 272 562 226 273 564 minecraft:gold_block
fill 227 272 599 227 285 599 minecraft:gold_block
fill 230 272 558 230 285 558 minecraft:gold_block
fill 230 272 559 230 272 560 minecraft:ochre_froglight
fill 230 272 561 230 285 561 minecraft:gold_block
fill 230 272 570 230 285 570 minecraft:gold_block
fill 230 272 571 230 272 572 minecraft:ochre_froglight
fill 230 272 573 230 285 573 minecraft:gold_block
fill 230 272 582 230 285 582 minecraft:gold_block
fill 230 272 583 230 272 584 minecraft:ochre_froglight
fill 230 272 585 230 285 585 minecraft:gold_block
fill 230 272 594 230 285 594 minecraft:gold_block
fill 230 272 595 230 272 596 minecraft:ochre_froglight
fill 230 272 597 230 285 597 minecraft:gold_block
fill 188 273 564 188 285 565 minecraft:gold_block
fill 188 273 576 188 285 577 minecraft:gold_block
fill 188 273 588 188 285 589 minecraft:gold_block
fill 189 273 599 190 285 599 minecraft:gold_block
fill 196 273 557 197 285 557 minecraft:gold_block
fill 197 273 578 197 275 579 minecraft:yellow_stained_glass
fill 197 273 581 197 275 582 minecraft:yellow_stained_glass
fill 198 273 574 198 274 575 minecraft:yellow_stained_glass
fill 198 273 585 198 274 586 minecraft:yellow_stained_glass
fill 200 273 572 200 274 572 minecraft:gold_block
fill 200 273 588 200 274 588 minecraft:gold_block
fill 201 273 599 202 285 599 minecraft:gold_block
fill 203 273 570 203 275 570 minecraft:yellow_stained_glass
fill 203 273 590 203 275 590 minecraft:yellow_stained_glass
fill 206 273 569 207 275 569 minecraft:yellow_stained_glass
fill 206 273 591 207 275 591 minecraft:yellow_stained_glass
fill 208 273 557 209 285 557 minecraft:gold_block
fill 209 273 569 210 275 569 minecraft:yellow_stained_glass
fill 209 273 591 210 275 591 minecraft:yellow_stained_glass
fill 213 273 570 214 274 570 minecraft:yellow_stained_glass
fill 213 273 590 214 274 590 minecraft:yellow_stained_glass
fill 213 273 599 214 285 599 minecraft:gold_block
fill 215 273 574 215 273 581 minecraft:gold_block
fill 216 273 572 216 274 572 minecraft:gold_block
fill 216 273 588 216 274 588 minecraft:gold_block
fill 218 273 575 218 275 575 minecraft:yellow_stained_glass
fill 218 273 585 218 275 585 minecraft:yellow_stained_glass
fill 219 273 578 219 275 579 minecraft:yellow_stained_glass
fill 219 273 581 219 275 582 minecraft:yellow_stained_glass
fill 220 273 557 221 285 557 minecraft:gold_block
fill 225 273 599 226 285 599 minecraft:gold_block
fill 230 273 559 230 285 560 minecraft:gold_block
fill 230 273 571 230 285 572 minecraft:gold_block
fill 230 273 583 230 285 584 minecraft:gold_block
fill 230 273 595 230 285 596 minecraft:gold_block
fill 197 274 580 197 275 580 minecraft:yellow_stained_glass
fill 198 274 576 198 275 576 minecraft:yellow_stained_glass
fill 198 274 584 198 275 584 minecraft:yellow_stained_glass
fill 199 274 574 199 275 574 minecraft:yellow_stained_glass
fill 199 274 586 199 275 586 minecraft:yellow_stained_glass
fill 200 274 573 200 275 573 minecraft:yellow_stained_glass
fill 200 274 587 200 275 587 minecraft:yellow_stained_glass
fill 201 274 572 201 275 572 minecraft:yellow_stained_glass
fill 201 274 588 201 275 588 minecraft:yellow_stained_glass
fill 202 274 571 202 275 571 minecraft:yellow_stained_glass
fill 202 274 589 202 275 589 minecraft:yellow_stained_glass
fill 204 274 570 204 275 570 minecraft:yellow_stained_glass
fill 204 274 590 204 275 590 minecraft:yellow_stained_glass
fill 208 274 569 208 275 569 minecraft:yellow_stained_glass
fill 208 274 591 208 275 591 minecraft:yellow_stained_glass
fill 212 274 570 212 275 570 minecraft:yellow_stained_glass
fill 212 274 590 212 275 590 minecraft:yellow_stained_glass
fill 214 274 571 214 275 571 minecraft:yellow_stained_glass
fill 214 274 589 214 275 589 minecraft:yellow_stained_glass
fill 215 274 572 215 275 572 minecraft:yellow_stained_glass
fill 215 274 588 215 275 588 minecraft:yellow_stained_glass
fill 216 274 573 216 275 573 minecraft:yellow_stained_glass
fill 216 274 587 216 275 587 minecraft:yellow_stained_glass
fill 217 274 574 217 275 574 minecraft:yellow_stained_glass
fill 217 274 586 217 275 586 minecraft:yellow_stained_glass
fill 218 274 576 218 275 576 minecraft:yellow_stained_glass
fill 218 274 584 218 275 584 minecraft:yellow_stained_glass
fill 219 274 580 219 275 580 minecraft:yellow_stained_glass
setblock 191 275 560 minecraft:light[level=14]
setblock 191 275 568 minecraft:light[level=14]
setblock 191 275 576 minecraft:light[level=14]
setblock 191 275 584 minecraft:light[level=14]
setblock 191 275 592 minecraft:light[level=14]
fill 198 275 575 199 275 575 minecraft:yellow_stained_glass
fill 198 275 577 198 276 577 minecraft:gold_block
fill 198 275 578 198 276 582 minecraft:yellow_stained_glass
fill 198 275 583 198 276 583 minecraft:gold_block
fill 198 275 585 199 275 585 minecraft:yellow_stained_glass
setblock 199 275 560 minecraft:light[level=14]
setblock 199 275 568 minecraft:light[level=14]
setblock 199 275 576 minecraft:light[level=14]
setblock 199 275 584 minecraft:light[level=14]
setblock 199 275 592 minecraft:light[level=14]
fill 200 275 574 200 276 574 minecraft:yellow_stained_glass
fill 200 275 586 200 276 586 minecraft:yellow_stained_glass
fill 202 275 572 202 276 572 minecraft:yellow_stained_glass
fill 202 275 588 202 276 588 minecraft:yellow_stained_glass
fill 203 275 571 203 276 571 minecraft:yellow_stained_glass
fill 203 275 589 203 276 589 minecraft:yellow_stained_glass
fill 205 275 570 205 276 570 minecraft:gold_block
fill 205 275 590 205 276 590 minecraft:gold_block
fill 206 275 570 210 276 570 minecraft:yellow_stained_glass
fill 206 275 590 210 276 590 minecraft:yellow_stained_glass
setblock 207 275 560 minecraft:light[level=14]
setblock 207 275 568 minecraft:light[level=14]
setblock 207 275 576 minecraft:light[level=14]
setblock 207 275 584 minecraft:light[level=14]
setblock 207 275 592 minecraft:light[level=14]
fill 211 275 570 211 276 570 minecraft:gold_block
fill 211 275 590 211 276 590 minecraft:gold_block
fill 213 275 570 213 275 571 minecraft:yellow_stained_glass
fill 213 275 589 213 275 590 minecraft:yellow_stained_glass
fill 214 275 572 214 276 572 minecraft:yellow_stained_glass
fill 214 275 588 214 276 588 minecraft:yellow_stained_glass
setblock 215 275 560 minecraft:light[level=14]
setblock 215 275 568 minecraft:light[level=14]
setblock 215 275 576 minecraft:light[level=14]
setblock 215 275 584 minecraft:light[level=14]
setblock 215 275 592 minecraft:light[level=14]
fill 216 275 574 216 276 574 minecraft:yellow_stained_glass
fill 216 275 586 216 276 586 minecraft:yellow_stained_glass
fill 217 275 575 217 276 575 minecraft:yellow_stained_glass
fill 217 275 585 217 276 585 minecraft:yellow_stained_glass
fill 218 275 577 218 276 577 minecraft:gold_block
fill 218 275 578 218 276 582 minecraft:yellow_stained_glass
fill 218 275 583 218 276 583 minecraft:gold_block
setblock 223 275 560 minecraft:light[level=14]
setblock 223 275 568 minecraft:light[level=14]
setblock 223 275 576 minecraft:light[level=14]
setblock 223 275 584 minecraft:light[level=14]
setblock 223 275 592 minecraft:light[level=14]
fill 199 276 575 199 276 577 minecraft:yellow_stained_glass
fill 199 276 583 199 276 585 minecraft:yellow_stained_glass
fill 200 276 575 200 277 575 minecraft:yellow_stained_glass
fill 200 276 585 200 277 585 minecraft:yellow_stained_glass
setblock 201 276 573 minecraft:gold_block
setblock 201 276 587 minecraft:gold_block
fill 203 276 572 203 277 572 minecraft:yellow_stained_glass
fill 203 276 588 203 277 588 minecraft:yellow_stained_glass
fill 204 276 571 205 276 571 minecraft:yellow_stained_glass
fill 204 276 589 205 276 589 minecraft:yellow_stained_glass
fill 211 276 571 213 276 571 minecraft:yellow_stained_glass
fill 211 276 589 213 276 589 minecraft:yellow_stained_glass
fill 213 276 572 213 277 572 minecraft:yellow_stained_glass
fill 213 276 588 213 277 588 minecraft:yellow_stained_glass
setblock 215 276 573 minecraft:gold_block
setblock 215 276 587 minecraft:gold_block
fill 216 276 575 216 277 575 minecraft:yellow_stained_glass
fill 216 276 585 216 277 585 minecraft:yellow_stained_glass
fill 217 276 576 217 276 577 minecraft:yellow_stained_glass
fill 217 276 583 217 276 584 minecraft:yellow_stained_glass
fill 199 277 577 199 277 583 minecraft:yellow_stained_glass
fill 200 277 576 200 277 577 minecraft:yellow_stained_glass
fill 200 277 583 200 277 584 minecraft:yellow_stained_glass
fill 201 277 574 201 277 575 minecraft:yellow_stained_glass
fill 201 277 585 201 277 586 minecraft:yellow_stained_glass
fill 202 277 573 203 277 573 minecraft:yellow_stained_glass
fill 202 277 574 202 278 574 minecraft:gold_block
fill 202 277 586 202 278 586 minecraft:gold_block
fill 202 277 587 203 277 587 minecraft:yellow_stained_glass
fill 204 277 572 205 277 572 minecraft:yellow_stained_glass
fill 204 277 588 205 277 588 minecraft:yellow_stained_glass
fill 205 277 571 211 277 571 minecraft:yellow_stained_glass
fill 205 277 589 211 277 589 minecraft:yellow_stained_glass
fill 211 277 572 212 277 572 minecraft:yellow_stained_glass
fill 211 277 588 212 277 588 minecraft:yellow_stained_glass
fill 213 277 573 214 277 573 minecraft:yellow_stained_glass
fill 213 277 587 214 277 587 minecraft:yellow_stained_glass
fill 214 277 574 214 278 574 minecraft:gold_block
fill 214 277 586 214 278 586 minecraft:gold_block
fill 215 277 574 215 277 575 minecraft:yellow_stained_glass
fill 215 277 585 215 277 586 minecraft:yellow_stained_glass
fill 216 277 576 216 277 577 minecraft:yellow_stained_glass
fill 216 277 583 216 277 584 minecraft:yellow_stained_glass
fill 217 277 577 217 277 583 minecraft:yellow_stained_glass
fill 200 278 577 201 278 577 minecraft:yellow_stained_glass
fill 200 278 578 201 278 578 minecraft:gold_block
fill 200 278 579 200 278 581 minecraft:yellow_stained_glass
fill 200 278 582 201 278 582 minecraft:gold_block
fill 200 278 583 201 278 583 minecraft:yellow_stained_glass
fill 201 278 575 202 278 576 minecraft:yellow_stained_glass
fill 201 278 584 202 278 585 minecraft:yellow_stained_glass
fill 203 278 573 204 278 574 minecraft:yellow_stained_glass
fill 203 278 586 204 278 587 minecraft:yellow_stained_glass
fill 205 278 572 205 278 573 minecraft:yellow_stained_glass
fill 205 278 587 205 278 588 minecraft:yellow_stained_glass
fill 206 278 572 206 278 573 minecraft:gold_block
fill 206 278 587 206 278 588 minecraft:gold_block
fill 207 278 572 209 278 572 minecraft:yellow_stained_glass
fill 207 278 588 209 278 588 minecraft:yellow_stained_glass
fill 210 278 572 210 278 573 minecraft:gold_block
fill 210 278 587 210 278 588 minecraft:gold_block
fill 211 278 572 211 278 573 minecraft:yellow_stained_glass
fill 211 278 587 211 278 588 minecraft:yellow_stained_glass
fill 212 278 573 213 278 574 minecraft:yellow_stained_glass
fill 212 278 586 213 278 587 minecraft:yellow_stained_glass
fill 214 278 575 215 278 576 minecraft:yellow_stained_glass
fill 214 278 584 215 278 585 minecraft:yellow_stained_glass
fill 215 278 577 216 278 577 minecraft:yellow_stained_glass
fill 215 278 578 216 278 578 minecraft:gold_block
fill 215 278 582 216 278 582 minecraft:gold_block
fill 215 278 583 216 278 583 minecraft:yellow_stained_glass
fill 216 278 579 216 278 581 minecraft:yellow_stained_glass
fill 201 279 577 203 280 577 minecraft:yellow_stained_glass
setblock 201 279 578 minecraft:gold_block
fill 201 279 579 202 280 581 minecraft:yellow_stained_glass
setblock 201 279 582 minecraft:gold_block
fill 201 279 583 203 280 583 minecraft:yellow_stained_glass
fill 202 279 576 203 280 576 minecraft:yellow_stained_glass
fill 202 279 578 202 280 578 minecraft:yellow_stained_glass
fill 202 279 582 202 280 582 minecraft:yellow_stained_glass
fill 202 279 584 203 280 584 minecraft:yellow_stained_glass
setblock 203 279 575 minecraft:gold_block
setblock 203 279 585 minecraft:gold_block
fill 204 279 574 205 280 575 minecraft:yellow_stained_glass
setblock 204 279 576 minecraft:gold_block
setblock 204 279 584 minecraft:gold_block
fill 204 279 585 205 280 586 minecraft:yellow_stained_glass
fill 205 279 573 205 280 573 minecraft:yellow_stained_glass
fill 205 279 587 205 280 587 minecraft:yellow_stained_glass
setblock 206 279 573 minecraft:gold_block
fill 206 279 574 212 280 574 minecraft:yellow_stained_glass
fill 206 279 586 212 280 586 minecraft:yellow_stained_glass
setblock 206 279 587 minecraft:gold_block
fill 207 279 573 209 280 573 minecraft:yellow_stained_glass
fill 207 279 587 209 280 587 minecraft:yellow_stained_glass
setblock 210 279 573 minecraft:gold_block
setblock 210 279 587 minecraft:gold_block
fill 211 279 573 211 280 573 minecraft:yellow_stained_glass
fill 211 279 575 212 280 575 minecraft:yellow_stained_glass
fill 211 279 585 212 280 585 minecraft:yellow_stained_glass
fill 211 279 587 211 280 587 minecraft:yellow_stained_glass
setblock 212 279 576 minecraft:gold_block
setblock 212 279 584 minecraft:gold_block
setblock 213 279 575 minecraft:gold_block
fill 213 279 576 214 280 577 minecraft:yellow_stained_glass
fill 213 279 583 214 280 584 minecraft:yellow_stained_glass
setblock 213 279 585 minecraft:gold_block
fill 214 279 578 214 280 582 minecraft:yellow_stained_glass
fill 215 279 577 215 280 577 minecraft:yellow_stained_glass
setblock 215 279 578 minecraft:gold_block
fill 215 279 579 215 280 581 minecraft:yellow_stained_glass
setblock 215 279 582 minecraft:gold_block
fill 215 279 583 215 280 583 minecraft:yellow_stained_glass
fill 189 280 558 197 280 598 minecraft:quartz_block
fill 198 280 558 198 280 575 minecraft:quartz_block
fill 198 280 576 200 280 584 minecraft:yellow_stained_glass
fill 198 280 585 198 280 598 minecraft:quartz_block
fill 199 280 558 199 280 574 minecraft:quartz_block
fill 199 280 575 203 280 575 minecraft:yellow_stained_glass
fill 199 280 585 203 280 585 minecraft:yellow_stained_glass
fill 199 280 586 199 280 598 minecraft:quartz_block
fill 200 280 558 200 280 572 minecraft:quartz_block
fill 200 280 573 203 280 574 minecraft:yellow_stained_glass
fill 200 280 586 203 280 587 minecraft:yellow_stained_glass
fill 200 280 588 200 280 598 minecraft:quartz_block
fill 201 280 558 202 280 571 minecraft:quartz_block
fill 201 280 572 215 280 572 minecraft:yellow_stained_glass
setblock 201 280 576 minecraft:yellow_stained_glass
setblock 201 280 578 minecraft:yellow_stained_glass
setblock 201 280 582 minecraft:yellow_stained_glass
setblock 201 280 584 minecraft:yellow_stained_glass
fill 201 280 588 215 280 588 minecraft:yellow_stained_glass
fill 201 280 589 202 280 598 minecraft:quartz_block
fill 203 280 558 203 280 570 minecraft:quartz_block
fill 203 280 571 213 280 571 minecraft:yellow_stained_glass
fill 203 280 578 204 280 582 minecraft:yellow_stained_glass
fill 203 280 589 213 280 589 minecraft:yellow_stained_glass
fill 203 280 590 203 280 598 minecraft:quartz_block
fill 204 280 558 229 280 569 minecraft:quartz_block
fill 204 280 570 212 280 570 minecraft:yellow_stained_glass
setblock 204 280 573 minecraft:yellow_stained_glass
fill 204 280 576 206 280 577 minecraft:yellow_stained_glass
fill 204 280 583 206 280 584 minecraft:yellow_stained_glass
setblock 204 280 587 minecraft:yellow_stained_glass
fill 204 280 590 212 280 590 minecraft:yellow_stained_glass
fill 204 280 591 229 280 598 minecraft:quartz_block
setblock 205 280 578 minecraft:yellow_stained_glass
fill 205 280 579 205 280 581 minecraft:ochre_froglight
setblock 205 280 582 minecraft:yellow_stained_glass
setblock 206 280 573 minecraft:yellow_stained_glass
fill 206 280 575 210 280 575 minecraft:yellow_stained_glass
fill 206 280 578 206 280 579 minecraft:ochre_froglight
fill 206 280 581 206 280 582 minecraft:ochre_froglight
fill 206 280 585 210 280 585 minecraft:yellow_stained_glass
setblock 206 280 587 minecraft:yellow_stained_glass
fill 207 280 576 212 280 576 minecraft:yellow_stained_glass
fill 207 280 577 207 280 578 minecraft:ochre_froglight
fill 207 280 582 207 280 583 minecraft:ochre_froglight
fill 207 280 584 212 280 584 minecraft:yellow_stained_glass
fill 208 280 577 209 280 577 minecraft:ochre_froglight
fill 208 280 583 209 280 583 minecraft:ochre_froglight
fill 209 280 578 210 280 578 minecraft:ochre_froglight
fill 209 280 582 210 280 582 minecraft:ochre_froglight
setblock 210 280 573 minecraft:yellow_stained_glass
fill 210 280 577 212 280 577 minecraft:yellow_stained_glass
fill 210 280 579 211 280 579 minecraft:ochre_froglight
fill 210 280 581 211 280 581 minecraft:ochre_froglight
fill 210 280 583 212 280 583 minecraft:yellow_stained_glass
setblock 210 280 587 minecraft:yellow_stained_glass
fill 211 280 578 213 280 578 minecraft:yellow_stained_glass
setblock 211 280 580 minecraft:ochre_froglight
fill 211 280 582 213 280 582 minecraft:yellow_stained_glass
fill 212 280 573 216 280 573 minecraft:yellow_stained_glass
fill 212 280 579 213 280 581 minecraft:yellow_stained_glass
fill 212 280 587 216 280 587 minecraft:yellow_stained_glass
fill 213 280 570 229 280 570 minecraft:quartz_block
fill 213 280 574 216 280 575 minecraft:yellow_stained_glass
fill 213 280 585 216 280 586 minecraft:yellow_stained_glass
fill 213 280 590 229 280 590 minecraft:quartz_block
fill 214 280 571 229 280 571 minecraft:quartz_block
fill 214 280 589 229 280 589 minecraft:quartz_block
fill 215 280 576 218 280 576 minecraft:yellow_stained_glass
fill 215 280 578 218 280 578 minecraft:yellow_stained_glass
fill 215 280 582 218 280 582 minecraft:yellow_stained_glass
fill 215 280 584 218 280 584 minecraft:yellow_stained_glass
fill 216 280 572 229 280 572 minecraft:quartz_block
fill 216 280 577 218 280 577 minecraft:yellow_stained_glass
fill 216 280 579 218 280 581 minecraft:yellow_stained_glass
fill 216 280 583 218 280 583 minecraft:yellow_stained_glass
fill 216 280 588 229 280 588 minecraft:quartz_block
fill 217 280 573 229 280 574 minecraft:quartz_block
setblock 217 280 575 minecraft:yellow_stained_glass
setblock 217 280 585 minecraft:yellow_stained_glass
fill 217 280 586 229 280 587 minecraft:quartz_block
fill 218 280 575 229 280 575 minecraft:quartz_block
fill 218 280 585 229 280 585 minecraft:quartz_block
fill 219 280 576 229 280 584 minecraft:quartz_block
fill 205 281 579 205 281 581 minecraft:yellow_stained_glass
setblock 206 281 578 minecraft:gold_block
setblock 206 281 579 minecraft:yellow_stained_glass
setblock 206 281 581 minecraft:yellow_stained_glass
setblock 206 281 582 minecraft:gold_block
fill 207 281 577 207 281 578 minecraft:yellow_stained_glass
fill 207 281 582 207 281 583 minecraft:yellow_stained_glass
fill 208 281 577 209 281 577 minecraft:yellow_stained_glass
fill 208 281 583 209 281 583 minecraft:yellow_stained_glass
setblock 209 281 578 minecraft:yellow_stained_glass
setblock 209 281 582 minecraft:yellow_stained_glass
setblock 210 281 578 minecraft:gold_block
fill 210 281 579 211 281 579 minecraft:yellow_stained_glass
fill 210 281 581 211 281 581 minecraft:yellow_stained_glass
setblock 210 281 582 minecraft:gold_block
setblock 211 281 580 minecraft:yellow_stained_glass
setblock 191 283 560 minecraft:light[level=14]
setblock 191 283 568 minecraft:light[level=14]
setblock 191 283 576 minecraft:light[level=14]
setblock 191 283 584 minecraft:light[level=14]
setblock 191 283 592 minecraft:light[level=14]
setblock 199 283 560 minecraft:light[level=14]
setblock 199 283 568 minecraft:light[level=14]
setblock 199 283 576 minecraft:light[level=14]
setblock 199 283 584 minecraft:light[level=14]
setblock 199 283 592 minecraft:light[level=14]
setblock 207 283 560 minecraft:light[level=14]
setblock 207 283 568 minecraft:light[level=14]
setblock 207 283 576 minecraft:light[level=14]
setblock 207 283 584 minecraft:light[level=14]
setblock 207 283 592 minecraft:light[level=14]
setblock 215 283 560 minecraft:light[level=14]
setblock 215 283 568 minecraft:light[level=14]
setblock 215 283 576 minecraft:light[level=14]
setblock 215 283 584 minecraft:light[level=14]
setblock 215 283 592 minecraft:light[level=14]
setblock 223 283 560 minecraft:light[level=14]
setblock 223 283 568 minecraft:light[level=14]
setblock 223 283 576 minecraft:light[level=14]
setblock 223 283 584 minecraft:light[level=14]
setblock 223 283 592 minecraft:light[level=14]
fill 189 284 558 191 300 558 minecraft:quartz_block
fill 189 284 561 193 284 573 minecraft:quartz_block
fill 189 284 580 189 300 582 minecraft:quartz_block
fill 189 284 592 189 300 594 minecraft:quartz_block
fill 190 284 579 190 285 581 minecraft:quartz_block
fill 190 284 591 190 285 593 minecraft:quartz_block
fill 192 284 590 205 284 598 minecraft:quartz_block
fill 200 284 559 202 285 559 minecraft:quartz_block
fill 201 284 558 203 300 558 minecraft:quartz_block
fill 207 284 598 209 300 598 minecraft:quartz_block
fill 208 284 597 210 285 597 minecraft:quartz_block
fill 212 284 559 214 285 559 minecraft:quartz_block
fill 213 284 558 215 300 558 minecraft:quartz_block
fill 217 284 559 221 288 559 minecraft:red_wool
fill 219 284 598 221 300 598 minecraft:quartz_block
fill 220 284 597 222 285 597 minecraft:quartz_block
fill 224 284 559 226 285 559 minecraft:quartz_block
fill 225 284 558 227 300 558 minecraft:quartz_block
fill 228 284 567 228 285 569 minecraft:quartz_block
fill 228 284 579 228 285 581 minecraft:quartz_block
fill 228 284 591 228 285 593 minecraft:quartz_block
fill 229 284 566 229 300 568 minecraft:quartz_block
fill 229 284 578 229 300 580 minecraft:quartz_block
fill 229 284 590 229 300 592 minecraft:quartz_block
fill 189 285 561 189 285 566 minecraft:yellow_terracotta
fill 189 285 567 193 285 572 minecraft:quartz_block
fill 189 285 573 189 285 578 minecraft:yellow_terracotta
fill 189 285 585 189 285 590 minecraft:yellow_terracotta
fill 189 285 597 189 285 598 minecraft:yellow_terracotta
fill 190 285 561 193 285 566 minecraft:quartz_block
fill 190 285 573 193 285 573 minecraft:quartz_block
fill 190 285 598 193 285 598 minecraft:yellow_terracotta
fill 192 285 590 205 285 597 minecraft:quartz_block
fill 193 285 558 198 285 558 minecraft:yellow_terracotta
fill 194 285 598 199 285 598 minecraft:quartz_block
fill 200 285 598 205 285 598 minecraft:yellow_terracotta
fill 205 285 558 210 285 558 minecraft:yellow_terracotta
fill 212 285 598 217 285 598 minecraft:yellow_terracotta
fill 217 285 558 222 285 558 minecraft:yellow_terracotta
fill 224 285 598 229 285 598 minecraft:yellow_terracotta
fill 229 285 558 229 285 563 minecraft:yellow_terracotta
fill 229 285 570 229 285 575 minecraft:yellow_terracotta
fill 229 285 582 229 285 587 minecraft:yellow_terracotta
fill 229 285 594 229 285 597 minecraft:yellow_terracotta
fill 188 286 563 188 291 566 minecraft:ochre_froglight
fill 188 286 575 188 291 578 minecraft:ochre_froglight
fill 188 286 587 188 291 590 minecraft:ochre_froglight
fill 188 286 599 191 291 599 minecraft:ochre_froglight
fill 189 286 561 189 300 561 minecraft:quartz_block
setblock 189 286 562 minecraft:ochre_froglight
fill 189 286 563 189 300 563 minecraft:quartz_block
setblock 189 286 564 minecraft:ochre_froglight
fill 189 286 565 189 300 565 minecraft:quartz_block
setblock 189 286 566 minecraft:ochre_froglight
fill 189 286 567 189 300 567 minecraft:quartz_block
setblock 189 286 568 minecraft:ochre_froglight
fill 189 286 569 189 300 569 minecraft:quartz_block
setblock 189 286 570 minecraft:ochre_froglight
fill 189 286 571 189 300 571 minecraft:quartz_block
setblock 189 286 572 minecraft:ochre_froglight
fill 189 286 573 189 300 573 minecraft:quartz_block
setblock 190 286 561 minecraft:ochre_froglight
fill 190 286 562 190 300 562 minecraft:quartz_block
setblock 190 286 563 minecraft:ochre_froglight
fill 190 286 564 190 300 564 minecraft:quartz_block
setblock 190 286 565 minecraft:ochre_froglight
fill 190 286 566 190 300 566 minecraft:quartz_block
setblock 190 286 567 minecraft:ochre_froglight
fill 190 286 568 190 300 568 minecraft:quartz_block
setblock 190 286 569 minecraft:ochre_froglight
fill 190 286 570 190 300 570 minecraft:quartz_block
setblock 190 286 571 minecraft:ochre_froglight
fill 190 286 572 190 300 572 minecraft:quartz_block
setblock 190 286 573 minecraft:ochre_froglight
fill 191 286 561 191 300 561 minecraft:quartz_block
setblock 191 286 562 minecraft:ochre_froglight
fill 191 286 563 191 300 563 minecraft:quartz_block
setblock 191 286 564 minecraft:ochre_froglight
fill 191 286 565 191 300 565 minecraft:quartz_block
setblock 191 286 566 minecraft:ochre_froglight
fill 191 286 567 191 300 567 minecraft:quartz_block
setblock 191 286 568 minecraft:ochre_froglight
fill 191 286 569 191 300 569 minecraft:quartz_block
setblock 191 286 570 minecraft:ochre_froglight
fill 191 286 571 191 300 571 minecraft:quartz_block
setblock 191 286 572 minecraft:ochre_froglight
fill 191 286 573 191 300 573 minecraft:quartz_block
setblock 192 286 561 minecraft:ochre_froglight
fill 192 286 562 192 300 562 minecraft:quartz_block
setblock 192 286 563 minecraft:ochre_froglight
fill 192 286 564 192 300 564 minecraft:quartz_block
setblock 192 286 565 minecraft:ochre_froglight
fill 192 286 566 192 300 566 minecraft:quartz_block
setblock 192 286 567 minecraft:ochre_froglight
fill 192 286 568 192 300 568 minecraft:quartz_block
setblock 192 286 569 minecraft:ochre_froglight
fill 192 286 570 192 300 570 minecraft:quartz_block
setblock 192 286 571 minecraft:ochre_froglight
fill 192 286 572 192 300 572 minecraft:quartz_block
setblock 192 286 573 minecraft:ochre_froglight
fill 192 286 590 192 300 590 minecraft:quartz_block
setblock 192 286 591 minecraft:ochre_froglight
fill 192 286 592 192 300 592 minecraft:quartz_block
setblock 192 286 593 minecraft:ochre_froglight
fill 192 286 594 192 300 594 minecraft:quartz_block
setblock 192 286 595 minecraft:ochre_froglight
fill 192 286 596 192 300 596 minecraft:quartz_block
setblock 192 286 597 minecraft:ochre_froglight
fill 192 286 598 192 300 598 minecraft:quartz_block
fill 193 286 561 193 300 561 minecraft:quartz_block
setblock 193 286 562 minecraft:ochre_froglight
fill 193 286 563 193 300 563 minecraft:quartz_block
setblock 193 286 564 minecraft:ochre_froglight
fill 193 286 565 193 300 565 minecraft:quartz_block
setblock 193 286 566 minecraft:ochre_froglight
fill 193 286 567 193 300 567 minecraft:quartz_block
setblock 193 286 568 minecraft:ochre_froglight
fill 193 286 569 193 300 569 minecraft:quartz_block
setblock 193 286 570 minecraft:ochre_froglight
fill 193 286 571 193 300 571 minecraft:quartz_block
setblock 193 286 572 minecraft:ochre_froglight
fill 193 286 573 193 300 573 minecraft:quartz_block
setblock 193 286 590 minecraft:ochre_froglight
fill 193 286 591 193 300 591 minecraft:quartz_block
setblock 193 286 592 minecraft:ochre_froglight
fill 193 286 593 193 300 593 minecraft:quartz_block
setblock 193 286 594 minecraft:ochre_froglight
fill 193 286 595 193 300 595 minecraft:quartz_block
setblock 193 286 596 minecraft:ochre_froglight
fill 193 286 597 193 300 597 minecraft:quartz_block
setblock 193 286 598 minecraft:ochre_froglight
fill 194 286 590 194 300 590 minecraft:quartz_block
setblock 194 286 591 minecraft:ochre_froglight
fill 194 286 592 194 300 592 minecraft:quartz_block
setblock 194 286 593 minecraft:ochre_froglight
fill 194 286 594 194 300 594 minecraft:quartz_block
setblock 194 286 595 minecraft:ochre_froglight
fill 194 286 596 194 300 596 minecraft:quartz_block
setblock 194 286 597 minecraft:ochre_froglight
fill 194 286 598 194 300 598 minecraft:quartz_block
fill 195 286 557 198 291 557 minecraft:ochre_froglight
setblock 195 286 590 minecraft:ochre_froglight
fill 195 286 591 195 300 591 minecraft:quartz_block
setblock 195 286 592 minecraft:ochre_froglight
fill 195 286 593 195 300 593 minecraft:quartz_block
setblock 195 286 594 minecraft:ochre_froglight
fill 195 286 595 195 300 595 minecraft:quartz_block
setblock 195 286 596 minecraft:ochre_froglight
fill 195 286 597 195 300 597 minecraft:quartz_block
setblock 195 286 598 minecraft:ochre_froglight
fill 196 286 590 196 300 590 minecraft:quartz_block
setblock 196 286 591 minecraft:ochre_froglight
fill 196 286 592 196 300 592 minecraft:quartz_block
setblock 196 286 593 minecraft:ochre_froglight
fill 196 286 594 196 300 594 minecraft:quartz_block
setblock 196 286 595 minecraft:ochre_froglight
fill 196 286 596 196 300 596 minecraft:quartz_block
setblock 196 286 597 minecraft:ochre_froglight
fill 196 286 598 196 300 598 minecraft:quartz_block
setblock 197 286 590 minecraft:ochre_froglight
fill 197 286 591 197 300 591 minecraft:quartz_block
setblock 197 286 592 minecraft:ochre_froglight
fill 197 286 593 197 300 593 minecraft:quartz_block
setblock 197 286 594 minecraft:ochre_froglight
fill 197 286 595 197 300 595 minecraft:quartz_block
setblock 197 286 596 minecraft:ochre_froglight
fill 197 286 597 197 300 597 minecraft:quartz_block
setblock 197 286 598 minecraft:ochre_froglight
fill 198 286 590 198 300 590 minecraft:quartz_block
setblock 198 286 591 minecraft:ochre_froglight
fill 198 286 592 198 300 592 minecraft:quartz_block
setblock 198 286 593 minecraft:ochre_froglight
fill 198 286 594 198 300 594 minecraft:quartz_block
setblock 198 286 595 minecraft:ochre_froglight
fill 198 286 596 198 300 596 minecraft:quartz_block
setblock 198 286 597 minecraft:ochre_froglight
fill 198 286 598 198 300 598 minecraft:quartz_block
setblock 199 286 590 minecraft:ochre_froglight
fill 199 286 591 199 300 591 minecraft:quartz_block
setblock 199 286 592 minecraft:ochre_froglight
fill 199 286 593 199 300 593 minecraft:quartz_block
setblock 199 286 594 minecraft:ochre_froglight
fill 199 286 595 199 300 595 minecraft:quartz_block
setblock 199 286 596 minecraft:ochre_froglight
fill 199 286 597 199 300 597 minecraft:quartz_block
setblock 199 286 598 minecraft:ochre_froglight
fill 200 286 590 200 300 590 minecraft:quartz_block
setblock 200 286 591 minecraft:ochre_froglight
fill 200 286 592 200 300 592 minecraft:quartz_block
setblock 200 286 593 minecraft:ochre_froglight
fill 200 286 594 200 300 594 minecraft:quartz_block
setblock 200 286 595 minecraft:ochre_froglight
fill 200 286 596 200 300 596 minecraft:quartz_block
setblock 200 286 597 minecraft:ochre_froglight
fill 200 286 598 200 300 598 minecraft:quartz_block
fill 200 286 599 203 291 599 minecraft:ochre_froglight
setblock 201 286 590 minecraft:ochre_froglight
fill 201 286 591 201 300 591 minecraft:quartz_block
setblock 201 286 592 minecraft:ochre_froglight
fill 201 286 593 201 300 593 minecraft:quartz_block
setblock 201 286 594 minecraft:ochre_froglight
fill 201 286 595 201 300 595 minecraft:quartz_block
setblock 201 286 596 minecraft:ochre_froglight
fill 201 286 597 201 300 597 minecraft:quartz_block
setblock 201 286 598 minecraft:ochre_froglight
fill 202 286 590 202 300 590 minecraft:quartz_block
setblock 202 286 591 minecraft:ochre_froglight
fill 202 286 592 202 300 592 minecraft:quartz_block
setblock 202 286 593 minecraft:ochre_froglight
fill 202 286 594 202 300 594 minecraft:quartz_block
setblock 202 286 595 minecraft:ochre_froglight
fill 202 286 596 202 300 596 minecraft:quartz_block
setblock 202 286 597 minecraft:ochre_froglight
fill 202 286 598 202 300 598 minecraft:quartz_block
setblock 203 286 590 minecraft:ochre_froglight
fill 203 286 591 203 300 591 minecraft:quartz_block
setblock 203 286 592 minecraft:ochre_froglight
fill 203 286 593 203 300 593 minecraft:quartz_block
setblock 203 286 594 minecraft:ochre_froglight
fill 203 286 595 203 300 595 minecraft:quartz_block
setblock 203 286 596 minecraft:ochre_froglight
fill 203 286 597 203 300 597 minecraft:quartz_block
setblock 203 286 598 minecraft:ochre_froglight
fill 204 286 590 204 300 590 minecraft:quartz_block
setblock 204 286 591 minecraft:ochre_froglight
fill 204 286 592 204 300 592 minecraft:quartz_block
setblock 204 286 593 minecraft:ochre_froglight
fill 204 286 594 204 300 594 minecraft:quartz_block
setblock 204 286 595 minecraft:ochre_froglight
fill 204 286 596 204 300 596 minecraft:quartz_block
setblock 204 286 597 minecraft:ochre_froglight
fill 204 286 598 204 300 598 minecraft:quartz_block
setblock 205 286 590 minecraft:ochre_froglight
fill 205 286 591 205 300 591 minecraft:quartz_block
setblock 205 286 592 minecraft:ochre_froglight
fill 205 286 593 205 300 593 minecraft:quartz_block
setblock 205 286 594 minecraft:ochre_froglight
fill 205 286 595 205 300 595 minecraft:quartz_block
setblock 205 286 596 minecraft:ochre_froglight
fill 205 286 597 205 300 597 minecraft:quartz_block
setblock 205 286 598 minecraft:ochre_froglight
fill 207 286 557 210 291 557 minecraft:ochre_froglight
fill 212 286 599 215 291 599 minecraft:ochre_froglight
fill 219 286 557 222 291 557 minecraft:ochre_froglight
fill 224 286 599 227 291 599 minecraft:ochre_froglight
fill 227 286 589 227 299 589 minecraft:red_wool
fill 230 286 558 230 291 561 minecraft:ochre_froglight
fill 230 286 570 230 291 573 minecraft:ochre_froglight
fill 230 286 582 230 291 585 minecraft:ochre_froglight
fill 230 286 594 230 291 597 minecraft:ochre_froglight
fill 189 287 562 189 288 562 minecraft:quartz_block
fill 189 287 564 189 288 564 minecraft:quartz_block
fill 189 287 566 189 288 566 minecraft:quartz_block
fill 189 287 568 189 288 568 minecraft:quartz_block
fill 189 287 570 189 288 570 minecraft:quartz_block
fill 189 287 572 189 288 572 minecraft:quartz_block
fill 190 287 561 190 288 561 minecraft:quartz_block
fill 190 287 563 190 288 563 minecraft:quartz_block
fill 190 287 565 190 288 565 minecraft:quartz_block
fill 190 287 567 190 288 567 minecraft:quartz_block
fill 190 287 569 190 288 569 minecraft:quartz_block
fill 190 287 571 190 288 571 minecraft:quartz_block
fill 190 287 573 190 288 573 minecraft:quartz_block
fill 191 287 562 191 288 562 minecraft:quartz_block
fill 191 287 564 191 288 564 minecraft:quartz_block
fill 191 287 566 191 288 566 minecraft:quartz_block
fill 191 287 568 191 288 568 minecraft:quartz_block
fill 191 287 570 191 288 570 minecraft:quartz_block
fill 191 287 572 191 288 572 minecraft:quartz_block
fill 192 287 561 192 288 561 minecraft:quartz_block
fill 192 287 563 192 288 563 minecraft:quartz_block
fill 192 287 565 192 288 565 minecraft:quartz_block
fill 192 287 567 192 288 567 minecraft:quartz_block
fill 192 287 569 192 288 569 minecraft:quartz_block
fill 192 287 571 192 288 571 minecraft:quartz_block
fill 192 287 573 192 288 573 minecraft:quartz_block
fill 192 287 591 192 288 591 minecraft:quartz_block
fill 192 287 593 192 288 593 minecraft:quartz_block
fill 192 287 595 192 288 595 minecraft:quartz_block
fill 192 287 597 192 288 597 minecraft:quartz_block
fill 193 287 562 193 288 562 minecraft:quartz_block
fill 193 287 564 193 288 564 minecraft:quartz_block
fill 193 287 566 193 288 566 minecraft:quartz_block
fill 193 287 568 193 288 568 minecraft:quartz_block
fill 193 287 570 193 288 570 minecraft:quartz_block
fill 193 287 572 193 288 572 minecraft:quartz_block
fill 193 287 590 193 288 590 minecraft:quartz_block
fill 193 287 592 193 288 592 minecraft:quartz_block
fill 193 287 594 193 288 594 minecraft:quartz_block
fill 193 287 596 193 288 596 minecraft:quartz_block
fill 193 287 598 193 288 598 minecraft:quartz_block
fill 194 287 591 194 288 591 minecraft:quartz_block
fill 194 287 593 194 288 593 minecraft:quartz_block
fill 194 287 595 194 288 595 minecraft:quartz_block
fill 194 287 597 194 288 597 minecraft:quartz_block
fill 195 287 590 195 288 590 minecraft:quartz_block
fill 195 287 592 195 288 592 minecraft:quartz_block
fill 195 287 594 195 288 594 minecraft:quartz_block
fill 195 287 596 195 288 596 minecraft:quartz_block
fill 195 287 598 195 288 598 minecraft:quartz_block
fill 196 287 591 196 288 591 minecraft:quartz_block
fill 196 287 593 196 288 593 minecraft:quartz_block
fill 196 287 595 196 288 595 minecraft:quartz_block
fill 196 287 597 196 288 597 minecraft:quartz_block
fill 197 287 590 197 288 590 minecraft:quartz_block
fill 197 287 592 197 288 592 minecraft:quartz_block
fill 197 287 594 197 288 594 minecraft:quartz_block
fill 197 287 596 197 288 596 minecraft:quartz_block
fill 197 287 598 197 288 598 minecraft:quartz_block
fill 198 287 591 198 288 591 minecraft:quartz_block
fill 198 287 593 198 288 593 minecraft:quartz_block
fill 198 287 595 198 288 595 minecraft:quartz_block
fill 198 287 597 198 288 597 minecraft:quartz_block
fill 199 287 590 199 288 590 minecraft:quartz_block
fill 199 287 592 199 288 592 minecraft:quartz_block
fill 199 287 594 199 288 594 minecraft:quartz_block
fill 199 287 596 199 288 596 minecraft:quartz_block
fill 199 287 598 199 288 598 minecraft:quartz_block
fill 200 287 591 200 288 591 minecraft:quartz_block
fill 200 287 593 200 288 593 minecraft:quartz_block
fill 200 287 595 200 288 595 minecraft:quartz_block
fill 200 287 597 200 288 597 minecraft:quartz_block
fill 201 287 590 201 288 590 minecraft:quartz_block
fill 201 287 592 201 288 592 minecraft:quartz_block
fill 201 287 594 201 288 594 minecraft:quartz_block
fill 201 287 596 201 288 596 minecraft:quartz_block
fill 201 287 598 201 288 598 minecraft:quartz_block
fill 202 287 591 202 288 591 minecraft:quartz_block
fill 202 287 593 202 288 593 minecraft:quartz_block
fill 202 287 595 202 288 595 minecraft:quartz_block
fill 202 287 597 202 288 597 minecraft:quartz_block
fill 203 287 590 203 288 590 minecraft:quartz_block
fill 203 287 592 203 288 592 minecraft:quartz_block
fill 203 287 594 203 288 594 minecraft:quartz_block
fill 203 287 596 203 288 596 minecraft:quartz_block
fill 203 287 598 203 288 598 minecraft:quartz_block
fill 204 287 591 204 288 591 minecraft:quartz_block
fill 204 287 593 204 288 593 minecraft:quartz_block
fill 204 287 595 204 288 595 minecraft:quartz_block
fill 204 287 597 204 288 597 minecraft:quartz_block
fill 205 287 590 205 288 590 minecraft:quartz_block
fill 205 287 592 205 288 592 minecraft:quartz_block
fill 205 287 594 205 288 594 minecraft:quartz_block
fill 205 287 596 205 288 596 minecraft:quartz_block
fill 205 287 598 205 288 598 minecraft:quartz_block
fill 227 287 587 227 299 588 minecraft:red_wool
fill 227 287 590 227 299 591 minecraft:red_wool
setblock 189 289 562 minecraft:ochre_froglight
setblock 189 289 564 minecraft:ochre_froglight
setblock 189 289 566 minecraft:ochre_froglight
setblock 189 289 568 minecraft:ochre_froglight
setblock 189 289 570 minecraft:ochre_froglight
setblock 189 289 572 minecraft:ochre_froglight
setblock 190 289 561 minecraft:ochre_froglight
setblock 190 289 563 minecraft:ochre_froglight
setblock 190 289 565 minecraft:ochre_froglight
setblock 190 289 567 minecraft:ochre_froglight
setblock 190 289 569 minecraft:ochre_froglight
setblock 190 289 571 minecraft:ochre_froglight
setblock 190 289 573 minecraft:ochre_froglight
setblock 191 289 562 minecraft:ochre_froglight
setblock 191 289 564 minecraft:ochre_froglight
setblock 191 289 566 minecraft:ochre_froglight
setblock 191 289 568 minecraft:ochre_froglight
setblock 191 289 570 minecraft:ochre_froglight
setblock 191 289 572 minecraft:ochre_froglight
setblock 192 289 561 minecraft:ochre_froglight
setblock 192 289 563 minecraft:ochre_froglight
setblock 192 289 565 minecraft:ochre_froglight
setblock 192 289 567 minecraft:ochre_froglight
setblock 192 289 569 minecraft:ochre_froglight
setblock 192 289 571 minecraft:ochre_froglight
setblock 192 289 573 minecraft:ochre_froglight
setblock 192 289 591 minecraft:ochre_froglight
setblock 192 289 593 minecraft:ochre_froglight
setblock 192 289 595 minecraft:ochre_froglight
setblock 192 289 597 minecraft:ochre_froglight
setblock 193 289 562 minecraft:ochre_froglight
setblock 193 289 564 minecraft:ochre_froglight
setblock 193 289 566 minecraft:ochre_froglight
setblock 193 289 568 minecraft:ochre_froglight
setblock 193 289 570 minecraft:ochre_froglight
setblock 193 289 572 minecraft:ochre_froglight
setblock 193 289 590 minecraft:ochre_froglight
setblock 193 289 592 minecraft:ochre_froglight
setblock 193 289 594 minecraft:ochre_froglight
setblock 193 289 596 minecraft:ochre_froglight
setblock 193 289 598 minecraft:ochre_froglight
setblock 194 289 591 minecraft:ochre_froglight
setblock 194 289 593 minecraft:ochre_froglight
setblock 194 289 595 minecraft:ochre_froglight
setblock 194 289 597 minecraft:ochre_froglight
setblock 195 289 590 minecraft:ochre_froglight
setblock 195 289 592 minecraft:ochre_froglight
setblock 195 289 594 minecraft:ochre_froglight
setblock 195 289 596 minecraft:ochre_froglight
setblock 195 289 598 minecraft:ochre_froglight
setblock 196 289 591 minecraft:ochre_froglight
setblock 196 289 593 minecraft:ochre_froglight
setblock 196 289 595 minecraft:ochre_froglight
setblock 196 289 597 minecraft:ochre_froglight
setblock 197 289 590 minecraft:ochre_froglight
setblock 197 289 592 minecraft:ochre_froglight
setblock 197 289 594 minecraft:ochre_froglight
setblock 197 289 596 minecraft:ochre_froglight
setblock 197 289 598 minecraft:ochre_froglight
setblock 198 289 591 minecraft:ochre_froglight
setblock 198 289 593 minecraft:ochre_froglight
setblock 198 289 595 minecraft:ochre_froglight
setblock 198 289 597 minecraft:ochre_froglight
setblock 199 289 590 minecraft:ochre_froglight
setblock 199 289 592 minecraft:ochre_froglight
setblock 199 289 594 minecraft:ochre_froglight
setblock 199 289 596 minecraft:ochre_froglight
setblock 199 289 598 minecraft:ochre_froglight
setblock 200 289 591 minecraft:ochre_froglight
setblock 200 289 593 minecraft:ochre_froglight
setblock 200 289 595 minecraft:ochre_froglight
setblock 200 289 597 minecraft:ochre_froglight
setblock 201 289 590 minecraft:ochre_froglight
setblock 201 289 592 minecraft:ochre_froglight
setblock 201 289 594 minecraft:ochre_froglight
setblock 201 289 596 minecraft:ochre_froglight
setblock 201 289 598 minecraft:ochre_froglight
setblock 202 289 591 minecraft:ochre_froglight
setblock 202 289 593 minecraft:ochre_froglight
setblock 202 289 595 minecraft:ochre_froglight
setblock 202 289 597 minecraft:ochre_froglight
setblock 203 289 590 minecraft:ochre_froglight
setblock 203 289 592 minecraft:ochre_froglight
setblock 203 289 594 minecraft:ochre_froglight
setblock 203 289 596 minecraft:ochre_froglight
setblock 203 289 598 minecraft:ochre_froglight
setblock 204 289 591 minecraft:ochre_froglight
setblock 204 289 593 minecraft:ochre_froglight
setblock 204 289 595 minecraft:ochre_froglight
setblock 204 289 597 minecraft:ochre_froglight
setblock 205 289 590 minecraft:ochre_froglight
setblock 205 289 592 minecraft:ochre_froglight
setblock 205 289 594 minecraft:ochre_froglight
setblock 205 289 596 minecraft:ochre_froglight
setblock 205 289 598 minecraft:ochre_froglight
fill 216 289 559 222 290 559 minecraft:gold_block
fill 189 290 562 189 291 562 minecraft:quartz_block
fill 189 290 564 189 291 564 minecraft:quartz_block
fill 189 290 566 189 291 566 minecraft:quartz_block
fill 189 290 568 189 291 568 minecraft:quartz_block
fill 189 290 570 189 291 570 minecraft:quartz_block
fill 189 290 572 189 291 572 minecraft:quartz_block
fill 190 290 561 190 291 561 minecraft:quartz_block
fill 190 290 563 190 291 563 minecraft:quartz_block
fill 190 290 565 190 291 565 minecraft:quartz_block
fill 190 290 567 190 291 567 minecraft:quartz_block
fill 190 290 569 190 291 569 minecraft:quartz_block
fill 190 290 571 190 291 571 minecraft:quartz_block
fill 190 290 573 190 291 573 minecraft:quartz_block
fill 191 290 562 191 291 562 minecraft:quartz_block
fill 191 290 564 191 291 564 minecraft:quartz_block
fill 191 290 566 191 291 566 minecraft:quartz_block
fill 191 290 568 191 291 568 minecraft:quartz_block
fill 191 290 570 191 291 570 minecraft:quartz_block
fill 191 290 572 191 291 572 minecraft:quartz_block
fill 192 290 561 192 291 561 minecraft:quartz_block
fill 192 290 563 192 291 563 minecraft:quartz_block
fill 192 290 565 192 291 565 minecraft:quartz_block
fill 192 290 567 192 291 567 minecraft:quartz_block
fill 192 290 569 192 291 569 minecraft:quartz_block
fill 192 290 571 192 291 571 minecraft:quartz_block
fill 192 290 573 192 291 573 minecraft:quartz_block
fill 192 290 591 192 291 591 minecraft:quartz_block
fill 192 290 593 192 291 593 minecraft:quartz_block
fill 192 290 595 192 291 595 minecraft:quartz_block
fill 192 290 597 192 291 597 minecraft:quartz_block
fill 193 290 562 193 291 562 minecraft:quartz_block
fill 193 290 564 193 291 564 minecraft:quartz_block
fill 193 290 566 193 291 566 minecraft:quartz_block
fill 193 290 568 193 291 568 minecraft:quartz_block
fill 193 290 570 193 291 570 minecraft:quartz_block
fill 193 290 572 193 291 572 minecraft:quartz_block
fill 193 290 590 193 291 590 minecraft:quartz_block
fill 193 290 592 193 291 592 minecraft:quartz_block
fill 193 290 594 193 291 594 minecraft:quartz_block
fill 193 290 596 193 291 596 minecraft:quartz_block
fill 193 290 598 193 291 598 minecraft:quartz_block
fill 194 290 591 194 291 591 minecraft:quartz_block
fill 194 290 593 194 291 593 minecraft:quartz_block
fill 194 290 595 194 291 595 minecraft:quartz_block
fill 194 290 597 194 291 597 minecraft:quartz_block
fill 195 290 590 195 291 590 minecraft:quartz_block
fill 195 290 592 195 291 592 minecraft:quartz_block
fill 195 290 594 195 291 594 minecraft:quartz_block
fill 195 290 596 195 291 596 minecraft:quartz_block
fill 195 290 598 195 291 598 minecraft:quartz_block
fill 196 290 591 196 291 591 minecraft:quartz_block
fill 196 290 593 196 291 593 minecraft:quartz_block
fill 196 290 595 196 291 595 minecraft:quartz_block
fill 196 290 597 196 291 597 minecraft:quartz_block
fill 197 290 590 197 291 590 minecraft:quartz_block
fill 197 290 592 197 291 592 minecraft:quartz_block
fill 197 290 594 197 291 594 minecraft:quartz_block
fill 197 290 596 197 291 596 minecraft:quartz_block
fill 197 290 598 197 291 598 minecraft:quartz_block
fill 198 290 563 199 291 563 minecraft:raw_gold_block
fill 198 290 591 198 291 591 minecraft:quartz_block
fill 198 290 593 198 291 593 minecraft:quartz_block
fill 198 290 595 198 291 595 minecraft:quartz_block
fill 198 290 597 198 291 597 minecraft:quartz_block
fill 199 290 590 199 291 590 minecraft:quartz_block
fill 199 290 592 199 291 592 minecraft:quartz_block
fill 199 290 594 199 291 594 minecraft:quartz_block
fill 199 290 596 199 291 596 minecraft:quartz_block
fill 199 290 598 199 291 598 minecraft:quartz_block
fill 200 290 591 200 291 591 minecraft:quartz_block
fill 200 290 593 200 291 593 minecraft:quartz_block
fill 200 290 595 200 291 595 minecraft:quartz_block
fill 200 290 597 200 291 597 minecraft:quartz_block
fill 201 290 590 201 291 590 minecraft:quartz_block
fill 201 290 592 201 291 592 minecraft:quartz_block
fill 201 290 594 201 291 594 minecraft:quartz_block
fill 201 290 596 201 291 596 minecraft:quartz_block
fill 201 290 598 201 291 598 minecraft:quartz_block
fill 202 290 591 202 291 591 minecraft:quartz_block
fill 202 290 593 202 291 593 minecraft:quartz_block
fill 202 290 595 202 291 595 minecraft:quartz_block
fill 202 290 597 202 291 597 minecraft:quartz_block
fill 203 290 590 203 291 590 minecraft:quartz_block
fill 203 290 592 203 291 592 minecraft:quartz_block
fill 203 290 594 203 291 594 minecraft:quartz_block
fill 203 290 596 203 291 596 minecraft:quartz_block
fill 203 290 598 203 291 598 minecraft:quartz_block
fill 204 290 591 204 291 591 minecraft:quartz_block
fill 204 290 593 204 291 593 minecraft:quartz_block
fill 204 290 595 204 291 595 minecraft:quartz_block
fill 204 290 597 204 291 597 minecraft:quartz_block
fill 205 290 590 205 291 590 minecraft:quartz_block
fill 205 290 592 205 291 592 minecraft:quartz_block
fill 205 290 594 205 291 594 minecraft:quartz_block
fill 205 290 596 205 291 596 minecraft:quartz_block
fill 205 290 598 205 291 598 minecraft:quartz_block
setblock 191 291 560 minecraft:light[level=14]
setblock 191 291 576 minecraft:light[level=14]
setblock 191 291 584 minecraft:light[level=14]
setblock 191 291 592 minecraft:light[level=14]
setblock 199 291 560 minecraft:light[level=14]
setblock 199 291 568 minecraft:light[level=14]
setblock 199 291 576 minecraft:light[level=14]
setblock 199 291 584 minecraft:light[level=14]
setblock 207 291 560 minecraft:light[level=14]
setblock 207 291 568 minecraft:light[level=14]
setblock 207 291 576 minecraft:light[level=14]
setblock 207 291 584 minecraft:light[level=14]
setblock 207 291 592 minecraft:light[level=14]
setblock 215 291 560 minecraft:light[level=14]
setblock 215 291 568 minecraft:light[level=14]
setblock 215 291 576 minecraft:light[level=14]
setblock 215 291 584 minecraft:light[level=14]
setblock 215 291 592 minecraft:light[level=14]
setblock 223 291 560 minecraft:light[level=14]
setblock 223 291 568 minecraft:light[level=14]
setblock 223 291 576 minecraft:light[level=14]
setblock 223 291 584 minecraft:light[level=14]
setblock 223 291 592 minecraft:light[level=14]
fill 188 292 563 188 307 563 minecraft:gold_block
fill 188 292 564 188 292 565 minecraft:ochre_froglight
fill 188 292 566 188 307 566 minecraft:gold_block
fill 188 292 575 188 307 575 minecraft:gold_block
fill 188 292 576 188 292 577 minecraft:ochre_froglight
fill 188 292 578 188 307 578 minecraft:gold_block
fill 188 292 587 188 307 587 minecraft:gold_block
fill 188 292 588 188 292 589 minecraft:ochre_froglight
fill 188 292 590 188 307 590 minecraft:gold_block
fill 188 292 599 188 307 599 minecraft:gold_block
setblock 189 292 562 minecraft:ochre_froglight
setblock 189 292 564 minecraft:ochre_froglight
setblock 189 292 566 minecraft:ochre_froglight
setblock 189 292 568 minecraft:ochre_froglight
setblock 189 292 570 minecraft:ochre_froglight
setblock 189 292 572 minecraft:ochre_froglight
fill 189 292 599 190 292 599 minecraft:ochre_froglight
setblock 190 292 561 minecraft:ochre_froglight
setblock 190 292 563 minecraft:ochre_froglight
setblock 190 292 565 minecraft:ochre_froglight
setblock 190 292 567 minecraft:ochre_froglight
setblock 190 292 569 minecraft:ochre_froglight
setblock 190 292 571 minecraft:ochre_froglight
setblock 190 292 573 minecraft:ochre_froglight
setblock 191 292 562 minecraft:ochre_froglight
setblock 191 292 564 minecraft:ochre_froglight
setblock 191 292 566 minecraft:ochre_froglight
setblock 191 292 568 minecraft:ochre_froglight
setblock 191 292 570 minecraft:ochre_froglight
setblock 191 292 572 minecraft:ochre_froglight
fill 191 292 599 191 307 599 minecraft:gold_block
setblock 192 292 561 minecraft:ochre_froglight
setblock 192 292 563 minecraft:ochre_froglight
setblock 192 292 565 minecraft:ochre_froglight
setblock 192 292 567 minecraft:ochre_froglight
setblock 192 292 569 minecraft:ochre_froglight
setblock 192 292 571 minecraft:ochre_froglight
setblock 192 292 573 minecraft:ochre_froglight
setblock 192 292 591 minecraft:ochre_froglight
setblock 192 292 593 minecraft:ochre_froglight
setblock 192 292 595 minecraft:ochre_froglight
setblock 192 292 597 minecraft:ochre_froglight
setblock 193 292 562 minecraft:ochre_froglight
setblock 193 292 564 minecraft:ochre_froglight
setblock 193 292 566 minecraft:ochre_froglight
setblock 193 292 568 minecraft:ochre_froglight
setblock 193 292 570 minecraft:ochre_froglight
setblock 193 292 572 minecraft:ochre_froglight
setblock 193 292 590 minecraft:ochre_froglight
setblock 193 292 592 minecraft:ochre_froglight
setblock 193 292 594 minecraft:ochre_froglight
setblock 193 292 596 minecraft:ochre_froglight
setblock 193 292 598 minecraft:ochre_froglight
setblock 194 292 591 minecraft:ochre_froglight
setblock 194 292 593 minecraft:ochre_froglight
setblock 194 292 595 minecraft:ochre_froglight
setblock 194 292 597 minecraft:ochre_froglight
fill 195 292 557 195 307 557 minecraft:gold_block
setblock 195 292 590 minecraft:ochre_froglight
setblock 195 292 592 minecraft:ochre_froglight
setblock 195 292 594 minecraft:ochre_froglight
setblock 195 292 596 minecraft:ochre_froglight
setblock 195 292 598 minecraft:ochre_froglight
fill 196 292 557 197 292 557 minecraft:ochre_froglight
setblock 196 292 591 minecraft:ochre_froglight
setblock 196 292 593 minecraft:ochre_froglight
setblock 196 292 595 minecraft:ochre_froglight
setblock 196 292 597 minecraft:ochre_froglight
setblock 197 292 590 minecraft:ochre_froglight
setblock 197 292 592 minecraft:ochre_froglight
setblock 197 292 594 minecraft:ochre_froglight
setblock 197 292 596 minecraft:ochre_froglight
setblock 197 292 598 minecraft:ochre_froglight
fill 198 292 557 198 307 557 minecraft:gold_block
setblock 198 292 591 minecraft:ochre_froglight
setblock 198 292 593 minecraft:ochre_froglight
setblock 198 292 595 minecraft:ochre_froglight
setblock 198 292 597 minecraft:ochre_froglight
setblock 199 292 590 minecraft:ochre_froglight
setblock 199 292 592 minecraft:ochre_froglight
setblock 199 292 594 minecraft:ochre_froglight
setblock 199 292 596 minecraft:ochre_froglight
setblock 199 292 598 minecraft:ochre_froglight
setblock 200 292 591 minecraft:ochre_froglight
setblock 200 292 593 minecraft:ochre_froglight
setblock 200 292 595 minecraft:ochre_froglight
setblock 200 292 597 minecraft:ochre_froglight
fill 200 292 599 200 307 599 minecraft:gold_block
setblock 201 292 590 minecraft:ochre_froglight
setblock 201 292 592 minecraft:ochre_froglight
setblock 201 292 594 minecraft:ochre_froglight
setblock 201 292 596 minecraft:ochre_froglight
fill 201 292 598 201 292 599 minecraft:ochre_froglight
setblock 202 292 591 minecraft:ochre_froglight
setblock 202 292 593 minecraft:ochre_froglight
setblock 202 292 595 minecraft:ochre_froglight
setblock 202 292 597 minecraft:ochre_froglight
setblock 202 292 599 minecraft:ochre_froglight
setblock 203 292 590 minecraft:ochre_froglight
setblock 203 292 592 minecraft:ochre_froglight
setblock 203 292 594 minecraft:ochre_froglight
setblock 203 292 596 minecraft:ochre_froglight
setblock 203 292 598 minecraft:ochre_froglight
fill 203 292 599 203 307 599 minecraft:gold_block
setblock 204 292 591 minecraft:ochre_froglight
setblock 204 292 593 minecraft:ochre_froglight
setblock 204 292 595 minecraft:ochre_froglight
setblock 204 292 597 minecraft:ochre_froglight
setblock 205 292 590 minecraft:ochre_froglight
setblock 205 292 592 minecraft:ochre_froglight
setblock 205 292 594 minecraft:ochre_froglight
setblock 205 292 596 minecraft:ochre_froglight
setblock 205 292 598 minecraft:ochre_froglight
fill 207 292 557 207 307 557 minecraft:gold_block
fill 208 292 557 209 292 557 minecraft:ochre_froglight
fill 210 292 557 210 307 557 minecraft:gold_block
fill 212 292 599 212 307 599 minecraft:gold_block
fill 213 292 599 214 292 599 minecraft:ochre_froglight
fill 215 292 599 215 307 599 minecraft:gold_block
fill 219 292 557 219 307 557 minecraft:gold_block
fill 220 292 557 221 292 557 minecraft:ochre_froglight
fill 222 292 557 222 307 557 minecraft:gold_block
fill 224 292 599 224 307 599 minecraft:gold_block
fill 225 292 599 226 292 599 minecraft:ochre_froglight
fill 227 292 599 227 307 599 minecraft:gold_block
fill 230 292 558 230 307 558 minecraft:gold_block
fill 230 292 559 230 292 560 minecraft:ochre_froglight
fill 230 292 561 230 307 561 minecraft:gold_block
fill 230 292 570 230 307 570 minecraft:gold_block
fill 230 292 571 230 292 572 minecraft:ochre_froglight
fill 230 292 573 230 307 573 minecraft:gold_block
fill 230 292 582 230 307 582 minecraft:gold_block
fill 230 292 583 230 292 584 minecraft:ochre_froglight
fill 230 292 585 230 307 585 minecraft:gold_block
fill 230 292 594 230 307 594 minecraft:gold_block
fill 230 292 595 230 292 596 minecraft:ochre_froglight
fill 230 292 597 230 307 597 minecraft:gold_block
fill 188 293 564 188 307 565 minecraft:gold_block
fill 188 293 576 188 307 577 minecraft:gold_block
fill 188 293 588 188 307 589 minecraft:gold_block
fill 189 293 562 189 294 562 minecraft:quartz_block
fill 189 293 564 189 294 564 minecraft:quartz_block
fill 189 293 566 189 294 566 minecraft:quartz_block
fill 189 293 568 189 294 568 minecraft:quartz_block
fill 189 293 570 189 294 570 minecraft:quartz_block
fill 189 293 572 189 294 572 minecraft:quartz_block
fill 189 293 599 190 307 599 minecraft:gold_block
fill 190 293 561 190 294 561 minecraft:quartz_block
fill 190 293 563 190 294 563 minecraft:quartz_block
fill 190 293 565 190 294 565 minecraft:quartz_block
fill 190 293 567 190 294 567 minecraft:quartz_block
fill 190 293 569 190 294 569 minecraft:quartz_block
fill 190 293 571 190 294 571 minecraft:quartz_block
fill 190 293 573 190 294 573 minecraft:quartz_block
fill 191 293 562 191 294 562 minecraft:quartz_block
fill 191 293 564 191 294 564 minecraft:quartz_block
fill 191 293 566 191 294 566 minecraft:quartz_block
fill 191 293 568 191 294 568 minecraft:quartz_block
fill 191 293 570 191 294 570 minecraft:quartz_block
fill 191 293 572 191 294 572 minecraft:quartz_block
fill 192 293 561 192 294 561 minecraft:quartz_block
fill 192 293 563 192 294 563 minecraft:quartz_block
fill 192 293 565 192 294 565 minecraft:quartz_block
fill 192 293 567 192 294 567 minecraft:quartz_block
fill 192 293 569 192 294 569 minecraft:quartz_block
fill 192 293 571 192 294 571 minecraft:quartz_block
fill 192 293 573 192 294 573 minecraft:quartz_block
fill 192 293 591 192 294 591 minecraft:quartz_block
fill 192 293 593 192 294 593 minecraft:quartz_block
fill 192 293 595 192 294 595 minecraft:quartz_block
fill 192 293 597 192 294 597 minecraft:quartz_block
fill 193 293 562 193 294 562 minecraft:quartz_block
fill 193 293 564 193 294 564 minecraft:quartz_block
fill 193 293 566 193 294 566 minecraft:quartz_block
fill 193 293 568 193 294 568 minecraft:quartz_block
fill 193 293 570 193 294 570 minecraft:quartz_block
fill 193 293 572 193 294 572 minecraft:quartz_block
fill 193 293 590 193 294 590 minecraft:quartz_block
fill 193 293 592 193 294 592 minecraft:quartz_block
fill 193 293 594 193 294 594 minecraft:quartz_block
fill 193 293 596 193 294 596 minecraft:quartz_block
fill 193 293 598 193 294 598 minecraft:quartz_block
fill 194 293 591 194 294 591 minecraft:quartz_block
fill 194 293 593 194 294 593 minecraft:quartz_block
fill 194 293 595 194 294 595 minecraft:quartz_block
fill 194 293 597 194 294 597 minecraft:quartz_block
fill 195 293 590 195 294 590 minecraft:quartz_block
fill 195 293 592 195 294 592 minecraft:quartz_block
fill 195 293 594 195 294 594 minecraft:quartz_block
fill 195 293 596 195 294 596 minecraft:quartz_block
fill 195 293 598 195 294 598 minecraft:quartz_block
fill 196 293 557 197 307 557 minecraft:gold_block
fill 196 293 591 196 294 591 minecraft:quartz_block
fill 196 293 593 196 294 593 minecraft:quartz_block
fill 196 293 595 196 294 595 minecraft:quartz_block
fill 196 293 597 196 294 597 minecraft:quartz_block
fill 197 293 590 197 294 590 minecraft:quartz_block
fill 197 293 592 197 294 592 minecraft:quartz_block
fill 197 293 594 197 294 594 minecraft:quartz_block
fill 197 293 596 197 294 596 minecraft:quartz_block
fill 197 293 598 197 294 598 minecraft:quartz_block
fill 198 293 591 198 294 591 minecraft:quartz_block
fill 198 293 593 198 294 593 minecraft:quartz_block
fill 198 293 595 198 294 595 minecraft:quartz_block
fill 198 293 597 198 294 597 minecraft:quartz_block
fill 199 293 590 199 294 590 minecraft:quartz_block
fill 199 293 592 199 294 592 minecraft:quartz_block
fill 199 293 594 199 294 594 minecraft:quartz_block
fill 199 293 596 199 294 596 minecraft:quartz_block
fill 199 293 598 199 294 598 minecraft:quartz_block
fill 200 293 591 200 294 591 minecraft:quartz_block
fill 200 293 593 200 294 593 minecraft:quartz_block
fill 200 293 595 200 294 595 minecraft:quartz_block
fill 200 293 597 200 294 597 minecraft:quartz_block
fill 201 293 590 201 294 590 minecraft:quartz_block
fill 201 293 592 201 294 592 minecraft:quartz_block
fill 201 293 594 201 294 594 minecraft:quartz_block
fill 201 293 596 201 294 596 minecraft:quartz_block
fill 201 293 598 201 294 598 minecraft:quartz_block
fill 201 293 599 202 307 599 minecraft:gold_block
fill 202 293 591 202 294 591 minecraft:quartz_block
fill 202 293 593 202 294 593 minecraft:quartz_block
fill 202 293 595 202 294 595 minecraft:quartz_block
fill 202 293 597 202 294 597 minecraft:quartz_block
fill 203 293 590 203 294 590 minecraft:quartz_block
fill 203 293 592 203 294 592 minecraft:quartz_block
fill 203 293 594 203 294 594 minecraft:quartz_block
fill 203 293 596 203 294 596 minecraft:quartz_block
fill 203 293 598 203 294 598 minecraft:quartz_block
fill 204 293 591 204 294 591 minecraft:quartz_block
fill 204 293 593 204 294 593 minecraft:quartz_block
fill 204 293 595 204 294 595 minecraft:quartz_block
fill 204 293 597 204 294 597 minecraft:quartz_block
fill 205 293 590 205 294 590 minecraft:quartz_block
fill 205 293 592 205 294 592 minecraft:quartz_block
fill 205 293 594 205 294 594 minecraft:quartz_block
fill 205 293 596 205 294 596 minecraft:quartz_block
fill 205 293 598 205 294 598 minecraft:quartz_block
fill 208 293 557 209 307 557 minecraft:gold_block
fill 213 293 599 214 307 599 minecraft:gold_block
fill 220 293 557 221 307 557 minecraft:gold_block
fill 225 293 599 226 307 599 minecraft:gold_block
fill 230 293 559 230 307 560 minecraft:gold_block
fill 230 293 571 230 307 572 minecraft:gold_block
fill 230 293 583 230 307 584 minecraft:gold_block
fill 230 293 595 230 307 596 minecraft:gold_block
fill 204 294 558 206 295 558 minecraft:quartz_block
fill 206 294 597 206 295 598 minecraft:quartz_block
setblock 189 295 562 minecraft:ochre_froglight
setblock 189 295 564 minecraft:ochre_froglight
setblock 189 295 566 minecraft:ochre_froglight
setblock 189 295 568 minecraft:ochre_froglight
setblock 189 295 570 minecraft:ochre_froglight
setblock 189 295 572 minecraft:ochre_froglight
setblock 190 295 561 minecraft:ochre_froglight
setblock 190 295 563 minecraft:ochre_froglight
setblock 190 295 565 minecraft:ochre_froglight
setblock 190 295 567 minecraft:ochre_froglight
setblock 190 295 569 minecraft:ochre_froglight
setblock 190 295 571 minecraft:ochre_froglight
setblock 190 295 573 minecraft:ochre_froglight
setblock 191 295 562 minecraft:ochre_froglight
setblock 191 295 564 minecraft:ochre_froglight
setblock 191 295 566 minecraft:ochre_froglight
setblock 191 295 568 minecraft:ochre_froglight
setblock 191 295 570 minecraft:ochre_froglight
setblock 191 295 572 minecraft:ochre_froglight
setblock 192 295 561 minecraft:ochre_froglight
setblock 192 295 563 minecraft:ochre_froglight
setblock 192 295 565 minecraft:ochre_froglight
setblock 192 295 567 minecraft:ochre_froglight
setblock 192 295 569 minecraft:ochre_froglight
setblock 192 295 571 minecraft:ochre_froglight
setblock 192 295 573 minecraft:ochre_froglight
setblock 192 295 591 minecraft:ochre_froglight
setblock 192 295 593 minecraft:ochre_froglight
setblock 192 295 595 minecraft:ochre_froglight
setblock 192 295 597 minecraft:ochre_froglight
setblock 193 295 562 minecraft:ochre_froglight
setblock 193 295 564 minecraft:ochre_froglight
setblock 193 295 566 minecraft:ochre_froglight
setblock 193 295 568 minecraft:ochre_froglight
setblock 193 295 570 minecraft:ochre_froglight
setblock 193 295 572 minecraft:ochre_froglight
setblock 193 295 590 minecraft:ochre_froglight
setblock 193 295 592 minecraft:ochre_froglight
setblock 193 295 594 minecraft:ochre_froglight
setblock 193 295 596 minecraft:ochre_froglight
setblock 193 295 598 minecraft:ochre_froglight
setblock 194 295 591 minecraft:ochre_froglight
setblock 194 295 593 minecraft:ochre_froglight
setblock 194 295 595 minecraft:ochre_froglight
setblock 194 295 597 minecraft:ochre_froglight
setblock 195 295 590 minecraft:ochre_froglight
setblock 195 295 592 minecraft:ochre_froglight
setblock 195 295 594 minecraft:ochre_froglight
setblock 195 295 596 minecraft:ochre_froglight
setblock 195 295 598 minecraft:ochre_froglight
setblock 196 295 591 minecraft:ochre_froglight
setblock 196 295 593 minecraft:ochre_froglight
setblock 196 295 595 minecraft:ochre_froglight
setblock 196 295 597 minecraft:ochre_froglight
setblock 197 295 590 minecraft:ochre_froglight
setblock 197 295 592 minecraft:ochre_froglight
setblock 197 295 594 minecraft:ochre_froglight
setblock 197 295 596 minecraft:ochre_froglight
setblock 197 295 598 minecraft:ochre_froglight
setblock 198 295 591 minecraft:ochre_froglight
setblock 198 295 593 minecraft:ochre_froglight
setblock 198 295 595 minecraft:ochre_froglight
setblock 198 295 597 minecraft:ochre_froglight
setblock 199 295 590 minecraft:ochre_froglight
setblock 199 295 592 minecraft:ochre_froglight
setblock 199 295 594 minecraft:ochre_froglight
setblock 199 295 596 minecraft:ochre_froglight
setblock 199 295 598 minecraft:ochre_froglight
setblock 200 295 591 minecraft:ochre_froglight
setblock 200 295 593 minecraft:ochre_froglight
setblock 200 295 595 minecraft:ochre_froglight
setblock 200 295 597 minecraft:ochre_froglight
setblock 201 295 590 minecraft:ochre_froglight
setblock 201 295 592 minecraft:ochre_froglight
setblock 201 295 594 minecraft:ochre_froglight
setblock 201 295 596 minecraft:ochre_froglight
setblock 201 295 598 minecraft:ochre_froglight
setblock 202 295 591 minecraft:ochre_froglight
setblock 202 295 593 minecraft:ochre_froglight
setblock 202 295 595 minecraft:ochre_froglight
setblock 202 295 597 minecraft:ochre_froglight
setblock 203 295 590 minecraft:ochre_froglight
setblock 203 295 592 minecraft:ochre_froglight
setblock 203 295 594 minecraft:ochre_froglight
setblock 203 295 596 minecraft:ochre_froglight
setblock 203 295 598 minecraft:ochre_froglight
fill 204 295 559 206 296 559 minecraft:quartz_block
setblock 204 295 591 minecraft:ochre_froglight
setblock 204 295 593 minecraft:ochre_froglight
setblock 204 295 595 minecraft:ochre_froglight
setblock 204 295 597 minecraft:ochre_froglight
fill 205 295 560 205 298 560 minecraft:quartz_block
setblock 205 295 590 minecraft:ochre_froglight
setblock 205 295 592 minecraft:ochre_froglight
setblock 205 295 594 minecraft:ochre_froglight
setblock 205 295 596 minecraft:ochre_froglight
setblock 205 295 598 minecraft:ochre_froglight
fill 206 295 596 206 296 596 minecraft:quartz_block
fill 189 296 562 189 297 562 minecraft:quartz_block
fill 189 296 564 189 297 564 minecraft:quartz_block
fill 189 296 566 189 297 566 minecraft:quartz_block
fill 189 296 568 189 297 568 minecraft:quartz_block
fill 189 296 570 189 297 570 minecraft:quartz_block
fill 189 296 572 189 297 572 minecraft:quartz_block
fill 190 296 561 190 297 561 minecraft:quartz_block
fill 190 296 563 190 297 563 minecraft:quartz_block
fill 190 296 565 190 297 565 minecraft:quartz_block
fill 190 296 567 190 297 567 minecraft:quartz_block
fill 190 296 569 190 297 569 minecraft:quartz_block
fill 190 296 571 190 297 571 minecraft:quartz_block
fill 190 296 573 190 297 573 minecraft:quartz_block
fill 191 296 562 191 297 562 minecraft:quartz_block
fill 191 296 564 191 297 564 minecraft:quartz_block
fill 191 296 566 191 297 566 minecraft:quartz_block
fill 191 296 568 191 297 568 minecraft:quartz_block
fill 191 296 570 191 297 570 minecraft:quartz_block
fill 191 296 572 191 297 572 minecraft:quartz_block
fill 192 296 561 192 297 561 minecraft:quartz_block
fill 192 296 563 192 297 563 minecraft:quartz_block
fill 192 296 565 192 297 565 minecraft:quartz_block
fill 192 296 567 192 297 567 minecraft:quartz_block
fill 192 296 569 192 297 569 minecraft:quartz_block
fill 192 296 571 192 297 571 minecraft:quartz_block
fill 192 296 573 192 297 573 minecraft:quartz_block
fill 192 296 591 192 297 591 minecraft:quartz_block
fill 192 296 593 192 297 593 minecraft:quartz_block
fill 192 296 595 192 297 595 minecraft:quartz_block
fill 192 296 597 192 297 597 minecraft:quartz_block
fill 193 296 562 193 297 562 minecraft:quartz_block
fill 193 296 564 193 297 564 minecraft:quartz_block
fill 193 296 566 193 297 566 minecraft:quartz_block
fill 193 296 568 193 297 568 minecraft:quartz_block
fill 193 296 570 193 297 570 minecraft:quartz_block
fill 193 296 572 193 297 572 minecraft:quartz_block
fill 193 296 590 193 297 590 minecraft:quartz_block
fill 193 296 592 193 297 592 minecraft:quartz_block
fill 193 296 594 193 297 594 minecraft:quartz_block
fill 193 296 596 193 297 596 minecraft:quartz_block
fill 193 296 598 193 297 598 minecraft:quartz_block
fill 194 296 591 194 297 591 minecraft:quartz_block
fill 194 296 593 194 297 593 minecraft:quartz_block
fill 194 296 595 194 297 595 minecraft:quartz_block
fill 194 296 597 194 297 597 minecraft:quartz_block
fill 195 296 590 195 297 590 minecraft:quartz_block
fill 195 296 592 195 297 592 minecraft:quartz_block
fill 195 296 594 195 297 594 minecraft:quartz_block
fill 195 296 596 195 297 596 minecraft:quartz_block
fill 195 296 598 195 297 598 minecraft:quartz_block
fill 196 296 591 196 297 591 minecraft:quartz_block
fill 196 296 593 196 297 593 minecraft:quartz_block
fill 196 296 595 196 297 595 minecraft:quartz_block
fill 196 296 597 196 297 597 minecraft:quartz_block
fill 197 296 590 197 297 590 minecraft:quartz_block
fill 197 296 592 197 297 592 minecraft:quartz_block
fill 197 296 594 197 297 594 minecraft:quartz_block
fill 197 296 596 197 297 596 minecraft:quartz_block
fill 197 296 598 197 297 598 minecraft:quartz_block
fill 198 296 591 198 297 591 minecraft:quartz_block
fill 198 296 593 198 297 593 minecraft:quartz_block
fill 198 296 595 198 297 595 minecraft:quartz_block
fill 198 296 597 198 297 597 minecraft:quartz_block
fill 199 296 590 199 297 590 minecraft:quartz_block
fill 199 296 592 199 297 592 minecraft:quartz_block
fill 199 296 594 199 297 594 minecraft:quartz_block
fill 199 296 596 199 297 596 minecraft:quartz_block
fill 199 296 598 199 297 598 minecraft:quartz_block
fill 200 296 591 200 297 591 minecraft:quartz_block
fill 200 296 593 200 297 593 minecraft:quartz_block
fill 200 296 595 200 297 595 minecraft:quartz_block
fill 200 296 597 200 297 597 minecraft:quartz_block
fill 201 296 590 201 297 590 minecraft:quartz_block
fill 201 296 592 201 297 592 minecraft:quartz_block
fill 201 296 594 201 297 594 minecraft:quartz_block
fill 201 296 596 201 297 596 minecraft:quartz_block
fill 201 296 598 201 297 598 minecraft:quartz_block
fill 202 296 591 202 297 591 minecraft:quartz_block
fill 202 296 593 202 297 593 minecraft:quartz_block
fill 202 296 595 202 297 595 minecraft:quartz_block
fill 202 296 597 202 297 597 minecraft:quartz_block
fill 203 296 590 203 297 590 minecraft:quartz_block
fill 203 296 592 203 297 592 minecraft:quartz_block
fill 203 296 594 203 297 594 minecraft:quartz_block
fill 203 296 596 203 297 596 minecraft:quartz_block
fill 203 296 598 203 297 598 minecraft:quartz_block
fill 204 296 560 204 297 560 minecraft:quartz_block
fill 204 296 591 204 297 591 minecraft:quartz_block
fill 204 296 593 204 297 593 minecraft:quartz_block
schedule function dropper:buildpart/136_4 1t
