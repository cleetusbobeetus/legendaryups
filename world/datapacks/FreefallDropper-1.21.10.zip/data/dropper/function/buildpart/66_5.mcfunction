setblock 320 277 306 minecraft:light[level=12]
setblock 320 277 313 minecraft:light[level=12]
fill 324 277 286 324 282 288 minecraft:light_gray_concrete
setblock 324 277 289 minecraft:sea_lantern
fill 314 278 317 314 285 317 minecraft:light_gray_concrete
fill 315 278 275 316 282 275 minecraft:light_gray_concrete
setblock 317 278 275 minecraft:sea_lantern
fill 318 278 275 318 282 275 minecraft:light_gray_concrete
fill 324 278 289 324 282 289 minecraft:light_gray_concrete
fill 283 279 276 323 279 277 minecraft:gray_concrete
setblock 283 279 278 minecraft:yellow_concrete
fill 283 279 279 283 279 283 minecraft:gray_concrete
setblock 283 279 284 minecraft:yellow_concrete
fill 283 279 285 283 279 289 minecraft:gray_concrete
setblock 283 279 290 minecraft:yellow_concrete
fill 283 279 291 283 279 295 minecraft:gray_concrete
setblock 283 279 296 minecraft:yellow_concrete
fill 283 279 297 283 279 301 minecraft:gray_concrete
setblock 283 279 302 minecraft:yellow_concrete
fill 283 279 303 283 279 307 minecraft:gray_concrete
setblock 283 279 308 minecraft:yellow_concrete
fill 283 279 309 283 279 313 minecraft:gray_concrete
setblock 283 279 314 minecraft:yellow_concrete
fill 283 279 315 323 279 316 minecraft:gray_concrete
fill 284 279 278 284 279 280 minecraft:gray_concrete
setblock 284 279 281 minecraft:yellow_concrete
fill 284 279 282 284 279 286 minecraft:gray_concrete
setblock 284 279 287 minecraft:yellow_concrete
fill 284 279 288 284 279 292 minecraft:gray_concrete
setblock 284 279 293 minecraft:yellow_concrete
fill 284 279 294 284 279 298 minecraft:gray_concrete
setblock 284 279 299 minecraft:yellow_concrete
fill 284 279 300 284 279 304 minecraft:gray_concrete
setblock 284 279 305 minecraft:yellow_concrete
fill 284 279 306 284 279 310 minecraft:gray_concrete
setblock 284 279 311 minecraft:yellow_concrete
fill 284 279 312 284 279 314 minecraft:gray_concrete
setblock 285 279 278 minecraft:yellow_concrete
fill 285 279 279 285 279 283 minecraft:gray_concrete
setblock 285 279 284 minecraft:yellow_concrete
fill 285 279 285 285 279 289 minecraft:gray_concrete
setblock 285 279 290 minecraft:yellow_concrete
fill 285 279 291 285 279 295 minecraft:gray_concrete
setblock 285 279 296 minecraft:yellow_concrete
fill 285 279 297 285 279 301 minecraft:gray_concrete
setblock 285 279 302 minecraft:yellow_concrete
fill 285 279 303 285 279 307 minecraft:gray_concrete
setblock 285 279 308 minecraft:yellow_concrete
fill 285 279 309 285 279 313 minecraft:gray_concrete
setblock 285 279 314 minecraft:yellow_concrete
fill 286 279 278 286 279 280 minecraft:gray_concrete
setblock 286 279 281 minecraft:yellow_concrete
fill 286 279 282 286 279 286 minecraft:gray_concrete
setblock 286 279 287 minecraft:yellow_concrete
fill 286 279 288 286 279 292 minecraft:gray_concrete
setblock 286 279 293 minecraft:yellow_concrete
fill 286 279 294 286 279 298 minecraft:gray_concrete
setblock 286 279 299 minecraft:yellow_concrete
fill 286 279 300 286 279 304 minecraft:gray_concrete
setblock 286 279 305 minecraft:yellow_concrete
fill 286 279 306 286 279 310 minecraft:gray_concrete
setblock 286 279 311 minecraft:yellow_concrete
fill 286 279 312 286 279 314 minecraft:gray_concrete
setblock 287 279 278 minecraft:yellow_concrete
fill 287 279 279 287 279 283 minecraft:gray_concrete
setblock 287 279 284 minecraft:yellow_concrete
fill 287 279 285 287 279 289 minecraft:gray_concrete
setblock 287 279 290 minecraft:yellow_concrete
fill 287 279 291 287 279 295 minecraft:gray_concrete
setblock 287 279 296 minecraft:yellow_concrete
fill 287 279 297 287 279 301 minecraft:gray_concrete
setblock 287 279 302 minecraft:yellow_concrete
fill 287 279 303 287 279 307 minecraft:gray_concrete
setblock 287 279 308 minecraft:yellow_concrete
fill 287 279 309 287 279 313 minecraft:gray_concrete
setblock 287 279 314 minecraft:yellow_concrete
fill 288 279 278 288 279 280 minecraft:gray_concrete
setblock 288 279 281 minecraft:yellow_concrete
fill 288 279 282 288 279 286 minecraft:gray_concrete
setblock 288 279 287 minecraft:yellow_concrete
fill 288 279 288 288 279 292 minecraft:gray_concrete
setblock 288 279 293 minecraft:yellow_concrete
fill 288 279 294 288 279 298 minecraft:gray_concrete
setblock 288 279 299 minecraft:yellow_concrete
fill 288 279 300 288 279 304 minecraft:gray_concrete
setblock 288 279 305 minecraft:yellow_concrete
fill 288 279 306 288 279 310 minecraft:gray_concrete
setblock 288 279 311 minecraft:yellow_concrete
fill 288 279 312 288 279 314 minecraft:gray_concrete
setblock 289 279 278 minecraft:yellow_concrete
fill 289 279 279 289 279 283 minecraft:gray_concrete
setblock 289 279 284 minecraft:yellow_concrete
fill 289 279 285 289 279 289 minecraft:gray_concrete
setblock 289 279 290 minecraft:yellow_concrete
fill 289 279 291 289 279 295 minecraft:gray_concrete
setblock 289 279 296 minecraft:yellow_concrete
fill 289 279 297 289 279 301 minecraft:gray_concrete
setblock 289 279 302 minecraft:yellow_concrete
fill 289 279 303 289 279 307 minecraft:gray_concrete
setblock 289 279 308 minecraft:yellow_concrete
fill 289 279 309 289 279 313 minecraft:gray_concrete
setblock 289 279 314 minecraft:yellow_concrete
fill 290 279 278 290 279 280 minecraft:gray_concrete
setblock 290 279 281 minecraft:yellow_concrete
fill 290 279 282 290 279 286 minecraft:gray_concrete
setblock 290 279 287 minecraft:yellow_concrete
fill 290 279 288 290 279 292 minecraft:gray_concrete
setblock 290 279 293 minecraft:yellow_concrete
fill 290 279 294 290 279 298 minecraft:gray_concrete
setblock 290 279 299 minecraft:yellow_concrete
fill 290 279 300 290 279 304 minecraft:gray_concrete
setblock 290 279 305 minecraft:yellow_concrete
fill 290 279 306 290 279 310 minecraft:gray_concrete
setblock 290 279 311 minecraft:yellow_concrete
fill 290 279 312 290 279 314 minecraft:gray_concrete
setblock 291 279 278 minecraft:yellow_concrete
fill 291 279 279 291 279 283 minecraft:gray_concrete
setblock 291 279 284 minecraft:yellow_concrete
fill 291 279 285 291 279 289 minecraft:gray_concrete
setblock 291 279 290 minecraft:yellow_concrete
fill 291 279 291 291 279 295 minecraft:gray_concrete
setblock 291 279 296 minecraft:yellow_concrete
fill 291 279 297 291 279 301 minecraft:gray_concrete
setblock 291 279 302 minecraft:yellow_concrete
fill 291 279 303 291 279 307 minecraft:gray_concrete
setblock 291 279 308 minecraft:yellow_concrete
fill 291 279 309 291 279 313 minecraft:gray_concrete
setblock 291 279 314 minecraft:yellow_concrete
fill 292 279 278 292 279 280 minecraft:gray_concrete
setblock 292 279 281 minecraft:yellow_concrete
fill 292 279 282 292 279 284 minecraft:gray_concrete
fill 292 279 285 294 279 306 minecraft:iron_block
fill 292 279 307 292 279 310 minecraft:gray_concrete
setblock 292 279 311 minecraft:yellow_concrete
fill 292 279 312 292 279 314 minecraft:gray_concrete
setblock 293 279 278 minecraft:yellow_concrete
fill 293 279 279 293 279 283 minecraft:gray_concrete
setblock 293 279 284 minecraft:yellow_concrete
fill 293 279 307 323 279 307 minecraft:gray_concrete
setblock 293 279 308 minecraft:yellow_concrete
fill 293 279 309 293 279 313 minecraft:gray_concrete
setblock 293 279 314 minecraft:yellow_concrete
fill 294 279 278 294 279 280 minecraft:gray_concrete
setblock 294 279 281 minecraft:yellow_concrete
fill 294 279 282 294 279 284 minecraft:gray_concrete
fill 294 279 308 294 279 310 minecraft:gray_concrete
setblock 294 279 311 minecraft:yellow_concrete
fill 294 279 312 294 279 314 minecraft:gray_concrete
setblock 295 279 278 minecraft:yellow_concrete
fill 295 279 279 295 279 283 minecraft:gray_concrete
setblock 295 279 284 minecraft:yellow_concrete
fill 295 279 285 295 279 299 minecraft:iron_block
fill 295 279 300 295 279 302 minecraft:redstone_block
fill 295 279 303 295 279 306 minecraft:iron_block
setblock 295 279 308 minecraft:yellow_concrete
fill 295 279 309 295 279 313 minecraft:gray_concrete
setblock 295 279 314 minecraft:yellow_concrete
fill 296 279 278 296 279 280 minecraft:gray_concrete
setblock 296 279 281 minecraft:yellow_concrete
fill 296 279 282 296 279 284 minecraft:gray_concrete
fill 296 279 285 296 279 298 minecraft:iron_block
fill 296 279 299 296 279 300 minecraft:redstone_block
fill 296 279 301 298 279 301 minecraft:white_concrete
fill 296 279 302 296 279 303 minecraft:redstone_block
fill 296 279 304 313 279 306 minecraft:iron_block
fill 296 279 308 296 279 310 minecraft:gray_concrete
setblock 296 279 311 minecraft:yellow_concrete
fill 296 279 312 296 279 314 minecraft:gray_concrete
setblock 297 279 278 minecraft:yellow_concrete
fill 297 279 279 297 279 283 minecraft:gray_concrete
setblock 297 279 284 minecraft:yellow_concrete
fill 297 279 285 297 279 293 minecraft:iron_block
fill 297 279 294 297 279 296 minecraft:lime_concrete
fill 297 279 297 297 279 298 minecraft:iron_block
fill 297 279 299 298 279 299 minecraft:redstone_block
setblock 297 279 300 minecraft:white_concrete
setblock 297 279 302 minecraft:white_concrete
fill 297 279 303 298 279 303 minecraft:redstone_block
setblock 297 279 308 minecraft:yellow_concrete
fill 297 279 309 297 279 313 minecraft:gray_concrete
setblock 297 279 314 minecraft:yellow_concrete
fill 298 279 278 298 279 280 minecraft:gray_concrete
setblock 298 279 281 minecraft:yellow_concrete
fill 298 279 282 298 279 284 minecraft:gray_concrete
fill 298 279 285 313 279 287 minecraft:iron_block
fill 298 279 288 298 279 290 minecraft:black_concrete
fill 298 279 291 299 279 291 minecraft:iron_block
fill 298 279 292 298 279 294 minecraft:lime_concrete
fill 298 279 296 298 279 298 minecraft:lime_concrete
fill 298 279 300 299 279 300 minecraft:redstone_block
fill 298 279 302 299 279 302 minecraft:redstone_block
fill 298 279 308 298 279 310 minecraft:gray_concrete
setblock 298 279 311 minecraft:yellow_concrete
fill 298 279 312 298 279 314 minecraft:gray_concrete
setblock 299 279 278 minecraft:yellow_concrete
fill 299 279 279 299 279 283 minecraft:gray_concrete
setblock 299 279 284 minecraft:yellow_concrete
fill 299 279 288 299 279 290 minecraft:iron_block
fill 299 279 292 300 279 292 minecraft:lime_concrete
fill 299 279 298 300 279 298 minecraft:lime_concrete
setblock 299 279 299 minecraft:iron_block
setblock 299 279 301 minecraft:redstone_block
fill 299 279 303 307 279 303 minecraft:iron_block
setblock 299 279 308 minecraft:yellow_concrete
fill 299 279 309 299 279 313 minecraft:gray_concrete
setblock 299 279 314 minecraft:yellow_concrete
fill 300 279 278 300 279 280 minecraft:gray_concrete
setblock 300 279 281 minecraft:yellow_concrete
fill 300 279 282 300 279 284 minecraft:gray_concrete
fill 300 279 288 300 279 290 minecraft:black_concrete
fill 300 279 291 302 279 291 minecraft:lime_concrete
fill 300 279 299 302 279 299 minecraft:lime_concrete
fill 300 279 300 306 279 302 minecraft:iron_block
fill 300 279 308 300 279 310 minecraft:gray_concrete
setblock 300 279 311 minecraft:yellow_concrete
fill 300 279 312 300 279 314 minecraft:gray_concrete
setblock 301 279 278 minecraft:yellow_concrete
fill 301 279 279 301 279 283 minecraft:gray_concrete
setblock 301 279 284 minecraft:yellow_concrete
fill 301 279 288 301 279 290 minecraft:iron_block
setblock 301 279 308 minecraft:yellow_concrete
fill 301 279 309 301 279 313 minecraft:gray_concrete
setblock 301 279 314 minecraft:yellow_concrete
fill 302 279 278 302 279 280 minecraft:gray_concrete
setblock 302 279 281 minecraft:yellow_concrete
fill 302 279 282 302 279 284 minecraft:gray_concrete
fill 302 279 288 302 279 290 minecraft:black_concrete
fill 302 279 292 304 279 292 minecraft:lime_concrete
fill 302 279 298 304 279 298 minecraft:lime_concrete
fill 302 279 308 302 279 310 minecraft:gray_concrete
setblock 302 279 311 minecraft:yellow_concrete
fill 302 279 312 302 279 314 minecraft:gray_concrete
setblock 303 279 278 minecraft:yellow_concrete
fill 303 279 279 303 279 283 minecraft:gray_concrete
setblock 303 279 284 minecraft:yellow_concrete
fill 303 279 288 303 279 291 minecraft:iron_block
fill 303 279 299 307 279 299 minecraft:iron_block
setblock 303 279 308 minecraft:yellow_concrete
fill 303 279 309 303 279 313 minecraft:gray_concrete
setblock 303 279 314 minecraft:yellow_concrete
fill 304 279 278 304 279 280 minecraft:gray_concrete
setblock 304 279 281 minecraft:yellow_concrete
fill 304 279 282 304 279 284 minecraft:gray_concrete
fill 304 279 288 304 279 290 minecraft:black_concrete
fill 304 279 291 313 279 291 minecraft:iron_block
fill 304 279 293 304 279 294 minecraft:lime_concrete
fill 304 279 296 304 279 297 minecraft:lime_concrete
fill 304 279 308 304 279 310 minecraft:gray_concrete
setblock 304 279 311 minecraft:yellow_concrete
fill 304 279 312 304 279 314 minecraft:gray_concrete
setblock 305 279 278 minecraft:yellow_concrete
fill 305 279 279 305 279 283 minecraft:gray_concrete
setblock 305 279 284 minecraft:yellow_concrete
fill 305 279 288 305 279 290 minecraft:iron_block
fill 305 279 292 313 279 293 minecraft:iron_block
fill 305 279 294 305 279 296 minecraft:lime_concrete
fill 305 279 297 313 279 298 minecraft:iron_block
setblock 305 279 308 minecraft:yellow_concrete
fill 305 279 309 305 279 313 minecraft:gray_concrete
setblock 305 279 314 minecraft:yellow_concrete
fill 306 279 278 306 279 280 minecraft:gray_concrete
setblock 306 279 281 minecraft:yellow_concrete
fill 306 279 282 306 279 284 minecraft:gray_concrete
fill 306 279 288 306 279 290 minecraft:black_concrete
fill 306 279 294 313 279 296 minecraft:iron_block
fill 306 279 308 306 279 310 minecraft:gray_concrete
setblock 306 279 311 minecraft:yellow_concrete
fill 306 279 312 306 279 314 minecraft:gray_concrete
setblock 307 279 278 minecraft:yellow_concrete
fill 307 279 279 307 279 283 minecraft:gray_concrete
setblock 307 279 284 minecraft:yellow_concrete
fill 307 279 288 307 279 290 minecraft:iron_block
fill 307 279 300 307 279 302 minecraft:redstone_block
setblock 307 279 308 minecraft:yellow_concrete
fill 307 279 309 307 279 313 minecraft:gray_concrete
setblock 307 279 314 minecraft:yellow_concrete
fill 308 279 278 308 279 280 minecraft:gray_concrete
setblock 308 279 281 minecraft:yellow_concrete
fill 308 279 282 308 279 284 minecraft:gray_concrete
fill 308 279 288 308 279 290 minecraft:black_concrete
fill 308 279 299 308 279 300 minecraft:redstone_block
fill 308 279 301 310 279 301 minecraft:white_concrete
fill 308 279 302 308 279 303 minecraft:redstone_block
fill 308 279 308 308 279 310 minecraft:gray_concrete
setblock 308 279 311 minecraft:yellow_concrete
fill 308 279 312 308 279 314 minecraft:gray_concrete
setblock 309 279 278 minecraft:yellow_concrete
fill 309 279 279 309 279 283 minecraft:gray_concrete
setblock 309 279 284 minecraft:yellow_concrete
fill 309 279 288 313 279 290 minecraft:iron_block
fill 309 279 299 310 279 299 minecraft:redstone_block
setblock 309 279 300 minecraft:white_concrete
setblock 309 279 302 minecraft:white_concrete
fill 309 279 303 310 279 303 minecraft:redstone_block
setblock 309 279 308 minecraft:yellow_concrete
fill 309 279 309 309 279 313 minecraft:gray_concrete
setblock 309 279 314 minecraft:yellow_concrete
fill 310 279 278 310 279 280 minecraft:gray_concrete
setblock 310 279 281 minecraft:yellow_concrete
fill 310 279 282 310 279 284 minecraft:gray_concrete
fill 310 279 300 311 279 300 minecraft:redstone_block
fill 310 279 302 311 279 302 minecraft:redstone_block
fill 310 279 308 310 279 310 minecraft:gray_concrete
setblock 310 279 311 minecraft:yellow_concrete
fill 310 279 312 310 279 314 minecraft:gray_concrete
setblock 311 279 278 minecraft:yellow_concrete
fill 311 279 279 311 279 283 minecraft:gray_concrete
setblock 311 279 284 minecraft:yellow_concrete
fill 311 279 299 313 279 299 minecraft:iron_block
setblock 311 279 301 minecraft:redstone_block
fill 311 279 303 313 279 303 minecraft:iron_block
setblock 311 279 308 minecraft:yellow_concrete
fill 311 279 309 311 279 313 minecraft:gray_concrete
setblock 311 279 314 minecraft:yellow_concrete
fill 312 279 278 312 279 280 minecraft:gray_concrete
setblock 312 279 281 minecraft:yellow_concrete
fill 312 279 282 312 279 284 minecraft:gray_concrete
fill 312 279 300 313 279 302 minecraft:iron_block
fill 312 279 308 312 279 310 minecraft:gray_concrete
setblock 312 279 311 minecraft:yellow_concrete
fill 312 279 312 312 279 314 minecraft:gray_concrete
setblock 313 279 278 minecraft:yellow_concrete
fill 313 279 279 313 279 283 minecraft:gray_concrete
setblock 313 279 284 minecraft:yellow_concrete
setblock 313 279 308 minecraft:yellow_concrete
fill 313 279 309 313 279 313 minecraft:gray_concrete
setblock 313 279 314 minecraft:yellow_concrete
fill 314 279 278 314 279 280 minecraft:gray_concrete
setblock 314 279 281 minecraft:yellow_concrete
fill 314 279 282 314 279 286 minecraft:gray_concrete
setblock 314 279 287 minecraft:yellow_concrete
fill 314 279 288 314 279 292 minecraft:gray_concrete
setblock 314 279 293 minecraft:yellow_concrete
fill 314 279 294 314 279 298 minecraft:gray_concrete
setblock 314 279 299 minecraft:yellow_concrete
fill 314 279 300 314 279 304 minecraft:gray_concrete
setblock 314 279 305 minecraft:yellow_concrete
fill 314 279 306 323 279 306 minecraft:gray_concrete
fill 314 279 308 314 279 310 minecraft:gray_concrete
setblock 314 279 311 minecraft:yellow_concrete
fill 314 279 312 314 279 314 minecraft:gray_concrete
setblock 315 279 278 minecraft:yellow_concrete
fill 315 279 279 315 279 283 minecraft:gray_concrete
setblock 315 279 284 minecraft:yellow_concrete
fill 315 279 285 315 279 289 minecraft:gray_concrete
setblock 315 279 290 minecraft:yellow_concrete
fill 315 279 291 315 279 295 minecraft:gray_concrete
setblock 315 279 296 minecraft:yellow_concrete
fill 315 279 297 315 279 301 minecraft:gray_concrete
setblock 315 279 302 minecraft:yellow_concrete
fill 315 279 303 315 279 305 minecraft:gray_concrete
setblock 315 279 308 minecraft:yellow_concrete
fill 315 279 309 315 279 313 minecraft:gray_concrete
setblock 315 279 314 minecraft:yellow_concrete
fill 316 279 278 316 279 280 minecraft:gray_concrete
setblock 316 279 281 minecraft:yellow_concrete
fill 316 279 282 316 279 286 minecraft:gray_concrete
setblock 316 279 287 minecraft:yellow_concrete
fill 316 279 288 316 279 292 minecraft:gray_concrete
setblock 316 279 293 minecraft:yellow_concrete
fill 316 279 294 316 279 298 minecraft:gray_concrete
setblock 316 279 299 minecraft:yellow_concrete
fill 316 279 300 316 279 304 minecraft:gray_concrete
setblock 316 279 305 minecraft:yellow_concrete
fill 316 279 308 316 279 310 minecraft:gray_concrete
setblock 316 279 311 minecraft:yellow_concrete
fill 316 279 312 316 279 314 minecraft:gray_concrete
fill 317 279 275 317 282 275 minecraft:light_gray_concrete
setblock 317 279 278 minecraft:yellow_concrete
fill 317 279 279 317 279 283 minecraft:gray_concrete
setblock 317 279 284 minecraft:yellow_concrete
fill 317 279 285 317 279 289 minecraft:gray_concrete
setblock 317 279 290 minecraft:yellow_concrete
fill 317 279 291 317 279 295 minecraft:gray_concrete
setblock 317 279 296 minecraft:yellow_concrete
fill 317 279 297 317 279 301 minecraft:gray_concrete
setblock 317 279 302 minecraft:yellow_concrete
fill 317 279 303 317 279 305 minecraft:gray_concrete
setblock 317 279 308 minecraft:yellow_concrete
fill 317 279 309 317 279 313 minecraft:gray_concrete
setblock 317 279 314 minecraft:yellow_concrete
fill 318 279 278 318 279 280 minecraft:gray_concrete
setblock 318 279 281 minecraft:yellow_concrete
fill 318 279 282 318 279 286 minecraft:gray_concrete
setblock 318 279 287 minecraft:yellow_concrete
fill 318 279 288 318 279 292 minecraft:gray_concrete
setblock 318 279 293 minecraft:yellow_concrete
fill 318 279 294 318 279 298 minecraft:gray_concrete
setblock 318 279 299 minecraft:yellow_concrete
fill 318 279 300 318 279 304 minecraft:gray_concrete
setblock 318 279 305 minecraft:yellow_concrete
fill 318 279 308 318 279 310 minecraft:gray_concrete
setblock 318 279 311 minecraft:yellow_concrete
fill 318 279 312 318 279 314 minecraft:gray_concrete
setblock 319 279 278 minecraft:yellow_concrete
fill 319 279 279 319 279 283 minecraft:gray_concrete
setblock 319 279 284 minecraft:yellow_concrete
fill 319 279 285 319 279 289 minecraft:gray_concrete
setblock 319 279 290 minecraft:yellow_concrete
fill 319 279 291 319 279 295 minecraft:gray_concrete
setblock 319 279 296 minecraft:yellow_concrete
fill 319 279 297 319 279 301 minecraft:gray_concrete
setblock 319 279 302 minecraft:yellow_concrete
fill 319 279 303 319 279 305 minecraft:gray_concrete
setblock 319 279 308 minecraft:yellow_concrete
fill 319 279 309 319 279 313 minecraft:gray_concrete
setblock 319 279 314 minecraft:yellow_concrete
fill 320 279 278 320 279 280 minecraft:gray_concrete
setblock 320 279 281 minecraft:yellow_concrete
fill 320 279 282 320 279 286 minecraft:gray_concrete
setblock 320 279 287 minecraft:yellow_concrete
fill 320 279 288 320 279 292 minecraft:gray_concrete
setblock 320 279 293 minecraft:yellow_concrete
fill 320 279 294 320 279 298 minecraft:gray_concrete
setblock 320 279 299 minecraft:yellow_concrete
fill 320 279 300 320 279 304 minecraft:gray_concrete
setblock 320 279 305 minecraft:yellow_concrete
fill 320 279 308 320 279 310 minecraft:gray_concrete
setblock 320 279 311 minecraft:yellow_concrete
fill 320 279 312 320 279 314 minecraft:gray_concrete
setblock 321 279 278 minecraft:yellow_concrete
fill 321 279 279 321 279 283 minecraft:gray_concrete
setblock 321 279 284 minecraft:yellow_concrete
fill 321 279 285 321 279 289 minecraft:gray_concrete
setblock 321 279 290 minecraft:yellow_concrete
fill 321 279 291 321 279 295 minecraft:gray_concrete
setblock 321 279 296 minecraft:yellow_concrete
fill 321 279 297 321 279 301 minecraft:gray_concrete
setblock 321 279 302 minecraft:yellow_concrete
fill 321 279 303 321 279 305 minecraft:gray_concrete
setblock 321 279 308 minecraft:yellow_concrete
fill 321 279 309 321 279 313 minecraft:gray_concrete
setblock 321 279 314 minecraft:yellow_concrete
fill 322 279 278 322 279 280 minecraft:gray_concrete
setblock 322 279 281 minecraft:yellow_concrete
fill 322 279 282 322 279 286 minecraft:gray_concrete
setblock 322 279 287 minecraft:yellow_concrete
fill 322 279 288 322 279 292 minecraft:gray_concrete
setblock 322 279 293 minecraft:yellow_concrete
fill 322 279 294 322 279 298 minecraft:gray_concrete
setblock 322 279 299 minecraft:yellow_concrete
fill 322 279 300 322 279 304 minecraft:gray_concrete
setblock 322 279 305 minecraft:yellow_concrete
fill 322 279 308 322 279 310 minecraft:gray_concrete
setblock 322 279 311 minecraft:yellow_concrete
fill 322 279 312 322 279 314 minecraft:gray_concrete
setblock 323 279 278 minecraft:yellow_concrete
fill 323 279 279 323 279 283 minecraft:gray_concrete
setblock 323 279 284 minecraft:yellow_concrete
fill 323 279 285 323 279 289 minecraft:gray_concrete
setblock 323 279 290 minecraft:yellow_concrete
fill 323 279 291 323 279 295 minecraft:gray_concrete
setblock 323 279 296 minecraft:yellow_concrete
fill 323 279 297 323 279 301 minecraft:gray_concrete
setblock 323 279 302 minecraft:yellow_concrete
fill 323 279 303 323 279 305 minecraft:gray_concrete
setblock 323 279 308 minecraft:yellow_concrete
fill 323 279 309 323 279 313 minecraft:gray_concrete
setblock 323 279 314 minecraft:yellow_concrete
setblock 282 280 285 minecraft:redstone_block
fill 282 280 286 282 285 288 minecraft:light_gray_concrete
fill 282 281 285 282 285 285 minecraft:light_gray_concrete
setblock 285 281 278 minecraft:light[level=15]
setblock 285 281 286 minecraft:light[level=15]
setblock 285 281 294 minecraft:light[level=15]
setblock 285 281 302 minecraft:light[level=15]
setblock 285 281 310 minecraft:light[level=15]
setblock 293 281 278 minecraft:light[level=15]
setblock 293 281 286 minecraft:light[level=15]
setblock 293 281 294 minecraft:light[level=15]
setblock 293 281 302 minecraft:light[level=15]
setblock 293 281 310 minecraft:light[level=15]
fill 296 281 317 298 282 317 minecraft:light_gray_concrete
setblock 299 281 317 minecraft:redstone_block
setblock 301 281 278 minecraft:light[level=15]
setblock 301 281 286 minecraft:light[level=15]
setblock 301 281 302 minecraft:light[level=15]
setblock 301 281 310 minecraft:light[level=15]
setblock 309 281 278 minecraft:light[level=15]
setblock 309 281 286 minecraft:light[level=15]
setblock 309 281 294 minecraft:light[level=15]
setblock 309 281 302 minecraft:light[level=15]
setblock 309 281 310 minecraft:light[level=15]
setblock 317 281 278 minecraft:light[level=15]
setblock 317 281 286 minecraft:light[level=15]
setblock 317 281 294 minecraft:light[level=15]
setblock 317 281 302 minecraft:light[level=15]
setblock 317 281 310 minecraft:light[level=15]
setblock 299 282 317 minecraft:light_gray_concrete
setblock 324 282 276 minecraft:light_gray_concrete
setblock 324 282 277 minecraft:sea_lantern
fill 324 282 278 324 282 279 minecraft:light_gray_concrete
fill 282 283 281 282 283 284 minecraft:pearlescent_froglight
fill 282 283 291 282 283 294 minecraft:pearlescent_froglight
fill 282 283 301 282 283 304 minecraft:pearlescent_froglight
fill 282 283 311 282 283 314 minecraft:pearlescent_froglight
setblock 283 283 275 minecraft:redstone_block
fill 283 283 277 283 300 277 minecraft:iron_block
fill 283 283 287 283 300 287 minecraft:iron_block
fill 283 283 297 283 300 297 minecraft:iron_block
fill 283 283 307 283 300 307 minecraft:iron_block
fill 284 283 275 284 285 275 minecraft:light_gray_concrete
fill 284 283 316 284 300 316 minecraft:iron_block
fill 285 283 275 288 283 275 minecraft:pearlescent_froglight
setblock 285 283 278 minecraft:light[level=12]
setblock 285 283 285 minecraft:light[level=12]
setblock 285 283 292 minecraft:light[level=12]
setblock 285 283 299 minecraft:light[level=12]
setblock 285 283 306 minecraft:light[level=12]
setblock 285 283 313 minecraft:light[level=12]
fill 286 283 317 289 283 317 minecraft:pearlescent_froglight
fill 290 283 276 290 300 276 minecraft:iron_block
fill 291 283 306 299 285 316 minecraft:iron_block
setblock 292 283 278 minecraft:light[level=12]
setblock 292 283 285 minecraft:light[level=12]
setblock 292 283 292 minecraft:light[level=12]
setblock 292 283 299 minecraft:light[level=12]
fill 295 283 275 298 283 275 minecraft:pearlescent_froglight
fill 296 283 317 299 283 317 minecraft:pearlescent_froglight
setblock 299 283 278 minecraft:light[level=12]
setblock 299 283 285 minecraft:light[level=12]
setblock 299 283 292 minecraft:light[level=12]
setblock 299 283 299 minecraft:light[level=12]
fill 300 283 276 300 300 276 minecraft:iron_block
fill 304 283 316 304 300 316 minecraft:iron_block
fill 305 283 275 308 283 275 minecraft:pearlescent_froglight
fill 305 283 312 305 300 312 minecraft:iron_block
setblock 306 283 278 minecraft:light[level=12]
setblock 306 283 285 minecraft:light[level=12]
setblock 306 283 292 minecraft:light[level=12]
setblock 306 283 299 minecraft:light[level=12]
setblock 306 283 306 minecraft:light[level=12]
setblock 306 283 313 minecraft:light[level=12]
fill 306 283 317 309 283 317 minecraft:pearlescent_froglight
fill 310 283 276 310 300 276 minecraft:iron_block
setblock 313 283 278 minecraft:light[level=12]
setblock 313 283 285 minecraft:light[level=12]
setblock 313 283 292 minecraft:light[level=12]
setblock 313 283 299 minecraft:light[level=12]
setblock 313 283 306 minecraft:light[level=12]
setblock 313 283 313 minecraft:light[level=12]
fill 314 283 316 314 300 316 minecraft:iron_block
fill 315 283 275 318 283 275 minecraft:pearlescent_froglight
fill 316 283 317 319 283 317 minecraft:pearlescent_froglight
fill 317 283 291 323 285 303 minecraft:iron_block
fill 320 283 276 320 300 276 minecraft:iron_block
setblock 320 283 278 minecraft:light[level=12]
setblock 320 283 285 minecraft:light[level=12]
setblock 320 283 306 minecraft:light[level=12]
setblock 320 283 313 minecraft:light[level=12]
fill 323 283 283 323 300 283 minecraft:iron_block
fill 323 283 313 323 300 313 minecraft:iron_block
fill 324 283 276 324 283 279 minecraft:pearlescent_froglight
fill 324 283 286 324 283 289 minecraft:pearlescent_froglight
setblock 324 283 294 minecraft:redstone_block
fill 324 283 295 324 285 295 minecraft:light_gray_concrete
fill 324 283 296 324 283 299 minecraft:pearlescent_froglight
fill 324 283 306 324 283 309 minecraft:pearlescent_froglight
setblock 324 283 316 minecraft:pearlescent_froglight
fill 282 284 281 282 285 284 minecraft:light_gray_concrete
fill 282 284 291 282 285 294 minecraft:light_gray_concrete
fill 282 284 301 282 285 304 minecraft:light_gray_concrete
fill 282 284 311 282 285 314 minecraft:light_gray_concrete
fill 283 284 275 283 285 275 minecraft:light_gray_concrete
fill 285 284 275 288 285 275 minecraft:light_gray_concrete
fill 286 284 317 289 285 317 minecraft:light_gray_concrete
fill 295 284 275 298 285 275 minecraft:light_gray_concrete
fill 296 284 317 299 285 317 minecraft:light_gray_concrete
fill 302 284 278 302 297 278 minecraft:iron_block
fill 305 284 275 308 285 275 minecraft:light_gray_concrete
fill 305 284 313 305 285 315 minecraft:iron_block
fill 306 284 317 309 285 317 minecraft:light_gray_concrete
fill 315 284 275 318 285 275 minecraft:light_gray_concrete
fill 316 284 317 319 284 317 minecraft:light_gray_concrete
fill 324 284 276 324 285 279 minecraft:light_gray_concrete
fill 324 284 286 324 285 289 minecraft:light_gray_concrete
fill 324 284 294 324 285 294 minecraft:light_gray_concrete
fill 324 284 296 324 285 299 minecraft:light_gray_concrete
fill 324 284 306 324 285 309 minecraft:light_gray_concrete
fill 324 284 316 324 285 316 minecraft:light_gray_concrete
fill 304 285 311 304 285 313 minecraft:iron_block
fill 305 285 311 306 285 311 minecraft:iron_block
fill 306 285 312 306 285 313 minecraft:iron_block
setblock 316 285 317 minecraft:light_gray_concrete
setblock 317 285 317 minecraft:redstone_block
fill 318 285 317 319 285 317 minecraft:light_gray_concrete
fill 282 286 275 282 287 276 minecraft:yellow_concrete
fill 282 286 277 282 287 278 minecraft:black_concrete
fill 282 286 279 282 287 280 minecraft:yellow_concrete
fill 282 286 281 282 287 282 minecraft:black_concrete
fill 282 286 283 282 287 284 minecraft:yellow_concrete
fill 282 286 285 282 287 286 minecraft:black_concrete
fill 282 286 287 282 287 288 minecraft:yellow_concrete
fill 282 286 289 282 287 290 minecraft:black_concrete
fill 282 286 291 282 287 292 minecraft:yellow_concrete
fill 282 286 293 282 287 294 minecraft:black_concrete
fill 282 286 295 282 287 296 minecraft:yellow_concrete
fill 282 286 297 282 287 298 minecraft:black_concrete
fill 282 286 299 282 287 300 minecraft:yellow_concrete
fill 282 286 301 282 287 302 minecraft:black_concrete
fill 282 286 303 282 287 304 minecraft:yellow_concrete
fill 282 286 305 282 287 306 minecraft:black_concrete
fill 282 286 307 282 287 308 minecraft:yellow_concrete
fill 282 286 309 282 287 310 minecraft:black_concrete
fill 282 286 311 282 287 312 minecraft:yellow_concrete
fill 282 286 313 282 287 314 minecraft:black_concrete
fill 282 286 315 282 287 316 minecraft:yellow_concrete
fill 282 286 317 282 287 317 minecraft:black_concrete
fill 283 286 275 283 287 275 minecraft:yellow_concrete
fill 283 286 317 283 287 317 minecraft:yellow_concrete
fill 284 286 275 285 287 275 minecraft:black_concrete
fill 284 286 317 285 287 317 minecraft:black_concrete
fill 286 286 275 287 287 275 minecraft:yellow_concrete
fill 286 286 317 287 287 317 minecraft:yellow_concrete
fill 288 286 275 289 287 275 minecraft:black_concrete
fill 288 286 317 289 287 317 minecraft:black_concrete
fill 290 286 275 291 287 275 minecraft:yellow_concrete
fill 290 286 317 291 287 317 minecraft:yellow_concrete
setblock 291 286 306 minecraft:pearlescent_froglight
fill 291 286 307 291 299 307 minecraft:iron_block
setblock 291 286 308 minecraft:pearlescent_froglight
fill 291 286 309 291 299 309 minecraft:iron_block
setblock 291 286 310 minecraft:pearlescent_froglight
fill 291 286 311 291 299 311 minecraft:iron_block
setblock 291 286 312 minecraft:pearlescent_froglight
fill 291 286 313 291 299 313 minecraft:iron_block
setblock 291 286 314 minecraft:pearlescent_froglight
fill 291 286 315 291 299 315 minecraft:iron_block
setblock 291 286 316 minecraft:pearlescent_froglight
fill 292 286 275 293 287 275 minecraft:black_concrete
fill 292 286 306 292 299 306 minecraft:iron_block
setblock 292 286 307 minecraft:pearlescent_froglight
fill 292 286 308 292 299 308 minecraft:iron_block
setblock 292 286 309 minecraft:pearlescent_froglight
fill 292 286 310 292 299 310 minecraft:iron_block
setblock 292 286 311 minecraft:pearlescent_froglight
fill 292 286 312 292 299 312 minecraft:iron_block
setblock 292 286 313 minecraft:pearlescent_froglight
fill 292 286 314 292 299 314 minecraft:iron_block
setblock 292 286 315 minecraft:pearlescent_froglight
fill 292 286 316 292 299 316 minecraft:iron_block
fill 292 286 317 293 287 317 minecraft:black_concrete
setblock 293 286 306 minecraft:pearlescent_froglight
fill 293 286 307 293 299 307 minecraft:iron_block
setblock 293 286 308 minecraft:pearlescent_froglight
fill 293 286 309 293 299 309 minecraft:iron_block
setblock 293 286 310 minecraft:pearlescent_froglight
fill 293 286 311 293 299 311 minecraft:iron_block
setblock 293 286 312 minecraft:pearlescent_froglight
fill 293 286 313 293 299 313 minecraft:iron_block
setblock 293 286 314 minecraft:pearlescent_froglight
fill 293 286 315 293 299 315 minecraft:iron_block
setblock 293 286 316 minecraft:pearlescent_froglight
fill 294 286 275 295 287 275 minecraft:yellow_concrete
fill 294 286 306 294 299 306 minecraft:iron_block
setblock 294 286 307 minecraft:pearlescent_froglight
fill 294 286 308 294 299 308 minecraft:iron_block
setblock 294 286 309 minecraft:pearlescent_froglight
fill 294 286 310 294 299 310 minecraft:iron_block
setblock 294 286 311 minecraft:pearlescent_froglight
fill 294 286 312 294 299 312 minecraft:iron_block
setblock 294 286 313 minecraft:pearlescent_froglight
fill 294 286 314 294 299 314 minecraft:iron_block
setblock 294 286 315 minecraft:pearlescent_froglight
fill 294 286 316 294 300 316 minecraft:iron_block
fill 294 286 317 295 287 317 minecraft:yellow_concrete
setblock 295 286 306 minecraft:pearlescent_froglight
fill 295 286 307 295 299 307 minecraft:iron_block
setblock 295 286 308 minecraft:pearlescent_froglight
fill 295 286 309 295 299 309 minecraft:iron_block
setblock 295 286 310 minecraft:pearlescent_froglight
fill 295 286 311 295 299 311 minecraft:iron_block
setblock 295 286 312 minecraft:pearlescent_froglight
fill 295 286 313 295 299 313 minecraft:iron_block
setblock 295 286 314 minecraft:pearlescent_froglight
fill 295 286 315 295 299 315 minecraft:iron_block
setblock 295 286 316 minecraft:pearlescent_froglight
fill 296 286 275 297 287 275 minecraft:black_concrete
fill 296 286 306 296 299 306 minecraft:iron_block
setblock 296 286 307 minecraft:pearlescent_froglight
fill 296 286 308 296 299 308 minecraft:iron_block
setblock 296 286 309 minecraft:pearlescent_froglight
fill 296 286 310 296 299 310 minecraft:iron_block
setblock 296 286 311 minecraft:pearlescent_froglight
fill 296 286 312 296 299 312 minecraft:iron_block
setblock 296 286 313 minecraft:pearlescent_froglight
fill 296 286 314 296 299 314 minecraft:iron_block
setblock 296 286 315 minecraft:pearlescent_froglight
fill 296 286 316 296 299 316 minecraft:iron_block
fill 296 286 317 297 287 317 minecraft:black_concrete
setblock 297 286 306 minecraft:pearlescent_froglight
fill 297 286 307 297 299 307 minecraft:iron_block
setblock 297 286 308 minecraft:pearlescent_froglight
fill 297 286 309 297 299 309 minecraft:iron_block
setblock 297 286 310 minecraft:pearlescent_froglight
fill 297 286 311 297 299 311 minecraft:iron_block
setblock 297 286 312 minecraft:pearlescent_froglight
fill 297 286 313 297 299 313 minecraft:iron_block
setblock 297 286 314 minecraft:pearlescent_froglight
fill 297 286 315 297 299 315 minecraft:iron_block
setblock 297 286 316 minecraft:pearlescent_froglight
fill 298 286 275 299 287 275 minecraft:yellow_concrete
fill 298 286 306 298 299 306 minecraft:iron_block
setblock 298 286 307 minecraft:pearlescent_froglight
fill 298 286 308 298 299 308 minecraft:iron_block
setblock 298 286 309 minecraft:pearlescent_froglight
fill 298 286 310 298 299 310 minecraft:iron_block
setblock 298 286 311 minecraft:pearlescent_froglight
fill 298 286 312 298 299 312 minecraft:iron_block
setblock 298 286 313 minecraft:pearlescent_froglight
fill 298 286 314 298 299 314 minecraft:iron_block
setblock 298 286 315 minecraft:pearlescent_froglight
fill 298 286 316 298 299 316 minecraft:iron_block
fill 298 286 317 299 287 317 minecraft:yellow_concrete
setblock 299 286 306 minecraft:pearlescent_froglight
fill 299 286 307 299 299 307 minecraft:iron_block
setblock 299 286 308 minecraft:pearlescent_froglight
fill 299 286 309 299 299 309 minecraft:iron_block
setblock 299 286 310 minecraft:pearlescent_froglight
fill 299 286 311 299 299 311 minecraft:iron_block
setblock 299 286 312 minecraft:pearlescent_froglight
fill 299 286 313 299 299 313 minecraft:iron_block
setblock 299 286 314 minecraft:pearlescent_froglight
fill 299 286 315 299 299 315 minecraft:iron_block
setblock 299 286 316 minecraft:pearlescent_froglight
fill 300 286 275 301 287 275 minecraft:black_concrete
fill 300 286 317 301 287 317 minecraft:black_concrete
fill 302 286 275 303 287 275 minecraft:yellow_concrete
fill 302 286 317 303 287 317 minecraft:yellow_concrete
fill 304 286 275 305 287 275 minecraft:black_concrete
fill 304 286 317 305 287 317 minecraft:black_concrete
fill 306 286 275 307 287 275 minecraft:yellow_concrete
fill 306 286 317 307 287 317 minecraft:yellow_concrete
fill 308 286 275 309 287 275 minecraft:black_concrete
fill 308 286 317 309 287 317 minecraft:black_concrete
fill 310 286 275 311 287 275 minecraft:yellow_concrete
fill 310 286 317 311 287 317 minecraft:yellow_concrete
fill 312 286 275 313 287 275 minecraft:black_concrete
fill 312 286 317 313 287 317 minecraft:black_concrete
fill 314 286 275 315 287 275 minecraft:yellow_concrete
fill 314 286 317 315 287 317 minecraft:yellow_concrete
fill 316 286 275 317 287 275 minecraft:black_concrete
fill 316 286 317 317 287 317 minecraft:black_concrete
fill 317 286 291 317 295 291 minecraft:iron_block
setblock 317 286 292 minecraft:pearlescent_froglight
fill 317 286 293 317 295 293 minecraft:iron_block
setblock 317 286 294 minecraft:pearlescent_froglight
fill 317 286 295 317 295 295 minecraft:iron_block
setblock 317 286 296 minecraft:pearlescent_froglight
fill 317 286 297 317 295 297 minecraft:iron_block
setblock 317 286 298 minecraft:pearlescent_froglight
fill 317 286 299 317 295 299 minecraft:iron_block
setblock 317 286 300 minecraft:pearlescent_froglight
fill 317 286 301 317 295 301 minecraft:iron_block
setblock 317 286 302 minecraft:pearlescent_froglight
fill 317 286 303 317 295 303 minecraft:iron_block
fill 318 286 275 319 287 275 minecraft:yellow_concrete
setblock 318 286 291 minecraft:pearlescent_froglight
fill 318 286 292 318 295 292 minecraft:iron_block
setblock 318 286 293 minecraft:pearlescent_froglight
fill 318 286 294 318 295 294 minecraft:iron_block
setblock 318 286 295 minecraft:pearlescent_froglight
fill 318 286 296 318 295 296 minecraft:iron_block
setblock 318 286 297 minecraft:pearlescent_froglight
fill 318 286 298 318 295 298 minecraft:iron_block
setblock 318 286 299 minecraft:pearlescent_froglight
fill 318 286 300 318 295 300 minecraft:iron_block
setblock 318 286 301 minecraft:pearlescent_froglight
fill 318 286 302 318 295 302 minecraft:iron_block
setblock 318 286 303 minecraft:pearlescent_froglight
fill 318 286 317 319 287 317 minecraft:yellow_concrete
fill 319 286 291 319 295 291 minecraft:iron_block
setblock 319 286 292 minecraft:pearlescent_froglight
fill 319 286 293 319 295 293 minecraft:iron_block
setblock 319 286 294 minecraft:pearlescent_froglight
fill 319 286 295 319 295 295 minecraft:iron_block
setblock 319 286 296 minecraft:pearlescent_froglight
fill 319 286 297 319 295 297 minecraft:iron_block
setblock 319 286 298 minecraft:pearlescent_froglight
fill 319 286 299 319 295 299 minecraft:iron_block
setblock 319 286 300 minecraft:pearlescent_froglight
fill 319 286 301 319 295 301 minecraft:iron_block
setblock 319 286 302 minecraft:pearlescent_froglight
fill 319 286 303 319 295 303 minecraft:iron_block
fill 320 286 275 321 287 275 minecraft:black_concrete
setblock 320 286 291 minecraft:pearlescent_froglight
fill 320 286 292 320 295 292 minecraft:iron_block
setblock 320 286 293 minecraft:pearlescent_froglight
fill 320 286 294 320 295 294 minecraft:iron_block
setblock 320 286 295 minecraft:pearlescent_froglight
fill 320 286 296 320 295 296 minecraft:iron_block
setblock 320 286 297 minecraft:pearlescent_froglight
fill 320 286 298 320 295 298 minecraft:iron_block
setblock 320 286 299 minecraft:pearlescent_froglight
fill 320 286 300 320 295 300 minecraft:iron_block
setblock 320 286 301 minecraft:pearlescent_froglight
fill 320 286 302 320 295 302 minecraft:iron_block
setblock 320 286 303 minecraft:pearlescent_froglight
fill 320 286 317 321 287 317 minecraft:black_concrete
fill 321 286 291 321 295 291 minecraft:iron_block
setblock 321 286 292 minecraft:pearlescent_froglight
fill 321 286 293 321 295 293 minecraft:iron_block
setblock 321 286 294 minecraft:pearlescent_froglight
fill 321 286 295 321 295 295 minecraft:iron_block
setblock 321 286 296 minecraft:pearlescent_froglight
fill 321 286 297 321 295 297 minecraft:iron_block
setblock 321 286 298 minecraft:pearlescent_froglight
fill 321 286 299 321 295 299 minecraft:iron_block
setblock 321 286 300 minecraft:pearlescent_froglight
fill 321 286 301 321 295 301 minecraft:iron_block
setblock 321 286 302 minecraft:pearlescent_froglight
fill 321 286 303 321 295 303 minecraft:iron_block
fill 322 286 275 323 287 275 minecraft:yellow_concrete
setblock 322 286 291 minecraft:pearlescent_froglight
fill 322 286 292 322 295 292 minecraft:iron_block
setblock 322 286 293 minecraft:pearlescent_froglight
fill 322 286 294 322 295 294 minecraft:iron_block
setblock 322 286 295 minecraft:pearlescent_froglight
fill 322 286 296 322 295 296 minecraft:iron_block
setblock 322 286 297 minecraft:pearlescent_froglight
fill 322 286 298 322 295 298 minecraft:iron_block
setblock 322 286 299 minecraft:pearlescent_froglight
fill 322 286 300 322 295 300 minecraft:iron_block
setblock 322 286 301 minecraft:pearlescent_froglight
fill 322 286 302 322 295 302 minecraft:iron_block
setblock 322 286 303 minecraft:pearlescent_froglight
fill 322 286 317 323 287 317 minecraft:yellow_concrete
fill 323 286 291 323 295 291 minecraft:iron_block
setblock 323 286 292 minecraft:pearlescent_froglight
fill 323 286 293 323 300 293 minecraft:iron_block
setblock 323 286 294 minecraft:pearlescent_froglight
fill 323 286 295 323 295 295 minecraft:iron_block
setblock 323 286 296 minecraft:pearlescent_froglight
fill 323 286 297 323 295 297 minecraft:iron_block
setblock 323 286 298 minecraft:pearlescent_froglight
fill 323 286 299 323 295 299 minecraft:iron_block
setblock 323 286 300 minecraft:pearlescent_froglight
fill 323 286 301 323 295 301 minecraft:iron_block
setblock 323 286 302 minecraft:pearlescent_froglight
fill 323 286 303 323 300 303 minecraft:iron_block
fill 324 286 275 324 287 275 minecraft:black_concrete
fill 324 286 276 324 287 276 minecraft:yellow_concrete
fill 324 286 277 324 287 278 minecraft:black_concrete
fill 324 286 279 324 287 280 minecraft:yellow_concrete
fill 324 286 281 324 287 282 minecraft:black_concrete
fill 324 286 283 324 287 284 minecraft:yellow_concrete
fill 324 286 285 324 287 286 minecraft:black_concrete
fill 324 286 287 324 287 288 minecraft:yellow_concrete
fill 324 286 289 324 287 290 minecraft:black_concrete
fill 324 286 291 324 287 292 minecraft:yellow_concrete
fill 324 286 293 324 287 294 minecraft:black_concrete
fill 324 286 295 324 287 296 minecraft:yellow_concrete
fill 324 286 297 324 287 298 minecraft:black_concrete
fill 324 286 299 324 287 300 minecraft:yellow_concrete
fill 324 286 301 324 287 302 minecraft:black_concrete
fill 324 286 303 324 287 304 minecraft:yellow_concrete
fill 324 286 305 324 287 306 minecraft:black_concrete
fill 324 286 307 324 287 308 minecraft:yellow_concrete
fill 324 286 309 324 287 310 minecraft:black_concrete
fill 324 286 311 324 287 312 minecraft:yellow_concrete
fill 324 286 313 324 287 314 minecraft:black_concrete
fill 324 286 315 324 287 316 minecraft:yellow_concrete
fill 324 286 317 324 287 317 minecraft:black_concrete
fill 291 287 306 291 288 306 minecraft:iron_block
fill 291 287 308 291 288 308 minecraft:iron_block
fill 291 287 310 291 288 310 minecraft:iron_block
fill 291 287 312 291 288 312 minecraft:iron_block
fill 291 287 314 291 288 314 minecraft:iron_block
fill 291 287 316 291 288 316 minecraft:iron_block
fill 292 287 307 292 288 307 minecraft:iron_block
fill 292 287 309 292 288 309 minecraft:iron_block
fill 292 287 311 292 288 311 minecraft:iron_block
fill 292 287 313 292 288 313 minecraft:iron_block
fill 292 287 315 292 288 315 minecraft:iron_block
fill 293 287 306 293 288 306 minecraft:iron_block
fill 293 287 308 293 288 308 minecraft:iron_block
fill 293 287 310 293 288 310 minecraft:iron_block
fill 293 287 312 293 288 312 minecraft:iron_block
fill 293 287 314 293 288 314 minecraft:iron_block
fill 293 287 316 293 288 316 minecraft:iron_block
fill 294 287 307 294 288 307 minecraft:iron_block
fill 294 287 309 294 288 309 minecraft:iron_block
fill 294 287 311 294 288 311 minecraft:iron_block
fill 294 287 313 294 288 313 minecraft:iron_block
fill 294 287 315 294 288 315 minecraft:iron_block
fill 295 287 306 295 288 306 minecraft:iron_block
fill 295 287 308 295 288 308 minecraft:iron_block
fill 295 287 310 295 288 310 minecraft:iron_block
fill 295 287 312 295 288 312 minecraft:iron_block
fill 295 287 314 295 288 314 minecraft:iron_block
fill 295 287 316 295 288 316 minecraft:iron_block
fill 296 287 307 296 288 307 minecraft:iron_block
fill 296 287 309 296 288 309 minecraft:iron_block
fill 296 287 311 296 288 311 minecraft:iron_block
fill 296 287 313 296 288 313 minecraft:iron_block
fill 296 287 315 296 288 315 minecraft:iron_block
fill 297 287 306 297 288 306 minecraft:iron_block
fill 297 287 308 297 288 308 minecraft:iron_block
fill 297 287 310 297 288 310 minecraft:iron_block
fill 297 287 312 297 288 312 minecraft:iron_block
fill 297 287 314 297 288 314 minecraft:iron_block
fill 297 287 316 297 288 316 minecraft:iron_block
fill 298 287 307 298 288 307 minecraft:iron_block
fill 298 287 309 298 288 309 minecraft:iron_block
fill 298 287 311 298 288 311 minecraft:iron_block
fill 298 287 313 298 288 313 minecraft:iron_block
fill 298 287 315 298 288 315 minecraft:iron_block
fill 299 287 306 299 288 306 minecraft:iron_block
fill 299 287 308 299 288 308 minecraft:iron_block
fill 299 287 310 299 288 310 minecraft:iron_block
fill 299 287 312 299 288 312 minecraft:iron_block
fill 299 287 314 299 288 314 minecraft:iron_block
fill 299 287 316 299 288 316 minecraft:iron_block
fill 317 287 292 317 288 292 minecraft:iron_block
fill 317 287 294 317 288 294 minecraft:iron_block
fill 317 287 296 317 288 296 minecraft:iron_block
fill 317 287 298 317 288 298 minecraft:iron_block
fill 317 287 300 317 288 300 minecraft:iron_block
fill 317 287 302 317 288 302 minecraft:iron_block
fill 318 287 291 318 288 291 minecraft:iron_block
fill 318 287 293 318 288 293 minecraft:iron_block
fill 318 287 295 318 288 295 minecraft:iron_block
fill 318 287 297 318 288 297 minecraft:iron_block
fill 318 287 299 318 288 299 minecraft:iron_block
fill 318 287 301 318 288 301 minecraft:iron_block
fill 318 287 303 318 288 303 minecraft:iron_block
fill 319 287 292 319 288 292 minecraft:iron_block
fill 319 287 294 319 288 294 minecraft:iron_block
fill 319 287 296 319 288 296 minecraft:iron_block
fill 319 287 298 319 288 298 minecraft:iron_block
fill 319 287 300 319 288 300 minecraft:iron_block
fill 319 287 302 319 288 302 minecraft:iron_block
fill 320 287 291 320 288 291 minecraft:iron_block
fill 320 287 293 320 288 293 minecraft:iron_block
fill 320 287 295 320 288 295 minecraft:iron_block
fill 320 287 297 320 288 297 minecraft:iron_block
fill 320 287 299 320 288 299 minecraft:iron_block
fill 320 287 301 320 288 301 minecraft:iron_block
fill 320 287 303 320 288 303 minecraft:iron_block
fill 321 287 292 321 288 292 minecraft:iron_block
fill 321 287 294 321 288 294 minecraft:iron_block
fill 321 287 296 321 288 296 minecraft:iron_block
fill 321 287 298 321 288 298 minecraft:iron_block
fill 321 287 300 321 288 300 minecraft:iron_block
fill 321 287 302 321 288 302 minecraft:iron_block
fill 322 287 291 322 288 291 minecraft:iron_block
fill 322 287 293 322 288 293 minecraft:iron_block
fill 322 287 295 322 288 295 minecraft:iron_block
fill 322 287 297 322 288 297 minecraft:iron_block
fill 322 287 299 322 288 299 minecraft:iron_block
fill 322 287 301 322 288 301 minecraft:iron_block
fill 322 287 303 322 288 303 minecraft:iron_block
fill 323 287 292 323 288 292 minecraft:iron_block
fill 323 287 294 323 288 294 minecraft:iron_block
fill 323 287 296 323 288 296 minecraft:iron_block
fill 323 287 298 323 288 298 minecraft:iron_block
fill 323 287 300 323 288 300 minecraft:iron_block
fill 323 287 302 323 288 302 minecraft:iron_block
fill 282 288 275 282 291 317 minecraft:light_gray_concrete
fill 283 288 275 324 291 275 minecraft:light_gray_concrete
setblock 283 288 278 minecraft:iron_block
fill 283 288 280 283 288 283 minecraft:iron_block
setblock 283 288 288 minecraft:iron_block
fill 283 288 290 283 288 293 minecraft:iron_block
setblock 283 288 298 minecraft:iron_block
fill 283 288 300 283 288 303 minecraft:iron_block
setblock 283 288 308 minecraft:iron_block
fill 283 288 310 283 288 313 minecraft:iron_block
fill 283 288 317 324 291 317 minecraft:light_gray_concrete
fill 284 288 276 287 288 276 minecraft:iron_block
setblock 285 288 316 minecraft:iron_block
fill 287 288 316 290 288 316 minecraft:iron_block
setblock 289 288 276 minecraft:iron_block
fill 294 288 276 297 288 276 minecraft:iron_block
setblock 299 288 276 minecraft:iron_block
setblock 300 288 316 minecraft:iron_block
fill 304 288 276 307 288 276 minecraft:iron_block
setblock 305 288 316 minecraft:iron_block
fill 307 288 316 310 288 316 minecraft:iron_block
setblock 309 288 276 minecraft:iron_block
fill 314 288 276 317 288 276 minecraft:iron_block
setblock 315 288 316 minecraft:iron_block
fill 317 288 316 320 288 316 minecraft:iron_block
setblock 319 288 276 minecraft:iron_block
fill 323 288 277 323 288 280 minecraft:iron_block
setblock 323 288 282 minecraft:iron_block
fill 323 288 287 323 288 290 minecraft:iron_block
fill 323 288 307 323 288 310 minecraft:iron_block
setblock 323 288 312 minecraft:iron_block
fill 324 288 276 324 291 316 minecraft:light_gray_concrete
setblock 285 289 278 minecraft:light[level=15]
setblock 285 289 285 minecraft:light[level=12]
setblock 285 289 286 minecraft:light[level=15]
setblock 285 289 292 minecraft:light[level=12]
setblock 285 289 294 minecraft:light[level=15]
setblock 285 289 299 minecraft:light[level=12]
setblock 285 289 302 minecraft:light[level=15]
setblock 285 289 306 minecraft:light[level=12]
setblock 285 289 310 minecraft:light[level=15]
setblock 285 289 313 minecraft:light[level=12]
setblock 291 289 306 minecraft:pearlescent_froglight
setblock 291 289 308 minecraft:pearlescent_froglight
setblock 291 289 310 minecraft:pearlescent_froglight
setblock 291 289 312 minecraft:pearlescent_froglight
setblock 291 289 314 minecraft:pearlescent_froglight
setblock 291 289 316 minecraft:pearlescent_froglight
setblock 292 289 278 minecraft:light[level=12]
setblock 292 289 285 minecraft:light[level=12]
setblock 292 289 292 minecraft:light[level=12]
setblock 292 289 299 minecraft:light[level=12]
setblock 292 289 307 minecraft:pearlescent_froglight
setblock 292 289 309 minecraft:pearlescent_froglight
setblock 292 289 311 minecraft:pearlescent_froglight
setblock 292 289 313 minecraft:pearlescent_froglight
setblock 292 289 315 minecraft:pearlescent_froglight
setblock 293 289 278 minecraft:light[level=15]
setblock 293 289 286 minecraft:light[level=15]
setblock 293 289 294 minecraft:light[level=15]
setblock 293 289 302 minecraft:light[level=15]
setblock 293 289 306 minecraft:pearlescent_froglight
setblock 293 289 308 minecraft:pearlescent_froglight
setblock 293 289 310 minecraft:pearlescent_froglight
setblock 293 289 312 minecraft:pearlescent_froglight
setblock 293 289 314 minecraft:pearlescent_froglight
setblock 293 289 316 minecraft:pearlescent_froglight
setblock 294 289 307 minecraft:pearlescent_froglight
setblock 294 289 309 minecraft:pearlescent_froglight
setblock 294 289 311 minecraft:pearlescent_froglight
setblock 294 289 313 minecraft:pearlescent_froglight
setblock 294 289 315 minecraft:pearlescent_froglight
setblock 295 289 306 minecraft:pearlescent_froglight
setblock 295 289 308 minecraft:pearlescent_froglight
setblock 295 289 310 minecraft:pearlescent_froglight
setblock 295 289 312 minecraft:pearlescent_froglight
setblock 295 289 314 minecraft:pearlescent_froglight
setblock 295 289 316 minecraft:pearlescent_froglight
setblock 296 289 307 minecraft:pearlescent_froglight
setblock 296 289 309 minecraft:pearlescent_froglight
setblock 296 289 311 minecraft:pearlescent_froglight
setblock 296 289 313 minecraft:pearlescent_froglight
setblock 296 289 315 minecraft:pearlescent_froglight
setblock 297 289 306 minecraft:pearlescent_froglight
setblock 297 289 308 minecraft:pearlescent_froglight
setblock 297 289 310 minecraft:pearlescent_froglight
setblock 297 289 312 minecraft:pearlescent_froglight
setblock 297 289 314 minecraft:pearlescent_froglight
setblock 297 289 316 minecraft:pearlescent_froglight
setblock 298 289 307 minecraft:pearlescent_froglight
setblock 298 289 309 minecraft:pearlescent_froglight
setblock 298 289 311 minecraft:pearlescent_froglight
setblock 298 289 313 minecraft:pearlescent_froglight
setblock 298 289 315 minecraft:pearlescent_froglight
setblock 299 289 278 minecraft:light[level=12]
setblock 299 289 285 minecraft:light[level=12]
setblock 299 289 292 minecraft:light[level=12]
setblock 299 289 299 minecraft:light[level=12]
setblock 299 289 306 minecraft:pearlescent_froglight
setblock 299 289 308 minecraft:pearlescent_froglight
setblock 299 289 310 minecraft:pearlescent_froglight
setblock 299 289 312 minecraft:pearlescent_froglight
setblock 299 289 314 minecraft:pearlescent_froglight
setblock 299 289 316 minecraft:pearlescent_froglight
setblock 301 289 278 minecraft:light[level=15]
setblock 301 289 286 minecraft:light[level=15]
setblock 301 289 302 minecraft:light[level=15]
setblock 301 289 310 minecraft:light[level=15]
setblock 306 289 278 minecraft:light[level=12]
setblock 306 289 285 minecraft:light[level=12]
setblock 306 289 292 minecraft:light[level=12]
setblock 306 289 299 minecraft:light[level=12]
setblock 306 289 306 minecraft:light[level=12]
setblock 306 289 313 minecraft:light[level=12]
setblock 309 289 278 minecraft:light[level=15]
setblock 309 289 286 minecraft:light[level=15]
setblock 309 289 294 minecraft:light[level=15]
setblock 309 289 302 minecraft:light[level=15]
setblock 309 289 310 minecraft:light[level=15]
setblock 313 289 278 minecraft:light[level=12]
setblock 313 289 285 minecraft:light[level=12]
setblock 313 289 292 minecraft:light[level=12]
setblock 313 289 299 minecraft:light[level=12]
setblock 313 289 306 minecraft:light[level=12]
setblock 313 289 313 minecraft:light[level=12]
setblock 317 289 278 minecraft:light[level=15]
setblock 317 289 286 minecraft:light[level=15]
setblock 317 289 292 minecraft:pearlescent_froglight
setblock 317 289 294 minecraft:pearlescent_froglight
setblock 317 289 296 minecraft:pearlescent_froglight
setblock 317 289 298 minecraft:pearlescent_froglight
setblock 317 289 300 minecraft:pearlescent_froglight
setblock 317 289 302 minecraft:pearlescent_froglight
setblock 317 289 310 minecraft:light[level=15]
setblock 318 289 291 minecraft:pearlescent_froglight
setblock 318 289 293 minecraft:pearlescent_froglight
setblock 318 289 295 minecraft:pearlescent_froglight
setblock 318 289 297 minecraft:pearlescent_froglight
setblock 318 289 299 minecraft:pearlescent_froglight
setblock 318 289 301 minecraft:pearlescent_froglight
setblock 318 289 303 minecraft:pearlescent_froglight
setblock 319 289 292 minecraft:pearlescent_froglight
setblock 319 289 294 minecraft:pearlescent_froglight
setblock 319 289 296 minecraft:pearlescent_froglight
setblock 319 289 298 minecraft:pearlescent_froglight
setblock 319 289 300 minecraft:pearlescent_froglight
setblock 319 289 302 minecraft:pearlescent_froglight
setblock 320 289 278 minecraft:light[level=12]
setblock 320 289 285 minecraft:light[level=12]
setblock 320 289 291 minecraft:pearlescent_froglight
setblock 320 289 293 minecraft:pearlescent_froglight
setblock 320 289 295 minecraft:pearlescent_froglight
setblock 320 289 297 minecraft:pearlescent_froglight
setblock 320 289 299 minecraft:pearlescent_froglight
setblock 320 289 301 minecraft:pearlescent_froglight
setblock 320 289 303 minecraft:pearlescent_froglight
setblock 320 289 306 minecraft:light[level=12]
setblock 320 289 313 minecraft:light[level=12]
setblock 321 289 292 minecraft:pearlescent_froglight
setblock 321 289 294 minecraft:pearlescent_froglight
setblock 321 289 296 minecraft:pearlescent_froglight
setblock 321 289 298 minecraft:pearlescent_froglight
setblock 321 289 300 minecraft:pearlescent_froglight
setblock 321 289 302 minecraft:pearlescent_froglight
setblock 322 289 291 minecraft:pearlescent_froglight
setblock 322 289 293 minecraft:pearlescent_froglight
setblock 322 289 295 minecraft:pearlescent_froglight
setblock 322 289 297 minecraft:pearlescent_froglight
setblock 322 289 299 minecraft:pearlescent_froglight
setblock 322 289 301 minecraft:pearlescent_froglight
setblock 322 289 303 minecraft:pearlescent_froglight
setblock 323 289 292 minecraft:pearlescent_froglight
setblock 323 289 294 minecraft:pearlescent_froglight
setblock 323 289 296 minecraft:pearlescent_froglight
setblock 323 289 298 minecraft:pearlescent_froglight
setblock 323 289 300 minecraft:pearlescent_froglight
setblock 323 289 302 minecraft:pearlescent_froglight
fill 291 290 306 291 291 306 minecraft:iron_block
fill 291 290 308 291 291 308 minecraft:iron_block
fill 291 290 310 291 291 310 minecraft:iron_block
fill 291 290 312 291 291 312 minecraft:iron_block
fill 291 290 314 291 291 314 minecraft:iron_block
fill 291 290 316 291 291 316 minecraft:iron_block
fill 292 290 307 292 291 307 minecraft:iron_block
fill 292 290 309 292 291 309 minecraft:iron_block
fill 292 290 311 292 291 311 minecraft:iron_block
fill 292 290 313 292 291 313 minecraft:iron_block
fill 292 290 315 292 291 315 minecraft:iron_block
fill 293 290 306 293 291 306 minecraft:iron_block
fill 293 290 308 293 291 308 minecraft:iron_block
fill 293 290 310 293 291 310 minecraft:iron_block
fill 293 290 312 293 291 312 minecraft:iron_block
fill 293 290 314 293 291 314 minecraft:iron_block
fill 293 290 316 293 291 316 minecraft:iron_block
fill 294 290 307 294 291 307 minecraft:iron_block
fill 294 290 309 294 291 309 minecraft:iron_block
fill 294 290 311 294 291 311 minecraft:iron_block
fill 294 290 313 294 291 313 minecraft:iron_block
fill 294 290 315 294 291 315 minecraft:iron_block
fill 295 290 306 295 291 306 minecraft:iron_block
fill 295 290 308 295 291 308 minecraft:iron_block
fill 295 290 310 295 291 310 minecraft:iron_block
fill 295 290 312 295 291 312 minecraft:iron_block
fill 295 290 314 295 291 314 minecraft:iron_block
fill 295 290 316 295 291 316 minecraft:iron_block
fill 296 290 307 296 291 307 minecraft:iron_block
fill 296 290 309 296 291 309 minecraft:iron_block
fill 296 290 311 296 291 311 minecraft:iron_block
fill 296 290 313 296 291 313 minecraft:iron_block
fill 296 290 315 296 291 315 minecraft:iron_block
fill 297 290 306 297 291 306 minecraft:iron_block
fill 297 290 308 297 291 308 minecraft:iron_block
fill 297 290 310 297 291 310 minecraft:iron_block
fill 297 290 312 297 291 312 minecraft:iron_block
fill 297 290 314 297 291 314 minecraft:iron_block
fill 297 290 316 297 291 316 minecraft:iron_block
fill 298 290 307 298 291 307 minecraft:iron_block
fill 298 290 309 298 291 309 minecraft:iron_block
fill 298 290 311 298 291 311 minecraft:iron_block
fill 298 290 313 298 291 313 minecraft:iron_block
fill 298 290 315 298 291 315 minecraft:iron_block
fill 299 290 306 299 291 306 minecraft:iron_block
fill 299 290 308 299 291 308 minecraft:iron_block
fill 299 290 310 299 291 310 minecraft:iron_block
fill 299 290 312 299 291 312 minecraft:iron_block
fill 299 290 314 299 291 314 minecraft:iron_block
fill 299 290 316 299 291 316 minecraft:iron_block
fill 317 290 292 317 291 292 minecraft:iron_block
fill 317 290 294 317 291 294 minecraft:iron_block
fill 317 290 296 317 291 296 minecraft:iron_block
fill 317 290 298 317 291 298 minecraft:iron_block
fill 317 290 300 317 291 300 minecraft:iron_block
fill 317 290 302 317 291 302 minecraft:iron_block
fill 318 290 291 318 291 291 minecraft:iron_block
fill 318 290 293 318 291 293 minecraft:iron_block
fill 318 290 295 318 291 295 minecraft:iron_block
fill 318 290 297 318 291 297 minecraft:iron_block
fill 318 290 299 318 291 299 minecraft:iron_block
fill 318 290 301 318 291 301 minecraft:iron_block
fill 318 290 303 318 291 303 minecraft:iron_block
fill 319 290 292 319 291 292 minecraft:iron_block
fill 319 290 294 319 291 294 minecraft:iron_block
fill 319 290 296 319 291 296 minecraft:iron_block
fill 319 290 298 319 291 298 minecraft:iron_block
fill 319 290 300 319 291 300 minecraft:iron_block
fill 319 290 302 319 291 302 minecraft:iron_block
fill 320 290 291 320 291 291 minecraft:iron_block
fill 320 290 293 320 291 293 minecraft:iron_block
fill 320 290 295 320 291 295 minecraft:iron_block
fill 320 290 297 320 291 297 minecraft:iron_block
fill 320 290 299 320 291 299 minecraft:iron_block
fill 320 290 301 320 291 301 minecraft:iron_block
fill 320 290 303 320 291 303 minecraft:iron_block
fill 321 290 292 321 291 292 minecraft:iron_block
fill 321 290 294 321 291 294 minecraft:iron_block
fill 321 290 296 321 291 296 minecraft:iron_block
fill 321 290 298 321 291 298 minecraft:iron_block
fill 321 290 300 321 291 300 minecraft:iron_block
fill 321 290 302 321 291 302 minecraft:iron_block
fill 322 290 291 322 291 291 minecraft:iron_block
fill 322 290 293 322 291 293 minecraft:iron_block
fill 322 290 295 322 291 295 minecraft:iron_block
fill 322 290 297 322 291 297 minecraft:iron_block
fill 322 290 299 322 291 299 minecraft:iron_block
fill 322 290 301 322 291 301 minecraft:iron_block
fill 322 290 303 322 291 303 minecraft:iron_block
fill 323 290 292 323 291 292 minecraft:iron_block
fill 323 290 294 323 291 294 minecraft:iron_block
fill 323 290 296 323 291 296 minecraft:iron_block
fill 323 290 298 323 291 298 minecraft:iron_block
fill 323 290 300 323 291 300 minecraft:iron_block
fill 323 290 302 323 291 302 minecraft:iron_block
fill 304 291 311 304 291 313 minecraft:iron_block
fill 305 291 311 306 291 311 minecraft:iron_block
fill 305 291 313 306 291 313 minecraft:iron_block
setblock 306 291 312 minecraft:iron_block
fill 282 292 275 282 308 280 minecraft:light_gray_concrete
fill 282 292 281 282 292 284 minecraft:pearlescent_froglight
fill 282 292 285 282 308 290 minecraft:light_gray_concrete
fill 282 292 291 282 292 294 minecraft:pearlescent_froglight
fill 282 292 295 282 308 300 minecraft:light_gray_concrete
fill 282 292 301 282 292 304 minecraft:pearlescent_froglight
fill 282 292 305 282 293 310 minecraft:light_gray_concrete
fill 282 292 311 282 292 314 minecraft:pearlescent_froglight
fill 282 292 315 282 308 317 minecraft:light_gray_concrete
fill 283 292 275 284 308 275 minecraft:light_gray_concrete
fill 283 292 317 285 308 317 minecraft:light_gray_concrete
fill 285 292 275 288 292 275 minecraft:pearlescent_froglight
fill 286 292 317 289 292 317 minecraft:pearlescent_froglight
fill 287 292 293 287 299 293 minecraft:iron_block
fill 289 292 275 294 308 275 minecraft:light_gray_concrete
fill 290 292 317 295 298 317 minecraft:light_gray_concrete
setblock 291 292 306 minecraft:pearlescent_froglight
setblock 291 292 308 minecraft:pearlescent_froglight
setblock 291 292 310 minecraft:pearlescent_froglight
setblock 291 292 312 minecraft:pearlescent_froglight
setblock 291 292 314 minecraft:pearlescent_froglight
setblock 291 292 316 minecraft:pearlescent_froglight
setblock 292 292 307 minecraft:pearlescent_froglight
setblock 292 292 309 minecraft:pearlescent_froglight
setblock 292 292 311 minecraft:pearlescent_froglight
setblock 292 292 313 minecraft:pearlescent_froglight
setblock 292 292 315 minecraft:pearlescent_froglight
setblock 293 292 306 minecraft:pearlescent_froglight
setblock 293 292 308 minecraft:pearlescent_froglight
setblock 293 292 310 minecraft:pearlescent_froglight
setblock 293 292 312 minecraft:pearlescent_froglight
setblock 293 292 314 minecraft:pearlescent_froglight
setblock 293 292 316 minecraft:pearlescent_froglight
setblock 294 292 307 minecraft:pearlescent_froglight
setblock 294 292 309 minecraft:pearlescent_froglight
setblock 294 292 311 minecraft:pearlescent_froglight
setblock 294 292 313 minecraft:pearlescent_froglight
setblock 294 292 315 minecraft:pearlescent_froglight
fill 295 292 275 298 292 275 minecraft:pearlescent_froglight
setblock 295 292 306 minecraft:pearlescent_froglight
setblock 295 292 308 minecraft:pearlescent_froglight
setblock 295 292 310 minecraft:pearlescent_froglight
setblock 295 292 312 minecraft:pearlescent_froglight
setblock 295 292 314 minecraft:pearlescent_froglight
setblock 295 292 316 minecraft:pearlescent_froglight
setblock 296 292 307 minecraft:pearlescent_froglight
setblock 296 292 309 minecraft:pearlescent_froglight
setblock 296 292 311 minecraft:pearlescent_froglight
setblock 296 292 313 minecraft:pearlescent_froglight
setblock 296 292 315 minecraft:pearlescent_froglight
fill 296 292 317 299 292 317 minecraft:pearlescent_froglight
setblock 297 292 306 minecraft:pearlescent_froglight
setblock 297 292 308 minecraft:pearlescent_froglight
setblock 297 292 310 minecraft:pearlescent_froglight
setblock 297 292 312 minecraft:pearlescent_froglight
setblock 297 292 314 minecraft:pearlescent_froglight
setblock 297 292 316 minecraft:pearlescent_froglight
setblock 298 292 307 minecraft:pearlescent_froglight
setblock 298 292 309 minecraft:pearlescent_froglight
setblock 298 292 311 minecraft:pearlescent_froglight
setblock 298 292 313 minecraft:pearlescent_froglight
setblock 298 292 315 minecraft:pearlescent_froglight
fill 299 292 275 304 292 275 minecraft:light_gray_concrete
setblock 299 292 306 minecraft:pearlescent_froglight
setblock 299 292 308 minecraft:pearlescent_froglight
setblock 299 292 310 minecraft:pearlescent_froglight
setblock 299 292 312 minecraft:pearlescent_froglight
setblock 299 292 314 minecraft:pearlescent_froglight
setblock 299 292 316 minecraft:pearlescent_froglight
fill 300 292 317 305 308 317 minecraft:light_gray_concrete
fill 305 292 275 308 292 275 minecraft:pearlescent_froglight
fill 306 292 317 309 292 317 minecraft:pearlescent_froglight
fill 309 292 275 314 298 275 minecraft:light_gray_concrete
fill 310 292 317 315 308 317 minecraft:light_gray_concrete
fill 315 292 275 318 292 275 minecraft:pearlescent_froglight
fill 316 292 317 319 292 317 minecraft:pearlescent_froglight
setblock 317 292 292 minecraft:pearlescent_froglight
setblock 317 292 294 minecraft:pearlescent_froglight
setblock 317 292 296 minecraft:pearlescent_froglight
setblock 317 292 298 minecraft:pearlescent_froglight
setblock 317 292 300 minecraft:pearlescent_froglight
setblock 317 292 302 minecraft:pearlescent_froglight
setblock 318 292 291 minecraft:pearlescent_froglight
setblock 318 292 293 minecraft:pearlescent_froglight
setblock 318 292 295 minecraft:pearlescent_froglight
setblock 318 292 297 minecraft:pearlescent_froglight
setblock 318 292 299 minecraft:pearlescent_froglight
setblock 318 292 301 minecraft:pearlescent_froglight
setblock 318 292 303 minecraft:pearlescent_froglight
fill 319 292 275 324 308 275 minecraft:light_gray_concrete
setblock 319 292 292 minecraft:pearlescent_froglight
setblock 319 292 294 minecraft:pearlescent_froglight
setblock 319 292 296 minecraft:pearlescent_froglight
setblock 319 292 298 minecraft:pearlescent_froglight
setblock 319 292 300 minecraft:pearlescent_froglight
setblock 319 292 302 minecraft:pearlescent_froglight
setblock 320 292 291 minecraft:pearlescent_froglight
setblock 320 292 293 minecraft:pearlescent_froglight
setblock 320 292 295 minecraft:pearlescent_froglight
setblock 320 292 297 minecraft:pearlescent_froglight
setblock 320 292 299 minecraft:pearlescent_froglight
setblock 320 292 301 minecraft:pearlescent_froglight
setblock 320 292 303 minecraft:pearlescent_froglight
fill 320 292 317 324 304 317 minecraft:light_gray_concrete
setblock 321 292 292 minecraft:pearlescent_froglight
setblock 321 292 294 minecraft:pearlescent_froglight
setblock 321 292 296 minecraft:pearlescent_froglight
setblock 321 292 298 minecraft:pearlescent_froglight
setblock 321 292 300 minecraft:pearlescent_froglight
setblock 321 292 302 minecraft:pearlescent_froglight
setblock 322 292 291 minecraft:pearlescent_froglight
setblock 322 292 293 minecraft:pearlescent_froglight
setblock 322 292 295 minecraft:pearlescent_froglight
setblock 322 292 297 minecraft:pearlescent_froglight
setblock 322 292 299 minecraft:pearlescent_froglight
setblock 322 292 301 minecraft:pearlescent_froglight
setblock 322 292 303 minecraft:pearlescent_froglight
setblock 323 292 292 minecraft:pearlescent_froglight
setblock 323 292 294 minecraft:pearlescent_froglight
fill 323 292 296 324 292 296 minecraft:pearlescent_froglight
fill 323 292 298 324 292 298 minecraft:pearlescent_froglight
setblock 323 292 300 minecraft:pearlescent_froglight
setblock 323 292 302 minecraft:pearlescent_froglight
fill 324 292 276 324 292 279 minecraft:pearlescent_froglight
fill 324 292 280 324 304 285 minecraft:light_gray_concrete
fill 324 292 286 324 292 289 minecraft:pearlescent_froglight
fill 324 292 290 324 301 295 minecraft:light_gray_concrete
setblock 324 292 297 minecraft:pearlescent_froglight
setblock 324 292 299 minecraft:pearlescent_froglight
fill 324 292 300 324 308 305 minecraft:light_gray_concrete
fill 324 292 306 324 292 309 minecraft:pearlescent_froglight
fill 324 292 310 324 308 315 minecraft:light_gray_concrete
setblock 324 292 316 minecraft:pearlescent_froglight
fill 282 293 281 282 308 284 minecraft:light_gray_concrete
fill 282 293 291 282 308 294 minecraft:light_gray_concrete
fill 282 293 301 282 308 304 minecraft:light_gray_concrete
fill 282 293 311 282 301 314 minecraft:light_gray_concrete
fill 285 293 275 288 308 275 minecraft:light_gray_concrete
fill 286 293 317 289 308 317 minecraft:light_gray_concrete
fill 288 293 293 288 298 293 minecraft:iron_block
fill 291 293 306 291 294 306 minecraft:iron_block
fill 291 293 308 291 294 308 minecraft:iron_block
fill 291 293 310 291 294 310 minecraft:iron_block
fill 291 293 312 291 294 312 minecraft:iron_block
fill 291 293 314 291 294 314 minecraft:iron_block
fill 291 293 316 291 294 316 minecraft:iron_block
fill 292 293 307 292 294 307 minecraft:iron_block
fill 292 293 309 292 294 309 minecraft:iron_block
fill 292 293 311 292 294 311 minecraft:iron_block
fill 292 293 313 292 294 313 minecraft:iron_block
fill 292 293 315 292 294 315 minecraft:iron_block
fill 293 293 306 293 294 306 minecraft:iron_block
fill 293 293 308 293 294 308 minecraft:iron_block
fill 293 293 310 293 294 310 minecraft:iron_block
fill 293 293 312 293 294 312 minecraft:iron_block
fill 293 293 314 293 294 314 minecraft:iron_block
fill 293 293 316 293 294 316 minecraft:iron_block
fill 294 293 307 294 294 307 minecraft:iron_block
fill 294 293 309 294 294 309 minecraft:iron_block
fill 294 293 311 294 294 311 minecraft:iron_block
fill 294 293 313 294 294 313 minecraft:iron_block
fill 294 293 315 294 294 315 minecraft:iron_block
fill 295 293 275 298 308 275 minecraft:light_gray_concrete
fill 295 293 306 295 294 306 minecraft:iron_block
fill 295 293 308 295 294 308 minecraft:iron_block
fill 295 293 310 295 294 310 minecraft:iron_block
fill 295 293 312 295 294 312 minecraft:iron_block
fill 295 293 314 295 294 314 minecraft:iron_block
fill 295 293 316 295 294 316 minecraft:iron_block
fill 296 293 307 296 294 307 minecraft:iron_block
fill 296 293 309 296 294 309 minecraft:iron_block
fill 296 293 311 296 294 311 minecraft:iron_block
fill 296 293 313 296 294 313 minecraft:iron_block
fill 296 293 315 296 294 315 minecraft:iron_block
fill 296 293 317 299 298 317 minecraft:light_gray_concrete
fill 297 293 306 297 294 306 minecraft:iron_block
fill 297 293 308 297 294 308 minecraft:iron_block
fill 297 293 310 297 294 310 minecraft:iron_block
fill 297 293 312 297 294 312 minecraft:iron_block
fill 297 293 314 297 294 314 minecraft:iron_block
fill 297 293 316 297 294 316 minecraft:iron_block
fill 298 293 307 298 294 307 minecraft:iron_block
fill 298 293 309 298 294 309 minecraft:iron_block
fill 298 293 311 298 294 311 minecraft:iron_block
fill 298 293 313 298 294 313 minecraft:iron_block
fill 298 293 315 298 294 315 minecraft:iron_block
setblock 299 293 275 minecraft:sea_lantern
fill 299 293 306 299 294 306 minecraft:iron_block
fill 299 293 308 299 294 308 minecraft:iron_block
fill 299 293 310 299 294 310 minecraft:iron_block
fill 299 293 312 299 294 312 minecraft:iron_block
fill 299 293 314 299 294 314 minecraft:iron_block
fill 299 293 316 299 294 316 minecraft:iron_block
fill 300 293 275 308 294 275 minecraft:light_gray_concrete
fill 306 293 317 309 308 317 minecraft:light_gray_concrete
fill 315 293 275 318 308 275 minecraft:light_gray_concrete
fill 316 293 317 317 308 317 minecraft:light_gray_concrete
fill 317 293 292 317 295 292 minecraft:iron_block
fill 317 293 294 317 295 294 minecraft:iron_block
fill 317 293 296 317 295 296 minecraft:iron_block
fill 317 293 298 317 295 298 minecraft:iron_block
fill 317 293 300 317 295 300 minecraft:iron_block
fill 317 293 302 317 295 302 minecraft:iron_block
fill 318 293 291 318 295 291 minecraft:iron_block
fill 318 293 293 318 295 293 minecraft:iron_block
fill 318 293 295 318 295 295 minecraft:iron_block
fill 318 293 297 318 295 297 minecraft:iron_block
fill 318 293 299 318 295 299 minecraft:iron_block
fill 318 293 301 318 295 301 minecraft:iron_block
fill 318 293 303 318 295 303 minecraft:iron_block
setblock 318 293 317 minecraft:redstone_block
fill 319 293 292 319 295 292 minecraft:iron_block
fill 319 293 294 319 295 294 minecraft:iron_block
fill 319 293 296 319 295 296 minecraft:iron_block
fill 319 293 298 319 295 298 minecraft:iron_block
fill 319 293 300 319 295 300 minecraft:iron_block
fill 319 293 302 319 295 302 minecraft:iron_block
fill 319 293 317 319 308 317 minecraft:light_gray_concrete
fill 320 293 291 320 295 291 minecraft:iron_block
fill 320 293 293 320 295 293 minecraft:iron_block
fill 320 293 295 320 295 295 minecraft:iron_block
fill 320 293 297 320 295 297 minecraft:iron_block
fill 320 293 299 320 295 299 minecraft:iron_block
fill 320 293 301 320 295 301 minecraft:iron_block
fill 320 293 303 320 295 303 minecraft:iron_block
fill 321 293 292 321 295 292 minecraft:iron_block
fill 321 293 294 321 295 294 minecraft:iron_block
fill 321 293 296 321 295 296 minecraft:iron_block
fill 321 293 298 321 295 298 minecraft:iron_block
fill 321 293 300 321 295 300 minecraft:iron_block
fill 321 293 302 321 295 302 minecraft:iron_block
fill 322 293 291 322 295 291 minecraft:iron_block
fill 322 293 293 322 295 293 minecraft:iron_block
fill 322 293 295 322 295 295 minecraft:iron_block
fill 322 293 297 322 295 297 minecraft:iron_block
fill 322 293 299 322 295 299 minecraft:iron_block
fill 322 293 301 322 295 301 minecraft:iron_block
fill 322 293 303 322 295 303 minecraft:iron_block
fill 323 293 292 323 295 292 minecraft:iron_block
fill 323 293 294 323 295 294 minecraft:iron_block
fill 323 293 296 323 295 296 minecraft:iron_block
fill 323 293 298 323 295 298 minecraft:iron_block
fill 323 293 300 323 295 300 minecraft:iron_block
fill 323 293 302 323 295 302 minecraft:iron_block
fill 324 293 276 324 308 279 minecraft:light_gray_concrete
fill 324 293 286 324 301 289 minecraft:light_gray_concrete
fill 324 293 296 324 308 299 minecraft:light_gray_concrete
fill 324 293 306 324 304 309 minecraft:light_gray_concrete
fill 324 293 316 324 308 316 minecraft:light_gray_concrete
fill 282 294 305 282 308 305 minecraft:light_gray_concrete
setblock 282 294 306 minecraft:redstone_block
fill 282 294 307 282 308 310 minecraft:light_gray_concrete
setblock 283 294 278 minecraft:iron_block
setblock 283 294 288 minecraft:iron_block
setblock 283 294 298 minecraft:iron_block
setblock 283 294 308 minecraft:iron_block
setblock 285 294 316 minecraft:iron_block
setblock 289 294 276 minecraft:iron_block
fill 299 294 275 299 308 275 minecraft:light_gray_concrete
setblock 299 294 276 minecraft:iron_block
setblock 305 294 316 minecraft:iron_block
setblock 309 294 276 minecraft:iron_block
setblock 315 294 316 minecraft:iron_block
fill 318 294 317 318 308 317 minecraft:light_gray_concrete
setblock 319 294 276 minecraft:iron_block
setblock 323 294 282 minecraft:iron_block
setblock 323 294 312 minecraft:iron_block
fill 282 295 306 282 308 306 minecraft:light_gray_concrete
setblock 285 295 278 minecraft:light[level=12]
setblock 285 295 285 minecraft:light[level=12]
setblock 285 295 292 minecraft:light[level=12]
setblock 285 295 299 minecraft:light[level=12]
setblock 285 295 306 minecraft:light[level=12]
setblock 285 295 313 minecraft:light[level=12]
setblock 291 295 306 minecraft:pearlescent_froglight
setblock 291 295 308 minecraft:pearlescent_froglight
setblock 291 295 310 minecraft:pearlescent_froglight
setblock 291 295 312 minecraft:pearlescent_froglight
setblock 291 295 314 minecraft:pearlescent_froglight
setblock 291 295 316 minecraft:pearlescent_froglight
setblock 292 295 278 minecraft:light[level=12]
setblock 292 295 285 minecraft:light[level=12]
setblock 292 295 292 minecraft:light[level=12]
setblock 292 295 299 minecraft:light[level=12]
setblock 292 295 307 minecraft:pearlescent_froglight
setblock 292 295 309 minecraft:pearlescent_froglight
setblock 292 295 311 minecraft:pearlescent_froglight
setblock 292 295 313 minecraft:pearlescent_froglight
setblock 292 295 315 minecraft:pearlescent_froglight
setblock 293 295 306 minecraft:pearlescent_froglight
setblock 293 295 308 minecraft:pearlescent_froglight
setblock 293 295 310 minecraft:pearlescent_froglight
setblock 293 295 312 minecraft:pearlescent_froglight
setblock 293 295 314 minecraft:pearlescent_froglight
setblock 293 295 316 minecraft:pearlescent_froglight
setblock 294 295 307 minecraft:pearlescent_froglight
setblock 294 295 309 minecraft:pearlescent_froglight
setblock 294 295 311 minecraft:pearlescent_froglight
setblock 294 295 313 minecraft:pearlescent_froglight
setblock 294 295 315 minecraft:pearlescent_froglight
setblock 295 295 306 minecraft:pearlescent_froglight
setblock 295 295 308 minecraft:pearlescent_froglight
setblock 295 295 310 minecraft:pearlescent_froglight
setblock 295 295 312 minecraft:pearlescent_froglight
setblock 295 295 314 minecraft:pearlescent_froglight
setblock 295 295 316 minecraft:pearlescent_froglight
setblock 296 295 307 minecraft:pearlescent_froglight
setblock 296 295 309 minecraft:pearlescent_froglight
setblock 296 295 311 minecraft:pearlescent_froglight
setblock 296 295 313 minecraft:pearlescent_froglight
setblock 296 295 315 minecraft:pearlescent_froglight
setblock 297 295 306 minecraft:pearlescent_froglight
setblock 297 295 308 minecraft:pearlescent_froglight
setblock 297 295 310 minecraft:pearlescent_froglight
setblock 297 295 312 minecraft:pearlescent_froglight
setblock 297 295 314 minecraft:pearlescent_froglight
setblock 297 295 316 minecraft:pearlescent_froglight
setblock 298 295 307 minecraft:pearlescent_froglight
setblock 298 295 309 minecraft:pearlescent_froglight
setblock 298 295 311 minecraft:pearlescent_froglight
setblock 298 295 313 minecraft:pearlescent_froglight
setblock 298 295 315 minecraft:pearlescent_froglight
setblock 299 295 278 minecraft:light[level=12]
setblock 299 295 285 minecraft:light[level=12]
setblock 299 295 292 minecraft:light[level=12]
setblock 299 295 299 minecraft:light[level=12]
setblock 299 295 306 minecraft:pearlescent_froglight
setblock 299 295 308 minecraft:pearlescent_froglight
setblock 299 295 310 minecraft:pearlescent_froglight
setblock 299 295 312 minecraft:pearlescent_froglight
setblock 299 295 314 minecraft:pearlescent_froglight
setblock 299 295 316 minecraft:pearlescent_froglight
fill 300 295 275 301 308 275 minecraft:light_gray_concrete
setblock 302 295 275 minecraft:sea_lantern
fill 303 295 275 308 308 275 minecraft:light_gray_concrete
setblock 306 295 278 minecraft:light[level=12]
setblock 306 295 285 minecraft:light[level=12]
setblock 306 295 292 minecraft:light[level=12]
setblock 306 295 299 minecraft:light[level=12]
setblock 306 295 306 minecraft:light[level=12]
setblock 306 295 313 minecraft:light[level=12]
setblock 313 295 278 minecraft:light[level=12]
setblock 313 295 285 minecraft:light[level=12]
setblock 313 295 292 minecraft:light[level=12]
setblock 313 295 299 minecraft:light[level=12]
setblock 313 295 306 minecraft:light[level=12]
setblock 313 295 313 minecraft:light[level=12]
setblock 320 295 278 minecraft:light[level=12]
setblock 320 295 285 minecraft:light[level=12]
setblock 320 295 306 minecraft:light[level=12]
setblock 320 295 313 minecraft:light[level=12]
fill 291 296 306 291 297 306 minecraft:iron_block
fill 291 296 308 291 297 308 minecraft:iron_block
fill 291 296 310 291 297 310 minecraft:iron_block
fill 291 296 312 291 297 312 minecraft:iron_block
fill 291 296 314 291 297 314 minecraft:iron_block
fill 291 296 316 291 297 316 minecraft:iron_block
fill 292 296 307 292 297 307 minecraft:iron_block
fill 292 296 309 292 297 309 minecraft:iron_block
fill 292 296 311 292 297 311 minecraft:iron_block
fill 292 296 313 292 297 313 minecraft:iron_block
fill 292 296 315 292 297 315 minecraft:iron_block
fill 293 296 306 293 297 306 minecraft:iron_block
fill 293 296 308 293 297 308 minecraft:iron_block
fill 293 296 310 293 297 310 minecraft:iron_block
fill 293 296 312 293 297 312 minecraft:iron_block
fill 293 296 314 293 297 314 minecraft:iron_block
fill 293 296 316 293 297 316 minecraft:iron_block
fill 294 296 307 294 297 307 minecraft:iron_block
fill 294 296 309 294 297 309 minecraft:iron_block
fill 294 296 311 294 297 311 minecraft:iron_block
fill 294 296 313 294 297 313 minecraft:iron_block
fill 294 296 315 294 297 315 minecraft:iron_block
fill 295 296 306 295 297 306 minecraft:iron_block
fill 295 296 308 295 297 308 minecraft:iron_block
fill 295 296 310 295 297 310 minecraft:iron_block
fill 295 296 312 295 297 312 minecraft:iron_block
fill 295 296 314 295 297 314 minecraft:iron_block
fill 295 296 316 295 297 316 minecraft:iron_block
fill 296 296 307 296 297 307 minecraft:iron_block
fill 296 296 309 296 297 309 minecraft:iron_block
fill 296 296 311 296 297 311 minecraft:iron_block
fill 296 296 313 296 297 313 minecraft:iron_block
fill 296 296 315 296 297 315 minecraft:iron_block
fill 297 296 306 297 297 306 minecraft:iron_block
fill 297 296 308 297 297 308 minecraft:iron_block
fill 297 296 310 297 297 310 minecraft:iron_block
fill 297 296 312 297 297 312 minecraft:iron_block
fill 297 296 314 297 297 314 minecraft:iron_block
fill 297 296 316 297 297 316 minecraft:iron_block
fill 298 296 307 298 297 307 minecraft:iron_block
fill 298 296 309 298 297 309 minecraft:iron_block
fill 298 296 311 298 297 311 minecraft:iron_block
fill 298 296 313 298 297 313 minecraft:iron_block
fill 298 296 315 298 297 315 minecraft:iron_block
fill 299 296 306 299 297 306 minecraft:iron_block
fill 299 296 308 299 297 308 minecraft:iron_block
fill 299 296 310 299 297 310 minecraft:iron_block
fill 299 296 312 299 297 312 minecraft:iron_block
fill 299 296 314 299 297 314 minecraft:iron_block
fill 299 296 316 299 297 316 minecraft:iron_block
fill 302 296 275 302 308 275 minecraft:light_gray_concrete
fill 283 297 280 283 297 283 minecraft:iron_block
fill 283 297 290 283 297 293 minecraft:iron_block
fill 283 297 300 283 297 303 minecraft:iron_block
fill 283 297 310 283 297 313 minecraft:iron_block
fill 284 297 276 287 297 276 minecraft:iron_block
setblock 285 297 278 minecraft:light[level=15]
setblock 285 297 286 minecraft:light[level=15]
setblock 285 297 294 minecraft:light[level=15]
setblock 285 297 302 minecraft:light[level=15]
setblock 285 297 310 minecraft:light[level=15]
fill 287 297 316 290 297 316 minecraft:iron_block
setblock 293 297 278 minecraft:light[level=15]
setblock 293 297 286 minecraft:light[level=15]
setblock 293 297 294 minecraft:light[level=15]
setblock 293 297 302 minecraft:light[level=15]
fill 294 297 276 297 297 276 minecraft:iron_block
setblock 300 297 316 minecraft:iron_block
setblock 301 297 278 minecraft:light[level=15]
setblock 301 297 286 minecraft:light[level=15]
setblock 301 297 294 minecraft:light[level=15]
setblock 301 297 302 minecraft:light[level=15]
setblock 301 297 310 minecraft:light[level=15]
fill 304 297 276 307 297 276 minecraft:iron_block
fill 304 297 311 304 297 313 minecraft:iron_block
fill 305 297 311 306 297 311 minecraft:iron_block
fill 305 297 313 305 298 315 minecraft:iron_block
fill 306 297 312 306 297 313 minecraft:iron_block
fill 307 297 316 310 297 316 minecraft:iron_block
setblock 309 297 278 minecraft:light[level=15]
setblock 309 297 286 minecraft:light[level=15]
setblock 309 297 294 minecraft:light[level=15]
setblock 309 297 302 minecraft:light[level=15]
setblock 309 297 310 minecraft:light[level=15]
fill 314 297 276 317 297 276 minecraft:iron_block
setblock 317 297 278 minecraft:light[level=15]
setblock 317 297 286 minecraft:light[level=15]
setblock 317 297 294 minecraft:light[level=15]
setblock 317 297 302 minecraft:light[level=15]
setblock 317 297 310 minecraft:light[level=15]
fill 317 297 316 320 297 316 minecraft:iron_block
fill 323 297 277 323 297 280 minecraft:iron_block
fill 323 297 287 323 297 290 minecraft:iron_block
fill 323 297 297 323 297 300 minecraft:iron_block
fill 323 297 307 323 297 310 minecraft:iron_block
setblock 291 298 306 minecraft:pearlescent_froglight
setblock 291 298 308 minecraft:pearlescent_froglight
setblock 291 298 310 minecraft:pearlescent_froglight
setblock 291 298 312 minecraft:pearlescent_froglight
setblock 291 298 314 minecraft:pearlescent_froglight
setblock 291 298 316 minecraft:pearlescent_froglight
setblock 292 298 307 minecraft:pearlescent_froglight
setblock 292 298 309 minecraft:pearlescent_froglight
setblock 292 298 311 minecraft:pearlescent_froglight
setblock 292 298 313 minecraft:pearlescent_froglight
setblock 292 298 315 minecraft:pearlescent_froglight
setblock 293 298 306 minecraft:pearlescent_froglight
setblock 293 298 308 minecraft:pearlescent_froglight
setblock 293 298 310 minecraft:pearlescent_froglight
setblock 293 298 312 minecraft:pearlescent_froglight
setblock 293 298 314 minecraft:pearlescent_froglight
setblock 293 298 316 minecraft:pearlescent_froglight
setblock 294 298 307 minecraft:pearlescent_froglight
setblock 294 298 309 minecraft:pearlescent_froglight
setblock 294 298 311 minecraft:pearlescent_froglight
setblock 294 298 313 minecraft:pearlescent_froglight
setblock 294 298 315 minecraft:pearlescent_froglight
setblock 295 298 306 minecraft:pearlescent_froglight
setblock 295 298 308 minecraft:pearlescent_froglight
setblock 295 298 310 minecraft:pearlescent_froglight
setblock 295 298 312 minecraft:pearlescent_froglight
setblock 295 298 314 minecraft:pearlescent_froglight
setblock 295 298 316 minecraft:pearlescent_froglight
setblock 296 298 307 minecraft:pearlescent_froglight
setblock 296 298 309 minecraft:pearlescent_froglight
setblock 296 298 311 minecraft:pearlescent_froglight
setblock 296 298 313 minecraft:pearlescent_froglight
setblock 296 298 315 minecraft:pearlescent_froglight
setblock 297 298 306 minecraft:pearlescent_froglight
setblock 297 298 308 minecraft:pearlescent_froglight
setblock 297 298 310 minecraft:pearlescent_froglight
setblock 297 298 312 minecraft:pearlescent_froglight
setblock 297 298 314 minecraft:pearlescent_froglight
setblock 297 298 316 minecraft:pearlescent_froglight
setblock 298 298 307 minecraft:pearlescent_froglight
setblock 298 298 309 minecraft:pearlescent_froglight
setblock 298 298 311 minecraft:pearlescent_froglight
setblock 298 298 313 minecraft:pearlescent_froglight
setblock 298 298 315 minecraft:pearlescent_froglight
setblock 299 298 306 minecraft:pearlescent_froglight
setblock 299 298 308 minecraft:pearlescent_froglight
setblock 299 298 310 minecraft:pearlescent_froglight
setblock 299 298 312 minecraft:pearlescent_froglight
setblock 299 298 314 minecraft:pearlescent_froglight
setblock 299 298 316 minecraft:pearlescent_froglight
fill 290 299 317 291 308 317 minecraft:light_gray_concrete
setblock 291 299 306 minecraft:iron_block
setblock 291 299 308 minecraft:iron_block
setblock 291 299 310 minecraft:iron_block
setblock 291 299 312 minecraft:iron_block
setblock 291 299 314 minecraft:iron_block
setblock 291 299 316 minecraft:iron_block
setblock 292 299 307 minecraft:iron_block
setblock 292 299 309 minecraft:iron_block
setblock 292 299 311 minecraft:iron_block
setblock 292 299 313 minecraft:iron_block
setblock 292 299 315 minecraft:iron_block
setblock 292 299 317 minecraft:sea_lantern
setblock 293 299 306 minecraft:iron_block
setblock 293 299 308 minecraft:iron_block
setblock 293 299 310 minecraft:iron_block
setblock 293 299 312 minecraft:iron_block
setblock 293 299 314 minecraft:iron_block
setblock 293 299 316 minecraft:iron_block
fill 293 299 317 295 308 317 minecraft:light_gray_concrete
setblock 294 299 307 minecraft:iron_block
setblock 294 299 309 minecraft:iron_block
setblock 294 299 311 minecraft:iron_block
setblock 294 299 313 minecraft:iron_block
setblock 294 299 315 minecraft:iron_block
setblock 295 299 306 minecraft:iron_block
setblock 295 299 308 minecraft:iron_block
setblock 295 299 310 minecraft:iron_block
setblock 295 299 312 minecraft:iron_block
setblock 295 299 314 minecraft:iron_block
fill 295 299 316 295 300 316 minecraft:iron_block
setblock 296 299 307 minecraft:iron_block
setblock 296 299 309 minecraft:iron_block
setblock 296 299 311 minecraft:iron_block
setblock 296 299 313 minecraft:iron_block
setblock 296 299 315 minecraft:iron_block
setblock 296 299 317 minecraft:sea_lantern
setblock 297 299 306 minecraft:iron_block
setblock 297 299 308 minecraft:iron_block
setblock 297 299 310 minecraft:iron_block
setblock 297 299 312 minecraft:iron_block
setblock 297 299 314 minecraft:iron_block
setblock 297 299 316 minecraft:iron_block
fill 297 299 317 299 308 317 minecraft:light_gray_concrete
setblock 298 299 307 minecraft:iron_block
setblock 298 299 309 minecraft:iron_block
setblock 298 299 311 minecraft:iron_block
setblock 298 299 313 minecraft:iron_block
setblock 298 299 315 minecraft:iron_block
setblock 299 299 306 minecraft:iron_block
setblock 299 299 308 minecraft:iron_block
setblock 299 299 310 minecraft:iron_block
setblock 299 299 312 minecraft:iron_block
setblock 299 299 314 minecraft:iron_block
setblock 299 299 316 minecraft:iron_block
setblock 309 299 275 minecraft:redstone_block
fill 310 299 275 314 308 275 minecraft:light_gray_concrete
setblock 283 300 278 minecraft:iron_block
setblock 283 300 288 minecraft:iron_block
setblock 283 300 298 minecraft:iron_block
setblock 283 300 308 minecraft:iron_block
setblock 285 300 316 minecraft:iron_block
setblock 289 300 276 minecraft:iron_block
fill 292 300 317 292 308 317 minecraft:light_gray_concrete
fill 296 300 317 296 308 317 minecraft:light_gray_concrete
setblock 299 300 276 minecraft:iron_block
setblock 305 300 316 minecraft:iron_block
fill 309 300 275 309 308 275 minecraft:light_gray_concrete
setblock 309 300 276 minecraft:iron_block
setblock 315 300 316 minecraft:iron_block
setblock 319 300 276 minecraft:iron_block
setblock 323 300 282 minecraft:iron_block
setblock 323 300 292 minecraft:iron_block
setblock 323 300 302 minecraft:iron_block
setblock 323 300 312 minecraft:iron_block
setblock 285 301 278 minecraft:light[level=12]
setblock 285 301 285 minecraft:light[level=12]
setblock 285 301 292 minecraft:light[level=12]
setblock 285 301 299 minecraft:light[level=12]
setblock 285 301 306 minecraft:light[level=12]
setblock 285 301 313 minecraft:light[level=12]
setblock 292 301 278 minecraft:light[level=12]
setblock 292 301 285 minecraft:light[level=12]
setblock 292 301 292 minecraft:light[level=12]
setblock 292 301 299 minecraft:light[level=12]
setblock 292 301 306 minecraft:light[level=12]
setblock 292 301 313 minecraft:light[level=12]
setblock 299 301 278 minecraft:light[level=12]
setblock 299 301 285 minecraft:light[level=12]
setblock 299 301 292 minecraft:light[level=12]
setblock 299 301 299 minecraft:light[level=12]
setblock 299 301 306 minecraft:light[level=12]
setblock 299 301 313 minecraft:light[level=12]
setblock 306 301 278 minecraft:light[level=12]
setblock 306 301 285 minecraft:light[level=12]
setblock 306 301 292 minecraft:light[level=12]
setblock 306 301 299 minecraft:light[level=12]
setblock 306 301 306 minecraft:light[level=12]
setblock 306 301 313 minecraft:light[level=12]
setblock 313 301 278 minecraft:light[level=12]
setblock 313 301 285 minecraft:light[level=12]
setblock 313 301 292 minecraft:light[level=12]
setblock 313 301 299 minecraft:light[level=12]
setblock 313 301 306 minecraft:light[level=12]
setblock 313 301 313 minecraft:light[level=12]
setblock 320 301 278 minecraft:light[level=12]
setblock 320 301 285 minecraft:light[level=12]
setblock 320 301 292 minecraft:light[level=12]
setblock 320 301 299 minecraft:light[level=12]
setblock 320 301 306 minecraft:light[level=12]
setblock 320 301 313 minecraft:light[level=12]
fill 282 302 311 282 306 313 minecraft:light_gray_concrete
setblock 282 302 314 minecraft:redstone_block
fill 324 302 286 324 308 288 minecraft:light_gray_concrete
setblock 324 302 289 minecraft:sea_lantern
fill 324 302 290 324 308 291 minecraft:light_gray_concrete
setblock 324 302 292 minecraft:redstone_block
fill 324 302 293 324 308 295 minecraft:light_gray_concrete
fill 282 303 314 282 308 314 minecraft:light_gray_concrete
fill 324 303 289 324 308 289 minecraft:light_gray_concrete
fill 324 303 292 324 308 292 minecraft:light_gray_concrete
fill 320 305 317 321 308 317 minecraft:light_gray_concrete
setblock 322 305 317 minecraft:sea_lantern
fill 323 305 317 324 308 317 minecraft:light_gray_concrete
fill 324 305 280 324 308 281 minecraft:light_gray_concrete
setblock 324 305 282 minecraft:redstone_block
fill 324 305 283 324 305 285 minecraft:light_gray_concrete
setblock 324 305 306 minecraft:sea_lantern
fill 324 305 307 324 308 309 minecraft:light_gray_concrete
fill 322 306 317 322 308 317 minecraft:light_gray_concrete
fill 324 306 282 324 308 283 minecraft:light_gray_concrete
setblock 324 306 284 minecraft:redstone_block
fill 324 306 285 324 308 285 minecraft:light_gray_concrete
fill 324 306 306 324 308 306 minecraft:light_gray_concrete
setblock 282 307 311 minecraft:sea_lantern
fill 282 307 312 282 308 313 minecraft:light_gray_concrete
fill 324 307 284 324 308 284 minecraft:light_gray_concrete
setblock 282 308 311 minecraft:light_gray_concrete
