fill 103 214 512 103 216 512 minecraft:blackstone
fill 103 214 531 103 214 533 minecraft:gold_block
fill 103 214 549 104 214 549 minecraft:blackstone
setblock 103 214 551 minecraft:smooth_basalt
fill 104 214 511 104 216 511 minecraft:blackstone
fill 104 214 513 105 214 513 minecraft:blackstone
setblock 104 214 550 minecraft:smooth_basalt
fill 104 214 551 104 216 551 minecraft:blackstone
fill 105 214 514 105 214 516 minecraft:gold_block
setblock 105 214 549 minecraft:smooth_basalt
fill 105 214 550 105 216 550 minecraft:blackstone
setblock 106 214 513 minecraft:smooth_basalt
setblock 106 214 548 minecraft:smooth_basalt
fill 106 214 549 109 214 549 minecraft:blackstone
setblock 107 214 512 minecraft:smooth_basalt
fill 107 214 513 107 215 513 minecraft:blackstone
fill 107 214 548 109 215 548 minecraft:blackstone
setblock 108 214 511 minecraft:smooth_basalt
fill 108 214 512 108 216 512 minecraft:blackstone
setblock 108 214 551 minecraft:smooth_basalt
fill 109 214 511 109 216 511 minecraft:blackstone
setblock 109 214 550 minecraft:smooth_basalt
fill 109 214 551 109 216 551 minecraft:blackstone
setblock 110 214 549 minecraft:smooth_basalt
fill 110 214 550 110 216 550 minecraft:blackstone
fill 111 214 549 111 216 549 minecraft:blackstone
setblock 113 214 511 minecraft:smooth_basalt
fill 113 214 549 113 215 549 minecraft:blackstone
setblock 113 214 551 minecraft:smooth_basalt
fill 114 214 511 114 216 511 minecraft:blackstone
setblock 114 214 550 minecraft:smooth_basalt
fill 114 214 551 117 214 551 minecraft:blackstone
fill 115 214 550 118 214 550 minecraft:blackstone
fill 118 214 549 119 214 549 minecraft:blackstone
setblock 118 214 551 minecraft:smooth_basalt
setblock 119 214 550 minecraft:smooth_basalt
fill 119 214 551 119 216 551 minecraft:blackstone
setblock 120 214 549 minecraft:smooth_basalt
fill 120 214 550 123 214 550 minecraft:blackstone
fill 121 214 511 122 214 511 minecraft:blackstone
setblock 121 214 548 minecraft:smooth_basalt
fill 121 214 549 124 214 549 minecraft:blackstone
fill 122 214 548 125 214 548 minecraft:blackstone
setblock 123 214 511 minecraft:smooth_basalt
setblock 123 214 551 minecraft:smooth_basalt
fill 124 214 511 124 216 511 minecraft:blackstone
setblock 124 214 550 minecraft:smooth_basalt
fill 124 214 551 124 216 551 minecraft:blackstone
fill 125 214 547 125 215 547 minecraft:blackstone
setblock 125 214 549 minecraft:smooth_basalt
fill 125 214 550 125 216 550 minecraft:blackstone
setblock 126 214 548 minecraft:smooth_basalt
fill 126 214 549 126 216 549 minecraft:blackstone
fill 127 214 548 127 216 548 minecraft:blackstone
setblock 128 214 511 minecraft:smooth_basalt
setblock 128 214 551 minecraft:smooth_basalt
setblock 129 214 550 minecraft:smooth_basalt
fill 129 214 551 129 216 551 minecraft:blackstone
setblock 130 214 549 minecraft:smooth_basalt
fill 130 214 550 130 216 550 minecraft:blackstone
setblock 133 214 526 minecraft:smooth_basalt
fill 133 214 527 133 216 527 minecraft:blackstone
setblock 134 214 525 minecraft:smooth_basalt
fill 134 214 526 134 216 526 minecraft:blackstone
setblock 134 214 529 minecraft:blackstone
setblock 134 214 530 minecraft:smooth_basalt
setblock 134 214 545 minecraft:smooth_basalt
setblock 134 214 546 minecraft:blackstone
setblock 135 214 519 minecraft:smooth_basalt
fill 135 214 520 135 216 520 minecraft:blackstone
setblock 135 214 524 minecraft:smooth_basalt
fill 135 214 525 135 216 525 minecraft:blackstone
setblock 135 214 529 minecraft:smooth_basalt
fill 135 214 530 135 216 530 minecraft:blackstone
setblock 135 214 533 minecraft:blackstone
setblock 135 214 534 minecraft:smooth_basalt
setblock 135 214 539 minecraft:smooth_basalt
setblock 135 214 540 minecraft:blackstone
setblock 135 214 544 minecraft:smooth_basalt
fill 135 214 545 135 216 545 minecraft:blackstone
setblock 135 214 549 minecraft:smooth_basalt
setblock 95 215 518 minecraft:smooth_basalt
fill 95 215 519 95 216 519 minecraft:blackstone
setblock 95 215 523 minecraft:smooth_basalt
fill 95 215 524 95 216 524 minecraft:blackstone
setblock 95 215 527 minecraft:blackstone
setblock 95 215 528 minecraft:smooth_basalt
fill 95 215 529 96 216 529 minecraft:blackstone
fill 95 215 546 95 215 547 minecraft:blackstone
setblock 95 215 548 minecraft:smooth_basalt
setblock 96 215 522 minecraft:smooth_basalt
fill 96 215 523 96 216 523 minecraft:blackstone
setblock 96 215 527 minecraft:smooth_basalt
fill 96 215 528 96 216 528 minecraft:blackstone
setblock 97 215 511 minecraft:smooth_basalt
setblock 97 215 526 minecraft:smooth_basalt
fill 98 215 511 98 216 511 minecraft:blackstone
fill 98 215 531 98 215 532 minecraft:gold_block
fill 98 215 551 101 215 551 minecraft:blackstone
setblock 100 215 512 minecraft:blackstone
fill 100 215 534 101 215 534 minecraft:gold_block
fill 100 215 550 102 215 550 minecraft:blackstone
setblock 101 215 512 minecraft:smooth_basalt
setblock 101 215 515 minecraft:gold_block
setblock 102 215 511 minecraft:smooth_basalt
fill 102 215 512 102 216 512 minecraft:blackstone
setblock 102 215 530 minecraft:gold_block
fill 102 215 549 103 215 549 minecraft:blackstone
setblock 102 215 551 minecraft:smooth_basalt
fill 103 215 511 103 216 511 minecraft:blackstone
fill 103 215 513 104 215 513 minecraft:blackstone
setblock 103 215 517 minecraft:gold_block
fill 103 215 531 103 215 532 minecraft:gold_block
setblock 103 215 550 minecraft:smooth_basalt
fill 103 215 551 103 216 551 minecraft:blackstone
setblock 104 215 548 minecraft:blackstone
setblock 104 215 549 minecraft:smooth_basalt
fill 104 215 550 104 216 550 minecraft:blackstone
setblock 105 215 513 minecraft:smooth_basalt
fill 105 215 514 105 215 515 minecraft:gold_block
setblock 105 215 548 minecraft:smooth_basalt
fill 105 215 549 108 215 549 minecraft:blackstone
setblock 106 215 512 minecraft:smooth_basalt
fill 106 215 513 106 216 513 minecraft:blackstone
fill 106 215 548 106 216 548 minecraft:blackstone
setblock 107 215 511 minecraft:smooth_basalt
fill 107 215 512 107 216 512 minecraft:blackstone
setblock 107 215 551 minecraft:smooth_basalt
fill 108 215 511 108 216 511 minecraft:blackstone
setblock 108 215 550 minecraft:smooth_basalt
fill 108 215 551 108 216 551 minecraft:blackstone
setblock 109 215 549 minecraft:smooth_basalt
fill 109 215 550 109 216 550 minecraft:blackstone
fill 110 215 549 110 216 549 minecraft:blackstone
setblock 112 215 511 minecraft:smooth_basalt
setblock 112 215 551 minecraft:smooth_basalt
fill 113 215 511 113 216 511 minecraft:blackstone
setblock 113 215 550 minecraft:smooth_basalt
fill 113 215 551 116 215 551 minecraft:blackstone
setblock 114 215 549 minecraft:smooth_basalt
fill 114 215 550 117 215 550 minecraft:blackstone
fill 115 215 546 117 216 546 minecraft:smooth_basalt
fill 115 215 549 118 215 549 minecraft:blackstone
fill 116 215 545 116 216 545 minecraft:smooth_basalt
fill 116 215 547 116 216 547 minecraft:smooth_basalt
setblock 117 215 551 minecraft:smooth_basalt
setblock 118 215 550 minecraft:smooth_basalt
fill 118 215 551 118 216 551 minecraft:blackstone
setblock 119 215 549 minecraft:smooth_basalt
fill 119 215 550 122 215 550 minecraft:blackstone
fill 120 215 511 121 215 511 minecraft:blackstone
setblock 120 215 548 minecraft:smooth_basalt
fill 120 215 549 123 215 549 minecraft:blackstone
fill 121 215 548 124 215 548 minecraft:blackstone
setblock 122 215 511 minecraft:smooth_basalt
setblock 122 215 551 minecraft:smooth_basalt
fill 123 215 511 123 216 511 minecraft:blackstone
setblock 123 215 550 minecraft:smooth_basalt
fill 123 215 551 123 216 551 minecraft:blackstone
setblock 124 215 547 minecraft:blackstone
setblock 124 215 549 minecraft:smooth_basalt
fill 124 215 550 124 216 550 minecraft:blackstone
setblock 125 215 548 minecraft:smooth_basalt
fill 125 215 549 125 216 549 minecraft:blackstone
setblock 126 215 511 minecraft:blackstone
fill 126 215 548 126 216 548 minecraft:blackstone
setblock 127 215 511 minecraft:smooth_basalt
setblock 127 215 551 minecraft:smooth_basalt
fill 128 215 511 128 216 511 minecraft:blackstone
setblock 128 215 550 minecraft:smooth_basalt
fill 128 215 551 128 216 551 minecraft:blackstone
setblock 129 215 549 minecraft:smooth_basalt
fill 129 215 550 129 216 550 minecraft:blackstone
setblock 131 215 551 minecraft:blackstone
setblock 132 215 551 minecraft:smooth_basalt
setblock 133 215 525 minecraft:smooth_basalt
fill 133 215 526 133 216 526 minecraft:blackstone
fill 133 215 528 133 216 528 minecraft:blackstone
setblock 134 215 524 minecraft:smooth_basalt
fill 134 215 525 134 216 525 minecraft:blackstone
setblock 134 215 529 minecraft:smooth_basalt
fill 134 215 530 134 216 531 minecraft:blackstone
setblock 135 215 523 minecraft:smooth_basalt
fill 135 215 524 135 216 524 minecraft:blackstone
setblock 135 215 528 minecraft:smooth_basalt
fill 135 215 529 135 216 529 minecraft:blackstone
setblock 135 215 533 minecraft:smooth_basalt
fill 135 215 534 135 216 534 minecraft:blackstone
setblock 135 215 543 minecraft:smooth_basalt
fill 135 215 544 135 216 544 minecraft:blackstone
setblock 135 215 547 minecraft:blackstone
setblock 135 215 548 minecraft:smooth_basalt
fill 135 215 549 135 216 549 minecraft:blackstone
setblock 95 216 518 minecraft:blackstone
setblock 95 216 522 minecraft:smooth_basalt
setblock 95 216 523 minecraft:blackstone
setblock 95 216 527 minecraft:smooth_basalt
setblock 95 216 528 minecraft:blackstone
fill 95 216 548 95 216 549 minecraft:blackstone
setblock 96 216 511 minecraft:smooth_basalt
setblock 96 216 521 minecraft:smooth_basalt
setblock 96 216 522 minecraft:blackstone
setblock 96 216 526 minecraft:smooth_basalt
setblock 96 216 527 minecraft:blackstone
setblock 97 216 511 minecraft:blackstone
setblock 97 216 525 minecraft:smooth_basalt
setblock 97 216 526 minecraft:blackstone
fill 97 216 551 100 216 551 minecraft:blackstone
setblock 99 216 512 minecraft:blackstone
fill 99 216 550 101 216 550 minecraft:blackstone
setblock 100 216 512 minecraft:smooth_basalt
setblock 101 216 511 minecraft:smooth_basalt
setblock 101 216 512 minecraft:blackstone
fill 101 216 549 102 216 549 minecraft:blackstone
setblock 101 216 551 minecraft:smooth_basalt
setblock 102 216 511 minecraft:blackstone
fill 102 216 513 103 216 513 minecraft:blackstone
setblock 102 216 550 minecraft:smooth_basalt
setblock 102 216 551 minecraft:blackstone
setblock 103 216 549 minecraft:smooth_basalt
setblock 103 216 550 minecraft:blackstone
setblock 104 216 513 minecraft:smooth_basalt
setblock 104 216 548 minecraft:smooth_basalt
fill 104 216 549 107 216 549 minecraft:blackstone
setblock 105 216 512 minecraft:smooth_basalt
setblock 105 216 513 minecraft:blackstone
setblock 105 216 548 minecraft:blackstone
setblock 106 216 511 minecraft:smooth_basalt
setblock 106 216 512 minecraft:blackstone
setblock 106 216 551 minecraft:smooth_basalt
setblock 107 216 511 minecraft:blackstone
fill 107 216 548 108 216 548 minecraft:blackstone
setblock 107 216 550 minecraft:smooth_basalt
setblock 107 216 551 minecraft:blackstone
setblock 108 216 549 minecraft:smooth_basalt
setblock 108 216 550 minecraft:blackstone
setblock 109 216 549 minecraft:blackstone
setblock 110 216 512 minecraft:smooth_basalt
setblock 111 216 511 minecraft:smooth_basalt
setblock 111 216 551 minecraft:smooth_basalt
setblock 112 216 511 minecraft:blackstone
setblock 112 216 550 minecraft:smooth_basalt
fill 112 216 551 115 216 551 minecraft:blackstone
setblock 113 216 549 minecraft:smooth_basalt
fill 113 216 550 116 216 550 minecraft:blackstone
fill 114 216 549 117 216 549 minecraft:blackstone
setblock 116 216 551 minecraft:smooth_basalt
setblock 117 216 550 minecraft:smooth_basalt
setblock 117 216 551 minecraft:blackstone
fill 118 216 511 120 216 511 minecraft:blackstone
setblock 118 216 549 minecraft:smooth_basalt
fill 118 216 550 121 216 550 minecraft:blackstone
fill 119 216 549 122 216 549 minecraft:blackstone
fill 120 216 548 123 216 548 minecraft:blackstone
setblock 121 216 511 minecraft:smooth_basalt
setblock 121 216 551 minecraft:smooth_basalt
setblock 122 216 511 minecraft:blackstone
setblock 122 216 550 minecraft:smooth_basalt
setblock 122 216 551 minecraft:blackstone
setblock 123 216 549 minecraft:smooth_basalt
setblock 123 216 550 minecraft:blackstone
setblock 124 216 548 minecraft:smooth_basalt
setblock 124 216 549 minecraft:blackstone
setblock 125 216 548 minecraft:blackstone
setblock 126 216 511 minecraft:smooth_basalt
setblock 126 216 551 minecraft:smooth_basalt
setblock 127 216 511 minecraft:blackstone
setblock 127 216 550 minecraft:smooth_basalt
setblock 127 216 551 minecraft:blackstone
setblock 128 216 549 minecraft:smooth_basalt
setblock 128 216 550 minecraft:blackstone
setblock 129 216 549 minecraft:blackstone
setblock 131 216 551 minecraft:smooth_basalt
setblock 132 216 551 minecraft:blackstone
setblock 134 216 523 minecraft:smooth_basalt
setblock 134 216 524 minecraft:blackstone
setblock 134 216 528 minecraft:smooth_basalt
setblock 134 216 529 minecraft:blackstone
setblock 135 216 522 minecraft:smooth_basalt
setblock 135 216 523 minecraft:blackstone
setblock 135 216 527 minecraft:smooth_basalt
setblock 135 216 528 minecraft:blackstone
setblock 135 216 532 minecraft:smooth_basalt
setblock 135 216 533 minecraft:blackstone
setblock 135 216 543 minecraft:blackstone
setblock 135 216 547 minecraft:smooth_basalt
setblock 135 216 548 minecraft:blackstone
setblock 97 221 513 minecraft:light[level=12]
setblock 97 221 521 minecraft:light[level=12]
setblock 97 221 529 minecraft:light[level=12]
setblock 97 221 537 minecraft:light[level=12]
setblock 97 221 545 minecraft:light[level=12]
setblock 105 221 513 minecraft:light[level=12]
setblock 105 221 521 minecraft:light[level=12]
setblock 105 221 529 minecraft:light[level=12]
setblock 105 221 537 minecraft:light[level=12]
setblock 105 221 545 minecraft:light[level=12]
setblock 113 221 513 minecraft:light[level=12]
setblock 113 221 521 minecraft:light[level=12]
setblock 113 221 529 minecraft:light[level=12]
setblock 113 221 537 minecraft:light[level=12]
setblock 113 221 545 minecraft:light[level=12]
setblock 121 221 513 minecraft:light[level=12]
setblock 121 221 521 minecraft:light[level=12]
setblock 121 221 529 minecraft:light[level=12]
setblock 121 221 537 minecraft:light[level=12]
setblock 121 221 545 minecraft:light[level=12]
setblock 129 221 513 minecraft:light[level=12]
setblock 129 221 521 minecraft:light[level=12]
setblock 129 221 529 minecraft:light[level=12]
setblock 129 221 537 minecraft:light[level=12]
setblock 129 221 545 minecraft:light[level=12]
fill 107 222 526 107 224 530 minecraft:gold_block
fill 108 222 524 108 224 527 minecraft:gold_block
fill 108 222 528 112 222 528 minecraft:blackstone
fill 108 222 529 108 224 532 minecraft:gold_block
fill 109 222 522 109 224 524 minecraft:gold_block
fill 109 222 525 113 222 527 minecraft:blackstone
fill 109 222 529 113 222 531 minecraft:blackstone
fill 109 222 532 109 224 534 minecraft:gold_block
fill 110 222 522 110 224 523 minecraft:gold_block
fill 110 222 524 120 223 524 minecraft:blackstone
fill 110 222 532 120 223 532 minecraft:blackstone
fill 110 222 533 110 224 534 minecraft:gold_block
fill 111 222 521 111 224 522 minecraft:gold_block
fill 111 222 523 119 223 523 minecraft:blackstone
fill 111 222 533 119 223 533 minecraft:blackstone
fill 111 222 534 111 224 535 minecraft:gold_block
fill 112 222 521 114 224 521 minecraft:gold_block
fill 112 222 522 118 223 522 minecraft:blackstone
fill 112 222 534 118 223 534 minecraft:blackstone
fill 112 222 535 114 224 535 minecraft:gold_block
fill 113 222 520 117 224 520 minecraft:gold_block
fill 113 222 536 117 224 536 minecraft:gold_block
fill 114 222 525 114 222 526 minecraft:blackstone
fill 114 222 530 114 222 531 minecraft:blackstone
fill 115 222 521 115 223 521 minecraft:blackstone
fill 115 222 525 121 222 525 minecraft:blackstone
fill 115 222 531 121 222 531 minecraft:blackstone
fill 115 222 535 115 223 535 minecraft:blackstone
fill 116 222 521 119 224 521 minecraft:gold_block
fill 116 222 526 121 222 526 minecraft:blackstone
fill 116 222 530 121 222 530 minecraft:blackstone
fill 116 222 535 119 224 535 minecraft:gold_block
fill 117 222 527 121 222 527 minecraft:blackstone
fill 117 222 529 121 222 529 minecraft:blackstone
fill 118 222 528 122 222 528 minecraft:blackstone
fill 119 222 522 121 224 522 minecraft:gold_block
fill 119 222 534 121 224 534 minecraft:gold_block
fill 120 222 523 121 224 523 minecraft:gold_block
fill 120 222 533 121 224 533 minecraft:gold_block
fill 121 222 524 122 224 524 minecraft:gold_block
fill 121 222 532 122 224 532 minecraft:gold_block
fill 122 222 525 122 224 527 minecraft:gold_block
fill 122 222 529 122 224 531 minecraft:gold_block
fill 123 222 526 123 224 530 minecraft:gold_block
fill 95 223 511 106 223 551 minecraft:smooth_basalt
fill 107 223 511 107 223 524 minecraft:smooth_basalt
setblock 107 223 525 minecraft:gold_block
setblock 107 223 531 minecraft:gold_block
fill 107 223 532 107 223 551 minecraft:smooth_basalt
fill 108 223 511 108 223 522 minecraft:smooth_basalt
setblock 108 223 523 minecraft:gold_block
fill 108 223 528 111 223 528 minecraft:blackstone
setblock 108 223 533 minecraft:gold_block
fill 108 223 534 108 223 551 minecraft:smooth_basalt
fill 109 223 511 109 223 521 minecraft:smooth_basalt
fill 109 223 525 111 223 527 minecraft:blackstone
fill 109 223 529 111 223 531 minecraft:blackstone
fill 109 223 535 109 223 551 minecraft:smooth_basalt
fill 110 223 511 111 223 520 minecraft:smooth_basalt
setblock 110 223 521 minecraft:gold_block
setblock 110 223 535 minecraft:gold_block
fill 110 223 536 111 223 551 minecraft:smooth_basalt
fill 112 223 511 135 223 519 minecraft:smooth_basalt
setblock 112 223 520 minecraft:gold_block
fill 112 223 525 112 223 526 minecraft:blackstone
fill 112 223 527 112 223 529 minecraft:shroomlight
fill 112 223 530 112 223 531 minecraft:blackstone
setblock 112 223 536 minecraft:gold_block
fill 112 223 537 135 223 551 minecraft:smooth_basalt
setblock 113 223 525 minecraft:blackstone
fill 113 223 526 113 223 527 minecraft:shroomlight
fill 113 223 529 113 223 530 minecraft:shroomlight
setblock 113 223 531 minecraft:blackstone
fill 114 223 525 114 223 526 minecraft:shroomlight
fill 114 223 530 114 223 531 minecraft:shroomlight
fill 115 223 525 116 223 525 minecraft:shroomlight
fill 115 223 531 116 223 531 minecraft:shroomlight
fill 116 223 526 117 223 526 minecraft:shroomlight
fill 116 223 530 117 223 530 minecraft:shroomlight
fill 117 223 525 121 223 525 minecraft:blackstone
fill 117 223 527 118 223 527 minecraft:shroomlight
fill 117 223 529 118 223 529 minecraft:shroomlight
fill 117 223 531 121 223 531 minecraft:blackstone
setblock 118 223 520 minecraft:gold_block
fill 118 223 526 121 223 526 minecraft:blackstone
setblock 118 223 528 minecraft:shroomlight
fill 118 223 530 121 223 530 minecraft:blackstone
setblock 118 223 536 minecraft:gold_block
fill 119 223 520 135 223 520 minecraft:smooth_basalt
fill 119 223 527 121 223 529 minecraft:blackstone
fill 119 223 536 135 223 536 minecraft:smooth_basalt
setblock 120 223 521 minecraft:gold_block
setblock 120 223 535 minecraft:gold_block
fill 121 223 521 135 223 521 minecraft:smooth_basalt
fill 121 223 535 135 223 535 minecraft:smooth_basalt
fill 122 223 522 135 223 522 minecraft:smooth_basalt
setblock 122 223 523 minecraft:gold_block
setblock 122 223 528 minecraft:blackstone
setblock 122 223 533 minecraft:gold_block
fill 122 223 534 135 223 534 minecraft:smooth_basalt
fill 123 223 523 135 223 524 minecraft:smooth_basalt
setblock 123 223 525 minecraft:gold_block
setblock 123 223 531 minecraft:gold_block
fill 123 223 532 135 223 533 minecraft:smooth_basalt
fill 124 223 525 135 223 531 minecraft:smooth_basalt
fill 108 224 528 109 224 528 minecraft:gold_block
fill 109 224 525 109 224 527 minecraft:gold_block
fill 109 224 529 109 224 531 minecraft:gold_block
fill 110 224 524 110 224 525 minecraft:gold_block
fill 110 224 531 110 224 532 minecraft:gold_block
fill 111 224 523 111 224 524 minecraft:gold_block
fill 111 224 532 111 224 533 minecraft:gold_block
fill 112 224 522 112 224 523 minecraft:gold_block
fill 112 224 533 112 224 534 minecraft:gold_block
fill 113 224 522 118 224 522 minecraft:gold_block
fill 113 224 534 118 224 534 minecraft:gold_block
setblock 115 224 521 minecraft:gold_block
setblock 115 224 535 minecraft:gold_block
fill 118 224 523 119 224 523 minecraft:gold_block
fill 118 224 533 119 224 533 minecraft:gold_block
fill 119 224 524 120 224 524 minecraft:gold_block
fill 119 224 532 120 224 532 minecraft:gold_block
fill 120 224 525 121 224 525 minecraft:gold_block
fill 120 224 531 121 224 531 minecraft:gold_block
fill 121 224 526 121 224 530 minecraft:gold_block
setblock 122 224 528 minecraft:gold_block
setblock 95 227 511 minecraft:smooth_basalt
fill 95 227 512 95 227 515 minecraft:blackstone
setblock 95 227 516 minecraft:smooth_basalt
fill 95 227 517 95 227 520 minecraft:blackstone
setblock 95 227 521 minecraft:smooth_basalt
fill 95 227 522 95 227 525 minecraft:blackstone
setblock 95 227 526 minecraft:smooth_basalt
fill 95 227 527 95 227 530 minecraft:blackstone
setblock 95 227 531 minecraft:smooth_basalt
fill 95 227 532 95 227 535 minecraft:blackstone
setblock 95 227 536 minecraft:smooth_basalt
fill 95 227 537 95 227 540 minecraft:blackstone
fill 95 227 547 95 227 550 minecraft:blackstone
setblock 95 227 551 minecraft:smooth_basalt
fill 96 227 511 96 227 514 minecraft:blackstone
setblock 96 227 515 minecraft:smooth_basalt
fill 96 227 516 96 227 519 minecraft:blackstone
setblock 96 227 520 minecraft:smooth_basalt
fill 96 227 521 96 229 522 minecraft:blackstone
fill 96 227 528 96 227 529 minecraft:blackstone
setblock 96 227 530 minecraft:smooth_basalt
fill 96 227 531 96 227 534 minecraft:blackstone
setblock 96 227 535 minecraft:smooth_basalt
fill 96 227 536 96 229 537 minecraft:blackstone
setblock 96 227 549 minecraft:blackstone
setblock 96 227 550 minecraft:smooth_basalt
fill 96 227 551 99 227 551 minecraft:blackstone
fill 97 227 511 97 227 513 minecraft:blackstone
setblock 97 227 514 minecraft:smooth_basalt
fill 97 227 515 97 227 518 minecraft:blackstone
setblock 97 227 519 minecraft:smooth_basalt
fill 97 227 550 100 227 550 minecraft:blackstone
fill 98 227 511 98 227 512 minecraft:blackstone
setblock 98 227 513 minecraft:smooth_basalt
fill 98 227 514 98 228 516 minecraft:blackstone
setblock 99 227 511 minecraft:blackstone
setblock 99 227 512 minecraft:smooth_basalt
fill 99 227 513 101 227 514 minecraft:blackstone
fill 99 227 549 100 228 549 minecraft:blackstone
setblock 100 227 511 minecraft:smooth_basalt
fill 100 227 512 103 227 512 minecraft:blackstone
setblock 100 227 551 minecraft:smooth_basalt
fill 101 227 511 104 227 511 minecraft:blackstone
setblock 101 227 550 minecraft:smooth_basalt
fill 101 227 551 104 227 551 minecraft:blackstone
setblock 102 227 513 minecraft:blackstone
setblock 102 227 514 minecraft:smooth_basalt
fill 102 227 550 105 227 550 minecraft:blackstone
setblock 103 227 513 minecraft:smooth_basalt
setblock 104 227 512 minecraft:smooth_basalt
fill 104 227 513 104 229 513 minecraft:blackstone
setblock 105 227 511 minecraft:smooth_basalt
fill 105 227 512 108 227 512 minecraft:blackstone
setblock 105 227 551 minecraft:smooth_basalt
fill 106 227 511 109 227 511 minecraft:blackstone
setblock 106 227 550 minecraft:smooth_basalt
fill 106 227 551 109 227 551 minecraft:blackstone
setblock 110 227 511 minecraft:smooth_basalt
setblock 110 227 551 minecraft:smooth_basalt
fill 111 227 511 114 227 511 minecraft:blackstone
fill 111 227 551 114 227 551 minecraft:blackstone
fill 112 227 550 115 227 550 minecraft:blackstone
setblock 113 227 512 minecraft:blackstone
setblock 114 227 512 minecraft:smooth_basalt
setblock 115 227 511 minecraft:smooth_basalt
fill 115 227 512 118 227 512 minecraft:blackstone
setblock 115 227 551 minecraft:smooth_basalt
fill 116 227 511 119 227 511 minecraft:blackstone
setblock 116 227 550 minecraft:smooth_basalt
fill 116 227 551 119 227 551 minecraft:blackstone
fill 117 227 550 120 227 550 minecraft:blackstone
setblock 119 227 512 minecraft:smooth_basalt
setblock 120 227 511 minecraft:smooth_basalt
fill 120 227 512 123 227 512 minecraft:blackstone
setblock 120 227 551 minecraft:smooth_basalt
fill 121 227 511 124 227 511 minecraft:blackstone
setblock 121 227 550 minecraft:smooth_basalt
fill 121 227 551 124 227 551 minecraft:blackstone
setblock 122 227 550 minecraft:blackstone
setblock 125 227 511 minecraft:smooth_basalt
fill 126 227 511 129 227 511 minecraft:blackstone
setblock 130 227 511 minecraft:smooth_basalt
fill 131 227 511 134 227 511 minecraft:blackstone
fill 132 227 512 133 227 512 minecraft:blackstone
setblock 133 227 532 minecraft:blackstone
setblock 133 227 533 minecraft:smooth_basalt
setblock 134 227 512 minecraft:smooth_basalt
fill 134 227 513 134 227 516 minecraft:blackstone
setblock 134 227 517 minecraft:smooth_basalt
fill 134 227 518 134 227 521 minecraft:blackstone
fill 134 227 525 134 227 526 minecraft:blackstone
setblock 134 227 527 minecraft:smooth_basalt
fill 134 227 528 134 227 531 minecraft:blackstone
setblock 134 227 532 minecraft:smooth_basalt
fill 134 227 533 134 227 536 minecraft:blackstone
setblock 134 227 537 minecraft:smooth_basalt
setblock 134 227 551 minecraft:blackstone
setblock 135 227 511 minecraft:smooth_basalt
fill 135 227 512 135 227 515 minecraft:blackstone
setblock 135 227 516 minecraft:smooth_basalt
fill 135 227 517 135 227 520 minecraft:blackstone
setblock 135 227 521 minecraft:smooth_basalt
fill 135 227 522 135 227 525 minecraft:blackstone
setblock 135 227 526 minecraft:smooth_basalt
fill 135 227 527 135 227 530 minecraft:blackstone
setblock 135 227 531 minecraft:smooth_basalt
fill 135 227 532 135 227 535 minecraft:blackstone
setblock 135 227 536 minecraft:smooth_basalt
fill 135 227 537 135 227 540 minecraft:blackstone
setblock 135 227 550 minecraft:blackstone
setblock 135 227 551 minecraft:smooth_basalt
fill 95 228 511 95 228 514 minecraft:blackstone
setblock 95 228 515 minecraft:smooth_basalt
fill 95 228 516 95 228 519 minecraft:blackstone
setblock 95 228 520 minecraft:smooth_basalt
fill 95 228 521 95 228 524 minecraft:blackstone
setblock 95 228 525 minecraft:smooth_basalt
fill 95 228 526 95 228 529 minecraft:blackstone
setblock 95 228 530 minecraft:smooth_basalt
fill 95 228 531 95 228 534 minecraft:blackstone
setblock 95 228 535 minecraft:smooth_basalt
fill 95 228 536 95 228 539 minecraft:blackstone
setblock 95 228 540 minecraft:smooth_basalt
fill 95 228 541 95 228 544 minecraft:blackstone
setblock 95 228 545 minecraft:smooth_basalt
fill 95 228 546 95 228 549 minecraft:blackstone
setblock 95 228 550 minecraft:smooth_basalt
fill 95 228 551 98 228 551 minecraft:blackstone
fill 96 228 511 96 228 513 minecraft:blackstone
setblock 96 228 514 minecraft:smooth_basalt
fill 96 228 515 96 228 518 minecraft:blackstone
setblock 96 228 519 minecraft:smooth_basalt
fill 96 228 520 97 230 520 minecraft:blackstone
setblock 96 228 523 minecraft:blackstone
setblock 96 228 528 minecraft:blackstone
setblock 96 228 529 minecraft:smooth_basalt
fill 96 228 530 96 228 533 minecraft:blackstone
setblock 96 228 534 minecraft:smooth_basalt
fill 96 228 535 97 230 535 minecraft:blackstone
setblock 96 228 538 minecraft:blackstone
setblock 96 228 539 minecraft:smooth_basalt
setblock 96 228 548 minecraft:blackstone
setblock 96 228 549 minecraft:smooth_basalt
fill 96 228 550 99 228 550 minecraft:blackstone
fill 97 228 511 97 228 512 minecraft:blackstone
setblock 97 228 513 minecraft:smooth_basalt
fill 97 228 514 97 228 517 minecraft:blackstone
setblock 97 228 518 minecraft:smooth_basalt
fill 97 228 519 97 231 519 minecraft:blackstone
setblock 97 228 533 minecraft:smooth_basalt
fill 97 228 534 97 230 534 minecraft:blackstone
fill 97 228 536 97 229 536 minecraft:blackstone
setblock 98 228 511 minecraft:blackstone
setblock 98 228 512 minecraft:smooth_basalt
fill 98 228 513 101 228 513 minecraft:blackstone
setblock 98 228 517 minecraft:smooth_basalt
setblock 99 228 511 minecraft:smooth_basalt
fill 99 228 512 102 228 512 minecraft:blackstone
fill 99 228 514 100 228 514 minecraft:blackstone
setblock 99 228 551 minecraft:smooth_basalt
fill 100 228 511 103 228 511 minecraft:blackstone
setblock 100 228 550 minecraft:smooth_basalt
fill 100 228 551 103 228 551 minecraft:blackstone
setblock 101 228 514 minecraft:smooth_basalt
fill 101 228 550 104 228 550 minecraft:blackstone
setblock 102 228 513 minecraft:smooth_basalt
setblock 102 228 514 minecraft:blackstone
setblock 103 228 512 minecraft:smooth_basalt
fill 103 228 513 103 230 513 minecraft:blackstone
setblock 104 228 511 minecraft:smooth_basalt
fill 104 228 512 107 228 512 minecraft:blackstone
setblock 104 228 551 minecraft:smooth_basalt
fill 105 228 511 108 228 511 minecraft:blackstone
setblock 105 228 550 minecraft:smooth_basalt
fill 105 228 551 108 228 551 minecraft:blackstone
setblock 106 228 550 minecraft:blackstone
setblock 108 228 512 minecraft:smooth_basalt
setblock 109 228 511 minecraft:smooth_basalt
setblock 109 228 551 minecraft:smooth_basalt
fill 110 228 511 113 228 511 minecraft:blackstone
fill 110 228 551 113 228 551 minecraft:blackstone
fill 111 228 512 112 228 512 minecraft:blackstone
fill 112 228 550 114 228 550 minecraft:blackstone
setblock 113 228 512 minecraft:smooth_basalt
setblock 114 228 511 minecraft:smooth_basalt
fill 114 228 512 117 228 512 minecraft:blackstone
setblock 114 228 551 minecraft:smooth_basalt
fill 115 228 511 118 228 511 minecraft:blackstone
setblock 115 228 550 minecraft:smooth_basalt
fill 115 228 551 118 228 551 minecraft:blackstone
fill 116 228 550 119 228 550 minecraft:blackstone
setblock 117 228 513 minecraft:smooth_basalt
setblock 118 228 512 minecraft:smooth_basalt
fill 118 228 513 120 228 513 minecraft:blackstone
setblock 119 228 511 minecraft:smooth_basalt
fill 119 228 512 122 228 512 minecraft:blackstone
setblock 119 228 551 minecraft:smooth_basalt
fill 120 228 511 123 228 511 minecraft:blackstone
setblock 120 228 550 minecraft:smooth_basalt
fill 120 228 551 123 228 551 minecraft:blackstone
setblock 121 228 550 minecraft:blackstone
setblock 123 228 512 minecraft:smooth_basalt
setblock 124 228 511 minecraft:smooth_basalt
setblock 124 228 551 minecraft:smooth_basalt
fill 125 228 511 128 228 511 minecraft:blackstone
setblock 129 228 511 minecraft:smooth_basalt
fill 130 228 511 133 228 511 minecraft:blackstone
fill 131 228 512 132 228 512 minecraft:blackstone
setblock 133 228 512 minecraft:smooth_basalt
fill 133 228 513 133 228 516 minecraft:blackstone
setblock 133 228 517 minecraft:smooth_basalt
setblock 133 228 531 minecraft:blackstone
setblock 133 228 532 minecraft:smooth_basalt
fill 133 228 533 134 228 535 minecraft:blackstone
setblock 134 228 511 minecraft:smooth_basalt
fill 134 228 512 134 228 515 minecraft:blackstone
setblock 134 228 516 minecraft:smooth_basalt
fill 134 228 517 134 228 520 minecraft:blackstone
setblock 134 228 521 minecraft:smooth_basalt
fill 134 228 522 134 228 525 minecraft:blackstone
setblock 134 228 526 minecraft:smooth_basalt
fill 134 228 527 134 228 530 minecraft:blackstone
setblock 134 228 531 minecraft:smooth_basalt
fill 134 228 532 135 230 532 minecraft:blackstone
setblock 134 228 536 minecraft:smooth_basalt
fill 134 228 537 135 229 538 minecraft:blackstone
setblock 134 228 551 minecraft:smooth_basalt
fill 135 228 511 135 228 514 minecraft:blackstone
setblock 135 228 515 minecraft:smooth_basalt
fill 135 228 516 135 228 519 minecraft:blackstone
setblock 135 228 520 minecraft:smooth_basalt
fill 135 228 521 135 228 524 minecraft:blackstone
setblock 135 228 525 minecraft:smooth_basalt
fill 135 228 526 135 228 529 minecraft:blackstone
setblock 135 228 530 minecraft:smooth_basalt
fill 135 228 531 135 231 531 minecraft:blackstone
fill 135 228 533 135 228 534 minecraft:blackstone
setblock 135 228 535 minecraft:smooth_basalt
fill 135 228 536 135 231 536 minecraft:blackstone
setblock 135 228 539 minecraft:blackstone
setblock 135 228 540 minecraft:smooth_basalt
fill 135 228 541 135 231 541 minecraft:blackstone
setblock 135 228 550 minecraft:smooth_basalt
fill 135 228 551 135 231 551 minecraft:blackstone
fill 95 229 511 95 229 513 minecraft:blackstone
setblock 95 229 514 minecraft:smooth_basalt
fill 95 229 515 95 229 518 minecraft:blackstone
setblock 95 229 519 minecraft:smooth_basalt
fill 95 229 520 95 229 523 minecraft:blackstone
setblock 95 229 524 minecraft:smooth_basalt
fill 95 229 525 95 229 528 minecraft:blackstone
setblock 95 229 529 minecraft:smooth_basalt
fill 95 229 530 95 229 533 minecraft:blackstone
setblock 95 229 534 minecraft:smooth_basalt
fill 95 229 535 95 229 538 minecraft:blackstone
setblock 95 229 539 minecraft:smooth_basalt
fill 95 229 540 95 229 543 minecraft:blackstone
setblock 95 229 544 minecraft:smooth_basalt
fill 95 229 545 95 229 548 minecraft:blackstone
setblock 95 229 549 minecraft:smooth_basalt
fill 95 229 550 97 229 551 minecraft:blackstone
fill 96 229 511 96 229 512 minecraft:blackstone
setblock 96 229 513 minecraft:smooth_basalt
fill 96 229 514 96 229 517 minecraft:blackstone
setblock 96 229 518 minecraft:smooth_basalt
fill 96 229 519 96 232 519 minecraft:blackstone
setblock 96 229 523 minecraft:smooth_basalt
fill 96 229 529 96 229 532 minecraft:blackstone
setblock 96 229 533 minecraft:smooth_basalt
fill 96 229 534 96 232 534 minecraft:blackstone
setblock 96 229 538 minecraft:smooth_basalt
fill 96 229 539 96 229 542 minecraft:blackstone
setblock 96 229 548 minecraft:smooth_basalt
fill 96 229 549 96 232 549 minecraft:blackstone
setblock 97 229 511 minecraft:blackstone
setblock 97 229 512 minecraft:smooth_basalt
fill 97 229 513 97 229 516 minecraft:blackstone
setblock 97 229 517 minecraft:smooth_basalt
fill 97 229 518 98 231 518 minecraft:blackstone
setblock 97 229 521 minecraft:light[level=12]
setblock 97 229 529 minecraft:light[level=12]
setblock 97 229 533 minecraft:blackstone
setblock 97 229 537 minecraft:smooth_basalt
fill 97 229 538 97 232 538 minecraft:blackstone
setblock 97 229 545 minecraft:light[level=12]
setblock 98 229 511 minecraft:smooth_basalt
fill 98 229 512 98 229 515 minecraft:blackstone
setblock 98 229 516 minecraft:smooth_basalt
fill 98 229 517 98 232 517 minecraft:blackstone
setblock 98 229 550 minecraft:blackstone
setblock 98 229 551 minecraft:smooth_basalt
fill 99 229 511 99 229 514 minecraft:blackstone
setblock 99 229 550 minecraft:smooth_basalt
fill 99 229 551 102 229 551 minecraft:blackstone
fill 100 229 511 100 229 513 minecraft:blackstone
setblock 100 229 514 minecraft:smooth_basalt
fill 100 229 550 103 229 550 minecraft:blackstone
fill 101 229 511 101 229 512 minecraft:blackstone
setblock 101 229 513 minecraft:smooth_basalt
fill 101 229 514 101 230 514 minecraft:blackstone
setblock 102 229 511 minecraft:blackstone
setblock 102 229 512 minecraft:smooth_basalt
fill 102 229 513 102 231 513 minecraft:blackstone
setblock 103 229 511 minecraft:smooth_basalt
fill 103 229 512 106 229 512 minecraft:blackstone
setblock 103 229 551 minecraft:smooth_basalt
fill 104 229 511 107 229 511 minecraft:blackstone
setblock 104 229 550 minecraft:smooth_basalt
fill 104 229 551 107 229 551 minecraft:blackstone
setblock 105 229 513 minecraft:light[level=12]
setblock 105 229 521 minecraft:light[level=12]
setblock 105 229 529 minecraft:light[level=12]
setblock 105 229 537 minecraft:light[level=12]
setblock 105 229 545 minecraft:light[level=12]
setblock 107 229 512 minecraft:smooth_basalt
setblock 108 229 511 minecraft:smooth_basalt
setblock 108 229 551 minecraft:smooth_basalt
fill 109 229 511 112 229 511 minecraft:blackstone
fill 109 229 551 112 229 551 minecraft:blackstone
setblock 111 229 512 minecraft:blackstone
setblock 112 229 512 minecraft:smooth_basalt
fill 112 229 550 113 229 550 minecraft:blackstone
setblock 113 229 511 minecraft:smooth_basalt
fill 113 229 512 116 229 512 minecraft:blackstone
setblock 113 229 513 minecraft:light[level=12]
setblock 113 229 521 minecraft:light[level=12]
setblock 113 229 529 minecraft:light[level=12]
setblock 113 229 537 minecraft:light[level=12]
setblock 113 229 545 minecraft:light[level=12]
setblock 113 229 551 minecraft:smooth_basalt
fill 114 229 511 117 229 511 minecraft:blackstone
setblock 114 229 550 minecraft:smooth_basalt
fill 114 229 551 117 229 551 minecraft:blackstone
fill 115 229 550 118 229 550 minecraft:blackstone
setblock 116 229 513 minecraft:smooth_basalt
setblock 117 229 512 minecraft:smooth_basalt
fill 117 229 513 119 229 513 minecraft:blackstone
setblock 118 229 511 minecraft:smooth_basalt
fill 118 229 512 121 229 512 minecraft:blackstone
setblock 118 229 551 minecraft:smooth_basalt
fill 119 229 511 122 229 511 minecraft:blackstone
setblock 119 229 550 minecraft:smooth_basalt
fill 119 229 551 122 229 551 minecraft:blackstone
setblock 120 229 550 minecraft:blackstone
setblock 121 229 513 minecraft:light[level=12]
setblock 121 229 521 minecraft:light[level=12]
setblock 121 229 529 minecraft:light[level=12]
setblock 121 229 537 minecraft:light[level=12]
setblock 121 229 545 minecraft:light[level=12]
setblock 122 229 512 minecraft:smooth_basalt
setblock 123 229 511 minecraft:smooth_basalt
setblock 123 229 512 minecraft:blackstone
setblock 123 229 551 minecraft:smooth_basalt
fill 124 229 511 127 229 511 minecraft:blackstone
setblock 128 229 511 minecraft:smooth_basalt
fill 129 229 511 132 229 511 minecraft:blackstone
setblock 129 229 513 minecraft:light[level=12]
setblock 129 229 521 minecraft:light[level=12]
setblock 129 229 529 minecraft:light[level=12]
setblock 129 229 537 minecraft:light[level=12]
setblock 129 229 545 minecraft:light[level=12]
fill 130 229 512 131 229 512 minecraft:blackstone
setblock 132 229 512 minecraft:smooth_basalt
fill 132 229 513 135 229 513 minecraft:blackstone
setblock 133 229 511 minecraft:smooth_basalt
fill 133 229 512 135 230 512 minecraft:blackstone
fill 133 229 514 133 229 515 minecraft:blackstone
setblock 133 229 516 minecraft:smooth_basalt
fill 133 229 517 134 229 519 minecraft:blackstone
setblock 133 229 531 minecraft:smooth_basalt
fill 133 229 532 133 229 535 minecraft:blackstone
setblock 133 229 536 minecraft:smooth_basalt
setblock 133 229 551 minecraft:smooth_basalt
fill 134 229 511 135 231 511 minecraft:blackstone
setblock 134 229 514 minecraft:blackstone
setblock 134 229 515 minecraft:smooth_basalt
fill 134 229 516 135 231 516 minecraft:blackstone
setblock 134 229 520 minecraft:smooth_basalt
fill 134 229 521 134 229 524 minecraft:blackstone
setblock 134 229 525 minecraft:smooth_basalt
fill 134 229 526 134 229 529 minecraft:blackstone
setblock 134 229 530 minecraft:smooth_basalt
fill 134 229 531 134 232 531 minecraft:blackstone
fill 134 229 533 134 229 534 minecraft:blackstone
setblock 134 229 535 minecraft:smooth_basalt
fill 134 229 536 134 232 536 minecraft:blackstone
setblock 134 229 539 minecraft:blackstone
fill 134 229 551 134 232 551 minecraft:blackstone
setblock 135 229 514 minecraft:smooth_basalt
fill 135 229 515 135 232 515 minecraft:blackstone
fill 135 229 517 135 229 518 minecraft:blackstone
setblock 135 229 519 minecraft:smooth_basalt
fill 135 229 520 135 229 523 minecraft:blackstone
setblock 135 229 524 minecraft:smooth_basalt
fill 135 229 525 135 229 528 minecraft:blackstone
setblock 135 229 529 minecraft:smooth_basalt
fill 135 229 530 135 232 530 minecraft:blackstone
setblock 135 229 533 minecraft:blackstone
setblock 135 229 534 minecraft:smooth_basalt
fill 135 229 535 135 232 535 minecraft:blackstone
setblock 135 229 539 minecraft:smooth_basalt
fill 135 229 540 135 232 540 minecraft:blackstone
fill 135 229 542 135 229 543 minecraft:blackstone
setblock 135 229 549 minecraft:smooth_basalt
fill 135 229 550 135 232 550 minecraft:blackstone
fill 95 230 511 95 230 512 minecraft:blackstone
setblock 95 230 513 minecraft:smooth_basalt
fill 95 230 514 95 230 517 minecraft:blackstone
setblock 95 230 518 minecraft:smooth_basalt
fill 95 230 519 95 230 522 minecraft:blackstone
setblock 95 230 523 minecraft:smooth_basalt
fill 95 230 524 95 230 527 minecraft:blackstone
setblock 95 230 528 minecraft:smooth_basalt
fill 95 230 529 95 230 532 minecraft:blackstone
setblock 95 230 533 minecraft:smooth_basalt
fill 95 230 534 95 230 537 minecraft:blackstone
setblock 95 230 538 minecraft:smooth_basalt
fill 95 230 539 95 230 542 minecraft:blackstone
setblock 95 230 543 minecraft:smooth_basalt
fill 95 230 544 95 230 547 minecraft:blackstone
setblock 95 230 548 minecraft:smooth_basalt
fill 95 230 549 95 231 551 minecraft:blackstone
setblock 96 230 511 minecraft:blackstone
setblock 96 230 512 minecraft:smooth_basalt
fill 96 230 513 96 230 516 minecraft:blackstone
setblock 96 230 517 minecraft:smooth_basalt
fill 96 230 518 96 233 518 minecraft:blackstone
setblock 96 230 521 minecraft:blackstone
setblock 96 230 522 minecraft:smooth_basalt
fill 96 230 523 96 233 523 minecraft:blackstone
fill 96 230 530 96 230 531 minecraft:blackstone
setblock 96 230 532 minecraft:smooth_basalt
fill 96 230 533 96 232 533 minecraft:blackstone
setblock 96 230 536 minecraft:blackstone
setblock 96 230 537 minecraft:smooth_basalt
fill 96 230 538 96 230 541 minecraft:blackstone
setblock 96 230 542 minecraft:smooth_basalt
fill 96 230 543 96 232 544 minecraft:blackstone
setblock 96 230 547 minecraft:smooth_basalt
fill 96 230 548 96 233 548 minecraft:blackstone
fill 96 230 550 96 230 551 minecraft:blackstone
setblock 97 230 511 minecraft:smooth_basalt
fill 97 230 512 97 230 515 minecraft:blackstone
setblock 97 230 516 minecraft:smooth_basalt
fill 97 230 517 97 233 517 minecraft:blackstone
setblock 97 230 536 minecraft:smooth_basalt
fill 97 230 537 97 232 537 minecraft:blackstone
fill 97 230 539 97 231 539 minecraft:blackstone
setblock 97 230 550 minecraft:blackstone
setblock 97 230 551 minecraft:smooth_basalt
fill 98 230 511 98 230 514 minecraft:blackstone
setblock 98 230 515 minecraft:smooth_basalt
fill 98 230 516 98 232 516 minecraft:blackstone
setblock 98 230 550 minecraft:smooth_basalt
fill 98 230 551 101 230 551 minecraft:blackstone
fill 99 230 511 99 230 513 minecraft:blackstone
setblock 99 230 514 minecraft:smooth_basalt
fill 99 230 550 102 230 550 minecraft:blackstone
fill 100 230 511 100 230 512 minecraft:blackstone
setblock 100 230 513 minecraft:smooth_basalt
fill 100 230 514 100 231 514 minecraft:blackstone
setblock 101 230 511 minecraft:blackstone
setblock 101 230 512 minecraft:smooth_basalt
fill 101 230 513 101 232 513 minecraft:blackstone
setblock 102 230 511 minecraft:smooth_basalt
fill 102 230 512 105 230 512 minecraft:blackstone
setblock 102 230 551 minecraft:smooth_basalt
fill 103 230 511 106 230 511 minecraft:blackstone
setblock 103 230 550 minecraft:smooth_basalt
fill 103 230 551 106 230 551 minecraft:blackstone
setblock 106 230 512 minecraft:smooth_basalt
setblock 107 230 511 minecraft:smooth_basalt
setblock 107 230 551 minecraft:smooth_basalt
fill 108 230 511 111 230 511 minecraft:blackstone
fill 108 230 551 111 230 551 minecraft:blackstone
setblock 111 230 512 minecraft:smooth_basalt
setblock 112 230 511 minecraft:smooth_basalt
fill 112 230 512 115 230 512 minecraft:blackstone
setblock 112 230 550 minecraft:blackstone
setblock 112 230 551 minecraft:smooth_basalt
fill 113 230 511 116 230 511 minecraft:blackstone
setblock 113 230 550 minecraft:smooth_basalt
fill 113 230 551 116 230 551 minecraft:blackstone
fill 114 230 550 117 230 550 minecraft:blackstone
setblock 116 230 512 minecraft:smooth_basalt
fill 116 230 513 118 230 513 minecraft:blackstone
setblock 117 230 511 minecraft:smooth_basalt
fill 117 230 512 120 230 512 minecraft:blackstone
setblock 117 230 551 minecraft:smooth_basalt
fill 118 230 511 121 230 511 minecraft:blackstone
setblock 118 230 550 minecraft:smooth_basalt
fill 118 230 551 121 230 551 minecraft:blackstone
setblock 119 230 550 minecraft:blackstone
setblock 121 230 512 minecraft:smooth_basalt
setblock 122 230 511 minecraft:smooth_basalt
setblock 122 230 512 minecraft:blackstone
setblock 122 230 551 minecraft:smooth_basalt
fill 123 230 511 125 230 511 minecraft:blackstone
fill 128 230 511 131 230 511 minecraft:blackstone
setblock 130 230 512 minecraft:blackstone
setblock 131 230 512 minecraft:smooth_basalt
setblock 132 230 511 minecraft:smooth_basalt
fill 132 230 512 132 232 513 minecraft:blackstone
fill 133 230 511 133 233 511 minecraft:blackstone
fill 133 230 513 133 230 514 minecraft:blackstone
setblock 133 230 515 minecraft:smooth_basalt
fill 133 230 516 133 230 519 minecraft:blackstone
setblock 133 230 520 minecraft:smooth_basalt
fill 133 230 521 135 231 521 minecraft:blackstone
fill 133 230 532 133 230 534 minecraft:blackstone
setblock 133 230 535 minecraft:smooth_basalt
fill 133 230 536 133 231 536 minecraft:blackstone
setblock 133 230 551 minecraft:blackstone
setblock 134 230 513 minecraft:blackstone
setblock 134 230 514 minecraft:smooth_basalt
fill 134 230 515 134 233 515 minecraft:blackstone
fill 134 230 517 134 230 518 minecraft:blackstone
setblock 134 230 519 minecraft:smooth_basalt
fill 134 230 520 135 232 520 minecraft:blackstone
fill 134 230 522 134 230 523 minecraft:blackstone
setblock 134 230 524 minecraft:smooth_basalt
fill 134 230 525 134 230 528 minecraft:blackstone
setblock 134 230 529 minecraft:smooth_basalt
fill 134 230 530 134 232 530 minecraft:blackstone
setblock 134 230 533 minecraft:blackstone
setblock 134 230 534 minecraft:smooth_basalt
fill 134 230 535 134 233 535 minecraft:blackstone
fill 134 230 537 134 230 538 minecraft:blackstone
setblock 134 230 539 minecraft:smooth_basalt
fill 134 230 540 134 233 540 minecraft:blackstone
setblock 135 230 513 minecraft:smooth_basalt
fill 135 230 514 135 233 514 minecraft:blackstone
setblock 135 230 517 minecraft:blackstone
setblock 135 230 518 minecraft:smooth_basalt
fill 135 230 519 135 233 519 minecraft:blackstone
setblock 135 230 522 minecraft:blackstone
setblock 135 230 523 minecraft:smooth_basalt
fill 135 230 524 135 230 527 minecraft:blackstone
setblock 135 230 528 minecraft:smooth_basalt
fill 135 230 529 135 233 529 minecraft:blackstone
setblock 135 230 533 minecraft:smooth_basalt
fill 135 230 534 135 233 534 minecraft:blackstone
setblock 135 230 537 minecraft:blackstone
setblock 135 230 538 minecraft:smooth_basalt
fill 135 230 539 135 233 539 minecraft:blackstone
setblock 135 230 542 minecraft:blackstone
setblock 135 230 543 minecraft:smooth_basalt
fill 135 230 544 135 233 544 minecraft:blackstone
fill 135 230 549 135 231 549 minecraft:blackstone
setblock 95 231 511 minecraft:blackstone
setblock 95 231 512 minecraft:smooth_basalt
fill 95 231 513 95 231 516 minecraft:blackstone
setblock 95 231 517 minecraft:smooth_basalt
fill 95 231 518 95 231 521 minecraft:blackstone
setblock 95 231 522 minecraft:smooth_basalt
fill 95 231 523 95 231 526 minecraft:blackstone
setblock 95 231 527 minecraft:smooth_basalt
fill 95 231 528 95 231 531 minecraft:blackstone
setblock 95 231 532 minecraft:smooth_basalt
fill 95 231 533 95 231 536 minecraft:blackstone
setblock 95 231 537 minecraft:smooth_basalt
fill 95 231 538 95 231 541 minecraft:blackstone
setblock 95 231 542 minecraft:smooth_basalt
fill 95 231 543 95 231 546 minecraft:blackstone
setblock 95 231 547 minecraft:smooth_basalt
fill 95 231 548 95 234 548 minecraft:blackstone
setblock 96 231 511 minecraft:smooth_basalt
fill 96 231 512 96 231 515 minecraft:blackstone
setblock 96 231 516 minecraft:smooth_basalt
fill 96 231 517 96 234 517 minecraft:blackstone
setblock 96 231 520 minecraft:blackstone
setblock 96 231 521 minecraft:smooth_basalt
fill 96 231 522 96 234 522 minecraft:blackstone
setblock 96 231 532 minecraft:blackstone
setblock 96 231 535 minecraft:blackstone
setblock 96 231 536 minecraft:smooth_basalt
fill 96 231 537 96 231 540 minecraft:blackstone
setblock 96 231 541 minecraft:smooth_basalt
fill 96 231 542 96 234 542 minecraft:blackstone
setblock 96 231 545 minecraft:blackstone
setblock 96 231 546 minecraft:smooth_basalt
fill 96 231 547 96 234 547 minecraft:blackstone
setblock 96 231 550 minecraft:blackstone
setblock 96 231 551 minecraft:smooth_basalt
fill 97 231 511 97 231 514 minecraft:blackstone
setblock 97 231 515 minecraft:smooth_basalt
fill 97 231 516 97 234 516 minecraft:blackstone
setblock 97 231 520 minecraft:smooth_basalt
setblock 97 231 536 minecraft:blackstone
setblock 97 231 540 minecraft:smooth_basalt
setblock 97 231 550 minecraft:smooth_basalt
fill 97 231 551 100 231 551 minecraft:blackstone
fill 98 231 511 98 231 513 minecraft:blackstone
setblock 98 231 514 minecraft:smooth_basalt
fill 98 231 515 98 232 515 minecraft:blackstone
fill 98 231 550 101 231 550 minecraft:blackstone
fill 99 231 511 99 231 512 minecraft:blackstone
setblock 99 231 513 minecraft:smooth_basalt
setblock 99 231 514 minecraft:blackstone
setblock 100 231 511 minecraft:blackstone
setblock 100 231 512 minecraft:smooth_basalt
fill 100 231 513 100 232 513 minecraft:blackstone
setblock 101 231 511 minecraft:smooth_basalt
fill 101 231 512 104 231 512 minecraft:blackstone
setblock 101 231 551 minecraft:smooth_basalt
fill 102 231 511 105 231 511 minecraft:blackstone
setblock 102 231 550 minecraft:smooth_basalt
fill 102 231 551 105 231 551 minecraft:blackstone
setblock 106 231 511 minecraft:smooth_basalt
setblock 106 231 551 minecraft:smooth_basalt
fill 107 231 511 110 231 511 minecraft:blackstone
fill 107 231 526 109 232 527 minecraft:gold_block
fill 107 231 551 110 231 551 minecraft:blackstone
fill 109 231 517 113 232 520 minecraft:smooth_basalt
fill 110 231 521 112 232 521 minecraft:smooth_basalt
setblock 111 231 511 minecraft:smooth_basalt
fill 111 231 516 111 273 516 minecraft:smooth_basalt
setblock 111 231 551 minecraft:smooth_basalt
fill 112 231 511 114 231 512 minecraft:blackstone
fill 112 231 551 115 231 551 minecraft:blackstone
fill 113 231 550 116 231 550 minecraft:blackstone
setblock 115 231 511 minecraft:blackstone
setblock 115 231 512 minecraft:smooth_basalt
setblock 116 231 511 minecraft:smooth_basalt
fill 116 231 512 119 231 512 minecraft:blackstone
setblock 116 231 551 minecraft:smooth_basalt
fill 117 231 511 120 231 511 minecraft:blackstone
setblock 117 231 550 minecraft:smooth_basalt
fill 117 231 551 120 231 551 minecraft:blackstone
setblock 120 231 512 minecraft:smooth_basalt
setblock 121 231 511 minecraft:smooth_basalt
fill 122 231 511 123 231 511 minecraft:blackstone
fill 129 231 511 130 231 511 minecraft:blackstone
setblock 130 231 512 minecraft:smooth_basalt
setblock 131 231 511 minecraft:smooth_basalt
fill 131 231 512 131 234 512 minecraft:blackstone
fill 132 231 511 132 234 511 minecraft:blackstone
fill 133 231 512 133 231 513 minecraft:blackstone
setblock 133 231 514 minecraft:smooth_basalt
fill 133 231 515 133 231 518 minecraft:blackstone
setblock 133 231 519 minecraft:smooth_basalt
fill 133 231 520 133 234 520 minecraft:blackstone
fill 133 231 522 134 231 522 minecraft:blackstone
setblock 133 231 534 minecraft:smooth_basalt
setblock 133 231 535 minecraft:blackstone
fill 133 231 537 134 231 537 minecraft:blackstone
setblock 134 231 512 minecraft:blackstone
setblock 134 231 513 minecraft:smooth_basalt
fill 134 231 514 134 234 514 minecraft:blackstone
setblock 134 231 517 minecraft:blackstone
setblock 134 231 518 minecraft:smooth_basalt
fill 134 231 519 134 234 519 minecraft:blackstone
setblock 134 231 523 minecraft:smooth_basalt
fill 134 231 524 134 231 527 minecraft:blackstone
setblock 134 231 528 minecraft:smooth_basalt
fill 134 231 529 134 232 529 minecraft:blackstone
setblock 134 231 532 minecraft:blackstone
setblock 134 231 533 minecraft:smooth_basalt
fill 134 231 534 134 234 534 minecraft:blackstone
setblock 134 231 538 minecraft:smooth_basalt
fill 134 231 539 134 234 539 minecraft:blackstone
fill 134 231 541 134 232 541 minecraft:blackstone
setblock 135 231 512 minecraft:smooth_basalt
fill 135 231 513 135 234 513 minecraft:blackstone
setblock 135 231 517 minecraft:smooth_basalt
fill 135 231 518 135 234 518 minecraft:blackstone
setblock 135 231 522 minecraft:smooth_basalt
fill 135 231 523 135 231 526 minecraft:blackstone
setblock 135 231 527 minecraft:smooth_basalt
fill 135 231 528 135 234 528 minecraft:blackstone
setblock 135 231 532 minecraft:smooth_basalt
fill 135 231 533 135 234 533 minecraft:blackstone
setblock 135 231 537 minecraft:smooth_basalt
fill 135 231 538 135 234 538 minecraft:blackstone
setblock 135 231 542 minecraft:smooth_basalt
fill 135 231 543 135 234 543 minecraft:blackstone
fill 135 231 545 135 232 545 minecraft:blackstone
setblock 95 232 511 minecraft:smooth_basalt
fill 95 232 512 95 232 515 minecraft:blackstone
setblock 95 232 516 minecraft:smooth_basalt
fill 95 232 517 95 232 520 minecraft:blackstone
setblock 95 232 521 minecraft:smooth_basalt
fill 95 232 522 95 232 525 minecraft:blackstone
setblock 95 232 526 minecraft:smooth_basalt
fill 95 232 527 95 232 530 minecraft:blackstone
setblock 95 232 531 minecraft:smooth_basalt
fill 95 232 532 95 232 535 minecraft:blackstone
setblock 95 232 536 minecraft:smooth_basalt
fill 95 232 537 95 232 540 minecraft:blackstone
setblock 95 232 541 minecraft:smooth_basalt
fill 95 232 542 95 232 545 minecraft:blackstone
setblock 95 232 546 minecraft:smooth_basalt
fill 95 232 547 95 235 547 minecraft:blackstone
fill 95 232 549 95 232 550 minecraft:blackstone
setblock 95 232 551 minecraft:smooth_basalt
fill 96 232 511 96 232 514 minecraft:blackstone
setblock 96 232 515 minecraft:smooth_basalt
fill 96 232 516 96 235 516 minecraft:blackstone
setblock 96 232 520 minecraft:smooth_basalt
fill 96 232 521 96 235 521 minecraft:blackstone
setblock 96 232 535 minecraft:smooth_basalt
fill 96 232 536 96 232 539 minecraft:blackstone
setblock 96 232 540 minecraft:smooth_basalt
fill 96 232 541 96 235 541 minecraft:blackstone
setblock 96 232 545 minecraft:smooth_basalt
fill 96 232 546 96 235 546 minecraft:blackstone
setblock 96 232 550 minecraft:smooth_basalt
fill 96 232 551 99 232 551 minecraft:blackstone
fill 97 232 511 97 232 513 minecraft:blackstone
setblock 97 232 514 minecraft:smooth_basalt
fill 97 232 515 97 235 515 minecraft:blackstone
setblock 97 232 518 minecraft:blackstone
setblock 97 232 519 minecraft:smooth_basalt
fill 97 232 520 97 233 520 minecraft:blackstone
setblock 97 232 539 minecraft:smooth_basalt
setblock 97 232 540 minecraft:blackstone
fill 97 232 550 100 232 550 minecraft:blackstone
fill 98 232 511 98 232 512 minecraft:blackstone
setblock 98 232 513 minecraft:smooth_basalt
setblock 98 232 514 minecraft:blackstone
setblock 99 232 511 minecraft:blackstone
setblock 99 232 512 minecraft:smooth_basalt
fill 99 232 513 99 233 513 minecraft:blackstone
setblock 100 232 511 minecraft:smooth_basalt
fill 100 232 512 102 232 512 minecraft:blackstone
setblock 100 232 551 minecraft:smooth_basalt
fill 101 232 511 104 232 511 minecraft:blackstone
fill 101 232 551 104 232 551 minecraft:blackstone
setblock 105 232 511 minecraft:smooth_basalt
setblock 105 232 551 minecraft:smooth_basalt
fill 108 232 517 108 233 519 minecraft:blackstone
fill 108 232 520 108 273 522 minecraft:smooth_basalt
fill 109 232 516 110 233 516 minecraft:blackstone
fill 109 232 521 109 273 523 minecraft:smooth_basalt
setblock 109 232 551 minecraft:blackstone
setblock 110 232 511 minecraft:smooth_basalt
fill 110 232 515 112 233 515 minecraft:blackstone
fill 110 232 522 110 273 522 minecraft:smooth_basalt
setblock 110 232 551 minecraft:smooth_basalt
fill 111 232 511 114 232 511 minecraft:blackstone
fill 111 232 522 112 234 522 minecraft:blackstone
fill 111 232 551 114 232 551 minecraft:blackstone
fill 112 232 516 113 233 516 minecraft:blackstone
setblock 113 232 512 minecraft:blackstone
fill 113 232 521 114 233 521 minecraft:blackstone
setblock 114 232 512 minecraft:smooth_basalt
fill 114 232 517 114 233 520 minecraft:blackstone
setblock 115 232 511 minecraft:smooth_basalt
fill 115 232 512 118 232 512 minecraft:blackstone
setblock 115 232 551 minecraft:smooth_basalt
fill 116 232 511 119 232 511 minecraft:blackstone
fill 116 232 551 119 232 551 minecraft:blackstone
setblock 120 232 511 minecraft:smooth_basalt
setblock 121 232 511 minecraft:blackstone
setblock 129 232 511 minecraft:blackstone
setblock 130 232 511 minecraft:smooth_basalt
fill 131 232 511 131 235 511 minecraft:blackstone
fill 132 232 517 133 232 517 minecraft:blackstone
setblock 133 232 512 minecraft:blackstone
setblock 133 232 513 minecraft:smooth_basalt
fill 133 232 514 133 233 516 minecraft:blackstone
setblock 133 232 518 minecraft:smooth_basalt
fill 133 232 519 133 235 519 minecraft:blackstone
fill 133 232 521 133 232 522 minecraft:blackstone
setblock 134 232 511 minecraft:blackstone
setblock 134 232 512 minecraft:smooth_basalt
fill 134 232 513 134 235 513 minecraft:blackstone
setblock 134 232 516 minecraft:blackstone
setblock 134 232 517 minecraft:smooth_basalt
fill 134 232 518 134 235 518 minecraft:blackstone
setblock 134 232 521 minecraft:blackstone
setblock 134 232 522 minecraft:smooth_basalt
fill 134 232 523 134 232 526 minecraft:blackstone
setblock 134 232 527 minecraft:smooth_basalt
setblock 134 232 528 minecraft:blackstone
setblock 134 232 532 minecraft:smooth_basalt
fill 134 232 533 134 233 533 minecraft:blackstone
setblock 134 232 537 minecraft:smooth_basalt
fill 134 232 538 134 235 538 minecraft:blackstone
setblock 135 232 511 minecraft:smooth_basalt
fill 135 232 512 135 235 512 minecraft:blackstone
setblock 135 232 516 minecraft:smooth_basalt
fill 135 232 517 135 235 517 minecraft:blackstone
setblock 135 232 521 minecraft:smooth_basalt
fill 135 232 522 135 232 525 minecraft:blackstone
setblock 135 232 526 minecraft:smooth_basalt
fill 135 232 527 135 235 527 minecraft:blackstone
setblock 135 232 531 minecraft:smooth_basalt
fill 135 232 532 135 235 532 minecraft:blackstone
setblock 135 232 536 minecraft:smooth_basalt
fill 135 232 537 135 235 537 minecraft:blackstone
setblock 135 232 541 minecraft:smooth_basalt
fill 135 232 542 135 235 542 minecraft:blackstone
setblock 135 232 551 minecraft:smooth_basalt
fill 95 233 511 95 233 514 minecraft:blackstone
setblock 95 233 515 minecraft:smooth_basalt
fill 95 233 516 95 233 519 minecraft:blackstone
setblock 95 233 520 minecraft:smooth_basalt
fill 95 233 521 95 233 524 minecraft:blackstone
setblock 95 233 525 minecraft:smooth_basalt
setblock 95 233 526 minecraft:blackstone
fill 95 233 531 95 233 534 minecraft:blackstone
setblock 95 233 535 minecraft:smooth_basalt
fill 95 233 536 95 233 539 minecraft:blackstone
setblock 95 233 540 minecraft:smooth_basalt
fill 95 233 541 95 233 544 minecraft:blackstone
setblock 95 233 545 minecraft:smooth_basalt
fill 95 233 546 95 236 546 minecraft:blackstone
setblock 95 233 549 minecraft:blackstone
setblock 95 233 550 minecraft:smooth_basalt
fill 95 233 551 98 233 551 minecraft:blackstone
fill 96 233 511 96 233 513 minecraft:blackstone
setblock 96 233 514 minecraft:smooth_basalt
fill 96 233 515 96 236 515 minecraft:blackstone
setblock 96 233 519 minecraft:smooth_basalt
fill 96 233 520 96 236 520 minecraft:blackstone
fill 96 233 535 96 233 538 minecraft:blackstone
setblock 96 233 539 minecraft:smooth_basalt
fill 96 233 540 96 236 540 minecraft:blackstone
setblock 96 233 543 minecraft:blackstone
setblock 96 233 544 minecraft:smooth_basalt
fill 96 233 545 96 236 545 minecraft:blackstone
setblock 96 233 549 minecraft:smooth_basalt
fill 96 233 550 98 233 550 minecraft:blackstone
fill 97 233 511 97 233 512 minecraft:blackstone
setblock 97 233 513 minecraft:smooth_basalt
fill 97 233 514 97 234 514 minecraft:blackstone
setblock 97 233 518 minecraft:smooth_basalt
fill 97 233 519 97 234 519 minecraft:blackstone
setblock 98 233 511 minecraft:blackstone
setblock 98 233 512 minecraft:smooth_basalt
setblock 98 233 513 minecraft:blackstone
setblock 99 233 511 minecraft:smooth_basalt
fill 99 233 512 101 233 512 minecraft:blackstone
setblock 99 233 551 minecraft:smooth_basalt
fill 100 233 511 103 233 511 minecraft:blackstone
fill 100 233 551 102 233 551 minecraft:blackstone
fill 107 233 516 107 233 522 minecraft:blackstone
fill 108 233 515 108 233 516 minecraft:blackstone
fill 108 233 523 108 234 523 minecraft:blackstone
setblock 109 233 515 minecraft:blackstone
fill 109 233 517 113 233 518 minecraft:smooth_basalt
fill 109 233 519 110 234 519 minecraft:blackstone
fill 109 233 520 110 273 520 minecraft:smooth_basalt
fill 110 233 514 112 233 514 minecraft:blackstone
fill 110 233 521 110 273 521 minecraft:smooth_basalt
fill 110 233 523 113 233 523 minecraft:blackstone
fill 110 233 551 113 233 551 minecraft:blackstone
fill 111 233 511 113 233 511 minecraft:blackstone
fill 111 233 519 113 233 519 minecraft:smooth_basalt
fill 111 233 520 111 234 521 minecraft:blackstone
fill 112 233 520 112 233 521 minecraft:smooth_basalt
fill 113 233 515 114 233 515 minecraft:blackstone
fill 113 233 520 113 273 520 minecraft:smooth_basalt
fill 113 233 522 114 233 522 minecraft:blackstone
setblock 114 233 511 minecraft:smooth_basalt
fill 114 233 516 115 233 516 minecraft:blackstone
setblock 114 233 551 minecraft:smooth_basalt
fill 115 233 511 118 233 511 minecraft:blackstone
fill 115 233 517 115 233 521 minecraft:blackstone
fill 115 233 551 117 233 551 minecraft:blackstone
fill 130 233 511 130 235 511 minecraft:blackstone
setblock 132 233 512 minecraft:blackstone
setblock 132 233 513 minecraft:smooth_basalt
setblock 132 233 517 minecraft:blackstone
setblock 132 233 518 minecraft:smooth_basalt
setblock 133 233 512 minecraft:smooth_basalt
fill 133 233 513 133 235 513 minecraft:blackstone
setblock 133 233 517 minecraft:smooth_basalt
fill 133 233 518 133 236 518 minecraft:blackstone
setblock 133 233 521 minecraft:blackstone
setblock 133 233 522 minecraft:smooth_basalt
fill 133 233 523 135 234 523 minecraft:blackstone
setblock 134 233 511 minecraft:smooth_basalt
fill 134 233 512 134 236 512 minecraft:blackstone
setblock 134 233 516 minecraft:smooth_basalt
fill 134 233 517 134 236 517 minecraft:blackstone
setblock 134 233 520 minecraft:blackstone
setblock 134 233 521 minecraft:smooth_basalt
fill 134 233 522 135 235 522 minecraft:blackstone
fill 134 233 524 134 233 525 minecraft:blackstone
setblock 134 233 526 minecraft:smooth_basalt
setblock 134 233 532 minecraft:blackstone
setblock 134 233 536 minecraft:smooth_basalt
fill 134 233 537 134 235 537 minecraft:blackstone
setblock 134 233 541 minecraft:smooth_basalt
setblock 134 233 551 minecraft:smooth_basalt
fill 135 233 511 135 236 511 minecraft:blackstone
setblock 135 233 515 minecraft:smooth_basalt
fill 135 233 516 135 236 516 minecraft:blackstone
setblock 135 233 520 minecraft:smooth_basalt
fill 135 233 521 135 236 521 minecraft:blackstone
setblock 135 233 524 minecraft:blackstone
setblock 135 233 525 minecraft:smooth_basalt
fill 135 233 526 135 236 526 minecraft:blackstone
setblock 135 233 530 minecraft:smooth_basalt
fill 135 233 531 135 235 531 minecraft:blackstone
setblock 135 233 535 minecraft:smooth_basalt
fill 135 233 536 135 236 536 minecraft:blackstone
setblock 135 233 540 minecraft:smooth_basalt
fill 135 233 541 135 236 541 minecraft:blackstone
setblock 135 233 545 minecraft:smooth_basalt
fill 135 233 546 135 236 546 minecraft:blackstone
setblock 135 233 550 minecraft:smooth_basalt
fill 135 233 551 135 234 551 minecraft:blackstone
fill 95 234 511 95 234 513 minecraft:blackstone
setblock 95 234 514 minecraft:smooth_basalt
fill 95 234 515 95 234 518 minecraft:blackstone
setblock 95 234 519 minecraft:smooth_basalt
fill 95 234 520 95 234 523 minecraft:blackstone
setblock 95 234 524 minecraft:smooth_basalt
fill 95 234 525 95 237 525 minecraft:blackstone
setblock 95 234 533 minecraft:blackstone
setblock 95 234 534 minecraft:smooth_basalt
fill 95 234 535 95 234 538 minecraft:blackstone
setblock 95 234 539 minecraft:smooth_basalt
fill 95 234 540 95 234 543 minecraft:blackstone
setblock 95 234 544 minecraft:smooth_basalt
fill 95 234 545 95 237 545 minecraft:blackstone
setblock 95 234 549 minecraft:smooth_basalt
fill 95 234 550 96 234 551 minecraft:blackstone
fill 96 234 511 96 234 512 minecraft:blackstone
setblock 96 234 513 minecraft:smooth_basalt
fill 96 234 514 96 237 514 minecraft:blackstone
setblock 96 234 518 minecraft:smooth_basalt
fill 96 234 519 96 237 519 minecraft:blackstone
fill 96 234 536 96 234 537 minecraft:blackstone
setblock 96 234 538 minecraft:smooth_basalt
fill 96 234 539 96 237 539 minecraft:blackstone
setblock 96 234 543 minecraft:smooth_basalt
fill 96 234 544 96 237 544 minecraft:blackstone
setblock 97 234 511 minecraft:blackstone
setblock 97 234 512 minecraft:smooth_basalt
setblock 97 234 513 minecraft:blackstone
setblock 97 234 517 minecraft:smooth_basalt
fill 97 234 518 97 235 518 minecraft:blackstone
setblock 97 234 551 minecraft:blackstone
setblock 98 234 511 minecraft:smooth_basalt
fill 98 234 512 99 234 512 minecraft:blackstone
setblock 98 234 551 minecraft:smooth_basalt
fill 99 234 511 101 234 511 minecraft:blackstone
fill 99 234 551 101 234 551 minecraft:blackstone
fill 106 234 521 107 234 522 minecraft:blackstone
fill 107 234 519 107 234 520 minecraft:blackstone
setblock 107 234 523 minecraft:blackstone
setblock 108 234 519 minecraft:blackstone
fill 108 234 524 110 234 524 minecraft:blackstone
fill 109 234 517 113 273 517 minecraft:smooth_basalt
setblock 109 234 518 minecraft:blackstone
fill 110 234 518 113 269 518 minecraft:smooth_basalt
fill 110 234 523 111 234 523 minecraft:blackstone
setblock 111 234 519 minecraft:blackstone
fill 111 234 551 112 234 551 minecraft:blackstone
fill 112 234 519 113 273 519 minecraft:smooth_basalt
fill 112 234 520 112 234 521 minecraft:blackstone
setblock 113 234 511 minecraft:smooth_basalt
setblock 113 234 551 minecraft:smooth_basalt
fill 114 234 511 116 234 511 minecraft:blackstone
fill 114 234 551 116 234 551 minecraft:blackstone
setblock 132 234 512 minecraft:smooth_basalt
setblock 132 234 517 minecraft:smooth_basalt
fill 132 234 518 132 236 519 minecraft:blackstone
setblock 133 234 511 minecraft:smooth_basalt
fill 133 234 512 133 237 512 minecraft:blackstone
fill 133 234 514 133 234 515 minecraft:blackstone
setblock 133 234 516 minecraft:smooth_basalt
fill 133 234 517 133 237 517 minecraft:blackstone
setblock 133 234 521 minecraft:smooth_basalt
fill 133 234 522 133 237 522 minecraft:blackstone
fill 134 234 511 134 237 511 minecraft:blackstone
setblock 134 234 515 minecraft:smooth_basalt
fill 134 234 516 134 237 516 minecraft:blackstone
setblock 134 234 520 minecraft:smooth_basalt
fill 134 234 521 134 237 521 minecraft:blackstone
setblock 134 234 524 minecraft:blackstone
setblock 134 234 525 minecraft:smooth_basalt
fill 134 234 526 134 237 526 minecraft:blackstone
setblock 134 234 535 minecraft:smooth_basalt
setblock 134 234 536 minecraft:blackstone
setblock 134 234 540 minecraft:smooth_basalt
fill 134 234 541 134 236 542 minecraft:blackstone
setblock 135 234 514 minecraft:smooth_basalt
fill 135 234 515 135 237 515 minecraft:blackstone
setblock 135 234 519 minecraft:smooth_basalt
fill 135 234 520 135 237 520 minecraft:blackstone
setblock 135 234 524 minecraft:smooth_basalt
fill 135 234 525 135 237 525 minecraft:blackstone
setblock 135 234 529 minecraft:smooth_basalt
fill 135 234 530 135 235 530 minecraft:blackstone
setblock 135 234 534 minecraft:smooth_basalt
fill 135 234 535 135 236 535 minecraft:blackstone
setblock 135 234 539 minecraft:smooth_basalt
fill 135 234 540 135 237 540 minecraft:blackstone
setblock 135 234 544 minecraft:smooth_basalt
fill 135 234 545 135 237 545 minecraft:blackstone
fill 95 235 511 95 235 512 minecraft:blackstone
setblock 95 235 513 minecraft:smooth_basalt
fill 95 235 514 95 235 517 minecraft:blackstone
setblock 95 235 518 minecraft:smooth_basalt
fill 95 235 519 95 235 522 minecraft:blackstone
setblock 95 235 523 minecraft:smooth_basalt
fill 95 235 524 95 238 524 minecraft:blackstone
fill 95 235 534 95 235 537 minecraft:blackstone
setblock 95 235 538 minecraft:smooth_basalt
fill 95 235 539 95 235 542 minecraft:blackstone
setblock 95 235 543 minecraft:smooth_basalt
fill 95 235 544 95 238 544 minecraft:blackstone
setblock 95 235 548 minecraft:smooth_basalt
fill 95 235 549 95 236 551 minecraft:blackstone
setblock 96 235 511 minecraft:blackstone
setblock 96 235 512 minecraft:smooth_basalt
fill 96 235 513 96 237 513 minecraft:blackstone
setblock 96 235 517 minecraft:smooth_basalt
fill 96 235 518 96 238 518 minecraft:blackstone
setblock 96 235 522 minecraft:smooth_basalt
setblock 96 235 537 minecraft:smooth_basalt
fill 96 235 538 96 236 538 minecraft:blackstone
setblock 96 235 542 minecraft:smooth_basalt
fill 96 235 543 96 238 543 minecraft:blackstone
setblock 96 235 547 minecraft:smooth_basalt
setblock 96 235 551 minecraft:blackstone
setblock 97 235 511 minecraft:smooth_basalt
fill 97 235 512 98 235 512 minecraft:blackstone
setblock 97 235 516 minecraft:smooth_basalt
setblock 97 235 517 minecraft:blackstone
setblock 97 235 551 minecraft:smooth_basalt
fill 98 235 511 100 235 511 minecraft:blackstone
fill 98 235 551 99 235 551 minecraft:blackstone
fill 109 235 518 109 269 519 minecraft:smooth_basalt
fill 110 235 519 111 269 519 minecraft:smooth_basalt
fill 111 235 520 112 269 521 minecraft:smooth_basalt
setblock 113 235 551 minecraft:blackstone
setblock 132 235 511 minecraft:smooth_basalt
fill 132 235 512 132 238 512 minecraft:blackstone
setblock 132 235 517 minecraft:blackstone
fill 133 235 511 133 238 511 minecraft:blackstone
setblock 133 235 514 minecraft:blackstone
setblock 133 235 515 minecraft:smooth_basalt
fill 133 235 516 133 238 516 minecraft:blackstone
setblock 133 235 520 minecraft:smooth_basalt
fill 133 235 521 133 238 521 minecraft:blackstone
fill 133 235 523 134 235 523 minecraft:blackstone
setblock 134 235 514 minecraft:smooth_basalt
fill 134 235 515 134 238 515 minecraft:blackstone
setblock 134 235 519 minecraft:smooth_basalt
fill 134 235 520 134 238 520 minecraft:blackstone
setblock 134 235 524 minecraft:smooth_basalt
fill 134 235 525 134 238 525 minecraft:blackstone
setblock 134 235 539 minecraft:smooth_basalt
fill 134 235 540 134 238 540 minecraft:blackstone
setblock 135 235 513 minecraft:smooth_basalt
fill 135 235 514 135 238 514 minecraft:blackstone
setblock 135 235 518 minecraft:smooth_basalt
fill 135 235 519 135 238 519 minecraft:blackstone
setblock 135 235 523 minecraft:smooth_basalt
fill 135 235 524 135 238 524 minecraft:blackstone
setblock 135 235 528 minecraft:smooth_basalt
setblock 135 235 529 minecraft:blackstone
setblock 135 235 533 minecraft:smooth_basalt
fill 135 235 534 135 236 534 minecraft:blackstone
setblock 135 235 538 minecraft:smooth_basalt
fill 135 235 539 135 238 539 minecraft:blackstone
setblock 135 235 543 minecraft:smooth_basalt
fill 135 235 544 135 238 544 minecraft:blackstone
setblock 95 236 511 minecraft:blackstone
setblock 95 236 512 minecraft:smooth_basalt
fill 95 236 513 95 236 516 minecraft:blackstone
setblock 95 236 517 minecraft:smooth_basalt
fill 95 236 518 95 236 521 minecraft:blackstone
setblock 95 236 522 minecraft:smooth_basalt
fill 95 236 523 95 239 523 minecraft:blackstone
fill 95 236 535 95 236 536 minecraft:blackstone
setblock 95 236 537 minecraft:smooth_basalt
fill 95 236 538 95 236 541 minecraft:blackstone
setblock 95 236 542 minecraft:smooth_basalt
fill 95 236 543 95 239 543 minecraft:blackstone
setblock 95 236 547 minecraft:smooth_basalt
fill 95 236 548 95 239 548 minecraft:blackstone
setblock 96 236 511 minecraft:smooth_basalt
setblock 96 236 512 minecraft:blackstone
setblock 96 236 516 minecraft:smooth_basalt
fill 96 236 517 96 239 517 minecraft:blackstone
setblock 96 236 521 minecraft:smooth_basalt
setblock 96 236 522 minecraft:blackstone
setblock 96 236 541 minecraft:smooth_basalt
fill 96 236 542 96 239 542 minecraft:blackstone
setblock 96 236 546 minecraft:smooth_basalt
fill 96 236 547 96 239 547 minecraft:blackstone
setblock 96 236 551 minecraft:smooth_basalt
fill 97 236 511 98 236 511 minecraft:blackstone
fill 97 236 551 98 238 551 minecraft:blackstone
setblock 131 236 511 minecraft:smooth_basalt
fill 132 236 511 132 239 511 minecraft:blackstone
setblock 132 236 520 minecraft:smooth_basalt
setblock 133 236 514 minecraft:smooth_basalt
fill 133 236 515 133 239 515 minecraft:blackstone
setblock 133 236 519 minecraft:smooth_basalt
fill 133 236 520 133 239 520 minecraft:blackstone
setblock 133 236 523 minecraft:blackstone
setblock 134 236 513 minecraft:smooth_basalt
fill 134 236 514 134 239 514 minecraft:blackstone
setblock 134 236 518 minecraft:smooth_basalt
fill 134 236 519 134 239 519 minecraft:blackstone
setblock 134 236 522 minecraft:blackstone
setblock 134 236 523 minecraft:smooth_basalt
fill 134 236 524 134 239 524 minecraft:blackstone
setblock 134 236 539 minecraft:blackstone
setblock 135 236 512 minecraft:smooth_basalt
fill 135 236 513 135 239 513 minecraft:blackstone
setblock 135 236 517 minecraft:smooth_basalt
fill 135 236 518 135 239 518 minecraft:blackstone
setblock 135 236 522 minecraft:smooth_basalt
fill 135 236 523 135 239 523 minecraft:blackstone
setblock 135 236 527 minecraft:smooth_basalt
fill 135 236 528 135 239 528 minecraft:blackstone
setblock 135 236 537 minecraft:smooth_basalt
fill 135 236 538 135 239 538 minecraft:blackstone
setblock 135 236 542 minecraft:smooth_basalt
fill 135 236 543 135 239 543 minecraft:blackstone
setblock 135 236 547 minecraft:smooth_basalt
setblock 95 237 511 minecraft:smooth_basalt
fill 95 237 512 95 237 515 minecraft:blackstone
setblock 95 237 516 minecraft:smooth_basalt
fill 95 237 517 95 237 520 minecraft:blackstone
setblock 95 237 521 minecraft:smooth_basalt
fill 95 237 522 95 240 522 minecraft:blackstone
setblock 95 237 536 minecraft:smooth_basalt
fill 95 237 537 95 237 540 minecraft:blackstone
setblock 95 237 541 minecraft:smooth_basalt
fill 95 237 542 95 240 542 minecraft:blackstone
setblock 95 237 546 minecraft:smooth_basalt
fill 95 237 547 95 240 547 minecraft:blackstone
fill 95 237 549 95 237 550 minecraft:blackstone
setblock 95 237 551 minecraft:smooth_basalt
fill 96 237 511 97 238 511 minecraft:blackstone
setblock 96 237 515 minecraft:smooth_basalt
fill 96 237 516 96 238 516 minecraft:blackstone
setblock 96 237 520 minecraft:smooth_basalt
fill 96 237 521 96 240 521 minecraft:blackstone
setblock 96 237 540 minecraft:smooth_basalt
fill 96 237 541 96 240 541 minecraft:blackstone
setblock 96 237 545 minecraft:smooth_basalt
fill 96 237 546 96 240 546 minecraft:blackstone
fill 96 237 548 96 238 548 minecraft:blackstone
fill 96 237 551 96 240 551 minecraft:blackstone
setblock 97 237 513 minecraft:light[level=12]
setblock 97 237 521 minecraft:light[level=12]
setblock 97 237 529 minecraft:light[level=12]
setblock 97 237 537 minecraft:light[level=12]
setblock 97 237 545 minecraft:light[level=12]
setblock 105 237 513 minecraft:light[level=12]
setblock 105 237 521 minecraft:light[level=12]
setblock 105 237 529 minecraft:light[level=12]
setblock 105 237 537 minecraft:light[level=12]
setblock 105 237 545 minecraft:light[level=12]
setblock 113 237 513 minecraft:light[level=12]
setblock 113 237 521 minecraft:light[level=12]
setblock 113 237 529 minecraft:light[level=12]
setblock 113 237 537 minecraft:light[level=12]
setblock 113 237 545 minecraft:light[level=12]
setblock 121 237 513 minecraft:light[level=12]
setblock 121 237 521 minecraft:light[level=12]
setblock 121 237 529 minecraft:light[level=12]
setblock 121 237 537 minecraft:light[level=12]
setblock 121 237 545 minecraft:light[level=12]
setblock 129 237 513 minecraft:light[level=12]
setblock 129 237 521 minecraft:light[level=12]
setblock 129 237 529 minecraft:light[level=12]
setblock 129 237 537 minecraft:light[level=12]
setblock 129 237 545 minecraft:light[level=12]
setblock 130 237 511 minecraft:smooth_basalt
fill 131 237 511 131 240 511 minecraft:blackstone
setblock 132 237 518 minecraft:blackstone
setblock 132 237 519 minecraft:smooth_basalt
fill 132 237 520 132 239 521 minecraft:blackstone
fill 133 237 514 133 238 514 minecraft:blackstone
setblock 133 237 518 minecraft:smooth_basalt
fill 133 237 519 133 240 519 minecraft:blackstone
setblock 133 237 523 minecraft:smooth_basalt
fill 133 237 524 133 240 524 minecraft:blackstone
setblock 134 237 512 minecraft:smooth_basalt
fill 134 237 513 134 240 513 minecraft:blackstone
setblock 134 237 517 minecraft:smooth_basalt
fill 134 237 518 134 240 518 minecraft:blackstone
setblock 134 237 522 minecraft:smooth_basalt
fill 134 237 523 134 240 523 minecraft:blackstone
setblock 134 237 541 minecraft:blackstone
setblock 134 237 542 minecraft:smooth_basalt
fill 134 237 543 134 240 543 minecraft:blackstone
setblock 135 237 511 minecraft:smooth_basalt
fill 135 237 512 135 240 512 minecraft:blackstone
setblock 135 237 516 minecraft:smooth_basalt
fill 135 237 517 135 240 517 minecraft:blackstone
setblock 135 237 521 minecraft:smooth_basalt
fill 135 237 522 135 240 522 minecraft:blackstone
setblock 135 237 526 minecraft:smooth_basalt
fill 135 237 527 135 240 527 minecraft:blackstone
setblock 135 237 536 minecraft:smooth_basalt
fill 135 237 537 135 238 537 minecraft:blackstone
setblock 135 237 541 minecraft:smooth_basalt
fill 135 237 542 135 240 542 minecraft:blackstone
setblock 135 237 546 minecraft:smooth_basalt
fill 135 237 547 135 238 549 minecraft:blackstone
fill 95 238 511 95 238 514 minecraft:blackstone
setblock 95 238 515 minecraft:smooth_basalt
fill 95 238 516 95 238 519 minecraft:blackstone
setblock 95 238 520 minecraft:smooth_basalt
fill 95 238 521 95 241 521 minecraft:blackstone
setblock 95 238 525 minecraft:smooth_basalt
fill 95 238 537 95 238 539 minecraft:blackstone
setblock 95 238 540 minecraft:smooth_basalt
fill 95 238 541 95 241 541 minecraft:blackstone
setblock 95 238 545 minecraft:smooth_basalt
fill 95 238 546 95 241 546 minecraft:blackstone
setblock 95 238 549 minecraft:blackstone
setblock 95 238 550 minecraft:smooth_basalt
fill 95 238 551 95 241 551 minecraft:blackstone
setblock 96 238 515 minecraft:blackstone
setblock 96 238 519 minecraft:smooth_basalt
fill 96 238 520 96 240 520 minecraft:blackstone
setblock 96 238 539 minecraft:smooth_basalt
fill 96 238 540 96 241 540 minecraft:blackstone
setblock 96 238 544 minecraft:smooth_basalt
fill 96 238 545 96 241 545 minecraft:blackstone
setblock 96 238 549 minecraft:smooth_basalt
fill 111 238 551 112 239 551 minecraft:blackstone
fill 119 238 521 122 273 522 minecraft:smooth_basalt
fill 120 238 523 122 273 523 minecraft:smooth_basalt
fill 130 238 511 130 241 511 minecraft:blackstone
setblock 132 238 518 minecraft:smooth_basalt
fill 132 238 519 132 241 519 minecraft:blackstone
setblock 132 238 522 minecraft:blackstone
setblock 133 238 512 minecraft:smooth_basalt
setblock 133 238 517 minecraft:smooth_basalt
fill 133 238 518 133 241 518 minecraft:blackstone
setblock 133 238 522 minecraft:smooth_basalt
fill 133 238 523 133 241 523 minecraft:blackstone
setblock 133 238 551 minecraft:blackstone
setblock 134 238 511 minecraft:smooth_basalt
fill 134 238 512 134 241 512 minecraft:blackstone
setblock 134 238 516 minecraft:smooth_basalt
fill 134 238 517 134 241 517 minecraft:blackstone
setblock 134 238 521 minecraft:smooth_basalt
fill 134 238 522 134 241 522 minecraft:blackstone
setblock 134 238 526 minecraft:smooth_basalt
setblock 134 238 541 minecraft:smooth_basalt
fill 134 238 542 134 241 542 minecraft:blackstone
fill 134 238 544 134 238 545 minecraft:blackstone
setblock 134 238 551 minecraft:smooth_basalt
fill 135 238 511 135 241 511 minecraft:blackstone
setblock 135 238 515 minecraft:smooth_basalt
fill 135 238 516 135 241 516 minecraft:blackstone
setblock 135 238 520 minecraft:smooth_basalt
fill 135 238 521 135 241 521 minecraft:blackstone
setblock 135 238 525 minecraft:smooth_basalt
fill 135 238 526 135 241 526 minecraft:blackstone
setblock 135 238 540 minecraft:smooth_basalt
fill 135 238 541 135 241 541 minecraft:blackstone
setblock 135 238 545 minecraft:smooth_basalt
fill 135 238 546 135 241 546 minecraft:blackstone
setblock 135 238 550 minecraft:smooth_basalt
fill 135 238 551 135 241 551 minecraft:blackstone
fill 95 239 511 95 239 513 minecraft:blackstone
setblock 95 239 514 minecraft:smooth_basalt
fill 95 239 515 95 239 518 minecraft:blackstone
setblock 95 239 519 minecraft:smooth_basalt
fill 95 239 520 95 242 520 minecraft:blackstone
setblock 95 239 524 minecraft:smooth_basalt
fill 95 239 525 95 241 526 minecraft:blackstone
fill 95 239 537 95 239 538 minecraft:blackstone
setblock 95 239 539 minecraft:smooth_basalt
fill 95 239 540 95 242 540 minecraft:blackstone
setblock 95 239 544 minecraft:smooth_basalt
fill 95 239 545 95 242 545 minecraft:blackstone
setblock 95 239 549 minecraft:smooth_basalt
fill 95 239 550 96 241 550 minecraft:blackstone
fill 96 239 511 96 240 511 minecraft:blackstone
setblock 96 239 518 minecraft:smooth_basalt
fill 96 239 519 96 240 519 minecraft:blackstone
setblock 96 239 543 minecraft:smooth_basalt
fill 96 239 544 96 242 544 minecraft:blackstone
setblock 96 239 548 minecraft:smooth_basalt
fill 96 239 549 96 242 549 minecraft:blackstone
setblock 97 239 551 minecraft:blackstone
setblock 98 239 551 minecraft:smooth_basalt
setblock 108 239 551 minecraft:smooth_basalt
fill 109 239 551 110 241 551 minecraft:blackstone
setblock 113 239 551 minecraft:smooth_basalt
fill 118 239 522 118 240 522 minecraft:blackstone
fill 119 239 520 122 240 520 minecraft:blackstone
fill 119 239 523 119 240 524 minecraft:blackstone
fill 120 239 524 122 240 524 minecraft:blackstone
fill 123 239 521 123 240 522 minecraft:blackstone
fill 129 239 511 129 242 511 minecraft:blackstone
setblock 131 239 512 minecraft:blackstone
fill 131 239 551 132 239 551 minecraft:blackstone
setblock 132 239 512 minecraft:smooth_basalt
fill 132 239 518 132 242 518 minecraft:blackstone
setblock 132 239 522 minecraft:smooth_basalt
fill 132 239 523 132 242 523 minecraft:blackstone
setblock 133 239 511 minecraft:smooth_basalt
fill 133 239 512 133 242 512 minecraft:blackstone
setblock 133 239 516 minecraft:smooth_basalt
fill 133 239 517 133 242 517 minecraft:blackstone
setblock 133 239 521 minecraft:smooth_basalt
fill 133 239 522 133 242 522 minecraft:blackstone
setblock 133 239 525 minecraft:blackstone
setblock 133 239 551 minecraft:smooth_basalt
fill 134 239 511 134 242 511 minecraft:blackstone
setblock 134 239 515 minecraft:smooth_basalt
fill 134 239 516 134 242 516 minecraft:blackstone
setblock 134 239 520 minecraft:smooth_basalt
fill 134 239 521 134 242 521 minecraft:blackstone
setblock 134 239 525 minecraft:smooth_basalt
fill 134 239 526 134 241 527 minecraft:blackstone
fill 134 239 541 134 242 541 minecraft:blackstone
setblock 134 239 544 minecraft:blackstone
setblock 134 239 545 minecraft:smooth_basalt
fill 134 239 546 134 241 547 minecraft:blackstone
fill 134 239 551 134 242 551 minecraft:blackstone
setblock 135 239 514 minecraft:smooth_basalt
fill 135 239 515 135 242 515 minecraft:blackstone
setblock 135 239 519 minecraft:smooth_basalt
fill 135 239 520 135 242 520 minecraft:blackstone
setblock 135 239 524 minecraft:smooth_basalt
fill 135 239 525 135 242 525 minecraft:blackstone
setblock 135 239 539 minecraft:smooth_basalt
fill 135 239 540 135 242 540 minecraft:blackstone
setblock 135 239 544 minecraft:smooth_basalt
fill 135 239 545 135 242 545 minecraft:blackstone
fill 135 239 547 135 239 548 minecraft:blackstone
setblock 135 239 549 minecraft:smooth_basalt
fill 135 239 550 135 242 550 minecraft:blackstone
fill 95 240 511 95 240 512 minecraft:blackstone
setblock 95 240 513 minecraft:smooth_basalt
fill 95 240 514 95 240 517 minecraft:blackstone
setblock 95 240 518 minecraft:smooth_basalt
fill 95 240 519 95 243 519 minecraft:blackstone
setblock 95 240 523 minecraft:smooth_basalt
fill 95 240 524 95 243 524 minecraft:blackstone
setblock 95 240 537 minecraft:blackstone
setblock 95 240 538 minecraft:smooth_basalt
fill 95 240 539 95 243 539 minecraft:blackstone
setblock 95 240 543 minecraft:smooth_basalt
fill 95 240 544 95 243 544 minecraft:blackstone
setblock 95 240 548 minecraft:smooth_basalt
fill 95 240 549 95 243 549 minecraft:blackstone
setblock 96 240 542 minecraft:smooth_basalt
fill 96 240 543 96 243 543 minecraft:blackstone
setblock 96 240 547 minecraft:smooth_basalt
fill 96 240 548 96 243 548 minecraft:blackstone
fill 97 240 544 97 240 545 minecraft:blackstone
setblock 97 240 546 minecraft:smooth_basalt
setblock 97 240 550 minecraft:blackstone
setblock 97 240 551 minecraft:smooth_basalt
fill 98 240 551 99 242 551 minecraft:blackstone
setblock 106 240 551 minecraft:blackstone
setblock 107 240 551 minecraft:smooth_basalt
fill 108 240 551 108 243 551 minecraft:blackstone
fill 109 240 550 111 241 550 minecraft:blackstone
setblock 111 240 551 minecraft:blackstone
setblock 112 240 551 minecraft:smooth_basalt
fill 113 240 551 114 242 551 minecraft:blackstone
fill 118 240 520 118 240 521 minecraft:blackstone
fill 118 240 523 118 240 524 minecraft:blackstone
fill 119 240 519 122 240 519 minecraft:blackstone
fill 120 240 525 121 240 525 minecraft:blackstone
setblock 123 240 520 minecraft:blackstone
fill 123 240 523 123 240 524 minecraft:blackstone
fill 128 240 511 128 243 511 minecraft:blackstone
setblock 130 240 512 minecraft:blackstone
fill 130 240 551 131 240 551 minecraft:blackstone
setblock 131 240 512 minecraft:smooth_basalt
setblock 132 240 511 minecraft:smooth_basalt
fill 132 240 512 132 243 512 minecraft:blackstone
setblock 132 240 520 minecraft:blackstone
setblock 132 240 521 minecraft:smooth_basalt
fill 132 240 522 132 243 522 minecraft:blackstone
fill 132 240 524 132 241 524 minecraft:blackstone
setblock 132 240 551 minecraft:smooth_basalt
fill 133 240 511 133 243 511 minecraft:blackstone
setblock 133 240 515 minecraft:smooth_basalt
fill 133 240 516 133 243 516 minecraft:blackstone
setblock 133 240 520 minecraft:smooth_basalt
fill 133 240 521 133 243 521 minecraft:blackstone
setblock 133 240 525 minecraft:smooth_basalt
fill 133 240 526 133 243 526 minecraft:blackstone
fill 133 240 551 133 243 551 minecraft:blackstone
setblock 134 240 514 minecraft:smooth_basalt
fill 134 240 515 134 243 515 minecraft:blackstone
setblock 134 240 519 minecraft:smooth_basalt
fill 134 240 520 134 243 520 minecraft:blackstone
setblock 134 240 524 minecraft:smooth_basalt
fill 134 240 525 134 243 525 minecraft:blackstone
setblock 134 240 544 minecraft:smooth_basalt
fill 134 240 545 134 243 545 minecraft:blackstone
setblock 134 240 548 minecraft:blackstone
setblock 134 240 549 minecraft:smooth_basalt
setblock 135 240 513 minecraft:smooth_basalt
fill 135 240 514 135 243 514 minecraft:blackstone
setblock 135 240 518 minecraft:smooth_basalt
fill 135 240 519 135 243 519 minecraft:blackstone
setblock 135 240 523 minecraft:smooth_basalt
fill 135 240 524 135 243 524 minecraft:blackstone
setblock 135 240 528 minecraft:smooth_basalt
fill 135 240 529 135 243 529 minecraft:blackstone
setblock 135 240 538 minecraft:smooth_basalt
fill 135 240 539 135 242 539 minecraft:blackstone
setblock 135 240 543 minecraft:smooth_basalt
fill 135 240 544 135 243 544 minecraft:blackstone
setblock 135 240 547 minecraft:blackstone
setblock 135 240 548 minecraft:smooth_basalt
fill 135 240 549 135 243 549 minecraft:blackstone
setblock 95 241 511 minecraft:blackstone
setblock 95 241 512 minecraft:smooth_basalt
fill 95 241 513 95 241 516 minecraft:blackstone
setblock 95 241 517 minecraft:smooth_basalt
fill 95 241 518 95 244 518 minecraft:blackstone
setblock 95 241 522 minecraft:smooth_basalt
fill 95 241 523 95 244 523 minecraft:blackstone
setblock 95 241 527 minecraft:smooth_basalt
setblock 95 241 537 minecraft:smooth_basalt
fill 95 241 538 95 244 538 minecraft:blackstone
setblock 95 241 542 minecraft:smooth_basalt
fill 95 241 543 95 244 543 minecraft:blackstone
setblock 95 241 547 minecraft:smooth_basalt
fill 95 241 548 95 244 548 minecraft:blackstone
setblock 96 241 511 minecraft:smooth_basalt
setblock 96 241 541 minecraft:smooth_basalt
fill 96 241 542 96 244 542 minecraft:blackstone
setblock 96 241 546 minecraft:smooth_basalt
fill 96 241 547 97 243 547 minecraft:blackstone
setblock 96 241 551 minecraft:smooth_basalt
fill 97 241 543 97 241 544 minecraft:blackstone
setblock 97 241 545 minecraft:smooth_basalt
fill 97 241 546 97 244 546 minecraft:blackstone
setblock 97 241 550 minecraft:smooth_basalt
fill 97 241 551 97 244 551 minecraft:blackstone
fill 98 241 550 98 244 550 minecraft:blackstone
setblock 100 241 551 minecraft:blackstone
setblock 101 241 551 minecraft:smooth_basalt
fill 102 241 551 105 241 551 minecraft:blackstone
setblock 106 241 550 minecraft:blackstone
setblock 106 241 551 minecraft:smooth_basalt
setblock 107 241 550 minecraft:smooth_basalt
fill 107 241 551 107 244 551 minecraft:blackstone
fill 108 241 550 108 244 550 minecraft:blackstone
setblock 111 241 551 minecraft:smooth_basalt
setblock 112 241 550 minecraft:smooth_basalt
fill 112 241 551 112 244 551 minecraft:blackstone
fill 113 241 550 113 244 550 minecraft:blackstone
fill 127 241 511 127 244 511 minecraft:blackstone
fill 128 241 551 130 241 551 minecraft:blackstone
setblock 129 241 512 minecraft:blackstone
setblock 130 241 512 minecraft:smooth_basalt
fill 130 241 550 131 241 550 minecraft:blackstone
setblock 131 241 511 minecraft:smooth_basalt
fill 131 241 512 131 244 512 minecraft:blackstone
setblock 131 241 551 minecraft:smooth_basalt
fill 132 241 511 132 244 511 minecraft:blackstone
setblock 132 241 520 minecraft:smooth_basalt
fill 132 241 521 132 244 521 minecraft:blackstone
setblock 132 241 550 minecraft:smooth_basalt
fill 132 241 551 132 244 551 minecraft:blackstone
fill 133 241 515 133 242 515 minecraft:blackstone
setblock 133 241 519 minecraft:smooth_basalt
fill 133 241 520 133 244 520 minecraft:blackstone
setblock 133 241 524 minecraft:smooth_basalt
fill 133 241 525 133 244 525 minecraft:blackstone
fill 133 241 545 133 243 546 minecraft:blackstone
fill 133 241 550 134 243 550 minecraft:blackstone
setblock 134 241 513 minecraft:smooth_basalt
fill 134 241 514 134 244 514 minecraft:blackstone
setblock 134 241 518 minecraft:smooth_basalt
fill 134 241 519 134 244 519 minecraft:blackstone
setblock 134 241 523 minecraft:smooth_basalt
fill 134 241 524 134 244 524 minecraft:blackstone
setblock 134 241 528 minecraft:smooth_basalt
setblock 134 241 543 minecraft:smooth_basalt
fill 134 241 544 134 244 544 minecraft:blackstone
setblock 134 241 548 minecraft:smooth_basalt
fill 134 241 549 134 244 549 minecraft:blackstone
setblock 135 241 512 minecraft:smooth_basalt
fill 135 241 513 135 244 513 minecraft:blackstone
setblock 135 241 517 minecraft:smooth_basalt
fill 135 241 518 135 244 518 minecraft:blackstone
setblock 135 241 522 minecraft:smooth_basalt
fill 135 241 523 135 244 523 minecraft:blackstone
setblock 135 241 527 minecraft:smooth_basalt
fill 135 241 528 135 244 528 minecraft:blackstone
setblock 135 241 542 minecraft:smooth_basalt
fill 135 241 543 135 244 543 minecraft:blackstone
setblock 135 241 547 minecraft:smooth_basalt
fill 135 241 548 135 244 548 minecraft:blackstone
setblock 95 242 511 minecraft:smooth_basalt
fill 95 242 512 95 242 515 minecraft:blackstone
setblock 95 242 516 minecraft:smooth_basalt
fill 95 242 517 95 243 517 minecraft:blackstone
setblock 95 242 521 minecraft:smooth_basalt
fill 95 242 522 95 245 522 minecraft:blackstone
setblock 95 242 525 minecraft:blackstone
setblock 95 242 526 minecraft:smooth_basalt
fill 95 242 527 95 244 528 minecraft:blackstone
setblock 95 242 537 minecraft:blackstone
setblock 95 242 541 minecraft:smooth_basalt
fill 95 242 542 95 245 542 minecraft:blackstone
setblock 95 242 546 minecraft:smooth_basalt
fill 95 242 547 95 245 547 minecraft:blackstone
setblock 95 242 550 minecraft:blackstone
setblock 95 242 551 minecraft:smooth_basalt
fill 96 242 511 96 244 511 minecraft:blackstone
setblock 96 242 540 minecraft:smooth_basalt
fill 96 242 541 96 244 541 minecraft:blackstone
setblock 96 242 545 minecraft:smooth_basalt
fill 96 242 546 96 245 546 minecraft:blackstone
setblock 96 242 550 minecraft:smooth_basalt
fill 96 242 551 96 245 551 minecraft:blackstone
setblock 97 242 543 minecraft:blackstone
setblock 97 242 544 minecraft:smooth_basalt
fill 97 242 545 97 245 545 minecraft:blackstone
setblock 97 242 548 minecraft:blackstone
fill 97 242 550 97 245 550 minecraft:blackstone
fill 99 242 550 99 243 550 minecraft:blackstone
setblock 100 242 551 minecraft:smooth_basalt
fill 101 242 551 104 242 551 minecraft:blackstone
fill 104 242 550 105 242 550 minecraft:blackstone
setblock 105 242 551 minecraft:smooth_basalt
setblock 106 242 549 minecraft:blackstone
setblock 106 242 550 minecraft:smooth_basalt
fill 106 242 551 106 245 551 minecraft:blackstone
setblock 107 242 549 minecraft:smooth_basalt
fill 107 242 550 107 245 550 minecraft:blackstone
fill 108 242 549 111 242 549 minecraft:blackstone
fill 109 242 550 109 242 551 minecraft:blackstone
setblock 110 242 550 minecraft:blackstone
setblock 110 242 551 minecraft:smooth_basalt
setblock 111 242 550 minecraft:smooth_basalt
fill 111 242 551 111 245 551 minecraft:blackstone
setblock 112 242 549 minecraft:smooth_basalt
fill 112 242 550 112 245 550 minecraft:blackstone
setblock 115 242 551 minecraft:smooth_basalt
fill 126 242 511 126 245 511 minecraft:blackstone
fill 127 242 551 129 242 551 minecraft:blackstone
setblock 128 242 512 minecraft:blackstone
fill 128 242 550 130 242 550 minecraft:blackstone
setblock 129 242 512 minecraft:smooth_basalt
setblock 130 242 511 minecraft:smooth_basalt
fill 130 242 512 130 245 512 minecraft:blackstone
setblock 130 242 551 minecraft:smooth_basalt
fill 131 242 511 131 245 511 minecraft:blackstone
fill 131 242 513 131 243 513 minecraft:blackstone
setblock 131 242 549 minecraft:blackstone
setblock 131 242 550 minecraft:smooth_basalt
fill 131 242 551 131 245 551 minecraft:blackstone
setblock 132 242 519 minecraft:smooth_basalt
fill 132 242 520 132 243 520 minecraft:blackstone
setblock 132 242 524 minecraft:smooth_basalt
fill 132 242 525 132 244 525 minecraft:blackstone
setblock 132 242 549 minecraft:smooth_basalt
fill 132 242 550 132 245 550 minecraft:blackstone
setblock 133 242 518 minecraft:smooth_basalt
fill 133 242 519 133 244 519 minecraft:blackstone
setblock 133 242 523 minecraft:smooth_basalt
fill 133 242 524 133 245 524 minecraft:blackstone
setblock 133 242 527 minecraft:blackstone
fill 133 242 544 133 244 544 minecraft:blackstone
setblock 133 242 547 minecraft:blackstone
setblock 133 242 548 minecraft:smooth_basalt
fill 133 242 549 133 245 549 minecraft:blackstone
setblock 134 242 512 minecraft:smooth_basalt
fill 134 242 513 134 245 513 minecraft:blackstone
setblock 134 242 517 minecraft:smooth_basalt
fill 134 242 518 134 245 518 minecraft:blackstone
setblock 134 242 522 minecraft:smooth_basalt
fill 134 242 523 134 245 523 minecraft:blackstone
setblock 134 242 526 minecraft:blackstone
setblock 134 242 527 minecraft:smooth_basalt
fill 134 242 528 134 245 528 minecraft:blackstone
setblock 134 242 542 minecraft:smooth_basalt
fill 134 242 543 134 245 543 minecraft:blackstone
setblock 134 242 546 minecraft:blackstone
setblock 134 242 547 minecraft:smooth_basalt
fill 134 242 548 134 245 548 minecraft:blackstone
setblock 135 242 511 minecraft:smooth_basalt
fill 135 242 512 135 245 512 minecraft:blackstone
setblock 135 242 516 minecraft:smooth_basalt
fill 135 242 517 135 245 517 minecraft:blackstone
setblock 135 242 521 minecraft:smooth_basalt
fill 135 242 522 135 245 522 minecraft:blackstone
setblock 135 242 526 minecraft:smooth_basalt
fill 135 242 527 135 245 527 minecraft:blackstone
setblock 135 242 530 minecraft:blackstone
setblock 135 242 541 minecraft:smooth_basalt
fill 135 242 542 135 245 542 minecraft:blackstone
setblock 135 242 546 minecraft:smooth_basalt
fill 135 242 547 135 245 547 minecraft:blackstone
setblock 135 242 551 minecraft:smooth_basalt
fill 95 243 511 95 243 514 minecraft:blackstone
setblock 95 243 515 minecraft:smooth_basalt
setblock 95 243 516 minecraft:blackstone
setblock 95 243 520 minecraft:smooth_basalt
fill 95 243 521 95 245 521 minecraft:blackstone
setblock 95 243 525 minecraft:smooth_basalt
fill 95 243 526 95 246 526 minecraft:blackstone
setblock 95 243 529 minecraft:blackstone
setblock 95 243 540 minecraft:smooth_basalt
fill 95 243 541 95 246 541 minecraft:blackstone
setblock 95 243 545 minecraft:smooth_basalt
fill 95 243 546 95 246 546 minecraft:blackstone
setblock 95 243 550 minecraft:smooth_basalt
fill 95 243 551 95 246 551 minecraft:blackstone
setblock 96 243 544 minecraft:smooth_basalt
fill 96 243 545 96 246 545 minecraft:blackstone
setblock 96 243 549 minecraft:smooth_basalt
fill 96 243 550 96 246 550 minecraft:blackstone
setblock 97 243 543 minecraft:smooth_basalt
fill 97 243 544 97 244 544 minecraft:blackstone
setblock 97 243 548 minecraft:smooth_basalt
fill 97 243 549 97 246 549 minecraft:blackstone
setblock 98 243 551 minecraft:blackstone
setblock 99 243 551 minecraft:smooth_basalt
setblock 100 243 550 minecraft:smooth_basalt
fill 100 243 551 103 243 551 minecraft:blackstone
fill 101 243 550 104 243 550 minecraft:blackstone
fill 104 243 549 105 243 549 minecraft:blackstone
setblock 104 243 551 minecraft:smooth_basalt
setblock 105 243 550 minecraft:smooth_basalt
fill 105 243 551 105 246 551 minecraft:blackstone
setblock 106 243 549 minecraft:smooth_basalt
fill 106 243 550 106 246 550 minecraft:blackstone
fill 107 243 549 110 243 549 minecraft:blackstone
setblock 108 243 511 minecraft:blackstone
fill 108 243 548 110 244 548 minecraft:blackstone
setblock 109 243 511 minecraft:smooth_basalt
setblock 109 243 550 minecraft:blackstone
setblock 109 243 551 minecraft:smooth_basalt
fill 110 243 511 111 245 511 minecraft:blackstone
setblock 110 243 550 minecraft:smooth_basalt
fill 110 243 551 110 246 551 minecraft:blackstone
setblock 111 243 549 minecraft:smooth_basalt
fill 111 243 550 111 246 550 minecraft:blackstone
fill 112 243 549 112 245 549 minecraft:blackstone
setblock 113 243 551 minecraft:blackstone
setblock 114 243 550 minecraft:blackstone
setblock 114 243 551 minecraft:smooth_basalt
fill 115 243 551 115 246 551 minecraft:blackstone
fill 125 243 511 125 246 511 minecraft:blackstone
fill 125 243 551 128 243 551 minecraft:blackstone
setblock 127 243 512 minecraft:blackstone
fill 127 243 550 129 243 550 minecraft:blackstone
setblock 128 243 512 minecraft:smooth_basalt
setblock 129 243 511 minecraft:smooth_basalt
fill 129 243 512 129 246 512 minecraft:blackstone
fill 129 243 549 130 243 549 minecraft:blackstone
setblock 129 243 551 minecraft:smooth_basalt
fill 130 243 511 130 246 511 minecraft:blackstone
fill 130 243 513 130 244 513 minecraft:blackstone
setblock 130 243 550 minecraft:smooth_basalt
fill 130 243 551 130 246 551 minecraft:blackstone
setblock 131 243 549 minecraft:smooth_basalt
fill 131 243 550 131 246 550 minecraft:blackstone
setblock 132 243 513 minecraft:smooth_basalt
setblock 132 243 519 minecraft:blackstone
setblock 132 243 523 minecraft:smooth_basalt
fill 132 243 524 132 244 524 minecraft:blackstone
fill 132 243 549 132 246 549 minecraft:blackstone
setblock 133 243 512 minecraft:smooth_basalt
setblock 133 243 517 minecraft:smooth_basalt
fill 133 243 518 133 244 518 minecraft:blackstone
setblock 133 243 522 minecraft:smooth_basalt
fill 133 243 523 133 245 523 minecraft:blackstone
setblock 133 243 527 minecraft:smooth_basalt
setblock 133 243 547 minecraft:smooth_basalt
fill 133 243 548 133 246 548 minecraft:blackstone
setblock 134 243 511 minecraft:smooth_basalt
fill 134 243 512 134 246 512 minecraft:blackstone
setblock 134 243 516 minecraft:smooth_basalt
fill 134 243 517 134 245 517 minecraft:blackstone
setblock 134 243 521 minecraft:smooth_basalt
fill 134 243 522 134 246 522 minecraft:blackstone
setblock 134 243 526 minecraft:smooth_basalt
fill 134 243 527 134 246 527 minecraft:blackstone
fill 134 243 542 134 244 542 minecraft:blackstone
setblock 134 243 546 minecraft:smooth_basalt
fill 134 243 547 134 246 547 minecraft:blackstone
setblock 134 243 551 minecraft:smooth_basalt
fill 135 243 511 135 246 511 minecraft:blackstone
setblock 135 243 515 minecraft:smooth_basalt
fill 135 243 516 135 246 516 minecraft:blackstone
setblock 135 243 520 minecraft:smooth_basalt
fill 135 243 521 135 246 521 minecraft:blackstone
setblock 135 243 525 minecraft:smooth_basalt
fill 135 243 526 135 246 526 minecraft:blackstone
setblock 135 243 530 minecraft:smooth_basalt
setblock 135 243 540 minecraft:smooth_basalt
fill 135 243 541 135 245 541 minecraft:blackstone
setblock 135 243 545 minecraft:smooth_basalt
fill 135 243 546 135 246 546 minecraft:blackstone
setblock 135 243 550 minecraft:smooth_basalt
fill 135 243 551 135 246 551 minecraft:blackstone
fill 95 244 511 95 245 512 minecraft:blackstone
setblock 95 244 519 minecraft:smooth_basalt
setblock 95 244 520 minecraft:blackstone
setblock 95 244 524 minecraft:smooth_basalt
fill 95 244 525 95 246 525 minecraft:blackstone
setblock 95 244 529 minecraft:smooth_basalt
setblock 95 244 539 minecraft:smooth_basalt
fill 95 244 540 95 246 540 minecraft:blackstone
setblock 95 244 544 minecraft:smooth_basalt
fill 95 244 545 95 247 545 minecraft:blackstone
setblock 95 244 549 minecraft:smooth_basalt
fill 95 244 550 95 247 550 minecraft:blackstone
setblock 96 244 543 minecraft:smooth_basalt
fill 96 244 544 96 247 544 minecraft:blackstone
setblock 96 244 547 minecraft:blackstone
setblock 96 244 548 minecraft:smooth_basalt
fill 96 244 549 96 247 549 minecraft:blackstone
setblock 97 244 547 minecraft:smooth_basalt
fill 97 244 548 97 246 548 minecraft:blackstone
setblock 98 244 551 minecraft:smooth_basalt
setblock 99 244 550 minecraft:smooth_basalt
fill 99 244 551 102 244 551 minecraft:blackstone
fill 100 244 550 103 244 550 minecraft:blackstone
fill 103 244 549 104 244 549 minecraft:blackstone
setblock 103 244 551 minecraft:smooth_basalt
setblock 104 244 550 minecraft:smooth_basalt
fill 104 244 551 104 247 551 minecraft:blackstone
setblock 105 244 549 minecraft:smooth_basalt
fill 105 244 550 105 247 550 minecraft:blackstone
setblock 106 244 548 minecraft:smooth_basalt
fill 106 244 549 109 244 549 minecraft:blackstone
setblock 107 244 511 minecraft:blackstone
fill 107 244 548 107 246 548 minecraft:blackstone
setblock 108 244 511 minecraft:smooth_basalt
setblock 108 244 551 minecraft:smooth_basalt
fill 109 244 511 109 247 511 minecraft:blackstone
setblock 109 244 550 minecraft:smooth_basalt
fill 109 244 551 109 247 551 minecraft:blackstone
setblock 110 244 549 minecraft:smooth_basalt
fill 110 244 550 110 247 550 minecraft:blackstone
fill 111 244 549 111 246 549 minecraft:blackstone
setblock 112 244 511 minecraft:blackstone
setblock 113 244 551 minecraft:smooth_basalt
setblock 114 244 550 minecraft:smooth_basalt
fill 114 244 551 114 247 551 minecraft:blackstone
fill 124 244 511 124 247 511 minecraft:blackstone
fill 124 244 551 127 244 551 minecraft:blackstone
setblock 126 244 512 minecraft:blackstone
fill 126 244 550 128 244 550 minecraft:blackstone
setblock 127 244 512 minecraft:smooth_basalt
setblock 128 244 511 minecraft:smooth_basalt
fill 128 244 512 128 247 512 minecraft:blackstone
fill 128 244 549 129 244 549 minecraft:blackstone
setblock 128 244 551 minecraft:smooth_basalt
fill 129 244 511 129 247 511 minecraft:blackstone
fill 129 244 513 129 245 513 minecraft:blackstone
setblock 129 244 550 minecraft:smooth_basalt
fill 129 244 551 129 247 551 minecraft:blackstone
setblock 130 244 549 minecraft:smooth_basalt
fill 130 244 550 130 247 550 minecraft:blackstone
setblock 131 244 513 minecraft:smooth_basalt
fill 131 244 549 131 247 549 minecraft:blackstone
setblock 132 244 512 minecraft:smooth_basalt
setblock 132 244 513 minecraft:blackstone
setblock 132 244 522 minecraft:smooth_basalt
setblock 132 244 523 minecraft:blackstone
setblock 133 244 511 minecraft:smooth_basalt
fill 133 244 512 133 247 512 minecraft:blackstone
setblock 133 244 517 minecraft:blackstone
setblock 133 244 521 minecraft:smooth_basalt
fill 133 244 522 133 245 522 minecraft:blackstone
setblock 133 244 526 minecraft:smooth_basalt
fill 133 244 527 133 245 527 minecraft:blackstone
setblock 133 244 545 minecraft:blackstone
setblock 133 244 546 minecraft:smooth_basalt
fill 133 244 547 133 246 547 minecraft:blackstone
setblock 133 244 550 minecraft:blackstone
setblock 133 244 551 minecraft:smooth_basalt
fill 134 244 511 134 247 511 minecraft:blackstone
setblock 134 244 515 minecraft:smooth_basalt
fill 134 244 516 134 245 516 minecraft:blackstone
setblock 134 244 520 minecraft:smooth_basalt
fill 134 244 521 134 246 521 minecraft:blackstone
setblock 134 244 525 minecraft:smooth_basalt
fill 134 244 526 134 246 526 minecraft:blackstone
setblock 134 244 529 minecraft:blackstone
setblock 134 244 545 minecraft:smooth_basalt
fill 134 244 546 134 247 546 minecraft:blackstone
setblock 134 244 550 minecraft:smooth_basalt
fill 134 244 551 134 247 551 minecraft:blackstone
setblock 135 244 514 minecraft:smooth_basalt
fill 135 244 515 135 246 515 minecraft:blackstone
setblock 135 244 519 minecraft:smooth_basalt
fill 135 244 520 135 246 520 minecraft:blackstone
setblock 135 244 524 minecraft:smooth_basalt
fill 135 244 525 135 247 525 minecraft:blackstone
setblock 135 244 529 minecraft:smooth_basalt
fill 135 244 530 135 245 530 minecraft:blackstone
setblock 135 244 540 minecraft:blackstone
setblock 135 244 544 minecraft:smooth_basalt
fill 135 244 545 135 247 545 minecraft:blackstone
setblock 135 244 549 minecraft:smooth_basalt
fill 135 244 550 135 247 550 minecraft:blackstone
setblock 95 245 523 minecraft:smooth_basalt
fill 95 245 524 95 246 524 minecraft:blackstone
setblock 95 245 527 minecraft:blackstone
setblock 95 245 528 minecraft:smooth_basalt
fill 95 245 529 95 247 529 minecraft:blackstone
setblock 95 245 539 minecraft:blackstone
setblock 95 245 543 minecraft:smooth_basalt
fill 95 245 544 95 248 544 minecraft:blackstone
setblock 95 245 548 minecraft:smooth_basalt
fill 95 245 549 95 248 549 minecraft:blackstone
setblock 96 245 542 minecraft:smooth_basalt
fill 96 245 543 96 246 543 minecraft:blackstone
setblock 96 245 547 minecraft:smooth_basalt
fill 96 245 548 96 248 548 minecraft:blackstone
setblock 97 245 513 minecraft:light[level=12]
setblock 97 245 521 minecraft:light[level=12]
setblock 97 245 529 minecraft:light[level=12]
setblock 97 245 537 minecraft:light[level=12]
setblock 97 245 546 minecraft:smooth_basalt
fill 97 245 547 97 246 547 minecraft:blackstone
setblock 97 245 551 minecraft:smooth_basalt
setblock 98 245 550 minecraft:smooth_basalt
fill 98 245 551 101 245 551 minecraft:blackstone
fill 99 245 550 102 245 550 minecraft:blackstone
fill 102 245 549 103 245 549 minecraft:blackstone
setblock 102 245 551 minecraft:smooth_basalt
setblock 103 245 550 minecraft:smooth_basalt
fill 103 245 551 103 248 551 minecraft:blackstone
setblock 104 245 549 minecraft:smooth_basalt
fill 104 245 550 104 248 550 minecraft:blackstone
setblock 105 245 513 minecraft:light[level=12]
setblock 105 245 521 minecraft:light[level=12]
setblock 105 245 529 minecraft:light[level=12]
setblock 105 245 537 minecraft:light[level=12]
setblock 105 245 545 minecraft:light[level=12]
setblock 105 245 548 minecraft:smooth_basalt
fill 105 245 549 108 245 549 minecraft:blackstone
setblock 106 245 511 minecraft:blackstone
fill 106 245 548 106 246 548 minecraft:blackstone
setblock 107 245 511 minecraft:smooth_basalt
setblock 107 245 551 minecraft:smooth_basalt
fill 108 245 511 108 248 511 minecraft:blackstone
fill 108 245 548 109 245 548 minecraft:blackstone
setblock 108 245 550 minecraft:smooth_basalt
fill 108 245 551 108 248 551 minecraft:blackstone
setblock 109 245 549 minecraft:smooth_basalt
fill 109 245 550 109 248 550 minecraft:blackstone
setblock 110 245 548 minecraft:smooth_basalt
fill 110 245 549 110 247 549 minecraft:blackstone
setblock 112 245 511 minecraft:smooth_basalt
setblock 112 245 551 minecraft:smooth_basalt
setblock 113 245 513 minecraft:light[level=12]
setblock 113 245 521 minecraft:light[level=12]
setblock 113 245 529 minecraft:light[level=12]
setblock 113 245 537 minecraft:light[level=12]
setblock 113 245 545 minecraft:light[level=12]
setblock 113 245 550 minecraft:smooth_basalt
fill 113 245 551 113 248 551 minecraft:blackstone
setblock 121 245 513 minecraft:light[level=12]
setblock 121 245 529 minecraft:light[level=12]
setblock 121 245 537 minecraft:light[level=12]
setblock 121 245 545 minecraft:light[level=12]
fill 123 245 511 123 248 511 minecraft:blackstone
fill 123 245 551 126 245 551 minecraft:blackstone
setblock 125 245 512 minecraft:blackstone
fill 125 245 550 127 245 550 minecraft:blackstone
setblock 126 245 512 minecraft:smooth_basalt
setblock 127 245 511 minecraft:smooth_basalt
fill 127 245 512 127 248 512 minecraft:blackstone
fill 127 245 549 128 245 549 minecraft:blackstone
setblock 127 245 551 minecraft:smooth_basalt
fill 128 245 511 128 248 511 minecraft:blackstone
fill 128 245 513 128 246 513 minecraft:blackstone
setblock 128 245 550 minecraft:smooth_basalt
fill 128 245 551 128 248 551 minecraft:blackstone
setblock 129 245 521 minecraft:light[level=12]
setblock 129 245 529 minecraft:light[level=12]
setblock 129 245 537 minecraft:light[level=12]
setblock 129 245 545 minecraft:light[level=12]
setblock 129 245 549 minecraft:smooth_basalt
fill 129 245 550 129 248 550 minecraft:blackstone
setblock 130 245 513 minecraft:smooth_basalt
fill 130 245 549 130 248 549 minecraft:blackstone
setblock 131 245 512 minecraft:smooth_basalt
setblock 131 245 513 minecraft:blackstone
setblock 132 245 511 minecraft:smooth_basalt
fill 132 245 512 132 248 512 minecraft:blackstone
setblock 132 245 551 minecraft:smooth_basalt
fill 133 245 511 133 248 511 minecraft:blackstone
setblock 133 245 520 minecraft:smooth_basalt
setblock 133 245 521 minecraft:blackstone
setblock 133 245 525 minecraft:smooth_basalt
setblock 133 245 526 minecraft:blackstone
setblock 133 245 545 minecraft:smooth_basalt
fill 133 245 546 133 246 546 minecraft:blackstone
setblock 133 245 550 minecraft:smooth_basalt
fill 133 245 551 133 248 551 minecraft:blackstone
setblock 134 245 514 minecraft:smooth_basalt
setblock 134 245 515 minecraft:blackstone
setblock 134 245 519 minecraft:smooth_basalt
setblock 134 245 520 minecraft:blackstone
setblock 134 245 524 minecraft:smooth_basalt
fill 134 245 525 134 246 525 minecraft:blackstone
setblock 134 245 544 minecraft:smooth_basalt
fill 134 245 545 134 247 545 minecraft:blackstone
setblock 134 245 549 minecraft:smooth_basalt
fill 134 245 550 134 248 550 minecraft:blackstone
setblock 135 245 513 minecraft:smooth_basalt
fill 135 245 514 135 247 514 minecraft:blackstone
setblock 135 245 518 minecraft:smooth_basalt
fill 135 245 519 135 246 519 minecraft:blackstone
setblock 135 245 523 minecraft:smooth_basalt
fill 135 245 524 135 247 524 minecraft:blackstone
setblock 135 245 528 minecraft:smooth_basalt
fill 135 245 529 135 247 529 minecraft:blackstone
setblock 135 245 543 minecraft:smooth_basalt
fill 135 245 544 135 247 544 minecraft:blackstone
setblock 135 245 548 minecraft:smooth_basalt
fill 135 245 549 135 248 549 minecraft:blackstone
setblock 95 246 511 minecraft:blackstone
setblock 95 246 523 minecraft:blackstone
setblock 95 246 527 minecraft:smooth_basalt
fill 95 246 528 95 247 528 minecraft:blackstone
setblock 95 246 542 minecraft:smooth_basalt
fill 95 246 543 95 248 543 minecraft:blackstone
setblock 95 246 547 minecraft:smooth_basalt
fill 95 246 548 95 249 548 minecraft:blackstone
setblock 96 246 546 minecraft:smooth_basalt
fill 96 246 547 96 249 547 minecraft:blackstone
setblock 96 246 551 minecraft:smooth_basalt
setblock 97 246 546 minecraft:blackstone
setblock 97 246 550 minecraft:smooth_basalt
fill 97 246 551 100 246 551 minecraft:blackstone
fill 98 246 550 101 246 550 minecraft:blackstone
fill 101 246 549 102 246 549 minecraft:blackstone
setblock 101 246 551 minecraft:smooth_basalt
setblock 102 246 550 minecraft:smooth_basalt
fill 102 246 551 102 249 551 minecraft:blackstone
setblock 103 246 549 minecraft:smooth_basalt
fill 103 246 550 103 249 550 minecraft:blackstone
fill 104 246 549 107 246 549 minecraft:blackstone
setblock 105 246 511 minecraft:blackstone
setblock 105 246 548 minecraft:blackstone
setblock 106 246 511 minecraft:smooth_basalt
setblock 106 246 551 minecraft:smooth_basalt
fill 107 246 511 107 249 511 minecraft:blackstone
setblock 107 246 550 minecraft:smooth_basalt
fill 107 246 551 107 249 551 minecraft:blackstone
setblock 108 246 548 minecraft:blackstone
setblock 108 246 549 minecraft:smooth_basalt
fill 108 246 550 108 249 550 minecraft:blackstone
fill 109 246 549 109 248 549 minecraft:blackstone
setblock 110 246 511 minecraft:blackstone
setblock 111 246 511 minecraft:smooth_basalt
setblock 111 246 551 minecraft:smooth_basalt
setblock 112 246 511 minecraft:blackstone
setblock 112 246 550 minecraft:smooth_basalt
fill 112 246 551 112 249 551 minecraft:blackstone
setblock 113 246 550 minecraft:blackstone
fill 122 246 511 122 249 511 minecraft:blackstone
fill 122 246 551 125 246 551 minecraft:blackstone
fill 124 246 550 126 246 550 minecraft:blackstone
setblock 125 246 512 minecraft:smooth_basalt
setblock 126 246 511 minecraft:smooth_basalt
fill 126 246 512 126 249 512 minecraft:blackstone
fill 126 246 549 127 246 549 minecraft:blackstone
setblock 126 246 551 minecraft:smooth_basalt
fill 127 246 511 127 249 511 minecraft:blackstone
setblock 127 246 550 minecraft:smooth_basalt
fill 127 246 551 127 249 551 minecraft:blackstone
setblock 128 246 549 minecraft:smooth_basalt
fill 128 246 550 128 249 550 minecraft:blackstone
setblock 129 246 513 minecraft:smooth_basalt
fill 129 246 549 129 249 549 minecraft:blackstone
setblock 130 246 512 minecraft:smooth_basalt
fill 130 246 513 130 247 513 minecraft:blackstone
setblock 131 246 511 minecraft:smooth_basalt
fill 131 246 512 131 249 512 minecraft:blackstone
setblock 131 246 551 minecraft:smooth_basalt
fill 132 246 511 132 249 511 minecraft:blackstone
setblock 132 246 550 minecraft:smooth_basalt
fill 132 246 551 132 249 551 minecraft:blackstone
setblock 133 246 549 minecraft:smooth_basalt
fill 133 246 550 133 249 550 minecraft:blackstone
setblock 134 246 513 minecraft:smooth_basalt
setblock 134 246 523 minecraft:smooth_basalt
setblock 134 246 524 minecraft:blackstone
setblock 134 246 528 minecraft:smooth_basalt
setblock 134 246 544 minecraft:blackstone
setblock 134 246 548 minecraft:smooth_basalt
fill 134 246 549 134 249 549 minecraft:blackstone
setblock 135 246 512 minecraft:smooth_basalt
fill 135 246 513 135 248 513 minecraft:blackstone
setblock 135 246 517 minecraft:smooth_basalt
setblock 135 246 518 minecraft:blackstone
setblock 135 246 522 minecraft:smooth_basalt
fill 135 246 523 135 247 523 minecraft:blackstone
setblock 135 246 527 minecraft:smooth_basalt
fill 135 246 528 135 247 528 minecraft:blackstone
setblock 135 246 542 minecraft:smooth_basalt
setblock 135 246 543 minecraft:blackstone
setblock 135 246 547 minecraft:smooth_basalt
fill 135 246 548 135 249 548 minecraft:blackstone
setblock 95 247 511 minecraft:smooth_basalt
setblock 95 247 526 minecraft:smooth_basalt
setblock 95 247 527 minecraft:blackstone
setblock 95 247 541 minecraft:smooth_basalt
setblock 95 247 542 minecraft:blackstone
setblock 95 247 546 minecraft:smooth_basalt
fill 95 247 547 95 250 547 minecraft:blackstone
setblock 95 247 551 minecraft:smooth_basalt
setblock 96 247 545 minecraft:smooth_basalt
fill 96 247 546 96 248 546 minecraft:blackstone
setblock 96 247 550 minecraft:smooth_basalt
fill 96 247 551 99 247 551 minecraft:blackstone
fill 97 247 550 100 247 550 minecraft:blackstone
setblock 100 247 551 minecraft:smooth_basalt
setblock 101 247 550 minecraft:smooth_basalt
fill 101 247 551 101 250 551 minecraft:blackstone
setblock 102 247 549 minecraft:smooth_basalt
fill 102 247 550 102 250 550 minecraft:blackstone
fill 103 247 549 106 247 549 minecraft:blackstone
setblock 104 247 511 minecraft:blackstone
setblock 105 247 511 minecraft:smooth_basalt
setblock 105 247 551 minecraft:smooth_basalt
fill 106 247 511 106 250 511 minecraft:blackstone
setblock 106 247 550 minecraft:smooth_basalt
fill 106 247 551 106 250 551 minecraft:blackstone
setblock 107 247 549 minecraft:smooth_basalt
fill 107 247 550 107 250 550 minecraft:blackstone
fill 108 247 549 108 248 549 minecraft:blackstone
setblock 110 247 511 minecraft:smooth_basalt
setblock 110 247 551 minecraft:smooth_basalt
fill 111 247 511 111 248 511 minecraft:blackstone
setblock 111 247 550 minecraft:smooth_basalt
fill 111 247 551 111 250 551 minecraft:blackstone
setblock 112 247 550 minecraft:blackstone
fill 121 247 511 121 250 511 minecraft:blackstone
fill 122 247 551 124 247 551 minecraft:blackstone
setblock 124 247 512 minecraft:smooth_basalt
fill 124 247 550 125 247 550 minecraft:blackstone
setblock 125 247 511 minecraft:smooth_basalt
fill 125 247 512 125 250 512 minecraft:blackstone
setblock 125 247 551 minecraft:smooth_basalt
fill 126 247 511 126 250 511 minecraft:blackstone
setblock 126 247 549 minecraft:blackstone
setblock 126 247 550 minecraft:smooth_basalt
fill 126 247 551 126 250 551 minecraft:blackstone
setblock 127 247 513 minecraft:blackstone
setblock 127 247 549 minecraft:smooth_basalt
fill 127 247 550 127 250 550 minecraft:blackstone
setblock 128 247 513 minecraft:smooth_basalt
fill 128 247 549 128 250 549 minecraft:blackstone
setblock 129 247 512 minecraft:smooth_basalt
fill 129 247 513 129 248 513 minecraft:blackstone
setblock 130 247 511 minecraft:smooth_basalt
fill 130 247 512 130 250 512 minecraft:blackstone
setblock 130 247 551 minecraft:smooth_basalt
fill 131 247 511 131 250 511 minecraft:blackstone
schedule function dropper:buildpart/122_10 1t
