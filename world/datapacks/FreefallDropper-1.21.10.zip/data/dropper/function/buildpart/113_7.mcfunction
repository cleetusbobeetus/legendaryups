setblock 248 180 504 minecraft:bone_block
fill 249 180 464 249 183 464 minecraft:brown_terracotta
setblock 249 180 503 minecraft:bone_block
fill 249 180 504 249 183 504 minecraft:brown_terracotta
setblock 250 180 501 minecraft:brown_terracotta
setblock 250 180 502 minecraft:bone_block
fill 250 180 503 250 183 503 minecraft:brown_terracotta
setblock 251 180 465 minecraft:brown_terracotta
setblock 251 180 466 minecraft:bone_block
setblock 251 180 501 minecraft:bone_block
fill 251 180 502 251 183 502 minecraft:brown_terracotta
setblock 252 180 465 minecraft:bone_block
fill 252 180 466 253 182 466 minecraft:brown_terracotta
fill 252 180 501 252 183 501 minecraft:brown_terracotta
setblock 253 180 464 minecraft:bone_block
fill 253 180 465 253 183 465 minecraft:brown_terracotta
setblock 253 180 504 minecraft:bone_block
fill 254 180 464 254 183 464 minecraft:brown_terracotta
setblock 254 180 500 minecraft:brown_terracotta
setblock 254 180 503 minecraft:bone_block
fill 254 180 504 254 183 504 minecraft:brown_terracotta
setblock 255 180 502 minecraft:bone_block
fill 255 180 503 255 183 503 minecraft:brown_terracotta
setblock 256 180 465 minecraft:brown_terracotta
setblock 256 180 501 minecraft:bone_block
fill 256 180 502 256 183 502 minecraft:brown_terracotta
setblock 257 180 465 minecraft:bone_block
fill 257 180 501 257 182 501 minecraft:brown_terracotta
setblock 258 180 464 minecraft:bone_block
setblock 258 180 504 minecraft:bone_block
fill 259 180 464 259 183 464 minecraft:brown_terracotta
setblock 259 180 503 minecraft:bone_block
fill 259 180 504 259 183 504 minecraft:brown_terracotta
setblock 260 180 502 minecraft:bone_block
fill 260 180 503 260 183 503 minecraft:brown_terracotta
fill 261 180 502 261 181 502 minecraft:brown_terracotta
setblock 263 180 504 minecraft:bone_block
setblock 264 180 503 minecraft:bone_block
fill 264 180 504 267 180 504 minecraft:brown_terracotta
fill 265 180 503 268 180 503 minecraft:brown_terracotta
fill 267 180 502 269 180 502 minecraft:brown_terracotta
setblock 268 180 504 minecraft:bone_block
fill 269 180 464 272 180 464 minecraft:brown_terracotta
setblock 269 180 503 minecraft:bone_block
fill 269 180 504 269 183 504 minecraft:brown_terracotta
setblock 270 180 502 minecraft:bone_block
fill 270 180 503 270 183 503 minecraft:brown_terracotta
fill 271 180 502 271 183 502 minecraft:brown_terracotta
setblock 272 180 501 minecraft:brown_terracotta
setblock 273 180 464 minecraft:bone_block
fill 273 180 477 273 180 478 minecraft:brown_terracotta
setblock 273 180 479 minecraft:bone_block
fill 273 180 480 273 183 480 minecraft:brown_terracotta
setblock 273 180 483 minecraft:brown_terracotta
setblock 273 180 484 minecraft:bone_block
fill 273 180 485 273 182 486 minecraft:brown_terracotta
setblock 273 180 499 minecraft:bone_block
setblock 273 180 500 minecraft:brown_terracotta
setblock 273 180 504 minecraft:bone_block
fill 274 180 464 274 183 464 minecraft:brown_terracotta
fill 274 180 474 274 181 474 minecraft:brown_terracotta
setblock 274 180 478 minecraft:bone_block
fill 274 180 479 274 183 479 minecraft:brown_terracotta
setblock 274 180 483 minecraft:bone_block
fill 274 180 484 274 183 484 minecraft:brown_terracotta
fill 274 180 486 274 180 487 minecraft:brown_terracotta
setblock 274 180 488 minecraft:bone_block
fill 274 180 489 274 181 490 minecraft:brown_terracotta
setblock 274 180 493 minecraft:bone_block
setblock 274 180 494 minecraft:brown_terracotta
setblock 274 180 498 minecraft:bone_block
fill 274 180 499 274 182 499 minecraft:brown_terracotta
setblock 274 180 503 minecraft:bone_block
fill 274 180 504 274 183 504 minecraft:brown_terracotta
setblock 275 180 472 minecraft:bone_block
fill 275 180 473 275 182 473 minecraft:brown_terracotta
setblock 275 180 477 minecraft:bone_block
fill 275 180 478 275 183 478 minecraft:brown_terracotta
setblock 275 180 482 minecraft:bone_block
fill 275 180 483 275 183 483 minecraft:brown_terracotta
setblock 275 180 487 minecraft:bone_block
fill 275 180 488 275 183 488 minecraft:brown_terracotta
setblock 275 180 492 minecraft:bone_block
fill 275 180 493 275 182 493 minecraft:brown_terracotta
setblock 275 180 497 minecraft:bone_block
fill 275 180 498 275 182 498 minecraft:brown_terracotta
setblock 275 180 502 minecraft:bone_block
fill 275 180 503 275 183 503 minecraft:brown_terracotta
setblock 276 180 465 minecraft:brown_terracotta
setblock 276 180 466 minecraft:bone_block
fill 276 180 467 276 183 467 minecraft:brown_terracotta
setblock 276 180 471 minecraft:bone_block
fill 276 180 472 276 183 472 minecraft:brown_terracotta
setblock 276 180 476 minecraft:bone_block
fill 276 180 477 276 183 477 minecraft:brown_terracotta
setblock 276 180 481 minecraft:bone_block
fill 276 180 482 276 183 482 minecraft:brown_terracotta
setblock 276 180 486 minecraft:bone_block
fill 276 180 487 276 183 487 minecraft:brown_terracotta
setblock 276 180 491 minecraft:bone_block
fill 276 180 492 276 183 492 minecraft:brown_terracotta
setblock 276 180 496 minecraft:bone_block
fill 276 180 497 276 183 497 minecraft:brown_terracotta
setblock 276 180 501 minecraft:bone_block
fill 276 180 502 276 183 502 minecraft:brown_terracotta
setblock 236 181 464 minecraft:brown_terracotta
setblock 236 181 465 minecraft:bone_block
fill 236 181 466 236 184 466 minecraft:brown_terracotta
setblock 236 181 470 minecraft:bone_block
fill 236 181 471 236 184 471 minecraft:brown_terracotta
setblock 236 181 475 minecraft:bone_block
fill 236 181 476 236 184 476 minecraft:brown_terracotta
setblock 236 181 480 minecraft:bone_block
fill 236 181 481 236 184 481 minecraft:brown_terracotta
setblock 236 181 485 minecraft:bone_block
fill 236 181 486 236 184 486 minecraft:brown_terracotta
setblock 236 181 490 minecraft:bone_block
setblock 236 181 495 minecraft:bone_block
setblock 236 181 496 minecraft:brown_terracotta
setblock 236 181 500 minecraft:bone_block
fill 236 181 501 236 184 501 minecraft:brown_terracotta
setblock 237 181 464 minecraft:bone_block
fill 237 181 465 237 184 465 minecraft:brown_terracotta
setblock 237 181 469 minecraft:bone_block
setblock 237 181 470 minecraft:brown_terracotta
setblock 237 181 474 minecraft:bone_block
fill 237 181 475 237 183 475 minecraft:brown_terracotta
setblock 237 181 479 minecraft:bone_block
fill 237 181 480 237 184 480 minecraft:brown_terracotta
setblock 237 181 484 minecraft:bone_block
fill 237 181 485 237 183 485 minecraft:brown_terracotta
setblock 237 181 500 minecraft:brown_terracotta
setblock 237 181 503 minecraft:brown_terracotta
setblock 237 181 504 minecraft:bone_block
fill 238 181 464 241 181 464 minecraft:brown_terracotta
setblock 238 181 478 minecraft:bone_block
fill 238 181 479 238 182 479 minecraft:brown_terracotta
setblock 238 181 503 minecraft:bone_block
fill 238 181 504 241 181 504 minecraft:brown_terracotta
setblock 239 181 503 minecraft:brown_terracotta
setblock 242 181 464 minecraft:bone_block
setblock 242 181 504 minecraft:bone_block
fill 243 181 464 246 181 464 minecraft:brown_terracotta
fill 243 181 504 246 181 504 minecraft:brown_terracotta
fill 244 181 503 247 181 503 minecraft:brown_terracotta
setblock 245 181 465 minecraft:brown_terracotta
setblock 246 181 465 minecraft:bone_block
setblock 247 181 464 minecraft:bone_block
fill 247 181 465 247 184 465 minecraft:brown_terracotta
fill 247 181 502 248 181 502 minecraft:brown_terracotta
setblock 247 181 504 minecraft:bone_block
fill 248 181 464 248 184 464 minecraft:brown_terracotta
setblock 248 181 503 minecraft:bone_block
fill 248 181 504 248 184 504 minecraft:brown_terracotta
setblock 249 181 501 minecraft:brown_terracotta
setblock 249 181 502 minecraft:bone_block
fill 249 181 503 249 184 503 minecraft:brown_terracotta
setblock 250 181 466 minecraft:bone_block
setblock 250 181 501 minecraft:bone_block
fill 250 181 502 250 184 502 minecraft:brown_terracotta
setblock 251 181 465 minecraft:bone_block
fill 251 181 466 251 184 466 minecraft:brown_terracotta
fill 251 181 501 251 184 501 minecraft:brown_terracotta
setblock 252 181 464 minecraft:bone_block
fill 252 181 465 252 184 465 minecraft:brown_terracotta
setblock 252 181 504 minecraft:bone_block
fill 253 181 464 253 184 464 minecraft:brown_terracotta
setblock 253 181 503 minecraft:bone_block
fill 253 181 504 253 184 504 minecraft:brown_terracotta
setblock 254 181 502 minecraft:bone_block
fill 254 181 503 254 184 503 minecraft:brown_terracotta
setblock 255 181 501 minecraft:bone_block
fill 255 181 502 255 184 502 minecraft:brown_terracotta
setblock 256 181 465 minecraft:bone_block
fill 256 181 501 256 182 501 minecraft:brown_terracotta
setblock 257 181 464 minecraft:bone_block
fill 257 181 465 257 182 465 minecraft:brown_terracotta
setblock 257 181 504 minecraft:bone_block
fill 258 181 464 258 184 464 minecraft:brown_terracotta
setblock 258 181 503 minecraft:bone_block
fill 258 181 504 258 184 504 minecraft:brown_terracotta
setblock 259 181 502 minecraft:bone_block
fill 259 181 503 259 184 503 minecraft:brown_terracotta
fill 260 181 502 260 182 502 minecraft:brown_terracotta
setblock 262 181 504 minecraft:bone_block
setblock 263 181 503 minecraft:bone_block
fill 263 181 504 266 181 504 minecraft:brown_terracotta
fill 264 181 503 267 181 503 minecraft:brown_terracotta
fill 266 181 502 268 181 502 minecraft:brown_terracotta
setblock 267 181 504 minecraft:bone_block
fill 268 181 464 271 181 464 minecraft:brown_terracotta
setblock 268 181 503 minecraft:bone_block
fill 268 181 504 268 184 504 minecraft:brown_terracotta
setblock 269 181 502 minecraft:bone_block
fill 269 181 503 269 184 503 minecraft:brown_terracotta
fill 270 181 502 270 184 502 minecraft:brown_terracotta
setblock 272 181 464 minecraft:bone_block
fill 272 181 481 272 182 482 minecraft:brown_terracotta
setblock 272 181 504 minecraft:bone_block
fill 273 181 464 273 184 464 minecraft:brown_terracotta
setblock 273 181 477 minecraft:brown_terracotta
setblock 273 181 478 minecraft:bone_block
fill 273 181 479 273 184 479 minecraft:brown_terracotta
setblock 273 181 482 minecraft:brown_terracotta
setblock 273 181 483 minecraft:bone_block
fill 273 181 484 273 184 484 minecraft:brown_terracotta
setblock 273 181 503 minecraft:bone_block
fill 273 181 504 273 184 504 minecraft:brown_terracotta
setblock 274 181 477 minecraft:bone_block
fill 274 181 478 274 184 478 minecraft:brown_terracotta
setblock 274 181 482 minecraft:bone_block
fill 274 181 483 274 184 483 minecraft:brown_terracotta
setblock 274 181 486 minecraft:brown_terracotta
setblock 274 181 487 minecraft:bone_block
fill 274 181 488 274 184 488 minecraft:brown_terracotta
setblock 274 181 497 minecraft:bone_block
setblock 274 181 498 minecraft:brown_terracotta
setblock 274 181 502 minecraft:bone_block
fill 274 181 503 274 184 503 minecraft:brown_terracotta
setblock 275 181 472 minecraft:brown_terracotta
setblock 275 181 476 minecraft:bone_block
fill 275 181 477 275 184 477 minecraft:brown_terracotta
setblock 275 181 481 minecraft:bone_block
fill 275 181 482 275 184 482 minecraft:brown_terracotta
setblock 275 181 486 minecraft:bone_block
fill 275 181 487 275 184 487 minecraft:brown_terracotta
setblock 275 181 491 minecraft:bone_block
fill 275 181 492 275 182 492 minecraft:brown_terracotta
setblock 275 181 496 minecraft:bone_block
fill 275 181 497 275 182 497 minecraft:brown_terracotta
setblock 275 181 501 minecraft:bone_block
fill 275 181 502 275 183 502 minecraft:brown_terracotta
setblock 276 181 465 minecraft:bone_block
fill 276 181 466 276 184 466 minecraft:brown_terracotta
setblock 276 181 470 minecraft:bone_block
fill 276 181 471 276 183 471 minecraft:brown_terracotta
setblock 276 181 475 minecraft:bone_block
fill 276 181 476 276 184 476 minecraft:brown_terracotta
setblock 276 181 480 minecraft:bone_block
fill 276 181 481 276 184 481 minecraft:brown_terracotta
setblock 276 181 485 minecraft:bone_block
fill 276 181 486 276 184 486 minecraft:brown_terracotta
setblock 276 181 490 minecraft:bone_block
fill 276 181 491 276 184 491 minecraft:brown_terracotta
setblock 276 181 495 minecraft:bone_block
fill 276 181 496 276 183 496 minecraft:brown_terracotta
setblock 276 181 500 minecraft:bone_block
fill 276 181 501 276 184 501 minecraft:brown_terracotta
setblock 236 182 464 minecraft:bone_block
fill 236 182 465 236 185 465 minecraft:brown_terracotta
setblock 236 182 469 minecraft:bone_block
fill 236 182 470 236 185 470 minecraft:brown_terracotta
setblock 236 182 474 minecraft:bone_block
fill 236 182 475 236 185 475 minecraft:brown_terracotta
setblock 236 182 479 minecraft:bone_block
fill 236 182 480 236 185 480 minecraft:brown_terracotta
setblock 236 182 484 minecraft:bone_block
fill 236 182 485 236 185 485 minecraft:brown_terracotta
setblock 236 182 489 minecraft:bone_block
setblock 236 182 499 minecraft:bone_block
fill 236 182 500 236 183 500 minecraft:brown_terracotta
setblock 236 182 504 minecraft:bone_block
fill 237 182 464 240 182 464 minecraft:brown_terracotta
setblock 237 182 468 minecraft:bone_block
setblock 237 182 473 minecraft:bone_block
setblock 237 182 474 minecraft:brown_terracotta
setblock 237 182 478 minecraft:bone_block
fill 237 182 479 237 184 479 minecraft:brown_terracotta
setblock 237 182 483 minecraft:bone_block
fill 237 182 484 237 184 484 minecraft:brown_terracotta
setblock 237 182 503 minecraft:bone_block
fill 237 182 504 240 182 504 minecraft:brown_terracotta
setblock 238 182 478 minecraft:brown_terracotta
setblock 238 182 482 minecraft:bone_block
setblock 238 182 503 minecraft:brown_terracotta
setblock 241 182 464 minecraft:bone_block
setblock 241 182 504 minecraft:bone_block
fill 242 182 464 245 182 464 minecraft:brown_terracotta
fill 242 182 504 245 182 504 minecraft:brown_terracotta
fill 243 182 465 244 182 465 minecraft:brown_terracotta
fill 243 182 503 246 182 503 minecraft:brown_terracotta
setblock 245 182 465 minecraft:bone_block
setblock 246 182 464 minecraft:bone_block
fill 246 182 465 246 185 465 minecraft:brown_terracotta
fill 246 182 502 247 182 502 minecraft:brown_terracotta
setblock 246 182 504 minecraft:bone_block
fill 247 182 464 247 185 464 minecraft:brown_terracotta
setblock 247 182 503 minecraft:bone_block
fill 247 182 504 247 185 504 minecraft:brown_terracotta
setblock 248 182 502 minecraft:bone_block
fill 248 182 503 248 185 503 minecraft:brown_terracotta
setblock 249 182 466 minecraft:bone_block
setblock 249 182 501 minecraft:bone_block
fill 249 182 502 249 185 502 minecraft:brown_terracotta
setblock 250 182 465 minecraft:bone_block
fill 250 182 466 250 185 466 minecraft:brown_terracotta
fill 250 182 501 250 184 501 minecraft:brown_terracotta
setblock 251 182 464 minecraft:bone_block
fill 251 182 465 251 185 465 minecraft:brown_terracotta
setblock 251 182 504 minecraft:bone_block
fill 252 182 464 252 185 464 minecraft:brown_terracotta
setblock 252 182 503 minecraft:bone_block
fill 252 182 504 252 185 504 minecraft:brown_terracotta
setblock 253 182 502 minecraft:bone_block
fill 253 182 503 253 185 503 minecraft:brown_terracotta
setblock 254 182 501 minecraft:bone_block
fill 254 182 502 254 185 502 minecraft:brown_terracotta
setblock 255 182 465 minecraft:bone_block
fill 255 182 501 255 183 501 minecraft:brown_terracotta
setblock 256 182 464 minecraft:bone_block
fill 256 182 465 256 183 465 minecraft:brown_terracotta
setblock 256 182 504 minecraft:bone_block
fill 257 182 464 257 185 464 minecraft:brown_terracotta
setblock 257 182 503 minecraft:bone_block
fill 257 182 504 257 185 504 minecraft:brown_terracotta
setblock 258 182 502 minecraft:bone_block
fill 258 182 503 258 185 503 minecraft:brown_terracotta
fill 259 182 502 259 183 502 minecraft:brown_terracotta
setblock 261 182 504 minecraft:bone_block
setblock 262 182 503 minecraft:bone_block
fill 262 182 504 265 182 504 minecraft:brown_terracotta
fill 263 182 503 266 182 503 minecraft:brown_terracotta
setblock 266 182 504 minecraft:bone_block
fill 267 182 464 270 182 464 minecraft:brown_terracotta
setblock 267 182 502 minecraft:brown_terracotta
setblock 267 182 503 minecraft:bone_block
fill 267 182 504 267 185 504 minecraft:brown_terracotta
setblock 268 182 502 minecraft:bone_block
fill 268 182 503 268 185 503 minecraft:brown_terracotta
fill 269 182 502 269 183 502 minecraft:brown_terracotta
setblock 271 182 464 minecraft:bone_block
setblock 271 182 504 minecraft:bone_block
fill 272 182 464 272 184 465 minecraft:brown_terracotta
setblock 272 182 483 minecraft:bone_block
setblock 272 182 503 minecraft:bone_block
fill 272 182 504 272 185 504 minecraft:brown_terracotta
fill 273 182 465 274 182 465 minecraft:brown_terracotta
setblock 273 182 477 minecraft:bone_block
fill 273 182 478 273 183 478 minecraft:brown_terracotta
setblock 273 182 482 minecraft:bone_block
fill 273 182 483 273 185 483 minecraft:brown_terracotta
setblock 273 182 487 minecraft:bone_block
setblock 273 182 502 minecraft:bone_block
fill 273 182 503 273 185 503 minecraft:brown_terracotta
setblock 274 182 476 minecraft:bone_block
fill 274 182 477 274 184 477 minecraft:brown_terracotta
setblock 274 182 481 minecraft:bone_block
fill 274 182 482 274 185 482 minecraft:brown_terracotta
setblock 274 182 486 minecraft:bone_block
fill 274 182 487 274 185 487 minecraft:brown_terracotta
fill 274 182 489 274 183 489 minecraft:brown_terracotta
setblock 274 182 501 minecraft:bone_block
setblock 274 182 502 minecraft:brown_terracotta
setblock 275 182 464 minecraft:brown_terracotta
setblock 275 182 475 minecraft:bone_block
fill 275 182 476 275 184 476 minecraft:brown_terracotta
setblock 275 182 480 minecraft:bone_block
fill 275 182 481 275 185 481 minecraft:brown_terracotta
setblock 275 182 485 minecraft:bone_block
fill 275 182 486 275 185 486 minecraft:brown_terracotta
setblock 275 182 490 minecraft:bone_block
setblock 275 182 491 minecraft:brown_terracotta
setblock 275 182 495 minecraft:bone_block
setblock 275 182 496 minecraft:brown_terracotta
setblock 275 182 500 minecraft:bone_block
fill 275 182 501 275 183 501 minecraft:brown_terracotta
setblock 276 182 464 minecraft:bone_block
fill 276 182 465 276 185 465 minecraft:brown_terracotta
setblock 276 182 469 minecraft:bone_block
fill 276 182 470 276 183 470 minecraft:brown_terracotta
setblock 276 182 474 minecraft:bone_block
fill 276 182 475 276 185 475 minecraft:brown_terracotta
setblock 276 182 479 minecraft:bone_block
fill 276 182 480 276 185 480 minecraft:brown_terracotta
setblock 276 182 484 minecraft:bone_block
fill 276 182 485 276 185 485 minecraft:brown_terracotta
setblock 276 182 489 minecraft:bone_block
fill 276 182 490 276 185 490 minecraft:brown_terracotta
setblock 276 182 494 minecraft:bone_block
fill 276 182 495 276 183 495 minecraft:brown_terracotta
setblock 276 182 499 minecraft:bone_block
fill 276 182 500 276 184 500 minecraft:brown_terracotta
setblock 276 182 504 minecraft:bone_block
fill 236 183 464 239 183 464 minecraft:brown_terracotta
setblock 236 183 468 minecraft:bone_block
fill 236 183 469 236 186 469 minecraft:brown_terracotta
setblock 236 183 473 minecraft:bone_block
fill 236 183 474 236 185 474 minecraft:brown_terracotta
setblock 236 183 478 minecraft:bone_block
fill 236 183 479 236 186 479 minecraft:brown_terracotta
setblock 236 183 483 minecraft:bone_block
fill 236 183 484 236 186 484 minecraft:brown_terracotta
setblock 236 183 488 minecraft:bone_block
setblock 236 183 499 minecraft:brown_terracotta
setblock 236 183 503 minecraft:bone_block
fill 236 183 504 239 183 504 minecraft:brown_terracotta
setblock 237 183 467 minecraft:bone_block
setblock 237 183 477 minecraft:bone_block
fill 237 183 478 237 184 478 minecraft:brown_terracotta
setblock 237 183 482 minecraft:bone_block
fill 237 183 483 237 184 483 minecraft:brown_terracotta
setblock 237 183 503 minecraft:brown_terracotta
setblock 238 183 465 minecraft:brown_terracotta
setblock 239 183 465 minecraft:bone_block
setblock 240 183 464 minecraft:bone_block
setblock 240 183 504 minecraft:bone_block
fill 241 183 464 244 183 464 minecraft:brown_terracotta
fill 241 183 504 244 183 504 minecraft:brown_terracotta
fill 242 183 465 243 183 465 minecraft:brown_terracotta
fill 243 183 503 245 183 503 minecraft:brown_terracotta
setblock 244 183 465 minecraft:bone_block
setblock 245 183 464 minecraft:bone_block
fill 245 183 465 245 186 465 minecraft:brown_terracotta
setblock 245 183 504 minecraft:bone_block
fill 246 183 464 246 186 464 minecraft:brown_terracotta
setblock 246 183 502 minecraft:brown_terracotta
setblock 246 183 503 minecraft:bone_block
fill 246 183 504 246 186 504 minecraft:brown_terracotta
setblock 247 183 502 minecraft:bone_block
fill 247 183 503 247 186 503 minecraft:brown_terracotta
setblock 248 183 466 minecraft:bone_block
fill 248 183 502 248 186 502 minecraft:brown_terracotta
setblock 249 183 465 minecraft:bone_block
fill 249 183 466 249 186 466 minecraft:brown_terracotta
setblock 249 183 501 minecraft:brown_terracotta
setblock 250 183 464 minecraft:bone_block
fill 250 183 465 250 186 465 minecraft:brown_terracotta
setblock 250 183 504 minecraft:bone_block
fill 251 183 464 251 186 464 minecraft:brown_terracotta
setblock 251 183 503 minecraft:bone_block
fill 251 183 504 251 186 504 minecraft:brown_terracotta
setblock 252 183 466 minecraft:brown_terracotta
setblock 252 183 502 minecraft:bone_block
fill 252 183 503 252 186 503 minecraft:brown_terracotta
setblock 253 183 466 minecraft:bone_block
setblock 253 183 501 minecraft:bone_block
fill 253 183 502 253 186 502 minecraft:brown_terracotta
setblock 254 183 465 minecraft:bone_block
setblock 254 183 501 minecraft:brown_terracotta
setblock 255 183 464 minecraft:bone_block
fill 255 183 465 255 185 465 minecraft:brown_terracotta
setblock 255 183 504 minecraft:bone_block
fill 256 183 464 256 186 464 minecraft:brown_terracotta
setblock 256 183 503 minecraft:bone_block
fill 256 183 504 256 186 504 minecraft:brown_terracotta
setblock 257 183 502 minecraft:bone_block
fill 257 183 503 257 186 503 minecraft:brown_terracotta
setblock 258 183 502 minecraft:brown_terracotta
setblock 260 183 464 minecraft:bone_block
setblock 260 183 504 minecraft:bone_block
setblock 261 183 503 minecraft:bone_block
fill 261 183 504 264 183 504 minecraft:brown_terracotta
fill 262 183 503 265 183 503 minecraft:brown_terracotta
setblock 265 183 504 minecraft:bone_block
fill 266 183 464 269 183 464 minecraft:brown_terracotta
setblock 266 183 503 minecraft:bone_block
fill 266 183 504 266 186 504 minecraft:brown_terracotta
fill 267 183 503 267 186 503 minecraft:brown_terracotta
setblock 268 183 502 minecraft:brown_terracotta
setblock 270 183 464 minecraft:bone_block
setblock 270 183 504 minecraft:bone_block
fill 271 183 464 271 185 465 minecraft:brown_terracotta
setblock 271 183 503 minecraft:bone_block
fill 271 183 504 271 186 504 minecraft:brown_terracotta
setblock 272 183 482 minecraft:bone_block
setblock 272 183 483 minecraft:brown_terracotta
setblock 272 183 502 minecraft:bone_block
fill 272 183 503 272 185 503 minecraft:brown_terracotta
setblock 273 183 465 minecraft:brown_terracotta
setblock 273 183 481 minecraft:bone_block
fill 273 183 482 273 185 482 minecraft:brown_terracotta
setblock 273 183 485 minecraft:brown_terracotta
setblock 273 183 486 minecraft:bone_block
setblock 273 183 487 minecraft:brown_terracotta
setblock 273 183 502 minecraft:brown_terracotta
setblock 274 183 465 minecraft:bone_block
setblock 274 183 476 minecraft:brown_terracotta
setblock 274 183 480 minecraft:bone_block
fill 274 183 481 274 186 481 minecraft:brown_terracotta
setblock 274 183 485 minecraft:bone_block
fill 274 183 486 274 186 486 minecraft:brown_terracotta
setblock 275 183 464 minecraft:bone_block
setblock 275 183 474 minecraft:bone_block
fill 275 183 475 275 184 475 minecraft:brown_terracotta
setblock 275 183 479 minecraft:bone_block
fill 275 183 480 275 186 480 minecraft:brown_terracotta
setblock 275 183 484 minecraft:bone_block
fill 275 183 485 275 186 485 minecraft:brown_terracotta
setblock 275 183 489 minecraft:bone_block
setblock 275 183 490 minecraft:brown_terracotta
setblock 275 183 499 minecraft:bone_block
setblock 275 183 500 minecraft:brown_terracotta
setblock 275 183 504 minecraft:bone_block
fill 276 183 464 276 186 464 minecraft:brown_terracotta
setblock 276 183 468 minecraft:bone_block
fill 276 183 469 276 184 469 minecraft:brown_terracotta
setblock 276 183 473 minecraft:bone_block
fill 276 183 474 276 185 474 minecraft:brown_terracotta
setblock 276 183 478 minecraft:bone_block
fill 276 183 479 276 186 479 minecraft:brown_terracotta
setblock 276 183 483 minecraft:bone_block
fill 276 183 484 276 186 484 minecraft:brown_terracotta
setblock 276 183 488 minecraft:bone_block
fill 276 183 489 276 186 489 minecraft:brown_terracotta
setblock 276 183 493 minecraft:bone_block
setblock 276 183 494 minecraft:brown_terracotta
setblock 276 183 498 minecraft:bone_block
setblock 276 183 499 minecraft:brown_terracotta
setblock 276 183 503 minecraft:bone_block
fill 276 183 504 276 185 504 minecraft:brown_terracotta
fill 236 184 464 238 184 464 minecraft:brown_terracotta
setblock 236 184 467 minecraft:bone_block
fill 236 184 468 236 187 468 minecraft:brown_terracotta
setblock 236 184 472 minecraft:bone_block
fill 236 184 473 236 185 473 minecraft:brown_terracotta
setblock 236 184 477 minecraft:bone_block
fill 236 184 478 236 186 478 minecraft:brown_terracotta
setblock 236 184 482 minecraft:bone_block
fill 236 184 483 236 187 483 minecraft:brown_terracotta
setblock 236 184 487 minecraft:bone_block
setblock 236 184 488 minecraft:brown_terracotta
setblock 236 184 502 minecraft:bone_block
fill 236 184 503 236 185 504 minecraft:brown_terracotta
setblock 237 184 466 minecraft:bone_block
setblock 237 184 481 minecraft:bone_block
setblock 237 184 482 minecraft:brown_terracotta
fill 237 184 504 238 184 504 minecraft:brown_terracotta
setblock 238 184 465 minecraft:bone_block
setblock 238 184 466 minecraft:light[level=12]
setblock 238 184 474 minecraft:light[level=12]
setblock 238 184 482 minecraft:light[level=12]
setblock 238 184 490 minecraft:light[level=12]
setblock 238 184 498 minecraft:light[level=12]
setblock 239 184 464 minecraft:bone_block
setblock 239 184 465 minecraft:brown_terracotta
setblock 239 184 504 minecraft:bone_block
fill 240 184 464 243 184 464 minecraft:brown_terracotta
fill 240 184 504 243 184 504 minecraft:brown_terracotta
setblock 242 184 465 minecraft:brown_terracotta
setblock 243 184 465 minecraft:bone_block
setblock 244 184 464 minecraft:bone_block
fill 244 184 465 244 187 465 minecraft:brown_terracotta
setblock 244 184 503 minecraft:brown_terracotta
setblock 244 184 504 minecraft:bone_block
fill 245 184 464 245 187 464 minecraft:brown_terracotta
setblock 245 184 503 minecraft:bone_block
fill 245 184 504 245 187 504 minecraft:brown_terracotta
setblock 246 184 466 minecraft:light[level=12]
setblock 246 184 474 minecraft:light[level=12]
setblock 246 184 482 minecraft:light[level=12]
setblock 246 184 490 minecraft:light[level=12]
setblock 246 184 498 minecraft:light[level=12]
fill 246 184 503 246 187 503 minecraft:brown_terracotta
fill 247 184 502 247 187 502 minecraft:brown_terracotta
setblock 248 184 465 minecraft:bone_block
fill 248 184 466 248 187 466 minecraft:brown_terracotta
setblock 249 184 464 minecraft:bone_block
fill 249 184 465 249 187 465 minecraft:brown_terracotta
setblock 249 184 504 minecraft:bone_block
fill 250 184 464 250 187 464 minecraft:brown_terracotta
setblock 250 184 503 minecraft:bone_block
fill 250 184 504 250 187 504 minecraft:brown_terracotta
setblock 251 184 502 minecraft:bone_block
fill 251 184 503 251 187 503 minecraft:brown_terracotta
setblock 252 184 466 minecraft:bone_block
setblock 252 184 501 minecraft:bone_block
fill 252 184 502 252 187 502 minecraft:brown_terracotta
setblock 253 184 465 minecraft:bone_block
setblock 253 184 501 minecraft:brown_terracotta
setblock 254 184 464 minecraft:bone_block
fill 254 184 465 254 187 465 minecraft:brown_terracotta
setblock 254 184 466 minecraft:light[level=12]
setblock 254 184 474 minecraft:light[level=12]
setblock 254 184 482 minecraft:light[level=12]
setblock 254 184 490 minecraft:light[level=12]
setblock 254 184 498 minecraft:light[level=12]
setblock 254 184 504 minecraft:bone_block
fill 255 184 464 255 187 464 minecraft:brown_terracotta
setblock 255 184 503 minecraft:bone_block
fill 255 184 504 255 187 504 minecraft:brown_terracotta
setblock 256 184 502 minecraft:bone_block
fill 256 184 503 256 187 503 minecraft:brown_terracotta
setblock 257 184 502 minecraft:brown_terracotta
setblock 259 184 464 minecraft:bone_block
setblock 259 184 504 minecraft:bone_block
setblock 260 184 503 minecraft:bone_block
fill 260 184 504 263 184 504 minecraft:brown_terracotta
fill 261 184 503 264 184 503 minecraft:brown_terracotta
setblock 262 184 466 minecraft:light[level=12]
setblock 262 184 474 minecraft:light[level=12]
setblock 262 184 482 minecraft:light[level=12]
setblock 262 184 490 minecraft:light[level=12]
setblock 262 184 498 minecraft:light[level=12]
setblock 264 184 504 minecraft:bone_block
setblock 265 184 503 minecraft:bone_block
fill 265 184 504 265 187 504 minecraft:brown_terracotta
fill 266 184 464 268 184 464 minecraft:brown_terracotta
fill 266 184 503 266 186 503 minecraft:brown_terracotta
setblock 269 184 464 minecraft:bone_block
setblock 269 184 504 minecraft:bone_block
fill 270 184 464 270 187 464 minecraft:brown_terracotta
setblock 270 184 466 minecraft:light[level=12]
setblock 270 184 474 minecraft:light[level=12]
setblock 270 184 482 minecraft:light[level=12]
setblock 270 184 490 minecraft:light[level=12]
setblock 270 184 498 minecraft:light[level=12]
setblock 270 184 503 minecraft:bone_block
fill 270 184 504 270 187 504 minecraft:brown_terracotta
setblock 271 184 502 minecraft:bone_block
fill 271 184 503 271 186 503 minecraft:brown_terracotta
setblock 273 184 465 minecraft:bone_block
setblock 273 184 480 minecraft:bone_block
fill 273 184 481 273 185 481 minecraft:brown_terracotta
setblock 273 184 485 minecraft:bone_block
fill 273 184 486 273 185 486 minecraft:brown_terracotta
setblock 274 184 464 minecraft:bone_block
setblock 274 184 465 minecraft:brown_terracotta
setblock 274 184 479 minecraft:bone_block
fill 274 184 480 274 186 480 minecraft:brown_terracotta
setblock 274 184 484 minecraft:bone_block
fill 274 184 485 274 187 485 minecraft:brown_terracotta
setblock 274 184 504 minecraft:bone_block
fill 275 184 464 275 187 464 minecraft:brown_terracotta
setblock 275 184 478 minecraft:bone_block
fill 275 184 479 275 186 479 minecraft:brown_terracotta
setblock 275 184 483 minecraft:bone_block
fill 275 184 484 275 187 484 minecraft:brown_terracotta
setblock 275 184 488 minecraft:bone_block
fill 275 184 489 275 185 489 minecraft:brown_terracotta
setblock 275 184 503 minecraft:bone_block
fill 275 184 504 275 186 504 minecraft:brown_terracotta
setblock 276 184 467 minecraft:bone_block
fill 276 184 468 276 185 468 minecraft:brown_terracotta
setblock 276 184 472 minecraft:bone_block
setblock 276 184 473 minecraft:brown_terracotta
setblock 276 184 477 minecraft:bone_block
fill 276 184 478 276 187 478 minecraft:brown_terracotta
setblock 276 184 482 minecraft:bone_block
fill 276 184 483 276 187 483 minecraft:brown_terracotta
setblock 276 184 487 minecraft:bone_block
fill 276 184 488 276 187 488 minecraft:brown_terracotta
setblock 276 184 502 minecraft:bone_block
fill 276 184 503 276 185 503 minecraft:brown_terracotta
fill 236 185 464 237 185 464 minecraft:brown_terracotta
setblock 236 185 466 minecraft:bone_block
fill 236 185 467 236 188 467 minecraft:brown_terracotta
setblock 236 185 471 minecraft:bone_block
setblock 236 185 472 minecraft:brown_terracotta
setblock 236 185 476 minecraft:bone_block
fill 236 185 477 236 186 477 minecraft:brown_terracotta
setblock 236 185 481 minecraft:bone_block
fill 236 185 482 236 187 482 minecraft:brown_terracotta
setblock 236 185 486 minecraft:bone_block
setblock 236 185 487 minecraft:brown_terracotta
setblock 236 185 502 minecraft:brown_terracotta
setblock 237 185 465 minecraft:bone_block
setblock 237 185 466 minecraft:brown_terracotta
setblock 237 185 504 minecraft:brown_terracotta
setblock 238 185 464 minecraft:bone_block
fill 238 185 465 238 186 465 minecraft:brown_terracotta
setblock 238 185 504 minecraft:bone_block
fill 239 185 464 242 185 464 minecraft:brown_terracotta
fill 239 185 504 242 185 504 minecraft:brown_terracotta
setblock 242 185 465 minecraft:bone_block
setblock 243 185 464 minecraft:bone_block
fill 243 185 465 243 188 465 minecraft:brown_terracotta
setblock 243 185 504 minecraft:bone_block
fill 244 185 464 244 188 464 minecraft:brown_terracotta
setblock 244 185 503 minecraft:bone_block
fill 244 185 504 244 188 504 minecraft:brown_terracotta
fill 245 185 503 245 188 503 minecraft:brown_terracotta
fill 246 185 494 247 186 495 minecraft:soul_soil
setblock 247 185 465 minecraft:bone_block
fill 247 185 466 247 188 466 minecraft:brown_terracotta
setblock 248 185 464 minecraft:bone_block
fill 248 185 465 248 188 465 minecraft:brown_terracotta
fill 248 185 495 248 186 495 minecraft:soul_soil
setblock 248 185 504 minecraft:bone_block
fill 249 185 464 249 188 464 minecraft:brown_terracotta
setblock 249 185 503 minecraft:bone_block
fill 249 185 504 249 188 504 minecraft:brown_terracotta
setblock 250 185 502 minecraft:bone_block
fill 250 185 503 250 188 503 minecraft:brown_terracotta
setblock 251 185 466 minecraft:bone_block
fill 251 185 502 251 188 502 minecraft:brown_terracotta
setblock 252 185 465 minecraft:bone_block
setblock 253 185 464 minecraft:bone_block
fill 253 185 465 253 188 465 minecraft:brown_terracotta
setblock 253 185 504 minecraft:bone_block
fill 254 185 464 254 188 464 minecraft:brown_terracotta
setblock 254 185 503 minecraft:bone_block
fill 254 185 504 254 188 504 minecraft:brown_terracotta
setblock 255 185 502 minecraft:bone_block
fill 255 185 503 255 188 503 minecraft:brown_terracotta
setblock 256 185 502 minecraft:brown_terracotta
setblock 258 185 464 minecraft:bone_block
setblock 258 185 504 minecraft:bone_block
setblock 259 185 503 minecraft:bone_block
fill 259 185 504 262 185 504 minecraft:brown_terracotta
setblock 263 185 504 minecraft:bone_block
fill 264 185 504 264 188 504 minecraft:brown_terracotta
setblock 265 185 503 minecraft:brown_terracotta
fill 266 185 464 267 185 464 minecraft:brown_terracotta
setblock 268 185 464 minecraft:bone_block
setblock 268 185 504 minecraft:bone_block
fill 269 185 464 269 188 464 minecraft:brown_terracotta
setblock 269 185 503 minecraft:bone_block
fill 269 185 504 269 188 504 minecraft:brown_terracotta
fill 270 185 465 270 186 465 minecraft:brown_terracotta
fill 270 185 503 270 186 503 minecraft:brown_terracotta
setblock 272 185 464 minecraft:brown_terracotta
setblock 272 185 465 minecraft:bone_block
setblock 273 185 464 minecraft:bone_block
fill 273 185 465 273 186 465 minecraft:brown_terracotta
setblock 273 185 484 minecraft:bone_block
setblock 273 185 485 minecraft:brown_terracotta
setblock 273 185 504 minecraft:bone_block
fill 274 185 464 274 188 464 minecraft:brown_terracotta
setblock 274 185 479 minecraft:brown_terracotta
setblock 274 185 483 minecraft:bone_block
fill 274 185 484 274 188 484 minecraft:brown_terracotta
fill 274 185 504 274 187 504 minecraft:brown_terracotta
setblock 275 185 477 minecraft:bone_block
fill 275 185 478 275 186 478 minecraft:brown_terracotta
setblock 275 185 482 minecraft:bone_block
fill 275 185 483 275 188 483 minecraft:brown_terracotta
setblock 275 185 487 minecraft:bone_block
fill 275 185 488 275 188 488 minecraft:brown_terracotta
setblock 276 185 466 minecraft:bone_block
fill 276 185 467 276 188 467 minecraft:brown_terracotta
setblock 276 185 476 minecraft:bone_block
fill 276 185 477 276 187 477 minecraft:brown_terracotta
setblock 276 185 481 minecraft:bone_block
fill 276 185 482 276 188 482 minecraft:brown_terracotta
setblock 276 185 486 minecraft:bone_block
fill 276 185 487 276 188 487 minecraft:brown_terracotta
setblock 236 186 464 minecraft:brown_terracotta
setblock 236 186 465 minecraft:bone_block
fill 236 186 466 236 189 466 minecraft:brown_terracotta
setblock 236 186 470 minecraft:bone_block
setblock 236 186 480 minecraft:bone_block
fill 236 186 481 236 187 481 minecraft:brown_terracotta
setblock 236 186 485 minecraft:bone_block
fill 236 186 486 236 187 486 minecraft:brown_terracotta
setblock 236 186 504 minecraft:brown_terracotta
setblock 237 186 464 minecraft:bone_block
fill 237 186 465 237 189 465 minecraft:brown_terracotta
setblock 237 186 504 minecraft:bone_block
fill 238 186 464 241 186 464 minecraft:brown_terracotta
fill 238 186 504 241 186 504 minecraft:brown_terracotta
setblock 241 186 465 minecraft:bone_block
setblock 242 186 464 minecraft:bone_block
fill 242 186 465 242 189 465 minecraft:brown_terracotta
setblock 242 186 504 minecraft:bone_block
fill 243 186 464 243 189 464 minecraft:brown_terracotta
fill 243 186 504 243 189 504 minecraft:brown_terracotta
fill 244 186 503 244 189 503 minecraft:brown_terracotta
setblock 246 186 465 minecraft:bone_block
setblock 247 186 464 minecraft:bone_block
fill 247 186 465 247 189 465 minecraft:brown_terracotta
setblock 247 186 504 minecraft:bone_block
fill 248 186 464 248 189 464 minecraft:brown_terracotta
setblock 248 186 503 minecraft:bone_block
fill 248 186 504 248 189 504 minecraft:brown_terracotta
setblock 249 186 502 minecraft:bone_block
fill 249 186 503 249 189 503 minecraft:brown_terracotta
setblock 250 186 466 minecraft:bone_block
fill 250 186 502 250 189 502 minecraft:brown_terracotta
setblock 251 186 465 minecraft:bone_block
setblock 251 186 466 minecraft:brown_terracotta
setblock 252 186 464 minecraft:bone_block
fill 252 186 465 252 189 465 minecraft:brown_terracotta
setblock 252 186 504 minecraft:bone_block
fill 253 186 464 253 189 464 minecraft:brown_terracotta
setblock 253 186 503 minecraft:bone_block
fill 253 186 504 253 189 504 minecraft:brown_terracotta
setblock 254 186 502 minecraft:bone_block
fill 254 186 503 254 189 503 minecraft:brown_terracotta
setblock 257 186 464 minecraft:bone_block
setblock 257 186 504 minecraft:bone_block
fill 258 186 504 261 186 504 minecraft:brown_terracotta
setblock 262 186 504 minecraft:bone_block
fill 263 186 504 263 189 504 minecraft:brown_terracotta
fill 265 186 464 266 186 464 minecraft:brown_terracotta
setblock 267 186 464 minecraft:bone_block
setblock 267 186 504 minecraft:bone_block
fill 268 186 464 268 189 464 minecraft:brown_terracotta
setblock 268 186 503 minecraft:bone_block
fill 268 186 504 268 189 504 minecraft:brown_terracotta
fill 269 186 503 269 187 503 minecraft:brown_terracotta
setblock 271 186 464 minecraft:brown_terracotta
setblock 271 186 465 minecraft:bone_block
setblock 272 186 464 minecraft:bone_block
fill 272 186 465 272 189 465 minecraft:brown_terracotta
setblock 272 186 504 minecraft:bone_block
fill 273 186 464 273 189 464 minecraft:brown_terracotta
setblock 273 186 483 minecraft:bone_block
setblock 273 186 484 minecraft:brown_terracotta
fill 273 186 504 273 188 504 minecraft:brown_terracotta
setblock 274 186 482 minecraft:bone_block
fill 274 186 483 274 187 483 minecraft:brown_terracotta
setblock 274 186 487 minecraft:bone_block
setblock 275 186 481 minecraft:bone_block
fill 275 186 482 275 189 482 minecraft:brown_terracotta
setblock 275 186 486 minecraft:bone_block
fill 275 186 487 275 189 487 minecraft:brown_terracotta
setblock 276 186 465 minecraft:bone_block
fill 276 186 466 276 189 466 minecraft:brown_terracotta
setblock 276 186 476 minecraft:brown_terracotta
setblock 276 186 480 minecraft:bone_block
fill 276 186 481 276 189 481 minecraft:brown_terracotta
setblock 276 186 485 minecraft:bone_block
fill 276 186 486 276 189 486 minecraft:brown_terracotta
setblock 236 187 464 minecraft:bone_block
fill 236 187 465 236 190 465 minecraft:brown_terracotta
setblock 236 187 469 minecraft:bone_block
fill 236 187 470 236 190 470 minecraft:brown_terracotta
setblock 236 187 480 minecraft:brown_terracotta
setblock 236 187 484 minecraft:bone_block
setblock 236 187 485 minecraft:brown_terracotta
fill 237 187 464 240 187 464 minecraft:brown_terracotta
setblock 240 187 465 minecraft:bone_block
setblock 240 187 504 minecraft:brown_terracotta
setblock 241 187 464 minecraft:bone_block
fill 241 187 465 241 190 465 minecraft:brown_terracotta
setblock 241 187 504 minecraft:bone_block
fill 242 187 464 242 190 464 minecraft:brown_terracotta
fill 242 187 504 242 190 504 minecraft:brown_terracotta
setblock 245 187 465 minecraft:bone_block
setblock 246 187 464 minecraft:bone_block
fill 246 187 465 246 189 466 minecraft:brown_terracotta
setblock 246 187 504 minecraft:bone_block
fill 247 187 464 247 190 464 minecraft:brown_terracotta
setblock 247 187 503 minecraft:bone_block
fill 247 187 504 247 190 504 minecraft:brown_terracotta
setblock 248 187 502 minecraft:bone_block
fill 248 187 503 248 190 503 minecraft:brown_terracotta
setblock 249 187 466 minecraft:bone_block
fill 249 187 502 249 190 502 minecraft:brown_terracotta
setblock 250 187 465 minecraft:bone_block
fill 250 187 466 250 190 466 minecraft:brown_terracotta
setblock 251 187 464 minecraft:bone_block
fill 251 187 465 251 190 465 minecraft:brown_terracotta
setblock 251 187 504 minecraft:bone_block
fill 252 187 464 252 190 464 minecraft:brown_terracotta
setblock 252 187 503 minecraft:bone_block
fill 252 187 504 252 190 504 minecraft:brown_terracotta
fill 253 187 503 253 190 503 minecraft:brown_terracotta
setblock 256 187 464 minecraft:bone_block
setblock 256 187 504 minecraft:bone_block
fill 257 187 504 260 187 504 minecraft:brown_terracotta
setblock 261 187 504 minecraft:bone_block
fill 262 187 504 262 190 504 minecraft:brown_terracotta
setblock 265 187 464 minecraft:brown_terracotta
setblock 266 187 464 minecraft:bone_block
setblock 266 187 504 minecraft:bone_block
fill 267 187 464 267 190 464 minecraft:brown_terracotta
fill 267 187 504 267 190 504 minecraft:brown_terracotta
setblock 268 187 503 minecraft:brown_terracotta
setblock 269 187 465 minecraft:brown_terracotta
setblock 270 187 465 minecraft:bone_block
setblock 271 187 464 minecraft:bone_block
fill 271 187 465 271 190 465 minecraft:brown_terracotta
setblock 271 187 504 minecraft:bone_block
fill 272 187 464 272 190 464 minecraft:brown_terracotta
fill 272 187 504 272 189 504 minecraft:brown_terracotta
setblock 274 187 482 minecraft:brown_terracotta
setblock 274 187 486 minecraft:bone_block
setblock 275 187 480 minecraft:bone_block
fill 275 187 481 275 188 481 minecraft:brown_terracotta
setblock 275 187 485 minecraft:bone_block
fill 275 187 486 275 190 486 minecraft:brown_terracotta
setblock 276 187 464 minecraft:bone_block
fill 276 187 465 276 190 465 minecraft:brown_terracotta
setblock 276 187 468 minecraft:brown_terracotta
setblock 276 187 479 minecraft:bone_block
fill 276 187 480 276 189 480 minecraft:brown_terracotta
setblock 276 187 484 minecraft:bone_block
fill 276 187 485 276 190 485 minecraft:brown_terracotta
setblock 276 187 489 minecraft:bone_block
fill 236 188 464 239 188 464 minecraft:brown_terracotta
setblock 236 188 468 minecraft:bone_block
fill 236 188 469 236 191 469 minecraft:brown_terracotta
setblock 237 188 466 minecraft:brown_terracotta
setblock 238 188 465 minecraft:brown_terracotta
setblock 239 188 465 minecraft:bone_block
setblock 240 188 464 minecraft:bone_block
fill 240 188 465 240 191 465 minecraft:brown_terracotta
setblock 240 188 504 minecraft:bone_block
fill 241 188 464 241 191 464 minecraft:brown_terracotta
fill 241 188 504 241 191 504 minecraft:brown_terracotta
setblock 244 188 465 minecraft:bone_block
setblock 245 188 464 minecraft:bone_block
fill 245 188 465 245 190 466 minecraft:brown_terracotta
setblock 245 188 504 minecraft:bone_block
fill 246 188 464 246 191 464 minecraft:brown_terracotta
setblock 246 188 503 minecraft:bone_block
fill 246 188 504 246 191 504 minecraft:brown_terracotta
fill 247 188 503 247 191 503 minecraft:brown_terracotta
setblock 248 188 466 minecraft:bone_block
fill 248 188 502 248 191 502 minecraft:brown_terracotta
setblock 249 188 465 minecraft:bone_block
fill 249 188 466 249 191 466 minecraft:brown_terracotta
setblock 250 188 464 minecraft:bone_block
fill 250 188 465 250 191 465 minecraft:brown_terracotta
setblock 250 188 504 minecraft:bone_block
fill 251 188 464 251 191 464 minecraft:brown_terracotta
setblock 251 188 503 minecraft:bone_block
fill 251 188 504 251 191 504 minecraft:brown_terracotta
fill 252 188 503 252 191 503 minecraft:brown_terracotta
setblock 255 188 464 minecraft:bone_block
setblock 255 188 504 minecraft:bone_block
fill 256 188 464 256 189 464 minecraft:brown_terracotta
fill 256 188 504 259 188 504 minecraft:brown_terracotta
fill 259 188 494 259 189 495 minecraft:soul_soil
setblock 264 188 464 minecraft:brown_terracotta
setblock 265 188 464 minecraft:bone_block
setblock 265 188 504 minecraft:bone_block
fill 266 188 464 266 191 464 minecraft:brown_terracotta
fill 266 188 504 266 191 504 minecraft:brown_terracotta
setblock 268 188 465 minecraft:brown_terracotta
setblock 269 188 465 minecraft:bone_block
setblock 270 188 464 minecraft:bone_block
fill 270 188 465 270 191 465 minecraft:brown_terracotta
setblock 270 188 504 minecraft:bone_block
fill 271 188 464 271 191 464 minecraft:brown_terracotta
fill 271 188 504 271 190 504 minecraft:brown_terracotta
setblock 274 188 485 minecraft:bone_block
setblock 275 188 464 minecraft:bone_block
setblock 275 188 484 minecraft:bone_block
fill 275 188 485 275 191 485 minecraft:brown_terracotta
fill 276 188 464 276 191 464 minecraft:brown_terracotta
setblock 276 188 468 minecraft:bone_block
setblock 276 188 479 minecraft:brown_terracotta
setblock 276 188 483 minecraft:bone_block
fill 276 188 484 276 191 484 minecraft:brown_terracotta
setblock 276 188 488 minecraft:bone_block
fill 276 188 489 276 191 489 minecraft:brown_terracotta
fill 236 189 464 238 189 464 minecraft:brown_terracotta
setblock 236 189 467 minecraft:bone_block
fill 236 189 468 236 192 468 minecraft:brown_terracotta
setblock 236 189 471 minecraft:brown_terracotta
setblock 237 189 466 minecraft:bone_block
fill 237 189 467 237 192 467 minecraft:brown_terracotta
setblock 238 189 465 minecraft:bone_block
setblock 239 189 464 minecraft:bone_block
fill 239 189 465 239 192 465 minecraft:brown_terracotta
fill 240 189 464 240 192 464 minecraft:brown_terracotta
fill 240 189 504 240 192 504 minecraft:brown_terracotta
setblock 243 189 465 minecraft:bone_block
fill 243 189 466 244 191 466 minecraft:brown_terracotta
setblock 244 189 464 minecraft:bone_block
fill 244 189 465 244 192 465 minecraft:brown_terracotta
setblock 244 189 504 minecraft:bone_block
fill 245 189 464 245 192 464 minecraft:brown_terracotta
setblock 245 189 503 minecraft:bone_block
fill 245 189 504 245 192 504 minecraft:brown_terracotta
fill 246 189 503 246 192 503 minecraft:brown_terracotta
setblock 247 189 466 minecraft:bone_block
setblock 248 189 465 minecraft:bone_block
fill 248 189 466 248 192 466 minecraft:brown_terracotta
setblock 249 189 464 minecraft:bone_block
fill 249 189 465 249 192 465 minecraft:brown_terracotta
setblock 249 189 504 minecraft:bone_block
fill 250 189 464 250 192 464 minecraft:brown_terracotta
setblock 250 189 503 minecraft:bone_block
fill 250 189 504 250 192 504 minecraft:brown_terracotta
fill 251 189 503 251 192 503 minecraft:brown_terracotta
setblock 253 189 465 minecraft:bone_block
setblock 254 189 464 minecraft:bone_block
setblock 254 189 504 minecraft:bone_block
fill 255 189 464 255 192 464 minecraft:brown_terracotta
fill 255 189 504 257 189 504 minecraft:brown_terracotta
setblock 264 189 464 minecraft:bone_block
setblock 264 189 504 minecraft:bone_block
fill 265 189 464 265 192 464 minecraft:brown_terracotta
fill 265 189 504 265 192 504 minecraft:brown_terracotta
setblock 267 189 465 minecraft:brown_terracotta
setblock 268 189 465 minecraft:bone_block
setblock 269 189 464 minecraft:bone_block
fill 269 189 465 269 192 465 minecraft:brown_terracotta
setblock 269 189 504 minecraft:bone_block
fill 270 189 464 270 192 464 minecraft:brown_terracotta
fill 270 189 504 270 192 504 minecraft:brown_terracotta
setblock 274 189 464 minecraft:bone_block
fill 275 189 464 275 192 464 minecraft:brown_terracotta
setblock 275 189 483 minecraft:bone_block
fill 275 189 484 275 190 484 minecraft:brown_terracotta
setblock 276 189 467 minecraft:bone_block
fill 276 189 468 276 190 470 minecraft:brown_terracotta
setblock 276 189 482 minecraft:bone_block
fill 276 189 483 276 192 483 minecraft:brown_terracotta
setblock 276 189 487 minecraft:bone_block
fill 276 189 488 276 192 488 minecraft:brown_terracotta
fill 236 190 464 237 190 464 minecraft:brown_terracotta
setblock 236 190 466 minecraft:bone_block
fill 236 190 467 236 193 467 minecraft:brown_terracotta
setblock 236 190 471 minecraft:bone_block
setblock 237 190 465 minecraft:bone_block
fill 237 190 466 237 193 466 minecraft:brown_terracotta
fill 237 190 468 237 191 468 minecraft:brown_terracotta
setblock 238 190 464 minecraft:bone_block
fill 238 190 465 238 193 465 minecraft:brown_terracotta
fill 239 190 464 239 193 464 minecraft:brown_terracotta
setblock 242 190 465 minecraft:bone_block
fill 242 190 466 242 193 466 minecraft:brown_terracotta
setblock 243 190 464 minecraft:bone_block
fill 243 190 465 243 193 465 minecraft:brown_terracotta
setblock 243 190 503 minecraft:brown_terracotta
setblock 243 190 504 minecraft:bone_block
fill 244 190 464 244 193 464 minecraft:brown_terracotta
setblock 244 190 503 minecraft:bone_block
fill 244 190 504 244 193 504 minecraft:brown_terracotta
fill 245 190 503 245 193 503 minecraft:brown_terracotta
setblock 246 190 465 minecraft:brown_terracotta
setblock 246 190 466 minecraft:bone_block
setblock 247 190 465 minecraft:bone_block
fill 247 190 466 247 193 466 minecraft:brown_terracotta
setblock 248 190 464 minecraft:bone_block
fill 248 190 465 248 193 465 minecraft:brown_terracotta
setblock 248 190 504 minecraft:bone_block
fill 249 190 464 249 193 464 minecraft:brown_terracotta
setblock 249 190 503 minecraft:bone_block
fill 249 190 504 249 193 504 minecraft:brown_terracotta
fill 250 190 503 250 193 503 minecraft:brown_terracotta
setblock 252 190 465 minecraft:bone_block
setblock 253 190 464 minecraft:bone_block
setblock 253 190 465 minecraft:brown_terracotta
setblock 253 190 504 minecraft:bone_block
fill 254 190 464 254 193 464 minecraft:brown_terracotta
fill 254 190 504 256 191 504 minecraft:brown_terracotta
setblock 263 190 464 minecraft:bone_block
setblock 263 190 504 minecraft:bone_block
fill 264 190 464 264 193 464 minecraft:brown_terracotta
fill 264 190 504 264 193 504 minecraft:brown_terracotta
setblock 266 190 465 minecraft:brown_terracotta
setblock 267 190 465 minecraft:bone_block
setblock 268 190 464 minecraft:bone_block
fill 268 190 465 268 193 465 minecraft:brown_terracotta
setblock 268 190 504 minecraft:bone_block
fill 269 190 464 269 193 464 minecraft:brown_terracotta
fill 269 190 504 269 193 504 minecraft:brown_terracotta
setblock 272 190 465 minecraft:bone_block
setblock 273 190 464 minecraft:bone_block
fill 273 190 465 273 193 465 minecraft:brown_terracotta
fill 274 190 464 274 193 464 minecraft:brown_terracotta
setblock 275 190 487 minecraft:bone_block
setblock 276 190 466 minecraft:bone_block
fill 276 190 467 276 193 467 minecraft:brown_terracotta
setblock 276 190 471 minecraft:bone_block
setblock 276 190 481 minecraft:bone_block
fill 276 190 482 276 192 482 minecraft:brown_terracotta
setblock 276 190 486 minecraft:bone_block
fill 276 190 487 276 193 487 minecraft:brown_terracotta
setblock 236 191 464 minecraft:brown_terracotta
setblock 236 191 465 minecraft:bone_block
fill 236 191 466 236 194 466 minecraft:brown_terracotta
setblock 236 191 470 minecraft:bone_block
fill 236 191 471 236 193 472 minecraft:brown_terracotta
setblock 237 191 464 minecraft:bone_block
fill 237 191 465 237 194 465 minecraft:brown_terracotta
setblock 237 191 469 minecraft:bone_block
fill 238 191 464 238 194 464 minecraft:brown_terracotta
fill 239 191 504 239 193 504 minecraft:brown_terracotta
setblock 241 191 465 minecraft:bone_block
fill 241 191 466 241 194 466 minecraft:brown_terracotta
setblock 242 191 464 minecraft:bone_block
fill 242 191 465 242 194 465 minecraft:brown_terracotta
setblock 242 191 504 minecraft:bone_block
fill 243 191 464 243 194 464 minecraft:brown_terracotta
setblock 243 191 503 minecraft:bone_block
fill 243 191 504 243 194 504 minecraft:brown_terracotta
fill 244 191 503 244 194 503 minecraft:brown_terracotta
setblock 245 191 465 minecraft:brown_terracotta
setblock 245 191 466 minecraft:bone_block
setblock 246 191 465 minecraft:bone_block
fill 246 191 466 246 194 466 minecraft:brown_terracotta
setblock 247 191 464 minecraft:bone_block
fill 247 191 465 247 194 465 minecraft:brown_terracotta
fill 247 191 502 247 192 502 minecraft:brown_terracotta
setblock 247 191 504 minecraft:bone_block
fill 248 191 464 248 194 464 minecraft:brown_terracotta
setblock 248 191 503 minecraft:bone_block
fill 248 191 504 248 194 504 minecraft:brown_terracotta
fill 249 191 503 249 194 503 minecraft:brown_terracotta
setblock 250 191 466 minecraft:bone_block
setblock 251 191 465 minecraft:bone_block
setblock 252 191 464 minecraft:bone_block
fill 252 191 465 252 193 465 minecraft:brown_terracotta
setblock 252 191 504 minecraft:bone_block
fill 253 191 464 253 194 464 minecraft:brown_terracotta
fill 253 191 504 253 194 504 minecraft:brown_terracotta
setblock 262 191 464 minecraft:bone_block
setblock 262 191 504 minecraft:bone_block
fill 263 191 464 263 194 464 minecraft:brown_terracotta
fill 263 191 504 263 194 504 minecraft:brown_terracotta
fill 264 191 465 265 191 465 minecraft:brown_terracotta
setblock 266 191 465 minecraft:bone_block
setblock 267 191 464 minecraft:bone_block
fill 267 191 465 267 194 465 minecraft:brown_terracotta
setblock 267 191 504 minecraft:bone_block
fill 268 191 464 268 194 464 minecraft:brown_terracotta
fill 268 191 504 268 194 504 minecraft:brown_terracotta
setblock 271 191 465 minecraft:bone_block
setblock 272 191 464 minecraft:bone_block
fill 272 191 465 272 194 465 minecraft:brown_terracotta
fill 273 191 464 273 194 464 minecraft:brown_terracotta
setblock 275 191 466 minecraft:bone_block
fill 275 191 467 275 192 469 minecraft:brown_terracotta
setblock 275 191 486 minecraft:bone_block
fill 275 191 487 275 192 487 minecraft:brown_terracotta
setblock 276 191 465 minecraft:bone_block
fill 276 191 466 276 194 466 minecraft:brown_terracotta
fill 276 191 468 276 191 469 minecraft:brown_terracotta
setblock 276 191 470 minecraft:bone_block
fill 276 191 471 276 192 473 minecraft:brown_terracotta
setblock 276 191 481 minecraft:brown_terracotta
setblock 276 191 485 minecraft:bone_block
fill 276 191 486 276 194 486 minecraft:brown_terracotta
setblock 276 191 490 minecraft:bone_block
setblock 236 192 464 minecraft:bone_block
fill 236 192 465 236 195 465 minecraft:brown_terracotta
setblock 236 192 469 minecraft:bone_block
fill 236 192 470 237 194 470 minecraft:brown_terracotta
setblock 236 192 473 minecraft:brown_terracotta
fill 237 192 464 237 195 464 minecraft:brown_terracotta
setblock 237 192 468 minecraft:bone_block
fill 237 192 469 237 195 469 minecraft:brown_terracotta
setblock 238 192 466 minecraft:light[level=12]
setblock 238 192 474 minecraft:light[level=12]
setblock 238 192 482 minecraft:light[level=12]
setblock 238 192 490 minecraft:light[level=12]
setblock 238 192 498 minecraft:light[level=12]
setblock 239 192 466 minecraft:bone_block
setblock 240 192 465 minecraft:bone_block
fill 240 192 466 240 195 466 minecraft:brown_terracotta
setblock 241 192 464 minecraft:bone_block
fill 241 192 465 241 195 465 minecraft:brown_terracotta
setblock 241 192 504 minecraft:bone_block
fill 242 192 464 242 195 464 minecraft:brown_terracotta
setblock 242 192 503 minecraft:bone_block
fill 242 192 504 242 195 504 minecraft:brown_terracotta
setblock 243 192 466 minecraft:brown_terracotta
fill 243 192 503 243 195 503 minecraft:brown_terracotta
setblock 244 192 466 minecraft:bone_block
fill 244 192 467 247 192 467 minecraft:brown_terracotta
setblock 245 192 465 minecraft:bone_block
fill 245 192 466 245 195 466 minecraft:brown_terracotta
setblock 246 192 464 minecraft:bone_block
fill 246 192 465 246 195 465 minecraft:brown_terracotta
setblock 246 192 474 minecraft:light[level=12]
setblock 246 192 482 minecraft:light[level=12]
setblock 246 192 490 minecraft:light[level=12]
setblock 246 192 498 minecraft:light[level=12]
fill 246 192 502 246 193 502 minecraft:brown_terracotta
setblock 246 192 504 minecraft:bone_block
fill 247 192 464 247 195 464 minecraft:brown_terracotta
setblock 247 192 503 minecraft:bone_block
fill 247 192 504 247 195 504 minecraft:brown_terracotta
setblock 248 192 502 minecraft:bone_block
fill 248 192 503 248 195 503 minecraft:brown_terracotta
setblock 249 192 466 minecraft:bone_block
setblock 250 192 465 minecraft:bone_block
fill 250 192 466 250 193 466 minecraft:brown_terracotta
setblock 251 192 464 minecraft:bone_block
fill 251 192 465 251 194 465 minecraft:brown_terracotta
setblock 251 192 504 minecraft:bone_block
fill 252 192 464 252 195 464 minecraft:brown_terracotta
setblock 252 192 503 minecraft:bone_block
fill 252 192 504 252 195 504 minecraft:brown_terracotta
setblock 254 192 466 minecraft:light[level=12]
setblock 254 192 474 minecraft:light[level=12]
setblock 254 192 482 minecraft:light[level=12]
setblock 254 192 490 minecraft:light[level=12]
setblock 254 192 498 minecraft:light[level=12]
fill 254 192 504 255 192 504 minecraft:brown_terracotta
setblock 261 192 464 minecraft:bone_block
setblock 261 192 504 minecraft:bone_block
fill 262 192 464 262 195 464 minecraft:brown_terracotta
setblock 262 192 466 minecraft:light[level=12]
setblock 262 192 474 minecraft:light[level=12]
setblock 262 192 482 minecraft:light[level=12]
setblock 262 192 490 minecraft:light[level=12]
setblock 262 192 498 minecraft:light[level=12]
fill 262 192 504 262 195 504 minecraft:brown_terracotta
fill 263 192 465 264 192 465 minecraft:brown_terracotta
setblock 265 192 465 minecraft:bone_block
setblock 266 192 464 minecraft:bone_block
fill 266 192 465 266 194 466 minecraft:brown_terracotta
setblock 266 192 504 minecraft:bone_block
fill 267 192 464 267 195 464 minecraft:brown_terracotta
fill 267 192 466 268 192 466 minecraft:brown_terracotta
fill 267 192 504 267 195 504 minecraft:brown_terracotta
setblock 269 192 466 minecraft:bone_block
setblock 270 192 465 minecraft:bone_block
fill 270 192 466 270 194 466 minecraft:brown_terracotta
setblock 270 192 474 minecraft:light[level=12]
setblock 270 192 482 minecraft:light[level=12]
setblock 270 192 490 minecraft:light[level=12]
setblock 270 192 498 minecraft:light[level=12]
setblock 271 192 464 minecraft:bone_block
fill 271 192 465 271 195 465 minecraft:brown_terracotta
fill 272 192 464 272 195 464 minecraft:brown_terracotta
setblock 274 192 465 minecraft:brown_terracotta
fill 275 192 466 275 195 466 minecraft:brown_terracotta
setblock 275 192 470 minecraft:bone_block
fill 275 192 471 275 195 471 minecraft:brown_terracotta
setblock 275 192 486 minecraft:brown_terracotta
setblock 275 192 488 minecraft:brown_terracotta
setblock 276 192 464 minecraft:bone_block
fill 276 192 465 276 195 465 minecraft:brown_terracotta
setblock 276 192 468 minecraft:brown_terracotta
setblock 276 192 469 minecraft:bone_block
fill 276 192 470 276 195 470 minecraft:brown_terracotta
setblock 276 192 474 minecraft:bone_block
fill 276 192 475 276 195 475 minecraft:brown_terracotta
setblock 276 192 484 minecraft:bone_block
fill 276 192 485 276 195 485 minecraft:brown_terracotta
setblock 276 192 489 minecraft:bone_block
fill 276 192 490 276 194 491 minecraft:brown_terracotta
fill 235 193 473 235 196 476 minecraft:brown_terracotta
setblock 235 193 477 minecraft:soul_soil
fill 235 193 478 235 197 478 minecraft:brown_terracotta
setblock 235 193 489 minecraft:soul_soil
fill 236 193 463 236 196 464 minecraft:brown_terracotta
setblock 236 193 468 minecraft:bone_block
fill 236 193 469 236 196 469 minecraft:brown_terracotta
setblock 236 193 473 minecraft:bone_block
fill 236 193 474 236 196 474 minecraft:brown_terracotta
fill 237 193 463 239 193 463 minecraft:brown_terracotta
setblock 237 193 467 minecraft:bone_block
fill 237 193 468 238 195 468 minecraft:brown_terracotta
setblock 237 193 471 minecraft:brown_terracotta
setblock 238 193 466 minecraft:bone_block
fill 238 193 467 238 196 467 minecraft:brown_terracotta
fill 238 193 504 238 194 504 minecraft:brown_terracotta
setblock 239 193 465 minecraft:bone_block
fill 239 193 466 239 196 466 minecraft:brown_terracotta
fill 240 193 463 241 193 463 minecraft:soul_soil
setblock 240 193 464 minecraft:bone_block
fill 240 193 465 240 196 465 minecraft:brown_terracotta
setblock 240 193 504 minecraft:bone_block
fill 241 193 464 241 196 464 minecraft:brown_terracotta
fill 241 193 504 241 196 504 minecraft:brown_terracotta
setblock 242 193 467 minecraft:bone_block
fill 242 193 503 242 196 503 minecraft:brown_terracotta
setblock 243 193 466 minecraft:bone_block
fill 243 193 467 246 193 467 minecraft:brown_terracotta
setblock 244 193 465 minecraft:bone_block
fill 244 193 466 244 196 466 minecraft:brown_terracotta
setblock 245 193 464 minecraft:bone_block
fill 245 193 465 245 196 465 minecraft:brown_terracotta
fill 245 193 502 245 194 502 minecraft:brown_terracotta
setblock 245 193 504 minecraft:bone_block
fill 246 193 464 246 196 464 minecraft:brown_terracotta
setblock 246 193 503 minecraft:bone_block
fill 246 193 504 246 196 504 minecraft:brown_terracotta
setblock 247 193 467 minecraft:bone_block
setblock 247 193 502 minecraft:bone_block
fill 247 193 503 247 196 503 minecraft:brown_terracotta
setblock 247 193 505 minecraft:soul_soil
setblock 248 193 466 minecraft:bone_block
setblock 248 193 502 minecraft:brown_terracotta
fill 248 193 505 249 193 505 minecraft:brown_terracotta
setblock 249 193 465 minecraft:bone_block
fill 249 193 466 249 194 466 minecraft:brown_terracotta
setblock 250 193 464 minecraft:bone_block
fill 250 193 465 250 195 465 minecraft:brown_terracotta
setblock 250 193 504 minecraft:bone_block
fill 251 193 464 251 196 464 minecraft:brown_terracotta
setblock 251 193 503 minecraft:bone_block
fill 251 193 504 251 196 504 minecraft:brown_terracotta
setblock 254 193 504 minecraft:brown_terracotta
setblock 255 193 504 minecraft:bone_block
fill 258 193 463 261 194 463 minecraft:brown_terracotta
setblock 260 193 464 minecraft:bone_block
fill 261 193 464 261 196 464 minecraft:brown_terracotta
fill 261 193 504 261 195 504 minecraft:brown_terracotta
setblock 261 193 505 minecraft:soul_soil
setblock 262 193 463 minecraft:soul_soil
fill 263 193 463 263 196 463 minecraft:brown_terracotta
setblock 263 193 465 minecraft:brown_terracotta
setblock 263 193 505 minecraft:soul_soil
setblock 264 193 463 minecraft:soul_soil
setblock 264 193 465 minecraft:bone_block
fill 264 193 505 266 193 505 minecraft:brown_terracotta
fill 265 193 463 271 193 463 minecraft:brown_terracotta
setblock 265 193 464 minecraft:bone_block
fill 265 193 465 265 195 466 minecraft:brown_terracotta
setblock 265 193 504 minecraft:bone_block
fill 266 193 464 266 196 464 minecraft:brown_terracotta
fill 266 193 490 267 194 491 minecraft:soul_soil
fill 266 193 504 266 196 504 minecraft:brown_terracotta
setblock 267 193 466 minecraft:brown_terracotta
setblock 268 193 466 minecraft:bone_block
setblock 269 193 465 minecraft:bone_block
fill 269 193 466 269 195 466 minecraft:brown_terracotta
setblock 270 193 464 minecraft:bone_block
fill 270 193 465 270 196 465 minecraft:brown_terracotta
fill 271 193 464 271 196 464 minecraft:brown_terracotta
fill 272 193 463 273 193 463 minecraft:soul_soil
fill 274 193 463 274 196 463 minecraft:brown_terracotta
setblock 274 193 465 minecraft:bone_block
setblock 275 193 464 minecraft:bone_block
fill 275 193 465 275 194 465 minecraft:brown_terracotta
fill 275 193 467 275 193 468 minecraft:brown_terracotta
setblock 275 193 469 minecraft:bone_block
fill 275 193 470 275 196 470 minecraft:brown_terracotta
fill 275 193 472 277 193 472 minecraft:brown_terracotta
fill 276 193 463 277 194 463 minecraft:soul_soil
fill 276 193 464 276 196 464 minecraft:brown_terracotta
setblock 276 193 468 minecraft:bone_block
fill 276 193 469 277 196 469 minecraft:brown_terracotta
fill 276 193 471 276 194 471 minecraft:brown_terracotta
setblock 276 193 473 minecraft:bone_block
fill 276 193 474 276 196 474 minecraft:brown_terracotta
fill 276 193 476 276 194 476 minecraft:brown_terracotta
setblock 276 193 483 minecraft:bone_block
fill 276 193 484 276 194 484 minecraft:brown_terracotta
setblock 276 193 488 minecraft:bone_block
fill 276 193 489 277 196 489 minecraft:brown_terracotta
fill 277 193 468 277 196 468 minecraft:brown_terracotta
fill 277 193 470 277 196 470 minecraft:brown_terracotta
setblock 277 193 471 minecraft:soul_soil
fill 277 193 473 277 196 473 minecraft:brown_terracotta
fill 277 193 482 277 196 483 minecraft:brown_terracotta
setblock 277 193 484 minecraft:soul_soil
fill 277 193 485 277 196 485 minecraft:brown_terracotta
fill 277 193 487 277 196 488 minecraft:brown_terracotta
fill 277 193 490 277 196 491 minecraft:brown_terracotta
fill 277 193 492 277 194 492 minecraft:soul_soil
fill 277 193 493 277 199 493 minecraft:brown_terracotta
setblock 277 193 501 minecraft:soul_soil
fill 277 193 502 277 197 502 minecraft:brown_terracotta
setblock 277 193 503 minecraft:soul_soil
setblock 235 194 465 minecraft:brown_terracotta
fill 235 194 466 235 194 467 minecraft:soul_soil
fill 235 194 468 236 196 468 minecraft:brown_terracotta
setblock 235 194 470 minecraft:brown_terracotta
setblock 235 194 471 minecraft:soul_soil
fill 235 194 472 235 196 472 minecraft:brown_terracotta
fill 235 194 477 235 196 477 minecraft:brown_terracotta
fill 235 194 489 235 196 489 minecraft:brown_terracotta
fill 235 194 491 235 196 500 minecraft:brown_terracotta
setblock 235 194 501 minecraft:soul_soil
fill 235 194 502 235 196 504 minecraft:brown_terracotta
setblock 236 194 467 minecraft:bone_block
setblock 236 194 471 minecraft:brown_terracotta
setblock 236 194 472 minecraft:bone_block
fill 236 194 473 236 197 473 minecraft:brown_terracotta
fill 236 194 490 236 195 490 minecraft:brown_terracotta
fill 237 194 463 238 194 463 minecraft:brown_terracotta
setblock 237 194 466 minecraft:bone_block
fill 237 194 467 237 197 467 minecraft:brown_terracotta
setblock 237 194 471 minecraft:bone_block
fill 237 194 472 237 197 472 minecraft:brown_terracotta
setblock 238 194 465 minecraft:bone_block
fill 238 194 466 238 196 466 minecraft:brown_terracotta
setblock 238 194 469 minecraft:brown_terracotta
setblock 238 194 470 minecraft:bone_block
setblock 239 194 463 minecraft:soul_soil
setblock 239 194 464 minecraft:bone_block
fill 239 194 465 239 197 465 minecraft:brown_terracotta
setblock 239 194 504 minecraft:bone_block
fill 240 194 463 240 196 464 minecraft:brown_terracotta
fill 240 194 504 240 197 504 minecraft:brown_terracotta
fill 241 194 463 242 196 463 minecraft:brown_terracotta
setblock 241 194 467 minecraft:bone_block
fill 241 194 503 241 197 503 minecraft:brown_terracotta
setblock 242 194 466 minecraft:bone_block
fill 242 194 467 245 194 467 minecraft:brown_terracotta
setblock 243 194 463 minecraft:soul_soil
setblock 243 194 465 minecraft:bone_block
fill 243 194 466 243 197 466 minecraft:brown_terracotta
fill 244 194 463 247 196 463 minecraft:brown_terracotta
setblock 244 194 464 minecraft:bone_block
fill 244 194 465 244 197 465 minecraft:brown_terracotta
fill 244 194 502 244 195 502 minecraft:brown_terracotta
setblock 244 194 504 minecraft:bone_block
fill 245 194 464 245 197 464 minecraft:brown_terracotta
setblock 245 194 503 minecraft:bone_block
fill 245 194 504 245 197 504 minecraft:brown_terracotta
setblock 246 194 467 minecraft:bone_block
setblock 246 194 502 minecraft:bone_block
fill 246 194 503 246 197 503 minecraft:brown_terracotta
setblock 247 194 466 minecraft:bone_block
setblock 247 194 467 minecraft:brown_terracotta
fill 247 194 502 247 195 502 minecraft:brown_terracotta
fill 247 194 505 248 196 505 minecraft:brown_terracotta
setblock 248 194 465 minecraft:bone_block
fill 248 194 466 248 195 466 minecraft:brown_terracotta
setblock 249 194 464 minecraft:bone_block
fill 249 194 465 249 196 465 minecraft:brown_terracotta
setblock 249 194 504 minecraft:bone_block
fill 249 194 505 250 194 505 minecraft:soul_soil
fill 250 194 463 250 196 464 minecraft:brown_terracotta
setblock 250 194 503 minecraft:bone_block
fill 250 194 504 250 197 504 minecraft:brown_terracotta
fill 251 194 463 253 196 463 minecraft:brown_terracotta
setblock 251 194 503 minecraft:brown_terracotta
setblock 254 194 463 minecraft:soul_soil
setblock 254 194 504 minecraft:bone_block
fill 255 194 505 256 194 505 minecraft:soul_soil
fill 260 194 464 260 196 464 minecraft:brown_terracotta
fill 261 194 505 261 196 505 minecraft:brown_terracotta
setblock 262 194 463 minecraft:brown_terracotta
setblock 262 194 465 minecraft:brown_terracotta
setblock 263 194 465 minecraft:bone_block
fill 263 194 505 264 196 505 minecraft:brown_terracotta
fill 264 194 463 267 194 463 minecraft:brown_terracotta
setblock 264 194 464 minecraft:bone_block
fill 264 194 465 264 197 465 minecraft:brown_terracotta
setblock 264 194 504 minecraft:bone_block
fill 265 194 464 265 197 464 minecraft:brown_terracotta
fill 265 194 504 265 196 504 minecraft:brown_terracotta
fill 265 194 505 267 194 505 minecraft:soul_soil
setblock 267 194 466 minecraft:bone_block
setblock 268 194 463 minecraft:soul_soil
setblock 268 194 465 minecraft:bone_block
fill 268 194 466 268 195 466 minecraft:brown_terracotta
setblock 268 194 505 minecraft:brown_terracotta
fill 269 194 463 273 196 463 minecraft:brown_terracotta
setblock 269 194 464 minecraft:bone_block
fill 269 194 465 269 196 465 minecraft:brown_terracotta
setblock 269 194 505 minecraft:soul_soil
fill 270 194 464 270 197 464 minecraft:brown_terracotta
fill 270 194 505 274 196 505 minecraft:brown_terracotta
setblock 273 194 465 minecraft:bone_block
setblock 274 194 464 minecraft:bone_block
setblock 274 194 465 minecraft:brown_terracotta
fill 275 194 464 275 197 464 minecraft:brown_terracotta
setblock 275 194 467 minecraft:brown_terracotta
setblock 275 194 468 minecraft:bone_block
fill 275 194 469 275 197 469 minecraft:brown_terracotta
setblock 275 194 472 minecraft:brown_terracotta
setblock 275 194 473 minecraft:bone_block
fill 275 194 474 275 197 474 minecraft:brown_terracotta
setblock 276 194 467 minecraft:bone_block
fill 276 194 468 276 197 468 minecraft:brown_terracotta
setblock 276 194 472 minecraft:bone_block
fill 276 194 473 276 197 473 minecraft:brown_terracotta
setblock 276 194 477 minecraft:bone_block
setblock 276 194 487 minecraft:bone_block
fill 276 194 488 276 196 488 minecraft:brown_terracotta
setblock 276 194 492 minecraft:bone_block
fill 277 194 471 277 194 472 minecraft:brown_terracotta
setblock 277 194 479 minecraft:soul_soil
fill 277 194 484 277 196 484 minecraft:brown_terracotta
fill 277 194 501 277 196 501 minecraft:brown_terracotta
fill 277 194 503 277 196 503 minecraft:brown_terracotta
fill 235 195 464 235 195 465 minecraft:soul_soil
fill 235 195 466 235 196 467 minecraft:brown_terracotta
setblock 235 195 470 minecraft:soul_soil
fill 235 195 471 235 196 471 minecraft:brown_terracotta
fill 235 195 501 235 196 501 minecraft:brown_terracotta
setblock 236 195 466 minecraft:bone_block
fill 236 195 467 236 198 467 minecraft:brown_terracotta
setblock 236 195 470 minecraft:brown_terracotta
setblock 236 195 471 minecraft:bone_block
fill 236 195 472 236 198 472 minecraft:brown_terracotta
setblock 236 195 475 minecraft:brown_terracotta
setblock 236 195 489 minecraft:brown_terracotta
setblock 236 195 491 minecraft:bone_block
fill 236 195 492 236 197 493 minecraft:brown_terracotta
fill 236 195 505 237 195 505 minecraft:soul_soil
fill 237 195 463 237 196 463 minecraft:brown_terracotta
setblock 237 195 465 minecraft:bone_block
fill 237 195 466 237 198 466 minecraft:brown_terracotta
setblock 237 195 470 minecraft:bone_block
fill 237 195 471 237 198 471 minecraft:brown_terracotta
fill 237 195 473 237 196 473 minecraft:brown_terracotta
setblock 237 195 504 minecraft:brown_terracotta
setblock 238 195 463 minecraft:soul_soil
setblock 238 195 464 minecraft:bone_block
fill 238 195 465 238 198 465 minecraft:brown_terracotta
setblock 238 195 469 minecraft:bone_block
fill 238 195 470 238 198 470 minecraft:brown_terracotta
setblock 238 195 504 minecraft:bone_block
fill 239 195 463 239 197 464 minecraft:brown_terracotta
fill 239 195 504 239 198 504 minecraft:brown_terracotta
setblock 241 195 466 minecraft:bone_block
fill 241 195 467 244 195 467 minecraft:brown_terracotta
setblock 242 195 465 minecraft:bone_block
fill 242 195 466 242 198 466 minecraft:brown_terracotta
fill 243 195 463 243 196 463 minecraft:brown_terracotta
setblock 243 195 464 minecraft:bone_block
fill 243 195 465 243 198 465 minecraft:brown_terracotta
setblock 243 195 504 minecraft:bone_block
fill 244 195 464 244 198 464 minecraft:brown_terracotta
setblock 244 195 503 minecraft:bone_block
fill 244 195 504 244 198 504 minecraft:brown_terracotta
setblock 245 195 467 minecraft:bone_block
setblock 245 195 502 minecraft:bone_block
fill 245 195 503 245 198 503 minecraft:brown_terracotta
setblock 246 195 466 minecraft:bone_block
setblock 246 195 467 minecraft:brown_terracotta
fill 246 195 502 246 196 502 minecraft:brown_terracotta
setblock 247 195 465 minecraft:bone_block
fill 247 195 466 247 196 466 minecraft:brown_terracotta
setblock 248 195 464 minecraft:bone_block
fill 248 195 465 248 197 465 minecraft:brown_terracotta
setblock 248 195 504 minecraft:bone_block
fill 249 195 464 249 197 464 minecraft:brown_terracotta
setblock 249 195 503 minecraft:bone_block
fill 249 195 504 249 196 505 minecraft:brown_terracotta
setblock 250 195 503 minecraft:brown_terracotta
fill 250 195 505 250 197 505 minecraft:brown_terracotta
setblock 253 195 504 minecraft:bone_block
fill 254 195 463 254 196 463 minecraft:brown_terracotta
fill 255 195 505 256 196 505 minecraft:brown_terracotta
fill 258 195 463 258 196 463 minecraft:brown_terracotta
setblock 259 195 463 minecraft:soul_soil
fill 260 195 463 261 196 463 minecraft:brown_terracotta
fill 260 195 494 261 196 495 minecraft:bone_block
setblock 260 195 505 minecraft:soul_soil
setblock 262 195 463 minecraft:soul_soil
setblock 262 195 465 minecraft:bone_block
setblock 263 195 464 minecraft:bone_block
fill 263 195 465 263 197 465 minecraft:brown_terracotta
setblock 263 195 504 minecraft:bone_block
fill 264 195 463 264 196 464 minecraft:brown_terracotta
setblock 264 195 466 minecraft:brown_terracotta
fill 264 195 504 264 197 504 minecraft:brown_terracotta
fill 265 195 463 265 199 463 minecraft:brown_terracotta
setblock 265 195 505 minecraft:soul_soil
setblock 266 195 463 minecraft:soul_soil
setblock 266 195 465 minecraft:brown_terracotta
setblock 266 195 466 minecraft:bone_block
fill 266 195 505 267 196 505 minecraft:brown_terracotta
fill 267 195 463 268 196 463 minecraft:brown_terracotta
setblock 267 195 465 minecraft:bone_block
fill 267 195 466 267 196 466 minecraft:brown_terracotta
setblock 268 195 464 minecraft:bone_block
fill 268 195 465 268 197 465 minecraft:brown_terracotta
setblock 268 195 505 minecraft:soul_soil
fill 269 195 464 269 197 464 minecraft:brown_terracotta
fill 269 195 505 269 197 505 minecraft:brown_terracotta
setblock 272 195 465 minecraft:bone_block
setblock 273 195 464 minecraft:bone_block
fill 274 195 464 274 196 464 minecraft:brown_terracotta
fill 274 195 469 274 195 471 minecraft:brown_terracotta
setblock 275 195 467 minecraft:bone_block
fill 275 195 468 275 198 468 minecraft:brown_terracotta
setblock 275 195 472 minecraft:bone_block
fill 275 195 473 275 198 473 minecraft:brown_terracotta
fill 276 195 463 277 196 463 minecraft:brown_terracotta
setblock 276 195 466 minecraft:bone_block
fill 276 195 467 277 196 467 minecraft:brown_terracotta
setblock 276 195 471 minecraft:bone_block
fill 276 195 472 276 198 472 minecraft:brown_terracotta
setblock 276 195 476 minecraft:bone_block
fill 276 195 477 277 196 477 minecraft:brown_terracotta
setblock 276 195 486 minecraft:bone_block
fill 276 195 487 276 196 487 minecraft:brown_terracotta
setblock 276 195 490 minecraft:brown_terracotta
setblock 276 195 491 minecraft:bone_block
fill 276 195 492 277 196 492 minecraft:brown_terracotta
setblock 277 195 466 minecraft:soul_soil
fill 277 195 471 277 196 471 minecraft:brown_terracotta
setblock 277 195 472 minecraft:soul_soil
setblock 277 195 474 minecraft:soul_soil
fill 277 195 475 277 196 476 minecraft:brown_terracotta
fill 277 195 478 277 196 479 minecraft:brown_terracotta
setblock 277 195 480 minecraft:soul_soil
setblock 277 195 505 minecraft:soul_soil
fill 235 196 464 235 196 465 minecraft:brown_terracotta
setblock 235 196 470 minecraft:brown_terracotta
setblock 236 196 465 minecraft:bone_block
fill 236 196 466 236 199 466 minecraft:brown_terracotta
setblock 236 196 470 minecraft:bone_block
fill 236 196 471 236 199 471 minecraft:brown_terracotta
setblock 236 196 475 minecraft:bone_block
setblock 236 196 490 minecraft:bone_block
fill 236 196 491 236 198 491 minecraft:brown_terracotta
setblock 236 196 494 minecraft:brown_terracotta
fill 236 196 505 237 196 505 minecraft:brown_terracotta
setblock 237 196 464 minecraft:bone_block
fill 237 196 465 237 198 465 minecraft:brown_terracotta
setblock 237 196 468 minecraft:brown_terracotta
setblock 237 196 469 minecraft:bone_block
fill 237 196 470 237 199 470 minecraft:brown_terracotta
setblock 237 196 504 minecraft:bone_block
fill 238 196 463 238 196 464 minecraft:brown_terracotta
setblock 238 196 468 minecraft:bone_block
fill 238 196 469 238 198 469 minecraft:brown_terracotta
fill 238 196 471 238 197 471 minecraft:brown_terracotta
fill 238 196 504 238 199 504 minecraft:brown_terracotta
setblock 240 196 466 minecraft:bone_block
fill 240 196 503 240 198 503 minecraft:brown_terracotta
setblock 241 196 465 minecraft:bone_block
fill 241 196 466 241 198 466 minecraft:brown_terracotta
setblock 242 196 464 minecraft:bone_block
fill 242 196 465 242 199 465 minecraft:brown_terracotta
fill 242 196 467 243 196 467 minecraft:brown_terracotta
setblock 242 196 504 minecraft:bone_block
fill 243 196 464 243 199 464 minecraft:brown_terracotta
setblock 243 196 503 minecraft:bone_block
fill 243 196 504 243 199 504 minecraft:brown_terracotta
setblock 244 196 467 minecraft:bone_block
setblock 244 196 502 minecraft:bone_block
fill 244 196 503 244 199 503 minecraft:brown_terracotta
setblock 245 196 466 minecraft:bone_block
setblock 245 196 467 minecraft:brown_terracotta
fill 245 196 502 245 197 502 minecraft:brown_terracotta
setblock 246 196 465 minecraft:bone_block
fill 246 196 466 246 197 466 minecraft:brown_terracotta
setblock 247 196 464 minecraft:bone_block
fill 247 196 465 247 197 465 minecraft:brown_terracotta
setblock 247 196 504 minecraft:bone_block
fill 248 196 464 248 198 464 minecraft:brown_terracotta
setblock 248 196 503 minecraft:bone_block
fill 248 196 504 248 199 504 minecraft:brown_terracotta
setblock 249 196 503 minecraft:brown_terracotta
setblock 252 196 504 minecraft:bone_block
setblock 259 196 463 minecraft:brown_terracotta
setblock 260 196 505 minecraft:brown_terracotta
fill 262 196 463 262 197 463 minecraft:brown_terracotta
setblock 262 196 464 minecraft:bone_block
setblock 262 196 465 minecraft:brown_terracotta
setblock 262 196 504 minecraft:bone_block
fill 263 196 464 263 199 464 minecraft:brown_terracotta
fill 263 196 504 263 197 504 minecraft:brown_terracotta
setblock 265 196 465 minecraft:brown_terracotta
setblock 265 196 466 minecraft:bone_block
setblock 265 196 505 minecraft:brown_terracotta
setblock 266 196 463 minecraft:brown_terracotta
setblock 266 196 465 minecraft:bone_block
setblock 266 196 466 minecraft:brown_terracotta
setblock 267 196 464 minecraft:bone_block
fill 267 196 465 267 197 465 minecraft:brown_terracotta
fill 268 196 464 268 198 464 minecraft:brown_terracotta
setblock 268 196 505 minecraft:brown_terracotta
setblock 272 196 464 minecraft:bone_block
setblock 273 196 464 minecraft:brown_terracotta
fill 274 196 470 274 196 471 minecraft:brown_terracotta
setblock 275 196 466 minecraft:bone_block
fill 275 196 467 275 198 467 minecraft:brown_terracotta
setblock 275 196 471 minecraft:bone_block
fill 275 196 472 275 199 472 minecraft:brown_terracotta
setblock 275 196 475 minecraft:brown_terracotta
setblock 276 196 465 minecraft:bone_block
fill 276 196 466 277 196 466 minecraft:brown_terracotta
setblock 276 196 470 minecraft:bone_block
fill 276 196 471 276 199 471 minecraft:brown_terracotta
setblock 276 196 475 minecraft:bone_block
fill 276 196 476 276 199 476 minecraft:brown_terracotta
fill 276 196 478 276 197 478 minecraft:brown_terracotta
setblock 276 196 490 minecraft:bone_block
fill 276 196 491 276 197 491 minecraft:brown_terracotta
fill 276 196 493 276 197 493 minecraft:brown_terracotta
setblock 277 196 472 minecraft:brown_terracotta
setblock 277 196 474 minecraft:brown_terracotta
setblock 277 196 480 minecraft:brown_terracotta
setblock 277 196 505 minecraft:brown_terracotta
fill 235 197 464 235 198 477 minecraft:soul_soil
fill 235 197 479 235 307 479 minecraft:soul_soil
setblock 235 197 480 minecraft:brown_terracotta
fill 235 197 481 235 307 481 minecraft:soul_soil
setblock 235 197 482 minecraft:brown_terracotta
fill 235 197 483 235 197 487 minecraft:soul_soil
setblock 235 197 488 minecraft:brown_terracotta
fill 235 197 489 235 197 505 minecraft:soul_soil
fill 236 197 463 238 307 463 minecraft:soul_soil
setblock 236 197 464 minecraft:bone_block
fill 236 197 465 236 200 465 minecraft:brown_terracotta
setblock 236 197 468 minecraft:brown_terracotta
setblock 236 197 469 minecraft:bone_block
fill 236 197 470 236 200 470 minecraft:brown_terracotta
setblock 236 197 474 minecraft:bone_block
fill 236 197 475 236 200 475 minecraft:brown_terracotta
setblock 236 197 494 minecraft:bone_block
fill 236 197 495 236 199 496 minecraft:brown_terracotta
fill 236 197 505 249 197 505 minecraft:soul_soil
fill 237 197 464 238 199 464 minecraft:brown_terracotta
setblock 237 197 468 minecraft:bone_block
fill 237 197 469 237 200 469 minecraft:brown_terracotta
setblock 237 197 473 minecraft:bone_block
fill 237 197 504 237 200 504 minecraft:brown_terracotta
setblock 238 197 467 minecraft:bone_block
setblock 238 197 468 minecraft:brown_terracotta
setblock 239 197 466 minecraft:bone_block
fill 240 197 463 241 307 463 minecraft:soul_soil
setblock 240 197 464 minecraft:brown_terracotta
setblock 240 197 465 minecraft:bone_block
fill 240 197 466 240 198 466 minecraft:brown_terracotta
setblock 241 197 464 minecraft:bone_block
fill 241 197 465 241 200 465 minecraft:brown_terracotta
setblock 241 197 504 minecraft:bone_block
fill 242 197 463 242 197 464 minecraft:brown_terracotta
setblock 242 197 503 minecraft:bone_block
fill 242 197 504 242 200 504 minecraft:brown_terracotta
fill 243 197 463 261 197 463 minecraft:soul_soil
fill 243 197 503 243 200 503 minecraft:brown_terracotta
setblock 244 197 466 minecraft:bone_block
setblock 244 197 502 minecraft:brown_terracotta
setblock 245 197 465 minecraft:bone_block
setblock 245 197 466 minecraft:brown_terracotta
setblock 246 197 464 minecraft:bone_block
fill 246 197 465 246 198 465 minecraft:brown_terracotta
setblock 246 197 504 minecraft:bone_block
fill 247 197 464 247 198 464 minecraft:brown_terracotta
setblock 247 197 503 minecraft:bone_block
fill 247 197 504 247 200 504 minecraft:brown_terracotta
setblock 248 197 503 minecraft:brown_terracotta
fill 249 197 504 249 198 504 minecraft:brown_terracotta
fill 251 197 505 255 307 505 minecraft:soul_soil
setblock 256 197 505 minecraft:brown_terracotta
fill 257 197 505 261 198 505 minecraft:soul_soil
setblock 261 197 464 minecraft:bone_block
fill 262 197 464 262 198 464 minecraft:brown_terracotta
fill 263 197 463 264 307 463 minecraft:soul_soil
fill 263 197 505 265 307 505 minecraft:soul_soil
fill 264 197 464 264 198 464 minecraft:brown_terracotta
setblock 265 197 465 minecraft:bone_block
fill 266 197 463 277 197 463 minecraft:soul_soil
setblock 266 197 464 minecraft:bone_block
setblock 266 197 465 minecraft:brown_terracotta
setblock 266 197 505 minecraft:brown_terracotta
fill 267 197 464 267 198 464 minecraft:brown_terracotta
fill 267 197 505 268 307 505 minecraft:soul_soil
fill 270 197 505 270 307 505 minecraft:soul_soil
fill 271 197 505 272 197 505 minecraft:brown_terracotta
fill 273 197 505 273 307 505 minecraft:soul_soil
fill 274 197 505 274 199 505 minecraft:brown_terracotta
setblock 275 197 470 minecraft:bone_block
fill 275 197 471 275 200 471 minecraft:brown_terracotta
setblock 275 197 475 minecraft:bone_block
fill 275 197 505 277 307 505 minecraft:soul_soil
setblock 276 197 464 minecraft:bone_block
fill 276 197 465 276 198 467 minecraft:brown_terracotta
setblock 276 197 469 minecraft:bone_block
fill 276 197 470 276 200 470 minecraft:brown_terracotta
setblock 276 197 474 minecraft:bone_block
fill 276 197 475 276 200 475 minecraft:brown_terracotta
fill 276 197 477 276 198 477 minecraft:brown_terracotta
setblock 276 197 489 minecraft:bone_block
setblock 276 197 490 minecraft:brown_terracotta
setblock 276 197 492 minecraft:brown_terracotta
fill 277 197 464 277 198 480 minecraft:soul_soil
fill 277 197 482 277 307 486 minecraft:soul_soil
setblock 277 197 487 minecraft:brown_terracotta
fill 277 197 488 277 197 492 minecraft:soul_soil
fill 277 197 494 277 198 498 minecraft:soul_soil
setblock 277 197 499 minecraft:brown_terracotta
fill 277 197 500 277 307 501 minecraft:soul_soil
fill 277 197 503 277 307 504 minecraft:soul_soil
fill 235 198 463 235 307 463 minecraft:soul_soil
fill 235 198 478 235 307 478 minecraft:soul_soil
fill 235 198 480 235 307 480 minecraft:soul_soil
fill 235 198 482 235 307 483 minecraft:soul_soil
fill 235 198 484 235 199 484 minecraft:brown_terracotta
fill 235 198 485 235 307 492 minecraft:soul_soil
fill 235 198 493 235 198 494 minecraft:brown_terracotta
fill 235 198 495 235 198 497 minecraft:soul_soil
setblock 235 198 498 minecraft:brown_terracotta
fill 235 198 499 235 307 500 minecraft:soul_soil
setblock 235 198 501 minecraft:brown_terracotta
fill 235 198 502 235 307 505 minecraft:soul_soil
fill 236 198 464 236 200 464 minecraft:brown_terracotta
setblock 236 198 468 minecraft:bone_block
fill 236 198 469 236 201 469 minecraft:brown_terracotta
setblock 236 198 473 minecraft:bone_block
fill 236 198 474 237 200 474 minecraft:brown_terracotta
fill 236 198 476 236 199 476 minecraft:brown_terracotta
setblock 236 198 492 minecraft:brown_terracotta
setblock 236 198 493 minecraft:bone_block
fill 236 198 494 236 201 494 minecraft:brown_terracotta
setblock 236 198 497 minecraft:brown_terracotta
fill 236 198 505 247 198 505 minecraft:soul_soil
setblock 237 198 467 minecraft:bone_block
fill 237 198 468 237 200 468 minecraft:brown_terracotta
setblock 237 198 472 minecraft:bone_block
fill 237 198 473 237 201 473 minecraft:brown_terracotta
setblock 238 198 471 minecraft:bone_block
fill 239 198 463 239 307 463 minecraft:soul_soil
setblock 239 198 464 minecraft:brown_terracotta
setblock 239 198 465 minecraft:bone_block
setblock 240 198 464 minecraft:bone_block
fill 240 198 465 240 200 465 minecraft:brown_terracotta
setblock 240 198 504 minecraft:bone_block
fill 241 198 464 242 200 464 minecraft:brown_terracotta
setblock 241 198 503 minecraft:bone_block
fill 241 198 504 241 201 504 minecraft:brown_terracotta
fill 242 198 463 244 307 463 minecraft:soul_soil
fill 242 198 503 242 201 503 minecraft:brown_terracotta
setblock 243 198 466 minecraft:bone_block
setblock 244 198 465 minecraft:bone_block
setblock 244 198 466 minecraft:brown_terracotta
setblock 245 198 463 minecraft:brown_terracotta
setblock 245 198 464 minecraft:bone_block
setblock 245 198 465 minecraft:brown_terracotta
setblock 245 198 504 minecraft:bone_block
fill 246 198 463 259 307 463 minecraft:soul_soil
fill 246 198 464 246 199 464 minecraft:brown_terracotta
setblock 246 198 503 minecraft:bone_block
fill 246 198 504 246 201 504 minecraft:brown_terracotta
setblock 247 198 503 minecraft:brown_terracotta
setblock 248 198 505 minecraft:brown_terracotta
fill 249 198 505 250 307 505 minecraft:soul_soil
fill 256 198 505 256 307 505 minecraft:soul_soil
setblock 260 198 463 minecraft:brown_terracotta
fill 260 198 466 264 199 470 minecraft:soul_soil
fill 261 198 463 262 307 463 minecraft:soul_soil
setblock 262 198 465 minecraft:soul_soil
fill 262 198 505 262 307 505 minecraft:soul_soil
setblock 265 198 464 minecraft:bone_block
fill 266 198 463 266 198 464 minecraft:brown_terracotta
fill 266 198 505 266 307 505 minecraft:soul_soil
fill 267 198 463 267 307 463 minecraft:soul_soil
setblock 268 198 463 minecraft:brown_terracotta
fill 269 198 463 277 198 463 minecraft:soul_soil
setblock 269 198 505 minecraft:soul_soil
fill 271 198 505 272 307 505 minecraft:soul_soil
setblock 275 198 469 minecraft:bone_block
fill 275 198 470 275 201 470 minecraft:brown_terracotta
setblock 275 198 474 minecraft:bone_block
fill 275 198 475 275 201 475 minecraft:brown_terracotta
setblock 276 198 464 minecraft:brown_terracotta
setblock 276 198 468 minecraft:bone_block
fill 276 198 469 276 201 469 minecraft:brown_terracotta
setblock 276 198 473 minecraft:bone_block
fill 276 198 474 276 201 474 minecraft:brown_terracotta
setblock 276 198 478 minecraft:bone_block
fill 277 198 481 277 307 481 minecraft:soul_soil
fill 277 198 487 277 307 490 minecraft:soul_soil
setblock 277 198 491 minecraft:brown_terracotta
fill 277 198 492 277 307 492 minecraft:soul_soil
fill 277 198 499 277 307 499 minecraft:soul_soil
fill 277 198 502 277 307 502 minecraft:soul_soil
fill 235 199 464 235 307 472 minecraft:soul_soil
fill 235 199 473 236 199 473 minecraft:brown_terracotta
fill 235 199 474 235 307 477 minecraft:soul_soil
fill 235 199 493 235 307 496 minecraft:soul_soil
setblock 235 199 497 minecraft:brown_terracotta
fill 235 199 498 235 307 498 minecraft:soul_soil
fill 235 199 501 235 307 501 minecraft:soul_soil
setblock 236 199 467 minecraft:bone_block
fill 236 199 468 236 202 468 minecraft:brown_terracotta
setblock 236 199 472 minecraft:bone_block
setblock 236 199 492 minecraft:bone_block
fill 236 199 493 236 202 493 minecraft:brown_terracotta
setblock 236 199 497 minecraft:bone_block
fill 236 199 498 236 201 499 minecraft:brown_terracotta
setblock 236 199 505 minecraft:brown_terracotta
setblock 237 199 466 minecraft:bone_block
setblock 237 199 467 minecraft:brown_terracotta
setblock 237 199 471 minecraft:bone_block
fill 237 199 472 237 202 472 minecraft:brown_terracotta
fill 237 199 505 240 307 505 minecraft:soul_soil
setblock 238 199 465 minecraft:bone_block
setblock 239 199 464 minecraft:bone_block
setblock 239 199 465 minecraft:brown_terracotta
setblock 239 199 504 minecraft:bone_block
fill 240 199 464 240 202 464 minecraft:brown_terracotta
setblock 240 199 503 minecraft:bone_block
fill 240 199 504 240 202 504 minecraft:brown_terracotta
fill 241 199 503 241 202 503 minecraft:brown_terracotta
setblock 241 199 505 minecraft:brown_terracotta
fill 242 199 505 248 307 505 minecraft:soul_soil
setblock 243 199 465 minecraft:bone_block
setblock 244 199 464 minecraft:bone_block
setblock 244 199 465 minecraft:brown_terracotta
setblock 244 199 504 minecraft:bone_block
fill 245 199 463 245 307 463 minecraft:soul_soil
fill 245 199 464 245 200 464 minecraft:brown_terracotta
setblock 245 199 503 minecraft:bone_block
fill 245 199 504 245 202 504 minecraft:brown_terracotta
setblock 246 199 503 minecraft:brown_terracotta
fill 257 199 505 258 199 505 minecraft:brown_terracotta
fill 259 199 505 261 307 505 minecraft:soul_soil
fill 260 199 463 260 307 463 minecraft:soul_soil
setblock 264 199 464 minecraft:bone_block
setblock 265 199 464 minecraft:brown_terracotta
fill 266 199 463 266 307 463 minecraft:soul_soil
fill 268 199 463 270 307 463 minecraft:soul_soil
setblock 269 199 505 minecraft:brown_terracotta
setblock 271 199 463 minecraft:brown_terracotta
fill 272 199 463 277 307 463 minecraft:soul_soil
setblock 275 199 468 minecraft:bone_block
fill 275 199 469 275 200 469 minecraft:brown_terracotta
setblock 275 199 473 minecraft:bone_block
fill 275 199 474 275 202 474 minecraft:brown_terracotta
fill 276 199 465 276 199 466 minecraft:brown_terracotta
setblock 276 199 467 minecraft:bone_block
fill 276 199 468 276 202 468 minecraft:brown_terracotta
setblock 276 199 472 minecraft:bone_block
fill 276 199 473 276 202 473 minecraft:brown_terracotta
setblock 276 199 477 minecraft:bone_block
fill 276 199 478 276 202 478 minecraft:brown_terracotta
fill 277 199 464 277 307 464 minecraft:soul_soil
setblock 277 199 465 minecraft:brown_terracotta
fill 277 199 466 277 307 468 minecraft:soul_soil
setblock 277 199 469 minecraft:brown_terracotta
fill 277 199 470 277 307 470 minecraft:soul_soil
setblock 277 199 471 minecraft:brown_terracotta
fill 277 199 472 277 307 476 minecraft:soul_soil
setblock 277 199 477 minecraft:brown_terracotta
fill 277 199 478 277 307 480 minecraft:soul_soil
fill 277 199 491 277 307 491 minecraft:soul_soil
setblock 277 199 494 minecraft:brown_terracotta
fill 277 199 495 277 307 498 minecraft:soul_soil
fill 235 200 473 235 307 473 minecraft:soul_soil
fill 235 200 484 235 307 484 minecraft:soul_soil
fill 235 200 497 235 307 497 minecraft:soul_soil
setblock 236 200 466 minecraft:bone_block
fill 236 200 467 236 203 467 minecraft:brown_terracotta
setblock 236 200 471 minecraft:bone_block
fill 236 200 472 236 202 473 minecraft:brown_terracotta
setblock 236 200 476 minecraft:bone_block
setblock 236 200 492 minecraft:brown_terracotta
setblock 236 200 495 minecraft:brown_terracotta
setblock 236 200 496 minecraft:bone_block
fill 236 200 497 237 202 497 minecraft:brown_terracotta
setblock 236 200 500 minecraft:brown_terracotta
fill 236 200 505 236 307 505 minecraft:soul_soil
setblock 237 200 464 minecraft:brown_terracotta
setblock 237 200 470 minecraft:bone_block
fill 237 200 471 237 202 471 minecraft:brown_terracotta
setblock 237 200 495 minecraft:bone_block
fill 237 200 496 237 203 496 minecraft:brown_terracotta
setblock 238 200 464 minecraft:bone_block
setblock 238 200 466 minecraft:light[level=12]
setblock 238 200 474 minecraft:light[level=12]
setblock 238 200 482 minecraft:light[level=12]
setblock 238 200 490 minecraft:light[level=12]
setblock 238 200 498 minecraft:light[level=12]
setblock 238 200 504 minecraft:bone_block
fill 239 200 464 239 203 464 minecraft:brown_terracotta
fill 239 200 504 239 203 504 minecraft:brown_terracotta
fill 240 200 503 240 203 503 minecraft:brown_terracotta
fill 241 200 505 241 307 505 minecraft:soul_soil
setblock 242 200 465 minecraft:bone_block
setblock 243 200 464 minecraft:bone_block
setblock 243 200 504 minecraft:bone_block
fill 244 200 464 244 201 464 minecraft:brown_terracotta
setblock 244 200 503 minecraft:bone_block
fill 244 200 504 244 203 504 minecraft:brown_terracotta
setblock 245 200 503 minecraft:brown_terracotta
setblock 246 200 466 minecraft:light[level=12]
setblock 246 200 474 minecraft:light[level=12]
setblock 246 200 482 minecraft:light[level=12]
setblock 246 200 490 minecraft:light[level=12]
setblock 246 200 498 minecraft:light[level=12]
setblock 254 200 466 minecraft:light[level=12]
setblock 254 200 474 minecraft:light[level=12]
setblock 254 200 482 minecraft:light[level=12]
setblock 254 200 490 minecraft:light[level=12]
setblock 254 200 498 minecraft:light[level=12]
fill 257 200 505 258 307 505 minecraft:soul_soil
fill 258 200 467 260 201 467 minecraft:bone_block
fill 258 200 469 260 201 469 minecraft:bone_block
fill 259 200 468 259 201 468 minecraft:bone_block
setblock 262 200 466 minecraft:light[level=12]
setblock 262 200 474 minecraft:light[level=12]
setblock 262 200 482 minecraft:light[level=12]
setblock 262 200 490 minecraft:light[level=12]
setblock 262 200 498 minecraft:light[level=12]
fill 265 200 463 265 307 463 minecraft:soul_soil
fill 269 200 505 269 307 505 minecraft:soul_soil
setblock 270 200 466 minecraft:light[level=12]
setblock 270 200 474 minecraft:light[level=12]
setblock 270 200 482 minecraft:light[level=12]
setblock 270 200 490 minecraft:light[level=12]
setblock 270 200 498 minecraft:light[level=12]
fill 271 200 463 271 307 463 minecraft:soul_soil
fill 274 200 505 274 307 505 minecraft:soul_soil
setblock 275 200 472 minecraft:bone_block
fill 275 200 473 275 203 473 minecraft:brown_terracotta
setblock 276 200 465 minecraft:brown_terracotta
setblock 276 200 466 minecraft:bone_block
fill 276 200 467 276 203 467 minecraft:brown_terracotta
setblock 276 200 471 minecraft:bone_block
fill 276 200 472 276 203 472 minecraft:brown_terracotta
setblock 276 200 476 minecraft:bone_block
fill 276 200 477 276 203 477 minecraft:brown_terracotta
fill 277 200 465 277 307 465 minecraft:soul_soil
fill 277 200 469 277 307 469 minecraft:soul_soil
fill 277 200 471 277 307 471 minecraft:soul_soil
fill 277 200 477 277 307 477 minecraft:soul_soil
fill 277 200 493 277 307 494 minecraft:soul_soil
setblock 236 201 465 minecraft:bone_block
fill 236 201 466 236 204 466 minecraft:brown_terracotta
setblock 236 201 470 minecraft:bone_block
fill 236 201 471 236 204 471 minecraft:brown_terracotta
setblock 236 201 474 minecraft:brown_terracotta
setblock 236 201 475 minecraft:bone_block
fill 236 201 476 236 204 476 minecraft:brown_terracotta
setblock 236 201 495 minecraft:bone_block
fill 236 201 496 236 204 496 minecraft:brown_terracotta
setblock 236 201 500 minecraft:bone_block
fill 236 201 501 236 203 502 minecraft:brown_terracotta
setblock 237 201 464 minecraft:bone_block
setblock 237 201 470 minecraft:brown_terracotta
setblock 237 201 474 minecraft:bone_block
setblock 237 201 494 minecraft:bone_block
fill 237 201 495 237 204 495 minecraft:brown_terracotta
setblock 237 201 498 minecraft:brown_terracotta
setblock 237 201 499 minecraft:bone_block
setblock 237 201 504 minecraft:bone_block
fill 238 201 464 238 204 464 minecraft:brown_terracotta
fill 238 201 504 238 204 504 minecraft:brown_terracotta
fill 239 201 503 239 204 503 minecraft:brown_terracotta
setblock 241 201 464 minecraft:brown_terracotta
setblock 242 201 464 minecraft:bone_block
setblock 242 201 504 minecraft:bone_block
fill 243 201 464 243 202 464 minecraft:brown_terracotta
setblock 243 201 503 minecraft:bone_block
fill 243 201 504 243 204 504 minecraft:brown_terracotta
fill 244 201 503 244 204 503 minecraft:brown_terracotta
fill 260 201 468 261 202 468 minecraft:bone_block
setblock 275 201 471 minecraft:bone_block
fill 275 201 472 275 204 472 minecraft:brown_terracotta
fill 276 201 466 276 204 466 minecraft:brown_terracotta
setblock 276 201 470 minecraft:bone_block
fill 276 201 471 276 204 471 minecraft:brown_terracotta
setblock 276 201 475 minecraft:bone_block
fill 276 201 476 276 204 476 minecraft:brown_terracotta
setblock 236 202 469 minecraft:bone_block
fill 236 202 470 236 205 470 minecraft:brown_terracotta
setblock 236 202 474 minecraft:bone_block
fill 236 202 475 236 205 475 minecraft:brown_terracotta
fill 236 202 477 236 203 477 minecraft:brown_terracotta
setblock 236 202 494 minecraft:bone_block
fill 236 202 495 236 205 495 minecraft:brown_terracotta
setblock 236 202 498 minecraft:brown_terracotta
setblock 236 202 499 minecraft:bone_block
fill 236 202 500 237 204 500 minecraft:brown_terracotta
setblock 236 202 503 minecraft:brown_terracotta
setblock 236 202 504 minecraft:bone_block
fill 237 202 464 237 205 464 minecraft:brown_terracotta
setblock 237 202 473 minecraft:bone_block
fill 237 202 474 237 205 474 minecraft:brown_terracotta
fill 237 202 494 237 205 494 minecraft:brown_terracotta
setblock 237 202 498 minecraft:bone_block
fill 237 202 499 237 205 499 minecraft:brown_terracotta
fill 237 202 501 237 203 501 minecraft:brown_terracotta
fill 237 202 504 237 205 504 minecraft:brown_terracotta
setblock 238 202 496 minecraft:brown_terracotta
setblock 238 202 497 minecraft:bone_block
fill 238 202 498 238 205 498 minecraft:brown_terracotta
fill 238 202 503 238 205 503 minecraft:brown_terracotta
setblock 241 202 464 minecraft:bone_block
setblock 241 202 504 minecraft:bone_block
fill 242 202 464 242 205 464 minecraft:brown_terracotta
setblock 242 202 503 minecraft:bone_block
fill 242 202 504 242 205 504 minecraft:brown_terracotta
fill 243 202 503 243 205 503 minecraft:brown_terracotta
setblock 246 202 504 minecraft:bone_block
fill 262 202 468 262 203 468 minecraft:bone_block
setblock 275 202 470 minecraft:bone_block
fill 275 202 471 275 205 471 minecraft:brown_terracotta
setblock 275 202 475 minecraft:bone_block
fill 275 202 476 275 205 476 minecraft:brown_terracotta
setblock 276 202 469 minecraft:bone_block
fill 276 202 470 276 205 470 minecraft:brown_terracotta
setblock 276 202 474 minecraft:bone_block
fill 276 202 475 276 205 475 minecraft:brown_terracotta
setblock 276 202 479 minecraft:bone_block
fill 236 203 464 236 206 464 minecraft:brown_terracotta
setblock 236 203 468 minecraft:bone_block
fill 236 203 469 236 206 469 minecraft:brown_terracotta
setblock 236 203 472 minecraft:brown_terracotta
setblock 236 203 473 minecraft:bone_block
fill 236 203 474 236 206 474 minecraft:brown_terracotta
setblock 236 203 478 minecraft:bone_block
setblock 236 203 492 minecraft:brown_terracotta
setblock 236 203 493 minecraft:bone_block
fill 236 203 494 236 206 494 minecraft:brown_terracotta
setblock 236 203 497 minecraft:brown_terracotta
setblock 236 203 498 minecraft:bone_block
fill 236 203 499 236 206 499 minecraft:brown_terracotta
setblock 236 203 503 minecraft:bone_block
fill 236 203 504 236 206 504 minecraft:brown_terracotta
setblock 237 203 472 minecraft:bone_block
fill 237 203 473 237 206 473 minecraft:brown_terracotta
fill 237 203 475 237 204 475 minecraft:brown_terracotta
setblock 237 203 497 minecraft:bone_block
fill 237 203 498 237 206 498 minecraft:brown_terracotta
setblock 237 203 502 minecraft:bone_block
fill 237 203 503 237 206 503 minecraft:brown_terracotta
setblock 238 203 495 minecraft:brown_terracotta
setblock 238 203 496 minecraft:bone_block
fill 238 203 497 238 206 497 minecraft:brown_terracotta
fill 238 203 499 238 203 500 minecraft:brown_terracotta
fill 239 203 502 241 203 502 minecraft:brown_terracotta
setblock 240 203 464 minecraft:bone_block
setblock 240 203 504 minecraft:bone_block
fill 241 203 464 241 206 464 minecraft:brown_terracotta
setblock 241 203 503 minecraft:bone_block
fill 241 203 504 241 206 504 minecraft:brown_terracotta
setblock 242 203 502 minecraft:bone_block
fill 242 203 503 242 206 503 minecraft:brown_terracotta
setblock 245 203 504 minecraft:bone_block
fill 246 203 504 246 206 504 minecraft:brown_terracotta
fill 263 203 468 264 204 468 minecraft:bone_block
fill 275 203 470 275 206 470 minecraft:brown_terracotta
setblock 275 203 474 minecraft:bone_block
fill 275 203 475 275 206 475 minecraft:brown_terracotta
fill 275 203 477 275 204 477 minecraft:brown_terracotta
fill 276 203 465 276 205 465 minecraft:brown_terracotta
setblock 276 203 468 minecraft:bone_block
fill 276 203 469 276 206 469 minecraft:brown_terracotta
setblock 276 203 473 minecraft:bone_block
fill 276 203 474 276 206 474 minecraft:brown_terracotta
setblock 276 203 478 minecraft:bone_block
fill 276 203 479 276 205 480 minecraft:brown_terracotta
fill 276 203 495 276 203 497 minecraft:brown_terracotta
setblock 276 203 498 minecraft:bone_block
fill 276 203 499 276 205 500 minecraft:brown_terracotta
fill 236 204 465 236 205 465 minecraft:brown_terracotta
setblock 236 204 467 minecraft:bone_block
fill 236 204 468 236 207 468 minecraft:brown_terracotta
setblock 236 204 472 minecraft:bone_block
fill 236 204 473 236 207 473 minecraft:brown_terracotta
setblock 236 204 477 minecraft:bone_block
fill 236 204 478 236 206 479 minecraft:brown_terracotta
setblock 236 204 492 minecraft:bone_block
fill 236 204 493 237 206 493 minecraft:brown_terracotta
setblock 236 204 497 minecraft:bone_block
fill 236 204 498 236 207 498 minecraft:brown_terracotta
setblock 236 204 501 minecraft:brown_terracotta
setblock 236 204 502 minecraft:bone_block
fill 236 204 503 236 207 503 minecraft:brown_terracotta
fill 237 204 472 237 207 472 minecraft:brown_terracotta
setblock 237 204 476 minecraft:bone_block
setblock 237 204 496 minecraft:bone_block
fill 237 204 497 237 207 497 minecraft:brown_terracotta
setblock 237 204 501 minecraft:bone_block
fill 237 204 502 240 204 502 minecraft:brown_terracotta
setblock 238 204 495 minecraft:bone_block
fill 238 204 496 238 207 496 minecraft:brown_terracotta
setblock 238 204 499 minecraft:brown_terracotta
setblock 238 204 500 minecraft:bone_block
fill 238 204 501 238 207 501 minecraft:brown_terracotta
setblock 239 204 464 minecraft:bone_block
fill 239 204 497 239 204 498 minecraft:brown_terracotta
setblock 239 204 499 minecraft:bone_block
setblock 239 204 504 minecraft:bone_block
fill 240 204 464 240 207 464 minecraft:brown_terracotta
setblock 240 204 503 minecraft:bone_block
fill 240 204 504 240 207 504 minecraft:brown_terracotta
setblock 241 204 502 minecraft:bone_block
fill 241 204 503 241 207 503 minecraft:brown_terracotta
fill 242 204 502 243 206 502 minecraft:brown_terracotta
setblock 244 204 504 minecraft:bone_block
fill 245 204 504 245 207 504 minecraft:brown_terracotta
fill 264 204 467 266 205 467 minecraft:bone_block
fill 264 204 469 266 205 469 minecraft:bone_block
fill 265 204 468 265 205 468 minecraft:bone_block
setblock 275 204 473 minecraft:bone_block
fill 275 204 474 275 207 474 minecraft:brown_terracotta
setblock 275 204 478 minecraft:bone_block
fill 276 204 464 276 206 464 minecraft:brown_terracotta
setblock 276 204 467 minecraft:bone_block
fill 276 204 468 276 207 468 minecraft:brown_terracotta
setblock 276 204 472 minecraft:bone_block
fill 276 204 473 276 207 473 minecraft:brown_terracotta
setblock 276 204 477 minecraft:bone_block
fill 276 204 478 276 207 478 minecraft:brown_terracotta
setblock 276 204 481 minecraft:brown_terracotta
fill 276 204 494 276 204 496 minecraft:brown_terracotta
setblock 276 204 497 minecraft:bone_block
fill 276 204 498 276 207 498 minecraft:brown_terracotta
setblock 276 204 501 minecraft:brown_terracotta
setblock 276 204 502 minecraft:bone_block
fill 276 204 503 276 206 504 minecraft:brown_terracotta
setblock 236 205 466 minecraft:bone_block
fill 236 205 467 236 208 467 minecraft:brown_terracotta
setblock 236 205 471 minecraft:bone_block
fill 236 205 472 236 208 472 minecraft:brown_terracotta
setblock 236 205 476 minecraft:bone_block
fill 236 205 477 237 207 477 minecraft:brown_terracotta
setblock 236 205 480 minecraft:brown_terracotta
setblock 236 205 491 minecraft:bone_block
fill 236 205 492 236 208 492 minecraft:brown_terracotta
setblock 236 205 496 minecraft:bone_block
fill 236 205 497 236 208 497 minecraft:brown_terracotta
setblock 236 205 500 minecraft:brown_terracotta
setblock 236 205 501 minecraft:bone_block
fill 236 205 502 239 205 502 minecraft:brown_terracotta
setblock 237 205 475 minecraft:bone_block
fill 237 205 476 237 208 476 minecraft:brown_terracotta
fill 237 205 478 237 206 478 minecraft:brown_terracotta
setblock 237 205 495 minecraft:bone_block
fill 237 205 496 237 208 496 minecraft:brown_terracotta
setblock 237 205 500 minecraft:bone_block
fill 237 205 501 237 208 501 minecraft:brown_terracotta
setblock 238 205 464 minecraft:bone_block
setblock 238 205 494 minecraft:bone_block
fill 238 205 495 238 208 495 minecraft:brown_terracotta
setblock 238 205 499 minecraft:bone_block
fill 238 205 500 239 207 500 minecraft:brown_terracotta
setblock 238 205 504 minecraft:bone_block
fill 239 205 464 239 208 464 minecraft:brown_terracotta
fill 239 205 496 239 205 497 minecraft:brown_terracotta
setblock 239 205 498 minecraft:bone_block
fill 239 205 499 239 208 499 minecraft:brown_terracotta
fill 239 205 501 240 205 501 minecraft:brown_terracotta
setblock 239 205 503 minecraft:bone_block
fill 239 205 504 239 208 504 minecraft:brown_terracotta
setblock 240 205 502 minecraft:bone_block
fill 240 205 503 240 208 503 minecraft:brown_terracotta
setblock 241 205 501 minecraft:bone_block
fill 241 205 502 241 208 502 minecraft:brown_terracotta
setblock 243 205 504 minecraft:bone_block
setblock 244 205 503 minecraft:bone_block
fill 244 205 504 244 208 504 minecraft:brown_terracotta
fill 245 205 503 245 208 503 minecraft:brown_terracotta
setblock 257 205 504 minecraft:brown_terracotta
setblock 258 205 504 minecraft:bone_block
fill 259 205 504 261 206 504 minecraft:brown_terracotta
fill 275 205 464 275 207 464 minecraft:brown_terracotta
setblock 275 205 472 minecraft:bone_block
fill 275 205 473 275 208 473 minecraft:brown_terracotta
setblock 275 205 477 minecraft:bone_block
fill 275 205 478 275 207 479 minecraft:brown_terracotta
fill 275 205 504 275 207 504 minecraft:brown_terracotta
setblock 276 205 466 minecraft:bone_block
fill 276 205 467 276 208 467 minecraft:brown_terracotta
setblock 276 205 471 minecraft:bone_block
fill 276 205 472 276 208 472 minecraft:brown_terracotta
setblock 276 205 476 minecraft:bone_block
fill 276 205 477 276 208 477 minecraft:brown_terracotta
setblock 276 205 481 minecraft:bone_block
fill 276 205 482 276 208 482 minecraft:brown_terracotta
fill 276 205 494 276 205 495 minecraft:brown_terracotta
setblock 276 205 496 minecraft:bone_block
fill 276 205 497 276 208 497 minecraft:brown_terracotta
setblock 276 205 501 minecraft:bone_block
fill 276 205 502 276 208 502 minecraft:brown_terracotta
setblock 236 206 465 minecraft:bone_block
fill 236 206 466 236 209 466 minecraft:brown_terracotta
setblock 236 206 470 minecraft:bone_block
fill 236 206 471 236 209 471 minecraft:brown_terracotta
setblock 236 206 475 minecraft:bone_block
fill 236 206 476 236 209 476 minecraft:brown_terracotta
setblock 236 206 480 minecraft:bone_block
fill 236 206 481 236 208 482 minecraft:brown_terracotta
fill 236 206 491 236 209 491 minecraft:brown_terracotta
setblock 236 206 495 minecraft:bone_block
fill 236 206 496 236 209 496 minecraft:brown_terracotta
setblock 236 206 500 minecraft:bone_block
fill 236 206 501 236 208 502 minecraft:brown_terracotta
setblock 237 206 464 minecraft:bone_block
setblock 237 206 474 minecraft:bone_block
fill 237 206 475 237 209 475 minecraft:brown_terracotta
setblock 237 206 479 minecraft:bone_block
fill 237 206 480 237 209 480 minecraft:brown_terracotta
fill 237 206 492 237 207 492 minecraft:brown_terracotta
setblock 237 206 494 minecraft:bone_block
fill 237 206 495 237 209 495 minecraft:brown_terracotta
setblock 237 206 499 minecraft:bone_block
fill 237 206 500 237 209 500 minecraft:brown_terracotta
fill 237 206 502 238 206 502 minecraft:brown_terracotta
setblock 237 206 504 minecraft:bone_block
fill 238 206 464 238 209 464 minecraft:brown_terracotta
fill 238 206 494 238 209 494 minecraft:brown_terracotta
setblock 238 206 498 minecraft:bone_block
fill 238 206 499 238 209 499 minecraft:brown_terracotta
setblock 238 206 503 minecraft:bone_block
fill 238 206 504 238 209 504 minecraft:brown_terracotta
setblock 239 206 496 minecraft:brown_terracotta
setblock 239 206 497 minecraft:bone_block
fill 239 206 498 239 209 498 minecraft:brown_terracotta
setblock 239 206 501 minecraft:brown_terracotta
setblock 239 206 502 minecraft:bone_block
fill 239 206 503 239 209 503 minecraft:brown_terracotta
setblock 240 206 501 minecraft:bone_block
fill 240 206 502 240 209 502 minecraft:brown_terracotta
fill 241 206 501 242 208 501 minecraft:brown_terracotta
setblock 242 206 464 minecraft:bone_block
setblock 242 206 504 minecraft:bone_block
setblock 243 206 503 minecraft:bone_block
fill 243 206 504 243 209 504 minecraft:brown_terracotta
setblock 244 206 502 minecraft:bone_block
fill 244 206 503 244 209 503 minecraft:brown_terracotta
setblock 247 206 504 minecraft:bone_block
fill 255 206 504 256 206 504 minecraft:brown_terracotta
setblock 257 206 504 minecraft:bone_block
setblock 258 206 503 minecraft:bone_block
fill 258 206 504 258 209 504 minecraft:brown_terracotta
fill 259 206 503 259 209 503 minecraft:brown_terracotta
fill 260 206 464 261 206 464 minecraft:brown_terracotta
setblock 262 206 504 minecraft:bone_block
fill 273 206 464 274 208 464 minecraft:brown_terracotta
fill 273 206 504 274 208 504 minecraft:brown_terracotta
fill 274 206 475 274 206 476 minecraft:brown_terracotta
fill 275 206 469 275 207 469 minecraft:brown_terracotta
setblock 275 206 471 minecraft:bone_block
fill 275 206 472 275 209 472 minecraft:brown_terracotta
setblock 275 206 476 minecraft:bone_block
fill 275 206 477 275 209 477 minecraft:brown_terracotta
setblock 275 206 480 minecraft:brown_terracotta
fill 275 206 497 275 206 500 minecraft:brown_terracotta
setblock 275 206 501 minecraft:bone_block
fill 275 206 502 275 208 503 minecraft:brown_terracotta
setblock 276 206 465 minecraft:bone_block
fill 276 206 466 276 209 466 minecraft:brown_terracotta
setblock 276 206 470 minecraft:bone_block
fill 276 206 471 276 209 471 minecraft:brown_terracotta
setblock 276 206 475 minecraft:bone_block
fill 276 206 476 276 209 476 minecraft:brown_terracotta
setblock 276 206 479 minecraft:brown_terracotta
setblock 276 206 480 minecraft:bone_block
fill 276 206 481 276 209 481 minecraft:brown_terracotta
fill 276 206 483 276 207 483 minecraft:brown_terracotta
fill 276 206 493 276 206 494 minecraft:brown_terracotta
setblock 276 206 495 minecraft:bone_block
fill 276 206 496 276 209 496 minecraft:brown_terracotta
setblock 276 206 499 minecraft:brown_terracotta
setblock 276 206 500 minecraft:bone_block
fill 276 206 501 276 209 501 minecraft:brown_terracotta
setblock 236 207 464 minecraft:bone_block
fill 236 207 465 239 207 465 minecraft:brown_terracotta
setblock 236 207 469 minecraft:bone_block
fill 236 207 470 236 210 470 minecraft:brown_terracotta
setblock 236 207 474 minecraft:bone_block
fill 236 207 475 236 210 475 minecraft:brown_terracotta
setblock 236 207 478 minecraft:brown_terracotta
setblock 236 207 479 minecraft:bone_block
fill 236 207 480 236 210 480 minecraft:brown_terracotta
setblock 236 207 483 minecraft:brown_terracotta
setblock 236 207 484 minecraft:bone_block
fill 236 207 485 236 210 485 minecraft:brown_terracotta
setblock 236 207 489 minecraft:bone_block
fill 236 207 490 236 210 490 minecraft:brown_terracotta
setblock 236 207 493 minecraft:brown_terracotta
setblock 236 207 494 minecraft:bone_block
fill 236 207 495 236 210 495 minecraft:brown_terracotta
setblock 236 207 499 minecraft:bone_block
fill 236 207 500 236 210 500 minecraft:brown_terracotta
setblock 236 207 504 minecraft:bone_block
fill 237 207 464 237 210 464 minecraft:brown_terracotta
setblock 237 207 473 minecraft:bone_block
fill 237 207 474 237 210 474 minecraft:brown_terracotta
setblock 237 207 478 minecraft:bone_block
fill 237 207 479 237 210 479 minecraft:brown_terracotta
fill 237 207 481 237 207 482 minecraft:brown_terracotta
setblock 237 207 493 minecraft:bone_block
fill 237 207 494 237 210 494 minecraft:brown_terracotta
setblock 237 207 498 minecraft:bone_block
fill 237 207 499 237 210 499 minecraft:brown_terracotta
setblock 237 207 502 minecraft:brown_terracotta
setblock 237 207 503 minecraft:bone_block
fill 237 207 504 237 210 504 minecraft:brown_terracotta
setblock 238 207 497 minecraft:bone_block
fill 238 207 498 238 210 498 minecraft:brown_terracotta
setblock 238 207 502 minecraft:bone_block
fill 238 207 503 238 210 503 minecraft:brown_terracotta
setblock 239 207 496 minecraft:bone_block
fill 239 207 497 239 210 497 minecraft:brown_terracotta
setblock 239 207 501 minecraft:bone_block
fill 239 207 502 239 210 502 minecraft:brown_terracotta
fill 240 207 501 240 210 501 minecraft:brown_terracotta
setblock 241 207 464 minecraft:bone_block
setblock 241 207 504 minecraft:bone_block
fill 242 207 464 242 210 464 minecraft:brown_terracotta
setblock 242 207 502 minecraft:brown_terracotta
setblock 242 207 503 minecraft:bone_block
fill 242 207 504 242 210 504 minecraft:brown_terracotta
setblock 243 207 502 minecraft:bone_block
fill 243 207 503 243 210 503 minecraft:brown_terracotta
fill 244 207 502 244 210 502 minecraft:brown_terracotta
setblock 246 207 503 minecraft:brown_terracotta
setblock 246 207 504 minecraft:bone_block
fill 247 207 504 248 209 504 minecraft:brown_terracotta
fill 252 207 504 255 207 504 minecraft:brown_terracotta
fill 255 207 503 256 207 503 minecraft:brown_terracotta
setblock 256 207 504 minecraft:bone_block
fill 257 207 464 260 207 464 minecraft:brown_terracotta
setblock 257 207 503 minecraft:bone_block
fill 257 207 504 257 210 504 minecraft:brown_terracotta
fill 258 207 503 258 210 503 minecraft:brown_terracotta
fill 259 207 504 260 207 504 minecraft:brown_terracotta
fill 260 207 503 261 207 503 minecraft:brown_terracotta
setblock 261 207 464 minecraft:bone_block
setblock 261 207 504 minecraft:bone_block
fill 262 207 464 263 209 464 minecraft:brown_terracotta
fill 262 207 504 263 209 504 minecraft:brown_terracotta
setblock 271 207 464 minecraft:bone_block
fill 272 207 464 272 210 464 minecraft:brown_terracotta
fill 272 207 504 272 210 504 minecraft:brown_terracotta
fill 274 207 474 274 207 475 minecraft:brown_terracotta
setblock 274 207 476 minecraft:bone_block
fill 274 207 477 274 209 478 minecraft:brown_terracotta
fill 274 207 503 274 209 503 minecraft:brown_terracotta
setblock 275 207 465 minecraft:bone_block
fill 275 207 466 275 208 468 minecraft:brown_terracotta
setblock 275 207 470 minecraft:bone_block
fill 275 207 471 275 210 471 minecraft:brown_terracotta
setblock 275 207 475 minecraft:bone_block
fill 275 207 476 275 210 476 minecraft:brown_terracotta
setblock 275 207 480 minecraft:bone_block
fill 275 207 481 275 210 481 minecraft:brown_terracotta
fill 275 207 496 275 207 499 minecraft:brown_terracotta
setblock 275 207 500 minecraft:bone_block
fill 275 207 501 275 210 501 minecraft:brown_terracotta
setblock 276 207 464 minecraft:bone_block
fill 276 207 465 276 210 465 minecraft:brown_terracotta
setblock 276 207 469 minecraft:bone_block
fill 276 207 470 276 210 470 minecraft:brown_terracotta
setblock 276 207 474 minecraft:bone_block
fill 276 207 475 276 210 475 minecraft:brown_terracotta
setblock 276 207 479 minecraft:bone_block
fill 276 207 480 276 210 480 minecraft:brown_terracotta
setblock 276 207 484 minecraft:bone_block
setblock 276 207 493 minecraft:brown_terracotta
setblock 276 207 494 minecraft:bone_block
fill 276 207 495 276 210 495 minecraft:brown_terracotta
setblock 276 207 499 minecraft:bone_block
fill 276 207 500 276 210 500 minecraft:brown_terracotta
setblock 276 207 503 minecraft:brown_terracotta
setblock 276 207 504 minecraft:bone_block
fill 236 208 464 236 210 465 minecraft:brown_terracotta
setblock 236 208 468 minecraft:bone_block
fill 236 208 469 236 211 469 minecraft:brown_terracotta
setblock 236 208 473 minecraft:bone_block
fill 236 208 474 236 211 474 minecraft:brown_terracotta
setblock 236 208 477 minecraft:brown_terracotta
setblock 236 208 478 minecraft:bone_block
fill 236 208 479 236 211 479 minecraft:brown_terracotta
setblock 236 208 483 minecraft:bone_block
fill 236 208 484 237 210 484 minecraft:brown_terracotta
fill 236 208 486 236 208 487 minecraft:brown_terracotta
setblock 236 208 488 minecraft:bone_block
fill 236 208 489 236 211 489 minecraft:brown_terracotta
setblock 236 208 493 minecraft:bone_block
fill 236 208 494 236 211 494 minecraft:brown_terracotta
setblock 236 208 498 minecraft:bone_block
fill 236 208 499 236 211 499 minecraft:brown_terracotta
setblock 236 208 503 minecraft:bone_block
fill 236 208 504 236 211 504 minecraft:brown_terracotta
fill 237 208 465 237 208 466 minecraft:brown_terracotta
setblock 237 208 472 minecraft:bone_block
fill 237 208 473 237 209 473 minecraft:brown_terracotta
setblock 237 208 477 minecraft:bone_block
fill 237 208 478 238 210 478 minecraft:brown_terracotta
setblock 237 208 481 minecraft:brown_terracotta
setblock 237 208 482 minecraft:bone_block
fill 237 208 483 237 211 483 minecraft:brown_terracotta
setblock 237 208 491 minecraft:brown_terracotta
setblock 237 208 492 minecraft:bone_block
fill 237 208 493 238 209 493 minecraft:brown_terracotta
setblock 237 208 497 minecraft:bone_block
fill 237 208 498 237 211 498 minecraft:brown_terracotta
setblock 237 208 502 minecraft:bone_block
fill 237 208 503 237 211 503 minecraft:brown_terracotta
setblock 238 208 465 minecraft:brown_terracotta
setblock 238 208 466 minecraft:light[level=12]
setblock 238 208 474 minecraft:light[level=12]
fill 238 208 477 238 209 477 minecraft:brown_terracotta
fill 238 208 479 238 208 480 minecraft:brown_terracotta
setblock 238 208 482 minecraft:light[level=12]
setblock 238 208 490 minecraft:light[level=12]
setblock 238 208 496 minecraft:bone_block
fill 238 208 497 238 211 497 minecraft:brown_terracotta
setblock 238 208 500 minecraft:brown_terracotta
setblock 238 208 501 minecraft:bone_block
fill 238 208 502 238 211 502 minecraft:brown_terracotta
setblock 239 208 465 minecraft:bone_block
fill 239 208 496 239 209 496 minecraft:brown_terracotta
setblock 239 208 500 minecraft:bone_block
fill 239 208 501 239 211 501 minecraft:brown_terracotta
setblock 240 208 464 minecraft:bone_block
setblock 240 208 499 minecraft:bone_block
fill 240 208 500 240 209 500 minecraft:brown_terracotta
setblock 240 208 504 minecraft:bone_block
fill 241 208 464 241 211 464 minecraft:brown_terracotta
setblock 241 208 503 minecraft:bone_block
fill 241 208 504 241 211 504 minecraft:brown_terracotta
setblock 242 208 502 minecraft:bone_block
fill 242 208 503 242 211 503 minecraft:brown_terracotta
setblock 243 208 501 minecraft:bone_block
fill 243 208 502 243 211 502 minecraft:brown_terracotta
setblock 245 208 504 minecraft:bone_block
setblock 246 208 466 minecraft:light[level=12]
setblock 246 208 474 minecraft:light[level=12]
setblock 246 208 482 minecraft:light[level=12]
fill 246 208 487 246 209 487 minecraft:bone_block
setblock 246 208 490 minecraft:light[level=12]
setblock 246 208 498 minecraft:light[level=12]
setblock 246 208 503 minecraft:bone_block
fill 246 208 504 246 211 504 minecraft:brown_terracotta
setblock 249 208 504 minecraft:brown_terracotta
setblock 250 208 504 minecraft:bone_block
fill 251 208 504 254 208 504 minecraft:brown_terracotta
fill 253 208 503 255 208 503 minecraft:brown_terracotta
setblock 254 208 466 minecraft:light[level=12]
setblock 254 208 474 minecraft:light[level=12]
setblock 254 208 482 minecraft:light[level=12]
setblock 254 208 490 minecraft:light[level=12]
setblock 254 208 498 minecraft:light[level=12]
setblock 255 208 464 minecraft:bone_block
setblock 255 208 504 minecraft:bone_block
fill 256 208 464 259 208 464 minecraft:brown_terracotta
setblock 256 208 502 minecraft:brown_terracotta
setblock 256 208 503 minecraft:bone_block
fill 256 208 504 256 211 504 minecraft:brown_terracotta
setblock 257 208 502 minecraft:bone_block
fill 257 208 503 257 211 503 minecraft:brown_terracotta
schedule function dropper:buildpart/113_8 1t
