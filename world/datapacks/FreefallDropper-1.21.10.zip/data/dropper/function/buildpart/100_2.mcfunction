setblock 207 201 419 minecraft:light[level=13]
setblock 207 201 427 minecraft:light[level=13]
setblock 207 201 435 minecraft:light[level=13]
setblock 207 201 443 minecraft:light[level=13]
setblock 207 201 451 minecraft:light[level=13]
setblock 215 201 419 minecraft:light[level=13]
setblock 215 201 427 minecraft:light[level=13]
setblock 215 201 435 minecraft:light[level=13]
setblock 215 201 443 minecraft:light[level=13]
setblock 215 201 451 minecraft:light[level=13]
setblock 223 201 419 minecraft:light[level=13]
setblock 223 201 427 minecraft:light[level=13]
setblock 223 201 435 minecraft:light[level=13]
setblock 223 201 443 minecraft:light[level=13]
setblock 223 201 451 minecraft:light[level=13]
setblock 226 201 442 minecraft:polished_deepslate
fill 228 201 434 228 222 434 minecraft:polished_deepslate
fill 224 202 441 228 206 441 minecraft:polished_deepslate
fill 195 203 435 195 223 435 minecraft:polished_deepslate
fill 223 203 435 223 223 435 minecraft:polished_deepslate
fill 194 204 434 194 222 434 minecraft:polished_deepslate
fill 224 204 434 224 222 434 minecraft:polished_deepslate
fill 189 205 420 189 205 425 minecraft:deepslate
fill 189 205 432 189 205 437 minecraft:deepslate
fill 189 205 438 194 206 441 minecraft:polished_deepslate
fill 189 205 444 189 205 449 minecraft:deepslate
fill 189 205 456 189 205 457 minecraft:deepslate
fill 190 205 435 194 222 437 minecraft:polished_deepslate
fill 190 205 457 193 205 457 minecraft:deepslate
fill 193 205 417 198 205 417 minecraft:deepslate
fill 196 205 437 196 222 438 minecraft:polished_deepslate
fill 200 205 453 200 220 453 minecraft:iron_block
fill 200 205 457 205 205 457 minecraft:deepslate
fill 205 205 417 210 205 417 minecraft:deepslate
fill 212 205 457 217 205 457 minecraft:deepslate
fill 217 205 417 222 205 417 minecraft:deepslate
fill 222 205 437 222 222 438 minecraft:polished_deepslate
fill 224 205 457 229 205 457 minecraft:deepslate
fill 229 205 417 229 205 422 minecraft:deepslate
fill 229 205 429 229 205 434 minecraft:deepslate
fill 229 205 441 229 205 446 minecraft:deepslate
fill 229 205 453 229 205 456 minecraft:deepslate
fill 188 206 422 188 211 425 minecraft:shroomlight
fill 188 206 434 188 211 437 minecraft:shroomlight
fill 188 206 446 188 211 449 minecraft:shroomlight
fill 188 206 458 191 211 458 minecraft:shroomlight
fill 189 206 435 189 222 437 minecraft:polished_deepslate
fill 195 206 416 198 211 416 minecraft:shroomlight
fill 200 206 458 203 211 458 minecraft:shroomlight
fill 207 206 416 210 211 416 minecraft:shroomlight
fill 212 206 458 215 211 458 minecraft:shroomlight
fill 219 206 416 222 211 416 minecraft:shroomlight
fill 224 206 458 227 211 458 minecraft:shroomlight
fill 230 206 417 230 211 420 minecraft:shroomlight
fill 230 206 429 230 211 432 minecraft:shroomlight
fill 230 206 441 230 211 444 minecraft:shroomlight
fill 230 206 453 230 211 456 minecraft:shroomlight
fill 189 207 438 193 208 441 minecraft:polished_deepslate
fill 194 207 438 194 222 440 minecraft:polished_deepslate
fill 225 207 441 228 208 441 minecraft:polished_deepslate
fill 189 209 438 189 222 441 minecraft:polished_deepslate
fill 190 209 438 193 222 440 minecraft:polished_deepslate
setblock 191 209 419 minecraft:light[level=13]
setblock 191 209 427 minecraft:light[level=13]
fill 191 209 441 193 222 441 minecraft:polished_deepslate
setblock 191 209 443 minecraft:light[level=13]
setblock 191 209 451 minecraft:light[level=13]
fill 192 209 433 192 222 433 minecraft:polished_deepslate
setblock 199 209 419 minecraft:light[level=13]
setblock 199 209 427 minecraft:light[level=13]
setblock 199 209 435 minecraft:light[level=13]
setblock 199 209 443 minecraft:light[level=13]
setblock 199 209 451 minecraft:light[level=13]
setblock 207 209 419 minecraft:light[level=13]
setblock 207 209 427 minecraft:light[level=13]
setblock 207 209 435 minecraft:light[level=13]
setblock 207 209 443 minecraft:light[level=13]
setblock 207 209 451 minecraft:light[level=13]
setblock 215 209 419 minecraft:light[level=13]
setblock 215 209 427 minecraft:light[level=13]
setblock 215 209 435 minecraft:light[level=13]
setblock 215 209 443 minecraft:light[level=13]
setblock 215 209 451 minecraft:light[level=13]
setblock 223 209 419 minecraft:light[level=13]
setblock 223 209 427 minecraft:light[level=13]
setblock 223 209 443 minecraft:light[level=13]
setblock 223 209 451 minecraft:light[level=13]
fill 225 209 441 227 222 441 minecraft:polished_deepslate
fill 226 209 433 226 222 433 minecraft:polished_deepslate
fill 196 210 436 196 222 436 minecraft:polished_deepslate
fill 222 210 436 222 222 436 minecraft:polished_deepslate
fill 227 210 442 227 213 442 minecraft:red_wool
fill 191 211 433 191 222 433 minecraft:polished_deepslate
fill 193 211 433 193 222 433 minecraft:polished_deepslate
fill 195 211 436 195 223 439 minecraft:polished_deepslate
fill 209 211 455 211 213 456 minecraft:orange_stained_glass
fill 210 211 452 210 212 454 minecraft:orange_stained_glass
fill 210 211 457 210 214 457 minecraft:orange_stained_glass
fill 223 211 436 229 222 439 minecraft:polished_deepslate
fill 224 211 440 229 211 440 minecraft:polished_deepslate
fill 225 211 433 225 222 433 minecraft:polished_deepslate
fill 227 211 433 227 222 433 minecraft:polished_deepslate
fill 227 211 443 227 214 444 minecraft:red_wool
fill 188 212 422 188 225 422 minecraft:polished_andesite
fill 188 212 423 188 212 424 minecraft:shroomlight
fill 188 212 425 188 225 425 minecraft:polished_andesite
fill 188 212 434 188 225 434 minecraft:polished_andesite
fill 188 212 435 188 212 436 minecraft:shroomlight
fill 188 212 437 188 225 437 minecraft:polished_andesite
fill 188 212 446 188 225 446 minecraft:polished_andesite
fill 188 212 447 188 212 448 minecraft:shroomlight
fill 188 212 449 188 225 449 minecraft:polished_andesite
fill 188 212 458 188 225 458 minecraft:polished_andesite
fill 189 212 458 190 212 458 minecraft:shroomlight
fill 191 212 458 191 225 458 minecraft:polished_andesite
fill 195 212 416 195 225 416 minecraft:polished_andesite
fill 196 212 416 197 212 416 minecraft:shroomlight
fill 198 212 416 198 225 416 minecraft:polished_andesite
fill 200 212 458 200 225 458 minecraft:polished_andesite
fill 201 212 458 202 212 458 minecraft:shroomlight
fill 203 212 458 203 225 458 minecraft:polished_andesite
fill 207 212 416 207 225 416 minecraft:polished_andesite
fill 208 212 416 209 212 416 minecraft:shroomlight
fill 209 212 453 209 212 454 minecraft:orange_stained_glass
fill 210 212 416 210 225 416 minecraft:polished_andesite
fill 211 212 453 211 212 454 minecraft:orange_stained_glass
fill 211 212 457 211 213 457 minecraft:orange_stained_glass
fill 212 212 458 212 224 458 minecraft:polished_andesite
fill 213 212 458 214 212 458 minecraft:shroomlight
fill 215 212 458 215 224 458 minecraft:polished_andesite
fill 219 212 416 219 225 416 minecraft:polished_andesite
fill 220 212 416 221 212 416 minecraft:shroomlight
fill 222 212 416 222 225 416 minecraft:polished_andesite
fill 224 212 440 228 222 440 minecraft:polished_deepslate
fill 224 212 458 224 225 458 minecraft:polished_andesite
fill 225 212 458 226 212 458 minecraft:shroomlight
fill 227 212 458 227 225 458 minecraft:polished_andesite
fill 230 212 417 230 224 417 minecraft:polished_andesite
fill 230 212 418 230 212 419 minecraft:shroomlight
fill 230 212 420 230 223 420 minecraft:polished_andesite
fill 230 212 429 230 224 429 minecraft:polished_andesite
fill 230 212 430 230 212 431 minecraft:shroomlight
fill 230 212 432 230 225 432 minecraft:polished_andesite
fill 230 212 441 230 225 441 minecraft:polished_andesite
fill 230 212 442 230 212 443 minecraft:shroomlight
fill 230 212 444 230 225 444 minecraft:polished_andesite
fill 230 212 453 230 222 453 minecraft:polished_andesite
fill 230 212 454 230 212 455 minecraft:shroomlight
fill 230 212 456 230 225 456 minecraft:polished_andesite
fill 188 213 423 188 225 424 minecraft:polished_andesite
fill 188 213 435 188 225 436 minecraft:polished_andesite
fill 188 213 447 188 225 448 minecraft:polished_andesite
fill 189 213 458 190 224 458 minecraft:polished_andesite
fill 194 213 433 195 222 433 minecraft:polished_deepslate
fill 194 213 441 195 222 441 minecraft:polished_deepslate
fill 195 213 434 196 222 434 minecraft:polished_deepslate
fill 195 213 440 196 222 440 minecraft:polished_deepslate
fill 196 213 416 197 222 416 minecraft:polished_andesite
fill 196 213 435 197 222 435 minecraft:polished_deepslate
fill 196 213 439 197 222 439 minecraft:polished_deepslate
fill 197 213 436 197 222 438 minecraft:polished_deepslate
fill 201 213 458 202 225 458 minecraft:polished_andesite
fill 208 213 416 209 225 416 minecraft:polished_andesite
fill 209 213 454 211 213 454 minecraft:orange_stained_glass
fill 213 213 458 214 225 458 minecraft:polished_andesite
fill 220 213 416 221 225 416 minecraft:polished_andesite
fill 221 213 435 221 222 439 minecraft:polished_deepslate
fill 222 213 434 222 222 435 minecraft:polished_deepslate
fill 222 213 439 222 222 440 minecraft:polished_deepslate
fill 223 213 433 223 222 434 minecraft:polished_deepslate
fill 223 213 440 223 222 441 minecraft:polished_deepslate
fill 224 213 433 224 222 433 minecraft:polished_deepslate
fill 224 213 441 224 222 441 minecraft:polished_deepslate
fill 225 213 458 226 225 458 minecraft:polished_andesite
fill 230 213 418 230 223 419 minecraft:polished_andesite
fill 230 213 430 230 222 431 minecraft:polished_andesite
fill 230 213 442 230 225 443 minecraft:polished_andesite
fill 230 213 454 230 225 455 minecraft:polished_andesite
fill 189 214 433 189 221 434 minecraft:polished_deepslate
fill 190 214 432 190 221 433 minecraft:polished_deepslate
fill 190 214 441 190 221 442 minecraft:polished_deepslate
fill 191 214 432 196 221 432 minecraft:polished_deepslate
fill 191 214 442 196 221 442 minecraft:polished_deepslate
fill 192 214 431 194 221 431 minecraft:polished_deepslate
fill 192 214 443 194 221 443 minecraft:polished_deepslate
fill 196 214 433 197 221 433 minecraft:polished_deepslate
fill 196 214 441 197 221 441 minecraft:polished_deepslate
fill 197 214 434 198 221 434 minecraft:polished_deepslate
fill 197 214 440 198 221 440 minecraft:polished_deepslate
fill 198 214 435 198 221 439 minecraft:polished_deepslate
fill 199 214 436 199 221 438 minecraft:polished_deepslate
fill 209 214 456 211 214 456 minecraft:orange_stained_glass
setblock 210 214 455 minecraft:orange_stained_glass
fill 219 214 436 220 221 437 minecraft:polished_deepslate
fill 220 214 434 220 221 435 minecraft:polished_deepslate
fill 220 214 438 220 221 440 minecraft:polished_deepslate
fill 221 214 433 221 221 434 minecraft:polished_deepslate
fill 221 214 440 221 221 441 minecraft:polished_deepslate
fill 222 214 432 222 221 433 minecraft:polished_deepslate
fill 222 214 441 222 221 442 minecraft:polished_deepslate
fill 223 214 432 228 221 432 minecraft:polished_deepslate
fill 223 214 442 228 221 442 minecraft:polished_deepslate
fill 224 214 431 226 221 431 minecraft:polished_deepslate
fill 224 214 443 226 221 443 minecraft:polished_deepslate
fill 228 214 433 229 221 433 minecraft:polished_deepslate
fill 228 214 441 229 221 441 minecraft:polished_deepslate
fill 229 214 434 229 221 434 minecraft:polished_deepslate
fill 229 214 440 229 221 440 minecraft:polished_deepslate
fill 189 215 432 189 220 432 minecraft:polished_deepslate
fill 189 215 442 189 220 442 minecraft:polished_deepslate
fill 190 215 431 191 220 431 minecraft:polished_deepslate
fill 190 215 443 191 220 443 minecraft:polished_deepslate
fill 195 215 431 196 220 431 minecraft:polished_deepslate
fill 195 215 443 196 220 443 minecraft:polished_deepslate
fill 197 215 432 197 220 432 minecraft:polished_deepslate
fill 197 215 442 197 220 442 minecraft:polished_deepslate
fill 198 215 433 198 220 433 minecraft:polished_deepslate
fill 198 215 441 198 220 441 minecraft:polished_deepslate
fill 199 215 434 199 220 435 minecraft:polished_deepslate
fill 199 215 439 199 220 440 minecraft:polished_deepslate
fill 219 215 434 219 220 435 minecraft:polished_deepslate
fill 219 215 440 219 220 440 minecraft:polished_deepslate
fill 220 215 433 220 220 433 minecraft:polished_deepslate
fill 220 215 441 220 220 441 minecraft:polished_deepslate
fill 221 215 432 221 220 432 minecraft:polished_deepslate
fill 221 215 442 221 220 442 minecraft:polished_deepslate
fill 222 215 431 223 220 431 minecraft:polished_deepslate
fill 222 215 443 223 220 443 minecraft:polished_deepslate
fill 227 215 431 228 220 431 minecraft:polished_deepslate
fill 227 215 443 228 220 443 minecraft:polished_deepslate
fill 227 215 444 227 216 444 minecraft:red_wool
fill 229 215 432 229 220 432 minecraft:polished_deepslate
fill 229 215 442 229 220 442 minecraft:polished_deepslate
fill 189 216 431 189 219 431 minecraft:polished_deepslate
fill 189 216 443 189 219 443 minecraft:polished_deepslate
fill 192 216 430 194 219 430 minecraft:polished_deepslate
fill 192 216 444 194 219 444 minecraft:polished_deepslate
fill 197 216 431 197 219 431 minecraft:polished_deepslate
fill 197 216 443 197 219 443 minecraft:polished_deepslate
fill 198 216 432 198 219 432 minecraft:polished_deepslate
fill 198 216 442 198 219 442 minecraft:polished_deepslate
fill 199 216 433 199 219 433 minecraft:polished_deepslate
fill 199 216 441 199 219 441 minecraft:polished_deepslate
fill 200 216 436 200 219 438 minecraft:polished_deepslate
fill 219 216 433 219 219 433 minecraft:polished_deepslate
fill 219 216 441 219 219 441 minecraft:polished_deepslate
fill 220 216 432 220 219 432 minecraft:polished_deepslate
fill 220 216 442 220 219 442 minecraft:polished_deepslate
fill 221 216 431 221 219 431 minecraft:polished_deepslate
fill 221 216 443 221 219 443 minecraft:polished_deepslate
fill 224 216 430 226 219 430 minecraft:polished_deepslate
fill 224 216 444 226 219 444 minecraft:polished_deepslate
fill 229 216 431 229 219 431 minecraft:polished_deepslate
fill 229 216 443 229 219 443 minecraft:polished_deepslate
setblock 191 217 419 minecraft:light[level=13]
setblock 191 217 427 minecraft:light[level=13]
fill 191 217 430 191 218 430 minecraft:polished_deepslate
fill 191 217 444 191 218 444 minecraft:polished_deepslate
setblock 191 217 451 minecraft:light[level=13]
fill 195 217 430 195 218 430 minecraft:polished_deepslate
fill 195 217 444 195 218 444 minecraft:polished_deepslate
setblock 199 217 419 minecraft:light[level=13]
setblock 199 217 427 minecraft:light[level=13]
setblock 199 217 443 minecraft:light[level=13]
setblock 199 217 451 minecraft:light[level=13]
fill 200 217 435 200 218 435 minecraft:polished_deepslate
fill 200 217 439 200 218 439 minecraft:polished_deepslate
setblock 207 217 419 minecraft:light[level=13]
setblock 207 217 427 minecraft:light[level=13]
setblock 207 217 435 minecraft:light[level=13]
setblock 207 217 443 minecraft:light[level=13]
setblock 207 217 451 minecraft:light[level=13]
setblock 215 217 419 minecraft:light[level=13]
setblock 215 217 427 minecraft:light[level=13]
setblock 215 217 435 minecraft:light[level=13]
setblock 215 217 443 minecraft:light[level=13]
setblock 215 217 451 minecraft:light[level=13]
fill 218 217 435 218 218 435 minecraft:polished_deepslate
fill 219 217 438 219 221 438 minecraft:polished_deepslate
setblock 223 217 419 minecraft:light[level=13]
setblock 223 217 427 minecraft:light[level=13]
fill 223 217 430 223 218 430 minecraft:polished_deepslate
fill 223 217 444 223 218 444 minecraft:polished_deepslate
setblock 223 217 451 minecraft:light[level=13]
fill 227 217 430 227 218 430 minecraft:polished_deepslate
fill 227 217 444 227 218 444 minecraft:polished_deepslate
fill 219 218 439 219 220 439 minecraft:polished_deepslate
fill 190 219 430 191 220 430 minecraft:iron_block
fill 190 219 444 191 220 444 minecraft:iron_block
fill 195 219 430 196 220 430 minecraft:iron_block
fill 195 219 444 196 220 444 minecraft:iron_block
fill 200 219 434 200 220 435 minecraft:iron_block
fill 200 219 439 200 220 440 minecraft:iron_block
fill 218 219 434 218 220 435 minecraft:iron_block
fill 222 219 430 223 220 430 minecraft:iron_block
fill 222 219 444 223 220 444 minecraft:iron_block
fill 227 219 430 228 220 430 minecraft:iron_block
fill 227 219 444 228 220 444 minecraft:iron_block
fill 189 220 431 189 221 431 minecraft:iron_block
fill 189 220 443 189 221 443 minecraft:iron_block
fill 190 220 426 190 225 428 minecraft:polished_deepslate
fill 190 220 450 190 225 452 minecraft:polished_deepslate
fill 192 220 430 194 221 430 minecraft:iron_block
fill 192 220 444 194 221 444 minecraft:iron_block
fill 196 220 456 198 225 456 minecraft:polished_deepslate
fill 197 220 431 197 221 431 minecraft:iron_block
fill 197 220 443 197 221 443 minecraft:iron_block
fill 198 220 432 198 221 432 minecraft:iron_block
fill 198 220 442 198 221 442 minecraft:iron_block
fill 199 220 433 199 221 433 minecraft:iron_block
fill 199 220 441 199 221 441 minecraft:iron_block
fill 200 220 418 202 225 418 minecraft:polished_deepslate
fill 200 220 436 200 221 438 minecraft:iron_block
fill 208 220 456 210 225 456 minecraft:polished_deepslate
fill 212 220 418 214 225 418 minecraft:polished_deepslate
fill 219 220 433 219 221 433 minecraft:iron_block
fill 219 220 441 219 221 441 minecraft:iron_block
fill 220 220 432 220 221 432 minecraft:iron_block
fill 220 220 442 220 221 442 minecraft:iron_block
fill 220 220 456 222 225 456 minecraft:polished_deepslate
fill 221 220 431 221 221 431 minecraft:iron_block
fill 221 220 443 221 221 443 minecraft:iron_block
fill 224 220 418 226 225 418 minecraft:polished_deepslate
fill 224 220 430 226 221 430 minecraft:iron_block
fill 224 220 444 226 221 444 minecraft:iron_block
fill 228 220 426 228 225 428 minecraft:polished_deepslate
fill 228 220 450 228 225 452 minecraft:polished_deepslate
fill 229 220 431 229 221 431 minecraft:iron_block
fill 229 220 443 229 221 443 minecraft:iron_block
setblock 189 221 432 minecraft:iron_block
setblock 189 221 442 minecraft:iron_block
fill 190 221 431 191 221 431 minecraft:iron_block
fill 190 221 443 191 221 443 minecraft:iron_block
fill 195 221 431 196 221 431 minecraft:iron_block
fill 195 221 443 196 221 443 minecraft:iron_block
setblock 197 221 432 minecraft:iron_block
setblock 197 221 442 minecraft:iron_block
setblock 198 221 433 minecraft:iron_block
setblock 198 221 441 minecraft:iron_block
fill 199 221 434 199 221 435 minecraft:iron_block
fill 199 221 439 199 221 440 minecraft:iron_block
fill 219 221 434 219 221 435 minecraft:iron_block
fill 219 221 439 219 221 440 minecraft:iron_block
setblock 220 221 433 minecraft:iron_block
setblock 220 221 441 minecraft:iron_block
setblock 221 221 432 minecraft:iron_block
setblock 221 221 442 minecraft:iron_block
fill 222 221 431 223 221 431 minecraft:iron_block
fill 222 221 443 223 221 443 minecraft:iron_block
fill 227 221 431 228 221 431 minecraft:iron_block
fill 227 221 443 228 221 443 minecraft:iron_block
fill 227 221 444 227 222 444 minecraft:red_wool
setblock 229 221 432 minecraft:iron_block
setblock 229 221 442 minecraft:iron_block
fill 189 222 433 189 222 434 minecraft:iron_block
fill 190 222 432 190 222 433 minecraft:iron_block
fill 190 222 441 190 222 442 minecraft:iron_block
fill 191 222 432 196 222 432 minecraft:iron_block
fill 191 222 442 196 222 442 minecraft:iron_block
fill 192 222 431 194 222 431 minecraft:iron_block
fill 192 222 443 194 222 443 minecraft:iron_block
fill 196 222 433 197 222 433 minecraft:iron_block
fill 196 222 441 197 222 441 minecraft:iron_block
fill 197 222 434 198 222 434 minecraft:iron_block
fill 197 222 440 198 222 440 minecraft:iron_block
fill 198 222 435 198 222 439 minecraft:iron_block
fill 199 222 436 199 222 438 minecraft:iron_block
fill 219 222 436 220 222 438 minecraft:iron_block
fill 220 222 434 220 222 435 minecraft:iron_block
fill 220 222 439 220 222 440 minecraft:iron_block
fill 221 222 433 221 222 434 minecraft:iron_block
fill 221 222 440 221 222 441 minecraft:iron_block
fill 222 222 432 222 222 433 minecraft:iron_block
fill 222 222 441 222 222 442 minecraft:iron_block
fill 223 222 432 228 222 432 minecraft:iron_block
fill 223 222 442 228 222 442 minecraft:iron_block
fill 224 222 431 226 222 431 minecraft:iron_block
fill 224 222 443 226 222 443 minecraft:iron_block
setblock 227 222 443 minecraft:red_wool
fill 228 222 433 229 222 433 minecraft:iron_block
fill 228 222 441 229 222 441 minecraft:iron_block
setblock 229 222 434 minecraft:iron_block
setblock 229 222 440 minecraft:iron_block
setblock 188 223 438 minecraft:stone
fill 188 223 440 188 226 440 minecraft:polished_andesite
setblock 188 223 441 minecraft:stone
fill 188 223 442 188 223 444 minecraft:polished_andesite
setblock 188 223 453 minecraft:stone
setblock 189 223 416 minecraft:stone
fill 189 223 439 189 231 441 minecraft:polished_deepslate
fill 190 223 416 191 223 416 minecraft:polished_andesite
fill 190 223 435 190 223 437 minecraft:iron_block
fill 190 223 438 190 225 440 minecraft:polished_deepslate
fill 191 223 434 195 223 434 minecraft:iron_block
fill 191 223 435 194 223 439 minecraft:polished_deepslate
fill 191 223 440 195 223 440 minecraft:iron_block
setblock 192 223 416 minecraft:stone
setblock 196 223 416 minecraft:stone
fill 196 223 435 196 223 439 minecraft:iron_block
fill 197 223 416 197 225 416 minecraft:polished_andesite
setblock 210 223 458 minecraft:stone
fill 211 223 458 211 226 458 minecraft:polished_andesite
fill 222 223 435 222 223 439 minecraft:iron_block
fill 223 223 416 224 226 416 minecraft:polished_andesite
fill 223 223 434 227 223 434 minecraft:iron_block
fill 223 223 436 227 223 439 minecraft:polished_deepslate
fill 223 223 440 227 223 440 minecraft:iron_block
fill 224 223 435 227 223 435 minecraft:polished_deepslate
fill 225 223 416 225 224 416 minecraft:stone
fill 227 223 441 227 224 445 minecraft:iron_block
fill 228 223 435 228 223 437 minecraft:iron_block
fill 228 223 438 228 225 440 minecraft:polished_deepslate
fill 229 223 437 229 231 439 minecraft:polished_deepslate
setblock 230 223 430 minecraft:stone
fill 230 223 431 230 225 431 minecraft:polished_andesite
fill 230 223 437 230 226 437 minecraft:polished_andesite
setblock 230 223 438 minecraft:stone
fill 230 223 439 230 226 439 minecraft:polished_andesite
setblock 230 223 440 minecraft:stone
setblock 230 223 446 minecraft:stone
fill 230 223 447 230 223 452 minecraft:polished_andesite
setblock 230 223 453 minecraft:stone
fill 188 224 438 188 226 438 minecraft:polished_andesite
setblock 188 224 439 minecraft:stone
fill 188 224 441 188 226 441 minecraft:polished_andesite
setblock 188 224 442 minecraft:stone
fill 188 224 443 188 226 443 minecraft:polished_andesite
setblock 188 224 444 minecraft:stone
setblock 188 224 450 minecraft:stone
fill 188 224 451 188 226 451 minecraft:polished_andesite
fill 188 224 453 188 226 453 minecraft:polished_andesite
fill 189 224 416 189 227 416 minecraft:polished_andesite
setblock 190 224 416 minecraft:stone
fill 191 224 416 192 226 416 minecraft:polished_andesite
fill 196 224 416 196 225 416 minecraft:polished_andesite
fill 199 224 416 199 225 416 minecraft:stone
fill 200 224 416 205 226 416 minecraft:polished_andesite
fill 204 224 458 205 226 458 minecraft:polished_andesite
setblock 206 224 416 minecraft:stone
setblock 206 224 458 minecraft:stone
setblock 208 224 458 minecraft:stone
fill 209 224 458 210 227 458 minecraft:polished_andesite
setblock 211 224 416 minecraft:stone
setblock 216 224 416 minecraft:stone
fill 227 224 439 227 224 440 minecraft:iron_block
setblock 230 224 418 minecraft:stone
fill 230 224 419 230 225 419 minecraft:polished_andesite
setblock 230 224 420 minecraft:stone
fill 230 224 430 230 225 430 minecraft:polished_andesite
setblock 230 224 438 minecraft:polished_andesite
fill 230 224 440 230 226 440 minecraft:polished_andesite
fill 230 224 446 230 224 449 minecraft:polished_andesite
fill 230 224 450 230 224 451 minecraft:stone
fill 230 224 452 230 224 453 minecraft:polished_andesite
setblock 188 225 416 minecraft:stone
fill 188 225 417 188 226 417 minecraft:polished_andesite
setblock 188 225 418 minecraft:stone
fill 188 225 420 188 227 420 minecraft:polished_andesite
setblock 188 225 421 minecraft:stone
fill 188 225 439 188 226 439 minecraft:polished_andesite
fill 188 225 442 188 226 442 minecraft:polished_andesite
fill 188 225 444 188 226 444 minecraft:polished_andesite
fill 188 225 450 188 226 450 minecraft:polished_andesite
fill 189 225 420 189 225 425 minecraft:deepslate
fill 189 225 432 189 225 437 minecraft:deepslate
fill 189 225 444 189 225 449 minecraft:deepslate
fill 189 225 456 189 225 457 minecraft:deepslate
setblock 189 225 458 minecraft:stone
fill 190 225 416 190 227 416 minecraft:polished_andesite
fill 190 225 457 193 225 457 minecraft:deepslate
setblock 190 225 458 minecraft:polished_andesite
setblock 191 225 419 minecraft:light[level=13]
setblock 191 225 427 minecraft:light[level=13]
setblock 191 225 435 minecraft:light[level=13]
setblock 191 225 443 minecraft:light[level=13]
setblock 191 225 451 minecraft:light[level=13]
fill 193 225 417 198 225 417 minecraft:deepslate
setblock 195 225 458 minecraft:stone
fill 196 225 458 196 226 458 minecraft:polished_andesite
setblock 199 225 419 minecraft:light[level=13]
setblock 199 225 427 minecraft:light[level=13]
setblock 199 225 435 minecraft:light[level=13]
setblock 199 225 443 minecraft:light[level=13]
setblock 199 225 451 minecraft:light[level=13]
fill 200 225 457 205 225 457 minecraft:deepslate
fill 205 225 417 210 225 417 minecraft:deepslate
fill 206 225 416 206 226 416 minecraft:polished_andesite
fill 206 225 458 206 226 458 minecraft:polished_andesite
setblock 207 225 419 minecraft:light[level=13]
setblock 207 225 427 minecraft:light[level=13]
setblock 207 225 435 minecraft:light[level=13]
setblock 207 225 443 minecraft:light[level=13]
setblock 207 225 451 minecraft:light[level=13]
fill 208 225 458 208 227 458 minecraft:polished_andesite
fill 211 225 416 211 226 416 minecraft:polished_andesite
fill 212 225 457 217 225 457 minecraft:deepslate
setblock 212 225 458 minecraft:stone
setblock 215 225 419 minecraft:light[level=13]
setblock 215 225 427 minecraft:light[level=13]
setblock 215 225 435 minecraft:light[level=13]
setblock 215 225 443 minecraft:light[level=13]
setblock 215 225 451 minecraft:light[level=13]
fill 215 225 458 216 225 458 minecraft:stone
fill 216 225 416 216 226 416 minecraft:polished_andesite
fill 217 225 417 222 225 417 minecraft:deepslate
fill 217 225 458 223 226 458 minecraft:polished_andesite
setblock 223 225 419 minecraft:light[level=13]
setblock 223 225 427 minecraft:light[level=13]
setblock 223 225 435 minecraft:light[level=13]
setblock 223 225 443 minecraft:light[level=13]
setblock 223 225 451 minecraft:light[level=13]
fill 224 225 457 229 225 457 minecraft:deepslate
fill 225 225 416 227 226 416 minecraft:polished_andesite
fill 228 225 416 230 225 416 minecraft:stone
fill 229 225 417 229 225 422 minecraft:deepslate
fill 229 225 429 229 225 434 minecraft:deepslate
fill 229 225 441 229 225 446 minecraft:deepslate
fill 229 225 453 229 225 456 minecraft:deepslate
setblock 230 225 417 minecraft:stone
setblock 230 225 418 minecraft:polished_andesite
setblock 230 225 420 minecraft:polished_andesite
fill 230 225 424 230 226 424 minecraft:polished_andesite
setblock 230 225 425 minecraft:stone
fill 230 225 426 230 226 428 minecraft:polished_andesite
setblock 230 225 429 minecraft:stone
setblock 230 225 438 minecraft:stone
fill 230 225 446 230 226 446 minecraft:polished_andesite
fill 230 225 447 230 225 448 minecraft:stone
fill 230 225 449 230 226 451 minecraft:polished_andesite
setblock 230 225 452 minecraft:stone
setblock 230 225 453 minecraft:polished_andesite
fill 188 226 416 188 227 416 minecraft:polished_andesite
setblock 188 226 418 minecraft:polished_andesite
setblock 188 226 421 minecraft:polished_andesite
fill 188 226 422 188 231 425 minecraft:shroomlight
fill 188 226 434 188 231 437 minecraft:shroomlight
fill 188 226 446 188 231 449 minecraft:shroomlight
fill 188 226 458 191 231 458 minecraft:shroomlight
fill 195 226 416 198 231 416 minecraft:shroomlight
setblock 195 226 458 minecraft:polished_andesite
fill 199 226 416 199 227 416 minecraft:polished_andesite
fill 200 226 458 203 231 458 minecraft:shroomlight
fill 207 226 416 210 231 416 minecraft:shroomlight
fill 212 226 458 215 231 458 minecraft:shroomlight
setblock 216 226 458 minecraft:polished_andesite
fill 219 226 416 222 231 416 minecraft:shroomlight
fill 224 226 458 227 231 458 minecraft:shroomlight
fill 228 226 416 230 226 416 minecraft:polished_andesite
fill 230 226 417 230 231 420 minecraft:shroomlight
setblock 230 226 425 minecraft:polished_andesite
fill 230 226 429 230 231 432 minecraft:shroomlight
setblock 230 226 438 minecraft:polished_andesite
fill 230 226 441 230 231 444 minecraft:shroomlight
fill 230 226 447 230 226 448 minecraft:polished_andesite
setblock 230 226 452 minecraft:polished_andesite
fill 230 226 453 230 231 456 minecraft:shroomlight
fill 188 227 417 188 307 419 minecraft:stone
fill 188 227 421 188 228 421 minecraft:stone
fill 188 227 426 188 227 428 minecraft:stone
fill 188 227 430 188 307 433 minecraft:stone
fill 188 227 438 188 228 445 minecraft:stone
fill 188 227 450 188 228 457 minecraft:stone
setblock 191 227 416 minecraft:polished_andesite
fill 192 227 416 194 307 416 minecraft:stone
fill 192 227 458 199 307 458 minecraft:stone
fill 200 227 416 206 227 416 minecraft:stone
fill 204 227 458 207 307 458 minecraft:stone
fill 211 227 416 218 228 416 minecraft:stone
setblock 211 227 458 minecraft:stone
fill 216 227 458 223 227 458 minecraft:stone
fill 223 227 416 224 307 416 minecraft:stone
setblock 225 227 416 minecraft:polished_andesite
fill 226 227 416 227 307 416 minecraft:stone
setblock 228 227 416 minecraft:polished_andesite
fill 228 227 458 230 307 458 minecraft:stone
fill 229 227 416 229 307 416 minecraft:stone
setblock 230 227 416 minecraft:polished_andesite
setblock 230 227 421 minecraft:stone
setblock 230 227 422 minecraft:polished_andesite
fill 230 227 424 230 228 427 minecraft:stone
fill 230 227 428 230 228 428 minecraft:polished_andesite
fill 230 227 433 230 307 434 minecraft:stone
fill 230 227 436 230 307 440 minecraft:stone
fill 230 227 446 230 228 452 minecraft:stone
fill 230 227 457 230 307 457 minecraft:stone
fill 188 228 416 191 228 416 minecraft:stone
fill 188 228 420 188 307 420 minecraft:stone
setblock 188 228 426 minecraft:polished_andesite
fill 188 228 427 188 307 429 minecraft:stone
fill 189 228 445 191 229 445 minecraft:iron_block
fill 199 228 416 203 228 416 minecraft:stone
fill 204 228 416 205 228 416 minecraft:polished_andesite
fill 206 228 416 206 307 416 minecraft:stone
fill 208 228 458 210 228 458 minecraft:stone
setblock 211 228 458 minecraft:polished_andesite
setblock 216 228 458 minecraft:polished_andesite
fill 217 228 458 223 307 458 minecraft:stone
fill 225 228 416 225 307 416 minecraft:stone
fill 228 228 416 228 307 416 minecraft:stone
fill 230 228 416 230 307 416 minecraft:stone
setblock 230 228 421 minecraft:polished_andesite
fill 230 228 422 230 228 423 minecraft:stone
fill 230 228 435 230 307 435 minecraft:stone
fill 230 228 445 230 307 445 minecraft:stone
setblock 188 229 416 minecraft:polished_andesite
setblock 188 229 421 minecraft:polished_andesite
fill 188 229 426 188 307 426 minecraft:stone
fill 188 229 438 188 307 444 minecraft:stone
setblock 188 229 445 minecraft:polished_andesite
fill 188 229 450 188 307 454 minecraft:stone
fill 188 229 455 188 229 456 minecraft:polished_andesite
fill 188 229 457 188 307 457 minecraft:stone
fill 189 229 416 189 307 416 minecraft:stone
setblock 190 229 416 minecraft:polished_andesite
fill 191 229 416 191 307 416 minecraft:stone
setblock 199 229 416 minecraft:polished_andesite
fill 200 229 416 203 307 416 minecraft:stone
setblock 204 229 416 minecraft:polished_andesite
fill 205 229 416 205 307 416 minecraft:stone
fill 208 229 458 208 307 458 minecraft:stone
setblock 209 229 458 minecraft:polished_andesite
fill 210 229 458 211 307 458 minecraft:stone
fill 211 229 416 216 307 416 minecraft:stone
fill 216 229 458 216 307 458 minecraft:stone
setblock 217 229 416 minecraft:polished_andesite
fill 218 229 416 218 307 416 minecraft:stone
fill 230 229 421 230 307 422 minecraft:stone
setblock 230 229 423 minecraft:polished_andesite
fill 230 229 424 230 307 424 minecraft:stone
setblock 230 229 425 minecraft:polished_andesite
fill 230 229 426 230 307 428 minecraft:stone
fill 230 229 446 230 307 450 minecraft:stone
setblock 230 229 451 minecraft:polished_andesite
fill 230 229 452 230 307 452 minecraft:stone
fill 188 230 416 188 307 416 minecraft:stone
fill 188 230 421 188 307 421 minecraft:stone
fill 188 230 445 188 307 445 minecraft:stone
fill 188 230 455 188 307 456 minecraft:stone
fill 190 230 416 190 307 416 minecraft:stone
fill 199 230 416 199 307 416 minecraft:stone
fill 204 230 416 204 307 416 minecraft:stone
fill 209 230 458 209 307 458 minecraft:stone
fill 217 230 416 217 307 416 minecraft:stone
fill 230 230 423 230 307 423 minecraft:stone
fill 230 230 425 230 307 425 minecraft:stone
fill 230 230 451 230 307 451 minecraft:stone
fill 188 232 422 188 245 425 minecraft:stone
fill 188 232 434 188 245 437 minecraft:stone
fill 188 232 446 188 245 449 minecraft:stone
fill 188 232 458 191 245 458 minecraft:stone
fill 195 232 416 198 245 416 minecraft:stone
fill 200 232 458 203 245 458 minecraft:stone
fill 207 232 416 210 245 416 minecraft:stone
fill 212 232 458 215 245 458 minecraft:stone
fill 219 232 416 222 245 416 minecraft:stone
fill 224 232 458 227 245 458 minecraft:stone
fill 230 232 417 230 245 420 minecraft:stone
fill 230 232 429 230 245 432 minecraft:stone
fill 230 232 441 230 245 444 minecraft:stone
fill 230 232 453 230 245 456 minecraft:stone
setblock 191 233 419 minecraft:light[level=13]
setblock 191 233 427 minecraft:light[level=13]
setblock 191 233 435 minecraft:light[level=13]
setblock 191 233 443 minecraft:light[level=13]
setblock 191 233 451 minecraft:light[level=13]
setblock 199 233 419 minecraft:light[level=13]
setblock 199 233 427 minecraft:light[level=13]
setblock 199 233 435 minecraft:light[level=13]
setblock 199 233 443 minecraft:light[level=13]
setblock 199 233 451 minecraft:light[level=13]
setblock 207 233 419 minecraft:light[level=13]
setblock 207 233 427 minecraft:light[level=13]
setblock 207 233 435 minecraft:light[level=13]
setblock 207 233 443 minecraft:light[level=13]
setblock 207 233 451 minecraft:light[level=13]
setblock 215 233 419 minecraft:light[level=13]
setblock 215 233 427 minecraft:light[level=13]
setblock 215 233 435 minecraft:light[level=13]
setblock 215 233 443 minecraft:light[level=13]
setblock 215 233 451 minecraft:light[level=13]
setblock 223 233 419 minecraft:light[level=13]
setblock 223 233 427 minecraft:light[level=13]
setblock 223 233 435 minecraft:light[level=13]
setblock 223 233 443 minecraft:light[level=13]
setblock 223 233 451 minecraft:light[level=13]
fill 201 237 438 212 237 438 minecraft:polished_deepslate
fill 202 237 434 202 238 435 minecraft:polished_deepslate
fill 202 237 437 212 237 437 minecraft:polished_deepslate
fill 202 237 440 213 237 440 minecraft:polished_deepslate
fill 202 237 443 203 238 443 minecraft:polished_deepslate
fill 203 237 432 225 237 432 minecraft:polished_deepslate
fill 203 237 435 226 237 435 minecraft:polished_deepslate
fill 203 237 442 226 237 442 minecraft:polished_deepslate
fill 203 237 445 224 237 445 minecraft:polished_deepslate
fill 204 237 430 223 237 430 minecraft:polished_deepslate
fill 204 237 433 225 237 434 minecraft:polished_deepslate
fill 204 237 436 213 237 436 minecraft:polished_deepslate
fill 204 237 439 212 237 439 minecraft:polished_deepslate
fill 204 237 441 228 237 441 minecraft:polished_deepslate
fill 205 237 429 205 238 429 minecraft:polished_deepslate
fill 205 237 443 226 237 444 minecraft:polished_deepslate
fill 206 237 428 207 238 428 minecraft:polished_deepslate
fill 206 237 431 227 237 431 minecraft:polished_deepslate
fill 206 237 447 206 238 447 minecraft:polished_deepslate
fill 207 237 427 207 238 427 minecraft:polished_deepslate
fill 207 237 429 222 237 429 minecraft:polished_deepslate
fill 207 237 446 226 237 446 minecraft:polished_deepslate
fill 208 237 447 208 238 450 minecraft:polished_deepslate
fill 209 237 426 209 238 428 minecraft:polished_deepslate
fill 209 237 447 221 238 448 minecraft:polished_deepslate
fill 210 237 427 219 238 428 minecraft:polished_deepslate
fill 210 237 450 210 238 451 minecraft:polished_deepslate
fill 211 237 425 212 238 425 minecraft:polished_deepslate
fill 211 237 449 211 238 450 minecraft:polished_deepslate
fill 212 237 426 212 238 426 minecraft:polished_deepslate
fill 212 237 449 221 238 449 minecraft:polished_deepslate
fill 213 237 450 213 238 451 minecraft:polished_deepslate
fill 214 237 425 214 238 426 minecraft:polished_deepslate
fill 215 237 426 215 238 426 minecraft:polished_deepslate
fill 215 237 450 216 238 450 minecraft:polished_deepslate
fill 216 237 451 216 238 451 minecraft:polished_deepslate
fill 217 237 425 217 238 426 minecraft:polished_deepslate
fill 217 237 436 228 237 436 minecraft:polished_deepslate
fill 217 237 440 226 237 440 minecraft:polished_deepslate
fill 218 237 437 226 237 439 minecraft:polished_deepslate
fill 218 237 450 218 238 451 minecraft:polished_deepslate
fill 219 237 426 220 238 426 minecraft:polished_deepslate
fill 219 237 451 219 238 451 minecraft:polished_deepslate
fill 220 237 425 220 238 425 minecraft:polished_deepslate
fill 220 237 428 222 238 428 minecraft:polished_deepslate
fill 221 237 450 221 238 450 minecraft:polished_deepslate
fill 222 237 426 222 238 427 minecraft:polished_deepslate
fill 222 237 447 223 238 447 minecraft:polished_deepslate
fill 223 237 448 223 238 449 minecraft:polished_deepslate
fill 224 237 429 224 238 429 minecraft:polished_deepslate
fill 224 237 448 224 238 448 minecraft:polished_deepslate
fill 225 237 447 225 238 447 minecraft:polished_deepslate
fill 226 237 434 227 238 434 minecraft:polished_deepslate
fill 227 237 433 228 238 433 minecraft:polished_deepslate
fill 227 237 438 228 238 439 minecraft:polished_deepslate
fill 227 237 444 227 238 444 minecraft:polished_deepslate
fill 228 237 442 228 238 442 minecraft:polished_deepslate
fill 229 237 438 229 238 438 minecraft:polished_deepslate
fill 189 238 417 200 238 457 minecraft:deepslate
fill 201 238 417 201 238 437 minecraft:deepslate
fill 201 238 438 211 238 438 minecraft:polished_deepslate
fill 201 238 439 201 238 457 minecraft:deepslate
fill 202 238 417 202 238 433 minecraft:deepslate
fill 202 238 436 203 238 436 minecraft:deepslate
fill 202 238 437 211 238 437 minecraft:polished_deepslate
fill 202 238 439 203 238 439 minecraft:deepslate
fill 202 238 440 205 238 440 minecraft:polished_deepslate
fill 202 238 441 202 238 442 minecraft:deepslate
fill 202 238 444 202 238 457 minecraft:deepslate
fill 203 238 417 203 238 431 minecraft:deepslate
fill 203 238 432 211 238 432 minecraft:polished_deepslate
fill 203 238 433 203 238 434 minecraft:deepslate
fill 203 238 435 212 238 435 minecraft:polished_deepslate
setblock 203 238 441 minecraft:deepslate
fill 203 238 442 206 238 442 minecraft:polished_deepslate
fill 203 238 444 204 238 444 minecraft:deepslate
fill 203 238 445 208 238 445 minecraft:polished_deepslate
fill 203 238 446 205 238 457 minecraft:deepslate
fill 204 238 417 204 238 429 minecraft:deepslate
fill 204 238 430 210 238 430 minecraft:polished_deepslate
fill 204 238 431 205 238 431 minecraft:deepslate
fill 204 238 433 212 238 434 minecraft:polished_deepslate
fill 204 238 436 211 238 436 minecraft:polished_deepslate
fill 204 238 439 205 238 439 minecraft:polished_deepslate
fill 204 238 441 205 238 441 minecraft:polished_deepslate
setblock 204 238 443 minecraft:deepslate
fill 205 238 417 205 238 428 minecraft:deepslate
fill 205 238 443 206 238 444 minecraft:polished_deepslate
fill 206 238 417 206 238 427 minecraft:deepslate
setblock 206 238 429 minecraft:deepslate
fill 206 238 431 210 238 431 minecraft:polished_deepslate
fill 206 238 439 211 238 441 minecraft:gold_block
setblock 206 238 446 minecraft:deepslate
fill 206 238 448 207 238 457 minecraft:deepslate
fill 207 238 417 208 238 426 minecraft:deepslate
fill 207 238 429 211 238 429 minecraft:polished_deepslate
fill 207 238 442 212 238 443 minecraft:gold_block
setblock 207 238 444 minecraft:polished_deepslate
fill 207 238 446 209 238 446 minecraft:polished_deepslate
setblock 207 238 447 minecraft:deepslate
fill 208 238 427 208 238 428 minecraft:deepslate
fill 208 238 444 211 238 444 minecraft:gold_block
fill 208 238 451 209 238 457 minecraft:deepslate
fill 209 238 417 210 238 425 minecraft:deepslate
fill 209 238 445 210 238 445 minecraft:gold_block
fill 209 238 449 209 238 450 minecraft:deepslate
fill 210 238 426 211 238 426 minecraft:deepslate
setblock 210 238 446 minecraft:gold_block
setblock 210 238 449 minecraft:deepslate
fill 210 238 452 229 238 457 minecraft:deepslate
fill 211 238 417 229 238 424 minecraft:deepslate
fill 211 238 430 219 238 431 minecraft:gold_block
fill 211 238 445 219 238 446 minecraft:polished_deepslate
fill 211 238 451 212 238 451 minecraft:deepslate
fill 212 238 429 218 238 429 minecraft:gold_block
fill 212 238 432 218 238 432 minecraft:gold_block
setblock 212 238 436 minecraft:shroomlight
fill 212 238 437 212 238 439 minecraft:ochre_froglight
setblock 212 238 440 minecraft:shroomlight
setblock 212 238 441 minecraft:gold_block
fill 212 238 444 218 238 444 minecraft:polished_deepslate
setblock 212 238 450 minecraft:deepslate
fill 213 238 425 213 238 426 minecraft:deepslate
fill 213 238 433 217 238 434 minecraft:gold_block
setblock 213 238 435 minecraft:shroomlight
setblock 213 238 436 minecraft:ochre_froglight
setblock 213 238 440 minecraft:ochre_froglight
setblock 213 238 441 minecraft:shroomlight
fill 213 238 442 217 238 443 minecraft:polished_deepslate
fill 214 238 435 216 238 435 minecraft:ochre_froglight
fill 214 238 441 216 238 441 minecraft:ochre_froglight
fill 214 238 450 214 238 451 minecraft:deepslate
fill 215 238 425 216 238 425 minecraft:deepslate
setblock 215 238 451 minecraft:deepslate
setblock 216 238 426 minecraft:deepslate
setblock 217 238 435 minecraft:shroomlight
setblock 217 238 436 minecraft:ochre_froglight
setblock 217 238 440 minecraft:ochre_froglight
setblock 217 238 441 minecraft:shroomlight
fill 217 238 450 217 238 451 minecraft:deepslate
fill 218 238 425 218 238 426 minecraft:deepslate
fill 218 238 433 225 238 435 minecraft:polished_deepslate
setblock 218 238 436 minecraft:shroomlight
fill 218 238 437 218 238 439 minecraft:ochre_froglight
setblock 218 238 440 minecraft:shroomlight
fill 218 238 441 223 238 443 minecraft:gold_block
setblock 219 238 425 minecraft:deepslate
fill 219 238 429 222 238 429 minecraft:polished_deepslate
fill 219 238 432 225 238 432 minecraft:polished_deepslate
fill 219 238 436 226 238 437 minecraft:polished_deepslate
fill 219 238 438 224 238 440 minecraft:gold_block
fill 219 238 444 222 238 444 minecraft:gold_block
fill 219 238 450 220 238 450 minecraft:deepslate
fill 220 238 427 221 238 427 minecraft:deepslate
fill 220 238 430 223 238 431 minecraft:polished_deepslate
fill 220 238 445 220 238 446 minecraft:gold_block
fill 220 238 451 229 238 451 minecraft:deepslate
fill 221 238 425 221 238 426 minecraft:deepslate
setblock 221 238 445 minecraft:gold_block
fill 221 238 446 226 238 446 minecraft:polished_deepslate
fill 222 238 425 229 238 425 minecraft:deepslate
fill 222 238 445 224 238 445 minecraft:polished_deepslate
fill 222 238 448 222 238 450 minecraft:deepslate
fill 223 238 426 223 238 429 minecraft:deepslate
fill 223 238 444 226 238 444 minecraft:polished_deepslate
fill 223 238 450 229 238 450 minecraft:deepslate
fill 224 238 426 229 238 428 minecraft:deepslate
fill 224 238 430 229 238 430 minecraft:deepslate
fill 224 238 431 227 238 431 minecraft:polished_deepslate
setblock 224 238 441 minecraft:gold_block
fill 224 238 442 226 238 443 minecraft:polished_deepslate
setblock 224 238 447 minecraft:deepslate
fill 224 238 449 229 238 449 minecraft:deepslate
fill 225 238 429 229 238 429 minecraft:deepslate
fill 225 238 438 226 238 441 minecraft:polished_deepslate
fill 225 238 445 229 238 445 minecraft:deepslate
fill 225 238 448 229 238 448 minecraft:deepslate
fill 226 238 432 226 238 433 minecraft:deepslate
setblock 226 238 435 minecraft:polished_deepslate
fill 226 238 447 229 238 447 minecraft:deepslate
fill 227 238 432 229 238 432 minecraft:deepslate
fill 227 238 435 229 238 435 minecraft:deepslate
fill 227 238 436 228 238 436 minecraft:polished_deepslate
fill 227 238 437 229 238 437 minecraft:deepslate
fill 227 238 440 229 238 440 minecraft:deepslate
fill 227 238 441 228 238 441 minecraft:polished_deepslate
fill 227 238 442 227 238 443 minecraft:deepslate
fill 227 238 446 229 238 446 minecraft:deepslate
fill 228 238 431 229 238 431 minecraft:deepslate
fill 228 238 434 229 238 434 minecraft:deepslate
fill 228 238 443 229 238 444 minecraft:deepslate
setblock 229 238 433 minecraft:deepslate
setblock 229 238 436 minecraft:deepslate
setblock 229 238 439 minecraft:deepslate
fill 229 238 441 229 238 442 minecraft:deepslate
fill 206 239 429 206 240 429 minecraft:bone_block
fill 206 239 438 206 245 438 minecraft:bone_block
fill 206 239 447 206 240 447 minecraft:bone_block
fill 209 239 429 209 240 429 minecraft:bone_block
fill 209 239 438 209 245 438 minecraft:bone_block
fill 209 239 447 209 240 447 minecraft:bone_block
fill 212 239 429 212 240 429 minecraft:bone_block
fill 212 239 438 212 245 438 minecraft:bone_block
fill 212 239 447 212 240 447 minecraft:bone_block
fill 215 239 429 215 240 429 minecraft:bone_block
fill 215 239 447 215 240 447 minecraft:bone_block
fill 218 239 429 218 240 429 minecraft:bone_block
fill 218 239 438 218 245 438 minecraft:bone_block
fill 218 239 447 218 240 447 minecraft:bone_block
fill 221 239 429 221 240 429 minecraft:bone_block
fill 221 239 438 221 245 438 minecraft:bone_block
fill 221 239 447 221 240 447 minecraft:bone_block
fill 224 239 429 224 240 429 minecraft:bone_block
fill 224 239 438 224 245 438 minecraft:bone_block
fill 224 239 447 224 240 447 minecraft:bone_block
setblock 191 241 419 minecraft:light[level=13]
setblock 191 241 427 minecraft:light[level=13]
setblock 191 241 435 minecraft:light[level=13]
setblock 191 241 443 minecraft:light[level=13]
setblock 191 241 451 minecraft:light[level=13]
setblock 199 241 419 minecraft:light[level=13]
setblock 199 241 427 minecraft:light[level=13]
setblock 199 241 435 minecraft:light[level=13]
setblock 199 241 443 minecraft:light[level=13]
setblock 199 241 451 minecraft:light[level=13]
fill 206 241 430 206 242 430 minecraft:bone_block
fill 206 241 446 206 242 446 minecraft:bone_block
setblock 207 241 419 minecraft:light[level=13]
setblock 207 241 427 minecraft:light[level=13]
setblock 207 241 435 minecraft:light[level=13]
setblock 207 241 443 minecraft:light[level=13]
setblock 207 241 451 minecraft:light[level=13]
fill 209 241 430 209 242 430 minecraft:bone_block
fill 209 241 446 209 242 446 minecraft:bone_block
fill 212 241 430 212 242 430 minecraft:bone_block
fill 212 241 446 212 242 446 minecraft:bone_block
setblock 215 241 419 minecraft:light[level=13]
setblock 215 241 427 minecraft:light[level=13]
fill 215 241 430 215 242 430 minecraft:bone_block
setblock 215 241 435 minecraft:light[level=13]
setblock 215 241 443 minecraft:light[level=13]
fill 215 241 446 215 242 446 minecraft:bone_block
setblock 215 241 451 minecraft:light[level=13]
fill 218 241 430 218 242 430 minecraft:bone_block
fill 218 241 446 218 242 446 minecraft:bone_block
fill 221 241 430 221 242 430 minecraft:bone_block
fill 221 241 446 221 242 446 minecraft:bone_block
setblock 223 241 419 minecraft:light[level=13]
setblock 223 241 427 minecraft:light[level=13]
setblock 223 241 435 minecraft:light[level=13]
setblock 223 241 443 minecraft:light[level=13]
setblock 223 241 451 minecraft:light[level=13]
fill 224 241 430 224 242 430 minecraft:bone_block
fill 224 241 446 224 242 446 minecraft:bone_block
fill 189 242 417 191 269 417 minecraft:polished_deepslate
fill 189 242 427 189 269 429 minecraft:polished_deepslate
fill 189 242 439 189 269 441 minecraft:polished_deepslate
fill 189 242 451 189 269 453 minecraft:polished_deepslate
fill 190 242 426 190 245 428 minecraft:polished_deepslate
fill 190 242 438 190 245 440 minecraft:polished_deepslate
fill 190 242 450 190 245 452 minecraft:polished_deepslate
fill 195 242 457 197 269 457 minecraft:polished_deepslate
fill 196 242 456 198 245 456 minecraft:polished_deepslate
fill 200 242 418 202 245 418 minecraft:polished_deepslate
fill 201 242 417 203 269 417 minecraft:polished_deepslate
fill 207 242 457 209 269 457 minecraft:polished_deepslate
fill 208 242 456 210 245 456 minecraft:polished_deepslate
fill 212 242 418 214 245 418 minecraft:polished_deepslate
fill 213 242 417 215 269 417 minecraft:polished_deepslate
fill 219 242 457 221 269 457 minecraft:polished_deepslate
fill 220 242 456 222 245 456 minecraft:polished_deepslate
fill 224 242 418 226 245 418 minecraft:polished_deepslate
fill 225 242 417 227 269 417 minecraft:polished_deepslate
fill 228 242 426 228 245 428 minecraft:polished_deepslate
fill 228 242 438 228 245 440 minecraft:polished_deepslate
fill 228 242 450 228 245 452 minecraft:polished_deepslate
fill 229 242 425 229 269 427 minecraft:polished_deepslate
fill 229 242 437 229 269 439 minecraft:polished_deepslate
fill 229 242 449 229 269 451 minecraft:polished_deepslate
fill 201 243 436 202 249 439 minecraft:bone_block
fill 203 243 438 203 250 439 minecraft:bone_block
fill 204 243 438 204 250 438 minecraft:bone_block
fill 206 243 431 206 244 431 minecraft:bone_block
fill 206 243 445 206 244 445 minecraft:bone_block
fill 209 243 431 209 244 431 minecraft:bone_block
fill 209 243 445 209 244 445 minecraft:bone_block
fill 212 243 431 212 244 431 minecraft:bone_block
fill 212 243 445 212 244 445 minecraft:bone_block
fill 215 243 431 215 244 431 minecraft:bone_block
fill 215 243 445 215 244 445 minecraft:bone_block
fill 215 243 456 215 246 456 minecraft:orange_stained_glass
fill 218 243 431 218 244 431 minecraft:bone_block
fill 218 243 445 218 244 445 minecraft:bone_block
fill 221 243 431 221 244 431 minecraft:bone_block
fill 221 243 445 221 244 445 minecraft:bone_block
fill 224 243 431 224 244 431 minecraft:bone_block
fill 224 243 445 224 244 445 minecraft:bone_block
fill 200 244 436 200 249 440 minecraft:bone_block
fill 201 244 435 203 248 435 minecraft:bone_block
fill 201 244 440 203 248 441 minecraft:bone_block
fill 203 244 436 204 248 437 minecraft:bone_block
fill 204 244 439 204 249 440 minecraft:bone_block
fill 206 244 432 206 246 432 minecraft:bone_block
fill 206 244 444 206 246 444 minecraft:bone_block
fill 209 244 432 209 246 432 minecraft:bone_block
fill 209 244 444 209 246 444 minecraft:bone_block
fill 212 244 432 212 246 432 minecraft:bone_block
fill 212 244 444 212 246 444 minecraft:bone_block
fill 214 244 455 214 244 457 minecraft:orange_stained_glass
fill 215 244 432 215 246 432 minecraft:bone_block
fill 215 244 444 215 246 444 minecraft:bone_block
fill 215 244 454 215 246 455 minecraft:orange_stained_glass
fill 215 244 457 216 244 457 minecraft:orange_stained_glass
fill 216 244 455 216 245 456 minecraft:orange_stained_glass
fill 218 244 432 218 246 432 minecraft:bone_block
fill 218 244 444 218 246 444 minecraft:bone_block
fill 221 244 432 221 246 432 minecraft:bone_block
fill 221 244 444 221 246 444 minecraft:bone_block
fill 224 244 432 224 246 432 minecraft:bone_block
fill 224 244 444 224 246 444 minecraft:bone_block
fill 189 245 420 189 245 425 minecraft:deepslate
fill 189 245 432 189 245 437 minecraft:deepslate
fill 189 245 444 189 245 449 minecraft:deepslate
fill 189 245 456 189 245 457 minecraft:deepslate
fill 190 245 457 193 245 457 minecraft:deepslate
fill 193 245 417 198 245 417 minecraft:deepslate
fill 199 245 437 199 248 440 minecraft:bone_block
fill 200 245 435 200 248 435 minecraft:bone_block
fill 200 245 441 200 247 441 minecraft:bone_block
fill 200 245 457 205 245 457 minecraft:deepslate
fill 202 245 442 202 247 442 minecraft:bone_block
fill 204 245 435 204 247 435 minecraft:bone_block
fill 204 245 441 204 248 441 minecraft:bone_block
fill 205 245 417 210 245 417 minecraft:deepslate
fill 205 245 436 205 248 439 minecraft:bone_block
fill 206 245 437 206 248 437 minecraft:bone_block
fill 206 245 439 206 248 439 minecraft:bone_block
fill 209 245 437 209 248 437 minecraft:bone_block
fill 209 245 439 209 248 439 minecraft:bone_block
fill 212 245 437 212 248 437 minecraft:bone_block
fill 212 245 439 212 248 439 minecraft:bone_block
fill 212 245 457 217 245 457 minecraft:deepslate
fill 214 245 454 214 245 456 minecraft:orange_stained_glass
fill 215 245 437 215 245 439 minecraft:bone_block
fill 215 245 453 215 247 453 minecraft:orange_stained_glass
fill 216 245 454 216 246 454 minecraft:orange_stained_glass
fill 217 245 417 222 245 417 minecraft:deepslate
fill 218 245 437 218 248 437 minecraft:bone_block
fill 218 245 439 218 248 439 minecraft:bone_block
fill 221 245 437 221 248 437 minecraft:bone_block
fill 221 245 439 221 248 439 minecraft:bone_block
fill 224 245 437 224 248 437 minecraft:bone_block
fill 224 245 439 224 248 439 minecraft:bone_block
fill 224 245 457 229 245 457 minecraft:deepslate
fill 229 245 417 229 245 422 minecraft:deepslate
fill 229 245 429 229 245 434 minecraft:deepslate
fill 229 245 441 229 245 446 minecraft:deepslate
fill 229 245 453 229 245 456 minecraft:deepslate
fill 188 246 422 188 251 425 minecraft:shroomlight
fill 188 246 434 188 251 437 minecraft:shroomlight
fill 188 246 446 188 251 449 minecraft:shroomlight
fill 188 246 458 191 251 458 minecraft:shroomlight
fill 195 246 416 198 251 416 minecraft:shroomlight
fill 198 246 438 198 247 438 minecraft:bone_block
fill 199 246 436 199 248 436 minecraft:bone_block
fill 200 246 458 203 251 458 minecraft:shroomlight
setblock 201 246 442 minecraft:bone_block
fill 202 246 434 203 246 434 minecraft:bone_block
setblock 203 246 442 minecraft:bone_block
setblock 205 246 435 minecraft:bone_block
fill 205 246 440 205 248 440 minecraft:bone_block
fill 206 246 433 206 247 433 minecraft:bone_block
fill 206 246 443 206 247 443 minecraft:bone_block
fill 207 246 416 210 251 416 minecraft:shroomlight
fill 209 246 433 209 247 433 minecraft:bone_block
fill 209 246 443 209 247 443 minecraft:bone_block
fill 212 246 433 212 247 433 minecraft:bone_block
fill 212 246 443 212 247 443 minecraft:bone_block
fill 212 246 458 215 251 458 minecraft:shroomlight
fill 214 246 453 214 246 455 minecraft:orange_stained_glass
fill 215 246 433 215 247 433 minecraft:bone_block
fill 215 246 437 215 248 437 minecraft:bone_block
fill 215 246 439 215 248 439 minecraft:bone_block
fill 215 246 443 215 247 443 minecraft:bone_block
fill 215 246 451 215 247 452 minecraft:orange_stained_glass
setblock 216 246 453 minecraft:orange_stained_glass
setblock 216 246 455 minecraft:orange_stained_glass
fill 218 246 433 218 247 433 minecraft:bone_block
fill 218 246 443 218 247 443 minecraft:bone_block
fill 219 246 416 222 251 416 minecraft:shroomlight
fill 221 246 433 221 247 433 minecraft:bone_block
fill 221 246 443 221 247 443 minecraft:bone_block
fill 224 246 433 224 247 433 minecraft:bone_block
fill 224 246 443 224 247 443 minecraft:bone_block
fill 224 246 458 227 251 458 minecraft:shroomlight
fill 230 246 417 230 251 420 minecraft:shroomlight
fill 230 246 429 230 251 432 minecraft:shroomlight
fill 230 246 441 230 251 444 minecraft:shroomlight
fill 230 246 453 230 251 456 minecraft:shroomlight
fill 206 247 434 206 248 434 minecraft:bone_block
fill 206 247 442 206 248 442 minecraft:bone_block
fill 209 247 434 209 248 434 minecraft:bone_block
fill 209 247 442 209 248 442 minecraft:bone_block
fill 212 247 434 212 248 434 minecraft:bone_block
fill 212 247 442 212 248 442 minecraft:bone_block
fill 215 247 434 215 248 434 minecraft:bone_block
fill 215 247 442 215 248 442 minecraft:bone_block
setblock 215 247 450 minecraft:orange_stained_glass
fill 218 247 434 218 248 434 minecraft:bone_block
fill 218 247 442 218 248 442 minecraft:bone_block
fill 221 247 434 221 248 434 minecraft:bone_block
fill 221 247 442 221 248 442 minecraft:bone_block
fill 224 247 434 224 248 434 minecraft:bone_block
fill 224 247 442 224 248 442 minecraft:bone_block
fill 206 248 435 206 248 436 minecraft:bone_block
fill 206 248 438 212 249 438 minecraft:bone_block
fill 206 248 440 206 248 441 minecraft:bone_block
fill 209 248 435 209 248 436 minecraft:bone_block
fill 209 248 440 209 248 441 minecraft:bone_block
fill 212 248 435 212 248 436 minecraft:bone_block
fill 212 248 440 212 248 441 minecraft:bone_block
fill 215 248 435 215 248 436 minecraft:bone_block
fill 215 248 438 226 249 438 minecraft:bone_block
fill 215 248 440 215 248 441 minecraft:bone_block
setblock 215 248 449 minecraft:orange_stained_glass
fill 218 248 435 218 248 436 minecraft:bone_block
fill 218 248 440 218 248 441 minecraft:bone_block
fill 221 248 435 221 248 436 minecraft:bone_block
fill 221 248 440 221 248 441 minecraft:bone_block
fill 224 248 435 224 248 436 minecraft:bone_block
fill 224 248 440 224 248 441 minecraft:bone_block
setblock 191 249 419 minecraft:light[level=13]
setblock 191 249 427 minecraft:light[level=13]
setblock 191 249 435 minecraft:light[level=13]
setblock 191 249 443 minecraft:light[level=13]
setblock 191 249 451 minecraft:light[level=13]
setblock 199 249 419 minecraft:light[level=13]
setblock 199 249 427 minecraft:light[level=13]
setblock 199 249 435 minecraft:light[level=13]
fill 199 249 437 199 249 439 minecraft:bone_block
setblock 199 249 443 minecraft:light[level=13]
setblock 199 249 451 minecraft:light[level=13]
fill 201 249 440 203 249 440 minecraft:bone_block
fill 203 249 436 203 249 437 minecraft:bone_block
fill 204 249 437 205 249 437 minecraft:bone_block
fill 205 249 438 205 249 439 minecraft:bone_block
setblock 207 249 419 minecraft:light[level=13]
setblock 207 249 427 minecraft:light[level=13]
setblock 207 249 435 minecraft:light[level=13]
setblock 207 249 443 minecraft:light[level=13]
setblock 207 249 451 minecraft:light[level=13]
setblock 215 249 419 minecraft:light[level=13]
setblock 215 249 427 minecraft:light[level=13]
setblock 215 249 435 minecraft:light[level=13]
setblock 215 249 443 minecraft:light[level=13]
setblock 215 249 451 minecraft:light[level=13]
setblock 223 249 419 minecraft:light[level=13]
setblock 223 249 427 minecraft:light[level=13]
setblock 223 249 435 minecraft:light[level=13]
setblock 223 249 443 minecraft:light[level=13]
setblock 223 249 451 minecraft:light[level=13]
fill 201 250 437 202 250 439 minecraft:bone_block
setblock 203 250 437 minecraft:bone_block
setblock 204 250 439 minecraft:bone_block
fill 201 251 437 203 269 438 minecraft:polished_deepslate
fill 202 251 439 202 269 439 minecraft:polished_deepslate
fill 188 252 422 188 265 422 minecraft:stone
fill 188 252 423 188 252 424 minecraft:shroomlight
fill 188 252 425 188 265 425 minecraft:stone
fill 188 252 434 188 265 434 minecraft:stone
fill 188 252 435 188 252 436 minecraft:shroomlight
fill 188 252 437 188 265 437 minecraft:stone
fill 188 252 446 188 265 446 minecraft:stone
fill 188 252 447 188 252 448 minecraft:shroomlight
fill 188 252 449 188 265 449 minecraft:stone
fill 188 252 458 188 265 458 minecraft:stone
fill 189 252 458 190 252 458 minecraft:shroomlight
fill 191 252 458 191 265 458 minecraft:stone
fill 195 252 416 195 265 416 minecraft:stone
fill 196 252 416 197 252 416 minecraft:shroomlight
fill 198 252 416 198 265 416 minecraft:stone
fill 200 252 458 200 265 458 minecraft:stone
fill 201 252 436 203 253 436 minecraft:deepslate
fill 201 252 439 201 253 439 minecraft:deepslate
fill 201 252 458 202 252 458 minecraft:shroomlight
fill 203 252 439 203 253 439 minecraft:deepslate
fill 203 252 458 203 265 458 minecraft:stone
fill 204 252 437 204 253 438 minecraft:deepslate
fill 207 252 416 207 265 416 minecraft:stone
fill 207 252 418 207 261 418 minecraft:red_wool
fill 208 252 416 209 252 416 minecraft:shroomlight
fill 210 252 416 210 265 416 minecraft:stone
fill 212 252 458 212 265 458 minecraft:stone
fill 213 252 458 214 252 458 minecraft:shroomlight
fill 215 252 458 215 265 458 minecraft:stone
fill 219 252 416 219 265 416 minecraft:stone
fill 220 252 416 221 252 416 minecraft:shroomlight
fill 222 252 416 222 265 416 minecraft:stone
fill 224 252 458 224 265 458 minecraft:stone
fill 225 252 458 226 252 458 minecraft:shroomlight
fill 227 252 458 227 265 458 minecraft:stone
fill 230 252 417 230 265 417 minecraft:stone
fill 230 252 418 230 252 419 minecraft:shroomlight
fill 230 252 420 230 265 420 minecraft:stone
fill 230 252 429 230 265 429 minecraft:stone
fill 230 252 430 230 252 431 minecraft:shroomlight
fill 230 252 432 230 265 432 minecraft:stone
fill 230 252 441 230 265 441 minecraft:stone
fill 230 252 442 230 252 443 minecraft:shroomlight
fill 230 252 444 230 265 444 minecraft:stone
fill 230 252 453 230 265 453 minecraft:stone
fill 230 252 454 230 252 455 minecraft:shroomlight
fill 230 252 456 230 265 456 minecraft:stone
fill 188 253 423 188 265 424 minecraft:stone
fill 188 253 435 188 265 436 minecraft:stone
fill 188 253 447 188 265 448 minecraft:stone
fill 189 253 458 190 265 458 minecraft:stone
fill 196 253 416 197 265 416 minecraft:stone
fill 200 253 436 200 253 439 minecraft:deepslate
fill 201 253 440 203 253 440 minecraft:deepslate
fill 201 253 458 202 265 458 minecraft:stone
fill 202 253 435 203 253 435 minecraft:deepslate
setblock 204 253 436 minecraft:deepslate
setblock 204 253 439 minecraft:deepslate
fill 205 253 418 206 261 418 minecraft:red_wool
fill 208 253 416 209 265 416 minecraft:stone
fill 208 253 418 209 261 418 minecraft:red_wool
fill 213 253 458 214 265 458 minecraft:stone
fill 220 253 416 221 265 416 minecraft:stone
fill 225 253 458 226 265 458 minecraft:stone
fill 230 253 418 230 265 419 minecraft:stone
fill 230 253 430 230 265 431 minecraft:stone
fill 230 253 442 230 265 443 minecraft:stone
fill 230 253 454 230 265 455 minecraft:stone
fill 226 254 427 226 262 427 minecraft:iron_block
setblock 191 257 419 minecraft:light[level=13]
setblock 191 257 427 minecraft:light[level=13]
setblock 191 257 435 minecraft:light[level=13]
setblock 191 257 443 minecraft:light[level=13]
setblock 191 257 451 minecraft:light[level=13]
setblock 199 257 419 minecraft:light[level=13]
setblock 199 257 427 minecraft:light[level=13]
setblock 199 257 435 minecraft:light[level=13]
setblock 199 257 443 minecraft:light[level=13]
setblock 199 257 451 minecraft:light[level=13]
setblock 207 257 419 minecraft:light[level=13]
setblock 207 257 427 minecraft:light[level=13]
setblock 207 257 435 minecraft:light[level=13]
setblock 207 257 443 minecraft:light[level=13]
setblock 207 257 451 minecraft:light[level=13]
setblock 215 257 419 minecraft:light[level=13]
setblock 215 257 427 minecraft:light[level=13]
setblock 215 257 435 minecraft:light[level=13]
setblock 215 257 443 minecraft:light[level=13]
setblock 215 257 451 minecraft:light[level=13]
setblock 223 257 419 minecraft:light[level=13]
setblock 223 257 427 minecraft:light[level=13]
setblock 223 257 435 minecraft:light[level=13]
setblock 223 257 443 minecraft:light[level=13]
setblock 223 257 451 minecraft:light[level=13]
fill 226 259 442 228 260 442 minecraft:iron_block
fill 190 260 426 190 265 428 minecraft:polished_deepslate
fill 190 260 438 190 265 440 minecraft:polished_deepslate
fill 190 260 450 190 265 452 minecraft:polished_deepslate
fill 196 260 456 198 265 456 minecraft:polished_deepslate
fill 200 260 418 202 265 418 minecraft:polished_deepslate
fill 208 260 456 210 265 456 minecraft:polished_deepslate
fill 212 260 418 214 265 418 minecraft:polished_deepslate
fill 220 260 456 222 265 456 minecraft:polished_deepslate
fill 224 260 418 226 265 418 minecraft:polished_deepslate
fill 228 260 426 228 265 428 minecraft:polished_deepslate
fill 228 260 438 228 265 440 minecraft:polished_deepslate
fill 228 260 450 228 265 452 minecraft:polished_deepslate
fill 204 262 418 210 263 418 minecraft:iron_block
fill 189 265 420 189 265 425 minecraft:deepslate
fill 189 265 432 189 265 437 minecraft:deepslate
fill 189 265 444 189 265 449 minecraft:deepslate
fill 189 265 456 189 265 457 minecraft:deepslate
fill 190 265 457 193 265 457 minecraft:deepslate
setblock 191 265 419 minecraft:light[level=13]
setblock 191 265 427 minecraft:light[level=13]
setblock 191 265 435 minecraft:light[level=13]
setblock 191 265 443 minecraft:light[level=13]
setblock 191 265 451 minecraft:light[level=13]
fill 193 265 417 198 265 417 minecraft:deepslate
setblock 199 265 419 minecraft:light[level=13]
setblock 199 265 427 minecraft:light[level=13]
setblock 199 265 435 minecraft:light[level=13]
setblock 199 265 443 minecraft:light[level=13]
setblock 199 265 451 minecraft:light[level=13]
fill 200 265 457 205 265 457 minecraft:deepslate
fill 205 265 417 210 265 417 minecraft:deepslate
setblock 207 265 419 minecraft:light[level=13]
setblock 207 265 427 minecraft:light[level=13]
setblock 207 265 435 minecraft:light[level=13]
setblock 207 265 443 minecraft:light[level=13]
setblock 207 265 451 minecraft:light[level=13]
fill 212 265 457 217 265 457 minecraft:deepslate
setblock 215 265 419 minecraft:light[level=13]
setblock 215 265 427 minecraft:light[level=13]
setblock 215 265 435 minecraft:light[level=13]
setblock 215 265 443 minecraft:light[level=13]
setblock 215 265 451 minecraft:light[level=13]
fill 217 265 417 222 265 417 minecraft:deepslate
setblock 223 265 419 minecraft:light[level=13]
setblock 223 265 427 minecraft:light[level=13]
setblock 223 265 435 minecraft:light[level=13]
setblock 223 265 443 minecraft:light[level=13]
setblock 223 265 451 minecraft:light[level=13]
fill 224 265 457 229 265 457 minecraft:deepslate
fill 229 265 417 229 265 422 minecraft:deepslate
fill 229 265 429 229 265 434 minecraft:deepslate
fill 229 265 441 229 265 446 minecraft:deepslate
fill 229 265 453 229 265 456 minecraft:deepslate
fill 188 266 422 188 269 425 minecraft:shroomlight
fill 188 266 434 188 269 437 minecraft:shroomlight
fill 188 266 446 188 269 449 minecraft:shroomlight
fill 188 266 458 191 269 458 minecraft:shroomlight
fill 195 266 416 198 269 416 minecraft:shroomlight
fill 200 266 436 200 266 439 minecraft:gold_block
fill 200 266 458 203 269 458 minecraft:shroomlight
fill 201 266 435 203 266 436 minecraft:gold_block
fill 201 266 439 201 266 440 minecraft:gold_block
fill 202 266 440 203 266 440 minecraft:gold_block
fill 203 266 439 204 267 439 minecraft:gold_block
fill 204 266 436 204 267 438 minecraft:gold_block
fill 205 266 437 205 266 438 minecraft:gold_block
fill 207 266 416 210 269 416 minecraft:shroomlight
fill 212 266 458 215 269 458 minecraft:shroomlight
fill 219 266 416 222 269 416 minecraft:shroomlight
fill 224 266 458 227 269 458 minecraft:shroomlight
fill 230 266 417 230 269 420 minecraft:shroomlight
fill 230 266 429 230 269 432 minecraft:shroomlight
fill 230 266 441 230 269 444 minecraft:shroomlight
fill 230 266 453 230 269 456 minecraft:shroomlight
fill 200 267 437 200 267 438 minecraft:gold_block
fill 201 267 436 203 268 436 minecraft:gold_block
fill 201 267 439 201 268 439 minecraft:gold_block
setblock 203 268 439 minecraft:gold_block
fill 204 268 437 204 268 438 minecraft:gold_block
fill 188 270 422 188 285 425 minecraft:stone
fill 188 270 434 188 285 437 minecraft:stone
fill 188 270 446 188 285 449 minecraft:stone
fill 188 270 458 191 285 458 minecraft:stone
fill 195 270 416 198 285 416 minecraft:stone
fill 200 270 458 203 285 458 minecraft:stone
fill 207 270 416 210 285 416 minecraft:stone
fill 212 270 458 215 285 458 minecraft:stone
fill 219 270 416 222 285 416 minecraft:stone
fill 224 270 458 227 285 458 minecraft:stone
fill 230 270 417 230 285 420 minecraft:stone
fill 230 270 429 230 285 432 minecraft:stone
fill 230 270 441 230 285 444 minecraft:stone
fill 230 270 453 230 285 456 minecraft:stone
setblock 191 273 419 minecraft:light[level=13]
setblock 191 273 427 minecraft:light[level=13]
setblock 191 273 435 minecraft:light[level=13]
setblock 191 273 443 minecraft:light[level=13]
setblock 191 273 451 minecraft:light[level=13]
setblock 199 273 419 minecraft:light[level=13]
setblock 199 273 427 minecraft:light[level=13]
setblock 199 273 435 minecraft:light[level=13]
setblock 199 273 443 minecraft:light[level=13]
setblock 199 273 451 minecraft:light[level=13]
setblock 207 273 419 minecraft:light[level=13]
setblock 207 273 427 minecraft:light[level=13]
setblock 207 273 435 minecraft:light[level=13]
setblock 207 273 443 minecraft:light[level=13]
setblock 207 273 451 minecraft:light[level=13]
setblock 215 273 419 minecraft:light[level=13]
setblock 215 273 427 minecraft:light[level=13]
setblock 215 273 435 minecraft:light[level=13]
setblock 215 273 443 minecraft:light[level=13]
setblock 215 273 451 minecraft:light[level=13]
setblock 223 273 419 minecraft:light[level=13]
setblock 223 273 427 minecraft:light[level=13]
setblock 223 273 435 minecraft:light[level=13]
setblock 223 273 443 minecraft:light[level=13]
setblock 223 273 451 minecraft:light[level=13]
fill 189 275 419 209 275 455 minecraft:iron_block
fill 190 275 418 228 275 418 minecraft:iron_block
fill 190 275 456 228 275 456 minecraft:iron_block
fill 191 275 417 227 275 417 minecraft:iron_block
fill 191 275 457 227 275 457 minecraft:iron_block
fill 210 275 419 210 277 435 minecraft:iron_block
fill 210 275 439 210 277 455 minecraft:iron_block
fill 211 275 419 229 275 434 minecraft:iron_block
fill 211 275 440 229 275 455 minecraft:iron_block
fill 214 275 435 229 277 435 minecraft:iron_block
fill 214 275 439 229 277 439 minecraft:iron_block
fill 215 275 436 229 277 438 minecraft:iron_block
fill 189 276 420 209 276 454 minecraft:iron_block
fill 190 276 419 209 276 419 minecraft:iron_block
fill 190 276 455 209 276 455 minecraft:iron_block
fill 191 276 418 227 276 418 minecraft:iron_block
fill 191 276 456 227 276 456 minecraft:iron_block
fill 192 276 417 226 276 417 minecraft:iron_block
fill 192 276 457 226 276 457 minecraft:iron_block
fill 211 276 419 228 276 434 minecraft:iron_block
fill 211 276 440 228 276 455 minecraft:iron_block
fill 229 276 420 229 276 434 minecraft:iron_block
fill 229 276 440 229 276 454 minecraft:iron_block
fill 189 277 421 209 277 453 minecraft:iron_block
fill 190 277 420 209 279 420 minecraft:iron_block
fill 190 277 454 209 279 454 minecraft:iron_block
fill 191 277 419 209 279 419 minecraft:iron_block
fill 191 277 455 209 279 455 minecraft:iron_block
fill 192 277 418 226 279 418 minecraft:iron_block
fill 192 277 456 226 279 456 minecraft:iron_block
fill 193 277 417 225 279 417 minecraft:iron_block
fill 193 277 457 225 279 457 minecraft:iron_block
fill 211 277 419 227 277 434 minecraft:iron_block
fill 211 277 440 227 277 455 minecraft:iron_block
fill 228 277 420 228 279 434 minecraft:iron_block
fill 228 277 440 228 279 454 minecraft:iron_block
fill 229 277 421 229 279 434 minecraft:iron_block
fill 229 277 440 229 279 453 minecraft:iron_block
fill 189 278 421 208 278 453 minecraft:iron_block
fill 209 278 421 209 278 435 minecraft:iron_block
fill 209 278 436 209 278 438 minecraft:gold_block
fill 209 278 439 209 278 453 minecraft:iron_block
fill 210 278 419 210 278 434 minecraft:iron_block
setblock 210 278 435 minecraft:gold_block
setblock 210 278 439 minecraft:gold_block
fill 210 278 440 210 278 455 minecraft:iron_block
fill 211 278 419 227 278 433 minecraft:iron_block
fill 211 278 434 213 278 434 minecraft:gold_block
fill 211 278 440 213 278 440 minecraft:gold_block
fill 211 278 441 227 278 455 minecraft:iron_block
fill 214 278 434 227 278 434 minecraft:iron_block
setblock 214 278 435 minecraft:gold_block
setblock 214 278 439 minecraft:gold_block
fill 214 278 440 227 278 440 minecraft:iron_block
fill 215 278 435 229 278 436 minecraft:iron_block
setblock 215 278 437 minecraft:gold_block
fill 215 278 438 229 278 439 minecraft:iron_block
fill 216 278 437 229 278 437 minecraft:iron_block
fill 189 279 417 189 279 457 minecraft:iron_block
fill 190 279 417 190 279 419 minecraft:iron_block
fill 190 279 421 207 279 453 minecraft:iron_block
fill 190 279 455 190 279 457 minecraft:iron_block
fill 191 279 417 191 279 418 minecraft:iron_block
fill 191 279 456 191 279 457 minecraft:iron_block
setblock 192 279 417 minecraft:iron_block
setblock 192 279 457 minecraft:iron_block
fill 208 279 421 208 279 434 minecraft:iron_block
fill 208 279 435 208 279 439 minecraft:polished_deepslate
fill 208 279 440 208 279 453 minecraft:iron_block
fill 209 279 421 210 279 433 minecraft:iron_block
setblock 209 279 434 minecraft:polished_deepslate
fill 209 279 435 209 279 439 minecraft:shroomlight
setblock 209 279 440 minecraft:polished_deepslate
fill 209 279 441 210 279 453 minecraft:iron_block
fill 210 279 419 227 279 420 minecraft:iron_block
fill 210 279 434 210 279 435 minecraft:shroomlight
fill 210 279 439 210 279 440 minecraft:shroomlight
fill 210 279 454 227 279 455 minecraft:iron_block
fill 211 279 421 227 279 432 minecraft:iron_block
fill 211 279 433 213 279 433 minecraft:polished_deepslate
fill 211 279 434 214 279 434 minecraft:shroomlight
fill 211 279 440 214 279 440 minecraft:shroomlight
fill 211 279 441 213 279 441 minecraft:polished_deepslate
fill 211 279 442 227 279 453 minecraft:iron_block
fill 214 279 433 227 279 433 minecraft:iron_block
fill 214 279 435 215 279 435 minecraft:shroomlight
fill 214 279 439 215 279 439 minecraft:shroomlight
fill 214 279 441 227 279 441 minecraft:iron_block
fill 215 279 434 227 279 434 minecraft:iron_block
fill 215 279 436 215 279 438 minecraft:shroomlight
fill 215 279 440 227 279 440 minecraft:iron_block
fill 216 279 435 229 279 436 minecraft:iron_block
setblock 216 279 437 minecraft:polished_deepslate
fill 216 279 438 229 279 439 minecraft:iron_block
fill 217 279 437 229 280 437 minecraft:iron_block
fill 226 279 417 229 279 417 minecraft:iron_block
fill 226 279 457 229 279 457 minecraft:iron_block
fill 227 279 418 229 279 418 minecraft:iron_block
fill 227 279 456 229 279 456 minecraft:iron_block
fill 228 279 419 229 279 419 minecraft:iron_block
fill 228 279 455 229 279 455 minecraft:iron_block
setblock 229 279 420 minecraft:iron_block
setblock 229 279 454 minecraft:iron_block
fill 189 280 423 206 280 451 minecraft:iron_block
fill 190 280 422 228 280 422 minecraft:iron_block
fill 190 280 452 228 280 452 minecraft:iron_block
fill 191 280 421 227 281 421 minecraft:iron_block
fill 191 280 453 227 281 453 minecraft:iron_block
fill 192 280 420 226 281 420 minecraft:iron_block
fill 192 280 454 226 281 454 minecraft:iron_block
fill 193 280 419 225 281 419 minecraft:iron_block
fill 193 280 455 225 281 455 minecraft:iron_block
fill 194 280 418 224 280 418 minecraft:iron_block
fill 194 280 456 224 280 456 minecraft:iron_block
fill 195 280 417 223 280 417 minecraft:iron_block
fill 195 280 457 223 280 457 minecraft:iron_block
fill 207 280 423 207 280 433 minecraft:iron_block
fill 207 280 434 207 280 440 minecraft:gold_block
fill 207 280 441 207 280 451 minecraft:iron_block
fill 208 280 423 209 280 432 minecraft:iron_block
fill 208 280 433 208 280 434 minecraft:gold_block
fill 208 280 440 208 280 441 minecraft:gold_block
fill 208 280 442 209 280 451 minecraft:iron_block
fill 209 280 433 210 280 433 minecraft:gold_block
fill 209 280 441 210 280 441 minecraft:gold_block
fill 210 280 423 229 280 431 minecraft:iron_block
fill 210 280 432 212 280 432 minecraft:gold_block
fill 210 280 442 212 280 442 minecraft:gold_block
fill 210 280 443 229 280 451 minecraft:iron_block
fill 213 280 432 229 280 432 minecraft:iron_block
fill 213 280 433 214 280 433 minecraft:gold_block
fill 213 280 441 214 280 441 minecraft:gold_block
fill 213 280 442 229 280 442 minecraft:iron_block
fill 215 280 433 229 280 433 minecraft:iron_block
setblock 215 280 434 minecraft:gold_block
setblock 215 280 440 minecraft:gold_block
fill 215 280 441 229 280 441 minecraft:iron_block
fill 216 280 434 229 280 434 minecraft:iron_block
fill 216 280 435 216 280 439 minecraft:gold_block
fill 216 280 440 229 280 440 minecraft:iron_block
fill 217 280 435 229 280 436 minecraft:iron_block
fill 217 280 438 229 280 439 minecraft:iron_block
fill 189 281 424 204 281 450 minecraft:iron_block
fill 190 281 423 228 281 423 minecraft:iron_block
fill 190 281 451 228 281 451 minecraft:iron_block
setblock 191 281 419 minecraft:light[level=13]
fill 191 281 422 227 282 422 minecraft:iron_block
fill 191 281 452 227 282 452 minecraft:iron_block
fill 195 281 418 223 281 418 minecraft:iron_block
fill 195 281 456 223 281 456 minecraft:iron_block
fill 196 281 417 222 281 417 minecraft:iron_block
fill 196 281 457 222 281 457 minecraft:iron_block
fill 205 281 424 205 281 435 minecraft:iron_block
fill 205 281 436 206 281 438 minecraft:gold_block
fill 205 281 439 205 281 450 minecraft:iron_block
fill 206 281 424 206 281 433 minecraft:iron_block
fill 206 281 434 206 281 435 minecraft:gold_block
fill 206 281 439 206 281 440 minecraft:gold_block
fill 206 281 441 206 281 450 minecraft:iron_block
fill 207 281 424 207 281 432 minecraft:iron_block
setblock 207 281 433 minecraft:gold_block
setblock 207 281 435 minecraft:light[level=13]
setblock 207 281 441 minecraft:gold_block
fill 207 281 442 207 281 450 minecraft:iron_block
fill 208 281 424 209 281 431 minecraft:iron_block
fill 208 281 432 209 281 432 minecraft:gold_block
fill 208 281 442 209 281 442 minecraft:gold_block
fill 208 281 443 209 281 450 minecraft:iron_block
fill 210 281 424 229 281 430 minecraft:iron_block
fill 210 281 431 212 281 431 minecraft:gold_block
fill 210 281 443 212 281 443 minecraft:gold_block
fill 210 281 444 229 281 450 minecraft:iron_block
fill 213 281 431 229 281 431 minecraft:iron_block
fill 213 281 432 214 281 432 minecraft:gold_block
fill 213 281 442 214 281 442 minecraft:gold_block
fill 213 281 443 229 281 443 minecraft:iron_block
fill 215 281 432 229 281 432 minecraft:iron_block
setblock 215 281 433 minecraft:gold_block
setblock 215 281 435 minecraft:light[level=13]
setblock 215 281 441 minecraft:gold_block
fill 215 281 442 229 281 442 minecraft:iron_block
fill 216 281 433 229 281 433 minecraft:iron_block
setblock 216 281 434 minecraft:gold_block
setblock 216 281 440 minecraft:gold_block
fill 216 281 441 229 281 441 minecraft:iron_block
fill 217 281 434 229 281 434 minecraft:iron_block
fill 217 281 435 217 281 439 minecraft:gold_block
fill 217 281 440 229 281 440 minecraft:iron_block
fill 218 281 435 229 281 439 minecraft:iron_block
fill 189 282 425 203 282 449 minecraft:iron_block
fill 190 282 424 228 282 424 minecraft:iron_block
fill 190 282 450 228 282 450 minecraft:iron_block
fill 191 282 423 227 283 423 minecraft:iron_block
fill 191 282 451 227 283 451 minecraft:iron_block
fill 192 282 421 226 282 421 minecraft:iron_block
fill 192 282 453 226 282 453 minecraft:iron_block
fill 193 282 420 225 282 420 minecraft:iron_block
fill 193 282 454 225 282 454 minecraft:iron_block
fill 194 282 419 224 282 419 minecraft:iron_block
fill 194 282 455 224 282 455 minecraft:iron_block
fill 196 282 418 222 282 418 minecraft:iron_block
fill 196 282 456 222 282 456 minecraft:iron_block
fill 197 282 417 221 282 417 minecraft:iron_block
fill 197 282 457 221 282 457 minecraft:iron_block
fill 204 282 425 204 282 434 minecraft:iron_block
fill 204 282 435 204 282 439 minecraft:polished_deepslate
fill 204 282 440 204 282 449 minecraft:iron_block
fill 205 282 425 205 282 432 minecraft:iron_block
fill 205 282 433 205 282 435 minecraft:polished_deepslate
fill 205 282 439 205 282 441 minecraft:polished_deepslate
fill 205 282 442 205 282 449 minecraft:iron_block
fill 206 282 425 206 282 431 minecraft:iron_block
fill 206 282 432 206 282 433 minecraft:polished_deepslate
fill 206 282 441 206 282 442 minecraft:polished_deepslate
fill 206 282 443 206 282 449 minecraft:iron_block
fill 207 282 425 208 282 430 minecraft:iron_block
fill 207 282 431 207 282 432 minecraft:polished_deepslate
fill 207 282 442 207 282 443 minecraft:polished_deepslate
fill 207 282 444 208 282 449 minecraft:iron_block
fill 208 282 431 209 282 431 minecraft:polished_deepslate
fill 208 282 443 209 282 443 minecraft:polished_deepslate
fill 209 282 425 229 282 429 minecraft:iron_block
fill 209 282 430 212 282 430 minecraft:polished_deepslate
fill 209 282 444 212 282 444 minecraft:polished_deepslate
fill 209 282 445 229 282 449 minecraft:iron_block
fill 213 282 430 229 282 430 minecraft:iron_block
fill 213 282 431 214 282 431 minecraft:polished_deepslate
fill 213 282 443 214 282 443 minecraft:polished_deepslate
fill 213 282 444 229 282 444 minecraft:iron_block
fill 215 282 431 229 282 431 minecraft:iron_block
fill 215 282 432 216 282 432 minecraft:polished_deepslate
fill 215 282 442 216 282 442 minecraft:polished_deepslate
fill 215 282 443 229 282 443 minecraft:iron_block
setblock 216 282 433 minecraft:polished_deepslate
setblock 216 282 441 minecraft:polished_deepslate
fill 217 282 432 229 282 433 minecraft:iron_block
setblock 217 282 434 minecraft:polished_deepslate
setblock 217 282 440 minecraft:polished_deepslate
fill 217 282 441 229 282 442 minecraft:iron_block
fill 218 282 434 229 282 434 minecraft:iron_block
fill 218 282 435 218 282 439 minecraft:polished_deepslate
fill 218 282 440 229 282 440 minecraft:iron_block
fill 219 282 435 229 282 439 minecraft:iron_block
fill 189 283 417 191 300 417 minecraft:polished_deepslate
fill 189 283 426 202 283 448 minecraft:iron_block
fill 189 283 451 189 300 453 minecraft:polished_deepslate
fill 190 283 425 228 283 425 minecraft:iron_block
fill 190 283 449 228 283 449 minecraft:iron_block
fill 190 283 450 190 285 452 minecraft:polished_deepslate
fill 191 283 424 227 284 424 minecraft:iron_block
fill 191 283 450 227 284 450 minecraft:iron_block
fill 192 283 422 226 283 422 minecraft:iron_block
fill 192 283 452 226 283 452 minecraft:iron_block
fill 193 283 421 225 283 421 minecraft:iron_block
fill 193 283 453 225 283 453 minecraft:iron_block
fill 194 283 420 224 283 420 minecraft:iron_block
fill 194 283 454 224 283 454 minecraft:iron_block
fill 195 283 419 223 283 419 minecraft:iron_block
fill 195 283 455 223 283 455 minecraft:iron_block
fill 195 283 457 197 300 457 minecraft:polished_deepslate
fill 196 283 456 196 285 456 minecraft:polished_deepslate
fill 197 283 418 221 283 418 minecraft:iron_block
fill 197 283 456 221 283 456 minecraft:iron_block
fill 198 283 417 220 283 417 minecraft:iron_block
fill 198 283 457 220 283 457 minecraft:iron_block
fill 203 283 426 203 283 433 minecraft:iron_block
fill 203 283 434 203 283 440 minecraft:gold_block
fill 203 283 441 203 283 448 minecraft:iron_block
fill 204 283 426 204 283 431 minecraft:iron_block
fill 204 283 432 204 283 434 minecraft:gold_block
fill 204 283 440 204 283 442 minecraft:gold_block
fill 204 283 443 204 283 448 minecraft:iron_block
fill 205 283 426 205 283 430 minecraft:iron_block
fill 205 283 431 205 283 432 minecraft:gold_block
fill 205 283 442 205 283 443 minecraft:gold_block
fill 205 283 444 205 283 448 minecraft:iron_block
fill 206 283 426 208 283 429 minecraft:iron_block
fill 206 283 430 206 283 431 minecraft:gold_block
fill 206 283 443 206 283 444 minecraft:gold_block
fill 206 283 445 208 283 448 minecraft:iron_block
fill 207 283 430 208 283 430 minecraft:gold_block
fill 207 283 444 208 283 444 minecraft:gold_block
fill 209 283 426 229 283 428 minecraft:iron_block
fill 209 283 429 212 283 429 minecraft:gold_block
fill 209 283 445 212 283 445 minecraft:gold_block
fill 209 283 446 229 283 448 minecraft:iron_block
fill 213 283 429 229 283 429 minecraft:iron_block
fill 213 283 430 215 283 430 minecraft:gold_block
fill 213 283 444 215 283 444 minecraft:gold_block
fill 213 283 445 229 283 445 minecraft:iron_block
fill 215 283 431 216 283 431 minecraft:gold_block
fill 215 283 443 216 283 443 minecraft:gold_block
fill 216 283 430 229 283 430 minecraft:iron_block
fill 216 283 444 229 283 444 minecraft:iron_block
fill 217 283 431 229 283 431 minecraft:iron_block
fill 217 283 432 217 283 433 minecraft:gold_block
fill 217 283 441 217 283 442 minecraft:gold_block
fill 217 283 443 229 283 443 minecraft:iron_block
fill 218 283 432 229 283 433 minecraft:iron_block
fill 218 283 434 218 283 435 minecraft:gold_block
fill 218 283 439 218 283 440 minecraft:gold_block
fill 218 283 441 229 283 442 minecraft:iron_block
fill 219 283 434 229 283 435 minecraft:iron_block
fill 219 283 436 219 284 438 minecraft:gold_block
fill 219 283 439 229 283 440 minecraft:iron_block
fill 220 283 436 229 284 438 minecraft:iron_block
fill 221 283 457 221 300 457 minecraft:polished_deepslate
fill 222 283 456 222 285 456 minecraft:polished_deepslate
fill 224 283 418 226 285 418 minecraft:polished_deepslate
fill 225 283 417 227 300 417 minecraft:polished_deepslate
fill 228 283 450 228 285 452 minecraft:polished_deepslate
fill 229 283 425 229 300 425 minecraft:polished_deepslate
fill 229 283 449 229 300 451 minecraft:polished_deepslate
fill 189 284 427 189 300 427 minecraft:polished_deepslate
fill 189 284 428 200 284 446 minecraft:iron_block
fill 190 284 426 228 284 427 minecraft:iron_block
fill 190 284 447 228 284 448 minecraft:iron_block
fill 191 284 425 227 285 425 minecraft:iron_block
fill 191 284 449 227 285 449 minecraft:iron_block
fill 192 284 423 226 284 423 minecraft:iron_block
fill 192 284 451 226 284 451 minecraft:iron_block
fill 193 284 422 225 284 422 minecraft:iron_block
fill 193 284 452 225 284 452 minecraft:iron_block
fill 194 284 421 224 284 421 minecraft:iron_block
fill 194 284 453 224 284 453 minecraft:iron_block
fill 195 284 420 223 284 420 minecraft:iron_block
fill 195 284 454 223 284 454 minecraft:iron_block
fill 196 284 419 222 284 419 minecraft:iron_block
fill 196 284 455 222 284 455 minecraft:iron_block
fill 197 284 456 197 285 456 minecraft:polished_deepslate
fill 198 284 418 220 284 418 minecraft:iron_block
fill 198 284 456 220 284 456 minecraft:iron_block
fill 200 284 417 218 284 417 minecraft:iron_block
fill 200 284 457 218 284 457 minecraft:iron_block
fill 201 284 428 201 284 435 minecraft:iron_block
fill 201 284 436 202 284 438 minecraft:gold_block
fill 201 284 439 201 284 446 minecraft:iron_block
fill 202 284 428 202 284 432 minecraft:iron_block
fill 202 284 433 202 284 435 minecraft:gold_block
fill 202 284 439 202 284 441 minecraft:gold_block
fill 202 284 442 202 284 446 minecraft:iron_block
fill 203 284 428 203 284 431 minecraft:iron_block
fill 203 284 432 203 284 433 minecraft:gold_block
fill 203 284 441 203 284 442 minecraft:gold_block
fill 203 284 443 203 284 446 minecraft:iron_block
fill 204 284 428 205 284 429 minecraft:iron_block
fill 204 284 430 204 284 431 minecraft:gold_block
fill 204 284 443 204 284 444 minecraft:gold_block
fill 204 284 445 205 284 446 minecraft:iron_block
setblock 205 284 430 minecraft:gold_block
setblock 205 284 444 minecraft:gold_block
fill 206 284 428 207 284 428 minecraft:iron_block
fill 206 284 429 208 284 429 minecraft:gold_block
fill 206 284 445 208 284 445 minecraft:gold_block
fill 206 284 446 207 284 446 minecraft:iron_block
fill 208 284 428 212 284 428 minecraft:gold_block
fill 208 284 446 212 284 446 minecraft:gold_block
fill 213 284 428 229 284 428 minecraft:iron_block
fill 213 284 429 215 284 429 minecraft:gold_block
fill 213 284 445 215 284 445 minecraft:gold_block
fill 213 284 446 229 284 446 minecraft:iron_block
fill 216 284 429 229 284 429 minecraft:iron_block
setblock 216 284 430 minecraft:gold_block
setblock 216 284 444 minecraft:gold_block
fill 216 284 445 229 284 445 minecraft:iron_block
fill 217 284 430 229 284 430 minecraft:iron_block
setblock 217 284 431 minecraft:gold_block
setblock 217 284 443 minecraft:gold_block
fill 217 284 444 229 284 444 minecraft:iron_block
fill 218 284 431 229 284 431 minecraft:iron_block
fill 218 284 432 218 284 433 minecraft:gold_block
fill 218 284 441 218 284 442 minecraft:gold_block
fill 218 284 443 229 284 443 minecraft:iron_block
fill 219 284 432 229 284 433 minecraft:iron_block
fill 219 284 434 219 284 435 minecraft:gold_block
fill 219 284 439 219 284 440 minecraft:gold_block
fill 219 284 441 229 284 442 minecraft:iron_block
fill 219 284 457 220 300 457 minecraft:polished_deepslate
fill 220 284 434 229 284 435 minecraft:iron_block
fill 220 284 439 229 284 440 minecraft:iron_block
fill 221 284 456 221 285 456 minecraft:polished_deepslate
fill 227 284 454 227 285 456 minecraft:iron_block
fill 229 284 426 229 300 427 minecraft:polished_deepslate
fill 189 285 420 189 285 425 minecraft:deepslate
fill 189 285 428 189 300 428 minecraft:polished_deepslate
fill 189 285 429 199 285 445 minecraft:iron_block
fill 189 285 446 189 285 449 minecraft:deepslate
fill 189 285 456 189 285 457 minecraft:deepslate
setblock 190 285 426 minecraft:polished_deepslate
fill 190 285 427 204 285 428 minecraft:iron_block
fill 190 285 446 204 285 447 minecraft:iron_block
fill 190 285 457 193 285 457 minecraft:deepslate
fill 191 285 426 227 285 426 minecraft:iron_block
fill 191 285 448 227 285 448 minecraft:iron_block
fill 192 285 424 226 285 424 minecraft:iron_block
fill 192 285 450 226 285 450 minecraft:iron_block
fill 193 285 417 198 285 417 minecraft:deepslate
fill 193 285 423 225 285 423 minecraft:iron_block
fill 193 285 451 225 285 451 minecraft:iron_block
fill 194 285 422 224 285 422 minecraft:iron_block
fill 194 285 452 224 285 452 minecraft:iron_block
fill 195 285 421 223 285 421 minecraft:iron_block
fill 195 285 453 223 285 453 minecraft:iron_block
fill 196 285 420 222 285 420 minecraft:iron_block
fill 196 285 454 222 285 454 minecraft:iron_block
fill 197 285 419 221 285 419 minecraft:iron_block
fill 197 285 455 221 285 455 minecraft:iron_block
setblock 198 285 456 minecraft:polished_deepslate
fill 199 285 418 219 285 418 minecraft:iron_block
fill 199 285 456 219 285 456 minecraft:iron_block
fill 200 285 429 200 285 433 minecraft:iron_block
fill 200 285 434 200 285 440 minecraft:polished_deepslate
fill 200 285 441 200 285 445 minecraft:iron_block
setblock 200 285 457 minecraft:deepslate
fill 201 285 417 217 285 417 minecraft:iron_block
fill 201 285 429 201 285 431 minecraft:iron_block
fill 201 285 432 201 285 435 minecraft:polished_deepslate
fill 201 285 439 201 285 442 minecraft:polished_deepslate
fill 201 285 443 201 285 445 minecraft:iron_block
fill 201 285 457 217 285 457 minecraft:iron_block
fill 202 285 429 202 285 430 minecraft:iron_block
fill 202 285 431 202 285 432 minecraft:polished_deepslate
fill 202 285 442 202 285 443 minecraft:polished_deepslate
fill 202 285 444 202 285 445 minecraft:iron_block
setblock 203 285 429 minecraft:iron_block
fill 203 285 430 203 285 431 minecraft:polished_deepslate
fill 203 285 443 203 285 444 minecraft:polished_deepslate
setblock 203 285 445 minecraft:iron_block
fill 204 285 429 205 285 429 minecraft:polished_deepslate
fill 204 285 445 205 285 445 minecraft:polished_deepslate
fill 205 285 427 207 285 427 minecraft:iron_block
fill 205 285 428 207 285 428 minecraft:polished_deepslate
fill 205 285 446 207 285 446 minecraft:polished_deepslate
fill 205 285 447 207 285 447 minecraft:iron_block
fill 208 285 427 212 285 427 minecraft:polished_deepslate
fill 208 285 447 212 285 447 minecraft:polished_deepslate
fill 213 285 427 228 285 427 minecraft:iron_block
fill 213 285 428 215 285 428 minecraft:polished_deepslate
fill 213 285 446 215 285 446 minecraft:polished_deepslate
fill 213 285 447 228 285 447 minecraft:iron_block
fill 216 285 428 228 285 428 minecraft:iron_block
setblock 216 285 429 minecraft:polished_deepslate
setblock 216 285 445 minecraft:polished_deepslate
fill 216 285 446 228 285 446 minecraft:iron_block
fill 217 285 429 229 285 429 minecraft:iron_block
setblock 217 285 430 minecraft:polished_deepslate
setblock 217 285 444 minecraft:polished_deepslate
fill 217 285 445 229 285 445 minecraft:iron_block
fill 218 285 417 222 285 417 minecraft:deepslate
fill 218 285 430 229 285 430 minecraft:iron_block
setblock 218 285 431 minecraft:polished_deepslate
setblock 218 285 443 minecraft:polished_deepslate
fill 218 285 444 229 285 444 minecraft:iron_block
fill 219 285 431 229 285 431 minecraft:iron_block
fill 219 285 432 219 285 433 minecraft:polished_deepslate
fill 219 285 441 219 285 442 minecraft:polished_deepslate
fill 219 285 443 229 285 443 minecraft:iron_block
fill 220 285 432 229 285 433 minecraft:iron_block
fill 220 285 434 220 285 440 minecraft:polished_deepslate
fill 220 285 441 229 285 442 minecraft:iron_block
setblock 220 285 456 minecraft:polished_deepslate
fill 221 285 434 229 285 440 minecraft:iron_block
fill 224 285 457 229 285 457 minecraft:deepslate
setblock 228 285 426 minecraft:polished_deepslate
fill 229 285 417 229 285 422 minecraft:deepslate
setblock 229 285 446 minecraft:deepslate
fill 229 285 453 229 285 456 minecraft:deepslate
fill 188 286 422 188 291 425 minecraft:shroomlight
fill 188 286 434 188 291 437 minecraft:shroomlight
fill 188 286 446 188 291 449 minecraft:shroomlight
fill 188 286 458 191 291 458 minecraft:shroomlight
fill 189 286 429 189 300 429 minecraft:polished_deepslate
fill 189 286 432 198 286 442 minecraft:iron_block
fill 190 286 429 199 286 431 minecraft:iron_block
fill 190 286 443 199 286 445 minecraft:iron_block
fill 191 286 427 202 286 428 minecraft:iron_block
fill 191 286 446 202 286 447 minecraft:iron_block
fill 192 286 425 206 286 426 minecraft:iron_block
fill 192 286 448 206 286 449 minecraft:iron_block
fill 193 286 424 225 286 424 minecraft:iron_block
fill 193 286 450 225 286 450 minecraft:iron_block
fill 194 286 423 224 286 423 minecraft:iron_block
fill 194 286 451 224 286 451 minecraft:iron_block
fill 195 286 416 198 291 416 minecraft:shroomlight
fill 195 286 422 223 286 422 minecraft:iron_block
fill 195 286 452 223 286 452 minecraft:iron_block
fill 196 286 421 222 286 421 minecraft:iron_block
fill 196 286 453 222 286 453 minecraft:iron_block
fill 197 286 420 221 286 420 minecraft:iron_block
fill 197 286 454 221 286 454 minecraft:iron_block
fill 199 286 419 219 286 419 minecraft:iron_block
setblock 199 286 432 minecraft:iron_block
fill 199 286 433 199 286 441 minecraft:gold_block
setblock 199 286 442 minecraft:iron_block
fill 199 286 455 219 286 455 minecraft:iron_block
fill 200 286 429 200 286 430 minecraft:iron_block
fill 200 286 431 200 286 433 minecraft:gold_block
fill 200 286 441 200 286 443 minecraft:gold_block
fill 200 286 444 200 286 445 minecraft:iron_block
fill 200 286 458 203 291 458 minecraft:shroomlight
fill 201 286 417 203 300 417 minecraft:polished_deepslate
fill 201 286 418 217 286 418 minecraft:iron_block
setblock 201 286 429 minecraft:iron_block
fill 201 286 430 201 286 431 minecraft:gold_block
fill 201 286 443 201 286 444 minecraft:gold_block
setblock 201 286 445 minecraft:iron_block
fill 201 286 456 217 286 456 minecraft:iron_block
fill 202 286 429 202 286 430 minecraft:gold_block
fill 202 286 444 202 286 445 minecraft:gold_block
fill 203 286 427 204 286 427 minecraft:iron_block
fill 203 286 428 203 286 429 minecraft:gold_block
fill 203 286 445 203 286 446 minecraft:gold_block
fill 203 286 447 204 286 447 minecraft:iron_block
fill 204 286 417 214 286 417 minecraft:iron_block
setblock 204 286 428 minecraft:gold_block
setblock 204 286 446 minecraft:gold_block
fill 204 286 457 214 286 457 minecraft:iron_block
fill 205 286 427 207 286 427 minecraft:gold_block
fill 205 286 447 207 286 447 minecraft:gold_block
fill 207 286 416 210 291 416 minecraft:shroomlight
fill 207 286 425 226 286 425 minecraft:iron_block
fill 207 286 426 212 286 426 minecraft:gold_block
fill 207 286 448 212 286 448 minecraft:gold_block
fill 207 286 449 226 286 449 minecraft:iron_block
fill 212 286 458 215 291 458 minecraft:shroomlight
fill 213 286 426 226 286 426 minecraft:iron_block
fill 213 286 427 215 286 427 minecraft:gold_block
fill 213 286 447 215 286 447 minecraft:gold_block
fill 213 286 448 226 286 448 minecraft:iron_block
fill 215 286 417 215 300 417 minecraft:polished_deepslate
fill 216 286 427 227 286 427 minecraft:iron_block
setblock 216 286 428 minecraft:gold_block
setblock 216 286 446 minecraft:gold_block
fill 216 286 447 227 286 447 minecraft:iron_block
fill 217 286 428 227 286 428 minecraft:iron_block
setblock 217 286 429 minecraft:gold_block
setblock 217 286 445 minecraft:gold_block
fill 217 286 446 227 286 446 minecraft:iron_block
fill 218 286 429 228 286 429 minecraft:iron_block
setblock 218 286 430 minecraft:gold_block
setblock 218 286 444 minecraft:gold_block
fill 218 286 445 228 286 445 minecraft:iron_block
fill 219 286 416 222 291 416 minecraft:shroomlight
fill 219 286 430 228 286 430 minecraft:iron_block
setblock 219 286 431 minecraft:gold_block
setblock 219 286 443 minecraft:gold_block
fill 219 286 444 228 286 444 minecraft:iron_block
fill 220 286 431 228 286 431 minecraft:iron_block
fill 220 286 432 220 286 434 minecraft:gold_block
fill 220 286 440 220 286 442 minecraft:gold_block
fill 220 286 443 228 286 443 minecraft:iron_block
fill 221 286 432 229 286 434 minecraft:iron_block
fill 221 286 435 221 286 439 minecraft:gold_block
fill 221 286 440 229 286 442 minecraft:iron_block
fill 222 286 435 229 286 439 minecraft:iron_block
fill 224 286 458 227 291 458 minecraft:shroomlight
fill 230 286 417 230 291 420 minecraft:shroomlight
fill 230 286 429 230 291 432 minecraft:shroomlight
fill 230 286 441 230 291 444 minecraft:shroomlight
fill 230 286 453 230 291 456 minecraft:shroomlight
fill 189 287 439 189 300 441 minecraft:polished_deepslate
fill 190 287 431 196 287 443 minecraft:iron_block
fill 191 287 429 199 287 430 minecraft:iron_block
fill 191 287 444 199 287 445 minecraft:iron_block
fill 192 287 427 200 287 428 minecraft:iron_block
fill 192 287 446 200 287 447 minecraft:iron_block
fill 193 287 426 203 287 426 minecraft:iron_block
fill 193 287 448 203 287 448 minecraft:iron_block
fill 194 287 424 206 287 425 minecraft:iron_block
fill 194 287 449 206 287 450 minecraft:iron_block
fill 195 287 423 223 287 423 minecraft:iron_block
fill 195 287 451 223 287 451 minecraft:iron_block
fill 196 287 422 222 287 422 minecraft:iron_block
fill 196 287 452 222 287 452 minecraft:iron_block
fill 197 287 431 197 287 435 minecraft:iron_block
fill 197 287 436 198 287 438 minecraft:gold_block
fill 197 287 439 197 287 443 minecraft:iron_block
fill 198 287 421 220 287 421 minecraft:iron_block
setblock 198 287 431 minecraft:iron_block
fill 198 287 432 198 287 435 minecraft:gold_block
fill 198 287 439 198 287 442 minecraft:gold_block
setblock 198 287 443 minecraft:iron_block
fill 198 287 453 220 287 453 minecraft:iron_block
fill 199 287 420 219 287 420 minecraft:iron_block
fill 199 287 431 199 287 432 minecraft:gold_block
fill 199 287 442 199 287 443 minecraft:gold_block
fill 199 287 454 219 287 454 minecraft:iron_block
fill 200 287 429 200 287 430 minecraft:gold_block
fill 200 287 437 201 287 437 minecraft:gold_block
fill 200 287 444 200 287 445 minecraft:gold_block
fill 201 287 419 217 287 419 minecraft:iron_block
setblock 201 287 427 minecraft:iron_block
fill 201 287 428 201 287 429 minecraft:gold_block
fill 201 287 433 202 288 433 minecraft:gold_block
fill 201 287 441 202 288 441 minecraft:gold_block
fill 201 287 445 201 287 446 minecraft:gold_block
setblock 201 287 447 minecraft:iron_block
fill 201 287 455 217 287 455 minecraft:iron_block
fill 202 287 427 202 287 428 minecraft:gold_block
fill 202 287 446 202 287 447 minecraft:gold_block
fill 203 287 418 215 287 418 minecraft:iron_block
fill 203 287 427 204 287 427 minecraft:gold_block
fill 203 287 447 204 287 447 minecraft:gold_block
fill 203 287 456 215 287 456 minecraft:iron_block
fill 204 287 426 206 287 426 minecraft:gold_block
fill 204 287 448 206 287 448 minecraft:gold_block
fill 205 287 429 205 288 430 minecraft:gold_block
fill 205 287 444 205 288 445 minecraft:gold_block
fill 207 287 424 224 287 424 minecraft:iron_block
fill 207 287 425 212 287 425 minecraft:gold_block
fill 207 287 449 212 287 449 minecraft:gold_block
fill 207 287 450 224 287 450 minecraft:iron_block
fill 207 287 457 209 300 457 minecraft:polished_deepslate
fill 209 287 428 209 287 429 minecraft:gold_block
fill 209 287 445 209 287 446 minecraft:gold_block
fill 213 287 417 214 300 417 minecraft:polished_deepslate
fill 213 287 425 224 287 425 minecraft:iron_block
fill 213 287 426 215 287 426 minecraft:gold_block
fill 213 287 429 213 288 430 minecraft:gold_block
fill 213 287 444 213 288 445 minecraft:gold_block
fill 213 287 448 215 287 448 minecraft:gold_block
fill 213 287 449 224 287 449 minecraft:iron_block
fill 216 287 426 225 287 426 minecraft:iron_block
setblock 216 287 427 minecraft:gold_block
fill 216 287 433 217 288 433 minecraft:gold_block
fill 216 287 441 217 288 441 minecraft:gold_block
setblock 216 287 447 minecraft:gold_block
fill 216 287 448 225 287 448 minecraft:iron_block
fill 217 287 427 226 287 427 minecraft:iron_block
fill 217 287 428 218 287 428 minecraft:gold_block
fill 217 287 437 218 287 437 minecraft:gold_block
fill 217 287 446 218 287 446 minecraft:gold_block
fill 217 287 447 226 287 447 minecraft:iron_block
setblock 218 287 429 minecraft:gold_block
setblock 218 287 445 minecraft:gold_block
fill 219 287 428 226 287 429 minecraft:iron_block
setblock 219 287 430 minecraft:gold_block
setblock 219 287 444 minecraft:gold_block
fill 219 287 445 226 287 446 minecraft:iron_block
fill 220 287 430 227 287 430 minecraft:iron_block
fill 220 287 431 220 287 432 minecraft:gold_block
fill 220 287 442 220 287 443 minecraft:gold_block
fill 220 287 444 227 287 444 minecraft:iron_block
fill 221 287 431 228 287 432 minecraft:iron_block
fill 221 287 433 221 287 435 minecraft:gold_block
fill 221 287 439 221 287 441 minecraft:gold_block
fill 221 287 442 228 287 443 minecraft:iron_block
fill 222 287 433 228 287 435 minecraft:iron_block
fill 222 287 436 222 287 438 minecraft:gold_block
fill 222 287 439 228 287 441 minecraft:iron_block
fill 223 287 436 228 287 438 minecraft:iron_block
setblock 227 287 429 minecraft:iron_block
setblock 227 287 445 minecraft:iron_block
fill 229 287 437 229 300 439 minecraft:polished_deepslate
fill 191 288 432 195 288 442 minecraft:iron_block
fill 192 288 429 197 288 431 minecraft:iron_block
fill 192 288 443 197 288 445 minecraft:iron_block
fill 193 288 428 199 288 428 minecraft:iron_block
fill 193 288 446 199 288 446 minecraft:iron_block
fill 194 288 426 200 288 427 minecraft:iron_block
fill 194 288 447 200 288 448 minecraft:iron_block
fill 195 288 425 202 288 425 minecraft:iron_block
fill 195 288 449 202 288 449 minecraft:iron_block
fill 196 288 424 205 288 424 minecraft:iron_block
fill 196 288 432 196 288 433 minecraft:iron_block
fill 196 288 434 196 288 440 minecraft:polished_deepslate
fill 196 288 441 196 288 442 minecraft:iron_block
fill 196 288 450 205 288 450 minecraft:iron_block
fill 197 288 423 221 288 423 minecraft:iron_block
fill 197 288 432 197 288 435 minecraft:polished_deepslate
fill 197 288 439 197 288 442 minecraft:polished_deepslate
fill 197 288 451 221 288 451 minecraft:iron_block
fill 198 288 422 220 288 422 minecraft:iron_block
setblock 198 288 429 minecraft:iron_block
fill 198 288 430 198 288 431 minecraft:polished_deepslate
fill 198 288 437 200 288 437 minecraft:gold_block
fill 198 288 443 198 288 444 minecraft:polished_deepslate
setblock 198 288 445 minecraft:iron_block
fill 198 288 452 220 288 452 minecraft:iron_block
fill 199 288 429 199 288 430 minecraft:polished_deepslate
fill 199 288 432 201 288 432 minecraft:gold_block
fill 199 288 442 201 288 442 minecraft:gold_block
fill 199 288 444 199 288 445 minecraft:polished_deepslate
fill 200 288 421 218 288 421 minecraft:iron_block
setblock 200 288 428 minecraft:polished_deepslate
fill 200 288 431 200 289 431 minecraft:gold_block
fill 200 288 443 200 289 443 minecraft:gold_block
setblock 200 288 446 minecraft:polished_deepslate
fill 200 288 453 218 288 453 minecraft:iron_block
fill 201 288 420 217 288 420 minecraft:iron_block
setblock 201 288 426 minecraft:iron_block
setblock 201 288 427 minecraft:polished_deepslate
setblock 201 288 447 minecraft:polished_deepslate
setblock 201 288 448 minecraft:iron_block
fill 201 288 454 217 288 454 minecraft:iron_block
fill 202 288 426 203 288 426 minecraft:polished_deepslate
fill 202 288 448 203 288 448 minecraft:polished_deepslate
fill 203 288 425 206 288 425 minecraft:polished_deepslate
fill 203 288 428 204 289 428 minecraft:gold_block
fill 203 288 446 204 289 446 minecraft:gold_block
fill 203 288 449 206 288 449 minecraft:polished_deepslate
fill 204 288 419 214 288 419 minecraft:iron_block
fill 204 288 427 204 289 427 minecraft:gold_block
setblock 204 288 429 minecraft:gold_block
setblock 204 288 445 minecraft:gold_block
fill 204 288 447 204 289 447 minecraft:gold_block
fill 204 288 455 214 288 455 minecraft:iron_block
fill 206 288 424 212 288 424 minecraft:polished_deepslate
fill 206 288 450 212 288 450 minecraft:polished_deepslate
fill 209 288 426 209 288 428 minecraft:gold_block
fill 209 288 446 209 288 448 minecraft:gold_block
fill 213 288 424 222 288 424 minecraft:iron_block
fill 213 288 425 215 288 425 minecraft:polished_deepslate
fill 213 288 449 215 288 449 minecraft:polished_deepslate
fill 213 288 450 222 288 450 minecraft:iron_block
fill 214 288 427 214 288 429 minecraft:gold_block
fill 214 288 445 214 288 447 minecraft:gold_block
fill 215 288 428 215 289 428 minecraft:gold_block
fill 215 288 446 215 289 446 minecraft:gold_block
fill 216 288 425 223 288 425 minecraft:iron_block
setblock 216 288 426 minecraft:polished_deepslate
setblock 216 288 448 minecraft:polished_deepslate
fill 216 288 449 223 288 449 minecraft:iron_block
fill 217 288 426 224 288 426 minecraft:iron_block
fill 217 288 427 218 288 427 minecraft:polished_deepslate
fill 217 288 432 219 288 432 minecraft:gold_block
fill 217 288 442 219 288 442 minecraft:gold_block
fill 217 288 447 218 288 447 minecraft:polished_deepslate
fill 217 288 448 224 288 448 minecraft:iron_block
fill 218 288 431 218 289 431 minecraft:gold_block
fill 218 288 437 220 288 437 minecraft:gold_block
fill 218 288 443 218 289 443 minecraft:gold_block
fill 219 288 427 224 288 427 minecraft:iron_block
fill 219 288 428 219 288 429 minecraft:polished_deepslate
fill 219 288 445 219 288 446 minecraft:polished_deepslate
fill 219 288 447 224 288 447 minecraft:iron_block
fill 220 288 428 225 288 429 minecraft:iron_block
setblock 220 288 430 minecraft:polished_deepslate
setblock 220 288 444 minecraft:polished_deepslate
fill 220 288 445 225 288 446 minecraft:iron_block
fill 221 288 430 226 288 430 minecraft:iron_block
fill 221 288 431 221 288 432 minecraft:polished_deepslate
fill 221 288 442 221 288 443 minecraft:polished_deepslate
fill 221 288 444 226 288 444 minecraft:iron_block
fill 222 288 431 226 288 432 minecraft:iron_block
fill 222 288 433 222 288 441 minecraft:polished_deepslate
fill 222 288 442 226 288 443 minecraft:iron_block
fill 223 288 433 227 288 441 minecraft:iron_block
setblock 226 288 429 minecraft:iron_block
setblock 226 288 445 minecraft:iron_block
setblock 227 288 432 minecraft:iron_block
setblock 227 288 442 minecraft:iron_block
setblock 191 289 419 minecraft:light[level=13]
setblock 191 289 427 minecraft:light[level=13]
setblock 191 289 435 minecraft:light[level=13]
setblock 191 289 443 minecraft:light[level=13]
setblock 191 289 451 minecraft:light[level=13]
fill 192 289 435 194 289 439 minecraft:iron_block
fill 193 289 431 194 289 434 minecraft:iron_block
fill 193 289 440 194 289 443 minecraft:iron_block
fill 194 289 429 196 289 430 minecraft:iron_block
fill 194 289 444 196 289 445 minecraft:iron_block
fill 195 289 427 198 289 428 minecraft:iron_block
fill 195 289 431 195 289 433 minecraft:iron_block
fill 195 289 434 195 289 440 minecraft:gold_block
fill 195 289 441 195 289 443 minecraft:iron_block
fill 195 289 446 198 289 447 minecraft:iron_block
fill 196 289 426 200 289 426 minecraft:iron_block
setblock 196 289 431 minecraft:iron_block
fill 196 289 432 196 289 433 minecraft:gold_block
fill 196 289 436 198 289 438 minecraft:gold_block
fill 196 289 441 196 289 442 minecraft:gold_block
setblock 196 289 443 minecraft:iron_block
fill 196 289 448 200 289 448 minecraft:iron_block
fill 197 289 425 201 289 425 minecraft:iron_block
setblock 197 289 429 minecraft:iron_block
fill 197 289 430 199 290 431 minecraft:gold_block
fill 197 289 443 199 290 444 minecraft:gold_block
setblock 197 289 445 minecraft:iron_block
fill 197 289 449 201 289 449 minecraft:iron_block
fill 198 289 424 202 289 424 minecraft:iron_block
fill 198 289 429 198 290 429 minecraft:gold_block
fill 198 289 432 200 289 432 minecraft:gold_block
fill 198 289 442 200 289 442 minecraft:gold_block
fill 198 289 445 198 290 445 minecraft:gold_block
fill 198 289 450 202 289 450 minecraft:iron_block
setblock 199 289 419 minecraft:light[level=13]
fill 199 289 423 205 289 423 minecraft:iron_block
setblock 199 289 427 minecraft:iron_block
setblock 199 289 428 minecraft:gold_block
setblock 199 289 435 minecraft:light[level=13]
setblock 199 289 437 minecraft:gold_block
setblock 199 289 446 minecraft:gold_block
setblock 199 289 447 minecraft:iron_block
fill 199 289 451 205 289 451 minecraft:iron_block
setblock 200 289 427 minecraft:gold_block
setblock 200 289 447 minecraft:gold_block
fill 201 289 422 217 289 422 minecraft:iron_block
fill 201 289 426 204 289 426 minecraft:gold_block
fill 201 289 448 204 289 448 minecraft:gold_block
fill 201 289 452 217 289 452 minecraft:iron_block
fill 202 289 425 203 290 425 minecraft:gold_block
fill 202 289 427 203 290 427 minecraft:gold_block
fill 202 289 447 203 290 447 minecraft:gold_block
fill 202 289 449 203 290 449 minecraft:gold_block
fill 203 289 421 215 289 421 minecraft:iron_block
fill 203 289 424 205 289 424 minecraft:gold_block
fill 203 289 450 205 289 450 minecraft:gold_block
fill 203 289 453 215 289 453 minecraft:iron_block
fill 206 289 423 212 289 423 minecraft:gold_block
fill 206 289 451 212 289 451 minecraft:gold_block
setblock 207 289 419 minecraft:light[level=13]
fill 207 289 420 211 289 420 minecraft:iron_block
setblock 207 289 427 minecraft:light[level=13]
setblock 207 289 435 minecraft:light[level=13]
setblock 207 289 443 minecraft:light[level=13]
fill 207 289 454 211 289 454 minecraft:iron_block
fill 208 289 424 210 289 426 minecraft:gold_block
fill 208 289 448 210 289 450 minecraft:gold_block
setblock 209 289 427 minecraft:gold_block
setblock 209 289 447 minecraft:gold_block
fill 213 289 423 219 289 423 minecraft:iron_block
fill 213 289 424 215 289 424 minecraft:gold_block
fill 213 289 450 215 289 450 minecraft:gold_block
fill 213 289 451 219 289 451 minecraft:iron_block
fill 214 289 426 214 289 428 minecraft:gold_block
fill 214 289 446 214 289 448 minecraft:gold_block
setblock 215 289 419 minecraft:light[level=13]
fill 215 289 425 216 290 427 minecraft:gold_block
setblock 215 289 435 minecraft:light[level=13]
setblock 215 289 443 minecraft:light[level=13]
fill 215 289 447 216 290 449 minecraft:gold_block
fill 216 289 424 220 289 424 minecraft:iron_block
fill 216 289 450 220 289 450 minecraft:iron_block
fill 217 289 425 221 289 425 minecraft:iron_block
fill 217 289 426 218 289 426 minecraft:gold_block
fill 217 289 448 218 289 448 minecraft:gold_block
fill 217 289 449 221 289 449 minecraft:iron_block
fill 218 289 432 220 289 432 minecraft:gold_block
fill 218 289 442 220 289 442 minecraft:gold_block
fill 219 289 426 222 289 426 minecraft:iron_block
setblock 219 289 427 minecraft:gold_block
fill 219 289 430 221 290 431 minecraft:gold_block
fill 219 289 437 223 289 437 minecraft:gold_block
fill 219 289 443 221 290 444 minecraft:gold_block
setblock 219 289 447 minecraft:gold_block
fill 219 289 448 222 289 448 minecraft:iron_block
fill 220 289 427 223 289 427 minecraft:iron_block
fill 220 289 428 220 289 429 minecraft:gold_block
fill 220 289 436 223 289 436 minecraft:gold_block
fill 220 289 438 223 289 438 minecraft:gold_block
fill 220 289 445 220 289 446 minecraft:gold_block
fill 220 289 447 223 289 447 minecraft:iron_block
fill 221 289 428 223 289 429 minecraft:iron_block
fill 221 289 445 223 289 446 minecraft:iron_block
fill 222 289 430 224 289 430 minecraft:iron_block
fill 222 289 431 222 289 432 minecraft:gold_block
fill 222 289 442 222 289 443 minecraft:gold_block
fill 222 289 444 224 289 444 minecraft:iron_block
setblock 223 289 419 minecraft:light[level=13]
fill 223 289 431 225 289 432 minecraft:iron_block
fill 223 289 433 223 289 435 minecraft:gold_block
fill 223 289 439 223 289 441 minecraft:gold_block
fill 223 289 442 225 289 443 minecraft:iron_block
setblock 223 289 451 minecraft:light[level=13]
setblock 224 289 429 minecraft:iron_block
fill 224 289 433 225 289 441 minecraft:iron_block
setblock 224 289 445 minecraft:iron_block
fill 226 289 435 226 289 439 minecraft:iron_block
fill 194 290 437 197 290 437 minecraft:gold_block
fill 195 290 436 197 290 436 minecraft:gold_block
fill 195 290 438 197 290 438 minecraft:gold_block
fill 196 290 430 196 290 431 minecraft:gold_block
fill 196 290 443 196 290 444 minecraft:gold_block
setblock 197 290 429 minecraft:gold_block
setblock 197 290 445 minecraft:gold_block
fill 201 290 425 201 290 426 minecraft:gold_block
fill 201 290 448 201 290 449 minecraft:gold_block
fill 202 290 424 203 290 424 minecraft:gold_block
fill 202 290 426 203 290 426 minecraft:gold_block
fill 202 290 448 203 290 448 minecraft:gold_block
fill 202 290 450 203 290 450 minecraft:gold_block
fill 208 290 423 210 290 425 minecraft:gold_block
fill 208 290 449 210 290 451 minecraft:gold_block
setblock 209 290 422 minecraft:gold_block
setblock 209 290 452 minecraft:gold_block
fill 215 290 424 216 290 424 minecraft:gold_block
fill 215 290 450 216 290 450 minecraft:gold_block
fill 217 290 425 217 290 426 minecraft:gold_block
fill 217 290 448 217 290 449 minecraft:gold_block
fill 220 290 429 221 290 429 minecraft:gold_block
fill 220 290 445 221 290 445 minecraft:gold_block
fill 221 290 436 223 290 438 minecraft:gold_block
fill 222 290 430 222 290 431 minecraft:gold_block
fill 222 290 443 222 290 444 minecraft:gold_block
setblock 224 290 437 minecraft:gold_block
fill 188 292 422 188 307 422 minecraft:stone
fill 188 292 423 188 292 424 minecraft:shroomlight
fill 188 292 425 188 307 425 minecraft:stone
fill 188 292 434 188 307 434 minecraft:stone
fill 188 292 435 188 292 436 minecraft:shroomlight
fill 188 292 437 188 307 437 minecraft:stone
fill 188 292 446 188 307 446 minecraft:stone
fill 188 292 447 188 292 448 minecraft:shroomlight
fill 188 292 449 188 307 449 minecraft:stone
fill 188 292 458 188 307 458 minecraft:stone
fill 189 292 458 190 292 458 minecraft:shroomlight
fill 191 292 458 191 307 458 minecraft:stone
fill 195 292 416 195 307 416 minecraft:stone
fill 196 292 416 197 292 416 minecraft:shroomlight
fill 198 292 416 198 307 416 minecraft:stone
fill 200 292 458 200 307 458 minecraft:stone
fill 201 292 458 202 292 458 minecraft:shroomlight
fill 203 292 458 203 307 458 minecraft:stone
fill 207 292 416 207 307 416 minecraft:stone
fill 208 292 416 209 292 416 minecraft:shroomlight
fill 210 292 416 210 307 416 minecraft:stone
fill 212 292 458 212 307 458 minecraft:stone
fill 213 292 458 214 292 458 minecraft:shroomlight
fill 215 292 458 215 307 458 minecraft:stone
fill 219 292 416 219 307 416 minecraft:stone
fill 220 292 416 221 292 416 minecraft:shroomlight
fill 222 292 416 222 307 416 minecraft:stone
fill 224 292 458 224 307 458 minecraft:stone
fill 225 292 458 226 292 458 minecraft:shroomlight
fill 227 292 458 227 307 458 minecraft:stone
fill 230 292 417 230 307 417 minecraft:stone
fill 230 292 418 230 292 419 minecraft:shroomlight
fill 230 292 420 230 307 420 minecraft:stone
fill 230 292 429 230 307 429 minecraft:stone
fill 230 292 430 230 292 431 minecraft:shroomlight
fill 230 292 432 230 307 432 minecraft:stone
fill 230 292 441 230 307 441 minecraft:stone
fill 230 292 442 230 292 443 minecraft:shroomlight
fill 230 292 444 230 307 444 minecraft:stone
fill 230 292 453 230 307 453 minecraft:stone
fill 230 292 454 230 292 455 minecraft:shroomlight
fill 230 292 456 230 307 456 minecraft:stone
fill 188 293 423 188 307 424 minecraft:stone
fill 188 293 435 188 307 436 minecraft:stone
fill 188 293 447 188 307 448 minecraft:stone
fill 189 293 458 190 307 458 minecraft:stone
fill 196 293 416 197 307 416 minecraft:stone
fill 201 293 458 202 307 458 minecraft:stone
fill 208 293 416 209 307 416 minecraft:stone
fill 213 293 458 214 307 458 minecraft:stone
fill 220 293 416 221 307 416 minecraft:stone
fill 225 293 458 226 307 458 minecraft:stone
fill 230 293 418 230 307 419 minecraft:stone
fill 230 293 430 230 307 431 minecraft:stone
fill 230 293 442 230 307 443 minecraft:stone
fill 230 293 454 230 307 455 minecraft:stone
fill 189 295 437 191 296 437 minecraft:iron_block
setblock 191 297 419 minecraft:light[level=13]
setblock 191 297 427 minecraft:light[level=13]
setblock 191 297 435 minecraft:light[level=13]
setblock 191 297 443 minecraft:light[level=13]
setblock 191 297 451 minecraft:light[level=13]
setblock 199 297 419 minecraft:light[level=13]
setblock 199 297 427 minecraft:light[level=13]
setblock 199 297 435 minecraft:light[level=13]
setblock 199 297 443 minecraft:light[level=13]
setblock 199 297 451 minecraft:light[level=13]
setblock 207 297 419 minecraft:light[level=13]
setblock 207 297 427 minecraft:light[level=13]
setblock 207 297 435 minecraft:light[level=13]
setblock 207 297 443 minecraft:light[level=13]
setblock 207 297 451 minecraft:light[level=13]
setblock 215 297 419 minecraft:light[level=13]
setblock 215 297 427 minecraft:light[level=13]
setblock 215 297 435 minecraft:light[level=13]
setblock 215 297 443 minecraft:light[level=13]
setblock 215 297 451 minecraft:light[level=13]
setblock 223 297 419 minecraft:light[level=13]
setblock 223 297 427 minecraft:light[level=13]
setblock 223 297 435 minecraft:light[level=13]
setblock 223 297 443 minecraft:light[level=13]
setblock 223 297 451 minecraft:light[level=13]
fill 190 300 426 190 300 428 minecraft:polished_deepslate
fill 190 300 438 190 300 440 minecraft:polished_deepslate
fill 190 300 450 190 300 452 minecraft:polished_deepslate
fill 196 300 456 198 300 456 minecraft:polished_deepslate
fill 200 300 418 202 300 418 minecraft:polished_deepslate
fill 208 300 456 210 300 456 minecraft:polished_deepslate
fill 212 300 418 214 300 418 minecraft:polished_deepslate
fill 220 300 456 222 300 456 minecraft:polished_deepslate
fill 224 300 418 226 300 418 minecraft:polished_deepslate
fill 228 300 426 228 300 428 minecraft:polished_deepslate
fill 228 300 438 228 300 440 minecraft:polished_deepslate
fill 228 300 450 228 300 452 minecraft:polished_deepslate
