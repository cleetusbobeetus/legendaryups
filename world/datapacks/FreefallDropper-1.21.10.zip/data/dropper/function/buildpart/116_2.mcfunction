fill 380 200 485 380 201 485 minecraft:black_concrete
fill 381 200 480 381 201 480 minecraft:black_concrete
fill 381 200 482 381 201 482 minecraft:black_concrete
fill 381 200 484 381 201 484 minecraft:black_concrete
fill 382 200 479 382 201 479 minecraft:black_concrete
fill 382 200 481 382 201 481 minecraft:black_concrete
fill 382 200 483 382 201 483 minecraft:black_concrete
fill 382 200 485 382 201 485 minecraft:black_concrete
fill 383 200 463 383 205 463 minecraft:sea_lantern
setblock 387 200 466 minecraft:light[level=14]
setblock 387 200 474 minecraft:light[level=14]
setblock 387 200 482 minecraft:light[level=14]
setblock 387 200 490 minecraft:light[level=14]
setblock 387 200 498 minecraft:light[level=14]
fill 387 200 505 387 205 505 minecraft:sea_lantern
fill 391 200 463 391 205 463 minecraft:sea_lantern
setblock 395 200 466 minecraft:light[level=14]
setblock 395 200 474 minecraft:light[level=14]
setblock 395 200 482 minecraft:light[level=14]
setblock 395 200 490 minecraft:light[level=14]
setblock 395 200 498 minecraft:light[level=14]
fill 395 200 505 395 205 505 minecraft:sea_lantern
fill 399 200 463 399 205 463 minecraft:sea_lantern
fill 401 200 489 402 201 490 minecraft:lime_concrete
setblock 403 200 466 minecraft:light[level=14]
setblock 403 200 474 minecraft:light[level=14]
setblock 403 200 482 minecraft:light[level=14]
setblock 403 200 490 minecraft:light[level=14]
setblock 403 200 498 minecraft:light[level=14]
fill 403 200 505 403 205 505 minecraft:sea_lantern
fill 407 200 463 407 205 463 minecraft:sea_lantern
setblock 411 200 466 minecraft:light[level=14]
setblock 411 200 474 minecraft:light[level=14]
setblock 411 200 482 minecraft:light[level=14]
setblock 411 200 490 minecraft:light[level=14]
setblock 411 200 498 minecraft:light[level=14]
fill 411 200 505 411 205 505 minecraft:sea_lantern
fill 415 200 463 415 205 463 minecraft:sea_lantern
fill 418 200 468 418 205 468 minecraft:sea_lantern
fill 418 200 476 418 205 476 minecraft:sea_lantern
fill 418 200 484 418 205 484 minecraft:sea_lantern
fill 418 200 492 418 205 492 minecraft:sea_lantern
fill 418 200 500 418 205 500 minecraft:sea_lantern
setblock 377 202 480 minecraft:sea_lantern
setblock 377 202 482 minecraft:sea_lantern
setblock 377 202 484 minecraft:sea_lantern
setblock 378 202 479 minecraft:sea_lantern
setblock 378 202 481 minecraft:sea_lantern
setblock 378 202 483 minecraft:sea_lantern
setblock 378 202 485 minecraft:sea_lantern
setblock 379 202 480 minecraft:sea_lantern
setblock 379 202 482 minecraft:sea_lantern
setblock 379 202 484 minecraft:sea_lantern
fill 379 202 491 381 204 493 minecraft:gold_block
setblock 380 202 479 minecraft:sea_lantern
setblock 380 202 481 minecraft:sea_lantern
setblock 380 202 483 minecraft:sea_lantern
setblock 380 202 485 minecraft:sea_lantern
setblock 381 202 480 minecraft:sea_lantern
setblock 381 202 482 minecraft:sea_lantern
setblock 381 202 484 minecraft:sea_lantern
setblock 382 202 479 minecraft:sea_lantern
setblock 382 202 481 minecraft:sea_lantern
setblock 382 202 483 minecraft:sea_lantern
setblock 382 202 485 minecraft:sea_lantern
fill 392 202 478 394 204 480 minecraft:white_concrete
fill 377 203 480 377 204 480 minecraft:black_concrete
fill 377 203 482 377 204 482 minecraft:black_concrete
fill 377 203 484 377 204 484 minecraft:black_concrete
fill 378 203 479 378 204 479 minecraft:black_concrete
fill 378 203 481 378 204 481 minecraft:black_concrete
fill 378 203 483 378 204 483 minecraft:black_concrete
fill 378 203 485 378 204 485 minecraft:black_concrete
fill 379 203 480 379 204 480 minecraft:black_concrete
fill 379 203 482 379 204 482 minecraft:black_concrete
fill 379 203 484 379 204 484 minecraft:black_concrete
fill 380 203 479 380 204 479 minecraft:black_concrete
fill 380 203 481 380 204 481 minecraft:black_concrete
fill 380 203 483 380 204 483 minecraft:black_concrete
fill 380 203 485 380 204 485 minecraft:black_concrete
fill 381 203 480 381 204 480 minecraft:black_concrete
fill 381 203 482 381 204 482 minecraft:black_concrete
fill 381 203 484 381 204 484 minecraft:black_concrete
fill 382 203 479 382 204 479 minecraft:black_concrete
fill 382 203 481 382 204 481 minecraft:black_concrete
fill 382 203 483 382 204 483 minecraft:black_concrete
fill 382 203 485 382 204 485 minecraft:black_concrete
setblock 377 205 480 minecraft:sea_lantern
setblock 377 205 482 minecraft:sea_lantern
setblock 377 205 484 minecraft:sea_lantern
setblock 378 205 479 minecraft:sea_lantern
setblock 378 205 481 minecraft:sea_lantern
setblock 378 205 483 minecraft:sea_lantern
setblock 378 205 485 minecraft:sea_lantern
setblock 379 205 480 minecraft:sea_lantern
setblock 379 205 482 minecraft:sea_lantern
setblock 379 205 484 minecraft:sea_lantern
setblock 380 205 479 minecraft:sea_lantern
setblock 380 205 481 minecraft:sea_lantern
setblock 380 205 483 minecraft:sea_lantern
setblock 380 205 485 minecraft:sea_lantern
setblock 381 205 480 minecraft:sea_lantern
setblock 381 205 482 minecraft:sea_lantern
setblock 381 205 484 minecraft:sea_lantern
setblock 382 205 479 minecraft:sea_lantern
setblock 382 205 481 minecraft:sea_lantern
setblock 382 205 483 minecraft:sea_lantern
setblock 382 205 485 minecraft:sea_lantern
fill 376 206 468 376 213 468 minecraft:black_concrete
fill 376 206 476 376 213 476 minecraft:black_concrete
fill 376 206 484 377 207 484 minecraft:black_concrete
fill 376 206 492 376 213 492 minecraft:black_concrete
fill 376 206 500 376 213 500 minecraft:black_concrete
fill 377 206 480 377 207 480 minecraft:black_concrete
fill 377 206 482 377 207 482 minecraft:black_concrete
fill 378 206 479 378 207 479 minecraft:black_concrete
fill 378 206 481 378 207 481 minecraft:black_concrete
fill 378 206 483 378 207 483 minecraft:black_concrete
fill 378 206 485 378 207 485 minecraft:black_concrete
fill 379 206 480 379 207 480 minecraft:black_concrete
fill 379 206 482 379 207 482 minecraft:black_concrete
fill 379 206 484 379 207 484 minecraft:black_concrete
fill 379 206 505 379 213 505 minecraft:black_concrete
fill 380 206 479 380 207 479 minecraft:black_concrete
fill 380 206 481 380 207 481 minecraft:black_concrete
fill 380 206 483 380 207 483 minecraft:black_concrete
fill 380 206 485 380 207 485 minecraft:black_concrete
fill 381 206 480 381 207 480 minecraft:black_concrete
fill 381 206 482 381 207 482 minecraft:black_concrete
fill 381 206 484 381 207 484 minecraft:black_concrete
fill 382 206 479 382 207 479 minecraft:black_concrete
fill 382 206 481 382 207 481 minecraft:black_concrete
fill 382 206 483 382 207 483 minecraft:black_concrete
fill 382 206 485 382 207 485 minecraft:black_concrete
fill 383 206 463 383 213 463 minecraft:black_concrete
fill 387 206 505 387 213 505 minecraft:black_concrete
fill 391 206 463 391 213 463 minecraft:black_concrete
fill 395 206 505 395 213 505 minecraft:black_concrete
fill 399 206 463 399 213 463 minecraft:black_concrete
fill 403 206 505 403 213 505 minecraft:black_concrete
fill 407 206 463 407 213 463 minecraft:black_concrete
fill 411 206 505 411 213 505 minecraft:black_concrete
fill 415 206 463 415 213 463 minecraft:black_concrete
fill 418 206 468 418 213 468 minecraft:black_concrete
fill 418 206 476 418 213 476 minecraft:black_concrete
fill 418 206 484 418 213 484 minecraft:black_concrete
fill 418 206 492 418 213 492 minecraft:black_concrete
fill 418 206 500 418 213 500 minecraft:black_concrete
fill 376 208 484 376 213 484 minecraft:black_concrete
setblock 377 208 480 minecraft:sea_lantern
setblock 377 208 482 minecraft:sea_lantern
setblock 377 208 484 minecraft:sea_lantern
setblock 378 208 479 minecraft:sea_lantern
setblock 378 208 481 minecraft:sea_lantern
setblock 378 208 483 minecraft:sea_lantern
setblock 378 208 485 minecraft:sea_lantern
setblock 379 208 466 minecraft:light[level=14]
setblock 379 208 474 minecraft:light[level=14]
setblock 379 208 480 minecraft:sea_lantern
setblock 379 208 482 minecraft:sea_lantern
setblock 379 208 484 minecraft:sea_lantern
setblock 379 208 490 minecraft:light[level=14]
setblock 379 208 498 minecraft:light[level=14]
setblock 380 208 479 minecraft:sea_lantern
setblock 380 208 481 minecraft:sea_lantern
setblock 380 208 483 minecraft:sea_lantern
setblock 380 208 485 minecraft:sea_lantern
fill 380 208 490 380 213 490 minecraft:magenta_concrete
setblock 381 208 480 minecraft:sea_lantern
setblock 381 208 482 minecraft:sea_lantern
setblock 381 208 484 minecraft:sea_lantern
setblock 382 208 479 minecraft:sea_lantern
setblock 382 208 481 minecraft:sea_lantern
setblock 382 208 483 minecraft:sea_lantern
setblock 382 208 485 minecraft:sea_lantern
setblock 387 208 466 minecraft:light[level=14]
setblock 387 208 474 minecraft:light[level=14]
setblock 387 208 482 minecraft:light[level=14]
setblock 387 208 490 minecraft:light[level=14]
setblock 387 208 498 minecraft:light[level=14]
setblock 395 208 466 minecraft:light[level=14]
setblock 395 208 474 minecraft:light[level=14]
setblock 395 208 482 minecraft:light[level=14]
setblock 395 208 490 minecraft:light[level=14]
setblock 395 208 498 minecraft:light[level=14]
fill 398 208 496 400 210 498 minecraft:gold_block
setblock 403 208 466 minecraft:light[level=14]
setblock 403 208 474 minecraft:light[level=14]
setblock 403 208 482 minecraft:light[level=14]
setblock 403 208 490 minecraft:light[level=14]
setblock 403 208 498 minecraft:light[level=14]
setblock 411 208 466 minecraft:light[level=14]
setblock 411 208 474 minecraft:light[level=14]
setblock 411 208 482 minecraft:light[level=14]
setblock 411 208 490 minecraft:light[level=14]
setblock 411 208 498 minecraft:light[level=14]
fill 377 209 480 377 211 480 minecraft:black_concrete
fill 377 209 482 377 211 482 minecraft:black_concrete
fill 377 209 484 377 211 484 minecraft:black_concrete
fill 378 209 479 378 210 479 minecraft:black_concrete
fill 378 209 481 378 210 481 minecraft:black_concrete
fill 378 209 483 378 210 483 minecraft:black_concrete
fill 378 209 485 378 210 485 minecraft:black_concrete
fill 379 209 480 379 210 480 minecraft:black_concrete
fill 379 209 482 379 210 482 minecraft:black_concrete
fill 379 209 484 379 210 484 minecraft:black_concrete
fill 380 209 479 380 210 479 minecraft:black_concrete
fill 380 209 481 380 210 481 minecraft:black_concrete
fill 380 209 483 380 210 483 minecraft:black_concrete
fill 380 209 485 380 210 485 minecraft:black_concrete
fill 381 209 480 381 210 480 minecraft:black_concrete
fill 381 209 482 381 210 482 minecraft:black_concrete
fill 381 209 484 381 210 484 minecraft:black_concrete
fill 381 209 490 381 213 490 minecraft:magenta_concrete
fill 382 209 479 382 210 479 minecraft:black_concrete
fill 382 209 481 382 210 481 minecraft:black_concrete
fill 382 209 483 382 210 483 minecraft:black_concrete
fill 382 209 485 382 210 485 minecraft:black_concrete
fill 377 210 464 377 211 469 minecraft:black_concrete
fill 377 210 472 378 210 477 minecraft:black_concrete
fill 377 210 488 378 210 493 minecraft:black_concrete
fill 377 210 496 378 210 501 minecraft:black_concrete
fill 377 210 504 382 211 504 minecraft:black_concrete
fill 378 210 465 378 210 471 minecraft:black_concrete
setblock 378 210 478 minecraft:black_concrete
fill 378 210 486 378 210 487 minecraft:black_concrete
fill 378 210 494 378 210 495 minecraft:black_concrete
fill 378 210 502 378 210 503 minecraft:black_concrete
fill 379 210 465 416 210 465 minecraft:black_concrete
fill 379 210 490 379 213 490 minecraft:magenta_concrete
fill 379 210 503 417 210 503 minecraft:black_concrete
fill 380 210 464 385 211 464 minecraft:black_concrete
fill 380 210 489 381 213 489 minecraft:magenta_concrete
fill 380 210 491 381 213 491 minecraft:magenta_concrete
fill 385 210 504 390 211 504 minecraft:black_concrete
fill 388 210 464 393 211 464 minecraft:black_concrete
fill 393 210 504 398 211 504 minecraft:black_concrete
fill 396 210 464 401 211 464 minecraft:black_concrete
fill 401 210 504 406 211 504 minecraft:black_concrete
fill 404 210 464 409 211 464 minecraft:black_concrete
fill 409 210 504 414 211 504 minecraft:black_concrete
fill 412 210 464 417 211 464 minecraft:black_concrete
fill 416 210 466 416 210 502 minecraft:black_concrete
fill 417 210 467 417 211 472 minecraft:black_concrete
fill 417 210 475 417 211 480 minecraft:black_concrete
fill 417 210 483 417 211 488 minecraft:black_concrete
fill 417 210 491 417 211 496 minecraft:black_concrete
fill 417 210 499 417 211 502 minecraft:black_concrete
fill 417 210 504 417 211 504 minecraft:black_concrete
fill 377 211 472 377 211 477 minecraft:black_concrete
fill 377 211 488 377 211 493 minecraft:black_concrete
fill 377 211 496 377 211 501 minecraft:black_concrete
fill 379 211 489 379 213 489 minecraft:magenta_concrete
fill 379 211 491 379 213 491 minecraft:magenta_concrete
fill 380 211 488 380 213 488 minecraft:magenta_concrete
fill 380 211 492 380 213 492 minecraft:magenta_concrete
fill 382 211 489 382 213 491 minecraft:magenta_concrete
setblock 417 211 503 minecraft:black_concrete
fill 377 212 486 377 216 487 minecraft:black_concrete
fill 378 212 489 378 213 491 minecraft:magenta_concrete
fill 379 212 488 379 213 488 minecraft:magenta_concrete
fill 379 212 492 379 213 492 minecraft:magenta_concrete
fill 381 212 488 381 213 488 minecraft:magenta_concrete
fill 381 212 492 381 213 492 minecraft:magenta_concrete
setblock 378 213 488 minecraft:magenta_concrete
setblock 378 213 492 minecraft:magenta_concrete
fill 380 213 487 381 213 487 minecraft:magenta_concrete
fill 380 213 493 381 213 493 minecraft:magenta_concrete
setblock 382 213 488 minecraft:magenta_concrete
setblock 382 213 492 minecraft:magenta_concrete
fill 383 213 489 383 213 491 minecraft:magenta_concrete
fill 376 214 468 376 219 468 minecraft:sea_lantern
fill 376 214 476 376 219 476 minecraft:sea_lantern
fill 376 214 484 376 219 484 minecraft:sea_lantern
fill 376 214 492 376 219 492 minecraft:sea_lantern
fill 376 214 500 376 219 500 minecraft:sea_lantern
fill 377 214 484 384 216 485 minecraft:black_concrete
fill 377 214 488 384 216 493 minecraft:black_concrete
fill 377 214 496 384 216 496 minecraft:black_concrete
fill 378 214 486 384 216 487 minecraft:black_concrete
fill 378 214 494 384 216 495 minecraft:black_concrete
fill 379 214 505 379 219 505 minecraft:sea_lantern
fill 383 214 463 383 219 463 minecraft:sea_lantern
fill 387 214 505 387 219 505 minecraft:sea_lantern
fill 391 214 463 391 219 463 minecraft:sea_lantern
fill 395 214 505 395 219 505 minecraft:sea_lantern
fill 399 214 463 399 219 463 minecraft:sea_lantern
fill 403 214 505 403 219 505 minecraft:sea_lantern
fill 407 214 463 407 219 463 minecraft:sea_lantern
fill 411 214 505 411 219 505 minecraft:sea_lantern
fill 415 214 463 415 219 463 minecraft:sea_lantern
fill 418 214 468 418 219 468 minecraft:sea_lantern
fill 418 214 476 418 219 476 minecraft:sea_lantern
fill 418 214 484 418 219 484 minecraft:sea_lantern
fill 418 214 492 418 219 492 minecraft:sea_lantern
fill 418 214 500 418 219 500 minecraft:sea_lantern
setblock 379 216 466 minecraft:light[level=14]
setblock 379 216 474 minecraft:light[level=14]
setblock 379 216 482 minecraft:light[level=14]
setblock 379 216 498 minecraft:light[level=14]
setblock 387 216 466 minecraft:light[level=14]
setblock 387 216 474 minecraft:light[level=14]
setblock 387 216 482 minecraft:light[level=14]
setblock 387 216 490 minecraft:light[level=14]
setblock 387 216 498 minecraft:light[level=14]
setblock 395 216 466 minecraft:light[level=14]
setblock 395 216 474 minecraft:light[level=14]
setblock 395 216 482 minecraft:light[level=14]
setblock 395 216 490 minecraft:light[level=14]
setblock 395 216 498 minecraft:light[level=14]
setblock 403 216 466 minecraft:light[level=14]
setblock 403 216 474 minecraft:light[level=14]
setblock 403 216 482 minecraft:light[level=14]
setblock 403 216 490 minecraft:light[level=14]
setblock 403 216 498 minecraft:light[level=14]
setblock 411 216 466 minecraft:light[level=14]
setblock 411 216 474 minecraft:light[level=14]
setblock 411 216 482 minecraft:light[level=14]
setblock 411 216 490 minecraft:light[level=14]
setblock 411 216 498 minecraft:light[level=14]
setblock 377 217 484 minecraft:sea_lantern
fill 377 217 485 377 230 485 minecraft:black_concrete
setblock 377 217 486 minecraft:sea_lantern
fill 377 217 487 377 230 487 minecraft:black_concrete
setblock 377 217 488 minecraft:sea_lantern
fill 377 217 489 377 230 489 minecraft:black_concrete
setblock 377 217 490 minecraft:sea_lantern
fill 377 217 491 377 230 491 minecraft:black_concrete
setblock 377 217 492 minecraft:sea_lantern
fill 377 217 493 377 230 493 minecraft:black_concrete
setblock 377 217 494 minecraft:sea_lantern
fill 377 217 495 377 230 495 minecraft:black_concrete
setblock 377 217 496 minecraft:sea_lantern
fill 378 217 484 378 230 484 minecraft:black_concrete
setblock 378 217 485 minecraft:sea_lantern
fill 378 217 486 378 230 486 minecraft:black_concrete
setblock 378 217 487 minecraft:sea_lantern
fill 378 217 488 378 230 488 minecraft:black_concrete
setblock 378 217 489 minecraft:sea_lantern
fill 378 217 490 378 230 490 minecraft:black_concrete
setblock 378 217 491 minecraft:sea_lantern
fill 378 217 492 378 230 492 minecraft:black_concrete
setblock 378 217 493 minecraft:sea_lantern
fill 378 217 494 378 230 494 minecraft:black_concrete
setblock 378 217 495 minecraft:sea_lantern
fill 378 217 496 378 230 496 minecraft:black_concrete
setblock 379 217 484 minecraft:sea_lantern
fill 379 217 485 379 230 485 minecraft:black_concrete
setblock 379 217 486 minecraft:sea_lantern
fill 379 217 487 379 230 487 minecraft:black_concrete
setblock 379 217 488 minecraft:sea_lantern
fill 379 217 489 379 230 489 minecraft:black_concrete
setblock 379 217 490 minecraft:sea_lantern
fill 379 217 491 379 230 491 minecraft:black_concrete
setblock 379 217 492 minecraft:sea_lantern
fill 379 217 493 379 230 493 minecraft:black_concrete
setblock 379 217 494 minecraft:sea_lantern
fill 379 217 495 379 230 495 minecraft:black_concrete
setblock 379 217 496 minecraft:sea_lantern
fill 380 217 484 380 230 484 minecraft:black_concrete
setblock 380 217 485 minecraft:sea_lantern
fill 380 217 486 380 230 486 minecraft:black_concrete
setblock 380 217 487 minecraft:sea_lantern
fill 380 217 488 380 230 488 minecraft:black_concrete
setblock 380 217 489 minecraft:sea_lantern
fill 380 217 490 380 230 490 minecraft:black_concrete
setblock 380 217 491 minecraft:sea_lantern
fill 380 217 492 380 230 492 minecraft:black_concrete
setblock 380 217 493 minecraft:sea_lantern
fill 380 217 494 380 230 494 minecraft:black_concrete
setblock 380 217 495 minecraft:sea_lantern
fill 380 217 496 380 230 496 minecraft:black_concrete
setblock 381 217 484 minecraft:sea_lantern
fill 381 217 485 381 230 485 minecraft:black_concrete
setblock 381 217 486 minecraft:sea_lantern
fill 381 217 487 381 230 487 minecraft:black_concrete
setblock 381 217 488 minecraft:sea_lantern
fill 381 217 489 381 230 489 minecraft:black_concrete
setblock 381 217 490 minecraft:sea_lantern
fill 381 217 491 381 230 491 minecraft:black_concrete
setblock 381 217 492 minecraft:sea_lantern
fill 381 217 493 381 229 493 minecraft:black_concrete
setblock 381 217 494 minecraft:sea_lantern
fill 381 217 495 381 229 495 minecraft:black_concrete
setblock 381 217 496 minecraft:sea_lantern
fill 382 217 484 382 230 484 minecraft:black_concrete
setblock 382 217 485 minecraft:sea_lantern
fill 382 217 486 382 230 486 minecraft:black_concrete
setblock 382 217 487 minecraft:sea_lantern
fill 382 217 488 382 230 488 minecraft:black_concrete
setblock 382 217 489 minecraft:sea_lantern
fill 382 217 490 382 230 490 minecraft:black_concrete
setblock 382 217 491 minecraft:sea_lantern
fill 382 217 492 382 230 492 minecraft:black_concrete
setblock 382 217 493 minecraft:sea_lantern
fill 382 217 494 382 229 494 minecraft:black_concrete
setblock 382 217 495 minecraft:sea_lantern
fill 382 217 496 382 230 496 minecraft:black_concrete
setblock 383 217 484 minecraft:sea_lantern
fill 383 217 485 383 230 485 minecraft:black_concrete
setblock 383 217 486 minecraft:sea_lantern
fill 383 217 487 383 230 487 minecraft:black_concrete
setblock 383 217 488 minecraft:sea_lantern
fill 383 217 489 383 230 489 minecraft:black_concrete
setblock 383 217 490 minecraft:sea_lantern
fill 383 217 491 383 230 491 minecraft:black_concrete
setblock 383 217 492 minecraft:sea_lantern
fill 383 217 493 383 229 493 minecraft:black_concrete
setblock 383 217 494 minecraft:sea_lantern
fill 383 217 495 383 229 495 minecraft:black_concrete
setblock 383 217 496 minecraft:sea_lantern
fill 384 217 484 384 230 484 minecraft:black_concrete
setblock 384 217 485 minecraft:sea_lantern
fill 384 217 486 384 230 486 minecraft:black_concrete
setblock 384 217 487 minecraft:sea_lantern
fill 384 217 488 384 230 488 minecraft:black_concrete
setblock 384 217 489 minecraft:sea_lantern
fill 384 217 490 384 230 490 minecraft:black_concrete
setblock 384 217 491 minecraft:sea_lantern
fill 384 217 492 384 230 492 minecraft:black_concrete
setblock 384 217 493 minecraft:sea_lantern
fill 384 217 494 384 230 494 minecraft:black_concrete
setblock 384 217 495 minecraft:sea_lantern
fill 384 217 496 384 230 496 minecraft:black_concrete
fill 377 218 484 377 219 484 minecraft:black_concrete
fill 377 218 486 377 219 486 minecraft:black_concrete
fill 377 218 488 377 219 488 minecraft:black_concrete
fill 377 218 490 377 219 490 minecraft:black_concrete
fill 377 218 492 377 219 492 minecraft:black_concrete
fill 377 218 494 377 219 494 minecraft:black_concrete
fill 377 218 496 377 219 496 minecraft:black_concrete
fill 378 218 485 378 219 485 minecraft:black_concrete
fill 378 218 487 378 219 487 minecraft:black_concrete
fill 378 218 489 378 219 489 minecraft:black_concrete
fill 378 218 491 378 219 491 minecraft:black_concrete
fill 378 218 493 378 219 493 minecraft:black_concrete
fill 378 218 495 378 219 495 minecraft:black_concrete
fill 379 218 484 379 219 484 minecraft:black_concrete
fill 379 218 486 379 219 486 minecraft:black_concrete
fill 379 218 488 379 219 488 minecraft:black_concrete
fill 379 218 490 379 219 490 minecraft:black_concrete
fill 379 218 492 379 219 492 minecraft:black_concrete
fill 379 218 494 379 219 494 minecraft:black_concrete
fill 379 218 496 379 219 496 minecraft:black_concrete
fill 380 218 485 380 219 485 minecraft:black_concrete
fill 380 218 487 380 219 487 minecraft:black_concrete
fill 380 218 489 380 219 489 minecraft:black_concrete
fill 380 218 491 380 219 491 minecraft:black_concrete
fill 380 218 493 380 219 493 minecraft:black_concrete
fill 380 218 495 380 219 495 minecraft:black_concrete
fill 381 218 484 381 219 484 minecraft:black_concrete
fill 381 218 486 381 219 486 minecraft:black_concrete
fill 381 218 488 381 219 488 minecraft:black_concrete
fill 381 218 490 381 219 490 minecraft:black_concrete
fill 381 218 492 381 219 492 minecraft:black_concrete
fill 381 218 494 381 219 494 minecraft:black_concrete
fill 381 218 496 381 219 496 minecraft:black_concrete
fill 382 218 485 382 219 485 minecraft:black_concrete
fill 382 218 487 382 219 487 minecraft:black_concrete
fill 382 218 489 382 219 489 minecraft:black_concrete
fill 382 218 491 382 219 491 minecraft:black_concrete
fill 382 218 493 382 219 493 minecraft:black_concrete
fill 382 218 495 382 219 495 minecraft:black_concrete
fill 383 218 484 383 219 484 minecraft:black_concrete
fill 383 218 486 383 219 486 minecraft:black_concrete
fill 383 218 488 383 219 488 minecraft:black_concrete
fill 383 218 490 383 219 490 minecraft:black_concrete
fill 383 218 492 383 219 492 minecraft:black_concrete
fill 383 218 494 383 219 494 minecraft:black_concrete
fill 383 218 496 383 219 496 minecraft:black_concrete
fill 384 218 485 384 219 485 minecraft:black_concrete
fill 384 218 487 384 219 487 minecraft:black_concrete
fill 384 218 489 384 219 489 minecraft:black_concrete
fill 384 218 491 384 219 491 minecraft:black_concrete
fill 384 218 493 384 219 493 minecraft:black_concrete
fill 384 218 495 384 219 495 minecraft:black_concrete
fill 400 219 494 401 220 495 minecraft:white_concrete
fill 409 219 499 412 222 502 minecraft:lime_concrete
fill 376 220 468 376 227 468 minecraft:black_concrete
fill 376 220 476 376 227 476 minecraft:black_concrete
fill 376 220 484 376 227 484 minecraft:black_concrete
fill 376 220 492 376 227 492 minecraft:black_concrete
fill 376 220 500 376 227 500 minecraft:black_concrete
setblock 377 220 484 minecraft:sea_lantern
setblock 377 220 486 minecraft:sea_lantern
setblock 377 220 488 minecraft:sea_lantern
setblock 377 220 490 minecraft:sea_lantern
setblock 377 220 492 minecraft:sea_lantern
setblock 377 220 494 minecraft:sea_lantern
setblock 377 220 496 minecraft:sea_lantern
setblock 378 220 485 minecraft:sea_lantern
setblock 378 220 487 minecraft:sea_lantern
setblock 378 220 489 minecraft:sea_lantern
setblock 378 220 491 minecraft:sea_lantern
setblock 378 220 493 minecraft:sea_lantern
setblock 378 220 495 minecraft:sea_lantern
setblock 379 220 484 minecraft:sea_lantern
setblock 379 220 486 minecraft:sea_lantern
setblock 379 220 488 minecraft:sea_lantern
setblock 379 220 490 minecraft:sea_lantern
setblock 379 220 492 minecraft:sea_lantern
setblock 379 220 494 minecraft:sea_lantern
setblock 379 220 496 minecraft:sea_lantern
fill 379 220 505 379 227 505 minecraft:black_concrete
setblock 380 220 485 minecraft:sea_lantern
setblock 380 220 487 minecraft:sea_lantern
setblock 380 220 489 minecraft:sea_lantern
setblock 380 220 491 minecraft:sea_lantern
setblock 380 220 493 minecraft:sea_lantern
setblock 380 220 495 minecraft:sea_lantern
setblock 381 220 484 minecraft:sea_lantern
setblock 381 220 486 minecraft:sea_lantern
setblock 381 220 488 minecraft:sea_lantern
setblock 381 220 490 minecraft:sea_lantern
setblock 381 220 492 minecraft:sea_lantern
setblock 381 220 494 minecraft:sea_lantern
setblock 381 220 496 minecraft:sea_lantern
setblock 382 220 485 minecraft:sea_lantern
setblock 382 220 487 minecraft:sea_lantern
setblock 382 220 489 minecraft:sea_lantern
setblock 382 220 491 minecraft:sea_lantern
setblock 382 220 493 minecraft:sea_lantern
setblock 382 220 495 minecraft:sea_lantern
fill 383 220 463 383 227 463 minecraft:black_concrete
setblock 383 220 484 minecraft:sea_lantern
setblock 383 220 486 minecraft:sea_lantern
setblock 383 220 488 minecraft:sea_lantern
setblock 383 220 490 minecraft:sea_lantern
setblock 383 220 492 minecraft:sea_lantern
setblock 383 220 494 minecraft:sea_lantern
setblock 383 220 496 minecraft:sea_lantern
setblock 384 220 485 minecraft:sea_lantern
setblock 384 220 487 minecraft:sea_lantern
setblock 384 220 489 minecraft:sea_lantern
setblock 384 220 491 minecraft:sea_lantern
setblock 384 220 493 minecraft:sea_lantern
setblock 384 220 495 minecraft:sea_lantern
fill 387 220 505 387 227 505 minecraft:black_concrete
fill 391 220 463 391 227 463 minecraft:black_concrete
fill 395 220 505 395 227 505 minecraft:black_concrete
fill 399 220 463 399 227 463 minecraft:black_concrete
fill 403 220 505 403 227 505 minecraft:black_concrete
fill 407 220 463 407 227 463 minecraft:black_concrete
fill 411 220 505 411 227 505 minecraft:black_concrete
fill 415 220 463 415 227 463 minecraft:black_concrete
fill 418 220 468 418 227 468 minecraft:black_concrete
fill 418 220 476 418 227 476 minecraft:black_concrete
fill 418 220 484 418 227 484 minecraft:black_concrete
fill 418 220 492 418 227 492 minecraft:black_concrete
fill 418 220 500 418 227 500 minecraft:black_concrete
fill 377 221 484 377 222 484 minecraft:black_concrete
fill 377 221 486 377 222 486 minecraft:black_concrete
fill 377 221 488 377 222 488 minecraft:black_concrete
fill 377 221 490 377 222 490 minecraft:black_concrete
fill 377 221 492 377 222 492 minecraft:black_concrete
fill 377 221 494 377 222 494 minecraft:black_concrete
fill 377 221 496 377 222 496 minecraft:black_concrete
fill 378 221 485 378 222 485 minecraft:black_concrete
fill 378 221 487 378 222 487 minecraft:black_concrete
fill 378 221 489 378 222 489 minecraft:black_concrete
fill 378 221 491 378 222 491 minecraft:black_concrete
fill 378 221 493 378 222 493 minecraft:black_concrete
fill 378 221 495 378 222 495 minecraft:black_concrete
fill 379 221 484 379 222 484 minecraft:black_concrete
fill 379 221 486 379 222 486 minecraft:black_concrete
fill 379 221 488 379 222 488 minecraft:black_concrete
fill 379 221 490 379 222 490 minecraft:black_concrete
fill 379 221 492 379 222 492 minecraft:black_concrete
fill 379 221 494 379 222 494 minecraft:black_concrete
fill 379 221 496 379 222 496 minecraft:black_concrete
fill 380 221 485 380 222 485 minecraft:black_concrete
fill 380 221 487 380 222 487 minecraft:black_concrete
fill 380 221 489 380 222 489 minecraft:black_concrete
fill 380 221 491 380 222 491 minecraft:black_concrete
fill 380 221 493 380 222 493 minecraft:black_concrete
fill 380 221 495 380 222 495 minecraft:black_concrete
fill 381 221 484 381 222 484 minecraft:black_concrete
fill 381 221 486 381 222 486 minecraft:black_concrete
fill 381 221 488 381 222 488 minecraft:black_concrete
fill 381 221 490 381 222 490 minecraft:black_concrete
fill 381 221 492 381 222 492 minecraft:black_concrete
fill 381 221 494 381 222 494 minecraft:black_concrete
fill 381 221 496 381 222 496 minecraft:black_concrete
fill 382 221 485 382 222 485 minecraft:black_concrete
fill 382 221 487 382 222 487 minecraft:black_concrete
fill 382 221 489 382 222 489 minecraft:black_concrete
fill 382 221 491 382 222 491 minecraft:black_concrete
fill 382 221 493 382 222 493 minecraft:black_concrete
fill 382 221 495 382 222 495 minecraft:black_concrete
fill 383 221 484 383 222 484 minecraft:black_concrete
fill 383 221 486 383 222 486 minecraft:black_concrete
fill 383 221 488 383 222 488 minecraft:black_concrete
fill 383 221 490 383 222 490 minecraft:black_concrete
fill 383 221 492 383 222 492 minecraft:black_concrete
fill 383 221 494 383 222 494 minecraft:black_concrete
fill 383 221 496 383 222 496 minecraft:black_concrete
fill 384 221 485 384 222 485 minecraft:black_concrete
fill 384 221 487 384 222 487 minecraft:black_concrete
fill 384 221 489 384 222 489 minecraft:black_concrete
fill 384 221 491 384 222 491 minecraft:black_concrete
fill 384 221 493 384 222 493 minecraft:black_concrete
fill 384 221 495 384 222 495 minecraft:black_concrete
setblock 377 223 484 minecraft:sea_lantern
setblock 377 223 486 minecraft:sea_lantern
setblock 377 223 488 minecraft:sea_lantern
setblock 377 223 490 minecraft:sea_lantern
setblock 377 223 492 minecraft:sea_lantern
setblock 377 223 494 minecraft:sea_lantern
setblock 377 223 496 minecraft:sea_lantern
setblock 378 223 485 minecraft:sea_lantern
setblock 378 223 487 minecraft:sea_lantern
setblock 378 223 489 minecraft:sea_lantern
setblock 378 223 491 minecraft:sea_lantern
setblock 378 223 493 minecraft:sea_lantern
setblock 378 223 495 minecraft:sea_lantern
setblock 379 223 484 minecraft:sea_lantern
setblock 379 223 486 minecraft:sea_lantern
setblock 379 223 488 minecraft:sea_lantern
setblock 379 223 490 minecraft:sea_lantern
setblock 379 223 492 minecraft:sea_lantern
setblock 379 223 494 minecraft:sea_lantern
setblock 379 223 496 minecraft:sea_lantern
setblock 380 223 485 minecraft:sea_lantern
setblock 380 223 487 minecraft:sea_lantern
setblock 380 223 489 minecraft:sea_lantern
setblock 380 223 491 minecraft:sea_lantern
setblock 380 223 493 minecraft:sea_lantern
setblock 380 223 495 minecraft:sea_lantern
setblock 381 223 484 minecraft:sea_lantern
setblock 381 223 486 minecraft:sea_lantern
setblock 381 223 488 minecraft:sea_lantern
setblock 381 223 490 minecraft:sea_lantern
setblock 381 223 492 minecraft:sea_lantern
setblock 381 223 494 minecraft:sea_lantern
setblock 381 223 496 minecraft:sea_lantern
setblock 382 223 485 minecraft:sea_lantern
setblock 382 223 487 minecraft:sea_lantern
setblock 382 223 489 minecraft:sea_lantern
setblock 382 223 491 minecraft:sea_lantern
setblock 382 223 493 minecraft:sea_lantern
setblock 382 223 495 minecraft:sea_lantern
setblock 383 223 484 minecraft:sea_lantern
setblock 383 223 486 minecraft:sea_lantern
setblock 383 223 488 minecraft:sea_lantern
setblock 383 223 490 minecraft:sea_lantern
setblock 383 223 492 minecraft:sea_lantern
setblock 383 223 494 minecraft:sea_lantern
setblock 383 223 496 minecraft:sea_lantern
setblock 384 223 485 minecraft:sea_lantern
setblock 384 223 487 minecraft:sea_lantern
setblock 384 223 489 minecraft:sea_lantern
setblock 384 223 491 minecraft:sea_lantern
setblock 384 223 493 minecraft:sea_lantern
setblock 384 223 495 minecraft:sea_lantern
fill 396 223 473 398 225 475 minecraft:cyan_concrete
fill 377 224 464 377 225 469 minecraft:black_concrete
fill 377 224 472 378 224 477 minecraft:black_concrete
fill 377 224 480 377 225 484 minecraft:black_concrete
fill 377 224 486 377 225 486 minecraft:black_concrete
fill 377 224 488 377 225 488 minecraft:black_concrete
fill 377 224 490 377 225 490 minecraft:black_concrete
fill 377 224 492 377 225 492 minecraft:black_concrete
fill 377 224 494 377 225 494 minecraft:black_concrete
fill 377 224 496 377 225 501 minecraft:black_concrete
fill 377 224 504 382 225 504 minecraft:black_concrete
fill 378 224 465 378 224 471 minecraft:black_concrete
fill 378 224 478 378 224 483 minecraft:black_concrete
fill 378 224 485 378 225 485 minecraft:black_concrete
fill 378 224 487 378 225 487 minecraft:black_concrete
fill 378 224 489 378 225 489 minecraft:black_concrete
fill 378 224 491 378 225 491 minecraft:black_concrete
fill 378 224 493 378 225 493 minecraft:black_concrete
fill 378 224 495 378 225 495 minecraft:black_concrete
fill 378 224 497 378 224 503 minecraft:black_concrete
fill 379 224 465 416 224 465 minecraft:black_concrete
setblock 379 224 466 minecraft:light[level=14]
setblock 379 224 474 minecraft:light[level=14]
setblock 379 224 482 minecraft:light[level=14]
fill 379 224 484 379 225 484 minecraft:black_concrete
fill 379 224 486 379 225 486 minecraft:black_concrete
fill 379 224 488 379 225 488 minecraft:black_concrete
fill 379 224 490 379 225 490 minecraft:black_concrete
fill 379 224 492 379 225 492 minecraft:black_concrete
fill 379 224 494 379 225 494 minecraft:black_concrete
fill 379 224 496 379 225 496 minecraft:black_concrete
setblock 379 224 498 minecraft:light[level=14]
fill 379 224 503 417 224 503 minecraft:black_concrete
fill 380 224 464 385 225 464 minecraft:black_concrete
fill 380 224 485 380 225 485 minecraft:black_concrete
fill 380 224 487 380 225 487 minecraft:black_concrete
fill 380 224 489 380 225 489 minecraft:black_concrete
fill 380 224 491 380 225 491 minecraft:black_concrete
fill 380 224 493 380 225 493 minecraft:black_concrete
fill 380 224 495 380 225 495 minecraft:black_concrete
fill 381 224 484 381 225 484 minecraft:black_concrete
fill 381 224 486 381 225 486 minecraft:black_concrete
fill 381 224 488 381 225 488 minecraft:black_concrete
fill 381 224 490 381 225 490 minecraft:black_concrete
fill 381 224 492 381 225 492 minecraft:black_concrete
fill 381 224 494 381 225 494 minecraft:black_concrete
fill 381 224 496 381 225 496 minecraft:black_concrete
fill 382 224 485 382 225 485 minecraft:black_concrete
fill 382 224 487 382 225 487 minecraft:black_concrete
fill 382 224 489 382 225 489 minecraft:black_concrete
fill 382 224 491 382 225 491 minecraft:black_concrete
fill 382 224 493 382 225 493 minecraft:black_concrete
fill 382 224 495 382 225 495 minecraft:black_concrete
fill 383 224 484 383 225 484 minecraft:black_concrete
fill 383 224 486 383 225 486 minecraft:black_concrete
fill 383 224 488 383 225 488 minecraft:black_concrete
fill 383 224 490 383 225 490 minecraft:black_concrete
fill 383 224 492 383 225 492 minecraft:black_concrete
fill 383 224 494 383 225 494 minecraft:black_concrete
fill 383 224 496 383 225 496 minecraft:black_concrete
fill 384 224 485 384 225 485 minecraft:black_concrete
fill 384 224 487 384 225 487 minecraft:black_concrete
fill 384 224 489 384 225 489 minecraft:black_concrete
fill 384 224 491 384 225 491 minecraft:black_concrete
fill 384 224 493 384 225 493 minecraft:black_concrete
fill 384 224 495 384 225 495 minecraft:black_concrete
fill 385 224 504 390 225 504 minecraft:black_concrete
setblock 387 224 466 minecraft:light[level=14]
setblock 387 224 474 minecraft:light[level=14]
setblock 387 224 482 minecraft:light[level=14]
setblock 387 224 490 minecraft:light[level=14]
setblock 387 224 498 minecraft:light[level=14]
fill 388 224 464 393 225 464 minecraft:black_concrete
fill 393 224 504 398 225 504 minecraft:black_concrete
setblock 395 224 466 minecraft:light[level=14]
setblock 395 224 474 minecraft:light[level=14]
setblock 395 224 482 minecraft:light[level=14]
setblock 395 224 490 minecraft:light[level=14]
setblock 395 224 498 minecraft:light[level=14]
fill 396 224 464 401 225 464 minecraft:black_concrete
fill 401 224 504 406 225 504 minecraft:black_concrete
setblock 403 224 466 minecraft:light[level=14]
setblock 403 224 474 minecraft:light[level=14]
setblock 403 224 482 minecraft:light[level=14]
setblock 403 224 490 minecraft:light[level=14]
setblock 403 224 498 minecraft:light[level=14]
fill 404 224 464 409 225 464 minecraft:black_concrete
fill 406 224 466 406 225 473 minecraft:black_concrete
fill 409 224 504 414 225 504 minecraft:black_concrete
setblock 411 224 466 minecraft:light[level=14]
setblock 411 224 474 minecraft:light[level=14]
setblock 411 224 482 minecraft:light[level=14]
setblock 411 224 490 minecraft:light[level=14]
setblock 411 224 498 minecraft:light[level=14]
fill 412 224 464 417 225 464 minecraft:black_concrete
fill 416 224 466 416 224 502 minecraft:black_concrete
fill 417 224 467 417 225 472 minecraft:black_concrete
fill 417 224 475 417 225 480 minecraft:black_concrete
fill 417 224 483 417 225 488 minecraft:black_concrete
fill 417 224 491 417 225 496 minecraft:black_concrete
fill 417 224 499 417 225 502 minecraft:black_concrete
fill 417 224 504 417 225 504 minecraft:black_concrete
fill 377 225 472 377 225 477 minecraft:black_concrete
fill 405 225 465 405 225 481 minecraft:black_concrete
setblock 406 225 465 minecraft:black_concrete
fill 406 225 474 406 226 493 minecraft:black_concrete
setblock 417 225 503 minecraft:black_concrete
setblock 377 226 484 minecraft:sea_lantern
setblock 377 226 486 minecraft:sea_lantern
setblock 377 226 488 minecraft:sea_lantern
setblock 377 226 490 minecraft:sea_lantern
setblock 377 226 492 minecraft:sea_lantern
setblock 377 226 494 minecraft:sea_lantern
setblock 377 226 496 minecraft:sea_lantern
setblock 378 226 485 minecraft:sea_lantern
setblock 378 226 487 minecraft:sea_lantern
setblock 378 226 489 minecraft:sea_lantern
setblock 378 226 491 minecraft:sea_lantern
setblock 378 226 493 minecraft:sea_lantern
setblock 378 226 495 minecraft:sea_lantern
setblock 379 226 484 minecraft:sea_lantern
setblock 379 226 486 minecraft:sea_lantern
setblock 379 226 488 minecraft:sea_lantern
setblock 379 226 490 minecraft:sea_lantern
setblock 379 226 492 minecraft:sea_lantern
setblock 379 226 494 minecraft:sea_lantern
setblock 379 226 496 minecraft:sea_lantern
setblock 380 226 485 minecraft:sea_lantern
setblock 380 226 487 minecraft:sea_lantern
setblock 380 226 489 minecraft:sea_lantern
setblock 380 226 491 minecraft:sea_lantern
setblock 380 226 493 minecraft:sea_lantern
setblock 380 226 495 minecraft:sea_lantern
setblock 381 226 484 minecraft:sea_lantern
setblock 381 226 486 minecraft:sea_lantern
setblock 381 226 488 minecraft:sea_lantern
setblock 381 226 490 minecraft:sea_lantern
setblock 381 226 492 minecraft:sea_lantern
setblock 381 226 494 minecraft:sea_lantern
setblock 381 226 496 minecraft:sea_lantern
setblock 382 226 485 minecraft:sea_lantern
setblock 382 226 487 minecraft:sea_lantern
setblock 382 226 489 minecraft:sea_lantern
setblock 382 226 491 minecraft:sea_lantern
setblock 382 226 493 minecraft:sea_lantern
setblock 382 226 495 minecraft:sea_lantern
setblock 383 226 484 minecraft:sea_lantern
setblock 383 226 486 minecraft:sea_lantern
setblock 383 226 488 minecraft:sea_lantern
setblock 383 226 490 minecraft:sea_lantern
setblock 383 226 492 minecraft:sea_lantern
setblock 383 226 494 minecraft:sea_lantern
setblock 383 226 496 minecraft:sea_lantern
setblock 384 226 485 minecraft:sea_lantern
setblock 384 226 487 minecraft:sea_lantern
setblock 384 226 489 minecraft:sea_lantern
setblock 384 226 491 minecraft:sea_lantern
setblock 384 226 493 minecraft:sea_lantern
setblock 384 226 495 minecraft:sea_lantern
fill 405 226 487 405 226 496 minecraft:black_concrete
fill 406 226 464 406 226 473 minecraft:magenta_concrete
fill 406 226 494 406 227 504 minecraft:black_concrete
fill 377 227 484 377 228 484 minecraft:black_concrete
fill 377 227 486 377 228 486 minecraft:black_concrete
fill 377 227 488 377 228 488 minecraft:black_concrete
fill 377 227 490 377 228 490 minecraft:black_concrete
fill 377 227 492 377 228 492 minecraft:black_concrete
fill 377 227 494 377 228 494 minecraft:black_concrete
fill 377 227 496 377 228 496 minecraft:black_concrete
fill 378 227 485 378 228 485 minecraft:black_concrete
fill 378 227 487 378 228 487 minecraft:black_concrete
fill 378 227 489 378 228 489 minecraft:black_concrete
fill 378 227 491 378 228 491 minecraft:black_concrete
fill 378 227 493 378 228 493 minecraft:black_concrete
fill 378 227 495 378 228 495 minecraft:black_concrete
fill 379 227 484 379 228 484 minecraft:black_concrete
fill 379 227 486 379 228 486 minecraft:black_concrete
fill 379 227 488 379 228 488 minecraft:black_concrete
fill 379 227 490 379 228 490 minecraft:black_concrete
fill 379 227 492 379 228 492 minecraft:black_concrete
fill 379 227 494 379 228 494 minecraft:black_concrete
fill 379 227 496 379 228 496 minecraft:black_concrete
fill 380 227 485 380 228 485 minecraft:black_concrete
fill 380 227 487 380 228 487 minecraft:black_concrete
fill 380 227 489 380 228 489 minecraft:black_concrete
fill 380 227 491 380 228 491 minecraft:black_concrete
fill 380 227 493 380 228 493 minecraft:black_concrete
fill 380 227 495 380 228 495 minecraft:black_concrete
fill 381 227 484 381 228 484 minecraft:black_concrete
fill 381 227 486 381 228 486 minecraft:black_concrete
fill 381 227 488 381 228 488 minecraft:black_concrete
fill 381 227 490 381 228 490 minecraft:black_concrete
fill 381 227 492 381 228 492 minecraft:black_concrete
fill 381 227 494 381 228 494 minecraft:black_concrete
fill 381 227 496 381 228 496 minecraft:black_concrete
fill 382 227 485 382 228 485 minecraft:black_concrete
fill 382 227 487 382 228 487 minecraft:black_concrete
fill 382 227 489 382 228 489 minecraft:black_concrete
fill 382 227 491 382 228 491 minecraft:black_concrete
fill 382 227 493 382 228 493 minecraft:black_concrete
fill 382 227 495 382 228 495 minecraft:black_concrete
fill 383 227 484 383 228 484 minecraft:black_concrete
fill 383 227 486 383 228 486 minecraft:black_concrete
fill 383 227 488 383 228 488 minecraft:black_concrete
fill 383 227 490 383 228 490 minecraft:black_concrete
fill 383 227 492 383 228 492 minecraft:black_concrete
fill 383 227 494 383 228 494 minecraft:black_concrete
fill 383 227 496 383 228 496 minecraft:black_concrete
fill 384 227 485 384 228 485 minecraft:black_concrete
fill 384 227 487 384 228 487 minecraft:black_concrete
fill 384 227 489 384 228 489 minecraft:black_concrete
fill 384 227 491 384 228 491 minecraft:black_concrete
fill 384 227 493 384 228 493 minecraft:black_concrete
fill 384 227 495 384 228 495 minecraft:black_concrete
fill 406 227 475 406 227 493 minecraft:magenta_concrete
fill 376 228 468 376 230 468 minecraft:sea_lantern
fill 376 228 476 376 230 476 minecraft:sea_lantern
fill 376 228 484 376 230 484 minecraft:sea_lantern
fill 376 228 492 376 230 492 minecraft:sea_lantern
fill 376 228 500 376 230 500 minecraft:sea_lantern
fill 379 228 505 379 230 505 minecraft:sea_lantern
fill 383 228 463 383 230 463 minecraft:sea_lantern
fill 387 228 505 387 230 505 minecraft:sea_lantern
fill 391 228 463 391 230 463 minecraft:sea_lantern
fill 395 228 505 395 230 505 minecraft:sea_lantern
fill 399 228 463 399 230 463 minecraft:sea_lantern
fill 403 228 505 403 230 505 minecraft:sea_lantern
fill 406 228 495 406 228 504 minecraft:magenta_concrete
fill 407 228 463 407 230 463 minecraft:sea_lantern
fill 411 228 505 411 230 505 minecraft:sea_lantern
fill 415 228 463 415 230 463 minecraft:sea_lantern
fill 418 228 468 418 230 468 minecraft:sea_lantern
fill 418 228 476 418 230 476 minecraft:sea_lantern
fill 418 228 484 418 230 484 minecraft:sea_lantern
fill 418 228 492 418 230 492 minecraft:sea_lantern
fill 418 228 500 418 230 500 minecraft:sea_lantern
setblock 377 229 484 minecraft:sea_lantern
setblock 377 229 486 minecraft:sea_lantern
setblock 377 229 488 minecraft:sea_lantern
setblock 377 229 490 minecraft:sea_lantern
setblock 377 229 492 minecraft:sea_lantern
setblock 377 229 494 minecraft:sea_lantern
setblock 377 229 496 minecraft:sea_lantern
setblock 378 229 485 minecraft:sea_lantern
setblock 378 229 487 minecraft:sea_lantern
setblock 378 229 489 minecraft:sea_lantern
setblock 378 229 491 minecraft:sea_lantern
setblock 378 229 493 minecraft:sea_lantern
setblock 378 229 495 minecraft:sea_lantern
setblock 379 229 484 minecraft:sea_lantern
setblock 379 229 486 minecraft:sea_lantern
setblock 379 229 488 minecraft:sea_lantern
setblock 379 229 490 minecraft:sea_lantern
setblock 379 229 492 minecraft:sea_lantern
setblock 379 229 494 minecraft:sea_lantern
setblock 379 229 496 minecraft:sea_lantern
setblock 380 229 485 minecraft:sea_lantern
setblock 380 229 487 minecraft:sea_lantern
setblock 380 229 489 minecraft:sea_lantern
setblock 380 229 491 minecraft:sea_lantern
setblock 380 229 493 minecraft:sea_lantern
setblock 380 229 495 minecraft:sea_lantern
setblock 381 229 484 minecraft:sea_lantern
setblock 381 229 486 minecraft:sea_lantern
setblock 381 229 488 minecraft:sea_lantern
setblock 381 229 490 minecraft:sea_lantern
setblock 381 229 492 minecraft:sea_lantern
setblock 381 229 494 minecraft:sea_lantern
setblock 381 229 496 minecraft:sea_lantern
setblock 382 229 485 minecraft:sea_lantern
setblock 382 229 487 minecraft:sea_lantern
setblock 382 229 489 minecraft:sea_lantern
setblock 382 229 491 minecraft:sea_lantern
setblock 382 229 493 minecraft:sea_lantern
setblock 382 229 495 minecraft:sea_lantern
setblock 383 229 484 minecraft:sea_lantern
setblock 383 229 486 minecraft:sea_lantern
setblock 383 229 488 minecraft:sea_lantern
setblock 383 229 490 minecraft:sea_lantern
setblock 383 229 492 minecraft:sea_lantern
setblock 383 229 494 minecraft:sea_lantern
setblock 383 229 496 minecraft:sea_lantern
setblock 384 229 485 minecraft:sea_lantern
setblock 384 229 487 minecraft:sea_lantern
setblock 384 229 489 minecraft:sea_lantern
setblock 384 229 491 minecraft:sea_lantern
setblock 384 229 493 minecraft:sea_lantern
setblock 384 229 495 minecraft:sea_lantern
setblock 377 230 484 minecraft:black_concrete
setblock 377 230 486 minecraft:black_concrete
setblock 377 230 488 minecraft:black_concrete
setblock 377 230 490 minecraft:black_concrete
setblock 377 230 492 minecraft:black_concrete
setblock 377 230 494 minecraft:black_concrete
setblock 377 230 496 minecraft:black_concrete
setblock 378 230 485 minecraft:black_concrete
setblock 378 230 487 minecraft:black_concrete
setblock 378 230 489 minecraft:black_concrete
setblock 378 230 491 minecraft:black_concrete
setblock 378 230 493 minecraft:black_concrete
setblock 378 230 495 minecraft:black_concrete
setblock 379 230 484 minecraft:black_concrete
setblock 379 230 486 minecraft:black_concrete
setblock 379 230 488 minecraft:black_concrete
setblock 379 230 490 minecraft:black_concrete
setblock 379 230 492 minecraft:black_concrete
setblock 379 230 494 minecraft:black_concrete
setblock 379 230 496 minecraft:black_concrete
setblock 380 230 485 minecraft:black_concrete
setblock 380 230 487 minecraft:black_concrete
setblock 380 230 489 minecraft:black_concrete
setblock 380 230 491 minecraft:black_concrete
setblock 380 230 493 minecraft:black_concrete
setblock 380 230 495 minecraft:black_concrete
setblock 381 230 484 minecraft:black_concrete
setblock 381 230 486 minecraft:black_concrete
setblock 381 230 488 minecraft:black_concrete
setblock 381 230 490 minecraft:black_concrete
setblock 381 230 492 minecraft:black_concrete
fill 381 230 493 383 230 495 minecraft:gold_block
setblock 381 230 496 minecraft:black_concrete
setblock 382 230 485 minecraft:black_concrete
setblock 382 230 487 minecraft:black_concrete
setblock 382 230 489 minecraft:black_concrete
setblock 382 230 491 minecraft:black_concrete
setblock 383 230 484 minecraft:black_concrete
setblock 383 230 486 minecraft:black_concrete
setblock 383 230 488 minecraft:black_concrete
setblock 383 230 490 minecraft:black_concrete
setblock 383 230 492 minecraft:black_concrete
setblock 383 230 496 minecraft:black_concrete
setblock 384 230 485 minecraft:black_concrete
setblock 384 230 487 minecraft:black_concrete
setblock 384 230 489 minecraft:black_concrete
setblock 384 230 491 minecraft:black_concrete
setblock 384 230 493 minecraft:black_concrete
setblock 384 230 495 minecraft:black_concrete
fill 376 231 468 376 238 468 minecraft:black_concrete
fill 376 231 476 376 239 476 minecraft:black_concrete
fill 376 231 484 376 239 484 minecraft:black_concrete
fill 376 231 492 376 238 492 minecraft:black_concrete
fill 376 231 500 376 238 500 minecraft:black_concrete
fill 379 231 505 379 234 505 minecraft:black_concrete
fill 383 231 463 383 234 463 minecraft:black_concrete
fill 387 231 505 387 235 505 minecraft:black_concrete
fill 391 231 463 391 238 463 minecraft:black_concrete
fill 395 231 505 395 235 505 minecraft:black_concrete
fill 399 231 463 399 238 463 minecraft:black_concrete
fill 403 231 505 403 235 505 minecraft:black_concrete
fill 407 231 463 407 238 463 minecraft:black_concrete
fill 411 231 505 411 238 505 minecraft:black_concrete
fill 415 231 463 415 238 463 minecraft:black_concrete
fill 418 231 468 418 234 468 minecraft:black_concrete
fill 418 231 476 418 236 476 minecraft:black_concrete
fill 418 231 484 418 238 484 minecraft:black_concrete
fill 418 231 492 418 238 492 minecraft:black_concrete
fill 418 231 500 418 234 500 minecraft:black_concrete
setblock 379 232 466 minecraft:light[level=14]
setblock 379 232 474 minecraft:light[level=14]
setblock 379 232 482 minecraft:light[level=14]
setblock 379 232 490 minecraft:light[level=14]
setblock 379 232 498 minecraft:light[level=14]
setblock 387 232 466 minecraft:light[level=14]
setblock 387 232 474 minecraft:light[level=14]
setblock 387 232 482 minecraft:light[level=14]
setblock 387 232 490 minecraft:light[level=14]
setblock 387 232 498 minecraft:light[level=14]
setblock 395 232 466 minecraft:light[level=14]
setblock 395 232 474 minecraft:light[level=14]
setblock 395 232 482 minecraft:light[level=14]
setblock 395 232 490 minecraft:light[level=14]
setblock 395 232 498 minecraft:light[level=14]
setblock 403 232 466 minecraft:light[level=14]
setblock 403 232 474 minecraft:light[level=14]
setblock 403 232 482 minecraft:light[level=14]
setblock 403 232 490 minecraft:light[level=14]
setblock 403 232 498 minecraft:light[level=14]
setblock 411 232 466 minecraft:light[level=14]
setblock 411 232 474 minecraft:light[level=14]
setblock 411 232 482 minecraft:light[level=14]
setblock 411 232 490 minecraft:light[level=14]
setblock 411 232 498 minecraft:light[level=14]
fill 376 235 464 376 238 465 minecraft:black_concrete
setblock 376 235 466 minecraft:magenta_concrete
fill 376 235 467 376 238 467 minecraft:black_concrete
setblock 376 235 486 minecraft:magenta_concrete
fill 376 235 487 376 238 489 minecraft:black_concrete
fill 376 235 494 376 236 495 minecraft:black_concrete
fill 376 235 496 376 236 496 minecraft:magenta_concrete
fill 376 235 501 376 238 503 minecraft:black_concrete
setblock 376 235 504 minecraft:magenta_concrete
fill 376 235 505 376 238 505 minecraft:black_concrete
setblock 379 235 463 minecraft:magenta_concrete
setblock 379 235 505 minecraft:magenta_concrete
fill 380 235 463 380 238 463 minecraft:black_concrete
setblock 383 235 463 minecraft:magenta_concrete
fill 392 235 463 392 238 463 minecraft:black_concrete
fill 393 235 463 393 236 463 minecraft:magenta_concrete
fill 394 235 463 395 238 463 minecraft:black_concrete
setblock 396 235 463 minecraft:magenta_concrete
fill 400 235 463 400 238 463 minecraft:black_concrete
fill 401 235 463 401 236 463 minecraft:magenta_concrete
fill 402 235 463 404 236 463 minecraft:black_concrete
fill 408 235 463 408 236 463 minecraft:black_concrete
setblock 409 235 463 minecraft:magenta_concrete
fill 418 235 466 418 238 466 minecraft:black_concrete
fill 418 235 467 418 235 468 minecraft:magenta_concrete
fill 418 235 481 418 238 481 minecraft:black_concrete
setblock 418 235 482 minecraft:magenta_concrete
fill 418 235 483 418 238 483 minecraft:black_concrete
fill 418 235 494 418 235 496 minecraft:black_concrete
setblock 418 235 497 minecraft:magenta_concrete
setblock 418 235 500 minecraft:magenta_concrete
fill 376 236 466 376 238 466 minecraft:black_concrete
setblock 376 236 477 minecraft:magenta_concrete
fill 376 236 478 376 238 481 minecraft:black_concrete
setblock 376 236 482 minecraft:magenta_concrete
fill 376 236 483 376 238 483 minecraft:black_concrete
setblock 376 236 485 minecraft:magenta_concrete
fill 376 236 486 376 238 486 minecraft:black_concrete
setblock 376 236 504 minecraft:black_concrete
fill 377 236 464 377 237 465 minecraft:lime_concrete
fill 377 236 466 377 237 477 minecraft:cyan_concrete
fill 377 236 478 377 237 480 minecraft:lime_concrete
fill 377 236 481 377 237 492 minecraft:cyan_concrete
fill 377 236 493 377 237 495 minecraft:lime_concrete
fill 377 236 496 377 237 504 minecraft:cyan_concrete
fill 378 236 464 385 237 465 minecraft:cyan_concrete
fill 378 236 466 379 237 468 minecraft:lime_concrete
fill 378 236 469 379 237 480 minecraft:cyan_concrete
fill 378 236 481 379 237 483 minecraft:lime_concrete
fill 378 236 484 379 237 495 minecraft:cyan_concrete
fill 378 236 496 379 237 498 minecraft:lime_concrete
fill 378 236 499 379 237 504 minecraft:cyan_concrete
fill 379 236 463 379 238 463 minecraft:black_concrete
fill 379 236 505 379 238 505 minecraft:black_concrete
fill 380 236 466 387 237 468 minecraft:cyan_concrete
fill 380 236 469 381 237 471 minecraft:lime_concrete
fill 380 236 472 381 237 483 minecraft:cyan_concrete
fill 380 236 484 381 237 486 minecraft:lime_concrete
fill 380 236 487 381 237 498 minecraft:cyan_concrete
fill 380 236 499 381 237 501 minecraft:lime_concrete
fill 380 236 502 381 237 504 minecraft:cyan_concrete
setblock 380 236 505 minecraft:magenta_concrete
fill 382 236 469 389 237 471 minecraft:cyan_concrete
fill 382 236 472 383 237 474 minecraft:lime_concrete
fill 382 236 475 383 237 486 minecraft:cyan_concrete
fill 382 236 487 383 237 489 minecraft:lime_concrete
fill 382 236 490 383 237 501 minecraft:cyan_concrete
fill 382 236 502 383 237 504 minecraft:lime_concrete
fill 383 236 463 383 238 463 minecraft:black_concrete
fill 384 236 472 391 237 474 minecraft:cyan_concrete
fill 384 236 475 385 237 477 minecraft:lime_concrete
fill 384 236 478 385 237 489 minecraft:cyan_concrete
fill 384 236 490 385 237 492 minecraft:lime_concrete
fill 384 236 493 385 237 504 minecraft:cyan_concrete
fill 386 236 464 387 237 465 minecraft:lime_concrete
fill 386 236 475 393 237 477 minecraft:cyan_concrete
fill 386 236 478 387 237 480 minecraft:lime_concrete
fill 386 236 481 387 237 492 minecraft:cyan_concrete
fill 386 236 493 387 237 495 minecraft:lime_concrete
fill 386 236 496 387 237 504 minecraft:cyan_concrete
fill 387 236 505 388 236 505 minecraft:magenta_concrete
fill 388 236 464 395 237 465 minecraft:cyan_concrete
fill 388 236 466 389 237 468 minecraft:lime_concrete
fill 388 236 478 395 237 480 minecraft:cyan_concrete
fill 388 236 481 389 237 483 minecraft:lime_concrete
fill 388 236 484 389 237 495 minecraft:cyan_concrete
fill 388 236 496 389 237 498 minecraft:lime_concrete
fill 388 236 499 389 237 504 minecraft:cyan_concrete
fill 389 236 505 389 239 505 minecraft:black_concrete
fill 390 236 466 397 237 468 minecraft:cyan_concrete
fill 390 236 469 391 237 471 minecraft:lime_concrete
fill 390 236 481 397 236 483 minecraft:cyan_concrete
fill 390 236 484 391 237 486 minecraft:lime_concrete
fill 390 236 487 391 237 498 minecraft:cyan_concrete
fill 390 236 499 391 237 501 minecraft:lime_concrete
fill 390 236 502 391 237 504 minecraft:cyan_concrete
setblock 390 236 505 minecraft:magenta_concrete
fill 391 236 505 391 238 505 minecraft:black_concrete
fill 392 236 469 399 237 471 minecraft:cyan_concrete
fill 392 236 472 393 237 474 minecraft:lime_concrete
fill 392 236 484 396 236 486 minecraft:cyan_concrete
fill 392 236 487 393 237 489 minecraft:lime_concrete
fill 392 236 490 393 237 501 minecraft:cyan_concrete
fill 392 236 502 393 237 504 minecraft:lime_concrete
fill 394 236 472 401 237 474 minecraft:cyan_concrete
fill 394 236 475 395 237 477 minecraft:lime_concrete
fill 394 236 487 401 236 489 minecraft:cyan_concrete
fill 394 236 490 395 237 492 minecraft:lime_concrete
fill 394 236 493 395 237 504 minecraft:cyan_concrete
fill 395 236 505 396 236 505 minecraft:magenta_concrete
fill 396 236 463 397 238 463 minecraft:black_concrete
fill 396 236 464 397 237 465 minecraft:lime_concrete
fill 396 236 475 403 237 477 minecraft:cyan_concrete
fill 396 236 478 397 237 480 minecraft:lime_concrete
fill 396 236 490 403 237 492 minecraft:cyan_concrete
fill 396 236 493 397 237 495 minecraft:lime_concrete
fill 396 236 496 397 237 504 minecraft:cyan_concrete
fill 397 236 485 397 236 486 minecraft:cyan_concrete
fill 397 236 505 400 238 505 minecraft:black_concrete
setblock 398 236 463 minecraft:magenta_concrete
fill 398 236 464 405 237 465 minecraft:cyan_concrete
fill 398 236 466 399 237 468 minecraft:lime_concrete
fill 398 236 478 405 237 480 minecraft:cyan_concrete
fill 398 236 481 398 236 482 minecraft:lime_concrete
setblock 398 236 486 minecraft:cyan_concrete
fill 398 236 493 405 237 495 minecraft:cyan_concrete
fill 398 236 496 399 237 498 minecraft:lime_concrete
fill 398 236 499 399 237 504 minecraft:cyan_concrete
setblock 399 236 481 minecraft:lime_concrete
fill 400 236 466 407 237 468 minecraft:cyan_concrete
fill 400 236 469 401 237 471 minecraft:lime_concrete
fill 400 236 481 407 236 482 minecraft:cyan_concrete
fill 400 236 486 401 236 486 minecraft:lime_concrete
fill 400 236 496 407 237 498 minecraft:cyan_concrete
fill 400 236 499 401 237 501 minecraft:lime_concrete
fill 400 236 502 401 237 504 minecraft:cyan_concrete
fill 401 236 483 407 236 483 minecraft:cyan_concrete
setblock 401 236 485 minecraft:lime_concrete
setblock 401 236 505 minecraft:magenta_concrete
fill 402 236 469 409 237 471 minecraft:cyan_concrete
fill 402 236 472 403 237 474 minecraft:lime_concrete
fill 402 236 484 409 236 486 minecraft:cyan_concrete
fill 402 236 487 403 237 489 minecraft:lime_concrete
fill 402 236 499 409 237 501 minecraft:cyan_concrete
fill 402 236 502 403 237 504 minecraft:lime_concrete
setblock 403 236 505 minecraft:magenta_concrete
fill 404 236 472 411 237 474 minecraft:cyan_concrete
fill 404 236 475 405 237 477 minecraft:lime_concrete
fill 404 236 487 411 237 489 minecraft:cyan_concrete
fill 404 236 490 405 237 492 minecraft:lime_concrete
fill 404 236 502 411 237 504 minecraft:cyan_concrete
fill 406 236 464 407 237 465 minecraft:lime_concrete
fill 406 236 475 413 237 477 minecraft:cyan_concrete
fill 406 236 478 407 237 480 minecraft:lime_concrete
fill 406 236 490 413 237 492 minecraft:cyan_concrete
fill 406 236 493 407 237 495 minecraft:lime_concrete
fill 408 236 464 415 237 465 minecraft:cyan_concrete
fill 408 236 466 409 237 468 minecraft:lime_concrete
fill 408 236 478 415 237 480 minecraft:cyan_concrete
fill 408 236 481 409 237 483 minecraft:lime_concrete
fill 408 236 493 415 237 495 minecraft:cyan_concrete
fill 408 236 496 409 237 498 minecraft:lime_concrete
fill 409 236 463 409 239 463 minecraft:black_concrete
fill 410 236 466 417 237 468 minecraft:cyan_concrete
fill 410 236 469 411 237 471 minecraft:lime_concrete
fill 410 236 481 417 237 483 minecraft:cyan_concrete
fill 410 236 484 411 237 486 minecraft:lime_concrete
fill 410 236 496 417 237 498 minecraft:cyan_concrete
fill 410 236 499 411 237 501 minecraft:lime_concrete
fill 412 236 469 417 237 471 minecraft:cyan_concrete
fill 412 236 472 413 237 474 minecraft:lime_concrete
fill 412 236 484 417 237 486 minecraft:cyan_concrete
fill 412 236 487 413 237 489 minecraft:lime_concrete
fill 412 236 499 417 237 501 minecraft:cyan_concrete
fill 412 236 502 413 237 504 minecraft:lime_concrete
setblock 413 236 463 minecraft:magenta_concrete
fill 414 236 472 417 237 474 minecraft:cyan_concrete
fill 414 236 475 415 237 477 minecraft:lime_concrete
fill 414 236 487 417 237 489 minecraft:cyan_concrete
fill 414 236 490 415 237 492 minecraft:lime_concrete
fill 414 236 502 417 237 504 minecraft:cyan_concrete
fill 416 236 464 417 237 465 minecraft:lime_concrete
fill 416 236 475 417 237 477 minecraft:cyan_concrete
fill 416 236 478 417 237 480 minecraft:lime_concrete
fill 416 236 490 417 237 492 minecraft:cyan_concrete
fill 416 236 493 417 237 495 minecraft:lime_concrete
fill 418 236 467 418 236 468 minecraft:black_concrete
fill 418 236 482 418 238 482 minecraft:black_concrete
fill 418 236 494 418 236 495 minecraft:magenta_concrete
fill 418 236 496 418 236 497 minecraft:black_concrete
setblock 418 236 500 minecraft:black_concrete
fill 376 237 470 376 237 471 minecraft:magenta_concrete
fill 376 237 472 376 238 472 minecraft:black_concrete
fill 376 237 477 376 238 477 minecraft:black_concrete
fill 376 237 482 376 238 482 minecraft:black_concrete
fill 376 237 485 376 238 485 minecraft:black_concrete
setblock 376 237 494 minecraft:magenta_concrete
fill 376 237 495 376 238 496 minecraft:black_concrete
setblock 376 237 504 minecraft:magenta_concrete
setblock 377 237 505 minecraft:magenta_concrete
fill 378 237 505 378 238 505 minecraft:black_concrete
fill 380 237 505 380 239 505 minecraft:black_concrete
fill 387 237 505 387 238 505 minecraft:black_concrete
setblock 388 237 505 minecraft:magenta_concrete
setblock 390 237 463 minecraft:magenta_concrete
fill 390 237 481 395 237 483 minecraft:cyan_concrete
fill 390 237 505 390 238 505 minecraft:black_concrete
fill 392 237 484 395 237 486 minecraft:cyan_concrete
fill 393 237 463 393 238 463 minecraft:black_concrete
fill 394 237 487 397 237 489 minecraft:cyan_concrete
fill 395 237 505 396 238 505 minecraft:black_concrete
fill 396 237 481 396 237 482 minecraft:cyan_concrete
fill 396 237 483 396 237 485 minecraft:sea_lantern
setblock 396 237 486 minecraft:cyan_concrete
setblock 397 237 481 minecraft:cyan_concrete
fill 397 237 482 397 237 483 minecraft:sea_lantern
fill 397 237 485 397 237 486 minecraft:sea_lantern
fill 398 237 463 398 238 463 minecraft:black_concrete
fill 398 237 481 398 237 482 minecraft:sea_lantern
fill 398 237 486 398 237 487 minecraft:sea_lantern
fill 398 237 488 401 237 489 minecraft:cyan_concrete
fill 399 237 481 400 237 481 minecraft:sea_lantern
fill 399 237 487 400 237 487 minecraft:sea_lantern
fill 400 237 482 401 237 482 minecraft:sea_lantern
fill 400 237 486 401 237 486 minecraft:sea_lantern
fill 401 237 463 402 238 463 minecraft:black_concrete
fill 401 237 481 407 237 481 minecraft:cyan_concrete
fill 401 237 483 402 237 483 minecraft:sea_lantern
fill 401 237 485 402 237 485 minecraft:sea_lantern
setblock 401 237 487 minecraft:cyan_concrete
fill 401 237 505 401 238 505 minecraft:black_concrete
fill 402 237 482 407 237 482 minecraft:cyan_concrete
setblock 402 237 484 minecraft:sea_lantern
fill 402 237 486 409 237 486 minecraft:cyan_concrete
setblock 403 237 463 minecraft:magenta_concrete
fill 403 237 483 407 237 485 minecraft:cyan_concrete
fill 403 237 505 405 238 505 minecraft:black_concrete
fill 404 237 463 405 238 463 minecraft:black_concrete
setblock 406 237 463 minecraft:magenta_concrete
setblock 406 237 505 minecraft:magenta_concrete
fill 407 237 505 410 238 505 minecraft:black_concrete
setblock 408 237 463 minecraft:magenta_concrete
fill 408 237 484 409 237 485 minecraft:cyan_concrete
fill 413 237 463 413 238 463 minecraft:black_concrete
fill 414 237 505 414 238 505 minecraft:black_concrete
setblock 415 237 505 minecraft:magenta_concrete
fill 418 237 463 418 237 464 minecraft:magenta_concrete
setblock 418 237 467 minecraft:magenta_concrete
fill 418 237 468 418 238 469 minecraft:black_concrete
setblock 418 237 470 minecraft:magenta_concrete
fill 418 237 471 418 238 472 minecraft:black_concrete
setblock 418 237 476 minecraft:magenta_concrete
fill 418 237 487 418 238 487 minecraft:black_concrete
setblock 418 237 488 minecraft:magenta_concrete
fill 418 237 489 418 238 490 minecraft:black_concrete
fill 418 237 494 418 238 495 minecraft:black_concrete
setblock 418 237 496 minecraft:magenta_concrete
fill 418 237 497 418 238 498 minecraft:black_concrete
fill 418 237 499 418 237 500 minecraft:magenta_concrete
fill 376 238 470 376 238 471 minecraft:black_concrete
setblock 376 238 494 minecraft:black_concrete
setblock 376 238 504 minecraft:black_concrete
setblock 377 238 505 minecraft:black_concrete
setblock 388 238 505 minecraft:black_concrete
setblock 390 238 463 minecraft:black_concrete
setblock 403 238 463 minecraft:black_concrete
setblock 406 238 463 minecraft:black_concrete
setblock 406 238 505 minecraft:black_concrete
setblock 408 238 463 minecraft:black_concrete
setblock 415 238 505 minecraft:black_concrete
fill 418 238 463 418 238 464 minecraft:black_concrete
setblock 418 238 467 minecraft:black_concrete
setblock 418 238 470 minecraft:black_concrete
setblock 418 238 476 minecraft:black_concrete
setblock 418 238 488 minecraft:black_concrete
setblock 418 238 496 minecraft:black_concrete
fill 418 238 499 418 238 500 minecraft:black_concrete
fill 376 239 463 376 307 464 minecraft:magenta_concrete
setblock 376 239 465 minecraft:black_concrete
fill 376 239 466 376 241 469 minecraft:magenta_concrete
setblock 376 239 470 minecraft:black_concrete
fill 376 239 471 376 240 473 minecraft:magenta_concrete
setblock 376 239 475 minecraft:magenta_concrete
fill 376 239 477 376 239 483 minecraft:magenta_concrete
fill 376 239 485 376 307 486 minecraft:magenta_concrete
setblock 376 239 487 minecraft:black_concrete
fill 376 239 488 376 307 488 minecraft:magenta_concrete
setblock 376 239 489 minecraft:black_concrete
fill 376 239 490 376 239 505 minecraft:magenta_concrete
fill 377 239 463 384 240 463 minecraft:magenta_concrete
fill 377 239 505 379 241 505 minecraft:magenta_concrete
fill 381 239 505 388 240 505 minecraft:magenta_concrete
fill 385 239 463 385 240 463 minecraft:black_concrete
fill 386 239 463 408 239 463 minecraft:magenta_concrete
fill 390 239 505 391 307 505 minecraft:magenta_concrete
fill 393 239 505 401 239 505 minecraft:magenta_concrete
fill 403 239 505 411 241 505 minecraft:magenta_concrete
fill 410 239 463 411 307 463 minecraft:magenta_concrete
fill 413 239 463 418 239 463 minecraft:magenta_concrete
fill 414 239 505 415 258 505 minecraft:magenta_concrete
fill 418 239 464 418 239 473 minecraft:magenta_concrete
setblock 418 239 474 minecraft:black_concrete
fill 418 239 475 418 239 502 minecraft:magenta_concrete
fill 418 239 504 418 307 505 minecraft:magenta_concrete
fill 376 240 465 376 307 465 minecraft:magenta_concrete
fill 376 240 470 376 307 470 minecraft:magenta_concrete
setblock 376 240 475 minecraft:black_concrete
fill 376 240 476 376 240 479 minecraft:magenta_concrete
setblock 376 240 480 minecraft:black_concrete
fill 376 240 481 376 307 482 minecraft:magenta_concrete
setblock 376 240 483 minecraft:black_concrete
fill 376 240 484 376 241 484 minecraft:magenta_concrete
fill 376 240 487 376 307 487 minecraft:magenta_concrete
fill 376 240 489 376 240 500 minecraft:magenta_concrete
setblock 376 240 501 minecraft:black_concrete
fill 376 240 502 376 240 505 minecraft:magenta_concrete
setblock 379 240 466 minecraft:light[level=14]
setblock 379 240 474 minecraft:light[level=14]
setblock 379 240 482 minecraft:light[level=14]
setblock 379 240 490 minecraft:light[level=14]
setblock 379 240 498 minecraft:light[level=14]
fill 380 240 505 380 307 505 minecraft:magenta_concrete
fill 386 240 463 395 241 463 minecraft:magenta_concrete
setblock 387 240 466 minecraft:light[level=14]
setblock 387 240 474 minecraft:light[level=14]
setblock 387 240 482 minecraft:light[level=14]
setblock 387 240 490 minecraft:light[level=14]
setblock 387 240 498 minecraft:light[level=14]
fill 389 240 505 389 307 505 minecraft:magenta_concrete
fill 393 240 505 396 240 505 minecraft:magenta_concrete
setblock 395 240 466 minecraft:light[level=14]
setblock 395 240 474 minecraft:light[level=14]
setblock 395 240 482 minecraft:light[level=14]
setblock 395 240 490 minecraft:light[level=14]
setblock 395 240 498 minecraft:light[level=14]
setblock 396 240 463 minecraft:black_concrete
fill 397 240 463 397 307 463 minecraft:magenta_concrete
setblock 397 240 505 minecraft:black_concrete
fill 398 240 463 398 241 463 minecraft:black_concrete
fill 398 240 505 402 307 505 minecraft:magenta_concrete
fill 399 240 463 409 241 463 minecraft:magenta_concrete
setblock 403 240 466 minecraft:light[level=14]
setblock 403 240 474 minecraft:light[level=14]
setblock 403 240 482 minecraft:light[level=14]
setblock 403 240 490 minecraft:light[level=14]
setblock 403 240 498 minecraft:light[level=14]
setblock 411 240 466 minecraft:light[level=14]
setblock 411 240 474 minecraft:light[level=14]
setblock 411 240 482 minecraft:light[level=14]
setblock 411 240 490 minecraft:light[level=14]
setblock 411 240 498 minecraft:light[level=14]
fill 412 240 505 413 258 505 minecraft:magenta_concrete
fill 413 240 463 415 240 463 minecraft:magenta_concrete
setblock 416 240 463 minecraft:black_concrete
fill 416 240 505 417 258 505 minecraft:magenta_concrete
fill 417 240 463 418 307 463 minecraft:magenta_concrete
fill 418 240 464 418 241 464 minecraft:black_concrete
fill 418 240 465 418 240 477 minecraft:magenta_concrete
setblock 418 240 478 minecraft:black_concrete
fill 418 240 479 418 240 485 minecraft:magenta_concrete
setblock 418 240 486 minecraft:black_concrete
fill 418 240 487 418 307 491 minecraft:magenta_concrete
fill 418 240 492 418 241 492 minecraft:black_concrete
fill 418 240 493 418 240 496 minecraft:magenta_concrete
setblock 418 240 497 minecraft:black_concrete
fill 418 240 498 418 240 500 minecraft:magenta_concrete
setblock 418 240 501 minecraft:black_concrete
fill 418 240 502 418 307 502 minecraft:magenta_concrete
fill 376 241 471 376 307 472 minecraft:magenta_concrete
setblock 376 241 473 minecraft:black_concrete
fill 376 241 474 376 241 476 minecraft:magenta_concrete
setblock 376 241 477 minecraft:black_concrete
fill 376 241 478 376 307 480 minecraft:magenta_concrete
fill 376 241 483 376 307 483 minecraft:magenta_concrete
fill 376 241 489 376 307 489 minecraft:magenta_concrete
setblock 376 241 490 minecraft:black_concrete
fill 376 241 491 376 241 501 minecraft:magenta_concrete
fill 376 241 502 377 241 502 minecraft:black_concrete
fill 376 241 503 376 255 504 minecraft:magenta_concrete
setblock 376 241 505 minecraft:black_concrete
fill 377 241 463 379 307 463 minecraft:magenta_concrete
fill 377 241 470 377 273 471 minecraft:black_concrete
fill 377 241 478 377 273 479 minecraft:black_concrete
fill 377 241 486 377 273 487 minecraft:black_concrete
fill 377 241 494 377 273 495 minecraft:black_concrete
fill 377 241 503 377 273 503 minecraft:black_concrete
fill 378 241 464 379 273 464 minecraft:black_concrete
setblock 380 241 463 minecraft:black_concrete
fill 381 241 463 382 307 463 minecraft:magenta_concrete
fill 381 241 505 386 307 505 minecraft:magenta_concrete
setblock 383 241 463 minecraft:black_concrete
fill 383 241 504 384 255 504 minecraft:black_concrete
fill 384 241 463 385 307 463 minecraft:magenta_concrete
fill 386 241 464 387 273 464 minecraft:black_concrete
setblock 387 241 505 minecraft:black_concrete
fill 388 241 505 388 307 505 minecraft:magenta_concrete
fill 391 241 504 392 273 504 minecraft:black_concrete
fill 393 241 505 393 307 505 minecraft:magenta_concrete
fill 394 241 464 395 273 464 minecraft:black_concrete
fill 394 241 505 395 241 505 minecraft:black_concrete
fill 396 241 463 396 307 463 minecraft:magenta_concrete
fill 396 241 505 397 307 505 minecraft:magenta_concrete
fill 399 241 504 400 273 504 minecraft:black_concrete
fill 402 241 464 403 273 464 minecraft:black_concrete
fill 407 241 504 408 273 504 minecraft:black_concrete
fill 409 241 483 417 243 491 minecraft:black_concrete
fill 410 241 464 411 273 464 minecraft:black_concrete
fill 412 241 463 413 307 463 minecraft:magenta_concrete
fill 414 241 463 415 241 463 minecraft:black_concrete
fill 414 241 493 415 242 494 minecraft:lime_concrete
fill 415 241 504 416 258 504 minecraft:black_concrete
fill 416 241 463 416 307 463 minecraft:magenta_concrete
fill 417 241 465 417 273 466 minecraft:black_concrete
fill 417 241 473 417 273 474 minecraft:black_concrete
fill 417 241 481 417 273 482 minecraft:black_concrete
fill 417 241 497 417 258 498 minecraft:black_concrete
fill 418 241 465 418 241 472 minecraft:magenta_concrete
setblock 418 241 473 minecraft:black_concrete
fill 418 241 474 418 307 475 minecraft:magenta_concrete
setblock 418 241 476 minecraft:black_concrete
fill 418 241 477 418 307 478 minecraft:magenta_concrete
setblock 418 241 479 minecraft:black_concrete
fill 418 241 480 418 307 481 minecraft:magenta_concrete
setblock 418 241 482 minecraft:black_concrete
fill 418 241 483 418 241 486 minecraft:magenta_concrete
fill 418 241 493 418 307 495 minecraft:magenta_concrete
setblock 418 241 496 minecraft:black_concrete
fill 418 241 497 418 307 498 minecraft:magenta_concrete
setblock 418 241 499 minecraft:black_concrete
fill 418 241 500 418 241 501 minecraft:magenta_concrete
fill 418 241 503 418 307 503 minecraft:magenta_concrete
fill 376 242 466 376 307 467 minecraft:magenta_concrete
fill 376 242 468 376 247 468 minecraft:sea_lantern
fill 376 242 469 376 307 469 minecraft:magenta_concrete
fill 376 242 473 376 307 475 minecraft:magenta_concrete
fill 376 242 476 376 247 476 minecraft:sea_lantern
fill 376 242 477 376 307 477 minecraft:magenta_concrete
fill 376 242 484 376 247 484 minecraft:sea_lantern
fill 376 242 490 376 307 491 minecraft:magenta_concrete
fill 376 242 492 376 247 492 minecraft:sea_lantern
fill 376 242 493 376 255 499 minecraft:magenta_concrete
fill 376 242 500 376 247 500 minecraft:sea_lantern
fill 376 242 501 376 255 502 minecraft:magenta_concrete
fill 376 242 505 378 307 505 minecraft:magenta_concrete
fill 377 242 502 377 255 502 minecraft:black_concrete
fill 379 242 505 379 247 505 minecraft:sea_lantern
fill 380 242 463 380 307 463 minecraft:magenta_concrete
fill 383 242 463 383 247 463 minecraft:sea_lantern
fill 386 242 463 390 307 463 minecraft:magenta_concrete
fill 387 242 505 387 247 505 minecraft:sea_lantern
fill 391 242 463 391 247 463 minecraft:sea_lantern
fill 392 242 463 395 307 463 minecraft:magenta_concrete
fill 392 242 505 392 307 505 minecraft:magenta_concrete
fill 394 242 505 394 307 505 minecraft:magenta_concrete
fill 395 242 505 395 247 505 minecraft:sea_lantern
fill 398 242 463 398 307 463 minecraft:magenta_concrete
fill 399 242 463 399 247 463 minecraft:sea_lantern
fill 400 242 463 406 307 463 minecraft:magenta_concrete
fill 403 242 505 403 247 505 minecraft:sea_lantern
fill 404 242 505 410 258 505 minecraft:magenta_concrete
fill 406 242 480 407 243 481 minecraft:black_concrete
fill 407 242 463 407 247 463 minecraft:sea_lantern
fill 408 242 463 409 307 463 minecraft:magenta_concrete
fill 411 242 505 411 247 505 minecraft:sea_lantern
fill 414 242 463 414 307 463 minecraft:magenta_concrete
fill 415 242 463 415 247 463 minecraft:sea_lantern
fill 418 242 464 418 307 467 minecraft:magenta_concrete
fill 418 242 468 418 247 468 minecraft:sea_lantern
fill 418 242 469 418 307 473 minecraft:magenta_concrete
fill 418 242 476 418 247 476 minecraft:sea_lantern
fill 418 242 479 418 307 479 minecraft:magenta_concrete
fill 418 242 482 418 307 483 minecraft:magenta_concrete
fill 418 242 484 418 247 484 minecraft:sea_lantern
fill 418 242 485 418 307 486 minecraft:magenta_concrete
fill 418 242 492 418 247 492 minecraft:sea_lantern
fill 418 242 496 418 307 496 minecraft:magenta_concrete
fill 418 242 499 418 307 499 minecraft:magenta_concrete
fill 418 242 500 418 247 500 minecraft:sea_lantern
fill 418 242 501 418 307 501 minecraft:magenta_concrete
fill 384 243 474 387 246 477 minecraft:cyan_concrete
fill 409 244 483 409 255 483 minecraft:black_concrete
setblock 409 244 484 minecraft:sea_lantern
fill 409 244 485 409 255 485 minecraft:black_concrete
setblock 409 244 486 minecraft:sea_lantern
fill 409 244 487 409 255 487 minecraft:black_concrete
setblock 409 244 488 minecraft:sea_lantern
fill 409 244 489 409 255 489 minecraft:black_concrete
setblock 409 244 490 minecraft:sea_lantern
fill 409 244 491 409 255 491 minecraft:black_concrete
setblock 410 244 483 minecraft:sea_lantern
fill 410 244 484 410 255 484 minecraft:black_concrete
setblock 410 244 485 minecraft:sea_lantern
fill 410 244 486 410 255 486 minecraft:black_concrete
setblock 410 244 487 minecraft:sea_lantern
fill 410 244 488 410 255 488 minecraft:black_concrete
setblock 410 244 489 minecraft:sea_lantern
fill 410 244 490 410 255 490 minecraft:black_concrete
setblock 410 244 491 minecraft:sea_lantern
fill 411 244 483 411 255 483 minecraft:black_concrete
setblock 411 244 484 minecraft:sea_lantern
fill 411 244 485 411 255 485 minecraft:black_concrete
setblock 411 244 486 minecraft:sea_lantern
fill 411 244 487 411 255 487 minecraft:black_concrete
setblock 411 244 488 minecraft:sea_lantern
fill 411 244 489 411 255 489 minecraft:black_concrete
setblock 411 244 490 minecraft:sea_lantern
fill 411 244 491 411 255 491 minecraft:black_concrete
setblock 412 244 483 minecraft:sea_lantern
fill 412 244 484 412 255 484 minecraft:black_concrete
setblock 412 244 485 minecraft:sea_lantern
fill 412 244 486 412 255 486 minecraft:black_concrete
setblock 412 244 487 minecraft:sea_lantern
fill 412 244 488 412 255 488 minecraft:black_concrete
setblock 412 244 489 minecraft:sea_lantern
fill 412 244 490 412 255 490 minecraft:black_concrete
setblock 412 244 491 minecraft:sea_lantern
fill 413 244 483 413 255 483 minecraft:black_concrete
setblock 413 244 484 minecraft:sea_lantern
fill 413 244 485 413 255 485 minecraft:black_concrete
setblock 413 244 486 minecraft:sea_lantern
fill 413 244 487 413 255 487 minecraft:black_concrete
setblock 413 244 488 minecraft:sea_lantern
fill 413 244 489 413 255 489 minecraft:black_concrete
setblock 413 244 490 minecraft:sea_lantern
fill 413 244 491 413 255 491 minecraft:black_concrete
setblock 414 244 483 minecraft:sea_lantern
fill 414 244 484 414 255 484 minecraft:black_concrete
setblock 414 244 485 minecraft:sea_lantern
fill 414 244 486 414 255 486 minecraft:black_concrete
setblock 414 244 487 minecraft:sea_lantern
fill 414 244 488 414 255 488 minecraft:black_concrete
setblock 414 244 489 minecraft:sea_lantern
fill 414 244 490 414 255 490 minecraft:black_concrete
setblock 414 244 491 minecraft:sea_lantern
fill 415 244 483 415 255 483 minecraft:black_concrete
setblock 415 244 484 minecraft:sea_lantern
fill 415 244 485 415 255 485 minecraft:black_concrete
setblock 415 244 486 minecraft:sea_lantern
fill 415 244 487 415 255 487 minecraft:black_concrete
setblock 415 244 488 minecraft:sea_lantern
fill 415 244 489 415 255 489 minecraft:black_concrete
setblock 415 244 490 minecraft:sea_lantern
fill 415 244 491 415 255 491 minecraft:black_concrete
setblock 416 244 483 minecraft:sea_lantern
fill 416 244 484 416 255 484 minecraft:black_concrete
setblock 416 244 485 minecraft:sea_lantern
fill 416 244 486 416 255 486 minecraft:black_concrete
setblock 416 244 487 minecraft:sea_lantern
fill 416 244 488 416 255 488 minecraft:black_concrete
setblock 416 244 489 minecraft:sea_lantern
fill 416 244 490 416 255 490 minecraft:black_concrete
setblock 416 244 491 minecraft:sea_lantern
fill 417 244 483 417 255 483 minecraft:black_concrete
setblock 417 244 484 minecraft:sea_lantern
fill 417 244 485 417 255 485 minecraft:black_concrete
setblock 417 244 486 minecraft:sea_lantern
fill 417 244 487 417 255 487 minecraft:black_concrete
setblock 417 244 488 minecraft:sea_lantern
fill 417 244 489 417 273 489 minecraft:black_concrete
setblock 417 244 490 minecraft:sea_lantern
fill 417 244 491 417 255 491 minecraft:black_concrete
fill 409 245 484 409 246 484 minecraft:black_concrete
fill 409 245 486 409 246 486 minecraft:black_concrete
fill 409 245 488 409 246 488 minecraft:black_concrete
fill 409 245 490 409 246 490 minecraft:black_concrete
fill 410 245 483 410 246 483 minecraft:black_concrete
fill 410 245 485 410 246 485 minecraft:black_concrete
fill 410 245 487 410 246 487 minecraft:black_concrete
fill 410 245 489 410 246 489 minecraft:black_concrete
fill 410 245 491 410 246 491 minecraft:black_concrete
fill 411 245 484 411 246 484 minecraft:black_concrete
fill 411 245 486 411 246 486 minecraft:black_concrete
fill 411 245 488 411 246 488 minecraft:black_concrete
fill 411 245 490 411 246 490 minecraft:black_concrete
fill 412 245 483 412 246 483 minecraft:black_concrete
fill 412 245 485 412 246 485 minecraft:black_concrete
fill 412 245 487 412 246 487 minecraft:black_concrete
fill 412 245 489 412 246 489 minecraft:black_concrete
fill 412 245 491 412 246 491 minecraft:black_concrete
fill 413 245 484 413 246 484 minecraft:black_concrete
fill 413 245 486 413 246 486 minecraft:black_concrete
fill 413 245 488 413 246 488 minecraft:black_concrete
fill 413 245 490 413 246 490 minecraft:black_concrete
fill 414 245 483 414 246 483 minecraft:black_concrete
fill 414 245 485 414 246 485 minecraft:black_concrete
fill 414 245 487 414 246 487 minecraft:black_concrete
fill 414 245 489 414 246 489 minecraft:black_concrete
fill 414 245 491 414 246 491 minecraft:black_concrete
fill 415 245 484 415 246 484 minecraft:black_concrete
fill 415 245 486 415 246 486 minecraft:black_concrete
fill 415 245 488 415 246 488 minecraft:black_concrete
fill 415 245 490 415 246 490 minecraft:black_concrete
fill 416 245 483 416 246 483 minecraft:black_concrete
fill 416 245 485 416 246 485 minecraft:black_concrete
fill 416 245 487 416 246 487 minecraft:black_concrete
fill 416 245 489 416 246 489 minecraft:black_concrete
fill 416 245 491 416 246 491 minecraft:black_concrete
fill 417 245 484 417 246 484 minecraft:black_concrete
fill 417 245 486 417 246 486 minecraft:black_concrete
fill 417 245 488 417 246 488 minecraft:black_concrete
fill 417 245 490 417 246 490 minecraft:black_concrete
setblock 409 247 484 minecraft:sea_lantern
setblock 409 247 486 minecraft:sea_lantern
setblock 409 247 488 minecraft:sea_lantern
setblock 409 247 490 minecraft:sea_lantern
setblock 410 247 483 minecraft:sea_lantern
setblock 410 247 485 minecraft:sea_lantern
setblock 410 247 487 minecraft:sea_lantern
setblock 410 247 489 minecraft:sea_lantern
setblock 410 247 491 minecraft:sea_lantern
setblock 411 247 484 minecraft:sea_lantern
setblock 411 247 486 minecraft:sea_lantern
setblock 411 247 488 minecraft:sea_lantern
setblock 411 247 490 minecraft:sea_lantern
setblock 412 247 483 minecraft:sea_lantern
setblock 412 247 485 minecraft:sea_lantern
setblock 412 247 487 minecraft:sea_lantern
setblock 412 247 489 minecraft:sea_lantern
setblock 412 247 491 minecraft:sea_lantern
setblock 413 247 484 minecraft:sea_lantern
setblock 413 247 486 minecraft:sea_lantern
setblock 413 247 488 minecraft:sea_lantern
setblock 413 247 490 minecraft:sea_lantern
setblock 414 247 483 minecraft:sea_lantern
setblock 414 247 485 minecraft:sea_lantern
setblock 414 247 487 minecraft:sea_lantern
setblock 414 247 489 minecraft:sea_lantern
setblock 414 247 491 minecraft:sea_lantern
setblock 415 247 484 minecraft:sea_lantern
setblock 415 247 486 minecraft:sea_lantern
setblock 415 247 488 minecraft:sea_lantern
setblock 415 247 490 minecraft:sea_lantern
setblock 416 247 483 minecraft:sea_lantern
setblock 416 247 485 minecraft:sea_lantern
setblock 416 247 487 minecraft:sea_lantern
setblock 416 247 489 minecraft:sea_lantern
setblock 416 247 491 minecraft:sea_lantern
setblock 417 247 484 minecraft:sea_lantern
setblock 417 247 486 minecraft:sea_lantern
setblock 417 247 488 minecraft:sea_lantern
setblock 417 247 490 minecraft:sea_lantern
fill 376 248 468 376 255 468 minecraft:magenta_concrete
fill 376 248 476 376 255 476 minecraft:magenta_concrete
fill 376 248 484 376 255 484 minecraft:magenta_concrete
fill 376 248 492 376 255 492 minecraft:magenta_concrete
fill 376 248 500 376 255 500 minecraft:magenta_concrete
setblock 379 248 466 minecraft:light[level=14]
setblock 379 248 474 minecraft:light[level=14]
setblock 379 248 482 minecraft:light[level=14]
setblock 379 248 490 minecraft:light[level=14]
setblock 379 248 498 minecraft:light[level=14]
fill 379 248 505 379 255 505 minecraft:magenta_concrete
fill 380 248 501 380 253 501 minecraft:magenta_concrete
fill 383 248 463 383 255 463 minecraft:magenta_concrete
setblock 387 248 466 minecraft:light[level=14]
setblock 387 248 474 minecraft:light[level=14]
setblock 387 248 482 minecraft:light[level=14]
setblock 387 248 490 minecraft:light[level=14]
setblock 387 248 498 minecraft:light[level=14]
fill 387 248 505 387 255 505 minecraft:magenta_concrete
fill 391 248 463 391 255 463 minecraft:magenta_concrete
setblock 395 248 466 minecraft:light[level=14]
setblock 395 248 474 minecraft:light[level=14]
setblock 395 248 482 minecraft:light[level=14]
setblock 395 248 490 minecraft:light[level=14]
setblock 395 248 498 minecraft:light[level=14]
fill 395 248 505 395 255 505 minecraft:magenta_concrete
fill 399 248 463 399 255 463 minecraft:magenta_concrete
setblock 403 248 466 minecraft:light[level=14]
setblock 403 248 474 minecraft:light[level=14]
setblock 403 248 482 minecraft:light[level=14]
setblock 403 248 490 minecraft:light[level=14]
setblock 403 248 498 minecraft:light[level=14]
fill 403 248 505 403 255 505 minecraft:magenta_concrete
fill 407 248 463 407 255 463 minecraft:magenta_concrete
fill 409 248 484 409 249 484 minecraft:black_concrete
fill 409 248 486 409 249 486 minecraft:black_concrete
fill 409 248 488 409 249 488 minecraft:black_concrete
fill 409 248 490 409 249 490 minecraft:black_concrete
fill 410 248 483 410 249 483 minecraft:black_concrete
fill 410 248 485 410 249 485 minecraft:black_concrete
fill 410 248 487 410 249 487 minecraft:black_concrete
fill 410 248 489 410 249 489 minecraft:black_concrete
fill 410 248 491 410 249 491 minecraft:black_concrete
setblock 411 248 466 minecraft:light[level=14]
setblock 411 248 474 minecraft:light[level=14]
setblock 411 248 482 minecraft:light[level=14]
fill 411 248 484 411 249 484 minecraft:black_concrete
fill 411 248 486 411 249 486 minecraft:black_concrete
fill 411 248 488 411 249 488 minecraft:black_concrete
fill 411 248 490 411 249 490 minecraft:black_concrete
setblock 411 248 498 minecraft:light[level=14]
fill 411 248 505 411 255 505 minecraft:magenta_concrete
fill 412 248 483 412 249 483 minecraft:black_concrete
fill 412 248 485 412 249 485 minecraft:black_concrete
fill 412 248 487 412 249 487 minecraft:black_concrete
fill 412 248 489 412 249 489 minecraft:black_concrete
fill 412 248 491 412 249 491 minecraft:black_concrete
fill 413 248 484 413 249 484 minecraft:black_concrete
fill 413 248 486 413 249 486 minecraft:black_concrete
fill 413 248 488 413 249 488 minecraft:black_concrete
fill 413 248 490 413 249 490 minecraft:black_concrete
fill 414 248 483 414 249 483 minecraft:black_concrete
fill 414 248 485 414 249 485 minecraft:black_concrete
fill 414 248 487 414 249 487 minecraft:black_concrete
fill 414 248 489 414 249 489 minecraft:black_concrete
fill 414 248 491 414 249 491 minecraft:black_concrete
fill 415 248 463 415 255 463 minecraft:magenta_concrete
fill 415 248 484 415 249 484 minecraft:black_concrete
fill 415 248 486 415 249 486 minecraft:black_concrete
fill 415 248 488 415 249 488 minecraft:black_concrete
fill 415 248 490 415 249 490 minecraft:black_concrete
fill 416 248 483 416 249 483 minecraft:black_concrete
fill 416 248 485 416 249 485 minecraft:black_concrete
fill 416 248 487 416 249 487 minecraft:black_concrete
fill 416 248 489 416 249 489 minecraft:black_concrete
fill 416 248 491 416 249 491 minecraft:black_concrete
fill 417 248 484 417 249 484 minecraft:black_concrete
fill 417 248 486 417 249 486 minecraft:black_concrete
fill 417 248 488 417 249 488 minecraft:black_concrete
fill 417 248 490 417 249 490 minecraft:black_concrete
fill 418 248 468 418 255 468 minecraft:magenta_concrete
fill 418 248 476 418 255 476 minecraft:magenta_concrete
fill 418 248 484 418 255 484 minecraft:magenta_concrete
fill 418 248 492 418 255 492 minecraft:magenta_concrete
fill 418 248 500 418 255 500 minecraft:magenta_concrete
fill 401 249 478 404 252 481 minecraft:magenta_concrete
fill 404 249 482 406 251 483 minecraft:magenta_concrete
fill 405 249 481 406 251 481 minecraft:magenta_concrete
fill 379 250 501 379 253 501 minecraft:magenta_concrete
fill 380 250 500 380 253 500 minecraft:magenta_concrete
fill 381 250 501 381 253 501 minecraft:magenta_concrete
setblock 409 250 484 minecraft:sea_lantern
setblock 409 250 486 minecraft:sea_lantern
setblock 409 250 488 minecraft:sea_lantern
setblock 409 250 490 minecraft:sea_lantern
setblock 410 250 483 minecraft:sea_lantern
setblock 410 250 485 minecraft:sea_lantern
setblock 410 250 487 minecraft:sea_lantern
setblock 410 250 489 minecraft:sea_lantern
setblock 410 250 491 minecraft:sea_lantern
setblock 411 250 484 minecraft:sea_lantern
setblock 411 250 486 minecraft:sea_lantern
setblock 411 250 488 minecraft:sea_lantern
setblock 411 250 490 minecraft:sea_lantern
setblock 412 250 483 minecraft:sea_lantern
setblock 412 250 485 minecraft:sea_lantern
setblock 412 250 487 minecraft:sea_lantern
setblock 412 250 489 minecraft:sea_lantern
setblock 412 250 491 minecraft:sea_lantern
setblock 413 250 484 minecraft:sea_lantern
setblock 413 250 486 minecraft:sea_lantern
setblock 413 250 488 minecraft:sea_lantern
setblock 413 250 490 minecraft:sea_lantern
setblock 414 250 483 minecraft:sea_lantern
setblock 414 250 485 minecraft:sea_lantern
setblock 414 250 487 minecraft:sea_lantern
setblock 414 250 489 minecraft:sea_lantern
setblock 414 250 491 minecraft:sea_lantern
setblock 415 250 484 minecraft:sea_lantern
setblock 415 250 486 minecraft:sea_lantern
setblock 415 250 488 minecraft:sea_lantern
setblock 415 250 490 minecraft:sea_lantern
setblock 416 250 483 minecraft:sea_lantern
setblock 416 250 485 minecraft:sea_lantern
setblock 416 250 487 minecraft:sea_lantern
setblock 416 250 489 minecraft:sea_lantern
setblock 416 250 491 minecraft:sea_lantern
setblock 417 250 484 minecraft:sea_lantern
setblock 417 250 486 minecraft:sea_lantern
setblock 417 250 488 minecraft:sea_lantern
setblock 417 250 490 minecraft:sea_lantern
fill 379 251 500 379 253 500 minecraft:magenta_concrete
fill 380 251 502 380 253 502 minecraft:magenta_concrete
fill 381 251 500 381 253 500 minecraft:magenta_concrete
fill 409 251 484 409 252 484 minecraft:black_concrete
fill 409 251 486 409 252 486 minecraft:black_concrete
fill 409 251 488 409 252 488 minecraft:black_concrete
fill 409 251 490 409 252 490 minecraft:black_concrete
fill 410 251 483 410 252 483 minecraft:black_concrete
fill 410 251 485 410 252 485 minecraft:black_concrete
fill 410 251 487 410 252 487 minecraft:black_concrete
fill 410 251 489 410 252 489 minecraft:black_concrete
fill 410 251 491 410 252 491 minecraft:black_concrete
fill 411 251 484 411 252 484 minecraft:black_concrete
fill 411 251 486 411 252 486 minecraft:black_concrete
fill 411 251 488 411 252 488 minecraft:black_concrete
fill 411 251 490 411 252 490 minecraft:black_concrete
fill 412 251 483 412 252 483 minecraft:black_concrete
fill 412 251 485 412 252 485 minecraft:black_concrete
fill 412 251 487 412 252 487 minecraft:black_concrete
fill 412 251 489 412 252 489 minecraft:black_concrete
fill 412 251 491 412 252 491 minecraft:black_concrete
fill 413 251 484 413 252 484 minecraft:black_concrete
fill 413 251 486 413 252 486 minecraft:black_concrete
fill 413 251 488 413 252 488 minecraft:black_concrete
fill 413 251 490 413 252 490 minecraft:black_concrete
fill 414 251 483 414 252 483 minecraft:black_concrete
fill 414 251 485 414 252 485 minecraft:black_concrete
fill 414 251 487 414 252 487 minecraft:black_concrete
fill 414 251 489 414 252 489 minecraft:black_concrete
fill 414 251 491 414 252 491 minecraft:black_concrete
fill 415 251 484 415 252 484 minecraft:black_concrete
fill 415 251 486 415 252 486 minecraft:black_concrete
fill 415 251 488 415 252 488 minecraft:black_concrete
fill 415 251 490 415 252 490 minecraft:black_concrete
fill 416 251 483 416 252 483 minecraft:black_concrete
fill 416 251 485 416 252 485 minecraft:black_concrete
fill 416 251 487 416 252 487 minecraft:black_concrete
fill 416 251 489 416 252 489 minecraft:black_concrete
fill 416 251 491 416 252 491 minecraft:black_concrete
fill 417 251 484 417 252 484 minecraft:black_concrete
fill 417 251 486 417 252 486 minecraft:black_concrete
fill 417 251 488 417 252 488 minecraft:black_concrete
fill 417 251 490 417 252 490 minecraft:black_concrete
fill 377 252 464 377 253 469 minecraft:black_concrete
fill 377 252 472 378 252 477 minecraft:black_concrete
fill 377 252 480 378 252 485 minecraft:black_concrete
fill 377 252 488 378 252 493 minecraft:black_concrete
fill 377 252 496 378 252 501 minecraft:black_concrete
fill 377 252 504 382 255 504 minecraft:black_concrete
fill 378 252 465 378 252 471 minecraft:black_concrete
fill 378 252 478 378 252 479 minecraft:black_concrete
fill 378 252 486 378 252 487 minecraft:black_concrete
fill 378 252 494 378 252 495 minecraft:black_concrete
fill 378 252 502 378 252 503 minecraft:black_concrete
fill 379 252 465 416 252 465 minecraft:black_concrete
fill 379 252 502 379 253 502 minecraft:magenta_concrete
fill 379 252 503 417 252 503 minecraft:black_concrete
fill 380 252 464 385 253 464 minecraft:black_concrete
fill 380 252 499 380 253 499 minecraft:magenta_concrete
fill 381 252 502 381 253 502 minecraft:magenta_concrete
fill 385 252 504 390 253 504 minecraft:black_concrete
fill 388 252 464 393 253 464 minecraft:black_concrete
fill 393 252 504 398 253 504 minecraft:black_concrete
fill 396 252 464 401 253 464 minecraft:black_concrete
fill 401 252 504 406 253 504 minecraft:black_concrete
fill 404 252 464 409 253 464 minecraft:black_concrete
fill 409 252 504 414 253 504 minecraft:black_concrete
fill 412 252 464 417 253 464 minecraft:black_concrete
fill 412 252 500 412 257 500 minecraft:magenta_concrete
fill 416 252 466 416 252 482 minecraft:black_concrete
fill 416 252 492 416 252 502 minecraft:black_concrete
fill 417 252 467 417 253 472 minecraft:black_concrete
fill 417 252 475 417 253 480 minecraft:black_concrete
fill 417 252 492 417 253 496 minecraft:black_concrete
fill 417 252 499 417 253 502 minecraft:black_concrete
fill 417 252 504 417 253 504 minecraft:black_concrete
fill 377 253 472 377 253 477 minecraft:black_concrete
fill 377 253 480 377 253 485 minecraft:black_concrete
fill 377 253 488 377 253 493 minecraft:black_concrete
fill 377 253 496 377 253 501 minecraft:black_concrete
fill 378 253 500 378 253 501 minecraft:magenta_concrete
setblock 379 253 499 minecraft:magenta_concrete
setblock 380 253 503 minecraft:magenta_concrete
setblock 381 253 499 minecraft:magenta_concrete
fill 382 253 500 382 253 501 minecraft:magenta_concrete
setblock 409 253 484 minecraft:sea_lantern
setblock 409 253 486 minecraft:sea_lantern
setblock 409 253 488 minecraft:sea_lantern
setblock 409 253 490 minecraft:sea_lantern
setblock 410 253 483 minecraft:sea_lantern
setblock 410 253 485 minecraft:sea_lantern
setblock 410 253 487 minecraft:sea_lantern
setblock 410 253 489 minecraft:sea_lantern
setblock 410 253 491 minecraft:sea_lantern
setblock 411 253 484 minecraft:sea_lantern
setblock 411 253 486 minecraft:sea_lantern
setblock 411 253 488 minecraft:sea_lantern
setblock 411 253 490 minecraft:sea_lantern
setblock 412 253 483 minecraft:sea_lantern
setblock 412 253 485 minecraft:sea_lantern
setblock 412 253 487 minecraft:sea_lantern
setblock 412 253 489 minecraft:sea_lantern
setblock 412 253 491 minecraft:sea_lantern
setblock 413 253 484 minecraft:sea_lantern
setblock 413 253 486 minecraft:sea_lantern
setblock 413 253 488 minecraft:sea_lantern
setblock 413 253 490 minecraft:sea_lantern
fill 413 253 500 413 257 500 minecraft:magenta_concrete
setblock 414 253 483 minecraft:sea_lantern
setblock 414 253 485 minecraft:sea_lantern
setblock 414 253 487 minecraft:sea_lantern
setblock 414 253 489 minecraft:sea_lantern
setblock 414 253 491 minecraft:sea_lantern
setblock 415 253 484 minecraft:sea_lantern
setblock 415 253 486 minecraft:sea_lantern
setblock 415 253 488 minecraft:sea_lantern
setblock 415 253 490 minecraft:sea_lantern
setblock 416 253 483 minecraft:sea_lantern
setblock 416 253 485 minecraft:sea_lantern
setblock 416 253 487 minecraft:sea_lantern
setblock 416 253 489 minecraft:sea_lantern
setblock 416 253 491 minecraft:sea_lantern
setblock 417 253 484 minecraft:sea_lantern
setblock 417 253 486 minecraft:sea_lantern
setblock 417 253 488 minecraft:sea_lantern
setblock 417 253 490 minecraft:sea_lantern
setblock 417 253 503 minecraft:black_concrete
fill 377 254 498 384 255 501 minecraft:black_concrete
fill 378 254 502 384 255 503 minecraft:black_concrete
fill 409 254 484 409 255 484 minecraft:black_concrete
fill 409 254 486 409 255 486 minecraft:black_concrete
fill 409 254 488 409 255 488 minecraft:black_concrete
fill 409 254 490 409 255 490 minecraft:black_concrete
fill 410 254 483 410 255 483 minecraft:black_concrete
fill 410 254 485 410 255 485 minecraft:black_concrete
fill 410 254 487 410 255 487 minecraft:black_concrete
fill 410 254 489 410 255 489 minecraft:black_concrete
fill 410 254 491 410 255 491 minecraft:black_concrete
fill 411 254 484 411 255 484 minecraft:black_concrete
fill 411 254 486 411 255 486 minecraft:black_concrete
fill 411 254 488 411 255 488 minecraft:black_concrete
fill 411 254 490 411 255 490 minecraft:black_concrete
fill 411 254 499 411 257 501 minecraft:magenta_concrete
fill 412 254 483 412 255 483 minecraft:black_concrete
fill 412 254 485 412 255 485 minecraft:black_concrete
fill 412 254 487 412 255 487 minecraft:black_concrete
fill 412 254 489 412 255 489 minecraft:black_concrete
fill 412 254 491 412 255 491 minecraft:black_concrete
fill 412 254 499 413 257 499 minecraft:magenta_concrete
fill 412 254 501 413 257 501 minecraft:magenta_concrete
fill 413 254 484 413 255 484 minecraft:black_concrete
fill 413 254 486 413 255 486 minecraft:black_concrete
fill 413 254 488 413 255 488 minecraft:black_concrete
fill 413 254 490 413 255 490 minecraft:black_concrete
fill 414 254 483 414 255 483 minecraft:black_concrete
fill 414 254 485 414 255 485 minecraft:black_concrete
fill 414 254 487 414 255 487 minecraft:black_concrete
fill 414 254 489 414 255 489 minecraft:black_concrete
fill 414 254 491 414 255 491 minecraft:black_concrete
fill 415 254 484 415 255 484 minecraft:black_concrete
fill 415 254 486 415 255 486 minecraft:black_concrete
fill 415 254 488 415 255 488 minecraft:black_concrete
fill 415 254 490 415 255 490 minecraft:black_concrete
fill 416 254 483 416 255 483 minecraft:black_concrete
fill 416 254 485 416 255 485 minecraft:black_concrete
fill 416 254 487 416 255 487 minecraft:black_concrete
fill 416 254 489 416 255 489 minecraft:black_concrete
fill 416 254 491 416 255 491 minecraft:black_concrete
fill 417 254 484 417 255 484 minecraft:black_concrete
fill 417 254 486 417 255 486 minecraft:black_concrete
fill 417 254 488 417 255 488 minecraft:black_concrete
fill 417 254 490 417 273 490 minecraft:black_concrete
fill 385 255 496 386 256 497 minecraft:magenta_concrete
fill 410 255 500 410 257 500 minecraft:magenta_concrete
fill 412 255 498 413 257 498 minecraft:magenta_concrete
fill 412 255 502 413 257 502 minecraft:magenta_concrete
fill 414 255 499 414 257 501 minecraft:magenta_concrete
fill 376 256 468 376 261 468 minecraft:sea_lantern
fill 376 256 476 376 261 476 minecraft:sea_lantern
fill 376 256 484 376 261 484 minecraft:sea_lantern
fill 376 256 492 376 261 492 minecraft:sea_lantern
fill 376 256 493 376 307 498 minecraft:magenta_concrete
fill 376 256 499 376 256 501 minecraft:sea_lantern
fill 376 256 502 376 307 502 minecraft:magenta_concrete
setblock 376 256 503 minecraft:sea_lantern
fill 376 256 504 376 307 504 minecraft:magenta_concrete
setblock 377 256 498 minecraft:sea_lantern
fill 377 256 499 377 273 499 minecraft:black_concrete
setblock 377 256 500 minecraft:sea_lantern
fill 377 256 501 377 273 501 minecraft:black_concrete
setblock 377 256 502 minecraft:sea_lantern
setblock 377 256 504 minecraft:sea_lantern
fill 378 256 498 378 273 498 minecraft:black_concrete
setblock 378 256 499 minecraft:sea_lantern
fill 378 256 500 378 273 500 minecraft:black_concrete
setblock 378 256 501 minecraft:sea_lantern
fill 378 256 502 378 273 502 minecraft:black_concrete
setblock 378 256 503 minecraft:sea_lantern
fill 378 256 504 378 273 504 minecraft:black_concrete
setblock 379 256 466 minecraft:light[level=14]
setblock 379 256 474 minecraft:light[level=14]
setblock 379 256 482 minecraft:light[level=14]
setblock 379 256 490 minecraft:light[level=14]
setblock 379 256 498 minecraft:sea_lantern
fill 379 256 499 379 273 499 minecraft:black_concrete
setblock 379 256 500 minecraft:sea_lantern
fill 379 256 501 379 273 501 minecraft:black_concrete
setblock 379 256 502 minecraft:sea_lantern
fill 379 256 503 379 273 503 minecraft:black_concrete
fill 379 256 504 379 256 505 minecraft:sea_lantern
fill 380 256 498 380 273 498 minecraft:black_concrete
setblock 380 256 499 minecraft:sea_lantern
fill 380 256 500 380 273 500 minecraft:black_concrete
setblock 380 256 501 minecraft:sea_lantern
fill 380 256 502 380 273 502 minecraft:black_concrete
setblock 380 256 503 minecraft:sea_lantern
fill 380 256 504 380 273 504 minecraft:black_concrete
setblock 381 256 498 minecraft:sea_lantern
fill 381 256 499 381 273 499 minecraft:black_concrete
setblock 381 256 500 minecraft:sea_lantern
fill 381 256 501 381 273 501 minecraft:black_concrete
setblock 381 256 502 minecraft:sea_lantern
fill 381 256 503 381 273 503 minecraft:black_concrete
setblock 381 256 504 minecraft:sea_lantern
fill 382 256 498 382 273 498 minecraft:black_concrete
setblock 382 256 499 minecraft:sea_lantern
fill 382 256 500 382 273 500 minecraft:black_concrete
setblock 382 256 501 minecraft:sea_lantern
fill 382 256 502 382 273 502 minecraft:black_concrete
setblock 382 256 503 minecraft:sea_lantern
fill 382 256 504 382 273 504 minecraft:black_concrete
fill 383 256 463 383 261 463 minecraft:sea_lantern
setblock 383 256 498 minecraft:sea_lantern
fill 383 256 499 383 273 499 minecraft:black_concrete
setblock 383 256 500 minecraft:sea_lantern
fill 383 256 501 383 273 501 minecraft:black_concrete
setblock 383 256 502 minecraft:sea_lantern
fill 383 256 503 383 273 503 minecraft:black_concrete
setblock 383 256 504 minecraft:sea_lantern
fill 384 256 498 384 273 498 minecraft:black_concrete
setblock 384 256 499 minecraft:sea_lantern
fill 384 256 500 384 273 500 minecraft:black_concrete
setblock 384 256 501 minecraft:sea_lantern
fill 384 256 502 384 273 502 minecraft:black_concrete
setblock 384 256 503 minecraft:sea_lantern
fill 384 256 504 384 273 504 minecraft:black_concrete
setblock 387 256 466 minecraft:light[level=14]
setblock 387 256 474 minecraft:light[level=14]
setblock 387 256 482 minecraft:light[level=14]
setblock 387 256 490 minecraft:light[level=14]
setblock 387 256 498 minecraft:light[level=14]
fill 387 256 505 387 261 505 minecraft:sea_lantern
fill 391 256 463 391 261 463 minecraft:sea_lantern
setblock 395 256 466 minecraft:light[level=14]
setblock 395 256 474 minecraft:light[level=14]
setblock 395 256 482 minecraft:light[level=14]
setblock 395 256 490 minecraft:light[level=14]
setblock 395 256 498 minecraft:light[level=14]
fill 395 256 505 395 261 505 minecraft:sea_lantern
fill 399 256 463 399 261 463 minecraft:sea_lantern
setblock 403 256 466 minecraft:light[level=14]
setblock 403 256 474 minecraft:light[level=14]
setblock 403 256 482 minecraft:light[level=14]
setblock 403 256 490 minecraft:light[level=14]
setblock 403 256 498 minecraft:light[level=14]
fill 403 256 505 403 261 505 minecraft:sea_lantern
fill 407 256 463 407 261 463 minecraft:sea_lantern
fill 410 256 499 410 257 499 minecraft:magenta_concrete
fill 410 256 501 410 257 501 minecraft:magenta_concrete
setblock 411 256 466 minecraft:light[level=14]
setblock 411 256 474 minecraft:light[level=14]
setblock 411 256 482 minecraft:light[level=14]
setblock 411 256 490 minecraft:light[level=14]
fill 411 256 498 411 257 498 minecraft:magenta_concrete
fill 411 256 502 411 257 502 minecraft:magenta_concrete
fill 411 256 505 411 261 505 minecraft:sea_lantern
fill 414 256 498 414 257 498 minecraft:magenta_concrete
fill 414 256 502 414 257 502 minecraft:magenta_concrete
fill 415 256 463 415 261 463 minecraft:sea_lantern
fill 415 256 499 415 257 501 minecraft:magenta_concrete
fill 418 256 468 418 261 468 minecraft:sea_lantern
fill 418 256 476 418 261 476 minecraft:sea_lantern
fill 418 256 484 418 261 484 minecraft:sea_lantern
fill 418 256 492 418 261 492 minecraft:sea_lantern
fill 418 256 500 418 261 500 minecraft:sea_lantern
fill 376 257 499 376 258 499 minecraft:magenta_concrete
fill 376 257 500 376 261 500 minecraft:sea_lantern
fill 376 257 501 376 258 501 minecraft:magenta_concrete
fill 376 257 503 376 258 503 minecraft:magenta_concrete
fill 377 257 498 377 258 498 minecraft:black_concrete
fill 377 257 500 377 258 500 minecraft:black_concrete
fill 377 257 502 377 258 502 minecraft:black_concrete
fill 377 257 504 377 258 504 minecraft:black_concrete
fill 378 257 499 378 258 499 minecraft:black_concrete
fill 378 257 501 378 258 501 minecraft:black_concrete
fill 378 257 503 378 258 503 minecraft:black_concrete
fill 379 257 498 379 258 498 minecraft:black_concrete
fill 379 257 500 379 258 500 minecraft:black_concrete
fill 379 257 502 379 258 502 minecraft:black_concrete
fill 379 257 504 379 258 504 minecraft:black_concrete
fill 379 257 505 379 261 505 minecraft:sea_lantern
fill 380 257 499 380 258 499 minecraft:black_concrete
fill 380 257 501 380 258 501 minecraft:black_concrete
fill 380 257 503 380 258 503 minecraft:black_concrete
fill 381 257 498 381 258 498 minecraft:black_concrete
fill 381 257 500 381 258 500 minecraft:black_concrete
fill 381 257 502 381 258 502 minecraft:black_concrete
fill 381 257 504 381 258 504 minecraft:black_concrete
fill 382 257 499 382 258 499 minecraft:black_concrete
fill 382 257 501 382 258 501 minecraft:black_concrete
fill 382 257 503 382 258 503 minecraft:black_concrete
fill 383 257 498 383 258 498 minecraft:black_concrete
fill 383 257 500 383 258 500 minecraft:black_concrete
fill 383 257 502 383 258 502 minecraft:black_concrete
fill 383 257 504 383 258 504 minecraft:black_concrete
fill 384 257 499 384 258 499 minecraft:black_concrete
fill 384 257 501 384 258 501 minecraft:black_concrete
fill 384 257 503 384 258 503 minecraft:black_concrete
fill 409 257 499 409 257 501 minecraft:magenta_concrete
setblock 410 257 498 minecraft:magenta_concrete
setblock 410 257 502 minecraft:magenta_concrete
fill 411 257 497 414 257 497 minecraft:magenta_concrete
fill 411 257 503 414 257 503 minecraft:magenta_concrete
fill 412 257 486 413 258 487 minecraft:magenta_concrete
setblock 415 257 498 minecraft:magenta_concrete
setblock 415 257 502 minecraft:magenta_concrete
fill 408 258 494 416 258 503 minecraft:black_concrete
fill 409 258 504 414 258 504 minecraft:black_concrete
fill 417 258 494 417 258 496 minecraft:black_concrete
fill 417 258 499 417 258 504 minecraft:black_concrete
setblock 376 259 499 minecraft:sea_lantern
setblock 376 259 501 minecraft:sea_lantern
setblock 376 259 503 minecraft:sea_lantern
setblock 377 259 498 minecraft:sea_lantern
setblock 377 259 500 minecraft:sea_lantern
setblock 377 259 502 minecraft:sea_lantern
setblock 377 259 504 minecraft:sea_lantern
setblock 378 259 499 minecraft:sea_lantern
setblock 378 259 501 minecraft:sea_lantern
setblock 378 259 503 minecraft:sea_lantern
setblock 379 259 498 minecraft:sea_lantern
setblock 379 259 500 minecraft:sea_lantern
setblock 379 259 502 minecraft:sea_lantern
setblock 379 259 504 minecraft:sea_lantern
setblock 380 259 499 minecraft:sea_lantern
setblock 380 259 501 minecraft:sea_lantern
setblock 380 259 503 minecraft:sea_lantern
setblock 381 259 498 minecraft:sea_lantern
setblock 381 259 500 minecraft:sea_lantern
setblock 381 259 502 minecraft:sea_lantern
setblock 381 259 504 minecraft:sea_lantern
setblock 382 259 499 minecraft:sea_lantern
setblock 382 259 501 minecraft:sea_lantern
setblock 382 259 503 minecraft:sea_lantern
setblock 383 259 498 minecraft:sea_lantern
setblock 383 259 500 minecraft:sea_lantern
setblock 383 259 502 minecraft:sea_lantern
setblock 383 259 504 minecraft:sea_lantern
setblock 384 259 499 minecraft:sea_lantern
setblock 384 259 501 minecraft:sea_lantern
setblock 384 259 503 minecraft:sea_lantern
fill 404 259 505 407 307 505 minecraft:magenta_concrete
fill 408 259 494 408 273 494 minecraft:black_concrete
setblock 408 259 495 minecraft:sea_lantern
fill 408 259 496 408 273 496 minecraft:black_concrete
setblock 408 259 497 minecraft:sea_lantern
fill 408 259 498 408 273 498 minecraft:black_concrete
setblock 408 259 499 minecraft:sea_lantern
fill 408 259 500 408 273 500 minecraft:black_concrete
setblock 408 259 501 minecraft:sea_lantern
fill 408 259 502 408 273 502 minecraft:black_concrete
setblock 408 259 503 minecraft:sea_lantern
setblock 408 259 505 minecraft:sea_lantern
setblock 409 259 494 minecraft:sea_lantern
fill 409 259 495 409 273 495 minecraft:black_concrete
setblock 409 259 496 minecraft:sea_lantern
fill 409 259 497 409 273 497 minecraft:black_concrete
setblock 409 259 498 minecraft:sea_lantern
fill 409 259 499 409 273 499 minecraft:black_concrete
setblock 409 259 500 minecraft:sea_lantern
fill 409 259 501 409 273 501 minecraft:black_concrete
setblock 409 259 502 minecraft:sea_lantern
fill 409 259 503 409 273 503 minecraft:black_concrete
setblock 409 259 504 minecraft:sea_lantern
fill 409 259 505 409 307 505 minecraft:magenta_concrete
fill 410 259 494 410 273 494 minecraft:black_concrete
setblock 410 259 495 minecraft:sea_lantern
fill 410 259 496 410 273 496 minecraft:black_concrete
setblock 410 259 497 minecraft:sea_lantern
fill 410 259 498 410 273 498 minecraft:black_concrete
setblock 410 259 499 minecraft:sea_lantern
fill 410 259 500 410 273 500 minecraft:black_concrete
setblock 410 259 501 minecraft:sea_lantern
fill 410 259 502 410 273 502 minecraft:black_concrete
setblock 410 259 503 minecraft:sea_lantern
fill 410 259 504 410 273 504 minecraft:black_concrete
setblock 410 259 505 minecraft:sea_lantern
setblock 411 259 494 minecraft:sea_lantern
fill 411 259 495 411 273 495 minecraft:black_concrete
setblock 411 259 496 minecraft:sea_lantern
fill 411 259 497 411 273 497 minecraft:black_concrete
setblock 411 259 498 minecraft:sea_lantern
fill 411 259 499 411 273 499 minecraft:black_concrete
setblock 411 259 500 minecraft:sea_lantern
fill 411 259 501 411 273 501 minecraft:black_concrete
setblock 411 259 502 minecraft:sea_lantern
fill 411 259 503 411 273 503 minecraft:black_concrete
setblock 411 259 504 minecraft:sea_lantern
fill 412 259 494 412 273 494 minecraft:black_concrete
setblock 412 259 495 minecraft:sea_lantern
fill 412 259 496 412 273 496 minecraft:black_concrete
setblock 412 259 497 minecraft:sea_lantern
fill 412 259 498 412 273 498 minecraft:black_concrete
setblock 412 259 499 minecraft:sea_lantern
fill 412 259 500 412 273 500 minecraft:black_concrete
setblock 412 259 501 minecraft:sea_lantern
fill 412 259 502 412 273 502 minecraft:black_concrete
setblock 412 259 503 minecraft:sea_lantern
fill 412 259 504 412 273 504 minecraft:black_concrete
setblock 412 259 505 minecraft:sea_lantern
setblock 413 259 494 minecraft:sea_lantern
fill 413 259 495 413 273 495 minecraft:black_concrete
setblock 413 259 496 minecraft:sea_lantern
fill 413 259 497 413 273 497 minecraft:black_concrete
setblock 413 259 498 minecraft:sea_lantern
fill 413 259 499 413 273 499 minecraft:black_concrete
setblock 413 259 500 minecraft:sea_lantern
fill 413 259 501 413 273 501 minecraft:black_concrete
setblock 413 259 502 minecraft:sea_lantern
fill 413 259 503 413 273 503 minecraft:black_concrete
setblock 413 259 504 minecraft:sea_lantern
fill 413 259 505 413 307 505 minecraft:magenta_concrete
fill 414 259 494 414 273 494 minecraft:black_concrete
setblock 414 259 495 minecraft:sea_lantern
fill 414 259 496 414 273 496 minecraft:black_concrete
setblock 414 259 497 minecraft:sea_lantern
fill 414 259 498 414 273 498 minecraft:black_concrete
setblock 414 259 499 minecraft:sea_lantern
fill 414 259 500 414 273 500 minecraft:black_concrete
setblock 414 259 501 minecraft:sea_lantern
fill 414 259 502 414 273 502 minecraft:black_concrete
setblock 414 259 503 minecraft:sea_lantern
fill 414 259 504 414 273 504 minecraft:black_concrete
setblock 414 259 505 minecraft:sea_lantern
setblock 415 259 494 minecraft:sea_lantern
fill 415 259 495 415 273 495 minecraft:black_concrete
setblock 415 259 496 minecraft:sea_lantern
fill 415 259 497 415 273 497 minecraft:black_concrete
setblock 415 259 498 minecraft:sea_lantern
fill 415 259 499 415 273 499 minecraft:black_concrete
setblock 415 259 500 minecraft:sea_lantern
fill 415 259 501 415 273 501 minecraft:black_concrete
setblock 415 259 502 minecraft:sea_lantern
fill 415 259 503 415 273 503 minecraft:black_concrete
setblock 415 259 504 minecraft:sea_lantern
fill 415 259 505 415 307 505 minecraft:magenta_concrete
fill 416 259 494 416 273 494 minecraft:black_concrete
setblock 416 259 495 minecraft:sea_lantern
fill 416 259 496 416 273 496 minecraft:black_concrete
setblock 416 259 497 minecraft:sea_lantern
fill 416 259 498 416 273 498 minecraft:black_concrete
setblock 416 259 499 minecraft:sea_lantern
fill 416 259 500 416 273 500 minecraft:black_concrete
setblock 416 259 501 minecraft:sea_lantern
fill 416 259 502 416 273 502 minecraft:black_concrete
setblock 416 259 503 minecraft:sea_lantern
fill 416 259 504 416 273 504 minecraft:black_concrete
setblock 416 259 505 minecraft:sea_lantern
setblock 417 259 494 minecraft:sea_lantern
fill 417 259 495 417 273 495 minecraft:black_concrete
setblock 417 259 496 minecraft:sea_lantern
fill 417 259 497 417 273 497 minecraft:black_concrete
setblock 417 259 498 minecraft:sea_lantern
fill 417 259 499 417 273 499 minecraft:black_concrete
setblock 417 259 500 minecraft:sea_lantern
fill 417 259 501 417 273 501 minecraft:black_concrete
setblock 417 259 502 minecraft:sea_lantern
fill 417 259 503 417 273 503 minecraft:black_concrete
setblock 417 259 504 minecraft:sea_lantern
fill 417 259 505 417 307 505 minecraft:magenta_concrete
fill 376 260 499 376 261 499 minecraft:magenta_concrete
fill 376 260 501 376 261 501 minecraft:magenta_concrete
fill 376 260 503 376 261 503 minecraft:magenta_concrete
fill 377 260 498 377 261 498 minecraft:black_concrete
fill 377 260 500 377 261 500 minecraft:black_concrete
fill 377 260 502 377 261 502 minecraft:black_concrete
fill 377 260 504 377 261 504 minecraft:black_concrete
fill 378 260 499 378 261 499 minecraft:black_concrete
fill 378 260 501 378 261 501 minecraft:black_concrete
fill 378 260 503 378 261 503 minecraft:black_concrete
fill 379 260 498 379 261 498 minecraft:black_concrete
fill 379 260 500 379 261 500 minecraft:black_concrete
fill 379 260 502 379 261 502 minecraft:black_concrete
fill 379 260 504 379 261 504 minecraft:black_concrete
fill 380 260 499 380 261 499 minecraft:black_concrete
fill 380 260 501 380 261 501 minecraft:black_concrete
fill 380 260 503 380 261 503 minecraft:black_concrete
fill 381 260 498 381 261 498 minecraft:black_concrete
fill 381 260 500 381 261 500 minecraft:black_concrete
fill 381 260 502 381 261 502 minecraft:black_concrete
fill 381 260 504 381 261 504 minecraft:black_concrete
fill 382 260 499 382 261 499 minecraft:black_concrete
fill 382 260 501 382 261 501 minecraft:black_concrete
fill 382 260 503 382 261 503 minecraft:black_concrete
fill 383 260 498 383 261 498 minecraft:black_concrete
fill 383 260 500 383 261 500 minecraft:black_concrete
fill 383 260 502 383 261 502 minecraft:black_concrete
fill 383 260 504 383 261 504 minecraft:black_concrete
fill 384 260 499 384 261 499 minecraft:black_concrete
fill 384 260 501 384 261 501 minecraft:black_concrete
fill 384 260 503 384 261 503 minecraft:black_concrete
fill 408 260 495 408 261 495 minecraft:black_concrete
fill 408 260 497 408 261 497 minecraft:black_concrete
fill 408 260 499 408 261 499 minecraft:black_concrete
fill 408 260 501 408 261 501 minecraft:black_concrete
fill 408 260 503 408 261 503 minecraft:black_concrete
fill 408 260 505 408 261 505 minecraft:magenta_concrete
fill 409 260 494 409 261 494 minecraft:black_concrete
fill 409 260 496 409 261 496 minecraft:black_concrete
fill 409 260 498 409 261 498 minecraft:black_concrete
fill 409 260 500 409 261 500 minecraft:black_concrete
fill 409 260 502 409 261 502 minecraft:black_concrete
fill 409 260 504 409 261 504 minecraft:black_concrete
fill 410 260 495 410 261 495 minecraft:black_concrete
fill 410 260 497 410 261 497 minecraft:black_concrete
fill 410 260 499 410 261 499 minecraft:black_concrete
fill 410 260 501 410 261 501 minecraft:black_concrete
fill 410 260 503 410 261 503 minecraft:black_concrete
fill 410 260 505 410 261 505 minecraft:magenta_concrete
fill 411 260 494 411 261 494 minecraft:black_concrete
fill 411 260 496 411 261 496 minecraft:black_concrete
fill 411 260 498 411 261 498 minecraft:black_concrete
fill 411 260 500 411 261 500 minecraft:black_concrete
fill 411 260 502 411 261 502 minecraft:black_concrete
fill 411 260 504 411 261 504 minecraft:black_concrete
fill 412 260 495 412 261 495 minecraft:black_concrete
fill 412 260 497 412 261 497 minecraft:black_concrete
fill 412 260 499 412 261 499 minecraft:black_concrete
fill 412 260 501 412 261 501 minecraft:black_concrete
fill 412 260 503 412 261 503 minecraft:black_concrete
fill 412 260 505 412 261 505 minecraft:magenta_concrete
fill 413 260 494 413 261 494 minecraft:black_concrete
fill 413 260 496 413 261 496 minecraft:black_concrete
fill 413 260 498 413 261 498 minecraft:black_concrete
fill 413 260 500 413 261 500 minecraft:black_concrete
fill 413 260 502 413 261 502 minecraft:black_concrete
fill 413 260 504 413 261 504 minecraft:black_concrete
fill 414 260 495 414 261 495 minecraft:black_concrete
fill 414 260 497 414 261 497 minecraft:black_concrete
fill 414 260 499 414 261 499 minecraft:black_concrete
fill 414 260 501 414 261 501 minecraft:black_concrete
fill 414 260 503 414 261 503 minecraft:black_concrete
fill 414 260 505 414 261 505 minecraft:magenta_concrete
fill 415 260 494 415 261 494 minecraft:black_concrete
fill 415 260 496 415 261 496 minecraft:black_concrete
fill 415 260 498 415 261 498 minecraft:black_concrete
fill 415 260 500 415 261 500 minecraft:black_concrete
fill 415 260 502 415 261 502 minecraft:black_concrete
fill 415 260 504 415 261 504 minecraft:black_concrete
fill 416 260 495 416 261 495 minecraft:black_concrete
fill 416 260 497 416 261 497 minecraft:black_concrete
fill 416 260 499 416 261 499 minecraft:black_concrete
fill 416 260 501 416 261 501 minecraft:black_concrete
fill 416 260 503 416 261 503 minecraft:black_concrete
fill 416 260 505 416 261 505 minecraft:magenta_concrete
fill 417 260 494 417 261 494 minecraft:black_concrete
fill 417 260 496 417 261 496 minecraft:black_concrete
fill 417 260 498 417 261 498 minecraft:black_concrete
fill 417 260 500 417 261 500 minecraft:black_concrete
fill 417 260 502 417 261 502 minecraft:black_concrete
fill 417 260 504 417 261 504 minecraft:black_concrete
fill 376 262 468 376 269 468 minecraft:magenta_concrete
fill 376 262 476 376 269 476 minecraft:magenta_concrete
fill 376 262 484 376 269 484 minecraft:magenta_concrete
fill 376 262 492 376 269 492 minecraft:magenta_concrete
setblock 376 262 499 minecraft:sea_lantern
fill 376 262 500 376 269 500 minecraft:magenta_concrete
setblock 376 262 501 minecraft:sea_lantern
setblock 376 262 503 minecraft:sea_lantern
setblock 377 262 498 minecraft:sea_lantern
setblock 377 262 500 minecraft:sea_lantern
setblock 377 262 502 minecraft:sea_lantern
setblock 377 262 504 minecraft:sea_lantern
setblock 378 262 499 minecraft:sea_lantern
setblock 378 262 501 minecraft:sea_lantern
setblock 378 262 503 minecraft:sea_lantern
setblock 379 262 498 minecraft:sea_lantern
setblock 379 262 500 minecraft:sea_lantern
setblock 379 262 502 minecraft:sea_lantern
setblock 379 262 504 minecraft:sea_lantern
fill 379 262 505 379 269 505 minecraft:magenta_concrete
setblock 380 262 499 minecraft:sea_lantern
setblock 380 262 501 minecraft:sea_lantern
setblock 380 262 503 minecraft:sea_lantern
setblock 381 262 498 minecraft:sea_lantern
setblock 381 262 500 minecraft:sea_lantern
setblock 381 262 502 minecraft:sea_lantern
setblock 381 262 504 minecraft:sea_lantern
setblock 382 262 499 minecraft:sea_lantern
setblock 382 262 501 minecraft:sea_lantern
setblock 382 262 503 minecraft:sea_lantern
fill 383 262 463 383 269 463 minecraft:magenta_concrete
setblock 383 262 498 minecraft:sea_lantern
setblock 383 262 500 minecraft:sea_lantern
setblock 383 262 502 minecraft:sea_lantern
setblock 383 262 504 minecraft:sea_lantern
setblock 384 262 499 minecraft:sea_lantern
setblock 384 262 501 minecraft:sea_lantern
setblock 384 262 503 minecraft:sea_lantern
fill 387 262 505 387 269 505 minecraft:magenta_concrete
fill 391 262 463 391 269 463 minecraft:magenta_concrete
fill 395 262 505 395 269 505 minecraft:magenta_concrete
fill 399 262 463 399 269 463 minecraft:magenta_concrete
fill 403 262 505 403 269 505 minecraft:magenta_concrete
fill 407 262 463 407 269 463 minecraft:magenta_concrete
setblock 408 262 495 minecraft:sea_lantern
setblock 408 262 497 minecraft:sea_lantern
setblock 408 262 499 minecraft:sea_lantern
setblock 408 262 501 minecraft:sea_lantern
setblock 408 262 503 minecraft:sea_lantern
setblock 408 262 505 minecraft:sea_lantern
setblock 409 262 494 minecraft:sea_lantern
setblock 409 262 496 minecraft:sea_lantern
setblock 409 262 498 minecraft:sea_lantern
setblock 409 262 500 minecraft:sea_lantern
setblock 409 262 502 minecraft:sea_lantern
setblock 409 262 504 minecraft:sea_lantern
setblock 410 262 495 minecraft:sea_lantern
setblock 410 262 497 minecraft:sea_lantern
setblock 410 262 499 minecraft:sea_lantern
setblock 410 262 501 minecraft:sea_lantern
setblock 410 262 503 minecraft:sea_lantern
setblock 410 262 505 minecraft:sea_lantern
setblock 411 262 494 minecraft:sea_lantern
setblock 411 262 496 minecraft:sea_lantern
setblock 411 262 498 minecraft:sea_lantern
setblock 411 262 500 minecraft:sea_lantern
setblock 411 262 502 minecraft:sea_lantern
setblock 411 262 504 minecraft:sea_lantern
fill 411 262 505 411 269 505 minecraft:magenta_concrete
setblock 412 262 495 minecraft:sea_lantern
setblock 412 262 497 minecraft:sea_lantern
setblock 412 262 499 minecraft:sea_lantern
setblock 412 262 501 minecraft:sea_lantern
setblock 412 262 503 minecraft:sea_lantern
setblock 412 262 505 minecraft:sea_lantern
setblock 413 262 494 minecraft:sea_lantern
setblock 413 262 496 minecraft:sea_lantern
setblock 413 262 498 minecraft:sea_lantern
setblock 413 262 500 minecraft:sea_lantern
setblock 413 262 502 minecraft:sea_lantern
setblock 413 262 504 minecraft:sea_lantern
setblock 414 262 495 minecraft:sea_lantern
setblock 414 262 497 minecraft:sea_lantern
setblock 414 262 499 minecraft:sea_lantern
setblock 414 262 501 minecraft:sea_lantern
setblock 414 262 503 minecraft:sea_lantern
setblock 414 262 505 minecraft:sea_lantern
fill 415 262 463 415 269 463 minecraft:magenta_concrete
setblock 415 262 494 minecraft:sea_lantern
setblock 415 262 496 minecraft:sea_lantern
setblock 415 262 498 minecraft:sea_lantern
setblock 415 262 500 minecraft:sea_lantern
setblock 415 262 502 minecraft:sea_lantern
setblock 415 262 504 minecraft:sea_lantern
setblock 416 262 495 minecraft:sea_lantern
setblock 416 262 497 minecraft:sea_lantern
setblock 416 262 499 minecraft:sea_lantern
setblock 416 262 501 minecraft:sea_lantern
setblock 416 262 503 minecraft:sea_lantern
setblock 416 262 505 minecraft:sea_lantern
setblock 417 262 494 minecraft:sea_lantern
setblock 417 262 496 minecraft:sea_lantern
setblock 417 262 498 minecraft:sea_lantern
setblock 417 262 500 minecraft:sea_lantern
setblock 417 262 502 minecraft:sea_lantern
setblock 417 262 504 minecraft:sea_lantern
fill 418 262 468 418 269 468 minecraft:magenta_concrete
fill 418 262 476 418 269 476 minecraft:magenta_concrete
fill 418 262 484 418 269 484 minecraft:magenta_concrete
fill 418 262 492 418 269 492 minecraft:magenta_concrete
fill 418 262 500 418 269 500 minecraft:magenta_concrete
fill 376 263 499 376 264 499 minecraft:magenta_concrete
fill 376 263 501 376 264 501 minecraft:magenta_concrete
fill 376 263 503 376 264 503 minecraft:magenta_concrete
fill 377 263 498 377 264 498 minecraft:black_concrete
fill 377 263 500 377 264 500 minecraft:black_concrete
fill 377 263 502 377 264 502 minecraft:black_concrete
fill 377 263 504 377 264 504 minecraft:black_concrete
fill 378 263 499 378 264 499 minecraft:black_concrete
fill 378 263 501 378 264 501 minecraft:black_concrete
fill 378 263 503 378 264 503 minecraft:black_concrete
schedule function dropper:buildpart/116_3 1t
