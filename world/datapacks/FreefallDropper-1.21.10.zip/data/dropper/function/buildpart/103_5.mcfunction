fill 349 286 451 351 286 451 minecraft:red_wool
setblock 350 286 457 minecraft:red_concrete
fill 352 286 450 355 286 450 minecraft:red_wool
fill 352 286 451 355 286 451 minecraft:black_wool
setblock 354 286 417 minecraft:red_concrete
fill 354 286 423 360 286 423 minecraft:black_wool
fill 354 286 424 355 286 424 minecraft:red_wool
setblock 355 286 452 minecraft:jack_o_lantern
setblock 355 286 454 minecraft:jack_o_lantern
fill 355 286 455 355 299 455 minecraft:red_concrete
setblock 355 286 456 minecraft:jack_o_lantern
fill 355 286 457 355 300 457 minecraft:red_concrete
fill 356 286 424 361 286 424 minecraft:black_wool
fill 356 286 425 357 286 425 minecraft:red_wool
fill 356 286 449 357 286 449 minecraft:red_wool
fill 356 286 450 361 286 450 minecraft:black_wool
setblock 356 286 451 minecraft:jack_o_lantern
setblock 356 286 452 minecraft:black_wool
setblock 356 286 453 minecraft:jack_o_lantern
fill 356 286 454 356 299 454 minecraft:red_concrete
setblock 356 286 455 minecraft:jack_o_lantern
fill 356 286 456 356 299 456 minecraft:red_concrete
setblock 356 286 457 minecraft:jack_o_lantern
setblock 357 286 451 minecraft:black_wool
setblock 357 286 452 minecraft:jack_o_lantern
fill 357 286 453 357 299 453 minecraft:red_concrete
setblock 357 286 454 minecraft:jack_o_lantern
fill 357 286 455 357 299 455 minecraft:red_concrete
setblock 357 286 456 minecraft:jack_o_lantern
fill 357 286 457 357 300 457 minecraft:red_concrete
fill 358 286 425 362 286 425 minecraft:black_wool
setblock 358 286 426 minecraft:red_wool
setblock 358 286 448 minecraft:red_wool
fill 358 286 449 362 286 449 minecraft:black_wool
setblock 358 286 451 minecraft:jack_o_lantern
setblock 358 286 452 minecraft:black_wool
setblock 358 286 453 minecraft:jack_o_lantern
fill 358 286 454 358 299 454 minecraft:red_concrete
setblock 358 286 455 minecraft:jack_o_lantern
fill 358 286 456 358 299 456 minecraft:red_concrete
setblock 358 286 457 minecraft:jack_o_lantern
fill 359 286 426 363 286 426 minecraft:black_wool
setblock 359 286 427 minecraft:red_wool
setblock 359 286 447 minecraft:red_wool
fill 359 286 448 363 286 448 minecraft:black_wool
setblock 359 286 451 minecraft:black_wool
setblock 359 286 452 minecraft:jack_o_lantern
fill 359 286 453 359 299 453 minecraft:red_concrete
setblock 359 286 454 minecraft:jack_o_lantern
fill 359 286 455 359 299 455 minecraft:red_concrete
setblock 359 286 456 minecraft:jack_o_lantern
fill 359 286 457 359 300 457 minecraft:red_concrete
fill 360 286 427 364 286 427 minecraft:black_wool
setblock 360 286 428 minecraft:red_wool
setblock 360 286 446 minecraft:red_wool
fill 360 286 447 364 286 447 minecraft:black_wool
setblock 360 286 451 minecraft:jack_o_lantern
fill 360 286 452 360 299 452 minecraft:red_concrete
setblock 360 286 453 minecraft:jack_o_lantern
fill 360 286 454 360 299 454 minecraft:red_concrete
setblock 360 286 455 minecraft:jack_o_lantern
fill 360 286 456 360 299 456 minecraft:red_concrete
setblock 360 286 457 minecraft:jack_o_lantern
setblock 361 286 417 minecraft:red_concrete
fill 361 286 428 364 286 428 minecraft:black_wool
setblock 361 286 429 minecraft:red_wool
setblock 361 286 445 minecraft:red_wool
fill 361 286 446 364 286 446 minecraft:black_wool
fill 361 286 451 361 299 451 minecraft:red_concrete
setblock 361 286 452 minecraft:jack_o_lantern
fill 361 286 453 361 299 453 minecraft:red_concrete
setblock 361 286 454 minecraft:jack_o_lantern
fill 361 286 455 361 299 455 minecraft:red_concrete
setblock 361 286 456 minecraft:jack_o_lantern
fill 361 286 457 361 300 457 minecraft:red_concrete
fill 362 286 429 365 286 429 minecraft:black_wool
fill 362 286 430 362 286 431 minecraft:red_wool
fill 362 286 443 362 286 444 minecraft:red_wool
fill 362 286 445 365 286 445 minecraft:black_wool
setblock 362 286 451 minecraft:jack_o_lantern
fill 362 286 452 362 299 452 minecraft:red_concrete
setblock 362 286 453 minecraft:jack_o_lantern
fill 362 286 454 362 299 454 minecraft:red_concrete
setblock 362 286 455 minecraft:jack_o_lantern
fill 362 286 456 362 299 456 minecraft:red_concrete
setblock 362 286 457 minecraft:jack_o_lantern
fill 363 286 430 365 286 431 minecraft:black_wool
fill 363 286 432 363 286 433 minecraft:red_wool
fill 363 286 440 363 286 442 minecraft:red_wool
fill 363 286 443 365 286 444 minecraft:black_wool
fill 363 286 451 363 299 451 minecraft:red_concrete
setblock 363 286 452 minecraft:jack_o_lantern
fill 363 286 453 363 299 453 minecraft:red_concrete
setblock 363 286 454 minecraft:jack_o_lantern
fill 363 286 455 363 299 455 minecraft:red_concrete
setblock 363 286 456 minecraft:jack_o_lantern
fill 363 286 457 363 300 457 minecraft:red_concrete
fill 364 286 432 366 286 433 minecraft:black_wool
fill 364 286 434 364 286 439 minecraft:red_wool
fill 364 286 440 366 286 442 minecraft:black_wool
setblock 364 286 451 minecraft:jack_o_lantern
fill 364 286 452 364 299 452 minecraft:red_concrete
setblock 364 286 453 minecraft:jack_o_lantern
fill 364 286 454 364 299 454 minecraft:red_concrete
setblock 364 286 455 minecraft:jack_o_lantern
fill 364 286 456 364 299 456 minecraft:red_concrete
setblock 364 286 457 minecraft:jack_o_lantern
fill 365 286 434 366 286 439 minecraft:black_wool
fill 365 286 451 365 299 451 minecraft:red_concrete
setblock 365 286 452 minecraft:jack_o_lantern
fill 365 286 453 365 299 453 minecraft:red_concrete
setblock 365 286 454 minecraft:jack_o_lantern
fill 365 286 455 365 299 455 minecraft:red_concrete
setblock 365 286 456 minecraft:jack_o_lantern
fill 365 286 457 365 300 457 minecraft:red_concrete
setblock 366 286 431 minecraft:black_wool
setblock 366 286 443 minecraft:black_wool
setblock 366 286 451 minecraft:jack_o_lantern
fill 366 286 452 366 299 452 minecraft:red_concrete
setblock 366 286 453 minecraft:jack_o_lantern
fill 366 286 454 366 299 454 minecraft:red_concrete
setblock 366 286 455 minecraft:jack_o_lantern
fill 366 286 456 366 299 456 minecraft:red_concrete
setblock 366 286 457 minecraft:jack_o_lantern
fill 367 286 435 367 286 439 minecraft:black_wool
fill 367 286 451 367 299 451 minecraft:red_concrete
setblock 367 286 452 minecraft:jack_o_lantern
fill 367 286 453 367 299 453 minecraft:red_concrete
setblock 367 286 454 minecraft:jack_o_lantern
fill 367 286 455 367 299 455 minecraft:red_concrete
setblock 367 286 456 minecraft:jack_o_lantern
fill 367 286 457 367 300 457 minecraft:red_concrete
setblock 368 286 417 minecraft:red_concrete
setblock 370 286 422 minecraft:red_concrete
setblock 370 286 429 minecraft:red_concrete
setblock 370 286 436 minecraft:red_concrete
setblock 370 286 443 minecraft:red_concrete
setblock 370 286 450 minecraft:red_concrete
fill 340 287 447 340 288 448 minecraft:red_wool
fill 341 287 448 341 288 448 minecraft:red_wool
fill 355 287 451 355 288 454 minecraft:red_concrete
fill 355 287 456 355 288 456 minecraft:red_concrete
fill 356 287 451 356 288 453 minecraft:red_concrete
fill 356 287 455 356 288 455 minecraft:red_concrete
fill 356 287 457 356 288 457 minecraft:red_concrete
fill 357 287 451 359 288 452 minecraft:red_concrete
fill 357 287 454 357 288 454 minecraft:red_concrete
fill 357 287 456 357 288 456 minecraft:red_concrete
fill 358 287 453 358 288 453 minecraft:red_concrete
fill 358 287 455 358 288 455 minecraft:red_concrete
fill 358 287 457 358 288 457 minecraft:red_concrete
fill 359 287 454 359 288 454 minecraft:red_concrete
fill 359 287 456 359 288 456 minecraft:red_concrete
fill 360 287 451 360 288 451 minecraft:red_concrete
fill 360 287 453 360 288 453 minecraft:red_concrete
fill 360 287 455 360 288 455 minecraft:red_concrete
fill 360 287 457 360 288 457 minecraft:red_concrete
fill 361 287 452 361 288 452 minecraft:red_concrete
fill 361 287 454 361 288 454 minecraft:red_concrete
fill 361 287 456 361 288 456 minecraft:red_concrete
fill 362 287 451 362 288 451 minecraft:red_concrete
fill 362 287 453 362 288 453 minecraft:red_concrete
fill 362 287 455 362 288 455 minecraft:red_concrete
fill 362 287 457 362 288 457 minecraft:red_concrete
fill 363 287 452 363 288 452 minecraft:red_concrete
fill 363 287 454 363 288 454 minecraft:red_concrete
fill 363 287 456 363 288 456 minecraft:red_concrete
fill 364 287 451 364 288 451 minecraft:red_concrete
fill 364 287 453 364 288 453 minecraft:red_concrete
fill 364 287 455 364 288 455 minecraft:red_concrete
fill 364 287 457 364 288 457 minecraft:red_concrete
fill 365 287 452 365 288 452 minecraft:red_concrete
fill 365 287 454 365 288 454 minecraft:red_concrete
fill 365 287 456 365 288 456 minecraft:red_concrete
fill 366 287 451 366 288 451 minecraft:red_concrete
fill 366 287 453 366 288 453 minecraft:red_concrete
fill 366 287 455 366 288 455 minecraft:red_concrete
fill 366 287 457 366 288 457 minecraft:red_concrete
fill 367 287 452 367 288 452 minecraft:red_concrete
fill 367 287 454 367 288 454 minecraft:red_concrete
fill 367 287 456 367 288 456 minecraft:red_concrete
setblock 330 288 423 minecraft:red_concrete
setblock 330 288 430 minecraft:red_concrete
setblock 330 288 437 minecraft:red_concrete
setblock 330 288 444 minecraft:red_concrete
setblock 330 288 451 minecraft:red_concrete
setblock 331 288 417 minecraft:red_concrete
setblock 331 288 457 minecraft:red_concrete
setblock 332 288 419 minecraft:light[level=12]
setblock 332 288 427 minecraft:light[level=12]
setblock 332 288 435 minecraft:light[level=12]
setblock 332 288 443 minecraft:light[level=12]
setblock 332 288 451 minecraft:light[level=12]
setblock 338 288 417 minecraft:red_concrete
setblock 338 288 457 minecraft:red_concrete
setblock 340 288 419 minecraft:light[level=12]
setblock 340 288 427 minecraft:light[level=12]
setblock 340 288 435 minecraft:light[level=12]
setblock 340 288 443 minecraft:light[level=12]
setblock 340 288 451 minecraft:light[level=12]
setblock 345 288 417 minecraft:red_concrete
setblock 345 288 457 minecraft:red_concrete
setblock 348 288 419 minecraft:light[level=12]
setblock 348 288 427 minecraft:light[level=12]
setblock 348 288 435 minecraft:light[level=12]
setblock 348 288 443 minecraft:light[level=12]
setblock 348 288 451 minecraft:light[level=12]
setblock 352 288 417 minecraft:red_concrete
setblock 352 288 457 minecraft:red_concrete
setblock 356 288 419 minecraft:light[level=12]
setblock 356 288 427 minecraft:light[level=12]
setblock 356 288 435 minecraft:light[level=12]
setblock 356 288 443 minecraft:light[level=12]
setblock 359 288 417 minecraft:red_concrete
setblock 364 288 419 minecraft:light[level=12]
setblock 364 288 427 minecraft:light[level=12]
setblock 364 288 435 minecraft:light[level=12]
setblock 364 288 443 minecraft:light[level=12]
setblock 366 288 417 minecraft:red_concrete
setblock 370 288 420 minecraft:red_concrete
setblock 370 288 427 minecraft:red_concrete
setblock 370 288 434 minecraft:red_concrete
setblock 370 288 441 minecraft:red_concrete
setblock 370 288 448 minecraft:red_concrete
setblock 370 288 455 minecraft:red_concrete
fill 330 289 417 330 290 417 minecraft:red_concrete
fill 330 289 424 330 290 424 minecraft:red_concrete
fill 330 289 431 330 290 431 minecraft:red_concrete
fill 330 289 438 330 290 438 minecraft:red_concrete
fill 330 289 445 330 290 445 minecraft:red_concrete
fill 330 289 452 330 290 452 minecraft:red_concrete
fill 332 289 457 332 290 457 minecraft:red_concrete
fill 337 289 417 337 290 417 minecraft:red_concrete
fill 339 289 457 339 290 457 minecraft:red_concrete
fill 344 289 417 344 290 417 minecraft:red_concrete
fill 346 289 457 346 290 457 minecraft:red_concrete
fill 351 289 417 351 290 417 minecraft:red_concrete
fill 353 289 457 353 290 457 minecraft:red_concrete
fill 355 289 451 355 299 451 minecraft:red_concrete
setblock 355 289 452 minecraft:jack_o_lantern
fill 355 289 453 355 299 453 minecraft:red_concrete
setblock 355 289 454 minecraft:jack_o_lantern
setblock 355 289 456 minecraft:jack_o_lantern
setblock 356 289 451 minecraft:jack_o_lantern
fill 356 289 452 356 299 452 minecraft:red_concrete
setblock 356 289 453 minecraft:jack_o_lantern
setblock 356 289 455 minecraft:jack_o_lantern
setblock 356 289 457 minecraft:jack_o_lantern
fill 357 289 451 357 299 451 minecraft:red_concrete
setblock 357 289 452 minecraft:jack_o_lantern
setblock 357 289 454 minecraft:jack_o_lantern
setblock 357 289 456 minecraft:jack_o_lantern
fill 358 289 417 358 290 417 minecraft:red_concrete
setblock 358 289 451 minecraft:jack_o_lantern
fill 358 289 452 358 299 452 minecraft:red_concrete
setblock 358 289 453 minecraft:jack_o_lantern
setblock 358 289 455 minecraft:jack_o_lantern
setblock 358 289 457 minecraft:jack_o_lantern
fill 359 289 451 359 299 451 minecraft:red_concrete
setblock 359 289 452 minecraft:jack_o_lantern
setblock 359 289 454 minecraft:jack_o_lantern
setblock 359 289 456 minecraft:jack_o_lantern
setblock 360 289 451 minecraft:jack_o_lantern
setblock 360 289 453 minecraft:jack_o_lantern
setblock 360 289 455 minecraft:jack_o_lantern
setblock 360 289 457 minecraft:jack_o_lantern
setblock 361 289 452 minecraft:jack_o_lantern
setblock 361 289 454 minecraft:jack_o_lantern
setblock 361 289 456 minecraft:jack_o_lantern
setblock 362 289 451 minecraft:jack_o_lantern
setblock 362 289 453 minecraft:jack_o_lantern
setblock 362 289 455 minecraft:jack_o_lantern
setblock 362 289 457 minecraft:jack_o_lantern
setblock 363 289 452 minecraft:jack_o_lantern
setblock 363 289 454 minecraft:jack_o_lantern
setblock 363 289 456 minecraft:jack_o_lantern
setblock 364 289 451 minecraft:jack_o_lantern
setblock 364 289 453 minecraft:jack_o_lantern
setblock 364 289 455 minecraft:jack_o_lantern
setblock 364 289 457 minecraft:jack_o_lantern
fill 365 289 417 365 290 417 minecraft:red_concrete
setblock 365 289 452 minecraft:jack_o_lantern
setblock 365 289 454 minecraft:jack_o_lantern
setblock 365 289 456 minecraft:jack_o_lantern
setblock 366 289 451 minecraft:jack_o_lantern
setblock 366 289 453 minecraft:jack_o_lantern
setblock 366 289 455 minecraft:jack_o_lantern
setblock 366 289 457 minecraft:jack_o_lantern
setblock 367 289 452 minecraft:jack_o_lantern
setblock 367 289 454 minecraft:jack_o_lantern
setblock 367 289 456 minecraft:jack_o_lantern
fill 370 289 419 370 290 419 minecraft:red_concrete
fill 370 289 426 370 290 426 minecraft:red_concrete
fill 370 289 433 370 290 433 minecraft:red_concrete
fill 370 289 440 370 290 440 minecraft:red_concrete
fill 370 289 447 370 290 447 minecraft:red_concrete
fill 370 289 454 370 290 454 minecraft:red_concrete
fill 330 290 418 330 290 421 minecraft:red_concrete
setblock 330 290 423 minecraft:red_concrete
fill 330 290 425 330 290 428 minecraft:red_concrete
setblock 330 290 430 minecraft:red_concrete
fill 330 290 432 330 290 435 minecraft:red_concrete
setblock 330 290 437 minecraft:red_concrete
fill 330 290 439 330 290 442 minecraft:red_concrete
setblock 330 290 444 minecraft:red_concrete
fill 330 290 446 330 290 449 minecraft:red_concrete
setblock 330 290 451 minecraft:red_concrete
fill 330 290 453 330 290 456 minecraft:red_concrete
setblock 331 290 417 minecraft:red_concrete
setblock 331 290 457 minecraft:red_concrete
fill 333 290 417 336 290 417 minecraft:red_concrete
fill 333 290 457 336 290 457 minecraft:red_concrete
setblock 338 290 417 minecraft:red_concrete
setblock 338 290 457 minecraft:red_concrete
fill 340 290 417 343 290 417 minecraft:red_concrete
fill 340 290 457 343 290 457 minecraft:red_concrete
setblock 345 290 417 minecraft:red_concrete
setblock 345 290 457 minecraft:red_concrete
fill 347 290 417 350 290 417 minecraft:red_concrete
fill 347 290 457 350 290 457 minecraft:red_concrete
setblock 352 290 417 minecraft:red_concrete
setblock 352 290 457 minecraft:red_concrete
fill 354 290 417 357 290 417 minecraft:red_concrete
setblock 354 290 457 minecraft:red_concrete
fill 355 290 452 355 291 452 minecraft:red_concrete
fill 355 290 454 355 291 454 minecraft:red_concrete
fill 355 290 456 355 291 456 minecraft:red_concrete
fill 356 290 451 356 291 451 minecraft:red_concrete
fill 356 290 453 356 291 453 minecraft:red_concrete
fill 356 290 455 356 291 455 minecraft:red_concrete
fill 356 290 457 356 291 457 minecraft:red_concrete
fill 357 290 452 357 291 452 minecraft:red_concrete
fill 357 290 454 357 291 454 minecraft:red_concrete
fill 357 290 456 357 291 456 minecraft:red_concrete
fill 358 290 451 358 291 451 minecraft:red_concrete
fill 358 290 453 358 291 453 minecraft:red_concrete
fill 358 290 455 358 291 455 minecraft:red_concrete
fill 358 290 457 358 291 457 minecraft:red_concrete
setblock 359 290 417 minecraft:red_concrete
fill 359 290 452 359 291 452 minecraft:red_concrete
fill 359 290 454 359 291 454 minecraft:red_concrete
fill 359 290 456 359 291 456 minecraft:red_concrete
fill 360 290 451 360 291 451 minecraft:red_concrete
fill 360 290 453 360 291 453 minecraft:red_concrete
fill 360 290 455 360 291 455 minecraft:red_concrete
fill 360 290 457 360 291 457 minecraft:red_concrete
fill 361 290 417 364 290 417 minecraft:red_concrete
fill 361 290 452 361 291 452 minecraft:red_concrete
fill 361 290 454 361 291 454 minecraft:red_concrete
fill 361 290 456 361 291 456 minecraft:red_concrete
fill 362 290 451 362 291 451 minecraft:red_concrete
fill 362 290 453 362 291 453 minecraft:red_concrete
fill 362 290 455 362 291 455 minecraft:red_concrete
fill 362 290 457 362 291 457 minecraft:red_concrete
fill 363 290 452 363 291 452 minecraft:red_concrete
fill 363 290 454 363 291 454 minecraft:red_concrete
fill 363 290 456 363 291 456 minecraft:red_concrete
fill 364 290 451 364 291 451 minecraft:red_concrete
fill 364 290 453 364 291 453 minecraft:red_concrete
fill 364 290 455 364 291 455 minecraft:red_concrete
fill 364 290 457 364 291 457 minecraft:red_concrete
fill 365 290 452 365 291 452 minecraft:red_concrete
fill 365 290 454 365 291 454 minecraft:red_concrete
fill 365 290 456 365 291 456 minecraft:red_concrete
setblock 366 290 417 minecraft:red_concrete
fill 366 290 451 366 291 451 minecraft:red_concrete
fill 366 290 453 366 291 453 minecraft:red_concrete
fill 366 290 455 366 291 455 minecraft:red_concrete
fill 366 290 457 366 291 457 minecraft:red_concrete
fill 367 290 452 367 291 452 minecraft:red_concrete
fill 367 290 454 367 291 454 minecraft:red_concrete
fill 367 290 456 367 291 456 minecraft:red_concrete
fill 368 290 417 370 290 417 minecraft:red_concrete
fill 368 290 457 370 290 457 minecraft:red_concrete
setblock 370 290 418 minecraft:red_concrete
setblock 370 290 420 minecraft:red_concrete
fill 370 290 422 370 290 425 minecraft:red_concrete
setblock 370 290 427 minecraft:red_concrete
fill 370 290 429 370 290 432 minecraft:red_concrete
setblock 370 290 434 minecraft:red_concrete
fill 370 290 436 370 290 439 minecraft:red_concrete
setblock 370 290 441 minecraft:red_concrete
fill 370 290 443 370 290 446 minecraft:red_concrete
setblock 370 290 448 minecraft:red_concrete
fill 370 290 450 370 290 453 minecraft:red_concrete
setblock 370 290 455 minecraft:red_concrete
setblock 330 291 419 minecraft:red_concrete
setblock 330 291 426 minecraft:red_concrete
setblock 330 291 433 minecraft:red_concrete
setblock 330 291 440 minecraft:red_concrete
setblock 330 291 447 minecraft:red_concrete
setblock 330 291 454 minecraft:red_concrete
setblock 334 291 457 minecraft:red_concrete
setblock 335 291 417 minecraft:red_concrete
setblock 341 291 457 minecraft:red_concrete
setblock 342 291 417 minecraft:red_concrete
setblock 348 291 457 minecraft:red_concrete
setblock 349 291 417 minecraft:red_concrete
setblock 356 291 417 minecraft:red_concrete
setblock 363 291 417 minecraft:red_concrete
setblock 369 291 457 minecraft:red_concrete
setblock 370 291 417 minecraft:red_concrete
setblock 370 291 424 minecraft:red_concrete
setblock 370 291 431 minecraft:red_concrete
setblock 370 291 438 minecraft:red_concrete
setblock 370 291 445 minecraft:red_concrete
setblock 370 291 452 minecraft:red_concrete
setblock 330 292 420 minecraft:red_concrete
setblock 330 292 427 minecraft:red_concrete
setblock 330 292 434 minecraft:red_concrete
setblock 330 292 441 minecraft:red_concrete
setblock 330 292 448 minecraft:red_concrete
setblock 330 292 455 minecraft:red_concrete
setblock 334 292 417 minecraft:red_concrete
setblock 335 292 457 minecraft:red_concrete
setblock 341 292 417 minecraft:red_concrete
setblock 342 292 457 minecraft:red_concrete
setblock 348 292 417 minecraft:red_concrete
setblock 349 292 457 minecraft:red_concrete
setblock 355 292 417 minecraft:red_concrete
setblock 355 292 452 minecraft:jack_o_lantern
setblock 355 292 454 minecraft:jack_o_lantern
setblock 355 292 456 minecraft:jack_o_lantern
setblock 356 292 451 minecraft:jack_o_lantern
setblock 356 292 453 minecraft:jack_o_lantern
setblock 356 292 455 minecraft:jack_o_lantern
setblock 356 292 457 minecraft:jack_o_lantern
setblock 357 292 452 minecraft:jack_o_lantern
setblock 357 292 454 minecraft:jack_o_lantern
setblock 357 292 456 minecraft:jack_o_lantern
setblock 358 292 451 minecraft:jack_o_lantern
setblock 358 292 453 minecraft:jack_o_lantern
setblock 358 292 455 minecraft:jack_o_lantern
setblock 358 292 457 minecraft:jack_o_lantern
setblock 359 292 452 minecraft:jack_o_lantern
setblock 359 292 454 minecraft:jack_o_lantern
setblock 359 292 456 minecraft:jack_o_lantern
setblock 360 292 451 minecraft:jack_o_lantern
setblock 360 292 453 minecraft:jack_o_lantern
setblock 360 292 455 minecraft:jack_o_lantern
setblock 360 292 457 minecraft:jack_o_lantern
setblock 361 292 452 minecraft:jack_o_lantern
setblock 361 292 454 minecraft:jack_o_lantern
setblock 361 292 456 minecraft:jack_o_lantern
setblock 362 292 417 minecraft:red_concrete
setblock 362 292 451 minecraft:jack_o_lantern
setblock 362 292 453 minecraft:jack_o_lantern
setblock 362 292 455 minecraft:jack_o_lantern
setblock 362 292 457 minecraft:jack_o_lantern
setblock 363 292 452 minecraft:jack_o_lantern
setblock 363 292 454 minecraft:jack_o_lantern
setblock 363 292 456 minecraft:jack_o_lantern
setblock 364 292 451 minecraft:jack_o_lantern
setblock 364 292 453 minecraft:jack_o_lantern
setblock 364 292 455 minecraft:jack_o_lantern
setblock 364 292 457 minecraft:jack_o_lantern
setblock 365 292 452 minecraft:jack_o_lantern
setblock 365 292 454 minecraft:jack_o_lantern
setblock 365 292 456 minecraft:jack_o_lantern
setblock 366 292 451 minecraft:jack_o_lantern
setblock 366 292 453 minecraft:jack_o_lantern
setblock 366 292 455 minecraft:jack_o_lantern
setblock 366 292 457 minecraft:jack_o_lantern
setblock 367 292 452 minecraft:jack_o_lantern
setblock 367 292 454 minecraft:jack_o_lantern
setblock 367 292 456 minecraft:jack_o_lantern
setblock 369 292 417 minecraft:red_concrete
setblock 370 292 423 minecraft:red_concrete
setblock 370 292 430 minecraft:red_concrete
setblock 370 292 437 minecraft:red_concrete
setblock 370 292 444 minecraft:red_concrete
setblock 370 292 451 minecraft:red_concrete
setblock 370 292 457 minecraft:red_concrete
setblock 330 293 421 minecraft:red_concrete
setblock 330 293 428 minecraft:red_concrete
setblock 330 293 435 minecraft:red_concrete
setblock 330 293 442 minecraft:red_concrete
setblock 330 293 449 minecraft:red_concrete
setblock 330 293 456 minecraft:red_concrete
setblock 333 293 417 minecraft:red_concrete
setblock 336 293 457 minecraft:red_concrete
setblock 340 293 417 minecraft:red_concrete
setblock 343 293 457 minecraft:red_concrete
setblock 347 293 417 minecraft:red_concrete
setblock 350 293 457 minecraft:red_concrete
setblock 354 293 417 minecraft:red_concrete
fill 355 293 452 355 294 452 minecraft:red_concrete
fill 355 293 454 355 294 454 minecraft:red_concrete
fill 355 293 456 355 294 456 minecraft:red_concrete
fill 356 293 451 356 294 451 minecraft:red_concrete
fill 356 293 453 356 294 453 minecraft:red_concrete
fill 356 293 455 356 294 455 minecraft:red_concrete
fill 356 293 457 356 294 457 minecraft:red_concrete
fill 357 293 452 357 294 452 minecraft:red_concrete
fill 357 293 454 357 294 454 minecraft:red_concrete
fill 357 293 456 357 294 456 minecraft:red_concrete
fill 358 293 451 358 294 451 minecraft:red_concrete
fill 358 293 453 358 294 453 minecraft:red_concrete
fill 358 293 455 358 294 455 minecraft:red_concrete
fill 358 293 457 358 294 457 minecraft:red_concrete
fill 359 293 452 359 294 452 minecraft:red_concrete
fill 359 293 454 359 294 454 minecraft:red_concrete
fill 359 293 456 359 294 456 minecraft:red_concrete
fill 360 293 451 360 294 451 minecraft:red_concrete
fill 360 293 453 360 294 453 minecraft:red_concrete
fill 360 293 455 360 294 455 minecraft:red_concrete
fill 360 293 457 360 294 457 minecraft:red_concrete
setblock 361 293 417 minecraft:red_concrete
fill 361 293 452 361 294 452 minecraft:red_concrete
fill 361 293 454 361 294 454 minecraft:red_concrete
fill 361 293 456 361 294 456 minecraft:red_concrete
fill 362 293 451 362 294 451 minecraft:red_concrete
fill 362 293 453 362 294 453 minecraft:red_concrete
fill 362 293 455 362 294 455 minecraft:red_concrete
fill 362 293 457 362 294 457 minecraft:red_concrete
fill 363 293 452 363 294 452 minecraft:red_concrete
fill 363 293 454 363 294 454 minecraft:red_concrete
fill 363 293 456 363 294 456 minecraft:red_concrete
fill 364 293 451 364 294 451 minecraft:red_concrete
fill 364 293 453 364 294 453 minecraft:red_concrete
fill 364 293 455 364 294 455 minecraft:red_concrete
fill 364 293 457 364 294 457 minecraft:red_concrete
fill 365 293 452 365 294 452 minecraft:red_concrete
fill 365 293 454 365 294 454 minecraft:red_concrete
fill 365 293 456 365 294 456 minecraft:red_concrete
fill 366 293 451 366 294 451 minecraft:red_concrete
fill 366 293 453 366 294 453 minecraft:red_concrete
fill 366 293 455 366 294 455 minecraft:red_concrete
fill 366 293 457 366 294 457 minecraft:red_concrete
fill 367 293 452 367 294 452 minecraft:red_concrete
fill 367 293 454 367 294 454 minecraft:red_concrete
fill 367 293 456 367 294 456 minecraft:red_concrete
setblock 368 293 417 minecraft:red_concrete
setblock 370 293 422 minecraft:red_concrete
setblock 370 293 429 minecraft:red_concrete
setblock 370 293 436 minecraft:red_concrete
setblock 370 293 443 minecraft:red_concrete
setblock 370 293 450 minecraft:red_concrete
setblock 330 295 423 minecraft:red_concrete
setblock 330 295 430 minecraft:red_concrete
setblock 330 295 437 minecraft:red_concrete
setblock 330 295 444 minecraft:red_concrete
setblock 330 295 451 minecraft:red_concrete
setblock 331 295 417 minecraft:red_concrete
setblock 331 295 457 minecraft:red_concrete
setblock 338 295 417 minecraft:red_concrete
setblock 338 295 457 minecraft:red_concrete
setblock 345 295 417 minecraft:red_concrete
setblock 345 295 457 minecraft:red_concrete
setblock 352 295 417 minecraft:red_concrete
setblock 352 295 457 minecraft:red_concrete
setblock 355 295 452 minecraft:jack_o_lantern
setblock 355 295 454 minecraft:jack_o_lantern
setblock 355 295 456 minecraft:jack_o_lantern
setblock 356 295 451 minecraft:jack_o_lantern
setblock 356 295 453 minecraft:jack_o_lantern
setblock 356 295 455 minecraft:jack_o_lantern
setblock 356 295 457 minecraft:jack_o_lantern
setblock 357 295 452 minecraft:jack_o_lantern
setblock 357 295 454 minecraft:jack_o_lantern
setblock 357 295 456 minecraft:jack_o_lantern
setblock 358 295 451 minecraft:jack_o_lantern
setblock 358 295 453 minecraft:jack_o_lantern
setblock 358 295 455 minecraft:jack_o_lantern
setblock 358 295 457 minecraft:jack_o_lantern
setblock 359 295 417 minecraft:red_concrete
setblock 359 295 452 minecraft:jack_o_lantern
setblock 359 295 454 minecraft:jack_o_lantern
setblock 359 295 456 minecraft:jack_o_lantern
setblock 360 295 451 minecraft:jack_o_lantern
setblock 360 295 453 minecraft:jack_o_lantern
setblock 360 295 455 minecraft:jack_o_lantern
setblock 360 295 457 minecraft:jack_o_lantern
setblock 361 295 452 minecraft:jack_o_lantern
setblock 361 295 454 minecraft:jack_o_lantern
setblock 361 295 456 minecraft:jack_o_lantern
setblock 362 295 451 minecraft:jack_o_lantern
setblock 362 295 453 minecraft:jack_o_lantern
setblock 362 295 455 minecraft:jack_o_lantern
setblock 362 295 457 minecraft:jack_o_lantern
setblock 363 295 452 minecraft:jack_o_lantern
setblock 363 295 454 minecraft:jack_o_lantern
setblock 363 295 456 minecraft:jack_o_lantern
setblock 364 295 451 minecraft:jack_o_lantern
setblock 364 295 453 minecraft:jack_o_lantern
setblock 364 295 455 minecraft:jack_o_lantern
setblock 364 295 457 minecraft:jack_o_lantern
setblock 365 295 452 minecraft:jack_o_lantern
setblock 365 295 454 minecraft:jack_o_lantern
setblock 365 295 456 minecraft:jack_o_lantern
setblock 366 295 417 minecraft:red_concrete
setblock 366 295 451 minecraft:jack_o_lantern
setblock 366 295 453 minecraft:jack_o_lantern
setblock 366 295 455 minecraft:jack_o_lantern
setblock 366 295 457 minecraft:jack_o_lantern
setblock 367 295 452 minecraft:jack_o_lantern
setblock 367 295 454 minecraft:jack_o_lantern
setblock 367 295 456 minecraft:jack_o_lantern
setblock 370 295 420 minecraft:red_concrete
setblock 370 295 427 minecraft:red_concrete
setblock 370 295 434 minecraft:red_concrete
setblock 370 295 441 minecraft:red_concrete
setblock 370 295 448 minecraft:red_concrete
setblock 370 295 455 minecraft:red_concrete
setblock 330 296 417 minecraft:red_concrete
setblock 330 296 424 minecraft:red_concrete
setblock 330 296 431 minecraft:red_concrete
setblock 330 296 438 minecraft:red_concrete
setblock 330 296 445 minecraft:red_concrete
setblock 330 296 452 minecraft:red_concrete
setblock 332 296 419 minecraft:light[level=12]
setblock 332 296 427 minecraft:light[level=12]
setblock 332 296 435 minecraft:light[level=12]
setblock 332 296 443 minecraft:light[level=12]
setblock 332 296 451 minecraft:light[level=12]
setblock 332 296 457 minecraft:red_concrete
setblock 337 296 417 minecraft:red_concrete
setblock 339 296 457 minecraft:red_concrete
setblock 340 296 419 minecraft:light[level=12]
setblock 340 296 427 minecraft:light[level=12]
setblock 340 296 435 minecraft:light[level=12]
setblock 340 296 443 minecraft:light[level=12]
setblock 340 296 451 minecraft:light[level=12]
setblock 344 296 417 minecraft:red_concrete
setblock 346 296 457 minecraft:red_concrete
setblock 348 296 419 minecraft:light[level=12]
setblock 348 296 427 minecraft:light[level=12]
setblock 348 296 435 minecraft:light[level=12]
setblock 348 296 443 minecraft:light[level=12]
setblock 348 296 451 minecraft:light[level=12]
setblock 351 296 417 minecraft:red_concrete
setblock 353 296 457 minecraft:red_concrete
fill 355 296 452 355 297 452 minecraft:red_concrete
fill 355 296 454 355 297 454 minecraft:red_concrete
fill 355 296 456 355 297 456 minecraft:red_concrete
setblock 356 296 419 minecraft:light[level=12]
setblock 356 296 427 minecraft:light[level=12]
setblock 356 296 435 minecraft:light[level=12]
setblock 356 296 443 minecraft:light[level=12]
fill 356 296 451 356 297 451 minecraft:red_concrete
fill 356 296 453 356 297 453 minecraft:red_concrete
fill 356 296 455 356 297 455 minecraft:red_concrete
fill 356 296 457 356 297 457 minecraft:red_concrete
fill 357 296 452 357 297 452 minecraft:red_concrete
fill 357 296 454 357 297 454 minecraft:red_concrete
fill 357 296 456 357 297 456 minecraft:red_concrete
setblock 358 296 417 minecraft:red_concrete
fill 358 296 451 358 297 451 minecraft:red_concrete
fill 358 296 453 358 297 453 minecraft:red_concrete
fill 358 296 455 358 297 455 minecraft:red_concrete
fill 358 296 457 358 297 457 minecraft:red_concrete
fill 359 296 452 359 297 452 minecraft:red_concrete
fill 359 296 454 359 297 454 minecraft:red_concrete
fill 359 296 456 359 297 456 minecraft:red_concrete
fill 360 296 451 360 297 451 minecraft:red_concrete
fill 360 296 453 360 297 453 minecraft:red_concrete
fill 360 296 455 360 297 455 minecraft:red_concrete
fill 360 296 457 360 297 457 minecraft:red_concrete
fill 361 296 452 361 297 452 minecraft:red_concrete
fill 361 296 454 361 297 454 minecraft:red_concrete
fill 361 296 456 361 297 456 minecraft:red_concrete
fill 362 296 451 362 297 451 minecraft:red_concrete
fill 362 296 453 362 297 453 minecraft:red_concrete
fill 362 296 455 362 297 455 minecraft:red_concrete
fill 362 296 457 362 297 457 minecraft:red_concrete
fill 363 296 452 363 297 452 minecraft:red_concrete
fill 363 296 454 363 297 454 minecraft:red_concrete
fill 363 296 456 363 297 456 minecraft:red_concrete
setblock 364 296 419 minecraft:light[level=12]
setblock 364 296 427 minecraft:light[level=12]
setblock 364 296 435 minecraft:light[level=12]
setblock 364 296 443 minecraft:light[level=12]
fill 364 296 451 364 297 451 minecraft:red_concrete
fill 364 296 453 364 297 453 minecraft:red_concrete
fill 364 296 455 364 297 455 minecraft:red_concrete
fill 364 296 457 364 297 457 minecraft:red_concrete
setblock 365 296 417 minecraft:red_concrete
fill 365 296 452 365 297 452 minecraft:red_concrete
fill 365 296 454 365 297 454 minecraft:red_concrete
fill 365 296 456 365 297 456 minecraft:red_concrete
fill 366 296 451 366 297 451 minecraft:red_concrete
fill 366 296 453 366 297 453 minecraft:red_concrete
fill 366 296 455 366 297 455 minecraft:red_concrete
fill 366 296 457 366 297 457 minecraft:red_concrete
fill 367 296 452 367 297 452 minecraft:red_concrete
fill 367 296 454 367 297 454 minecraft:red_concrete
fill 367 296 456 367 297 456 minecraft:red_concrete
setblock 370 296 419 minecraft:red_concrete
setblock 370 296 426 minecraft:red_concrete
setblock 370 296 433 minecraft:red_concrete
setblock 370 296 440 minecraft:red_concrete
setblock 370 296 447 minecraft:red_concrete
setblock 370 296 454 minecraft:red_concrete
setblock 330 297 418 minecraft:red_concrete
setblock 330 297 425 minecraft:red_concrete
setblock 330 297 432 minecraft:red_concrete
setblock 330 297 439 minecraft:red_concrete
setblock 330 297 446 minecraft:red_concrete
setblock 330 297 453 minecraft:red_concrete
setblock 333 297 457 minecraft:red_concrete
setblock 336 297 417 minecraft:red_concrete
setblock 340 297 457 minecraft:red_concrete
setblock 343 297 417 minecraft:red_concrete
setblock 347 297 457 minecraft:red_concrete
setblock 350 297 417 minecraft:red_concrete
setblock 354 297 457 minecraft:red_concrete
setblock 357 297 417 minecraft:red_concrete
setblock 364 297 417 minecraft:red_concrete
setblock 368 297 457 minecraft:red_concrete
setblock 370 297 418 minecraft:red_concrete
setblock 370 297 425 minecraft:red_concrete
setblock 370 297 432 minecraft:red_concrete
setblock 370 297 439 minecraft:red_concrete
setblock 370 297 446 minecraft:red_concrete
setblock 370 297 453 minecraft:red_concrete
setblock 330 298 419 minecraft:red_concrete
setblock 330 298 426 minecraft:red_concrete
setblock 330 298 433 minecraft:red_concrete
setblock 330 298 440 minecraft:red_concrete
setblock 330 298 447 minecraft:red_concrete
setblock 330 298 454 minecraft:red_concrete
setblock 334 298 457 minecraft:red_concrete
setblock 335 298 417 minecraft:red_concrete
setblock 341 298 457 minecraft:red_concrete
setblock 342 298 417 minecraft:red_concrete
fill 344 298 443 344 299 445 minecraft:white_wool
fill 345 298 443 345 299 444 minecraft:white_wool
setblock 348 298 457 minecraft:red_concrete
setblock 349 298 417 minecraft:red_concrete
setblock 355 298 452 minecraft:jack_o_lantern
setblock 355 298 454 minecraft:jack_o_lantern
setblock 355 298 456 minecraft:jack_o_lantern
setblock 356 298 417 minecraft:red_concrete
setblock 356 298 451 minecraft:jack_o_lantern
setblock 356 298 453 minecraft:jack_o_lantern
setblock 356 298 455 minecraft:jack_o_lantern
setblock 356 298 457 minecraft:jack_o_lantern
setblock 357 298 452 minecraft:jack_o_lantern
setblock 357 298 454 minecraft:jack_o_lantern
setblock 357 298 456 minecraft:jack_o_lantern
setblock 358 298 451 minecraft:jack_o_lantern
setblock 358 298 453 minecraft:jack_o_lantern
setblock 358 298 455 minecraft:jack_o_lantern
setblock 358 298 457 minecraft:jack_o_lantern
setblock 359 298 452 minecraft:jack_o_lantern
setblock 359 298 454 minecraft:jack_o_lantern
setblock 359 298 456 minecraft:jack_o_lantern
setblock 360 298 451 minecraft:jack_o_lantern
setblock 360 298 453 minecraft:jack_o_lantern
setblock 360 298 455 minecraft:jack_o_lantern
setblock 360 298 457 minecraft:jack_o_lantern
setblock 361 298 452 minecraft:jack_o_lantern
setblock 361 298 454 minecraft:jack_o_lantern
setblock 361 298 456 minecraft:jack_o_lantern
setblock 362 298 451 minecraft:jack_o_lantern
setblock 362 298 453 minecraft:jack_o_lantern
setblock 362 298 455 minecraft:jack_o_lantern
setblock 362 298 457 minecraft:jack_o_lantern
setblock 363 298 417 minecraft:red_concrete
setblock 363 298 452 minecraft:jack_o_lantern
setblock 363 298 454 minecraft:jack_o_lantern
setblock 363 298 456 minecraft:jack_o_lantern
setblock 364 298 451 minecraft:jack_o_lantern
setblock 364 298 453 minecraft:jack_o_lantern
setblock 364 298 455 minecraft:jack_o_lantern
setblock 364 298 457 minecraft:jack_o_lantern
setblock 365 298 452 minecraft:jack_o_lantern
setblock 365 298 454 minecraft:jack_o_lantern
setblock 365 298 456 minecraft:jack_o_lantern
setblock 366 298 451 minecraft:jack_o_lantern
setblock 366 298 453 minecraft:jack_o_lantern
setblock 366 298 455 minecraft:jack_o_lantern
setblock 366 298 457 minecraft:jack_o_lantern
setblock 367 298 452 minecraft:jack_o_lantern
setblock 367 298 454 minecraft:jack_o_lantern
setblock 367 298 456 minecraft:jack_o_lantern
setblock 369 298 457 minecraft:red_concrete
setblock 370 298 417 minecraft:red_concrete
setblock 370 298 424 minecraft:red_concrete
setblock 370 298 431 minecraft:red_concrete
setblock 370 298 438 minecraft:red_concrete
setblock 370 298 445 minecraft:red_concrete
setblock 370 298 452 minecraft:red_concrete
fill 330 299 420 330 300 420 minecraft:red_concrete
fill 330 299 427 330 300 427 minecraft:red_concrete
fill 330 299 434 330 300 434 minecraft:red_concrete
fill 330 299 438 336 299 438 minecraft:black_concrete
fill 330 299 441 330 300 441 minecraft:red_concrete
fill 330 299 448 330 300 448 minecraft:red_concrete
fill 330 299 455 330 300 455 minecraft:red_concrete
fill 332 299 436 336 300 437 minecraft:black_concrete
fill 332 299 439 336 300 440 minecraft:black_concrete
fill 334 299 417 334 300 417 minecraft:red_concrete
fill 335 299 457 335 300 457 minecraft:red_concrete
fill 341 299 417 341 300 417 minecraft:red_concrete
fill 342 299 457 342 300 457 minecraft:red_concrete
fill 348 299 417 348 300 417 minecraft:red_concrete
fill 349 299 457 349 300 457 minecraft:red_concrete
fill 355 299 417 355 300 417 minecraft:red_concrete
setblock 355 299 452 minecraft:red_concrete
setblock 355 299 454 minecraft:red_concrete
setblock 355 299 456 minecraft:red_concrete
setblock 356 299 451 minecraft:red_concrete
setblock 356 299 453 minecraft:red_concrete
setblock 356 299 455 minecraft:red_concrete
fill 356 299 457 356 300 457 minecraft:red_concrete
setblock 357 299 452 minecraft:red_concrete
setblock 357 299 454 minecraft:red_concrete
setblock 357 299 456 minecraft:red_concrete
setblock 358 299 451 minecraft:red_concrete
setblock 358 299 453 minecraft:red_concrete
setblock 358 299 455 minecraft:red_concrete
fill 358 299 457 358 300 457 minecraft:red_concrete
setblock 359 299 452 minecraft:red_concrete
setblock 359 299 454 minecraft:red_concrete
setblock 359 299 456 minecraft:red_concrete
setblock 360 299 451 minecraft:red_concrete
setblock 360 299 453 minecraft:red_concrete
setblock 360 299 455 minecraft:red_concrete
fill 360 299 457 360 300 457 minecraft:red_concrete
setblock 361 299 452 minecraft:red_concrete
setblock 361 299 454 minecraft:red_concrete
setblock 361 299 456 minecraft:red_concrete
fill 362 299 417 362 300 417 minecraft:red_concrete
setblock 362 299 451 minecraft:red_concrete
setblock 362 299 453 minecraft:red_concrete
setblock 362 299 455 minecraft:red_concrete
fill 362 299 457 362 300 457 minecraft:red_concrete
setblock 363 299 452 minecraft:red_concrete
setblock 363 299 454 minecraft:red_concrete
setblock 363 299 456 minecraft:red_concrete
setblock 364 299 451 minecraft:red_concrete
setblock 364 299 453 minecraft:red_concrete
setblock 364 299 455 minecraft:red_concrete
fill 364 299 457 364 300 457 minecraft:red_concrete
setblock 365 299 452 minecraft:red_concrete
setblock 365 299 454 minecraft:red_concrete
setblock 365 299 456 minecraft:red_concrete
setblock 366 299 451 minecraft:red_concrete
setblock 366 299 453 minecraft:red_concrete
setblock 366 299 455 minecraft:red_concrete
fill 366 299 457 366 300 457 minecraft:red_concrete
setblock 367 299 452 minecraft:red_concrete
setblock 367 299 454 minecraft:red_concrete
setblock 367 299 456 minecraft:red_concrete
fill 369 299 417 369 300 417 minecraft:red_concrete
fill 370 299 423 370 300 423 minecraft:red_concrete
fill 370 299 430 370 300 430 minecraft:red_concrete
fill 370 299 437 370 300 437 minecraft:red_concrete
fill 370 299 444 370 300 444 minecraft:red_concrete
fill 370 299 451 370 300 451 minecraft:red_concrete
fill 370 299 457 370 300 457 minecraft:red_concrete
fill 330 300 417 330 300 419 minecraft:red_concrete
setblock 330 300 421 minecraft:red_concrete
fill 330 300 423 330 300 426 minecraft:red_concrete
setblock 330 300 428 minecraft:red_concrete
fill 330 300 430 330 300 433 minecraft:red_concrete
setblock 330 300 435 minecraft:red_concrete
fill 330 300 437 330 300 440 minecraft:red_concrete
setblock 330 300 442 minecraft:red_concrete
fill 330 300 444 330 300 447 minecraft:red_concrete
setblock 330 300 449 minecraft:red_concrete
fill 330 300 451 330 300 454 minecraft:red_concrete
setblock 330 300 456 minecraft:red_concrete
setblock 331 300 417 minecraft:red_concrete
fill 331 300 457 334 300 457 minecraft:red_concrete
fill 332 300 438 336 300 438 minecraft:black_concrete
setblock 333 300 417 minecraft:red_concrete
fill 335 300 417 338 300 417 minecraft:red_concrete
setblock 336 300 457 minecraft:red_concrete
fill 338 300 457 341 300 457 minecraft:red_concrete
setblock 340 300 417 minecraft:red_concrete
fill 342 300 417 345 300 417 minecraft:red_concrete
setblock 343 300 457 minecraft:red_concrete
fill 345 300 457 348 300 457 minecraft:red_concrete
setblock 347 300 417 minecraft:red_concrete
fill 349 300 417 352 300 417 minecraft:red_concrete
setblock 350 300 457 minecraft:red_concrete
fill 352 300 457 354 300 457 minecraft:red_concrete
setblock 354 300 417 minecraft:red_concrete
fill 356 300 417 359 300 417 minecraft:red_concrete
fill 356 300 452 366 300 456 minecraft:white_concrete
setblock 361 300 417 minecraft:red_concrete
fill 363 300 417 366 300 417 minecraft:red_concrete
setblock 368 300 417 minecraft:red_concrete
fill 368 300 457 369 300 457 minecraft:red_concrete
fill 370 300 417 370 300 420 minecraft:red_concrete
setblock 370 300 422 minecraft:red_concrete
fill 370 300 424 370 300 427 minecraft:red_concrete
setblock 370 300 429 minecraft:red_concrete
fill 370 300 431 370 300 434 minecraft:red_concrete
setblock 370 300 436 minecraft:red_concrete
fill 370 300 438 370 300 441 minecraft:red_concrete
setblock 370 300 443 minecraft:red_concrete
fill 370 300 445 370 300 448 minecraft:red_concrete
setblock 370 300 450 minecraft:red_concrete
fill 370 300 452 370 300 455 minecraft:red_concrete
