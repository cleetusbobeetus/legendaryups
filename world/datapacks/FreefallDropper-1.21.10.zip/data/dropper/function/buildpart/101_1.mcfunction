setblock 269 138 416 minecraft:white_concrete
fill 271 138 416 271 144 416 minecraft:black_concrete
setblock 272 138 458 minecraft:white_concrete
fill 277 138 426 277 144 426 minecraft:black_concrete
fill 277 138 442 277 144 442 minecraft:black_concrete
fill 235 139 420 235 257 420 minecraft:black_concrete
setblock 235 139 428 minecraft:white_concrete
fill 235 139 429 235 210 429 minecraft:black_concrete
fill 235 139 454 235 149 454 minecraft:black_concrete
setblock 240 139 416 minecraft:white_concrete
fill 242 139 443 242 140 443 minecraft:crying_obsidian
fill 264 139 438 265 140 438 minecraft:amethyst_block
fill 269 139 416 269 234 416 minecraft:black_concrete
fill 272 139 458 272 170 458 minecraft:black_concrete
setblock 277 139 427 minecraft:white_concrete
setblock 277 139 453 minecraft:amethyst_block
fill 235 140 428 235 226 428 minecraft:black_concrete
fill 240 140 416 240 208 416 minecraft:black_concrete
setblock 245 140 416 minecraft:crying_obsidian
fill 256 140 422 256 141 423 minecraft:crying_obsidian
setblock 257 140 416 minecraft:white_concrete
fill 277 140 417 277 267 417 minecraft:black_concrete
setblock 277 140 418 minecraft:amethyst_block
fill 277 140 427 277 202 427 minecraft:black_concrete
fill 277 140 453 277 212 453 minecraft:black_concrete
setblock 235 141 433 minecraft:white_concrete
setblock 235 141 457 minecraft:crying_obsidian
setblock 237 141 458 minecraft:amethyst_block
fill 245 141 416 245 228 416 minecraft:black_concrete
setblock 255 141 458 minecraft:white_concrete
fill 257 141 416 257 192 416 minecraft:black_concrete
setblock 266 141 458 minecraft:amethyst_block
fill 268 141 434 269 142 434 minecraft:obsidian
setblock 274 141 416 minecraft:white_concrete
fill 277 141 418 277 242 418 minecraft:black_concrete
setblock 235 142 432 minecraft:amethyst_block
fill 235 142 433 235 151 433 minecraft:black_concrete
fill 235 142 457 235 196 457 minecraft:black_concrete
setblock 236 142 458 minecraft:amethyst_block
fill 237 142 458 237 152 458 minecraft:black_concrete
setblock 250 142 416 minecraft:white_concrete
fill 255 142 458 255 217 458 minecraft:black_concrete
setblock 262 142 416 minecraft:amethyst_block
fill 266 142 458 266 199 458 minecraft:black_concrete
fill 274 142 416 274 207 416 minecraft:black_concrete
setblock 277 142 447 minecraft:white_concrete
setblock 235 143 425 minecraft:white_concrete
fill 235 143 432 235 148 432 minecraft:black_concrete
setblock 235 143 434 minecraft:white_concrete
setblock 235 143 439 minecraft:amethyst_block
fill 236 143 458 236 216 458 minecraft:black_concrete
setblock 249 143 458 minecraft:amethyst_block
fill 250 143 416 250 160 416 minecraft:black_concrete
setblock 251 143 458 minecraft:crying_obsidian
setblock 252 143 416 minecraft:amethyst_block
fill 262 143 416 262 180 416 minecraft:black_concrete
fill 277 143 447 277 161 447 minecraft:black_concrete
fill 235 144 425 235 232 425 minecraft:black_concrete
fill 235 144 434 235 182 434 minecraft:black_concrete
fill 235 144 439 235 164 439 minecraft:black_concrete
setblock 238 144 419 minecraft:light[level=12]
setblock 238 144 427 minecraft:light[level=12]
setblock 238 144 435 minecraft:light[level=12]
setblock 238 144 443 minecraft:light[level=12]
setblock 238 144 451 minecraft:light[level=12]
setblock 246 144 419 minecraft:light[level=12]
setblock 246 144 427 minecraft:light[level=12]
setblock 246 144 435 minecraft:light[level=12]
setblock 246 144 443 minecraft:light[level=12]
setblock 246 144 451 minecraft:light[level=12]
setblock 249 144 458 minecraft:black_concrete
fill 251 144 458 251 208 458 minecraft:black_concrete
fill 252 144 416 252 162 416 minecraft:black_concrete
setblock 254 144 419 minecraft:light[level=12]
setblock 254 144 427 minecraft:light[level=12]
setblock 254 144 435 minecraft:light[level=12]
setblock 254 144 443 minecraft:light[level=12]
setblock 254 144 451 minecraft:light[level=12]
setblock 262 144 419 minecraft:light[level=12]
setblock 262 144 427 minecraft:light[level=12]
setblock 262 144 435 minecraft:light[level=12]
setblock 262 144 443 minecraft:light[level=12]
setblock 262 144 451 minecraft:light[level=12]
fill 269 144 428 270 145 429 minecraft:amethyst_block
setblock 270 144 419 minecraft:light[level=12]
setblock 270 144 427 minecraft:light[level=12]
setblock 270 144 435 minecraft:light[level=12]
setblock 270 144 443 minecraft:light[level=12]
setblock 270 144 451 minecraft:light[level=12]
setblock 235 145 417 minecraft:crying_obsidian
fill 235 145 424 235 146 424 minecraft:purple_concrete
fill 235 145 440 235 146 440 minecraft:purple_concrete
fill 235 145 456 235 146 456 minecraft:purple_concrete
fill 239 145 416 239 146 416 minecraft:purple_concrete
fill 249 145 458 249 146 458 minecraft:purple_concrete
fill 255 145 416 255 146 416 minecraft:purple_concrete
fill 265 145 458 265 146 458 minecraft:purple_concrete
fill 271 145 416 271 146 416 minecraft:purple_concrete
fill 277 145 426 277 146 426 minecraft:purple_concrete
setblock 277 145 434 minecraft:white_concrete
setblock 277 145 436 minecraft:amethyst_block
fill 277 145 442 277 146 442 minecraft:purple_concrete
fill 235 146 417 235 202 417 minecraft:black_concrete
fill 262 146 429 262 147 430 minecraft:obsidian
fill 277 146 434 277 205 434 minecraft:black_concrete
fill 277 146 436 277 228 436 minecraft:black_concrete
setblock 277 146 456 minecraft:crying_obsidian
fill 235 147 424 235 153 424 minecraft:black_concrete
fill 235 147 440 235 153 440 minecraft:black_concrete
setblock 235 147 445 minecraft:crying_obsidian
fill 235 147 456 235 153 456 minecraft:black_concrete
fill 239 147 416 239 153 416 minecraft:black_concrete
setblock 247 147 458 minecraft:crying_obsidian
fill 249 147 458 249 153 458 minecraft:black_concrete
fill 255 147 416 255 153 416 minecraft:black_concrete
fill 265 147 458 265 153 458 minecraft:black_concrete
fill 271 147 416 271 153 416 minecraft:black_concrete
setblock 274 147 458 minecraft:amethyst_block
fill 277 147 426 277 153 426 minecraft:black_concrete
fill 277 147 429 277 195 429 minecraft:black_concrete
setblock 277 147 430 minecraft:white_concrete
setblock 277 147 442 minecraft:amethyst_block
fill 277 147 456 277 282 456 minecraft:black_concrete
fill 235 148 445 235 217 445 minecraft:black_concrete
setblock 235 148 452 minecraft:amethyst_block
fill 247 148 458 247 158 458 minecraft:black_concrete
fill 274 148 458 274 263 458 minecraft:black_concrete
fill 277 148 430 277 182 430 minecraft:black_concrete
setblock 277 148 438 minecraft:white_concrete
fill 277 148 442 277 153 442 minecraft:black_concrete
setblock 235 149 427 minecraft:amethyst_block
setblock 235 149 432 minecraft:amethyst_block
fill 235 149 452 235 261 452 minecraft:black_concrete
setblock 277 149 421 minecraft:white_concrete
fill 277 149 438 277 186 438 minecraft:black_concrete
fill 235 150 427 235 192 427 minecraft:black_concrete
fill 235 150 432 235 273 432 minecraft:black_concrete
setblock 235 150 454 minecraft:crying_obsidian
setblock 243 150 416 minecraft:amethyst_block
fill 277 150 421 277 159 421 minecraft:black_concrete
fill 235 151 454 235 244 454 minecraft:black_concrete
fill 243 151 416 243 156 416 minecraft:black_concrete
setblock 256 151 416 minecraft:white_concrete
setblock 271 151 458 minecraft:amethyst_block
setblock 277 151 439 minecraft:crying_obsidian
setblock 235 152 433 minecraft:crying_obsidian
setblock 238 152 419 minecraft:light[level=12]
setblock 238 152 427 minecraft:light[level=12]
setblock 238 152 435 minecraft:light[level=12]
setblock 238 152 443 minecraft:light[level=12]
setblock 238 152 451 minecraft:light[level=12]
setblock 246 152 419 minecraft:light[level=12]
setblock 246 152 427 minecraft:light[level=12]
setblock 246 152 435 minecraft:light[level=12]
setblock 246 152 443 minecraft:light[level=12]
setblock 246 152 451 minecraft:light[level=12]
setblock 254 152 419 minecraft:light[level=12]
setblock 254 152 427 minecraft:light[level=12]
setblock 254 152 435 minecraft:light[level=12]
setblock 254 152 443 minecraft:light[level=12]
setblock 254 152 451 minecraft:light[level=12]
fill 256 152 416 256 293 416 minecraft:black_concrete
setblock 262 152 419 minecraft:light[level=12]
setblock 262 152 427 minecraft:light[level=12]
setblock 262 152 435 minecraft:light[level=12]
setblock 262 152 443 minecraft:light[level=12]
setblock 262 152 451 minecraft:light[level=12]
setblock 270 152 419 minecraft:light[level=12]
setblock 270 152 427 minecraft:light[level=12]
setblock 270 152 435 minecraft:light[level=12]
setblock 270 152 443 minecraft:light[level=12]
setblock 270 152 451 minecraft:light[level=12]
fill 271 152 458 271 161 458 minecraft:black_concrete
fill 277 152 439 277 278 439 minecraft:black_concrete
setblock 235 153 418 minecraft:white_concrete
fill 235 153 433 235 307 433 minecraft:black_concrete
setblock 235 153 447 minecraft:amethyst_block
setblock 237 153 458 minecraft:white_concrete
fill 248 153 439 248 154 440 minecraft:amethyst_block
fill 235 154 418 235 175 418 minecraft:black_concrete
fill 235 154 424 235 155 424 minecraft:purple_concrete
fill 235 154 440 235 155 440 minecraft:purple_concrete
fill 235 154 447 235 166 447 minecraft:black_concrete
fill 235 154 456 235 155 456 minecraft:purple_concrete
fill 237 154 458 237 230 458 minecraft:black_concrete
fill 239 154 416 239 155 416 minecraft:purple_concrete
setblock 246 154 458 minecraft:white_concrete
fill 249 154 458 249 155 458 minecraft:purple_concrete
fill 255 154 416 255 155 416 minecraft:purple_concrete
fill 265 154 458 265 155 458 minecraft:purple_concrete
fill 266 154 440 266 155 440 minecraft:amethyst_block
fill 271 154 416 271 155 416 minecraft:purple_concrete
setblock 277 154 419 minecraft:white_concrete
fill 277 154 426 277 155 426 minecraft:purple_concrete
fill 277 154 442 277 155 442 minecraft:purple_concrete
setblock 277 154 446 minecraft:amethyst_block
setblock 235 155 423 minecraft:amethyst_block
fill 246 155 458 246 307 458 minecraft:black_concrete
fill 277 155 419 277 203 419 minecraft:black_concrete
fill 277 155 446 277 179 446 minecraft:black_concrete
fill 235 156 423 235 156 424 minecraft:black_concrete
fill 235 156 440 235 170 440 minecraft:black_concrete
fill 235 156 456 235 170 456 minecraft:black_concrete
fill 239 156 416 239 170 416 minecraft:black_concrete
fill 249 156 458 249 170 458 minecraft:black_concrete
fill 255 156 416 255 159 416 minecraft:black_concrete
fill 265 156 458 265 168 458 minecraft:black_concrete
fill 271 156 416 271 158 416 minecraft:black_concrete
fill 277 156 426 277 170 426 minecraft:black_concrete
fill 277 156 442 277 170 442 minecraft:black_concrete
setblock 235 157 423 minecraft:white_concrete
fill 235 157 424 235 158 424 minecraft:black_concrete
setblock 243 157 416 minecraft:amethyst_block
setblock 246 157 416 minecraft:crying_obsidian
setblock 264 157 416 minecraft:white_concrete
setblock 277 157 443 minecraft:crying_obsidian
fill 235 158 423 235 187 423 minecraft:black_concrete
setblock 243 158 416 minecraft:crying_obsidian
fill 246 158 416 246 181 416 minecraft:black_concrete
setblock 249 158 416 minecraft:amethyst_block
fill 264 158 416 264 217 416 minecraft:black_concrete
fill 277 158 443 277 278 443 minecraft:black_concrete
setblock 277 158 451 minecraft:amethyst_block
setblock 235 159 424 minecraft:crying_obsidian
setblock 235 159 446 minecraft:crying_obsidian
fill 243 159 416 243 173 416 minecraft:black_concrete
setblock 247 159 458 minecraft:crying_obsidian
fill 249 159 416 249 276 416 minecraft:black_concrete
setblock 271 159 416 minecraft:crying_obsidian
setblock 277 159 433 minecraft:white_concrete
fill 277 159 451 277 173 451 minecraft:black_concrete
fill 235 160 424 235 170 424 minecraft:black_concrete
setblock 235 160 444 minecraft:white_concrete
fill 235 160 446 235 165 446 minecraft:black_concrete
setblock 235 160 453 minecraft:crying_obsidian
setblock 238 160 416 minecraft:crying_obsidian
setblock 238 160 419 minecraft:light[level=12]
setblock 238 160 427 minecraft:light[level=12]
setblock 238 160 435 minecraft:light[level=12]
setblock 238 160 443 minecraft:light[level=12]
setblock 238 160 451 minecraft:light[level=12]
setblock 246 160 419 minecraft:light[level=12]
setblock 246 160 427 minecraft:light[level=12]
setblock 246 160 435 minecraft:light[level=12]
setblock 246 160 443 minecraft:light[level=12]
setblock 246 160 451 minecraft:light[level=12]
fill 247 160 458 247 282 458 minecraft:black_concrete
setblock 254 160 419 minecraft:light[level=12]
setblock 254 160 427 minecraft:light[level=12]
setblock 254 160 435 minecraft:light[level=12]
setblock 254 160 443 minecraft:light[level=12]
setblock 254 160 451 minecraft:light[level=12]
setblock 255 160 416 minecraft:crying_obsidian
setblock 262 160 419 minecraft:light[level=12]
setblock 262 160 427 minecraft:light[level=12]
setblock 262 160 435 minecraft:light[level=12]
setblock 262 160 443 minecraft:light[level=12]
setblock 262 160 451 minecraft:light[level=12]
setblock 270 160 419 minecraft:light[level=12]
setblock 270 160 427 minecraft:light[level=12]
setblock 270 160 435 minecraft:light[level=12]
setblock 270 160 443 minecraft:light[level=12]
setblock 270 160 451 minecraft:light[level=12]
fill 271 160 416 271 170 416 minecraft:black_concrete
setblock 277 160 421 minecraft:white_concrete
fill 277 160 433 277 219 433 minecraft:black_concrete
fill 235 161 444 235 211 444 minecraft:black_concrete
setblock 235 161 450 minecraft:crying_obsidian
fill 235 161 453 235 307 453 minecraft:black_concrete
fill 238 161 416 238 258 416 minecraft:black_concrete
setblock 238 161 458 minecraft:amethyst_block
setblock 250 161 416 minecraft:white_concrete
fill 255 161 416 255 170 416 minecraft:black_concrete
setblock 270 161 458 minecraft:amethyst_block
fill 277 161 421 277 173 421 minecraft:black_concrete
setblock 235 162 419 minecraft:white_concrete
fill 235 162 450 235 203 450 minecraft:black_concrete
fill 238 162 458 238 175 458 minecraft:black_concrete
fill 243 162 438 244 163 438 minecraft:black_concrete
fill 244 162 435 245 163 437 minecraft:black_concrete
fill 244 162 439 245 163 441 minecraft:black_concrete
fill 245 162 433 246 162 434 minecraft:black_concrete
fill 245 162 438 252 162 438 minecraft:purple_concrete
fill 245 162 442 246 162 443 minecraft:black_concrete
fill 246 162 432 249 162 432 minecraft:black_concrete
fill 246 162 435 252 162 437 minecraft:purple_concrete
fill 246 162 439 252 162 441 minecraft:purple_concrete
fill 246 162 444 249 162 444 minecraft:black_concrete
setblock 247 162 433 minecraft:black_concrete
fill 247 162 434 255 162 434 minecraft:purple_concrete
fill 247 162 442 255 162 442 minecraft:purple_concrete
setblock 247 162 443 minecraft:black_concrete
fill 248 162 431 251 162 431 minecraft:black_concrete
fill 248 162 433 256 162 433 minecraft:purple_concrete
fill 248 162 443 256 162 443 minecraft:purple_concrete
fill 248 162 445 251 162 445 minecraft:black_concrete
fill 249 162 430 256 162 430 minecraft:black_concrete
fill 249 162 446 256 162 446 minecraft:black_concrete
fill 250 162 416 250 215 416 minecraft:black_concrete
fill 250 162 432 266 162 432 minecraft:purple_concrete
fill 250 162 444 266 162 444 minecraft:purple_concrete
fill 252 162 429 264 162 429 minecraft:black_concrete
fill 252 162 431 264 162 431 minecraft:purple_concrete
fill 252 162 445 264 162 445 minecraft:purple_concrete
fill 252 162 447 264 162 447 minecraft:black_concrete
setblock 253 162 435 minecraft:purple_concrete
setblock 253 162 436 minecraft:magenta_concrete
setblock 253 162 437 minecraft:purple_concrete
fill 253 162 438 255 162 438 minecraft:magenta_concrete
setblock 253 162 439 minecraft:purple_concrete
setblock 253 162 440 minecraft:magenta_concrete
setblock 253 162 441 minecraft:purple_concrete
fill 254 162 435 256 162 435 minecraft:magenta_concrete
setblock 254 162 436 minecraft:purple_concrete
fill 254 162 437 255 162 437 minecraft:magenta_concrete
fill 254 162 439 255 162 439 minecraft:magenta_concrete
setblock 254 162 440 minecraft:purple_concrete
fill 254 162 441 256 162 441 minecraft:magenta_concrete
fill 255 162 436 256 162 436 minecraft:magenta_concrete
fill 255 162 440 256 162 440 minecraft:magenta_concrete
fill 256 162 434 257 162 434 minecraft:magenta_concrete
setblock 256 162 437 minecraft:black_concrete
setblock 256 162 439 minecraft:black_concrete
fill 256 162 442 257 162 442 minecraft:magenta_concrete
fill 257 162 428 259 162 428 minecraft:black_concrete
fill 257 162 430 259 162 430 minecraft:purple_concrete
setblock 257 162 433 minecraft:magenta_concrete
fill 257 162 435 259 162 435 minecraft:purple_concrete
setblock 257 162 436 minecraft:black_concrete
setblock 257 162 440 minecraft:black_concrete
fill 257 162 441 259 162 441 minecraft:purple_concrete
setblock 257 162 443 minecraft:magenta_concrete
fill 257 162 446 259 162 446 minecraft:purple_concrete
fill 257 162 448 259 162 448 minecraft:black_concrete
fill 258 162 433 258 162 434 minecraft:purple_concrete
fill 258 162 442 258 162 443 minecraft:purple_concrete
fill 259 162 433 259 162 434 minecraft:magenta_concrete
setblock 259 162 436 minecraft:black_concrete
setblock 259 162 440 minecraft:black_concrete
fill 259 162 442 259 162 443 minecraft:magenta_concrete
fill 260 162 430 267 162 430 minecraft:black_concrete
fill 260 162 433 268 162 433 minecraft:purple_concrete
fill 260 162 434 260 162 436 minecraft:magenta_concrete
setblock 260 162 437 minecraft:black_concrete
setblock 260 162 439 minecraft:black_concrete
fill 260 162 440 260 162 442 minecraft:magenta_concrete
fill 260 162 443 268 162 443 minecraft:purple_concrete
fill 260 162 446 267 162 446 minecraft:black_concrete
fill 261 162 434 269 162 434 minecraft:purple_concrete
fill 261 162 435 261 162 441 minecraft:magenta_concrete
fill 261 162 442 269 162 442 minecraft:purple_concrete
setblock 262 162 435 minecraft:magenta_concrete
setblock 262 162 436 minecraft:purple_concrete
fill 262 162 437 262 162 439 minecraft:magenta_concrete
setblock 262 162 440 minecraft:purple_concrete
setblock 262 162 441 minecraft:magenta_concrete
fill 263 162 435 270 162 435 minecraft:purple_concrete
setblock 263 162 436 minecraft:magenta_concrete
fill 263 162 437 270 162 437 minecraft:purple_concrete
setblock 263 162 438 minecraft:magenta_concrete
fill 263 162 439 270 162 439 minecraft:purple_concrete
setblock 263 162 440 minecraft:magenta_concrete
fill 263 162 441 270 162 441 minecraft:purple_concrete
fill 264 162 436 270 162 436 minecraft:purple_concrete
fill 264 162 438 271 162 438 minecraft:purple_concrete
fill 264 162 440 270 162 440 minecraft:purple_concrete
fill 265 162 431 268 162 431 minecraft:black_concrete
fill 265 162 445 268 162 445 minecraft:black_concrete
fill 267 162 432 270 162 432 minecraft:black_concrete
fill 267 162 444 270 162 444 minecraft:black_concrete
fill 269 162 433 271 162 433 minecraft:black_concrete
fill 269 162 443 271 162 443 minecraft:black_concrete
fill 270 162 434 271 163 434 minecraft:black_concrete
fill 270 162 442 271 163 442 minecraft:black_concrete
fill 270 162 458 270 176 458 minecraft:black_concrete
fill 271 162 435 272 163 437 minecraft:black_concrete
fill 271 162 439 272 163 441 minecraft:black_concrete
setblock 271 162 458 minecraft:amethyst_block
fill 272 162 438 273 163 438 minecraft:black_concrete
setblock 273 162 458 minecraft:amethyst_block
setblock 277 162 447 minecraft:crying_obsidian
setblock 277 162 450 minecraft:amethyst_block
fill 235 163 419 276 163 419 minecraft:black_concrete
setblock 235 163 437 minecraft:white_concrete
fill 236 163 417 276 163 418 minecraft:black_concrete
fill 236 163 420 242 163 457 minecraft:black_concrete
fill 243 163 420 243 163 437 minecraft:black_concrete
fill 243 163 439 243 163 457 minecraft:black_concrete
fill 244 163 420 245 163 434 minecraft:black_concrete
fill 244 163 442 245 163 457 minecraft:black_concrete
fill 245 163 438 254 164 438 minecraft:iron_block
fill 246 163 420 246 163 432 minecraft:black_concrete
fill 246 163 433 270 164 433 minecraft:iron_block
setblock 246 163 434 minecraft:black_concrete
fill 246 163 435 247 163 436 minecraft:purple_concrete
fill 246 163 437 246 164 437 minecraft:iron_block
fill 246 163 439 246 164 439 minecraft:iron_block
fill 246 163 440 247 163 441 minecraft:purple_concrete
setblock 246 163 442 minecraft:black_concrete
fill 246 163 443 270 164 443 minecraft:iron_block
fill 246 163 444 246 163 457 minecraft:black_concrete
fill 247 163 420 249 163 431 minecraft:black_concrete
fill 247 163 432 269 164 432 minecraft:iron_block
fill 247 163 434 269 164 434 minecraft:iron_block
setblock 247 163 437 minecraft:purple_concrete
setblock 247 163 439 minecraft:purple_concrete
fill 247 163 442 269 164 442 minecraft:iron_block
fill 247 163 444 269 164 444 minecraft:iron_block
fill 247 163 445 249 163 457 minecraft:black_concrete
fill 248 163 435 254 164 437 minecraft:iron_block
fill 248 163 439 254 164 441 minecraft:iron_block
fill 250 163 420 254 163 427 minecraft:black_concrete
fill 250 163 428 251 164 429 minecraft:iron_block
setblock 250 163 430 minecraft:black_concrete
fill 250 163 431 266 164 431 minecraft:iron_block
fill 250 163 445 266 164 445 minecraft:iron_block
setblock 250 163 446 minecraft:black_concrete
fill 250 163 447 251 164 448 minecraft:iron_block
fill 250 163 449 254 163 457 minecraft:black_concrete
fill 251 163 430 265 164 430 minecraft:iron_block
fill 251 163 446 265 164 446 minecraft:iron_block
setblock 252 163 416 minecraft:amethyst_block
fill 252 163 428 253 163 428 minecraft:black_concrete
fill 252 163 429 266 164 429 minecraft:iron_block
fill 252 163 447 266 164 447 minecraft:iron_block
fill 252 163 448 253 163 448 minecraft:black_concrete
fill 254 163 428 262 164 428 minecraft:iron_block
fill 254 163 448 262 164 448 minecraft:iron_block
fill 255 163 420 276 163 425 minecraft:black_concrete
fill 255 163 426 256 164 427 minecraft:iron_block
fill 255 163 435 255 164 436 minecraft:iron_block
fill 255 163 437 255 165 439 minecraft:waxed_copper_block
fill 255 163 440 255 164 441 minecraft:iron_block
fill 255 163 449 256 164 450 minecraft:iron_block
fill 255 163 451 276 163 457 minecraft:black_concrete
fill 256 163 435 256 164 435 minecraft:iron_block
fill 256 163 436 256 163 437 minecraft:waxed_copper_block
fill 256 163 439 256 163 440 minecraft:waxed_copper_block
fill 256 163 441 256 164 441 minecraft:iron_block
fill 257 163 426 257 163 427 minecraft:black_concrete
fill 257 163 435 257 163 436 minecraft:waxed_copper_block
fill 257 163 440 257 163 441 minecraft:waxed_copper_block
fill 257 163 449 257 163 450 minecraft:black_concrete
fill 258 163 426 259 163 426 minecraft:black_concrete
fill 258 163 427 258 164 427 minecraft:iron_block
fill 258 163 435 259 165 435 minecraft:waxed_copper_block
fill 258 163 441 259 165 441 minecraft:waxed_copper_block
fill 258 163 449 258 164 449 minecraft:iron_block
fill 258 163 450 259 163 450 minecraft:black_concrete
setblock 259 163 427 minecraft:black_concrete
fill 259 163 436 260 163 436 minecraft:waxed_copper_block
fill 259 163 440 260 163 440 minecraft:waxed_copper_block
setblock 259 163 449 minecraft:black_concrete
fill 260 163 426 261 164 427 minecraft:iron_block
fill 260 163 435 268 164 435 minecraft:iron_block
fill 260 163 437 261 163 437 minecraft:waxed_copper_block
fill 260 163 439 261 163 439 minecraft:waxed_copper_block
fill 260 163 441 268 164 441 minecraft:iron_block
fill 260 163 449 261 164 450 minecraft:iron_block
fill 261 163 436 268 164 436 minecraft:iron_block
fill 261 163 438 261 165 438 minecraft:waxed_copper_block
fill 261 163 440 268 164 440 minecraft:iron_block
fill 262 163 426 276 163 427 minecraft:black_concrete
fill 262 163 437 268 164 439 minecraft:iron_block
fill 262 163 449 276 163 450 minecraft:black_concrete
fill 263 163 428 264 163 428 minecraft:black_concrete
fill 263 163 448 264 163 448 minecraft:black_concrete
fill 265 163 428 266 164 428 minecraft:iron_block
fill 265 163 448 266 164 448 minecraft:iron_block
fill 266 163 430 276 163 430 minecraft:black_concrete
fill 266 163 446 276 163 446 minecraft:black_concrete
fill 267 163 428 276 163 429 minecraft:black_concrete
fill 267 163 431 276 163 431 minecraft:black_concrete
fill 267 163 445 276 163 445 minecraft:black_concrete
fill 267 163 447 276 163 448 minecraft:black_concrete
fill 269 163 435 269 163 437 minecraft:purple_concrete
fill 269 163 438 271 164 438 minecraft:iron_block
fill 269 163 439 269 163 441 minecraft:purple_concrete
fill 270 163 432 276 163 432 minecraft:black_concrete
fill 270 163 435 270 163 436 minecraft:purple_concrete
fill 270 163 437 270 164 437 minecraft:iron_block
fill 270 163 439 270 164 439 minecraft:iron_block
fill 270 163 440 270 163 441 minecraft:purple_concrete
fill 270 163 444 276 163 444 minecraft:black_concrete
fill 271 163 433 276 163 433 minecraft:black_concrete
fill 271 163 443 276 163 443 minecraft:black_concrete
fill 271 163 458 271 212 458 minecraft:black_concrete
fill 272 163 434 276 163 434 minecraft:black_concrete
fill 272 163 442 276 163 442 minecraft:black_concrete
fill 273 163 435 276 163 437 minecraft:black_concrete
fill 273 163 439 276 163 441 minecraft:black_concrete
fill 273 163 458 273 166 458 minecraft:black_concrete
fill 274 163 438 276 163 438 minecraft:black_concrete
fill 277 163 447 277 195 447 minecraft:black_concrete
fill 277 163 450 277 266 450 minecraft:black_concrete
fill 235 164 419 235 177 419 minecraft:black_concrete
fill 235 164 437 235 183 437 minecraft:black_concrete
setblock 241 164 458 minecraft:crying_obsidian
setblock 252 164 416 minecraft:black_concrete
setblock 256 164 436 minecraft:waxed_copper_block
setblock 256 164 440 minecraft:waxed_copper_block
fill 257 164 435 257 165 435 minecraft:waxed_copper_block
fill 257 164 441 257 165 441 minecraft:waxed_copper_block
setblock 260 164 436 minecraft:waxed_copper_block
setblock 260 164 440 minecraft:waxed_copper_block
fill 261 164 437 261 165 437 minecraft:waxed_copper_block
fill 261 164 439 261 165 439 minecraft:waxed_copper_block
setblock 269 164 458 minecraft:crying_obsidian
setblock 235 165 422 minecraft:white_concrete
setblock 235 165 439 minecraft:crying_obsidian
setblock 235 165 443 minecraft:amethyst_block
fill 241 165 458 241 179 458 minecraft:black_concrete
fill 251 165 436 251 165 440 minecraft:waxed_oxidized_copper
setblock 252 165 416 minecraft:white_concrete
fill 252 165 434 252 165 435 minecraft:waxed_oxidized_copper
fill 252 165 441 252 165 442 minecraft:waxed_oxidized_copper
setblock 253 165 433 minecraft:waxed_oxidized_copper
setblock 253 165 443 minecraft:waxed_oxidized_copper
fill 254 165 432 255 165 432 minecraft:waxed_oxidized_copper
fill 254 165 444 255 165 444 minecraft:waxed_oxidized_copper
fill 256 165 431 260 165 431 minecraft:waxed_oxidized_copper
fill 256 165 445 260 165 445 minecraft:waxed_oxidized_copper
fill 261 165 432 262 165 432 minecraft:waxed_oxidized_copper
fill 261 165 444 262 165 444 minecraft:waxed_oxidized_copper
setblock 263 165 433 minecraft:waxed_oxidized_copper
setblock 263 165 443 minecraft:waxed_oxidized_copper
fill 264 165 434 264 165 435 minecraft:waxed_oxidized_copper
fill 264 165 441 264 165 442 minecraft:waxed_oxidized_copper
fill 265 165 436 265 165 440 minecraft:waxed_oxidized_copper
fill 269 165 458 269 278 458 minecraft:black_concrete
fill 235 166 422 235 182 422 minecraft:black_concrete
fill 235 166 439 235 287 439 minecraft:black_concrete
fill 235 166 443 235 203 443 minecraft:black_concrete
setblock 235 166 446 minecraft:amethyst_block
fill 252 166 416 252 176 416 minecraft:black_concrete
setblock 277 166 444 minecraft:amethyst_block
fill 235 167 446 235 177 446 minecraft:black_concrete
setblock 235 167 447 minecraft:white_concrete
fill 249 167 444 250 168 445 minecraft:obsidian
fill 256 167 450 258 172 451 minecraft:black_concrete
fill 257 167 449 257 172 449 minecraft:black_concrete
fill 257 167 452 257 172 452 minecraft:black_concrete
setblock 273 167 458 minecraft:white_concrete
fill 277 167 444 277 230 444 minecraft:black_concrete
fill 235 168 447 235 206 447 minecraft:black_concrete
fill 236 168 425 237 171 427 minecraft:amethyst_block
setblock 238 168 419 minecraft:light[level=12]
setblock 238 168 427 minecraft:light[level=12]
setblock 238 168 435 minecraft:light[level=12]
setblock 238 168 443 minecraft:light[level=12]
setblock 238 168 451 minecraft:light[level=12]
setblock 246 168 419 minecraft:light[level=12]
setblock 246 168 427 minecraft:light[level=12]
setblock 246 168 435 minecraft:light[level=12]
setblock 246 168 443 minecraft:light[level=12]
setblock 246 168 451 minecraft:light[level=12]
setblock 254 168 419 minecraft:light[level=12]
setblock 254 168 427 minecraft:light[level=12]
setblock 254 168 435 minecraft:light[level=12]
setblock 254 168 443 minecraft:light[level=12]
setblock 254 168 451 minecraft:light[level=12]
fill 256 168 449 256 172 449 minecraft:black_concrete
fill 256 168 452 256 172 452 minecraft:black_concrete
fill 258 168 449 258 172 449 minecraft:black_concrete
fill 258 168 452 258 172 452 minecraft:black_concrete
fill 259 168 450 259 172 451 minecraft:black_concrete
setblock 262 168 419 minecraft:light[level=12]
setblock 262 168 427 minecraft:light[level=12]
setblock 262 168 435 minecraft:light[level=12]
setblock 262 168 443 minecraft:light[level=12]
setblock 262 168 451 minecraft:light[level=12]
setblock 270 168 419 minecraft:light[level=12]
setblock 270 168 427 minecraft:light[level=12]
setblock 270 168 435 minecraft:light[level=12]
setblock 270 168 443 minecraft:light[level=12]
setblock 270 168 451 minecraft:light[level=12]
fill 273 168 458 273 284 458 minecraft:black_concrete
setblock 235 169 438 minecraft:amethyst_block
fill 236 169 424 236 170 424 minecraft:amethyst_block
fill 236 169 428 236 170 428 minecraft:amethyst_block
fill 238 169 425 238 171 427 minecraft:amethyst_block
fill 239 169 426 239 172 426 minecraft:amethyst_block
setblock 244 169 458 minecraft:white_concrete
fill 255 169 450 255 172 451 minecraft:black_concrete
fill 259 169 449 259 172 449 minecraft:black_concrete
fill 259 169 452 259 172 452 minecraft:black_concrete
fill 262 169 435 263 169 441 minecraft:waxed_copper_block
fill 263 169 434 271 170 434 minecraft:waxed_copper_block
fill 263 169 442 271 170 442 minecraft:waxed_copper_block
fill 264 169 433 270 170 433 minecraft:waxed_copper_block
fill 264 169 435 264 170 437 minecraft:waxed_copper_block
fill 264 169 439 264 170 441 minecraft:waxed_copper_block
fill 264 169 443 270 170 443 minecraft:waxed_copper_block
fill 265 169 435 266 170 435 minecraft:waxed_copper_block
fill 265 169 441 266 170 441 minecraft:waxed_copper_block
setblock 265 169 458 minecraft:white_concrete
fill 267 169 432 267 170 432 minecraft:waxed_copper_block
fill 267 169 444 267 170 444 minecraft:waxed_copper_block
fill 268 169 435 272 170 435 minecraft:waxed_copper_block
fill 268 169 441 272 170 441 minecraft:waxed_copper_block
fill 270 169 436 272 170 437 minecraft:waxed_copper_block
fill 270 169 439 272 170 440 minecraft:waxed_copper_block
fill 271 169 438 273 170 438 minecraft:waxed_copper_block
fill 235 170 438 235 247 438 minecraft:black_concrete
fill 239 170 425 239 171 425 minecraft:amethyst_block
fill 239 170 427 239 171 427 minecraft:amethyst_block
fill 240 170 426 240 172 426 minecraft:amethyst_block
fill 244 170 458 244 274 458 minecraft:black_concrete
setblock 253 170 458 minecraft:white_concrete
fill 255 170 449 255 172 449 minecraft:black_concrete
fill 255 170 452 255 172 452 minecraft:black_concrete
fill 256 170 448 258 172 448 minecraft:black_concrete
fill 256 170 453 258 172 453 minecraft:black_concrete
fill 262 170 435 263 170 436 minecraft:waxed_copper_block
fill 262 170 440 263 170 441 minecraft:waxed_copper_block
fill 263 170 437 263 170 439 minecraft:waxed_copper_block
setblock 265 170 458 minecraft:black_concrete
fill 235 171 424 235 173 424 minecraft:purple_concrete
fill 235 171 440 235 173 440 minecraft:purple_concrete
fill 235 171 456 235 173 456 minecraft:purple_concrete
fill 239 171 416 239 173 416 minecraft:purple_concrete
setblock 240 171 425 minecraft:amethyst_block
setblock 240 171 427 minecraft:amethyst_block
fill 241 171 426 242 172 426 minecraft:amethyst_block
setblock 244 171 416 minecraft:amethyst_block
fill 249 171 458 249 173 458 minecraft:purple_concrete
fill 253 171 458 253 240 458 minecraft:black_concrete
fill 254 171 450 254 172 451 minecraft:black_concrete
fill 255 171 416 255 173 416 minecraft:purple_concrete
fill 255 171 448 255 172 448 minecraft:black_concrete
fill 255 171 453 255 172 453 minecraft:black_concrete
fill 259 171 448 259 172 448 minecraft:black_concrete
fill 259 171 453 259 172 453 minecraft:black_concrete
fill 260 171 449 260 172 452 minecraft:black_concrete
setblock 264 171 458 minecraft:amethyst_block
fill 265 171 458 265 173 458 minecraft:purple_concrete
setblock 268 171 416 minecraft:white_concrete
fill 271 171 416 271 173 416 minecraft:purple_concrete
setblock 272 171 458 minecraft:crying_obsidian
setblock 277 171 423 minecraft:amethyst_block
fill 277 171 426 277 173 426 minecraft:purple_concrete
fill 277 171 442 277 173 442 minecraft:purple_concrete
setblock 277 171 457 minecraft:white_concrete
setblock 243 172 426 minecraft:amethyst_block
fill 244 172 416 244 305 416 minecraft:black_concrete
setblock 254 172 449 minecraft:black_concrete
setblock 254 172 452 minecraft:black_concrete
fill 256 172 447 258 172 447 minecraft:black_concrete
fill 256 172 454 258 172 454 minecraft:black_concrete
setblock 260 172 448 minecraft:black_concrete
setblock 260 172 453 minecraft:black_concrete
fill 264 172 458 264 185 458 minecraft:black_concrete
fill 268 172 416 268 184 416 minecraft:black_concrete
fill 272 172 458 272 225 458 minecraft:black_concrete
fill 277 172 423 277 288 423 minecraft:black_concrete
fill 277 172 457 277 221 457 minecraft:black_concrete
fill 256 173 450 258 173 451 minecraft:amethyst_block
setblock 259 173 458 minecraft:amethyst_block
setblock 235 174 424 minecraft:amethyst_block
fill 235 174 440 235 179 440 minecraft:black_concrete
fill 235 174 456 235 179 456 minecraft:black_concrete
fill 239 174 416 239 179 416 minecraft:black_concrete
setblock 243 174 416 minecraft:white_concrete
setblock 245 174 458 minecraft:amethyst_block
fill 249 174 458 249 179 458 minecraft:black_concrete
fill 255 174 416 255 179 416 minecraft:black_concrete
fill 257 174 450 258 174 451 minecraft:amethyst_block
setblock 258 174 458 minecraft:amethyst_block
fill 259 174 458 259 181 458 minecraft:black_concrete
fill 265 174 458 265 179 458 minecraft:black_concrete
fill 270 174 435 270 175 435 minecraft:amethyst_block
fill 271 174 416 271 179 416 minecraft:black_concrete
setblock 277 174 421 minecraft:crying_obsidian
setblock 277 174 424 minecraft:amethyst_block
fill 277 174 426 277 179 426 minecraft:black_concrete
fill 277 174 442 277 179 442 minecraft:black_concrete
setblock 277 174 451 minecraft:crying_obsidian
fill 235 175 424 235 176 424 minecraft:black_concrete
fill 243 175 416 243 307 416 minecraft:black_concrete
fill 245 175 458 245 177 458 minecraft:black_concrete
fill 257 175 450 257 176 451 minecraft:amethyst_block
fill 258 175 458 258 274 458 minecraft:black_concrete
setblock 262 175 458 minecraft:amethyst_block
fill 277 175 421 277 276 421 minecraft:black_concrete
fill 277 175 424 277 180 424 minecraft:black_concrete
setblock 277 175 428 minecraft:white_concrete
fill 277 175 451 277 184 451 minecraft:black_concrete
setblock 235 176 418 minecraft:amethyst_block
setblock 238 176 419 minecraft:light[level=12]
setblock 238 176 427 minecraft:light[level=12]
setblock 238 176 435 minecraft:light[level=12]
setblock 238 176 443 minecraft:light[level=12]
setblock 238 176 451 minecraft:light[level=12]
setblock 238 176 458 minecraft:amethyst_block
setblock 246 176 419 minecraft:light[level=12]
setblock 246 176 427 minecraft:light[level=12]
setblock 246 176 435 minecraft:light[level=12]
setblock 246 176 443 minecraft:light[level=12]
setblock 246 176 451 minecraft:light[level=12]
setblock 251 176 416 minecraft:white_concrete
setblock 254 176 419 minecraft:light[level=12]
setblock 254 176 427 minecraft:light[level=12]
setblock 254 176 435 minecraft:light[level=12]
setblock 254 176 443 minecraft:light[level=12]
setblock 254 176 451 minecraft:light[level=12]
setblock 262 176 419 minecraft:light[level=12]
setblock 262 176 427 minecraft:light[level=12]
setblock 262 176 435 minecraft:light[level=12]
setblock 262 176 443 minecraft:light[level=12]
setblock 262 176 451 minecraft:light[level=12]
fill 262 176 458 262 214 458 minecraft:black_concrete
setblock 270 176 419 minecraft:light[level=12]
setblock 270 176 427 minecraft:light[level=12]
fill 270 176 435 270 185 435 minecraft:black_concrete
setblock 270 176 443 minecraft:light[level=12]
setblock 270 176 451 minecraft:light[level=12]
fill 277 176 428 277 186 428 minecraft:black_concrete
fill 235 177 418 235 226 418 minecraft:black_concrete
setblock 235 177 424 minecraft:white_concrete
fill 238 177 458 238 180 458 minecraft:black_concrete
fill 251 177 416 251 252 416 minecraft:black_concrete
setblock 252 177 416 minecraft:crying_obsidian
fill 270 177 434 270 185 434 minecraft:black_concrete
setblock 270 177 458 minecraft:crying_obsidian
setblock 235 178 419 minecraft:amethyst_block
fill 235 178 424 235 179 424 minecraft:black_concrete
setblock 235 178 446 minecraft:amethyst_block
setblock 245 178 458 minecraft:crying_obsidian
fill 252 178 416 252 215 416 minecraft:black_concrete
fill 269 178 435 269 185 435 minecraft:black_concrete
fill 270 178 458 270 185 458 minecraft:black_concrete
fill 271 178 435 271 185 435 minecraft:black_concrete
setblock 235 179 419 minecraft:black_concrete
fill 235 179 446 235 194 446 minecraft:black_concrete
fill 245 179 458 245 202 458 minecraft:black_concrete
setblock 263 179 458 minecraft:crying_obsidian
fill 269 179 434 269 185 434 minecraft:black_concrete
fill 270 179 436 270 185 436 minecraft:black_concrete
fill 271 179 434 271 185 434 minecraft:black_concrete
setblock 235 180 419 minecraft:amethyst_block
fill 235 180 424 235 182 424 minecraft:purple_concrete
fill 235 180 440 235 182 440 minecraft:purple_concrete
fill 235 180 456 235 182 456 minecraft:purple_concrete
fill 239 180 416 239 182 416 minecraft:purple_concrete
setblock 241 180 458 minecraft:amethyst_block
fill 249 180 458 249 182 458 minecraft:purple_concrete
fill 255 180 416 255 182 416 minecraft:purple_concrete
fill 263 180 458 263 200 458 minecraft:black_concrete
fill 265 180 458 265 182 458 minecraft:purple_concrete
fill 268 180 434 268 185 435 minecraft:black_concrete
fill 269 180 433 271 185 433 minecraft:black_concrete
fill 269 180 436 269 185 436 minecraft:black_concrete
fill 271 180 416 271 182 416 minecraft:purple_concrete
fill 271 180 436 271 185 436 minecraft:black_concrete
fill 272 180 434 272 185 435 minecraft:black_concrete
fill 277 180 426 277 182 426 minecraft:purple_concrete
fill 277 180 442 277 182 442 minecraft:purple_concrete
setblock 277 180 446 minecraft:amethyst_block
fill 235 181 419 235 252 419 minecraft:black_concrete
setblock 238 181 458 minecraft:crying_obsidian
fill 241 181 458 241 217 458 minecraft:black_concrete
setblock 254 181 458 minecraft:crying_obsidian
setblock 262 181 416 minecraft:crying_obsidian
fill 268 181 433 268 185 433 minecraft:black_concrete
fill 268 181 436 268 185 436 minecraft:black_concrete
fill 269 181 437 271 185 437 minecraft:black_concrete
fill 272 181 433 272 185 433 minecraft:black_concrete
fill 272 181 436 272 185 436 minecraft:black_concrete
setblock 277 181 424 minecraft:amethyst_block
fill 277 181 446 277 187 446 minecraft:black_concrete
setblock 235 182 451 minecraft:crying_obsidian
fill 238 182 458 238 215 458 minecraft:black_concrete
fill 245 182 426 246 183 427 minecraft:amethyst_block
setblock 246 182 416 minecraft:crying_obsidian
fill 254 182 458 254 187 458 minecraft:black_concrete
setblock 259 182 458 minecraft:white_concrete
fill 262 182 416 262 188 416 minecraft:black_concrete
fill 267 182 434 267 185 435 minecraft:black_concrete
fill 269 182 432 271 185 432 minecraft:black_concrete
fill 272 182 437 272 185 437 minecraft:black_concrete
fill 273 182 434 273 185 435 minecraft:black_concrete
setblock 277 182 424 minecraft:black_concrete
setblock 277 182 440 minecraft:white_concrete
setblock 235 183 422 minecraft:white_concrete
fill 235 183 424 235 188 424 minecraft:black_concrete
setblock 235 183 434 minecraft:crying_obsidian
fill 235 183 440 235 188 440 minecraft:black_concrete
fill 235 183 451 235 185 451 minecraft:black_concrete
fill 235 183 456 235 188 456 minecraft:black_concrete
fill 239 183 416 239 188 416 minecraft:black_concrete
fill 246 183 416 246 249 416 minecraft:black_concrete
fill 249 183 458 249 188 458 minecraft:black_concrete
fill 255 183 416 255 188 416 minecraft:black_concrete
fill 259 183 458 259 200 458 minecraft:black_concrete
fill 265 183 458 265 188 458 minecraft:black_concrete
fill 267 183 433 267 185 433 minecraft:black_concrete
fill 267 183 436 267 185 436 minecraft:black_concrete
fill 268 183 432 268 185 432 minecraft:black_concrete
fill 268 183 437 268 185 437 minecraft:black_concrete
fill 269 183 438 271 185 438 minecraft:black_concrete
fill 271 183 416 271 188 416 minecraft:black_concrete
fill 272 183 432 272 185 432 minecraft:black_concrete
fill 273 183 433 273 185 433 minecraft:black_concrete
fill 273 183 436 273 185 436 minecraft:black_concrete
setblock 277 183 424 minecraft:crying_obsidian
fill 277 183 426 277 188 426 minecraft:black_concrete
setblock 277 183 430 minecraft:amethyst_block
fill 277 183 440 277 194 440 minecraft:black_concrete
fill 277 183 442 277 188 442 minecraft:black_concrete
setblock 277 183 452 minecraft:amethyst_block
setblock 235 184 421 minecraft:white_concrete
fill 235 184 422 235 219 422 minecraft:black_concrete
fill 235 184 434 235 214 434 minecraft:black_concrete
setblock 235 184 437 minecraft:crying_obsidian
setblock 238 184 419 minecraft:light[level=12]
setblock 238 184 427 minecraft:light[level=12]
setblock 238 184 435 minecraft:light[level=12]
setblock 238 184 443 minecraft:light[level=12]
setblock 238 184 451 minecraft:light[level=12]
setblock 243 184 458 minecraft:crying_obsidian
setblock 246 184 419 minecraft:light[level=12]
setblock 246 184 427 minecraft:light[level=12]
setblock 246 184 435 minecraft:light[level=12]
setblock 246 184 443 minecraft:light[level=12]
setblock 246 184 451 minecraft:light[level=12]
setblock 254 184 419 minecraft:light[level=12]
setblock 254 184 427 minecraft:light[level=12]
setblock 254 184 435 minecraft:light[level=12]
setblock 254 184 443 minecraft:light[level=12]
setblock 254 184 451 minecraft:light[level=12]
setblock 262 184 419 minecraft:light[level=12]
setblock 262 184 427 minecraft:light[level=12]
setblock 262 184 435 minecraft:light[level=12]
setblock 262 184 443 minecraft:light[level=12]
setblock 262 184 451 minecraft:light[level=12]
fill 266 184 435 266 185 435 minecraft:black_concrete
fill 267 184 432 267 185 432 minecraft:black_concrete
fill 267 184 437 267 185 437 minecraft:black_concrete
setblock 267 184 458 minecraft:crying_obsidian
fill 268 184 438 268 185 438 minecraft:black_concrete
fill 269 184 431 271 185 431 minecraft:black_concrete
setblock 270 184 419 minecraft:light[level=12]
setblock 270 184 427 minecraft:light[level=12]
setblock 270 184 443 minecraft:light[level=12]
setblock 270 184 451 minecraft:light[level=12]
fill 272 184 438 272 185 438 minecraft:black_concrete
fill 273 184 432 273 185 432 minecraft:black_concrete
fill 273 184 437 273 185 437 minecraft:black_concrete
fill 274 184 434 274 185 435 minecraft:black_concrete
fill 277 184 424 277 186 424 minecraft:black_concrete
fill 277 184 430 277 223 430 minecraft:black_concrete
fill 277 184 452 277 192 452 minecraft:black_concrete
fill 235 185 421 235 191 421 minecraft:black_concrete
fill 235 185 437 235 229 437 minecraft:black_concrete
fill 243 185 458 243 202 458 minecraft:black_concrete
fill 251 185 448 252 186 449 minecraft:obsidian
fill 266 185 433 266 185 434 minecraft:black_concrete
setblock 266 185 436 minecraft:black_concrete
setblock 267 185 438 minecraft:black_concrete
fill 267 185 458 267 189 458 minecraft:black_concrete
setblock 268 185 416 minecraft:amethyst_block
setblock 268 185 431 minecraft:black_concrete
fill 269 185 439 271 185 439 minecraft:black_concrete
setblock 272 185 431 minecraft:black_concrete
setblock 273 185 438 minecraft:black_concrete
setblock 274 185 433 minecraft:black_concrete
setblock 274 185 436 minecraft:black_concrete
setblock 277 185 451 minecraft:crying_obsidian
setblock 235 186 451 minecraft:crying_obsidian
setblock 264 186 458 minecraft:crying_obsidian
fill 268 186 416 268 197 416 minecraft:black_concrete
setblock 268 186 458 minecraft:crying_obsidian
fill 269 186 434 271 186 435 minecraft:amethyst_block
setblock 270 186 458 minecraft:crying_obsidian
fill 277 186 451 277 228 451 minecraft:black_concrete
setblock 235 187 441 minecraft:amethyst_block
fill 235 187 451 235 249 451 minecraft:black_concrete
fill 264 187 458 264 258 458 minecraft:black_concrete
fill 268 187 458 268 201 458 minecraft:black_concrete
fill 270 187 434 270 188 435 minecraft:amethyst_block
fill 270 187 458 270 232 458 minecraft:black_concrete
setblock 271 187 435 minecraft:amethyst_block
setblock 277 187 424 minecraft:white_concrete
setblock 277 187 428 minecraft:amethyst_block
setblock 277 187 438 minecraft:white_concrete
setblock 235 188 423 minecraft:white_concrete
fill 235 188 441 235 211 441 minecraft:black_concrete
setblock 254 188 458 minecraft:amethyst_block
fill 274 188 452 274 207 452 minecraft:obsidian
fill 277 188 424 277 259 424 minecraft:black_concrete
fill 277 188 428 277 307 428 minecraft:black_concrete
fill 277 188 438 277 197 438 minecraft:black_concrete
setblock 277 188 446 minecraft:crying_obsidian
setblock 277 188 449 minecraft:amethyst_block
fill 235 189 423 235 209 423 minecraft:black_concrete
fill 235 189 424 235 191 424 minecraft:purple_concrete
fill 235 189 440 235 191 440 minecraft:purple_concrete
fill 235 189 456 235 191 456 minecraft:purple_concrete
fill 239 189 416 239 191 416 minecraft:purple_concrete
fill 249 189 458 249 191 458 minecraft:purple_concrete
fill 254 189 458 254 208 458 minecraft:black_concrete
fill 255 189 416 255 191 416 minecraft:purple_concrete
setblock 262 189 416 minecraft:crying_obsidian
fill 265 189 458 265 191 458 minecraft:purple_concrete
setblock 270 189 435 minecraft:amethyst_block
fill 271 189 416 271 191 416 minecraft:purple_concrete
fill 277 189 426 277 191 426 minecraft:purple_concrete
setblock 277 189 437 minecraft:crying_obsidian
fill 277 189 442 277 191 442 minecraft:purple_concrete
fill 277 189 446 277 268 446 minecraft:black_concrete
fill 277 189 449 277 190 449 minecraft:black_concrete
fill 262 190 416 262 211 416 minecraft:black_concrete
fill 263 190 416 263 191 416 minecraft:crying_obsidian
setblock 267 190 458 minecraft:amethyst_block
fill 277 190 437 277 278 437 minecraft:black_concrete
fill 267 191 458 267 291 458 minecraft:black_concrete
setblock 277 191 449 minecraft:amethyst_block
setblock 235 192 421 minecraft:white_concrete
fill 235 192 424 235 197 424 minecraft:black_concrete
fill 235 192 440 235 197 440 minecraft:black_concrete
fill 235 192 456 235 193 456 minecraft:black_concrete
setblock 238 192 419 minecraft:light[level=12]
setblock 238 192 427 minecraft:light[level=12]
setblock 238 192 435 minecraft:light[level=12]
setblock 238 192 443 minecraft:light[level=12]
setblock 238 192 451 minecraft:light[level=12]
fill 239 192 416 239 197 416 minecraft:black_concrete
setblock 246 192 419 minecraft:light[level=12]
setblock 246 192 427 minecraft:light[level=12]
setblock 246 192 435 minecraft:light[level=12]
setblock 246 192 443 minecraft:light[level=12]
setblock 246 192 451 minecraft:light[level=12]
fill 249 192 458 249 197 458 minecraft:black_concrete
fill 253 192 416 253 293 416 minecraft:black_concrete
setblock 254 192 416 minecraft:crying_obsidian
setblock 254 192 419 minecraft:light[level=12]
setblock 254 192 427 minecraft:light[level=12]
setblock 254 192 435 minecraft:light[level=12]
setblock 254 192 443 minecraft:light[level=12]
setblock 254 192 451 minecraft:light[level=12]
fill 255 192 416 255 197 416 minecraft:black_concrete
setblock 262 192 419 minecraft:light[level=12]
setblock 262 192 427 minecraft:light[level=12]
setblock 262 192 435 minecraft:light[level=12]
setblock 262 192 443 minecraft:light[level=12]
setblock 262 192 451 minecraft:light[level=12]
fill 263 192 416 263 201 416 minecraft:black_concrete
fill 265 192 458 265 197 458 minecraft:black_concrete
setblock 270 192 419 minecraft:light[level=12]
setblock 270 192 427 minecraft:light[level=12]
setblock 270 192 435 minecraft:light[level=12]
setblock 270 192 443 minecraft:light[level=12]
setblock 270 192 451 minecraft:light[level=12]
fill 271 192 416 271 197 416 minecraft:black_concrete
fill 277 192 426 277 197 426 minecraft:black_concrete
setblock 277 192 442 minecraft:black_concrete
fill 277 192 449 277 217 449 minecraft:black_concrete
fill 235 193 421 235 200 421 minecraft:black_concrete
setblock 235 193 427 minecraft:crying_obsidian
fill 254 193 416 254 201 416 minecraft:black_concrete
setblock 257 193 416 minecraft:white_concrete
fill 273 193 453 273 208 453 minecraft:obsidian
setblock 277 193 442 minecraft:white_concrete
setblock 277 193 452 minecraft:white_concrete
fill 235 194 427 235 266 427 minecraft:black_concrete
setblock 235 194 456 minecraft:white_concrete
setblock 241 194 416 minecraft:amethyst_block
fill 254 194 426 255 195 427 minecraft:crying_obsidian
fill 257 194 416 257 307 416 minecraft:black_concrete
setblock 277 194 425 minecraft:amethyst_block
fill 277 194 442 277 197 442 minecraft:black_concrete
fill 277 194 452 277 285 452 minecraft:black_concrete
setblock 235 195 446 minecraft:amethyst_block
fill 235 195 456 235 197 456 minecraft:black_concrete
fill 241 195 416 241 211 416 minecraft:black_concrete
setblock 252 195 458 minecraft:white_concrete
fill 277 195 425 277 203 425 minecraft:black_concrete
setblock 277 195 440 minecraft:white_concrete
fill 235 196 446 235 276 446 minecraft:black_concrete
fill 251 196 426 251 197 427 minecraft:obsidian
fill 252 196 458 252 215 458 minecraft:black_concrete
fill 261 196 429 262 197 430 minecraft:obsidian
setblock 277 196 429 minecraft:crying_obsidian
fill 277 196 440 277 201 440 minecraft:black_concrete
setblock 277 196 447 minecraft:crying_obsidian
setblock 235 197 457 minecraft:amethyst_block
fill 277 197 429 277 265 429 minecraft:black_concrete
fill 277 197 447 277 235 447 minecraft:black_concrete
fill 235 198 424 235 200 424 minecraft:purple_concrete
setblock 235 198 430 minecraft:crying_obsidian
fill 235 198 440 235 200 440 minecraft:purple_concrete
fill 235 198 456 235 200 456 minecraft:purple_concrete
fill 235 198 457 235 254 457 minecraft:black_concrete
fill 239 198 416 239 200 416 minecraft:purple_concrete
setblock 242 198 416 minecraft:white_concrete
setblock 248 198 416 minecraft:crying_obsidian
fill 249 198 458 249 200 458 minecraft:purple_concrete
fill 255 198 416 255 200 416 minecraft:purple_concrete
fill 265 198 458 265 200 458 minecraft:purple_concrete
setblock 268 198 416 minecraft:white_concrete
fill 271 198 416 271 200 416 minecraft:purple_concrete
setblock 275 198 416 minecraft:amethyst_block
fill 277 198 426 277 200 426 minecraft:purple_concrete
setblock 277 198 438 minecraft:white_concrete
fill 277 198 442 277 200 442 minecraft:purple_concrete
fill 235 199 430 235 215 430 minecraft:black_concrete
fill 242 199 416 242 281 416 minecraft:black_concrete
fill 248 199 416 248 222 416 minecraft:black_concrete
fill 268 199 416 268 244 416 minecraft:black_concrete
fill 275 199 416 275 232 416 minecraft:black_concrete
fill 277 199 438 277 247 438 minecraft:black_concrete
setblock 238 200 419 minecraft:light[level=12]
setblock 238 200 427 minecraft:light[level=12]
setblock 238 200 435 minecraft:light[level=12]
setblock 238 200 443 minecraft:light[level=12]
setblock 238 200 451 minecraft:light[level=12]
setblock 246 200 419 minecraft:light[level=12]
setblock 246 200 427 minecraft:light[level=12]
setblock 246 200 435 minecraft:light[level=12]
setblock 246 200 443 minecraft:light[level=12]
setblock 246 200 451 minecraft:light[level=12]
setblock 254 200 419 minecraft:light[level=12]
setblock 254 200 427 minecraft:light[level=12]
setblock 254 200 435 minecraft:light[level=12]
setblock 254 200 443 minecraft:light[level=12]
setblock 254 200 451 minecraft:light[level=12]
setblock 262 200 419 minecraft:light[level=12]
setblock 262 200 427 minecraft:light[level=12]
setblock 262 200 435 minecraft:light[level=12]
setblock 262 200 443 minecraft:light[level=12]
setblock 262 200 451 minecraft:light[level=12]
setblock 266 200 458 minecraft:white_concrete
setblock 270 200 419 minecraft:light[level=12]
setblock 270 200 427 minecraft:light[level=12]
setblock 270 200 435 minecraft:light[level=12]
setblock 270 200 443 minecraft:light[level=12]
setblock 270 200 451 minecraft:light[level=12]
setblock 235 201 421 minecraft:amethyst_block
fill 235 201 424 235 206 424 minecraft:black_concrete
fill 235 201 440 235 206 440 minecraft:black_concrete
fill 235 201 456 235 206 456 minecraft:black_concrete
fill 239 201 416 239 206 416 minecraft:black_concrete
setblock 247 201 416 minecraft:amethyst_block
fill 249 201 458 249 206 458 minecraft:black_concrete
fill 255 201 416 255 206 416 minecraft:black_concrete
setblock 259 201 458 minecraft:amethyst_block
setblock 263 201 458 minecraft:white_concrete
fill 265 201 458 266 206 458 minecraft:black_concrete
fill 271 201 416 271 206 416 minecraft:black_concrete
fill 277 201 426 277 206 426 minecraft:black_concrete
fill 277 201 442 277 206 442 minecraft:black_concrete
fill 235 202 421 235 307 421 minecraft:black_concrete
setblock 235 202 448 minecraft:crying_obsidian
fill 241 202 441 242 203 442 minecraft:obsidian
fill 247 202 416 247 305 416 minecraft:black_concrete
fill 247 202 429 248 203 429 minecraft:crying_obsidian
setblock 254 202 416 minecraft:amethyst_block
fill 259 202 458 259 285 458 minecraft:black_concrete
setblock 263 202 416 minecraft:white_concrete
fill 263 202 458 263 212 458 minecraft:black_concrete
fill 266 202 428 267 203 428 minecraft:crying_obsidian
setblock 268 202 458 minecraft:crying_obsidian
setblock 277 202 440 minecraft:amethyst_block
setblock 277 202 445 minecraft:amethyst_block
setblock 235 203 417 minecraft:crying_obsidian
fill 235 203 448 235 204 448 minecraft:black_concrete
setblock 243 203 458 minecraft:white_concrete
fill 245 203 449 246 204 450 minecraft:crying_obsidian
setblock 245 203 458 minecraft:amethyst_block
fill 254 203 416 254 241 416 minecraft:black_concrete
fill 263 203 416 263 250 416 minecraft:black_concrete
fill 268 203 420 268 203 424 minecraft:amethyst_block
fill 268 203 458 268 234 458 minecraft:black_concrete
setblock 277 203 427 minecraft:crying_obsidian
fill 277 203 440 277 278 440 minecraft:black_concrete
fill 277 203 445 277 246 445 minecraft:black_concrete
setblock 277 203 455 minecraft:crying_obsidian
fill 235 204 417 235 207 417 minecraft:black_concrete
setblock 235 204 443 minecraft:white_concrete
setblock 235 204 450 minecraft:crying_obsidian
fill 243 204 458 243 277 458 minecraft:black_concrete
fill 245 204 458 245 289 458 minecraft:black_concrete
fill 267 204 417 269 205 421 minecraft:amethyst_block
fill 268 204 422 268 204 423 minecraft:amethyst_block
setblock 277 204 419 minecraft:crying_obsidian
setblock 277 204 425 minecraft:amethyst_block
fill 277 204 427 277 307 427 minecraft:black_concrete
fill 277 204 455 277 282 455 minecraft:black_concrete
fill 235 205 443 235 307 443 minecraft:black_concrete
setblock 235 205 448 minecraft:white_concrete
setblock 235 205 449 minecraft:amethyst_block
fill 235 205 450 235 269 450 minecraft:black_concrete
setblock 239 205 458 minecraft:white_concrete
fill 266 205 417 266 206 418 minecraft:amethyst_block
setblock 268 205 422 minecraft:amethyst_block
fill 270 205 417 270 206 418 minecraft:amethyst_block
fill 277 205 419 277 286 419 minecraft:black_concrete
fill 277 205 425 277 288 425 minecraft:black_concrete
fill 235 206 448 235 288 449 minecraft:black_concrete
fill 239 206 458 239 307 458 minecraft:black_concrete
fill 267 206 417 269 206 419 minecraft:amethyst_block
setblock 268 206 420 minecraft:amethyst_block
fill 271 206 443 271 216 443 minecraft:obsidian
setblock 277 206 431 minecraft:white_concrete
fill 277 206 432 277 240 432 minecraft:black_concrete
setblock 277 206 434 minecraft:amethyst_block
fill 235 207 424 235 209 424 minecraft:purple_concrete
fill 235 207 440 235 209 440 minecraft:purple_concrete
setblock 235 207 447 minecraft:crying_obsidian
fill 235 207 456 235 209 456 minecraft:purple_concrete
fill 239 207 416 239 209 416 minecraft:purple_concrete
setblock 242 207 458 minecraft:crying_obsidian
fill 249 207 458 249 209 458 minecraft:purple_concrete
fill 255 207 416 255 209 416 minecraft:purple_concrete
setblock 261 207 416 minecraft:white_concrete
fill 265 207 458 265 209 458 minecraft:purple_concrete
fill 266 207 458 266 270 458 minecraft:black_concrete
fill 267 207 417 269 207 418 minecraft:amethyst_block
fill 271 207 416 271 209 416 minecraft:purple_concrete
fill 277 207 426 277 209 426 minecraft:purple_concrete
fill 277 207 431 277 225 431 minecraft:black_concrete
fill 277 207 434 277 278 434 minecraft:black_concrete
fill 277 207 442 277 209 442 minecraft:purple_concrete
setblock 235 208 417 minecraft:crying_obsidian
fill 235 208 447 235 307 447 minecraft:black_concrete
setblock 238 208 419 minecraft:light[level=12]
setblock 238 208 427 minecraft:light[level=12]
setblock 238 208 435 minecraft:light[level=12]
setblock 238 208 443 minecraft:light[level=12]
setblock 238 208 451 minecraft:light[level=12]
fill 242 208 458 242 247 458 minecraft:black_concrete
setblock 246 208 419 minecraft:light[level=12]
setblock 246 208 427 minecraft:light[level=12]
setblock 246 208 435 minecraft:light[level=12]
setblock 246 208 443 minecraft:light[level=12]
setblock 246 208 451 minecraft:light[level=12]
setblock 254 208 419 minecraft:light[level=12]
setblock 254 208 427 minecraft:light[level=12]
setblock 254 208 435 minecraft:light[level=12]
setblock 254 208 443 minecraft:light[level=12]
setblock 254 208 451 minecraft:light[level=12]
fill 261 208 416 261 260 416 minecraft:black_concrete
setblock 262 208 419 minecraft:light[level=12]
setblock 262 208 427 minecraft:light[level=12]
setblock 262 208 435 minecraft:light[level=12]
setblock 262 208 443 minecraft:light[level=12]
setblock 262 208 451 minecraft:light[level=12]
setblock 270 208 419 minecraft:light[level=12]
setblock 270 208 427 minecraft:light[level=12]
setblock 270 208 435 minecraft:light[level=12]
setblock 270 208 443 minecraft:light[level=12]
setblock 270 208 451 minecraft:light[level=12]
setblock 274 208 416 minecraft:amethyst_block
fill 235 209 417 235 252 417 minecraft:black_concrete
setblock 240 209 416 minecraft:amethyst_block
setblock 251 209 458 minecraft:amethyst_block
setblock 254 209 458 minecraft:white_concrete
fill 274 209 416 274 288 416 minecraft:black_concrete
setblock 235 210 423 minecraft:crying_obsidian
fill 235 210 424 235 215 424 minecraft:black_concrete
fill 235 210 440 235 215 440 minecraft:black_concrete
fill 235 210 456 235 215 456 minecraft:black_concrete
fill 236 210 427 236 213 429 minecraft:amethyst_block
fill 237 210 428 237 213 428 minecraft:amethyst_block
fill 239 210 416 240 215 416 minecraft:black_concrete
fill 249 210 458 249 215 458 minecraft:black_concrete
fill 251 210 458 251 307 458 minecraft:black_concrete
fill 254 210 458 254 241 458 minecraft:black_concrete
fill 255 210 416 255 215 416 minecraft:black_concrete
fill 265 210 458 265 215 458 minecraft:black_concrete
fill 271 210 416 271 215 416 minecraft:black_concrete
fill 277 210 426 277 215 426 minecraft:black_concrete
fill 277 210 442 277 215 442 minecraft:black_concrete
fill 235 211 423 235 286 423 minecraft:black_concrete
setblock 235 211 429 minecraft:crying_obsidian
fill 237 211 427 238 212 427 minecraft:amethyst_block
fill 237 211 429 238 212 429 minecraft:amethyst_block
fill 238 211 428 239 212 428 minecraft:amethyst_block
fill 235 212 429 235 217 429 minecraft:black_concrete
setblock 235 212 441 minecraft:amethyst_block
setblock 235 212 444 minecraft:crying_obsidian
setblock 241 212 416 minecraft:amethyst_block
setblock 262 212 416 minecraft:amethyst_block
setblock 277 212 441 minecraft:amethyst_block
fill 235 213 441 235 307 441 minecraft:black_concrete
fill 235 213 444 235 283 444 minecraft:black_concrete
setblock 236 213 416 minecraft:white_concrete
setblock 237 213 416 minecraft:crying_obsidian
fill 241 213 416 241 235 416 minecraft:black_concrete
fill 262 213 416 262 283 416 minecraft:black_concrete
setblock 263 213 458 minecraft:amethyst_block
setblock 271 213 458 minecraft:amethyst_block
fill 277 213 441 277 278 441 minecraft:black_concrete
setblock 277 213 453 minecraft:amethyst_block
fill 236 214 416 236 237 416 minecraft:black_concrete
setblock 237 214 416 minecraft:white_concrete
fill 263 214 458 263 296 458 minecraft:black_concrete
fill 271 214 458 271 248 458 minecraft:black_concrete
fill 277 214 453 277 245 453 minecraft:black_concrete
setblock 235 215 434 minecraft:crying_obsidian
setblock 235 215 436 minecraft:white_concrete
fill 237 215 416 237 225 416 minecraft:black_concrete
setblock 262 215 458 minecraft:white_concrete
setblock 276 215 458 minecraft:crying_obsidian
fill 235 216 424 235 218 424 minecraft:purple_concrete
setblock 235 216 430 minecraft:crying_obsidian
fill 235 216 434 235 303 434 minecraft:black_concrete
fill 235 216 436 235 225 436 minecraft:black_concrete
fill 235 216 440 235 218 440 minecraft:purple_concrete
fill 235 216 456 235 218 456 minecraft:purple_concrete
setblock 238 216 419 minecraft:light[level=12]
setblock 238 216 427 minecraft:light[level=12]
setblock 238 216 435 minecraft:light[level=12]
setblock 238 216 443 minecraft:light[level=12]
setblock 238 216 451 minecraft:light[level=12]
setblock 238 216 458 minecraft:white_concrete
fill 239 216 416 239 218 416 minecraft:purple_concrete
fill 240 216 416 240 268 416 minecraft:black_concrete
setblock 246 216 419 minecraft:light[level=12]
setblock 246 216 427 minecraft:light[level=12]
setblock 246 216 435 minecraft:light[level=12]
setblock 246 216 443 minecraft:light[level=12]
setblock 246 216 451 minecraft:light[level=12]
fill 249 216 458 249 218 458 minecraft:purple_concrete
setblock 250 216 416 minecraft:crying_obsidian
setblock 252 216 416 minecraft:white_concrete
setblock 252 216 458 minecraft:white_concrete
setblock 254 216 419 minecraft:light[level=12]
setblock 254 216 427 minecraft:light[level=12]
setblock 254 216 435 minecraft:light[level=12]
setblock 254 216 443 minecraft:light[level=12]
setblock 254 216 451 minecraft:light[level=12]
fill 255 216 416 255 218 416 minecraft:purple_concrete
setblock 262 216 419 minecraft:light[level=12]
setblock 262 216 427 minecraft:light[level=12]
setblock 262 216 435 minecraft:light[level=12]
setblock 262 216 443 minecraft:light[level=12]
setblock 262 216 451 minecraft:light[level=12]
setblock 262 216 458 minecraft:amethyst_block
fill 265 216 458 265 218 458 minecraft:purple_concrete
setblock 270 216 419 minecraft:light[level=12]
setblock 270 216 427 minecraft:light[level=12]
setblock 270 216 435 minecraft:light[level=12]
setblock 270 216 443 minecraft:light[level=12]
setblock 270 216 451 minecraft:light[level=12]
fill 271 216 416 271 218 416 minecraft:purple_concrete
fill 276 216 458 276 226 458 minecraft:black_concrete
fill 277 216 426 277 218 426 minecraft:purple_concrete
fill 277 216 442 277 218 442 minecraft:purple_concrete
fill 235 217 430 235 298 430 minecraft:black_concrete
setblock 236 217 458 minecraft:amethyst_block
fill 238 217 458 238 218 458 minecraft:black_concrete
fill 250 217 416 250 307 416 minecraft:black_concrete
fill 252 217 416 252 240 416 minecraft:black_concrete
fill 252 217 458 252 267 458 minecraft:black_concrete
fill 262 217 458 262 307 458 minecraft:black_concrete
setblock 235 218 429 minecraft:white_concrete
setblock 235 218 445 minecraft:white_concrete
fill 236 218 458 236 256 458 minecraft:black_concrete
setblock 241 218 458 minecraft:crying_obsidian
fill 253 218 456 255 221 456 minecraft:amethyst_block
fill 254 218 454 254 220 455 minecraft:amethyst_block
fill 254 218 457 254 221 457 minecraft:amethyst_block
setblock 255 218 458 minecraft:amethyst_block
setblock 264 218 416 minecraft:white_concrete
setblock 277 218 449 minecraft:amethyst_block
fill 235 219 424 235 233 424 minecraft:black_concrete
fill 235 219 429 235 307 429 minecraft:black_concrete
fill 235 219 440 235 233 440 minecraft:black_concrete
fill 235 219 445 235 265 445 minecraft:black_concrete
fill 235 219 456 235 233 456 minecraft:black_concrete
setblock 238 219 458 minecraft:amethyst_block
fill 239 219 416 239 233 416 minecraft:black_concrete
fill 241 219 458 241 250 458 minecraft:black_concrete
fill 249 219 458 249 233 458 minecraft:black_concrete
fill 253 219 453 253 220 455 minecraft:amethyst_block
fill 253 219 457 253 220 457 minecraft:amethyst_block
fill 254 219 451 254 220 453 minecraft:amethyst_block
fill 255 219 416 255 226 416 minecraft:black_concrete
fill 255 219 453 255 220 455 minecraft:amethyst_block
fill 255 219 457 255 220 457 minecraft:amethyst_block
fill 255 219 458 255 271 458 minecraft:black_concrete
fill 264 219 416 264 252 416 minecraft:black_concrete
fill 265 219 458 265 233 458 minecraft:black_concrete
fill 271 219 416 271 233 416 minecraft:black_concrete
fill 277 219 426 277 233 426 minecraft:black_concrete
fill 277 219 442 277 233 442 minecraft:black_concrete
fill 277 219 449 277 242 449 minecraft:black_concrete
setblock 235 220 422 minecraft:amethyst_block
fill 238 220 458 238 307 458 minecraft:black_concrete
setblock 277 220 433 minecraft:crying_obsidian
fill 235 221 422 235 241 422 minecraft:black_concrete
setblock 254 221 455 minecraft:amethyst_block
fill 277 221 433 277 253 433 minecraft:black_concrete
setblock 272 222 416 minecraft:amethyst_block
setblock 277 222 457 minecraft:amethyst_block
setblock 248 223 416 minecraft:crying_obsidian
setblock 257 223 458 minecraft:crying_obsidian
fill 272 223 416 272 233 416 minecraft:black_concrete
fill 277 223 457 277 224 457 minecraft:black_concrete
setblock 238 224 419 minecraft:light[level=12]
setblock 238 224 427 minecraft:light[level=12]
setblock 238 224 435 minecraft:light[level=12]
setblock 238 224 443 minecraft:light[level=12]
setblock 238 224 451 minecraft:light[level=12]
setblock 246 224 419 minecraft:light[level=12]
setblock 246 224 427 minecraft:light[level=12]
setblock 246 224 435 minecraft:light[level=12]
setblock 246 224 443 minecraft:light[level=12]
setblock 246 224 451 minecraft:light[level=12]
fill 248 224 416 248 307 416 minecraft:black_concrete
setblock 254 224 419 minecraft:light[level=12]
setblock 254 224 427 minecraft:light[level=12]
setblock 254 224 435 minecraft:light[level=12]
setblock 254 224 443 minecraft:light[level=12]
setblock 254 224 451 minecraft:light[level=12]
fill 257 224 458 257 238 458 minecraft:black_concrete
setblock 258 224 416 minecraft:white_concrete
setblock 262 224 419 minecraft:light[level=12]
setblock 262 224 427 minecraft:light[level=12]
setblock 262 224 435 minecraft:light[level=12]
setblock 262 224 443 minecraft:light[level=12]
setblock 262 224 451 minecraft:light[level=12]
setblock 270 224 419 minecraft:light[level=12]
setblock 270 224 427 minecraft:light[level=12]
setblock 270 224 435 minecraft:light[level=12]
setblock 270 224 443 minecraft:light[level=12]
setblock 270 224 451 minecraft:light[level=12]
setblock 277 224 430 minecraft:crying_obsidian
fill 258 225 416 258 259 416 minecraft:black_concrete
fill 277 225 430 277 278 430 minecraft:black_concrete
setblock 277 225 457 minecraft:amethyst_block
setblock 235 226 436 minecraft:crying_obsidian
setblock 237 226 416 minecraft:amethyst_block
setblock 260 226 458 minecraft:amethyst_block
setblock 266 226 416 minecraft:crying_obsidian
setblock 272 226 458 minecraft:white_concrete
setblock 277 226 431 minecraft:crying_obsidian
fill 277 226 457 277 244 457 minecraft:black_concrete
setblock 235 227 418 minecraft:amethyst_block
setblock 235 227 428 minecraft:amethyst_block
fill 235 227 436 235 236 436 minecraft:black_concrete
fill 237 227 416 237 307 416 minecraft:black_concrete
setblock 255 227 416 minecraft:amethyst_block
fill 260 227 458 260 278 458 minecraft:black_concrete
setblock 266 227 416 minecraft:black_concrete
fill 272 227 458 272 300 458 minecraft:black_concrete
setblock 276 227 458 minecraft:white_concrete
fill 277 227 431 277 278 431 minecraft:black_concrete
fill 235 228 418 235 235 418 minecraft:black_concrete
fill 235 228 428 235 305 428 minecraft:black_concrete
fill 255 228 416 255 233 416 minecraft:black_concrete
setblock 266 228 416 minecraft:white_concrete
fill 276 228 458 276 245 458 minecraft:black_concrete
setblock 245 229 416 minecraft:crying_obsidian
fill 248 229 434 248 231 436 minecraft:amethyst_block
fill 249 229 431 249 231 434 minecraft:amethyst_block
fill 249 229 435 254 229 435 minecraft:black_concrete
fill 249 229 436 249 231 439 minecraft:amethyst_block
fill 250 229 430 250 231 431 minecraft:amethyst_block
fill 250 229 432 255 229 434 minecraft:black_concrete
fill 250 229 436 255 229 438 minecraft:black_concrete
fill 250 229 439 250 231 440 minecraft:amethyst_block
fill 251 229 429 251 231 429 minecraft:amethyst_block
fill 251 229 430 263 230 431 minecraft:black_concrete
fill 251 229 439 263 230 440 minecraft:black_concrete
fill 251 229 441 251 231 441 minecraft:amethyst_block
fill 252 229 428 253 231 428 minecraft:amethyst_block
fill 252 229 429 262 230 429 minecraft:black_concrete
fill 252 229 441 262 230 441 minecraft:black_concrete
fill 252 229 442 253 231 442 minecraft:amethyst_block
fill 253 229 427 256 231 427 minecraft:amethyst_block
fill 253 229 443 256 231 443 minecraft:amethyst_block
fill 254 229 428 260 230 428 minecraft:black_concrete
fill 254 229 442 260 230 442 minecraft:black_concrete
fill 256 229 426 258 231 426 minecraft:amethyst_block
fill 256 229 432 256 229 433 minecraft:black_concrete
fill 256 229 437 256 229 438 minecraft:black_concrete
fill 256 229 444 258 231 444 minecraft:amethyst_block
fill 257 229 427 257 230 427 minecraft:black_concrete
fill 257 229 432 264 229 432 minecraft:black_concrete
fill 257 229 438 264 229 438 minecraft:black_concrete
fill 257 229 443 257 230 443 minecraft:black_concrete
fill 258 229 427 261 231 427 minecraft:amethyst_block
fill 258 229 433 264 229 433 minecraft:black_concrete
fill 258 229 437 264 229 437 minecraft:black_concrete
fill 258 229 443 261 231 443 minecraft:amethyst_block
fill 259 229 434 264 229 434 minecraft:black_concrete
fill 259 229 436 264 229 436 minecraft:black_concrete
fill 260 229 435 265 229 435 minecraft:black_concrete
fill 261 229 428 262 231 428 minecraft:amethyst_block
fill 261 229 442 262 231 442 minecraft:amethyst_block
fill 263 229 429 263 231 429 minecraft:amethyst_block
fill 263 229 441 263 231 441 minecraft:amethyst_block
fill 264 229 430 264 231 431 minecraft:amethyst_block
fill 264 229 439 264 231 440 minecraft:amethyst_block
fill 265 229 431 265 231 434 minecraft:amethyst_block
fill 265 229 436 265 231 439 minecraft:amethyst_block
fill 266 229 416 266 307 416 minecraft:black_concrete
fill 266 229 434 266 231 436 minecraft:amethyst_block
setblock 277 229 436 minecraft:amethyst_block
setblock 277 229 448 minecraft:white_concrete
setblock 277 229 451 minecraft:amethyst_block
setblock 235 230 437 minecraft:white_concrete
fill 236 230 417 247 230 457 minecraft:obsidian
fill 245 230 416 245 232 416 minecraft:black_concrete
fill 248 230 417 248 230 431 minecraft:obsidian
fill 248 230 432 248 230 433 minecraft:amethyst_block
fill 248 230 437 248 230 438 minecraft:amethyst_block
fill 248 230 439 248 230 457 minecraft:obsidian
fill 249 230 417 249 230 429 minecraft:obsidian
setblock 249 230 430 minecraft:amethyst_block
fill 249 230 435 253 230 435 minecraft:black_concrete
setblock 249 230 440 minecraft:amethyst_block
fill 249 230 441 249 230 457 minecraft:obsidian
fill 250 230 417 250 230 428 minecraft:obsidian
setblock 250 230 429 minecraft:amethyst_block
fill 250 230 432 253 230 434 minecraft:black_concrete
fill 250 230 436 253 230 438 minecraft:black_concrete
setblock 250 230 441 minecraft:amethyst_block
fill 250 230 442 250 230 457 minecraft:obsidian
fill 251 230 417 251 230 427 minecraft:obsidian
setblock 251 230 428 minecraft:amethyst_block
setblock 251 230 442 minecraft:amethyst_block
fill 251 230 443 251 230 457 minecraft:obsidian
fill 252 230 417 253 230 426 minecraft:obsidian
setblock 252 230 427 minecraft:amethyst_block
setblock 252 230 443 minecraft:amethyst_block
fill 252 230 444 253 230 457 minecraft:obsidian
fill 254 230 417 276 230 425 minecraft:obsidian
fill 254 230 426 255 230 426 minecraft:amethyst_block
fill 254 230 432 254 230 433 minecraft:black_concrete
fill 254 230 434 254 230 436 minecraft:crying_obsidian
fill 254 230 437 254 230 438 minecraft:black_concrete
fill 254 230 444 255 230 444 minecraft:amethyst_block
fill 254 230 445 276 230 457 minecraft:obsidian
setblock 255 230 432 minecraft:black_concrete
fill 255 230 433 255 230 434 minecraft:crying_obsidian
fill 255 230 436 255 230 437 minecraft:crying_obsidian
setblock 255 230 438 minecraft:black_concrete
fill 256 230 432 256 230 433 minecraft:crying_obsidian
fill 256 230 437 256 230 438 minecraft:crying_obsidian
fill 257 230 432 258 230 432 minecraft:crying_obsidian
fill 257 230 438 258 230 438 minecraft:crying_obsidian
fill 258 230 433 259 230 433 minecraft:crying_obsidian
fill 258 230 437 259 230 437 minecraft:crying_obsidian
fill 259 230 426 260 230 426 minecraft:amethyst_block
fill 259 230 432 264 230 432 minecraft:black_concrete
fill 259 230 434 260 230 434 minecraft:crying_obsidian
fill 259 230 436 260 230 436 minecraft:crying_obsidian
fill 259 230 438 264 230 438 minecraft:black_concrete
fill 259 230 444 260 230 444 minecraft:amethyst_block
fill 260 230 433 264 230 433 minecraft:black_concrete
setblock 260 230 435 minecraft:crying_obsidian
fill 260 230 437 264 230 437 minecraft:black_concrete
fill 261 230 426 276 230 426 minecraft:obsidian
fill 261 230 434 264 230 436 minecraft:black_concrete
fill 261 230 444 276 230 444 minecraft:obsidian
setblock 262 230 427 minecraft:amethyst_block
setblock 262 230 443 minecraft:amethyst_block
fill 263 230 427 276 230 427 minecraft:obsidian
setblock 263 230 428 minecraft:amethyst_block
setblock 263 230 442 minecraft:amethyst_block
fill 263 230 443 276 230 443 minecraft:obsidian
fill 264 230 428 276 230 428 minecraft:obsidian
setblock 264 230 429 minecraft:amethyst_block
setblock 264 230 441 minecraft:amethyst_block
fill 264 230 442 276 230 442 minecraft:obsidian
setblock 265 230 416 minecraft:amethyst_block
fill 265 230 429 276 230 429 minecraft:obsidian
setblock 265 230 430 minecraft:amethyst_block
setblock 265 230 435 minecraft:black_concrete
setblock 265 230 440 minecraft:amethyst_block
fill 265 230 441 276 230 441 minecraft:obsidian
fill 266 230 430 276 230 431 minecraft:obsidian
fill 266 230 432 266 230 433 minecraft:amethyst_block
fill 266 230 437 266 230 438 minecraft:amethyst_block
fill 266 230 439 276 230 440 minecraft:obsidian
fill 267 230 432 276 230 438 minecraft:obsidian
fill 277 230 436 277 239 436 minecraft:black_concrete
fill 277 230 448 277 240 448 minecraft:black_concrete
fill 277 230 451 277 248 451 minecraft:black_concrete
fill 235 231 437 235 236 437 minecraft:black_concrete
setblock 237 231 458 minecraft:white_concrete
fill 249 231 435 250 231 435 minecraft:amethyst_block
fill 250 231 432 250 231 434 minecraft:amethyst_block
fill 250 231 436 250 231 438 minecraft:amethyst_block
fill 251 231 430 251 231 431 minecraft:amethyst_block
fill 251 231 439 251 231 440 minecraft:amethyst_block
fill 252 231 429 252 231 430 minecraft:amethyst_block
fill 252 231 440 252 231 441 minecraft:amethyst_block
setblock 253 231 429 minecraft:amethyst_block
setblock 253 231 441 minecraft:amethyst_block
fill 254 231 428 260 231 428 minecraft:amethyst_block
fill 254 231 442 260 231 442 minecraft:amethyst_block
setblock 257 231 427 minecraft:amethyst_block
setblock 257 231 443 minecraft:amethyst_block
fill 261 231 429 262 231 429 minecraft:amethyst_block
fill 261 231 441 262 231 441 minecraft:amethyst_block
fill 262 231 430 263 231 430 minecraft:amethyst_block
fill 262 231 440 263 231 440 minecraft:amethyst_block
setblock 263 231 431 minecraft:amethyst_block
setblock 263 231 439 minecraft:amethyst_block
fill 264 231 432 264 231 438 minecraft:amethyst_block
fill 265 231 416 265 234 416 minecraft:black_concrete
setblock 265 231 435 minecraft:amethyst_block
setblock 277 231 444 minecraft:white_concrete
fill 237 232 458 237 234 458 minecraft:black_concrete
setblock 238 232 419 minecraft:light[level=12]
setblock 238 232 427 minecraft:light[level=12]
setblock 238 232 435 minecraft:light[level=12]
setblock 238 232 443 minecraft:light[level=12]
setblock 238 232 451 minecraft:light[level=12]
setblock 246 232 419 minecraft:light[level=12]
setblock 246 232 427 minecraft:light[level=12]
setblock 246 232 435 minecraft:light[level=12]
setblock 246 232 443 minecraft:light[level=12]
setblock 246 232 451 minecraft:light[level=12]
setblock 254 232 419 minecraft:light[level=12]
setblock 254 232 427 minecraft:light[level=12]
setblock 254 232 435 minecraft:light[level=12]
setblock 254 232 443 minecraft:light[level=12]
setblock 254 232 451 minecraft:light[level=12]
setblock 262 232 419 minecraft:light[level=12]
setblock 262 232 427 minecraft:light[level=12]
setblock 262 232 435 minecraft:light[level=12]
setblock 262 232 443 minecraft:light[level=12]
setblock 262 232 451 minecraft:light[level=12]
setblock 270 232 419 minecraft:light[level=12]
setblock 270 232 427 minecraft:light[level=12]
setblock 270 232 435 minecraft:light[level=12]
setblock 270 232 443 minecraft:light[level=12]
setblock 270 232 451 minecraft:light[level=12]
fill 277 232 444 277 243 444 minecraft:black_concrete
setblock 235 233 425 minecraft:amethyst_block
setblock 245 233 416 minecraft:crying_obsidian
setblock 248 233 458 minecraft:white_concrete
setblock 270 233 458 minecraft:crying_obsidian
setblock 275 233 416 minecraft:amethyst_block
fill 235 234 424 235 236 424 minecraft:purple_concrete
fill 235 234 425 235 256 425 minecraft:black_concrete
fill 235 234 440 235 236 440 minecraft:purple_concrete
fill 235 234 456 235 236 456 minecraft:purple_concrete
fill 239 234 416 239 236 416 minecraft:purple_concrete
fill 245 234 416 245 255 416 minecraft:black_concrete
fill 248 234 458 248 243 458 minecraft:black_concrete
fill 249 234 458 249 236 458 minecraft:purple_concrete
fill 255 234 416 255 236 416 minecraft:purple_concrete
fill 265 234 458 265 236 458 minecraft:purple_concrete
fill 270 234 458 270 307 458 minecraft:black_concrete
fill 271 234 416 271 236 416 minecraft:purple_concrete
fill 272 234 416 272 235 416 minecraft:white_concrete
fill 275 234 416 275 307 416 minecraft:black_concrete
fill 277 234 426 277 236 426 minecraft:purple_concrete
fill 277 234 442 277 236 442 minecraft:purple_concrete
setblock 237 235 458 minecraft:white_concrete
setblock 265 235 416 minecraft:amethyst_block
setblock 268 235 458 minecraft:white_concrete
setblock 269 235 416 minecraft:crying_obsidian
setblock 235 236 418 minecraft:crying_obsidian
setblock 235 236 442 minecraft:white_concrete
fill 237 236 458 237 261 458 minecraft:black_concrete
setblock 241 236 416 minecraft:crying_obsidian
fill 265 236 416 265 258 416 minecraft:black_concrete
fill 268 236 458 268 307 458 minecraft:black_concrete
fill 269 236 416 269 284 416 minecraft:black_concrete
fill 272 236 416 272 240 416 minecraft:black_concrete
fill 272 236 456 274 239 456 minecraft:amethyst_block
fill 273 236 454 273 238 455 minecraft:amethyst_block
fill 273 236 457 273 239 457 minecraft:amethyst_block
setblock 277 236 447 minecraft:amethyst_block
fill 235 237 418 235 297 418 minecraft:black_concrete
fill 235 237 424 235 242 424 minecraft:black_concrete
fill 235 237 436 235 237 437 minecraft:amethyst_block
fill 235 237 440 235 242 440 minecraft:black_concrete
fill 235 237 442 235 300 442 minecraft:black_concrete
fill 235 237 456 235 242 456 minecraft:black_concrete
fill 239 237 416 239 242 416 minecraft:black_concrete
fill 241 237 416 241 261 416 minecraft:black_concrete
fill 249 237 458 249 242 458 minecraft:black_concrete
fill 255 237 416 255 239 416 minecraft:black_concrete
fill 265 237 458 265 242 458 minecraft:black_concrete
fill 271 237 416 271 242 416 minecraft:black_concrete
fill 272 237 452 272 237 455 minecraft:amethyst_block
fill 272 237 457 272 238 457 minecraft:amethyst_block
fill 273 237 450 273 237 453 minecraft:amethyst_block
fill 274 237 452 274 237 455 minecraft:amethyst_block
fill 274 237 457 274 238 457 minecraft:amethyst_block
fill 277 237 426 277 242 426 minecraft:black_concrete
fill 277 237 442 277 242 442 minecraft:black_concrete
setblock 277 237 447 minecraft:black_concrete
fill 235 238 436 235 271 437 minecraft:black_concrete
setblock 236 238 416 minecraft:amethyst_block
fill 264 238 436 265 239 437 minecraft:crying_obsidian
fill 272 238 453 272 238 455 minecraft:amethyst_block
fill 273 238 451 273 238 453 minecraft:amethyst_block
fill 274 238 453 274 238 455 minecraft:amethyst_block
setblock 277 238 447 minecraft:white_concrete
fill 236 239 416 236 286 416 minecraft:black_concrete
setblock 257 239 458 minecraft:crying_obsidian
setblock 260 239 416 minecraft:amethyst_block
setblock 273 239 455 minecraft:amethyst_block
setblock 276 239 416 minecraft:crying_obsidian
fill 277 239 447 277 307 447 minecraft:black_concrete
setblock 238 240 419 minecraft:light[level=12]
setblock 238 240 427 minecraft:light[level=12]
setblock 238 240 435 minecraft:light[level=12]
setblock 238 240 443 minecraft:light[level=12]
setblock 238 240 451 minecraft:light[level=12]
setblock 246 240 419 minecraft:light[level=12]
setblock 246 240 427 minecraft:light[level=12]
setblock 246 240 435 minecraft:light[level=12]
setblock 246 240 443 minecraft:light[level=12]
setblock 246 240 451 minecraft:light[level=12]
setblock 254 240 419 minecraft:light[level=12]
setblock 254 240 427 minecraft:light[level=12]
setblock 254 240 435 minecraft:light[level=12]
setblock 254 240 443 minecraft:light[level=12]
setblock 254 240 451 minecraft:light[level=12]
setblock 255 240 416 minecraft:white_concrete
fill 257 240 458 257 301 458 minecraft:black_concrete
fill 260 240 416 260 280 416 minecraft:black_concrete
setblock 262 240 419 minecraft:light[level=12]
setblock 262 240 427 minecraft:light[level=12]
setblock 262 240 435 minecraft:light[level=12]
setblock 262 240 443 minecraft:light[level=12]
setblock 262 240 451 minecraft:light[level=12]
setblock 270 240 419 minecraft:light[level=12]
setblock 270 240 427 minecraft:light[level=12]
setblock 270 240 435 minecraft:light[level=12]
setblock 270 240 443 minecraft:light[level=12]
setblock 270 240 451 minecraft:light[level=12]
fill 276 240 416 276 292 416 minecraft:black_concrete
setblock 277 240 436 minecraft:crying_obsidian
setblock 252 241 416 minecraft:crying_obsidian
setblock 253 241 458 minecraft:amethyst_block
fill 255 241 416 255 242 416 minecraft:black_concrete
setblock 272 241 416 minecraft:crying_obsidian
setblock 277 241 432 minecraft:white_concrete
fill 277 241 436 277 278 436 minecraft:black_concrete
setblock 277 241 448 minecraft:amethyst_block
setblock 235 242 422 minecraft:amethyst_block
setblock 240 242 458 minecraft:amethyst_block
fill 245 242 422 245 254 422 minecraft:obsidian
fill 252 242 416 252 249 416 minecraft:black_concrete
fill 253 242 458 253 307 458 minecraft:black_concrete
setblock 254 242 416 minecraft:crying_obsidian
setblock 254 242 458 minecraft:crying_obsidian
fill 272 242 416 272 273 416 minecraft:black_concrete
fill 277 242 432 277 278 432 minecraft:black_concrete
fill 277 242 448 277 286 448 minecraft:black_concrete
fill 235 243 422 235 282 422 minecraft:black_concrete
fill 235 243 424 235 245 424 minecraft:purple_concrete
fill 235 243 440 235 245 440 minecraft:purple_concrete
fill 235 243 456 235 245 456 minecraft:purple_concrete
fill 239 243 416 239 245 416 minecraft:purple_concrete
fill 240 243 458 240 270 458 minecraft:black_concrete
fill 249 243 458 249 245 458 minecraft:purple_concrete
fill 254 243 416 254 248 416 minecraft:black_concrete
fill 254 243 458 254 307 458 minecraft:black_concrete
fill 255 243 416 255 245 416 minecraft:purple_concrete
fill 265 243 458 265 245 458 minecraft:purple_concrete
fill 269 243 435 270 244 435 minecraft:obsidian
fill 271 243 416 271 245 416 minecraft:purple_concrete
setblock 277 243 418 minecraft:amethyst_block
fill 277 243 426 277 245 426 minecraft:purple_concrete
fill 277 243 442 277 245 442 minecraft:purple_concrete
setblock 277 243 449 minecraft:amethyst_block
setblock 248 244 458 minecraft:amethyst_block
fill 277 244 418 277 253 418 minecraft:black_concrete
setblock 277 244 422 minecraft:white_concrete
setblock 277 244 444 minecraft:crying_obsidian
setblock 277 244 449 minecraft:crying_obsidian
setblock 235 245 454 minecraft:white_concrete
fill 248 245 458 248 290 458 minecraft:black_concrete
setblock 267 245 416 minecraft:amethyst_block
fill 267 245 450 267 257 450 minecraft:obsidian
setblock 268 245 416 minecraft:crying_obsidian
fill 275 245 451 275 248 451 minecraft:amethyst_block
fill 277 245 422 277 307 422 minecraft:black_concrete
fill 277 245 444 277 278 444 minecraft:black_concrete
fill 277 245 449 277 264 449 minecraft:black_concrete
setblock 277 245 457 minecraft:white_concrete
fill 235 246 424 235 251 424 minecraft:black_concrete
setblock 235 246 440 minecraft:black_concrete
fill 235 246 454 235 307 454 minecraft:black_concrete
fill 235 246 456 235 251 456 minecraft:black_concrete
fill 239 246 416 239 251 416 minecraft:black_concrete
setblock 249 246 458 minecraft:black_concrete
fill 255 246 416 255 251 416 minecraft:black_concrete
fill 265 246 458 265 251 458 minecraft:black_concrete
fill 267 246 416 268 251 416 minecraft:black_concrete
fill 271 246 416 271 251 416 minecraft:black_concrete
fill 274 246 450 274 248 452 minecraft:amethyst_block
fill 275 246 450 276 247 450 minecraft:amethyst_block
fill 275 246 452 276 247 452 minecraft:amethyst_block
fill 276 246 451 276 247 451 minecraft:amethyst_block
setblock 276 246 458 minecraft:amethyst_block
fill 277 246 426 277 251 426 minecraft:black_concrete
setblock 277 246 435 minecraft:crying_obsidian
fill 277 246 442 277 251 442 minecraft:black_concrete
setblock 277 246 453 minecraft:amethyst_block
fill 277 246 457 277 269 457 minecraft:black_concrete
setblock 235 247 440 minecraft:crying_obsidian
setblock 249 247 458 minecraft:white_concrete
fill 273 247 451 273 249 451 minecraft:amethyst_block
fill 276 247 458 276 307 458 minecraft:black_concrete
fill 277 247 435 277 278 435 minecraft:black_concrete
setblock 277 247 445 minecraft:amethyst_block
fill 277 247 453 277 307 453 minecraft:black_concrete
setblock 235 248 438 minecraft:amethyst_block
fill 235 248 440 235 251 440 minecraft:black_concrete
setblock 238 248 419 minecraft:light[level=12]
setblock 238 248 427 minecraft:light[level=12]
setblock 238 248 435 minecraft:light[level=12]
setblock 238 248 443 minecraft:light[level=12]
setblock 238 248 451 minecraft:light[level=12]
setblock 242 248 458 minecraft:crying_obsidian
setblock 246 248 419 minecraft:light[level=12]
setblock 246 248 427 minecraft:light[level=12]
setblock 246 248 435 minecraft:light[level=12]
setblock 246 248 443 minecraft:light[level=12]
setblock 246 248 451 minecraft:light[level=12]
fill 249 248 458 249 251 458 minecraft:black_concrete
setblock 254 248 419 minecraft:light[level=12]
setblock 254 248 427 minecraft:light[level=12]
setblock 254 248 435 minecraft:light[level=12]
setblock 254 248 443 minecraft:light[level=12]
setblock 254 248 451 minecraft:light[level=12]
setblock 262 248 419 minecraft:light[level=12]
setblock 262 248 427 minecraft:light[level=12]
setblock 262 248 435 minecraft:light[level=12]
setblock 262 248 443 minecraft:light[level=12]
setblock 262 248 451 minecraft:light[level=12]
setblock 270 248 419 minecraft:light[level=12]
setblock 270 248 427 minecraft:light[level=12]
setblock 270 248 435 minecraft:light[level=12]
setblock 270 248 443 minecraft:light[level=12]
setblock 270 248 451 minecraft:light[level=12]
fill 272 248 451 272 249 451 minecraft:amethyst_block
setblock 273 248 450 minecraft:amethyst_block
setblock 273 248 452 minecraft:amethyst_block
setblock 277 248 438 minecraft:crying_obsidian
fill 277 248 445 277 278 445 minecraft:black_concrete
fill 235 249 438 235 271 438 minecraft:black_concrete
fill 242 249 458 242 307 458 minecraft:black_concrete
setblock 254 249 416 minecraft:crying_obsidian
fill 271 249 451 271 250 451 minecraft:amethyst_block
setblock 271 249 458 minecraft:amethyst_block
fill 277 249 438 277 278 438 minecraft:black_concrete
setblock 277 249 451 minecraft:amethyst_block
setblock 235 250 451 minecraft:white_concrete
setblock 246 250 416 minecraft:white_concrete
setblock 252 250 416 minecraft:amethyst_block
fill 254 250 416 254 307 416 minecraft:black_concrete
fill 271 250 458 271 307 458 minecraft:black_concrete
fill 277 250 451 277 287 451 minecraft:black_concrete
fill 235 251 451 235 268 451 minecraft:black_concrete
setblock 241 251 458 minecraft:crying_obsidian
fill 243 251 434 243 252 435 minecraft:amethyst_block
fill 246 251 416 246 307 416 minecraft:black_concrete
fill 252 251 416 252 307 416 minecraft:black_concrete
setblock 263 251 416 minecraft:white_concrete
fill 235 252 424 235 254 424 minecraft:purple_concrete
fill 235 252 440 235 254 440 minecraft:purple_concrete
fill 235 252 456 235 254 456 minecraft:purple_concrete
fill 239 252 416 239 254 416 minecraft:purple_concrete
fill 241 252 458 241 255 458 minecraft:black_concrete
fill 249 252 458 249 254 458 minecraft:purple_concrete
fill 255 252 416 255 254 416 minecraft:purple_concrete
fill 263 252 416 263 305 416 minecraft:black_concrete
fill 265 252 458 265 254 458 minecraft:purple_concrete
fill 267 252 416 267 274 416 minecraft:black_concrete
setblock 268 252 416 minecraft:amethyst_block
fill 271 252 416 271 254 416 minecraft:purple_concrete
fill 277 252 426 277 254 426 minecraft:purple_concrete
fill 277 252 442 277 254 442 minecraft:purple_concrete
setblock 235 253 417 minecraft:amethyst_block
setblock 235 253 419 minecraft:amethyst_block
setblock 251 253 416 minecraft:amethyst_block
setblock 264 253 416 minecraft:crying_obsidian
fill 268 253 416 268 288 416 minecraft:black_concrete
fill 235 254 417 235 300 417 minecraft:black_concrete
fill 235 254 419 235 307 419 minecraft:black_concrete
fill 251 254 416 251 279 416 minecraft:black_concrete
fill 264 254 416 264 307 416 minecraft:black_concrete
setblock 277 254 418 minecraft:amethyst_block
setblock 277 254 433 minecraft:crying_obsidian
fill 235 255 424 235 260 424 minecraft:black_concrete
fill 235 255 440 235 260 440 minecraft:black_concrete
fill 235 255 456 235 260 456 minecraft:black_concrete
setblock 235 255 457 minecraft:white_concrete
fill 239 255 416 239 260 416 minecraft:black_concrete
fill 249 255 458 249 260 458 minecraft:black_concrete
setblock 250 255 458 minecraft:amethyst_block
fill 255 255 416 255 260 416 minecraft:black_concrete
fill 265 255 458 265 260 458 minecraft:black_concrete
fill 271 255 416 271 260 416 minecraft:black_concrete
fill 277 255 418 277 307 418 minecraft:black_concrete
fill 277 255 426 277 260 426 minecraft:black_concrete
fill 277 255 433 277 278 433 minecraft:black_concrete
fill 277 255 442 277 260 442 minecraft:black_concrete
fill 235 256 457 235 307 457 minecraft:black_concrete
setblock 238 256 419 minecraft:light[level=12]
setblock 238 256 427 minecraft:light[level=12]
setblock 238 256 435 minecraft:light[level=12]
setblock 238 256 443 minecraft:light[level=12]
setblock 238 256 451 minecraft:light[level=12]
setblock 241 256 458 minecraft:crying_obsidian
setblock 245 256 416 minecraft:crying_obsidian
setblock 246 256 419 minecraft:light[level=12]
setblock 246 256 427 minecraft:light[level=12]
setblock 246 256 435 minecraft:light[level=12]
setblock 246 256 443 minecraft:light[level=12]
setblock 246 256 451 minecraft:light[level=12]
fill 250 256 458 250 307 458 minecraft:black_concrete
setblock 254 256 419 minecraft:light[level=12]
setblock 254 256 427 minecraft:light[level=12]
setblock 254 256 435 minecraft:light[level=12]
setblock 254 256 443 minecraft:light[level=12]
setblock 254 256 451 minecraft:light[level=12]
setblock 262 256 419 minecraft:light[level=12]
setblock 262 256 427 minecraft:light[level=12]
setblock 262 256 435 minecraft:light[level=12]
setblock 262 256 443 minecraft:light[level=12]
setblock 262 256 451 minecraft:light[level=12]
setblock 270 256 419 minecraft:light[level=12]
setblock 270 256 427 minecraft:light[level=12]
setblock 270 256 435 minecraft:light[level=12]
setblock 270 256 443 minecraft:light[level=12]
setblock 270 256 451 minecraft:light[level=12]
setblock 235 257 425 minecraft:amethyst_block
setblock 236 257 458 minecraft:amethyst_block
fill 241 257 458 241 282 458 minecraft:black_concrete
fill 245 257 416 245 269 416 minecraft:black_concrete
fill 250 257 448 250 258 448 minecraft:amethyst_block
setblock 235 258 420 minecraft:amethyst_block
fill 235 258 425 235 307 425 minecraft:black_concrete
fill 236 258 458 236 285 458 minecraft:black_concrete
fill 258 258 424 258 259 424 minecraft:crying_obsidian
fill 235 259 420 235 288 420 minecraft:black_concrete
setblock 238 259 416 minecraft:white_concrete
fill 250 259 448 250 267 448 minecraft:black_concrete
setblock 264 259 458 minecraft:amethyst_block
setblock 265 259 416 minecraft:white_concrete
setblock 238 260 416 minecraft:black_concrete
fill 249 260 447 249 267 448 minecraft:black_concrete
fill 250 260 447 250 267 447 minecraft:black_concrete
setblock 258 260 416 minecraft:crying_obsidian
fill 264 260 458 264 307 458 minecraft:black_concrete
fill 265 260 416 265 307 416 minecraft:black_concrete
setblock 277 260 424 minecraft:white_concrete
fill 235 261 424 235 263 424 minecraft:purple_concrete
fill 235 261 440 235 263 440 minecraft:purple_concrete
fill 235 261 456 235 263 456 minecraft:purple_concrete
setblock 238 261 416 minecraft:white_concrete
fill 239 261 416 239 263 416 minecraft:purple_concrete
fill 249 261 449 250 267 449 minecraft:black_concrete
fill 249 261 458 249 263 458 minecraft:purple_concrete
fill 251 261 448 251 267 448 minecraft:black_concrete
fill 255 261 416 255 263 416 minecraft:purple_concrete
fill 258 261 416 258 278 416 minecraft:black_concrete
setblock 261 261 416 minecraft:amethyst_block
fill 265 261 458 265 263 458 minecraft:purple_concrete
fill 271 261 416 271 263 416 minecraft:purple_concrete
fill 277 261 424 277 307 424 minecraft:black_concrete
fill 277 261 426 277 263 426 minecraft:purple_concrete
fill 277 261 442 277 263 442 minecraft:purple_concrete
setblock 235 262 452 minecraft:amethyst_block
setblock 237 262 458 minecraft:white_concrete
fill 238 262 416 238 307 416 minecraft:black_concrete
setblock 241 262 416 minecraft:crying_obsidian
fill 248 262 447 248 267 448 minecraft:black_concrete
fill 249 262 446 250 267 446 minecraft:black_concrete
fill 251 262 447 251 267 447 minecraft:black_concrete
fill 251 262 449 251 267 449 minecraft:black_concrete
fill 261 262 416 261 283 416 minecraft:black_concrete
setblock 235 263 452 minecraft:crying_obsidian
fill 237 263 458 237 307 458 minecraft:black_concrete
fill 241 263 416 241 288 416 minecraft:black_concrete
fill 248 263 446 248 267 446 minecraft:black_concrete
fill 248 263 449 248 267 449 minecraft:black_concrete
fill 249 263 450 250 267 450 minecraft:black_concrete
fill 251 263 446 251 267 446 minecraft:black_concrete
fill 235 264 424 235 265 424 minecraft:black_concrete
fill 235 264 440 235 269 440 minecraft:black_concrete
fill 235 264 452 235 307 452 minecraft:black_concrete
fill 235 264 456 235 268 456 minecraft:black_concrete
setblock 238 264 419 minecraft:light[level=12]
setblock 238 264 427 minecraft:light[level=12]
setblock 238 264 435 minecraft:light[level=12]
setblock 238 264 443 minecraft:light[level=12]
setblock 238 264 451 minecraft:light[level=12]
fill 239 264 416 239 269 416 minecraft:black_concrete
setblock 246 264 419 minecraft:light[level=12]
setblock 246 264 427 minecraft:light[level=12]
setblock 246 264 435 minecraft:light[level=12]
setblock 246 264 443 minecraft:light[level=12]
setblock 246 264 451 minecraft:light[level=12]
fill 247 264 447 247 267 449 minecraft:black_concrete
fill 248 264 450 248 267 450 minecraft:black_concrete
fill 249 264 445 250 267 445 minecraft:black_concrete
fill 249 264 458 249 269 458 minecraft:black_concrete
fill 251 264 450 251 267 450 minecraft:black_concrete
fill 252 264 446 252 267 449 minecraft:black_concrete
setblock 254 264 419 minecraft:light[level=12]
setblock 254 264 427 minecraft:light[level=12]
setblock 254 264 435 minecraft:light[level=12]
setblock 254 264 443 minecraft:light[level=12]
setblock 254 264 451 minecraft:light[level=12]
fill 255 264 416 255 269 416 minecraft:black_concrete
setblock 262 264 419 minecraft:light[level=12]
setblock 262 264 427 minecraft:light[level=12]
setblock 262 264 435 minecraft:light[level=12]
setblock 262 264 443 minecraft:light[level=12]
setblock 262 264 451 minecraft:light[level=12]
fill 265 264 458 265 269 458 minecraft:black_concrete
setblock 270 264 419 minecraft:light[level=12]
setblock 270 264 427 minecraft:light[level=12]
setblock 270 264 435 minecraft:light[level=12]
setblock 270 264 443 minecraft:light[level=12]
setblock 270 264 451 minecraft:light[level=12]
fill 271 264 416 271 269 416 minecraft:black_concrete
setblock 274 264 458 minecraft:amethyst_block
fill 277 264 426 277 269 426 minecraft:black_concrete
fill 277 264 442 277 269 442 minecraft:black_concrete
fill 247 265 446 247 267 446 minecraft:black_concrete
fill 247 265 450 247 267 450 minecraft:black_concrete
fill 248 265 445 248 267 445 minecraft:black_concrete
fill 249 265 451 250 267 451 minecraft:black_concrete
fill 251 265 445 251 267 445 minecraft:black_concrete
fill 252 265 450 252 267 450 minecraft:black_concrete
fill 274 265 458 274 275 458 minecraft:black_concrete
setblock 277 265 449 minecraft:crying_obsidian
setblock 235 266 424 minecraft:white_concrete
setblock 235 266 445 minecraft:white_concrete
fill 246 266 446 246 267 449 minecraft:black_concrete
fill 247 266 445 247 267 445 minecraft:black_concrete
fill 248 266 451 248 267 451 minecraft:black_concrete
fill 249 266 444 251 267 444 minecraft:black_concrete
fill 251 266 451 251 267 451 minecraft:black_concrete
fill 252 266 445 252 267 445 minecraft:black_concrete
fill 253 266 446 253 267 449 minecraft:black_concrete
setblock 277 266 429 minecraft:crying_obsidian
fill 277 266 449 277 307 449 minecraft:black_concrete
fill 235 267 424 235 269 424 minecraft:black_concrete
setblock 235 267 427 minecraft:amethyst_block
fill 235 267 445 235 287 445 minecraft:black_concrete
setblock 246 267 445 minecraft:black_concrete
setblock 246 267 450 minecraft:black_concrete
setblock 247 267 451 minecraft:black_concrete
setblock 248 267 444 minecraft:black_concrete
fill 249 267 452 250 267 452 minecraft:black_concrete
setblock 252 267 444 minecraft:black_concrete
setblock 252 267 451 minecraft:black_concrete
setblock 253 267 445 minecraft:black_concrete
setblock 253 267 450 minecraft:black_concrete
fill 266 267 450 266 268 450 minecraft:obsidian
fill 277 267 429 277 278 429 minecraft:black_concrete
setblock 277 267 450 minecraft:crying_obsidian
setblock 235 268 426 minecraft:crying_obsidian
fill 235 268 427 235 307 427 minecraft:black_concrete
fill 249 268 447 250 269 448 minecraft:amethyst_block
setblock 252 268 458 minecraft:white_concrete
setblock 277 268 417 minecraft:white_concrete
fill 277 268 450 277 282 450 minecraft:black_concrete
fill 235 269 426 235 307 426 minecraft:black_concrete
setblock 235 269 451 minecraft:white_concrete
setblock 235 269 456 minecraft:crying_obsidian
setblock 240 269 416 minecraft:amethyst_block
fill 252 269 458 252 277 458 minecraft:black_concrete
fill 256 269 426 257 270 426 minecraft:amethyst_block
fill 277 269 417 277 281 417 minecraft:black_concrete
setblock 277 269 446 minecraft:white_concrete
fill 235 270 424 235 272 424 minecraft:purple_concrete
fill 235 270 440 235 272 440 minecraft:purple_concrete
setblock 235 270 450 minecraft:white_concrete
fill 235 270 451 235 297 451 minecraft:black_concrete
fill 235 270 456 235 272 456 minecraft:purple_concrete
fill 239 270 416 239 272 416 minecraft:purple_concrete
fill 240 270 416 240 304 416 minecraft:black_concrete
setblock 245 270 416 minecraft:crying_obsidian
fill 249 270 448 250 270 448 minecraft:amethyst_block
fill 249 270 458 249 272 458 minecraft:purple_concrete
fill 255 270 416 255 272 416 minecraft:purple_concrete
setblock 259 270 416 minecraft:amethyst_block
fill 265 270 458 265 272 458 minecraft:purple_concrete
fill 271 270 416 271 272 416 minecraft:purple_concrete
fill 277 270 426 277 272 426 minecraft:purple_concrete
fill 277 270 442 277 272 442 minecraft:purple_concrete
fill 277 270 446 277 307 446 minecraft:black_concrete
setblock 277 270 454 minecraft:crying_obsidian
setblock 277 270 457 minecraft:crying_obsidian
fill 235 271 450 235 307 450 minecraft:black_concrete
setblock 240 271 458 minecraft:amethyst_block
fill 245 271 416 245 290 416 minecraft:black_concrete
fill 259 271 416 259 307 416 minecraft:black_concrete
setblock 266 271 458 minecraft:white_concrete
fill 277 271 454 277 307 454 minecraft:black_concrete
fill 277 271 457 277 281 457 minecraft:black_concrete
fill 235 272 436 235 307 436 minecraft:black_concrete
setblock 235 272 437 minecraft:amethyst_block
setblock 235 272 438 minecraft:crying_obsidian
setblock 238 272 419 minecraft:light[level=12]
setblock 238 272 427 minecraft:light[level=12]
setblock 238 272 435 minecraft:light[level=12]
setblock 238 272 443 minecraft:light[level=12]
setblock 238 272 451 minecraft:light[level=12]
fill 240 272 458 240 288 458 minecraft:black_concrete
setblock 246 272 419 minecraft:light[level=12]
setblock 246 272 427 minecraft:light[level=12]
setblock 246 272 435 minecraft:light[level=12]
setblock 246 272 443 minecraft:light[level=12]
setblock 246 272 451 minecraft:light[level=12]
setblock 254 272 419 minecraft:light[level=12]
setblock 254 272 427 minecraft:light[level=12]
setblock 254 272 435 minecraft:light[level=12]
setblock 254 272 443 minecraft:light[level=12]
setblock 254 272 451 minecraft:light[level=12]
setblock 255 272 458 minecraft:amethyst_block
setblock 262 272 419 minecraft:light[level=12]
setblock 262 272 427 minecraft:light[level=12]
setblock 262 272 435 minecraft:light[level=12]
setblock 262 272 443 minecraft:light[level=12]
setblock 262 272 451 minecraft:light[level=12]
fill 266 272 458 266 307 458 minecraft:black_concrete
setblock 270 272 419 minecraft:light[level=12]
setblock 270 272 427 minecraft:light[level=12]
setblock 270 272 435 minecraft:light[level=12]
setblock 270 272 443 minecraft:light[level=12]
setblock 270 272 451 minecraft:light[level=12]
fill 235 273 424 235 287 424 minecraft:black_concrete
fill 235 273 437 235 304 438 minecraft:black_concrete
fill 235 273 440 235 287 440 minecraft:black_concrete
fill 235 273 456 235 287 456 minecraft:black_concrete
fill 239 273 416 239 287 416 minecraft:black_concrete
fill 249 273 458 249 280 458 minecraft:black_concrete
fill 255 273 416 255 287 416 minecraft:black_concrete
fill 255 273 458 255 307 458 minecraft:black_concrete
fill 265 273 458 265 275 458 minecraft:black_concrete
fill 271 273 416 271 287 416 minecraft:black_concrete
fill 277 273 426 277 287 426 minecraft:black_concrete
fill 277 273 442 277 278 442 minecraft:black_concrete
setblock 235 274 432 minecraft:crying_obsidian
setblock 272 274 416 minecraft:white_concrete
fill 235 275 432 235 307 432 minecraft:black_concrete
setblock 244 275 458 minecraft:crying_obsidian
setblock 258 275 458 minecraft:crying_obsidian
setblock 267 275 416 minecraft:crying_obsidian
fill 272 275 416 272 306 416 minecraft:black_concrete
fill 244 276 458 244 303 458 minecraft:black_concrete
fill 258 276 458 258 278 458 minecraft:black_concrete
setblock 265 276 458 minecraft:crying_obsidian
fill 267 276 416 267 307 416 minecraft:black_concrete
setblock 274 276 458 minecraft:white_concrete
setblock 235 277 446 minecraft:amethyst_block
setblock 249 277 416 minecraft:white_concrete
fill 265 277 458 265 287 458 minecraft:black_concrete
setblock 274 277 458 minecraft:amethyst_block
setblock 277 277 421 minecraft:amethyst_block
setblock 235 278 435 minecraft:crying_obsidian
fill 235 278 446 235 307 446 minecraft:black_concrete
setblock 243 278 458 minecraft:crying_obsidian
fill 249 278 416 249 307 416 minecraft:black_concrete
setblock 252 278 458 minecraft:crying_obsidian
fill 274 278 458 274 304 458 minecraft:black_concrete
fill 277 278 421 277 307 421 minecraft:black_concrete
fill 235 279 435 235 307 435 minecraft:black_concrete
fill 237 279 437 255 279 437 minecraft:obsidian
fill 238 279 431 255 279 436 minecraft:obsidian
fill 238 279 438 255 279 443 minecraft:obsidian
fill 239 279 429 277 279 430 minecraft:obsidian
fill 239 279 444 277 279 445 minecraft:obsidian
fill 240 279 427 276 279 428 minecraft:obsidian
fill 240 279 446 276 279 447 minecraft:obsidian
fill 241 279 425 275 279 426 minecraft:obsidian
fill 241 279 448 275 279 449 minecraft:obsidian
fill 242 279 424 274 279 424 minecraft:obsidian
fill 242 279 450 274 279 450 minecraft:obsidian
fill 243 279 423 273 279 423 minecraft:obsidian
fill 243 279 451 273 279 451 minecraft:obsidian
fill 243 279 458 243 307 458 minecraft:black_concrete
fill 244 279 422 272 279 422 minecraft:obsidian
fill 244 279 452 272 279 452 minecraft:obsidian
fill 245 279 421 271 279 421 minecraft:obsidian
fill 245 279 453 271 279 453 minecraft:obsidian
fill 246 279 420 270 279 420 minecraft:obsidian
fill 246 279 454 270 279 454 minecraft:obsidian
fill 248 279 419 268 279 419 minecraft:obsidian
fill 248 279 455 268 279 455 minecraft:obsidian
fill 250 279 418 266 279 418 minecraft:obsidian
fill 250 279 456 266 279 456 minecraft:obsidian
fill 252 279 417 264 279 417 minecraft:obsidian
fill 252 279 457 264 279 457 minecraft:obsidian
fill 252 279 458 252 307 458 minecraft:black_concrete
fill 256 279 431 256 279 435 minecraft:obsidian
fill 256 279 439 256 279 443 minecraft:obsidian
fill 257 279 431 277 279 434 minecraft:obsidian
fill 257 279 440 277 279 443 minecraft:obsidian
fill 258 279 416 258 286 416 minecraft:obsidian
fill 258 279 458 258 286 458 minecraft:obsidian
fill 260 279 435 277 279 435 minecraft:obsidian
fill 260 279 439 277 279 439 minecraft:obsidian
setblock 260 279 458 minecraft:white_concrete
fill 261 279 436 277 279 438 minecraft:obsidian
setblock 269 279 458 minecraft:amethyst_block
fill 236 280 417 236 280 457 minecraft:black_concrete
fill 237 280 417 237 280 436 minecraft:black_concrete
fill 237 280 437 237 286 437 minecraft:purple_concrete
fill 237 280 438 237 280 457 minecraft:black_concrete
fill 238 280 417 238 280 430 minecraft:black_concrete
fill 238 280 431 239 286 435 minecraft:obsidian
fill 238 280 436 238 286 436 minecraft:purple_concrete
fill 238 280 437 240 286 443 minecraft:obsidian
fill 238 280 444 238 280 457 minecraft:black_concrete
fill 239 280 417 239 280 428 minecraft:black_concrete
fill 239 280 429 251 283 430 minecraft:obsidian
fill 239 280 436 250 282 436 minecraft:obsidian
fill 239 280 444 239 286 445 minecraft:obsidian
fill 239 280 446 239 280 457 minecraft:black_concrete
fill 240 280 417 240 280 426 minecraft:black_concrete
fill 240 280 427 242 286 428 minecraft:obsidian
fill 240 280 431 240 286 434 minecraft:obsidian
fill 240 280 435 240 286 435 minecraft:purple_concrete
fill 240 280 444 240 286 444 minecraft:purple_concrete
fill 240 280 445 245 285 447 minecraft:obsidian
fill 240 280 448 240 280 457 minecraft:black_concrete
fill 241 280 417 241 280 424 minecraft:black_concrete
fill 241 280 425 253 284 426 minecraft:obsidian
fill 241 280 431 243 285 433 minecraft:obsidian
fill 241 280 434 242 285 434 minecraft:purple_concrete
fill 241 280 435 252 281 435 minecraft:obsidian
fill 241 280 437 241 285 442 minecraft:obsidian
fill 241 280 443 241 286 443 minecraft:purple_concrete
fill 241 280 444 246 284 444 minecraft:obsidian
fill 241 280 448 244 286 449 minecraft:obsidian
fill 241 280 450 241 280 457 minecraft:black_concrete
fill 242 280 417 242 280 423 minecraft:black_concrete
fill 242 280 424 252 284 424 minecraft:obsidian
fill 242 280 437 242 285 440 minecraft:obsidian
fill 242 280 441 242 285 441 minecraft:purple_concrete
fill 242 280 442 247 284 443 minecraft:obsidian
fill 242 280 450 244 286 450 minecraft:obsidian
fill 242 280 451 242 280 457 minecraft:black_concrete
fill 243 280 417 243 280 422 minecraft:black_concrete
fill 243 280 423 258 284 423 minecraft:obsidian
fill 243 280 427 245 285 427 minecraft:purple_concrete
fill 243 280 428 248 284 428 minecraft:obsidian
fill 243 280 434 253 281 434 minecraft:obsidian
fill 243 280 437 243 285 439 minecraft:obsidian
fill 243 280 440 243 285 440 minecraft:purple_concrete
fill 243 280 441 248 283 441 minecraft:obsidian
fill 243 280 451 244 286 451 minecraft:obsidian
fill 243 280 452 243 280 457 minecraft:black_concrete
fill 244 280 417 244 280 421 minecraft:black_concrete
fill 244 280 422 248 286 422 minecraft:obsidian
fill 244 280 431 255 281 432 minecraft:obsidian
fill 244 280 433 245 284 433 minecraft:purple_concrete
fill 244 280 437 245 284 438 minecraft:obsidian
fill 244 280 439 244 284 439 minecraft:purple_concrete
fill 244 280 440 249 283 440 minecraft:obsidian
fill 244 280 452 244 286 452 minecraft:obsidian
fill 244 280 453 244 280 457 minecraft:black_concrete
fill 245 280 417 245 280 420 minecraft:black_concrete
fill 245 280 421 245 286 421 minecraft:obsidian
fill 245 280 439 252 281 439 minecraft:obsidian
fill 245 280 448 250 284 448 minecraft:obsidian
fill 245 280 449 245 286 453 minecraft:purple_concrete
fill 245 280 454 245 280 457 minecraft:black_concrete
fill 246 280 417 247 280 419 minecraft:black_concrete
fill 246 280 420 256 285 420 minecraft:obsidian
fill 246 280 421 247 286 421 minecraft:purple_concrete
fill 246 280 427 255 283 427 minecraft:obsidian
fill 246 280 433 251 282 433 minecraft:obsidian
fill 246 280 437 252 281 437 minecraft:obsidian
fill 246 280 438 246 284 438 minecraft:purple_concrete
fill 246 280 445 258 282 445 minecraft:obsidian
fill 246 280 446 246 285 446 minecraft:purple_concrete
fill 246 280 447 250 284 447 minecraft:obsidian
fill 246 280 449 250 284 454 minecraft:obsidian
fill 246 280 455 247 280 457 minecraft:black_concrete
fill 247 280 438 252 281 438 minecraft:obsidian
fill 247 280 444 247 284 444 minecraft:purple_concrete
fill 247 280 446 265 282 446 minecraft:obsidian
fill 248 280 417 249 280 418 minecraft:black_concrete
fill 248 280 419 255 286 419 minecraft:obsidian
fill 248 280 421 257 285 421 minecraft:obsidian
fill 248 280 442 248 283 442 minecraft:purple_concrete
fill 248 280 443 277 281 444 minecraft:obsidian
fill 248 280 455 251 286 455 minecraft:obsidian
fill 248 280 456 249 280 457 minecraft:black_concrete
fill 249 280 422 250 285 422 minecraft:purple_concrete
fill 249 280 428 250 284 428 minecraft:purple_concrete
fill 249 280 441 249 283 441 minecraft:purple_concrete
fill 249 280 442 255 281 442 minecraft:obsidian
fill 250 280 417 251 280 417 minecraft:black_concrete
fill 250 280 418 254 286 418 minecraft:obsidian
fill 250 280 440 250 282 440 minecraft:purple_concrete
fill 250 280 441 254 281 441 minecraft:obsidian
fill 250 280 456 260 286 456 minecraft:obsidian
fill 250 280 457 251 280 457 minecraft:black_concrete
setblock 251 280 416 minecraft:amethyst_block
fill 251 280 422 270 285 422 minecraft:obsidian
fill 251 280 428 269 282 428 minecraft:obsidian
fill 251 280 436 251 282 436 minecraft:purple_concrete
fill 251 280 440 253 281 440 minecraft:obsidian
fill 251 280 447 251 284 451 minecraft:purple_concrete
fill 251 280 452 251 285 454 minecraft:obsidian
fill 252 280 417 253 286 417 minecraft:obsidian
fill 252 280 429 252 283 429 minecraft:purple_concrete
fill 252 280 430 268 282 430 minecraft:obsidian
fill 252 280 433 252 282 433 minecraft:purple_concrete
fill 252 280 436 252 281 436 minecraft:obsidian
fill 252 280 447 255 283 453 minecraft:obsidian
fill 252 280 454 252 286 455 minecraft:purple_concrete
fill 252 280 457 252 286 457 minecraft:obsidian
fill 253 280 424 253 284 424 minecraft:purple_concrete
fill 253 280 429 256 282 429 minecraft:obsidian
fill 253 280 433 254 281 433 minecraft:obsidian
fill 253 280 435 255 280 439 minecraft:crying_obsidian
fill 253 280 454 258 285 455 minecraft:obsidian
fill 253 280 457 253 286 457 minecraft:purple_concrete
fill 254 280 417 254 286 417 minecraft:purple_concrete
fill 254 280 424 264 284 424 minecraft:obsidian
fill 254 280 425 254 284 425 minecraft:purple_concrete
fill 254 280 426 254 283 426 minecraft:obsidian
fill 254 280 434 262 280 434 minecraft:crying_obsidian
fill 254 280 440 262 280 440 minecraft:crying_obsidian
fill 254 280 457 261 286 457 minecraft:obsidian
fill 255 280 417 262 286 417 minecraft:obsidian
fill 255 280 418 255 286 418 minecraft:purple_concrete
fill 255 280 425 259 284 425 minecraft:obsidian
fill 255 280 426 255 283 426 minecraft:purple_concrete
fill 255 280 433 261 281 433 minecraft:crying_obsidian
fill 255 280 441 261 281 441 minecraft:crying_obsidian
fill 256 280 418 266 286 418 minecraft:obsidian
fill 256 280 419 256 286 419 minecraft:purple_concrete
fill 256 280 426 259 283 426 minecraft:obsidian
fill 256 280 427 256 283 427 minecraft:purple_concrete
fill 256 280 431 274 281 431 minecraft:obsidian
fill 256 280 432 260 281 432 minecraft:crying_obsidian
setblock 256 280 435 minecraft:crying_obsidian
setblock 256 280 439 minecraft:crying_obsidian
fill 256 280 442 260 281 442 minecraft:crying_obsidian
fill 256 280 447 259 283 447 minecraft:obsidian
fill 256 280 448 256 283 449 minecraft:purple_concrete
fill 256 280 450 256 284 453 minecraft:obsidian
fill 257 280 419 263 286 419 minecraft:obsidian
fill 257 280 420 257 285 420 minecraft:purple_concrete
fill 257 280 427 264 283 427 minecraft:obsidian
fill 257 280 429 257 282 429 minecraft:purple_concrete
fill 257 280 448 260 283 450 minecraft:obsidian
fill 257 280 451 257 284 451 minecraft:purple_concrete
fill 257 280 452 257 285 453 minecraft:obsidian
fill 258 280 420 263 285 420 minecraft:obsidian
fill 258 280 421 258 285 421 minecraft:purple_concrete
fill 258 280 429 277 282 429 minecraft:obsidian
fill 258 280 451 265 284 452 minecraft:obsidian
fill 258 280 453 258 285 453 minecraft:purple_concrete
fill 259 280 421 270 285 421 minecraft:obsidian
fill 259 280 423 259 284 423 minecraft:purple_concrete
fill 259 280 445 259 282 445 minecraft:purple_concrete
fill 259 280 453 268 285 453 minecraft:obsidian
fill 259 280 454 259 285 454 minecraft:purple_concrete
fill 259 280 455 259 286 455 minecraft:obsidian
fill 260 280 423 264 284 423 minecraft:obsidian
fill 260 280 425 260 283 426 minecraft:purple_concrete
fill 260 280 435 263 280 435 minecraft:crying_obsidian
fill 260 280 439 263 280 439 minecraft:crying_obsidian
fill 260 280 445 263 282 445 minecraft:obsidian
fill 260 280 447 260 283 447 minecraft:purple_concrete
fill 260 280 454 270 285 454 minecraft:obsidian
fill 260 280 455 260 286 455 minecraft:purple_concrete
fill 260 280 458 260 302 458 minecraft:black_concrete
fill 261 280 425 264 283 426 minecraft:obsidian
fill 261 280 432 267 281 432 minecraft:obsidian
fill 261 280 436 263 280 438 minecraft:crying_obsidian
fill 261 280 442 277 281 442 minecraft:obsidian
fill 261 280 447 270 283 447 minecraft:obsidian
fill 261 280 448 261 283 448 minecraft:purple_concrete
fill 261 280 449 261 284 450 minecraft:obsidian
fill 261 280 455 268 286 455 minecraft:obsidian
fill 261 280 456 261 286 456 minecraft:purple_concrete
fill 262 280 433 266 281 433 minecraft:obsidian
fill 262 280 441 263 281 441 minecraft:obsidian
fill 262 280 448 275 283 448 minecraft:obsidian
fill 262 280 449 262 284 449 minecraft:purple_concrete
fill 262 280 450 262 284 450 minecraft:obsidian
fill 262 280 456 266 286 456 minecraft:obsidian
fill 262 280 457 262 286 457 minecraft:purple_concrete
fill 263 280 417 263 286 417 minecraft:purple_concrete
fill 263 280 434 265 281 434 minecraft:obsidian
fill 263 280 440 273 281 440 minecraft:obsidian
fill 263 280 449 275 284 449 minecraft:obsidian
fill 263 280 450 263 284 450 minecraft:purple_concrete
fill 263 280 457 264 286 457 minecraft:obsidian
fill 264 280 417 264 286 417 minecraft:obsidian
fill 264 280 419 264 286 420 minecraft:purple_concrete
fill 264 280 435 264 281 439 minecraft:obsidian
fill 264 280 441 264 282 441 minecraft:purple_concrete
fill 264 280 445 264 283 445 minecraft:purple_concrete
fill 264 280 450 274 284 450 minecraft:obsidian
fill 265 280 417 276 280 417 minecraft:black_concrete
fill 265 280 419 268 286 420 minecraft:obsidian
fill 265 280 423 265 284 427 minecraft:purple_concrete
fill 265 280 435 269 282 437 minecraft:obsidian
fill 265 280 438 265 282 438 minecraft:purple_concrete
fill 265 280 439 275 282 439 minecraft:obsidian
fill 265 280 441 270 282 441 minecraft:obsidian
fill 265 280 445 277 283 445 minecraft:obsidian
fill 265 280 457 276 280 457 minecraft:black_concrete
fill 266 280 423 270 284 427 minecraft:obsidian
fill 266 280 434 266 282 434 minecraft:purple_concrete
fill 266 280 438 277 282 438 minecraft:obsidian
fill 266 280 446 267 284 446 minecraft:purple_concrete
fill 266 280 451 273 285 451 minecraft:obsidian
fill 266 280 452 267 285 452 minecraft:purple_concrete
fill 267 280 418 276 280 418 minecraft:black_concrete
fill 267 280 433 267 283 433 minecraft:purple_concrete
fill 267 280 434 272 283 434 minecraft:obsidian
fill 267 280 456 276 280 456 minecraft:black_concrete
fill 268 280 432 268 283 432 minecraft:purple_concrete
fill 268 280 433 273 283 433 minecraft:obsidian
fill 268 280 446 276 284 446 minecraft:obsidian
fill 268 280 452 272 286 452 minecraft:obsidian
fill 269 280 419 276 280 419 minecraft:black_concrete
fill 269 280 420 270 286 420 minecraft:obsidian
fill 269 280 430 269 284 430 minecraft:purple_concrete
fill 269 280 432 277 284 432 minecraft:obsidian
fill 269 280 453 270 286 453 minecraft:purple_concrete
fill 269 280 455 276 280 455 minecraft:black_concrete
fill 269 280 458 269 307 458 minecraft:black_concrete
fill 270 280 428 270 285 428 minecraft:purple_concrete
fill 270 280 430 275 284 430 minecraft:obsidian
fill 270 280 435 271 284 435 minecraft:obsidian
fill 270 280 436 270 284 436 minecraft:purple_concrete
fill 270 280 437 277 284 437 minecraft:obsidian
fill 271 280 420 276 280 420 minecraft:black_concrete
fill 271 280 421 271 286 425 minecraft:purple_concrete
fill 271 280 426 275 285 428 minecraft:obsidian
fill 271 280 436 277 284 436 minecraft:obsidian
fill 271 280 441 272 284 441 minecraft:purple_concrete
fill 271 280 447 273 285 447 minecraft:purple_concrete
fill 271 280 453 271 286 453 minecraft:obsidian
fill 271 280 454 276 280 454 minecraft:black_concrete
fill 272 280 421 276 280 421 minecraft:black_concrete
fill 272 280 422 272 286 425 minecraft:obsidian
fill 272 280 435 272 284 435 minecraft:purple_concrete
fill 272 280 453 276 280 453 minecraft:black_concrete
fill 273 280 422 276 280 422 minecraft:black_concrete
fill 273 280 423 273 286 425 minecraft:obsidian
fill 273 280 434 273 285 434 minecraft:purple_concrete
fill 273 280 435 277 285 435 minecraft:obsidian
fill 273 280 441 277 285 441 minecraft:obsidian
fill 273 280 452 276 280 452 minecraft:black_concrete
fill 274 280 423 276 280 423 minecraft:black_concrete
fill 274 280 424 274 286 425 minecraft:obsidian
fill 274 280 433 274 285 433 minecraft:purple_concrete
fill 274 280 434 277 285 434 minecraft:obsidian
fill 274 280 440 275 285 440 minecraft:purple_concrete
fill 274 280 447 276 286 447 minecraft:obsidian
fill 274 280 451 276 280 451 minecraft:black_concrete
fill 275 280 424 276 280 424 minecraft:black_concrete
fill 275 280 425 275 286 425 minecraft:obsidian
fill 275 280 431 275 286 431 minecraft:purple_concrete
fill 275 280 433 277 286 433 minecraft:obsidian
fill 275 280 450 276 280 450 minecraft:black_concrete
fill 276 280 425 276 280 426 minecraft:black_concrete
fill 276 280 427 276 286 428 minecraft:obsidian
fill 276 280 430 276 286 430 minecraft:purple_concrete
fill 276 280 431 277 286 431 minecraft:obsidian
fill 276 280 439 276 286 439 minecraft:purple_concrete
fill 276 280 440 277 286 440 minecraft:obsidian
fill 276 280 448 276 280 449 minecraft:black_concrete
fill 277 280 430 277 286 430 minecraft:obsidian
fill 277 280 439 277 286 439 minecraft:obsidian
setblock 249 281 458 minecraft:crying_obsidian
fill 251 281 416 251 291 416 minecraft:black_concrete
fill 253 281 435 254 281 439 minecraft:crying_obsidian
fill 254 281 434 255 281 434 minecraft:crying_obsidian
fill 254 281 440 255 281 440 minecraft:crying_obsidian
setblock 260 281 416 minecraft:crying_obsidian
fill 261 281 434 262 281 434 minecraft:crying_obsidian
fill 261 281 440 262 281 440 minecraft:crying_obsidian
fill 262 281 435 263 281 439 minecraft:crying_obsidian
setblock 235 282 455 minecraft:crying_obsidian
fill 241 282 435 251 282 435 minecraft:obsidian
setblock 242 282 416 minecraft:amethyst_block
fill 243 282 434 252 282 434 minecraft:obsidian
fill 244 282 431 253 282 432 minecraft:obsidian
fill 245 282 439 251 282 439 minecraft:obsidian
fill 246 282 437 251 282 437 minecraft:obsidian
fill 247 282 438 251 282 438 minecraft:obsidian
fill 248 282 443 255 282 444 minecraft:obsidian
fill 249 282 442 253 282 442 minecraft:obsidian
fill 249 282 458 249 287 458 minecraft:black_concrete
fill 250 282 441 252 282 441 minecraft:obsidian
fill 251 282 440 252 282 440 minecraft:obsidian
fill 254 282 431 255 282 431 minecraft:obsidian
fill 256 282 444 277 282 444 minecraft:obsidian
fill 260 282 416 260 307 416 minecraft:black_concrete
fill 261 282 431 274 282 431 minecraft:obsidian
fill 261 282 443 277 282 443 minecraft:obsidian
fill 263 282 432 267 282 432 minecraft:obsidian
fill 263 282 442 277 282 442 minecraft:obsidian
fill 264 282 433 265 282 434 minecraft:obsidian
fill 264 282 440 273 282 440 minecraft:obsidian
setblock 266 282 433 minecraft:obsidian
setblock 277 282 417 minecraft:white_concrete
setblock 277 282 457 minecraft:crying_obsidian
setblock 235 283 422 minecraft:amethyst_block
fill 235 283 455 235 294 455 minecraft:black_concrete
fill 239 283 436 248 283 436 minecraft:obsidian
fill 241 283 435 249 283 435 minecraft:obsidian
setblock 241 283 458 minecraft:amethyst_block
setblock 242 283 416 minecraft:crying_obsidian
fill 243 283 434 249 283 434 minecraft:obsidian
fill 244 283 431 250 283 432 minecraft:obsidian
fill 245 283 439 249 283 439 minecraft:obsidian
fill 246 283 433 249 283 433 minecraft:obsidian
fill 246 283 437 248 283 437 minecraft:obsidian
fill 246 283 445 253 283 445 minecraft:obsidian
fill 247 283 438 248 283 438 minecraft:obsidian
fill 247 283 446 256 283 446 minecraft:obsidian
setblock 247 283 458 minecraft:amethyst_block
fill 248 283 443 251 283 444 minecraft:obsidian
fill 249 283 442 250 283 442 minecraft:obsidian
fill 251 283 428 256 283 428 minecraft:obsidian
setblock 251 283 431 minecraft:obsidian
setblock 252 283 430 minecraft:obsidian
setblock 252 283 444 minecraft:obsidian
setblock 253 283 429 minecraft:obsidian
fill 260 283 428 269 283 428 minecraft:obsidian
fill 260 283 446 265 283 446 minecraft:obsidian
fill 263 283 429 277 283 429 minecraft:obsidian
setblock 263 283 445 minecraft:obsidian
fill 264 283 430 268 283 430 minecraft:obsidian
fill 264 283 444 277 283 444 minecraft:obsidian
fill 265 283 431 274 283 431 minecraft:obsidian
fill 265 283 443 277 283 443 minecraft:obsidian
fill 266 283 432 267 283 432 minecraft:obsidian
fill 266 283 442 277 283 442 minecraft:obsidian
fill 267 283 435 269 283 435 minecraft:obsidian
fill 267 283 439 270 283 441 minecraft:obsidian
fill 268 283 436 269 283 438 minecraft:obsidian
fill 270 283 438 277 284 438 minecraft:obsidian
fill 271 283 439 273 284 440 minecraft:obsidian
fill 274 283 439 275 285 439 minecraft:obsidian
fill 277 283 417 277 307 417 minecraft:black_concrete
setblock 277 283 450 minecraft:white_concrete
setblock 277 283 455 minecraft:amethyst_block
setblock 277 283 456 minecraft:crying_obsidian
fill 277 283 457 277 307 457 minecraft:black_concrete
fill 235 284 422 235 294 422 minecraft:black_concrete
setblock 235 284 444 minecraft:amethyst_block
fill 239 284 429 248 284 430 minecraft:obsidian
fill 239 284 436 246 284 436 minecraft:obsidian
fill 241 284 435 246 284 435 minecraft:obsidian
fill 241 284 458 241 296 458 minecraft:black_concrete
fill 242 284 416 242 307 416 minecraft:black_concrete
fill 243 284 434 246 284 434 minecraft:obsidian
fill 243 284 441 246 284 441 minecraft:obsidian
fill 244 284 431 247 284 432 minecraft:obsidian
fill 244 284 440 246 284 440 minecraft:obsidian
fill 245 284 439 246 284 439 minecraft:obsidian
fill 246 284 427 251 284 427 minecraft:obsidian
setblock 246 284 433 minecraft:obsidian
setblock 246 284 437 minecraft:obsidian
fill 246 284 445 249 284 445 minecraft:obsidian
fill 247 284 446 250 284 446 minecraft:obsidian
fill 247 284 458 247 307 458 minecraft:black_concrete
setblock 248 284 444 minecraft:obsidian
setblock 249 284 429 minecraft:obsidian
fill 252 284 448 253 284 453 minecraft:obsidian
fill 254 284 449 255 284 453 minecraft:obsidian
setblock 256 284 449 minecraft:purple_concrete
fill 257 284 449 260 284 450 minecraft:obsidian
setblock 260 284 425 minecraft:purple_concrete
fill 261 284 416 262 284 416 minecraft:white_concrete
fill 261 284 425 264 284 425 minecraft:obsidian
fill 263 284 426 264 284 426 minecraft:obsidian
fill 263 284 448 275 284 448 minecraft:obsidian
fill 265 284 447 270 284 447 minecraft:obsidian
fill 266 284 428 269 284 428 minecraft:obsidian
fill 267 284 429 277 284 429 minecraft:obsidian
fill 267 284 445 277 284 445 minecraft:obsidian
setblock 268 284 430 minecraft:obsidian
fill 268 284 444 277 284 444 minecraft:obsidian
fill 269 284 431 274 284 431 minecraft:obsidian
fill 269 284 442 277 284 443 minecraft:obsidian
fill 270 284 433 272 284 434 minecraft:obsidian
fill 270 284 439 270 284 441 minecraft:obsidian
fill 273 284 433 273 285 433 minecraft:obsidian
fill 277 284 450 277 307 450 minecraft:black_concrete
fill 277 284 455 277 307 456 minecraft:black_concrete
fill 235 285 444 235 287 444 minecraft:black_concrete
fill 239 285 429 245 285 430 minecraft:obsidian
fill 239 285 436 243 285 436 minecraft:obsidian
fill 241 285 425 248 285 426 minecraft:obsidian
fill 241 285 435 243 285 435 minecraft:obsidian
schedule function dropper:buildpart/101_2 1t
