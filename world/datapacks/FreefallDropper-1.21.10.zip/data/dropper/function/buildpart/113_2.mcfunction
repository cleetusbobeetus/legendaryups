fill 274 31 483 274 34 483 minecraft:brown_terracotta
setblock 274 31 486 minecraft:brown_terracotta
setblock 274 31 487 minecraft:bone_block
fill 274 31 488 274 34 488 minecraft:brown_terracotta
setblock 274 31 497 minecraft:bone_block
fill 274 31 498 274 34 498 minecraft:brown_terracotta
setblock 274 31 502 minecraft:bone_block
fill 274 31 503 274 34 503 minecraft:brown_terracotta
setblock 275 31 476 minecraft:bone_block
fill 275 31 477 275 34 477 minecraft:brown_terracotta
setblock 275 31 481 minecraft:bone_block
fill 275 31 482 275 34 482 minecraft:brown_terracotta
setblock 275 31 485 minecraft:brown_terracotta
setblock 275 31 486 minecraft:bone_block
fill 275 31 487 275 34 487 minecraft:brown_terracotta
setblock 275 31 491 minecraft:bone_block
fill 275 31 492 275 34 492 minecraft:brown_terracotta
setblock 275 31 496 minecraft:bone_block
fill 275 31 497 275 34 497 minecraft:brown_terracotta
setblock 275 31 501 minecraft:bone_block
fill 275 31 502 275 34 502 minecraft:brown_terracotta
setblock 276 31 465 minecraft:bone_block
setblock 276 31 475 minecraft:bone_block
fill 276 31 476 276 34 476 minecraft:brown_terracotta
setblock 276 31 480 minecraft:bone_block
fill 276 31 481 276 34 481 minecraft:brown_terracotta
setblock 276 31 485 minecraft:bone_block
fill 276 31 486 276 34 486 minecraft:brown_terracotta
setblock 276 31 490 minecraft:bone_block
fill 276 31 491 276 34 491 minecraft:brown_terracotta
setblock 276 31 495 minecraft:bone_block
fill 276 31 496 276 34 496 minecraft:brown_terracotta
setblock 276 31 500 minecraft:bone_block
fill 276 31 501 276 34 501 minecraft:brown_terracotta
setblock 236 32 464 minecraft:bone_block
fill 236 32 465 236 35 465 minecraft:brown_terracotta
setblock 236 32 469 minecraft:bone_block
fill 236 32 470 236 35 470 minecraft:brown_terracotta
setblock 236 32 474 minecraft:bone_block
fill 236 32 475 236 35 475 minecraft:brown_terracotta
setblock 236 32 479 minecraft:bone_block
fill 236 32 480 236 35 480 minecraft:brown_terracotta
setblock 236 32 484 minecraft:bone_block
fill 236 32 485 236 35 485 minecraft:brown_terracotta
setblock 236 32 489 minecraft:bone_block
fill 236 32 490 236 35 490 minecraft:brown_terracotta
setblock 236 32 494 minecraft:bone_block
fill 236 32 495 236 34 495 minecraft:brown_terracotta
setblock 236 32 499 minecraft:bone_block
fill 236 32 500 236 35 500 minecraft:brown_terracotta
setblock 236 32 504 minecraft:bone_block
fill 237 32 464 237 35 464 minecraft:brown_terracotta
setblock 237 32 473 minecraft:bone_block
fill 237 32 474 237 34 474 minecraft:brown_terracotta
setblock 237 32 478 minecraft:bone_block
fill 237 32 479 237 35 479 minecraft:brown_terracotta
setblock 237 32 483 minecraft:bone_block
fill 237 32 484 237 35 484 minecraft:brown_terracotta
setblock 237 32 488 minecraft:bone_block
setblock 237 32 503 minecraft:bone_block
fill 237 32 504 237 35 504 minecraft:brown_terracotta
setblock 238 32 466 minecraft:light[level=12]
setblock 238 32 474 minecraft:light[level=12]
setblock 238 32 477 minecraft:bone_block
fill 238 32 478 238 34 478 minecraft:brown_terracotta
setblock 238 32 482 minecraft:bone_block
fill 238 32 483 238 35 483 minecraft:brown_terracotta
fill 238 32 485 238 33 485 minecraft:brown_terracotta
setblock 238 32 490 minecraft:light[level=12]
setblock 238 32 498 minecraft:light[level=12]
setblock 240 32 464 minecraft:brown_terracotta
setblock 241 32 464 minecraft:bone_block
setblock 241 32 504 minecraft:bone_block
fill 242 32 464 245 32 464 minecraft:brown_terracotta
fill 242 32 504 245 32 504 minecraft:brown_terracotta
setblock 246 32 464 minecraft:bone_block
setblock 246 32 466 minecraft:light[level=12]
setblock 246 32 474 minecraft:light[level=12]
setblock 246 32 482 minecraft:light[level=12]
setblock 246 32 490 minecraft:light[level=12]
setblock 246 32 498 minecraft:light[level=12]
setblock 246 32 504 minecraft:bone_block
fill 247 32 464 247 34 465 minecraft:brown_terracotta
setblock 247 32 503 minecraft:bone_block
fill 247 32 504 247 35 504 minecraft:brown_terracotta
fill 248 32 465 249 32 465 minecraft:brown_terracotta
fill 248 32 503 248 35 503 minecraft:brown_terracotta
setblock 250 32 465 minecraft:bone_block
fill 250 32 466 251 34 466 minecraft:brown_terracotta
fill 250 32 502 252 32 502 minecraft:brown_terracotta
setblock 251 32 464 minecraft:bone_block
fill 251 32 465 251 35 465 minecraft:brown_terracotta
setblock 251 32 504 minecraft:bone_block
fill 252 32 464 252 35 464 minecraft:brown_terracotta
setblock 252 32 503 minecraft:bone_block
fill 252 32 504 252 35 504 minecraft:brown_terracotta
setblock 253 32 466 minecraft:brown_terracotta
setblock 253 32 501 minecraft:brown_terracotta
setblock 253 32 502 minecraft:bone_block
fill 253 32 503 253 35 503 minecraft:brown_terracotta
setblock 254 32 466 minecraft:bone_block
setblock 254 32 474 minecraft:light[level=12]
setblock 254 32 482 minecraft:light[level=12]
setblock 254 32 490 minecraft:light[level=12]
setblock 254 32 501 minecraft:bone_block
fill 254 32 502 254 35 502 minecraft:brown_terracotta
setblock 255 32 465 minecraft:bone_block
fill 255 32 466 256 34 466 minecraft:brown_terracotta
fill 255 32 501 255 34 501 minecraft:brown_terracotta
setblock 256 32 464 minecraft:bone_block
fill 256 32 465 256 35 465 minecraft:brown_terracotta
setblock 256 32 504 minecraft:bone_block
fill 257 32 464 257 35 464 minecraft:brown_terracotta
setblock 257 32 501 minecraft:brown_terracotta
setblock 257 32 503 minecraft:bone_block
fill 257 32 504 257 35 504 minecraft:brown_terracotta
setblock 258 32 502 minecraft:bone_block
fill 258 32 503 258 35 503 minecraft:brown_terracotta
fill 259 32 496 259 33 496 minecraft:bone_block
fill 259 32 502 259 35 502 minecraft:brown_terracotta
setblock 261 32 464 minecraft:bone_block
setblock 261 32 504 minecraft:bone_block
fill 262 32 464 262 35 464 minecraft:brown_terracotta
setblock 262 32 466 minecraft:light[level=12]
setblock 262 32 474 minecraft:light[level=12]
setblock 262 32 482 minecraft:light[level=12]
setblock 262 32 490 minecraft:light[level=12]
setblock 262 32 498 minecraft:light[level=12]
setblock 262 32 502 minecraft:brown_terracotta
setblock 262 32 503 minecraft:bone_block
fill 262 32 504 262 35 504 minecraft:brown_terracotta
setblock 263 32 502 minecraft:bone_block
fill 263 32 503 266 32 503 minecraft:brown_terracotta
fill 264 32 464 265 32 464 minecraft:brown_terracotta
fill 264 32 502 267 32 502 minecraft:brown_terracotta
setblock 266 32 464 minecraft:bone_block
setblock 266 32 504 minecraft:bone_block
fill 267 32 464 270 32 464 minecraft:brown_terracotta
setblock 267 32 503 minecraft:bone_block
fill 267 32 504 267 35 504 minecraft:brown_terracotta
setblock 268 32 502 minecraft:bone_block
fill 268 32 503 268 35 503 minecraft:brown_terracotta
fill 269 32 494 272 33 498 minecraft:soul_soil
fill 269 32 502 269 35 502 minecraft:brown_terracotta
setblock 270 32 466 minecraft:light[level=12]
setblock 270 32 474 minecraft:light[level=12]
setblock 270 32 482 minecraft:light[level=12]
setblock 270 32 490 minecraft:light[level=12]
fill 270 32 501 270 35 501 minecraft:brown_terracotta
setblock 271 32 464 minecraft:bone_block
setblock 271 32 504 minecraft:bone_block
fill 272 32 464 272 35 464 minecraft:brown_terracotta
setblock 272 32 503 minecraft:bone_block
fill 272 32 504 272 35 504 minecraft:brown_terracotta
fill 273 32 480 273 32 481 minecraft:brown_terracotta
setblock 273 32 482 minecraft:bone_block
fill 273 32 483 273 33 485 minecraft:brown_terracotta
fill 273 32 494 273 33 497 minecraft:soul_soil
setblock 273 32 498 minecraft:brown_terracotta
setblock 273 32 502 minecraft:bone_block
fill 273 32 503 273 35 503 minecraft:brown_terracotta
fill 274 32 464 275 32 464 minecraft:brown_terracotta
fill 274 32 477 274 34 477 minecraft:brown_terracotta
setblock 274 32 480 minecraft:brown_terracotta
setblock 274 32 481 minecraft:bone_block
fill 274 32 482 274 35 482 minecraft:brown_terracotta
setblock 274 32 486 minecraft:bone_block
fill 274 32 487 274 35 487 minecraft:brown_terracotta
fill 274 32 489 274 32 490 minecraft:brown_terracotta
setblock 274 32 491 minecraft:bone_block
fill 274 32 492 274 34 493 minecraft:brown_terracotta
setblock 274 32 496 minecraft:bone_block
fill 274 32 497 274 34 497 minecraft:brown_terracotta
setblock 274 32 501 minecraft:bone_block
fill 274 32 502 274 35 502 minecraft:brown_terracotta
setblock 275 32 475 minecraft:bone_block
fill 275 32 476 275 35 476 minecraft:brown_terracotta
setblock 275 32 480 minecraft:bone_block
fill 275 32 481 275 35 481 minecraft:brown_terracotta
setblock 275 32 485 minecraft:bone_block
fill 275 32 486 275 35 486 minecraft:brown_terracotta
setblock 275 32 490 minecraft:bone_block
fill 275 32 491 275 35 491 minecraft:brown_terracotta
setblock 275 32 495 minecraft:bone_block
fill 275 32 496 275 35 496 minecraft:brown_terracotta
setblock 275 32 500 minecraft:bone_block
fill 275 32 501 275 35 501 minecraft:brown_terracotta
setblock 276 32 464 minecraft:bone_block
fill 276 32 465 276 34 466 minecraft:brown_terracotta
setblock 276 32 474 minecraft:bone_block
fill 276 32 475 276 35 475 minecraft:brown_terracotta
setblock 276 32 479 minecraft:bone_block
fill 276 32 480 276 35 480 minecraft:brown_terracotta
setblock 276 32 484 minecraft:bone_block
fill 276 32 485 276 35 485 minecraft:brown_terracotta
setblock 276 32 489 minecraft:bone_block
fill 276 32 490 276 35 490 minecraft:brown_terracotta
setblock 276 32 494 minecraft:bone_block
fill 276 32 495 276 35 495 minecraft:brown_terracotta
setblock 276 32 499 minecraft:bone_block
fill 276 32 500 276 35 500 minecraft:brown_terracotta
setblock 276 32 504 minecraft:bone_block
fill 236 33 464 236 36 464 minecraft:brown_terracotta
fill 236 33 466 236 33 467 minecraft:brown_terracotta
setblock 236 33 468 minecraft:bone_block
fill 236 33 469 236 36 469 minecraft:brown_terracotta
setblock 236 33 473 minecraft:bone_block
fill 236 33 474 236 36 474 minecraft:brown_terracotta
setblock 236 33 478 minecraft:bone_block
fill 236 33 479 236 36 479 minecraft:brown_terracotta
setblock 236 33 483 minecraft:bone_block
fill 236 33 484 236 36 484 minecraft:brown_terracotta
setblock 236 33 488 minecraft:bone_block
fill 236 33 489 237 34 489 minecraft:brown_terracotta
setblock 236 33 493 minecraft:bone_block
fill 236 33 494 236 34 494 minecraft:brown_terracotta
setblock 236 33 498 minecraft:bone_block
fill 236 33 499 236 35 499 minecraft:brown_terracotta
setblock 236 33 503 minecraft:bone_block
fill 236 33 504 236 36 504 minecraft:brown_terracotta
fill 237 33 465 237 34 465 minecraft:brown_terracotta
setblock 237 33 473 minecraft:brown_terracotta
setblock 237 33 477 minecraft:bone_block
fill 237 33 478 237 36 478 minecraft:brown_terracotta
setblock 237 33 482 minecraft:bone_block
fill 237 33 483 237 36 483 minecraft:brown_terracotta
setblock 237 33 487 minecraft:bone_block
fill 237 33 488 237 36 488 minecraft:brown_terracotta
setblock 237 33 502 minecraft:bone_block
fill 237 33 503 237 34 503 minecraft:brown_terracotta
setblock 238 33 477 minecraft:brown_terracotta
setblock 238 33 481 minecraft:bone_block
fill 238 33 482 238 36 482 minecraft:brown_terracotta
setblock 240 33 464 minecraft:bone_block
setblock 240 33 504 minecraft:bone_block
fill 241 33 464 244 33 464 minecraft:brown_terracotta
fill 241 33 504 244 33 504 minecraft:brown_terracotta
setblock 245 33 464 minecraft:bone_block
fill 245 33 465 246 35 465 minecraft:brown_terracotta
setblock 245 33 504 minecraft:bone_block
fill 246 33 464 246 36 464 minecraft:brown_terracotta
setblock 246 33 503 minecraft:bone_block
fill 246 33 504 246 36 504 minecraft:brown_terracotta
fill 247 33 503 247 36 503 minecraft:brown_terracotta
setblock 248 33 465 minecraft:brown_terracotta
setblock 248 33 466 minecraft:bone_block
setblock 249 33 465 minecraft:bone_block
fill 249 33 466 249 36 466 minecraft:brown_terracotta
fill 249 33 502 251 33 502 minecraft:brown_terracotta
setblock 250 33 464 minecraft:bone_block
fill 250 33 465 250 36 465 minecraft:brown_terracotta
setblock 250 33 504 minecraft:bone_block
fill 251 33 464 251 36 464 minecraft:brown_terracotta
setblock 251 33 503 minecraft:bone_block
fill 251 33 504 251 36 504 minecraft:brown_terracotta
setblock 252 33 501 minecraft:brown_terracotta
setblock 252 33 502 minecraft:bone_block
fill 252 33 503 252 36 503 minecraft:brown_terracotta
setblock 253 33 466 minecraft:bone_block
setblock 253 33 498 minecraft:soul_soil
setblock 253 33 500 minecraft:soul_soil
setblock 253 33 501 minecraft:bone_block
fill 253 33 502 253 36 502 minecraft:brown_terracotta
setblock 254 33 465 minecraft:bone_block
fill 254 33 466 254 36 466 minecraft:brown_terracotta
fill 254 33 501 254 34 501 minecraft:brown_terracotta
setblock 255 33 464 minecraft:bone_block
fill 255 33 465 255 36 465 minecraft:brown_terracotta
setblock 255 33 498 minecraft:soul_soil
setblock 255 33 500 minecraft:soul_soil
setblock 255 33 504 minecraft:bone_block
fill 256 33 464 256 36 464 minecraft:brown_terracotta
setblock 256 33 503 minecraft:bone_block
fill 256 33 504 256 36 504 minecraft:brown_terracotta
setblock 257 33 502 minecraft:bone_block
fill 257 33 503 257 36 503 minecraft:brown_terracotta
fill 258 33 502 258 36 502 minecraft:brown_terracotta
setblock 259 33 465 minecraft:bone_block
setblock 260 33 464 minecraft:bone_block
setblock 260 33 504 minecraft:bone_block
fill 261 33 464 261 36 464 minecraft:brown_terracotta
setblock 261 33 503 minecraft:bone_block
fill 261 33 504 261 36 504 minecraft:brown_terracotta
setblock 262 33 502 minecraft:bone_block
fill 262 33 503 265 33 503 minecraft:brown_terracotta
fill 263 33 502 266 33 502 minecraft:brown_terracotta
setblock 264 33 464 minecraft:brown_terracotta
setblock 265 33 464 minecraft:bone_block
setblock 265 33 504 minecraft:bone_block
fill 266 33 464 269 33 464 minecraft:brown_terracotta
setblock 266 33 503 minecraft:bone_block
fill 266 33 504 266 36 504 minecraft:brown_terracotta
setblock 267 33 502 minecraft:bone_block
fill 267 33 503 267 36 503 minecraft:brown_terracotta
fill 268 33 502 268 36 502 minecraft:brown_terracotta
fill 269 33 501 269 35 501 minecraft:brown_terracotta
setblock 270 33 464 minecraft:bone_block
setblock 270 33 504 minecraft:bone_block
fill 271 33 464 271 35 465 minecraft:brown_terracotta
setblock 271 33 503 minecraft:bone_block
fill 271 33 504 271 36 504 minecraft:brown_terracotta
fill 272 33 465 273 33 465 minecraft:brown_terracotta
setblock 272 33 501 minecraft:brown_terracotta
setblock 272 33 502 minecraft:bone_block
fill 272 33 503 272 36 503 minecraft:brown_terracotta
setblock 273 33 480 minecraft:brown_terracotta
setblock 273 33 481 minecraft:bone_block
fill 273 33 482 273 36 482 minecraft:brown_terracotta
setblock 273 33 486 minecraft:bone_block
fill 273 33 487 273 36 487 minecraft:brown_terracotta
setblock 273 33 498 minecraft:soul_soil
setblock 273 33 501 minecraft:bone_block
fill 273 33 502 273 36 502 minecraft:brown_terracotta
setblock 274 33 464 minecraft:brown_terracotta
setblock 274 33 465 minecraft:bone_block
setblock 274 33 480 minecraft:bone_block
fill 274 33 481 274 36 481 minecraft:brown_terracotta
setblock 274 33 484 minecraft:brown_terracotta
setblock 274 33 485 minecraft:bone_block
fill 274 33 486 274 36 486 minecraft:brown_terracotta
setblock 274 33 489 minecraft:brown_terracotta
setblock 274 33 490 minecraft:bone_block
fill 274 33 491 274 36 491 minecraft:brown_terracotta
setblock 274 33 495 minecraft:bone_block
fill 274 33 496 274 34 496 minecraft:brown_terracotta
setblock 274 33 500 minecraft:bone_block
fill 274 33 501 274 36 501 minecraft:brown_terracotta
setblock 275 33 464 minecraft:bone_block
fill 275 33 475 275 34 475 minecraft:brown_terracotta
setblock 275 33 479 minecraft:bone_block
fill 275 33 480 275 36 480 minecraft:brown_terracotta
setblock 275 33 484 minecraft:bone_block
fill 275 33 485 275 36 485 minecraft:brown_terracotta
setblock 275 33 489 minecraft:bone_block
fill 275 33 490 275 36 490 minecraft:brown_terracotta
setblock 275 33 494 minecraft:bone_block
fill 275 33 495 275 36 495 minecraft:brown_terracotta
setblock 275 33 499 minecraft:bone_block
fill 275 33 500 275 36 500 minecraft:brown_terracotta
setblock 275 33 504 minecraft:bone_block
fill 276 33 464 276 36 464 minecraft:brown_terracotta
setblock 276 33 467 minecraft:brown_terracotta
setblock 276 33 473 minecraft:bone_block
fill 276 33 474 276 36 474 minecraft:brown_terracotta
setblock 276 33 478 minecraft:bone_block
fill 276 33 479 276 36 479 minecraft:brown_terracotta
setblock 276 33 483 minecraft:bone_block
fill 276 33 484 276 36 484 minecraft:brown_terracotta
setblock 276 33 488 minecraft:bone_block
fill 276 33 489 276 36 489 minecraft:brown_terracotta
setblock 276 33 493 minecraft:bone_block
fill 276 33 494 276 36 494 minecraft:brown_terracotta
setblock 276 33 498 minecraft:bone_block
fill 276 33 499 276 36 499 minecraft:brown_terracotta
setblock 276 33 503 minecraft:bone_block
fill 276 33 504 276 36 504 minecraft:brown_terracotta
setblock 236 34 466 minecraft:brown_terracotta
setblock 236 34 467 minecraft:bone_block
fill 236 34 468 236 37 468 minecraft:brown_terracotta
setblock 236 34 472 minecraft:bone_block
fill 236 34 473 236 37 473 minecraft:brown_terracotta
setblock 236 34 477 minecraft:bone_block
fill 236 34 478 236 37 478 minecraft:brown_terracotta
setblock 236 34 482 minecraft:bone_block
fill 236 34 483 236 37 483 minecraft:brown_terracotta
setblock 236 34 487 minecraft:bone_block
fill 236 34 488 236 37 488 minecraft:brown_terracotta
setblock 236 34 492 minecraft:bone_block
setblock 236 34 493 minecraft:brown_terracotta
setblock 236 34 497 minecraft:bone_block
fill 236 34 498 236 35 498 minecraft:brown_terracotta
setblock 236 34 502 minecraft:bone_block
fill 236 34 503 236 37 503 minecraft:brown_terracotta
setblock 237 34 466 minecraft:bone_block
setblock 237 34 476 minecraft:bone_block
fill 237 34 477 237 36 477 minecraft:brown_terracotta
setblock 237 34 481 minecraft:bone_block
fill 237 34 482 237 37 482 minecraft:brown_terracotta
setblock 237 34 486 minecraft:bone_block
fill 237 34 487 237 37 487 minecraft:brown_terracotta
setblock 238 34 464 minecraft:brown_terracotta
setblock 238 34 465 minecraft:bone_block
setblock 238 34 480 minecraft:bone_block
fill 238 34 481 238 36 481 minecraft:brown_terracotta
setblock 238 34 485 minecraft:bone_block
setblock 239 34 464 minecraft:bone_block
fill 239 34 498 239 37 498 minecraft:bone_block
setblock 239 34 504 minecraft:bone_block
fill 240 34 464 243 34 464 minecraft:brown_terracotta
fill 240 34 497 240 37 497 minecraft:bone_block
fill 240 34 499 240 37 499 minecraft:bone_block
fill 240 34 504 243 34 504 minecraft:brown_terracotta
fill 241 34 498 241 37 498 minecraft:bone_block
setblock 243 34 465 minecraft:bone_block
setblock 244 34 464 minecraft:bone_block
fill 244 34 465 244 37 465 minecraft:brown_terracotta
setblock 244 34 504 minecraft:bone_block
fill 245 34 464 245 37 464 minecraft:brown_terracotta
fill 245 34 504 245 37 504 minecraft:brown_terracotta
fill 246 34 503 246 37 503 minecraft:brown_terracotta
setblock 247 34 466 minecraft:bone_block
setblock 248 34 465 minecraft:bone_block
fill 248 34 466 248 37 466 minecraft:brown_terracotta
fill 248 34 502 250 34 502 minecraft:brown_terracotta
setblock 249 34 464 minecraft:bone_block
fill 249 34 465 249 37 465 minecraft:brown_terracotta
setblock 249 34 504 minecraft:bone_block
fill 250 34 464 250 37 464 minecraft:brown_terracotta
setblock 250 34 503 minecraft:bone_block
fill 250 34 504 250 37 504 minecraft:brown_terracotta
setblock 251 34 502 minecraft:bone_block
fill 251 34 503 251 37 503 minecraft:brown_terracotta
setblock 252 34 465 minecraft:brown_terracotta
setblock 252 34 466 minecraft:bone_block
setblock 252 34 501 minecraft:bone_block
fill 252 34 502 252 37 502 minecraft:brown_terracotta
setblock 253 34 465 minecraft:bone_block
fill 253 34 466 253 37 466 minecraft:brown_terracotta
fill 253 34 501 253 35 501 minecraft:brown_terracotta
setblock 254 34 464 minecraft:bone_block
fill 254 34 465 254 37 465 minecraft:brown_terracotta
setblock 254 34 504 minecraft:bone_block
fill 255 34 464 255 37 464 minecraft:brown_terracotta
setblock 255 34 503 minecraft:bone_block
fill 255 34 504 255 37 504 minecraft:brown_terracotta
setblock 256 34 502 minecraft:bone_block
fill 256 34 503 256 37 503 minecraft:brown_terracotta
fill 257 34 502 257 36 502 minecraft:brown_terracotta
setblock 258 34 465 minecraft:bone_block
setblock 259 34 464 minecraft:bone_block
fill 259 34 465 260 35 465 minecraft:brown_terracotta
setblock 259 34 504 minecraft:bone_block
fill 260 34 464 260 37 464 minecraft:brown_terracotta
setblock 260 34 503 minecraft:bone_block
fill 260 34 504 260 37 504 minecraft:brown_terracotta
setblock 261 34 502 minecraft:bone_block
fill 261 34 503 264 34 503 minecraft:brown_terracotta
fill 262 34 502 265 34 502 minecraft:brown_terracotta
setblock 264 34 464 minecraft:bone_block
setblock 264 34 504 minecraft:bone_block
fill 265 34 464 268 34 464 minecraft:brown_terracotta
setblock 265 34 503 minecraft:bone_block
fill 265 34 504 265 37 504 minecraft:brown_terracotta
setblock 266 34 502 minecraft:bone_block
fill 266 34 503 266 37 503 minecraft:brown_terracotta
fill 267 34 495 269 35 495 minecraft:bone_block
fill 267 34 497 269 35 497 minecraft:bone_block
fill 267 34 502 267 37 502 minecraft:brown_terracotta
fill 268 34 496 268 35 496 minecraft:bone_block
setblock 269 34 464 minecraft:bone_block
fill 269 34 465 270 36 465 minecraft:brown_terracotta
setblock 269 34 504 minecraft:bone_block
fill 270 34 464 270 37 464 minecraft:brown_terracotta
setblock 270 34 503 minecraft:bone_block
fill 270 34 504 270 37 504 minecraft:brown_terracotta
setblock 271 34 502 minecraft:bone_block
fill 271 34 503 271 37 503 minecraft:brown_terracotta
setblock 272 34 465 minecraft:brown_terracotta
setblock 272 34 501 minecraft:bone_block
fill 272 34 502 272 37 502 minecraft:brown_terracotta
setblock 273 34 465 minecraft:bone_block
setblock 273 34 480 minecraft:bone_block
fill 273 34 481 273 36 481 minecraft:brown_terracotta
fill 273 34 483 273 34 484 minecraft:brown_terracotta
setblock 273 34 485 minecraft:bone_block
fill 273 34 486 273 37 486 minecraft:brown_terracotta
fill 273 34 488 273 35 488 minecraft:brown_terracotta
setblock 273 34 500 minecraft:bone_block
setblock 273 34 501 minecraft:brown_terracotta
setblock 274 34 464 minecraft:bone_block
fill 274 34 465 275 36 465 minecraft:brown_terracotta
setblock 274 34 479 minecraft:bone_block
fill 274 34 480 274 37 480 minecraft:brown_terracotta
setblock 274 34 484 minecraft:bone_block
fill 274 34 485 274 37 485 minecraft:brown_terracotta
setblock 274 34 489 minecraft:bone_block
fill 274 34 490 274 37 490 minecraft:brown_terracotta
setblock 274 34 494 minecraft:bone_block
setblock 274 34 495 minecraft:brown_terracotta
setblock 274 34 499 minecraft:bone_block
fill 274 34 500 274 35 500 minecraft:brown_terracotta
setblock 274 34 504 minecraft:bone_block
fill 275 34 464 275 37 464 minecraft:brown_terracotta
setblock 275 34 478 minecraft:bone_block
fill 275 34 479 275 37 479 minecraft:brown_terracotta
setblock 275 34 483 minecraft:bone_block
fill 275 34 484 275 37 484 minecraft:brown_terracotta
setblock 275 34 488 minecraft:bone_block
fill 275 34 489 275 37 489 minecraft:brown_terracotta
setblock 275 34 493 minecraft:bone_block
fill 275 34 494 275 36 494 minecraft:brown_terracotta
setblock 275 34 498 minecraft:bone_block
fill 275 34 499 275 36 499 minecraft:brown_terracotta
setblock 275 34 503 minecraft:bone_block
fill 275 34 504 275 37 504 minecraft:brown_terracotta
setblock 276 34 467 minecraft:bone_block
fill 276 34 468 276 37 468 minecraft:brown_terracotta
setblock 276 34 472 minecraft:bone_block
fill 276 34 473 276 35 473 minecraft:brown_terracotta
setblock 276 34 477 minecraft:bone_block
fill 276 34 478 276 37 478 minecraft:brown_terracotta
setblock 276 34 482 minecraft:bone_block
fill 276 34 483 276 37 483 minecraft:brown_terracotta
setblock 276 34 487 minecraft:bone_block
fill 276 34 488 276 37 488 minecraft:brown_terracotta
setblock 276 34 492 minecraft:bone_block
fill 276 34 493 276 37 493 minecraft:brown_terracotta
setblock 276 34 497 minecraft:bone_block
fill 276 34 498 276 36 498 minecraft:brown_terracotta
setblock 276 34 502 minecraft:bone_block
fill 276 34 503 276 37 503 minecraft:brown_terracotta
setblock 236 35 466 minecraft:bone_block
fill 236 35 467 237 37 467 minecraft:brown_terracotta
setblock 236 35 471 minecraft:bone_block
fill 236 35 472 236 38 472 minecraft:brown_terracotta
setblock 236 35 476 minecraft:bone_block
fill 236 35 477 236 38 477 minecraft:brown_terracotta
setblock 236 35 481 minecraft:bone_block
fill 236 35 482 236 38 482 minecraft:brown_terracotta
setblock 236 35 486 minecraft:bone_block
fill 236 35 487 236 38 487 minecraft:brown_terracotta
fill 236 35 489 236 36 489 minecraft:brown_terracotta
setblock 236 35 491 minecraft:bone_block
setblock 236 35 492 minecraft:brown_terracotta
setblock 236 35 501 minecraft:bone_block
fill 236 35 502 236 36 502 minecraft:brown_terracotta
setblock 237 35 465 minecraft:bone_block
fill 237 35 466 237 38 466 minecraft:brown_terracotta
setblock 237 35 475 minecraft:bone_block
fill 237 35 476 237 36 476 minecraft:brown_terracotta
setblock 237 35 480 minecraft:bone_block
fill 237 35 481 237 38 481 minecraft:brown_terracotta
setblock 237 35 485 minecraft:bone_block
fill 237 35 486 237 38 486 minecraft:brown_terracotta
setblock 238 35 464 minecraft:bone_block
fill 238 35 465 241 35 465 minecraft:brown_terracotta
setblock 238 35 479 minecraft:bone_block
setblock 238 35 480 minecraft:brown_terracotta
setblock 238 35 484 minecraft:bone_block
setblock 238 35 485 minecraft:brown_terracotta
setblock 238 35 504 minecraft:bone_block
fill 239 35 464 242 35 464 minecraft:brown_terracotta
fill 239 35 489 239 45 489 minecraft:soul_soil
fill 239 35 504 242 35 504 minecraft:brown_terracotta
setblock 242 35 465 minecraft:bone_block
setblock 243 35 464 minecraft:bone_block
fill 243 35 465 243 38 465 minecraft:brown_terracotta
setblock 243 35 504 minecraft:bone_block
fill 244 35 464 244 38 464 minecraft:brown_terracotta
fill 244 35 504 244 38 504 minecraft:brown_terracotta
fill 245 35 503 245 37 503 minecraft:brown_terracotta
setblock 246 35 466 minecraft:bone_block
setblock 247 35 464 minecraft:brown_terracotta
setblock 247 35 465 minecraft:bone_block
fill 247 35 466 247 38 466 minecraft:brown_terracotta
setblock 248 35 464 minecraft:bone_block
fill 248 35 465 248 38 465 minecraft:brown_terracotta
fill 248 35 502 249 35 502 minecraft:brown_terracotta
setblock 248 35 504 minecraft:bone_block
fill 249 35 464 249 38 464 minecraft:brown_terracotta
setblock 249 35 503 minecraft:bone_block
fill 249 35 504 249 38 504 minecraft:brown_terracotta
setblock 250 35 466 minecraft:brown_terracotta
setblock 250 35 467 minecraft:bone_block
setblock 250 35 502 minecraft:bone_block
fill 250 35 503 250 38 503 minecraft:brown_terracotta
setblock 251 35 466 minecraft:bone_block
fill 251 35 467 252 37 467 minecraft:brown_terracotta
fill 251 35 502 251 38 502 minecraft:brown_terracotta
setblock 252 35 465 minecraft:bone_block
fill 252 35 466 252 38 466 minecraft:brown_terracotta
setblock 253 35 464 minecraft:bone_block
fill 253 35 465 253 38 465 minecraft:brown_terracotta
setblock 253 35 504 minecraft:bone_block
fill 254 35 464 254 38 464 minecraft:brown_terracotta
setblock 254 35 503 minecraft:bone_block
fill 254 35 504 254 38 504 minecraft:brown_terracotta
setblock 255 35 466 minecraft:brown_terracotta
setblock 255 35 502 minecraft:bone_block
fill 255 35 503 255 38 503 minecraft:brown_terracotta
setblock 256 35 466 minecraft:bone_block
fill 256 35 502 256 37 502 minecraft:brown_terracotta
setblock 257 35 465 minecraft:bone_block
setblock 258 35 464 minecraft:bone_block
fill 258 35 465 258 37 465 minecraft:brown_terracotta
setblock 258 35 504 minecraft:bone_block
fill 259 35 464 259 38 464 minecraft:brown_terracotta
setblock 259 35 503 minecraft:bone_block
fill 259 35 504 259 38 504 minecraft:brown_terracotta
setblock 260 35 502 minecraft:bone_block
fill 260 35 503 263 35 503 minecraft:brown_terracotta
setblock 263 35 464 minecraft:bone_block
setblock 263 35 504 minecraft:bone_block
fill 264 35 464 267 35 464 minecraft:brown_terracotta
setblock 264 35 502 minecraft:brown_terracotta
setblock 264 35 503 minecraft:bone_block
fill 264 35 504 264 38 504 minecraft:brown_terracotta
setblock 265 35 502 minecraft:bone_block
fill 265 35 503 265 38 503 minecraft:brown_terracotta
fill 266 35 502 266 37 502 minecraft:brown_terracotta
setblock 267 35 465 minecraft:bone_block
setblock 268 35 464 minecraft:bone_block
fill 268 35 465 268 38 465 minecraft:brown_terracotta
setblock 268 35 504 minecraft:bone_block
fill 269 35 464 269 38 464 minecraft:brown_terracotta
fill 269 35 496 270 36 496 minecraft:bone_block
setblock 269 35 503 minecraft:bone_block
fill 269 35 504 269 38 504 minecraft:brown_terracotta
setblock 270 35 502 minecraft:bone_block
fill 270 35 503 270 38 503 minecraft:brown_terracotta
setblock 271 35 501 minecraft:bone_block
fill 271 35 502 271 37 502 minecraft:brown_terracotta
setblock 272 35 465 minecraft:bone_block
setblock 272 35 501 minecraft:brown_terracotta
setblock 273 35 464 minecraft:bone_block
fill 273 35 465 273 38 465 minecraft:brown_terracotta
setblock 273 35 480 minecraft:brown_terracotta
setblock 273 35 483 minecraft:brown_terracotta
setblock 273 35 484 minecraft:bone_block
fill 273 35 485 273 38 485 minecraft:brown_terracotta
setblock 273 35 489 minecraft:bone_block
setblock 273 35 504 minecraft:bone_block
fill 274 35 464 274 38 464 minecraft:brown_terracotta
setblock 274 35 478 minecraft:bone_block
fill 274 35 479 274 36 479 minecraft:brown_terracotta
setblock 274 35 483 minecraft:bone_block
fill 274 35 484 274 38 484 minecraft:brown_terracotta
setblock 274 35 488 minecraft:bone_block
fill 274 35 489 274 38 489 minecraft:brown_terracotta
setblock 274 35 492 minecraft:brown_terracotta
setblock 274 35 498 minecraft:bone_block
setblock 274 35 499 minecraft:brown_terracotta
setblock 274 35 503 minecraft:bone_block
fill 274 35 504 274 38 504 minecraft:brown_terracotta
setblock 275 35 477 minecraft:bone_block
fill 275 35 478 275 37 478 minecraft:brown_terracotta
setblock 275 35 482 minecraft:bone_block
fill 275 35 483 275 38 483 minecraft:brown_terracotta
setblock 275 35 487 minecraft:bone_block
fill 275 35 488 275 38 488 minecraft:brown_terracotta
setblock 275 35 492 minecraft:bone_block
fill 275 35 493 275 37 493 minecraft:brown_terracotta
setblock 275 35 497 minecraft:bone_block
fill 275 35 498 275 36 498 minecraft:brown_terracotta
setblock 275 35 502 minecraft:bone_block
fill 275 35 503 275 37 503 minecraft:brown_terracotta
setblock 276 35 465 minecraft:brown_terracotta
setblock 276 35 466 minecraft:bone_block
fill 276 35 467 276 38 467 minecraft:brown_terracotta
setblock 276 35 469 minecraft:brown_terracotta
setblock 276 35 476 minecraft:bone_block
fill 276 35 477 276 38 477 minecraft:brown_terracotta
setblock 276 35 481 minecraft:bone_block
fill 276 35 482 276 38 482 minecraft:brown_terracotta
setblock 276 35 486 minecraft:bone_block
fill 276 35 487 276 38 487 minecraft:brown_terracotta
setblock 276 35 491 minecraft:bone_block
fill 276 35 492 276 38 492 minecraft:brown_terracotta
setblock 276 35 496 minecraft:bone_block
fill 276 35 497 276 36 497 minecraft:brown_terracotta
setblock 276 35 501 minecraft:bone_block
fill 276 35 502 276 37 502 minecraft:brown_terracotta
setblock 236 36 465 minecraft:bone_block
fill 236 36 466 236 39 466 minecraft:brown_terracotta
setblock 236 36 470 minecraft:bone_block
fill 236 36 471 236 39 471 minecraft:brown_terracotta
setblock 236 36 475 minecraft:bone_block
fill 236 36 476 236 38 476 minecraft:brown_terracotta
setblock 236 36 480 minecraft:bone_block
fill 236 36 481 236 39 481 minecraft:brown_terracotta
setblock 236 36 485 minecraft:bone_block
fill 236 36 486 236 39 486 minecraft:brown_terracotta
setblock 236 36 490 minecraft:bone_block
fill 236 36 491 236 37 491 minecraft:brown_terracotta
setblock 236 36 501 minecraft:brown_terracotta
setblock 237 36 464 minecraft:bone_block
fill 237 36 465 240 36 465 minecraft:brown_terracotta
setblock 237 36 479 minecraft:bone_block
fill 237 36 480 237 37 480 minecraft:brown_terracotta
setblock 237 36 484 minecraft:bone_block
fill 237 36 485 237 38 485 minecraft:brown_terracotta
setblock 237 36 504 minecraft:bone_block
fill 238 36 464 241 36 464 minecraft:brown_terracotta
setblock 238 36 483 minecraft:bone_block
setblock 238 36 484 minecraft:brown_terracotta
fill 238 36 504 241 36 504 minecraft:brown_terracotta
fill 239 36 497 239 37 497 minecraft:bone_block
fill 239 36 499 239 37 499 minecraft:bone_block
setblock 241 36 465 minecraft:bone_block
fill 241 36 497 241 37 497 minecraft:bone_block
fill 241 36 499 241 37 499 minecraft:bone_block
setblock 242 36 464 minecraft:bone_block
fill 242 36 465 242 39 465 minecraft:brown_terracotta
setblock 242 36 504 minecraft:bone_block
fill 243 36 464 243 39 464 minecraft:brown_terracotta
fill 243 36 504 243 39 504 minecraft:brown_terracotta
setblock 245 36 465 minecraft:brown_terracotta
setblock 245 36 466 minecraft:bone_block
setblock 246 36 465 minecraft:bone_block
fill 246 36 466 246 39 466 minecraft:brown_terracotta
setblock 247 36 464 minecraft:bone_block
fill 247 36 465 247 39 465 minecraft:brown_terracotta
setblock 247 36 504 minecraft:bone_block
fill 248 36 464 248 39 464 minecraft:brown_terracotta
setblock 248 36 502 minecraft:brown_terracotta
setblock 248 36 503 minecraft:bone_block
fill 248 36 504 248 39 504 minecraft:brown_terracotta
setblock 249 36 467 minecraft:bone_block
setblock 249 36 502 minecraft:bone_block
fill 249 36 503 249 39 503 minecraft:brown_terracotta
setblock 250 36 466 minecraft:bone_block
fill 250 36 467 250 39 467 minecraft:brown_terracotta
fill 250 36 502 250 38 502 minecraft:brown_terracotta
setblock 251 36 465 minecraft:bone_block
fill 251 36 466 251 39 466 minecraft:brown_terracotta
setblock 252 36 464 minecraft:bone_block
fill 252 36 465 252 39 465 minecraft:brown_terracotta
setblock 252 36 504 minecraft:bone_block
fill 253 36 464 253 39 464 minecraft:brown_terracotta
setblock 253 36 503 minecraft:bone_block
fill 253 36 504 253 39 504 minecraft:brown_terracotta
setblock 254 36 502 minecraft:bone_block
fill 254 36 503 254 39 503 minecraft:brown_terracotta
setblock 255 36 466 minecraft:bone_block
fill 255 36 502 255 37 502 minecraft:brown_terracotta
setblock 256 36 465 minecraft:bone_block
setblock 256 36 466 minecraft:brown_terracotta
setblock 257 36 464 minecraft:bone_block
fill 257 36 465 257 38 465 minecraft:brown_terracotta
setblock 257 36 504 minecraft:bone_block
fill 258 36 464 258 39 464 minecraft:brown_terracotta
setblock 258 36 503 minecraft:bone_block
fill 258 36 504 258 39 504 minecraft:brown_terracotta
setblock 259 36 465 minecraft:brown_terracotta
fill 259 36 503 262 36 503 minecraft:brown_terracotta
setblock 262 36 464 minecraft:bone_block
setblock 262 36 504 minecraft:bone_block
fill 263 36 464 266 36 464 minecraft:brown_terracotta
setblock 263 36 503 minecraft:bone_block
fill 263 36 504 263 39 504 minecraft:brown_terracotta
fill 264 36 503 264 39 503 minecraft:brown_terracotta
setblock 265 36 502 minecraft:brown_terracotta
setblock 267 36 464 minecraft:bone_block
fill 267 36 465 267 39 465 minecraft:brown_terracotta
setblock 267 36 504 minecraft:bone_block
fill 268 36 464 268 39 464 minecraft:brown_terracotta
setblock 268 36 503 minecraft:bone_block
fill 268 36 504 268 39 504 minecraft:brown_terracotta
setblock 269 36 502 minecraft:bone_block
fill 269 36 503 269 39 503 minecraft:brown_terracotta
fill 270 36 502 270 38 502 minecraft:brown_terracotta
setblock 271 36 464 minecraft:brown_terracotta
setblock 271 36 465 minecraft:bone_block
fill 271 36 496 271 37 496 minecraft:bone_block
setblock 272 36 464 minecraft:bone_block
fill 272 36 465 272 39 465 minecraft:brown_terracotta
setblock 272 36 504 minecraft:bone_block
fill 273 36 464 273 39 464 minecraft:brown_terracotta
setblock 273 36 483 minecraft:bone_block
fill 273 36 484 273 38 484 minecraft:brown_terracotta
setblock 273 36 488 minecraft:bone_block
fill 273 36 489 273 37 489 minecraft:brown_terracotta
setblock 273 36 503 minecraft:bone_block
fill 273 36 504 273 39 504 minecraft:brown_terracotta
setblock 274 36 482 minecraft:bone_block
fill 274 36 483 274 39 483 minecraft:brown_terracotta
setblock 274 36 487 minecraft:bone_block
fill 274 36 488 274 39 488 minecraft:brown_terracotta
setblock 274 36 502 minecraft:bone_block
fill 274 36 503 274 37 503 minecraft:brown_terracotta
setblock 275 36 477 minecraft:brown_terracotta
setblock 275 36 481 minecraft:bone_block
fill 275 36 482 275 39 482 minecraft:brown_terracotta
setblock 275 36 486 minecraft:bone_block
fill 275 36 487 275 39 487 minecraft:brown_terracotta
setblock 275 36 491 minecraft:bone_block
fill 275 36 492 275 38 492 minecraft:brown_terracotta
setblock 275 36 497 minecraft:brown_terracotta
setblock 275 36 501 minecraft:bone_block
fill 275 36 502 275 37 502 minecraft:brown_terracotta
setblock 276 36 465 minecraft:bone_block
fill 276 36 466 276 39 466 minecraft:brown_terracotta
setblock 276 36 475 minecraft:bone_block
fill 276 36 476 276 37 476 minecraft:brown_terracotta
setblock 276 36 480 minecraft:bone_block
fill 276 36 481 276 39 481 minecraft:brown_terracotta
setblock 276 36 485 minecraft:bone_block
fill 276 36 486 276 39 486 minecraft:brown_terracotta
setblock 276 36 490 minecraft:bone_block
fill 276 36 491 276 39 491 minecraft:brown_terracotta
setblock 276 36 495 minecraft:bone_block
setblock 276 36 496 minecraft:brown_terracotta
setblock 276 36 500 minecraft:bone_block
fill 276 36 501 276 37 501 minecraft:brown_terracotta
setblock 236 37 464 minecraft:bone_block
fill 236 37 465 239 37 465 minecraft:brown_terracotta
setblock 236 37 469 minecraft:bone_block
fill 236 37 470 236 40 470 minecraft:brown_terracotta
setblock 236 37 474 minecraft:bone_block
fill 236 37 475 236 38 475 minecraft:brown_terracotta
setblock 236 37 479 minecraft:bone_block
fill 236 37 480 236 39 480 minecraft:brown_terracotta
setblock 236 37 484 minecraft:bone_block
fill 236 37 485 236 40 485 minecraft:brown_terracotta
setblock 236 37 489 minecraft:bone_block
fill 236 37 490 236 38 490 minecraft:brown_terracotta
setblock 236 37 504 minecraft:bone_block
fill 237 37 464 240 37 464 minecraft:brown_terracotta
setblock 237 37 478 minecraft:bone_block
setblock 237 37 479 minecraft:brown_terracotta
setblock 237 37 483 minecraft:bone_block
fill 237 37 484 237 38 484 minecraft:brown_terracotta
setblock 237 37 504 minecraft:brown_terracotta
setblock 240 37 465 minecraft:bone_block
setblock 241 37 464 minecraft:bone_block
fill 241 37 465 241 40 465 minecraft:brown_terracotta
fill 242 37 464 242 40 464 minecraft:brown_terracotta
fill 242 37 504 242 38 504 minecraft:brown_terracotta
setblock 245 37 465 minecraft:bone_block
fill 245 37 466 245 40 466 minecraft:brown_terracotta
setblock 246 37 464 minecraft:bone_block
fill 246 37 465 246 40 465 minecraft:brown_terracotta
setblock 246 37 504 minecraft:bone_block
fill 247 37 464 247 40 464 minecraft:brown_terracotta
setblock 247 37 503 minecraft:bone_block
fill 247 37 504 247 40 504 minecraft:brown_terracotta
setblock 248 37 467 minecraft:bone_block
fill 248 37 503 248 40 503 minecraft:brown_terracotta
setblock 249 37 466 minecraft:bone_block
fill 249 37 467 249 40 467 minecraft:brown_terracotta
fill 249 37 502 249 38 502 minecraft:brown_terracotta
setblock 250 37 465 minecraft:bone_block
fill 250 37 466 250 40 466 minecraft:brown_terracotta
setblock 251 37 464 minecraft:bone_block
fill 251 37 465 251 40 465 minecraft:brown_terracotta
setblock 251 37 504 minecraft:bone_block
fill 252 37 464 252 40 464 minecraft:brown_terracotta
setblock 252 37 503 minecraft:bone_block
fill 252 37 504 252 40 504 minecraft:brown_terracotta
setblock 253 37 502 minecraft:bone_block
fill 253 37 503 253 40 503 minecraft:brown_terracotta
setblock 254 37 466 minecraft:bone_block
setblock 254 37 502 minecraft:brown_terracotta
setblock 255 37 465 minecraft:bone_block
setblock 255 37 466 minecraft:brown_terracotta
setblock 256 37 464 minecraft:bone_block
fill 256 37 465 256 39 465 minecraft:brown_terracotta
setblock 256 37 504 minecraft:bone_block
fill 257 37 464 257 40 464 minecraft:brown_terracotta
setblock 257 37 503 minecraft:bone_block
fill 257 37 504 257 40 504 minecraft:brown_terracotta
fill 258 37 503 261 37 503 minecraft:brown_terracotta
setblock 261 37 464 minecraft:bone_block
setblock 261 37 504 minecraft:bone_block
fill 262 37 464 265 37 464 minecraft:brown_terracotta
setblock 262 37 503 minecraft:bone_block
fill 262 37 504 262 40 504 minecraft:brown_terracotta
fill 263 37 503 263 38 503 minecraft:brown_terracotta
setblock 266 37 464 minecraft:bone_block
fill 266 37 465 266 39 465 minecraft:brown_terracotta
setblock 266 37 504 minecraft:bone_block
fill 267 37 464 267 40 464 minecraft:brown_terracotta
setblock 267 37 503 minecraft:bone_block
fill 267 37 504 267 40 504 minecraft:brown_terracotta
setblock 268 37 502 minecraft:bone_block
fill 268 37 503 268 40 503 minecraft:brown_terracotta
setblock 269 37 465 minecraft:brown_terracotta
fill 269 37 502 269 38 502 minecraft:brown_terracotta
setblock 270 37 465 minecraft:bone_block
setblock 271 37 464 minecraft:bone_block
fill 271 37 465 271 40 465 minecraft:brown_terracotta
setblock 271 37 504 minecraft:bone_block
fill 272 37 464 272 40 464 minecraft:brown_terracotta
fill 272 37 496 273 38 496 minecraft:bone_block
setblock 272 37 503 minecraft:bone_block
fill 272 37 504 272 40 504 minecraft:brown_terracotta
setblock 273 37 482 minecraft:bone_block
fill 273 37 483 273 38 483 minecraft:brown_terracotta
setblock 273 37 487 minecraft:bone_block
fill 273 37 488 273 38 488 minecraft:brown_terracotta
fill 273 37 503 273 38 503 minecraft:brown_terracotta
setblock 274 37 465 minecraft:brown_terracotta
setblock 274 37 481 minecraft:bone_block
fill 274 37 482 274 39 482 minecraft:brown_terracotta
setblock 274 37 486 minecraft:bone_block
fill 274 37 487 274 40 487 minecraft:brown_terracotta
setblock 274 37 491 minecraft:bone_block
setblock 275 37 480 minecraft:bone_block
fill 275 37 481 275 39 481 minecraft:brown_terracotta
setblock 275 37 485 minecraft:bone_block
fill 275 37 486 275 40 486 minecraft:brown_terracotta
setblock 275 37 490 minecraft:bone_block
fill 275 37 491 275 40 491 minecraft:brown_terracotta
setblock 276 37 464 minecraft:bone_block
fill 276 37 465 276 39 465 minecraft:brown_terracotta
setblock 276 37 479 minecraft:bone_block
fill 276 37 480 276 40 480 minecraft:brown_terracotta
setblock 276 37 484 minecraft:bone_block
fill 276 37 485 276 40 485 minecraft:brown_terracotta
setblock 276 37 489 minecraft:bone_block
fill 276 37 490 276 40 490 minecraft:brown_terracotta
setblock 276 37 494 minecraft:bone_block
setblock 276 37 495 minecraft:brown_terracotta
setblock 276 37 499 minecraft:bone_block
setblock 276 37 500 minecraft:brown_terracotta
setblock 276 37 504 minecraft:bone_block
fill 236 38 464 237 38 465 minecraft:brown_terracotta
setblock 236 38 467 minecraft:brown_terracotta
setblock 236 38 468 minecraft:bone_block
fill 236 38 469 236 41 469 minecraft:brown_terracotta
setblock 236 38 473 minecraft:bone_block
setblock 236 38 474 minecraft:brown_terracotta
setblock 236 38 478 minecraft:bone_block
fill 236 38 479 236 39 479 minecraft:brown_terracotta
setblock 236 38 483 minecraft:bone_block
fill 236 38 484 236 41 484 minecraft:brown_terracotta
setblock 236 38 488 minecraft:bone_block
fill 236 38 489 236 40 489 minecraft:brown_terracotta
setblock 237 38 482 minecraft:bone_block
setblock 237 38 483 minecraft:brown_terracotta
fill 238 38 464 239 38 464 minecraft:brown_terracotta
setblock 240 38 464 minecraft:bone_block
fill 240 38 465 240 39 465 minecraft:brown_terracotta
fill 241 38 464 241 41 464 minecraft:brown_terracotta
setblock 244 38 465 minecraft:bone_block
fill 244 38 466 244 41 466 minecraft:brown_terracotta
setblock 245 38 464 minecraft:bone_block
fill 245 38 465 245 41 465 minecraft:brown_terracotta
setblock 245 38 504 minecraft:bone_block
fill 246 38 464 246 41 464 minecraft:brown_terracotta
setblock 246 38 503 minecraft:bone_block
fill 246 38 504 246 41 504 minecraft:brown_terracotta
fill 247 38 503 247 41 503 minecraft:brown_terracotta
setblock 248 38 466 minecraft:bone_block
fill 248 38 467 248 41 467 minecraft:brown_terracotta
setblock 249 38 465 minecraft:bone_block
fill 249 38 466 249 41 466 minecraft:brown_terracotta
setblock 250 38 464 minecraft:bone_block
fill 250 38 465 250 41 465 minecraft:brown_terracotta
setblock 250 38 504 minecraft:bone_block
fill 251 38 464 251 41 464 minecraft:brown_terracotta
setblock 251 38 467 minecraft:brown_terracotta
setblock 251 38 503 minecraft:bone_block
fill 251 38 504 251 41 504 minecraft:brown_terracotta
setblock 252 38 502 minecraft:bone_block
fill 252 38 503 252 41 503 minecraft:brown_terracotta
setblock 253 38 466 minecraft:bone_block
setblock 253 38 502 minecraft:brown_terracotta
setblock 254 38 465 minecraft:bone_block
fill 254 38 466 254 39 466 minecraft:brown_terracotta
setblock 255 38 464 minecraft:bone_block
fill 255 38 465 255 41 465 minecraft:brown_terracotta
setblock 255 38 504 minecraft:bone_block
fill 256 38 464 256 41 464 minecraft:brown_terracotta
setblock 256 38 503 minecraft:bone_block
fill 256 38 504 256 41 504 minecraft:brown_terracotta
fill 257 38 503 260 38 503 minecraft:brown_terracotta
setblock 260 38 464 minecraft:bone_block
setblock 260 38 504 minecraft:bone_block
fill 261 38 464 264 38 464 minecraft:brown_terracotta
setblock 261 38 503 minecraft:bone_block
fill 261 38 504 261 41 504 minecraft:brown_terracotta
setblock 262 38 503 minecraft:brown_terracotta
fill 264 38 486 264 39 487 minecraft:soul_soil
setblock 265 38 464 minecraft:bone_block
setblock 265 38 504 minecraft:bone_block
fill 266 38 464 266 41 464 minecraft:brown_terracotta
setblock 266 38 503 minecraft:bone_block
fill 266 38 504 266 41 504 minecraft:brown_terracotta
fill 267 38 503 267 40 503 minecraft:brown_terracotta
setblock 268 38 502 minecraft:brown_terracotta
setblock 269 38 465 minecraft:bone_block
setblock 270 38 464 minecraft:bone_block
fill 270 38 465 270 41 465 minecraft:brown_terracotta
setblock 270 38 504 minecraft:bone_block
fill 271 38 464 271 41 464 minecraft:brown_terracotta
setblock 271 38 503 minecraft:bone_block
fill 271 38 504 271 41 504 minecraft:brown_terracotta
fill 272 38 503 272 39 503 minecraft:brown_terracotta
setblock 273 38 486 minecraft:bone_block
fill 273 38 487 273 39 487 minecraft:brown_terracotta
fill 273 38 495 275 39 495 minecraft:bone_block
fill 273 38 497 275 39 497 minecraft:bone_block
setblock 274 38 481 minecraft:brown_terracotta
setblock 274 38 485 minecraft:bone_block
fill 274 38 486 274 41 486 minecraft:brown_terracotta
setblock 274 38 490 minecraft:bone_block
fill 274 38 496 274 39 496 minecraft:bone_block
setblock 275 38 464 minecraft:bone_block
setblock 275 38 479 minecraft:bone_block
setblock 275 38 480 minecraft:brown_terracotta
setblock 275 38 484 minecraft:bone_block
fill 275 38 485 275 41 485 minecraft:brown_terracotta
setblock 275 38 489 minecraft:bone_block
fill 275 38 490 275 41 490 minecraft:brown_terracotta
setblock 275 38 504 minecraft:bone_block
fill 276 38 464 276 39 464 minecraft:brown_terracotta
setblock 276 38 478 minecraft:bone_block
fill 276 38 479 276 39 479 minecraft:brown_terracotta
setblock 276 38 483 minecraft:bone_block
fill 276 38 484 276 41 484 minecraft:brown_terracotta
setblock 276 38 488 minecraft:bone_block
fill 276 38 489 276 41 489 minecraft:brown_terracotta
setblock 276 38 493 minecraft:bone_block
setblock 276 38 503 minecraft:bone_block
setblock 276 38 504 minecraft:brown_terracotta
fill 236 39 464 236 40 465 minecraft:brown_terracotta
setblock 236 39 467 minecraft:bone_block
fill 236 39 468 236 42 468 minecraft:brown_terracotta
setblock 236 39 472 minecraft:bone_block
setblock 236 39 478 minecraft:brown_terracotta
setblock 236 39 482 minecraft:bone_block
fill 236 39 483 236 41 483 minecraft:brown_terracotta
setblock 236 39 487 minecraft:bone_block
fill 236 39 488 236 41 488 minecraft:brown_terracotta
fill 237 39 464 238 39 464 minecraft:brown_terracotta
setblock 239 39 464 minecraft:bone_block
fill 240 39 464 240 42 464 minecraft:brown_terracotta
setblock 243 39 465 minecraft:bone_block
setblock 244 39 464 minecraft:bone_block
fill 244 39 465 244 42 465 minecraft:brown_terracotta
setblock 244 39 504 minecraft:bone_block
fill 245 39 464 245 42 464 minecraft:brown_terracotta
fill 245 39 504 245 42 504 minecraft:brown_terracotta
fill 246 39 503 246 40 503 minecraft:brown_terracotta
setblock 247 39 466 minecraft:bone_block
setblock 248 39 465 minecraft:bone_block
fill 248 39 466 248 42 466 minecraft:brown_terracotta
setblock 249 39 464 minecraft:bone_block
fill 249 39 465 249 42 465 minecraft:brown_terracotta
setblock 249 39 504 minecraft:bone_block
fill 250 39 464 250 42 464 minecraft:brown_terracotta
setblock 250 39 503 minecraft:bone_block
fill 250 39 504 250 42 504 minecraft:brown_terracotta
fill 251 39 503 251 42 503 minecraft:brown_terracotta
setblock 252 39 466 minecraft:bone_block
setblock 253 39 465 minecraft:bone_block
fill 253 39 466 253 40 466 minecraft:brown_terracotta
setblock 254 39 464 minecraft:bone_block
fill 254 39 465 254 42 465 minecraft:brown_terracotta
setblock 254 39 504 minecraft:bone_block
fill 255 39 464 255 42 464 minecraft:brown_terracotta
setblock 255 39 503 minecraft:bone_block
fill 255 39 504 255 42 504 minecraft:brown_terracotta
setblock 256 39 503 minecraft:brown_terracotta
setblock 259 39 464 minecraft:bone_block
setblock 259 39 504 minecraft:bone_block
fill 260 39 464 263 39 464 minecraft:brown_terracotta
fill 260 39 504 260 41 504 minecraft:brown_terracotta
setblock 264 39 464 minecraft:bone_block
setblock 264 39 504 minecraft:bone_block
fill 265 39 464 265 42 464 minecraft:brown_terracotta
setblock 265 39 503 minecraft:bone_block
fill 265 39 504 265 42 504 minecraft:brown_terracotta
fill 266 39 503 266 40 503 minecraft:brown_terracotta
setblock 268 39 465 minecraft:bone_block
setblock 269 39 464 minecraft:bone_block
fill 269 39 465 269 42 465 minecraft:brown_terracotta
setblock 269 39 504 minecraft:bone_block
fill 270 39 464 270 42 464 minecraft:brown_terracotta
setblock 270 39 503 minecraft:bone_block
fill 270 39 504 270 42 504 minecraft:brown_terracotta
setblock 271 39 503 minecraft:brown_terracotta
setblock 273 39 485 minecraft:bone_block
setblock 273 39 486 minecraft:brown_terracotta
setblock 274 39 464 minecraft:bone_block
setblock 274 39 484 minecraft:bone_block
fill 274 39 485 274 40 485 minecraft:brown_terracotta
setblock 274 39 489 minecraft:bone_block
setblock 274 39 490 minecraft:brown_terracotta
setblock 274 39 504 minecraft:bone_block
setblock 275 39 464 minecraft:brown_terracotta
setblock 275 39 483 minecraft:bone_block
fill 275 39 484 275 41 484 minecraft:brown_terracotta
setblock 275 39 488 minecraft:bone_block
fill 275 39 489 275 42 489 minecraft:brown_terracotta
setblock 275 39 504 minecraft:brown_terracotta
setblock 276 39 467 minecraft:bone_block
setblock 276 39 482 minecraft:bone_block
fill 276 39 483 276 42 483 minecraft:brown_terracotta
setblock 276 39 487 minecraft:bone_block
fill 276 39 488 276 42 488 minecraft:brown_terracotta
setblock 276 39 492 minecraft:bone_block
setblock 236 40 466 minecraft:bone_block
fill 236 40 467 236 43 467 minecraft:brown_terracotta
setblock 236 40 471 minecraft:bone_block
setblock 236 40 481 minecraft:bone_block
setblock 236 40 482 minecraft:brown_terracotta
setblock 236 40 486 minecraft:bone_block
fill 236 40 487 236 42 487 minecraft:brown_terracotta
setblock 237 40 464 minecraft:brown_terracotta
setblock 238 40 464 minecraft:bone_block
setblock 238 40 466 minecraft:light[level=12]
setblock 238 40 474 minecraft:light[level=12]
setblock 238 40 482 minecraft:light[level=12]
setblock 238 40 490 minecraft:light[level=12]
setblock 238 40 498 minecraft:light[level=12]
fill 239 40 464 239 43 464 minecraft:brown_terracotta
setblock 242 40 465 minecraft:bone_block
setblock 243 40 464 minecraft:bone_block
fill 243 40 465 243 43 465 minecraft:brown_terracotta
setblock 243 40 504 minecraft:bone_block
fill 244 40 464 244 43 464 minecraft:brown_terracotta
fill 244 40 504 244 43 504 minecraft:brown_terracotta
setblock 246 40 466 minecraft:bone_block
setblock 246 40 474 minecraft:light[level=12]
setblock 246 40 482 minecraft:light[level=12]
setblock 246 40 490 minecraft:light[level=12]
setblock 246 40 498 minecraft:light[level=12]
setblock 247 40 465 minecraft:bone_block
fill 247 40 466 247 42 467 minecraft:brown_terracotta
setblock 248 40 464 minecraft:bone_block
fill 248 40 465 248 43 465 minecraft:brown_terracotta
setblock 248 40 504 minecraft:bone_block
fill 249 40 464 249 43 464 minecraft:brown_terracotta
setblock 249 40 503 minecraft:bone_block
fill 249 40 504 249 43 504 minecraft:brown_terracotta
fill 250 40 503 250 43 503 minecraft:brown_terracotta
setblock 251 40 466 minecraft:bone_block
setblock 252 40 465 minecraft:bone_block
fill 252 40 466 252 42 466 minecraft:brown_terracotta
setblock 253 40 464 minecraft:bone_block
fill 253 40 465 253 43 465 minecraft:brown_terracotta
setblock 253 40 504 minecraft:bone_block
fill 254 40 464 254 43 464 minecraft:brown_terracotta
setblock 254 40 466 minecraft:light[level=12]
setblock 254 40 474 minecraft:light[level=12]
setblock 254 40 482 minecraft:light[level=12]
setblock 254 40 490 minecraft:light[level=12]
setblock 254 40 498 minecraft:light[level=12]
setblock 254 40 503 minecraft:bone_block
fill 254 40 504 254 43 504 minecraft:brown_terracotta
setblock 258 40 464 minecraft:bone_block
setblock 258 40 504 minecraft:bone_block
fill 259 40 464 262 40 464 minecraft:brown_terracotta
fill 259 40 504 259 41 504 minecraft:brown_terracotta
setblock 262 40 466 minecraft:light[level=12]
setblock 262 40 474 minecraft:light[level=12]
setblock 262 40 482 minecraft:light[level=12]
setblock 262 40 490 minecraft:light[level=12]
setblock 262 40 498 minecraft:light[level=12]
setblock 263 40 464 minecraft:bone_block
setblock 263 40 504 minecraft:bone_block
fill 264 40 464 264 43 464 minecraft:brown_terracotta
fill 264 40 504 264 43 504 minecraft:brown_terracotta
setblock 265 40 503 minecraft:brown_terracotta
setblock 267 40 465 minecraft:bone_block
setblock 268 40 464 minecraft:bone_block
fill 268 40 465 268 43 465 minecraft:brown_terracotta
setblock 268 40 504 minecraft:bone_block
fill 269 40 464 269 43 464 minecraft:brown_terracotta
setblock 269 40 503 minecraft:bone_block
fill 269 40 504 269 43 504 minecraft:brown_terracotta
setblock 270 40 466 minecraft:light[level=12]
setblock 270 40 474 minecraft:light[level=12]
setblock 270 40 482 minecraft:light[level=12]
setblock 270 40 490 minecraft:light[level=12]
setblock 270 40 498 minecraft:light[level=12]
setblock 270 40 503 minecraft:brown_terracotta
setblock 273 40 464 minecraft:bone_block
setblock 273 40 504 minecraft:bone_block
setblock 274 40 464 minecraft:brown_terracotta
setblock 274 40 484 minecraft:brown_terracotta
setblock 274 40 488 minecraft:bone_block
setblock 274 40 489 minecraft:brown_terracotta
setblock 275 40 482 minecraft:bone_block
fill 275 40 483 275 41 483 minecraft:brown_terracotta
setblock 275 40 487 minecraft:bone_block
fill 275 40 488 275 43 488 minecraft:brown_terracotta
setblock 276 40 481 minecraft:bone_block
fill 276 40 482 276 42 482 minecraft:brown_terracotta
setblock 276 40 486 minecraft:bone_block
fill 276 40 487 276 43 487 minecraft:brown_terracotta
setblock 276 40 491 minecraft:bone_block
fill 276 40 492 276 43 492 minecraft:brown_terracotta
setblock 236 41 464 minecraft:brown_terracotta
setblock 236 41 465 minecraft:bone_block
fill 236 41 466 236 44 466 minecraft:brown_terracotta
setblock 236 41 470 minecraft:bone_block
fill 236 41 471 236 44 471 minecraft:brown_terracotta
setblock 236 41 485 minecraft:bone_block
fill 236 41 486 236 42 486 minecraft:brown_terracotta
setblock 237 41 464 minecraft:bone_block
fill 238 41 464 238 44 464 minecraft:brown_terracotta
setblock 240 41 465 minecraft:brown_terracotta
setblock 241 41 465 minecraft:bone_block
setblock 242 41 464 minecraft:bone_block
fill 242 41 465 242 44 465 minecraft:brown_terracotta
fill 243 41 464 243 44 464 minecraft:brown_terracotta
fill 243 41 466 243 42 466 minecraft:brown_terracotta
fill 243 41 504 243 44 504 minecraft:brown_terracotta
setblock 245 41 466 minecraft:bone_block
setblock 246 41 465 minecraft:bone_block
fill 246 41 466 246 44 466 minecraft:brown_terracotta
setblock 247 41 464 minecraft:bone_block
fill 247 41 465 247 44 465 minecraft:brown_terracotta
setblock 247 41 504 minecraft:bone_block
fill 248 41 464 248 44 464 minecraft:brown_terracotta
setblock 248 41 503 minecraft:bone_block
fill 248 41 504 248 44 504 minecraft:brown_terracotta
setblock 249 41 467 minecraft:bone_block
fill 249 41 503 249 44 503 minecraft:brown_terracotta
setblock 250 41 466 minecraft:bone_block
setblock 251 41 465 minecraft:bone_block
fill 251 41 466 251 44 466 minecraft:brown_terracotta
setblock 252 41 464 minecraft:bone_block
fill 252 41 465 252 44 465 minecraft:brown_terracotta
setblock 252 41 504 minecraft:bone_block
fill 253 41 464 253 44 464 minecraft:brown_terracotta
setblock 253 41 503 minecraft:bone_block
fill 253 41 504 253 44 504 minecraft:brown_terracotta
setblock 257 41 464 minecraft:bone_block
setblock 257 41 504 minecraft:bone_block
setblock 258 41 464 minecraft:brown_terracotta
setblock 258 41 504 minecraft:brown_terracotta
setblock 262 41 464 minecraft:bone_block
setblock 262 41 504 minecraft:bone_block
fill 263 41 464 263 44 464 minecraft:brown_terracotta
fill 263 41 504 263 44 504 minecraft:brown_terracotta
setblock 267 41 464 minecraft:bone_block
fill 267 41 465 267 44 465 minecraft:brown_terracotta
setblock 267 41 504 minecraft:bone_block
fill 268 41 464 268 44 464 minecraft:brown_terracotta
fill 268 41 504 268 44 504 minecraft:brown_terracotta
setblock 272 41 464 minecraft:bone_block
setblock 272 41 504 minecraft:bone_block
setblock 273 41 464 minecraft:brown_terracotta
setblock 274 41 487 minecraft:bone_block
setblock 274 41 488 minecraft:brown_terracotta
setblock 275 41 486 minecraft:bone_block
fill 275 41 487 275 44 487 minecraft:brown_terracotta
setblock 276 41 481 minecraft:brown_terracotta
setblock 276 41 485 minecraft:bone_block
fill 276 41 486 276 44 486 minecraft:brown_terracotta
setblock 276 41 490 minecraft:bone_block
fill 276 41 491 276 44 491 minecraft:brown_terracotta
setblock 236 42 464 minecraft:bone_block
fill 236 42 465 236 45 465 minecraft:brown_terracotta
setblock 236 42 469 minecraft:bone_block
fill 236 42 470 236 45 470 minecraft:brown_terracotta
fill 236 42 472 236 43 472 minecraft:brown_terracotta
fill 237 42 464 237 45 464 minecraft:brown_terracotta
setblock 240 42 465 minecraft:bone_block
setblock 241 42 464 minecraft:bone_block
fill 241 42 465 241 45 465 minecraft:brown_terracotta
fill 242 42 464 242 45 464 minecraft:brown_terracotta
setblock 244 42 466 minecraft:bone_block
setblock 245 42 465 minecraft:bone_block
fill 245 42 466 245 45 466 minecraft:brown_terracotta
setblock 246 42 464 minecraft:bone_block
fill 246 42 465 246 45 465 minecraft:brown_terracotta
fill 246 42 467 246 43 467 minecraft:brown_terracotta
setblock 246 42 504 minecraft:bone_block
fill 247 42 464 247 45 464 minecraft:brown_terracotta
setblock 247 42 503 minecraft:bone_block
fill 247 42 504 247 45 504 minecraft:brown_terracotta
setblock 248 42 467 minecraft:bone_block
fill 248 42 503 248 45 503 minecraft:brown_terracotta
setblock 249 42 466 minecraft:bone_block
setblock 250 42 465 minecraft:bone_block
fill 250 42 466 250 45 466 minecraft:brown_terracotta
setblock 251 42 464 minecraft:bone_block
fill 251 42 465 251 45 465 minecraft:brown_terracotta
setblock 251 42 504 minecraft:bone_block
fill 252 42 464 252 45 464 minecraft:brown_terracotta
fill 252 42 504 252 45 504 minecraft:brown_terracotta
setblock 256 42 464 minecraft:bone_block
setblock 256 42 504 minecraft:bone_block
setblock 257 42 464 minecraft:brown_terracotta
setblock 261 42 504 minecraft:bone_block
fill 262 42 464 262 45 464 minecraft:brown_terracotta
fill 262 42 504 262 45 504 minecraft:brown_terracotta
setblock 266 42 464 minecraft:bone_block
setblock 266 42 504 minecraft:bone_block
fill 267 42 464 267 45 464 minecraft:brown_terracotta
fill 267 42 504 267 45 504 minecraft:brown_terracotta
setblock 271 42 464 minecraft:bone_block
setblock 271 42 504 minecraft:bone_block
setblock 272 42 464 minecraft:brown_terracotta
setblock 275 42 485 minecraft:bone_block
fill 275 42 486 275 43 486 minecraft:brown_terracotta
setblock 275 42 490 minecraft:bone_block
setblock 276 42 484 minecraft:bone_block
fill 276 42 485 276 45 485 minecraft:brown_terracotta
setblock 276 42 489 minecraft:bone_block
fill 276 42 490 276 45 490 minecraft:brown_terracotta
fill 236 43 464 236 46 464 minecraft:brown_terracotta
setblock 236 43 468 minecraft:bone_block
fill 236 43 469 236 46 469 minecraft:brown_terracotta
setblock 236 43 473 minecraft:bone_block
fill 237 43 468 237 46 468 minecraft:brown_terracotta
fill 238 43 489 238 45 489 minecraft:soul_soil
fill 239 43 488 239 45 488 minecraft:soul_soil
fill 239 43 490 239 45 490 minecraft:soul_soil
setblock 240 43 464 minecraft:bone_block
fill 240 43 465 240 46 465 minecraft:brown_terracotta
fill 240 43 489 240 45 489 minecraft:soul_soil
fill 241 43 464 241 46 464 minecraft:brown_terracotta
setblock 242 43 466 minecraft:brown_terracotta
setblock 243 43 466 minecraft:bone_block
setblock 244 43 465 minecraft:bone_block
fill 244 43 466 244 46 466 minecraft:brown_terracotta
setblock 245 43 464 minecraft:bone_block
fill 245 43 465 245 46 465 minecraft:brown_terracotta
fill 245 43 467 245 44 467 minecraft:brown_terracotta
setblock 245 43 504 minecraft:bone_block
fill 246 43 464 246 46 464 minecraft:brown_terracotta
setblock 246 43 503 minecraft:bone_block
fill 246 43 504 246 46 504 minecraft:brown_terracotta
setblock 247 43 466 minecraft:brown_terracotta
setblock 247 43 467 minecraft:bone_block
fill 247 43 503 247 46 503 minecraft:brown_terracotta
setblock 248 43 466 minecraft:bone_block
fill 248 43 467 248 46 467 minecraft:brown_terracotta
setblock 249 43 465 minecraft:bone_block
fill 249 43 466 249 46 466 minecraft:brown_terracotta
setblock 250 43 464 minecraft:bone_block
fill 250 43 465 250 46 465 minecraft:brown_terracotta
setblock 250 43 504 minecraft:bone_block
fill 251 43 464 251 46 464 minecraft:brown_terracotta
fill 251 43 504 251 46 504 minecraft:brown_terracotta
setblock 255 43 464 minecraft:bone_block
setblock 255 43 504 minecraft:bone_block
setblock 256 43 464 minecraft:brown_terracotta
setblock 265 43 464 minecraft:bone_block
setblock 265 43 504 minecraft:bone_block
fill 266 43 464 266 46 464 minecraft:brown_terracotta
fill 266 43 504 266 46 504 minecraft:brown_terracotta
setblock 270 43 464 minecraft:bone_block
setblock 270 43 504 minecraft:bone_block
fill 271 43 464 271 44 464 minecraft:brown_terracotta
setblock 275 43 489 minecraft:bone_block
fill 275 43 490 275 46 490 minecraft:brown_terracotta
setblock 276 43 468 minecraft:bone_block
fill 276 43 469 276 45 470 minecraft:brown_terracotta
setblock 276 43 483 minecraft:bone_block
fill 276 43 484 276 46 484 minecraft:brown_terracotta
setblock 276 43 488 minecraft:bone_block
fill 276 43 489 276 46 489 minecraft:brown_terracotta
setblock 236 44 467 minecraft:bone_block
fill 236 44 468 236 47 468 minecraft:brown_terracotta
setblock 236 44 472 minecraft:bone_block
fill 236 44 473 236 46 474 minecraft:brown_terracotta
fill 237 44 467 237 47 467 minecraft:brown_terracotta
fill 237 44 469 237 44 470 minecraft:brown_terracotta
setblock 237 44 471 minecraft:bone_block
setblock 239 44 464 minecraft:bone_block
fill 239 44 465 239 47 465 minecraft:brown_terracotta
fill 240 44 464 240 47 464 minecraft:brown_terracotta
setblock 241 44 466 minecraft:brown_terracotta
setblock 242 44 466 minecraft:bone_block
fill 242 44 504 242 45 504 minecraft:brown_terracotta
setblock 243 44 465 minecraft:bone_block
fill 243 44 466 243 47 466 minecraft:brown_terracotta
setblock 244 44 464 minecraft:bone_block
fill 244 44 465 244 47 465 minecraft:brown_terracotta
fill 244 44 467 244 45 467 minecraft:brown_terracotta
setblock 244 44 504 minecraft:bone_block
fill 245 44 464 245 47 464 minecraft:brown_terracotta
fill 245 44 504 245 47 504 minecraft:brown_terracotta
setblock 246 44 467 minecraft:bone_block
fill 246 44 503 246 47 503 minecraft:brown_terracotta
setblock 247 44 466 minecraft:bone_block
fill 247 44 467 247 47 467 minecraft:brown_terracotta
setblock 248 44 465 minecraft:bone_block
fill 248 44 466 248 47 466 minecraft:brown_terracotta
setblock 249 44 464 minecraft:bone_block
fill 249 44 465 249 47 465 minecraft:brown_terracotta
setblock 249 44 504 minecraft:bone_block
fill 250 44 464 250 47 464 minecraft:brown_terracotta
setblock 250 44 503 minecraft:bone_block
fill 250 44 504 250 47 504 minecraft:brown_terracotta
setblock 253 44 465 minecraft:bone_block
setblock 254 44 464 minecraft:bone_block
setblock 254 44 504 minecraft:bone_block
setblock 255 44 464 minecraft:brown_terracotta
fill 261 44 504 261 46 504 minecraft:brown_terracotta
setblock 264 44 464 minecraft:bone_block
setblock 264 44 504 minecraft:bone_block
fill 265 44 464 265 47 464 minecraft:brown_terracotta
fill 265 44 504 265 47 504 minecraft:brown_terracotta
fill 266 44 465 266 45 465 minecraft:brown_terracotta
setblock 268 44 465 minecraft:bone_block
setblock 269 44 464 minecraft:bone_block
setblock 269 44 504 minecraft:bone_block
fill 270 44 464 270 46 464 minecraft:brown_terracotta
setblock 275 44 488 minecraft:bone_block
fill 275 44 489 275 47 489 minecraft:brown_terracotta
setblock 276 44 467 minecraft:bone_block
fill 276 44 468 276 47 468 minecraft:brown_terracotta
setblock 276 44 471 minecraft:brown_terracotta
setblock 276 44 472 minecraft:bone_block
setblock 276 44 487 minecraft:bone_block
fill 276 44 488 276 47 488 minecraft:brown_terracotta
setblock 276 44 492 minecraft:bone_block
setblock 236 45 466 minecraft:bone_block
fill 236 45 467 236 48 467 minecraft:brown_terracotta
setblock 236 45 471 minecraft:bone_block
fill 236 45 472 237 47 472 minecraft:brown_terracotta
setblock 236 45 475 minecraft:brown_terracotta
fill 237 45 466 237 48 466 minecraft:brown_terracotta
setblock 237 45 469 minecraft:brown_terracotta
setblock 237 45 470 minecraft:bone_block
fill 237 45 471 237 48 471 minecraft:brown_terracotta
setblock 238 45 464 minecraft:bone_block
fill 238 45 465 238 48 465 minecraft:brown_terracotta
fill 239 45 464 239 48 464 minecraft:brown_terracotta
setblock 240 45 466 minecraft:brown_terracotta
setblock 241 45 466 minecraft:bone_block
setblock 242 45 465 minecraft:bone_block
fill 242 45 466 242 48 466 minecraft:brown_terracotta
setblock 243 45 464 minecraft:bone_block
fill 243 45 465 243 48 465 minecraft:brown_terracotta
fill 243 45 467 243 46 467 minecraft:brown_terracotta
setblock 243 45 504 minecraft:bone_block
fill 244 45 464 244 48 464 minecraft:brown_terracotta
fill 244 45 504 244 48 504 minecraft:brown_terracotta
setblock 245 45 467 minecraft:bone_block
fill 245 45 503 245 48 503 minecraft:brown_terracotta
setblock 246 45 466 minecraft:bone_block
fill 246 45 467 246 48 467 minecraft:brown_terracotta
setblock 247 45 465 minecraft:bone_block
fill 247 45 466 247 48 466 minecraft:brown_terracotta
setblock 248 45 464 minecraft:bone_block
fill 248 45 465 248 48 465 minecraft:brown_terracotta
setblock 248 45 504 minecraft:bone_block
fill 249 45 464 249 48 464 minecraft:brown_terracotta
setblock 249 45 503 minecraft:bone_block
fill 249 45 504 249 48 504 minecraft:brown_terracotta
fill 250 45 503 250 47 503 minecraft:brown_terracotta
setblock 252 45 465 minecraft:bone_block
setblock 253 45 464 minecraft:bone_block
setblock 253 45 504 minecraft:bone_block
fill 254 45 464 254 46 464 minecraft:brown_terracotta
fill 254 45 504 254 46 504 minecraft:brown_terracotta
fill 261 45 464 261 46 464 minecraft:brown_terracotta
setblock 263 45 464 minecraft:bone_block
setblock 263 45 504 minecraft:bone_block
fill 264 45 464 264 48 464 minecraft:brown_terracotta
fill 264 45 504 264 48 504 minecraft:brown_terracotta
fill 265 45 465 265 46 465 minecraft:brown_terracotta
setblock 267 45 465 minecraft:bone_block
setblock 268 45 464 minecraft:bone_block
setblock 268 45 504 minecraft:bone_block
fill 269 45 464 269 47 464 minecraft:brown_terracotta
setblock 275 45 487 minecraft:bone_block
fill 275 45 488 275 46 488 minecraft:brown_terracotta
fill 276 45 467 276 48 467 minecraft:brown_terracotta
setblock 276 45 471 minecraft:bone_block
fill 276 45 472 276 45 475 minecraft:brown_terracotta
setblock 276 45 486 minecraft:bone_block
fill 276 45 487 276 48 487 minecraft:brown_terracotta
setblock 276 45 491 minecraft:bone_block
fill 276 45 492 276 47 493 minecraft:brown_terracotta
setblock 236 46 465 minecraft:bone_block
fill 236 46 466 236 49 466 minecraft:brown_terracotta
setblock 236 46 470 minecraft:bone_block
fill 236 46 471 236 49 471 minecraft:brown_terracotta
setblock 236 46 475 minecraft:bone_block
fill 236 46 476 236 49 476 minecraft:brown_terracotta
setblock 237 46 464 minecraft:bone_block
setblock 237 46 469 minecraft:bone_block
fill 237 46 470 238 48 470 minecraft:brown_terracotta
setblock 237 46 473 minecraft:brown_terracotta
setblock 237 46 474 minecraft:bone_block
fill 238 46 464 238 49 464 minecraft:brown_terracotta
setblock 238 46 468 minecraft:bone_block
fill 238 46 469 238 49 469 minecraft:brown_terracotta
fill 238 46 471 238 47 471 minecraft:brown_terracotta
setblock 240 46 466 minecraft:bone_block
setblock 241 46 465 minecraft:bone_block
fill 241 46 466 241 49 466 minecraft:brown_terracotta
setblock 241 46 504 minecraft:brown_terracotta
setblock 242 46 464 minecraft:bone_block
fill 242 46 465 242 49 465 minecraft:brown_terracotta
fill 242 46 467 242 47 467 minecraft:brown_terracotta
setblock 242 46 504 minecraft:bone_block
fill 243 46 464 243 49 464 minecraft:brown_terracotta
fill 243 46 504 243 49 504 minecraft:brown_terracotta
setblock 244 46 467 minecraft:bone_block
fill 244 46 503 244 49 503 minecraft:brown_terracotta
setblock 245 46 466 minecraft:bone_block
fill 245 46 467 245 49 467 minecraft:brown_terracotta
setblock 246 46 465 minecraft:bone_block
fill 246 46 466 246 49 466 minecraft:brown_terracotta
setblock 247 46 464 minecraft:bone_block
fill 247 46 465 247 49 465 minecraft:brown_terracotta
setblock 247 46 504 minecraft:bone_block
fill 248 46 464 248 49 464 minecraft:brown_terracotta
setblock 248 46 503 minecraft:bone_block
fill 248 46 504 248 49 504 minecraft:brown_terracotta
fill 249 46 503 249 49 503 minecraft:brown_terracotta
setblock 250 46 466 minecraft:bone_block
setblock 251 46 465 minecraft:bone_block
setblock 252 46 464 minecraft:bone_block
setblock 252 46 465 minecraft:brown_terracotta
setblock 252 46 504 minecraft:bone_block
fill 253 46 464 253 47 464 minecraft:brown_terracotta
fill 253 46 504 253 49 504 minecraft:brown_terracotta
fill 260 46 504 260 47 504 minecraft:brown_terracotta
setblock 262 46 464 minecraft:bone_block
setblock 262 46 504 minecraft:bone_block
fill 263 46 464 263 49 464 minecraft:brown_terracotta
fill 263 46 504 263 49 504 minecraft:brown_terracotta
setblock 266 46 465 minecraft:bone_block
setblock 267 46 464 minecraft:bone_block
setblock 267 46 465 minecraft:brown_terracotta
setblock 267 46 504 minecraft:bone_block
fill 268 46 464 268 48 464 minecraft:brown_terracotta
fill 268 46 504 268 47 504 minecraft:brown_terracotta
setblock 275 46 470 minecraft:brown_terracotta
setblock 275 46 471 minecraft:bone_block
fill 275 46 472 276 48 472 minecraft:brown_terracotta
setblock 275 46 491 minecraft:bone_block
fill 276 46 466 276 49 466 minecraft:brown_terracotta
setblock 276 46 469 minecraft:brown_terracotta
setblock 276 46 470 minecraft:bone_block
fill 276 46 471 276 49 471 minecraft:brown_terracotta
fill 276 46 473 276 46 474 minecraft:brown_terracotta
setblock 276 46 475 minecraft:bone_block
fill 276 46 476 276 48 477 minecraft:brown_terracotta
setblock 276 46 485 minecraft:bone_block
fill 276 46 486 276 49 486 minecraft:brown_terracotta
setblock 276 46 490 minecraft:bone_block
fill 276 46 491 276 49 491 minecraft:brown_terracotta
setblock 276 46 494 minecraft:brown_terracotta
setblock 236 47 464 minecraft:bone_block
fill 236 47 465 237 49 465 minecraft:brown_terracotta
setblock 236 47 469 minecraft:bone_block
fill 236 47 470 236 50 470 minecraft:brown_terracotta
setblock 236 47 473 minecraft:brown_terracotta
setblock 236 47 474 minecraft:bone_block
fill 236 47 475 237 49 475 minecraft:brown_terracotta
fill 236 47 477 236 48 477 minecraft:brown_terracotta
fill 236 47 490 236 48 492 minecraft:brown_terracotta
fill 237 47 464 237 50 464 minecraft:brown_terracotta
setblock 237 47 468 minecraft:bone_block
fill 237 47 469 237 50 469 minecraft:brown_terracotta
setblock 237 47 473 minecraft:bone_block
fill 237 47 474 237 50 474 minecraft:brown_terracotta
setblock 238 47 467 minecraft:bone_block
fill 238 47 468 238 50 468 minecraft:brown_terracotta
setblock 238 47 472 minecraft:bone_block
setblock 239 47 466 minecraft:bone_block
setblock 240 47 465 minecraft:bone_block
fill 240 47 466 240 50 466 minecraft:brown_terracotta
setblock 240 47 504 minecraft:brown_terracotta
setblock 241 47 464 minecraft:bone_block
fill 241 47 465 241 50 465 minecraft:brown_terracotta
fill 241 47 467 241 48 467 minecraft:brown_terracotta
setblock 241 47 504 minecraft:bone_block
fill 242 47 464 242 50 464 minecraft:brown_terracotta
fill 242 47 504 242 50 504 minecraft:brown_terracotta
setblock 243 47 467 minecraft:bone_block
fill 243 47 503 243 50 503 minecraft:brown_terracotta
setblock 244 47 466 minecraft:bone_block
fill 244 47 467 244 49 467 minecraft:brown_terracotta
setblock 245 47 465 minecraft:bone_block
fill 245 47 466 245 50 466 minecraft:brown_terracotta
setblock 246 47 464 minecraft:bone_block
fill 246 47 465 246 50 465 minecraft:brown_terracotta
setblock 246 47 504 minecraft:bone_block
fill 247 47 464 247 50 464 minecraft:brown_terracotta
setblock 247 47 503 minecraft:bone_block
fill 247 47 504 247 50 504 minecraft:brown_terracotta
fill 248 47 503 248 50 503 minecraft:brown_terracotta
setblock 249 47 466 minecraft:bone_block
setblock 250 47 465 minecraft:bone_block
setblock 251 47 464 minecraft:bone_block
setblock 251 47 465 minecraft:brown_terracotta
setblock 251 47 504 minecraft:bone_block
fill 252 47 464 252 48 464 minecraft:brown_terracotta
fill 252 47 504 252 50 504 minecraft:brown_terracotta
fill 259 47 504 259 48 504 minecraft:brown_terracotta
setblock 261 47 464 minecraft:bone_block
setblock 261 47 504 minecraft:bone_block
fill 262 47 464 262 50 464 minecraft:brown_terracotta
fill 262 47 504 262 50 504 minecraft:brown_terracotta
setblock 264 47 465 minecraft:brown_terracotta
setblock 265 47 465 minecraft:bone_block
setblock 266 47 464 minecraft:bone_block
setblock 266 47 465 minecraft:brown_terracotta
setblock 266 47 504 minecraft:bone_block
fill 267 47 464 267 49 464 minecraft:brown_terracotta
fill 267 47 504 267 49 504 minecraft:brown_terracotta
setblock 275 47 469 minecraft:brown_terracotta
setblock 275 47 470 minecraft:bone_block
fill 275 47 471 275 50 471 minecraft:brown_terracotta
fill 275 47 473 275 47 474 minecraft:brown_terracotta
setblock 275 47 490 minecraft:bone_block
fill 275 47 491 275 48 491 minecraft:brown_terracotta
setblock 276 47 469 minecraft:bone_block
fill 276 47 470 276 50 470 minecraft:brown_terracotta
setblock 276 47 473 minecraft:brown_terracotta
setblock 276 47 474 minecraft:bone_block
fill 276 47 475 276 50 475 minecraft:brown_terracotta
setblock 276 47 478 minecraft:brown_terracotta
setblock 276 47 479 minecraft:bone_block
setblock 276 47 484 minecraft:bone_block
fill 276 47 485 276 49 485 minecraft:brown_terracotta
setblock 276 47 489 minecraft:bone_block
fill 276 47 490 276 50 490 minecraft:brown_terracotta
setblock 276 47 494 minecraft:bone_block
fill 236 48 464 236 51 464 minecraft:brown_terracotta
setblock 236 48 468 minecraft:bone_block
fill 236 48 469 236 51 469 minecraft:brown_terracotta
setblock 236 48 472 minecraft:brown_terracotta
setblock 236 48 473 minecraft:bone_block
fill 236 48 474 236 51 474 minecraft:brown_terracotta
setblock 236 48 478 minecraft:bone_block
setblock 236 48 493 minecraft:bone_block
fill 236 48 494 236 51 494 minecraft:brown_terracotta
setblock 237 48 467 minecraft:bone_block
fill 237 48 468 237 51 468 minecraft:brown_terracotta
setblock 237 48 472 minecraft:bone_block
fill 237 48 473 238 50 473 minecraft:brown_terracotta
setblock 237 48 476 minecraft:brown_terracotta
setblock 238 48 466 minecraft:light[level=12]
fill 238 48 467 238 50 467 minecraft:brown_terracotta
setblock 238 48 471 minecraft:bone_block
fill 238 48 472 238 51 472 minecraft:brown_terracotta
fill 238 48 474 238 49 474 minecraft:brown_terracotta
setblock 238 48 482 minecraft:light[level=12]
setblock 238 48 490 minecraft:light[level=12]
setblock 238 48 498 minecraft:light[level=12]
setblock 239 48 465 minecraft:bone_block
fill 239 48 466 239 50 466 minecraft:brown_terracotta
setblock 239 48 470 minecraft:bone_block
setblock 240 48 464 minecraft:bone_block
fill 240 48 465 240 51 465 minecraft:brown_terracotta
setblock 240 48 504 minecraft:bone_block
fill 241 48 464 241 51 464 minecraft:brown_terracotta
fill 241 48 504 241 51 504 minecraft:brown_terracotta
setblock 242 48 467 minecraft:bone_block
fill 242 48 503 242 51 503 minecraft:brown_terracotta
setblock 243 48 466 minecraft:bone_block
fill 243 48 467 243 50 467 minecraft:brown_terracotta
setblock 244 48 465 minecraft:bone_block
fill 244 48 466 244 51 466 minecraft:brown_terracotta
setblock 245 48 464 minecraft:bone_block
fill 245 48 465 245 51 465 minecraft:brown_terracotta
setblock 245 48 504 minecraft:bone_block
fill 246 48 464 246 51 464 minecraft:brown_terracotta
setblock 246 48 474 minecraft:light[level=12]
setblock 246 48 482 minecraft:light[level=12]
setblock 246 48 490 minecraft:light[level=12]
setblock 246 48 498 minecraft:light[level=12]
setblock 246 48 503 minecraft:bone_block
fill 246 48 504 246 51 504 minecraft:brown_terracotta
fill 247 48 503 247 51 503 minecraft:brown_terracotta
setblock 248 48 466 minecraft:bone_block
setblock 249 48 465 minecraft:bone_block
setblock 250 48 464 minecraft:bone_block
setblock 250 48 465 minecraft:brown_terracotta
setblock 250 48 504 minecraft:bone_block
fill 251 48 464 251 49 464 minecraft:brown_terracotta
fill 251 48 504 251 51 504 minecraft:brown_terracotta
setblock 254 48 466 minecraft:light[level=12]
setblock 254 48 474 minecraft:light[level=12]
setblock 254 48 482 minecraft:light[level=12]
setblock 254 48 490 minecraft:light[level=12]
setblock 254 48 498 minecraft:light[level=12]
fill 258 48 504 258 49 504 minecraft:brown_terracotta
setblock 260 48 504 minecraft:bone_block
fill 261 48 464 261 50 464 minecraft:brown_terracotta
fill 261 48 504 261 51 504 minecraft:brown_terracotta
setblock 262 48 466 minecraft:light[level=12]
setblock 262 48 474 minecraft:light[level=12]
setblock 262 48 482 minecraft:light[level=12]
setblock 262 48 490 minecraft:light[level=12]
setblock 262 48 498 minecraft:light[level=12]
setblock 265 48 464 minecraft:bone_block
setblock 265 48 504 minecraft:bone_block
fill 266 48 464 266 50 464 minecraft:brown_terracotta
fill 266 48 504 266 50 504 minecraft:brown_terracotta
setblock 270 48 466 minecraft:light[level=12]
setblock 270 48 474 minecraft:light[level=12]
setblock 270 48 482 minecraft:light[level=12]
setblock 270 48 490 minecraft:light[level=12]
setblock 270 48 498 minecraft:light[level=12]
setblock 275 48 469 minecraft:bone_block
fill 275 48 470 275 51 470 minecraft:brown_terracotta
setblock 275 48 473 minecraft:brown_terracotta
setblock 275 48 474 minecraft:bone_block
fill 275 48 475 275 50 476 minecraft:brown_terracotta
setblock 275 48 490 minecraft:brown_terracotta
fill 275 48 492 276 48 492 minecraft:brown_terracotta
setblock 276 48 468 minecraft:bone_block
fill 276 48 469 276 51 469 minecraft:brown_terracotta
setblock 276 48 473 minecraft:bone_block
fill 276 48 474 276 51 474 minecraft:brown_terracotta
setblock 276 48 478 minecraft:bone_block
fill 276 48 479 276 49 481 minecraft:brown_terracotta
setblock 276 48 484 minecraft:brown_terracotta
setblock 276 48 488 minecraft:bone_block
fill 276 48 489 276 51 489 minecraft:brown_terracotta
setblock 276 48 493 minecraft:bone_block
fill 276 48 494 276 50 495 minecraft:brown_terracotta
setblock 236 49 467 minecraft:bone_block
fill 236 49 468 236 52 468 minecraft:brown_terracotta
setblock 236 49 472 minecraft:bone_block
fill 236 49 473 236 52 473 minecraft:brown_terracotta
setblock 236 49 477 minecraft:bone_block
fill 236 49 478 236 52 478 minecraft:brown_terracotta
setblock 236 49 491 minecraft:brown_terracotta
setblock 236 49 492 minecraft:bone_block
fill 236 49 493 236 52 493 minecraft:brown_terracotta
fill 236 49 495 236 50 495 minecraft:brown_terracotta
setblock 237 49 466 minecraft:bone_block
fill 237 49 467 237 52 467 minecraft:brown_terracotta
setblock 237 49 470 minecraft:brown_terracotta
setblock 237 49 471 minecraft:bone_block
fill 237 49 472 237 52 472 minecraft:brown_terracotta
setblock 237 49 476 minecraft:bone_block
setblock 238 49 465 minecraft:bone_block
setblock 238 49 470 minecraft:bone_block
fill 238 49 471 239 51 471 minecraft:brown_terracotta
setblock 238 49 475 minecraft:bone_block
setblock 239 49 464 minecraft:bone_block
fill 239 49 465 239 52 465 minecraft:brown_terracotta
setblock 239 49 469 minecraft:bone_block
fill 239 49 470 239 50 470 minecraft:brown_terracotta
fill 239 49 472 239 50 472 minecraft:brown_terracotta
setblock 239 49 504 minecraft:bone_block
fill 240 49 464 240 52 464 minecraft:brown_terracotta
fill 240 49 504 240 52 504 minecraft:brown_terracotta
setblock 241 49 467 minecraft:bone_block
fill 241 49 503 241 52 503 minecraft:brown_terracotta
setblock 242 49 466 minecraft:bone_block
fill 242 49 467 242 50 467 minecraft:brown_terracotta
setblock 243 49 465 minecraft:bone_block
fill 243 49 466 243 51 466 minecraft:brown_terracotta
setblock 244 49 464 minecraft:bone_block
fill 244 49 465 244 52 465 minecraft:brown_terracotta
setblock 244 49 504 minecraft:bone_block
fill 245 49 464 245 52 464 minecraft:brown_terracotta
setblock 245 49 502 minecraft:brown_terracotta
setblock 245 49 503 minecraft:bone_block
fill 245 49 504 245 52 504 minecraft:brown_terracotta
fill 246 49 503 246 52 503 minecraft:brown_terracotta
setblock 247 49 466 minecraft:bone_block
setblock 248 49 465 minecraft:bone_block
setblock 249 49 464 minecraft:bone_block
setblock 249 49 465 minecraft:brown_terracotta
setblock 249 49 504 minecraft:bone_block
fill 250 49 464 250 50 464 minecraft:brown_terracotta
fill 250 49 504 250 52 504 minecraft:brown_terracotta
setblock 259 49 504 minecraft:bone_block
fill 260 49 504 260 52 504 minecraft:brown_terracotta
fill 262 49 503 263 50 503 minecraft:brown_terracotta
setblock 264 49 464 minecraft:bone_block
setblock 264 49 504 minecraft:bone_block
fill 265 49 464 265 50 464 minecraft:brown_terracotta
fill 265 49 504 265 51 504 minecraft:brown_terracotta
fill 275 49 469 275 50 469 minecraft:brown_terracotta
setblock 275 49 472 minecraft:brown_terracotta
setblock 275 49 473 minecraft:bone_block
fill 275 49 474 275 52 474 minecraft:brown_terracotta
setblock 275 49 477 minecraft:brown_terracotta
setblock 276 49 467 minecraft:bone_block
fill 276 49 468 276 52 468 minecraft:brown_terracotta
setblock 276 49 472 minecraft:bone_block
fill 276 49 473 276 52 473 minecraft:brown_terracotta
setblock 276 49 476 minecraft:brown_terracotta
setblock 276 49 477 minecraft:bone_block
fill 276 49 478 276 52 478 minecraft:brown_terracotta
setblock 276 49 482 minecraft:bone_block
setblock 276 49 487 minecraft:bone_block
fill 276 49 488 276 50 488 minecraft:brown_terracotta
setblock 276 49 492 minecraft:bone_block
fill 276 49 493 276 52 493 minecraft:brown_terracotta
setblock 276 49 496 minecraft:brown_terracotta
setblock 236 50 465 minecraft:brown_terracotta
setblock 236 50 466 minecraft:bone_block
fill 236 50 467 236 53 467 minecraft:brown_terracotta
setblock 236 50 471 minecraft:bone_block
fill 236 50 472 236 53 472 minecraft:brown_terracotta
setblock 236 50 475 minecraft:brown_terracotta
setblock 236 50 476 minecraft:bone_block
fill 236 50 477 237 52 477 minecraft:brown_terracotta
fill 236 50 479 236 51 479 minecraft:brown_terracotta
setblock 236 50 491 minecraft:bone_block
fill 236 50 492 236 51 492 minecraft:brown_terracotta
setblock 236 50 496 minecraft:bone_block
fill 236 50 497 236 53 497 minecraft:brown_terracotta
setblock 237 50 465 minecraft:bone_block
fill 237 50 466 237 52 466 minecraft:brown_terracotta
setblock 237 50 470 minecraft:bone_block
fill 237 50 471 237 53 471 minecraft:brown_terracotta
setblock 237 50 475 minecraft:bone_block
fill 237 50 476 237 53 476 minecraft:brown_terracotta
setblock 238 50 464 minecraft:bone_block
fill 238 50 465 238 52 465 minecraft:brown_terracotta
setblock 238 50 469 minecraft:bone_block
fill 238 50 470 238 53 470 minecraft:brown_terracotta
setblock 238 50 474 minecraft:bone_block
fill 238 50 475 238 53 475 minecraft:brown_terracotta
setblock 238 50 504 minecraft:bone_block
fill 239 50 464 239 53 464 minecraft:brown_terracotta
fill 239 50 504 239 53 504 minecraft:brown_terracotta
setblock 241 50 466 minecraft:bone_block
setblock 242 50 465 minecraft:bone_block
fill 242 50 466 242 52 466 minecraft:brown_terracotta
setblock 243 50 464 minecraft:bone_block
fill 243 50 465 243 53 465 minecraft:brown_terracotta
setblock 243 50 504 minecraft:bone_block
fill 244 50 464 244 53 464 minecraft:brown_terracotta
setblock 244 50 502 minecraft:brown_terracotta
setblock 244 50 503 minecraft:bone_block
fill 244 50 504 244 53 504 minecraft:brown_terracotta
setblock 245 50 502 minecraft:bone_block
fill 245 50 503 245 53 503 minecraft:brown_terracotta
setblock 246 50 466 minecraft:bone_block
setblock 247 50 465 minecraft:bone_block
setblock 248 50 464 minecraft:bone_block
setblock 248 50 465 minecraft:brown_terracotta
setblock 248 50 504 minecraft:bone_block
fill 249 50 464 249 51 464 minecraft:brown_terracotta
setblock 249 50 503 minecraft:bone_block
fill 249 50 504 249 53 504 minecraft:brown_terracotta
setblock 257 50 504 minecraft:brown_terracotta
setblock 258 50 504 minecraft:bone_block
fill 259 50 504 259 53 504 minecraft:brown_terracotta
setblock 263 50 464 minecraft:bone_block
setblock 263 50 504 minecraft:bone_block
setblock 264 50 464 minecraft:brown_terracotta
fill 264 50 504 264 52 504 minecraft:brown_terracotta
setblock 275 50 472 minecraft:bone_block
fill 275 50 473 275 53 473 minecraft:brown_terracotta
setblock 275 50 477 minecraft:bone_block
fill 275 50 478 275 53 478 minecraft:brown_terracotta
setblock 276 50 466 minecraft:bone_block
fill 276 50 467 276 53 467 minecraft:brown_terracotta
setblock 276 50 471 minecraft:bone_block
fill 276 50 472 276 53 472 minecraft:brown_terracotta
setblock 276 50 476 minecraft:bone_block
fill 276 50 477 276 53 477 minecraft:brown_terracotta
fill 276 50 479 276 50 480 minecraft:brown_terracotta
setblock 276 50 481 minecraft:bone_block
fill 276 50 482 276 53 482 minecraft:brown_terracotta
setblock 276 50 487 minecraft:brown_terracotta
setblock 276 50 491 minecraft:bone_block
fill 276 50 492 276 52 492 minecraft:brown_terracotta
setblock 276 50 496 minecraft:bone_block
setblock 236 51 465 minecraft:bone_block
fill 236 51 466 236 54 466 minecraft:brown_terracotta
setblock 236 51 470 minecraft:bone_block
fill 236 51 471 236 54 471 minecraft:brown_terracotta
setblock 236 51 475 minecraft:bone_block
fill 236 51 476 236 54 476 minecraft:brown_terracotta
setblock 236 51 495 minecraft:bone_block
fill 236 51 496 236 54 496 minecraft:brown_terracotta
fill 236 51 498 236 52 498 minecraft:brown_terracotta
setblock 237 51 464 minecraft:bone_block
setblock 237 51 469 minecraft:bone_block
fill 237 51 470 237 54 470 minecraft:brown_terracotta
setblock 237 51 473 minecraft:brown_terracotta
setblock 237 51 474 minecraft:bone_block
fill 237 51 475 237 54 475 minecraft:brown_terracotta
fill 238 51 464 238 54 464 minecraft:brown_terracotta
setblock 238 51 468 minecraft:bone_block
fill 238 51 469 238 52 469 minecraft:brown_terracotta
setblock 238 51 473 minecraft:bone_block
fill 238 51 474 238 54 474 minecraft:brown_terracotta
fill 238 51 504 238 54 504 minecraft:brown_terracotta
setblock 239 51 472 minecraft:bone_block
setblock 240 51 466 minecraft:bone_block
fill 240 51 503 240 53 503 minecraft:brown_terracotta
setblock 241 51 465 minecraft:bone_block
fill 241 51 466 241 52 466 minecraft:brown_terracotta
setblock 242 51 464 minecraft:bone_block
fill 242 51 465 242 54 465 minecraft:brown_terracotta
setblock 242 51 504 minecraft:bone_block
fill 243 51 464 243 54 464 minecraft:brown_terracotta
setblock 243 51 502 minecraft:brown_terracotta
setblock 243 51 503 minecraft:bone_block
fill 243 51 504 243 54 504 minecraft:brown_terracotta
setblock 244 51 502 minecraft:bone_block
fill 244 51 503 244 54 503 minecraft:brown_terracotta
fill 245 51 502 245 52 502 minecraft:brown_terracotta
setblock 246 51 465 minecraft:bone_block
setblock 247 51 464 minecraft:bone_block
setblock 247 51 465 minecraft:brown_terracotta
setblock 247 51 504 minecraft:bone_block
setblock 248 51 464 minecraft:brown_terracotta
setblock 248 51 503 minecraft:bone_block
fill 248 51 504 248 54 504 minecraft:brown_terracotta
setblock 257 51 504 minecraft:bone_block
fill 258 51 504 258 54 504 minecraft:brown_terracotta
setblock 262 51 503 minecraft:brown_terracotta
setblock 262 51 504 minecraft:bone_block
fill 263 51 504 263 54 504 minecraft:brown_terracotta
setblock 275 51 471 minecraft:bone_block
fill 275 51 472 275 54 472 minecraft:brown_terracotta
setblock 275 51 475 minecraft:brown_terracotta
setblock 275 51 476 minecraft:bone_block
fill 275 51 477 275 54 477 minecraft:brown_terracotta
setblock 276 51 470 minecraft:bone_block
fill 276 51 471 276 54 471 minecraft:brown_terracotta
setblock 276 51 475 minecraft:bone_block
fill 276 51 476 276 54 476 minecraft:brown_terracotta
setblock 276 51 479 minecraft:brown_terracotta
setblock 276 51 480 minecraft:bone_block
fill 276 51 481 276 54 481 minecraft:brown_terracotta
setblock 276 51 490 minecraft:bone_block
setblock 276 51 491 minecraft:brown_terracotta
setblock 276 51 494 minecraft:brown_terracotta
setblock 276 51 495 minecraft:bone_block
fill 276 51 496 276 53 497 minecraft:brown_terracotta
setblock 236 52 464 minecraft:bone_block
fill 236 52 465 236 55 465 minecraft:brown_terracotta
setblock 236 52 469 minecraft:bone_block
fill 236 52 470 236 55 470 minecraft:brown_terracotta
setblock 236 52 474 minecraft:bone_block
fill 236 52 475 236 55 475 minecraft:brown_terracotta
setblock 236 52 479 minecraft:bone_block
setblock 236 52 494 minecraft:bone_block
fill 236 52 495 236 55 495 minecraft:brown_terracotta
setblock 236 52 499 minecraft:bone_block
fill 236 52 500 236 55 500 minecraft:brown_terracotta
fill 237 52 464 237 55 464 minecraft:brown_terracotta
setblock 237 52 468 minecraft:bone_block
fill 237 52 469 237 54 469 minecraft:brown_terracotta
setblock 237 52 473 minecraft:bone_block
fill 237 52 474 237 55 474 minecraft:brown_terracotta
setblock 237 52 478 minecraft:bone_block
setblock 238 52 471 minecraft:brown_terracotta
setblock 238 52 472 minecraft:bone_block
fill 238 52 473 238 54 473 minecraft:brown_terracotta
setblock 240 52 465 minecraft:bone_block
setblock 241 52 464 minecraft:bone_block
fill 241 52 465 241 54 465 minecraft:brown_terracotta
setblock 241 52 504 minecraft:bone_block
fill 242 52 464 242 55 464 minecraft:brown_terracotta
setblock 242 52 502 minecraft:brown_terracotta
setblock 242 52 503 minecraft:bone_block
fill 242 52 504 242 55 504 minecraft:brown_terracotta
setblock 243 52 502 minecraft:bone_block
fill 243 52 503 243 55 503 minecraft:brown_terracotta
fill 244 52 502 244 54 502 minecraft:brown_terracotta
setblock 245 52 465 minecraft:bone_block
setblock 246 52 464 minecraft:bone_block
setblock 246 52 504 minecraft:bone_block
setblock 247 52 464 minecraft:brown_terracotta
setblock 247 52 503 minecraft:bone_block
fill 247 52 504 247 55 504 minecraft:brown_terracotta
fill 257 52 504 257 55 504 minecraft:brown_terracotta
setblock 261 52 504 minecraft:bone_block
fill 262 52 504 262 55 504 minecraft:brown_terracotta
setblock 275 52 470 minecraft:bone_block
fill 275 52 471 275 54 471 minecraft:brown_terracotta
setblock 275 52 475 minecraft:bone_block
fill 275 52 476 275 55 476 minecraft:brown_terracotta
setblock 276 52 469 minecraft:bone_block
fill 276 52 470 276 55 470 minecraft:brown_terracotta
setblock 276 52 474 minecraft:bone_block
fill 276 52 475 276 55 475 minecraft:brown_terracotta
setblock 276 52 479 minecraft:bone_block
fill 276 52 480 276 55 480 minecraft:brown_terracotta
setblock 276 52 494 minecraft:bone_block
fill 276 52 495 276 53 495 minecraft:brown_terracotta
fill 236 53 464 236 56 464 minecraft:brown_terracotta
setblock 236 53 468 minecraft:bone_block
fill 236 53 469 236 56 469 minecraft:brown_terracotta
setblock 236 53 473 minecraft:bone_block
fill 236 53 474 236 56 474 minecraft:brown_terracotta
setblock 236 53 477 minecraft:brown_terracotta
setblock 236 53 478 minecraft:bone_block
fill 236 53 479 236 56 479 minecraft:brown_terracotta
fill 236 53 494 236 54 494 minecraft:brown_terracotta
setblock 236 53 498 minecraft:bone_block
fill 236 53 499 236 56 499 minecraft:brown_terracotta
fill 236 53 501 236 54 501 minecraft:brown_terracotta
setblock 237 53 467 minecraft:bone_block
fill 237 53 468 237 54 468 minecraft:brown_terracotta
setblock 237 53 472 minecraft:bone_block
fill 237 53 473 237 56 473 minecraft:brown_terracotta
setblock 237 53 477 minecraft:bone_block
fill 237 53 478 237 56 478 minecraft:brown_terracotta
setblock 237 53 497 minecraft:bone_block
fill 237 53 498 237 56 498 minecraft:brown_terracotta
fill 237 53 504 237 55 504 minecraft:brown_terracotta
setblock 238 53 471 minecraft:bone_block
fill 238 53 472 238 54 472 minecraft:brown_terracotta
setblock 239 53 465 minecraft:bone_block
fill 239 53 503 239 54 503 minecraft:brown_terracotta
setblock 240 53 464 minecraft:bone_block
fill 240 53 465 240 55 465 minecraft:brown_terracotta
setblock 240 53 504 minecraft:bone_block
fill 241 53 464 241 56 464 minecraft:brown_terracotta
setblock 241 53 503 minecraft:bone_block
fill 241 53 504 241 56 504 minecraft:brown_terracotta
setblock 242 53 502 minecraft:bone_block
fill 242 53 503 242 56 503 minecraft:brown_terracotta
fill 243 53 502 243 56 502 minecraft:brown_terracotta
setblock 244 53 465 minecraft:bone_block
setblock 245 53 464 minecraft:bone_block
setblock 245 53 504 minecraft:bone_block
setblock 246 53 464 minecraft:brown_terracotta
setblock 246 53 503 minecraft:bone_block
fill 246 53 504 246 56 504 minecraft:brown_terracotta
setblock 247 53 503 minecraft:brown_terracotta
setblock 260 53 504 minecraft:bone_block
fill 261 53 504 261 56 504 minecraft:brown_terracotta
setblock 275 53 474 minecraft:bone_block
fill 275 53 475 275 56 475 minecraft:brown_terracotta
setblock 275 53 479 minecraft:bone_block
setblock 276 53 468 minecraft:bone_block
fill 276 53 469 276 56 469 minecraft:brown_terracotta
setblock 276 53 473 minecraft:bone_block
fill 276 53 474 276 56 474 minecraft:brown_terracotta
setblock 276 53 478 minecraft:bone_block
fill 276 53 479 276 56 479 minecraft:brown_terracotta
setblock 276 53 494 minecraft:brown_terracotta
setblock 236 54 467 minecraft:bone_block
fill 236 54 468 236 57 468 minecraft:brown_terracotta
setblock 236 54 472 minecraft:bone_block
fill 236 54 473 236 57 473 minecraft:brown_terracotta
setblock 236 54 477 minecraft:bone_block
fill 236 54 478 236 57 478 minecraft:brown_terracotta
fill 236 54 480 236 55 480 minecraft:brown_terracotta
setblock 236 54 497 minecraft:bone_block
fill 236 54 498 236 57 498 minecraft:brown_terracotta
setblock 236 54 502 minecraft:bone_block
fill 236 54 503 236 57 503 minecraft:brown_terracotta
setblock 237 54 471 minecraft:bone_block
fill 237 54 472 237 57 472 minecraft:brown_terracotta
setblock 237 54 476 minecraft:bone_block
fill 237 54 477 237 57 477 minecraft:brown_terracotta
fill 237 54 497 237 57 497 minecraft:brown_terracotta
fill 237 54 499 237 54 500 minecraft:brown_terracotta
setblock 238 54 475 minecraft:bone_block
fill 238 54 503 238 55 503 minecraft:brown_terracotta
setblock 239 54 464 minecraft:bone_block
setblock 239 54 465 minecraft:brown_terracotta
setblock 239 54 504 minecraft:bone_block
fill 240 54 464 240 57 464 minecraft:brown_terracotta
setblock 240 54 503 minecraft:bone_block
fill 240 54 504 240 57 504 minecraft:brown_terracotta
setblock 241 54 502 minecraft:bone_block
fill 241 54 503 241 57 503 minecraft:brown_terracotta
fill 242 54 502 242 57 502 minecraft:brown_terracotta
setblock 244 54 464 minecraft:bone_block
setblock 244 54 504 minecraft:bone_block
setblock 245 54 464 minecraft:brown_terracotta
setblock 245 54 503 minecraft:bone_block
fill 245 54 504 245 57 504 minecraft:brown_terracotta
fill 246 54 503 246 57 503 minecraft:brown_terracotta
setblock 259 54 504 minecraft:bone_block
fill 260 54 504 260 57 504 minecraft:brown_terracotta
setblock 275 54 473 minecraft:bone_block
fill 275 54 474 275 57 474 minecraft:brown_terracotta
setblock 275 54 478 minecraft:bone_block
fill 275 54 479 275 57 479 minecraft:brown_terracotta
fill 276 54 468 276 57 468 minecraft:brown_terracotta
setblock 276 54 472 minecraft:bone_block
fill 276 54 473 276 57 473 minecraft:brown_terracotta
setblock 276 54 477 minecraft:bone_block
fill 276 54 478 276 57 478 minecraft:brown_terracotta
setblock 276 54 482 minecraft:bone_block
setblock 276 54 496 minecraft:brown_terracotta
setblock 276 54 497 minecraft:bone_block
setblock 236 55 466 minecraft:bone_block
fill 236 55 467 236 58 467 minecraft:brown_terracotta
setblock 236 55 471 minecraft:bone_block
fill 236 55 472 236 58 472 minecraft:brown_terracotta
setblock 236 55 476 minecraft:bone_block
fill 236 55 477 236 58 477 minecraft:brown_terracotta
setblock 236 55 496 minecraft:bone_block
fill 236 55 497 236 58 497 minecraft:brown_terracotta
setblock 236 55 501 minecraft:bone_block
fill 236 55 502 237 57 502 minecraft:brown_terracotta
fill 236 55 504 236 56 504 minecraft:brown_terracotta
setblock 237 55 470 minecraft:bone_block
fill 237 55 471 237 58 471 minecraft:brown_terracotta
setblock 237 55 475 minecraft:bone_block
fill 237 55 476 237 58 476 minecraft:brown_terracotta
setblock 237 55 499 minecraft:brown_terracotta
setblock 237 55 500 minecraft:bone_block
fill 237 55 501 237 58 501 minecraft:brown_terracotta
setblock 238 55 464 minecraft:bone_block
setblock 238 55 504 minecraft:bone_block
fill 239 55 464 239 58 464 minecraft:brown_terracotta
setblock 239 55 503 minecraft:bone_block
fill 239 55 504 239 58 504 minecraft:brown_terracotta
setblock 240 55 502 minecraft:bone_block
fill 240 55 503 240 58 503 minecraft:brown_terracotta
fill 241 55 502 241 58 502 minecraft:brown_terracotta
setblock 243 55 464 minecraft:bone_block
setblock 243 55 504 minecraft:bone_block
fill 244 55 464 244 58 464 minecraft:brown_terracotta
setblock 244 55 503 minecraft:bone_block
fill 244 55 504 244 58 504 minecraft:brown_terracotta
fill 245 55 503 245 58 503 minecraft:brown_terracotta
setblock 248 55 504 minecraft:bone_block
fill 256 55 504 256 56 504 minecraft:brown_terracotta
setblock 258 55 504 minecraft:bone_block
fill 259 55 504 259 58 504 minecraft:brown_terracotta
setblock 275 55 472 minecraft:bone_block
fill 275 55 473 275 58 473 minecraft:brown_terracotta
setblock 275 55 477 minecraft:bone_block
fill 275 55 478 275 58 478 minecraft:brown_terracotta
setblock 276 55 471 minecraft:bone_block
fill 276 55 472 276 58 472 minecraft:brown_terracotta
setblock 276 55 476 minecraft:bone_block
fill 276 55 477 276 58 477 minecraft:brown_terracotta
setblock 276 55 481 minecraft:bone_block
fill 276 55 482 276 58 482 minecraft:brown_terracotta
fill 276 55 497 276 57 498 minecraft:brown_terracotta
setblock 236 56 465 minecraft:bone_block
fill 236 56 466 236 59 466 minecraft:brown_terracotta
setblock 236 56 470 minecraft:bone_block
fill 236 56 471 236 59 471 minecraft:brown_terracotta
setblock 236 56 475 minecraft:bone_block
fill 236 56 476 236 59 476 minecraft:brown_terracotta
setblock 236 56 480 minecraft:bone_block
fill 236 56 481 236 59 481 minecraft:brown_terracotta
setblock 236 56 495 minecraft:bone_block
fill 236 56 496 237 58 496 minecraft:brown_terracotta
setblock 236 56 500 minecraft:bone_block
fill 236 56 501 236 59 501 minecraft:brown_terracotta
setblock 237 56 464 minecraft:bone_block
setblock 237 56 470 minecraft:brown_terracotta
setblock 237 56 474 minecraft:bone_block
fill 237 56 475 237 59 475 minecraft:brown_terracotta
setblock 237 56 479 minecraft:bone_block
setblock 237 56 499 minecraft:bone_block
fill 237 56 500 238 58 500 minecraft:brown_terracotta
setblock 237 56 503 minecraft:brown_terracotta
setblock 237 56 504 minecraft:bone_block
fill 238 56 464 238 59 464 minecraft:brown_terracotta
setblock 238 56 466 minecraft:light[level=12]
setblock 238 56 474 minecraft:light[level=12]
setblock 238 56 482 minecraft:light[level=12]
setblock 238 56 490 minecraft:light[level=12]
setblock 238 56 498 minecraft:light[level=12]
fill 238 56 499 238 59 499 minecraft:brown_terracotta
fill 238 56 501 238 57 501 minecraft:brown_terracotta
setblock 238 56 503 minecraft:bone_block
fill 238 56 504 238 59 504 minecraft:brown_terracotta
setblock 239 56 502 minecraft:bone_block
fill 239 56 503 239 59 503 minecraft:brown_terracotta
fill 240 56 502 240 59 502 minecraft:brown_terracotta
setblock 242 56 464 minecraft:bone_block
setblock 242 56 504 minecraft:bone_block
fill 243 56 464 243 59 464 minecraft:brown_terracotta
setblock 243 56 503 minecraft:bone_block
fill 243 56 504 243 59 504 minecraft:brown_terracotta
setblock 244 56 502 minecraft:bone_block
fill 244 56 503 244 59 503 minecraft:brown_terracotta
setblock 246 56 466 minecraft:light[level=12]
setblock 246 56 474 minecraft:light[level=12]
setblock 246 56 482 minecraft:light[level=12]
setblock 246 56 490 minecraft:light[level=12]
setblock 246 56 498 minecraft:light[level=12]
setblock 247 56 504 minecraft:bone_block
fill 248 56 504 248 59 504 minecraft:brown_terracotta
setblock 254 56 466 minecraft:light[level=12]
setblock 254 56 474 minecraft:light[level=12]
setblock 254 56 482 minecraft:light[level=12]
setblock 254 56 490 minecraft:light[level=12]
setblock 254 56 498 minecraft:light[level=12]
fill 255 56 504 255 57 504 minecraft:brown_terracotta
setblock 257 56 504 minecraft:bone_block
setblock 258 56 503 minecraft:bone_block
fill 258 56 504 258 59 504 minecraft:brown_terracotta
fill 259 56 503 260 58 503 minecraft:brown_terracotta
setblock 262 56 466 minecraft:light[level=12]
setblock 262 56 474 minecraft:light[level=12]
setblock 262 56 482 minecraft:light[level=12]
setblock 262 56 490 minecraft:light[level=12]
setblock 262 56 498 minecraft:light[level=12]
setblock 262 56 504 minecraft:bone_block
setblock 270 56 466 minecraft:light[level=12]
setblock 270 56 474 minecraft:light[level=12]
setblock 270 56 482 minecraft:light[level=12]
setblock 270 56 490 minecraft:light[level=12]
setblock 270 56 498 minecraft:light[level=12]
fill 275 56 472 275 59 472 minecraft:brown_terracotta
setblock 275 56 476 minecraft:bone_block
fill 275 56 477 275 59 477 minecraft:brown_terracotta
setblock 275 56 480 minecraft:brown_terracotta
setblock 276 56 470 minecraft:bone_block
fill 276 56 471 276 59 471 minecraft:brown_terracotta
setblock 276 56 475 minecraft:bone_block
fill 276 56 476 276 59 476 minecraft:brown_terracotta
setblock 276 56 480 minecraft:bone_block
fill 276 56 481 276 59 481 minecraft:brown_terracotta
fill 276 56 483 276 57 483 minecraft:brown_terracotta
setblock 276 56 499 minecraft:brown_terracotta
setblock 276 56 500 minecraft:bone_block
setblock 236 57 464 minecraft:bone_block
fill 236 57 465 236 60 465 minecraft:brown_terracotta
setblock 236 57 469 minecraft:bone_block
fill 236 57 470 236 60 470 minecraft:brown_terracotta
setblock 236 57 474 minecraft:bone_block
fill 236 57 475 236 60 475 minecraft:brown_terracotta
setblock 236 57 479 minecraft:bone_block
fill 236 57 480 236 60 480 minecraft:brown_terracotta
fill 236 57 495 236 60 495 minecraft:brown_terracotta
setblock 236 57 499 minecraft:bone_block
fill 236 57 500 236 60 500 minecraft:brown_terracotta
setblock 236 57 504 minecraft:bone_block
fill 237 57 464 237 60 464 minecraft:brown_terracotta
setblock 237 57 473 minecraft:bone_block
fill 237 57 474 237 60 474 minecraft:brown_terracotta
setblock 237 57 478 minecraft:bone_block
fill 237 57 479 237 60 479 minecraft:brown_terracotta
setblock 237 57 498 minecraft:bone_block
fill 237 57 499 237 60 499 minecraft:brown_terracotta
setblock 237 57 503 minecraft:bone_block
fill 237 57 504 237 60 504 minecraft:brown_terracotta
fill 238 57 465 239 57 465 minecraft:brown_terracotta
fill 238 57 498 238 60 498 minecraft:brown_terracotta
setblock 238 57 502 minecraft:bone_block
fill 238 57 503 238 60 503 minecraft:brown_terracotta
fill 239 57 502 239 60 502 minecraft:brown_terracotta
setblock 240 57 465 minecraft:bone_block
setblock 241 57 464 minecraft:bone_block
setblock 241 57 504 minecraft:bone_block
fill 242 57 464 242 60 464 minecraft:brown_terracotta
setblock 242 57 503 minecraft:bone_block
fill 242 57 504 242 60 504 minecraft:brown_terracotta
setblock 243 57 502 minecraft:bone_block
fill 243 57 503 243 60 503 minecraft:brown_terracotta
fill 244 57 502 244 60 502 minecraft:brown_terracotta
setblock 246 57 504 minecraft:bone_block
fill 247 57 504 247 60 504 minecraft:brown_terracotta
fill 249 57 504 249 58 504 minecraft:brown_terracotta
fill 253 57 504 254 58 504 minecraft:brown_terracotta
setblock 256 57 503 minecraft:brown_terracotta
setblock 256 57 504 minecraft:bone_block
setblock 257 57 503 minecraft:bone_block
fill 257 57 504 257 60 504 minecraft:brown_terracotta
fill 258 57 503 258 60 503 minecraft:brown_terracotta
setblock 261 57 503 minecraft:brown_terracotta
setblock 261 57 504 minecraft:bone_block
fill 262 57 504 262 60 504 minecraft:brown_terracotta
setblock 275 57 475 minecraft:bone_block
fill 275 57 476 275 60 476 minecraft:brown_terracotta
setblock 275 57 480 minecraft:bone_block
fill 275 57 481 275 60 481 minecraft:brown_terracotta
setblock 276 57 464 minecraft:bone_block
fill 276 57 465 276 58 467 minecraft:brown_terracotta
setblock 276 57 469 minecraft:bone_block
fill 276 57 470 276 60 470 minecraft:brown_terracotta
setblock 276 57 474 minecraft:bone_block
fill 276 57 475 276 60 475 minecraft:brown_terracotta
setblock 276 57 479 minecraft:bone_block
fill 276 57 480 276 60 480 minecraft:brown_terracotta
setblock 276 57 484 minecraft:bone_block
fill 276 57 496 276 59 496 minecraft:brown_terracotta
setblock 276 57 499 minecraft:bone_block
fill 276 57 500 276 57 503 minecraft:brown_terracotta
fill 236 58 464 236 61 464 minecraft:brown_terracotta
setblock 236 58 468 minecraft:bone_block
fill 236 58 469 236 61 469 minecraft:brown_terracotta
setblock 236 58 473 minecraft:bone_block
fill 236 58 474 236 61 474 minecraft:brown_terracotta
setblock 236 58 478 minecraft:bone_block
fill 236 58 479 236 61 479 minecraft:brown_terracotta
setblock 236 58 482 minecraft:brown_terracotta
setblock 236 58 483 minecraft:bone_block
fill 236 58 494 236 61 494 minecraft:brown_terracotta
setblock 236 58 498 minecraft:bone_block
fill 236 58 499 236 61 499 minecraft:brown_terracotta
setblock 236 58 502 minecraft:brown_terracotta
setblock 236 58 503 minecraft:bone_block
fill 236 58 504 236 61 504 minecraft:brown_terracotta
fill 237 58 465 237 58 466 minecraft:brown_terracotta
setblock 237 58 472 minecraft:bone_block
fill 237 58 473 237 61 473 minecraft:brown_terracotta
setblock 237 58 477 minecraft:bone_block
fill 237 58 478 237 61 478 minecraft:brown_terracotta
fill 237 58 480 237 59 480 minecraft:brown_terracotta
setblock 237 58 497 minecraft:bone_block
fill 237 58 498 237 61 498 minecraft:brown_terracotta
setblock 237 58 502 minecraft:bone_block
fill 237 58 503 237 61 503 minecraft:brown_terracotta
setblock 238 58 465 minecraft:brown_terracotta
setblock 238 58 501 minecraft:bone_block
fill 238 58 502 238 61 502 minecraft:brown_terracotta
setblock 239 58 465 minecraft:bone_block
setblock 240 58 464 minecraft:bone_block
fill 240 58 465 240 61 465 minecraft:brown_terracotta
fill 240 58 501 240 60 501 minecraft:brown_terracotta
setblock 240 58 504 minecraft:bone_block
fill 241 58 464 241 61 464 minecraft:brown_terracotta
setblock 241 58 503 minecraft:bone_block
fill 241 58 504 241 61 504 minecraft:brown_terracotta
setblock 242 58 502 minecraft:bone_block
fill 242 58 503 242 61 503 minecraft:brown_terracotta
fill 243 58 502 243 61 502 minecraft:brown_terracotta
setblock 245 58 504 minecraft:bone_block
setblock 246 58 503 minecraft:bone_block
fill 246 58 504 246 61 504 minecraft:brown_terracotta
fill 247 58 503 247 61 503 minecraft:brown_terracotta
fill 249 58 498 249 59 499 minecraft:soul_soil
setblock 250 58 504 minecraft:bone_block
fill 251 58 504 252 60 504 minecraft:brown_terracotta
fill 254 58 503 255 58 503 minecraft:brown_terracotta
setblock 255 58 504 minecraft:bone_block
setblock 256 58 503 minecraft:bone_block
fill 256 58 504 256 61 504 minecraft:brown_terracotta
fill 257 58 503 257 61 503 minecraft:brown_terracotta
setblock 260 58 504 minecraft:bone_block
setblock 261 58 503 minecraft:bone_block
fill 261 58 504 261 61 504 minecraft:brown_terracotta
fill 263 58 504 263 59 504 minecraft:brown_terracotta
fill 274 58 477 274 59 478 minecraft:brown_terracotta
setblock 275 58 464 minecraft:bone_block
setblock 275 58 474 minecraft:bone_block
fill 275 58 475 275 61 475 minecraft:brown_terracotta
setblock 275 58 479 minecraft:bone_block
fill 275 58 480 275 61 480 minecraft:brown_terracotta
fill 275 58 482 275 59 482 minecraft:brown_terracotta
setblock 275 58 504 minecraft:bone_block
fill 276 58 464 276 61 464 minecraft:brown_terracotta
setblock 276 58 468 minecraft:bone_block
fill 276 58 469 276 61 469 minecraft:brown_terracotta
setblock 276 58 473 minecraft:bone_block
fill 276 58 474 276 61 474 minecraft:brown_terracotta
setblock 276 58 478 minecraft:bone_block
fill 276 58 479 276 61 479 minecraft:brown_terracotta
setblock 276 58 483 minecraft:bone_block
fill 276 58 484 276 61 484 minecraft:brown_terracotta
setblock 276 58 497 minecraft:brown_terracotta
setblock 276 58 498 minecraft:bone_block
fill 276 58 499 276 58 502 minecraft:brown_terracotta
setblock 276 58 503 minecraft:bone_block
fill 276 58 504 276 61 504 minecraft:brown_terracotta
setblock 236 59 467 minecraft:bone_block
fill 236 59 468 236 61 468 minecraft:brown_terracotta
setblock 236 59 472 minecraft:bone_block
fill 236 59 473 236 61 473 minecraft:brown_terracotta
setblock 236 59 477 minecraft:bone_block
fill 236 59 478 236 61 478 minecraft:brown_terracotta
setblock 236 59 482 minecraft:bone_block
fill 236 59 483 236 61 484 minecraft:brown_terracotta
setblock 236 59 496 minecraft:brown_terracotta
setblock 236 59 497 minecraft:bone_block
fill 236 59 498 236 61 498 minecraft:brown_terracotta
setblock 236 59 502 minecraft:bone_block
fill 236 59 503 236 61 503 minecraft:brown_terracotta
setblock 237 59 465 minecraft:brown_terracotta
setblock 237 59 466 minecraft:bone_block
fill 237 59 467 237 61 467 minecraft:brown_terracotta
setblock 237 59 471 minecraft:bone_block
fill 237 59 472 237 61 472 minecraft:brown_terracotta
setblock 237 59 476 minecraft:bone_block
fill 237 59 477 237 61 477 minecraft:brown_terracotta
setblock 237 59 481 minecraft:bone_block
fill 237 59 482 237 61 482 minecraft:brown_terracotta
setblock 237 59 495 minecraft:brown_terracotta
setblock 237 59 496 minecraft:bone_block
fill 237 59 497 238 61 497 minecraft:brown_terracotta
setblock 237 59 500 minecraft:brown_terracotta
setblock 237 59 501 minecraft:bone_block
fill 237 59 502 237 61 502 minecraft:brown_terracotta
setblock 238 59 465 minecraft:bone_block
setblock 238 59 500 minecraft:bone_block
fill 238 59 501 239 61 501 minecraft:brown_terracotta
setblock 239 59 464 minecraft:bone_block
fill 239 59 465 239 61 465 minecraft:brown_terracotta
fill 239 59 500 239 61 500 minecraft:brown_terracotta
setblock 239 59 504 minecraft:bone_block
fill 240 59 464 240 61 464 minecraft:brown_terracotta
setblock 240 59 503 minecraft:bone_block
fill 240 59 504 240 61 504 minecraft:brown_terracotta
fill 241 59 465 241 60 465 minecraft:brown_terracotta
setblock 241 59 501 minecraft:brown_terracotta
setblock 241 59 502 minecraft:bone_block
fill 241 59 503 241 61 503 minecraft:brown_terracotta
fill 242 59 502 242 61 502 minecraft:brown_terracotta
setblock 244 59 464 minecraft:bone_block
setblock 244 59 504 minecraft:bone_block
setblock 245 59 502 minecraft:brown_terracotta
setblock 245 59 503 minecraft:bone_block
fill 245 59 504 245 61 504 minecraft:brown_terracotta
fill 246 59 503 246 61 503 minecraft:brown_terracotta
fill 248 59 503 248 60 503 minecraft:brown_terracotta
setblock 249 59 504 minecraft:bone_block
fill 250 59 504 250 61 504 minecraft:brown_terracotta
fill 251 59 503 254 59 503 minecraft:brown_terracotta
setblock 253 59 504 minecraft:brown_terracotta
setblock 254 59 504 minecraft:bone_block
setblock 255 59 502 minecraft:brown_terracotta
setblock 255 59 503 minecraft:bone_block
fill 255 59 504 255 61 504 minecraft:brown_terracotta
setblock 256 59 502 minecraft:bone_block
fill 256 59 503 256 61 503 minecraft:brown_terracotta
fill 257 59 502 259 60 502 minecraft:brown_terracotta
setblock 259 59 503 minecraft:brown_terracotta
setblock 259 59 504 minecraft:bone_block
setblock 260 59 503 minecraft:bone_block
fill 260 59 504 260 61 504 minecraft:brown_terracotta
fill 261 59 503 262 61 503 minecraft:brown_terracotta
setblock 274 59 464 minecraft:bone_block
fill 274 59 476 274 61 476 minecraft:brown_terracotta
setblock 274 59 479 minecraft:bone_block
fill 274 59 480 274 61 480 minecraft:brown_terracotta
setblock 274 59 504 minecraft:bone_block
fill 275 59 464 275 61 464 minecraft:brown_terracotta
fill 275 59 471 275 60 471 minecraft:brown_terracotta
setblock 275 59 473 minecraft:bone_block
fill 275 59 474 275 61 474 minecraft:brown_terracotta
setblock 275 59 478 minecraft:bone_block
fill 275 59 479 275 61 479 minecraft:brown_terracotta
setblock 275 59 483 minecraft:bone_block
fill 275 59 504 275 61 504 minecraft:brown_terracotta
fill 276 59 465 276 59 466 minecraft:brown_terracotta
setblock 276 59 467 minecraft:bone_block
fill 276 59 468 276 61 468 minecraft:brown_terracotta
setblock 276 59 472 minecraft:bone_block
fill 276 59 473 276 61 473 minecraft:brown_terracotta
setblock 276 59 477 minecraft:bone_block
fill 276 59 478 276 61 478 minecraft:brown_terracotta
setblock 276 59 482 minecraft:bone_block
fill 276 59 483 276 61 483 minecraft:brown_terracotta
fill 276 59 485 276 59 486 minecraft:brown_terracotta
setblock 276 59 497 minecraft:bone_block
fill 276 59 498 276 59 501 minecraft:brown_terracotta
setblock 276 59 502 minecraft:bone_block
fill 276 59 503 276 61 503 minecraft:brown_terracotta
setblock 236 60 466 minecraft:bone_block
fill 236 60 467 236 61 467 minecraft:brown_terracotta
setblock 236 60 471 minecraft:bone_block
fill 236 60 472 236 61 472 minecraft:brown_terracotta
setblock 236 60 476 minecraft:bone_block
fill 236 60 477 236 61 477 minecraft:brown_terracotta
setblock 236 60 481 minecraft:bone_block
fill 236 60 482 236 61 482 minecraft:brown_terracotta
setblock 236 60 485 minecraft:brown_terracotta
setblock 236 60 486 minecraft:bone_block
fill 236 60 493 236 61 493 minecraft:brown_terracotta
setblock 236 60 496 minecraft:bone_block
fill 236 60 497 236 61 497 minecraft:brown_terracotta
setblock 236 60 501 minecraft:bone_block
fill 236 60 502 236 61 502 minecraft:brown_terracotta
setblock 237 60 465 minecraft:bone_block
fill 237 60 466 237 61 466 minecraft:brown_terracotta
fill 237 60 468 237 60 469 minecraft:brown_terracotta
setblock 237 60 470 minecraft:bone_block
fill 237 60 471 237 61 471 minecraft:brown_terracotta
setblock 237 60 475 minecraft:bone_block
fill 237 60 476 237 61 476 minecraft:brown_terracotta
setblock 237 60 480 minecraft:bone_block
fill 237 60 481 237 61 481 minecraft:brown_terracotta
fill 237 60 483 237 61 483 minecraft:brown_terracotta
setblock 237 60 495 minecraft:bone_block
fill 237 60 496 237 61 496 minecraft:brown_terracotta
setblock 237 60 500 minecraft:bone_block
fill 237 60 501 237 61 501 minecraft:brown_terracotta
setblock 238 60 464 minecraft:bone_block
fill 238 60 465 238 61 465 minecraft:brown_terracotta
setblock 238 60 499 minecraft:bone_block
fill 238 60 500 238 61 500 minecraft:brown_terracotta
setblock 238 60 504 minecraft:bone_block
fill 239 60 464 239 61 464 minecraft:brown_terracotta
fill 239 60 499 239 61 499 minecraft:brown_terracotta
setblock 239 60 503 minecraft:bone_block
fill 239 60 504 239 61 504 minecraft:brown_terracotta
setblock 240 60 502 minecraft:bone_block
fill 240 60 503 240 61 503 minecraft:brown_terracotta
setblock 241 60 501 minecraft:bone_block
fill 241 60 502 241 61 502 minecraft:brown_terracotta
fill 242 60 501 242 61 501 minecraft:brown_terracotta
setblock 243 60 464 minecraft:bone_block
setblock 243 60 504 minecraft:bone_block
fill 244 60 464 244 61 464 minecraft:brown_terracotta
setblock 244 60 503 minecraft:bone_block
fill 244 60 504 244 61 504 minecraft:brown_terracotta
setblock 245 60 502 minecraft:bone_block
fill 245 60 503 245 61 503 minecraft:brown_terracotta
setblock 248 60 504 minecraft:bone_block
setblock 249 60 503 minecraft:bone_block
fill 249 60 504 249 61 504 minecraft:brown_terracotta
fill 250 60 503 253 60 503 minecraft:brown_terracotta
fill 253 60 502 254 60 502 minecraft:brown_terracotta
setblock 253 60 504 minecraft:bone_block
setblock 254 60 503 minecraft:bone_block
fill 254 60 504 254 61 504 minecraft:brown_terracotta
setblock 255 60 502 minecraft:bone_block
fill 255 60 503 255 61 503 minecraft:brown_terracotta
fill 256 60 464 257 60 464 minecraft:brown_terracotta
fill 256 60 502 256 61 502 minecraft:brown_terracotta
setblock 258 60 464 minecraft:bone_block
setblock 258 60 504 minecraft:bone_block
fill 259 60 464 261 61 464 minecraft:brown_terracotta
setblock 259 60 503 minecraft:bone_block
fill 259 60 504 259 61 504 minecraft:brown_terracotta
setblock 260 60 502 minecraft:bone_block
fill 260 60 503 260 61 503 minecraft:brown_terracotta
setblock 263 60 504 minecraft:bone_block
fill 264 60 504 264 61 504 minecraft:brown_terracotta
setblock 272 60 464 minecraft:brown_terracotta
setblock 272 60 504 minecraft:brown_terracotta
setblock 273 60 464 minecraft:bone_block
setblock 273 60 504 minecraft:bone_block
fill 274 60 464 274 61 464 minecraft:brown_terracotta
schedule function dropper:buildpart/113_3 1t
