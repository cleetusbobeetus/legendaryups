fill 385 234 183 388 234 183 minecraft:mossy_cobblestone
setblock 385 234 195 minecraft:cobbled_deepslate
setblock 385 234 197 minecraft:cobbled_deepslate
fill 386 234 182 389 234 182 minecraft:mossy_cobblestone
setblock 386 234 193 minecraft:cobbled_deepslate
fill 386 234 222 389 234 222 minecraft:mossy_cobblestone
fill 387 234 199 389 234 199 minecraft:cobbled_deepslate
setblock 389 234 183 minecraft:stone_bricks
fill 389 234 184 389 237 184 minecraft:mossy_cobblestone
setblock 390 234 182 minecraft:stone_bricks
fill 390 234 183 393 234 183 minecraft:mossy_cobblestone
setblock 390 234 193 minecraft:cobbled_deepslate
setblock 390 234 198 minecraft:cobbled_deepslate
setblock 390 234 221 minecraft:mossy_cobblestone
setblock 390 234 222 minecraft:stone_bricks
fill 391 234 182 394 234 182 minecraft:mossy_cobblestone
fill 391 234 195 391 234 197 minecraft:cobbled_deepslate
setblock 391 234 221 minecraft:stone_bricks
fill 391 234 222 394 234 222 minecraft:mossy_cobblestone
fill 392 234 221 395 234 221 minecraft:mossy_cobblestone
setblock 393 234 184 minecraft:stone_bricks
setblock 394 234 183 minecraft:stone_bricks
fill 394 234 184 394 237 184 minecraft:mossy_cobblestone
fill 394 234 220 395 234 220 minecraft:mossy_cobblestone
setblock 395 234 182 minecraft:stone_bricks
fill 395 234 183 395 237 183 minecraft:mossy_cobblestone
setblock 395 234 222 minecraft:stone_bricks
fill 396 234 182 396 237 182 minecraft:mossy_cobblestone
setblock 396 234 221 minecraft:stone_bricks
fill 396 234 222 399 234 222 minecraft:mossy_cobblestone
fill 397 234 221 400 234 221 minecraft:mossy_cobblestone
setblock 399 234 183 minecraft:stone_bricks
setblock 400 234 182 minecraft:stone_bricks
setblock 400 234 222 minecraft:stone_bricks
fill 401 234 182 401 235 182 minecraft:mossy_cobblestone
fill 401 234 222 404 234 222 minecraft:mossy_cobblestone
setblock 405 234 222 minecraft:stone_bricks
setblock 406 234 222 minecraft:mossy_cobblestone
setblock 410 234 182 minecraft:stone_bricks
setblock 410 234 222 minecraft:stone_bricks
fill 411 234 182 411 237 182 minecraft:mossy_cobblestone
fill 411 234 222 411 237 222 minecraft:mossy_cobblestone
setblock 414 234 183 minecraft:stone_bricks
setblock 414 234 203 minecraft:stone_bricks
fill 414 234 204 414 237 204 minecraft:mossy_cobblestone
setblock 414 234 207 minecraft:mossy_cobblestone
setblock 415 234 182 minecraft:stone_bricks
fill 415 234 183 415 237 183 minecraft:mossy_cobblestone
setblock 415 234 202 minecraft:stone_bricks
fill 415 234 203 415 237 203 minecraft:mossy_cobblestone
setblock 415 234 207 minecraft:stone_bricks
fill 415 234 208 415 237 208 minecraft:mossy_cobblestone
setblock 415 234 222 minecraft:stone_bricks
fill 416 234 182 416 237 182 minecraft:mossy_cobblestone
setblock 416 234 185 minecraft:mossy_cobblestone
setblock 416 234 186 minecraft:stone_bricks
setblock 416 234 196 minecraft:stone_bricks
fill 416 234 197 416 235 197 minecraft:mossy_cobblestone
setblock 416 234 201 minecraft:stone_bricks
fill 416 234 202 416 237 202 minecraft:mossy_cobblestone
setblock 416 234 206 minecraft:stone_bricks
fill 416 234 207 416 237 207 minecraft:mossy_cobblestone
setblock 416 234 211 minecraft:stone_bricks
fill 416 234 222 416 235 222 minecraft:mossy_cobblestone
setblock 417 234 185 minecraft:stone_bricks
fill 417 234 186 417 234 189 minecraft:mossy_cobblestone
setblock 417 234 190 minecraft:stone_bricks
fill 417 234 191 417 234 194 minecraft:mossy_cobblestone
setblock 417 234 195 minecraft:stone_bricks
fill 417 234 196 417 237 196 minecraft:mossy_cobblestone
setblock 417 234 200 minecraft:stone_bricks
fill 417 234 201 417 237 201 minecraft:mossy_cobblestone
setblock 417 234 205 minecraft:stone_bricks
fill 417 234 206 417 237 206 minecraft:mossy_cobblestone
setblock 417 234 210 minecraft:stone_bricks
fill 417 234 211 417 237 211 minecraft:mossy_cobblestone
setblock 417 234 221 minecraft:mossy_cobblestone
fill 377 235 182 377 235 183 minecraft:mossy_cobblestone
setblock 377 235 184 minecraft:stone_bricks
fill 377 235 185 377 235 188 minecraft:mossy_cobblestone
setblock 377 235 189 minecraft:stone_bricks
fill 377 235 190 377 235 193 minecraft:mossy_cobblestone
setblock 377 235 194 minecraft:stone_bricks
fill 377 235 195 377 235 198 minecraft:mossy_cobblestone
setblock 377 235 199 minecraft:stone_bricks
fill 377 235 200 377 235 203 minecraft:mossy_cobblestone
setblock 377 235 204 minecraft:stone_bricks
fill 377 235 205 377 238 205 minecraft:mossy_cobblestone
setblock 377 235 208 minecraft:mossy_cobblestone
setblock 377 235 209 minecraft:stone_bricks
setblock 378 235 182 minecraft:mossy_cobblestone
setblock 378 235 183 minecraft:stone_bricks
fill 378 235 184 378 235 187 minecraft:mossy_cobblestone
setblock 378 235 188 minecraft:stone_bricks
fill 378 235 189 378 238 189 minecraft:mossy_cobblestone
setblock 378 235 203 minecraft:stone_bricks
setblock 378 235 204 minecraft:mossy_cobblestone
setblock 379 235 182 minecraft:stone_bricks
fill 379 235 183 382 235 183 minecraft:mossy_cobblestone
fill 380 235 182 383 235 182 minecraft:mossy_cobblestone
setblock 383 235 183 minecraft:stone_bricks
setblock 384 235 182 minecraft:stone_bricks
fill 384 235 183 387 235 183 minecraft:mossy_cobblestone
fill 385 235 182 388 235 182 minecraft:mossy_cobblestone
fill 387 235 195 389 235 196 minecraft:lantern
fill 387 235 222 388 235 222 minecraft:mossy_cobblestone
setblock 388 235 183 minecraft:stone_bricks
fill 388 235 184 388 238 184 minecraft:mossy_cobblestone
setblock 388 235 197 minecraft:lantern
setblock 389 235 182 minecraft:stone_bricks
fill 389 235 183 392 235 183 minecraft:mossy_cobblestone
setblock 389 235 222 minecraft:stone_bricks
fill 390 235 182 393 235 182 minecraft:mossy_cobblestone
setblock 390 235 221 minecraft:stone_bricks
fill 390 235 222 393 235 222 minecraft:mossy_cobblestone
fill 391 235 221 394 235 221 minecraft:mossy_cobblestone
setblock 392 235 184 minecraft:stone_bricks
setblock 393 235 183 minecraft:stone_bricks
fill 393 235 184 393 238 184 minecraft:mossy_cobblestone
setblock 394 235 182 minecraft:stone_bricks
fill 394 235 183 394 238 183 minecraft:mossy_cobblestone
setblock 394 235 222 minecraft:stone_bricks
fill 395 235 182 395 238 182 minecraft:mossy_cobblestone
setblock 395 235 221 minecraft:stone_bricks
fill 395 235 222 398 235 222 minecraft:mossy_cobblestone
fill 396 235 221 398 235 221 minecraft:mossy_cobblestone
setblock 398 235 183 minecraft:stone_bricks
setblock 399 235 182 minecraft:stone_bricks
setblock 399 235 222 minecraft:stone_bricks
fill 400 235 182 400 236 182 minecraft:mossy_cobblestone
fill 400 235 222 402 235 222 minecraft:mossy_cobblestone
setblock 409 235 182 minecraft:stone_bricks
setblock 409 235 222 minecraft:stone_bricks
fill 410 235 182 410 238 182 minecraft:mossy_cobblestone
fill 410 235 222 410 238 222 minecraft:mossy_cobblestone
setblock 412 235 183 minecraft:mossy_cobblestone
setblock 413 235 183 minecraft:stone_bricks
setblock 414 235 182 minecraft:stone_bricks
fill 414 235 183 414 238 183 minecraft:mossy_cobblestone
fill 414 235 203 414 236 203 minecraft:mossy_cobblestone
setblock 414 235 207 minecraft:stone_bricks
setblock 414 235 222 minecraft:stone_bricks
fill 415 235 182 415 238 182 minecraft:mossy_cobblestone
setblock 415 235 201 minecraft:stone_bricks
fill 415 235 202 415 238 202 minecraft:mossy_cobblestone
setblock 415 235 206 minecraft:stone_bricks
fill 415 235 207 415 238 207 minecraft:mossy_cobblestone
fill 415 235 222 415 236 222 minecraft:mossy_cobblestone
setblock 416 235 185 minecraft:stone_bricks
fill 416 235 186 417 236 187 minecraft:mossy_cobblestone
setblock 416 235 200 minecraft:stone_bricks
fill 416 235 201 416 238 201 minecraft:mossy_cobblestone
setblock 416 235 205 minecraft:stone_bricks
fill 416 235 206 416 238 206 minecraft:mossy_cobblestone
setblock 416 235 210 minecraft:stone_bricks
fill 416 235 211 416 238 211 minecraft:mossy_cobblestone
setblock 417 235 184 minecraft:stone_bricks
fill 417 235 185 417 238 185 minecraft:mossy_cobblestone
setblock 417 235 188 minecraft:mossy_cobblestone
setblock 417 235 189 minecraft:stone_bricks
fill 417 235 190 417 235 193 minecraft:mossy_cobblestone
setblock 417 235 194 minecraft:stone_bricks
fill 417 235 195 417 238 195 minecraft:mossy_cobblestone
setblock 417 235 199 minecraft:stone_bricks
fill 417 235 200 417 238 200 minecraft:mossy_cobblestone
setblock 417 235 204 minecraft:stone_bricks
fill 417 235 205 417 238 205 minecraft:mossy_cobblestone
setblock 417 235 209 minecraft:stone_bricks
fill 417 235 210 417 238 210 minecraft:mossy_cobblestone
setblock 377 236 182 minecraft:mossy_cobblestone
setblock 377 236 183 minecraft:stone_bricks
fill 377 236 184 377 236 187 minecraft:mossy_cobblestone
setblock 377 236 188 minecraft:stone_bricks
fill 377 236 189 377 236 192 minecraft:mossy_cobblestone
setblock 377 236 193 minecraft:stone_bricks
fill 377 236 194 377 236 197 minecraft:mossy_cobblestone
setblock 377 236 198 minecraft:stone_bricks
fill 377 236 199 377 236 202 minecraft:mossy_cobblestone
setblock 377 236 203 minecraft:stone_bricks
fill 377 236 204 377 239 204 minecraft:mossy_cobblestone
setblock 377 236 208 minecraft:stone_bricks
fill 377 236 209 377 239 209 minecraft:mossy_cobblestone
setblock 378 236 182 minecraft:stone_bricks
fill 378 236 183 378 236 186 minecraft:mossy_cobblestone
setblock 378 236 187 minecraft:stone_bricks
fill 378 236 188 378 239 188 minecraft:mossy_cobblestone
fill 379 236 182 381 236 183 minecraft:mossy_cobblestone
setblock 382 236 182 minecraft:mossy_cobblestone
setblock 382 236 183 minecraft:stone_bricks
setblock 383 236 182 minecraft:stone_bricks
fill 383 236 183 386 236 183 minecraft:mossy_cobblestone
fill 384 236 182 387 236 182 minecraft:mossy_cobblestone
setblock 387 236 183 minecraft:stone_bricks
fill 387 236 196 389 236 196 minecraft:lantern
setblock 387 236 222 minecraft:mossy_cobblestone
setblock 388 236 182 minecraft:stone_bricks
fill 388 236 183 391 236 183 minecraft:mossy_cobblestone
fill 388 236 195 388 237 195 minecraft:lantern
setblock 388 236 222 minecraft:stone_bricks
fill 389 236 182 392 236 182 minecraft:mossy_cobblestone
fill 389 236 222 392 236 222 minecraft:mossy_cobblestone
fill 390 236 221 393 236 221 minecraft:mossy_cobblestone
setblock 391 236 184 minecraft:stone_bricks
setblock 392 236 183 minecraft:stone_bricks
fill 392 236 184 392 239 184 minecraft:mossy_cobblestone
setblock 393 236 182 minecraft:stone_bricks
fill 393 236 183 393 239 183 minecraft:mossy_cobblestone
setblock 393 236 222 minecraft:stone_bricks
fill 394 236 182 394 239 182 minecraft:mossy_cobblestone
setblock 394 236 221 minecraft:stone_bricks
fill 394 236 222 397 236 222 minecraft:mossy_cobblestone
fill 395 236 221 397 236 221 minecraft:mossy_cobblestone
setblock 397 236 183 minecraft:stone_bricks
setblock 398 236 182 minecraft:stone_bricks
setblock 398 236 183 minecraft:mossy_cobblestone
setblock 398 236 222 minecraft:stone_bricks
fill 399 236 182 399 238 182 minecraft:mossy_cobblestone
fill 399 236 222 401 236 222 minecraft:mossy_cobblestone
fill 409 236 182 409 239 182 minecraft:mossy_cobblestone
fill 409 236 222 409 239 222 minecraft:mossy_cobblestone
setblock 412 236 183 minecraft:stone_bricks
setblock 413 236 182 minecraft:stone_bricks
fill 413 236 183 413 239 183 minecraft:mossy_cobblestone
setblock 413 236 222 minecraft:stone_bricks
fill 414 236 182 414 239 182 minecraft:mossy_cobblestone
setblock 414 236 206 minecraft:stone_bricks
fill 414 236 207 414 239 207 minecraft:mossy_cobblestone
fill 414 236 222 414 237 222 minecraft:mossy_cobblestone
setblock 415 236 200 minecraft:stone_bricks
fill 415 236 201 415 237 201 minecraft:mossy_cobblestone
setblock 415 236 205 minecraft:stone_bricks
fill 415 236 206 415 239 206 minecraft:mossy_cobblestone
setblock 416 236 184 minecraft:stone_bricks
fill 416 236 185 416 239 185 minecraft:mossy_cobblestone
setblock 416 236 188 minecraft:mossy_cobblestone
setblock 416 236 199 minecraft:stone_bricks
fill 416 236 200 416 239 200 minecraft:mossy_cobblestone
setblock 416 236 204 minecraft:stone_bricks
fill 416 236 205 416 239 205 minecraft:mossy_cobblestone
setblock 416 236 209 minecraft:stone_bricks
fill 416 236 210 416 239 210 minecraft:mossy_cobblestone
setblock 417 236 183 minecraft:stone_bricks
fill 417 236 184 417 239 184 minecraft:mossy_cobblestone
setblock 417 236 188 minecraft:stone_bricks
fill 417 236 189 417 236 192 minecraft:mossy_cobblestone
setblock 417 236 193 minecraft:stone_bricks
fill 417 236 194 417 239 194 minecraft:mossy_cobblestone
setblock 417 236 198 minecraft:stone_bricks
fill 417 236 199 417 239 199 minecraft:mossy_cobblestone
setblock 417 236 203 minecraft:stone_bricks
fill 417 236 204 417 239 204 minecraft:mossy_cobblestone
setblock 417 236 208 minecraft:stone_bricks
fill 417 236 209 417 239 209 minecraft:mossy_cobblestone
setblock 377 237 182 minecraft:stone_bricks
fill 377 237 183 377 237 186 minecraft:mossy_cobblestone
setblock 377 237 187 minecraft:stone_bricks
fill 377 237 188 377 237 191 minecraft:mossy_cobblestone
setblock 377 237 192 minecraft:stone_bricks
fill 377 237 193 377 237 196 minecraft:mossy_cobblestone
setblock 377 237 197 minecraft:stone_bricks
fill 377 237 198 377 237 201 minecraft:mossy_cobblestone
setblock 377 237 202 minecraft:stone_bricks
fill 377 237 203 377 240 203 minecraft:mossy_cobblestone
setblock 377 237 207 minecraft:stone_bricks
fill 377 237 208 377 240 208 minecraft:mossy_cobblestone
fill 378 237 182 378 237 185 minecraft:mossy_cobblestone
setblock 378 237 186 minecraft:stone_bricks
fill 378 237 187 378 240 187 minecraft:mossy_cobblestone
setblock 378 237 190 minecraft:mossy_cobblestone
fill 379 237 182 380 237 183 minecraft:mossy_cobblestone
setblock 381 237 182 minecraft:mossy_cobblestone
setblock 381 237 183 minecraft:stone_bricks
setblock 382 237 182 minecraft:stone_bricks
fill 382 237 183 385 237 183 minecraft:mossy_cobblestone
fill 383 237 182 386 237 182 minecraft:mossy_cobblestone
setblock 386 237 183 minecraft:stone_bricks
setblock 386 237 222 minecraft:mossy_cobblestone
setblock 387 237 182 minecraft:stone_bricks
fill 387 237 183 387 239 184 minecraft:mossy_cobblestone
setblock 387 237 222 minecraft:stone_bricks
fill 388 237 182 390 237 183 minecraft:mossy_cobblestone
fill 388 237 196 388 239 196 minecraft:lantern
fill 388 237 222 391 237 222 minecraft:mossy_cobblestone
fill 389 237 221 392 237 221 minecraft:mossy_cobblestone
setblock 390 237 184 minecraft:stone_bricks
setblock 391 237 182 minecraft:mossy_cobblestone
setblock 391 237 183 minecraft:stone_bricks
fill 391 237 184 391 240 184 minecraft:mossy_cobblestone
setblock 392 237 182 minecraft:stone_bricks
fill 392 237 183 392 240 183 minecraft:mossy_cobblestone
setblock 392 237 222 minecraft:stone_bricks
fill 393 237 182 393 240 182 minecraft:mossy_cobblestone
setblock 393 237 221 minecraft:stone_bricks
fill 393 237 222 396 237 222 minecraft:mossy_cobblestone
fill 394 237 221 396 238 221 minecraft:mossy_cobblestone
setblock 395 237 184 minecraft:stone_bricks
setblock 396 237 183 minecraft:stone_bricks
setblock 397 237 182 minecraft:stone_bricks
fill 397 237 183 397 238 183 minecraft:mossy_cobblestone
setblock 397 237 222 minecraft:stone_bricks
fill 398 237 182 398 240 182 minecraft:mossy_cobblestone
fill 398 237 222 400 237 222 minecraft:mossy_cobblestone
fill 408 237 182 408 240 182 minecraft:mossy_cobblestone
setblock 411 237 183 minecraft:stone_bricks
setblock 412 237 182 minecraft:stone_bricks
fill 412 237 183 412 240 183 minecraft:mossy_cobblestone
setblock 412 237 222 minecraft:stone_bricks
fill 413 237 182 413 240 182 minecraft:mossy_cobblestone
fill 413 237 222 413 239 222 minecraft:mossy_cobblestone
setblock 414 237 205 minecraft:stone_bricks
fill 414 237 206 414 240 206 minecraft:mossy_cobblestone
setblock 415 237 204 minecraft:stone_bricks
fill 415 237 205 415 240 205 minecraft:mossy_cobblestone
setblock 415 237 209 minecraft:stone_bricks
setblock 416 237 183 minecraft:stone_bricks
fill 416 237 184 416 240 184 minecraft:mossy_cobblestone
fill 416 237 186 416 237 187 minecraft:mossy_cobblestone
setblock 416 237 188 minecraft:stone_bricks
fill 416 237 189 417 238 190 minecraft:mossy_cobblestone
fill 416 237 199 416 239 199 minecraft:mossy_cobblestone
setblock 416 237 203 minecraft:stone_bricks
fill 416 237 204 416 240 204 minecraft:mossy_cobblestone
setblock 416 237 208 minecraft:stone_bricks
fill 416 237 209 416 240 209 minecraft:mossy_cobblestone
setblock 417 237 182 minecraft:stone_bricks
fill 417 237 183 417 240 183 minecraft:mossy_cobblestone
setblock 417 237 186 minecraft:mossy_cobblestone
setblock 417 237 187 minecraft:stone_bricks
fill 417 237 188 417 240 188 minecraft:mossy_cobblestone
setblock 417 237 191 minecraft:mossy_cobblestone
setblock 417 237 192 minecraft:stone_bricks
fill 417 237 193 417 240 193 minecraft:mossy_cobblestone
setblock 417 237 197 minecraft:stone_bricks
fill 417 237 198 417 240 198 minecraft:mossy_cobblestone
setblock 417 237 202 minecraft:stone_bricks
fill 417 237 203 417 240 203 minecraft:mossy_cobblestone
setblock 417 237 207 minecraft:stone_bricks
fill 417 237 208 417 240 208 minecraft:mossy_cobblestone
setblock 417 237 212 minecraft:stone_bricks
fill 377 238 182 377 238 185 minecraft:mossy_cobblestone
setblock 377 238 186 minecraft:stone_bricks
fill 377 238 187 377 238 190 minecraft:mossy_cobblestone
setblock 377 238 191 minecraft:stone_bricks
fill 377 238 192 377 238 195 minecraft:mossy_cobblestone
setblock 377 238 200 minecraft:mossy_cobblestone
setblock 377 238 201 minecraft:stone_bricks
fill 377 238 202 377 239 202 minecraft:mossy_cobblestone
setblock 377 238 206 minecraft:stone_bricks
fill 377 238 207 377 241 207 minecraft:mossy_cobblestone
setblock 377 238 210 minecraft:mossy_cobblestone
fill 378 238 182 378 238 184 minecraft:mossy_cobblestone
setblock 378 238 185 minecraft:stone_bricks
fill 378 238 186 378 241 186 minecraft:mossy_cobblestone
setblock 378 238 190 minecraft:stone_bricks
fill 379 238 182 379 238 183 minecraft:mossy_cobblestone
setblock 380 238 182 minecraft:mossy_cobblestone
setblock 380 238 183 minecraft:stone_bricks
setblock 381 238 182 minecraft:stone_bricks
fill 381 238 183 384 238 183 minecraft:mossy_cobblestone
fill 382 238 182 385 238 182 minecraft:mossy_cobblestone
setblock 385 238 183 minecraft:stone_bricks
setblock 386 238 182 minecraft:stone_bricks
fill 386 238 183 386 240 184 minecraft:mossy_cobblestone
setblock 386 238 222 minecraft:stone_bricks
fill 387 238 182 390 238 182 minecraft:mossy_cobblestone
fill 387 238 222 390 238 222 minecraft:mossy_cobblestone
fill 388 238 183 389 238 183 minecraft:mossy_cobblestone
setblock 389 238 184 minecraft:stone_bricks
fill 389 238 221 391 238 221 minecraft:mossy_cobblestone
setblock 390 238 183 minecraft:stone_bricks
fill 390 238 184 390 241 184 minecraft:mossy_cobblestone
setblock 391 238 182 minecraft:stone_bricks
fill 391 238 183 391 241 183 minecraft:mossy_cobblestone
setblock 391 238 222 minecraft:stone_bricks
fill 392 238 182 392 241 182 minecraft:mossy_cobblestone
setblock 392 238 221 minecraft:stone_bricks
fill 392 238 222 395 238 222 minecraft:mossy_cobblestone
fill 393 238 221 393 241 221 minecraft:mossy_cobblestone
setblock 394 238 184 minecraft:stone_bricks
setblock 395 238 183 minecraft:stone_bricks
setblock 395 238 184 minecraft:mossy_cobblestone
setblock 396 238 182 minecraft:stone_bricks
fill 396 238 183 396 240 183 minecraft:mossy_cobblestone
setblock 396 238 222 minecraft:stone_bricks
fill 397 238 182 397 241 182 minecraft:mossy_cobblestone
fill 397 238 222 399 238 222 minecraft:mossy_cobblestone
setblock 410 238 183 minecraft:stone_bricks
setblock 411 238 182 minecraft:stone_bricks
fill 411 238 183 411 241 183 minecraft:mossy_cobblestone
setblock 411 238 222 minecraft:stone_bricks
fill 412 238 182 412 241 182 minecraft:mossy_cobblestone
fill 412 238 222 412 241 222 minecraft:mossy_cobblestone
setblock 414 238 204 minecraft:stone_bricks
fill 414 238 205 414 239 205 minecraft:mossy_cobblestone
setblock 414 238 208 minecraft:mossy_cobblestone
setblock 415 238 183 minecraft:stone_bricks
setblock 415 238 203 minecraft:stone_bricks
fill 415 238 204 415 241 204 minecraft:mossy_cobblestone
setblock 415 238 208 minecraft:stone_bricks
fill 415 238 209 415 240 210 minecraft:mossy_cobblestone
setblock 416 238 182 minecraft:stone_bricks
setblock 416 238 183 minecraft:mossy_cobblestone
setblock 416 238 186 minecraft:mossy_cobblestone
setblock 416 238 187 minecraft:stone_bricks
fill 416 238 188 416 241 188 minecraft:mossy_cobblestone
setblock 416 238 191 minecraft:mossy_cobblestone
setblock 416 238 192 minecraft:stone_bricks
setblock 416 238 202 minecraft:stone_bricks
fill 416 238 203 416 241 203 minecraft:mossy_cobblestone
setblock 416 238 207 minecraft:stone_bricks
fill 416 238 208 416 241 208 minecraft:mossy_cobblestone
fill 417 238 182 417 241 182 minecraft:mossy_cobblestone
setblock 417 238 186 minecraft:stone_bricks
fill 417 238 187 417 241 187 minecraft:mossy_cobblestone
setblock 417 238 191 minecraft:stone_bricks
fill 417 238 192 417 241 192 minecraft:mossy_cobblestone
setblock 417 238 196 minecraft:stone_bricks
fill 417 238 197 417 241 197 minecraft:mossy_cobblestone
setblock 417 238 201 minecraft:stone_bricks
fill 417 238 202 417 241 202 minecraft:mossy_cobblestone
setblock 417 238 206 minecraft:stone_bricks
fill 417 238 207 417 241 207 minecraft:mossy_cobblestone
setblock 417 238 211 minecraft:stone_bricks
fill 417 238 212 417 241 212 minecraft:mossy_cobblestone
fill 377 239 182 377 239 184 minecraft:mossy_cobblestone
setblock 377 239 185 minecraft:stone_bricks
fill 377 239 186 377 239 189 minecraft:mossy_cobblestone
setblock 377 239 190 minecraft:stone_bricks
fill 377 239 191 377 239 194 minecraft:mossy_cobblestone
setblock 377 239 195 minecraft:stone_bricks
setblock 377 239 205 minecraft:stone_bricks
fill 377 239 206 377 241 206 minecraft:mossy_cobblestone
setblock 377 239 210 minecraft:stone_bricks
fill 378 239 182 378 239 183 minecraft:mossy_cobblestone
setblock 378 239 184 minecraft:stone_bricks
fill 378 239 185 378 242 185 minecraft:mossy_cobblestone
setblock 378 239 189 minecraft:stone_bricks
fill 378 239 190 378 241 191 minecraft:mossy_cobblestone
setblock 379 239 182 minecraft:mossy_cobblestone
setblock 379 239 183 minecraft:stone_bricks
setblock 380 239 182 minecraft:stone_bricks
fill 380 239 183 383 239 183 minecraft:mossy_cobblestone
fill 381 239 182 384 239 182 minecraft:mossy_cobblestone
setblock 384 239 183 minecraft:stone_bricks
setblock 385 239 182 minecraft:stone_bricks
fill 385 239 183 385 241 184 minecraft:mossy_cobblestone
setblock 385 239 222 minecraft:stone_bricks
fill 386 239 182 389 239 182 minecraft:mossy_cobblestone
fill 386 239 222 389 239 222 minecraft:mossy_cobblestone
setblock 388 239 183 minecraft:mossy_cobblestone
setblock 388 239 184 minecraft:stone_bricks
fill 388 239 221 390 239 221 minecraft:mossy_cobblestone
setblock 389 239 183 minecraft:stone_bricks
fill 389 239 184 389 241 185 minecraft:mossy_cobblestone
setblock 390 239 182 minecraft:stone_bricks
fill 390 239 183 390 242 183 minecraft:mossy_cobblestone
fill 390 239 185 391 239 185 minecraft:mossy_cobblestone
setblock 390 239 222 minecraft:stone_bricks
fill 391 239 182 391 242 182 minecraft:mossy_cobblestone
setblock 391 239 221 minecraft:stone_bricks
fill 391 239 222 394 239 222 minecraft:mossy_cobblestone
fill 392 239 221 392 242 221 minecraft:mossy_cobblestone
setblock 393 239 184 minecraft:stone_bricks
setblock 394 239 183 minecraft:stone_bricks
fill 394 239 184 394 240 184 minecraft:mossy_cobblestone
fill 394 239 221 395 239 221 minecraft:mossy_cobblestone
setblock 395 239 182 minecraft:stone_bricks
fill 395 239 183 395 241 183 minecraft:mossy_cobblestone
setblock 395 239 222 minecraft:stone_bricks
fill 396 239 182 396 242 182 minecraft:mossy_cobblestone
fill 396 239 222 398 240 222 minecraft:mossy_cobblestone
fill 407 239 182 407 241 182 minecraft:mossy_cobblestone
fill 408 239 222 408 240 222 minecraft:mossy_cobblestone
setblock 410 239 182 minecraft:stone_bricks
fill 410 239 183 410 242 183 minecraft:mossy_cobblestone
setblock 410 239 222 minecraft:stone_bricks
fill 411 239 182 411 242 182 minecraft:mossy_cobblestone
fill 411 239 222 411 242 222 minecraft:mossy_cobblestone
setblock 414 239 183 minecraft:stone_bricks
setblock 414 239 208 minecraft:stone_bricks
setblock 415 239 182 minecraft:stone_bricks
fill 415 239 183 415 241 183 minecraft:mossy_cobblestone
setblock 415 239 187 minecraft:stone_bricks
fill 415 239 188 415 241 189 minecraft:mossy_cobblestone
setblock 415 239 202 minecraft:stone_bricks
fill 415 239 203 415 240 203 minecraft:mossy_cobblestone
setblock 415 239 207 minecraft:stone_bricks
fill 415 239 208 415 242 208 minecraft:mossy_cobblestone
fill 416 239 182 416 242 182 minecraft:mossy_cobblestone
setblock 416 239 186 minecraft:stone_bricks
fill 416 239 187 416 242 187 minecraft:mossy_cobblestone
fill 416 239 189 416 239 190 minecraft:mossy_cobblestone
setblock 416 239 191 minecraft:stone_bricks
fill 416 239 192 416 241 193 minecraft:mossy_cobblestone
setblock 416 239 201 minecraft:stone_bricks
fill 416 239 202 416 241 202 minecraft:mossy_cobblestone
setblock 416 239 206 minecraft:stone_bricks
fill 416 239 207 416 242 207 minecraft:mossy_cobblestone
setblock 416 239 211 minecraft:stone_bricks
fill 416 239 212 416 242 212 minecraft:mossy_cobblestone
setblock 417 239 185 minecraft:stone_bricks
fill 417 239 186 417 242 186 minecraft:mossy_cobblestone
setblock 417 239 189 minecraft:mossy_cobblestone
setblock 417 239 190 minecraft:stone_bricks
fill 417 239 191 417 242 191 minecraft:mossy_cobblestone
setblock 417 239 195 minecraft:stone_bricks
fill 417 239 196 417 242 196 minecraft:mossy_cobblestone
setblock 417 239 200 minecraft:stone_bricks
fill 417 239 201 417 242 201 minecraft:mossy_cobblestone
setblock 417 239 205 minecraft:stone_bricks
fill 417 239 206 417 242 206 minecraft:mossy_cobblestone
setblock 417 239 210 minecraft:stone_bricks
fill 417 239 211 417 242 211 minecraft:mossy_cobblestone
fill 417 239 213 417 240 213 minecraft:mossy_cobblestone
fill 377 240 182 377 240 183 minecraft:mossy_cobblestone
setblock 377 240 184 minecraft:stone_bricks
fill 377 240 185 377 240 188 minecraft:mossy_cobblestone
setblock 377 240 189 minecraft:stone_bricks
fill 377 240 190 377 240 193 minecraft:mossy_cobblestone
setblock 377 240 194 minecraft:stone_bricks
fill 377 240 195 377 242 196 minecraft:mossy_cobblestone
setblock 377 240 204 minecraft:stone_bricks
fill 377 240 205 377 241 205 minecraft:mossy_cobblestone
setblock 377 240 209 minecraft:stone_bricks
fill 377 240 210 377 242 211 minecraft:mossy_cobblestone
setblock 378 240 182 minecraft:mossy_cobblestone
setblock 378 240 183 minecraft:stone_bricks
fill 378 240 184 378 243 184 minecraft:mossy_cobblestone
setblock 378 240 188 minecraft:stone_bricks
fill 378 240 189 378 243 189 minecraft:mossy_cobblestone
setblock 378 240 192 minecraft:mossy_cobblestone
setblock 379 240 182 minecraft:stone_bricks
fill 379 240 183 382 240 183 minecraft:mossy_cobblestone
setblock 379 240 186 minecraft:mossy_cobblestone
setblock 379 240 187 minecraft:stone_bricks
fill 380 240 182 383 240 182 minecraft:mossy_cobblestone
setblock 383 240 183 minecraft:stone_bricks
setblock 384 240 182 minecraft:stone_bricks
fill 384 240 183 384 242 184 minecraft:mossy_cobblestone
setblock 384 240 222 minecraft:stone_bricks
fill 385 240 182 388 240 182 minecraft:mossy_cobblestone
fill 385 240 222 388 240 222 minecraft:mossy_cobblestone
setblock 387 240 183 minecraft:mossy_cobblestone
setblock 387 240 184 minecraft:stone_bricks
fill 387 240 221 389 240 221 minecraft:mossy_cobblestone
setblock 388 240 183 minecraft:stone_bricks
fill 388 240 184 388 242 185 minecraft:mossy_cobblestone
setblock 389 240 182 minecraft:stone_bricks
fill 389 240 183 389 243 183 minecraft:mossy_cobblestone
setblock 389 240 222 minecraft:stone_bricks
fill 390 240 182 390 243 182 minecraft:mossy_cobblestone
setblock 390 240 185 minecraft:mossy_cobblestone
setblock 390 240 221 minecraft:stone_bricks
fill 390 240 222 393 240 222 minecraft:mossy_cobblestone
setblock 391 240 185 minecraft:stone_bricks
fill 391 240 221 391 243 221 minecraft:mossy_cobblestone
setblock 392 240 184 minecraft:stone_bricks
setblock 393 240 183 minecraft:stone_bricks
fill 393 240 184 393 241 184 minecraft:mossy_cobblestone
setblock 394 240 182 minecraft:stone_bricks
fill 394 240 183 394 242 183 minecraft:mossy_cobblestone
setblock 394 240 221 minecraft:mossy_cobblestone
setblock 394 240 222 minecraft:stone_bricks
fill 395 240 182 395 243 182 minecraft:mossy_cobblestone
setblock 395 240 221 minecraft:stone_bricks
fill 395 240 222 395 243 222 minecraft:mossy_cobblestone
setblock 409 240 182 minecraft:stone_bricks
fill 409 240 183 409 243 183 minecraft:mossy_cobblestone
setblock 409 240 222 minecraft:stone_bricks
fill 410 240 182 410 243 182 minecraft:mossy_cobblestone
fill 410 240 222 410 243 222 minecraft:mossy_cobblestone
setblock 413 240 183 minecraft:stone_bricks
setblock 414 240 182 minecraft:stone_bricks
fill 414 240 183 414 242 183 minecraft:mossy_cobblestone
setblock 414 240 207 minecraft:stone_bricks
fill 414 240 208 414 240 209 minecraft:mossy_cobblestone
fill 415 240 182 415 243 182 minecraft:mossy_cobblestone
setblock 415 240 186 minecraft:stone_bricks
fill 415 240 187 415 243 187 minecraft:mossy_cobblestone
setblock 415 240 190 minecraft:mossy_cobblestone
setblock 415 240 191 minecraft:stone_bricks
setblock 415 240 206 minecraft:stone_bricks
fill 415 240 207 415 242 207 minecraft:mossy_cobblestone
setblock 415 240 211 minecraft:stone_bricks
setblock 416 240 185 minecraft:stone_bricks
fill 416 240 186 416 243 186 minecraft:mossy_cobblestone
setblock 416 240 189 minecraft:mossy_cobblestone
setblock 416 240 190 minecraft:stone_bricks
fill 416 240 191 416 243 191 minecraft:mossy_cobblestone
setblock 416 240 194 minecraft:mossy_cobblestone
setblock 416 240 195 minecraft:stone_bricks
setblock 416 240 200 minecraft:stone_bricks
fill 416 240 201 416 241 201 minecraft:mossy_cobblestone
setblock 416 240 205 minecraft:stone_bricks
fill 416 240 206 416 243 206 minecraft:mossy_cobblestone
setblock 416 240 210 minecraft:stone_bricks
fill 416 240 211 416 243 211 minecraft:mossy_cobblestone
setblock 417 240 184 minecraft:stone_bricks
fill 417 240 185 417 243 185 minecraft:mossy_cobblestone
setblock 417 240 189 minecraft:stone_bricks
fill 417 240 190 417 243 190 minecraft:mossy_cobblestone
setblock 417 240 194 minecraft:stone_bricks
fill 417 240 195 417 243 195 minecraft:mossy_cobblestone
setblock 417 240 199 minecraft:stone_bricks
fill 417 240 200 417 243 200 minecraft:mossy_cobblestone
setblock 417 240 204 minecraft:stone_bricks
fill 417 240 205 417 243 205 minecraft:mossy_cobblestone
setblock 417 240 209 minecraft:stone_bricks
fill 417 240 210 417 243 210 minecraft:mossy_cobblestone
setblock 377 241 182 minecraft:mossy_cobblestone
setblock 377 241 183 minecraft:stone_bricks
fill 377 241 184 377 241 187 minecraft:mossy_cobblestone
setblock 377 241 188 minecraft:stone_bricks
fill 377 241 189 377 241 192 minecraft:mossy_cobblestone
setblock 377 241 193 minecraft:stone_bricks
fill 377 241 194 377 244 194 minecraft:mossy_cobblestone
setblock 377 241 208 minecraft:stone_bricks
fill 377 241 209 377 243 209 minecraft:mossy_cobblestone
setblock 377 241 212 minecraft:mossy_cobblestone
setblock 378 241 182 minecraft:stone_bricks
fill 378 241 183 381 241 183 minecraft:mossy_cobblestone
setblock 378 241 187 minecraft:stone_bricks
fill 378 241 188 379 243 188 minecraft:mossy_cobblestone
setblock 378 241 192 minecraft:stone_bricks
fill 379 241 182 382 241 182 minecraft:mossy_cobblestone
setblock 379 241 184 minecraft:light[level=12]
setblock 379 241 186 minecraft:stone_bricks
fill 379 241 187 379 243 187 minecraft:mossy_cobblestone
setblock 379 241 192 minecraft:light[level=12]
setblock 379 241 200 minecraft:light[level=12]
setblock 379 241 208 minecraft:light[level=12]
setblock 379 241 216 minecraft:light[level=12]
setblock 382 241 183 minecraft:stone_bricks
setblock 383 241 182 minecraft:stone_bricks
fill 383 241 183 383 244 183 minecraft:mossy_cobblestone
fill 384 241 182 387 241 182 minecraft:mossy_cobblestone
fill 384 241 222 387 241 222 minecraft:mossy_cobblestone
setblock 386 241 183 minecraft:mossy_cobblestone
setblock 386 241 184 minecraft:stone_bricks
setblock 387 241 183 minecraft:stone_bricks
fill 387 241 184 387 242 185 minecraft:mossy_cobblestone
setblock 387 241 192 minecraft:light[level=12]
setblock 387 241 200 minecraft:light[level=12]
setblock 387 241 208 minecraft:light[level=12]
setblock 387 241 216 minecraft:light[level=12]
fill 387 241 221 388 241 221 minecraft:mossy_cobblestone
setblock 388 241 182 minecraft:stone_bricks
fill 388 241 183 388 244 183 minecraft:mossy_cobblestone
setblock 388 241 222 minecraft:stone_bricks
fill 389 241 182 389 244 182 minecraft:mossy_cobblestone
setblock 389 241 221 minecraft:stone_bricks
fill 389 241 222 392 241 222 minecraft:mossy_cobblestone
setblock 390 241 185 minecraft:stone_bricks
setblock 390 241 220 minecraft:stone_bricks
fill 390 241 221 390 244 221 minecraft:mossy_cobblestone
setblock 391 241 184 minecraft:stone_bricks
setblock 391 241 185 minecraft:mossy_cobblestone
fill 391 241 220 391 244 220 minecraft:mossy_cobblestone
setblock 392 241 183 minecraft:stone_bricks
fill 392 241 184 392 242 184 minecraft:mossy_cobblestone
setblock 393 241 182 minecraft:stone_bricks
fill 393 241 183 393 243 183 minecraft:mossy_cobblestone
setblock 393 241 222 minecraft:stone_bricks
fill 394 241 182 394 244 182 minecraft:mossy_cobblestone
setblock 394 241 221 minecraft:stone_bricks
fill 394 241 222 394 244 222 minecraft:mossy_cobblestone
setblock 395 241 184 minecraft:light[level=12]
setblock 395 241 192 minecraft:light[level=12]
setblock 395 241 200 minecraft:light[level=12]
setblock 395 241 208 minecraft:light[level=12]
setblock 395 241 216 minecraft:light[level=12]
setblock 395 241 221 minecraft:mossy_cobblestone
fill 396 241 222 397 241 222 minecraft:mossy_cobblestone
setblock 403 241 184 minecraft:light[level=12]
setblock 403 241 192 minecraft:light[level=12]
setblock 403 241 200 minecraft:light[level=12]
setblock 403 241 208 minecraft:light[level=12]
setblock 403 241 216 minecraft:light[level=12]
fill 406 241 182 406 242 182 minecraft:mossy_cobblestone
setblock 407 241 222 minecraft:mossy_cobblestone
setblock 408 241 182 minecraft:stone_bricks
fill 408 241 183 408 242 183 minecraft:mossy_cobblestone
setblock 408 241 222 minecraft:stone_bricks
fill 409 241 182 409 244 182 minecraft:mossy_cobblestone
fill 409 241 222 409 244 222 minecraft:mossy_cobblestone
setblock 411 241 184 minecraft:light[level=12]
setblock 411 241 192 minecraft:light[level=12]
setblock 411 241 200 minecraft:light[level=12]
setblock 411 241 208 minecraft:light[level=12]
setblock 411 241 216 minecraft:light[level=12]
setblock 412 241 183 minecraft:stone_bricks
setblock 413 241 182 minecraft:stone_bricks
fill 413 241 183 413 242 183 minecraft:mossy_cobblestone
fill 414 241 182 414 243 182 minecraft:mossy_cobblestone
fill 414 241 207 414 241 208 minecraft:mossy_cobblestone
fill 415 241 186 415 242 186 minecraft:mossy_cobblestone
setblock 415 241 190 minecraft:stone_bricks
fill 415 241 191 415 242 193 minecraft:mossy_cobblestone
setblock 415 241 205 minecraft:stone_bricks
fill 415 241 206 415 242 206 minecraft:mossy_cobblestone
setblock 415 241 209 minecraft:mossy_cobblestone
setblock 415 241 210 minecraft:stone_bricks
fill 415 241 211 415 242 211 minecraft:mossy_cobblestone
setblock 416 241 184 minecraft:stone_bricks
fill 416 241 185 416 243 185 minecraft:mossy_cobblestone
setblock 416 241 189 minecraft:stone_bricks
fill 416 241 190 416 244 190 minecraft:mossy_cobblestone
setblock 416 241 194 minecraft:stone_bricks
fill 416 241 195 416 243 196 minecraft:mossy_cobblestone
setblock 416 241 204 minecraft:stone_bricks
fill 416 241 205 416 242 205 minecraft:mossy_cobblestone
setblock 416 241 209 minecraft:stone_bricks
fill 416 241 210 416 244 210 minecraft:mossy_cobblestone
setblock 417 241 183 minecraft:stone_bricks
fill 417 241 184 417 244 184 minecraft:mossy_cobblestone
setblock 417 241 188 minecraft:stone_bricks
fill 417 241 189 417 244 189 minecraft:mossy_cobblestone
setblock 417 241 193 minecraft:stone_bricks
fill 417 241 194 417 244 194 minecraft:mossy_cobblestone
setblock 417 241 198 minecraft:stone_bricks
fill 417 241 199 417 244 199 minecraft:mossy_cobblestone
setblock 417 241 203 minecraft:stone_bricks
fill 417 241 204 417 243 204 minecraft:mossy_cobblestone
setblock 417 241 208 minecraft:stone_bricks
fill 417 241 209 417 244 209 minecraft:mossy_cobblestone
setblock 417 241 213 minecraft:stone_bricks
fill 417 241 214 417 244 214 minecraft:mossy_cobblestone
setblock 377 242 182 minecraft:stone_bricks
fill 377 242 183 377 242 186 minecraft:mossy_cobblestone
setblock 377 242 187 minecraft:stone_bricks
fill 377 242 188 377 242 191 minecraft:mossy_cobblestone
setblock 377 242 192 minecraft:stone_bricks
fill 377 242 193 378 244 193 minecraft:mossy_cobblestone
setblock 377 242 207 minecraft:stone_bricks
fill 377 242 208 377 243 208 minecraft:mossy_cobblestone
setblock 377 242 212 minecraft:stone_bricks
fill 378 242 182 380 242 183 minecraft:mossy_cobblestone
setblock 378 242 186 minecraft:stone_bricks
fill 378 242 187 378 245 187 minecraft:mossy_cobblestone
setblock 378 242 190 minecraft:mossy_cobblestone
setblock 378 242 191 minecraft:stone_bricks
fill 378 242 192 378 245 192 minecraft:mossy_cobblestone
setblock 379 242 186 minecraft:mossy_cobblestone
setblock 379 242 189 minecraft:mossy_cobblestone
setblock 381 242 182 minecraft:mossy_cobblestone
setblock 381 242 183 minecraft:stone_bricks
setblock 382 242 182 minecraft:stone_bricks
fill 382 242 183 382 244 183 minecraft:mossy_cobblestone
fill 383 242 182 386 242 182 minecraft:mossy_cobblestone
fill 383 242 222 386 242 222 minecraft:mossy_cobblestone
setblock 385 242 183 minecraft:mossy_cobblestone
setblock 385 242 184 minecraft:stone_bricks
setblock 386 242 183 minecraft:stone_bricks
fill 386 242 184 386 245 184 minecraft:mossy_cobblestone
fill 386 242 221 387 242 221 minecraft:mossy_cobblestone
setblock 387 242 182 minecraft:stone_bricks
fill 387 242 183 387 245 183 minecraft:mossy_cobblestone
setblock 387 242 222 minecraft:stone_bricks
fill 388 242 182 388 245 182 minecraft:mossy_cobblestone
setblock 388 242 221 minecraft:stone_bricks
fill 388 242 222 391 242 222 minecraft:mossy_cobblestone
setblock 389 242 184 minecraft:mossy_cobblestone
setblock 389 242 185 minecraft:stone_bricks
setblock 389 242 220 minecraft:stone_bricks
fill 389 242 221 389 245 221 minecraft:mossy_cobblestone
setblock 390 242 184 minecraft:stone_bricks
setblock 390 242 185 minecraft:mossy_cobblestone
fill 390 242 220 390 245 220 minecraft:mossy_cobblestone
setblock 391 242 183 minecraft:stone_bricks
fill 391 242 184 391 243 184 minecraft:mossy_cobblestone
setblock 392 242 182 minecraft:stone_bricks
fill 392 242 183 392 244 183 minecraft:mossy_cobblestone
setblock 392 242 222 minecraft:stone_bricks
fill 393 242 182 393 244 182 minecraft:mossy_cobblestone
setblock 393 242 221 minecraft:stone_bricks
fill 393 242 222 393 245 222 minecraft:mossy_cobblestone
fill 394 242 221 394 243 221 minecraft:mossy_cobblestone
setblock 396 242 222 minecraft:mossy_cobblestone
setblock 397 242 222 minecraft:stone_bricks
setblock 406 242 222 minecraft:mossy_cobblestone
setblock 407 242 182 minecraft:stone_bricks
setblock 407 242 222 minecraft:stone_bricks
fill 408 242 182 408 245 182 minecraft:mossy_cobblestone
fill 408 242 222 408 245 222 minecraft:mossy_cobblestone
setblock 411 242 183 minecraft:stone_bricks
setblock 412 242 182 minecraft:stone_bricks
fill 412 242 183 412 243 183 minecraft:mossy_cobblestone
fill 413 242 182 413 244 182 minecraft:mossy_cobblestone
setblock 415 242 188 minecraft:mossy_cobblestone
setblock 415 242 189 minecraft:stone_bricks
fill 415 242 190 415 245 190 minecraft:mossy_cobblestone
setblock 415 242 194 minecraft:stone_bricks
setblock 415 242 209 minecraft:stone_bricks
setblock 415 242 210 minecraft:mossy_cobblestone
setblock 416 242 184 minecraft:mossy_cobblestone
setblock 416 242 188 minecraft:stone_bricks
fill 416 242 189 416 245 189 minecraft:mossy_cobblestone
setblock 416 242 192 minecraft:mossy_cobblestone
setblock 416 242 193 minecraft:stone_bricks
fill 416 242 194 416 245 194 minecraft:mossy_cobblestone
setblock 416 242 203 minecraft:stone_bricks
setblock 416 242 204 minecraft:mossy_cobblestone
setblock 416 242 208 minecraft:stone_bricks
fill 416 242 209 416 244 209 minecraft:mossy_cobblestone
fill 417 242 183 417 243 183 minecraft:mossy_cobblestone
setblock 417 242 187 minecraft:stone_bricks
fill 417 242 188 417 245 188 minecraft:mossy_cobblestone
setblock 417 242 192 minecraft:stone_bricks
fill 417 242 193 417 245 193 minecraft:mossy_cobblestone
setblock 417 242 197 minecraft:stone_bricks
fill 417 242 198 417 245 198 minecraft:mossy_cobblestone
setblock 417 242 202 minecraft:stone_bricks
fill 417 242 203 417 243 203 minecraft:mossy_cobblestone
setblock 417 242 207 minecraft:stone_bricks
fill 417 242 208 417 244 208 minecraft:mossy_cobblestone
setblock 417 242 212 minecraft:stone_bricks
fill 417 242 213 417 245 213 minecraft:mossy_cobblestone
fill 377 243 182 377 243 185 minecraft:mossy_cobblestone
setblock 377 243 186 minecraft:stone_bricks
fill 377 243 187 377 243 190 minecraft:mossy_cobblestone
setblock 377 243 191 minecraft:stone_bricks
fill 377 243 192 377 246 192 minecraft:mossy_cobblestone
setblock 377 243 195 minecraft:mossy_cobblestone
setblock 377 243 196 minecraft:stone_bricks
setblock 377 243 210 minecraft:mossy_cobblestone
setblock 377 243 211 minecraft:stone_bricks
fill 377 243 212 377 244 213 minecraft:mossy_cobblestone
fill 378 243 182 380 243 182 minecraft:mossy_cobblestone
setblock 378 243 185 minecraft:stone_bricks
fill 378 243 186 378 245 186 minecraft:mossy_cobblestone
setblock 378 243 190 minecraft:stone_bricks
fill 378 243 191 378 246 191 minecraft:mossy_cobblestone
setblock 379 243 189 minecraft:stone_bricks
setblock 380 243 183 minecraft:stone_bricks
setblock 381 243 182 minecraft:stone_bricks
setblock 381 243 183 minecraft:mossy_cobblestone
fill 382 243 182 385 243 182 minecraft:mossy_cobblestone
fill 383 243 222 385 243 222 minecraft:mossy_cobblestone
setblock 384 243 183 minecraft:mossy_cobblestone
setblock 384 243 184 minecraft:stone_bricks
setblock 385 243 183 minecraft:stone_bricks
fill 385 243 184 385 244 184 minecraft:mossy_cobblestone
fill 385 243 221 386 243 221 minecraft:mossy_cobblestone
setblock 386 243 182 minecraft:stone_bricks
fill 386 243 183 386 246 183 minecraft:mossy_cobblestone
setblock 386 243 222 minecraft:stone_bricks
fill 387 243 182 387 246 182 minecraft:mossy_cobblestone
fill 387 243 184 388 243 184 minecraft:mossy_cobblestone
setblock 387 243 221 minecraft:stone_bricks
fill 387 243 222 390 243 222 minecraft:mossy_cobblestone
setblock 388 243 185 minecraft:stone_bricks
setblock 388 243 220 minecraft:stone_bricks
fill 388 243 221 388 246 221 minecraft:mossy_cobblestone
setblock 389 243 184 minecraft:stone_bricks
fill 389 243 220 389 246 220 minecraft:mossy_cobblestone
setblock 390 243 183 minecraft:stone_bricks
fill 390 243 184 390 244 184 minecraft:mossy_cobblestone
setblock 391 243 182 minecraft:stone_bricks
fill 391 243 183 391 245 183 minecraft:mossy_cobblestone
setblock 391 243 222 minecraft:stone_bricks
fill 392 243 182 392 245 182 minecraft:mossy_cobblestone
setblock 392 243 221 minecraft:stone_bricks
fill 392 243 222 392 246 222 minecraft:mossy_cobblestone
fill 393 243 221 393 244 221 minecraft:mossy_cobblestone
setblock 396 243 222 minecraft:stone_bricks
setblock 406 243 182 minecraft:stone_bricks
setblock 406 243 222 minecraft:stone_bricks
fill 407 243 182 407 245 182 minecraft:mossy_cobblestone
fill 407 243 222 407 245 222 minecraft:mossy_cobblestone
setblock 410 243 183 minecraft:stone_bricks
setblock 411 243 182 minecraft:stone_bricks
setblock 411 243 183 minecraft:mossy_cobblestone
setblock 411 243 222 minecraft:stone_bricks
fill 412 243 182 412 244 182 minecraft:mossy_cobblestone
setblock 415 243 188 minecraft:stone_bricks
fill 415 243 189 415 245 189 minecraft:mossy_cobblestone
fill 415 243 191 415 243 192 minecraft:mossy_cobblestone
setblock 415 243 193 minecraft:stone_bricks
fill 415 243 194 415 245 194 minecraft:mossy_cobblestone
setblock 416 243 187 minecraft:stone_bricks
fill 416 243 188 416 246 188 minecraft:mossy_cobblestone
setblock 416 243 192 minecraft:stone_bricks
fill 416 243 193 416 246 193 minecraft:mossy_cobblestone
setblock 416 243 207 minecraft:stone_bricks
setblock 416 243 208 minecraft:mossy_cobblestone
setblock 416 243 212 minecraft:stone_bricks
setblock 417 243 186 minecraft:stone_bricks
fill 417 243 187 417 246 187 minecraft:mossy_cobblestone
setblock 417 243 191 minecraft:stone_bricks
fill 417 243 192 417 246 192 minecraft:mossy_cobblestone
setblock 417 243 196 minecraft:stone_bricks
fill 417 243 197 417 246 197 minecraft:mossy_cobblestone
setblock 417 243 201 minecraft:stone_bricks
setblock 417 243 202 minecraft:mossy_cobblestone
setblock 417 243 206 minecraft:stone_bricks
fill 417 243 207 417 244 207 minecraft:mossy_cobblestone
setblock 417 243 211 minecraft:stone_bricks
fill 417 243 212 417 245 212 minecraft:mossy_cobblestone
fill 377 244 182 377 244 184 minecraft:mossy_cobblestone
setblock 377 244 185 minecraft:stone_bricks
fill 377 244 186 377 244 189 minecraft:mossy_cobblestone
setblock 377 244 190 minecraft:stone_bricks
fill 377 244 191 377 247 191 minecraft:mossy_cobblestone
setblock 377 244 195 minecraft:stone_bricks
setblock 377 244 196 minecraft:mossy_cobblestone
setblock 377 244 211 minecraft:mossy_cobblestone
fill 378 244 182 379 244 182 minecraft:mossy_cobblestone
setblock 378 244 185 minecraft:mossy_cobblestone
setblock 378 244 188 minecraft:mossy_cobblestone
setblock 378 244 189 minecraft:stone_bricks
fill 378 244 190 378 247 190 minecraft:mossy_cobblestone
setblock 380 244 182 minecraft:stone_bricks
fill 381 244 182 384 244 182 minecraft:mossy_cobblestone
fill 382 244 222 384 244 222 minecraft:mossy_cobblestone
setblock 384 244 183 minecraft:stone_bricks
setblock 384 244 184 minecraft:mossy_cobblestone
setblock 385 244 182 minecraft:stone_bricks
fill 385 244 183 385 247 183 minecraft:mossy_cobblestone
setblock 385 244 221 minecraft:mossy_cobblestone
setblock 385 244 222 minecraft:stone_bricks
fill 386 244 182 386 247 182 minecraft:mossy_cobblestone
setblock 386 244 221 minecraft:stone_bricks
fill 386 244 222 389 244 222 minecraft:mossy_cobblestone
setblock 387 244 184 minecraft:mossy_cobblestone
setblock 387 244 220 minecraft:stone_bricks
fill 387 244 221 387 247 221 minecraft:mossy_cobblestone
setblock 388 244 184 minecraft:stone_bricks
fill 388 244 220 388 247 220 minecraft:mossy_cobblestone
setblock 389 244 183 minecraft:stone_bricks
setblock 389 244 184 minecraft:mossy_cobblestone
setblock 390 244 182 minecraft:stone_bricks
fill 390 244 183 390 245 183 minecraft:mossy_cobblestone
setblock 390 244 222 minecraft:stone_bricks
fill 391 244 182 391 246 182 minecraft:mossy_cobblestone
setblock 391 244 221 minecraft:stone_bricks
fill 391 244 222 391 247 222 minecraft:mossy_cobblestone
fill 392 244 221 392 246 221 minecraft:mossy_cobblestone
setblock 395 244 222 minecraft:stone_bricks
setblock 406 244 222 minecraft:mossy_cobblestone
setblock 410 244 182 minecraft:stone_bricks
setblock 410 244 222 minecraft:stone_bricks
fill 411 244 182 411 245 182 minecraft:mossy_cobblestone
setblock 415 244 188 minecraft:mossy_cobblestone
setblock 415 244 191 minecraft:mossy_cobblestone
setblock 415 244 192 minecraft:stone_bricks
fill 415 244 193 415 246 193 minecraft:mossy_cobblestone
setblock 416 244 186 minecraft:stone_bricks
fill 416 244 187 416 245 187 minecraft:mossy_cobblestone
setblock 416 244 191 minecraft:stone_bricks
fill 416 244 192 416 247 192 minecraft:mossy_cobblestone
setblock 416 244 195 minecraft:mossy_cobblestone
setblock 416 244 196 minecraft:stone_bricks
setblock 417 244 185 minecraft:stone_bricks
fill 417 244 186 417 246 186 minecraft:mossy_cobblestone
setblock 417 244 190 minecraft:stone_bricks
fill 417 244 191 417 247 191 minecraft:mossy_cobblestone
setblock 417 244 195 minecraft:stone_bricks
fill 417 244 196 417 247 196 minecraft:mossy_cobblestone
setblock 417 244 205 minecraft:stone_bricks
setblock 417 244 206 minecraft:mossy_cobblestone
setblock 417 244 210 minecraft:stone_bricks
fill 417 244 211 417 245 211 minecraft:mossy_cobblestone
setblock 377 245 183 minecraft:mossy_cobblestone
setblock 377 245 184 minecraft:stone_bricks
fill 377 245 185 377 245 188 minecraft:mossy_cobblestone
setblock 377 245 189 minecraft:stone_bricks
fill 377 245 190 377 248 190 minecraft:mossy_cobblestone
setblock 377 245 193 minecraft:mossy_cobblestone
setblock 377 245 194 minecraft:stone_bricks
fill 377 245 195 377 248 195 minecraft:mossy_cobblestone
setblock 378 245 182 minecraft:mossy_cobblestone
setblock 378 245 188 minecraft:stone_bricks
fill 378 245 189 378 246 189 minecraft:mossy_cobblestone
setblock 378 245 193 minecraft:stone_bricks
setblock 379 245 182 minecraft:stone_bricks
fill 380 245 182 383 245 182 minecraft:mossy_cobblestone
fill 382 245 222 383 245 222 minecraft:mossy_cobblestone
setblock 383 245 183 minecraft:stone_bricks
setblock 384 245 182 minecraft:stone_bricks
fill 384 245 183 384 246 183 minecraft:mossy_cobblestone
setblock 384 245 221 minecraft:mossy_cobblestone
setblock 384 245 222 minecraft:stone_bricks
fill 385 245 182 385 248 182 minecraft:mossy_cobblestone
setblock 385 245 221 minecraft:stone_bricks
fill 385 245 222 388 245 222 minecraft:mossy_cobblestone
fill 386 245 221 386 248 221 minecraft:mossy_cobblestone
setblock 387 245 184 minecraft:stone_bricks
fill 387 245 220 387 248 220 minecraft:mossy_cobblestone
setblock 388 245 183 minecraft:stone_bricks
setblock 388 245 184 minecraft:mossy_cobblestone
setblock 389 245 182 minecraft:stone_bricks
fill 389 245 183 389 246 183 minecraft:mossy_cobblestone
setblock 389 245 222 minecraft:stone_bricks
fill 390 245 182 390 247 182 minecraft:mossy_cobblestone
setblock 390 245 221 minecraft:stone_bricks
fill 390 245 222 390 248 222 minecraft:mossy_cobblestone
fill 391 245 221 391 247 221 minecraft:mossy_cobblestone
setblock 394 245 222 minecraft:stone_bricks
setblock 409 245 182 minecraft:stone_bricks
setblock 410 245 182 minecraft:mossy_cobblestone
setblock 415 245 191 minecraft:stone_bricks
fill 415 245 192 415 246 192 minecraft:mossy_cobblestone
setblock 416 245 190 minecraft:stone_bricks
fill 416 245 191 416 248 191 minecraft:mossy_cobblestone
setblock 416 245 195 minecraft:stone_bricks
fill 416 245 196 416 246 196 minecraft:mossy_cobblestone
setblock 417 245 185 minecraft:mossy_cobblestone
setblock 417 245 189 minecraft:stone_bricks
fill 417 245 190 417 248 190 minecraft:mossy_cobblestone
setblock 417 245 194 minecraft:stone_bricks
fill 417 245 195 417 248 195 minecraft:mossy_cobblestone
setblock 417 245 209 minecraft:stone_bricks
setblock 417 245 210 minecraft:mossy_cobblestone
fill 377 246 184 377 246 187 minecraft:mossy_cobblestone
setblock 377 246 188 minecraft:stone_bricks
fill 377 246 189 377 249 189 minecraft:mossy_cobblestone
setblock 377 246 193 minecraft:stone_bricks
fill 377 246 194 377 249 194 minecraft:mossy_cobblestone
setblock 378 246 188 minecraft:mossy_cobblestone
setblock 378 246 192 minecraft:stone_bricks
fill 380 246 182 382 246 182 minecraft:mossy_cobblestone
setblock 382 246 222 minecraft:mossy_cobblestone
setblock 383 246 182 minecraft:stone_bricks
setblock 383 246 183 minecraft:mossy_cobblestone
setblock 383 246 222 minecraft:stone_bricks
fill 384 246 182 384 249 182 minecraft:mossy_cobblestone
setblock 384 246 221 minecraft:stone_bricks
fill 384 246 222 387 246 222 minecraft:mossy_cobblestone
fill 385 246 221 385 249 221 minecraft:mossy_cobblestone
fill 386 246 220 386 249 220 minecraft:mossy_cobblestone
setblock 387 246 183 minecraft:stone_bricks
setblock 388 246 182 minecraft:stone_bricks
setblock 388 246 183 minecraft:mossy_cobblestone
setblock 388 246 222 minecraft:stone_bricks
fill 389 246 182 389 248 182 minecraft:mossy_cobblestone
setblock 389 246 221 minecraft:stone_bricks
fill 389 246 222 389 249 222 minecraft:mossy_cobblestone
setblock 390 246 220 minecraft:stone_bricks
fill 390 246 221 390 249 221 minecraft:mossy_cobblestone
setblock 393 246 222 minecraft:stone_bricks
setblock 415 246 191 minecraft:mossy_cobblestone
setblock 416 246 189 minecraft:stone_bricks
fill 416 246 190 416 248 190 minecraft:mossy_cobblestone
setblock 416 246 194 minecraft:stone_bricks
fill 416 246 195 416 248 195 minecraft:mossy_cobblestone
setblock 417 246 188 minecraft:stone_bricks
fill 417 246 189 417 249 189 minecraft:mossy_cobblestone
setblock 417 246 193 minecraft:stone_bricks
fill 417 246 194 417 249 194 minecraft:mossy_cobblestone
setblock 417 246 198 minecraft:stone_bricks
setblock 377 247 186 minecraft:mossy_cobblestone
setblock 377 247 187 minecraft:stone_bricks
fill 377 247 188 377 248 188 minecraft:mossy_cobblestone
setblock 377 247 192 minecraft:stone_bricks
fill 377 247 193 377 250 193 minecraft:mossy_cobblestone
setblock 378 247 191 minecraft:stone_bricks
setblock 381 247 182 minecraft:mossy_cobblestone
setblock 381 247 222 minecraft:mossy_cobblestone
setblock 382 247 182 minecraft:stone_bricks
setblock 382 247 222 minecraft:stone_bricks
fill 383 247 182 383 250 182 minecraft:mossy_cobblestone
setblock 383 247 221 minecraft:stone_bricks
fill 383 247 222 386 247 222 minecraft:mossy_cobblestone
fill 384 247 221 384 250 221 minecraft:mossy_cobblestone
setblock 386 247 183 minecraft:stone_bricks
setblock 387 247 182 minecraft:stone_bricks
setblock 387 247 183 minecraft:mossy_cobblestone
setblock 387 247 222 minecraft:stone_bricks
fill 388 247 182 388 249 182 minecraft:mossy_cobblestone
setblock 388 247 221 minecraft:stone_bricks
fill 388 247 222 388 250 222 minecraft:mossy_cobblestone
setblock 389 247 220 minecraft:stone_bricks
fill 389 247 221 389 250 221 minecraft:mossy_cobblestone
setblock 392 247 222 minecraft:stone_bricks
setblock 393 247 222 minecraft:mossy_cobblestone
setblock 416 247 189 minecraft:mossy_cobblestone
setblock 416 247 193 minecraft:stone_bricks
fill 416 247 194 416 250 194 minecraft:mossy_cobblestone
setblock 417 247 187 minecraft:stone_bricks
fill 417 247 188 417 249 188 minecraft:mossy_cobblestone
setblock 417 247 192 minecraft:stone_bricks
fill 417 247 193 417 250 193 minecraft:mossy_cobblestone
setblock 417 247 197 minecraft:stone_bricks
setblock 377 248 187 minecraft:mossy_cobblestone
setblock 377 248 191 minecraft:stone_bricks
fill 377 248 192 377 251 192 minecraft:mossy_cobblestone
setblock 381 248 182 minecraft:stone_bricks
setblock 381 248 222 minecraft:stone_bricks
fill 382 248 182 382 251 182 minecraft:mossy_cobblestone
fill 382 248 222 385 248 222 minecraft:mossy_cobblestone
fill 383 248 221 383 251 221 minecraft:mossy_cobblestone
fill 385 248 220 385 250 220 minecraft:mossy_cobblestone
setblock 386 248 182 minecraft:stone_bricks
setblock 386 248 222 minecraft:stone_bricks
fill 387 248 182 387 251 182 minecraft:mossy_cobblestone
setblock 387 248 221 minecraft:stone_bricks
fill 387 248 222 387 251 222 minecraft:mossy_cobblestone
setblock 388 248 220 minecraft:stone_bricks
fill 388 248 221 388 251 221 minecraft:mossy_cobblestone
setblock 391 248 222 minecraft:stone_bricks
fill 392 248 222 392 249 222 minecraft:mossy_cobblestone
setblock 416 248 192 minecraft:stone_bricks
fill 416 248 193 416 251 193 minecraft:mossy_cobblestone
setblock 417 248 191 minecraft:stone_bricks
fill 417 248 192 417 251 192 minecraft:mossy_cobblestone
setblock 417 248 196 minecraft:stone_bricks
fill 417 248 197 417 251 197 minecraft:mossy_cobblestone
setblock 377 249 190 minecraft:stone_bricks
fill 377 249 191 377 252 191 minecraft:mossy_cobblestone
setblock 377 249 195 minecraft:stone_bricks
setblock 379 249 184 minecraft:light[level=12]
setblock 379 249 192 minecraft:light[level=12]
setblock 379 249 200 minecraft:light[level=12]
setblock 379 249 208 minecraft:light[level=12]
setblock 379 249 216 minecraft:light[level=12]
setblock 380 249 222 minecraft:stone_bricks
fill 381 249 182 381 252 182 minecraft:mossy_cobblestone
fill 381 249 222 384 249 222 minecraft:mossy_cobblestone
fill 382 249 221 382 252 221 minecraft:mossy_cobblestone
fill 384 249 220 384 251 220 minecraft:mossy_cobblestone
setblock 385 249 182 minecraft:stone_bricks
setblock 385 249 222 minecraft:stone_bricks
fill 386 249 182 386 252 182 minecraft:mossy_cobblestone
setblock 386 249 221 minecraft:stone_bricks
fill 386 249 222 386 252 222 minecraft:mossy_cobblestone
setblock 387 249 184 minecraft:light[level=12]
setblock 387 249 192 minecraft:light[level=12]
setblock 387 249 200 minecraft:light[level=12]
setblock 387 249 208 minecraft:light[level=12]
setblock 387 249 216 minecraft:light[level=12]
setblock 387 249 220 minecraft:stone_bricks
fill 387 249 221 387 252 221 minecraft:mossy_cobblestone
fill 388 249 220 388 252 220 minecraft:mossy_cobblestone
setblock 390 249 222 minecraft:stone_bricks
fill 391 249 222 391 252 222 minecraft:mossy_cobblestone
setblock 395 249 184 minecraft:light[level=12]
setblock 395 249 192 minecraft:light[level=12]
setblock 395 249 200 minecraft:light[level=12]
setblock 395 249 208 minecraft:light[level=12]
setblock 395 249 216 minecraft:light[level=12]
setblock 403 249 184 minecraft:light[level=12]
setblock 403 249 192 minecraft:light[level=12]
setblock 403 249 200 minecraft:light[level=12]
setblock 403 249 208 minecraft:light[level=12]
setblock 403 249 216 minecraft:light[level=12]
setblock 411 249 184 minecraft:light[level=12]
setblock 411 249 192 minecraft:light[level=12]
setblock 411 249 200 minecraft:light[level=12]
setblock 411 249 208 minecraft:light[level=12]
setblock 411 249 216 minecraft:light[level=12]
setblock 416 249 192 minecraft:mossy_cobblestone
setblock 417 249 190 minecraft:stone_bricks
fill 417 249 191 417 252 191 minecraft:mossy_cobblestone
setblock 417 249 195 minecraft:stone_bricks
fill 417 249 196 417 252 196 minecraft:mossy_cobblestone
setblock 377 250 190 minecraft:mossy_cobblestone
setblock 377 250 194 minecraft:stone_bricks
fill 377 250 195 377 253 195 minecraft:mossy_cobblestone
setblock 379 250 222 minecraft:stone_bricks
fill 380 250 222 383 250 222 minecraft:mossy_cobblestone
fill 381 250 221 381 253 221 minecraft:mossy_cobblestone
fill 383 250 220 383 252 220 minecraft:mossy_cobblestone
setblock 384 250 182 minecraft:stone_bricks
setblock 384 250 222 minecraft:stone_bricks
fill 385 250 182 385 253 182 minecraft:mossy_cobblestone
setblock 385 250 221 minecraft:stone_bricks
fill 385 250 222 385 253 222 minecraft:mossy_cobblestone
setblock 386 250 220 minecraft:stone_bricks
fill 386 250 221 386 253 221 minecraft:mossy_cobblestone
fill 387 250 220 387 253 220 minecraft:mossy_cobblestone
setblock 389 250 222 minecraft:stone_bricks
setblock 390 250 221 minecraft:stone_bricks
fill 390 250 222 390 253 222 minecraft:mossy_cobblestone
setblock 417 250 189 minecraft:stone_bricks
fill 417 250 190 417 253 190 minecraft:mossy_cobblestone
setblock 417 250 194 minecraft:stone_bricks
fill 417 250 195 417 253 195 minecraft:mossy_cobblestone
setblock 417 250 198 minecraft:mossy_cobblestone
setblock 377 251 193 minecraft:stone_bricks
fill 377 251 194 377 254 194 minecraft:mossy_cobblestone
fill 377 251 216 377 251 217 minecraft:mossy_cobblestone
setblock 377 251 218 minecraft:stone_bricks
fill 377 251 219 377 252 221 minecraft:mossy_cobblestone
setblock 378 251 222 minecraft:stone_bricks
fill 379 251 222 382 251 222 minecraft:mossy_cobblestone
fill 380 251 182 380 253 182 minecraft:mossy_cobblestone
fill 380 251 221 380 254 221 minecraft:mossy_cobblestone
fill 382 251 220 382 253 220 minecraft:mossy_cobblestone
setblock 383 251 182 minecraft:stone_bricks
setblock 383 251 222 minecraft:stone_bricks
fill 384 251 182 384 254 182 minecraft:mossy_cobblestone
setblock 384 251 221 minecraft:stone_bricks
fill 384 251 222 384 254 222 minecraft:mossy_cobblestone
setblock 385 251 219 minecraft:mossy_cobblestone
setblock 385 251 220 minecraft:stone_bricks
fill 385 251 221 385 254 221 minecraft:mossy_cobblestone
setblock 386 251 219 minecraft:stone_bricks
fill 386 251 220 386 254 220 minecraft:mossy_cobblestone
setblock 388 251 222 minecraft:stone_bricks
setblock 389 251 221 minecraft:stone_bricks
fill 389 251 222 389 254 222 minecraft:mossy_cobblestone
fill 390 251 221 390 254 221 minecraft:mossy_cobblestone
setblock 403 251 222 minecraft:stone_bricks
fill 404 251 222 406 252 222 minecraft:mossy_cobblestone
setblock 416 251 194 minecraft:stone_bricks
fill 416 251 195 416 254 195 minecraft:mossy_cobblestone
fill 417 251 189 417 254 189 minecraft:mossy_cobblestone
setblock 417 251 193 minecraft:stone_bricks
fill 417 251 194 417 254 194 minecraft:mossy_cobblestone
setblock 417 251 198 minecraft:stone_bricks
setblock 377 252 192 minecraft:stone_bricks
fill 377 252 193 377 255 193 minecraft:mossy_cobblestone
setblock 377 252 196 minecraft:mossy_cobblestone
fill 377 252 215 377 252 216 minecraft:mossy_cobblestone
setblock 377 252 217 minecraft:stone_bricks
fill 377 252 218 378 254 218 minecraft:mossy_cobblestone
setblock 377 252 222 minecraft:stone_bricks
fill 378 252 182 379 254 182 minecraft:mossy_cobblestone
fill 378 252 217 378 255 217 minecraft:mossy_cobblestone
fill 378 252 219 378 252 220 minecraft:mossy_cobblestone
setblock 378 252 221 minecraft:stone_bricks
fill 378 252 222 381 252 222 minecraft:mossy_cobblestone
fill 379 252 221 379 255 221 minecraft:mossy_cobblestone
fill 380 252 220 381 254 220 minecraft:mossy_cobblestone
setblock 382 252 182 minecraft:stone_bricks
setblock 382 252 222 minecraft:stone_bricks
fill 383 252 182 383 255 182 minecraft:mossy_cobblestone
fill 383 252 219 384 252 219 minecraft:mossy_cobblestone
setblock 383 252 221 minecraft:stone_bricks
fill 383 252 222 383 255 222 minecraft:mossy_cobblestone
setblock 384 252 220 minecraft:stone_bricks
fill 384 252 221 384 255 221 minecraft:mossy_cobblestone
setblock 385 252 219 minecraft:stone_bricks
fill 385 252 220 385 255 220 minecraft:mossy_cobblestone
fill 386 252 219 387 254 219 minecraft:mossy_cobblestone
setblock 387 252 182 minecraft:stone_bricks
setblock 387 252 222 minecraft:stone_bricks
setblock 388 252 221 minecraft:stone_bricks
fill 388 252 222 388 255 222 minecraft:mossy_cobblestone
setblock 389 252 220 minecraft:stone_bricks
fill 389 252 221 389 255 221 minecraft:mossy_cobblestone
setblock 392 252 222 minecraft:stone_bricks
fill 400 252 222 401 252 222 minecraft:mossy_cobblestone
setblock 402 252 222 minecraft:stone_bricks
fill 403 252 222 403 255 222 minecraft:mossy_cobblestone
setblock 407 252 222 minecraft:stone_bricks
setblock 416 252 193 minecraft:stone_bricks
fill 416 252 194 416 255 194 minecraft:mossy_cobblestone
fill 416 252 196 416 253 196 minecraft:mossy_cobblestone
setblock 417 252 192 minecraft:stone_bricks
fill 417 252 193 417 255 193 minecraft:mossy_cobblestone
setblock 417 252 197 minecraft:stone_bricks
fill 417 252 198 417 254 199 minecraft:mossy_cobblestone
fill 377 253 182 377 255 183 minecraft:mossy_cobblestone
setblock 377 253 191 minecraft:stone_bricks
fill 377 253 192 377 256 192 minecraft:mossy_cobblestone
setblock 377 253 196 minecraft:stone_bricks
fill 377 253 197 377 255 198 minecraft:mossy_cobblestone
fill 377 253 214 377 253 215 minecraft:mossy_cobblestone
setblock 377 253 216 minecraft:stone_bricks
fill 377 253 217 377 256 217 minecraft:mossy_cobblestone
fill 377 253 219 377 253 220 minecraft:mossy_cobblestone
setblock 377 253 221 minecraft:stone_bricks
fill 377 253 222 380 253 222 minecraft:mossy_cobblestone
fill 378 253 216 378 256 216 minecraft:mossy_cobblestone
setblock 378 253 219 minecraft:mossy_cobblestone
setblock 378 253 220 minecraft:stone_bricks
fill 378 253 221 378 256 221 minecraft:mossy_cobblestone
fill 379 253 217 379 253 218 minecraft:mossy_cobblestone
setblock 379 253 219 minecraft:stone_bricks
fill 379 253 220 379 256 220 minecraft:mossy_cobblestone
fill 380 253 189 380 272 189 minecraft:spruce_log
setblock 381 253 182 minecraft:stone_bricks
fill 381 253 183 383 254 183 minecraft:mossy_cobblestone
fill 381 253 219 383 253 219 minecraft:mossy_cobblestone
setblock 381 253 222 minecraft:stone_bricks
fill 382 253 182 382 256 182 minecraft:mossy_cobblestone
setblock 382 253 221 minecraft:stone_bricks
fill 382 253 222 382 256 222 minecraft:mossy_cobblestone
setblock 383 253 220 minecraft:stone_bricks
fill 383 253 221 383 256 221 minecraft:mossy_cobblestone
setblock 384 253 219 minecraft:stone_bricks
fill 384 253 220 384 256 220 minecraft:mossy_cobblestone
fill 385 253 219 385 256 219 minecraft:mossy_cobblestone
setblock 386 253 182 minecraft:stone_bricks
setblock 386 253 222 minecraft:stone_bricks
fill 387 253 182 387 256 182 minecraft:mossy_cobblestone
setblock 387 253 221 minecraft:stone_bricks
fill 387 253 222 387 256 222 minecraft:mossy_cobblestone
setblock 388 253 220 minecraft:stone_bricks
fill 388 253 221 388 256 221 minecraft:mossy_cobblestone
fill 389 253 220 389 256 220 minecraft:mossy_cobblestone
setblock 391 253 221 minecraft:mossy_cobblestone
setblock 391 253 222 minecraft:stone_bricks
fill 392 253 222 393 255 222 minecraft:mossy_cobblestone
fill 397 253 222 400 253 222 minecraft:mossy_cobblestone
setblock 401 253 221 minecraft:mossy_cobblestone
setblock 401 253 222 minecraft:stone_bricks
setblock 402 253 221 minecraft:stone_bricks
fill 402 253 222 402 256 222 minecraft:mossy_cobblestone
fill 403 253 221 405 254 221 minecraft:mossy_cobblestone
fill 404 253 182 405 253 182 minecraft:mossy_cobblestone
fill 404 253 222 405 253 222 minecraft:mossy_cobblestone
setblock 406 253 182 minecraft:stone_bricks
setblock 406 253 222 minecraft:stone_bricks
fill 407 253 222 408 255 222 minecraft:mossy_cobblestone
fill 416 253 193 416 256 193 minecraft:mossy_cobblestone
setblock 416 253 197 minecraft:stone_bricks
fill 417 253 188 417 255 188 minecraft:mossy_cobblestone
setblock 417 253 191 minecraft:stone_bricks
fill 417 253 192 417 256 192 minecraft:mossy_cobblestone
setblock 417 253 196 minecraft:stone_bricks
fill 417 253 197 417 256 197 minecraft:mossy_cobblestone
setblock 417 253 200 minecraft:mossy_cobblestone
fill 417 253 218 417 253 220 minecraft:mossy_cobblestone
setblock 417 253 221 minecraft:stone_bricks
setblock 377 254 184 minecraft:mossy_cobblestone
setblock 377 254 185 minecraft:stone_bricks
setblock 377 254 190 minecraft:stone_bricks
fill 377 254 191 377 257 191 minecraft:mossy_cobblestone
setblock 377 254 195 minecraft:stone_bricks
fill 377 254 196 377 257 196 minecraft:mossy_cobblestone
setblock 377 254 199 minecraft:mossy_cobblestone
setblock 377 254 200 minecraft:stone_bricks
setblock 377 254 214 minecraft:mossy_cobblestone
setblock 377 254 215 minecraft:stone_bricks
fill 377 254 216 377 257 216 minecraft:mossy_cobblestone
setblock 377 254 219 minecraft:mossy_cobblestone
setblock 377 254 220 minecraft:stone_bricks
fill 377 254 221 377 256 222 minecraft:mossy_cobblestone
fill 378 254 215 378 257 215 minecraft:mossy_cobblestone
setblock 378 254 219 minecraft:stone_bricks
fill 378 254 220 378 257 220 minecraft:mossy_cobblestone
fill 378 254 222 379 254 222 minecraft:mossy_cobblestone
setblock 379 254 183 minecraft:stone_bricks
fill 379 254 216 379 254 217 minecraft:mossy_cobblestone
setblock 379 254 218 minecraft:stone_bricks
fill 379 254 219 382 254 219 minecraft:mossy_cobblestone
setblock 380 254 182 minecraft:stone_bricks
fill 380 254 183 380 257 183 minecraft:mossy_cobblestone
fill 380 254 218 380 257 218 minecraft:mossy_cobblestone
setblock 380 254 222 minecraft:stone_bricks
fill 381 254 182 381 257 182 minecraft:mossy_cobblestone
setblock 381 254 221 minecraft:stone_bricks
fill 381 254 222 381 257 222 minecraft:mossy_cobblestone
setblock 382 254 220 minecraft:stone_bricks
fill 382 254 221 382 257 221 minecraft:mossy_cobblestone
setblock 383 254 219 minecraft:stone_bricks
fill 383 254 220 383 257 220 minecraft:mossy_cobblestone
setblock 384 254 183 minecraft:stone_bricks
fill 384 254 219 384 257 219 minecraft:mossy_cobblestone
setblock 385 254 182 minecraft:stone_bricks
setblock 385 254 222 minecraft:stone_bricks
fill 386 254 182 386 257 182 minecraft:mossy_cobblestone
setblock 386 254 221 minecraft:stone_bricks
fill 386 254 222 386 257 222 minecraft:mossy_cobblestone
setblock 387 254 220 minecraft:stone_bricks
fill 387 254 221 387 257 221 minecraft:mossy_cobblestone
fill 388 254 182 388 255 182 minecraft:mossy_cobblestone
fill 388 254 212 388 255 219 minecraft:stone_bricks
fill 388 254 220 388 257 220 minecraft:mossy_cobblestone
setblock 390 254 222 minecraft:stone_bricks
setblock 391 254 221 minecraft:stone_bricks
fill 391 254 222 391 257 222 minecraft:mossy_cobblestone
setblock 394 254 222 minecraft:mossy_cobblestone
setblock 395 254 222 minecraft:stone_bricks
fill 396 254 222 399 254 222 minecraft:mossy_cobblestone
fill 398 254 221 400 254 221 minecraft:mossy_cobblestone
setblock 400 254 222 minecraft:stone_bricks
fill 401 254 182 404 254 182 minecraft:mossy_cobblestone
setblock 401 254 221 minecraft:stone_bricks
fill 401 254 222 401 257 222 minecraft:mossy_cobblestone
fill 402 254 221 402 257 221 minecraft:mossy_cobblestone
setblock 404 254 222 minecraft:mossy_cobblestone
setblock 405 254 182 minecraft:stone_bricks
setblock 405 254 222 minecraft:stone_bricks
fill 406 254 182 408 255 182 minecraft:mossy_cobblestone
setblock 406 254 221 minecraft:stone_bricks
fill 406 254 222 406 257 222 minecraft:mossy_cobblestone
setblock 409 254 222 minecraft:mossy_cobblestone
fill 416 254 182 417 256 182 minecraft:mossy_cobblestone
fill 416 254 192 416 257 192 minecraft:mossy_cobblestone
setblock 416 254 196 minecraft:stone_bricks
fill 416 254 197 416 255 199 minecraft:mossy_cobblestone
fill 416 254 222 417 256 222 minecraft:mossy_cobblestone
fill 417 254 183 417 254 184 minecraft:mossy_cobblestone
setblock 417 254 185 minecraft:stone_bricks
fill 417 254 186 417 256 187 minecraft:mossy_cobblestone
setblock 417 254 190 minecraft:stone_bricks
fill 417 254 191 417 257 191 minecraft:mossy_cobblestone
setblock 417 254 195 minecraft:stone_bricks
fill 417 254 196 417 257 196 minecraft:mossy_cobblestone
setblock 417 254 200 minecraft:stone_bricks
fill 417 254 201 417 257 201 minecraft:mossy_cobblestone
fill 417 254 216 417 254 219 minecraft:mossy_cobblestone
setblock 417 254 220 minecraft:stone_bricks
fill 417 254 221 417 257 221 minecraft:mossy_cobblestone
setblock 377 255 184 minecraft:stone_bricks
fill 377 255 185 377 255 188 minecraft:mossy_cobblestone
setblock 377 255 189 minecraft:stone_bricks
fill 377 255 190 377 258 190 minecraft:mossy_cobblestone
setblock 377 255 194 minecraft:stone_bricks
fill 377 255 195 378 257 195 minecraft:mossy_cobblestone
setblock 377 255 199 minecraft:stone_bricks
fill 377 255 200 377 257 201 minecraft:mossy_cobblestone
setblock 377 255 213 minecraft:mossy_cobblestone
setblock 377 255 214 minecraft:stone_bricks
fill 377 255 215 377 258 215 minecraft:mossy_cobblestone
setblock 377 255 218 minecraft:mossy_cobblestone
setblock 377 255 219 minecraft:stone_bricks
fill 377 255 220 377 258 220 minecraft:mossy_cobblestone
setblock 378 255 182 minecraft:mossy_cobblestone
setblock 378 255 183 minecraft:stone_bricks
fill 378 255 184 378 258 184 minecraft:mossy_cobblestone
fill 378 255 194 378 257 194 minecraft:mossy_cobblestone
fill 378 255 196 378 255 197 minecraft:mossy_cobblestone
setblock 378 255 198 minecraft:stone_bricks
fill 378 255 199 378 258 199 minecraft:mossy_cobblestone
fill 378 255 214 378 258 214 minecraft:mossy_cobblestone
setblock 378 255 218 minecraft:stone_bricks
fill 378 255 219 381 255 219 minecraft:mossy_cobblestone
setblock 378 255 222 minecraft:mossy_cobblestone
setblock 379 255 182 minecraft:stone_bricks
fill 379 255 183 379 258 183 minecraft:mossy_cobblestone
fill 379 255 215 379 255 216 minecraft:mossy_cobblestone
setblock 379 255 217 minecraft:stone_bricks
fill 379 255 218 379 258 218 minecraft:mossy_cobblestone
setblock 379 255 222 minecraft:stone_bricks
fill 380 255 182 380 258 182 minecraft:mossy_cobblestone
fill 380 255 217 380 258 217 minecraft:mossy_cobblestone
setblock 380 255 220 minecraft:mossy_cobblestone
setblock 380 255 221 minecraft:stone_bricks
fill 380 255 222 380 258 222 minecraft:mossy_cobblestone
fill 381 255 183 382 255 183 minecraft:mossy_cobblestone
setblock 381 255 220 minecraft:stone_bricks
fill 381 255 221 381 258 221 minecraft:mossy_cobblestone
setblock 382 255 219 minecraft:stone_bricks
fill 382 255 220 382 258 220 minecraft:mossy_cobblestone
setblock 383 255 183 minecraft:stone_bricks
setblock 383 255 218 minecraft:stone_bricks
fill 383 255 219 383 258 219 minecraft:mossy_cobblestone
setblock 384 255 182 minecraft:stone_bricks
fill 384 255 183 385 257 183 minecraft:mossy_cobblestone
setblock 384 255 222 minecraft:stone_bricks
fill 385 255 182 385 258 182 minecraft:mossy_cobblestone
setblock 385 255 221 minecraft:stone_bricks
fill 385 255 222 385 258 222 minecraft:mossy_cobblestone
setblock 386 255 219 minecraft:mossy_cobblestone
setblock 386 255 220 minecraft:stone_bricks
fill 386 255 221 386 258 221 minecraft:mossy_cobblestone
fill 387 255 192 387 255 217 minecraft:stone_bricks
setblock 387 255 219 minecraft:stone_bricks
fill 387 255 220 387 258 220 minecraft:mossy_cobblestone
fill 388 255 198 388 255 211 minecraft:stone_bricks
setblock 389 255 222 minecraft:stone_bricks
setblock 390 255 221 minecraft:stone_bricks
fill 390 255 222 390 258 222 minecraft:mossy_cobblestone
fill 391 255 221 393 256 221 minecraft:mossy_cobblestone
setblock 394 255 222 minecraft:stone_bricks
setblock 395 255 221 minecraft:stone_bricks
fill 395 255 222 398 255 222 minecraft:mossy_cobblestone
fill 396 255 221 399 255 221 minecraft:mossy_cobblestone
setblock 399 255 182 minecraft:stone_bricks
setblock 399 255 222 minecraft:stone_bricks
fill 400 255 182 403 255 182 minecraft:mossy_cobblestone
setblock 400 255 220 minecraft:mossy_cobblestone
setblock 400 255 221 minecraft:stone_bricks
fill 400 255 222 400 258 222 minecraft:mossy_cobblestone
setblock 401 255 220 minecraft:stone_bricks
fill 401 255 221 401 258 221 minecraft:mossy_cobblestone
fill 402 255 220 404 256 220 minecraft:mossy_cobblestone
fill 403 255 221 404 255 221 minecraft:mossy_cobblestone
setblock 404 255 182 minecraft:stone_bricks
setblock 404 255 222 minecraft:stone_bricks
fill 405 255 182 405 258 182 minecraft:mossy_cobblestone
setblock 405 255 221 minecraft:stone_bricks
fill 405 255 222 405 258 222 minecraft:mossy_cobblestone
fill 406 255 221 407 257 221 minecraft:mossy_cobblestone
setblock 409 255 182 minecraft:stone_bricks
setblock 409 255 222 minecraft:stone_bricks
fill 410 255 182 413 255 182 minecraft:mossy_cobblestone
fill 410 255 222 410 258 222 minecraft:mossy_cobblestone
setblock 414 255 182 minecraft:stone_bricks
setblock 414 255 222 minecraft:stone_bricks
fill 415 255 182 415 258 182 minecraft:mossy_cobblestone
fill 415 255 222 415 258 222 minecraft:mossy_cobblestone
setblock 416 255 195 minecraft:stone_bricks
fill 416 255 196 416 258 196 minecraft:mossy_cobblestone
setblock 416 255 200 minecraft:stone_bricks
setblock 417 255 183 minecraft:mossy_cobblestone
setblock 417 255 184 minecraft:stone_bricks
fill 417 255 185 417 258 185 minecraft:mossy_cobblestone
setblock 417 255 189 minecraft:stone_bricks
fill 417 255 190 417 258 190 minecraft:mossy_cobblestone
setblock 417 255 194 minecraft:stone_bricks
fill 417 255 195 417 258 195 minecraft:mossy_cobblestone
setblock 417 255 198 minecraft:mossy_cobblestone
setblock 417 255 199 minecraft:stone_bricks
fill 417 255 200 417 258 200 minecraft:mossy_cobblestone
fill 417 255 202 417 255 203 minecraft:mossy_cobblestone
fill 417 255 216 417 255 218 minecraft:mossy_cobblestone
setblock 417 255 219 minecraft:stone_bricks
fill 417 255 220 417 258 220 minecraft:mossy_cobblestone
setblock 377 256 182 minecraft:mossy_cobblestone
setblock 377 256 183 minecraft:stone_bricks
fill 377 256 184 377 256 187 minecraft:mossy_cobblestone
setblock 377 256 188 minecraft:stone_bricks
fill 377 256 189 377 259 189 minecraft:mossy_cobblestone
setblock 377 256 193 minecraft:stone_bricks
fill 377 256 194 377 259 194 minecraft:mossy_cobblestone
setblock 377 256 197 minecraft:mossy_cobblestone
setblock 377 256 198 minecraft:stone_bricks
fill 377 256 199 377 259 199 minecraft:mossy_cobblestone
setblock 377 256 202 minecraft:mossy_cobblestone
setblock 377 256 203 minecraft:stone_bricks
setblock 377 256 212 minecraft:mossy_cobblestone
setblock 377 256 213 minecraft:stone_bricks
fill 377 256 214 377 259 214 minecraft:mossy_cobblestone
setblock 377 256 218 minecraft:stone_bricks
fill 377 256 219 380 256 219 minecraft:mossy_cobblestone
setblock 378 256 182 minecraft:stone_bricks
fill 378 256 183 378 259 183 minecraft:mossy_cobblestone
fill 378 256 185 378 257 185 minecraft:mossy_cobblestone
setblock 378 256 196 minecraft:mossy_cobblestone
setblock 378 256 197 minecraft:stone_bricks
fill 378 256 198 378 259 198 minecraft:mossy_cobblestone
fill 378 256 200 378 256 201 minecraft:mossy_cobblestone
setblock 378 256 217 minecraft:stone_bricks
fill 378 256 218 378 259 218 minecraft:mossy_cobblestone
setblock 378 256 222 minecraft:stone_bricks
fill 379 256 182 379 259 182 minecraft:mossy_cobblestone
setblock 379 256 215 minecraft:mossy_cobblestone
setblock 379 256 216 minecraft:stone_bricks
fill 379 256 217 379 259 217 minecraft:mossy_cobblestone
setblock 379 256 221 minecraft:stone_bricks
fill 379 256 222 379 259 222 minecraft:mossy_cobblestone
fill 380 256 216 380 257 216 minecraft:mossy_cobblestone
setblock 380 256 220 minecraft:stone_bricks
fill 380 256 221 380 259 221 minecraft:mossy_cobblestone
setblock 381 256 183 minecraft:mossy_cobblestone
setblock 381 256 219 minecraft:stone_bricks
fill 381 256 220 381 259 220 minecraft:mossy_cobblestone
setblock 382 256 183 minecraft:stone_bricks
setblock 382 256 218 minecraft:stone_bricks
fill 382 256 219 382 259 219 minecraft:mossy_cobblestone
setblock 383 256 182 minecraft:stone_bricks
fill 383 256 183 383 259 183 minecraft:mossy_cobblestone
setblock 383 256 218 minecraft:mossy_cobblestone
setblock 383 256 222 minecraft:stone_bricks
fill 384 256 182 384 259 182 minecraft:mossy_cobblestone
setblock 384 256 221 minecraft:stone_bricks
fill 384 256 222 384 259 222 minecraft:mossy_cobblestone
setblock 385 256 220 minecraft:stone_bricks
fill 385 256 221 385 259 221 minecraft:mossy_cobblestone
fill 386 256 183 387 256 188 minecraft:stone_bricks
setblock 386 256 219 minecraft:stone_bricks
fill 386 256 220 386 259 220 minecraft:mossy_cobblestone
fill 387 256 189 387 256 207 minecraft:stone_bricks
setblock 387 256 219 minecraft:mossy_cobblestone
setblock 388 256 182 minecraft:stone_bricks
fill 388 256 190 388 256 210 minecraft:stone_bricks
fill 388 256 211 388 256 219 minecraft:spruce_planks
setblock 388 256 222 minecraft:stone_bricks
setblock 389 256 221 minecraft:stone_bricks
fill 389 256 222 389 259 222 minecraft:mossy_cobblestone
fill 390 256 221 390 259 221 minecraft:mossy_cobblestone
setblock 392 256 222 minecraft:mossy_cobblestone
setblock 393 256 222 minecraft:stone_bricks
setblock 394 256 221 minecraft:stone_bricks
fill 394 256 222 397 256 222 minecraft:mossy_cobblestone
fill 395 256 221 398 256 221 minecraft:mossy_cobblestone
setblock 398 256 182 minecraft:stone_bricks
fill 398 256 220 399 256 220 minecraft:mossy_cobblestone
setblock 398 256 222 minecraft:stone_bricks
fill 399 256 182 402 256 182 minecraft:mossy_cobblestone
setblock 399 256 221 minecraft:stone_bricks
fill 399 256 222 399 259 222 minecraft:mossy_cobblestone
setblock 400 256 220 minecraft:stone_bricks
fill 400 256 221 400 259 221 minecraft:mossy_cobblestone
fill 401 256 220 401 259 220 minecraft:mossy_cobblestone
setblock 402 256 183 minecraft:stone_bricks
setblock 403 256 182 minecraft:stone_bricks
fill 403 256 183 405 257 183 minecraft:mossy_cobblestone
setblock 403 256 221 minecraft:mossy_cobblestone
setblock 403 256 222 minecraft:stone_bricks
fill 404 256 182 404 259 182 minecraft:mossy_cobblestone
setblock 404 256 221 minecraft:stone_bricks
fill 404 256 222 404 259 222 minecraft:mossy_cobblestone
fill 405 256 221 405 259 221 minecraft:mossy_cobblestone
fill 406 256 182 407 256 182 minecraft:mossy_cobblestone
setblock 407 256 222 minecraft:mossy_cobblestone
setblock 408 256 182 minecraft:stone_bricks
setblock 408 256 222 minecraft:stone_bricks
fill 409 256 182 412 256 182 minecraft:mossy_cobblestone
fill 409 256 222 409 259 222 minecraft:mossy_cobblestone
fill 411 256 222 412 256 222 minecraft:mossy_cobblestone
setblock 413 256 182 minecraft:stone_bricks
setblock 413 256 222 minecraft:stone_bricks
fill 414 256 182 414 259 182 minecraft:mossy_cobblestone
fill 414 256 222 414 259 222 minecraft:mossy_cobblestone
setblock 416 256 183 minecraft:mossy_cobblestone
setblock 416 256 184 minecraft:stone_bricks
setblock 416 256 194 minecraft:stone_bricks
fill 416 256 195 416 259 195 minecraft:mossy_cobblestone
fill 416 256 197 416 256 198 minecraft:mossy_cobblestone
setblock 416 256 199 minecraft:stone_bricks
fill 416 256 200 416 258 201 minecraft:mossy_cobblestone
setblock 416 256 219 minecraft:stone_bricks
fill 416 256 220 416 258 221 minecraft:mossy_cobblestone
setblock 417 256 183 minecraft:stone_bricks
fill 417 256 184 417 259 184 minecraft:mossy_cobblestone
setblock 417 256 188 minecraft:stone_bricks
fill 417 256 189 417 259 189 minecraft:mossy_cobblestone
setblock 417 256 193 minecraft:stone_bricks
fill 417 256 194 417 259 194 minecraft:mossy_cobblestone
setblock 417 256 198 minecraft:stone_bricks
fill 417 256 199 417 259 199 minecraft:mossy_cobblestone
setblock 417 256 202 minecraft:mossy_cobblestone
setblock 417 256 203 minecraft:stone_bricks
fill 417 256 204 417 259 204 minecraft:mossy_cobblestone
fill 417 256 215 417 256 217 minecraft:mossy_cobblestone
setblock 417 256 218 minecraft:stone_bricks
fill 417 256 219 417 259 219 minecraft:mossy_cobblestone
setblock 377 257 182 minecraft:stone_bricks
fill 377 257 183 377 257 186 minecraft:mossy_cobblestone
setblock 377 257 187 minecraft:stone_bricks
fill 377 257 188 377 260 188 minecraft:mossy_cobblestone
setblock 377 257 192 minecraft:stone_bricks
fill 377 257 193 377 259 193 minecraft:mossy_cobblestone
setblock 377 257 197 minecraft:stone_bricks
fill 377 257 198 377 260 198 minecraft:mossy_cobblestone
setblock 377 257 202 minecraft:stone_bricks
fill 377 257 203 377 257 206 minecraft:mossy_cobblestone
setblock 377 257 212 minecraft:stone_bricks
fill 377 257 213 378 259 213 minecraft:mossy_cobblestone
setblock 377 257 217 minecraft:stone_bricks
fill 377 257 218 377 259 219 minecraft:mossy_cobblestone
setblock 377 257 221 minecraft:mossy_cobblestone
setblock 377 257 222 minecraft:stone_bricks
fill 378 257 182 378 260 182 minecraft:mossy_cobblestone
setblock 378 257 186 minecraft:stone_bricks
setblock 378 257 196 minecraft:stone_bricks
fill 378 257 197 378 260 197 minecraft:mossy_cobblestone
setblock 378 257 200 minecraft:mossy_cobblestone
setblock 378 257 201 minecraft:stone_bricks
fill 378 257 202 378 259 203 minecraft:mossy_cobblestone
setblock 378 257 216 minecraft:stone_bricks
fill 378 257 217 378 260 217 minecraft:mossy_cobblestone
fill 378 257 219 379 257 219 minecraft:mossy_cobblestone
setblock 378 257 221 minecraft:stone_bricks
fill 378 257 222 378 260 222 minecraft:mossy_cobblestone
setblock 379 257 184 minecraft:mossy_cobblestone
setblock 379 257 192 minecraft:light[level=12]
setblock 379 257 200 minecraft:light[level=12]
setblock 379 257 208 minecraft:light[level=12]
setblock 379 257 215 minecraft:stone_bricks
fill 379 257 216 379 260 216 minecraft:mossy_cobblestone
setblock 379 257 220 minecraft:stone_bricks
fill 379 257 221 379 260 221 minecraft:mossy_cobblestone
setblock 380 257 184 minecraft:stone_bricks
setblock 380 257 219 minecraft:stone_bricks
fill 380 257 220 380 260 220 minecraft:mossy_cobblestone
setblock 381 257 183 minecraft:stone_bricks
fill 381 257 184 381 260 184 minecraft:mossy_cobblestone
fill 381 257 219 381 260 219 minecraft:mossy_cobblestone
setblock 382 257 182 minecraft:stone_bricks
fill 382 257 183 382 260 183 minecraft:mossy_cobblestone
setblock 382 257 218 minecraft:mossy_cobblestone
setblock 382 257 222 minecraft:stone_bricks
fill 383 257 182 383 260 182 minecraft:mossy_cobblestone
setblock 383 257 221 minecraft:stone_bricks
fill 383 257 222 383 260 222 minecraft:mossy_cobblestone
setblock 384 257 220 minecraft:stone_bricks
fill 384 257 221 384 260 221 minecraft:mossy_cobblestone
setblock 385 257 219 minecraft:stone_bricks
fill 385 257 220 385 260 220 minecraft:mossy_cobblestone
fill 386 257 183 387 257 183 minecraft:stone_bricks
setblock 386 257 219 minecraft:mossy_cobblestone
setblock 387 257 182 minecraft:stone_bricks
fill 387 257 184 387 257 191 minecraft:stone_bricks
fill 387 257 192 387 257 203 minecraft:spruce_planks
setblock 387 257 208 minecraft:light[level=12]
setblock 387 257 216 minecraft:light[level=12]
setblock 387 257 222 minecraft:stone_bricks
fill 388 257 182 388 259 182 minecraft:mossy_cobblestone
fill 388 257 203 388 257 208 minecraft:spruce_planks
setblock 388 257 221 minecraft:stone_bricks
fill 388 257 222 388 260 222 minecraft:mossy_cobblestone
setblock 389 257 220 minecraft:stone_bricks
fill 389 257 221 389 260 221 minecraft:mossy_cobblestone
fill 391 257 221 392 257 221 minecraft:mossy_cobblestone
setblock 392 257 222 minecraft:stone_bricks
setblock 393 257 221 minecraft:stone_bricks
fill 393 257 222 396 257 222 minecraft:mossy_cobblestone
fill 394 257 221 397 257 221 minecraft:mossy_cobblestone
setblock 395 257 184 minecraft:light[level=12]
setblock 395 257 192 minecraft:light[level=12]
setblock 395 257 200 minecraft:light[level=12]
setblock 395 257 208 minecraft:light[level=12]
setblock 395 257 216 minecraft:light[level=12]
setblock 396 257 182 minecraft:mossy_cobblestone
setblock 397 257 182 minecraft:stone_bricks
setblock 397 257 222 minecraft:stone_bricks
fill 398 257 182 401 257 182 minecraft:mossy_cobblestone
setblock 398 257 220 minecraft:mossy_cobblestone
setblock 398 257 221 minecraft:stone_bricks
fill 398 257 222 398 260 222 minecraft:mossy_cobblestone
setblock 399 257 220 minecraft:stone_bricks
fill 399 257 221 399 260 221 minecraft:mossy_cobblestone
setblock 400 257 183 minecraft:mossy_cobblestone
fill 400 257 220 400 259 220 minecraft:mossy_cobblestone
setblock 401 257 183 minecraft:stone_bricks
setblock 402 257 182 minecraft:stone_bricks
fill 402 257 183 402 260 183 minecraft:mossy_cobblestone
fill 402 257 220 403 257 220 minecraft:mossy_cobblestone
setblock 402 257 222 minecraft:stone_bricks
fill 403 257 182 403 260 182 minecraft:mossy_cobblestone
setblock 403 257 184 minecraft:light[level=12]
setblock 403 257 192 minecraft:light[level=12]
setblock 403 257 200 minecraft:light[level=12]
setblock 403 257 208 minecraft:light[level=12]
setblock 403 257 216 minecraft:light[level=12]
setblock 403 257 221 minecraft:stone_bricks
fill 403 257 222 403 260 222 minecraft:mossy_cobblestone
setblock 404 257 220 minecraft:stone_bricks
fill 404 257 221 404 260 221 minecraft:mossy_cobblestone
setblock 406 257 182 minecraft:mossy_cobblestone
setblock 406 257 183 minecraft:stone_bricks
setblock 407 257 182 minecraft:stone_bricks
setblock 407 257 222 minecraft:stone_bricks
fill 408 257 182 411 257 182 minecraft:mossy_cobblestone
fill 408 257 222 408 260 222 minecraft:mossy_cobblestone
setblock 411 257 184 minecraft:light[level=12]
setblock 411 257 192 minecraft:light[level=12]
setblock 411 257 200 minecraft:light[level=12]
setblock 411 257 208 minecraft:light[level=12]
setblock 411 257 216 minecraft:light[level=12]
setblock 411 257 222 minecraft:mossy_cobblestone
setblock 412 257 182 minecraft:stone_bricks
setblock 412 257 222 minecraft:stone_bricks
fill 413 257 182 413 260 182 minecraft:mossy_cobblestone
fill 413 257 222 413 260 222 minecraft:mossy_cobblestone
fill 414 257 183 415 257 183 minecraft:mossy_cobblestone
fill 415 257 221 415 259 221 minecraft:mossy_cobblestone
setblock 416 257 182 minecraft:mossy_cobblestone
setblock 416 257 183 minecraft:stone_bricks
fill 416 257 184 416 258 186 minecraft:mossy_cobblestone
setblock 416 257 193 minecraft:stone_bricks
fill 416 257 194 416 259 194 minecraft:mossy_cobblestone
setblock 416 257 197 minecraft:mossy_cobblestone
setblock 416 257 198 minecraft:stone_bricks
fill 416 257 199 416 260 199 minecraft:mossy_cobblestone
setblock 416 257 202 minecraft:mossy_cobblestone
fill 416 257 219 416 260 219 minecraft:mossy_cobblestone
setblock 416 257 222 minecraft:mossy_cobblestone
setblock 417 257 182 minecraft:stone_bricks
fill 417 257 183 417 260 183 minecraft:mossy_cobblestone
setblock 417 257 186 minecraft:mossy_cobblestone
setblock 417 257 187 minecraft:stone_bricks
fill 417 257 188 417 260 188 minecraft:mossy_cobblestone
setblock 417 257 192 minecraft:stone_bricks
fill 417 257 193 417 260 193 minecraft:mossy_cobblestone
setblock 417 257 197 minecraft:stone_bricks
fill 417 257 198 417 260 198 minecraft:mossy_cobblestone
setblock 417 257 202 minecraft:stone_bricks
fill 417 257 203 417 260 203 minecraft:mossy_cobblestone
fill 417 257 205 417 258 205 minecraft:mossy_cobblestone
fill 417 257 215 417 257 216 minecraft:mossy_cobblestone
setblock 417 257 217 minecraft:stone_bricks
fill 417 257 218 417 260 218 minecraft:mossy_cobblestone
setblock 417 257 222 minecraft:stone_bricks
fill 377 258 182 377 258 185 minecraft:mossy_cobblestone
setblock 377 258 186 minecraft:stone_bricks
fill 377 258 187 377 261 187 minecraft:mossy_cobblestone
setblock 377 258 191 minecraft:stone_bricks
fill 377 258 192 377 259 192 minecraft:mossy_cobblestone
setblock 377 258 195 minecraft:mossy_cobblestone
setblock 377 258 196 minecraft:stone_bricks
fill 377 258 197 377 261 197 minecraft:mossy_cobblestone
setblock 377 258 200 minecraft:mossy_cobblestone
setblock 377 258 201 minecraft:stone_bricks
fill 377 258 202 377 258 205 minecraft:mossy_cobblestone
setblock 377 258 206 minecraft:stone_bricks
fill 377 258 207 377 258 210 minecraft:mossy_cobblestone
setblock 377 258 211 minecraft:stone_bricks
fill 377 258 212 377 261 212 minecraft:mossy_cobblestone
setblock 377 258 216 minecraft:stone_bricks
fill 377 258 217 377 261 217 minecraft:mossy_cobblestone
setblock 377 258 221 minecraft:stone_bricks
fill 377 258 222 377 261 222 minecraft:mossy_cobblestone
setblock 378 258 185 minecraft:stone_bricks
fill 378 258 186 378 261 186 minecraft:mossy_cobblestone
setblock 378 258 195 minecraft:stone_bricks
fill 378 258 196 378 259 196 minecraft:mossy_cobblestone
setblock 378 258 200 minecraft:stone_bricks
fill 378 258 201 379 260 201 minecraft:mossy_cobblestone
setblock 378 258 204 minecraft:mossy_cobblestone
setblock 378 258 205 minecraft:stone_bricks
setblock 378 258 215 minecraft:stone_bricks
fill 378 258 216 378 261 216 minecraft:mossy_cobblestone
setblock 378 258 219 minecraft:mossy_cobblestone
setblock 378 258 220 minecraft:stone_bricks
fill 378 258 221 378 261 221 minecraft:mossy_cobblestone
setblock 379 258 184 minecraft:stone_bricks
setblock 379 258 199 minecraft:stone_bricks
fill 379 258 200 379 259 200 minecraft:mossy_cobblestone
fill 379 258 215 379 259 215 minecraft:mossy_cobblestone
setblock 379 258 219 minecraft:stone_bricks
fill 379 258 220 379 261 220 minecraft:mossy_cobblestone
setblock 380 258 183 minecraft:stone_bricks
fill 380 258 184 380 261 184 minecraft:mossy_cobblestone
setblock 380 258 218 minecraft:stone_bricks
fill 380 258 219 380 260 219 minecraft:mossy_cobblestone
setblock 381 258 182 minecraft:stone_bricks
fill 381 258 183 381 261 183 minecraft:mossy_cobblestone
setblock 381 258 222 minecraft:stone_bricks
fill 382 258 182 382 261 182 minecraft:mossy_cobblestone
setblock 382 258 221 minecraft:stone_bricks
fill 382 258 222 382 261 222 minecraft:mossy_cobblestone
setblock 383 258 220 minecraft:stone_bricks
fill 383 258 221 383 261 221 minecraft:mossy_cobblestone
setblock 384 258 183 minecraft:mossy_cobblestone
setblock 384 258 219 minecraft:stone_bricks
fill 384 258 220 384 261 220 minecraft:mossy_cobblestone
setblock 385 258 183 minecraft:stone_bricks
setblock 385 258 219 minecraft:mossy_cobblestone
setblock 386 258 182 minecraft:stone_bricks
setblock 386 258 222 minecraft:stone_bricks
fill 387 258 182 387 261 182 minecraft:mossy_cobblestone
fill 387 258 183 387 258 190 minecraft:spruce_planks
setblock 387 258 221 minecraft:stone_bricks
fill 387 258 222 387 261 222 minecraft:mossy_cobblestone
setblock 388 258 220 minecraft:stone_bricks
fill 388 258 221 388 260 221 minecraft:mossy_cobblestone
setblock 391 258 221 minecraft:mossy_cobblestone
setblock 391 258 222 minecraft:stone_bricks
setblock 392 258 221 minecraft:stone_bricks
fill 392 258 222 395 258 222 minecraft:mossy_cobblestone
fill 393 258 221 396 258 221 minecraft:mossy_cobblestone
setblock 395 258 182 minecraft:mossy_cobblestone
setblock 396 258 182 minecraft:stone_bricks
setblock 396 258 222 minecraft:stone_bricks
fill 397 258 182 400 258 182 minecraft:mossy_cobblestone
setblock 397 258 221 minecraft:stone_bricks
fill 397 258 222 397 261 222 minecraft:mossy_cobblestone
setblock 398 258 220 minecraft:stone_bricks
fill 398 258 221 398 261 221 minecraft:mossy_cobblestone
setblock 399 258 183 minecraft:mossy_cobblestone
fill 399 258 220 399 259 220 minecraft:mossy_cobblestone
setblock 400 258 183 minecraft:stone_bricks
setblock 401 258 182 minecraft:stone_bricks
fill 401 258 183 401 261 183 minecraft:mossy_cobblestone
setblock 401 258 222 minecraft:stone_bricks
fill 402 258 182 402 261 182 minecraft:mossy_cobblestone
setblock 402 258 220 minecraft:mossy_cobblestone
setblock 402 258 221 minecraft:stone_bricks
fill 402 258 222 402 261 222 minecraft:mossy_cobblestone
fill 403 258 183 404 258 183 minecraft:mossy_cobblestone
setblock 403 258 220 minecraft:stone_bricks
fill 403 258 221 403 260 221 minecraft:mossy_cobblestone
setblock 405 258 183 minecraft:stone_bricks
setblock 406 258 182 minecraft:stone_bricks
fill 406 258 183 407 260 183 minecraft:mossy_cobblestone
setblock 406 258 221 minecraft:mossy_cobblestone
setblock 406 258 222 minecraft:stone_bricks
fill 407 258 182 410 258 182 minecraft:mossy_cobblestone
fill 407 258 222 407 260 222 minecraft:mossy_cobblestone
setblock 411 258 182 minecraft:stone_bricks
setblock 411 258 222 minecraft:stone_bricks
fill 412 258 182 412 261 182 minecraft:mossy_cobblestone
fill 412 258 222 412 261 222 minecraft:mossy_cobblestone
fill 413 258 183 414 258 183 minecraft:mossy_cobblestone
fill 414 258 221 414 260 221 minecraft:mossy_cobblestone
setblock 415 258 183 minecraft:stone_bricks
setblock 416 258 182 minecraft:stone_bricks
fill 416 258 183 416 261 183 minecraft:mossy_cobblestone
setblock 416 258 187 minecraft:stone_bricks
setblock 416 258 192 minecraft:stone_bricks
setblock 416 258 193 minecraft:mossy_cobblestone
setblock 416 258 197 minecraft:stone_bricks
fill 416 258 198 416 261 198 minecraft:mossy_cobblestone
setblock 416 258 202 minecraft:stone_bricks
setblock 416 258 218 minecraft:mossy_cobblestone
setblock 416 258 222 minecraft:stone_bricks
fill 417 258 182 417 261 182 minecraft:mossy_cobblestone
setblock 417 258 186 minecraft:stone_bricks
fill 417 258 187 417 261 187 minecraft:mossy_cobblestone
setblock 417 258 191 minecraft:stone_bricks
fill 417 258 192 417 261 192 minecraft:mossy_cobblestone
setblock 417 258 196 minecraft:stone_bricks
fill 417 258 197 417 261 197 minecraft:mossy_cobblestone
setblock 417 258 201 minecraft:stone_bricks
fill 417 258 202 417 261 202 minecraft:mossy_cobblestone
setblock 417 258 206 minecraft:stone_bricks
setblock 417 258 215 minecraft:mossy_cobblestone
setblock 417 258 216 minecraft:stone_bricks
fill 417 258 217 417 261 217 minecraft:mossy_cobblestone
setblock 417 258 221 minecraft:stone_bricks
fill 417 258 222 417 261 222 minecraft:mossy_cobblestone
fill 377 259 182 377 259 184 minecraft:mossy_cobblestone
setblock 377 259 185 minecraft:stone_bricks
fill 377 259 186 377 262 186 minecraft:mossy_cobblestone
setblock 377 259 190 minecraft:stone_bricks
setblock 377 259 191 minecraft:mossy_cobblestone
setblock 377 259 195 minecraft:stone_bricks
fill 377 259 196 377 261 196 minecraft:mossy_cobblestone
setblock 377 259 200 minecraft:stone_bricks
fill 377 259 201 377 259 204 minecraft:mossy_cobblestone
setblock 377 259 205 minecraft:stone_bricks
fill 377 259 206 377 259 209 minecraft:mossy_cobblestone
setblock 377 259 210 minecraft:stone_bricks
fill 377 259 211 377 262 211 minecraft:mossy_cobblestone
setblock 377 259 215 minecraft:stone_bricks
fill 377 259 216 377 262 216 minecraft:mossy_cobblestone
setblock 377 259 220 minecraft:stone_bricks
fill 377 259 221 377 262 221 minecraft:mossy_cobblestone
setblock 378 259 184 minecraft:stone_bricks
fill 378 259 185 378 262 185 minecraft:mossy_cobblestone
fill 378 259 187 378 260 187 minecraft:mossy_cobblestone
setblock 378 259 199 minecraft:stone_bricks
fill 378 259 200 378 262 200 minecraft:mossy_cobblestone
setblock 378 259 204 minecraft:stone_bricks
fill 378 259 205 378 261 206 minecraft:mossy_cobblestone
setblock 378 259 214 minecraft:stone_bricks
fill 378 259 215 378 262 215 minecraft:mossy_cobblestone
setblock 378 259 219 minecraft:stone_bricks
fill 378 259 220 378 262 220 minecraft:mossy_cobblestone
setblock 379 259 183 minecraft:stone_bricks
fill 379 259 184 379 262 184 minecraft:mossy_cobblestone
setblock 379 259 202 minecraft:mossy_cobblestone
setblock 379 259 218 minecraft:stone_bricks
fill 379 259 219 379 262 219 minecraft:mossy_cobblestone
setblock 380 259 182 minecraft:stone_bricks
fill 380 259 183 380 262 183 minecraft:mossy_cobblestone
setblock 380 259 217 minecraft:stone_bricks
fill 380 259 218 380 260 218 minecraft:mossy_cobblestone
setblock 380 259 222 minecraft:stone_bricks
fill 381 259 182 381 262 182 minecraft:mossy_cobblestone
setblock 381 259 221 minecraft:stone_bricks
fill 381 259 222 381 262 222 minecraft:mossy_cobblestone
setblock 382 259 220 minecraft:stone_bricks
fill 382 259 221 382 262 221 minecraft:mossy_cobblestone
setblock 383 259 219 minecraft:stone_bricks
fill 383 259 220 383 261 220 minecraft:mossy_cobblestone
setblock 384 259 183 minecraft:stone_bricks
setblock 384 259 219 minecraft:mossy_cobblestone
setblock 385 259 182 minecraft:stone_bricks
setblock 385 259 183 minecraft:mossy_cobblestone
setblock 385 259 222 minecraft:stone_bricks
fill 386 259 182 386 262 182 minecraft:mossy_cobblestone
setblock 386 259 221 minecraft:stone_bricks
fill 386 259 222 386 262 222 minecraft:mossy_cobblestone
setblock 387 259 220 minecraft:stone_bricks
fill 387 259 221 387 261 221 minecraft:mossy_cobblestone
setblock 390 259 222 minecraft:stone_bricks
setblock 391 259 221 minecraft:stone_bricks
fill 391 259 222 394 259 222 minecraft:mossy_cobblestone
fill 392 259 221 395 259 221 minecraft:mossy_cobblestone
setblock 394 259 182 minecraft:mossy_cobblestone
setblock 395 259 182 minecraft:stone_bricks
setblock 395 259 222 minecraft:stone_bricks
fill 396 259 182 399 259 182 minecraft:mossy_cobblestone
setblock 396 259 221 minecraft:stone_bricks
fill 396 259 222 396 262 222 minecraft:mossy_cobblestone
fill 397 259 221 397 261 221 minecraft:mossy_cobblestone
setblock 398 259 183 minecraft:mossy_cobblestone
setblock 399 259 183 minecraft:stone_bricks
setblock 400 259 182 minecraft:stone_bricks
fill 400 259 183 400 262 183 minecraft:mossy_cobblestone
setblock 400 259 222 minecraft:stone_bricks
fill 401 259 182 401 262 182 minecraft:mossy_cobblestone
setblock 401 259 221 minecraft:stone_bricks
fill 401 259 222 401 262 222 minecraft:mossy_cobblestone
fill 402 259 221 402 261 221 minecraft:mossy_cobblestone
setblock 403 259 183 minecraft:mossy_cobblestone
setblock 404 259 183 minecraft:stone_bricks
setblock 405 259 182 minecraft:stone_bricks
fill 405 259 183 405 262 183 minecraft:mossy_cobblestone
setblock 405 259 222 minecraft:stone_bricks
fill 406 259 182 409 259 182 minecraft:mossy_cobblestone
fill 406 259 222 406 261 222 minecraft:mossy_cobblestone
setblock 408 259 183 minecraft:mossy_cobblestone
setblock 410 259 182 minecraft:stone_bricks
setblock 410 259 222 minecraft:stone_bricks
fill 411 259 182 411 261 183 minecraft:mossy_cobblestone
fill 411 259 222 411 261 222 minecraft:mossy_cobblestone
fill 412 259 183 413 259 183 minecraft:mossy_cobblestone
setblock 414 259 183 minecraft:stone_bricks
setblock 415 259 182 minecraft:stone_bricks
fill 415 259 183 415 262 183 minecraft:mossy_cobblestone
setblock 415 259 222 minecraft:stone_bricks
fill 416 259 182 416 262 182 minecraft:mossy_cobblestone
fill 416 259 184 416 259 185 minecraft:mossy_cobblestone
setblock 416 259 186 minecraft:stone_bricks
fill 416 259 187 416 261 188 minecraft:mossy_cobblestone
setblock 416 259 196 minecraft:stone_bricks
fill 416 259 197 416 260 197 minecraft:mossy_cobblestone
setblock 416 259 200 minecraft:mossy_cobblestone
setblock 416 259 201 minecraft:stone_bricks
fill 416 259 202 416 261 203 minecraft:mossy_cobblestone
setblock 416 259 220 minecraft:mossy_cobblestone
setblock 416 259 221 minecraft:stone_bricks
fill 416 259 222 416 262 222 minecraft:mossy_cobblestone
setblock 417 259 185 minecraft:stone_bricks
fill 417 259 186 417 262 186 minecraft:mossy_cobblestone
setblock 417 259 190 minecraft:stone_bricks
fill 417 259 191 417 262 191 minecraft:mossy_cobblestone
setblock 417 259 195 minecraft:stone_bricks
fill 417 259 196 417 262 196 minecraft:mossy_cobblestone
setblock 417 259 200 minecraft:stone_bricks
fill 417 259 201 417 262 201 minecraft:mossy_cobblestone
setblock 417 259 205 minecraft:stone_bricks
fill 417 259 206 417 262 206 minecraft:mossy_cobblestone
setblock 417 259 215 minecraft:stone_bricks
fill 417 259 216 417 262 216 minecraft:mossy_cobblestone
setblock 417 259 220 minecraft:stone_bricks
fill 417 259 221 417 262 221 minecraft:mossy_cobblestone
fill 377 260 182 377 260 183 minecraft:mossy_cobblestone
setblock 377 260 184 minecraft:stone_bricks
fill 377 260 185 377 263 185 minecraft:mossy_cobblestone
setblock 377 260 189 minecraft:stone_bricks
setblock 377 260 190 minecraft:mossy_cobblestone
setblock 377 260 194 minecraft:stone_bricks
setblock 377 260 195 minecraft:mossy_cobblestone
setblock 377 260 199 minecraft:stone_bricks
fill 377 260 200 377 260 203 minecraft:mossy_cobblestone
setblock 377 260 204 minecraft:stone_bricks
fill 377 260 205 377 260 208 minecraft:mossy_cobblestone
setblock 377 260 209 minecraft:stone_bricks
fill 377 260 210 377 263 210 minecraft:mossy_cobblestone
setblock 377 260 213 minecraft:mossy_cobblestone
setblock 377 260 214 minecraft:stone_bricks
fill 377 260 215 377 263 215 minecraft:mossy_cobblestone
setblock 377 260 218 minecraft:mossy_cobblestone
setblock 377 260 219 minecraft:stone_bricks
fill 377 260 220 377 263 220 minecraft:mossy_cobblestone
setblock 378 260 183 minecraft:stone_bricks
fill 378 260 184 378 263 184 minecraft:mossy_cobblestone
setblock 378 260 198 minecraft:stone_bricks
fill 378 260 199 378 261 199 minecraft:mossy_cobblestone
setblock 378 260 202 minecraft:mossy_cobblestone
setblock 378 260 203 minecraft:stone_bricks
fill 378 260 204 378 263 204 minecraft:mossy_cobblestone
setblock 378 260 207 minecraft:mossy_cobblestone
setblock 378 260 208 minecraft:stone_bricks
setblock 378 260 213 minecraft:stone_bricks
fill 378 260 214 378 262 214 minecraft:mossy_cobblestone
setblock 378 260 218 minecraft:stone_bricks
fill 378 260 219 378 263 219 minecraft:mossy_cobblestone
setblock 379 260 182 minecraft:stone_bricks
fill 379 260 183 379 263 183 minecraft:mossy_cobblestone
setblock 379 260 202 minecraft:stone_bricks
fill 379 260 203 379 261 203 minecraft:mossy_cobblestone
setblock 379 260 217 minecraft:stone_bricks
fill 379 260 218 379 262 218 minecraft:mossy_cobblestone
setblock 379 260 222 minecraft:stone_bricks
fill 380 260 182 380 263 182 minecraft:mossy_cobblestone
setblock 380 260 221 minecraft:stone_bricks
fill 380 260 222 380 263 222 minecraft:mossy_cobblestone
setblock 381 260 220 minecraft:stone_bricks
fill 381 260 221 381 263 221 minecraft:mossy_cobblestone
setblock 382 260 219 minecraft:stone_bricks
fill 382 260 220 382 262 220 minecraft:mossy_cobblestone
setblock 383 260 183 minecraft:stone_bricks
setblock 384 260 182 minecraft:stone_bricks
setblock 384 260 183 minecraft:mossy_cobblestone
setblock 384 260 222 minecraft:stone_bricks
fill 385 260 182 385 263 182 minecraft:mossy_cobblestone
setblock 385 260 221 minecraft:stone_bricks
fill 385 260 222 385 263 222 minecraft:mossy_cobblestone
fill 386 260 221 386 261 221 minecraft:mossy_cobblestone
setblock 389 260 222 minecraft:stone_bricks
fill 390 260 222 393 260 222 minecraft:mossy_cobblestone
setblock 394 260 182 minecraft:stone_bricks
setblock 394 260 221 minecraft:mossy_cobblestone
setblock 394 260 222 minecraft:stone_bricks
fill 395 260 182 398 260 182 minecraft:mossy_cobblestone
setblock 395 260 221 minecraft:stone_bricks
fill 395 260 222 395 263 222 minecraft:mossy_cobblestone
fill 396 260 221 396 261 221 minecraft:mossy_cobblestone
setblock 397 260 183 minecraft:mossy_cobblestone
setblock 398 260 183 minecraft:stone_bricks
setblock 399 260 182 minecraft:stone_bricks
fill 399 260 183 399 263 183 minecraft:mossy_cobblestone
setblock 399 260 222 minecraft:stone_bricks
fill 400 260 182 400 263 182 minecraft:mossy_cobblestone
setblock 400 260 221 minecraft:stone_bricks
fill 400 260 222 400 263 222 minecraft:mossy_cobblestone
fill 401 260 221 401 261 221 minecraft:mossy_cobblestone
setblock 403 260 183 minecraft:stone_bricks
setblock 404 260 182 minecraft:stone_bricks
fill 404 260 183 404 263 183 minecraft:mossy_cobblestone
setblock 404 260 222 minecraft:stone_bricks
fill 405 260 182 408 260 182 minecraft:mossy_cobblestone
fill 405 260 222 405 261 222 minecraft:mossy_cobblestone
setblock 409 260 182 minecraft:stone_bricks
setblock 409 260 222 minecraft:stone_bricks
fill 410 260 182 410 263 182 minecraft:mossy_cobblestone
setblock 410 260 222 minecraft:mossy_cobblestone
setblock 412 260 183 minecraft:mossy_cobblestone
setblock 413 260 183 minecraft:stone_bricks
setblock 414 260 182 minecraft:stone_bricks
fill 414 260 183 414 263 183 minecraft:mossy_cobblestone
setblock 414 260 222 minecraft:stone_bricks
fill 415 260 182 415 263 182 minecraft:mossy_cobblestone
fill 415 260 184 416 260 184 minecraft:mossy_cobblestone
setblock 415 260 221 minecraft:stone_bricks
fill 415 260 222 415 263 222 minecraft:mossy_cobblestone
setblock 416 260 185 minecraft:stone_bricks
fill 416 260 186 416 263 186 minecraft:mossy_cobblestone
setblock 416 260 196 minecraft:mossy_cobblestone
setblock 416 260 200 minecraft:stone_bricks
fill 416 260 201 416 262 201 minecraft:mossy_cobblestone
setblock 416 260 220 minecraft:stone_bricks
fill 416 260 221 416 263 221 minecraft:mossy_cobblestone
setblock 417 260 184 minecraft:stone_bricks
fill 417 260 185 417 263 185 minecraft:mossy_cobblestone
setblock 417 260 189 minecraft:stone_bricks
fill 417 260 190 417 263 190 minecraft:mossy_cobblestone
setblock 417 260 194 minecraft:stone_bricks
fill 417 260 195 417 263 195 minecraft:mossy_cobblestone
setblock 417 260 199 minecraft:stone_bricks
fill 417 260 200 417 263 200 minecraft:mossy_cobblestone
setblock 417 260 204 minecraft:stone_bricks
fill 417 260 205 417 263 205 minecraft:mossy_cobblestone
fill 417 260 207 417 261 207 minecraft:mossy_cobblestone
setblock 417 260 215 minecraft:mossy_cobblestone
setblock 417 260 219 minecraft:stone_bricks
fill 417 260 220 417 263 220 minecraft:mossy_cobblestone
setblock 377 261 182 minecraft:mossy_cobblestone
setblock 377 261 183 minecraft:stone_bricks
fill 377 261 184 377 264 184 minecraft:mossy_cobblestone
setblock 377 261 188 minecraft:stone_bricks
fill 377 261 189 377 264 189 minecraft:mossy_cobblestone
setblock 377 261 198 minecraft:stone_bricks
fill 377 261 199 377 261 202 minecraft:mossy_cobblestone
setblock 377 261 203 minecraft:stone_bricks
fill 377 261 204 377 261 207 minecraft:mossy_cobblestone
setblock 377 261 208 minecraft:stone_bricks
fill 377 261 209 378 263 209 minecraft:mossy_cobblestone
setblock 377 261 213 minecraft:stone_bricks
fill 377 261 214 377 264 214 minecraft:mossy_cobblestone
setblock 377 261 218 minecraft:stone_bricks
fill 377 261 219 377 264 219 minecraft:mossy_cobblestone
setblock 378 261 182 minecraft:stone_bricks
fill 378 261 183 378 264 183 minecraft:mossy_cobblestone
setblock 378 261 201 minecraft:mossy_cobblestone
setblock 378 261 202 minecraft:stone_bricks
fill 378 261 203 378 264 203 minecraft:mossy_cobblestone
setblock 378 261 207 minecraft:stone_bricks
fill 378 261 208 378 264 208 minecraft:mossy_cobblestone
setblock 378 261 217 minecraft:stone_bricks
fill 378 261 218 378 264 218 minecraft:mossy_cobblestone
setblock 378 261 222 minecraft:stone_bricks
fill 379 261 182 379 264 182 minecraft:mossy_cobblestone
setblock 379 261 204 minecraft:mossy_cobblestone
setblock 379 261 217 minecraft:mossy_cobblestone
setblock 379 261 221 minecraft:stone_bricks
fill 379 261 222 379 264 222 minecraft:mossy_cobblestone
setblock 380 261 220 minecraft:stone_bricks
fill 380 261 221 380 264 221 minecraft:mossy_cobblestone
fill 381 261 220 381 262 220 minecraft:mossy_cobblestone
setblock 382 261 183 minecraft:stone_bricks
setblock 383 261 182 minecraft:stone_bricks
fill 383 261 183 383 262 183 minecraft:mossy_cobblestone
setblock 383 261 222 minecraft:stone_bricks
fill 384 261 182 384 264 182 minecraft:mossy_cobblestone
setblock 384 261 221 minecraft:stone_bricks
fill 384 261 222 384 264 222 minecraft:mossy_cobblestone
fill 385 261 221 385 262 221 minecraft:mossy_cobblestone
setblock 388 261 222 minecraft:stone_bricks
fill 389 261 222 392 261 222 minecraft:mossy_cobblestone
setblock 393 261 222 minecraft:stone_bricks
fill 394 261 182 397 261 182 minecraft:mossy_cobblestone
fill 394 261 222 394 264 222 minecraft:mossy_cobblestone
setblock 397 261 183 minecraft:stone_bricks
setblock 398 261 182 minecraft:stone_bricks
fill 398 261 183 398 264 183 minecraft:mossy_cobblestone
setblock 398 261 222 minecraft:stone_bricks
fill 399 261 182 399 264 182 minecraft:mossy_cobblestone
setblock 399 261 221 minecraft:stone_bricks
fill 399 261 222 399 264 222 minecraft:mossy_cobblestone
setblock 400 261 221 minecraft:mossy_cobblestone
setblock 402 261 183 minecraft:stone_bricks
setblock 403 261 182 minecraft:stone_bricks
fill 403 261 183 403 264 183 minecraft:mossy_cobblestone
setblock 403 261 222 minecraft:stone_bricks
fill 404 261 182 407 261 182 minecraft:mossy_cobblestone
fill 404 261 222 404 262 222 minecraft:mossy_cobblestone
setblock 406 261 183 minecraft:mossy_cobblestone
setblock 408 261 182 minecraft:stone_bricks
fill 409 261 182 409 264 182 minecraft:mossy_cobblestone
fill 410 261 183 410 262 183 minecraft:mossy_cobblestone
setblock 412 261 183 minecraft:stone_bricks
setblock 413 261 182 minecraft:stone_bricks
fill 413 261 183 413 264 183 minecraft:mossy_cobblestone
setblock 413 261 222 minecraft:stone_bricks
fill 414 261 182 414 264 182 minecraft:mossy_cobblestone
setblock 414 261 221 minecraft:stone_bricks
fill 414 261 222 414 264 222 minecraft:mossy_cobblestone
setblock 415 261 184 minecraft:mossy_cobblestone
setblock 415 261 185 minecraft:stone_bricks
fill 415 261 221 415 264 221 minecraft:mossy_cobblestone
setblock 416 261 184 minecraft:stone_bricks
fill 416 261 185 416 264 185 minecraft:mossy_cobblestone
setblock 416 261 199 minecraft:stone_bricks
fill 416 261 200 416 262 200 minecraft:mossy_cobblestone
setblock 416 261 219 minecraft:stone_bricks
fill 416 261 220 416 264 220 minecraft:mossy_cobblestone
setblock 417 261 183 minecraft:stone_bricks
fill 417 261 184 417 264 184 minecraft:mossy_cobblestone
setblock 417 261 188 minecraft:stone_bricks
fill 417 261 189 417 264 189 minecraft:mossy_cobblestone
setblock 417 261 193 minecraft:stone_bricks
fill 417 261 194 417 263 194 minecraft:mossy_cobblestone
setblock 417 261 198 minecraft:stone_bricks
fill 417 261 199 417 264 199 minecraft:mossy_cobblestone
setblock 417 261 203 minecraft:stone_bricks
fill 417 261 204 417 264 204 minecraft:mossy_cobblestone
setblock 417 261 208 minecraft:stone_bricks
setblock 417 261 218 minecraft:stone_bricks
fill 417 261 219 417 264 219 minecraft:mossy_cobblestone
setblock 377 262 182 minecraft:stone_bricks
fill 377 262 183 377 265 183 minecraft:mossy_cobblestone
setblock 377 262 187 minecraft:stone_bricks
fill 377 262 188 377 265 188 minecraft:mossy_cobblestone
setblock 377 262 197 minecraft:stone_bricks
fill 377 262 198 377 262 201 minecraft:mossy_cobblestone
setblock 377 262 202 minecraft:stone_bricks
fill 377 262 203 377 262 206 minecraft:mossy_cobblestone
setblock 377 262 207 minecraft:stone_bricks
fill 377 262 208 377 265 208 minecraft:mossy_cobblestone
setblock 377 262 212 minecraft:stone_bricks
fill 377 262 213 377 265 213 minecraft:mossy_cobblestone
setblock 377 262 217 minecraft:stone_bricks
fill 377 262 218 377 265 218 minecraft:mossy_cobblestone
setblock 377 262 222 minecraft:stone_bricks
fill 378 262 182 378 265 182 minecraft:mossy_cobblestone
setblock 378 262 186 minecraft:stone_bricks
setblock 378 262 201 minecraft:stone_bricks
fill 378 262 202 378 265 202 minecraft:mossy_cobblestone
setblock 378 262 205 minecraft:mossy_cobblestone
setblock 378 262 206 minecraft:stone_bricks
fill 378 262 207 378 265 207 minecraft:mossy_cobblestone
setblock 378 262 210 minecraft:mossy_cobblestone
setblock 378 262 216 minecraft:stone_bricks
fill 378 262 217 378 265 217 minecraft:mossy_cobblestone
setblock 378 262 221 minecraft:stone_bricks
fill 378 262 222 378 265 222 minecraft:mossy_cobblestone
setblock 379 262 220 minecraft:stone_bricks
fill 379 262 221 379 265 221 minecraft:mossy_cobblestone
fill 380 262 220 380 263 220 minecraft:mossy_cobblestone
setblock 381 262 183 minecraft:stone_bricks
setblock 382 262 182 minecraft:stone_bricks
fill 382 262 183 382 263 183 minecraft:mossy_cobblestone
setblock 382 262 222 minecraft:stone_bricks
fill 383 262 182 383 265 182 minecraft:mossy_cobblestone
setblock 383 262 221 minecraft:stone_bricks
fill 383 262 222 383 265 222 minecraft:mossy_cobblestone
fill 384 262 221 384 263 221 minecraft:mossy_cobblestone
setblock 387 262 222 minecraft:stone_bricks
fill 388 262 222 391 262 222 minecraft:mossy_cobblestone
setblock 392 262 222 minecraft:stone_bricks
fill 393 262 182 396 262 182 minecraft:mossy_cobblestone
fill 393 262 222 393 263 222 minecraft:mossy_cobblestone
setblock 396 262 183 minecraft:stone_bricks
setblock 397 262 182 minecraft:stone_bricks
fill 397 262 183 397 265 183 minecraft:mossy_cobblestone
setblock 397 262 222 minecraft:stone_bricks
fill 398 262 182 398 265 182 minecraft:mossy_cobblestone
setblock 398 262 221 minecraft:stone_bricks
fill 398 262 222 398 265 222 minecraft:mossy_cobblestone
setblock 399 262 221 minecraft:mossy_cobblestone
setblock 401 262 183 minecraft:stone_bricks
setblock 402 262 182 minecraft:stone_bricks
fill 402 262 183 402 265 183 minecraft:mossy_cobblestone
setblock 402 262 222 minecraft:stone_bricks
fill 403 262 182 406 262 182 minecraft:mossy_cobblestone
setblock 403 262 222 minecraft:mossy_cobblestone
setblock 407 262 182 minecraft:stone_bricks
fill 408 262 182 408 265 182 minecraft:mossy_cobblestone
setblock 411 262 182 minecraft:mossy_cobblestone
setblock 411 262 183 minecraft:stone_bricks
setblock 412 262 182 minecraft:stone_bricks
fill 412 262 183 412 265 183 minecraft:mossy_cobblestone
setblock 412 262 222 minecraft:stone_bricks
fill 413 262 182 413 265 182 minecraft:mossy_cobblestone
fill 413 262 222 413 265 222 minecraft:mossy_cobblestone
setblock 414 262 184 minecraft:mossy_cobblestone
setblock 415 262 184 minecraft:stone_bricks
fill 415 262 185 415 265 185 minecraft:mossy_cobblestone
setblock 416 262 183 minecraft:stone_bricks
fill 416 262 184 416 265 184 minecraft:mossy_cobblestone
setblock 416 262 187 minecraft:mossy_cobblestone
setblock 416 262 188 minecraft:stone_bricks
setblock 416 262 202 minecraft:mossy_cobblestone
setblock 416 262 203 minecraft:stone_bricks
setblock 417 262 182 minecraft:stone_bricks
fill 417 262 183 417 265 183 minecraft:mossy_cobblestone
setblock 417 262 187 minecraft:stone_bricks
fill 417 262 188 417 265 188 minecraft:mossy_cobblestone
setblock 417 262 192 minecraft:stone_bricks
fill 417 262 193 417 263 193 minecraft:mossy_cobblestone
setblock 417 262 197 minecraft:stone_bricks
fill 417 262 198 417 264 198 minecraft:mossy_cobblestone
setblock 417 262 202 minecraft:stone_bricks
fill 417 262 203 417 265 203 minecraft:mossy_cobblestone
setblock 417 262 207 minecraft:stone_bricks
fill 417 262 208 417 265 208 minecraft:mossy_cobblestone
setblock 417 262 217 minecraft:stone_bricks
fill 417 262 218 417 265 218 minecraft:mossy_cobblestone
setblock 417 262 222 minecraft:stone_bricks
fill 377 263 182 377 266 182 minecraft:mossy_cobblestone
setblock 377 263 186 minecraft:stone_bricks
fill 377 263 187 377 266 187 minecraft:mossy_cobblestone
fill 377 263 198 377 263 200 minecraft:mossy_cobblestone
setblock 377 263 201 minecraft:stone_bricks
fill 377 263 202 377 263 205 minecraft:mossy_cobblestone
setblock 377 263 206 minecraft:stone_bricks
fill 377 263 207 377 266 207 minecraft:mossy_cobblestone
setblock 377 263 211 minecraft:stone_bricks
fill 377 263 212 377 266 212 minecraft:mossy_cobblestone
setblock 377 263 216 minecraft:stone_bricks
fill 377 263 217 377 266 217 minecraft:mossy_cobblestone
setblock 377 263 221 minecraft:stone_bricks
fill 377 263 222 377 266 222 minecraft:mossy_cobblestone
setblock 378 263 185 minecraft:stone_bricks
fill 378 263 186 378 266 186 minecraft:mossy_cobblestone
fill 378 263 201 378 264 201 minecraft:mossy_cobblestone
setblock 378 263 205 minecraft:stone_bricks
fill 378 263 206 378 266 206 minecraft:mossy_cobblestone
setblock 378 263 210 minecraft:stone_bricks
fill 378 263 211 378 266 211 minecraft:mossy_cobblestone
setblock 378 263 215 minecraft:stone_bricks
fill 378 263 216 378 266 216 minecraft:mossy_cobblestone
setblock 378 263 220 minecraft:stone_bricks
fill 378 263 221 378 266 221 minecraft:mossy_cobblestone
setblock 379 263 219 minecraft:stone_bricks
fill 379 263 220 379 264 220 minecraft:mossy_cobblestone
setblock 380 263 183 minecraft:stone_bricks
setblock 381 263 182 minecraft:stone_bricks
fill 381 263 183 381 265 183 minecraft:mossy_cobblestone
setblock 381 263 222 minecraft:stone_bricks
fill 382 263 182 382 266 182 minecraft:mossy_cobblestone
setblock 382 263 221 minecraft:stone_bricks
fill 382 263 222 382 266 222 minecraft:mossy_cobblestone
setblock 383 263 221 minecraft:mossy_cobblestone
setblock 386 263 222 minecraft:stone_bricks
setblock 387 263 222 minecraft:mossy_cobblestone
fill 393 263 182 395 263 182 minecraft:mossy_cobblestone
setblock 396 263 182 minecraft:stone_bricks
fill 396 263 183 396 266 183 minecraft:mossy_cobblestone
setblock 396 263 222 minecraft:stone_bricks
fill 397 263 182 397 266 182 minecraft:mossy_cobblestone
fill 397 263 222 397 266 222 minecraft:mossy_cobblestone
setblock 400 263 183 minecraft:stone_bricks
setblock 401 263 182 minecraft:stone_bricks
fill 401 263 183 401 266 183 minecraft:mossy_cobblestone
setblock 401 263 222 minecraft:stone_bricks
fill 402 263 182 405 263 182 minecraft:mossy_cobblestone
setblock 402 263 222 minecraft:mossy_cobblestone
setblock 406 263 182 minecraft:stone_bricks
fill 407 263 182 407 266 182 minecraft:mossy_cobblestone
setblock 410 263 183 minecraft:stone_bricks
setblock 411 263 182 minecraft:stone_bricks
fill 411 263 183 411 266 183 minecraft:mossy_cobblestone
fill 412 263 182 412 266 182 minecraft:mossy_cobblestone
fill 412 263 222 412 266 222 minecraft:mossy_cobblestone
setblock 414 263 184 minecraft:stone_bricks
setblock 415 263 183 minecraft:stone_bricks
fill 415 263 184 415 266 184 minecraft:mossy_cobblestone
fill 415 263 186 415 264 186 minecraft:mossy_cobblestone
setblock 416 263 182 minecraft:stone_bricks
fill 416 263 183 416 266 183 minecraft:mossy_cobblestone
setblock 416 263 187 minecraft:stone_bricks
fill 416 263 188 416 265 189 minecraft:mossy_cobblestone
setblock 416 263 203 minecraft:mossy_cobblestone
setblock 416 263 222 minecraft:stone_bricks
fill 417 263 182 417 266 182 minecraft:mossy_cobblestone
setblock 417 263 186 minecraft:stone_bricks
fill 417 263 187 417 266 187 minecraft:mossy_cobblestone
setblock 417 263 191 minecraft:stone_bricks
fill 417 263 192 417 266 192 minecraft:mossy_cobblestone
setblock 417 263 196 minecraft:stone_bricks
setblock 417 263 197 minecraft:mossy_cobblestone
setblock 417 263 201 minecraft:stone_bricks
fill 417 263 202 417 266 202 minecraft:mossy_cobblestone
setblock 417 263 206 minecraft:stone_bricks
fill 417 263 207 417 266 207 minecraft:mossy_cobblestone
fill 417 263 209 417 264 209 minecraft:mossy_cobblestone
fill 417 263 217 417 266 217 minecraft:mossy_cobblestone
setblock 417 263 221 minecraft:stone_bricks
fill 417 263 222 417 266 222 minecraft:mossy_cobblestone
setblock 377 264 185 minecraft:stone_bricks
fill 377 264 186 377 267 186 minecraft:mossy_cobblestone
setblock 377 264 199 minecraft:mossy_cobblestone
setblock 377 264 200 minecraft:stone_bricks
fill 377 264 201 377 264 204 minecraft:mossy_cobblestone
setblock 377 264 205 minecraft:stone_bricks
fill 377 264 206 377 267 206 minecraft:mossy_cobblestone
setblock 377 264 209 minecraft:mossy_cobblestone
setblock 377 264 210 minecraft:stone_bricks
fill 377 264 211 377 267 211 minecraft:mossy_cobblestone
setblock 377 264 215 minecraft:stone_bricks
fill 377 264 216 377 267 216 minecraft:mossy_cobblestone
setblock 377 264 220 minecraft:stone_bricks
fill 377 264 221 377 267 221 minecraft:mossy_cobblestone
setblock 378 264 184 minecraft:stone_bricks
fill 378 264 185 378 267 185 minecraft:mossy_cobblestone
setblock 378 264 204 minecraft:stone_bricks
fill 378 264 205 378 267 205 minecraft:mossy_cobblestone
setblock 378 264 209 minecraft:stone_bricks
fill 378 264 210 378 267 210 minecraft:mossy_cobblestone
fill 378 264 212 378 265 212 minecraft:mossy_cobblestone
setblock 378 264 219 minecraft:stone_bricks
fill 378 264 220 378 267 220 minecraft:mossy_cobblestone
setblock 379 264 183 minecraft:stone_bricks
setblock 380 264 182 minecraft:stone_bricks
fill 380 264 183 380 267 183 minecraft:mossy_cobblestone
setblock 380 264 222 minecraft:stone_bricks
fill 381 264 182 381 267 182 minecraft:mossy_cobblestone
setblock 381 264 221 minecraft:stone_bricks
fill 381 264 222 381 267 222 minecraft:mossy_cobblestone
setblock 382 264 221 minecraft:mossy_cobblestone
setblock 385 264 222 minecraft:stone_bricks
fill 393 264 182 394 264 182 minecraft:mossy_cobblestone
setblock 395 264 182 minecraft:stone_bricks
setblock 395 264 222 minecraft:stone_bricks
fill 396 264 182 396 267 182 minecraft:mossy_cobblestone
fill 396 264 222 396 267 222 minecraft:mossy_cobblestone
setblock 399 264 183 minecraft:stone_bricks
setblock 400 264 182 minecraft:stone_bricks
fill 400 264 183 400 267 183 minecraft:mossy_cobblestone
setblock 400 264 222 minecraft:stone_bricks
fill 401 264 182 404 264 182 minecraft:mossy_cobblestone
setblock 401 264 222 minecraft:mossy_cobblestone
setblock 404 264 183 minecraft:stone_bricks
setblock 405 264 182 minecraft:stone_bricks
fill 406 264 182 406 267 182 minecraft:mossy_cobblestone
setblock 410 264 182 minecraft:stone_bricks
fill 410 264 183 410 267 183 minecraft:mossy_cobblestone
fill 411 264 182 411 267 182 minecraft:mossy_cobblestone
setblock 413 264 184 minecraft:stone_bricks
setblock 414 264 183 minecraft:stone_bricks
fill 414 264 184 414 267 184 minecraft:mossy_cobblestone
setblock 415 264 182 minecraft:stone_bricks
fill 415 264 183 415 267 183 minecraft:mossy_cobblestone
setblock 415 264 222 minecraft:stone_bricks
fill 416 264 182 416 267 182 minecraft:mossy_cobblestone
setblock 416 264 186 minecraft:stone_bricks
fill 416 264 187 416 267 187 minecraft:mossy_cobblestone
setblock 416 264 221 minecraft:stone_bricks
fill 416 264 222 416 267 222 minecraft:mossy_cobblestone
setblock 417 264 185 minecraft:stone_bricks
fill 417 264 186 417 267 186 minecraft:mossy_cobblestone
setblock 417 264 190 minecraft:stone_bricks
fill 417 264 191 417 267 191 minecraft:mossy_cobblestone
setblock 417 264 200 minecraft:stone_bricks
fill 417 264 201 417 267 201 minecraft:mossy_cobblestone
setblock 417 264 205 minecraft:stone_bricks
fill 417 264 206 417 267 206 minecraft:mossy_cobblestone
setblock 417 264 210 minecraft:stone_bricks
setblock 417 264 220 minecraft:stone_bricks
fill 417 264 221 417 267 221 minecraft:mossy_cobblestone
setblock 377 265 184 minecraft:stone_bricks
fill 377 265 185 377 268 185 minecraft:mossy_cobblestone
setblock 377 265 189 minecraft:stone_bricks
setblock 377 265 199 minecraft:stone_bricks
fill 377 265 200 377 265 203 minecraft:mossy_cobblestone
setblock 377 265 204 minecraft:stone_bricks
fill 377 265 205 377 268 205 minecraft:mossy_cobblestone
setblock 377 265 209 minecraft:stone_bricks
fill 377 265 210 377 268 210 minecraft:mossy_cobblestone
setblock 377 265 214 minecraft:stone_bricks
fill 377 265 215 378 267 215 minecraft:mossy_cobblestone
setblock 377 265 219 minecraft:stone_bricks
fill 377 265 220 377 268 220 minecraft:mossy_cobblestone
setblock 378 265 183 minecraft:stone_bricks
fill 378 265 184 378 268 184 minecraft:mossy_cobblestone
setblock 378 265 187 minecraft:mossy_cobblestone
setblock 378 265 203 minecraft:stone_bricks
fill 378 265 204 378 268 204 minecraft:mossy_cobblestone
setblock 378 265 208 minecraft:stone_bricks
fill 378 265 209 378 268 209 minecraft:mossy_cobblestone
setblock 378 265 213 minecraft:stone_bricks
fill 378 265 214 378 268 214 minecraft:mossy_cobblestone
setblock 378 265 218 minecraft:stone_bricks
fill 378 265 219 378 268 219 minecraft:mossy_cobblestone
setblock 379 265 182 minecraft:stone_bricks
fill 379 265 183 379 268 183 minecraft:mossy_cobblestone
setblock 379 265 184 minecraft:light[level=12]
setblock 379 265 192 minecraft:light[level=12]
setblock 379 265 200 minecraft:light[level=12]
setblock 379 265 206 minecraft:mossy_cobblestone
setblock 379 265 207 minecraft:stone_bricks
setblock 379 265 208 minecraft:light[level=12]
setblock 379 265 216 minecraft:light[level=12]
setblock 379 265 222 minecraft:stone_bricks
fill 380 265 182 380 268 182 minecraft:mossy_cobblestone
setblock 380 265 221 minecraft:stone_bricks
schedule function dropper:buildpart/44_11 1t
