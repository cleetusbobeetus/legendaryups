setblock 501 109 299 minecraft:light[level=12]
setblock 501 109 306 minecraft:light[level=12]
setblock 501 109 313 minecraft:light[level=12]
setblock 505 109 278 minecraft:light[level=13]
setblock 505 109 286 minecraft:light[level=13]
fill 505 109 290 505 119 290 minecraft:black_concrete
setblock 505 109 294 minecraft:light[level=13]
setblock 505 109 302 minecraft:light[level=13]
setblock 505 109 310 minecraft:light[level=13]
fill 507 109 292 508 110 292 minecraft:white_wool
setblock 508 109 278 minecraft:light[level=12]
setblock 508 109 285 minecraft:light[level=12]
setblock 508 109 299 minecraft:light[level=12]
setblock 508 109 306 minecraft:light[level=12]
setblock 508 109 313 minecraft:light[level=12]
fill 510 109 316 510 112 316 minecraft:deepslate_tiles
setblock 511 109 284 minecraft:cobbled_deepslate
fill 511 109 285 511 110 285 minecraft:deepslate_tiles
setblock 511 109 289 minecraft:cobbled_deepslate
fill 511 109 290 511 112 290 minecraft:deepslate_tiles
setblock 511 109 309 minecraft:cobbled_deepslate
fill 511 109 310 511 112 310 minecraft:deepslate_tiles
setblock 511 109 313 minecraft:deepslate_tiles
setblock 511 109 314 minecraft:cobbled_deepslate
fill 511 109 315 511 112 315 minecraft:deepslate_tiles
fill 471 110 283 471 112 283 minecraft:cobbled_deepslate
fill 471 110 285 471 112 285 minecraft:cobbled_deepslate
fill 471 110 304 471 113 304 minecraft:deepslate_tiles
setblock 471 110 308 minecraft:cobbled_deepslate
fill 471 110 309 471 113 309 minecraft:deepslate_tiles
setblock 471 110 313 minecraft:cobbled_deepslate
fill 471 110 314 471 113 314 minecraft:deepslate_tiles
setblock 472 110 307 minecraft:cobbled_deepslate
fill 472 110 308 472 113 308 minecraft:deepslate_tiles
setblock 472 110 312 minecraft:cobbled_deepslate
fill 472 110 313 472 113 313 minecraft:deepslate_tiles
fill 473 110 283 473 112 283 minecraft:cobbled_deepslate
fill 473 110 285 473 112 285 minecraft:cobbled_deepslate
fill 473 110 307 473 111 307 minecraft:deepslate_tiles
setblock 473 110 310 minecraft:deepslate_tiles
setblock 473 110 311 minecraft:cobbled_deepslate
fill 473 110 312 473 113 312 minecraft:deepslate_tiles
fill 473 110 314 473 111 314 minecraft:deepslate_tiles
setblock 473 110 316 minecraft:cobbled_deepslate
setblock 474 110 310 minecraft:cobbled_deepslate
fill 474 110 311 474 113 311 minecraft:deepslate_tiles
setblock 474 110 315 minecraft:cobbled_deepslate
fill 474 110 316 474 113 316 minecraft:deepslate_tiles
setblock 475 110 314 minecraft:cobbled_deepslate
fill 475 110 315 475 113 315 minecraft:deepslate_tiles
fill 476 110 314 476 113 314 minecraft:deepslate_tiles
setblock 478 110 316 minecraft:cobbled_deepslate
setblock 479 110 315 minecraft:cobbled_deepslate
fill 479 110 316 479 113 316 minecraft:deepslate_tiles
fill 480 110 315 480 111 315 minecraft:deepslate_tiles
fill 495 110 276 495 112 276 minecraft:deepslate_tiles
fill 495 110 316 495 112 316 minecraft:deepslate_tiles
setblock 498 110 276 minecraft:cobbled_deepslate
fill 498 110 314 498 120 314 minecraft:black_concrete
setblock 498 110 316 minecraft:cobbled_deepslate
fill 499 110 276 499 113 276 minecraft:deepslate_tiles
fill 499 110 316 499 113 316 minecraft:deepslate_tiles
setblock 511 110 288 minecraft:cobbled_deepslate
fill 511 110 289 511 113 289 minecraft:deepslate_tiles
setblock 511 110 308 minecraft:cobbled_deepslate
fill 511 110 309 511 113 309 minecraft:deepslate_tiles
setblock 511 110 313 minecraft:cobbled_deepslate
fill 511 110 314 511 113 314 minecraft:deepslate_tiles
fill 470 111 308 470 127 315 minecraft:black_concrete
setblock 470 111 316 minecraft:redstone_block
fill 471 111 290 471 111 291 minecraft:deepslate_tiles
setblock 471 111 307 minecraft:cobbled_deepslate
fill 471 111 308 471 114 308 minecraft:deepslate_tiles
setblock 471 111 312 minecraft:cobbled_deepslate
fill 471 111 313 471 114 313 minecraft:deepslate_tiles
setblock 472 111 306 minecraft:cobbled_deepslate
fill 472 111 307 472 114 307 minecraft:deepslate_tiles
setblock 472 111 311 minecraft:cobbled_deepslate
fill 472 111 312 472 114 312 minecraft:deepslate_tiles
setblock 472 111 316 minecraft:cobbled_deepslate
setblock 473 111 310 minecraft:cobbled_deepslate
fill 473 111 311 473 114 311 minecraft:deepslate_tiles
setblock 473 111 315 minecraft:cobbled_deepslate
fill 473 111 316 473 114 316 minecraft:deepslate_tiles
setblock 474 111 314 minecraft:cobbled_deepslate
fill 474 111 315 474 114 315 minecraft:deepslate_tiles
fill 475 111 314 475 114 314 minecraft:deepslate_tiles
setblock 477 111 316 minecraft:cobbled_deepslate
setblock 478 111 315 minecraft:cobbled_deepslate
fill 478 111 316 478 114 316 minecraft:deepslate_tiles
fill 479 111 315 479 114 315 minecraft:deepslate_tiles
fill 494 111 276 494 113 276 minecraft:deepslate_tiles
fill 494 111 316 494 113 316 minecraft:deepslate_tiles
setblock 497 111 276 minecraft:cobbled_deepslate
setblock 497 111 316 minecraft:cobbled_deepslate
fill 498 111 276 498 114 276 minecraft:deepslate_tiles
fill 498 111 316 498 114 316 minecraft:deepslate_tiles
setblock 498 111 317 minecraft:redstone_block
setblock 502 111 276 minecraft:cobbled_deepslate
setblock 502 111 316 minecraft:cobbled_deepslate
fill 504 111 290 504 119 290 minecraft:black_concrete
fill 505 111 289 505 119 289 minecraft:black_concrete
fill 505 111 291 505 119 291 minecraft:black_concrete
fill 506 111 290 506 119 290 minecraft:black_concrete
fill 509 111 316 509 113 316 minecraft:deepslate_tiles
setblock 510 111 312 minecraft:deepslate_tiles
setblock 510 111 313 minecraft:cobbled_deepslate
setblock 511 111 287 minecraft:cobbled_deepslate
fill 511 111 288 511 114 288 minecraft:deepslate_tiles
setblock 511 111 307 minecraft:cobbled_deepslate
fill 511 111 308 511 114 308 minecraft:deepslate_tiles
setblock 511 111 312 minecraft:cobbled_deepslate
fill 511 111 313 511 114 313 minecraft:deepslate_tiles
fill 470 112 316 470 178 316 minecraft:black_concrete
fill 471 112 289 471 112 290 minecraft:deepslate_tiles
setblock 471 112 291 minecraft:cobbled_deepslate
fill 471 112 292 471 113 294 minecraft:deepslate_tiles
setblock 471 112 306 minecraft:cobbled_deepslate
fill 471 112 307 471 115 307 minecraft:deepslate_tiles
setblock 471 112 311 minecraft:cobbled_deepslate
fill 471 112 312 471 115 312 minecraft:deepslate_tiles
setblock 471 112 316 minecraft:cobbled_deepslate
setblock 472 112 282 minecraft:cobbled_deepslate
setblock 472 112 286 minecraft:cobbled_deepslate
fill 472 112 306 472 115 306 minecraft:deepslate_tiles
setblock 472 112 310 minecraft:cobbled_deepslate
fill 472 112 311 472 115 311 minecraft:deepslate_tiles
setblock 472 112 315 minecraft:cobbled_deepslate
fill 472 112 316 472 115 316 minecraft:deepslate_tiles
setblock 473 112 309 minecraft:cobbled_deepslate
fill 473 112 310 473 115 310 minecraft:deepslate_tiles
setblock 473 112 314 minecraft:cobbled_deepslate
fill 473 112 315 473 115 315 minecraft:deepslate_tiles
setblock 474 112 284 minecraft:cobbled_deepslate
setblock 474 112 312 minecraft:deepslate_tiles
fill 474 112 314 474 115 314 minecraft:deepslate_tiles
setblock 476 112 316 minecraft:cobbled_deepslate
setblock 477 112 315 minecraft:cobbled_deepslate
fill 477 112 316 477 115 316 minecraft:deepslate_tiles
setblock 478 112 314 minecraft:cobbled_deepslate
fill 478 112 315 478 115 315 minecraft:deepslate_tiles
setblock 481 112 316 minecraft:cobbled_deepslate
setblock 483 112 317 minecraft:white_wool
fill 484 112 317 484 201 317 minecraft:black_concrete
fill 493 112 276 493 114 276 minecraft:deepslate_tiles
fill 493 112 316 493 114 316 minecraft:deepslate_tiles
setblock 496 112 276 minecraft:cobbled_deepslate
setblock 496 112 315 minecraft:deepslate_tiles
setblock 496 112 316 minecraft:cobbled_deepslate
fill 497 112 276 497 115 276 minecraft:deepslate_tiles
setblock 497 112 315 minecraft:cobbled_deepslate
fill 497 112 316 497 115 316 minecraft:deepslate_tiles
fill 498 112 315 498 115 315 minecraft:deepslate_tiles
fill 498 112 317 498 197 317 minecraft:black_concrete
setblock 501 112 276 minecraft:cobbled_deepslate
setblock 501 112 316 minecraft:cobbled_deepslate
fill 502 112 276 502 115 276 minecraft:deepslate_tiles
fill 502 112 316 503 114 316 minecraft:deepslate_tiles
fill 504 112 289 504 119 289 minecraft:black_concrete
fill 504 112 291 504 119 291 minecraft:black_concrete
fill 506 112 289 506 119 289 minecraft:black_concrete
fill 506 112 291 506 121 291 minecraft:black_concrete
fill 507 112 316 508 114 316 minecraft:deepslate_tiles
fill 508 112 291 508 120 291 minecraft:black_concrete
setblock 510 112 276 minecraft:deepslate_tiles
setblock 510 112 311 minecraft:deepslate_tiles
setblock 510 112 312 minecraft:cobbled_deepslate
fill 510 112 313 510 113 315 minecraft:deepslate_tiles
setblock 511 112 276 minecraft:cobbled_deepslate
setblock 511 112 287 minecraft:deepslate_tiles
setblock 511 112 291 minecraft:cobbled_deepslate
fill 511 112 307 511 115 307 minecraft:deepslate_tiles
setblock 511 112 311 minecraft:cobbled_deepslate
fill 511 112 312 511 115 312 minecraft:deepslate_tiles
setblock 511 112 316 minecraft:cobbled_deepslate
fill 471 113 288 471 113 289 minecraft:deepslate_tiles
setblock 471 113 290 minecraft:cobbled_deepslate
fill 471 113 291 472 115 291 minecraft:deepslate_tiles
setblock 471 113 295 minecraft:cobbled_deepslate
fill 471 113 296 471 115 297 minecraft:deepslate_tiles
fill 471 113 303 471 114 303 minecraft:deepslate_tiles
setblock 471 113 305 minecraft:cobbled_deepslate
fill 471 113 306 471 116 306 minecraft:deepslate_tiles
setblock 471 113 310 minecraft:cobbled_deepslate
fill 471 113 311 471 116 311 minecraft:deepslate_tiles
setblock 471 113 315 minecraft:cobbled_deepslate
fill 471 113 316 471 116 316 minecraft:deepslate_tiles
fill 472 113 278 472 116 278 minecraft:black_concrete
fill 472 113 292 472 113 293 minecraft:deepslate_tiles
setblock 472 113 294 minecraft:cobbled_deepslate
setblock 472 113 309 minecraft:cobbled_deepslate
fill 472 113 310 472 116 310 minecraft:deepslate_tiles
setblock 472 113 314 minecraft:cobbled_deepslate
fill 472 113 315 472 116 315 minecraft:deepslate_tiles
fill 473 113 276 474 113 276 minecraft:deepslate_tiles
setblock 473 113 308 minecraft:cobbled_deepslate
fill 473 113 309 473 116 309 minecraft:deepslate_tiles
setblock 473 113 313 minecraft:cobbled_deepslate
fill 473 113 314 473 116 314 minecraft:deepslate_tiles
setblock 474 113 312 minecraft:cobbled_deepslate
fill 474 113 313 475 115 313 minecraft:deepslate_tiles
setblock 475 113 276 minecraft:cobbled_deepslate
setblock 475 113 316 minecraft:cobbled_deepslate
setblock 476 113 315 minecraft:cobbled_deepslate
fill 476 113 316 476 116 316 minecraft:deepslate_tiles
setblock 477 113 314 minecraft:cobbled_deepslate
fill 477 113 315 477 116 315 minecraft:deepslate_tiles
fill 478 113 314 478 115 314 minecraft:deepslate_tiles
setblock 480 113 316 minecraft:cobbled_deepslate
fill 481 113 316 481 116 316 minecraft:deepslate_tiles
fill 483 113 317 483 126 317 minecraft:black_concrete
fill 487 113 275 487 201 275 minecraft:black_concrete
setblock 488 113 275 minecraft:white_wool
fill 492 113 276 492 115 276 minecraft:deepslate_tiles
fill 492 113 316 492 115 316 minecraft:deepslate_tiles
fill 494 113 315 495 113 315 minecraft:deepslate_tiles
setblock 495 113 276 minecraft:cobbled_deepslate
fill 495 113 277 498 113 277 minecraft:deepslate_tiles
setblock 495 113 316 minecraft:cobbled_deepslate
fill 496 113 276 496 116 276 minecraft:deepslate_tiles
setblock 496 113 315 minecraft:cobbled_deepslate
fill 496 113 316 496 116 316 minecraft:deepslate_tiles
fill 497 113 315 497 116 315 minecraft:deepslate_tiles
fill 499 113 315 499 114 315 minecraft:deepslate_tiles
setblock 500 113 276 minecraft:cobbled_deepslate
setblock 500 113 316 minecraft:cobbled_deepslate
fill 501 113 276 501 116 276 minecraft:deepslate_tiles
fill 501 113 316 501 116 316 minecraft:deepslate_tiles
fill 503 113 276 503 114 276 minecraft:deepslate_tiles
fill 503 113 289 503 119 291 minecraft:black_concrete
fill 504 113 292 505 119 292 minecraft:black_concrete
setblock 504 113 316 minecraft:deepslate_tiles
fill 505 113 288 505 119 288 minecraft:black_concrete
setblock 505 113 316 minecraft:cobbled_deepslate
fill 506 113 316 506 116 316 minecraft:deepslate_tiles
setblock 509 113 276 minecraft:deepslate_tiles
fill 509 113 315 509 114 315 minecraft:deepslate_tiles
setblock 510 113 276 minecraft:cobbled_deepslate
setblock 510 113 310 minecraft:deepslate_tiles
setblock 510 113 311 minecraft:cobbled_deepslate
fill 510 113 312 510 116 312 minecraft:deepslate_tiles
setblock 510 113 316 minecraft:cobbled_deepslate
fill 511 113 276 511 115 277 minecraft:deepslate_tiles
setblock 511 113 290 minecraft:cobbled_deepslate
fill 511 113 291 511 114 293 minecraft:deepslate_tiles
setblock 511 113 310 minecraft:cobbled_deepslate
fill 511 113 311 511 116 311 minecraft:deepslate_tiles
setblock 511 113 315 minecraft:cobbled_deepslate
fill 511 113 316 511 116 316 minecraft:deepslate_tiles
fill 471 114 276 473 114 276 minecraft:deepslate_tiles
setblock 471 114 288 minecraft:deepslate_tiles
setblock 471 114 289 minecraft:cobbled_deepslate
fill 471 114 290 472 116 290 minecraft:deepslate_tiles
fill 471 114 292 471 114 293 minecraft:deepslate_tiles
setblock 471 114 294 minecraft:cobbled_deepslate
fill 471 114 295 472 116 295 minecraft:deepslate_tiles
setblock 471 114 298 minecraft:deepslate_tiles
setblock 471 114 299 minecraft:cobbled_deepslate
fill 471 114 300 471 115 302 minecraft:deepslate_tiles
setblock 471 114 304 minecraft:cobbled_deepslate
fill 471 114 305 472 116 305 minecraft:deepslate_tiles
setblock 471 114 309 minecraft:cobbled_deepslate
fill 471 114 310 471 117 310 minecraft:deepslate_tiles
setblock 471 114 314 minecraft:cobbled_deepslate
fill 471 114 315 471 117 315 minecraft:deepslate_tiles
setblock 472 114 292 minecraft:deepslate_tiles
setblock 472 114 293 minecraft:cobbled_deepslate
fill 472 114 294 472 117 294 minecraft:deepslate_tiles
fill 472 114 296 472 114 297 minecraft:deepslate_tiles
setblock 472 114 298 minecraft:cobbled_deepslate
setblock 472 114 308 minecraft:cobbled_deepslate
fill 472 114 309 472 117 309 minecraft:deepslate_tiles
setblock 472 114 313 minecraft:cobbled_deepslate
fill 472 114 314 472 117 314 minecraft:deepslate_tiles
setblock 473 114 307 minecraft:cobbled_deepslate
fill 473 114 308 473 117 308 minecraft:deepslate_tiles
setblock 473 114 312 minecraft:cobbled_deepslate
fill 473 114 313 473 117 313 minecraft:deepslate_tiles
setblock 474 114 276 minecraft:cobbled_deepslate
setblock 474 114 311 minecraft:cobbled_deepslate
fill 474 114 312 474 117 312 minecraft:deepslate_tiles
setblock 474 114 316 minecraft:cobbled_deepslate
fill 475 114 276 477 115 276 minecraft:deepslate_tiles
setblock 475 114 315 minecraft:cobbled_deepslate
fill 475 114 316 475 117 316 minecraft:deepslate_tiles
setblock 476 114 314 minecraft:cobbled_deepslate
fill 476 114 315 476 117 315 minecraft:deepslate_tiles
fill 477 114 314 477 117 314 minecraft:deepslate_tiles
setblock 479 114 316 minecraft:cobbled_deepslate
fill 480 114 316 480 117 316 minecraft:deepslate_tiles
fill 488 114 275 488 165 275 minecraft:black_concrete
fill 490 114 316 491 116 316 minecraft:deepslate_tiles
fill 491 114 276 491 116 276 minecraft:deepslate_tiles
setblock 493 114 277 minecraft:cobbled_deepslate
fill 493 114 315 494 114 315 minecraft:deepslate_tiles
setblock 494 114 276 minecraft:cobbled_deepslate
fill 494 114 277 497 114 277 minecraft:deepslate_tiles
setblock 494 114 316 minecraft:cobbled_deepslate
fill 495 114 276 495 117 276 minecraft:deepslate_tiles
setblock 495 114 315 minecraft:cobbled_deepslate
fill 495 114 316 495 117 316 minecraft:deepslate_tiles
fill 496 114 315 496 117 315 minecraft:deepslate_tiles
setblock 498 114 277 minecraft:cobbled_deepslate
setblock 499 114 276 minecraft:cobbled_deepslate
fill 499 114 277 499 117 277 minecraft:deepslate_tiles
setblock 499 114 316 minecraft:cobbled_deepslate
fill 500 114 276 500 117 276 minecraft:deepslate_tiles
setblock 500 114 315 minecraft:cobbled_deepslate
fill 500 114 316 500 117 316 minecraft:deepslate_tiles
fill 503 114 292 503 119 292 minecraft:black_concrete
setblock 504 114 276 minecraft:cobbled_deepslate
fill 504 114 288 504 119 288 minecraft:black_concrete
setblock 504 114 316 minecraft:cobbled_deepslate
fill 505 114 276 508 114 276 minecraft:deepslate_tiles
fill 505 114 316 505 117 316 minecraft:deepslate_tiles
fill 506 114 288 506 119 288 minecraft:black_concrete
fill 506 114 292 506 121 292 minecraft:black_concrete
fill 507 114 289 507 119 291 minecraft:black_concrete
fill 507 114 315 508 115 315 minecraft:deepslate_tiles
setblock 509 114 276 minecraft:cobbled_deepslate
setblock 509 114 316 minecraft:cobbled_deepslate
fill 510 114 276 510 117 276 minecraft:deepslate_tiles
setblock 510 114 310 minecraft:cobbled_deepslate
fill 510 114 311 510 117 311 minecraft:deepslate_tiles
fill 510 114 313 510 114 314 minecraft:deepslate_tiles
setblock 510 114 315 minecraft:cobbled_deepslate
fill 510 114 316 510 117 316 minecraft:deepslate_tiles
setblock 511 114 278 minecraft:deepslate_tiles
setblock 511 114 279 minecraft:cobbled_deepslate
fill 511 114 287 511 115 287 minecraft:deepslate_tiles
setblock 511 114 289 minecraft:cobbled_deepslate
fill 511 114 290 511 117 290 minecraft:deepslate_tiles
setblock 511 114 294 minecraft:cobbled_deepslate
fill 511 114 295 511 117 295 minecraft:deepslate_tiles
fill 511 114 306 511 116 306 minecraft:deepslate_tiles
setblock 511 114 309 minecraft:cobbled_deepslate
fill 511 114 310 511 117 310 minecraft:deepslate_tiles
setblock 511 114 314 minecraft:cobbled_deepslate
fill 511 114 315 511 117 315 minecraft:deepslate_tiles
fill 471 115 276 471 115 277 minecraft:deepslate_tiles
setblock 471 115 287 minecraft:deepslate_tiles
setblock 471 115 288 minecraft:cobbled_deepslate
fill 471 115 289 472 117 289 minecraft:deepslate_tiles
setblock 471 115 292 minecraft:deepslate_tiles
setblock 471 115 293 minecraft:cobbled_deepslate
fill 471 115 294 471 118 294 minecraft:deepslate_tiles
setblock 471 115 298 minecraft:cobbled_deepslate
fill 471 115 299 472 117 299 minecraft:deepslate_tiles
setblock 471 115 303 minecraft:cobbled_deepslate
fill 471 115 304 472 117 304 minecraft:deepslate_tiles
setblock 471 115 308 minecraft:cobbled_deepslate
fill 471 115 309 471 118 309 minecraft:deepslate_tiles
setblock 471 115 313 minecraft:cobbled_deepslate
fill 471 115 314 471 118 314 minecraft:deepslate_tiles
setblock 472 115 276 minecraft:deepslate_tiles
setblock 472 115 292 minecraft:cobbled_deepslate
fill 472 115 293 473 117 293 minecraft:deepslate_tiles
setblock 472 115 296 minecraft:deepslate_tiles
setblock 472 115 297 minecraft:cobbled_deepslate
fill 472 115 298 473 117 298 minecraft:deepslate_tiles
fill 472 115 300 472 115 301 minecraft:deepslate_tiles
setblock 472 115 302 minecraft:cobbled_deepslate
fill 472 115 303 472 118 303 minecraft:deepslate_tiles
setblock 472 115 307 minecraft:cobbled_deepslate
fill 472 115 308 472 118 308 minecraft:deepslate_tiles
setblock 472 115 312 minecraft:cobbled_deepslate
fill 472 115 313 472 118 313 minecraft:deepslate_tiles
setblock 473 115 276 minecraft:cobbled_deepslate
setblock 473 115 278 minecraft:light[level=12]
setblock 473 115 285 minecraft:light[level=12]
setblock 473 115 291 minecraft:cobbled_deepslate
fill 473 115 292 473 118 292 minecraft:deepslate_tiles
fill 473 115 294 473 115 295 minecraft:deepslate_tiles
setblock 473 115 296 minecraft:cobbled_deepslate
fill 473 115 297 473 118 297 minecraft:deepslate_tiles
setblock 473 115 299 minecraft:light[level=12]
setblock 473 115 306 minecraft:light[level=12]
fill 473 115 307 473 118 307 minecraft:deepslate_tiles
setblock 473 115 311 minecraft:cobbled_deepslate
fill 473 115 312 473 118 312 minecraft:deepslate_tiles
setblock 473 115 316 minecraft:cobbled_deepslate
fill 474 115 276 474 118 276 minecraft:deepslate_tiles
fill 474 115 311 474 116 311 minecraft:deepslate_tiles
setblock 474 115 315 minecraft:cobbled_deepslate
fill 474 115 316 474 118 316 minecraft:deepslate_tiles
setblock 475 115 314 minecraft:cobbled_deepslate
fill 475 115 315 475 118 315 minecraft:deepslate_tiles
fill 476 115 314 476 118 314 minecraft:deepslate_tiles
setblock 478 115 316 minecraft:cobbled_deepslate
setblock 479 115 315 minecraft:cobbled_deepslate
fill 479 115 316 479 118 316 minecraft:deepslate_tiles
setblock 480 115 278 minecraft:light[level=12]
setblock 480 115 285 minecraft:light[level=12]
setblock 480 115 292 minecraft:light[level=12]
setblock 480 115 299 minecraft:light[level=12]
setblock 480 115 306 minecraft:light[level=12]
setblock 480 115 313 minecraft:light[level=12]
setblock 487 115 278 minecraft:light[level=12]
setblock 487 115 285 minecraft:light[level=12]
setblock 487 115 292 minecraft:light[level=12]
setblock 487 115 299 minecraft:light[level=12]
setblock 487 115 306 minecraft:light[level=12]
setblock 487 115 313 minecraft:light[level=12]
fill 489 115 276 490 117 276 minecraft:deepslate_tiles
fill 489 115 316 489 118 316 minecraft:deepslate_tiles
fill 491 115 315 493 115 315 minecraft:deepslate_tiles
setblock 492 115 277 minecraft:cobbled_deepslate
setblock 493 115 276 minecraft:cobbled_deepslate
fill 493 115 277 496 115 277 minecraft:deepslate_tiles
setblock 493 115 316 minecraft:cobbled_deepslate
fill 494 115 276 494 118 276 minecraft:deepslate_tiles
setblock 494 115 278 minecraft:light[level=12]
setblock 494 115 285 minecraft:light[level=12]
setblock 494 115 292 minecraft:light[level=12]
setblock 494 115 299 minecraft:light[level=12]
setblock 494 115 306 minecraft:light[level=12]
setblock 494 115 313 minecraft:light[level=12]
setblock 494 115 315 minecraft:cobbled_deepslate
fill 494 115 316 494 118 316 minecraft:deepslate_tiles
fill 495 115 315 495 118 315 minecraft:deepslate_tiles
setblock 497 115 277 minecraft:cobbled_deepslate
fill 497 115 314 497 120 314 minecraft:black_concrete
setblock 498 115 276 minecraft:cobbled_deepslate
fill 498 115 277 498 118 277 minecraft:deepslate_tiles
fill 498 115 313 498 120 313 minecraft:black_concrete
setblock 498 115 316 minecraft:cobbled_deepslate
fill 499 115 276 499 118 276 minecraft:deepslate_tiles
fill 499 115 314 499 120 314 minecraft:black_concrete
setblock 499 115 315 minecraft:cobbled_deepslate
fill 499 115 316 499 118 316 minecraft:deepslate_tiles
fill 500 115 277 500 116 277 minecraft:deepslate_tiles
fill 500 115 315 501 117 315 minecraft:deepslate_tiles
setblock 501 115 278 minecraft:light[level=12]
setblock 501 115 285 minecraft:light[level=12]
setblock 501 115 292 minecraft:light[level=12]
setblock 501 115 299 minecraft:light[level=12]
setblock 501 115 306 minecraft:light[level=12]
setblock 501 115 313 minecraft:light[level=12]
fill 502 115 289 502 119 291 minecraft:black_concrete
setblock 502 115 316 minecraft:deepslate_tiles
setblock 503 115 276 minecraft:cobbled_deepslate
fill 503 115 277 503 116 277 minecraft:black_concrete
fill 503 115 288 503 119 288 minecraft:black_concrete
setblock 503 115 316 minecraft:cobbled_deepslate
fill 504 115 276 507 115 276 minecraft:deepslate_tiles
fill 504 115 287 505 119 287 minecraft:black_concrete
fill 504 115 293 506 119 293 minecraft:black_concrete
fill 504 115 316 504 118 316 minecraft:deepslate_tiles
fill 505 115 315 506 117 315 minecraft:deepslate_tiles
setblock 506 115 317 minecraft:redstone_block
fill 507 115 288 507 119 288 minecraft:black_concrete
fill 507 115 292 507 121 292 minecraft:black_concrete
setblock 507 115 316 minecraft:deepslate_tiles
fill 507 115 317 508 145 317 minecraft:black_concrete
setblock 508 115 276 minecraft:cobbled_deepslate
setblock 508 115 278 minecraft:light[level=12]
setblock 508 115 285 minecraft:light[level=12]
setblock 508 115 292 minecraft:light[level=12]
setblock 508 115 299 minecraft:light[level=12]
setblock 508 115 306 minecraft:light[level=12]
setblock 508 115 313 minecraft:light[level=12]
setblock 508 115 316 minecraft:cobbled_deepslate
fill 509 115 276 509 118 276 minecraft:deepslate_tiles
fill 509 115 313 509 115 314 minecraft:deepslate_tiles
setblock 509 115 315 minecraft:cobbled_deepslate
fill 509 115 316 509 118 316 minecraft:deepslate_tiles
setblock 509 115 317 minecraft:white_wool
fill 510 115 277 510 116 277 minecraft:deepslate_tiles
setblock 510 115 309 minecraft:cobbled_deepslate
fill 510 115 310 510 118 310 minecraft:deepslate_tiles
setblock 510 115 313 minecraft:deepslate_tiles
setblock 510 115 314 minecraft:cobbled_deepslate
fill 510 115 315 510 118 315 minecraft:deepslate_tiles
setblock 511 115 278 minecraft:cobbled_deepslate
fill 511 115 279 511 117 280 minecraft:deepslate_tiles
setblock 511 115 288 minecraft:cobbled_deepslate
fill 511 115 289 511 118 289 minecraft:deepslate_tiles
fill 511 115 291 511 115 292 minecraft:deepslate_tiles
setblock 511 115 293 minecraft:cobbled_deepslate
fill 511 115 294 511 118 294 minecraft:deepslate_tiles
fill 511 115 296 511 115 297 minecraft:deepslate_tiles
setblock 511 115 298 minecraft:cobbled_deepslate
fill 511 115 305 511 117 305 minecraft:deepslate_tiles
setblock 511 115 308 minecraft:cobbled_deepslate
fill 511 115 309 511 118 309 minecraft:deepslate_tiles
setblock 511 115 313 minecraft:cobbled_deepslate
fill 511 115 314 511 118 314 minecraft:deepslate_tiles
setblock 471 116 276 minecraft:deepslate_tiles
setblock 471 116 277 minecraft:cobbled_deepslate
fill 471 116 278 471 118 279 minecraft:deepslate_tiles
setblock 471 116 287 minecraft:cobbled_deepslate
fill 471 116 288 471 119 288 minecraft:deepslate_tiles
setblock 471 116 291 minecraft:deepslate_tiles
setblock 471 116 292 minecraft:cobbled_deepslate
fill 471 116 293 471 119 293 minecraft:deepslate_tiles
setblock 471 116 296 minecraft:deepslate_tiles
setblock 471 116 297 minecraft:cobbled_deepslate
fill 471 116 298 471 119 298 minecraft:deepslate_tiles
fill 471 116 300 471 116 301 minecraft:deepslate_tiles
setblock 471 116 302 minecraft:cobbled_deepslate
fill 471 116 303 471 119 303 minecraft:deepslate_tiles
setblock 471 116 307 minecraft:cobbled_deepslate
fill 471 116 308 471 119 308 minecraft:deepslate_tiles
setblock 471 116 312 minecraft:cobbled_deepslate
fill 471 116 313 471 119 313 minecraft:deepslate_tiles
setblock 472 116 276 minecraft:cobbled_deepslate
setblock 472 116 291 minecraft:cobbled_deepslate
fill 472 116 292 472 119 292 minecraft:deepslate_tiles
setblock 472 116 296 minecraft:cobbled_deepslate
fill 472 116 297 472 119 297 minecraft:deepslate_tiles
setblock 472 116 300 minecraft:deepslate_tiles
setblock 472 116 301 minecraft:cobbled_deepslate
fill 472 116 302 472 119 302 minecraft:deepslate_tiles
setblock 472 116 306 minecraft:cobbled_deepslate
fill 472 116 307 472 119 307 minecraft:deepslate_tiles
setblock 472 116 311 minecraft:cobbled_deepslate
fill 472 116 312 472 119 312 minecraft:deepslate_tiles
setblock 472 116 316 minecraft:cobbled_deepslate
fill 473 116 276 473 119 276 minecraft:deepslate_tiles
fill 473 116 291 473 119 291 minecraft:deepslate_tiles
setblock 473 116 294 minecraft:deepslate_tiles
setblock 473 116 295 minecraft:cobbled_deepslate
fill 473 116 296 474 118 296 minecraft:deepslate_tiles
setblock 473 116 299 minecraft:deepslate_tiles
setblock 473 116 300 minecraft:cobbled_deepslate
fill 473 116 301 473 119 301 minecraft:deepslate_tiles
fill 473 116 306 473 119 306 minecraft:deepslate_tiles
setblock 473 116 310 minecraft:cobbled_deepslate
fill 473 116 311 473 119 311 minecraft:deepslate_tiles
setblock 473 116 315 minecraft:cobbled_deepslate
fill 473 116 316 473 119 316 minecraft:deepslate_tiles
fill 474 116 292 476 117 292 minecraft:white_wool
setblock 474 116 294 minecraft:cobbled_deepslate
fill 474 116 295 474 119 295 minecraft:deepslate_tiles
setblock 474 116 313 minecraft:deepslate_tiles
setblock 474 116 314 minecraft:cobbled_deepslate
fill 474 116 315 474 119 315 minecraft:deepslate_tiles
fill 475 116 276 476 116 276 minecraft:deepslate_tiles
fill 475 116 291 475 117 291 minecraft:white_wool
fill 475 116 293 475 117 293 minecraft:white_wool
setblock 475 116 313 minecraft:cobbled_deepslate
fill 475 116 314 475 119 314 minecraft:deepslate_tiles
setblock 477 116 276 minecraft:cobbled_deepslate
setblock 477 116 316 minecraft:cobbled_deepslate
fill 478 116 276 478 119 276 minecraft:deepslate_tiles
setblock 478 116 315 minecraft:cobbled_deepslate
fill 478 116 316 478 119 316 minecraft:deepslate_tiles
fill 479 116 315 479 118 315 minecraft:deepslate_tiles
setblock 482 116 316 minecraft:cobbled_deepslate
setblock 487 116 316 minecraft:cobbled_deepslate
fill 488 116 276 488 119 276 minecraft:deepslate_tiles
fill 488 116 316 488 119 316 minecraft:deepslate_tiles
setblock 490 116 277 minecraft:deepslate_tiles
fill 490 116 315 492 116 315 minecraft:deepslate_tiles
setblock 491 116 277 minecraft:cobbled_deepslate
setblock 492 116 276 minecraft:cobbled_deepslate
fill 492 116 277 495 116 277 minecraft:deepslate_tiles
setblock 492 116 316 minecraft:cobbled_deepslate
fill 493 116 276 493 119 276 minecraft:deepslate_tiles
fill 493 116 278 494 116 278 minecraft:deepslate_tiles
setblock 493 116 315 minecraft:cobbled_deepslate
fill 493 116 316 493 119 316 minecraft:deepslate_tiles
setblock 494 116 314 minecraft:cobbled_deepslate
fill 494 116 315 494 119 315 minecraft:deepslate_tiles
setblock 495 116 278 minecraft:cobbled_deepslate
fill 495 116 314 495 118 314 minecraft:deepslate_tiles
setblock 496 116 277 minecraft:cobbled_deepslate
fill 496 116 278 497 118 278 minecraft:deepslate_tiles
setblock 497 116 276 minecraft:cobbled_deepslate
fill 497 116 277 497 119 277 minecraft:deepslate_tiles
setblock 497 116 316 minecraft:cobbled_deepslate
fill 498 116 276 498 119 276 minecraft:deepslate_tiles
setblock 498 116 315 minecraft:cobbled_deepslate
fill 498 116 316 498 119 316 minecraft:deepslate_tiles
fill 499 116 315 499 119 315 minecraft:deepslate_tiles
setblock 501 116 277 minecraft:cobbled_deepslate
setblock 502 116 276 minecraft:cobbled_deepslate
fill 502 116 288 502 119 288 minecraft:black_concrete
fill 502 116 292 502 119 292 minecraft:black_concrete
setblock 502 116 315 minecraft:deepslate_tiles
setblock 502 116 316 minecraft:cobbled_deepslate
fill 503 116 276 506 116 276 minecraft:deepslate_tiles
fill 503 116 287 503 119 287 minecraft:black_concrete
fill 503 116 293 503 119 293 minecraft:black_concrete
setblock 503 116 315 minecraft:cobbled_deepslate
fill 503 116 316 503 119 316 minecraft:deepslate_tiles
fill 504 116 315 504 119 315 minecraft:deepslate_tiles
fill 506 116 287 506 119 287 minecraft:black_concrete
fill 506 116 317 506 122 317 minecraft:black_concrete
setblock 507 116 276 minecraft:cobbled_deepslate
fill 507 116 277 509 117 277 minecraft:deepslate_tiles
setblock 507 116 315 minecraft:deepslate_tiles
setblock 507 116 316 minecraft:cobbled_deepslate
fill 508 116 276 508 119 276 minecraft:deepslate_tiles
fill 508 116 289 508 120 290 minecraft:black_concrete
fill 508 116 292 508 120 292 minecraft:black_concrete
setblock 508 116 314 minecraft:deepslate_tiles
setblock 508 116 315 minecraft:cobbled_deepslate
fill 508 116 316 508 119 316 minecraft:deepslate_tiles
fill 509 116 282 509 123 282 minecraft:black_concrete
fill 509 116 291 509 120 291 minecraft:black_concrete
fill 509 116 312 509 116 313 minecraft:deepslate_tiles
setblock 509 116 314 minecraft:cobbled_deepslate
fill 509 116 315 509 119 315 minecraft:deepslate_tiles
fill 509 116 317 509 198 317 minecraft:black_concrete
setblock 510 116 278 minecraft:cobbled_deepslate
setblock 510 116 292 minecraft:deepslate_tiles
setblock 510 116 293 minecraft:cobbled_deepslate
fill 510 116 294 510 119 294 minecraft:deepslate_tiles
fill 510 116 309 510 119 309 minecraft:deepslate_tiles
setblock 510 116 313 minecraft:cobbled_deepslate
fill 510 116 314 510 119 314 minecraft:deepslate_tiles
setblock 511 116 276 minecraft:deepslate_tiles
setblock 511 116 277 minecraft:cobbled_deepslate
fill 511 116 278 511 119 278 minecraft:deepslate_tiles
setblock 511 116 281 minecraft:deepslate_tiles
setblock 511 116 282 minecraft:cobbled_deepslate
setblock 511 116 286 minecraft:deepslate_tiles
setblock 511 116 287 minecraft:cobbled_deepslate
fill 511 116 288 511 119 288 minecraft:deepslate_tiles
setblock 511 116 291 minecraft:deepslate_tiles
setblock 511 116 292 minecraft:cobbled_deepslate
fill 511 116 293 511 119 293 minecraft:deepslate_tiles
setblock 511 116 296 minecraft:deepslate_tiles
setblock 511 116 297 minecraft:cobbled_deepslate
fill 511 116 298 511 116 301 minecraft:deepslate_tiles
setblock 511 116 302 minecraft:cobbled_deepslate
fill 511 116 303 511 118 304 minecraft:deepslate_tiles
setblock 511 116 307 minecraft:cobbled_deepslate
fill 511 116 308 511 119 308 minecraft:deepslate_tiles
setblock 511 116 312 minecraft:cobbled_deepslate
fill 511 116 313 511 119 313 minecraft:deepslate_tiles
setblock 471 117 276 minecraft:cobbled_deepslate
fill 471 117 277 474 117 277 minecraft:deepslate_tiles
setblock 471 117 280 minecraft:deepslate_tiles
setblock 471 117 286 minecraft:cobbled_deepslate
fill 471 117 287 471 120 287 minecraft:deepslate_tiles
setblock 471 117 290 minecraft:deepslate_tiles
setblock 471 117 291 minecraft:cobbled_deepslate
fill 471 117 292 471 120 292 minecraft:deepslate_tiles
setblock 471 117 295 minecraft:deepslate_tiles
setblock 471 117 296 minecraft:cobbled_deepslate
fill 471 117 297 471 120 297 minecraft:deepslate_tiles
setblock 471 117 300 minecraft:deepslate_tiles
setblock 471 117 301 minecraft:cobbled_deepslate
fill 471 117 302 471 120 302 minecraft:deepslate_tiles
setblock 471 117 305 minecraft:deepslate_tiles
setblock 471 117 306 minecraft:cobbled_deepslate
fill 471 117 307 471 120 307 minecraft:deepslate_tiles
setblock 471 117 311 minecraft:cobbled_deepslate
fill 471 117 312 471 120 312 minecraft:deepslate_tiles
setblock 471 117 316 minecraft:cobbled_deepslate
fill 472 117 276 472 120 276 minecraft:deepslate_tiles
fill 472 117 278 472 118 278 minecraft:deepslate_tiles
fill 472 117 279 472 118 279 minecraft:black_concrete
fill 472 117 288 472 118 288 minecraft:deepslate_tiles
setblock 472 117 290 minecraft:cobbled_deepslate
fill 472 117 291 472 120 291 minecraft:deepslate_tiles
setblock 472 117 295 minecraft:cobbled_deepslate
fill 472 117 296 472 120 296 minecraft:deepslate_tiles
setblock 472 117 300 minecraft:cobbled_deepslate
fill 472 117 301 472 120 301 minecraft:deepslate_tiles
setblock 472 117 305 minecraft:cobbled_deepslate
fill 472 117 306 472 120 306 minecraft:deepslate_tiles
setblock 472 117 310 minecraft:cobbled_deepslate
fill 472 117 311 472 120 311 minecraft:deepslate_tiles
setblock 472 117 315 minecraft:cobbled_deepslate
fill 472 117 316 472 120 316 minecraft:deepslate_tiles
fill 473 117 278 473 121 278 minecraft:black_concrete
setblock 473 117 286 minecraft:light[level=13]
fill 473 117 290 473 118 290 minecraft:deepslate_tiles
setblock 473 117 294 minecraft:cobbled_deepslate
fill 473 117 295 473 120 295 minecraft:deepslate_tiles
setblock 473 117 299 minecraft:cobbled_deepslate
fill 473 117 300 473 120 300 minecraft:deepslate_tiles
fill 473 117 302 473 117 303 minecraft:deepslate_tiles
setblock 473 117 304 minecraft:cobbled_deepslate
fill 473 117 305 473 120 305 minecraft:deepslate_tiles
setblock 473 117 309 minecraft:cobbled_deepslate
fill 473 117 310 473 120 310 minecraft:deepslate_tiles
setblock 473 117 314 minecraft:cobbled_deepslate
fill 473 117 315 473 120 315 minecraft:deepslate_tiles
setblock 474 117 293 minecraft:cobbled_deepslate
fill 474 117 294 474 120 294 minecraft:deepslate_tiles
setblock 474 117 297 minecraft:deepslate_tiles
setblock 474 117 298 minecraft:cobbled_deepslate
fill 474 117 299 474 120 299 minecraft:deepslate_tiles
setblock 474 117 313 minecraft:cobbled_deepslate
fill 474 117 314 474 120 314 minecraft:deepslate_tiles
setblock 475 117 276 minecraft:deepslate_tiles
setblock 475 117 277 minecraft:cobbled_deepslate
setblock 476 117 276 minecraft:cobbled_deepslate
setblock 476 117 316 minecraft:cobbled_deepslate
fill 477 117 276 477 120 276 minecraft:deepslate_tiles
setblock 477 117 315 minecraft:cobbled_deepslate
fill 477 117 316 477 120 316 minecraft:deepslate_tiles
fill 478 117 315 478 119 315 minecraft:deepslate_tiles
fill 479 117 276 479 118 276 minecraft:deepslate_tiles
setblock 481 117 278 minecraft:light[level=13]
setblock 481 117 286 minecraft:light[level=13]
setblock 481 117 294 minecraft:light[level=13]
setblock 481 117 302 minecraft:light[level=13]
setblock 481 117 310 minecraft:light[level=13]
setblock 481 117 316 minecraft:cobbled_deepslate
fill 482 117 316 482 119 316 minecraft:deepslate_tiles
setblock 485 117 316 minecraft:deepslate_tiles
setblock 486 117 276 minecraft:cobbled_deepslate
setblock 486 117 316 minecraft:cobbled_deepslate
fill 487 117 276 487 120 276 minecraft:deepslate_tiles
fill 487 117 316 487 120 316 minecraft:deepslate_tiles
setblock 489 117 277 minecraft:deepslate_tiles
setblock 489 117 278 minecraft:light[level=13]
setblock 489 117 286 minecraft:light[level=13]
setblock 489 117 294 minecraft:light[level=13]
setblock 489 117 302 minecraft:light[level=13]
setblock 489 117 310 minecraft:light[level=13]
fill 489 117 315 491 117 315 minecraft:deepslate_tiles
setblock 490 117 277 minecraft:cobbled_deepslate
setblock 490 117 316 minecraft:deepslate_tiles
setblock 491 117 276 minecraft:cobbled_deepslate
fill 491 117 277 493 117 278 minecraft:deepslate_tiles
setblock 491 117 316 minecraft:cobbled_deepslate
fill 492 117 276 492 120 276 minecraft:deepslate_tiles
setblock 492 117 315 minecraft:cobbled_deepslate
fill 492 117 316 492 120 316 minecraft:deepslate_tiles
setblock 493 117 314 minecraft:cobbled_deepslate
fill 493 117 315 493 120 315 minecraft:deepslate_tiles
setblock 494 117 277 minecraft:deepslate_tiles
setblock 494 117 278 minecraft:cobbled_deepslate
fill 494 117 314 494 119 314 minecraft:deepslate_tiles
setblock 495 117 277 minecraft:cobbled_deepslate
fill 495 117 278 495 120 278 minecraft:deepslate_tiles
setblock 496 117 276 minecraft:cobbled_deepslate
fill 496 117 277 496 120 277 minecraft:deepslate_tiles
fill 496 117 314 496 118 314 minecraft:deepslate_tiles
setblock 496 117 316 minecraft:cobbled_deepslate
fill 497 117 276 497 120 276 minecraft:deepslate_tiles
setblock 497 117 286 minecraft:light[level=13]
setblock 497 117 294 minecraft:light[level=13]
setblock 497 117 302 minecraft:light[level=13]
setblock 497 117 310 minecraft:light[level=13]
fill 497 117 313 497 120 313 minecraft:black_concrete
setblock 497 117 315 minecraft:cobbled_deepslate
fill 497 117 316 497 120 316 minecraft:deepslate_tiles
setblock 498 117 278 minecraft:deepslate_tiles
fill 498 117 315 498 120 315 minecraft:deepslate_tiles
fill 499 117 313 499 120 313 minecraft:black_concrete
setblock 500 117 277 minecraft:cobbled_deepslate
setblock 501 117 276 minecraft:cobbled_deepslate
fill 501 117 277 504 117 277 minecraft:deepslate_tiles
fill 501 117 289 501 119 291 minecraft:black_concrete
setblock 501 117 316 minecraft:cobbled_deepslate
setblock 501 117 317 minecraft:white_wool
fill 502 117 276 505 117 276 minecraft:deepslate_tiles
fill 502 117 287 502 119 287 minecraft:black_concrete
fill 502 117 293 502 119 293 minecraft:black_concrete
setblock 502 117 315 minecraft:cobbled_deepslate
fill 502 117 316 502 120 316 minecraft:deepslate_tiles
fill 503 117 315 503 120 315 minecraft:deepslate_tiles
fill 504 117 286 505 119 286 minecraft:black_concrete
fill 504 117 294 506 119 294 minecraft:black_concrete
setblock 505 117 277 minecraft:cobbled_deepslate
setblock 505 117 278 minecraft:light[level=13]
setblock 505 117 302 minecraft:light[level=13]
setblock 505 117 310 minecraft:light[level=13]
setblock 506 117 276 minecraft:cobbled_deepslate
fill 506 117 277 506 120 277 minecraft:deepslate_tiles
setblock 506 117 316 minecraft:cobbled_deepslate
fill 507 117 276 507 120 276 minecraft:deepslate_tiles
fill 507 117 287 507 119 287 minecraft:black_concrete
fill 507 117 293 507 119 293 minecraft:black_concrete
setblock 507 117 314 minecraft:deepslate_tiles
setblock 507 117 315 minecraft:cobbled_deepslate
fill 507 117 316 507 120 316 minecraft:deepslate_tiles
fill 508 117 288 508 119 288 minecraft:black_concrete
setblock 508 117 314 minecraft:cobbled_deepslate
fill 508 117 315 508 120 315 minecraft:deepslate_tiles
fill 509 117 311 509 117 312 minecraft:deepslate_tiles
setblock 509 117 313 minecraft:cobbled_deepslate
fill 509 117 314 509 120 314 minecraft:deepslate_tiles
setblock 510 117 277 minecraft:cobbled_deepslate
fill 510 117 278 510 119 279 minecraft:deepslate_tiles
setblock 510 117 291 minecraft:deepslate_tiles
setblock 510 117 292 minecraft:cobbled_deepslate
fill 510 117 293 510 120 293 minecraft:deepslate_tiles
fill 510 117 295 510 117 296 minecraft:deepslate_tiles
setblock 510 117 297 minecraft:cobbled_deepslate
fill 510 117 298 511 119 298 minecraft:deepslate_tiles
fill 510 117 308 510 120 308 minecraft:deepslate_tiles
setblock 510 117 312 minecraft:cobbled_deepslate
fill 510 117 313 510 120 313 minecraft:deepslate_tiles
setblock 511 117 276 minecraft:cobbled_deepslate
fill 511 117 277 511 120 277 minecraft:deepslate_tiles
setblock 511 117 281 minecraft:cobbled_deepslate
fill 511 117 282 511 117 285 minecraft:deepslate_tiles
setblock 511 117 286 minecraft:cobbled_deepslate
fill 511 117 287 511 120 287 minecraft:deepslate_tiles
setblock 511 117 291 minecraft:cobbled_deepslate
fill 511 117 292 511 120 292 minecraft:deepslate_tiles
setblock 511 117 296 minecraft:cobbled_deepslate
fill 511 117 297 511 120 297 minecraft:deepslate_tiles
fill 511 117 299 511 117 300 minecraft:deepslate_tiles
setblock 511 117 301 minecraft:cobbled_deepslate
fill 511 117 302 511 120 302 minecraft:deepslate_tiles
setblock 511 117 306 minecraft:cobbled_deepslate
fill 511 117 307 511 120 307 minecraft:deepslate_tiles
setblock 511 117 311 minecraft:cobbled_deepslate
fill 511 117 312 511 120 312 minecraft:deepslate_tiles
setblock 511 117 316 minecraft:cobbled_deepslate
fill 470 118 292 470 169 293 minecraft:black_concrete
setblock 470 118 294 minecraft:redstone_block
fill 470 118 295 470 201 295 minecraft:black_concrete
fill 471 118 276 471 120 277 minecraft:deepslate_tiles
setblock 471 118 280 minecraft:cobbled_deepslate
fill 471 118 281 471 120 282 minecraft:deepslate_tiles
setblock 471 118 285 minecraft:cobbled_deepslate
fill 471 118 286 471 121 286 minecraft:deepslate_tiles
setblock 471 118 289 minecraft:deepslate_tiles
setblock 471 118 290 minecraft:cobbled_deepslate
fill 471 118 291 471 121 291 minecraft:deepslate_tiles
setblock 471 118 295 minecraft:cobbled_deepslate
fill 471 118 296 471 121 296 minecraft:deepslate_tiles
setblock 471 118 299 minecraft:deepslate_tiles
setblock 471 118 300 minecraft:cobbled_deepslate
fill 471 118 301 471 121 301 minecraft:deepslate_tiles
setblock 471 118 304 minecraft:deepslate_tiles
setblock 471 118 305 minecraft:cobbled_deepslate
fill 471 118 306 471 121 306 minecraft:deepslate_tiles
setblock 471 118 310 minecraft:cobbled_deepslate
fill 471 118 311 471 121 311 minecraft:deepslate_tiles
setblock 471 118 315 minecraft:cobbled_deepslate
fill 471 118 316 471 121 316 minecraft:deepslate_tiles
fill 472 118 277 473 118 277 minecraft:deepslate_tiles
setblock 472 118 289 minecraft:cobbled_deepslate
fill 472 118 290 472 121 290 minecraft:deepslate_tiles
setblock 472 118 293 minecraft:deepslate_tiles
setblock 472 118 294 minecraft:cobbled_deepslate
fill 472 118 295 472 121 295 minecraft:deepslate_tiles
setblock 472 118 298 minecraft:deepslate_tiles
setblock 472 118 299 minecraft:cobbled_deepslate
fill 472 118 300 472 121 300 minecraft:deepslate_tiles
setblock 472 118 304 minecraft:cobbled_deepslate
fill 472 118 305 472 121 305 minecraft:deepslate_tiles
setblock 472 118 309 minecraft:cobbled_deepslate
fill 472 118 310 472 121 310 minecraft:deepslate_tiles
setblock 472 118 314 minecraft:cobbled_deepslate
fill 472 118 315 472 121 315 minecraft:deepslate_tiles
setblock 473 118 293 minecraft:cobbled_deepslate
fill 473 118 294 473 121 294 minecraft:deepslate_tiles
setblock 473 118 298 minecraft:cobbled_deepslate
fill 473 118 299 473 121 299 minecraft:deepslate_tiles
setblock 473 118 302 minecraft:deepslate_tiles
setblock 473 118 303 minecraft:cobbled_deepslate
fill 473 118 304 473 121 304 minecraft:deepslate_tiles
setblock 473 118 308 minecraft:cobbled_deepslate
fill 473 118 309 473 119 309 minecraft:deepslate_tiles
setblock 473 118 313 minecraft:cobbled_deepslate
fill 473 118 314 473 121 314 minecraft:deepslate_tiles
setblock 474 118 277 minecraft:cobbled_deepslate
fill 474 118 293 474 119 293 minecraft:deepslate_tiles
setblock 474 118 297 minecraft:cobbled_deepslate
fill 474 118 298 474 121 298 minecraft:deepslate_tiles
fill 474 118 300 474 119 300 minecraft:deepslate_tiles
setblock 474 118 313 minecraft:deepslate_tiles
setblock 475 118 276 minecraft:cobbled_deepslate
fill 475 118 277 475 121 277 minecraft:deepslate_tiles
setblock 475 118 316 minecraft:cobbled_deepslate
fill 476 118 276 476 121 276 minecraft:deepslate_tiles
setblock 476 118 315 minecraft:cobbled_deepslate
fill 476 118 316 476 121 316 minecraft:deepslate_tiles
fill 477 118 315 477 120 315 minecraft:deepslate_tiles
setblock 480 118 276 minecraft:cobbled_deepslate
setblock 480 118 316 minecraft:cobbled_deepslate
fill 481 118 316 481 119 316 minecraft:deepslate_tiles
fill 483 118 316 484 118 316 minecraft:deepslate_tiles
setblock 484 118 276 minecraft:deepslate_tiles
setblock 485 118 276 minecraft:cobbled_deepslate
setblock 485 118 316 minecraft:cobbled_deepslate
fill 486 118 276 486 121 276 minecraft:deepslate_tiles
fill 486 118 316 486 121 316 minecraft:deepslate_tiles
fill 487 118 277 488 118 277 minecraft:deepslate_tiles
fill 488 118 315 490 118 315 minecraft:deepslate_tiles
setblock 489 118 276 minecraft:deepslate_tiles
setblock 489 118 277 minecraft:cobbled_deepslate
setblock 490 118 276 minecraft:cobbled_deepslate
fill 490 118 277 492 118 278 minecraft:deepslate_tiles
setblock 490 118 316 minecraft:cobbled_deepslate
fill 491 118 276 491 121 276 minecraft:deepslate_tiles
setblock 491 118 315 minecraft:cobbled_deepslate
fill 491 118 316 491 121 316 minecraft:deepslate_tiles
setblock 492 118 314 minecraft:cobbled_deepslate
fill 492 118 315 492 121 315 minecraft:deepslate_tiles
setblock 493 118 277 minecraft:deepslate_tiles
setblock 493 118 278 minecraft:cobbled_deepslate
fill 493 118 314 493 119 314 minecraft:deepslate_tiles
setblock 494 118 277 minecraft:cobbled_deepslate
fill 494 118 278 494 121 278 minecraft:deepslate_tiles
setblock 495 118 276 minecraft:cobbled_deepslate
fill 495 118 277 495 121 277 minecraft:deepslate_tiles
setblock 495 118 316 minecraft:cobbled_deepslate
fill 496 118 276 496 121 276 minecraft:deepslate_tiles
setblock 496 118 315 minecraft:cobbled_deepslate
fill 496 118 316 496 121 316 minecraft:deepslate_tiles
fill 497 118 315 497 121 315 minecraft:deepslate_tiles
setblock 498 118 278 minecraft:cobbled_deepslate
setblock 499 118 277 minecraft:cobbled_deepslate
setblock 500 118 276 minecraft:cobbled_deepslate
fill 500 118 277 503 118 277 minecraft:deepslate_tiles
setblock 500 118 315 minecraft:deepslate_tiles
setblock 500 118 316 minecraft:cobbled_deepslate
fill 501 118 276 504 118 276 minecraft:deepslate_tiles
fill 501 118 288 501 119 288 minecraft:black_concrete
fill 501 118 292 501 119 292 minecraft:black_concrete
setblock 501 118 315 minecraft:cobbled_deepslate
fill 501 118 316 501 121 316 minecraft:deepslate_tiles
fill 501 118 317 501 156 317 minecraft:black_concrete
fill 502 118 315 502 121 315 minecraft:deepslate_tiles
fill 503 118 278 503 119 278 minecraft:black_concrete
fill 503 118 286 503 119 286 minecraft:black_concrete
fill 503 118 294 503 119 294 minecraft:black_concrete
setblock 504 118 277 minecraft:cobbled_deepslate
setblock 505 118 276 minecraft:cobbled_deepslate
fill 505 118 277 505 121 277 minecraft:deepslate_tiles
setblock 505 118 315 minecraft:deepslate_tiles
setblock 505 118 316 minecraft:cobbled_deepslate
fill 506 118 276 506 121 276 minecraft:deepslate_tiles
fill 506 118 286 507 119 286 minecraft:black_concrete
setblock 506 118 314 minecraft:deepslate_tiles
setblock 506 118 315 minecraft:cobbled_deepslate
fill 506 118 316 506 121 316 minecraft:deepslate_tiles
fill 507 118 277 508 118 277 minecraft:deepslate_tiles
fill 507 118 294 507 119 294 minecraft:black_concrete
setblock 507 118 314 minecraft:cobbled_deepslate
fill 507 118 315 507 121 315 minecraft:deepslate_tiles
fill 508 118 287 508 119 287 minecraft:black_concrete
fill 508 118 293 508 120 293 minecraft:black_concrete
fill 508 118 314 508 121 314 minecraft:deepslate_tiles
setblock 509 118 277 minecraft:cobbled_deepslate
fill 509 118 289 509 119 290 minecraft:black_concrete
fill 509 118 292 509 120 292 minecraft:black_concrete
setblock 509 118 311 minecraft:deepslate_tiles
setblock 509 118 312 minecraft:cobbled_deepslate
fill 509 118 313 509 121 313 minecraft:deepslate_tiles
setblock 510 118 276 minecraft:cobbled_deepslate
fill 510 118 277 510 121 277 minecraft:deepslate_tiles
setblock 510 118 280 minecraft:deepslate_tiles
setblock 510 118 291 minecraft:cobbled_deepslate
fill 510 118 292 510 121 292 minecraft:deepslate_tiles
setblock 510 118 295 minecraft:deepslate_tiles
setblock 510 118 296 minecraft:cobbled_deepslate
fill 510 118 297 510 121 297 minecraft:deepslate_tiles
fill 510 118 299 510 118 300 minecraft:deepslate_tiles
setblock 510 118 301 minecraft:cobbled_deepslate
fill 510 118 307 510 121 307 minecraft:deepslate_tiles
setblock 510 118 311 minecraft:cobbled_deepslate
fill 510 118 312 510 121 312 minecraft:deepslate_tiles
setblock 510 118 316 minecraft:cobbled_deepslate
fill 511 118 276 511 121 276 minecraft:deepslate_tiles
setblock 511 118 279 minecraft:deepslate_tiles
setblock 511 118 280 minecraft:cobbled_deepslate
fill 511 118 281 511 118 284 minecraft:deepslate_tiles
setblock 511 118 285 minecraft:cobbled_deepslate
fill 511 118 286 511 120 286 minecraft:deepslate_tiles
setblock 511 118 290 minecraft:cobbled_deepslate
fill 511 118 291 511 121 291 minecraft:deepslate_tiles
setblock 511 118 295 minecraft:cobbled_deepslate
fill 511 118 296 511 121 296 minecraft:deepslate_tiles
setblock 511 118 299 minecraft:deepslate_tiles
setblock 511 118 300 minecraft:cobbled_deepslate
fill 511 118 301 511 121 301 minecraft:deepslate_tiles
setblock 511 118 305 minecraft:cobbled_deepslate
fill 511 118 306 511 121 306 minecraft:deepslate_tiles
setblock 511 118 310 minecraft:cobbled_deepslate
fill 511 118 311 511 121 311 minecraft:deepslate_tiles
setblock 511 118 315 minecraft:cobbled_deepslate
fill 511 118 316 511 121 316 minecraft:deepslate_tiles
fill 512 118 300 512 201 300 minecraft:black_concrete
setblock 512 118 301 minecraft:white_wool
fill 512 118 302 512 201 302 minecraft:black_concrete
fill 470 119 285 470 144 286 minecraft:black_concrete
setblock 470 119 287 minecraft:redstone_block
fill 470 119 294 470 143 294 minecraft:black_concrete
setblock 471 119 278 minecraft:deepslate_tiles
setblock 471 119 279 minecraft:cobbled_deepslate
fill 471 119 280 471 122 280 minecraft:deepslate_tiles
setblock 471 119 283 minecraft:deepslate_tiles
setblock 471 119 284 minecraft:cobbled_deepslate
fill 471 119 285 471 122 285 minecraft:deepslate_tiles
setblock 471 119 289 minecraft:cobbled_deepslate
fill 471 119 290 471 122 290 minecraft:deepslate_tiles
setblock 471 119 294 minecraft:cobbled_deepslate
fill 471 119 295 471 122 295 minecraft:deepslate_tiles
setblock 471 119 299 minecraft:cobbled_deepslate
fill 471 119 300 471 122 300 minecraft:deepslate_tiles
setblock 471 119 304 minecraft:cobbled_deepslate
fill 471 119 305 471 122 305 minecraft:deepslate_tiles
setblock 471 119 309 minecraft:cobbled_deepslate
fill 471 119 310 471 122 310 minecraft:deepslate_tiles
setblock 471 119 314 minecraft:cobbled_deepslate
fill 471 119 315 471 122 315 minecraft:deepslate_tiles
setblock 472 119 277 minecraft:deepslate_tiles
setblock 472 119 278 minecraft:cobbled_deepslate
fill 472 119 279 472 122 279 minecraft:deepslate_tiles
fill 472 119 289 472 120 289 minecraft:deepslate_tiles
setblock 472 119 293 minecraft:cobbled_deepslate
fill 472 119 294 472 122 294 minecraft:deepslate_tiles
setblock 472 119 298 minecraft:cobbled_deepslate
fill 472 119 299 472 122 299 minecraft:deepslate_tiles
setblock 472 119 303 minecraft:cobbled_deepslate
fill 472 119 304 472 122 304 minecraft:deepslate_tiles
setblock 472 119 308 minecraft:cobbled_deepslate
fill 472 119 309 472 122 309 minecraft:deepslate_tiles
setblock 472 119 313 minecraft:cobbled_deepslate
fill 472 119 314 472 122 314 minecraft:deepslate_tiles
setblock 473 119 277 minecraft:cobbled_deepslate
fill 473 119 279 473 121 279 minecraft:black_concrete
setblock 473 119 292 minecraft:cobbled_deepslate
fill 473 119 293 473 122 293 minecraft:deepslate_tiles
setblock 473 119 296 minecraft:deepslate_tiles
setblock 473 119 297 minecraft:cobbled_deepslate
fill 473 119 298 473 122 298 minecraft:deepslate_tiles
setblock 473 119 302 minecraft:cobbled_deepslate
fill 473 119 303 473 122 303 minecraft:deepslate_tiles
setblock 473 119 307 minecraft:cobbled_deepslate
setblock 473 119 308 minecraft:deepslate_tiles
setblock 473 119 312 minecraft:cobbled_deepslate
fill 473 119 313 473 120 313 minecraft:deepslate_tiles
setblock 474 119 276 minecraft:cobbled_deepslate
fill 474 119 277 474 122 277 minecraft:deepslate_tiles
setblock 474 119 296 minecraft:cobbled_deepslate
fill 474 119 297 474 122 297 minecraft:deepslate_tiles
setblock 474 119 301 minecraft:cobbled_deepslate
setblock 474 119 316 minecraft:cobbled_deepslate
fill 475 119 276 475 122 276 minecraft:deepslate_tiles
setblock 475 119 315 minecraft:cobbled_deepslate
fill 475 119 316 475 122 316 minecraft:deepslate_tiles
setblock 476 119 277 minecraft:deepslate_tiles
setblock 476 119 314 minecraft:cobbled_deepslate
fill 476 119 315 476 121 315 minecraft:deepslate_tiles
setblock 479 119 276 minecraft:cobbled_deepslate
setblock 479 119 316 minecraft:cobbled_deepslate
fill 480 119 276 483 119 276 minecraft:deepslate_tiles
fill 480 119 316 480 120 316 minecraft:deepslate_tiles
setblock 483 119 316 minecraft:deepslate_tiles
setblock 484 119 276 minecraft:cobbled_deepslate
setblock 484 119 316 minecraft:cobbled_deepslate
fill 485 119 276 485 122 276 minecraft:deepslate_tiles
fill 485 119 316 485 122 316 minecraft:deepslate_tiles
fill 486 119 277 487 119 277 minecraft:deepslate_tiles
setblock 488 119 277 minecraft:cobbled_deepslate
fill 488 119 315 489 119 315 minecraft:deepslate_tiles
setblock 489 119 276 minecraft:cobbled_deepslate
fill 489 119 277 491 119 278 minecraft:deepslate_tiles
setblock 489 119 316 minecraft:cobbled_deepslate
fill 489 119 317 491 129 317 minecraft:black_concrete
fill 490 119 276 490 122 276 minecraft:deepslate_tiles
setblock 490 119 315 minecraft:cobbled_deepslate
fill 490 119 316 490 122 316 minecraft:deepslate_tiles
fill 491 119 315 491 122 315 minecraft:deepslate_tiles
setblock 492 119 277 minecraft:deepslate_tiles
setblock 492 119 278 minecraft:cobbled_deepslate
fill 492 119 279 494 120 279 minecraft:deepslate_tiles
setblock 492 119 314 minecraft:deepslate_tiles
setblock 492 119 317 minecraft:redstone_block
setblock 493 119 277 minecraft:cobbled_deepslate
fill 493 119 278 493 122 278 minecraft:deepslate_tiles
setblock 494 119 276 minecraft:cobbled_deepslate
fill 494 119 277 494 122 277 minecraft:deepslate_tiles
setblock 494 119 316 minecraft:cobbled_deepslate
fill 495 119 276 495 122 276 minecraft:deepslate_tiles
setblock 495 119 315 minecraft:cobbled_deepslate
fill 495 119 316 495 122 316 minecraft:deepslate_tiles
setblock 496 119 278 minecraft:deepslate_tiles
fill 496 119 315 496 121 315 minecraft:deepslate_tiles
setblock 497 119 278 minecraft:cobbled_deepslate
setblock 498 119 277 minecraft:cobbled_deepslate
fill 498 119 278 499 120 278 minecraft:deepslate_tiles
setblock 499 119 276 minecraft:cobbled_deepslate
fill 499 119 277 502 119 277 minecraft:deepslate_tiles
setblock 499 119 316 minecraft:cobbled_deepslate
fill 500 119 276 503 119 276 minecraft:deepslate_tiles
fill 500 119 289 500 119 291 minecraft:black_concrete
setblock 500 119 315 minecraft:cobbled_deepslate
fill 500 119 316 500 122 316 minecraft:deepslate_tiles
setblock 501 119 287 minecraft:black_concrete
setblock 501 119 293 minecraft:black_concrete
fill 501 119 315 501 120 315 minecraft:deepslate_tiles
setblock 502 119 278 minecraft:black_concrete
setblock 502 119 286 minecraft:black_concrete
setblock 502 119 294 minecraft:black_concrete
setblock 503 119 277 minecraft:cobbled_deepslate
setblock 504 119 276 minecraft:cobbled_deepslate
fill 504 119 277 504 122 277 minecraft:deepslate_tiles
setblock 504 119 278 minecraft:black_concrete
fill 504 119 285 505 119 285 minecraft:black_concrete
fill 504 119 295 506 119 295 minecraft:black_concrete
setblock 504 119 316 minecraft:cobbled_deepslate
fill 505 119 276 505 122 276 minecraft:deepslate_tiles
setblock 505 119 315 minecraft:cobbled_deepslate
fill 505 119 316 505 122 316 minecraft:deepslate_tiles
setblock 506 119 314 minecraft:cobbled_deepslate
fill 506 119 315 506 122 315 minecraft:deepslate_tiles
setblock 507 119 277 minecraft:deepslate_tiles
fill 507 119 314 507 122 314 minecraft:deepslate_tiles
setblock 508 119 277 minecraft:cobbled_deepslate
fill 508 119 278 509 121 278 minecraft:deepslate_tiles
fill 508 119 282 508 123 282 minecraft:black_concrete
setblock 508 119 294 minecraft:black_concrete
setblock 509 119 276 minecraft:cobbled_deepslate
fill 509 119 277 509 122 277 minecraft:deepslate_tiles
fill 509 119 281 509 123 281 minecraft:black_concrete
fill 509 119 283 509 123 283 minecraft:black_concrete
setblock 509 119 288 minecraft:black_concrete
setblock 509 119 293 minecraft:black_concrete
setblock 509 119 311 minecraft:cobbled_deepslate
fill 509 119 312 509 122 312 minecraft:deepslate_tiles
setblock 509 119 316 minecraft:cobbled_deepslate
fill 510 119 276 510 122 276 minecraft:deepslate_tiles
setblock 510 119 280 minecraft:cobbled_deepslate
fill 510 119 281 511 121 281 minecraft:deepslate_tiles
fill 510 119 282 510 123 282 minecraft:black_concrete
setblock 510 119 291 minecraft:deepslate_tiles
setblock 510 119 295 minecraft:cobbled_deepslate
fill 510 119 296 510 122 296 minecraft:deepslate_tiles
setblock 510 119 299 minecraft:deepslate_tiles
setblock 510 119 300 minecraft:cobbled_deepslate
fill 510 119 301 510 119 304 minecraft:deepslate_tiles
setblock 510 119 305 minecraft:cobbled_deepslate
fill 510 119 306 510 122 306 minecraft:deepslate_tiles
setblock 510 119 310 minecraft:cobbled_deepslate
fill 510 119 311 510 122 311 minecraft:deepslate_tiles
setblock 510 119 315 minecraft:cobbled_deepslate
fill 510 119 316 510 122 316 minecraft:deepslate_tiles
setblock 511 119 279 minecraft:cobbled_deepslate
fill 511 119 280 511 122 280 minecraft:deepslate_tiles
fill 511 119 282 511 119 283 minecraft:deepslate_tiles
setblock 511 119 284 minecraft:cobbled_deepslate
fill 511 119 285 511 121 285 minecraft:deepslate_tiles
setblock 511 119 289 minecraft:cobbled_deepslate
fill 511 119 290 511 122 290 minecraft:deepslate_tiles
setblock 511 119 294 minecraft:cobbled_deepslate
fill 511 119 295 511 122 295 minecraft:deepslate_tiles
setblock 511 119 299 minecraft:cobbled_deepslate
fill 511 119 300 511 122 300 minecraft:deepslate_tiles
setblock 511 119 303 minecraft:deepslate_tiles
setblock 511 119 304 minecraft:cobbled_deepslate
fill 511 119 305 511 122 305 minecraft:deepslate_tiles
setblock 511 119 309 minecraft:cobbled_deepslate
fill 511 119 310 511 122 310 minecraft:deepslate_tiles
setblock 511 119 314 minecraft:cobbled_deepslate
fill 511 119 315 511 122 315 minecraft:deepslate_tiles
fill 512 119 297 512 201 297 minecraft:black_concrete
setblock 512 119 298 minecraft:white_wool
fill 512 119 299 512 147 299 minecraft:black_concrete
fill 512 119 301 512 201 301 minecraft:black_concrete
fill 470 120 287 470 201 287 minecraft:black_concrete
setblock 471 120 278 minecraft:cobbled_deepslate
fill 471 120 279 471 123 279 minecraft:deepslate_tiles
setblock 471 120 283 minecraft:cobbled_deepslate
fill 471 120 284 471 123 284 minecraft:deepslate_tiles
setblock 471 120 288 minecraft:cobbled_deepslate
fill 471 120 289 471 123 289 minecraft:deepslate_tiles
setblock 471 120 293 minecraft:cobbled_deepslate
fill 471 120 294 471 123 294 minecraft:deepslate_tiles
setblock 471 120 298 minecraft:cobbled_deepslate
fill 471 120 299 471 123 299 minecraft:deepslate_tiles
setblock 471 120 303 minecraft:cobbled_deepslate
fill 471 120 304 471 123 304 minecraft:deepslate_tiles
setblock 471 120 308 minecraft:cobbled_deepslate
fill 471 120 309 471 123 309 minecraft:deepslate_tiles
setblock 471 120 313 minecraft:cobbled_deepslate
fill 471 120 314 471 123 314 minecraft:deepslate_tiles
setblock 472 120 277 minecraft:cobbled_deepslate
fill 472 120 278 472 123 278 minecraft:deepslate_tiles
fill 472 120 280 472 121 280 minecraft:deepslate_tiles
setblock 472 120 292 minecraft:cobbled_deepslate
fill 472 120 293 472 123 293 minecraft:deepslate_tiles
setblock 472 120 297 minecraft:cobbled_deepslate
fill 472 120 298 472 123 298 minecraft:deepslate_tiles
setblock 472 120 302 minecraft:cobbled_deepslate
fill 472 120 303 472 123 303 minecraft:deepslate_tiles
setblock 472 120 307 minecraft:cobbled_deepslate
fill 472 120 308 472 123 308 minecraft:deepslate_tiles
setblock 472 120 312 minecraft:cobbled_deepslate
fill 472 120 313 472 123 313 minecraft:deepslate_tiles
setblock 473 120 276 minecraft:cobbled_deepslate
fill 473 120 277 473 123 277 minecraft:deepslate_tiles
setblock 473 120 291 minecraft:cobbled_deepslate
fill 473 120 292 473 121 292 minecraft:deepslate_tiles
setblock 473 120 296 minecraft:cobbled_deepslate
fill 473 120 297 473 123 297 minecraft:deepslate_tiles
setblock 473 120 301 minecraft:cobbled_deepslate
fill 473 120 302 473 123 302 minecraft:deepslate_tiles
setblock 473 120 306 minecraft:cobbled_deepslate
setblock 473 120 311 minecraft:cobbled_deepslate
setblock 473 120 312 minecraft:deepslate_tiles
setblock 473 120 316 minecraft:cobbled_deepslate
fill 474 120 276 474 123 276 minecraft:deepslate_tiles
setblock 474 120 295 minecraft:cobbled_deepslate
fill 474 120 296 474 122 296 minecraft:deepslate_tiles
setblock 474 120 300 minecraft:cobbled_deepslate
fill 474 120 301 474 121 301 minecraft:deepslate_tiles
setblock 474 120 315 minecraft:cobbled_deepslate
fill 474 120 316 474 123 316 minecraft:deepslate_tiles
fill 475 120 315 475 121 315 minecraft:deepslate_tiles
setblock 478 120 276 minecraft:cobbled_deepslate
setblock 478 120 316 minecraft:cobbled_deepslate
fill 479 120 276 482 120 276 minecraft:deepslate_tiles
setblock 479 120 316 minecraft:deepslate_tiles
setblock 483 120 276 minecraft:cobbled_deepslate
fill 484 120 276 484 123 276 minecraft:deepslate_tiles
setblock 484 120 316 minecraft:deepslate_tiles
fill 485 120 277 486 120 277 minecraft:deepslate_tiles
setblock 487 120 277 minecraft:cobbled_deepslate
setblock 488 120 276 minecraft:cobbled_deepslate
fill 488 120 277 490 120 278 minecraft:deepslate_tiles
setblock 488 120 315 minecraft:deepslate_tiles
setblock 488 120 316 minecraft:cobbled_deepslate
fill 489 120 276 489 123 276 minecraft:deepslate_tiles
setblock 489 120 315 minecraft:cobbled_deepslate
fill 489 120 316 489 123 316 minecraft:deepslate_tiles
fill 490 120 315 490 123 315 minecraft:deepslate_tiles
setblock 491 120 277 minecraft:deepslate_tiles
setblock 491 120 278 minecraft:cobbled_deepslate
fill 491 120 279 491 123 279 minecraft:deepslate_tiles
setblock 492 120 277 minecraft:cobbled_deepslate
fill 492 120 278 492 123 278 minecraft:deepslate_tiles
fill 492 120 317 492 202 317 minecraft:black_concrete
setblock 493 120 276 minecraft:cobbled_deepslate
fill 493 120 277 493 123 277 minecraft:deepslate_tiles
setblock 493 120 316 minecraft:cobbled_deepslate
fill 494 120 276 494 123 276 minecraft:deepslate_tiles
setblock 494 120 315 minecraft:cobbled_deepslate
fill 494 120 316 494 123 316 minecraft:deepslate_tiles
setblock 495 120 279 minecraft:cobbled_deepslate
fill 495 120 315 495 122 315 minecraft:deepslate_tiles
setblock 496 120 278 minecraft:cobbled_deepslate
setblock 496 120 314 minecraft:black_concrete
setblock 497 120 277 minecraft:cobbled_deepslate
fill 497 120 278 497 123 278 minecraft:deepslate_tiles
setblock 498 120 276 minecraft:cobbled_deepslate
fill 498 120 277 501 120 277 minecraft:deepslate_tiles
setblock 498 120 312 minecraft:black_concrete
setblock 498 120 316 minecraft:cobbled_deepslate
fill 499 120 276 502 120 276 minecraft:deepslate_tiles
setblock 499 120 315 minecraft:cobbled_deepslate
fill 499 120 316 499 123 316 minecraft:deepslate_tiles
setblock 500 120 314 minecraft:black_concrete
setblock 500 120 315 minecraft:deepslate_tiles
setblock 502 120 277 minecraft:cobbled_deepslate
setblock 503 120 276 minecraft:cobbled_deepslate
fill 503 120 277 503 123 277 minecraft:deepslate_tiles
setblock 503 120 316 minecraft:cobbled_deepslate
fill 504 120 276 504 123 276 minecraft:deepslate_tiles
fill 504 120 290 505 120 291 minecraft:white_wool
setblock 504 120 315 minecraft:cobbled_deepslate
fill 504 120 316 504 123 316 minecraft:deepslate_tiles
setblock 505 120 289 minecraft:white_wool
fill 505 120 315 505 123 315 minecraft:deepslate_tiles
setblock 506 120 290 minecraft:white_wool
fill 506 120 314 506 121 314 minecraft:deepslate_tiles
setblock 507 120 277 minecraft:cobbled_deepslate
fill 507 120 278 507 123 278 minecraft:deepslate_tiles
fill 507 120 290 507 121 291 minecraft:black_concrete
setblock 508 120 276 minecraft:cobbled_deepslate
fill 508 120 277 508 123 277 minecraft:deepslate_tiles
setblock 508 120 316 minecraft:cobbled_deepslate
fill 509 120 276 509 123 276 minecraft:deepslate_tiles
setblock 509 120 279 minecraft:deepslate_tiles
setblock 509 120 290 minecraft:black_concrete
fill 509 120 297 509 121 298 minecraft:deepslate_tiles
fill 509 120 311 509 121 311 minecraft:deepslate_tiles
setblock 509 120 315 minecraft:cobbled_deepslate
fill 509 120 316 509 123 316 minecraft:deepslate_tiles
setblock 510 120 278 minecraft:deepslate_tiles
setblock 510 120 279 minecraft:cobbled_deepslate
fill 510 120 280 510 123 280 minecraft:deepslate_tiles
setblock 510 120 291 minecraft:black_concrete
setblock 510 120 294 minecraft:cobbled_deepslate
fill 510 120 295 510 123 295 minecraft:deepslate_tiles
setblock 510 120 298 minecraft:deepslate_tiles
setblock 510 120 299 minecraft:cobbled_deepslate
fill 510 120 300 510 120 303 minecraft:deepslate_tiles
setblock 510 120 304 minecraft:cobbled_deepslate
fill 510 120 305 510 123 305 minecraft:deepslate_tiles
setblock 510 120 309 minecraft:cobbled_deepslate
fill 510 120 310 510 123 310 minecraft:deepslate_tiles
setblock 510 120 314 minecraft:cobbled_deepslate
fill 510 120 315 510 123 315 minecraft:deepslate_tiles
setblock 511 120 278 minecraft:cobbled_deepslate
fill 511 120 279 511 123 279 minecraft:deepslate_tiles
setblock 511 120 282 minecraft:deepslate_tiles
setblock 511 120 283 minecraft:cobbled_deepslate
fill 511 120 284 511 123 284 minecraft:deepslate_tiles
setblock 511 120 288 minecraft:cobbled_deepslate
fill 511 120 289 511 121 289 minecraft:deepslate_tiles
setblock 511 120 293 minecraft:cobbled_deepslate
fill 511 120 294 511 123 294 minecraft:deepslate_tiles
setblock 511 120 298 minecraft:cobbled_deepslate
fill 511 120 299 511 123 299 minecraft:deepslate_tiles
setblock 511 120 303 minecraft:cobbled_deepslate
fill 511 120 304 511 123 304 minecraft:deepslate_tiles
setblock 511 120 308 minecraft:cobbled_deepslate
fill 511 120 309 511 123 309 minecraft:deepslate_tiles
setblock 511 120 313 minecraft:cobbled_deepslate
fill 511 120 314 511 123 314 minecraft:deepslate_tiles
setblock 511 120 317 minecraft:white_wool
fill 512 120 298 512 201 298 minecraft:black_concrete
setblock 471 121 276 minecraft:deepslate_tiles
setblock 471 121 277 minecraft:cobbled_deepslate
fill 471 121 278 471 124 278 minecraft:deepslate_tiles
setblock 471 121 281 minecraft:deepslate_tiles
setblock 471 121 282 minecraft:cobbled_deepslate
fill 471 121 283 471 124 283 minecraft:deepslate_tiles
setblock 471 121 287 minecraft:cobbled_deepslate
fill 471 121 288 471 122 288 minecraft:deepslate_tiles
setblock 471 121 292 minecraft:cobbled_deepslate
fill 471 121 293 471 124 293 minecraft:deepslate_tiles
setblock 471 121 297 minecraft:cobbled_deepslate
fill 471 121 298 471 124 298 minecraft:deepslate_tiles
setblock 471 121 302 minecraft:cobbled_deepslate
fill 471 121 303 471 124 303 minecraft:deepslate_tiles
setblock 471 121 307 minecraft:cobbled_deepslate
fill 471 121 308 471 124 308 minecraft:deepslate_tiles
setblock 471 121 312 minecraft:cobbled_deepslate
fill 471 121 313 471 124 313 minecraft:deepslate_tiles
setblock 472 121 276 minecraft:cobbled_deepslate
fill 472 121 277 472 123 277 minecraft:deepslate_tiles
setblock 472 121 291 minecraft:cobbled_deepslate
fill 472 121 292 472 123 292 minecraft:deepslate_tiles
setblock 472 121 296 minecraft:cobbled_deepslate
fill 472 121 297 472 124 297 minecraft:deepslate_tiles
setblock 472 121 301 minecraft:cobbled_deepslate
fill 472 121 302 472 124 302 minecraft:deepslate_tiles
setblock 472 121 306 minecraft:cobbled_deepslate
fill 472 121 307 472 124 307 minecraft:deepslate_tiles
setblock 472 121 311 minecraft:cobbled_deepslate
fill 472 121 312 472 122 312 minecraft:deepslate_tiles
setblock 472 121 316 minecraft:cobbled_deepslate
fill 473 121 276 473 124 276 minecraft:deepslate_tiles
setblock 473 121 285 minecraft:light[level=12]
setblock 473 121 295 minecraft:cobbled_deepslate
fill 473 121 296 473 124 296 minecraft:deepslate_tiles
setblock 473 121 300 minecraft:cobbled_deepslate
fill 473 121 301 473 124 301 minecraft:deepslate_tiles
setblock 473 121 305 minecraft:cobbled_deepslate
setblock 473 121 306 minecraft:light[level=12]
setblock 473 121 313 minecraft:light[level=12]
setblock 473 121 315 minecraft:cobbled_deepslate
fill 473 121 316 473 124 316 minecraft:deepslate_tiles
setblock 474 121 295 minecraft:deepslate_tiles
setblock 474 121 299 minecraft:cobbled_deepslate
fill 474 121 300 474 122 300 minecraft:deepslate_tiles
fill 474 121 315 474 122 315 minecraft:deepslate_tiles
setblock 477 121 276 minecraft:cobbled_deepslate
setblock 477 121 316 minecraft:cobbled_deepslate
fill 478 121 276 481 121 276 minecraft:deepslate_tiles
setblock 478 121 316 minecraft:deepslate_tiles
setblock 480 121 278 minecraft:light[level=12]
setblock 480 121 285 minecraft:light[level=12]
setblock 480 121 292 minecraft:light[level=12]
setblock 480 121 299 minecraft:light[level=12]
setblock 480 121 306 minecraft:light[level=12]
setblock 480 121 313 minecraft:light[level=12]
setblock 482 121 276 minecraft:cobbled_deepslate
fill 483 121 276 483 124 276 minecraft:deepslate_tiles
setblock 485 121 277 minecraft:deepslate_tiles
setblock 486 121 277 minecraft:cobbled_deepslate
setblock 487 121 276 minecraft:cobbled_deepslate
fill 487 121 277 489 121 278 minecraft:deepslate_tiles
setblock 487 121 285 minecraft:light[level=12]
setblock 487 121 292 minecraft:light[level=12]
setblock 487 121 299 minecraft:light[level=12]
setblock 487 121 306 minecraft:light[level=12]
setblock 487 121 313 minecraft:light[level=12]
setblock 487 121 316 minecraft:cobbled_deepslate
fill 488 121 276 488 124 276 minecraft:deepslate_tiles
setblock 488 121 315 minecraft:cobbled_deepslate
fill 488 121 316 488 124 316 minecraft:deepslate_tiles
fill 489 121 315 489 122 315 minecraft:deepslate_tiles
setblock 490 121 277 minecraft:deepslate_tiles
setblock 490 121 278 minecraft:cobbled_deepslate
fill 490 121 279 490 124 279 minecraft:deepslate_tiles
setblock 491 121 277 minecraft:cobbled_deepslate
fill 491 121 278 491 124 278 minecraft:deepslate_tiles
setblock 492 121 276 minecraft:cobbled_deepslate
fill 492 121 277 492 124 277 minecraft:deepslate_tiles
fill 492 121 279 493 121 279 minecraft:deepslate_tiles
setblock 492 121 316 minecraft:cobbled_deepslate
fill 493 121 276 493 124 276 minecraft:deepslate_tiles
fill 493 121 313 495 122 313 minecraft:white_wool
setblock 493 121 315 minecraft:cobbled_deepslate
fill 493 121 316 493 124 316 minecraft:deepslate_tiles
setblock 494 121 279 minecraft:cobbled_deepslate
setblock 494 121 285 minecraft:light[level=12]
setblock 494 121 292 minecraft:light[level=12]
setblock 494 121 299 minecraft:light[level=12]
setblock 494 121 306 minecraft:light[level=12]
fill 494 121 312 494 122 312 minecraft:white_wool
fill 494 121 314 494 122 314 minecraft:white_wool
fill 494 121 315 494 122 315 minecraft:deepslate_tiles
setblock 495 121 278 minecraft:cobbled_deepslate
setblock 496 121 277 minecraft:cobbled_deepslate
fill 496 121 278 496 123 278 minecraft:deepslate_tiles
setblock 497 121 276 minecraft:cobbled_deepslate
fill 497 121 277 500 121 277 minecraft:deepslate_tiles
setblock 497 121 316 minecraft:cobbled_deepslate
fill 498 121 276 501 121 276 minecraft:deepslate_tiles
fill 498 121 278 498 122 278 minecraft:deepslate_tiles
setblock 498 121 315 minecraft:cobbled_deepslate
fill 498 121 316 498 124 316 minecraft:deepslate_tiles
setblock 501 121 277 minecraft:cobbled_deepslate
setblock 501 121 278 minecraft:light[level=12]
setblock 501 121 285 minecraft:light[level=12]
setblock 501 121 292 minecraft:light[level=12]
setblock 501 121 299 minecraft:light[level=12]
setblock 501 121 306 minecraft:light[level=12]
setblock 501 121 313 minecraft:light[level=12]
setblock 502 121 276 minecraft:cobbled_deepslate
fill 502 121 277 502 124 277 minecraft:deepslate_tiles
setblock 502 121 316 minecraft:cobbled_deepslate
fill 503 121 276 503 124 276 minecraft:deepslate_tiles
setblock 503 121 315 minecraft:cobbled_deepslate
fill 503 121 316 503 124 316 minecraft:deepslate_tiles
fill 504 121 290 505 122 290 minecraft:white_wool
fill 504 121 315 504 123 315 minecraft:deepslate_tiles
setblock 505 121 291 minecraft:white_wool
setblock 505 121 292 minecraft:black_concrete
setblock 506 121 277 minecraft:cobbled_deepslate
fill 506 121 278 506 124 278 minecraft:deepslate_tiles
setblock 506 121 290 minecraft:black_concrete
setblock 507 121 276 minecraft:cobbled_deepslate
fill 507 121 277 507 124 277 minecraft:deepslate_tiles
setblock 507 121 316 minecraft:cobbled_deepslate
fill 508 121 276 508 124 276 minecraft:deepslate_tiles
fill 508 121 281 508 123 281 minecraft:black_concrete
fill 508 121 283 508 123 283 minecraft:black_concrete
setblock 508 121 285 minecraft:light[level=12]
setblock 508 121 292 minecraft:light[level=12]
setblock 508 121 299 minecraft:light[level=12]
setblock 508 121 306 minecraft:light[level=12]
setblock 508 121 313 minecraft:light[level=12]
setblock 508 121 315 minecraft:cobbled_deepslate
fill 508 121 316 508 124 316 minecraft:deepslate_tiles
setblock 509 121 279 minecraft:cobbled_deepslate
setblock 509 121 299 minecraft:cobbled_deepslate
fill 509 121 300 510 123 300 minecraft:deepslate_tiles
setblock 509 121 314 minecraft:cobbled_deepslate
fill 509 121 315 509 124 315 minecraft:deepslate_tiles
setblock 510 121 278 minecraft:cobbled_deepslate
fill 510 121 279 510 124 279 minecraft:deepslate_tiles
fill 510 121 283 510 123 283 minecraft:black_concrete
setblock 510 121 293 minecraft:cobbled_deepslate
fill 510 121 294 510 123 294 minecraft:deepslate_tiles
setblock 510 121 298 minecraft:cobbled_deepslate
fill 510 121 299 510 124 299 minecraft:deepslate_tiles
fill 510 121 301 510 121 302 minecraft:deepslate_tiles
setblock 510 121 303 minecraft:cobbled_deepslate
fill 510 121 304 510 124 304 minecraft:deepslate_tiles
setblock 510 121 308 minecraft:cobbled_deepslate
fill 510 121 309 510 124 309 minecraft:deepslate_tiles
setblock 510 121 313 minecraft:cobbled_deepslate
fill 510 121 314 510 124 314 minecraft:deepslate_tiles
setblock 511 121 277 minecraft:cobbled_deepslate
fill 511 121 278 511 124 278 minecraft:deepslate_tiles
setblock 511 121 282 minecraft:cobbled_deepslate
fill 511 121 283 511 124 283 minecraft:deepslate_tiles
setblock 511 121 288 minecraft:deepslate_tiles
setblock 511 121 292 minecraft:cobbled_deepslate
fill 511 121 293 511 124 293 minecraft:deepslate_tiles
setblock 511 121 297 minecraft:cobbled_deepslate
fill 511 121 298 511 124 298 minecraft:deepslate_tiles
setblock 511 121 302 minecraft:cobbled_deepslate
fill 511 121 303 511 124 303 minecraft:deepslate_tiles
setblock 511 121 307 minecraft:cobbled_deepslate
fill 511 121 308 511 124 308 minecraft:deepslate_tiles
setblock 511 121 312 minecraft:cobbled_deepslate
fill 511 121 313 511 124 313 minecraft:deepslate_tiles
fill 511 121 317 511 201 317 minecraft:black_concrete
setblock 471 122 276 minecraft:cobbled_deepslate
fill 471 122 277 471 125 277 minecraft:deepslate_tiles
setblock 471 122 281 minecraft:cobbled_deepslate
fill 471 122 282 471 125 282 minecraft:deepslate_tiles
setblock 471 122 287 minecraft:deepslate_tiles
setblock 471 122 291 minecraft:cobbled_deepslate
fill 471 122 292 471 125 292 minecraft:deepslate_tiles
setblock 471 122 296 minecraft:cobbled_deepslate
fill 471 122 297 471 125 297 minecraft:deepslate_tiles
setblock 471 122 301 minecraft:cobbled_deepslate
fill 471 122 302 471 125 302 minecraft:deepslate_tiles
setblock 471 122 306 minecraft:cobbled_deepslate
fill 471 122 307 471 125 307 minecraft:deepslate_tiles
setblock 471 122 311 minecraft:cobbled_deepslate
fill 471 122 312 471 125 312 minecraft:deepslate_tiles
setblock 471 122 316 minecraft:cobbled_deepslate
fill 472 122 276 472 125 276 minecraft:deepslate_tiles
setblock 472 122 280 minecraft:cobbled_deepslate
setblock 472 122 291 minecraft:deepslate_tiles
setblock 472 122 295 minecraft:cobbled_deepslate
fill 472 122 296 472 125 296 minecraft:deepslate_tiles
setblock 472 122 300 minecraft:cobbled_deepslate
fill 472 122 301 472 125 301 minecraft:deepslate_tiles
setblock 472 122 305 minecraft:cobbled_deepslate
fill 472 122 306 472 125 306 minecraft:deepslate_tiles
setblock 472 122 310 minecraft:cobbled_deepslate
setblock 472 122 311 minecraft:deepslate_tiles
setblock 472 122 315 minecraft:cobbled_deepslate
fill 472 122 316 472 125 316 minecraft:deepslate_tiles
setblock 473 122 294 minecraft:cobbled_deepslate
fill 473 122 295 473 123 295 minecraft:deepslate_tiles
setblock 473 122 299 minecraft:cobbled_deepslate
fill 473 122 300 473 125 300 minecraft:deepslate_tiles
setblock 473 122 304 minecraft:cobbled_deepslate
setblock 473 122 315 minecraft:deepslate_tiles
setblock 474 122 298 minecraft:cobbled_deepslate
setblock 474 122 299 minecraft:deepslate_tiles
setblock 476 122 276 minecraft:cobbled_deepslate
setblock 476 122 316 minecraft:cobbled_deepslate
fill 477 122 276 478 122 276 minecraft:deepslate_tiles
setblock 477 122 316 minecraft:deepslate_tiles
setblock 481 122 276 minecraft:cobbled_deepslate
fill 482 122 276 482 125 276 minecraft:deepslate_tiles
setblock 484 122 277 minecraft:deepslate_tiles
setblock 485 122 277 minecraft:cobbled_deepslate
setblock 486 122 276 minecraft:cobbled_deepslate
fill 486 122 277 489 122 277 minecraft:deepslate_tiles
setblock 486 122 316 minecraft:cobbled_deepslate
fill 487 122 276 487 125 276 minecraft:deepslate_tiles
fill 487 122 278 488 122 278 minecraft:deepslate_tiles
fill 487 122 316 487 125 316 minecraft:deepslate_tiles
setblock 489 122 275 minecraft:redstone_block
setblock 489 122 278 minecraft:cobbled_deepslate
fill 489 122 279 489 125 279 minecraft:deepslate_tiles
setblock 490 122 277 minecraft:cobbled_deepslate
fill 490 122 278 490 125 278 minecraft:deepslate_tiles
setblock 491 122 276 minecraft:cobbled_deepslate
fill 491 122 277 491 125 277 minecraft:deepslate_tiles
setblock 491 122 316 minecraft:cobbled_deepslate
fill 492 122 276 492 125 276 minecraft:deepslate_tiles
setblock 492 122 279 minecraft:deepslate_tiles
setblock 492 122 315 minecraft:cobbled_deepslate
fill 492 122 316 492 125 316 minecraft:deepslate_tiles
setblock 493 122 279 minecraft:cobbled_deepslate
setblock 493 122 315 minecraft:deepslate_tiles
setblock 494 122 278 minecraft:cobbled_deepslate
setblock 494 122 279 minecraft:deepslate_tiles
setblock 495 122 277 minecraft:cobbled_deepslate
fill 495 122 278 495 124 278 minecraft:deepslate_tiles
setblock 496 122 276 minecraft:cobbled_deepslate
fill 496 122 277 499 122 277 minecraft:deepslate_tiles
setblock 496 122 316 minecraft:cobbled_deepslate
fill 497 122 276 500 122 276 minecraft:deepslate_tiles
fill 497 122 316 497 124 316 minecraft:deepslate_tiles
setblock 500 122 277 minecraft:cobbled_deepslate
setblock 501 122 276 minecraft:cobbled_deepslate
fill 501 122 277 501 125 277 minecraft:deepslate_tiles
setblock 501 122 316 minecraft:cobbled_deepslate
fill 502 122 276 502 125 276 minecraft:deepslate_tiles
fill 502 122 316 502 125 316 minecraft:deepslate_tiles
setblock 503 122 315 minecraft:deepslate_tiles
setblock 505 122 277 minecraft:cobbled_deepslate
setblock 506 122 276 minecraft:cobbled_deepslate
fill 506 122 277 506 125 277 minecraft:deepslate_tiles
setblock 506 122 316 minecraft:cobbled_deepslate
fill 507 122 276 507 125 276 minecraft:deepslate_tiles
setblock 507 122 315 minecraft:cobbled_deepslate
fill 507 122 316 507 125 316 minecraft:deepslate_tiles
setblock 508 122 278 minecraft:deepslate_tiles
fill 508 122 288 508 127 288 minecraft:black_concrete
setblock 508 122 314 minecraft:cobbled_deepslate
fill 508 122 315 508 125 315 minecraft:deepslate_tiles
setblock 509 122 278 minecraft:cobbled_deepslate
fill 509 122 279 509 123 279 minecraft:deepslate_tiles
setblock 509 122 297 minecraft:deepslate_tiles
setblock 509 122 298 minecraft:cobbled_deepslate
fill 509 122 299 509 125 299 minecraft:deepslate_tiles
fill 509 122 301 510 122 301 minecraft:deepslate_tiles
setblock 509 122 313 minecraft:cobbled_deepslate
fill 509 122 314 509 124 314 minecraft:deepslate_tiles
setblock 510 122 277 minecraft:cobbled_deepslate
fill 510 122 278 510 125 278 minecraft:deepslate_tiles
setblock 510 122 281 minecraft:deepslate_tiles
setblock 510 122 293 minecraft:deepslate_tiles
setblock 510 122 297 minecraft:cobbled_deepslate
fill 510 122 298 510 125 298 minecraft:deepslate_tiles
setblock 510 122 302 minecraft:cobbled_deepslate
fill 510 122 303 510 125 303 minecraft:deepslate_tiles
setblock 510 122 307 minecraft:cobbled_deepslate
fill 510 122 308 510 125 308 minecraft:deepslate_tiles
setblock 510 122 312 minecraft:cobbled_deepslate
fill 510 122 313 510 125 313 minecraft:deepslate_tiles
setblock 511 122 276 minecraft:cobbled_deepslate
fill 511 122 277 511 125 277 minecraft:deepslate_tiles
setblock 511 122 281 minecraft:cobbled_deepslate
fill 511 122 282 511 125 282 minecraft:deepslate_tiles
setblock 511 122 291 minecraft:cobbled_deepslate
fill 511 122 292 511 123 292 minecraft:deepslate_tiles
setblock 511 122 296 minecraft:cobbled_deepslate
fill 511 122 297 511 125 297 minecraft:deepslate_tiles
setblock 511 122 301 minecraft:cobbled_deepslate
fill 511 122 302 511 125 302 minecraft:deepslate_tiles
setblock 511 122 306 minecraft:cobbled_deepslate
fill 511 122 307 511 125 307 minecraft:deepslate_tiles
setblock 511 122 311 minecraft:cobbled_deepslate
fill 511 122 312 511 125 312 minecraft:deepslate_tiles
setblock 511 122 316 minecraft:cobbled_deepslate
fill 471 123 276 471 126 276 minecraft:deepslate_tiles
setblock 471 123 280 minecraft:cobbled_deepslate
fill 471 123 281 471 126 281 minecraft:deepslate_tiles
setblock 471 123 290 minecraft:cobbled_deepslate
fill 471 123 291 471 125 291 minecraft:deepslate_tiles
setblock 471 123 295 minecraft:cobbled_deepslate
fill 471 123 296 471 126 296 minecraft:deepslate_tiles
setblock 471 123 300 minecraft:cobbled_deepslate
fill 471 123 301 471 126 301 minecraft:deepslate_tiles
setblock 471 123 305 minecraft:cobbled_deepslate
fill 471 123 306 471 126 306 minecraft:deepslate_tiles
setblock 471 123 310 minecraft:cobbled_deepslate
fill 471 123 311 471 125 311 minecraft:deepslate_tiles
setblock 471 123 315 minecraft:cobbled_deepslate
fill 471 123 316 471 126 316 minecraft:deepslate_tiles
setblock 472 123 279 minecraft:cobbled_deepslate
setblock 472 123 294 minecraft:cobbled_deepslate
fill 472 123 295 472 126 295 minecraft:deepslate_tiles
setblock 472 123 299 minecraft:cobbled_deepslate
fill 472 123 300 472 126 300 minecraft:deepslate_tiles
setblock 472 123 304 minecraft:cobbled_deepslate
fill 472 123 305 472 126 305 minecraft:deepslate_tiles
setblock 472 123 314 minecraft:cobbled_deepslate
setblock 472 123 315 minecraft:deepslate_tiles
setblock 473 123 294 minecraft:deepslate_tiles
setblock 473 123 298 minecraft:cobbled_deepslate
fill 473 123 299 473 126 299 minecraft:deepslate_tiles
setblock 473 123 303 minecraft:cobbled_deepslate
setblock 473 123 304 minecraft:deepslate_tiles
setblock 475 123 276 minecraft:cobbled_deepslate
setblock 475 123 316 minecraft:cobbled_deepslate
setblock 476 123 276 minecraft:deepslate_tiles
setblock 484 123 277 minecraft:cobbled_deepslate
setblock 485 123 276 minecraft:cobbled_deepslate
fill 485 123 277 488 123 277 minecraft:deepslate_tiles
fill 486 123 276 486 126 276 minecraft:deepslate_tiles
fill 486 123 278 487 123 278 minecraft:deepslate_tiles
fill 486 123 316 486 124 316 minecraft:deepslate_tiles
setblock 488 123 278 minecraft:cobbled_deepslate
fill 489 123 275 489 201 275 minecraft:black_concrete
setblock 489 123 277 minecraft:cobbled_deepslate
fill 489 123 278 489 126 278 minecraft:deepslate_tiles
setblock 490 123 276 minecraft:cobbled_deepslate
fill 490 123 277 490 126 277 minecraft:deepslate_tiles
setblock 490 123 316 minecraft:cobbled_deepslate
fill 491 123 276 491 126 276 minecraft:deepslate_tiles
setblock 491 123 315 minecraft:cobbled_deepslate
fill 491 123 316 491 126 316 minecraft:deepslate_tiles
setblock 492 123 279 minecraft:cobbled_deepslate
setblock 492 123 315 minecraft:deepslate_tiles
setblock 493 123 278 minecraft:cobbled_deepslate
setblock 493 123 279 minecraft:deepslate_tiles
setblock 494 123 277 minecraft:cobbled_deepslate
fill 494 123 278 494 126 278 minecraft:deepslate_tiles
setblock 495 123 276 minecraft:cobbled_deepslate
fill 495 123 277 498 123 277 minecraft:deepslate_tiles
setblock 495 123 316 minecraft:cobbled_deepslate
fill 496 123 276 499 123 276 minecraft:deepslate_tiles
fill 496 123 316 496 124 316 minecraft:deepslate_tiles
setblock 499 123 277 minecraft:cobbled_deepslate
setblock 500 123 276 minecraft:cobbled_deepslate
fill 500 123 277 500 125 277 minecraft:deepslate_tiles
setblock 500 123 316 minecraft:cobbled_deepslate
fill 501 123 276 501 126 276 minecraft:deepslate_tiles
fill 501 123 316 501 126 316 minecraft:deepslate_tiles
setblock 504 123 277 minecraft:cobbled_deepslate
setblock 505 123 276 minecraft:cobbled_deepslate
fill 505 123 277 505 126 277 minecraft:deepslate_tiles
fill 505 123 290 505 124 290 minecraft:white_wool
setblock 505 123 316 minecraft:cobbled_deepslate
fill 506 123 276 506 126 276 minecraft:deepslate_tiles
setblock 506 123 315 minecraft:cobbled_deepslate
fill 506 123 316 506 126 316 minecraft:deepslate_tiles
setblock 506 123 317 minecraft:redstone_block
setblock 507 123 282 minecraft:black_concrete
fill 507 123 315 507 126 315 minecraft:deepslate_tiles
setblock 508 123 278 minecraft:cobbled_deepslate
setblock 508 123 314 minecraft:deepslate_tiles
setblock 509 123 277 minecraft:cobbled_deepslate
fill 509 123 278 509 125 278 minecraft:deepslate_tiles
setblock 509 123 280 minecraft:black_concrete
setblock 509 123 284 minecraft:black_concrete
fill 509 123 298 509 124 298 minecraft:deepslate_tiles
setblock 509 123 301 minecraft:deepslate_tiles
setblock 509 123 302 minecraft:cobbled_deepslate
setblock 509 123 313 minecraft:deepslate_tiles
setblock 510 123 276 minecraft:cobbled_deepslate
fill 510 123 277 510 126 277 minecraft:deepslate_tiles
setblock 510 123 281 minecraft:cobbled_deepslate
setblock 510 123 296 minecraft:cobbled_deepslate
fill 510 123 297 510 126 297 minecraft:deepslate_tiles
setblock 510 123 301 minecraft:cobbled_deepslate
fill 510 123 302 510 126 302 minecraft:deepslate_tiles
setblock 510 123 306 minecraft:cobbled_deepslate
fill 510 123 307 510 126 307 minecraft:deepslate_tiles
setblock 510 123 311 minecraft:cobbled_deepslate
fill 510 123 312 510 126 312 minecraft:deepslate_tiles
setblock 510 123 316 minecraft:cobbled_deepslate
fill 511 123 276 511 126 276 minecraft:deepslate_tiles
setblock 511 123 280 minecraft:cobbled_deepslate
fill 511 123 281 511 126 281 minecraft:deepslate_tiles
setblock 511 123 291 minecraft:deepslate_tiles
setblock 511 123 295 minecraft:cobbled_deepslate
fill 511 123 296 511 126 296 minecraft:deepslate_tiles
setblock 511 123 300 minecraft:cobbled_deepslate
fill 511 123 301 511 126 301 minecraft:deepslate_tiles
setblock 511 123 305 minecraft:cobbled_deepslate
fill 511 123 306 511 126 306 minecraft:deepslate_tiles
setblock 511 123 310 minecraft:cobbled_deepslate
fill 511 123 311 511 126 311 minecraft:deepslate_tiles
setblock 511 123 315 minecraft:cobbled_deepslate
fill 511 123 316 511 126 316 minecraft:deepslate_tiles
setblock 471 124 279 minecraft:cobbled_deepslate
fill 471 124 280 471 127 280 minecraft:deepslate_tiles
setblock 471 124 284 minecraft:cobbled_deepslate
setblock 471 124 290 minecraft:deepslate_tiles
setblock 471 124 294 minecraft:cobbled_deepslate
fill 471 124 295 471 127 295 minecraft:deepslate_tiles
setblock 471 124 299 minecraft:cobbled_deepslate
fill 471 124 300 471 127 300 minecraft:deepslate_tiles
setblock 471 124 304 minecraft:cobbled_deepslate
fill 471 124 305 471 127 305 minecraft:deepslate_tiles
setblock 471 124 309 minecraft:cobbled_deepslate
fill 471 124 310 471 127 310 minecraft:deepslate_tiles
setblock 471 124 314 minecraft:cobbled_deepslate
fill 471 124 315 471 125 315 minecraft:deepslate_tiles
setblock 472 124 293 minecraft:cobbled_deepslate
fill 472 124 294 472 125 294 minecraft:deepslate_tiles
setblock 472 124 298 minecraft:cobbled_deepslate
fill 472 124 299 472 127 299 minecraft:deepslate_tiles
setblock 472 124 303 minecraft:cobbled_deepslate
fill 472 124 304 472 127 304 minecraft:deepslate_tiles
setblock 473 124 297 minecraft:cobbled_deepslate
fill 473 124 298 473 126 298 minecraft:deepslate_tiles
setblock 473 124 302 minecraft:cobbled_deepslate
fill 473 124 303 473 125 303 minecraft:deepslate_tiles
setblock 474 124 276 minecraft:cobbled_deepslate
setblock 484 124 276 minecraft:cobbled_deepslate
fill 484 124 277 487 124 277 minecraft:deepslate_tiles
fill 485 124 276 485 127 276 minecraft:deepslate_tiles
setblock 486 124 278 minecraft:deepslate_tiles
setblock 487 124 278 minecraft:cobbled_deepslate
setblock 488 124 277 minecraft:cobbled_deepslate
fill 488 124 278 488 127 278 minecraft:deepslate_tiles
setblock 489 124 276 minecraft:cobbled_deepslate
fill 489 124 277 489 127 277 minecraft:deepslate_tiles
setblock 489 124 316 minecraft:cobbled_deepslate
setblock 490 124 275 minecraft:white_wool
fill 490 124 276 490 127 276 minecraft:deepslate_tiles
fill 490 124 316 490 127 316 minecraft:deepslate_tiles
setblock 491 124 279 minecraft:cobbled_deepslate
setblock 492 124 278 minecraft:cobbled_deepslate
setblock 492 124 279 minecraft:deepslate_tiles
setblock 493 124 277 minecraft:cobbled_deepslate
fill 493 124 278 493 127 278 minecraft:deepslate_tiles
setblock 494 124 276 minecraft:cobbled_deepslate
fill 494 124 277 497 124 277 minecraft:deepslate_tiles
setblock 494 124 316 minecraft:cobbled_deepslate
fill 495 124 276 498 124 276 minecraft:deepslate_tiles
fill 495 124 316 495 125 316 minecraft:deepslate_tiles
setblock 498 124 277 minecraft:cobbled_deepslate
setblock 499 124 276 minecraft:cobbled_deepslate
fill 499 124 277 499 125 277 minecraft:deepslate_tiles
setblock 499 124 316 minecraft:cobbled_deepslate
fill 500 124 276 500 127 276 minecraft:deepslate_tiles
setblock 500 124 316 minecraft:deepslate_tiles
setblock 503 124 277 minecraft:cobbled_deepslate
setblock 504 124 276 minecraft:cobbled_deepslate
fill 504 124 277 504 127 277 minecraft:deepslate_tiles
setblock 504 124 316 minecraft:cobbled_deepslate
fill 505 124 276 505 127 276 minecraft:deepslate_tiles
setblock 505 124 315 minecraft:cobbled_deepslate
fill 505 124 316 505 127 316 minecraft:deepslate_tiles
fill 506 124 315 506 127 315 minecraft:deepslate_tiles
fill 506 124 317 506 198 317 minecraft:black_concrete
setblock 507 124 278 minecraft:cobbled_deepslate
setblock 508 124 277 minecraft:cobbled_deepslate
fill 508 124 278 508 125 278 minecraft:deepslate_tiles
setblock 509 124 276 minecraft:cobbled_deepslate
fill 509 124 277 509 127 277 minecraft:deepslate_tiles
setblock 509 124 300 minecraft:deepslate_tiles
setblock 509 124 301 minecraft:cobbled_deepslate
fill 509 124 302 509 126 303 minecraft:deepslate_tiles
setblock 509 124 316 minecraft:cobbled_deepslate
fill 510 124 276 510 127 276 minecraft:deepslate_tiles
setblock 510 124 280 minecraft:cobbled_deepslate
fill 510 124 281 510 127 281 minecraft:deepslate_tiles
setblock 510 124 295 minecraft:cobbled_deepslate
fill 510 124 296 510 126 296 minecraft:deepslate_tiles
setblock 510 124 300 minecraft:cobbled_deepslate
fill 510 124 301 510 127 301 minecraft:deepslate_tiles
setblock 510 124 305 minecraft:cobbled_deepslate
fill 510 124 306 510 127 306 minecraft:deepslate_tiles
setblock 510 124 310 minecraft:cobbled_deepslate
fill 510 124 311 510 127 311 minecraft:deepslate_tiles
setblock 510 124 315 minecraft:cobbled_deepslate
fill 510 124 316 510 127 316 minecraft:deepslate_tiles
setblock 511 124 279 minecraft:cobbled_deepslate
fill 511 124 280 511 127 280 minecraft:deepslate_tiles
setblock 511 124 294 minecraft:cobbled_deepslate
fill 511 124 295 511 127 295 minecraft:deepslate_tiles
setblock 511 124 299 minecraft:cobbled_deepslate
fill 511 124 300 511 127 300 minecraft:deepslate_tiles
setblock 511 124 304 minecraft:cobbled_deepslate
fill 511 124 305 511 127 305 minecraft:deepslate_tiles
setblock 511 124 309 minecraft:cobbled_deepslate
fill 511 124 310 511 127 310 minecraft:deepslate_tiles
setblock 511 124 314 minecraft:cobbled_deepslate
fill 511 124 315 511 127 315 minecraft:deepslate_tiles
setblock 471 125 278 minecraft:cobbled_deepslate
fill 471 125 279 471 128 279 minecraft:deepslate_tiles
setblock 471 125 283 minecraft:cobbled_deepslate
fill 471 125 284 471 128 284 minecraft:deepslate_tiles
setblock 471 125 293 minecraft:cobbled_deepslate
fill 471 125 294 471 128 294 minecraft:deepslate_tiles
setblock 471 125 298 minecraft:cobbled_deepslate
fill 471 125 299 471 128 299 minecraft:deepslate_tiles
setblock 471 125 303 minecraft:cobbled_deepslate
fill 471 125 304 471 128 304 minecraft:deepslate_tiles
setblock 471 125 308 minecraft:cobbled_deepslate
fill 471 125 309 471 128 309 minecraft:deepslate_tiles
setblock 471 125 313 minecraft:cobbled_deepslate
setblock 471 125 314 minecraft:deepslate_tiles
setblock 472 125 297 minecraft:cobbled_deepslate
fill 472 125 298 472 128 298 minecraft:deepslate_tiles
setblock 472 125 302 minecraft:cobbled_deepslate
fill 472 125 303 472 128 303 minecraft:deepslate_tiles
setblock 473 125 276 minecraft:cobbled_deepslate
setblock 473 125 278 minecraft:light[level=13]
setblock 473 125 286 minecraft:light[level=13]
setblock 473 125 294 minecraft:light[level=13]
setblock 473 125 297 minecraft:deepslate_tiles
setblock 473 125 301 minecraft:cobbled_deepslate
fill 473 125 302 473 127 302 minecraft:deepslate_tiles
setblock 473 125 310 minecraft:light[level=13]
setblock 481 125 278 minecraft:light[level=13]
setblock 481 125 286 minecraft:light[level=13]
setblock 481 125 294 minecraft:light[level=13]
setblock 481 125 302 minecraft:light[level=13]
setblock 481 125 310 minecraft:light[level=13]
setblock 483 125 276 minecraft:cobbled_deepslate
fill 484 125 276 484 127 277 minecraft:deepslate_tiles
fill 485 125 277 486 125 277 minecraft:deepslate_tiles
setblock 486 125 278 minecraft:cobbled_deepslate
setblock 487 125 277 minecraft:cobbled_deepslate
fill 487 125 278 487 128 278 minecraft:deepslate_tiles
setblock 488 125 276 minecraft:cobbled_deepslate
fill 488 125 277 488 128 277 minecraft:deepslate_tiles
fill 488 125 279 488 126 279 minecraft:deepslate_tiles
setblock 488 125 316 minecraft:cobbled_deepslate
fill 489 125 276 489 128 276 minecraft:deepslate_tiles
setblock 489 125 286 minecraft:light[level=13]
setblock 489 125 294 minecraft:light[level=13]
setblock 489 125 302 minecraft:light[level=13]
setblock 489 125 310 minecraft:light[level=13]
fill 489 125 316 489 128 316 minecraft:deepslate_tiles
fill 490 125 275 490 156 275 minecraft:black_concrete
setblock 490 125 279 minecraft:cobbled_deepslate
setblock 491 125 278 minecraft:cobbled_deepslate
setblock 491 125 279 minecraft:deepslate_tiles
setblock 492 125 277 minecraft:cobbled_deepslate
fill 492 125 278 492 128 278 minecraft:deepslate_tiles
setblock 493 125 276 minecraft:cobbled_deepslate
fill 493 125 277 496 125 277 minecraft:deepslate_tiles
setblock 493 125 316 minecraft:cobbled_deepslate
fill 494 125 276 497 125 276 minecraft:deepslate_tiles
setblock 494 125 316 minecraft:deepslate_tiles
setblock 497 125 277 minecraft:cobbled_deepslate
setblock 497 125 278 minecraft:light[level=13]
setblock 497 125 286 minecraft:light[level=13]
setblock 497 125 294 minecraft:light[level=13]
setblock 497 125 302 minecraft:light[level=13]
setblock 497 125 310 minecraft:light[level=13]
setblock 498 125 276 minecraft:cobbled_deepslate
setblock 498 125 277 minecraft:deepslate_tiles
fill 499 125 276 499 128 276 minecraft:deepslate_tiles
setblock 502 125 277 minecraft:cobbled_deepslate
setblock 503 125 276 minecraft:cobbled_deepslate
fill 503 125 277 503 128 277 minecraft:deepslate_tiles
setblock 503 125 316 minecraft:cobbled_deepslate
fill 504 125 276 504 128 276 minecraft:deepslate_tiles
fill 504 125 316 504 128 316 minecraft:deepslate_tiles
setblock 505 125 278 minecraft:light[level=13]
setblock 505 125 286 minecraft:light[level=13]
setblock 505 125 294 minecraft:light[level=13]
setblock 505 125 302 minecraft:light[level=13]
setblock 505 125 310 minecraft:light[level=13]
fill 505 125 315 505 128 315 minecraft:deepslate_tiles
setblock 507 125 277 minecraft:cobbled_deepslate
setblock 507 125 278 minecraft:deepslate_tiles
fill 507 125 288 507 127 288 minecraft:black_concrete
setblock 508 125 276 minecraft:cobbled_deepslate
fill 508 125 277 508 128 277 minecraft:deepslate_tiles
fill 508 125 287 508 127 287 minecraft:black_concrete
fill 508 125 289 508 127 289 minecraft:black_concrete
setblock 508 125 316 minecraft:cobbled_deepslate
fill 509 125 276 509 128 276 minecraft:deepslate_tiles
fill 509 125 288 509 127 288 minecraft:black_concrete
setblock 509 125 300 minecraft:cobbled_deepslate
fill 509 125 301 509 128 301 minecraft:deepslate_tiles
setblock 509 125 304 minecraft:deepslate_tiles
setblock 509 125 315 minecraft:cobbled_deepslate
fill 509 125 316 509 128 316 minecraft:deepslate_tiles
setblock 510 125 279 minecraft:cobbled_deepslate
fill 510 125 280 510 128 280 minecraft:deepslate_tiles
setblock 510 125 299 minecraft:cobbled_deepslate
fill 510 125 300 510 128 300 minecraft:deepslate_tiles
setblock 510 125 304 minecraft:cobbled_deepslate
fill 510 125 305 510 128 305 minecraft:deepslate_tiles
setblock 510 125 309 minecraft:cobbled_deepslate
fill 510 125 310 510 128 310 minecraft:deepslate_tiles
setblock 510 125 314 minecraft:cobbled_deepslate
fill 510 125 315 510 127 315 minecraft:deepslate_tiles
setblock 511 125 278 minecraft:cobbled_deepslate
fill 511 125 279 511 128 279 minecraft:deepslate_tiles
setblock 511 125 283 minecraft:cobbled_deepslate
fill 511 125 294 511 126 294 minecraft:deepslate_tiles
setblock 511 125 298 minecraft:cobbled_deepslate
fill 511 125 299 511 128 299 minecraft:deepslate_tiles
setblock 511 125 303 minecraft:cobbled_deepslate
fill 511 125 304 511 128 304 minecraft:deepslate_tiles
setblock 511 125 308 minecraft:cobbled_deepslate
fill 511 125 309 511 128 309 minecraft:deepslate_tiles
setblock 511 125 313 minecraft:cobbled_deepslate
fill 511 125 314 511 128 314 minecraft:deepslate_tiles
setblock 471 126 277 minecraft:cobbled_deepslate
fill 471 126 278 471 129 278 minecraft:deepslate_tiles
setblock 471 126 282 minecraft:cobbled_deepslate
setblock 471 126 283 minecraft:deepslate_tiles
setblock 471 126 292 minecraft:cobbled_deepslate
fill 471 126 293 471 129 293 minecraft:deepslate_tiles
setblock 471 126 297 minecraft:cobbled_deepslate
fill 471 126 298 471 129 298 minecraft:deepslate_tiles
setblock 471 126 302 minecraft:cobbled_deepslate
fill 471 126 303 471 129 303 minecraft:deepslate_tiles
setblock 471 126 307 minecraft:cobbled_deepslate
fill 471 126 308 471 129 308 minecraft:deepslate_tiles
setblock 472 126 276 minecraft:cobbled_deepslate
setblock 472 126 296 minecraft:cobbled_deepslate
fill 472 126 297 472 129 297 minecraft:deepslate_tiles
setblock 472 126 301 minecraft:cobbled_deepslate
fill 472 126 302 472 129 302 minecraft:deepslate_tiles
setblock 472 126 306 minecraft:cobbled_deepslate
setblock 473 126 300 minecraft:cobbled_deepslate
fill 473 126 301 473 127 301 minecraft:deepslate_tiles
setblock 475 126 279 minecraft:white_wool
setblock 476 126 278 minecraft:white_wool
setblock 477 126 277 minecraft:white_wool
setblock 478 126 276 minecraft:white_wool
setblock 482 126 276 minecraft:cobbled_deepslate
fill 483 126 276 483 129 276 minecraft:deepslate_tiles
setblock 485 126 277 minecraft:deepslate_tiles
setblock 485 126 278 minecraft:cobbled_deepslate
setblock 486 126 277 minecraft:cobbled_deepslate
fill 486 126 278 486 129 278 minecraft:deepslate_tiles
setblock 487 126 276 minecraft:cobbled_deepslate
fill 487 126 277 487 129 277 minecraft:deepslate_tiles
setblock 487 126 316 minecraft:cobbled_deepslate
fill 488 126 276 488 129 276 minecraft:deepslate_tiles
fill 488 126 316 488 129 316 minecraft:deepslate_tiles
setblock 489 126 279 minecraft:cobbled_deepslate
setblock 490 126 278 minecraft:cobbled_deepslate
fill 490 126 279 490 128 279 minecraft:deepslate_tiles
setblock 491 126 277 minecraft:cobbled_deepslate
fill 491 126 278 491 129 278 minecraft:deepslate_tiles
setblock 492 126 276 minecraft:cobbled_deepslate
fill 492 126 277 495 126 277 minecraft:deepslate_tiles
setblock 492 126 316 minecraft:cobbled_deepslate
fill 493 126 276 496 126 276 minecraft:deepslate_tiles
setblock 493 126 316 minecraft:deepslate_tiles
setblock 496 126 277 minecraft:cobbled_deepslate
setblock 497 126 276 minecraft:cobbled_deepslate
setblock 497 126 277 minecraft:deepslate_tiles
fill 498 126 276 498 129 276 minecraft:deepslate_tiles
setblock 502 126 276 minecraft:cobbled_deepslate
fill 502 126 277 502 129 277 minecraft:deepslate_tiles
setblock 502 126 316 minecraft:cobbled_deepslate
fill 503 126 276 503 128 276 minecraft:deepslate_tiles
fill 503 126 316 503 129 316 minecraft:deepslate_tiles
setblock 506 126 277 minecraft:cobbled_deepslate
setblock 507 126 276 minecraft:cobbled_deepslate
fill 507 126 277 507 129 277 minecraft:deepslate_tiles
setblock 507 126 316 minecraft:cobbled_deepslate
fill 508 126 276 508 129 276 minecraft:deepslate_tiles
setblock 508 126 315 minecraft:cobbled_deepslate
fill 508 126 316 508 129 316 minecraft:deepslate_tiles
setblock 509 126 299 minecraft:cobbled_deepslate
fill 509 126 300 509 129 300 minecraft:deepslate_tiles
setblock 509 126 304 minecraft:cobbled_deepslate
fill 509 126 305 509 129 305 minecraft:deepslate_tiles
fill 509 126 315 509 129 315 minecraft:deepslate_tiles
setblock 510 126 278 minecraft:cobbled_deepslate
fill 510 126 279 510 129 279 minecraft:deepslate_tiles
setblock 510 126 298 minecraft:cobbled_deepslate
fill 510 126 299 510 129 299 minecraft:deepslate_tiles
setblock 510 126 303 minecraft:cobbled_deepslate
fill 510 126 304 510 129 304 minecraft:deepslate_tiles
setblock 510 126 308 minecraft:cobbled_deepslate
fill 510 126 309 510 129 309 minecraft:deepslate_tiles
setblock 510 126 313 minecraft:cobbled_deepslate
setblock 510 126 314 minecraft:deepslate_tiles
setblock 511 126 277 minecraft:cobbled_deepslate
fill 511 126 278 511 129 278 minecraft:deepslate_tiles
setblock 511 126 282 minecraft:cobbled_deepslate
fill 511 126 283 511 129 283 minecraft:deepslate_tiles
setblock 511 126 297 minecraft:cobbled_deepslate
fill 511 126 298 511 129 298 minecraft:deepslate_tiles
setblock 511 126 302 minecraft:cobbled_deepslate
fill 511 126 303 511 129 303 minecraft:deepslate_tiles
setblock 511 126 307 minecraft:cobbled_deepslate
fill 511 126 308 511 129 308 minecraft:deepslate_tiles
setblock 511 126 312 minecraft:cobbled_deepslate
fill 511 126 313 511 129 313 minecraft:deepslate_tiles
setblock 471 127 276 minecraft:cobbled_deepslate
fill 471 127 277 471 128 277 minecraft:deepslate_tiles
setblock 471 127 281 minecraft:cobbled_deepslate
fill 471 127 282 471 130 282 minecraft:deepslate_tiles
setblock 471 127 283 minecraft:white_wool
setblock 471 127 285 minecraft:deepslate_tiles
fill 471 127 292 471 130 292 minecraft:deepslate_tiles
setblock 471 127 296 minecraft:cobbled_deepslate
fill 471 127 297 471 130 297 minecraft:deepslate_tiles
setblock 471 127 301 minecraft:cobbled_deepslate
fill 471 127 302 471 130 302 minecraft:deepslate_tiles
setblock 471 127 306 minecraft:cobbled_deepslate
fill 471 127 307 471 130 307 minecraft:deepslate_tiles
setblock 472 127 282 minecraft:white_wool
fill 472 127 296 472 128 296 minecraft:deepslate_tiles
setblock 472 127 300 minecraft:cobbled_deepslate
fill 472 127 301 472 130 301 minecraft:deepslate_tiles
setblock 472 127 305 minecraft:cobbled_deepslate
fill 472 127 306 472 130 306 minecraft:deepslate_tiles
setblock 473 127 278 minecraft:light[level=12]
setblock 473 127 281 minecraft:white_wool
setblock 473 127 285 minecraft:light[level=12]
setblock 473 127 292 minecraft:light[level=12]
setblock 473 127 299 minecraft:light[level=12]
setblock 473 127 300 minecraft:deepslate_tiles
setblock 473 127 306 minecraft:light[level=12]
setblock 473 127 313 minecraft:light[level=12]
setblock 474 127 280 minecraft:white_wool
fill 474 127 317 474 158 317 minecraft:black_concrete
setblock 475 127 317 minecraft:redstone_block
fill 476 127 317 477 201 317 minecraft:black_concrete
setblock 480 127 278 minecraft:light[level=12]
setblock 480 127 285 minecraft:light[level=12]
setblock 480 127 292 minecraft:light[level=12]
setblock 480 127 299 minecraft:light[level=12]
setblock 480 127 306 minecraft:light[level=12]
setblock 480 127 313 minecraft:light[level=12]
fill 482 127 276 482 130 276 minecraft:deepslate_tiles
fill 483 127 277 483 128 277 minecraft:deepslate_tiles
setblock 483 127 317 minecraft:redstone_block
setblock 485 127 277 minecraft:cobbled_deepslate
fill 485 127 278 485 130 278 minecraft:deepslate_tiles
setblock 486 127 276 minecraft:cobbled_deepslate
fill 486 127 277 486 130 277 minecraft:deepslate_tiles
fill 487 127 276 487 130 276 minecraft:deepslate_tiles
setblock 487 127 279 minecraft:deepslate_tiles
setblock 487 127 285 minecraft:light[level=12]
setblock 487 127 292 minecraft:light[level=12]
setblock 487 127 299 minecraft:light[level=12]
setblock 487 127 306 minecraft:light[level=12]
setblock 487 127 313 minecraft:light[level=12]
fill 487 127 316 487 130 316 minecraft:deepslate_tiles
setblock 488 127 279 minecraft:cobbled_deepslate
setblock 489 127 278 minecraft:cobbled_deepslate
fill 489 127 279 489 130 279 minecraft:deepslate_tiles
setblock 490 127 277 minecraft:cobbled_deepslate
fill 490 127 278 490 130 278 minecraft:deepslate_tiles
setblock 491 127 276 minecraft:cobbled_deepslate
fill 491 127 277 494 127 277 minecraft:deepslate_tiles
setblock 491 127 316 minecraft:cobbled_deepslate
fill 492 127 276 495 127 276 minecraft:deepslate_tiles
setblock 494 127 278 minecraft:light[level=12]
setblock 494 127 285 minecraft:light[level=12]
setblock 494 127 292 minecraft:light[level=12]
setblock 494 127 299 minecraft:light[level=12]
setblock 494 127 306 minecraft:light[level=12]
setblock 494 127 313 minecraft:light[level=12]
setblock 495 127 277 minecraft:cobbled_deepslate
setblock 496 127 276 minecraft:cobbled_deepslate
setblock 496 127 277 minecraft:deepslate_tiles
fill 497 127 276 497 130 276 minecraft:deepslate_tiles
setblock 501 127 276 minecraft:cobbled_deepslate
setblock 501 127 278 minecraft:light[level=12]
setblock 501 127 285 minecraft:light[level=12]
setblock 501 127 292 minecraft:light[level=12]
setblock 501 127 299 minecraft:light[level=12]
setblock 501 127 306 minecraft:light[level=12]
setblock 501 127 313 minecraft:light[level=12]
fill 502 127 276 502 130 276 minecraft:deepslate_tiles
fill 502 127 316 502 130 316 minecraft:deepslate_tiles
setblock 505 127 277 minecraft:cobbled_deepslate
setblock 506 127 276 minecraft:cobbled_deepslate
fill 506 127 277 506 130 277 minecraft:deepslate_tiles
setblock 506 127 316 minecraft:cobbled_deepslate
fill 507 127 276 507 130 276 minecraft:deepslate_tiles
setblock 507 127 287 minecraft:black_concrete
setblock 507 127 289 minecraft:black_concrete
setblock 507 127 315 minecraft:cobbled_deepslate
fill 507 127 316 507 130 316 minecraft:deepslate_tiles
setblock 508 127 278 minecraft:light[level=12]
setblock 508 127 285 minecraft:light[level=12]
setblock 508 127 292 minecraft:light[level=12]
setblock 508 127 299 minecraft:light[level=12]
setblock 508 127 306 minecraft:light[level=12]
setblock 508 127 313 minecraft:light[level=12]
fill 508 127 315 508 130 315 minecraft:deepslate_tiles
setblock 509 127 287 minecraft:black_concrete
setblock 509 127 289 minecraft:black_concrete
fill 509 127 299 509 130 299 minecraft:deepslate_tiles
setblock 509 127 302 minecraft:deepslate_tiles
setblock 509 127 303 minecraft:cobbled_deepslate
fill 509 127 304 509 130 304 minecraft:deepslate_tiles
fill 509 127 306 509 127 307 minecraft:deepslate_tiles
setblock 510 127 277 minecraft:cobbled_deepslate
fill 510 127 278 510 128 278 minecraft:deepslate_tiles
setblock 510 127 297 minecraft:cobbled_deepslate
fill 510 127 298 510 130 298 minecraft:deepslate_tiles
setblock 510 127 302 minecraft:cobbled_deepslate
fill 510 127 303 510 130 303 minecraft:deepslate_tiles
setblock 510 127 307 minecraft:cobbled_deepslate
fill 510 127 308 510 130 308 minecraft:deepslate_tiles
setblock 511 127 276 minecraft:cobbled_deepslate
fill 511 127 277 511 130 277 minecraft:deepslate_tiles
setblock 511 127 281 minecraft:cobbled_deepslate
fill 511 127 282 511 130 282 minecraft:deepslate_tiles
setblock 511 127 296 minecraft:cobbled_deepslate
fill 511 127 297 511 130 297 minecraft:deepslate_tiles
setblock 511 127 301 minecraft:cobbled_deepslate
fill 511 127 302 511 130 302 minecraft:deepslate_tiles
setblock 511 127 306 minecraft:cobbled_deepslate
fill 511 127 307 511 130 307 minecraft:deepslate_tiles
setblock 511 127 311 minecraft:cobbled_deepslate
fill 511 127 312 511 130 312 minecraft:deepslate_tiles
setblock 511 127 316 minecraft:cobbled_deepslate
setblock 512 127 303 minecraft:redstone_block
fill 470 128 308 470 129 311 minecraft:black_concrete
setblock 470 128 312 minecraft:white_wool
fill 470 128 313 470 149 315 minecraft:black_concrete
setblock 471 128 280 minecraft:cobbled_deepslate
fill 471 128 281 471 131 281 minecraft:deepslate_tiles
fill 471 128 283 471 129 283 minecraft:deepslate_tiles
setblock 471 128 285 minecraft:cobbled_deepslate
fill 471 128 286 471 130 287 minecraft:deepslate_tiles
setblock 471 128 295 minecraft:cobbled_deepslate
fill 471 128 296 471 131 296 minecraft:deepslate_tiles
setblock 471 128 300 minecraft:cobbled_deepslate
fill 471 128 301 471 131 301 minecraft:deepslate_tiles
setblock 471 128 305 minecraft:cobbled_deepslate
fill 471 128 306 471 131 306 minecraft:deepslate_tiles
setblock 471 128 310 minecraft:cobbled_deepslate
setblock 472 128 299 minecraft:cobbled_deepslate
fill 472 128 300 472 131 300 minecraft:deepslate_tiles
setblock 472 128 304 minecraft:cobbled_deepslate
fill 472 128 305 472 131 305 minecraft:deepslate_tiles
fill 475 128 317 475 192 317 minecraft:black_concrete
fill 483 128 317 483 201 317 minecraft:black_concrete
setblock 484 128 276 minecraft:deepslate_tiles
setblock 484 128 277 minecraft:cobbled_deepslate
fill 484 128 278 484 131 278 minecraft:deepslate_tiles
setblock 485 128 276 minecraft:cobbled_deepslate
fill 485 128 277 485 131 277 minecraft:deepslate_tiles
fill 486 128 276 486 131 276 minecraft:deepslate_tiles
setblock 486 128 279 minecraft:deepslate_tiles
setblock 487 128 279 minecraft:cobbled_deepslate
setblock 488 128 278 minecraft:cobbled_deepslate
fill 488 128 279 488 131 279 minecraft:deepslate_tiles
setblock 489 128 277 minecraft:cobbled_deepslate
fill 489 128 278 489 131 278 minecraft:deepslate_tiles
setblock 490 128 276 minecraft:cobbled_deepslate
fill 490 128 277 493 128 277 minecraft:deepslate_tiles
setblock 490 128 316 minecraft:cobbled_deepslate
fill 491 128 276 494 128 276 minecraft:deepslate_tiles
setblock 494 128 277 minecraft:cobbled_deepslate
setblock 495 128 276 minecraft:cobbled_deepslate
setblock 495 128 277 minecraft:deepslate_tiles
fill 496 128 276 496 131 276 minecraft:deepslate_tiles
setblock 500 128 276 minecraft:cobbled_deepslate
fill 501 128 276 501 131 276 minecraft:deepslate_tiles
fill 501 128 316 501 131 316 minecraft:deepslate_tiles
setblock 504 128 277 minecraft:cobbled_deepslate
setblock 505 128 276 minecraft:cobbled_deepslate
fill 505 128 277 505 131 277 minecraft:deepslate_tiles
setblock 505 128 316 minecraft:cobbled_deepslate
fill 506 128 276 506 131 276 minecraft:deepslate_tiles
setblock 506 128 315 minecraft:cobbled_deepslate
fill 506 128 316 506 131 316 minecraft:deepslate_tiles
fill 507 128 315 507 131 315 minecraft:deepslate_tiles
setblock 509 128 277 minecraft:cobbled_deepslate
setblock 509 128 302 minecraft:cobbled_deepslate
fill 509 128 303 509 131 303 minecraft:deepslate_tiles
setblock 509 128 306 minecraft:deepslate_tiles
setblock 509 128 307 minecraft:cobbled_deepslate
fill 509 128 308 509 131 308 minecraft:deepslate_tiles
setblock 510 128 276 minecraft:cobbled_deepslate
setblock 510 128 277 minecraft:deepslate_tiles
setblock 510 128 281 minecraft:cobbled_deepslate
fill 510 128 297 510 130 297 minecraft:deepslate_tiles
setblock 510 128 301 minecraft:cobbled_deepslate
fill 510 128 302 510 131 302 minecraft:deepslate_tiles
setblock 510 128 306 minecraft:cobbled_deepslate
fill 510 128 307 510 131 307 minecraft:deepslate_tiles
setblock 510 128 311 minecraft:cobbled_deepslate
setblock 510 128 316 minecraft:cobbled_deepslate
fill 511 128 276 511 129 276 minecraft:deepslate_tiles
setblock 511 128 280 minecraft:cobbled_deepslate
fill 511 128 281 511 131 281 minecraft:deepslate_tiles
setblock 511 128 284 minecraft:deepslate_tiles
setblock 511 128 295 minecraft:cobbled_deepslate
fill 511 128 296 511 131 296 minecraft:deepslate_tiles
setblock 511 128 300 minecraft:cobbled_deepslate
fill 511 128 301 511 131 301 minecraft:deepslate_tiles
setblock 511 128 305 minecraft:cobbled_deepslate
fill 511 128 306 511 131 306 minecraft:deepslate_tiles
setblock 511 128 310 minecraft:cobbled_deepslate
fill 511 128 311 511 131 311 minecraft:deepslate_tiles
setblock 511 128 315 minecraft:cobbled_deepslate
fill 511 128 316 511 131 316 minecraft:deepslate_tiles
fill 512 128 303 512 197 303 minecraft:black_concrete
fill 470 129 312 470 198 312 minecraft:black_concrete
setblock 471 129 279 minecraft:cobbled_deepslate
fill 471 129 280 471 132 280 minecraft:deepslate_tiles
setblock 471 129 284 minecraft:cobbled_deepslate
fill 471 129 285 471 132 285 minecraft:deepslate_tiles
setblock 471 129 288 minecraft:deepslate_tiles
setblock 471 129 289 minecraft:cobbled_deepslate
fill 471 129 290 471 131 291 minecraft:deepslate_tiles
setblock 471 129 294 minecraft:cobbled_deepslate
fill 471 129 295 471 132 295 minecraft:deepslate_tiles
setblock 471 129 299 minecraft:cobbled_deepslate
fill 471 129 300 471 132 300 minecraft:deepslate_tiles
setblock 471 129 304 minecraft:cobbled_deepslate
fill 471 129 305 471 132 305 minecraft:deepslate_tiles
setblock 471 129 309 minecraft:cobbled_deepslate
fill 471 129 310 471 132 310 minecraft:deepslate_tiles
setblock 472 129 298 minecraft:cobbled_deepslate
fill 472 129 299 472 132 299 minecraft:deepslate_tiles
setblock 472 129 303 minecraft:cobbled_deepslate
fill 472 129 304 472 132 304 minecraft:deepslate_tiles
setblock 472 129 307 minecraft:deepslate_tiles
fill 481 129 276 481 131 276 minecraft:deepslate_tiles
setblock 482 129 277 minecraft:deepslate_tiles
setblock 483 129 277 minecraft:cobbled_deepslate
setblock 484 129 276 minecraft:cobbled_deepslate
fill 484 129 277 484 132 277 minecraft:deepslate_tiles
fill 485 129 276 485 132 276 minecraft:deepslate_tiles
setblock 485 129 279 minecraft:deepslate_tiles
setblock 486 129 279 minecraft:cobbled_deepslate
fill 486 129 316 486 131 316 minecraft:deepslate_tiles
setblock 487 129 278 minecraft:cobbled_deepslate
fill 487 129 279 487 132 279 minecraft:deepslate_tiles
setblock 488 129 277 minecraft:cobbled_deepslate
fill 488 129 278 488 132 278 minecraft:deepslate_tiles
setblock 489 129 276 minecraft:cobbled_deepslate
fill 489 129 277 492 129 277 minecraft:deepslate_tiles
setblock 489 129 316 minecraft:cobbled_deepslate
fill 490 129 276 493 129 276 minecraft:deepslate_tiles
fill 490 129 316 490 132 316 minecraft:deepslate_tiles
setblock 492 129 278 minecraft:cobbled_deepslate
setblock 493 129 277 minecraft:cobbled_deepslate
setblock 494 129 276 minecraft:cobbled_deepslate
fill 494 129 277 494 130 277 minecraft:deepslate_tiles
fill 495 129 276 495 132 276 minecraft:deepslate_tiles
setblock 499 129 276 minecraft:cobbled_deepslate
fill 500 129 276 500 132 276 minecraft:deepslate_tiles
fill 501 129 277 501 130 277 minecraft:deepslate_tiles
setblock 503 129 276 minecraft:white_wool
setblock 503 129 277 minecraft:cobbled_deepslate
setblock 504 129 276 minecraft:cobbled_deepslate
setblock 504 129 277 minecraft:white_wool
setblock 504 129 315 minecraft:deepslate_tiles
setblock 504 129 316 minecraft:cobbled_deepslate
fill 505 129 276 505 132 276 minecraft:deepslate_tiles
setblock 505 129 278 minecraft:white_wool
setblock 505 129 315 minecraft:cobbled_deepslate
fill 505 129 316 505 132 316 minecraft:deepslate_tiles
setblock 506 129 279 minecraft:white_wool
fill 506 129 315 506 132 315 minecraft:deepslate_tiles
setblock 508 129 277 minecraft:cobbled_deepslate
setblock 508 129 302 minecraft:cobbled_deepslate
fill 508 129 303 508 129 306 minecraft:deepslate_tiles
setblock 509 129 276 minecraft:cobbled_deepslate
setblock 509 129 277 minecraft:deepslate_tiles
setblock 509 129 301 minecraft:cobbled_deepslate
fill 509 129 302 509 132 302 minecraft:deepslate_tiles
setblock 509 129 306 minecraft:cobbled_deepslate
fill 509 129 307 509 132 307 minecraft:deepslate_tiles
fill 509 129 309 509 130 309 minecraft:deepslate_tiles
setblock 509 129 316 minecraft:cobbled_deepslate
fill 510 129 276 510 131 276 minecraft:deepslate_tiles
setblock 510 129 280 minecraft:cobbled_deepslate
fill 510 129 281 510 131 282 minecraft:deepslate_tiles
setblock 510 129 300 minecraft:cobbled_deepslate
fill 510 129 301 510 132 301 minecraft:deepslate_tiles
setblock 510 129 305 minecraft:cobbled_deepslate
fill 510 129 306 510 132 306 minecraft:deepslate_tiles
setblock 510 129 310 minecraft:cobbled_deepslate
fill 510 129 311 510 131 312 minecraft:deepslate_tiles
fill 510 129 316 510 132 316 minecraft:deepslate_tiles
setblock 511 129 279 minecraft:cobbled_deepslate
fill 511 129 280 511 132 280 minecraft:deepslate_tiles
setblock 511 129 284 minecraft:cobbled_deepslate
fill 511 129 285 511 132 285 minecraft:deepslate_tiles
fill 511 129 295 511 132 295 minecraft:deepslate_tiles
setblock 511 129 299 minecraft:cobbled_deepslate
fill 511 129 300 511 132 300 minecraft:deepslate_tiles
setblock 511 129 304 minecraft:cobbled_deepslate
fill 511 129 305 511 132 305 minecraft:deepslate_tiles
setblock 511 129 309 minecraft:cobbled_deepslate
fill 511 129 310 511 132 310 minecraft:deepslate_tiles
setblock 511 129 314 minecraft:cobbled_deepslate
fill 511 129 315 511 132 315 minecraft:deepslate_tiles
fill 470 130 308 470 158 310 minecraft:black_concrete
setblock 470 130 311 minecraft:white_wool
setblock 471 130 278 minecraft:cobbled_deepslate
fill 471 130 279 471 133 279 minecraft:deepslate_tiles
setblock 471 130 283 minecraft:cobbled_deepslate
fill 471 130 284 471 133 284 minecraft:deepslate_tiles
setblock 471 130 288 minecraft:cobbled_deepslate
fill 471 130 289 471 133 289 minecraft:deepslate_tiles
setblock 471 130 293 minecraft:cobbled_deepslate
fill 471 130 294 471 133 294 minecraft:deepslate_tiles
setblock 471 130 298 minecraft:cobbled_deepslate
fill 471 130 299 471 133 299 minecraft:deepslate_tiles
setblock 471 130 303 minecraft:cobbled_deepslate
fill 471 130 304 471 133 304 minecraft:deepslate_tiles
setblock 471 130 308 minecraft:cobbled_deepslate
fill 471 130 309 471 133 309 minecraft:deepslate_tiles
fill 472 130 283 472 133 283 minecraft:deepslate_tiles
setblock 472 130 297 minecraft:cobbled_deepslate
fill 472 130 298 472 131 298 minecraft:deepslate_tiles
setblock 472 130 302 minecraft:cobbled_deepslate
fill 472 130 303 472 133 303 minecraft:deepslate_tiles
setblock 472 130 307 minecraft:cobbled_deepslate
setblock 482 130 277 minecraft:cobbled_deepslate
setblock 483 130 276 minecraft:cobbled_deepslate
fill 483 130 277 483 132 278 minecraft:deepslate_tiles
fill 484 130 276 484 133 276 minecraft:deepslate_tiles
setblock 485 130 279 minecraft:cobbled_deepslate
fill 485 130 316 485 132 316 minecraft:deepslate_tiles
setblock 486 130 278 minecraft:cobbled_deepslate
fill 486 130 279 486 133 279 minecraft:deepslate_tiles
setblock 487 130 277 minecraft:cobbled_deepslate
fill 487 130 278 487 133 278 minecraft:deepslate_tiles
setblock 488 130 276 minecraft:cobbled_deepslate
fill 488 130 277 491 130 277 minecraft:deepslate_tiles
setblock 488 130 316 minecraft:cobbled_deepslate
fill 489 130 276 492 130 276 minecraft:deepslate_tiles
fill 489 130 316 489 133 316 minecraft:deepslate_tiles
fill 489 130 317 490 140 317 minecraft:black_concrete
setblock 491 130 278 minecraft:cobbled_deepslate
setblock 491 130 317 minecraft:white_wool
setblock 492 130 277 minecraft:cobbled_deepslate
setblock 493 130 276 minecraft:cobbled_deepslate
fill 493 130 277 493 131 277 minecraft:deepslate_tiles
fill 494 130 276 494 133 276 minecraft:deepslate_tiles
setblock 498 130 276 minecraft:cobbled_deepslate
fill 499 130 276 499 133 276 minecraft:deepslate_tiles
fill 500 130 316 500 132 316 minecraft:deepslate_tiles
setblock 502 130 277 minecraft:cobbled_deepslate
setblock 503 130 276 minecraft:cobbled_deepslate
fill 503 130 277 504 132 277 minecraft:deepslate_tiles
setblock 503 130 315 minecraft:deepslate_tiles
setblock 503 130 316 minecraft:cobbled_deepslate
fill 504 130 276 504 133 276 minecraft:deepslate_tiles
setblock 504 130 315 minecraft:cobbled_deepslate
fill 504 130 316 504 133 316 minecraft:deepslate_tiles
fill 505 130 315 505 133 315 minecraft:deepslate_tiles
setblock 507 130 277 minecraft:cobbled_deepslate
setblock 507 130 280 minecraft:white_wool
setblock 508 130 276 minecraft:cobbled_deepslate
fill 508 130 277 508 131 277 minecraft:deepslate_tiles
setblock 508 130 281 minecraft:white_wool
fill 508 130 302 508 130 305 minecraft:deepslate_tiles
setblock 508 130 306 minecraft:cobbled_deepslate
fill 508 130 307 508 133 307 minecraft:deepslate_tiles
setblock 508 130 316 minecraft:cobbled_deepslate
fill 509 130 276 509 132 276 minecraft:deepslate_tiles
setblock 509 130 282 minecraft:white_wool
setblock 509 130 300 minecraft:cobbled_deepslate
fill 509 130 301 509 133 301 minecraft:deepslate_tiles
setblock 509 130 305 minecraft:cobbled_deepslate
fill 509 130 306 509 133 306 minecraft:deepslate_tiles
setblock 509 130 310 minecraft:cobbled_deepslate
setblock 509 130 315 minecraft:cobbled_deepslate
fill 509 130 316 509 133 316 minecraft:deepslate_tiles
setblock 510 130 280 minecraft:deepslate_tiles
setblock 510 130 283 minecraft:white_wool
setblock 510 130 299 minecraft:cobbled_deepslate
fill 510 130 300 510 133 300 minecraft:deepslate_tiles
setblock 510 130 304 minecraft:cobbled_deepslate
fill 510 130 305 510 133 305 minecraft:deepslate_tiles
setblock 510 130 309 minecraft:cobbled_deepslate
fill 510 130 310 510 133 310 minecraft:deepslate_tiles
setblock 511 130 278 minecraft:cobbled_deepslate
fill 511 130 279 511 132 279 minecraft:deepslate_tiles
setblock 511 130 283 minecraft:cobbled_deepslate
fill 511 130 284 511 133 284 minecraft:deepslate_tiles
fill 511 130 286 511 131 286 minecraft:deepslate_tiles
setblock 511 130 298 minecraft:cobbled_deepslate
fill 511 130 299 511 133 299 minecraft:deepslate_tiles
setblock 511 130 303 minecraft:cobbled_deepslate
fill 511 130 304 511 133 304 minecraft:deepslate_tiles
setblock 511 130 308 minecraft:cobbled_deepslate
fill 511 130 309 511 133 309 minecraft:deepslate_tiles
setblock 511 130 313 minecraft:cobbled_deepslate
fill 511 130 314 511 133 314 minecraft:deepslate_tiles
fill 470 131 311 470 198 311 minecraft:black_concrete
setblock 471 131 278 minecraft:deepslate_tiles
setblock 471 131 282 minecraft:cobbled_deepslate
fill 471 131 283 471 134 283 minecraft:deepslate_tiles
setblock 471 131 286 minecraft:deepslate_tiles
setblock 471 131 287 minecraft:cobbled_deepslate
fill 471 131 288 471 134 288 minecraft:deepslate_tiles
setblock 471 131 292 minecraft:cobbled_deepslate
fill 471 131 293 471 134 293 minecraft:deepslate_tiles
setblock 471 131 297 minecraft:cobbled_deepslate
fill 471 131 298 471 134 298 minecraft:deepslate_tiles
setblock 471 131 302 minecraft:cobbled_deepslate
fill 471 131 303 471 134 303 minecraft:deepslate_tiles
setblock 471 131 307 minecraft:cobbled_deepslate
fill 471 131 308 471 134 308 minecraft:deepslate_tiles
setblock 471 131 311 minecraft:deepslate_tiles
fill 472 131 282 472 133 282 minecraft:deepslate_tiles
fill 472 131 284 472 131 285 minecraft:deepslate_tiles
setblock 472 131 286 minecraft:cobbled_deepslate
setblock 472 131 301 minecraft:cobbled_deepslate
fill 472 131 302 472 134 302 minecraft:deepslate_tiles
setblock 472 131 306 minecraft:cobbled_deepslate
fill 472 131 307 472 134 307 minecraft:deepslate_tiles
fill 480 131 276 480 132 276 minecraft:deepslate_tiles
setblock 481 131 277 minecraft:cobbled_deepslate
setblock 482 131 276 minecraft:cobbled_deepslate
fill 482 131 277 482 133 278 minecraft:deepslate_tiles
fill 483 131 276 483 134 276 minecraft:deepslate_tiles
setblock 484 131 279 minecraft:cobbled_deepslate
fill 484 131 316 484 133 316 minecraft:deepslate_tiles
setblock 485 131 278 minecraft:cobbled_deepslate
fill 485 131 279 485 134 279 minecraft:deepslate_tiles
setblock 486 131 277 minecraft:cobbled_deepslate
fill 486 131 278 486 134 278 minecraft:deepslate_tiles
setblock 487 131 276 minecraft:cobbled_deepslate
fill 487 131 277 490 131 277 minecraft:deepslate_tiles
setblock 487 131 316 minecraft:cobbled_deepslate
fill 488 131 276 491 131 276 minecraft:deepslate_tiles
fill 488 131 316 488 134 316 minecraft:deepslate_tiles
setblock 489 131 279 minecraft:cobbled_deepslate
setblock 490 131 278 minecraft:cobbled_deepslate
setblock 491 131 277 minecraft:cobbled_deepslate
setblock 491 131 278 minecraft:deepslate_tiles
fill 491 131 317 491 197 317 minecraft:black_concrete
setblock 492 131 276 minecraft:cobbled_deepslate
fill 492 131 277 492 132 277 minecraft:deepslate_tiles
fill 493 131 276 493 134 276 minecraft:deepslate_tiles
setblock 497 131 276 minecraft:cobbled_deepslate
fill 498 131 276 498 134 276 minecraft:deepslate_tiles
fill 499 131 316 499 133 316 minecraft:deepslate_tiles
setblock 500 131 277 minecraft:deepslate_tiles
setblock 501 131 277 minecraft:cobbled_deepslate
setblock 502 131 276 minecraft:cobbled_deepslate
fill 502 131 277 502 134 277 minecraft:deepslate_tiles
setblock 502 131 315 minecraft:deepslate_tiles
setblock 502 131 316 minecraft:cobbled_deepslate
fill 503 131 276 503 134 276 minecraft:deepslate_tiles
setblock 503 131 315 minecraft:cobbled_deepslate
fill 503 131 316 503 134 316 minecraft:deepslate_tiles
fill 504 131 315 504 134 315 minecraft:deepslate_tiles
setblock 506 131 277 minecraft:cobbled_deepslate
setblock 507 131 276 minecraft:cobbled_deepslate
fill 507 131 277 507 132 277 minecraft:deepslate_tiles
setblock 507 131 316 minecraft:cobbled_deepslate
fill 508 131 276 508 133 276 minecraft:deepslate_tiles
fill 508 131 302 508 131 304 minecraft:deepslate_tiles
setblock 508 131 305 minecraft:cobbled_deepslate
fill 508 131 306 508 134 306 minecraft:deepslate_tiles
fill 508 131 308 508 131 309 minecraft:deepslate_tiles
setblock 508 131 315 minecraft:cobbled_deepslate
fill 508 131 316 508 134 316 minecraft:deepslate_tiles
setblock 509 131 299 minecraft:cobbled_deepslate
fill 509 131 300 509 133 300 minecraft:deepslate_tiles
setblock 509 131 304 minecraft:cobbled_deepslate
fill 509 131 305 509 134 305 minecraft:deepslate_tiles
setblock 509 131 309 minecraft:cobbled_deepslate
fill 509 131 310 509 133 311 minecraft:deepslate_tiles
fill 509 131 315 509 132 315 minecraft:deepslate_tiles
setblock 510 131 283 minecraft:cobbled_deepslate
fill 510 131 284 510 133 284 minecraft:deepslate_tiles
setblock 510 131 298 minecraft:cobbled_deepslate
fill 510 131 299 510 134 299 minecraft:deepslate_tiles
setblock 510 131 303 minecraft:cobbled_deepslate
fill 510 131 304 510 134 304 minecraft:deepslate_tiles
setblock 510 131 308 minecraft:cobbled_deepslate
schedule function dropper:buildpart/70_6 1t
