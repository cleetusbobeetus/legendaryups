fill 282 175 576 282 212 576 minecraft:magenta_stained_glass
fill 287 175 557 287 223 557 minecraft:magenta_stained_glass
fill 300 175 599 300 179 599 minecraft:magenta_stained_glass
fill 309 175 599 309 223 599 minecraft:magenta_stained_glass
fill 313 175 557 313 223 557 minecraft:magenta_stained_glass
fill 317 175 579 319 175 579 minecraft:light_blue_stained_glass
setblock 318 175 580 minecraft:light_blue_stained_glass
fill 319 175 573 319 176 573 minecraft:light_blue_stained_glass
fill 319 175 578 321 177 578 minecraft:light_blue_stained_glass
setblock 319 175 581 minecraft:light_blue_stained_glass
fill 319 175 584 320 175 584 minecraft:light_blue_stained_glass
fill 319 175 586 320 175 586 minecraft:light_blue_stained_glass
fill 321 175 583 323 175 583 minecraft:light_blue_stained_glass
fill 321 175 587 323 175 587 minecraft:light_blue_stained_glass
fill 322 175 577 322 178 577 minecraft:light_blue_stained_glass
fill 323 175 578 323 178 578 minecraft:light_blue_stained_glass
fill 324 175 584 324 204 584 minecraft:magenta_stained_glass
setblock 324 175 585 minecraft:sea_lantern
setblock 324 175 592 minecraft:white_concrete
setblock 285 176 560 minecraft:light[level=14]
setblock 285 176 568 minecraft:light[level=14]
setblock 285 176 576 minecraft:light[level=14]
setblock 285 176 584 minecraft:light[level=14]
setblock 285 176 592 minecraft:light[level=14]
setblock 293 176 560 minecraft:light[level=14]
setblock 293 176 568 minecraft:light[level=14]
setblock 293 176 576 minecraft:light[level=14]
setblock 293 176 584 minecraft:light[level=14]
setblock 293 176 592 minecraft:light[level=14]
setblock 300 176 557 minecraft:light_blue_stained_glass
setblock 301 176 560 minecraft:light[level=14]
setblock 301 176 568 minecraft:light[level=14]
setblock 301 176 576 minecraft:light[level=14]
setblock 301 176 584 minecraft:light[level=14]
setblock 301 176 592 minecraft:light[level=14]
setblock 309 176 560 minecraft:light[level=14]
setblock 309 176 568 minecraft:light[level=14]
setblock 309 176 576 minecraft:light[level=14]
setblock 309 176 584 minecraft:light[level=14]
setblock 309 176 592 minecraft:light[level=14]
fill 316 176 557 316 192 557 minecraft:magenta_stained_glass
setblock 317 176 557 minecraft:white_concrete
setblock 317 176 560 minecraft:light[level=14]
setblock 317 176 568 minecraft:light[level=14]
setblock 317 176 576 minecraft:light[level=14]
setblock 317 176 584 minecraft:light[level=14]
setblock 317 176 592 minecraft:light[level=14]
fill 318 176 557 318 214 557 minecraft:magenta_stained_glass
fill 318 176 579 320 176 579 minecraft:light_blue_stained_glass
fill 320 176 580 320 177 580 minecraft:light_blue_stained_glass
fill 321 176 577 321 177 577 minecraft:light_blue_stained_glass
fill 321 176 585 323 176 585 minecraft:light_blue_stained_glass
fill 323 176 577 323 177 577 minecraft:light_blue_stained_glass
setblock 324 176 575 minecraft:white_concrete
fill 324 176 585 324 223 585 minecraft:magenta_stained_glass
fill 324 176 592 324 220 592 minecraft:magenta_stained_glass
setblock 282 177 593 minecraft:light_blue_stained_glass
setblock 294 177 599 minecraft:white_concrete
fill 300 177 557 300 219 557 minecraft:magenta_stained_glass
setblock 312 177 599 minecraft:sea_lantern
fill 317 177 557 317 207 557 minecraft:magenta_stained_glass
setblock 318 177 599 minecraft:sea_lantern
fill 319 177 573 319 185 573 minecraft:amethyst_block
fill 319 177 579 320 177 579 minecraft:light_blue_stained_glass
fill 324 177 575 324 223 575 minecraft:magenta_stained_glass
fill 324 177 589 324 186 589 minecraft:magenta_stained_glass
setblock 324 177 590 minecraft:sea_lantern
fill 324 177 591 324 220 591 minecraft:magenta_stained_glass
setblock 282 178 587 minecraft:sea_lantern
fill 282 178 593 282 187 593 minecraft:magenta_stained_glass
setblock 282 178 596 minecraft:sea_lantern
setblock 290 178 599 minecraft:light_blue_stained_glass
fill 294 178 599 294 179 599 minecraft:magenta_stained_glass
fill 295 178 593 295 179 593 minecraft:light_blue_stained_glass
setblock 298 178 557 minecraft:white_concrete
fill 312 178 599 312 219 599 minecraft:magenta_stained_glass
setblock 316 178 599 minecraft:sea_lantern
fill 318 178 573 318 185 573 minecraft:amethyst_block
fill 318 178 599 318 194 599 minecraft:magenta_stained_glass
fill 319 178 572 319 185 572 minecraft:amethyst_block
fill 320 178 579 323 178 579 minecraft:light_blue_stained_glass
setblock 321 178 578 minecraft:light_blue_stained_glass
fill 321 178 580 323 178 580 minecraft:light_blue_stained_glass
setblock 322 178 581 minecraft:light_blue_stained_glass
setblock 323 178 557 minecraft:white_concrete
fill 324 178 557 324 220 557 minecraft:magenta_stained_glass
fill 324 178 590 324 187 590 minecraft:magenta_stained_glass
fill 282 179 587 282 206 587 minecraft:magenta_stained_glass
fill 282 179 596 282 221 596 minecraft:magenta_stained_glass
fill 290 179 599 290 195 599 minecraft:magenta_stained_glass
fill 298 179 557 298 224 557 minecraft:magenta_stained_glass
fill 315 179 564 315 180 564 minecraft:light_blue_stained_glass
fill 316 179 599 316 210 599 minecraft:magenta_stained_glass
fill 318 179 572 318 185 572 minecraft:amethyst_block
fill 319 179 574 319 185 574 minecraft:amethyst_block
fill 320 179 572 320 185 573 minecraft:amethyst_block
setblock 322 179 579 minecraft:light_blue_stained_glass
fill 323 179 557 323 195 557 minecraft:magenta_stained_glass
setblock 324 179 565 minecraft:sea_lantern
setblock 294 180 599 minecraft:white_concrete
fill 295 180 593 295 186 593 minecraft:amethyst_block
setblock 300 180 599 minecraft:light_blue_stained_glass
setblock 313 180 599 minecraft:white_concrete
fill 318 180 574 318 185 574 minecraft:amethyst_block
fill 319 180 571 319 185 571 minecraft:amethyst_block
fill 320 180 574 320 185 574 minecraft:amethyst_block
fill 324 180 565 324 219 565 minecraft:magenta_stained_glass
fill 282 181 572 282 192 572 minecraft:magenta_stained_glass
setblock 282 181 573 minecraft:light_blue_stained_glass
fill 282 181 574 282 196 574 minecraft:magenta_stained_glass
fill 288 181 573 290 182 573 minecraft:magenta_stained_glass
fill 289 181 572 289 182 572 minecraft:magenta_stained_glass
fill 289 181 574 289 182 574 minecraft:magenta_stained_glass
fill 294 181 599 294 223 599 minecraft:magenta_stained_glass
fill 295 181 592 295 186 592 minecraft:amethyst_block
fill 296 181 593 296 186 593 minecraft:amethyst_block
fill 300 181 599 300 197 599 minecraft:magenta_stained_glass
fill 313 181 599 313 198 599 minecraft:magenta_stained_glass
setblock 315 181 557 minecraft:sea_lantern
fill 317 181 572 317 185 574 minecraft:amethyst_block
fill 318 181 571 318 185 571 minecraft:amethyst_block
fill 318 181 575 319 185 575 minecraft:amethyst_block
fill 320 181 571 320 185 571 minecraft:amethyst_block
fill 321 181 572 321 185 574 minecraft:amethyst_block
setblock 282 182 560 minecraft:sea_lantern
setblock 282 182 564 minecraft:sea_lantern
fill 282 182 573 282 198 573 minecraft:magenta_stained_glass
fill 282 182 590 282 219 591 minecraft:magenta_stained_glass
setblock 282 182 592 minecraft:sea_lantern
fill 295 182 594 296 186 594 minecraft:amethyst_block
fill 296 182 592 296 186 592 minecraft:amethyst_block
setblock 309 182 557 minecraft:sea_lantern
fill 315 182 557 315 224 557 minecraft:magenta_stained_glass
fill 317 182 571 317 185 571 minecraft:amethyst_block
setblock 317 182 599 minecraft:sea_lantern
fill 318 182 570 319 185 570 minecraft:amethyst_block
fill 320 182 575 320 185 575 minecraft:amethyst_block
fill 321 182 571 321 185 571 minecraft:amethyst_block
setblock 324 182 558 minecraft:light_blue_stained_glass
setblock 324 182 596 minecraft:white_concrete
fill 282 183 560 282 221 560 minecraft:magenta_stained_glass
setblock 282 183 562 minecraft:sea_lantern
fill 282 183 564 282 221 564 minecraft:magenta_stained_glass
fill 282 183 592 282 199 592 minecraft:magenta_stained_glass
setblock 284 183 599 minecraft:light_blue_stained_glass
setblock 285 183 557 minecraft:white_concrete
fill 285 183 599 286 216 599 minecraft:magenta_stained_glass
fill 294 183 592 294 186 593 minecraft:amethyst_block
fill 295 183 591 295 186 591 minecraft:amethyst_block
setblock 295 183 599 minecraft:white_concrete
fill 297 183 592 297 186 593 minecraft:amethyst_block
fill 309 183 557 309 221 557 minecraft:magenta_stained_glass
fill 316 183 572 316 185 574 minecraft:amethyst_block
fill 317 183 570 317 185 570 minecraft:amethyst_block
fill 317 183 575 317 185 575 minecraft:amethyst_block
fill 317 183 599 317 207 599 minecraft:magenta_stained_glass
fill 318 183 576 320 185 576 minecraft:amethyst_block
fill 320 183 570 320 186 570 minecraft:amethyst_block
setblock 320 183 599 minecraft:sea_lantern
fill 321 183 575 321 185 575 minecraft:amethyst_block
fill 322 183 572 322 185 574 minecraft:amethyst_block
fill 324 183 558 324 223 558 minecraft:magenta_stained_glass
fill 324 183 596 324 223 596 minecraft:magenta_stained_glass
fill 282 184 562 282 196 562 minecraft:magenta_stained_glass
setblock 282 184 582 minecraft:white_concrete
setblock 283 184 599 minecraft:light_blue_stained_glass
fill 284 184 599 284 216 599 minecraft:magenta_stained_glass
fill 285 184 557 285 211 557 minecraft:magenta_stained_glass
setblock 285 184 560 minecraft:light[level=14]
setblock 285 184 568 minecraft:light[level=14]
setblock 285 184 576 minecraft:light[level=14]
setblock 285 184 584 minecraft:light[level=14]
setblock 285 184 592 minecraft:light[level=14]
setblock 293 184 560 minecraft:light[level=14]
setblock 293 184 568 minecraft:light[level=14]
setblock 293 184 576 minecraft:light[level=14]
setblock 293 184 584 minecraft:light[level=14]
setblock 293 184 592 minecraft:light[level=14]
fill 294 184 591 294 186 591 minecraft:amethyst_block
fill 294 184 594 294 186 594 minecraft:amethyst_block
fill 295 184 599 295 195 599 minecraft:magenta_stained_glass
fill 296 184 591 296 186 591 minecraft:amethyst_block
fill 297 184 594 297 186 594 minecraft:amethyst_block
setblock 299 184 599 minecraft:light_blue_stained_glass
setblock 301 184 560 minecraft:light[level=14]
setblock 301 184 568 minecraft:light[level=14]
setblock 301 184 576 minecraft:light[level=14]
setblock 301 184 584 minecraft:light[level=14]
setblock 301 184 592 minecraft:light[level=14]
setblock 309 184 560 minecraft:light[level=14]
setblock 309 184 568 minecraft:light[level=14]
setblock 309 184 576 minecraft:light[level=14]
setblock 309 184 584 minecraft:light[level=14]
setblock 309 184 592 minecraft:light[level=14]
fill 316 184 571 316 185 571 minecraft:amethyst_block
fill 316 184 575 316 185 575 minecraft:amethyst_block
setblock 317 184 560 minecraft:light[level=14]
setblock 317 184 568 minecraft:light[level=14]
fill 317 184 576 317 185 576 minecraft:amethyst_block
setblock 317 184 584 minecraft:light[level=14]
setblock 317 184 592 minecraft:light[level=14]
fill 318 184 569 319 185 569 minecraft:amethyst_block
fill 320 184 599 320 192 599 minecraft:magenta_stained_glass
fill 321 184 570 321 185 570 minecraft:amethyst_block
fill 321 184 576 321 185 576 minecraft:amethyst_block
fill 322 184 571 322 185 571 minecraft:amethyst_block
fill 322 184 575 322 185 575 minecraft:amethyst_block
fill 282 185 582 282 186 582 minecraft:magenta_stained_glass
setblock 282 185 597 minecraft:sea_lantern
fill 283 185 599 283 191 599 minecraft:magenta_stained_glass
fill 293 185 592 293 186 594 minecraft:amethyst_block
fill 294 185 595 296 186 595 minecraft:amethyst_block
fill 296 185 572 296 186 572 minecraft:light_blue_stained_glass
fill 297 185 591 297 186 591 minecraft:amethyst_block
fill 298 185 592 298 186 593 minecraft:amethyst_block
fill 299 185 599 299 203 599 minecraft:magenta_stained_glass
fill 315 185 571 315 185 574 minecraft:amethyst_block
setblock 316 185 570 minecraft:amethyst_block
setblock 317 185 569 minecraft:amethyst_block
fill 318 185 577 319 185 577 minecraft:amethyst_block
fill 320 185 569 321 185 569 minecraft:amethyst_block
setblock 322 185 570 minecraft:amethyst_block
fill 323 185 572 323 185 574 minecraft:amethyst_block
fill 282 186 597 282 219 597 minecraft:magenta_stained_glass
setblock 293 186 591 minecraft:amethyst_block
fill 294 186 590 297 186 590 minecraft:amethyst_block
setblock 297 186 595 minecraft:amethyst_block
setblock 298 186 591 minecraft:amethyst_block
setblock 298 186 594 minecraft:amethyst_block
fill 318 186 572 320 186 573 minecraft:light_blue_stained_glass
setblock 319 186 574 minecraft:light_blue_stained_glass
setblock 322 186 557 minecraft:light_blue_stained_glass
setblock 324 186 576 minecraft:sea_lantern
fill 324 186 577 324 219 577 minecraft:magenta_stained_glass
setblock 282 187 582 minecraft:light_blue_stained_glass
fill 295 187 592 296 188 593 minecraft:light_blue_stained_glass
fill 318 187 573 319 187 573 minecraft:light_blue_stained_glass
fill 319 187 572 319 190 572 minecraft:light_blue_stained_glass
fill 322 187 557 322 224 557 minecraft:magenta_stained_glass
fill 324 187 576 324 223 576 minecraft:magenta_stained_glass
fill 324 187 586 324 196 586 minecraft:magenta_stained_glass
setblock 324 187 587 minecraft:light_blue_stained_glass
setblock 324 187 589 minecraft:sea_lantern
fill 282 188 579 282 223 580 minecraft:magenta_stained_glass
setblock 282 188 581 minecraft:sea_lantern
fill 282 188 582 282 219 582 minecraft:magenta_stained_glass
setblock 282 188 593 minecraft:white_concrete
setblock 310 188 557 minecraft:light_blue_stained_glass
fill 311 188 557 311 194 557 minecraft:magenta_stained_glass
fill 319 188 573 322 190 573 minecraft:light_blue_stained_glass
fill 324 188 587 324 195 587 minecraft:magenta_stained_glass
fill 324 188 589 324 223 589 minecraft:magenta_stained_glass
setblock 324 188 590 minecraft:white_concrete
setblock 324 188 598 minecraft:sea_lantern
fill 282 189 581 282 212 581 minecraft:magenta_stained_glass
fill 282 189 593 282 221 593 minecraft:magenta_stained_glass
fill 295 189 593 296 189 593 minecraft:light_blue_stained_glass
setblock 307 189 599 minecraft:light_blue_stained_glass
fill 310 189 557 310 197 557 minecraft:magenta_stained_glass
setblock 318 189 573 minecraft:light_blue_stained_glass
fill 319 189 574 323 190 574 minecraft:light_blue_stained_glass
fill 320 189 572 323 191 572 minecraft:light_blue_stained_glass
fill 322 189 571 322 191 571 minecraft:light_blue_stained_glass
fill 322 189 575 322 191 575 minecraft:light_blue_stained_glass
fill 323 189 573 323 191 573 minecraft:light_blue_stained_glass
fill 324 189 590 324 221 590 minecraft:magenta_stained_glass
fill 324 189 598 324 223 598 minecraft:magenta_stained_glass
setblock 282 190 584 minecraft:light_blue_stained_glass
setblock 283 190 557 minecraft:white_concrete
setblock 295 190 593 minecraft:light_blue_stained_glass
fill 307 190 599 307 195 599 minecraft:magenta_stained_glass
fill 317 190 577 319 191 577 minecraft:light_blue_stained_glass
fill 318 190 578 318 191 578 minecraft:light_blue_stained_glass
fill 321 190 571 321 191 571 minecraft:light_blue_stained_glass
fill 321 190 575 321 191 575 minecraft:light_blue_stained_glass
fill 323 190 571 323 191 571 minecraft:light_blue_stained_glass
fill 323 190 575 323 191 575 minecraft:light_blue_stained_glass
fill 282 191 584 282 219 584 minecraft:magenta_stained_glass
setblock 282 191 598 minecraft:white_concrete
fill 282 191 599 282 223 599 minecraft:magenta_stained_glass
fill 283 191 557 283 218 557 minecraft:magenta_stained_glass
fill 294 191 557 294 202 557 minecraft:magenta_stained_glass
setblock 295 191 557 minecraft:light_blue_stained_glass
fill 320 191 573 322 191 574 minecraft:light_blue_stained_glass
setblock 323 191 574 minecraft:light_blue_stained_glass
setblock 282 192 598 minecraft:magenta_stained_glass
setblock 283 192 599 minecraft:white_concrete
setblock 285 192 560 minecraft:light[level=14]
setblock 285 192 568 minecraft:light[level=14]
setblock 285 192 576 minecraft:light[level=14]
setblock 285 192 584 minecraft:light[level=14]
setblock 285 192 592 minecraft:light[level=14]
setblock 293 192 560 minecraft:light[level=14]
setblock 293 192 568 minecraft:light[level=14]
setblock 293 192 576 minecraft:light[level=14]
setblock 293 192 584 minecraft:light[level=14]
setblock 293 192 592 minecraft:light[level=14]
fill 295 192 557 295 223 557 minecraft:magenta_stained_glass
fill 295 192 579 301 209 581 minecraft:jungle_log
fill 296 192 578 300 210 578 minecraft:jungle_log
fill 296 192 582 300 210 582 minecraft:jungle_log
fill 297 192 577 299 210 577 minecraft:jungle_log
fill 297 192 583 299 210 583 minecraft:jungle_log
setblock 301 192 560 minecraft:light[level=14]
setblock 301 192 568 minecraft:light[level=14]
setblock 301 192 576 minecraft:light[level=14]
setblock 301 192 584 minecraft:light[level=14]
setblock 301 192 592 minecraft:light[level=14]
setblock 301 192 599 minecraft:sea_lantern
setblock 309 192 560 minecraft:light[level=14]
setblock 309 192 568 minecraft:light[level=14]
setblock 309 192 576 minecraft:light[level=14]
setblock 309 192 584 minecraft:light[level=14]
setblock 309 192 592 minecraft:light[level=14]
setblock 317 192 560 minecraft:light[level=14]
setblock 317 192 568 minecraft:light[level=14]
setblock 317 192 576 minecraft:light[level=14]
setblock 317 192 584 minecraft:light[level=14]
setblock 317 192 592 minecraft:light[level=14]
setblock 324 192 569 minecraft:sea_lantern
setblock 282 193 572 minecraft:sea_lantern
setblock 282 193 598 minecraft:sea_lantern
fill 283 193 599 283 223 599 minecraft:magenta_stained_glass
fill 301 193 599 301 220 599 minecraft:magenta_stained_glass
setblock 316 193 557 minecraft:sea_lantern
setblock 320 193 599 minecraft:light_blue_stained_glass
fill 324 193 569 324 211 569 minecraft:magenta_stained_glass
setblock 324 193 580 minecraft:white_concrete
setblock 282 194 571 minecraft:white_concrete
fill 282 194 572 282 223 572 minecraft:magenta_stained_glass
fill 282 194 598 282 223 598 minecraft:magenta_stained_glass
setblock 316 194 557 minecraft:magenta_stained_glass
fill 320 194 599 320 220 599 minecraft:magenta_stained_glass
fill 324 194 580 324 223 580 minecraft:magenta_stained_glass
fill 282 195 571 282 223 571 minecraft:magenta_stained_glass
fill 304 195 557 304 223 557 minecraft:magenta_stained_glass
setblock 305 195 557 minecraft:white_concrete
setblock 311 195 557 minecraft:white_concrete
setblock 316 195 557 minecraft:sea_lantern
setblock 318 195 599 minecraft:light_blue_stained_glass
setblock 290 196 599 minecraft:white_concrete
setblock 295 196 599 minecraft:light_blue_stained_glass
fill 304 196 576 306 196 578 minecraft:redstone_block
fill 304 196 582 306 196 584 minecraft:redstone_block
fill 305 196 557 305 223 557 minecraft:magenta_stained_glass
setblock 307 196 599 minecraft:sea_lantern
fill 311 196 557 311 205 557 minecraft:magenta_stained_glass
fill 311 196 575 313 196 577 minecraft:redstone_block
fill 312 196 582 314 196 584 minecraft:redstone_block
fill 316 196 557 316 207 557 minecraft:magenta_stained_glass
setblock 318 196 599 minecraft:sea_lantern
setblock 323 196 557 minecraft:light_blue_stained_glass
setblock 324 196 568 minecraft:light_blue_stained_glass
setblock 324 196 587 minecraft:sea_lantern
setblock 282 197 562 minecraft:sea_lantern
setblock 282 197 574 minecraft:sea_lantern
fill 283 197 558 294 197 598 minecraft:purple_stained_glass
fill 290 197 599 290 202 599 minecraft:magenta_stained_glass
fill 295 197 558 295 197 578 minecraft:purple_stained_glass
fill 295 197 582 295 197 598 minecraft:purple_stained_glass
fill 295 197 599 295 202 599 minecraft:magenta_stained_glass
fill 296 197 558 296 197 577 minecraft:purple_stained_glass
fill 296 197 583 296 197 598 minecraft:purple_stained_glass
fill 297 197 558 303 197 576 minecraft:purple_stained_glass
fill 297 197 584 303 197 598 minecraft:purple_stained_glass
fill 300 197 577 303 197 577 minecraft:purple_stained_glass
fill 300 197 583 303 197 583 minecraft:purple_stained_glass
fill 301 197 578 303 197 578 minecraft:purple_stained_glass
fill 301 197 582 303 197 582 minecraft:purple_stained_glass
fill 302 197 579 307 197 581 minecraft:purple_stained_glass
fill 304 197 558 310 197 575 minecraft:purple_stained_glass
fill 304 197 585 323 197 598 minecraft:purple_stained_glass
fill 307 197 576 310 197 578 minecraft:purple_stained_glass
fill 307 197 582 311 197 584 minecraft:purple_stained_glass
fill 307 197 599 307 222 599 minecraft:magenta_stained_glass
fill 311 197 558 323 197 574 minecraft:purple_stained_glass
fill 311 197 578 323 197 581 minecraft:purple_stained_glass
fill 314 197 575 323 197 577 minecraft:purple_stained_glass
setblock 314 197 599 minecraft:sea_lantern
fill 315 197 582 323 197 584 minecraft:purple_stained_glass
fill 318 197 599 318 223 599 minecraft:magenta_stained_glass
fill 323 197 557 323 203 557 minecraft:magenta_stained_glass
fill 324 197 568 324 218 568 minecraft:magenta_stained_glass
setblock 324 197 586 minecraft:light_blue_stained_glass
fill 324 197 587 324 223 587 minecraft:magenta_stained_glass
fill 282 198 562 282 217 562 minecraft:magenta_stained_glass
fill 282 198 574 282 223 574 minecraft:magenta_stained_glass
fill 283 198 558 284 198 558 minecraft:purple_stained_glass
fill 283 198 559 323 198 559 minecraft:amethyst_block
fill 283 198 560 323 198 561 minecraft:purple_stained_glass
fill 283 198 562 323 198 562 minecraft:amethyst_block
fill 283 198 563 284 198 564 minecraft:purple_stained_glass
fill 283 198 565 323 198 565 minecraft:amethyst_block
fill 283 198 566 323 198 567 minecraft:purple_stained_glass
fill 283 198 568 323 198 568 minecraft:amethyst_block
fill 283 198 569 284 198 570 minecraft:purple_stained_glass
fill 283 198 571 323 198 571 minecraft:amethyst_block
fill 283 198 572 323 198 573 minecraft:purple_stained_glass
fill 283 198 574 309 198 574 minecraft:amethyst_block
fill 283 198 575 284 198 576 minecraft:purple_stained_glass
fill 283 198 577 296 198 577 minecraft:amethyst_block
fill 283 198 578 294 198 579 minecraft:purple_stained_glass
fill 283 198 580 294 198 580 minecraft:amethyst_block
fill 283 198 581 284 198 582 minecraft:purple_stained_glass
fill 283 198 583 296 198 583 minecraft:amethyst_block
fill 283 198 584 302 198 585 minecraft:purple_stained_glass
fill 283 198 586 323 198 586 minecraft:amethyst_block
fill 283 198 587 284 198 588 minecraft:purple_stained_glass
fill 283 198 589 323 198 589 minecraft:amethyst_block
fill 283 198 590 323 198 591 minecraft:purple_stained_glass
fill 283 198 592 323 198 592 minecraft:amethyst_block
fill 283 198 593 284 198 594 minecraft:purple_stained_glass
fill 283 198 595 323 198 595 minecraft:amethyst_block
fill 283 198 596 323 198 597 minecraft:purple_stained_glass
fill 283 198 598 323 198 598 minecraft:amethyst_block
setblock 285 198 558 minecraft:amethyst_block
fill 285 198 563 285 198 564 minecraft:amethyst_block
fill 285 198 569 285 198 570 minecraft:amethyst_block
fill 285 198 575 285 198 576 minecraft:amethyst_block
fill 285 198 581 285 198 582 minecraft:amethyst_block
fill 285 198 587 285 198 588 minecraft:amethyst_block
fill 285 198 593 285 198 594 minecraft:amethyst_block
fill 286 198 558 287 198 558 minecraft:purple_stained_glass
fill 286 198 563 287 198 564 minecraft:purple_stained_glass
fill 286 198 569 287 198 570 minecraft:purple_stained_glass
fill 286 198 575 287 198 576 minecraft:purple_stained_glass
fill 286 198 581 287 198 582 minecraft:purple_stained_glass
fill 286 198 587 287 198 588 minecraft:purple_stained_glass
fill 286 198 593 287 198 594 minecraft:purple_stained_glass
setblock 288 198 558 minecraft:amethyst_block
fill 288 198 563 288 198 564 minecraft:amethyst_block
fill 288 198 569 288 198 570 minecraft:amethyst_block
fill 288 198 575 288 198 576 minecraft:amethyst_block
fill 288 198 581 288 198 582 minecraft:amethyst_block
fill 288 198 587 288 198 588 minecraft:amethyst_block
fill 288 198 593 288 198 594 minecraft:amethyst_block
fill 289 198 558 290 198 558 minecraft:purple_stained_glass
fill 289 198 563 290 198 564 minecraft:purple_stained_glass
fill 289 198 569 290 198 570 minecraft:purple_stained_glass
fill 289 198 575 290 198 576 minecraft:purple_stained_glass
fill 289 198 581 290 198 582 minecraft:purple_stained_glass
fill 289 198 587 290 198 588 minecraft:purple_stained_glass
fill 289 198 593 290 198 594 minecraft:purple_stained_glass
setblock 291 198 558 minecraft:amethyst_block
fill 291 198 563 291 198 564 minecraft:amethyst_block
fill 291 198 569 291 198 570 minecraft:amethyst_block
fill 291 198 575 291 198 576 minecraft:amethyst_block
fill 291 198 581 291 198 582 minecraft:amethyst_block
fill 291 198 587 291 198 588 minecraft:amethyst_block
fill 291 198 593 291 198 594 minecraft:amethyst_block
fill 292 198 558 293 198 558 minecraft:purple_stained_glass
fill 292 198 563 293 198 564 minecraft:purple_stained_glass
fill 292 198 569 293 198 570 minecraft:purple_stained_glass
fill 292 198 575 293 198 576 minecraft:purple_stained_glass
fill 292 198 581 293 198 582 minecraft:purple_stained_glass
fill 292 198 587 293 198 588 minecraft:purple_stained_glass
fill 292 198 593 293 198 594 minecraft:purple_stained_glass
setblock 294 198 558 minecraft:amethyst_block
fill 294 198 563 294 198 564 minecraft:amethyst_block
fill 294 198 569 294 198 570 minecraft:amethyst_block
fill 294 198 575 294 198 576 minecraft:amethyst_block
fill 294 198 581 294 198 582 minecraft:amethyst_block
fill 294 198 587 294 198 588 minecraft:amethyst_block
fill 294 198 593 294 198 594 minecraft:amethyst_block
fill 295 198 558 296 198 558 minecraft:purple_stained_glass
fill 295 198 563 296 198 564 minecraft:purple_stained_glass
fill 295 198 569 296 198 570 minecraft:purple_stained_glass
fill 295 198 575 296 198 576 minecraft:purple_stained_glass
setblock 295 198 578 minecraft:purple_stained_glass
setblock 295 198 582 minecraft:purple_stained_glass
fill 295 198 587 296 198 588 minecraft:purple_stained_glass
fill 295 198 593 296 198 594 minecraft:purple_stained_glass
setblock 297 198 558 minecraft:amethyst_block
fill 297 198 563 297 198 564 minecraft:amethyst_block
fill 297 198 569 297 198 570 minecraft:amethyst_block
fill 297 198 575 297 198 576 minecraft:amethyst_block
fill 297 198 587 297 198 588 minecraft:amethyst_block
fill 297 198 593 297 198 594 minecraft:amethyst_block
fill 298 198 558 299 198 558 minecraft:purple_stained_glass
fill 298 198 563 299 198 564 minecraft:purple_stained_glass
fill 298 198 569 299 198 570 minecraft:purple_stained_glass
fill 298 198 575 299 198 576 minecraft:purple_stained_glass
fill 298 198 587 299 198 588 minecraft:purple_stained_glass
fill 298 198 593 299 198 594 minecraft:purple_stained_glass
setblock 300 198 558 minecraft:amethyst_block
fill 300 198 563 300 198 564 minecraft:amethyst_block
fill 300 198 569 300 198 570 minecraft:amethyst_block
fill 300 198 575 300 198 577 minecraft:amethyst_block
fill 300 198 583 302 198 583 minecraft:amethyst_block
fill 300 198 587 300 198 588 minecraft:amethyst_block
fill 300 198 593 300 198 594 minecraft:amethyst_block
setblock 300 198 599 minecraft:white_concrete
fill 301 198 558 302 198 558 minecraft:purple_stained_glass
fill 301 198 563 302 198 564 minecraft:purple_stained_glass
fill 301 198 569 302 198 570 minecraft:purple_stained_glass
fill 301 198 575 302 198 576 minecraft:purple_stained_glass
fill 301 198 577 302 198 577 minecraft:amethyst_block
fill 301 198 578 302 198 578 minecraft:purple_stained_glass
fill 301 198 582 302 198 582 minecraft:purple_stained_glass
fill 301 198 587 302 198 588 minecraft:purple_stained_glass
fill 301 198 593 302 198 594 minecraft:purple_stained_glass
setblock 302 198 579 minecraft:purple_stained_glass
fill 302 198 580 306 198 580 minecraft:amethyst_block
setblock 302 198 581 minecraft:purple_stained_glass
setblock 302 198 599 minecraft:light_blue_stained_glass
setblock 303 198 558 minecraft:amethyst_block
fill 303 198 563 303 198 564 minecraft:amethyst_block
fill 303 198 569 303 198 570 minecraft:amethyst_block
fill 303 198 575 303 198 579 minecraft:sea_lantern
fill 303 198 581 303 198 585 minecraft:sea_lantern
fill 303 198 587 303 198 588 minecraft:amethyst_block
fill 303 198 593 303 198 594 minecraft:amethyst_block
fill 304 198 558 305 198 558 minecraft:purple_stained_glass
fill 304 198 563 305 198 564 minecraft:purple_stained_glass
fill 304 198 569 305 198 570 minecraft:purple_stained_glass
fill 304 198 575 307 198 575 minecraft:sea_lantern
fill 304 198 576 306 198 578 minecraft:purple_stained_glass
fill 304 198 579 306 198 579 minecraft:sea_lantern
fill 304 198 581 306 198 581 minecraft:sea_lantern
fill 304 198 582 306 198 584 minecraft:purple_stained_glass
fill 304 198 585 307 198 585 minecraft:sea_lantern
fill 304 198 587 305 198 588 minecraft:purple_stained_glass
fill 304 198 593 305 198 594 minecraft:purple_stained_glass
setblock 306 198 558 minecraft:amethyst_block
fill 306 198 563 306 198 564 minecraft:amethyst_block
fill 306 198 569 306 198 570 minecraft:amethyst_block
fill 306 198 587 306 198 588 minecraft:amethyst_block
fill 306 198 593 306 198 594 minecraft:amethyst_block
fill 307 198 558 308 198 558 minecraft:purple_stained_glass
fill 307 198 563 308 198 564 minecraft:purple_stained_glass
fill 307 198 569 308 198 570 minecraft:purple_stained_glass
fill 307 198 576 307 198 578 minecraft:sea_lantern
fill 307 198 579 307 198 581 minecraft:ochre_froglight
fill 307 198 582 307 198 584 minecraft:sea_lantern
fill 307 198 587 308 198 588 minecraft:purple_stained_glass
fill 307 198 593 308 198 594 minecraft:purple_stained_glass
fill 308 198 575 308 198 576 minecraft:purple_stained_glass
fill 308 198 577 309 198 577 minecraft:amethyst_block
fill 308 198 578 310 198 578 minecraft:ochre_froglight
fill 308 198 582 310 198 582 minecraft:ochre_froglight
fill 308 198 583 310 198 583 minecraft:amethyst_block
fill 308 198 584 310 198 585 minecraft:purple_stained_glass
setblock 309 198 558 minecraft:amethyst_block
fill 309 198 563 309 198 564 minecraft:amethyst_block
fill 309 198 569 309 198 570 minecraft:amethyst_block
fill 309 198 575 309 198 576 minecraft:amethyst_block
fill 309 198 587 309 198 588 minecraft:amethyst_block
fill 309 198 593 309 198 594 minecraft:amethyst_block
setblock 310 198 557 minecraft:light_blue_stained_glass
fill 310 198 558 311 198 558 minecraft:purple_stained_glass
fill 310 198 563 311 198 564 minecraft:purple_stained_glass
fill 310 198 569 311 198 570 minecraft:purple_stained_glass
fill 310 198 574 310 198 577 minecraft:sea_lantern
fill 310 198 587 311 198 588 minecraft:purple_stained_glass
fill 310 198 593 311 198 594 minecraft:purple_stained_glass
fill 311 198 574 314 198 574 minecraft:sea_lantern
fill 311 198 575 313 198 577 minecraft:purple_stained_glass
fill 311 198 578 314 198 578 minecraft:sea_lantern
fill 311 198 579 311 198 581 minecraft:ochre_froglight
fill 311 198 582 311 198 585 minecraft:sea_lantern
setblock 312 198 558 minecraft:amethyst_block
fill 312 198 563 312 198 564 minecraft:amethyst_block
fill 312 198 569 312 198 570 minecraft:amethyst_block
fill 312 198 579 323 198 579 minecraft:purple_stained_glass
fill 312 198 580 323 198 580 minecraft:amethyst_block
fill 312 198 581 315 198 581 minecraft:sea_lantern
fill 312 198 582 314 198 584 minecraft:purple_stained_glass
fill 312 198 585 315 198 585 minecraft:sea_lantern
fill 312 198 587 312 198 588 minecraft:amethyst_block
fill 312 198 593 312 198 594 minecraft:amethyst_block
fill 313 198 558 314 198 558 minecraft:purple_stained_glass
fill 313 198 563 314 198 564 minecraft:purple_stained_glass
fill 313 198 569 314 198 570 minecraft:purple_stained_glass
fill 313 198 587 314 198 588 minecraft:purple_stained_glass
fill 313 198 593 314 198 594 minecraft:purple_stained_glass
fill 314 198 575 314 198 577 minecraft:sea_lantern
fill 314 198 599 314 219 599 minecraft:magenta_stained_glass
setblock 315 198 558 minecraft:amethyst_block
fill 315 198 563 315 198 564 minecraft:amethyst_block
fill 315 198 569 315 198 570 minecraft:amethyst_block
fill 315 198 574 315 198 577 minecraft:amethyst_block
fill 315 198 578 323 198 578 minecraft:purple_stained_glass
fill 315 198 582 315 198 584 minecraft:sea_lantern
fill 315 198 587 315 198 588 minecraft:amethyst_block
fill 315 198 593 315 198 594 minecraft:amethyst_block
fill 316 198 558 317 198 558 minecraft:purple_stained_glass
fill 316 198 563 317 198 564 minecraft:purple_stained_glass
fill 316 198 569 317 198 570 minecraft:purple_stained_glass
fill 316 198 574 323 198 574 minecraft:amethyst_block
fill 316 198 575 317 198 576 minecraft:purple_stained_glass
fill 316 198 577 323 198 577 minecraft:amethyst_block
fill 316 198 581 317 198 582 minecraft:purple_stained_glass
fill 316 198 583 323 198 583 minecraft:amethyst_block
fill 316 198 584 323 198 585 minecraft:purple_stained_glass
fill 316 198 587 317 198 588 minecraft:purple_stained_glass
fill 316 198 593 317 198 594 minecraft:purple_stained_glass
setblock 318 198 558 minecraft:amethyst_block
fill 318 198 563 318 198 564 minecraft:amethyst_block
fill 318 198 569 318 198 570 minecraft:amethyst_block
fill 318 198 575 318 198 576 minecraft:amethyst_block
fill 318 198 581 318 198 582 minecraft:amethyst_block
fill 318 198 587 318 198 588 minecraft:amethyst_block
fill 318 198 593 318 198 594 minecraft:amethyst_block
fill 319 198 558 320 198 558 minecraft:purple_stained_glass
fill 319 198 563 320 198 564 minecraft:purple_stained_glass
fill 319 198 569 320 198 570 minecraft:purple_stained_glass
fill 319 198 575 320 198 576 minecraft:purple_stained_glass
fill 319 198 581 320 198 582 minecraft:purple_stained_glass
fill 319 198 587 320 198 588 minecraft:purple_stained_glass
fill 319 198 593 320 198 594 minecraft:purple_stained_glass
setblock 321 198 558 minecraft:amethyst_block
fill 321 198 563 321 198 564 minecraft:amethyst_block
fill 321 198 569 321 198 570 minecraft:amethyst_block
fill 321 198 575 321 198 576 minecraft:amethyst_block
fill 321 198 581 321 198 582 minecraft:amethyst_block
fill 321 198 587 321 198 588 minecraft:amethyst_block
fill 321 198 593 321 198 594 minecraft:amethyst_block
fill 322 198 558 323 198 558 minecraft:purple_stained_glass
fill 322 198 563 323 198 564 minecraft:purple_stained_glass
fill 322 198 569 323 198 570 minecraft:purple_stained_glass
fill 322 198 575 323 198 576 minecraft:purple_stained_glass
fill 322 198 581 323 198 582 minecraft:purple_stained_glass
fill 322 198 587 323 198 588 minecraft:purple_stained_glass
fill 322 198 593 323 198 594 minecraft:purple_stained_glass
fill 324 198 586 324 219 586 minecraft:magenta_stained_glass
setblock 282 199 573 minecraft:white_concrete
setblock 284 199 557 minecraft:sea_lantern
setblock 296 199 599 minecraft:light_blue_stained_glass
fill 300 199 599 300 212 599 minecraft:magenta_stained_glass
fill 302 199 599 302 221 599 minecraft:magenta_stained_glass
fill 310 199 557 310 220 557 minecraft:magenta_stained_glass
setblock 313 199 599 minecraft:sea_lantern
setblock 324 199 566 minecraft:sea_lantern
fill 282 200 573 282 223 573 minecraft:magenta_stained_glass
setblock 282 200 592 minecraft:sea_lantern
setblock 282 200 594 minecraft:light_blue_stained_glass
fill 284 200 557 284 213 557 minecraft:magenta_stained_glass
setblock 285 200 560 minecraft:light[level=14]
setblock 285 200 568 minecraft:light[level=14]
setblock 285 200 576 minecraft:light[level=14]
setblock 285 200 584 minecraft:light[level=14]
setblock 285 200 592 minecraft:light[level=14]
setblock 293 200 560 minecraft:light[level=14]
setblock 293 200 568 minecraft:light[level=14]
setblock 293 200 576 minecraft:light[level=14]
setblock 293 200 584 minecraft:light[level=14]
setblock 293 200 592 minecraft:light[level=14]
fill 296 200 599 296 201 599 minecraft:magenta_stained_glass
setblock 301 200 560 minecraft:light[level=14]
setblock 301 200 568 minecraft:light[level=14]
setblock 301 200 576 minecraft:light[level=14]
setblock 301 200 584 minecraft:light[level=14]
setblock 301 200 592 minecraft:light[level=14]
setblock 309 200 560 minecraft:light[level=14]
setblock 309 200 568 minecraft:light[level=14]
setblock 309 200 576 minecraft:light[level=14]
setblock 309 200 584 minecraft:light[level=14]
setblock 309 200 592 minecraft:light[level=14]
fill 313 200 599 313 223 599 minecraft:magenta_stained_glass
setblock 315 200 599 minecraft:white_concrete
setblock 317 200 560 minecraft:light[level=14]
setblock 317 200 568 minecraft:light[level=14]
setblock 317 200 576 minecraft:light[level=14]
setblock 317 200 584 minecraft:light[level=14]
setblock 317 200 592 minecraft:light[level=14]
fill 324 200 566 324 223 566 minecraft:magenta_stained_glass
fill 282 201 592 282 202 592 minecraft:magenta_stained_glass
fill 282 201 594 282 223 594 minecraft:magenta_stained_glass
fill 315 201 599 315 212 599 minecraft:magenta_stained_glass
setblock 296 202 599 minecraft:sea_lantern
fill 315 202 577 322 204 579 minecraft:amethyst_block
fill 316 202 576 321 204 576 minecraft:amethyst_block
fill 316 202 580 321 204 581 minecraft:amethyst_block
fill 317 202 575 320 204 575 minecraft:amethyst_block
fill 318 202 582 319 204 582 minecraft:amethyst_block
setblock 324 202 559 minecraft:light_blue_stained_glass
setblock 324 202 588 minecraft:sea_lantern
setblock 282 203 592 minecraft:white_concrete
setblock 290 203 599 minecraft:light_blue_stained_glass
setblock 294 203 557 minecraft:sea_lantern
setblock 295 203 599 minecraft:sea_lantern
fill 296 203 599 296 210 599 minecraft:magenta_stained_glass
setblock 297 203 599 minecraft:white_concrete
setblock 299 203 557 minecraft:light_blue_stained_glass
fill 315 203 576 315 204 576 minecraft:amethyst_block
fill 315 203 580 315 204 580 minecraft:amethyst_block
fill 316 203 575 316 204 575 minecraft:amethyst_block
fill 317 203 582 317 204 582 minecraft:amethyst_block
fill 320 203 582 320 204 582 minecraft:amethyst_block
fill 321 203 575 321 204 575 minecraft:amethyst_block
fill 322 203 576 322 204 576 minecraft:amethyst_block
fill 322 203 580 322 204 580 minecraft:amethyst_block
fill 324 203 559 324 223 559 minecraft:magenta_stained_glass
fill 324 203 588 324 220 588 minecraft:magenta_stained_glass
fill 282 204 592 282 217 592 minecraft:magenta_stained_glass
fill 290 204 599 290 219 599 minecraft:magenta_stained_glass
fill 294 204 557 294 207 557 minecraft:magenta_stained_glass
setblock 295 204 599 minecraft:magenta_stained_glass
fill 297 204 599 297 209 599 minecraft:magenta_stained_glass
fill 299 204 557 299 221 557 minecraft:magenta_stained_glass
setblock 299 204 599 minecraft:white_concrete
fill 314 204 577 314 204 580 minecraft:amethyst_block
setblock 315 204 581 minecraft:amethyst_block
setblock 316 204 582 minecraft:amethyst_block
fill 317 204 574 320 204 574 minecraft:amethyst_block
fill 318 204 583 319 204 583 minecraft:amethyst_block
setblock 321 204 582 minecraft:amethyst_block
setblock 322 204 581 minecraft:amethyst_block
setblock 323 204 557 minecraft:white_concrete
fill 323 204 577 323 204 580 minecraft:amethyst_block
setblock 324 204 560 minecraft:white_concrete
setblock 295 205 599 minecraft:white_concrete
fill 299 205 599 299 220 599 minecraft:magenta_stained_glass
setblock 304 205 599 minecraft:white_concrete
fill 318 205 578 319 207 579 minecraft:light_blue_stained_glass
fill 323 205 557 323 223 557 minecraft:magenta_stained_glass
fill 324 205 560 324 221 560 minecraft:magenta_stained_glass
setblock 324 205 584 minecraft:white_concrete
fill 295 206 599 295 207 599 minecraft:magenta_stained_glass
fill 304 206 599 304 219 599 minecraft:magenta_stained_glass
setblock 306 206 557 minecraft:light_blue_stained_glass
setblock 311 206 557 minecraft:white_concrete
fill 324 206 584 324 215 584 minecraft:magenta_stained_glass
setblock 282 207 587 minecraft:white_concrete
fill 306 207 557 306 223 557 minecraft:magenta_stained_glass
setblock 308 207 557 minecraft:white_concrete
fill 311 207 557 311 223 557 minecraft:magenta_stained_glass
fill 282 208 587 282 223 587 minecraft:magenta_stained_glass
setblock 285 208 560 minecraft:light[level=14]
setblock 285 208 568 minecraft:light[level=14]
setblock 285 208 576 minecraft:light[level=14]
setblock 285 208 584 minecraft:light[level=14]
setblock 285 208 592 minecraft:light[level=14]
setblock 290 208 557 minecraft:white_concrete
setblock 293 208 560 minecraft:light[level=14]
setblock 293 208 568 minecraft:light[level=14]
setblock 293 208 576 minecraft:light[level=14]
setblock 293 208 584 minecraft:light[level=14]
setblock 293 208 592 minecraft:light[level=14]
setblock 294 208 557 minecraft:white_concrete
setblock 295 208 599 minecraft:light_blue_stained_glass
fill 296 208 595 297 209 595 minecraft:amethyst_block
setblock 301 208 560 minecraft:light[level=14]
setblock 301 208 568 minecraft:light[level=14]
setblock 301 208 576 minecraft:light[level=14]
setblock 301 208 584 minecraft:light[level=14]
setblock 301 208 592 minecraft:light[level=14]
fill 308 208 557 308 223 557 minecraft:magenta_stained_glass
setblock 309 208 560 minecraft:light[level=14]
setblock 309 208 568 minecraft:light[level=14]
setblock 309 208 576 minecraft:light[level=14]
setblock 309 208 584 minecraft:light[level=14]
setblock 309 208 592 minecraft:light[level=14]
setblock 310 208 599 minecraft:white_concrete
setblock 316 208 557 minecraft:light_blue_stained_glass
setblock 317 208 557 minecraft:white_concrete
setblock 317 208 560 minecraft:light[level=14]
setblock 317 208 568 minecraft:light[level=14]
setblock 317 208 576 minecraft:light[level=14]
setblock 317 208 584 minecraft:light[level=14]
setblock 317 208 592 minecraft:light[level=14]
setblock 317 208 599 minecraft:sea_lantern
setblock 288 209 557 minecraft:sea_lantern
fill 290 209 557 290 218 557 minecraft:magenta_stained_glass
fill 294 209 557 294 223 557 minecraft:magenta_stained_glass
fill 295 209 599 295 223 599 minecraft:magenta_stained_glass
fill 310 209 599 310 215 599 minecraft:magenta_stained_glass
fill 316 209 557 317 223 557 minecraft:magenta_stained_glass
fill 317 209 599 317 223 599 minecraft:magenta_stained_glass
setblock 324 209 563 minecraft:white_concrete
fill 324 209 564 324 223 564 minecraft:magenta_stained_glass
setblock 282 210 578 minecraft:light_blue_stained_glass
fill 288 210 557 288 223 557 minecraft:magenta_stained_glass
fill 289 210 580 289 211 580 minecraft:jungle_log
fill 295 210 579 299 210 581 minecraft:jungle_log
setblock 297 210 599 minecraft:sea_lantern
fill 300 210 579 305 210 581 minecraft:jungle_leaves[persistent=true]
fill 301 210 577 305 215 578 minecraft:jungle_leaves[persistent=true]
fill 301 210 582 305 215 583 minecraft:jungle_leaves[persistent=true]
fill 302 210 576 310 212 576 minecraft:jungle_leaves[persistent=true]
fill 302 210 584 310 212 584 minecraft:jungle_leaves[persistent=true]
fill 304 210 575 308 217 575 minecraft:jungle_leaves[persistent=true]
fill 304 210 585 308 217 585 minecraft:jungle_leaves[persistent=true]
fill 306 210 577 306 214 577 minecraft:jungle_leaves[persistent=true]
fill 306 210 583 306 214 583 minecraft:jungle_leaves[persistent=true]
fill 307 210 580 307 211 580 minecraft:jungle_log
fill 324 210 563 324 217 563 minecraft:magenta_stained_glass
setblock 324 210 574 minecraft:white_concrete
fill 282 211 578 282 221 578 minecraft:magenta_stained_glass
setblock 282 211 588 minecraft:light_blue_stained_glass
fill 290 211 580 292 211 580 minecraft:jungle_log
fill 294 211 573 294 211 574 minecraft:jungle_log
fill 294 211 586 294 211 587 minecraft:jungle_log
fill 295 211 574 295 211 575 minecraft:jungle_log
fill 295 211 579 295 211 581 minecraft:jungle_log
fill 295 211 585 295 211 586 minecraft:jungle_log
setblock 296 211 578 minecraft:jungle_log
fill 296 211 579 303 211 581 minecraft:jungle_leaves[persistent=true]
setblock 296 211 582 minecraft:jungle_log
setblock 296 211 599 minecraft:sea_lantern
fill 297 211 577 300 211 578 minecraft:jungle_leaves[persistent=true]
fill 297 211 582 300 211 583 minecraft:jungle_leaves[persistent=true]
fill 297 211 599 297 223 599 minecraft:magenta_stained_glass
fill 298 211 575 300 211 576 minecraft:jungle_leaves[persistent=true]
fill 298 211 584 300 211 585 minecraft:jungle_leaves[persistent=true]
fill 299 211 574 300 216 574 minecraft:jungle_leaves[persistent=true]
fill 299 211 586 300 216 586 minecraft:jungle_leaves[persistent=true]
setblock 301 211 557 minecraft:white_concrete
fill 301 211 573 301 216 573 minecraft:jungle_leaves[persistent=true]
fill 301 211 574 301 211 575 minecraft:jungle_log
fill 301 211 576 301 220 576 minecraft:jungle_leaves[persistent=true]
fill 301 211 584 301 220 584 minecraft:jungle_leaves[persistent=true]
fill 301 211 585 301 211 586 minecraft:jungle_log
fill 301 211 587 301 216 587 minecraft:jungle_leaves[persistent=true]
fill 302 211 557 302 223 557 minecraft:magenta_stained_glass
fill 302 211 573 302 211 574 minecraft:jungle_log
fill 302 211 575 303 216 575 minecraft:jungle_leaves[persistent=true]
fill 302 211 585 303 216 585 minecraft:jungle_leaves[persistent=true]
fill 302 211 586 302 211 587 minecraft:jungle_log
fill 303 211 572 309 216 574 minecraft:jungle_leaves[persistent=true]
fill 303 211 586 309 216 588 minecraft:jungle_leaves[persistent=true]
fill 304 211 579 305 213 579 minecraft:jungle_leaves[persistent=true]
fill 304 211 580 306 211 580 minecraft:jungle_log
fill 304 211 581 305 213 581 minecraft:jungle_leaves[persistent=true]
fill 309 211 575 314 216 575 minecraft:jungle_leaves[persistent=true]
fill 309 211 585 314 216 585 minecraft:jungle_leaves[persistent=true]
fill 310 211 573 311 216 574 minecraft:jungle_leaves[persistent=true]
fill 310 211 586 311 216 587 minecraft:jungle_leaves[persistent=true]
fill 311 211 576 314 215 576 minecraft:jungle_leaves[persistent=true]
fill 311 211 584 314 215 584 minecraft:jungle_leaves[persistent=true]
fill 312 211 574 313 216 574 minecraft:jungle_leaves[persistent=true]
fill 312 211 577 315 214 577 minecraft:jungle_leaves[persistent=true]
fill 312 211 583 315 214 583 minecraft:jungle_leaves[persistent=true]
fill 312 211 586 313 216 586 minecraft:jungle_leaves[persistent=true]
fill 313 211 578 315 212 582 minecraft:jungle_leaves[persistent=true]
fill 316 211 579 316 216 581 minecraft:jungle_leaves[persistent=true]
setblock 316 211 599 minecraft:light_blue_stained_glass
fill 320 211 557 320 223 557 minecraft:magenta_stained_glass
setblock 321 211 557 minecraft:light_blue_stained_glass
fill 324 211 574 324 218 574 minecraft:magenta_stained_glass
fill 282 212 588 282 223 588 minecraft:magenta_stained_glass
setblock 285 212 557 minecraft:white_concrete
fill 292 212 580 295 212 580 minecraft:jungle_log
setblock 295 212 575 minecraft:jungle_log
fill 295 212 576 295 215 579 minecraft:jungle_leaves[persistent=true]
fill 295 212 581 295 215 584 minecraft:jungle_leaves[persistent=true]
setblock 295 212 585 minecraft:jungle_log
fill 296 212 575 300 215 575 minecraft:jungle_leaves[persistent=true]
fill 296 212 576 296 212 577 minecraft:jungle_log
fill 296 212 578 300 212 582 minecraft:jungle_leaves[persistent=true]
fill 296 212 583 296 212 584 minecraft:jungle_log
fill 296 212 585 300 215 585 minecraft:jungle_leaves[persistent=true]
fill 296 212 599 296 221 599 minecraft:magenta_stained_glass
setblock 297 212 557 minecraft:sea_lantern
fill 297 212 574 298 215 574 minecraft:jungle_leaves[persistent=true]
fill 297 212 576 299 215 577 minecraft:jungle_leaves[persistent=true]
fill 297 212 583 299 215 584 minecraft:jungle_leaves[persistent=true]
fill 297 212 586 298 215 586 minecraft:jungle_leaves[persistent=true]
fill 298 212 573 300 215 573 minecraft:jungle_leaves[persistent=true]
fill 298 212 587 300 215 587 minecraft:jungle_leaves[persistent=true]
fill 299 212 572 302 215 572 minecraft:jungle_leaves[persistent=true]
fill 299 212 588 302 215 588 minecraft:jungle_leaves[persistent=true]
fill 300 212 576 300 212 577 minecraft:jungle_log
fill 300 212 583 300 212 584 minecraft:jungle_log
fill 301 212 557 301 223 557 minecraft:magenta_stained_glass
fill 301 212 571 311 215 571 minecraft:jungle_leaves[persistent=true]
fill 301 212 574 302 216 574 minecraft:jungle_leaves[persistent=true]
setblock 301 212 575 minecraft:jungle_log
fill 301 212 579 303 220 579 minecraft:jungle_leaves[persistent=true]
fill 301 212 580 304 212 580 minecraft:jungle_log
fill 301 212 581 303 220 581 minecraft:jungle_leaves[persistent=true]
setblock 301 212 585 minecraft:jungle_log
fill 301 212 586 302 216 586 minecraft:jungle_leaves[persistent=true]
fill 301 212 589 311 215 589 minecraft:jungle_leaves[persistent=true]
fill 302 212 573 302 216 573 minecraft:jungle_leaves[persistent=true]
fill 302 212 587 302 216 587 minecraft:jungle_leaves[persistent=true]
fill 304 212 570 308 215 570 minecraft:jungle_leaves[persistent=true]
fill 304 212 590 308 215 590 minecraft:jungle_leaves[persistent=true]
setblock 305 212 580 minecraft:jungle_leaves[persistent=true]
fill 310 212 572 313 215 572 minecraft:jungle_leaves[persistent=true]
fill 310 212 588 313 215 588 minecraft:jungle_leaves[persistent=true]
fill 312 212 573 314 215 573 minecraft:jungle_leaves[persistent=true]
fill 312 212 587 314 215 587 minecraft:jungle_leaves[persistent=true]
fill 314 212 574 315 215 574 minecraft:jungle_leaves[persistent=true]
fill 314 212 586 315 215 586 minecraft:jungle_leaves[persistent=true]
fill 315 212 575 316 215 576 minecraft:jungle_leaves[persistent=true]
fill 315 212 584 316 215 585 minecraft:jungle_leaves[persistent=true]
fill 316 212 577 317 215 578 minecraft:jungle_leaves[persistent=true]
fill 316 212 582 317 215 583 minecraft:jungle_leaves[persistent=true]
fill 316 212 599 316 221 599 minecraft:magenta_stained_glass
fill 317 212 576 317 215 576 minecraft:jungle_leaves[persistent=true]
fill 317 212 579 317 215 581 minecraft:jungle_leaves[persistent=true]
fill 317 212 584 317 215 584 minecraft:jungle_leaves[persistent=true]
fill 318 212 580 318 215 580 minecraft:jungle_leaves[persistent=true]
fill 321 212 557 321 220 557 minecraft:magenta_stained_glass
setblock 324 212 569 minecraft:light_blue_stained_glass
setblock 282 213 576 minecraft:sea_lantern
setblock 282 213 581 minecraft:light_blue_stained_glass
fill 285 213 557 285 223 557 minecraft:magenta_stained_glass
setblock 293 213 599 minecraft:white_concrete
fill 294 213 576 294 214 584 minecraft:jungle_leaves[persistent=true]
fill 295 213 575 295 214 575 minecraft:jungle_leaves[persistent=true]
fill 295 213 580 301 213 580 minecraft:jungle_log
fill 295 213 585 295 214 585 minecraft:jungle_leaves[persistent=true]
fill 296 213 574 296 214 574 minecraft:jungle_leaves[persistent=true]
fill 296 213 576 296 215 579 minecraft:jungle_leaves[persistent=true]
fill 296 213 581 296 215 584 minecraft:jungle_leaves[persistent=true]
fill 296 213 586 296 214 586 minecraft:jungle_leaves[persistent=true]
fill 297 213 557 297 219 557 minecraft:magenta_stained_glass
fill 297 213 573 297 214 573 minecraft:jungle_leaves[persistent=true]
fill 297 213 578 297 213 579 minecraft:jungle_log
fill 297 213 581 297 213 582 minecraft:jungle_log
fill 297 213 587 297 214 587 minecraft:jungle_leaves[persistent=true]
fill 298 213 572 298 214 572 minecraft:jungle_leaves[persistent=true]
fill 298 213 578 298 221 578 minecraft:jungle_leaves[persistent=true]
fill 298 213 579 299 213 579 minecraft:jungle_log
fill 298 213 581 299 213 581 minecraft:jungle_log
fill 298 213 582 298 221 582 minecraft:jungle_leaves[persistent=true]
fill 298 213 588 298 214 588 minecraft:jungle_leaves[persistent=true]
fill 299 213 571 300 214 571 minecraft:jungle_leaves[persistent=true]
setblock 299 213 578 minecraft:jungle_log
setblock 299 213 582 minecraft:jungle_log
fill 299 213 589 300 214 589 minecraft:jungle_leaves[persistent=true]
fill 300 213 576 300 220 579 minecraft:jungle_leaves[persistent=true]
fill 300 213 581 300 220 584 minecraft:jungle_leaves[persistent=true]
setblock 300 213 599 minecraft:light_blue_stained_glass
fill 301 213 570 303 214 570 minecraft:jungle_leaves[persistent=true]
fill 301 213 575 301 220 575 minecraft:jungle_leaves[persistent=true]
fill 301 213 585 301 220 585 minecraft:jungle_leaves[persistent=true]
fill 301 213 590 303 214 590 minecraft:jungle_leaves[persistent=true]
fill 302 213 576 308 213 576 minecraft:jungle_leaves[persistent=true]
fill 302 213 580 304 220 580 minecraft:jungle_leaves[persistent=true]
fill 302 213 584 308 213 584 minecraft:jungle_leaves[persistent=true]
fill 309 213 570 311 214 570 minecraft:jungle_leaves[persistent=true]
fill 309 213 590 311 214 590 minecraft:jungle_leaves[persistent=true]
setblock 310 213 576 minecraft:jungle_leaves[persistent=true]
setblock 310 213 584 minecraft:jungle_leaves[persistent=true]
fill 312 213 571 313 214 571 minecraft:jungle_leaves[persistent=true]
fill 312 213 589 313 214 589 minecraft:jungle_leaves[persistent=true]
fill 313 213 578 315 213 579 minecraft:jungle_leaves[persistent=true]
fill 313 213 581 315 213 582 minecraft:jungle_leaves[persistent=true]
fill 314 213 572 314 214 572 minecraft:jungle_leaves[persistent=true]
fill 314 213 580 315 216 580 minecraft:jungle_leaves[persistent=true]
fill 314 213 588 314 214 588 minecraft:jungle_leaves[persistent=true]
fill 315 213 573 315 214 573 minecraft:jungle_leaves[persistent=true]
fill 315 213 587 315 214 587 minecraft:jungle_leaves[persistent=true]
setblock 315 213 599 minecraft:light_blue_stained_glass
fill 316 213 574 316 214 574 minecraft:jungle_leaves[persistent=true]
fill 316 213 586 316 214 586 minecraft:jungle_leaves[persistent=true]
fill 317 213 575 317 214 575 minecraft:jungle_leaves[persistent=true]
fill 317 213 585 317 214 585 minecraft:jungle_leaves[persistent=true]
fill 318 213 576 318 214 579 minecraft:jungle_leaves[persistent=true]
fill 318 213 581 318 214 584 minecraft:jungle_leaves[persistent=true]
fill 324 213 569 324 219 569 minecraft:magenta_stained_glass
setblock 282 214 565 minecraft:white_concrete
fill 282 214 576 282 215 576 minecraft:magenta_stained_glass
setblock 282 214 581 minecraft:magenta_stained_glass
setblock 284 214 557 minecraft:light_blue_stained_glass
setblock 287 214 599 minecraft:white_concrete
fill 291 214 597 293 219 597 minecraft:light_blue_stained_glass
fill 292 214 596 292 219 596 minecraft:light_blue_stained_glass
fill 292 214 598 292 219 598 minecraft:light_blue_stained_glass
fill 293 214 599 293 217 599 minecraft:magenta_stained_glass
fill 295 214 580 297 221 580 minecraft:jungle_leaves[persistent=true]
fill 297 214 578 297 221 579 minecraft:jungle_leaves[persistent=true]
fill 297 214 581 297 221 582 minecraft:jungle_leaves[persistent=true]
fill 298 214 579 299 221 579 minecraft:jungle_leaves[persistent=true]
setblock 298 214 580 minecraft:jungle_log
fill 298 214 581 299 221 581 minecraft:jungle_leaves[persistent=true]
fill 299 214 578 299 221 578 minecraft:jungle_leaves[persistent=true]
fill 299 214 580 301 221 580 minecraft:jungle_leaves[persistent=true]
fill 299 214 582 299 221 582 minecraft:jungle_leaves[persistent=true]
fill 300 214 599 300 216 599 minecraft:magenta_stained_glass
fill 302 214 576 307 215 576 minecraft:jungle_leaves[persistent=true]
fill 302 214 584 307 215 584 minecraft:jungle_leaves[persistent=true]
fill 304 214 579 304 219 579 minecraft:jungle_leaves[persistent=true]
fill 304 214 581 304 219 581 minecraft:jungle_leaves[persistent=true]
setblock 305 214 599 minecraft:white_concrete
fill 313 214 578 315 215 578 minecraft:jungle_leaves[persistent=true]
fill 313 214 582 315 215 582 minecraft:jungle_leaves[persistent=true]
fill 314 214 579 315 216 579 minecraft:jungle_leaves[persistent=true]
fill 314 214 581 315 216 581 minecraft:jungle_leaves[persistent=true]
fill 315 214 599 315 216 599 minecraft:magenta_stained_glass
setblock 324 214 594 minecraft:sea_lantern
fill 282 215 565 282 223 565 minecraft:magenta_stained_glass
setblock 282 215 568 minecraft:light_blue_stained_glass
setblock 282 215 581 minecraft:light_blue_stained_glass
fill 284 215 557 284 223 557 minecraft:magenta_stained_glass
fill 287 215 599 287 223 599 minecraft:magenta_stained_glass
fill 290 215 596 290 218 598 minecraft:light_blue_stained_glass
fill 291 215 595 291 219 596 minecraft:light_blue_stained_glass
fill 291 215 598 291 218 598 minecraft:light_blue_stained_glass
fill 292 215 595 293 219 595 minecraft:light_blue_stained_glass
fill 293 215 596 294 218 596 minecraft:light_blue_stained_glass
fill 293 215 598 294 218 598 minecraft:light_blue_stained_glass
setblock 294 215 580 minecraft:jungle_leaves[persistent=true]
fill 294 215 597 294 218 597 minecraft:light_blue_stained_glass
fill 298 215 580 298 221 580 minecraft:jungle_leaves[persistent=true]
fill 305 215 599 305 223 599 minecraft:magenta_stained_glass
fill 313 215 577 315 216 577 minecraft:jungle_leaves[persistent=true]
fill 313 215 583 315 216 583 minecraft:jungle_leaves[persistent=true]
setblock 318 215 557 minecraft:sea_lantern
setblock 321 215 599 minecraft:white_concrete
fill 322 215 599 322 224 599 minecraft:magenta_stained_glass
fill 324 215 594 324 223 594 minecraft:magenta_stained_glass
fill 282 216 568 282 223 568 minecraft:magenta_stained_glass
setblock 282 216 576 minecraft:white_concrete
setblock 282 216 577 minecraft:light_blue_stained_glass
fill 282 216 581 282 223 581 minecraft:magenta_stained_glass
setblock 285 216 560 minecraft:light[level=14]
setblock 285 216 568 minecraft:light[level=14]
setblock 285 216 576 minecraft:light[level=14]
setblock 285 216 584 minecraft:light[level=14]
setblock 285 216 592 minecraft:light[level=14]
fill 292 216 594 292 219 594 minecraft:light_blue_stained_glass
setblock 293 216 560 minecraft:light[level=14]
setblock 293 216 568 minecraft:light[level=14]
setblock 293 216 576 minecraft:light[level=14]
setblock 293 216 584 minecraft:light[level=14]
setblock 293 216 592 minecraft:light[level=14]
fill 295 216 578 296 221 579 minecraft:jungle_leaves[persistent=true]
fill 295 216 581 296 221 582 minecraft:jungle_leaves[persistent=true]
fill 296 216 577 299 221 577 minecraft:jungle_leaves[persistent=true]
fill 296 216 583 299 221 583 minecraft:jungle_leaves[persistent=true]
fill 298 216 575 299 220 576 minecraft:jungle_leaves[persistent=true]
fill 298 216 584 299 220 585 minecraft:jungle_leaves[persistent=true]
fill 300 216 575 300 220 575 minecraft:jungle_leaves[persistent=true]
fill 300 216 585 300 220 585 minecraft:jungle_leaves[persistent=true]
setblock 301 216 560 minecraft:light[level=14]
setblock 301 216 568 minecraft:light[level=14]
fill 301 216 577 304 219 578 minecraft:jungle_leaves[persistent=true]
fill 301 216 582 304 219 583 minecraft:jungle_leaves[persistent=true]
setblock 301 216 592 minecraft:light[level=14]
fill 302 216 576 306 217 576 minecraft:jungle_leaves[persistent=true]
fill 302 216 584 306 217 584 minecraft:jungle_leaves[persistent=true]
fill 305 216 577 305 217 577 minecraft:jungle_leaves[persistent=true]
fill 305 216 583 305 217 583 minecraft:jungle_leaves[persistent=true]
setblock 309 216 560 minecraft:light[level=14]
setblock 309 216 568 minecraft:light[level=14]
setblock 309 216 592 minecraft:light[level=14]
setblock 310 216 599 minecraft:light_blue_stained_glass
fill 312 216 576 314 216 576 minecraft:jungle_leaves[persistent=true]
fill 312 216 584 314 216 584 minecraft:jungle_leaves[persistent=true]
fill 314 216 578 315 216 578 minecraft:jungle_leaves[persistent=true]
fill 314 216 582 315 216 582 minecraft:jungle_leaves[persistent=true]
setblock 317 216 560 minecraft:light[level=14]
setblock 317 216 568 minecraft:light[level=14]
setblock 317 216 576 minecraft:light[level=14]
setblock 317 216 584 minecraft:light[level=14]
setblock 317 216 592 minecraft:light[level=14]
fill 318 216 557 318 223 557 minecraft:magenta_stained_glass
fill 321 216 599 321 223 599 minecraft:magenta_stained_glass
setblock 324 216 584 minecraft:white_concrete
fill 282 217 576 282 217 577 minecraft:magenta_stained_glass
setblock 282 217 585 minecraft:white_concrete
setblock 284 217 599 minecraft:sea_lantern
setblock 285 217 599 minecraft:light_blue_stained_glass
fill 286 217 599 286 223 599 minecraft:magenta_stained_glass
setblock 290 217 595 minecraft:light_blue_stained_glass
fill 291 217 594 291 219 594 minecraft:light_blue_stained_glass
fill 292 217 580 294 220 580 minecraft:jungle_leaves[persistent=true]
fill 293 217 577 294 220 579 minecraft:jungle_leaves[persistent=true]
fill 293 217 581 294 220 583 minecraft:jungle_leaves[persistent=true]
fill 293 217 594 293 219 594 minecraft:light_blue_stained_glass
fill 294 217 576 297 220 576 minecraft:jungle_leaves[persistent=true]
fill 294 217 584 297 220 584 minecraft:jungle_leaves[persistent=true]
setblock 294 217 595 minecraft:light_blue_stained_glass
fill 295 217 575 297 220 575 minecraft:jungle_leaves[persistent=true]
fill 295 217 577 295 220 577 minecraft:jungle_leaves[persistent=true]
fill 295 217 583 295 220 583 minecraft:jungle_leaves[persistent=true]
fill 295 217 585 297 220 585 minecraft:jungle_leaves[persistent=true]
fill 298 217 574 298 220 574 minecraft:jungle_leaves[persistent=true]
fill 298 217 586 298 220 586 minecraft:jungle_leaves[persistent=true]
setblock 300 217 599 minecraft:sea_lantern
fill 310 217 599 310 221 599 minecraft:magenta_stained_glass
setblock 311 217 599 minecraft:light_blue_stained_glass
setblock 315 217 599 minecraft:white_concrete
fill 324 217 584 324 221 584 minecraft:magenta_stained_glass
setblock 282 218 562 minecraft:sea_lantern
setblock 282 218 569 minecraft:white_concrete
setblock 282 218 576 minecraft:sea_lantern
fill 282 218 577 282 220 577 minecraft:magenta_stained_glass
fill 282 218 585 282 223 585 minecraft:magenta_stained_glass
setblock 282 218 592 minecraft:white_concrete
fill 284 218 599 285 220 599 minecraft:magenta_stained_glass
fill 292 218 577 292 219 579 minecraft:jungle_leaves[persistent=true]
fill 292 218 581 292 219 583 minecraft:jungle_leaves[persistent=true]
fill 292 218 593 292 220 593 minecraft:light_blue_stained_glass
fill 293 218 576 293 219 576 minecraft:jungle_leaves[persistent=true]
fill 293 218 584 293 219 584 minecraft:jungle_leaves[persistent=true]
setblock 293 218 599 minecraft:white_concrete
fill 294 218 575 294 219 575 minecraft:jungle_leaves[persistent=true]
fill 294 218 585 294 219 585 minecraft:jungle_leaves[persistent=true]
fill 295 218 574 297 219 574 minecraft:jungle_leaves[persistent=true]
fill 295 218 586 297 219 586 minecraft:jungle_leaves[persistent=true]
fill 299 218 574 301 219 574 minecraft:jungle_leaves[persistent=true]
fill 299 218 586 301 219 586 minecraft:jungle_leaves[persistent=true]
fill 300 218 599 300 219 599 minecraft:magenta_stained_glass
fill 302 218 575 302 219 576 minecraft:jungle_leaves[persistent=true]
fill 302 218 584 302 219 585 minecraft:jungle_leaves[persistent=true]
fill 303 218 576 303 219 576 minecraft:jungle_leaves[persistent=true]
fill 303 218 584 303 219 584 minecraft:jungle_leaves[persistent=true]
fill 311 218 599 311 223 599 minecraft:magenta_stained_glass
fill 315 218 599 315 223 599 minecraft:magenta_stained_glass
setblock 324 218 563 minecraft:white_concrete
fill 282 219 562 282 223 562 minecraft:magenta_stained_glass
fill 282 219 569 282 220 569 minecraft:magenta_stained_glass
fill 282 219 576 282 223 576 minecraft:magenta_stained_glass
fill 282 219 592 282 223 592 minecraft:magenta_stained_glass
setblock 283 219 557 minecraft:light_blue_stained_glass
setblock 290 219 557 minecraft:white_concrete
setblock 293 219 596 minecraft:light_blue_stained_glass
fill 293 219 599 293 225 599 minecraft:magenta_stained_glass
setblock 324 219 563 minecraft:magenta_stained_glass
setblock 324 219 568 minecraft:sea_lantern
setblock 324 219 574 minecraft:light_blue_stained_glass
setblock 282 220 558 minecraft:purple_stained_glass
setblock 282 220 567 minecraft:sea_lantern
setblock 282 220 582 minecraft:purple_stained_glass
setblock 282 220 584 minecraft:purple_stained_glass
setblock 282 220 590 minecraft:purple_stained_glass
setblock 282 220 591 minecraft:white_concrete
setblock 282 220 595 minecraft:purple_stained_glass
setblock 282 220 597 minecraft:purple_stained_glass
fill 283 220 557 283 223 557 minecraft:magenta_stained_glass
setblock 290 220 557 minecraft:purple_stained_glass
setblock 290 220 599 minecraft:purple_stained_glass
setblock 297 220 557 minecraft:white_concrete
setblock 298 220 599 minecraft:purple_stained_glass
setblock 300 220 557 minecraft:purple_stained_glass
setblock 300 220 599 minecraft:purple_stained_glass
fill 301 220 577 303 220 578 minecraft:jungle_leaves[persistent=true]
fill 301 220 582 303 220 583 minecraft:jungle_leaves[persistent=true]
setblock 302 220 576 minecraft:jungle_leaves[persistent=true]
setblock 302 220 584 minecraft:jungle_leaves[persistent=true]
setblock 304 220 599 minecraft:purple_stained_glass
fill 311 220 590 311 221 590 minecraft:light_blue_stained_glass
setblock 312 220 599 minecraft:purple_stained_glass
setblock 314 220 599 minecraft:light_blue_stained_glass
setblock 319 220 557 minecraft:light_blue_stained_glass
fill 319 220 599 319 221 599 minecraft:purple_stained_glass
setblock 323 220 599 minecraft:purple_stained_glass
setblock 324 220 563 minecraft:purple_stained_glass
setblock 324 220 565 minecraft:purple_stained_glass
setblock 324 220 568 minecraft:light_blue_stained_glass
setblock 324 220 569 minecraft:purple_stained_glass
fill 324 220 571 324 223 571 minecraft:magenta_stained_glass
setblock 324 220 572 minecraft:sea_lantern
fill 324 220 574 324 223 574 minecraft:magenta_stained_glass
setblock 324 220 577 minecraft:purple_stained_glass
setblock 324 220 582 minecraft:purple_stained_glass
setblock 324 220 586 minecraft:purple_stained_glass
fill 282 221 558 282 224 558 minecraft:magenta_stained_glass
fill 282 221 567 282 223 567 minecraft:magenta_stained_glass
setblock 282 221 569 minecraft:purple_stained_glass
setblock 282 221 577 minecraft:light_blue_stained_glass
fill 282 221 582 282 223 582 minecraft:magenta_stained_glass
fill 282 221 584 282 223 584 minecraft:magenta_stained_glass
fill 282 221 590 282 223 591 minecraft:magenta_stained_glass
fill 282 221 595 282 223 595 minecraft:magenta_stained_glass
fill 282 221 597 282 223 597 minecraft:magenta_stained_glass
fill 284 221 599 284 223 599 minecraft:magenta_stained_glass
setblock 285 221 599 minecraft:purple_stained_glass
setblock 288 221 599 minecraft:purple_stained_glass
fill 290 221 557 290 223 557 minecraft:magenta_stained_glass
fill 290 221 599 290 223 599 minecraft:magenta_stained_glass
setblock 296 221 557 minecraft:purple_stained_glass
fill 297 221 557 297 223 557 minecraft:magenta_stained_glass
fill 298 221 599 298 222 599 minecraft:magenta_stained_glass
setblock 299 221 599 minecraft:sea_lantern
fill 300 221 557 300 223 557 minecraft:magenta_stained_glass
fill 300 221 577 300 221 579 minecraft:jungle_leaves[persistent=true]
fill 300 221 581 300 221 583 minecraft:jungle_leaves[persistent=true]
fill 300 221 599 300 223 599 minecraft:magenta_stained_glass
fill 301 221 578 301 221 579 minecraft:jungle_leaves[persistent=true]
fill 301 221 581 301 221 582 minecraft:jungle_leaves[persistent=true]
setblock 301 221 599 minecraft:purple_stained_glass
fill 304 221 599 304 223 599 minecraft:magenta_stained_glass
setblock 310 221 557 minecraft:light_blue_stained_glass
fill 312 221 599 312 223 599 minecraft:magenta_stained_glass
setblock 314 221 599 minecraft:magenta_stained_glass
setblock 319 221 557 minecraft:magenta_stained_glass
setblock 320 221 599 minecraft:purple_stained_glass
fill 321 221 557 321 222 557 minecraft:purple_stained_glass
setblock 323 221 599 minecraft:magenta_stained_glass
setblock 324 221 557 minecraft:purple_stained_glass
setblock 324 221 563 minecraft:magenta_stained_glass
fill 324 221 565 324 223 565 minecraft:magenta_stained_glass
fill 324 221 568 324 221 569 minecraft:magenta_stained_glass
fill 324 221 572 324 223 572 minecraft:magenta_stained_glass
fill 324 221 577 324 223 578 minecraft:magenta_stained_glass
setblock 324 221 579 minecraft:light_blue_stained_glass
fill 324 221 582 324 223 582 minecraft:magenta_stained_glass
fill 324 221 586 324 223 586 minecraft:magenta_stained_glass
setblock 324 221 588 minecraft:purple_stained_glass
fill 324 221 591 324 221 592 minecraft:purple_stained_glass
setblock 324 221 597 minecraft:purple_stained_glass
fill 324 221 599 324 222 599 minecraft:purple_stained_glass
setblock 282 222 557 minecraft:purple_stained_glass
setblock 282 222 560 minecraft:purple_stained_glass
fill 282 222 563 282 222 564 minecraft:purple_stained_glass
fill 282 222 569 282 223 569 minecraft:magenta_stained_glass
fill 282 222 577 282 224 577 minecraft:magenta_stained_glass
setblock 282 222 578 minecraft:purple_stained_glass
setblock 282 222 593 minecraft:purple_stained_glass
setblock 282 222 596 minecraft:purple_stained_glass
fill 285 222 599 285 223 599 minecraft:magenta_stained_glass
fill 288 222 599 288 223 599 minecraft:magenta_stained_glass
setblock 289 222 557 minecraft:purple_stained_glass
fill 296 222 557 296 223 557 minecraft:magenta_stained_glass
setblock 296 222 599 minecraft:purple_stained_glass
setblock 299 222 557 minecraft:purple_stained_glass
fill 299 222 599 299 223 599 minecraft:magenta_stained_glass
fill 301 222 599 301 223 599 minecraft:magenta_stained_glass
setblock 302 222 599 minecraft:purple_stained_glass
setblock 308 222 599 minecraft:purple_stained_glass
setblock 309 222 557 minecraft:sea_lantern
fill 310 222 557 310 224 557 minecraft:magenta_stained_glass
setblock 310 222 599 minecraft:purple_stained_glass
fill 311 222 590 312 228 590 minecraft:amethyst_block
setblock 314 222 599 minecraft:purple_stained_glass
setblock 316 222 599 minecraft:purple_stained_glass
setblock 319 222 557 minecraft:purple_stained_glass
fill 319 222 599 320 223 599 minecraft:magenta_stained_glass
setblock 323 222 599 minecraft:purple_stained_glass
fill 324 222 557 324 223 557 minecraft:magenta_stained_glass
setblock 324 222 560 minecraft:purple_stained_glass
setblock 324 222 563 minecraft:purple_stained_glass
fill 324 222 568 324 223 568 minecraft:magenta_stained_glass
fill 324 222 569 324 222 570 minecraft:purple_stained_glass
setblock 324 222 573 minecraft:purple_stained_glass
setblock 324 222 579 minecraft:sea_lantern
setblock 324 222 584 minecraft:purple_stained_glass
fill 324 222 588 324 223 588 minecraft:magenta_stained_glass
setblock 324 222 590 minecraft:purple_stained_glass
fill 324 222 591 324 223 592 minecraft:magenta_stained_glass
fill 324 222 597 324 223 597 minecraft:magenta_stained_glass
setblock 282 223 557 minecraft:magenta_stained_glass
setblock 282 223 560 minecraft:magenta_stained_glass
fill 282 223 563 282 223 564 minecraft:magenta_stained_glass
setblock 282 223 578 minecraft:magenta_stained_glass
setblock 282 223 593 minecraft:magenta_stained_glass
setblock 282 223 596 minecraft:light_blue_stained_glass
setblock 289 223 557 minecraft:magenta_stained_glass
fill 296 223 599 296 227 599 minecraft:magenta_stained_glass
setblock 298 223 599 minecraft:sea_lantern
setblock 299 223 557 minecraft:sea_lantern
fill 302 223 569 302 224 569 minecraft:light_blue_stained_glass
setblock 302 223 599 minecraft:magenta_stained_glass
setblock 307 223 599 minecraft:sea_lantern
setblock 308 223 599 minecraft:magenta_stained_glass
setblock 309 223 557 minecraft:magenta_stained_glass
setblock 310 223 599 minecraft:magenta_stained_glass
setblock 314 223 599 minecraft:magenta_stained_glass
setblock 316 223 599 minecraft:magenta_stained_glass
setblock 319 223 557 minecraft:magenta_stained_glass
setblock 321 223 557 minecraft:magenta_stained_glass
fill 323 223 599 324 223 599 minecraft:magenta_stained_glass
setblock 324 223 560 minecraft:magenta_stained_glass
setblock 324 223 563 minecraft:light_blue_stained_glass
fill 324 223 569 324 223 570 minecraft:magenta_stained_glass
setblock 324 223 573 minecraft:magenta_stained_glass
setblock 324 223 579 minecraft:magenta_stained_glass
setblock 324 223 581 minecraft:white_concrete
fill 324 223 584 324 224 584 minecraft:magenta_stained_glass
setblock 324 223 590 minecraft:magenta_stained_glass
fill 282 224 557 285 224 557 minecraft:purple_stained_glass
fill 282 224 559 282 232 563 minecraft:purple_stained_glass
setblock 282 224 564 minecraft:magenta_stained_glass
fill 282 224 565 282 224 576 minecraft:purple_stained_glass
fill 282 224 578 282 224 599 minecraft:purple_stained_glass
fill 283 224 599 292 225 599 minecraft:purple_stained_glass
setblock 285 224 560 minecraft:light[level=14]
setblock 285 224 568 minecraft:light[level=14]
setblock 285 224 576 minecraft:light[level=14]
setblock 285 224 584 minecraft:light[level=14]
setblock 285 224 592 minecraft:light[level=14]
fill 287 224 557 297 225 557 minecraft:purple_stained_glass
setblock 293 224 560 minecraft:light[level=14]
setblock 293 224 568 minecraft:light[level=14]
setblock 293 224 576 minecraft:light[level=14]
setblock 293 224 584 minecraft:light[level=14]
setblock 293 224 592 minecraft:light[level=14]
fill 294 224 599 295 224 599 minecraft:purple_stained_glass
fill 297 224 599 318 224 599 minecraft:purple_stained_glass
fill 299 224 557 309 224 557 minecraft:purple_stained_glass
setblock 301 224 560 minecraft:light[level=14]
setblock 301 224 568 minecraft:light[level=14]
setblock 301 224 576 minecraft:light[level=14]
setblock 301 224 584 minecraft:light[level=14]
setblock 301 224 592 minecraft:light[level=14]
setblock 309 224 560 minecraft:light[level=14]
setblock 309 224 568 minecraft:light[level=14]
setblock 309 224 576 minecraft:light[level=14]
setblock 309 224 584 minecraft:light[level=14]
setblock 309 224 592 minecraft:light[level=14]
fill 311 224 557 314 229 557 minecraft:purple_stained_glass
fill 311 224 591 312 228 591 minecraft:amethyst_block
fill 316 224 557 321 224 557 minecraft:purple_stained_glass
setblock 317 224 560 minecraft:light[level=14]
setblock 317 224 568 minecraft:light[level=14]
setblock 317 224 576 minecraft:light[level=14]
setblock 317 224 584 minecraft:light[level=14]
setblock 317 224 592 minecraft:light[level=14]
setblock 319 224 599 minecraft:magenta_stained_glass
fill 320 224 599 321 232 599 minecraft:purple_stained_glass
fill 323 224 557 324 307 557 minecraft:purple_stained_glass
fill 323 224 599 324 250 599 minecraft:purple_stained_glass
fill 324 224 558 324 224 573 minecraft:purple_stained_glass
setblock 324 224 574 minecraft:sea_lantern
fill 324 224 575 324 224 583 minecraft:purple_stained_glass
fill 324 224 585 324 224 588 minecraft:purple_stained_glass
setblock 324 224 589 minecraft:sea_lantern
fill 324 224 590 324 224 598 minecraft:purple_stained_glass
fill 282 225 557 282 240 558 minecraft:purple_stained_glass
fill 282 225 564 282 228 564 minecraft:purple_stained_glass
fill 282 225 565 282 227 565 minecraft:magenta_stained_glass
fill 282 225 566 282 227 571 minecraft:purple_stained_glass
setblock 282 225 572 minecraft:magenta_stained_glass
fill 282 225 573 282 269 574 minecraft:purple_stained_glass
setblock 282 225 575 minecraft:magenta_stained_glass
fill 282 225 576 282 261 577 minecraft:purple_stained_glass
fill 282 225 578 282 226 578 minecraft:magenta_stained_glass
fill 282 225 579 282 232 580 minecraft:purple_stained_glass
fill 282 225 581 282 227 581 minecraft:magenta_stained_glass
fill 282 225 582 282 225 589 minecraft:purple_stained_glass
setblock 282 225 590 minecraft:magenta_stained_glass
fill 282 225 591 282 237 595 minecraft:purple_stained_glass
fill 282 225 596 282 225 597 minecraft:magenta_stained_glass
setblock 282 225 598 minecraft:purple_stained_glass
setblock 282 225 599 minecraft:magenta_stained_glass
fill 283 225 557 283 226 557 minecraft:magenta_stained_glass
fill 284 225 557 285 228 557 minecraft:purple_stained_glass
fill 294 225 599 294 255 599 minecraft:purple_stained_glass
setblock 295 225 599 minecraft:magenta_stained_glass
fill 297 225 599 297 282 599 minecraft:purple_stained_glass
fill 298 225 557 301 229 557 minecraft:purple_stained_glass
setblock 298 225 599 minecraft:magenta_stained_glass
fill 299 225 599 311 225 599 minecraft:purple_stained_glass
fill 302 225 557 303 225 557 minecraft:magenta_stained_glass
fill 304 225 557 307 235 557 minecraft:purple_stained_glass
setblock 308 225 557 minecraft:magenta_stained_glass
fill 309 225 557 310 225 557 minecraft:purple_stained_glass
fill 310 225 590 310 228 591 minecraft:amethyst_block
fill 311 225 589 312 228 589 minecraft:amethyst_block
fill 312 225 599 313 226 599 minecraft:magenta_stained_glass
fill 313 225 590 313 228 590 minecraft:amethyst_block
fill 314 225 599 319 225 599 minecraft:purple_stained_glass
fill 315 225 557 317 226 557 minecraft:purple_stained_glass
fill 318 225 557 318 227 557 minecraft:magenta_stained_glass
fill 319 225 557 321 233 557 minecraft:purple_stained_glass
setblock 322 225 557 minecraft:white_concrete
fill 322 225 599 322 227 599 minecraft:purple_stained_glass
fill 324 225 558 324 225 566 minecraft:purple_stained_glass
fill 324 225 567 324 227 567 minecraft:magenta_stained_glass
fill 324 225 568 324 227 582 minecraft:purple_stained_glass
fill 324 225 583 324 227 583 minecraft:magenta_stained_glass
fill 324 225 584 324 231 587 minecraft:purple_stained_glass
setblock 324 225 588 minecraft:magenta_stained_glass
fill 324 225 589 324 281 590 minecraft:purple_stained_glass
fill 324 225 591 324 226 591 minecraft:magenta_stained_glass
fill 324 225 592 324 225 595 minecraft:purple_stained_glass
fill 324 225 596 324 226 596 minecraft:magenta_stained_glass
fill 324 225 597 324 234 598 minecraft:purple_stained_glass
setblock 282 226 572 minecraft:purple_stained_glass
fill 282 226 575 282 254 575 minecraft:purple_stained_glass
setblock 282 226 582 minecraft:magenta_stained_glass
fill 282 226 583 282 237 588 minecraft:purple_stained_glass
setblock 282 226 589 minecraft:sea_lantern
fill 282 226 590 282 241 590 minecraft:purple_stained_glass
fill 282 226 596 282 282 596 minecraft:purple_stained_glass
fill 282 226 597 282 227 597 minecraft:magenta_stained_glass
setblock 282 226 598 minecraft:white_concrete
fill 282 226 599 287 232 599 minecraft:purple_stained_glass
fill 283 226 580 284 229 582 minecraft:light_blue_stained_glass
fill 285 226 581 285 229 581 minecraft:light_blue_stained_glass
fill 287 226 557 287 307 557 minecraft:purple_stained_glass
setblock 288 226 557 minecraft:magenta_stained_glass
setblock 288 226 599 minecraft:magenta_stained_glass
fill 289 226 557 289 307 557 minecraft:purple_stained_glass
fill 289 226 599 289 227 599 minecraft:purple_stained_glass
setblock 290 226 557 minecraft:magenta_stained_glass
setblock 290 226 599 minecraft:magenta_stained_glass
fill 291 226 557 293 239 557 minecraft:purple_stained_glass
fill 291 226 599 293 307 599 minecraft:purple_stained_glass
setblock 294 226 557 minecraft:magenta_stained_glass
fill 295 226 557 297 256 557 minecraft:purple_stained_glass
fill 295 226 599 295 307 599 minecraft:purple_stained_glass
fill 298 226 599 300 231 599 minecraft:purple_stained_glass
setblock 301 226 599 minecraft:light_blue_stained_glass
fill 302 226 557 302 227 557 minecraft:magenta_stained_glass
fill 302 226 562 302 227 563 minecraft:amethyst_block
fill 302 226 599 311 226 599 minecraft:purple_stained_glass
fill 303 226 557 303 307 557 minecraft:purple_stained_glass
fill 303 226 562 303 227 562 minecraft:amethyst_block
fill 308 226 557 308 303 557 minecraft:purple_stained_glass
setblock 309 226 557 minecraft:magenta_stained_glass
fill 310 226 557 310 249 557 minecraft:purple_stained_glass
fill 310 226 589 310 228 589 minecraft:amethyst_block
fill 311 226 592 312 228 592 minecraft:amethyst_block
fill 313 226 589 313 228 589 minecraft:amethyst_block
fill 313 226 591 313 228 591 minecraft:amethyst_block
fill 314 226 599 318 236 599 minecraft:purple_stained_glass
fill 317 226 558 317 226 564 minecraft:light_blue_stained_glass
setblock 319 226 599 minecraft:magenta_stained_glass
fill 322 226 557 322 303 557 minecraft:purple_stained_glass
fill 324 226 558 324 230 563 minecraft:purple_stained_glass
setblock 324 226 564 minecraft:magenta_stained_glass
fill 324 226 565 324 254 565 minecraft:purple_stained_glass
setblock 324 226 566 minecraft:magenta_stained_glass
fill 324 226 588 324 241 588 minecraft:purple_stained_glass
fill 324 226 592 324 226 594 minecraft:purple_stained_glass
setblock 324 226 595 minecraft:sea_lantern
setblock 282 227 572 minecraft:white_concrete
fill 282 227 578 282 238 578 minecraft:purple_stained_glass
fill 282 227 582 282 229 582 minecraft:purple_stained_glass
fill 282 227 589 282 307 589 minecraft:purple_stained_glass
fill 282 227 598 282 307 598 minecraft:purple_stained_glass
fill 283 227 557 283 307 557 minecraft:purple_stained_glass
fill 283 227 579 284 228 579 minecraft:light_blue_stained_glass
fill 283 227 583 284 228 583 minecraft:light_blue_stained_glass
fill 285 227 580 286 229 580 minecraft:light_blue_stained_glass
fill 285 227 582 286 229 582 minecraft:light_blue_stained_glass
fill 286 227 581 287 229 581 minecraft:light_blue_stained_glass
fill 288 227 557 288 260 557 minecraft:purple_stained_glass
fill 288 227 599 288 275 599 minecraft:purple_stained_glass
fill 290 227 557 290 236 557 minecraft:purple_stained_glass
fill 290 227 599 290 294 599 minecraft:purple_stained_glass
fill 294 227 557 294 281 557 minecraft:purple_stained_glass
fill 301 227 599 308 230 599 minecraft:purple_stained_glass
fill 309 227 557 309 270 557 minecraft:purple_stained_glass
fill 309 227 590 309 228 591 minecraft:amethyst_block
setblock 309 227 599 minecraft:white_concrete
fill 310 227 592 310 228 592 minecraft:amethyst_block
fill 310 227 599 311 228 599 minecraft:purple_stained_glass
fill 311 227 588 312 228 588 minecraft:amethyst_block
setblock 312 227 599 minecraft:magenta_stained_glass
fill 313 227 592 313 228 592 minecraft:amethyst_block
fill 313 227 599 313 307 599 minecraft:purple_stained_glass
setblock 315 227 557 minecraft:light_blue_stained_glass
fill 316 227 557 317 235 557 minecraft:purple_stained_glass
fill 316 227 558 318 227 561 minecraft:light_blue_stained_glass
fill 317 227 562 317 227 563 minecraft:light_blue_stained_glass
fill 319 227 599 319 287 599 minecraft:purple_stained_glass
fill 324 227 564 324 241 564 minecraft:purple_stained_glass
fill 324 227 566 324 279 566 minecraft:purple_stained_glass
fill 324 227 591 324 234 591 minecraft:purple_stained_glass
setblock 324 227 592 minecraft:light_blue_stained_glass
fill 324 227 593 324 227 596 minecraft:purple_stained_glass
fill 282 228 565 282 228 570 minecraft:purple_stained_glass
setblock 282 228 571 minecraft:light_blue_stained_glass
fill 282 228 572 282 265 572 minecraft:purple_stained_glass
fill 282 228 581 282 233 581 minecraft:purple_stained_glass
fill 282 228 597 282 233 597 minecraft:purple_stained_glass
setblock 285 228 579 minecraft:light_blue_stained_glass
setblock 285 228 583 minecraft:light_blue_stained_glass
fill 286 228 557 286 233 557 minecraft:purple_stained_glass
fill 287 228 580 288 229 580 minecraft:light_blue_stained_glass
fill 287 228 582 288 229 582 minecraft:light_blue_stained_glass
fill 288 228 581 289 229 581 minecraft:light_blue_stained_glass
setblock 289 228 599 minecraft:light_blue_stained_glass
fill 296 228 599 296 233 599 minecraft:purple_stained_glass
fill 302 228 557 302 233 557 minecraft:purple_stained_glass
fill 302 228 568 303 229 568 minecraft:light_blue_stained_glass
setblock 309 228 589 minecraft:amethyst_block
fill 309 228 599 309 307 599 minecraft:purple_stained_glass
setblock 310 228 588 minecraft:amethyst_block
fill 311 228 593 312 228 593 minecraft:amethyst_block
fill 312 228 599 312 233 599 minecraft:purple_stained_glass
setblock 313 228 588 minecraft:amethyst_block
fill 314 228 589 314 228 591 minecraft:amethyst_block
fill 315 228 557 315 249 557 minecraft:purple_stained_glass
fill 316 228 558 318 228 559 minecraft:light_blue_stained_glass
fill 317 228 560 317 228 561 minecraft:light_blue_stained_glass
fill 318 228 557 318 233 557 minecraft:purple_stained_glass
setblock 322 228 599 minecraft:sea_lantern
fill 324 228 567 324 230 579 minecraft:purple_stained_glass
setblock 324 228 580 minecraft:sea_lantern
fill 324 228 581 324 233 583 minecraft:purple_stained_glass
fill 324 228 592 324 307 592 minecraft:purple_stained_glass
setblock 324 228 593 minecraft:sea_lantern
fill 324 228 594 324 236 596 minecraft:purple_stained_glass
setblock 282 229 564 minecraft:light_blue_stained_glass
setblock 282 229 565 minecraft:sea_lantern
fill 282 229 566 282 230 571 minecraft:purple_stained_glass
setblock 284 229 557 minecraft:light_blue_stained_glass
fill 285 229 557 285 248 557 minecraft:purple_stained_glass
setblock 289 229 580 minecraft:light_blue_stained_glass
setblock 289 229 582 minecraft:light_blue_stained_glass
fill 289 229 599 289 307 599 minecraft:purple_stained_glass
setblock 290 229 581 minecraft:light_blue_stained_glass
fill 310 229 599 310 268 599 minecraft:purple_stained_glass
fill 311 229 589 311 229 591 minecraft:light_blue_stained_glass
setblock 311 229 599 minecraft:sea_lantern
fill 312 229 590 312 230 591 minecraft:light_blue_stained_glass
setblock 317 229 558 minecraft:light_blue_stained_glass
fill 322 229 599 322 235 599 minecraft:purple_stained_glass
fill 324 229 580 324 270 580 minecraft:purple_stained_glass
fill 324 229 593 324 233 593 minecraft:purple_stained_glass
fill 282 230 564 282 233 565 minecraft:purple_stained_glass
setblock 282 230 582 minecraft:sea_lantern
fill 284 230 557 284 243 557 minecraft:purple_stained_glass
fill 298 230 557 298 256 557 minecraft:purple_stained_glass
setblock 299 230 557 minecraft:light_blue_stained_glass
fill 300 230 557 301 249 557 minecraft:purple_stained_glass
fill 311 230 557 311 307 557 minecraft:purple_stained_glass
fill 311 230 590 311 230 591 minecraft:light_blue_stained_glass
fill 311 230 599 311 241 599 minecraft:purple_stained_glass
setblock 312 230 557 minecraft:sea_lantern
fill 313 230 557 314 236 557 minecraft:purple_stained_glass
fill 282 231 566 282 291 567 minecraft:purple_stained_glass
setblock 282 231 568 minecraft:white_concrete
fill 282 231 569 282 238 571 minecraft:purple_stained_glass
fill 282 231 582 282 307 582 minecraft:purple_stained_glass
fill 299 231 557 299 248 557 minecraft:purple_stained_glass
fill 301 231 599 305 236 599 minecraft:purple_stained_glass
setblock 306 231 599 minecraft:light_blue_stained_glass
fill 307 231 599 308 305 599 minecraft:purple_stained_glass
fill 311 231 590 312 231 590 minecraft:light_blue_stained_glass
fill 312 231 557 312 238 557 minecraft:purple_stained_glass
fill 321 231 590 323 234 592 minecraft:light_blue_stained_glass
fill 324 231 558 324 269 559 minecraft:purple_stained_glass
setblock 324 231 560 minecraft:white_concrete
fill 324 231 561 324 307 563 minecraft:purple_stained_glass
fill 324 231 567 324 233 571 minecraft:purple_stained_glass
setblock 324 231 572 minecraft:light_blue_stained_glass
fill 324 231 573 324 242 579 minecraft:purple_stained_glass
fill 282 232 568 282 307 568 minecraft:purple_stained_glass
setblock 285 232 560 minecraft:light[level=14]
setblock 285 232 568 minecraft:light[level=14]
setblock 285 232 576 minecraft:light[level=14]
setblock 285 232 584 minecraft:light[level=14]
setblock 285 232 592 minecraft:light[level=14]
setblock 293 232 560 minecraft:light[level=14]
setblock 293 232 568 minecraft:light[level=14]
setblock 293 232 576 minecraft:light[level=14]
setblock 293 232 584 minecraft:light[level=14]
setblock 293 232 592 minecraft:light[level=14]
fill 298 232 599 298 233 599 minecraft:sea_lantern
fill 299 232 599 300 238 599 minecraft:purple_stained_glass
setblock 301 232 560 minecraft:light[level=14]
setblock 301 232 568 minecraft:light[level=14]
setblock 301 232 576 minecraft:light[level=14]
setblock 301 232 584 minecraft:light[level=14]
setblock 301 232 592 minecraft:light[level=14]
fill 306 232 599 306 307 599 minecraft:purple_stained_glass
setblock 309 232 560 minecraft:light[level=14]
setblock 309 232 568 minecraft:light[level=14]
setblock 309 232 576 minecraft:light[level=14]
setblock 309 232 584 minecraft:light[level=14]
setblock 309 232 592 minecraft:light[level=14]
setblock 311 232 590 minecraft:light_blue_stained_glass
fill 317 232 558 319 237 559 minecraft:light_blue_stained_glass
setblock 317 232 560 minecraft:light[level=14]
setblock 317 232 568 minecraft:light[level=14]
setblock 317 232 576 minecraft:light[level=14]
setblock 317 232 584 minecraft:light[level=14]
setblock 317 232 592 minecraft:light[level=14]
fill 319 232 591 320 235 591 minecraft:light_blue_stained_glass
fill 320 232 590 320 234 590 minecraft:light_blue_stained_glass
fill 320 232 592 320 234 592 minecraft:light_blue_stained_glass
fill 321 232 589 323 233 589 minecraft:light_blue_stained_glass
fill 321 232 593 323 233 593 minecraft:light_blue_stained_glass
fill 324 232 560 324 307 560 minecraft:purple_stained_glass
fill 324 232 572 324 242 572 minecraft:purple_stained_glass
fill 324 232 584 324 267 584 minecraft:purple_stained_glass
setblock 324 232 585 minecraft:light_blue_stained_glass
fill 324 232 586 324 294 587 minecraft:purple_stained_glass
fill 282 233 559 282 238 562 minecraft:purple_stained_glass
setblock 282 233 563 minecraft:sea_lantern
fill 282 233 579 282 307 579 minecraft:purple_stained_glass
setblock 282 233 580 minecraft:white_concrete
fill 282 233 599 284 234 599 minecraft:purple_stained_glass
setblock 285 233 599 minecraft:white_concrete
fill 286 233 599 287 264 599 minecraft:purple_stained_glass
fill 316 233 558 316 236 559 minecraft:light_blue_stained_glass
fill 317 233 560 319 237 560 minecraft:light_blue_stained_glass
fill 318 233 591 318 235 591 minecraft:light_blue_stained_glass
fill 319 233 590 319 235 590 minecraft:light_blue_stained_glass
fill 319 233 592 319 235 592 minecraft:light_blue_stained_glass
fill 320 233 558 320 236 559 minecraft:light_blue_stained_glass
setblock 320 233 599 minecraft:sea_lantern
fill 321 233 599 321 307 599 minecraft:purple_stained_glass
fill 324 233 585 324 307 585 minecraft:purple_stained_glass
fill 282 234 563 282 257 564 minecraft:purple_stained_glass
fill 282 234 565 282 236 565 minecraft:magenta_stained_glass
fill 282 234 580 282 307 580 minecraft:purple_stained_glass
fill 282 234 581 282 236 581 minecraft:magenta_stained_glass
fill 282 234 597 282 236 597 minecraft:magenta_stained_glass
fill 285 234 599 285 298 599 minecraft:purple_stained_glass
fill 286 234 557 286 236 557 minecraft:magenta_stained_glass
fill 287 234 586 287 235 587 minecraft:amethyst_block
fill 296 234 599 296 236 599 minecraft:magenta_stained_glass
fill 298 234 599 298 243 599 minecraft:purple_stained_glass
fill 302 234 557 302 236 557 minecraft:magenta_stained_glass
fill 312 234 599 312 236 599 minecraft:magenta_stained_glass
fill 316 234 560 316 236 560 minecraft:light_blue_stained_glass
fill 317 234 561 319 237 561 minecraft:light_blue_stained_glass
fill 317 234 591 317 235 591 minecraft:light_blue_stained_glass
fill 318 234 557 318 236 557 minecraft:magenta_stained_glass
fill 318 234 562 318 237 562 minecraft:light_blue_stained_glass
fill 318 234 590 318 235 590 minecraft:light_blue_stained_glass
fill 318 234 592 318 235 592 minecraft:light_blue_stained_glass
fill 319 234 557 319 239 557 minecraft:purple_stained_glass
setblock 320 234 557 minecraft:sea_lantern
fill 320 234 560 320 236 560 minecraft:light_blue_stained_glass
setblock 320 234 599 minecraft:white_concrete
fill 321 234 557 321 282 557 minecraft:purple_stained_glass
fill 324 234 567 324 236 567 minecraft:magenta_stained_glass
fill 324 234 568 324 240 571 minecraft:purple_stained_glass
fill 324 234 581 324 253 582 minecraft:purple_stained_glass
fill 324 234 583 324 236 583 minecraft:magenta_stained_glass
setblock 324 234 593 minecraft:white_concrete
fill 282 235 599 283 307 599 minecraft:purple_stained_glass
setblock 284 235 599 minecraft:light_blue_stained_glass
fill 289 235 587 289 236 587 minecraft:light_blue_stained_glass
fill 308 235 570 308 236 570 minecraft:magenta_stained_glass
fill 315 235 591 316 235 591 minecraft:light_blue_stained_glass
fill 317 235 562 317 237 562 minecraft:light_blue_stained_glass
fill 318 235 563 318 237 563 minecraft:light_blue_stained_glass
fill 319 235 562 319 237 562 minecraft:light_blue_stained_glass
fill 320 235 557 320 307 557 minecraft:purple_stained_glass
setblock 320 235 599 minecraft:purple_stained_glass
setblock 321 235 591 minecraft:light_blue_stained_glass
setblock 324 235 591 minecraft:sea_lantern
fill 324 235 593 324 243 593 minecraft:purple_stained_glass
setblock 324 235 597 minecraft:sea_lantern
fill 324 235 598 324 258 598 minecraft:purple_stained_glass
fill 284 236 599 284 240 599 minecraft:purple_stained_glass
fill 304 236 557 305 263 557 minecraft:purple_stained_glass
setblock 306 236 557 minecraft:white_concrete
fill 307 236 557 307 307 557 minecraft:purple_stained_glass
setblock 315 236 591 minecraft:light_blue_stained_glass
setblock 316 236 557 minecraft:light_blue_stained_glass
setblock 316 236 561 minecraft:light_blue_stained_glass
fill 317 236 557 317 270 557 minecraft:purple_stained_glass
fill 317 236 563 317 237 563 minecraft:light_blue_stained_glass
fill 318 236 564 318 237 564 minecraft:light_blue_stained_glass
fill 319 236 563 319 237 563 minecraft:light_blue_stained_glass
setblock 320 236 561 minecraft:light_blue_stained_glass
setblock 320 236 599 minecraft:sea_lantern
setblock 322 236 599 minecraft:sea_lantern
fill 324 236 591 324 301 591 minecraft:purple_stained_glass
fill 324 236 597 324 276 597 minecraft:purple_stained_glass
fill 282 237 565 282 243 565 minecraft:purple_stained_glass
fill 282 237 581 282 251 581 minecraft:purple_stained_glass
fill 282 237 597 282 251 597 minecraft:purple_stained_glass
fill 286 237 557 286 251 557 minecraft:purple_stained_glass
setblock 290 237 557 minecraft:sea_lantern
fill 295 237 579 295 238 579 minecraft:light_blue_stained_glass
fill 296 237 599 296 251 599 minecraft:purple_stained_glass
fill 301 237 599 301 307 599 minecraft:purple_stained_glass
fill 302 237 557 302 251 557 minecraft:purple_stained_glass
setblock 302 237 599 minecraft:white_concrete
fill 303 237 599 305 241 599 minecraft:purple_stained_glass
fill 306 237 557 306 307 557 minecraft:purple_stained_glass
fill 312 237 599 312 251 599 minecraft:purple_stained_glass
setblock 313 237 557 minecraft:sea_lantern
fill 314 237 557 314 307 557 minecraft:purple_stained_glass
fill 314 237 599 317 237 599 minecraft:purple_stained_glass
fill 316 237 557 316 289 557 minecraft:purple_stained_glass
setblock 317 237 564 minecraft:light_blue_stained_glass
fill 318 237 557 318 251 557 minecraft:purple_stained_glass
fill 318 237 565 318 237 566 minecraft:light_blue_stained_glass
setblock 318 237 599 minecraft:sea_lantern
setblock 319 237 564 minecraft:light_blue_stained_glass
fill 320 237 599 320 307 599 minecraft:purple_stained_glass
fill 322 237 599 322 241 599 minecraft:purple_stained_glass
fill 324 237 567 324 251 567 minecraft:purple_stained_glass
fill 324 237 583 324 249 583 minecraft:purple_stained_glass
fill 324 237 594 324 237 595 minecraft:purple_stained_glass
setblock 324 237 596 minecraft:sea_lantern
setblock 282 238 583 minecraft:sea_lantern
fill 282 238 584 282 249 588 minecraft:purple_stained_glass
fill 282 238 591 282 256 593 minecraft:purple_stained_glass
setblock 282 238 594 minecraft:sea_lantern
fill 282 238 595 282 261 595 minecraft:purple_stained_glass
fill 290 238 557 290 267 557 minecraft:purple_stained_glass
fill 302 238 599 302 283 599 minecraft:purple_stained_glass
fill 313 238 557 313 266 557 minecraft:purple_stained_glass
fill 314 238 599 316 252 599 minecraft:purple_stained_glass
setblock 317 238 599 minecraft:light_blue_stained_glass
setblock 318 238 565 minecraft:light_blue_stained_glass
fill 318 238 599 318 272 599 minecraft:purple_stained_glass
fill 324 238 594 324 278 594 minecraft:purple_stained_glass
setblock 324 238 595 minecraft:sea_lantern
fill 324 238 596 324 307 596 minecraft:purple_stained_glass
fill 282 239 559 282 245 561 minecraft:purple_stained_glass
setblock 282 239 562 minecraft:sea_lantern
setblock 282 239 569 minecraft:sea_lantern
fill 282 239 570 282 256 571 minecraft:purple_stained_glass
setblock 282 239 578 minecraft:white_concrete
fill 282 239 583 282 278 583 minecraft:purple_stained_glass
fill 282 239 594 282 264 594 minecraft:purple_stained_glass
fill 299 239 599 299 260 599 minecraft:purple_stained_glass
setblock 300 239 599 minecraft:white_concrete
setblock 312 239 557 minecraft:white_concrete
fill 317 239 599 317 253 599 minecraft:purple_stained_glass
fill 324 239 595 324 278 595 minecraft:purple_stained_glass
fill 282 240 562 282 299 562 minecraft:purple_stained_glass
fill 282 240 569 282 252 569 minecraft:purple_stained_glass
fill 282 240 578 282 307 578 minecraft:purple_stained_glass
setblock 285 240 560 minecraft:light[level=14]
setblock 285 240 568 minecraft:light[level=14]
setblock 285 240 576 minecraft:light[level=14]
setblock 285 240 584 minecraft:light[level=14]
setblock 285 240 592 minecraft:light[level=14]
fill 291 240 557 291 280 557 minecraft:purple_stained_glass
setblock 292 240 557 minecraft:white_concrete
fill 293 240 557 293 276 557 minecraft:purple_stained_glass
setblock 293 240 560 minecraft:light[level=14]
setblock 293 240 568 minecraft:light[level=14]
setblock 293 240 576 minecraft:light[level=14]
setblock 293 240 584 minecraft:light[level=14]
setblock 293 240 592 minecraft:light[level=14]
fill 300 240 599 300 307 599 minecraft:purple_stained_glass
setblock 301 240 560 minecraft:light[level=14]
setblock 301 240 568 minecraft:light[level=14]
setblock 301 240 576 minecraft:light[level=14]
setblock 301 240 584 minecraft:light[level=14]
setblock 301 240 592 minecraft:light[level=14]
setblock 309 240 560 minecraft:light[level=14]
setblock 309 240 568 minecraft:light[level=14]
setblock 309 240 576 minecraft:light[level=14]
setblock 309 240 584 minecraft:light[level=14]
setblock 309 240 592 minecraft:light[level=14]
fill 312 240 557 312 272 557 minecraft:purple_stained_glass
setblock 317 240 560 minecraft:light[level=14]
setblock 317 240 568 minecraft:light[level=14]
setblock 317 240 576 minecraft:light[level=14]
setblock 317 240 584 minecraft:light[level=14]
setblock 317 240 592 minecraft:light[level=14]
setblock 319 240 557 minecraft:white_concrete
fill 282 241 557 282 307 557 minecraft:purple_stained_glass
setblock 282 241 558 minecraft:sea_lantern
setblock 284 241 599 minecraft:white_concrete
fill 292 241 557 292 307 557 minecraft:purple_stained_glass
fill 319 241 557 319 289 557 minecraft:purple_stained_glass
fill 324 241 568 324 254 568 minecraft:purple_stained_glass
setblock 324 241 569 minecraft:sea_lantern
fill 324 241 570 324 293 571 minecraft:purple_stained_glass
fill 282 242 558 282 274 558 minecraft:purple_stained_glass
setblock 282 242 590 minecraft:sea_lantern
fill 284 242 599 284 297 599 minecraft:purple_stained_glass
fill 303 242 599 304 249 599 minecraft:purple_stained_glass
setblock 305 242 599 minecraft:white_concrete
setblock 311 242 599 minecraft:light_blue_stained_glass
setblock 322 242 599 minecraft:white_concrete
setblock 324 242 564 minecraft:sea_lantern
fill 324 242 569 324 286 569 minecraft:purple_stained_glass
setblock 324 242 588 minecraft:sea_lantern
fill 282 243 590 282 307 590 minecraft:purple_stained_glass
fill 302 243 577 304 243 579 minecraft:redstone_block
fill 305 243 599 305 307 599 minecraft:purple_stained_glass
fill 307 243 572 309 243 574 minecraft:redstone_block
fill 307 243 582 309 243 584 minecraft:redstone_block
fill 311 243 599 311 276 599 minecraft:purple_stained_glass
fill 312 243 577 314 243 579 minecraft:redstone_block
fill 322 243 599 322 307 599 minecraft:purple_stained_glass
fill 324 243 564 324 261 564 minecraft:purple_stained_glass
setblock 324 243 572 minecraft:white_concrete
fill 324 243 573 324 263 574 minecraft:purple_stained_glass
setblock 324 243 575 minecraft:light_blue_stained_glass
fill 324 243 576 324 243 579 minecraft:purple_stained_glass
fill 324 243 588 324 307 588 minecraft:purple_stained_glass
setblock 282 244 565 minecraft:light_blue_stained_glass
setblock 284 244 557 minecraft:sea_lantern
fill 292 244 578 295 245 578 minecraft:magenta_stained_glass
fill 293 244 573 293 245 576 minecraft:light_blue_stained_glass
fill 293 244 577 296 245 577 minecraft:magenta_stained_glass
fill 293 244 579 293 245 583 minecraft:magenta_stained_glass
fill 294 244 571 294 245 575 minecraft:light_blue_stained_glass
fill 294 244 576 298 245 576 minecraft:magenta_stained_glass
fill 294 244 579 294 245 580 minecraft:magenta_stained_glass
fill 294 244 581 298 245 585 minecraft:light_blue_stained_glass
fill 295 244 569 295 245 574 minecraft:light_blue_stained_glass
fill 295 244 575 300 245 575 minecraft:magenta_stained_glass
fill 295 244 579 295 245 579 minecraft:magenta_stained_glass
fill 295 244 580 300 245 580 minecraft:light_blue_stained_glass
fill 295 244 586 298 245 587 minecraft:light_blue_stained_glass
fill 296 244 568 297 245 573 minecraft:light_blue_stained_glass
fill 296 244 574 305 245 574 minecraft:magenta_stained_glass
fill 296 244 578 301 244 579 minecraft:light_blue_stained_glass
fill 296 244 588 298 245 588 minecraft:light_blue_stained_glass
fill 297 244 567 307 245 567 minecraft:magenta_stained_glass
fill 297 244 577 301 244 577 minecraft:light_blue_stained_glass
fill 297 244 589 298 245 589 minecraft:light_blue_stained_glass
fill 298 244 566 306 245 566 minecraft:magenta_stained_glass
fill 298 244 568 303 245 572 minecraft:light_blue_stained_glass
fill 298 244 573 304 245 573 minecraft:magenta_stained_glass
fill 298 244 590 298 245 590 minecraft:light_blue_stained_glass
setblock 298 244 599 minecraft:white_concrete
fill 299 244 565 304 245 565 minecraft:magenta_stained_glass
fill 299 244 576 306 244 576 minecraft:light_blue_stained_glass
fill 299 244 581 299 245 582 minecraft:light_blue_stained_glass
fill 299 244 583 301 245 590 minecraft:magenta_stained_glass
fill 299 244 591 299 245 591 minecraft:light_blue_stained_glass
fill 300 244 581 302 245 582 minecraft:magenta_stained_glass
fill 300 244 591 303 245 591 minecraft:magenta_stained_glass
fill 301 244 564 301 245 564 minecraft:magenta_stained_glass
fill 301 244 575 304 245 575 minecraft:light_blue_stained_glass
fill 301 244 580 303 244 580 minecraft:magenta_stained_glass
fill 301 244 592 303 245 592 minecraft:magenta_stained_glass
fill 302 244 564 312 245 564 minecraft:light_blue_stained_glass
fill 302 244 583 305 245 588 minecraft:light_blue_stained_glass
fill 302 244 589 302 245 590 minecraft:magenta_stained_glass
fill 303 244 563 311 245 563 minecraft:light_blue_stained_glass
fill 303 244 581 305 245 582 minecraft:light_blue_stained_glass
fill 303 244 589 308 245 590 minecraft:light_blue_stained_glass
fill 303 244 593 304 245 593 minecraft:magenta_stained_glass
fill 304 244 568 308 245 568 minecraft:magenta_stained_glass
fill 304 244 569 305 245 572 minecraft:light_blue_stained_glass
fill 304 244 580 306 244 580 minecraft:light_blue_stained_glass
fill 304 244 591 311 245 592 minecraft:light_blue_stained_glass
fill 305 244 565 312 245 565 minecraft:light_blue_stained_glass
fill 305 244 573 306 244 573 minecraft:light_blue_stained_glass
fill 305 244 575 306 244 575 minecraft:magenta_stained_glass
fill 305 244 577 306 244 577 minecraft:light_blue_stained_glass
fill 305 244 578 306 244 578 minecraft:magenta_stained_glass
fill 305 244 579 306 244 579 minecraft:light_blue_stained_glass
fill 305 244 593 313 245 593 minecraft:light_blue_stained_glass
fill 306 244 569 309 245 569 minecraft:magenta_stained_glass
fill 306 244 570 306 244 572 minecraft:light_blue_stained_glass
setblock 306 244 574 minecraft:light_blue_stained_glass
fill 306 244 581 306 244 585 minecraft:magenta_stained_glass
fill 306 244 586 306 245 588 minecraft:light_blue_stained_glass
fill 307 244 566 313 245 566 minecraft:light_blue_stained_glass
fill 307 244 570 309 245 570 minecraft:magenta_stained_glass
setblock 307 244 571 minecraft:light_blue_stained_glass
fill 307 244 575 308 244 575 minecraft:light_blue_stained_glass
setblock 307 244 576 minecraft:magenta_stained_glass
fill 307 244 580 307 244 581 minecraft:magenta_stained_glass
fill 307 244 585 308 244 587 minecraft:magenta_stained_glass
fill 307 244 588 307 245 588 minecraft:light_blue_stained_glass
fill 308 244 562 308 245 562 minecraft:light_blue_stained_glass
fill 308 244 567 313 245 567 minecraft:light_blue_stained_glass
fill 308 244 571 310 244 571 minecraft:magenta_stained_glass
setblock 308 244 576 minecraft:light_blue_stained_glass
fill 308 244 580 308 244 581 minecraft:light_blue_stained_glass
fill 308 244 588 312 245 588 minecraft:magenta_stained_glass
fill 308 244 594 308 245 594 minecraft:light_blue_stained_glass
fill 309 244 568 314 245 568 minecraft:light_blue_stained_glass
fill 309 244 575 309 244 576 minecraft:magenta_stained_glass
setblock 309 244 580 minecraft:magenta_stained_glass
setblock 309 244 581 minecraft:light_blue_stained_glass
fill 309 244 585 322 244 585 minecraft:light_blue_stained_glass
fill 309 244 586 309 245 587 minecraft:magenta_stained_glass
fill 309 244 589 319 245 589 minecraft:magenta_stained_glass
fill 309 244 590 309 245 590 minecraft:light_blue_stained_glass
fill 310 244 569 314 245 570 minecraft:light_blue_stained_glass
fill 310 244 572 310 244 575 minecraft:magenta_stained_glass
fill 310 244 576 311 244 577 minecraft:light_blue_stained_glass
fill 310 244 578 311 244 578 minecraft:magenta_stained_glass
fill 310 244 579 311 244 580 minecraft:light_blue_stained_glass
fill 310 244 581 311 244 581 minecraft:magenta_stained_glass
fill 310 244 582 310 244 584 minecraft:light_blue_stained_glass
fill 310 244 586 321 245 586 minecraft:light_blue_stained_glass
fill 310 244 587 310 245 587 minecraft:magenta_stained_glass
fill 310 244 590 318 245 590 minecraft:magenta_stained_glass
fill 311 244 571 313 245 575 minecraft:light_blue_stained_glass
fill 311 244 582 320 245 582 minecraft:magenta_stained_glass
fill 311 244 583 311 245 584 minecraft:light_blue_stained_glass
fill 311 244 587 321 245 587 minecraft:light_blue_stained_glass
fill 312 244 563 313 245 563 minecraft:magenta_stained_glass
setblock 312 244 576 minecraft:light_blue_stained_glass
fill 312 244 580 315 244 581 minecraft:light_blue_stained_glass
fill 312 244 583 318 245 583 minecraft:magenta_stained_glass
fill 312 244 584 322 245 584 minecraft:light_blue_stained_glass
fill 312 244 591 317 245 591 minecraft:magenta_stained_glass
fill 312 244 592 314 245 592 minecraft:light_blue_stained_glass
fill 313 244 564 315 245 565 minecraft:magenta_stained_glass
fill 313 244 576 315 244 576 minecraft:magenta_stained_glass
fill 313 244 588 320 245 588 minecraft:light_blue_stained_glass
fill 314 244 566 317 245 567 minecraft:magenta_stained_glass
fill 314 244 571 314 245 573 minecraft:light_blue_stained_glass
fill 314 244 574 316 245 575 minecraft:magenta_stained_glass
fill 315 244 568 317 245 573 minecraft:magenta_stained_glass
fill 315 244 577 319 244 579 minecraft:light_blue_stained_glass
fill 315 244 592 315 245 592 minecraft:magenta_stained_glass
fill 316 244 565 316 245 565 minecraft:magenta_stained_glass
fill 316 244 576 321 245 576 minecraft:light_blue_stained_glass
fill 316 244 580 317 245 580 minecraft:light_blue_stained_glass
fill 316 244 581 321 245 581 minecraft:magenta_stained_glass
fill 317 244 565 317 245 565 minecraft:light_blue_stained_glass
fill 317 244 574 322 245 575 minecraft:light_blue_stained_glass
fill 318 244 566 318 245 573 minecraft:light_blue_stained_glass
fill 318 244 580 322 245 580 minecraft:magenta_stained_glass
fill 319 244 567 319 245 573 minecraft:light_blue_stained_glass
fill 319 244 583 323 245 583 minecraft:light_blue_stained_glass
fill 320 244 568 320 245 573 minecraft:light_blue_stained_glass
fill 320 244 577 320 245 578 minecraft:light_blue_stained_glass
fill 320 244 579 323 245 579 minecraft:magenta_stained_glass
fill 321 244 569 321 245 573 minecraft:light_blue_stained_glass
fill 321 244 577 323 245 578 minecraft:magenta_stained_glass
fill 321 244 582 323 245 582 minecraft:light_blue_stained_glass
fill 322 244 571 322 245 573 minecraft:light_blue_stained_glass
fill 322 244 576 323 245 576 minecraft:magenta_stained_glass
fill 322 244 581 323 245 581 minecraft:light_blue_stained_glass
fill 323 244 573 323 245 575 minecraft:magenta_stained_glass
fill 323 244 580 323 245 580 minecraft:light_blue_stained_glass
fill 324 244 572 324 307 572 minecraft:purple_stained_glass
fill 324 244 575 324 270 577 minecraft:purple_stained_glass
fill 324 244 578 324 245 578 minecraft:magenta_stained_glass
fill 324 244 579 324 307 579 minecraft:purple_stained_glass
setblock 324 244 593 minecraft:light_blue_stained_glass
fill 282 245 565 298 245 565 minecraft:purple_stained_glass
fill 283 245 558 300 245 564 minecraft:purple_stained_glass
fill 283 245 566 291 245 598 minecraft:purple_stained_glass
fill 284 245 557 284 288 557 minecraft:purple_stained_glass
fill 292 245 566 292 245 577 minecraft:purple_stained_glass
fill 292 245 579 292 245 598 minecraft:purple_stained_glass
fill 293 245 566 293 245 572 minecraft:purple_stained_glass
fill 293 245 584 293 245 598 minecraft:purple_stained_glass
fill 294 245 566 294 245 570 minecraft:purple_stained_glass
fill 294 245 586 294 245 598 minecraft:purple_stained_glass
fill 295 245 566 295 245 568 minecraft:purple_stained_glass
fill 295 245 588 295 245 598 minecraft:purple_stained_glass
fill 296 245 566 296 245 567 minecraft:purple_stained_glass
fill 296 245 578 300 245 579 minecraft:light_blue_stained_glass
fill 296 245 589 296 245 598 minecraft:purple_stained_glass
setblock 297 245 566 minecraft:purple_stained_glass
fill 297 245 577 300 245 577 minecraft:light_blue_stained_glass
fill 297 245 590 297 245 598 minecraft:purple_stained_glass
fill 298 245 591 298 245 599 minecraft:purple_stained_glass
fill 299 245 576 300 245 576 minecraft:light_blue_stained_glass
fill 299 245 592 300 245 598 minecraft:purple_stained_glass
fill 301 245 558 302 245 563 minecraft:purple_stained_glass
fill 301 245 576 301 245 580 minecraft:sea_lantern
fill 301 245 593 302 245 598 minecraft:purple_stained_glass
fill 302 245 576 315 245 576 minecraft:sea_lantern
fill 302 245 577 304 245 579 minecraft:purple_stained_glass
fill 302 245 580 315 245 580 minecraft:sea_lantern
fill 303 245 558 307 245 562 minecraft:purple_stained_glass
fill 303 245 594 307 245 598 minecraft:purple_stained_glass
setblock 305 245 573 minecraft:light_blue_stained_glass
setblock 305 245 575 minecraft:magenta_stained_glass
fill 305 245 577 306 245 579 minecraft:sea_lantern
setblock 306 245 570 minecraft:light_blue_stained_glass
fill 306 245 571 306 245 575 minecraft:sea_lantern
fill 306 245 581 306 245 585 minecraft:sea_lantern
fill 307 245 571 310 245 571 minecraft:sea_lantern
fill 307 245 572 309 245 574 minecraft:purple_stained_glass
fill 307 245 575 310 245 575 minecraft:sea_lantern
fill 307 245 581 310 245 581 minecraft:sea_lantern
fill 307 245 582 309 245 584 minecraft:purple_stained_glass
fill 307 245 585 310 245 585 minecraft:sea_lantern
fill 307 245 586 308 245 587 minecraft:magenta_stained_glass
fill 308 245 558 323 245 561 minecraft:purple_stained_glass
fill 308 245 595 323 245 598 minecraft:purple_stained_glass
fill 309 245 562 323 245 562 minecraft:purple_stained_glass
fill 309 245 594 323 245 594 minecraft:purple_stained_glass
fill 310 245 572 310 245 574 minecraft:sea_lantern
fill 310 245 577 311 245 579 minecraft:sea_lantern
fill 310 245 582 310 245 584 minecraft:sea_lantern
setblock 311 245 581 minecraft:magenta_stained_glass
fill 311 245 585 322 245 585 minecraft:light_blue_stained_glass
fill 312 245 577 314 245 579 minecraft:purple_stained_glass
fill 312 245 581 315 245 581 minecraft:light_blue_stained_glass
fill 314 245 563 323 245 563 minecraft:purple_stained_glass
fill 314 245 593 324 245 593 minecraft:purple_stained_glass
fill 315 245 577 315 245 579 minecraft:sea_lantern
fill 316 245 564 323 245 564 minecraft:purple_stained_glass
fill 316 245 577 319 245 579 minecraft:light_blue_stained_glass
fill 316 245 592 323 245 592 minecraft:purple_stained_glass
fill 318 245 565 323 245 565 minecraft:purple_stained_glass
fill 318 245 591 323 245 591 minecraft:purple_stained_glass
fill 319 245 566 323 245 566 minecraft:purple_stained_glass
fill 319 245 590 323 245 590 minecraft:purple_stained_glass
fill 320 245 567 323 245 567 minecraft:purple_stained_glass
fill 320 245 589 323 245 589 minecraft:purple_stained_glass
fill 321 245 568 323 245 568 minecraft:purple_stained_glass
fill 321 245 588 323 245 588 minecraft:purple_stained_glass
fill 322 245 569 323 245 570 minecraft:purple_stained_glass
fill 322 245 586 323 245 587 minecraft:purple_stained_glass
fill 323 245 571 323 245 572 minecraft:purple_stained_glass
fill 323 245 584 323 245 585 minecraft:purple_stained_glass
fill 282 246 559 282 274 559 minecraft:purple_stained_glass
setblock 282 246 560 minecraft:white_concrete
fill 282 246 561 282 307 561 minecraft:purple_stained_glass
fill 282 246 565 282 247 565 minecraft:purple_stained_glass
fill 298 246 599 298 270 599 minecraft:purple_stained_glass
fill 324 246 578 324 295 578 minecraft:purple_stained_glass
fill 324 246 593 324 261 593 minecraft:purple_stained_glass
fill 282 247 560 282 282 560 minecraft:purple_stained_glass
setblock 282 248 565 minecraft:sea_lantern
setblock 285 248 560 minecraft:light[level=14]
setblock 285 248 568 minecraft:light[level=14]
setblock 285 248 576 minecraft:light[level=14]
setblock 285 248 584 minecraft:light[level=14]
setblock 285 248 592 minecraft:light[level=14]
setblock 293 248 560 minecraft:light[level=14]
setblock 293 248 568 minecraft:light[level=14]
setblock 293 248 576 minecraft:light[level=14]
setblock 293 248 584 minecraft:light[level=14]
setblock 293 248 592 minecraft:light[level=14]
setblock 301 248 560 minecraft:light[level=14]
setblock 301 248 568 minecraft:light[level=14]
setblock 301 248 576 minecraft:light[level=14]
setblock 301 248 584 minecraft:light[level=14]
setblock 301 248 592 minecraft:light[level=14]
setblock 309 248 560 minecraft:light[level=14]
setblock 309 248 568 minecraft:light[level=14]
setblock 309 248 576 minecraft:light[level=14]
setblock 309 248 584 minecraft:light[level=14]
setblock 309 248 592 minecraft:light[level=14]
setblock 317 248 560 minecraft:light[level=14]
setblock 317 248 568 minecraft:light[level=14]
setblock 317 248 576 minecraft:light[level=14]
setblock 317 248 584 minecraft:light[level=14]
setblock 317 248 592 minecraft:light[level=14]
fill 282 249 565 282 251 565 minecraft:purple_stained_glass
setblock 285 249 557 minecraft:light_blue_stained_glass
fill 297 249 575 297 252 581 minecraft:iron_block
fill 298 249 573 298 252 574 minecraft:iron_block
fill 298 249 582 298 252 583 minecraft:iron_block
setblock 299 249 557 minecraft:sea_lantern
fill 299 249 571 299 252 572 minecraft:iron_block
fill 299 249 584 299 252 585 minecraft:iron_block
fill 300 249 570 300 249 571 minecraft:iron_block
fill 300 249 585 300 249 586 minecraft:iron_block
fill 301 249 569 301 252 570 minecraft:iron_block
fill 301 249 586 301 252 587 minecraft:iron_block
fill 302 249 569 302 252 569 minecraft:iron_block
fill 302 249 587 302 252 587 minecraft:iron_block
fill 303 249 568 304 252 568 minecraft:iron_block
fill 303 249 588 304 252 588 minecraft:iron_block
fill 305 249 567 311 252 567 minecraft:iron_block
fill 305 249 589 311 252 589 minecraft:iron_block
fill 312 249 568 313 252 568 minecraft:iron_block
fill 312 249 588 313 252 588 minecraft:iron_block
fill 314 249 569 315 252 569 minecraft:iron_block
fill 314 249 587 315 252 587 minecraft:iron_block
fill 315 249 570 316 249 570 minecraft:iron_block
fill 315 249 586 316 249 586 minecraft:iron_block
fill 316 249 571 317 252 571 minecraft:iron_block
fill 316 249 585 317 252 585 minecraft:iron_block
fill 317 249 572 317 252 572 minecraft:iron_block
fill 317 249 584 317 252 584 minecraft:iron_block
fill 318 249 573 318 252 574 minecraft:iron_block
fill 318 249 582 318 252 583 minecraft:iron_block
fill 319 249 575 319 252 581 minecraft:iron_block
fill 282 250 584 282 301 585 minecraft:purple_stained_glass
setblock 282 250 586 minecraft:white_concrete
fill 282 250 587 282 263 588 minecraft:purple_stained_glass
fill 285 250 557 285 251 557 minecraft:purple_stained_glass
fill 296 250 575 296 250 581 minecraft:iron_block
fill 297 250 573 297 251 574 minecraft:iron_block
fill 297 250 582 297 251 583 minecraft:iron_block
fill 298 250 571 298 251 572 minecraft:iron_block
fill 298 250 575 298 251 581 minecraft:iron_block
fill 298 250 584 298 251 585 minecraft:iron_block
fill 299 250 557 299 301 557 minecraft:purple_stained_glass
fill 299 250 570 299 251 570 minecraft:iron_block
fill 299 250 573 299 251 575 minecraft:iron_block
fill 299 250 581 299 251 583 minecraft:iron_block
fill 299 250 586 299 251 586 minecraft:iron_block
setblock 300 250 557 minecraft:sea_lantern
fill 300 250 569 300 251 569 minecraft:iron_block
fill 300 250 570 300 251 570 minecraft:light_gray_concrete
fill 300 250 571 300 251 572 minecraft:iron_block
fill 300 250 584 300 251 585 minecraft:iron_block
fill 300 250 586 300 251 586 minecraft:light_gray_concrete
fill 300 250 587 300 251 587 minecraft:iron_block
fill 301 250 557 301 293 557 minecraft:purple_stained_glass
fill 301 250 568 302 251 568 minecraft:iron_block
fill 301 250 571 301 251 571 minecraft:light_gray_concrete
fill 301 250 585 301 251 585 minecraft:light_gray_concrete
fill 301 250 588 302 251 588 minecraft:iron_block
fill 302 250 570 302 251 570 minecraft:iron_block
fill 302 250 572 302 251 572 minecraft:light_gray_concrete
fill 302 250 584 302 251 584 minecraft:light_gray_concrete
fill 302 250 586 302 251 586 minecraft:iron_block
fill 303 250 567 304 251 567 minecraft:iron_block
fill 303 250 569 305 251 569 minecraft:iron_block
fill 303 250 573 303 251 573 minecraft:light_gray_concrete
fill 303 250 583 303 251 583 minecraft:light_gray_concrete
fill 303 250 587 305 251 587 minecraft:iron_block
fill 303 250 589 304 251 589 minecraft:iron_block
setblock 303 250 599 minecraft:light_blue_stained_glass
fill 304 250 574 304 251 574 minecraft:light_gray_concrete
fill 304 250 577 305 251 579 minecraft:white_concrete
fill 304 250 582 304 251 582 minecraft:light_gray_concrete
fill 304 250 599 304 253 599 minecraft:purple_stained_glass
fill 305 250 566 311 251 566 minecraft:iron_block
fill 305 250 568 311 251 568 minecraft:iron_block
fill 305 250 575 305 251 575 minecraft:light_gray_concrete
fill 305 250 576 305 251 576 minecraft:white_concrete
fill 305 250 580 305 251 580 minecraft:white_concrete
fill 305 250 581 305 251 581 minecraft:light_gray_concrete
fill 305 250 588 311 251 588 minecraft:iron_block
fill 305 250 590 311 251 590 minecraft:iron_block
fill 306 250 575 310 251 575 minecraft:white_concrete
fill 306 250 581 310 251 581 minecraft:white_concrete
fill 307 250 574 309 251 574 minecraft:white_concrete
fill 307 250 582 309 251 582 minecraft:white_concrete
setblock 310 250 557 minecraft:white_concrete
fill 311 250 569 313 251 569 minecraft:iron_block
fill 311 250 575 311 251 575 minecraft:light_gray_concrete
fill 311 250 576 311 251 580 minecraft:white_concrete
fill 311 250 581 311 251 581 minecraft:light_gray_concrete
fill 311 250 587 313 251 587 minecraft:iron_block
fill 312 250 567 313 251 567 minecraft:iron_block
fill 312 250 574 312 251 574 minecraft:light_gray_concrete
fill 312 250 577 312 251 579 minecraft:white_concrete
fill 312 250 582 312 251 582 minecraft:light_gray_concrete
fill 312 250 589 313 251 589 minecraft:iron_block
fill 313 250 573 313 251 573 minecraft:light_gray_concrete
fill 313 250 583 313 251 583 minecraft:light_gray_concrete
fill 314 250 568 315 251 568 minecraft:iron_block
fill 314 250 570 315 251 570 minecraft:iron_block
fill 314 250 572 314 251 572 minecraft:light_gray_concrete
fill 314 250 584 314 251 584 minecraft:light_gray_concrete
fill 314 250 586 315 251 586 minecraft:iron_block
fill 314 250 588 315 251 588 minecraft:iron_block
setblock 315 250 557 minecraft:light_blue_stained_glass
fill 315 250 571 315 251 571 minecraft:light_gray_concrete
fill 315 250 585 315 251 585 minecraft:light_gray_concrete
fill 316 250 569 316 251 569 minecraft:iron_block
fill 316 250 570 316 251 570 minecraft:light_gray_concrete
fill 316 250 572 316 251 572 minecraft:iron_block
fill 316 250 584 316 251 584 minecraft:iron_block
fill 316 250 586 316 251 586 minecraft:light_gray_concrete
fill 316 250 587 316 251 587 minecraft:iron_block
fill 317 250 570 317 251 570 minecraft:iron_block
fill 317 250 573 317 251 575 minecraft:iron_block
fill 317 250 581 317 251 583 minecraft:iron_block
fill 317 250 586 317 251 586 minecraft:iron_block
fill 318 250 571 318 251 572 minecraft:iron_block
fill 318 250 575 318 251 581 minecraft:iron_block
fill 318 250 584 318 251 585 minecraft:iron_block
fill 319 250 573 319 251 574 minecraft:iron_block
fill 319 250 582 319 251 583 minecraft:iron_block
fill 320 250 575 320 250 581 minecraft:iron_block
setblock 324 250 583 minecraft:light_blue_stained_glass
fill 282 251 586 282 307 586 minecraft:purple_stained_glass
fill 288 251 558 288 256 558 minecraft:light_blue_stained_glass
fill 292 251 575 296 251 581 minecraft:blue_stained_glass
fill 295 251 592 295 252 593 minecraft:magenta_stained_glass
fill 300 251 557 300 258 557 minecraft:purple_stained_glass
fill 303 251 599 303 307 599 minecraft:purple_stained_glass
fill 310 251 557 310 263 557 minecraft:purple_stained_glass
fill 315 251 557 315 307 557 minecraft:purple_stained_glass
fill 320 251 575 323 251 581 minecraft:blue_stained_glass
setblock 323 251 599 minecraft:sea_lantern
setblock 324 251 583 minecraft:purple_stained_glass
fill 324 251 599 324 307 599 minecraft:purple_stained_glass
fill 282 252 565 282 254 565 minecraft:magenta_stained_glass
fill 282 252 581 282 254 581 minecraft:magenta_stained_glass
fill 282 252 597 282 254 597 minecraft:magenta_stained_glass
fill 283 252 575 283 255 575 minecraft:light_blue_stained_glass
setblock 285 252 557 minecraft:white_concrete
fill 286 252 557 286 254 557 minecraft:magenta_stained_glass
fill 286 252 558 287 255 558 minecraft:light_blue_stained_glass
fill 287 252 559 289 254 562 minecraft:light_blue_stained_glass
fill 288 252 563 288 254 563 minecraft:light_blue_stained_glass
fill 289 252 558 290 255 558 minecraft:light_blue_stained_glass
fill 296 252 599 296 254 599 minecraft:magenta_stained_glass
fill 300 252 570 300 252 571 minecraft:iron_block
fill 300 252 585 300 252 586 minecraft:iron_block
fill 302 252 557 302 254 557 minecraft:magenta_stained_glass
fill 312 252 599 312 254 599 minecraft:magenta_stained_glass
fill 315 252 570 316 252 570 minecraft:iron_block
fill 315 252 586 316 252 586 minecraft:iron_block
fill 318 252 557 318 254 557 minecraft:magenta_stained_glass
fill 323 252 599 323 279 599 minecraft:purple_stained_glass
fill 324 252 567 324 254 567 minecraft:magenta_stained_glass
fill 324 252 583 324 254 583 minecraft:magenta_stained_glass
setblock 282 253 569 minecraft:light_blue_stained_glass
fill 283 253 574 285 254 574 minecraft:light_blue_stained_glass
fill 283 253 576 285 254 576 minecraft:light_blue_stained_glass
fill 284 253 575 287 254 575 minecraft:light_blue_stained_glass
fill 285 253 557 285 255 557 minecraft:purple_stained_glass
fill 286 253 559 286 254 560 minecraft:light_blue_stained_glass
setblock 287 253 563 minecraft:light_blue_stained_glass
fill 288 253 564 288 253 565 minecraft:light_blue_stained_glass
setblock 289 253 563 minecraft:light_blue_stained_glass
fill 290 253 559 290 254 560 minecraft:light_blue_stained_glass
fill 314 253 599 315 269 599 minecraft:purple_stained_glass
setblock 316 253 599 minecraft:light_blue_stained_glass
fill 282 254 569 282 265 569 minecraft:purple_stained_glass
setblock 304 254 599 minecraft:light_blue_stained_glass
fill 316 254 599 316 267 599 minecraft:purple_stained_glass
setblock 317 254 599 minecraft:white_concrete
fill 324 254 581 324 274 581 minecraft:purple_stained_glass
setblock 324 254 582 minecraft:white_concrete
fill 282 255 565 282 260 565 minecraft:purple_stained_glass
setblock 282 255 575 minecraft:light_blue_stained_glass
fill 282 255 581 282 260 581 minecraft:purple_stained_glass
fill 282 255 597 282 260 597 minecraft:purple_stained_glass
fill 286 255 557 286 257 557 minecraft:purple_stained_glass
fill 287 255 559 289 255 560 minecraft:light_blue_stained_glass
setblock 288 255 561 minecraft:light_blue_stained_glass
fill 296 255 599 296 260 599 minecraft:purple_stained_glass
fill 302 255 557 302 260 557 minecraft:purple_stained_glass
fill 304 255 599 304 297 599 minecraft:purple_stained_glass
fill 312 255 599 312 260 599 minecraft:purple_stained_glass
fill 317 255 599 317 307 599 minecraft:purple_stained_glass
fill 318 255 557 318 260 557 minecraft:purple_stained_glass
fill 324 255 565 324 256 565 minecraft:white_concrete
fill 324 255 567 324 260 567 minecraft:purple_stained_glass
setblock 324 255 568 minecraft:white_concrete
fill 324 255 582 324 260 583 minecraft:purple_stained_glass
fill 282 256 575 282 261 575 minecraft:purple_stained_glass
setblock 285 256 557 minecraft:white_concrete
setblock 285 256 560 minecraft:light[level=14]
setblock 285 256 568 minecraft:light[level=14]
setblock 285 256 576 minecraft:light[level=14]
setblock 285 256 584 minecraft:light[level=14]
setblock 285 256 592 minecraft:light[level=14]
setblock 293 256 560 minecraft:light[level=14]
setblock 293 256 568 minecraft:light[level=14]
setblock 293 256 576 minecraft:light[level=14]
setblock 293 256 584 minecraft:light[level=14]
setblock 293 256 592 minecraft:light[level=14]
setblock 294 256 599 minecraft:light_blue_stained_glass
setblock 301 256 560 minecraft:light[level=14]
setblock 301 256 568 minecraft:light[level=14]
setblock 301 256 576 minecraft:light[level=14]
setblock 301 256 584 minecraft:light[level=14]
setblock 301 256 592 minecraft:light[level=14]
setblock 309 256 560 minecraft:light[level=14]
setblock 309 256 568 minecraft:light[level=14]
setblock 309 256 576 minecraft:light[level=14]
setblock 309 256 584 minecraft:light[level=14]
setblock 309 256 592 minecraft:light[level=14]
setblock 317 256 560 minecraft:light[level=14]
setblock 317 256 568 minecraft:light[level=14]
setblock 317 256 576 minecraft:light[level=14]
setblock 317 256 584 minecraft:light[level=14]
setblock 317 256 592 minecraft:light[level=14]
fill 324 256 568 324 307 568 minecraft:purple_stained_glass
fill 282 257 570 282 279 570 minecraft:purple_stained_glass
setblock 282 257 571 minecraft:white_concrete
setblock 282 257 591 minecraft:light_blue_stained_glass
fill 282 257 592 282 296 593 minecraft:purple_stained_glass
fill 285 257 557 285 258 557 minecraft:purple_stained_glass
fill 294 257 599 294 307 599 minecraft:purple_stained_glass
fill 295 257 557 296 264 557 minecraft:purple_stained_glass
setblock 297 257 557 minecraft:light_blue_stained_glass
setblock 298 257 557 minecraft:white_concrete
fill 324 257 565 324 271 565 minecraft:purple_stained_glass
fill 282 258 563 282 275 563 minecraft:purple_stained_glass
setblock 282 258 564 minecraft:white_concrete
fill 282 258 571 282 294 571 minecraft:purple_stained_glass
fill 282 258 591 282 260 591 minecraft:purple_stained_glass
setblock 286 258 557 minecraft:light_blue_stained_glass
fill 297 258 557 298 307 557 minecraft:purple_stained_glass
fill 282 259 564 282 307 564 minecraft:purple_stained_glass
setblock 285 259 557 minecraft:white_concrete
fill 286 259 557 286 260 557 minecraft:purple_stained_glass
setblock 300 259 557 minecraft:white_concrete
setblock 324 259 598 minecraft:sea_lantern
fill 283 260 560 283 265 560 minecraft:light_blue_stained_glass
fill 285 260 557 285 292 557 minecraft:purple_stained_glass
fill 300 260 557 300 294 557 minecraft:purple_stained_glass
fill 324 260 598 324 286 598 minecraft:purple_stained_glass
fill 282 261 565 282 263 565 minecraft:magenta_stained_glass
fill 282 261 581 282 263 581 minecraft:magenta_stained_glass
setblock 282 261 591 minecraft:sea_lantern
fill 282 261 597 282 263 597 minecraft:magenta_stained_glass
fill 283 261 558 283 264 559 minecraft:light_blue_stained_glass
fill 283 261 561 283 264 562 minecraft:light_blue_stained_glass
fill 284 261 559 289 261 561 minecraft:light_blue_stained_glass
fill 286 261 557 286 263 557 minecraft:magenta_stained_glass
setblock 288 261 557 minecraft:white_concrete
fill 290 261 560 291 261 560 minecraft:light_blue_stained_glass
fill 296 261 599 296 263 599 minecraft:magenta_stained_glass
setblock 299 261 599 minecraft:white_concrete
fill 302 261 557 302 263 557 minecraft:magenta_stained_glass
fill 312 261 599 312 263 599 minecraft:magenta_stained_glass
fill 318 261 557 318 263 557 minecraft:magenta_stained_glass
fill 324 261 567 324 263 567 minecraft:magenta_stained_glass
fill 324 261 582 324 268 582 minecraft:purple_stained_glass
fill 324 261 583 324 263 583 minecraft:magenta_stained_glass
setblock 282 262 575 minecraft:light_blue_stained_glass
fill 282 262 576 282 307 576 minecraft:purple_stained_glass
setblock 282 262 577 minecraft:sea_lantern
fill 282 262 591 282 307 591 minecraft:purple_stained_glass
setblock 282 262 595 minecraft:white_concrete
fill 284 262 558 285 262 562 minecraft:light_blue_stained_glass
fill 286 262 559 288 262 561 minecraft:light_blue_stained_glass
fill 288 262 557 288 307 557 minecraft:purple_stained_glass
setblock 289 262 560 minecraft:light_blue_stained_glass
fill 299 262 599 299 270 599 minecraft:purple_stained_glass
fill 321 262 586 323 265 588 minecraft:light_blue_stained_glass
setblock 324 262 564 minecraft:light_blue_stained_glass
setblock 324 262 593 minecraft:sea_lantern
fill 282 263 575 282 307 575 minecraft:purple_stained_glass
fill 282 263 577 282 307 577 minecraft:purple_stained_glass
fill 282 263 595 282 307 595 minecraft:purple_stained_glass
fill 284 263 558 284 263 562 minecraft:light_blue_stained_glass
fill 285 263 559 286 263 561 minecraft:light_blue_stained_glass
setblock 287 263 560 minecraft:light_blue_stained_glass
fill 319 263 587 320 264 587 minecraft:light_blue_stained_glass
fill 320 263 586 320 264 586 minecraft:light_blue_stained_glass
fill 320 263 588 320 264 588 minecraft:light_blue_stained_glass
fill 321 263 590 322 265 590 minecraft:light_blue_stained_glass
fill 322 263 585 322 264 585 minecraft:light_blue_stained_glass
fill 322 263 589 322 265 589 minecraft:light_blue_stained_glass
fill 324 263 564 324 276 564 minecraft:purple_stained_glass
fill 324 263 593 324 282 593 minecraft:purple_stained_glass
fill 282 264 565 282 269 565 minecraft:purple_stained_glass
fill 282 264 581 282 269 581 minecraft:purple_stained_glass
fill 282 264 587 282 269 587 minecraft:purple_stained_glass
setblock 282 264 588 minecraft:sea_lantern
fill 282 264 597 282 266 597 minecraft:purple_stained_glass
fill 284 264 559 285 264 561 minecraft:light_blue_stained_glass
setblock 285 264 568 minecraft:light[level=14]
setblock 285 264 576 minecraft:light[level=14]
setblock 285 264 584 minecraft:light[level=14]
setblock 285 264 592 minecraft:light[level=14]
fill 286 264 557 286 269 557 minecraft:purple_stained_glass
setblock 293 264 560 minecraft:light[level=14]
setblock 293 264 568 minecraft:light[level=14]
setblock 293 264 576 minecraft:light[level=14]
setblock 293 264 584 minecraft:light[level=14]
setblock 293 264 592 minecraft:light[level=14]
fill 296 264 599 296 269 599 minecraft:purple_stained_glass
setblock 301 264 560 minecraft:light[level=14]
setblock 301 264 568 minecraft:light[level=14]
setblock 301 264 576 minecraft:light[level=14]
setblock 301 264 584 minecraft:light[level=14]
setblock 301 264 592 minecraft:light[level=14]
fill 302 264 557 302 269 557 minecraft:purple_stained_glass
setblock 304 264 557 minecraft:white_concrete
fill 305 264 557 305 282 557 minecraft:purple_stained_glass
setblock 309 264 560 minecraft:light[level=14]
setblock 309 264 568 minecraft:light[level=14]
setblock 309 264 576 minecraft:light[level=14]
setblock 309 264 584 minecraft:light[level=14]
setblock 309 264 592 minecraft:light[level=14]
setblock 310 264 557 minecraft:white_concrete
fill 312 264 599 312 269 599 minecraft:purple_stained_glass
setblock 317 264 560 minecraft:light[level=14]
setblock 317 264 568 minecraft:light[level=14]
setblock 317 264 576 minecraft:light[level=14]
setblock 317 264 584 minecraft:light[level=14]
setblock 317 264 592 minecraft:light[level=14]
fill 318 264 557 318 269 557 minecraft:purple_stained_glass
setblock 318 264 587 minecraft:light_blue_stained_glass
fill 318 264 590 320 264 590 minecraft:light_blue_stained_glass
fill 320 264 589 321 264 589 minecraft:light_blue_stained_glass
fill 320 264 591 323 264 591 minecraft:light_blue_stained_glass
fill 323 264 589 323 265 590 minecraft:light_blue_stained_glass
fill 324 264 567 324 269 567 minecraft:purple_stained_glass
setblock 324 264 573 minecraft:light_blue_stained_glass
fill 324 264 574 324 307 574 minecraft:purple_stained_glass
fill 324 264 583 324 269 583 minecraft:purple_stained_glass
fill 282 265 588 282 307 588 minecraft:purple_stained_glass
setblock 282 265 594 minecraft:light_blue_stained_glass
setblock 286 265 599 minecraft:white_concrete
fill 287 265 599 287 307 599 minecraft:purple_stained_glass
fill 295 265 557 295 307 557 minecraft:purple_stained_glass
setblock 296 265 557 minecraft:sea_lantern
fill 304 265 557 304 307 557 minecraft:purple_stained_glass
fill 310 265 557 310 307 557 minecraft:purple_stained_glass
fill 315 265 569 315 266 569 minecraft:amethyst_block
fill 319 265 590 320 265 590 minecraft:light_blue_stained_glass
setblock 320 265 587 minecraft:light_blue_stained_glass
setblock 321 265 589 minecraft:light_blue_stained_glass
fill 321 265 591 323 265 591 minecraft:light_blue_stained_glass
fill 324 265 573 324 307 573 minecraft:purple_stained_glass
setblock 282 266 569 minecraft:light_blue_stained_glass
setblock 282 266 572 minecraft:sea_lantern
fill 282 266 594 282 307 594 minecraft:purple_stained_glass
fill 286 266 599 286 307 599 minecraft:purple_stained_glass
fill 296 266 557 296 268 557 minecraft:purple_stained_glass
setblock 322 266 590 minecraft:light_blue_stained_glass
fill 282 267 569 282 272 569 minecraft:purple_stained_glass
fill 282 267 572 282 307 572 minecraft:purple_stained_glass
setblock 282 267 597 minecraft:light_blue_stained_glass
setblock 313 267 557 minecraft:light_blue_stained_glass
fill 282 268 597 282 269 597 minecraft:purple_stained_glass
setblock 290 268 557 minecraft:light_blue_stained_glass
fill 295 268 569 296 269 570 minecraft:light_blue_stained_glass
fill 313 268 557 313 307 557 minecraft:purple_stained_glass
setblock 316 268 599 minecraft:white_concrete
setblock 324 268 584 minecraft:sea_lantern
fill 290 269 557 290 307 557 minecraft:purple_stained_glass
setblock 296 269 557 minecraft:light_blue_stained_glass
setblock 310 269 599 minecraft:sea_lantern
fill 316 269 599 316 273 599 minecraft:purple_stained_glass
fill 321 269 593 323 272 593 minecraft:light_blue_stained_glass
fill 322 269 592 322 272 592 minecraft:light_blue_stained_glass
fill 322 269 594 322 272 594 minecraft:light_blue_stained_glass
setblock 324 269 582 minecraft:light_blue_stained_glass
fill 324 269 584 324 280 584 minecraft:purple_stained_glass
fill 282 270 565 282 272 565 minecraft:magenta_stained_glass
setblock 282 270 573 minecraft:white_concrete
fill 282 270 574 282 289 574 minecraft:purple_stained_glass
fill 282 270 581 282 272 581 minecraft:magenta_stained_glass
setblock 282 270 587 minecraft:sea_lantern
fill 282 270 597 282 272 597 minecraft:magenta_stained_glass
fill 286 270 557 286 272 557 minecraft:magenta_stained_glass
fill 296 270 557 296 307 557 minecraft:purple_stained_glass
fill 296 270 599 296 272 599 minecraft:magenta_stained_glass
fill 302 270 557 302 272 557 minecraft:magenta_stained_glass
fill 310 270 599 310 291 599 minecraft:purple_stained_glass
fill 312 270 599 312 272 599 minecraft:magenta_stained_glass
setblock 314 270 599 minecraft:sea_lantern
fill 315 270 599 315 298 599 minecraft:purple_stained_glass
fill 318 270 557 318 272 557 minecraft:magenta_stained_glass
fill 318 270 593 320 271 593 minecraft:light_blue_stained_glass
fill 319 270 592 321 271 592 minecraft:light_blue_stained_glass
fill 319 270 594 321 271 594 minecraft:light_blue_stained_glass
fill 323 270 592 323 271 592 minecraft:light_blue_stained_glass
fill 323 270 594 323 271 594 minecraft:light_blue_stained_glass
setblock 324 270 558 minecraft:light_blue_stained_glass
fill 324 270 559 324 305 559 minecraft:purple_stained_glass
fill 324 270 567 324 272 567 minecraft:magenta_stained_glass
fill 324 270 582 324 307 582 minecraft:purple_stained_glass
fill 324 270 583 324 272 583 minecraft:magenta_stained_glass
fill 282 271 573 282 307 573 minecraft:purple_stained_glass
fill 282 271 587 282 272 587 minecraft:purple_stained_glass
fill 298 271 599 299 271 599 minecraft:white_concrete
setblock 309 271 557 minecraft:white_concrete
fill 314 271 599 314 307 599 minecraft:purple_stained_glass
setblock 317 271 557 minecraft:white_concrete
fill 324 271 558 324 282 558 minecraft:purple_stained_glass
fill 324 271 575 324 307 575 minecraft:purple_stained_glass
setblock 324 271 576 minecraft:sea_lantern
setblock 324 271 577 minecraft:purple_stained_glass
setblock 324 271 580 minecraft:sea_lantern
setblock 285 272 560 minecraft:light[level=14]
setblock 285 272 568 minecraft:light[level=14]
setblock 285 272 576 minecraft:light[level=14]
setblock 285 272 584 minecraft:light[level=14]
setblock 285 272 592 minecraft:light[level=14]
setblock 293 272 560 minecraft:light[level=14]
setblock 293 272 568 minecraft:light[level=14]
setblock 293 272 576 minecraft:light[level=14]
setblock 293 272 584 minecraft:light[level=14]
setblock 293 272 592 minecraft:light[level=14]
fill 296 272 591 296 273 592 minecraft:magenta_stained_glass
fill 298 272 599 299 289 599 minecraft:purple_stained_glass
setblock 301 272 560 minecraft:light[level=14]
setblock 301 272 568 minecraft:light[level=14]
setblock 301 272 576 minecraft:light[level=14]
setblock 301 272 584 minecraft:light[level=14]
setblock 301 272 592 minecraft:light[level=14]
fill 309 272 557 309 307 557 minecraft:purple_stained_glass
setblock 309 272 560 minecraft:light[level=14]
setblock 309 272 568 minecraft:light[level=14]
setblock 309 272 576 minecraft:light[level=14]
setblock 309 272 584 minecraft:light[level=14]
setblock 309 272 592 minecraft:light[level=14]
fill 317 272 557 317 299 557 minecraft:purple_stained_glass
setblock 317 272 560 minecraft:light[level=14]
setblock 317 272 568 minecraft:light[level=14]
setblock 317 272 576 minecraft:light[level=14]
setblock 317 272 584 minecraft:light[level=14]
setblock 317 272 592 minecraft:light[level=14]
setblock 324 272 565 minecraft:sea_lantern
fill 324 272 576 324 307 576 minecraft:purple_stained_glass
setblock 324 272 577 minecraft:white_concrete
fill 324 272 580 324 273 580 minecraft:purple_stained_glass
fill 282 273 565 282 287 565 minecraft:purple_stained_glass
setblock 282 273 569 minecraft:light_blue_stained_glass
fill 282 273 581 282 287 581 minecraft:purple_stained_glass
setblock 282 273 587 minecraft:sea_lantern
fill 282 273 597 282 287 597 minecraft:purple_stained_glass
setblock 286 273 557 minecraft:purple_stained_glass
fill 296 273 599 296 287 599 minecraft:purple_stained_glass
fill 302 273 557 302 287 557 minecraft:purple_stained_glass
setblock 312 273 557 minecraft:light_blue_stained_glass
fill 312 273 599 312 275 599 minecraft:purple_stained_glass
fill 318 273 557 318 287 557 minecraft:purple_stained_glass
setblock 318 273 599 minecraft:sea_lantern
fill 324 273 565 324 307 565 minecraft:purple_stained_glass
fill 324 273 567 324 276 567 minecraft:purple_stained_glass
fill 324 273 577 324 307 577 minecraft:purple_stained_glass
fill 324 273 583 324 287 583 minecraft:purple_stained_glass
fill 282 274 569 282 307 569 minecraft:purple_stained_glass
fill 282 274 587 282 307 587 minecraft:purple_stained_glass
setblock 286 274 557 minecraft:white_concrete
fill 312 274 557 312 289 557 minecraft:purple_stained_glass
setblock 316 274 599 minecraft:white_concrete
setblock 318 274 599 minecraft:white_concrete
setblock 324 274 580 minecraft:sea_lantern
setblock 282 275 558 minecraft:sea_lantern
setblock 282 275 559 minecraft:light_blue_stained_glass
fill 286 275 557 286 287 557 minecraft:purple_stained_glass
fill 316 275 599 316 307 599 minecraft:purple_stained_glass
setblock 318 275 599 minecraft:light_blue_stained_glass
fill 324 275 580 324 297 580 minecraft:purple_stained_glass
setblock 324 275 581 minecraft:white_concrete
fill 282 276 558 282 296 559 minecraft:purple_stained_glass
setblock 282 276 563 minecraft:light_blue_stained_glass
setblock 288 276 599 minecraft:white_concrete
setblock 312 276 599 minecraft:white_concrete
fill 318 276 599 318 307 599 minecraft:purple_stained_glass
fill 324 276 581 324 307 581 minecraft:purple_stained_glass
fill 282 277 563 282 282 563 minecraft:purple_stained_glass
fill 288 277 599 288 307 599 minecraft:purple_stained_glass
setblock 293 277 557 minecraft:light_blue_stained_glass
setblock 311 277 599 minecraft:light_blue_stained_glass
fill 312 277 599 312 287 599 minecraft:purple_stained_glass
setblock 324 277 564 minecraft:light_blue_stained_glass
setblock 324 277 567 minecraft:white_concrete
setblock 324 277 597 minecraft:white_concrete
schedule function dropper:buildpart/138_2 1t
